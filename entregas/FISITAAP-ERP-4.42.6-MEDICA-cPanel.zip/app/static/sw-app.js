// Service worker de la aplicación (3.55, venta sin internet): deja abrir el sistema y la caja aunque se caiga la conexión.
// - Archivos del programa (JS, CSS, imágenes, vendor): se sirven de la caché. 3.87: mientras no cambie ningún archivo del programa no se
//   vuelven a pedir. El servidor pone en HUELLA la huella de esos archivos: si cambia uno (una entrega, aunque se esté extrayendo, o un
//   arreglo sin subir VERSION), cambia este archivo, el navegador instala de nuevo el service worker y guarda el programa otra vez. Sin
//   HUELLA (archivo servido tal cual) o en un servidor local de desarrollo, lo guardado se sigue actualizando en segundo plano.
// - Lecturas que la caja necesita (sesión, empresa, clientes, ítems, registros, sistema): primero la red; sin red, la última copia
//   guardada, marcada con la cabecera X-Desde-Cache para que la pantalla avise «sin conexión». La copia se guarda por empresa y
//   por sesión (cabeceras X-Empresa y Authorization) para no mezclar datos de otra empresa u otro usuario.
// - Nada que escriba (POST, PUT, DELETE) pasa por aquí: la caja guarda esas ventas en una cola y las manda al volver la red.
const VERSION = 'app-v4.42.6';
const HUELLA = '';   // 3.87: la llena el servidor al entregar este archivo (main.py, sw_app); no la cambie a mano
const ESTATICO = VERSION + HUELLA + ':estatico', API = VERSION + ':api';
const LECTURAS = ['/api/arranque', '/api/fisitaap/', '/api/pedidos/negocio', '/api/auth/yo', '/api/empresa', '/api/clientes', '/api/productos', '/api/registros', '/api/sistema', '/api/inventario/bodegas', '/api/bancos/cuentas', '/api/exoneraciones/cliente/'];

// 3.73: el programa entero se guarda al instalar (una sola vez por versión): la siguiente pantalla abre sin pedir nada al servidor
const PROGRAMA = ['/app/', '/ui.css', '/js/paleta-inicial.js', '/js/app.js', '/js/menu.js', '/js/iconos.js', '/js/vendor/vue.esm-browser.prod.min.js', '/js/api.js', '/js/components.js', '/js/paletas.js', '/js/avisos.js', '/js/pages/rrhh/_datos.js', '/fonts/inter-latin.woff2', '/fonts/manrope-latin.woff2',
                  '/app/fisitaap/', '/js/fis/app.js', '/js/fis/sesion.js', '/js/fis/ui.js', '/fisitaap/fis.css', '/fisitaap/assets/app.bundle.css', '/fisitaap/assets/v12.css', '/fisitaap/assets/linea-reference-r15.css', '/fisitaap/assets/interface-r15.css', '/fisitaap/assets/interface-r14.css', '/fisitaap/assets/fisitapp-logo.webp'];   // 3.74: FISITAAP embebido
// 3.87: se pide al servidor (cache: 'no-cache'), no a la caché HTTP del navegador: vendor y fuentes duran ahí 7 días y quedarían viejos
self.addEventListener('install', e => { e.waitUntil(caches.open(ESTATICO).then(c => Promise.all(PROGRAMA.map(u => c.add(new Request(u, { cache: 'no-cache' })).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {   // 3.87: fuera también el programa guardado con otra HUELLA (las copias de lecturas siguen por VERSION)
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('app-v') && k !== ESTATICO && k !== API).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', e => {
  if (e.data && e.data.tipo === 'limpiar') caches.delete(API);            // cierre de sesión o cambio de empresa: fuera las copias de lecturas
});
// aviso de pedido nuevo (FISITAAP, 3.58): al tocarlo se abre (o se trae al frente) la bandeja de pedidos
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/app/fisitaap/#/pedidos';   // 3.74
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => {
    const c = cs.find(x => x.url.includes('/app'));
    if (c) { c.navigate(url).catch(() => {}); return c.focus(); }
    return self.clients.openWindow(url);
  }));
});

const DESARROLLO = ['localhost', '127.0.0.1', '[::1]'].includes(self.location.hostname);   // 3.87
const PROPIO = /^\/(js|fonts|img|fisitaap)\/|^\/[^/]+\.(css|js)$/;   // 3.87: archivos del programa (app/static, lo que cubre HUELLA)

function claveApi(req) {
  const emp = req.headers.get('X-Empresa') || '', tok = req.headers.get('Authorization') || '';
  // la clave incluye la empresa y un fragmento de la sesión: una copia nunca sirve a otra empresa ni a otro usuario
  return new Request(req.url + (req.url.includes('?') ? '&' : '?') + '_sw=' + encodeURIComponent(emp + '|' + tok.slice(-12)), { method: 'GET' });
}

self.addEventListener('fetch', e => {
  const req = e.request; const u = new URL(req.url);
  if (req.method !== 'GET' || u.origin !== location.origin) return;
  if (u.pathname.startsWith('/api/')) {
    if (!LECTURAS.some(p => u.pathname === p || u.pathname.startsWith(p))) return;
    const clave = claveApi(req);
    e.respondWith(fetch(req).then(r => {
      if (r.ok) { const copia = r.clone(); caches.open(API).then(c => c.put(clave, copia)); }
      return r;
    }).catch(async () => {
      const c = await caches.open(API); const g = await c.match(clave);
      if (!g) return new Response(JSON.stringify({ detail: 'Sin conexión con el servidor y sin copia guardada' }), { status: 503, headers: { 'Content-Type': 'application/json' } });
      const h = new Headers(g.headers); h.set('X-Desde-Cache', '1');
      return new Response(await g.blob(), { status: 200, headers: h });
    }));
    return;
  }
  // la página de la aplicación y sus archivos: caché primero (3.87: sin volver a preguntar mientras HUELLA no cambie, salvo en desarrollo)
  const esPagina = req.mode === 'navigate' || u.pathname === '/app/' || u.pathname === '/app' || u.pathname === '/app/index.html';
  e.respondWith(caches.open(ESTATICO).then(async c => {
    const guardado = await c.match(req, { ignoreSearch: esPagina });
    if (guardado && !esPagina && !DESARROLLO && HUELLA && PROPIO.test(u.pathname)) return guardado;   // 3.87: antes cada carga revalidaba ~17 archivos (304)
    const red = fetch(req).then(r => { if (r.ok && (r.type === 'basic' || r.type === 'default')) c.put(req, r.clone()); return r; }).catch(() => null);
    if (esPagina) { const r = await red; return r || guardado || new Response('Sin conexión', { status: 503 }); }   // la página: primero la red (así entra la versión nueva)
    if (guardado) { red.catch(() => {}); return guardado; }
    const r = await red; return r || new Response('Sin conexión', { status: 503 });
  }));
});
