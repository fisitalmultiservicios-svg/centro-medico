"""Cuentas (multicuenta), inicio de sesión, MFA (TOTP), roles, auditoría y panel de administración.

Modelo:
- Un **superadministrador** crea las cuentas de los clientes desde el panel Admin (correo + contraseña + empresa):
  al crear la empresa se genera su **base de datos propia** y su **clave de cifrado propia**.
- El **cliente** inicia sesión con correo y contraseña, entra solo a las empresas donde está **autorizado explícitamente**
  (con un rol), puede cambiar su contraseña y activar MFA.
- **Roles** (aplicados en el servidor): Administrador (todo), Contador (consulta + configuración de documentos y contabilidad),
  Vendedor (facturar, cotizar, clientes, productos), Solo lectura (consultar).
- Bloqueo temporal tras 5 intentos fallidos (15 minutos) y auditoría de las acciones relevantes.

Endurecimiento para exposición pública:
- Límite de intentos **por IP** en login / MFA / setup (además del bloqueo por cuenta) y respuesta de tiempo constante.
- **Sesiones en el servidor** (tabla `sesion`): revocables (cerrar sesión, cerrar todas, cambio de contraseña, bloqueo),
  con expiración por inactividad. El token lleva el id de sesión.
- Cookie de sesión emitida por el servidor con `HttpOnly; Secure; SameSite=Strict`; la cookie solo vale para GET (descargas);
  toda operación que modifica datos exige el header Authorization (sin CSRF).
- **MFA obligatorio** para el administrador del sistema y para quien tenga rol Administrador en alguna empresa; códigos de respaldo.
- Recursos humanos solo con MFA activo (4.7): sin la verificación en dos pasos el permiso rrhh no queda en la sesión ni en las
  peticiones (no se exige al entrar; el Administrador y el administrador del sistema ya la tienen obligatoria).
- Renuncia a la verificación en dos pasos (4.7): quien la tiene exigida (nunca el administrador del sistema) puede declinarla
  aceptando un descargo (app/static/renuncia-mfa.html) con las dos casillas, su contraseña y la palabra ACEPTO; queda la constancia
  (versión, fecha, IP, navegador, auditoría y copia por correo). Vale mientras el interruptor del sistema esté encendido y la empresa
  no exija la verificación sin excepción (mfa_cubierto).
- Política de contraseñas (12+ caracteres, no comunes, no derivadas del correo) y aviso por correo al entrar desde una IP nueva.
- Verificación contra robots (Turnstile de Cloudflare) en el inicio de sesión y en la recuperación de contraseña, si el
  administrador del sistema la activó en Sitio web (3.84; sitio.verificar_login).
"""
import base64
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import struct
import threading
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Body, Cookie, Depends, Header, HTTPException, Request, Response
from pydantic import BaseModel
from sqlalchemy import Index, delete as sa_delete, func as sa_func
from sqlmodel import Field, Session, SQLModel, select

from . import secretos
from .config import DATA_DIR, DATOS_EJEMPLO, PROVEEDOR_SISTEMAS, nombre_sistema, correo_ventas
from .db import Auditoria, Empresa, central, engine, engine_empresa, get_session
from .config import URL_PUBLICA

router = APIRouter(prefix="/api/auth", tags=["auth"])
admin = APIRouter(prefix="/api/admin", tags=["admin"])

_KEY_FILE = DATA_DIR / "secret.key"
if os.getenv("FE_SECRET_KEY"):
    SECRET = os.environ["FE_SECRET_KEY"].strip().encode()
    if len(SECRET) < 32:                                   # (R227)
        raise RuntimeError("FE_SECRET_KEY debe tener al menos 32 caracteres (genere una con secrets.token_urlsafe(48))")
elif _KEY_FILE.exists():
    SECRET = _KEY_FILE.read_bytes()
    if len(SECRET) < 32:
        raise RuntimeError(f"{_KEY_FILE} está dañado (debe tener 32 bytes): restáurelo de un respaldo o bórrelo para generar otro (cierra todas las sesiones)")
else:
    # Creación atómica: si varios procesos de Passenger arrancan a la vez, solo uno escribe la clave y los demás la releen
    # (si no, cada proceso firmaría sesiones con una clave distinta y los inicios de sesión fallarían al azar).
    SECRET = secrets.token_bytes(32)
    try:
        _fd = os.open(_KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(_fd, "wb") as _f:
            _f.write(SECRET)
    except FileExistsError:
        SECRET = _KEY_FILE.read_bytes()

DURACION_SESION = 60 * 60 * 12       # 12 horas (máximo absoluto)
INACTIVIDAD = 60 * 60                # 60 minutos sin actividad cierran la sesión
DURACION_SUPLANTACION = 60 * 60      # 4.35: «Entrar como» otro usuario (soporte, desde la consola) dura como máximo 1 hora
DURACION_MFA = 60 * 5
MAX_INTENTOS = 5                     # por correo y conexión, y por correo desde conexiones desconocidas (3.87; ver login)
MINUTOS_BLOQUEO = 15
LIMITE_IP = (30, 300)                # 30 intentos por IP cada 5 minutos en login / MFA / setup (cuenta también los correctos) (R295)
LIMITE_IP_PROGRAMA = (150, 300)      # 4.25 (9b, U12): en el programa local real, el tope GENERAL de ingresos (todas las personas de una caja salen por la misma dirección)
MIN_PASSWORD = 12
CORREO_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
COOKIE = "facturacr_token"
PRODUCCION = os.getenv("FE_ENTORNO", "").lower() in ("produccion", "production", "prod")
_HASH_FICTICIO = None                # para que un correo inexistente tarde lo mismo que uno real

PASSWORDS_COMUNES = {
    "password", "contraseña", "contrasena", "123456789012", "qwertyuiop12", "administrador", "admin1234567", "facturacr123",
    "costarica123", "bienvenido12", "password1234", "1234567890ab", "abcdefghijkl", "qwerty123456", "letmein12345", "welcome12345",
}

# ----------------------------------------------------------------------------- límite por IP (persistente en la base central)
# Cada intento queda en la tabla intentoip: sobrevive a reinicios y vale para todos los procesos (Passenger levanta varios).
_intentos_ip: dict[str, list[float]] = defaultdict(list)     # respaldo en memoria si la base no responde
_lock_ip = threading.Lock()
_purga_ip = [0.0]


class IntentoIp(SQLModel, table=True):
    __table_args__ = (Index("ix_intentoip_clave_ip_momento", "clave", "ip", "momento"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    clave: str                            # login, mfa, setup, recuperar, recuperar_correo, restablecer
    ip: str                               # IP o sujeto (u<id>, correo)
    momento: float


# Claves que se persisten (autenticación: deben sobrevivir reinicios y valer para todos los procesos). Las de alto volumen
# (api, publico, consulta, reporte) se limitan en memoria por proceso: una fila por petición en la base no vale la pena.
CLAVES_PERSISTENTES = ("login", "mfa", "setup", "recuperar", "recuperar_correo", "restablecer", "renuncia", "renuncia_fallo", "sinc", "sinc_xml", "sinc_usuarios", "sinc_usuario",
                       "login_prog", "mfa_prog", "sinc_par", "sinc_cod", "sinc_rec", "sinc_producto")   # 4.25 (tanda 9): + cambios del programa a ítems de la web; 4.25 (tanda 5): + conectar una computadora nueva (iniciar, códigos que no existen, secretos que no existen); 4.7: + renuncia a la verificación; 4.15: + canje del código de vinculación; 4.25: + XML en lote, y bajada de usuarios y fichas por instalación (cada una con su clave); + topes del ingreso por instalación (claves propias: ninguna IP, ni escrita a mano, cae en ellas)
# 4.25 (revisión): con `sujeto` (el ingreso del programa por instalación, «inst<id>») los contadores usan claves propias, nunca las de la
# web: en la web el sujeto es la dirección de quien llama, que detrás de ciertos proxys puede venir escrita a mano y coincidir con «inst<id>».
CLAVES_SUJETO = {"login": "login_prog", "login_fallo": "login_fallo_prog", "mfa": "mfa_prog"}


def clave_contador(clave: str, sujeto: str | None) -> str:
    """4.25: la clave del contador: la de siempre sin `sujeto`; con `sujeto`, la propia (CLAVES_SUJETO)."""
    return CLAVES_SUJETO.get(clave, clave) if sujeto else clave


def _limitar_memoria(clave: str, ip: str, maximo: int, ventana: int, ahora: float, aviso: str, registrar: bool = True):
    with _lock_ip:
        lista = _intentos_ip[f"{clave}:{ip}"]
        lista[:] = [t for t in lista if ahora - t < ventana]
        if len(lista) >= maximo:
            raise HTTPException(429, aviso)
        if registrar:
            lista.append(ahora)


def limitar_ip(request: Request | None, clave: str = "auth", maximo: int | None = None, ventana: int | None = None, mensaje: str | None = None, sujeto: str | None = None, registrar: bool = True):
    """Rechaza (429) cuando una misma IP (o `sujeto`, p. ej. el usuario) supera `maximo` intentos en la ventana (LIMITE_IP por defecto).
    4.5: con registrar=False solo revisa el cupo sin contar el intento (para contar únicamente los fallos: revisar antes, registrar al fallar)."""
    ip = (sujeto or _ip(request) or "?")[:120]
    maximo, ventana = maximo or LIMITE_IP[0], ventana or LIMITE_IP[1]
    ahora = time.time()
    aviso = mensaje or "Demasiados intentos desde su conexión. Espere unos minutos e intente de nuevo."
    if clave not in CLAVES_PERSISTENTES:
        return _limitar_memoria(clave, ip, maximo, ventana, ahora, aviso, registrar)
    try:
        with Session(engine) as s:                                   # sin el lock del proceso: la transacción de SQLite basta
            if ahora - _purga_ip[0] > 600:                           # intentos de más de un día no se consultan nunca
                _purga_ip[0] = ahora
                s.exec(sa_delete(IntentoIp).where(IntentoIp.momento < ahora - 86400)); s.commit()
            n = s.exec(select(sa_func.count()).select_from(IntentoIp).where(IntentoIp.clave == clave, IntentoIp.ip == ip, IntentoIp.momento > ahora - ventana)).one()
            if int(n or 0) >= maximo:
                raise HTTPException(429, aviso)
            if registrar:
                s.add(IntentoIp(clave=clave, ip=ip, momento=ahora)); s.commit()
            return
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001  base no disponible: se limita en memoria para no dejar pasar todo
        pass
    _limitar_memoria(clave, ip, maximo, ventana, ahora, aviso, registrar)

# ----------------------------------------------------------------------------- roles y permisos
# «Avanzado» (3.32): todo lo del Administrador en la operación (ventas y caja, compras y bancos, inventario, contabilidad, reportes,
# recursos humanos y módulos del hotel) sin la configuración de la empresa, los formatos de impresión ni los usuarios.
ROLES = ["Administrador", "Avanzado", "Contador", "Vendedor", "Cajero", "Solo lectura"]
from .medica_config import PERMISOS as PERMISOS_MEDICA, habilitada as _medica_habilitada

PERMISOS = {
    **{p: set() for p in PERMISOS_MEDICA},
    "ver": {"Administrador", "Avanzado", "Contador", "Vendedor", "Cajero", "Solo lectura"},   # entrar y consultar lo propio de su trabajo
    "pos": {"Administrador", "Avanzado", "Vendedor", "Cajero"},        # punto de venta: cobrar en caja (tiquetes/facturas de contado), cierres, clientes rápidos
    "tike": {"Administrador", "Avanzado"},                             # TiKe (3.52): tickets de soporte, portal del cliente y buzón
    "tike_claves": {"Administrador", "Avanzado"},                      # TiKe (3.54): ver y copiar contraseñas de la documentación del cliente (Avanzado = todo menos configuración)
    "ver_todo": {"Administrador", "Avanzado", "Contador", "Solo lectura"},                    # ver también gastos, bancos, contabilidad y reportes
    "escribir": {"Administrador", "Avanzado", "Contador", "Vendedor"},                        # guardar registros de módulos sin permiso específico
    "facturar": {"Administrador", "Avanzado", "Vendedor"},             # emitir comprobantes, enviar a Hacienda, correo, cotizaciones, recurrentes
    "catalogos": {"Administrador", "Avanzado", "Vendedor"},            # clientes, productos, bodegas
    "inventario": {"Administrador", "Avanzado", "Vendedor"},           # ajustes, transferencias
    "cobros": {"Administrador", "Avanzado", "Contador", "Vendedor"},   # pagos recibidos (recibos de caja y REP), botón Pagada
    "gastos": {"Administrador", "Avanzado", "Contador"},               # compras, pagos a proveedores, recepción de comprobantes, bancos
    "contabilidad": {"Administrador", "Avanzado", "Contador"},         # asientos, catálogo, parametrización, periodos, activos
    "reportes": {"Administrador", "Avanzado", "Contador"},             # resumen financiero del Inicio, reporte ejecutivo y reportes
    "documentos": {"Administrador", "Contador"},           # configuración de formatos de impresión
    "configurar": {"Administrador"},                       # empresa, Hacienda, certificado, SMTP, logo, exportar datos
    "rrhh": {"Administrador", "Avanzado"},                 # empleados, planilla, vacaciones, liquidaciones (datos sensibles); 4.7: solo con MFA (quitar_rrhh_sin_mfa)
    "limpieza": {"Administrador", "Avanzado"},             # hotel: ama de llaves (tablero de habitaciones, reportes de limpieza) (2.4)
    "mantenimiento": {"Administrador", "Avanzado"},        # hotel: mantenimiento (incidencias, habitaciones fuera de servicio) (2.4)
    "seguridad": {"Administrador", "Avanzado"},            # hotel: seguridad (bitácora, visitantes y vehículos, incidentes, objetos perdidos; sin montos) (3.3)
    "usuarios": {"Administrador"},
}
# 3.87: permisos que existen solo si el plan trae su módulo (los que quita planes.filtrar_permisos)
PERMISOS_MODULO = frozenset({"contabilidad", "rrhh", "reportes", "pos", "tike", *PERMISOS_MEDICA})
PERMISOS_NOMBRE = {
    **PERMISOS_MEDICA,
    "ver": "Entrar y consultar", "ver_todo": "Ver gastos, bancos, contabilidad y reportes", "escribir": "Guardar registros de los módulos",
    "facturar": "Emitir facturas, tiquetes, notas y cotizaciones", "catalogos": "Clientes e ítems", "inventario": "Inventario",
    "cobros": "Registrar cobros (recibos de caja y REP)", "gastos": "Compras, pagos a proveedores, recepción de comprobantes y bancos",
    "contabilidad": "Asientos, catálogo y parametrización contable", "reportes": "Resumen financiero y reportes", "documentos": "Formatos de impresión",
    "configurar": "Configuración de la empresa y exportación de datos", "rrhh": "Recursos humanos (empleados, planilla, liquidaciones; pide la verificación en dos pasos)", "usuarios": "Usuarios de la empresa",
    "pos": "Punto de venta (caja, cobros de mostrador y cierres)",
    "tike": "TiKe: tickets de soporte, portal del cliente y buzón de correo",
    "tike_claves": "TiKe: ver y copiar las contraseñas guardadas en la documentación del cliente",
    "limpieza": "Hotel: ama de llaves (tablero de habitaciones y reportes de limpieza)", "mantenimiento": "Hotel: mantenimiento (incidencias y habitaciones fuera de servicio)",
    "seguridad": "Hotel: seguridad (bitácora, visitantes, vehículos, incidentes y objetos perdidos; sin montos)",
}
DESCRIPCION_ROLES = {
    "Administrador": "Todo: factura, cobra, registra gastos y compras, contabilidad, bancos, reportes, recursos humanos, configuración y usuarios.",
    "Avanzado": "Todo lo de la operación: factura y cobra, caja, compras y bancos, inventario, contabilidad, reportes, recursos humanos (con la verificación en dos pasos activa) y módulos del hotel. No cambia la configuración de la empresa (Hacienda, certificado, correo, impuestos, monedas, formatos de impresión) ni administra usuarios.",
    "Contador": "Cobros y pagos, compras y recepción de comprobantes, bancos, contabilidad, reportes y formatos de impresión. No emite facturas, no cambia clientes ni ítems y no toca la configuración.",
    "Vendedor": "Emite facturas, tiquetes, notas y cotizaciones, administra clientes, ítems e inventario y registra cobros. No ve gastos, bancos, contabilidad ni reportes financieros.",
    "Cajero": "Solo el punto de venta: cobra en la caja (tiquetes y facturas de contado), crea clientes desde la caja y hace su cierre. No entra al resto del sistema.",
    "Solo lectura": "Ve todo (facturas, cobros, gastos, bancos, contabilidad y reportes) sin poder crear ni cambiar nada.",
}
# Permiso para guardar cada registro de la interfaz (PUT /api/registros/{clave}), por clave o prefijo
REGISTROS_PERMISO = {
    "asientos": "contabilidad", "catalogo": "contabilidad", "param_contable": "contabilidad", "periodos_": "contabilidad",
    "numeraciones_contables": "contabilidad", "activos": "contabilidad", "tipos_asiento": "contabilidad", "saldos_iniciales": "contabilidad",
    "centros_costo": "contabilidad", "presupuesto_": "contabilidad",      # centros de costo y presupuesto por año (3.8)
    "bancos": "gastos", "movimientos": "gastos", "conciliaciones": "gastos", "compras": "gastos", "ordenes": "gastos", "pagos_gastos": "gastos",
    "notas_debito_gastos": "gastos", "nd_gastos": "gastos", "recurrentes_gastos": "gastos", "gastos": "gastos",
    "cotizaciones": "facturar", "remisiones": "facturar",
    "monedas": "configurar", "terminos_pago": "configurar", "vendedores": "configurar", "otros_cargos": "configurar", "plantillas": "configurar",
    "notificaciones": "configurar", "campos_adicionales": "catalogos", "integraciones": "configurar", "impuestos": "configurar", "retenciones": "configurar",
    "reportes_recientes": "ver", "reportes_favoritos": "ver", "reportes_exportables": "ver", "dash": "ver",
    "empleados": "rrhh", "planillas": "rrhh", "vacaciones_tomadas": "rrhh", "liquidaciones": "rrhh", "rrhh_": "rrhh",
    # inventario y catálogos (R122): antes caían en el genérico 'escribir' y el Contador editaba ítems
    "items_extra": "catalogos", "categorias": "catalogos", "variantes": "catalogos", "listas_precios": "catalogos", "importaciones": "catalogos",
    "actualizaciones": "catalogos", "atributos": "catalogos",
    "inventario_config": "configurar", "proveedor_items": "inventario",      # método de costeo y relaciones proveedor → ítem (3.75)
    "config_documentos_opciones": "documentos", "empresa_extra": "configurar", "config_documentos": "documentos", "roles_": "configurar",
    "notas-credito": "facturar", "notas-debito": "facturar", "numeracion-": "facturar",
    # punto de venta: la configuración la cambia quien configura; cajas, cierres y ventas en espera quien factura
    "pos_config": "configurar", "pos_impresoras": "configurar", "pos_promos": "configurar", "pos_": "pos",   # impresoras de comanda y comprobantes (3.10)
    # impresión, correo y recordatorios (los lee el servidor al imprimir, enviar correos y mandar recordatorios)
    "estilo_impresion": "configurar", "firma_documentos": "configurar", "plantillas_correo": "configurar", "recordatorios_enviados": "configurar",
    # hotel (2.2): la configuración (categorías, temporadas y tarifas) la cambia quien configura; reservas, huéspedes y estado de
    # las habitaciones quien escribe (recepción, camarera); la cuenta del huésped también desde la caja (cargo a habitación)
    "hotel_config": "configurar", "hotel_categorias": "configurar", "hotel_folios": "pos",
    # reportes de problemas (2.4): cualquier usuario puede reportar; los tipos de problema los agrega cada módulo
    "hotel_reportes": "ver", "hotel_tipos_problema": "escribir",
    # seguridad (3.3): bitácora, visitantes, incidentes y objetos perdidos los escribe quien tiene seguridad (o escribir); lavandería y preventivo, limpieza/mantenimiento o escribir
    "hotel_seg_": "seguridad", "hotel_lavanderia": "limpieza", "hotel_preventivo": "mantenimiento", "hotel_": "escribir",
    "recetas": "catalogos",                                           # fichas técnicas (3.4): quien administra los ítems
}


def permiso_registro(clave: str) -> str:
    for prefijo, permiso in REGISTROS_PERMISO.items():
        if clave == prefijo or clave.startswith(prefijo):
            return permiso
    return "escribir"


# Registros que necesita el punto de venta (lo único que lee un usuario que solo tiene 'pos')
REGISTROS_POS = ("categorias", "items_extra", "listas_precios", "contactos_extra", "monedas", "pos_config", "pos_impresoras", "pos_cajas", "pos_ventas", "pos_espera", "vendedores",
                 "hotel_config", "hotel_habitaciones", "hotel_reservas", "hotel_huespedes", "hotel_folios", "hotel_reportes", "hotel_tipos_problema",   # cargo a habitación y reportes desde la caja (2.2/2.4)
                 "hotel_servicios", "hotel_servicios_agenda", "hotel_salones", "hotel_eventos")   # servicios y eventos: el cajero cobra o carga lo de paso (3.5/3.6)
# (3.20) el cajero ya no recibe depósitos en garantía, cierres del día, contratos de agencias, lavandería ni preventivo: no los usa en la caja
# Registros con dinero del hotel y de la caja: solo quien opera recepción, reservas, caja o facturación (o ve todo). Camarera y
# Técnico leen habitaciones, reservas, huéspedes, servicios y eventos (lo que muestra su tablero), no las cuentas, depósitos ni cierres (3.20).
REGISTROS_MONTOS = {"hotel_folios", "hotel_cierres", "hotel_depositos", "hotel_agencias", "hotel_diario", "hotel_cotizaciones"}   # 3.87: + cotizaciones (solo precios)
PERMISOS_MONTOS = {"escribir", "pos", "cobros", "facturar", "ver_todo"}
# 3.87: lo que sí leen esos roles, pero sin el dinero: la reserva (huésped, habitación, fechas, estado) sin total, tarifa ni
# historial (que anota los montos), la configuración del hotel sin tarifas ni recargos, y servicios, salones y eventos sin precios.
# Al guardar, el servidor repone lo que no se les envió (reponer_montos): su copia sin montos nunca borra los montos guardados.
CAMPOS_MONTOS = {
    "hotel_reservas": ("total", "tarifa_noche", "tarifa", "neto", "iva", "adelanto_requerido", "precio_manual", "penalidad", "historial"),
    "hotel_config": ("tarifas", "temporadas", "planes", "cargos_auto", "persona_extra", "finde_pct", "ocupacion_reglas", "larga_reglas",
                     "tope_cuenta", "adelanto_pct"),
    "hotel_servicios": ("precio", "comision_pct"), "hotel_servicios_agenda": ("precio", "total", "comision_pct", "liquidado"),
    "hotel_salones": ("precio", "precio_hora"), "hotel_eventos": ("lineas", "historial", "anticipo_pct"),
}
# 3.87: comprobantes, pagos, borradores, recurrentes, costos e inventario: cualquier permiso de la operación o de la administración.
# Quedan fuera los roles operativos (Camarera, Técnico, Seguridad, Técnico de soporte, solo RRHH), que antes los recibían completos
# con solo «ver» (y más que el Cajero, que solo ve lo de hoy).
PERMISOS_DOCUMENTOS = PERMISOS_MONTOS | {"gastos", "contabilidad", "reportes", "inventario", "catalogos", "documentos", "configurar"}
# 3.87: documentos de venta guardados como registros (cotizaciones, remisiones y notas): tampoco para esos roles
REGISTROS_DOCUMENTOS = ("cotizaciones", "remisiones", "notas-credito", "notas-debito")


def sin_montos(permisos) -> bool:
    """(3.87) Rol sin ningún permiso de dinero: no recibe REGISTROS_MONTOS ni los CAMPOS_MONTOS."""
    return not (set(permisos) & PERMISOS_MONTOS)


def oculta_montos(permisos, clave: str) -> bool:
    """(3.87) Si a este rol se le quitan los CAMPOS_MONTOS de la clave: sin permisos de dinero y sin el permiso que guarda la
    clave (quien configura el hotel ve y cambia sus tarifas aunque no cobre: antes las recibía vacías y al guardar las borraba)."""
    return clave in CAMPOS_MONTOS and sin_montos(permisos) and permiso_registro(clave) not in permisos


def recortar_montos(permisos, clave: str, datos):
    """(3.87) Los datos del registro sin los campos con dinero para quien no los ve; para los demás, tal cual."""
    campos = CAMPOS_MONTOS.get(clave)
    if not campos or not oculta_montos(permisos, clave):
        return datos
    quitar = lambda x: {k: v for k, v in x.items() if k not in campos} if isinstance(x, dict) else x   # noqa: E731
    return [quitar(x) for x in datos] if isinstance(datos, list) else quitar(datos)


def reponer_montos(clave: str, guardado, nuevo):
    """(3.87) Lo que guarda un rol sin montos deja los campos con dinero de un elemento que ya existe como estaban: no se le
    enviaron, así que lo que mande en ellos es de su copia recortada (la pantalla rellena tarifas:{} o un historial [nuevo] que
    borraría el guardado). En un alta queda lo enviado."""
    campos = CAMPOS_MONTOS.get(clave)
    if not campos or not isinstance(guardado, dict) or not isinstance(nuevo, dict):
        return nuevo
    return {**{k: v for k, v in nuevo.items() if k not in campos}, **{k: guardado[k] for k in campos if k in guardado}}


def solo_pos(permisos) -> bool:
    """Usuario que solo puede usar el punto de venta (rol Cajero o personalizado con solo ese permiso)."""
    return "pos" in permisos and not (set(permisos) - {"ver", "pos"})


# 3.87: permisos de vender, cobrar, llevar inventario o administrar. Quien no tiene ninguno ni la caja es un rol de un solo módulo
# (Técnico de soporte, solo RRHH, Camarera, Técnico, Seguridad): hace su trabajo sin leer ventas, cobros, recurrentes, cotizaciones
# ni montos de clientes (antes los leía completos con solo «ver», más que el Cajero).
PERMISOS_NEGOCIO = {"escribir", "facturar", "cobros", "catalogos", "inventario", "gastos", "contabilidad", "reportes", "documentos", "configurar", "ver_todo"}


def solo_modulo(permisos) -> bool:
    """(3.87) Rol sin caja y sin ningún permiso de PERMISOS_NEGOCIO."""
    return not (set(permisos) & (PERMISOS_NEGOCIO | {"pos"}))


def puede_leer_registro(permisos, clave: str) -> bool:
    """Quién puede LEER cada registro: RRHH solo con su permiso; gastos, bancos, contabilidad y reportes con su permiso o
    con 'ver_todo' (Contador, Solo lectura); el cajero solo lo del punto de venta; lo demás (ventas, inventario,
    configuración general) cualquier rol."""
    if solo_pos(permisos):
        return clave in REGISTROS_POS or clave.startswith("pos_")
    if clave == "gastos_rectificaciones":                            # 4.23: lo eliminado o cambiado de meses pasados también lo consulta quien lleva la contabilidad
        return bool(set(permisos) & {"gastos", "contabilidad", "ver_todo"})
    if (clave in REGISTROS_MONTOS or clave.startswith("pos_")) and not (set(permisos) & PERMISOS_MONTOS):
        return False
    if clave in REGISTROS_DOCUMENTOS and not (set(permisos) & PERMISOS_DOCUMENTOS):   # 3.87: Camarera, Técnico, Seguridad, soporte, RRHH
        return False
    p = permiso_registro(clave)
    if p in ("facturar", "cobros", "inventario") and solo_modulo(permisos):   # 3.87: cotizaciones, remisiones, notas y costos de proveedores
        return False
    if p == "rrhh":
        return "rrhh" in permisos
    if p in ("seguridad", "limpieza", "mantenimiento"):              # módulos del hotel: su permiso o el de recepción (escribir)
        return p in permisos or "escribir" in permisos or "ver_todo" in permisos   # 3.87: y quien ve todo (Solo lectura) los consulta; escribir sigue pidiendo el permiso
    if p in ("gastos", "contabilidad", "reportes"):
        return p in permisos or "ver_todo" in permisos
    if clave in ("firma_documentos", "recordatorios_enviados"):      # la firma en alta resolución y la lista de morosos no son para todos
        return "configurar" in permisos or "documentos" in permisos
    return True


# ----------------------------------------------------------------------------- roles personalizados por empresa
PERMISOS_ASIGNABLES = [p for p in PERMISOS if p not in ("ver", "usuarios")]   # 'ver' va siempre; administrar usuarios es solo del Administrador


def validar_rol_personalizado(nombre: str, permisos) -> tuple[str, list[str]]:
    nombre = " ".join(str(nombre or "").split())
    if not 2 <= len(nombre) <= 40:
        raise HTTPException(400, "El nombre del rol debe tener entre 2 y 40 caracteres")
    if nombre.lower() in {r.lower() for r in ROLES}:
        raise HTTPException(400, f"«{nombre}» es un rol base; elija otro nombre")
    lista = sorted({str(p) for p in (permisos or [])})
    malos = [p for p in lista if p not in PERMISOS_ASIGNABLES]
    if malos:
        raise HTTPException(400, "Permisos no asignables: " + ", ".join(malos) + (" (administrar usuarios es solo del Administrador)" if "usuarios" in malos else ""))
    if not lista:
        raise HTTPException(400, "Marque al menos un permiso")
    return nombre, lista


def rol_personalizado(s: Session, empresa_id: int, nombre: str | None):
    if not nombre:
        return None
    for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == empresa_id)).all():
        if r.nombre.lower() == nombre.lower():
            return r
    return None


def permisos_de_rol(s: Session, empresa_id: int, rol: str | None) -> set[str]:
    """Permisos efectivos de un rol en una empresa: base (tabla PERMISOS) o personalizado ('ver' + los marcados)."""
    if rol in ROLES:
        return {p for p, rs in PERMISOS.items() if rol in rs}
    r = rol_personalizado(s, empresa_id, rol)
    if not r:
        return set()
    try:
        lista = json.loads(r.permisos or "[]")
    except ValueError:
        lista = []
    return {"ver"} | {p for p in lista if p in PERMISOS}


def rol_valido(s: Session, empresa_id: int, rol: str | None) -> bool:
    return rol in ROLES or rol_personalizado(s, empresa_id, rol) is not None


def rol_exige_mfa(s: Session, empresa_id: int, rol: str | None) -> bool:
    """Administrador y cualquier rol que pueda cambiar la configuración o los usuarios deben tener MFA."""
    return rol == "Administrador" or bool({"configurar", "usuarios"} & permisos_de_rol(s, empresa_id, rol))


# 4.7: Recursos humanos (salarios, cuentas IBAN, embargos e incapacidades) solo con la verificación en dos pasos activa. El rol puede
# traer el permiso (Avanzado o un rol propio), pero sin MFA no queda en los permisos efectivos de la sesión (_permisos_sesion: el menú
# no lo muestra) ni de cada petición (contexto(): 403 con MENSAJE_RRHH_MFA). No se exige al entrar: el resto del sistema sigue igual.
# El Administrador y el administrador del sistema ya la tienen obligatoria (mfa_obligatorio). Los tokens de API no llevan rrhh.
MENSAJE_RRHH_MFA = "Para ver Recursos humanos active la verificación en dos pasos en Mi perfil"


def rrhh_con_mfa(u, rol: str | None, s: "Session | None" = None, empresa_id: int | None = None) -> bool:
    """(4.7) Si el permiso rrhh del rol vale para este usuario: Administrador o administrador del sistema (que ya la tienen
    obligatoria al entrar), o con la verificación cubierta en la empresa `empresa_id` (mfa_cubierto: activa, o su renuncia vigente
    si esa empresa no exige la verificación sin excepción)."""
    if getattr(u, "es_superadmin", False) or rol == "Administrador":
        return True
    return mfa_cubierto(s, u, empresa_id)


def quitar_rrhh_sin_mfa(permisos, u, rol: str | None, s: "Session | None" = None, empresa_id: int | None = None) -> tuple[set, bool]:
    """(4.7) Permisos efectivos sin rrhh cuando el usuario no tiene la verificación en dos pasos (ni una renuncia que valga en la
    empresa), y si se le quitó."""
    permisos = set(permisos or ())
    if "rrhh" in permisos and not _rrhh_cubierto(u, rol, s, empresa_id):         # 4.25: en el programa, para quien viene de la nube, lo que dijo la web
        return permisos - {"rrhh"}, True
    return permisos, False


# ----------------------------------------------------------------------------- modelos (base central)
class Usuario(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    correo: str = Field(index=True, unique=True)
    nombre: str
    password_hash: str
    pin_hash: Optional[str] = None               # etapa 1: PIN de caja (4 a 6 números) para entrar en FISITAAP Local
    de_nube: bool = False                        # etapa 1: en una instalación, usuario que manda la nube (su contraseña y PIN se cambian en la web)
    es_superadmin: bool = False
    admin_principal: bool = False                # 3.80: super administrador (agrega, quita y limita a los demás administradores del sistema)
    empresas_ocultas: str = "[]"                 # 3.80: JSON con ids de empresas que este administrador del sistema NO ve (las demás y las nuevas sí)
    bloqueado: bool = False
    debe_cambiar_password: bool = False
    terminos_version: Optional[str] = None       # versión de los términos del servicio aceptada (Ley 10946: consentimiento para la factura del servicio)
    terminos_fecha: Optional[datetime] = None
    consiente_factura: bool = False              # acepta recibir las facturas del servicio por medios electrónicos
    paleta: Optional[str] = None                 # colores de la interfaz elegidos por el usuario (None = aún no eligió: se le pregunta)
    mfa_secret: Optional[str] = None
    mfa_activo: bool = False
    mfa_pendiente: Optional[str] = None
    mfa_respaldo: Optional[str] = None           # JSON con hashes de los códigos de respaldo no usados
    intentos_fallidos: int = 0
    mfa_fallidos: int = 0                        # códigos MFA incorrectos seguidos (5 → bloqueo temporal, R44)
    mfa_ultimo: Optional[str] = None             # último código TOTP aceptado: no se admite dos veces
    mfa_renuncia_version: Optional[str] = None   # 4.7: versión del descargo aceptado para no usar la verificación (RENUNCIA_MFA_VERSION)
    mfa_renuncia_fecha: Optional[datetime] = None
    mfa_renuncia_ip: Optional[str] = None        # constancia: desde dónde y con qué navegador se aceptó
    mfa_renuncia_agente: Optional[str] = None
    bloqueado_hasta: Optional[datetime] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ultimo_acceso: Optional[datetime] = None
    # 4.25 (programa local, usuario de la nube): lo que dijo la web en la última ficha o bajada. En la web no se usan.
    mfa_nube: Optional[str] = None               # huella de los dos pasos vigentes en la web (vacío = no los usa; nunca el secreto)
    mfa_entrar_nube: bool = False                # la web le pide código para entrar (los usa, o su rol se los exige y no los tiene)
    temporal_nube: bool = False                  # contraseña temporal sin cambiar en la web: aquí no entra
    nube_validado: Optional[datetime] = None     # último ingreso confirmado en línea en esta computadora
    pin_fallos: int = 0                          # 4.25 (programa local): PIN de caja malos seguidos desde cualquier conexión (PIN_MAX_FALLOS lo apagan aquí hasta entrar con contraseña)
    huella_password: Optional[str] = None        # 4.25 (9b, D-Q, programa local): HMAC con la llave local del hash real que la bajada cambió por el inservible (nunca el hash)
    ultima_empresa_id: Optional[int] = None      # 4.35: empresa de la última membresía PROPIA (no traída) que se le quitó: solo esa la trata como nueva si queda sin empresas


class UsuarioEmpresa(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    usuario_id: int = Field(index=True)
    empresa_id: int = Field(index=True)
    rol: str = "Administrador"
    sucursal_id: Optional[int] = None            # 3.66: amarrado a una sucursal (vacío = todas)
    modulos_ocultos: Optional[str] = None        # 3.70: JSON con los módulos apagados solo para este usuario en esta empresa
    # 4.25 (programa local, usuario de la nube): lo que dijo la web en la última ficha de ESTA empresa (la escribe sinc._aplicar_usuario). En la web no se usan.
    mfa_rrhh_nube: bool = False                  # la regla de dos pasos de Recursos humanos queda cubierta en esta empresa (la web la calcula por empresa)
    hash_nube: bool = False                      # la web le manda a la instalación de esta empresa el hash real de la persona (ya entró en línea por ella)
    cuenta_traida: bool = False                  # 4.35: la cuenta ya existía y se agregó con su contraseña de siempre: esta empresa no se la restablece ni la reactiva


def ocultos_usuario(m) -> list:
    """Módulos apagados para un usuario en una empresa (su fila UsuarioEmpresa), o [] (3.70)."""
    try:
        v = json.loads(getattr(m, "modulos_ocultos", None) or "[]") if m is not None else []
    except ValueError:
        v = []
    return sorted(x for x in v if isinstance(x, str))


# 3.70: contraseña temporal fácil de escribir y de recordar: dos palabras y cuatro dígitos (Tucan-Playa-4821). Cumple la política
# (12+ caracteres, no común, no derivada del correo) y se debe cambiar al entrar. Sin tildes ni eñes para que se teclee igual en todo lado.
PALABRAS_CLAVE = ("Tucan", "Volcan", "Playa", "Cafe", "Monte", "Selva", "Nube", "Perla", "Coral", "Arena", "Brisa", "Palma", "Cedro", "Ambar", "Norte",
                  "Lago", "Isla", "Valle", "Cielo", "Flor", "Mango", "Coco", "Lluvia", "Luna", "Pino", "Roble", "Ceiba", "Garza", "Colibri", "Mono",
                  "Iguana", "Rana", "Puma", "Jaguar", "Delfin", "Tortuga", "Cacao", "Trigo", "Miel", "Plata", "Cobre", "Bronce", "Verde", "Azul",
                  "Lila", "Limon", "Papaya", "Guayaba", "Nance", "Yuca", "Frijol", "Sol", "Mar", "Rio", "Oro")


def clave_facil() -> str:
    a = secrets.choice(PALABRAS_CLAVE)
    b = secrets.choice([p for p in PALABRAS_CLAVE if p != a])
    return f"{a}-{b}-{secrets.randbelow(9000) + 1000}"


class Sesion(SQLModel, table=True):
    """Sesión viva en el servidor: permite revocarla y aplicar expiración por inactividad."""
    id: Optional[int] = Field(default=None, primary_key=True)
    sid: str = Field(index=True, unique=True)
    usuario_id: int = Field(index=True)
    creada: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ultimo_uso: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ip: Optional[str] = None
    agente: Optional[str] = None
    revocada: bool = False
    sin_nube: bool = False                       # 4.25 (programa local): se abrió con lo guardado en la computadora, sin confirmar con la web
    suplantada_por: Optional[int] = None         # 4.35: administrador del sistema que abrió esta sesión «entrando como» la persona (soporte); vacío = sesión propia
    suplantada_vuelve: Optional[int] = None      # 4.35: id de la sesión del administrador a la que vuelve con «Volver a mi cuenta» (nunca su token)


class RolEmpresa(SQLModel, table=True):
    """Rol personalizado de una empresa: nombre + permisos (JSON). Los cuatro roles base no se guardan aquí."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str
    descripcion: Optional[str] = None
    permisos: str = "[]"
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class TokenApi(SQLModel, table=True):
    """Token de acceso para integraciones de terceros (Configuración › Integraciones › API). Se guarda solo su hash; el token
    completo se muestra una única vez al crearlo. Actúa con los permisos elegidos (nunca usuarios ni configurar) en nombre
    del usuario que lo creó, sobre una sola empresa."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    usuario_id: int                         # 0 = token de la empresa (instalaciones locales, 3.15): no depende de ninguna persona
    nombre: str
    prefijo: str = Field(index=True)        # primeros caracteres visibles (fcr_ab12cd34) para identificarlo
    hash: str
    permisos: str = "[]"                    # JSON
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ultimo_uso: Optional[datetime] = None
    revocado: bool = False


class IngresoPrograma(SQLModel, table=True):
    """4.25 (nube): personas que ya entraron EN LÍNEA (validadas por la web con /api/sinc/ingreso) en cada instalación del programa
    local, identificada por el token de su vinculación. A esa instalación solo le bajan el hash de la contraseña y del PIN de estas
    personas (a las demás, sinc.HASH_INSERVIBLE). Una fila por instalación y persona: no crece más que usuarios × instalaciones, y
    las filas de una instalación se borran al revocarla."""
    __table_args__ = (Index("ux_ingresoprograma_token_usuario", "token_id", "usuario_id", unique=True),)
    id: Optional[int] = Field(default=None, primary_key=True)
    token_id: int = Field(index=True)
    usuario_id: int
    fecha: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PagoPlan(SQLModel, table=True):
    """Pagos del plan registrados a mano por el administrador del sistema (3.17): cada uno extiende el vencimiento de la empresa.
    Cuando haya pasarela de pago, sus cobros se registrarán aquí también."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    fecha: str
    monto: float = 0
    moneda: str = "CRC"
    medio: str = ""                         # SINPE | transferencia | tarjeta | efectivo | otro
    referencia: Optional[str] = None
    meses: int = 1
    vence_anterior: Optional[str] = None
    vence_nuevo: Optional[str] = None
    nota: Optional[str] = None
    usuario: Optional[str] = None
    factura_empresa_id: Optional[int] = None      # 3.65: comprobante que emitió la empresa facturadora por este pago
    factura_documento_id: Optional[int] = None
    factura_consecutivo: Optional[str] = None
    factura_error: Optional[str] = None           # por qué no se pudo facturar (se reintenta desde Administración)
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


central(Usuario, UsuarioEmpresa, Sesion, RolEmpresa, TokenApi, IntentoIp, PagoPlan, IngresoPrograma)

TERMINOS_VERSION = "2026-10-15"          # versión de app/static/terminos.html; al cambiarla todos vuelven a aceptar
RECUPERACION_SEGUNDOS = 30 * 60


def terminos_pendientes(u: "Usuario") -> bool:
    return (not u.es_superadmin) and (u.terminos_version or "") != TERMINOS_VERSION


def _cfg_smtp_plataforma(s: Session, u: "Usuario"):
    """Correo con que la plataforma escribe a un usuario (recuperación de contraseña): el SMTP del sistema (variables
    FE_SMTP_HOST, FE_SMTP_PUERTO, FE_SMTP_USUARIO, FE_SMTP_PASSWORD, FE_SMTP_REMITENTE, FE_SMTP_SEGURIDAD) o, si no está
    definido, el de alguna empresa del usuario."""
    from . import correo
    host = (os.getenv("FE_SMTP_HOST") or "").strip()
    if host:
        seg = (os.getenv("FE_SMTP_SEGURIDAD") or "ssl").strip().lower()
        try:
            puerto = int(os.getenv("FE_SMTP_PUERTO") or (465 if seg == "ssl" else 587))
        except ValueError:
            puerto = 465
        return correo.ConfigSMTP(host, puerto, os.getenv("FE_SMTP_USUARIO") or None, os.getenv("FE_SMTP_PASSWORD") or None,
                                 (os.getenv("FE_SMTP_REMITENTE") or os.getenv("FE_SMTP_USUARIO") or "").strip(), seguridad=seg, nombre=nombre_sistema())
    if u.es_superadmin:                       # el correo del administrador del sistema nunca sale por el servidor de un cliente
        return None
    membresias = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()
    # solo una empresa donde el usuario sea Administrador (o la única a la que pertenece): su propio correo, no el de otro inquilino
    candidatas = [s.get(Empresa, m.empresa_id) for m in membresias if m.rol == "Administrador" or len(membresias) == 1]
    e = next((e for e in candidatas if e and e.smtp_host and e.smtp_remitente), None)
    if not e:
        return None
    try:
        return correo.ConfigSMTP(e.smtp_host, e.smtp_puerto or (465 if (e.smtp_seguridad or "ssl") == "ssl" else 587), e.smtp_usuario,
                                 secretos.descifrar(e.clave_cifrada, e.smtp_password), e.smtp_remitente, seguridad=e.smtp_seguridad or "ssl",
                                 nombre=e.smtp_nombre or None)
    except Exception:  # noqa: BLE001
        return None

PERMISOS_API = ("ver", "ver_todo", "facturar", "catalogos", "inventario", "cobros", "gastos", "contabilidad", "reportes", "documentos", "escribir")
LIMITE_API = (600, 300)                     # peticiones por token cada 5 minutos


def _hash_token_api(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _contexto_api(request: Request, token: str, s: Session) -> "Contexto":
    """Petición autenticada con un token de API (Authorization: Bearer fcr_…)."""
    from . import planes
    t = s.exec(select(TokenApi).where(TokenApi.hash == _hash_token_api(token))).first()
    if not t or t.revocado:
        raise HTTPException(401, "Token de API inválido o revocado")
    limitar_ip(request, "api", LIMITE_API[0], LIMITE_API[1], "Demasiadas peticiones con este token; espere unos minutos", f"t{t.id}")
    e = s.get(Empresa, t.empresa_id)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if e.bloqueada:
        raise HTTPException(403, f"El acceso de esta empresa está bloqueado. {e.bloqueo_motivo or ''}")
    if t.usuario_id == TOKEN_EMPRESA:
        # token de la empresa (instalación local): permisos fijos del token, sin depender de ningún usuario; en la auditoría
        # queda el nombre de la instalación
        try:
            permisos = [p for p in json.loads(t.permisos or "[]") if p in PERMISOS_API]
        except ValueError:
            permisos = []
        if "ver" not in permisos:
            permisos.append("ver")
        ahora = datetime.now(timezone.utc)
        if not t.ultimo_uso or (ahora - t.ultimo_uso.replace(tzinfo=timezone.utc)).total_seconds() > 60:
            t.ultimo_uso = ahora; s.add(t); s.commit()
        u = Usuario(id=None, correo=f"instalacion-{t.id}@{e.id}.local", nombre=t.nombre, password_hash="", es_superadmin=False)
        ctx = Contexto(u, e, "API", request, permisos)
        ctx.token_api = t
        return ctx
    u = _usuario_activo(s, t.usuario_id)
    retirada = _cuenta_local_retirada(s, u) if _local_cerrado() and not u.de_nube else False
    if retirada is None:                                                        # 4.25 (6b, R3): no se sabe: no pasa, pero el token no se revoca
        raise HTTPException(503, MENSAJE_CUENTA_NO_SABIDA)
    if retirada is True:                                                        # 4.25 (E-13): token de persona de una cuenta retirada: se revoca
        _revocar_tokens_api(s, u.id)
        raise HTTPException(403, "El token de API es de una cuenta creada solo en esta computadora, que ya no se usa: quedó revocado")
    if u.debe_cambiar_password:
        raise HTTPException(403, "El usuario que creó el token debe cambiar su contraseña antes de que el token vuelva a funcionar")
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == e.id)).first()
    if not (admin_ve_empresa(u, e.id) if u.es_superadmin else m):      # 3.87: también si después se la ocultaron
        raise HTTPException(403, "El usuario que creó el token ya no tiene acceso a esta empresa")
    try:
        permisos = [p for p in json.loads(t.permisos or "[]") if p in PERMISOS_API]
    except ValueError:
        permisos = []
    # un token nunca puede más que quien lo creó HOY: si a esa persona le quitaron permisos, el token los pierde también
    vigentes = permisos_de_rol(s, e.id, m.rol) if m else (set(PERMISOS_API) if u.es_superadmin else set())
    permisos = [p for p in permisos if p in vigentes or p == "ver"]
    if "ver" not in permisos:
        permisos.append("ver")
    ahora = datetime.now(timezone.utc)
    if not t.ultimo_uso or (ahora - t.ultimo_uso.replace(tzinfo=timezone.utc)).total_seconds() > 60:
        t.ultimo_uso = ahora; s.add(t); s.commit()
    ctx = Contexto(u, e, "API", request, permisos)
    ctx.token_api = t
    return ctx


def _revocar_tokens_api(s: Session, usuario_id: int) -> int:
    """Revoca los tokens de API creados por un usuario (al restablecer su contraseña o bloquearlo: respuesta a una cuenta comprometida)."""
    n = 0
    for t in s.exec(select(TokenApi).where(TokenApi.usuario_id == usuario_id, TokenApi.revocado == False)).all():  # noqa: E712
        t.revocado = True; s.add(t); n += 1
    if n:
        s.commit()
    return n


TOKEN_EMPRESA = 0                       # usuario_id de los tokens de la empresa (instalaciones locales)


class TokenApiIn(BaseModel):
    nombre: str
    permisos: list[str] = []


def _token_dict(t: "TokenApi") -> dict:
    return {"id": t.id, "nombre": t.nombre, "prefijo": t.prefijo, "permisos": json.loads(t.permisos or "[]"), "creado": t.creado.isoformat(),
            "ultimo_uso": t.ultimo_uso.isoformat() if t.ultimo_uso else None, "revocado": t.revocado}



# ----------------------------------------------------------------------------- utilidades
def validar_correo(v: str) -> str:
    v = (v or "").strip().lower()
    if not CORREO_RE.match(v):
        raise HTTPException(400, "Correo electrónico inválido")
    return v


def validar_password(pw: str, correo: str | None = None, anterior: str | None = None):
    """Política: 12+ caracteres, no de las más comunes, no derivada del correo, no repetir la anterior."""
    pw = pw or ""
    if len(pw) < MIN_PASSWORD:
        raise HTTPException(400, f"La contraseña debe tener al menos {MIN_PASSWORD} caracteres")
    bajo = pw.lower()
    if bajo in PASSWORDS_COMUNES or len(set(bajo)) < 4:
        raise HTTPException(400, "Esa contraseña es demasiado común o predecible; elija otra")
    if correo:
        local = correo.split("@")[0].lower()
        if len(local) >= 4 and local in bajo:
            raise HTTPException(400, "La contraseña no debe contener su correo o nombre de usuario")
    if anterior is not None and pw == anterior:
        raise HTTPException(400, "La nueva contraseña no puede ser igual a la anterior")


def hash_password(pw: str) -> str:
    sal = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=sal, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${base64.b64encode(sal).decode()}${base64.b64encode(h).decode()}"


def verificar_password(pw: str, almacenado: str) -> bool:
    try:
        _, sal, h = almacenado.split("$")
        calc = hashlib.scrypt(pw.encode(), salt=base64.b64decode(sal), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(h))
    except Exception:
        return False


def _b64(d: bytes) -> str:
    return base64.urlsafe_b64encode(d).rstrip(b"=").decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def firmar(payload: dict, segundos: int) -> str:
    cuerpo = _b64(json.dumps({**payload, "exp": int(time.time()) + segundos}).encode())
    return f"{cuerpo}.{_b64(hmac.new(SECRET, cuerpo.encode(), hashlib.sha256).digest())}"


def abrir(token: str) -> dict | None:
    try:
        cuerpo, firma = token.split(".")
        if not hmac.compare_digest(_b64(hmac.new(SECRET, cuerpo.encode(), hashlib.sha256).digest()).encode(), firma.encode("utf-8", "replace")):
            return None
        datos = json.loads(_unb64(cuerpo))
        return datos if datos.get("exp", 0) > time.time() else None
    except Exception:
        return None


def nuevo_secreto() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def codigo_totp(secreto: str, t: float | None = None, paso: int = 30, digitos: int = 6) -> str:
    clave = base64.b32decode(secreto + "=" * (-len(secreto) % 8))
    contador = int((t if t is not None else time.time()) // paso)
    h = hmac.new(clave, struct.pack(">Q", contador), hashlib.sha1).digest()
    off = h[-1] & 0x0F
    return str((struct.unpack(">I", h[off:off + 4])[0] & 0x7FFFFFFF) % (10 ** digitos)).zfill(digitos)


PREFIJO_MFA = "mfa:"


def _cifrar_mfa(secreto: str | None) -> str | None:
    """El secreto TOTP se guarda cifrado con la clave maestra del servidor (R288)."""
    if not secreto or secreto.startswith(PREFIJO_MFA):
        return secreto
    from .secretos import _fernet_maestra
    return PREFIJO_MFA + _fernet_maestra().encrypt(secreto.encode()).decode()


def _descifrar_mfa(valor: str | None) -> str | None:
    if not valor or not valor.startswith(PREFIJO_MFA):
        return valor                                        # secretos anteriores en texto plano siguen funcionando
    from cryptography.fernet import InvalidToken
    from .secretos import _fernet_maestra
    try:
        return _fernet_maestra().decrypt(valor[len(PREFIJO_MFA):].encode()).decode()
    except (InvalidToken, ValueError):
        return None                                         # clave maestra distinta: el TOTP no vale, quedan los códigos de respaldo


def verificar_totp(secreto: str, codigo: str) -> bool:
    codigo = re.sub(r"[^0-9]", "", codigo or "")            # tildes o símbolos daban error 500 en compare_digest (R296)
    if not secreto or len(codigo) != 6:
        return False
    secreto = _descifrar_mfa(secreto)
    if not secreto:
        return False
    ahora = time.time()
    return any(hmac.compare_digest(codigo_totp(secreto, ahora + d), codigo) for d in (-30, 0, 30))


def _normalizar_respaldo(codigo: str) -> bytes:
    return re.sub(r"[^A-Za-z0-9]", "", codigo or "").upper().encode()


def _hash_respaldo(codigo: str, sal: bytes | None = None) -> str:
    """scrypt con sal por código ('s:<sal>:<hash>'); los hashes viejos (sha256 sin sal) se siguen aceptando (R288)."""
    sal = sal or secrets.token_bytes(8)
    h = hashlib.scrypt(_normalizar_respaldo(codigo), salt=sal, n=2 ** 14, r=8, p=1, dklen=32)
    return f"s:{sal.hex()}:{h.hex()}"


def _coincide_respaldo(codigo: str, guardado: str) -> bool:
    if guardado.startswith("s:"):
        try:
            _, sal, _ = guardado.split(":")
            return hmac.compare_digest(_hash_respaldo(codigo, bytes.fromhex(sal)), guardado)
        except ValueError:
            return False
    return hmac.compare_digest(hashlib.sha256(_normalizar_respaldo(codigo)).hexdigest(), guardado)


def generar_respaldo(u: "Usuario", n: int = 8) -> list[str]:
    """Códigos de respaldo de un solo uso (se muestran una única vez; solo se guarda su hash)."""
    abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    codigos = ["".join(secrets.choice(abc) for _ in range(4)) + "-" + "".join(secrets.choice(abc) for _ in range(4)) for _ in range(n)]
    u.mfa_respaldo = json.dumps([_hash_respaldo(c) for c in codigos])
    return codigos


def usar_respaldo(u: "Usuario", codigo: str) -> bool:
    if not u.mfa_respaldo or not codigo or len(_normalizar_respaldo(codigo)) != 8:
        return False
    hashes = json.loads(u.mfa_respaldo)
    usado = next((h for h in hashes if _coincide_respaldo(codigo, h)), None)
    if usado is None:
        return False
    hashes.remove(usado)
    u.mfa_respaldo = json.dumps(hashes)
    return True


def mfa_obligatorio(s: Session, u: "Usuario") -> bool:
    """El administrador del sistema, los administradores de empresa y los roles personalizados con configuración o usuarios deben tener MFA."""
    if u.es_superadmin:
        return True
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all():
        if rol_exige_mfa(s, m.empresa_id, m.rol):
            return True
    return False


# ----------------------------------------------------------------------------- renuncia a la verificación en dos pasos (4.7)
# Quien tiene la verificación exigida (Administrador, roles con configurar o usuarios, o Recursos humanos) puede declinarla aceptando el
# descargo de app/static/renuncia-mfa.html (versión RENUNCIA_MFA_VERSION) con las dos casillas, su contraseña y la palabra ACEPTO. La
# renuncia VIGENTE hace las veces de la verificación (mfa_cubierto) en cada petición (_exigir_mfa), en la sesión y en Recursos humanos.
# Nunca para el administrador del sistema. No vale si cambió la versión del texto, si el interruptor del sistema está apagado
# (data/seguridad.json, «mfa_renuncia») ni, en una empresa con la política «sin excepción» (Empresa.mfa_sin_excepcion), para sus roles
# que exigen la verificación (que se pide al entrar, para todo el sistema) ni para su Recursos humanos.
RENUNCIA_MFA_VERSION = "2026-11-07"      # versión de app/static/renuncia-mfa.html; al cambiarla, cada renuncia se debe aceptar de nuevo
RENUNCIA_MFA_URL = "/renuncia-mfa.html"
RENUNCIA_MFA_PALABRA = "ACEPTO"
_RENUNCIA_HTML = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "renuncia-mfa.html")


def renuncia_mfa_permitida() -> bool:
    """Interruptor del administrador del sistema «Permitir la renuncia a la verificación en dos pasos» (encendido por defecto: sin el
    archivo o sin la clave). Se lee del archivo en cada consulta: apagarlo vale de inmediato en todos los procesos. Un archivo dañado o
    ilegible, o un valor que no se entiende, cuenta como apagado (la verificación se vuelve a exigir)."""
    d = None
    for intento in range(3):
        try:
            d = json.loads(_SEGURIDAD.read_text(encoding="utf-8"))
            break
        except FileNotFoundError:
            return True
        except PermissionError:                  # Windows: seguridad_guardar lo está reemplazando en ese instante
            if intento == 2:
                return False
            time.sleep(0.02)
        except (OSError, ValueError):
            return False
    if not isinstance(d, dict):
        return False
    v = d.get("mfa_renuncia")
    if v is None:
        return True
    return isinstance(v, dict) and v.get("permitida", True) is True   # revisión: «false», 0 o cualquier valor raro = apagado


def renuncia_mfa_vigente(u, interruptor: bool | None = None) -> bool:
    """La renuncia del usuario está aceptada en la versión vigente del texto y el interruptor del sistema está encendido (se lee si no
    viene en `interruptor`); nunca la del administrador del sistema. No mira la política de cada empresa (renuncia_mfa_cubre)."""
    if getattr(u, "es_superadmin", False) or getattr(u, "mfa_renuncia_version", None) != RENUNCIA_MFA_VERSION:
        return False
    return renuncia_mfa_permitida() if interruptor is None else bool(interruptor)


def empresa_sin_excepcion(s: Session, empresa_id) -> bool:
    """Política de la empresa «Exigir la verificación en dos pasos sin excepción» (Empresa.mfa_sin_excepcion)."""
    e = s.get(Empresa, empresa_id) if empresa_id else None
    return bool(e is not None and getattr(e, "mfa_sin_excepcion", False))


def _bloqueos_sin_excepcion(s: Session, u) -> list:
    """Empresas con la política «sin excepción» donde el rol del usuario exige la verificación al entrar: ahí su renuncia no vale y,
    como esa verificación se pide para todo el sistema, tampoco lo libera en las demás."""
    if getattr(u, "id", None) is None:
        return []
    return [m.empresa_id for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()
            if empresa_sin_excepcion(s, m.empresa_id) and rol_exige_mfa(s, m.empresa_id, m.rol)]


def _renuncia_vale(s: Session, u, empresa_id: int | None) -> bool:
    """Sin la política «sin excepción» en `empresa_id` (si viene) ni en ninguna empresa donde su rol exige la verificación al entrar
    (si ahí no vale, el usuario no pasa de la pantalla de activarla en ninguna empresa: tampoco se le abre Recursos humanos)."""
    if empresa_id is not None and empresa_sin_excepcion(s, empresa_id):
        return False
    return not _bloqueos_sin_excepcion(s, u)


def renuncia_mfa_cubre(s: "Session | None", u, empresa_id: int | None = None) -> bool:
    """La renuncia hace las veces de la verificación: vigente (renuncia_mfa_vigente) y sin la política «sin excepción» que la anule
    (_renuncia_vale): en `empresa_id` (Recursos humanos de esa empresa) y en las empresas donde su rol la exige al entrar."""
    if not renuncia_mfa_vigente(u):
        return False
    if s is None:
        with Session(engine) as s2:
            return _renuncia_vale(s2, u, empresa_id)
    return _renuncia_vale(s, u, empresa_id)


def mfa_cubierto(s: "Session | None", u, empresa_id: int | None = None) -> bool:
    """(4.7) La verificación en dos pasos está cubierta: activa, o con una renuncia que vale (renuncia_mfa_cubre). Es la única regla
    de las peticiones (_exigir_mfa), de la sesión y de Recursos humanos (rrhh_con_mfa)."""
    return bool(getattr(u, "mfa_activo", False)) or renuncia_mfa_cubre(s, u, empresa_id)


def mfa_exigida(s: Session, u: "Usuario") -> bool:
    """El rol exige la verificación (mfa_obligatorio) y no hay una renuncia que valga: apagada, se le pide activarla antes de continuar;
    activa, no la puede desactivar. Es el «mfa_obligatorio» de la sesión."""
    return mfa_obligatorio(s, u) and not renuncia_mfa_cubre(s, u)


def _borrar_renuncia(u) -> None:
    u.mfa_renuncia_version = u.mfa_renuncia_fecha = u.mfa_renuncia_ip = u.mfa_renuncia_agente = None


def _fecha_iso(v) -> str | None:
    """Fecha de la renuncia en ISO con zona (UTC): la base la devuelve sin zona y el navegador la leería como hora local."""
    if not v:
        return None
    return (v if v.tzinfo else v.replace(tzinfo=timezone.utc)).isoformat()


def _renuncia_sesion(u) -> dict:
    """(4.7) La renuncia en la respuesta de la sesión (usuario.mfa_renuncia)."""
    version, fecha = getattr(u, "mfa_renuncia_version", None), getattr(u, "mfa_renuncia_fecha", None)
    return {"vigente": renuncia_mfa_vigente(u), "fecha": _fecha_iso(fecha), "version": version,
            "version_actual": RENUNCIA_MFA_VERSION, "desactualizada": bool(version) and version != RENUNCIA_MFA_VERSION}


def _renuncia_fila(s: Session, u, empresa_id: int | None = None, interruptor: bool | None = None) -> dict | None:
    """(4.7) Marca «Sin verificación: renuncia aceptada el …» de las listas de usuarios (empresa y consola); None si no la aceptó.
    vale_aqui: la renuncia cubre en esa empresa (vigente y sin la política «sin excepción»)."""
    version = getattr(u, "mfa_renuncia_version", None)
    if not version or getattr(u, "es_superadmin", False):
        return None
    fecha = getattr(u, "mfa_renuncia_fecha", None)
    vigente = renuncia_mfa_vigente(u, interruptor)
    return {"fecha": _fecha_iso(fecha), "version": version, "vigente": vigente,
            "desactualizada": version != RENUNCIA_MFA_VERSION,
            "vale_aqui": vigente and _renuncia_vale(s, u, empresa_id)}   # revisión: la misma regla que renuncia_mfa_cubre


def otpauth_url(secreto: str, correo: str, emisor: str | None = None) -> str:
    from urllib.parse import quote
    emisor = emisor or nombre_sistema()
    return f"otpauth://totp/{quote(emisor)}:{quote(correo)}?secret={secreto}&issuer={quote(emisor)}&digits=6&period=30"


def qr_png_base64(texto: str) -> str:
    import qrcode
    buf = io.BytesIO()
    qrcode.make(texto).save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _ip(request: Request | None) -> str | None:
    """IP del cliente. El PRIMER valor de X-Forwarded-For lo escribe el propio cliente (se falsificaba para evadir el límite de
    intentos); el proxy de confianza (Apache/Passenger, Cloudflare) agrega el suyo al FINAL, así que se toma el último. Detrás de
    Cloudflare (FE_CLOUDFLARE=1) vale CF-Connecting-IP."""
    if request is None:
        return None
    directa = request.client.host if request.client else None
    # Solo con un proxy de confianza declarado (mod_proxy, Cloudflare: FE_PROXY_CONFIABLE=1) se leen las cabeceras; sin él
    # (Passenger integrado en Apache, uvicorn directo) el cliente podría escribirlas y vale la IP del socket.
    if os.environ.get("FE_PROXY_CONFIABLE") == "1" or os.environ.get("FE_CLOUDFLARE") == "1":
        if request.headers.get("cf-connecting-ip"):
            return request.headers["cf-connecting-ip"].strip()
        xff = [x.strip() for x in request.headers.get("x-forwarded-for", "").split(",") if x.strip()]
        if xff:
            return xff[-1]
    return directa


def _soporte_de(usuario=None, request=None) -> str | None:
    """4.35: correo del administrador del sistema cuando la petición viene de una sesión de soporte («Entrar como» desde la consola), o
    None. Lo marca _autenticar en la petición (request.state) y en el usuario de esa sesión."""
    for obj in (request, usuario):
        try:
            v = getattr(obj.state if obj is request else obj, "fe_soporte", None) if obj is not None else None
        except Exception:  # noqa: BLE001  una petición de prueba sin state
            v = None
        if isinstance(v, str) and v:                 # solo el texto que puso _marcar_soporte (no lo que devuelva un objeto de prueba)
            return v
    return None


def auditar(s: Session, accion: str, detalle: str | None = None, usuario: "Usuario | None" = None, empresa_id: int | None = None,
            request: Request | None = None, correo: str | None = None):
    soporte = _soporte_de(usuario, request)          # 4.35: lo hecho al entrar como otro usuario deja constancia de quién lo hizo
    if soporte and soporte not in (detalle or ""):
        detalle = (f"{detalle} · " if detalle else "") + f"por soporte {soporte}"
    s.add(Auditoria(accion=accion, detalle=detalle, usuario_id=usuario.id if usuario else None,
                    correo=usuario.correo if usuario else correo, empresa_id=empresa_id, ip=_ip(request)))
    s.commit()


# ----------------------------------------------------------------------------- contexto (dependencias)
class Contexto:
    def __init__(self, usuario: "Usuario", empresa: Empresa, rol: str, request: Request | None = None, permisos: set[str] | None = None):
        self.usuario, self.empresa, self.rol, self.request = usuario, empresa, rol, request
        self.permisos = set(permisos) if permisos is not None else {p for p, rs in PERMISOS.items() if rol in rs}

    token_api = None                      # TokenApi cuando la petición viene de una integración (rol "API")
    rrhh_sin_mfa = False                  # 4.7: el rol trae Recursos humanos pero el usuario no tiene la verificación en dos pasos
    sucursal = None                       # 3.66: sucursal activa de la petición (None = todas / la principal al emitir)
    sucursal_fija = False                 # el usuario está amarrado a su sucursal
    soporte = None                        # 4.35: correo del administrador del sistema que entró como este usuario (sesión de soporte)
    suplantada_por = None                 # 4.35: su id (vacío = la persona misma)

    def puede(self, permiso: str) -> bool:
        if self.token_api is not None:        # un token solo puede lo que dice el token, aunque lo haya creado el superadministrador
            return permiso in self.permisos
        if getattr(self.usuario, "es_superadmin", False):
            # 3.87: dentro de una empresa el administrador del sistema usa lo que el plan incluye, como en la interfaz: todo, menos los
            # permisos de los módulos que el plan no trae o están apagados (contexto() ya se los quitó con planes.filtrar_permisos).
            # Antes rrhh, pos, reportes o tike le servían por API aunque el Administrador de esa empresa recibiera 403.
            return permiso in self.permisos or permiso not in PERMISOS_MODULO
        return permiso in self.permisos

    def exigir(self, permiso: str):
        if not self.puede(permiso):
            if permiso == "rrhh" and self.rrhh_sin_mfa:          # 4.7: lo que falta es la verificación en dos pasos, no el rol
                raise HTTPException(403, {"codigo": "rrhh_mfa", "mensaje": MENSAJE_RRHH_MFA})
            if getattr(self.usuario, "es_superadmin", False) and self.token_api is None and self.empresa is not None:
                from . import planes
                planes.exigir_modulo(self.empresa, permiso)      # 3.87: lo que le falta es el módulo, no el rol: 403 sin_modulo
            raise HTTPException(403, f"Su rol ({self.rol}) no tiene permiso para esta acción")

    def sesion(self) -> Session:
        return Session(engine_empresa(self.empresa.id))


def _datos_token(authorization: str | None, cookie: str | None, request: Request, s: Session) -> dict:
    """Valida el token (header o cookie), su sesión en el servidor y la inactividad. La cookie solo vale para GET."""
    token = None
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    elif cookie and request.method == "GET":
        token = cookie
    if not token:
        raise HTTPException(401, "Inicie sesión")
    datos = abrir(token)
    if not datos or datos.get("tipo") != "sesion":
        raise HTTPException(401, "Sesión inválida o expirada")
    ses = s.exec(select(Sesion).where(Sesion.sid == datos.get("sid", ""))).first()
    if not ses or ses.revocada or ses.usuario_id != datos["uid"]:
        raise HTTPException(401, "La sesión fue cerrada; inicie sesión de nuevo")
    ahora = datetime.now(timezone.utc)
    if (ahora - ses.creada.replace(tzinfo=timezone.utc)).total_seconds() > DURACION_SESION:      # máximo absoluto (R125)
        ses.revocada = True; s.add(ses); s.commit()
        raise HTTPException(401, "Su sesión alcanzó el máximo de 12 horas; inicie sesión de nuevo")
    if getattr(ses, "suplantada_por", None) and (ahora - ses.creada.replace(tzinfo=timezone.utc)).total_seconds() > DURACION_SUPLANTACION:
        ses.revocada = True; s.add(ses); s.commit()                                              # 4.35: «Entrar como» dura 1 hora
        raise HTTPException(401, MENSAJE_SOPORTE_VENCIDO)
    if (ahora - ses.ultimo_uso.replace(tzinfo=timezone.utc)).total_seconds() > INACTIVIDAD:
        ses.revocada = True; s.add(ses); s.commit()
        raise HTTPException(401, "Su sesión se cerró por inactividad; inicie sesión de nuevo")
    if (ahora - ses.ultimo_uso.replace(tzinfo=timezone.utc)).total_seconds() > 60:
        ses.ultimo_uso = ahora; s.add(ses); s.commit()
    datos["_sesion"] = ses
    try:
        request.state.fe_sesion_id = ses.id          # 4.35: la sesión de quien llama («Entrar como» guarda a cuál vuelve el administrador)
    except Exception:  # noqa: BLE001
        pass
    return datos


def _usuario_activo(s: Session, uid: int) -> "Usuario":
    u = s.get(Usuario, uid)
    if not u:
        raise HTTPException(401, "Usuario no disponible")
    if u.bloqueado:
        raise HTTPException(403, "Su cuenta está bloqueada. Contacte al administrador del sistema.")
    return u


def _exigir_mfa(s: Session, u: "Usuario"):
    # 4.7: una renuncia vigente que valga cuenta como la verificación (mfa_cubierto). Se revisa en cada petición: apagar el interruptor
    # del sistema o encender la política «sin excepción» de la empresa la exige de nuevo de inmediato.
    if _nube_manda(u):                             # 4.25: en el programa, quien viene de la nube: lo que dijo la web (aquí no se activa otro)
        if getattr(u, "mfa_entrar_nube", False) and not getattr(u, "mfa_nube", None):
            raise HTTPException(403, MENSAJE_FALTA_MFA_WEB)
        return
    if not u.mfa_activo and mfa_obligatorio(s, u) and not mfa_cubierto(s, u):
        raise HTTPException(403, "Debe activar la verificación en dos pasos antes de continuar (Mi perfil)")


# ----------------------------------------------------------------------------- 4.35: «Entrar como» otro usuario (soporte)
# El administrador del sistema abre desde la consola una sesión NUEVA de una persona en una de sus empresas (admin_entrar_como), con el rol
# de su membresía y por 1 hora como máximo; la sesión guarda quién la abrió (Sesion.suplantada_por) y a qué sesión suya vuelve
# (Sesion.suplantada_vuelve). Mientras dura, la seguridad de la cuenta, administrar a las personas y los roles de la empresa, crear
# credenciales a su nombre, aceptar por ella, cambiar de empresa y la consola no están disponibles (RUTAS_NO_SUPLANTADA), y cada fila de
# auditoría lleva « · por soporte <correo>» (auditar). Solo en la página web.
MENSAJE_SUPLANTADA = "No disponible al entrar como otro usuario"
MENSAJE_SOPORTE_VENCIDO = "La sesión de soporte terminó (dura como máximo 1 hora). Entre de nuevo con su cuenta."
MENSAJE_SOPORTE_CERRADO = "La sesión de soporte se cerró: el administrador del sistema que la abrió ya no tiene acceso o cerró su sesión."
_ESCRIBE = frozenset({"POST", "PUT", "PATCH", "DELETE"})
RUTAS_NO_SUPLANTADA = (                      # (métodos o None = todos, expresión sobre la ruta)
    (None, re.compile(r"/api/auth/(password|pin|salir-todas|empresa)$")),                   # contraseña, PIN, cerrar todas, cambiar de empresa
    (None, re.compile(r"/api/auth/mfa/(activar|confirmar|respaldo|desactivar)$")),          # dos pasos y sus códigos de recuperación
    (_ESCRIBE, re.compile(r"/api/auth/(mfa/renuncia|mfa/politica|terminos|paleta)$")),      # renuncia, política, aceptar por la persona
    (_ESCRIBE, re.compile(r"/api/auth/(usuarios|roles)(/.*)?$")),                            # personas (también contadores) y roles
    (frozenset({"POST"}), re.compile(r"/api/auth/tokens-api$")),                              # credenciales de API a su nombre
    (None, re.compile(r"/api/admin(/.*)?$")),                                                 # la consola (y «Entrar como» otra vez)
    # 4.35: conectar computadoras y contestar sus avisos de seguridad (E-6: el soporte no las aprueba; quedaría a nombre de la persona)
    (None, re.compile(r"/api/sinc/conexion/(consultar|aprobar|seguimiento|detener)$")),
    (_ESCRIBE, re.compile(r"/api/sinc/conexion/avisos/[^/]+$")),
)


def ruta_no_suplantada(metodo: str, ruta: str) -> bool:
    m = (metodo or "").upper()
    return any((metodos is None or m in metodos) and patron.search(ruta or "") for metodos, patron in RUTAS_NO_SUPLANTADA)


def _marcar_soporte(s: Session, request: Request, u: "Usuario", ses: "Sesion") -> None:
    """4.35: la sesión de la petición es de soporte. Si el administrador que la abrió ya no lo es, está bloqueado o cerró la sesión a la que
    volvería, esta se cierra (401). Si no, marca la petición y al usuario (auditar, Contexto.soporte) y rechaza lo que no se hace como otro."""
    a = s.get(Usuario, ses.suplantada_por)
    propia = s.get(Sesion, ses.suplantada_vuelve) if ses.suplantada_vuelve else None
    if a is None or not a.es_superadmin or a.bloqueado or propia is None or propia.revocada or propia.usuario_id != a.id:
        ses.revocada = True; s.add(ses); s.commit()
        raise HTTPException(401, MENSAJE_SOPORTE_CERRADO)
    try:
        request.state.fe_soporte = a.correo
    except Exception:  # noqa: BLE001
        pass
    object.__setattr__(u, "fe_soporte", a.correo)        # no es columna: solo vive en este objeto (la sesión de base de datos de la petición)
    if ruta_no_suplantada(request.method, request.scope.get("path") or request.url.path):
        raise HTTPException(403, MENSAJE_SUPLANTADA)


def _autenticar(request: Request, authorization: str | None, cookie: str | None, s: Session) -> tuple["Usuario", dict]:
    datos = _datos_token(authorization, cookie, request, s)
    u = _usuario_activo(s, datos["uid"])
    if getattr(datos.get("_sesion"), "suplantada_por", None):                   # 4.35: sesión de soporte («Entrar como»)
        _marcar_soporte(s, request, u, datos["_sesion"])
    retirada = _cuenta_local_retirada(s, u) if _local_cerrado() and not u.de_nube else False
    if retirada is None:                                                        # 4.25 (6b, R3): no se sabe: no pasa, pero no se cierra nada
        raise HTTPException(503, MENSAJE_CUENTA_NO_SABIDA)
    if retirada is True:                                                        # 4.25 (E-13): una sesión que quedó abierta de una cuenta retirada
        _revocar_sesiones(s, u.id)
        _revocar_tokens_api(s, u.id)
        raise HTTPException(401, MENSAJE_CUENTA_LOCAL.format(web=_web_programa()))
    return u, datos


def solo_usuario(request: Request, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None),
                 s: Session = Depends(get_session)) -> "Usuario":
    return _autenticar(request, authorization, facturacr_token, s)[0]


def contexto(request: Request, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None),
             s: Session = Depends(get_session)) -> Contexto:
    """Usuario autenticado + empresa activa (y su rol). Todas las rutas de negocio dependen de esto."""
    if authorization and authorization.lower().startswith("bearer fcr_"):          # integraciones: token de API de la empresa
        return _contexto_api(request, authorization.split(" ", 1)[1].strip(), s)
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    _exigir_mfa(s, u)
    if u.debe_cambiar_password:                    # la contraseña temporal del administrador se cambia antes de cualquier otra cosa (R123)
        raise HTTPException(403, {"codigo": "cambiar_password", "mensaje": "Debe cambiar la contraseña temporal antes de continuar"})
    if terminos_pendientes(u):                     # términos del servicio y consentimiento (Ley 10946) antes de usar el sistema
        raise HTTPException(403, {"codigo": "aceptar_terminos", "mensaje": "Debe aceptar los términos del servicio antes de continuar"})
    eid = datos.get("eid")
    if not eid:
        raise HTTPException(409, "Seleccione una empresa")
    # Las pestañas comparten la sesión: si en otra pestaña se cambió de empresa, esta (que todavía muestra la anterior)
    # no puede emitir ni guardar en la empresa nueva sin darse cuenta.
    tab = request.headers.get("x-empresa")
    if tab and tab.isdigit() and int(tab) != int(eid):
        raise HTTPException(409, {"codigo": "empresa_cambiada", "mensaje": "En otra pestaña se cambió de empresa. Recargue esta pestaña antes de continuar."})
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if e.bloqueada and not u.es_superadmin:
        raise HTTPException(403, f"El acceso de esta empresa está bloqueado. {e.bloqueo_motivo or 'Contacte al administrador del sistema.'}")
    if prueba_vencida(e) and not u.es_superadmin:
        raise HTTPException(403, {"codigo": "prueba_vencida", "mensaje": MENSAJE_PRUEBA.format(fecha=_fecha_cr(e.prueba_hasta), correo=correo_ventas())})
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first()
    if not (admin_ve_empresa(u, eid) if u.es_superadmin else m):      # 3.87: oculta para este administrador = sin acceso, aunque sea miembro
        raise HTTPException(403, "No tiene acceso a esta empresa")
    rol = "Administrador" if u.es_superadmin else m.rol      # 3.87: como en la sesión (_respuesta); antes valía el rol de su membresía
    permisos = permisos_de_rol(s, e.id, rol)
    if bloqueo_local is not None:                  # instalación local revocada y bloqueada (3.15): solo el administrador, y solo para revincular
        bloqueo_local(request, e, u, permisos)
    from . import planes
    del_rol = permisos
    permisos = planes.filtrar_permisos(e, permisos, ocultos_usuario(None if u.es_superadmin else m))   # módulos que el plan no incluye (3.16) o apagados (3.70)
    permisos, rrhh_sin_mfa = quitar_rrhh_sin_mfa(permisos, u, rol, s, e.id)   # 4.7: Recursos humanos solo con la verificación en dos pasos (o la renuncia que vale aquí)
    if solo_pos(del_rol) and "pos" not in permisos:
        # 3.87: un rol de solo caja sin el punto de venta (plan sin el extra o módulo apagado para la empresa o para él) quedaba
        # con «ver» y sin los cortes del cajero: leía todas las ventas, los cobros y las reservas con montos. No tiene nada que hacer.
        raise HTTPException(403, {"codigo": "sin_caja", "mensaje": "Su rol solo usa el punto de venta y el punto de venta no está activo para usted en "
                                  "esta empresa: pida al administrador que lo active o que le asigne otro rol"})
    planes.verificar_vigencia(e, request, u.es_superadmin)     # plan vencido: modo lectura
    ctx = Contexto(u, e, rol, request, permisos)
    ctx.rrhh_sin_mfa = rrhh_sin_mfa
    if getattr(datos.get("_sesion"), "suplantada_por", None):     # 4.35: sesión de soporte (_marcar_soporte ya la revisó)
        ctx.soporte, ctx.suplantada_por = _soporte_de(u, request), datos["_sesion"].suplantada_por
    fija = getattr(m, "sucursal_id", None) if m else None
    cab = request.headers.get("x-sucursal")
    if fija or (cab and cab.strip()):                           # 3.66: sucursal activa (solo se consulta cuando hace falta)
        from . import sucursales as _suc
        with Session(engine_empresa(e.id)) as se:
            ctx.sucursal = _suc.resolver(se, e.id, cab, fija)
        ctx.sucursal_fija = bool(fija)
    return ctx


bloqueo_local = None     # gancho de sinc (instalación local): lanza 403 si la empresa está bloqueada en esta computadora
aviso_local = None       # gancho de sinc: dict con el estado de la instalación (revocada/bloqueada) para la franja de la aplicación
# 4.25 (X2, programa local): ganchos que sinc instala con FE_MODO_LOCAL=1. En la web quedan vacíos y nada de esto cambia.
ingreso_nube = None      # login(s, request, response, data): el ingreso de quien viene de la nube (o no existe aquí) lo valida la web; None = camino de siempre
dos_pasos_nube = None    # mfa_verificar(s, request, response, datos, codigo): el segundo paso de ese ingreso, con el token «mfa_nube»
TIPO_MFA_NUBE = "mfa_nube"
MENSAJE_SOLO_WEB_MFA = "La verificación en dos pasos de su cuenta se administra en la página web (fisitaap.com, Mi perfil); se hace allá, no en esta computadora."
MENSAJE_FALTA_MFA_WEB = "Su cuenta necesita la verificación en dos pasos. Actívela en fisitaap.com (Mi perfil) y vuelva a entrar aquí."
PIN_MAX_FALLOS = 10      # 4.25: PIN de caja malos seguidos (desde cualquier conexión) que lo apagan en esta computadora hasta entrar con contraseña
MENSAJE_PIN_APAGADO = ("Su PIN de caja quedó apagado en esta computadora por demasiados intentos. Entre con su correo y su contraseña "
                       "para volver a usarlo.")


def _viene_de_nube(u) -> bool:
    """4.25: en el programa local (ganchos instalados), la persona viene de la nube: su ingreso va por el gancho, su PIN pide antes la
    ficha fresca y su contraseña y su PIN se administran en la web."""
    return ingreso_nube is not None and bool(getattr(u, "de_nube", False))


def _nube_manda(u) -> bool:
    """4.25 (D-N): viene de la nube Y la web 4.25 ya aceptó un ingreso suyo en esta computadora (nube_validado, que anota
    sinc._aceptar_ficha). Solo entonces sus dos pasos los administra la web y vale lo que dijo la web (mfa_entrar_nube y, por empresa,
    mfa_rrhh_nube de su membresía), no los de esta computadora. Mientras la web no haya hablado de ella aquí (computadora conectada a
    otra dirección, sin vinculación o contra una web anterior), sus dos pasos siguen como en la 4.24."""
    return _viene_de_nube(u) and bool(getattr(u, "nube_validado", None))


def _solo_en_web(u) -> None:
    """4.25: activar, confirmar, códigos de respaldo, desactivar y renuncia de los dos pasos: para quien viene de la nube se hace en la web."""
    if _nube_manda(u):
        raise HTTPException(400, MENSAJE_SOLO_WEB_MFA)


def _rrhh_cubierto(u, rol: str | None, s: "Session | None", empresa_id: int | None) -> bool:
    """4.25: rrhh_con_mfa, salvo para quien viene de la nube en el programa: ahí vale lo que calculó la web PARA ESA EMPRESA
    (mfa_rrhh_nube de su membresía: la web lo calcula por empresa, y una computadora puede tener varias vinculadas). Sin empresa, sin
    membresía o si la web no dijo nada de esa empresa: no cubierta."""
    if _nube_manda(u):
        if s is None or empresa_id is None or getattr(u, "id", None) is None:
            return False
        m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == empresa_id)).first()
        return bool(m is not None and m.mfa_rrhh_nube)
    return rrhh_con_mfa(u, rol, s, empresa_id)


# 4.25 (tanda 6, E-13): en el programa local real (FE_MODO_LOCAL=1) las cuentas se crean y se administran en la página web. Las rutas
# que crean o cambian cuentas, membresías, roles o empresas responden 403 «solo_web» (solo_web) y las cuentas creadas en la
# computadora dejan de entrar en cuanto alguna de sus empresas se vinculó (_cuenta_local_retirada). Con FE_LOCAL_ADMIN=1 (soporte)
# todo vuelve a ser como en la 4.24. En la web nada de esto hace nada.
MENSAJE_SOLO_WEB = "Esto se hace en la página web ({web}). Los cambios llegan solos a esta computadora en unos minutos."
MENSAJE_SOLO_WEB_SETUP = "En este programa no se crean cuentas. Conecte la computadora con la cuenta de su empresa."
MENSAJE_SOLO_WEB_RECUPERAR = "La contraseña se recupera en la página web: abra {web} y toque «¿Olvidó su contraseña?»."
MENSAJE_CUENTA_LOCAL = "Esta cuenta se creó solo en esta computadora y ya no se usa. Entre con su correo y su contraseña de {web}."


def _local_cerrado() -> bool:
    """El programa local real sin el modo soporte (FE_LOCAL_ADMIN=1)."""
    return _es_local() and os.environ.get("FE_LOCAL_ADMIN", "") != "1"


def _web_programa() -> str:
    from . import sinc as _sinc
    return _sinc._web()


def solo_web(request: Request) -> None:
    """Dependencia de las rutas que en el programa se hacen en la página web: 403 {codigo: solo_web, mensaje}."""
    if not _local_cerrado():
        return
    ruta = request.url.path if request is not None else ""
    if ruta.endswith("/api/auth/setup"):
        mensaje = MENSAJE_SOLO_WEB_SETUP
    elif ruta.endswith("/api/auth/recuperar") or ruta.endswith("/api/auth/restablecer"):
        mensaje = MENSAJE_SOLO_WEB_RECUPERAR.format(web=_web_programa())
    else:
        mensaje = MENSAJE_SOLO_WEB.format(web=_web_programa())
    raise HTTPException(403, {"codigo": "solo_web", "mensaje": mensaje})


def _cuenta_local_retirada(s: Session, u) -> bool | None:
    """E-13: en el programa real (sin FE_LOCAL_ADMIN=1), una cuenta creada en esta computadora (no viene de la web) ya no entra si es
    miembro de una empresa que alguna vez se vinculó aquí, o si es el administrador del sistema de esta computadora y alguna empresa se
    vinculó alguna vez. «Alguna vez» se lee de la configuración guardada de cada empresa (terminal anotada).
    4.25 (6b, R3): tres respuestas: True (retirada: la terminal anotada se leyó de verdad), False (no) y None (no se sabe: no se pudo leer
    la configuración). Con None la cuenta NO entra, pero no se revoca ni se cierra nada (_exigir_cuenta_local_sabida)."""
    if not _local_cerrado() or u is None or getattr(u, "de_nube", False) or getattr(u, "id", None) is None:
        return False
    from . import sinc as _sinc
    duda = False
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all():
        v = _sinc.vinculada_alguna_vez(m.empresa_id)
        if v is True:
            return True
        duda = duda or v is None
    if u.es_superadmin:
        v = _sinc.hay_vinculada()
        if v is True:
            return True
        duda = duda or v is None
    return None if duda else False


MENSAJE_CUENTA_NO_SABIDA = "No se pudo comprobar su cuenta en esta computadora. Inténtelo de nuevo en un momento."


def _exigir_cuenta_local_sabida(retirada) -> None:
    """4.25 (6b, R3): «no se sabe» si la cuenta está retirada (error pasajero al leer la configuración: antivirus, sincronización de
    carpetas): la petición no pasa (503, «inténtelo de nuevo»), pero NO se revoca ni se cierra nada."""
    if retirada is None:
        raise HTTPException(503, {"codigo": "reintentar", "mensaje": MENSAJE_CUENTA_NO_SABIDA})


def _rechazar_cuenta_local(s: Session, u, request: Request | None) -> None:
    """Si la cuenta quedó retirada (E-13): cierra sus sesiones, revoca sus tokens de API, lo audita y responde 403. Si no se sabe (R3):
    503 sin revocar ni cerrar nada."""
    retirada = _cuenta_local_retirada(s, u)
    _exigir_cuenta_local_sabida(retirada)
    if retirada is not True:
        return
    _revocar_sesiones(s, u.id)
    _revocar_tokens_api(s, u.id)
    auditar(s, "login_cuenta_local", "Cuenta creada solo en esta computadora: ya no se usa (se entra con la cuenta de la página web)", u, request=request)
    raise HTTPException(403, {"codigo": "cuenta_local", "mensaje": MENSAJE_CUENTA_LOCAL.format(web=_web_programa())})


def sesion_empresa(ctx: Contexto = Depends(contexto)):
    """Sesión sobre la base de datos propia de la empresa activa."""
    with ctx.sesion() as s:
        yield s


def requiere(permiso: str):
    def dep(ctx: Contexto = Depends(contexto)) -> Contexto:
        ctx.exigir(permiso)
        return ctx
    return dep


def ve_documentos(ctx: Contexto) -> bool:
    """(3.87) Si el rol ve comprobantes, pagos y costos (PERMISOS_DOCUMENTOS). Un token de API siempre trae alguno."""
    return any(ctx.puede(p) for p in PERMISOS_DOCUMENTOS)


def con_documentos(ctx: Contexto = Depends(contexto)) -> Contexto:
    """(3.87) Dependencia de las rutas de comprobantes, pagos e inventario: los roles operativos reciben 403."""
    if not ve_documentos(ctx):
        raise HTTPException(403, f"Su rol ({ctx.rol}) no tiene acceso a comprobantes, pagos ni costos")
    return ctx


def empresas_ocultas_de(u) -> set:
    """Empresas que este administrador del sistema no ve (3.80). Vacío para el super administrador y para los usuarios normales."""
    if not getattr(u, "es_superadmin", False) or getattr(u, "admin_principal", False):
        return set()
    try:
        return {int(x) for x in json.loads(getattr(u, "empresas_ocultas", None) or "[]")}
    except (TypeError, ValueError):
        return set()


def admin_ve_empresa(u, eid) -> bool:
    try:
        return int(eid) not in empresas_ocultas_de(u)
    except (TypeError, ValueError):
        return True


def es_admin_principal(s: Session, u) -> bool:
    """¿Es el super administrador? Si ninguna cuenta tiene la marca (instalaciones anteriores a 3.80), lo es el primer administrador
    del sistema por id, y queda marcado."""
    if not getattr(u, "es_superadmin", False):
        return False
    if getattr(u, "admin_principal", False):
        return True
    if s.exec(select(Usuario).where(Usuario.es_superadmin == True, Usuario.admin_principal == True).limit(1)).first():  # noqa: E712
        return False
    primero = s.exec(select(Usuario).where(Usuario.es_superadmin == True).order_by(Usuario.id).limit(1)).first()  # noqa: E712
    if primero and primero.id == getattr(u, "id", None):
        primero.admin_principal = True; s.add(primero); s.commit()
        try:
            u.admin_principal = True
        except Exception:  # noqa: BLE001
            pass
        return True
    return False


def superadmin(request: Request, u: "Usuario" = Depends(solo_usuario), s: Session = Depends(get_session)) -> "Usuario":
    if _soporte_de(u, request):              # 4.35: al entrar como otro usuario no hay consola (ni otro «Entrar como»), sea cual sea la ruta
        raise HTTPException(403, MENSAJE_SUPLANTADA)
    if not u.es_superadmin:
        raise HTTPException(403, "Solo el administrador del sistema puede hacer esto")
    _exigir_mfa(s, u)
    exigir_ip_admin(request)                 # lista de IP permitidas (opcional, 2.3)
    if u.debe_cambiar_password:              # 3.87: R123 también en la consola (antes la contraseña temporal servía para operarla por API)
        raise HTTPException(403, {"codigo": "cambiar_password", "mensaje": "Debe cambiar la contraseña temporal antes de continuar"})
    ocultas = empresas_ocultas_de(u)         # 3.80: una empresa oculta para este administrador no existe para él en la consola
    if ocultas:
        for v in (request.path_params.get("eid"), request.path_params.get("empresa_id"), request.query_params.get("empresa_id")):
            if v is not None and str(v).isdigit() and int(v) in ocultas:
                raise HTTPException(404, "Empresa no encontrada")
    return u


def solo_principal(s: Session, a) -> None:
    if not es_admin_principal(s, a):
        raise HTTPException(403, "Solo el super administrador puede administrar a los administradores del sistema")


def _solo_principal_si_admin_sistema(s: Session, actor, uid) -> None:
    """3.87: las membresías de un administrador del sistema (agregarlo a una empresa, cambiarle el rol o quitarlo) solo las toca el
    super administrador, desde la consola o desde Usuarios de la empresa. Cada uno sí puede tocar la suya."""
    obj = s.get(Usuario, uid) if uid else None
    if obj and obj.es_superadmin and obj.id != getattr(actor, "id", None):
        solo_principal(s, actor)


def _exigir_usuario_visible(s: Session, a, uid: int) -> None:
    """3.87: un administrador con empresas ocultas no bloquea ni restablece la contraseña (acciones sobre la cuenta entera) de quien
    pertenece a alguna de ellas: 404 si todas sus empresas le están ocultas (para él no existe), 403 si comparte alguna visible.
    Su propia cuenta sí (restablecer la suya aunque sea miembro de una empresa oculta)."""
    ocultas = empresas_ocultas_de(a)
    if not ocultas or uid == getattr(a, "id", None):
        return
    suyas = {m.empresa_id for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid)).all()}
    if suyas & ocultas:
        if not (suyas - ocultas):
            raise HTTPException(404, "Usuario no encontrado")
        raise HTTPException(403, "Ese usuario también pertenece a empresas que usted no administra: solo el super administrador puede hacerlo")


def _exigir_traible(s: Session, actor, u, eid: int | None) -> None:
    """3.87: quien tiene empresas ocultas no trae a otra empresa (consola, Nueva cuenta o Usuarios de la empresa como soporte) una
    cuenta que ya pertenece a alguna de ellas; además, la membresía de otro administrador del sistema solo la da el super administrador."""
    if u is None:
        return
    _solo_principal_si_admin_sistema(s, actor, u.id)
    ocultas = empresas_ocultas_de(actor) if getattr(actor, "es_superadmin", False) else set()
    if not ocultas or u.id == getattr(actor, "id", None):
        return
    suyas = {m.empresa_id for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()}
    if eid not in suyas and suyas & ocultas:
        raise HTTPException(403, "Ese correo ya tiene una cuenta que usted no administra: pídale al super administrador que lo autorice")


def _poner_cookie(response: Response | None, token: str, request: Request | None):
    """Cookie HttpOnly (el JS no la lee) y Secure salvo en localhost; solo sirve para descargas GET."""
    if response is None:
        return
    host = (request.url.hostname if request else "") or ""
    segura = PRODUCCION or host not in ("localhost", "127.0.0.1", "::1")
    response.set_cookie(COOKIE, token, max_age=DURACION_SESION, httponly=True, secure=segura, samesite="strict", path="/")


def _revocar_sesiones(s: Session, usuario_id: int, excepto_sid: str | None = None):
    for ses in s.exec(select(Sesion).where(Sesion.usuario_id == usuario_id, Sesion.revocada == False)).all():  # noqa: E712
        if ses.sid != excepto_sid:
            ses.revocada = True; s.add(ses)
    s.commit()


def _limpiar_sesiones(s: Session):
    """Borra sesiones revocadas o vencidas con más de 30 días (mantenimiento ligero en cada login)."""
    limite = datetime.now(timezone.utc) - timedelta(days=30)
    for ses in s.exec(select(Sesion).where(Sesion.ultimo_uso < limite)).all():
        s.delete(ses)
    s.commit()


MENSAJE_PRUEBA = ("Su prueba gratis terminó el {fecha}. Escríbanos al WhatsApp 6228 1597 o a {correo} para activar su plan: "
                  "sus datos se conservan.")


def prueba_vencida(e) -> bool:
    from .config import ahora_cr
    return bool(e.prueba_hasta) and ahora_cr().date().isoformat() > str(e.prueba_hasta)[:10]


def _fecha_cr(iso) -> str:
    v = str(iso or "")[:10]
    return f"{v[8:10]}/{v[5:7]}/{v[:4]}" if len(v) == 10 else v


def _info_empresa(e, ocultos_usuario: list | None = None) -> dict:
    d = {"es_demo": bool(e.es_demo), "prueba_hasta": e.prueba_hasta, "prueba_vencida": prueba_vencida(e), "tipo_negocio": tipo_negocio_de(e),
         "factura_electronica": getattr(e, "factura_electronica", True) is not False,
         "mfa_sin_excepcion": bool(getattr(e, "mfa_sin_excepcion", False))}      # 4.7: la renuncia a la verificación no vale en esta empresa
    from . import planes
    d["medica_activa"] = _medica_habilitada(e)
    d["plan"] = planes.info(e)
    if ocultos_usuario:                                        # 3.70: lo apagado solo para este usuario tampoco sale en su menú
        d["plan"]["modulos"] = sorted(set(d["plan"]["modulos"]) - set(ocultos_usuario))
        d["plan"]["ocultos_usuario"] = list(ocultos_usuario)
    d["es_local"] = _es_local()                                 # etapa 1: la aplicación pide la franja de conexión y plazo de Hacienda
    if aviso_local is not None:
        try:
            d["instalacion"] = aviso_local(e.id)
        except Exception:  # noqa: BLE001
            d["instalacion"] = None
        try:                                                   # 4.9: la nube niega el acceso SIN revocar (empresa bloqueada por cobro,
            from . import sinc as _sinc                        # cortafuegos): franja aparte, nunca «revocada»; {desde, motivo} o None
            d["sin_acceso_nube"] = _sinc.sin_acceso(e.id)
            d["correo_en_nube"] = _sinc.correo_en_nube(e.id)   # 4.14: para marcar en el comprobante que el correo lo envía la nube
        except Exception:  # noqa: BLE001
            d["sin_acceso_nube"] = None
        try:                                                   # 4.25 (tanda 9): rango de esta computadora conectada (los demás ítems se cambian en la web); 0 = sin conectar
            from . import sinc as _sinc
            r = _sinc.rango_web(e.id)
            d["rango_items"] = 0 if r is None else (r if r >= 1 else -1)
        except Exception:  # noqa: BLE001
            d["rango_items"] = 0
        try:                                                   # 4.32 (contrato §5): bandera datos_v2 del programa = protocolo 2 y no en pausa
            from . import sinc_datos_programa as _sdp
            d["datos_v2"] = _sdp.protocolo(e.id) == 2 and not _sdp.en_pausa(e.id)
        except Exception:  # noqa: BLE001
            d["datos_v2"] = False
        try:                                                   # 4.32 (contrato §5): bandera pedidos_programa = datos_v2 y la última respuesta de /datos lo dijo
            from . import sinc_datos_programa as _sdp
            d["pedidos_programa"] = bool(d["datos_v2"]) and bool(_sdp.estado(e.id).get("pedidos_programa"))
        except Exception:  # noqa: BLE001
            d["pedidos_programa"] = False
        d["comandas_programa"] = False                         # validación 4.32: sin pedidos_programa (interruptor apagado o en pausa), la estación
        if not d["pedidos_programa"]:                          # sigue mientras queden comandas pendientes de pedidos ya asignados aquí (plan §7)
            try:
                from . import comandas as _com, sinc_datos_programa as _sdp
                if _sdp.protocolo(e.id) == 2:
                    with Session(engine_empresa(e.id)) as _s:
                        d["comandas_programa"] = _com.resumen_comandas(_s, e.id)["comandas_pendientes"] > 0
            except Exception:  # noqa: BLE001
                d["comandas_programa"] = False
    try:                                                       # 4.32 (B7): franja y «Cambios que no quedaron», también en pausa y en la página web
        from . import sinc_datos as _sd, sinc_datos_programa as _sdp
        d["sinc_pantallas"] = bool(_sd.encendido() and (_sdp.protocolo(e.id) == 2 if d["es_local"] else True))
    except Exception:  # noqa: BLE001
        d["sinc_pantallas"] = False
    return d


# ----------------------------------------------------------------------------- tipo de negocio (2.5)
# Una sola base y tres tipos que deciden qué módulos ve cada empresa y en qué orden. Lo fija el administrador del sistema al crear
# la cuenta; el cliente no lo cambia. Los roles sugeridos de cada tipo se crean como roles personalizados al asignar el tipo.
TIPOS_NEGOCIO = {"facturacion": "Facturación", "comercio": "Comercio (punto de venta)", "restaurante": "Restaurante (mesas y ventas en línea)", "hospitalidad": "Hospitalidad (hotel)", "servicios": "Servicios e IT (TiKe)"}   # 3.51
ROLES_POR_TIPO = {
    "medica": [(nombre, nombre, [permiso]) for permiso, nombre in PERMISOS_MEDICA.items()],
    "servicios": [("Técnico de soporte", "TiKe: atiende tickets, responde al cliente y registra su tiempo; sin facturación ni caja", ["tike"])],   # 3.52
    "hospitalidad": [("Recepcionista", "Recepción del hotel: reservas, check-in y check-out, cuenta del huésped, cobros y caja", ["escribir", "facturar", "catalogos", "cobros", "pos"]),
                     ("Reservas", "Reservaciones: reservas, huéspedes, grupos, depósitos y adelantos; sin facturación ni caja", ["escribir", "catalogos", "cobros"]),
                     ("Camarera", "Ama de llaves: tablero de habitaciones y reportes de limpieza", ["limpieza"]),
                     ("Técnico", "Mantenimiento: incidencias, habitaciones fuera de servicio y preventivo", ["mantenimiento"]),
                     ("Seguridad", "Seguridad: llegadas y salidas sin montos, bitácora de turno, visitantes, vehículos, incidentes y objetos perdidos", ["seguridad"])],
    "comercio": [("Supervisor de caja", "Punto de venta, cierres, ítems e inventario, sin gastos ni contabilidad", ["escribir", "facturar", "catalogos", "inventario", "cobros", "pos"])],
    "facturacion": [],
}


# 3.87: un rol de solo caja (Cajero o propio con solo 'pos') donde el punto de venta no está activo no tiene nada que hacer: contexto()
# le responde 403 sin_caja en todo. La sesión lo trae marcado (pantalla propia en la interfaz), no se asigna ese rol ahí y se avisa
# cuando apagar el punto de venta deja cajeros sin trabajo.
MOTIVOS_SIN_CAJA = {"tipo": "su tipo de negocio no tiene punto de venta", "plan": "el plan de la empresa no incluye el punto de venta",
                    "empresa": "el punto de venta está apagado para toda la empresa", "usuario": "el punto de venta no está activo para esta persona"}
QUE_HACER_SIN_CAJA = {"tipo": "Elija otro rol.", "plan": "Elija otro rol o agregue primero el punto de venta al plan.",
                      "empresa": "Elija otro rol o encienda primero el punto de venta para la empresa.",
                      "usuario": "Elija otro rol o deje encendido el punto de venta para esta persona."}


def motivo_sin_caja(e, ocultos=()) -> str | None:
    """(3.87) Por qué el punto de venta no está activo en la empresa `e` para un usuario con esos módulos apagados: 'tipo' (no existe en
    su tipo de negocio), 'plan' (el plan no trae el extra), 'empresa' (apagado para toda la empresa) o 'usuario' (apagado solo para él).
    None si está activo. Es la misma condición que usa contexto() para el 403 sin_caja."""
    from . import planes
    if "pos" in planes.modulos_de(e) - set(ocultos or ()):
        return None
    tipo = planes.tipo_de(e)
    if "pos" not in planes.BASE.get(tipo, set()) and "pos" not in planes.EXTRAS_TIPO.get(tipo, []):
        return "tipo"
    if "pos" not in planes.modulos_plan(e):
        return "plan"
    return "empresa" if "pos" in planes.ocultos_de(e) else "usuario"


def rol_sin_caja(s: Session, e, rol: str | None, ocultos=()) -> str | None:
    """(3.87) El motivo de motivo_sin_caja si `rol` es de solo caja; None si no lo es o si tiene el punto de venta."""
    if not rol or not solo_pos(permisos_de_rol(s, e.id, rol)):
        return None
    return motivo_sin_caja(e, ocultos)


def exigir_caja_para_rol(s: Session, e, rol: str, m=None, ocultos=None, u=None) -> None:
    """(3.87) 400 si el cambio deja a la persona con un rol de solo caja sin el punto de venta (no tendría nada que hacer). m: su membresía
    actual (None = nueva); ocultos: sus módulos apagados después del cambio (None = los de ahora). No se rechaza lo que ya estaba así
    antes del cambio ni a un administrador del sistema (dentro de la empresa trabaja como Administrador)."""
    if u is not None and getattr(u, "es_superadmin", False):
        return
    actuales = ocultos_usuario(m) if m is not None else []
    motivo = rol_sin_caja(s, e, rol, actuales if ocultos is None else ocultos)
    if not motivo or (m is not None and rol_sin_caja(s, e, m.rol, actuales)):
        return
    raise HTTPException(400, {"codigo": "rol_sin_caja", "mensaje": f"El rol «{rol}» solo usa el punto de venta y {MOTIVOS_SIN_CAJA[motivo]}: "
                                                                f"esa persona no tendría nada que hacer en el sistema. {QUE_HACER_SIN_CAJA[motivo]}"})


def cajeros_sin_caja(s: Session, e) -> list[str]:
    """(3.87) Correos de los usuarios de la empresa (sin los administradores del sistema) con un rol de solo caja y sin el punto de venta."""
    out = []
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == e.id)).all():
        u = s.get(Usuario, m.usuario_id)
        if u and not u.es_superadmin and rol_sin_caja(s, e, m.rol, ocultos_usuario(m)):
            out.append(u.correo)
    return sorted(out)


def aviso_cajeros(antes: list, despues: list) -> str | None:
    """(3.87) Aviso para quien apagó el punto de venta (módulos, plan o tipo de negocio) y dejó cajeros sin nada que hacer."""
    nuevos = [x for x in despues if x not in antes]
    if not nuevos:
        return None
    n = len(nuevos)
    quien = ", ".join(nuevos[:5]) + (f" y {n - 5} más" if n > 5 else "")
    return (("Un usuario con un rol que solo usa el punto de venta (como Cajero) queda" if n == 1 else
             f"{n} usuarios con un rol que solo usa el punto de venta (como Cajero) quedan") +
            f" sin nada que hacer en esta empresa: {quien}. Cámbieles el rol o vuelva a activar el punto de venta.")


def roles_de_empresa(s: Session, empresa_id: int) -> list[str]:
    """Roles base y personalizados de una empresa (consola de administración de cuentas) (3.32)."""
    propios = sorted((r.nombre for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == empresa_id)).all()), key=str.lower)
    e = s.get(Empresa, empresa_id)               # 3.87: sin los de solo caja donde el punto de venta no está activo (no tendrían nada que hacer)
    sin = e is not None and motivo_sin_caja(e) is not None
    return [r for r in list(ROLES) + propios if not (sin and solo_pos(permisos_de_rol(s, empresa_id, r)))]


def migrar_roles_hotel(s: Session) -> dict:
    """Al arrancar (3.20): cada hotel recibe el rol Reservas si no lo tiene, y Camarera/Técnico pierden «guardar registros» cuando
    todavía llevan exactamente los permisos con que se crearon (un rol que el cliente ya tocó no se cambia)."""
    from .db import Empresa
    out = {"reservas": 0, "ajustados": 0}
    viejos = {"camarera": ["escribir", "limpieza"], "técnico": ["escribir", "mantenimiento"]}
    for e in s.exec(select(Empresa)).all():
        if tipo_negocio_de(e) != "hospitalidad":
            continue
        out["reservas"] += len(roles_por_tipo(s, e.id, "hospitalidad", solo={"Reservas"}))   # 4.15: en la primera corrida en la nube no reaparece un rol que el cliente borró
        for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == e.id)).all():
            viejo = viejos.get(r.nombre.lower())
            try:
                actuales = sorted(json.loads(r.permisos or "[]"))
            except ValueError:
                continue
            if viejo and actuales == sorted(viejo):
                r.permisos = json.dumps([p for p in viejo if p != "escribir"]); s.add(r); out["ajustados"] += 1
    s.commit()
    return out


def tipo_negocio_de(e) -> str:
    t = getattr(e, "tipo_negocio", None) or "facturacion"
    return t if t in TIPOS_NEGOCIO else "facturacion"


def roles_por_tipo(s: Session, empresa_id: int, tipo: str, solo: set | None = None) -> list[str]:
    """Crea los roles sugeridos del tipo que todavía no existan en la empresa (no toca los que ya hay). Devuelve los creados."""
    creados = []
    existentes = {r.nombre.lower() for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == empresa_id)).all()}
    for nombre, descripcion, permisos in ROLES_POR_TIPO.get(tipo, []):
        if (solo is not None and nombre not in solo) or nombre.lower() in existentes or nombre.lower() in {r.lower() for r in ROLES}:
            continue
        s.add(RolEmpresa(empresa_id=empresa_id, nombre=nombre, descripcion=descripcion, permisos=json.dumps(sorted(p for p in permisos if p in PERMISOS))))
        creados.append(nombre)
    if creados:
        s.commit()
    return creados


def _empresas_de(s: Session, u: "Usuario") -> list[dict]:
    if u.es_superadmin:
        ocultas = empresas_ocultas_de(u)
        return [{"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id, "rol": "Administrador",
                 "bloqueada": e.bloqueada, "bloqueo_motivo": e.bloqueo_motivo, **_info_empresa(e)} for e in s.exec(select(Empresa).order_by(Empresa.nombre)).all() if e.id not in ocultas]
    out = []
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all():
        e = s.get(Empresa, m.empresa_id)
        if e:
            out.append({"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id, "rol": m.rol,
                        "bloqueada": e.bloqueada, "bloqueo_motivo": e.bloqueo_motivo, **_info_empresa(e, ocultos_usuario(m))})
    return out


def _respuesta(s: Session, u: "Usuario", eid: int | None, request: Request | None = None, response: Response | None = None,
               sid: str | None = None, sin_nube: bool = False) -> dict:
    """Token + datos de sesión. Si no se indica `sid` se abre una sesión nueva en el servidor.
    4.25 (programa local): `sin_nube` marca la sesión nueva como abierta con lo guardado; en el programa la respuesta lleva además
    usuario.de_nube, usuario.nube_manda (4b, D-N), usuario.sin_nube y usuario.dos_pasos_en_web, y a quien la web le administra los dos
    pasos (_nube_manda) no se le pide activar otros aquí."""
    rol = None
    if eid:
        m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first()
        if s.get(Empresa, eid) is None or not (admin_ve_empresa(u, eid) if u.es_superadmin else m):
            eid = None       # 3.87: empresa borrada, oculta o retirada con la sesión abierta: la sesión sigue, sin empresa (antes la base se volvía a crear)
        else:
            rol = "Administrador" if u.es_superadmin else m.rol
    if not sid:
        sid = secrets.token_urlsafe(24)
        s.add(Sesion(sid=sid, usuario_id=u.id, ip=_ip(request), agente=(request.headers.get("user-agent", "")[:200] if request else None), sin_nube=bool(sin_nube)))
        s.commit()
    ses = s.exec(select(Sesion).where(Sesion.sid == sid)).first()
    soporte = _datos_soporte(s, ses)               # 4.35: sesión de soporte («Entrar como»): 1 hora, solo esta empresa y la franja
    duracion = DURACION_SUPLANTACION if soporte else DURACION_SESION
    restante = duracion
    if ses and ses.creada:                         # al reutilizar la sesión el token solo dura lo que le queda a la sesión (R125)
        restante = max(60, int(duracion - (datetime.now(timezone.utc) - ses.creada.replace(tzinfo=timezone.utc)).total_seconds()))
    token = firmar({"tipo": "sesion", "uid": u.id, "eid": eid, "sid": sid}, restante)
    _poner_cookie(response, token, request)
    nube = _nube_manda(u)
    exigido = False if nube else mfa_obligatorio(s, u)   # 4.7: «mfa_obligatorio» ya descuenta la renuncia que vale; 4.25: los dos pasos de quien viene de la nube los pide la web
    usuario = {"id": u.id, "correo": u.correo, "nombre": u.nombre, "mfa_activo": u.mfa_activo, "es_superadmin": u.es_superadmin,
               "debe_cambiar_password": u.debe_cambiar_password, "mfa_obligatorio": exigido and not renuncia_mfa_cubre(s, u),
               "mfa_exigido_rol": exigido, "mfa_renuncia": _renuncia_sesion(u),
               "terminos_pendientes": terminos_pendientes(u), "paleta": u.paleta}
    if ingreso_nube is not None:                   # 4.25: solo en el programa (los usa la pantalla)
        usuario.update({"de_nube": bool(u.de_nube), "nube_manda": nube, "sin_nube": bool(ses and getattr(ses, "sin_nube", False)),
                        "dos_pasos_en_web": nube and bool(getattr(u, "mfa_nube", None) or getattr(u, "mfa_entrar_nube", False)),
                        # 4.25 (tanda 4): la web le exige los dos pasos y no los tiene: la pantalla le pide activarlos EN LA WEB (contexto da 403)
                        "dos_pasos_falta": nube and bool(getattr(u, "mfa_entrar_nube", False)) and not getattr(u, "mfa_nube", None)})
    empresas = _empresas_de(s, u)
    if soporte:                                    # 4.35: la franja «Está usando FISITAAP como…»; sin elegir colores por la persona
        usuario.update({"soporte": soporte, "paleta": u.paleta or "fusion"})
        empresas = [x for x in empresas if x["id"] == eid]     # sus otras empresas no se ven ni se abren desde aquí
    return {"token": token,
            "usuario": usuario,
            "empresas": empresas, "empresa_id": eid, "rol": rol, "datos_ejemplo": DATOS_EJEMPLO,
            "permisos": sorted(_permisos_sesion(s, u, eid, rol)) if eid else [],
            "rrhh_requiere_mfa": bool(eid) and not _rrhh_cubierto(u, rol, s, eid) and "rrhh" in _permisos_plan(s, u, eid, rol),   # 4.7: el rol trae RRHH, falta la verificación (o una renuncia que valga aquí)
            "sin_caja": _sin_caja_sesion(s, u, eid, rol) if eid else None,      # 3.87: rol de solo caja sin el punto de venta (motivo)
            **(_sucursales_sesion(s, u, eid) if eid else {"sucursales": [], "sucursal_fija": None})}


def _datos_soporte(s: Session, ses) -> dict | None:
    """4.35: lo que la pantalla muestra de una sesión de soporte (correo y nombre del administrador del sistema y hasta cuándo dura), o
    None si la sesión es de la persona misma."""
    if ses is None or not getattr(ses, "suplantada_por", None):
        return None
    a = s.get(Usuario, ses.suplantada_por)
    vence = ses.creada.replace(tzinfo=timezone.utc) + timedelta(seconds=DURACION_SUPLANTACION)
    return {"correo": a.correo if a else None, "nombre": a.nombre if a else None, "vence": vence.isoformat()}


def _sucursales_sesion(s: Session, u: "Usuario", eid: int) -> dict:
    from . import sucursales as _suc
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first()
    return _suc.resumen_sesion(s, eid, m)


def _permisos_sesion(s: Session, u: "Usuario", eid: int, rol: str | None) -> set:
    """Permisos que ve el navegador: los del rol, menos los módulos que el plan de la empresa no incluye (3.16).
    4.7: y sin Recursos humanos mientras el usuario no tenga la verificación en dos pasos (la misma regla de contexto())."""
    return quitar_rrhh_sin_mfa(_permisos_plan(s, u, eid, rol), u, rol, s, eid)[0]


def _permisos_plan(s: Session, u: "Usuario", eid: int, rol: str | None) -> set:
    """(4.7) Los permisos del rol menos los módulos que el plan no incluye o están apagados, antes de la regla de la verificación."""
    from . import planes
    base = set(PERMISOS) if u.es_superadmin else permisos_de_rol(s, eid, rol)
    e = s.get(Empresa, eid)
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first() if getattr(u, "id", None) is not None else None
    return planes.filtrar_permisos(e, base, ocultos_usuario(None if u.es_superadmin else m)) if e else base


def _sin_caja_sesion(s: Session, u: "Usuario", eid: int, rol: str | None) -> str | None:
    """(3.87) Motivo (tipo, plan, empresa o usuario) si la sesión es de un rol de solo caja sin el punto de venta: la misma condición del
    403 sin_caja de contexto(). Nunca para el administrador del sistema."""
    if u.es_superadmin:
        return None
    e = s.get(Empresa, eid)
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first() if getattr(u, "id", None) is not None else None
    return rol_sin_caja(s, e, rol, ocultos_usuario(m)) if e else None


def crear_empresa(s: Session, nombre: str, correo: str, numero_id: str = "", nombre_comercial: str | None = None, **extra) -> Empresa:
    """Crea la empresa con su clave de cifrado y su base de datos propia."""
    if extra.get("tipo_negocio") and "modulos_ocultos" not in extra:        # 3.70: lo que no aplica a ese tipo nace apagado
        from . import planes
        extra["modulos_ocultos"] = json.dumps(planes.ocultos_por_tipo(extra["tipo_negocio"], prueba=bool(extra.get("es_demo") or extra.get("prueba_hasta"))))
    extra.setdefault("medica_activa", False)
    e = Empresa(nombre=nombre, nombre_comercial=nombre_comercial or nombre, numero_id=numero_id, correo=correo, ambiente="sandbox",
                proveedor_sistemas=PROVEEDOR_SISTEMAS, clave_cifrada=secretos.nueva_clave_empresa(), **extra)
    s.add(e); s.commit(); s.refresh(e)
    engine_empresa(e.id)            # crea data/empresas/empresa_<id>.db con sus tablas
    if e.medica_activa:
        roles_por_tipo(s, e.id, "medica")
    if extra.get("tipo_negocio") == "restaurante":   # 3.58: el restaurante nace con una caja de salón y 6 mesas (se ajustan en Punto de venta › Configuración)
        try:
            from . import modulos
            with Session(engine_empresa(e.id)) as se:
                modulos.plantilla_restaurante(se, e.id)
        except Exception as ex:  # noqa: BLE001  (una plantilla que falle no impide crear la empresa)
            import logging
            logging.getLogger(__name__).warning("plantilla de mesas de la empresa %s: %s", e.id, ex)
    elif extra.get("tipo_negocio") in ("comercio", "hospitalidad"):   # 3.87: la caja del comercio (y la del hotel con punto de venta) también nace con «Caja general»
        try:
            from . import modulos
            with Session(engine_empresa(e.id)) as se:
                modulos.cuenta_efectivo_inicial(se, e.id)
        except Exception as ex:  # noqa: BLE001  (no impide crear la empresa)
            import logging
            logging.getLogger(__name__).warning("cuenta de efectivo de la empresa %s: %s", e.id, ex)
    return e


# ----------------------------------------------------------------------------- estado / arranque
@router.get("/estado")
def estado(request: Request, s: Session = Depends(get_session)):
    hay_admin = s.exec(select(Usuario).where(Usuario.es_superadmin == True).limit(1)).first() is not None  # noqa: E712
    from .config import AVISO_ENTORNO
    try:
        from . import sitio as _sitio
        captcha = _sitio.turnstile_login() or None              # 3.84: clave pública del sitio si el inicio de sesión pide la verificación
    except Exception:  # noqa: BLE001
        captcha = None
    from . import version as _version                         # 4.2: la pantalla compara su versión con la del programa en marcha
    salida = {"hay_admin": hay_admin, "aviso_entorno": AVISO_ENTORNO or None, "captcha": captcha,
              "version": _version.EN_EJECUCION, "archivos": _version.actual().get("version"), "pin_local": _es_local()}
    if ingreso_nube is not None or _es_local():     # 4.25 (programa local): aviso «sin internet» y la página web para recuperar la contraseña
        from . import sinc as _sinc
        cfgs = _sinc._cfgs_empresas()               # tanda 6: una sola pasada por las empresas para los dos bloques
        if ingreso_nube is not None:
            salida.update(_sinc.estado_ingreso(cfgs))
        if _es_local():                             # tanda 6: {nueva, vinculada, admin_local, web, equipo}
            salida["local"] = _sinc.resumen_ingreso(s, request, cfgs)
    return salida


class SetupIn(BaseModel):
    correo: str
    password: str
    nombre: str
    token: Optional[str] = None          # FE_SETUP_TOKEN (R287)


@router.post("/setup", dependencies=[Depends(solo_web)])
def setup(data: SetupIn, request: Request, response: Response, s: Session = Depends(get_session)):
    """Crea el superadministrador. Solo funciona una vez y solo con el token de instalación (FE_SETUP_TOKEN) o desde la
    propia máquina: en una instalación nueva en internet el primer visitante no puede adueñarse del sistema (R287).
    4.25 (tanda 6): en el programa local real responde 403 solo_web (salvo FE_LOCAL_ADMIN=1)."""
    solo_web(request)
    limitar_ip(request, "setup")
    if s.exec(select(Usuario).where(Usuario.es_superadmin == True).limit(1)).first():  # noqa: E712
        raise HTTPException(400, "El administrador del sistema ya fue creado")
    token_instalacion = (os.getenv("FE_SETUP_TOKEN") or "").strip()
    local = (_ip(request) or "") in ("127.0.0.1", "::1", "localhost", "testclient")   # respeta el proxy de confianza
    if PRODUCCION and not token_instalacion:
        raise HTTPException(403, "En producción el administrador del sistema solo se crea con la variable FE_SETUP_TOKEN definida en el servidor")
    if token_instalacion:
        if not hmac.compare_digest((data.token or "").strip().encode("utf-8", "replace"), token_instalacion.encode()):
            raise HTTPException(403, "Token de instalación incorrecto (variable FE_SETUP_TOKEN del servidor)")
    elif not local:
        raise HTTPException(403, "Para crear el administrador desde internet defina la variable FE_SETUP_TOKEN en el servidor e indíquela aquí")
    correo = validar_correo(data.correo)
    validar_password(data.password, correo)
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first() or Usuario(correo=correo, nombre=data.nombre, password_hash="")
    u.nombre, u.password_hash, u.es_superadmin, u.admin_principal = data.nombre.strip(), hash_password(data.password), True, True   # 3.80: super administrador
    s.add(u); s.commit(); s.refresh(u)
    for e in s.exec(select(Empresa)).all():
        if not s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == e.id).limit(1)).first():
            s.add(UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Administrador"))
    s.commit()
    auditar(s, "setup_admin", "Administrador del sistema creado", u, request=request)
    return _respuesta(s, u, None, request, response)


# ----------------------------------------------------------------------------- sesión
class LoginIn(BaseModel):
    correo: str
    password: str
    turnstile: Optional[str] = None      # 3.84: respuesta del recuadro de verificación de Cloudflare


def _exigir_captcha(s: Session, request: Request | None, token: str | None, accion: str, correo: str | None = None):
    """Verificación contra robots del inicio de sesión y de la recuperación de contraseña (3.84). Va después del límite por
    conexión y antes de mirar la contraseña: sin verificación no se gasta el cálculo lento ni se toca el contador de la cuenta."""
    from . import sitio as _sitio
    ok, nota = _sitio.verificar_login((token or "")[:4096], _ip(request), accion)
    if nota in ("sin_respuesta", "claves"):
        auditar(s, "captcha_sin_respuesta", ("Cloudflare no respondió" if nota == "sin_respuesta" else "Cloudflare rechazó la clave secreta de Turnstile")
                + f"; se dejó pasar ({accion})", None, request=request, correo=correo)
    if ok:
        return
    auditar(s, "captcha_fallido", f"Sin verificación contra robots ({accion})" if nota == "sin_token" else f"La verificación contra robots no pasó ({accion})",
            None, request=request, correo=correo)
    if nota == "sin_token":
        raise HTTPException(400, "Falta la verificación contra robots. Si el recuadro de verificación no aparece, recargue la página; si sigue sin "
                                 "aparecer, revise su conexión o permita este sitio en el bloqueador de anuncios.")
    raise HTTPException(400, "La verificación contra robots no pasó o ya venció. Espere el visto bueno del recuadro e intente de nuevo.")


def _avisar_ip_nueva(s: Session, u: Usuario, ip: str | None):
    """Si el usuario ya había entrado antes pero nunca desde esta IP, le envía un aviso por correo (SMTP de alguna de sus empresas)."""
    if not ip:
        return
    previos = s.exec(select(Auditoria).where(Auditoria.usuario_id == u.id, Auditoria.accion == "login").limit(1)).first()
    if not previos or s.exec(select(Auditoria).where(Auditoria.usuario_id == u.id, Auditoria.accion == "login", Auditoria.ip == ip).limit(1)).first():
        return
    empresas = s.exec(select(Empresa)).all() if u.es_superadmin else [s.get(Empresa, m.empresa_id) for m in
                                                                      s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()]
    e = next((e for e in empresas if e and e.smtp_host and e.smtp_remitente), None)
    if not e:
        return
    from . import correo
    from .config import ahora_cr
    try:
        cfg = correo.ConfigSMTP(e.smtp_host, e.smtp_puerto or (465 if (e.smtp_seguridad or "ssl") == "ssl" else 587), e.smtp_usuario,
                                secretos.descifrar(e.clave_cifrada, e.smtp_password), e.smtp_remitente, seguridad=e.smtp_seguridad or "ssl",
                                nombre=e.smtp_nombre or None)
    except Exception:  # noqa: BLE001  la contraseña SMTP no se pudo leer: el aviso no impide el ingreso (R136)
        return
    cuando = ahora_cr().strftime("%d/%m/%Y %H:%M") + " (hora de Costa Rica)"
    texto = (f"Hola {u.nombre},\n\nSe inició sesión en {nombre_sistema()} con su cuenta ({u.correo}) desde una conexión nueva.\n"
             f"Fecha: {cuando}\nDirección IP: {ip}\n\nSi fue usted, ignore este mensaje. Si no, cambie su contraseña de inmediato "
             f"y avise al administrador del sistema.")
    from . import correo_diseno as _dz                                    # 3.83: diseño común
    html = _dz.armar(_dz.plataforma(), titulo="Se entró a su cuenta desde una conexión nueva", asunto=f"{nombre_sistema()}: inicio de sesión desde una conexión nueva",
                     preencabezado=f"Inicio de sesión el {cuando}.", saludo=f"Hola {u.nombre},",
                     parrafos_txt=[f"Se inició sesión en {nombre_sistema()} con su cuenta desde una conexión que no habíamos visto antes."],
                     datos=[("Cuenta", u.correo), ("Fecha", cuando), ("Dirección IP", ip)],
                     aviso="Si fue usted, no tiene que hacer nada. Si no fue usted, cambie su contraseña de inmediato y avise al administrador del sistema.",
                     aviso_tono="ambar")

    destino = u.correo                         # valor suelto: el hilo no toca la instancia de la base

    def _enviar():
        try:
            correo.enviar(cfg, [destino], f"{nombre_sistema()}: inicio de sesión desde una conexión nueva", html, texto, [])
        except Exception:
            pass
    threading.Thread(target=_enviar, daemon=True).start()


def _verificar_lento(password: str, almacenado: str | None) -> bool:
    """Siempre calcula un scrypt para que un correo inexistente tarde lo mismo que uno real."""
    global _HASH_FICTICIO
    if almacenado is None:
        if _HASH_FICTICIO is None:
            _HASH_FICTICIO = hash_password(secrets.token_hex(16))
        verificar_password(password, _HASH_FICTICIO)
        return False
    return verificar_password(password, almacenado)


# 3.87: espera por intentos fallidos sin revelar qué correos tienen cuenta y sin que otro deje a la persona afuera. Cada correo lleva,
# exista o no la cuenta (la respuesta es la misma), contadores en intentoip: «login_fallo» por conexión y correo, «login_cuenta» por
# correo para las conexiones desconocidas y «login_disp» por marca de dispositivo y correo. Cada MAX_INTENTOS fallos seguidos abren
# MINUTOS_BLOQUEO minutos de espera (igual que antes por cuenta). El dispositivo (cookie firmada) o la conexión desde donde la persona ya
# entró no suma ni espera por el contador del correo: quien ataca desde otro lado ya no la bloquea ahí. La marca es un pase al portador,
# así que lleva su propio contador (vale desde cualquier conexión: copiarla y rotar conexiones no da intentos sin fin): con
# MAX_INTENTOS fallos deja de contar como conocida y vuelve a regir el contador del correo (OWASP «device cookies»). Cada ingreso
# correcto entrega una marca nueva (los ingresos de la persona no le devuelven intentos a una copia vieja) y todas dejan de valer al
# cambiar o restablecer la contraseña. La conexión solo cuenta como conocida con un ingreso correcto en los últimos DIAS_IP_CONOCIDA
# días. Así, por correo, a lo sumo 5 intentos cada 15 minutos desde conexiones desconocidas, 5 por cada marca y 5 por cada conexión
# conocida, más el límite de 30 por conexión cada 5 minutos (LIMITE_IP).
COOKIE_DISPOSITIVO = "facturacr_disp"
DURACION_DISPOSITIVO = 60 * 60 * 24 * 180
DIAS_IP_CONOCIDA = 30


def _sujeto_fallo(request: Request | None, correo: str) -> str:
    return f"{_ip(request) or '?'}|{correo}"[:300]


def _fin_espera(s: Session, clave: str, sujeto: str) -> float:
    fallos = s.exec(select(IntentoIp.momento).where(IntentoIp.clave == clave, IntentoIp.ip == sujeto).order_by(IntentoIp.momento)).all()
    return (fallos[-1] + MINUTOS_BLOQUEO * 60) if fallos and len(fallos) % MAX_INTENTOS == 0 else 0.0


def _huella_cuenta(u: "Usuario") -> str:
    """3.87: la marca del dispositivo vale mientras la contraseña sea la misma (al cambiarla o restablecerla, las marcas viejas, también
    una copiada, dejan de valer). Resumen con la llave del servidor: no dice nada de la contraseña."""
    return _b64(hmac.new(SECRET, f"disp|{u.id}|{u.password_hash or ''}".encode(), hashlib.sha256).digest()[:12])


def _marca_dispositivo(request: Request | None) -> dict | None:
    datos = abrir(request.cookies.get(COOKIE_DISPOSITIVO) or "") if request is not None else None
    return datos if datos and datos.get("tipo") == "dispositivo" and isinstance(datos.get("d"), str) else None


def _dispositivo_de(request: Request | None, u: "Usuario | None") -> str | None:
    """Id del dispositivo si su marca dice que ya entró a esta cuenta con la contraseña actual."""
    datos = _marca_dispositivo(request)
    if not datos or not u:
        return None
    h = _huella_cuenta(u)
    for x in datos.get("c") or []:
        if isinstance(x, list) and len(x) == 2 and x[0] == u.id and hmac.compare_digest(str(x[1]).encode(), h.encode()):
            return datos["d"][:40]
    return None


def _ip_conocida(s: Session, request: Request | None, u: "Usuario | None") -> bool:
    """La conexión tuvo un ingreso correcto de esta cuenta hace poco. Para un correo sin cuenta se hace la misma consulta (uid 0)."""
    ip = _ip(request)
    desde = datetime.now(timezone.utc) - timedelta(days=DIAS_IP_CONOCIDA)
    return bool(ip) and s.exec(select(Auditoria.id).where(Auditoria.usuario_id == (u.id if u else 0), Auditoria.accion == "login", Auditoria.ip == ip,
                                                          Auditoria.fecha >= desde).limit(1)).first() is not None


def _marcar_dispositivo(request: Request | None, response: Response | None, u: "Usuario"):
    if response is None or getattr(u, "id", None) is None:
        return
    datos = _marca_dispositivo(request)
    previos = [x for x in ((datos or {}).get("c") or []) if isinstance(x, list) and len(x) == 2 and isinstance(x[0], int) and x[0] != u.id]
    cuentas = previos[-4:] + [[u.id, _huella_cuenta(u)]]                 # una computadora compartida recuerda hasta 5 cuentas
    host = (request.url.hostname if request else "") or ""
    response.set_cookie(COOKIE_DISPOSITIVO, firmar({"tipo": "dispositivo", "d": secrets.token_urlsafe(12), "c": cuentas}, DURACION_DISPOSITIVO),
                        max_age=DURACION_DISPOSITIVO, httponly=True, secure=PRODUCCION or host not in ("localhost", "127.0.0.1", "::1"),
                        samesite="strict", path="/api/auth")


# 4.25 (programa local, D-I): marca del NAVEGADOR «aquí ya pasó su código de dos pasos con internet». La entrega el programa cuando la web
# acepta el código (sinc._dos_pasos_nube), firmada con la llave de ESTA computadora, atada a la persona, a su contraseña guardada y a la
# huella de sus dos pasos en la web (mfa_nube): si cambia cualquiera de las dos, la marca deja de servir. Sin internet, quien usa los dos
# pasos de la web entra con su contraseña SOLO desde un navegador que traiga una marca vigente: DIAS_MFA_AQUI días desde su último
# ingreso en línea con código en ese navegador (cada uno la renueva). Va en una galleta httponly de ruta /api/auth, sin «Secure» cuando el
# programa se abre por http (127.0.0.1 o la red del local: con «Secure» el navegador la descartaría). Recuerda hasta 5 cuentas por navegador.
COOKIE_MFA_AQUI = "facturacr_mfa_aqui"
DIAS_MFA_AQUI = 30


def _huella_mfa_aqui(u: "Usuario") -> str:
    return _b64(hmac.new(SECRET, f"mfa_aqui|{u.id}|{u.password_hash or ''}|{getattr(u, 'mfa_nube', None) or ''}".encode(), hashlib.sha256).digest()[:12])


def _cuentas_mfa_aqui(request: Request | None) -> list:
    datos = abrir(request.cookies.get(COOKIE_MFA_AQUI) or "") if request is not None else None
    if not datos or datos.get("tipo") != "mfa_aqui":
        return []
    ahora = time.time()
    return [x for x in (datos.get("c") or []) if isinstance(x, list) and len(x) == 3 and isinstance(x[0], int) and isinstance(x[1], str)
            and isinstance(x[2], (int, float)) and 0 <= ahora - x[2] < DIAS_MFA_AQUI * 86400]


def marcar_mfa_aqui(request: Request | None, response: Response | None, u: "Usuario") -> None:
    """Entrega (o renueva) la marca de este navegador para `u`. Solo para quien usa los dos pasos de la web (mfa_nube con valor)."""
    if response is None or getattr(u, "id", None) is None or not getattr(u, "mfa_nube", None):
        return
    previos = [x for x in _cuentas_mfa_aqui(request) if x[0] != u.id]
    cuentas = previos[-4:] + [[u.id, _huella_mfa_aqui(u), int(time.time())]]
    response.set_cookie(COOKIE_MFA_AQUI, firmar({"tipo": "mfa_aqui", "c": cuentas}, DIAS_MFA_AQUI * 86400), max_age=DIAS_MFA_AQUI * 86400,
                        httponly=True, secure=bool(request is not None and request.url.scheme == "https"), samesite="strict", path="/api/auth")


def mfa_aqui_vigente(request: Request | None, u: "Usuario | None") -> bool:
    """El navegador trae una marca vigente de `u` que coincide con su contraseña guardada y con la huella de sus dos pasos en la web."""
    if u is None or getattr(u, "id", None) is None or not getattr(u, "mfa_nube", None):
        return False
    h = _huella_mfa_aqui(u)
    return any(x[0] == u.id and hmac.compare_digest(x[1].encode(), h.encode()) for x in _cuentas_mfa_aqui(request))


def _limpiar_fallos_login(s: Session, correo: str, sujeto: str | None = None, cuenta: bool = True):
    """Borra la espera por intentos fallidos de ese correo. Sin `sujeto`, toda (desbloqueo, restablecimiento, enlace del correo). Con
    `sujeto` (ingreso correcto), la de esa conexión, y la del correo solo si `cuenta` (se entró desde una conexión desconocida): si la
    persona entra desde su dispositivo, quien prueba claves desde otro lado no recupera sus intentos (ni los de una marca copiada)."""
    correo = (correo or "").lower().strip()
    if cuenta:
        s.exec(sa_delete(IntentoIp).where(IntentoIp.clave == "login_cuenta", IntentoIp.ip == correo[:300]))
    if sujeto:
        s.exec(sa_delete(IntentoIp).where(IntentoIp.clave.in_(("login_fallo", "login_fallo_prog")), IntentoIp.ip == sujeto))
    else:
        for clave in ("login_fallo", "login_disp", "login_fallo_prog"):     # 4.25: también la espera de ese correo en las instalaciones
            s.exec(sa_delete(IntentoIp).where(IntentoIp.clave == clave, IntentoIp.ip.endswith("|" + correo, autoescape=True)))
    s.commit()


def validar_ingreso(s: Session, request: Request | None, correo: str, password: str, turnstile: str | None = None, *,
                    recuadro: bool = True, sujeto: str | None = None, tope: tuple | None = None, comprobar=None) -> "Usuario":
    """4.25: el ingreso con correo y contraseña (lo que hacía la ruta /login hasta la contraseña buena). Devuelve al usuario ya validado
    (no bloqueado, con sus fallos limpios) o lanza el mismo HTTPException de siempre. Quien llama decide si pide el segundo paso o entra.
    Con los valores por omisión es exactamente el ingreso web. Para otras rutas:
    - recuadro=False salta la verificación contra robots (solo para quien ya probó por otro medio que no es un robot).
    - sujeto (p. ej. «inst<id>») reemplaza a la conexión de internet en el tope general («login») y en los fallos («login_fallo» con
      «<sujeto>|<correo>»); además NO se leen ni se escriben el contador por correo («login_cuenta»), la marca de dispositivo ni la
      conexión conocida del ingreso web, y la espera por códigos de dos pasos fallidos rige siempre (lo más estricto).
    - tope (máximo, ventana en segundos, mensaje): el tope general de ese sujeto en lugar de LIMITE_IP (un sujeto que junta a muchas
      personas, como una instalación, no cabe en el cupo de una sola conexión).
    - comprobar(u) (4.25, programa local: el gancho ingreso_nube) reemplaza la comparación con el hash guardado, DESPUÉS del tope y de
      las esperas locales (así valen con y sin internet). Devuelve el Usuario validado (puede ser otro objeto, p. ej. recién creado con
      la ficha de la web), un dict (la contraseña pasó y falta el segundo paso: se limpia la espera y se devuelve tal cual), False (la web
      rechazó la contraseña) o None (no coincide con lo guardado): esos dos cuentan como fallo local. Para negar sin contar fallo
      (bloqueado, sin confirmar, etc.) lanza su HTTPException.
    - Con sujeto, los contadores usan claves propias (clave_contador): «login_prog» y «login_fallo_prog»."""
    limitar_ip(request, clave_contador("login", sujeto), *(tope or (_tope_ingreso() if sujeto is None else ())), sujeto=sujeto)
    fallo = clave_contador("login_fallo", sujeto)
    correo = (correo or "").lower().strip()
    if recuadro:
        _exigir_captcha(s, request, turnstile, "login", correo[:254])
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    ahora = datetime.now(timezone.utc)
    if sujeto is None:
        disp = _dispositivo_de(request, u)                               # 3.87
        por_conexion, por_disp = _sujeto_fallo(request, correo), (f"{disp}|{correo}"[:300] if disp else None)
        if por_disp and _fin_espera(s, "login_disp", por_disp) > time.time():
            por_disp = None                   # la marca que acumuló fallos deja de contar como conocida: rige el contador del correo
        conocido = bool(por_disp) or _ip_conocida(s, request, u)
        fin = max(_fin_espera(s, "login_fallo", por_conexion), 0.0 if conocido else _fin_espera(s, "login_cuenta", correo[:300]))
    else:                                                                # 4.25: contadores propios de quien llama
        por_conexion, por_disp, conocido = f"{sujeto}|{correo}"[:300], None, False
        fin = _fin_espera(s, fallo, por_conexion)
    por_correo = sujeto is None and not conocido                         # el contador por correo es solo del ingreso web
    if u and not conocido and u.bloqueado_hasta and u.bloqueado_hasta.replace(tzinfo=timezone.utc) > ahora:   # códigos de dos pasos fallidos
        fin = max(fin, u.bloqueado_hasta.replace(tzinfo=timezone.utc).timestamp())
    if fin > time.time():
        restante = int((fin - time.time()) // 60) + 1
        auditar(s, "login_bloqueado", f"Intento durante bloqueo temporal ({restante} min restantes)", u, request=request, correo=correo[:254])
        raise HTTPException(429, f"Demasiados intentos fallidos. Intente de nuevo en {restante} minutos.")
    ok = _verificar_lento(password, u.password_hash if u else None) if comprobar is None else comprobar(u)
    if not ok:
        momento = time.time()                                            # 3.87: el mismo registro exista o no la cuenta
        s.add(IntentoIp(clave=fallo, ip=por_conexion, momento=momento))
        if por_disp:                                                     # la marca lleva su cuenta, desde cualquier conexión
            s.add(IntentoIp(clave="login_disp", ip=por_disp, momento=momento))
        if por_correo:
            s.add(IntentoIp(clave="login_cuenta", ip=correo[:300], momento=momento))
        s.commit()
        auditar(s, "login_fallido", "Correo o contraseña incorrectos" + (" (la web rechazó el ingreso)" if comprobar is not None and ok is False else ""),
                u, request=request, correo=correo)
        raise HTTPException(401, "Correo o contraseña incorrectos")
    if isinstance(ok, dict):                                             # 4.25: la contraseña pasó y falta el segundo paso (lo decide `comprobar`)
        _limpiar_fallos_login(s, correo, por_conexion, cuenta=por_correo)
        return ok
    if comprobar is not None:
        u = ok
    if u.bloqueado:
        auditar(s, "login_rechazado", "Cuenta bloqueada por el administrador", u, request=request)
        raise HTTPException(403, "Su cuenta está bloqueada. Contacte al administrador del sistema.")
    u.intentos_fallidos = 0
    if not (u.bloqueado_hasta and u.bloqueado_hasta.replace(tzinfo=timezone.utc) > ahora):   # la espera por códigos sigue en mfa/verificar
        u.bloqueado_hasta = None
    s.add(u); s.commit()
    _limpiar_fallos_login(s, correo, por_conexion, cuenta=por_correo)
    return u


@router.post("/login")
def login(data: LoginIn, request: Request, response: Response, s: Session = Depends(get_session)):
    if ingreso_nube is not None:                   # 4.25 (programa local): quien viene de la nube (o no existe aquí) lo valida la web
        r = ingreso_nube(s, request, response, data)
        if r is not None:
            return r
    u = validar_ingreso(s, request, data.correo, data.password, data.turnstile)
    _rechazar_cuenta_local(s, u, request)          # 4.25 (E-13): después de comprobar la contraseña y el bloqueo
    if u.mfa_activo:
        return {"mfa_requerido": True, "token_mfa": firmar({"tipo": "mfa", "uid": u.id}, DURACION_MFA)}
    return _entrar(s, u, request, response)


def _entrar(s: Session, u: Usuario, request: Request | None, response: Response | None, sin_nube: bool = False, detalle: str | None = None) -> dict:
    _rechazar_cuenta_local(s, u, request)          # 4.25 (E-13): paso común de contraseña, PIN y dos pasos
    todas = _empresas_de(s, u)
    emps = [e for e in todas if not e["bloqueada"] or u.es_superadmin]
    if not u.es_superadmin and not emps:
        bloqueadas = [e for e in todas if e["bloqueada"]]
        if bloqueadas:                                                  # el motivo que escribió el administrador sí se muestra (R302)
            motivo = next((e.get("bloqueo_motivo") for e in bloqueadas if e.get("bloqueo_motivo")), None)
            raise HTTPException(403, "El acceso de su empresa está bloqueado. " + (motivo or "Contacte al administrador del sistema."))
        raise HTTPException(403, "Su usuario no tiene empresas asignadas. Contacte al administrador del sistema.")
    eid = emps[0]["id"] if (len(emps) == 1 and not u.es_superadmin) else None
    _avisar_ip_nueva(s, u, _ip(request))
    u.ultimo_acceso = datetime.now(timezone.utc)
    u.pin_fallos = 0                                   # 4.25: entró (con contraseña, o con un PIN que todavía no estaba apagado): vuelve a tener sus intentos de PIN
    s.add(u); s.commit()
    _limpiar_sesiones(s)
    auditar(s, "login", detalle, u, eid, request)      # 4.25: en el programa, «validado en la web» o «sin internet: …»
    _marcar_dispositivo(request, response, u)          # 3.87: aquí ya se entró; la espera que provoque otro no lo frena
    return _respuesta(s, u, eid, request, response, sin_nube=sin_nube)


def _es_local() -> bool:
    return os.environ.get("FE_MODO_LOCAL", "") == "1"


def _tope_ingreso() -> tuple:
    """4.25 (9b, U12): el tope general de ingresos por conexión (clave «login», contando los buenos): en el programa local real
    LIMITE_IP_PROGRAMA (150 cada 5 minutos: toda la caja entra desde 127.0.0.1); en la web, LIMITE_IP como siempre. La espera por
    cuenta (5 contraseñas malas, 15 minutos) y el apagado del PIN no cambian."""
    return LIMITE_IP_PROGRAMA if _es_local() else LIMITE_IP


class PinEntrarIn(BaseModel):
    correo: str
    pin: str


class PinIn(BaseModel):
    pin: str
    password: str


@router.put("/pin")
def poner_pin(data: PinIn, request: Request, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None), s: Session = Depends(get_session)):
    """Etapa 1: el usuario pone (o quita, con PIN vacío) su PIN de caja. Pide su contraseña. En una instalación vinculada lo administra la nube."""
    u, _ = _autenticar(request, authorization, facturacr_token, s)
    if _es_local() and u.de_nube:
        raise HTTPException(400, "Su PIN lo administra la nube: póngalo en la página web y llega a esta computadora al sincronizar")
    if not verificar_password(data.password, u.password_hash):
        raise HTTPException(400, "La contraseña no coincide")
    pin = (data.pin or "").strip()
    if pin and not (pin.isdigit() and 4 <= len(pin) <= 6):
        raise HTTPException(400, "El PIN debe tener de 4 a 6 números")
    if pin and (len(set(pin)) == 1 or pin in "0123456789" or pin in "9876543210"):
        raise HTTPException(400, "Ese PIN es muy fácil de adivinar: use otro")
    u.pin_hash = hash_password(pin) if pin else None
    s.add(u); s.commit()
    auditar(s, "pin_caja", "PIN de caja " + ("actualizado" if pin else "quitado"), u, request=request)
    return {"ok": True}


@router.post("/pin/entrar")
def entrar_con_pin(data: PinEntrarIn, request: Request, response: Response, s: Session = Depends(get_session)):
    """Etapa 1: entrada rápida a FISITAAP Local con PIN, solo para usuarios de caja sin verificación en dos pasos. Con los mismos topes de intentos.
    4.25 (programa local): (1) para quien viene de la nube, con internet se pide antes su ficha a la web (POST /api/sinc/usuario, el
    correo en el cuerpo): un bloqueo, una baja o un PIN nuevo aplican también aquí; sin internet vale lo guardado, y el PIN sirve solo a
    quien tiene aquí un hash de PIN utilizable; (2) contador por cuenta desde cualquier conexión: PIN_MAX_FALLOS PIN malos seguidos
    apagan el PIN de esa persona en esta computadora hasta que entre con su contraseña; (3) no entra quien usa dos pasos, los de esta
    computadora o los de la web (mfa de la ficha), ni a quien la web se los exige, ni quien tiene contraseña temporal en la web;
    (4) si la web no mandó ninguna ficha fresca, la sesión se abre marcada sin_nube (validada con lo guardado)."""
    if not _es_local():
        raise HTTPException(404, "Solo en el programa local")
    limitar_ip(request, "login", *_tope_ingreso())                       # 4.25 (9b, U12)
    correo = data.correo.lower().strip()
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    por_conexion = _sujeto_fallo(request, correo)
    fin = _fin_espera(s, "login_fallo", por_conexion)
    if fin > time.time():
        raise HTTPException(429, f"Demasiados intentos fallidos. Intente de nuevo en {int((fin - time.time()) // 60) + 1} minutos.")
    from . import sinc as _sinc
    sin_ficha = False                                                    # 4.25 (Q4): viene de la nube y la web no mandó ninguna ficha fresca
    if u is not None and _viene_de_nube(u) and (u.pin_fallos or 0) < PIN_MAX_FALLOS:   # D-N: vale para todo el que viene de la nube
        u, fresca = _sinc.refrescar_para_pin(s, u)                        # con internet, la ficha fresca de la web (sin internet, lo guardado)
        sin_ficha = not fresca
    if u is not None and (u.pin_fallos or 0) >= PIN_MAX_FALLOS:          # apagado por intentos: no se compara nada ni cuenta otro fallo
        raise HTTPException(403, MENSAJE_PIN_APAGADO)
    if u is not None and u.pin_hash == _sinc.HASH_INSERVIBLE:           # 4.25 (D-E): su PIN no baja a esta computadora hasta que entre en línea aquí; no es un fallo
        raise HTTPException(403, "Entre una vez con su correo y contraseña en esta computadora (con internet) para activar su PIN aquí")
    if not _verificar_lento(data.pin, u.pin_hash if u and u.pin_hash else None):
        s.add(IntentoIp(clave="login_fallo", ip=por_conexion, momento=time.time()))
        if u is not None:
            u.pin_fallos = (u.pin_fallos or 0) + 1; s.add(u)
        s.commit()
        auditar(s, "login_fallido", "PIN de caja incorrecto" + (" (el PIN quedó apagado en esta computadora)" if u is not None and u.pin_fallos >= PIN_MAX_FALLOS else ""),
                u, request=request, correo=correo[:254])
        raise HTTPException(401, "Correo o PIN incorrectos")
    if u.bloqueado:
        auditar(s, "login_rechazado", "Cuenta bloqueada por el administrador", u, request=request)   # 4.25 (9b, U8): también con el PIN
        raise HTTPException(403, "Su cuenta está bloqueada. Contacte al administrador del sistema.")
    if getattr(u, "temporal_nube", False):                               # 4.25 (Q3): contraseña temporal en la web: tampoco con PIN
        raise HTTPException(403, _sinc.MENSAJES_INGRESO["temporal"])
    membresias = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()
    dos_pasos_web = bool(getattr(u, "mfa_nube", None) or getattr(u, "mfa_entrar_nube", False))   # 4.25: los de la web (según la ficha) cuentan igual
    if u.es_superadmin or u.mfa_activo or dos_pasos_web or not membresias or not all(solo_pos(permisos_de_rol(s, m.empresa_id, m.rol)) for m in membresias):
        raise HTTPException(403, "El PIN es solo para usuarios de caja: entre con su contraseña")
    _limpiar_fallos_login(s, correo, por_conexion, cuenta=False)
    if sin_ficha:                                                        # 4.25 (Q4): sin respuesta de la web, la sesión queda marcada
        return _entrar(s, u, request, response, sin_nube=True,
                       detalle="PIN de caja: sin confirmar con la web, validado con lo guardado en esta computadora")
    return _entrar(s, u, request, response)


class MfaLoginIn(BaseModel):
    token_mfa: str
    codigo: str


def validar_segundo_factor(s: Session, request: Request | None, token_mfa: str, codigo: str, *, tipo: str = "mfa",
                           sujeto: str | None = None, atado: dict | None = None) -> "Usuario":
    """4.25: el segundo paso del ingreso (lo que hacía la ruta /mfa/verificar hasta el código bueno). Devuelve al usuario o lanza el mismo
    HTTPException de siempre. Con los valores por omisión es exactamente el de la web. Para otras rutas:
    - tipo: el tipo que debe traer el token firmado (un token de otro tipo no sirve: el de la web no vale en otra ruta ni al revés).
    - sujeto: reemplaza a la conexión de internet en el tope general («mfa»).
    - atado: datos que el token debe traer iguales (p. ej. la instalación que lo pidió); si falta o no coincide alguno, no sirve.
    Los códigos fallidos cuentan en la cuenta de la persona (mfa_fallidos y su espera), igual que en la web."""
    limitar_ip(request, clave_contador("mfa", sujeto), sujeto=sujeto)     # 4.25: con sujeto, la clave propia «mfa_prog»
    datos = abrir(token_mfa or "")
    if not datos or datos.get("tipo") != tipo or any(k not in datos or datos.get(k) != v for k, v in (atado or {}).items()):
        raise HTTPException(401, "El tiempo para el segundo factor expiró; inicie sesión de nuevo")
    u = s.get(Usuario, datos["uid"])
    if not u or not u.mfa_activo:
        raise HTTPException(401, "Código de verificación incorrecto")
    ahora = datetime.now(timezone.utc)
    if u.bloqueado_hasta and u.bloqueado_hasta.replace(tzinfo=timezone.utc) > ahora:
        restante = int((u.bloqueado_hasta.replace(tzinfo=timezone.utc) - ahora).total_seconds() // 60) + 1
        raise HTTPException(429, f"Demasiados códigos incorrectos. Intente de nuevo en {restante} minutos.")
    codigo = (codigo or "").replace(" ", "").strip()
    intervalo = int(time.time() // 30)
    ultimo = (u.mfa_ultimo or "").split(":")                        # "intervalo:código" del último aceptado
    if codigo and len(ultimo) == 2 and ultimo[1] == codigo and intervalo - int(ultimo[0] or 0) <= 2:   # vale una sola vez en su ventana
        auditar(s, "mfa_fallido", "Código MFA ya usado", u, request=request)
        raise HTTPException(401, "Ese código ya se usó; espere el siguiente")
    if verificar_totp(u.mfa_secret, codigo):
        u.mfa_ultimo = f"{intervalo}:{codigo}"
    elif usar_respaldo(u, codigo):
        auditar(s, "mfa_respaldo_usado", f"Quedan {len(json.loads(u.mfa_respaldo))} códigos de respaldo", u, request=request)
    else:
        u.mfa_fallidos = (u.mfa_fallidos or 0) + 1
        if u.mfa_fallidos >= MAX_INTENTOS:                         # 5 códigos malos: bloqueo temporal como en el login
            u.bloqueado_hasta = ahora + timedelta(minutes=MINUTOS_BLOQUEO); u.mfa_fallidos = 0
        s.add(u); s.commit()
        auditar(s, "mfa_fallido", "Código MFA incorrecto", u, request=request)
        raise HTTPException(401, "Código de verificación incorrecto")
    u.mfa_fallidos = 0
    s.add(u); s.commit()
    return u


@router.post("/mfa/verificar")
def mfa_verificar(data: MfaLoginIn, request: Request, response: Response, s: Session = Depends(get_session)):
    if dos_pasos_nube is not None:                 # 4.25 (programa local): el segundo paso de un ingreso que validó la web
        datos = abrir(data.token_mfa or "")
        if datos and datos.get("tipo") == TIPO_MFA_NUBE:
            limitar_ip(request, "mfa")             # el tope local por conexión vale igual
            return dos_pasos_nube(s, request, response, datos, data.codigo)
    u = validar_segundo_factor(s, request, data.token_mfa, data.codigo)
    # 4.25 (programa local): el segundo paso de ESTA computadora tras validar la contraseña con lo guardado (sinc._con_lo_guardado): la
    # sesión queda marcada sin_nube, con su detalle en la auditoría. En la web el token «mfa» no trae esa marca y nada cambia.
    guardado = (abrir(data.token_mfa or "") or {}) if ingreso_nube is not None else {}
    if guardado.get("sin_nube") is True:
        return _entrar(s, u, request, response, sin_nube=True, detalle=str(guardado.get("detalle") or "")[:300] or None)
    return _entrar(s, u, request, response)


@router.get("/yo")
def yo(request: Request, response: Response, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None),
       s: Session = Depends(get_session)):
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    return _respuesta(s, u, datos.get("eid"), request, response, sid=datos["sid"])


@router.post("/salir")
def salir(request: Request, response: Response, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None),
          s: Session = Depends(get_session)):
    """Cierra la sesión en el servidor (el token deja de valer aunque alguien lo haya copiado).
    4.25 (7b, T1): revoca SIEMPRE la sesión del token, sin pasar por la revisión de cuenta retirada (que en «no se sabe» contesta 503 y
    dejaba la sesión viva). La auditoría va después y se omite si no se puede saber quién es."""
    try:
        datos = _datos_token(authorization, facturacr_token, request, s)
    except HTTPException:
        datos = None
    if datos:
        ses = datos["_sesion"]; ses.revocada = True; s.add(ses); s.commit()
        u = s.get(Usuario, datos.get("uid"))
        if getattr(ses, "suplantada_por", None):                   # 4.35: cerrar la sesión de soporte es salir de ella
            propia = s.get(Sesion, ses.suplantada_vuelve) if ses.suplantada_vuelve else None
            if propia is not None and propia.usuario_id == ses.suplantada_por and not propia.revocada:
                propia.revocada = True; s.add(propia); s.commit()  # y de la del administrador: su token ya no está en este navegador
            _auditar_salida_soporte(s, ses, u, datos.get("eid"), request, "cerró la sesión de soporte")
        elif u is not None:
            auditar(s, "logout", None, u, datos.get("eid"), request)
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


def _auditar_salida_soporte(s: Session, ses: "Sesion", u, eid, request: Request | None, que: str) -> None:
    """4.35: «soporte_salio» en la empresa (la ve su Auditoría) y en el registro del sistema."""
    a = s.get(Usuario, ses.suplantada_por)
    quien = a.correo if a else f"administrador del sistema #{ses.suplantada_por}"
    como = u.correo if u else f"usuario #{ses.usuario_id}"
    if eid:
        auditar(s, "soporte_salio", f"{quien} {que} como {como}", a, eid, request, correo=quien)
    e = s.get(Empresa, eid) if eid else None
    auditar(s, "soporte_salio", f"{quien} {que} como {como}" + (f" en la empresa {eid} ({e.nombre_comercial or e.nombre})" if e else ""),
            a, None, request, correo=quien)


@router.post("/volver", dependencies=[Depends(solo_web)])
def volver_de_soporte(request: Request, response: Response, authorization: str | None = Header(default=None),
                      facturacr_token: str | None = Cookie(default=None), s: Session = Depends(get_session)):
    """4.35: «Volver a mi cuenta» desde una sesión de soporte («Entrar como»): la cierra y devuelve al administrador del sistema su propia
    sesión (la que tenía al entrar: Sesion.suplantada_vuelve) si sigue abierta, sin pedirle nada; si no, la pantalla de entrar. Como en
    /salir, no pasa por _autenticar: se puede volver aunque mientras tanto bloquearan a la persona."""
    datos = _datos_token(authorization, facturacr_token, request, s)
    ses = datos["_sesion"]
    if not getattr(ses, "suplantada_por", None):
        raise HTTPException(400, "Esta sesión no es de soporte: no hay otra cuenta a la cual volver")
    ses.revocada = True; s.add(ses); s.commit()
    _auditar_salida_soporte(s, ses, s.get(Usuario, ses.usuario_id), datos.get("eid"), request, "volvió a su cuenta; había entrado")
    a = s.get(Usuario, ses.suplantada_por)
    propia = s.get(Sesion, ses.suplantada_vuelve) if ses.suplantada_vuelve else None
    ahora = datetime.now(timezone.utc)
    # su sesión vale si sigue abierta y dentro de las 12 horas; la inactividad no cuenta: mientras tanto trabajó en la de soporte
    if (a is not None and a.es_superadmin and not a.bloqueado and propia is not None and not propia.revocada and propia.usuario_id == a.id
            and not propia.suplantada_por and (ahora - propia.creada.replace(tzinfo=timezone.utc)).total_seconds() <= DURACION_SESION):
        propia.ultimo_uso = ahora; s.add(propia); s.commit()
        return {**_respuesta(s, a, None, request, response, sid=propia.sid), "volvio": True}
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True, "volvio": False, "mensaje": "Su sesión de administrador ya se cerró: entre de nuevo con su cuenta."}


@router.post("/salir-todas")
def salir_todas(request: Request, response: Response, authorization: str | None = Header(default=None),
                facturacr_token: str | None = Cookie(default=None), s: Session = Depends(get_session)):
    """Cierra todas las sesiones del usuario en cualquier dispositivo, incluida la actual."""
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    _revocar_sesiones(s, u.id)
    auditar(s, "logout_todas", None, u, datos.get("eid"), request)
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


@router.get("/sesiones")
def sesiones(request: Request, authorization: str | None = Header(default=None), facturacr_token: str | None = Cookie(default=None),
             s: Session = Depends(get_session)):
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    rows = s.exec(select(Sesion).where(Sesion.usuario_id == u.id, Sesion.revocada == False).order_by(Sesion.ultimo_uso.desc())).all()  # noqa: E712
    return [{"id": r.id, "creada": r.creada.isoformat(), "ultimo_uso": r.ultimo_uso.isoformat(), "ip": r.ip, "agente": r.agente,
             "actual": r.sid == datos["sid"]} for r in rows]


class SeleccionIn(BaseModel):
    empresa_id: int


@router.post("/empresa")
def seleccionar_empresa(data: SeleccionIn, request: Request, response: Response, authorization: str | None = Header(default=None),
                        facturacr_token: str | None = Cookie(default=None), s: Session = Depends(get_session)):
    """Cambia la empresa activa: solo a las que el usuario tiene autorizadas explícitamente."""
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    if u.es_superadmin and admin_ve_empresa(u, data.empresa_id) and s.get(Empresa, data.empresa_id) is None:
        raise HTTPException(404, "Empresa no encontrada")      # 3.87: antes abría (y creaba como archivo) una empresa que no existe
    # 3.87: para un administrador del sistema una empresa oculta no se abre aunque sea miembro (lo decide el super administrador)
    if not (admin_ve_empresa(u, data.empresa_id) if u.es_superadmin else s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == data.empresa_id)).first()):
        auditar(s, "acceso_denegado", f"Intento de entrar a la empresa {data.empresa_id} sin autorización", u, data.empresa_id, request)
        raise HTTPException(403, "No tiene acceso a esa empresa")
    auditar(s, "cambio_empresa", None, u, data.empresa_id, request)
    return _respuesta(s, u, data.empresa_id, request, response, sid=datos["sid"])


class CambioPassIn(BaseModel):
    actual: str
    nueva: str


@router.post("/password")
def cambiar_password(data: CambioPassIn, request: Request, response: Response, authorization: str | None = Header(default=None),
                     facturacr_token: str | None = Cookie(default=None), s: Session = Depends(get_session)):
    u, datos = _autenticar(request, authorization, facturacr_token, s)
    if _es_local() and u.de_nube and (_local_cerrado() or not u.debe_cambiar_password):   # etapa 1: aquí la pisaría la siguiente bajada; 4.12: si un administrador local le exigió cambiarla, se deja (4.25, tanda 6: solo en modo soporte)
        raise HTTPException(400, "Su contraseña la administra la nube: cámbiela en la página web y llega a esta computadora al sincronizar")
    if not verificar_password(data.actual, u.password_hash):
        raise HTTPException(400, "La contraseña actual no coincide")
    validar_password(data.nueva, u.correo, anterior=data.actual)
    marcado = _dispositivo_de(request, u) is not None
    u.password_hash, u.debe_cambiar_password = hash_password(data.nueva), False
    s.add(u); s.commit()
    _revocar_sesiones(s, u.id, excepto_sid=datos["sid"])      # cierra las sesiones en otros dispositivos
    if marcado:
        _marcar_dispositivo(request, response, u)          # 3.87: este dispositivo sigue conocido; las marcas copiadas en otros ya no valen
    auditar(s, "cambio_password", None, u, request=request)
    return {"ok": True}


class ReenrolarIn(BaseModel):
    password: Optional[str] = None
    codigo: Optional[str] = None


@router.post("/mfa/activar")
def mfa_activar(data: Optional[ReenrolarIn] = Body(None), u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    _solo_en_web(u)                                 # 4.25: quien viene de la nube los administra en la web
    if u.mfa_activo:                                # ya hay MFA: cambiar de teléfono exige la contraseña actual y un código vigente (R124)
        if not data or not data.password or not _verificar_lento(data.password, u.password_hash):
            raise HTTPException(401, "Para cambiar la verificación en dos pasos indique su contraseña actual")
        if not (verificar_totp(u.mfa_secret, data.codigo or "") or usar_respaldo(u, (data.codigo or "").strip())):
            raise HTTPException(401, "Indique un código vigente de su aplicación (o un código de respaldo) para cambiar de teléfono")
    secreto = nuevo_secreto()
    u.mfa_pendiente = _cifrar_mfa(secreto); s.add(u); s.commit()     # cifrado en la base; en claro solo para el QR (R288)
    url = otpauth_url(secreto, u.correo)
    return {"secreto": secreto, "otpauth": url, "qr": qr_png_base64(url)}


class CodigoIn(BaseModel):
    codigo: str


@router.post("/mfa/confirmar")
def mfa_confirmar(data: CodigoIn, request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    _solo_en_web(u)
    if not u.mfa_pendiente or not verificar_totp(u.mfa_pendiente, data.codigo):
        raise HTTPException(400, "Código incorrecto; revise la hora del teléfono e intente de nuevo")
    u.mfa_secret, u.mfa_pendiente, u.mfa_activo = u.mfa_pendiente, None, True
    renuncia = u.mfa_renuncia_version
    _borrar_renuncia(u)                             # 4.7: al activar la verificación, la renuncia queda sin efecto
    respaldo = generar_respaldo(u)
    s.add(u); s.commit()
    auditar(s, "mfa_activado", f"La renuncia a la verificación en dos pasos (versión {renuncia}) quedó sin efecto" if renuncia else None, u, request=request)
    return {"ok": True, "mfa_activo": True, "respaldo": respaldo}


@router.post("/mfa/respaldo")
def mfa_nuevo_respaldo(data: CodigoIn, request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    """Genera códigos de respaldo nuevos (invalida los anteriores); requiere el código actual de la aplicación."""
    _solo_en_web(u)
    if not u.mfa_activo or not verificar_totp(u.mfa_secret, data.codigo):
        raise HTTPException(400, "Código incorrecto")
    respaldo = generar_respaldo(u)
    s.add(u); s.commit()
    auditar(s, "mfa_respaldo_regenerado", None, u, request=request)
    return {"ok": True, "respaldo": respaldo}


@router.post("/mfa/desactivar")
def mfa_desactivar(data: CodigoIn, request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    _solo_en_web(u)
    if not u.mfa_activo or not verificar_totp(u.mfa_secret, data.codigo):
        raise HTTPException(400, "Código incorrecto")
    if mfa_exigida(s, u):                           # 4.7: con una renuncia vigente que valga sí se puede desactivar
        raise HTTPException(400, "La verificación en dos pasos es obligatoria para administradores y no puede desactivarse")
    u.mfa_secret, u.mfa_activo, u.mfa_respaldo = None, False, None
    s.add(u); s.commit()
    auditar(s, "mfa_desactivado", None, u, request=request)
    return {"ok": True, "mfa_activo": False}


# ----------------------------------------------------------------------------- renuncia a la verificación: Mi perfil (4.7)
def texto_renuncia_mfa() -> list:
    """Párrafos del descargo tal como se publica (app/static/renuncia-mfa.html, sin etiquetas, estilos ni comentarios; las viñetas
    con «• »). La constancia por correo lleva exactamente este texto y la auditoría su huella."""
    from html.parser import HTMLParser

    class _Texto(HTMLParser):
        BLOQUES = {"h1", "h2", "h3", "p", "li", "div", "ul", "ol", "br"}
        FUERA = {"head", "style", "script", "title"}

        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.partes, self.actual, self.saltar = [], [], 0

        def cortar(self):
            t = " ".join("".join(self.actual).split())
            self.actual = []
            if t and t != "•":
                self.partes.append(t)

        def handle_starttag(self, tag, attrs):
            if tag in self.FUERA:
                self.saltar += 1
            elif tag in self.BLOQUES:
                self.cortar()
                if tag == "li":
                    self.actual.append("• ")

        def handle_endtag(self, tag):
            if tag in self.FUERA:
                self.saltar = max(0, self.saltar - 1)
            elif tag in self.BLOQUES:
                self.cortar()

        def handle_data(self, data):
            if not self.saltar:
                self.actual.append(data)

    try:
        with open(_RENUNCIA_HTML, encoding="utf-8") as f:
            fuente = f.read()
    except OSError:
        return []
    lector = _Texto()
    lector.feed(fuente)
    lector.close()
    lector.cortar()
    return lector.partes


def _empresas_renuncia(s: Session, u: "Usuario") -> list:
    """Empresas donde el usuario necesita la verificación: por su rol (se pide al entrar: motivo «rol») o para Recursos humanos
    (motivo «rrhh»), con la política «sin excepción» de cada una."""
    out = []
    if u.es_superadmin:
        return out
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all():
        e = s.get(Empresa, m.empresa_id)
        if e is None:
            continue
        al_entrar = rol_exige_mfa(s, e.id, m.rol)
        if al_entrar or "rrhh" in _permisos_plan(s, u, e.id, m.rol):
            out.append({"id": e.id, "nombre": e.nombre_comercial or e.nombre, "rol": m.rol, "motivo": "rol" if al_entrar else "rrhh",
                        "sin_excepcion": bool(getattr(e, "mfa_sin_excepcion", False))})
    return out


def estado_renuncia(s: Session, u: "Usuario") -> dict:
    """(4.7) Lo que Mi perfil y la pantalla de la verificación necesitan para ofrecer la renuncia, o decir por qué no se puede."""
    interruptor = renuncia_mfa_permitida()
    empresas = _empresas_renuncia(s, u)
    estrictas = [x["nombre"] for x in empresas if x["sin_excepcion"] and x["motivo"] == "rol"]
    motivo = None
    if u.es_superadmin:
        motivo = "El administrador del sistema siempre usa la verificación en dos pasos: no puede renunciar a ella."
    elif not interruptor:
        motivo = "La renuncia a la verificación en dos pasos no está disponible: actívela en Mi perfil."
    elif not empresas:
        motivo = "Su cuenta no necesita la verificación en dos pasos: no hay nada que aceptar."
    elif estrictas:
        motivo = ((f"La empresa {estrictas[0]} exige" if len(estrictas) == 1 else f"Las empresas {', '.join(estrictas)} exigen")
                  + " la verificación en dos pasos sin excepción para su rol: actívela en Mi perfil.")
    elif all(x["sin_excepcion"] for x in empresas):
        motivo = "Sus empresas exigen la verificación en dos pasos sin excepción: actívela en Mi perfil."
    version, fecha = u.mfa_renuncia_version, u.mfa_renuncia_fecha
    return {"permitida": motivo is None, "motivo": motivo, "aplica": bool(empresas), "interruptor": interruptor,
            "requiere_cambiar_password": bool(u.debe_cambiar_password), "mfa_activo": bool(u.mfa_activo),
            "version": RENUNCIA_MFA_VERSION, "url": RENUNCIA_MFA_URL, "palabra": RENUNCIA_MFA_PALABRA,
            "aceptada": bool(version), "version_aceptada": version, "fecha": _fecha_iso(fecha),
            "vigente": renuncia_mfa_vigente(u, interruptor), "desactualizada": bool(version) and version != RENUNCIA_MFA_VERSION,
            "empresas": empresas, "empresas_sin_excepcion": [x["nombre"] for x in empresas if x["sin_excepcion"]]}


def _enviar_constancia_renuncia(s: Session, u: "Usuario", texto: list, ip: str | None, agente: str | None, huella: str) -> bool:
    """Copia del descargo aceptado al correo del usuario, como constancia (correo de la plataforma, como la recuperación de la
    contraseña). False si no hay con qué enviarlo; el envío va en un hilo y, si falla, queda en la auditoría."""
    cfg = _cfg_smtp_plataforma(s, u)
    if not cfg:
        auditar(s, "mfa_renuncia_sin_correo", "No hay correo de la plataforma para enviar la constancia de la renuncia", u)
        return False
    from . import correo as _correo
    from . import correo_diseno as _dz
    from .config import ahora_cr
    cuando = ahora_cr().strftime("%d/%m/%Y %H:%M") + " (hora de Costa Rica)"
    destino, nombre = u.correo, u.nombre          # valores sueltos: el hilo no toca la instancia de la base
    asunto = f"{nombre_sistema()}: constancia de su renuncia a la verificación en dos pasos"
    intro = (f"Usted aceptó el descargo para no usar la verificación en dos pasos en su cuenta de {nombre_sistema()}. Le enviamos una copia "
             "del texto aceptado como constancia: guárdela.")
    aviso = ("Puede retirar la renuncia o activar la verificación en dos pasos cuando quiera desde Mi perfil. Si usted no hizo esta "
             "aceptación, cambie su contraseña de inmediato y avise al administrador de su empresa.")
    datos = [("Cuenta", destino), ("Fecha", cuando), ("Versión del texto", RENUNCIA_MFA_VERSION), ("Dirección IP", ip or "desconocida"),
             ("Navegador", agente or "desconocido"), ("Huella del texto (SHA-256)", huella)]
    html = _dz.armar(_dz.plataforma(), titulo="Constancia de su renuncia a la verificación en dos pasos", asunto=asunto,
                     preencabezado=f"Aceptada el {cuando}.", saludo=f"Hola {nombre},", parrafos_txt=[intro],
                     aviso=aviso, aviso_tono="ambar", datos=datos, despues=["**Texto aceptado**"] + list(texto))
    plano = (f"Hola {nombre},\n\n{intro}\n\n" + "\n".join(f"{k}: {v}" for k, v in datos) + f"\n\n{aviso}\n\nTEXTO ACEPTADO\n\n"
             + "\n\n".join(texto) + f"\n\n{nombre_sistema()}")

    def _enviar():
        try:
            _correo.enviar(cfg, [destino], asunto, html, plano, [])
        except Exception as ex:  # noqa: BLE001
            try:
                with Session(engine) as sc:
                    auditar(sc, "mfa_renuncia_correo_fallido", f"{destino}: {str(ex)[:150]}", None, request=None, correo=destino)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=_enviar, daemon=True).start()
    return True


class RenunciaMfaIn(BaseModel):
    acepta: bool = False                         # casilla «Leí y acepto el descargo»
    asume_responsabilidad: bool = False          # casilla «Asumo la responsabilidad»: las dos son obligatorias
    version: str = ""                            # la versión del texto que la persona leyó (RENUNCIA_MFA_VERSION)
    password: str = Field("", max_length=1024)   # su contraseña actual (completa: se verifica sin recortar)
    confirmacion: str = ""                       # la palabra ACEPTO


@router.get("/mfa/renuncia")
def ver_renuncia_mfa(u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    """(4.7) Estado de la renuncia del usuario: si puede aceptarla (y por qué no), el texto vigente y lo que ya aceptó."""
    return estado_renuncia(s, u)


@router.post("/mfa/renuncia")
def aceptar_renuncia_mfa(data: RenunciaMfaIn, request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    """(4.7) El usuario declina la verificación en dos pasos: leyó el descargo, marcó las dos casillas y escribe su contraseña y ACEPTO.
    Solo para sí mismo (su propia sesión: un token de API no llega aquí) y nunca el administrador del sistema."""
    _solo_en_web(u)                                 # 4.25: en el programa, quien viene de la nube la acepta en la web
    limitar_ip(request, "renuncia")
    aviso_espera = "Demasiadas contraseñas incorrectas. Espere unos minutos e intente de nuevo."
    limitar_ip(request, "renuncia_fallo", MAX_INTENTOS, MINUTOS_BLOQUEO * 60, aviso_espera, sujeto=f"u{u.id}", registrar=False)
    if u.es_superadmin:
        raise HTTPException(403, "El administrador del sistema siempre usa la verificación en dos pasos: no puede renunciar a ella")
    estado = estado_renuncia(s, u)
    if not estado["permitida"]:
        raise HTTPException(403, {"codigo": "renuncia_no_permitida", "mensaje": estado["motivo"]})
    if u.debe_cambiar_password:                    # la contraseña temporal la conoce quien la creó: la aceptación debe ser personal
        raise HTTPException(403, {"codigo": "cambiar_password", "mensaje": "Antes de aceptar el descargo cambie su contraseña temporal por una que solo usted conozca"})
    if (data.version or "").strip() != RENUNCIA_MFA_VERSION:
        raise HTTPException(409, {"codigo": "renuncia_version", "mensaje": "El texto del descargo cambió: léalo de nuevo antes de aceptarlo",
                                  "version": RENUNCIA_MFA_VERSION})
    if not (data.acepta and data.asume_responsabilidad):
        raise HTTPException(400, "Marque las dos casillas: que leyó y acepta el descargo y que asume la responsabilidad")
    if " ".join((data.confirmacion or "").split()).upper() != RENUNCIA_MFA_PALABRA:
        raise HTTPException(400, f"Escriba la palabra {RENUNCIA_MFA_PALABRA} para confirmar")
    texto = texto_renuncia_mfa()
    if not texto or not any(RENUNCIA_MFA_VERSION in t for t in texto):
        raise HTTPException(503, "El texto del descargo no está disponible en este momento; intente más tarde")
    hash_leido = u.password_hash
    if not _verificar_lento(data.password or "", hash_leido):
        limitar_ip(request, "renuncia_fallo", MAX_INTENTOS, MINUTOS_BLOQUEO * 60, aviso_espera, sujeto=f"u{u.id}")
        auditar(s, "mfa_renuncia_fallida", "Contraseña incorrecta al aceptar el descargo de la verificación en dos pasos", u, request=request)
        raise HTTPException(400, "La contraseña no coincide")
    s.refresh(u)
    if u.password_hash != hash_leido or u.bloqueado:              # revisión: la cuenta se restableció o bloqueó mientras tanto
        raise HTTPException(409, "Su cuenta cambió mientras confirmaba (contraseña restablecida o bloqueo): vuelva a iniciar sesión")
    ip = (_ip(request) or "")[:64] or None
    agente = (request.headers.get("user-agent") or "")[:300] or None
    u.mfa_renuncia_version, u.mfa_renuncia_fecha = RENUNCIA_MFA_VERSION, datetime.now(timezone.utc)
    u.mfa_renuncia_ip, u.mfa_renuncia_agente = ip, agente
    s.add(u); s.commit(); s.refresh(u)
    huella = hashlib.sha256("\n".join(texto).encode("utf-8")).hexdigest()
    auditar(s, "mfa_renuncia_aceptada", f"versión {RENUNCIA_MFA_VERSION}; IP {ip or 'desconocida'}; navegador {(agente or 'desconocido')[:160]}; "
            f"texto sha256 {huella[:16]}", u, request=request)
    for x in estado["empresas"]:                   # también en la auditoría de cada empresa donde la necesitaba (solo la ve quien tiene «usuarios»)
        auditar(s, "mfa_renuncia_aceptada", f"{u.correo} aceptó la renuncia a la verificación en dos pasos (versión {RENUNCIA_MFA_VERSION})",
                u, x["id"], request)
    enviado = _enviar_constancia_renuncia(s, u, texto, ip, agente, huella)
    return {"ok": True, "correo": enviado, **estado_renuncia(s, u)}


@router.delete("/mfa/renuncia")
def retirar_renuncia_mfa(request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    """(4.7) El usuario retira su renuncia: la verificación en dos pasos se le pide otra vez (al entrar si su rol la exige, o para
    Recursos humanos)."""
    _solo_en_web(u)
    if u.mfa_renuncia_version or u.mfa_renuncia_fecha:
        anterior = u.mfa_renuncia_version
        _borrar_renuncia(u)
        s.add(u); s.commit(); s.refresh(u)
        auditar(s, "mfa_renuncia_retirada", f"versión {anterior or '—'}; desde Mi perfil", u, request=request)
    return {"ok": True, **estado_renuncia(s, u), "mfa_pendiente": (not u.mfa_activo) and mfa_exigida(s, u)}


# ----------------------------------------------------------------------------- política de la empresa (Configuración › Usuarios) (4.7)
class PoliticaMfaIn(BaseModel):
    sin_excepcion: bool


def _politica_mfa(s: Session, e: Empresa) -> dict:
    interruptor = renuncia_mfa_permitida()
    filas = []
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == e.id)).all():
        x = s.get(Usuario, m.usuario_id)
        r = _renuncia_fila(s, x, e.id, interruptor) if x else None
        if r:
            filas.append({"id": x.id, "correo": x.correo, "nombre": x.nombre, "rol": m.rol, "mfa_activo": bool(x.mfa_activo), **r})
    return {"sin_excepcion": bool(getattr(e, "mfa_sin_excepcion", False)), "renuncia_permitida": interruptor, "version": RENUNCIA_MFA_VERSION,
            "url": RENUNCIA_MFA_URL, "renuncias": sorted(filas, key=lambda f: (f["correo"] or "").lower())}


@router.get("/mfa/politica")
def ver_politica_mfa(ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    """(4.7) Política de la empresa activa sobre la verificación en dos pasos y quién de sus usuarios renunció a ella."""
    return _politica_mfa(s, s.get(Empresa, ctx.empresa.id))


@router.put("/mfa/politica", dependencies=[Depends(solo_web)])
def guardar_politica_mfa(data: PoliticaMfaIn, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    """(4.7) «Exigir la verificación en dos pasos sin excepción»: encendida, la renuncia no vale en esta empresa para los roles que la
    exigen ni para Recursos humanos. Vale de inmediato (cada petición lo revisa)."""
    if ctx.token_api is not None:
        raise HTTPException(403, "Un token de API no cambia la política de la verificación en dos pasos")
    e = s.get(Empresa, ctx.empresa.id)
    if data.sin_excepcion and not ctx.usuario.mfa_activo and not ctx.usuario.es_superadmin:
        raise HTTPException(400, "Active primero su propia verificación en dos pasos en Mi perfil: con esta política usted también la necesitará")
    antes = bool(getattr(e, "mfa_sin_excepcion", False))
    e.mfa_sin_excepcion = bool(data.sin_excepcion)
    s.add(e); s.commit(); s.refresh(e)
    out = _politica_mfa(s, e)
    afectados = [f["correo"] for f in out["renuncias"] if f["vigente"] and not f["mfa_activo"]] if e.mfa_sin_excepcion else []
    if antes != e.mfa_sin_excepcion:
        auditar(s, "mfa_politica_empresa", ("Verificación en dos pasos sin excepción: ENCENDIDA" if e.mfa_sin_excepcion else
                                            "Verificación en dos pasos sin excepción: apagada (vale la renuncia aceptada)")
                + (f"; {len(afectados)} usuario(s) deberán activarla" if afectados else ""), ctx.usuario, e.id, ctx.request)   # revisión: sin correos
    return {**out, "afectados": afectados}


# Usuarios de la empresa (el administrador de la empresa gestiona su equipo)
class InvitacionIn(BaseModel):
    correo: str
    nombre: str
    rol: str = "Vendedor"
    password_temporal: str


@router.get("/usuarios")
def usuarios_empresa(ctx: Contexto = Depends(contexto), s: Session = Depends(get_session)):
    """Usuarios de la empresa activa. 3.87: completo (correo, rol, dos pasos, bloqueo, último acceso) solo con 'usuarios'; los demás
    roles reciben id y nombre (responsables de Mis tareas); la caja (solo pos) y los tokens de API, nada."""
    if ctx.token_api is not None or solo_pos(ctx.permisos):
        raise HTTPException(403, "Su rol no tiene permiso para ver los usuarios de la empresa")
    completo = ctx.puede("usuarios")
    out, completas = [], []
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == ctx.empresa.id)).all():
        u = s.get(Usuario, m.usuario_id)
        if u and not completo:
            out.append({"id": u.id, "nombre": (u.nombre or "").strip() or f"Usuario {u.id}"})   # sin nombre: un rótulo, no el correo
        elif u:
            out.append({"id": u.id, "correo": u.correo, "nombre": u.nombre, "rol": m.rol, "mfa_activo": u.mfa_activo, "bloqueado": u.bloqueado,
                        "sucursal_id": m.sucursal_id, "modulos_ocultos": ocultos_usuario(m), "ultimo_acceso": u.ultimo_acceso.isoformat() if u.ultimo_acceso else None,
                        "mfa_renuncia": _renuncia_fila(s, u, ctx.empresa.id)})      # 4.7: «Sin verificación: renuncia aceptada el …»
            completas.append((out[-1], u, m))
    # 4.35: 🔑 solo donde el servidor deja restablecer (la misma regla que POST /usuarios/{uid}/password). Solo un sí o un no: nada de
    # las otras empresas de la persona. Quién entra a otras empresas sale de UNA consulta para toda la lista.
    otras = _en_otras_empresas(s, [u.id for _, u, _ in completas], ctx.empresa.id)
    for fila, u, m in completas:
        fila["restablecible"] = _no_restablecible(u.id, u, m, ctx.usuario.id, u.id in otras, bool(ctx.soporte)) is None
    _marcar_admins_sistema(s, ctx.usuario, out)
    return out


def _marcar_admins_sistema(s: Session, actor, filas: list) -> None:
    """3.87: la fila de un administrador del sistema miembro queda de solo lectura (rol, módulos, quitar) para quien no es el super
    administrador; cada uno sí cambia la suya. Solo en las filas completas (con rol)."""
    ids = [x["id"] for x in filas if "rol" in x]
    sistema = {u.id for u in s.exec(select(Usuario).where(Usuario.id.in_(ids), Usuario.es_superadmin == True)).all()} if ids else set()  # noqa: E712  # type: ignore[attr-defined]
    principal = None
    for x in filas:
        if "rol" in x:
            x["admin_sistema"] = x["id"] in sistema
            if x["admin_sistema"] and principal is None:
                principal = es_admin_principal(s, actor)
            x["editable"] = not x["admin_sistema"] or x["id"] == getattr(actor, "id", None) or bool(principal)


# 4.35: la cuenta que ya existe al agregarla a una empresa. Al quitar a alguien de una empresa solo se borra su membresía: la cuenta
# (global) queda con su contraseña, su PIN y sus sesiones. Antes, al volver a agregar el mismo correo la contraseña temporal del
# formulario no se aplicaba (existia=True, password_aplica=False) y la persona no podía entrar con ella: «Correo o contraseña
# incorrectos» (401). Ahora la cuenta huérfana (sin ninguna empresa), que no es administrador del sistema ni está bloqueada, se trata
# como nueva; las demás conservan su contraseña y la respuesta dice por qué.
AVISOS_CUENTA_EXISTENTE = {
    "reactivada": "Ese correo ya tenía una cuenta sin acceso a ninguna empresa: quedó con la contraseña temporal y se cerraron sus sesiones anteriores.",
    "otras": ("Ese correo ya entra a otras empresas: se agregó a esta con su contraseña de siempre (la temporal no se aplicó). Si no la "
              "recuerda, puede recuperarla con «¿Olvidó su contraseña?» al entrar."),
    "sistema": "Ese correo es de un administrador del sistema: se agregó con su contraseña de siempre (la temporal no se aplicó).",
    "bloqueada": ("Ese correo ya tenía una cuenta y está bloqueada por el soporte de FISITAAP: se agregó a esta empresa, pero no podrá entrar "
                  "hasta que la desbloqueen. La contraseña temporal no se aplicó."),
    "sin_password": ("Ese correo ya tenía una cuenta sin acceso a ninguna empresa y no se indicó una contraseña inicial: conserva la anterior. "
                     "Si no la recuerda, restablézcala con 🔑."),
    "ajena": ("Ese correo ya tenía una cuenta que no es de esta empresa: se agregó con su contraseña de siempre (la temporal no se aplicó). "
              "Si no la recuerda, puede recuperarla con «¿Olvidó su contraseña?» al entrar."),
}


def _anotar_retiro(s: Session, m) -> None:
    """4.35: al quitarle a alguien su membresía `m`, la cuenta recuerda la empresa si esa membresía era PROPIA (la empresa creó o reactivó
    la cuenta; no traída): solo esa empresa la vuelve a tratar como nueva si queda sin empresas. Quitar una traída no cambia nada (si no,
    cualquier empresa que la agregue y la quite le quitaría ese derecho a la dueña). No hace commit."""
    if getattr(m, "cuenta_traida", False):
        return
    u = s.get(Usuario, m.usuario_id)
    if u is not None:
        u.ultima_empresa_id = m.empresa_id
        s.add(u)


def _huerfana_de(s: Session, u, empresa_id: int) -> bool:
    """4.35: la cuenta huérfana es de esta empresa (la puede tratar como nueva): su última membresía propia fue aquí. Las cuentas que se
    quitaron antes de 4.35 no lo tienen anotado: vale si TODAS las veces que se quitó (auditoría «usuario_retirado») fue de esta empresa."""
    if u.ultima_empresa_id is not None:
        return u.ultima_empresa_id == empresa_id
    filas = s.exec(select(Auditoria.empresa_id).where(Auditoria.accion == "usuario_retirado", Auditoria.detalle == f"usuario {u.id}")).all()
    return bool(filas) and all(x == empresa_id for x in filas)


def _motivo_cuenta_existente(s: Session, u, empresa_id: int | None = None) -> str | None:
    """4.35: None si la cuenta que ya existe se trata como nueva al agregarla a una empresa (no es miembro de NINGUNA empresa, no es
    administrador del sistema y no está bloqueada por el sistema); si no, por qué su contraseña no se toca: «sistema», «bloqueada» u
    «otras». Cuenta cualquier membresía, también la de la empresa a la que se agrega (en la consola, autorizar a quien ya es miembro solo
    le cambia el rol). Con `empresa_id` (Usuarios de una empresa; la consola es de confianza y no lo pasa), la huérfana solo se trata como
    nueva si es de esa empresa (_huerfana_de); si no, «ajena»: un Administrador no le pone contraseña a una cuenta de otra empresa."""
    if u.es_superadmin:
        return "sistema"
    if u.bloqueado:
        return "bloqueada"
    if s.exec(select(UsuarioEmpresa.id).where(UsuarioEmpresa.usuario_id == u.id).limit(1)).first() is not None:
        return "otras"
    if empresa_id is not None and not _huerfana_de(s, u, empresa_id):
        return "ajena"
    return None


def _poner_temporal(s: Session, u, clave: str) -> int:
    """4.35: deja la cuenta con la contraseña temporal `clave` (ya validada con validar_password): debe cambiarla al entrar, sin la espera
    por intentos fallidos, con la renuncia a los dos pasos retirada (la clave la conoce quien la puso: la persona decide de nuevo, como al
    restablecerla en la consola) y con sus sesiones y tokens de API cerrados. No toca la verificación en dos pasos (eso es del soporte, en
    la consola), el PIN ni el bloqueo del sistema. Devuelve cuántos tokens de API se revocaron."""
    u.password_hash, u.debe_cambiar_password = hash_password(clave), True
    _borrar_renuncia(u)
    u.intentos_fallidos, u.bloqueado_hasta = 0, None
    s.add(u); s.commit()
    _limpiar_fallos_login(s, u.correo)
    _revocar_sesiones(s, u.id)
    return _revocar_tokens_api(s, u.id)


def _reactivar_huerfana(s: Session, u, clave: str, nombre: str | None = None) -> int:
    """4.35: la cuenta huérfana que se vuelve a agregar a una empresa se trata como nueva: contraseña temporal (_poner_temporal), sin el PIN
    de caja de antes (lo vuelve a poner en Mi perfil) y con el nombre del formulario. Conserva la verificación en dos pasos (está en el
    teléfono de la persona; la apaga el soporte). Devuelve cuántos tokens de API se revocaron."""
    u.pin_hash, u.pin_fallos = None, 0
    if (nombre or "").strip():
        u.nombre = nombre.strip()
    return _poner_temporal(s, u, clave)


@router.post("/usuarios", dependencies=[Depends(solo_web)])
def invitar_usuario(data: InvitacionIn, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    if not rol_valido(s, ctx.empresa.id, data.rol):
        raise HTTPException(400, "Rol inválido")
    data.rol = rol_canonico(s, ctx.empresa.id, data.rol)               # (R290)
    from . import planes
    planes.verificar_usuarios(s, ctx.empresa, UsuarioEmpresa)          # usuarios incluidos en el plan (3.16)
    correo = validar_correo(data.correo)
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    _exigir_traible(s, ctx.usuario, u, ctx.empresa.id)                # 3.87: también al entrar como soporte
    exigir_caja_para_rol(s, ctx.empresa, data.rol, u=u)               # 3.87: ni un Cajero donde no hay punto de venta
    existia = u is not None
    motivo = None
    if u is not None:
        if s.exec(select(UsuarioEmpresa.id).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == ctx.empresa.id)).first() is not None:
            raise HTTPException(409, "Ese correo ya es usuario de esta empresa: use «Cambiar rol» en la lista")
        motivo = _motivo_cuenta_existente(s, u, ctx.empresa.id)       # 4.35: antes de tocar nada
    if motivo is None:
        validar_password(data.password_temporal, correo)              # 4.35: también para la cuenta huérfana que se trata como nueva
    tokens = 0
    if not u:
        u = Usuario(correo=correo, nombre=data.nombre, password_hash=hash_password(data.password_temporal), debe_cambiar_password=True)
        s.add(u); s.commit(); s.refresh(u)
    elif motivo is None:
        tokens = _reactivar_huerfana(s, u, data.password_temporal, data.nombre)   # 4.35
    # 4.35: traída = la cuenta ya existía y conserva su contraseña: esta empresa no se la restablece (🔑) ni la reactiva al quitarla
    s.add(UsuarioEmpresa(usuario_id=u.id, empresa_id=ctx.empresa.id, rol=data.rol, cuenta_traida=motivo is not None)); s.commit()
    reactivada = existia and motivo is None
    if tokens:
        auditar(s, "token_api_revocado", f"{tokens} token(s) de API de {correo} al volver a agregar su cuenta", ctx.usuario, ctx.empresa.id, ctx.request)
    auditar(s, "usuario_autorizado", f"{correo} como {data.rol}" + ("; la cuenta no tenía empresas: contraseña temporal nueva y sesiones cerradas"
                                                                   if reactivada else ""), ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True, "existia": existia, "password_aplica": motivo is None, "reactivada": reactivada, "motivo": motivo,
            "aviso": AVISOS_CUENTA_EXISTENTE["reactivada" if reactivada else motivo] if existia else None}


@router.delete("/usuarios/{uid}", dependencies=[Depends(solo_web)])
def quitar_usuario(uid: int, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    if uid == ctx.usuario.id:
        raise HTTPException(400, "No puede quitarse a sí mismo")
    _solo_principal_si_admin_sistema(s, ctx.usuario, uid)             # 3.87
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == ctx.empresa.id)).first()
    if m and m.rol == "Administrador":
        _asegurar_otro_administrador(s, ctx.empresa.id, uid)
    if m:
        _anotar_retiro(s, m)                                           # 4.35
        s.delete(m); s.commit()
        auditar(s, "usuario_retirado", f"usuario {uid}", ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True}


class PasswordUsuarioIn(BaseModel):
    password: Optional[str] = None               # 4.35: vacía, la genera el servidor (clave_facil)


MENSAJE_RESTABLECE_SOPORTE = "Esta cuenta también entra a otras empresas: la restablece el soporte de FISITAAP"
MENSAJE_CUENTA_TRAIDA = ("Esta cuenta ya existía cuando se agregó a esta empresa: la persona la recupera con «¿Olvidó su contraseña?» o la "
                         "restablece el soporte de FISITAAP")


def _en_otras_empresas(s: Session, uids: list, empresa_id: int) -> set:
    """4.35: de las cuentas `uids`, las que también son miembros de alguna empresa distinta de `empresa_id`. Una sola consulta agrupada
    para toda la lista de Usuarios (no una por persona); solo ids de las cuentas pedidas, nunca cuáles son esas empresas."""
    if not uids:
        return set()
    return set(s.exec(select(UsuarioEmpresa.usuario_id).where(UsuarioEmpresa.usuario_id.in_(uids),   # type: ignore[attr-defined]
                                                              UsuarioEmpresa.empresa_id != empresa_id).group_by(UsuarioEmpresa.usuario_id)).all())


def _no_restablecible(uid: int, u, m, actor_id: int | None, en_otras: bool, soporte: bool = False) -> tuple[int, str] | None:
    """4.35: LA regla de 🔑 (restablecer_password_usuario) para la cuenta `uid` (`u`, con su membresía `m` en la empresa activa, o None si
    no es de ella): None si quien administra los usuarios de la empresa (`actor_id`) se la puede restablecer; si no, (código HTTP,
    mensaje). `en_otras`: la cuenta también entra a otras empresas (_en_otras_empresas). `soporte`: la petición viene de una sesión de
    «Entrar como» (Contexto.soporte), donde la ruta da 403 (RUTAS_NO_SUPLANTADA). La usan la ruta y la lista de Usuarios (campo
    «restablecible»), para que el botón no aparezca donde el servidor va a decir que no."""
    if soporte:
        return 403, MENSAJE_SUPLANTADA
    if uid == actor_id:
        return 400, "Su propia contraseña se cambia en Mi perfil"
    if u is None or m is None:
        return 404, "Usuario no encontrado en esta empresa"
    if u.es_superadmin:
        return 403, "La contraseña de un administrador del sistema no se restablece desde aquí"
    if en_otras:
        return 409, MENSAJE_RESTABLECE_SOPORTE
    if m.cuenta_traida:                  # 4.35: la trajo de otra empresa con su contraseña: no es suya aunque hoy sea la única
        return 409, MENSAJE_CUENTA_TRAIDA
    if u.bloqueado:
        return 409, "Esta cuenta está bloqueada por el soporte de FISITAAP: pídales que la revisen"
    return None


def _clave_temporal(correo: str) -> str:
    """4.35: contraseña temporal generada en el servidor (clave_facil, azar de secrets) que cumple validar_password para ese correo (una
    palabra de la clave podría coincidir con el nombre del correo: se genera otra)."""
    for _ in range(50):
        clave = clave_facil()
        try:
            validar_password(clave, correo)
            return clave
        except HTTPException:
            continue
    clave = secrets.token_urlsafe(12)
    validar_password(clave, correo)
    return clave


@router.post("/usuarios/{uid}/password", dependencies=[Depends(solo_web)])
def restablecer_password_usuario(uid: int, data: Optional[PasswordUsuarioIn] = Body(default=None), ctx: Contexto = Depends(requiere("usuarios")),
                                 s: Session = Depends(get_session)):
    """4.35: el administrador de la empresa restablece la contraseña de una persona de su equipo (Configuración › Usuarios). Las cuentas
    son globales (una misma cuenta puede entrar a varias empresas), así que solo la de quien es miembro de ESTA empresa y de ninguna otra
    (si no, un administrador de una empresa tomaría una cuenta que entra a otra: 409, la restablece el soporte en la consola) y que no se
    trajo de otra empresa con su contraseña (cuenta_traida: 409 aunque hoy sea la única); nunca la propia (Mi perfil) ni la de un
    administrador del sistema. Contraseña temporal generada aquí o la que escriba el administrador
    (validar_password); se devuelve UNA vez para que se la entregue a la persona, que debe cambiarla al entrar. Cierra sus sesiones y
    tokens de API; NO apaga la verificación en dos pasos (eso es del soporte, en la consola) ni toca el PIN de caja. En el programa
    (solo_web) se hace en la página web."""
    if ctx.token_api is not None:
        raise HTTPException(403, "Un token de API no restablece contraseñas")
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == ctx.empresa.id)).first() if uid != ctx.usuario.id else None
    u = s.get(Usuario, uid) if m else None
    no = _no_restablecible(uid, u, m, ctx.usuario.id, u is not None and uid in _en_otras_empresas(s, [uid], ctx.empresa.id), bool(ctx.soporte))
    if no is not None:
        raise HTTPException(*no)
    escrita = data.password if data is not None and (data.password or "").strip() else None
    if escrita is not None:
        validar_password(escrita, u.correo)
    clave = escrita if escrita is not None else _clave_temporal(u.correo)
    tokens = _poner_temporal(s, u, clave)
    if tokens:
        auditar(s, "token_api_revocado", f"{tokens} token(s) de API de {u.correo} por restablecimiento de contraseña", ctx.usuario, ctx.empresa.id, ctx.request)
    auditar(s, "usuario_password_restablecida", u.correo, ctx.usuario, ctx.empresa.id, ctx.request)   # sin la contraseña
    return {"ok": True, "correo": u.correo, "password": clave, "mfa_activo": bool(u.mfa_activo)}


@router.get("/auditoria")
def auditoria_empresa(limite: int = 200, ctx: Contexto = Depends(contexto), s: Session = Depends(get_session)):
    """Historial de operaciones de la empresa activa (lo ven todos los roles). 4.7: las filas de la verificación en dos pasos (quién
    renunció, la política «sin excepción») solo las ve quien administra los usuarios: a los demás les revelarían qué cuentas con
    privilegios entran solo con la contraseña. 4.21: las de Recursos humanos («rrhh_…»: fichas cambiadas, comprobantes descargados,
    lo pagado y lo eliminado) solo las ve quien tiene ese permiso; llevan nombres de empleados."""
    stmt = select(Auditoria).where(Auditoria.empresa_id == ctx.empresa.id)
    if not ctx.puede("usuarios"):
        stmt = stmt.where(~Auditoria.accion.startswith("mfa_"))
    if not ctx.puede("rrhh"):
        stmt = stmt.where(~Auditoria.accion.startswith("rrhh_"))
    if not (ctx.puede("ver_todo") or ctx.puede("configurar")):   # 4.41: cierre ciego: lo contado y la diferencia de un cierre corregido o borrado, solo para quien ve el corte
        stmt = stmt.where(~Auditoria.accion.startswith("pos_cierre"))
    rows = s.exec(stmt.order_by(Auditoria.id.desc()).limit(limite)).all()
    return [r.model_dump() for r in rows]


# ----------------------------------------------------------------------------- panel de administración del sistema
class CuentaIn(BaseModel):
    medica_activa: bool = False
    correo: str
    password: str
    nombre_empresa: str
    nombre_contacto: Optional[str] = None
    numero_id: Optional[str] = None
    tipo_negocio: str = "facturacion"            # facturacion | comercio | restaurante | hospitalidad | servicios (2.5, 3.51)


class TipoNegocioIn(BaseModel):
    tipo_negocio: str


def _resumen_empresa(s: Session, e: Empresa, actor=None) -> dict:
    from .db import Documento
    usuarios, admins_sistema = [], []
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == e.id)).all():
        u = s.get(Usuario, m.usuario_id)
        if u and u.es_superadmin:            # 3.87: también se muestran (aparte, solo lectura) los administradores del sistema que son miembros
            admins_sistema.append({"id": u.id, "correo": u.correo, "nombre": u.nombre, "rol": m.rol,     # editable: quién puede quitarla
                                   "editable": bool(actor) and (u.id == actor.id or es_admin_principal(s, actor))})
        elif u:
            usuarios.append({"id": u.id, "correo": u.correo, "nombre": u.nombre, "rol": m.rol, "bloqueado": u.bloqueado, "mfa_activo": u.mfa_activo,
                             "ultimo_acceso": u.ultimo_acceso.isoformat() if u.ultimo_acceso else None,
                             "mfa_renuncia": _renuncia_fila(s, u, e.id)})                 # 4.7
    empleados = None
    try:
        with Session(engine_empresa(e.id)) as se:
            n_docs = len(se.exec(select(Documento.id)).all())
            try:                                              # 3.87: aparte, para que un fallo aquí no deje la consola en 0 documentos
                from . import planes
                empleados = planes.empleados_plan(e, se)      # 3.87: empleados activos contra los 15 del extra de Recursos humanos
            except Exception:  # noqa: BLE001
                empleados = None
    except Exception:
        n_docs = 0
    return {"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id, "correo": e.correo,
            "ambiente": e.ambiente, "bloqueada": e.bloqueada, "bloqueo_motivo": e.bloqueo_motivo, "usuarios": usuarios, "admins_sistema": admins_sistema, **_info_empresa(e),
            "medica_heredada": e.medica_activa is None and _medica_habilitada(e),
            "roles": roles_de_empresa(s, e.id),
            "documentos": n_docs, "certificado": bool(e.p12_nombre), "creada": e.creada.isoformat() if e.creada else None,
            "empleados": empleados,
            "base_datos": f"empresas/empresa_{e.id}.db"}


@admin.get("/cuentas")
def admin_cuentas(a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    ocultas = empresas_ocultas_de(a)
    return [_resumen_empresa(s, e, a) for e in s.exec(select(Empresa).order_by(Empresa.id)).all() if e.id not in ocultas]


@admin.post("/cuentas", dependencies=[Depends(solo_web)])
def admin_crear_cuenta(data: CuentaIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Crea la cuenta de un cliente: usuario + empresa (con su base de datos y clave de cifrado propias).
    4.35: con el correo de una cuenta que ya existe, la misma regla que al autorizarla desde la consola (de confianza: no importa de qué
    empresa la quitaron): la huérfana (sin ninguna empresa, no es administrador del sistema ni está bloqueada) se trata como nueva
    (_reactivar_huerfana: la contraseña escrita como temporal, sus sesiones y tokens cerrados, sin el PIN ni la renuncia de antes); las
    demás conservan su contraseña, quedan traídas en la empresa nueva y el aviso dice por qué. (La prueba gratis del sitio,
    demo.crear_prueba, NUNCA le pone contraseña a una cuenta que ya existe.)"""
    correo = validar_correo(data.correo)
    validar_password(data.password, correo)
    if not (data.nombre_empresa or "").strip():
        raise HTTPException(400, "Indique el nombre de la empresa")
    if data.tipo_negocio not in TIPOS_NEGOCIO:          # 4.35: antes de crear o tocar una cuenta (antes quedaba creada aunque diera 400)
        raise HTTPException(400, "Tipo de negocio inválido: facturacion, comercio, restaurante, hospitalidad o servicios")
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    _exigir_traible(s, a, u, None)       # 3.87: con un correo que ya existe, las mismas reglas que al autorizarlo en una empresa
    existia = u is not None
    motivo = _motivo_cuenta_existente(s, u) if u is not None else None     # 4.35: antes de tocar nada
    if not u:
        u = Usuario(correo=correo, nombre=(data.nombre_contacto or data.nombre_empresa).strip(), password_hash=hash_password(data.password),
                    debe_cambiar_password=True)
        s.add(u); s.commit(); s.refresh(u)
    e = crear_empresa(s, data.nombre_empresa.strip(), correo, (data.numero_id or "").strip(), tipo_negocio=data.tipo_negocio,
                      medica_activa=data.medica_activa)
    reactivada, tokens = existia and motivo is None, 0
    if reactivada:
        tokens = _reactivar_huerfana(s, u, data.password, data.nombre_contacto)   # 4.35
    # 4.35: traída = la cuenta ya existía y conserva su contraseña (como al autorizarla en la consola)
    s.add(UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Administrador", cuenta_traida=motivo is not None)); s.commit()
    roles = roles_por_tipo(s, e.id, data.tipo_negocio)
    if tokens:
        auditar(s, "token_api_revocado", f"{tokens} token(s) de API de {correo} al crearle una cuenta nueva", a, request=request)
    auditar(s, "cuenta_creada", f"Empresa '{e.nombre}' ({TIPOS_NEGOCIO[data.tipo_negocio]}) para {correo}" + (f"; roles: {', '.join(roles)}" if roles else "")
            + ("; la cuenta no tenía empresas: contraseña temporal nueva y sesiones cerradas" if reactivada else "")
            + ("; la cuenta ya existía y conserva su contraseña" if motivo else ""), a, e.id, request)
    if reactivada:
        aviso = _aviso_reactivada_consola(u)
    elif motivo:
        aviso = AVISOS_CUENTA_EXISTENTE[motivo]
    else:
        aviso = AVISO_PRIMER_INGRESO
    return {"ok": True, "empresa_id": e.id, "usuario_id": u.id, "aviso": aviso, "existia": existia, "password_aplica": motivo is None,
            "reactivada": reactivada, "motivo": motivo}


# 3.58: lo que le espera al administrador de una cuenta nueva (la consola lo muestra al crearla; antes se enteraba al entrar)
AVISO_PRIMER_INGRESO = ("Al entrar por primera vez, el administrador de la cuenta deberá cambiar la contraseña temporal, activar la verificación en dos pasos "
                        "(obligatoria para administradores: necesita una aplicación de códigos en su celular) y aceptar los términos del servicio.")


def _aviso_reactivada_consola(u) -> str:
    """4.35: «Nueva cuenta» con el correo de una cuenta que había quedado sin empresas: no es su primer ingreso; el aviso dice qué pasó y
    solo lo que de verdad le espera al entrar (la verificación en dos pasos y los términos pueden estar ya hechos)."""
    pasos = ["cambiar la contraseña temporal"]
    if not u.mfa_activo:
        pasos.append("activar la verificación en dos pasos (obligatoria para administradores: necesita una aplicación de códigos en su celular)")
    if terminos_pendientes(u):
        pasos.append("aceptar los términos del servicio")
    return (AVISOS_CUENTA_EXISTENTE["reactivada"] + " Al entrar, el administrador de la cuenta deberá "
            + (", ".join(pasos[:-1]) + " y " + pasos[-1] if len(pasos) > 1 else pasos[0]) + ".")


def _cedula_comparable(v) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", str(v or "")).upper()


@admin.get("/cuentas/cedula")
def admin_cedula_repetida(numero: str = "", a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Otras empresas con la misma cédula (3.58): aviso al crear una cuenta, sin impedirlo (las sucursales son empresas aparte).
    3.87: sin las empresas que este administrador tiene ocultas (antes el aviso le decía su nombre)."""
    n = _cedula_comparable(numero)
    if not n:
        return {"empresas": []}
    ocultas = empresas_ocultas_de(a)
    return {"empresas": [{"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "tipo_negocio": tipo_negocio_de(e)}
                         for e in s.exec(select(Empresa).order_by(Empresa.nombre)).all() if e.id not in ocultas and _cedula_comparable(e.numero_id) == n]}


class FuncionesIn(BaseModel):
    funciones: list[str] = []


@admin.put("/cuentas/{eid}/funciones", dependencies=[Depends(solo_web)])
def admin_funciones(eid: int, data: FuncionesIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Funciones en prueba encendidas solo en esta empresa (3.58)."""
    from . import planes
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    activas = planes.asignar_funciones(e, data.funciones)
    s.add(e); s.commit(); s.refresh(e)
    auditar(s, "funciones_prueba", f"{e.nombre}: {', '.join(activas) or 'ninguna'}", a, eid, request)
    return {"ok": True, "funciones": activas, "plan": planes.info(e)}


class MedicaEmpresaIn(BaseModel):
    activa: bool


@admin.put("/cuentas/{eid}/medica", dependencies=[Depends(solo_web)])
def admin_medica(eid: int, data: MedicaEmpresaIn, request: Request,
                 a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    from .medica_config import habilitada

    s.connection().exec_driver_sql("BEGIN IMMEDIATE")
    e = s.get(Empresa, eid)
    if not e or not admin_ve_empresa(a, eid):
        raise HTTPException(404, "Empresa no encontrada")
    e.medica_activa = data.activa
    roles = roles_por_tipo(s, eid, "medica") if data.activa else []
    auditar(s, "medica_empresa", "Activada" if data.activa else "Desactivada", a, eid, request)
    return {"medica_activa": habilitada(e), "roles_creados": roles}


@admin.post("/cuentas/{eid}/tipo", dependencies=[Depends(solo_web)])
def admin_tipo_negocio(eid: int, data: TipoNegocioIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Cambia el tipo de negocio de una empresa (solo el administrador del sistema). No borra nada: reordena el menú, enciende
    los módulos del tipo y crea sus roles sugeridos si faltan."""
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if data.tipo_negocio not in TIPOS_NEGOCIO:
        raise HTTPException(400, "Tipo de negocio inválido: facturacion, comercio, restaurante, hospitalidad o servicios")
    anterior = tipo_negocio_de(e)
    antes = cajeros_sin_caja(s, e)                                     # 3.87
    e.tipo_negocio = data.tipo_negocio
    # 3.76: lo apagado «por tipo» al crear la empresa (3.70) se recalcula para el tipo nuevo; si no, una empresa creada como
    # Facturación seguía sin punto de venta ni ventas en línea al pasar a Restaurante aunque el plan los incluyera
    from . import planes
    e.modulos_ocultos = json.dumps(planes.ocultos_por_tipo(data.tipo_negocio, prueba=bool(e.es_demo or e.prueba_hasta)))
    s.add(e); s.commit()
    roles = roles_por_tipo(s, e.id, data.tipo_negocio)
    auditar(s, "tipo_negocio", f"{TIPOS_NEGOCIO[anterior]} → {TIPOS_NEGOCIO[data.tipo_negocio]}" + (f"; roles creados: {', '.join(roles)}" if roles else ""), a, e.id, request)
    return {"ok": True, "tipo_negocio": data.tipo_negocio, "roles_creados": roles, "aviso": aviso_cajeros(antes, cajeros_sin_caja(s, e))}   # 3.87


class BloqueoIn(BaseModel):
    bloquear: bool
    motivo: Optional[str] = None


@admin.post("/cuentas/{eid}/bloqueo", dependencies=[Depends(solo_web)])
def admin_bloquear_empresa(eid: int, data: BloqueoIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404)
    e.bloqueada, e.bloqueo_motivo = data.bloquear, (data.motivo if data.bloquear else None)
    s.add(e); s.commit()
    auditar(s, "empresa_bloqueada" if data.bloquear else "empresa_desbloqueada", data.motivo, a, eid, request)
    return {"ok": True, "bloqueada": e.bloqueada}


@admin.post("/usuarios/{uid}/bloqueo", dependencies=[Depends(solo_web)])
def admin_bloquear_usuario(uid: int, data: BloqueoIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    u = s.get(Usuario, uid)
    if not u:
        raise HTTPException(404)
    if u.id == a.id:
        raise HTTPException(400, "No puede bloquearse a sí mismo")
    if u.es_superadmin:
        solo_principal(s, a)                 # 3.80: a un administrador del sistema solo lo bloquea el super administrador
    _exigir_usuario_visible(s, a, uid)       # 3.87: ni a quien pertenece a una empresa que este administrador no ve
    u.bloqueado = data.bloquear
    if not data.bloquear:
        u.intentos_fallidos, u.bloqueado_hasta = 0, None
        _limpiar_fallos_login(s, u.correo)   # 3.87: desbloquear también quita la espera por intentos fallidos
    s.add(u); s.commit()
    if data.bloquear:
        _revocar_sesiones(s, u.id)
        n = _revocar_tokens_api(s, u.id)
        if n:
            auditar(s, "token_api_revocado", f"{n} token(s) de API de {u.correo} por bloqueo", a, request=request)
    auditar(s, "usuario_bloqueado" if data.bloquear else "usuario_desbloqueado", u.correo, a, request=request)
    return {"ok": True, "bloqueado": u.bloqueado}


class PasswordAdminIn(BaseModel):
    password: str


@admin.post("/usuarios/{uid}/password", dependencies=[Depends(solo_web)])
def admin_reset_password(uid: int, data: PasswordAdminIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    u = s.get(Usuario, uid)
    if not u:
        raise HTTPException(404)
    if u.es_superadmin and u.id != a.id:
        solo_principal(s, a)                 # 3.80
    _exigir_usuario_visible(s, a, uid)       # 3.87: antes restablecía la del Administrador de una empresa oculta y entraba a ella
    validar_password(data.password, u.correo)
    u.password_hash, u.debe_cambiar_password, u.mfa_activo, u.mfa_secret, u.mfa_respaldo = hash_password(data.password), True, False, None, None
    _borrar_renuncia(u)                      # 4.7: la persona decide de nuevo (la contraseña temporal la conoce quien la restableció)
    u.intentos_fallidos, u.bloqueado_hasta = 0, None
    _limpiar_fallos_login(s, u.correo)
    s.add(u); s.commit()
    _revocar_sesiones(s, u.id)
    n = _revocar_tokens_api(s, u.id)
    if n:
        auditar(s, "token_api_revocado", f"{n} token(s) de API de {u.correo} por restablecimiento de contraseña", a, request=request)
    auditar(s, "password_restablecida", u.correo, a, request=request)
    return {"ok": True}


class AutorizacionIn(BaseModel):
    correo: str
    rol: str = "Vendedor"
    nombre: Optional[str] = None
    password: Optional[str] = None


@admin.post("/cuentas/{eid}/usuarios", dependencies=[Depends(solo_web)])
def admin_autorizar_usuario(eid: int, data: AutorizacionIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Autoriza explícitamente a un usuario (existente o nuevo) en una empresa."""
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if not rol_valido(s, eid, data.rol):
        raise HTTPException(400, "Rol inválido")
    from . import planes
    planes.verificar_usuarios(s, e, UsuarioEmpresa)
    correo = validar_correo(data.correo)
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    _exigir_traible(s, a, u, eid)          # 3.87: ni otro administrador del sistema ni alguien de una empresa oculta
    m_antes = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first() if u else None
    exigir_caja_para_rol(s, e, rol_canonico(s, eid, data.rol), u=u, m=m_antes)     # 3.87: ni un Cajero donde no hay punto de venta
    existia, motivo, tokens = u is not None, None, 0
    if u is not None:                    # 4.35: la cuenta huérfana (sin ninguna empresa) con contraseña inicial se trata como nueva
        motivo = _motivo_cuenta_existente(s, u)
        if motivo is None and not data.password:
            motivo = "sin_password"
        if motivo is None:
            validar_password(data.password, correo)
    if not u:
        if not data.password:
            raise HTTPException(400, f"El usuario no existe: indique una contraseña inicial de al menos {MIN_PASSWORD} caracteres para crearlo")
        validar_password(data.password, correo)
        u = Usuario(correo=correo, nombre=(data.nombre or correo.split("@")[0]).strip(), password_hash=hash_password(data.password),
                    debe_cambiar_password=True)
        s.add(u); s.commit(); s.refresh(u)
    elif motivo is None:
        tokens = _reactivar_huerfana(s, u, data.password, data.nombre)        # 4.35
    data.rol = rol_canonico(s, eid, data.rol)
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id, UsuarioEmpresa.empresa_id == eid)).first()
    if m:
        if m.rol == "Administrador" and data.rol != "Administrador":
            _asegurar_otro_administrador(s, eid, u.id)                 # (R289)
        m.rol = data.rol
    else:                                # 4.35: traída si conserva la contraseña que ya tenía en otra empresa (la huérfana sin contraseña inicial no)
        m = UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=data.rol, cuenta_traida=motivo in ("otras", "sistema", "bloqueada"))
    s.add(m); s.commit()
    reactivada = existia and motivo is None
    if tokens:
        auditar(s, "token_api_revocado", f"{tokens} token(s) de API de {correo} al volver a autorizar su cuenta", a, request=request)
    auditar(s, "usuario_autorizado", f"{correo} como {data.rol}" + ("; la cuenta no tenía empresas: contraseña inicial nueva y sesiones cerradas"
                                                                   if reactivada else ""), a, eid, request)
    # 4.35: el aviso dice la verdad sobre la contraseña: nueva (huérfana), sin tocar (con su motivo) o nada (cuenta nueva o solo cambio de rol)
    if reactivada:
        aviso = AVISOS_CUENTA_EXISTENTE["reactivada"]
    elif m_antes is not None or motivo is None:
        aviso = None
    elif motivo in ("bloqueada", "sin_password") or data.password:
        aviso = AVISOS_CUENTA_EXISTENTE[motivo]
    else:
        aviso = None
    return {"ok": True, "usuario_id": u.id, "rol": m.rol, "existia": existia, "password_aplica": motivo is None, "reactivada": reactivada,
            "motivo": motivo, "aviso": aviso}


class AdminCambioRolIn(BaseModel):
    rol: str


@admin.put("/cuentas/{eid}/usuarios/{uid}/rol", dependencies=[Depends(solo_web)])
def admin_cambiar_rol(eid: int, uid: int, data: AdminCambioRolIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Cambia el rol de un usuario en una empresa desde la consola de administración de cuentas (3.32)."""
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    _solo_principal_si_admin_sistema(s, a, uid)            # 3.87
    rol = rol_canonico(s, eid, (data.rol or "").strip())                # «avanzado» = «Avanzado»
    if not rol_valido(s, eid, rol):
        raise HTTPException(400, "Rol inválido para esta empresa")
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == eid)).first()
    if not m:
        raise HTTPException(404, "El usuario no pertenece a esta empresa")
    if m.rol == "Administrador" and rol != "Administrador":
        _asegurar_otro_administrador(s, eid, uid)                      # la empresa conserva al menos un Administrador
    exigir_caja_para_rol(s, e, rol, m, u=s.get(Usuario, uid))           # 3.87
    anterior = m.rol
    m.rol = rol; s.add(m); s.commit()
    auditar(s, "usuario_rol", f"usuario {uid}: {anterior} → {rol} (consola de administración)", a, eid, request)
    return {"ok": True, "rol": rol, "exige_mfa": rol_exige_mfa(s, eid, rol)}


@admin.delete("/cuentas/{eid}/usuarios/{uid}", dependencies=[Depends(solo_web)])
def admin_quitar_autorizacion(eid: int, uid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    _solo_principal_si_admin_sistema(s, a, uid)            # 3.87
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == eid)).first()
    if m:
        if m.rol == "Administrador":
            _asegurar_otro_administrador(s, eid, uid)                  # (R289)
        _anotar_retiro(s, m)                                           # 4.35
        s.delete(m); s.commit()
        auditar(s, "usuario_retirado", f"usuario {uid}", a, eid, request)
    return {"ok": True}


@admin.post("/cuentas/{eid}/usuarios/{uid}/entrar-como", dependencies=[Depends(solo_web)])
def admin_entrar_como(eid: int, uid: int, request: Request, response: Response, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """4.35: soporte. El administrador del sistema entra a la empresa COMO una de sus personas, para ver lo que ella ve: una sesión nueva
    de esa cuenta en esa empresa, con el rol de su membresía, que dura 1 hora como máximo y no pide los dos pasos de la persona (el
    administrador ya entró con los suyos). Solo en empresas que este administrador ve (superadmin: las ocultas dan 404) y si la persona no
    pertenece a otra que él no ve; nunca como un administrador del sistema (tampoco el super administrador) ni como una cuenta bloqueada
    o de una empresa bloqueada. Queda en la Auditoría de la empresa (la ve la empresa, a propósito) y en el registro del sistema."""
    if _es_local():                                               # en el programa no existe, tampoco en modo soporte (FE_LOCAL_ADMIN=1)
        raise HTTPException(403, {"codigo": "solo_web", "mensaje": MENSAJE_SOLO_WEB.format(web=_web_programa())})
    propia = s.get(Sesion, getattr(request.state, "fe_sesion_id", None) or 0)
    if propia is None or propia.suplantada_por or propia.usuario_id != a.id:
        raise HTTPException(403, MENSAJE_SUPLANTADA)              # sin anidar (superadmin ya lo rechaza)
    if not a.mfa_activo:                                          # superadmin ya la exige; aquí, por si la política cambiara
        raise HTTPException(403, "Para entrar como otro usuario active primero su verificación en dos pasos (Mi perfil)")
    e = s.get(Empresa, eid)
    if e is None:
        raise HTTPException(404, "Empresa no encontrada")
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == eid)).first()
    u = s.get(Usuario, uid) if m else None
    if u is None:
        raise HTTPException(404, "Esa persona no es usuario de esta empresa")
    if u.es_superadmin:
        raise HTTPException(403, "No se puede entrar como un administrador del sistema")
    _exigir_usuario_visible(s, a, uid)                            # ni como quien también pertenece a una empresa que este administrador no ve
    if u.bloqueado:
        raise HTTPException(409, "Esa cuenta está bloqueada: desbloquéela antes de entrar como ella")
    if e.bloqueada:
        raise HTTPException(409, "La empresa está bloqueada: sus usuarios no pueden entrar. Desbloquéela antes de entrar como uno de ellos")
    # lo que la persona debe hacer ella misma al entrar: como soporte no se hace por ella (esas rutas están cerradas), así que no se entra
    if u.debe_cambiar_password:
        raise HTTPException(409, "Esa persona todavía tiene la contraseña temporal: debe entrar y cambiarla antes")
    if terminos_pendientes(u):
        raise HTTPException(409, "Esa persona todavía no aceptó los términos del servicio: debe entrar y aceptarlos antes")
    if not u.mfa_activo and mfa_obligatorio(s, u) and not mfa_cubierto(s, u):
        raise HTTPException(409, "Esa persona todavía no activó la verificación en dos pasos que su rol exige: debe activarla antes")
    ahora = datetime.now(timezone.utc)
    propia.ultimo_uso = ahora; s.add(propia)                     # al volver, su sesión cuenta desde ahora
    sid = secrets.token_urlsafe(24)
    s.add(Sesion(sid=sid, usuario_id=u.id, ip=_ip(request), agente=request.headers.get("user-agent", "")[:200],
                 suplantada_por=a.id, suplantada_vuelve=propia.id))
    s.commit()
    auditar(s, "soporte_entro_como", f"{a.correo} entró como {u.correo}", a, eid, request)
    auditar(s, "soporte_entro_como", f"{a.correo} entró como {u.correo} ({m.rol}) en la empresa {eid} ({e.nombre_comercial or e.nombre})", a, None, request)
    return _respuesta(s, u, eid, request, response, sid=sid)      # sin ultimo_acceso ni aviso de conexión nueva: no entró la persona


@admin.get("/usuarios")
def admin_usuarios(a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    out = []; ocultas = empresas_ocultas_de(a)
    for u in s.exec(select(Usuario).order_by(Usuario.correo)).all():
        if u.es_superadmin:
            continue
        todas = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()
        emps = [{"id": e.id, "nombre": e.nombre_comercial or e.nombre, "rol": m.rol}
                for m in todas if m.empresa_id not in ocultas and (e := s.get(Empresa, m.empresa_id))]
        if ocultas and todas and not emps:                  # solo pertenece a empresas que este administrador no ve
            continue
        out.append({"id": u.id, "correo": u.correo, "nombre": u.nombre, "bloqueado": u.bloqueado, "mfa_activo": u.mfa_activo, "empresas": emps,
                    "mfa_renuncia": _renuncia_fila(s, u)})                                  # 4.7
    return out


# ----------------------------------------------------------------------------- administradores del sistema (3.80)
# Los de la consola: crean, bloquean y quitan empresas, entran como soporte, ven la auditoría. Antes solo existía el creado en la
# instalación; ahora un administrador agrega a otro (cuenta nueva con contraseña temporal o un usuario que ya existe) y lo quita.
# Todos deben activar la verificación en dos pasos (la consola la exige) y cambiar la contraseña temporal al entrar.
class AdministradorIn(BaseModel):
    correo: str
    nombre: str = Field(min_length=2, max_length=80)
    enviar_correo: bool = True


def _salida_administrador(u: "Usuario", yo: Optional[int] = None, principal_id: Optional[int] = None) -> dict:
    return {"id": u.id, "correo": u.correo, "nombre": u.nombre, "mfa_activo": bool(u.mfa_activo), "bloqueado": bool(u.bloqueado),
            "debe_cambiar_password": bool(u.debe_cambiar_password), "ultimo_acceso": u.ultimo_acceso.isoformat() if u.ultimo_acceso else None,
            "yo": u.id == yo, "principal": u.id == principal_id, "empresas_ocultas": sorted(empresas_ocultas_de(u)) if u.id != principal_id else []}


def _principal_id(s: Session) -> Optional[int]:
    admins = s.exec(select(Usuario).where(Usuario.es_superadmin == True).order_by(Usuario.id)).all()  # noqa: E712
    for x in admins:
        if x.admin_principal:
            return x.id
    if admins:
        es_admin_principal(s, admins[0])     # instalaciones anteriores a 3.80: el primero queda marcado
        return admins[0].id
    return None


def _correo_nuevo_administrador(s: Session, u: "Usuario", clave: Optional[str]) -> bool:
    """Aviso al nuevo administrador con la dirección de la consola (y su contraseña temporal si la cuenta es nueva). Solo por el
    correo de la plataforma (FE_SMTP_*): el de un administrador del sistema nunca sale por el servidor de un cliente."""
    from . import correo as _correo
    smtp = _cfg_smtp_plataforma(s, u)
    if not smtp:
        return False
    url = (URL_PUBLICA or "").rstrip("/") + "/app/"
    texto = (f"Hola {u.nombre},\n\nLe dieron acceso como administrador del sistema de {nombre_sistema()}: desde la consola se crean, bloquean y "
             f"quitan las empresas, y se da soporte a sus usuarios.\n\nIngrese en {url}\nCorreo: {u.correo}\n"
             + (f"Contraseña temporal: {clave}\n(se le pedirá cambiarla al entrar)\n" if clave else "Use la contraseña que ya tiene.\n")
             + "\nAl entrar deberá activar la verificación en dos pasos con una aplicación de códigos en su celular.\n\n" + nombre_sistema())
    from . import correo_diseno as _dz                                    # 3.83: diseño común
    html = _dz.armar(_dz.plataforma(), titulo="Ya es administrador del sistema", asunto=f"Acceso de administrador del sistema · {nombre_sistema()}",
                     preencabezado="Su acceso a la consola donde se administran las empresas.", saludo=f"Hola {u.nombre},",
                     parrafos_txt=[f"Le dieron acceso como administrador del sistema de {nombre_sistema()}. Desde la consola se crean, bloquean y quitan "
                                   "las empresas, y se da soporte a sus usuarios."],
                     datos=[("Correo", u.correo), ("Contraseña temporal" if clave else "Contraseña", clave or "La que ya tiene")],
                     boton_=("Entrar a la consola", url),
                     despues=[("Al entrar se le pedirá cambiar la contraseña temporal. " if clave else "")
                              + "También deberá activar la verificación en dos pasos con una aplicación de códigos en su celular."])
    try:
        _correo.enviar(smtp, [u.correo], f"Acceso de administrador del sistema · {nombre_sistema()}", html, texto, [])
        return True
    except Exception:  # noqa: BLE001  (sin correo, la consola muestra la contraseña temporal para entregarla a mano)
        import logging; logging.getLogger(__name__).exception("No se pudo avisar al nuevo administrador del sistema")
        return False


@admin.get("/administradores")
def admin_administradores(a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    pid = _principal_id(s)
    return [_salida_administrador(u, a.id, pid) for u in s.exec(select(Usuario).where(Usuario.es_superadmin == True).order_by(Usuario.nombre)).all()]  # noqa: E712


@admin.post("/administradores", dependencies=[Depends(solo_web)])
def admin_agregar_administrador(data: AdministradorIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    solo_principal(s, a)
    correo = validar_correo(data.correo)
    u = s.exec(select(Usuario).where(Usuario.correo == correo)).first()
    clave, reactivada = None, False
    if u:
        if u.es_superadmin:
            raise HTTPException(400, f"{correo} ya es administrador del sistema")
        if u.bloqueado:
            if s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id).limit(1)).first():
                raise HTTPException(400, f"El usuario {correo} está bloqueado: desbloquéelo en Cuentas, en la empresa donde aparece, antes de darle acceso a la consola")
            # 3.85: quedó bloqueada al quitarla de la consola (sin empresas no aparece en ningún lado para desbloquearla): volver a
            # agregarla la reactiva con una contraseña temporal nueva; la verificación en dos pasos que ya tenía se conserva
            clave, reactivada = clave_facil(), True
            u.password_hash, u.debe_cambiar_password = hash_password(clave), True
            u.bloqueado, u.intentos_fallidos, u.bloqueado_hasta = False, 0, None
        u.es_superadmin = True
        _borrar_renuncia(u)                  # 4.7: el administrador del sistema siempre usa la verificación en dos pasos
    else:
        clave = clave_facil()
        u = Usuario(correo=correo, nombre=" ".join(data.nombre.split()), password_hash=hash_password(clave), debe_cambiar_password=True, es_superadmin=True)
    s.add(u); s.commit(); s.refresh(u)
    enviado = _correo_nuevo_administrador(s, u, clave) if data.enviar_correo else False
    auditar(s, "admin_sistema_agregado", f"{correo} ({'cuenta reactivada con contraseña temporal nueva' if reactivada else 'cuenta nueva' if clave else 'usuario existente'})",
            a, request=request)
    return {"ok": True, "administrador": _salida_administrador(u, a.id, _principal_id(s)), "password_temporal": clave, "correo_enviado": enviado}


@admin.delete("/administradores/{uid}", dependencies=[Depends(solo_web)])
def admin_quitar_administrador(uid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    solo_principal(s, a)
    u = s.get(Usuario, uid)
    if not u or not u.es_superadmin:
        raise HTTPException(404, "Ese usuario no es administrador del sistema")
    if u.id == a.id:
        raise HTTPException(400, "No puede quitarse a sí mismo: pídaselo a otro administrador del sistema")
    otros = [x for x in s.exec(select(Usuario).where(Usuario.es_superadmin == True)).all() if x.id != u.id and not x.bloqueado]  # noqa: E712
    if not otros:
        raise HTTPException(400, "Debe quedar al menos un administrador del sistema activo")
    u.es_superadmin = False
    sin_empresas = not s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id).limit(1)).first()
    if sin_empresas:                    # sin consola ni empresas la cuenta no sirve para nada: queda bloqueada
        u.bloqueado = True
    s.add(u); s.commit()
    _revocar_sesiones(s, u.id)
    _revocar_tokens_api(s, u.id)
    auditar(s, "admin_sistema_quitado", u.correo + (" (cuenta bloqueada: no pertenece a ninguna empresa)" if sin_empresas else ""), a, request=request)
    return {"ok": True, "bloqueado": bool(u.bloqueado)}


class OcultasIn(BaseModel):
    ocultas: list[int] = []


@admin.put("/administradores/{uid}/empresas", dependencies=[Depends(solo_web)])
def admin_empresas_ocultas(uid: int, data: OcultasIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Empresas que un administrador del sistema NO ve (3.80). Las demás, y las que se creen después, sí las ve."""
    solo_principal(s, a)
    u = s.get(Usuario, uid)
    if not u or not u.es_superadmin:
        raise HTTPException(404, "Ese usuario no es administrador del sistema")
    if es_admin_principal(s, u):
        raise HTTPException(400, "El super administrador ve todas las empresas")
    existentes = {e.id for e in s.exec(select(Empresa)).all()}
    ocultas = sorted({int(x) for x in data.ocultas if int(x) in existentes})
    u.empresas_ocultas = json.dumps(ocultas)
    s.add(u); s.commit()
    nombres = ", ".join((e.nombre_comercial or e.nombre) for e in (s.get(Empresa, x) for x in ocultas) if e) or "ninguna"
    auditar(s, "admin_sistema_empresas", f"{u.correo} no ve: {nombres}", a, request=request)
    return {"ok": True, "empresas_ocultas": ocultas}


# ----------------------------------------------------------------------------- renuncia a la verificación: consola del sistema (4.7)
class InterruptorRenunciaIn(BaseModel):
    permitida: bool


def _renuncias_consola(s: Session, a) -> dict:
    """Interruptor y quién aceptó la renuncia (usuario, empresas visibles para este administrador, fecha, versión)."""
    interruptor = renuncia_mfa_permitida()
    ocultas = empresas_ocultas_de(a)
    filas = []
    for x in s.exec(select(Usuario).where(Usuario.mfa_renuncia_version != None).order_by(Usuario.correo)).all():  # noqa: E711
        if x.es_superadmin:
            continue
        todas = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == x.id)).all()
        emps = [{"id": e.id, "nombre": e.nombre_comercial or e.nombre, "rol": m.rol, "sin_excepcion": bool(getattr(e, "mfa_sin_excepcion", False))}
                for m in todas if m.empresa_id not in ocultas and (e := s.get(Empresa, m.empresa_id))]
        if ocultas and todas and not emps:              # solo pertenece a empresas que este administrador no ve
            continue
        filas.append({"id": x.id, "correo": x.correo, "nombre": x.nombre, "mfa_activo": bool(x.mfa_activo), "bloqueado": bool(x.bloqueado),
                      "ip": x.mfa_renuncia_ip, "agente": x.mfa_renuncia_agente, "empresas": emps, **(_renuncia_fila(s, x, None, interruptor) or {})})
    return {"permitida": interruptor, "version": RENUNCIA_MFA_VERSION, "url": RENUNCIA_MFA_URL, "puede_cambiar": es_admin_principal(s, a),
            "renuncias": filas}


@admin.get("/mfa-renuncia")
def admin_ver_renuncia_mfa(a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """(4.7) Interruptor «Permitir la renuncia a la verificación en dos pasos» y lista de quién la aceptó."""
    return _renuncias_consola(s, a)


@admin.put("/mfa-renuncia", dependencies=[Depends(solo_web)])
def admin_interruptor_renuncia_mfa(data: InterruptorRenunciaIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """(4.7) Enciende o apaga la renuncia en todo el sistema. Apagada, ninguna renuncia vale: la verificación se exige de nuevo de
    inmediato. Como la lista de IP, solo el super administrador lo cambia."""
    if not es_admin_principal(s, a):
        raise HTTPException(403, "Solo el super administrador cambia si se permite la renuncia a la verificación en dos pasos")
    antes = renuncia_mfa_permitida()
    seguridad_guardar({"mfa_renuncia": {"permitida": bool(data.permitida)}})
    if antes != bool(data.permitida):
        n = len(s.exec(select(Usuario.id).where(Usuario.mfa_renuncia_version == RENUNCIA_MFA_VERSION, Usuario.es_superadmin == False,  # noqa: E712
                                                Usuario.mfa_activo == False)).all())  # noqa: E712
        auditar(s, "mfa_renuncia_interruptor", ("Renuncia a la verificación en dos pasos PERMITIDA" if data.permitida else
                                                f"Renuncia a la verificación en dos pasos APAGADA para todo el sistema: {n} persona(s) deberán activar la verificación"),
                a, request=request)
    return _renuncias_consola(s, a)


@admin.get("/auditoria")
def admin_auditoria(limite: int = 300, empresa_id: Optional[int] = None, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    stmt = select(Auditoria)
    if empresa_id:
        stmt = stmt.where(Auditoria.empresa_id == empresa_id)
    ocultas = empresas_ocultas_de(a)
    if not ocultas:
        return [r.model_dump() for r in s.exec(stmt.order_by(Auditoria.id.desc()).limit(limite)).all()]
    # 3.87: lo que habla de una empresa oculta tampoco existe aquí. Se filtra antes del límite (antes, con limite=1000, el administrador
    # limitado recibía 705 filas) y, en las filas sin empresa, se quitan las de usuarios que solo pertenecen a empresas ocultas (la misma
    # regla de /usuarios: inicios de sesión y códigos fallidos, contraseñas restablecidas, bloqueos) y las que nombran a una empresa oculta
    # (p. ej. «x no ve: Hotel …»). Lo que un usuario hizo en una empresa visible se sigue viendo aunque hoy solo esté en una oculta.
    por_u: dict = defaultdict(set)
    for m in s.exec(select(UsuarioEmpresa)).all():
        por_u[m.usuario_id].add(m.empresa_id)
    admins = {u.id for u in s.exec(select(Usuario).where(Usuario.es_superadmin == True)).all()}  # noqa: E712
    solo = {uid for uid, es in por_u.items() if es and es <= ocultas and uid not in admins}
    correos = {u.correo.lower() for u in s.exec(select(Usuario).where(Usuario.id.in_(solo))).all() if u.correo} if solo else set()  # type: ignore[attr-defined]
    todas = s.exec(select(Empresa)).all()
    lista_ocultas = {x for e in todas if e.id in ocultas for x in (e.nombre, e.nombre_comercial) if x}
    nombres = {x for x in lista_ocultas if len(x) >= 4}
    # 3.87: nombres de empresas visibles que contienen el de una oculta («Soda y Restaurante El Fogón Demo» contiene «Restaurante El
    # Fogón»): se quitan del texto antes de buscar, para no esconder una fila que habla de la visible
    mayores = sorted({x for e in todas if e.id not in ocultas for x in (e.nombre, e.nombre_comercial)
                      if x and x not in lista_ocultas and any(n in x for n in nombres)}, key=len, reverse=True)
    stmt = stmt.where((Auditoria.empresa_id == None) | (Auditoria.empresa_id.notin_(ocultas)))  # noqa: E711  # type: ignore[union-attr]
    if solo:   # 3.87: solo en las filas sin empresa (antes también escondía lo que ese usuario hizo en una empresa visible)
        stmt = stmt.where((Auditoria.empresa_id != None) | (Auditoria.usuario_id == None) | (Auditoria.usuario_id.notin_(solo)))  # noqa: E711  # type: ignore[union-attr]

    def de_oculta(r) -> bool:
        if r.empresa_id is not None:
            return False
        det = r.detalle or ""
        palabras = {w.strip(".,;:()«»").lower() for w in det.split()}
        if (r.correo or "").lower() in correos or correos & palabras:
            return True
        if r.accion == "admin_sistema_empresas" and " no ve: " in det:          # «x no ve: A, B»: se comparan los nombres completos de la lista
            lista = ", " + det.split(" no ve: ", 1)[1].strip() + ", "
            return any(f", {n}, " in lista for n in lista_ocultas)
        ids = {int(x) for x in re.findall(r"(?i)\bempresa[\s_#]+(\d+)\b", det)}
        if ids:                                                                 # «Empresa 11 (…)»: decide el número, no el nombre
            return bool(ids & ocultas)
        for x in mayores:
            det = det.replace(x, " ")
        return any(re.search(r"(?<!\w)" + re.escape(n) + r"(?!\w)", det) for n in nombres)   # nombre completo, no un pedazo de palabra

    # 3.87: el filtro de arriba corre en Python; se pide por tandas hasta juntar `limite` filas visibles o terminar la tabla
    filas: list = []
    tanda, ultimo_id = max(int(limite or 0), 100), None
    while len(filas) < limite:
        q = stmt if ultimo_id is None else stmt.where(Auditoria.id < ultimo_id)
        lote = s.exec(q.order_by(Auditoria.id.desc()).limit(tanda)).all()
        filas += [r for r in lote if not de_oculta(r)]
        if len(lote) < tanda:
            break
        ultimo_id = lote[-1].id
    return [r.model_dump() for r in filas[:limite]]


@admin.get("/planes")
def admin_planes(_: Usuario = Depends(superadmin)):
    """Catálogo de planes y extras por tipo de negocio (3.16)."""
    from . import planes
    return planes.catalogo()


class PlanIn(BaseModel):
    precio_acordado: Optional[float] = None      # 3.95: precio fijo (sin IVA); vacío o 0 = precio de lista
    precio_acordado_nota: str = ""
    plan: Optional[str] = None
    extras: list[str] = []
    docs_extra: int = 0
    plan_inicio: Optional[str] = None
    habitaciones: int = 0
    cajas: int = 0
    limite_usuarios: int = 0
    vence: Optional[str] = None
    plan_dia_vence: Optional[int] = None         # 4.28: día fijo propio (1 a 28; 0 = sin día fijo); vacío = el general
    plan_dias_gracia: Optional[int] = None       # 4.28: días de gracia propios (0 a 60); vacío = el general


def _texto_cobro(dia, gracia) -> str:
    return f"día de vencimiento {('sin día fijo' if dia == 0 else dia) if dia is not None else 'el general'}, días de gracia {gracia if gracia is not None else 'el general'}"


class CobroPlanIn(BaseModel):
    dia_vence: Optional[int] = None              # 1 a 28; vacío = cada empresa conserva su fecha
    dias_gracia: int = 0                         # 0 a 60


@admin.get("/cobro-plan")
def admin_ver_cobro_plan(_: Usuario = Depends(superadmin)):
    """4.28 (P-2): día de vencimiento de cada mes y días de gracia generales de los planes."""
    from . import sistema
    return sistema.cobro_plan()


@admin.put("/cobro-plan", dependencies=[Depends(solo_web)])
def admin_guardar_cobro_plan(data: CobroPlanIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """4.28 (P-2): solo el administrador del sistema. Fijar el día NO cambia la fecha de ninguna empresa: se alinea en su siguiente pago."""
    from . import sistema
    if data.dia_vence is not None and not 1 <= data.dia_vence <= 28:
        raise HTTPException(400, "El día de vencimiento va de 1 a 28 (vacío = cada empresa conserva su fecha)")
    if not 0 <= data.dias_gracia <= 60:
        raise HTTPException(400, "Los días de gracia van de 0 a 60")
    antes = sistema.cobro_plan()
    nuevo = sistema.guardar_cobro_plan(data.dia_vence, data.dias_gracia)
    if nuevo != antes:
        auditar(s, "cobro_plan_configurado", f"Vencimiento de los planes: día {antes['dia_vence'] or 'sin día fijo'} → {nuevo['dia_vence'] or 'sin día fijo'}; "
                                             f"días de gracia {antes['dias_gracia']} → {nuevo['dias_gracia']}", a, request=request)
    return nuevo


@admin.post("/cuentas/{eid}/plan", dependencies=[Depends(solo_web)])
def admin_plan(eid: int, data: PlanIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Asigna plan, extras, límites y vencimiento a una empresa (solo el administrador del sistema)."""
    from . import planes
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    antes = cajeros_sin_caja(s, e)                                     # 3.87
    datos = data.model_dump()
    for k in ("plan_dia_vence", "plan_dias_gracia"):                   # 4.28: una consola anterior que no los manda no borra lo guardado
        if k not in data.model_fields_set:
            datos.pop(k, None)
    cobro_antes = (e.plan_dia_vence, e.plan_dias_gracia)
    planes.asignar(e, datos)
    s.add(e); s.commit(); s.refresh(e)
    cobro = f"; {_texto_cobro(e.plan_dia_vence, e.plan_dias_gracia)}" if (e.plan_dia_vence, e.plan_dias_gracia) != cobro_antes else ""
    auditar(s, "plan_asignado", f"{e.nombre}: plan {e.plan or 'sin plan'}, extras {e.extras}, vence {e.vence or '—'}, habitaciones {e.habitaciones}, cajas {e.cajas}{cobro}", a, eid, request)
    aviso = aviso_cajeros(antes, cajeros_sin_caja(s, e))               # 3.87: el plan nuevo dejó cajeros sin punto de venta
    return {**_resumen_empresa(s, e, a), **({"aviso": aviso} if aviso else {})}


class PagoPlanIn(BaseModel):
    fecha: Optional[str] = None
    monto: float = 0
    moneda: str = "CRC"
    medio: str = ""
    referencia: Optional[str] = None
    meses: int = 1
    nota: Optional[str] = None


def _pago_plan_dict(p: "PagoPlan") -> dict:
    return {k: getattr(p, k, None) for k in ("id", "empresa_id", "fecha", "monto", "moneda", "medio", "referencia", "meses", "vence_anterior", "vence_nuevo", "nota", "usuario",
                                              "factura_empresa_id", "factura_documento_id", "factura_consecutivo", "factura_error")} | {"creado": p.creado.isoformat()}


@admin.get("/cuentas/{eid}/pagos")
def admin_pagos_plan(eid: int, _: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    return [_pago_plan_dict(p) for p in s.exec(select(PagoPlan).where(PagoPlan.empresa_id == eid).order_by(PagoPlan.id.desc())).all()]


@admin.post("/cuentas/{eid}/pagos/{pid}/facturar", dependencies=[Depends(solo_web)])
def admin_facturar_pago_plan(eid: int, pid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """3.65: emite (o reintenta) la factura de un pago del plan desde la empresa facturadora."""
    from . import factura_plan
    e = s.get(Empresa, eid)
    p = s.get(PagoPlan, pid)
    if not e or not p or p.empresa_id != eid:
        raise HTTPException(404, "Pago no encontrado")
    if p.factura_documento_id:
        return _pago_plan_dict(p)
    if not factura_plan.configurada():
        raise HTTPException(400, "Configure primero la factura del plan en Pagos en línea (empresa que factura e ítem)")
    r = factura_plan.facturar_pago(s, e, p, a)
    if not r:
        raise HTTPException(400, p.factura_error or "No se pudo facturar el pago")
    auditar(s, "plan_facturado", f"{e.nombre}: pago {p.id} facturado con {r['consecutivo']}", a, eid, request)
    return _pago_plan_dict(p)


@admin.post("/cuentas/{eid}/pagos", dependencies=[Depends(solo_web)])
def admin_registrar_pago_plan(eid: int, data: PagoPlanIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Registra un pago del plan y extiende el vencimiento `meses` (desde hoy o desde el vencimiento vigente, el mayor)."""
    from . import planes
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    p = planes.registrar_pago(s, e, data.model_dump(), getattr(a, "correo", None))
    auditar(s, "plan_pagado", f"{e.nombre}: {p.moneda} {p.monto:,.2f} ({p.medio or 'sin medio'}) por {p.meses} mes(es); vence {p.vence_nuevo}", a, eid, request)
    return {"pago": _pago_plan_dict(p), "cuenta": _resumen_empresa(s, e, a)}


def _borrar_base(p) -> None:
    """3.87: en Windows una petición que todavía tiene abierta la base impide borrar el archivo: se reintenta unos segundos y, si sigue
    abierta, queda en el registro del servidor. La empresa ya se borró; antes respondía 500 a medio camino (visto en la QA)."""
    for _ in range(20):
        try:
            p.unlink(missing_ok=True)
            return
        except PermissionError:
            time.sleep(0.25)
    import logging
    logging.getLogger(__name__).warning("No se pudo borrar %s: otro proceso la tiene abierta", p)


@admin.delete("/cuentas/{eid}", dependencies=[Depends(solo_web)])
def admin_eliminar_cuenta(eid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Elimina una empresa SIN documentos emitidos (las que ya facturaron solo se bloquean)."""
    from .db import EMPRESAS_DIR, Documento, _engines
    e = s.get(Empresa, eid)
    if not e:
        return {"ok": True}
    from . import modulos, recepcion
    with Session(engine_empresa(eid)) as se:
        if se.exec(select(Documento.id).limit(1)).first():
            raise HTTPException(400, "La empresa tiene comprobantes emitidos; bloquéela en lugar de eliminarla")
        # también lo que no son comprobantes: recibidos, pagos y registros (contabilidad, bancos, RRHH…) (R169)
        tiene = []
        if se.exec(select(recepcion.Recibido.id).limit(1)).first(): tiene.append("comprobantes recibidos")
        if se.exec(select(modulos.Pago.id).limit(1)).first(): tiene.append("pagos")
        if se.exec(select(modulos.Registro.id).where(modulos.Registro.clave.notin_(("catalogo", "catalogo_version", "monedas"))).limit(1)).first(): tiene.append("registros (compras, bancos, contabilidad o RRHH)")
        if tiene:
            raise HTTPException(400, "La empresa tiene " + ", ".join(tiene) + "; exporte sus datos (Configuración › Exportar) y bloquéela, o vacíelos antes de eliminarla")
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == eid)).all():
        _anotar_retiro(s, m)             # 4.35: la empresa ya no existe (su id no se reutiliza): nadie más reactiva esas cuentas
        s.delete(m)
    for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == eid)).all():       # roles personalizados (R170)
        s.delete(r)
    from .pedidos import liberar_direcciones
    liberar_direcciones(s, eid)          # 3.87: nombre público, dominio propio y portal de TiKe quedan libres para otra empresa
    s.delete(e); s.commit()
    hit = _engines.pop(eid, None)
    if hit is not None:
        hit[0].dispose()
    for suf in ("", "-wal", "-shm"):
        _borrar_base(EMPRESAS_DIR / f"empresa_{eid}.db{suf}")
    auditar(s, "empresa_eliminada", e.nombre, a, eid, request)
    return {"ok": True}


def _asegurar_otro_administrador(s: Session, empresa_id: int, excluir_uid: int):
    """La empresa conserva al menos un Administrador NO bloqueado además del que se retira o cambia de rol (R289)."""
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == empresa_id, UsuarioEmpresa.rol == "Administrador",
                                                 UsuarioEmpresa.usuario_id != excluir_uid)).all():
        u = s.get(Usuario, m.usuario_id)
        if u and not u.bloqueado:
            return
    raise HTTPException(400, "La empresa debe conservar al menos un Administrador activo (no bloqueado)")


def rol_canonico(s: Session, empresa_id: int, rol: str) -> str:
    """Nombre del rol tal como está definido (mayúsculas incluidas): un rol guardado con otra capitalización quedaba
    huérfano al renombrar o borrar el rol (R290)."""
    for r in ROLES:
        if r.lower() == (rol or "").lower():
            return r
    p = rol_personalizado(s, empresa_id, rol)
    return p.nombre if p is not None else rol


class RolIn(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    permisos: list[str] = []


class CambioRolIn(BaseModel):
    rol: str
    sucursal_id: Optional[int] = None          # 3.66: sucursal fija del usuario (vacío = todas); solo se aplica con sucursal_definida
    sucursal_definida: bool = False
    modulos_ocultos: Optional[list[str]] = None   # 3.70: módulos apagados solo para este usuario (None = no cambiar)


class ModulosIn(BaseModel):
    ocultos: list[str]


@router.get("/modulos")
def ver_modulos(ctx: Contexto = Depends(contexto)):
    """Matriz de módulos (3.70): los que el plan trae y cuáles están apagados en esta empresa."""
    if not (ctx.puede("configurar") or ctx.puede("usuarios")):
        raise HTTPException(403, "Su rol no administra los módulos")
    from . import planes
    e = ctx.empresa
    plan = planes.modulos_plan(e)
    return {"disponibles": [{"codigo": m, "nombre": planes.NOMBRES.get(m, m)} for m in planes.MODULOS if m in plan], "ocultos": planes.ocultos_de(e)}


@router.put("/modulos")
def guardar_modulos(data: ModulosIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    from . import planes
    malos = [x for x in data.ocultos if x not in planes.MODULOS]
    if malos:
        raise HTTPException(400, f"Módulo desconocido: {malos[0]}")
    e = s.get(Empresa, ctx.empresa.id)
    antes = cajeros_sin_caja(s, e)                                     # 3.87
    e.modulos_ocultos = json.dumps(sorted(set(data.ocultos))); s.add(e); s.commit()
    auditar(s, "modulos_empresa", "Apagados: " + (", ".join(sorted(set(data.ocultos))) or "ninguno"), ctx.usuario, e.id, ctx.request)
    return {"ok": True, "ocultos": planes.ocultos_de(e), "aviso": aviso_cajeros(antes, cajeros_sin_caja(s, e))}   # 3.87: cajeros que quedan sin caja


def _rol_dict(s: Session, r: RolEmpresa) -> dict:
    n = len(s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == r.empresa_id, UsuarioEmpresa.rol == r.nombre)).all())
    return {"id": r.id, "rol": r.nombre, "descripcion": r.descripcion or "", "permisos": sorted(permisos_de_rol(s, r.empresa_id, r.nombre)),
            "personalizado": True, "usuarios": n, "exige_mfa": rol_exige_mfa(s, r.empresa_id, r.nombre)}


@router.get("/roles")
def roles_info(ctx: Contexto = Depends(contexto), s: Session = Depends(get_session)):
    """Roles base y personalizados de la empresa activa, con sus permisos (Configuración › Usuarios)."""
    eid = ctx.empresa.id
    base = [{"rol": r, "descripcion": DESCRIPCION_ROLES.get(r, ""), "permisos": sorted(p for p, rs in PERMISOS.items() if r in rs), "personalizado": False,
             "usuarios": len(s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == eid, UsuarioEmpresa.rol == r)).all()), "exige_mfa": r == "Administrador"}
            for r in ROLES]
    propios = sorted((_rol_dict(s, r) for r in s.exec(select(RolEmpresa).where(RolEmpresa.empresa_id == eid)).all()), key=lambda x: x["rol"].lower())
    sin = motivo_sin_caja(ctx.empresa)                                 # 3.87: un rol de solo caja no se asigna donde no hay punto de venta
    for r in base + propios:
        r["solo_caja"] = solo_pos(r["permisos"]); r["sin_caja"] = bool(sin and r["solo_caja"])
    return {"roles": base + propios, "permisos": PERMISOS_NOMBRE, "asignables": PERMISOS_ASIGNABLES}


@router.post("/roles", dependencies=[Depends(solo_web)])
def crear_rol(data: RolIn, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    nombre, lista = validar_rol_personalizado(data.nombre, data.permisos)
    if rol_personalizado(s, ctx.empresa.id, nombre):
        raise HTTPException(400, f"Ya existe un rol llamado «{nombre}»")
    r = RolEmpresa(empresa_id=ctx.empresa.id, nombre=nombre, descripcion=(data.descripcion or "").strip()[:200] or None, permisos=json.dumps(lista))
    s.add(r); s.commit(); s.refresh(r)
    auditar(s, "rol_creado", f"{nombre}: {', '.join(lista)}", ctx.usuario, ctx.empresa.id, ctx.request)
    return _rol_dict(s, r)


@router.put("/roles/{rid}", dependencies=[Depends(solo_web)])
def editar_rol(rid: int, data: RolIn, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    r = s.get(RolEmpresa, rid)
    if not r or r.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Rol no encontrado")
    nombre, lista = validar_rol_personalizado(data.nombre, data.permisos)
    otro = rol_personalizado(s, ctx.empresa.id, nombre)
    if otro and otro.id != r.id:
        raise HTTPException(400, f"Ya existe un rol llamado «{nombre}»")
    if nombre != r.nombre:                                   # los usuarios con el rol siguen el cambio de nombre
        for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == ctx.empresa.id, UsuarioEmpresa.rol == r.nombre)).all():
            m.rol = nombre; s.add(m)
    r.nombre, r.descripcion, r.permisos = nombre, (data.descripcion or "").strip()[:200] or None, json.dumps(lista)
    s.add(r); s.commit(); s.refresh(r)
    auditar(s, "rol_editado", f"{nombre}: {', '.join(lista)}", ctx.usuario, ctx.empresa.id, ctx.request)
    return _rol_dict(s, r)


@router.delete("/roles/{rid}", dependencies=[Depends(solo_web)])
def eliminar_rol(rid: int, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    r = s.get(RolEmpresa, rid)
    if not r or r.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Rol no encontrado")
    if s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == ctx.empresa.id, UsuarioEmpresa.rol == r.nombre)).first():
        raise HTTPException(400, "Hay usuarios con este rol; cámbieles el rol antes de eliminarlo")
    s.delete(r); s.commit()
    auditar(s, "rol_eliminado", r.nombre, ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True}


@router.put("/usuarios/{uid}", dependencies=[Depends(solo_web)])
def cambiar_rol_usuario(uid: int, data: CambioRolIn, ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    """Cambia el rol de un usuario en la empresa activa (base o personalizado)."""
    _solo_principal_si_admin_sistema(s, ctx.usuario, uid)             # 3.87
    if not rol_valido(s, ctx.empresa.id, data.rol):
        raise HTTPException(400, "Rol inválido")
    data.rol = rol_canonico(s, ctx.empresa.id, data.rol)               # (R290)
    m = s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == uid, UsuarioEmpresa.empresa_id == ctx.empresa.id)).first()
    if not m:
        raise HTTPException(404, "El usuario no pertenece a esta empresa")
    if data.sucursal_definida:                                        # 3.66
        if data.sucursal_id:
            from . import sucursales as _suc
            with ctx.sesion() as se:
                if _suc.por_id(se, ctx.empresa.id, data.sucursal_id) is None:
                    raise HTTPException(400, "Sucursal no encontrada")
        m.sucursal_id = data.sucursal_id or None
    if m.rol == "Administrador" and data.rol != "Administrador":
        _asegurar_otro_administrador(s, ctx.empresa.id, uid)
    exigir_caja_para_rol(s, ctx.empresa, data.rol, m, data.modulos_ocultos, s.get(Usuario, uid))   # 3.87: ni Cajero sin caja ni apagarle la caja
    anterior = m.rol
    if data.modulos_ocultos is not None:                              # 3.70
        from . import planes
        malos = [x for x in data.modulos_ocultos if x not in planes.MODULOS]
        if malos:
            raise HTTPException(400, f"Módulo desconocido: {malos[0]}")
        m.modulos_ocultos = json.dumps(sorted(set(data.modulos_ocultos))) if data.modulos_ocultos else None
    m.rol = data.rol; s.add(m); s.commit()
    auditar(s, "usuario_rol", f"usuario {uid}: {anterior} → {data.rol}" + (f" · módulos apagados: {', '.join(sorted(set(data.modulos_ocultos))) or 'ninguno'}" if data.modulos_ocultos is not None else ""),
            ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True, "rol": data.rol, "modulos_ocultos": ocultos_usuario(m)}


# ----------------------------------------------------------------------------- tokens de API (Configuración › Integraciones)
@router.get("/tokens-api")
def listar_tokens_api(ctx: "Contexto" = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    # los tokens de las instalaciones locales (de la empresa) se administran solo en Configuración › Instalación local
    return [_token_dict(t) for t in s.exec(select(TokenApi).where(TokenApi.empresa_id == ctx.empresa.id, TokenApi.usuario_id != TOKEN_EMPRESA).order_by(TokenApi.id.desc())).all()
            if not (t.nombre or "").startswith("Instalación local ·")]        # también los de instalaciones de versiones anteriores


@router.post("/tokens-api", dependencies=[Depends(solo_web)])
def crear_token_api(data: TokenApiIn, ctx: "Contexto" = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    if ctx.rol == "API":
        raise HTTPException(403, "Un token de API no puede crear otros tokens")
    if ctx.usuario.es_superadmin:
        raise HTTPException(403, "Los tokens de API los crea un administrador de la empresa, no el administrador del sistema")
    nombre = (data.nombre or "").strip()[:80]
    if len(nombre) < 3:
        raise HTTPException(400, "Indique un nombre para el token (3 caracteres o más)")
    permisos = sorted({p for p in data.permisos if p in PERMISOS_API})
    if not permisos:
        raise HTTPException(400, "Elija al menos un permiso para el token")
    # solo permisos que el propio usuario tiene (un token nunca puede más que quien lo crea)
    permisos = [p for p in permisos if p in ctx.permisos or p == "ver"]
    if not [p for p in permisos if p != "ver"]:
        raise HTTPException(400, "Su rol no tiene esos permisos")
    activos = s.exec(select(TokenApi).where(TokenApi.empresa_id == ctx.empresa.id, TokenApi.revocado == False)).all()  # noqa: E712
    if len(activos) >= 20:
        raise HTTPException(400, "La empresa ya tiene 20 tokens activos; revoque alguno")
    token = "fcr_" + secrets.token_urlsafe(32)
    t = TokenApi(empresa_id=ctx.empresa.id, usuario_id=ctx.usuario.id, nombre=nombre, prefijo=token[:12], hash=_hash_token_api(token), permisos=json.dumps(permisos))
    s.add(t); s.commit(); s.refresh(t)
    auditar(s, "token_api_creado", f"{nombre} ({t.prefijo}…) permisos: {', '.join(permisos)}", ctx.usuario, ctx.empresa.id, ctx.request)
    return {**_token_dict(t), "token": token}


@router.delete("/tokens-api/{tid}")
def revocar_token_api(tid: int, ctx: "Contexto" = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    if ctx.rol == "API":
        raise HTTPException(403, "Un token de API no puede revocar tokens")
    t = s.get(TokenApi, tid)
    if not t or t.empresa_id != ctx.empresa.id or t.usuario_id == TOKEN_EMPRESA:
        raise HTTPException(404, "Token no encontrado")
    t.revocado = True; s.add(t); s.commit()
    auditar(s, "token_api_revocado", f"{t.nombre} ({t.prefijo}…)", ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True}


# ----------------------------------------------------------------------------- recuperación de contraseña por correo
class RecuperarIn(BaseModel):
    correo: str
    turnstile: Optional[str] = None      # 3.84


class RestablecerIn(BaseModel):
    token: str
    nueva: str


def _token_recuperacion(u: "Usuario") -> str:
    """Enlace de un solo uso: lleva una huella de la contraseña actual; al cambiarla el enlace deja de servir."""
    return firmar({"tipo": "reset", "uid": u.id, "h": hashlib.sha256((u.password_hash or "").encode()).hexdigest()[:16]}, RECUPERACION_SEGUNDOS)


@router.post("/recuperar", dependencies=[Depends(solo_web)])
def recuperar_password(data: RecuperarIn, request: Request, s: Session = Depends(get_session)):
    """Envía por correo un enlace temporal para restablecer la contraseña. Responde igual exista o no el correo."""
    limitar_ip(request, "recuperar", 5, 900, "Demasiadas solicitudes de recuperación; espere 15 minutos")
    correo_u = (data.correo or "").strip().lower()[:254]
    _exigir_captcha(s, request, data.turnstile, "recuperar", correo_u)
    respuesta = {"ok": True, "mensaje": "Si el correo está registrado, recibirá en unos minutos un mensaje con el enlace para restablecer la contraseña (revise también el correo no deseado)."}
    if not correo_u or not CORREO_RE.match(correo_u):
        return respuesta
    limitar_ip(request, "recuperar_correo", 3, 3600, "Ya se enviaron varios enlaces a ese correo; espere una hora", sujeto=correo_u)
    u = s.exec(select(Usuario).where(Usuario.correo == correo_u)).first()
    if not u or u.bloqueado:
        auditar(s, "recuperacion_solicitada", f"{correo_u}: correo no registrado o bloqueado", None, request=request)
        return respuesta
    cfg = _cfg_smtp_plataforma(s, u)
    # la raíz del enlace NUNCA sale de la cabecera Host de la petición (un atacante recibiría el token): solo FE_URL_PUBLICA, o la
    # propia máquina en desarrollo
    local = (request.url.hostname or "") in ("localhost", "127.0.0.1", "::1", "testserver")
    raiz = (URL_PUBLICA or (str(request.base_url) if local else "")).rstrip("/")
    if not cfg or not raiz:
        auditar(s, "recuperacion_sin_correo", f"{correo_u}: " + ("sin servidor de correo de la plataforma configurado" if not cfg else "sin dirección pública (FE_URL_PUBLICA)"), u, request=request)
        return respuesta
    destino, nombre = u.correo, u.nombre          # valores sueltos: el hilo no toca la instancia de la base (se cierra con la petición)
    enlace = f"{raiz}/app/#/restablecer?t={_token_recuperacion(u)}"
    texto = (f"Hola {nombre},\n\nRecibimos una solicitud para restablecer la contraseña de su cuenta en {nombre_sistema()} ({destino}).\n"
             f"Abra este enlace en los próximos 30 minutos y elija una contraseña nueva:\n\n{enlace}\n\n"
             f"Si usted no lo solicitó, ignore este mensaje: su contraseña no cambia.")
    from . import correo_diseno as _dz                                    # 3.83: diseño común
    html = _dz.armar(_dz.plataforma(), titulo="Restablecer su contraseña", asunto=f"{nombre_sistema()}: restablecer su contraseña",
                     preencabezado="El enlace sirve durante 30 minutos.", saludo=f"Hola {nombre},",
                     parrafos_txt=[f"Recibimos una solicitud para restablecer la contraseña de su cuenta {destino}. "
                                   "Toque el botón en los próximos 30 minutos y elija una contraseña nueva."],
                     boton_=("Elegir una contraseña nueva", enlace),
                     nota="Si usted no lo pidió, ignore este correo: su contraseña no cambia.")
    from . import correo as _correo

    def _enviar():
        try:
            _correo.enviar(cfg, [destino], f"{nombre_sistema()}: restablecer su contraseña", html, texto, [])
        except Exception as ex:  # noqa: BLE001
            try:
                with Session(engine) as sc:
                    auditar(sc, "recuperacion_fallida", f"{destino}: {str(ex)[:150]}", None, request=None)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=_enviar, daemon=True).start()
    auditar(s, "recuperacion_solicitada", u.correo, u, request=request)
    return respuesta


@router.post("/restablecer", dependencies=[Depends(solo_web)])
def restablecer_password(data: RestablecerIn, request: Request, s: Session = Depends(get_session)):
    """Cambia la contraseña con el enlace recibido por correo (válido 30 minutos y una sola vez)."""
    limitar_ip(request, "restablecer", 10, 900)
    datos = abrir(data.token or "")
    if not datos or datos.get("tipo") != "reset":
        raise HTTPException(400, "El enlace no es válido o ya venció; solicite uno nuevo")
    u = s.get(Usuario, int(datos.get("uid") or 0))
    if not u or u.bloqueado or datos.get("h") != hashlib.sha256((u.password_hash or "").encode()).hexdigest()[:16]:
        raise HTTPException(400, "El enlace ya se usó o venció; solicite uno nuevo")
    if _es_local() and u.de_nube:                   # 4.25: el mismo control que cambiar la contraseña y el PIN (la pisaría la siguiente bajada)
        raise HTTPException(400, "Su contraseña la administra la nube: restablézcala en la página web y llega a esta computadora al sincronizar")
    validar_password(data.nueva, u.correo)
    if verificar_password(data.nueva, u.password_hash or ""):
        raise HTTPException(400, "La contraseña nueva no puede ser igual a la anterior")
    u.password_hash = hash_password(data.nueva)
    u.debe_cambiar_password = False
    u.intentos_fallidos, u.bloqueado_hasta = 0, None
    _limpiar_fallos_login(s, u.correo)              # 3.87: el enlace del correo también quita la espera por intentos fallidos
    s.add(u); s.commit()
    _revocar_sesiones(s, u.id)
    _revocar_tokens_api(s, u.id)
    auditar(s, "password_restablecida_por_correo", u.correo, u, request=request)
    return {"ok": True}


# ----------------------------------------------------------------------------- paleta de colores del usuario (1.35)
PALETAS = ("fusion", "estudio", "noche", "turquesa", "oceano", "indigo", "grafito", "terracota")   # FISITAAP by Brillante Agencia: tres diseños; las paletas viejas siguen aceptadas


class PaletaIn(BaseModel):
    paleta: str


@router.post("/paleta")
def elegir_paleta(data: PaletaIn, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    if data.paleta not in PALETAS:
        raise HTTPException(400, "Paleta no válida")
    u.paleta = data.paleta
    s.add(u); s.commit()
    return {"ok": True, "paleta": u.paleta}


# ----------------------------------------------------------------------------- términos del servicio y consentimiento (Ley 10946)
class TerminosIn(BaseModel):
    acepta: bool
    consiente_factura: bool = True


@router.get("/terminos")
def ver_terminos(u: Usuario = Depends(solo_usuario)):
    return {"version": TERMINOS_VERSION, "url": "/terminos.html", "pendientes": terminos_pendientes(u), "aceptados": u.terminos_version,
            "fecha": u.terminos_fecha.isoformat() if u.terminos_fecha else None, "consiente_factura": u.consiente_factura}


@router.post("/terminos")
def aceptar_terminos(data: TerminosIn, request: Request, u: Usuario = Depends(solo_usuario), s: Session = Depends(get_session)):
    if not data.acepta:
        raise HTTPException(400, "Para usar el sistema debe aceptar los términos del servicio")
    u.terminos_version, u.terminos_fecha, u.consiente_factura = TERMINOS_VERSION, datetime.now(timezone.utc), bool(data.consiente_factura)
    s.add(u); s.commit()
    auditar(s, "terminos_aceptados", f"versión {TERMINOS_VERSION}; factura electrónica del servicio: {'sí' if data.consiente_factura else 'no'}", u, request=request)
    return {"ok": True, "version": TERMINOS_VERSION}


# ----------------------------------------------------------------------------- lista de IP permitidas para administración (2.3)
# data/seguridad.json: {"ip_admin": {"activa": bool, "ips": ["190.10.20.30", "200.1.0.0/24"]}}. Opcional: apagada, no cambia nada.
# 4.7: también {"mfa_renuncia": {"permitida": bool}}: interruptor de la renuncia a la verificación (sin la clave = permitida).
# Con la lista activa, el panel de administración (superadministrador) solo responde desde esas direcciones.
import ipaddress  # noqa: E402

_SEGURIDAD = DATA_DIR / "seguridad.json"


def seguridad_leer() -> dict:
    try:
        d = json.loads(_SEGURIDAD.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    ip = d.get("ip_admin") if isinstance(d, dict) else None
    ip = ip if isinstance(ip, dict) else {}
    return {"ip_admin": {"activa": bool(ip.get("activa")), "ips": [str(x) for x in (ip.get("ips") or []) if str(x).strip()]}}


def seguridad_guardar(cfg: dict) -> None:
    """Guarda las claves de `cfg` sin tocar las demás (4.7: la lista de IP y el interruptor de la renuncia viven en el mismo archivo y
    cada pantalla guarda solo lo suyo). Escritura atómica: quien lee nunca ve el archivo a medias."""
    try:
        actual = json.loads(_SEGURIDAD.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        actual = {}
    if not isinstance(actual, dict):
        actual = {}
    actual.update(cfg or {})
    contenido = json.dumps(actual, ensure_ascii=False, indent=1)
    tmp = _SEGURIDAD.with_name(f"{_SEGURIDAD.name}.{os.getpid()}.{secrets.token_hex(4)}.tmp")
    tmp.write_text(contenido, encoding="utf-8")
    for _ in range(20):
        try:
            os.replace(tmp, _SEGURIDAD)
            return
        except PermissionError:                    # Windows: otro proceso lo tiene abierto un instante
            time.sleep(0.05)
    _SEGURIDAD.write_text(contenido, encoding="utf-8")
    try:
        tmp.unlink()
    except OSError:
        pass


def ip_valida(texto: str) -> bool:
    try:
        ipaddress.ip_network(str(texto).strip(), strict=False)
        return True
    except ValueError:
        return False


def ip_en_lista(ip: str | None, lista) -> bool:
    if not ip:
        return False
    try:
        a = ipaddress.ip_address(ip.strip())
    except ValueError:
        return False
    for x in lista or []:
        try:
            if a in ipaddress.ip_network(str(x).strip(), strict=False):
                return True
        except ValueError:
            continue
    return False


def exigir_ip_admin(request: Request | None) -> None:
    """403 si la lista está activa y la dirección del cliente no está en ella. Desde la propia máquina (127.0.0.1) siempre pasa:
    así un cron o una prueba local nunca se bloquea, y la lista no deja al administrador fuera por error."""
    cfg = seguridad_leer()["ip_admin"]
    if not cfg["activa"]:
        return
    ip = _ip(request)
    if ip in ("127.0.0.1", "::1") or ip_en_lista(ip, cfg["ips"]):
        return
    raise HTTPException(403, f"La administración solo se permite desde las direcciones autorizadas (la suya es {ip or 'desconocida'})")
