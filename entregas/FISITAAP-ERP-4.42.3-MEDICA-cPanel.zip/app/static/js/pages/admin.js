// Panel del administrador del sistema: crear cuentas de clientes, bloquear/desbloquear, restablecer contraseñas, entrar como soporte.
import { api, toast, fecha, fechaHora, mock, money, cabecerasAuth, claveFacil } from '../api.js';
import { sesion, NOMBRES_MODULO } from '../app.js';
import { filaAuditoria, exportarAuditoria } from './configuracion/seccion.js';
import { exportarTabla } from './reportes/_montos.js';
import AdminPublicidad from './admin-publicidad.js';
import { pintarTurnstile } from '../turnstile.js';
import { fechaRenuncia, marcaRenuncia, estadoRenuncia, claseRenuncia } from '../renuncia-mfa.js';   // 4.7: renuncia a la verificación en dos pasos

// 4.28 (C2): lee un número entero de un campo de la consola. { ok, valor }: vacío vale solo si vacioVale (valor null = «usar el general»);
// letras, decimales o fuera de min..max no valen (antes se guardaban como 0 o como vacío sin avisar). malo: el navegador marcó lo escrito
// como inválido (en un campo numérico, unas letras llegan como vacío).
export function enteroCampo(v, min, max, vacioVale, malo) {
  if (malo) return { ok: false, valor: null };
  const s = v == null ? '' : String(v).trim();
  if (s === '') return { ok: !!vacioVale, valor: null };
  if (!/^\d+$/.test(s)) return { ok: false, valor: null };
  const n = Number(s);
  return n >= min && n <= max ? { ok: true, valor: n } : { ok: false, valor: null };
}

export default {
  props: ['params'],
  components: { AdminPublicidad },
  data() {
    return { tsPrueba: '', tsPruebaError: '', ia: null, iaForm: { key: '', modelo: 'claude-opus-5-5', activo: false, limite_mes: 300 }, iaUso: null, guardandoIA: false, probandoIA: false,
            pasarela: null, pasForm: { key: '', user: '', password: '', activo: false, modo_prueba: false }, suscripciones: [], guardandoPas: false, probandoPas: false,
             renunciaMfa: null, guardandoRenuncia: false, seguridad: null, seguridadIps: '', guardandoSeg: false, admins: null, adminForm: { nombre: '', correo: '', enviar_correo: true }, guardandoAdmin: false, adminRes: null, ocultarAdmin: null, ocultasSel: [], guardandoOcultas: false,   // 3.80: administradores del sistema
             prueba: null, creandoPrueba: false, resultadoPrueba: null, sitio: null, guardandoSitio: false, contactos: [], cuentas: [], q: '', modal: false, guardando: false, esLocal: false, tab: 'cuentas', auditoria: [], qa: '', filtroEmpresa: '', respaldos: null, creandoRespaldo: false, subirEid: null, demo: null, creandoDemo: false, fpForm: null, fpItems: [], fpCuentas: [], guardandoFP: false,
             colAud: [{ key: 'fecha', label: 'Fecha', fmt: v => fechaHora(v) }, { key: 'usuario', label: 'Usuario' }, { key: 'empresa', label: 'Empresa' }, { key: 'solucion', label: 'Área' }, { key: 'descripcion', label: 'Descripción' }, { key: 'ip', label: 'IP' }],
             f: { correo: '', password: '', nombre_empresa: '', nombre_contacto: '', numero_id: '', tipo_negocio: 'facturacion', medica_activa: false }, bloqueo: null, motivo: '', planCfg: null, planForm: null, planCuenta: null, planPagos: [], pagoForm: null,
             cedulaRepetida: [], avisoCuenta: '', local: null, localForm: { version: '', archivo: null, automatica: true }, subiendoLocal: false, cambiandoAuto: false,   // 3.58: cédula repetida, aviso del primer ingreso y programa local publicado
             salud: null, cargandoSalud: false, procesandoCola: false, vistaResumen: null,   // 3.87: salud del sistema y resumen diario por correo
             cobroPlan: null, cobroForm: { dia_vence: '', dias_gracia: 0 }, guardandoCobro: false, filtroPago: '',   // 4.28: día de vencimiento y días de gracia de los planes
             // Tipos de negocio (2.5): lo fija el administrador del sistema; el cliente no lo cambia
             TIPOS: [['facturacion', 'Facturación', 'Ventas, gastos, contactos, inventario, bancos, contabilidad y planilla. Sin punto de venta ni hotel.'],
                     ['comercio', 'Comercio (punto de venta)', 'Punto de venta primero (supermercados, tiendas) más todo lo de Facturación.'],
                     ['restaurante', 'Restaurante (mesas y ventas en línea)', 'Punto de venta con mesas y monitor de preparación más el catálogo en línea con pedidos a la caja (FISITAAP). Entregas, contabilidad y planilla como extras.'],
                     ['servicios', 'Servicios e IT (TiKe)', 'Facturación más TiKe: tickets de soporte, contratos y documentación del cliente (módulo en desarrollo). Contabilidad y planilla como extras.'],
                     ['hospitalidad', 'Hospitalidad (hotel)', 'Recepción, reservaciones, huéspedes, ama de llaves, mantenimiento y punto de venta dentro de Hotel, más todo lo de Facturación. Crea los roles Recepcionista, Camarera, Técnico y Seguridad.']],
             autorizar: null, a: { correo: '', rol: 'Vendedor', nombre: '', password: '' }, ROLES: ['Administrador', 'Avanzado', 'Contador', 'Vendedor', 'Cajero', 'Solo lectura'] };
  },
  computed: {
    dominioActual() { return location.hostname; },
    yoPrincipal() { return !!(this.admins || []).find(x => x.yo && x.principal); },   // 3.80: super administrador
    filtradas() { const q = this.q.toLowerCase(); return this.cuentas.filter(c => !this.filtroPago || this.pagoPendiente(c)).filter(c => !q || [c.nombre, c.nombre_comercial, c.numero_id, c.correo, ...c.usuarios.map(u => u.correo)].join(' ').toLowerCase().includes(q)); },
    activas() { return this.cuentas.filter(c => !c.bloqueada).length; },
    enPrueba() { return this.cuentas.filter(c => c.prueba_hasta).length; },
    pruebasVencidas() { return this.cuentas.filter(c => c.prueba_hasta && c.prueba_vencida).length; },
  },
  methods: {
    // ---- sitio web público (1.36)
    async verSitio() {
      this.tab = 'sitio';
      try {
        const s = await api('/api/admin/sitio');
        for (const k of ['facturacion', 'comercio', 'restaurante', 'servicios']) s.planes[k] = (s.planes[k] || []).map(p => ({ ...p, incluyeTxt: (p.incluye || []).join('\n') }));
        try { s.sistema = await api('/api/admin/sistema'); } catch { s.sistema = { nombre: 'FISITAAP by Brillante Agencia', eslogan: '', dominio: '', correo_ventas: '' }; }
        s.planes.hospitalidad = { ...(s.planes.hospitalidad || {}), incluyeTxt: ((s.planes.hospitalidad || {}).incluye || []).join('\n') };
        s.correosTxt = (s.contacto.correos || []).join(', ');
        s.soporte = { slug: '', whatsapp: '', ...(s.soporte || {}) };   // enlace de ayuda (3.58)
        s.prueba = { automatica: false, dias: 30, turnstile_sitio: '', turnstile_secreto: '', turnstile_configurado: false, turnstile_login: false, ...(s.prueba || {}) };   // prueba automática (3.68)
        s.prueba._login_guardado = !!s.prueba.turnstile_login; s.prueba._sitio_guardado = s.prueba.turnstile_sitio || '';   // 3.84
        this.quitarTsPrueba();
        this.sitio = s;
      } catch (e) { toast(e.message, 'err'); }
    },
    nuevoPlan(tipo) { this.sitio.planes[tipo].push({ nombre: '', precio: 0, periodo: 'mes', documentos: '', usuarios: '', destacado: false, incluyeTxt: '' }); },
    planSitio(p) { return { nombre: p.nombre, precio: +p.precio || 0, periodo: p.periodo === 'anio' ? 'anio' : 'mes', documentos: p.documentos, usuarios: p.usuarios, destacado: !!p.destacado, incluye: String(p.incluyeTxt || '').split('\n').map(x => x.trim()).filter(Boolean) }; },
    async guardarSitio() {
      const s = this.sitio; this.guardandoSitio = true;
      const body = { contacto: { whatsapp: s.contacto.whatsapp, correos: s.correosTxt.split(/[,;\s]+/).filter(Boolean), correo_empresa_id: s.contacto.correo_empresa_id || null },
        planes: { facturacion: s.planes.facturacion.map(this.planSitio), comercio: s.planes.comercio.map(this.planSitio), restaurante: (s.planes.restaurante || []).map(this.planSitio), servicios: (s.planes.servicios || []).map(this.planSitio),
          hospitalidad: { por_habitacion: +s.planes.hospitalidad.por_habitacion || 0, minimo: +s.planes.hospitalidad.minimo || 0, extra_habitacion: +s.planes.hospitalidad.extra_habitacion || 0, precio_40: +s.planes.hospitalidad.precio_40 || 0, precio_50: +s.planes.hospitalidad.precio_50 || 0, canales_usd: +s.planes.hospitalidad.canales_usd || 0, canales: s.planes.hospitalidad.canales, incluye: String(s.planes.hospitalidad.incluyeTxt || '').split('\n').map(x => x.trim()).filter(Boolean) } },
        adicionales: s.adicionales.filter(a => a.nombre), anual: s.anual, soporte: { slug: (s.soporte || {}).slug || '', whatsapp: (s.soporte || {}).whatsapp || '' },
        prueba: { automatica: !!s.prueba.automatica, dias: s.prueba.dias, turnstile_sitio: s.prueba.turnstile_sitio || '', turnstile_secreto: s.prueba.turnstile_secreto || '',
          turnstile_login: !!s.prueba.turnstile_login, turnstile_prueba: this.tsPrueba || null } };
      try { if (s.sistema) await api('/api/admin/sistema', { method: 'PUT', body: { nombre: s.sistema.nombre, eslogan: s.sistema.eslogan || '', dominio: s.sistema.dominio || '', correo_ventas: s.sistema.correo_ventas || '' } }); await api('/api/admin/sitio', { method: 'PUT', body }); toast('Sitio actualizado: los cambios ya se ven en la página', 'ok'); await this.verSitio(); }
      catch (e) { toast(e.message, 'err'); if (this.tsPruebaCtl) { this.tsPruebaCtl.reiniciar(); this.tsPrueba = ''; } }
      this.guardandoSitio = false;
    },
    // ---- 3.84: antes de pedir la verificación al iniciar sesión, la prueba tiene que pasar aquí con las claves escritas
    pruebaTsNecesaria() {
      const p = this.sitio && this.sitio.prueba;
      return !!(p && p.turnstile_login && (!p._login_guardado || (p.turnstile_sitio || '').trim() !== p._sitio_guardado || !!p.turnstile_secreto));
    },
    quitarTsPrueba() { if (this.tsPruebaCtl) { this.tsPruebaCtl.quitar(); this.tsPruebaCtl = null; } this.tsPrueba = ''; this.tsPruebaError = ''; },
    async probarTs() {
      this.quitarTsPrueba();
      const clave = (this.sitio.prueba.turnstile_sitio || '').trim();
      if (!clave) return toast('Escriba primero la clave del sitio de Turnstile', 'err');
      await this.$nextTick();
      try {
        this.tsPruebaCtl = await pintarTurnstile(this.$refs.tsPrueba, clave, 'prueba_login', {
          token: t => { this.tsPrueba = t; if (t) this.tsPruebaError = ''; },
          error: c => { this.tsPruebaError = 'Cloudflare rechazó la verificación (código ' + c + '): revise la clave del sitio y que este dominio (' + location.hostname + ') esté en la lista del widget.'; },
        });
      } catch { this.tsPruebaError = 'No se pudo cargar la verificación de Cloudflare. Si acaba de guardar la clave del sitio por primera vez, recargue la página y pruebe otra vez.'; }
    },
    async cargarItemsFP() { this.fpForm.producto_id = null; this.fpForm.cuenta = ''; this.fpItems = []; this.fpCuentas = []; if (!this.fpForm.empresa_id) return; try { const r = await api('/api/admin/factura-plan/items?empresa_id=' + this.fpForm.empresa_id); this.fpItems = r.items || []; this.fpCuentas = r.cuentas || []; } catch (e) { toast(e.message, 'err'); } },
    async guardarFP() { this.guardandoFP = true; try { const fp = await api('/api/admin/factura-plan', { method: 'PUT', body: this.fpForm }); this.fpItems = fp.items || []; this.fpCuentas = fp.cuentas || []; toast(fp.activo ? 'Cada pago del plan se facturará automáticamente' : 'Factura del plan guardada (inactiva)', 'ok'); } catch (e) { toast(e.message, 'err'); } this.guardandoFP = false; },
    async facturarPagoPlan(p) { try { const r = await api('/api/admin/cuentas/' + p.empresa_id + '/pagos/' + p.id + '/facturar', { method: 'POST' }); this.planPagos = this.planPagos.map(x => (x.id === r.id ? r : x)); toast('Factura ' + r.factura_consecutivo + ' emitida', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    abrirDemo() { this.demo = { tipo: 'comercio', meses: 1, nombre: '' }; },
    async crearDemo() {
      this.creandoDemo = true;
      try { const r = await api('/api/admin/demo', { method: 'POST', body: this.demo }); toast('Empresa demo creada: ' + r.nombre + '. Entre como soporte para presentarla.', 'ok'); this.demo = null; this.cargar && this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.creandoDemo = false;
    },
    abrirPrueba(c) { this.resultadoPrueba = null; this.prueba = { correo: c ? c.correo : '', nombre: c ? c.nombre : '', nombre_empresa: c ? (c.empresa || c.nombre) : '', numero_id: c ? (c.cedula || '') : '', dias: 30, solicitud_id: c ? c.id : null, enviar_correo: true, medica_activa: false, tipo_negocio: (c && c.tipo_negocio) || 'facturacion' }; },
    nombreTipo(t) { return (this.TIPOS.find(x => x[0] === t) || this.TIPOS[0])[1]; },
    // ---- plan, extras y límites por empresa (3.16)
    async abrirPlan(c, venceDefecto) {
      try { if (!this.planCfg) this.planCfg = await api('/api/admin/planes'); } catch (e) { return toast(e.message, 'err'); }
      if (!this.cobroPlan) await this.cargarCobroPlan();
      const p = c.plan || {};
      this.planCuenta = c;
      this.planForm = { plan: p.codigo || '', extras: [...(p.extras || [])], docs_extra: p.docs_extra || 0, plan_inicio: p.plan_inicio || '', habitaciones: p.habitaciones || 0, cajas: p.cajas || 0, limite_usuarios: p.limite_usuarios || 0, precio_acordado: p.precio_acordado || null, precio_acordado_nota: p.precio_acordado_nota || '', vence: p.vence || venceDefecto || '', funciones: [...(p.funciones || [])], plan_dia_vence: p.plan_dia_vence == null ? '' : p.plan_dia_vence, plan_dias_gracia: p.plan_dias_gracia == null ? '' : p.plan_dias_gracia };
      this.pagoForm = { fecha: new Date().toISOString().slice(0, 10), monto: 0, moneda: 'CRC', medio: 'SINPE', referencia: '', meses: 1, nota: '' };
      this.planPagos = [];
      try { this.planPagos = await api('/api/admin/cuentas/' + c.id + '/pagos'); } catch {}
    },
    mesDespues(n) { const d = new Date(); d.setMonth(d.getMonth() + (n || 1)); return d.toISOString().slice(0, 10); },
    diasPara(f) { return f ? Math.ceil((new Date(f + 'T23:59:59') - new Date()) / 86400000) : null; },
    async registrarPago() {
      const c = this.planCuenta, f = this.pagoForm;
      if (!this.planForm.plan && !(c.plan && c.plan.codigo)) return toast('Guarde primero el plan de la empresa', 'err');
      if (!(+f.monto >= 0)) return toast('Indique el monto', 'err');
      try { const r = await api('/api/admin/cuentas/' + c.id + '/pagos', { method: 'POST', body: { ...f, monto: +f.monto, meses: +f.meses || 1 } }); Object.assign(c, r.cuenta); this.planForm.vence = r.pago.vence_nuevo; this.planPagos.unshift(r.pago); toast('Pago registrado: vence el ' + fecha(r.pago.vence_nuevo), 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    planesDe(c) { return (this.planCfg && this.planCfg.planes[c.tipo_negocio || 'facturacion']) || []; },
    // 3.87: al elegir otro plan, el campo de cajas pasa a las del plan nuevo (antes quedaban las del plan anterior)
    alCambiarPlan() { const p = this.planesDe(this.planCuenta).find(x => x.codigo === this.planForm.plan); if (p && p.cajas) this.planForm.cajas = p.cajas; },
    extrasDe(c) { return (this.planCfg && this.planCfg.extras_tipo[c.tipo_negocio || 'facturacion']) || []; },
    async guardarPlan() {
      const c = this.planCuenta, f = this.planForm;
      const dg = enteroCampo(f.plan_dias_gracia, 0, 60, true, this.campoMalo('graciaFicha')), dv = enteroCampo(f.plan_dia_vence, 0, 28, true);   /* 4.28 (C2): vacío = usar el general; letras o fuera de rango, no se guarda */
      if (!dg.ok) return toast('Escriba los días de gracia de esta empresa: un número de 0 a 60, o déjelo vacío para usar el general', 'err');
      if (!dv.ok) return toast('Elija el día de vencimiento de esta empresa: de 1 a 28, sin día fijo o usar el general', 'err');
      try { const { funciones, ...plan } = f; const r = await api('/api/admin/cuentas/' + c.id + '/plan', { method: 'POST', body: { ...plan, plan: f.plan || null, plan_inicio: f.plan_inicio || null, vence: f.vence || null, precio_acordado: (f.precio_acordado === '' || f.precio_acordado == null) ? null : +f.precio_acordado, plan_dia_vence: dv.valor, plan_dias_gracia: dg.valor } }); const { aviso, ...cuenta } = r; Object.assign(c, cuenta); this.planForm = null; toast(aviso ? 'Plan guardado. ' + aviso : 'Plan guardado', aviso ? 'err' : 'ok'); }   /* 3.87: aviso de cajeros que quedan sin punto de venta */
      catch (e) { toast(e.message, 'err'); }
    },
    resumenPlan(c) { const p = c.plan; if (!p) return ''; if (p.sin_plan) return 'Sin plan (todo encendido)'; return p.nombre + (p.extras && p.extras.length ? ' + ' + p.extras.map(x => (this.planCfg && this.planCfg.nombres[x]) || NOMBRES_MODULO[x] || x).join(', ') : '') + (p.vence ? ' · vence ' + fecha(p.vence) : ''); },   /* 4.28: «Vencido» o «En gracia hasta…» van en una marca junto a la fecha */
    async cambiarMedica(c) {
      const activa = c.medica_heredada || !c.medica_activa;
      this.guardando = true;
      try {
        const r = await api('/api/admin/cuentas/' + c.id + '/medica', { method: 'PUT', body: { activa } });
        c.medica_activa = r.medica_activa;
        c.medica_heredada = false;
        toast(r.medica_activa ? 'FISITAAP Médica activada' : 'FISITAAP Médica desactivada', 'ok');
        await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      finally { this.guardando = false; }
    },
    async cambiarTipo(c, tipo) {
      if (tipo === (c.tipo_negocio || 'facturacion')) return;
      if (!confirm('¿Cambiar ' + (c.nombre_comercial || c.nombre) + ' a «' + this.nombreTipo(tipo) + '»? No se borra nada: cambia el menú que ven sus usuarios y se crean los roles sugeridos del tipo si faltan.')) return this.cargar();
      try { const r = await api(`/api/admin/cuentas/${c.id}/tipo`, { method: 'POST', body: { tipo_negocio: tipo } }); toast('Tipo cambiado a ' + this.nombreTipo(tipo) + (r.roles_creados?.length ? '. Roles creados: ' + r.roles_creados.join(', ') : '') + '. Quien esté dentro de la empresa debe recargar la página para ver sus módulos.' + (r.aviso ? ' ' + r.aviso : ''), r.aviso ? 'err' : 'ok');   /* 3.87 */ if (sesion.empresa_id === c.id) { try { await sesion.restaurar(); } catch {} } }
      catch (e) { toast(e.message, 'err'); }
      this.cargar();
    },
    async crearPrueba() {
      const p = this.prueba; if (!p.correo || !p.nombre_empresa) return toast('Indique el correo y el nombre de la empresa', 'err');
      this.creandoPrueba = true;
      try { this.resultadoPrueba = await api('/api/admin/pruebas', { method: 'POST', body: p }); toast('Prueba creada hasta el ' + fecha(this.resultadoPrueba.vence), 'ok'); this.cargar && this.cargar(); if (this.tab === 'contactos') this.verContactos(); }
      catch (e) { toast(e.message, 'err'); }
      this.creandoPrueba = false;
    },
    async extender(c, dias) {
      if (!confirm(dias ? '¿Extender la prueba ' + dias + ' días?' : '¿Activar como cliente? La prueba termina y a continuación se le asigna el plan, los extras y el vencimiento.')) return;
      try { await api('/api/admin/pruebas/' + c.id, { method: 'POST', body: { dias } }); toast(dias ? 'Prueba extendida' : 'Cuenta activada como cliente: asigne su plan', 'ok'); if (!dias) { c.prueba_hasta = null; await this.abrirPlan(c, this.mesDespues(1)); } else if (this.cargar) this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminarPrueba(c) {
      if (!confirm('¿Eliminar «' + (c.nombre_comercial || c.nombre) + '» con todos sus datos? No se puede deshacer.')) return;
      try { const r = await api('/api/admin/pruebas/' + c.id, { method: 'DELETE' }); toast('Empresa eliminada (' + r.xml_borrados + ' comprobantes de ejemplo)', 'ok'); this.cargar && this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- lista de IP permitidas para administración (2.3): opcional; apagada no cambia nada
    // 3.36: Pagos en línea (Tilopay). Solo el administrador del sistema; las empresas nunca ven esta configuración
    async verIA() {
      this.tab = 'ia';
      try { this.ia = await api('/api/admin/ia'); this.iaForm = { key: '', modelo: this.ia.modelo, activo: !!this.ia.activo, limite_mes: this.ia.limite_mes }; } catch (e) { toast(e.message, 'err'); }
      try { this.iaUso = await api('/api/admin/ia/uso'); } catch { this.iaUso = null; }
    },
    async guardarIA() {
      this.guardandoIA = true;
      try { this.ia = await api('/api/admin/ia', { method: 'PUT', body: this.iaForm }); this.iaForm.key = ''; toast('Configuración de la IA guardada', 'ok'); } catch (e) { toast(e.message, 'err'); }
      this.guardandoIA = false;
    },
    async probarIA() { this.probandoIA = true; try { const r = await api('/api/admin/ia/probar', { method: 'POST', body: {} }); toast(r.mensaje, 'ok'); this.ia = await api('/api/admin/ia'); } catch (e) { toast(e.message, 'err'); } this.probandoIA = false; },
    async verPagos() {
      this.tab = 'pagos';
      this.cargarCobroPlan();
      try { const fp = await api('/api/admin/factura-plan'); this.fpForm = { activo: !!fp.activo, empresa_id: fp.empresa_id || null, producto_id: fp.producto_id || null, cuenta: fp.cuenta || '', oculta: !!fp.oculta }; this.fpItems = fp.items || []; this.fpCuentas = fp.cuentas || []; } catch {}   /* 3.65; 3.87: oculta = la factura sale de una empresa que este administrador no ve */
      try { this.pasarela = await api('/api/admin/pasarela'); this.pasForm = { key: '', user: '', password: '', activo: !!this.pasarela.activo, modo_prueba: !!this.pasarela.modo_prueba }; this.suscripciones = await api('/api/admin/suscripciones'); } catch (e) { toast(e.message, 'err'); }
    },
    // 4.28 (P-2): día de vencimiento de cada mes y días de gracia generales (solo el administrador del sistema)
    async cargarCobroPlan() {
      try { this.cobroPlan = await api('/api/admin/cobro-plan'); this.cobroForm = { dia_vence: this.cobroPlan.dia_vence || '', dias_gracia: this.cobroPlan.dias_gracia || 0 }; } catch { this.cobroPlan = null; }
    },
    async guardarCobroPlan() {
      const f = this.cobroForm, g = enteroCampo(f.dias_gracia, 0, 60, false, this.campoMalo('graciaGeneral')), d = enteroCampo(f.dia_vence, 1, 28, true);   /* 4.28 (C2): vacío o letras no se guardan como 0 */
      if (!g.ok) return toast('Escriba los días de gracia: un número de 0 a 60', 'err');
      if (!d.ok) return toast('Elija el día de vencimiento: de 1 a 28, o «Cada empresa conserva su fecha»', 'err');
      this.guardandoCobro = true;
      try { this.cobroPlan = await api('/api/admin/cobro-plan', { method: 'PUT', body: { dia_vence: d.valor, dias_gracia: g.valor } }); toast('Vencimiento y días de gracia guardados', 'ok'); this.cargar && this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoCobro = false;
    },
    campoMalo(r) { const el = this.$refs && this.$refs[r]; return !!(el && el.validity && el.validity.badInput); },   /* 4.28 (C2): letras en un campo numérico */
    fechaCr(f) { const v = String(f || '').slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v.slice(8, 10) + '/' + v.slice(5, 7) + '/' + v.slice(0, 4) : (v || '—'); },   /* 4.28 (C6): DD/MM/AAAA */
    pagoPendiente(c) { const e = c.plan && c.plan.estado_pago; return e === 'en_gracia' || e === 'vencido'; },
    diaMes(f) { const v = String(f || '').slice(0, 10); return v.length === 10 ? v.slice(8, 10) + '/' + v.slice(5, 7) : v; },
    generalCobro() { const g = this.cobroPlan; if (!g) return ''; return (g.dia_vence ? 'día ' + g.dia_vence : 'sin día fijo') + ' y ' + (g.dias_gracia || 0) + ' días de gracia'; },
    async guardarPasarela() {
      this.guardandoPas = true;
      try { this.pasarela = await api('/api/admin/pasarela', { method: 'PUT', body: this.pasForm }); this.pasForm.key = this.pasForm.user = this.pasForm.password = ''; toast('Configuración de Tilopay guardada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoPas = false;
    },
    async probarPasarela() {
      this.probandoPas = true;
      try { const r = await api('/api/admin/pasarela/probar', { method: 'POST' }); toast('Conexión con Tilopay correcta · ' + r.planes + ' plan(es) en la integración', 'ok'); this.pasarela = await api('/api/admin/pasarela'); }
      catch (e) { toast(e.message, 'err'); }
      this.probandoPas = false;
    },
    async sincronizarSusc(x) { try { const r = await api('/api/admin/suscripciones/' + x.empresa_id + '/sincronizar', { method: 'POST' }); toast('Sincronizada: ' + (r.registrados || 0) + ' pago(s) nuevo(s)', 'ok'); this.suscripciones = await api('/api/admin/suscripciones'); } catch (e) { toast(e.message, 'err'); } },
    async verSeguridad() { this.tab = 'seguridad'; this.cargarAdmins(); this.cargarRenunciaMfa(); try { this.seguridad = await api('/api/admin/seguridad'); this.seguridadIps = (this.seguridad.ip_admin.ips || []).join('\n'); } catch (e) { toast(e.message, 'err'); } },
    // administradores del sistema (3.80): quienes entran a esta consola
    async cargarAdmins() { try { this.admins = await api('/api/admin/administradores'); } catch (e) { this.admins = []; toast(e.message, 'err'); } if (!this.cuentas.length && this.cargar) this.cargar(); },
    // 3.80: empresas que un administrador NO ve (las demás y las nuevas sí); solo el super administrador las elige
    elegirOcultas(x) { this.ocultarAdmin = x; this.ocultasSel = [...(x.empresas_ocultas || [])]; },
    async guardarOcultas() {
      this.guardandoOcultas = true;
      try { await api('/api/admin/administradores/' + this.ocultarAdmin.id + '/empresas', { method: 'PUT', body: { ocultas: this.ocultasSel } }); toast(this.ocultasSel.length ? this.ocultarAdmin.nombre + ' ya no ve ' + this.ocultasSel.length + ' empresa(s)' : this.ocultarAdmin.nombre + ' ve todas las empresas', 'ok'); this.ocultarAdmin = null; await this.cargarAdmins(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoOcultas = false;
    },
    async agregarAdmin() {
      const f = this.adminForm; if (!f.nombre.trim() || !f.correo.trim()) return toast('Nombre y correo son obligatorios', 'err');
      if (!confirm(f.nombre.trim() + ' (' + f.correo.trim() + ') podrá crear, bloquear y quitar empresas, entrar a cualquiera como soporte y agregar o quitar administradores. ¿Darle acceso?')) return;
      this.guardandoAdmin = true; this.adminRes = null;
      try { const r = await api('/api/admin/administradores', { method: 'POST', body: { nombre: f.nombre.trim(), correo: f.correo.trim(), enviar_correo: f.enviar_correo } }); this.adminRes = { ...r, pidio_correo: f.enviar_correo }; this.adminForm = { nombre: '', correo: '', enviar_correo: true }; toast('Administrador del sistema agregado', 'ok'); await this.cargarAdmins(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoAdmin = false;
    },
    async quitarAdmin(x) {
      if (!confirm('¿Quitar a ' + x.nombre + ' (' + x.correo + ') como administrador del sistema? Se cierran sus sesiones y deja de ver esta consola.')) return;
      try { const r = await api('/api/admin/administradores/' + x.id, { method: 'DELETE' }); toast(r.bloqueado ? 'Quitado. Su cuenta quedó bloqueada porque no pertenece a ninguna empresa; si lo vuelve a agregar, se reactiva con una contraseña temporal nueva' : 'Quitado como administrador del sistema', 'ok'); this.adminRes = null; await this.cargarAdmins(); }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- 4.7: renuncia a la verificación en dos pasos: interruptor del sistema (solo el super administrador) y quién la aceptó
    fechaRenuncia, marcaRenuncia, estadoRenuncia, claseRenuncia,
    async cargarRenunciaMfa() { try { this.renunciaMfa = await api('/api/admin/mfa-renuncia'); } catch (e) { this.renunciaMfa = null; toast(e.message, 'err'); } },
    async guardarRenunciaMfa(ev) {
      const permitida = ev.target.checked, n = this.renunciaMfa.renuncias.filter(x => x.vigente && !x.mfa_activo).length;
      const pregunta = permitida ? 'Al permitirla, quienes deben usar la verificación en dos pasos podrán no hacerlo si aceptan el descargo de responsabilidad con su contraseña. ¿Permitirla?'
        : 'Al apagarla, ninguna renuncia vale y la verificación en dos pasos se vuelve a pedir de inmediato' + (n ? ' a ' + (n === 1 ? '1 persona que la aceptó' : n + ' personas que la aceptaron') : '') + '. ¿Apagarla?';
      if (!confirm(pregunta)) { ev.target.checked = !permitida; return; }
      this.guardandoRenuncia = true;
      try { this.renunciaMfa = await api('/api/admin/mfa-renuncia', { method: 'PUT', body: { permitida } }); toast(permitida ? 'Renuncia permitida: cada persona decide aceptando el descargo' : 'Renuncia apagada: la verificación se pide de nuevo a todos los que la necesitan', 'ok'); }
      catch (e) { ev.target.checked = !permitida; toast(e.message, 'err'); }
      this.guardandoRenuncia = false;
    },
    async guardarSeguridad(activa) {
      const ips = this.seguridadIps.split(/[\n,;\s]+/).map(x => x.trim()).filter(Boolean);
      if (activa && !confirm('Con la lista activa, el panel de administración solo responde desde estas direcciones: ' + ips.join(', ') + (this.seguridad.ip_actual && !ips.includes(this.seguridad.ip_actual) ? ' (y la suya actual, ' + this.seguridad.ip_actual + ', que se agrega sola)' : '') + '. ¿Activar?')) return;
      this.guardandoSeg = true;
      try { const r = await api('/api/admin/seguridad', { method: 'PUT', body: { activa, ips } }); this.seguridad = r; this.seguridadIps = (r.ip_admin.ips || []).join('\n'); toast(activa ? 'Lista de IP activada' + (r.aviso ? '. ' + r.aviso : '') : 'Lista de IP desactivada: la administración responde desde cualquier dirección', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoSeg = false;
    },
    async verContactos() { this.tab = 'contactos'; try { this.contactos = await api('/api/admin/contactos'); } catch (e) { toast(e.message, 'err'); } },
    async atender(c) { try { await api('/api/admin/contactos/' + c.id, { method: 'PUT', body: { atendida: !c.atendida } }); c.atendida = !c.atendida; } catch (e) { toast(e.message, 'err'); } },
    // ---- 3.87: salud del sistema (cola, cron, Hacienda, respaldos, correo, avisos del servidor) y resumen diario por correo
    async cargarSalud() { this.cargandoSalud = true; try { this.salud = await api('/api/admin/salud'); } catch (e) { this.salud = null; if (this.tab === 'salud') toast(e.message, 'err'); } this.cargandoSalud = false; },
    verSalud() { this.tab = 'salud'; this.vistaResumen = null; this.cargarSalud(); },
    sem(x) { return ({ ok: 'ok', aviso: 'warn', mal: 'danger' })[x] || 'info'; },
    semTxt(x) { return ({ ok: 'Bien', aviso: 'Revisar', mal: 'Atención' })[x] || 'Info'; },
    origenCola(p) { const o = { cron: 'la corrió el cron', script: 'la corrió el programa de la cola', hilo: 'la corrió el sistema mientras alguien lo usaba', consola: 'la pidió ' + (p.por || 'un administrador') + ' desde esta consola' }[p.origen] || ''; return o + (p.duracion_ms != null ? ' en ' + (p.duracion_ms / 1000).toFixed(1).replace('.', ',') + ' s' : ''); },
    async procesarCola() { this.procesandoCola = true; try { await api('/api/admin/cola/procesar', { method: 'POST' }); toast('Pasada de la cola iniciada: en unos segundos se actualiza el estado', 'ok'); setTimeout(() => this.cargarSalud(), 6000); } catch (e) { toast(e.message, 'err'); } this.procesandoCola = false; },
    async copiarCron() { try { await navigator.clipboard.writeText(this.salud.cron.comando); toast('Comando copiado: cambie AQUI_EL_TOKEN por el valor de FE_CRON_TOKEN', 'ok'); } catch { toast('No se pudo copiar: selecciónelo y cópielo a mano', 'err'); } },
    async guardarResumen(activo) { try { await api('/api/admin/salud/resumen', { method: 'PUT', body: { activo } }); toast(activo ? 'Resumen diario encendido' : 'Resumen diario apagado', 'ok'); } catch (e) { toast(e.message, 'err'); } this.cargarSalud(); },
    async verResumen() { try { this.vistaResumen = await api('/api/admin/salud/resumen/vista'); } catch (e) { toast(e.message, 'err'); } },
    diasDesde(f) { return f ? (Date.now() - new Date(f).getTime()) / 86400000 : Infinity; },
    trasDescargar() { setTimeout(async () => { try { this.respaldos = await api('/api/admin/respaldos'); } catch {} }, 3000); },   // 3.87: la consola anota la descarga
    fecha, fechaHora, money, exportar: exportarAuditoria,
    async cargar() { try { this.cuentas = await api('/api/admin/cuentas'); } catch (e) { toast(e.message, 'err'); } try { this.respaldos = await api('/api/admin/respaldos'); } catch { this.respaldos = null; } },
    async restaurarRespaldo(r, eid, nombre) {
      const texto = prompt('Va a restaurar «' + nombre + '» al estado de ' + r.nombre + '. Todo lo registrado después se pierde de la vista (se guarda antes una copia de seguridad). Escriba RESTAURAR para confirmar:');
      if (!texto) return;
      try { const x = await api('/api/admin/respaldos/empresa/' + eid + '/' + r.nombre + '/restaurar', { method: 'POST', body: { confirmacion: texto } }); toast('Empresa restaurada desde ' + x.nombre + ' (seguridad: ' + x.seguridad + ')', 'ok'); if (x.otra_instalacion && x.pendiente && x.pendiente.length) alert('Respaldo de otra instalación restaurado en «' + nombre + '». Queda pendiente:\n\n• ' + x.pendiente.join('\n• ')); this.respaldos = await api('/api/admin/respaldos'); } catch (e) { toast(e.message, 'err'); }
    },
    async subirRespaldo(ev, eid) {
      const f = ev.target.files && ev.target.files[0]; ev.target.value = ''; if (!f) return;
      const fd = new FormData(); fd.append('archivo', f);
      try { const r = await api('/api/admin/respaldos/empresa/' + eid + '/subir', { method: 'POST', body: fd }); toast('Respaldo subido: ' + r.nombre, 'ok'); this.respaldos = await api('/api/admin/respaldos'); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminarRespaldo(r, eid) {
      if (!confirm('¿Eliminar el respaldo ' + r.nombre + '? No se puede deshacer.')) return;
      try { await api(eid ? '/api/admin/respaldos/empresa/' + eid + '/' + r.nombre : '/api/admin/respaldos/' + r.nombre, { method: 'DELETE' }); toast('Respaldo eliminado', 'ok'); this.respaldos = await api('/api/admin/respaldos'); } catch (e) { toast(e.message, 'err'); }
    },
    async registroClientes() {   // 4.17
      try { const filas = await api('/api/admin/registro-clientes?formato=json'); if (!filas.length) return toast('No hay clientes registrados'); exportarTabla('registro_clientes', Object.keys(filas[0]).map(k => ({ key: k, label: (k.charAt(0).toUpperCase() + k.slice(1)).replace(/_/g, ' ') })), filas, { titulo: 'Registro de clientes' }); } catch (e) { toast(e.message, 'err'); }
    },
    async crearRespaldo() { this.creandoRespaldo = true; try { const r = await api('/api/admin/respaldos', { method: 'POST' }); toast('Respaldo creado: ' + r.nombre + ' (' + Math.round(r.bytes / 1024) + ' KB)', 'ok'); this.respaldos = await api('/api/admin/respaldos'); } catch (e) { toast(e.message, 'err'); } this.creandoRespaldo = false; },
    kb(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB'; },
    async cargarAuditoria() {
      try {
        const nombres = Object.fromEntries(this.cuentas.map(c => [c.id, c.nombre_comercial || c.nombre]));
        this.auditoria = (await api('/api/admin/auditoria?limite=1000' + (this.filtroEmpresa ? '&empresa_id=' + this.filtroEmpresa : ''))).map(a => ({ ...filaAuditoria(a), empresa: nombres[a.empresa_id] || (a.empresa_id ? '#' + a.empresa_id : '—') }));
      } catch (e) { toast(e.message, 'err'); }
    },
    verAuditoria() { this.tab = 'auditoria'; this.cargarAuditoria(); },
    generarClave() { this.f.password = claveFacil(); },   // 3.70: fácil de teclear y de recordar; el cliente la cambia al entrar
    async crear() {
      if (!this.f.correo || !this.f.password || !this.f.nombre_empresa) return toast('Correo, contraseña y nombre de la empresa son obligatorios', 'err');
      this.guardando = true;
      try {
        const r = await api('/api/admin/cuentas', { method: 'POST', body: { ...this.f, numero_id: this.f.numero_id || null, nombre_contacto: this.f.nombre_contacto || null } });
        // 4.35: si el correo ya tenía una cuenta que conserva su contraseña (entra a otras empresas, es del sistema o está bloqueada), la escrita no vale: no se ofrece entregarla
        if (r.password_aplica === false) toast(`Cuenta creada. ${this.f.correo} conserva su contraseña de siempre: la que escribió no se aplicó`, r.motivo === 'bloqueada' ? 'err' : 'ok');
        else toast(`Cuenta creada. Entregue al cliente: ${this.f.correo} / ${this.f.password}`, 'ok');
        this.avisoCuenta = 'Cuenta «' + this.f.nombre_empresa + '» creada para ' + this.f.correo + '. ' + (r.aviso || 'Al entrar por primera vez, el administrador deberá cambiar la contraseña temporal, activar la verificación en dos pasos y aceptar los términos del servicio.');
        this.modal = false; this.cedulaRepetida = []; this.f = { correo: '', password: '', nombre_empresa: '', nombre_contacto: '', numero_id: '', tipo_negocio: 'facturacion', medica_activa: false }; this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    // 3.58: otras empresas con la misma cédula (aviso; no impide crear: las sucursales son empresas aparte)
    async revisarCedula() {
      const n = (this.f.numero_id || '').trim(); this.cedulaRepetida = [];
      if (!n) return;
      try { this.cedulaRepetida = (await api('/api/admin/cuentas/cedula?numero=' + encodeURIComponent(n))).empresas || []; } catch {}
    },
    // 3.58: funciones en prueba por empresa (dentro de «Plan y extras»)
    async guardarFunciones() {
      const c = this.planCuenta;
      try { const r = await api('/api/admin/cuentas/' + c.id + '/funciones', { method: 'PUT', body: { funciones: this.planForm.funciones } }); c.plan = r.plan; toast(r.funciones.length ? 'Funciones en prueba: ' + r.funciones.map(x => this.planCfg.funciones[x].nombre).join(', ') : 'Sin funciones en prueba', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    // 3.58: programa local Windows publicado en la nube (las instalaciones lo descargan solas)
    async verLocal() {
      this.tab = 'local';
      try { this.local = await api('/api/admin/local'); } catch (e) { toast(e.message, 'err'); }
    },
    archivoLocal(ev) { this.localForm.archivo = (ev.target.files && ev.target.files[0]) || null; },
    async publicarLocal() {
      const f = this.localForm;
      if (!f.archivo) return toast('Elija el archivo del programa (.exe)', 'err');
      if (!/^\d+(\.\d+)*$/.test((f.version || '').trim())) return toast('Indique la versión del programa, por ejemplo 1.46', 'err');
      this.subiendoLocal = true;
      try {
        const fd = new FormData(); fd.append('archivo', f.archivo); fd.append('version', f.version.trim()); fd.append('automatica', f.automatica ? 'true' : 'false');   /* 4.26 */
        const r = await fetch('/api/admin/local/publicar', { method: 'POST', headers: cabecerasAuth(), body: fd });
        const j = await r.json().catch(() => null);
        if (!r.ok) throw new Error((j && j.detail && (typeof j.detail === 'string' ? j.detail : j.detail.mensaje)) || 'No se pudo subir (' + r.status + ')');
        this.local = { ...(this.local || {}), publicado: j.publicado }; this.localForm = { version: '', archivo: null, automatica: true };
        toast(j.publicado.automatica === false ? 'Programa local ' + j.publicado.version + ' publicado: quedó disponible para descargar desde Configuración › Instalación local; las computadoras conectadas no lo descargan solas' : 'Programa local ' + j.publicado.version + ' publicado: las instalaciones lo descargan en su siguiente revisión', 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.subiendoLocal = false;
    },
    // 4.26: activar o desactivar la actualización automática de lo publicado sin subir el archivo otra vez
    async cambiarAutoLocal(valor) {
      this.cambiandoAuto = true;
      try { const r = await api('/api/admin/local/automatica', { method: 'POST', body: { automatica: !!valor } }); this.local = { ...(this.local || {}), publicado: r.publicado }; toast(valor ? 'Actualización automática activada: las computadoras conectadas descargan esta versión en su siguiente revisión' : 'Actualización automática desactivada: las computadoras conectadas ya no descargan esta versión solas; las que ya la descargaron la instalan al reiniciar el programa', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.cambiandoAuto = false;
    },
    async quitarLocal() {
      if (!confirm('¿Quitar el programa publicado? Las instalaciones dejarán de ver una versión nueva hasta que publique otra.')) return;
      try { await api('/api/admin/local', { method: 'DELETE' }); this.local = { ...(this.local || {}), publicado: null }; toast('Programa quitado', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    mb(b) { return (b / 1048576).toFixed(1) + ' MB'; },
    pedirBloqueo(c) { this.bloqueo = c; this.motivo = ''; },
    async bloquear(c, bloquear) {
      try { await api(`/api/admin/cuentas/${c.id}/bloqueo`, { method: 'POST', body: { bloquear, motivo: this.motivo || null } }); toast(bloquear ? 'Acceso bloqueado' : 'Acceso restablecido', 'ok'); this.bloqueo = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async bloquearUsuario(u, bloquear) {
      try { await api(`/api/admin/usuarios/${u.id}/bloqueo`, { method: 'POST', body: { bloquear } }); toast(bloquear ? 'Usuario bloqueado' : 'Usuario desbloqueado', 'ok'); this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async resetPassword(u) {
      const p = prompt(`Nueva contraseña temporal para ${u.correo} (mínimo 12 caracteres):`, claveFacil()); if (!p) return;
      try { await api(`/api/admin/usuarios/${u.id}/password`, { method: 'POST', body: { password: p } }); toast('Contraseña restablecida; el usuario deberá cambiarla al entrar. Se desactivó su verificación en dos pasos y se retiró su renuncia a ella, si la tenía.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async eliminar(c) {
      if (!confirm(`¿Eliminar la empresa "${c.nombre}"? Solo es posible si no tiene comprobantes.`)) return;
      try { await api(`/api/admin/cuentas/${c.id}`, { method: 'DELETE' }); toast('Empresa eliminada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    // Autorización explícita de un usuario en una empresa (sin ella no puede entrar ni cambiarse a esa empresa)
    // 3.32: roles de cada empresa (base + propios) y cambio de rol directo desde la lista
    rolesDe(c, u) { const l = (c && c.roles && c.roles.length) ? c.roles : this.ROLES; return u && u.rol && !l.includes(u.rol) ? [u.rol, ...l] : l; },
    async cambiarRol(c, u, ev) {
      const rol = ev.target.value, antes = u.rol;
      if (rol === antes) return;
      if (!confirm('¿Cambiar a ' + u.correo + ' de «' + antes + '» a «' + rol + '» en ' + (c.nombre_comercial || c.nombre) + '?')) { ev.target.value = antes; return; }
      try { const r = await api(`/api/admin/cuentas/${c.id}/usuarios/${u.id}/rol`, { method: 'PUT', body: { rol } }); u.rol = r.rol; toast('Rol cambiado a ' + r.rol + (r.exige_mfa && !u.mfa_activo ? '. Deberá activar la verificación en dos pasos al entrar' : ''), 'ok'); }
      catch (e) { ev.target.value = antes; toast(e.message, 'err'); }
    },
    pedirAutorizar(c) { this.autorizar = c; this.a = { correo: '', rol: 'Vendedor', nombre: '', password: '' }; },
    async confirmarAutorizar() {
      if (!this.a.correo) return toast('Indique el correo del usuario', 'err');
      try {
        const r = await api(`/api/admin/cuentas/${this.autorizar.id}/usuarios`, { method: 'POST', body: { ...this.a, nombre: this.a.nombre || null, password: this.a.password || null } });
        toast(`${this.a.correo} autorizado en ${this.autorizar.nombre_comercial || this.autorizar.nombre}` + (r && r.aviso ? '. ' + r.aviso : ''), r && r.motivo === 'bloqueada' ? 'err' : 'ok'); this.autorizar = null; this.cargar();   /* 4.35: el aviso dice qué pasó con la contraseña (la cuenta sin empresas queda con la inicial; las demás conservan la suya) */
      } catch (e) { toast(e.message, 'err'); }
    },
    async quitarAutorizacion(c, u) {
      if (!confirm(`¿Quitar a ${u.correo} el acceso a "${c.nombre_comercial || c.nombre}"? Conservará sus otras empresas.`)) return;
      try { await api(`/api/admin/cuentas/${c.id}/usuarios/${u.id}`, { method: 'DELETE' }); toast('Autorización retirada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async entrar(c) { try { if (mock.cargado) await mock.guardarTodo(); await sesion.iniciar(await api('/api/auth/empresa', { method: 'POST', body: { empresa_id: c.id } })); location.hash = '/inicio'; } catch (e) { toast(e.message, 'err'); } },
    // 4.35: soporte: entrar a la empresa COMO una de sus personas (su rol, 1 hora como máximo, queda en la auditoría de la empresa). La sesión
    // del administrador sigue abierta en el servidor; «Volver a mi cuenta» (franja de arriba) la devuelve. Solo en la página web.
    async entrarComo(c, u) {
      if (!confirm('¿Entrar a ' + (c.nombre_comercial || c.nombre) + ' como ' + u.correo + ' (' + u.rol + ')? Verá lo que esa persona ve, por 1 hora como máximo. Queda en la auditoría de la empresa.')) return;
      try { if (mock.cargado) await mock.guardarTodo(); await sesion.iniciar(await api(`/api/admin/cuentas/${c.id}/usuarios/${u.id}/entrar-como`, { method: 'POST' })); toast('Está usando FISITAAP como ' + u.correo, 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); this.cargarSalud(); api('/api/auth/estado').then(r => { this.esLocal = !!r.pin_local; }).catch(() => {}); },   // 4.14
  template: `
  <div class="page">
    <div class="erp-intro">
      <div><p class="eyebrow">{{$store.sistema.nombre || 'FISITAAP by Brillante Agencia'}} · Panel maestro</p><h1>Una plataforma. Todo conectado.</h1><p>Cree las cuentas de sus clientes, controle su acceso, asigne planes y entre a cualquier empresa como soporte.</p></div>
      <div class="erp-page-tools">
        <button class="btn sec" @click="abrirDemo">+ Empresa demo</button>
        <button class="btn sec" @click="abrirPrueba(null)">+ Prueba gratis 30 días</button>
        <button class="btn" @click="modal=true;generarClave()">+ Nueva cuenta</button>
      </div>
    </div>
    <div class="card salud-linea" v-if="salud" style="display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:10px 16px">
      <span><span class="badge" :class="sem(salud.semaforo)">{{semTxt(salud.semaforo)}}</span> <b>Salud del sistema:</b> {{salud.resumen}}<span class="small muted" v-for="f in salud.filas.filter(x => x.estado === 'mal').slice(0, 2)" :key="f.clave"> · {{f.titulo}}</span></span>
      <button class="btn sm sec" @click="verSalud">Ver detalle</button>
    </div>
    <div class="card" v-if="respaldos">
      <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div><h2 style="margin:0">Respaldos y registro de clientes</h2><div class="small muted" v-if="respaldos.general !== false">Respaldo automático diario de <span class="mono">data/</span> en <span class="mono">{{respaldos.carpeta}}</span> (se conservan {{respaldos.conservar}}). Último: <template v-if="respaldos.ultimo_real"><span class="mono">{{respaldos.ultimo_real.nombre}}</span> · {{fechaHora(respaldos.ultimo_real.fecha)}} · {{kb(respaldos.ultimo_real.bytes)}}</template><template v-else>ninguno todavía</template>.<template v-if="respaldos.ultima_descarga"> Último descargado: {{fechaHora(respaldos.ultima_descarga.fecha)}}.</template></div>
          <div class="small muted" v-else>El respaldo general incluye todas las empresas: lo crea y lo descarga el super administrador. Aquí están los respaldos de las empresas a su cargo.</div></div>
        <div class="row" style="gap:8px"><button class="btn sec" @click="registroClientes">⤓ Registro de clientes</button><button class="btn" @click="crearRespaldo" :disabled="creandoRespaldo" v-if="respaldos.general !== false">{{creandoRespaldo ? 'Creando…' : 'Crear respaldo ahora'}}</button></div>
      </div>
      <div class="alert err" style="margin:10px 0 0" v-if="respaldos.dentro_app"><b>Estos respaldos se perderían al instalar una versión nueva.</b> La carpeta <span class="mono">{{respaldos.carpeta}}</span> está dentro de la carpeta de la aplicación. Defina la variable <span class="mono">FE_RESPALDOS_DIR={{respaldos.carpeta_sugerida}}</span> (fuera de la aplicación), reinicie y copie allí los respaldos que ya tiene.</div>
      <div class="small" style="margin:8px 0 0;color:var(--warn)" v-if="respaldos.general !== false && respaldos.ultimo_real && diasDesde(respaldos.ultima_descarga && respaldos.ultima_descarga.fecha) > 7">⚠ {{respaldos.ultima_descarga ? 'El último respaldo general se descargó el ' + fechaHora(respaldos.ultima_descarga.fecha) : 'Nunca se ha descargado un respaldo general'}}. Descargue el más reciente y guárdelo fuera del servidor: si se pierde la cuenta del hosting, un respaldo que solo está aquí no sirve.</div>
      <div class="table-wrap" style="margin-top:10px" v-if="respaldos.respaldos.length"><table class="tbl"><thead><tr><th>Archivo</th><th>Fecha</th><th class="num">Tamaño</th><th></th></tr></thead>
        <tbody><tr v-for="r in respaldos.respaldos.slice(0,10)" :key="r.nombre"><td class="mono">{{r.nombre}}</td><td>{{fechaHora(r.fecha)}}</td><td class="num">{{kb(r.bytes)}}</td><td style="text-align:right;white-space:nowrap"><a class="btn sm sec" :href="'/api/admin/respaldos/'+r.nombre" @click="trasDescargar">Descargar</a> <button class="btn sm sec" @click="eliminarRespaldo(r)">Eliminar</button></td></tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0" v-else-if="respaldos.general !== false">Aún no hay respaldos. El primero se crea solo en la próxima pasada de la cola (o ahora con el botón). Descargue uno de vez en cuando a un lugar fuera del servidor.</p>
      <template v-if="respaldos.empresas && respaldos.empresas.length">
        <h3 style="margin:14px 0 4px">Respaldos creados por las empresas</h3>
        <div class="small muted">Cada empresa crea los suyos en Configuración › Respaldos (hasta {{respaldos.maximo_empresa}} por empresa). Aquí puede descargarlos o borrarlos si ocupan espacio.</div>
        <div class="table-wrap" style="margin-top:8px"><table class="tbl"><thead><tr><th>Empresa</th><th>Archivo</th><th>Fecha</th><th class="num">Tamaño</th><th></th></tr></thead>
          <tbody><template v-for="e in respaldos.empresas" :key="e.empresa_id"><tr v-for="r in e.respaldos" :key="r.nombre"><td>{{e.nombre}}</td><td class="mono">{{r.nombre}}</td><td>{{fechaHora(r.fecha)}}</td><td class="num">{{kb(r.bytes)}}</td><td style="text-align:right;white-space:nowrap"><a class="btn sm sec" :href="'/api/admin/respaldos/empresa/'+e.empresa_id+'/'+r.nombre">Descargar</a> <button class="btn sm sec" @click="eliminarRespaldo(r, e.empresa_id)">Eliminar</button> <button class="btn sm" @click="restaurarRespaldo(r, e.empresa_id, e.nombre)">Restaurar</button></td></tr></template></tbody></table></div>
        <div class="row" style="gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap"><span class="small muted">Subir un respaldo .zip para una cuenta:</span><select class="inp" v-model="subirEid" style="max-width:260px"><option :value="null">— Elegir cuenta —</option><option v-for="c in cuentas" :key="c.id" :value="c.id">{{c.nombre_comercial || c.nombre}}</option></select><label class="btn sm sec" style="cursor:pointer" v-if="subirEid">⤒ Subir<input type="file" accept=".zip" style="display:none" @change="subirRespaldo($event, subirEid)"></label></div>
      </template>
    </div>
    <div class="dash" style="margin-bottom:18px">
      <div class="kpi w3"><div class="t">Empresas</div><div class="v">{{cuentas.length}}</div><div class="d">{{cuentas.reduce((s,c)=>s+(c.documentos||0),0)}} comprobantes emitidos</div></div>
      <div class="kpi w3"><div class="t">Con acceso</div><div class="v">{{activas}}</div><div class="d">entran y trabajan hoy</div></div>
      <div class="kpi w3"><div class="t">En prueba</div><div class="v">{{enPrueba}}</div><div class="d">{{pruebasVencidas}} con la prueba vencida</div></div>
      <div class="kpi w3"><div class="t">Bloqueadas</div><div class="v">{{cuentas.length-activas}}</div><div class="d">sin acceso hasta desbloquear</div></div>
    </div>
    <div class="tabs" style="margin-bottom:12px">
      <button class="tab" :class="{on:tab==='cuentas'}" @click="tab='cuentas'">Cuentas</button>
      <button class="tab" :class="{on:tab==='salud'}" @click="verSalud">Salud</button>
      <button class="tab" :class="{on:tab==='auditoria'}" @click="verAuditoria">Auditoría del sistema</button>
      <button class="tab" :class="{on:tab==='sitio'}" @click="verSitio">Sitio web</button>
      <button class="tab" :class="{on:tab==='contactos'}" @click="verContactos">Solicitudes de contacto</button>
      <button class="tab" :class="{on:tab==='seguridad'}" @click="verSeguridad">Seguridad</button>
      <button class="tab" :class="{on:tab==='pagos'}" @click="verPagos">Pagos en línea</button>
      <button class="tab" v-if="!esLocal" :class="{on:tab==='ia'}" @click="verIA">IA</button>
      <button class="tab" :class="{on:tab==='local'}" @click="verLocal">Programa local</button>
      <button class="tab" v-if="!esLocal" :class="{on:tab==='publicidad'}" @click="tab='publicidad'">Publicidad</button>
    </div>
    <AdminPublicidad v-if="tab==='publicidad'"></AdminPublicidad>
    <template v-if="tab==='salud'">
      <div class="card" v-if="!salud"><p class="muted">{{cargandoSalud ? 'Revisando el sistema…' : 'No se pudo leer el estado del sistema.'}}</p></div>
      <template v-else>
        <div class="card pad0"><div class="row" style="padding:14px 16px 0;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><h2 style="margin:0">Salud del sistema <small>{{salud.resumen}} · revisado {{fechaHora(salud.generado)}}</small></h2><button class="btn sec" @click="cargarSalud" :disabled="cargandoSalud">{{cargandoSalud ? 'Revisando…' : 'Actualizar'}}</button></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Estado</th><th>Qué</th><th>Cómo está</th><th>Qué hacer</th></tr></thead>
            <tbody><tr v-for="f in salud.filas" :key="f.clave"><td><span class="badge" :class="sem(f.estado)">{{semTxt(f.estado)}}</span></td><td><b>{{f.titulo}}</b></td><td style="white-space:normal">{{f.valor}}</td><td class="small muted" style="white-space:normal;max-width:380px">{{f.accion}}</td></tr></tbody></table></div>
        </div>
        <div class="card"><h2>Cola de Hacienda y cron <small>la cola reintenta lo que Hacienda no recibió; el cron la corre cada 5 minutos aunque nadie use el sistema</small></h2>
          <p class="small" style="margin:0 0 6px" v-if="salud.cron.ultima_pasada">Última pasada: <b>{{fechaHora(salud.cron.ultima_pasada.hora)}}</b><template v-if="salud.cron.ultima_pasada.origen"> · {{origenCola(salud.cron.ultima_pasada)}}</template><template v-if="salud.cron.ultima_pasada.empresas != null"> · {{salud.cron.ultima_pasada.empresas}} empresa(s), {{salud.cron.ultima_pasada.enviados || 0}} enviado(s), {{salud.cron.ultima_pasada.aceptados || 0}} aceptado(s), {{salud.cron.ultima_pasada.errores || 0}} con error</template>.</p>
          <p class="small" style="margin:0 0 6px" v-else>La cola todavía no ha corrido en esta instalación.</p>
          <p class="small" style="margin:0 0 10px">Cron: {{salud.cron.ultimo_cron ? 'llamó por última vez el ' + fechaHora(salud.cron.ultimo_cron.hora) : 'nunca ha llamado en esta instalación: la cola solo corre mientras alguien usa el sistema'}}.</p>
          <div class="row" style="gap:8px;margin:0 0 14px"><button class="btn" @click="procesarCola" :disabled="procesandoCola || salud.cron.en_curso">{{salud.cron.en_curso ? 'Pasada en curso…' : procesandoCola ? 'Iniciando…' : 'Procesar ahora'}}</button><span class="small muted" style="align-self:center">La misma pasada que hace el cron; nunca corren dos a la vez.</span></div>
          <h3 style="margin:6px 0 4px">Crear el cron en el hosting</h3>
          <p class="small muted" style="margin:0 0 6px">En el hosting, Cron Jobs: frecuencia <b>{{salud.cron.frecuencia}}</b> y este comando. Cambie <span class="mono">AQUI_EL_TOKEN</span> por el valor de <span class="mono">FE_CRON_TOKEN</span> de las variables de la aplicación (aquí nunca se muestra).<template v-if="!salud.cron.token_definido"> <b>Esta instalación todavía no tiene FE_CRON_TOKEN:</b> defínala primero y reinicie.</template></p>
          <div class="row" style="gap:8px;align-items:flex-start"><pre class="mono small" style="flex:1;min-width:0;white-space:pre-wrap;word-break:break-all;margin:0;padding:10px;background:var(--subtle);border-radius:8px">{{salud.cron.comando}}</pre><button class="btn sm sec" @click="copiarCron">Copiar</button></div>
          <p class="small muted" style="margin:6px 0 0">Cada llamada queda anotada en <span class="mono">{{salud.cron.log}}</span>. El mismo cron mantiene despierto al servidor, así el primer ingreso del día no es lento.</p>
        </div>
        <div class="card pad0" v-if="salud.atascados.length"><div style="padding:14px 16px 0"><h2>Comprobantes sin respuesta por empresa</h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Empresa</th><th>Ambiente</th><th class="num">Sin enviar</th><th class="num">Esperando respuesta</th><th class="num">Con error</th><th>El más viejo</th></tr></thead>
            <tbody><tr v-for="x in salud.atascados" :key="x.empresa_id"><td>{{x.empresa}}<div class="small" style="color:var(--danger)" v-if="x.falla">{{x.falla}}</div></td><td>{{x.ambiente === 'produccion' ? 'Producción' : 'Pruebas'}}</td><td class="num">{{x.firmado}}</td><td class="num">{{x.enviado}}</td><td class="num">{{x.error}}</td><td>{{x.mas_viejo ? fechaHora(x.mas_viejo) : '—'}}</td></tr></tbody></table></div>
        </div>
        <div class="card pad0" v-if="salud.buzones.length"><div style="padding:14px 16px 0"><h2>Buzones con error</h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Empresa</th><th>Error</th><th>Desde</th></tr></thead>
            <tbody><tr v-for="x in salud.buzones" :key="x.empresa_id"><td>{{x.empresa}}</td><td class="small" style="white-space:normal">{{x.error}}</td><td class="small">{{x.desde ? fechaHora(x.desde) : '—'}}</td></tr></tbody></table></div>
        </div>
        <div class="card pad0" v-if="salud.llaves.length"><div style="padding:14px 16px 0"><h2>Llaves criptográficas vencidas o por vencer</h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Empresa</th><th>Vence</th><th class="num">Días</th></tr></thead>
            <tbody><tr v-for="x in salud.llaves" :key="x.empresa_id"><td>{{x.empresa}}</td><td>{{fecha(x.vence)}}</td><td class="num"><span class="badge" :class="x.dias < 0 ? 'danger' : 'warn'">{{x.dias < 0 ? 'vencida' : x.dias}}</span></td></tr></tbody></table></div>
        </div>
        <div class="card pad0"><div style="padding:14px 16px 0"><h2>Últimas advertencias del servidor <small>de este proceso, desde que arrancó; sin claves</small></h2></div>
          <div class="table-wrap" v-if="salud.advertencias.length"><table class="tbl"><thead><tr><th>Hora</th><th>Nivel</th><th>Dónde</th><th>Mensaje</th></tr></thead>
            <tbody><tr v-for="(x, i) in salud.advertencias" :key="i"><td class="small">{{fechaHora(x.hora)}}</td><td><span class="badge" :class="x.nivel === 'WARNING' ? 'warn' : 'danger'">{{x.nivel === 'WARNING' ? 'Advertencia' : 'Error'}}</span></td><td class="small mono">{{x.origen}}</td><td class="small" style="white-space:normal;word-break:break-word">{{x.mensaje}}</td></tr></tbody></table></div>
          <p class="muted small" style="padding:0 16px 14px" v-else>Ninguna desde que arrancó el proceso.</p>
        </div>
        <div class="card"><h2>Resumen diario por correo <small>para los administradores del sistema</small></h2>
          <p class="small muted" style="margin:0 0 8px">Cada mañana, después de las {{salud.resumen_diario.hora}}:00, cada administrador del sistema recibe lo que pide acción: el estado del sistema, pruebas gratis por vencer, planes que vencen, solicitudes sin atender, empresas donde nadie entra, comprobantes rechazados, llaves por vencer y errores del servidor. Cada uno, sin las empresas que tiene ocultas; solo nombres y cantidades. Sale por el correo de la plataforma.</p>
          <label class="row small" style="gap:6px;cursor:pointer;margin:0 0 8px" v-if="salud.puede_configurar"><input type="checkbox" :checked="salud.resumen_diario.activo" @change="guardarResumen($event.target.checked)"> Enviar el resumen diario</label>
          <p class="small" style="margin:0 0 8px" v-else>{{salud.resumen_diario.activo ? 'Encendido' : 'Apagado'}}. Lo enciende o apaga el super administrador.</p>
          <button class="btn sm sec" @click="verResumen">Ver cómo le llega hoy</button>
          <div v-if="vistaResumen" style="margin-top:10px"><div class="small muted" style="margin-bottom:6px">Asunto: <b>{{vistaResumen.asunto}}</b> (vista previa: no se envió nada)</div><iframe :srcdoc="vistaResumen.html" sandbox="" style="width:100%;height:560px;border:1px solid var(--border);border-radius:8px;background:#f3f5f4"></iframe></div>
        </div>
      </template>
    </template>
    <template v-if="tab==='pagos'">
      <div class="card" v-if="cobroPlan"><h2>Vencimiento de los planes y días de gracia</h2>
        <p class="small muted" style="margin:0 0 10px">Día de vencimiento de cada mes: vacío, cada empresa conserva su fecha. Fijarlo NO cambia la fecha de ninguna empresa: cada una se alinea a ese día en su siguiente pago. Días de gracia: después de vencer, la empresa sigue trabajando completa esos días y ve un aviso de pago pendiente; al terminar queda solo para consultar. En la ficha de cada cuenta (Plan y extras) puede poner otros valores para esa empresa. Las empresas con el cobro automático con tarjeta activo conservan el día de su cobro.</p>
        <div class="grid cols-3">
          <Field label="Día de vencimiento de cada mes"><select v-model="cobroForm.dia_vence"><option value="">Cada empresa conserva su fecha</option><option v-for="n in 28" :key="n" :value="n">Día {{n}}</option></select></Field>
          <Field label="Días de gracia" help="0 a 60. Con 0, al día siguiente de vencer queda solo para consultar (como hasta ahora)"><input type="number" min="0" max="60" step="1" ref="graciaGeneral" v-model.number="cobroForm.dias_gracia"></Field>
        </div>
        <div class="row" style="gap:8px;margin-top:8px"><button class="btn" @click="guardarCobroPlan" :disabled="guardandoCobro">{{guardandoCobro ? 'Guardando…' : 'Guardar'}}</button></div>
      </div>
      <div class="card" v-if="!pasarela"><p class="muted">Cargando…</p></div>
      <template v-else>
        <div class="card"><h2>Cobro del plan con tarjeta · Tilopay</h2>
          <p class="small muted" style="margin:0 0 10px">Con esto activo, cada empresa puede registrar su tarjeta en Configuración › Suscripción y planes y Tilopay le cobra el plan cada mes (o cada año). Las credenciales se guardan cifradas y las empresas nunca las ven. Se sacan en Tilopay › Connecting to platforms › Api General.</p>
          <div class="alert" :class="pasarela.activo ? 'ok' : 'info'" style="margin:0 0 12px">{{pasarela.activo ? 'Cobro con tarjeta ACTIVO' + (pasarela.modo_prueba ? ' en modo de prueba' : '') : 'Cobro con tarjeta desactivado: las empresas no ven la opción'}}{{pasarela.llave ? ' · llave ' + pasarela.llave : ''}}{{pasarela.origen === 'variables del servidor' ? ' · tomado de las variables del servidor' : ''}}</div>
          <div class="grid cols-3">
            <Field label="API Key" :help="pasarela.llave ? 'Guardada (' + pasarela.llave + '). Escriba solo para cambiarla' : ''"><input v-model="pasForm.key" class="mono" autocomplete="off" :placeholder="pasarela.llave ? 'Sin cambios' : 'XXXX-XXXX-XXXX-XXXX-XXXX'"></Field>
            <Field label="API User" :help="pasarela.usuario_guardado ? 'Guardado. Escriba solo para cambiarlo' : ''"><input v-model="pasForm.user" autocomplete="off" :placeholder="pasarela.usuario_guardado ? 'Sin cambios' : ''"></Field>
            <Field label="API Password" :help="pasarela.clave_guardada ? 'Guardada. Escriba solo para cambiarla' : ''"><input type="password" v-model="pasForm.password" autocomplete="new-password" :placeholder="pasarela.clave_guardada ? 'Sin cambios' : ''"></Field>
          </div>
          <div class="row" style="gap:18px;margin-top:10px;flex-wrap:wrap">
            <Toggle v-model="pasForm.activo" label="Ofrecer el pago automático con tarjeta a las empresas"></Toggle>
            <Toggle v-model="pasForm.modo_prueba" label="La cuenta de Tilopay está en modo de prueba (las empresas ven el aviso)"></Toggle>
          </div>
          <div class="alert warn" style="margin:12px 0 0" v-if="!pasarela.aviso_url">El servidor no tiene una dirección pública con https (FE_URL_PUBLICA), así que Tilopay no podrá avisar cada cobro. Los cobros igual se registran al volver la empresa de Tilopay y en la revisión diaria.</div>
          <div class="small muted" style="margin-top:8px" v-if="pasarela.ultima_prueba">Última prueba de conexión: {{fechaHora(pasarela.ultima_prueba.fecha)}} · {{pasarela.ultima_prueba.mensaje}}</div>
          <div class="row" style="gap:8px;margin-top:12px"><button class="btn sec" @click="probarPasarela" :disabled="probandoPas || !pasarela.activo">{{probandoPas ? 'Probando…' : 'Probar conexión'}}</button><button class="btn" @click="guardarPasarela" :disabled="guardandoPas">Guardar</button></div>
        </div>
        <div class="card" v-if="fpForm && fpForm.oculta"><h2>Factura del plan</h2><p class="small muted" style="margin:0">La factura del plan sale de una empresa que usted no administra: solo el super administrador la ve y la cambia.<template v-if="fpForm.activo"> Hoy cada pago del plan se factura automáticamente.</template></p></div>
        <div class="card" v-if="fpForm && !fpForm.oculta"><h2>Factura del plan <small>cada pago del plan genera un comprobante desde su empresa</small></h2>
          <p class="small muted" style="margin:0 0 10px">Al registrar un pago del plan (a mano aquí o cobrado por Tilopay), la empresa elegida emite la factura a la cuenta cliente con el ítem indicado y la deja cobrada. Si esa empresa tiene facturación electrónica, va a Hacienda y al correo del cliente al aceptarse; si no, es un comprobante interno que se envía al momento.</p>
          <div class="grid cols-3">
            <Field label="Empresa que factura" req><select v-model="fpForm.empresa_id" @change="cargarItemsFP"><option :value="null">— Elegir —</option><option v-for="c in cuentas" :key="c.id" :value="c.id">{{c.nombre_comercial || c.nombre}}</option></select></Field>
            <Field label="Ítem con que se factura" req help="Un servicio de esa empresa; su CABYS e IVA van en la factura"><select v-model="fpForm.producto_id"><option :value="null">— Elegir —</option><option v-for="i in fpItems" :key="i.id" :value="i.id">{{i.nombre}}</option></select></Field>
            <Field label="Cuenta donde entra el dinero" help="Cuenta de Bancos de esa empresa; vacío = el cobro queda sin cuenta"><select v-model="fpForm.cuenta"><option value="">— Sin cuenta —</option><option v-for="b in fpCuentas" :key="b" :value="b">{{b}}</option></select></Field>
          </div>
          <div class="row" style="gap:18px;margin-top:10px;flex-wrap:wrap;align-items:center"><Toggle v-model="fpForm.activo" label="Facturar automáticamente cada pago del plan"></Toggle><span style="flex:1"></span><button class="btn" @click="guardarFP" :disabled="guardandoFP">{{guardandoFP ? 'Guardando…' : 'Guardar'}}</button></div>
        </div>
        <div class="card pad0"><div style="padding:14px 16px 0"><h2>Empresas con pago automático</h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Empresa</th><th>Estado</th><th class="num">Monto</th><th>Próximo cobro</th><th>Plan vence</th><th>Correo</th><th>Revisado</th><th></th></tr></thead>
            <tbody><tr v-for="x in suscripciones" :key="x.empresa_id"><td>{{x.empresa}}</td><td><Badge :value="({activa:'Activa',pendiente:'Pendiente',rechazada:'Rechazada',pausada:'Pausada',cancelada:'Cancelada'})[x.estado] || x.estado"></Badge></td><td class="num">{{money(x.monto, x.moneda)}} <span class="small muted">/ {{x.periodo === 'anio' ? 'año' : 'mes'}}</span></td><td>{{x.proximo_cobro ? fecha(x.proximo_cobro) : '—'}}</td><td>{{x.vence ? fecha(x.vence) : '—'}}</td><td class="small">{{x.correo || '—'}}</td><td class="small muted">{{x.sincronizado ? fechaHora(x.sincronizado) : '—'}}</td><td><button class="btn sm sec" @click="sincronizarSusc(x)">Revisar ahora</button></td></tr>
              <tr v-if="!suscripciones.length"><td colspan="8" class="muted" style="text-align:center;padding:18px">Ninguna empresa ha activado el pago automático todavía.</td></tr></tbody></table></div>
        </div>
      </template>
    </template>
    <template v-if="tab==='ia'">
      <div class="card" v-if="!ia"><p class="muted">Cargando…</p></div>
      <template v-else>
        <div class="card"><h2>Asistente con IA · Claude (Anthropic)</h2>
          <p class="small muted" style="margin:0 0 10px">Una sola clave para todo el sistema. Cada empresa enciende el asistente en Configuración › Asistente con IA. La clave se guarda cifrada y nunca se muestra completa. El consumo se cobra en la cuenta de Anthropic de esta clave.</p>
          <div class="alert warn" v-if="!ia.paquete" style="margin:0 0 12px">El paquete «anthropic» no está instalado en el servidor: instálelo con los requisitos (pip install -r requirements.txt) y reinicie.</div>
          <div class="alert" :class="ia.activo ? 'ok' : 'info'" style="margin:0 0 12px">{{ia.activo ? 'IA ACTIVA · ' + ia.modelos[ia.modelo] : 'IA apagada: las empresas no ven el asistente.'}}</div>
          <div class="grid cols-3">
            <Field label="Clave de la API (sk-ant-…)" :help="ia.llave ? 'Guardada (' + ia.llave + '). Escriba solo para cambiarla' : 'Se crea en console.anthropic.com'"><input v-model="iaForm.key" class="mono" autocomplete="off" :placeholder="ia.llave ? 'Sin cambios' : 'sk-ant-…'"></Field>
            <Field label="Modelo"><select v-model="iaForm.modelo"><option v-for="(n, id) in ia.modelos" :key="id" :value="id">{{n}}</option></select></Field>
            <Field label="Límite de consultas por empresa al mes" help="0 = sin límite"><input type="number" min="0" max="100000" v-model.number="iaForm.limite_mes"></Field>
          </div>
          <div class="row" style="gap:18px;margin-top:10px"><Toggle v-model="iaForm.activo" label="Ofrecer el asistente con IA a las empresas"></Toggle></div>
          <div class="small muted" style="margin-top:8px" v-if="ia.ultima_prueba">Última prueba: {{fechaHora(ia.ultima_prueba.fecha)}} · {{ia.ultima_prueba.mensaje}}</div>
          <div class="row" style="gap:8px;margin-top:12px"><button class="btn sec" @click="probarIA" :disabled="probandoIA || !ia.activo">{{probandoIA ? 'Probando…' : 'Probar conexión'}}</button><button class="btn" @click="guardarIA" :disabled="guardandoIA">Guardar</button></div>
        </div>
        <div class="card pad0" v-if="iaUso"><div style="padding:14px 16px 0"><h2>Consumo del mes {{iaUso.mes}} <small>{{iaUso.total}} consultas</small></h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Empresa</th><th class="num">Consultas</th><th class="num">Tokens de entrada</th><th class="num">Tokens de salida</th></tr></thead>
            <tbody><tr v-for="x in iaUso.empresas" :key="x.empresa_id"><td>{{x.empresa}}</td><td class="num">{{x.consultas}}</td><td class="num">{{x.tokens_entrada.toLocaleString('es-CR')}}</td><td class="num">{{x.tokens_salida.toLocaleString('es-CR')}}</td></tr>
              <tr v-if="!iaUso.empresas.length"><td colspan="4" class="muted" style="text-align:center;padding:18px">Ninguna consulta este mes.</td></tr></tbody></table></div>
        </div>
      </template>
    </template>
    <template v-if="tab==='local'">
      <div class="card" v-if="!local"><p class="muted">Cargando…</p></div>
      <template v-else>
        <div class="card"><h2>Programa local para Windows</h2>
          <p class="small muted" style="margin:0 0 10px">El programa que se instala en las computadoras de los clientes (vende sin internet y sincroniza con la nube). Publique aquí cada versión nueva: cada instalación vinculada revisa la nube al arrancar y cada 6 horas, descarga la versión en segundo plano, comprueba que el archivo esté íntegro y la instala al reiniciar el programa (o cuando el cliente pulsa «Reiniciar y actualizar» en Configuración › Instalación local). Ya no hace falta copiar el archivo a mano en cada computadora.</p>
          <div class="alert" :class="local.publicado ? 'ok' : 'info'" style="margin:0 0 12px" v-if="local.publicado">Versión publicada: <b>{{local.publicado.version}}</b> · {{mb(local.publicado.bytes)}} · {{local.publicado.fecha ? fechaHora(local.publicado.fecha) : ''}}<div class="small mono" style="margin-top:4px;word-break:break-all">sha256 {{local.publicado.sha256}}</div></div>
          <div class="alert" :class="local.publicado.automatica === false ? 'warn' : 'info'" style="margin:0 0 12px;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap" v-if="local.publicado">
            <span v-if="local.publicado.automatica === false"><b>Actualización automática desactivada.</b> El programa queda solo para descargar desde Configuración › Instalación local. Las computadoras conectadas no descargan esta versión solas hasta que la active; las que ya la descargaron la instalan al reiniciar el programa.</span>
            <span v-else><b>Actualización automática activada.</b> Las computadoras conectadas descargan esta versión solas y la instalan al reiniciar el programa. También se puede descargar desde Configuración › Instalación local.</span>
            <button class="btn sm ghost" @click="cambiarAutoLocal(local.publicado.automatica === false)" :disabled="cambiandoAuto">{{cambiandoAuto ? 'Guardando…' : (local.publicado.automatica === false ? 'Activar la actualización automática' : 'Desactivar la actualización automática')}}</button>
          </div>
          <div class="alert info" style="margin:0 0 12px" v-else>No hay ningún programa publicado: las instalaciones no verán versiones nuevas hasta que suba una.</div>
          <div class="grid cols-3" style="align-items:end">
            <Field label="Versión del programa" req help="La que muestra el instalable, por ejemplo 1.46"><input v-model="localForm.version" placeholder="1.46" class="mono"></Field>
            <Field label="Archivo del programa (.exe)" req><input type="file" accept=".exe" @change="archivoLocal"></Field>
            <div class="row" style="gap:8px"><button class="btn" @click="publicarLocal" :disabled="subiendoLocal">{{subiendoLocal ? 'Subiendo (puede tardar)…' : 'Publicar'}}</button><button class="btn ghost" @click="quitarLocal" v-if="local.publicado">Quitar</button></div>
          </div>
          <label class="row small" style="gap:6px;cursor:pointer;margin:10px 0 0"><input type="checkbox" v-model="localForm.automatica"> Actualizar solas las computadoras conectadas</label>
          <p class="small muted" style="margin:4px 0 0">Desmarcada, el programa queda solo para descargar desde Configuración › Instalación local y las computadoras conectadas no lo descargan solas hasta que active la actualización automática aquí. Una computadora que ya descargó una versión la instala al reiniciar el programa, aunque después se desactive.</p>
          <p class="small muted" style="margin:10px 0 0">El archivo pesa unos 50 MB. Si la subida por esta pantalla falla por el límite del hosting, copie el archivo como <span class="mono">GrupoFacturaLocal.exe</span> y un <span class="mono">version.json</span> (con version, sha256, bytes y fecha) en la carpeta <span class="mono">{{local.carpeta}}</span> con el administrador de archivos.</p>
        </div>
      </template>
    </template>
    <template v-if="tab==='seguridad'">
      <div class="card"><h2>Administradores del sistema <small>quienes entran a esta consola: crean, bloquean y quitan empresas y dan soporte</small></h2>
        <div class="table-wrap" v-if="admins && admins.length"><table class="tbl"><thead><tr><th>Nombre</th><th>Correo</th><th>Empresas que ve</th><th>Verificación en dos pasos</th><th>Estado</th><th>Último acceso</th><th></th></tr></thead>
          <tbody><tr v-for="x in admins" :key="x.id"><td><b>{{x.nombre}}</b> <span class="badge ok" v-if="x.principal">Super administrador</span> <span class="badge info" v-if="x.yo">Usted</span></td><td>{{x.correo}}</td>
            <td>{{x.principal || !x.empresas_ocultas.length ? 'Todas' : 'Todas menos ' + x.empresas_ocultas.length}} <button class="btn sm ghost" v-if="yoPrincipal && !x.principal" @click="elegirOcultas(x)">Elegir</button></td>
            <td><span class="badge" :class="x.mfa_activo ? 'ok' : 'warn'">{{x.mfa_activo ? 'Activa' : 'Pendiente'}}</span></td>
            <td><span class="badge danger" v-if="x.bloqueado">Bloqueado</span><span class="badge warn" v-else-if="x.debe_cambiar_password">Debe cambiar la contraseña</span><span class="badge ok" v-else>Activo</span></td>
            <td>{{x.ultimo_acceso ? fechaHora(x.ultimo_acceso) : 'Nunca'}}</td>
            <td style="text-align:right"><button class="btn sm danger" v-if="yoPrincipal && !x.yo" @click="quitarAdmin(x)">Quitar</button></td></tr></tbody></table></div>
        <p class="muted small" v-else-if="admins">Cargando…</p>
        <div class="card" v-if="ocultarAdmin" style="margin:14px 0 0;background:var(--subtle)"><h3 style="margin:0 0 6px">Empresas que {{ocultarAdmin.nombre}} NO ve</h3>
          <p class="small muted" style="margin:0 0 8px">Marque las que no debe ver. Las demás, y todas las empresas que se creen después, sí las ve.</p>
          <div style="max-height:260px;overflow:auto;display:grid;gap:4px"><label class="row small" style="gap:6px;cursor:pointer" v-for="c in cuentas" :key="c.id"><input type="checkbox" :value="c.id" v-model="ocultasSel"> {{c.nombre_comercial || c.nombre}} <span class="muted mono">{{c.numero_id}}</span></label></div>
          <div class="row" style="gap:8px;margin-top:10px"><button class="btn sec" @click="ocultarAdmin=null">Cancelar</button><button class="btn" @click="guardarOcultas" :disabled="guardandoOcultas">{{guardandoOcultas ? 'Guardando…' : 'Guardar'}}</button></div>
        </div>
        <template v-if="yoPrincipal">
        <h3 style="margin:16px 0 8px">Agregar administrador</h3>
        <div class="grid cols-3">
          <Field label="Nombre" req><input v-model="adminForm.nombre" maxlength="80" placeholder="Nombre y apellido"></Field>
          <Field label="Correo" req help="Si ya tiene usuario en el sistema, se le da acceso con su misma contraseña. Si se le quitó antes y su cuenta quedó bloqueada, se reactiva con una contraseña temporal nueva"><input type="email" v-model="adminForm.correo" maxlength="120" placeholder="compañero@fisitaap.com"></Field>
          <Field label="Aviso por correo" help="Le llega la dirección de la consola y, si la cuenta es nueva o se reactiva, la contraseña temporal"><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="adminForm.enviar_correo"> Enviarle el acceso por correo</label></Field>
        </div>
        <div class="row" style="gap:8px;margin-top:10px"><button class="btn" @click="agregarAdmin" :disabled="guardandoAdmin">{{guardandoAdmin ? 'Agregando…' : '+ Agregar administrador del sistema'}}</button></div>
        <div class="alert ok" style="margin-top:12px" v-if="adminRes"><b>{{adminRes.administrador.nombre}}</b> ya es administrador del sistema.
          <template v-if="adminRes.password_temporal"> Contraseña temporal: <b class="mono">{{adminRes.password_temporal}}</b> (solo se muestra ahora).</template>
          {{adminRes.correo_enviado ? 'Se le envió el acceso por correo.' : (adminRes.pidio_correo ? 'No se pudo enviar el correo: entréguele el acceso usted.' : 'Entréguele el acceso usted.')}}
          Al entrar debe cambiar la contraseña temporal y activar la verificación en dos pasos.</div>
        </template>
        <p class="small muted" style="margin:10px 0 0" v-else-if="admins">Solo el super administrador agrega, quita o limita a los administradores del sistema.</p>
        <p class="small muted" style="margin:10px 0 0">Cada administrador entra con su propio usuario y su propia verificación en dos pasos; todo lo que hace queda en la auditoría con su nombre. Cada uno ve todas las empresas, también las nuevas, salvo las que el super administrador le oculte. Nadie puede quitarse a sí mismo y siempre queda al menos uno activo.</p>
      </div>
      <div class="card" v-if="!seguridad"><p class="muted">Cargando…</p></div>
      <div class="card" v-else><h2>Direcciones IP permitidas para administración <small>opcional</small></h2>
        <p class="small muted" style="margin:0 0 10px">Con la lista activa, este panel (crear cuentas, bloquear, entrar como soporte, respaldos, sitio) solo responde desde las direcciones indicadas; los clientes y sus usuarios no se ven afectados. Acepta direcciones sueltas (190.10.20.30) o rangos (200.1.0.0/24). Desde la propia máquina del servidor siempre se puede entrar, y al activarla se agrega su dirección actual para que no quede fuera.</p>
        <div class="alert" :class="seguridad.ip_admin.activa ? 'ok' : 'info'" style="margin:0 0 12px">{{seguridad.ip_admin.activa ? 'Lista ACTIVA: solo ' + seguridad.ip_admin.ips.length + ' dirección(es) pueden administrar.' : 'Lista desactivada: la administración responde desde cualquier dirección (solo con contraseña y verificación en dos pasos).'}} Su dirección actual: <b class="mono">{{seguridad.ip_actual || 'desconocida'}}</b></div>
        <template v-if="yoPrincipal"><!-- 3.87: la lista también limita al super administrador: solo él la cambia (el servidor lo exige) -->
        <Field label="Direcciones permitidas (una por línea)" help="Si su proveedor de internet le cambia la IP, agregue el rango o desactive la lista desde una dirección permitida"><textarea rows="5" class="mono" v-model="seguridadIps" placeholder="190.10.20.30&#10;200.1.0.0/24"></textarea></Field>
        <div class="row" style="gap:8px;margin-top:12px"><button class="btn sec" @click="guardarSeguridad(false)" :disabled="guardandoSeg">Guardar desactivada</button><button class="btn" @click="guardarSeguridad(true)" :disabled="guardandoSeg">Guardar y activar</button></div>
        </template>
        <p class="small muted" style="margin:0" v-else-if="admins"><span v-if="seguridad.ip_admin.ips.length">Direcciones permitidas: <span class="mono">{{seguridad.ip_admin.ips.join(', ')}}</span>. </span>Solo el super administrador cambia la lista de direcciones permitidas.</p>
      </div>
      <div class="card" v-if="renunciaMfa"><h2>Renuncia a la verificación en dos pasos <small>descargo de responsabilidad</small></h2>
        <label class="row" style="gap:10px;align-items:flex-start;cursor:pointer"><input type="checkbox" :checked="renunciaMfa.permitida" :disabled="!renunciaMfa.puede_cambiar || guardandoRenuncia" @change="guardarRenunciaMfa($event)" style="margin-top:4px"><span><b>Permitir la renuncia a la verificación en dos pasos</b><div class="small muted">Marcada, los usuarios de las empresas a quienes se les pide la verificación (Administrador, roles que cambian la configuración o los usuarios, y Recursos humanos) pueden no usarla si aceptan el descargo con su contraseña y la palabra ACEPTO; queda registrado (fecha, IP, navegador y versión del texto) y les llega una copia por correo. Cada empresa puede exigirla sin excepción. Los administradores del sistema siempre la usan. Desmarcada, ninguna renuncia vale y la verificación se vuelve a pedir de inmediato.</div></span></label>
        <p class="small muted" style="margin:8px 0 0">Texto vigente: <a class="link" :href="renunciaMfa.url" target="_blank" rel="noopener">versión {{renunciaMfa.version}}</a>.<span v-if="!renunciaMfa.puede_cambiar"> Solo el super administrador cambia esta opción.</span></p>
        <div class="table-wrap" style="margin-top:12px" v-if="renunciaMfa.renuncias.length"><table class="tbl"><thead><tr><th>Usuario</th><th>Empresas</th><th>Aceptó</th><th>Versión</th><th>Estado</th><th>Desde</th></tr></thead>
          <tbody><tr v-for="x in renunciaMfa.renuncias" :key="x.id"><td><b>{{x.nombre || x.correo}}</b><div class="small muted">{{x.correo}}</div><span class="badge danger" v-if="x.bloqueado">Bloqueado</span></td>
            <td class="small" style="white-space:normal"><div v-for="e in x.empresas" :key="e.id">{{e.nombre}} · {{e.rol}} <span class="badge info" v-if="e.sin_excepcion">sin excepción</span></div><span class="muted" v-if="!x.empresas.length">—</span></td>
            <td>{{fechaHora(x.fecha)}}</td><td class="mono">{{x.version}}</td>
            <td><span class="badge" :class="claseRenuncia(x)">{{estadoRenuncia(x)}}</span></td>
            <td class="small muted" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" :title="x.agente || ''"><span class="mono">{{x.ip || '—'}}</span> · {{x.agente || '—'}}</td></tr></tbody></table></div>
        <p class="small muted" style="margin:10px 0 0" v-else>Nadie ha renunciado a la verificación en dos pasos.</p>
      </div>
    </template>
    <template v-if="tab==='sitio'">
      <div class="card" v-if="!sitio"><p class="muted">Cargando…</p></div>
      <template v-else>
        <div class="card"><h2>Contacto <small>Se muestra en <a href="/" target="_blank">la página pública</a></small></h2>
          <div class="grid cols-3">
            <Field label="WhatsApp" help="8 dígitos, sin 506"><input v-model="sitio.contacto.whatsapp" maxlength="12"></Field>
            <Field label="Correos de ventas" help="Separados por coma; reciben las solicitudes"><input v-model="sitio.correosTxt"></Field>
            <Field label="Empresa que envía los avisos" help="Si no hay correo de la plataforma (FE_SMTP_*), se usa el servidor de correo de esta empresa"><select v-model="sitio.contacto.correo_empresa_id"><option :value="null">— Ninguna —</option><option v-for="c in cuentas" :key="c.id" :value="c.id">{{c.nombre_comercial || c.nombre}}</option></select></Field>
            <Field label="Portal de soporte (TiKe)" help="Dirección del portal de la empresa que da soporte al sistema; activa el enlace «Ayuda y soporte» del menú del usuario, que abre el portal con el correo de quien lo pide"><div class="row" style="gap:6px;align-items:center"><span class="small muted">/soporte/</span><input v-model="sitio.soporte.slug" maxlength="60" placeholder="itcoresync"></div></Field>
            <Field label="WhatsApp de soporte" help="8 dígitos, sin 506 (opcional)"><input v-model="sitio.soporte.whatsapp" maxlength="12"></Field>
          </div>
        </div>
        <div class="card"><h2>Prueba gratis automática <small>El formulario de la página crea la cuenta al instante y envía el acceso por correo</small></h2>
          <label class="row small" style="gap:6px;cursor:pointer;margin-bottom:6px"><input type="checkbox" v-model="sitio.prueba.automatica"> Crear la prueba automáticamente al recibir la solicitud</label>
          <p class="small muted" style="margin:0 0 10px">Necesita el correo de avisos de arriba (correo de la plataforma o empresa que envía los avisos): sin él, la solicitud queda para atenderla a mano. En modo automático el formulario exige empresa, cédula, teléfono, tipo de negocio y a qué se dedica. Si el correo ya tiene cuenta, la cédula ya existe o hay varias pruebas desde la misma conexión en un día, no se crea sola y la solicitud dice por qué. «Solo información» nunca crea cuenta.</p>
          <div class="grid cols-3">
            <Field label="Días de prueba" help="Entre 7 y 90"><input type="number" min="7" max="90" v-model.number="sitio.prueba.dias"></Field>
            <Field label="Turnstile de Cloudflare: clave del sitio" help="Verificación sin captcha. En Cloudflare › Turnstile cree un widget para su dominio y copie aquí la clave del sitio. Vacía = sin verificación"><input v-model="sitio.prueba.turnstile_sitio" maxlength="100" placeholder="0x4AAAAAAA…"></Field>
            <Field label="Turnstile: clave secreta" :help="sitio.prueba.turnstile_configurado ? 'Ya hay una guardada (cifrada); escriba otra solo para reemplazarla' : 'Se guarda cifrada y no se vuelve a mostrar'"><input type="password" v-model="sitio.prueba.turnstile_secreto" maxlength="120" autocomplete="new-password"></Field>
          </div>
          <div style="margin-top:12px;border-top:1px solid var(--line);padding-top:12px">
            <label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="sitio.prueba.turnstile_login" :disabled="!sitio.prueba.turnstile_sitio" @change="quitarTsPrueba"> <b>Pedir también la verificación al iniciar sesión y al recuperar la contraseña</b></label>
            <p class="small muted" style="margin:4px 0 0">Usa las mismas claves. En Cloudflare › Turnstile, la lista de dominios del widget debe tener el dominio con el que se entra a la aplicación ({{dominioActual}}). Si algún día nadie pudiera entrar por la verificación, la variable del servidor FE_TURNSTILE_LOGIN=0 la apaga sin entrar aquí.</p>
            <div v-if="pruebaTsNecesaria()" class="ts-prueba">
              <div class="small">Para activarla (o cambiarle las claves), primero la verificación tiene que pasar aquí con estas claves. Así nadie se queda sin poder entrar por una clave mal copiada.</div>
              <button class="btn sm" style="margin-top:8px" @click="probarTs">Probar la verificación</button>
              <div ref="tsPrueba" style="margin-top:8px"></div>
              <div v-if="tsPrueba" class="small" style="color:var(--ok,#15803d);margin-top:4px">✓ La verificación pasó. Ahora toque «Guardar cambios» para activarla.</div>
              <div v-if="tsPruebaError" class="small" style="color:var(--err,#b91c1c);margin-top:4px">{{tsPruebaError}}</div>
            </div>
          </div>
        </div>
        <div class="card" v-if="sitio.sistema"><h2>Nombre del sistema <small>Un solo lugar: correos, página pública y título de la aplicación</small></h2>
          <div class="grid cols-2">
            <Field label="Nombre" help="El nombre que ven los clientes en la aplicación, los correos y la página pública"><input v-model="sitio.sistema.nombre" maxlength="40"></Field>
            <Field label="Lema (opcional)"><input v-model="sitio.sistema.eslogan" maxlength="90"></Field>
            <Field label="Dominio del sistema" help="Sin https ni barras. Es el de la página pública y el de los subdominios de los negocios (mi-negocio.dominio)"><input v-model="sitio.sistema.dominio" maxlength="80" placeholder="fisitaap.com"></Field>
            <Field label="Correo de ventas" help="Aparece en los avisos de plan por vencer, prueba vencida y módulos no incluidos"><input v-model="sitio.sistema.correo_ventas" maxlength="120" placeholder="ventas@fisitaap.com"></Field>
          </div>
        </div>
        <div class="card" v-for="tipo in ['facturacion', 'comercio', 'restaurante', 'servicios']" :key="tipo"><h2>Planes de {{ {facturacion: 'Facturación', comercio: 'Punto de venta', restaurante: 'Restaurante · FISITAAP', servicios: 'Servicios e IT · TiKe'}[tipo] }} <small>Precios en colones, sin IVA</small></h2>
          <div class="grid cols-2">
            <div v-for="(p, i) in sitio.planes[tipo]" :key="i" class="card" style="margin:0">
              <div class="grid cols-2">
                <Field label="Nombre"><input v-model="p.nombre" maxlength="40"></Field>
                <Field label="Precio (₡)"><input type="number" min="0" step="100" v-model.number="p.precio"></Field>
                <Field label="Periodo"><select v-model="p.periodo"><option value="mes">Mensual</option><option value="anio">Anual (prepago)</option></select></Field>
                <Field label="Documentos"><input v-model="p.documentos" maxlength="60"></Field>
                <Field label="Usuarios / nota"><input v-model="p.usuarios" maxlength="40"></Field>
              </div>
              <Field label="Incluye (una línea por punto)" style="margin-top:8px"><textarea rows="4" v-model="p.incluyeTxt"></textarea></Field>
              <div class="row" style="justify-content:space-between;margin-top:8px"><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="p.destacado"> Plan destacado</label><button class="btn sm ghost" @click="sitio.planes[tipo].splice(i,1)">Quitar plan</button></div>
            </div>
          </div>
          <button class="btn sec sm" style="margin-top:10px" @click="nuevoPlan(tipo)" v-if="sitio.planes[tipo].length < 10">+ Agregar plan</button>
        </div>
        <div class="card"><h2>Hotelería <small>Se cobra por habitación</small></h2>
          <div class="grid cols-3">
            <Field label="Precio por habitación al mes (₡)"><input type="number" min="0" step="100" v-model.number="sitio.planes.hospitalidad.por_habitacion"></Field>
            <Field label="Mínimo de habitaciones"><input type="number" min="0" v-model.number="sitio.planes.hospitalidad.minimo"></Field>
            <Field label="Cada extra, por habitación al mes (₡)"><input type="number" min="0" step="100" v-model.number="sitio.planes.hospitalidad.extra_habitacion"></Field>
            <Field label="Paquete 40 habitaciones, todo incluido (₡)"><input type="number" min="0" step="1000" v-model.number="sitio.planes.hospitalidad.precio_40"></Field>
            <Field label="Paquete 50 habitaciones, todo incluido (₡)"><input type="number" min="0" step="1000" v-model.number="sitio.planes.hospitalidad.precio_50"></Field>
            <Field label="Canales (USD al mes)"><input type="number" min="0" v-model.number="sitio.planes.hospitalidad.canales_usd"></Field>
            <Field label="Con integración de canales (texto)"><input v-model="sitio.planes.hospitalidad.canales" maxlength="160"></Field>
          </div>
          <Field label="Incluye (una línea por punto)" style="margin-top:8px"><textarea rows="5" v-model="sitio.planes.hospitalidad.incluyeTxt"></textarea></Field>
        </div>
        <div class="card"><h2>Extras, adicionales y pago anual</h2>
          <div v-for="(a, i) in sitio.adicionales" :key="i" class="row" style="gap:8px;margin-bottom:6px"><input class="inp" v-model="a.nombre" placeholder="Adicional" style="flex:2" maxlength="70"><input class="inp" v-model="a.precio" placeholder="Precio (texto)" style="flex:1" maxlength="50"><button class="btn icon" @click="sitio.adicionales.splice(i,1)">✕</button></div>
          <button class="btn sec sm" @click="sitio.adicionales.push({nombre:'', precio:''})">+ Adicional</button>
          <Field label="Oferta de pago anual" style="margin-top:12px"><input v-model="sitio.anual" maxlength="120"></Field>
        </div>
        <div class="row end"><a class="btn ghost" href="/" target="_blank">Ver la página</a><button class="btn" @click="guardarSitio" :disabled="guardandoSitio">{{guardandoSitio ? 'Guardando…' : 'Guardar cambios'}}</button></div>
      </template>
    </template>
    <div class="card pad0" v-else-if="tab==='contactos'">
      <div class="table-wrap" v-if="contactos.length"><table class="tbl">
        <thead><tr><th>Fecha</th><th>Nombre</th><th>Contacto</th><th>Plan y origen</th><th>Mensaje</th><th>Estado</th></tr></thead>
        <tbody><tr v-for="c in contactos" :key="c.id">
          <td class="small">{{fechaHora(c.creado)}}</td>
          <td><b>{{c.nombre}}</b><div class="small muted">{{c.empresa}}</div></td>
          <td class="small"><a :href="'mailto:' + c.correo">{{c.correo}}</a><div>{{c.telefono}}</div><div v-if="c.cedula">Cédula {{c.cedula}}</div></td>
          <td>{{c.plan || '—'}}<div class="small" v-if="c.tipo_negocio">{{nombreTipo(c.tipo_negocio)}}</div><div class="small muted" v-if="c.origen">{{c.origen}}</div><div class="small muted" v-if="c.pagina">{{c.pagina}}</div></td>
          <td class="small" style="white-space:normal;max-width:340px">{{c.mensaje}}</td>
          <td><span v-if="c.empresa_id" class="badge info" style="margin-bottom:4px">Prueba creada sola · empresa {{c.empresa_id}}</span><button v-else class="btn sm sec" style="margin-bottom:4px" @click="abrirPrueba(c)">Crear prueba</button><br><button class="btn sm" :class="c.atendida ? 'ghost' : ''" @click="atender(c)">{{c.atendida ? '✓ Atendida' : 'Marcar atendida'}}</button><div class="small muted" style="white-space:normal;max-width:220px" v-if="c.resultado">{{c.resultado}}</div><div class="small muted" v-if="!c.notificada">sin aviso por correo</div></td>
        </tr></tbody>
      </table></div>
      <p class="muted" style="padding:16px" v-else>Aún no hay solicitudes desde la página.</p>
    </div>
    <div class="card pad0" v-else-if="tab==='auditoria'">
      <div class="toolbar" style="padding:12px 12px 0;gap:8px">
        <input class="search" placeholder="Buscar en la auditoría" v-model="qa">
        <select v-model="filtroEmpresa" @change="cargarAuditoria" style="max-width:260px"><option value="">Todas las empresas</option><option v-for="c in cuentas" :key="c.id" :value="c.id">{{c.nombre_comercial||c.nombre}}</option></select>
        <button class="btn sec" @click="exportar(auditoria,'auditoria_sistema')" :disabled="!auditoria.length">⤓ Exportar</button>
      </div>
      <DataTable :rows="auditoria" :columns="colAud" :search="qa" empty-title="Sin registros de auditoría"></DataTable>
    </div>
    <div class="card pad0" v-else-if="tab==='cuentas'">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar empresa, cédula o correo" v-model="q"><select v-model="filtroPago" style="max-width:280px"><option value="">Todas las cuentas</option><option value="pendiente">Con pago pendiente (en gracia o vencido)</option></select></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Empresa</th><th>Cédula</th><th>Usuarios</th><th>Ambiente</th><th class="num">Docs</th><th>Acceso</th><th>Creada</th><th></th></tr></thead>
        <tbody>
          <tr v-for="c in filtradas" :key="c.id">
            <td><b>{{c.nombre_comercial||c.nombre}}</b> <span v-if="c.es_demo" class="badge warn">Demo</span> <span v-if="c.mfa_sin_excepcion" class="badge info" title="La empresa exige la verificación en dos pasos sin excepción: la renuncia de sus usuarios no vale aquí">Verificación sin excepción</span> <span v-if="c.prueba_hasta" class="badge" :class="c.prueba_vencida ? 'danger' : 'info'">{{c.prueba_vencida ? 'Prueba vencida' : 'Prueba hasta ' + fecha(c.prueba_hasta)}}</span>
              <div class="small muted">{{c.nombre}} · {{c.correo}}</div>
              <div class="row small" style="gap:6px;margin-top:4px;align-items:center"><span class="muted">Tipo:</span><select class="inp" style="padding:2px 6px;font-size:12px" :value="c.tipo_negocio||'facturacion'" @change="cambiarTipo(c, $event.target.value)" title="Tipo de negocio: decide los módulos que ven sus usuarios. Solo el administrador del sistema lo cambia."><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></div>
              <div class="row small" style="gap:6px;margin-top:4px;align-items:center">
                <span>FISITAAP Médica {{c.medica_activa ? 'activa' : 'desactivada'}}</span>
                <button class="btn sm ghost" :disabled="guardando" @click="cambiarMedica(c)">{{c.medica_heredada ? 'Guardar activación' : (c.medica_activa ? 'Desactivar Médica' : 'Activar Médica')}}</button>
              </div>
              <div class="row small" style="gap:6px;margin-top:4px;align-items:center"><span class="muted">Plan:</span><span :class="{danger: c.plan && c.plan.vencido}">{{resumenPlan(c) || (c.plan && c.plan.nombre) || 'Sin plan (todo encendido)'}}</span><span v-if="c.plan && c.plan.vence && !c.plan.vencido && diasPara(c.plan.vence) <= 7 && diasPara(c.plan.vence) > 0" class="badge warn">vence en {{diasPara(c.plan.vence)}} días</span><span v-if="c.plan && c.plan.estado_pago === 'en_gracia'" class="badge warn" title="Pasó la fecha de vencimiento: sigue trabajando completa hasta terminar los días de gracia">En gracia hasta {{diaMes(c.plan.gracia_hasta)}}</span><span v-if="c.plan && c.plan.estado_pago === 'vencido'" class="badge danger">Vencido</span><button class="btn sm ghost" @click="abrirPlan(c)">Plan y extras</button></div>
              <div class="row small" style="gap:6px;margin-top:4px;align-items:center" v-if="c.empleados"><span class="muted">Empleados:</span><span>{{c.empleados.activos}} activo(s){{c.empleados.incluidos ? ' de ' + c.empleados.incluidos + ' incluidos' : ''}}</span><span v-if="c.empleados.excedente" class="badge warn" title="Extra de Recursos humanos: cada empleado adicional se cobra aparte">+{{c.empleados.excedente}} · {{money(c.empleados.cargo)}} al mes</span></div>
              <div v-if="c.prueba_hasta" class="row" style="gap:6px;margin-top:4px"><button class="btn sm sec" @click="extender(c, 30)">+30 días</button><button class="btn sm" @click="extender(c, 0)">Activar como cliente</button><button class="btn sm ghost" @click="eliminarPrueba(c)">Eliminar</button></div>
              <div v-else-if="c.es_demo" class="row" style="gap:6px;margin-top:4px"><button class="btn sm ghost" @click="eliminarPrueba(c)">Eliminar demo</button></div></td>
            <td class="mono">{{c.numero_id||'—'}}</td>
            <td style="white-space:normal">
              <div v-for="u in c.usuarios" :key="u.id" class="row" style="gap:6px;margin:2px 0;flex-wrap:nowrap">
                <span :class="{muted:u.bloqueado}" :style="u.bloqueado?'text-decoration:line-through':''">{{u.correo}}</span>
                <select class="inp" style="padding:2px 4px;font-size:12px;width:auto;max-width:140px;flex:none" :class="{rolAdmin: u.rol==='Administrador'}" :value="u.rol" @change="cambiarRol(c, u, $event)" title="Rol del usuario en esta empresa"><option v-for="r in rolesDe(c, u)" :key="r" :value="r">{{r}}</option></select>
                <span class="badge ok" v-if="u.mfa_activo" title="Verificación en dos pasos activa">MFA</span>
                <span class="badge warn" v-if="!u.mfa_activo && u.mfa_renuncia" :title="marcaRenuncia(u.mfa_renuncia)">{{u.mfa_renuncia.vale_aqui ? 'Sin MFA: renuncia' : 'Renuncia sin efecto'}}</span>
                <button class="btn icon" :title="u.bloqueado?'Desbloquear usuario':'Bloquear usuario'" @click="bloquearUsuario(u,!u.bloqueado)">{{u.bloqueado?'🔓':'🔒'}}</button>
                <button class="btn icon" title="Restablecer contraseña" @click="resetPassword(u)">🔑</button>
                <button class="btn icon" v-if="!esLocal && !u.bloqueado && !c.bloqueada" title="Entrar a la empresa como este usuario, para ver lo que él ve" @click="entrarComo(c,u)">👤</button>
                <button class="btn icon" title="Quitar acceso a esta empresa" @click="quitarAutorizacion(c,u)">✕</button>
              </div>
              <div v-for="u in (c.admins_sistema || [])" :key="'sa' + u.id" class="row small" style="gap:6px;margin:2px 0;flex-wrap:nowrap" title="Administrador del sistema que además es miembro de esta empresa. Su membresía la cambia solo el super administrador; dentro de la empresa siempre trabaja como Administrador.">
                <span>{{u.correo}}</span><span class="badge info">Administrador del sistema · miembro como {{u.rol}}</span>
                <button class="btn icon" v-if="u.editable" title="Quitar su membresía de esta empresa (solo el super administrador, o la suya)" @click="quitarAutorizacion(c,u)">✕</button>
              </div>
              <span class="muted small" v-if="!c.usuarios.length && !(c.admins_sistema || []).length">Sin usuarios</span>
              <div><button class="btn sm ghost" style="margin-top:4px" @click="pedirAutorizar(c)">+ Autorizar usuario</button></div>
            </td>
            <td><Badge :value="c.ambiente==='produccion'?'Producción':'Pruebas'"></Badge> <span class="small muted" v-if="c.certificado">· .p12</span></td>
            <td class="num">{{c.documentos}}</td>
            <td><Badge :value="c.bloqueada?'Bloqueada':'Activa'"></Badge><div class="small muted" v-if="c.bloqueo_motivo">{{c.bloqueo_motivo}}</div></td>
            <td class="small muted">{{fecha(c.creada)}}</td>
            <td><div class="acts">
              <button class="btn sm sec" @click="entrar(c)" title="Entrar a la empresa como soporte">Entrar</button>
              <button class="btn sm" :class="c.bloqueada?'sec':'danger'" @click="c.bloqueada?bloquear(c,false):pedirBloqueo(c)">{{c.bloqueada?'Desbloquear':'Bloquear'}}</button>
              <button class="btn icon" title="Eliminar (solo sin comprobantes)" @click="eliminar(c)" v-if="!c.documentos">🗑</button>
            </div></td>
          </tr>
        </tbody>
      </table></div>
      <Empty v-if="!filtradas.length" icon="🏢" title="Sin cuentas" text="Cree la primera cuenta de cliente con el botón “Nueva cuenta”."></Empty>
    </div>

    <Modal v-if="planForm" :title="'Plan de ' + (planCuenta.nombre_comercial || planCuenta.nombre)" @close="planForm=null">
      <p class="small muted">Tipo de negocio: <b>{{nombreTipo(planCuenta.tipo_negocio || 'facturacion')}}</b>. Sin plan, en prueba gratis o demo, la empresa tiene todo encendido. Los precios se cobran fuera del sistema; aquí solo se define qué tiene y hasta cuándo.</p>
      <div class="grid cols-2">
        <Field label="Plan"><select v-model="planForm.plan" @change="alCambiarPlan"><option value="">Sin plan (todo encendido)</option><option v-for="p in planesDe(planCuenta)" :key="p.codigo" :value="p.codigo">{{p.nombre}}{{p.documentos ? ' · ' + p.documentos + (p.periodo === 'anio' ? ' comprobantes/año' : ' comprobantes/mes') : ''}}{{p.precio ? ' · ₡' + p.precio : ''}}{{p.precio_habitacion ? ' · ₡' + p.precio_habitacion + '/habitación' : ''}}</option></select></Field>
        <Field label="Vence (AAAA-MM-DD)" help="Vacío: sin vencimiento. Vencido: la empresa solo consulta y exporta"><input v-model="planForm.vence" placeholder="2026-12-31"></Field>
        <Field label="Día de vencimiento de cada mes" :help="'Solo para esta empresa. Usar el general: ' + (generalCobro() || 'el de Pagos en línea') + '. No cambia la fecha Vence: se alinea en su siguiente pago. Con el cobro automático con tarjeta activo se conserva el día de ese cobro.'"><select v-model="planForm.plan_dia_vence"><option value="">Usar el general</option><option :value="0">Sin día fijo (conserva su fecha)</option><option v-for="n in 28" :key="n" :value="n">Día {{n}}</option></select></Field>
        <Field label="Días de gracia" help="Solo para esta empresa (0 a 60). Vacío: usar el general. En esos días después de vencer sigue trabajando completa y ve el aviso de pago pendiente"><input type="number" min="0" max="60" step="1" ref="graciaFicha" v-model="planForm.plan_dias_gracia" placeholder="Usar el general"></Field>
        <Field label="Extras" style="grid-column:1/-1"><div class="row" style="gap:14px;flex-wrap:wrap"><label v-for="x in extrasDe(planCuenta)" :key="x" class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" :value="x" v-model="planForm.extras"> {{planCfg.nombres[x] || x}}<span class="muted" v-if="planCfg.extras[x]"> ({{(planCuenta.tipo_negocio === 'hospitalidad' && planCfg.extras[x].precio_habitacion) ? '₡' + planCfg.extras[x].precio_habitacion + '/habitación' : planCfg.extras[x].precio_usd ? 'USD ' + planCfg.extras[x].precio_usd : planCfg.extras[x].precio ? '₡' + planCfg.extras[x].precio : 'cotización'}})</span></label></div></Field>
        <Field label="Paquetes de comprobantes extra" help="Comprobantes electrónicos adicionales en el periodo; solo cuentan los emitidos a Hacienda en producción (4.5)"><input type="number" min="0" v-model.number="planForm.docs_extra"></Field>
        <Field label="Inicio del prepago anual (AAAA-MM-DD)" help="Solo planes prepago; vacío = hoy al asignar"><input v-model="planForm.plan_inicio" placeholder="2026-10-19"></Field>
        <Field label="Habitaciones contratadas" help="Hotelería; 0 = sin límite"><input type="number" min="0" v-model.number="planForm.habitaciones"></Field>
        <Field label="Cajas contratadas" help="Punto de venta; 0 = las que trae el plan (básico 1, completo 2). Un número mayor = cajas adicionales"><input type="number" min="0" v-model.number="planForm.cajas"></Field>
        <Field label="Límite de usuarios" help="0 = sin límite"><input type="number" min="0" v-model.number="planForm.limite_usuarios"></Field>
        <Field label="Precio acordado (₡ por periodo, sin IVA)" help="Precio fijo para esta empresa con los paquetes que marcó arriba. Vacío = precio de lista. Es el que ve en su plan y el que se cobra con tarjeta."><input type="number" min="0" step="1" v-model.number="planForm.precio_acordado" placeholder="Precio de lista"></Field>
        <Field label="Descripción del precio acordado" help="Opcional: lo que ve la empresa en su plan"><input maxlength="120" v-model="planForm.precio_acordado_nota" placeholder="Paquete: caja + ventas en línea + recursos humanos"></Field>
      </div>
      <div class="row end" style="margin-top:12px"><button class="btn ghost" @click="planForm=null">Cancelar</button><button class="btn" @click="guardarPlan">Guardar plan</button></div>
      <h3 style="margin:18px 0 6px">Funciones en prueba</h3>
      <p class="small muted" style="margin:0 0 8px">Algo nuevo que se enciende solo en esta empresa antes que en todas (para probarlo con uno o dos clientes). Se guarda aparte del plan.</p>
      <div v-if="planCfg.funciones && Object.keys(planCfg.funciones).length">
        <label v-for="(fn, cod) in planCfg.funciones" :key="cod" class="row small" style="gap:8px;cursor:pointer;align-items:flex-start;margin-bottom:6px"><input type="checkbox" :value="cod" v-model="planForm.funciones" style="margin-top:3px"><span><b>{{fn.nombre}}</b><span class="muted" v-if="fn.nota"> · {{fn.nota}}</span></span></label>
        <div class="row end" style="margin-top:6px"><button class="btn sec" @click="guardarFunciones">Guardar funciones en prueba</button></div>
      </div>
      <p class="small muted" v-else>No hay funciones en prueba en esta versión.</p>
      <h3 style="margin:18px 0 6px">Pagos del plan</h3>
      <p class="small muted" style="margin:0 0 8px">Registre aquí cada pago recibido: el vencimiento se extiende los meses indicados desde hoy o desde el vencimiento vigente, el que sea mayor. Con día de vencimiento o días de gracia, se cuenta desde el vencimiento anterior (la gracia no se regala) y cae en el día fijo; si se atrasó más de un periodo, desde hoy. Cuando haya pasarela de pago, sus cobros entrarán aquí solos.</p>
      <div class="grid cols-3" v-if="pagoForm">
        <Field label="Fecha"><input v-model="pagoForm.fecha" placeholder="AAAA-MM-DD"></Field>
        <Field label="Monto"><input type="number" min="0" step="100" v-model.number="pagoForm.monto"></Field>
        <Field label="Moneda"><select v-model="pagoForm.moneda"><option>CRC</option><option>USD</option></select></Field>
        <Field label="Medio"><select v-model="pagoForm.medio"><option>SINPE</option><option>transferencia</option><option>tarjeta</option><option>efectivo</option><option>otro</option></select></Field>
        <Field label="Referencia"><input v-model="pagoForm.referencia" maxlength="80"></Field>
        <Field label="Meses que cubre"><input type="number" min="1" max="36" v-model.number="pagoForm.meses"></Field>
      </div>
      <div class="row end" style="margin-top:6px"><button class="btn sec" @click="registrarPago">Registrar pago y extender vencimiento</button></div>
      <div v-if="planPagos.length" style="margin-top:10px;overflow-x:auto"><table class="tbl"><thead><tr><th>Fecha</th><th class="num">Monto</th><th>Medio</th><th>Referencia</th><th class="num">Meses</th><th>Vencía</th><th>Vence</th><th>Factura</th></tr></thead>
        <tbody><tr v-for="p in planPagos" :key="p.id"><td>{{fecha(p.fecha)}}</td><td class="num">{{p.moneda}} {{p.monto}}</td><td>{{p.medio}}</td><td class="small">{{p.referencia || '—'}}</td><td class="num">{{p.meses}}</td><td>{{fechaCr(p.vence_anterior)}}</td><td>{{fechaCr(p.vence_nuevo)}}</td><td class="small"><span class="mono" v-if="p.factura_consecutivo">{{p.factura_consecutivo}}</span><template v-else><span class="muted" :title="p.factura_error || ''">{{p.factura_error ? 'Falló' : '—'}}</span> <button class="btn sm ghost" @click="facturarPagoPlan(p)">Emitir</button></template></td></tr></tbody></table></div>
    </Modal>
    <div class="alert ok" style="margin:0 0 12px;display:flex;gap:12px;align-items:flex-start;justify-content:space-between" v-if="avisoCuenta"><span>{{avisoCuenta}}</span><button class="btn sm ghost" @click="avisoCuenta=''">Cerrar</button></div>
    <Modal v-if="modal" title="Nueva cuenta de cliente" @close="modal=false;cedulaRepetida=[]">
      <p class="small muted">El cliente iniciará sesión con este correo y contraseña, deberá cambiarla al entrar y podrá completar los datos de su empresa (cédula, actividad, dirección, logo, Hacienda).</p>
      <div class="grid" style="grid-template-columns:1fr;gap:12px">
        <Field label="Nombre de la empresa" req><input v-model="f.nombre_empresa" placeholder="Hotel Montaña Verde S.A."></Field>
        <Field label="Tipo de negocio" req :help="TIPOS.find(t=>t[0]===f.tipo_negocio)[2] + ' El cliente no puede cambiarlo.'"><select v-model="f.tipo_negocio"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <label class="row"><input type="checkbox" v-model="f.medica_activa"> Habilitar FISITAAP Médica</label>
        <Field label="Cédula jurídica / física" help="Opcional; el cliente puede completarla después"><input v-model="f.numero_id" class="mono" placeholder="3101123456" @blur="revisarCedula"></Field>
        <div class="alert warn" style="margin:0" v-if="cedulaRepetida.length">Ya existe otra empresa con esta cédula: <b>{{cedulaRepetida.map(x => x.nombre_comercial || x.nombre).join(', ')}}</b>. Si es una sucursal u otra marca del mismo dueño, puede continuar; si no, revise el número.</div>
        <Field label="Nombre del contacto"><input v-model="f.nombre_contacto" placeholder="Persona que administrará la cuenta"></Field>
        <Field label="Correo de acceso" req><input type="email" v-model="f.correo" placeholder="cliente@empresa.cr"></Field>
        <Field label="Contraseña inicial" req help="Mínimo 12 caracteres. «Generar» da una fácil de teclear y de recordar (dos palabras y cuatro dígitos); el cliente la cambia al entrar."><div class="row" style="gap:6px"><input v-model="f.password" class="mono" style="flex:1"><button class="btn ghost sm" @click="generarClave">Generar</button></div></Field>
      </div>
      <div class="alert info" style="margin:12px 0 0">Al entrar por primera vez, el administrador de la cuenta deberá <b>cambiar la contraseña temporal</b>, <b>activar la verificación en dos pasos</b> (obligatoria para administradores: necesita una aplicación de códigos en su celular, como Google Authenticator) y <b>aceptar los términos del servicio</b>. Avísele para que no le tome por sorpresa.</div>
      <template #foot><button class="btn ghost" @click="modal=false;cedulaRepetida=[]">Cancelar</button><button class="btn" @click="crear" :disabled="guardando">Crear cuenta</button></template>
    </Modal>
    <Modal v-if="autorizar" :title="'Autorizar usuario en '+(autorizar.nombre_comercial||autorizar.nombre)" @close="autorizar=null">
      <p class="small muted">Un usuario solo puede entrar a las empresas donde esté autorizado explícitamente. Si el correo ya existe (por ejemplo, un contador que atiende varias empresas), solo se le agrega esta empresa con el rol indicado y conserva su contraseña; si no existe, o quedó sin ninguna empresa, entra con la contraseña inicial.</p>
      <div class="grid" style="grid-template-columns:1fr;gap:12px">
        <Field label="Correo del usuario" req><input type="email" v-model="a.correo" placeholder="contador@despacho.cr"></Field>
        <Field label="Rol en esta empresa" req><select v-model="a.rol"><option v-for="r in rolesDe(autorizar)" :key="r">{{r}}</option></select></Field>
        <Field label="Nombre (solo si es un usuario nuevo)"><input v-model="a.nombre"></Field>
        <Field label="Contraseña inicial (usuario nuevo o sin empresas)" help="Mínimo 12 caracteres; deberá cambiarla al entrar"><input v-model="a.password" class="mono"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="autorizar=null">Cancelar</button><button class="btn" @click="confirmarAutorizar">Autorizar</button></template>
    </Modal>
    <Modal v-if="bloqueo" :title="'Bloquear acceso: '+(bloqueo.nombre_comercial||bloqueo.nombre)" @close="bloqueo=null">
      <p class="small muted">Ningún usuario de esta empresa podrá entrar al sistema hasta que la desbloquee. Sus datos se conservan.</p>
      <Field label="Motivo (se muestra al cliente al intentar entrar)"><input v-model="motivo" placeholder="Ej.: Pago pendiente"></Field>
      <template #foot><button class="btn ghost" @click="bloqueo=null">Cancelar</button><button class="btn danger" @click="bloquear(bloqueo,true)">Bloquear</button></template>
    </Modal>
    <Modal v-if="demo" title="Empresa de demostración" @close="demo=null">
      <p class="small muted" style="margin-top:0">Crea una empresa marcada como demo, con nombres ficticios y datos de ejemplo del tipo elegido (clientes, ítems, ventas, cobros, compras, planilla y lo propio del tipo: caja, menú en línea, hotel o tickets). No se conecta a Hacienda. Sirve para presentar el sistema; se elimina desde la lista cuando ya no haga falta.</p>
      <div class="grid cols-2">
        <Field label="Tipo de negocio" req :help="TIPOS.find(t=>t[0]===demo.tipo)[2]"><select v-model="demo.tipo"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Meses de datos" help="1 = el último mes; más meses tardan más en crearse"><input type="number" min="1" max="12" v-model.number="demo.meses"></Field>
        <Field label="Nombre (opcional)" help="Vacío = el nombre de ejemplo del tipo" style="grid-column:1/-1"><input v-model="demo.nombre" maxlength="100" placeholder="Minisúper La Esquina Demo S.A."></Field>
      </div>
      <template #foot><button class="btn ghost" @click="demo=null">Cerrar</button><button class="btn" :disabled="creandoDemo" @click="crearDemo">{{creandoDemo ? 'Creando (puede tardar un minuto)…' : 'Crear demo'}}</button></template>
    </Modal>
    <Modal v-if="prueba" title="Prueba gratis de 1 mes" @close="prueba=null">
      <template v-if="!resultadoPrueba">
        <p class="small muted" style="margin-top:0">Crea el usuario (con contraseña temporal) y su empresa, que vence al terminar la prueba (los datos se conservan).</p>
        <div class="grid cols-2">
          <Field label="Correo" req><input type="email" v-model="prueba.correo"></Field>
          <Field label="Nombre de la persona"><input v-model="prueba.nombre" maxlength="80"></Field>
          <Field label="Nombre de su empresa" req><input v-model="prueba.nombre_empresa" maxlength="100"></Field>
          <Field label="Días de prueba"><input type="number" min="1" max="90" v-model.number="prueba.dias"></Field>
          <Field label="Tipo de negocio" req :help="TIPOS.find(t=>t[0]===prueba.tipo_negocio)[2]"><select v-model="prueba.tipo_negocio"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <label class="row"><input type="checkbox" v-model="prueba.medica_activa"> Habilitar FISITAAP Médica</label>
        </div>
        <label class="row small" style="gap:6px;margin-top:10px;cursor:pointer"><input type="checkbox" v-model="prueba.enviar_correo"> Enviarle el correo de bienvenida con el acceso</label>
      </template>
      <div v-else>
        <div class="alert ok" style="margin-top:0">Prueba lista hasta el {{fecha(resultadoPrueba.vence)}}. {{resultadoPrueba.correo_enviado ? 'Se le envió el correo de bienvenida.' : 'No se envió correo: compártale los datos de acceso.'}}</div>
        <p class="small">Acceso: <b>{{sistemaCfg().dominio}}/app</b> · Correo: <b>{{resultadoPrueba.correo}}</b><span v-if="resultadoPrueba.password_temporal"> · Contraseña temporal: <b class="mono">{{resultadoPrueba.password_temporal}}</b></span><span v-else> · (ya tenía cuenta: usa su contraseña)</span></p>
        <p class="small muted">Al entrar por primera vez se le pedirá cambiar la contraseña temporal, activar la verificación en dos pasos (obligatoria para administradores: necesita una aplicación de códigos en su celular) y aceptar los términos del servicio. Avísele para que no le tome por sorpresa.</p>
      </div>
      <template #foot><button class="btn ghost" @click="prueba=null">Cerrar</button><button v-if="!resultadoPrueba" class="btn" :disabled="creandoPrueba" @click="crearPrueba">{{creandoPrueba ? 'Creando (unos segundos)…' : 'Crear prueba'}}</button></template>
    </Modal>
  </div>`,
};
