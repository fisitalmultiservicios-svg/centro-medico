// FISITAAP by Brillante Agencia (3.77): el menú, los tipos de negocio y las reglas de visibilidad en un solo lugar. Lo usan la aplicación del ERP
// (js/app.js, con su sesión) y la aplicación de Ventas en línea (/app/fisitaap/, js/fis/app.js, con su espejo de sesión): las dos
// arman el mismo árbol, así que el usuario ve un solo menú esté donde esté. Las funciones terminadas en «De» reciben la sesión
// (s) y, cuando hace falta, la función que dice si el hotel está activo.

// Pantalla de la aplicación de Ventas en línea: enlace externo con su clave (permiso pos, como la sección; 3.87: catálogos en CLAVES_CATALOGOS)
const fis = (clave, label) => ({ label, clave, href: '/app/fisitaap/#/' + clave, permiso: CLAVES_CATALOGOS.includes(clave) ? 'catalogos' : 'pos' });
// 3.87: lo único de Ventas en línea que ve el modo cajero (Cajero, Mesero): los pedidos que se atienden desde la caja
const CLAVES_CAJA = ['pedidos', 'express-pendientes'];
// 3.87: pantallas de Ventas en línea que guardan con 'catalogos' en el servidor (el catálogo web, los cupones y la edición de Mi página:
// pedidos.gestion y promociones.gestion); un rol propio con caja y sin catálogos las veía y al guardar recibía 403
const CLAVES_CATALOGOS = ['productos', 'extras', 'opcionales', 'combos', 'promociones', 'cupones', 'publicar', 'configuracion', 'contenido', 'delivery'];

export const MENU = [
  // 3.37: reorganización aprobada por Norman (croquis 21/10). Cada módulo es una entrada propia; los catálogos y ajustes viven en
  // Configuración; las direcciones de las pantallas no cambian. El orden y los agrupamientos por tipo de negocio están en menuTipo().
  { label: 'Inicio', ico: '⌂', to: '/inicio' },
  { label: 'Ingresos', ico: '↗', permisos: ['facturar', 'cobros', 'ver_todo'], children: [   // 3.87: como dentro de Contabilidad; el técnico de soporte no factura
    { label: 'Cotizaciones', to: '/ventas/cotizaciones' },
    { label: 'Remisiones', to: '/ventas/remisiones' },
    { label: 'Facturas de venta', to: '/ventas/facturas' },
    { label: 'Facturas recurrentes', to: '/ventas/recurrentes' },
    { label: 'Notas de crédito', to: '/ventas/notas-credito' },
    { label: 'Notas de débito', to: '/ventas/notas-debito' },
    { label: 'Pagos recibidos', to: '/ventas/pagos' },
    { label: 'Reportes', to: '/reportes/de-ingresos', permisos: ['facturar', 'reportes'], modulo: 'reportes' },   // 4.1: los reportes de cada módulo
  ] },
  // 4.23: el grupo «Compras» pasa a «Gastos» (mismo permiso y mismas rutas). Compras y Gastos son el registro de lo aceptado (de ahí
  // salen los reportes y la contabilidad); Rectificaciones, lo de meses pasados que se eliminó, se volvió a registrar o cambió de tipo
  { label: 'Gastos', ico: '↙', permiso: 'gastos', children: [
    { label: 'Compras', to: '/gastos/compras' },
    { label: 'Gastos', to: '/gastos/gastos' },
    { label: 'Recepción de comprobantes', to: '/gastos/recepcion' },
    { label: 'Proveedores', to: '/contactos?tipo=Proveedor' },
    { label: 'Órdenes de compra', to: '/gastos/ordenes' },
    { label: 'Notas de débito del proveedor', to: '/gastos/notas-debito' },
    { label: 'Pagos a proveedores', to: '/gastos/pagos' },
    { label: 'Pagos recurrentes', to: '/gastos/recurrentes' },
    { label: 'Rectificaciones', to: '/gastos/rectificaciones' },
    { label: 'Reportes', to: '/reportes/de-compras', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Contactos', ico: '☺', children: [   // 4.1: submenú por tipo de contacto
    { label: 'Todos los contactos', to: '/contactos' },
    { label: 'Clientes', children: [   // 4.1: cada tipo con su lista y sus reportes
      { label: 'Lista de clientes', to: '/contactos?tipo=Cliente' },
      { label: 'Revendedoras y saldos', to: '/contactos/revendedoras', permisos: ['facturar', 'cobros', 'catalogos', 'ver_todo'] },   // 4.9: sin módulo (también sin Reportes)
      { label: 'Reportes', to: '/reportes/de-clientes', permisos: ['facturar', 'cobros', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Proveedores', children: [
      { label: 'Lista de proveedores', to: '/contactos?tipo=Proveedor' },
      { label: 'Reportes', to: '/reportes/de-proveedores', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Clientes y proveedores', children: [
      { label: 'Lista', to: '/contactos?tipo=Ambos' },
      { label: 'Reportes', to: '/reportes/de-ambos', permisos: ['facturar', 'cobros', 'gastos', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Reportes de contactos', to: '/reportes/de-contactos', permisos: ['facturar', 'gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Inventario', ico: '▦', permisos: ['catalogos', 'inventario', 'escribir', 'facturar', 'cobros', 'pos', 'gastos', 'contabilidad', 'reportes', 'documentos', 'configurar'], children: [   // 3.87: costos y valor no son para los roles operativos (el servidor los niega)
    { label: 'Ítems', to: '/inventario/items' },
    { label: 'Conteo físico', to: '/pos/inventario', permiso: 'inventario' },          // antes «Mercadería y conteo» en Punto de venta
    { label: 'Ajustes de inventario', to: '/inventario/ajustes' },
    { label: 'Traslados a otra empresa', to: '/inventario/traslados', permiso: 'inventario' },   // grupo de empresas (3.69)
    { label: 'Recetas y fichas técnicas', to: '/pos/recetas', permiso: 'catalogos' },   // antes en Punto de venta
    { label: 'Valor de inventario', to: '/inventario/valor' },
    { label: 'Por reponer', to: '/inventario/reponer', permisos: ['inventario', 'gastos', 'catalogos'] },   // 3.87: ítems en o bajo su existencia mínima (los mismos permisos que la ruta del servidor)
    { label: 'Importar y actualizar ítems', to: '/inventario/gestion', permiso: 'catalogos' },   // 3.87: todo lo de esa pantalla exige catálogos
    { label: 'Reportes', to: '/reportes/de-inventario', permisos: ['inventario', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Bancos', ico: '🏦', permiso: 'gastos', children: [
    { label: 'Bancos y cajas', to: '/bancos' },
    { label: 'Conciliaciones bancarias', to: '/bancos/conciliaciones' },
    { label: 'Reportes', to: '/reportes/de-bancos', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Contabilidad', ico: '≡', permiso: 'contabilidad', children: [
    { label: 'Asientos', to: '/contabilidad/asientos' },
    { label: 'Libro diario', to: '/contabilidad/libro-diario' },
    { label: 'Activos', to: '/contabilidad/activos' },
    { label: 'Presupuesto', to: '/contabilidad/presupuesto' },
    { label: 'Diferencial cambiario', to: '/contabilidad/diferencial' },
    { label: 'Reportes', to: '/reportes/de-contabilidad', permisos: ['contabilidad', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Recursos humanos', ico: '👥', permiso: 'rrhh', children: [
    { label: 'Empleados', to: '/rrhh/empleados' },
    { label: 'Acciones de personal', to: '/rrhh/acciones' },   // 4.21
    { label: 'Horarios de trabajo', to: '/rrhh/horarios' },
    { label: 'Marcas de asistencia', to: '/rrhh/marcas' },
    { label: 'Organigrama', to: '/rrhh/pronto/organigrama', soon: true },   // 4.42: marca «Próximamente»: lleva a su tarjeta de «Lo que viene» (RRHH_PRONTO, al final)
    { label: 'Documentos por vencer', to: '/rrhh/pronto/documentos-por-vencer', soon: true },
    { label: 'Planilla', children: [
      { label: 'Planilla del mes', to: '/rrhh/planilla' },
      { label: 'Horas extra', to: '/rrhh/horas-extra' },
      { label: 'Aguinaldo', to: '/rrhh/aguinaldo' },
      { label: 'Retenciones a terceros', to: '/rrhh/pronto/retenciones-terceros', soon: true },
      { label: 'Cierre del mes', to: '/rrhh/pronto/cierre-mes', soon: true },
    ] },
    { label: 'Novedades', children: [
      { label: 'Vacaciones', to: '/rrhh/vacaciones' },
      { label: 'Ausencias e incapacidades', to: '/rrhh/ausencias' },
      { label: 'Liquidaciones', to: '/rrhh/liquidaciones' },
    ] },
    { label: 'Configuración de RRHH', children: [   // 4.42 (L7): lo de Configuración › Recursos humanos (configuracion/hub.js), con el permiso de la sección ('/rrhh')
      { label: 'Parámetros', to: '/rrhh/parametros' },
      { label: 'Deducciones e ingresos fijos', to: '/rrhh/conceptos' },
      { label: 'Departamentos y turnos', to: '/rrhh/horarios?tab=config' },
    ] },
    { label: 'Reportes', to: '/rrhh/informes' },   // 4.1: antes «Informes» (mismo nombre en todos los módulos)
    { label: 'Lo que viene', to: '/rrhh/pronto' },   // 4.42: todo lo que está en preparación (RRHH_PRONTO)
  ] },
  { label: 'Punto de venta', ico: '🛒', permiso: 'pos', children: [
    { label: 'Caja', to: '/pos/caja' },
    { label: 'Ventas de caja', to: '/pos/ventas' },   // 4.34: todas las ventas de todas las cajas, para ver, imprimir a carta o reimprimir el tiquete
    { label: 'Cierres de caja', to: '/pos/cierres' },
    { label: 'Reportes de caja', to: '/pos/reportes', permiso: 'cobros' },   // 3.58: ventas por día, producto, categoría y hora sin necesitar el módulo Reportes
    { label: 'Reportes', to: '/reportes/de-pos', permisos: ['cobros', 'reportes'], modulo: 'reportes' },   // 4.1: ventas, servicio 10 % y propinas
    { label: 'Servicio 10 % y propinas', to: '/pos/servicio' },
    { label: 'Pantalla del cliente', to: '/pos/pantalla' },
    { label: 'Pantalla de cocina', to: '/pos/cocina' },
  ] },
  // FISITAAP (3.57): un solo módulo extra, como RRHH o Contabilidad. Todo lo del negocio en línea vive aquí: su página, el catálogo
  // o menú, los pedidos, los clientes web, las entregas (extra «entregas» dentro de FISITAAP), las promociones, el asistente y la
  // configuración. Lo genérico (Contactos, Inventario, Punto de venta) queda fuera y FISITAAP se alimenta de eso. Antes (3.47 a 3.56)
  // eran tres menús sueltos: Pedidos en línea, Promociones y Entregas.
  // 3.74: FISITAAP embebido tal cual es hoy: abre su propia aplicación (/app/fisitaap/) con su menú y sus pantallas; lo que ya existe en
  // el ERP (ítems, caja, contactos, compras, reportes, usuarios…) lo enlaza desde allá. Las rutas viejas (#/fisitaap/…) saltan a ella.
  // 3.77: Ventas en línea es una sección con sus pantallas (la aplicación embebida en /app/fisitaap/): el mismo árbol se ve en el ERP y
  // dentro de Ventas en línea. clave = pantalla de esa aplicación; permiso pos en cada entrada para que el modo cajero vea lo mismo que antes.
  { label: 'Ventas en línea', ico: '🌐', img: '/img/fisitaap-icono.svg', permiso: 'pos', modulo: 'pedidos_online', href: '/app/fisitaap/#/resumen', children: [
    fis('resumen', 'Resumen'), fis('bienvenida', 'Bienvenida'), { ...fis('configurador', 'Configurador'), permiso: 'configurar' },
    { label: 'Catálogo web', permiso: 'catalogos', children: [fis('productos', 'Productos en línea'), fis('extras', 'Extras'), fis('opcionales', 'Grupos de opcionales'), fis('combos', 'Combos'), fis('promociones', 'Promociones'), fis('cupones', 'Códigos de descuento')] },
    { label: 'Pedidos web', permiso: 'pos', children: [fis('pedidos', 'Pedidos'), { ...fis('express-pendientes', 'Express pendientes'), tipos: ['restaurante'], modulo: 'entregas' }] },   // 3.87: Express y Zonas de envío solo con el extra Entregas
    { label: 'Clientes web', permiso: 'pos', children: [fis('clientes-historial', 'Historial de clientes'), fis('fidelizacion', 'Fidelización'), fis('contactos', 'Contactos de la página'),
      { label: 'Revendedoras y saldos', to: '/contactos/revendedoras', permisos: ['facturar', 'cobros', 'catalogos', 'ver_todo'] }] },   // 4.9: pantalla del ERP (el modo cajero no la ve)
    { label: 'Mi página', permiso: 'pos', children: [fis('publicar', 'Publicar y dominio'), fis('configuracion', 'Generales'), fis('contenido', 'Diseño de la página'), { ...fis('delivery', 'Zonas de envío'), modulo: 'entregas' }, fis('kpis', 'Reportes y KPIs')] },
    { label: 'Entregas', permiso: 'pos', modulo: 'entregas', children: [fis('afiliados', 'Motorizados afiliados'), fis('invitaciones', 'Invitaciones'), fis('entregas-historial', 'Historial de entregas')] },
  ] },
  // TiKe (3.52): tickets de soporte para empresas de servicios e IT; módulo «tike» (base de Servicios, extra en Facturación y Comercio)
  { label: 'Médica', ico: '✚', children: [
    { label: 'Configurar Médica', to: '/medica/configuracion' },
    { label: 'Recepción y agenda', to: '/medica/agenda' },
    { label: 'Enfermería y consulta', to: '/medica/clinica' },
    { label: 'Órdenes y documentos', to: '/medica/ordenes' },
    { label: 'Operación y convenios', to: '/medica/gestion' },
  ] },
  { label: 'TiKe', ico: '🎫', permiso: 'tike', modulo: 'tike', children: [
    { label: 'Tablero', to: '/tike/tablero' },
    { label: 'Tickets', to: '/tike/tickets' },
    { label: 'Mis tickets (celular)', to: '/tike/mio' },
    { label: 'Contratos de soporte', to: '/tike/contratos' },
    { label: 'Equipos del cliente', to: '/tike/equipos' },
    { label: 'Documentación del cliente', to: '/tike/documentacion' },
    { label: 'Reportes', to: '/tike/reportes' },   // 4.1: mismo nombre en todos los módulos
    { label: 'Configuración de TiKe', to: '/tike/configuracion' },
  ] },
  // Hotel (Hospitalidad): cada módulo es una entrada propia (croquis 21/10). hotel: true = solo con el hotel activo; los permisos son
  // los mismos de siempre (recepción y reservas: quien opera o cobra; ama de llaves, mantenimiento y seguridad: su permiso).
  { label: 'Recepción', ico: '🛎', hotel: true, permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Tablero del día', to: '/hotel/recepcion' },
    { label: 'Calendario de habitaciones', to: '/hotel/calendario' },
    { label: 'Huéspedes', to: '/hotel/huespedes' },
    { label: 'Cuentas externas', to: '/hotel/folios' },
    { label: 'Cierre del día', to: '/hotel/cierre' },
    { label: 'Reportes', to: '/hotel/reportes' },   // 4.1: la pantalla existía pero no estaba en el menú
  ] },
  { label: 'Reservaciones', ico: '📅', hotel: true, permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Reservaciones', to: '/hotel/reservaciones' },
    { label: 'Cotizaciones', to: '/hotel/cotizaciones' },
    { label: 'Lista de espera', to: '/hotel/espera' },
    { label: 'Grupos y rooming list', to: '/hotel/grupos' },
    { label: 'Depósitos en garantía', to: '/hotel/depositos' },
    { label: 'Agencias y empresas', to: '/hotel/agencias' },
    { label: 'Histórico', to: '/hotel/historico' },   // H21: búsqueda de reservas de cualquier fecha y estado, y por habitación
    { label: 'Reportes', to: '/hotel/reportes' },
  ] },
  { label: 'Servicios', ico: '🧖', hotel: true, modulo: 'hotel_completo', permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Agenda de servicios', to: '/hotel/servicios' },
    { label: 'Liquidación a proveedores', to: '/hotel/servicios?tab=proveedores' },
  ] },
  { label: 'Eventos y banquetes', ico: '🎉', hotel: true, modulo: 'hotel_completo', permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Eventos y cotizaciones', to: '/hotel/eventos' },
    { label: 'Calendario de salones', to: '/hotel/eventos?tab=calendario' },
  ] },
  { label: 'Ama de llaves', ico: '🧹', hotel: true, permiso: 'limpieza', children: [
    { label: 'Tablero de habitaciones', to: '/hotel/ama-de-llaves/tablero' },
    { label: 'Reportes de limpieza', to: '/hotel/ama-de-llaves/incidencias' },
    { label: 'Lavandería y blancos', to: '/hotel/ama-de-llaves/lavanderia', modulo: 'hotel_completo' },
  ] },
  { label: 'Mantenimiento', ico: '🔧', hotel: true, permiso: 'mantenimiento', children: [
    { label: 'Incidencias', to: '/hotel/mantenimiento/incidencias' },
    { label: 'Habitaciones fuera de servicio', to: '/hotel/mantenimiento/habitaciones' },
    { label: 'Preventivo programado', to: '/hotel/mantenimiento/preventivo' },
  ] },
  { label: 'Seguridad', ico: '🛡', hotel: true, permiso: 'seguridad', modulo: 'hotel_completo', children: [
    { label: 'Puesto de seguridad', to: '/hotel/seguridad' },
    { label: 'Bitácora de turno', to: '/hotel/seguridad/bitacora' },
    { label: 'Visitantes y vehículos', to: '/hotel/seguridad/visitantes' },
    { label: 'Incidentes', to: '/hotel/seguridad/incidentes' },
    { label: 'Objetos perdidos', to: '/hotel/seguridad/objetos' },
  ] },
  { label: 'Reportes', ico: '▤', modulo: 'reportes', children: [   // 4.2: menú con los tipos de reporte (3.57: se oculta si el plan no lo incluye)
    { label: 'Todos los reportes', to: '/reportes' },
    { label: 'Favoritos', to: '/reportes/favoritos' },
    { label: 'Reporte ejecutivo', to: '/reportes/ejecutivo', permisos: ['reportes'] },
    { label: 'Ejecutivo por módulo', to: '/reportes/modulos' },
    { label: 'Ventas', to: '/reportes/ventas', permisos: ['facturar', 'reportes'] },
    { label: 'Administrativos', to: '/reportes/administrativos', permisos: ['gastos', 'reportes', 'inventario'] },
    { label: 'Financieros', to: '/reportes/financieros', permisos: ['reportes', 'gastos'] },
    { label: 'Contables', to: '/reportes/contables', permisos: ['contabilidad', 'reportes'] },
    { label: 'Fiscales', to: '/reportes/fiscales', permisos: ['contabilidad', 'reportes'] },
    { label: 'Punto de venta', to: '/reportes/pos', permisos: ['pos', 'reportes'], tipos: ['comercio', 'restaurante', 'hospitalidad', 'servicios'] },
    { label: 'Para trabajar', to: '/reportes/para-trabajar' },
  ] },
  { label: 'Mis tareas', ico: '✓', to: '/tareas' },
  { label: 'Configuración', ico: '⚙', to: '/configuracion' },
  { label: 'Reportar problema', ico: '⚑', accion: 'reporte', hotel: true },
];
// FISITAAP by Brillante Agencia: icono de línea de cada sección del menú (los nombres son los trazos de iconos.js)
export const ICONO_MENU = { Inicio: 'overview', Ingresos: 'sales', Gastos: 'box', Contactos: 'users', 'Contactos y fiado': 'users', Inventario: 'box', Bancos: 'wallet', Contabilidad: 'credit',
  'Recursos humanos': 'users', 'Punto de venta': 'store', 'Ventas en línea': 'store', TiKe: 'tool', Recepción: 'bed', Reservaciones: 'calendar', Servicios: 'gift', 'Eventos y banquetes': 'table',
  'Ama de llaves': 'check', Mantenimiento: 'settings', Seguridad: 'shield', Reportes: 'overview', 'Mis tareas': 'check', Configuración: 'settings', 'Reportar problema': 'help', Administración: 'shield' };

// Tipos de negocio (2.5): una sola base y tres versiones. El administrador del sistema fija el tipo al crear la cuenta y el cliente
// no lo cambia. El tipo decide qué módulos hay y en qué orden: Facturación (sin punto de venta ni hotel), Comercio (punto de venta
// primero) y Hospitalidad (todo dentro de Hotel, con el punto de venta anidado ahí).
export const TIPOS_NEGOCIO = { facturacion: 'Facturación', comercio: 'Comercio (punto de venta)', restaurante: 'Restaurante (mesas y ventas en línea)', hospitalidad: 'Hospitalidad (hotel)', servicios: 'Servicios e IT (TiKe)' };   // 3.51
const ORDEN_TIPO = {
  facturacion: ['Inicio', 'Ingresos', 'Gastos', 'Contactos', 'Inventario', 'Bancos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  comercio: ['Inicio', 'Punto de venta', 'Inventario', 'Gastos', 'Contactos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  restaurante: ['Inicio', 'Punto de venta', 'Ventas en línea', 'Inventario', 'Gastos', 'Contactos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  servicios: ['Inicio', 'TiKe', 'Ingresos', 'Gastos', 'Contactos', 'Inventario', 'Bancos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  hospitalidad: ['Inicio', 'Recepción', 'Reservaciones', 'Servicios', 'Eventos y banquetes', 'Ama de llaves', 'Mantenimiento', 'Seguridad', 'Punto de venta',
                 'Contactos', 'Inventario', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración', 'Reportar problema'],
};
const _menus = {};
export function menuTipo(tipo) {
  tipo = ORDEN_TIPO[tipo] ? tipo : 'facturacion';
  if (_menus[tipo]) return _menus[tipo];
  const por = Object.fromEntries(MENU.map(it => [it.label, it]));
  const sin = it => { const r = { ...it }; delete r.ico; delete r.permiso; delete r.permisos; return r; };
  // Comercio y Hospitalidad (croquis 21/10): Contabilidad agrupa lo administrativo (Ingresos, Bancos y, en el hotel, Gastos), porque
  // lo usa el dueño o el contador, no la caja ni la recepción. En Comercio, Gastos queda arriba: comprar mercadería es del día a día.
  const conta = (conCompras) => ({ label: 'Contabilidad', ico: '≡', permisos: ['contabilidad', 'gastos', 'facturar', 'cobros'], children: [
    { ...sin(por['Ingresos']), permisos: ['facturar', 'cobros', 'ver_todo'] },
    ...(conCompras ? [{ ...sin(por['Gastos']), permiso: 'gastos' }] : []),
    { ...sin(por['Bancos']), permiso: 'gastos' },
    ...por['Contabilidad'].children.map(c => ({ ...c, permisos: ['contabilidad'] })),   // 3.87: con «permisos» también pasa ver_todo (Solo lectura), como en Facturación
  ] });
  const lista = ORDEN_TIPO[tipo].map(l => {
    if (l === 'Contabilidad' && tipo !== 'facturacion' && tipo !== 'servicios') return conta(tipo === 'hospitalidad');   // 3.87: Servicios ya tiene Ingresos y Bancos en la raíz (salían dos veces)
    if (l === 'Contactos' && (tipo === 'comercio' || tipo === 'restaurante')) return { ...por['Contactos'], label: 'Contactos y fiado' };
    return por[l];
  }).filter(Boolean);
  // Módulos que se contratan como extra (FISITAAP, TiKe): si el orden del tipo no los lista, van antes de «Mis tareas»; el plan decide
  // si se ven (modulo:). Arreglo 3.52: en Comercio y Hospitalidad no aparecían (3.47-3.51). 3.57: FISITAAP es una sola entrada.
  const extras = ['Ventas en línea', 'TiKe', 'Médica'].filter(l => !ORDEN_TIPO[tipo].includes(l) && por[l]).map(l => por[l]);
  if (extras.length) { const i = lista.findIndex(it => it.label === 'Mis tareas'); lista.splice(i < 0 ? lista.length : i, 0, ...extras); }
  return (_menus[tipo] = lista);
}
// Secciones que solo existen en algunos tipos (el menú no las muestra y la ruta tampoco abre)
const RUTA_TIPO = [['/hotel', ['hospitalidad']], ['/pos', ['comercio', 'hospitalidad', 'restaurante']]];
export { RUTA_TIPO };
export function rutaDeOtroTipoDe(s, path) { return RUTA_TIPO.some(([pre, tipos]) => path.startsWith(pre) && !tipos.includes(s.tipo)); }

// Permiso para ABRIR cada sección (el servidor además filtra los datos). estricto: no basta 'ver_todo'.
const PERMISO_RUTA = [['/fisitaap', 'pos'], ['/pedidos', 'pos'], ['/promociones', 'pos'], ['/entregas', 'pos'], ['/tike', 'tike', true],   /* 3.57; 3.87: TiKe no se abre con ver_todo (el servidor lo niega) */ ['/rrhh', 'rrhh', true], ['/inventario/gestion', 'catalogos', true], ['/ventas/importar', 'configurar', true], ['/pos/recetas', 'catalogos'], ['/pos/reportes', 'cobros'], ['/pos/inventario', 'inventario'], ['/pos/configuracion', 'configurar', true], ['/pos', 'pos', true], ['/gastos', 'gastos'], ['/bancos', 'gastos'], ['/contabilidad', 'contabilidad'], ['/reportes/ejecutivo', 'reportes'],
  ['/configuracion/contabilidad-', 'contabilidad'], ['/configuracion/exportar', 'configurar', true], ['/configuracion/empresa', 'configurar', true], ['/configuracion/marcas', 'configurar', true], ['/configuracion/hacienda', 'configurar', true], ['/configuracion/integraciones', 'configurar', true], ['/configuracion/instalacion-local', 'configurar', true], ['/configuracion/suscripcion', 'configurar', true],   /* 3.32 */ ['/hotel/configuracion', 'configurar', true], ['/hotel/ama-de-llaves', 'limpieza'], ['/hotel/mantenimiento', 'mantenimiento'], ['/hotel/seguridad', 'seguridad']];
export { PERMISO_RUTA };
// 3.87: rutas que se abren con cualquiera de varios permisos: los mismos con que el servidor da sus datos (PERMISO_RUTA lleva uno por regla)
const PERMISO_RUTA_ALGUNO = [['/inventario/reponer', ['inventario', 'gastos', 'catalogos', 'ver_todo']],   // GET /api/inventario/reponer
  ['/inventario/traslados', ['inventario', 'gastos', 'facturar']],   // GET /api/traslados (el historial; trasladar pide inventario y facturar)
  ['/contactos/revendedoras', ['facturar', 'cobros', 'catalogos', 'ver_todo']], ['/contactos/estado-cuenta', ['facturar', 'cobros', 'catalogos', 'ver_todo']]];   // 4.9: GET /api/revendedoras y su estado de cuenta (lector_cuentas)
// 3.87: espejo de auth.PERMISOS_DOCUMENTOS: sin ninguno, el servidor niega comprobantes, pagos, costos e inventario (con_documentos)
const PERMISOS_DOCUMENTOS = ['escribir', 'pos', 'cobros', 'facturar', 'ver_todo', 'gastos', 'contabilidad', 'reportes', 'inventario', 'catalogos', 'documentos', 'configurar'];
// 3.87: permiso de cada sección de Configuración (#/configuracion/<sección>). Lo usan la portada (configuracion/hub.js, que solo
// muestra lo que el rol puede usar) y la ruta: antes la portada escondía la sección, pero escrita a mano abría con botones que daban
// 403. Con varios, los pide todos (Respaldos: configurar y usuarios, como el servidor). Lo que no está aquí sigue en PERMISO_RUTA.
export const PERMISO_CONFIG = {
  empresa: 'configurar', usuarios: 'usuarios', perfil: 'ver', 'centros-costos': 'contabilidad', monedas: 'configurar', exportar: 'configurar', respaldos: ['configurar', 'usuarios'], sucursales: 'configurar',
  hacienda: 'configurar', 'terminos-pago': 'configurar', numeraciones: 'facturar', documentos: 'documentos', vendedores: 'configurar', 'otros-cargos': 'configurar',
  plantillas: 'configurar', impuestos: 'configurar', retenciones: 'configurar', notificaciones: 'configurar', 'plantillas-correo': 'configurar', preferencias: 'ver',
  'campos-adicionales': 'catalogos', variantes: 'catalogos', integraciones: 'configurar', 'instalacion-local': 'configurar', ia: 'configurar', 'inventario-costeo': 'configurar',
  'historial-correos': 'ver_todo', 'historial-operaciones': 'ver_todo', suscripcion: ['ver_todo', 'escribir'],   /* 3.95: Administrador, Avanzado y Contador pagan el plan */
};
// Módulos que dependen del plan de la empresa (3.16): si el plan no los incluye, el menú no los muestra y la ruta tampoco abre
const RUTA_MODULO = [['/fisitaap', 'pedidos_online'], ['/pedidos', 'pedidos_online'], ['/promociones', 'pedidos_online'], ['/entregas', 'entregas'], ['/tike', 'tike'],   /* 3.57 */ ['/hotel/servicios', 'hotel_completo'], ['/hotel/eventos', 'hotel_completo'], ['/hotel/ama-de-llaves/lavanderia', 'hotel_completo'],
  ['/hotel/seguridad', 'hotel_completo'], ['/contabilidad', 'contabilidad'], ['/configuracion/contabilidad-', 'contabilidad'], ['/configuracion/centros-costos', 'contabilidad'],   /* 3.87 */ ['/rrhh', 'rrhh'], ['/reportes', 'reportes'], ['/pos', 'pos']];
export { RUTA_MODULO };
export const NOMBRES_MODULO = { contabilidad: 'Contabilidad', rrhh: 'Recursos humanos', reportes: 'Reportes', pos: 'Punto de venta', hotel_completo: 'Hotel completo (servicios, eventos, lavandería y seguridad)', canales: 'Integración de canales', pedidos_online: 'Ventas en línea', entregas: 'Ventas en línea · Entregas', tike: 'TiKe' };
export function rutaSinModuloDe(s, path) { for (const [pre, m] of RUTA_MODULO) if (path.startsWith(pre) && !s.tieneModulo(m)) return m; return null; }
// modo cajero (rol Cajero): la sesión del ERP lo trae calculado; si no, se deduce de los permisos
export function modoCajeroDe(s) { if (s.modoCajero !== undefined) return !!s.modoCajero; return s.tipo !== 'facturacion' && !s.esAdmin && s.puede('pos') && (s.permisos || []).every(p => p === 'ver' || p === 'pos'); }
// 4.5: la ruta tal como la comparan los permisos, sin codificación: #/configuracion/%68acienda esquivaba PERMISO_CONFIG y PERMISO_RUTA
// (startsWith no la reconocía) y match() sí decodificaba el parámetro, así que la pantalla abría. Si no se puede decodificar, queda como vino.
export function decodificarRuta(path) { const p = String(path || ''); try { return decodeURIComponent(p); } catch { return p; } }
export function rutaPermitidaDe(s, path) {
  path = decodificarRuta(path);
  // modo cajero (rol Cajero): solo el punto de venta y su perfil
  if (modoCajeroDe(s) && !(path.startsWith('/pos') || path === '/configuracion/perfil')) return false;
  for (const [pre, tipos] of RUTA_TIPO) if (path.startsWith(pre) && !tipos.includes(s.tipo)) return false;   // tipo de negocio (2.5)
  if (path.startsWith('/medica/')) return permiteMedica(s, path);
  if (rutaSinModuloDe(s, path)) return false;   // módulo no incluido en el plan (3.16)
  if (path.startsWith('/hotel/seguridad') && s.puede('escribir')) return true;   // 3.3
  // recepción, reservas, servicios, eventos, cierre y reportes del hotel: quien opera o cobra (3.20); ama de llaves y mantenimiento tienen lo suyo
  if (/^\/hotel\/(recepcion|reservaciones|calendario|huespedes|folios|cierre|grupos|depositos|agencias|servicios|eventos|reportes|espera|cotizaciones|historico)/.test(path)) return ['escribir', 'pos', 'cobros', 'facturar', 'ver_todo'].some(p => s.puede(p));
  // 3.87: Ingresos e Inventario no abren a los roles de un solo módulo (técnico de soporte, solo RRHH, camarera, técnico, seguridad):
  // el servidor les niega esos datos y la pantalla abría vacía con avisos 403 en vez de «Sin acceso»
  if (/^\/(ventas|inventario)(\/|$)/.test(path) && !PERMISOS_DOCUMENTOS.some(p => s.puede(p))) return false;
  for (const [pre, perms] of PERMISO_RUTA_ALGUNO) if (path.startsWith(pre)) return perms.some(p => s.puede(p));
  const seccion = path.startsWith('/configuracion/') && PERMISO_CONFIG[path.slice('/configuracion/'.length)];   // 3.87: lo mismo que la portada
  if (seccion) return [].concat(seccion).every(p => p === 'ver' || s.puede(p));   // 'ver' lo trae todo rol: Mi perfil siempre abre
  for (const [pre, perm, estricto] of PERMISO_RUTA) if (path.startsWith(pre)) return s.puede(perm) || (!estricto && s.puede('ver_todo'));
  return true;
}

// 4.7: Recursos humanos pide la verificación en dos pasos. Quien tiene el permiso en su rol pero todavía no la activó (la sesión trae
// rrhh_requiere_mfa y el servidor le quita el permiso) ve la sección con candado: una sola entrada que lleva a Mi perfil, a la tarjeta
// de la verificación, con el aviso. Al activarla, Mi perfil vuelve a leer la sesión y aparece el menú completo.
export const AVISO_RRHH_MFA = 'Active la verificación en dos pasos para ver Recursos humanos';
export const RUTA_RRHH_MFA = '/configuracion/perfil?aviso=rrhh';
// También en modo cajero: un rol propio con caja y Recursos humanos queda en modo cajero justamente porque el servidor le quitó «rrhh»
// (le falta la verificación). El Cajero de siempre nunca trae rrhh_requiere_mfa, así que para él no cambia nada.
export function rrhhConCandadoDe(s) { return !!(s && s.empresa_id && s.rrhhRequiereMfa && !s.puede('rrhh') && s.tieneModulo('rrhh')); }
export function candadoDe(s, it) { return it && it.permiso === 'rrhh' && it.children && rrhhConCandadoDe(s) ? { label: it.label, ico: it.ico, to: RUTA_RRHH_MFA, candado: true, aviso: AVISO_RRHH_MFA } : it; }

// Visibilidad del menú por módulo del plan, tipo de negocio, hotel activo y rol. hotelActivo: función (en el ERP lee los registros;
// en Ventas en línea, lo que trajo /api/arranque). La portada de aplicaciones y el cajón de Ventas en línea arman sus tarjetas y
// grupos con exactamente lo que el menú muestra a cada empresa.
const MEDICA = {
  '/medica/agenda': ['medica_recepcion'],
  '/medica/clinica': ['medica_clinica', 'medica_enfermeria'],
  '/medica/ordenes': ['medica_clinica', 'medica_laboratorio', 'medica_farmacia'],
  '/medica/gestion': ['medica_gestion'],
};
function permiteMedica(s, path) {
  if (!s.empresaInfo?.medica_activa) return false;
  if (path === '/medica/configuracion') {
    return !s.usuario?.soporte && (s.usuario?.es_superadmin || s.puede('usuarios'));
  }
  return !!s.usuario?.mfa_activo && !s.usuario?.es_superadmin && !s.usuario?.soporte && (MEDICA[path] || []).some(p => (s.permisos || []).includes(p));
}
export function hijoOkDe(s, hotelActivo, c) {
  if (c.to?.startsWith('/medica/')) return permiteMedica(s, c.to);
  if (c.modulo && !s.tieneModulo(c.modulo)) return false;
  if (c.tipos && !c.tipos.includes(s.tipo)) return false;                 // entrada de un tipo de negocio (3.77: Express pendientes solo en restaurante)
  if (c.to && !c.children) { const b = c.to.split('?')[0]; if (rutaDeOtroTipoDe(s, b) || rutaSinModuloDe(s, b)) return false; }   // p. ej. Conteo físico y Recetas solo con punto de venta (3.37)
  if (modoCajeroDe(s) && !((c.permiso === 'pos' && (!c.clave || CLAVES_CAJA.includes(c.clave))) || (c.to || '').startsWith('/pos'))) return false;   // 3.87: de Ventas en línea, solo los pedidos
  if (c.hotel && !hotelActivo()) return false;
  if (c.permiso === 'seguridad' && s.puede('escribir')) return true;   // recepción también usa el módulo de Seguridad (3.3)
  if (c.permisos) return c.permisos.some(p => s.puede(p)) || s.puede('ver_todo');
  if (!c.permiso) return true; return s.puede(c.permiso) || (!!c.children && s.puede('ver_todo'));
}
export function conHijosDe(s, hotelActivo, it) { return (it.children || []).some(c => hijoOkDe(s, hotelActivo, c) && (!c.children || conHijosDe(s, hotelActivo, c))); }
export function menuOkDe(s, hotelActivo, it) {
  if (it.label === 'Médica') return !modoCajeroDe(s) && conHijosDe(s, hotelActivo, it);
  if (it.modulo && !s.tieneModulo(it.modulo)) return false;        // módulo no incluido en el plan (3.16)
  // 4.7: Recursos humanos sin la verificación en dos pasos se muestra con candado (candadoDe), también en modo cajero. Va antes de
  // revisar los hijos: en modo cajero ninguna entrada de la sección es de la caja y el grupo se descartaba.
  if (it.permiso === 'rrhh' && rrhhConCandadoDe(s)) return true;
  if (it.hotel) return s.tipo === 'hospitalidad' && hijoOkDe(s, hotelActivo, it) && (!it.children || conHijosDe(s, hotelActivo, it));   // módulos del hotel (3.37): con el hotel activo y su permiso
  if (it.children && !conHijosDe(s, hotelActivo, it)) return false;    // grupo sin ninguna entrada visible para este rol (3.37)
  if (modoCajeroDe(s)) return it.permiso === 'pos';                     // cajero: solo el punto de venta
  if (it.permisos) return it.permisos.some(p => s.puede(p)) || s.puede('ver_todo');   // grupo con varias puertas (Contabilidad: contabilidad o gastos por Bancos)
  if (!it.permiso) return true; if (['rrhh', 'facturar', 'pos', 'configurar', 'tike'].includes(it.permiso)) return s.puede(it.permiso); return s.puede(it.permiso) || s.puede('ver_todo');   // 3.87: TiKe tampoco se abre con ver_todo
}
// El menú de la empresa activa ya filtrado a cualquier profundidad (lo que ve este usuario)
export function menuVisibleDe(s, hotelActivo) {
  if (!s.empresa_id) return [];
  const podar = items => items.filter(c => hijoOkDe(s, hotelActivo, c) && (!c.children || conHijosDe(s, hotelActivo, c))).map(c => c.children ? { ...c, children: podar(c.children) } : c);
  return menuTipo(s.tipo).filter(it => menuOkDe(s, hotelActivo, it)).map(it => candadoDe(s, it)).map(it => it.children ? { ...it, children: podar(it.children) } : it);   // 4.7: RRHH con candado
}
// 4.42: «Lo que viene» de Recursos humanos (#/rrhh/pronto y #/rrhh/pronto/<clave>, pages/rrhh/pronto.js). Una sola lista: la pantalla
// muestra todas; las que llevan menu: true salen además en el menú con la marca «Próximamente» (sus entradas, arriba en MENU, van a
// /rrhh/pronto/<clave>). Vive aquí porque menu.js no importa nada (dos pruebas lo corren solo en Node) y el service worker lo guarda.
// Textos: sin fechas ni plazos, dicen lo que hará y nunca que ya existe; no nombran bancos. «hoy» es lo que YA se puede hacer: cada
// uno se comprobó contra su pantalla (la ruta existe en ROUTES de app.js y la pantalla hace lo que dice el texto); si una pantalla
// cambia, se corrige o se quita aquí. «hoy» es { texto, ruta } o una lista de ellos cuando lo que ya existe está en varias pantallas.
// «ruta», nunca «to»: hay pruebas que cuentan to: '/rrhh/…' en este archivo. ya: al entregar una, su ruta real (la tarjeta lleva allá
// y el índice deja de mostrarla). Lista de pago y Comprobantes para imprimir no están aquí: se entregan en la 4.42.
export const GRUPOS_PRONTO = ['Personal', 'Asistencia', 'Planilla y pagos', 'Vacaciones y salidas', 'Documentos', 'Reportes', 'Portal del empleado', 'Selección de personal', 'Avisos'];
export const RRHH_PRONTO = [
  { clave: 'organigrama', grupo: 'Personal', etiqueta: 'Organigrama', menu: true, descripcion: 'Verá quién reporta a quién en su empresa, con el jefe inmediato de cada empleado.',
    que_hara: ['Elegir el jefe inmediato de cada empleado de la lista de empleados.', 'Ver el organigrama completo o por departamento.'], hoy: { texto: 'Anotar el jefe inmediato de cada empleado en su ficha, en Empleados.', ruta: '/rrhh/empleados' } },
  { clave: 'reingreso', grupo: 'Personal', etiqueta: 'Reingreso con nuevo contrato', descripcion: 'Podrá volver a contratar a una o a varias personas con una nueva fecha de ingreso.',
    que_hara: ['Reingresar a quien ya trabajó en la empresa, con nueva fecha de ingreso.', 'Reingresar a varios a la vez, por ejemplo al iniciar una temporada.'],
    hoy: { texto: 'Volver a activar a la persona desde su ficha, en Empleados, y cambiarle la fecha de ingreso.', ruta: '/rrhh/empleados' } },
  { clave: 'ingreso-salida', grupo: 'Personal', etiqueta: 'Lista de ingreso y salida', descripcion: 'Tendrá una lista de pasos para no olvidar nada cuando alguien entra a la empresa o se va.',
    que_hara: ['Pasos para cuando alguien entra: contrato, documentos y accesos.', 'Pasos para cuando alguien se va: liquidación y devolución de lo que se le entregó.', 'Marcar cada paso como hecho y ver lo que falta.'] },
  { clave: 'resumen-empleado', grupo: 'Personal', etiqueta: 'Resumen completo del empleado', descripcion: 'Verá todo lo de un empleado en una sola pantalla.',
    que_hara: ['La ficha, las acciones de personal, las vacaciones, las ausencias y los pagos juntos.', 'Descargar el resumen.'] },
  { clave: 'mas-datos-ficha', grupo: 'Personal', etiqueta: 'Más datos en la ficha', descripcion: 'La ficha guardará el género, el estado civil y la ocupación del INS de cada empleado.',
    que_hara: ['Registrar el género y el estado civil.', 'Elegir la ocupación del catálogo del INS.', 'Usar esos datos en los reportes.'] },
  { clave: 'calidad-datos', grupo: 'Personal', etiqueta: 'Calidad de datos de las fichas', descripcion: 'Verá qué le falta a cada ficha antes de calcular la planilla o presentar reportes.',
    que_hara: ['Una lista de las fichas con datos que faltan o que conviene revisar.', 'Ir directo a corregir cada ficha.'],
    hoy: { texto: 'Ver los avisos de «Requiere atención» en Empleados.', ruta: '/rrhh/empleados' } },
  { clave: 'aprobacion-acciones', grupo: 'Personal', etiqueta: 'Aprobación de acciones por otro usuario', descripcion: 'Otro usuario podrá aprobar un aumento o un cambio de puesto antes de que se aplique a la ficha.',
    que_hara: ['Elegir qué acciones de personal piden aprobación.', 'Quien aprueba ve las pendientes y las aprueba o las rechaza con su motivo.', 'Queda constancia de quién aprobó.'] },
  { clave: 'acciones-automaticas', grupo: 'Personal', etiqueta: 'Acciones que se aplican solas en su fecha', descripcion: 'Si usted lo activa, una acción de personal con fecha futura se aplicará a la ficha al llegar su fecha.',
    que_hara: ['Una opción para que las acciones se apliquen solas en su fecha.', 'Un aviso de lo que se aplicó.'],
    hoy: { texto: 'Ver en Acciones de personal las que están pendientes de aplicar y aplicarlas con el botón «Aplicar».', ruta: '/rrhh/acciones' } },
  { clave: 'descanso-trabajado', grupo: 'Asistencia', etiqueta: 'Día de descanso trabajado', descripcion: 'La planilla pagará el día de descanso que el empleado trabajó.',
    que_hara: ['Registrar el día de descanso trabajado.', 'Sumarlo en la planilla del período.'],
    hoy: { texto: 'Registrar en Horas extra las horas trabajadas en feriado; la planilla las paga.', ruta: '/rrhh/horas-extra' } },
  { clave: 'marcas-ausencias', grupo: 'Asistencia', etiqueta: 'Marcas en días de vacaciones o incapacidad', descripcion: 'Le avisará cuando alguien marque asistencia un día en que está de vacaciones o incapacitado.',
    que_hara: ['Un aviso en el resumen de asistencia.', 'Revisar y corregir la marca o la ausencia.'] },
  { clave: 'retenciones-terceros', grupo: 'Planilla y pagos', etiqueta: 'Retenciones a terceros', menu: true, descripcion: 'Tendrá un reporte de lo que se rebaja a los empleados para pagarle a otros: embargos, pensiones alimentarias y asociación solidarista.',
    que_hara: ['Totales por tipo de retención y por empleado.', 'Elegir el período.', 'Descargar el reporte.'] },
  { clave: 'cierre-mes', grupo: 'Planilla y pagos', etiqueta: 'Cierre del mes', menu: true, descripcion: 'Verá una lista de lo que falta para cerrar el mes de Recursos humanos.',
    que_hara: ['Ver lo pendiente: planillas sin pagar, novedades sin revisar y cargas sociales sin pagar.', 'Ir a cada pantalla para resolverlo.'] },
  { clave: 'archivo-banca', grupo: 'Planilla y pagos', etiqueta: 'Archivo para su banca en línea', descripcion: 'Tendrá un archivo con las transferencias de la planilla para subirlo a su banca en línea.',
    que_hara: ['Armar el archivo con la cuenta IBAN y el monto de cada empleado.', 'Subirlo a su banca en línea para pagarles a todos de una vez.'],
    hoy: { texto: 'Marcar la planilla como pagada en Planilla del mes; el pago queda registrado en Bancos.', ruta: '/rrhh/planilla' } },
  { clave: 'rebajos-lote', grupo: 'Planilla y pagos', etiqueta: 'Rebajos por lote y desde Excel', descripcion: 'Podrá aplicar un mismo rebajo a varios empleados a la vez, o cargarlos desde una hoja de Excel.',
    que_hara: ['Elegir varios empleados y aplicarles el mismo rebajo.', 'Cargar los rebajos desde una hoja de Excel.'],
    hoy: { texto: 'Registrar deducciones e ingresos fijos empleado por empleado.', ruta: '/rrhh/conceptos' } },
  { clave: 'consumo-empleados', grupo: 'Planilla y pagos', etiqueta: 'Consumo de empleados', descripcion: 'Lo que un empleado consuma en la caja se rebajará de su planilla.',
    que_hara: ['Cargar el consumo a la cuenta del empleado desde la caja.', 'Rebajarlo en la planilla del período.'] },
  { clave: 'proyeccion-aguinaldo', grupo: 'Planilla y pagos', etiqueta: 'Proyección del aguinaldo', descripcion: 'Verá un estimado, mes a mes, de lo que habrá que pagar de aguinaldo.',
    que_hara: ['El estimado por empleado y el total.', 'Prever el pago con tiempo.'],
    hoy: { texto: 'Calcular en Aguinaldo el pago del año con las planillas pagadas y registrarlo.', ruta: '/rrhh/aguinaldo' } },
  { clave: 'comparar-salida', grupo: 'Vacaciones y salidas', etiqueta: 'Comparar motivos de salida', descripcion: 'Verá cuánto costaría cada motivo de salida, lado a lado, sin guardar nada.',
    que_hara: ['Calcular la liquidación con cada motivo de salida.', 'Ver las diferencias lado a lado; es solo un estimado y no se guarda.'],
    hoy: { texto: 'Calcular en Liquidaciones la liquidación con un motivo de salida a la vez.', ruta: '/rrhh/liquidaciones' } },
  { clave: 'liquidacion-grupo', grupo: 'Vacaciones y salidas', etiqueta: 'Liquidación de grupo', descripcion: 'Podrá liquidar a varias personas a la vez, por ejemplo al cerrar una temporada.',
    que_hara: ['Elegir a varios empleados y calcular sus liquidaciones juntas.', 'Revisarlas antes de guardarlas.'],
    hoy: { texto: 'Liquidar en Liquidaciones a cada persona por separado.', ruta: '/rrhh/liquidaciones' } },
  { clave: 'suspension-sin-goce', grupo: 'Vacaciones y salidas', etiqueta: 'Suspensión sin goce', descripcion: 'La suspensión registrada como acción de personal rebajará esos días en la planilla.',
    que_hara: ['Indicar en la suspensión si es sin goce de salario.', 'Rebajar esos días en la planilla del período.'],
    hoy: [{ texto: 'Registrar la suspensión, con sus fechas, en Acciones de personal; solo deja constancia.', ruta: '/rrhh/acciones' }, { texto: 'Registrar el permiso sin goce de salario en Ausencias e incapacidades; la planilla descuenta esos días.', ruta: '/rrhh/ausencias' }] },
  { clave: 'accidentes', grupo: 'Vacaciones y salidas', etiqueta: 'Registro de accidentes de trabajo', descripcion: 'Llevará un registro interno de cada accidente de trabajo, ligado a la incapacidad del INS.',
    que_hara: ['Registrar qué pasó, dónde y quiénes lo vieron.', 'Ligar el accidente a su incapacidad.'],
    hoy: { texto: 'Registrar la incapacidad por riesgo del trabajo (INS) en Ausencias e incapacidades.', ruta: '/rrhh/ausencias' } },
  { clave: 'contrato-cartas', grupo: 'Documentos', etiqueta: 'Contrato y cartas con texto propio', descripcion: 'El sistema llenará el contrato y las cartas con los datos de cada empleado, con el texto de su empresa.',
    que_hara: ['Guardar el texto de su contrato y de sus cartas.', 'Llenarlos con los datos del empleado y descargarlos.'],
    hoy: [{ texto: 'Descargar la constancia salarial de un empleado desde Empleados.', ruta: '/rrhh/empleados' },
      { texto: 'Descargar cada acción de personal, con espacio para las firmas, desde Acciones de personal.', ruta: '/rrhh/acciones' },
      { texto: 'Descargar la liquidación con «Recibí conforme» desde Liquidaciones.', ruta: '/rrhh/liquidaciones' }] },
  { clave: 'capacitaciones', grupo: 'Documentos', etiqueta: 'Capacitaciones y carnés de todo el personal', descripcion: 'Verá una lista de los cursos y carnés de todo el personal, con su vencimiento.',
    que_hara: ['Registrar los cursos y carnés de cada empleado.', 'Ver los que están por vencer.'],
    hoy: { texto: 'Subir a la ficha de cada empleado sus documentos, con fecha de vencimiento y aviso.', ruta: '/rrhh/empleados' } },
  { clave: 'documentos-por-vencer', grupo: 'Documentos', etiqueta: 'Documentos por vencer', menu: true, descripcion: 'Verá en una sola lista los documentos y contratos del personal que están por vencer.',
    que_hara: ['Todo lo que vence, de todos los empleados, en un solo lugar.', 'Filtrar por tipo de documento y por fecha.', 'Descargar la lista.'],
    hoy: { texto: 'Ver en Empleados los avisos de lo que vence y, en cada ficha, los documentos con su fecha de vencimiento.', ruta: '/rrhh/empleados' } },
  { clave: 'ausentismo-empleado', grupo: 'Reportes', etiqueta: 'Ausentismo por empleado', descripcion: 'Verá quiénes acumulan más ausencias injustificadas y permisos sin goce.',
    que_hara: ['Los empleados ordenados por ausencias injustificadas y permisos sin goce.', 'Las incapacidades y licencias, aparte y solo como totales.'],
    hoy: { texto: 'Ver el ausentismo por tipo de ausencia en Reportes › Indicadores.', ruta: '/rrhh/informes?ver=indicadores' } },
  { clave: 'antiguedad-vacaciones', grupo: 'Reportes', etiqueta: 'Antigüedad y vacaciones del personal', descripcion: 'Verá en un solo reporte la antigüedad de cada empleado y sus vacaciones ganadas, disfrutadas y pendientes.',
    que_hara: ['Un solo reporte de todo el personal, con la antigüedad junto a las vacaciones.', 'Descargarlo.'],
    hoy: { texto: 'Ver en Vacaciones los días ganados, los disfrutados y el saldo de cada empleado.', ruta: '/rrhh/vacaciones' } },
  { clave: 'revision-presentar', grupo: 'Reportes', etiqueta: 'Revisión antes de presentar', descripcion: 'Le mostrará errores y datos que faltan antes de presentar la planilla a la CCSS y al INS.',
    que_hara: ['Revisar identificaciones, ocupaciones y salarios.', 'Ir a corregir cada dato.'] },
  { clave: 'archivos-sicere', grupo: 'Reportes', etiqueta: 'Archivos en el formato de SICERE y RT-Virtual', descripcion: 'Descargará un archivo con el formato que pide cada sitio para cargar la planilla.',
    que_hara: ['Un archivo para SICERE y otro para RT-Virtual.', 'Revisar los datos antes de descargarlos.'],
    hoy: { texto: 'Descargar en CSV los datos de la planilla del mes desde Reportes.', ruta: '/rrhh/informes' } },
  { clave: 'panel-rrhh', grupo: 'Reportes', etiqueta: 'Panel de Recursos humanos', descripcion: 'Verá un resumen para la gerencia: personal, costo de la planilla, ausentismo y pendientes.',
    que_hara: ['Las cifras principales en una sola pantalla.', 'Ir al detalle de cada una.'],
    hoy: { texto: 'Ver en Reportes › Indicadores el costo de la planilla por departamento, el ausentismo y la rotación.', ruta: '/rrhh/informes?ver=indicadores' } },
  { clave: 'compensacion-anual', grupo: 'Reportes', etiqueta: 'Compensación total anual', descripcion: 'Verá todo lo que recibió cada empleado en el año: salario, extras, aguinaldo y otros pagos.',
    que_hara: ['Un reporte por empleado y por año.', 'Descargarlo.'],
    hoy: { texto: 'Ver en Reportes el costo de cada empleado en el mes.', ruta: '/rrhh/informes' } },
  { clave: 'portal', grupo: 'Portal del empleado', etiqueta: 'Portal del empleado', descripcion: 'Cada empleado podrá ver sus comprobantes de pago, sus vacaciones y sus marcas.',
    que_hara: ['Una entrada propia para cada empleado.', 'Sus comprobantes, su saldo de vacaciones y sus marcas.'] },
  { clave: 'solicitud-vacaciones', grupo: 'Portal del empleado', etiqueta: 'Solicitud de vacaciones', descripcion: 'El empleado pedirá sus vacaciones y su jefe las aprobará.',
    que_hara: ['El empleado pide los días.', 'Su jefe los aprueba o los rechaza.', 'Lo aprobado queda en Vacaciones.'] },
  { clave: 'marcar-telefono', grupo: 'Portal del empleado', etiqueta: 'Marcar desde el teléfono propio', descripcion: 'El empleado podrá marcar su entrada y su salida desde su propio teléfono.',
    que_hara: ['Marcar desde el teléfono del empleado.', 'Las marcas llegan al resumen de asistencia.'],
    hoy: { texto: 'Activar un quiosco en un equipo del negocio: los empleados marcan ahí con su código y su clave.', ruta: '/rrhh/marcas?tab=quiosco' } },
  { clave: 'incapacidades-empleado', grupo: 'Portal del empleado', etiqueta: 'Incapacidades enviadas por el empleado', descripcion: 'El empleado enviará la boleta de su incapacidad y Recursos humanos la confirmará.',
    que_hara: ['El empleado envía la foto de la boleta.', 'Recursos humanos la revisa y la registra.'] },
  { clave: 'actualizacion-datos', grupo: 'Portal del empleado', etiqueta: 'Actualización de datos', descripcion: 'El empleado pedirá cambiar sus datos y Recursos humanos aprobará el cambio.',
    que_hara: ['El empleado pide el cambio.', 'Recursos humanos lo aprueba o lo rechaza.'] },
  { clave: 'candidatos', grupo: 'Selección de personal', etiqueta: 'Candidatos', descripcion: 'Llevará a los candidatos por etapa y los contratará con un clic.',
    que_hara: ['Los candidatos de cada puesto, por etapa.', 'Contratar a uno y crear su ficha con lo que ya se tiene.'] },
  { clave: 'vencimientos-correo', grupo: 'Avisos', etiqueta: 'Vencimientos por correo', descripcion: 'Le avisará por correo de los documentos y contratos por vencer.',
    que_hara: ['Un correo con lo que está por vencer.', 'Elegir quién lo recibe.'],
    hoy: { texto: 'Ver en Empleados los avisos de contratos y documentos vencidos o por vencer.', ruta: '/rrhh/empleados' } },
];
export function prontoDe(clave) { return RRHH_PRONTO.find(p => p.clave === clave) || null; }
export function hoyDe(p) { return [].concat((p && p.hoy) || []); }   // lo que hoy ya se puede hacer, siempre como lista de { texto, ruta }
