import { sesion } from '../../app.js';

export default {
  computed: {
    empresa() { return sesion.empresaInfo; },
    esAdminSistema() { return sesion.esAdmin; },
  },
  template: `
    <div class="page">
      <PageHead title="Configurar Médica" :crumbs="[{label:'Médica'}]"></PageHead>
      <section class="card">
        <h2>{{empresa?.nombre_comercial || empresa?.nombre}}</h2>
        <p>FISITAAP Médica activa para esta empresa.</p>
        <p>En Usuarios, asigna a cada persona su rol de Médica. Por ejemplo, asigna <b>Médica · Recepción y agenda</b> para gestionar pacientes y citas.</p>
        <p>Las pantallas de trabajo aparecen al iniciar sesión directamente con la cuenta del personal, con la verificación en dos pasos activa.</p>
        <div class="acts">
          <a class="btn" href="#/configuracion/usuarios">Usuarios y roles</a>
          <a v-if="esAdminSistema" class="btn sec" href="#/admin">Administración de cuentas</a>
        </div>
      </section>
    </div>`,
};
