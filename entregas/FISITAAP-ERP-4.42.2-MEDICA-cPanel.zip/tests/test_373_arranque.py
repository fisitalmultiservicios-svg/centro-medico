"""3.73: una sola llamada al entrar (/api/arranque) con lo mismo que devolvían las llamadas sueltas; ventas de caja de más de N días
fuera de la carga inicial (y completas al pedirlas); medidor Server-Timing; caché de librerías y fuentes; índices nuevos."""
import json
import os
import types
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlmodel import Session, select

from app import auth, modulos
from app.config import ahora_cr
from app.db import Empresa, engine, engine_empresa, init_db
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

PW = "Clave-Segura-373!"


def _usuario_real(sufijo: str, rol: str = "Vendedor", debe_cambiar: bool = False):
    """Empresa + usuario con contraseña real (sin MFA: el rol no la exige), listo para entrar por /api/auth/login."""
    from app.main import app
    init_db()
    correo = f"arranque{sufijo}@example.test"
    with Session(engine) as s:
        for e in s.exec(select(Empresa).where(Empresa.nombre == f"Arranque QA {sufijo} S.A.")).all():
            s.delete(e)
        for u in s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).all():
            for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(m)
            s.delete(u)
        s.commit()
        e = auth.crear_empresa(s, f"Arranque QA {sufijo} S.A.", f"empresa{sufijo}@example.test", f"31013733{int(sufijo):02d}", tipo_negocio="comercio", factura_electronica=False)
        u = auth.Usuario(correo=correo, nombre="Usuario Arranque", password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION,
                         terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, debe_cambiar_password=debe_cambiar)
        s.add(u); s.commit(); s.refresh(u)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()
        for x in s.exec(select(auth.IntentoIp)).all():      # otra prueba pudo agotar el límite de ingresos de esta IP
            s.delete(x)
        s.commit()
        eid = e.id
    auth._intentos_ip.clear()
    c = TestClient(app)
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 200, r.text
    j = r.json()
    assert not j.get("mfa_requerido")
    tok = j["token"]
    if j.get("empresa_id") != eid:
        tok = c.post("/api/auth/empresa", headers={"Authorization": f"Bearer {tok}"}, json={"empresa_id": eid}).json()["token"]
    return c, eid, {"Authorization": f"Bearer {tok}"}


def test_arranque_trae_lo_mismo_que_las_llamadas_sueltas():
    c, eid, H = _usuario_real("01")
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "categorias", [{"id": 1, "nombre": "Abarrotes"}], [], [1]); s.commit()
    r = c.get("/api/arranque", headers=H)
    assert r.status_code == 200, r.text
    a = r.json()
    assert set(a) >= {"yo", "empresa", "clientes", "productos", "registros"}
    yo = c.get("/api/auth/yo", headers=H).json()
    assert a["yo"]["empresa_id"] == eid and a["yo"]["usuario"]["correo"] == "arranque01@example.test" and a["yo"]["permisos"] == yo["permisos"]
    assert a["empresa"] == c.get("/api/empresa", headers=H).json()
    assert a["clientes"] == c.get("/api/clientes", headers=H).json() and a["productos"] == c.get("/api/productos", headers=H).json()
    rr = c.get("/api/registros?v=2", headers=H); reg = rr.json()
    assert rr.status_code == 200 and "datos" in reg, (rr.status_code, rr.text[:300])
    assert a["registros"]["datos"] == reg["datos"] and a["registros"]["versiones"] == reg["versiones"] and set(a["registros"]) == {"datos", "versiones", "topes", "rango", "parciales"}
    assert a["registros"]["datos"]["categorias"] == [{"id": 1, "nombre": "Abarrotes"}] and "compras" not in a["registros"]["datos"]   # un Vendedor no ve gastos
    assert "tipo_cambio" not in a or isinstance(a["tipo_cambio"], dict)
    assert r.headers.get("server-timing", "").startswith("app;dur=")
    # con gzip aceptado viaja comprimido y con el mismo contenido
    rz = c.get("/api/arranque", headers={**H, "Accept-Encoding": "gzip"})
    assert rz.headers.get("content-encoding") == "gzip" and rz.json()["registros"]["datos"] == a["registros"]["datos"]


def test_arranque_solo_sesion_si_la_empresa_no_esta_lista():
    c, eid, H = _usuario_real("02", debe_cambiar=True)
    a = c.get("/api/arranque", headers=H).json()
    assert a["yo"]["usuario"]["debe_cambiar_password"] and "empresa" not in a and "registros" not in a
    assert c.get("/api/arranque").status_code == 401


def test_ventana_de_ventas_de_caja(api, monkeypatch):  # noqa: F811
    from app.main import app
    c = api
    ctx = app.dependency_overrides[auth.contexto](); eid = ctx.empresa.id
    hoy = ahora_cr()
    vieja = (hoy - timedelta(days=200)).isoformat(timespec="seconds"); reciente = (hoy - timedelta(days=3)).isoformat(timespec="seconds")
    ventas = [{"id": 1, "caja_id": 1, "total": 1000, "hora": vieja}, {"id": 2, "caja_id": 1, "total": 2000, "hora": reciente}, {"id": 3, "caja_id": 1, "total": 3000}]
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_ventas", ventas, [], [1, 2, 3]); s.commit()
    monkeypatch.setenv("FE_VENTANA_POS_DIAS", "90")
    j = c.get("/api/registros?v=2", headers={"Accept-Encoding": "identity"}).json()
    assert [v["id"] for v in j["datos"]["pos_ventas"]] == [2, 3]                       # la vieja no viene; la que no tiene fecha sí
    assert j["parciales"] == {"pos_ventas": {"desde": (hoy.date() - timedelta(days=90)).isoformat(), "omitidos": 1}}
    completa = c.get("/api/registros/pos_ventas").json()
    assert [v["id"] for v in completa["datos"]] == [1, 2, 3]                            # la clave sola siempre viene completa
    assert [v["id"] for v in c.get("/api/registros", headers={"Accept-Encoding": "identity"}).json()["pos_ventas"]] == [1, 2, 3]   # versión anterior: sin ventana
    monkeypatch.setenv("FE_VENTANA_POS_DIAS", "0")
    j0 = c.get("/api/registros?v=2", headers={"Accept-Encoding": "identity"}).json()
    assert [v["id"] for v in j0["datos"]["pos_ventas"]] == [1, 2, 3] and j0["parciales"] == {}


def test_cabeceras_indices_y_precarga(api):  # noqa: F811
    from app.main import app
    c = api
    ctx = app.dependency_overrides[auth.contexto]()
    app.dependency_overrides[auth.solo_usuario] = lambda: ctx.usuario
    assert c.get("/api/version").headers.get("server-timing", "").startswith("app;dur=")
    v = c.get("/js/vendor/vue.esm-browser.prod.min.js")
    assert v.status_code == 200 and v.headers["cache-control"] == "public, max-age=604800"
    assert c.get("/js/app.js").headers["cache-control"] == "no-cache" and c.get("/api/clientes").headers["cache-control"] == "no-store"
    assert c.get("/fonts/inter-latin.woff2").headers["cache-control"] == "public, max-age=604800"
    html = c.get("/app/").text
    assert html.count('rel="modulepreload"') == 9 and 'href="/js/api.js"' in html and 'rel="preload" href="/fonts/inter-latin.woff2"' in html   # 3.87: + iconos.js y menu.js
    sw = c.get("/sw-app.js").text
    from app import version as _version
    assert f"const VERSION = 'app-v{_version.actual()['version']}'" in sw and "'/api/arranque'" in sw and "PROGRAMA" in sw
    with engine_empresa(ctx.empresa.id).connect() as con:
        indices = {r[1] for r in con.execute(text("PRAGMA index_list('documento')")).all()}
    assert {"ix_documento_fecha_emision", "ix_documento_cliente_id", "ix_documento_estado"} <= indices
