"""Recepción y consulta de FISITAAP Médica."""
from datetime import date, datetime, time, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field, StringConstraints, field_validator, model_validator
from sqlalchemy import DateTime, UniqueConstraint, or_, text
from sqlmodel import Field as Column, Session, SQLModel, select

from . import auth, secretos
from .config import ahora_cr
from .db import por_empresa
from .medica_config import CLINICA, ENFERMERIA, RECEPCION, habilitada

def _privada(response: Response):
    response.headers["Cache-Control"] = "private, no-store"


router = APIRouter(prefix="/api/medica", dependencies=[Depends(_privada)])
Nombre = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=160)]


class Paciente(SQLModel, table=True):
    __tablename__ = "medica_paciente"
    __table_args__ = (UniqueConstraint("sede", "documento"), {"sqlite_autoincrement": True})

    id: int | None = Column(default=None, primary_key=True)
    sede: int = Column(index=True)
    documento: str
    nombre: str
    nacimiento: date
    telefono: str
    correo: str
    cliente_id: int | None = None
    datos_administrativos: str | None = None


class Cita(SQLModel, table=True):
    __tablename__ = "medica_cita"
    __table_args__ = {"sqlite_autoincrement": True}

    id: int | None = Column(default=None, primary_key=True)
    sede: int = Column(index=True)
    paciente_id: int = Column(foreign_key="medica_paciente.id")
    profesional_id: int = Column(index=True)
    consultorio: str
    inicio: datetime = Column(index=True, sa_type=DateTime)
    fin: datetime = Column(sa_type=DateTime)
    estado: str = "programada"
    llegada: datetime | None = Column(default=None, sa_type=DateTime)
    modalidad: str = "presencial"
    tipo_atencion: str = "consulta"
    ubicacion: str | None = None
    inicio_atencion: datetime | None = Column(default=None, sa_type=DateTime)
    fin_atencion: datetime | None = Column(default=None, sa_type=DateTime)


class Consulta(SQLModel, table=True):
    __tablename__ = "medica_consulta"

    cita_id: int = Column(primary_key=True, foreign_key="medica_cita.id")
    profesional_id: int
    motivo: str
    diagnostico: str
    plan: str
    registrada: datetime = Column(sa_type=DateTime)
    cie: str | None = None
    cifrada: bool = False


class Evento(SQLModel, table=True):
    __tablename__ = "medica_evento"
    __table_args__ = {"sqlite_autoincrement": True}

    id: int | None = Column(default=None, primary_key=True)
    usuario_id: int
    accion: str
    recurso_id: int
    fecha: datetime = Column(sa_type=DateTime)


por_empresa(Paciente, Cita, Consulta, Evento)


class PacienteIn(BaseModel):
    documento: Annotated[str, StringConstraints(strip_whitespace=True, min_length=3, max_length=32)]
    nombre: Nombre
    nacimiento: date
    telefono: str = Field(default="", max_length=40)
    correo: str = Field(default="", max_length=160)

    @field_validator("documento")
    @classmethod
    def normalizar_documento(cls, valor):
        normalizado = "".join(c for c in valor.upper() if c.isalnum())
        if len(normalizado) < 3:
            raise ValueError("Documento inválido")
        return normalizado

    @field_validator("nacimiento")
    @classmethod
    def validar_nacimiento(cls, valor):
        if valor > ahora_cr().date():
            raise ValueError("Fecha de nacimiento futura")
        return valor


class CitaIn(BaseModel):
    paciente_id: int
    profesional_id: int
    consultorio: Nombre
    inicio: datetime
    fin: datetime

    modalidad: Literal["presencial", "telemedicina", "en sitio", "en calle"] = "presencial"
    tipo_atencion: Literal["consulta", "pre-empleo", "periódico", "reintegro", "egreso", "campaña"] = "consulta"
    ubicacion: str | None = Field(default=None, max_length=180)

    @model_validator(mode="after")
    def validar_intervalo(self):
        if self.inicio.tzinfo or self.fin.tzinfo or self.fin <= self.inicio:
            raise ValueError("Indique inicio y fin en hora local de Costa Rica")
        return self


class EstadoIn(BaseModel):
    estado: Literal["confirmada", "llegó", "en espera", "cancelada", "no se presentó"]


class ConsultaIn(BaseModel):
    motivo: str = Field(min_length=1, max_length=4000)
    diagnostico: str = Field(min_length=1, max_length=4000)
    plan: str = Field(min_length=1, max_length=8000)
    cie: str | None = Field(default=None, max_length=20)


def _ahora():
    return ahora_cr().replace(tzinfo=None)


def _evento(s, ctx, accion, recurso_id):
    s.add(Evento(usuario_id=ctx.usuario.id, accion=accion, recurso_id=recurso_id, fecha=_ahora()))


def _acceso(*permisos):
    def comprobar(ctx: auth.Contexto = Depends(auth.contexto)):
        if (not habilitada(ctx.empresa.id) or ctx.token_api or ctx.suplantada_por
                or ctx.usuario.es_superadmin or not ctx.usuario.mfa_activo
                or not any(permiso in ctx.permisos for permiso in permisos)):
            raise HTTPException(403, "Médica requiere un permiso asignado y verificación en dos pasos")
        return ctx

    return comprobar


Recepcion = Annotated[auth.Contexto, Depends(_acceso(RECEPCION))]
Clinica = Annotated[auth.Contexto, Depends(_acceso(CLINICA))]
Personal = Annotated[auth.Contexto, Depends(_acceso(RECEPCION, CLINICA, ENFERMERIA))]
Base = Annotated[Session, Depends(auth.sesion_empresa)]
Central = Annotated[Session, Depends(auth.get_session)]


def _sede(ctx):
    return ctx.sucursal.id if ctx.sucursal else 0


def _buscar(s, modelo, identificador, ctx):
    fila = s.get(modelo, identificador)
    if not fila or fila.sede != _sede(ctx):
        raise HTTPException(404, "Registro no disponible en esta sede")
    return fila


def _profesionales(ctx, central):
    relaciones = central.exec(select(auth.UsuarioEmpresa).where(
        auth.UsuarioEmpresa.empresa_id == ctx.empresa.id
    )).all()
    resultado = []
    for relacion in relaciones:
        if "medica_clinica" not in auth.permisos_de_rol(central, ctx.empresa.id, relacion.rol):
            continue
        usuario = central.get(auth.Usuario, relacion.usuario_id)
        if (usuario and usuario.mfa_activo and not usuario.es_superadmin and not usuario.bloqueado
                and (relacion.sucursal_id is None or relacion.sucursal_id == _sede(ctx))):
            resultado.append({"id": usuario.id, "nombre": usuario.nombre})
    return resultado


@router.get("/profesionales")
def profesionales(ctx: Recepcion, central: Central):
    return _profesionales(ctx, central)


@router.get("/pacientes")
def pacientes(ctx: Recepcion, s: Base, q: str = ""):
    filtro = select(Paciente).where(Paciente.sede == _sede(ctx))
    q = q.strip()[:100]
    if q:
        filtro = filtro.where(
            Paciente.nombre.contains(q, autoescape=True)
            | Paciente.documento.contains(q.upper(), autoescape=True)
            | Paciente.telefono.contains(q, autoescape=True)
            | (Paciente.id == (int(q.lstrip("#")) if q.lstrip("#").isdigit() and len(q) < 12 else -1))
        )
    return [p.model_dump(exclude={"datos_administrativos"})
            for p in s.exec(filtro.order_by(Paciente.nombre).limit(100))]


@router.post("/pacientes", status_code=201)
def crear_paciente(data: PacienteIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    existe = s.exec(select(Paciente.id).where(
        Paciente.sede == _sede(ctx), Paciente.documento == data.documento
    )).first()
    if existe:
        raise HTTPException(409, "Ya existe un expediente con ese documento en esta sede")
    paciente = Paciente(sede=_sede(ctx), **data.model_dump())
    s.add(paciente)
    s.flush()
    _evento(s, ctx, "paciente.creado", paciente.id)
    s.commit()
    s.refresh(paciente)
    return paciente


@router.put("/pacientes/{paciente_id}")
def actualizar_paciente(paciente_id: int, data: PacienteIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _buscar(s, Paciente, paciente_id, ctx)
    duplicado = s.exec(select(Paciente.id).where(
        Paciente.sede == fila.sede, Paciente.documento == data.documento, Paciente.id != fila.id
    )).first()
    if duplicado:
        raise HTTPException(409, "Ya existe un expediente con ese documento en esta sede")
    fila.sqlmodel_update(data.model_dump())
    _evento(s, ctx, "paciente.actualizado", paciente_id)
    s.commit()
    return {"ok": True}


@router.get("/agenda")
def agenda(ctx: Personal, s: Base, dia: date | None = None):
    consulta = select(Cita, Paciente.nombre).join(Paciente).where(Cita.sede == _sede(ctx))
    if not {RECEPCION, ENFERMERIA} & ctx.permisos:
        consulta = consulta.where(Cita.profesional_id == ctx.usuario.id)
    if dia:
        inicio = datetime.combine(dia, time.min)
        consulta = consulta.where(Cita.inicio >= inicio, Cita.inicio < inicio + timedelta(days=1))
    return [
        {**cita.model_dump(), "paciente": nombre}
        for cita, nombre in s.exec(consulta.order_by(Cita.inicio.desc()).limit(200))
    ]


@router.post("/agenda", status_code=201)
def reservar(data: CitaIn, ctx: Recepcion, s: Base, central: Central):
    if not any(p["id"] == data.profesional_id for p in _profesionales(ctx, central)):
        raise HTTPException(422, "Profesional no disponible")
    s.exec(text("BEGIN IMMEDIATE"))
    _buscar(s, Paciente, data.paciente_id, ctx)
    cita = nueva_cita(s, _sede(ctx), data)
    _evento(s, ctx, "cita.creada", cita.id)
    s.commit()
    s.refresh(cita)
    return cita


def nueva_cita(s, sede: int, data: CitaIn):
    """El llamador toma BEGIN IMMEDIATE antes de validar la disponibilidad."""
    sala = data.consultorio.casefold()
    conflicto = s.exec(select(Cita.id).where(
        Cita.estado.not_in(("cancelada", "no se presentó")),
        Cita.inicio < data.fin,
        Cita.fin > data.inicio,
        (Cita.profesional_id == data.profesional_id)
        | ((Cita.sede == sede) & ((Cita.consultorio == sala) | (Cita.paciente_id == data.paciente_id))),
    )).first()
    if conflicto:
        raise HTTPException(409, "Profesional o consultorio ya reservado en ese horario")
    from .medica_operacion import revisar_bloqueo

    revisar_bloqueo(s, sede, data.profesional_id, sala, data.inicio, data.fin)
    cita = Cita(sede=sede, **{**data.model_dump(), "consultorio": sala})
    s.add(cita)
    s.flush()
    return cita


TRANSICIONES = {
    "programada": {"confirmada", "llegó", "cancelada", "no se presentó"},
    "confirmada": {"llegó", "cancelada", "no se presentó"},
    "llegó": {"en espera", "cancelada"},
    "en espera": {"cancelada"},
}


@router.put("/agenda/{cita_id}/estado")
def cambiar_estado(cita_id: int, data: EstadoIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    cita = _buscar(s, Cita, cita_id, ctx)
    if data.estado not in TRANSICIONES.get(cita.estado, set()):
        raise HTTPException(409, "Ese cambio de estado no está disponible")
    cita.estado = data.estado
    if data.estado == "llegó":
        cita.llegada = _ahora()
    _evento(s, ctx, f"cita.{data.estado}", cita.id)
    s.commit()
    return {"estado": data.estado}


def _cita_clinica(s, cita_id, ctx):
    cita = _buscar(s, Cita, cita_id, ctx)
    if cita.profesional_id != ctx.usuario.id:
        raise HTTPException(404, "Atención no disponible")
    return cita


@router.get("/agenda/{cita_id}/consulta")
def ver_consulta(cita_id: int, ctx: Clinica, s: Base):
    _cita_clinica(s, cita_id, ctx)
    consulta = s.get(Consulta, cita_id)
    if not consulta:
        raise HTTPException(404, "Consulta pendiente")
    _evento(s, ctx, "consulta.leida", cita_id)
    salida = consulta.model_dump(exclude={"cifrada"})
    salida.update(datos_consulta(ctx.empresa.clave_cifrada, consulta))
    s.commit()
    return salida


@router.post("/agenda/{cita_id}/consulta", status_code=201)
def cerrar_consulta(cita_id: int, data: ConsultaIn, ctx: Clinica, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    cita = _cita_clinica(s, cita_id, ctx)
    if cita.estado not in {"llegó", "en espera", "en consulta"}:
        raise HTTPException(409, "La cita debe estar en recepción antes de cerrar la consulta")
    campos = data.model_dump()
    if ctx.empresa.clave_cifrada:
        campos = {k: secretos.cifrar(ctx.empresa.clave_cifrada, v) for k, v in campos.items()}
    else:
        raise HTTPException(503, "La empresa requiere su clave de cifrado para guardar consultas")
    consulta = Consulta(cita_id=cita.id, profesional_id=ctx.usuario.id, registrada=_ahora(), cifrada=True, **campos)
    s.add(consulta)
    cita.estado = "atendida"
    cita.fin_atencion = _ahora()
    if not cita.inicio_atencion:
        cita.inicio_atencion = cita.fin_atencion
    _evento(s, ctx, "consulta.cerrada", cita.id)
    s.commit()
    return {"cita_id": cita_id, "estado": "atendida"}


CAMPOS_CONSULTA = ("motivo", "diagnostico", "plan", "cie")


def datos_consulta(clave, consulta):
    datos = {campo: getattr(consulta, campo) for campo in CAMPOS_CONSULTA}
    if not consulta.cifrada:
        return datos
    return {campo: secretos.descifrar(clave, valor) for campo, valor in datos.items()}


def migrar_consultas(s, empresa_id):
    """Cifra consultas de la versión piloto con la clave de la misma empresa."""
    from .db import Empresa, engine

    with Session(engine) as sc:
        e = sc.get(Empresa, empresa_id)
        clave = e.clave_cifrada if e else None
    if not clave:
        return
    s.exec(text("BEGIN IMMEDIATE"))
    anteriores = s.exec(select(Consulta).where(or_(Consulta.cifrada == False, Consulta.cifrada.is_(None)))).all()  # noqa: E712
    for consulta in anteriores:
        for campo in CAMPOS_CONSULTA:
            setattr(consulta, campo, secretos.cifrar(clave, getattr(consulta, campo)))
        consulta.cifrada = True
    s.commit()
