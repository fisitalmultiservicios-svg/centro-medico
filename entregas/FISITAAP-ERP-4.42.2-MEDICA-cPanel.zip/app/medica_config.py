"""Activación y permisos de FISITAAP Médica."""
import os


def habilitada(empresa_id: int) -> bool:
    empresas = os.getenv("FE_MEDICA_EMPRESAS", "").split(",")
    return os.getenv("FE_MODO_LOCAL") != "1" and str(empresa_id) in {valor.strip() for valor in empresas}


RECEPCION = "medica_recepcion"
CLINICA = "medica_clinica"
ENFERMERIA = "medica_enfermeria"
LABORATORIO = "medica_laboratorio"
FARMACIA = "medica_farmacia"
GESTION = "medica_gestion"
PERMISOS = {
    RECEPCION: "Médica · Recepción y agenda",
    CLINICA: "Médica · Consultas asignadas",
    ENFERMERIA: "Médica · Enfermería",
    LABORATORIO: "Médica · Laboratorio e imágenes",
    FARMACIA: "Médica · Farmacia",
    GESTION: "Médica · Operación y convenios",
}
