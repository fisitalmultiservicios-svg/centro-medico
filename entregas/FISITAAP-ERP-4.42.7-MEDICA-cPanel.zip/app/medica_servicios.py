"""Órdenes de atención y facturación mediante los servicios del ERP."""
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Literal
from uuid import uuid4

from fastapi import Depends, File, HTTPException, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, LargeBinary, text
from sqlmodel import Field as Col, SQLModel, select

from . import auth, inventario, secretos
from .db import Documento, Producto, por_empresa
from .medica import Base, Cita, Clinica, Nombre, Paciente, Recepcion, _acceso, _ahora, _buscar, _cita_clinica, _evento, _sede, router
from .medica_config import CLINICA, FARMACIA, LABORATORIO
from .medica_operacion import Cobertura, Registro, Validacion, _contacto, cifrar, leer

Tipo = Literal["laboratorio", "imágenes", "farmacia", "receta", "referencia", "certificado", "incapacidad", "indicaciones"]
Servicios = Annotated[auth.Contexto, Depends(_acceso(CLINICA, FARMACIA, LABORATORIO))]
PERMISO_ORDEN = {"laboratorio": LABORATORIO, "imágenes": LABORATORIO, "farmacia": FARMACIA}
MAX_ADJUNTO = 8 * 1024 * 1024


class Orden(SQLModel, table=True):
    __tablename__ = "medica_orden"
    __table_args__ = {"sqlite_autoincrement": True}
    id: int | None = Col(default=None, primary_key=True)
    cita_id: int = Col(index=True)
    tipo: str
    estado: str
    datos: str
    resultado: str | None = None
    creada: datetime = Col(sa_type=DateTime)
    autor_id: int
    cumplida: datetime | None = Col(default=None, sa_type=DateTime)
    cumplio_id: int | None = None
    publicada: datetime | None = Col(default=None, sa_type=DateTime)
    producto_id: int | None = None
    cantidad: float = 1


class Adjunto(SQLModel, table=True):
    __tablename__ = "medica_adjunto"
    orden_id: int = Col(primary_key=True)
    tipo: str
    contenido: bytes = Col(sa_type=LargeBinary)


class Cargo(SQLModel, table=True):
    __tablename__ = "medica_cargo"
    __table_args__ = {"sqlite_autoincrement": True}
    id: int | None = Col(default=None, primary_key=True)
    cita_id: int = Col(index=True)
    cliente_id: int | None = None
    pagador: str
    tipo: str
    moneda: str
    lineas: str
    clave: str = Col(index=True, unique=True)
    cancelado: bool = False
    privado_portal: bool = True
    creado: datetime = Col(sa_type=DateTime)


por_empresa(Orden, Adjunto, Cargo)


class OrdenIn(BaseModel):
    tipo: Tipo
    titulo: Nombre
    indicaciones: str = Field(default="", max_length=8000)
    producto_id: int | None = None
    cantidad: Decimal = Field(default=1, ge=Decimal("0.001"), le=10000, decimal_places=3)


class ResultadoIn(BaseModel):
    texto: str = Field(min_length=1, max_length=16000)
    lote: str | None = Field(default=None, max_length=80)
    vence: date | None = None


def producto_de_venta(s, ctx, identificador):
    p = s.get(Producto, identificador)
    if not p or p.empresa_id != ctx.empresa.id or not p.activo or not p.es_venta:
        raise HTTPException(422, "Seleccione un ítem de venta activo del ERP")
    return p


def _orden(s, ctx, identificador, *, ejecutar=False):
    fila = s.get(Orden, identificador)
    if not fila:
        raise HTTPException(404, "Orden no disponible")
    cita = _buscar(s, Cita, fila.cita_id, ctx)
    autor = CLINICA in ctx.permisos and cita.profesional_id == ctx.usuario.id
    servicio = PERMISO_ORDEN.get(fila.tipo) in ctx.permisos
    if not (servicio if ejecutar else autor or servicio):
        raise HTTPException(404, "Orden no disponible")
    return fila


def _salida(s, e, fila):
    cita = s.get(Cita, fila.cita_id)
    paciente = s.get(Paciente, cita.paciente_id)
    return {
        **fila.model_dump(exclude={"datos", "resultado"}), **leer(e, fila.datos),
        "paciente": paciente.nombre, "expediente": paciente.id,
        "resultado": leer(e, fila.resultado), "adjunto": s.exec(select(Adjunto.orden_id).where(Adjunto.orden_id == fila.id)).first() is not None,
    }


@router.get("/ordenes")
def ordenes(ctx: Servicios, s: Base, cita_id: int | None = None):
    q = select(Orden).join(Cita, Cita.id == Orden.cita_id).where(Cita.sede == _sede(ctx))
    filtros = []
    if CLINICA in ctx.permisos:
        filtros.append(Cita.profesional_id == ctx.usuario.id)
    tipos = [tipo for tipo, permiso in PERMISO_ORDEN.items() if permiso in ctx.permisos]
    if tipos:
        filtros.append(Orden.tipo.in_(tipos))
    from sqlalchemy import or_

    q = q.where(or_(*filtros))
    if cita_id:
        q = q.where(Orden.cita_id == cita_id)
    salida = []
    for fila in s.exec(q.order_by(Orden.id.desc()).limit(200)):
        _evento(s, ctx, "orden.leida", fila.id)
        salida.append(_salida(s, ctx.empresa, fila))
    s.commit()
    return salida


@router.post("/agenda/{cita_id}/ordenes", status_code=201)
def crear_orden(cita_id: int, data: OrdenIn, ctx: Clinica, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    cita = _cita_clinica(s, cita_id, ctx)
    if cita.estado not in {"en consulta", "atendida"}:
        raise HTTPException(409, "Inicie la consulta para registrar órdenes")
    if data.producto_id:
        p = producto_de_venta(s, ctx, data.producto_id)
        if data.tipo == "farmacia" and (not p.inventariable or p.es_servicio):
            raise HTTPException(422, "Seleccione un producto inventariable")
    if data.tipo == "farmacia" and not data.producto_id:
        raise HTTPException(422, "Seleccione un producto del catálogo para farmacia")
    fila = Orden(cita_id=cita_id, tipo=data.tipo, estado="pendiente" if data.tipo in PERMISO_ORDEN else "emitida",
                 datos=cifrar(ctx.empresa, {"titulo": data.titulo, "indicaciones": data.indicaciones}),
                 creada=_ahora(), autor_id=ctx.usuario.id, producto_id=data.producto_id, cantidad=float(data.cantidad))
    s.add(fila)
    s.flush()
    _evento(s, ctx, "orden.creada", fila.id)
    salida = _salida(s, ctx.empresa, fila)
    s.commit()
    return salida


@router.put("/ordenes/{orden_id}/resultado")
def completar(orden_id: int, data: ResultadoIn, ctx: Servicios, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _orden(s, ctx, orden_id, ejecutar=True)
    if fila.estado != "pendiente":
        raise HTTPException(409, "La orden ya se procesó")
    if fila.tipo == "farmacia":
        data = _usar_lote(s, ctx, fila, data)
    fila.resultado = cifrar(ctx.empresa, data.model_dump())
    fila.estado = "dispensada" if fila.tipo == "farmacia" else "completada"
    fila.cumplida = _ahora()
    fila.cumplio_id = ctx.usuario.id
    _evento(s, ctx, "orden.cumplida", fila.id)
    s.commit()
    return {"ok": True}


@router.put("/ordenes/{orden_id}/adjunto")
def adjuntar(orden_id: int, ctx: Servicios, s: Base, archivo: UploadFile = File(...)):
    from .main import _leer_subida

    contenido = _leer_subida(archivo, MAX_ADJUNTO)
    if not contenido.startswith(b"%PDF-"):
        raise HTTPException(422, "Adjunte un documento PDF")
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _orden(s, ctx, orden_id)
    if fila.publicada or fila.estado == "cancelada":
        raise HTTPException(409, "Retire la publicación antes de cambiar el adjunto")
    if not ctx.empresa.clave_cifrada:
        raise HTTPException(503, "Falta la clave de cifrado de la empresa")
    protegido = secretos.fernet_empresa(ctx.empresa.clave_cifrada).encrypt(contenido)
    actual = s.get(Adjunto, orden_id)
    if actual:
        actual.contenido = protegido
    else:
        s.add(Adjunto(orden_id=orden_id, contenido=protegido, tipo="application/pdf"))
    _evento(s, ctx, "orden.adjunto_guardado", orden_id)
    s.commit()
    return {"ok": True}


def descarga_adjunto(s, empresa, orden_id):
    fila = s.get(Adjunto, orden_id)
    if not fila:
        raise HTTPException(404, "Sin adjunto disponible")
    contenido = secretos.fernet_empresa(empresa.clave_cifrada).decrypt(fila.contenido)
    return Response(contenido, media_type=fila.tipo, headers={
        "Content-Disposition": f'attachment; filename="documento-medica-{orden_id}.pdf"',
        "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
    })


@router.get("/ordenes/{orden_id}/adjunto")
def descargar(orden_id: int, ctx: Servicios, s: Base):
    _orden(s, ctx, orden_id)
    respuesta = descarga_adjunto(s, ctx.empresa, orden_id)
    _evento(s, ctx, "orden.adjunto_descargado", orden_id)
    s.commit()
    return respuesta


class PublicacionIn(BaseModel):
    publicada: bool


@router.put("/ordenes/{orden_id}/publicacion")
def publicar(orden_id: int, data: PublicacionIn, ctx: Clinica, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _orden(s, ctx, orden_id)
    _cita_clinica(s, fila.cita_id, ctx)
    if data.publicada and fila.estado not in {"emitida", "completada", "dispensada"}:
        raise HTTPException(409, "Complete o emita la orden antes de publicar")
    if data.publicada and fila.tipo in {"certificado", "incapacidad", "receta"} and not s.get(Adjunto, fila.id):
        raise HTTPException(409, "Adjunte el documento médico firmado antes de publicarlo")
    fila.publicada = _ahora() if data.publicada else None
    _evento(s, ctx, "orden.publicacion_modificada", orden_id)
    s.commit()
    return {"ok": True}


class LineaCargo(BaseModel):
    producto_id: int
    cantidad: Decimal = Field(default=1, ge=Decimal("0.001"), le=10000, decimal_places=3)
    precio_unitario: Decimal | None = Field(default=None, ge=0, le=100000000, decimal_places=5)
    orden_id: int | None = None


class CargoIn(BaseModel):
    cliente_id: int | None = None
    pagador: Literal["paciente", "tercero", "aseguradora", "empresa"] = "paciente"
    tipo: Literal["01", "04"] = "01"
    lineas: list[LineaCargo] = Field(min_length=1, max_length=30)
    mostrar_portal: bool = False


class EmisionIn(BaseModel):
    medio_pago: Literal["01", "02", "03", "04", "05", "06"] = "01"
    condicion_venta: Literal["01", "02"] = "01"
    plazo_credito: int | None = Field(default=None, ge=1, le=365)


def _documento(s, eid, cargo):
    return s.exec(select(Documento).where(
        Documento.empresa_id == eid, Documento.idempotencia == cargo.clave
    )).first()


def _lineas(cargo):
    import json

    return json.loads(cargo.lineas)


def _cargo_dict(ctx, s, r):
    doc = _documento(s, ctx.empresa.id, r)
    from .medica_pagos import PagoWeb

    return {
        "pago_web": s.get(PagoWeb, r.id) is not None, "reabrible": _corregido(doc),
        "id": r.id, "cita_id": r.cita_id, "cliente_id": r.cliente_id, "pagador": r.pagador,
        "tipo": r.tipo, "moneda": r.moneda, "creado": r.creado, "cancelado": r.cancelado,
        "lineas": _lineas(r),
        "documento": {"id": doc.id, "consecutivo": doc.consecutivo, "estado": doc.estado, "total": doc.total,
                      "saldo": max(0, doc.total - doc.pagado - doc.acreditado)} if doc else None,
    }


@router.get("/agenda/{cita_id}/items-pendientes")
def items_pendientes(cita_id: int, ctx: Recepcion, s: Base):
    ctx.exigir("facturar")
    _buscar(s, Cita, cita_id, ctx)
    cargos_activos = s.exec(select(Cargo).where(Cargo.cita_id == cita_id, Cargo.cancelado.is_(False))).all()
    ocupadas = {l["orden_id"] for cargo in cargos_activos for l in _lineas(cargo) if l.get("orden_id")}
    q = select(Orden, Producto).join(Producto, Producto.id == Orden.producto_id).where(
        Orden.cita_id == cita_id, Orden.estado.in_(("emitida", "completada", "dispensada")),
        Producto.empresa_id == ctx.empresa.id, Producto.activo.is_(True),
        Producto.es_venta.is_(True), Producto.moneda == "CRC",
    )
    # Recepción recibe el concepto comercial del ERP. El texto clínico se mantiene en Órdenes.
    return [{"orden_id": o.id, "producto_id": p.id, "nombre": p.nombre, "cantidad": o.cantidad, "precio": p.precio}
            for o, p in s.exec(q.order_by(Orden.id)) if o.id not in ocupadas]


@router.get("/agenda/{cita_id}/cargos")
def cargos(cita_id: int, ctx: Recepcion, s: Base):
    ctx.exigir("facturar")
    _buscar(s, Cita, cita_id, ctx)
    return [_cargo_dict(ctx, s, r) for r in s.exec(select(Cargo).where(Cargo.cita_id == cita_id).order_by(Cargo.id.desc()).limit(100))]


@router.post("/agenda/{cita_id}/cargos", status_code=201)
def preparar(cita_id: int, data: CargoIn, ctx: Recepcion, s: Base):
    import json
    from .tike_contratos import _linea_producto

    ctx.exigir("facturar")
    s.exec(text("BEGIN IMMEDIATE"))
    c = _buscar(s, Cita, cita_id, ctx)
    if c.estado in {"cancelada", "no se presentó"}:
        raise HTTPException(409, "La cita está cancelada o ausente")
    paciente = _buscar(s, Paciente, c.paciente_id, ctx)
    cliente_id = data.cliente_id or (paciente.cliente_id if data.pagador == "paciente" else None)
    if data.pagador in {"aseguradora", "empresa"}:
        val = s.get(Validacion, cita_id)
        cobertura = s.get(Cobertura, val.cobertura_id) if val and val.estado in {"cubierta", "parcial"} else None
        tipo = "asegurado" if data.pagador == "aseguradora" else "corporativo"
        if not cobertura or cobertura.tipo != tipo:
            raise HTTPException(409, "Valide primero la cobertura de este pagador")
        entidad = _buscar(s, Registro, cobertura.convenio_id, ctx)
        if not entidad.contacto_id or (cliente_id and cliente_id != entidad.contacto_id):
            raise HTTPException(422, "Vincule el pagador del convenio a un contacto fiscal")
        cliente_id = entidad.contacto_id
    cliente = _contacto(s, ctx, cliente_id)
    if data.mostrar_portal and (data.pagador != "paciente" or cliente_id != paciente.cliente_id):
        raise HTTPException(422, "El portal solo muestra comprobantes del contacto fiscal del paciente")
    if (data.tipo == "01" or data.pagador != "paciente") and not cliente:
        raise HTTPException(422, "Indique el contacto fiscal del pagador")
    lineas, monedas, ordenes_usadas = [], set(), set()
    anteriores = s.exec(select(Cargo).where(Cargo.cita_id == cita_id, Cargo.cancelado == False)).all()  # noqa: E712
    ocupadas = {l["orden_id"] for r in anteriores for l in _lineas(r) if l.get("orden_id")}
    for linea in data.lineas:
        p = producto_de_venta(s, ctx, linea.producto_id)
        if linea.orden_id:
            orden = s.get(Orden, linea.orden_id)
            if (not orden or orden.cita_id != cita_id or orden.producto_id != p.id
                    or orden.estado not in {"emitida", "completada", "dispensada"}
                    or linea.cantidad != Decimal(str(orden.cantidad))):
                raise HTTPException(422, "La orden no corresponde al ítem, está pendiente o tiene otra cantidad")
            if orden.id in ocupadas or orden.id in ordenes_usadas:
                raise HTTPException(409, "La orden ya está incluida en otro cargo")
            ordenes_usadas.add(orden.id)
        monedas.add(p.moneda or "CRC")
        lineas.append({**_linea_producto(p, float(linea.cantidad), linea.precio_unitario), "orden_id": linea.orden_id})
    if len(monedas) != 1:
        raise HTTPException(422, "Use una sola moneda por cargo")
    if monedas != {"CRC"}:
        raise HTTPException(422, "Los cargos de Médica se emiten en CRC")
    # Una repetición del mismo formulario conserva el cargo pendiente en vez de duplicarlo.
    serializadas = json.dumps(lineas, ensure_ascii=False)
    for anterior in anteriores:
        if (anterior.cliente_id, anterior.pagador, anterior.tipo, anterior.lineas) == (cliente_id, data.pagador, data.tipo, serializadas):
            return _cargo_dict(ctx, s, anterior)
    fila = Cargo(cita_id=cita_id, cliente_id=cliente_id, pagador=data.pagador, tipo=data.tipo,
                 moneda=monedas.pop(), lineas=serializadas, clave="medica:" + uuid4().hex,
                 creado=_ahora(), privado_portal=not data.mostrar_portal or data.pagador != "paciente")
    s.add(fila)
    s.flush()
    _evento(s, ctx, "cargo.preparado", fila.id)
    salida = _cargo_dict(ctx, s, fila)
    s.commit()
    return salida


def _corregido(doc):
    return bool(doc and (doc.estado in {"rechazado", "anulado"}
                         or (doc.acreditado > 0 and doc.acreditado >= doc.total - 0.005)))


def _cargo(s, ctx, identificador):
    fila = s.get(Cargo, identificador)
    if not fila:
        raise HTTPException(404, "Cargo no disponible")
    _buscar(s, Cita, fila.cita_id, ctx)
    return fila


@router.post("/cargos/{cargo_id}/cancelar")
def cancelar_cargo(cargo_id: int, ctx: Recepcion, s: Base):
    ctx.exigir("facturar")
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _cargo(s, ctx, cargo_id)
    doc = _documento(s, ctx.empresa.id, fila)
    if doc and not _corregido(doc):
        raise HTTPException(409, "Use la anulación o nota de crédito de Ventas")
    fila.cancelado = True
    _evento(s, ctx, "cargo.cancelado", cargo_id)
    s.commit()
    return {"ok": True}


@router.post("/cargos/{cargo_id}/emitir")
def emitir(cargo_id: int, data: EmisionIn, ctx: Recepcion, s: Base):
    from .main import ComprobanteIn, crear_comprobante

    ctx.exigir("facturar")
    # bodega_principal puede crear la bodega y confirmar. Se resuelve antes de tomar el bloqueo.
    _cargo(s, ctx, cargo_id)
    bodega = ctx.sucursal.bodega_id if ctx.sucursal else None
    if not bodega:
        bodega = inventario.bodega_principal(s, ctx.empresa.id).id
    s.rollback()
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _cargo(s, ctx, cargo_id)
    if fila.cancelado:
        raise HTTPException(409, "Cargo cancelado")
    existente = _documento(s, ctx.empresa.id, fila)
    if existente:
        return _cargo_dict(ctx, s, fila)
    if data.condicion_venta == "02" and not fila.cliente_id:
        raise HTTPException(422, "El crédito requiere un contacto fiscal")
    comp = ComprobanteIn(
        tipo_documento=fila.tipo, cliente_id=fila.cliente_id, moneda=fila.moneda,
        bodega_id=bodega, idempotencia=fila.clave, lineas=_lineas(fila), **data.model_dump(),
    )
    _evento(s, ctx, "cargo.emitido", cargo_id)
    crear_comprobante(comp, ctx, s)
    return _cargo_dict(ctx, s, fila)


class Lote(SQLModel, table=True):
    __tablename__ = "medica_lote"
    __table_args__ = {"sqlite_autoincrement": True}
    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    producto_id: int = Col(index=True)
    codigo: str
    vence: date
    cantidad: float
    consumida: float = 0


por_empresa(Lote)
Farmacia = Annotated[auth.Contexto, Depends(_acceso(FARMACIA))]


class LoteIn(BaseModel):
    producto_id: int
    codigo: Nombre
    vence: date
    cantidad: Decimal = Field(ge=Decimal("0.001"), le=1000000, decimal_places=3)


@router.get("/farmacia/lotes")
def lotes(ctx: Farmacia, s: Base, producto_id: int | None = None):
    consulta = select(Lote).where(Lote.sede == _sede(ctx))
    if producto_id:
        consulta = consulta.where(Lote.producto_id == producto_id, Lote.vence >= _ahora().date())
    return s.exec(consulta.order_by(Lote.vence, Lote.codigo).limit(250)).all()


@router.post("/farmacia/lotes", status_code=201)
def registrar_lote(data: LoteIn, ctx: Farmacia, s: Base):
    p = producto_de_venta(s, ctx, data.producto_id)
    if p.es_servicio or not p.inventariable or data.vence < _ahora().date():
        raise HTTPException(422, "Seleccione un producto inventariable y un vencimiento vigente")
    s.exec(text("BEGIN IMMEDIATE"))
    existe = s.exec(select(Lote.id).where(
        Lote.sede == _sede(ctx), Lote.producto_id == p.id, Lote.codigo == data.codigo
    )).first()
    if existe:
        raise HTTPException(409, "Ese lote ya está registrado para el producto")
    r = Lote(sede=_sede(ctx), **data.model_dump())
    s.add(r)
    s.flush()
    _evento(s, ctx, "farmacia.lote_registrado", r.id)
    s.commit()
    s.refresh(r)
    return r


def _usar_lote(s, ctx, orden, data):
    codigo = (data.lote or "").strip()
    r = s.exec(select(Lote).where(
        Lote.sede == _sede(ctx), Lote.producto_id == orden.producto_id, Lote.codigo == codigo
    )).first()
    if not r or r.vence < _ahora().date():
        raise HTTPException(422, "Seleccione un lote vigente registrado en Farmacia")
    if Decimal(str(r.cantidad)) - Decimal(str(r.consumida)) < Decimal(str(orden.cantidad)):
        raise HTTPException(409, "El lote no alcanza para completar la orden")
    r.consumida = round(r.consumida + orden.cantidad, 3)
    return data.model_copy(update={"lote": r.codigo, "vence": r.vence})
