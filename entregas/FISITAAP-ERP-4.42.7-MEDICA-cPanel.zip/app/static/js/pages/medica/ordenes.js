import { abrirPDF, campo, enviar, fechaHora, Formulario, leer, operaciones, permiso, productos, tiposOrden } from './_comun.js';
import { sesion } from '../../app.js';

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() { return { filas:[], tipo:'', actual:null, archivo:null, lotes:[], verLotes:false, tiposOrden }; },
  computed: { farmacia() { return permiso('medica_farmacia'); }, filtradas() { return this.tipo ? this.filas.filter(x=>x.tipo===this.tipo) : this.filas; } },
  methods: {
    fechaHora,
    async cargar() {
      this.filas = await leer('/ordenes');
      if (this.actual) this.actual = this.filas.find(r=>r.id===this.actual.id) || null;
    },
    abrir(fila) { this.actual = fila; this.archivo = null; },
    autora(fila) { return permiso('medica_clinica') && fila.autor_id === sesion.usuario?.id; },
    operadora(fila) { return fila.tipo === 'farmacia' ? permiso('medica_farmacia') : ['laboratorio','imágenes'].includes(fila.tipo) && permiso('medica_laboratorio'); },
    async resultado() {
      const r = this.actual;
      const campos = [campo('texto',r.tipo==='farmacia'?'Registro de dispensación':'Resultado','textarea',{req:true,max:16000})];
      if (r.tipo==='farmacia') {
        const filas=await leer('/farmacia/lotes',{producto_id:r.producto_id});
        campos.push(campo('lote','Lote','select',{req:true,opciones:filas.filter(x=>x.cantidad-x.consumida>=r.cantidad).map(x=>[x.codigo,x.codigo+' · Vence '+x.vence])}));
      }
      this.pedir('Completar orden',campos,{},async d=>{await enviar('/ordenes/'+r.id+'/resultado',d,'PUT');await this.cargar();});
    },
    async cambiar() {
      this.verLotes=!this.verLotes;
      if (this.verLotes) this.lotes=await leer('/farmacia/lotes');
    },
    nuevoLote() {
      this.pedir('Registrar lote de una entrada de inventario',[
        campo('producto_id','Producto inventariable del ERP','select',{req:true,opciones:productos()}),
        campo('codigo','Lote','text',{req:true}),campo('vence','Vencimiento','date',{req:true}),
        campo('cantidad','Cantidad','number',{req:true,min:.001,paso:.001}),
      ],{},async d=>{await enviar('/farmacia/lotes',d);this.lotes=await leer('/farmacia/lotes');});
    },
    async publicar(publicada) {
      await enviar('/ordenes/'+this.actual.id+'/publicacion',{publicada},'PUT');
      await this.cargar();
    },
    async adjuntar() {
      const cuerpo = new FormData();
      cuerpo.append('archivo',this.archivo);
      await enviar('/ordenes/'+this.actual.id+'/adjunto',cuerpo,'PUT');
      this.archivo = null;
      await this.cargar();
    },
    descargar() { return abrirPDF('/ordenes/'+this.actual.id+'/adjunto',this.actual.titulo); },
  },
  created() { this.ejecutar(this.cargar); },
  template: `
  <div class="page medica-workspace">
    <PageHead title="Órdenes y documentos" :crumbs="[{label:'Médica'}]"><button v-if="farmacia" class="btn sec" @click="ejecutar(cambiar)">{{verLotes?'Volver a órdenes':'Lotes de farmacia'}}</button><button class="btn sec" @click="ejecutar(cargar)">Actualizar</button></PageHead>
    <section v-if="verLotes" class="card">
      <button class="btn" @click="nuevoLote">Registrar lote</button>
      <p>Usa los lotes para registrar qué se dispensa. Las ventas descuentan el ítem en el inventario del ERP.</p>
      <p v-if="!lotes.length">Sin lotes registrados.</p>
      <ul><li v-for="l in lotes" :key="l.id">Ítem #{{l.producto_id}} · {{l.codigo}} · Vence {{l.vence}} · Restan {{+(l.cantidad-l.consumida).toFixed(3)}}</li></ul>
    </section>
    <section v-else class="card">
      <label>Tipo <select v-model="tipo"><option value="">Todos</option><option v-for="t in tiposOrden" :key="t">{{t}}</option></select></label>
      <p v-if="!filtradas.length">Sin órdenes para mostrar.</p>
      <div v-else class="tablewrap"><table class="tabla"><thead><tr><th>Orden</th><th>Paciente</th><th>Tipo</th><th>Estado</th><th></th></tr></thead>
      <tbody><tr v-for="r in filtradas" :key="r.id"><td>#{{r.id}} · {{r.titulo}}</td><td>{{r.paciente}} · #{{r.expediente}}</td><td>{{r.tipo}}</td>
        <td><span class="medica-status" :data-estado="r.estado">{{r.estado}}</span><span v-if="r.publicada"> · Publicada</span></td><td><button class="btn sm" @click="abrir(r)">Abrir</button></td></tr></tbody></table></div>
    </section>
    <Modal v-if="actual && !formulario" :title="actual.titulo" @close="actual=null" size="lg">
      <p>#{{actual.id}} · {{actual.tipo}} · {{actual.paciente}}</p>
      <p>{{actual.indicaciones}}</p>
      <p v-if="actual.producto_id">Ítem #{{actual.producto_id}} · Cantidad {{actual.cantidad}}</p>
      <p v-if="actual.resultado?.texto">{{actual.resultado.texto}} <span v-if="actual.resultado.lote">· Lote {{actual.resultado.lote}} · Vence {{actual.resultado.vence}}</span></p>
      <div class="acts">
        <button v-if="operadora(actual) && actual.estado==='pendiente'" class="btn" @click="ejecutar(resultado)">Completar</button>
        <button v-if="autora(actual) && actual.estado!=='pendiente'" class="btn sec" @click="ejecutar(()=>publicar(!actual.publicada))">{{actual.publicada?'Retirar publicación':'Publicar al paciente'}}</button>
        <button v-if="actual.adjunto" class="btn sec" @click="ejecutar(descargar)">Abrir PDF</button>
      </div>
      <form v-if="!actual.publicada" @submit.prevent="ejecutar(adjuntar)">
        <label>PDF <input type="file" accept="application/pdf" required @change="archivo=$event.target.files[0]"></label>
        <button class="btn sec" :disabled="!archivo || ocupado">Guardar PDF</button>
      </form>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
