import { sesion } from '../../app.js';
import { campo, clientes, enviar, Formulario, leer, operaciones, opciones } from './_comun.js';

const pantallas = [
  ['consultorio','Consultorios'],['equipo','Equipos'],['profesional','Profesionales'],['tarea','Tareas'],
  ['aseguradora','Aseguradoras'],['convenio','Convenios'],['campaña','Campañas'],['incidente','Incidentes'],['reportes','Reportes'],
];
const fechaCR = () => new Intl.DateTimeFormat('en-CA',{timeZone:'America/Costa_Rica',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() { return { pantallas, tipo:'consultorio', filas:[], activos:[], reporte:null, desde:fechaCR(), hasta:fechaCR() }; },
  computed: { puedeActivos() { return sesion.puede('contabilidad'); } },
  methods: {
    async cargar() {
      if (this.tipo==='reportes') this.reporte=await leer('/reportes',{desde:this.desde,hasta:this.hasta});
      else {
        const tipo=this.tipo;
        const [filas,activos]=await Promise.all([
          leer('/operacion/'+encodeURIComponent(tipo)),
          tipo==='equipo' && this.puedeActivos ? leer('/operacion-activos') : [],
        ]);
        this.filas=filas;
        this.activos=activos;
      }
    },
    cambiar(tipo) { this.tipo=tipo; this.filas=[]; return this.ejecutar(this.cargar); },
    registro(r = null) {
      const tipo = this.tipo;
      this.pedir(r ? 'Editar registro' : 'Agregar registro',[
        campo('nombre','Nombre','text',{req:true}), campo('estado','Estado','select',{req:true,opciones:opciones(['activo','inactivo','pendiente','en curso','cerrado'])}),
        campo('responsable_id','ID del usuario responsable','number',{min:1}),
        campo('contacto_id','Contacto del ERP','select',{opciones:clientes()}),
        campo('vence','Vencimiento','date'),
        campo('referencia',tipo==='equipo'?'Serie o referencia del equipo':'Referencia contractual o colegiatura','text',{max:120}),
        ...(tipo==='equipo' && this.puedeActivos ? [campo('activo_id','Activo fijo del ERP','select',{opciones:this.activos.map(a=>[a.id,a.nombre])})] : []),
        campo('detalle','Detalle operativo','textarea',{max:4000}),
      ],r || {estado:'activo'},async d=>{
        await enviar('/operacion/'+encodeURIComponent(tipo)+(r?'/'+r.id:''),d,r?'PUT':'POST');
        await this.cargar();
      });
    },
  },
  created() { this.ejecutar(this.cargar); },
  template: `
  <div class="page medica-workspace">
    <PageHead title="Operación y convenios" :crumbs="[{label:'Médica'}]">
      <button v-if="tipo!=='reportes'" class="btn" @click="registro()">Agregar registro</button>
    </PageHead>
    <nav class="medica-tabs" aria-label="Operación de la clínica"><button v-for="[id,label] in pantallas" :key="id" :aria-pressed="tipo===id" :disabled="ocupado" @click="cambiar(id)">{{label}}</button></nav>
    <section v-if="tipo!=='reportes'" class="card">
      <p v-if="!filas.length">Sin registros.</p>
      <div v-else class="tablewrap"><table class="tabla"><thead><tr><th>Nombre</th><th>Estado</th><th>Vencimiento</th><th>Referencia</th><th></th></tr></thead>
        <tbody><tr v-for="r in filas" :key="r.id"><td>{{r.nombre}}</td><td>{{r.estado}}</td><td>{{r.vence || '—'}}</td><td>{{r.referencia}}</td>
          <td class="medica-actions"><button class="btn sm sec" @click="registro(r)">Editar</button>
            <a v-if="tipo==='equipo' && puedeActivos && r.activo_id" class="btn sm sec" :href="'#/contabilidad/activos/'+encodeURIComponent(r.activo_id)">Abrir activo ERP</a></td></tr></tbody>
      </table></div>
    </section>
    <section v-else class="card">
      <h2>Actividad de la sede</h2>
      <form class="acts" @submit.prevent="ejecutar(cargar)"><label>Desde <input v-model="desde" type="date" required></label>
        <label>Hasta <input v-model="hasta" type="date" required></label><button class="btn">Consultar</button></form>
      <div v-if="reporte">
        <p>{{reporte.citas}} citas · Espera promedio {{reporte.espera_minutos ?? '—'}} min · Atención promedio {{reporte.consulta_minutos ?? '—'}} min</p>
        <div class="grid cols-2"><div><h3>Por estado</h3><ul><li v-for="(n,t) in reporte.por_estado" :key="t">{{t}} · {{n}}</li></ul></div>
        <div><h3>Por modalidad</h3><ul><li v-for="(n,t) in reporte.por_modalidad" :key="t">{{t}} · {{n}}</li></ul></div></div>
        <h3>Consumo por convenio</h3><ul><li v-for="c in reporte.convenios" :key="c.nombre">{{c.nombre}} · {{c.atenciones}} atenciones</li></ul>
      </div>
    </section>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
