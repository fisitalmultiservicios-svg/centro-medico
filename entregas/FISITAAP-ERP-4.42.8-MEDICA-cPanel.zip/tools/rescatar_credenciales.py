"""Rescate de credenciales cuando se perdió la clave maestra del servidor (FE_MASTER_KEY).

Sin la clave maestra con que se cifraron, la llave .p12, su PIN y las contraseñas de Hacienda, correo (general, RRHH) y buzón
de cada empresa ya no se pueden leer. Este script NO toca comprobantes, clientes, inventario ni contabilidad: solo, en las
empresas cuyas credenciales son ilegibles, les crea una clave propia nueva (cifrada con la clave maestra ACTUAL) y deja
vacías esas credenciales para volver a cargarlas en Configuración › Facturación electrónica. El archivo .p12 ilegible no se
borra: se renombra a certs/ilegible_<fecha>_<nombre>.

Uso (cPanel › Setup Python App › Execute python script, con la app DETENIDA):
    tools/rescatar_credenciales.py              → solo diagnóstico (no cambia nada)
    tools/rescatar_credenciales.py --confirmar  → aplica el rescate a las empresas con credenciales ilegibles

Antes de confirmar: defina la FE_MASTER_KEY definitiva en las variables de la app (y guárdela en un lugar seguro).
"""
import os
import sys
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
os.chdir(RAIZ)
os.environ.setdefault("FE_COLA_HILO", "0")

CAMPOS = ("password_hacienda", "p12_pin", "smtp_password", "rrhh_smtp_password", "imap_password")


def legible(secretos, e) -> bool:
    if not e.clave_cifrada:
        return True                      # sin clave propia: se crea al guardar; no hay nada cifrado que perder
    try:
        secretos.fernet_empresa(e.clave_cifrada)
        return True
    except ValueError:
        return False


def rescatar(confirmar: bool = False, salida=print) -> dict:
    from sqlmodel import Session, select
    from app import secretos
    from app.auth import auditar
    from app.config import DATA_DIR
    from app.db import Empresa, engine, init_db

    init_db()
    certs = DATA_DIR / "certs"
    origen = "variable FE_MASTER_KEY" if os.getenv("FE_MASTER_KEY") else "archivo data/master.key"
    salida(f"Clave maestra en uso: {origen}")
    res = {"legibles": [], "ilegibles": [], "rescatadas": []}
    with Session(engine) as s:
        for e in s.exec(select(Empresa).order_by(Empresa.id)).all():
            tiene = [c for c in CAMPOS if getattr(e, c, None)] + (["llave .p12"] if e.p12_nombre else [])
            if legible(secretos, e):
                res["legibles"].append(e.id)
                salida(f"  Empresa {e.id} · {e.nombre}: credenciales LEGIBLES ({', '.join(tiene) or 'sin credenciales cargadas'})")
                continue
            res["ilegibles"].append(e.id)
            salida(f"  Empresa {e.id} · {e.nombre}: credenciales ILEGIBLES con esta clave maestra ({', '.join(tiene) or 'ninguna'})")
            if not confirmar:
                continue
            e.clave_cifrada = secretos.nueva_clave_empresa()
            for c in CAMPOS:
                if hasattr(e, c):
                    setattr(e, c, None)
            if e.p12_nombre:
                p = certs / e.p12_nombre
                if p.exists():
                    p.rename(certs / f"ilegible_{datetime.now():%Y%m%d%H%M%S}_{e.p12_nombre}")
                e.p12_nombre = None
                e.p12_vence = None
            s.add(e)
            auditar(s, "credenciales_rescatadas", f"Empresa {e.id}: clave maestra perdida; credenciales vaciadas para cargarlas de nuevo",
                    correo="sistema (rescate de credenciales)", empresa_id=e.id)
            res["rescatadas"].append(e.id)
            salida(f"    → rescatada: vuelva a cargar la llave .p12 y su PIN, la contraseña de Hacienda y las de correo")
        s.commit()
    if res["ilegibles"] and not confirmar:
        salida("Solo diagnóstico: no se cambió nada. Para rescatar, ejecute de nuevo con --confirmar.")
    elif not res["ilegibles"]:
        salida("Todas las empresas se leen bien con esta clave maestra: no hay nada que rescatar.")
    return res


if __name__ == "__main__":
    rescatar(confirmar="--confirmar" in sys.argv[1:])
