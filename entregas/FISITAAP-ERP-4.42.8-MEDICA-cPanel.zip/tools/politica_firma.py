"""Descarga el PDF de la resolución (política de firma) y calcula su hash SHA-256 en base64.

Uso:  python tools/politica_firma.py [URL]
Luego exporta:  FE_POLITICA_URL=<url>  FE_POLITICA_HASH=<hash>
"""
import base64
import hashlib
import sys

import httpx

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent))
from app.config import POLITICA_FIRMA_URL  # noqa: E402

url = sys.argv[1] if len(sys.argv) > 1 else POLITICA_FIRMA_URL
r = httpx.get(url, follow_redirects=True, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
r.raise_for_status()
if not r.content.startswith(b"%PDF"):
    sys.exit(f"La URL no devolvió un PDF (content-type {r.headers.get('content-type')}). Verifica la URL en hacienda.go.cr")
h = base64.b64encode(hashlib.sha256(r.content).digest()).decode()
print(f"FE_POLITICA_URL={url}")
print(f"FE_POLITICA_HASH={h}")
