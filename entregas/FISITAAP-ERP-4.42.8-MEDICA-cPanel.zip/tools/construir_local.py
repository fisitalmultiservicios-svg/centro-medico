# -*- coding: utf-8 -*-
"""Construye FISITAAPLocal.exe, el programa local de FISITAAP (4.9), de forma reproducible.

Pasos: revisa el entorno contra local/requisitos-construccion.txt (PyInstaller y pywin32 obligatorios: sin pywin32 el exe sale
sin impresión USB), toma la versión del sistema (primera «VERSION x.y» de NOVEDADES.txt), genera el ícono (.ico, desde
app/static/img/fisitaap-icono-512.png con Pillow) y la ficha de versión de Windows (Brillante Agencia · FISITAAP Local · x.y),
llama a PyInstaller con todo lo que el programa necesita y deja local/dist/FISITAAPLocal.exe con su sha256
(FISITAAPLocal.exe.sha256). Al final abre el exe recién hecho en modo --autoprueba (con una carpeta de datos temporal) para
comprobar que trae la impresión, el servidor, los esquemas, el catálogo, la zona horaria y la firma.
4.9 (revisión): deja además local/dist/nube/ con la copia lista para publicar a mano: GrupoFacturaLocal.exe (el nombre con el
que la nube guarda y sirve el programa: /api/local/version y /api/local/descargar solo buscan data/local/GrupoFacturaLocal.exe,
para las instalaciones 4.9+ y para las 1.46, que piden la misma ruta) y su version.json. Se copian esos dos archivos tal cual a
data/local/ de la nube; un FISITAAPLocal.exe copiado ahí no se publica.

Uso (con el Python del entorno de construcción, Facturacion/Project/.venv):
  python tools/construir_local.py                    construye
  python tools/construir_local.py --solo-verificar   solo revisa el entorno y genera el ícono y la ficha en una carpeta temporal
Opciones: --trabajo DIR (carpeta de trabajo de PyInstaller; por omisión una temporal), --ignorar-versiones (avisa en lugar de
fallar si una versión instalada no es la fijada), --sin-autoprueba (no abre el exe construido).
Sale con 0 si todo está bien y 1 si hubo errores. No se usa en el servidor (cPanel)."""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
LOCAL = RAIZ / "local"
DIST = LOCAL / "dist"
NOMBRE_EXE = "FISITAAPLocal"
EXE_NUBE = "GrupoFacturaLocal.exe"       # 4.9: el nombre con el que la nube guarda y sirve el programa (= app/actualizacion_local.EXE_NUBE)
NUBE = DIST / "nube"                     # 4.9: lo que se copia a mano a data/local/ de la nube (exe con ese nombre + version.json)
ICONO_PNG = RAIZ / "app" / "static" / "img" / "fisitaap-icono-512.png"
REQUISITOS = LOCAL / "requisitos-construccion.txt"
EMPRESA = "Brillante Agencia"
PRODUCTO = "FISITAAP Local"
DESCRIPCION = "FISITAAP Local - facturación electrónica, punto de venta e impresión, con o sin internet"
TAMANOS_ICONO = (16, 20, 24, 32, 40, 48, 64, 128, 256)
# (origen relativo a la raíz, destino dentro del exe, obligatorio)
DATOS = (("app/static", "app/static", True), ("app/sitio_web", "app/sitio_web", False), ("schemas", "schemas", True),
         ("catalogos", "catalogos", True), ("NOVEDADES.txt", ".", True))
OCULTOS = ("uvicorn.logging", "uvicorn.loops.auto", "uvicorn.protocols.http.auto", "uvicorn.protocols.http.h11_impl",
           "uvicorn.protocols.websockets.auto", "uvicorn.lifespan.on", "uvicorn.lifespan.off",
           "win32print", "win32api", "pywintypes", "app.escpos", "app.etiquetas_impresora", "app.actualizacion_local", "app.agente_local")
COLECCIONES_DATOS = ("tzdata", "signxml")
_RE_VERSION = re.compile(r"^VERSION\s+(\S+)\s*[-–]\s*(.+?)\s*$")


class Informe:
    def __init__(self):
        self.errores, self.avisos = [], []

    def ok(self, texto):
        print("  ok     " + texto)

    def aviso(self, texto):
        self.avisos.append(texto); print("  AVISO  " + texto)

    def error(self, texto):
        self.errores.append(texto); print("  ERROR  " + texto)


def cargar_local():
    """local/local.py como módulo (no arranca nada al importarse): de ahí salen la versión y el nombre del programa."""
    spec = importlib.util.spec_from_file_location("fisitaap_local_construccion", LOCAL / "local.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def primera_version(archivo: Path) -> str:
    try:
        for linea in archivo.read_text(encoding="utf-8").splitlines():
            m = _RE_VERSION.match(linea.strip())
            if m:
                return m.group(1)
    except OSError:
        pass
    return ""


def version_sistema() -> str:
    """La versión del sistema, igual que la lee el programa al arrancar (local.version_sistema sobre NOVEDADES.txt)."""
    return cargar_local().version_sistema(str(RAIZ))


def numeros_version(v: str) -> tuple:
    """«4.9» → (4, 9, 0, 0) para la ficha de Windows (cada parte entre 0 y 65535, hasta cuatro partes)."""
    partes = str(v or "").strip().split(".")
    if not partes or len(partes) > 4 or not all(p.isdigit() for p in partes):
        raise ValueError(f"versión no válida para Windows: {v!r} (se esperan números como 4.9)")
    nums = [int(p) for p in partes]
    if any(n > 65535 for n in nums):
        raise ValueError(f"versión no válida para Windows: {v!r} (cada parte hasta 65535)")
    return tuple(nums + [0] * (4 - len(nums)))


def _nombre(n: str) -> str:
    return re.sub(r"[-_.]+", "-", n).strip().lower()


def leer_requisitos(ruta: Path = REQUISITOS) -> dict:
    """{nombre normalizado: versión} de las líneas «paquete==versión» (y «# python==x.y.z» bajo la clave «python»)."""
    out = {}
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        s = linea.strip()
        m = re.match(r"^#\s*python==(\S+)", s)
        if m:
            out["python"] = m.group(1); continue
        s = s.split("#", 1)[0].strip()
        m = re.match(r"^([A-Za-z0-9_.\-]+)(\[[^\]]*\])?\s*==\s*(\S+)$", s)
        if m:
            out[_nombre(m.group(1))] = m.group(3)
    return out


def verificar_entorno(inf: Informe, ignorar_versiones=False, requisitos=None):
    from importlib.metadata import PackageNotFoundError, version
    req = requisitos if requisitos is not None else leer_requisitos()
    py = "%d.%d.%d" % sys.version_info[:3]
    if req.get("python"):
        if py.split(".")[:2] != req["python"].split(".")[:2]:
            (inf.aviso if ignorar_versiones else inf.error)(f"Python {py}; la construcción fija Python {req['python']}")
        elif py != req["python"]:
            inf.aviso(f"Python {py} (fijado {req['python']}; misma serie, se acepta)")
        else:
            inf.ok(f"Python {py}")
    if sys.maxsize <= 2 ** 32:
        inf.error("Python de 32 bits: el programa se construye con Python de 64 bits")
    distintos = 0
    for n, v in sorted(req.items()):
        if n == "python":
            continue
        try:
            inst = version(n)
        except PackageNotFoundError:
            inf.error(f"falta el paquete {n}=={v}"); continue
        if inst != v:
            distintos += 1
            (inf.aviso if ignorar_versiones else inf.error)(f"{n} instalado {inst}, fijado {v}")
    if not distintos:
        inf.ok(f"{len([k for k in req if k != 'python'])} paquetes con la versión fijada")
    try:
        import PyInstaller
        inf.ok("PyInstaller " + PyInstaller.__version__)
    except ImportError:
        inf.error("falta PyInstaller (pip install pyinstaller==" + req.get("pyinstaller", "6.22.3") + ")")
    try:
        import pywintypes, win32api, win32print  # noqa: F401,E401
        inf.ok("pywin32 (win32print, win32api, pywintypes)")
    except ImportError as ex:
        inf.error(f"falta pywin32 ({ex}): sin él el programa sale SIN impresión USB. Instale pywin32=={req.get('pywin32', '312')}")
    try:
        import PIL  # noqa: F401
        inf.ok("Pillow (ícono)")
    except ImportError:
        inf.error("falta Pillow: se necesita para generar el ícono")


def verificar_archivos(inf: Informe) -> list:
    """Revisa lo que va dentro del exe y devuelve la lista de --add-data (origen absoluto, destino)."""
    datos = []
    for origen, destino, obligatorio in DATOS:
        p = RAIZ / origen
        if p.exists():
            datos.append((str(p), destino))
        elif obligatorio:
            inf.error(f"falta {origen}")
        else:
            inf.aviso(f"no está {origen} (opcional): el exe sale sin eso")
    for p in (LOCAL / "local.py", ICONO_PNG, RAIZ / "schemas" / "v4.4", RAIZ / "catalogos" / "cabys.csv.gz"):
        if not p.exists():
            inf.error(f"falta {p.relative_to(RAIZ)}")
    if not inf.errores:
        inf.ok("archivos del programa: " + ", ".join(o for o, _d, _ob in DATOS if (RAIZ / o).exists()))
    return datos


def generar_icono(png: Path, destino: Path) -> Path:
    """El .ico del programa con varios tamaños (Windows usa el que le toque: barra de tareas, escritorio, explorador)."""
    from PIL import Image
    destino.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(png) as im:
        im = im.convert("RGBA")
        im.save(destino, format="ICO", sizes=[(n, n) for n in TAMANOS_ICONO])
    with Image.open(destino) as ico:            # verificación: se vuelve a abrir y debe traer los tamaños
        tiene = set(ico.ico.sizes())
    falta = {(n, n) for n in TAMANOS_ICONO} - tiene
    if falta:
        raise ValueError(f"el ícono no quedó con los tamaños {sorted(falta)}")
    return destino


def texto_ficha_version(version: str) -> str:
    """Ficha de versión de Windows (formato de PyInstaller --version-file): Propiedades › Detalles del exe."""
    nums = numeros_version(version)
    anio = time.strftime("%Y")
    cadenas = [("CompanyName", EMPRESA), ("FileDescription", DESCRIPCION), ("FileVersion", version),
               ("InternalName", NOMBRE_EXE), ("LegalCopyright", f"© {anio} {EMPRESA}"), ("OriginalFilename", NOMBRE_EXE + ".exe"),
               ("ProductName", PRODUCTO), ("ProductVersion", version)]
    filas = ",\n          ".join(f"StringStruct({k!r}, {v!r})" for k, v in cadenas)
    return f"""# -*- coding: utf-8 -*-
# Ficha de versión de {NOMBRE_EXE}.exe (generada por tools/construir_local.py; no se edita a mano)
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers={nums},
    prodvers={nums},
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable(
        '140A04B0',
        [{filas}])
    ]),
    VarFileInfo([VarStruct('Translation', [0x140A, 1200])])
  ]
)
"""


def generar_ficha(version: str, destino: Path) -> Path:
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text(texto_ficha_version(version), encoding="utf-8")
    from PyInstaller.utils.win32.versioninfo import load_version_info_from_text_file
    info = load_version_info_from_text_file(str(destino))          # verificación: PyInstaller la entiende
    ms, ls = info.ffi.fileVersionMS, info.ffi.fileVersionLS
    if (ms >> 16, ms & 0xFFFF, ls >> 16, ls & 0xFFFF) != numeros_version(version):
        raise ValueError("la ficha de versión no quedó con la versión del sistema")
    return destino


def argumentos_pyinstaller(trabajo: Path, icono: Path, ficha: Path, datos: list, dist: Path = DIST) -> list:
    args = ["--noconfirm", "--clean", "--onefile", "--noconsole", "--name", NOMBRE_EXE,
            "--icon", str(icono), "--version-file", str(ficha),
            "--distpath", str(dist), "--workpath", str(trabajo / "build"), "--specpath", str(trabajo),
            "--paths", str(RAIZ), "--collect-submodules", "app"]
    for origen, destino in datos:
        args += ["--add-data", f"{origen}{os.pathsep}{destino}"]
    for paquete in COLECCIONES_DATOS:
        args += ["--collect-data", paquete]
    for oculto in OCULTOS:
        args += ["--hidden-import", oculto]
    return args + [str(LOCAL / "local.py")]


def _sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for trozo in iter(lambda: f.read(1024 * 1024), b""):
            h.update(trozo)
    return h.hexdigest()


def _entorno_aislado(trabajo: Path) -> dict:
    """Entorno para PyInstaller y la autoprueba: datos y LOCALAPPDATA en carpetas temporales (nunca la carpeta real del negocio)."""
    env = dict(os.environ)
    for k in list(env):
        if k.startswith("FE_") or k.startswith("_PYI_"):
            env.pop(k)
    env["FE_DATA_DIR"] = str(trabajo / "datos_construccion")
    env["LOCALAPPDATA"] = str(trabajo / "localappdata")
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    Path(env["FE_DATA_DIR"]).mkdir(parents=True, exist_ok=True); Path(env["LOCALAPPDATA"]).mkdir(parents=True, exist_ok=True)
    return env


def revisar_exe(exe: Path, trabajo: Path, version: str, inf: Informe, autoprueba=True):
    if not exe.exists():
        inf.error(f"no se generó {exe}"); return None
    tam = exe.stat().st_size
    (inf.ok if tam > 15 * 1024 * 1024 else inf.error)(f"{exe.name}: {tam / 1024 / 1024:.1f} MB")
    aviso = trabajo / "build" / NOMBRE_EXE / f"warn-{NOMBRE_EXE}.txt"
    if aviso.exists():
        txt = aviso.read_text(encoding="utf-8", errors="replace")
        for mod in ("win32print", "win32api", "pywintypes", "uvicorn", "app.main", "app.escpos", "app.etiquetas_impresora"):
            if re.search(rf"^missing module named '?{re.escape(mod)}'?(\s|$)", txt, re.M):
                inf.error(f"PyInstaller no encontró {mod} (ver {aviso})")
    try:
        import win32api
        info = win32api.GetFileVersionInfo(str(exe), "\\")
        ms, ls = info["FileVersionMS"], info["FileVersionLS"]
        leida = (ms >> 16, ms & 0xFFFF, ls >> 16, ls & 0xFFFF)
        (inf.ok if leida == numeros_version(version) else inf.error)(f"ficha de versión del exe: {'.'.join(map(str, leida))}")
        trad = win32api.GetFileVersionInfo(str(exe), "\\VarFileInfo\\Translation")
        if trad:
            lang, cp = trad[0]
            empresa = win32api.GetFileVersionInfo(str(exe), f"\\StringFileInfo\\{lang:04X}{cp:04X}\\CompanyName")
            (inf.ok if empresa == EMPRESA else inf.error)(f"empresa en la ficha: {empresa}")
    except Exception as ex:  # noqa: BLE001
        inf.error(f"no se pudo leer la ficha de versión del exe: {ex}")
    if autoprueba:
        salida = trabajo / "autoprueba.json"
        salida.unlink(missing_ok=True)
        try:
            subprocess.run([str(exe), "--autoprueba", str(salida)], env=_entorno_aislado(trabajo), timeout=600, cwd=str(trabajo))
        except subprocess.TimeoutExpired:
            inf.error("la autoprueba del exe no terminó en 10 minutos")
        r = json.loads(salida.read_text(encoding="utf-8")) if salida.exists() else None
        if not r:
            inf.error("el exe no escribió el resultado de la autoprueba (no arranca)")
        elif r.get("ok") and r.get("version") == version:
            inf.ok(f"autoprueba del exe: versión {r['version']}, impresión USB, servidor ({r.get('servidor')} rutas), esquemas, catálogo, zona horaria y firma")
        else:
            inf.error(f"autoprueba del exe con errores: {r.get('errores')} (versión {r.get('version')})")
    sha = _sha256(exe)
    (exe.parent / (exe.name + ".sha256")).write_text(f"{sha} *{exe.name}\n", encoding="ascii")
    meta = {"version": version, "sha256": sha, "bytes": tam, "fecha": time.strftime("%Y-%m-%dT%H:%M:%S")}
    inf.ok(f"sha256 {sha}")
    return meta


def preparar_publicacion(exe: Path, meta: dict, carpeta: Path = NUBE) -> Path:
    """4.9 (revisión): deja en `carpeta` lo que se copia a mano a data/local/ de la nube cuando la subida por Administración ›
    Programa local falla por el tamaño: el exe con el nombre que la nube sirve (GrupoFacturaLocal.exe; quien lo descarga lo
    recibe y lo instala como FISITAAPLocal.exe, y una 1.46 lo pone en lugar de su GrupoFacturaLocal.exe) y su version.json
    {version, sha256, bytes, fecha}. Comprueba que la copia quedó idéntica. Borra un version.json viejo junto al exe (de
    construcciones anteriores) para que no se publique por error."""
    carpeta = Path(carpeta)
    carpeta.mkdir(parents=True, exist_ok=True)
    copia = carpeta / EXE_NUBE
    shutil.copy2(exe, copia)
    if copia.stat().st_size != int(meta["bytes"]) or _sha256(copia) != meta["sha256"]:
        raise OSError(f"la copia {copia} no quedó igual al exe construido")
    (carpeta / "version.json").write_text(json.dumps(meta), encoding="utf-8")
    viejo = Path(exe).parent / "version.json"
    if viejo.exists() and viejo.parent.resolve() != carpeta.resolve():
        viejo.unlink()
    return carpeta


def instrucciones_publicar(meta: dict, exe: Path = DIST / f"{NOMBRE_EXE}.exe", carpeta: Path = NUBE) -> str:
    """4.9 (revisión): cómo publicar la versión recién construida (lo imprime la construcción al terminar)."""
    return (f"Para publicarlo en la nube (las instalaciones vinculadas lo bajan e instalan solas):\n"
            f"  a) Administración › Programa local: suba {exe} con la versión {meta['version']} (la nube lo guarda como {EXE_NUBE}).\n"
            f"  b) Si la subida falla por el tamaño (límite del hosting): copie los DOS archivos de {carpeta} ({EXE_NUBE} y version.json)\n"
            f"     a data/local/ de la nube con el administrador de archivos, con esos nombres. La nube solo sirve {EXE_NUBE}: un\n"
            f"     {NOMBRE_EXE}.exe copiado ahí NO se publica (/api/local/version seguiría respondiendo sin versión).\n"
            f"Las instalaciones 4.9+ lo bajan como {NOMBRE_EXE}.nuevo.exe y reemplazan {NOMBRE_EXE}.exe; una 1.46 lo pone en lugar de su\n"
            f"GrupoFacturaLocal.exe y, al abrirse, la versión nueva se copia como {NOMBRE_EXE}.exe y cambia los accesos.\n"
            f"Para instalar a mano en una computadora: {NOMBRE_EXE}.exe --instalar.")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Construye FISITAAPLocal.exe")
    ap.add_argument("--solo-verificar", action="store_true", help="revisa el entorno y genera el ícono y la ficha, sin construir")
    ap.add_argument("--trabajo", help="carpeta de trabajo (por omisión, una temporal)")
    ap.add_argument("--ignorar-versiones", action="store_true", help="avisa en lugar de fallar si una versión no es la fijada")
    ap.add_argument("--sin-autoprueba", action="store_true", help="no abre el exe construido para revisarlo")
    a = ap.parse_args(argv)
    for flujo in (sys.stdout, sys.stderr):                # la consola de Windows puede no tener algún carácter: que no se caiga
        try:
            flujo.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    inf = Informe()
    trabajo = Path(a.trabajo).resolve() if a.trabajo else Path(tempfile.mkdtemp(prefix="fisitaap_local_"))
    trabajo.mkdir(parents=True, exist_ok=True)
    print(f"FISITAAP Local · construcción ({'solo verificar' if a.solo_verificar else 'completa'}) · trabajo: {trabajo}")

    print("1. Versión")
    version = version_sistema()
    if not version:
        inf.error("no se pudo leer la versión de NOVEDADES.txt (primera línea «VERSION x.y - fecha»)")
    else:
        try:
            numeros_version(version); inf.ok(f"versión del sistema {version} (NOVEDADES.txt)")
        except ValueError as ex:
            inf.error(str(ex))
        cambios = primera_version(RAIZ / "CHANGELOG.txt")
        if cambios and cambios != version:
            inf.aviso(f"CHANGELOG.txt empieza con {cambios} y NOVEDADES.txt con {version}")
    print("2. Entorno")
    verificar_entorno(inf, a.ignorar_versiones)
    print("3. Archivos")
    datos = verificar_archivos(inf)
    print("4. Ícono y ficha de versión")
    icono = ficha = None
    try:
        icono = generar_icono(ICONO_PNG, trabajo / f"{NOMBRE_EXE}.ico"); inf.ok(f"ícono {icono}")
    except Exception as ex:  # noqa: BLE001
        inf.error(f"no se pudo generar el ícono: {ex}")
    if version:
        try:
            ficha = generar_ficha(version, trabajo / "ficha_version.txt"); inf.ok(f"ficha de versión {ficha}")
        except Exception as ex:  # noqa: BLE001
            inf.error(f"no se pudo generar la ficha de versión: {ex}")
    if a.solo_verificar or inf.errores:
        print(f"\n{'Con errores' if inf.errores else 'Todo listo para construir'}: {len(inf.errores)} errores, {len(inf.avisos)} avisos.")
        return 1 if inf.errores else 0

    print("5. PyInstaller (unos minutos)")
    DIST.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(NUBE, ignore_errors=True)               # 4.9 (revisión): si esta construcción falla, no queda lista para publicar la copia de otra anterior
    exe = DIST / f"{NOMBRE_EXE}.exe"
    r = subprocess.run([sys.executable, "-m", "PyInstaller", *argumentos_pyinstaller(trabajo, icono, ficha, datos)],
                       cwd=str(RAIZ), env=_entorno_aislado(trabajo))
    if r.returncode != 0:
        inf.error(f"PyInstaller terminó con código {r.returncode}")
        return 1
    print("6. Revisión del exe")
    meta = revisar_exe(exe, trabajo, version, inf, autoprueba=not a.sin_autoprueba)
    if meta and not inf.errores:                          # 4.9 (revisión): un exe con errores (p. ej. autoprueba fallida) no se deja listo para publicar
        try:
            nube = preparar_publicacion(exe, meta, NUBE); inf.ok(f"copia para publicar a mano: {nube / EXE_NUBE} y {nube / 'version.json'}")
        except OSError as ex:
            inf.error(f"no se pudo preparar la copia para publicar ({NUBE}): {ex}")
    print(f"\n{'Con errores' if inf.errores else 'Listo'}: {exe} · {len(inf.errores)} errores, {len(inf.avisos)} avisos.")
    if meta and not inf.errores:
        print(instrucciones_publicar(meta, exe, NUBE))
    if not a.trabajo and not inf.errores:
        shutil.rmtree(trabajo, ignore_errors=True)
    return 1 if inf.errores else 0


if __name__ == "__main__":
    sys.exit(main())
