"""Convierte el catálogo CABYS oficial (catalogos/cabys.xlsx, hoja «Catálogo») al archivo que viaja en el zip y lee el servidor:
catalogos/cabys.csv.gz (3.72). Pesa 0,4 MB en vez de 2,8 MB y se lee en una fracción de segundo en vez de varios segundos.

Uso (cuando Hacienda publique un catálogo nuevo): descargue el Excel a catalogos/cabys.xlsx y corra
    python tools/convertir_cabys.py
Las columnas se guardan tal como vienen del Excel (la tarifa como texto crudo) para que app/cabys.py las interprete igual
que antes. El Excel queda fuera del zip (tools/build_zip.py) mientras exista el csv.gz."""
import csv
import gzip
import io
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
XLSX = RAIZ / "catalogos" / "cabys.xlsx"
CSV = RAIZ / "catalogos" / "cabys.csv.gz"
COLUMNAS = ["codigo", "descripcion", "impuesto", "categoria", "subcategoria", "nombre_corto", "incluye", "excluye"]


def _texto(v) -> str:
    return "" if v is None else str(v).strip()


def convertir(xlsx: Path = XLSX, destino: Path = CSV) -> int:
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    ws = wb["Catálogo"]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(COLUMNAS)
    n = 0
    for row in ws.iter_rows(min_row=3, values_only=True):
        codigo = _texto(row[16])
        if len(codigo) != 13 or not codigo.isdigit():
            continue
        # la tarifa va cruda (0.13, '13%', 'Exento'…): cabys.leer_impuesto la interpreta igual que desde el Excel
        w.writerow([codigo, _texto(row[17]), _texto(row[18]), _texto(row[1]), _texto(row[3]), _texto(row[15]), _texto(row[19]), _texto(row[20])])
        n += 1
    destino.write_bytes(gzip.compress(buf.getvalue().encode("utf-8"), 9))
    return n


if __name__ == "__main__":
    origen = Path(sys.argv[1]) if len(sys.argv) > 1 else XLSX
    total = convertir(origen)
    print(f"{total} códigos → {CSV} ({CSV.stat().st_size / 1e6:.2f} MB)")
