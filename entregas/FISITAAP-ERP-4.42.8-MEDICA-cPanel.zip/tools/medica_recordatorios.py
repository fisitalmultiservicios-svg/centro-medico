"""Envía recordatorios de citas confirmadas dentro de las próximas 24 horas."""
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import HTTPException
from sqlalchemy import text
from sqlmodel import Session, select

from app.db import Empresa, engine, init_db, sesion_de
from app.main import app  # registra los modelos del ERP y de Médica
from app.medica import Cita, Paciente, _ahora
from app.medica_config import habilitada
from app.medica_operacion import Aviso, _enviar_aviso


def enviar_empresa(empresa):
    ahora = _ahora()
    with sesion_de(empresa.id) as s:
        citas = s.exec(select(Cita.id).where(
            Cita.estado == "confirmada", Cita.inicio > ahora,
            Cita.inicio <= ahora + timedelta(hours=24)
        ).order_by(Cita.inicio).limit(200)).all()
    enviados = 0
    for identificador in citas:
        with sesion_de(empresa.id) as s:
            s.exec(text("BEGIN IMMEDIATE"))
            previo = s.exec(select(Aviso.id).where(Aviso.cita_id == identificador)).first()
            cita = s.get(Cita, identificador)
            if previo or not cita or cita.estado != "confirmada" or cita.inicio <= _ahora():
                continue
            paciente = s.get(Paciente, cita.paciente_id)
            if not paciente:
                continue
            aviso = Aviso(cita_id=identificador, estado="en proceso", fecha=_ahora())
            s.add(aviso)
            s.commit()
            try:
                _enviar_aviso(empresa, paciente, cita)
            except HTTPException:
                aviso.estado = "falló"
            else:
                aviso.estado = "enviado"
                enviados += 1
            s.commit()
    return enviados


def main():
    init_db()
    with Session(engine) as s:
        empresas = s.exec(select(Empresa).where(Empresa.bloqueada == False)).all()  # noqa: E712
        s.expunge_all()
    total = sum(enviar_empresa(e) for e in empresas if habilitada(e) and e.smtp_host)
    print(f"Recordatorios de Médica enviados: {total}")


if __name__ == "__main__":
    main()
