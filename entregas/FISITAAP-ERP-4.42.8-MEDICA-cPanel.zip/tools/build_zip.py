"""Genera los zips de despliegue en dist/.

  python tools/build_zip.py            -> dist/facturacr-cpanel.zip  (solo código + documentación; NUNCA data/)
  python tools/build_zip.py --datos    -> además dist/facturacr-datos.zip (data/ local: bases, XML, certificados, claves).
                                          Contiene secretos: súbalo solo si quiere migrar sus datos y bórrelo del servidor después.

Se ejecuta desde cualquier carpeta; usa la raíz del proyecto (carpeta padre de tools/).
"""
import os
import sys
import shutil
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DIST = RAIZ / "dist"

# Lo que viaja al servidor (rutas relativas a la raíz del proyecto)
CARPETAS = ["app", "catalogos", "schemas", "tools", "tests", "docs"]
ARCHIVOS = ["passenger_wsgi.py", "requirements.txt", "README.md", "NOVEDADES.txt",     # PROCESOS.txt es interno: no viaja (R229)
            "REQUERIMIENTOS.md", "DESPLIEGUE_CPANEL.md", "DESPLIEGUE-FISITAAP.txt", ".gitignore"]   # 3.79: lista para el dominio nuevo
# Nunca al servidor
EXCLUIR_DIRS = {"__pycache__", ".pytest_cache", ".venv", "qa"}        # tools/qa son scripts de prueba locales
EXCLUIR_SUFIJOS = (".pyc", ".pyo", ".log")
# Herramientas de la orden que saca la versión (tools/sacar_version.py): internas, no viajan al servidor
EXCLUIR_RUTAS = ("tools/sacar_version.py", "tools/version.py", "tools/README-sacar-version.md", "tools/plantillas/")

# Dentro de data/ (solo con --datos): fuera respaldos y archivos sueltos de prueba
EXCLUIR_DATOS = ("backup", ".bak", "demo")


def _agregar_carpeta(zf: zipfile.ZipFile, carpeta: Path, filtro=None) -> int:
    n = 0
    for raiz, dirs, archivos in os.walk(carpeta):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUIR_DIRS)
        for nombre in sorted(archivos):
            if nombre.endswith(EXCLUIR_SUFIJOS) or nombre.startswith("_qa"):     # restos de pruebas locales (inicio de sesión temporal)
                continue
            ruta = Path(raiz) / nombre
            rel = ruta.relative_to(RAIZ).as_posix()
            if filtro and not filtro(rel):
                continue
            if rel.startswith(EXCLUIR_RUTAS):
                continue
            if rel == "catalogos/cabys.xlsx" and (RAIZ / "catalogos" / "cabys.csv.gz").exists():   # 3.72: viaja el csv.gz (0,4 MB), no el Excel (2,8 MB)
                continue
            zf.write(ruta, rel)
            n += 1
    return n


def construir_codigo() -> Path:
    DIST.mkdir(exist_ok=True)
    destino = DIST / "facturacr-cpanel.zip"
    n = 0
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zf:
        for c in CARPETAS:
            n += _agregar_carpeta(zf, RAIZ / c)
        for a in ARCHIVOS:
            ruta = RAIZ / a
            if ruta.exists():
                zf.write(ruta, a)
                n += 1
            else:
                print(f"  aviso: falta {a}")
    print(f"{destino.name}: {n} archivos, {destino.stat().st_size / 1e6:.2f} MB")
    mem = RAIZ.parent / "Memorias"
    if mem.is_dir():                                   # registro interno (técnico): copia en Memorias; NO viaja en el zip
        shutil.copyfile(RAIZ / "CHANGELOG.txt", mem / "CHANGELOG.txt")
        print(f"  registro interno copiado a {mem / 'CHANGELOG.txt'}")
    return destino


def construir_datos() -> Path:
    destino = DIST / "facturacr-datos.zip"
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zf:
        n = _agregar_carpeta(zf, RAIZ / "data",
                             filtro=lambda rel: not any(x in rel.lower() for x in EXCLUIR_DATOS))
    print(f"{destino.name}: {n} archivos, {destino.stat().st_size / 1e6:.2f} MB  (SENSIBLE: bases, .p12 y claves)")
    return destino


def _version_de(nombre: str) -> str:
    texto = (RAIZ / nombre).read_text(encoding="utf-8")
    return next((l.split()[1] for l in texto.splitlines() if l.startswith("VERSION ")), "")


def _verificar_registros() -> str:
    """NOVEDADES.txt (cliente, viaja en el zip) y CHANGELOG.txt (interno, no viaja) deben empezar con la misma versión."""
    publico, interno = _version_de("NOVEDADES.txt"), _version_de("CHANGELOG.txt")
    if not publico or publico != interno:
        sys.exit(f"ERROR: NOVEDADES.txt dice versión '{publico}' y CHANGELOG.txt '{interno}'. Agregue la entrada nueva en ambos antes de generar el zip.")
    print(f"versión {publico} (NOVEDADES.txt y CHANGELOG.txt coinciden)")
    return publico


if __name__ == "__main__":
    _verificar_registros()
    construir_codigo()
    if "--datos" in sys.argv:
        construir_datos()
