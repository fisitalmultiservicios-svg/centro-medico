"""Cola de Hacienda desde la línea de comandos (para el cron de cPanel o para correrla a mano).

  python tools/cola_hacienda.py            una pasada sobre todas las empresas
  python tools/cola_hacienda.py --estado   solo muestra el estado de Hacienda y los pendientes, sin enviar nada

cPanel › Cron Jobs, cada 5 minutos (una sola línea):
  source /home/<usuario>/virtualenv/facturacr/3.12/bin/activate && cd /home/<usuario>/facturacr && python tools/cola_hacienda.py >> data/cola.log 2>&1

IMPORTANTE: el cron NO hereda las variables de entorno de "Setup Python App". El `activate` del entorno virtual que crea
cPanel normalmente las exporta; este script se niega a correr en producción si no ve FE_MASTER_KEY, para no generar una
clave maestra distinta de la que usa la aplicación web (lo que dejaría ilegibles los secretos). Alternativa sin este
problema: un cron con curl al endpoint protegido:
  curl -s -m 280 -X POST https://facturas.itcoresync.com/api/cola/procesar -H "X-Cron-Token: <FE_CRON_TOKEN>"
"""
import json
import os
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

# Sin clave maestra conocida este script NO corre: app.secretos generaría una clave nueva y todo lo cifrado quedaría ilegible (R137)
if not os.environ.get("FE_MASTER_KEY") and not (RAIZ / "data" / "master.key").exists():
    sys.exit("FE_MASTER_KEY no está en el entorno del cron (ni existe data/master.key): use el endpoint /api/cola/procesar con curl "
             "o exporte las variables (source .../virtualenv/.../bin/activate) antes de ejecutar este script")

from app import cola  # noqa: E402
from app.db import init_db  # noqa: E402

init_db()
if "--estado" in sys.argv:
    from sqlmodel import Session, select
    from app.db import Empresa, engine, engine_empresa
    with Session(engine) as sc:
        empresas = sc.exec(select(Empresa)).all()
    for e in empresas:
        with Session(engine_empresa(e.id)) as s:
            print(json.dumps({"empresa": e.nombre, **cola.estado(e, s)}, ensure_ascii=False))
else:
    print(json.dumps(cola.procesar_todas(), ensure_ascii=False))
