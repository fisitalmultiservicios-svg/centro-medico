Esquemas XSD v4.4 de Hacienda, revision del 22 de abril de 2026 (obligatoria desde el 1 de noviembre de 2026).
Fuente oficial: www.hacienda.go.cr/docs/<Nombre>_V4.4.xsd (enlaces de la Oficina Virtual TRIBU-CR). Copia tomada el 11/10/2026 del
repositorio DojoCodingLabs/hacienda-cr (schemas/2026/v4.4), verificada contra los XSD oficiales de ATV (docs/esquemas/2024/v4.4):
solo cambian tres tipos simples (ClaveType alfanumerica, CodigoReferenciaType +13-16 y +17 en REP, TipoDocReferenciaType +19-20).
La version anterior (2024) quedo en Memorias/referencias/xsd_v4.4_2024_anterior. Los nombres se escriben en lowerCamelCase y el
import de xmldsig apunta al archivo local (asi los carga app/fe/validador.py).
