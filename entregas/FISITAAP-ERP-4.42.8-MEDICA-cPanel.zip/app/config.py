"""Configuración central del núcleo de facturación electrónica (Hacienda CR v4.4)."""
import os
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SCHEMAS_DIR = BASE_DIR / "schemas" / "v4.4"
DATA_DIR = Path(os.environ["FE_DATA_DIR"]) if os.environ.get("FE_DATA_DIR") else BASE_DIR / "data"   # FE_DATA_DIR: las pruebas usan una carpeta temporal
DATA_DIR.mkdir(exist_ok=True)
(DATA_DIR / "xml").mkdir(exist_ok=True)
(DATA_DIR / "certs").mkdir(exist_ok=True)

DB_URL = os.getenv("FE_DB_URL", f"sqlite:///{DATA_DIR / 'facturacr.db'}")

# Namespace base de los esquemas v4.4 (verificado contra el XSD oficial).
NS_BASE = "https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.4/"

# Tipos de comprobante soportados: código Hacienda -> (elemento raíz, sufijo de namespace / xsd)
TIPOS_DOCUMENTO = {
    "01": ("FacturaElectronica", "facturaElectronica"),
    "02": ("NotaDebitoElectronica", "notaDebitoElectronica"),
    "03": ("NotaCreditoElectronica", "notaCreditoElectronica"),
    "04": ("TiqueteElectronico", "tiqueteElectronico"),
    "08": ("FacturaElectronicaCompra", "facturaElectronicaCompra"),
    "09": ("FacturaElectronicaExportacion", "facturaElectronicaExportacion"),
    "10": ("ReciboElectronicoPago", "reciboElectronicoPago"),
}
# Mensajes del receptor (05 aceptado, 06 aceptado parcial, 07 rechazado) usan mensajeReceptor.xsd
TIPO_MENSAJE_RECEPTOR = {"05": 1, "06": 2, "07": 3}

AMBIENTES = {
    "sandbox": {
        # URL publicada en TRIBU-CR (2026). La antigua https://api.comprobanteselectronicos.go.cr/recepcion-sandbox/v1
        # (época ATV) responde 403 desde al menos octubre 2026. Verificado el 9/10/2026 con token válido.
        "api": "https://api-sandbox.comprobanteselectronicos.go.cr/recepcion/v1",
        "token": "https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token",
        "client_id": "api-stag",
    },
    "produccion": {
        "api": "https://api.comprobanteselectronicos.go.cr/recepcion/v1",
        "token": "https://idp.comprobanteselectronicos.go.cr/auth/realms/rut/protocol/openid-connect/token",
        "client_id": "api-prod",
    },
}

# APIs públicas de Hacienda (sin autenticación)
API_CONTRIBUYENTE = "https://api.hacienda.go.cr/fe/ae"      # ?identificacion=
API_CABYS = "https://api.hacienda.go.cr/fe/cabys"           # ?q=

# Política de firma XAdES-EPES (URL de la resolución + hash SHA-256 en base64).
# Valores tomados de una factura v4.4 real ACEPTADA por Hacienda en septiembre de 2026: los proveedores
# siguen referenciando la resolución v4.3. Si Hacienda publica una política nueva, ejecuta
# `python tools/politica_firma.py <URL>` y sobreescribe con FE_POLITICA_URL / FE_POLITICA_HASH.
POLITICA_FIRMA_URL = os.getenv(
    "FE_POLITICA_URL",
    "https://atv.hacienda.go.cr/ATV/ComprobanteElectronico/docs/esquemas/2016/v4.3/"
    "Resoluci%C3%B3n_General_sobre_disposiciones_t%C3%A9cnicas_comprobantes_electr%C3%B3nicos_para_efectos_tributarios.pdf",
)
POLITICA_FIRMA_HASH = os.getenv("FE_POLITICA_HASH", "0h7Q3dFHhu0bHbcZEgVc07cEcDlquUeG08HG6Iototo=")
POLITICA_FIRMA_DESCRIPCION = ""

ZONA_HORARIA = "-06:00"

# Hora oficial de Costa Rica, independiente de la zona horaria del servidor (cPanel suele estar en UTC).
# Con esto la fecha de la clave (ddmmyy) y FechaEmision siempre coinciden y van en hora CR.
from datetime import datetime as _dt
from zoneinfo import ZoneInfo as _ZoneInfo

TZ_CR = _ZoneInfo("America/Costa_Rica")


def ahora_cr() -> _dt:
    return _dt.now(TZ_CR)

# Cédula del PROVEEDOR DE SISTEMAS (campo obligatorio <ProveedorSistemas> de la v4.4): la de quien pone el sistema a
# disposición de los emisores. Para IT Core Sync facturando con su propio sistema coincide con su cédula; para las
# empresas cliente (SaaS) va la cédula de IT Core Sync, no la del cliente (Anexos v4.4, campo ProveedorSistemas).
# Formato: sin guiones (jurídica 10 caracteres). Se puede cambiar por empresa en Configuración › Facturación electrónica.
PROVEEDOR_SISTEMAS = os.environ.get("FE_PROVEEDOR_SISTEMAS", "3102956970")

# Token para que un cron externo dispare la cola de Hacienda (POST /api/cola/procesar con cabecera X-Cron-Token).
# Vacio = endpoint deshabilitado. Generar con: python -c "import secrets;print(secrets.token_urlsafe(32))"
CRON_TOKEN = os.environ.get("FE_CRON_TOKEN", "").strip()
# Datos de ejemplo en los módulos sin backend (cotizaciones, bancos, contabilidad, compras...). Apagado en producción;
# FE_DATOS_EJEMPLO=1 solo en instalaciones demo. La interfaz lo recibe en la respuesta de sesión (datos_ejemplo).
DATOS_EJEMPLO = os.environ.get("FE_DATOS_EJEMPLO", "0").strip().lower() in ("1", "true", "si", "sí", "yes")
# Dirección pública del sistema (https://facturas.ejemplo.com) para los enlaces de consulta que viajan en correos automáticos
# (la cola no tiene petición HTTP de la que tomarla). Si falta, se usa la de la petición cuando la hay y si no, sin enlace.
URL_PUBLICA = os.environ.get("FE_URL_PUBLICA", "").strip().rstrip("/")
# Instalación de pruebas (p. ej. labs en facturas.itcoresync.com): texto de una franja visible en todas las pantallas para no
# confundirla con producción. Vacío en producción.
AVISO_ENTORNO = re.sub(r"[\x00-\x1f<>]", "", os.environ.get("FE_AVISO_ENTORNO", "")).strip()[:80]
# Dominio anterior que pasa a ser otra instalación: los enlaces de consulta /p/... de los correos ya enviados se redirigen al dominio
# de producción indicado aquí (https://...). Vacío = no se redirige.
_red = os.environ.get("FE_REDIRIGIR_PUBLICOS", "").strip().rstrip("/")
REDIRIGIR_PUBLICOS = _red if re.fullmatch(r"https://[A-Za-z0-9.-]+(:\d+)?", _red) else ""


# ---- nombre del sistema en un solo lugar (3.51): data/sistema.json lo cambia el administrador desde la consola; FE_NOMBRE_SISTEMA es el valor inicial
_sistema_cache: dict = {}
NOMBRE_SISTEMA = "FISITAAP by Brillante Agencia"       # 3.86: marca del producto (antes «FISITAAP ERP»)
NOMBRES_VIEJOS = {"FISITAAP ERP"}
FIRMA_MARCA = "by Brillante Agencia"                   # lo que acompaña al logo de FISITAAP (pantallas y correos)


def sistema() -> dict:
    """{'nombre', 'eslogan', 'dominio', 'correo_ventas'} del producto. Se lee una vez por minuto; la consola limpia la caché al guardar."""
    import json as _json
    import time as _time
    if _sistema_cache and _time.time() < _sistema_cache.get("_vence", 0):
        return {k: _sistema_cache[k] for k in ("nombre", "eslogan", "dominio", "correo_ventas")}
    nombre = re.sub(r"[<>\"\\]", "", os.environ.get("FE_NOMBRE_SISTEMA", "")).strip()[:40] or NOMBRE_SISTEMA
    eslogan = "Facturación electrónica y administración de su empresa"
    # 3.77: dominio público del sistema (el de FE_URL_PUBLICA si está definida; si no, fisitaap.com) y correo de ventas
    dominio = re.sub(r"^https?://", "", URL_PUBLICA or "").split("/")[0].split(":")[0].strip().lower() or "fisitaap.com"
    correo = "ventas@" + dominio
    try:
        d = _json.loads((DATA_DIR / "sistema.json").read_text(encoding="utf-8"))
        if isinstance(d, dict):
            nombre = str(d.get("nombre") or nombre).strip()[:40] or nombre
            eslogan = str(d.get("eslogan") if d.get("eslogan") is not None else eslogan).strip()[:90]
            if d.get("dominio"):
                dominio = str(d["dominio"]).strip().lower()[:80]
                correo = "ventas@" + dominio
            if d.get("correo_ventas"):
                correo = str(d["correo_ventas"]).strip()[:120]
    except (OSError, ValueError):
        pass
    if nombre.upper() in NOMBRES_VIEJOS:                 # 3.86: el nombre de antes (consola o variable) pasa a la marca nueva
        nombre = NOMBRE_SISTEMA
    _sistema_cache.update(nombre=nombre, eslogan=eslogan, dominio=dominio, correo_ventas=correo, _vence=_time.time() + 60)
    return {"nombre": nombre, "eslogan": eslogan, "dominio": dominio, "correo_ventas": correo}


def nombre_sistema() -> str:
    return sistema()["nombre"]


def dominio_sistema() -> str:
    """Dominio público del sistema (fisitaap.com): página pública, subdominios de los negocios y enlaces en correos (3.77)."""
    return sistema()["dominio"]


def correo_ventas() -> str:
    """Correo de ventas que aparece en avisos de plan por vencer, prueba vencida y módulos no incluidos (3.77)."""
    return sistema()["correo_ventas"]
