"""Editor de recepción web. El portal sirve una copia publicada del diseño."""
import base64
import io
import json
import warnings
from typing import Literal

from fastapi import File, HTTPException, Response, UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import LargeBinary
from sqlmodel import Field as Col, SQLModel

from .db import por_empresa, sesion_de
from .medica import Base, Central, _evento, router
from .medica_operacion import Gestor
from .medica_portal import _empresa, pagina, portal

Plantilla = Literal["serena", "vital", "editorial"]
Seccion = Literal["servicios", "equipo", "seguros", "contacto"]
MAX_FOTO = 4 * 1024 * 1024


class Tarjeta(BaseModel):
    titulo: str = Field(min_length=1, max_length=100)
    texto: str = Field(default="", max_length=500)


class Diseno(BaseModel):
    plantilla: Plantilla = "serena"
    marca: str = Field(default="", max_length=90)
    titulo: str = Field(default="Atención médica cerca de ti", max_length=100)
    introduccion: str = Field(default="Consulta disponibilidad y reserva tu próxima cita.", max_length=450)
    boton: str = Field(default="Ver disponibilidad", max_length=35)
    color: str = Field(default="", pattern=r"^(#[0-9A-Fa-f]{6})?$")
    texto_foto: str = Field(default="Profesionales en la clínica", max_length=120)
    servicios: list[Tarjeta] = Field(default_factory=list, max_length=12)
    equipo: list[Tarjeta] = Field(default_factory=list, max_length=12)
    secciones: list[Seccion] = Field(default_factory=lambda: ["servicios","equipo","seguros","contacto"], max_length=4)
    direccion: str = Field(default="", max_length=180)
    telefono: str = Field(default="", max_length=40)
    correo: str = Field(default="", max_length=120)
    horario: str = Field(default="", max_length=200)

    @field_validator("secciones")
    @classmethod
    def sin_duplicados(cls, valores):
        if len(set(valores)) != len(valores):
            raise ValueError("Cada sección solo puede aparecer una vez")
        return valores


class WebClinica(SQLModel, table=True):
    __tablename__ = "medica_web_clinica"
    id: int = Col(default=1, primary_key=True)
    borrador: str = "{}"
    publicado: str | None = None
    foto: bytes | None = Col(default=None, sa_type=LargeBinary)
    foto_publicada: bytes | None = Col(default=None, sa_type=LargeBinary)


por_empresa(WebClinica)


def _web(s):
    fila = s.get(WebClinica, 1)
    if fila is None:
        fila = WebClinica()
        s.add(fila)
    return fila


def _diseno(valores, empresa):
    data = Diseno.model_validate(json.loads(valores or "{}")).model_dump()
    data["marca"] = data["marca"] or empresa.nombre_comercial or empresa.nombre
    return data


@router.get("/recepcion-web")
def consultar_editor(ctx: Gestor, s: Base):
    fila = s.get(WebClinica, 1)
    imagen = base64.b64encode(fila.foto).decode() if fila and fila.foto else None
    return {"diseno": _diseno(fila.borrador if fila else None, ctx.empresa), "foto": imagen,
            "publicado": bool(fila and fila.publicado), "url": f"/medica/web/{ctx.empresa.id}"}


class GuardarDisenoIn(BaseModel):
    diseno: Diseno
    publicar: bool = False


@router.put("/recepcion-web")
def guardar_diseno(data: GuardarDisenoIn, ctx: Gestor, s: Base):
    s.connection().exec_driver_sql("BEGIN IMMEDIATE")
    fila = _web(s)
    fila.borrador = data.diseno.model_dump_json()
    if data.publicar:
        fila.publicado = fila.borrador
        fila.foto_publicada = fila.foto
    _evento(s, ctx, "web.publicada" if data.publicar else "web.borrador", 1)
    s.commit()
    return {"publicado": bool(fila.publicado), "url": f"/medica/web/{ctx.empresa.id}"}


@router.delete("/recepcion-web/publicacion")
def retirar_web(ctx: Gestor, s: Base):
    s.connection().exec_driver_sql("BEGIN IMMEDIATE")
    fila = s.get(WebClinica, 1)
    if fila:
        fila.publicado = None
        fila.foto_publicada = None
        _evento(s, ctx, "web.retirada", 1)
        s.commit()
    return {"publicado": False}


@router.put("/recepcion-web/foto")
def subir_foto(ctx: Gestor, s: Base, archivo: UploadFile = File(...)):
    from .main import _leer_subida

    entrada = _leer_subida(archivo, MAX_FOTO)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(entrada), formats=["JPEG","PNG","WEBP"]) as original:
                imagen = ImageOps.exif_transpose(original).convert("RGB")
                imagen.thumbnail((1600, 1200))
                buffer = io.BytesIO()
                imagen.save(buffer, "JPEG", quality=86, optimize=True)
    except (UnidentifiedImageError, Image.DecompressionBombError, Image.DecompressionBombWarning, OSError, ValueError):
        raise HTTPException(422, "Seleccione una foto JPG, PNG o WebP válida") from None
    s.connection().exec_driver_sql("BEGIN IMMEDIATE")
    fila = _web(s)
    fila.foto = buffer.getvalue()
    s.commit()
    return {"foto": base64.b64encode(buffer.getvalue()).decode()}


@router.delete("/recepcion-web/foto")
def quitar_foto(ctx: Gestor, s: Base):
    s.connection().exec_driver_sql("BEGIN IMMEDIATE")
    fila = s.get(WebClinica, 1)
    if fila:
        fila.foto = None
        s.commit()
    return {"foto": None}


@portal.get("/medica/web/{eid}", include_in_schema=False)
def web_clinica(eid: int, sc: Central):
    return pagina(eid, sc)


@portal.get("/api/medica/portal/{eid}/diseno")
def diseno_web(eid: int, sc: Central):
    empresa = _empresa(sc, eid)
    with sesion_de(eid) as s:
        fila = s.get(WebClinica, 1)
        data = _diseno(fila.publicado if fila else None, empresa)
        data["foto_url"] = f"/api/medica/portal/{eid}/foto" if fila and fila.foto_publicada else None
        return data


@portal.get("/api/medica/portal/{eid}/foto")
def foto_web(eid: int, sc: Central):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        foto = s.get(WebClinica, 1)
        if not foto or not foto.publicado or not foto.foto_publicada:
            raise HTTPException(404, "Foto no disponible")
        return Response(foto.foto_publicada, media_type="image/jpeg", headers={"Cache-Control":"no-store"})
