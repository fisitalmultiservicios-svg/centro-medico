# -*- coding: utf-8 -*-
"""Etapa 2a: diario de cambios de cada base de empresa (la regla está en Memorias/REGLAS_sincronizacion_etapa_2a.md).

Cada comprobante o cobro que nace, cambia o se borra deja una línea en sinc_diario dentro de la misma transacción: si el guardado falla, la línea
tampoco queda. Quien sincroniza pide las líneas posteriores a su número de avance. Hay una sola línea por dato (la última gana y recibe un número
nuevo) porque viaja el estado actual del dato, no la historia de sus cambios. AUTOINCREMENT es obligatorio: sin él, SQLite repetiría el número de la
última línea reemplazada y quien ya pasó por ese número no vería el cambio.

Cada línea dice qué terminal la produjo (0 = la nube): lo que se aplica desde otro lado corre dentro de `aplicando(origen)`, y así no se le devuelve."""
import contextvars
import logging
from contextlib import contextmanager
from datetime import timezone
from typing import Optional

from sqlalchemy import UniqueConstraint, event
from sqlalchemy import inspect as sa_inspect
from sqlalchemy import text as _sql
from sqlmodel import Field, Session, SQLModel

from . import modulos
from .db import Documento, por_empresa

log = logging.getLogger(__name__)


class SincDiario(SQLModel, table=True):
    __tablename__ = "sinc_diario"
    __table_args__ = (UniqueConstraint("tipo", "ref", name="ux_sinc_diario"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    tipo: str                               # documento | pago
    ref: str                                # documento: su clave; pago: «terminal:id:sello» donde nació
    origen: int = 0                         # terminal que produjo este cambio (0 = la nube)
    borrado: bool = False


por_empresa(SincDiario)

# campos de un comprobante cuyo cambio le interesa a los demás (sinc_en, intentos, etc. son internos de cada base)
CAMPOS_DOCUMENTO = ("estado", "mensaje_hacienda", "xml_nombre", "respuesta_nombre", "correo_enviado", "acreditado")
_origen: contextvars.ContextVar[Optional[int]] = contextvars.ContextVar("sinc_origen", default=None)


@contextmanager
def aplicando(origen: int):
    """Lo que se guarde aquí adentro viene de `origen`: no se le devuelve."""
    marca = _origen.set(int(origen or 0))
    try:
        yield
    finally:
        _origen.reset(marca)


def sello(p) -> int:
    """Segundo en que nació el cobro: SQLite reutiliza el id del último cobro borrado, y sin esto el nuevo se confundiría con el borrado."""
    return int(p.creado.replace(tzinfo=p.creado.tzinfo or timezone.utc).timestamp()) if p.creado else 0


def ref_pago(p) -> str:
    return p.origen_sinc or f"{modulos.rango_propio(p.empresa_id)}:{p.id}:{sello(p)}"


def _linea(obj, nuevo: bool, borrado: bool):
    if isinstance(obj, Documento):
        if borrado or not obj.clave:
            return None
        if not nuevo:
            estado = sa_inspect(obj)
            if not any(estado.attrs[c].history.has_changes() for c in CAMPOS_DOCUMENTO):
                return None
        return "documento", obj.clave, obj.empresa_id, False
    if isinstance(obj, modulos.Pago) and (nuevo or borrado):
        return "pago", ref_pago(obj), obj.empresa_id, borrado
    return None


def _al_vaciar(session, _contexto) -> None:
    """Después de escribir y antes del commit: la sesión todavía tiene las listas y el historial previos al flush. Un error aquí nunca detiene una venta."""
    try:
        filas = []
        for objetos, nuevo, borrado in ((session.new, True, False), (session.dirty, False, False), (session.deleted, False, True)):
            for obj in objetos:
                f = _linea(obj, nuevo, borrado)
                if f:
                    filas.append(f)
        if not filas:
            return
        conexion = session.connection()
        fijado = _origen.get()
        for tipo, ref, eid, borrado in filas:
            origen = fijado if fijado is not None else modulos.rango_propio(eid)
            conexion.execute(_sql("INSERT OR REPLACE INTO sinc_diario (tipo, ref, origen, borrado) VALUES (:t, :r, :o, :b)"), {"t": tipo, "r": ref, "o": origen, "b": borrado})
    except Exception:  # noqa: BLE001
        log.exception("sinc_diario: no se pudo anotar un cambio")


event.listen(Session, "after_flush", _al_vaciar)


def sembrar(s) -> None:
    """Lo que existía antes de la primera vinculación entra al diario, sin pisar lo que ya tenga una línea."""
    s.execute(_sql("INSERT OR IGNORE INTO sinc_diario (tipo, ref, origen, borrado) SELECT 'documento', clave, 0, 0 FROM documento WHERE clave IS NOT NULL AND clave <> ''"))
    s.execute(_sql("INSERT OR IGNORE INTO sinc_diario (tipo, ref, origen, borrado) SELECT 'pago', COALESCE(NULLIF(origen_sinc, ''), '0:' || id || ':' || CAST(strftime('%s', creado) AS INTEGER)), 0, 0 FROM pago"))
