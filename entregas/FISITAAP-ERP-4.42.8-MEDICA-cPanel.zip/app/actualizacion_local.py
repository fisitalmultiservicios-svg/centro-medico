"""Actualización automática del programa local Windows (3.58; 4.9: FISITAAPLocal.exe, reemplazo con PowerShell y vuelta atrás).

Era el único punto donde un cliente podía quedarse con una versión vieja: el zip actualiza la nube para todas las empresas a la
vez, pero el exe había que copiarlo a mano en cada computadora. Ahora:

- Nube: el administrador del sistema publica el exe en Administración › Programa local (o copia a mano `data/local/GrupoFacturaLocal.exe`
  y `version.json` {version, sha256, bytes, fecha} con el administrador de archivos del hosting, si la subida por pantalla falla por
  el tamaño). `GET /api/local/version` y `GET /api/local/descargar` son públicos: el exe los consulta sin sesión (el programa se
  entrega a los clientes de todos modos; lo que importa es el sha256, que el exe verifica antes de instalar nada).
  4.9: en la nube el archivo se sigue guardando como GrupoFacturaLocal.exe (las versiones 1.x lo descargan por la misma ruta y las
  instrucciones de copia a mano no cambian); quien lo descarga lo recibe como FISITAAPLocal.exe.
  4.26: `version.json` puede llevar `automatica` (sin el campo vale verdadero). En falso, `/api/local/version` contesta
  `{"version": null}` (ningún programa instalado se actualiza solo) y el programa queda solo para descargar desde la página web
  (Configuración › Instalación local, con `GET /api/local/instalador`). Se cambia con `POST /api/admin/local/automatica`.
- Exe: 90 s después de arrancar y luego cada 6 horas pregunta a la nube con la que está vinculado (Configuración › Instalación
  local) si hay una versión más nueva que la suya (comparación numérica por partes: 4.10 > 4.9 > 1.46); si la hay, la descarga a
  `FISITAAPLocal.nuevo.exe` junto a los datos, verifica tamaño y sha256 y anota `actualizacion.json`. Al siguiente arranque (o con
  «Reiniciar y actualizar» en Configuración › Instalación local) se instala.
- 4.9, cómo se instala: la 3.58 usaba un .bat que no esperaba de verdad a que el exe se cerrara (sin consola `timeout` falla al
  instante: solo quedaban unos 5 segundos de reintentos y, si no alcanzaban, el programa no se volvía a abrir) y que dependía de la
  página de códigos de Windows para las rutas (iba en cp1252: un usuario con letras fuera de ella lo rompía). Ahora un guion
  de PowerShell (`actualizar.ps1`, UTF-8) recibe todas las rutas por variables de entorno, espera de verdad a que el programa se
  cierre, verifica el sha256, guarda el programa actual como `FISITAAPLocal.anterior.exe`, copia el nuevo, lo abre y espera su
  señal de arranque (`arranque.json`, la escribe local/local.py cuando el servidor ya responde; hasta 15 minutos). Si la versión
  nueva se cierra sin arrancar, avisa un error o no responde a tiempo, vuelve a poner la anterior, la abre y anota la versión como
  fallida en `actualizacion_resultado.json` (no se reintenta hasta que se publique otra). Todo queda en `actualizacion.log` y los errores también en `local_error.log`.
- 4.9 (revisión), nunca un programa que se cierra solo en cada arranque: cada intento de instalar una descarga se cuenta en
  `actualizacion_intentos.json` (por sha256) ANTES de lanzar el guion; a los 3 intentos sin que cambie nada (falló antes de
  abrir la versión nueva, también si la copia falló o quedó incompleta, o el guion ni siquiera corrió: PowerShell bloqueado
  por una política, un antivirus) esa descarga
  queda como fallida y el programa sigue con su versión. Además el programa solo se cierra cuando ve que el guion de verdad
  corre (tiene el cerrojo `actualizar.cerrojo`); si PowerShell se cierra antes o no da señales en 30 s, sigue y sirve.
- 4.9 (revisión), una sola actualización a la vez: el guion abre `actualizar.cerrojo` sin compartir mientras dura (Windows lo
  suelta solo si el guion termina o se cae). Un segundo arranque que encuentra el cerrojo tomado no lanza otro guion: se cierra
  y el que ya corre abre el programa al terminar (antes, dos guiones podían pisar FISITAAPLocal.anterior.exe con la versión nueva).
"""
import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from .auth import Contexto, Usuario, requiere, solo_usuario, superadmin
from .config import DATA_DIR, ahora_cr

log = logging.getLogger(__name__)
router = APIRouter(tags=["local"])
CARPETA_NUBE = DATA_DIR / "local"
EXE_NUBE = "GrupoFacturaLocal.exe"       # 4.9: nombre con el que la nube guarda el programa publicado (no cambia)
EXE = "FISITAAPLocal.exe"                # 4.9: nombre del programa en la computadora del cliente
NUEVO = "FISITAAPLocal.nuevo.exe"        # la versión descargada, lista para instalarse
ANTERIOR = "FISITAAPLocal.anterior.exe"  # la versión que se reemplazó (para volver atrás)
GUION = "actualizar.ps1"
RESULTADO = "actualizacion_resultado.json"
INTENTOS = "actualizacion_intentos.json"   # 4.9: cuántas veces se lanzó la instalación de cada descarga (por sha256)
MAX_INTENTOS = 3                           # 4.9: a los 3 intentos sin cambio, la descarga queda como fallida (no más reinicios)
CERROJO = "actualizar.cerrojo"             # 4.9: lo tiene abierto, sin compartir, el actualizar.ps1 que está corriendo
CERROJO_VENCE = 30 * 60                    # 4.9: un guion dura a lo sumo ~17 min (90 s + copias + 15 min de arranque): más es uno colgado
MAX_EXE = 120 * 1024 * 1024
MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"
_estado: dict = {"revisado": None, "error": None}


def _partes(v) -> tuple:
    """4.9: versión → números para comparar por partes: «4.9» → (4, 9), «4.10» → (4, 10), «1.46» → (1, 46). Los ceros del final
    no cuentan (4.9 = 4.9.0) y lo que no es número se ignora («v4.9b» → (4, 9))."""
    texto = re.sub(r"^[^\d]+", "", str(v or "").strip())
    out = []
    for p in texto.split("."):
        m = re.match(r"\s*(\d+)", p)
        out.append(int(m.group(1)) if m else 0)
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return tuple(out) or (0,)


def mas_nueva(nueva, actual) -> bool:
    return _partes(nueva) > _partes(actual)


def _sha_archivo(ruta: Path) -> str:
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for trozo in iter(lambda: f.read(1024 * 1024), b""):
            h.update(trozo)
    return h.hexdigest()


# ------------------------------------------------------------------------------------------------- nube
def _publicado() -> Optional[dict]:
    meta, exe = CARPETA_NUBE / "version.json", CARPETA_NUBE / EXE_NUBE
    if not meta.exists() or not exe.exists():
        return None
    try:
        d = json.loads(meta.read_text(encoding="utf-8"))
    except ValueError:
        return None
    if not isinstance(d, dict) or not d.get("version") or not d.get("sha256"):
        return None
    return {"version": str(d["version"]), "archivo": EXE_NUBE, "bytes": int(d.get("bytes") or exe.stat().st_size), "sha256": str(d["sha256"]), "fecha": d.get("fecha"),
            "automatica": _automatica(d)}


def _automatica(d: dict) -> bool:
    """4.26: ¿las computadoras conectadas se actualizan solas con lo publicado? Sin el campo (copiado a mano o publicado antes de la
    4.26) vale verdadero, como siempre. Solo un falso de verdad (false, 0, «false», «no»…) la apaga."""
    v = d.get("automatica", True)
    if isinstance(v, str):
        return v.strip().lower() not in ("false", "0", "no", "off")
    return v is None or bool(v)


@router.get("/api/local/version")
def version_publicada():
    """Versión del programa local publicada en la nube (pública: la consulta cada instalación). 4.26: con la actualización automática
    desactivada contesta como si no hubiera nada publicado, y así ningún programa instalado se actualiza solo."""
    p = _publicado()
    if not p or not p["automatica"]:
        return {"version": None}
    return {k: v for k, v in p.items() if k != "automatica"}          # lo mismo que antes de la 4.26


@router.get("/api/local/instalador")
def instalador_publicado():
    """4.26: lo que la página web necesita para ofrecer la descarga del programa (Configuración › Instalación local), haya o no
    actualización automática. Pública como /api/local/version y /api/local/descargar."""
    p = _publicado()
    if not p:
        return {"version": None}
    return {"version": p["version"], "bytes": p["bytes"], "fecha": p["fecha"], "automatica": p["automatica"]}


@router.get("/api/local/descargar", include_in_schema=False)
def descargar_publicado():
    p = _publicado()
    if not p:
        raise HTTPException(404, "No hay un programa local publicado")
    return FileResponse(CARPETA_NUBE / EXE_NUBE, media_type="application/octet-stream", filename=EXE, headers={"Cache-Control": "no-store"})


@router.get("/api/admin/local")
def admin_local(_: Usuario = Depends(superadmin)):
    return {"publicado": _publicado(), "carpeta": str(CARPETA_NUBE)}


@router.post("/api/admin/local/publicar")
def admin_publicar(archivo: UploadFile = File(...), version: str = Form(...), automatica: Optional[str] = Form(None),
                   _: Usuario = Depends(superadmin)):
    """Sube el exe y anota su versión y sha256. Se escribe primero a un archivo temporal: si la subida se corta, lo publicado sigue.
    4.26: `automatica` (opcional, por omisión verdadero) decide si las computadoras conectadas se actualizan solas con él."""
    auto = _automatica({"automatica": automatica})
    v = (version or "").strip()
    if not v or any(not p.isdigit() for p in v.split(".")):
        raise HTTPException(400, "Indique la versión del programa, por ejemplo 4.9")
    if not (archivo.filename or "").lower().endswith(".exe"):
        raise HTTPException(400, "El archivo debe ser el programa (.exe)")
    CARPETA_NUBE.mkdir(parents=True, exist_ok=True)
    tmp = CARPETA_NUBE / (EXE_NUBE + ".subiendo")
    h = hashlib.sha256(); total = 0
    try:
        with open(tmp, "wb") as f:
            while True:
                trozo = archivo.file.read(1024 * 1024)
                if not trozo:
                    break
                total += len(trozo)
                if total > MAX_EXE:
                    raise HTTPException(400, "El programa no puede pasar de 120 MB")
                h.update(trozo); f.write(trozo)
        if total < 1024:
            raise HTTPException(400, "El archivo está vacío o incompleto")
        os.replace(tmp, CARPETA_NUBE / EXE_NUBE)
    finally:
        tmp.unlink(missing_ok=True)
    meta = {"version": v, "sha256": h.hexdigest(), "bytes": total, "fecha": ahora_cr().isoformat(timespec="seconds"), "automatica": auto}
    (CARPETA_NUBE / "version.json").write_text(json.dumps(meta), encoding="utf-8")
    return {"ok": True, "publicado": _publicado()}


@router.post("/api/admin/local/automatica")
def admin_automatica(datos: dict = Body(...), _: Usuario = Depends(superadmin)):
    """4.26: activa o desactiva la actualización automática de lo publicado sin volver a subir el archivo. Solo cambia ese campo
    de version.json (el archivo, la versión y el sha256 quedan iguales)."""
    if not _publicado():
        raise HTTPException(404, "No hay un programa local publicado")
    valor = datos.get("automatica") if isinstance(datos, dict) else None
    if not isinstance(valor, bool):
        raise HTTPException(400, "Indique si la actualización automática queda activada (true) o desactivada (false)")
    ruta = CARPETA_NUBE / "version.json"
    meta = json.loads(ruta.read_text(encoding="utf-8"))
    meta["automatica"] = valor
    tmp = CARPETA_NUBE / "version.json.cambiando"
    tmp.write_text(json.dumps(meta), encoding="utf-8")
    os.replace(tmp, ruta)
    return {"ok": True, "publicado": _publicado()}


@router.delete("/api/admin/local")
def admin_quitar(_: Usuario = Depends(superadmin)):
    for n in (EXE_NUBE, "version.json"):
        (CARPETA_NUBE / n).unlink(missing_ok=True)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- instalación local
def version_local() -> str:
    return os.environ.get("FE_VERSION_LOCAL", "") or ""


def carpeta_local() -> Path:
    return Path(os.environ.get("FE_CARPETA_LOCAL") or (DATA_DIR.parent if DATA_DIR.name == "datos" else DATA_DIR))


def url_nube() -> Optional[str]:
    """Dirección de la nube con la que está vinculada alguna empresa de esta instalación (Configuración › Instalación local)."""
    try:
        from sqlmodel import Session, select
        from . import sinc
        from .db import Empresa, engine, engine_empresa
        with Session(engine) as sc:
            eids = [x.id for x in sc.exec(select(Empresa)).all()]
        for eid in eids:
            with Session(engine_empresa(eid)) as s:
                cfg = sinc._cfg_local(s, eid)
                if cfg.get("vinculado") and cfg.get("url"):
                    return str(cfg["url"]).rstrip("/")
    except Exception as ex:  # noqa: BLE001
        log.warning("actualización local: no se pudo leer la vinculación: %s", ex)
    return None


def _leer_json(ruta: Path) -> Optional[dict]:
    try:
        d = json.loads(ruta.read_text(encoding="utf-8-sig"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def _meta_descarga(carpeta: Path) -> Optional[dict]:
    return _leer_json(carpeta / "actualizacion.json")


def resultado(carpeta: Optional[Path] = None) -> Optional[dict]:
    """4.9: lo que pasó en la última instalación de una versión nueva ({ok, version, sha256, detalle, fecha}) o None."""
    return _leer_json((carpeta or carpeta_local()) / RESULTADO)


def intentos(carpeta: Path, sha256) -> int:
    """4.9: cuántas veces se lanzó ya la instalación de esa descarga (0 si es otra descarga o no hay registro)."""
    d = _leer_json(Path(carpeta) / INTENTOS) or {}
    if not sha256 or str(d.get("sha256") or "").lower() != str(sha256).lower():
        return 0
    try:
        return int(d.get("intentos") or 0)
    except (TypeError, ValueError):
        return 0


def _anotar_intento(carpeta: Path, sha256) -> int:
    """4.9: suma un intento de instalar esa descarga, ANTES de lanzar el guion (así cuenta también un guion que nunca llega a
    correr). Devuelve el número de intentos, o 0 si no se pudo anotar (entonces no se lanza: sin la cuenta no hay tope)."""
    n = intentos(carpeta, sha256) + 1
    try:
        (Path(carpeta) / INTENTOS).write_text(json.dumps({"sha256": str(sha256 or ""), "intentos": n,
                                                          "fecha": ahora_cr().isoformat(timespec="seconds")}), encoding="utf-8")
    except OSError as ex:
        log.error("actualización local: no se pudo anotar el intento: %s", ex)
        return 0
    return n


def _motivo_fallida(carpeta: Path, sha256) -> Optional[str]:
    """4.9: por qué esa descarga ya no se intenta instalar: «no_arranco» (se abrió, no arrancó y se volvió a la anterior) o
    «intentos» (se lanzó MAX_INTENTOS veces sin que cambiara nada). None si todavía se puede intentar."""
    r = resultado(carpeta)
    if r and r.get("ok") is False and r.get("probada", True) and sha256 and str(r.get("sha256") or "").lower() == str(sha256).lower():
        return "no_arranco"
    if intentos(carpeta, sha256) >= MAX_INTENTOS:      # 4.9 (revisión): tope, falle donde falle (o aunque el guion no corra)
        return "intentos"
    return None


def _fallida(carpeta: Path, sha256) -> bool:
    """4.9: esa misma descarga ya no se instala (no arrancó, o se intentó MAX_INTENTOS veces): evita un ciclo de reinicios."""
    return _motivo_fallida(carpeta, sha256) is not None


def _texto_fallida(motivo: str, version, version_actual=None) -> str:
    if motivo == "intentos":
        return (f"La versión {version} no se pudo instalar después de {MAX_INTENTOS} intentos (detalle en actualizacion.log); el programa "
                f"sigue con la versión {version_actual or 'actual'} y se espera a que se publique otra")
    return f"La versión {version} no arrancó en esta computadora y se volvió a la anterior; se espera a que se publique otra"


def pendiente(carpeta: Optional[Path] = None) -> Optional[dict]:
    """La versión nueva ya descargada y verificada, lista para instalarse, o None."""
    carpeta = carpeta or carpeta_local()
    d = _meta_descarga(carpeta); exe = carpeta / NUEVO
    if not d or not d.get("listo") or not exe.exists():
        return None
    actual = version_local()
    if not actual or not mas_nueva(d.get("version"), actual):
        return None          # ya es la versión que está corriendo (se instaló); 4.9: sin saber la versión propia no se instala nada
    if _fallida(carpeta, d.get("sha256")):
        return None
    try:
        if exe.stat().st_size != int(d.get("bytes") or 0) or _sha_archivo(exe) != d.get("sha256"):
            return None
    except OSError:
        return None
    return {"version": d.get("version"), "fecha": d.get("fecha"), "bytes": d.get("bytes")}


def revisar(version_actual: str, carpeta: Optional[Path] = None, url: Optional[str] = None) -> dict:
    """Pregunta a la nube y, si hay una versión más nueva, la descarga y verifica. Devuelve {nueva, descargada, error}."""
    import httpx
    carpeta = carpeta or carpeta_local(); url = (url or url_nube() or "").rstrip("/")
    _estado["revisado"] = ahora_cr().isoformat(timespec="seconds"); _estado["error"] = None
    if not url:
        return {"nueva": None, "descargada": False, "error": "La instalación no está vinculada con la nube"}
    try:
        r = httpx.get(url + "/api/local/version", timeout=20)
        r.raise_for_status(); info = r.json()
    except Exception as ex:  # noqa: BLE001
        _estado["error"] = f"No se pudo consultar la nube: {ex}"
        return {"nueva": None, "descargada": False, "error": _estado["error"]}
    nueva = info.get("version") if isinstance(info, dict) else None
    if not nueva or not mas_nueva(nueva, version_actual):
        return {"nueva": None, "descargada": False, "error": None}
    motivo = _motivo_fallida(carpeta, info.get("sha256"))
    if motivo:
        _estado["error"] = _texto_fallida(motivo, nueva, version_actual)
        return {"nueva": nueva, "descargada": False, "error": _estado["error"]}
    ya = _meta_descarga(carpeta)
    if ya and ya.get("version") == nueva and ya.get("sha256") == info.get("sha256") and pendiente(carpeta):
        return {"nueva": nueva, "descargada": True, "error": None}    # ya estaba descargada
    parcial = carpeta / (NUEVO + ".parcial")
    try:
        carpeta.mkdir(parents=True, exist_ok=True)
        h = hashlib.sha256(); total = 0
        with httpx.stream("GET", url + "/api/local/descargar", timeout=httpx.Timeout(600, connect=20)) as resp:
            resp.raise_for_status()
            with open(parcial, "wb") as f:
                for trozo in resp.iter_bytes(1024 * 1024):
                    total += len(trozo); h.update(trozo); f.write(trozo)
                    if total > MAX_EXE:
                        raise ValueError("el archivo es más grande de lo permitido")
        if total != int(info.get("bytes") or 0) or h.hexdigest() != info.get("sha256"):
            raise ValueError("el archivo descargado no coincide con el publicado (tamaño o firma)")
        os.replace(parcial, carpeta / NUEVO)
        (carpeta / "actualizacion.json").write_text(json.dumps({"version": nueva, "sha256": info.get("sha256"), "bytes": total, "listo": True,
                                                               "fecha": ahora_cr().isoformat(timespec="seconds")}), encoding="utf-8")
        log.info("actualización local: versión %s descargada y verificada", nueva)
        return {"nueva": nueva, "descargada": True, "error": None}
    except Exception as ex:  # noqa: BLE001
        parcial.unlink(missing_ok=True)
        _estado["error"] = f"No se pudo descargar la versión {nueva}: {ex}"
        log.warning(_estado["error"])
        return {"nueva": nueva, "descargada": False, "error": _estado["error"]}


def iniciar_hilo(version_actual: str, carpeta: Path, espera: int = 90, cada: int = 6 * 3600):
    def _ciclo():
        time.sleep(espera)
        while True:
            try:
                revisar(version_actual, carpeta)
            except Exception as ex:  # noqa: BLE001
                log.warning("actualización local: %s", ex)
            time.sleep(cada)
    threading.Thread(target=_ciclo, name="actualizacion-local", daemon=True).start()


# ------------------------------------------------------------------------------------------------- reemplazo (4.9)
GUION_PS1 = r"""# 4.9: reemplazo de FISITAAP Local por la versión descargada. Lo escribe y lanza app/actualizacion_local.py (aplicar).
# Las rutas y los datos llegan en variables de entorno FE_ACT_* y nunca se escriben dentro de este guion: un usuario de
# Windows con tilde, ñ o apóstrofo no rompe nada. Pasos: esperar a que el programa se cierre, verificar el sha256, guardar el
# programa actual como «anterior», copiar el nuevo, abrirlo y esperar su señal de arranque (arranque.json, hasta 15 minutos:
# la primera vez puede migrar la base). Si la versión nueva se cierra sin arrancar, avisa un error o no responde en ese tiempo,
# vuelve a poner la anterior, la abre y anota la versión como fallida.
$ErrorActionPreference = 'Stop'
$carpeta    = [string]$env:FE_ACT_CARPETA
$nuevo      = [string]$env:FE_ACT_NUEVO
$destino    = [string]$env:FE_ACT_DESTINO
$actual     = [string]$env:FE_ACT_EXE_ACTUAL
$anterior   = [string]$env:FE_ACT_ANTERIOR
$version    = [string]$env:FE_ACT_VERSION
$sha        = ([string]$env:FE_ACT_SHA256).ToLower()
$argumentos = ([string]$env:FE_ACT_ARGS).Trim()
$pids = @(([string]$env:FE_ACT_PIDS).Split(',') | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ })
$esperaCierre = 90
if ($env:FE_ACT_ESPERA_CIERRE -match '^\d+$') { $esperaCierre = [int]$env:FE_ACT_ESPERA_CIERRE }
$esperaArranque = 900
if ($env:FE_ACT_ESPERA_ARRANQUE -match '^\d+$') { $esperaArranque = [int]$env:FE_ACT_ESPERA_ARRANQUE }
$registro  = Join-Path $carpeta 'actualizacion.log'
$resultado = Join-Path $carpeta 'actualizacion_resultado.json'
$marca     = Join-Path $carpeta 'arranque.json'
$errores   = Join-Path $carpeta 'local_error.log'
$utf8      = New-Object System.Text.UTF8Encoding($false)

function Anotar([string]$t) {
  try { [IO.File]::AppendAllText($registro, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $t + "`r`n", $utf8) } catch { }
}
function Resultado([bool]$ok, [string]$detalle, [bool]$probada = $true) {
  # probada: la versión nueva llegó a abrirse (si falló así, no se reintenta la misma descarga)
  $o = New-Object PSObject -Property ([ordered]@{ ok = $ok; probada = $probada; version = $version; sha256 = $sha; detalle = $detalle;
        fecha = (Get-Date -Format 's'); destino = $destino; anterior = $anterior })
  try { [IO.File]::WriteAllText($resultado, ($o | ConvertTo-Json), $utf8) } catch { }
  if (-not $ok) {
    try { [IO.File]::AppendAllText($errores, "`r`n" + (Get-Date -Format 's') + " Actualización automática a la versión $version no aplicada: $detalle`r`n", $utf8) } catch { }
  }
}
function Normal([string]$r) { if (-not $r) { return '' }; try { return [IO.Path]::GetFullPath($r).ToLower() } catch { return $r.ToLower() } }
$nActual = Normal $actual
$nDestino = Normal $destino
function DelPrograma {
  # procesos que corren el programa (el actual o el destino), menos este guion
  $v = @()
  foreach ($x in @(Get-Process -ErrorAction SilentlyContinue)) {
    if ($x.Id -eq $PID) { continue }
    $ruta = $null
    try { $ruta = $x.Path } catch { }
    if ($ruta) { $n = Normal $ruta; if (($n -eq $nActual) -or ($n -eq $nDestino)) { $v += $x.Id } }
  }
  return $v
}
function Abiertos {
  $v = @(DelPrograma)
  foreach ($i in $pids) { if (Get-Process -Id $i -ErrorAction SilentlyContinue) { $v += $i } }
  return $v
}
function Hash([string]$r) { return (Get-FileHash -LiteralPath $r -Algorithm SHA256).Hash.ToLower() }
function Copiar([string]$de, [string]$a) {
  # con reintentos: el antivirus o Windows pueden tener el archivo abierto unos segundos
  for ($n = 1; $true; $n++) {
    try { [IO.File]::Copy($de, $a, $true); return } catch { if ($n -ge 30) { throw }; Start-Sleep -Milliseconds 500 }
  }
}
function Abrir([string]$r) {
  # Process.Start y no Start-Process: este último toma los corchetes de la ruta como comodines
  $i = New-Object System.Diagnostics.ProcessStartInfo
  $i.FileName = $r
  $i.WorkingDirectory = $carpeta
  $i.UseShellExecute = $true
  if ($argumentos) { $i.Arguments = $argumentos }
  $p = [System.Diagnostics.Process]::Start($i)
  if (-not $p) { throw "no se pudo abrir $r" }
  return $p
}

# 4.9 (revisión): una sola actualización a la vez. Si dos arranques del programa lanzan este guion casi juntos, el segundo no
# consigue el cerrojo (actualizar.cerrojo, abierto sin compartir mientras dure este guion; Windows lo suelta solo si el guion
# termina o se cae) y no hace nada: el primero abre el programa al terminar. Los reintentos cubren el instante en que el
# programa lo revisa. El programa además sabe por el cerrojo que este guion de verdad corre antes de cerrarse.
$cerrojo = $null
for ($n = 1; ($n -le 10) -and (-not $cerrojo); $n++) {
  try { $cerrojo = [IO.File]::Open((Join-Path $carpeta 'actualizar.cerrojo'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
  catch { Start-Sleep -Milliseconds 300 }
}
if (-not $cerrojo) { Anotar "Otra actualización ya está en curso: esta (versión $version) no hace nada"; return }
# desde cuándo lo tiene (el programa no confía en un cerrojo de un guion colgado: ver CERROJO_VENCE en actualizacion_local.py)
try { [IO.File]::WriteAllText((Join-Path $carpeta 'actualizar.cerrojo.json'), ('{"pid": ' + $PID + ', "inicio": ' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() + '}'), $utf8) } catch { }
if (-not [IO.File]::Exists($nuevo)) {
  # 4.9 (revisión): ya no hay nada que instalar (otra actualización la puso mientras este guion esperaba el cerrojo, o el archivo
  # desapareció). No se anota resultado ni se cambia nada; solo se asegura de que el programa quede abierto.
  Anotar "No se encontró la versión descargada ${version} (¿ya la instaló otra actualización?): no se cambia nada"
  $limite = (Get-Date).AddSeconds($esperaCierre)
  while ((@($pids | Where-Object { Get-Process -Id $_ -ErrorAction SilentlyContinue }).Count -gt 0) -and ((Get-Date) -lt $limite)) { Start-Sleep -Milliseconds 500 }
  Start-Sleep -Seconds 2
  if (@(DelPrograma).Count -eq 0) {
    $abrir = $destino
    if (-not [IO.File]::Exists($abrir)) { $abrir = $actual }
    $cerrojo.Dispose(); $cerrojo = $null
    if ($abrir -and [IO.File]::Exists($abrir)) {
      try { [void](Abrir $abrir); Anotar "Programa abierto de nuevo: $abrir" } catch { Anotar ('No se pudo abrir el programa: ' + $_.Exception.Message) }
    }
  }
  return
}

$cambiado = $false      # se tocó el destino: decide la vuelta atrás
$probada = $false       # 4.9 (revisión): se intentó abrir la versión nueva; un bloqueo pasajero al copiarla no la descarta
$proc = $null
try {
  Anotar "Actualización a la versión ${version}: esperando a que el programa se cierre"
  $limite = (Get-Date).AddSeconds($esperaCierre)
  while (@(Abiertos).Count -gt 0) {
    if ((Get-Date) -gt $limite) {
      if (@(DelPrograma).Count -eq 0) { Anotar 'Solo queda un número de proceso ocupado por otro programa: se sigue'; break }
      Anotar 'El programa no se cerró a tiempo: no se cambia nada'
      Resultado $false "el programa no se cerró en $esperaCierre segundos; se reintenta en el próximo arranque" $false
      return
    }
    Start-Sleep -Milliseconds 500
  }
  if (-not [IO.File]::Exists($nuevo)) { throw 'no se encontró el programa descargado' }
  if ($sha -and ((Hash $nuevo) -ne $sha)) { throw 'el programa descargado no coincide con el publicado (sha256)' }
  # 4.9 (revisión): se guarda el programa que estaba corriendo (el que lanzó esta actualización: funciona). Si ese ya era la
  # copia anterior (se abrió FISITAAPLocal.anterior.exe después de una vuelta atrás fallida), se conserva tal cual.
  $origen = $actual
  if (-not ($origen -and [IO.File]::Exists($origen))) { $origen = $destino }
  if ((Normal $origen) -eq (Normal $anterior)) { Anotar 'El programa que corría ya es la copia anterior: se conserva' }
  elseif ($origen -and [IO.File]::Exists($origen)) { Copiar $origen $anterior; Anotar "Versión anterior guardada en $anterior" }
  $cambiado = $true
  Copiar $nuevo $destino
  if ($sha -and ((Hash $destino) -ne $sha)) { throw 'la copia del programa nuevo quedó incompleta' }
  try { [IO.File]::Delete($nuevo) } catch { }
  try { [IO.File]::Delete($marca) } catch { }
  $probada = $true
  $proc = Abrir $destino
  Anotar "Versión $version copiada en $destino y abierta (proceso $($proc.Id))"
  $limite = (Get-Date).AddSeconds($esperaArranque)
  $cerrado = $false
  while ($true) {
    Start-Sleep -Milliseconds 500
    if ([IO.File]::Exists($marca)) {
      $m = $null
      try { $m = [IO.File]::ReadAllText($marca) | ConvertFrom-Json } catch { }
      if ($m -and ($m.estado -eq 'error')) { throw ('la versión nueva no arrancó: ' + [string]$m.error) }
      if ($m -and (($m.estado -eq 'sirviendo') -or ($m.estado -eq 'ocupado'))) {
        Anotar "La versión $version arrancó ($($m.estado))"
        Resultado $true 'instalada'
        return
      }
    }
    if ($cerrado) { throw "la versión nueva se cerró sin arrancar" }
    if ($proc.HasExited) { $cerrado = $true; Start-Sleep -Seconds 2; continue }   # una vuelta más por si la señal llegó al cerrar
    if ((Get-Date) -gt $limite) {
      # sigue abierta pero nunca respondió (colgada, o con la ventana de error de Windows esperando un clic)
      throw "la versión nueva no respondió en $esperaArranque segundos"
    }
  }
} catch {
  $detalle = [string]$_.Exception.Message
  Anotar "Error: $detalle"
  $abrir = $destino
  if ($cambiado -and [IO.File]::Exists($anterior)) {
    # cerrar lo que haya quedado abierto de la versión nueva y volver a la anterior
    if ($proc -and -not $proc.HasExited) { try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { } }
    foreach ($i in @(DelPrograma)) { try { Stop-Process -Id $i -Force -ErrorAction SilentlyContinue } catch { } }
    Start-Sleep -Seconds 1
    $vuelta = $false
    try {
      Copiar $anterior $destino
      $vuelta = ((Hash $destino) -eq (Hash $anterior))       # 4.9 (revisión): la vuelta atrás se comprueba
      if ($vuelta) { Anotar 'Se volvió a la versión anterior' } else { Anotar 'La copia de la versión anterior no quedó igual' }
    } catch { Anotar ('No se pudo volver a la versión anterior: ' + $_.Exception.Message) }
    # 4.9 (revisión): si no se pudo poner la anterior en su lugar, se abre la copia anterior misma (nunca la versión nueva rota)
    if (-not $vuelta) { $abrir = $anterior; Anotar "Se abre directamente la copia de la versión anterior: $anterior" }
  }
  Resultado $false $detalle $probada
  if (-not [IO.File]::Exists($abrir)) { $abrir = $actual }
  # 4.9 (revisión): soltar el cerrojo ANTES de abrir el programa: si vuelve a intentar esta descarga, no debe creer que otra
  # actualización sigue en curso (y cerrarse sin servir)
  if ($cerrojo) { try { $cerrojo.Dispose() } catch { }; $cerrojo = $null }
  if ($abrir -and [IO.File]::Exists($abrir)) {
    try { [void](Abrir $abrir); Anotar "Programa abierto de nuevo: $abrir" } catch { Anotar ('No se pudo abrir el programa: ' + $_.Exception.Message) }
  }
}
"""
# Lanza el guion leyéndolo como UTF-8 (no depende de la página de códigos de Windows) y como bloque de código: la política de
# ejecución de PowerShell solo se aplica a archivos .ps1, así que no hace falta pedir que se salte (-ExecutionPolicy Bypass).
ARRANQUE_PS = "& ([ScriptBlock]::Create([IO.File]::ReadAllText($env:FE_ACT_GUION, [Text.Encoding]::UTF8)))"


def _powershell() -> str:
    ruta = Path(os.environ.get("SystemRoot") or r"C:\Windows") / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(ruta) if ruta.exists() else "powershell"


def entorno_limpio(base: Optional[dict] = None) -> dict:
    """4.9: el entorno para abrir otro programa desde el exe sin pasarle lo propio de este proceso: las variables que puso
    local/local.py (FE_LOCAL_VARS_PUESTAS las lista), las del arranque de PyInstaller (_PYI_*, _MEIPASS2) y las que apuntan a
    su carpeta temporal. PYINSTALLER_RESET_ENVIRONMENT=1 hace que el exe que se abra arranque como programa nuevo y no como
    hijo de este (si no, buscaría la carpeta temporal de este proceso, que ya no existe)."""
    env = dict(os.environ if base is None else base)
    for k in (env.pop("FE_LOCAL_VARS_PUESTAS", "") or "").split(","):
        if k.strip():
            env.pop(k.strip(), None)
    mei = getattr(sys, "_MEIPASS", None)
    for k in list(env):
        if k.startswith("_PYI_") or k == "_MEIPASS2" or k.startswith("FE_ACT_"):
            env.pop(k, None)
        elif mei and k.upper() == "PATH":
            env[k] = os.pathsep.join(p for p in str(env[k]).split(os.pathsep) if mei not in p)
        elif mei and mei in str(env[k]):
            env.pop(k, None)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    return env


def destino_para(carpeta: Path, exe_actual) -> Path:
    """Qué archivo se reemplaza: el programa instalado en la carpeta (siempre con el nombre nuevo FISITAAPLocal.exe, aunque el que
    corre sea una 1.x llamada GrupoFacturaLocal.exe) o, si se abrió desde otra carpeta, ese mismo archivo."""
    actual = Path(exe_actual)
    try:
        en_carpeta = actual.resolve().parent == Path(carpeta).resolve()
    except OSError:
        en_carpeta = False
    return Path(carpeta) / EXE if en_carpeta else actual


def preparar_reemplazo(carpeta: Path, exe_actual, argv: list, esperar_pids=None, espera_cierre: int = 90,
                       espera_arranque: int = 900) -> tuple:
    """Escribe actualizar.ps1 y arma la orden y el entorno para lanzarlo. Devuelve (orden, entorno) o None si no hay nada que
    instalar. No lanza nada (aplicar lo hace); separado para poder probarlo."""
    carpeta = Path(carpeta)
    if not pendiente(carpeta):
        return None
    d = _meta_descarga(carpeta) or {}
    guion = carpeta / GUION
    guion.write_text(GUION_PS1, encoding="utf-8-sig")              # UTF-8 con BOM: también se lee bien si alguien lo abre a mano
    args = " ".join(f'"{a}"' if (" " in a or not a) else a for a in argv)
    env = entorno_limpio()
    env.update({
        "FE_ACT_GUION": str(guion),
        "FE_ACT_CARPETA": str(carpeta),
        "FE_ACT_NUEVO": str(carpeta / NUEVO),
        "FE_ACT_DESTINO": str(destino_para(carpeta, exe_actual)),
        "FE_ACT_EXE_ACTUAL": str(Path(exe_actual)),
        "FE_ACT_ANTERIOR": str(carpeta / ANTERIOR),
        "FE_ACT_VERSION": str(d.get("version") or ""),
        "FE_ACT_SHA256": str(d.get("sha256") or ""),
        "FE_ACT_ARGS": args,
        "FE_ACT_PIDS": ",".join(str(int(p)) for p in (esperar_pids if esperar_pids is not None else [os.getpid()])),
        "FE_ACT_ESPERA_CIERRE": str(int(espera_cierre)),
        "FE_ACT_ESPERA_ARRANQUE": str(int(espera_arranque)),
    })
    orden = [_powershell(), "-NoProfile", "-NonInteractive", "-Command", ARRANQUE_PS]       # sin ventana: CREATE_NO_WINDOW al lanzarlo
    return orden, env


def _lanzar_desprendido(orden: list, env: dict, cwd: Path):
    """Abre el proceso sin ventana y fuera del grupo de este, para que siga vivo cuando este programa se cierre."""
    base = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    fuera = getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0)
    try:
        return subprocess.Popen(orden, cwd=str(cwd), env=env, creationflags=base | fuera, close_fds=True,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        if not fuera:
            raise
        return subprocess.Popen(orden, cwd=str(cwd), env=env, creationflags=base, close_fds=True,       # el trabajo no permite salir
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def cerrojo_ocupado(carpeta: Path) -> bool:
    """4.9: True si un actualizar.ps1 está corriendo ahora (tiene actualizar.cerrojo abierto sin compartir). Se abre para leer
    con todo compartido: solo falla con «infracción de uso compartido» (error 32) si el guion lo tiene; un archivo de solo
    lectura u otro error no cuentan como ocupado (nunca se cierra el programa por eso)."""
    ruta = Path(carpeta) / CERROJO
    if os.name != "nt" or not ruta.exists():
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        crear = k32.CreateFileW
        crear.restype = wintypes.HANDLE
        crear.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        h = crear(str(ruta), 0x80000000, 0x7, None, 3, 0x80, None)   # GENERIC_READ, compartir todo, OPEN_EXISTING, NORMAL
        if h is None or h == wintypes.HANDLE(-1).value:
            return ctypes.get_last_error() == 32                      # ERROR_SHARING_VIOLATION: el guion lo tiene
        k32.CloseHandle(wintypes.HANDLE(h))
        return False
    except Exception as ex:  # noqa: BLE001
        log.warning("actualización local: no se pudo revisar el cerrojo: %s", ex)
        return False


def _cerrojo_vencido(carpeta: Path) -> bool:
    """4.9: el guion que tiene el cerrojo lo tomó hace más de CERROJO_VENCE (anota la hora en actualizar.cerrojo.json): está
    colgado y no se le cree (si no, cada arranque se cerraría esperándolo)."""
    d = _leer_json(Path(carpeta) / (CERROJO + ".json")) or {}
    try:
        return time.time() - float(d.get("inicio")) > CERROJO_VENCE
    except (TypeError, ValueError):
        return False


def _cerrojo_sostenido(carpeta: Path, espera: float) -> bool:
    """4.9: el cerrojo está tomado y lo sigue estando durante `espera` segundos (un guion que está terminando lo suelta antes
    de abrir el programa: no se confunde con uno en curso)."""
    if not cerrojo_ocupado(carpeta):
        return False
    fin = time.monotonic() + max(0.0, espera)
    while time.monotonic() < fin:
        time.sleep(0.25)
        if not cerrojo_ocupado(carpeta):
            return False
    return True


def _guion_en_marcha(proc, carpeta: Path, espera: float) -> bool:
    """4.9: espera a que el guion recién lanzado tome el cerrojo (señal de que de verdad corre). Si PowerShell se cierra antes
    (política que lo bloquea, antivirus) solo vale si otro guion ya está en curso; si en `espera` segundos no da señales, False."""
    fin = time.monotonic() + max(0.0, espera)
    while True:
        if cerrojo_ocupado(carpeta):
            return True
        if proc is not None and proc.poll() is not None:
            return cerrojo_ocupado(carpeta)
        if time.monotonic() >= fin:
            return False
        time.sleep(0.2)


def _error_local(carpeta: Path, texto: str):
    log.error("actualización local: %s", texto)
    _estado["error"] = "Actualización automática: " + texto
    try:
        with open(Path(carpeta) / "local_error.log", "a", encoding="utf-8") as f:
            f.write(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} Actualización automática: {texto}\n")
    except OSError:
        pass


def aplicar(carpeta: Path, exe_actual: str, argv: list, esperar_pids=None, espera_cierre: int = 90, espera_arranque: int = 900,
            espera_guion: float = 30, espera_cerrojo: float = 5) -> bool:
    """Lanza el reemplazo (actualizar.ps1), que espera a que este proceso termine. True si quien llama debe cerrar el programa
    enseguida. esperar_pids: procesos a esperar además de los que corren el exe (por omisión, este).
    4.9 (revisión): True solo si el guion de verdad corre (tomó el cerrojo) o si ya corría otro (ese abre el programa al
    terminar; no se lanza un segundo). False, y el programa sigue y sirve con su versión, si no hay nada que instalar, si esa
    descarga ya se intentó MAX_INTENTOS veces, si no se pudo anotar el intento o si el guion no llegó a correr (PowerShell
    bloqueado o cerrado por un antivirus): nunca se cierra sin que algo lo vuelva a abrir."""
    carpeta = Path(carpeta)
    if cerrojo_ocupado(carpeta) and _cerrojo_vencido(carpeta):
        _error_local(carpeta, f"un guion de actualización tiene el cerrojo desde hace más de {CERROJO_VENCE // 60} minutos (colgado); "
                              "se sigue con la versión actual")
        return False
    if _cerrojo_sostenido(carpeta, espera_cerrojo):
        log.info("actualización local: otra actualización ya está en curso; este arranque se cierra y esa abre el programa")
        return True
    try:
        listo = preparar_reemplazo(carpeta, exe_actual, argv, esperar_pids, espera_cierre, espera_arranque)
    except OSError as ex:
        listo = None
        log.error("actualización local: no se pudo preparar el reemplazo: %s", ex)
    if not listo:
        return False
    orden, env = listo
    if not _anotar_intento(carpeta, env.get("FE_ACT_SHA256")):
        _error_local(carpeta, "no se pudo anotar el intento de instalación (¿disco lleno?); se sigue con la versión actual")
        return False
    try:
        proc = _lanzar_desprendido(orden, env, carpeta)
    except OSError as ex:
        _error_local(carpeta, f"no se pudo reemplazar el programa: {ex}")
        return False
    if _guion_en_marcha(proc, carpeta, espera_guion):
        return True
    codigo = proc.poll()
    if codigo is None:
        try:
            proc.kill()                                  # no dio señales: que no quede esperando a un programa que sigue abierto
        except OSError:
            pass
    _error_local(carpeta, "el guion de reemplazo (PowerShell) no llegó a correr"
                 + (f" (terminó con código {codigo})" if codigo is not None else f" (sin señales en {int(espera_guion)} s)")
                 + "; se sigue con la versión actual. ¿PowerShell bloqueado por una política o un antivirus?")
    return False


@router.get("/api/local/estado")
def estado_instalacion(_: Usuario = Depends(solo_usuario)):
    if not MODO_LOCAL:
        raise HTTPException(404, "Solo en la instalación local")
    ult = resultado()
    error = _estado["error"]
    d = _meta_descarga(carpeta_local()) or {}
    if (not error and d.get("sha256") and mas_nueva(d.get("version"), version_local())
            and _motivo_fallida(carpeta_local(), d["sha256"]) == "intentos"):   # 4.9 (revisión): se agotaron los intentos
        error = _texto_fallida("intentos", d.get("version"), version_local())
    if not error and ult and ult.get("ok") is False:                 # 4.9: la última instalación falló y se volvió a la anterior
        error = f"La versión {ult.get('version')} no se pudo instalar: {ult.get('detalle')}"
    return {"version_local": version_local(), "descargada": pendiente(), "revisado": _estado["revisado"], "error": error, "nube": url_nube(),
            "ultima_actualizacion": ult, "anterior": (carpeta_local() / ANTERIOR).exists()}


@router.post("/api/local/revisar")
def revisar_ahora(ctx: Contexto = Depends(requiere("configurar"))):
    if not MODO_LOCAL:
        raise HTTPException(404, "Solo en la instalación local")
    r = revisar(version_local())
    return {**r, "descargada_info": pendiente(), "revisado": _estado["revisado"]}


@router.post("/api/local/reiniciar")
def reiniciar_y_actualizar(ctx: Contexto = Depends(requiere("configurar"))):
    """Instala la versión descargada: lanza el reemplazo y cierra este proceso (la respuesta sale antes)."""
    if not MODO_LOCAL:
        raise HTTPException(404, "Solo en la instalación local")
    p = pendiente()
    if not p:
        raise HTTPException(400, "No hay una versión nueva descargada")
    if not getattr(sys, "frozen", False):
        raise HTTPException(400, "El reemplazo automático solo funciona con el programa instalado (exe)")
    carpeta = carpeta_local()
    argv = [a for a in sys.argv[1:] if a != "--instalar"]
    if "--sin-abrir" not in argv:
        argv.append("--sin-abrir")                       # 4.9: el navegador ya está abierto; solo hay que recargar la página

    def _luego():
        time.sleep(1.5)
        if aplicar(carpeta, sys.executable, argv):
            os._exit(0)
    threading.Thread(target=_luego, daemon=True).start()
    return {"ok": True, "version": p["version"], "mensaje": "El programa se cierra y se vuelve a abrir con la versión nueva en unos segundos. Recargue la página después."}
