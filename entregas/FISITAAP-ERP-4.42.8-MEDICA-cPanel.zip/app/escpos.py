# -*- coding: utf-8 -*-
"""Motor de impresión térmica ESC/POS (3.11/3.12). Lo usan la instalación local (app/agente_local.py, dentro del propio sistema) y
el agente suelto para quien trabaja con la nube (agente/agente.py). No depende de nada más del sistema.

El navegador manda un documento sencillo de bloques y aquí se convierte en bytes para la impresora:
  {"ancho": 80|58, "cortar": true, "gaveta": false, "bloques": [
     {"t": "texto", "x": "Hola", "al": "C", "b": true, "tam": 2},   al = L|C|R, b = negrita, tam = 1|2 (doble alto y ancho)
     {"t": "par", "i": "Subtotal", "d": "1.000,00", "b": false},     izquierda y derecha en la misma línea
     {"t": "item", "cant": "2", "x": "Casado con pollo", "d": "9.000,00", "notas": ["Sin cebolla"]},
     {"t": "linea"}, {"t": "salto", "n": 1}, {"t": "qr", "x": "clave"}, {"t": "cortar"} ]}
Salida: impresora de red (IP:9100) o impresora de Windows por su nombre (USB, compartida) con pywin32 en modo RAW.

4.9: aquí vive también el servidor del agente de impresión en http://127.0.0.1:9800 (ServidorAgente), el mismo para el agente
suelto (agente/agente.py) y para el programa local FISITAAPLocal.exe, que lo abre junto al sistema y en modo --solo-impresion.
Así la caja de fisitaap.com abierta en esa computadora imprime directo con la misma API, el mismo CORS y el mismo permiso de red
privada, sin importar cuál de los dos programas responda.
4.9 (revisión): el 9800 ya viene encendido en cada instalación, así que solo atiende a los orígenes conocidos (origen_permitido:
el propio sistema en 127.0.0.1/localhost o en la red local, fisitaap.com y grupofactura.com con sus subdominios, facturas.itcoresync.com (labs) y los dominios de
FE_AGENTE_ORIGENES); cualquier otra página recibe 403 sin los permisos de CORS ni de red privada. Y ya no ofrece /raw (ninguna
pantalla lo usa y permitía mandar bytes a cualquier dirección y puerto): los datos sin formato solo van a una impresora USB o a
una de red local en el puerto 9100 (ver _raw_permitido; /api/agente/raw de la instalación local, con sesión, pasa por ahí).

4.24: la ruta de imprimir acepta además un trabajo de ETIQUETAS de productos para una impresora de etiquetas (TSPL o ZPL):
  {"impresora": {...}, "etiquetas": {"conexion": "usb"|"red", "direccion": "...", "lenguaje": "tspl"|"zpl", "ancho_mm": 50, "alto_mm": 30,
     "separacion_mm": 2, "densidad": 8, "dpi": 203, "etiquetas": [{"nombre": "...", "codigo": "...", "precio": "...", "copias": 1}]}}
Son solo datos: las órdenes de la impresora las arma app/etiquetas_impresora.py (con sus topes) y salen por el mismo camino de los
datos sin formato (USB de Windows o red local en el puerto 9100). No es una ruta de envío crudo: nada de lo que manda la pantalla
llega tal cual a la impresora. /estado anuncia `etiquetas` para que la pantalla sepa que este programa las entiende."""
import ipaddress
import json
import logging
import os
import socket
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

try:
    import win32print  # pywin32: impresoras de Windows (USB, compartidas)
except Exception:  # pragma: no cover - en Linux o sin pywin32
    win32print = None

ESC, GS = b"\x1b", b"\x1d"


def _cols(ancho):
    return 32 if int(ancho or 80) == 58 else 48


# 4.41: la página de códigos CP858 no tiene «₡» ni las rayas largas y salían como «?»: se cambian por «¢» y «-» (también los espacios
# especiales y las comillas tipográficas). Se aplica a los textos de cada bloque ANTES de partirlos en líneas, para que el ancho cuadre.
_TERMICA = str.maketrans({"₡": "¢", "—": "-", "–": "-", "−": "-", "‑": "-", "…": "...", "“": '"', "”": '"', "„": '"', "‘": "'", "’": "'",
                          " ": " ", " ": " ", " ": " ", "•": "·"})


def _termica(texto):
    return texto.translate(_TERMICA) if isinstance(texto, str) else texto


def _bloque_termica(bl):
    if not isinstance(bl, dict) or (bl.get("t") or "texto") not in ("texto", "par", "item"):
        return bl                                   # el QR y lo demás, tal cual
    x = dict(bl)
    for k in ("x", "i", "d", "cant"):
        if k in x:
            x[k] = _termica(x[k])
    if isinstance(x.get("notas"), list):
        x["notas"] = [_termica(n) for n in x["notas"]]
    return x


def _enc(texto, crudo=False):
    t = str(texto if texto is not None else "")
    t = t if crudo else _termica(t)
    try:
        return t.encode("cp858", errors="replace")
    except Exception:
        return t.encode("ascii", errors="replace")


def _envolver(texto, cols):
    """Parte un texto en líneas de `cols` caracteres cortando por palabras."""
    out, linea = [], ""
    for palabra in str(texto).split(" "):
        while len(palabra) > cols:
            if linea:
                out.append(linea); linea = ""
            out.append(palabra[:cols]); palabra = palabra[cols:]
        if not linea:
            linea = palabra
        elif len(linea) + 1 + len(palabra) <= cols:
            linea += " " + palabra
        else:
            out.append(linea); linea = palabra
    if linea or not out:
        out.append(linea)
    return out


def pulso_gaveta():
    return ESC + b"p" + b"\x00" + bytes([25, 250])   # cajón 1, 50 ms / 500 ms


def escpos(doc):
    """Documento (dict) → bytes ESC/POS."""
    cols = _cols(doc.get("ancho"))
    b = bytearray()
    b += ESC + b"@"                       # inicializar
    b += ESC + b"t" + bytes([19])         # página de códigos CP858 (acentos y símbolos de Latinoamérica)
    for bl in [_bloque_termica(x) for x in (doc.get("bloques") or [])]:
        t = bl.get("t") or "texto"
        if t == "texto":
            tam = 2 if int(bl.get("tam") or 1) >= 2 else 1
            c = cols // tam
            b += ESC + b"a" + bytes([{"L": 0, "C": 1, "R": 2}.get(str(bl.get("al") or "L").upper(), 0)])
            b += ESC + b"E" + (b"\x01" if bl.get("b") else b"\x00")
            b += GS + b"!" + (b"\x11" if tam == 2 else b"\x00")
            for ln in _envolver(bl.get("x") or "", c):
                b += _enc(ln) + b"\n"
            b += GS + b"!" + b"\x00" + ESC + b"E" + b"\x00" + ESC + b"a" + b"\x00"
        elif t == "par":
            izq, der = str(bl.get("i") or ""), str(bl.get("d") or "")
            b += ESC + b"E" + (b"\x01" if bl.get("b") else b"\x00")
            if len(izq) + 1 + len(der) > cols:
                for ln in _envolver(izq, cols):
                    b += _enc(ln) + b"\n"
                b += _enc(der.rjust(cols)) + b"\n"
            else:
                b += _enc(izq + der.rjust(cols - len(izq))) + b"\n"
            b += ESC + b"E" + b"\x00"
        elif t == "item":
            cant, x, der = str(bl.get("cant") or ""), str(bl.get("x") or ""), str(bl.get("d") or "")
            pref = (cant + " x ") if cant else ""
            lineas = _envolver(x, max(8, cols - len(pref) - (len(der) + 1 if der else 0)))
            primera = pref + lineas[0]
            b += _enc(primera + (der.rjust(cols - len(primera)) if der else "")) + b"\n"
            for ln in lineas[1:]:
                b += _enc(" " * len(pref) + ln) + b"\n"
            for nota in bl.get("notas") or []:
                b += ESC + b"E" + b"\x01"
                for ln in _envolver("  > " + str(nota), cols):
                    b += _enc(ln) + b"\n"
                b += ESC + b"E" + b"\x00"
        elif t == "linea":
            b += _enc("-" * cols) + b"\n"
        elif t == "salto":
            b += b"\n" * int(bl.get("n") or 1)
        elif t == "qr":
            datos = _enc(bl.get("x") or "", crudo=True)   # 4.41: el QR, tal cual (sin los cambios para la térmica)
            if datos:
                b += ESC + b"a" + b"\x01"
                b += GS + b"(k" + bytes([4, 0, 49, 65, 50, 0])                      # modelo 2
                b += GS + b"(k" + bytes([3, 0, 49, 67, int(bl.get("tam") or 5)])     # tamaño del módulo
                b += GS + b"(k" + bytes([3, 0, 49, 69, 48])                          # corrección L
                n = len(datos) + 3
                b += GS + b"(k" + bytes([n % 256, n // 256, 49, 80, 48]) + datos     # guardar
                b += GS + b"(k" + bytes([3, 0, 49, 81, 48])                          # imprimir
                b += ESC + b"a" + b"\x00"
        elif t == "cortar":
            b += b"\n\n\n" + GS + b"V" + b"\x42" + b"\x00"
    if doc.get("cortar", True) and not any((bl.get("t") == "cortar") for bl in doc.get("bloques") or []):
        b += b"\n\n\n" + GS + b"V" + b"\x42" + b"\x00"
    if doc.get("gaveta"):
        b += pulso_gaveta()
    return bytes(b)


def impresoras_windows():
    if not win32print:
        return []
    try:
        return [p[2] for p in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
    except Exception:
        return []


class ErrorImpresora(ValueError):
    """4.25 (tanda 8): la impresora no respondió o Windows no pudo imprimir. El texto es llano (para la pantalla) y nombra la impresora;
    el detalle técnico («timed out», «(1801, 'OpenPrinter', …)», «[WinError 10061]») va aparte, en `tecnico`, solo para el registro y
    para el último error del estado. `texto(nombre)` lo repite con el nombre que la impresora tiene en el sistema (si se conoce)."""
    PLANTILLAS = {
        "red": "La impresora «{x}» no responde: revise que esté encendida y conectada a la red",
        "no_existe": "Windows no tiene una impresora llamada «{x}». Elíjala de nuevo en Punto de venta › Configuración › Impresoras",
        "windows": "Windows no pudo imprimir en «{x}»: revise que esté encendida, con papel y sin trabajos detenidos",
    }

    def __init__(self, tipo: str, impresora: str, tecnico: str = ""):
        self.tipo, self.impresora, self.tecnico = tipo, str(impresora or ""), str(tecnico or "")
        super().__init__(self.texto())

    def texto(self, nombre=None) -> str:
        return self.PLANTILLAS[self.tipo].format(x=str(nombre or self.impresora or "la impresora"))


def _tecnico(ex) -> str:
    return f"{type(ex).__name__}: {ex}"[:300]


def mensaje_llano(ex, impresora=None) -> tuple:
    """4.25 (tanda 8): (texto para la pantalla, detalle técnico para el registro y el último error del estado) de un trabajo que falló.
    La impresora que no responde o que Windows no tiene: el texto llano con el nombre que tiene en el sistema. Un trabajo mal armado
    (ValueError) o el aviso de que falta pywin32 (RuntimeError) ya son texto llano: van tal cual. Cualquier otra cosa es técnica:
    a la pantalla, un texto general."""
    imp = impresora if isinstance(impresora, dict) else {}
    nombre = str(imp.get("nombre") or "").strip()[:60] or None
    if isinstance(ex, ErrorImpresora):
        x = nombre or ex.impresora or "la impresora"
        return ex.texto(nombre), f"«{x}»: {ex.tecnico or ex.tipo}"[:400]
    if isinstance(ex, (ValueError, RuntimeError)):
        return str(ex), str(ex)
    return ("No se pudo imprimir en «" + (nombre or str(imp.get("direccion") or "").strip()[:60] or "la impresora")
            + "»: revise que esté encendida y conectada"), _tecnico(ex)


def enviar(impresora, datos: bytes):
    """impresora = {"conexion": "usb"|"red", "direccion": "EPSON TM-T20" | "192.168.1.50[:9100]"}
    4.25 (tanda 8): una impresora que no responde o que Windows no tiene lanza ErrorImpresora (texto llano; el técnico en .tecnico)."""
    conexion = str(impresora.get("conexion") or "").lower()
    direccion = str(impresora.get("direccion") or "").strip()
    nombre_imp = str(impresora.get("nombre") or "").strip() or direccion
    if conexion == "red":
        if not direccion:
            raise ValueError("La impresora de red no tiene dirección IP")
        host, _, puerto = direccion.partition(":")
        try:
            with socket.create_connection((host, int(puerto or 9100)), timeout=6) as s:
                s.sendall(datos)
        except OSError as ex:                       # sin respuesta, conexión rechazada, red inalcanzable (incluye «timed out»)
            raise ErrorImpresora("red", nombre_imp, _tecnico(ex)) from None
        return
    if conexion == "usb":
        if not win32print:
            raise RuntimeError("Este equipo no puede usar impresoras de Windows (falta pywin32)")
        nombres = impresoras_windows()
        nombre = direccion or (win32print.GetDefaultPrinter() if nombres else "")
        if nombre not in nombres:
            cand = [n for n in nombres if direccion and direccion.lower() in n.lower()]
            if not cand:
                raise ErrorImpresora("no_existe", nombre_imp or nombre, f"no está entre las de Windows: {', '.join(nombres) or 'ninguna'}"[:300])
            nombre = cand[0]
        try:
            h = win32print.OpenPrinter(nombre)
        except Exception as ex:  # noqa: BLE001  pywintypes.error: 1801 = el nombre no existe; lo demás, Windows no pudo
            codigo = getattr(ex, "winerror", None) or (ex.args[0] if getattr(ex, "args", None) else None)
            raise ErrorImpresora("no_existe" if codigo == 1801 else "windows", nombre_imp or nombre, _tecnico(ex)) from None
        try:
            win32print.StartDocPrinter(h, 1, ("FISITAAP ERP", None, "RAW"))
            win32print.StartPagePrinter(h)
            win32print.WritePrinter(h, datos)
            win32print.EndPagePrinter(h)
            win32print.EndDocPrinter(h)
        except Exception as ex:  # noqa: BLE001  sin papel, pausada, sin conexión, trabajos detenidos
            raise ErrorImpresora("windows", nombre_imp or nombre, _tecnico(ex)) from None
        finally:
            win32print.ClosePrinter(h)
        return
    raise ValueError("La impresora debe ser USB (nombre en Windows) o de red (IP); las del navegador no pasan por aquí")


def doc_prueba(impresora):
    return {"ancho": impresora.get("ancho") or 80, "bloques": [
        {"t": "texto", "x": "FISITAAP", "al": "C", "b": True, "tam": 2},          # 4.9: marca FISITAAP (antes GRUPO FACTURA)
        {"t": "texto", "x": "Prueba de impresión", "al": "C"},
        {"t": "texto", "x": "Impresora: " + str(impresora.get("nombre") or impresora.get("direccion") or ""), "al": "C"},
        {"t": "texto", "x": time.strftime("%d/%m/%Y %H:%M"), "al": "C"},
        {"t": "linea"},
        {"t": "item", "cant": "2", "x": "Casado con pollo", "d": "9.000,00", "notas": ["Sin cebolla"]},
        {"t": "item", "cant": "1", "x": "Café con leche", "d": "1.500,00"},
        {"t": "linea"},
        {"t": "par", "i": "TOTAL CRC", "d": "10.500,00", "b": True},
        {"t": "texto", "x": "Acentos: áéíóú ñ Ñ ¿? ¡!", "al": "C"},
        {"t": "qr", "x": os.environ.get("FE_URL_PUBLICA", "").strip() or "https://fisitaap.com"},
        {"t": "texto", "x": "Si ve esto, la impresión funciona.", "al": "C"},
    ]}


class DestinoNoPermitido(ValueError):
    """4.25 (9c, P1): el destino de unos datos sin formato no es una impresora USB ni una de la red local en el 9100. Es un ValueError
    con el texto de siempre; quien arma la respuesta de etiquetas (agente_local.imprimir) lo traduce a un texto llano."""


def _raw_permitido(impresora: dict):
    """4.9: los datos sin formato (raw) solo van a una impresora: USB (por su nombre en Windows) o de red local (una IP privada
    del negocio, nunca esta misma computadora) en el puerto 9100 de las térmicas. Así /raw no sirve para mandar bytes a
    cualquier servidor o puerto (ni al propio sistema en 127.0.0.1:8020). Lanza ValueError (DestinoNoPermitido) si no se permite."""
    conexion = str(impresora.get("conexion") or "").lower()
    if conexion == "usb":
        return
    if conexion == "red":
        host, _, puerto = str(impresora.get("direccion") or "").strip().partition(":")
        try:
            ip = ipaddress.ip_address(host.strip())
        except ValueError:
            ip = None
        if ip is not None and ip.is_private and not (ip.is_loopback or ip.is_link_local or ip.is_unspecified) and (puerto.strip() or "9100") == "9100":
            return
    raise DestinoNoPermitido("Los datos sin formato solo se envían a una impresora USB o a una impresora de la red local (IP privada, puerto 9100)")


VERSION_ETIQUETAS = 1                 # 4.24: versión del trabajo de etiquetas que entiende este programa (sale en /estado)


def imprimir_etiquetas(trabajo: dict, impresora: dict | None = None):
    """4.24: trabajo de etiquetas de productos (datos) → órdenes TSPL o ZPL → impresora de etiquetas. La conexión y la dirección
    vienen en el trabajo (o, si faltan, en `impresora`); el destino pasa por _raw_permitido: USB de Windows o red local, puerto 9100."""
    from . import etiquetas_impresora
    if not isinstance(trabajo, dict):
        raise ValueError("El trabajo de etiquetas no es válido")
    impresora = impresora if isinstance(impresora, dict) else {}
    trabajo = {**trabajo, "conexion": trabajo.get("conexion") or impresora.get("conexion"), "direccion": trabajo.get("direccion") or impresora.get("direccion")}
    destino, datos = etiquetas_impresora.trabajo_etiquetas(trabajo)
    _raw_permitido(destino)
    enviar(destino, datos)


def ejecutar(ruta: str, impresora: dict, cuerpo: dict):
    """Una petición del navegador: /imprimir, /prueba, /gaveta o /raw. Lanza ValueError/RuntimeError si falla."""
    if ruta == "imprimir" and cuerpo.get("etiquetas") is not None:      # 4.24: etiquetas de productos (TSPL o ZPL)
        imprimir_etiquetas(cuerpo.get("etiquetas"), impresora)
    elif ruta == "imprimir":
        doc = cuerpo.get("documento") or {}
        doc.setdefault("ancho", impresora.get("ancho") or 80)
        enviar(impresora, escpos(doc))
    elif ruta == "prueba":
        enviar(impresora, escpos(doc_prueba(impresora)))
    elif ruta == "gaveta":
        enviar(impresora, ESC + b"@" + pulso_gaveta())
    elif ruta == "raw":
        import base64
        _raw_permitido(impresora)        # 4.9: nunca un relé de bytes a cualquier dirección y puerto
        enviar(impresora, base64.b64decode(cuerpo.get("datos") or ""))
    else:
        raise ValueError("Ruta desconocida")


# ================================================================================ agente de impresión en 127.0.0.1:9800 (4.9)
_log = logging.getLogger(__name__)
PUERTO_AGENTE = 9800
RUTAS_AGENTE = ("imprimir", "prueba", "gaveta")                     # 4.9: /raw ya no se ofrece en el 9800 (ninguna pantalla lo usa)
DOMINIOS_AGENTE = ("fisitaap.com", "grupofactura.com", "facturas.itcoresync.com")   # 4.9: las nubes en uso (y sus subdominios), solo por https; de itcoresync.com, solo el host de labs
MAX_CUERPO = 8 * 1024 * 1024          # 4.9: un trabajo de impresión nunca pasa de unos pocos KB; esto evita leer un cuerpo enorme


def origen_permitido(origen) -> bool:
    """4.9: ¿puede una página con este Origin usar el agente? Sí: sin Origin (no es un navegador: un programa o una prueba), el
    propio sistema o el propio agente (http://127.0.0.1, localhost o una IP de la red local, como cuando se entra con --red), y la
    nube: https://fisitaap.com, https://grupofactura.com y sus subdominios, https://facturas.itcoresync.com (labs), más los dominios que se agreguen en
    FE_AGENTE_ORIGENES (separados por comas, p. ej. una instalación de pruebas). Cualquier otra página (o «null») no."""
    if origen is None or origen == "":
        return True
    try:
        partes = urlsplit(str(origen).strip())
        host = (partes.hostname or "").lower().rstrip(".")
        esquema = (partes.scheme or "").lower()
    except ValueError:
        return False
    if esquema not in ("http", "https") or not host:
        return False
    if host == "localhost" or host.endswith(".localhost"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None:
        return ip.is_loopback or (ip.is_private and not ip.is_unspecified)
    if esquema != "https":
        return False
    extra = [d.strip().lower().lstrip(".") for d in os.environ.get("FE_AGENTE_ORIGENES", "").split(",") if d.strip()]
    return any(host == d or host.endswith("." + d) for d in (*DOMINIOS_AGENTE, *extra))


PAGINA_AGENTE = """<!doctype html><html lang="es"><head><meta charset="utf-8"><title>%TITULO%</title>
<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;max-width:720px;margin:30px auto;padding:0 16px;color:#1d2433}h1{color:#0f766e;font-size:22px}
.ok{color:#15803d}.card{border:1px solid #cfd6e0;border-radius:10px;padding:14px 16px;margin:12px 0}button{background:#0f766e;color:#fff;border:0;border-radius:7px;padding:8px 14px;cursor:pointer}
input,select{padding:7px;border:1px solid #cfd6e0;border-radius:6px}code{background:#f1f5f9;padding:2px 5px;border-radius:4px}small{color:#6b7280}</style></head><body>
<h1>%TITULO%</h1>
<p class="ok">En marcha, versión %VERSION% · puerto %PUERTO%. Déjelo abierto: el sistema en la nube lo usa para imprimir comandas y tiquetes en las impresoras de esta computadora y de la red.</p>
<div class="card"><b>Impresoras de Windows detectadas</b><p>%IMPRESORAS%</p><small>Para una impresora USB, en el sistema (Punto de venta › Configuración › Impresoras) use el nombre tal como aparece aquí.</small></div>
<div class="card"><b>Prueba de impresión</b><p><select id="con"><option value="usb">USB (nombre en Windows)</option><option value="red">Red (IP)</option></select> <input id="dir" placeholder="EPSON TM-T20 o 192.168.1.50" size="30"> <select id="an"><option value="80">80 mm</option><option value="58">58 mm</option></select> <button onclick="probar()">Imprimir prueba</button> <button onclick="gaveta()">Abrir gaveta</button></p><p id="res"></p></div>
<div class="card"><b>Registro</b><p><code>%LOG%</code></p><p>Trabajos impresos: %TRABAJOS% · último: %ULTIMO% %ERROR%</p></div>
<script>async function env(ruta){const imp={conexion:document.getElementById('con').value,direccion:document.getElementById('dir').value,ancho:+document.getElementById('an').value};const r=await fetch(ruta,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({impresora:imp})});const j=await r.json();document.getElementById('res').textContent=j.ok?'Listo':'Error: '+j.error;}
function probar(){env('/prueba')}function gaveta(){env('/gaveta')}</script></body></html>"""


def _html(texto) -> str:
    return str(texto).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class ManejadorAgente(BaseHTTPRequestHandler):
    """Rutas del agente (iguales desde la 3.11): GET /estado, GET / (página de estado y prueba), POST /imprimir, /prueba y
    /gaveta, y OPTIONS para la verificación previa del navegador. El CORS refleja el origen y responde
    Access-Control-Allow-Private-Network: Chrome lo exige para que una página pública hable con 127.0.0.1.
    4.9: solo para los orígenes de origen_permitido (los demás reciben 403, sin CORS ni permiso de red privada) y sin /raw."""

    def version_string(self):
        return self.server.firma

    def log_message(self, fmt, *args):   # sin ruido en consola
        pass

    def _cors(self):
        origen = self.headers.get("Origin")
        self.send_header("Vary", "Origin")
        if not origen_permitido(origen):                 # 4.9: a un origen ajeno no se le da ningún permiso
            return
        self.send_header("Access-Control-Allow-Origin", origen or "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _origen_rechazado(self) -> bool:
        """4.9: responde 403 si la petición viene de una página que no es el sistema ni la nube (lo anota una vez por origen)."""
        origen = self.headers.get("Origin")
        if origen_permitido(origen):
            return False
        rechazados = self.server.estado.setdefault("origenes_rechazados", set())
        if origen not in rechazados and len(rechazados) < 50:
            rechazados.add(origen)
            self.server.anotar(f"RECHAZADO origen no permitido {origen!r} ({self.command} {self.path.split('?')[0]})")
        self._descartar_cuerpo()
        self._json({"ok": False, "error": "Origen no permitido: este agente solo atiende al sistema FISITAAP"}, 403)
        return True

    def _descartar_cuerpo(self):
        """4.9: lee y descarta el cuerpo de una petición que no se atiende: cerrar la conexión con datos sin leer hace que
        Windows la corte (RST) y el navegador no reciba la respuesta."""
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if 0 < n <= MAX_CUERPO:
                self.rfile.read(n)
        except (ValueError, OSError):
            pass

    def _json(self, obj, codigo=200):
        datos = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo); self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(datos)))
        self.end_headers(); self.wfile.write(datos)

    def do_OPTIONS(self):
        if self._origen_rechazado():
            return
        self.send_response(204); self._cors(); self.end_headers()

    def do_GET(self):
        if self._origen_rechazado():
            return
        srv, ruta = self.server, self.path.split("?")[0]
        if ruta == "/estado":
            return self._json(srv.info())
        if ruta == "/equipo":                           # 4.31: la impresión «En esta computadora» del programa (solo lectura)
            return self._equipo(srv)
        if ruta == "/":
            imps = impresoras_windows()
            e = srv.estado
            html = (PAGINA_AGENTE.replace("%TITULO%", _html(srv.titulo)).replace("%VERSION%", _html(srv.version)).replace("%PUERTO%", str(srv.puerto))
                    .replace("%LOG%", _html(srv.registro or "—")).replace("%TRABAJOS%", str(e["trabajos"])).replace("%ULTIMO%", _html(e["ultimo"] or "—"))
                    .replace("%ERROR%", ("· último error: " + _html(e["ultimo_error"])) if e["ultimo_error"] else "")
                    .replace("%IMPRESORAS%", _html(", ".join(imps)) if imps else "ninguna (o este agente no tiene acceso a las impresoras de Windows)"))
            datos = html.encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(datos))); self.end_headers(); self.wfile.write(datos)
            return
        self._json({"ok": False, "error": "Ruta desconocida"}, 404)

    def _equipo(self, srv):
        """4.31: GET /equipo?cedula=<cédula de la empresa> → {ok: true, equipo: {propias, ajustes, tiquetes, etiquetas}} de esa empresa
        del programa, o {ok: false} (404) si este agente no la tiene (el agente suelto no tiene fuente) o no la encuentra."""
        fuente = getattr(srv, "fuente_equipo", None)
        if fuente is None:
            return self._json({"ok": False}, 404)
        from urllib.parse import parse_qs, urlsplit
        cedula = (parse_qs(urlsplit(self.path).query).get("cedula") or [""])[0]
        try:
            datos = fuente(cedula)
        except Exception as e:  # noqa: BLE001
            srv.anotar("ERROR equipo " + repr(e))
            datos = None
        if not isinstance(datos, dict):
            return self._json({"ok": False}, 404)
        return self._json({"ok": True, "equipo": datos})

    def do_POST(self):
        if self._origen_rechazado():
            return
        srv, ruta = self.server, self.path.split("?")[0].strip("/")
        if ruta not in RUTAS_AGENTE:                     # 4.9: incluye /raw, que ya no se ofrece aquí
            self._descartar_cuerpo()
            return self._json({"ok": False, "error": "Ruta desconocida"}, 404)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_CUERPO:
                return self._json({"ok": False, "error": "El trabajo de impresión es demasiado grande"}, 413)
            cuerpo = json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}
            if not isinstance(cuerpo, dict):
                raise ValueError("se esperaba un objeto JSON")
        except Exception as e:
            return self._json({"ok": False, "error": "Cuerpo inválido: " + str(e)}, 400)
        imp = cuerpo.get("impresora") or {}
        try:
            ejecutar(ruta, imp, cuerpo)
            e = srv.estado
            e["trabajos"] += 1; e["ultimo"] = time.strftime("%H:%M:%S") + " " + ruta + " → " + str(imp.get("nombre") or imp.get("direccion") or ""); e["ultimo_error"] = ""
            srv.anotar("OK " + ruta + " " + json.dumps(imp, ensure_ascii=False))
            return self._json({"ok": True})
        except Exception as e:
            texto, tecnico = mensaje_llano(e, imp)          # 4.25 (tanda 8): a la pantalla, el texto llano; el técnico, al registro y al estado
            srv.estado["ultimo_error"] = tecnico
            srv.anotar("ERROR " + ruta + " " + tecnico + "\n" + traceback.format_exc())
            return self._json({"ok": False, "error": texto}, 404 if "desconocida" in texto else 500)


class ServidorAgente(ThreadingHTTPServer):
    """Servidor del agente. Solo escucha en la propia computadora. Si el puerto ya está en uso lanza OSError (no se comparte:
    en Windows SO_REUSEADDR dejaría a dos programas escuchando el mismo puerto sin error y los trabajos irían a cualquiera)."""
    allow_reuse_address = False
    daemon_threads = True

    def __init__(self, puerto=PUERTO_AGENTE, *, nombre="FISITAAP ERP", version="", titulo=None, registro=None, extra=None,
                 estado=None, firma=None, host="127.0.0.1", fuente_equipo=None):
        self.nombre, self.version = nombre, str(version or "")
        self.fuente_equipo = fuente_equipo           # 4.31: función(cédula) → ajustes «En esta computadora» del programa (GET /equipo)
        self.titulo = titulo or ("Agente de impresión · " + nombre)
        self.registro = registro                     # archivo de registro (agente.log) o None
        self.extra = dict(extra or {})               # datos que se agregan a /estado (por ejemplo, el programa y el modo)
        self.estado = estado if estado is not None else {}
        for k, v in (("trabajos", 0), ("ultimo", ""), ("ultimo_error", ""), ("inicio", time.time())):
            self.estado.setdefault(k, v)
        self.firma = firma or ("FISITAAPAgente/" + self.version)
        super().__init__((host, int(puerto)), ManejadorAgente)

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):    # Windows: nadie más puede usar el puerto mientras lo tengamos
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    @property
    def puerto(self) -> int:
        return int(self.server_address[1])

    def info(self) -> dict:
        e = self.estado
        return {"agente": self.nombre, "version": self.version, "puerto": self.puerto, "impresoras_windows": impresoras_windows(),
                "trabajos": e["trabajos"], "ultimo": e["ultimo"], "ultimo_error": e["ultimo_error"], "windows": bool(win32print),
                "etiquetas": VERSION_ETIQUETAS, **self.extra,     # 4.24: este programa sabe imprimir etiquetas (TSPL y ZPL)
                **({"equipo": 1} if self.fuente_equipo is not None else {})}   # 4.31: ofrece GET /equipo

    def anotar(self, msg):
        if not self.registro:
            _log.info("agente %s: %s", self.puerto, msg)
            return
        try:
            os.makedirs(os.path.dirname(self.registro) or ".", exist_ok=True)
            with open(self.registro, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + str(msg) + "\n")
        except Exception:
            pass


def puerto_ocupado(puerto, host="127.0.0.1") -> bool:
    """True si ya hay un programa escuchando en ese puerto de esta computadora."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, int(puerto))) == 0


def iniciar_agente_en_hilo(puerto=PUERTO_AGENTE, **kw):
    """Abre el agente en un hilo aparte y devuelve el servidor. Si el puerto está ocupado (el agente suelto u otro programa ya
    escucha ahí) no falla: lo anota y devuelve None; la impresión desde la nube sigue por el que ya responde."""
    try:
        if puerto and puerto_ocupado(puerto):
            raise OSError(f"el puerto {puerto} ya está en uso")
        srv = ServidorAgente(puerto, **kw)
    except OSError as ex:
        _log.warning("Agente de impresión no abierto en 127.0.0.1:%s (%s); si es el agente suelto, la impresión sigue por él", puerto, ex)
        registro = kw.get("registro")
        if registro:
            try:
                os.makedirs(os.path.dirname(registro) or ".", exist_ok=True)
                with open(registro, "a", encoding="utf-8") as f:
                    f.write(time.strftime("%Y-%m-%d %H:%M:%S") + f" No se abrió el agente en el puerto {puerto}: {ex}\n")
            except Exception:
                pass
        return None
    threading.Thread(target=srv.serve_forever, name=f"agente-impresion-{srv.puerto}", daemon=True).start()
    srv.anotar(f"Agente {srv.version} escuchando en 127.0.0.1:{srv.puerto}")
    return srv
