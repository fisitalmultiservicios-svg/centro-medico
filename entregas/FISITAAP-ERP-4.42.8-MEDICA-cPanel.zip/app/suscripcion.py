"""Pago automático del plan con tarjeta por Tilopay (3.36).

Cómo funciona
- Cada empresa tiene su propio plan recurrente en Tilopay (createPlanRepeat) con su monto exacto (plan + extras + IVA), porque
  los extras y las habitaciones hacen que el precio cambie de una empresa a otra. Así cada aviso de Tilopay (que trae id_plan)
  identifica a la empresa sin depender del correo.
- La empresa entra a Configuración › Suscripción y planes, toca «Activar pago automático» y se le manda a la página de registro
  de Tilopay (recurrentUrl): ahí registra la tarjeta. El sistema nunca ve ni guarda datos de tarjeta.
- Los avisos (webhooks) de Tilopay NO traen firma verificable (el orderHash no es público). Por eso un aviso solo dispara una
  sincronización: el sistema le pregunta a Tilopay por los suscriptores y pagos de ese plan y registra lo que Tilopay confirma.
  La misma sincronización corre al volver de Tilopay (thanks_url) y una vez al día en la cola, así que nada depende de que el
  aviso llegue.
- Cada pago aprobado se registra como PagoPlan (referencia «tilopay:<id>», idempotente) y extiende el vencimiento con
  planes.registrar_pago (1 mes, o 12 si el plan es anual).

Configuración (variables de entorno del servidor, nunca en archivos del proyecto):
  FE_TILOPAY_KEY, FE_TILOPAY_USER, FE_TILOPAY_PASSWORD  (Tilopay › Connecting to platforms › Api General)
"""
import hashlib
import hmac
import json
import logging
import os
import secrets
import threading
import time
import types
from datetime import datetime, timezone
from typing import Optional

import httpx
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlmodel import Field, Session, SQLModel, select

from . import planes, secretos
from .auth import Contexto, contexto, requiere, superadmin, Usuario, PagoPlan, SECRET
from .config import DATA_DIR, URL_PUBLICA, ahora_cr
from .db import Empresa, central, engine, get_session

log = logging.getLogger(__name__)
router = APIRouter(tags=["suscripcion"])

API = "https://app.tilopay.com/api/v1/"
IVA = 0.13
FRECUENCIA = {"mes": 3, "anio": 4}          # 3 = mensual, 4 = anual (createPlanRepeat.frecuency)
EVENTOS = ("subscribe", "payment", "rejected", "unsubscribe", "reactive")


class SuscripcionPago(SQLModel, table=True):
    """Pago automático del plan de una empresa con Tilopay."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    proveedor: str = "tilopay"
    plan_id: Optional[int] = Field(default=None, index=True)   # plan recurrente en Tilopay (uno por empresa)
    monto: float = 0                         # monto con IVA del plan en Tilopay
    moneda: str = "CRC"
    periodo: str = "mes"                     # mes | anio
    correo: Optional[str] = None             # correo con que se registró la tarjeta
    estado: str = "pendiente"                # pendiente | activa | rechazada | pausada | cancelada
    suscriptor_id: Optional[int] = None
    proximo_cobro: Optional[str] = None
    ultimo_evento: Optional[str] = None
    ultimo_error: Optional[str] = None
    sincronizado: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


central(SuscripcionPago)


# ----------------------------------------------------------------------------- configuración y cliente de Tilopay
# La configura el administrador del sistema en la consola (Pagos en línea); se guarda cifrada con la clave maestra en
# data/pasarela.json. Las empresas nunca la ven. Las variables FE_TILOPAY_* quedan como respaldo si no hay archivo.
ARCHIVO = DATA_DIR / "pasarela.json"


def _leer_config() -> dict:
    try:
        return json.loads(ARCHIVO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _descifrar(v: Optional[str]) -> str:
    if not v:
        return ""
    try:
        return secretos._maestra.decrypt(v.encode()).decode()
    except Exception:  # noqa: BLE001
        return ""


def credenciales() -> Optional[dict]:
    cfg = _leer_config()
    if cfg:
        if not cfg.get("activo"):
            return None
        k, u, p = (_descifrar(cfg.get(x)) for x in ("key", "user", "password"))
    else:
        k, u, p = (os.environ.get(x, "").strip() for x in ("FE_TILOPAY_KEY", "FE_TILOPAY_USER", "FE_TILOPAY_PASSWORD"))
    return {"key": k, "user": u, "password": p} if k and u and p else None


def _resumen_config() -> dict:
    cfg = _leer_config()
    k = _descifrar(cfg.get("key")) if cfg else os.environ.get("FE_TILOPAY_KEY", "").strip()
    return {"proveedor": "tilopay", "origen": "consola" if cfg else ("variables del servidor" if credenciales() else None),
            "activo": bool(cfg.get("activo")) if cfg else bool(credenciales()), "llave": ("…" + k[-4:]) if k else "",
            "usuario_guardado": bool(_descifrar(cfg.get("user"))) if cfg else bool(os.environ.get("FE_TILOPAY_USER")),
            "clave_guardada": bool(_descifrar(cfg.get("password"))) if cfg else bool(os.environ.get("FE_TILOPAY_PASSWORD")),
            "modo_prueba": bool(cfg.get("modo_prueba")) if cfg else False, "actualizado": cfg.get("actualizado"), "ultima_prueba": cfg.get("ultima_prueba")}


def disponible() -> bool:
    return credenciales() is not None


_token: dict = {"valor": None, "vence": 0.0}


def _login(cred: dict) -> str:
    if _token["valor"] and time.time() < _token["vence"]:
        return _token["valor"]
    r = httpx.post(API + "login", json={"apiuser": cred["user"], "password": cred["password"]}, timeout=30)
    if r.status_code != 200:
        raise HTTPException(502, "Tilopay no aceptó las credenciales de la integración (revise FE_TILOPAY_USER y FE_TILOPAY_PASSWORD)")
    j = r.json()
    _token.update(valor=j["access_token"], vence=time.time() + min(int(j.get("expires_in") or 3600), 86400) - 600)
    return _token["valor"]


def llamar(op: str, cuerpo: dict) -> dict:
    """POST a la API de Tilopay con la llave de la integración. Devuelve el JSON (o {'type': '<código>', 'message': ...})."""
    cred = credenciales()
    if not cred:
        raise HTTPException(503, "El pago con tarjeta todavía no está configurado en el servidor")
    for intento in (1, 2):
        tok = _login(cred)
        try:
            r = httpx.post(API + op, json={"key": cred["key"], **cuerpo}, headers={"Authorization": "Bearer " + tok, "Accept": "application/json"}, timeout=40)
        except httpx.HTTPError as ex:
            raise HTTPException(504, f"Tilopay no respondió ({type(ex).__name__}); intente de nuevo en unos minutos")
        if r.status_code == 401 and intento == 1:            # token vencido: uno nuevo y se reintenta una vez
            _token["valor"] = None
            continue
        try:
            return r.json()
        except ValueError:
            return {"type": str(r.status_code), "message": r.text[:200]}
    return {"type": "401", "message": "Sin autorización"}


def _ok(j: dict) -> bool:
    return str(j.get("type")) == "200"


# ----------------------------------------------------------------------------- monto del plan
def monto_plan(e) -> dict:
    """Monto del plan de la empresa para cobrar en línea: {sin_iva, iva, total, moneda, periodo, nombre} o {'motivo'} si no se
    puede (sin plan, plan por cotización, extras en dólares)."""
    p = planes.plan_de(e)
    acordado = float(getattr(e, "precio_acordado", 0) or 0)
    if acordado > 0:                                    # 3.95: precio acordado (fijo) con la empresa: reemplaza el cálculo de la lista
        extras = planes.extras_de(e)
        nombre = (getattr(e, "precio_acordado_nota", "") or "").strip() or ((p["nombre"] if p else "Plan") + (
            (" + " + ", ".join(planes.EXTRAS[x]["nombre"] for x in extras if x in planes.EXTRAS)) if extras else ""))
        iva = round(acordado * IVA, 2)
        return {"sin_iva": round(acordado, 2), "iva": iva, "total": round(acordado + iva, 2), "moneda": "CRC", "periodo": (p or {}).get("periodo") or "mes",
                "nombre": nombre, "acordado": True}
    if not p:
        return {"motivo": "La empresa todavía no tiene un plan asignado"}
    if p.get("cotizacion"):
        return {"motivo": "Este plan se cobra por cotización: coordine el pago con su asesor"}
    extras = planes.extras_de(e)
    if "canales" in extras:
        return {"motivo": "La integración de canales se cobra en dólares aparte: coordine el pago con su asesor"}
    if p.get("precio_habitacion"):
        hab = max(int(getattr(e, "habitaciones", 0) or 0), int(p.get("minimo_habitaciones") or 0))
        por_hab = float(p["precio_habitacion"]) + sum(float(p.get("extra_habitacion") or 0) for x in extras if planes.EXTRAS.get(x, {}).get("precio_habitacion"))
        sin_iva = hab * por_hab
        fijos = [x for x in extras if planes.EXTRAS.get(x, {}).get("precio") and not planes.EXTRAS.get(x, {}).get("precio_habitacion")]   # extras de precio fijo (FISITAAP, 3.47)
        sin_iva += sum(float(planes.EXTRAS[x]["precio"]) for x in fijos)
        detalle = f"{p['nombre']}: {hab} habitaciones" + ((" + " + ", ".join(planes.EXTRAS[x]["nombre"] for x in fijos)) if fijos else "")
    else:
        sin_iva = float(p.get("precio") or 0)
        if not p.get("incluye_extras"):
            sin_iva += sum(float(planes.EXTRAS[x].get("precio") or 0) for x in extras)
        detalle = p["nombre"] + ((" + " + ", ".join(planes.EXTRAS[x]["nombre"] for x in extras)) if extras and not p.get("incluye_extras") else "")
    if sin_iva <= 0:
        return {"motivo": "El plan no tiene precio definido"}
    iva = round(sin_iva * IVA, 2)
    return {"sin_iva": round(sin_iva, 2), "iva": iva, "total": round(sin_iva + iva, 2), "moneda": "CRC", "periodo": p.get("periodo") or "mes", "nombre": detalle}


# ----------------------------------------------------------------------------- avisos (webhooks)
def token_aviso() -> str:
    """Parte secreta de las direcciones de aviso: sin ella nadie puede disparar sincronizaciones desde afuera."""
    return hmac.new(SECRET, b"tilopay-webhook", hashlib.sha256).hexdigest()[:32]


def _base(request: Optional[Request]) -> str:
    if URL_PUBLICA:
        return URL_PUBLICA
    return str(request.base_url).rstrip("/") if request is not None else ""


def _urls(request: Optional[Request]) -> dict:
    b = _base(request)
    if not b:
        return {"thanks_url": ""} | {f"webhook_{x}": "" for x in EVENTOS}
    publica = b.startswith("https://")                      # Tilopay solo puede avisar a una dirección pública
    return {"thanks_url": b + "/app/#/configuracion/suscripcion?tilopay=1"} | {f"webhook_{x}": (f"{b}/api/pagos/tilopay/{token_aviso()}/{x}" if publica else "") for x in EVENTOS}


# ----------------------------------------------------------------------------- operaciones
def _registro(s: Session, e) -> Optional[SuscripcionPago]:
    return s.exec(select(SuscripcionPago).where(SuscripcionPago.empresa_id == e.id).order_by(SuscripcionPago.id.desc())).first()


def activar(s: Session, e, correo: str, request: Optional[Request] = None) -> dict:
    """Crea (o actualiza) el plan recurrente de la empresa en Tilopay y devuelve la dirección donde registra la tarjeta."""
    m = monto_plan(e)
    if "motivo" in m:
        raise HTTPException(400, m["motivo"])
    correo = (correo or "").strip().lower()
    if "@" not in correo or len(correo) > 120:
        raise HTTPException(400, "Indique un correo válido para el pago automático")
    reg = _registro(s, e)
    if reg and reg.estado == "activa":
        raise HTTPException(409, "El pago automático ya está activo. Para cambiar la tarjeta, cancélelo y vuelva a activarlo")
    nombre = (e.nombre_comercial or e.nombre or "Empresa")[:60]
    cuerpo = {"title": f"FISITAAP by Brillante Agencia - {nombre}"[:90], "description": m["nombre"][:180], "frecuency": FRECUENCIA.get(m["periodo"], 3), "currency": m["moneda"],
              "first_amount": 0, "trial": 0, "trial_days": 0, "attempts": 3, "modality": [{"title": m["nombre"][:80], "amount": m["total"]}],
              "end_at": "", "notify": 0, **_urls(request)}
    if reg and reg.plan_id and abs(float(reg.monto or 0) - float(m["total"])) > 0.009:
        # editPlanRepeat no cambia el monto de la modalidad: con otro precio se crea un plan nuevo y se retira el anterior
        try:
            llamar("deletePlanRepeat", {"id": str(reg.plan_id)})
        except HTTPException:
            pass
        reg.plan_id = None
    if reg and reg.plan_id:
        j = llamar("getPlanRepeat", {"id": str(reg.plan_id)})
        if not _ok(j):                                        # el plan ya no existe en Tilopay: se crea otro
            reg.plan_id = None
    if not reg or not reg.plan_id:
        j = llamar("createPlanRepeat", cuerpo)
        if not _ok(j) or not j.get("id"):
            raise HTTPException(502, "Tilopay no creó el plan: " + str(j.get("message") or j.get("type")))
        reg = reg or SuscripcionPago(empresa_id=e.id)
        reg.plan_id = int(j["id"])
    reg.monto, reg.moneda, reg.periodo, reg.correo = m["total"], m["moneda"], m["periodo"], correo
    reg.estado, reg.ultimo_error = "pendiente", None
    s.add(reg); s.commit(); s.refresh(reg)
    u = llamar("recurrentUrl", {"id": str(reg.plan_id), "email": correo})
    url = u.get("url_register") or u.get("url_renew")
    if not _ok(u) or not url:
        raise HTTPException(502, "Tilopay no devolvió la página de registro: " + str(u.get("message") or u.get("type")))
    return {"url": url, "plan_id": reg.plan_id, "monto": reg.monto}


def _suscriptor(lista: list, correo: Optional[str]) -> Optional[dict]:
    """El suscriptor de la empresa en su plan: el del correo registrado y, si no, el más reciente que no esté borrado."""
    vivos = [x for x in lista or [] if str(x.get("status") or "").lower() != "delete"]
    if correo:
        c = [x for x in vivos if str(x.get("email") or "").strip().lower() == correo]
        if c:
            return sorted(c, key=lambda x: str(x.get("create") or ""))[-1]
    return sorted(vivos, key=lambda x: str(x.get("create") or ""))[-1] if vivos else None


ESTADOS_TILOPAY = {"active": "activa", "pause": "pausada", "paused": "pausada", "inactive": "cancelada", "cancel": "cancelada", "canceled": "cancelada", "delete": "cancelada"}


def sincronizar(s: Session, e, reg: Optional[SuscripcionPago] = None, evento: Optional[str] = None) -> dict:
    """Pregunta a Tilopay por el suscriptor y los pagos del plan de la empresa; registra los pagos aprobados que falten."""
    reg = reg or _registro(s, e)
    if not reg or not reg.plan_id or not disponible():
        return {"registrados": 0}
    nuevos = 0
    sub = llamar("getSuscriptorRepeat", {"id": str(reg.plan_id)})
    if _ok(sub):
        x = _suscriptor(sub.get("suscriptor") or [], reg.correo)
        if x:
            reg.suscriptor_id = x.get("id")
            reg.proximo_cobro = (str(x.get("expire") or "")[:10]) or reg.proximo_cobro
            est = ESTADOS_TILOPAY.get(str(x.get("status") or "").strip().lower())
            if est and not (reg.estado == "rechazada" and est == "activa" and evento == "rejected"):
                reg.estado = est
    # OJO: aunque la documentación dice «id del plan», getSuscriptorPayments recibe el id del SUSCRIPTOR (verificado en modo de
    # prueba el 21/10/2026: con el id del plan responde «The requested plan does not exist»)
    pagos = llamar("getSuscriptorPayments", {"id": str(reg.suscriptor_id)}) if reg.suscriptor_id else {}
    if _ok(pagos):
        hechos = {p.referencia for p in s.exec(select(PagoPlan).where(PagoPlan.empresa_id == e.id, PagoPlan.referencia.like("tilopay:%"))).all()}
        for p in sorted(pagos.get("data") or [], key=lambda x: str(x.get("create") or "")):
            if reg.suscriptor_id and p.get("suscriptor_id") and int(p["suscriptor_id"]) != int(reg.suscriptor_id):
                continue
            ref = f"tilopay:{p.get('id')}"
            try:
                monto = float(p.get("amount") or 0)
            except (TypeError, ValueError):
                monto = 0
            if ref in hechos or monto <= 0 or int(p.get("status") or 0) != 1:      # status 1 = cobro aprobado; 0 = registro sin cobro
                continue
            if not getattr(e, "plan", None):
                break
            planes.registrar_pago(s, e, {"fecha": str(p.get("create") or "")[:10] or None, "monto": monto, "moneda": p.get("currency") or reg.moneda,
                                         "medio": "Tarjeta (Tilopay)", "referencia": ref, "meses": 12 if reg.periodo == "anio" else 1,
                                         "nota": f"Cobro automático Tilopay · orden {p.get('reference') or '—'}"}, usuario="Tilopay")
            hechos.add(ref); nuevos += 1
            reg.estado = "activa"
    reg.sincronizado = ahora_cr().isoformat(timespec="seconds")
    if evento:
        reg.ultimo_evento = evento
    s.add(reg); s.commit()
    return {"registrados": nuevos, "estado": reg.estado}


def cancelar(s: Session, e) -> dict:
    reg = _registro(s, e)
    if not reg or not reg.plan_id:
        raise HTTPException(404, "No hay pago automático para cancelar")
    sub = llamar("getSuscriptorRepeat", {"id": str(reg.plan_id)})
    x = _suscriptor(sub.get("suscriptor") or [], reg.correo) if _ok(sub) else None
    if x and x.get("id"):
        j = llamar("deleteSuscriptorRepeat", {"id_suscriptor": str(x["id"])})
        if not _ok(j):
            raise HTTPException(502, "Tilopay no canceló el cobro automático: " + str(j.get("message") or j.get("type")))
    reg.estado, reg.proximo_cobro = "cancelada", None
    s.add(reg); s.commit()
    return {"ok": True}


def estado(s: Session, e) -> dict:
    revisar_unicos(s, e)                     # 3.97: pagos únicos con tarjeta que quedaron sin confirmar
    reg = _registro(s, e)
    m = monto_plan(e)
    pagos = s.exec(select(PagoPlan).where(PagoPlan.empresa_id == e.id).order_by(PagoPlan.id.desc())).all()[:24]
    try:                                     # uso de comprobantes del periodo: se cuenta en la base de la empresa
        from .db import engine_empresa
        with Session(engine_empresa(e.id)) as se:
            info = planes.info(e, se)
    except Exception:  # noqa: BLE001
        info = planes.info(e)
    return {"disponible": disponible(), "modo_prueba": bool(_leer_config().get("modo_prueba")), "plan": info, "monto": m,
            "suscripcion": None if not reg else {"estado": reg.estado, "monto": reg.monto, "moneda": reg.moneda, "periodo": reg.periodo, "correo": reg.correo,
                                                 "proximo_cobro": reg.proximo_cobro, "sincronizado": reg.sincronizado, "monto_distinto": "total" in m and abs(float(m["total"]) - float(reg.monto or 0)) > 0.009},
            "pagos": [{"fecha": p.fecha, "monto": p.monto, "moneda": p.moneda, "medio": p.medio, "referencia": p.referencia, "vence_nuevo": p.vence_nuevo} for p in pagos],
            "correo_sugerido": getattr(e, "correo", None) or ""}


def sincronizar_todas() -> int:
    """Una pasada diaria (cola): pagos que Tilopay haya cobrado y el aviso no haya traído."""
    if not disponible():
        return 0
    n = 0
    with Session(engine) as s:
        for eid in sorted({int(v.get("eid") or 0) for v in _pendientes().values()}):     # 3.97: pagos únicos sin confirmar
            e = s.get(Empresa, eid)
            if e:
                try:
                    n += revisar_unicos(s, e)
                except Exception:  # noqa: BLE001
                    log.exception("Tilopay: no se pudo revisar el pago único de la empresa %s", eid)
        for reg in s.exec(select(SuscripcionPago).where(SuscripcionPago.estado.in_(("activa", "pendiente", "rechazada")))).all():
            e = s.get(Empresa, reg.empresa_id)
            if not e:
                continue
            try:
                n += sincronizar(s, e, reg).get("registrados", 0)
            except Exception:  # noqa: BLE001
                log.exception("Tilopay: no se pudo sincronizar la empresa %s", reg.empresa_id)
    return n


# ----------------------------------------------------------------------------- API
@router.get("/api/plan/suscripcion")
def get_suscripcion(sincronizar_ahora: int = 0, ctx: Contexto = Depends(contexto), s: Session = Depends(get_session)):
    """Estado del pago del plan de la empresa activa. sincronizar_ahora=1 al volver de Tilopay."""
    e = s.get(Empresa, ctx.empresa.id)
    if sincronizar_ahora and ctx.puede("usuarios"):
        try:
            sincronizar(s, e)
        except HTTPException as ex:
            log.warning("Tilopay: sincronización al volver falló: %s", ex.detail)
        s.refresh(e)
    return estado(s, e)


def _puede_pagar(ctx: Contexto = Depends(contexto)) -> Contexto:
    """3.95: pagan el plan con tarjeta el Administrador, el Avanzado y el Contador (ver_todo y escribir; Solo lectura y Vendedor no)."""
    if not (ctx.puede("usuarios") or (ctx.puede("ver_todo") and ctx.puede("escribir"))):
        raise HTTPException(403, "Su rol no puede pagar el plan: lo hace el Administrador, el Avanzado o el Contador")
    return ctx


# ----------------------------------------------------------------------------- pago único del plan (3.97)
# Para quien no quiere el pago automático: paga UN periodo del plan con tarjeta en la página de Tilopay (processPayment, como la
# tienda en línea). La orden queda pendiente en PENDIENTES; se confirma consultando a Tilopay (nunca por lo que trae la dirección)
# al volver, al abrir la pantalla del plan y en la revisión diaria. El pago se registra una sola vez (referencia = orden) y extiende
# el plan un periodo con planes.registrar_pago, que también emite la factura del plan.
PENDIENTES = DATA_DIR / "pagos_unicos.json"
_cerrojo_unicos = threading.Lock()
DIAS_PENDIENTE = 3


def _pendientes() -> dict:
    try:
        return json.loads(PENDIENTES.read_text(encoding="utf-8")) or {}
    except Exception:  # noqa: BLE001
        return {}


def _guardar_pendientes(d: dict) -> None:
    tmp = PENDIENTES.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    os.replace(tmp, PENDIENTES)


def _registrar_unico(s: Session, e, orden: str, monto: float) -> bool:
    """Registra el pago de la orden si todavía no está (idempotente). True si lo registró ahora."""
    if s.exec(select(PagoPlan).where(PagoPlan.empresa_id == e.id, PagoPlan.referencia == orden)).first():
        return False
    planes.registrar_pago(s, e, {"fecha": ahora_cr().date().isoformat(), "monto": monto, "moneda": "CRC", "medio": "Tarjeta (Tilopay, pago único)",
                                 "referencia": orden, "meses": 1}, usuario="tilopay")
    return True


def confirmar_unico(s: Session, e, orden: str) -> str:
    """'pagado' | 'pendiente' | 'rechazado'. Consulta la orden a Tilopay y, si está aprobada por el monto esperado, la registra."""
    from . import pagos_online
    with _cerrojo_unicos:
        pend = _pendientes()
        dato = pend.get(orden)
        if s.exec(select(PagoPlan).where(PagoPlan.empresa_id == e.id, PagoPlan.referencia == orden)).first():
            pend.pop(orden, None); _guardar_pendientes(pend)
            return "pagado"
        if not dato or int(dato.get("eid") or 0) != e.id:
            return "rechazado"
        cred = credenciales()
        if not cred:
            return "pendiente"
        r = pagos_online.consultar(cred, orden)
        if r and r.get("aprobado") and float(r.get("monto") or 0) + 0.5 >= float(dato.get("monto") or 0):
            _registrar_unico(s, e, orden, float(r.get("monto") or dato.get("monto") or 0))
            pend.pop(orden, None); _guardar_pendientes(pend)
            return "pagado"
        viejo = (time.time() - float(dato.get("creado") or 0)) > DIAS_PENDIENTE * 86400
        if viejo or (r and not r.get("aprobado") and r.get("detalle")):
            if viejo:
                pend.pop(orden, None); _guardar_pendientes(pend)
            return "rechazado" if r else "pendiente"
        return "pendiente"


def revisar_unicos(s: Session, e) -> int:
    """Confirma las órdenes pendientes de la empresa (barato: sin pendientes no consulta nada)."""
    n = 0
    for orden, v in list(_pendientes().items()):
        if int(v.get("eid") or 0) == e.id:
            try:
                n += confirmar_unico(s, e, orden) == "pagado"
            except Exception:  # noqa: BLE001
                log.exception("Tilopay: no se pudo confirmar la orden %s", orden)
    return n


@router.post("/api/plan/pago-unico")
def post_pago_unico(data: dict, request: Request, ctx: Contexto = Depends(_puede_pagar), s: Session = Depends(get_session)):
    """3.97: abre la página de Tilopay para pagar un periodo del plan una sola vez, sin pago automático."""
    from . import pagos_online
    cred = credenciales()
    if not cred:
        raise HTTPException(400, "El pago con tarjeta no está disponible en este momento")
    e = s.get(Empresa, ctx.empresa.id)
    m = monto_plan(e)
    if m.get("motivo"):
        raise HTTPException(400, m["motivo"])
    correo = (str((data or {}).get("correo") or "").strip() or getattr(e, "correo", "") or "")[:120]
    if "@" not in correo:
        raise HTTPException(400, "Indique un correo para el comprobante del pago")
    orden = f"PL{e.id}-{ahora_cr():%y%m%d%H%M}-{secrets.token_hex(3)}"
    with _cerrojo_unicos:
        pend = _pendientes(); pend[orden] = {"eid": e.id, "monto": m["total"], "creado": time.time(), "correo": correo}; _guardar_pendientes(pend)
    p = types.SimpleNamespace(nombre=getattr(e, "nombre_comercial", None) or e.nombre, pago_orden=orden, direccion=getattr(e, "otras_senas", "") or "",
                              telefono=str(getattr(e, "telefono", "") or ""), token=orden)
    url = pagos_online.iniciar_pago(cred, p, m["total"], _base(request) + "/api/plan/pago-unico/retorno?orden=" + orden, correo)
    return {"url": url, "orden": orden, "monto": m["total"]}


@router.get("/api/plan/pago-unico/retorno")
def get_pago_unico_retorno(orden: str = "", s: Session = Depends(get_session)):
    """3.97: Tilopay devuelve aquí al cliente. Lo que trae la dirección no se cree: se consulta la orden a Tilopay."""
    estado_pago = "rechazado"
    try:
        eid = int(orden.split("-", 1)[0][2:]) if orden.startswith("PL") else 0
        e = s.get(Empresa, eid) if eid else None
        if e:
            estado_pago = confirmar_unico(s, e, orden)
    except Exception:  # noqa: BLE001
        log.exception("Tilopay: retorno del pago único %s", orden)
        estado_pago = "pendiente"
    return RedirectResponse("/app/#/configuracion/suscripcion?pago_unico=" + estado_pago, status_code=303)


@router.post("/api/plan/suscripcion/activar")
def post_activar(data: dict, request: Request, ctx: Contexto = Depends(_puede_pagar), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    return activar(s, e, str((data or {}).get("correo") or ""), request)


@router.post("/api/plan/suscripcion/cancelar")
def post_cancelar(ctx: Contexto = Depends(requiere("usuarios")), s: Session = Depends(get_session)):
    return cancelar(s, s.get(Empresa, ctx.empresa.id))


@router.post("/api/pagos/tilopay/{token}/{evento}")
async def aviso_tilopay(token: str, evento: str, request: Request, tareas: BackgroundTasks):
    """Aviso de Tilopay. Se responde 200 de inmediato (Tilopay lo exige) y se sincroniza aparte con la API: el contenido del
    aviso solo indica qué plan revisar, nunca se toma como prueba de pago."""
    if not hmac.compare_digest(token, token_aviso()) or evento not in EVENTOS:
        raise HTTPException(404)
    try:
        cuerpo = await request.json()
    except Exception:  # noqa: BLE001
        cuerpo = {}
    try:
        plan_id = int((cuerpo or {}).get("id_plan") or 0)
    except (TypeError, ValueError):
        plan_id = 0
    if plan_id:
        tareas.add_task(_procesar_aviso, plan_id, evento)
    return {"ok": True}


def _procesar_aviso(plan_id: int, evento: str):
    with Session(engine) as s:
        reg = s.exec(select(SuscripcionPago).where(SuscripcionPago.plan_id == plan_id)).first()
        if not reg:
            return
        e = s.get(Empresa, reg.empresa_id)
        if not e:
            return
        try:
            antes = reg.estado
            sincronizar(s, e, reg, evento)
            if evento == "rejected":
                reg.estado = "rechazada"; s.add(reg); s.commit()
                planes._enviar_aviso(s, e, "No se pudo cobrar su plan de FISITAAP by Brillante Agencia",
                                     f"Hola, {e.nombre_comercial or e.nombre}.\n\nTilopay no pudo cobrar el pago automático de su plan con la tarjeta registrada. "
                                     "Tilopay lo vuelve a intentar en los próximos días. Si cambió de tarjeta, entre a Configuración › Suscripción y planes, "
                                     "cancele el pago automático y vuelva a activarlo con la tarjeta nueva.\n\nFISITAAP by Brillante Agencia")
            elif evento == "unsubscribe" and antes != "cancelada":
                reg.estado = "cancelada"; s.add(reg); s.commit()
        except Exception:  # noqa: BLE001
            log.exception("Tilopay: no se pudo procesar el aviso %s del plan %s", evento, plan_id)


@router.get("/api/admin/pasarela")
def admin_ver_pasarela(_: Usuario = Depends(superadmin)):
    """Consola · Pagos en línea: configuración de Tilopay sin mostrar las claves."""
    return _pasarela_salida()


def _pasarela_salida() -> dict:
    """3.96: lo mismo al ver y al guardar (antes, al guardar faltaba aviso_url y la consola mostraba el aviso de FE_URL_PUBLICA aunque estuviera)."""
    return _resumen_config() | {"aviso_url": bool(URL_PUBLICA and URL_PUBLICA.startswith("https://")), "url_publica": URL_PUBLICA}


@router.put("/api/admin/pasarela")
def admin_guardar_pasarela(data: dict, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Guarda las credenciales de Tilopay cifradas. Un campo en blanco conserva el valor guardado."""
    from .auth import auditar
    cfg = _leer_config()
    for campo in ("key", "user", "password"):
        v = str((data or {}).get(campo) or "").strip()
        if v:
            if len(v) > 200:
                raise HTTPException(400, "Valor demasiado largo")
            cfg[campo] = secretos._maestra.encrypt(v.encode()).decode()
    cfg["activo"] = bool((data or {}).get("activo"))
    cfg["modo_prueba"] = bool((data or {}).get("modo_prueba"))
    if cfg["activo"] and not all(_descifrar(cfg.get(x)) for x in ("key", "user", "password")):
        raise HTTPException(400, "Para activar el cobro con tarjeta complete la llave, el usuario y la contraseña de la API de Tilopay")
    cfg["actualizado"] = ahora_cr().isoformat(timespec="seconds")
    tmp = ARCHIVO.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg), encoding="utf-8")
    os.replace(tmp, ARCHIVO)
    try:
        os.chmod(ARCHIVO, 0o600)
    except OSError:
        pass
    _token["valor"] = None
    auditar(s, "pasarela_configurada", "Tilopay " + ("activo" if cfg["activo"] else "inactivo") + (" (modo de prueba)" if cfg["modo_prueba"] else ""), a, None, request)
    return _pasarela_salida()


@router.post("/api/admin/pasarela/probar")
def admin_probar_pasarela(_: Usuario = Depends(superadmin)):
    """Prueba la conexión: inicia sesión en Tilopay y lista los planes de la integración."""
    cfg = _leer_config()
    if cfg and not cfg.get("activo"):
        raise HTTPException(400, "Active primero el cobro con tarjeta y guarde")
    _token["valor"] = None
    j = llamar("getPlansRepeat", {})
    ok = _ok(j)
    if cfg:
        cfg["ultima_prueba"] = {"fecha": ahora_cr().isoformat(timespec="seconds"), "ok": ok, "mensaje": "Conexión correcta" if ok else str(j.get("message") or j.get("type"))[:120]}
        ARCHIVO.write_text(json.dumps(cfg), encoding="utf-8")
    if not ok:
        raise HTTPException(502, "Tilopay respondió: " + str(j.get("message") or j.get("type")))
    return {"ok": True, "planes": len(j.get("data") or [])}


@router.get("/api/admin/suscripciones")
def admin_suscripciones(u: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Consola: pago automático de cada empresa (3.87: sin las empresas ocultas para este administrador)."""
    from .auth import empresas_ocultas_de
    ocultas = empresas_ocultas_de(u)
    out = []
    for r in s.exec(select(SuscripcionPago).order_by(SuscripcionPago.id.desc())).all():
        if r.empresa_id in ocultas:
            continue
        e = s.get(Empresa, r.empresa_id)
        out.append({"empresa_id": r.empresa_id, "empresa": (e.nombre_comercial or e.nombre) if e else f"#{r.empresa_id}", "estado": r.estado, "monto": r.monto,
                    "moneda": r.moneda, "periodo": r.periodo, "proximo_cobro": r.proximo_cobro, "vence": getattr(e, "vence", None) if e else None, "plan_id": r.plan_id,
                    "correo": r.correo, "sincronizado": r.sincronizado, "ultimo_evento": r.ultimo_evento})
    return out


@router.post("/api/admin/suscripciones/{eid}/sincronizar")
def admin_sincronizar(eid: int, _: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    return sincronizar(s, e)
