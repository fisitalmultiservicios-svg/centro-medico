"""Configuración de impresión por tipo de documento y por empresa (se guarda en la base de datos de cada empresa)."""
import json
import re

from sqlmodel import Session, select

from .db import ConfigDocumento, engine_empresa

CAMPOS = {
    "logo": ("Encabezado", "Logo de la empresa"),
    "emisor_nombre": ("Encabezado", "Nombre de la empresa"),
    "emisor_cedula": ("Encabezado", "Cédula / identificación"),
    "emisor_direccion": ("Encabezado", "Dirección"),
    "emisor_correo": ("Encabezado", "Correo electrónico"),
    "emisor_sitio_web": ("Encabezado", "Sitio web"),
    "emisor_telefono": ("Encabezado", "Teléfono"),
    "emisor_actividad": ("Encabezado", "Actividad económica"),
    "titulo": ("Documento", "Título del documento"),
    "numero": ("Documento", "Número / consecutivo"),
    "clave": ("Documento", "Clave de Hacienda (50 dígitos)"),
    "fecha_creacion": ("Documento", "Fecha de creación"),
    "fecha_emision": ("Documento", "Fecha y hora de emisión"),
    "fecha_vencimiento": ("Documento", "Fecha de vencimiento"),
    "condicion": ("Documento", "Condición de venta"),
    "vendedor": ("Documento", "Vendedor"),
    "moneda": ("Documento", "Moneda"),
    "saldo_pendiente": ("Documento", "Valor restante por pagar"),
    "medio_pago": ("Documento", "Medio de pago"),
    "qr": ("Documento", "Código QR de la clave"),
    "cliente_nombre": ("Cliente", "Nombre / razón social"),
    "cliente_cedula": ("Cliente", "Cédula / identificación"),
    "cliente_actividad": ("Cliente", "Actividad económica"),
    "cliente_telefono": ("Cliente", "Teléfono"),
    "cliente_direccion": ("Cliente", "Dirección"),
    "cliente_correo": ("Cliente", "Correo electrónico"),
    "col_imagen": ("Tabla de ítems", "Columna Imagen"),
    "col_cabys": ("Tabla de ítems", "Código CABYS bajo el concepto"),
    "col_unidad": ("Tabla de ítems", "Columna Unidad"),
    "col_descuento": ("Tabla de ítems", "Columna Descuento"),
    "col_impuesto": ("Tabla de ítems", "Columna Impuestos"),
    "monto_letras": ("Pie de página", "Monto en letras"),
    "tratamiento_impuestos": ("Pie de página", "Tabla de tratamiento de impuestos"),
    "terminos": ("Pie de página", "Términos y condiciones"),
    "notas": ("Pie de página", "Notas"),
    "leyenda_legal": ("Pie de página", "Leyenda legal de Hacienda (versión 4.4)"),
    "paginacion": ("Pie de página", "Página X de Y"),
}

TIPOS = {
    "factura": "Factura de venta electrónica",
    "tiquete": "Tiquete electrónico",
    "nota_credito": "Nota de crédito electrónica",
    "nota_debito": "Nota de débito electrónica",
    "cotizacion": "Cotización",
    "remision": "Remisión",
    "orden_compra": "Orden de compra",
    "recibo": "Recibo de pago",
    "recibo_pago": "Recibo electrónico de pago",
}

TERMINOS_DEFAULT = ""     # cada empresa escribe los suyos en Configuración › Documentos (p. ej. cuentas IBAN y condiciones de pago)

_FACTURA = ["logo", "emisor_nombre", "emisor_cedula", "emisor_direccion", "emisor_correo", "emisor_sitio_web", "emisor_telefono",
            "emisor_actividad", "titulo", "numero", "clave", "fecha_creacion", "fecha_emision", "fecha_vencimiento", "condicion",
            "vendedor", "moneda", "saldo_pendiente", "medio_pago", "qr", "cliente_nombre", "cliente_cedula", "cliente_actividad",
            "cliente_telefono", "cliente_direccion", "cliente_correo", "col_cabys", "col_unidad", "col_descuento", "col_impuesto",
            "monto_letras", "tratamiento_impuestos", "terminos", "notas", "leyenda_legal", "paginacion"]
_COTIZACION = ["logo", "emisor_cedula", "emisor_correo", "emisor_telefono", "emisor_sitio_web", "titulo", "numero", "fecha_creacion",
               "fecha_vencimiento", "cliente_nombre", "cliente_telefono", "cliente_direccion", "cliente_cedula", "col_imagen",
               "col_unidad", "col_descuento", "col_impuesto", "monto_letras", "terminos", "notas", "paginacion"]

DEFAULTS = {
    "factura": _FACTURA,
    "tiquete": [c for c in _FACTURA if not c.startswith("cliente_")],
    "nota_credito": [c for c in _FACTURA if c != "saldo_pendiente"],     # una nota de crédito no tiene "valor restante por pagar" (R254)
    "nota_debito": _FACTURA,
    "recibo_pago": [c for c in _FACTURA if c not in ("col_cabys", "col_unidad", "col_descuento", "tratamiento_impuestos", "saldo_pendiente", "fecha_vencimiento", "vendedor")],
    "cotizacion": _COTIZACION,
    "remision": _COTIZACION + ["condicion", "vendedor"],
    "orden_compra": [c for c in _COTIZACION if c != "col_imagen"] + ["emisor_nombre", "emisor_direccion"],
    "recibo": ["logo", "emisor_nombre", "emisor_cedula", "emisor_correo", "emisor_telefono", "titulo", "numero", "fecha_creacion",
               "cliente_nombre", "cliente_cedula", "medio_pago", "monto_letras", "notas", "paginacion"],
}


# Estilo de impresión de la empresa (Configuración › Plantillas de impresión): registro `estilo_impresion`; la firma, `firma_documentos`
ESTILO_BASE = {"color": "#0f766e", "tamano": 9.5, "papel": "carta", "pie": "", "firma_texto": "", "mostrar_firma": True}
_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


def validar_estilo(est) -> dict:
    """Devuelve un estilo completo y seguro a partir de lo guardado (valores fuera de rango → los base)."""
    out = dict(ESTILO_BASE)
    if not isinstance(est, dict):
        return out
    c = str(est.get("color") or "")
    if _HEX.match(c):
        out["color"] = c.lower()
    try:
        tam = float(est.get("tamano") or 0)
        if 7.5 <= tam <= 12:
            out["tamano"] = round(tam, 1)
    except (TypeError, ValueError):
        pass
    if str(est.get("papel") or "").lower() in ("carta", "a4"):
        out["papel"] = str(est["papel"]).lower()
    out["pie"] = str(est.get("pie") or "")[:200]
    out["firma_texto"] = str(est.get("firma_texto") or "")[:80]
    out["mostrar_firma"] = est.get("mostrar_firma") is not False
    return out


def estilo_empresa(empresa_id: int) -> dict:
    from . import modulos
    with Session(engine_empresa(empresa_id)) as s:
        est = validar_estilo(modulos.leer(s, empresa_id, "estilo_impresion", {}))
        firma = modulos.leer(s, empresa_id, "firma_documentos", None)
    est["firma"] = firma if isinstance(firma, str) and firma.startswith("data:image/") and len(firma) < 600000 and est["mostrar_firma"] else None
    return est


def _fila(s: Session, tipo: str) -> ConfigDocumento | None:
    return s.exec(select(ConfigDocumento).where(ConfigDocumento.tipo == tipo)).first()


def obtener(tipo: str, empresa_id: int) -> dict:
    if tipo not in TIPOS:
        tipo = "factura"
    with Session(engine_empresa(empresa_id)) as s:
        c = _fila(s, tipo)
        if c:
            return {"tipo": tipo, "titulo": c.titulo or TIPOS[tipo], "campos": json.loads(c.campos), "terminos": c.terminos or "",
                    "notas": c.notas or "", "guardada": True, "estilo": estilo_empresa(empresa_id)}
    return {"tipo": tipo, "titulo": TIPOS[tipo], "campos": list(DEFAULTS[tipo]), "terminos": TERMINOS_DEFAULT, "notas": "", "guardada": False,
            "estilo": estilo_empresa(empresa_id)}


def guardar(tipo: str, titulo: str | None, campos: list[str], terminos: str | None, notas: str | None, empresa_id: int) -> dict:
    campos = [c for c in campos if c in CAMPOS]
    if tipo in ("factura", "tiquete", "nota_credito", "nota_debito", "recibo_pago"):     # la clave y el consecutivo son obligatorios en la
        campos += [c for c in ("clave", "numero") if c not in campos]                   # representación impresa de un electrónico (R255)
    with Session(engine_empresa(empresa_id)) as s:
        c = _fila(s, tipo) or ConfigDocumento(empresa_id=empresa_id, tipo=tipo)
        c.titulo, c.campos, c.terminos, c.notas = titulo or TIPOS.get(tipo, tipo), json.dumps(campos), terminos, notas
        s.add(c); s.commit()
    return obtener(tipo, empresa_id)


def restaurar(tipo: str, empresa_id: int) -> dict:
    with Session(engine_empresa(empresa_id)) as s:
        c = _fila(s, tipo)
        if c:
            s.delete(c); s.commit()
    return obtener(tipo, empresa_id)


def catalogo() -> dict:
    grupos: dict[str, list] = {}
    for clave, (grupo, etiqueta) in CAMPOS.items():
        grupos.setdefault(grupo, []).append({"clave": clave, "etiqueta": etiqueta})
    return {"grupos": grupos, "tipos": TIPOS}
