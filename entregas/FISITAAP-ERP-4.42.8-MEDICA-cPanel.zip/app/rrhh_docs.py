"""Recursos humanos › documentos del empleado (4.22): contrato, identificación, permiso de trabajo, títulos y otros.

Cada archivo vive en DATA_DIR/empresas/<empresa>/rrhh_documentos/<empleado>/doc_<id>.<ext> (esa carpeta ya entra completa en el
respaldo de la empresa y vuelve al restaurarlo) y sus datos en el registro 'rrhh_documentos':
[{id, empleado_id, tipo, nombre, vence 'AAAA-MM-DD' | '', archivo 'doc_<id>.<ext>', bytes, mime, subido_por, subido_en}].
Ese registro lo escribe SOLO el servidor, por estas rutas (main._revisar_escritura rechaza el guardado genérico), y como todo lo de
Recursos humanos solo lo lee quien tiene el permiso rrhh (que exige la verificación en dos pasos). Reglas:
- Hasta MAX_DOC por archivo, MAX_POR_EMPLEADO archivos por empleado y MAX_BYTES_EMPRESA entre todos los de la empresa.
- Solo PDF, JPG y PNG, reconocidos por la firma del contenido (sus primeros bytes), nunca por la extensión ni por lo que diga el
  navegador. El nombre físico lo pone el servidor: del nombre del archivo subido no se usa nada.
- Solo en la nube: los archivos no viajan a las instalaciones locales, así que ahí no se suben.
- Al eliminar un empleado se van sus documentos (borrar_de_empleados: lo llama main DESPUÉS de guardar la baja). Al borrar la lista
  completa de empleados, los de todos (borrar_todos: lo llama main ANTES de borrar la lista, que no se borra si esto falla).
- Un número de documento no se vuelve a dar: la fila del registro guarda el mayor que hubo y no se borra nunca desde aquí.
El historial de operaciones anota quién subió, cambió, descargó o eliminó cada documento: su tipo, su número y el empleado. Nunca el
nombre que el usuario le puso al documento (puede traer una identificación) ni el del archivo."""
import logging
import os
import re
import shutil
import unicodedata
from datetime import date
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlmodel import Session

from . import modulos
from .auth import Contexto, requiere, sesion_empresa
from .config import DATA_DIR, ahora_cr

log = logging.getLogger(__name__)
router = APIRouter(tags=["rrhh"])

CLAVE = "rrhh_documentos"
MAX_DOC = 5 * 1024 * 1024                 # por archivo
MAX_POR_EMPLEADO = 50                     # archivos por empleado
MAX_BYTES_EMPRESA = 200 * 1024 * 1024     # entre todos los documentos de la empresa
MAX_NOMBRE = 120
# Los tipos de archivo que se admiten, por la firma de su contenido: (primeros bytes, extensión, tipo MIME)
FIRMAS = ((b"%PDF-", "pdf", "application/pdf"), (b"\xff\xd8\xff", "jpg", "image/jpeg"), (b"\x89PNG\r\n\x1a\n", "png", "image/png"))
MIME = {ext: mime for _, ext, mime in FIRMAS}
# Los mismos de TIPOS_DOCUMENTO en static/js/pages/rrhh/_datos.js
TIPOS = {"contrato": "Contrato", "identificacion": "Identificación", "permiso_trabajo": "Permiso de trabajo", "titulo": "Título o certificado", "otro": "Otro"}
_ARCHIVO = re.compile(r"doc_\d+\.(pdf|jpg|png)")


def tipo_de_archivo(datos: bytes) -> Optional[tuple]:
    """(extensión, tipo MIME) según los primeros bytes del contenido, o None si no es un PDF, un JPG ni un PNG."""
    for firma, ext, mime in FIRMAS:
        if datos.startswith(firma):
            return ext, mime
    return None


def validar_datos(tipo, nombre, vence) -> tuple:
    """(tipo, nombre, vence) listos para guardar, o ValueError con qué corregir. El tipo es uno de TIPOS; el nombre, de 1 a MAX_NOMBRE
    letras (sin saltos de línea ni otros caracteres de control; vacío toma el nombre del tipo); el vencimiento, vacío o una fecha
    AAAA-MM-DD que exista. Solo formato: no dice qué documentos pide la ley ni cuánto vale cada uno."""
    if not isinstance(tipo, str) or tipo not in TIPOS:
        raise ValueError("El tipo de documento no es válido: elija " + ", ".join(list(TIPOS.values())[:-1]) + " u " + list(TIPOS.values())[-1])
    limpio = re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", " ", str(nombre if nombre is not None else ""))).strip() or TIPOS[tipo]
    if len(limpio) > MAX_NOMBRE:
        raise ValueError(f"El nombre del documento admite hasta {MAX_NOMBRE} letras")
    v = str(vence if vence is not None else "").strip()
    if v:
        try:
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
                raise ValueError
            date.fromisoformat(v)
        except ValueError:
            raise ValueError("La fecha de vencimiento no es válida")
    return tipo, limpio, v


def carpeta_empresa(eid: int) -> Path:
    return DATA_DIR / "empresas" / str(int(eid)) / CLAVE


def carpeta_empleado(eid: int, emp_id: int) -> Path:
    return carpeta_empresa(eid) / str(int(emp_id))


def _docs(s: Session, eid: int) -> list:
    v = modulos.leer(s, eid, CLAVE, []) or []
    return [d for d in v if isinstance(d, dict)] if isinstance(v, list) else []


def _ruta(eid: int, d: dict) -> Optional[Path]:
    """El archivo de un documento guardado; None si sus datos no dicen de qué empleado es o su nombre físico no es uno de los que
    pone el servidor (nada que venga de los datos se usa como ruta sin pasar por aquí)."""
    emp, archivo = modulos._id_entero(d.get("empleado_id")), d.get("archivo")
    if emp is None or not isinstance(archivo, str) or not _ARCHIVO.fullmatch(archivo):
        return None
    return carpeta_empleado(eid, emp) / archivo


def nombre_descarga(d: dict) -> str:
    """Nombre con que se descarga: el que le puso el usuario, sin tildes ni signos, con la extensión real del archivo."""
    ext = str(d.get("archivo") or "").rsplit(".", 1)[-1]
    base = unicodedata.normalize("NFKD", str(d.get("nombre") or "")).encode("ascii", "ignore").decode("ascii")
    base = re.sub(r"[^A-Za-z0-9-]+", "_", base).strip("_")[:80] or "documento"
    return f"{base}.{ext}"


def _quien(emp_id, emp) -> str:
    """«#3 Ana Mora» para el historial de operaciones (como la bitácora de la ficha: id y nombre, nunca la identificación)."""
    nombre = " ".join(str((emp or {}).get(k) or "").strip() for k in ("nombre", "apellidos")) if isinstance(emp, dict) else ""
    return (f"#{emp_id} " + re.sub(r"[:\s]+", " ", nombre).strip()[:80]).strip()


def _detalle(d: dict, emp) -> str:
    return f"{TIPOS.get(d.get('tipo') if isinstance(d.get('tipo'), str) else '', 'Documento')} n.º {d.get('id')} · empleado {_quien(modulos._id_entero(d.get('empleado_id')), emp)}"[:500]


def _ayudas():
    """Lo que este módulo usa de main (que lo importa a él: por eso se pide al momento de usarlo)."""
    from . import main
    return main._auditar, main._candado_registro, main._items_guardados


def _http(ex: ValueError) -> HTTPException:
    return HTTPException(400, str(ex) or "Datos del documento inválidos")


@router.post("/api/rrhh/empleados/{emp_id}/documentos")
def subir_documento(emp_id: int, archivo: UploadFile = File(...), tipo: str = Form("otro"), nombre: str = Form(""), vence: str = Form(""),
                    ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Sube un documento a la ficha de un empleado. Todo se revisa aquí: tamaño (413), que sea un PDF, JPG o PNG por su contenido y
    los datos (400), que el empleado exista (404) y los topes por empleado y por empresa (409). El archivo se escribe primero y sus
    datos se guardan después, en el mismo paso en que se revisan los topes: nunca queda un documento en la lista sin su archivo."""
    if os.environ.get("FE_MODO_LOCAL", "") == "1":
        raise HTTPException(403, "Los documentos de los empleados se guardan en la nube: súbalos desde la versión en línea del sistema")
    auditar, candado, guardados = _ayudas()
    eid = ctx.empresa.id
    try:
        tipo, nombre, vence = validar_datos(tipo, nombre, vence)
    except ValueError as ex:
        raise _http(ex)
    datos = archivo.file.read(MAX_DOC + 1)
    if len(datos) > MAX_DOC:
        raise HTTPException(413, f"El archivo supera el tamaño máximo permitido ({MAX_DOC // (1024 * 1024)} MB)")
    if not datos:
        raise HTTPException(400, "El archivo está vacío")
    firma = tipo_de_archivo(datos)
    if firma is None:
        raise HTTPException(400, "Solo se admiten archivos PDF, JPG o PNG: el contenido de este archivo no es de ninguno de esos tipos")
    ext, mime = firma
    # con el candado de escritura tomado ANTES de mirar lo guardado: dos subidas a la vez no pasan juntas del tope ni reciben el mismo
    # número, y nadie elimina al empleado entre que se comprueba que existe y se guarda su documento
    candado(s, eid, CLAVE)
    emp = guardados(s, eid, "empleados", [emp_id]).get(emp_id)
    if not isinstance(emp, dict):
        s.rollback()
        raise HTTPException(404, "El empleado ya no existe: recargue la página")
    docs = _docs(s, eid)
    if sum(1 for d in docs if modulos._id_entero(d.get("empleado_id")) == emp_id) >= MAX_POR_EMPLEADO:
        s.rollback()
        raise HTTPException(409, f"Este empleado ya tiene {MAX_POR_EMPLEADO} documentos, el máximo: elimine alguno antes de subir otro")
    usado = sum(int(d.get("bytes") or 0) for d in docs if isinstance(d.get("bytes"), (int, float)) and not isinstance(d.get("bytes"), bool))
    if usado + len(datos) > MAX_BYTES_EMPRESA:
        s.rollback()
        raise HTTPException(409, f"La empresa llegó al espacio máximo para documentos de empleados ({MAX_BYTES_EMPRESA // (1024 * 1024)} MB): "
                                 "elimine documentos que ya no necesite antes de subir otro")
    reg = modulos._registro(s, eid, CLAVE)
    nuevo = max([(reg.ultimo_id or 0) if reg else 0] + [i for i in (modulos._id_entero(d.get("id")) for d in docs) if i is not None]) + 1
    item = {"id": nuevo, "empleado_id": emp_id, "tipo": tipo, "nombre": nombre, "vence": vence, "archivo": f"doc_{nuevo}.{ext}", "bytes": len(datos), "mime": mime,
            "subido_por": str(getattr(ctx.usuario, "correo", None) or ""), "subido_en": ahora_cr().isoformat(timespec="seconds")}
    carpeta = carpeta_empleado(eid, emp_id)
    destino, parcial = carpeta / item["archivo"], carpeta / (item["archivo"] + ".parcial")
    try:
        carpeta.mkdir(parents=True, exist_ok=True)
        for viejo in carpeta.glob(f"doc_{nuevo}.*"):     # restos con ese número (de un respaldo restaurado): el número es de este documento
            viejo.unlink(missing_ok=True)
        parcial.write_bytes(datos)
        os.replace(parcial, destino)
    except OSError:
        s.rollback()
        log.exception("No se pudo escribir el documento del empleado %s de la empresa %s", emp_id, eid)
        _quitar(parcial)
        raise HTTPException(500, "No se pudo guardar el archivo en el servidor: intente de nuevo en un momento")
    try:
        _, remap = modulos.aplicar_cambios(s, eid, CLAVE, [item], [], [nuevo])
    except Exception:  # noqa: BLE001  sin sus datos guardados el archivo no se queda
        s.rollback()
        _quitar(destino)
        log.exception("No se pudieron guardar los datos del documento del empleado %s de la empresa %s", emp_id, eid)
        raise HTTPException(409, "No se pudo guardar por cambios simultáneos; intente de nuevo")
    if remap:                                            # no debería pasar (el número se tomó con el candado puesto): se deshace
        modulos.aplicar_cambios(s, eid, CLAVE, [], list(remap.values()), [])
        _quitar(destino)
        raise HTTPException(409, "No se pudo guardar por cambios simultáneos; intente de nuevo")
    auditar(ctx, "rrhh_documento_subido", _detalle(item, emp))
    return item


def _quitar(ruta: Path) -> None:
    try:
        ruta.unlink(missing_ok=True)
    except OSError:
        log.warning("No se pudo borrar %s", ruta)


@router.get("/api/rrhh/documentos/{doc_id}", include_in_schema=False)
def descargar_documento(doc_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """El archivo de un documento de la empresa activa. Queda en el historial de operaciones quién lo abrió."""
    auditar, _candado, guardados = _ayudas()
    eid = ctx.empresa.id
    d = guardados(s, eid, CLAVE, [doc_id]).get(doc_id)
    ruta = _ruta(eid, d) if isinstance(d, dict) else None
    if ruta is None:
        raise HTTPException(404, "El documento ya no existe: recargue la página")
    if not ruta.is_file():
        raise HTTPException(404, "El archivo de este documento no está en el servidor: elimínelo de la lista y súbalo de nuevo")
    emp_id = modulos._id_entero(d.get("empleado_id"))
    auditar(ctx, "rrhh_documento_descargado", _detalle(d, guardados(s, eid, "empleados", [emp_id]).get(emp_id)))
    return FileResponse(ruta, media_type=MIME[ruta.suffix[1:]], filename=nombre_descarga(d))


class DocumentoIn(BaseModel):
    tipo: Optional[str] = None
    nombre: Optional[str] = None
    vence: Optional[str] = None


@router.put("/api/rrhh/documentos/{doc_id}")
def cambiar_documento(doc_id: int, data: DocumentoIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Cambia el tipo, el nombre o el vencimiento de un documento (lo que venga); el archivo y lo demás no se tocan."""
    auditar, candado, guardados = _ayudas()
    eid = ctx.empresa.id
    candado(s, eid, CLAVE)
    d = guardados(s, eid, CLAVE, [doc_id]).get(doc_id)
    if not isinstance(d, dict):
        s.rollback()
        raise HTTPException(404, "El documento ya no existe: recargue la página")
    try:
        tipo, nombre, vence = validar_datos(d.get("tipo") if data.tipo is None else data.tipo, d.get("nombre") if data.nombre is None else data.nombre,
                                            d.get("vence") if data.vence is None else data.vence)
    except ValueError as ex:
        s.rollback()
        raise _http(ex)
    nuevo = {**d, "tipo": tipo, "nombre": nombre, "vence": vence}
    if nuevo == d:
        s.rollback()
        return d
    modulos.aplicar_cambios(s, eid, CLAVE, [nuevo], [], [])
    emp_id = modulos._id_entero(d.get("empleado_id"))
    auditar(ctx, "rrhh_documento_cambiado", _detalle(nuevo, guardados(s, eid, "empleados", [emp_id]).get(emp_id)))
    return nuevo


@router.delete("/api/rrhh/documentos/{doc_id}")
def eliminar_documento(doc_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Elimina un documento: primero sus datos y después el archivo (si el archivo no se deja borrar, ya nadie llega a él)."""
    auditar, _candado, guardados = _ayudas()
    eid = ctx.empresa.id
    d = guardados(s, eid, CLAVE, [doc_id]).get(doc_id)
    if not isinstance(d, dict):
        raise HTTPException(404, "El documento ya no existe: recargue la página")
    emp_id = modulos._id_entero(d.get("empleado_id"))
    emp = guardados(s, eid, "empleados", [emp_id]).get(emp_id)
    modulos.aplicar_cambios(s, eid, CLAVE, [], [doc_id], [])
    ruta = _ruta(eid, d)
    if ruta is not None:
        _quitar(ruta)
    auditar(ctx, "rrhh_documento_eliminado", _detalle(d, emp))
    return {"ok": True}


def borrar_de_empleados(s: Session, eid: int, ids) -> int:
    """Quita los documentos (datos y archivos) de esos empleados, que ya no existen. Devuelve cuántos documentos se fueron."""
    ids = {i for i in (modulos._id_entero(x) for x in ids) if i is not None}
    if not ids:
        return 0
    mios = [modulos._id_entero(d.get("id")) for d in _docs(s, eid) if modulos._id_entero(d.get("empleado_id")) in ids]
    if mios:
        modulos.aplicar_cambios(s, eid, CLAVE, [], mios, [])
    for emp_id in ids:
        shutil.rmtree(carpeta_empleado(eid, emp_id), ignore_errors=True)
    return len(mios)


def borrar_todos(s: Session, eid: int) -> int:
    """Quita todos los documentos de empleados de la empresa (se borra la lista completa de empleados). Devuelve cuántos había.
    Los datos se quitan elemento por elemento, como en borrar_de_empleados, y la fila del registro SE QUEDA: guarda el mayor número
    que tuvo un documento (ultimo_id). Antes se borraba también esa fila y los números volvían a empezar en 1: el documento nuevo de
    otra persona recibía un número ya dado (y una pestaña vieja abría con ese número el documento equivocado)."""
    ids = [i for i in (modulos._id_entero(d.get("id")) for d in _docs(s, eid)) if i is not None]
    if ids:
        modulos.aplicar_cambios(s, eid, CLAVE, [], ids, [])
    shutil.rmtree(carpeta_empresa(eid), ignore_errors=True)
    return len(ids)
