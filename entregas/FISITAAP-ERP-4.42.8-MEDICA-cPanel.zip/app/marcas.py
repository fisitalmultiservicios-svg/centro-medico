"""Marcas de una empresa (3.45): una misma cédula factura con varios nombres comerciales y logos (p. ej. IT Core Sync factura como
FISITAAP by Brillante Agencia o como Brillante Agencia). La marca cambia lo que ve el cliente: logo y nombre comercial en el PDF, el tiquete, el
correo y la página de consulta, y el NombreComercial del XML. El emisor legal (nombre, cédula, actividad, ubicación) es siempre el
de la empresa. Sin marcas, o con «marca_id» vacío, todo sigue con el logo y el nombre comercial de la empresa."""
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field as PField
from sqlalchemy import func
from sqlmodel import Field, Session, SQLModel, select

from .auth import Contexto, contexto, requiere, sesion_empresa
from .config import DATA_DIR
from .db import Empresa, por_empresa

router = APIRouter(tags=["marcas"])
MAX_LOGO = 2 * 1024 * 1024
MAX_MARCAS = 20


class Marca(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str                                  # nombre comercial de la marca (va al PDF, al correo y al NombreComercial del XML)
    logo_nombre: Optional[str] = None            # data/logos/empresa_<eid>_marca_<id>.<ext>
    sitio_web: Optional[str] = None
    correo: Optional[str] = None
    telefono: Optional[int] = None
    predeterminada: bool = False                 # la que viene puesta en documentos nuevos (una por empresa)
    activa: bool = True
    creada: str = Field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))


por_empresa(Marca)
LOGOS_DIR = DATA_DIR / "logos"


def marca_de(s: Session, eid: int, marca_id) -> Optional[Marca]:
    """La marca indicada si existe y es de la empresa; None = usar los datos de la empresa."""
    if not marca_id:
        return None
    m = s.get(Marca, int(marca_id))
    return m if m and m.empresa_id == eid else None


def predeterminada(s: Session, eid: int) -> Optional[Marca]:
    return s.exec(select(Marca).where(Marca.empresa_id == eid, Marca.activa == True, Marca.predeterminada == True)).first()  # noqa: E712


def logo_de(e: Empresa, m: Optional[Marca]) -> Optional[Path]:
    """Logo a imprimir: el de la marca si lo tiene; si no, el de la empresa."""
    from .fe import pdf
    if m is not None and m.logo_nombre and (LOGOS_DIR / m.logo_nombre).exists():
        return LOGOS_DIR / m.logo_nombre
    return pdf.logo_empresa(e)


def nombre_de(e: Empresa, m: Optional[Marca]) -> str:
    return (m.nombre if m is not None else None) or e.nombre_comercial or e.nombre or ""


def contacto_de(e: Empresa, m: Optional[Marca]) -> dict:
    """Contacto que se imprime: el de la marca cuando lo tiene, si no el de la empresa."""
    if m is None:
        return {"sitio_web": e.sitio_web or "", "correo": e.correo or "", "telefono": e.telefono}
    return {"sitio_web": m.sitio_web or e.sitio_web or "", "correo": m.correo or e.correo or "", "telefono": m.telefono or e.telefono}


def validar_marca(s: Session, eid: int, marca_id, para: str = "el comprobante") -> Optional[Marca]:
    if not marca_id:
        return None
    m = marca_de(s, eid, marca_id)
    if m is None:
        raise HTTPException(400, f"La marca indicada para {para} no existe")
    if not m.activa:
        raise HTTPException(400, f"La marca «{m.nombre}» está inactiva: actívela en Configuración › Marcas o elija otra")
    return m


# ------------------------------------------------------------------------------------------------- API
class MarcaIn(BaseModel):
    nombre: str = PField(min_length=3, max_length=80)
    sitio_web: Optional[str] = PField(None, max_length=120)
    correo: Optional[str] = PField(None, max_length=120)
    telefono: Optional[int] = None
    predeterminada: bool = False
    activa: bool = True


def _limpiar(data: MarcaIn) -> dict:
    from .main import telefono_valido, _validar_texto_hacienda
    d = data.model_dump()
    d["nombre"] = " ".join(d["nombre"].split())
    _validar_texto_hacienda(d["nombre"], "El nombre de la marca", 3, 80)
    d["sitio_web"] = (d.get("sitio_web") or "").strip() or None
    d["correo"] = (d.get("correo") or "").strip().lower() or None
    if d["correo"] and not re.fullmatch(r"[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}", d["correo"]):
        raise HTTPException(400, "Revise el correo de la marca")
    if d.get("telefono") is not None and not telefono_valido(d["telefono"]):
        raise HTTPException(400, "El teléfono de la marca debe tener 8 dígitos (o ser un número especial de 3)")
    return d


def _salida(m: Marca) -> dict:
    return m.model_dump() | {"logo": f"/api/marcas/{m.id}/logo?v={abs(hash(m.logo_nombre or ''))}" if m.logo_nombre else None}


@router.get("/api/marcas")
def listar(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    return [_salida(m) for m in s.exec(select(Marca).where(Marca.empresa_id == ctx.empresa.id).order_by(Marca.predeterminada.desc(), Marca.nombre)).all()]


@router.post("/api/marcas")
def crear(data: MarcaIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    if len(s.exec(select(Marca).where(Marca.empresa_id == eid)).all()) >= MAX_MARCAS:
        raise HTTPException(400, f"Máximo {MAX_MARCAS} marcas por empresa")
    d = _limpiar(data)
    if s.exec(select(Marca).where(Marca.empresa_id == eid, func.lower(Marca.nombre) == d["nombre"].lower())).first():
        raise HTTPException(400, f"Ya existe la marca «{d['nombre']}»")
    m = Marca(empresa_id=eid, **d)
    if m.predeterminada:
        for o in s.exec(select(Marca).where(Marca.empresa_id == eid, Marca.predeterminada == True)).all():  # noqa: E712
            o.predeterminada = False; s.add(o)
    s.add(m); s.commit(); s.refresh(m)
    return _salida(m)


@router.put("/api/marcas/{mid}")
def editar(mid: int, data: MarcaIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    m = marca_de(s, ctx.empresa.id, mid)
    if m is None:
        raise HTTPException(404, "Marca no encontrada")
    d = _limpiar(data)
    if s.exec(select(Marca).where(Marca.empresa_id == ctx.empresa.id, func.lower(Marca.nombre) == d["nombre"].lower(), Marca.id != mid)).first():
        raise HTTPException(400, f"Ya existe la marca «{d['nombre']}»")
    for k, v in d.items():
        setattr(m, k, v)
    if m.predeterminada:
        for o in s.exec(select(Marca).where(Marca.empresa_id == ctx.empresa.id, Marca.predeterminada == True, Marca.id != mid)).all():  # noqa: E712
            o.predeterminada = False; s.add(o)
    s.add(m); s.commit(); s.refresh(m)
    return _salida(m)


@router.delete("/api/marcas/{mid}")
def borrar(mid: int, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    from .db import Documento
    m = marca_de(s, ctx.empresa.id, mid)
    if m is None:
        raise HTTPException(404, "Marca no encontrada")
    if s.exec(select(Documento).where(Documento.empresa_id == ctx.empresa.id, Documento.marca_id == mid)).first():
        m.activa = False; m.predeterminada = False; s.add(m); s.commit()
        return {"ok": True, "desactivada": True, "mensaje": "La marca tiene comprobantes emitidos: se desactivó en vez de borrarse"}
    if m.logo_nombre:
        try:
            (LOGOS_DIR / m.logo_nombre).unlink(missing_ok=True)
        except OSError:
            pass
    from .sucursales import Sucursal                                  # 3.82: sus sucursales vuelven a la predeterminada
    for x in s.exec(select(Sucursal).where(Sucursal.empresa_id == ctx.empresa.id, Sucursal.marca_id == mid)).all():
        x.marca_id = None; s.add(x)
    s.delete(m); s.commit()
    return {"ok": True}


@router.post("/api/marcas/{mid}/logo")
def subir_logo(mid: int, archivo: UploadFile = File(...), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    m = marca_de(s, ctx.empresa.id, mid)
    if m is None:
        raise HTTPException(404, "Marca no encontrada")
    ext = (archivo.filename or "logo.png").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg"):
        raise HTTPException(400, "El logo debe ser PNG o JPG")
    datos = archivo.file.read(MAX_LOGO + 1)
    if len(datos) > MAX_LOGO:
        raise HTTPException(400, "El logo no puede pasar de 2 MB")
    if not (datos.startswith(b"\x89PNG") or datos.startswith(b"\xff\xd8")):
        raise HTTPException(400, "El archivo no es una imagen PNG o JPG válida")
    LOGOS_DIR.mkdir(exist_ok=True)
    if m.logo_nombre and m.logo_nombre != f"empresa_{ctx.empresa.id}_marca_{m.id}.{ext}":
        try:
            (LOGOS_DIR / m.logo_nombre).unlink(missing_ok=True)
        except OSError:
            pass
    m.logo_nombre = f"empresa_{ctx.empresa.id}_marca_{m.id}.{ext}"
    (LOGOS_DIR / m.logo_nombre).write_bytes(datos)
    s.add(m); s.commit()
    return {"ok": True, "logo": f"/api/marcas/{m.id}/logo?v={int(datetime.now().timestamp())}"}


@router.delete("/api/marcas/{mid}/logo")
def quitar_logo(mid: int, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    m = marca_de(s, ctx.empresa.id, mid)
    if m is None:
        raise HTTPException(404, "Marca no encontrada")
    if m.logo_nombre:
        try:
            (LOGOS_DIR / m.logo_nombre).unlink(missing_ok=True)
        except OSError:
            pass
        m.logo_nombre = None; s.add(m); s.commit()
    return {"ok": True}


@router.get("/api/marcas/{mid}/logo")
def ver_logo(mid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    m = marca_de(s, ctx.empresa.id, mid)
    if m is None or not m.logo_nombre or not (LOGOS_DIR / m.logo_nombre).exists():
        raise HTTPException(404, "Sin logo")
    return FileResponse(LOGOS_DIR / m.logo_nombre, headers={"Cache-Control": "no-store"})
