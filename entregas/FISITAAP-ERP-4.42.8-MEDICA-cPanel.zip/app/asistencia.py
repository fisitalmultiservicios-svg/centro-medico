"""Marcas de asistencia de los empleados (3.46, traído de FISITAAP a Recursos humanos).

Un empleado marca Entrada, Pausa, Regreso o Salida desde el quiosco (/marcar.html en la caja, una tableta o cualquier equipo del
negocio) con su código de reloj y una clave personal distinta de la contraseña del sistema; no necesita usuario. El servidor
pone la hora, el equipo, el origen y quién registró; propone la siguiente marca y no deja marcar fuera de orden; limita los
intentos (5 fallidos = 5 minutos de bloqueo) y protege contra el doble envío con una clave de petición. Un supervisor corrige
una marca con motivo obligatorio: la original no se borra, queda marcada como corregida con bitácora. El resumen cruza las
marcas con el horario planificado (3.43) y calcula horas trabajadas, tardías, extra sugerida, ausencias y días incompletos.

Las marcas del reloj marcador (ZKTeco por archivo) y de UniFi Access entrarán a esta MISMA tabla con su `origen`: conviven
como opciones, no se sustituyen."""
import secrets
import uuid
from datetime import datetime, timedelta
from typing import Optional

from fastapi import File, Form, UploadFile, APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from . import modulos
from .auth import Contexto, abrir, contexto, firmar, hash_password, limitar_ip, requiere, sesion_empresa, verificar_password
from .config import ahora_cr
from .db import Empresa, get_session, por_empresa, sesion_de

router = APIRouter(tags=["asistencia"])
TIPOS = ("entrada", "pausa", "regreso", "salida")
NOMBRES = {"entrada": "Entrada", "pausa": "Pausa", "regreso": "Regreso", "salida": "Salida"}
ORIGENES = ("quiosco", "manual", "correccion", "reloj", "unifi", "sistema")   # 4.7: «sistema» = ícono ⏱ de la barra (3.94)
MAX_INTENTOS, BLOQUEO_MIN = 5, 5
MAX_TURNO_HORAS, TOPE_TURNO = 16, (12, 36)          # 4.7: horas máximas de un turno por defecto y rango permitido (turnos de noche)
DESCANSO_MIN_HORAS, TOPE_DESCANSO = 13, (6, 48)     # 4.7: reloj sin tipo de marca: un hueco de estas horas o más separa dos turnos (por defecto y rango)
DURACION_QUIOSCO = 365 * 24 * 3600
MAX_QUIOSCOS = 50                                   # 4.42: quioscos activos a la vez por empresa (el tope de siempre de la lista de nombres)
QUIOSCO_DESACTIVADO = "Este quiosco fue desactivado. Actívelo de nuevo desde Recursos humanos › Marcas."


class MarcaEmpleado(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    empleado_id: int = Field(index=True)
    tipo: str                                   # entrada | pausa | regreso | salida
    fecha_hora: str = Field(index=True)         # hora del servidor (Costa Rica), ISO con zona
    fecha: str = Field(index=True)              # AAAA-MM-DD (para agrupar por día)
    origen: str = "quiosco"                     # quiosco | manual | correccion | reloj | unifi
    equipo: Optional[str] = None                # nombre del quiosco o del reloj
    registrado_por: Optional[str] = None        # «quiosco» o el correo del usuario que la anotó o corrigió
    clave_peticion: Optional[str] = Field(default=None, index=True)   # idempotencia: el mismo envío dos veces no duplica
    nota: Optional[str] = None
    corregida: bool = False                     # True = fue reemplazada (o anulada) por una corrección; no se borra
    corregida_por: Optional[str] = None
    motivo: Optional[str] = None                # motivo de la corrección o de la marca manual
    original_id: Optional[int] = None           # en una corrección, la marca a la que reemplaza
    creada: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class ClaveMarca(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    empleado_id: int = Field(index=True)
    clave_hash: str
    intentos: int = 0
    bloqueado_hasta: Optional[str] = None
    actualizada: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class AsistenciaConfig(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    serie: str = Field(default_factory=lambda: secrets.token_urlsafe(12))   # cambia al «desactivar todos los quioscos»
    equipos: str = ""                           # nombres de quioscos activados, separados por |
    tolerancia_min: int = 10                    # minutos de gracia antes de contar una entrada como tardía
    max_turno_horas: int = MAX_TURNO_HORAS      # 4.7: una salida (aun de madrugada) dentro de estas horas desde la entrada cierra ese turno
    descanso_min_horas: int = DESCANSO_MIN_HORAS  # 4.7: reloj sin tipo: un hueco de estas horas o más entre dos marcas empieza otro turno


class QuioscoEquipo(SQLModel, table=True):
    """4.42: cada activación de un quiosco de marcas, con su identificador (qid), que va dentro del enlace firmado de ese equipo.
    Desactivar un equipo pone la fecha en `desactivado`: la fila no se borra, queda como constancia, y ese enlace deja de servir.
    Los enlaces de antes de la 4.42 no traen qid: valen hasta «Desactivar todos» (cambia la serie)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    qid: str = Field(index=True)                # al azar, uno por activación; solo vale junto con la firma del enlace
    nombre: str                                 # Caja 1, Tableta cocina…
    activado: str                               # hora del servidor (Costa Rica), ISO con zona
    activado_por: Optional[str] = None          # correo de quien lo activó
    desactivado: Optional[str] = None           # vacío = activo
    desactivado_por: Optional[str] = None


por_empresa(MarcaEmpleado, ClaveMarca, AsistenciaConfig, QuioscoEquipo)


# ------------------------------------------------------------------------------------------------- utilidades
def _config(s: Session, eid: int) -> AsistenciaConfig:
    c = s.exec(select(AsistenciaConfig).where(AsistenciaConfig.empresa_id == eid)).first()
    if not c:
        c = AsistenciaConfig(empresa_id=eid); s.add(c); s.commit(); s.refresh(c)
    return c


def _empleados(s: Session, eid: int) -> list:
    return [e for e in (modulos.leer(s, eid, "empleados", []) or []) if isinstance(e, dict) and e.get("id") is not None]


def _nombre(e: dict) -> str:
    return " ".join(x for x in (e.get("nombre"), e.get("apellidos")) if x).strip() or f"Empleado {e.get('id')}"


def _por_codigo(s: Session, eid: int, codigo: str) -> Optional[dict]:
    c = str(codigo or "").strip()
    if not c.isdigit() or int(c) == 0:
        return None
    c = c.zfill(4)
    for e in _empleados(s, eid):
        if e.get("activo", True) is not False and str(e.get("codigo_reloj") or "").strip().zfill(4) == c and str(e.get("codigo_reloj") or "").strip():
            return e
    return None


def _ultima(s: Session, eid: int, emp_id: int) -> Optional[MarcaEmpleado]:
    return s.exec(select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == eid, MarcaEmpleado.empleado_id == emp_id, MarcaEmpleado.corregida == False)  # noqa: E712
                  .order_by(MarcaEmpleado.fecha_hora.desc(), MarcaEmpleado.id.desc())).first()


def _momento(v) -> Optional[datetime]:
    """4.7: datetime con zona de una marca (texto ISO o datetime); None si no se entiende."""
    try:
        d = v if isinstance(v, datetime) else datetime.fromisoformat(str(v))
    except (TypeError, ValueError):
        return None
    return d if d.tzinfo is not None else d.replace(tzinfo=ahora_cr().tzinfo)


def _tope(c) -> float:
    """4.7: horas máximas de un turno de la empresa (AsistenciaConfig.max_turno_horas); fuera del rango, las de siempre."""
    try:
        v = float(getattr(c, "max_turno_horas", None) or MAX_TURNO_HORAS)
    except (TypeError, ValueError):
        v = float(MAX_TURNO_HORAS)
    return v if TOPE_TURNO[0] <= v <= TOPE_TURNO[1] else float(MAX_TURNO_HORAS)


def _descanso(c) -> float:
    """4.7: horas de descanso mínimo entre dos turnos (AsistenciaConfig.descanso_min_horas) para leer un reloj sin tipo de marca;
    fuera del rango, las de siempre."""
    try:
        v = float(getattr(c, "descanso_min_horas", None) or DESCANSO_MIN_HORAS)
    except (TypeError, ValueError):
        v = float(DESCANSO_MIN_HORAS)
    return v if TOPE_DESCANSO[0] <= v <= TOPE_DESCANSO[1] else float(DESCANSO_MIN_HORAS)


def inicio_turno(recientes: list):
    """4.7: la Entrada del turno al que pertenece la marca más reciente (`recientes`: de la más nueva a la más vieja). None si
    antes de llegar a una Entrada aparece la Salida de un turno anterior (marcas sueltas) o si no hay Entrada en la lista."""
    for i, m in enumerate(recientes):
        if m.tipo == "entrada":
            return m
        if m.tipo == "salida" and i > 0:
            return None
    return None


def _contexto_marca(s: Session, eid: int, emp_id: int) -> tuple:
    """4.7: (última marca vigente del empleado, Entrada del turno al que pertenece); mira sus últimas 30 marcas."""
    recientes = s.exec(select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == eid, MarcaEmpleado.empleado_id == emp_id, MarcaEmpleado.corregida == False)  # noqa: E712
                       .order_by(MarcaEmpleado.fecha_hora.desc(), MarcaEmpleado.id.desc()).limit(30)).all()
    return (recientes[0] if recientes else None), inicio_turno(recientes)


def permitidas(ultima: Optional[MarcaEmpleado], hoy: str, ahora: Optional[datetime] = None, max_horas: float = MAX_TURNO_HORAS, entrada=None) -> list:
    """Qué marcas puede hacer ahora: entrada → pausa o salida → regreso → pausa o salida.
    4.7: con `ahora`, el turno abierto sigue aunque haya pasado la medianoche (turno de noche) mientras no pasen `max_horas` desde
    su Entrada (`entrada`; sin ella se mide desde la última marca): a las 06:00 se marca la Salida del turno que empezó a las
    22:00. Si la última marca es de otro día, primero se ofrece seguir ese turno y además Entrada (para quien olvidó la salida:
    ese turno queda incompleto). Pasado el tope, solo Entrada (turno nuevo). El tope solo cuenta después de la medianoche: un
    turno que empezó hoy sigue abierto todo el día, como en la 4.6, aunque pase de `max_horas` (jornada larga con horas extra).
    Sin `ahora` manda el día del calendario (como antes)."""
    if ultima is None or ultima.tipo == "salida":
        return ["entrada"]
    sigue = ["pausa", "salida"] if ultima.tipo in ("entrada", "regreso") else ["regreso"]     # en pausa: regreso
    if ahora is None:
        return sigue if ultima.fecha == hoy else ["entrada"]
    ref = entrada if entrada is not None else ultima
    if (getattr(ref, "fecha", None) or str(ref.fecha_hora)[:10]) == hoy:
        return sigue                                        # el turno empezó hoy: el tope no lo corta el mismo día
    inicio = _momento(ref.fecha_hora)
    if inicio is None or (ahora - inicio).total_seconds() > float(max_horas or MAX_TURNO_HORAS) * 3600:
        return ["entrada"]                                  # pasó el tope después de medianoche: turno nuevo; el anterior queda incompleto
    if ultima.fecha == hoy:
        return sigue
    return (["salida", "pausa"] if ultima.tipo in ("entrada", "regreso") else ["regreso"]) + ["entrada"]


def _salida(m: MarcaEmpleado, nombre: str = "") -> dict:
    return {"id": m.id, "empleado_id": m.empleado_id, "empleado": nombre, "tipo": m.tipo, "tipo_nombre": NOMBRES.get(m.tipo, m.tipo), "fecha_hora": m.fecha_hora, "fecha": m.fecha,
            "hora": m.fecha_hora[11:16], "origen": m.origen, "equipo": m.equipo, "registrado_por": m.registrado_por, "nota": m.nota, "corregida": m.corregida,
            "corregida_por": m.corregida_por, "motivo": m.motivo, "original_id": m.original_id}


def _estado(s: Session, eid: int, e: dict) -> dict:
    ahora = ahora_cr(); hoy = ahora.date().isoformat(); tope = _tope(_config(s, eid))
    u, ent = _contexto_marca(s, eid, e["id"])
    p = permitidas(u, hoy, ahora, tope, ent)
    q = select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == eid, MarcaEmpleado.empleado_id == e["id"], MarcaEmpleado.corregida == False)  # noqa: E712
    t0 = _momento(ent.fecha_hora) if ent is not None else None
    noche = (t0 is not None and ent.fecha < hoy and (ahora - t0).total_seconds() <= tope * 3600     # 4.7: turno de noche: sus marcas desde la entrada,
             and u is not None and (u.tipo != "salida" or u.fecha == hoy))                        # solo si sigue abierto o cerró hoy (no el de ayer ya cerrado)
    de_hoy = s.exec((q.where(MarcaEmpleado.fecha_hora >= ent.fecha_hora) if noche else q.where(MarcaEmpleado.fecha == hoy)).order_by(MarcaEmpleado.fecha_hora)).all()
    abierto = bool(u and u.tipo != "salida" and p != ["entrada"])
    return {"empleado_id": e["id"], "nombre": _nombre(e), "ultima": _salida(u) if u else None, "ultima_sin_salida": bool(u and u.tipo != "salida" and p == ["entrada"]),
            "turno_desde": ent.fecha_hora if abierto and ent is not None else None,
            "permitidas": [{"tipo": t, "nombre": NOMBRES[t]} for t in p], "siguiente": p[0], "hoy": [_salida(m) for m in de_hoy], "ahora": ahora.isoformat(timespec="seconds")}


# ------------------------------------------------------------------------------------------------- quiosco (sin usuario)
class QuioscoIn(BaseModel):
    nombre: str = PField(min_length=2, max_length=40)


class MarcarIn(BaseModel):
    codigo: str = PField(min_length=1, max_length=4)
    clave: str = PField(min_length=4, max_length=8)
    tipo: Optional[str] = None                  # vacío = la siguiente propuesta
    clave_peticion: Optional[str] = PField(None, max_length=60)


class CambioClaveIn(BaseModel):
    codigo: str = PField(min_length=1, max_length=4)
    clave: str = PField(min_length=4, max_length=8)
    nueva: str = PField(min_length=4, max_length=8)


def _quiosco(request: Request, x_quiosco: str | None, sc: Session) -> tuple[Empresa, dict]:
    """Empresa y datos del quiosco a partir del token (encabezado X-Quiosco). Sin sesión de usuario."""
    datos = abrir(x_quiosco or "")
    if not datos or datos.get("tipo") != "quiosco":
        raise HTTPException(401, "Este equipo no está activado como quiosco de marcas. Actívelo desde Recursos humanos › Marcas.")
    e = sc.get(Empresa, int(datos.get("eid") or 0))
    if not e:
        raise HTTPException(401, "El quiosco apunta a una empresa que ya no existe")
    if e.bloqueada:
        raise HTTPException(403, "El acceso de esta empresa está bloqueado")
    from . import planes
    if "rrhh" not in planes.modulos_de(e):
        raise HTTPException(403, "El plan de la empresa no incluye Recursos humanos")
    with sesion_de(e.id) as s:
        if _config(s, e.id).serie != datos.get("serie"):
            raise HTTPException(401, QUIOSCO_DESACTIVADO)
        if "qid" in datos:          # 4.42: enlace con identificador: su equipo tiene que seguir activo en la lista. Los de antes (sin qid) valen hasta «Desactivar todos»
            filas = s.exec(select(QuioscoEquipo).where(QuioscoEquipo.empresa_id == e.id, QuioscoEquipo.qid == str(datos.get("qid") or ""))).all()
            if not filas or any(q.desactivado for q in filas):
                raise HTTPException(401, QUIOSCO_DESACTIVADO)
    return e, datos


def _validar_clave(s: Session, eid: int, e: dict, clave: str, request: Request) -> ClaveMarca:
    limitar_ip(request, clave="quiosco", maximo=25, ventana=300, sujeto=f"quiosco:{eid}:{e['id']}", mensaje="Demasiados intentos. Espere cinco minutos e intente de nuevo.")
    k = s.exec(select(ClaveMarca).where(ClaveMarca.empresa_id == eid, ClaveMarca.empleado_id == e["id"])).first()
    if not k:
        raise HTTPException(400, "Este empleado todavía no tiene clave para marcar: pídala en Recursos humanos")
    ahora = ahora_cr()
    if k.bloqueado_hasta and k.bloqueado_hasta > ahora.isoformat(timespec="seconds"):
        raise HTTPException(429, f"Clave bloqueada por intentos fallidos. Intente después de las {k.bloqueado_hasta[11:16]}")
    if not verificar_password(clave, k.clave_hash):
        k.intentos += 1
        if k.intentos >= MAX_INTENTOS:
            k.intentos = 0; k.bloqueado_hasta = (ahora + timedelta(minutes=BLOQUEO_MIN)).isoformat(timespec="seconds")
            s.add(k); s.commit()
            raise HTTPException(429, f"Clave incorrecta {MAX_INTENTOS} veces: bloqueada {BLOQUEO_MIN} minutos")
        s.add(k); s.commit()
        raise HTTPException(401, "Código o clave incorrectos")
    if k.intentos or k.bloqueado_hasta:
        k.intentos = 0; k.bloqueado_hasta = None; s.add(k); s.commit()
    return k


@router.get("/api/asistencia/quiosco/estado")
def quiosco_estado(request: Request, x_quiosco: str | None = Header(default=None), sc: Session = Depends(get_session)):
    e, datos = _quiosco(request, x_quiosco, sc)
    with sesion_de(e.id) as s:                           # 4.7: horas máximas de un turno, para el aviso del turno de noche en el quiosco
        tope = int(_tope(_config(s, e.id)))
    return {"empresa": e.nombre_comercial or e.nombre, "equipo": datos.get("equipo"), "ahora": ahora_cr().isoformat(timespec="seconds"), "max_turno_horas": tope}


@router.post("/api/asistencia/quien")
def quiosco_quien(data: MarcarIn, request: Request, x_quiosco: str | None = Header(default=None), sc: Session = Depends(get_session)):
    """Código y clave → nombre, última marca y las marcas permitidas ahora (no registra nada)."""
    e, _ = _quiosco(request, x_quiosco, sc)
    with sesion_de(e.id) as s:
        emp = _por_codigo(s, e.id, data.codigo)
        if not emp:
            limitar_ip(request, clave="quiosco", maximo=25, ventana=300, sujeto=f"quiosco:{e.id}:cod:{data.codigo}", mensaje="Demasiados intentos. Espere cinco minutos e intente de nuevo.")
            raise HTTPException(401, "Código o clave incorrectos")
        _validar_clave(s, e.id, emp, data.clave, request)
        return _estado(s, e.id, emp)


@router.post("/api/asistencia/marcar")
def quiosco_marcar(data: MarcarIn, request: Request, x_quiosco: str | None = Header(default=None), sc: Session = Depends(get_session)):
    e, datos = _quiosco(request, x_quiosco, sc)
    with sesion_de(e.id) as s:
        emp = _por_codigo(s, e.id, data.codigo)
        if not emp:
            limitar_ip(request, clave="quiosco", maximo=25, ventana=300, sujeto=f"quiosco:{e.id}:cod:{data.codigo}", mensaje="Demasiados intentos. Espere cinco minutos e intente de nuevo.")
            raise HTTPException(401, "Código o clave incorrectos")
        _validar_clave(s, e.id, emp, data.clave, request)
        if data.clave_peticion:                                   # doble envío: se devuelve la misma marca
            previa = s.exec(select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == e.id, MarcaEmpleado.clave_peticion == data.clave_peticion)).first()
            if previa:
                return {"marca": _salida(previa, _nombre(emp)), "repetida": True, **_estado(s, e.id, emp)}
        ahora = ahora_cr(); hoy = ahora.date().isoformat()
        u, ent = _contexto_marca(s, e.id, emp["id"])
        p = permitidas(u, hoy, ahora, _tope(_config(s, e.id)), ent)          # 4.7: el turno de noche sigue después de medianoche
        tipo = (data.tipo or p[0]).strip().lower()
        if tipo not in TIPOS:
            raise HTTPException(400, "Tipo de marca desconocido")
        if tipo not in p:
            raise HTTPException(400, f"Ahora corresponde {' o '.join(NOMBRES[t] for t in p)}, no {NOMBRES[tipo]}")
        m = MarcaEmpleado(empresa_id=e.id, empleado_id=emp["id"], tipo=tipo, fecha_hora=ahora.isoformat(timespec="seconds"), fecha=hoy, origen="quiosco",
                          equipo=str(datos.get("equipo") or "")[:40] or None, registrado_por="quiosco", clave_peticion=data.clave_peticion or str(uuid.uuid4()))
        s.add(m); s.commit(); s.refresh(m)
        return {"marca": _salida(m, _nombre(emp)), "repetida": False, **_estado(s, e.id, emp)}


@router.post("/api/asistencia/sistema/marcar")
def sistema_marcar(data: MarcarIn, request: Request, ctx: Contexto = Depends(contexto)):
    """3.94: ícono ⏱ de la barra del sistema: con la sesión abierta en la empresa (p. ej. la computadora de la caja), un empleado elige
    su marca y la confirma con su código de reloj y su PIN. Las mismas reglas del quiosco (bloqueo por intentos, marcas permitidas,
    doble envío); queda anotado quién tenía la sesión abierta. Los errores de clave salen como 400 (un 401 cerraría esa sesión)."""
    from . import planes
    e = ctx.empresa
    if e is None:
        raise HTTPException(400, "Elija una empresa")
    if "rrhh" not in planes.modulos_de(e):
        raise HTTPException(403, "La marca de asistencia es parte de Recursos humanos, que no está incluido en el plan de la empresa")
    correo = str(getattr(ctx.usuario, "correo", "") or "")
    try:
        with sesion_de(e.id) as s:
            emp = _por_codigo(s, e.id, data.codigo)
            if not emp:
                limitar_ip(request, clave="quiosco", maximo=25, ventana=300, sujeto=f"sistema:{e.id}:cod:{data.codigo}", mensaje="Demasiados intentos. Espere cinco minutos e intente de nuevo.")
                raise HTTPException(401, "Código o PIN incorrectos")
            _validar_clave(s, e.id, emp, data.clave, request)
            if data.clave_peticion:
                previa = s.exec(select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == e.id, MarcaEmpleado.clave_peticion == data.clave_peticion)).first()
                if previa:
                    return {"marca": _salida(previa, _nombre(emp)), "repetida": True, **_estado(s, e.id, emp)}
            ahora = ahora_cr(); hoy = ahora.date().isoformat()
            u, ent = _contexto_marca(s, e.id, emp["id"])
            p = permitidas(u, hoy, ahora, _tope(_config(s, e.id)), ent)      # 4.7: la misma regla del quiosco (turno de noche)
            tipo = (data.tipo or p[0]).strip().lower()
            if tipo not in TIPOS:
                raise HTTPException(400, "Tipo de marca desconocido")
            if tipo not in p:
                raise HTTPException(400, f"{_nombre(emp)}: ahora corresponde {' o '.join(NOMBRES[t] for t in p)}, no {NOMBRES[tipo]}")
            m = MarcaEmpleado(empresa_id=e.id, empleado_id=emp["id"], tipo=tipo, fecha_hora=ahora.isoformat(timespec="seconds"), fecha=hoy, origen="sistema",
                              equipo=correo[:40] or None, registrado_por=correo[:60] or "sistema", clave_peticion=data.clave_peticion or str(uuid.uuid4()))
            s.add(m); s.commit(); s.refresh(m)
            return {"marca": _salida(m, _nombre(emp)), "repetida": False, **_estado(s, e.id, emp)}
    except HTTPException as ex:
        if ex.status_code == 401:
            raise HTTPException(400, ex.detail if ex.detail != "Código o clave incorrectos" else "Código o PIN incorrectos")
        raise


@router.post("/api/asistencia/clave/propia")
def quiosco_cambiar_clave(data: CambioClaveIn, request: Request, x_quiosco: str | None = Header(default=None), sc: Session = Depends(get_session)):
    """El empleado cambia su propia clave desde el quiosco (con la actual)."""
    e, _ = _quiosco(request, x_quiosco, sc)
    _clave_valida(data.nueva)
    with sesion_de(e.id) as s:
        emp = _por_codigo(s, e.id, data.codigo)
        if not emp:
            raise HTTPException(401, "Código o clave incorrectos")
        k = _validar_clave(s, e.id, emp, data.clave, request)
        k.clave_hash = hash_password(data.nueva); k.actualizada = ahora_cr().isoformat(timespec="seconds"); s.add(k); s.commit()
        return {"ok": True}


def _clave_valida(clave: str):
    c = str(clave or "")
    if not c.isdigit() or not 4 <= len(c) <= 8:
        raise HTTPException(400, "La clave para marcar debe tener de 4 a 8 dígitos")
    if len(set(c)) == 1 or c in ("1234", "12345", "123456", "4321", "0000"):
        raise HTTPException(400, "Esa clave es demasiado fácil de adivinar; use otra")


# ------------------------------------------------------------------------------------------------- administración (permiso rrhh)
class ClaveIn(BaseModel):
    empleado_id: int
    clave: str = PField(min_length=4, max_length=8)


class MarcaManualIn(BaseModel):
    empleado_id: int
    tipo: str
    fecha_hora: str = PField(min_length=16, max_length=25)     # AAAA-MM-DDTHH:MM
    motivo: str = PField(min_length=3, max_length=200)


class CorreccionIn(BaseModel):
    tipo: Optional[str] = None
    fecha_hora: Optional[str] = PField(None, min_length=16, max_length=25)
    motivo: str = PField(min_length=3, max_length=200)
    anular: bool = False


class ConfigIn(BaseModel):
    tolerancia_min: int = PField(10, ge=0, le=120)
    max_turno_horas: Optional[int] = PField(None, ge=TOPE_TURNO[0], le=TOPE_TURNO[1])   # 4.7: vacío = no se cambia
    descanso_min_horas: Optional[int] = PField(None, ge=TOPE_DESCANSO[0], le=TOPE_DESCANSO[1])   # 4.7: vacío = no se cambia


def _fecha_hora(v: str) -> str:
    try:
        d = datetime.fromisoformat(v)
    except ValueError:
        raise HTTPException(400, "Fecha y hora inválidas")
    if d.tzinfo is None:
        d = d.replace(tzinfo=ahora_cr().tzinfo)
    if d > ahora_cr() + timedelta(minutes=2):
        raise HTTPException(400, "La marca no puede estar en el futuro")
    return d.isoformat(timespec="seconds")


@router.get("/api/asistencia/config")
def config(ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    c = _config(s, ctx.empresa.id)
    claves = {k.empleado_id for k in s.exec(select(ClaveMarca).where(ClaveMarca.empresa_id == ctx.empresa.id)).all()}
    emps = [{"id": e["id"], "nombre": _nombre(e), "codigo_reloj": str(e.get("codigo_reloj") or "").zfill(4) if str(e.get("codigo_reloj") or "").strip() else "", "con_clave": e["id"] in claves, "activo": e.get("activo", True) is not False} for e in _empleados(s, ctx.empresa.id)]
    # 4.42: los quioscos activos, uno por activación, con su fecha (se desactivan uno por uno) y, aparte, los nombres de los activados antes
    # de la 4.42 (sin fecha ni identificador: solo se quitan con «Desactivar todos»). «equipos» sigue siendo la lista de nombres de todos.
    ahora = ahora_cr()
    filas = s.exec(select(QuioscoEquipo).where(QuioscoEquipo.empresa_id == ctx.empresa.id, QuioscoEquipo.desactivado == None)  # noqa: E711
                   .order_by(QuioscoEquipo.activado, QuioscoEquipo.id)).all()
    anteriores = [x for x in c.equipos.split("|") if x]
    quioscos = []
    for q in filas:
        d = _momento(q.activado)
        vence = d + timedelta(seconds=DURACION_QUIOSCO) if d else None
        quioscos.append({"id": q.id, "nombre": q.nombre, "activado": q.activado, "activado_por": q.activado_por,
                         "vence": vence.isoformat(timespec="seconds") if vence else None, "vencido": bool(vence and vence <= ahora)})
    return {"equipos": list(dict.fromkeys(anteriores + [q.nombre for q in filas])), "quioscos": quioscos, "anteriores": anteriores,
            "tolerancia_min": c.tolerancia_min, "max_turno_horas": int(_tope(c)), "descanso_min_horas": int(_descanso(c)), "empleados": emps, "tipos": NOMBRES}


@router.put("/api/asistencia/config")
def config_guardar(data: ConfigIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    c = _config(s, ctx.empresa.id); c.tolerancia_min = data.tolerancia_min
    if data.max_turno_horas is not None:                     # 4.7: tope de horas de un turno (turnos de noche)
        c.max_turno_horas = data.max_turno_horas
    if data.descanso_min_horas is not None:                  # 4.7: hueco que separa dos turnos al leer un reloj sin tipo de marca
        c.descanso_min_horas = data.descanso_min_horas
    s.add(c); s.commit()
    return {"ok": True}


@router.post("/api/asistencia/quiosco")
def quiosco_activar(data: QuioscoIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Token para activar un equipo como quiosco (se guarda en ese navegador). Vale un año, hasta que se desactive ese equipo en la
    lista o hasta «Desactivar todos». 4.42: cada activación es una fila de QuioscoEquipo con su qid, que va dentro del token; activar
    otra vez el mismo nombre da otro qid (el enlace de un equipo desactivado no revive)."""
    eid = ctx.empresa.id
    c = _config(s, eid)
    nombre = " ".join(data.nombre.split())[:40]
    if not nombre:                      # solo espacios: quedaría una fila sin nombre en la lista
        raise HTTPException(400, "Póngale nombre al equipo (Caja 1, Tableta cocina…)")
    ahora = ahora_cr()
    hace_un_anio = (ahora - timedelta(seconds=DURACION_QUIOSCO)).isoformat(timespec="seconds")
    activos = s.exec(select(QuioscoEquipo.id).where(QuioscoEquipo.empresa_id == eid, QuioscoEquipo.desactivado == None,  # noqa: E711
                                                    QuioscoEquipo.activado > hace_un_anio)).all()
    if len(activos) >= MAX_QUIOSCOS:
        raise HTTPException(400, f"Ya hay {MAX_QUIOSCOS} quioscos activos. Desactive en la lista los que ya no use y vuelva a intentarlo.")
    serie = c.serie
    q = QuioscoEquipo(empresa_id=eid, qid=secrets.token_urlsafe(9), nombre=nombre, activado=ahora.isoformat(timespec="seconds"),
                      activado_por=str(getattr(ctx.usuario, "correo", "") or "")[:120] or None)
    s.add(q); s.commit(); s.refresh(q)
    from .main import _auditar
    _auditar(ctx, "rrhh_quiosco_activar", f"Quiosco de marcas «{nombre}» activado")   # con «rrhh_»: en el historial solo lo ve quien tiene Recursos humanos
    return {"token": firmar({"tipo": "quiosco", "eid": eid, "serie": serie, "equipo": nombre, "qid": q.qid}, DURACION_QUIOSCO), "equipo": nombre, "id": q.id}


@router.delete("/api/asistencia/quiosco")
def quiosco_desactivar(ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Desactiva TODOS los quioscos (cambia la serie): los equipos deben activarse de nuevo. Es lo único que apaga los enlaces de
    antes de la 4.42, que no traen identificador. 4.42: además deja cada fila de la lista con su fecha de desactivación."""
    eid = ctx.empresa.id
    c = _config(s, eid)
    anteriores = len([x for x in c.equipos.split("|") if x])
    c.serie = secrets.token_urlsafe(12); c.equipos = ""; s.add(c)
    ahora = ahora_cr().isoformat(timespec="seconds"); por = str(getattr(ctx.usuario, "correo", "") or "")[:120] or None
    activos = s.exec(select(QuioscoEquipo).where(QuioscoEquipo.empresa_id == eid, QuioscoEquipo.desactivado == None)).all()  # noqa: E711
    for q in activos:
        q.desactivado = ahora; q.desactivado_por = por; s.add(q)
    s.commit()
    from .main import _auditar
    _auditar(ctx, "rrhh_quiosco_desactivar_todos", f"Todos los quioscos de marcas desactivados ({len(activos)} de la lista" + (f" y {anteriores} de antes" if anteriores else "") + ")")
    return {"ok": True}


@router.delete("/api/asistencia/quiosco/{quiosco_id}")
def quiosco_quitar(quiosco_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.42: desactiva UN quiosco: su enlace deja de servir y los demás siguen marcando. La fila queda con la fecha y quién lo hizo.
    Repetirlo no da error (ni otra línea en la bitácora). Uno de otra empresa responde igual que uno que no existe."""
    q = s.get(QuioscoEquipo, quiosco_id)
    if not q or q.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Ese quiosco no existe")
    if q.desactivado:
        return {"ok": True, "ya_estaba": True}
    q.desactivado = ahora_cr().isoformat(timespec="seconds"); q.desactivado_por = str(getattr(ctx.usuario, "correo", "") or "")[:120] or None
    nombre, activado = q.nombre, str(q.activado or "")[:16].replace("T", " ")
    s.add(q); s.commit()
    from .main import _auditar
    _auditar(ctx, "rrhh_quiosco_desactivar", f"Quiosco de marcas «{nombre}» (activado el {activado}) desactivado")
    return {"ok": True}


@router.put("/api/asistencia/clave")
def clave_fijar(data: ClaveIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    _clave_valida(data.clave)
    if not any(e["id"] == data.empleado_id for e in _empleados(s, ctx.empresa.id)):
        raise HTTPException(404, "Empleado no encontrado")
    k = s.exec(select(ClaveMarca).where(ClaveMarca.empresa_id == ctx.empresa.id, ClaveMarca.empleado_id == data.empleado_id)).first() or ClaveMarca(empresa_id=ctx.empresa.id, empleado_id=data.empleado_id, clave_hash="")
    k.clave_hash = hash_password(data.clave); k.intentos = 0; k.bloqueado_hasta = None; k.actualizada = ahora_cr().isoformat(timespec="seconds")
    s.add(k); s.commit()
    return {"ok": True}


@router.delete("/api/asistencia/clave/{empleado_id}")
def clave_quitar(empleado_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    k = s.exec(select(ClaveMarca).where(ClaveMarca.empresa_id == ctx.empresa.id, ClaveMarca.empleado_id == empleado_id)).first()
    if k:
        s.delete(k); s.commit()
    return {"ok": True}


@router.get("/api/asistencia/marcas")
def marcas(desde: str, hasta: str, empleado_id: Optional[int] = None, incluir_corregidas: bool = False, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    q = select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == ctx.empresa.id, MarcaEmpleado.fecha >= desde[:10], MarcaEmpleado.fecha <= hasta[:10])
    if empleado_id:
        q = q.where(MarcaEmpleado.empleado_id == empleado_id)
    if not incluir_corregidas:
        q = q.where(MarcaEmpleado.corregida == False)  # noqa: E712
    nombres = {e["id"]: _nombre(e) for e in _empleados(s, ctx.empresa.id)}
    return [_salida(m, nombres.get(m.empleado_id, f"Empleado {m.empleado_id}")) for m in s.exec(q.order_by(MarcaEmpleado.fecha_hora, MarcaEmpleado.id)).all()]


@router.post("/api/asistencia/marcas")
def marca_manual(data: MarcaManualIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Un supervisor anota una marca que el empleado no pudo hacer (motivo obligatorio)."""
    if data.tipo not in TIPOS:
        raise HTTPException(400, "Tipo de marca desconocido")
    emp = next((e for e in _empleados(s, ctx.empresa.id) if e["id"] == data.empleado_id), None)
    if not emp:
        raise HTTPException(404, "Empleado no encontrado")
    fh = _fecha_hora(data.fecha_hora)
    m = MarcaEmpleado(empresa_id=ctx.empresa.id, empleado_id=emp["id"], tipo=data.tipo, fecha_hora=fh, fecha=fh[:10], origen="manual", equipo=None,
                      registrado_por=ctx.usuario.correo, motivo=data.motivo.strip(), clave_peticion=str(uuid.uuid4()))
    s.add(m); s.commit(); s.refresh(m)
    return _salida(m, _nombre(emp))


@router.put("/api/asistencia/marcas/{mid}/corregir")
def corregir(mid: int, data: CorreccionIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Corrige (o anula) una marca: la original queda con corregida=True y, si aplica, nace la de reemplazo con original_id."""
    m = s.get(MarcaEmpleado, mid)
    if not m or m.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Marca no encontrada")
    if m.corregida:
        raise HTTPException(400, "Esta marca ya fue corregida; corrija la marca vigente")
    ahora = ahora_cr().isoformat(timespec="seconds")
    m.corregida = True; m.corregida_por = ctx.usuario.correo; m.motivo = data.motivo.strip(); s.add(m)
    if data.anular:
        s.commit(); return {"ok": True, "anulada": True}
    tipo = (data.tipo or m.tipo).strip().lower()
    if tipo not in TIPOS:
        raise HTTPException(400, "Tipo de marca desconocido")
    fh = _fecha_hora(data.fecha_hora) if data.fecha_hora else m.fecha_hora
    nueva = MarcaEmpleado(empresa_id=ctx.empresa.id, empleado_id=m.empleado_id, tipo=tipo, fecha_hora=fh, fecha=fh[:10], origen="correccion", equipo=m.equipo,
                          registrado_por=ctx.usuario.correo, motivo=data.motivo.strip(), original_id=m.id, clave_peticion=str(uuid.uuid4()), creada=ahora)
    s.add(nueva); s.commit(); s.refresh(nueva)
    nombres = {e["id"]: _nombre(e) for e in _empleados(s, ctx.empresa.id)}
    return _salida(nueva, nombres.get(nueva.empleado_id, ""))


# ------------------------------------------------------------------------------------------------- resumen contra el horario
def _min(hhmm: str) -> Optional[int]:
    try:
        h, m = str(hhmm).split(":")[:2]
        return int(h) * 60 + int(m)
    except (ValueError, AttributeError):
        return None


def horas_turno(t: dict) -> float:
    a, b = _min(t.get("inicio")), _min(t.get("fin"))
    if a is None or b is None:
        return 0.0
    mins = b - a
    if mins <= 0:
        mins += 24 * 60
    return max(0.0, round((mins - int(t.get("descanso_min") or 0)) / 6) / 10)


def _planificado(horarios: list, turnos: dict, emp_id: int, fecha: str) -> dict:
    """Horas planificadas ese día y hora de inicio del turno (horario 3.43); sin horario = None."""
    d = datetime.fromisoformat(fecha).date()
    lunes = (d - timedelta(days=d.weekday())).isoformat(); i = d.weekday()
    h = next((x for x in horarios if x.get("empleado_id") == emp_id and x.get("semana") == lunes), None)
    if not h:
        return {"planificado": None, "inicio": None, "libre": False}
    dias = h.get("dias") or []
    celda = dias[i] if i < len(dias) else None
    if celda in (None, "", "L"):
        return {"planificado": 0.0, "inicio": None, "libre": True}
    partes = (h.get("partes") or [None] * 7)
    parte = partes[i] if i < len(partes) else None
    t = turnos.get(str(celda)) or turnos.get(celda)
    if isinstance(parte, list) and parte:
        horas = round(sum(float(z.get("h") or 0) for z in parte), 2)
        t0 = turnos.get(str(parte[0].get("t"))) or t
        return {"planificado": horas, "inicio": (t0 or {}).get("inicio"), "libre": False}
    return {"planificado": horas_turno(t) if t else 0.0, "inicio": (t or {}).get("inicio"), "libre": not t}


def dias_de_turno(marcas: list, max_horas: float = MAX_TURNO_HORAS) -> dict:
    """4.7: agrupa las marcas de UN empleado por el día en que empezó su turno, no por la fecha del calendario: una Pausa, un
    Regreso o una Salida del mismo día de la Entrada abierta siempre siguen en su turno (como en la 4.6); después de la medianoche
    cuentan en el día de esa Entrada mientras no pasen `max_horas` desde ella (de 22:00 a 06:00 = un turno de 8 h el día de la
    entrada). Pasado el tope, la marca de otro día va a su propio día y el turno anterior queda sin salida.
    Devuelve {AAAA-MM-DD: [marcas]} con las marcas en orden."""
    out: dict = {}
    abierta = None                                          # (hora, día) de la Entrada del turno abierto
    tope = float(max_horas or MAX_TURNO_HORAS) * 3600
    for m in sorted(marcas, key=lambda x: x["fecha_hora"]):
        t = _momento(m["fecha_hora"]); dia = m.get("fecha") or str(m["fecha_hora"])[:10]
        if m["tipo"] == "entrada":
            abierta = (t, dia) if t is not None else None
        elif abierta is not None and t is not None and (dia == abierta[1] or (t - abierta[0]).total_seconds() <= tope):   # 4.7: el mismo día, sin tope
            dia = abierta[1]
            if m["tipo"] == "salida":
                abierta = None
        else:
            abierta = None
        out.setdefault(dia, []).append(m)
    return out


def calcular_dia(marcas: list, tolerancia: int, plan: dict, jornada_dia: float, max_horas: float = MAX_TURNO_HORAS, ahora: Optional[datetime] = None) -> dict:
    """Horas trabajadas de un día a partir de sus marcas (entrada→salida menos pausa→regreso) y comparación con lo planificado.
    4.7: las marcas son las del turno que empezó ese día (dias_de_turno). El día queda incompleto, con el motivo en `avisos`, si
    hay una pausa sin regreso, una salida, pausa o regreso sin entrada, dos entradas seguidas o un turno sin salida (o con la
    salida de otro día después de `max_horas`); esos tramos no suman horas. Una salida del MISMO día de la entrada cuenta aunque
    pase el tope (como en la 4.6), con la nota «Turno de más de N h» en `notas` (no es incompleto). Un turno abierto que con
    `ahora` sigue en el día de su entrada o todavía no pasa el tope va «en curso» (no incompleto)."""
    marcas = sorted(marcas, key=lambda m: m["fecha_hora"])
    trabajado = 0.0; pausas = 0.0; abierto = None; en_pausa = None; entrada = None; avisos: list = []; pausa_turno = 0.0; notas: list = []
    tope = float(max_horas or MAX_TURNO_HORAS) * 3600
    for m in marcas:
        t = _momento(m["fecha_hora"])
        if t is None:
            continue
        if abierto is not None and m["tipo"] != "entrada" and (t - abierto).total_seconds() > tope:
            if t.date() != abierto.date():                  # 4.7: después de la medianoche y pasado el tope: ya no es de ese turno
                avisos.append(f"Turno sin salida en {tope / 3600:g} h"); abierto = None; en_pausa = None; pausa_turno = 0.0
            else:                                           # el mismo día de la entrada sigue en el turno (como en la 4.6): solo una nota
                notas.append(f"Turno de más de {tope / 3600:g} h")
        if m["tipo"] == "entrada":
            if abierto is not None:
                avisos.append("Entrada sin salida")
            abierto = t; entrada = entrada or t; en_pausa = None; pausa_turno = 0.0
        elif m["tipo"] == "pausa":
            if abierto is None or en_pausa is not None:
                avisos.append("Pausa sin entrada" if abierto is None else "Pausa repetida")
            else:
                en_pausa = t
        elif m["tipo"] == "regreso":
            if en_pausa is None:
                avisos.append("Regreso sin pausa")
            else:
                h = (t - en_pausa).total_seconds() / 3600; pausas += h; pausa_turno += h; en_pausa = None
        elif m["tipo"] == "salida":
            if abierto is None:
                avisos.append("Salida sin entrada")
                continue
            if en_pausa is not None:                        # 4.7: la pausa corre hasta la salida (no inventa horas), pero falta el regreso
                avisos.append("Pausa sin regreso")
                h = (t - en_pausa).total_seconds() / 3600; pausas += h; pausa_turno += h; en_pausa = None
            trabajado += (t - abierto).total_seconds() / 3600 - pausa_turno; abierto = None; pausa_turno = 0.0
    en_curso = False
    if abierto is not None:
        if ahora is not None and ((ahora - abierto).total_seconds() <= tope or ahora.date() == abierto.date()):
            en_curso = True                                 # 4.7: turno de hoy (o de noche dentro del tope) todavía abierto: en curso, no incompleto
        else:
            avisos.append("Pausa sin regreso ni salida" if en_pausa is not None else "Entrada sin salida")
    trabajado = round(max(0.0, trabajado), 2)
    plan_h = plan.get("planificado")
    base = plan_h if plan_h is not None else jornada_dia
    extra = round(max(0.0, trabajado - base), 2) if trabajado and base else 0.0
    tarde = 0
    if entrada is not None and plan.get("inicio"):
        ini = _min(plan["inicio"])
        if ini is not None:
            dif = entrada.hour * 60 + entrada.minute - ini
            tarde = dif if dif > tolerancia else 0
    ausente = bool(plan_h and not marcas)
    avisos = list(dict.fromkeys(avisos))
    return {"marcas": len(marcas), "trabajado": trabajado, "pausas": round(pausas, 2), "planificado": plan_h, "extra": extra, "tarde_min": tarde, "incompleta": bool(avisos), "ausente": ausente, "libre": bool(plan.get("libre")),
            "en_curso": en_curso, "avisos": avisos, "notas": list(dict.fromkeys(notas))}


def _resumen(s: Session, eid: int, desde: str, hasta: str, empleado_id: Optional[int] = None) -> dict:
    """4.21: el resumen de asistencia contra el horario, tal como lo devuelve /api/asistencia/resumen. Va aparte de la ruta para
    que la propuesta de horas extra y ausencias (/api/asistencia/propuesta) salga del mismo cálculo, sin repetirlo."""
    c = _config(s, eid)
    emps = [e for e in _empleados(s, eid) if (not empleado_id or e["id"] == empleado_id)]
    horarios = modulos.leer(s, eid, "rrhh_horarios", []) or []
    turnos = {str(t.get("id")): t for t in (modulos.leer(s, eid, "rrhh_turnos", []) or []) if isinstance(t, dict)}
    d0, d1 = datetime.fromisoformat(desde[:10]).date(), datetime.fromisoformat(hasta[:10]).date()
    if (d1 - d0).days > 62 or d1 < d0:
        raise HTTPException(400, "El período no puede pasar de dos meses")
    # 4.7: se leen dos días antes y después del período para armar los turnos que pasan la medianoche (dias_de_turno): cada
    # marca cuenta en el día de la entrada de su turno; la salida de madrugada del último día también entra
    q = select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == eid, MarcaEmpleado.fecha >= (d0 - timedelta(days=2)).isoformat(), MarcaEmpleado.fecha <= (d1 + timedelta(days=2)).isoformat(), MarcaEmpleado.corregida == False)  # noqa: E712
    if empleado_id:
        q = q.where(MarcaEmpleado.empleado_id == empleado_id)
    tope = _tope(c); ahora = ahora_cr(); crudas: dict = {}
    for m in s.exec(q.order_by(MarcaEmpleado.fecha_hora, MarcaEmpleado.id)).all():
        crudas.setdefault(m.empleado_id, []).append(_salida(m))
    por_emp_dia: dict = {k: dias_de_turno(v, tope) for k, v in crudas.items()}
    ultimo = {k: max(v) for k, v in por_emp_dia.items() if v}      # 4.7: solo el último turno de cada empleado puede ir «en curso»
    out = []
    jornadas = {"diurna": 8, "mixta": 7, "nocturna": 6, "medio_tiempo": 4}
    for e in emps:
        if e.get("activo", True) is False and e["id"] not in por_emp_dia:
            continue
        hs = float(e.get("horas_semana") or 0); jdia = hs / 6 if hs and hs != {"diurna": 48, "mixta": 42, "nocturna": 36, "medio_tiempo": 24}.get(e.get("jornada"), 48) else jornadas.get(e.get("jornada"), 8)
        dias = []; d = d0
        while d <= d1:
            f = d.isoformat(); ms = por_emp_dia.get(e["id"], {}).get(f, [])
            plan = _planificado(horarios, turnos, e["id"], f)
            if ms or (plan["planificado"] and not plan["libre"]):
                dias.append({"fecha": f, **calcular_dia(ms, c.tolerancia_min, plan, jdia, tope, ahora if f == ultimo.get(e["id"]) else None), "detalle": ms})   # 4.7: tope del turno; «en curso» solo el último
            d += timedelta(days=1)
        if not dias:
            continue
        tot = {"dias_marcados": len([x for x in dias if x["marcas"]]), "trabajado": round(sum(x["trabajado"] for x in dias), 2), "planificado": round(sum(x["planificado"] or 0 for x in dias), 2),
               "extra": round(sum(x["extra"] for x in dias), 2), "tardes": len([x for x in dias if x["tarde_min"]]), "tarde_min": sum(x["tarde_min"] for x in dias),
               "ausencias": len([x for x in dias if x["ausente"]]), "incompletos": len([x for x in dias if x["incompleta"]])}
        out.append({"empleado_id": e["id"], "nombre": _nombre(e), "codigo_reloj": str(e.get("codigo_reloj") or "").zfill(4) if str(e.get("codigo_reloj") or "").strip() else "", "dias": dias, **tot})
    return {"desde": d0.isoformat(), "hasta": d1.isoformat(), "tolerancia_min": c.tolerancia_min, "max_turno_horas": int(tope), "empleados": out}


@router.get("/api/asistencia/resumen")
def resumen(desde: str, hasta: str, empleado_id: Optional[int] = None, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    return _resumen(s, ctx.empresa.id, desde, hasta, empleado_id)


@router.get("/api/asistencia/propuesta")
def propuesta(desde: str, hasta: str, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.21: lo que la asistencia propone anotar en Horas extra y en Ausencias. Aquí no se guarda nada: Recursos humanos revisa cada
    fila en esas pantallas, la confirma y la guarda. Sale del mismo cálculo del resumen (_resumen y calcular_dia):
    - horas_extra: por empleado y día, las horas trabajadas por encima de lo planificado en su horario o, si no tiene horario, de
      su jornada (`jornada` es esa base y `planificado` viene vacío). `marcable` es falso si el día tiene marcas incompletas o el
      turno sigue en curso (el motivo va en `avisos`) o si ese empleado ya tiene horas registradas ese día (`ya_registrado`).
      Como el registro manual, no pasa de 16 horas por día.
    - ausencias: los días planificados sin ninguna marca, anteriores a hoy, unidos en rangos de días seguidos por empleado. No
      salen los que ya cubre una ausencia o unas vacaciones registradas. El tipo no se propone: lo elige Recursos humanos.
    No decide si un día es feriado ni si una ausencia es justificada."""
    try:
        datetime.fromisoformat(desde[:10]); datetime.fromisoformat(hasta[:10])
    except ValueError:
        raise HTTPException(400, "Indique las fechas del período")
    eid = ctx.empresa.id
    r = _resumen(s, eid, desde, hasta)
    registros = lambda clave: [x for x in (modulos.leer(s, eid, clave, []) or []) if isinstance(x, dict)]   # noqa: E731
    dia = lambda v: str(v or "")[:10]                                                                       # noqa: E731
    con_horas = {(modulos._id_entero(h.get("empleado_id")), dia(h.get("fecha"))) for h in registros("rrhh_horas_extra")}
    cubiertos: dict = {}
    for v in registros("rrhh_ausencias") + registros("vacaciones_tomadas"):
        if dia(v.get("desde")):
            cubiertos.setdefault(modulos._id_entero(v.get("empleado_id")), []).append((dia(v.get("desde")), dia(v.get("hasta")) or dia(v.get("desde"))))
    hoy = ahora_cr().date().isoformat()
    horas, ausencias = [], []
    for e in r["empleados"]:
        emp, abierta = modulos._id_entero(e["empleado_id"]), None
        for d in e["dias"]:
            f = d["fecha"]
            if d["extra"] > 0:
                ya = (emp, f) in con_horas
                horas.append({"empleado_id": e["empleado_id"], "nombre": e["nombre"], "fecha": f, "horas": min(16, round(d["extra"], 2)), "trabajado": d["trabajado"],
                              "planificado": d["planificado"], "jornada": round(d["trabajado"] - d["extra"], 2),
                              "marcable": not (d["incompleta"] or d["en_curso"]) and not ya, "ya_registrado": ya,
                              "avisos": list(d["avisos"]) + list(d["notas"]) + (["Turno todavía en curso"] if d["en_curso"] else [])})
            if d["ausente"] and f < hoy and not any(a <= f <= b for a, b in cubiertos.get(emp, [])):
                if abierta is not None and (datetime.fromisoformat(abierta["hasta"]) + timedelta(days=1)).date().isoformat() == f:
                    abierta["hasta"] = f; abierta["dias"] += 1
                else:
                    abierta = {"empleado_id": e["empleado_id"], "nombre": e["nombre"], "desde": f, "hasta": f, "dias": 1}
                    ausencias.append(abierta)
    orden = lambda campo: (lambda x: (str(x["nombre"]).lower(), x[campo]))                                   # noqa: E731
    return {"desde": r["desde"], "hasta": r["hasta"], "horas_extra": sorted(horas, key=orden("fecha")), "ausencias": sorted(ausencias, key=orden("desde"))}


# ----------------------------------------------------------------------------- relojes marcadores por archivo (3.67)
# El reloj (ZKTeco, Anviz, Hikvision…) exporta sus marcas a Excel o CSV; aquí se cargan a la misma tabla de marcas. Se reconoce
# al empleado por su código de reloj (o su identificación), la fecha y hora en una o dos columnas, y el tipo de marca si viene;
# si no viene, se deduce por el orden del día (entrada, pausa, regreso, salida). La misma marca dos veces no se duplica.
CABECERAS_RELOJ = {
    "codigo": ("codigo", "codigo reloj", "codigoreloj", "id", "no", "no.", "num", "numero", "user id", "userid", "id usuario", "usuario", "employee id", "emp id", "ac-no", "ac no", "enroll", "pin", "badge", "no. de id", "id de usuario"),
    "cedula": ("cedula", "identificacion", "id card", "card no", "documento"),
    "nombre": ("nombre", "name", "empleado", "employee"),
    "fecha": ("fecha", "date", "dia"),
    "hora": ("hora", "time", "clock", "check time", "hora marca"),
    "fecha_hora": ("fecha y hora", "fecha hora", "fechahora", "date time", "datetime", "date/time", "time stamp", "timestamp", "marca", "hora de marca", "fecha/hora", "punch time", "att time", "attendance time"),
    "tipo": ("tipo", "estado", "status", "state", "check type", "tipo marca", "in/out", "entrada/salida", "verify state", "evento", "event", "direction", "attendance state", "att state"),
}
TIPOS_RELOJ = {"entrada": ("entrada", "in", "check in", "check-in", "checkin", "c/in", "ingreso", "0", "e", "i", "ent"), "salida": ("salida", "out", "check out", "check-out", "checkout", "c/out", "egreso", "1", "s", "o", "sal"),
               "pausa": ("pausa", "break out", "break-out", "salida almuerzo", "almuerzo", "2", "p"), "regreso": ("regreso", "break in", "break-in", "regreso almuerzo", "3", "r")}
ORDEN_DIA = {1: ("entrada",), 2: ("entrada", "salida"), 3: ("entrada", "pausa", "salida")}


def _norm(v) -> str:
    import unicodedata
    t = unicodedata.normalize("NFKD", str(v if v is not None else "")).encode("ascii", "ignore").decode().lower().strip()
    return " ".join(t.replace("_", " ").split())


def _columnas_reloj(cabecera: list) -> dict:
    out = {}
    for i, c in enumerate(cabecera):
        n = _norm(c)
        if not n:
            continue
        for clave, nombres in CABECERAS_RELOJ.items():
            if clave not in out and (n in nombres or any(n.startswith(x + " ") for x in nombres if len(x) > 3)):
                out[clave] = i
                break
    return out


def _fecha_hora_celda(v, hora=None):
    """datetime de una celda (datetime de Excel, 'AAAA-MM-DD HH:MM[:SS]', 'DD/MM/AAAA HH:MM' o fecha + hora aparte); None si no se entiende."""
    import re
    if isinstance(v, datetime):
        d = v
    else:
        t = str(v or "").strip()
        if hora is not None:
            h = hora.strftime("%H:%M:%S") if hasattr(hora, "strftime") else str(hora or "").strip()
            t = (t[:10] if re.match(r"^\d{4}-\d{2}-\d{2}", t) else t.split(" ")[0]) + " " + h
        d = None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%d-%m-%Y %H:%M:%S", "%d-%m-%Y %H:%M",
                    "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%d/%m/%Y %I:%M:%S %p", "%d/%m/%Y %I:%M %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M"):
            try:
                d = datetime.strptime(t, fmt)
                break
            except ValueError:
                continue
        if d is None:
            return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=ahora_cr().tzinfo)
    return d


def _tipo_reloj(v) -> Optional[str]:
    n = _norm(v)
    if not n:
        return None
    for tipo, nombres in TIPOS_RELOJ.items():
        if n in nombres:
            return tipo
    for tipo, nombres in TIPOS_RELOJ.items():
        if any(x in n for x in nombres if len(x) > 2):
            return tipo
    return None


def interpretar_reloj(filas: list) -> dict:
    """Convierte las filas del archivo en marcas {codigo, cedula, nombre, fecha_hora (datetime), tipo|None}. La primera fila con
    cabeceras conocidas manda; sin cabeceras se toma la primera columna como código y la primera celda con fecha y hora."""
    if not filas:
        return {"marcas": [], "avisos": ["El archivo está vacío"]}
    cols, inicio = {}, 0
    for i, fila in enumerate(filas[:5]):
        c = _columnas_reloj(fila)
        if ("codigo" in c or "cedula" in c) and ("fecha_hora" in c or "fecha" in c):
            cols, inicio = c, i + 1
            break
    marcas, avisos = [], []
    for n_fila, fila in enumerate(filas[inicio:], start=inicio + 1):
        if not any(str(x or "").strip() for x in fila):
            continue
        if cols:
            codigo = fila[cols["codigo"]] if "codigo" in cols and cols["codigo"] < len(fila) else None
            cedula = fila[cols["cedula"]] if "cedula" in cols and cols["cedula"] < len(fila) else None
            nombre = fila[cols["nombre"]] if "nombre" in cols and cols["nombre"] < len(fila) else None
            if "fecha_hora" in cols:
                fh = _fecha_hora_celda(fila[cols["fecha_hora"]] if cols["fecha_hora"] < len(fila) else None)
            else:
                f = fila[cols["fecha"]] if cols["fecha"] < len(fila) else None
                h = fila[cols["hora"]] if "hora" in cols and cols["hora"] < len(fila) else None
                fh = _fecha_hora_celda(f, h) if h not in (None, "") else _fecha_hora_celda(f)      # hora vacía: la fecha trae todo
            tipo = _tipo_reloj(fila[cols["tipo"]]) if "tipo" in cols and cols["tipo"] < len(fila) else None
        else:
            codigo, cedula, nombre, tipo, fh = fila[0] if fila else None, None, None, None, None
            for j in range(1, len(fila)):
                fh = _fecha_hora_celda(fila[j]) or (_fecha_hora_celda(fila[j], fila[j + 1]) if j + 1 < len(fila) else None)
                if fh:
                    break
        if fh is None:
            avisos.append(f"Fila {n_fila}: sin fecha y hora")
            continue
        marcas.append({"codigo": str(codigo if codigo is not None else "").strip(), "cedula": str(cedula or "").strip(), "nombre": str(nombre or "").strip(), "fecha_hora": fh, "tipo": tipo})
    return {"marcas": marcas, "avisos": avisos[:20]}


def _codigo_comparable(v) -> str:
    t = "".join(ch for ch in str(v or "") if ch.isalnum()).upper()
    return t.lstrip("0") or t


def _minutos_del_dia(a: datetime, b: datetime) -> int:
    """4.7: distancia en minutos entre las horas del día de dos marcas, sin importar la fecha (23:50 y 00:10 = 20 minutos)."""
    d = abs((a.hour * 60 + a.minute) - (b.hour * 60 + b.minute)) % 1440
    return min(d, 1440 - d)


def deducir_tipos_reloj(marcas: list, previas=(), max_horas: float = MAX_TURNO_HORAS, descanso_horas: float = DESCANSO_MIN_HORAS) -> list:
    """4.7: tipo deducido (ORDEN_DIA, por el orden dentro del turno) para cada marca del reloj de UN empleado (dicts con
    `fecha_hora` datetime, en orden); solo se usa en las que no traen tipo. Antes se agrupaban por día del calendario y la salida
    de madrugada de un turno de noche salía «entrada». Una marca sigue en el turno de la anterior si:
    - el hueco desde la marca anterior es menor que `descanso_horas` (descanso mínimo entre turnos): un hueco igual o mayor
      empieza otro turno aunque el turno anterior haya quedado con un número impar de marcas. Así una marca olvidada (o un
      archivo que empieza con una salida) no invierte entrada y salida en los días siguientes;
    - y es del mismo día de la primera marca del turno (sigue como en la 4.6: el tope no corta el mismo día), o, después de la
      medianoche, no pasan `max_horas` desde esa primera marca y es del mismo día que la anterior o el turno quedó abierto
      (número impar de marcas: la entrada de las 22:00 sola).
    `previas` (MarcaEmpleado vigentes ya guardadas): si el turno de la última antes del archivo sigue abierto (la entrada vino en
    otro archivo, del quiosco o de una marca manual, aun del mismo día), el archivo empieza antes del descanso mínimo y dentro del
    tope (o el mismo día de esa entrada), el archivo lo continúa.
    Archivo exportado por fechas (empieza a las 00:00) con un turno de noche: si la primera marca del empleado queda sola, el
    turno siguiente del archivo pasa la medianoche y esa marca cae más cerca de la hora de salida que de la de entrada de ese
    turno, es la Salida de un turno que empezó antes del archivo. Fuera de ese caso una marca sola queda Entrada (como en la 4.6)
    y en el resumen ese día sale incompleto para que se revise."""
    tope = float(max_horas or MAX_TURNO_HORAS) * 3600
    descanso = float(descanso_horas or DESCANSO_MIN_HORAS) * 3600
    grupos: list = []                                       # [previas del turno, hora de inicio, hora de la última, [índices]]
    if marcas:
        t0 = marcas[0]["fecha_hora"]
        mismo = t0.isoformat(timespec="minutes")[:16]       # 4.7: guardada en el mismo minuto que la primera del archivo = la misma marca
        antes = sorted((p for p in previas if (_momento(p.fecha_hora) or t0) < t0 and str(p.fecha_hora)[:16] != mismo), key=lambda p: p.fecha_hora)
        k, ent = 0, None
        for p in reversed(antes):
            if p.tipo == "salida":
                break
            k += 1
            if p.tipo == "entrada":
                ent = p
                break
        ti, tu = (_momento(ent.fecha_hora), _momento(antes[-1].fecha_hora)) if ent is not None else (None, None)
        if ti is not None and tu is not None and (t0 - tu).total_seconds() < descanso and (t0.date() == ti.date() or (t0 - ti).total_seconds() <= tope):
            grupos.append([k, ti, tu, []])                  # 4.7: también una entrada abierta del mismo día (importación por partes)
    for i, m in enumerate(marcas):
        t = m["fecha_hora"]; g = grupos[-1] if grupos else None
        sigue = g is not None and ((not g[3] and g[0] > 0) or ((t - g[2]).total_seconds() < descanso and (t.date() == g[1].date() or (
            (t - g[1]).total_seconds() <= tope and (t.date() == g[2].date() or (g[0] + len(g[3])) % 2 == 1)))))
        if sigue:
            g[3].append(i); g[2] = t
        else:
            grupos.append([0, t, t, [i]])
    out = ["entrada"] * len(marcas)
    for k, _, _, idx in grupos:
        n = k + len(idx)
        orden = ORDEN_DIA.get(n) or ("entrada", "pausa", "regreso", "salida") + tuple("entrada" if j % 2 == 0 else "salida" for j in range(max(0, n - 4)))
        for j, i in enumerate(idx):
            out[i] = orden[k + j] if k + j < len(orden) else ("entrada" if (k + j) % 2 == 0 else "salida")
    if len(grupos) > 1 and grupos[0][0] == 0 and len(grupos[0][3]) == 1 and len(grupos[1][3]) >= 2:   # D5: archivo que empieza a medianoche
        sola, sig = marcas[grupos[0][3][0]]["fecha_hora"], [marcas[i]["fecha_hora"] for i in grupos[1][3]]
        if sig[-1].date() > sig[0].date() and out[grupos[1][3][-1]] == "salida" and _minutos_del_dia(sola, sig[-1]) < _minutos_del_dia(sola, sig[0]):
            out[grupos[0][3][0]] = "salida"                # la salida de un turno de noche que empezó antes del archivo
    return out


@router.post("/api/asistencia/importar")
def importar_reloj(archivo: UploadFile = File(...), equipo: str = Form(""), ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """Carga las marcas exportadas por un reloj marcador (Excel o CSV). Devuelve cuántas se crearon, cuántas ya existían y qué
    códigos no corresponden a ningún empleado."""
    from .importacion_items import _leer_csv, _leer_xlsx
    datos = archivo.file.read(8 * 1024 * 1024 + 1)
    if len(datos) > 8 * 1024 * 1024:
        raise HTTPException(413, "El archivo pesa más de 8 MB")
    nombre = (archivo.filename or "").lower()
    try:
        filas = _leer_xlsx(datos) if nombre.endswith((".xlsx", ".xlsm")) else _leer_csv(datos)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    r = interpretar_reloj(filas[:5001])
    empleados = _empleados(s, ctx.empresa.id)
    por_codigo = {_codigo_comparable(e.get("codigo_reloj")): e for e in empleados if _codigo_comparable(e.get("codigo_reloj"))}
    por_cedula = {_codigo_comparable(e.get("numero_id")): e for e in empleados if _codigo_comparable(e.get("numero_id"))}
    ahora = ahora_cr()
    creadas = repetidas = futuras = 0
    sin_empleado: dict[str, int] = {}
    por_emp: dict[int, list] = {}
    for m in r["marcas"]:
        emp = por_codigo.get(_codigo_comparable(m["codigo"])) or por_cedula.get(_codigo_comparable(m["cedula"])) or por_cedula.get(_codigo_comparable(m["codigo"]))
        if emp is None:
            k = m["codigo"] or m["cedula"] or m["nombre"] or "?"
            sin_empleado[k] = sin_empleado.get(k, 0) + 1
            continue
        if m["fecha_hora"] > ahora + timedelta(minutes=2):
            futuras += 1
            continue
        por_emp.setdefault(emp["id"], []).append((m, emp))
    equipo = (equipo or "").strip()[:60] or (archivo.filename or "reloj")[:60]
    cfg = _config(s, ctx.empresa.id); tope, descanso = _tope(cfg), _descanso(cfg)
    for eid_emp, lista in por_emp.items():                  # 4.7: por empleado y por turno (el de noche pasa la medianoche), no por día
        lista.sort(key=lambda x: x[0]["fecha_hora"])
        f0, f1 = (lista[0][0]["fecha_hora"].date() - timedelta(days=2)).isoformat(), (lista[-1][0]["fecha_hora"].date() + timedelta(days=1)).isoformat()
        existentes = s.exec(select(MarcaEmpleado).where(MarcaEmpleado.empresa_id == ctx.empresa.id, MarcaEmpleado.empleado_id == eid_emp, MarcaEmpleado.fecha >= f0, MarcaEmpleado.fecha <= f1)
                            .order_by(MarcaEmpleado.fecha_hora, MarcaEmpleado.id)).all()
        ya = {x.fecha_hora[:16] for x in existentes}         # 4.7: también las anuladas y las corregidas: reimportar no las revive
        deducidos = deducir_tipos_reloj([x[0] for x in lista], [x for x in existentes if not x.corregida], tope, descanso)
        for i, (m, emp) in enumerate(lista):
            fh = m["fecha_hora"].isoformat(timespec="seconds")
            if fh[:16] in ya:
                repetidas += 1
                continue
            tipo = m["tipo"] or deducidos[i]
            s.add(MarcaEmpleado(empresa_id=ctx.empresa.id, empleado_id=emp["id"], tipo=tipo, fecha_hora=fh, fecha=fh[:10], origen="reloj", equipo=equipo,
                                registrado_por=ctx.usuario.correo, clave_peticion=f"reloj:{emp['id']}:{fh}", nota=(m["nombre"] or None)))
            ya.add(fh[:16]); creadas += 1
    s.commit()
    return {"ok": True, "creadas": creadas, "repetidas": repetidas, "futuras": futuras, "leidas": len(r["marcas"]), "avisos": r["avisos"],
            "sin_empleado": [{"codigo": k, "marcas": v} for k, v in sorted(sin_empleado.items(), key=lambda x: -x[1])][:30]}
