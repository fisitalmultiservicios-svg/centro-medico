"""Importación de comprobantes ya emitidos en otro sistema (3.27): facturas, tiquetes, notas y facturas de exportación que la
empresa emitió antes (Alegra u otro) se registran a partir de su XML firmado, como históricos: no se reenvían a Hacienda, no
mueven inventario, no gastan consecutivos nuevos (la serie sigue después del mayor importado) y no generan asientos automáticos.

Fuentes:
- XML firmados (sueltos o en ZIP), v4.3 o v4.4. Obligatorio: de ahí salen clave, consecutivo, receptor, líneas y totales.
- Respuestas de Hacienda (MensajeHacienda) opcionales, en el mismo envío: fijan el estado (aceptado o rechazado).
- Listado del sistema anterior (Excel o CSV) opcional, con «Número» y «Por cobrar» (o «Saldo»), y «Vencimiento»: deja cada
  factura con el saldo pendiente real. Sin listado, las de contado quedan cobradas y las de crédito según `credito`.
"""
import csv
import io
import json
import re
import unicodedata
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

from lxml import etree
from sqlmodel import Session, select

from .db import Cliente, Documento, DocumentoLinea, Producto, Secuencia

TIPOS_VENTA = {"FacturaElectronica": "01", "NotaDebitoElectronica": "02", "NotaCreditoElectronica": "03",
               "TiqueteElectronico": "04", "FacturaElectronicaExportacion": "09"}
OTROS = {"FacturaElectronicaCompra": "factura electrónica de compra (se registra en Gastos)",
         "ReciboElectronicoPago": "recibo electrónico de pago"}
MAX_ARCHIVOS = 5000
MAX_DESCOMPRIMIDO = 300 * 1024 * 1024


def _t(el, ruta, default=""):
    if el is None:
        return default
    x = el.find(ruta)
    return (x.text or "").strip() if x is not None and x.text else default


def _f(el, ruta) -> float:
    try:
        return float(_t(el, ruta, "0") or 0)
    except ValueError:
        return 0.0


def _digitos(v) -> str:
    return re.sub(r"\D", "", str(v or ""))


def _cedula(v) -> str:
    """Cédula para comparar: letras y números, sin guiones ni espacios (las jurídicas nuevas pueden traer letras, 3.41)."""
    return re.sub(r"[^A-Za-z0-9]", "", str(v or "")).upper()


def leer_comprobante(xml: bytes) -> dict:
    """Datos completos de un comprobante de venta emitido. ValueError con el motivo si no se puede importar."""
    try:
        root = etree.fromstring(xml)
    except etree.XMLSyntaxError as ex:
        raise ValueError(f"XML inválido ({ex})")
    raiz = etree.QName(root).localname
    if raiz == "MensajeHacienda":
        return {"respuesta": True, "clave": _t(root, "{*}Clave"), "mensaje": _t(root, "{*}Mensaje"), "detalle": _t(root, "{*}DetalleMensaje")}
    if raiz in OTROS:
        raise ValueError(f"es una {OTROS[raiz]}, no una venta")
    if raiz not in TIPOS_VENTA:
        raise ValueError(f"no es un comprobante de venta ({raiz})")
    emisor, receptor, res = root.find("{*}Emisor"), root.find("{*}Receptor"), root.find("{*}ResumenFactura")
    lineas = []
    for i, ld in enumerate(root.findall("{*}DetalleServicio/{*}LineaDetalle"), start=1):
        imp = ld.find("{*}Impuesto")
        exo = imp.find("{*}Exoneracion") if imp is not None else None
        desc = sum(float(_t(d, "{*}MontoDescuento", "0") or 0) for d in ld.findall("{*}Descuento"))
        cabys = _t(ld, "{*}CodigoCABYS") or _t(ld, "{*}Codigo")
        imp_neto = _t(ld, "{*}ImpuestoNeto")
        # 3.41: IVA (código 01) aparte del Selectivo de Consumo y los impuestos específicos
        otros_l = round(sum(float(_t(ie, "{*}Monto", "0") or 0) for ie in ld.findall("{*}Impuesto") if (_t(ie, "{*}Codigo") or "01") != "01"), 5)
        lineas.append({
            "numero": int(_t(ld, "{*}NumeroLinea", str(i)) or i), "cabys": cabys if re.fullmatch(r"\d{13}", cabys or "") else (cabys or ""),
            "detalle": _t(ld, "{*}Detalle") or "Línea " + str(i), "cantidad": _f(ld, "{*}Cantidad"), "unidad_medida": _t(ld, "{*}UnidadMedida", "Unid"),
            "precio_unitario": _f(ld, "{*}PrecioUnitario"), "descuento": round(desc, 5),
            "codigo_tarifa": (_t(imp, "{*}CodigoTarifaIVA") or _t(imp, "{*}CodigoTarifa") or "08") if imp is not None else "01",
            "tarifa": _f(imp, "{*}Tarifa") if imp is not None else 0.0,
            "impuesto": round((float(imp_neto) if imp_neto else (_f(imp, "{*}Monto") if imp is not None else 0.0)) - otros_l, 5),
            "otros_impuestos": otros_l,
            "total": _f(ld, "{*}MontoTotalLinea"), "iva_exonerado": _f(exo, "{*}MontoExoneracion") if exo is not None else 0.0,
            "codigo_comercial": _t(ld, "{*}CodigoComercial/{*}Codigo"),
        })
    cargos = []
    for oc in root.findall("{*}OtrosCargos"):
        cargos.append({"tipo": _t(oc, "{*}TipoDocumentoOC") or _t(oc, "{*}TipoDocumento") or "99", "detalle": _t(oc, "{*}Detalle"),
                       "porcentaje": _f(oc, "{*}Porcentaje") or None, "monto": _f(oc, "{*}MontoCargo")})
    plazo = _t(root, "{*}PlazoCredito")
    return {
        "respuesta": False, "tipo_documento": TIPOS_VENTA[raiz], "clave": _t(root, "{*}Clave"), "consecutivo": _t(root, "{*}NumeroConsecutivo"),
        "fecha_emision": _t(root, "{*}FechaEmision"), "emisor_id": _cedula(_t(emisor, "{*}Identificacion/{*}Numero")),
        "receptor": None if receptor is None else {
            "nombre": _t(receptor, "{*}Nombre"), "tipo_id": _t(receptor, "{*}Identificacion/{*}Tipo") or ("05" if _t(receptor, "{*}IdentificacionExtranjero") else "01"),
            "numero_id": _t(receptor, "{*}Identificacion/{*}Numero") or _t(receptor, "{*}IdentificacionExtranjero"),
            "correo": _t(receptor, "{*}CorreoElectronico") or None, "telefono": _digitos(_t(receptor, "{*}Telefono/{*}NumTelefono"))[:8] or None},
        "condicion_venta": _t(root, "{*}CondicionVenta") or "01", "plazo": int(_digitos(plazo)) if _digitos(plazo) else None,
        "moneda": _t(res, "{*}CodigoTipoMoneda/{*}CodigoMoneda", "CRC") or "CRC", "tipo_cambio": _f(res, "{*}CodigoTipoMoneda/{*}TipoCambio") or 1.0,
        "total": _f(res, "{*}TotalComprobante"), "impuesto": round(_f(res, "{*}TotalImpuesto") - sum(x["otros_impuestos"] for x in lineas), 5),
        "otros_impuestos": round(sum(x["otros_impuestos"] for x in lineas), 5),
        "referencia_clave": (_t(root, "{*}InformacionReferencia/{*}Numero") or None) if TIPOS_VENTA[raiz] in ("02", "03") else None,
        "referencia_codigo": _t(root, "{*}InformacionReferencia/{*}Codigo") or None,
        "lineas": lineas, "otros_cargos": cargos,
    }


# ---------------------------------------------------------------------------------------------- listado del sistema anterior
def _sin_tilde(s: str) -> str:
    return unicodedata.normalize("NFD", str(s or "")).encode("ascii", "ignore").decode().lower().strip()


def _numero(v) -> Optional[float]:
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"[^\d,.\-]", "", str(v))
    if not t:
        return None
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".") if len(t.split(",")[-1]) != 3 else t.replace(",", "")
    try:
        return float(t)
    except ValueError:
        return None


def _fecha(v) -> Optional[str]:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    m = re.match(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})", str(v).strip())
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            return None
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", str(v).strip())
    return m.group(0) if m else None


def leer_listado(nombre: str, datos: bytes) -> dict:
    """{consecutivo de 20 o número corto: {por_cobrar, vencimiento}} desde un Excel o CSV con columnas Número y Por cobrar."""
    filas = []
    if nombre.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(datos), read_only=True, data_only=True)
        for ws in wb.worksheets:
            filas.extend(list(ws.iter_rows(values_only=True)))
    else:
        texto = datos.decode("utf-8-sig", errors="replace")
        sep = ";" if texto.count(";") >= texto.count(",") else ","
        filas = list(csv.reader(io.StringIO(texto), delimiter=sep))
    cab, i0 = None, 0
    for i, f in enumerate(filas[:30]):
        nombres = [_sin_tilde(c) for c in f]
        if any(n.startswith("numero") for n in nombres) and any(n in ("por cobrar", "saldo", "pendiente", "saldo pendiente") for n in nombres):
            cab, i0 = nombres, i
            break
    if not cab:
        raise ValueError("el listado no tiene las columnas «Número» y «Por cobrar» (o «Saldo»)")
    c_num = next(j for j, n in enumerate(cab) if n.startswith("numero"))
    c_saldo = next(j for j, n in enumerate(cab) if n in ("por cobrar", "saldo", "pendiente", "saldo pendiente"))
    c_venc = next((j for j, n in enumerate(cab) if n.startswith("vencimiento")), None)
    out = {}
    for f in filas[i0 + 1:]:
        if not f or c_num >= len(f):
            continue
        num = _digitos(f[c_num])
        if not num:
            continue
        saldo = _numero(f[c_saldo]) if c_saldo < len(f) else None
        out[num] = {"por_cobrar": saldo, "vencimiento": _fecha(f[c_venc]) if c_venc is not None and c_venc < len(f) else None}
    return out


def _del_listado(listado: dict, consecutivo: str) -> Optional[dict]:
    if not listado:
        return None
    if consecutivo in listado:
        return listado[consecutivo]
    corto = consecutivo[-10:].lstrip("0")
    return listado.get(corto) or listado.get(consecutivo[-10:])


# ---------------------------------------------------------------------------------------------- archivos subidos
def expandir(archivos: list[tuple[str, bytes]]) -> tuple[list[tuple[str, bytes]], list[str]]:
    """Abre los ZIP (también ZIP dentro de ZIP, un nivel) y devuelve los XML con su nombre; los demás se informan."""
    xmls, avisos, total = [], [], 0
    pendientes = list(archivos)
    nivel = 0
    while pendientes and nivel < 3:
        siguientes = []
        for nombre, datos in pendientes:
            n = nombre.lower()
            if n.endswith(".zip"):
                try:
                    with zipfile.ZipFile(io.BytesIO(datos)) as z:
                        for info in z.infolist():
                            if info.is_dir():
                                continue
                            total += info.file_size
                            if total > MAX_DESCOMPRIMIDO:
                                raise ValueError("los ZIP pesan más de 300 MB al descomprimir: súbalos en varias tandas")
                            if info.filename.lower().endswith((".xml", ".zip")):
                                siguientes.append((info.filename, z.read(info)))
                except zipfile.BadZipFile:
                    avisos.append(f"{nombre}: ZIP dañado")
            elif n.endswith(".xml"):
                xmls.append((nombre, datos))
            else:
                avisos.append(f"{nombre}: no es XML ni ZIP")
        pendientes, nivel = siguientes, nivel + 1
    if len(xmls) > MAX_ARCHIVOS:
        raise ValueError(f"son {len(xmls)} XML; el máximo por carga es {MAX_ARCHIVOS}: súbalos por año o por trimestre")
    return xmls, avisos


# ---------------------------------------------------------------------------------------------- importación
def _cliente_para(s: Session, eid: int, rec: Optional[dict], cache: dict) -> tuple[Optional[int], Optional[str], bool]:
    if not rec or not rec.get("numero_id"):
        return None, (rec or {}).get("nombre") or None, False
    num = str(rec["numero_id"]).strip()
    if num in cache:
        return cache[num], rec.get("nombre"), False
    c = s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.numero_id == num)).first()
    nuevo = False
    if not c:
        tel = int(rec["telefono"]) if rec.get("telefono") and str(rec["telefono"]).isdigit() else None
        c = Cliente(empresa_id=eid, nombre=(rec.get("nombre") or num)[:100], tipo_id=rec.get("tipo_id") or "01", numero_id=num,
                    correo=rec.get("correo"), telefono=tel, tipo="Cliente", comentarios="Creado al importar comprobantes del sistema anterior")
        s.add(c); s.flush(); nuevo = True
    cache[num] = c.id
    return c.id, c.nombre, nuevo


def importar(s: Session, empresa, xml_dir: Path, xmls: list[tuple[str, bytes]], listado: Optional[dict] = None,
             credito: str = "pendientes", origen: str = "Sistema anterior") -> dict:
    """Registra los comprobantes; devuelve el resumen. `credito`: 'pendientes' | 'cobradas' (si no hay listado)."""
    eid, emisor = empresa.id, _cedula(empresa.numero_id)
    res = {"importados": 0, "duplicados": 0, "respuestas": 0, "clientes_nuevos": 0, "por_cobrar": 0, "monto_por_cobrar": {},
           "descartados": [], "por_tipo": {}, "desde": None, "hasta": None}
    respuestas, comps = {}, []
    for nombre, datos in xmls:
        try:
            d = leer_comprobante(datos)
        except ValueError as ex:
            res["descartados"].append(f"{Path(nombre).name}: {ex}")
            continue
        if d["respuesta"]:
            if d["clave"]:
                respuestas[d["clave"]] = (d, datos)
            continue
        comps.append((nombre, d, datos))
    claves_existentes = set(s.exec(select(Documento.clave).where(Documento.empresa_id == eid)).all()) if (comps or respuestas) else set()
    productos = {p.nombre.strip().lower(): p.id for p in s.exec(select(Producto).where(Producto.empresa_id == eid)).all()}
    cache, vistos, maximos = {}, set(), {}
    for nombre, d, datos in comps:
        n = Path(nombre).name
        if not re.fullmatch(r"[A-Za-z0-9]{50}", d["clave"] or "") or not re.fullmatch(r"\d{20}", d["consecutivo"] or ""):   # clave alfanumérica (rev. 22/04/2026)
            res["descartados"].append(f"{n}: sin clave o consecutivo válidos"); continue
        if d["emisor_id"] != emisor:
            res["descartados"].append(f"{n}: lo emitió la cédula {d['emisor_id']}, no esta empresa"); continue
        if d["clave"] in claves_existentes or d["clave"] in vistos:
            res["duplicados"] += 1; continue
        vistos.add(d["clave"])
        cid, nombre_rec, nuevo = _cliente_para(s, eid, d["receptor"], cache)
        res["clientes_nuevos"] += 1 if nuevo else 0
        estado, mensaje, resp_nombre = "aceptado", f"Importado de {origen}", None
        r = respuestas.get(d["clave"])
        if r:
            if r[0]["mensaje"] == "3":
                estado = "rechazado"
            mensaje = (f"Importado de {origen} · Hacienda: " + (r[0]["detalle"] or ("rechazado" if estado == "rechazado" else "aceptado")))[:1000]
            resp_nombre = f"{d['clave']}_respuesta.xml"; (xml_dir / resp_nombre).write_bytes(r[1]); res["respuestas"] += 1
        fecha = d["fecha_emision"]
        venc = None
        if d["plazo"] and d["condicion_venta"] != "01":
            try:
                venc = (date.fromisoformat(fecha[:10]) + timedelta(days=int(d["plazo"]))).isoformat()
            except ValueError:
                venc = None
        total = float(d["total"] or 0)
        # lo cobrado: del listado (total − por cobrar); sin listado, contado cobrado y crédito según la opción
        lst = _del_listado(listado or {}, d["consecutivo"])
        if estado == "rechazado" or d["tipo_documento"] == "03":
            pagado = 0.0
        elif lst and lst.get("por_cobrar") is not None:
            pc = float(lst["por_cobrar"])
            pagado = total if pc <= 0.005 else max(0.0, total - pc)   # sin redondear: una factura cobrada no deja medio céntimo pendiente
        elif d["condicion_venta"] == "01" or credito == "cobradas":
            pagado = total
        else:
            pagado = 0.0
        if lst and lst.get("vencimiento"):
            venc = lst["vencimiento"]
        nombre_xml = f"{d['clave']}.xml"
        (xml_dir / nombre_xml).write_bytes(datos)
        doc = Documento(empresa_id=eid, tipo_documento=d["tipo_documento"], clave=d["clave"], consecutivo=d["consecutivo"], fecha_emision=fecha,
                        cliente_id=cid, receptor_nombre=nombre_rec, moneda=d["moneda"], tipo_cambio=d["tipo_cambio"], total=total, impuesto=d["impuesto"], otros_impuestos=d["otros_impuestos"],
                        estado=estado, ambiente="produccion", mensaje_hacienda=mensaje, xml_nombre=nombre_xml, respuesta_nombre=resp_nombre,
                        fecha_envio=fecha, fecha_vencimiento=venc, pagado=pagado, referencia_clave=d["referencia_clave"], referencia_codigo=d["referencia_codigo"],
                        condicion_venta=d["condicion_venta"], otros_cargos=json.dumps(d["otros_cargos"], ensure_ascii=False) if d["otros_cargos"] else None,
                        iva_exonerado=round(sum(x["iva_exonerado"] for x in d["lineas"]), 5), importado_de=origen)
        s.add(doc); s.flush()
        for x in d["lineas"]:
            s.add(DocumentoLinea(documento_id=doc.id, numero=x["numero"], producto_id=productos.get(x["detalle"].strip().lower()), cabys=x["cabys"] or "",
                                 detalle=x["detalle"][:200], cantidad=x["cantidad"], unidad_medida=x["unidad_medida"] or "Unid", precio_unitario=x["precio_unitario"],
                                 descuento=x["descuento"], codigo_tarifa=x["codigo_tarifa"], tarifa=x["tarifa"], impuesto=x["impuesto"], total=x["total"],
                                 otros_impuestos=x["otros_impuestos"], iva_exonerado=x["iva_exonerado"]))
        res["importados"] += 1
        res["por_tipo"][d["tipo_documento"]] = res["por_tipo"].get(d["tipo_documento"], 0) + 1
        dia = fecha[:10]
        res["desde"] = min(res["desde"] or dia, dia); res["hasta"] = max(res["hasta"] or dia, dia)
        saldo = round(max(0.0, total - pagado), 2)
        if saldo > 0.005 and estado != "rechazado" and d["tipo_documento"] in ("01", "02", "04", "09"):
            res["por_cobrar"] += 1
            res["monto_por_cobrar"][d["moneda"]] = round(res["monto_por_cobrar"].get(d["moneda"], 0) + saldo, 2)
        k = d["tipo_documento"]
        maximos[k] = max(maximos.get(k, 0), int(d["consecutivo"][-10:]))
    # la serie de cada tipo sigue después del mayor importado (nunca se emite un número ya usado)
    for tipo, mx in maximos.items():
        seq = s.exec(select(Secuencia).where(Secuencia.empresa_id == eid, Secuencia.tipo_documento == tipo, Secuencia.ambiente == "produccion")).first()
        if seq is None:
            seq = Secuencia(empresa_id=eid, tipo_documento=tipo, ambiente="produccion", ultimo=mx)
        elif seq.ultimo < mx:
            seq.ultimo = mx
        s.add(seq)
    # respuestas de comprobantes importados en una carga anterior: se agregan a ese comprobante
    for clave, (r, datos) in respuestas.items():
        if clave in vistos or clave not in claves_existentes:
            continue
        doc = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
        if doc and doc.importado_de and not doc.respuesta_nombre:
            doc.respuesta_nombre = f"{clave}_respuesta.xml"; (xml_dir / doc.respuesta_nombre).write_bytes(datos)
            if r["mensaje"] == "3":
                doc.estado = "rechazado"
            s.add(doc); res["respuestas"] += 1
    sueltas = len([c for c in respuestas if c not in vistos and c not in claves_existentes])
    if sueltas:
        res["descartados"].append(f"{sueltas} respuesta(s) de Hacienda sin su comprobante en esta carga")
    s.commit()
    return res
