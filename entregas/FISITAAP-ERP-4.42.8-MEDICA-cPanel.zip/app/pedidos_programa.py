"""FISITAAP 4.32 · Pedidos en línea que atiende el programa de escritorio (bloque B4; plan reingenieria_432 §2.4, §3, §4; contrato_432).

Declara para el mecanismo único de sincronización (app/sinc_datos.py, P1) los dos datos de los pedidos:
- «pedido» (escribe la web, baja al programa): la web lo manda a los programas sin token, sin los datos del pago ni los ids de la web
  (cuenta_espera_id y documento_id, que en el programa son suyos), con la caja de los pedidos (_caja), su edad con el reloj de la web
  (edad_s) y la clave del comprobante enlazado (documento_clave). El programa pide en vivo «aceptar» y «cancelar».
- «cuenta» (escribe su dueño, sube a la web): la copia de la cuenta de un pedido en línea que vive en el programa. En la web va a
  sinc_dato.datos y NUNCA a pos_espera: de ella salen el seguimiento del cliente y el panel del motorizado (pedidos.estado_efectivo).

PARTE WEB (días 2-4 de B4): el filtro, los campos calculados y las acciones que corren en la web.
PARTE PROGRAMA (días 5-8): reconciliar_pedido (al_aplicar de «pedido»: crea UNA vez en la vida del pedido su cuenta y su comanda con a_caja
del programa, o quita la cuenta de un pedido que ya no atiende), aceptar, rechazar y cancelar pedidos a la web en el momento
(cambiar_en_programa), el aviso de pedido nuevo en la caja (ultimo_entrado_id) y la limpieza de copias viejas (la bandera pedidos_programa de
auth._info_empresa la escribió P1).
Si el mecanismo nuevo todavía no existe (sin app/sinc_datos.py), no se declara nada."""
import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

from fastapi import HTTPException
from sqlmodel import Session, select

from . import modulos, pedidos
from .config import ahora_cr
from .db import Documento
from .pedidos import NegocioPublico, Pedido

log = logging.getLogger(__name__)
HORAS_RECIENTE = 48            # §2.4: viaja el pedido activo o cambiado en las últimas 48 h
ACTIVOS = ("nuevo", "confirmado")


# ------------------------------------------------------------------------------------------------- filtro y campos calculados (web)
def _fecha(v) -> Optional[datetime]:
    try:
        d = datetime.fromisoformat(str(v or ""))
    except ValueError:
        return None
    return d if d.tzinfo is not None else d.replace(tzinfo=ahora_cr().tzinfo)


def pedido_que_viaja(p: dict) -> bool:
    """Filtro del dato «pedido»: en línea, no a crédito (los atiende y los cobra siempre la web, decisión del dueño), ya pagado o sin pago en
    línea pendiente (pendiente_pago no) y activo (nuevo o confirmado) o cambiado en las últimas 48 h. Un pedido que deja de pasarlo baja como
    lápida y el programa quita su copia (contrato §1.4)."""
    if not isinstance(p, dict) or (p.get("canal") or "online") != "online" or p.get("a_credito"):
        return False
    est = p.get("estado") or ""
    if est == "pendiente_pago":
        return False
    if est in ACTIVOS:
        return True
    d = _fecha(p.get("actualizado")) or _fecha(p.get("creado"))
    return bool(d and ahora_cr() - d <= timedelta(hours=HORAS_RECIENTE))


def cuenta_de_pedido(c: dict) -> bool:
    """Filtro del dato «cuenta»: solo las cuentas de pedidos en línea (las mesas no viajan entre la web y el programa, §6)."""
    return bool(isinstance(c, dict) and c.get("pedido_id"))


def etiqueta_cuenta(c: dict) -> str:
    """Etiqueta de la copia de la cuenta (sinc_dato.etiqueta, con índice): «pedido:<id>», la que busca pedidos.estado_efectivo."""
    return f"pedido:{c['pedido_id']}"


def caja_del_negocio(s: Session, eid: int, obj) -> Optional[int]:
    """«_caja»: la caja a la que entran los pedidos en la web (NegocioPublico.terminal_id). NegocioPublico no viaja: el programa arma con esto
    el negocio en memoria para a_caja (§4.3). Sin tienda o sin caja elegida: None (a_caja toma la primera)."""
    n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()
    return int(n.terminal_id) if n is not None and n.terminal_id else None


def edad_en_la_web(s: Session, eid: int, obj) -> Optional[int]:
    """«edad_s»: segundos desde que se creó el pedido, con el reloj de la web al enviarlo (§4.4: la comanda tardía no depende del reloj de
    la computadora)."""
    d = _fecha(getattr(obj, "confirmado", None) or getattr(obj, "creado", None))   # validación 4.32 (E): desde que se aceptó, si ya se aceptó
    return max(0, int((ahora_cr() - d).total_seconds())) if d else None


def clave_del_enlace(s: Session, eid: int, obj) -> Optional[str]:
    """«documento_clave»: la clave del comprobante enlazado al pedido en la web (el id de la web no le sirve al programa)."""
    did = getattr(obj, "documento_id", None)
    if not did:
        return None
    d = s.get(Documento, int(did))
    return d.clave if d is not None and d.empresa_id == eid else None


# ------------------------------------------------------------------------------------------------- acciones que pide el programa (web)
def terminal_del_token(s: Session, eid: int, ctx) -> Optional[int]:
    """La terminal de la instalación dueña del token de la llamada (su ficha en sinc_vinculacion), nunca la del cuerpo. None si el token no es
    de una instalación de esta empresa."""
    t = getattr(ctx, "terminal_sinc", None)
    if t:
        return int(t)
    try:
        from . import sinc
        inst = sinc._instalacion_de(sinc._leer(s, eid, sinc.CLAVE_VINC, {}), ctx)
        return int(inst.get("terminal") or 0) or None if inst else None
    except Exception:  # noqa: BLE001  (ante la duda, no entra)
        return None


def _pedido_de(s: Session, eid: int, ref) -> Pedido:
    try:
        p = s.get(Pedido, int(ref))
    except (TypeError, ValueError):
        p = None
    if p is None or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    return p


def _salida(s: Session, eid: int, p: Pedido) -> dict:
    s.refresh(p)
    return pedidos._con_atiende(s, eid, pedidos._salida_pedido(p, pedidos.estado_efectivo(s, eid, [p])[p.id]), p)


def aceptar_desde_programa(s: Session, eid: int, ctx, ref: str, datos: dict, por: Optional[str]) -> dict:
    """Acción «aceptar» (contrato §3.6): la misma cambiar_estado de la web, con el pedido para el programa que la pide (atiende = su terminal,
    solo si es la elegida en «Los pedidos en línea los atiende») y sin a_caja en la web: la cuenta y la comanda nacen en el programa.
    Idempotente: quien ya lo aceptó recibe 200 con el pedido (una respuesta perdida se vuelve a pedir sin error)."""
    t = terminal_del_token(s, eid, ctx)
    if not t:
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    pedidos._admin(ctx)
    p = _pedido_de(s, eid, ref)
    if p.estado == "confirmado" and int(p.atiende or 0) == t:
        return _salida(s, eid, p)
    datos = datos if isinstance(datos, dict) else {}
    return pedidos._cambiar_estado(p.id, pedidos.EstadoIn(estado="confirmado", reclama=bool(datos.get("reclama"))), ctx, s, terminal=t)


def cancelar_desde_programa(s: Session, eid: int, ctx, ref: str, datos: dict, por: Optional[str]) -> dict:
    """Acción «cancelar» (§4.7): solo el programa que atiende el pedido (o, si todavía es «nuevo», el programa elegido para atenderlos:
    rechazarlo); la rama de cancelar de siempre (comanda, entrega, cupón, puntos,
    tarjeta de regalo y correo) SIN pedir el reembolso a Tilopay: un pago en línea aprobado queda «reembolso pendiente». Con cualquier
    comprobante de ese pedido en la web: 409. Idempotente: ya cancelado por él, 200 con el pedido."""
    t = terminal_del_token(s, eid, ctx)
    if not t:
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    pedidos._admin(ctx)
    p = _pedido_de(s, eid, ref)
    a = int(p.atiende or 0)
    rechazar = a == 0 and p.estado in ("nuevo", "cancelado") and pedidos.pedidos_programa_para(s, eid, t)   # rechazar uno que nadie aceptó
    if p.estado == "cancelado" and (a == t or rechazar):
        return _salida(s, eid, p)
    if a != t and not rechazar:
        raise HTTPException(409, pedidos.TEXTO_CANCELAR_AJENO.format(nombre=pedidos.nombre_terminal(s, eid, a)) if a > 0 else pedidos.TEXTO_CANCELAR_WEB)
    datos = datos if isinstance(datos, dict) else {}
    motivo = " ".join(str(datos.get("motivo") or "").split())[:200]
    return pedidos._cambiar_estado(p.id, pedidos.EstadoIn(estado="cancelado", motivo=motivo), ctx, s, terminal=t)


# ------------------------------------------------------------------------------------------------- parte del programa (días 5-8)
# Todo esto corre en el PROGRAMA con el canal nuevo (pedidos.en_programa_v2). Ahí cada Pedido es una copia de la web (con sus campos propios
# cuenta_espera_id y documento_id, que el goteo no pisa). Lo que no puede pasar dos veces lo decide la web (aceptar, cancelar) y lo que pasa
# aquí (la cuenta, la comanda, el cobro) lo hace solo el dueño: este programa, si el pedido dice atiende == su terminal.
EQUIPO = "programa-pedidos"          # reclamo de cobro (4.31) que toma el programa sobre la cuenta de un pedido para quitarla o cancelarla
HORAS_TARDIA = 3                     # §4.4: un pedido que llega con más de esto no saca su comanda sola (se imprime a mano desde Cocina)
MINUTOS_ENTRADO = 10                 # §4.2: ultimo_entrado_id mira las cuentas de pedidos creadas aquí en estos minutos
DIAS_COPIAS = 3                      # §4.2: las copias de pedidos de más de esto se quitan (salvo las que atiende y siguen confirmadas)
HORAS_RECLAMO_CANCELAR = 24          # §4.7: cancelación sin respuesta: el cobro queda tomado hasta que el goteo traiga el estado
TEXTO_ENTRO = "Entró a la caja el pedido en línea #{n}."
TEXTO_ACEPTADO = "Pedido #{n} aceptado: ya está en la caja y su comanda sale sola en unos segundos."
TEXTO_SIN_CONEXION_ACEPTAR = "Sin conexión con la página web: el pedido no se aceptó. Revise el internet o acéptelo desde la página web."
TEXTO_SIN_CONEXION_CANCELAR = ("Sin conexión con la página web: el pedido no se puede cancelar ahora. Déjelo en la caja y cancélelo cuando "
                               "vuelva la conexión.")
TEXTO_COBROS_AQUI = "Este pedido ya tiene cobros en esta caja: anule la venta antes de cancelarlo."
TEXTO_CONFIRMANDO = "Confirmando con la página web…"
TEXTO_COBRANDO = "Están cobrando este pedido en la caja: espere a que termine y vuelva a intentarlo."
TEXTO_CANCELADO_PAGO = "Cancelado. El pago en línea se devuelve desde la página web o desde su cuenta de Tilopay."
TEXTO_CANCELAR_EN_WEB = "Este pedido se cancela en la página web."
SEGUNDOS_CONFIRMAR_CANCELAR = 120    # revisión n.º 28/29: una cancelación sin respuesta se pregunta a la web pasado este tiempo
SEGUNDOS_REVISAR_CANCELACIONES = 60  # cada cuánto confirmar_cancelaciones mira la base (si no hay cancelaciones sin respuesta, no sale a la red)
_purga: dict = {}
_revision: dict = {}
# revisión n.º 13: (eid, pid) de las cancelaciones que esta computadora está pidiendo a la web en este momento. Mientras viaja la petición,
# una versión anterior del pedido que llegue por el goteo («confirmado») no suelta el cobro que tomó la cancelación.
_en_vuelo: set = set()
_lock_vuelo = threading.Lock()


def cancelando(eid: int, pid) -> bool:
    try:
        k = (int(eid), int(pid))
    except (TypeError, ValueError):
        return False
    with _lock_vuelo:
        return k in _en_vuelo


def _sdp():
    from . import sinc_datos_programa
    return sinc_datos_programa


def _yo(s: Session, eid: int) -> int:
    """La terminal de esta computadora (sinc_local)."""
    try:
        return int(_sdp()._terminal(s, eid) or 0)
    except Exception:  # noqa: BLE001
        return 0


def _cuentas(s: Session, eid: int, p: Pedido) -> list:
    """Las cuentas vivas del pedido en la caja de este programa (la de cuenta_espera_id, partes y cuentas «aparte»)."""
    return [x for x in (modulos.leer(s, eid, "pos_espera", []) or []) if isinstance(x, dict) and x.get("id") is not None
            and ((p.cuenta_espera_id and x.get("id") == p.cuenta_espera_id) or str(x.get("pedido_id") or "") == str(p.id))]


def _doc_local(s: Session, eid: int, pid: int) -> bool:
    return s.exec(select(Documento.id).where(Documento.empresa_id == eid, Documento.pedido_id == pid)).first() is not None


def ya_tomado(s: Session, eid: int, p: Pedido) -> bool:
    """§4.3 (v2): la cuenta de un pedido se crea UNA vez en su vida: ya tiene cuenta_espera_id (a_caja la escribe en su mismo commit), o un
    comprobante de aquí con ese pedido, o la copia fija de su comanda. Con esto nunca se vuelve a llamar a a_caja, aunque la cuenta ya se
    haya cobrado y no esté en la caja.
    Revisión n.º 2: la copia que repuso comandas.conservar_comandas al restaurar un respaldo (cuenta_id = 0: su cuenta no existe en la base
    restaurada) no cuenta como «ya tomado»: la cuenta se vuelve a crear, pero la comanda, que ya salió, no se vuelve a imprimir."""
    if p.cuenta_espera_id or _doc_local(s, eid, p.id):
        return True
    from sqlalchemy import text
    try:
        return s.execute(text("SELECT 1 FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :p AND cuenta_id <> 0"),
                         {"e": eid, "p": p.id}).first() is not None
    except Exception:  # noqa: BLE001  (ante la duda, ya tomado: nunca dos cuentas)
        return True


def listo_de(datos: dict, hora: str, llegada: Optional[datetime] = None) -> Optional[str]:
    """§4.4: desde cuándo puede salir sola la comanda de un pedido que llega ahora. La edad la calcula la web con su reloj (edad_s): el pedido
    se creó en llegada − edad_s. Con menos de HORAS_TARDIA horas: lo más tarde entre la hora de siempre (listo_desde) y la llegada; con más:
    la hora de siempre (ya vencida: no sale sola). Uno programado para más tarde sale a su hora. Sin edad_s: None (la hora de siempre)."""
    from . import comandas
    try:
        edad = int((datos or {}).get("edad_s"))
    except (TypeError, ValueError):
        return None
    if edad < 0:
        return None
    llegada = llegada or ahora_cr()
    base = comandas._fecha(comandas.listo_desde(comandas._iso(llegada - timedelta(seconds=edad)), hora or "")) or llegada
    if edad >= HORAS_TARDIA * 3600:
        return comandas._iso(base)
    return comandas._iso(max(base, llegada))


def _reclamo(s: Session, eid: int, cid) -> Optional[dict]:
    from sqlalchemy import text
    f = s.execute(text("SELECT estado, equipo FROM cobro_reclamo WHERE empresa_id = :e AND cuenta_id = :c"), {"e": eid, "c": int(cid)}).first()
    return {"estado": f[0] or "", "equipo": f[1] or ""} if f else None


def _tomadas_al_cancelar(s: Session, eid: int, ids: list) -> list:
    out = []
    for c in ids:
        r = _reclamo(s, eid, c)
        if r and r["estado"] == "reclamada" and r["equipo"] == EQUIPO:
            out.append(c)
    return out


def _tomar_cobros(s: Session, eid: int, ids: list) -> bool:
    """Toma el reclamo de cobro 4.31 de cada cuenta (todo o nada). False si alguna está ocupada (alguien cobrando): suelta las tomadas."""
    from . import cobro_reclamo
    tomadas = []
    for c in ids:
        if cobro_reclamo.reclamar(s, eid, int(c), EQUIPO, EQUIPO, []).get("resultado") != "ganada":
            _soltar_cobros(s, eid, tomadas)
            return False
        tomadas.append(c)
    return True


def _soltar_cobros(s: Session, eid: int, ids: list) -> None:
    from . import cobro_reclamo
    for c in ids:
        cobro_reclamo.soltar(s, eid, int(c), EQUIPO, False, [])


def _alargar_cobros(s: Session, eid: int, ids: list) -> None:
    """§4.7 (v2): la cancelación no tuvo respuesta: el cobro de esas cuentas sigue tomado (no vence a los 60 s) hasta que el goteo traiga el
    estado del pedido (reconciliar_pedido lo suelta o quita las cuentas)."""
    from sqlalchemy import text
    vence = (ahora_cr() + timedelta(hours=HORAS_RECLAMO_CANCELAR)).isoformat(timespec="seconds")
    for c in ids:
        s.execute(text("UPDATE cobro_reclamo SET vence = :v WHERE empresa_id = :e AND cuenta_id = :c AND estado = 'reclamada' AND equipo = :q"),
                  {"v": vence, "e": eid, "c": int(c), "q": EQUIPO})
    s.commit()


def _quitar(s: Session, eid: int, p: Pedido, ids: list) -> None:
    """Quita las cuentas del pedido de la caja y cierra la copia de su comanda (ya tiene tomado el cobro de cada una)."""
    from . import comandas
    if ids:
        modulos.aplicar_cambios(s, eid, "pos_espera", [], list(ids), [])
    comandas.cerrar_copia(s, eid, p.id, "cancelado" if p.estado == "cancelado" else "lo atiende otro equipo")
    s.commit()
    _soltar_cobros(s, eid, ids)


def _cobrado_fuera(s: Session, eid: int, p: Pedido) -> None:
    """§4.3: la cuenta del pedido ya tiene cobros aquí pero el pedido se canceló o lo atiende otro (rescate): el aviso «cobrado fuera» en
    «Cambios que no quedaron» (sinc_pisado), una sola vez."""
    from sqlalchemy import text
    if s.execute(text("SELECT 1 FROM sinc_pisado WHERE tipo = 'pedido' AND ref = :r AND motivo = 'cobrado_fuera'"), {"r": str(p.id)}).first():
        return
    _sdp()._pisado(s, "pedido", str(p.id), "cobrado_fuera", {"numero": p.numero, "estado": p.estado}, f"Pedido #{p.numero}")
    s.commit()


def _enlazar_clave(s: Session, eid: int, p: Pedido, clave) -> None:
    """documento_clave de la web: el comprobante de aquí con esa clave queda como documento del pedido (solo para la pantalla)."""
    if p.documento_id or not clave:
        return
    d = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == str(clave))).first()
    if d is not None:
        p.documento_id = d.id; s.add(p); s.commit()


def reconciliar_pedido(s: Session, eid: int, fila: dict) -> bool:
    """al_aplicar del dato «pedido» (contrato §3.3; plan §4.3): deja la caja de este programa de acuerdo con la copia del pedido que acaba de
    llegar. Corre después del commit, dentro de aplicando(0) y con el candado de la empresa. True = terminó; False = volver a llamar en la
    vuelta siguiente (el cobro de su cuenta está ocupado).
    - confirmado, lo atiende esta computadora y no «ya tomado»: a_caja DEL PROGRAMA (número de comanda, copia fija, cuenta y
      cuenta_espera_id en un solo commit), con la caja de los pedidos de la web (_caja) y la hora de su comanda (listo_de).
    - confirmado y suyo con cuenta: si cambió lo prepagado (SINPE verificado tarde) y no hay cobros, lo reescribe. Un reclamo de una
      cancelación sin respuesta se suelta (la web no la canceló).
    - entregado (la web cerró su entrega) y suyo: la cuenta queda «entregado» para cobrarla.
    - cancelado o de otro (rescate): sin cobros, toma el cobro, quita la cuenta y cierra la copia de la comanda; con cobros o comprobante
      de aquí, el aviso «cobrado fuera»."""
    if not pedidos.en_programa_v2(eid):
        return True
    try:
        pid = int(fila.get("ref"))
    except (TypeError, ValueError):
        return True
    p = s.get(Pedido, pid)
    if p is None or p.empresa_id != eid:
        return True                                           # lápida o copia quitada: nada que hacer aquí
    datos = fila.get("datos") if isinstance(fila.get("datos"), dict) else {}
    _enlazar_clave(s, eid, p, datos.get("documento_clave"))
    yo = _yo(s, eid)
    suyo = yo > 0 and int(p.atiende or 0) == yo
    ctas = _cuentas(s, eid, p)
    ids = [c["id"] for c in ctas]
    if suyo and p.estado == "confirmado":
        if not cancelando(eid, p.id):                         # revisión n.º 13: con la cancelación en camino, una versión vieja no suelta el cobro
            _soltar_cobros(s, eid, _tomadas_al_cancelar(s, eid, ids))
        if not ctas:
            if not ya_tomado(s, eid, p):
                caja = datos.get("_caja")
                n = NegocioPublico(empresa_id=eid, slug="", terminal_id=int(caja) if isinstance(caja, int) and caja > 0 else None)
                pedidos.a_caja(s, eid, p, n, "aceptar", listo=listo_de(datos, p.hora_programada))
            return True
        pre = pedidos._prepago(p)
        if not any(c.get("cobros") for c in ctas) and p.cuenta_espera_id:
            from . import comandas
            comandas.reescribir_cuentas(s, eid, lambda c: c.get("id") == p.cuenta_espera_id and not c.get("cobros"),
                                        lambda c: None if c.get("prepago") == pre else {**c, "prepago": pre})
        return True
    if suyo and p.estado == "entregado":
        if ctas and not any(c.get("cobros") for c in ctas):
            from . import comandas
            ahora = ahora_cr().isoformat(timespec="seconds")
            comandas.reescribir_cuentas(s, eid, lambda c: c.get("id") in ids,
                                        lambda c: None if c.get("estado") == "entregado" else {**c, "estado": "entregado", "hora_entregado": ahora})
        return True
    if p.estado == "cancelado" or not suyo:
        if not ctas:
            if _doc_local(s, eid, p.id):
                _cobrado_fuera(s, eid, p)                     # ya se cobró aquí (la cuenta salió de la caja) y la web lo canceló o lo atiende otro
                return True
            if p.estado == "cancelado":
                from . import comandas
                if comandas.cerrar_copia(s, eid, p.id, "cancelado"):
                    s.commit()
            return True
        if any(c.get("cobros") for c in ctas) or _doc_local(s, eid, p.id):
            _soltar_cobros(s, eid, _tomadas_al_cancelar(s, eid, ids))
            _cobrado_fuera(s, eid, p)
            return True
        if not _tomar_cobros(s, eid, ids):
            return False                                      # alguien está cobrando: la vuelta siguiente
        _quitar(s, eid, p, ids)
    return True


def _por(ctx) -> Optional[str]:
    u = getattr(ctx, "usuario", None)
    from . import sinc
    return sinc._texto_por(str(getattr(u, "nombre", "") or "")) if u is not None else None


def _reconciliar_ahora(eid: int, pid: int, filas: list) -> None:
    """Después de una acción: reconciliar_pedido con la fila del pedido que trajo la respuesta (o la copia de aquí si no vino), igual que en
    el goteo (con el candado y dentro de aplicando). Ya tomado = no hace nada otra vez."""
    fila = next((f for f in filas or [] if isinstance(f, dict) and f.get("tipo") == "pedido" and str(f.get("ref")) == str(pid)), None)
    if fila is None:
        fila = {"tipo": "pedido", "ref": str(pid), "v": 0, "borrado": False, "campos": {}, "datos": None, "dueno": None, "origen": 0}
    _sdp()._al_aplicar(eid, fila)


def _salida_local(s: Session, eid: int, pid: int, resultado) -> dict:
    s.expire_all()
    p = s.get(Pedido, pid)
    if p is None or p.empresa_id != eid:
        return dict(resultado) if isinstance(resultado, dict) else {"id": pid}
    return pedidos._con_atiende(s, eid, pedidos._salida_pedido(p, pedidos.estado_efectivo(s, eid, [p])[p.id]), p)


def cambiar_en_programa(pid: int, data, ctx, s: Session) -> dict:
    """PUT /api/pedidos/{pid}/estado en el programa con el canal nuevo (§4.3, §4.7). La copia del pedido no se toca aquí: aceptar y cancelar
    (también rechazar uno nuevo) se piden a la web en el momento (sinc_datos_programa.pedir_accion); la respuesta se aplica, se reconcilia
    la caja (la cuenta y la comanda nacen aquí) y la pantalla recibe la copia de aquí, con su propia cuenta. Lo demás se hace en la web."""
    eid = ctx.empresa.id
    sdp = _sdp()
    p = s.get(Pedido, pid)
    if p is None or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    if data.estado not in pedidos.ESTADOS:
        raise HTTPException(400, "Estado desconocido")
    if data.estado == "confirmado":
        if data.aqui:
            raise HTTPException(409, pedidos.TEXTO_SOLO_WEB)
        try:
            j = sdp.pedir_accion(eid, "pedido", str(pid), "aceptar", {"reclama": bool(data.reclama)}, _por(ctx))
        except sdp.SinConexionWeb:
            raise HTTPException(409, TEXTO_SIN_CONEXION_ACEPTAR) from None
        except sdp.SinRespuestaWeb:
            raise HTTPException(409, TEXTO_CONFIRMANDO) from None
        _reconciliar_ahora(eid, pid, j.get("filas"))
        out = _salida_local(s, eid, pid, j.get("resultado"))
        out["mensaje"] = TEXTO_ACEPTADO.format(n=out.get("numero") or p.numero)
        return out
    if data.estado != "cancelado":
        raise HTTPException(409, pedidos.TEXTO_SOLO_WEB)
    if p.estado in ("cancelado", "entregado"):
        raise HTTPException(400, "Ese pedido ya está cerrado")
    if sdp.en_pausa(eid):                                       # revisión n.º 7/9/14: la página web no tiene el canal nuevo (o está apagado)
        raise HTTPException(409, TEXTO_CANCELAR_EN_WEB)
    yo = _yo(s, eid); a = int(p.atiende or 0)
    if not (a == yo and yo > 0) and not (a == 0 and p.estado == "nuevo"):
        raise HTTPException(409, pedidos.TEXTO_CANCELAR_AJENO.format(nombre=f"Computadora {a}") if a > 0 else pedidos.TEXTO_CANCELAR_WEB)
    motivo = " ".join(str(data.motivo or "").split())[:200]
    if not motivo:
        raise HTTPException(400, "Indique el motivo de la cancelación")
    ctas = _cuentas(s, eid, p)
    if _doc_local(s, eid, p.id) or any(c.get("cobros") for c in ctas):
        raise HTTPException(409, TEXTO_COBROS_AQUI)
    ids = [c["id"] for c in ctas]
    k = (int(eid), int(pid))
    with _lock_vuelo:
        _en_vuelo.add(k)                                        # revisión n.º 13: desde que se toma el cobro hasta que la web contesta
    try:
        if not _tomar_cobros(s, eid, ids):
            raise HTTPException(409, TEXTO_COBRANDO)
        pagado = p.pago_estado == "aprobado"
        try:
            j = sdp.pedir_accion(eid, "pedido", str(pid), "cancelar", {"motivo": motivo}, _por(ctx))
        except sdp.SinConexionWeb:
            _soltar_cobros(s, eid, ids)
            raise HTTPException(409, TEXTO_CANCELAR_EN_WEB if sdp.en_pausa(eid) else TEXTO_SIN_CONEXION_CANCELAR) from None
        except sdp.SinRespuestaWeb:
            _alargar_cobros(s, eid, ids)                        # la web pudo recibirla: el cobro sigue tomado hasta saberlo (confirmar_cancelaciones)
            raise HTTPException(409, TEXTO_CONFIRMANDO) from None
        except Exception:
            _soltar_cobros(s, eid, ids)
            raise
    finally:
        with _lock_vuelo:
            _en_vuelo.discard(k)
    _reconciliar_ahora(eid, pid, j.get("filas"))
    out = _salida_local(s, eid, pid, j.get("resultado"))
    if pagado:
        out["mensaje"] = TEXTO_CANCELADO_PAGO
    return out


def confirmar_cancelaciones(eid: int, forzar: bool = False) -> int:
    """Revisión n.º 28/29 (§4.7): una cancelación que no tuvo respuesta deja el cobro de la cuenta tomado HORAS_RECLAMO_CANCELAR horas, y si la
    web nunca la recibió no llega ninguna fila nueva que lo suelte. El hilo del canal (sinc_datos_programa, con conexión y sin pausa) llama a
    esto en cada vuelta: como mucho cada SEGUNDOS_REVISAR_CANCELACIONES, busca los cobros alargados por una cancelación de hace más de
    SEGUNDOS_CONFIRMAR_CANCELAR y le pregunta a la web (/datos/filas, solo lectura) cómo está cada pedido. Si sigue «confirmado» y lo atiende
    esta computadora, la web no lo canceló: el cobro se suelta. Si no (cancelado, de otro), se deja: el goteo trae la fila y reconciliar_pedido
    quita la cuenta. Sin cancelaciones sin respuesta no sale a la red. Devuelve cuántos cobros soltó. Nunca lanza."""
    ya = time.monotonic()
    if not forzar and ya - _revision.get(eid, -1e9) < SEGUNDOS_REVISAR_CANCELACIONES:
        return 0
    _revision[eid] = ya
    try:
        from sqlalchemy import text
        from .db import engine_empresa
        sdp = _sdp()
        ahora = ahora_cr()
        por_pedido: dict = {}
        with Session(engine_empresa(eid)) as s:
            yo = _yo(s, eid)
            if yo <= 0:
                return 0
            alargadas = set()
            for cid, vence in s.execute(text("SELECT cuenta_id, vence FROM cobro_reclamo WHERE empresa_id = :e AND estado = 'reclamada' AND equipo = :q"),
                                        {"e": eid, "q": EQUIPO}).all():
                v = _fecha(vence)
                if v is not None and v > ahora + timedelta(hours=1) \
                        and ahora - (v - timedelta(hours=HORAS_RECLAMO_CANCELAR)) >= timedelta(seconds=SEGUNDOS_CONFIRMAR_CANCELAR):
                    alargadas.add(int(cid))
            if not alargadas:
                return 0
            for p in s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.estado == "confirmado", Pedido.atiende == yo)).all():
                cids = [c["id"] for c in _cuentas(s, eid, p) if modulos._id_entero(c.get("id")) in alargadas]
                if cids:
                    por_pedido[int(p.id)] = cids
        if not por_pedido:
            return 0
        con = sdp._conexion(eid)
        if con is None:
            return 0
        url, token, _cfg = con
        refs = [{"tipo": "pedido", "ref": str(pid)} for pid in sorted(por_pedido)[:50]]
        r = sdp.httpx.post(url + sdp.RUTA_FILAS, headers={"Authorization": "Bearer " + token}, json={"refs": refs},
                           timeout=sdp.httpx.Timeout(sdp.PLAZO_LLAMADA, connect=3.0))
        j = r.json() if getattr(r, "status_code", 0) == 200 else None
        if not isinstance(j, dict) or not isinstance(j.get("filas"), list):
            return 0
        soltadas = 0
        for f in j["filas"]:
            if not isinstance(f, dict) or f.get("tipo") != "pedido" or f.get("estado") != "existe" or not isinstance(f.get("datos"), dict):
                continue
            try:
                pid = int(f.get("ref"))
                atiende = int(f["datos"].get("atiende") or 0)
            except (TypeError, ValueError):
                continue
            if pid not in por_pedido or f["datos"].get("estado") != "confirmado" or atiende != yo:
                continue
            with sdp.candado(eid):
                if cancelando(eid, pid):                        # el cajero la está pidiendo otra vez en este momento
                    continue
                with Session(engine_empresa(eid)) as s:
                    tomadas = _tomadas_al_cancelar(s, eid, por_pedido[pid])
                    _soltar_cobros(s, eid, tomadas)
                    soltadas += len(tomadas)
        return soltadas
    except Exception as ex:  # noqa: BLE001  sin datos del pedido en el registro: solo el tipo del error
        log.warning("Cancelaciones sin respuesta (empresa %s): %s", eid, type(ex).__name__)
        return 0


def ultimo_entrado_id(s: Session, eid: int) -> int:
    """§4.2: el mayor id de pedido con cuenta creada en esta caja en los últimos MINUTOS_ENTRADO minutos (los pagados con tarjeta nunca son
    «nuevo»: así el aviso de la caja suena igual). 0 si ninguno."""
    lim = ahora_cr() - timedelta(minutes=MINUTOS_ENTRADO)
    mayor = 0
    for c in modulos.leer(s, eid, "pos_espera", []) or []:
        if not isinstance(c, dict) or c.get("canal") != "online":
            continue
        try:
            pid = int(c.get("pedido_id") or 0)
        except (TypeError, ValueError):
            continue
        d = _fecha(c.get("creado"))
        if pid > mayor and d is not None and d >= lim:
            mayor = pid
    return mayor


def purgar_copias(s: Session, eid: int, forzar: bool = False) -> int:
    """§4.2: una vez por hora, quita las copias de pedidos de más de DIAS_COPIAS días, dentro de aplicando y sin lápida, salvo las que
    atiende esta computadora y siguen «confirmado». Devuelve cuántas quitó. Nunca lanza."""
    ya = time.monotonic()
    if not forzar and ya - _purga.get(eid, -1e9) < 3600:
        return 0
    _purga[eid] = ya
    try:
        from . import sinc_diario
        yo = _yo(s, eid)
        lim = (ahora_cr() - timedelta(days=DIAS_COPIAS)).isoformat(timespec="seconds")
        viejas = [p for p in s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.creado < lim)).all()
                  if not (yo > 0 and int(p.atiende or 0) == yo and p.estado == "confirmado")]
        if not viejas:
            return 0
        with sinc_diario.aplicando(0):
            for p in viejas:
                s.delete(p)
            s.commit()
        return len(viejas)
    except Exception as ex:  # noqa: BLE001
        log.warning("Limpieza de copias de pedidos (empresa %s): %s", eid, type(ex).__name__)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return 0


# ------------------------------------------------------------------------------------------------- declaraciones (contrato §1.5)
def _declarar() -> bool:
    """Registra «cuenta» y «pedido» en el mecanismo nuevo. Sin app/sinc_datos.py (todavía no programado), no hace nada. Un error de la
    declaración no tumba la web: se registra y la sincronización de pedidos queda apagada."""
    try:
        from .sinc_datos import DATOS, Dato, declarar
    except ImportError:
        return False
    try:
        if "cuenta" not in DATOS:
            declarar(Dato("cuenta", registro="pos_espera", escribe="dueno", dueno_de="rango", viaja="sube",
                          filtro=cuenta_de_pedido, etiqueta=etiqueta_cuenta,
                          refs={"lineas[].producto_id": "producto", "cliente_id": "cliente"}))
        if "pedido" not in DATOS:
            declarar(Dato("pedido", modelo=Pedido, escribe="web", viaja="baja", copia_local=True,
                          filtro=pedido_que_viaja,
                          no_viajan=("token", "clave_peticion", "pago_orden", "pago_auth", "pago_detalle", "sinpe_comprobante",
                                     "cuenta_espera_id", "documento_id"),
                          locales=("cuenta_espera_id", "documento_id"),
                          extra={"_caja": caja_del_negocio, "edad_s": edad_en_la_web, "documento_clave": clave_del_enlace},
                          refs={"lineas[].producto_id": "producto"},
                          al_aplicar=reconciliar_pedido,
                          acciones={"aceptar": aceptar_desde_programa, "cancelar": cancelar_desde_programa}))
        return True
    except Exception:  # noqa: BLE001
        log.exception("No se pudieron declarar los datos de pedidos para la sincronización")
        return False


DECLARADO = _declarar()
