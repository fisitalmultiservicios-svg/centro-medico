# -*- coding: utf-8 -*-
"""4.32 (B7): las rutas que alimentan las pantallas de la sincronización: «Cambios que no quedaron» y la franja del programa.

  GET  /api/sinc/datos/pisados?limite=200   lo que se perdió en un cambio (más nuevo primero) y cuántos faltan por ver
  POST /api/sinc/datos/pisados/vistos       los marca como vistos (solo en la empresa de la sesión)
  GET  /api/sinc/datos/franja               lo que espera a la página web (solo en el programa), lo no visto y los choques
  GET  /api/sinc/datos/choques              la lista de choques de la carga inicial (en la página web, vacía)

Con FE_SINC_DATOS=0 las cuatro contestan 404. Exigen el permiso «configurar» (administrador de la empresa). Si la tabla no existe en esa
empresa contestan listas vacías. Nada de esto escribe auditoría ni devuelve llaves delicadas.
"""
import json
from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text as _sql
from sqlmodel import Session

from . import sinc_datos
from .auth import Contexto, requiere, sesion_empresa

router = APIRouter(prefix="/api/sinc", tags=["sinc"])

TOPE = 200
MAXIMO = 500
DELICADAS = ("token", "clave", "contrasena", "contraseña", "password", "pin", "hash", "secreto", "firma", "llave")

TIPOS = {
    "producto": "Ítem", "item": "Ítem", "cliente": "Cliente", "categoria": "Categoría", "pedido": "Pedido", "cuenta": "Cuenta",
    "caja": "Caja", "impresora": "Impresora", "item_extra": "Extra de ítem", "lista_precios": "Lista de precios", "modificador": "Opción",
    "promo": "Promoción", "promo_pos": "Promoción", "receta": "Receta",
}

TEXTOS = {
    "conflicto": "Este dato se cambió en dos lugares a la vez. Quedó el cambio más reciente y el otro no se guardó.",
    "eliminado": "Este dato ya estaba eliminado, por eso el cambio hecho después no se guardó.",
    "no_dueno": "Solo la caja que creó este dato puede cambiarlo. El cambio hecho desde otra caja no se guardó.",
    "no_valido": "El cambio no cumplía las reglas de este dato (por ejemplo, faltaba algo obligatorio) y no se guardó.",
    "codigo_repetido": "El código que se quiso usar ya lo tiene otro ítem, por eso el cambio no se guardó.",
    "ocupado": "Otra caja ya estaba atendiendo este pedido, por eso el cambio no se guardó.",
    "freno": "Se hicieron demasiados cambios en poco tiempo y se detuvieron por seguridad. Este no se guardó.",
    "plan_vencido": "El plan de la empresa está vencido, por eso este cambio no se guardó. Renueve el plan para poder guardar cambios.",
    "programa_anterior": "Este cambio vino de una versión anterior de este programa y no se pudo guardar. Actualice el programa.",
    "datos_locales": "Este dato se mantiene solo en esta computadora y no se comparte con la página web.",
    "cobrado_fuera": "Este pedido se cobró aquí después de que la página web lo canceló o lo pasó a otra caja. Revise que no se haya cobrado dos veces.",
}
TEXTO_GENERICO = "Un cambio no se guardó porque ya había otro más reciente en su lugar."


def _hay_tabla(s: Session, nombre: str) -> bool:
    return s.connection().execute(_sql("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = :n"), {"n": nombre}).first() is not None


def _delicada(llave: Any) -> bool:
    k = str(llave).lower()
    return any(p in k for p in DELICADAS)


def limpiar(x: Any) -> Any:
    """Quita, a cualquier profundidad, toda llave cuyo nombre sea delicado."""
    if isinstance(x, dict):
        return {k: limpiar(v) for k, v in x.items() if not _delicada(k)}
    if isinstance(x, list):
        return [limpiar(v) for v in x]
    return x


def _perdio(crudo) -> Any:
    try:
        return limpiar(json.loads(crudo)) if crudo else None
    except (TypeError, ValueError):
        return None                                     # se guardó cortado (4000): mejor nada que un texto con datos delicados


def _fila(r) -> dict:
    tipo = r[2] or ""
    return {"id": r[0], "cuando": r[1], "tipo": tipo, "tipo_nombre": TIPOS.get(tipo, "Dato"), "ref": r[3], "nombre": r[4] or "", "campo": r[5] or "",
            "motivo": r[6], "texto": TEXTOS.get(r[6], TEXTO_GENERICO), "perdio": None if _delicada(r[5] or "") else _perdio(r[7]), "perdio_de": r[8] or "", "quedo_de": r[9] or "",
            "visto": bool(r[10])}


def _sin_ver(s: Session) -> int:
    if not _hay_tabla(s, "sinc_pisado"):
        return 0
    return int(s.connection().execute(_sql("SELECT COUNT(*) FROM sinc_pisado WHERE visto = 0")).scalar() or 0)


def _choques(s: Session, eid: int) -> list:
    from . import sinc_completar
    try:
        lista = sinc_completar.lista_choques(s, eid)
    except Exception:  # noqa: BLE001
        return []
    return [{**x, "tipo_nombre": TIPOS.get(x.get("tipo") or "", "Dato"), "detalle": limpiar(x.get("detalle"))} for x in lista]


@router.get("/datos/pisados", dependencies=[Depends(sinc_datos._encendido)])
def pisados(limite: int = Query(TOPE, ge=1, le=MAXIMO), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    if not _hay_tabla(s, "sinc_pisado"):
        return {"pisados": [], "sin_ver": 0}
    filas = s.connection().execute(_sql("SELECT id, cuando, tipo, ref, nombre, campo, motivo, perdio, perdio_de, quedo_de, visto FROM sinc_pisado "
                                        "ORDER BY id DESC LIMIT :n"), {"n": int(limite)}).all()
    return {"pisados": [_fila(r) for r in filas], "sin_ver": _sin_ver(s)}


@router.post("/datos/pisados/vistos", dependencies=[Depends(sinc_datos._encendido)])
def pisados_vistos(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    if not _hay_tabla(s, "sinc_pisado"):
        return {"ok": True, "marcados": 0}
    n = s.connection().execute(_sql("UPDATE sinc_pisado SET visto = 1 WHERE visto = 0")).rowcount or 0
    s.commit()
    return {"ok": True, "marcados": int(n)}


@router.get("/datos/franja", dependencies=[Depends(sinc_datos._encendido)])
def franja(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    espera = {"cambios": 0, "ventas": 0, "pausa": False}
    if sinc_datos._es_programa():
        try:
            from . import sinc_datos_programa
            espera = sinc_datos_programa.en_espera(eid)
        except Exception:  # noqa: BLE001
            espera = {"cambios": 0, "ventas": 0, "pausa": False}
    return {"cambios": int(espera.get("cambios") or 0), "ventas": int(espera.get("ventas") or 0), "pausa": bool(espera.get("pausa")),
            "sin_ver": _sin_ver(s), "choques": len(_choques(s, eid))}


@router.get("/datos/choques", dependencies=[Depends(sinc_datos._encendido)])
def choques(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    return {"choques": _choques(s, ctx.empresa.id)}
