"""Asistente con IA (3.56, fase 10). Usa la API de Claude (Anthropic) con la clave del administrador del sistema.

Dónde ayuda
- Catálogo en línea (FISITAAP): un botón «Preguntar» en el catálogo responde dudas del cliente con el menú, precios, horarios y
  formas de entrega del negocio. Solo contesta con esos datos; nunca inventa precios ni pide datos personales.
- Negocio: «Resumen con IA» en Inicio (ventas, pedidos y tickets del periodo en lenguaje sencillo, con dos acciones sugeridas),
  «Redactar con IA» la descripción pública de un ítem y «Borrador con IA» de la respuesta a un ticket de TiKe.

Cómo se administra
- La clave de la API (una sola, de Norman) se guarda cifrada con la clave maestra en data/ia.json desde la consola
  (Administración › IA): modelo, activo, límite mensual de consultas por empresa. ANTHROPIC_API_KEY en el servidor sirve de
  respaldo. Cada empresa enciende el asistente en Configuración › Asistente con IA y elige dónde lo usa.
- Cada consulta queda en UsoIA (central: empresa, tipo, modelo, tokens) para ver el consumo y aplicar el límite mensual.
- Modelo por defecto claude-opus-5-5 con esfuerzo bajo (respuestas cortas); el administrador puede elegir Sonnet 5.5 o Haiku 5.5.
  Con Opus y Sonnet se piden los «fallbacks» del servidor: si un filtro de seguridad rechaza la petición, la API la reintenta sola."""
import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

anthropic = None   # el SDK se importa la primera vez que hace falta (3.72): cargarlo tarda ~3 s y encarecía cada arranque del servidor


def _sdk():
    """El paquete `anthropic`, importado bajo demanda; None si no está instalado (la función queda apagada con un aviso claro)."""
    global anthropic
    if anthropic is None:
        try:
            import anthropic as _a
        except ImportError:
            return None
        anthropic = _a
    return anthropic


_instalado: Optional[bool] = None


def _paquete() -> bool:
    """3.87: ¿está instalado el SDK? Sin importarlo (importarlo tarda varios segundos y solo hace falta al llamar a la API)."""
    global _instalado
    if anthropic is not None:
        return True
    if _instalado is None:
        import importlib.util
        try:
            _instalado = importlib.util.find_spec("anthropic") is not None
        except (ImportError, ValueError):
            _instalado = False
    return _instalado

from . import modulos, planes, secretos
from .auth import Contexto, Usuario, contexto, limitar_ip, requiere, sesion_empresa, superadmin
from .config import DATA_DIR, ahora_cr, nombre_sistema
from .db import Documento, Empresa, central, engine, get_session, sesion_de

log = logging.getLogger(__name__)
router = APIRouter(tags=["ia"])
ARCHIVO = DATA_DIR / "ia.json"
MODELOS = {"claude-opus-5-5": "Claude Opus 5.5 · el más capaz (USD 4 / 20 por millón de tokens)",
           "claude-sonnet-5-5": "Claude Sonnet 5.5 · equilibrio entre calidad y costo (USD 2 / 10)",
           "claude-haiku-5-5": "Claude Haiku 5.5 · el más rápido y barato (USD 0,10 / 0,50)"}
MODELO_DEFECTO = "claude-opus-5-5"
LIMITE_MES_DEFECTO = 300
USOS = ("catalogo", "resumen", "producto", "ticket", "prueba")
DEFECTO_EMPRESA = {"activo": False, "catalogo": False, "resumen": True, "productos": True, "tickets": True}


class UsoIA(SQLModel, table=True):
    """Consumo por consulta (central): para el límite mensual por empresa y la consola."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    tipo: str = "catalogo"
    modelo: str = ""
    tokens_entrada: int = 0
    tokens_salida: int = 0
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


central(UsoIA)


# ------------------------------------------------------------------------------------------------- configuración del sistema
def _leer_config() -> dict:
    try:
        return json.loads(ARCHIVO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _descifrar(v: Optional[str]) -> str:
    if not v:
        return ""
    try:
        return secretos._maestra.decrypt(v.encode()).decode()
    except Exception:  # noqa: BLE001
        return ""


def credenciales() -> Optional[str]:
    cfg = _leer_config()
    if cfg:
        if not cfg.get("activo"):
            return None
        k = _descifrar(cfg.get("key"))
    else:
        k = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    return k or None


def disponible() -> bool:
    # 3.87: primero la llave y después si el paquete está instalado, sin importarlo: /api/ia/config (Inicio) y el catálogo público
    # pagaban varios segundos de import en la primera visita de cada proceso aunque no hubiera llave
    return credenciales() is not None and _paquete()


def modelo_actual() -> str:
    m = _leer_config().get("modelo") or MODELO_DEFECTO
    return m if m in MODELOS else MODELO_DEFECTO


def limite_mes() -> int:
    try:
        return max(0, int(_leer_config().get("limite_mes", LIMITE_MES_DEFECTO)))
    except (TypeError, ValueError):
        return LIMITE_MES_DEFECTO


def _resumen_config() -> dict:
    cfg = _leer_config(); k = _descifrar(cfg.get("key")) if cfg else os.environ.get("ANTHROPIC_API_KEY", "").strip()
    return {"proveedor": "Anthropic (Claude)", "paquete": _paquete(), "origen": "consola" if cfg else ("variable del servidor" if k else None), "activo": bool(cfg.get("activo")) if cfg else bool(k),
            "llave": ("…" + k[-4:]) if k else "", "modelo": modelo_actual(), "modelos": MODELOS, "limite_mes": limite_mes(), "actualizado": cfg.get("actualizado"), "ultima_prueba": cfg.get("ultima_prueba")}


# ------------------------------------------------------------------------------------------------- la llamada
def _cliente():
    if _sdk() is None:
        raise HTTPException(503, "El paquete de IA no está instalado en el servidor (pip install anthropic)")
    key = credenciales()
    if not key:
        raise HTTPException(503, "El asistente con IA no está configurado en el servidor")
    return anthropic.Anthropic(api_key=key, timeout=60.0, max_retries=1)


def _llamar(sistema: str, mensajes: list, max_tokens: int = 1024, effort: str = "low", modelo: Optional[str] = None) -> tuple[str, dict]:
    """Una petición a Claude. Devuelve (texto, uso). Las pruebas sustituyen esta función."""
    modelo = modelo or modelo_actual(); c = _cliente()
    kw = dict(model=modelo, max_tokens=max_tokens, system=[{"type": "text", "text": sistema, "cache_control": {"type": "ephemeral"}}], messages=mensajes, output_config={"effort": effort})
    try:
        if modelo in ("claude-opus-5-5", "claude-sonnet-5-5"):      # fallbacks del servidor: si un filtro rechaza la petición, la API la reintenta sola en otro modelo
            r = c.beta.messages.create(betas=["server-side-fallback-2026-07-01"], fallbacks="default", **kw)
        else:
            r = c.messages.create(**kw)
    except anthropic.AuthenticationError:
        raise HTTPException(502, "La clave de la IA no es válida: revísela en Administración › IA")
    except anthropic.RateLimitError:
        raise HTTPException(503, "El proveedor de IA está saturado; intente de nuevo en un momento")
    except anthropic.APIConnectionError:
        raise HTTPException(504, "No se pudo conectar con el proveedor de IA")
    except anthropic.APIStatusError as ex:
        raise HTTPException(502, f"El proveedor de IA respondió con error ({ex.status_code})")
    if r.stop_reason == "refusal":
        raise HTTPException(400, "La IA no puede responder a esa solicitud")
    texto = "".join(b.text for b in r.content if b.type == "text").strip()
    return texto, {"modelo": r.model, "entrada": int(r.usage.input_tokens or 0), "salida": int(r.usage.output_tokens or 0)}


def _registrar_uso(eid: int, tipo: str, uso: dict) -> None:
    try:
        with Session(engine) as sc:
            sc.add(UsoIA(empresa_id=eid, tipo=tipo, modelo=uso.get("modelo") or "", tokens_entrada=uso.get("entrada", 0), tokens_salida=uso.get("salida", 0))); sc.commit()
    except Exception:  # noqa: BLE001
        log.warning("IA: no se registró el uso de la empresa %s", eid)


def uso_mes(eid: int) -> int:
    inicio = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    with Session(engine) as sc:
        return len(sc.exec(select(UsoIA.id).where(UsoIA.empresa_id == eid, UsoIA.creado >= inicio, UsoIA.tipo != "prueba")).all())


def _verificar_limite(eid: int) -> None:
    lim = limite_mes()
    if lim and uso_mes(eid) >= lim:
        raise HTTPException(429, f"Esta empresa ya usó las {lim} consultas de IA del mes")


def config_empresa(s: Session, eid: int) -> dict:
    v = modulos.leer(s, eid, "ia_config", None)
    return {**DEFECTO_EMPRESA, **(v if isinstance(v, dict) else {})}


def _exigir(s: Session, e: Empresa, uso: str) -> dict:
    if not disponible():
        raise HTTPException(503, "El asistente con IA no está disponible en este servidor")
    cfg = config_empresa(s, e.id)
    if not cfg.get("activo") or not cfg.get(uso, True):
        raise HTTPException(403, "El asistente con IA está apagado para esta función: enciéndalo en Configuración › Asistente con IA")
    _verificar_limite(e.id)
    return cfg


def _limpiar(texto: str, maximo: int) -> str:
    return re.sub(r"\s+", " ", str(texto or "")).strip()[:maximo]


# ------------------------------------------------------------------------------------------------- catálogo en línea (público)
class PreguntaIn(BaseModel):
    pregunta: str = PField(min_length=1, max_length=600)
    historial: list = PField(default_factory=list, max_length=12)      # [{rol: 'cliente'|'asistente', texto}]


def _prompt_catalogo(d: dict) -> str:
    cats: dict = {}
    for it in d.get("items", []):
        cats.setdefault(it.get("categoria") or "Otros", []).append(it)
    lineas = []
    for cat, items in cats.items():
        lineas.append(f"## {cat}")
        for it in items:
            ops = "; ".join(f"{g.get('nombre')}: " + ", ".join(f"{o.get('nombre')}{' +₡' + format(o.get('precio') or 0, ',.0f') if o.get('precio') else ''}" for o in g.get("opciones", [])) for g in it.get("modificadores", []) if g.get("opciones"))
            lineas.append(f"- {it['nombre']} — ₡{float(it.get('precio') or 0):,.0f}" + (f" — {it['descripcion']}" if it.get("descripcion") else "") + (" (AGOTADO hoy)" if it.get("agotado") else "") + (f" — opciones: {ops}" if ops else ""))
    hor = d.get("horarios") or []; dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
    horario = ", ".join(f"{dias[i]} {h[0]}–{h[1]}" if h and h[0] else f"{dias[i]} cerrado" for i, h in enumerate(hor)) if hor and any(hor) else "no indicado (sin horario fijo)"
    ac = d.get("acepta") or {}
    entregas = ", ".join(x for x, ok in (("recoger en el local", ac.get("recoger")), ("a domicilio", ac.get("domicilio")), ("envío por coordinar", ac.get("coordinado"))) if ok) or "no indicado"
    return (f"Eres el asistente del negocio «{d.get('nombre')}» en su catálogo de pedidos en línea (Costa Rica). Respondes SOLO con la información de abajo: menú o catálogo, precios (ya incluyen IVA, en colones), "
            "horarios, formas de entrega, envío y cómo pedir. Si algo no está en los datos, dilo con claridad y sugiere escribir por WhatsApp; nunca inventes precios, productos ni promociones. "
            "Responde corto (máximo 80 palabras), amable, en español de Costa Rica y tratando de usted. No pidas datos personales ni de pago; los pedidos se hacen con los botones del catálogo.\n\n"
            f"# Datos del negocio\nDescripción: {d.get('descripcion') or d.get('bienvenida') or '—'}\nHorario: {horario}\nAhora mismo: {'abierto' if (d.get('abierto') or {}).get('abierto') else 'cerrado'}\n"
            f"Formas de entrega: {entregas}\nCosto de envío a domicilio: ₡{float(d.get('costo_envio') or 0):,.0f}{' (o según la zona en el mapa)' if d.get('con_zonas') else ''}\nPedido mínimo: ₡{float(d.get('minimo_pedido') or 0):,.0f}\n"
            f"Tiempo estimado: {d.get('tiempo_estimado') or '—'}\nAviso al cliente: {d.get('nota_cliente') or '—'}\nWhatsApp: {d.get('whatsapp') or '—'} · Teléfono: {d.get('telefono') or '—'}\n\n# Catálogo\n" + "\n".join(lineas))


@router.post("/api/publico/{slug}/ia")
def pregunta_catalogo(slug: str, data: PreguntaIn, request: Request):
    from . import pedidos
    e, eid = pedidos._publico(slug)
    limitar_ip(request, clave="ia", maximo=40, ventana=3600, mensaje="Demasiadas preguntas seguidas. Espere unos minutos o escríbanos por WhatsApp.")
    with sesion_de(eid) as s:
        n = pedidos._negocio(s, eid)
        if not n.activo or n.slug != slug:
            raise HTTPException(404, "Este negocio no está publicado")
        _exigir(s, e, "catalogo")
    d = pedidos.datos_publicos(slug)
    mensajes = []
    for h in data.historial[-10:]:
        if isinstance(h, dict) and h.get("texto"):
            mensajes.append({"role": "assistant" if h.get("rol") == "asistente" else "user", "content": _limpiar(h["texto"], 600)})
    if mensajes and mensajes[0]["role"] != "user":
        mensajes = mensajes[1:]
    mensajes.append({"role": "user", "content": _limpiar(data.pregunta, 600)})
    try:
        texto, uso = _llamar(_prompt_catalogo(d), mensajes, max_tokens=400, effort="low")
    except HTTPException as ex:                        # al cliente no se le cuentan detalles internos (clave, proveedor)
        log.warning("IA catálogo %s: %s", slug, ex.detail)
        raise HTTPException(503 if ex.status_code != 400 else 400, "El asistente no está disponible en este momento" if ex.status_code != 400 else str(ex.detail))
    _registrar_uso(eid, "catalogo", uso)
    return {"respuesta": texto}


# ------------------------------------------------------------------------------------------------- dentro del sistema
class ResumenIn(BaseModel):
    desde: Optional[str] = PField(None, max_length=10)
    hasta: Optional[str] = PField(None, max_length=10)


@router.post("/api/ia/resumen")
def resumen_negocio(data: ResumenIn, ctx: Contexto = Depends(requiere("ver_todo")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa; eid = e.id; _exigir(s, e, "resumen")
    hoy = ahora_cr().date(); desde = (data.desde or hoy.replace(day=1).isoformat())[:10]; hasta = (data.hasta or hoy.isoformat())[:10]
    docs = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.fecha_emision >= desde, Documento.fecha_emision <= hasta + "T99", Documento.tipo_documento.in_(("01", "04")))).all()  # type: ignore[attr-defined]
    fija = ctx.sucursal if getattr(ctx, "sucursal_fija", False) else None   # 3.87: el amarrado a una sucursal, solo lo de ella (como /api/resumen)
    if fija is not None:
        from .sucursales import pertenece
        docs = [d for d in docs if pertenece(d, fija)]
    validos = [d for d in docs if d.estado not in ("rechazado", "error")]
    por_dia: dict = {}; clientes: dict = {}
    for d in validos:
        por_dia[d.fecha_emision[:10]] = por_dia.get(d.fecha_emision[:10], 0) + float(d.total or 0)
        k = d.receptor_nombre or "Consumidor final"; clientes[k] = clientes.get(k, 0) + float(d.total or 0)
    top_clientes = sorted(clientes.items(), key=lambda kv: -kv[1])[:5]
    partes = [f"Periodo: {desde} a {hasta}. Comprobantes de venta válidos: {len(validos)} (rechazados o con error: {len(docs) - len(validos)}). Total vendido: ₡{sum(float(d.total or 0) for d in validos):,.0f}.",
              "Ventas por día: " + ("; ".join(f"{k}: ₡{v:,.0f}" for k, v in sorted(por_dia.items())) or "ninguna") + ".",
              "Clientes que más compraron: " + ("; ".join(f"{k}: ₡{v:,.0f}" for k, v in top_clientes) or "—") + "."]
    try:
        ventas_pos = [v for v in (modulos.leer(s, eid, "pos_ventas", []) or []) if isinstance(v, dict) and desde <= str(v.get("hora") or v.get("fecha") or "")[:10] <= hasta]
        if fija is not None:                     # 3.87: las ventas de caja y los pedidos en línea no se separan por sucursal: no van
            ventas_pos = []
        if ventas_pos:
            medios: dict = {}
            for v in ventas_pos:
                for m in v.get("medios") or []:
                    medios[m.get("medio")] = medios.get(m.get("medio"), 0) + float(m.get("monto") or 0)
            partes.append(f"Punto de venta: {len(ventas_pos)} ventas por ₡{sum(float(v.get('total') or 0) for v in ventas_pos):,.0f}; por medio de pago: " + ", ".join(f"{k}: ₡{v:,.0f}" for k, v in medios.items()) + ".")
    except Exception:  # noqa: BLE001
        pass
    if "pedidos_online" in planes.modulos_de(e) and fija is None:
        from .pedidos import NOMBRES_ESTADO as NE, Pedido
        ps = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.creado >= desde, Pedido.creado <= hasta + "T99")).all()
        if ps:
            est: dict = {}
            for p in ps:
                est[NE.get(p.estado, p.estado)] = est.get(NE.get(p.estado, p.estado), 0) + 1
            vivos = [p for p in ps if p.estado != "cancelado"]       # 4.40: el monto sin los cancelados, como el tablero (fisitaap.resumen)
            partes.append(f"Pedidos en línea: {len(ps)} (" + ", ".join(f"{k}: {v}" for k, v in est.items()) + f"); monto sin los cancelados: ₡{sum(float(p.total or 0) for p in vivos):,.0f}.")
    if "tike" in planes.modulos_de(e):
        from .tike import ABIERTOS, Ticket
        ts = s.exec(select(Ticket).where(Ticket.empresa_id == eid)).all()
        abiertos = [t for t in ts if t.estado in ABIERTOS]; ahora = ahora_cr().isoformat(timespec="seconds")
        partes.append(f"TiKe: {len(abiertos)} tickets abiertos, {sum(1 for t in abiertos if t.vence and t.vence < ahora)} vencidos; {sum(1 for t in ts if desde <= t.creado[:10] <= hasta)} abiertos en el periodo.")
    sistema = (f"Eres el asesor de confianza del dueño de «{e.nombre_comercial or e.nombre}», una empresa en Costa Rica que usa {nombre_sistema()}. Con los datos que te den, escribe un resumen en lenguaje sencillo: "
               "entre 6 y 10 líneas, cifras en colones con separador de miles, qué llama la atención (subidas, bajadas, concentración en pocos clientes, pendientes) y termina con dos acciones concretas sugeridas. "
               "Trata de usted, sin tecnicismos, sin inventar datos que no estén en el texto. Si hay pocos datos, dilo y sugiere qué registrar.")
    texto, uso = _llamar(sistema, [{"role": "user", "content": "\n".join(partes)}], max_tokens=900, effort="low")
    _registrar_uso(eid, "resumen", uso)
    return {"resumen": texto, "datos": partes}


class ProductoIn(BaseModel):
    nombre: str = PField(min_length=2, max_length=120)
    categoria: Optional[str] = PField("", max_length=60)
    descripcion: Optional[str] = PField("", max_length=600)
    notas: Optional[str] = PField("", max_length=300)        # ingredientes, tamaño, qué lo hace especial


@router.post("/api/ia/producto")
def describir_producto(data: ProductoIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa; _exigir(s, e, "productos")
    sistema = (f"Escribes descripciones para el catálogo en línea de «{e.nombre_comercial or e.nombre}» (Costa Rica). Devuelve SOLO la descripción: una o dos frases, máximo 220 caracteres, en español de Costa Rica, "
               "clara y apetecible, sin precios, sin emojis, sin comillas ni comillas angulares, sin repetir el nombre del producto al inicio. No inventes ingredientes ni características que no se mencionen.")
    pedido = f"Producto: {data.nombre}\nCategoría: {data.categoria or '—'}\nDescripción interna: {data.descripcion or '—'}\nNotas: {data.notas or '—'}"
    texto, uso = _llamar(sistema, [{"role": "user", "content": pedido}], max_tokens=200, effort="low")
    _registrar_uso(e.id, "producto", uso)
    return {"descripcion_publica": _limpiar(texto.strip('"«»'), 300)}


class BorradorIn(BaseModel):
    instruccion: Optional[str] = PField("", max_length=400)   # p. ej. «dile que vamos mañana a las 9»


@router.post("/api/ia/ticket/{tid}/borrador")
def borrador_ticket(tid: int, data: BorradorIn, ctx: Contexto = Depends(requiere("tike")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa; _exigir(s, e, "tickets")
    from .tike import NOMBRES_ESTADO, Ticket, TicketEntrada, _ticket
    t = _ticket(s, e.id, tid)
    entradas = s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all()[-14:]
    hilo = "\n".join(f"[{x.creado[:16]}] {'CLIENTE' if x.tipo == 'cliente' else 'TÉCNICO ' + x.usuario if x.tipo == 'respuesta' else 'NOTA INTERNA ' + x.usuario if x.tipo == 'nota' else x.tipo.upper()}: {_limpiar(x.texto, 700)}" for x in entradas)
    sistema = (f"Eres técnico de soporte de «{e.nombre_comercial or e.nombre}» y redactas la respuesta que se enviará al cliente por correo desde el sistema de tickets. Escribe SOLO el texto de la respuesta (sin asunto ni firma): "
               "cordial, breve (máximo 120 palabras), trato de usted, español de Costa Rica. Apóyate únicamente en la bitácora; si falta información, haz una o dos preguntas concretas. No prometas plazos ni soluciones que no estén en las notas. "
               "Las notas internas son para ti: no las cites textualmente.")
    pedido = f"Ticket {t.codigo} · estado {NOMBRES_ESTADO.get(t.estado, t.estado)} · prioridad {t.prioridad}\nCliente: {t.cliente_nombre or t.solicitante or '—'} (solicita: {t.solicitante or '—'})\nAsunto: {t.asunto}\nDescripción: {_limpiar(t.descripcion, 1500)}\n\nBitácora:\n{hilo or '(sin entradas)'}" + (f"\n\nIndicación del técnico para esta respuesta: {_limpiar(data.instruccion, 400)}" if data.instruccion else "")
    texto, uso = _llamar(sistema, [{"role": "user", "content": pedido}], max_tokens=500, effort="low")
    _registrar_uso(e.id, "ticket", uso)
    return {"borrador": texto}


# ------------------------------------------------------------------------------------------------- configuración por empresa
class ConfigEmpresaIn(BaseModel):
    activo: bool = False
    catalogo: bool = False
    resumen: bool = True
    productos: bool = True
    tickets: bool = True


def _salida_empresa(s: Session, e: Empresa) -> dict:
    return {**config_empresa(s, e.id), "disponible": disponible(), "modelo": MODELOS.get(modelo_actual(), modelo_actual()), "uso_mes": uso_mes(e.id), "limite_mes": limite_mes(),
            "tiene_catalogo": "pedidos_online" in planes.modulos_de(e), "tiene_tike": "tike" in planes.modulos_de(e)}


@router.get("/api/ia/config")
def ver_config_empresa(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    return _salida_empresa(s, ctx.empresa)


@router.put("/api/ia/config")
def guardar_config_empresa(data: ConfigEmpresaIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    r = modulos._registro(s, ctx.empresa.id, "ia_config")
    modulos.reemplazar(s, ctx.empresa.id, "ia_config", {"activo": data.activo, "catalogo": data.catalogo, "resumen": data.resumen, "productos": data.productos, "tickets": data.tickets}, version=(r.version or 0) if r else 0)
    s.commit()
    return _salida_empresa(s, ctx.empresa)


@router.get("/api/ia/uso")
def uso_empresa(ctx: Contexto = Depends(requiere("configurar"))):
    inicio = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    with Session(engine) as sc:
        filas = sc.exec(select(UsoIA).where(UsoIA.empresa_id == ctx.empresa.id, UsoIA.creado >= inicio)).all()
    por_tipo: dict = {}
    for f in filas:
        por_tipo[f.tipo] = por_tipo.get(f.tipo, 0) + 1
    return {"mes": inicio.strftime("%Y-%m"), "consultas": len(filas), "por_tipo": por_tipo, "tokens_entrada": sum(f.tokens_entrada for f in filas), "tokens_salida": sum(f.tokens_salida for f in filas), "limite_mes": limite_mes()}


# ------------------------------------------------------------------------------------------------- consola (administrador del sistema)
@router.get("/api/admin/ia")
def admin_ver(_: Usuario = Depends(superadmin)):
    return _resumen_config()


@router.put("/api/admin/ia")
def admin_guardar(data: dict, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    from .auth import auditar
    cfg = _leer_config()
    k = str((data or {}).get("key") or "").strip()
    if k:
        if len(k) > 300 or not k.startswith("sk-ant-"):
            raise HTTPException(400, "La clave de Anthropic empieza por sk-ant-")
        cfg["key"] = secretos._maestra.encrypt(k.encode()).decode()
    m = str((data or {}).get("modelo") or cfg.get("modelo") or MODELO_DEFECTO)
    if m not in MODELOS:
        raise HTTPException(400, "Modelo desconocido")
    cfg["modelo"] = m; cfg["activo"] = bool((data or {}).get("activo"))
    try:
        cfg["limite_mes"] = max(0, min(100000, int((data or {}).get("limite_mes", cfg.get("limite_mes", LIMITE_MES_DEFECTO)))))
    except (TypeError, ValueError):
        raise HTTPException(400, "El límite mensual debe ser un número")
    if cfg["activo"] and not _descifrar(cfg.get("key")):
        raise HTTPException(400, "Para activar la IA guarde primero la clave")
    cfg["actualizado"] = ahora_cr().isoformat(timespec="seconds")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVO.write_text(json.dumps(cfg), encoding="utf-8")
    auditar(s, "ia_config", f"IA {'activa' if cfg['activo'] else 'apagada'} · {m} · {cfg['limite_mes']}/mes", a, None, request)
    return _resumen_config()


@router.post("/api/admin/ia/probar")
def admin_probar(_: Usuario = Depends(superadmin)):
    cfg = _leer_config()
    if cfg and not cfg.get("activo"):
        raise HTTPException(400, "Active primero la IA y guarde")
    try:
        texto, uso = _llamar("Responde únicamente con la palabra OK.", [{"role": "user", "content": "Prueba de conexión"}], max_tokens=20, effort="low")
        ok = True; mensaje = f"Conexión correcta · {uso.get('modelo')} · {uso.get('entrada', 0)} + {uso.get('salida', 0)} tokens"
    except HTTPException as ex:
        ok = False; mensaje = str(ex.detail)[:160]
    if cfg:
        cfg["ultima_prueba"] = {"fecha": ahora_cr().isoformat(timespec="seconds"), "ok": ok, "mensaje": mensaje}
        ARCHIVO.write_text(json.dumps(cfg), encoding="utf-8")
    if not ok:
        raise HTTPException(502, mensaje)
    return {"ok": True, "mensaje": mensaje}


@router.get("/api/admin/ia/uso")
def admin_uso(u: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    from .auth import empresas_ocultas_de
    ocultas = empresas_ocultas_de(u)          # 3.87: sin el consumo (ni el nombre) de las empresas ocultas para este administrador
    inicio = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    filas = [f for f in s.exec(select(UsoIA).where(UsoIA.creado >= inicio)).all() if f.empresa_id not in ocultas]
    nombres = {e.id: (e.nombre_comercial or e.nombre) for e in s.exec(select(Empresa)).all()}
    por: dict = {}
    for f in filas:
        x = por.setdefault(f.empresa_id, {"empresa_id": f.empresa_id, "empresa": nombres.get(f.empresa_id, str(f.empresa_id)), "consultas": 0, "tokens_entrada": 0, "tokens_salida": 0})
        x["consultas"] += 1; x["tokens_entrada"] += f.tokens_entrada; x["tokens_salida"] += f.tokens_salida
    return {"mes": inicio.strftime("%Y-%m"), "empresas": sorted(por.values(), key=lambda x: -x["consultas"]), "total": len(filas)}
