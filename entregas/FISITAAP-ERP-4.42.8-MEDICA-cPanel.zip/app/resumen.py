"""Resumen del negocio (Inicio) y reporte ejecutivo: cifras del período en todas las monedas de la empresa.

Cada monto se entrega consolidado en colones y en dólares ({"CRC": …, "USD": …}) más el desglose nativo por moneda del
documento ("nativo": {"CRC": …, "USD": …}). Conversión: lo emitido en dólares vale total × el tipo de cambio de ese
comprobante en colones; lo emitido en colones vale total ÷ tipo de cambio actual (venta + margen) en dólares.

Reglas: ventas = facturas (01), notas de débito (02), tiquetes (04) y facturas de exportación (09) no rechazados;
devoluciones = notas de crédito (03); egresos = comprobantes recibidos y aceptados (mensaje 05/06 no rechazado por Hacienda)
+ facturas electrónicas de compra emitidas (08); IVA del período = débito (ventas − devoluciones) − crédito (IVA acreditable de
lo recibido y aceptado + FEC); cuentas por cobrar = ventas a crédito con saldo (sin filtro de período, vencidas por su fecha de
vencimiento); cuentas por pagar = compras registradas con saldo (módulo Compras).
"""
import json
import math
from calendar import monthrange
from datetime import date, timedelta
from typing import Any, Iterable, Optional

VENTAS = ("01", "02", "04", "09")
DEVOLUCIONES = ("03",)
COMPRA_EMITIDA = ("08",)
NO_COMPRA_RECIBIDA = ("10",)            # recibo electrónico de pago de un proveedor: documenta un pago, no es una compra



def _iva_rec(r) -> float:
    """IVA de un comprobante recibido (sin Selectivo ni específicos; registros viejos: el impuesto total) (3.41)."""
    v = _g(r, "iva")
    return float(v if v is not None else (_g(r, "impuesto", 0) or 0))

def monto_recibido(r: Any) -> float:
    """Monto que cuenta como gasto de un comprobante recibido: en una aceptación parcial (06) lo aceptado (R316)."""
    if (_g(r, "respuesta") or "") == "06" and _g(r, "monto_gasto_aplicable") is not None:
        return float(_g(r, "monto_gasto_aplicable") or 0)
    return float(_g(r, "total", 0) or 0)


def signo_recibido(r: Any) -> int:
    """Una nota de crédito de un proveedor (03) RESTA de los egresos y del IVA acreditable; el resto de recibidos suma."""
    return -1 if _g(r, "tipo_documento") == "03" else 1


def otros_cargos_de(d: Any) -> float:
    """Total de «otros cargos» (impuesto de servicio, timbres…) de un documento: columna JSON [{tipo, detalle, porcentaje, monto}].
    Van dentro del total del comprobante pero no son venta de líneas ni IVA; se muestran aparte en resumen, reportes y exportación."""
    raw = _g(d, "otros_cargos")
    if not raw:
        return 0.0
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return 0.0
    if not isinstance(raw, list):
        return 0.0
    t = 0.0
    for oc in raw:
        if not isinstance(oc, dict):
            continue
        try:
            v = float(oc.get("monto") or 0)
        except (TypeError, ValueError):
            continue
        if math.isfinite(v):
            t += v
    return round(t, 2)


# Tarifas de IVA (código del XML → nombre y porcentaje) para la declaración por tarifa
TARIFAS_IVA = {"08": ("13 % general", 13.0), "04": ("4 % reducida", 4.0), "03": ("2 % reducida", 2.0), "02": ("1 % reducida", 1.0),
               "09": ("0,5 % reducida", 0.5), "07": ("8 % transitoria", 8.0), "06": ("4 % transitoria", 4.0), "05": ("0 % transitoria", 0.0),
               "01": ("0 % (exento)", 0.0), "10": ("Exento", 0.0), "11": ("0 % sin derecho a crédito", 0.0)}
EXCLUIR_ESTADOS = ("rechazado", "error")
CREDITO = ("02", "08", "10")              # condiciones de venta que dejan saldo por cobrar (antes: todo lo que no fuera contado) (R317)
TIPOS = {"01": "Factura", "02": "Nota de débito", "03": "Nota de crédito", "04": "Tiquete", "08": "Factura de compra",
         "09": "Factura de exportación", "10": "Recibo de pago"}


def rango(periodo: str, hoy: date, desde: Optional[str] = None, hasta: Optional[str] = None) -> tuple[str, str, str, str]:
    """(desde, hasta, desde_anterior, hasta_anterior) en ISO. Para 'mes' el período anterior es el mismo tramo del mes
    calendario anterior hasta el mismo día (1 al 12 de septiembre vs 1 al 12 de octubre) (R161); en los demás, igual duración."""
    def fin_mes(d: date) -> date:
        return d.replace(day=monthrange(d.year, d.month)[1])

    def restar_meses(d: date, n: int) -> date:
        y, m = d.year, d.month - n
        while m <= 0:
            m += 12; y -= 1
        return date(y, m, 1)

    if periodo == "rango" and desde and hasta:
        d1, d2 = date.fromisoformat(desde[:10]), date.fromisoformat(hasta[:10])
    elif periodo == "mes-ant":
        d1 = restar_meses(hoy, 1); d2 = fin_mes(d1)
    elif periodo == "anio":
        d1, d2 = date(hoy.year, 1, 1), date(hoy.year, 12, 31)
    elif periodo in ("bimestre", "trimestre", "semestre"):
        d1, d2 = restar_meses(hoy, {"bimestre": 2, "trimestre": 3, "semestre": 6}[periodo] - 1), fin_mes(hoy)
    else:
        d1, d2 = hoy.replace(day=1), fin_mes(hoy)
    if d2 < d1:
        d1, d2 = d2, d1
    dur = (d2 - d1).days + 1
    a2 = d1 - timedelta(days=1)
    a1 = a2 - timedelta(days=dur - 1)
    _r = (d1.isoformat(), d2.isoformat(), a1.isoformat(), a2.isoformat())
    if periodo == "mes" and not (desde and hasta):
        d1 = date.fromisoformat(_r[0]); corte = min(date.fromisoformat(_r[1]), hoy)
        a1 = restar_meses(d1, 1); a2 = min(a1.replace(day=min(corte.day, monthrange(a1.year, a1.month)[1])), fin_mes(a1))   # mismo tramo del mes anterior hasta el día de hoy
        return _r[0], _r[1], a1.isoformat(), a2.isoformat()
    return _r


class Montos:
    """Acumulador de un monto en varias monedas."""

    def __init__(self, tc: Optional[float]):
        self.tc = float(tc or 0)
        self.crc = 0.0
        self.usd = 0.0
        self.usd_crc = 0.0
        self.nativo: dict[str, float] = {}

    def sumar(self, moneda: Optional[str], monto: Any, tc_doc: Any = None) -> "Montos":
        monto = float(monto or 0)
        moneda = (moneda or "CRC").upper()
        self.nativo[moneda] = round(self.nativo.get(moneda, 0.0) + monto, 2)
        t_doc = float(tc_doc or 0)
        if moneda == "CRC":
            self.crc += monto
            self.usd += monto / self.tc if self.tc else 0.0
        elif moneda == "USD":
            self.crc += monto * (t_doc if t_doc > 1 else self.tc)     # documentos viejos sin tipo de cambio: el actual
            self.usd_crc += monto * (t_doc if t_doc > 1 else self.tc)     # 4.18: lo hecho en dólares, en colones al tipo de cambio de cada documento
            self.usd += monto
        else:                                                         # otra moneda: entra con el tipo de cambio del documento
            self.crc += monto * t_doc
            self.usd += (monto * t_doc / self.tc) if (t_doc and self.tc) else 0.0
        return self

    def menos(self, otro: "Montos") -> "Montos":
        r = Montos(self.tc)
        r.crc, r.usd, r.usd_crc = self.crc - otro.crc, self.usd - otro.usd, self.usd_crc - otro.usd_crc
        # 3.87: en el orden en que entraron (primero las de self, luego las nuevas de otro). Con set() el orden de iva.debito.nativo e
        # iva.neto.nativo dependía de la semilla de hash del proceso y el mismo resumen salía con bytes distintos según quién atendía.
        for k in list(self.nativo) + [x for x in otro.nativo if x not in self.nativo]:
            r.nativo[k] = round(self.nativo.get(k, 0.0) - otro.nativo.get(k, 0.0), 2)
        return r

    def dict(self) -> dict:
        d = {"CRC": round(self.crc, 2), "USD": round(self.usd, 2), "nativo": self.nativo}
        if self.usd_crc:                                              # 4.19: lo hecho en dólares, en colones al tipo de cambio de cada documento
            d["USD_CRC"] = round(self.usd_crc, 2)
        return d


def _g(o: Any, k: str, default: Any = None) -> Any:
    if isinstance(o, dict):
        return o.get(k, default)
    return getattr(o, k, default)


def tc_doc(x: Any) -> Any:
    """4.18: el tipo de cambio que trae el documento; si no lo trae (importados, compras a mano), la venta del BCCR del día del documento."""
    t = _g(x, "tipo_cambio")
    try:
        if float(t or 0) > 1:
            return t
    except (TypeError, ValueError):
        pass
    if str(_g(x, "moneda") or "CRC").upper() != "USD":
        return t
    from . import tipo_cambio
    return tipo_cambio.venta_en(str(_g(x, "fecha_emision") or _g(x, "creacion") or _g(x, "fecha") or "")[:10]) or t


def _en(fecha: Any, d1: str, d2: str) -> bool:
    f = str(fecha or "")[:10]
    return bool(f) and d1 <= f <= d2


def _conv(tc: Optional[float], moneda: Any, monto: Any, tc_doc: Any = None) -> dict:
    return Montos(tc).sumar(moneda, monto, tc_doc).dict()


def _a_crc(moneda: Any, monto: Any, tc_doc: Any, tc: Optional[float]) -> float:
    """Monto en colones: lo emitido en otra moneda con el tipo de cambio del documento (o el actual si no lo trae)."""
    moneda = (moneda or "CRC").upper()
    try:
        monto = float(monto or 0); t = float(tc_doc or 0)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(monto):
        return 0.0
    if moneda == "CRC":
        return monto
    if t > 1:
        return monto * t
    return monto * float(tc or 0) if moneda == "USD" else monto * t


def _registrado(r: Any) -> bool:
    """4.23: el recibido está en el registro de compras y gastos (sin el dato, sí: filas y diccionarios de antes de la 4.23)."""
    v = _g(r, "registrado")
    return v is None or bool(v)


def _aceptados(recibidos: list, d1: str, d2: str) -> list:
    """Comprobantes recibidos que cuentan como compra en el período: aceptados (05/06) no rechazados por Hacienda, sin recibos
    de pago (10); una nota de crédito del proveedor solo si la factura a la que se refiere también está aceptada.
    4.23: y solo los que están REGISTRADOS (uno aceptado que se quitó del registro no cuenta; tampoco la nota que se refiere a él)."""
    aceptadas_ok = {_g(r, "clave") for r in recibidos if (_g(r, "respuesta") or "") in ("05", "06") and (_g(r, "estado_mensaje") or "") not in EXCLUIR_ESTADOS
                    and _registrado(r)}

    def nota_valida(r):
        if _g(r, "tipo_documento") != "03":
            return True
        ref = _g(r, "referencia_clave")
        return not ref or ref in aceptadas_ok          # sin referencia conocida: resta (no se puede saber más)
    return [r for r in recibidos if (_g(r, "respuesta") or "") in ("05", "06") and (_g(r, "estado_mensaje") or "") not in EXCLUIR_ESTADOS and _registrado(r)
            and _en(_g(r, "fecha_emision"), d1, d2) and _g(r, "tipo_documento") not in NO_COMPRA_RECIBIDA and nota_valida(r)]


def compras_manuales(compras: Iterable[Any], recibidos: Iterable[Any], d1: str, d2: str) -> list[dict]:
    """Compras registradas a mano en el período (por fecha de creación) que no tienen factura electrónica de compra ni un
    comprobante recibido que las cubra: se cuentan como gasto e IVA acreditable en el resumen y en la declaración de IVA.
    4.23: la factura registrada desde un comprobante recibido (por su recepcion_id o por su clave) cuenta por sí misma mientras
    ese recibido NO esté aceptado y registrado (en una empresa sin facturación electrónica el XML no se «acepta»); cuando lo
    está, cuenta el recibido (_aceptados) y la factura no: nada se cuenta dos veces ni cero veces. Es la misma regla de los
    asientos (cm: en automaticos.js) y de las listas Compras y Gastos (gastos/_registro.js).
    La factura de un comprobante que se RECHAZÓ (respuesta 07) tampoco cuenta por sí misma: un comprobante rechazado no es una
    compra ni da IVA acreditable (como antes de la 4.23, cuando ninguna factura con comprobante recibido contaba aparte). En las
    listas esa factura sigue a la vista, para pagarla o eliminarla."""
    ids_cubren, claves_cubren = set(), set()               # recibidos cuya factura NO cuenta por sí misma: el aceptado y registrado, y el rechazado
    for r in recibidos:
        resp = _g(r, "respuesta") or ""
        if resp == "07" or (resp in ("05", "06") and (_g(r, "estado_mensaje") or "") not in EXCLUIR_ESTADOS and _registrado(r)):
            ids_cubren.add(str(_g(r, "id")))
            claves_cubren.add(_g(r, "clave"))
    out = []
    for c in compras:
        if not isinstance(c, dict) or c.get("fec_id") or (c.get("recepcion_id") and str(c.get("recepcion_id")) in ids_cubren) or (c.get("clave") and c.get("clave") in claves_cubren):
            continue
        if not _en(c.get("creacion"), d1, d2):
            continue
        lineas = []
        for l in c.get("lineas") or []:
            if not isinstance(l, dict):
                continue
            try:
                base = float(l.get("cantidad") or 0) * float(l.get("precio_unitario") or 0) - float(l.get("descuento") or 0)
                pct = float(l.get("tarifa") or 0)
            except (TypeError, ValueError):
                continue
            if not (math.isfinite(base) and math.isfinite(pct)):
                continue
            cod = str(l.get("codigo_tarifa") or "")
            lineas.append({"base": base, "pct": pct, "iva": base * pct / 100, "codigo": cod if cod in TARIFAS_IVA else _codigo_tarifa(pct)})
        if not lineas:
            continue
        out.append({"compra": c, "lineas": lineas, "base": sum(x["base"] for x in lineas), "iva": sum(x["iva"] for x in lineas)})
    return out


def _codigo_tarifa(pct: Any) -> str:
    try:
        p = round(float(pct or 0), 2)
    except (TypeError, ValueError):
        p = 0.0
    for cod in ("08", "04", "03", "02", "09", "07", "10"):
        if abs(TARIFAS_IVA[cod][1] - p) < 0.001:
            return cod
    return "10"


def iva_por_tarifa(docs: Iterable[Any], lineas: Iterable[Any], recibidos: Iterable[Any], compras: Iterable[dict], d1: str, d2: str,
                   tc: Optional[float], moneda: Optional[str] = None) -> list[dict]:
    """Ventas y compras del período por tarifa de IVA, en colones, para la declaración mensual (D-104).
    Ventas: líneas de facturas, tiquetes, notas de débito y facturas de exportación (menos las notas de crédito); las ventas con
    IVA diferido (condición 10) no suman al emitirse. Compras: líneas de las facturas electrónicas de compra (08) y de las compras
    registradas a mano; de los comprobantes recibidos y aceptados solo se conoce el total y el IVA acreditable (una fila aparte)."""
    docs = list(docs); recibidos = list(recibidos)
    # 4.3: con `moneda` solo entran los documentos hechos en esa moneda y con sus montos originales (sin tipo de cambio): la vista
    # «lo de dólares en dólares y lo de colones en colones»; sin `moneda`, todo en colones como se declara
    mon = (moneda or "").upper() or None
    es_mon = lambda m: (str(m or "CRC").upper() == mon)   # noqa: E731
    todos_recibidos = recibidos       # 4.23: saber si una factura está cubierta por su recibido se decide con TODOS, aunque estén en otra moneda
    if mon:
        _conv_crc = lambda m, monto, tc_doc, t: (float(monto or 0) if es_mon(m) else 0.0)   # noqa: E731
        docs = [d for d in docs if es_mon(_g(d, "moneda"))]
        recibidos = [r for r in recibidos if es_mon(_g(r, "moneda"))]
        compras = [c for c in compras if isinstance(c, dict) and es_mon(c.get("moneda"))]
    else:
        _conv_crc = _a_crc
    validos = {_g(d, "id"): d for d in docs if (_g(d, "estado") or "") not in EXCLUIR_ESTADOS and _en(_g(d, "fecha_emision"), d1, d2)}
    lado: dict[Any, tuple] = {}
    for did, d in validos.items():
        t = _g(d, "tipo_documento")
        if t in VENTAS and (_g(d, "condicion_venta") or "01") != "10":
            lado[did] = ("v", 1)
        elif t in DEVOLUCIONES:
            lado[did] = ("v", -1)
        elif t in COMPRA_EMITIDA:
            lado[did] = ("c", 1)
    filas: dict[str, dict] = {}

    def fila(cod: str, nombre: Optional[str] = None, pct: Optional[float] = None) -> dict:
        n, p = TARIFAS_IVA.get(cod, (nombre or cod, pct or 0.0))
        return filas.setdefault(cod, {"codigo": cod, "tarifa": nombre or n, "pct": p if pct is None else pct, "ventas": 0.0, "debito": 0.0, "compras": 0.0, "credito": 0.0, "docs": 0})
    # IVA diferido (condición de venta 10): entra con el recibo electrónico de pago (REP) del período, como en calcular (R318)
    for d in validos.values():
        if _g(d, "tipo_documento") == "10":
            f = fila("rep", "IVA diferido cobrado (recibos electrónicos de pago)", 0.0)
            f["debito"] += _conv_crc(_g(d, "moneda"), _g(d, "impuesto", 0), tc_doc(d), tc); f["docs"] += 1
    for l in lineas:
        did = _g(l, "documento_id")
        if did not in lado:
            continue
        d = validos[did]; lv, sg = lado[did]
        cod = str(_g(l, "codigo_tarifa") or "08")
        imp = _conv_crc(_g(d, "moneda"), _g(l, "impuesto", 0), tc_doc(d), tc)
        base = _conv_crc(_g(d, "moneda"), float(_g(l, "total", 0) or 0) - float(_g(l, "impuesto", 0) or 0), tc_doc(d), tc)
        f = fila(cod, None, _g(l, "tarifa"))
        exo = float(_g(l, "iva_exonerado", 0) or 0)
        if lv == "v" and exo:
            # venta con exoneración: la parte exonerada de la base se declara aparte (proporción tarifa exonerada / tarifa)
            tarifa = float(_g(l, "tarifa", 0) or 0)
            te = float(_g(l, "tarifa_exonerada", 0) or 0) or tarifa
            prop = min(1.0, te / tarifa) if tarifa else 0.0
            fx = fila("exo", "Ventas con exoneración (IVA no cobrado)", 0.0)
            fx["ventas"] += sg * base * prop
            fx["exonerado"] = fx.get("exonerado", 0.0) + sg * _conv_crc(_g(d, "moneda"), exo, tc_doc(d), tc)
            fx["docs"] += 1
            base = base * (1 - prop)
        if lv == "v":
            f["ventas"] += sg * base; f["debito"] += sg * imp
        else:
            f["compras"] += base; f["credito"] += imp
        f["docs"] += 1
    # compras registradas a mano (sin factura electrónica de compra ni comprobante recibido): líneas con su tarifa
    # (con `moneda`, las compras ya vienen filtradas; los recibidos van completos: la factura cuyo recibido está en otra moneda sigue
    # cubierta por él y no se cuenta de más)
    for cm in compras_manuales(compras, todos_recibidos, d1, d2):
        c = cm["compra"]
        for l in cm["lineas"]:
            f = fila(l["codigo"])
            f["compras"] += _conv_crc(c.get("moneda"), l["base"], tc_doc(c), tc)
            f["credito"] += _conv_crc(c.get("moneda"), l["iva"], tc_doc(c), tc)
            f["docs"] += 1
    # comprobantes recibidos y aceptados: solo el total y el IVA acreditable (el desglose por tarifa está en el XML del proveedor)
    for r in _aceptados(recibidos, d1, d2):
        sg = signo_recibido(r)
        acred = _g(r, "monto_impuesto_acreditar")
        acred = float(acred) if acred is not None else _iva_rec(r)
        base = float(_g(r, "total", 0) or 0) - _iva_rec(r)          # 3.41: el Selectivo pagado es parte del costo
        f = fila("rec", "Comprobantes recibidos (IVA según el proveedor)", 0.0)
        f["compras"] += sg * _conv_crc(_g(r, "moneda"), base, tc_doc(r), tc)
        f["credito"] += sg * _conv_crc(_g(r, "moneda"), acred, tc_doc(r), tc)
        f["docs"] += 1
    out = sorted(filas.values(), key=lambda f: (f["codigo"] in ("exo", "rec", "rep"), f["codigo"] != "exo", -f["pct"], f["codigo"]))
    for f in out:
        for k in ("ventas", "debito", "compras", "credito", "exonerado"):
            if k in f:
                f[k] = round(f[k], 2)
    return out


def _dias_vencido(venc: Any, hoy: date) -> int:
    v = str(venc or "")[:10]
    if not v:
        return 0
    try:
        return max(0, (hoy - date.fromisoformat(v)).days)
    except ValueError:
        return 0


def calcular(docs: Iterable[Any], lineas: Iterable[Any], recibidos: Iterable[Any], compras: Iterable[dict],
             d1: str, d2: str, a1: str, a2: str, tc: Optional[float], hoy: date, con_detalle: bool = False) -> dict:
    hoy_s = hoy.isoformat()
    docs = list(docs); lineas = list(lineas); recibidos = list(recibidos); compras = [c for c in compras if isinstance(c, dict)]
    validos = [d for d in docs if (_g(d, "estado") or "") not in EXCLUIR_ESTADOS]
    ventas = [d for d in validos if _g(d, "tipo_documento") in VENTAS and _en(_g(d, "fecha_emision"), d1, d2)]
    ventas_ant = [d for d in validos if _g(d, "tipo_documento") in VENTAS and _en(_g(d, "fecha_emision"), a1, a2)]
    devol = [d for d in validos if _g(d, "tipo_documento") in DEVOLUCIONES and _en(_g(d, "fecha_emision"), d1, d2)]
    fec = [d for d in validos if _g(d, "tipo_documento") in COMPRA_EMITIDA and _en(_g(d, "fecha_emision"), d1, d2)]
    # una nota de crédito de un proveedor resta solo si la factura a la que se refiere está entre los recibidos y fue
    # aceptada (si se rechazó, sigue sin respuesta o se eliminó, esa factura nunca sumó)
    aceptados = _aceptados(recibidos, d1, d2)

    def suma(items, campo="total"):
        m = Montos(tc)
        for x in items:
            m.sumar(_g(x, "moneda"), _g(x, campo, 0), tc_doc(x))
        return m

    m_ventas, m_ant, m_dev = suma(ventas), suma(ventas_ant), suma(devol)
    variacion = round((m_ventas.crc - m_ant.crc) / m_ant.crc * 100, 1) if m_ant.crc else None
    # otros cargos (impuesto de servicio, timbres…): dentro del total de ventas pero no son venta de líneas ni IVA
    m_oc = Montos(tc)
    for d in ventas:
        m_oc.sumar(_g(d, "moneda"), otros_cargos_de(d), tc_doc(d))
    for d in devol:
        m_oc.sumar(_g(d, "moneda"), -otros_cargos_de(d), tc_doc(d))

    # IVA: débito (ventas − devoluciones) y crédito (acreditable de recibidos aceptados + FEC). Las ventas con IVA diferido
    # (condición 10) no suman al emitirse: su IVA entra con el recibo electrónico de pago (REP) del período (R318)
    ventas_iva = [d for d in ventas if (_g(d, "condicion_venta") or "01") != "10"]
    reps = [d for d in validos if _g(d, "tipo_documento") == "10" and _en(_g(d, "fecha_emision"), d1, d2)]
    m_deb = suma(ventas_iva, "impuesto").menos(suma(devol, "impuesto"))
    for d in reps:
        m_deb.sumar(_g(d, "moneda"), _g(d, "impuesto", 0), tc_doc(d))
    m_cred = Montos(tc)
    for r in aceptados:
        acred = _g(r, "monto_impuesto_acreditar")
        m_cred.sumar(_g(r, "moneda"), signo_recibido(r) * float((acred if acred is not None else _iva_rec(r)) or 0), tc_doc(r))
    for d in fec:
        m_cred.sumar(_g(d, "moneda"), _g(d, "impuesto", 0), tc_doc(d))
    # compras registradas a mano (sin FEC ni comprobante recibido): también son gasto e IVA acreditable (como en la D-104 y
    # los asientos automáticos); por su fecha de registro
    manuales = compras_manuales(compras, recibidos, d1, d2)
    for cm in manuales:
        m_cred.sumar(cm["compra"].get("moneda"), cm["iva"], tc_doc(cm["compra"]))

    # egresos
    m_egr = Montos(tc).sumar("CRC", 0)
    for r in aceptados:
        m_egr.sumar(_g(r, "moneda"), signo_recibido(r) * monto_recibido(r), tc_doc(r))
    for d in fec:
        m_egr.sumar(_g(d, "moneda"), _g(d, "total", 0), tc_doc(d))
    for cm in manuales:
        m_egr.sumar(cm["compra"].get("moneda"), cm["base"] + cm["iva"], tc_doc(cm["compra"]))

    # cuentas por cobrar (saldos abiertos hoy)
    cxc_rows, m_cxc, m_cxc_venc, m_cxc_vig = [], Montos(tc), Montos(tc), Montos(tc)
    for d in validos:
        if _g(d, "tipo_documento") not in ("01", "02", "04", "09") or (_g(d, "condicion_venta") or "01") not in CREDITO:   # 4.9: también los tiquetes fiados (04 a crédito)
            continue
        # lo cobrado y lo rebajado con notas de crédito aceptadas ya no se debe
        saldo = round(float(_g(d, "total", 0) or 0) - float(_g(d, "pagado", 0) or 0) - float(_g(d, "acreditado", 0) or 0), 2)
        if saldo <= 0.005:
            continue
        dias = _dias_vencido(_g(d, "fecha_vencimiento"), hoy)
        m_cxc.sumar(_g(d, "moneda"), saldo, tc_doc(d))
        (m_cxc_venc if dias else m_cxc_vig).sumar(_g(d, "moneda"), saldo, tc_doc(d))
        cxc_rows.append({"id": _g(d, "id"), "fecha": _g(d, "fecha_emision"), "tipo": TIPOS.get(_g(d, "tipo_documento"), _g(d, "tipo_documento")),
                         "consecutivo": _g(d, "consecutivo"), "cliente": _g(d, "receptor_nombre") or "—", "vencimiento": _g(d, "fecha_vencimiento"),
                         "dias": dias, "moneda": _g(d, "moneda"), "total": _g(d, "total", 0), "pagado": _g(d, "pagado", 0) or 0,
                         "acreditado": _g(d, "acreditado", 0) or 0, "saldo": saldo,
                         "estado": "Vencida" if dias else "Vigente", **_conv(tc, _g(d, "moneda"), saldo, tc_doc(d))})

    # cuentas por pagar (compras registradas con saldo)
    cxp_rows, m_cxp, m_cxp_venc, m_cxp_vig = [], Montos(tc), Montos(tc), Montos(tc)
    for c in compras:
        # una compra con datos imposibles (montos enormes, tipo de cambio o moneda inválidos) se omite: no debe dejar sin
        # resumen a toda la empresa
        try:
            if not isinstance(c, dict) or not isinstance(c.get("moneda") or "CRC", str):
                continue
            saldo = round(float(c.get("total", 0) or 0) - float(c.get("pagado", 0) or 0), 2)
            if not math.isfinite(saldo) or abs(saldo) > 1e15 or saldo <= 0.005:
                continue
            conv = _conv(tc, c.get("moneda"), saldo, tc_doc(c))
            if any(isinstance(v, float) and not math.isfinite(v) for v in conv.values()):
                continue
            prueba = Montos(tc); prueba.sumar(c.get("moneda"), saldo, tc_doc(c))
        except (TypeError, ValueError, OverflowError, AttributeError):
            continue
        dias = _dias_vencido(c.get("vencimiento"), hoy)
        m_cxp.sumar(c.get("moneda"), saldo, tc_doc(c))
        (m_cxp_venc if dias else m_cxp_vig).sumar(c.get("moneda"), saldo, tc_doc(c))
        cxp_rows.append({"id": c.get("id"), "numero": c.get("numero"), "proveedor": c.get("proveedor") or "—", "fecha": c.get("creacion"),
                         "vencimiento": c.get("vencimiento"), "dias": dias, "moneda": c.get("moneda") or "CRC", "total": c.get("total", 0),
                         "pagado": c.get("pagado", 0) or 0, "saldo": saldo, "emision": c.get("emision") or "", "estado": "Vencida" if dias else "Vigente",
                         **_conv(tc, c.get("moneda"), saldo, tc_doc(c))})

    # ítems, clientes, proveedores, por día
    por_doc = {_g(d, "id"): d for d in ventas}
    unidades = 0.0
    items: dict[str, dict] = {}
    for l in lineas:
        d = por_doc.get(_g(l, "documento_id"))
        if d is None:
            continue
        cant = float(_g(l, "cantidad", 0) or 0)
        unidades += cant
        k = str(_g(l, "producto_id") or _g(l, "detalle") or "")
        it = items.setdefault(k, {"producto_id": _g(l, "producto_id"), "detalle": _g(l, "detalle") or "—", "cantidad": 0.0, "docs": 0, "_m": Montos(tc)})
        it["cantidad"] += cant; it["docs"] += 1
        it["_m"].sumar(_g(d, "moneda"), _g(l, "total", 0), tc_doc(d))
    clientes: dict[str, dict] = {}
    for d in ventas:
        k = str(_g(d, "cliente_id") or _g(d, "receptor_nombre") or "—")
        c = clientes.setdefault(k, {"nombre": _g(d, "receptor_nombre") or "Ventas sin cliente identificado", "docs": 0, "_m": Montos(tc)})   # (R322)
        c["docs"] += 1; c["_m"].sumar(_g(d, "moneda"), _g(d, "total", 0), tc_doc(d))
    proveedores: dict[str, dict] = {}
    for r in aceptados:
        p = proveedores.setdefault(_g(r, "emisor_nombre") or "—", {"nombre": _g(r, "emisor_nombre") or "—", "docs": 0, "_m": Montos(tc)})
        p["docs"] += 1; p["_m"].sumar(_g(r, "moneda"), signo_recibido(r) * monto_recibido(r), tc_doc(r))
    for d in fec:
        p = proveedores.setdefault(_g(d, "receptor_nombre") or "—", {"nombre": _g(d, "receptor_nombre") or "—", "docs": 0, "_m": Montos(tc)})
        p["docs"] += 1; p["_m"].sumar(_g(d, "moneda"), _g(d, "total", 0), tc_doc(d))
    for cm in manuales:
        c = cm["compra"]
        p = proveedores.setdefault(c.get("proveedor") or "—", {"nombre": c.get("proveedor") or "—", "docs": 0, "_m": Montos(tc)})
        p["docs"] += 1; p["_m"].sumar(c.get("moneda"), cm["base"] + cm["iva"], tc_doc(c))
    por_dia: dict[str, dict] = {}
    for d in ventas:
        f = str(_g(d, "fecha_emision"))[:10]
        por_dia.setdefault(f, {"ingresos": Montos(tc), "egresos": Montos(tc)})["ingresos"].sumar(_g(d, "moneda"), _g(d, "total", 0), tc_doc(d))
    ids_aceptados = {id(r) for r in aceptados}
    for x in aceptados + fec:
        f = str(_g(x, "fecha_emision"))[:10]
        sg = signo_recibido(x) if id(x) in ids_aceptados else 1
        monto_x = monto_recibido(x) if id(x) in ids_aceptados else float(_g(x, "total", 0) or 0)
        por_dia.setdefault(f, {"ingresos": Montos(tc), "egresos": Montos(tc)})["egresos"].sumar(_g(x, "moneda"), sg * monto_x, tc_doc(x))
    for cm in manuales:
        c = cm["compra"]; f = str(c.get("creacion"))[:10]
        por_dia.setdefault(f, {"ingresos": Montos(tc), "egresos": Montos(tc)})["egresos"].sumar(c.get("moneda"), cm["base"] + cm["iva"], tc_doc(c))

    def ranking(m: dict, n: Optional[int] = None) -> list[dict]:
        lst = sorted(m.values(), key=lambda x: -x["_m"].crc)
        out = [{**{k: v for k, v in x.items() if k != "_m"}, "monto": x["_m"].dict(), "usd_tc": round(x["_m"].usd_crc / x["_m"].nativo["USD"], 6) if x["_m"].nativo.get("USD") else 0} for x in lst]
        return out[:n] if n else out

    usadas: set[str] = set()
    for m in (m_ventas, m_dev, m_egr, m_cxc, m_cxp, m_deb, m_cred):
        usadas |= {k for k, v in m.nativo.items() if abs(v) > 0.005}

    out = {
        "desde": d1, "hasta": d2, "anterior": {"desde": a1, "hasta": a2}, "hoy": hoy_s, "tc": tc, "tc_disponible": bool(tc),
        "monedas_usadas": sorted(usadas, key=lambda c: (c != "CRC", c != "USD", c)),
        "ventas": m_ventas.dict(), "ventas_anterior": m_ant.dict(), "variacion": variacion, "documentos": len(ventas), "unidades": round(unidades, 2),
        "devoluciones": m_dev.dict(), "devoluciones_docs": len(devol),
        "otros_cargos": m_oc.dict(),
        "cxc": {"total": m_cxc.dict(), "vigente": m_cxc_vig.dict(), "vencido": m_cxc_venc.dict(), "docs": len(cxc_rows), "docs_vencidos": sum(1 for r in cxc_rows if r["dias"])},
        "cxp": {"total": m_cxp.dict(), "vigente": m_cxp_vig.dict(), "vencido": m_cxp_venc.dict(), "docs": len(cxp_rows), "docs_vencidos": sum(1 for r in cxp_rows if r["dias"])},
        "iva": {"debito": m_deb.dict(), "credito": m_cred.dict(), "neto": m_deb.menos(m_cred).dict(), "docs_emitidos": len(ventas) + len(devol), "docs_recibidos": len(aceptados) + len(fec) + len(manuales)},
        "egresos": m_egr.dict(), "egresos_docs": len(aceptados) + len(fec) + len(manuales),
        "clientes": len([k for k in clientes if k != "—"]),         # los tiquetes sin receptor no son un cliente (R322)
        "por_dia": [{"fecha": f, "ingresos": v["ingresos"].dict(), "egresos": v["egresos"].dict()} for f, v in sorted(por_dia.items())],
        "top_clientes": ranking(clientes, 5), "top_productos": ranking(items, 5), "gastos_por_proveedor": ranking(proveedores, 5),
    }
    if con_detalle:
        def fila_doc(d, signo=1):
            # 3.87: cada monto y su conversión se calculan una sola vez (antes, tres veces el del impuesto); mismas cifras y mismo orden
            moneda, tcd = _g(d, "moneda"), tc_doc(d)
            total, imp = signo * float(_g(d, "total", 0) or 0), signo * float(_g(d, "impuesto", 0) or 0)
            c_imp = _conv(tc, moneda, imp, tcd)
            return {"id": _g(d, "id"), "fecha": _g(d, "fecha_emision"), "tipo": TIPOS.get(_g(d, "tipo_documento"), _g(d, "tipo_documento")),
                    "consecutivo": _g(d, "consecutivo"), "cliente": _g(d, "receptor_nombre") or "—", "moneda": moneda,
                    "total": total, "impuesto": imp,
                    "otros_cargos": signo * otros_cargos_de(d), "vendedor": _g(d, "vendedor") or "",
                    "tipo_cambio": tcd or 1, "estado": _g(d, "estado"), "condicion_venta": _g(d, "condicion_venta"),
                    **_conv(tc, moneda, total, tcd),
                    "impuesto_CRC": c_imp["CRC"],
                    "impuesto_USD": c_imp["USD"]}

        def fila_recibido(r):
            sg = signo_recibido(r)                 # nota de crédito del proveedor: en negativo
            acred = _g(r, "monto_impuesto_acreditar")
            acred = sg * (float(acred) if acred is not None else _iva_rec(r))
            total, imp = sg * float(_g(r, "total", 0) or 0), sg * float(_g(r, "impuesto", 0) or 0)
            return {"id": _g(r, "id"), "fecha": _g(r, "fecha_emision"), "proveedor": _g(r, "emisor_nombre") or "—", "consecutivo": _g(r, "consecutivo"),
                    "origen": "Nota de crédito recibida" if sg < 0 else "Recibido", "moneda": _g(r, "moneda"), "total": total, "impuesto": imp, "acreditar": acred,
                    "clasificacion": _g(r, "clasificacion") or "gasto",   # 4.3: compra (costo de ventas) o gasto
                    "condicion_impuesto": _g(r, "condicion_impuesto") or "", "respuesta": {"05": "Aceptado", "06": "Aceptado parcialmente"}.get(_g(r, "respuesta"), ""),
                    **_conv(tc, _g(r, "moneda"), total, tc_doc(r)),
                    "acreditar_CRC": _conv(tc, _g(r, "moneda"), acred, tc_doc(r))["CRC"], "acreditar_USD": _conv(tc, _g(r, "moneda"), acred, tc_doc(r))["USD"]}

        def fila_manual(cm):
            c = cm["compra"]; total = cm["base"] + cm["iva"]
            return {"id": c.get("id"), "fecha": c.get("creacion"), "proveedor": c.get("proveedor") or "—", "consecutivo": c.get("numero") or "",
                    "origen": "Compra registrada", "moneda": c.get("moneda") or "CRC", "total": total, "impuesto": cm["iva"], "acreditar": cm["iva"], "clasificacion": c.get("tipo") or "gasto",
                    "condicion_impuesto": "", "respuesta": "", **_conv(tc, c.get("moneda"), total, tc_doc(c)),
                    "acreditar_CRC": _conv(tc, c.get("moneda"), cm["iva"], tc_doc(c))["CRC"], "acreditar_USD": _conv(tc, c.get("moneda"), cm["iva"], tc_doc(c))["USD"]}

        por_fec = {c.get("fec_id"): c for c in compras if c.get("fec_id")}   # 4.3: el tipo (compra/gasto) de la compra registrada de cada FEC

        def fila_fec(d):
            return {"id": _g(d, "id"), "fecha": _g(d, "fecha_emision"), "proveedor": _g(d, "receptor_nombre") or "—", "consecutivo": _g(d, "consecutivo"),
                    "origen": "Factura de compra", "moneda": _g(d, "moneda"), "total": _g(d, "total", 0), "impuesto": _g(d, "impuesto", 0), "clasificacion": (por_fec.get(_g(d, "id")) or {}).get("tipo") or "gasto",
                    "acreditar": _g(d, "impuesto", 0), "condicion_impuesto": "", "respuesta": _g(d, "estado") or "",
                    **_conv(tc, _g(d, "moneda"), _g(d, "total", 0), tc_doc(d)),
                    "acreditar_CRC": _conv(tc, _g(d, "moneda"), _g(d, "impuesto", 0), tc_doc(d))["CRC"],
                    "acreditar_USD": _conv(tc, _g(d, "moneda"), _g(d, "impuesto", 0), tc_doc(d))["USD"]}

        filas_ventas = [fila_doc(d) for d in sorted(ventas, key=lambda x: str(_g(x, "fecha_emision")))]   # 3.87: una vez para ventas y para IVA
        out["detalle"] = {
            "ventas": filas_ventas,
            "devoluciones": [fila_doc(d) for d in sorted(devol, key=lambda x: str(_g(x, "fecha_emision")))],
            "cxc": sorted(cxc_rows, key=lambda r: (-r["dias"], str(r["vencimiento"] or ""))),
            "cxp": sorted(cxp_rows, key=lambda r: (-r["dias"], str(r["vencimiento"] or ""))),
            "iva_emitidos": [{**f, "nativo": dict(f["nativo"])} for f in filas_ventas] + [fila_doc(d, -1) for d in devol],
            "iva_recibidos": [fila_recibido(r) for r in aceptados] + [fila_fec(d) for d in fec] + [fila_manual(cm) for cm in manuales],
            "egresos": [fila_recibido(r) for r in aceptados] + [fila_fec(d) for d in fec] + [fila_manual(cm) for cm in manuales],
            "items": ranking(items), "clientes": ranking(clientes), "proveedores": ranking(proveedores),
        }
    return out


def finitos(x):
    """Copia sin números no finitos (NaN o infinito pasan a 0): la respuesta JSON no los admite y daba error a todos."""
    if isinstance(x, float):
        return x if math.isfinite(x) else 0.0
    if isinstance(x, dict):
        return {k: finitos(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [finitos(v) for v in x]
    return x
