# -*- coding: utf-8 -*-
"""4.32: el mecanismo único de sincronización por API entre la página web y el programa (plan reingenieria_432 §2, contrato_432 §1 a §5).

Un «dato» es lo más chico que viaja con su propia versión: una fila de una tabla (producto, cliente, pedido), un elemento de un registro
que es lista con ids (categoria · 7), una llave de un registro que es un objeto (item_extra · 152) o una parte de un objeto partido
(caja · terminales#2). Cada módulo lo DECLARA con `declarar(Dato(...))`; el núcleo no sabe nada de ningún módulo.

- La web pone la versión: cada vez que un dato cambia, su línea de `sinc_dato` se reescribe (INSERT OR REPLACE) en la misma transacción y
  el id AUTOINCREMENT nuevo ES la versión (el truco de sinc_diario). Solo en las empresas con la marca de sembrada (fila tipo='_', ref='_').
- El oyente acumula por flush lo tocado (session.info["sinc_tocado"], con el valor de antes tomado la primera vez que se ve) y DECIDE una
  sola vez, en before_commit, comparando la huella final con la de sinc_dato: un reemplazar que borra, hace flush y recrea la colección
  (modulos._escribir_coleccion) no deja ni versiones ni lápidas de más.
- El programa con protocolo 2 (réplica) encola en `sinc_cambio` las operaciones (alta, cambio por grupo con antes, después y hora, baja y
  la copia de lo que es suyo) fuera de `sinc_diario.aplicando(...)`.
- Rutas (solo la web): POST /api/sinc/datos (operaciones y goteo) y POST /api/sinc/datos/accion. Con FE_SINC_DATOS=0 contestan 404.
Nunca detiene un guardado: los errores del oyente se registran y se cuentan (fallos(), para Salud)."""
import contextvars
import importlib
import json
import logging
import os
import random
import re
import string
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional, Union

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request
from sqlalchemy import Index, UniqueConstraint, event
from sqlalchemy import inspect as sa_inspect
from sqlalchemy import text as _sql
from sqlmodel import Field, Session, SQLModel

from . import modulos
from . import sinc_diario
from .auth import Contexto, get_session, limitar_ip, requiere, sesion_empresa
from .db import por_empresa
from .modulos import RANGO, Registro, RegistroItem

log = logging.getLogger(__name__)

Funcion = Union[Callable, str]          # una función, o "modulo.funcion" de app/ (se resuelve con importlib la primera vez que se usa)


# ======================================================================================================================
# Tablas (contrato §4)
# ======================================================================================================================
class SincDato(SQLModel, table=True):
    __tablename__ = "sinc_dato"
    __table_args__ = (UniqueConstraint("tipo", "ref", name="ux_sinc_dato"), Index("ix_sinc_dato_etiqueta", "etiqueta"),
                      Index("ix_sinc_dato_dueno", "dueno", "borrado"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)   # en la web ES la versión
    tipo: str                                                   # tipo declarado; "_" = marca de sembrada
    ref: str
    v: int = Field(default=0, sa_column_kwargs={"server_default": "0"})   # programa: versión de la web ya aplicada (0 = nunca vino). Web: 0
    campos: str = Field(default="{}", sa_column_kwargs={"server_default": "{}"})   # {grupo: hora ISO UTC de la web} del último cambio de cada grupo
    origen: int = Field(default=0, sa_column_kwargs={"server_default": "0"})   # terminal que produjo el cambio (0 = la web)
    dueno: Optional[int] = None                                 # solo datos «dueno»
    borrado: bool = Field(default=False, sa_column_kwargs={"server_default": "0"})   # lápida
    foto: Optional[str] = None                                  # con borrado: el contenido al eliminarse (JSON)
    huella: str = Field(default="", sa_column_kwargs={"server_default": ""})   # sha1 (huella())
    datos: Optional[str] = None                                 # solo en la web y solo datos «dueno» ajenos (la copia de la cuenta)
    etiqueta: Optional[str] = None                              # p. ej. «pedido:45»
    cambiado: str = Field(default="", sa_column_kwargs={"server_default": ""})   # ISO UTC de la última escritura de la línea


class SincCambio(SQLModel, table=True):
    __tablename__ = "sinc_cambio"
    __table_args__ = (UniqueConstraint("autora", "n", name="ux_sinc_cambio"), Index("ix_sinc_cambio_dato", "tipo", "ref"),
                      Index("ix_sinc_cambio_estado", "estado", "id"), Index("ix_sinc_cambio_creado", "creado"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    autora: str                                                 # "<terminal>.<época>"
    n: int
    tipo: str
    ref: str
    op: str                                                     # alta · cambio · baja · copia
    base_v: int = Field(default=0, sa_column_kwargs={"server_default": "0"})
    datos: str = Field(default="{}", sa_column_kwargs={"server_default": "{}"})
    por: Optional[str] = None
    estado: str                                                 # programa: abierta · enviada · hecha · rechazada. Web: el estado del resultado
    resultado: Optional[str] = None
    intentos: int = Field(default=0, sa_column_kwargs={"server_default": "0"})
    creado: str


class SincPisado(SQLModel, table=True):
    __tablename__ = "sinc_pisado"
    __table_args__ = (Index("ix_sinc_pisado_cuando", "cuando"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    cuando: str
    tipo: str
    ref: str
    nombre: str = Field(default="", sa_column_kwargs={"server_default": ""})
    campo: str = Field(default="", sa_column_kwargs={"server_default": ""})
    motivo: str
    perdio: str = Field(default="null", sa_column_kwargs={"server_default": "null"})
    perdio_de: str = Field(default="", sa_column_kwargs={"server_default": ""})
    quedo_de: str = Field(default="", sa_column_kwargs={"server_default": ""})
    visto: bool = Field(default=False, sa_column_kwargs={"server_default": "0"})


class SincLlamada(SQLModel, table=True):
    """Solo la web: la última llamada de cada computadora a /api/sinc/datos (hora time.time() y si dijo estacion_viva). Vive en la base de
    la empresa para que todos los procesos del servidor la vean igual (contacto_guardado)."""
    __tablename__ = "sinc_llamada"
    terminal: int = Field(primary_key=True)
    hora: float = Field(default=0, sa_column_kwargs={"server_default": "0"})
    estacion_viva: bool = Field(default=False, sa_column_kwargs={"server_default": "0"})


por_empresa(SincDato, SincCambio, SincPisado, SincLlamada)

TABLAS_PROPIAS = ("sinc_dato", "sinc_cambio", "sinc_pisado")
CLAVE_EPOCA = "sinc_epoca"                  # web: {"epoca": str}
CLAVE_ESTADO = "sinc_datos_estado"          # programa (P2): {"protocolo", "cursor", "epoca", ...}
WEB = "la página web"


# ======================================================================================================================
# Dato y declarar (contrato §1)
# ======================================================================================================================
@dataclass(frozen=True)
class Dato:
    tipo: str
    modelo: Optional[type] = None
    registro: Optional[str] = None
    forma: Optional[str] = None
    partir: Optional[dict] = None
    escribe: str = "todos"
    viaja: str = "dos"
    dueno_de: Optional[Funcion] = None
    grupos: dict = field(default_factory=dict)
    conjuntos: tuple = ()
    locales: tuple = ()
    no_viajan: tuple = ()
    filtro: Optional[Funcion] = None
    etiqueta: Optional[Funcion] = None
    refs: dict = field(default_factory=dict)
    alta: Optional[str] = None
    altas_bajas: str = "todos"
    baja: str = "borrar"
    permiso: Optional[str] = None
    validar: Optional[Funcion] = None
    copia_local: bool = False
    al_aplicar: Optional[Funcion] = None
    acciones: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    @property
    def forma_real(self) -> str:
        """§1.2: lo que se deduce si no se dice (nunca mirando datos)."""
        if self.forma:
            return self.forma
        if self.modelo is not None:
            return "fila"
        return "parte" if self.partir else "elemento"


DATOS: dict = {}
_vigilados: dict = {}                       # caché del filtro rápido del oyente (se rehace en declarar)
# §1.3 · nunca se declaran (la lista prohibida de §8 del plan)
MODELOS_PROHIBIDOS = ("Usuario", "UsuarioEmpresa", "RolEmpresa", "TokenApi", "Empresa")
REGISTROS_PROHIBIDOS = ("sinc_vinculacion", "sinc_local", CLAVE_ESTADO, CLAVE_EPOCA, "empresa_extra", "equipo_impresion", "impuestos", "monedas")


def declarar(d: Dato) -> Dato:
    """Registra la declaración en DATOS. ValueError si el tipo se repite o la declaración no cumple las reglas de §1.3."""
    if not isinstance(d.tipo, str) or not re.fullmatch(r"[a-z_]{1,30}", d.tipo) or d.tipo == "_":
        raise ValueError(f"Tipo no válido: {d.tipo!r}")
    if d.tipo in DATOS:
        raise ValueError(f"El tipo {d.tipo} ya está declarado")
    if (d.modelo is None) == (d.registro is None):
        raise ValueError("Se declara exactamente uno de modelo o registro")
    if d.escribe not in ("todos", "dueno", "web") or d.viaja not in ("dos", "baja", "sube"):
        raise ValueError("escribe o viaja no válidos")
    if d.forma not in (None, "fila", "elemento", "llave", "parte") or d.altas_bajas not in ("todos", "web"):
        raise ValueError("forma o altas_bajas no válidas")
    if d.escribe == "dueno" and (d.dueno_de is None or d.viaja not in ("sube", "dos")):
        raise ValueError("escribe='dueno' exige dueno_de y viaja 'sube' o 'dos'")
    if d.escribe == "web" and d.viaja != "baja":
        raise ValueError("escribe='web' exige viaja='baja'")
    if (d.acciones or d.copia_local or d.al_aplicar is not None) and d.escribe != "web":
        raise ValueError("acciones, copia_local y al_aplicar solo con escribe='web'")
    if d.copia_local and d.modelo is None:
        raise ValueError("copia_local exige modelo")
    if d.partir is not None and (d.registro is None or d.forma not in (None, "parte")):
        raise ValueError("partir exige registro y forma 'parte'")
    if d.altas_bajas == "web" and d.escribe != "todos":
        raise ValueError("altas_bajas='web' solo con escribe='todos'")
    if d.forma == "fila" and d.modelo is None:
        raise ValueError("forma 'fila' exige modelo")
    if d.forma in ("elemento", "llave", "parte") and d.registro is None:
        raise ValueError("esa forma exige registro")
    if d.baja != "borrar" and not d.baja.startswith("historia:"):
        raise ValueError("baja no válida")
    if d.modelo is not None and getattr(d.modelo, "__name__", "") in MODELOS_PROHIBIDOS:
        raise ValueError("Ese modelo no se sincroniza")
    if d.registro is not None:
        prohibido = d.registro in REGISTROS_PROHIBIDOS or d.registro.startswith("numeracion-") or d.registro.startswith("rrhh_")
        if prohibido or (d.registro == "pos_espera" and d.escribe != "dueno"):
            raise ValueError("Ese registro no se sincroniza")
    DATOS[d.tipo] = d
    _vigilados.clear()
    return d


def dato(tipo: str) -> Optional[Dato]:
    return DATOS.get(tipo)


_resueltas: dict = {}


def _fn(f):
    """Una función, o «modulo.funcion» de app/ resuelta con importlib la primera vez."""
    if f is None or callable(f):
        return f
    if f not in _resueltas:
        mod, _, nombre = str(f).rpartition(".")
        _resueltas[f] = getattr(importlib.import_module(f"app.{mod}" if not mod.startswith("app.") else mod), nombre)
    return _resueltas[f]


def _vig() -> dict:
    """{"items": {clave: tipo}, "registros": {clave: tipo}, "modelos": {clase: tipo}} de lo declarado (filtro rápido del oyente)."""
    if not _vigilados:
        items, regs, mods = {}, {}, {}
        for t, d in DATOS.items():
            if d.modelo is not None:
                mods[d.modelo] = t
            else:
                regs[d.registro] = t
                if d.forma_real == "elemento":
                    items[d.registro] = t
        _vigilados.update({"items": items, "registros": regs, "modelos": mods})
    return _vigilados


# ======================================================================================================================
# Contenido, grupos y huella (contrato §1.2 y §1.5)
# ======================================================================================================================
def _normal(x):
    """En todo nivel, cada float entero (1500.0) pasa a int; lo demás queda igual."""
    if isinstance(x, bool):
        return x
    if isinstance(x, float) and x.is_integer():
        return int(x)
    if isinstance(x, dict):
        return {k: _normal(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_normal(v) for v in x]
    return x


def huella(d: Dato, contenido) -> str:
    """sha1 de lo que viaja (sin `extra`), igual en los dos lados (P2 la importa)."""
    import hashlib
    if isinstance(contenido, dict) and d.extra:
        contenido = {k: v for k, v in contenido.items() if k not in d.extra}
    texto = json.dumps(_normal(contenido), sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)
    return hashlib.sha1(texto.encode("utf-8")).hexdigest()


def _de_fila(d: Dato, obj) -> dict:
    fuera = {"empresa_id", *d.locales, *d.no_viajan}
    return {k: v for k, v in obj.model_dump().items() if k not in fuera}


def _cargar(texto, defecto=None):
    try:
        return json.loads(texto) if texto is not None else defecto
    except (TypeError, ValueError):
        return defecto


def _valor_registro(conn, eid: int, clave: str):
    """(coleccion, datos) del registro, o (None, None) si no existe (lectura cruda: no toca la sesión)."""
    f = conn.execute(_sql("SELECT coleccion, datos FROM registro WHERE empresa_id = :e AND clave = :c ORDER BY id LIMIT 1"), {"e": eid, "c": clave}).first()
    if f is None:
        return None, None
    return bool(f[0]), _cargar(f[1])


def _partes(d: Dato, obj) -> dict:
    """{ref: contenido} de un objeto partido: «_» (sin las listas partidas) y «lista#id»."""
    if not isinstance(obj, dict):
        return {}
    partir = d.partir or {}
    out = {"_": {k: v for k, v in obj.items() if k not in partir}}
    for lista, campo in partir.items():
        for x in obj.get(lista) or [] if isinstance(obj.get(lista), list) else []:
            if isinstance(x, dict) and x.get(campo) is not None:
                out[f"{lista}#{x.get(campo)}"] = x
    return out


def _sub(d: Dato, entero, ref: str):
    """El contenido de `ref` dentro del valor entero de un registro (para elemento guardado como valor, llave y parte)."""
    forma = d.forma_real
    if forma == "llave":
        return entero.get(ref) if isinstance(entero, dict) else None
    if forma == "parte":
        return _partes(d, entero).get(ref)
    if isinstance(entero, list):
        iid = modulos._id_entero(ref)
        return next((x for x in entero if isinstance(x, dict) and modulos._id_entero(x.get("id")) == iid), None)
    return None


def _refs_de(d: Dato, entero) -> set:
    forma = d.forma_real
    if forma == "llave":
        return {str(k) for k in entero} if isinstance(entero, dict) else set()
    if forma == "parte":
        return set(_partes(d, entero))
    if isinstance(entero, list):
        return {str(modulos._id_entero(x.get("id"))) for x in entero if isinstance(x, dict) and modulos._id_entero(x.get("id")) is not None}
    return set()


def _valor_en(conn, eid: int, clave: str, cache: Optional[dict]):
    """_valor_registro, leído y parseado una sola vez por pasada si se da `cache` (el oyente: el registro no cambia mientras decide)."""
    if cache is None:
        return _valor_registro(conn, eid, clave)
    k = (eid, clave)
    if k not in cache:
        cache[k] = _valor_registro(conn, eid, clave)
    return cache[k]


def _contenido(s, eid: int, d: Dato, ref: str, cache: Optional[dict] = None):
    """Lo que viaja del dato (tipo, ref) tal como está AHORA en la transacción de `s` (None si no existe). `cache`: ver _valor_en."""
    conn = s.connection()
    if d.modelo is not None:
        iid = modulos._id_entero(ref)
        if iid is None:
            return None
        obj = s.get(d.modelo, iid, populate_existing=True)
        if obj is None or getattr(obj, "empresa_id", eid) != eid:
            return None
        return _de_fila(d, obj)
    if d.forma_real == "elemento":
        iid = modulos._id_entero(ref)
        if iid is None:
            return None
        f = conn.execute(_sql("SELECT datos FROM registroitem WHERE empresa_id = :e AND clave = :c AND item_id = :i"),
                         {"e": eid, "c": d.registro, "i": iid}).first()
        if f is not None:
            return _cargar(f[0])
        col, entero = _valor_en(conn, eid, d.registro, cache)
        return _sub(d, entero, ref) if col is False else None
    col, entero = _valor_en(conn, eid, d.registro, cache)
    return _sub(d, entero, ref) if col is False else None


def _todos(s, eid: int, d: Dato):
    """[(ref, contenido)] de todo lo que existe de ese dato (siembra)."""
    conn = s.connection()
    if d.modelo is not None:
        from sqlmodel import select
        return [(str(o.id), _de_fila(d, o)) for o in s.exec(select(d.modelo).where(d.modelo.empresa_id == eid)).all()]
    col, entero = _valor_registro(conn, eid, d.registro)
    if col is None:
        return []
    if col and d.forma_real == "elemento":
        out = []
        for iid, texto in conn.execute(_sql("SELECT item_id, datos FROM registroitem WHERE empresa_id = :e AND clave = :c ORDER BY item_id"),
                                       {"e": eid, "c": d.registro}).all():
            c = _cargar(texto)
            if c is not None:
                out.append((str(iid), c))
        return out
    if col:
        return []
    return [(r, _sub(d, entero, r)) for r in sorted(_refs_de(d, entero))]


GRUPO_VALOR = "_"          # una llave cuyo valor no es un objeto: un solo grupo (el mismo nombre que usa sinc_datos_programa._diferencia)


def _campos_de_grupo(d: Dato, g: str) -> tuple:
    """En una fila, los campos de un grupo declarado (o el campo mismo); en un registro cada llave de primer nivel es su propio grupo."""
    return tuple(d.grupos[g]) if (d.modelo is not None and g in d.grupos) else (g,)


def _excluidos(d: Dato) -> set:
    return {"id", "empresa_id", *d.locales, *d.no_viajan, *d.conjuntos, *d.extra}


def grupos_de(d: Dato, contenido) -> dict:
    """{grupo: [valores en el orden de la declaración]} de un contenido, en el formato de las operaciones (contrato §2.2): un grupo de un
    solo campo también va en lista; un campo ausente vale None. En un registro cada llave de primer nivel es su propio grupo; en una fila,
    los de `grupos` y cada campo no nombrado. Un contenido que no es objeto es el grupo «_»."""
    if contenido is None:
        return {}
    if not isinstance(contenido, dict):
        return {GRUPO_VALOR: [contenido]}
    fuera = _excluidos(d)
    grupos = d.grupos if d.modelo is not None else {}
    en_grupo = {c for cs in grupos.values() for c in cs}
    out = {}
    for g, cs in grupos.items():
        if any(c in contenido for c in cs):
            out[g] = [contenido.get(c) for c in cs]
    for k, v in contenido.items():
        if k not in fuera and k not in en_grupo:
            out[k] = [v]
    return out


def _grupo_valido(d: Dato, g: str, contenido) -> bool:
    """Un grupo que un programa puede cambiar: uno declarado (fila), o un campo propio que no es id, local, de la web, conjunto ni parte de
    un grupo declarado. En un contenido que no es objeto, solo «_»."""
    if not isinstance(contenido, dict):
        return g == GRUPO_VALOR
    grupos = d.grupos if d.modelo is not None else {}
    if g in grupos:
        return True
    return g not in _excluidos(d) and g not in {c for cs in grupos.values() for c in cs}


def _valor_grupo(d: Dato, contenido, g: str) -> list:
    """El valor actual de un grupo (campo ausente = None), para compararlo con el «antes» y el «después» de una operación."""
    if not isinstance(contenido, dict):
        return [contenido]
    return [contenido.get(c) for c in _campos_de_grupo(d, g)]


def _poner_grupo(d: Dato, nuevo, g: str, valores):
    """Aplica el valor de un grupo sobre el contenido (devuelve el contenido nuevo)."""
    if not isinstance(nuevo, dict):
        return valores[0] if g == GRUPO_VALOR and valores else nuevo
    for i, c in enumerate(_campos_de_grupo(d, g)):
        nuevo[c] = valores[i] if i < len(valores) else None
    return nuevo


def _elem(x):
    """Un elemento de un conjunto: un texto, o un objeto (las direcciones del cliente). Un objeto puede llegar como dict, como texto JSON o
    con la forma de Python de un dict (el programa arma «mas» y «menos» con str())."""
    if isinstance(x, dict):
        return x
    t = str(x if x is not None else "").strip()
    if t.startswith("{"):
        import ast
        for leer in (json.loads, ast.literal_eval):
            try:
                v = leer(t)
            except Exception:  # noqa: BLE001
                continue
            if isinstance(v, dict):
                return v
    return t


def _llave(x) -> str:
    """Con qué se compara un elemento de un conjunto (un objeto, sin importar el orden de sus llaves)."""
    return json.dumps(x, sort_keys=True, ensure_ascii=False, default=str) if isinstance(x, dict) else str(x)


def _conjunto(v) -> list:
    if isinstance(v, str):
        t = v.strip()
        if t.startswith("["):
            l = _cargar(t, None)
            if isinstance(l, list):
                v = l
        if isinstance(v, str):
            return [x.strip() for x in t.split(",") if x.strip()]
    if isinstance(v, list):
        return [e for e in (_elem(x) for x in v) if e != ""]
    return []


def _como_conjunto(original, lista: list):
    """La lista en la misma forma que tenía el campo (lista JSON, o texto separado por comas). Con objetos, siempre lista JSON."""
    if isinstance(original, list):
        return lista
    if any(isinstance(x, dict) for x in lista) or (isinstance(original, str) and original.strip().startswith("[")):
        return json.dumps(lista, ensure_ascii=False) if lista else (None if original is None else "[]")
    return ",".join(lista) if lista else ("" if isinstance(original, str) else None)


def _unir_conjunto(orig, x: dict):
    """(valor nuevo, cambió) al aplicar «mas» y «menos» sobre el valor actual del campo. Nunca choca."""
    lista = _conjunto(orig)
    tiene = {_llave(v) for v in lista}
    menos = {_llave(_elem(v)) for v in (x.get("menos") or [])}
    nueva = [v for v in lista if _llave(v) not in menos]
    for v in (_elem(v) for v in (x.get("mas") or [])):
        k = _llave(v)
        if v != "" and k not in tiene and k not in menos:
            nueva.append(v); tiene.add(k)
    if [_llave(v) for v in nueva] == [_llave(v) for v in lista]:
        return orig, False
    return _como_conjunto(orig, nueva), True


def diferencia_conjuntos(d: Dato, antes, despues) -> dict:
    out = {}
    for c in d.conjuntos:
        a = {_llave(v) for v in _conjunto((antes or {}).get(c) if isinstance(antes, dict) else None)}
        b = {_llave(v) for v in _conjunto((despues or {}).get(c) if isinstance(despues, dict) else None)}
        if a != b:
            out[c] = {"mas": sorted(b - a), "menos": sorted(a - b)}
    return out


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _fecha(v) -> Optional[datetime]:
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return d if d.tzinfo else None


def _es_programa() -> bool:
    try:
        from . import sinc as _s
        return bool(getattr(_s, "MODO_LOCAL", False))
    except Exception:  # noqa: BLE001
        return os.environ.get("FE_MODO_LOCAL") == "1"


def _hay_tabla(conn, nombre: str) -> bool:
    return conn.execute(_sql("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = :n"), {"n": nombre}).first() is not None


# ======================================================================================================================
# Marca de sembrada, época y modo del oyente
# ======================================================================================================================
_sembradas: set = set()
_lock = threading.Lock()
_FALLOS = [0]


def fallos() -> int:
    """Errores del oyente desde que arrancó el proceso (para Salud)."""
    return _FALLOS[0]


def _contar_fallo() -> None:
    with _lock:
        _FALLOS[0] += 1


def _sembrada_conn(conn, eid: int) -> bool:
    """Siempre en la base (una consulta por índice): la memoria de un proceso no se entera de que otro restauró un respaldo sin la marca.
    `_sembradas` queda solo como registro de lo visto (app/respaldo.py lo limpia)."""
    if not _hay_tabla(conn, "sinc_dato"):
        return False
    if conn.execute(_sql("SELECT 1 FROM sinc_dato WHERE tipo = '_' AND ref = '_'")).first() is not None:
        _sembradas.add(eid)
        return True
    _sembradas.discard(eid)
    return False


def sembrada(eid: int, s=None) -> bool:
    """¿La empresa tiene la marca de sembrada? Se mira en la base cada vez (n.º 11 de la revisión: varios procesos y respaldos)."""
    if s is not None:
        return _sembrada_conn(s.connection(), eid)
    from .db import engine_empresa
    with Session(engine_empresa(eid)) as x:
        return _sembrada_conn(x.connection(), eid)


def _estado_programa(conn, eid: int) -> dict:
    col, v = _valor_registro(conn, eid, CLAVE_ESTADO)
    return v if col is False and isinstance(v, dict) else {}


def _modo_conn(conn, eid: int) -> str:
    if _es_programa():
        return "replica" if _estado_programa(conn, eid).get("protocolo") == 2 else "apagado"
    return "autoridad" if _sembrada_conn(conn, eid) else "apagado"


def oyente_modo(eid: int) -> str:
    """«autoridad» (la web sembrada) · «replica» (programa con protocolo 2) · «apagado»."""
    from .db import engine_empresa
    with Session(engine_empresa(eid)) as x:
        return _modo_conn(x.connection(), eid)


def epoca(s, eid: int) -> str:
    """La época de la web (registro sinc_epoca, 4 a 12 caracteres [a-z0-9]); la crea la primera vez."""
    v = modulos.leer(s, eid, CLAVE_EPOCA, None)
    if isinstance(v, dict) and re.fullmatch(r"[a-z0-9]{4,12}", str(v.get("epoca") or "")):
        return v["epoca"]
    nueva = "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(6))
    try:
        r = modulos._registro(s, eid, CLAVE_EPOCA)
        modulos.reemplazar(s, eid, CLAVE_EPOCA, {"epoca": nueva}, version=(r.version or 0) if r else 0)
    except modulos.ConflictoRegistro:
        s.rollback()
        v = modulos.leer(s, eid, CLAVE_EPOCA, None)
        if isinstance(v, dict) and v.get("epoca"):
            return str(v["epoca"])
    return nueva


# ======================================================================================================================
# El oyente (contrato §1.4, plan §2.5)
# ======================================================================================================================
_SIN = object()          # «no se sabe el valor de antes» (UPDATE crudo, anotar_fila)


def _clave_obj(obj, vig: dict):
    """(eid, tipo, ref) de un objeto que el oyente vigila, o None."""
    if isinstance(obj, RegistroItem):
        t = vig["items"].get(obj.clave)
        return (obj.empresa_id, t, str(obj.item_id)) if t else None
    if isinstance(obj, Registro):
        t = vig["registros"].get(obj.clave)
        return (obj.empresa_id, t, "*") if t else None
    t = vig["modelos"].get(type(obj))
    if t and getattr(obj, "id", None) is not None:
        return (getattr(obj, "empresa_id", None), t, str(obj.id))
    return None


def _antes_de(obj, nuevo: bool, borrado: bool):
    """El contenido de antes del objeto (la primera vez que se ve en la transacción), del historial de atributos. Un objeto nuevo no tenía
    nada (None). Un registro que era colección no tiene «valor de antes» en `datos` (_SIN: sus elementos se ven como RegistroItem)."""
    if nuevo:
        return None
    est = sa_inspect(obj)
    if isinstance(obj, (RegistroItem, Registro)):
        h = est.attrs.datos.history
        texto = h.deleted[0] if (not borrado and h.deleted) else obj.datos
        if isinstance(obj, Registro):
            hc = est.attrs.coleccion.history
            if (hc.deleted[0] if (not borrado and hc.deleted) else obj.coleccion):
                return _SIN
        return _cargar(texto)
    d = DATOS[_vig()["modelos"][type(obj)]]
    previo = {}
    for a in est.mapper.column_attrs:
        h = est.attrs[a.key].history
        previo[a.key] = h.deleted[0] if (not borrado and h.deleted) else getattr(obj, a.key, None)
    fuera = {"empresa_id", *d.locales, *d.no_viajan}
    return {k: v for k, v in previo.items() if k not in fuera}


def _antes_flush(session, _contexto, _instancias) -> None:
    """Acumula lo tocado y, la primera vez que se ve cada dato en la transacción, su valor de antes."""
    try:
        if not DATOS:
            return
        vig = _vig()
        tocado = None
        for objetos, nuevo, borrado in ((session.new, True, False), (session.dirty, False, False), (session.deleted, False, True)):
            for obj in objetos:
                k = _clave_obj(obj, vig)
                if k is None or k[0] is None:
                    continue
                if tocado is None:
                    tocado = session.info.setdefault("sinc_tocado", {})
                if k not in tocado:
                    tocado[k] = _antes_de(obj, nuevo, borrado)
    except Exception:  # noqa: BLE001
        _contar_fallo()
        log.exception("sinc_datos: no se pudo anotar lo tocado")


def _despues_flush(session, _contexto) -> None:
    """B2: una fila nueva sin id (Producto, Cliente o Pedido creados en la web con id automático) recién tiene id después del flush: se
    anota aquí, sin valor de antes (no existía). session.new todavía muestra lo de antes del flush (así lo documenta SQLAlchemy)."""
    try:
        if not DATOS:
            return
        mods = _vig()["modelos"]
        if not mods:
            return
        tocado = None
        for obj in session.new:
            t = mods.get(type(obj))
            if t is None or getattr(obj, "id", None) is None or getattr(obj, "empresa_id", None) is None:
                continue
            if tocado is None:
                tocado = session.info.setdefault("sinc_tocado", {})
            tocado.setdefault((obj.empresa_id, t, str(obj.id)), None)
    except Exception:  # noqa: BLE001
        _contar_fallo()
        log.exception("sinc_datos: no se pudo anotar una fila nueva")


def _vigilado(obj, vig: dict) -> bool:
    """Lo que el oyente vigila, también una fila nueva que todavía no tiene id."""
    return _clave_obj(obj, vig) is not None or type(obj) in vig["modelos"]


def _al_deshacer(session, *_a) -> None:
    session.info.pop("sinc_tocado", None)


def anotar_fila(s: Session, tipo: str, ref) -> None:
    """A mano, para un UPDATE crudo sobre un dato declarado: dentro de la transacción de `s` y ANTES de su commit. Nunca lanza."""
    try:
        d = DATOS.get(tipo)
        if d is None:
            return
        eid = _eid_de_sesion(s)
        if eid is None:
            return
        s.info.setdefault("sinc_tocado", {}).setdefault((eid, tipo, str(ref)), _SIN)
    except Exception:  # noqa: BLE001
        _contar_fallo()
        log.exception("sinc_datos: no se pudo anotar una fila")


def _eid_de_sesion(s) -> Optional[int]:
    if isinstance(s.info.get("eid"), int):
        return s.info["eid"]
    try:
        m = re.search(r"empresa_(\d+)\.db", str(s.get_bind().url))
        return int(m.group(1)) if m else None
    except Exception:  # noqa: BLE001
        return None


def _antes_commit(session) -> None:
    """before_commit corre ANTES del último flush del commit: si hay algo vigilado pendiente se vacía aquí, y después se decide."""
    if not DATOS:
        return
    if not session.info.get("sinc_tocado"):
        try:
            vig = _vig()
            if not any(_vigilado(o, vig) for o in (*session.new, *session.dirty, *session.deleted)):
                return
        except Exception:  # noqa: BLE001
            _contar_fallo()
            log.exception("sinc_datos: no se pudo revisar lo pendiente")
            return
    session.flush()                                     # lo pendiente pasa por _antes_flush (un error aquí lo reporta el commit, como siempre)
    _decidir(session)


def _decidir(session) -> None:
    """Lo acumulado en la transacción se resuelve contra el estado final: versión o lápida (web) u operación (programa)."""
    tocado = session.info.pop("sinc_tocado", None)
    if not tocado:
        return
    try:
        conn = session.connection()
        por_eid: dict = {}
        for (eid, tipo, ref), antes in tocado.items():
            por_eid.setdefault(eid, []).append((tipo, ref, antes))
        for eid, lista in por_eid.items():
            modo = _modo_conn(conn, eid)
            if modo == "apagado":
                continue
            valores: dict = {}                          # n.º 21: cada registro se lee y se parsea una vez por pasada, no una por llave
            for tipo, ref, antes in _expandir(session, eid, lista):
                d = DATOS.get(tipo)
                if d is None:
                    continue
                final = _contenido(session, eid, d, ref, valores)
                if modo == "autoridad":
                    _versionar(conn, eid, d, ref, antes, final)
                elif antes is _SIN or _normal(antes) != _normal(final):    # borrado y vuelto a crear igual: nada que subir
                    _encolar(session, eid, d, ref, antes, final)
    except Exception:  # noqa: BLE001
        _contar_fallo()
        log.exception("sinc_datos: no se pudo anotar un cambio")


def _expandir(s, eid: int, lista: list) -> list:
    """Un registro de valor tocado entero («*») se abre en sus llaves, elementos o partes: las de antes, las de ahora y las ya anotadas."""
    out, vistos = [], set()
    conn = s.connection()
    for tipo, ref, antes in lista:
        d = DATOS.get(tipo)
        if d is None:
            continue
        if ref != "*":
            if (tipo, ref) not in vistos:
                vistos.add((tipo, ref)); out.append((tipo, ref, antes))
            continue
        if d.forma_real == "elemento":
            col, _ = _valor_registro(conn, eid, d.registro)
            if col:
                if antes is _SIN or not isinstance(antes, list):
                    continue                    # pasó a colección: sus elementos llegan como filas de RegistroItem
        col, entero = _valor_registro(conn, eid, d.registro)
        refs = set()
        if antes is not _SIN and antes is not None:
            refs |= _refs_de(d, antes)
        if col is False:
            refs |= _refs_de(d, entero)
        if _hay_tabla(conn, "sinc_dato"):
            refs |= {r for (r,) in conn.execute(_sql("SELECT ref FROM sinc_dato WHERE tipo = :t AND borrado = 0"), {"t": tipo}).all()}
        for r in sorted(refs):
            if (tipo, r) in vistos:
                continue
            vistos.add((tipo, r))
            a = _SIN if antes is _SIN else (_sub(d, antes, r) if antes is not None else None)
            out.append((tipo, r, a))
    return out


def _linea(conn, tipo: str, ref: str):
    return conn.execute(_sql("SELECT id, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta FROM sinc_dato WHERE tipo = :t AND ref = :r"),
                        {"t": tipo, "r": ref}).mappings().first()


def _escribir_linea(conn, tipo: str, ref: str, *, campos: dict, origen: int, dueno=None, borrado=False, foto=None, huella_="", datos=None,
                    etiqueta=None, v: int = 0) -> None:
    conn.execute(_sql("INSERT OR REPLACE INTO sinc_dato (tipo, ref, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta, cambiado) "
                      "VALUES (:t, :r, :v, :c, :o, :du, :b, :f, :h, :da, :e, :ca)"),
                 {"t": tipo, "r": ref, "v": v, "c": json.dumps(campos, ensure_ascii=False), "o": int(origen or 0), "du": dueno, "b": bool(borrado),
                  "f": json.dumps(foto, ensure_ascii=False, default=str) if foto is not None else None, "h": huella_,
                  "da": json.dumps(datos, ensure_ascii=False, default=str) if datos is not None else None, "e": etiqueta, "ca": _ahora()})


def _etiqueta(d: Dato, contenido) -> Optional[str]:
    if d.etiqueta is None or contenido is None:
        return None
    try:
        return str(_fn(d.etiqueta)(contenido))[:120]
    except Exception:  # noqa: BLE001
        return None


def _origen_actual() -> int:
    o = sinc_diario._origen.get()
    return int(o) if o is not None else 0


def _versionar(conn, eid: int, d: Dato, ref: str, antes, final) -> None:
    """Web (autoridad): versión nueva si la huella cambió; lápida con foto si el dato ya no existe."""
    if d.viaja == "sube" or d.escribe == "dueno":
        return                                          # las copias de lo ajeno las escribe aplicar_op; lo propio de la web no baja
    linea = _linea(conn, d.tipo, ref)
    origen = _origen_actual()
    if final is None:
        if linea is None or linea["borrado"]:
            return
        foto = antes if antes is not _SIN else None
        _escribir_linea(conn, d.tipo, ref, campos=_cargar(linea["campos"], {}) or {}, origen=origen, borrado=True, foto=foto,
                        huella_=linea["huella"] or "", etiqueta=linea["etiqueta"])
        return
    h = huella(d, final)
    if linea is not None and not linea["borrado"] and linea["huella"] == h:
        return
    campos = (_cargar(linea["campos"], {}) or {}) if linea is not None else {}
    ahora = _ahora()
    ga, gf = (grupos_de(d, antes) if antes not in (_SIN, None) else None), grupos_de(d, final)
    for g, val in gf.items():
        if ga is None or _normal(ga.get(g, [])) != _normal(val) or linea is None or linea["borrado"]:
            campos[g] = ahora
    if ga is not None:
        for g in ga:
            if g not in gf:
                campos[g] = ahora
    for c in diferencia_conjuntos(d, antes if antes is not _SIN else None, final):
        campos[c] = ahora
    _escribir_linea(conn, d.tipo, ref, campos=campos, origen=origen, huella_=h, etiqueta=_etiqueta(d, final))


# ---- programa (réplica) ----
def _pasa(d: Dato, contenido) -> bool:
    if contenido is None:
        return False
    if d.filtro is None:
        return True
    try:
        return bool(_fn(d.filtro)(contenido))
    except Exception:  # noqa: BLE001
        return False


def _dueno(d: Dato, ref: str, contenido) -> Optional[int]:
    if d.dueno_de == "rango":
        iid = modulos._id_entero(ref)
        return iid // RANGO if iid is not None else None
    try:
        return int(_fn(d.dueno_de)(contenido or {}))
    except Exception:  # noqa: BLE001
        return None


def _encolar(session, eid: int, d: Dato, ref: str, antes, final) -> None:
    """Programa con protocolo 2: la operación la arma y la funde sinc_datos_programa.anotar (P2), en la misma transacción del dato. Un
    «antes» desconocido (UPDATE crudo) va como objeto vacío: cada grupo sube como cambio y la web arbitra por la hora."""
    if d.escribe == "web" or d.viaja == "baja" or (d.escribe == "todos" and sinc_diario._origen.get() is not None):
        return                                          # nunca sube; o llegó de afuera (aplicando): no se devuelve
    try:
        from . import sinc_datos_programa as _sdp
    except ImportError:
        return
    if antes is _SIN:
        antes = {} if (final is None or isinstance(final, dict)) else None
    _sdp.anotar(session, eid, d.tipo, ref, antes, final, POR.get())


POR: contextvars.ContextVar = contextvars.ContextVar("sinc_datos_por", default=None)   # quién guarda en el programa (lo fija P2, opcional)

event.listen(Session, "before_flush", _antes_flush)
event.listen(Session, "after_flush", _despues_flush)
event.listen(Session, "before_commit", _antes_commit)
event.listen(Session, "after_rollback", _al_deshacer)


# ======================================================================================================================
# Siembra (web)
# ======================================================================================================================
def _sembrables() -> list:
    return [d for d in DATOS.values() if d.escribe in ("todos", "web") and d.viaja in ("dos", "baja")]


def sembrar(s, eid: int, tramo: int = 2000, terminal: Optional[int] = None) -> bool:
    """Web: crea las líneas de sinc_dato de todo lo declarado que existe, por tramos y con el bloqueo de escritura tomado. El último tramo
    revisa por huella lo ya sembrado (lo cambiado entre tramos recibe versión; lo que ya no existe, lápida) y escribe la marca, también en
    una empresa vacía. Con `terminal` (la del programa que llama), en esa misma transacción pedidos.fijar_atiende_al_sembrar (§4.1 del plan).
    True si terminó."""
    conn = s.connection()
    conn.execute(_sql("UPDATE sinc_dato SET id = id WHERE 0"))          # toma el bloqueo de escritura antes de leer
    if conn.execute(_sql("SELECT 1 FROM sinc_dato WHERE tipo = '_' AND ref = '_'")).first() is not None:
        s.commit(); _sembradas.add(eid)
        return True
    existentes = {(t, r): (h, b) for t, r, h, b in conn.execute(_sql("SELECT tipo, ref, huella, borrado FROM sinc_dato WHERE tipo <> '_'")).all()}
    todos = []
    for d in _sembrables():
        for ref, cont in _todos(s, eid, d):
            if cont is not None and _pasa(d, cont):
                todos.append((d, ref, cont))
    faltan = [x for x in todos if (x[0].tipo, x[1]) not in existentes]
    for d, ref, cont in faltan[:max(1, int(tramo))]:
        conn.execute(_sql("INSERT OR IGNORE INTO sinc_dato (tipo, ref, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta, cambiado) "
                          "VALUES (:t, :r, 0, '{}', 0, NULL, 0, NULL, :h, NULL, :e, :c)"),
                     {"t": d.tipo, "r": ref, "h": huella(d, cont), "e": _etiqueta(d, cont), "c": _ahora()})
    if len(faltan) > max(1, int(tramo)):
        s.commit()
        return False
    vistos = set()
    for d, ref, cont in todos:
        vistos.add((d.tipo, ref))
        previo = existentes.get((d.tipo, ref))
        if previo is not None and (previo[1] or previo[0] != huella(d, cont)):
            _escribir_linea(conn, d.tipo, ref, campos={g: _ahora() for g in grupos_de(d, cont)}, origen=0, huella_=huella(d, cont), etiqueta=_etiqueta(d, cont))
    tipos = {d.tipo for d in _sembrables()}
    for (t, r), (h, b) in existentes.items():
        if t in tipos and not b and (t, r) not in vistos:
            d = DATOS[t]
            if _contenido(s, eid, d, r) is None:
                _escribir_linea(conn, t, r, campos={}, origen=0, borrado=True, huella_=h or "")
    conn.execute(_sql("INSERT OR IGNORE INTO sinc_dato (tipo, ref, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta, cambiado) "
                      "VALUES ('_', '_', 0, '{}', 0, NULL, 0, NULL, '', NULL, NULL, :c)"), {"c": _ahora()})
    if terminal:
        try:
            from . import pedidos
            f = getattr(pedidos, "fijar_atiende_al_sembrar", None)
            if f is not None:
                f(s, eid, terminal)                                    # nunca lanza y no confirma: va en esta transacción
        except ImportError:
            pass
    s.commit()
    _sembradas.add(eid)
    return True


_RESIEMBRA: dict = {}                       # {eid: {"tope", "cursor", "hecha"}}: la resiembra por huella, en memoria por proceso


def resiembra_encendida() -> bool:
    return os.environ.get("FE_SINC_RESEMBRAR") == "1"


def resembrar(s, eid: int, tramo: int = 2000) -> bool:
    """§2.10 del plan: el código de la web volvió a la 4.31 (sin oyente) y otra vez a la 4.32. Por tramos, con el bloqueo de escritura tomado:
    cada línea viva sembrada antes de empezar cuya huella ya no coincide recibe versión nueva; la que ya no existe (o ya no pasa el filtro)
    recibe lápida. Al terminar, lo creado mientras corría la 4.31 (sin línea) recibe su línea con versión. Lo que tiene lápida no revive.
    Confirma cada tramo. True si terminó (una vez por empresa y proceso)."""
    est = _RESIEMBRA.get(eid)
    if est is not None and est["hecha"]:
        return True
    conn = s.connection()
    conn.execute(_sql("UPDATE sinc_dato SET id = id WHERE 0"))          # toma el bloqueo de escritura antes de leer
    if est is None:
        est = {"tope": int(conn.execute(_sql("SELECT COALESCE(MAX(id), 0) FROM sinc_dato")).scalar() or 0), "cursor": 0, "hecha": False}
        _RESIEMBRA[eid] = est
    tipos = {d.tipo for d in _sembrables()}
    lineas = conn.execute(_sql("SELECT id, tipo, ref, huella, campos, etiqueta FROM sinc_dato WHERE id > :c AND id <= :t AND tipo <> '_' AND borrado = 0 "
                               "ORDER BY id LIMIT :l"), {"c": est["cursor"], "t": est["tope"], "l": max(1, int(tramo))}).mappings().all()
    for linea in lineas:
        est["cursor"] = int(linea["id"])
        if linea["tipo"] not in tipos:
            continue
        d = DATOS[linea["tipo"]]
        cont = _contenido(s, eid, d, linea["ref"])
        campos = _cargar(linea["campos"], {}) or {}
        if cont is None or not _pasa(d, cont):
            _escribir_linea(conn, d.tipo, linea["ref"], campos=campos, origen=0, borrado=True, huella_=linea["huella"] or "", etiqueta=linea["etiqueta"])
        elif huella(d, cont) != (linea["huella"] or ""):
            ahora = _ahora()
            campos.update({g: ahora for g in grupos_de(d, cont)})
            _escribir_linea(conn, d.tipo, linea["ref"], campos=campos, origen=0, huella_=huella(d, cont), etiqueta=_etiqueta(d, cont))
    if len(lineas) < max(1, int(tramo)):
        existentes = {(t, r) for t, r in conn.execute(_sql("SELECT tipo, ref FROM sinc_dato")).all()}
        for d in _sembrables():
            for ref, cont in _todos(s, eid, d):
                if cont is not None and _pasa(d, cont) and (d.tipo, ref) not in existentes:
                    _escribir_linea(conn, d.tipo, ref, campos={g: _ahora() for g in grupos_de(d, cont)}, origen=0, huella_=huella(d, cont),
                                    etiqueta=_etiqueta(d, cont))
        est["hecha"] = True
    s.commit()
    return est["hecha"]


# ======================================================================================================================
# aplicar_op (web): una operación de un programa (contrato §1.4, §2.2)
# ======================================================================================================================
def _pisado(conn, tipo: str, ref: str, *, nombre: str = "", campo: str = "", motivo: str, perdio=None, perdio_de: str = "", quedo_de: str = "") -> None:
    texto = json.dumps(perdio, ensure_ascii=False, default=str)[:4000]
    conn.execute(_sql("INSERT INTO sinc_pisado (cuando, tipo, ref, nombre, campo, motivo, perdio, perdio_de, quedo_de, visto) "
                      "VALUES (:cu, :t, :r, :n, :ca, :m, :p, :pd, :qd, 0)"),
                 {"cu": _ahora(), "t": tipo, "r": str(ref)[:60], "n": str(nombre or "")[:120], "ca": str(campo or "")[:60], "m": motivo, "p": texto,
                  "pd": str(perdio_de or "")[:80], "qd": str(quedo_de or "")[:80]})


REINTENTAR = "reintentar"   # (I-2) la op no se aplicó por algo pasajero (motivo «error» o «plan_vencido»): la web no la anotó; se reenvía


def _resultado(op: dict, estado: str, motivo=None, v=None, ref=None, canonico=None, pisados=None) -> dict:
    return {"n": op.get("n"), "estado": estado, "motivo": motivo, "v": v, "ref": str(ref if ref is not None else op.get("ref")),
            "canonico": canonico, "pisados": pisados or []}


def _nombre(c) -> str:
    return str(c.get("nombre") or "")[:120] if isinstance(c, dict) else ""


def _hora_op(cuando, llegada: datetime, hora_local: Optional[datetime]) -> datetime:
    """cuando + (llegada − hora_local), nunca después de la llegada."""
    c = _fecha(cuando)
    if c is None or hora_local is None:
        return llegada
    return min(c + (llegada - hora_local), llegada)


def _escribir_dato(s, eid: int, d: Dato, ref: str, valor) -> bool:
    forma = d.forma_real
    if forma == "elemento":
        return modulos.aplicar_elemento(s, eid, d.registro, int(ref), valor)
    if forma in ("llave", "parte"):
        return modulos.aplicar_llave(s, eid, d.registro, ref, valor, d.partir)
    raise ValueError("Las filas se aplican en el bloque B2")


def _id_nuevo(s, eid: int, d: Dato, terminal: int) -> int:
    try:
        from . import sinc_completar
        return int(sinc_completar.id_nuevo_elemento(s, eid, d.registro, terminal))
    except ImportError:
        pass
    lo = terminal * RANGO
    usados = [i for i in (modulos._id_entero(r) for (r,) in s.connection().execute(_sql("SELECT ref FROM sinc_dato WHERE tipo = :t"), {"t": d.tipo}).all())
              if i is not None and lo < i < lo + RANGO]
    usados += [i for i in (modulos._id_entero(r) for r, _ in _todos(s, eid, d)) if i is not None and lo < i < lo + RANGO]
    return max(usados + [lo]) + 1


def aplicar_op(s, eid: int, ctx, inst: dict, op: dict, llegada: datetime, hora_local: Optional[datetime]) -> dict:
    """Web: aplica UNA operación de un programa y la confirma (con su línea en sinc_cambio). `op` lleva además «autora» (la pone la ruta).
    Devuelve un resultado de §2.2. Nunca escribe la tabla de trabajo de un dato «dueno»."""
    terminal = int((inst or {}).get("terminal") or 0)
    por = _por(op.get("por"))
    conn = s.connection()
    conn.execute(_sql("UPDATE sinc_cambio SET id = id WHERE 0"))       # bloqueo de escritura antes de leer
    previo = conn.execute(_sql("SELECT resultado FROM sinc_cambio WHERE autora = :a AND n = :n"), {"a": op["autora"], "n": op["n"]}).first()
    if previo is not None:
        s.rollback()
        guardado = _cargar(previo[0], {}) or {}
        return {**_resultado(op, "repetido"), **{k: v for k, v in guardado.items() if k not in ("n", "estado")}, "estado": "repetido"}
    d = DATOS.get(op.get("tipo"))
    ref = str(op.get("ref"))
    clase = op.get("op")
    datos = op.get("datos") if isinstance(op.get("datos"), dict) else {}
    datos_registro = datos
    pid_pedido = None
    if d is None:
        res = _resultado(op, "rechazado", "no_valido")
    elif clase != "copia" and _plan_vencido(ctx):
        s.rollback()                                    # (I-2) pasajero: ni sinc_cambio ni sinc_pisado; el programa la reenvía al renovar
        return _resultado(op, REINTENTAR, "plan_vencido")
    elif d.escribe == "dueno":
        pid_pedido = _pedido_de_copia(conn, d, ref, datos) if d.tipo == "cuenta" and clase == "copia" else None
        res = _op_copia(s, eid, d, ref, op, datos, terminal, por) if clase == "copia" else _resultado(op, "rechazado", "no_valido")
    elif d.escribe == "todos" and clase == "baja" and _frenar(conn, eid, terminal):
        actual = _contenido(s, eid, d, ref)
        _pisado(conn, d.tipo, ref, nombre=_nombre(actual), motivo="freno", perdio=actual, perdio_de=por or f"terminal {terminal}", quedo_de=WEB)
        res = _resultado(op, "rechazado", "freno", canonico=actual)
    elif d.escribe == "todos" and clase in ("alta", "cambio", "baja"):
        if clase == "baja":
            datos_registro = {**datos, "foto_web": _contenido(s, eid, d, ref)}      # auditoría: lo que había en la web al eliminarlo
        if d.modelo is None:
            res = _op_todos(s, eid, d, ref, op, clase, datos, terminal, por, llegada, hora_local)
        else:
            res = _op_fila(s, eid, ctx, inst, d, ref, op, clase, datos, terminal, por, llegada, hora_local)
    else:
        res = _resultado(op, "rechazado", "no_valido", canonico=_contenido(s, eid, d, ref) if d.escribe == "todos" else None)
    conn = s.connection()
    conn.execute(_sql("INSERT INTO sinc_cambio (autora, n, tipo, ref, op, base_v, datos, por, estado, resultado, intentos, creado) "
                      "VALUES (:a, :n, :t, :r, :o, :b, :d, :p, :e, :res, 0, :c)"),
                 {"a": op["autora"], "n": op["n"], "t": str(op.get("tipo"))[:30], "r": ref[:60], "o": str(clase)[:10], "b": int(op.get("base_v") or 0),
                  "d": json.dumps(datos_registro, ensure_ascii=False, default=str), "p": por, "e": res["estado"],
                  "res": json.dumps(res, ensure_ascii=False, default=str), "c": _ahora()})
    s.commit()
    if pid_pedido and res["estado"] == "aplicado":
        _gancho_pedidos("reintentar_enlaces", s, eid, None, int(pid_pedido))   # §4.5 (R3-3): al llegar la copia o la lápida de la cuenta; nunca lanza
    return res


def _pedido_de_copia(conn, d: Dato, ref: str, datos: dict) -> Optional[int]:
    """pedido_id de la copia que llega o, con {"fila": null}, de la copia que había en sinc_dato.datos (para reintentar el enlace)."""
    fila = datos.get("fila")
    if fila is None:
        linea = _linea(conn, d.tipo, ref)
        fila = _cargar(linea["datos"]) if linea is not None else None
    try:
        return int(fila["pedido_id"]) if isinstance(fila, dict) and fila.get("pedido_id") else None
    except (TypeError, ValueError):
        return None


def _plan_vencido(ctx) -> bool:
    try:
        from . import planes
        return bool(planes.vencido(ctx.empresa))
    except Exception:  # noqa: BLE001
        return False


def _por(v) -> Optional[str]:
    if not isinstance(v, str):
        return None
    t = " ".join("".join(ch if ch.isprintable() else " " for ch in v).split())[:80]
    return t or None


def _pedido_de_otra(conn, eid: int, d: Dato, contenido, terminal: int) -> bool:
    """Revisión n.º 34: la copia (o la lápida) de una cuenta que nombra un pedido que atiende OTRA computadora (atiende > 0 y distinto)
    no entra: con ella pedidos.estado_efectivo daría por entregado un pedido ajeno. Pedido con atiende 0 o vacío, sin pedido_id o
    sin la tabla: como antes (False)."""
    if d.tipo != "cuenta" or not isinstance(contenido, dict):
        return False
    pid = modulos._id_entero(contenido.get("pedido_id"))
    if pid is None:
        return False
    if not conn.execute(_sql("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'pedido'")).first():
        return False
    fila = conn.execute(_sql("SELECT atiende FROM pedido WHERE id = :i AND empresa_id = :e"), {"i": pid, "e": eid}).first()
    try:
        atiende = int(fila[0] or 0) if fila is not None else 0
    except (TypeError, ValueError):
        return False
    return atiende > 0 and atiende != int(terminal)


def _op_copia(s, eid: int, d: Dato, ref: str, op: dict, datos: dict, terminal: int, por) -> dict:
    """«dueno»: la copia del dueño va a sinc_dato.datos; nunca a la tabla de trabajo. De otra terminal: no_dueno."""
    conn = s.connection()
    if "fila" not in datos or not (datos["fila"] is None or isinstance(datos["fila"], dict)):
        return _resultado(op, "rechazado", "no_valido")
    fila = datos["fila"]
    linea = _linea(conn, d.tipo, ref)
    contenido = fila if fila is not None else _cargar(linea["datos"]) if linea is not None else None
    if _dueno(d, ref, contenido) != terminal or _pedido_de_otra(conn, eid, d, contenido, terminal):
        _pisado(conn, d.tipo, ref, nombre=_nombre(fila), motivo="no_dueno", perdio=fila, perdio_de=por or f"terminal {terminal}", quedo_de=WEB)
        return _resultado(op, "rechazado", "no_dueno")
    if fila is not None and not _pasa(d, fila):
        fila = None
    antes_id = linea["id"] if linea is not None else None
    if fila is None:
        if linea is None or linea["borrado"]:
            return _resultado(op, "aplicado")
        _escribir_linea(conn, d.tipo, ref, campos={}, origen=terminal, dueno=terminal, borrado=True, foto=_cargar(linea["datos"]),
                        huella_=linea["huella"] or "", etiqueta=linea["etiqueta"])
    else:
        h = huella(d, fila)
        if linea is not None and not linea["borrado"] and linea["huella"] == h:
            return _resultado(op, "aplicado")
        _escribir_linea(conn, d.tipo, ref, campos={}, origen=terminal, dueno=terminal, huella_=h, datos=fila, etiqueta=_etiqueta(d, fila))
    nueva = _linea(conn, d.tipo, ref)
    return _resultado(op, "aplicado", v=nueva["id"] if nueva is not None and nueva["id"] != antes_id else None)


def _arbitrar(conn, d: Dato, ref: str, actual, datos: dict, campos_web: dict, pisados: list, llegada, hora_local, terminal: int, por):
    """§2.9 del plan, por grupo: ya vale «después» → nada; vale «antes» → aplica; otra cosa → conflicto y gana la última hora de la web (el
    que pierde va a sinc_pisado; si pierde el programa, también a `pisados`). Después los conjuntos (lo agregado y lo quitado; nunca chocan).
    Devuelve (contenido nuevo, grupos aplicados, si se unió un conjunto). No escribe el dato."""
    campos_op = datos.get("campos") if isinstance(datos.get("campos"), dict) else {}
    conjuntos_op = datos.get("conjuntos") if isinstance(datos.get("conjuntos"), dict) else {}
    nuevo = json.loads(json.dumps(actual, default=str)) if isinstance(actual, (dict, list)) else actual
    aplicados = 0
    for g, trio in campos_op.items():
        if not (isinstance(trio, list) and len(trio) == 3 and isinstance(trio[0], (list, type(None))) and isinstance(trio[1], list)):
            continue
        if not _grupo_valido(d, g, actual):
            continue
        antes_g, despues_g, cuando = trio
        cur = _valor_grupo(d, nuevo, g)
        if _normal(cur) == _normal(despues_g):
            continue
        if antes_g is not None and _normal(cur) == _normal(antes_g):
            nuevo = _poner_grupo(d, nuevo, g, despues_g); aplicados += 1
            continue
        t_op = _hora_op(cuando, llegada, hora_local)
        t_web = _fecha(campos_web.get(g))
        if t_web is None or t_op > t_web:
            nuevo = _poner_grupo(d, nuevo, g, despues_g); aplicados += 1
            _pisado(conn, d.tipo, ref, nombre=_nombre(actual), campo=g, motivo="conflicto", perdio=cur, perdio_de=WEB, quedo_de=por or f"terminal {terminal}")
        else:
            pisados.append({"campo": g, "motivo": "conflicto", "perdio": despues_g})
            _pisado(conn, d.tipo, ref, nombre=_nombre(actual), campo=g, motivo="conflicto", perdio=despues_g, perdio_de=por or f"terminal {terminal}", quedo_de=WEB)
    unio = False
    for c, x in conjuntos_op.items():
        if c not in d.conjuntos or not isinstance(x, dict) or not isinstance(nuevo, dict):
            continue
        valor, cambio = _unir_conjunto(nuevo.get(c), x)
        if cambio:
            nuevo[c] = valor; unio = True
    return nuevo, aplicados, unio


def _op_todos(s, eid: int, d: Dato, ref: str, op: dict, clase: str, datos: dict, terminal: int, por, llegada, hora_local) -> dict:
    """«todos» sobre un elemento, llave o parte de un registro: arbitra por grupo (§2.9 del plan)."""
    pisados = []
    estado, motivo = "aplicado", None
    ref_final = ref
    with sinc_diario.aplicando(terminal):
        conn = s.connection()
        if d.forma_real == "elemento" and modulos._id_entero(ref) is None:
            return _resultado(op, "rechazado", "no_valido")
        actual = _contenido(s, eid, d, ref)
        linea = _linea(conn, d.tipo, ref) if _hay_tabla(conn, "sinc_dato") else None
        antes_id = linea["id"] if linea is not None else None
        if clase in ("alta", "baja") and d.altas_bajas == "web":
            return _resultado(op, "rechazado", "no_valido", canonico=actual)
        if clase == "alta":
            fila = datos.get("fila")
            if not isinstance(fila, dict) and not (d.forma_real == "llave" and "fila" in datos):
                return _resultado(op, "rechazado", "no_valido", canonico=actual)
            borrada = linea is not None and linea["borrado"]
            elemento = d.forma_real == "elemento"
            propio = not elemento or modulos.en_rango(int(ref), terminal)       # un programa crea elementos solo con ids de su rango
            guardado = {**fila, "id": int(ref)} if elemento else fila
            if actual is not None and huella(d, actual) == huella(d, guardado):
                pass                                                    # ya está igual (reenvío)
            elif actual is None and not borrada and propio:
                _escribir_dato(s, eid, d, ref, fila)
            elif elemento:                                              # el id ya existe con otro contenido o con lápida: id nuevo de su rango
                nuevo = _id_nuevo(s, eid, d, terminal)
                _escribir_dato(s, eid, d, str(nuevo), {**fila, "id": nuevo})
                estado, ref_final = "renumerar", str(nuevo)
            elif borrada:
                return _resultado(op, "rechazado", "eliminado")
            else:
                return _resultado(op, "rechazado", "conflicto", canonico=actual)
        elif clase == "baja":
            if actual is not None:
                _escribir_dato(s, eid, d, ref, None)
        else:
            if actual is None:
                _pisado(conn, d.tipo, ref, motivo="eliminado", perdio=datos, perdio_de=por or f"terminal {terminal}", quedo_de=WEB,
                        nombre=_nombre(_cargar(linea["foto"]) if linea is not None else None))
                return _resultado(op, "rechazado", "eliminado")
            campos_web = (_cargar(linea["campos"], {}) or {}) if linea is not None else {}
            nuevo, aplicados, unio = _arbitrar(conn, d, ref, actual, datos, campos_web, pisados, llegada, hora_local, terminal, por)
            if pisados and not aplicados and not unio:
                estado, motivo = "rechazado", "conflicto"
            elif pisados or unio:
                estado = "fusionado"
            if _normal(nuevo) != _normal(actual):
                _escribir_dato(s, eid, d, ref, nuevo)
        s.flush()
        _decidir(s)                                                    # la versión se escribe ya (origen = esta terminal)
        conn = s.connection()
        nueva = _linea(conn, d.tipo, ref_final) if _hay_tabla(conn, "sinc_dato") else None
        v = nueva["id"] if nueva is not None and (ref_final != ref or nueva["id"] != antes_id) else None
        canonico = _contenido(s, eid, d, ref_final)
    return _resultado(op, estado, motivo, v=v, ref=ref_final, canonico=canonico, pisados=pisados)


# ---- filas (Producto, Cliente): bloque B2 ----
FRENO_MINIMO, FRENO_PARTE = 25, 0.05        # bajas en 24 h desde una misma computadora: max(25, 5 % de ítems y clientes activos)
MAX_OPS_DIA = 20_000                        # operaciones por computadora en 24 h


def _desde_24h() -> str:
    from datetime import timedelta
    return (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec="seconds")


def _frenar(conn, eid: int, terminal: int) -> bool:
    """Freno de bajas (§2.7, solo escribe="todos"): ¿esta computadora ya hizo sus bajas permitidas de las últimas 24 h? Las bajas se cuentan
    al confirmarse (aplicadas en la web): un reemplazar que borra y recrea no cuenta, porque nunca llega como baja."""
    activos = 0
    for tabla in ("producto", "cliente"):
        if _hay_tabla(conn, tabla):
            activos += int(conn.execute(_sql(f"SELECT COUNT(*) FROM {tabla} WHERE empresa_id = :e AND activo = 1"), {"e": eid}).scalar() or 0)
    limite = max(FRENO_MINIMO, int(activos * FRENO_PARTE))
    hechas = conn.execute(_sql("SELECT COUNT(*) FROM sinc_cambio WHERE autora >= :a AND autora < :b AND op = 'baja' AND estado = 'aplicado' "
                               "AND creado >= :d"), {**_autoras_de(terminal), "d": _desde_24h()}).scalar() or 0
    return int(hechas) >= limite


def _autoras_de(terminal: int) -> dict:
    """Las autoras «<terminal>.<época>» como rango [a, b) (usa el índice de autora; LIKE en SQLite no lo usa). «/» sigue a «.» en ASCII."""
    return {"a": f"{int(terminal)}.", "b": f"{int(terminal)}/"}


def ops_del_dia(conn, terminal: int) -> int:
    """Operaciones recibidas de esa computadora en las últimas 24 h (tope MAX_OPS_DIA)."""
    return int(conn.execute(_sql("SELECT COUNT(*) FROM sinc_cambio WHERE autora >= :a AND autora < :b AND creado >= :d"),
                            {**_autoras_de(terminal), "d": _desde_24h()}).scalar() or 0)


# ---- purga de la web (contrato §4.3 y §4.4; n.º 33 de la revisión) ----
DIAS_CAMBIO, DIAS_CAMBIO_LARGO, DIAS_PISADO, FILAS_PISADO = 90, 365, 365, 5000
PURGA_CADA = 3600                           # segundos, por empresa y proceso
_PURGA: dict = {}                           # {eid: time.time() de la última purga en este proceso}
_INDICES_PURGA = ("CREATE INDEX IF NOT EXISTS ix_sinc_dato_dueno ON sinc_dato (dueno, borrado)",
                  "CREATE INDEX IF NOT EXISTS ix_sinc_cambio_creado ON sinc_cambio (creado)")


def _hace_dias(dias: int) -> str:
    from datetime import timedelta
    return (datetime.now(timezone.utc) - timedelta(days=dias)).isoformat(timespec="seconds")


def purgar_web(s, eid: int, forzar: bool = False) -> None:
    """Web: sinc_cambio guarda 90 días lo aplicado sin choques y 1 año lo demás (conflicto, rechazo, baja, con pisados), siempre con la
    última fila de cada autora (de ahí sale n_max); sinc_pisado guarda 365 días y como mucho 5000 filas. Asegura los índices de las bases
    creadas antes de declararlos. Como mucho cada PURGA_CADA segundos por empresa en este proceso; confirma; nunca lanza.
    Las lápidas de cuentas NO se purgan aquí (pendiente: necesitan el estado del pedido)."""
    ahora = time.time()
    if not forzar and ahora - _PURGA.get(eid, 0) < PURGA_CADA:
        return
    _PURGA[eid] = ahora
    try:
        conn = s.connection()
        if not (_hay_tabla(conn, "sinc_cambio") and _hay_tabla(conn, "sinc_pisado")):
            return
        for sql in _INDICES_PURGA:
            conn.execute(_sql(sql))
        conn.execute(_sql("DELETE FROM sinc_cambio WHERE creado < :corto "
                          "AND (creado < :largo OR (estado = 'aplicado' AND op <> 'baja' AND resultado LIKE '%\"pisados\": []%')) "
                          "AND id NOT IN (SELECT MAX(id) FROM sinc_cambio GROUP BY autora)"),
                     {"corto": _hace_dias(DIAS_CAMBIO), "largo": _hace_dias(DIAS_CAMBIO_LARGO)})
        conn.execute(_sql("DELETE FROM sinc_pisado WHERE cuando < :l"), {"l": _hace_dias(DIAS_PISADO)})
        conn.execute(_sql("DELETE FROM sinc_pisado WHERE id NOT IN (SELECT id FROM sinc_pisado ORDER BY id DESC LIMIT :n)"), {"n": FILAS_PISADO})
        s.commit()
    except Exception as ex:  # noqa: BLE001
        s.rollback()
        log.warning("sinc_datos: no se pudo purgar (%s)", type(ex).__name__)


def _campos_modelo(d: Dato, contenido: dict) -> dict:
    """Los campos de la tabla que el programa puede escribir: sin id, empresa_id, locales ni los que no viajan."""
    fuera = {"id", "empresa_id", *d.locales, *d.no_viajan, *d.extra}
    return {k: v for k, v in (contenido or {}).items() if k in d.modelo.model_fields and k not in fuera}


def _validar_fila(d: Dato, ctx, campos: dict):
    """(campos validados y normalizados, None) o (None, mensaje): corre la validación de la pantalla (`validar`, p. ej. main._validar_producto)
    sobre una copia suelta que nunca entra a la sesión."""
    try:
        obj = d.modelo(**campos)
    except Exception:  # noqa: BLE001
        return None, "Los datos no son válidos"
    if d.validar is not None:
        sin_fe = getattr(getattr(ctx, "empresa", None), "factura_electronica", True) is False      # lo mismo que main._sin_fe
        try:
            _fn(d.validar)(obj, sin_fe)
        except HTTPException as ex:
            return None, ex.detail if isinstance(ex.detail, str) else "Los datos no son válidos"
    return _campos_modelo(d, {k: getattr(obj, k, None) for k in d.modelo.model_fields}), None    # con lo que la validación ajustó


def _norm_cod(c) -> str:
    return str(c if c is not None else "").strip().lower()


def _codigos_libres(s, eid: int, pid: int, campos: dict, actual: Optional[dict], pisados: list, conn, terminal: int, por) -> dict:
    """La protección de códigos de la 4.24 (etiquetas.otro_con_codigo): un código o código alterno NUEVO que ya usa otro ítem no entra
    (motivo codigo_repetido, solo ese grupo); lo demás de la operación sigue."""
    from . import etiquetas
    filas = etiquetas._codigos_de_la_empresa(s, eid)
    antes_cod = (actual or {}).get("codigo")
    cod = campos.get("codigo")
    if cod and _norm_cod(cod) != _norm_cod(antes_cod) and etiquetas.otro_con_codigo(s, eid, cod, pid, filas) is not None:
        campos["codigo"] = antes_cod
        pisados.append({"campo": "codigos", "motivo": "codigo_repetido", "perdio": [cod]})
        _pisado(conn, "producto", str(pid), nombre=_nombre(campos), campo="codigos", motivo="codigo_repetido", perdio=[cod],
                perdio_de=por or f"terminal {terminal}", quedo_de=WEB)
    if campos.get("codigos_alternos"):
        tenia = {_norm_cod(x) for x in _conjunto((actual or {}).get("codigos_alternos"))}
        quedan, fuera = [], []
        for x in _conjunto(campos.get("codigos_alternos")):
            if _norm_cod(x) not in tenia and etiquetas.otro_con_codigo(s, eid, x, pid, filas) is not None:
                fuera.append(x)
            else:
                quedan.append(x)
        if fuera:
            campos["codigos_alternos"] = _como_conjunto(campos.get("codigos_alternos"), quedan) or None
            pisados.append({"campo": "codigos_alternos", "motivo": "codigo_repetido", "perdio": fuera})
            _pisado(conn, "producto", str(pid), nombre=_nombre(campos), campo="codigos_alternos", motivo="codigo_repetido", perdio=fuera,
                    perdio_de=por or f"terminal {terminal}", quedo_de=WEB)
    return campos


def _baja_de_fila(s, eid: int, d: Dato, obj) -> None:
    """La regla de baja de la declaración (contrato §1.4). «historia:…» → con historia queda inactivo (el ítem además suelta sus códigos,
    como main._borrar_producto_aqui); sin historia se borra (el ítem con sus existencias)."""
    regla = d.baja or "borrar"
    if regla.startswith("historia:") and _fn(regla.split(":", 1)[1])(s, eid, int(obj.id)):
        if hasattr(obj, "activo"):
            obj.activo = False
        if d.modelo.__name__ == "Producto":
            obj.codigo = None
            obj.codigos_alternos = None
        s.add(obj)
        return
    if d.modelo.__name__ == "Producto":
        from sqlmodel import select
        from . import inventario
        for ex in s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == obj.id)).all():
            s.delete(ex)
        for m in s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.producto_id == obj.id)).all():
            s.delete(m)
    s.delete(obj)


def _op_fila(s, eid: int, ctx, inst: dict, d: Dato, ref: str, op: dict, clase: str, datos: dict, terminal: int, por, llegada, hora_local) -> dict:
    """«todos» sobre una fila (ítem, cliente): alta con id de su rango (o del rango 0 en la carga inicial, C-3), cambio arbitrado por grupo
    con conjuntos, validación de la pantalla y códigos que no se repiten, y baja con la regla de historia. No confirma (lo hace aplicar_op)."""
    pisados: list = []
    iid = modulos._id_entero(ref)
    if iid is None or iid < 1:
        return _resultado(op, "rechazado", "no_valido")
    ref = str(iid)
    quien = por or f"terminal {terminal}"
    with sinc_diario.aplicando(terminal):
        conn = s.connection()
        actual = _contenido(s, eid, d, ref)
        linea = _linea(conn, d.tipo, ref)
        antes_id = linea["id"] if linea is not None else None
        estado, motivo = "aplicado", None
        if clase == "alta":
            fila = datos.get("fila")
            if not isinstance(fila, dict):
                return _resultado(op, "rechazado", "no_valido", canonico=actual)
            if linea is not None and linea["borrado"]:                 # nada con lápida revive (I7)
                _pisado(conn, d.tipo, ref, nombre=_nombre(fila), motivo="eliminado", perdio=fila, perdio_de=quien, quedo_de=WEB)
                return _resultado(op, "rechazado", "eliminado")
            if actual is not None:
                if huella(d, _campos_modelo(d, actual)) == huella(d, _campos_modelo(d, fila)):
                    return _resultado(op, "aplicado", canonico=actual)   # ya está igual (reenvío)
                return _resultado(op, "rechazado", "conflicto", canonico=actual)
            rango0 = iid // RANGO == 0
            if rango0:
                if d.tipo not in ("producto", "cliente"):
                    return _resultado(op, "rechazado", "no_valido")
                from . import sinc, sinc_completar                       # C-3: solo en la carga inicial de la única instalación
                motivo = sinc_completar.revisar_alta_rango0(s, eid, inst, sinc._leer(s, eid, sinc.CLAVE_VINC, {}), d.tipo, op["ref"])
                if motivo:
                    return {"n": op["n"], "estado": "rechazado", "motivo": motivo, "v": None, "ref": str(op["ref"]), "canonico": None, "pisados": []}
            elif not modulos.en_rango(iid, terminal):
                return _resultado(op, "rechazado", "no_valido")         # un programa crea filas solo con ids de su rango
            campos, error = _validar_fila(d, ctx, _campos_modelo(d, fila))
            if error is not None:
                _pisado(conn, d.tipo, ref, nombre=_nombre(fila), motivo="no_valido", perdio=fila, perdio_de=quien, quedo_de=WEB)
                return _resultado(op, "rechazado", "no_valido")
            if d.tipo == "producto":
                campos = _codigos_libres(s, eid, iid, campos, None, pisados, conn, terminal, por)
            obj = d.modelo(**campos)
            obj.id = iid
            obj.empresa_id = eid
            s.add(obj)
            s.flush()
            if rango0 and d.tipo == "producto":
                from . import sinc_completar
                sinc_completar.existencia_inicial(s, eid, obj, (op.get("datos") or {}).get("existencias"))
            if pisados:
                estado = "fusionado"
        elif clase == "baja":
            if actual is not None:
                _baja_de_fila(s, eid, d, s.get(d.modelo, iid))
        else:
            if actual is None:
                _pisado(conn, d.tipo, ref, motivo="eliminado", perdio=datos, perdio_de=quien, quedo_de=WEB,
                        nombre=_nombre(_cargar(linea["foto"]) if linea is not None else None))
                return _resultado(op, "rechazado", "eliminado")
            campos_web = (_cargar(linea["campos"], {}) or {}) if linea is not None else {}
            nuevo, _aplicados, unio = _arbitrar(conn, d, ref, actual, datos, campos_web, pisados, llegada, hora_local, terminal, por)
            if _normal(nuevo) != _normal(actual):
                campos, error = _validar_fila(d, ctx, _campos_modelo(d, nuevo))
                if error is not None:
                    _pisado(conn, d.tipo, ref, nombre=_nombre(actual), motivo="no_valido", perdio=datos, perdio_de=quien, quedo_de=WEB)
                    return _resultado(op, "rechazado", "no_valido", canonico=actual)
                if d.tipo == "producto":
                    campos = _codigos_libres(s, eid, iid, campos, actual, pisados, conn, terminal, por)
                obj = s.get(d.modelo, iid)
                for k, v in campos.items():
                    if getattr(obj, k, None) != v:
                        setattr(obj, k, v)
                s.add(obj)
                s.flush()
            cambio = _normal(_contenido(s, eid, d, ref)) != _normal(actual)
            if pisados and not cambio:
                estado, motivo = "rechazado", pisados[0]["motivo"]
            elif pisados or unio:
                estado = "fusionado"
        s.flush()
        _decidir(s)                                                    # la versión se escribe ya (origen = esta terminal)
        conn = s.connection()
        nueva = _linea(conn, d.tipo, ref)
        v = nueva["id"] if nueva is not None and nueva["id"] != antes_id else None
        canonico = _contenido(s, eid, d, ref)
    return _resultado(op, estado, motivo, v=v, ref=ref, canonico=canonico, pisados=pisados)


# ======================================================================================================================
# Acciones del núcleo (contrato §3.6)
# ======================================================================================================================
_ACCIONES_CARGA: dict = {}


def accion_de_carga(nombre: str, fn) -> None:
    """Registra una acción del núcleo: {"tipo": "_carga", "ref": "_", "accion": nombre}."""
    _ACCIONES_CARGA[str(nombre)] = fn


def _accion(tipo: str, accion: str):
    if tipo == "_carga":
        fn = _ACCIONES_CARGA.get(accion)
        if fn is None:
            try:
                from . import sinc_completar
                fn = getattr(sinc_completar, "ACCIONES_CARGA", {}).get(accion)
            except ImportError:
                fn = None
        return fn
    d = DATOS.get(tipo)
    if d is None or d.escribe != "web":
        return None
    f = d.acciones.get(accion)
    return _fn(f) if f is not None else None


# ======================================================================================================================
# Rutas (solo la web, contrato §2)
# ======================================================================================================================
router = APIRouter(prefix="/api/sinc", tags=["sinc"])
ULTIMA_LLAMADA: dict = {}                   # {(eid, terminal): (time.time(), estacion_viva)}: lo lee la regla de quién atiende
_ULTIMO_ANOTE: dict = {}                    # {(eid, terminal): time.time()} del último _anotar_instalacion
LIMITE_DATOS = (240, 300)                   # cubeta propia por instalación, en memoria (no está en auth.CLAVES_PERSISTENTES)
MAX_OPS, MAX_BYTES, MAX_FILAS, MAX_BYTES_FILAS = 100, 1_000_000, 500, 2_000_000
MAX_ACCION = 256_000
PLAN_VENCIDO_ACCION = "El plan de la empresa está vencido: los pedidos se atienden en la página web hasta renovarlo."
ESTADOS_ACTIVOS = ("nuevo", "confirmado", "en_preparacion", "listo")


def _dep_solo_nube() -> None:
    from . import sinc
    sinc._solo_nube()


def _dep_revocacion(authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)) -> None:
    from . import sinc
    sinc._revocacion_explicita(authorization, sc)


def encendido() -> bool:
    return os.environ.get("FE_SINC_DATOS", "1") != "0"


def _encendido() -> None:
    if not encendido():
        raise HTTPException(404, "Not Found")


def _cuerpo(codigo: str, mensaje: str) -> HTTPException:
    return HTTPException(400, {"codigo": codigo, "mensaje": mensaje})


def _instalacion(s, eid: int, ctx) -> dict:
    from . import sinc
    v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
    inst = sinc._instalacion_de(v, ctx)
    if not inst:
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    return inst


def _limitar(request: Request, ctx) -> None:
    limitar_ip(request, "sinc_datos", LIMITE_DATOS[0], LIMITE_DATOS[1], mensaje="Demasiadas llamadas seguidas desde esta computadora; espere unos minutos",
               sujeto=f"inst{ctx.token_api.id}")


LLAMADA_CADA = 20                           # (I-1) segundos entre escrituras de sinc_llamada (antes, si estacion_viva cambia)


def _llamada_conn(conn, terminal: int) -> Optional[tuple[float, bool]]:
    if not _hay_tabla(conn, "sinc_llamada"):
        return None
    f = conn.execute(_sql("SELECT hora, estacion_viva FROM sinc_llamada WHERE terminal = :t"), {"t": int(terminal)}).first()
    return (float(f[0] or 0), bool(f[1])) if f is not None else None


def contacto_guardado(eid: int, terminal: int) -> Optional[tuple[float, bool]]:
    """(I-1) (hora time.time() de la última llamada de esa computadora a /api/sinc/datos, si dijo estacion_viva), leído de la base de la
    EMPRESA: lo ven igual todos los procesos del servidor. None si nunca llamó. La base se escribe como mucho cada LLAMADA_CADA segundos
    (antes si estacion_viva cambia); si ESTE proceso atendió una llamada más reciente, se usa la de su memoria (ULTIMA_LLAMADA)."""
    from .db import engine_empresa
    try:
        with Session(engine_empresa(int(eid))) as x:
            guardada = _llamada_conn(x.connection(), int(terminal))
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos: no se pudo leer la última llamada (%s)", type(ex).__name__)
        guardada = None
    propia = ULTIMA_LLAMADA.get((int(eid), int(terminal)))
    if propia is not None and (guardada is None or propia[0] > guardada[0]):
        return propia
    return guardada


def _guardar_llamada(s, terminal: int, ahora: float, viva: bool) -> None:
    """Escribe la llamada en sinc_llamada si la guardada tiene LLAMADA_CADA segundos o más, o si estacion_viva cambió. Confirma."""
    try:
        conn = s.connection()
        previa = _llamada_conn(conn, terminal)
        if previa is not None and ahora - previa[0] < LLAMADA_CADA and previa[1] == viva:
            return
        conn.execute(_sql("INSERT OR REPLACE INTO sinc_llamada (terminal, hora, estacion_viva) VALUES (:t, :h, :v)"),
                     {"t": int(terminal), "h": float(ahora), "v": bool(viva)})
        s.commit()
    except Exception as ex:  # noqa: BLE001  nunca frena la llamada: la próxima vuelve a intentar
        s.rollback()
        log.warning("sinc_datos: no se pudo guardar la última llamada (%s)", type(ex).__name__)


def _contacto(s, eid: int, ctx, terminal: int, estacion_viva: bool) -> None:
    """La hora de la llamada y si la estación está viva: en sinc_llamada de la base de la empresa (I-1, para todos los procesos) y en
    memoria (caché de este proceso); y el último contacto en la ficha (como mucho cada 60 s)."""
    ahora = time.time()
    ULTIMA_LLAMADA[(eid, terminal)] = (ahora, bool(estacion_viva))
    _guardar_llamada(s, terminal, ahora, bool(estacion_viva))
    if ahora - _ULTIMO_ANOTE.get((eid, terminal), 0) >= 60:
        _ULTIMO_ANOTE[(eid, terminal)] = ahora
        try:
            from . import sinc
            sinc._anotar_instalacion(s, eid, ctx)
        except modulos.ConflictoRegistro:
            s.rollback()


def _validar_datos(cuerpo, request: Request) -> dict:
    try:
        largo = int(request.headers.get("content-length") or 0)
    except ValueError:
        largo = 0
    if largo > MAX_BYTES:
        raise _cuerpo("grande", "El envío es demasiado grande")
    try:                                    # n.º 37: también sin Content-Length (por trozos); la forma compacta nunca mide más que lo enviado
        medido = len(json.dumps(cuerpo, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8"))
    except (TypeError, ValueError):
        medido = 0
    if medido > MAX_BYTES:
        raise _cuerpo("grande", "El envío es demasiado grande")
    if not isinstance(cuerpo, dict):
        raise _cuerpo("cuerpo", "El envío no es válido")
    if cuerpo.get("protocolo") != 2:
        raise _cuerpo("protocolo", "Protocolo no reconocido")
    ent = lambda v: isinstance(v, int) and not isinstance(v, bool)   # noqa: E731
    if not isinstance(cuerpo.get("autora"), str) or not re.fullmatch(r"\d{1,7}\.[a-z0-9]{4,12}", cuerpo["autora"]):
        raise _cuerpo("cuerpo", "Falta la autora")
    if not ent(cuerpo.get("desde")) or cuerpo["desde"] < 0:
        raise _cuerpo("cuerpo", "Falta desde")
    if cuerpo.get("version") is not None and (not isinstance(cuerpo["version"], str) or len(cuerpo["version"]) > 20):
        raise _cuerpo("cuerpo", "Versión no válida")
    if not isinstance(cuerpo.get("hora_local"), str) or _fecha(cuerpo["hora_local"]) is None:
        raise _cuerpo("cuerpo", "Falta la hora local")
    if cuerpo.get("epoca_web") is not None and not isinstance(cuerpo["epoca_web"], str):
        raise _cuerpo("cuerpo", "Época no válida")
    if not isinstance(cuerpo.get("estacion_viva", False), bool):
        raise _cuerpo("cuerpo", "estacion_viva no válido")
    ops = cuerpo.get("ops", [])
    if not isinstance(ops, list):
        raise _cuerpo("cuerpo", "Las operaciones no son válidas")
    if len(ops) > MAX_OPS:
        raise _cuerpo("grande", f"Envíe hasta {MAX_OPS} operaciones por llamada")
    vistos = set()
    for o in ops:
        if not isinstance(o, dict) or not ent(o.get("n")) or o["n"] < 1 or o["n"] in vistos:
            raise _cuerpo("cuerpo", "Una operación no es válida")
        vistos.add(o["n"])
        if not isinstance(o.get("tipo"), str) or len(o["tipo"]) > 30 or not isinstance(o.get("ref"), str) or not o["ref"] or len(o["ref"]) > 60:
            raise _cuerpo("cuerpo", "Una operación no es válida")
        if o.get("op") not in ("alta", "cambio", "baja", "copia") or not ent(o.get("base_v", 0)) or not isinstance(o.get("datos", {}), dict):
            raise _cuerpo("cuerpo", "Una operación no es válida")
        if o.get("por") is not None and not isinstance(o["por"], str):
            raise _cuerpo("cuerpo", "Una operación no es válida")
    res = cuerpo.get("reservar")
    if res is not None and (not isinstance(res, dict) or set(res) - {"producto", "cliente"} or not all(ent(x) for x in res.values())):
        raise _cuerpo("cuerpo", "La reserva no es válida")
    return cuerpo


def _segundos() -> int:
    try:
        seg = int(os.environ.get("FE_DATOS_SEGUNDOS") or 5)
    except ValueError:
        seg = 5
    return max(1 if os.environ.get("FE_ENTORNO") == "qa" else 5, seg)


def _activo(conn, eid: int, terminal: int) -> bool:
    """Pedidos activos, tienda publicada o cuentas vivas de esa terminal: el programa llama más seguido."""
    if conn.execute(_sql("SELECT 1 FROM sinc_dato WHERE dueno = :t AND borrado = 0 LIMIT 1"), {"t": terminal}).first() is not None:
        return True
    if _hay_tabla(conn, "pedido") and conn.execute(_sql("SELECT 1 FROM pedido WHERE empresa_id = :e AND estado IN ('nuevo', 'confirmado', 'en_preparacion', 'listo') LIMIT 1"),
                                                   {"e": eid}).first() is not None:
        return True
    return _hay_tabla(conn, "negociopublico") and conn.execute(_sql("SELECT 1 FROM negociopublico WHERE empresa_id = :e AND activo = 1 LIMIT 1"),
                                                                 {"e": eid}).first() is not None


def _gancho_pedidos(nombre: str, *args, defecto=None):
    """Una función de app/pedidos.py (P3) que esta ruta llama; sin ella (o si falla), `defecto`."""
    try:
        from . import pedidos
        f = getattr(pedidos, nombre, None)
        return f(*args) if f is not None else defecto
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos: %s no se pudo completar (%s)", nombre, type(ex).__name__)
        return defecto


def _pedidos_programa(s, eid: int, terminal: int) -> bool:
    """`pedidos_programa` de la respuesta: lo decide pedidos.pedidos_programa_para (P3); sin ella, la columna atiende_terminal."""
    r = _gancho_pedidos("pedidos_programa_para", s, eid, terminal)
    if r is not None:
        return bool(r) and encendido()
    conn = s.connection()
    if not encendido() or os.environ.get("FE_PEDIDOS_PROGRAMA", "1") == "0" or not _hay_tabla(conn, "negociopublico"):
        return False
    if "atiende_terminal" not in {r[1] for r in conn.execute(_sql("PRAGMA table_info(negociopublico)")).all()}:
        return False
    f = conn.execute(_sql("SELECT atiende_terminal FROM negociopublico WHERE empresa_id = :e ORDER BY id LIMIT 1"), {"e": eid}).first()
    return f is not None and f[0] is not None and int(f[0]) == int(terminal)


def fila_goteo(s, eid: int, linea) -> Optional[dict]:
    """Una línea de sinc_dato como Fila del goteo (§2.2), con el contenido leído DESPUÉS de la línea. None si no se declara o no baja."""
    d = DATOS.get(linea["tipo"])
    if d is None or d.viaja not in ("dos", "baja"):
        return None
    borrado = bool(linea["borrado"])
    datos = None
    if not borrado:
        contenido = _contenido(s, eid, d, linea["ref"])
        if contenido is None or not _pasa(d, contenido):
            borrado = True
        else:
            datos = dict(contenido) if isinstance(contenido, dict) else contenido
            if d.modelo is not None and d.extra:
                obj = s.get(d.modelo, int(linea["ref"]))
                for k, f in d.extra.items():
                    try:
                        datos[k] = _fn(f)(s, eid, obj)
                    except Exception:  # noqa: BLE001
                        log.exception("sinc_datos: no se pudo calcular un campo extra")
                        datos[k] = None
    return {"tipo": d.tipo, "ref": linea["ref"], "v": int(linea["id"]), "dueno": linea["dueno"] if d.escribe == "dueno" else None,
            "borrado": borrado, "origen": int(linea["origen"] or 0), "campos": _cargar(linea["campos"], {}) or {}, "datos": None if borrado else datos}


def goteo(s, eid: int, desde: int) -> tuple[list, int, bool]:
    """(filas, cursor, mas): las líneas de sinc_dato con id > desde, en orden, hasta 500 o 2 MB. Primero la línea, después el contenido."""
    tipos = [t for t, d in DATOS.items() if d.viaja in ("dos", "baja")]
    if not tipos:
        return [], desde, False
    conn = s.connection()
    marcas = ", ".join(f":t{i}" for i in range(len(tipos)))
    lineas = conn.execute(_sql(f"SELECT id, tipo, ref, campos, origen, dueno, borrado FROM sinc_dato WHERE id > :d AND tipo IN ({marcas}) ORDER BY id LIMIT :l"),
                          {"d": int(desde), "l": MAX_FILAS + 1, **{f"t{i}": t for i, t in enumerate(tipos)}}).mappings().all()
    filas, cursor, peso, mas = [], int(desde), 0, len(lineas) > MAX_FILAS
    for linea in lineas[:MAX_FILAS]:
        f = fila_goteo(s, eid, linea)
        if f is not None:
            t = len(json.dumps(f, default=str))
            if filas and peso + t > MAX_BYTES_FILAS:
                mas = True
                break
            peso += t
            filas.append(f)
        cursor = int(linea["id"])
    return filas, cursor, mas


@router.post("/datos")
def datos_sinc(request: Request, _nube: None = Depends(_dep_solo_nube), _rev: None = Depends(_dep_revocacion), _enc: None = Depends(_encendido),
               cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """4.32: operaciones del programa y goteo de la web en una sola ida y vuelta (contrato §2.2). Solo para el token de una instalación de
    ESTA empresa; la terminal sale de su ficha, nunca del cuerpo. El cuerpo se valida a mano: un error nunca repite lo enviado."""
    eid = ctx.empresa.id
    inst = _instalacion(s, eid, ctx)
    terminal = int(inst.get("terminal") or 0)
    _limitar(request, ctx)
    c = _validar_datos(cuerpo, request)
    if int(c["autora"].split(".", 1)[0]) != terminal:
        raise HTTPException(403, {"codigo": "autora", "mensaje": "Esta computadora no puede mandar cambios con ese nombre"})
    llegada = datetime.now(timezone.utc)
    hora_local = _fecha(c["hora_local"])
    hecha = sembrada(eid, s) or sembrar(s, eid, terminal=terminal)       # al terminar de sembrar fija atiende_terminal (C-7 c, dentro de sembrar)
    if hecha and resiembra_encendida():
        resembrar(s, eid)                                               # §2.10: tras volver de la 4.31 (FE_SINC_RESEMBRAR=1), un tramo por llamada
    if c.get("ops") and ops_del_dia(s.connection(), terminal) + len(c["ops"]) > MAX_OPS_DIA:
        s.rollback()
        raise HTTPException(429, "Esta computadora mandó demasiados cambios hoy; quedan guardados en ella y se enviarán más tarde")
    _contacto(s, eid, ctx, terminal, c.get("estacion_viva", False))    # n.º 18: después del tope (un 429 no deja a la computadora «viva»)
    resultados = []
    ops = c.get("ops") or []
    for i, o in enumerate(ops):
        op = {**o, "autora": c["autora"]}
        try:
            res = aplicar_op(s, eid, ctx, inst, op, llegada, hora_local)
        except Exception as ex:  # noqa: BLE001  (I-2) pasajero: no se da por rechazada
            s.rollback()
            log.warning("sinc_datos: una operación no se pudo aplicar (%s)", type(ex).__name__)
            res = _resultado(op, REINTENTAR, "error")
        resultados.append(res)
        if res["estado"] == REINTENTAR:                                 # (I-2) ella y todas las siguientes: sin anotar, sin avanzar n_max
            resultados.extend(_resultado(x, REINTENTAR, res["motivo"]) for x in ops[i + 1:])
            break
    purgar_web(s, eid)                                                  # n.º 33: como mucho una vez por hora y empresa (en este proceso)
    _gancho_pedidos("reintentar_enlaces", s, eid, terminal)            # el enlace pedido↔comprobante que falló se repara solo (P3; confirma ella)
    reservado = None
    if c.get("reservar") is not None:
        try:
            from . import sinc, sinc_completar
            reservado = sinc_completar.reservar(s, eid, inst, sinc._leer(s, eid, sinc.CLAVE_VINC, {}), c["reservar"])   # None = error pasajero (n.º 25): no se manda «reservado»
        except Exception as ex:  # noqa: BLE001
            s.rollback(); reservado = None
            log.warning("sinc_datos: no se pudo reservar (%s)", type(ex).__name__)
    ep = epoca(s, eid)
    conn = s.connection()
    if hecha:
        filas, cursor, mas = goteo(s, eid, c["desde"])
    else:
        filas, cursor, mas = [], c["desde"], True
    n_max = int(conn.execute(_sql("SELECT COALESCE(MAX(n), 0) FROM sinc_cambio WHERE autora = :a"), {"a": c["autora"]}).scalar() or 0)
    seg = _segundos()
    salida = {"protocolo": 2, "hora": datetime.now(timezone.utc).isoformat(timespec="milliseconds"), "epoca": ep, "cursor": cursor, "mas": bool(mas),
              "sembrando": not hecha, "siguiente_en": seg if (not hecha or _activo(conn, eid, terminal)) else seg * 3, "n_max": n_max,
              "pedidos_programa": _pedidos_programa(s, eid, terminal), "resultados": resultados, "filas": filas}
    if reservado is not None:
        salida["reservado"] = reservado
    s.rollback()                                                        # solo lecturas desde el último commit
    return salida


def filas_de(s, eid: int, refs: list) -> list:
    """Las filas actuales (como en el goteo) de los datos pedidos que tienen línea en sinc_dato (para la respuesta de una acción)."""
    conn = s.connection()
    out = []
    for tipo, ref in refs:
        linea = conn.execute(_sql("SELECT id, tipo, ref, campos, origen, dueno, borrado FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": str(ref)}).mappings().first()
        if linea is not None:
            f = fila_goteo(s, eid, linea)
            if f is not None:
                out.append(f)
    return out


def _refs_de_contenido(d: Dato, contenido) -> list:
    """[(tipo, ref)] a los que apunta el contenido según `refs` («campo», «lista[].campo», «» = la ref misma)."""
    out = []
    if not isinstance(contenido, dict):
        return out
    for camino, tipo in (d.refs or {}).items():
        if not camino:
            continue
        if "[]." in camino:
            lista, _, campo = camino.partition("[].")
            v = contenido.get(lista)
            if isinstance(v, str):
                v = _cargar(v, [])
            for x in v if isinstance(v, list) else []:
                if isinstance(x, dict) and x.get(campo) is not None:
                    out.append((tipo, str(x.get(campo))))
        elif contenido.get(camino) is not None:
            out.append((tipo, str(contenido.get(camino))))
    return out


@router.post("/datos/accion")
def accion_sinc(request: Request, _nube: None = Depends(_dep_solo_nube), _rev: None = Depends(_dep_revocacion), _enc: None = Depends(_encendido),
                cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """4.32: una acción en vivo del programa (contrato §2.4): la web corre la MISMA función de su ruta. Sus 400, 404 y 409 salen tal cual."""
    eid = ctx.empresa.id
    inst = _instalacion(s, eid, ctx)
    terminal = int(inst.get("terminal") or 0)
    if not isinstance(cuerpo, dict):
        raise HTTPException(400, "El pedido no es válido")
    tipo, ref, accion, datos, por = cuerpo.get("tipo"), cuerpo.get("ref"), cuerpo.get("accion"), cuerpo.get("datos", {}), cuerpo.get("por")
    if not (isinstance(tipo, str) and isinstance(ref, str) and 0 < len(ref) <= 60 and isinstance(accion, str) and len(accion) <= 40
            and isinstance(datos, dict) and (por is None or isinstance(por, str))):
        raise HTTPException(400, "El pedido no es válido")
    if len(json.dumps(datos, default=str)) > MAX_ACCION:
        raise HTTPException(400, "El pedido es demasiado grande")
    _limitar(request, ctx)
    _contacto(s, eid, ctx, terminal, (contacto_guardado(eid, terminal) or (0, False))[1])   # la estación como la dijo /datos (cualquier proceso)
    fn = _accion(tipo, accion)
    if fn is None:
        raise HTTPException(400, "Esta acción no existe")
    if accion != "reenlazar" and _plan_vencido(ctx):
        raise HTTPException(409, PLAN_VENCIDO_ACCION)
    ctx.por_programa = _por(por)
    ctx.terminal_sinc = terminal                                        # 4.32: las acciones de pedidos leen aquí la terminal de la ficha
    resultado = fn(s, eid, ctx, ref, datos, ctx.por_programa)
    s.commit()                                                          # lo que la acción dejó (las funciones de las rutas ya confirman)
    try:
        from . import main as _m
        _m._auditar(ctx, "sinc_accion", f"Acción «{accion}» sobre {tipo} {ref} desde la computadora (terminal {terminal})")
    except Exception:  # noqa: BLE001
        log.exception("sinc_datos: no se pudo auditar una acción")
    filas = []
    if tipo != "_carga":
        d = DATOS[tipo]
        contenido = _contenido(s, eid, d, ref)
        filas = filas_de(s, eid, [(tipo, ref)] + _refs_de_contenido(d, contenido))
        s.rollback()
    return {"resultado": resultado, "filas": filas}


MAX_REFS = 500


@router.post("/datos/filas")
def filas_sinc(request: Request, _nube: None = Depends(_dep_solo_nube), _rev: None = Depends(_dep_revocacion), _enc: None = Depends(_encendido),
               cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """4.32 (contrato §2.3): el estado en la web de los datos pedidos: «existe» (con su contenido, como en el goteo), «borrado» (lápida) o
    «nunca». Más `max_dado` (solo lectura, C-2) y la época. Lo usan la carga inicial y la época nueva. Solo lectura."""
    eid = ctx.empresa.id
    inst = _instalacion(s, eid, ctx)
    _limitar(request, ctx)
    refs = cuerpo.get("refs") if isinstance(cuerpo, dict) else None
    if not isinstance(refs, list) or not 1 <= len(refs) <= MAX_REFS:
        raise _cuerpo("cuerpo", f"Pida de 1 a {MAX_REFS} datos")
    pedidos = []
    for x in refs:
        if not (isinstance(x, dict) and isinstance(x.get("tipo"), str) and x["tipo"] in DATOS and isinstance(x.get("ref"), str) and 0 < len(x["ref"]) <= 60):
            raise _cuerpo("cuerpo", "Un dato pedido no es válido")
        pedidos.append((x["tipo"], x["ref"]))
    for _tramo in range(100):                                          # termina de sembrar: la respuesta debe ver las lápidas
        if sembrada(eid, s) or sembrar(s, eid, terminal=int(inst.get("terminal") or 0)):
            break
    ep = epoca(s, eid)
    conn = s.connection()
    salida = []
    for tipo, ref in pedidos:
        d = DATOS[tipo]
        linea = conn.execute(_sql("SELECT id, tipo, ref, campos, origen, dueno, borrado, datos FROM sinc_dato WHERE tipo = :t AND ref = :r"),
                             {"t": tipo, "r": ref}).mappings().first()
        if d.viaja == "sube":                                           # la copia de lo ajeno vive en sinc_dato.datos
            vivo = linea is not None and not linea["borrado"]
            salida.append({"tipo": tipo, "ref": ref, "estado": "existe" if vivo else ("borrado" if linea is not None else "nunca"),
                           "v": int(linea["id"]) if linea is not None else None, "datos": _cargar(linea["datos"]) if vivo else None})
            continue
        f = fila_goteo(s, eid, linea) if linea is not None else None
        if f is not None:
            salida.append({"tipo": tipo, "ref": ref, "estado": "borrado" if f["borrado"] else "existe", "v": f["v"], "datos": f["datos"]})
            continue
        contenido = _contenido(s, eid, d, ref)                          # sin línea (no debería pasar en una empresa sembrada)
        if contenido is not None and _pasa(d, contenido):
            salida.append({"tipo": tipo, "ref": ref, "estado": "existe", "v": 0, "datos": contenido})
        else:
            salida.append({"tipo": tipo, "ref": ref, "estado": "nunca", "v": None, "datos": None})
    try:
        from . import sinc_completar
        max_dado = sinc_completar.max_dado(s, eid, inst)                # C-2: solo lectura
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos: no se pudo leer max_dado (%s)", type(ex).__name__)
        max_dado = {}
    s.rollback()
    return {"filas": salida, "max_dado": max_dado, "epoca": ep}
