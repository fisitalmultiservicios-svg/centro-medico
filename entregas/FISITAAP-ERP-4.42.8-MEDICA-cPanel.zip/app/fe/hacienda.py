"""Cliente de la API de recepción de comprobantes del Ministerio de Hacienda."""
import base64
import threading
import time
from dataclasses import dataclass

import httpx

from ..config import AMBIENTES, API_CABYS, API_CONTRIBUYENTE

# Tiempos explícitos: Hacienda se pone lento a fin de mes; sin esto un hilo de Passenger puede quedar colgado.
TIMEOUT = httpx.Timeout(connect=10, read=25, write=10, pool=5)

# Caché de tokens por (ambiente, usuario, contraseña) dentro del proceso: las acciones masivas no piden un token
# por cada comprobante al IdP (que puede bloquear la cuenta por exceso de inicios de sesión).
_TOKENS: dict[tuple[str, str, str], tuple[str, float]] = {}
_LOCK = threading.Lock()


class CredencialesInvalidas(RuntimeError):
    """Usuario o contraseña de API rechazados por el IdP de Hacienda."""


@dataclass
class Credenciales:
    ambiente: str          # "sandbox" | "produccion"
    usuario: str           # usuario de API (cpj-3-102-xxxxxx@stag... en pruebas, @prod... en producción)
    password: str


class ClienteHacienda:
    def __init__(self, cred: Credenciales, timeout: httpx.Timeout | float = TIMEOUT):
        if cred.ambiente not in AMBIENTES:
            raise RuntimeError(f"Ambiente de Hacienda desconocido: {cred.ambiente!r} (use sandbox o produccion)")
        self.cred = cred
        self.cfg = AMBIENTES[cred.ambiente]
        self.timeout = timeout

    # --- autenticación ---------------------------------------------------
    def token(self) -> str:
        k = (self.cred.ambiente, self.cred.usuario, self.cred.password)
        with _LOCK:
            hit = _TOKENS.get(k)
            if hit and time.time() < hit[1] - 30:
                return hit[0]
        with httpx.Client(timeout=self.timeout) as http:
            r = http.post(self.cfg["token"], data={
                "grant_type": "password",
                "client_id": self.cfg["client_id"],
                "username": self.cred.usuario,
                "password": self.cred.password,
            })
        if r.status_code in (400, 401):
            raise CredencialesInvalidas(
                f"Hacienda rechazó el usuario o la contraseña de API para el ambiente '{self.cred.ambiente}' "
                f"(HTTP {r.status_code}). Revise Configuración › Facturación electrónica: el usuario de pruebas termina en "
                f"@stag.comprobanteselectronicos.go.cr y el de producción en @prod.comprobanteselectronicos.go.cr")
        if r.status_code != 200:
            raise RuntimeError(f"Error de autenticación ({r.status_code}): {r.text[:300]}")
        data = r.json()
        tok = data["access_token"]
        with _LOCK:
            _TOKENS[k] = (tok, time.time() + int(data.get("expires_in", 300)))
        return tok

    def _headers(self):
        return {"Authorization": f"bearer {self.token()}", "Content-Type": "application/json"}

    # --- envío ------------------------------------------------------------
    def enviar(self, clave: str, fecha_emision: str, emisor: dict, receptor: dict | None,
               xml_firmado: bytes, consecutivo_receptor: str | None = None) -> dict:
        """POST /recepcion. Hacienda responde 202 si recibió el comprobante (no significa aceptado).
        Si la clave ya había sido recibida (reintento, doble clic) Hacienda responde 4xx; se reporta como `duplicado`
        y `ok=True` para que el documento no quede marcado como error."""
        payload = {
            "clave": clave,
            "fecha": fecha_emision,
            "emisor": {"tipoIdentificacion": emisor["tipo"], "numeroIdentificacion": emisor["numero"]},
            "comprobanteXml": base64.b64encode(xml_firmado).decode(),
        }
        if receptor:
            payload["receptor"] = {"tipoIdentificacion": receptor["tipo"], "numeroIdentificacion": receptor["numero"]}
        if consecutivo_receptor:
            payload["consecutivoReceptor"] = consecutivo_receptor
        with httpx.Client(timeout=self.timeout) as http:
            r = http.post(f"{self.cfg['api']}/recepcion", json=payload, headers=self._headers())
        causa = r.headers.get("X-Error-Cause") or ""
        texto = (causa or r.text[:500] or "").lower()
        duplicado = r.status_code in (400, 409) and any(x in texto for x in ("recibid", "ya existe", "ya fue", "duplic"))
        return {
            "status": r.status_code,
            "ok": r.status_code in (200, 201, 202) or duplicado,
            "duplicado": duplicado,
            "error": None if duplicado else (causa or (r.text[:500] if r.status_code >= 400 else None)),
            "location": r.headers.get("Location"),
        }

    # --- consulta ---------------------------------------------------------
    def consultar(self, clave: str) -> dict:
        """GET /recepcion/{clave} -> estado: recibido | procesando | aceptado | rechazado | error (de Hacienda),
        no_encontrado (404) o http_error (la consulta falló: no dice nada del comprobante)."""
        with httpx.Client(timeout=self.timeout) as http:
            r = http.get(f"{self.cfg['api']}/recepcion/{clave}", headers=self._headers())
        if r.status_code == 404:
            return {"estado": "no_encontrado", "status": 404}
        if r.status_code != 200:
            return {"estado": "http_error", "status": r.status_code,
                    "error": r.headers.get("X-Error-Cause") or r.text[:500]}
        data = r.json()
        respuesta_xml = base64.b64decode(data["respuesta-xml"]) if data.get("respuesta-xml") else None
        detalle = None
        if respuesta_xml:
            from lxml import etree
            try:
                root = etree.fromstring(respuesta_xml)
                detalle = root.findtext("{*}DetalleMensaje")
            except etree.XMLSyntaxError:
                pass
        return {
            "estado": data.get("ind-estado") or "desconocido",
            "status": 200,
            "fecha": data.get("fecha"),
            "respuesta_xml": respuesta_xml,
            "detalle": detalle,
        }


# --- APIs públicas (sin token) ------------------------------------------------
def consultar_contribuyente(identificacion: str) -> dict | None:
    try:
        r = httpx.get(API_CONTRIBUYENTE, params={"identificacion": identificacion}, timeout=15)
    except httpx.HTTPError as ex:
        raise RuntimeError(f"Hacienda no respondió la consulta de contribuyente ({type(ex).__name__}); intente en unos minutos")
    if r.status_code != 200:
        return None
    try:
        d = r.json()
    except ValueError:
        raise RuntimeError("Hacienda devolvió una respuesta que no se pudo leer; intente en unos minutos")
    actividades = [a for a in d.get("actividades", []) if a.get("estado") == "A"] or d.get("actividades", [])
    return {
        "nombre": d.get("nombre"),
        "tipo_identificacion": d.get("tipoIdentificacion"),
        "regimen": (d.get("regimen") or {}).get("descripcion"),
        "situacion": (d.get("situacion") or {}).get("estado"),
        "actividades": [{"codigo": a.get("codigo"), "descripcion": a.get("descripcion")} for a in actividades],
    }


def buscar_cabys(q: str, top: int = 20) -> list[dict]:
    try:
        r = httpx.get(API_CABYS, params={"q": q, "top": top}, timeout=15)
        if r.status_code != 200:
            return []
        return [{"codigo": c.get("codigo"), "descripcion": c.get("descripcion"), "impuesto": c.get("impuesto")}
                for c in r.json().get("cabys", [])]
    except (httpx.HTTPError, ValueError) as ex:
        raise RuntimeError(f"Hacienda no respondió la búsqueda CABYS ({type(ex).__name__}); intente en unos minutos")
