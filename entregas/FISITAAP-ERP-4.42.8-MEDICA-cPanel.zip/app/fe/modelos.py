"""Modelos de dominio (pydantic) del comprobante electrónico v4.4."""
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

TipoId = Literal["01", "02", "03", "04", "05", "06"]  # física, jurídica, DIMEX, NITE, extranjero, no contribuyente


class Identificacion(BaseModel):
    tipo: TipoId
    numero: str = Field(min_length=1, max_length=20)   # el XSD solo fija el máximo; los pasaportes pueden tener menos de 9 (R84)


class Ubicacion(BaseModel):
    provincia: int = Field(ge=1, le=7)
    canton: int = Field(ge=1, le=99)
    distrito: int = Field(ge=1, le=99)
    barrio: Optional[str] = None
    otras_senas: str = Field(min_length=5, max_length=250)


class Telefono(BaseModel):
    codigo_pais: int = 506
    numero: int


class Parte(BaseModel):
    """Emisor o Receptor."""
    nombre: str = Field(min_length=3, max_length=100)
    identificacion: Optional[Identificacion] = None    # solo el receptor del tiquete puede ir sin ella (3.33); el emisor siempre la lleva
    nombre_comercial: Optional[str] = None
    ubicacion: Optional[Ubicacion] = None
    telefono: Optional[Telefono] = None
    correo: Optional[str] = None
    actividad: Optional[str] = Field(default=None, min_length=6, max_length=6)
    registro_fiscal: Optional[str] = Field(default=None, max_length=12)   # Registrofiscal8707 (solo el emisor; bebidas alcohólicas)


# Catálogo CodigoDescuentoType v4.4: 01 regalía, 02 regalía IVA cobrado al cliente, 03 bonificación, 04 volumen, 05 temporada,
# 06 promocional, 07 comercial, 08 frecuencia, 09 sostenido, 99 otros. El descuento normal de una factura es el COMERCIAL (07):
# antes salía como 01 «Descuento por Regalía» (un obsequio) y sin NaturalezaDescuento, que Hacienda exige con todo descuento.
CODIGOS_DESCUENTO = {"01": "Descuento por regalía", "02": "Descuento por regalía IVA cobrado al cliente", "03": "Descuento por bonificación",
                     "04": "Descuento por volumen", "05": "Descuento por temporada", "06": "Descuento promocional", "07": "Descuento comercial",
                     "08": "Descuento por frecuencia", "09": "Descuento sostenido", "99": "Otros descuentos"}


class Descuento(BaseModel):
    monto: Decimal
    codigo: Literal["01", "02", "03", "04", "05", "06", "07", "08", "09", "99"] = "07"
    codigo_otro: Optional[str] = Field(default=None, min_length=5, max_length=100)   # obligatorio con 99
    naturaleza: Optional[str] = Field(default=None, min_length=3, max_length=80)     # si falta se usa el nombre del código


class Exoneracion(BaseModel):
    """Nodo Exoneracion del impuesto de una línea (ExoneracionType v4.4; notas 10.1 y 23). MontoExoneracion lo calcula calculo.py."""
    tipo: Literal["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "99"]   # TipoDocumentoEX1
    tipo_otro: Optional[str] = Field(default=None, min_length=5, max_length=100)            # TipoDocumentoOTRO (con 99)
    numero: str = Field(min_length=3, max_length=40)
    articulo: Optional[int] = Field(default=None, ge=0, le=999999)
    inciso: Optional[int] = Field(default=None, ge=0, le=999999)
    institucion: Literal["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "99"]   # NombreInstitucion
    institucion_otro: Optional[str] = Field(default=None, min_length=5, max_length=160)
    fecha_emision: str                       # xs:dateTime con zona
    tarifa: Decimal = Field(gt=0, le=Decimal("99.99"))     # TarifaExonerada: puntos de la tarifa (13 = todo el 13 %)

    @model_validator(mode="after")
    def _reglas(self):
        if self.tipo == "99" and not self.tipo_otro:
            raise ValueError("Con el tipo de exoneración 99 (Otros) describa el documento (5 a 100 caracteres)")
        if self.institucion == "99" and not self.institucion_otro:
            raise ValueError("Con la institución 99 (Otros) indique su nombre (5 a 160 caracteres)")
        if self.tipo in ("02", "03", "06", "07", "08") and self.articulo is None:
            raise ValueError(f"La exoneración tipo {self.tipo} requiere el artículo de la ley")
        self.tarifa = self.tarifa.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return self


# Nota 8 (códigos de impuesto). 07 (IVA cálculo especial), 08 (bienes usados) y 99 no se emiten desde este sistema (3.41).
CODIGOS_IMPUESTO = {
    "01": "Impuesto al valor agregado", "02": "Impuesto Selectivo de Consumo", "03": "Impuesto único a los combustibles",
    "04": "Impuesto específico de bebidas alcohólicas", "05": "Impuesto específico sobre bebidas envasadas sin contenido alcohólico y jabones de tocador",
    "06": "Impuesto a los productos de tabaco", "12": "Impuesto específico al cemento",
}
# Anexos 4.4, campo BaseImponible: Subtotal + Selectivo (02) + bebidas alcohólicas (04) + bebidas sin alcohol/jabones (05) + cemento (12)
EN_BASE_IVA = {"02", "04", "05", "12"}
ESPECIFICOS = {"03", "04", "05", "06"}                 # llevan DatosImpuestoEspecifico


class DatosImpuestoEspecifico(BaseModel):
    """DatosImpuestoEspecifico (Anexos 4.4, campos 10–14), por UNIDAD vendida del ítem:
    03: litros por unidad · 04 y 05: mililitros del envase · 06: unidades por paquete. impuesto_unidad: monto del impuesto por
    litro (03), por mililitro de alcohol absoluto (04), por volumen de referencia (05 bebidas) o por gramo (05 jabón), por unidad (06)."""
    cantidad_unidad: Decimal = Field(gt=0, lt=Decimal("100000"))          # CantidadUnidadMedida (7,2)
    porcentaje: Optional[Decimal] = Field(default=None, gt=0, le=Decimal("99.99"))   # 04: % de alcohol por volumen (4,2)
    volumen_unidad: Optional[Decimal] = Field(default=None, gt=0, lt=Decimal("100000"))   # 05: volumen de referencia o gramos (7,2)
    impuesto_unidad: Decimal = Field(ge=0, lt=Decimal("1e13"))            # ImpuestoUnidad (18,5)
    jabon: bool = False                                                   # 05: jabón de tocador (otra fórmula)


def otro_impuesto(d) -> "Optional[Impuesto]":
    """«Otro impuesto» guardado en el ítem o enviado en la línea (dict o JSON) → Impuesto. None o {} = sin otro impuesto.
    Formato: {"codigo": "02", "tarifa": 10} | {"codigo": "02", "monto_unidad": 250} | {"codigo": "04", "cantidad_unidad": 750,
    "porcentaje": 40, "impuesto_unidad": 5.12} | {"codigo": "05", "cantidad_unidad": 355, "volumen_unidad": 250, "impuesto_unidad": 20,
    "jabon": false} | {"codigo": "06" o "03", "cantidad_unidad": …, "impuesto_unidad": …} | {"codigo": "12"}."""
    import json as _json
    if d in (None, "", {}, "{}", "null"):
        return None
    if isinstance(d, str):
        d = _json.loads(d)
    if not isinstance(d, dict) or not d.get("codigo"):
        return None
    c = str(d["codigo"]).zfill(2)
    num = lambda k: None if d.get(k) in (None, "") else Decimal(str(d[k]))      # noqa: E731
    kw = {"codigo": c}
    if c == "02":
        if num("monto_unidad") is not None:
            kw["monto_unidad"] = num("monto_unidad")
        else:
            kw["tarifa"] = num("tarifa")
    elif c in ESPECIFICOS:
        if not num("cantidad_unidad") or num("cantidad_unidad") <= 0:
            raise ValueError({"03": "indique los litros por unidad", "04": "indique los mililitros del envase", "05": "indique los mililitros del envase o los gramos del jabón",
                              "06": "indique las unidades por paquete"}[c])
        if num("impuesto_unidad") is None or num("impuesto_unidad") < 0:
            raise ValueError("indique el impuesto por unidad que fija Hacienda")
        kw["especifico"] = DatosImpuestoEspecifico(cantidad_unidad=num("cantidad_unidad"), porcentaje=num("porcentaje"),
                                                   volumen_unidad=num("volumen_unidad"), impuesto_unidad=num("impuesto_unidad"), jabon=bool(d.get("jabon")))
    return Impuesto(**kw)


def otro_impuesto_dict(i: "Optional[Impuesto]") -> "Optional[dict]":
    """Impuesto → dict normalizado para guardar en el ítem (sin ceros de más)."""
    if i is None:
        return None
    f = lambda v: None if v is None else float(v)      # noqa: E731
    d = {"codigo": i.codigo}
    if i.codigo == "02":
        d.update({"monto_unidad": f(i.monto_unidad)} if i.monto_unidad is not None else {"tarifa": f(i.tarifa)})
    elif i.especifico is not None:
        e = i.especifico
        d.update({"cantidad_unidad": f(e.cantidad_unidad), "impuesto_unidad": f(e.impuesto_unidad)})
        if i.codigo == "04":
            d["porcentaje"] = f(e.porcentaje)
        if i.codigo == "05":
            d.update({"volumen_unidad": f(e.volumen_unidad), "jabon": bool(e.jabon)})
    return d


class Impuesto(BaseModel):
    codigo: str = "01"            # nota 8: 01 IVA, 02 Selectivo de Consumo, 03…06 específicos, 12 cemento
    codigo_tarifa: Optional[str] = "08"     # solo IVA: 08 = 13 % general, 10 = exento, 01 = 0 %
    tarifa: Optional[Decimal] = Decimal("13.00")    # IVA, Selectivo por porcentaje (editable) y cemento (5)
    monto_unidad: Optional[Decimal] = Field(default=None, ge=0, lt=Decimal("1e13"))   # 02 por monto: impuesto por unidad vendida
    especifico: Optional[DatosImpuestoEspecifico] = None
    exoneracion: Optional[Exoneracion] = None

    @model_validator(mode="after")
    def _reglas(self):
        c = self.codigo
        if c not in CODIGOS_IMPUESTO:
            raise ValueError(f"Código de impuesto {c!r} no admitido; válidos: {', '.join(CODIGOS_IMPUESTO)}")
        if c == "01":
            if not self.codigo_tarifa:
                raise ValueError("El IVA requiere el código de tarifa")
            if self.tarifa is None:
                raise ValueError("El IVA requiere la tarifa")
            return self
        self.codigo_tarifa = None                     # CodigoTarifaIVA es solo del IVA (01 y 07)
        if self.exoneracion is not None:
            raise ValueError(f"La exoneración en este sistema aplica solo al IVA, no al {CODIGOS_IMPUESTO[c].lower()}")
        if c == "02":
            # «tarifa» trae 13 por defecto (del IVA): solo cuenta si se indicó para el Selectivo
            con_tarifa = "tarifa" in self.model_fields_set and self.tarifa is not None and self.tarifa > 0
            if con_tarifa == (self.monto_unidad is not None):
                raise ValueError("El Impuesto Selectivo de Consumo se indica como porcentaje o como monto por unidad (uno de los dos)")
            if self.monto_unidad is not None:
                self.tarifa = None
            elif self.tarifa > Decimal("99.99"):
                raise ValueError("La tarifa del Selectivo de Consumo no puede pasar de 99,99 %")
        elif c == "12":
            self.tarifa, self.monto_unidad = Decimal("5.00"), None          # Anexos: «la tarifa será del 5%»
        else:
            self.tarifa, self.monto_unidad = None, None
            e = self.especifico
            if e is None:
                raise ValueError(f"El {CODIGOS_IMPUESTO[c].lower()} requiere los datos del impuesto específico")
            if c == "04" and e.porcentaje is None:
                raise ValueError("El impuesto de bebidas alcohólicas requiere el porcentaje de alcohol por volumen")
            if c == "05" and e.volumen_unidad is None:
                raise ValueError("El impuesto de bebidas sin alcohol o jabones requiere el volumen por unidad de consumo")
        if c not in ESPECIFICOS:
            self.especifico = None
        return self


class Linea(BaseModel):
    cabys: str = Field(default="", max_length=13)     # 3.93: vacío solo en comprobantes internos (sin facturación electrónica); main.py lo exige con FE

    @field_validator("cabys")
    @classmethod
    def _cabys_13(cls, v):
        v = (v or "").strip()
        if v and len(v) != 13:
            raise ValueError("El código CABYS debe tener 13 dígitos")
        return v

    detalle: str = Field(min_length=3, max_length=200)
    cantidad: Decimal = Decimal(1)
    unidad_medida: str = "Unid"   # "Sp" para servicios profesionales, "Unid" para mercancías
    precio_unitario: Decimal
    es_servicio: bool = False
    codigo_comercial: Optional[str] = Field(default=None, max_length=20)
    partida_arancelaria: Optional[str] = Field(default=None, min_length=12, max_length=12)   # solo factura de exportación (R86)
    descuentos: list[Descuento] = []
    impuestos: list[Impuesto] = [Impuesto()]


# Códigos de referencia del XSD v4.4 (CodigoReferenciaType). OJO: "03 Corrige monto" de la v4.3 ya no existe.
CODIGOS_REFERENCIA = {
    "01": "Anula documento de referencia", "02": "Corrige texto del documento de referencia", "04": "Referencia a otro documento",
    "05": "Sustituye comprobante provisional por contingencia", "06": "Devolución de mercancía", "07": "Sustituye comprobante electrónico",
    "08": "Factura endosada", "09": "Nota de crédito financiera", "10": "Nota de débito financiera", "11": "Proveedor no domiciliado",
    "12": "Crédito por exoneración posterior a la facturación",
    # Revisión del 22/04/2026 (obligatoria desde el 1/11/2026)
    "13": "Anula documento de referencia por error material", "14": "Corrige monto por error material",
    "15": "Sustituye comprobante electrónico por error material", "16": "Sustituye comprobante electrónico rechazado",
    "17": "Pago a comprobante electrónico (solo REP)", "99": "Otros",
}
TIPOS_DOC_REFERENCIA = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "99"}


class Referencia(BaseModel):
    tipo_doc: str = "01"                  # documento referenciado (01 FE, 02 ND, 03 NC, 04 TE, ... 99 otros)
    tipo_doc_otro: Optional[str] = None   # obligatorio (5-100) cuando tipo_doc == "99"  -> TipoDocRefOTRO
    numero: str                           # clave del documento referenciado
    fecha_emision: str                    # ISO 8601 con zona horaria
    codigo: str = "01"                    # ver CODIGOS_REFERENCIA
    codigo_otro: Optional[str] = None     # obligatorio (5-100) cuando codigo == "99"    -> CodigoReferenciaOTRO
    razon: str = Field(min_length=3, max_length=180)

    @model_validator(mode="after")
    def _reglas_v44(self):
        if self.codigo not in CODIGOS_REFERENCIA:
            raise ValueError(f"Código de referencia {self.codigo!r} no existe en v4.4; válidos: {', '.join(CODIGOS_REFERENCIA)}")
        if self.tipo_doc not in TIPOS_DOC_REFERENCIA:
            raise ValueError(f"Tipo de documento de referencia {self.tipo_doc!r} no existe en v4.4")
        otro = (self.codigo_otro or "").strip()
        if self.codigo == "99" and not 5 <= len(otro) <= 100:
            raise ValueError("Con el código de referencia 99 (Otros) hay que describir el código de referencia (5 a 100 caracteres)")
        t_otro = (self.tipo_doc_otro or "").strip()
        if self.tipo_doc == "99" and not 5 <= len(t_otro) <= 100:
            raise ValueError("Con el tipo de documento de referencia 99 (Otros) hay que describir el tipo de documento (5 a 100 caracteres)")
        return self


# Otros cargos (nodo OtrosCargos del XSD v4.4): 01 contribución parafiscal, 02 timbre Cruz Roja, 03 timbre Bomberos, 04 cobro de un
# tercero, 05 costos de exportación, 06 impuesto de servicio 10 % (restaurantes), 07 timbre de colegios profesionales, 08 depósitos de
# garantía, 09 multas o penalizaciones, 10 intereses moratorios, 99 otros (requiere `tipo_otro`). No llevan IVA y se suman al total.
TIPOS_OTRO_CARGO = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "99"}


class OtroCargo(BaseModel):
    tipo: str = "06"
    tipo_otro: Optional[str] = Field(default=None, min_length=5, max_length=100)   # obligatorio con el tipo 99
    detalle: str = Field(min_length=1, max_length=160)
    porcentaje: Optional[Decimal] = Field(default=None, ge=0, le=Decimal("9999.99999"))   # informativo (PorcentajeOC: 0..9 dígitos, 5 decimales)
    monto: Decimal = Field(gt=0, lt=Decimal("10000000000000"))                     # DecimalDineroType: 13 enteros + 5 decimales

    @model_validator(mode="after")
    def _reglas(self):
        if self.tipo not in TIPOS_OTRO_CARGO:
            raise ValueError(f"Tipo de otro cargo {self.tipo!r} no existe en v4.4")
        if self.tipo == "99" and not (self.tipo_otro or "").strip():
            raise ValueError("Con el tipo de otro cargo 99 (Otros) describa el cargo (5 a 100 caracteres)")
        if not self.monto.is_finite() or (self.porcentaje is not None and not self.porcentaje.is_finite()):
            raise ValueError("El monto y el porcentaje del cargo deben ser números finitos")
        # el XML escribe 5 decimales: el monto se fija así para que TotalOtrosCargos sea la suma exacta de los MontoCargo
        self.monto = self.monto.quantize(Decimal("0.00001"), rounding=ROUND_HALF_UP)
        if self.monto <= 0:
            raise ValueError("El monto del cargo debe ser mayor que cero")
        if self.porcentaje is not None:
            self.porcentaje = self.porcentaje.quantize(Decimal("0.00001"), rounding=ROUND_HALF_UP)
        return self


class MedioPago(BaseModel):
    tipo: str = "01"              # 01 efectivo, 02 tarjeta, 03 cheque, 04 transferencia, 06 SINPE móvil, 99 otros (requiere `otros`)
    total: Optional[Decimal] = None
    otros: Optional[str] = Field(default=None, min_length=3, max_length=100)   # descripción obligatoria con el tipo 99


class Comprobante(BaseModel):
    tipo_documento: Literal["01", "02", "03", "04", "08", "09"]   # 08 factura de compra, 09 exportación
    clave: str = Field(min_length=50, max_length=50)
    consecutivo: str = Field(min_length=20, max_length=20)
    fecha_emision: str            # ISO 8601 con zona, p.ej. 2026-10-08T10:00:00-06:00
    proveedor_sistemas: str = Field(max_length=20)
    emisor: Parte
    receptor: Optional[Parte] = None
    condicion_venta: str = "01"   # 01 contado, 02 crédito ...
    plazo_credito: Optional[int] = None
    condicion_venta_otros: Optional[str] = Field(default=None, min_length=5, max_length=100)   # obligatoria con la condición 99
    moneda: str = "CRC"
    tipo_cambio: Decimal = Decimal("1.00")
    lineas: list[Linea] = Field(min_length=1)
    medios_pago: list[MedioPago] = [MedioPago()]
    otros_cargos: list[OtroCargo] = Field(default_factory=list, max_length=15)
    referencias: list[Referencia] = []
    otro_texto: Optional[str] = None
