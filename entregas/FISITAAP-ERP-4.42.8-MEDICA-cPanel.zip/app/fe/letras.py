"""Monto en letras en español (p. ej. 'Cinco mil seiscientos setenta y cinco con cuarenta y un centavos')."""
from decimal import Decimal

_UNIDADES = ["", "un", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce",
             "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve", "veinte", "veintiún",
             "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"]
_DECENAS = ["", "", "", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"]
_CENTENAS = ["", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos",
             "ochocientos", "novecientos"]


def _menor_mil(n: int) -> str:
    if n == 0:
        return ""
    if n == 100:
        return "cien"
    c, r = divmod(n, 100)
    partes = []
    if c:
        partes.append(_CENTENAS[c])
    if r < 30:
        if r:
            partes.append(_UNIDADES[r])
    else:
        d, u = divmod(r, 10)
        partes.append(_DECENAS[d] + (f" y {_UNIDADES[u]}" if u else ""))
    return " ".join(partes)


def _entero(n: int) -> str:
    if n == 0:
        return "cero"
    partes = []
    millones, resto = divmod(n, 1_000_000)
    miles, unidades = divmod(resto, 1000)
    if millones:
        partes.append("un millón" if millones == 1 else f"{_entero(millones)} millones")
    if miles:
        partes.append("mil" if miles == 1 else f"{_menor_mil(miles)} mil")
    if unidades:
        partes.append(_menor_mil(unidades))
    return " ".join(partes)


def monto_en_letras(valor, moneda: str = "") -> str:
    v = Decimal(str(valor)).quantize(Decimal("0.01"))
    entero = int(v)
    centavos = int((v - entero) * 100)
    texto = _entero(entero)
    if not moneda and texto.endswith("veintiún"):        # solo la última palabra cambia (antes también "un mil" → "uno mil") (R252)
        texto = texto[:-len("veintiún")] + "veintiuno"
    elif not moneda and texto.endswith("un"):
        texto = texto[:-2] + "uno"
    cent = f" con {_entero(centavos)} centavos" if centavos else " exactos"
    if centavos == 1:
        cent = " con un centavo"
    resultado = f"{texto}{cent}"
    if moneda:
        nombre = {"CRC": "colones", "USD": "dólares", "EUR": "euros"}.get(moneda, moneda)
        resultado = f"{texto} {nombre}{cent}"
    return resultado[0].upper() + resultado[1:]
