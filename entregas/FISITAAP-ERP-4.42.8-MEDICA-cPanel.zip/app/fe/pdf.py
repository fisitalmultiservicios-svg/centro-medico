"""Representación impresa de documentos (PDF carta) con campos configurables por tipo de documento.

Dos entradas:
- `generar_pdf(xml_bytes, respuesta_xml, meta)`  → comprobantes electrónicos (FE, TE, NC, ND) a partir del XML.
- `generar_pdf_documento(datos)`                 → cotizaciones, remisiones, órdenes de compra, recibos (JSON).
Ambas construyen un `dict` normalizado y lo renderizan con `render(datos, cfg)`.
El diseño replica los formatos de referencia (logo arriba a la izquierda, título y número a la derecha,
bloque de cliente, tabla de ítems, monto en letras, tratamiento de impuestos + totales, términos, QR y leyenda).
"""
import io
import threading
from decimal import Decimal
from pathlib import Path

from lxml import etree

from ..config import DATA_DIR
from .letras import monto_en_letras

from xml.sax.saxutils import escape as _xml_escape


def _esc(v) -> str:
    """Texto libre (nombres, detalles, notas) seguro para Paragraph de reportlab, que interpreta etiquetas."""
    return _xml_escape(str(v if v is not None else ""))

TITULOS_XML = {
    "FacturaElectronica": ("factura", "Factura de venta electrónica"),
    "TiqueteElectronico": ("tiquete", "Tiquete electrónico"),
    "NotaCreditoElectronica": ("nota_credito", "Nota de crédito electrónica"),
    "NotaDebitoElectronica": ("nota_debito", "Nota de débito electrónica"),
    "FacturaElectronicaCompra": ("factura", "Factura electrónica de compra"),
    "FacturaElectronicaExportacion": ("factura", "Factura electrónica de exportación"),
    "ReciboElectronicoPago": ("recibo_pago", "Recibo electrónico de pago"),
}
# 3.61: comprobantes internos (empresa sin facturación electrónica): mismo XML interno, pero el PDF no dice «electrónica»,
# no lleva clave, QR ni la leyenda de Hacienda
TITULOS_INTERNOS = {"factura": "Comprobante de venta", "tiquete": "Comprobante de venta", "nota_credito": "Nota de crédito",
                    "nota_debito": "Nota de débito", "recibo_pago": "Recibo de pago"}


def _interno(d: dict) -> dict:
    d["titulo"] = TITULOS_INTERNOS.get(d.get("tipo"), "Comprobante")
    d["clave"] = None
    d["estado"] = None
    d["interno"] = True
    return d
TIPO_ID = {"01": "Cédula física", "02": "Cédula jurídica", "03": "DIMEX", "04": "NITE", "05": "Extranjero", "06": "No contribuyente"}
CONDICION_VENTA = {"01": "Contado", "02": "Crédito", "03": "Consignación", "04": "Apartado", "05": "Arrendamiento con opción de compra",
                   "06": "Arrendamiento en función financiera", "07": "Cobro a favor de un tercero", "08": "Servicios prestados al Estado",
                   "09": "Pago de servicios prestados al Estado", "10": "Venta a crédito hasta 90 días",
                   "11": "Pago de venta a crédito en IVA hasta 90 días", "12": "Venta mercancía no nacionalizada",
                   "13": "Venta bienes usados no contribuyente", "14": "Arrendamiento operativo", "15": "Arrendamiento financiero", "99": "Otros"}
MEDIO_PAGO = {"01": "Efectivo", "02": "Tarjeta", "03": "Cheque", "04": "Transferencia – depósito bancario", "05": "Recaudado por terceros",
              "06": "SINPE Móvil", "07": "Plataforma digital", "99": "Otros"}
# 3.41: nombres cortos del Selectivo de Consumo y los impuestos específicos en los totales
OTROS_IMP = {"02": "Selectivo de consumo", "03": "Imp. combustibles", "04": "Imp. bebidas alcohólicas", "05": "Imp. bebidas y jabones",
             "06": "Imp. tabaco", "12": "Imp. cemento"}

UNIDADES = {"Sp": "Servicios profesionales", "St": "Servicios técnicos", "Unid": "Unidad", "h": "Hora", "Kg": "Kilogramo", "L": "Litro",
            "m": "Metro", "d": "Día", "Os": "Otros servicios", "Otros": "Otros"}
# Helvetica no incluye "₡"; "¢" es la notación aceptada en Costa Rica.
SIMBOLO = {"CRC": "¢", "USD": "$", "EUR": "€"}
LEYENDA = ("Autorizada mediante resolución MH-DGT-RES-0027-2024 del 13 de noviembre del 2024 "
           "(Alcance N°186 a La Gaceta N°217 del 19/11/2024)")

# 3.87: reportlab y qrcode se importan la primera vez que se dibuja un PDF o un tiquete (_reportlab): eran ~0,25 s de cada arranque del
# servidor. Hasta entonces estos nombres valen None; _reportlab() los define todos de una vez (con cerrojo, por los hilos).
qrcode = colors = TA_RIGHT = A4 = letter = ParagraphStyle = mm = rl_canvas = None
Image = Paragraph = SimpleDocTemplate = Spacer = Table = TableStyle = _Canvas = None
VERDE = GRIS = GRIS_CLARO = LINEA = None
_rl_listo = False
_rl_cerrojo = threading.Lock()


def _reportlab():
    global _rl_listo
    if _rl_listo:
        return
    with _rl_cerrojo:
        if _rl_listo:
            return
        import qrcode as _qrcode
        from reportlab.lib import colors as _colors
        from reportlab.lib.enums import TA_RIGHT as _ta_right
        from reportlab.lib.pagesizes import A4 as _a4, letter as _letter
        from reportlab.lib.styles import ParagraphStyle as _ps
        from reportlab.lib.units import mm as _mm
        from reportlab.pdfgen import canvas as _rl_canvas
        from reportlab.platypus import Image as _im, Paragraph as _pa, SimpleDocTemplate as _sd, Spacer as _sp, Table as _ta, TableStyle as _ts
        globals().update(qrcode=_qrcode, colors=_colors, TA_RIGHT=_ta_right, A4=_a4, letter=_letter, ParagraphStyle=_ps, mm=_mm, rl_canvas=_rl_canvas,
                         Image=_im, Paragraph=_pa, SimpleDocTemplate=_sd, Spacer=_sp, Table=_ta, TableStyle=_ts,
                         _Canvas=type("_Canvas", (_CanvasPaginas, _rl_canvas.Canvas), {}),
                         VERDE=_colors.HexColor("#0f766e"), GRIS=_colors.HexColor("#555555"), GRIS_CLARO=_colors.HexColor("#f3f4f6"), LINEA=_colors.HexColor("#e5e7eb"))
        _rl_listo = True


# ----------------------------------------------------------------------------- utilidades
def _d(v) -> Decimal:
    try:
        return Decimal(str(v or "0"))
    except Exception:
        return Decimal(0)


def fmt(v, moneda="CRC", con_codigo=True) -> str:
    """1234.5 -> 'USD $1.234,50' (formato de los documentos de referencia)."""
    n = _d(v)
    if not n.is_finite():                 # NaN/inf no revientan un PDF: se imprimen como cero
        n = Decimal(0)
    n = n.quantize(Decimal("0.01"))
    s = f"{n:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    sim = SIMBOLO.get(moneda, "")
    return f"{moneda} {sim}{s}" if con_codigo else f"{sim}{s}"


def _fecha(iso: str, hora=False) -> str:
    if not iso:
        return ""
    f = iso[:10].split("-")
    if len(f) != 3:
        return iso
    txt = f"{f[2]}/{f[1]}/{f[0]}"
    return f"{txt} {iso[11:19]}" if hora and len(iso) >= 19 else txt


def _t(el, path, default=""):
    v = el.findtext(path) if el is not None else None
    return v if v is not None else default


# ----------------------------------------------------------------------------- datos desde XML
def datos_desde_xml(xml_bytes: bytes, respuesta_xml: bytes | None = None, meta: dict | None = None) -> dict:
    root = etree.fromstring(xml_bytes)
    tag = etree.QName(root).localname
    tipo, titulo = TITULOS_XML.get(tag, ("factura", tag))
    meta = meta or {}

    def parte(nombre):
        p = root.find(f"{{*}}{nombre}")
        if p is None:
            return None
        ub, tel = p.find("{*}Ubicacion"), p.find("{*}Telefono")
        def _i(tag):
            v = _t(ub, "{*}" + tag) if ub is not None else ""
            return int(v) if v and v.isdigit() else None
        from ..ubicaciones import nombre as _nombre_ubic
        def _i(tag):
            v = _t(ub, "{*}" + tag) if ub is not None else ""
            return int(v) if v and v.isdigit() else None
        from ..ubicaciones import nombre as _nombre_ubic
        return {
            "nombre": _t(p, "{*}Nombre"), "nombre_comercial": _t(p, "{*}NombreComercial"),
            "tipo_id": _t(p, "{*}Identificacion/{*}Tipo"), "cedula": _t(p, "{*}Identificacion/{*}Numero"),
            "direccion": ", ".join(x for x in [_nombre_ubic(_i("Provincia"), _i("Canton"), _i("Distrito")), _t(ub, "{*}Barrio"), _t(ub, "{*}OtrasSenas")] if x) if ub is not None else "",
            "telefono": f"+{_t(tel, '{*}CodigoPais')} {_t(tel, '{*}NumTelefono')}" if tel is not None else "",
            "correo": _t(p, "{*}CorreoElectronico"), "actividad": "", "sitio_web": "",
        }

    emisor, cliente = parte("Emisor"), parte("Receptor")
    emisor["actividad"] = _t(root, "{*}CodigoActividadEmisor")
    if cliente:
        cliente["actividad"] = _t(root, "{*}CodigoActividadReceptor")
    for k in ("sitio_web", "logo", "actividad_desc", "telefono"):
        if meta.get("emisor_" + k) and tag != "FacturaElectronicaCompra":    # en la FEC el emisor es el proveedor (R101)
            emisor[k] = meta["emisor_" + k]

    lineas, tot = [], {"grav_serv": 0, "grav_merc": 0, "ex_serv": 0, "ex_merc": 0, "iva_serv": 0, "iva_merc": 0, "exo_serv": 0, "exo_merc": 0, "iva_exonerado": 0}
    exoneraciones: list[dict] = []
    for ld in root.findall("{*}DetalleServicio/{*}LineaDetalle"):
        desc = sum((_d(_t(d, "{*}MontoDescuento")) for d in ld.findall("{*}Descuento")), Decimal(0))
        imp = ld.find("{*}Impuesto")
        unidad = _t(ld, "{*}UnidadMedida")
        es_serv = unidad in ("Sp", "St", "Os", "h", "d", "Spe", "Al", "Alc", "Cm", "I")
        imp_neto = _d(_t(ld, "{*}ImpuestoNeto"))
        # 3.41: el IVA (código 01) aparte del Selectivo de Consumo y los específicos
        otros_l = sum((_d(_t(ie, "{*}Monto")) for ie in ld.findall("{*}Impuesto") if _t(ie, "{*}Codigo") != "01"), Decimal(0))
        iva = imp_neto - otros_l
        sub = _d(_t(ld, "{*}SubTotal"))
        exo_l = None
        for ie in ld.findall("{*}Impuesto"):
            ex = ie.find("{*}Exoneracion")
            if ex is None:
                continue
            exo_l = {"numero": _t(ex, "{*}NumeroDocumento"), "tipo": _t(ex, "{*}TipoDocumentoEX1"), "tarifa": _d(_t(ex, "{*}TarifaExonerada") or "0"),
                     "monto": _d(_t(ex, "{*}MontoExoneracion") or "0"), "institucion": _t(ex, "{*}NombreInstitucion"),
                     "institucion_otro": _t(ex, "{*}NombreInstitucionOtros"), "fecha": _t(ex, "{*}FechaEmisionEX"),
                     "articulo": _t(ex, "{*}Articulo"), "inciso": _t(ex, "{*}Inciso")}
            tot["iva_exonerado"] += exo_l["monto"]
            if not any(x["numero"] == exo_l["numero"] for x in exoneraciones):
                exoneraciones.append(exo_l)
        lineas.append({
            "detalle": _t(ld, "{*}Detalle"), "descripcion": "", "cabys": _t(ld, "{*}CodigoCABYS"),
            "cantidad": _d(_t(ld, "{*}Cantidad") or "1"), "unidad": UNIDADES.get(unidad, unidad),
            "precio": _d(_t(ld, "{*}PrecioUnitario") or _t(ld, "{*}MontoTotal")), "descuento": desc, "descuento_pct": None,
            "tarifa": _d(_t(imp, "{*}Tarifa")) if imp is not None else Decimal(0), "impuesto": imp_neto, "total": sub,
            "exoneracion": exo_l,
        })
        k = "serv" if es_serv else "merc"
        tot[("grav_" if (iva or exo_l) else "ex_") + k] += sub
        tot["iva_" + k] += iva
    res = root.find("{*}ResumenFactura")
    moneda = _t(res, "{*}CodigoTipoMoneda/{*}CodigoMoneda", "CRC")
    total = _d(_t(res, "{*}TotalComprobante"))
    refs = [{"tipo": _t(r, "{*}TipoDocIR"), "numero": _t(r, "{*}Numero"), "fecha": _t(r, "{*}FechaEmisionIR"), "razon": _t(r, "{*}Razon"),
             "codigo": _t(r, "{*}Codigo"), "codigo_otro": _t(r, "{*}CodigoReferenciaOTRO")}
            for r in root.findall("{*}InformacionReferencia")]
    cond = _t(root, "{*}CondicionVenta")
    otros_cargos = [{"detalle": _t(oc, "{*}Detalle"), "tipo": _t(oc, "{*}TipoDocumentoOC"), "porcentaje": _t(oc, "{*}PorcentajeOC"), "monto": _d(_t(oc, "{*}MontoCargo") or "0")}
                    for oc in root.findall("{*}OtrosCargos")]
    # R102: los totales por clasificación son los del ResumenFactura (los mismos que recibe Hacienda), no una deducción por unidad
    if res is not None:
        for k, tag_r in (("grav_serv", "TotalServGravados"), ("grav_merc", "TotalMercanciasGravadas"), ("ex_serv", "TotalServExentos"), ("ex_merc", "TotalMercanciasExentas"),
                         ("exo_serv", "TotalServExonerado"), ("exo_merc", "TotalMercExonerada")):
            v = _t(res, "{*}" + tag_r)
            if v:
                tot[k] = _d(v)
    iva_por_tarifa: dict = {}
    otros_impuestos: dict = {}                     # 3.41: {código: monto} del Selectivo y los específicos
    for di in (res.findall("{*}TotalDesgloseImpuesto") if res is not None else []):
        cod = _t(di, "{*}Codigo") or "01"
        if cod != "01":
            otros_impuestos[cod] = otros_impuestos.get(cod, Decimal(0)) + _d(_t(di, "{*}TotalMontoImpuesto"))
            continue
        iva_por_tarifa[_t(di, "{*}CodigoTarifaIVA")] = iva_por_tarifa.get(_t(di, "{*}CodigoTarifaIVA"), Decimal(0)) + _d(_t(di, "{*}TotalMontoImpuesto"))
    total_otros_imp = sum(otros_impuestos.values(), Decimal(0))
    return {
        "tipo": tipo, "titulo": titulo, "numero": _t(root, "{*}NumeroConsecutivo"), "clave": _t(root, "{*}Clave"),
        "fecha_creacion": _t(root, "{*}FechaEmision"), "fecha_emision": _t(root, "{*}FechaEmision"),
        "fecha_vencimiento": meta.get("fecha_vencimiento") or "", "condicion": CONDICION_VENTA.get(cond, cond),
        "plazo": _t(root, "{*}PlazoCredito"), "vendedor": meta.get("vendedor") or "", "moneda": moneda,
        "tipo_cambio": _d(_t(res, "{*}CodigoTipoMoneda/{*}TipoCambio", "1")),
        "saldo": max(_d("0"), total - _d(meta.get("pagado", 0))),
        "medio_pago": ", ".join(MEDIO_PAGO.get(_t(m, "{*}TipoMedioPago"), "") for m in res.findall("{*}MedioPago")) if res is not None else "",
        "emisor": emisor, "cliente": cliente, "lineas": lineas,
        "totales": {
            "subtotal": _d(_t(res, "{*}TotalVenta")), "descuento": _d(_t(res, "{*}TotalDescuentos")),
            "subtotal_neto": _d(_t(res, "{*}TotalVentaNeta")), "impuesto": _d(_t(res, "{*}TotalImpuesto")) - total_otros_imp, "total": total,
            "otros_impuestos": [(OTROS_IMP.get(k, "Impuesto " + k), v) for k, v in sorted(otros_impuestos.items())],
            "otros_cargos": _d(_t(res, "{*}TotalOtrosCargos") or "0"),
            "tarifa": max([l["tarifa"] for l in lineas] or [Decimal(13)]), "iva_por_tarifa": iva_por_tarifa, **{k: Decimal(v) for k, v in tot.items()},
        },
        "otros_cargos": otros_cargos, "exoneraciones": exoneraciones,
        "referencias": refs, "notas": _t(root, "{*}Otros/{*}OtroTexto") or meta.get("notas") or "",
        "terminos": meta.get("terminos"), "estado": estado_respuesta(respuesta_xml),
    }


INSTITUCIONES_EXO = {"01": "Ministerio de Hacienda", "02": "Ministerio de Relaciones Exteriores y Culto", "03": "Ministerio de Agricultura y Ganadería",
                     "04": "MEIC", "05": "Cruz Roja Costarricense", "06": "Cuerpo de Bomberos", "07": "Obras del Espíritu Santo", "08": "Fecrunapa",
                     "09": "EARTH", "10": "INCAE", "11": "Junta de Protección Social", "12": "Aresep"}


def texto_exoneracion(xo: dict) -> str:
    inst = xo.get("institucion_otro") or INSTITUCIONES_EXO.get(xo.get("institucion") or "", "")
    fecha = _fecha(xo.get("fecha")) if xo.get("fecha") else ""
    art = f", artículo {xo['articulo']}" + (f" inciso {xo['inciso']}" if xo.get("inciso") else "") if xo.get("articulo") else ""
    return (f"Venta exonerada: documento {xo.get('numero')} (tipo {xo.get('tipo')}{art})" + (f", emitido por {inst}" if inst else "")
            + (f" el {fecha}" if fecha else "") + f"; tarifa exonerada {xo.get('tarifa', 0):g}%.")


def estado_respuesta(respuesta_xml: bytes | None) -> str:
    if not respuesta_xml:
        return ""
    try:
        m = etree.fromstring(respuesta_xml).findtext("{*}Mensaje")
        return {"1": "Aceptado por Hacienda", "3": "Rechazado por Hacienda"}.get(m, "")
    except etree.XMLSyntaxError:
        return ""


# ----------------------------------------------------------------------------- datos desde JSON (cotización, etc.)
def datos_desde_json(p: dict) -> dict:
    """Normaliza el documento enviado por la interfaz (cotizaciones, remisiones, órdenes, recibos)."""
    moneda = p.get("moneda") or "CRC"
    lineas, sub, desc_total, iva_total = [], Decimal(0), Decimal(0), Decimal(0)
    tot = {"grav_serv": Decimal(0), "grav_merc": Decimal(0), "ex_serv": Decimal(0), "ex_merc": Decimal(0), "iva_serv": Decimal(0), "iva_merc": Decimal(0),
           "exo_serv": Decimal(0), "exo_merc": Decimal(0), "iva_exonerado": Decimal(0)}
    # exoneración del cliente en cotizaciones y remisiones (v1.30): {numero, tipo, institucion, institucion_otro, fecha, tarifa, articulo, inciso}
    xo = p.get("exoneracion") if isinstance(p.get("exoneracion"), dict) else None
    exoneraciones = []
    if xo and str(xo.get("numero") or "").strip():
        exoneraciones.append({"numero": str(xo.get("numero"))[:40], "tipo": str(xo.get("tipo") or "")[:2], "institucion": str(xo.get("institucion") or "")[:2],
                              "institucion_otro": str(xo.get("institucion_otro") or "")[:160], "fecha": str(xo.get("fecha") or "")[:25],
                              "tarifa": max(Decimal(0), min(_d(xo.get("tarifa", 0)), Decimal(13))),
                              "articulo": str(xo.get("articulo") or "")[:6], "inciso": str(xo.get("inciso") or "")[:6]})
    for l in p.get("lineas", []):
        cant, precio, desc = _d(l.get("cantidad", 1)), _d(l.get("precio_unitario", l.get("precio", 0))), _d(l.get("descuento", 0))
        bruto = cant * precio
        neto = bruto - desc
        tarifa = _d(l.get("tarifa", 13))
        te = max(Decimal(0), min(_d(l.get("tarifa_exonerada", 0) or 0), tarifa)) if exoneraciones else Decimal(0)
        iva = neto * (tarifa - te) / 100
        exo_l = None
        if te > 0:
            exo_l = {"numero": exoneraciones[0]["numero"], "tarifa": te, "monto": neto * te / 100}
            tot["iva_exonerado"] += exo_l["monto"]
        es_serv = bool(l.get("es_servicio")) or (l.get("unidad_medida") in ("Sp", "St", "h"))
        lineas.append({"detalle": l.get("detalle") or l.get("nombre") or "", "descripcion": l.get("descripcion") or "", "referencia": l.get("referencia") or "",
                       "cabys": l.get("cabys") or "", "cantidad": cant, "unidad": UNIDADES.get(l.get("unidad_medida"), l.get("unidad_medida") or "Unidad"),
                       "precio": precio, "descuento": desc, "descuento_pct": (desc / bruto * 100) if bruto and desc else None,
                       "tarifa": tarifa, "impuesto": iva, "total": neto, "imagen": l.get("imagen"), "imagen_path": l.get("imagen_path"), "exoneracion": exo_l})
        sub += bruto; desc_total += desc; iva_total += iva
        k = "serv" if es_serv else "merc"
        if exo_l:                              # parte exonerada (proporción tarifa exonerada / tarifa) y el resto gravado
            parte = neto * te / tarifa
            tot["exo_" + k] += parte
            tot["grav_" + k] += neto - parte
        else:
            tot[("grav_" if iva else "ex_") + k] += neto
        tot["iva_" + k] += iva
    total = sub - desc_total + iva_total
    cli = p.get("cliente") or {}
    emi = p.get("emisor") or {}
    return {
        "tipo": p.get("tipo", "cotizacion"), "titulo": p.get("titulo") or "", "numero": str(p.get("numero") or ""), "clave": str(p.get("clave") or ""),
        "fecha_creacion": p.get("fecha") or p.get("fecha_creacion") or "", "fecha_emision": p.get("fecha_emision") or (p.get("fecha") if p.get("clave") else "") or "",
        "fecha_vencimiento": p.get("vence") or p.get("fecha_vencimiento") or "", "condicion": p.get("condicion") or "",
        "plazo": "", "vendedor": p.get("vendedor") or "", "moneda": moneda, "tipo_cambio": _d(p.get("tipo_cambio", 1)),
        "saldo": total, "medio_pago": p.get("medio_pago") or "",
        "emisor": {"nombre": emi.get("nombre", ""), "nombre_comercial": emi.get("nombre_comercial", ""), "tipo_id": emi.get("tipo_id", "02"),
                   "cedula": emi.get("cedula", ""), "direccion": emi.get("direccion", ""), "telefono": emi.get("telefono", ""),
                   "correo": emi.get("correo", ""), "sitio_web": emi.get("sitio_web", ""), "actividad": emi.get("actividad", ""),
                   "actividad_desc": emi.get("actividad_desc", ""), "logo": emi.get("logo")},
        "cliente": {"nombre": cli.get("nombre", ""), "tipo_id": cli.get("tipo_id", "01"), "cedula": cli.get("cedula") or cli.get("numero_id", ""),
                    "actividad": cli.get("actividad", ""), "telefono": cli.get("telefono", ""), "direccion": cli.get("direccion", ""),
                    "correo": cli.get("correo", "")} if cli else None,
        "lineas": lineas,
        "otros_cargos": [], "exoneraciones": exoneraciones if tot["iva_exonerado"] > 0 else [],
        "totales": {"subtotal": sub, "descuento": desc_total, "subtotal_neto": sub - desc_total, "impuesto": iva_total, "total": total, "otros_cargos": Decimal(0),
                    "tarifa": max([l["tarifa"] for l in lineas] or [Decimal(13)]), **tot},
        "referencias": [], "notas": p.get("notas") or "", "terminos": p.get("terminos"), "estado": str(p.get("estado") or ""),
    }


def _imagen_linea(l: dict):
    """Miniatura del producto para la columna Imagen; en blanco si no tiene."""
    import base64
    _reportlab()
    fuente = None
    if l.get("imagen_path") and Path(l["imagen_path"]).exists():
        fuente = str(l["imagen_path"])
    elif isinstance(l.get("imagen"), str) and l["imagen"].startswith("data:image"):
        try:
            fuente = io.BytesIO(base64.b64decode(l["imagen"].split(",", 1)[1]))
        except Exception:
            fuente = None
    if not fuente:
        return ""
    try:
        img = Image(fuente)
        ratio = img.imageWidth / float(img.imageHeight)
        lado = 14 * mm
        img.drawWidth, img.drawHeight = (lado, lado / ratio) if ratio >= 1 else (lado * ratio, lado)
        return img
    except Exception:
        return ""


# ----------------------------------------------------------------------------- render
class _CanvasPaginas:
    """Canvas que conoce el total de páginas para imprimir 'Página X de Y' y el pie fijo (3.87: _reportlab() arma _Canvas con esta
    clase y el Canvas de reportlab)."""

    def __init__(self, *a, pie=None, **kw):
        super().__init__(*a, **kw)
        self._saved = []
        self._pie = pie

    def showPage(self):
        self._saved.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved)
        for st in self._saved:
            self.__dict__.update(st)
            if self._pie:
                self._pie(self, self._pageNumber, total)
            super().showPage()
        super().save()


def render(d: dict, cfg: dict, logo_path: Path | None = None) -> bytes:
    _reportlab()
    campos = set(cfg.get("campos", []))
    on = lambda k: k in campos  # noqa: E731
    mon = d["moneda"]
    titulo = d["titulo"] or cfg.get("titulo") or ""
    e, c, t = d["emisor"], d["cliente"], d["totales"]

    electronico = d["tipo"] in ("factura", "tiquete", "nota_credito", "nota_debito", "recibo_pago")
    # estilo de la empresa (Configuración › Plantillas de impresión): color, tamaño de letra, papel, firma y texto al pie
    est = cfg.get("estilo") or {}
    try:
        acento = colors.HexColor(est.get("color") or "#0f766e")
    except ValueError:
        acento = VERDE
    tam = float(est.get("tamano") or 9.5)
    pagina = A4 if est.get("papel") == "a4" else letter
    base = ParagraphStyle("b", fontName="Helvetica", fontSize=tam, leading=tam + 3, textColor=colors.HexColor("#1d2433"))
    small = ParagraphStyle("s", parent=base, fontSize=8, leading=10, textColor=GRIS)
    tiny = ParagraphStyle("t", parent=base, fontSize=6.5, leading=8, textColor=GRIS)
    bold = ParagraphStyle("bb", parent=base, fontName="Helvetica-Bold")
    right = ParagraphStyle("r", parent=base, alignment=TA_RIGHT)
    right_small = ParagraphStyle("rs", parent=small, alignment=TA_RIGHT)
    h_titulo = ParagraphStyle("h", parent=base, fontName="Helvetica-Bold", fontSize=12, leading=15, alignment=TA_RIGHT, textColor=acento)
    h_num = ParagraphStyle("hn", parent=h_titulo, fontSize=16, leading=19)
    h_emp = ParagraphStyle("he", parent=base, fontName="Helvetica-Bold", fontSize=14, leading=17, textColor=acento)

    def L(label, valor, style=base):
        return Paragraph(f"<b>{label}:</b> {_esc(valor)}", style) if valor else None

    def bloque(items):
        return [i for i in items if i is not None]

    flow = []
    MARGEN = 9 * mm                                  # los formatos de referencia usan casi todo el ancho de la hoja
    ancho = pagina[0] - 2 * MARGEN

    # --- Encabezado. Electrónicos: logo + datos de contacto (izq) | título, número, clave, fechas (der).
    #     Cotización/remisión/orden/recibo (formato de referencia): logo (izq) | identificación y contacto (der);
    #     el título, el número y las fechas van en la fila del cliente.
    logo = None
    if on("logo") and logo_path and Path(logo_path).exists():
        try:
            logo = Image(str(logo_path))
            ratio = logo.imageWidth / float(logo.imageHeight)
            logo.drawHeight = 22 * mm
            logo.drawWidth = min(22 * mm * ratio, 75 * mm)
            logo.hAlign = "LEFT"
        except Exception:
            logo = None
    contacto = bloque([
        Paragraph(_esc(e["direccion"]), base) if on("emisor_direccion") and e.get("direccion") else None,
        Paragraph(_esc("      ".join(x for x in [e["correo"] if on("emisor_correo") else "", e.get("sitio_web", "") if on("emisor_sitio_web") else ""] if x)), base)
        if (on("emisor_correo") and e.get("correo")) or (on("emisor_sitio_web") and e.get("sitio_web")) else None,
        Paragraph(_esc(e["telefono"]), base) if on("emisor_telefono") and e.get("telefono") else None,
        L("Actividad Económica", " - ".join(x for x in [e.get("actividad", ""), e.get("actividad_desc", "")] if x)) if on("emisor_actividad") and e.get("actividad") else None,
    ])
    titulo_bloque = bloque([
        Paragraph(_esc(titulo), h_titulo) if on("titulo") else None,
        Paragraph(_esc(d["numero"]) if electronico else f"No. {_esc(d['numero'])}", h_num) if on("numero") and d["numero"] else None,
        Paragraph(f"<b>Clave</b> <font size=6.5>{_esc(d['clave'])}</font>", right_small) if on("clave") and d["clave"] else None,
        Spacer(1, 2 * mm) if electronico else None,
        L("Fecha de creación", _fecha(d["fecha_creacion"]), right) if on("fecha_creacion") else None,
        L("Fecha de emisión", _fecha(d["fecha_emision"], hora=True), right) if on("fecha_emision") and d["fecha_emision"] else None,
        L("Fecha de vencimiento", _fecha(d["fecha_vencimiento"]), right) if on("fecha_vencimiento") and d["fecha_vencimiento"] else None,
    ])
    if electronico:
        izq = ([logo, Spacer(1, 2 * mm)] if logo else [])
        if on("emisor_nombre"):
            izq.append(Paragraph(_esc(e.get("nombre_comercial") or e["nombre"]), h_emp))
            if e.get("nombre_comercial") and e.get("nombre") and e["nombre_comercial"].strip().lower() != e["nombre"].strip().lower():
                izq.append(Paragraph(_esc(e["nombre"]), base))          # nombre legal debajo de la marca (3.45)
        if on("emisor_cedula"):
            izq.append(Paragraph(f"{TIPO_ID.get(e.get('tipo_id'), 'Identificación')}  {_esc(e['cedula'])}", base))
        izq += contacto
        der = titulo_bloque
    else:
        izq = [logo] if logo else ([Paragraph(_esc(e.get("nombre_comercial") or e["nombre"]), h_emp)] if on("emisor_nombre") else [])
        der = bloque([Paragraph(_esc(e["nombre"]), right) if on("emisor_cedula") and e.get("nombre_comercial") and e.get("nombre") and e["nombre_comercial"].strip().lower() != e["nombre"].strip().lower() else None,
                      Paragraph(f"Identificación  {_esc(e['cedula'])}", right) if on("emisor_cedula") else None] +
                     [Paragraph(_esc(e["correo"]), right) if on("emisor_correo") and e.get("correo") else None,
                      Paragraph(_esc(e["telefono"]), right) if on("emisor_telefono") and e.get("telefono") else None,
                      Paragraph(_esc(e.get("sitio_web", "")), right) if on("emisor_sitio_web") and e.get("sitio_web") else None,
                      Paragraph(_esc(e["direccion"]), right) if on("emisor_direccion") and e.get("direccion") else None])
    head = Table([[izq, der]], colWidths=[ancho * 0.55, ancho * 0.45])
    estilo_head = [("VALIGN", (0, 0), (-1, -1), "TOP" if electronico else "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0 if electronico else 4),
                   ("RIGHTPADDING", (0, 0), (-1, -1), 0 if electronico else 4)]
    if not electronico:   # banda gris de fondo como en la cotización de referencia
        estilo_head += [("BACKGROUND", (0, 0), (-1, -1), GRIS_CLARO), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]
    head.setStyle(TableStyle(estilo_head))
    flow += [head, Spacer(1, 4 * mm)]

    # --- Cliente (izq) | condición, vendedor, moneda, saldo (der)  [no electrónicos: título, número y fechas a la derecha]
    cli_izq = []
    if c:
        nombre = L("Señor(es)" if electronico else "Cliente", c["nombre"]) if on("cliente_nombre") else None
        cedula = L(TIPO_ID.get(c.get("tipo_id"), "Identificación") if electronico else TIPO_ID.get(c.get("tipo_id"), "Identificación").upper(),
                   c["cedula"]) if on("cliente_cedula") and c.get("cedula") else None
        actividad = L("Actividad económica", c.get("actividad", "")) if on("cliente_actividad") and c.get("actividad") else None
        telefono = L("Teléfono", c.get("telefono", "")) if on("cliente_telefono") and c.get("telefono") else None
        direccion = L("Dirección", c.get("direccion", "")) if on("cliente_direccion") and c.get("direccion") else None
        correo = L("Email", c.get("correo", "")) if on("cliente_correo") and c.get("correo") else None
        # Comprobantes: cédula bajo el nombre (formato de referencia); cotización: la cédula al final en mayúsculas
        cli_izq = bloque([nombre, cedula, actividad, telefono, direccion, correo] if electronico else [nombre, telefono, direccion, correo, cedula])
    cli_der = bloque([
        L("Condición", d["condicion"] + (f" ({d['plazo']} días)" if d.get("plazo") else ""), right) if on("condicion") and d["condicion"] else None,
        L("Vendedor", d["vendedor"], right) if on("vendedor") and d["vendedor"] else None,
        L("Moneda", mon, right) if on("moneda") else None,
        L("Valor restante por pagar", fmt(d["saldo"], mon), right) if on("saldo_pendiente") else None,
    ])
    if not electronico:
        cli_der = titulo_bloque + cli_der
    if cli_izq or cli_der:
        tc = Table([[cli_izq, cli_der]], colWidths=[ancho * 0.6, ancho * 0.4])
        tc.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEABOVE", (0, 0), (-1, 0), 0.6, LINEA) if electronico else ("TOPPADDING", (0, 0), (-1, -1), 2),
                                ("TOPPADDING", (0, 0), (-1, -1), 6), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        flow += [tc, Spacer(1, 3 * mm)]

    for ref in d.get("referencias", []):
        from .modelos import CODIGOS_REFERENCIA
        cod = ref.get("codigo") or ""
        desc = ref.get("codigo_otro") or CODIGOS_REFERENCIA.get(cod, "")
        tipo_ref = f" · {cod} {desc}" if cod else ""
        flow.append(Paragraph(f"<b>Documento de referencia:</b> {_esc(ref['numero'])} del {_fecha(ref['fecha'])}{_esc(tipo_ref)} — {_esc(ref['razon'])}", small))

    # --- Tabla de ítems
    if electronico:   # Producto/Servicio | Cantidad | Precio Unitario | Unidad | Descuento | Impuestos | Total línea
        cols = [("Producto/Servicio", None, 0), ("Cantidad", "cant", 19 * mm), ("Precio Unitario", "precio", 29 * mm)]
        if on("col_unidad"):
            cols.append(("Unidad", "unidad", 22 * mm))
        if on("col_descuento"):
            cols.append(("Descuento", "desc", 23 * mm))
        if on("col_impuesto"):
            cols.append(("Impuestos", "imp", 27 * mm))
        cols.append(("Total línea", "total", 29 * mm))
    else:             # Concepto | Precio | Unidad | Cantidad | Descuento | Impuesto | Subtotal (cotización de referencia)
        cols = [("Concepto", None, 0), ("Precio", "precio", 27 * mm)]
        if on("col_unidad"):
            cols.append(("Unidad", "unidad", 22 * mm))
        cols.append(("Cantidad", "cant", 19 * mm))
        if on("col_descuento"):
            cols.append(("Descuento", "desc", 21 * mm))
        if on("col_impuesto"):
            cols.append(("Impuesto", "imp", 25 * mm))
        cols.append(("Subtotal", "total", 29 * mm))
    # La columna Imagen solo ocupa espacio si alguna línea trae miniatura (evita apretar la columna Concepto).
    if on("col_imagen") and any(l.get("imagen_path") or (isinstance(l.get("imagen"), str) and l["imagen"].startswith("data:image")) for l in d["lineas"]):
        cols.insert(0, ("Imagen", "img", 18 * mm))
    fijo = sum(w for _, k, w in cols if k)
    widths = [w if k else ancho - fijo for _, k, w in cols]
    rows = [[Paragraph(f"<b>{n}</b>", small) for n, _, _ in cols]]
    for l in d["lineas"]:
        concepto = [Paragraph(f"<b>{_esc(l['detalle'])}</b>", base)]
        if l.get("referencia"):
            concepto.append(Paragraph(f"Ref. {_esc(str(l['referencia']))}", tiny))
        if l.get("descripcion"):
            concepto.append(Paragraph(_esc(l["descripcion"]), small))
        if on("col_cabys") and l.get("cabys"):
            concepto.append(Paragraph(f"CAByS: {l['cabys']}", tiny))
        if l.get("exoneracion"):
            xo = l["exoneracion"]
            concepto.append(Paragraph(_esc(f"Exonerado {xo['tarifa']:g}% · IVA exonerado {fmt(xo['monto'], mon)} · Doc. {xo['numero']}"), tiny))
        celda = {"img": "", "cant": f"{l['cantidad']:.3f}".rstrip("0").rstrip("."), "precio": fmt(l["precio"], mon),
                 "unidad": l["unidad"], "desc": (f"{l['descuento_pct']:.2f}%" if l.get("descuento_pct") is not None else (fmt(l["descuento"], mon) if l["descuento"] else "")),
                 "imp": fmt(l["impuesto"], mon) if l["impuesto"] else "", "total": fmt(l["total"], mon)}
        fila = []
        for _, k, _ in cols:
            if not k:
                fila.append(concepto)
            elif k == "img":
                fila.append(_imagen_linea(l))
            else:
                fila.append(Paragraph(_esc(celda[k]), ParagraphStyle("c", parent=small, alignment=TA_RIGHT if k in ("cant", "precio", "desc", "imp", "total") else 0, textColor=colors.HexColor("#1d2433"))))
        rows.append(fila)
    tbl = Table(rows, colWidths=widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), GRIS_CLARO), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, -1), (-1, -1), 0.6, LINEA), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow += [tbl, Spacer(1, 3 * mm)]

    if on("medio_pago") and d.get("medio_pago"):
        flow += [Paragraph(f"<b>Medio de pago:</b> {_esc(d['medio_pago'])}", base), Spacer(1, 2 * mm)]
    if on("monto_letras"):
        letras = Table([[Paragraph(_esc(monto_en_letras(t["total"], mon)), base)]], colWidths=[ancho])   # con la moneda (R252)
        letras.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), GRIS_CLARO), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
        flow += [letras, Spacer(1, 3 * mm)]

    # --- Tratamiento de impuestos (izq) + totales (der)
    filas_tot = [("Subtotal", t["subtotal"])]
    if t["descuento"]:
        filas_tot += [("Descuento", t["descuento"]), ("Subtotal", t["subtotal_neto"])]
    if t.get("iva_exonerado"):
        filas_tot.append(("IVA exonerado (no se cobra)", t["iva_exonerado"]))
    filas_tot.append((f"Iva ({t['tarifa']:.2f}%)", t["impuesto"]))
    for nombre_oi, monto_oi in t.get("otros_impuestos") or []:   # Selectivo de Consumo e impuestos específicos (3.41)
        filas_tot.append((nombre_oi, monto_oi))
    for oc in d.get("otros_cargos") or []:                       # impuesto de servicio, timbres… (sin IVA, suman al total)
        filas_tot.append(((oc.get("detalle") or "Otros cargos")[:28], oc.get("monto") or Decimal(0)))
    filas_tot.append(("Total a pagar" if d["tipo"] in ("factura", "tiquete") else "Total", t["total"]))
    tc = d.get("tipo_cambio") or Decimal(1)
    if electronico and mon != "CRC" and tc and tc != 1:            # el comprobante en dólares muestra su tipo de cambio (R253)
        flow += [Paragraph(f"<b>Tipo de cambio:</b> {_esc(fmt(tc, 'CRC'))} por {_esc(mon)}", small), Spacer(1, 1.5 * mm)]
    # Cotizaciones y similares en dos monedas: la del documento y su equivalente (USD↔CRC) al tipo de cambio indicado
    dual = (not electronico) and mon in ("USD", "CRC") and tc and tc != 1
    if dual:
        otra = "CRC" if mon == "USD" else "USD"
        conv = (lambda v: v * tc) if mon == "USD" else (lambda v: v / tc)
        totales = [["", mon, otra]] + [[n, fmt(v, mon), fmt(conv(v), otra)] for n, v in filas_tot]
        tt = Table(totales, colWidths=[30 * mm, 38 * mm, 38 * mm], hAlign="RIGHT")
        tt.setStyle(TableStyle([("ALIGN", (1, 0), (-1, -1), "RIGHT"), ("FONTSIZE", (0, 0), (-1, -2), 9), ("TEXTCOLOR", (0, 0), (-1, -2), GRIS),
                                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINEA),
                                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("FONTSIZE", (0, -1), (-1, -1), 12),
                                ("LINEABOVE", (0, -1), (-1, -1), 0.8, LINEA), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    else:
        totales = [[n, fmt(v, mon)] for n, v in filas_tot]
        tt = Table(totales, colWidths=[40 * mm, 45 * mm], hAlign="RIGHT")
        tt.setStyle(TableStyle([("ALIGN", (1, 0), (1, -1), "RIGHT"), ("FONTSIZE", (0, 0), (-1, -2), 9), ("TEXTCOLOR", (0, 0), (-1, -2), GRIS),
                                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("FONTSIZE", (0, -1), (-1, -1), 13),
                                ("LINEABOVE", (0, -1), (-1, -1), 0.8, LINEA), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    if on("tratamiento_impuestos") and electronico:
        hay_exento = bool(t["ex_merc"] + t["ex_serv"])         # la columna Exento solo aparece cuando hay montos exentos
        hay_exo = bool(t.get("exo_merc", 0) + t.get("exo_serv", 0))   # y la columna Exonerado cuando hay exoneración
        cab = ([Paragraph("<b>Tratamiento de impuestos</b>", base), Paragraph("Gravado", small)] + ([Paragraph("Exento", small)] if hay_exento else [])
               + ([Paragraph("Exonerado", small)] if hay_exo else []) + [Paragraph(f"IVA {t['tarifa']:.2f}%", small)])

        def fila_tr(nombre, grav, ex, iva, exo=0):
            f = ([nombre, fmt(grav, mon) if grav else ""] + ([fmt(ex, mon) if ex else ""] if hay_exento else [])
                 + ([fmt(exo, mon) if exo else ""] if hay_exo else []) + [fmt(iva, mon) if iva else ""])
            return f
        tr = [cab, fila_tr("Mercancías", t["grav_merc"], t["ex_merc"], t["iva_merc"], t.get("exo_merc", 0)),
              fila_tr("Servicios", t["grav_serv"], t["ex_serv"], t["iva_serv"], t.get("exo_serv", 0)),
              fila_tr("Total", t["grav_merc"] + t["grav_serv"], t["ex_merc"] + t["ex_serv"], t["iva_merc"] + t["iva_serv"], t.get("exo_merc", 0) + t.get("exo_serv", 0))]
        anchos_tr = ([30 * mm if hay_exo else 34 * mm, 25 * mm if hay_exo else 28 * mm] + ([22 * mm] if hay_exento else [])
                     + ([24 * mm] if hay_exo else []) + [24 * mm if hay_exo else 26 * mm])
        ttr = Table(tr, colWidths=anchos_tr)
        ttr.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 8.5), ("ALIGN", (1, 1), (-1, -1), "RIGHT"), ("TEXTCOLOR", (0, 1), (-1, -1), GRIS),
                                 ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINEA), ("BACKGROUND", (0, -1), (-1, -1), GRIS_CLARO),
                                 ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
        fila = Table([[ttr, tt]], colWidths=[ancho * 0.58, ancho * 0.42])
        fila.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
        flow.append(fila)
    elif electronico:
        flow.append(tt)
    # (no electrónicos: los totales se dibujan al pie de la última página, como en la cotización de referencia)
    for xo in d.get("exoneraciones") or []:
        flow += [Spacer(1, 2 * mm), Paragraph(_esc(texto_exoneracion(xo)), small)]
    flow.append(Spacer(1, 4 * mm))

    terminos = d.get("terminos") or cfg.get("terminos", "")     # vacío en el documento → los configurados en Documentos (R50)
    if on("terminos") and terminos:
        flow.append(Paragraph("<b>Términos y condiciones:</b>", base))
        for linea in str(terminos).splitlines():
            if linea.strip():
                flow.append(Paragraph(_esc(linea.strip()), base))
        flow.append(Spacer(1, 2 * mm))
    notas = d.get("notas") or cfg.get("notas", "")
    if on("notas") and notas:
        flow += [Paragraph("<b>Notas:</b>", base), Paragraph(_esc(notas).replace("\n", "<br/>"), base)]
    if d.get("estado"):
        flow += [Spacer(1, 2 * mm), Paragraph(f"<b>Estado:</b> {_esc(d['estado'])}", small)]

    # --- Pie fijo (QR, leyenda, paginación)
    qr_img = None
    if on("qr") and d.get("clave"):
        buf = io.BytesIO(); qrcode.make(d["clave"]).save(buf, format="PNG"); buf.seek(0); qr_img = buf
    # firma de la empresa (imagen) al pie de la última página, a la izquierda; el pie propio (texto) sobre la leyenda
    firma_img = None
    if est.get("firma") and d["tipo"] in ("factura", "tiquete", "nota_credito", "nota_debito", "cotizacion", "remision", "orden_compra", "recibo"):
        try:
            import base64 as _b64
            raw = _b64.b64decode(str(est["firma"]).split(",", 1)[1])
            firma_img = io.BytesIO(raw)
            from reportlab.lib.utils import ImageReader
            iw0, ih0 = ImageReader(firma_img).getSize(); firma_img.seek(0)
            if iw0 * ih0 > 4_000_000 or iw0 > 3000 or ih0 > 2000:      # una imagen enorme consumiría cientos de MB por cada PDF
                firma_img = None
        except Exception:  # noqa: BLE001  una imagen corrupta no impide imprimir
            firma_img = None
    pie_propio = str(est.get("pie") or "").strip()

    def pie(cv, pagina_n, total):
        cv.saveState()
        y = 12 * mm
        if qr_img is not None and pagina_n == total:
            from reportlab.lib.utils import ImageReader
            qr_img.seek(0)
            cv.drawImage(ImageReader(qr_img), pagina[0] - MARGEN - 34 * mm, 18 * mm, 34 * mm, 34 * mm)
        if firma_img is not None and pagina_n == total:
            from reportlab.lib.utils import ImageReader
            firma_img.seek(0)
            img = ImageReader(firma_img); iw, ih = img.getSize()
            alto = 16 * mm; ancho_f = min(alto * iw / float(ih or 1), 55 * mm)
            x0 = MARGEN if electronico else MARGEN
            cv.drawImage(img, x0, 20 * mm, ancho_f, alto, mask="auto")
            if est.get("firma_texto"):
                cv.setFont("Helvetica", 7); cv.setFillColor(GRIS); cv.drawString(x0, 17.5 * mm, str(est["firma_texto"])[:80])
        if not electronico and pagina_n == total:
            # Totales al pie de la última página, a la derecha, con una línea gris a la izquierda (cotización de referencia)
            w_tt, h_tt = tt.wrapOn(cv, ancho * 0.6, 70 * mm)
            tt.drawOn(cv, pagina[0] - MARGEN - w_tt, 14 * mm)
            cv.setStrokeColor(LINEA); cv.line(MARGEN, 14 * mm, pagina[0] - MARGEN - w_tt - 6 * mm, 14 * mm)
            if dual:
                cv.setFont("Helvetica", 7.5); cv.setFillColor(GRIS)
                cv.drawRightString(pagina[0] - MARGEN, 14 * mm + h_tt + 2 * mm, f"Tipo de cambio: {fmt(tc, 'CRC')} por USD")
        cv.setFont("Helvetica", 7); cv.setFillColor(GRIS)
        if pie_propio:
            cv.drawCentredString(pagina[0] / 2, y + (18 if (on("leyenda_legal") and electronico and not d.get("interno")) else 9), pie_propio[:200])
        if on("leyenda_legal") and electronico and not d.get("interno"):
            cv.drawCentredString(pagina[0] / 2, y + 9, f"Representación impresa {'del' if titulo.lower().startswith(('tiquete', 'recibo')) else 'de la'} {titulo.lower()} - Versión 4.4")
            cv.drawCentredString(pagina[0] / 2, y, LEYENDA)
            cv.setStrokeColor(LINEA); cv.line(MARGEN, y - 4, pagina[0] - MARGEN, y - 4)
        if on("paginacion"):
            cv.drawString(MARGEN, 6 * mm, f"Página {pagina_n} de {total}")
        cv.restoreState()

    out = io.BytesIO()
    abajo = 58 if qr_img is not None else (44 if not electronico else 24)
    if firma_img is not None:
        abajo = max(abajo, 44)
    doc = SimpleDocTemplate(out, pagesize=pagina, leftMargin=MARGEN, rightMargin=MARGEN, topMargin=10 * mm,
                            bottomMargin=abajo * mm, title=f"{titulo} {d['numero']}")
    doc.build(flow, canvasmaker=lambda *a, **k: _Canvas(*a, pie=pie, **k))
    return out.getvalue()


# ----------------------------------------------------------------------------- API pública del módulo
def logo_empresa(empresa) -> Path | None:
    if empresa is not None and getattr(empresa, "logo_nombre", None):
        p = DATA_DIR / empresa.logo_nombre
        if p.exists():
            return p
    return None     # sin logo propio no se imprime logo (cada empresa sube el suyo en Configuración › Empresa)


def generar_pdf(xml_bytes: bytes, respuesta_xml: bytes | None = None, meta: dict | None = None, cfg: dict | None = None,
                logo_path: Path | None = None) -> bytes:
    d = datos_desde_xml(xml_bytes, respuesta_xml, meta)
    if cfg is None:                                                   # la plantilla es por empresa: debe venir resuelta (R257)
        raise ValueError("generar_pdf requiere cfg = plantillas.obtener(tipo, empresa_id)")
    if cfg.get("titulo") and cfg.get("guardada") and d["titulo"] not in ("Factura electrónica de compra", "Factura electrónica de exportación", "Recibo electrónico de pago"):
        d["titulo"] = cfg["titulo"]           # el título guardado NO se aplica a la factura de compra ni a la de exportación (R101)
    if meta and meta.get("interno"):
        _interno(d)
    return render(d, cfg, logo_path)


# ----------------------------------------------------------------------------- tiquete térmico (58 / 80 mm)
def render_tiquete(d: dict, ancho_mm: int = 80, logo_path: Path | None = None, extra: dict | None = None) -> bytes:
    """Representación para impresora térmica: una sola columna, ancho 58 u 80 mm, alto según el contenido. `extra` puede traer
    recibido/vuelto (efectivo) y el nombre del cajero; se imprimen al pie."""
    _reportlab()
    from reportlab.lib.utils import simpleSplit
    extra = extra or {}
    W = (80 if int(ancho_mm or 80) >= 70 else 58) * mm
    M = 3 * mm
    ancho = W - 2 * M
    mon = d["moneda"]
    e, c, t = d["emisor"], d.get("cliente"), d["totales"]
    lineas_txt: list[tuple[str, str, float, str]] = []     # (texto, fuente, tamaño, alineación L|C|R) o separadores

    def add(texto, fuente="Helvetica", tam=8, al="L"):
        for parte in simpleSplit(str(texto or ""), fuente, tam, ancho):
            lineas_txt.append((parte, fuente, tam, al))

    def sep():
        lineas_txt.append(("-" * (48 if W > 70 * mm else 32), "Courier", 7, "C"))

    def par(izq, der, fuente="Helvetica", tam=8):
        """Dos columnas: texto a la izquierda y monto a la derecha (la izquierda se recorta al espacio libre)."""
        from reportlab.pdfbase.pdfmetrics import stringWidth
        wd = stringWidth(der, fuente, tam)
        izq_ok = simpleSplit(str(izq), fuente, tam, ancho - wd - 2 * mm)
        lineas_txt.append(((izq_ok[0] if izq_ok else "", der), fuente, tam, "LR"))

    logo = None
    if logo_path and Path(logo_path).exists():
        try:
            from reportlab.lib.utils import ImageReader
            logo = ImageReader(str(logo_path))
        except Exception:
            logo = None
    if extra.get("copia"):                                  # 4.33: reimpresión de un tiquete ya entregado
        add("*** COPIA ***", "Helvetica-Bold", 14, "C")
        add("Reimpresión · no es un nuevo comprobante", "Helvetica", 6.5, "C")
    add(e.get("nombre_comercial") or e.get("nombre"), "Helvetica-Bold", 10, "C")
    if e.get("nombre_comercial") and e.get("nombre") and e["nombre"] != e["nombre_comercial"]:
        add(e["nombre"], "Helvetica", 7.5, "C")
    add(f"{TIPO_ID.get(e.get('tipo_id'), 'Identificación')}: {e.get('cedula', '')}", "Helvetica", 7.5, "C")
    if e.get("direccion"):
        add(e["direccion"], "Helvetica", 7, "C")
    if e.get("telefono") or e.get("correo"):
        add("  ".join(x for x in [e.get("telefono", ""), e.get("correo", "")] if x), "Helvetica", 7, "C")
    sep()
    add(d["titulo"], "Helvetica-Bold", 9, "C")
    add(f"No. {d['numero']}", "Courier-Bold", 8, "C")
    add(f"Fecha: {_fecha(d['fecha_emision'], hora=True)}", "Helvetica", 7.5, "C")
    if d.get("clave"):
        add("Clave: " + d["clave"], "Courier", 6, "C")
    if extra.get("cajero"):
        add(f"Cajero: {extra['cajero']}", "Helvetica", 7, "C")
    sep()
    if c and c.get("nombre"):
        add(f"Cliente: {c['nombre']}", "Helvetica", 7.5)
        if c.get("cedula"):
            add(f"{TIPO_ID.get(c.get('tipo_id'), 'Identificación')}: {c['cedula']}", "Helvetica", 7.5)
    else:
        add("Cliente: consumidor final", "Helvetica", 7.5)
    add(f"Condición: {d.get('condicion') or 'Contado'}" + (f"  ·  {d['medio_pago']}" if d.get("medio_pago") else ""), "Helvetica", 7.5)
    sep()
    for l in d["lineas"]:
        add(l["detalle"], "Helvetica", 8)
        cant = l["cantidad"]
        cant_txt = f"{cant:.3f}".rstrip("0").rstrip(".") if cant != cant.to_integral() else f"{int(cant)}"
        par(f"  {cant_txt} x {fmt(l['precio'], mon, con_codigo=False)}" + (f"  -{fmt(l['descuento'], mon, con_codigo=False)}" if l.get("descuento") else ""), fmt(l["total"] + (l.get("impuesto") or 0), mon, con_codigo=False), "Helvetica", 7.5)
        if l.get("exoneracion"):
            add(f"  Exonerado {l['exoneracion']['tarifa']:g}% (IVA {fmt(l['exoneracion']['monto'], mon, con_codigo=False)})", "Helvetica", 6.5)
    sep()
    par("Subtotal", fmt(t["subtotal"], mon, con_codigo=False))
    if t.get("descuento"):
        par("Descuento", "-" + fmt(t["descuento"], mon, con_codigo=False))
    if t.get("iva_exonerado"):
        par("IVA exonerado (no se cobra)", fmt(t["iva_exonerado"], mon, con_codigo=False))
    par("IVA", fmt(t["impuesto"], mon, con_codigo=False))
    for nombre_oi, monto_oi in t.get("otros_impuestos") or []:
        par(nombre_oi, fmt(monto_oi, mon, con_codigo=False))
    for oc in d.get("otros_cargos") or []:
        par(oc.get("detalle") or "Otros cargos", fmt(oc.get("monto") or 0, mon, con_codigo=False))
    par("TOTAL " + mon, fmt(t["total"], mon, con_codigo=False), "Helvetica-Bold", 10)
    if extra.get("recibido") is not None:
        par("Recibido", fmt(Decimal(str(extra["recibido"])), mon, con_codigo=False))
        par("Vuelto", fmt(Decimal(str(extra.get("vuelto") or 0)), mon, con_codigo=False), "Helvetica-Bold", 8)
    if extra.get("pagos"):
        for p in extra["pagos"]:
            par(str(p.get("medio") or "Pago"), fmt(Decimal(str(p.get("monto") or 0)), mon, con_codigo=False), "Helvetica", 7.5)
    tc = d.get("tipo_cambio") or Decimal(1)
    if mon != "CRC" and tc and tc != 1:
        add(f"Tipo de cambio: {fmt(tc, 'CRC', con_codigo=False)} por {mon}", "Helvetica", 7)
    sep()
    if d.get("estado"):
        add(f"Hacienda: {d['estado']}", "Helvetica", 7, "C")
    for xo in d.get("exoneraciones") or []:
        add(texto_exoneracion(xo), "Helvetica", 6.5)
    if d.get("notas"):
        add(d["notas"], "Helvetica", 7)
    add(LEYENDA, "Helvetica", 5.5, "C")
    add("¡Gracias por su compra!", "Helvetica-Bold", 8, "C")

    # alto: líneas + logo + QR
    alto_lineas = sum((tam * 1.25) for (_, _, tam, _) in lineas_txt)
    h_logo = 16 * mm if logo else 0
    h_qr = 24 * mm if d.get("clave") else 0
    H = alto_lineas + h_logo + h_qr + 2 * M + 10 * mm
    buf = io.BytesIO()
    cv = rl_canvas.Canvas(buf, pagesize=(W, H))
    y = H - M
    if logo:
        try:
            iw, ih = logo.getSize(); ratio = iw / float(ih)
            lw = min(ancho, 14 * mm * ratio); lh = lw / ratio
            cv.drawImage(logo, (W - lw) / 2, y - lh, lw, lh, mask="auto"); y -= lh + 2 * mm
        except Exception:
            pass
    for texto, fuente, tam, al in lineas_txt:
        y -= tam * 1.25
        cv.setFont(fuente, tam)
        if al == "LR":
            cv.drawString(M, y, texto[0]); cv.drawRightString(W - M, y, texto[1])
        elif al == "C":
            cv.drawCentredString(W / 2, y, texto)
        elif al == "R":
            cv.drawRightString(W - M, y, texto)
        else:
            cv.drawString(M, y, texto)
        if texto == "¡Gracias por su compra!" and d.get("clave"):
            qb = io.BytesIO(); qrcode.make(d["clave"]).save(qb, format="PNG"); qb.seek(0)
            from reportlab.lib.utils import ImageReader
            y -= 22 * mm + 1 * mm
            cv.drawImage(ImageReader(qb), (W - 22 * mm) / 2, y, 22 * mm, 22 * mm)
    cv.showPage(); cv.save()
    return buf.getvalue()


def generar_tiquete(xml_bytes: bytes, respuesta_xml: bytes | None = None, meta: dict | None = None, ancho_mm: int = 80,
                    logo_path: Path | None = None, extra: dict | None = None) -> bytes:
    d = datos_desde_xml(xml_bytes, respuesta_xml, meta)
    if meta and meta.get("interno"):
        _interno(d)
    return render_tiquete(d, ancho_mm, logo_path, extra)


def generar_pdf_documento(payload: dict, cfg: dict | None = None, logo_path: Path | None = None) -> bytes:
    d = datos_desde_json(payload)
    if cfg is None:
        raise ValueError("generar_pdf_documento requiere cfg = plantillas.obtener(tipo, empresa_id)")
    d["titulo"] = d["titulo"] or cfg.get("titulo", "")
    return render(d, cfg, logo_path)
