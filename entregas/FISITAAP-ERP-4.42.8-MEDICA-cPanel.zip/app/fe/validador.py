"""Validación de los XML contra los XSD oficiales v4.4."""
import copy
from functools import lru_cache

from lxml import etree

from ..config import SCHEMAS_DIR, TIPOS_DOCUMENTO


@lru_cache(maxsize=None)
def _esquema(nombre: str) -> etree.XMLSchema:
    return etree.XMLSchema(etree.parse(str(SCHEMAS_DIR / f"{nombre}.xsd")))


DS = "http://www.w3.org/2000/09/xmldsig#"
DS_SIGNATURE = f"{{{DS}}}Signature"

# Firma mínima sintácticamente válida según xmldsig-core-schema.xsd; se usa solo para poder validar
# el contenido de un comprobante antes de firmarlo (el XSD exige ds:Signature como último hijo).
_FIRMA_PLACEHOLDER = (
    f'<ds:Signature xmlns:ds="{DS}"><ds:SignedInfo>'
    '<ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>'
    '<ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/>'
    '<ds:Reference URI=""><ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>'
    "<ds:DigestValue>AA==</ds:DigestValue></ds:Reference></ds:SignedInfo>"
    "<ds:SignatureValue>AA==</ds:SignatureValue></ds:Signature>"
)


def validar(root: etree._Element, tipo_documento: str) -> list[str]:
    """Devuelve la lista de errores (vacía si el documento es válido).

    Si el documento aún no está firmado se valida una copia con una firma de relleno, de modo que el
    contenido pueda comprobarse contra el XSD antes de firmar.
    """
    nombre = "mensajeReceptor" if tipo_documento in ("05", "06", "07") else TIPOS_DOCUMENTO[tipo_documento][1]
    esquema = _esquema(nombre)
    if root.find(DS_SIGNATURE) is None:
        root = copy.deepcopy(root)
        root.append(etree.fromstring(_FIRMA_PLACEHOLDER))
    esquema.validate(root)
    return [f"línea {e.line}: {e.message}" for e in esquema.error_log]
