"""Clave numérica (50 dígitos) y número consecutivo (20 dígitos) según Hacienda CR.

Consecutivo (20): sucursal(3) + terminal(5) + tipo de documento(2) + número(10)
Clave (50):       506 + DDMMAA(6) + cédula emisor(12, rellena con ceros) + consecutivo(20)
                  + situación(1) + código de seguridad(8)
"""
import re
import secrets
from datetime import datetime

SITUACION_NORMAL = "1"
SITUACION_CONTINGENCIA = "2"
SITUACION_SIN_INTERNET = "3"


def generar_consecutivo(tipo_doc: str, numero: int, sucursal: int = 1, terminal: int = 1) -> str:
    if not re.fullmatch(r"\d{2}", tipo_doc):
        raise ValueError("tipo_doc debe ser de 2 dígitos")
    if not (0 < numero < 10**10):
        raise ValueError("numero fuera de rango")
    return f"{sucursal:03d}{terminal:05d}{tipo_doc}{numero:010d}"


def generar_clave(
    cedula_emisor: str,
    consecutivo: str,
    fecha: datetime,
    situacion: str = SITUACION_NORMAL,
    codigo_seguridad: str | None = None,
    pais: str = "506",
) -> str:
    # Revisión v4.4 de abril 2026: la clave admite cédulas alfanuméricas (ClaveType [a-zA-Z0-9]{50}); el segmento sigue siendo de 12 posiciones
    cedula = re.sub(r"[^A-Za-z0-9]", "", cedula_emisor).upper()
    if not (9 <= len(cedula) <= 12):
        raise ValueError("cédula del emisor debe tener entre 9 y 12 caracteres (dígitos o letras)")
    if len(consecutivo) != 20 or not consecutivo.isdigit():
        raise ValueError("consecutivo debe tener 20 dígitos")
    if situacion not in ("1", "2", "3"):
        raise ValueError("situación inválida")
    if codigo_seguridad is None:
        codigo_seguridad = f"{secrets.randbelow(10**8):08d}"
    if len(codigo_seguridad) != 8 or not codigo_seguridad.isdigit():
        raise ValueError("código de seguridad debe tener 8 dígitos")
    clave = f"{pais}{fecha:%d%m%y}{cedula.zfill(12)}{consecutivo}{situacion}{codigo_seguridad}"
    assert len(clave) == 50
    return clave


def desglosar_clave(clave: str) -> dict:
    # la cédula del emisor (posiciones 10–21) puede traer letras desde la revisión del 22/04/2026; el resto son dígitos
    if not re.fullmatch(r"[A-Za-z0-9]{50}", clave or "") or not (clave[:9] + clave[21:]).isdigit():
        raise ValueError("clave debe tener 50 caracteres (solo la cédula del emisor puede traer letras)")
    return {
        "pais": clave[0:3],
        "fecha": clave[3:9],
        "cedula_emisor": clave[9:21].lstrip("0"),
        "consecutivo": clave[21:41],
        "sucursal": clave[21:24],
        "terminal": clave[24:29],
        "tipo_documento": clave[29:31],
        "numero": clave[31:41],
        "situacion": clave[41],
        "codigo_seguridad": clave[42:50],
    }
