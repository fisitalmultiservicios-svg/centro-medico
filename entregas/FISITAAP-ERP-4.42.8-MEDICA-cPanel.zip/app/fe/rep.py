"""Recibo Electrónico de Pago (tipo 10, v4.4) — XML según reciboElectronicoPago.xsd.

Cuándo aplica (art. 27 LIVA): documenta el cobro de una factura emitida a crédito con IVA diferido (condición de venta 10,
"venta a crédito hasta 90 días") o de servicios prestados al Estado a crédito (condición 08). El REP lleva condición 11
(o 09 para el Estado), referencia la factura con el código 17 "pago a comprobante electrónico" (revisión de abril 2026)
y reparte el monto cobrado entre base e IVA en la misma proporción de la factura. Para facturas de contado o a crédito
normal (condición 01/02) no se emite REP: basta el recibo de caja.

Estructura (XSD): Clave, ProveedorSistemas, NumeroConsecutivo, FechaEmision, Emisor (Nombre, Identificacion, Correo),
Receptor (Nombre, Identificacion, Correo?), CondicionVenta, DetalleServicio/LineaDetalle (NumeroLinea, Detalle,
MontoTotal, SubTotal, Impuesto?, ImpuestoNeto, MontoTotalLinea), ResumenFactura (CodigoTipoMoneda, TotalVenta,
TotalVentaNeta, TotalDesgloseImpuesto*, TotalImpuesto?, MedioPago+, TotalComprobante), InformacionReferencia+, Signature.
"""
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal, Optional

from lxml import etree
from pydantic import BaseModel, Field

from ..config import NS_BASE, TIPOS_DOCUMENTO
from .modelos import Parte, Referencia
from .xml_builder import XSD, XSI, _Nodo, _d

CONDICION_FACTURA_A_REP = {"10": "11", "08": "09"}     # condición de la factura -> condición del REP
Q = Decimal("0.00001")


class LineaREP(BaseModel):
    detalle: str = Field(min_length=3, max_length=200)
    monto: Decimal                      # base (sin IVA) de la parte pagada
    codigo_tarifa: Optional[str] = None  # None = sin impuesto
    tarifa: Decimal = Decimal(0)
    impuesto: Decimal = Decimal(0)


class ReciboPago(BaseModel):
    clave: str = Field(min_length=50, max_length=50)
    consecutivo: str = Field(min_length=20, max_length=20)
    fecha_emision: str
    proveedor_sistemas: str
    emisor: Parte
    receptor: Parte
    condicion_venta: Literal["09", "11"] = "11"
    moneda: str = "CRC"
    tipo_cambio: Decimal = Decimal(1)
    lineas: list[LineaREP]
    medio_pago: str = "04"
    medio_pago_otros: Optional[str] = Field(default=None, min_length=3, max_length=100)   # obligatorio con 99
    referencias: list[Referencia]


def lineas_pago(lineas_factura: list[dict], total_factura: Decimal, monto_pagado: Decimal, consecutivo_factura: str) -> list[LineaREP]:
    """Reparte el monto pagado entre las tarifas de IVA de la factura, en la misma proporción. Una línea por tarifa."""
    fraccion = (monto_pagado / total_factura) if total_factura else Decimal(0)
    grupos: dict[tuple, dict] = {}
    suma_lineas = Decimal(0)
    for l in lineas_factura:
        k = (str(l.get("codigo_tarifa") or "08"), Decimal(str(l.get("tarifa") or 0)))
        g = grupos.setdefault(k, {"base": Decimal(0), "iva": Decimal(0)})
        base = Decimal(str(l.get("total") or 0)) - Decimal(str(l.get("impuesto") or 0))   # total de línea en DocumentoLinea incluye el IVA: la base es total − impuesto (R250)
        g["base"] += base; g["iva"] += Decimal(str(l.get("impuesto") or 0))
        suma_lineas += Decimal(str(l.get("total") or 0))
    out = []
    for (cod, tarifa), g in grupos.items():
        base = (g["base"] * fraccion).quantize(Q, ROUND_HALF_UP)
        iva = (g["iva"] * fraccion).quantize(Q, ROUND_HALF_UP)
        out.append(LineaREP(detalle=f"Pago de la factura {consecutivo_factura}" + (f" (IVA {tarifa:.2f} %)" if len(grupos) > 1 else ""),
                            monto=base, codigo_tarifa=cod if iva else None, tarifa=tarifa, impuesto=iva))
    # Otros cargos de la factura (impuesto de servicio, timbres): no están en las líneas y no llevan IVA → línea aparte
    otros = total_factura - suma_lineas
    if otros > Decimal("0.005"):
        out.append(LineaREP(detalle=f"Pago de otros cargos de la factura {consecutivo_factura}", monto=(otros * fraccion).quantize(Q, ROUND_HALF_UP), codigo_tarifa=None, tarifa=Decimal(0), impuesto=Decimal(0)))
    # Ajuste de redondeo: el total de las líneas debe ser exactamente el monto pagado (va a una línea sin IVA si la hay)
    diff = monto_pagado - sum((l.monto + l.impuesto for l in out), Decimal(0))
    if out and diff:
        destino = next((l for l in out if not l.impuesto), out[0])
        destino.monto += diff
    return out


def construir_xml_rep(r: ReciboPago) -> etree._Element:
    raiz, sufijo = TIPOS_DOCUMENTO["10"]
    ns = NS_BASE + sufijo
    root = etree.Element(f"{{{ns}}}{raiz}", nsmap={None: ns, "xsd": XSD, "xsi": XSI})
    sub = _Nodo(ns)
    sub(root, "Clave", r.clave)
    sub(root, "ProveedorSistemas", r.proveedor_sistemas)
    sub(root, "NumeroConsecutivo", r.consecutivo)
    sub(root, "FechaEmision", r.fecha_emision)
    for tag, p in (("Emisor", r.emisor), ("Receptor", r.receptor)):
        el = sub(root, tag)
        sub(el, "Nombre", p.nombre)
        ident = sub(el, "Identificacion")
        sub(ident, "Tipo", p.identificacion.tipo)
        sub(ident, "Numero", p.identificacion.numero)
        if p.correo:
            sub(el, "CorreoElectronico", p.correo)
        elif tag == "Emisor":
            raise ValueError("El emisor requiere correo electrónico")
    sub(root, "CondicionVenta", r.condicion_venta)
    det = sub(root, "DetalleServicio")
    total_venta = total_iva = Decimal(0)
    desglose: dict[str, Decimal] = {}
    for i, l in enumerate(r.lineas, start=1):
        ld = sub(det, "LineaDetalle")
        sub(ld, "NumeroLinea", i)
        sub(ld, "Detalle", l.detalle)
        sub(ld, "MontoTotal", _d(l.monto))
        sub(ld, "SubTotal", _d(l.monto))
        if l.codigo_tarifa and l.impuesto:
            ie = sub(ld, "Impuesto")
            sub(ie, "Codigo", "01")
            sub(ie, "CodigoTarifaIVA", l.codigo_tarifa)
            sub(ie, "Tarifa", f"{l.tarifa:.2f}")
            sub(ie, "Monto", _d(l.impuesto))
            desglose[l.codigo_tarifa] = desglose.get(l.codigo_tarifa, Decimal(0)) + l.impuesto
        sub(ld, "ImpuestoNeto", _d(l.impuesto))
        sub(ld, "MontoTotalLinea", _d(l.monto + l.impuesto))
        total_venta += l.monto; total_iva += l.impuesto
    res = sub(root, "ResumenFactura")
    mon = sub(res, "CodigoTipoMoneda")
    sub(mon, "CodigoMoneda", r.moneda)
    sub(mon, "TipoCambio", _d(r.tipo_cambio))
    sub(res, "TotalVenta", _d(total_venta))
    sub(res, "TotalVentaNeta", _d(total_venta))
    for cod, monto in desglose.items():
        di = sub(res, "TotalDesgloseImpuesto")
        sub(di, "Codigo", "01")
        sub(di, "CodigoTarifaIVA", cod)
        sub(di, "TotalMontoImpuesto", _d(monto))
    sub(res, "TotalImpuesto", _d(total_iva))
    mp = sub(res, "MedioPago")
    sub(mp, "TipoMedioPago", r.medio_pago)
    if r.medio_pago == "99":
        if not r.medio_pago_otros:
            raise ValueError("Con el medio de pago «Otros» (99) hay que indicar cuál (MedioPagoOtros, 3 a 100 caracteres)")
        sub(mp, "MedioPagoOtros", r.medio_pago_otros)
    sub(mp, "TotalMedioPago", _d(total_venta + total_iva))
    sub(res, "TotalComprobante", _d(total_venta + total_iva))
    if not r.referencias:
        raise ValueError("El recibo electrónico de pago requiere la factura de referencia")
    for ref in r.referencias:
        ir = sub(root, "InformacionReferencia")
        sub(ir, "TipoDocIR", ref.tipo_doc)
        if ref.tipo_doc == "99":
            sub(ir, "TipoDocRefOTRO", ref.tipo_doc_otro.strip())
        sub(ir, "Numero", ref.numero)
        sub(ir, "FechaEmisionIR", ref.fecha_emision)
        sub(ir, "Codigo", ref.codigo)
        if ref.codigo == "99":
            sub(ir, "CodigoReferenciaOTRO", ref.codigo_otro.strip())
        sub(ir, "Razon", ref.razon)
    return root
