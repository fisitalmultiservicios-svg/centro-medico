"""Cálculo de montos por línea y resumen del comprobante (reglas del Anexo v4.4)."""
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP

from .modelos import EN_BASE_IVA, Comprobante, Linea

Q5 = Decimal("0.00001")
Q2 = Decimal("0.01")
TARIFAS_EXENTAS = {"10"}  # 10 = Tarifa exenta


def q(valor: Decimal) -> Decimal:
    return Decimal(valor).quantize(Q5, rounding=ROUND_HALF_UP)


def q2(valor: Decimal) -> Decimal:
    return Decimal(valor).quantize(Q2, rounding=ROUND_HALF_UP)


@dataclass
class ImpuestoCalculado:
    codigo: str
    codigo_tarifa: object                      # None fuera del IVA
    tarifa: object                             # None en los específicos y en el Selectivo por monto
    monto: Decimal
    monto_exonerado: Decimal = Decimal(0)      # MontoExoneracion (0 sin exoneración)
    exoneracion: object = None                 # modelos.Exoneracion
    especifico: object = None                  # modelos.DatosImpuestoEspecifico
    cantidad_unidad: Decimal = Decimal(0)      # CantidadUnidadMedida escrita en el XML (7,2)
    proporcion: Decimal = Decimal(0)           # 04: mililitros de alcohol absoluto por unidad (10,5)


@dataclass
class LineaCalculada:
    linea: Linea
    monto_total: Decimal
    total_descuento: Decimal
    subtotal: Decimal
    base_imponible: Decimal
    impuestos: list[ImpuestoCalculado]
    impuesto_neto: Decimal
    monto_total_linea: Decimal
    gravada: bool
    iva_neto: Decimal = Decimal(0)             # IVA − exonerado (lo que va a la declaración de IVA)
    otros_neto: Decimal = Decimal(0)           # Selectivo y específicos (3.41)


@dataclass
class Resumen:
    lineas: list[LineaCalculada]
    total_serv_gravados: Decimal = Decimal(0)
    total_serv_exentos: Decimal = Decimal(0)
    total_serv_exonerado: Decimal = Decimal(0)
    total_merc_gravadas: Decimal = Decimal(0)
    total_merc_exentas: Decimal = Decimal(0)
    total_merc_exonerada: Decimal = Decimal(0)
    total_gravado: Decimal = Decimal(0)
    total_exento: Decimal = Decimal(0)
    total_exonerado: Decimal = Decimal(0)
    total_iva_exonerado: Decimal = Decimal(0)   # suma de MontoExoneracion (IVA que no se cobra)
    total_venta: Decimal = Decimal(0)
    total_descuentos: Decimal = Decimal(0)
    total_venta_neta: Decimal = Decimal(0)
    desglose_impuesto: dict[tuple[str, str], Decimal] = field(default_factory=dict)
    total_impuesto: Decimal = Decimal(0)
    total_iva: Decimal = Decimal(0)              # solo IVA neto (3.41)
    total_otros_impuestos: Decimal = Decimal(0)  # Selectivo de Consumo e impuestos específicos (3.41)
    total_otros_cargos: Decimal = Decimal(0)
    total_comprobante: Decimal = Decimal(0)


def _otro(imp, cantidad: Decimal, subtotal: Decimal) -> ImpuestoCalculado:
    """Selectivo de Consumo y específicos con las fórmulas del campo «Monto del impuesto» (Anexos 4.4)."""
    c, e = imp.codigo, imp.especifico
    cu = prop = Decimal(0)
    if c == "02":
        monto = q(subtotal * imp.tarifa / 100) if imp.tarifa is not None else q(cantidad * imp.monto_unidad)
    elif c == "12":
        monto = q(subtotal * imp.tarifa / 100)                      # tarifa (5 %) × subtotal
    elif c == "03":
        cu = q2(cantidad * e.cantidad_unidad)                         # litros de la línea
        monto = q(cu * e.impuesto_unidad)                             # Cantidad unidad de medida × Impuesto por unidad
    elif c == "04":
        cu = q2(e.cantidad_unidad)
        prop = q(cu * e.porcentaje / 100)                             # mililitros de alcohol absoluto por envase
        monto = q(cantidad * prop * e.impuesto_unidad)                # Cantidad × Proporción × Impuesto por unidad
    elif c == "05":
        cu = q2(e.cantidad_unidad)
        vol = q2(e.volumen_unidad)
        monto = q(cantidad * vol * e.impuesto_unidad) if e.jabon else q(cantidad * cu * e.impuesto_unidad / vol)
    else:                                                             # 06 tabaco
        cu = q2(e.cantidad_unidad)
        monto = q(cantidad * cu * e.impuesto_unidad)                  # Cantidad × Cantidad unidad de medida × Impuesto por unidad
    return ImpuestoCalculado(c, None, imp.tarifa, monto, especifico=e, cantidad_unidad=cu, proporcion=prop)


def calcular_linea(linea: Linea) -> LineaCalculada:
    monto_total = q(linea.cantidad * linea.precio_unitario)
    total_desc = q(sum((d.monto for d in linea.descuentos), Decimal(0)))
    subtotal = q(monto_total - total_desc)
    # primero el Selectivo y los específicos: los que indica el Anexo se suman a la base del IVA (3.41)
    otros = {id(imp): _otro(imp, linea.cantidad, subtotal) for imp in linea.impuestos if imp.codigo != "01"}
    base = q(subtotal + sum((o.monto for o in otros.values() if o.codigo in EN_BASE_IVA), Decimal(0)))
    impuestos = []
    gravada = False
    hay_iva = any(imp.codigo == "01" for imp in linea.impuestos)
    for imp in linea.impuestos:
        if imp.codigo != "01":
            impuestos.append(otros[id(imp)])
            continue
        exo, monto_exo = None, Decimal(0)
        if imp.codigo_tarifa in TARIFAS_EXENTAS:
            monto = Decimal(0)
        else:
            gravada = True
            monto = q(base * imp.tarifa / 100)
            if imp.exoneracion is not None and monto > 0:
                # MontoExoneracion = base × TarifaExonerada / 100, nunca mayor que el impuesto (Anexos v4.4)
                exo = imp.exoneracion
                monto_exo = min(q(base * min(exo.tarifa, imp.tarifa) / 100), monto)
        impuestos.append(ImpuestoCalculado(imp.codigo, imp.codigo_tarifa, imp.tarifa, monto, monto_exo, exo))
    if not hay_iva:
        gravada = any(i.monto > 0 for i in impuestos)
    iva_neto = q(sum((i.monto - i.monto_exonerado for i in impuestos if i.codigo == "01"), Decimal(0)))
    otros_neto = q(sum((i.monto for i in impuestos if i.codigo != "01"), Decimal(0)))
    impuesto_neto = q(iva_neto + otros_neto)
    return LineaCalculada(
        linea=linea, monto_total=monto_total, total_descuento=total_desc, subtotal=subtotal,
        base_imponible=base, impuestos=impuestos, impuesto_neto=impuesto_neto,
        monto_total_linea=q(subtotal + impuesto_neto), gravada=gravada, iva_neto=iva_neto, otros_neto=otros_neto,
    )


def calcular(comp: Comprobante) -> Resumen:
    r = Resumen(lineas=[calcular_linea(l) for l in comp.lineas])
    # por categoría (servicios / mercancías): monto gravado total y la parte exonerada. Anexos v4.4: porcentaje de exoneración =
    # monto exonerado / monto del impuesto, aplicado al MontoTotal de cada línea (así no se mezclan tarifas ni descuentos de
    # líneas distintas); gravado = total − exonerado
    cat = {"serv": [Decimal(0), Decimal(0)], "merc": [Decimal(0), Decimal(0)]}
    for lc in r.lineas:
        k = "serv" if lc.linea.es_servicio else "merc"
        if lc.gravada:
            cat[k][0] += lc.monto_total
            imp = sum((i.monto for i in lc.impuestos), Decimal(0))
            exo = sum((i.monto_exonerado for i in lc.impuestos), Decimal(0))
            if imp and exo:
                cat[k][1] += lc.monto_total * exo / imp
        elif k == "serv":
            r.total_serv_exentos += lc.monto_total
        else:
            r.total_merc_exentas += lc.monto_total
        r.total_descuentos += lc.total_descuento
        for i in lc.impuestos:
            if i.monto:          # con exoneración total el desglose va con su impuesto neto (puede ser 0)
                k2 = (i.codigo, i.codigo_tarifa)
                r.desglose_impuesto[k2] = r.desglose_impuesto.get(k2, Decimal(0)) + (i.monto - i.monto_exonerado)
        r.total_impuesto += lc.impuesto_neto
        r.total_iva += lc.iva_neto
        r.total_otros_impuestos += lc.otros_neto
        r.total_iva_exonerado += sum((i.monto_exonerado for i in lc.impuestos), Decimal(0))
    for k, (total, exo_total) in cat.items():
        exonerado = q(exo_total)                 # sin exoneración es 0 y todo queda gravado, como antes
        gravado = q(total - exonerado)
        if k == "serv":
            r.total_serv_gravados, r.total_serv_exonerado = gravado, exonerado
        else:
            r.total_merc_gravadas, r.total_merc_exonerada = gravado, exonerado
    r.total_gravado = q(r.total_serv_gravados + r.total_merc_gravadas)
    r.total_exento = q(r.total_serv_exentos + r.total_merc_exentas)
    r.total_exonerado = q(r.total_serv_exonerado + r.total_merc_exonerada)
    r.total_iva_exonerado = q(r.total_iva_exonerado)
    r.total_venta = q(r.total_gravado + r.total_exento + r.total_exonerado)
    r.total_venta_neta = q(r.total_venta - r.total_descuentos)
    r.total_impuesto = q(r.total_impuesto)
    r.total_iva, r.total_otros_impuestos = q(r.total_iva), q(r.total_otros_impuestos)
    r.total_otros_cargos = q(sum((q(oc.monto) for oc in getattr(comp, "otros_cargos", None) or []), Decimal(0)))
    r.total_comprobante = q(r.total_venta_neta + r.total_impuesto + r.total_otros_cargos)   # TotalComprobante incluye OtrosCargos (Anexo v4.4)
    return r
