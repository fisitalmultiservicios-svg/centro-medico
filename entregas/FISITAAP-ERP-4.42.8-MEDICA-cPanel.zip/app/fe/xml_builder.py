"""Construcción del XML v4.4 (FE, TE, NC, ND, FEC, FEE) a partir del modelo de dominio."""
from decimal import Decimal

from lxml import etree

from ..config import NS_BASE, TIPOS_DOCUMENTO
from .calculo import calcular
from .modelos import CODIGOS_DESCUENTO, Comprobante, Parte

XSI = "http://www.w3.org/2001/XMLSchema-instance"
XSD = "http://www.w3.org/2001/XMLSchema"


def _d(v: Decimal) -> str:
    return f"{Decimal(v):.5f}"


class _Nodo:
    """Ayudante para crear hijos en el namespace del documento."""

    def __init__(self, ns: str):
        self.ns = ns

    def __call__(self, parent, tag, text=None):
        el = etree.SubElement(parent, f"{{{self.ns}}}{tag}")
        if text is not None:
            el.text = str(text)
        return el


def _parte(sub: _Nodo, parent, tag: str, p: Parte, es_emisor: bool, exportacion: bool = False):
    el = sub(parent, tag)
    sub(el, "Nombre", p.nombre)
    if p.identificacion is not None:              # receptor de tiquete sin identificación (3.33): el XSD la deja opcional
        ident = sub(el, "Identificacion")
        sub(ident, "Tipo", p.identificacion.tipo)
        sub(ident, "Numero", p.identificacion.numero)
    elif es_emisor or tag == "Emisor":
        raise ValueError("El emisor requiere identificación")
    if tag == "Emisor" and p.registro_fiscal:     # EmisorType: registro de bebidas alcohólicas (Ley 8707); el receptor no lo tiene
        sub(el, "Registrofiscal8707", p.registro_fiscal)
    if p.nombre_comercial:
        sub(el, "NombreComercial", p.nombre_comercial)
    if exportacion:                      # receptor de la factura de exportación: dirección libre, sin cantón/distrito
        if p.ubicacion:
            sub(el, "OtrasSenasExtranjero", p.ubicacion.otras_senas[:300])
        if p.telefono:
            t = sub(el, "Telefono")
            sub(t, "CodigoPais", p.telefono.codigo_pais)
            sub(t, "NumTelefono", p.telefono.numero)
        if p.correo:
            sub(el, "CorreoElectronico", p.correo)
        return el
    if es_emisor and not p.ubicacion:
        raise ValueError("El emisor requiere ubicación")
    if p.ubicacion:
        u = sub(el, "Ubicacion")
        sub(u, "Provincia", p.ubicacion.provincia)
        sub(u, "Canton", f"{p.ubicacion.canton:02d}")
        sub(u, "Distrito", f"{p.ubicacion.distrito:02d}")
        if p.ubicacion.barrio:
            sub(u, "Barrio", p.ubicacion.barrio)
        sub(u, "OtrasSenas", p.ubicacion.otras_senas)
    if p.telefono:
        t = sub(el, "Telefono")
        sub(t, "CodigoPais", p.telefono.codigo_pais)
        sub(t, "NumTelefono", p.telefono.numero)
    if p.correo:
        sub(el, "CorreoElectronico", p.correo)
    elif es_emisor:
        raise ValueError("El emisor requiere correo electrónico")
    return el


def construir_xml(comp: Comprobante) -> etree._Element:
    raiz_nombre, sufijo = TIPOS_DOCUMENTO[comp.tipo_documento]
    ns = NS_BASE + sufijo
    root = etree.Element(f"{{{ns}}}{raiz_nombre}", nsmap={None: ns, "xsd": XSD, "xsi": XSI})
    sub = _Nodo(ns)
    r = calcular(comp)

    fec, fee = comp.tipo_documento == "08", comp.tipo_documento == "09"
    sub(root, "Clave", comp.clave)
    sub(root, "ProveedorSistemas", comp.proveedor_sistemas)
    if comp.emisor.actividad or not fec:          # en la factura de compra el emisor (proveedor) puede no tener actividad inscrita
        sub(root, "CodigoActividadEmisor", comp.emisor.actividad)
    if fec:                                       # obligatoria: actividad del receptor (la empresa que emite la FEC)
        if not (comp.receptor and comp.receptor.actividad):
            raise ValueError("La factura de compra requiere la actividad económica de la empresa (receptor)")
        sub(root, "CodigoActividadReceptor", comp.receptor.actividad)
    elif comp.receptor and comp.receptor.actividad and comp.tipo_documento not in ("04", "09"):
        # el tiquete y la factura de exportación no tienen ese campo en su esquema (con él, Hacienda rechazaba el tiquete)
        sub(root, "CodigoActividadReceptor", comp.receptor.actividad)
    sub(root, "NumeroConsecutivo", comp.consecutivo)
    sub(root, "FechaEmision", comp.fecha_emision)
    _parte(sub, root, "Emisor", comp.emisor, not fec)
    if comp.receptor:
        _parte(sub, root, "Receptor", comp.receptor, False, exportacion=fee)
    elif comp.tipo_documento not in ("04", "09", "02", "03"):   # NC/ND de un tiquete sin receptor: el XSD lo permite (R76)
        raise ValueError("Solo el tiquete, la factura de exportación y las notas de un tiquete pueden omitir el receptor")
    sub(root, "CondicionVenta", comp.condicion_venta)
    if comp.condicion_venta == "99":
        if not comp.condicion_venta_otros:
            raise ValueError("Con la condición de venta 99 (Otros) indique cuál es (de 5 a 100 caracteres)")
        sub(root, "CondicionVentaOtros", comp.condicion_venta_otros)
    if comp.condicion_venta in ("02", "08", "10"):   # toda venta a crédito lleva plazo (también Estado a crédito e IVA diferido)
        sub(root, "PlazoCredito", comp.plazo_credito or 30)

    detalle = sub(root, "DetalleServicio")
    for n, lc in enumerate(r.lineas, start=1):
        l = lc.linea
        ld = sub(detalle, "LineaDetalle")
        sub(ld, "NumeroLinea", n)
        if l.partida_arancelaria and comp.tipo_documento in ("09", "02", "03"):   # FEE y sus notas: partida antes del CABYS (R86)
            sub(ld, "PartidaArancelaria", l.partida_arancelaria)
        sub(ld, "CodigoCABYS", l.cabys)
        if l.codigo_comercial:
            cc = sub(ld, "CodigoComercial")
            sub(cc, "Tipo", "01")
            sub(cc, "Codigo", l.codigo_comercial)
        sub(ld, "Cantidad", f"{l.cantidad:.3f}")
        sub(ld, "UnidadMedida", l.unidad_medida)
        sub(ld, "Detalle", l.detalle)
        sub(ld, "PrecioUnitario", _d(l.precio_unitario))
        sub(ld, "MontoTotal", _d(lc.monto_total))
        for d in l.descuentos:
            de = sub(ld, "Descuento")
            sub(de, "MontoDescuento", _d(d.monto))
            sub(de, "CodigoDescuento", d.codigo)
            if d.codigo == "99":
                if not d.codigo_otro:
                    raise ValueError("Con el código de descuento 99 (Otros) indique cuál es (de 5 a 100 caracteres)")
                sub(de, "CodigoDescuentoOTRO", d.codigo_otro)
            sub(de, "NaturalezaDescuento", d.naturaleza or CODIGOS_DESCUENTO.get(d.codigo, "Descuento"))   # obligatoria si hay descuento
        sub(ld, "SubTotal", _d(lc.subtotal))
        if not fee:                               # la factura de exportación no lleva BaseImponible ni ImpuestoNeto
            sub(ld, "BaseImponible", _d(lc.base_imponible))
        for i in lc.impuestos:
            ie = sub(ld, "Impuesto")
            sub(ie, "Codigo", i.codigo)
            if i.codigo == "01":
                sub(ie, "CodigoTarifaIVA", i.codigo_tarifa)
            if i.tarifa is not None:
                sub(ie, "Tarifa", f"{i.tarifa:.2f}")
            if i.especifico is not None and (fec or fee):
                raise ValueError("La factura de compra y la de exportación no admiten impuestos específicos (combustibles, bebidas, tabaco)")
            if i.especifico is not None:          # 03, 04, 05, 06: orden del XSD (3.41)
                es = i.especifico
                de = sub(ie, "DatosImpuestoEspecifico")
                sub(de, "CantidadUnidadMedida", f"{i.cantidad_unidad:.2f}")
                if i.codigo == "04":
                    sub(de, "Porcentaje", f"{es.porcentaje:.2f}")
                    sub(de, "Proporcion", f"{i.proporcion:.5f}")
                if i.codigo == "05":
                    sub(de, "VolumenUnidadConsumo", f"{es.volumen_unidad:.2f}")
                sub(de, "ImpuestoUnidad", _d(es.impuesto_unidad))
            sub(ie, "Monto", _d(i.monto))
            if i.exoneracion is not None and not (fee or fec):
                x = i.exoneracion
                ex = sub(ie, "Exoneracion")
                sub(ex, "TipoDocumentoEX1", x.tipo)
                if x.tipo == "99":
                    sub(ex, "TipoDocumentoOTRO", x.tipo_otro)
                sub(ex, "NumeroDocumento", x.numero)
                if x.articulo is not None:
                    sub(ex, "Articulo", x.articulo)
                if x.inciso is not None:
                    sub(ex, "Inciso", x.inciso)
                sub(ex, "NombreInstitucion", x.institucion)
                if x.institucion == "99":
                    sub(ex, "NombreInstitucionOtros", x.institucion_otro)
                sub(ex, "FechaEmisionEX", x.fecha_emision)
                sub(ex, "TarifaExonerada", f"{min(x.tarifa, i.tarifa):.2f}")
                sub(ex, "MontoExoneracion", _d(i.monto_exonerado))
        if not (fec or fee):                      # solo FE/TE/NC/ND llevan ImpuestoAsumidoEmisorFabrica
            sub(ld, "ImpuestoAsumidoEmisorFabrica", _d(0))
        if not fee:
            sub(ld, "ImpuestoNeto", _d(lc.impuesto_neto))
        sub(ld, "MontoTotalLinea", _d(lc.monto_total_linea))

    for oc in comp.otros_cargos:                   # después del detalle y antes del resumen (orden del XSD)
        oce = sub(root, "OtrosCargos")
        sub(oce, "TipoDocumentoOC", oc.tipo)
        if oc.tipo == "99":
            sub(oce, "TipoDocumentoOTROS", oc.tipo_otro.strip())
        sub(oce, "Detalle", oc.detalle)
        if oc.porcentaje is not None:
            sub(oce, "PorcentajeOC", f"{oc.porcentaje:.2f}")
        sub(oce, "MontoCargo", _d(oc.monto))

    res = sub(root, "ResumenFactura")
    mon = sub(res, "CodigoTipoMoneda")
    sub(mon, "CodigoMoneda", comp.moneda)
    sub(mon, "TipoCambio", _d(comp.tipo_cambio))
    sub(res, "TotalServGravados", _d(r.total_serv_gravados))
    sub(res, "TotalServExentos", _d(r.total_serv_exentos))
    if r.total_serv_exonerado and not fee:
        sub(res, "TotalServExonerado", _d(r.total_serv_exonerado))
    sub(res, "TotalMercanciasGravadas", _d(r.total_merc_gravadas))
    sub(res, "TotalMercanciasExentas", _d(r.total_merc_exentas))
    if r.total_merc_exonerada and not fee:
        sub(res, "TotalMercExonerada", _d(r.total_merc_exonerada))
    sub(res, "TotalGravado", _d(r.total_gravado))
    sub(res, "TotalExento", _d(r.total_exento))
    if r.total_exonerado and not fee:
        sub(res, "TotalExonerado", _d(r.total_exonerado))
    sub(res, "TotalVenta", _d(r.total_venta))
    sub(res, "TotalDescuentos", _d(r.total_descuentos))
    sub(res, "TotalVentaNeta", _d(r.total_venta_neta))
    for (codigo, tarifa), monto in r.desglose_impuesto.items():
        di = sub(res, "TotalDesgloseImpuesto")
        sub(di, "Codigo", codigo)
        if tarifa:                                 # solo el IVA lleva código de tarifa (3.41)
            sub(di, "CodigoTarifaIVA", tarifa)
        sub(di, "TotalMontoImpuesto", _d(monto))
    sub(res, "TotalImpuesto", _d(r.total_impuesto))
    if comp.otros_cargos:
        sub(res, "TotalOtrosCargos", _d(r.total_otros_cargos))
    for mp in comp.medios_pago:
        mpe = sub(res, "MedioPago")
        sub(mpe, "TipoMedioPago", mp.tipo)
        if mp.tipo == "99":
            if not mp.otros:
                raise ValueError("Con el medio de pago 99 (Otros) indique cuál es (de 3 a 100 caracteres)")
            sub(mpe, "MedioPagoOtros", mp.otros)
        sub(mpe, "TotalMedioPago", _d(mp.total if mp.total is not None else r.total_comprobante))
    sub(res, "TotalComprobante", _d(r.total_comprobante))

    if comp.tipo_documento in ("02", "03") and not comp.referencias:
        raise ValueError("Las notas de crédito/débito requieren documento de referencia")
    if fec and not comp.referencias:
        raise ValueError("La factura de compra requiere la referencia al documento del proveedor (tipo 14 u otro)")
    for ref in comp.referencias:
        ir = sub(root, "InformacionReferencia")
        sub(ir, "TipoDocIR", ref.tipo_doc)
        if ref.tipo_doc == "99":
            sub(ir, "TipoDocRefOTRO", ref.tipo_doc_otro.strip())
        sub(ir, "Numero", ref.numero)
        sub(ir, "FechaEmisionIR", ref.fecha_emision)
        sub(ir, "Codigo", ref.codigo)
        if ref.codigo == "99":                       # Hacienda rechaza (-491) el código 99 sin esta descripción
            sub(ir, "CodigoReferenciaOTRO", ref.codigo_otro.strip())
        sub(ir, "Razon", ref.razon)

    if comp.otro_texto:
        otros = sub(root, "Otros")
        sub(otros, "OtroTexto", comp.otro_texto)
    return root


def a_bytes(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")
