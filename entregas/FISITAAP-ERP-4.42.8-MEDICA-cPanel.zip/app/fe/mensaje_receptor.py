"""Mensaje de receptor (aceptación / aceptación parcial / rechazo) de comprobantes recibidos."""
from decimal import Decimal

from lxml import etree

from ..config import NS_BASE

NS = NS_BASE + "mensajeReceptor"


def construir_mensaje_receptor(
    clave_documento: str,
    cedula_emisor: str,
    fecha: str,
    mensaje: int,                 # 1 aceptado, 2 aceptado parcialmente, 3 rechazado
    total_factura: Decimal,
    cedula_receptor: str,
    consecutivo_receptor: str,
    monto_total_impuesto: Decimal | None = None,
    detalle: str | None = None,
    codigo_actividad: str | None = None,
    condicion_impuesto: str | None = None,   # 01 crédito total, 02 parcial, 03 bienes de capital, 04 gasto, 05 proporcionalidad
    monto_impuesto_acreditar: Decimal | None = None,
    monto_gasto_aplicable: Decimal | None = None,
) -> etree._Element:
    root = etree.Element(f"{{{NS}}}MensajeReceptor", nsmap={None: NS})

    def sub(tag, text):
        el = etree.SubElement(root, f"{{{NS}}}{tag}")
        el.text = str(text)

    sub("Clave", clave_documento)
    sub("NumeroCedulaEmisor", cedula_emisor)
    sub("FechaEmisionDoc", fecha)
    sub("Mensaje", mensaje)
    if detalle:
        sub("DetalleMensaje", detalle[:160])
    if monto_total_impuesto is not None:
        sub("MontoTotalImpuesto", f"{monto_total_impuesto:.5f}")
    if codigo_actividad:
        sub("CodigoActividad", codigo_actividad)
    if condicion_impuesto:
        sub("CondicionImpuesto", condicion_impuesto)
    if monto_impuesto_acreditar is not None:
        sub("MontoTotalImpuestoAcreditar", f"{monto_impuesto_acreditar:.5f}")
    if monto_gasto_aplicable is not None:
        sub("MontoTotalDeGastoAplicable", f"{monto_gasto_aplicable:.5f}")
    sub("TotalFactura", f"{total_factura:.5f}")
    sub("NumeroCedulaReceptor", cedula_receptor)
    sub("NumeroConsecutivoReceptor", consecutivo_receptor)
    return root
