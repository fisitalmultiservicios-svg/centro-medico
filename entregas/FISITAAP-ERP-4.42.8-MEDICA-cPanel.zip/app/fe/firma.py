"""Firma XAdES-EPES (RSA-SHA256) con la llave criptográfica (.p12) emitida por Hacienda."""
import base64
import logging

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import pkcs12
from lxml import etree
# 3.87: signxml se importa al firmar o verificar (no al arrancar el servidor: ~0,08 s)

from ..config import POLITICA_FIRMA_DESCRIPCION, POLITICA_FIRMA_HASH, POLITICA_FIRMA_URL

log = logging.getLogger(__name__)


def cargar_p12(p12_bytes: bytes, pin: str, verificar_vigencia: bool = True):
    key, cert, _extra = pkcs12.load_key_and_certificates(p12_bytes, pin.encode())
    if key is None or cert is None:
        raise ValueError("El archivo .p12 no contiene llave privada y certificado")
    if verificar_vigencia:
        from datetime import datetime, timezone
        if cert.not_valid_after_utc < datetime.now(timezone.utc):
            raise ValueError(f"La llave criptográfica venció el {cert.not_valid_after_utc:%d/%m/%Y}; genere una nueva en "
                             f"TRIBU-CR (bloque Tico Factura) y cárguela en Configuración › Facturación electrónica")
    return key, cert


def cedula_del_certificado(cert) -> str | None:
    """Cédula del titular según el certificado de Hacienda (atributo serialNumber del sujeto, p. ej. CPJ-3-101-123456).
    Devuelve solo los dígitos, o None si el certificado no la trae."""
    from cryptography.x509.oid import NameOID
    try:
        sn = next((a.value for a in cert.subject.get_attributes_for_oid(NameOID.SERIAL_NUMBER)), "")
    except Exception:  # noqa: BLE001
        return None
    digitos = "".join(ch for ch in str(sn) if ch.isdigit())
    return digitos or None


def misma_cedula(a: str | None, b: str | None) -> bool:
    """Compara dos cédulas por sus dígitos sin ceros a la izquierda: el certificado de una persona física trae la cédula con
    un cero inicial (CPF-01-1234-5678 → 0112345678) y la empresa la guarda con 9 dígitos (112345678)."""
    da = "".join(ch for ch in str(a or "") if ch.isdigit()).lstrip("0")
    db = "".join(ch for ch in str(b or "") if ch.isdigit()).lstrip("0")
    return bool(da) and da == db


def _politica() -> "XAdESSignaturePolicy | None":  # noqa: F821
    from signxml import DigestAlgorithm
    from signxml.xades import XAdESSignaturePolicy
    if not POLITICA_FIRMA_HASH:
        log.warning("FE_POLITICA_HASH no configurado: la firma se generará sin SignaturePolicyIdentifier "
                    "(XAdES-BES). Hacienda exige XAdES-EPES; ejecuta tools/politica_firma.py")
        return None
    return XAdESSignaturePolicy(
        Identifier=POLITICA_FIRMA_URL,
        Description=POLITICA_FIRMA_DESCRIPCION,
        DigestMethod=DigestAlgorithm.SHA256,
        DigestValue=POLITICA_FIRMA_HASH,
    )


def firmar(root: etree._Element, p12_bytes: bytes, pin: str) -> etree._Element:
    from signxml import DigestAlgorithm, SignatureMethod, methods
    from signxml.xades import XAdESDataObjectFormat, XAdESSigner
    key, cert = cargar_p12(p12_bytes, pin)
    cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode()
    signer = XAdESSigner(
        signature_policy=_politica(),
        data_object_format=XAdESDataObjectFormat(Description="Comprobante electrónico", MimeType="text/xml"),
        method=methods.enveloped,
        signature_algorithm=SignatureMethod.RSA_SHA256,
        digest_algorithm=DigestAlgorithm.SHA256,
    )
    return signer.sign(root, key=key, cert=[cert_pem])


def verificar(xml_bytes: bytes) -> bool:
    """Verifica la firma de un XML firmado (p.ej. recibido de un proveedor)."""
    from signxml.xades import XAdESVerifier
    root = etree.fromstring(xml_bytes)
    sig = root.find("{http://www.w3.org/2000/09/xmldsig#}Signature")
    if sig is None:
        return False
    cert_b64 = "".join(sig.findtext(".//{http://www.w3.org/2000/09/xmldsig#}X509Certificate").split())
    cert = x509.load_der_x509_certificate(base64.b64decode(cert_b64))
    # Algunos proveedores emiten un ds:KeyValue inconsistente con el certificado; se valida solo con X509Data.
    XAdESVerifier().verify(root, x509_cert=cert, expect_references=3, expect_signature_policy=None,
                           ignore_ambiguous_key_info=True)
    return True
