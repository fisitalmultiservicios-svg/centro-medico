# -*- coding: utf-8 -*-
"""4.30 · Extras y opcionales: que las asignaciones a productos y categorías no se pierdan, y recuperar las ya perdidas.

Hasta la 4.29, «Guardar modificadores» en Punto de venta › Configuración volvía a escribir cada grupo de pos_modificadores solo con
id, nombre, mínimo, máximo, activo y opciones, y así borraba lo que FISITAAP › Extras y Opcionales guarda en el mismo grupo:
`productos`, `categorias`, `tipo` y `fis` (fisitaap._guardar_extra / _guardar_opcional). Desde ese guardado ni la caja
(pos/caja.js gruposDe) ni el catálogo en línea (promociones.grupos_de_producto) preguntaban esos extras.

1) El servidor protege (reponer_asignaciones / reponer_en_lista; main._revisar_escritura los llama solo para pos_modificadores,
   por el PUT del registro completo y por /cambios): un grupo que llega SIN alguna de esas claves conserva la que tenía guardada el
   grupo con el mismo id. Una clave que sí llega (aunque sea una lista vacía) se respeta, un grupo nuevo queda como llega y un
   grupo que se borra se borra. Así una pantalla vieja en el caché del navegador o un programa de escritorio anterior ya no borran.

2) Recuperar lo ya perdido desde los respaldos, sin restaurarlos:
   - Se leen los respaldos generales diarios (respaldo.RESPALDOS_DIR/facturacr_*.zip; se conservan respaldo.CONSERVAR, 14 por
     omisión, uno por día) y los que la propia empresa creó en Configuración › Respaldos (respaldo.dir_empresa; hasta
     respaldo.MAXIMO_EMPRESA, 10). De cada zip se descomprime SOLO la base de la empresa (data/empresas/empresa_<id>.db) a una
     carpeta temporal y se lee con sqlite3 en modo de solo lectura el registro pos_modificadores; no se toca nada más del zip.
   - Acotado: como mucho TOPE_RESPALDOS zips (30), TOPE_SEGUNDOS de trabajo por petición (8) y bases de hasta TOPE_BYTES (400 MB); lo
     leído se guarda en memoria por zip (nombre, tamaño y fecha) para que abrir la pantalla otra vez no vuelva a descomprimir. Si se acaba
     el tiempo no se propone nada esa vez («incompleta»); la próxima vez sigue donde quedó, porque lo ya leído está en memoria. Un zip que
     no alcanza a leerse ni con todo el tiempo de una petición queda anotado como no leído y no se reintenta en cada petición (H5).
   - Antes de abrir un respaldo se mira lo de hoy: si ningún grupo vigente perdió alguna de esas claves, no se lee ningún respaldo; si lo
     pendiente es lo mismo que en la última revisión completa sin nada que ofrecer (por ejemplo, grupos creados en Punto de venta, que
     nunca tienen esas claves), tampoco (H5).
   - propuesta(): del respaldo más nuevo al más viejo se decide cada grupo que hoy existe (mismo id) y perdió claves: el primer respaldo
     donde el grupo tiene alguna de ellas decide, con lo que tenía, aunque sea una lista vacía (H2); si el grupo no está en un respaldo
     se creó después y no se busca más atrás; un respaldo que no se puede leer corta la búsqueda. Se propone el primer respaldo donde algún
     grupo recupera algo que se nota (productos, categorías o tipo). Repone SOLO esas claves en SOLO esos grupos: nunca pisa una clave
     que el grupo tiene hoy, no revive grupos borrados y descarta los productos y las categorías que ya no existen.
   - GET /api/pos/modificadores/recuperar: la propuesta ({"hay": false} si no hay nada o si el usuario no puede configurar; en el
     programa de escritorio conectado a la web, además, «en_la_web» y la línea que manda a recuperar en la página web: H6).
   - POST /api/pos/modificadores/recuperar {"respaldo": nombre}: vuelve a calcular la propuesta (no confía en lo que manda el navegador)
     y, si sigue siendo de ese respaldo, la aplica con la versión del registro tomada antes de leer (H4) y deja auditoría. Permiso
     «configurar», el mismo del botón «Guardar modificadores». En el programa conectado a la web responde 409 (H6).
"""
import json
import os
import re
import sqlite3
import tempfile
import threading
import time
import zipfile
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlmodel import Session, select

from . import modulos, respaldo
from .auth import Contexto, contexto, requiere, sesion_empresa

router = APIRouter(tags=["pos"])

CLAVE = "pos_modificadores"
CAMPOS_ASIGNACION = ("productos", "categorias", "tipo", "fis")     # lo que FISITAAP guarda en el grupo y la pantalla del punto de venta no edita
TOPE_RESPALDOS = int(os.environ.get("FE_RECUPERAR_MODS_RESPALDOS", "30"))
TOPE_SEGUNDOS = float(os.environ.get("FE_RECUPERAR_MODS_SEGUNDOS", "8"))
TOPE_BYTES = int(os.environ.get("FE_RECUPERAR_MODS_BYTES", str(400 * 1024 * 1024)))
_RE_FECHA = re.compile(r"_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})")
_cache: dict = {}
_cache_lock = threading.Lock()
# H5: {empresa: lo pendiente (ids y claves que faltan)} de la última revisión completa que no encontró nada que ofrecer. Mientras lo pendiente
# sea lo mismo no se vuelven a revisar los respaldos: desde la 4.30 nada borra esas claves (main._revisar_escritura las repone), así que un
# respaldo más nuevo no trae nada distinto para esos grupos. Si cambia (un grupo nuevo, otro dañado, uno recuperado), se revisa otra vez.
_revisado: dict = {}


# --------------------------------------------------------------------------------------------- 1) el servidor protege
def _id(x) -> Optional[int]:
    return modulos._id_entero(x.get("id")) if isinstance(x, dict) else None


def reponer_asignaciones(guardado, nuevo):
    """El grupo que llega, con las claves de asignación que NO trae tomadas del grupo guardado con el mismo id."""
    if not isinstance(guardado, dict) or not isinstance(nuevo, dict):
        return nuevo
    faltan = [k for k in CAMPOS_ASIGNACION if k not in nuevo and k in guardado]
    return {**nuevo, **{k: guardado[k] for k in faltan}} if faltan else nuevo


def reponer_en_lista(guardados, datos):
    """PUT del registro completo: cada grupo que ya existía conserva lo que no trae; los nuevos quedan como llegan."""
    if not isinstance(datos, list) or not isinstance(guardados, list):
        return datos
    previos = {_id(g): g for g in guardados if isinstance(g, dict) and _id(g) is not None}
    return [reponer_asignaciones(previos.get(_id(x)), x) if isinstance(x, dict) else x for x in datos]


def reponer_en_upserts(previos: dict, upserts: list, nuevos) -> list:
    """/cambios: `previos` {id: grupo guardado}; un alta (id en `nuevos`) no toma nada (si su id ya existía recibe otro)."""
    altas = {modulos._id_entero(i) for i in (nuevos or [])}
    return [x if not isinstance(x, dict) or _id(x) in altas else reponer_asignaciones(previos.get(_id(x)), x) for x in (upserts or [])]


# --------------------------------------------------------------------------------------------- 2) leer los respaldos
def _fecha_de(nombre: str) -> Optional[str]:
    m = _RE_FECHA.search(nombre or "")
    return "".join(m.groups()) if m else None


def _respaldos(eid: int) -> list[dict]:
    """Respaldos que pueden traer la base de la empresa, del más nuevo al más viejo: los generales diarios y los de la empresa."""
    out = []
    base = Path(respaldo.RESPALDOS_DIR)
    try:
        for p in base.glob("facturacr_*.zip"):
            if re.fullmatch(respaldo.PATRON_GLOBAL, p.name) and p.is_file():
                out.append({"ruta": p, "nombre": p.name, "origen": "general", "orden": _fecha_de(p.name) or ""})
    except OSError:
        pass
    try:
        for p in respaldo.dir_empresa(eid).glob(f"empresa_{int(eid)}_*.zip"):
            if re.fullmatch(respaldo.PATRON_EMPRESA, p.name) and p.is_file():
                out.append({"ruta": p, "nombre": p.name, "origen": "empresa", "orden": _fecha_de(p.name) or ""})
    except OSError:
        pass
    out.sort(key=lambda r: (r["orden"], r["nombre"]), reverse=True)
    return out[:max(0, TOPE_RESPALDOS)]


class _SinTiempo(Exception):
    pass


def _leer_base(ruta: Path, eid: int):
    """La lista pos_modificadores de la empresa guardada en esa base (None si no la tiene o no se puede leer)."""
    con = sqlite3.connect(f"file:{ruta.as_posix()}?mode=ro", uri=True, timeout=5)
    try:
        fila = con.execute("SELECT coleccion, datos FROM registro WHERE empresa_id = ? AND clave = ? ORDER BY id LIMIT 1", (int(eid), CLAVE)).fetchone()
        if not fila:
            return None
        if fila[0]:
            out = []
            for (d,) in con.execute("SELECT datos FROM registroitem WHERE empresa_id = ? AND clave = ? ORDER BY orden, item_id", (int(eid), CLAVE)):
                try:
                    out.append(json.loads(d))
                except (TypeError, ValueError):
                    continue
            return out
        try:
            v = json.loads(fila[1])
        except (TypeError, ValueError):
            return None
        return v if isinstance(v, list) else None
    finally:
        con.close()


def _descomprimir(z: zipfile.ZipFile, info: zipfile.ZipInfo, destino: Path, hasta: float) -> None:
    """Copia la base de la empresa del zip a `destino` de a 1 MB; _SinTiempo si se acaba el tiempo de la petición."""
    with z.open(info) as src, open(destino, "wb") as dst:
        while True:
            if time.monotonic() >= hasta:
                raise _SinTiempo()
            trozo = src.read(1024 * 1024)
            if not trozo:
                break
            dst.write(trozo)


def _grupos_del_respaldo(r: dict, eid: int, hasta: float, leidos: Optional[list] = None):
    """pos_modificadores de la empresa en ese respaldo; None si el zip no trae su base, es muy grande o no se puede leer.
    H5: `leidos` son los zips que esta petición ya descomprimió. Si se acaba el tiempo con uno que empezó con el tiempo completo (el primero
    que se descomprime en la petición), queda anotado en la caché como no leído y no se reintenta en cada petición; si otro zip gastó el
    tiempo antes, no se anota: la próxima petición empieza por este (los anteriores ya están en la caché)."""
    ruta: Path = r["ruta"]
    try:
        st = ruta.stat()
    except OSError:
        return None
    llave = (str(ruta), st.st_size, st.st_mtime_ns, int(eid))
    with _cache_lock:
        if llave in _cache:
            return _cache[llave]
    leidos = [] if leidos is None else leidos
    primero = not leidos
    leidos.append(r.get("nombre"))
    resultado = None
    try:
        with zipfile.ZipFile(ruta) as z:
            try:
                info = z.getinfo(f"data/empresas/empresa_{int(eid)}.db")      # el de otra instalación trae otro número: no sirve
            except KeyError:
                info = None
            if info is not None and info.file_size <= TOPE_BYTES:
                with tempfile.TemporaryDirectory(prefix="fisitaap_mods_") as tmp:
                    destino = Path(tmp) / "empresa.db"
                    _descomprimir(z, info, destino, hasta)
                    resultado = _leer_base(destino, eid)
    except _SinTiempo:
        if not primero:
            raise
        resultado = None
    except (OSError, zipfile.BadZipFile, sqlite3.Error, RuntimeError, ValueError):
        resultado = None
    with _cache_lock:
        if len(_cache) > 2000:
            _cache.clear()
        _cache[llave] = resultado
    return resultado


def _existentes(s: Session, eid: int) -> tuple[dict, set]:
    """{id: nombre} de los productos de la empresa y los textos de categoría que existen (en algún ítem o en Inventario › Categorías)."""
    from .db import Producto
    prods, cats = {}, set()
    for p in s.exec(select(Producto).where(Producto.empresa_id == eid)).all():
        prods[int(p.id)] = p.nombre or ""
        if (p.categoria or "").strip():
            cats.add(p.categoria)
            cats.add(p.categoria.strip())
    for c in modulos.leer(s, eid, "categorias", []) or []:
        if isinstance(c, dict) and str(c.get("nombre") or "").strip():
            cats.add(str(c["nombre"]))
            cats.add(str(c["nombre"]).strip())
    return prods, cats


def _faltantes(actual: dict) -> list:
    return [k for k in CAMPOS_ASIGNACION if k not in actual]


def _comparar(actuales: dict, del_respaldo: list, prods: dict, cats: set, pendientes: dict) -> list[dict]:
    """Decide con un respaldo los grupos que hoy existen y perdieron claves (`pendientes`: {id: [claves que le faltan]}; el grupo que se
    decide sale de ahí y no se busca en respaldos más viejos). Grupos borrados hoy no están en `pendientes`: no se reviven.
    - El grupo no está en el respaldo: se creó después, y el que tuvo ese id en un respaldo más viejo era otro: no se repone nada.
    - Está, pero sin ninguna de esas claves (ya dañado, o creado en Punto de venta): queda pendiente para el respaldo anterior.
    - Tiene alguna (H2): se repone lo que tenía en ESAS claves aunque la lista quede vacía (FISITAAP siempre guarda las cuatro: una lista
      vacía es una decisión del dueño), sin los productos ni las categorías que ya no existen."""
    por_id = {_id(g): g for g in (del_respaldo or []) if isinstance(g, dict) and _id(g) is not None}
    out = []
    for gid in list(pendientes):
        g = por_id.get(gid)
        if g is None:
            del pendientes[gid]
            continue
        claves = [k for k in pendientes[gid] if k in g]
        if not claves:
            continue
        del pendientes[gid]
        reponer = {}
        for k in claves:
            v = g[k]
            if k == "productos":
                ids = []
                for x in (v if isinstance(v, list) else []):
                    i = modulos._id_entero(x)
                    if i is not None and i in prods and i not in ids:
                        ids.append(i)
                reponer[k] = ids
            elif k == "categorias":
                l = []
                for c in (v if isinstance(v, list) else []):
                    c = str(c)
                    if c.strip() and c in cats and c not in l:
                        l.append(c)
                reponer[k] = l
            elif k == "tipo":
                if v in ("extra", "opcional"):
                    reponer[k] = v
            elif k == "fis":
                reponer[k] = v is True
        if reponer:
            actual = actuales.get(gid) or {}
            out.append({"id": gid, "nombre": actual.get("nombre") or g.get("nombre") or "", "reponer": reponer})
    return out


def _algo_que_reponer(reponer: dict) -> bool:
    """H2: el aviso cuenta solo los grupos que recuperan algo que se nota: productos, categorías o su tipo (extra u opcional)."""
    return bool(reponer.get("productos") or reponer.get("categorias") or reponer.get("tipo"))


def _actuales(s: Session, eid: int) -> dict:
    return {_id(g): g for g in (modulos.leer(s, eid, CLAVE, []) or []) if isinstance(g, dict) and _id(g) is not None}


def _fecha_texto(nombre: str) -> str:
    f = _fecha_de(nombre)
    return f"{f[6:8]}/{f[4:6]}/{f[0:4]}" if f else ""


def _publica(p: dict) -> dict:
    """La propuesta sin lo interno (las claves que empiezan con «_»)."""
    return {k: v for k, v in p.items() if not k.startswith("_")}


def propuesta(s: Session, eid: int, solo: Optional[str] = None, segundos: Optional[float] = None) -> dict:
    """{"hay", "respaldo", "fecha", "grupos": [{id, nombre, reponer, productos_nombres}], "incompleta"} y, interno, "_aplicar".
    Del respaldo más nuevo al más viejo se decide cada grupo pendiente (_comparar); se propone el primer respaldo donde algún grupo
    recupera algo que se nota (H2): "grupos" son esos y "_aplicar" todo lo decidido con ese respaldo (también las listas vacías).
    Un respaldo que no se puede leer corta la búsqueda: lo que no se decidió hasta ahí no se busca en respaldos más viejos, que podrían
    traer asignaciones que el dueño ya cambió. `solo` (el POST): la propuesta de este momento tiene que ser de ese respaldo."""
    actuales = _actuales(s, eid)
    vacia = {"hay": False, "grupos": [], "incompleta": False}
    pendientes = {gid: _faltantes(g) for gid, g in actuales.items() if _faltantes(g)}
    if not pendientes:
        return vacia                                         # nadie perdió nada: no se abre ningún respaldo
    firma = tuple(sorted((gid, tuple(ks)) for gid, ks in pendientes.items()))
    with _cache_lock:
        if _revisado.get(int(eid)) == firma:
            return vacia                                     # H5: lo mismo pendiente que en la última revisión completa: nada nuevo
    prods, cats = _existentes(s, eid)
    hasta = time.monotonic() + (TOPE_SEGUNDOS if segundos is None else segundos)
    respaldos, leidos = _respaldos(eid), []
    for r in respaldos:
        if not pendientes:
            break
        if time.monotonic() >= hasta:
            return {**vacia, "incompleta": True}
        try:
            grupos = _grupos_del_respaldo(r, eid, hasta, leidos)
        except _SinTiempo:
            return {**vacia, "incompleta": True}
        if grupos is None:
            break
        cambios = _comparar(actuales, grupos, prods, cats, pendientes)
        vistos = [c for c in cambios if _algo_que_reponer(c["reponer"])]
        if vistos:
            if solo is not None and r["nombre"] != solo:
                return vacia
            for c in vistos:
                c["productos_nombres"] = [prods.get(i, "") for i in c["reponer"].get("productos", [])]
            return {"hay": True, "respaldo": r["nombre"], "origen": r["origen"], "fecha": _fecha_texto(r["nombre"]), "grupos": vistos,
                    "incompleta": False, "_aplicar": cambios}
    if respaldos:                                            # revisión completa sin nada que ofrecer (sin respaldos no se anota)
        with _cache_lock:
            if len(_revisado) > 5000:
                _revisado.clear()
            _revisado[int(eid)] = firma
    return vacia


def aplicar(s: Session, eid: int, nombre: str) -> dict:
    """Repone lo propuesto con ese respaldo. Vuelve a comprobar contra lo de este momento: nunca pisa una clave que el grupo ya tiene.
    H4: el registro y su versión se toman ANTES de leer los grupos y esa versión va a reemplazar(): si otra persona guardó en medio (el
    POST puede tardar descomprimiendo), ConflictoRegistro (409) y no se pisa lo suyo."""
    reg = modulos._registro(s, eid, CLAVE)
    version = int(reg.version or 0) if reg is not None else None
    p = propuesta(s, eid, solo=nombre)
    if not p["hay"]:
        return _publica(p)
    por_id = {c["id"]: c["reponer"] for c in p["_aplicar"]}
    grupos = [g for g in (modulos.leer(s, eid, CLAVE, []) or [])]
    cambiados = set()
    for i, g in enumerate(grupos):
        rep = por_id.get(_id(g)) if isinstance(g, dict) else None
        if not rep:
            continue
        nuevo = {**g, **{k: v for k, v in rep.items() if k not in g}}
        if nuevo != g:
            grupos[i] = nuevo
            cambiados.add(_id(g))
    hechos = [c for c in p["grupos"] if c["id"] in cambiados]
    if hechos:
        modulos.reemplazar(s, eid, CLAVE, grupos, version)
        s.commit()
    return {**_publica(p), "grupos": hechos, "hay": bool(hechos)}


def _detalle_auditoria(p: dict) -> str:
    partes = []
    for c in p["grupos"]:
        r = c["reponer"]
        d = []
        if r.get("productos"):
            d.append(f"{len(r['productos'])} producto(s)")
        if r.get("categorias"):
            d.append("categorías " + ", ".join(r["categorias"]))
        if r.get("tipo"):
            d.append("tipo " + r["tipo"])
        partes.append(f"#{c['id']} {c['nombre']}" + (f" ({'; '.join(d)})" if d else ""))
    n = len(p["grupos"])
    return (f"{n} {'grupo recuperado' if n == 1 else 'grupos recuperados'} del respaldo del {p.get('fecha') or '?'} ({p.get('respaldo')}): " + ", ".join(partes))[:500]


EN_LA_WEB = ("Esta computadora está conectada a la página web: los extras y opcionales que perdieron sus productos y categorías se recuperan "
             "en la página web (Punto de venta › Configuración › Modificadores, o FISITAAP › Extras y Opcionales) y bajan solos al sincronizar.")


def _programa_conectado(s: Session, eid: int) -> bool:
    """H6: el programa de escritorio conectado a la página web (lo mismo que avisa Punto de venta › Configuración: vinculado y sin revocar).
    Ahí pos_modificadores baja de la web en cada sincronización (sinc.CLAVES_CATALOGO) y pisa lo que se recupere de los respaldos de esa
    computadora: no se ofrece ni se acepta recuperar; se hace en la página web."""
    from . import sinc
    if not sinc.MODO_LOCAL:
        return False
    cfg = sinc._cfg_local(s, eid)
    return bool(cfg.get("vinculado")) and not cfg.get("revocada_en")


@router.get("/api/pos/modificadores/recuperar")
def ver_recuperar(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Lo que se puede recuperar. A quien no puede configurar no se le muestra nada (ni se leen respaldos). En el programa conectado a la
    web (H6) tampoco: la respuesta trae en «aviso_web» la línea que manda a recuperar en la página web."""
    if not ctx.puede("configurar"):
        return {"hay": False, "grupos": [], "incompleta": False}
    if _programa_conectado(s, ctx.empresa.id):
        return {"hay": False, "grupos": [], "incompleta": False, "en_la_web": True, "aviso_web": EN_LA_WEB}
    return _publica(propuesta(s, ctx.empresa.id))


@router.post("/api/pos/modificadores/recuperar")
def hacer_recuperar(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    nombre = cuerpo.get("respaldo") if isinstance(cuerpo, dict) else None
    if not isinstance(nombre, str) or not (re.fullmatch(respaldo.PATRON_GLOBAL, nombre) or re.fullmatch(respaldo.PATRON_EMPRESA, nombre)):
        raise HTTPException(400, "Indique de qué respaldo recuperar: vuelva a abrir la pantalla e intente de nuevo.")
    if _programa_conectado(s, ctx.empresa.id):
        raise HTTPException(409, EN_LA_WEB)
    try:
        p = aplicar(s, ctx.empresa.id, nombre)
    except modulos.ConflictoRegistro:
        raise HTTPException(409, "Otra persona cambió los modificadores en este momento: vuelva a abrir la pantalla e intente de nuevo.")
    if not p["hay"]:
        raise HTTPException(409, "Ya no hay nada que recuperar de ese respaldo: vuelva a abrir la pantalla.")
    from .main import _auditar
    _auditar(ctx, "pos_modificadores_recuperados", _detalle_auditoria(p))
    return {"ok": True, "grupos": p["grupos"], "fecha": p.get("fecha"), "respaldo": p.get("respaldo")}
