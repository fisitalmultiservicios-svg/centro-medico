"""Operación clínica, coberturas y catálogo de FISITAAP Médica."""
import json
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, text
from sqlmodel import Field as Col, SQLModel, select

from . import auth, modulos, secretos
from .db import Cliente, Producto, por_empresa
from .medica import (Base, Central, Cita, CitaIn, Clinica, Nombre, Paciente,
                     Recepcion, _acceso, _ahora, _buscar, _cita_clinica, _evento,
                     _profesionales, _sede, router)
from .medica_config import CLINICA, ENFERMERIA, GESTION

Gestor = Annotated[auth.Contexto, Depends(_acceso(GESTION))]
Enfermeria = Annotated[auth.Contexto, Depends(_acceso(ENFERMERIA))]
EquipoClinico = Annotated[auth.Contexto, Depends(_acceso(CLINICA, ENFERMERIA))]
RegistroTipo = Literal["consultorio", "equipo", "tarea", "profesional", "aseguradora", "convenio", "campaña", "incidente"]


class Registro(SQLModel, table=True):
    __tablename__ = "medica_operacion"
    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    tipo: str = Col(index=True)
    nombre: str
    estado: str
    responsable_id: int | None = None
    especialidad: str = ""
    vinculo: str = ""
    contacto_id: int | None = None
    activo_id: str | None = None
    vence: date | None = None
    inicio_convenio: date | None = None
    ciclo_facturacion: str | None = None
    servicios_convenio: str = ""
    exclusiones_convenio: str = ""
    detalle: str = ""
    referencia: str = ""


class Bloqueo(SQLModel, table=True):
    __tablename__ = "medica_bloqueo"
    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    profesional_id: int | None = None
    consultorio: str | None = None
    inicio: datetime = Col(sa_type=DateTime)
    fin: datetime = Col(sa_type=DateTime)
    motivo: str


class Cobertura(SQLModel, table=True):
    __tablename__ = "medica_cobertura"
    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    paciente_id: int = Col(index=True)
    convenio_id: int
    vigencia_desde: date
    vigencia_hasta: date
    tipo: str
    datos: str
    copago: float = 0
    deducible: float = 0
    max_atenciones: int = 0
    activa: bool = True


class Validacion(SQLModel, table=True):
    __tablename__ = "medica_validacion"
    cita_id: int = Col(primary_key=True)
    cobertura_id: int = Col(index=True)
    estado: str
    producto_id: int | None = None
    fecha: datetime = Col(sa_type=DateTime)


class Nota(SQLModel, table=True):
    __tablename__ = "medica_nota"
    id: int | None = Col(default=None, primary_key=True)
    cita_id: int = Col(index=True)
    autor_id: int
    tipo: str
    contenido: str
    fecha: datetime = Col(sa_type=DateTime)


por_empresa(Registro, Bloqueo, Cobertura, Validacion, Nota)


def cifrar(empresa, data: dict) -> str:
    if not empresa.clave_cifrada:
        raise HTTPException(503, "Falta la clave de cifrado de esta empresa")
    return secretos.cifrar(empresa.clave_cifrada, json.dumps(data, ensure_ascii=False, default=str))


def leer(empresa, valor: str) -> dict:
    return json.loads(secretos.descifrar(empresa.clave_cifrada, valor)) if valor else {}


class RegistroIn(BaseModel):
    nombre: Nombre
    estado: Literal["activo", "inactivo", "pendiente", "en curso", "cerrado"] = "activo"
    responsable_id: int | None = None
    especialidad: str = Field(default="", max_length=140)
    vinculo: str = Field(default="", max_length=140)
    contacto_id: int | None = None
    activo_id: str | None = Field(default=None, max_length=100)
    vence: date | None = None
    inicio_convenio: date | None = None
    ciclo_facturacion: Literal["por evento", "mensual", "trimestral", "anual", "mixto"] | None = None
    servicios_convenio: str = Field(default="", max_length=2000)
    exclusiones_convenio: str = Field(default="", max_length=2000)
    detalle: str = Field(default="", max_length=4000)
    referencia: str = Field(default="", max_length=120)


def _activos_erp(s, ctx):
    if not ctx.puede("contabilidad"):
        return []
    registros = modulos.leer(s, ctx.empresa.id, "activos", [])
    if not isinstance(registros, list):
        return []
    return [{"id": str(a["id"]), "nombre": a.get("nombre") or str(a["id"])}
            for a in registros if isinstance(a, dict) and a.get("id") is not None and not a.get("fecha_baja")]


@router.get("/operacion-activos")
def activos_erp(ctx: Gestor, s: Base):
    return _activos_erp(s, ctx)


def _vinculo_activo(s, ctx, tipo, activo_id):
    if activo_id and (tipo != "equipo" or activo_id not in {a["id"] for a in _activos_erp(s, ctx)}):
        raise HTTPException(422, "Seleccione un activo vigente del ERP con acceso a Contabilidad")


@router.get("/operacion/{tipo}")
def listar(tipo: RegistroTipo, ctx: Gestor, s: Base):
    return s.exec(select(Registro).where(Registro.sede == _sede(ctx), Registro.tipo == tipo)
                  .order_by(Registro.nombre).limit(250)).all()


def _contacto(s, ctx, cliente_id):
    contacto = s.get(Cliente, cliente_id) if cliente_id else None
    if cliente_id and (not contacto or contacto.empresa_id != ctx.empresa.id or not contacto.activo or contacto.tipo == "Proveedor"):
        raise HTTPException(422, "Seleccione un contacto activo del ERP")
    return contacto


@router.get("/operacion-profesionales")
def profesionales_erp(ctx: Gestor, sc: Central):
    return _profesionales(ctx, sc)


def _nombre_profesional(tipo, ctx, central, datos):
    if tipo != "profesional":
        return
    usuario = next((u for u in _profesionales(ctx, central) if u["id"] == datos.responsable_id), None)
    if not usuario:
        raise HTTPException(422, "Seleccione un usuario de la empresa con permiso de consulta médica y verificación en dos pasos")
    datos.nombre = usuario["nombre"]


def _validar_convenio(tipo, data):
    if tipo == "convenio" and data.inicio_convenio and data.vence and data.vence < data.inicio_convenio:
        raise HTTPException(422, "El vencimiento del convenio debe ser posterior a su inicio")


@router.post("/operacion/{tipo}", status_code=201)
def crear(tipo: RegistroTipo, data: RegistroIn, ctx: Gestor, s: Base, sc: Central):
    _nombre_profesional(tipo, ctx, sc, data)
    _validar_convenio(tipo, data)
    _contacto(s, ctx, data.contacto_id)
    _vinculo_activo(s, ctx, tipo, data.activo_id)
    fila = Registro(sede=_sede(ctx), tipo=tipo, **data.model_dump())
    s.add(fila)
    s.flush()
    _evento(s, ctx, f"operacion.{tipo}.creada", fila.id)
    s.commit()
    s.refresh(fila)
    return fila


@router.put("/operacion/{tipo}/{identificador}")
def editar(tipo: RegistroTipo, identificador: int, data: RegistroIn, ctx: Gestor, s: Base, sc: Central):
    fila = _buscar(s, Registro, identificador, ctx)
    if fila.tipo != tipo:
        raise HTTPException(404, "Registro no disponible")
    _nombre_profesional(tipo, ctx, sc, data)
    _validar_convenio(tipo, data)
    _contacto(s, ctx, data.contacto_id)
    datos = data.model_dump()
    if "activo_id" not in data.model_fields_set or data.activo_id == fila.activo_id:
        datos.pop("activo_id")
    else:
        ctx.exigir("contabilidad")
        _vinculo_activo(s, ctx, tipo, data.activo_id)
    fila.sqlmodel_update(datos)
    _evento(s, ctx, f"operacion.{tipo}.editada", fila.id)
    s.commit()
    s.refresh(fila)
    return fila


class BloqueoIn(BaseModel):
    profesional_id: int | None = None
    consultorio: str | None = Field(default=None, max_length=160)
    inicio: datetime
    fin: datetime
    motivo: Nombre


def revisar_bloqueo(s, sede, profesional, sala, inicio, fin):
    bloqueo = s.exec(select(Bloqueo.id).where(
        Bloqueo.inicio < fin, Bloqueo.fin > inicio,
        (Bloqueo.profesional_id == profesional)
        | ((Bloqueo.sede == sede) & (Bloqueo.consultorio == sala)),
    )).first()
    if bloqueo:
        raise HTTPException(409, "El horario está bloqueado")


@router.get("/bloqueos")
def bloqueos(ctx: Recepcion, s: Base):
    return s.exec(select(Bloqueo).where(Bloqueo.sede == _sede(ctx), Bloqueo.fin >= _ahora())
                  .order_by(Bloqueo.inicio).limit(200)).all()


@router.post("/bloqueos", status_code=201)
def bloquear(data: BloqueoIn, ctx: Recepcion, s: Base, sc: Central):
    sala = (data.consultorio or "").strip().casefold() or None
    if data.inicio.tzinfo or data.fin.tzinfo or data.inicio >= data.fin or not (data.profesional_id or sala):
        raise HTTPException(422, "Indique un intervalo local y un profesional o consultorio")
    if data.profesional_id and data.profesional_id not in {p["id"] for p in _profesionales(ctx, sc)}:
        raise HTTPException(422, "Profesional no disponible")
    s.exec(text("BEGIN IMMEDIATE"))
    filtros = []
    if sala:
        filtros.append((Cita.sede == _sede(ctx)) & (Cita.consultorio == sala))
    if data.profesional_id:
        filtros.append(Cita.profesional_id == data.profesional_id)
    from sqlalchemy import or_
    existe = s.exec(select(Cita.id).where(
        Cita.estado.not_in(("cancelada", "no se presentó")),
        Cita.inicio < data.fin, Cita.fin > data.inicio, or_(*filtros)
    )).first()
    if existe:
        raise HTTPException(409, "Reprograme las citas afectadas antes de bloquear")
    fila = Bloqueo(sede=_sede(ctx), **{**data.model_dump(), "consultorio": sala})
    s.add(fila)
    s.flush()
    _evento(s, ctx, "agenda.bloqueada", fila.id)
    s.commit()
    s.refresh(fila)
    return fila


@router.delete("/bloqueos/{identificador}")
def desbloquear(identificador: int, ctx: Recepcion, s: Base):
    fila = _buscar(s, Bloqueo, identificador, ctx)
    s.delete(fila)
    _evento(s, ctx, "agenda.desbloqueada", identificador)
    s.commit()
    return {"ok": True}


class Reprogramacion(CitaIn):
    paciente_id: int = 0
    motivo: Nombre


@router.put("/agenda/{cita_id}/reprogramar")
def reprogramar(cita_id: int, data: Reprogramacion, ctx: Recepcion, s: Base, sc: Central):
    if data.profesional_id not in {p["id"] for p in _profesionales(ctx, sc)}:
        raise HTTPException(422, "Profesional no disponible")
    from .medica import nueva_cita

    s.exec(text("BEGIN IMMEDIATE"))
    anterior = _buscar(s, Cita, cita_id, ctx)
    if anterior.estado not in {"programada", "confirmada"}:
        raise HTTPException(409, "Esta cita no se puede reprogramar")
    anterior.estado = "cancelada"
    s.flush()
    reemplazo = nueva_cita(s, anterior.sede, data.model_copy(update={"paciente_id": anterior.paciente_id}))
    _evento(s, ctx, "cita.reprogramada", anterior.id)
    _evento(s, ctx, "cita.creada", reemplazo.id)
    s.commit()
    return {"id": reemplazo.id}


class FichaIn(BaseModel):
    cliente_id: int | None = None
    tipo: Literal["particular", "asegurado", "corporativo"] = "particular"
    direccion: str = Field(default="", max_length=300)
    emergencia: str = Field(default="", max_length=200)
    idioma: str = Field(default="", max_length=80)
    sexo: str = Field(default="", max_length=60)
    genero: str = Field(default="", max_length=60)
    nacionalidad: str = Field(default="", max_length=80)
    estado_civil: str = Field(default="", max_length=60)
    ocupacion: str = Field(default="", max_length=100)
    responsable_pago: str = Field(default="", max_length=180)
    observacion_administrativa: str = Field(default="", max_length=300)
    consentimiento_datos: bool = False
    consentimiento_contacto: bool = False


@router.get("/pacientes/{paciente_id}/ficha")
def ficha(paciente_id: int, ctx: Recepcion, s: Base):
    p = _buscar(s, Paciente, paciente_id, ctx)
    return {"cliente_id": p.cliente_id, **leer(ctx.empresa, p.datos_administrativos)}


@router.put("/pacientes/{paciente_id}/ficha")
def actualizar_ficha(paciente_id: int, data: FichaIn, ctx: Recepcion, s: Base):
    p = _buscar(s, Paciente, paciente_id, ctx)
    _contacto(s, ctx, data.cliente_id)
    p.cliente_id = data.cliente_id
    p.datos_administrativos = cifrar(ctx.empresa, data.model_dump(exclude={"cliente_id"}))
    _evento(s, ctx, "paciente.ficha_actualizada", p.id)
    s.commit()
    return {"ok": True}


class CoberturaIn(BaseModel):
    convenio_id: int
    tipo: Literal["asegurado", "corporativo"]
    vigencia_desde: date
    vigencia_hasta: date
    poliza: str = Field(default="", max_length=120)
    autorizacion: str = Field(default="", max_length=120)
    numero_empleado: str = Field(default="", max_length=120)
    servicios: str = Field(default="", max_length=1000)
    exclusiones: str = Field(default="", max_length=1000)
    copago: Decimal = Field(default=Decimal("0"), ge=0, le=100000000)
    deducible: Decimal = Field(default=Decimal("0"), ge=0, le=100000000)
    max_atenciones: int = Field(default=0, ge=0, le=10000)
    activa: bool = True


def _cobertura_dict(ctx, fila):
    return {**fila.model_dump(exclude={"datos"}), **leer(ctx.empresa, fila.datos)}


@router.get("/pacientes/{paciente_id}/coberturas")
def coberturas(paciente_id: int, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, paciente_id, ctx)
    return [_cobertura_dict(ctx, x) for x in s.exec(select(Cobertura).where(
        Cobertura.paciente_id == paciente_id, Cobertura.sede == _sede(ctx)
    ).order_by(Cobertura.id.desc()).limit(100))]


@router.get("/operacion/convenio/{convenio_id}/padron")
def padron_convenio(convenio_id: int, ctx: Gestor, s: Base):
    convenio = _buscar(s, Registro, convenio_id, ctx)
    if convenio.tipo != "convenio":
        raise HTTPException(404, "Convenio no disponible")
    fecha = _ahora().date()
    q = select(Cobertura, Paciente.nombre).join(Paciente, Paciente.id == Cobertura.paciente_id).where(
        Cobertura.sede == _sede(ctx), Paciente.sede == _sede(ctx), Cobertura.convenio_id == convenio_id,
        Cobertura.tipo == "corporativo")
    return [{"paciente": nombre, "expediente": c.paciente_id,
             "numero_empleado": leer(ctx.empresa, c.datos).get("numero_empleado"),
             "desde": c.vigencia_desde, "hasta": c.vigencia_hasta,
             "vigente": bool(c.activa and convenio.estado == "activo" and c.vigencia_desde <= fecha <= c.vigencia_hasta
                             and (not convenio.inicio_convenio or convenio.inicio_convenio <= fecha)
                             and (not convenio.vence or fecha <= convenio.vence))}
            for c, nombre in s.exec(q.order_by(Paciente.nombre).limit(1000))]


@router.get("/catalogo-convenios")
def catalogo_convenios(ctx: Recepcion, s: Base):
    return [{ "id": r.id, "nombre": r.nombre, "tipo": r.tipo } for r in s.exec(select(Registro).where(
        Registro.sede == _sede(ctx), Registro.tipo.in_(("aseguradora", "convenio")), Registro.estado == "activo"
    ).order_by(Registro.nombre).limit(250))]


@router.post("/pacientes/{paciente_id}/coberturas", status_code=201)
def crear_cobertura(paciente_id: int, data: CoberturaIn, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, paciente_id, ctx)
    r = _buscar(s, Registro, data.convenio_id, ctx)
    tipo = "aseguradora" if data.tipo == "asegurado" else "convenio"
    if r.tipo != tipo or r.estado != "activo" or data.vigencia_hasta < data.vigencia_desde:
        raise HTTPException(422, "Revise el convenio y el período de cobertura")
    campos = {"poliza", "autorizacion", "numero_empleado", "servicios", "exclusiones"}
    fila = Cobertura(paciente_id=paciente_id, sede=_sede(ctx),
                     datos=cifrar(ctx.empresa, data.model_dump(include=campos)), **data.model_dump(exclude=campos))
    s.add(fila)
    s.flush()
    _evento(s, ctx, "cobertura.creada", fila.id)
    s.commit()
    s.refresh(fila)
    return _cobertura_dict(ctx, fila)


class ValidacionIn(BaseModel):
    cobertura_id: int
    producto_id: int | None = None
    estado: Literal["cubierta", "parcial", "rechazada"]


@router.get("/agenda/{cita_id}/cobertura")
def ver_validacion(cita_id: int, ctx: Recepcion, s: Base):
    _buscar(s, Cita, cita_id, ctx)
    return s.get(Validacion, cita_id)


@router.put("/agenda/{cita_id}/cobertura")
def validar_cobertura(cita_id: int, data: ValidacionIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    c = _buscar(s, Cita, cita_id, ctx)
    cob = _buscar(s, Cobertura, data.cobertura_id, ctx)
    p = s.get(Producto, data.producto_id) if data.producto_id else None
    if data.producto_id and (not p or p.empresa_id != ctx.empresa.id or not p.activo):
        raise HTTPException(422, "Seleccione un servicio del catálogo")
    if c.paciente_id != cob.paciente_id:
        raise HTTPException(422, "La cobertura corresponde a otro expediente")
    if data.estado != "rechazada":
        entidad = _buscar(s, Registro, cob.convenio_id, ctx)
        fecha = c.inicio.date()
        fuera_convenio = entidad.tipo == "convenio" and (
            (entidad.inicio_convenio and fecha < entidad.inicio_convenio) or
            (entidad.vence and fecha > entidad.vence)
        )
        if not cob.activa or entidad.estado != "activo" or fuera_convenio or not cob.vigencia_desde <= fecha <= cob.vigencia_hasta:
            raise HTTPException(409, "Cobertura fuera de vigencia")
        usados = s.exec(select(Validacion).join(Cita, Cita.id == Validacion.cita_id).where(
            Validacion.cobertura_id == cob.id, Validacion.cita_id != cita_id,
            Validacion.estado.in_(("cubierta", "parcial")), Cita.estado.not_in(("cancelada", "no se presentó"))
        )).all()
        if cob.max_atenciones and len(usados) >= cob.max_atenciones:
            raise HTTPException(409, "La cobertura agotó el límite de atenciones")
    fila = s.get(Validacion, cita_id)
    valores = {**data.model_dump(), "fecha": _ahora()}
    if fila:
        fila.sqlmodel_update(valores)
    else:
        fila = Validacion(cita_id=cita_id, **valores)
        s.add(fila)
    _evento(s, ctx, "cita.cobertura_validada", cita_id)
    s.commit()
    return {"estado": data.estado}


class NotaIn(BaseModel):
    texto: str = Field(default="", max_length=8000)
    presion: str = Field(default="", max_length=40)
    pulso: int | None = Field(default=None, ge=1, le=300)
    saturacion: int | None = Field(default=None, ge=1, le=100)
    respiraciones: int | None = Field(default=None, ge=1, le=200)
    temperatura: Decimal | None = Field(default=None, ge=20, le=50)
    peso: Decimal | None = Field(default=None, gt=0, le=500)
    talla: Decimal | None = Field(default=None, gt=0, le=250)


def _nota(cita_id, data, ctx, s, tipo):
    fila = Nota(cita_id=cita_id, autor_id=ctx.usuario.id, tipo=tipo,
                contenido=cifrar(ctx.empresa, data.model_dump()), fecha=_ahora())
    s.add(fila)
    _evento(s, ctx, f"atencion.{tipo}", cita_id)
    s.commit()
    return {"ok": True}


@router.post("/agenda/{cita_id}/enfermeria", status_code=201)
def enfermeria(cita_id: int, data: NotaIn, ctx: Enfermeria, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    cita = _buscar(s, Cita, cita_id, ctx)
    if cita.estado not in {"llegó", "en espera", "en consulta"}:
        raise HTTPException(409, "La atención todavía no ha comenzado o ya se cerró")
    return _nota(cita_id, data, ctx, s, "enfermeria")


@router.post("/agenda/{cita_id}/iniciar")
def iniciar_consulta(cita_id: int, ctx: Clinica, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    cita = _cita_clinica(s, cita_id, ctx)
    if cita.estado not in {"llegó", "en espera", "en consulta"}:
        raise HTTPException(409, "Registre la llegada antes de iniciar")
    if cita.estado != "en consulta":
        cita.estado = "en consulta"
        cita.inicio_atencion = _ahora()
        _evento(s, ctx, "consulta.iniciada", cita_id)
        s.commit()
    return {"estado": "en consulta"}


@router.post("/agenda/{cita_id}/adendas", status_code=201)
def agregar_adenda(cita_id: int, data: NotaIn, ctx: Clinica, s: Base):
    cita = _cita_clinica(s, cita_id, ctx)
    if cita.estado != "atendida" or not data.texto.strip():
        raise HTTPException(409, "La adenda requiere una consulta cerrada y texto")
    return _nota(cita_id, data, ctx, s, "adenda")


@router.get("/agenda/{cita_id}/notas")
def notas(cita_id: int, ctx: EquipoClinico, s: Base):
    c = _buscar(s, Cita, cita_id, ctx)
    medico = CLINICA in ctx.permisos and c.profesional_id == ctx.usuario.id
    if not medico and ENFERMERIA not in ctx.permisos:
        raise HTTPException(404, "Atención no disponible")
    q = select(Nota).where(Nota.cita_id == cita_id)
    if not medico:
        q = q.where(Nota.tipo == "enfermeria")
    resultado = [
        {**r.model_dump(exclude={"contenido"}), **leer(ctx.empresa, r.contenido)}
        for r in s.exec(q.order_by(Nota.id.desc()).limit(100))
    ]
    _evento(s, ctx, "atencion.notas_leidas", cita_id)
    s.commit()
    return resultado


class Espera(SQLModel, table=True):
    __tablename__ = "medica_espera"
    id: int | None = Col(default=None, primary_key=True)
    paciente_id: int
    sede: int = Col(index=True)
    servicio: str
    preferencia: str = ""
    origen: str = "recepcion"
    atendida: bool = False
    creada: datetime = Col(sa_type=DateTime)


class Aviso(SQLModel, table=True):
    __tablename__ = "medica_aviso"
    id: int | None = Col(default=None, primary_key=True)
    cita_id: int = Col(index=True)
    estado: str
    fecha: datetime = Col(sa_type=DateTime)


por_empresa(Espera, Aviso)


class EsperaIn(BaseModel):
    paciente_id: int
    servicio: Nombre
    preferencia: str = Field(default="", max_length=300)


@router.get("/espera")
def lista_espera(ctx: Recepcion, s: Base):
    return [
        {**r.model_dump(), "paciente": nombre}
        for r, nombre in s.exec(select(Espera, Paciente.nombre).join(Paciente, Paciente.id == Espera.paciente_id)
                                .where(Espera.sede == _sede(ctx)).order_by(Espera.creada).limit(200))
    ]


@router.post("/espera", status_code=201)
def poner_en_espera(data: EsperaIn, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, data.paciente_id, ctx)
    r = Espera(sede=_sede(ctx), creada=_ahora(), **data.model_dump())
    s.add(r)
    s.flush()
    _evento(s, ctx, "espera.registrada", r.id)
    s.commit()
    return {"ok": True}


@router.post("/espera/{identificador}/cerrar")
def cerrar_espera(identificador: int, ctx: Recepcion, s: Base):
    r = _buscar(s, Espera, identificador, ctx)
    r.atendida = True
    _evento(s, ctx, "espera.cerrada", r.id)
    s.commit()
    return {"ok": True}


def _enviar_aviso(e, p, c):
    import re
    from html import escape
    from . import correo
    from .main import _cfg_smtp

    if not leer(e, p.datos_administrativos).get("consentimiento_contacto"):
        raise HTTPException(409, "El expediente no tiene autorización para enviar avisos")
    destino = (p.correo or "").strip()
    if not re.fullmatch(r"[^\s,;<>@]+@[^\s,;<>@]+\.[^\s,;<>@]+", destino):
        raise HTTPException(422, "Registre un correo válido en el expediente")
    if not e.smtp_host or not e.smtp_remitente:
        raise HTTPException(409, "Configure SMTP en el ERP")
    cfg = _cfg_smtp(e)
    cfg.copia = None
    mensaje = f"Tiene una cita el {c.inicio:%d/%m/%Y} a las {c.inicio:%H:%M} (Costa Rica). Si necesita cambiarla, contacte a recepción."
    try:
        correo.enviar(cfg, [destino], "Recordatorio de cita", f"<p>{escape(mensaje)}</p>", mensaje, [])
    except correo.ErrorCorreo:
        raise HTTPException(502, "El servidor de correo no confirmó el envío") from None


@router.post("/agenda/{cita_id}/recordar")
def recordar(cita_id: int, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    c = _buscar(s, Cita, cita_id, ctx)
    if c.estado not in {"confirmada", "programada"} or c.inicio <= _ahora():
        raise HTTPException(409, "Seleccione una cita futura")
    ultimo = s.exec(select(Aviso).where(Aviso.cita_id == c.id).order_by(Aviso.id.desc()).limit(1)).first()
    if ultimo and ultimo.fecha > _ahora() - timedelta(minutes=15):
        raise HTTPException(409, "Ya se solicitó un aviso para esta cita")
    p = _buscar(s, Paciente, c.paciente_id, ctx)
    aviso = Aviso(cita_id=c.id, estado="en proceso", fecha=_ahora())
    s.add(aviso)
    s.commit()
    estado = "enviado"
    try:
        _enviar_aviso(ctx.empresa, p, c)
    except HTTPException as ex:
        estado = "falló"
        error = ex
    aviso.estado = estado
    _evento(s, ctx, f"aviso.{estado}", c.id)
    s.commit()
    if estado == "falló":
        raise error
    return {"estado": estado}


@router.get("/agenda/{cita_id}/avisos")
def avisos(cita_id: int, ctx: Recepcion, s: Base):
    _buscar(s, Cita, cita_id, ctx)
    return s.exec(select(Aviso).where(Aviso.cita_id == cita_id).order_by(Aviso.id.desc()).limit(50)).all()


@router.get("/reportes")
def reporte(ctx: Gestor, s: Base, desde: date, hasta: date):
    from collections import Counter
    from statistics import mean
    from sqlalchemy import func

    if hasta < desde or (hasta - desde).days > 92:
        raise HTTPException(422, "Seleccione un período de hasta 93 días")
    inicio, fin = datetime.combine(desde, datetime.min.time()), datetime.combine(hasta + timedelta(days=1), datetime.min.time())
    citas = s.exec(select(Cita).where(Cita.sede == _sede(ctx), Cita.inicio >= inicio, Cita.inicio < fin)).all()
    esperas = [(c.inicio_atencion - c.llegada).total_seconds() / 60 for c in citas if c.inicio_atencion and c.llegada]
    duraciones = [(c.fin_atencion - c.inicio_atencion).total_seconds() / 60 for c in citas if c.fin_atencion and c.inicio_atencion]
    convenios = s.exec(select(Registro.nombre, func.count()).select_from(Validacion)
        .join(Cita, Cita.id == Validacion.cita_id)
        .join(Cobertura, Cobertura.id == Validacion.cobertura_id)
        .join(Registro, Registro.id == Cobertura.convenio_id)
        .where(Cita.sede == _sede(ctx), Cita.inicio >= inicio, Cita.inicio < fin, Cita.estado == "atendida",
               Validacion.estado.in_(("cubierta", "parcial")))
        .group_by(Registro.id, Registro.nombre)).all()
    return {
        "citas": len(citas), "por_estado": dict(Counter(c.estado for c in citas)),
        "por_modalidad": dict(Counter(c.modalidad for c in citas)),
        "por_tipo_atencion": dict(Counter(c.tipo_atencion for c in citas)),
        "espera_minutos": round(mean(esperas), 1) if esperas else None,
        "consulta_minutos": round(mean(duraciones), 1) if duraciones else None,
        "convenios": [{"nombre": nombre, "atenciones": total} for nombre, total in convenios],
    }


class Historia(SQLModel, table=True):
    __tablename__ = "medica_historia"
    id: int | None = Col(default=None, primary_key=True)
    paciente_id: int = Col(index=True)
    cita_id: int
    autor_id: int
    datos: str
    fecha: datetime = Col(sa_type=DateTime)


por_empresa(Historia)


class HistoriaIn(BaseModel):
    antecedentes: str = Field(default="", max_length=6000)
    antecedentes_familiares: str = Field(default="", max_length=4000)
    quirurgicos: str = Field(default="", max_length=4000)
    habitos: str = Field(default="", max_length=4000)
    gineco_obstetricos: str = Field(default="", max_length=4000)
    tipo_sangre: str = Field(default="", max_length=20)
    alergias: str = Field(default="", max_length=2000)
    medicamentos: str = Field(default="", max_length=4000)
    vacunas: str = Field(default="", max_length=3000)
    alertas: str = Field(default="", max_length=2000)


@router.get("/agenda/{cita_id}/historia")
def historia(cita_id: int, ctx: Clinica, s: Base):
    from .medica import Consulta, datos_consulta

    c = _cita_clinica(s, cita_id, ctx)
    if c.estado not in {"llegó", "en espera", "en consulta", "atendida"}:
        raise HTTPException(409, "Registre la llegada antes de ver la historia")
    perfil = s.exec(select(Historia).where(Historia.paciente_id == c.paciente_id).order_by(Historia.id.desc()).limit(1)).first()
    q = select(Consulta, Cita.inicio).join(Cita, Cita.id == Consulta.cita_id).where(
        Cita.paciente_id == c.paciente_id, Cita.sede == c.sede
    ).order_by(Cita.inicio.desc()).limit(30)
    consultas = [
        {"cita_id": registro.cita_id, "inicio": inicio,
         **datos_consulta(ctx.empresa.clave_cifrada, registro)}
        for registro, inicio in s.exec(q)
    ]
    _evento(s, ctx, "paciente.historia_leida", c.paciente_id)
    s.commit()
    return {"perfil": leer(ctx.empresa, perfil.datos) if perfil else {}, "consultas": consultas}


@router.post("/agenda/{cita_id}/historia")
def actualizar_historia(cita_id: int, data: HistoriaIn, ctx: Clinica, s: Base):
    c = _cita_clinica(s, cita_id, ctx)
    if c.estado not in {"llegó", "en espera", "en consulta", "atendida"}:
        raise HTTPException(409, "La cita no está lista para actualizar la historia")
    s.add(Historia(paciente_id=c.paciente_id, cita_id=cita_id, autor_id=ctx.usuario.id,
                   datos=cifrar(ctx.empresa, data.model_dump()), fecha=_ahora()))
    _evento(s, ctx, "paciente.historia_actualizada", c.paciente_id)
    s.commit()
    return {"ok": True}
