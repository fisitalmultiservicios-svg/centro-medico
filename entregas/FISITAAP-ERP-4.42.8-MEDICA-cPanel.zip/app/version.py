"""Versión de la aplicación. Se lee de NOVEDADES.txt en la raíz (de cara al cliente: sin detalles técnicos; viaja en cada zip).
La primera entrada es la versión instalada; el resto, el historial de Mi perfil › Versión. El registro interno y técnico es
CHANGELOG.txt, que no viaja en el zip (tools/build_zip.py lo excluye y exige que ambos empiecen con la misma versión)."""
import re

from .config import BASE_DIR

ARCHIVO = BASE_DIR / "NOVEDADES.txt"
_RE_VERSION = re.compile(r"^VERSION\s+(\S+)\s*[-–]\s*(.+?)\s*$")
_RE_TAG = re.compile(r"^\[([^\]]+)\]\s*(.*)$")
_cache: dict = {"mtime": None, "datos": []}


def leer(texto: str) -> list[dict]:
    """Convierte el texto del registro en [{version, fecha, titulo, cambios: [{tipo, texto}]}], la más reciente primero."""
    out: list[dict] = []
    actual = None
    for linea in texto.splitlines():
        m = _RE_VERSION.match(linea.strip())
        if m:
            actual = {"version": m.group(1), "fecha": m.group(2), "titulo": "", "cambios": []}
            out.append(actual)
            continue
        if actual is None or not linea.strip():
            continue
        s = linea.strip()
        if s.startswith("- "):
            t = _RE_TAG.match(s[2:].strip())
            actual["cambios"].append({"tipo": t.group(1).lower() if t else "", "texto": (t.group(2) if t else s[2:]).strip()})
        elif linea.startswith((" ", "\t")) and actual["cambios"]:          # continuación del cambio anterior
            actual["cambios"][-1]["texto"] += " " + s
        elif not actual["titulo"]:
            actual["titulo"] = s
    return out


def historial() -> list[dict]:
    try:
        mtime = ARCHIVO.stat().st_mtime
    except FileNotFoundError:
        return []
    if _cache["mtime"] != mtime:
        _cache["datos"] = leer(ARCHIVO.read_text(encoding="utf-8"))
        _cache["mtime"] = mtime
    return _cache["datos"]


# 4.2: la versión con la que ARRANCÓ este proceso. La versión que se muestra (actual) se lee del archivo y cambia apenas se suben los
# archivos, pero el programa en memoria sigue siendo el anterior hasta reiniciar la aplicación en el hosting: si difieren, falta el Restart.
try:
    EN_EJECUCION = (leer(ARCHIVO.read_text(encoding="utf-8")) or [{}])[0].get("version") or "desconocida"
except Exception:  # noqa: BLE001
    EN_EJECUCION = "desconocida"


def falta_reiniciar() -> bool:
    v = actual().get("version")
    return bool(v and v != "desconocida" and EN_EJECUCION != "desconocida" and v != EN_EJECUCION)


def actual() -> dict:
    h = historial()
    return h[0] if h else {"version": "desconocida", "fecha": "", "titulo": "", "cambios": []}
