"""FISITAAP · Pedidos en línea (3.47, fase 1 de la fusión): catálogo público y pedidos del cliente final dentro de FISITAAP by Brillante Agencia.

Cada negocio con el extra «pedidos_online» publica su catálogo en grupofactura.com/<negocio> (también /t/<negocio>): portada,
categorías y los ítems marcados «visible en el catálogo» en Inventario. El público arma el carrito, elige recoger o a domicilio,
deja nombre y teléfono, y el pedido queda guardado con un número y un enlace de seguimiento; además se arma el texto para
WhatsApp. El cliente final puede crear un acceso con su teléfono y una clave para ver sus pedidos y guardar direcciones.

El negocio ve la bandeja (Pedidos en línea › Pedidos), confirma o cancela; al confirmar, el pedido entra a la caja como cuenta
en espera (registro pos_espera, origen «online») con la comanda enviada: aparece en el monitor de preparación y se cobra desde la
caja como cualquier venta (tiquete o factura electrónica). Los precios siempre los calcula el servidor con el ítem actual.

Nada vive en otro dominio: fisitaap.com solo es una portada informativa que enlaza aquí."""
import json
import logging
import os
import re
import secrets
import threading
import time
import uuid
from datetime import date, datetime, timedelta
from html import escape
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from pydantic import BaseModel, Field as PField
from sqlalchemy import func, or_
from sqlmodel import Field, Session, SQLModel, select

from . import modulos, pagos_online, planes, secretos
from .auth import Contexto, abrir, contexto, firmar, hash_password, limitar_ip, requiere, sesion_empresa, solo_modulo, solo_pos, verificar_password
from .config import DATA_DIR, ahora_cr, nombre_sistema, dominio_sistema
from .db import Cliente, Documento, DocumentoLinea, Empresa, Producto, central, engine, get_session, por_empresa, sesion_de

router = APIRouter(tags=["pedidos"])
RESERVADOS = {"app", "api", "docs", "redoc", "openapi.json", "p", "t", "js", "img", "fonts", "static", "marcar", "admin", "login", "sitio", "tienda",
              "pedidos", "robots.txt", "sitemap.xml", "terminos", "contacto", "demo", "fisitaap", "grupofactura", "www", "mail", "ftp", "cpanel", "webmail", "soporte", "tike"}
# 3.87: las páginas del sitio (precios, prueba-gratis, guias, hotel…) tampoco pueden ser el nombre público de un negocio: el middleware
# sirve /<negocio> como su página y le quitaba la suya al sitio (con la etiqueta de Google del negocio). Salen de sitio.PAGINAS, así que
# una página nueva del sitio queda reservada sola. Un negocio que ya tuviera uno de esos nombres sigue en /t/<nombre> hasta cambiarlo.
from .sitio import PAGINAS as _PAGINAS_SITIO  # noqa: E402
RESERVADOS |= {r.strip("/").split("/")[0] for r in _PAGINAS_SITIO if r.strip("/")}
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,59}$")
TIPOS = ("recoger", "domicilio", "coordinado")
NOMBRES_TIPO = {"recoger": "Para recoger", "domicilio": "A domicilio", "coordinado": "Envío por coordinar"}
ESTADOS = ("pendiente_pago", "nuevo", "confirmado", "en_preparacion", "listo", "entregado", "cancelado")
NOMBRES_ESTADO = {"pendiente_pago": "Esperando pago", "nuevo": "Nuevo", "confirmado": "Confirmado", "en_preparacion": "En preparación", "listo": "Listo", "entregado": "Entregado", "cancelado": "Cancelado"}
DIAS = ("lun", "mar", "mie", "jue", "vie", "sab", "dom")
PORTADAS_DIR = DATA_DIR / "portadas"
MAX_LINEAS, MAX_CANT = 60, 999


# ------------------------------------------------------------------------------------------------- tablas
class SlugPublico(SQLModel, table=True):
    """Central: nombre público → empresa (para resolver grupofactura.com/<negocio> sin abrir cada base)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    slug: str = Field(index=True, unique=True)
    empresa_id: int = Field(index=True)


class NegocioPublico(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    slug: str = ""
    activo: bool = False                         # publicado
    nombre: str = ""                             # vacío = nombre comercial de la empresa (o de la marca)
    marca_id: Optional[int] = None               # marca 3.45 para logo y nombre
    bienvenida: str = ""
    descripcion: str = ""
    whatsapp: Optional[str] = None               # 8 dígitos
    telefono: Optional[str] = None
    direccion: str = ""
    redes: str = "{}"                            # JSON {instagram, facebook, tiktok, sitio}
    horarios: str = "[]"                         # JSON: 7 entradas lun..dom, cada una null o ["08:00", "20:00"]
    abierto_manual: Optional[bool] = None        # None = según horario; True/False fuerza
    acepta_recoger: bool = True
    acepta_domicilio: bool = True
    acepta_coordinado: bool = False
    costo_envio: float = 0                       # costo fijo de envío a domicilio (las zonas llegan con Entregas, fase 2)
    minimo_pedido: float = 0
    tiempo_estimado: str = ""                    # «30 a 45 min»
    nota_cliente: str = ""                       # aviso que ve el cliente al pedir (pago, horarios…)
    terminal_id: Optional[int] = None            # caja a la que entran los pedidos (vacío = la primera)
    portada_nombre: Optional[str] = None
    color: str = "#0f766e"
    correo_aviso: Optional[str] = None           # a dónde avisar cada pedido (vacío = correo de la empresa)
    lat: Optional[float] = None                  # ubicación del negocio en el mapa (Entregas, 3.48)
    lng: Optional[float] = None
    pago_tarjeta: bool = False                   # pago con tarjeta en el carrito con la cuenta de Tilopay DEL NEGOCIO (3.50)
    tilopay_key: Optional[str] = None            # cifrados con la clave de la empresa
    tilopay_user: Optional[str] = None
    tilopay_password: Optional[str] = None
    tilopay_probado: Optional[str] = None        # última prueba de conexión correcta
    correo_cliente: bool = True                  # correos al cliente final por cada cambio del pedido (3.50)
    # 3.58: Mi página completa, SINPE Móvil, presentación y dominio propio
    presentacion: str = "catalogo"               # catalogo (fotos en cuadrícula) | menu (platos por sección, en lista)
    pago_sinpe: bool = False                     # SINPE Móvil: el cliente transfiere y sube el comprobante; el negocio lo verifica
    sinpe_numero: Optional[str] = None           # 8 dígitos
    sinpe_nombre: str = ""                       # a nombre de quién está el SINPE
    nosotros: str = ""                           # texto «Nosotros» (hasta 2000)
    galeria: str = "[]"                          # JSON: nombres de archivo en data/portadas (4.4: sin tope de fotos; cada una hasta 4 MB)
    tema: str = "claro"                          # claro | oscuro
    fuente: str = ""                             # '' (sistema) | inter | manrope | clasica
    seo_titulo: str = ""                         # título para buscadores (vacío = nombre · Pedidos en línea)
    seo_descripcion: str = ""
    seo_palabras: str = ""
    google_id: str = ""                          # etiqueta de Google (G-XXXXXXX): Analytics / Ads
    pixel_meta: str = ""                         # id del píxel de Meta (Facebook e Instagram)
    dominio: str = ""                            # dominio propio del negocio (www.minegocio.cr); se resuelve en la tabla central DominioNegocio
    dominio_verificado: Optional[str] = None     # fecha en que llegó la primera visita por ese dominio
    # 3.79: modo mayorista (revendedoras): catálogo privado con código, precios por la lista de cada contacto y pedidos a crédito
    mayorista: bool = False
    mayorista_codigo: str = ""
    mayorista_credito: bool = False
    mayorista_mixto: bool = False         # 3.91: página pública + revendedoras (el público compra a precio normal)
    atiende_terminal: Optional[int] = None  # 4.32: «Los pedidos en línea los atiende»: terminal del programa (vacío = la página web). Ruta propia, no va en NegocioIn
    agotado_auto: bool = False            # 4.40: «Mostrar agotado según existencias» (bodega de la caja que recibe los pedidos); apagada por omisión
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class ClienteFinal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    telefono: str = Field(index=True)            # 8 dígitos
    nombre: str = ""
    pin_hash: str = ""
    direcciones: str = "[]"                      # JSON [{nombre, detalle, enlace}]
    intentos: int = 0
    bloqueado_hasta: Optional[str] = None
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    ultimo_acceso: Optional[str] = None
    contacto_id: Optional[int] = None            # 3.79: revendedora = contacto del ERP (lista de precios y crédito)


class Pedido(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    numero: int = Field(index=True)
    token: str = Field(default="", index=True)   # seguimiento público. 4.32: la copia del programa no lo recibe (queda vacío)
    clave_peticion: Optional[str] = Field(default=None, index=True)
    cliente_final_id: Optional[int] = None
    nombre: str
    telefono: str
    tipo: str = "recoger"
    direccion: str = ""
    nota: str = ""
    hora_programada: str = ""                    # HH:MM o vacío
    lat: Optional[float] = None                  # ubicación fijada por el cliente en el mapa (Entregas, 3.48)
    lng: Optional[float] = None
    zona_id: Optional[int] = None
    zona_nombre: str = ""
    lineas: str = "[]"                           # JSON [{producto_id, detalle, cantidad, precio_unitario, tarifa, codigo_tarifa, cabys, unidad_medida, es_servicio, nota, total}]
    subtotal: float = 0
    impuestos: float = 0
    envio: float = 0
    total: float = 0
    estado: str = "nuevo"
    motivo: str = ""
    canal: str = "online"
    cupon_codigo: str = ""                       # comercio avanzado (3.49)
    descuento: float = 0                         # descuento del cupón (con impuestos)
    puntos_canjeados: float = 0
    descuento_puntos: float = 0
    tarjeta_codigo: str = ""
    tarjeta_monto: float = 0                     # parte pagada con tarjeta de regalo
    cuenta_espera_id: Optional[int] = None       # cuenta en pos_espera cuando se confirma
    documento_id: Optional[int] = None
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    actualizado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    confirmado: Optional[str] = None
    entregado: Optional[str] = None
    correo: str = ""                             # correo del cliente para los avisos (opcional, 3.50)
    pago_estado: str = ""                        # '' | pendiente | aprobado | rechazado | reembolsado | reembolso_pendiente (3.50)
    pago_orden: str = ""                         # número de orden enviado a Tilopay
    pago_monto: float = 0                        # lo que se cobra con tarjeta (total menos tarjeta de regalo)
    pago_referencia: str = ""                    # id de la transacción en Tilopay
    pago_auth: str = ""
    pago_fecha: Optional[str] = None
    pago_detalle: str = ""
    pago_medio: str = ""                         # 3.58: '' (al recibir) | tarjeta | sinpe
    sinpe_comprobante: Optional[str] = None      # archivo del comprobante en data/sinpe
    sinpe_referencia: str = ""                   # número de comprobante que escribió el cliente
    sinpe_verificado: Optional[str] = None       # fecha en que el negocio marcó «pago verificado»
    contacto_id: Optional[int] = None            # 3.79: revendedora (contacto del ERP) que hizo el pedido
    a_credito: bool = False                      # 3.79: se carga a la cuenta del contacto; la caja lo cierra como fiado
    atiende: Optional[int] = None                # 4.32: terminal del programa que lo atiende (su cuenta, su comanda y su cobro); 0 o vacío = la página web


class DominioNegocio(SQLModel, table=True):
    """Central (3.58): dominio propio → empresa. Una visita que entra por ese dominio ve la página del negocio."""
    id: Optional[int] = Field(default=None, primary_key=True)
    dominio: str = Field(index=True, unique=True)   # sin «www.» y en minúsculas
    empresa_id: int = Field(index=True)
    slug: str = ""


central(SlugPublico, DominioNegocio)
por_empresa(NegocioPublico, ClienteFinal, Pedido)

_cache_slugs: dict = {}            # slug → (empresa_id | None, vence)


# ------------------------------------------------------------------------------------------------- utilidades
def r2(x) -> float:
    return round(float(x or 0) + 1e-9, 2)


def slug_existe(slug: str) -> bool:
    return empresa_de_slug(slug) is not None


def empresa_de_slug(slug: str) -> Optional[int]:
    ahora = time.time()
    hit = _cache_slugs.get(slug)
    if hit and hit[1] > ahora:
        return hit[0]
    eid = None
    try:
        with Session(engine) as s:
            r = s.exec(select(SlugPublico).where(SlugPublico.slug == slug)).first()
            eid = r.empresa_id if r else None
    except Exception:  # noqa: BLE001  (base no disponible: no se rompe la navegación)
        eid = None
    _cache_slugs[slug] = (eid, ahora + 60)
    return eid


def _olvidar(slug: str):
    _cache_slugs.pop(slug, None)


_cache_dominios: dict = {}         # dominio → ((empresa_id, slug) | None, vence)
DOMINIO_RE = re.compile(r"^(?=.{4,80}$)[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")


def normalizar_dominio(v: str) -> str:
    d = (v or "").strip().lower()
    d = re.sub(r"^https?://", "", d).split("/")[0].split(":")[0]
    return d[4:] if d.startswith("www.") else d


def host_base() -> str:
    """Dominio del sistema (grupofactura.com) según FE_URL_PUBLICA; vacío si no está definida."""
    from .config import URL_PUBLICA
    return normalizar_dominio(URL_PUBLICA) if URL_PUBLICA else ""


def negocio_de_host(host: str) -> Optional[tuple[int, str]]:
    """(empresa_id, slug) del negocio que atiende este host: dominio propio registrado o <negocio>.grupofactura.com. None si no aplica."""
    h = normalizar_dominio(host)
    if not h or h in ("localhost", "127.0.0.1"):
        return None
    base = host_base()
    if base and h == base:
        return None
    if base and h.endswith("." + base):                       # subdominio: nombre-del-negocio.grupofactura.com
        slug = h[: -len(base) - 1]
        if "." in slug or slug in RESERVADOS or not SLUG_RE.fullmatch(slug):
            return None
        eid = empresa_de_slug(slug)
        return (eid, slug) if eid else None
    ahora = time.time()
    hit = _cache_dominios.get(h)
    if hit and hit[1] > ahora:
        return hit[0]
    val = None
    try:
        with Session(engine) as s:
            r = s.exec(select(DominioNegocio).where(DominioNegocio.dominio == h)).first()
            val = (r.empresa_id, r.slug) if r and r.slug else None
    except Exception:  # noqa: BLE001
        val = None
    _cache_dominios[h] = (val, ahora + 60)
    return val


def _olvidar_dominio(d: str):
    _cache_dominios.pop(normalizar_dominio(d), None)


def liberar_direcciones(sc: Session, eid: int) -> None:
    """3.87: al eliminar una empresa se liberan su nombre público, su dominio propio y la dirección de su portal TiKe (antes quedaban
    tomados para siempre y una visita por el dominio volvía a crear su base). También las filas que quedaron de empresas ya borradas
    (los id de empresa no se reutilizan). El commit lo hace quien borra la empresa."""
    from .tike import TikeSlug             # import perezoso (tike carga muchos módulos)
    vivas = {e for e in sc.exec(select(Empresa.id)).all()} - {eid}
    for f in sc.exec(select(SlugPublico)).all():
        if f.empresa_id not in vivas:
            _olvidar(f.slug); sc.delete(f)
    for f in sc.exec(select(DominioNegocio)).all():
        if f.empresa_id not in vivas:
            _olvidar_dominio(f.dominio); sc.delete(f)
    for f in sc.exec(select(TikeSlug)).all():
        if f.empresa_id not in vivas:
            sc.delete(f)


def marcar_dominio_visitado(eid: int, host: str) -> None:
    """Primera visita que entra por el dominio propio: queda verificado (la prueba de que el DNS apunta aquí es que llegó)."""
    try:
        with sesion_de(eid) as s:
            n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()
            if n and n.dominio and normalizar_dominio(host) == n.dominio and not n.dominio_verificado:
                n.dominio_verificado = ahora_cr().isoformat(timespec="seconds"); s.add(n); s.commit()
    except Exception:  # noqa: BLE001
        pass


def ruta_negocio(slug: str) -> str:
    """3.87: /<negocio>, o /t/<negocio> si ese nombre ahora es una página del sitio (un negocio que ya lo tenía antes de reservarlo)."""
    return f"/t/{slug}" if slug in RESERVADOS else f"/{slug}"


def url_negocio(n: "NegocioPublico") -> str:
    """Dirección pública del negocio: su dominio propio cuando ya está verificado; si no, grupofactura.com/<negocio>."""
    from .sitio import base_url
    if n.dominio and n.dominio_verificado:
        return "https://" + n.dominio
    return f"{base_url()}{ruta_negocio(n.slug)}" if n.slug else base_url()


def _negocio(s: Session, eid: int) -> NegocioPublico:
    n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()
    if not n:
        n = NegocioPublico(empresa_id=eid); s.add(n); s.commit(); s.refresh(n)
    return n


def _json(v, defecto):
    try:
        x = json.loads(v or "")
        return x if isinstance(x, type(defecto)) else defecto
    except ValueError:
        return defecto


def _otro_imp(v) -> Optional[dict]:
    if not v:
        return None
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            return None
    return v if isinstance(v, dict) and v.get("codigo") else None


def otro_impuesto_linea(v, cantidad: float, subtotal: float) -> dict:
    """{monto, base}: mismas reglas que la caja (api.js otroImpLinea): Selectivo (02) por tarifa o monto por unidad, 5 % cemento (12),
    específicos por unidad (03) y por grado alcohólico (04). Precios del catálogo en colones."""
    o = _otro_imp(v)
    if not o:
        return {"monto": 0.0, "base": 0.0}
    n = lambda k: float(o.get(k) or 0)  # noqa: E731
    q = float(cantidad or 0); m = 0.0
    if o["codigo"] == "02":
        m = q * n("monto_unidad") if o.get("monto_unidad") not in (None, "") else subtotal * n("tarifa") / 100
    elif o["codigo"] == "12":
        m = subtotal * 5 / 100
    elif o["codigo"] == "03":
        m = round(q * n("cantidad_unidad") + 1e-9, 2) * n("impuesto_unidad")
    elif o["codigo"] == "04":
        m = q * round(round(n("cantidad_unidad") + 1e-9, 2) * n("porcentaje") / 100 + 1e-9, 5) * n("impuesto_unidad")
    m = round(m + 1e-9, 5)
    return {"monto": m, "base": m if o.get("suma_base", True) is not False else 0.0}


def precio_final(p: Producto, base: Optional[float] = None) -> float:
    base = float(p.precio or 0) if base is None else float(base); oi = otro_impuesto_linea(p.otro_impuesto, 1, base)
    return r2(base + oi["monto"] + (base + oi["base"]) * float(p.tarifa or 0) / 100)


# ------------------------------------------------------------------------------------------------- modo mayorista (3.79)
# Un negocio que vende a revendedoras publica su catálogo en privado: entra solo quien está en Contactos (por su celular) con el
# código personal que le envía el negocio (3.87; antes, el código común del negocio); ve los precios de su lista de precios (registros listas_precios e items_extra, los mismos del ERP) y, si el
# negocio lo permite y el contacto tiene límite, pide a crédito. El pedido entra a la caja como cuenta del cliente.
def _digitos_tel(v) -> str:
    return re.sub(r"\D", "", str(v or ""))[-8:]


def contacto_por_telefono(s: Session, eid: int, tel: str) -> Optional[Cliente]:
    """Revendedora: contacto cliente activo cuyo celular o teléfono termina en esos 8 dígitos."""
    tel = _digitos_tel(tel)
    if len(tel) != 8:
        return None
    for c in s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.activo == True)).all():  # noqa: E712
        if (c.tipo or "Cliente") in ("Cliente", "Ambos") and tel in (_digitos_tel(c.celular), _digitos_tel(c.telefono)):
            return c
    return None


def lista_de_contacto(s: Session, eid: int, c: Cliente):
    """(id, nombre) de la lista de precios del contacto (registro contactos_extra), o (None, '') = lista general."""
    extra = modulos.leer(s, eid, "contactos_extra", {}) or {}
    ex = (extra.get(str(c.id)) if isinstance(extra, dict) else None) or (extra.get(c.id) if isinstance(extra, dict) else None) or {}
    try:
        lid = int(ex.get("lista_precios_id") or 0)
    except (TypeError, ValueError):
        lid = 0
    lista = next((x for x in (modulos.leer(s, eid, "listas_precios", []) or []) if isinstance(x, dict) and int(x.get("id") or 0) == lid), None)
    if not lid or not lista or lista.get("principal"):
        return None, ""
    return lid, str(lista.get("nombre") or "")


def precios_de_lista(s: Session, eid: int, lista_id) -> dict:
    """{producto_id: ("valor", precio base) | ("pct", descuento)} según la lista (registros listas_precios e items_extra); vacío = general."""
    try:
        lid = int(lista_id or 0)
    except (TypeError, ValueError):
        return {}
    lista = next((x for x in (modulos.leer(s, eid, "listas_precios", []) or []) if isinstance(x, dict) and int(x.get("id") or 0) == lid), None)
    if not lid or not lista or lista.get("principal"):
        return {}
    extra = modulos.leer(s, eid, "items_extra", {}) or {}
    out = {}
    for pid, ex in (extra.items() if isinstance(extra, dict) else []):
        fila = next((l for l in ((ex or {}).get("listas") or []) if isinstance(l, dict) and str(l.get("lista_id")) == str(lid)), None)
        if fila is None:
            continue
        try:
            valor = float(fila.get("valor") or 0); pid_i = int(pid)
        except (TypeError, ValueError):
            continue
        if lista.get("tipo") == "Porcentaje":
            out[pid_i] = ("pct", valor)
        elif valor > 0:
            out[pid_i] = ("valor", valor)
    return out


def precio_lista(p: Producto, precios: Optional[dict]) -> Optional[float]:
    """Precio base del ítem en la lista de la revendedora (None = el precio general)."""
    r = (precios or {}).get(p.id)
    if not r:
        return None
    return r2(float(p.precio or 0) * (1 - r[1] / 100)) if r[0] == "pct" else r2(r[1])


# 4.9: condiciones de venta que dejan saldo por cobrar (como resumen.CREDITO y CONDICIONES_CREDITO de main.py)
CONDICIONES_CREDITO = ("02", "08", "10")
# 4.9: comprobantes que cargan a la cuenta del cliente (facturas, notas de débito, tiquetes y exportación), como Cuentas por cobrar
# (resumen.py y reporte.js) y los cargos del estado de cuenta; las notas de crédito (03) abonan
TIPOS_SALDO = ("01", "02", "04", "09")


def moneda_principal(s: Session, eid: int) -> str:
    """4.9: moneda principal de la empresa (Configuración › Monedas), igual que main._moneda_principal; colones si no hay."""
    mon = modulos.leer(s, eid, "monedas", []) or []
    return next((str(m.get("codigo")) for m in mon if isinstance(m, dict) and m.get("principal") and m.get("codigo")), "CRC")


def conversor(s: Session, eid: int, principal: Optional[str] = None):
    """4.9: función (monto, moneda, tipo_cambio) → monto en la moneda principal, como aPrincipal (contabilidad/automaticos.js): el documento
    en otra moneda × su tipo de cambio; sin tipo de cambio guardado (documentos viejos), el de venta del día del BCCR (solo si hace falta)."""
    p = (principal or moneda_principal(s, eid) or "CRC").upper(); dia: dict = {}

    def _dia() -> float:
        if "v" not in dia:
            try:
                from . import tipo_cambio
                dia["v"] = float(tipo_cambio.obtener().get("venta") or 0)
            except Exception:  # noqa: BLE001
                dia["v"] = 0.0
        return dia["v"]

    def conv(monto, moneda, tc) -> float:
        v = float(monto or 0); m = (moneda or "CRC").upper(); t = float(tc or 0)
        if m == p:
            return v
        crc = v if m == "CRC" else v * (t if t > 1 else ((_dia() if m == "USD" else 0.0) or 1.0))
        if p == "CRC":
            return crc
        div = t if (m == "CRC" and t > 1) else _dia()
        return crc / div if div else crc
    return conv


def _espera_por_pedido(cuentas) -> tuple:
    """4.9: índices de las cuentas de pos_espera: (por id, por pedido_id → cuentas que siguen en la caja)."""
    por_id: dict = {}; por_pedido: dict = {}
    for c in cuentas or []:
        if not isinstance(c, dict):
            continue
        por_id[c.get("id")] = c
        try:
            k = int(c.get("pedido_id") or 0)
        except (TypeError, ValueError):
            k = 0
        if k:
            por_pedido.setdefault(k, []).append(c)
    return por_id, por_pedido


def _cuentas_del_pedido(p, por_id: dict, por_pedido: dict) -> list:
    """4.9: cuentas de la caja que siguen siendo del pedido: todas las que llevan su pedido_id (la original, las partes de «Dividir en partes»
    y las cuentas «aparte», que caja.js crea con datosCredito) y, de una caja vieja sin pedido_id, la de cuenta_espera_id mientras el pedido
    no tenga comprobante."""
    cs = list(por_pedido.get(p.id, []))
    c0 = por_id.get(p.cuenta_espera_id) if p.cuenta_espera_id and not p.documento_id else None
    if c0 is not None and not c0.get("pedido_id"):
        cs.append(c0)
    return cs


def _prepago_de_cuenta(c) -> float:
    """4.9: lo ya pagado (tarjeta de regalo / en línea) que lleva una cuenta de la caja; solo la que conserva el prepago lo tiene (datosCredito
    no lo pasa a las partes)."""
    pre = c.get("prepago") if isinstance(c, dict) else None
    try:
        return max(0.0, float(pre.get("monto") or 0)) if isinstance(pre, dict) else 0.0
    except (TypeError, ValueError):
        return 0.0


def prepago_pendiente(s: Session, eid: int, p) -> float:
    """4.9: lo ya pagado del pedido (prepago) que la caja todavía va a aplicar al cobrarlo (caja.js lo aplica sin cuenta al emitir: hallazgo
    14): mientras el pedido no tenga comprobante o alguna de sus cuentas en la caja conserve el prepago (cobro por partes en otro orden: la
    parte que lo lleva se cobra después). La revisión del fiado (main.crear_comprobante) lo descuenta de la venta, como pedidos_en_credito."""
    pre = _prepago(p)
    if not pre:
        return 0.0
    if p.documento_id:
        por_id, por_pedido = _espera_por_pedido(modulos.leer(s, eid, "pos_espera", []) or [])
        if not any(_prepago_de_cuenta(c) > 0 for c in _cuentas_del_pedido(p, por_id, por_pedido)):
            return 0.0                                          # ya se aplicó con la cuenta que lo llevaba
    return float(pre.get("monto") or 0)


def pedidos_en_credito(s: Session, eid: int, ids, espera: Optional[list] = None) -> dict:
    """4.9: {contacto_id: [(pedido, monto)]}: lo comprometido en pedidos a crédito que la caja todavía no ha cobrado. Un pedido «nuevo» cuenta
    completo; uno «confirmado» o «entregado», por lo que le queda en la caja: la suma de TODAS las cuentas de pos_espera que llevan su
    pedido_id (la original, las partes de «Dividir en partes» y las cuentas «aparte», que caja.js crea con datosCredito), aunque el pedido
    ya tenga documento_id porque se cobró una parte; sin ninguna cuenta en la caja cuenta 0 (la deuda ya está en el saldo de sus
    comprobantes). Antes un pedido confirmado seguía sumando en «en pedidos» aunque su tiquete fiado ya estuviera en el saldo (crédito
    contado dos veces), uno marcado «entregado» antes de cobrarlo dejaba de contar sin tener comprobante y, tras el primer cobro de un pedido
    dividido (o con todo pasado a una cuenta «aparte»), lo que seguía en la caja no contaba en ningún lado: el disponible salía inflado y la
    revendedora podía pedir por encima de su límite.
    4.9: entre la emisión del último comprobante y el momento en que la caja quita esa cuenta de la espera (segundos) su monto cuenta dos
    veces; es el lado estricto, a propósito, para no dejar de contar las partes que siguen en la caja.
    4.9: sin lo ya pagado con tarjeta de regalo (prepago): la caja solo fía el resto (aplica min(prepago, total) como cobro sin cuenta), así que
    el pedido «nuevo» cuenta total − prepago y cada cuenta, su total menos el prepago que conserva. Antes contaba el total y el disponible
    salía bajo mientras el pedido esperaba (el checkout rechazaba pedidos que sí cabían)."""
    ids = {int(i) for i in (ids or []) if i}
    if not ids:
        return {}
    por_id, por_pedido = _espera_por_pedido(espera if espera is not None else (modulos.leer(s, eid, "pos_espera", []) or []))   # pedido_id → cuentas en la caja
    abiertos = Pedido.documento_id == None  # noqa: E711
    if por_pedido:                                              # 4.9: cobro por partes: ya tiene documento, pero quedan cuentas en la caja
        abiertos = or_(abiertos, Pedido.id.in_(list(por_pedido)))  # type: ignore[union-attr]
    q = select(Pedido).where(Pedido.empresa_id == eid, Pedido.a_credito == True, Pedido.estado.in_(("nuevo", "confirmado", "entregado")), abiertos)  # type: ignore[attr-defined]  # noqa: E712
    q = q.where(Pedido.contacto_id == next(iter(ids))) if len(ids) == 1 else q.where(Pedido.contacto_id != None)  # noqa: E711
    out: dict = {}
    for p in s.exec(q.order_by(Pedido.id)).all():
        if p.contacto_id not in ids:
            continue
        if p.estado == "nuevo" and not p.documento_id:
            monto = max(0.0, float(p.total or 0) - float((_prepago(p) or {}).get("monto") or 0))   # 4.9: menos la tarjeta de regalo
        else:
            monto = 0.0
            for c in _cuentas_del_pedido(p, por_id, por_pedido):    # sin cuentas en la caja: 0 (ya se cobró todo o se descartó)
                propia = c.get("id") == p.cuenta_espera_id
                try:
                    tot = float(c["total"]) if c.get("total") is not None else (float(p.total or 0) if propia else 0.0)
                except (TypeError, ValueError):
                    tot = float(p.total or 0) if propia else 0.0
                monto += max(0.0, tot - _prepago_de_cuenta(c))  # 4.9: la caja fía la cuenta menos el prepago que lleva
        if monto > 0.009:
            out.setdefault(p.contacto_id, []).append((p, r2(monto)))
    return out


def creditos_contactos(s: Session, eid: int, contactos, ambiente: Optional[str] = None, espera: Optional[list] = None, principal: Optional[str] = None,
                       con_pedidos: bool = True, max_docs: Optional[int] = 20, pendientes: Optional[dict] = None, visible=None) -> dict:
    """4.9: {contacto_id: crédito} de varios contactos con dos consultas (lista de revendedoras): límite, saldo (facturas, notas de débito,
    tiquetes y exportación a crédito con saldo, solo del ambiente de Hacienda activo y en la moneda principal), lo vencido, lo comprometido
    en pedidos a crédito que siguen en la caja (pedidos_en_credito) y el disponible. `visible(documento)`: qué documentos se listan (privacidad por sucursal); los totales son de toda
    la cuenta."""
    cs = [c for c in (contactos or []) if c is not None and getattr(c, "id", None)]
    ids = {c.id for c in cs}
    if not ids:
        return {}
    conv = conversor(s, eid, principal); hoy = ahora_cr().date()
    saldo_sql = func.coalesce(Documento.total, 0) - func.coalesce(Documento.pagado, 0) - func.coalesce(Documento.acreditado, 0)
    # 4.9: mismas reglas que Cuentas por cobrar (resumen.py, reporte.js) y los cargos del estado de cuenta: TIPOS_SALDO (01/02/04/09) en
    # condición de crédito (CONDICIONES_CREDITO; vacía = contado). Antes 01/04 con condición distinta de 01: un tiquete «99 Otros» o
    # «04 Apartado» sin cobro rebajaba el disponible mientras el estado de cuenta lo cerraba con «Pago de contado», y una nota de débito o
    # una exportación a crédito no entraban. Diferencia intencional con Cuentas por cobrar: un comprobante en «error» (envío fallido, se
    # reintenta) se sigue debiendo y cuenta (el estado de cuenta también lo carga, _en_estado_cuenta); solo el rechazado no.
    q = select(Documento).where(Documento.empresa_id == eid, Documento.tipo_documento.in_(TIPOS_SALDO), Documento.estado != "rechazado",  # type: ignore[attr-defined]
                                Documento.condicion_venta.in_(CONDICIONES_CREDITO), saldo_sql > 0.009)  # type: ignore[attr-defined]
    q = q.where(Documento.cliente_id == next(iter(ids))) if len(ids) == 1 else q.where(Documento.cliente_id != None)  # noqa: E711
    if ambiente:
        q = q.where(Documento.ambiente == ambiente)
    abiertos: dict = {}
    for d in s.exec(q).all():
        if d.cliente_id in ids and modulos.saldo_documento(d) > 0.009:
            abiertos.setdefault(d.cliente_id, []).append(d)
    pend = pendientes if pendientes is not None else (pedidos_en_credito(s, eid, ids, espera) if con_pedidos else {})
    out = {}
    for c in cs:
        limite = float(c.limite_credito or 0); filas = []
        for d in sorted(abiertos.get(c.id, []), key=lambda d: d.fecha_emision or "", reverse=True):
            vence = (d.fecha_vencimiento or "")[:10] or None
            try:
                dias = max(0, (hoy - date.fromisoformat(vence)).days) if vence else 0
            except ValueError:
                dias = 0
            filas.append(({"id": d.id, "consecutivo": d.consecutivo, "fecha": (d.fecha_emision or "")[:10], "vence": vence, "dias": dias,
                           "total": r2(conv(d.total, d.moneda, d.tipo_cambio)), "saldo": r2(conv(modulos.saldo_documento(d), d.moneda, d.tipo_cambio))}, d))
        saldo = r2(sum(f["saldo"] for f, _d in filas)); vencido = r2(sum(f["saldo"] for f, _d in filas if f["dias"] > 0))
        en_pedidos = r2(sum(m for _p, m in pend.get(c.id, [])))
        docs = [f for f, d in filas if visible is None or visible(d)]
        out[c.id] = {"limite": r2(limite), "saldo": saldo, "en_pedidos": en_pedidos, "disponible": r2(max(0.0, limite - saldo - en_pedidos)), "permitido": limite > 0,
                     "vencido": vencido, "documentos": docs if max_docs is None else docs[:max_docs]}
    return out


def credito_contacto(s: Session, eid: int, c: Cliente, ambiente: Optional[str] = None, **kw) -> dict:
    """Límite, saldo (ventas a crédito con saldo), lo vencido y lo comprometido en pedidos a crédito aún no facturados; disponible = lo que
    queda. 4.9: sin doble conteo (pedidos_en_credito), solo del ambiente activo y en la moneda principal (creditos_contactos)."""
    return creditos_contactos(s, eid, [c], ambiente, **kw)[c.id]


def _salida_revendedora(s: Session, eid: int, c: Cliente, ambiente: Optional[str] = None) -> dict:
    lid, nombre_lista = lista_de_contacto(s, eid, c)
    return {"contacto_id": c.id, "nombre": c.nombre_comercial or c.nombre, "lista": nombre_lista, "credito": credito_contacto(s, eid, c, ambiente)}


def codigo_revendedora(eid: int, contacto_id: int, semilla: str = "") -> str:
    """3.87: código personal de acceso de cada revendedora (8 letras y números). Se deriva del código del negocio (cambiarlo cambia
    todos los códigos que aún no se usaron) y el negocio lo envía al celular de esa revendedora: así el código común ya no basta para
    crear el acceso con el teléfono de otra."""
    import base64, hashlib, hmac
    from .auth import SECRET
    d = hmac.new(SECRET, f"rev:{eid}:{contacto_id}:{(semilla or '').strip().upper()}".encode(), hashlib.sha256).digest()
    return base64.b32encode(d).decode()[:8]


def _contacto_vigente(s: Session, eid: int, cf: ClienteFinal) -> Optional[Cliente]:
    """3.87: contacto (revendedora) al que quedó vinculado el acceso, solo si sigue activo y su celular o teléfono sigue siendo el del
    acceso: si el negocio le cambia el celular en Contactos, la sesión vieja ya no entra a su cuenta ni a su crédito."""
    c = s.get(Cliente, cf.contacto_id) if cf.contacto_id else None
    if not c or c.empresa_id != eid or not c.activo or _digitos_tel(cf.telefono) not in (_digitos_tel(c.celular), _digitos_tel(c.telefono)):
        return None
    return c


def _revendedora(s: Session, eid: int, n: NegocioPublico, x_cliente: str | None):
    """(cliente_final, contacto, precios de su lista) de la sesión del cliente; (None, None, {}) si no hay sesión o no es revendedora."""
    cid = _cliente_token(x_cliente, eid)
    cf = s.get(ClienteFinal, cid) if cid else None
    if not cf or cf.empresa_id != eid or not cf.telefono:        # 3.87: sin teléfono = acceso restablecido por el negocio
        return None, None, {}
    # 3.87: ya no se vincula sola por el teléfono: el vínculo con el contacto lo hace el acceso con el código personal
    c = _contacto_vigente(s, eid, cf)
    if not c:
        return cf, None, {}
    lid, _nombre = lista_de_contacto(s, eid, c)
    return cf, c, precios_de_lista(s, eid, lid)


def _datos_privados(s: Session, e: Empresa, n: NegocioPublico, slug: str) -> dict:
    """Lo que ve quien llega a un catálogo mayorista sin haber entrado: nombre, contacto y la puerta de acceso, sin ítems ni precios."""
    info = _nombre_negocio(s, e, n)
    return {"plataforma": "https://" + dominio_sistema(), "mayorista": True, "privado": True, "cliente": None, "slug": slug, "diseno": {}, "ajustes": {}, "etiqueta": "Menú" if n.presentacion == "menu" else "Catálogo",
            "nombre": info["nombre"], "logo": info["logo"], "portada": None, "bienvenida": n.bienvenida, "descripcion": n.descripcion, "whatsapp": n.whatsapp, "telefono": n.telefono, "direccion": n.direccion,
            "redes": _json(n.redes, {}), "horarios": [], "abierto": abierto_ahora(n), "acepta": {"recoger": n.acepta_recoger, "domicilio": n.acepta_domicilio, "coordinado": n.acepta_coordinado},
            "costo_envio": n.costo_envio, "minimo_pedido": n.minimo_pedido, "tiempo_estimado": n.tiempo_estimado, "nota_cliente": n.nota_cliente, "color": n.color or "#0f766e", "pago_tarjeta": False, "ia": False,
            "presentacion": n.presentacion if n.presentacion in PRESENTACIONES else "catalogo", "nosotros": "", "galeria": [], "tema": n.tema or "claro", "fuente": n.fuente or "", "sinpe": None, "url": url_negocio(n),
            "categorias": [], "items": [], "moneda": "CRC", "puntos": {"activo": False}, "mapa": False, "zonas": [], "con_zonas": False}


def abierto_ahora(n: NegocioPublico) -> dict:
    if n.abierto_manual is not None:
        return {"abierto": bool(n.abierto_manual), "motivo": "" if n.abierto_manual else "Cerrado por ahora"}
    h = _json(n.horarios, [])
    if not h or not any(h):                                 # sin horario configurado (ningún día marcado) = siempre recibe; «cerrado» es abierto_manual=False
        return {"abierto": True, "motivo": ""}
    ahora = ahora_cr(); d = h[ahora.weekday()] if ahora.weekday() < len(h) else None
    if not d or len(d) < 2 or not d[0] or not d[1]:
        return {"abierto": False, "motivo": "Hoy no abrimos"}
    hm = ahora.strftime("%H:%M")
    if d[0] <= d[1]:
        ok = d[0] <= hm <= d[1]
    else:                                                   # cruza la medianoche
        ok = hm >= d[0] or hm <= d[1]
    return {"abierto": ok, "motivo": "" if ok else f"Cerrado: hoy abrimos de {d[0]} a {d[1]}"}


def _nombre_negocio(s: Session, e: Empresa, n: NegocioPublico) -> dict:
    """Nombre y logo que ve el público: la marca (3.45) si se eligió, si no la empresa."""
    from .marcas import marca_de, logo_de, nombre_de, contacto_de
    m = marca_de(s, e.id, n.marca_id)
    logo = logo_de(e, m)
    return {"nombre": (n.nombre or "").strip() or nombre_de(e, m), "logo": f"/api/publico/{n.slug}/logo" if logo else None, "contacto": contacto_de(e, m), "marca_id": n.marca_id}


def _salida_pedido(p: Pedido, estado: Optional[str] = None) -> dict:
    d = _salida_pedido_base(p, estado)
    d.update({"correo": p.correo or "", "pago_estado": p.pago_estado or "", "pago_estado_nombre": NOMBRES_PAGO.get(p.pago_estado or "", ""), "pago_monto": p.pago_monto or 0,
              "pago_referencia": p.pago_referencia or "", "pago_auth": p.pago_auth or "", "pago_fecha": p.pago_fecha, "pago_detalle": p.pago_detalle or ""})
    d["a_pagar"] = r2(max(0.0, float(p.total or 0) - float(p.tarjeta_monto or 0) - (float(p.pago_monto or 0) if p.pago_estado == "aprobado" else 0.0)))
    d["pago_medio"] = p.pago_medio or ""
    d["sinpe"] = {"comprobante": bool(p.sinpe_comprobante), "referencia": p.sinpe_referencia or "", "verificado": p.sinpe_verificado} if (p.pago_medio == "sinpe") else None
    return d


NOMBRES_PAGO = {"": "", "pendiente": "Pago pendiente", "aprobado": "Pagado en línea", "rechazado": "Pago rechazado", "reembolsado": "Reembolsado", "reembolso_pendiente": "Reembolso pendiente",
                "sinpe_pendiente": "SINPE por verificar"}   # 3.58


def _salida_pedido_base(p: Pedido, estado: Optional[str] = None) -> dict:
    est = estado or p.estado
    return {"id": p.id, "numero": p.numero, "token": p.token, "nombre": p.nombre, "telefono": p.telefono, "tipo": p.tipo, "tipo_nombre": NOMBRES_TIPO.get(p.tipo, p.tipo), "direccion": p.direccion,
            "nota": p.nota, "hora_programada": p.hora_programada, "lat": p.lat, "lng": p.lng, "zona": p.zona_nombre, "lineas": _json(p.lineas, []), "subtotal": p.subtotal, "impuestos": p.impuestos, "envio": p.envio, "total": p.total, "cupon": p.cupon_codigo, "descuento": p.descuento, "puntos_canjeados": p.puntos_canjeados, "descuento_puntos": p.descuento_puntos, "tarjeta": p.tarjeta_codigo, "tarjeta_monto": p.tarjeta_monto, "a_pagar": r2(p.total - p.tarjeta_monto),
            "estado": est, "estado_nombre": NOMBRES_ESTADO.get(est, est), "motivo": p.motivo, "canal": p.canal, "cuenta_espera_id": p.cuenta_espera_id, "documento_id": p.documento_id,
            "creado": p.creado, "actualizado": p.actualizado, "confirmado": p.confirmado, "entregado": p.entregado, "cliente_final_id": p.cliente_final_id,
            "contacto_id": p.contacto_id, "a_credito": bool(p.a_credito),
            "forma_pago": forma_pago(p, est), "facturado": bool(p.documento_id)}      # 4.9: forma de pago lista para mostrar y si ya tiene comprobante


def forma_pago(p: Pedido, estado: Optional[str] = None) -> str:
    """4.9: cómo se paga el pedido, con las etiquetas que calculaba FISITAAP (fis/pages/pedidos.js pago()) más «A crédito»: antes un pedido a
    crédito de una revendedora salía «Paga al recibir»."""
    if p.a_credito:
        return "A crédito"
    if p.pago_estado == "aprobado":
        return "SINPE verificado" if p.pago_medio == "sinpe" else "Pagado en línea"
    if p.pago_estado == "sinpe_pendiente":
        return "SINPE por verificar"
    if p.pago_medio == "sinpe" and p.pago_estado == "rechazado":
        return "SINPE rechazado · paga al recibir"
    if (estado or p.estado) == "pendiente_pago":
        return NOMBRES_PAGO.get(p.pago_estado or "", "") or "Pago pendiente"
    if p.pago_medio == "tarjeta" and (estado or p.estado) == "cancelado":   # 4.40: el de tarjeta que no se pagó (venció o no se abrió el pago)
        return "Pagado en línea" if p.pago_estado in ("reembolsado", "reembolso_pendiente") else "Tarjeta en línea · no se pagó"
    if p.pago_medio == "sinpe" and p.pago_estado in ("reembolsado", "reembolso_pendiente"):   # 4.40: el SINPE verificado y luego devuelto
        return "SINPE verificado"
    return "Paga al recibir"


def estado_efectivo(s: Session, eid: int, pedidos: list, espera: Optional[list] = None) -> dict:
    """{pedido_id: estado}: un pedido confirmado sigue el estado de su cuenta en la caja (en cocina, listo, entregado o cobrado).
    4.32: en la web, un pedido que atiende un programa (atiende > 0, sin cuenta aquí) sigue la copia de su cuenta que ese programa sube
    (sinc_dato, etiqueta «pedido:<id>»): sin copia, «confirmado»; viva, según su estado; con lápida (se cobró o se quitó), «entregado»."""
    out = {}
    if not _en_programa():
        out.update(_estado_de_copias(s, [p.id for p in pedidos if p.estado == "confirmado" and int(p.atiende or 0) > 0 and not p.cuenta_espera_id]))
    necesita = [p for p in pedidos if p.estado == "confirmado" and p.cuenta_espera_id and p.id not in out]
    if necesita:
        lista = espera if espera is not None else (modulos.leer(s, eid, "pos_espera", []) or [])
        por_id = {c.get("id"): c for c in lista if isinstance(c, dict)}
        for p in necesita:
            c = por_id.get(p.cuenta_espera_id)
            if c is None:
                out[p.id] = "entregado"                     # la cuenta ya se cobró (desapareció de la espera)
            else:
                est = c.get("estado") or "en_cocina"
                out[p.id] = "listo" if est == "listo" else "entregado" if est == "entregado" else "en_preparacion"
    for p in pedidos:
        out.setdefault(p.id, p.estado)
    return out


def _estado_de_copias(s: Session, pids: list) -> dict:
    """4.32: {pedido_id: estado} de los pedidos que atiende un programa, por las copias de sus cuentas en sinc_dato (las sube el programa,
    app/pedidos_programa.py, dato «cuenta»). Un pedido con varias cuentas (partes, cuentas «aparte») mira las que siguen vivas. Sin la tabla
    (empresa sin programa 4.32) o con cualquier error: {} y cada pedido queda con su estado guardado («confirmado»)."""
    if not pids:
        return {}
    from sqlalchemy import bindparam, text
    try:
        if not s.execute(text("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'sinc_dato'")).first():
            return {pid: "confirmado" for pid in pids}
        q = text("SELECT etiqueta, borrado, datos FROM sinc_dato WHERE tipo = 'cuenta' AND etiqueta IN :etiquetas").bindparams(bindparam("etiquetas", expanding=True))
        filas = s.execute(q, {"etiquetas": [f"pedido:{pid}" for pid in pids]}).all()
    except Exception as ex:  # noqa: BLE001  (el seguimiento nunca falla por la copia)
        logging.getLogger(__name__).warning("Estado de las copias de cuentas de pedidos: %s", type(ex).__name__)
        return {pid: "confirmado" for pid in pids}
    vivas: dict = {}; lapidas: set = set()
    for etiqueta, borrado, datos in filas:
        try:
            pid = int(str(etiqueta).split(":", 1)[1])
        except (IndexError, ValueError):
            continue
        if borrado:
            lapidas.add(pid); continue
        c = _json(datos, {})
        vivas.setdefault(pid, []).append((c.get("estado") if isinstance(c, dict) else None) or "en_cocina")
    out = {}
    for pid in pids:
        ests = vivas.get(pid)
        if ests:
            out[pid] = "entregado" if all(x == "entregado" for x in ests) else "listo" if all(x in ("listo", "entregado") for x in ests) else "en_preparacion"
        else:
            out[pid] = "entregado" if pid in lapidas else "confirmado"
    return out


# ------------------------------------------------------------------------------------------------- página y datos públicos
def _publico(slug: str) -> tuple[Empresa, int]:
    eid = empresa_de_slug(slug)
    if not eid:
        raise HTTPException(404, "Este negocio no existe o no está publicado")
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        if not e or e.bloqueada or "pedidos_online" not in planes.modulos_de(e):
            raise HTTPException(404, "Este negocio no está disponible")
        sc.expunge(e)
    return e, eid


PAGINA = """<!doctype html><html lang="es"{atributos}><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{titulo}</title><meta name="description" content="{descripcion}">{palabras}<meta name="theme-color" content="{color}">
<link rel="stylesheet" href="/fisitaap/assets/app.bundle.css"><link rel="stylesheet" href="/fisitaap/assets/v12.css"><link rel="stylesheet" href="/fisitaap/assets/qa180.css"><link rel="stylesheet" href="/fisitaap/assets/operations180.css"><link rel="stylesheet" href="/fisitaap/assets/experience-r11.css"><link rel="stylesheet" href="/fisitaap/assets/interface-r14.css"><link rel="stylesheet" href="/fisitaap/assets/interface-r15.css"><link rel="stylesheet" href="/fisitaap/assets/platform-r17.css"><link rel="stylesheet" href="/fisitaap/assets/restructure-r2.css"><link rel="stylesheet" href="/fisitaap/assets/fisichat.css"><link rel="stylesheet" href="/tienda.css">
<link rel="icon" href="/img/fisitaap-icono.svg"><style>:root{{--primary:{color};--accent:{acento};--on-primary:{sobre};--brand-ink:{tinta}}}.store-name-brand>span{{display:inline!important;font-size:16px;max-width:180px;overflow:hidden;text-overflow:ellipsis}}</style><link rel="canonical" href="{url}"><meta property="og:type" content="website"><meta property="og:url" content="{url}"><meta property="og:title" content="{titulo}"><meta property="og:description" content="{descripcion}">{og_imagen}{pixeles}
<script type="application/ld+json">{ldjson}</script></head><body class="public-body r14-store r15-store"><div id="app" data-slug="{slug}" v-cloak></div><script type="module" src="/js/tienda.js"></script>{pixel_js}</body></html>"""


def _pagina_html(s: Session, e: Empresa, n: NegocioPublico, slug: str) -> tuple[str, bool]:
    """HTML de la página del negocio con sus datos para buscadores (3.58) y, si los configuró, sus píxeles. Devuelve (html, con_pixeles)."""
    info = _nombre_negocio(s, e, n); nom = info["nombre"]; url = url_negocio(n)
    titulo = (n.seo_titulo or "").strip() or (nom + " · Pedidos en línea")
    descripcion = ((n.seo_descripcion or n.descripcion or n.bienvenida or "Pedidos en línea con FISITAAP").strip())[:160]
    palabras = f'<meta name="keywords" content="{escape(n.seo_palabras.strip()[:200])}">' if (n.seo_palabras or "").strip() else ""
    imagen = f"{url}/api/publico/{slug}/portada" if n.portada_nombre else (f"{url}/api/publico/{slug}/logo" if info["logo"] else "")
    og_imagen = f'<meta property="og:image" content="{escape(imagen, quote=True)}">' if imagen else ""
    g, m = (n.google_id or "").strip(), (n.pixel_meta or "").strip()
    pixeles = (f'<meta name="gf:google" content="{escape(g, quote=True)}">' if g else "") + (f'<meta name="gf:meta" content="{escape(m, quote=True)}">' if m else "")
    pixel_js = '<script type="module" src="/js/pixel.js"></script>' if (g or m) else ""
    atributos = (f' data-tema="{escape(n.tema)}"' if n.tema == "oscuro" else "") + (f' data-fuente="{escape(n.fuente)}"' if n.fuente in FUENTES else "")
    ld: dict = {"@context": "https://schema.org", "@type": "Restaurant" if e.tipo_negocio == "restaurante" else "LocalBusiness", "name": nom, "url": url, "description": descripcion}
    if imagen:
        ld["image"] = imagen
    tel = n.telefono or n.whatsapp
    if tel:
        ld["telephone"] = "+506" + re.sub(r"\D", "", tel)[-8:]
    if n.direccion:
        ld["address"] = {"@type": "PostalAddress", "streetAddress": n.direccion, "addressCountry": "CR"}
    horas = [f"{d} {h[0]}-{h[1]}" for d, h in zip(("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"), _json(n.horarios, [])) if h and len(h) >= 2 and h[0] and h[1]]
    if horas:
        ld["openingHours"] = horas
    color = n.color if re.match(r"^#[0-9a-fA-F]{6}$", n.color or "") else "#0f766e"
    from . import fisitaap as _fis
    acento = _fis.leer_diseno(s, e.id).get("accent_color") or "#dfe9c8"
    if not re.match(r"^#[0-9a-fA-F]{6}$", acento):
        acento = "#dfe9c8"
    rgb = [int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    lin = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    lum = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
    html = PAGINA.format(titulo=escape(titulo), descripcion=escape(descripcion), palabras=palabras, url=escape(url, quote=True), og_imagen=og_imagen, pixeles=pixeles, pixel_js=pixel_js,
                         atributos=atributos, ldjson=json.dumps(ld, ensure_ascii=False).replace("</", "<\\/"), slug=escape(slug),
                         color=color, acento=acento, sobre="#000000" if lum > 0.179 else "#ffffff", tinta="#24313b" if lum > 0.179 else color)
    return html, bool(g or m)


FUENTES = ("inter", "manrope", "clasica")
TEMAS = ("claro", "oscuro")
PRESENTACIONES = ("catalogo", "menu")


# ------------------------------------------------------------------------------------------------- 4.40: agotado según existencias
# Con NegocioPublico.agotado_auto encendida, un ítem del catálogo en línea sale agotado cuando no le quedan unidades en la bodega de
# la caja que recibe los pedidos. Nada se guarda: se calcula en cada lectura. La casilla manual «Agotado por ahora» (Producto.agotado)
# sigue mandando siempre. No se apartan unidades de los pedidos sin cobrar (documento_id no es una señal confiable del cobro).
EXISTENCIA_CERO = 1e-9
MENSAJE_SIN_EXISTENCIAS = "Ya no hay unidades suficientes de «{nombre}» para entrega inmediata. Baja la cantidad o quítalo del carrito."   # 4.40: uno solo y sin cifras (igual si falta todo o una parte)
# 4.40: con varios productos distintos no se dice cuál falla: nombrar la primera línea que no alcanza deja tantear la existencia de una
# línea con otra que seguro falla ([A n, B 999] nombra a A solo si A no alcanza). Conserva «unidades suficientes» (tienda.js recarga).
MENSAJE_SIN_EXISTENCIAS_VARIOS = "Ya no hay unidades suficientes de algunos productos del carrito para entrega inmediata. Baja las cantidades o quita alguno."


def revisar_existencias(c: dict) -> None:
    """4.40: rechaza el pedido si algún producto pide más de lo que hay. Se llama al final de crear_pedido, después de todas las demás
    validaciones, para que ningún otro error deje ver si la cantidad alcanzaba. Con un solo producto distinto lo nombra (no revela nada
    que el cliente no sepa); con varios, el mensaje común. «faltan» y «productos» son internos: ninguna respuesta los devuelve."""
    faltan = c.get("faltan") or []
    if faltan:
        raise HTTPException(400, MENSAJE_SIN_EXISTENCIAS.format(nombre=faltan[0]) if c.get("productos") == 1 else MENSAJE_SIN_EXISTENCIAS_VARIOS)


def _bodega_catalogo(s: Session, eid: int, n: NegocioPublico):
    """4.40: bodega que cuenta para el catálogo en línea: la de la caja que recibe los pedidos (NegocioPublico.terminal_id); si esa caja
    no tiene, la de su sucursal; si tampoco, la principal activa (el orden de bodegaDefecto() de la caja). Solo bodegas de la empresa y
    activas. No escribe nada: no usa bodega_principal(), que puede crear la bodega. None = no hay bodega activa (la opción no tiene efecto)."""
    from .inventario import Bodega

    def _id(v) -> int:
        try:
            v = int(v or 0)
        except (TypeError, ValueError, OverflowError):
            return 0
        return v if 0 < v < (1 << 63) else 0      # 4.40: fuera del rango de SQLite no hay bodega ni sucursal (s.get reventaba)

    def activa(bid):
        bid = _id(bid)
        b = s.get(Bodega, bid) if bid else None
        return b if (b is not None and b.empresa_id == eid and b.activa) else None

    t = _terminal(s, eid, n) or {}
    b = activa(t.get("bodega_id"))
    if b is not None:
        return b
    sid = _id(t.get("sucursal_id"))
    if sid:
        from .sucursales import Sucursal
        suc = s.get(Sucursal, sid)
        if suc is not None and suc.empresa_id == eid:
            b = activa(suc.bodega_id)
            if b is not None:
                return b
    return s.exec(select(Bodega).where(Bodega.empresa_id == eid, Bodega.principal == True, Bodega.activa == True)).first()  # noqa: E712


def _orden_alfabetico(nombre) -> tuple:
    """4.40: clave de orden alfabético en español: sin tildes, la ñ después de la n y sin distinguir mayúsculas."""
    import unicodedata
    t = (nombre or "").casefold().replace("ñ", "n\uffff")
    return ("".join(ch for ch in unicodedata.normalize("NFKD", t) if not unicodedata.combining(ch)), nombre or "")


def disponibilidad(s: Session, eid: int, n: Optional[NegocioPublico], prods) -> dict:
    """4.40: {producto_id: existencias (None = desconocidas)} de los ítems en la bodega del catálogo. {} si la opción está apagada o no
    hay bodega activa: entonces solo cuenta la casilla manual, como antes de la 4.40."""
    if n is None or not getattr(n, "agotado_auto", False):
        return {}
    b = _bodega_catalogo(s, eid, n)
    if b is None:
        return {}
    from .inventario import existencias_catalogo
    return existencias_catalogo(s, eid, prods, b.id)


def agotado_por_existencias(p: Producto, disp: dict) -> bool:
    """4.40: sin unidades en la bodega del catálogo (existencia conocida <= 0) y sin «vender en negativo». No mira la casilla manual."""
    return (not p.venta_negativo) and disp.get(p.id) is not None and float(disp[p.id]) <= EXISTENCIA_CERO


def agotado_web(p: Producto, disp: dict) -> bool:
    """4.40: lo que ve y respeta la página: la casilla manual siempre; con la opción encendida, también sin existencias."""
    return bool(p.agotado) or agotado_por_existencias(p, disp)


@router.get("/t/{slug}", response_class=HTMLResponse, include_in_schema=False)
def pagina_tienda(slug: str):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
        if not n.activo or n.slug != slug:
            raise HTTPException(404, "Este negocio no está publicado")
        html, con_pixeles = _pagina_html(s, e, n, slug)
    # con píxeles la política de seguridad de la página admite los scripts de Google y Meta (lo aplica el middleware)
    return HTMLResponse(html, headers={"X-Pagina-Pixeles": "1"} if con_pixeles else None)


@router.get("/api/publico/{slug}")
def datos_publicos(slug: str, x_cliente: str | None = Header(default=None)):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
        if not n.activo or n.slug != slug:
            raise HTTPException(404, "Este negocio no está publicado")
        cf, rev, precios = _revendedora(s, eid, n, x_cliente)   # 3.79: modo mayorista
        mixto = bool(n.mayorista and n.mayorista_mixto)          # 3.91: página pública + revendedoras
        if n.mayorista and not rev and not mixto:
            return _datos_privados(s, e, n, slug)
        if mixto and not rev:
            precios = {}                                         # el público ve los precios normales
        prods = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.visible_catalogo == True, Producto.activo == True, Producto.es_venta == True)).all()  # noqa: E712
        disp = disponibilidad(s, eid, n, prods)                  # 4.40: agotado según existencias (si la opción está encendida); ninguna cantidad sale en el JSON
        # 3.87: catálogo privado: el <img> no manda la sesión de la revendedora, así que cada foto lleva una firma de 7 días
        kf = ("?k=" + firmar({"tipo": "foto_mayorista", "eid": eid}, 7 * 24 * 3600)) if (n.mayorista and not mixto) else ""
        cats_reg = [c for c in (modulos.leer(s, eid, "categorias", []) or []) if isinstance(c, dict) and c.get("nombre")]
        orden = {c["nombre"]: i for i, c in enumerate(cats_reg)}
        usadas = sorted({p.categoria or "Otros" for p in prods}, key=lambda x: (orden.get(x, 999), x))
        iconos = {c["nombre"]: c.get("icono") or "" for c in cats_reg}
        items = [{"id": p.id, "nombre": p.nombre, "descripcion": (p.descripcion_publica or p.descripcion or "")[:300], "categoria": p.categoria or "Otros", "precio": precio_final(p, precio_lista(p, precios)),
                  "foto": f"/api/publico/{slug}/foto/{p.id}{kf}" if p.imagen_nombre else None, "destacado": bool(p.destacado), "agotado": agotado_web(p, disp), "unidad": p.unidad_medida or "Unid"} for p in prods]
        from . import promociones
        grupos = promociones.grupos_modificadores(s, eid)
        for it, p in zip(items, prods):
            it["modificadores"] = [{"id": g["id"], "nombre": g.get("nombre"), "minimo": int(g.get("minimo") or 0), "maximo": int(g.get("maximo") or 0),
                                    "opciones": [{"id": o["id"], "nombre": o.get("nombre"), "precio": r2(float(o.get("precio") or 0) * (1 + float(p.tarifa or 0) / 100))} for o in (g.get("opciones") or []) if isinstance(o, dict) and "id" in o]}
                                   for g in promociones.grupos_de_producto(s, eid, p.id, grupos)]
        from . import fisitaap as _fis                       # 3.74: promociones por producto (precio especial o 2 × 1 vigentes)
        promos = _fis.promociones_vigentes(s, eid)
        for it in items:
            pr = promos.get(it["id"])
            if pr and pr.get("tipo") == "bogo":
                it["promo"] = {"tipo": "bogo", "etiqueta": "2 × 1"}
            elif pr and float(pr.get("valor") or 0) > 0:
                it["promo"] = {"tipo": "special", "etiqueta": "Precio especial", "precio_antes": it["precio"]}; it["precio"] = r2(float(pr["valor"]))
        items.sort(key=lambda x: (not x["destacado"], orden.get(x["categoria"], 999), x["nombre"].lower()))
        fid = promociones.config_fid(s, eid)
        info = _nombre_negocio(s, e, n)
        gal_urls = {x: f"/api/publico/{slug}/galeria/{x}" for x in _json(n.galeria, []) if (PORTADAS_DIR / x).exists()}
        diseno = _fis.leer_diseno(s, eid)
        for k in _fis.DISENO_IMAGENES:
            diseno[k] = gal_urls.get(diseno.get(k) or "", "")
        if not diseno["hero_image"] and n.portada_nombre:
            diseno["hero_image"] = f"/api/publico/{slug}/portada"
        if diseno.get("catalog_intro_mode") == "auto":                 # 4.4: la portada y TODAS las fotos de la galería (sin límite)
            fotos = list(gal_urls.values())
            if n.portada_nombre:
                fotos = [f"/api/publico/{slug}/portada"] + fotos
            diseno["catalog_slides"] = fotos
            for i, k in enumerate(["catalog_intro_image", "catalog_intro_image_2", "catalog_intro_image_3"]):
                diseno[k] = fotos[i] if i < len(fotos) else ""
        ajustes = _fis.leer_ajustes(s, eid)
        return {"plataforma": "https://" + dominio_sistema(), "mayorista": bool(n.mayorista and (rev or not mixto)), "mayorista_mixto": mixto, "cliente": (_salida_revendedora(s, eid, rev, e.ambiente) if rev else None), "slug": slug, "diseno": diseno, "ajustes": ajustes, "etiqueta": "Menú" if n.presentacion == "menu" else "Catálogo", "nombre": info["nombre"], "logo": info["logo"], "portada": f"/api/publico/{slug}/portada" if n.portada_nombre else None, "bienvenida": n.bienvenida, "descripcion": n.descripcion,
                "whatsapp": n.whatsapp, "telefono": n.telefono or (str(info["contacto"].get("telefono") or "") or None), "direccion": n.direccion, "redes": _json(n.redes, {}), "horarios": _json(n.horarios, []),
                "abierto": abierto_ahora(n), "acepta": {"recoger": n.acepta_recoger, "domicilio": n.acepta_domicilio, "coordinado": n.acepta_coordinado}, "costo_envio": n.costo_envio,
                "minimo_pedido": n.minimo_pedido, "tiempo_estimado": n.tiempo_estimado, "nota_cliente": n.nota_cliente, "color": n.color or "#0f766e", "pago_tarjeta": pagos_online.credenciales(e, n) is not None, "ia": _ia_catalogo(s, e),
                "presentacion": n.presentacion if n.presentacion in PRESENTACIONES else "catalogo", "nosotros": n.nosotros or "", "galeria": [f"/api/publico/{slug}/galeria/{x}" for x in _json(n.galeria, [])], "tema": n.tema or "claro", "fuente": n.fuente or "",   # 3.58
                "sinpe": {"numero": n.sinpe_numero, "nombre": n.sinpe_nombre or ""} if (n.pago_sinpe and n.sinpe_numero) else None, "url": url_negocio(n),
                "categorias": [{"nombre": c, "icono": iconos.get(c, "")} for c in usadas], "items": items, "moneda": "CRC", "puntos": {"activo": fid.activo, "nombre": fid.nombre, "puntos_por_mil": fid.puntos_por_mil, "valor_punto": fid.valor_punto, "minimo_canje": fid.minimo_canje, "maximo_pct": fid.maximo_pct}, **_mapa_publico(s, e, eid, n)}


def _ia_catalogo(s: Session, e: Empresa) -> bool:
    """Asistente con IA en el catálogo (3.56): disponible en el servidor y encendido por la empresa."""
    try:
        from . import ia
        return bool(ia.disponible() and ia.config_empresa(s, e.id).get("activo") and ia.config_empresa(s, e.id).get("catalogo"))
    except Exception:  # noqa: BLE001
        return False


def _mapa_publico(s: Session, e: Empresa, eid: int, n: NegocioPublico) -> dict:
    """Con el extra Entregas: ubicación del negocio y zonas (círculos) para que el cliente marque dónde está (3.48)."""
    if "entregas" not in planes.modulos_de(e):
        return {"mapa": False, "zonas": [], "con_zonas": False}
    from . import entregas
    zs = [z for z in entregas.zonas_de(s, eid) if z.activa]
    return {"mapa": bool(zs) or (n.lat is not None), "negocio_ubicacion": {"lat": n.lat, "lng": n.lng}, "zonas": [{"id": z.id, "nombre": z.nombre, "lat": z.lat, "lng": z.lng, "radio_km": z.radio_km, "precio": z.precio, "tiempo": z.tiempo} for z in zs], "con_zonas": bool(zs)}


@router.get("/api/publico/{slug}/foto/{pid}", include_in_schema=False)
def foto_publica(slug: str, pid: int, k: str | None = None):
    e, eid = _publico(slug)
    from .main import _img_dir
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
        if not n.activo or n.slug != slug:                   # 3.87: la misma regla que los datos del catálogo
            raise HTTPException(404)
        if n.mayorista and not n.mayorista_mixto:            # 3.87: catálogo privado: solo con la firma que reciben las revendedoras con sesión (3.91: no en modo mixto)
            d = abrir(k or "")
            if not (d and d.get("tipo") == "foto_mayorista" and int(d.get("eid") or 0) == eid):
                raise HTTPException(404)
        p = s.get(Producto, pid)
        if not p or p.empresa_id != eid or not p.visible_catalogo or not p.imagen_nombre or not (_img_dir(eid) / p.imagen_nombre).exists():
            raise HTTPException(404)
        return FileResponse(_img_dir(eid) / p.imagen_nombre, headers={"Cache-Control": "public, max-age=3600"})


@router.get("/api/publico/{slug}/logo", include_in_schema=False)
def logo_publico(slug: str):
    e, eid = _publico(slug)
    from .marcas import marca_de, logo_de
    with sesion_de(eid) as s:
        n = _negocio(s, eid); ruta = logo_de(e, marca_de(s, eid, n.marca_id))
    if not ruta or not Path(ruta).exists():
        raise HTTPException(404)
    return FileResponse(ruta, headers={"Cache-Control": "public, max-age=3600"})


@router.get("/api/publico/{slug}/galeria/{nombre}", include_in_schema=False)
def galeria_publica(slug: str, nombre: str):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
    if nombre not in _json(n.galeria, []) or not (PORTADAS_DIR / nombre).exists():
        raise HTTPException(404)
    return FileResponse(PORTADAS_DIR / nombre, headers={"Cache-Control": "public, max-age=3600"})


@router.get("/api/publico/{slug}/portada", include_in_schema=False)
def portada_publica(slug: str):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
    if not n.portada_nombre or not (PORTADAS_DIR / n.portada_nombre).exists():
        raise HTTPException(404)
    return FileResponse(PORTADAS_DIR / n.portada_nombre, headers={"Cache-Control": "public, max-age=3600"})


# ------------------------------------------------------------------------------------------------- pedido del público
class LineaIn(BaseModel):
    producto_id: int
    cantidad: float = PField(gt=0, le=MAX_CANT)
    nota: Optional[str] = PField(None, max_length=120)
    opciones: list[int] = PField(default_factory=list, max_length=30)   # ids de opciones de modificadores (3.49)


class PedidoIn(BaseModel):
    nombre: str = PField(min_length=2, max_length=60)
    telefono: str = PField(min_length=8, max_length=20)
    tipo: str = "recoger"
    direccion: Optional[str] = PField(None, max_length=200)
    nota: Optional[str] = PField(None, max_length=300)
    hora_programada: Optional[str] = PField(None, max_length=5)
    cupon: Optional[str] = PField(None, max_length=20)
    puntos: Optional[float] = PField(None, ge=0, le=1e7)
    tarjeta: Optional[str] = PField(None, max_length=20)
    lineas: list[LineaIn] = PField(min_length=1, max_length=MAX_LINEAS)
    clave_peticion: Optional[str] = PField(None, max_length=60)
    lat: Optional[float] = PField(None, ge=-90, le=90)
    lng: Optional[float] = PField(None, ge=-180, le=180)
    correo: Optional[str] = PField(None, max_length=120)      # 3.50: avisos al cliente
    pagar_tarjeta: bool = False                                # 3.50: pagar ahora con Tilopay (cuenta del negocio)
    pago: Optional[str] = PField(None, max_length=10)         # 3.58: recibir | tarjeta | sinpe (pagar_tarjeta=True equivale a tarjeta)


def _tel(v: str) -> str:
    t = re.sub(r"\D", "", v or "")
    if t.startswith("506") and len(t) == 11:
        t = t[3:]
    if len(t) != 8:
        raise HTTPException(400, "El teléfono debe tener 8 dígitos")
    return t


def _cliente_token(x_cliente: str | None, eid: int) -> Optional[int]:
    d = abrir(x_cliente or "")
    return int(d["cid"]) if d and d.get("tipo") == "cliente_final" and int(d.get("eid") or 0) == eid else None


def calcular(s: Session, eid: int, lineas: list, n: NegocioPublico, tipo: str, lat: Optional[float] = None, lng: Optional[float] = None, con_zonas: bool = False, precios: Optional[dict] = None) -> dict:
    """Líneas con el precio actual del ítem (nunca el que mande el navegador) y totales."""
    ids = [l.producto_id for l in lineas]
    prods = {p.id: p for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.id.in_(ids))).all()}  # type: ignore[attr-defined]
    out, sub, imp = [], 0.0, 0.0
    from . import promociones
    from . import fisitaap as _fis
    grupos = promociones.grupos_modificadores(s, eid)
    promos = _fis.promociones_vigentes(s, eid)
    disp = disponibilidad(s, eid, n, list(prods.values()))   # 4.40: una vez por pedido; {} con la opción apagada (como antes)
    pedida: dict[int, float] = {}                           # 4.40: cantidad pedida por producto entre todas las líneas (los opcionales separan líneas)
    for l in lineas:
        p = prods.get(l.producto_id)
        if not p or not p.visible_catalogo or not p.activo or not p.es_venta:
            raise HTTPException(400, "Uno de los productos ya no está en el catálogo; revise el carrito")
        if p.agotado:
            raise HTTPException(400, f"«{p.nombre}» está agotado por ahora")
        if agotado_web(p, disp):                            # 4.40: sin existencias en la bodega del catálogo: el mismo mensaje que si falta una parte
            raise HTTPException(400, MENSAJE_SIN_EXISTENCIAS.format(nombre=p.nombre))
        pedida[p.id] = pedida.get(p.id, 0.0) + float(l.cantidad)   # 4.40: la cantidad se revisa al final del pedido (revisar_existencias)
        opciones, extra = promociones.resolver_opciones(promociones.grupos_de_producto(s, eid, p.id, grupos), getattr(l, "opciones", None) or [])
        q = float(l.cantidad); pl = precio_lista(p, precios); precio_base = float(p.precio or 0) if pl is None else pl; promo = promos.get(p.id); etiqueta_promo = ""
        if promo and promo.get("tipo") == "bogo" and q >= 2:               # 3.74: cada dos unidades pagan una (los extras se cobran en todas)
            precio_base = r2(precio_base * (q - int(q // 2)) / q); etiqueta_promo = "2 × 1"
        elif promo and promo.get("tipo") == "special" and float(promo.get("valor") or 0) > 0:
            precio_base = r2(float(promo["valor"]) / (1 + float(p.tarifa or 0) / 100)); etiqueta_promo = "Precio especial"
        unit = precio_base + extra
        base = unit * q; oi = otro_impuesto_linea(p.otro_impuesto, q, base)
        iva = (base + oi["base"]) * float(p.tarifa or 0) / 100
        total = r2(base + oi["monto"] + iva); sub += base; imp += oi["monto"] + iva
        out.append({"producto_id": p.id, "detalle": p.nombre, "cantidad": q, "precio_unitario": r2(unit), "precio_final": r2(precio_final(p, pl) + extra * (1 + float(p.tarifa or 0) / 100)), "tarifa": float(p.tarifa or 0), "codigo_tarifa": p.codigo_tarifa,
                    "cabys": p.cabys, "unidad_medida": p.unidad_medida or "Unid", "es_servicio": bool(p.es_servicio), "nota": (l.nota or "").strip()[:120], "total": total, "opciones": opciones, "promo": etiqueta_promo})
    envio = r2(n.costo_envio) if tipo == "domicilio" else 0.0; zona = None
    if tipo == "domicilio" and con_zonas:                   # Entregas (3.48): el costo lo fija la zona que contiene la ubicación del cliente
        from . import entregas
        zs = entregas.zonas_de(s, eid)
        if any(z.activa for z in zs):
            if lat is None or lng is None:
                raise HTTPException(400, "Marque su ubicación en el mapa para calcular el envío")
            zona = entregas.zona_para(zs, lat, lng)
            if not zona:
                raise HTTPException(400, "Su ubicación está fuera de las zonas de entrega; elija «recoger» o escríbanos por WhatsApp")
            envio = r2(zona.precio)
    faltan = [prods[pid].nombre for pid, q in pedida.items()                     # 4.40: los que piden más de lo que hay (sin cifras)
              if not prods[pid].venta_negativo and disp.get(pid) is not None and q > float(disp[pid]) + EXISTENCIA_CERO]
    # 4.40: "faltan" y "productos" son solo para revisar_existencias (crear_pedido); este diccionario no se devuelve en ninguna respuesta
    return {"lineas": out, "subtotal": r2(sub), "impuestos": r2(imp), "envio": envio, "total": r2(sub + imp + envio), "zona": zona, "faltan": faltan, "productos": len(pedida)}


def _texto_whatsapp(nombre_negocio: str, p: Pedido) -> str:
    ls = _json(p.lineas, [])
    partes = [f"Hola {nombre_negocio}, hice el pedido #{p.numero} ({NOMBRES_TIPO.get(p.tipo, p.tipo).lower()}):"]
    partes += [f"- {int(l['cantidad']) if float(l['cantidad']).is_integer() else l['cantidad']} × {l['detalle']}" + (f" ({l['nota']})" if l.get("nota") else "") for l in ls]
    if p.direccion:
        partes.append("Dirección: " + p.direccion)
    if p.hora_programada:
        partes.append("Hora: " + p.hora_programada)
    if p.nota:
        partes.append("Nota: " + p.nota)
    partes.append(f"Total: ₡{p.total:,.0f}".replace(",", "."))
    partes.append(f"Soy {p.nombre}, tel. {p.telefono}")
    return "\n".join(partes)


def _monto(v) -> str:
    return "₡" + f"{float(v or 0):,.0f}".replace(",", ".")


def _remitente_negocio(e: Empresa, n: NegocioPublico, nombre_negocio: str):
    """3.83: remitente del correo con el logo de la marca del negocio (o de la empresa) y el color de su página."""
    from . import correo_diseno as _dz
    from .marcas import marca_de
    try:
        with sesion_de(e.id) as s:
            m = marca_de(s, e.id, n.marca_id)
            if m is not None:
                s.expunge(m)
    except Exception:  # noqa: BLE001
        m = None
    return _dz.de_empresa(e, m, color=n.color or None, nombre=nombre_negocio)


def _avisar_negocio(e: Empresa, n: NegocioPublico, p: Pedido, nombre_negocio: str):
    """Correo al negocio por cada pedido nuevo (en segundo plano, con el SMTP de la empresa; si no hay, no pasa nada)."""
    para = (n.correo_aviso or e.correo or "").strip()
    if not para or not getattr(e, "smtp_host", None):
        return
    rem = _remitente_negocio(e, n, nombre_negocio)

    def _enviar():
        try:
            from . import correo
            from .main import _cfg_smtp
            from . import correo_diseno as _dz
            ls = _json(p.lineas, [])
            html = _dz.armar(rem, titulo=f"Entró el pedido #{p.numero}", antetitulo=NOMBRES_TIPO.get(p.tipo, p.tipo), asunto=f"Pedido en línea #{p.numero}",
                             preencabezado=f"{p.nombre} · total {_monto(p.total)}",
                             parrafos_txt=[f"**{p.nombre}** hizo un pedido ({NOMBRES_TIPO.get(p.tipo, p.tipo).lower()}). Teléfono: {p.telefono}."],
                             lineas=[(f"{l['cantidad']} × {l['detalle']}", _monto(l.get("total")), l.get("nota") or "") for l in ls],
                             totales=[("Total", _monto(p.total), True)],
                             datos=[("Dirección", p.direccion or ""), ("Hora", p.hora_programada or ""), ("Nota", p.nota or "")],
                             despues=[f"Confírmelo en {nombre_sistema()} › Ventas en línea › Pedidos web."])
            texto = f"Pedido #{p.numero} de {p.nombre} ({p.telefono}): total ₡{p.total:,.2f}. Confírmelo en Ventas en línea › Pedidos web."
            correo.enviar(_cfg_smtp(e), [para], f"Pedido en línea #{p.numero} · {nombre_negocio}", html, texto, [])
        except Exception:  # noqa: BLE001  (un correo fallido no detiene el pedido)
            pass
    threading.Thread(target=_enviar, daemon=True).start()


@router.post("/api/publico/{slug}/pedido")
def crear_pedido(slug: str, data: PedidoIn, request: Request, x_cliente: str | None = Header(default=None)):
    e, eid = _publico(slug)
    tel = _tel(data.telefono)
    limitar_ip(request, clave="pedidos", maximo=60, ventana=600, mensaje="Demasiados pedidos seguidos. Espere unos minutos.")   # 60 por IP cada 10 min: una red compartida (oficina, operador móvil) no debe quedar fuera (3.50)
    limitar_ip(request, clave="pedidos", maximo=10, ventana=600, sujeto=f"pedido:{eid}:{tel}", mensaje="Demasiados pedidos con este teléfono. Espere unos minutos.")
    if data.tipo not in TIPOS:
        raise HTTPException(400, "Tipo de pedido desconocido")
    with sesion_de(eid) as s:
        n = _negocio(s, eid)
        if not n.activo or n.slug != slug:
            raise HTTPException(404, "Este negocio no está publicado")
        if data.clave_peticion:
            previo = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.clave_peticion == data.clave_peticion)).first()
            if previo:
                return {**_salida_pedido(previo), "repetido": True, "whatsapp": _enlace_wa(n, previo, _nombre_negocio(s, e, n)["nombre"])}
        ab = abierto_ahora(n)
        if not ab["abierto"]:
            raise HTTPException(400, ab["motivo"] or "El negocio está cerrado por ahora")
        if not {"recoger": n.acepta_recoger, "domicilio": n.acepta_domicilio, "coordinado": n.acepta_coordinado}[data.tipo]:
            raise HTTPException(400, f"Este negocio no ofrece «{NOMBRES_TIPO[data.tipo]}»")
        if data.tipo == "domicilio" and not (data.direccion or "").strip():
            raise HTTPException(400, "Indique la dirección de entrega")
        if data.hora_programada and not re.fullmatch(r"[0-2]\d:[0-5]\d", data.hora_programada):
            raise HTTPException(400, "La hora debe ser HH:MM")
        cf_rev, rev, precios = _revendedora(s, eid, n, x_cliente)   # 3.79: modo mayorista
        if n.mayorista and not rev and n.mayorista_mixto:
            precios = {}                                         # 3.91: modo mixto: el público compra a precio normal
        if n.mayorista and not rev and not n.mayorista_mixto:
            raise HTTPException(401, "Este catálogo es para revendedoras: ingrese con su teléfono, su clave y su código de acceso")   # 3.87: código personal
        c = calcular(s, eid, data.lineas, n, data.tipo, data.lat, data.lng, con_zonas="entregas" in planes.modulos_de(e), precios=precios)
        if n.minimo_pedido and c["subtotal"] + c["impuestos"] < float(n.minimo_pedido):
            raise HTTPException(400, f"El pedido mínimo es ₡{float(n.minimo_pedido):,.0f}".replace(",", "."))
        ultimo = s.exec(select(Pedido).where(Pedido.empresa_id == eid).order_by(Pedido.numero.desc())).first()
        cid = cf_rev.id if cf_rev else None                      # 3.87: el acceso de la sesión (vigente); antes bastaba un token de un acceso ya restablecido
        # comercio avanzado (3.49): cupón, puntos (solo con acceso de cliente) y tarjeta de regalo; todo se valida antes de guardar
        from . import promociones
        bruto = r2(c["subtotal"] + c["impuestos"]); cupon = None; desc_cupon = 0.0
        if data.cupon:
            cupon, desc_cupon = promociones.evaluar_cupon(s, eid, data.cupon, bruto, "online", tel)
        puntos = float(data.puntos or 0); desc_puntos = 0.0
        tel_pts = cf_rev.telefono if cf_rev else ""              # 3.87: los puntos son del teléfono del acceso, nunca del que se escribe en el pedido
        if puntos > 0:
            if not tel_pts:
                raise HTTPException(400, "Para usar puntos ingrese con su teléfono y clave")
            cfg = promociones.config_fid(s, eid)
            if not cfg.activo or puntos > promociones.saldo_puntos(s, eid, tel_pts) + 1e-6 or puntos < float(cfg.minimo_canje or 0):
                raise HTTPException(400, "No tiene suficientes puntos para ese canje" if cfg.activo else "El programa de puntos no está activo")
            desc_puntos = r2(min(puntos * float(cfg.valor_punto or 0), r2((bruto - desc_cupon) * float(cfg.maximo_pct or 100) / 100)))
            puntos = r2(desc_puntos / float(cfg.valor_punto or 1))
        total = r2(max(0.0, bruto - desc_cupon - desc_puntos) + c["envio"]); tarjeta = None; tarjeta_monto = 0.0
        if data.tarjeta:
            tarjeta = promociones.tarjeta_vigente(promociones.tarjeta_por_codigo(s, eid, data.tarjeta)); tarjeta_monto = r2(min(tarjeta.saldo, total))
        p = Pedido(empresa_id=eid, numero=(ultimo.numero if ultimo else 0) + 1, token=secrets.token_urlsafe(12), clave_peticion=data.clave_peticion, cliente_final_id=cid,
                   nombre=" ".join(data.nombre.split())[:60], telefono=tel, tipo=data.tipo, direccion=(data.direccion or "").strip()[:200], nota=(data.nota or "").strip()[:300],
                   hora_programada=data.hora_programada or "", lineas=json.dumps(c["lineas"], ensure_ascii=False), subtotal=c["subtotal"], impuestos=c["impuestos"], envio=c["envio"], total=total,
                   cupon_codigo=cupon.codigo if cupon else "", descuento=desc_cupon, puntos_canjeados=puntos if desc_puntos else 0, descuento_puntos=desc_puntos, tarjeta_codigo=tarjeta.codigo if tarjeta else "", tarjeta_monto=tarjeta_monto,
                   lat=data.lat, lng=data.lng, zona_id=c["zona"].id if c.get("zona") else None, zona_nombre=c["zona"].nombre if c.get("zona") else "")
        correo = (data.correo or "").strip().lower()[:120]
        if correo and not CORREO_RE.fullmatch(correo):
            raise HTTPException(400, "Revise el correo electrónico")
        p.correo = correo
        cred = None; pago_url = None; a_tarjeta = r2(total - tarjeta_monto)
        medio = (data.pago or ("tarjeta" if data.pagar_tarjeta else "recibir")).strip().lower()
        if medio not in ("recibir", "tarjeta", "sinpe", "credito"):
            raise HTTPException(400, "Forma de pago desconocida")
        if rev:
            p.contacto_id = rev.id
        if medio == "credito":                                   # 3.79: a crédito, dentro del límite del contacto (la caja lo cierra como fiado)
            if not (n.mayorista and n.mayorista_credito and rev):
                raise HTTPException(400, "Este negocio no recibe pedidos a crédito por la página")
            cr = credito_contacto(s, eid, rev, e.ambiente)            # 4.9: sin doble conteo y solo del ambiente activo
            if not cr["permitido"]:
                raise HTTPException(400, "Su cuenta no tiene límite de crédito; pida al negocio que se lo asigne")
            if a_tarjeta > cr["disponible"] + 1e-6:              # 4.9: solo lo que va a crédito (total − tarjeta de regalo: la caja fía el resto)
                fmt = lambda v: f"{v:,.0f}".replace(",", ".")  # noqa: E731  (4.9: cada monto por separado; el replace global cambiaba la coma del texto)
                que = f"Lo que queda a crédito (₡{fmt(a_tarjeta)}, sin la tarjeta de regalo)" if tarjeta_monto else f"El pedido (₡{fmt(total)})"
                raise HTTPException(400, f"{que} supera su crédito disponible (₡{fmt(cr['disponible'])})")
            p.a_credito = True; p.pago_medio = "credito"
        if medio == "tarjeta" and a_tarjeta > 0:
            cred = pagos_online.credenciales(e, n)
            if not cred:
                raise HTTPException(400, "Este negocio no recibe pagos con tarjeta en línea; elija pagar al recibir")
            p.estado = "pendiente_pago"; p.pago_estado = "pendiente"; p.pago_monto = a_tarjeta; p.pago_medio = "tarjeta"
        elif medio == "sinpe" and a_tarjeta > 0:                  # 3.58: el cliente transfiere y sube el comprobante; el negocio verifica
            if not (n.pago_sinpe and n.sinpe_numero):
                raise HTTPException(400, "Este negocio no recibe SINPE Móvil por la página; elija otra forma de pago")
            p.pago_estado = "sinpe_pendiente"; p.pago_monto = a_tarjeta; p.pago_medio = "sinpe"
        revisar_existencias(c)                                    # 4.40: la última validación antes de guardar (público, mayorista y revendedora pasan por aquí)
        s.add(p); s.commit(); s.refresh(p)
        if cred:
            p.pago_orden = f"GF{eid}-{p.id}-{secrets.token_hex(3).upper()}"
            try:
                pago_url = pagos_online.iniciar_pago(cred, p, p.pago_monto, _url_retorno(slug), correo or (e.correo or "pedidos@" + dominio_sistema()), n.direccion or "")
            except Exception:
                # 4.40: el pedido no se borra: borrarlo dejaba tantear la existencia sin rastro mientras Tilopay falla (502/504 = alcanzaba).
                # Queda «Cancelado» a la vista, como los de tarjeta que vencen; el cupón, los puntos y la tarjeta de regalo todavía no se usaron.
                # Cualquier falla (también una respuesta rara de Tilopay que no es HTTPException): sin clave de petición, reintentar crea otro
                # pedido en vez de devolver este como recibido
                try:
                    p.estado = "cancelado"; p.motivo = "No se pudo abrir el pago en línea"; p.clave_peticion = None
                    p.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(p); s.commit()
                except Exception:  # noqa: BLE001  (que un fallo al guardar no tape el error original)
                    s.rollback()
                raise
            s.add(p); s.commit(); s.refresh(p)
        ref = f"pedido:{p.id}"
        if cupon:
            promociones.registrar_uso(s, eid, cupon, tel, ref, desc_cupon, "online")
        if desc_puntos:
            promociones.canjear(s, eid, tel_pts, puntos, bruto - desc_cupon, ref, p.nombre)
        if tarjeta and tarjeta_monto:
            promociones.consumir_tarjeta(s, eid, tarjeta.codigo, tarjeta_monto, ref)
        nom = _nombre_negocio(s, e, n)["nombre"]
        if pago_url:                                              # el negocio se entera cuando Tilopay confirme el pago
            return {**_salida_pedido(p), "repetido": False, "whatsapp": None, "pago_url": pago_url}
        _avisar_negocio(e, n, p, nom)
        avisar_cliente(e, n, p, "recibido")
        return {**_salida_pedido(p), "repetido": False, "whatsapp": _enlace_wa(n, p, nom)}


def _enlace_wa(n: NegocioPublico, p: Pedido, nombre_negocio: str) -> Optional[str]:
    from urllib.parse import quote
    numero = re.sub(r"[^0-9]", "", n.whatsapp or n.telefono or "")      # 4.4: sin WhatsApp configurado, el teléfono del negocio
    if len(numero) < 8:
        return None
    return f"https://wa.me/506{numero[-8:]}?text=" + quote(_texto_whatsapp(nombre_negocio, p))


@router.get("/api/publico/{slug}/pedido/{token}")
def seguimiento(slug: str, token: str, x_cliente: str | None = Header(default=None)):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        p = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.token == token)).first()
        if not p:
            raise HTTPException(404, "Pedido no encontrado")
        previo = s.get(ClienteFinal, p.cliente_final_id) if (p.cliente_final_id and x_cliente) else None
        if x_cliente and not (previo and previo.telefono):       # 3.87: quien abre el enlace de su pedido de invitado con su sesión (mismo
            cid = _cliente_token(x_cliente, eid)                 # teléfono) lo suma a «Mis pedidos»; el teléfono solo ya no basta. También
            cf = s.get(ClienteFinal, cid) if cid else None       # el de un acceso que el negocio restableció (clave olvidada): el enlace es la prueba
            if cf and cf.empresa_id == eid and cf.telefono and cf.telefono == p.telefono:
                p.cliente_final_id = cf.id; s.add(p); s.commit(); s.refresh(p)
        est = estado_efectivo(s, eid, [p])[p.id]
        n = _negocio(s, eid)
        from . import entregas
        return {**_salida_pedido(p, est), "negocio": _nombre_negocio(s, e, n)["nombre"], "whatsapp": _enlace_wa(n, p, _nombre_negocio(s, e, n)["nombre"]), "entrega": entregas.seguimiento_publico(s, eid, p.id) if "entregas" in planes.modulos_de(e) else None}


# ------------------------------------------------------------------------------------------------- cliente final (teléfono + clave)
class AccesoIn(BaseModel):
    telefono: str = PField(min_length=8, max_length=20)
    pin: str = PField(min_length=4, max_length=8)
    nombre: Optional[str] = PField(None, max_length=60)
    codigo: Optional[str] = PField(None, max_length=40)   # 3.79: código del negocio (modo mayorista)


class DireccionesIn(BaseModel):
    direcciones: list = PField(max_length=10)


@router.post("/api/publico/{slug}/cliente/acceso")
def acceso_cliente(slug: str, data: AccesoIn, request: Request):
    """Teléfono y clave: si el teléfono es nuevo, se crea el acceso (con nombre); si existe, se verifica la clave."""
    e, eid = _publico(slug)
    tel = _tel(data.telefono)
    if not data.pin.isdigit():
        raise HTTPException(400, "La clave debe ser de 4 a 8 dígitos")
    limitar_ip(request, clave="pedidos", maximo=15, ventana=600, sujeto=f"cliente:{eid}:{tel}", mensaje="Demasiados intentos. Espere unos minutos.")
    with sesion_de(eid) as s:
        c = s.exec(select(ClienteFinal).where(ClienteFinal.empresa_id == eid, ClienteFinal.telefono == tel)).first()
        ahora = ahora_cr().isoformat(timespec="seconds")
        n = _negocio(s, eid); rev = None
        if not c:                                                # 3.87: tope por conexión para los teléfonos sin acceso (frena recorrer números)
            from .auth import _ip
            limitar_ip(request, clave="pedidos", maximo=20, ventana=600, sujeto=f"alta_cliente:{eid}:{_ip(request) or '?'}",
                       mensaje="Demasiados accesos nuevos desde su conexión. Espere unos minutos.")
        if n.mayorista:                                          # 3.79: solo revendedoras registradas en Contactos
            rev = contacto_por_telefono(s, eid, tel)
            if not rev and not n.mayorista_mixto:                # 3.91: en modo mixto, un teléfono que no es de revendedora entra como cliente normal
                raise HTTPException(403, "Este teléfono no está registrado como revendedora; escríbanos por WhatsApp para registrarlo")
            # 3.87: al crear el acceso (o al vincular uno que no era de esta revendedora) se pide su código PERSONAL, el que el negocio
            # envía a su celular; el código común del negocio ya no basta para entrar con el teléfono de otra y cargarle pedidos a crédito
            if rev and (not c or c.contacto_id != rev.id):
                import hmac
                dado = re.sub(r"[^A-Z0-9]", "", (data.codigo or "").upper())
                if not hmac.compare_digest(dado, codigo_revendedora(eid, rev.id, n.mayorista_codigo)):
                    raise HTTPException(403, {"codigo": "codigo", "mensaje": "El código de acceso no es correcto: use el código personal que le envió el negocio"})
        if not c:
            if not (data.nombre or "").strip() and not rev:
                raise HTTPException(404, {"codigo": "nuevo", "mensaje": "Este teléfono no tiene acceso todavía: indique su nombre para crearlo"})
            nombre = " ".join((data.nombre or (rev.nombre_comercial or rev.nombre if rev else "")).split())[:60]
            c = ClienteFinal(empresa_id=eid, telefono=tel, nombre=nombre, pin_hash=hash_password(data.pin), ultimo_acceso=ahora, contacto_id=rev.id if rev else None)
            s.add(c); s.commit(); s.refresh(c)
        else:
            if c.bloqueado_hasta and c.bloqueado_hasta > ahora:
                raise HTTPException(429, "Acceso bloqueado por intentos fallidos. Intente en unos minutos.")
            if not verificar_password(data.pin, c.pin_hash):
                c.intentos += 1
                if c.intentos >= 5:
                    c.intentos = 0; c.bloqueado_hasta = (ahora_cr() + timedelta(minutes=10)).isoformat(timespec="seconds")
                s.add(c); s.commit()
                raise HTTPException(401, "Clave incorrecta")
            c.intentos = 0; c.bloqueado_hasta = None; c.ultimo_acceso = ahora
            if rev and c.contacto_id != rev.id:
                c.contacto_id = rev.id
            s.add(c); s.commit()
        return {"token": firmar({"tipo": "cliente_final", "eid": eid, "cid": c.id}, 30 * 24 * 3600), "nombre": c.nombre, "telefono": c.telefono, "direcciones": _json(c.direcciones, []),
                "contacto": _salida_revendedora(s, eid, rev, e.ambiente) if rev else None}


def _cliente(s: Session, eid: int, x_cliente: str | None) -> ClienteFinal:
    cid = _cliente_token(x_cliente, eid)
    c = s.get(ClienteFinal, cid) if cid else None
    if not c or c.empresa_id != eid or not c.telefono:          # 3.87: sin teléfono = acceso restablecido por el negocio
        raise HTTPException(401, "Ingrese con su teléfono y clave")
    return c


def telefono_puntos(s: Session, p: Pedido) -> str:
    """3.87: los puntos que gana un pedido van al teléfono del acceso con que se hizo (igual que el canje, tel_pts en crear_pedido), no al
    teléfono escrito en el formulario (quien pide para otra persona). Pedido de invitado, o acceso que el negocio restableció: el del pedido."""
    cf = s.get(ClienteFinal, p.cliente_final_id) if p.cliente_final_id else None
    return cf.telefono if cf and cf.empresa_id == p.empresa_id and cf.telefono else p.telefono


@router.get("/api/publico/{slug}/mis-pedidos")
def mis_pedidos(slug: str, x_cliente: str | None = Header(default=None)):
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        c = _cliente(s, eid, x_cliente)
        # 3.87: solo los pedidos hechos con este acceso. Antes también los de cualquier pedido con ese teléfono: quien creara el acceso
        # con el número de otra persona veía su nombre, dirección, nota y enlace de seguimiento (con el PIN de la entrega). Un pedido
        # de invitado se suma abriendo su enlace de seguimiento con la sesión (seguimiento()).
        ps = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.cliente_final_id == c.id).order_by(Pedido.id.desc())).all()[:50]
        est = estado_efectivo(s, eid, ps)
        rev = _contacto_vigente(s, eid, c)
        return {"nombre": c.nombre, "telefono": c.telefono, "direcciones": _json(c.direcciones, []), "pedidos": [_salida_pedido(p, est[p.id]) for p in ps],
                "cuenta": _salida_revendedora(s, eid, rev, e.ambiente) if rev else None}   # 3.79: estado de cuenta de la revendedora (4.9: del ambiente activo)


@router.put("/api/publico/{slug}/cliente/direcciones")
def guardar_direcciones(slug: str, data: DireccionesIn, x_cliente: str | None = Header(default=None)):
    e, eid = _publico(slug)
    limpias = []
    for d in data.direcciones:
        if isinstance(d, dict) and str(d.get("detalle") or "").strip():
            limpias.append({"nombre": str(d.get("nombre") or "")[:40], "detalle": str(d.get("detalle") or "").strip()[:200], "enlace": str(d.get("enlace") or "")[:300]})
    with sesion_de(eid) as s:
        c = _cliente(s, eid, x_cliente); c.direcciones = json.dumps(limpias, ensure_ascii=False); s.add(c); s.commit()
    return {"ok": True, "direcciones": limpias}


# ------------------------------------------------------------------------------------------------- administración del negocio
class NegocioIn(BaseModel):
    slug: str = PField(min_length=2, max_length=60)
    activo: bool = False
    nombre: Optional[str] = PField("", max_length=80)
    marca_id: Optional[int] = None
    bienvenida: Optional[str] = PField("", max_length=200)
    descripcion: Optional[str] = PField("", max_length=600)
    whatsapp: Optional[str] = PField(None, max_length=20)
    telefono: Optional[str] = PField(None, max_length=20)
    direccion: Optional[str] = PField("", max_length=200)
    redes: dict = {}
    horarios: list = []
    abierto_manual: Optional[bool] = None
    acepta_recoger: bool = True
    acepta_domicilio: bool = True
    acepta_coordinado: bool = False
    costo_envio: float = PField(0, ge=0, le=1e6)
    minimo_pedido: float = PField(0, ge=0, le=1e7)
    tiempo_estimado: Optional[str] = PField("", max_length=40)
    nota_cliente: Optional[str] = PField("", max_length=300)
    terminal_id: Optional[int] = None
    color: Optional[str] = PField("#0f766e", max_length=9)
    correo_aviso: Optional[str] = PField(None, max_length=120)
    pago_tarjeta: bool = False                                  # 3.50
    tilopay_key: Optional[str] = PField(None, max_length=200)   # None = no tocar; "" = borrar
    tilopay_user: Optional[str] = PField(None, max_length=120)
    tilopay_password: Optional[str] = PField(None, max_length=200)
    correo_cliente: bool = True
    # 3.58
    presentacion: Optional[str] = PField("catalogo", max_length=12)
    pago_sinpe: bool = False
    sinpe_numero: Optional[str] = PField(None, max_length=20)
    sinpe_nombre: Optional[str] = PField("", max_length=80)
    nosotros: Optional[str] = PField("", max_length=2000)
    tema: Optional[str] = PField("claro", max_length=10)
    fuente: Optional[str] = PField("", max_length=12)
    seo_titulo: Optional[str] = PField("", max_length=70)
    seo_descripcion: Optional[str] = PField("", max_length=160)
    seo_palabras: Optional[str] = PField("", max_length=200)
    google_id: Optional[str] = PField("", max_length=30)
    pixel_meta: Optional[str] = PField("", max_length=20)
    dominio: Optional[str] = PField("", max_length=100)
    mayorista: bool = False                                     # 3.79: catálogo privado para revendedoras
    mayorista_codigo: Optional[str] = PField("", max_length=40)
    mayorista_credito: bool = False
    mayorista_mixto: bool = False         # 3.91: página pública + revendedoras (el público compra a precio normal)
    agotado_auto: Optional[bool] = None   # 4.40: «Mostrar agotado según existencias»; None (no vino) = no se toca: una pestaña de antes de la 4.40 no la apaga


def _admin(ctx: Contexto) -> Contexto:
    planes.exigir_modulo(ctx.empresa, "pedidos_online")
    return ctx


def admin(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    return _admin(ctx)


# 3.87: 'pos' es operar (ver la página, la bandeja, estados, SINPE recibido). Editar la página (textos, fotos, horario, publicación)
# es de quien administra ítems y precios ('catalogos': Administrador, Avanzado, Vendedor, Supervisor de caja, Recepcionista), no
# del Cajero ni de un rol de solo caja. Los datos de cobro y a dónde van los avisos los cambia solo quien configura la empresa.
PERMISO_COBROS = "configurar"
COBROS_TIENDA = ("pago_sinpe", "sinpe_numero", "sinpe_nombre", "pago_tarjeta", "correo_aviso", "dominio", "google_id", "pixel_meta")
AVISO_COBROS = ("Los datos de cobro (SINPE Móvil y tarjeta), el correo de aviso, el dominio propio y los píxeles solo los cambia el "
                "administrador de la empresa")


def gestion(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    ctx.exigir("catalogos")
    return _admin(ctx)


def gestion_cobros(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    if not ctx.puede(PERMISO_COBROS):
        raise HTTPException(403, AVISO_COBROS)
    return _admin(ctx)


def _conservar_cobros(n: NegocioPublico, data: "NegocioIn") -> None:
    """3.87: quien edita la página sin configurar guarda todo lo demás; los datos de cobro quedan como estaban (si no los mandó o
    los mandó iguales) y si intenta cambiarlos, 403. Los valores de `data` ya vienen normalizados (teléfono, Google, píxel)."""
    def igual(v, w):
        if isinstance(v, bool) or isinstance(w, bool):
            return bool(v) == bool(w)
        return " ".join(str(v or "").split()).lower() == " ".join(str(w or "").split()).lower()
    enviados = data.model_fields_set
    nuevo = {**{k: getattr(data, k) for k in COBROS_TIENDA}, "dominio": normalizar_dominio(data.dominio or "")}
    if any(k in enviados and not igual(nuevo[k], getattr(n, k)) for k in COBROS_TIENDA) or \
            any(getattr(data, k) is not None for k in ("tilopay_key", "tilopay_user", "tilopay_password")):
        raise HTTPException(403, AVISO_COBROS)
    for k in COBROS_TIENDA:
        setattr(data, k, getattr(n, k))


# ------------------------------------------------------------------------------------------------- SINPE Móvil con comprobante (3.58)
SINPE_DIR = DATA_DIR / "sinpe"


@router.post("/api/publico/{slug}/pedido/{token}/sinpe")
def subir_comprobante_sinpe(slug: str, token: str, request: Request, archivo: UploadFile = File(...), referencia: str = Form("")):
    """El cliente sube la foto (o PDF) del comprobante del SINPE y el número de referencia; el negocio lo ve en Pedidos y marca «pago verificado»."""
    e, eid = _publico(slug)
    limitar_ip(request, clave="pedidos", maximo=10, ventana=600, sujeto=f"sinpe:{eid}:{token}", mensaje="Demasiados intentos. Espere unos minutos.")
    ext = (archivo.filename or "comprobante.jpg").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg", "webp", "pdf"):
        raise HTTPException(400, "El comprobante debe ser una foto (JPG, PNG o WEBP) o un PDF")
    datos = archivo.file.read(5 * 1024 * 1024 + 1)
    if not datos or len(datos) > 5 * 1024 * 1024:
        raise HTTPException(400, "El comprobante puede pesar hasta 5 MB")
    with sesion_de(eid) as s:
        p = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.token == token)).first()
        if not p:
            raise HTTPException(404, "Pedido no encontrado")
        if p.pago_medio != "sinpe" or p.estado == "cancelado":
            raise HTTPException(400, "Este pedido no se paga por SINPE Móvil")
        if p.sinpe_verificado:
            raise HTTPException(400, "El negocio ya verificó el pago de este pedido")
        SINPE_DIR.mkdir(exist_ok=True)
        nombre = f"{eid}_{p.id}.{ext}"
        if p.sinpe_comprobante and p.sinpe_comprobante != nombre:
            (SINPE_DIR / p.sinpe_comprobante).unlink(missing_ok=True)
        (SINPE_DIR / nombre).write_bytes(datos)
        p.sinpe_comprobante = nombre; p.sinpe_referencia = " ".join((referencia or "").split())[:40]; p.pago_estado = "sinpe_pendiente"
        p.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(p); s.commit(); s.refresh(p)
        return _salida_pedido(p, estado_efectivo(s, eid, [p])[p.id])


@router.get("/api/pedidos/{pid}/sinpe/comprobante", include_in_schema=False)
def ver_comprobante_sinpe(pid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):   # 4.5: solo quien atiende pedidos ('pos'); antes cualquier rol con sesión (Camarera, Solo lectura…) llegaba al archivo
    p = s.get(Pedido, pid)
    if not p or p.empresa_id != ctx.empresa.id or not p.sinpe_comprobante or not (SINPE_DIR / p.sinpe_comprobante).exists():
        raise HTTPException(404, "Sin comprobante")
    return FileResponse(SINPE_DIR / p.sinpe_comprobante, headers={"Cache-Control": "no-store"})


class SinpeIn(BaseModel):
    verificado: bool = True
    motivo: Optional[str] = PField(None, max_length=120)


@router.put("/api/pedidos/{pid}/sinpe")
def verificar_sinpe(pid: int, data: SinpeIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """El negocio revisó el SINPE en su banco: «pago verificado» deja el pedido pagado (también en la caja si ya entró); «rechazar» lo deja por pagar al recibir."""
    eid = ctx.empresa.id; p = s.get(Pedido, pid)
    solo_en_la_web(eid)                                         # 4.32: en el programa con el canal nuevo, en la página web
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    if p.pago_medio != "sinpe":
        raise HTTPException(400, "Este pedido no se paga por SINPE Móvil")
    if p.estado == "cancelado":
        raise HTTPException(400, "El pedido está cancelado")
    ahora = ahora_cr().isoformat(timespec="seconds")
    if data.verificado:
        if p.pago_estado == "aprobado":
            raise HTTPException(400, "Este pago ya estaba verificado")
        p.pago_estado = "aprobado"; p.pago_fecha = ahora; p.sinpe_verificado = ahora; p.pago_referencia = p.sinpe_referencia or "SINPE"; p.pago_detalle = f"SINPE Móvil verificado por {ctx.usuario.nombre or ctx.usuario.correo}"[:120]
        p.pago_monto = r2(max(0.0, float(p.total or 0) - float(p.tarjeta_monto or 0)))
    else:
        p.pago_estado = "rechazado"; p.sinpe_verificado = None; p.pago_detalle = (data.motivo or "Comprobante no válido: paga al recibir")[:120]
    if p.cuenta_espera_id:                                   # ya está en la caja: se le pone (o quita) el prepago para que la caja cobre lo que falta
        from . import comandas   # 4.31 (L-9): la cuenta se lee dentro del bloqueo: no pisa un plato que la caja guardó en ese instante
        comandas.reescribir_cuentas(s, eid, lambda x: x.get("id") == p.cuenta_espera_id,
                                    lambda c: None if (c.get("cobros") or []) else {**c, "prepago": _prepago(p)})
    p.actualizado = ahora; s.add(p); s.commit(); s.refresh(p)
    if data.verificado:
        avisar_cliente(ctx.empresa, _negocio(s, eid), p, "pagado")
    return _salida_pedido(p, estado_efectivo(s, eid, [p])[p.id])


def _salida_negocio(s: Session, e: Empresa, n: NegocioPublico) -> dict:
    d = {k: getattr(n, k) for k in ("id", "slug", "activo", "nombre", "marca_id", "bienvenida", "descripcion", "whatsapp", "telefono", "direccion", "abierto_manual", "acepta_recoger", "acepta_domicilio",
                                    "acepta_coordinado", "costo_envio", "minimo_pedido", "tiempo_estimado", "nota_cliente", "terminal_id", "color", "correo_aviso", "pago_tarjeta", "correo_cliente",
                                    "presentacion", "pago_sinpe", "sinpe_numero", "sinpe_nombre", "nosotros", "tema", "fuente", "seo_titulo", "seo_descripcion", "seo_palabras", "google_id", "pixel_meta", "dominio", "dominio_verificado", "mayorista", "mayorista_codigo", "mayorista_credito", "mayorista_mixto",
                                    "agotado_auto")}   # 4.40
    d["redes"] = _json(n.redes, {}); d["horarios"] = _json(n.horarios, [])
    d["galeria"] = [{"nombre": x, "url": f"/api/pedidos/negocio/galeria/{x}?v={abs(hash(x))}"} for x in _json(n.galeria, []) if (PORTADAS_DIR / x).exists()]   # 3.58
    d["url_dominio"] = ("https://" + n.dominio) if n.dominio else None; d["host_base"] = host_base()
    d["url_subdominio"] = (f"https://{n.slug}.{host_base()}" if (n.slug and host_base() and n.slug not in RESERVADOS) else None)   # 3.87: sin subdominio si el nombre está reservado
    k = secretos.descifrar(e.clave_cifrada, n.tilopay_key) or "" if n.tilopay_key else ""
    d["tilopay"] = {"llave": ("…" + k[-4:]) if k else "", "usuario_guardado": bool(n.tilopay_user), "clave_guardada": bool(n.tilopay_password), "probado": n.tilopay_probado,
                    "listo": pagos_online.credenciales(e, n) is not None}
    d["portada"] = f"/api/pedidos/negocio/portada?v={abs(hash(n.portada_nombre))}" if n.portada_nombre else None
    d["abierto"] = abierto_ahora(n); d["nombre_publico"] = _nombre_negocio(s, e, n)["nombre"]
    from .sitio import base_url
    d["url"] = (f"{base_url()}{ruta_negocio(n.slug)}" if n.slug else None); d["url_publica"] = url_negocio(n) if n.slug else None
    d["visibles"] = len(s.exec(select(Producto.id).where(Producto.empresa_id == e.id, Producto.visible_catalogo == True, Producto.activo == True)).all())  # noqa: E712
    # 4.32: «Los pedidos en línea los atiende» (se cambia con PUT /api/pedidos/negocio/atiende): la terminal elegida, su nombre y las computadoras
    # conectadas para elegir (en el programa, ninguna: se elige en la página web)
    _elegido = n.atiende_terminal if (_en_programa() or interruptores_encendidos()) else None   # con un interruptor apagado la tienda de la web se ve como la 4.31 (sin «Aceptar y atenderlo aquí»)
    d["atiende_terminal"] = _elegido or None
    d["atiende_nombre"] = nombre_terminal(s, e.id, _elegido) if _elegido else ""
    # (revisión 4.32) con FE_SINC_DATOS o FE_PEDIDOS_PROGRAMA apagados no hay qué elegir: la pantalla de la tienda queda como la 4.31
    d["atiende_opciones"] = [] if (_en_programa() or not interruptores_encendidos()) else instalaciones_vigentes(s, e.id)
    return d


@router.get("/api/pedidos/negocio")
def ver_negocio(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    d = _salida_negocio(s, ctx.empresa, _negocio(s, ctx.empresa.id))
    if not ctx.puede("catalogos"):        # 3.87: la caja lee la página para atender pedidos, no el correo de aviso, el código mayorista ni las llaves
        d.update({"correo_aviso": None, "mayorista_codigo": "", "tilopay": {**d["tilopay"], "llave": ""}})
    if solo_pos(ctx.permisos):            # 4.5: el Cajero opera la bandeja (nombre, url, abierto, qué acepta); los datos de cobro, el dominio, el SEO y los píxeles no
        d.update({"sinpe_numero": "", "sinpe_nombre": "", "google_id": "", "pixel_meta": "", "dominio": "", "dominio_verificado": None, "url_dominio": None,
                  "seo_titulo": "", "seo_descripcion": "", "seo_palabras": "",
                  "tilopay": {"llave": "", "usuario_guardado": False, "clave_guardada": False, "probado": None, "listo": d["tilopay"]["listo"]}})
    return d


@router.put("/api/pedidos/negocio")
def guardar_negocio(data: NegocioIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    solo_en_la_web(ctx.empresa.id)                              # 4.32: la tienda se configura en la página web
    eid = ctx.empresa.id; n = _negocio(s, eid)
    slug = data.slug.strip().lower()
    # 3.87: quien ya tenía un nombre que ahora es una página del sitio puede seguir guardando (su página sigue en /t/<nombre>)
    if not SLUG_RE.fullmatch(slug) or (slug in RESERVADOS and slug != n.slug) or "--" in slug:
        raise HTTPException(400, "El nombre público solo lleva letras minúsculas, números y guiones (2 a 60), y no puede ser una palabra reservada")
    otro = sc.exec(select(SlugPublico).where(SlugPublico.slug == slug, SlugPublico.empresa_id != eid)).first()
    if otro:
        raise HTTPException(400, f"El nombre público «{slug}» ya lo usa otro negocio; elija otro")
    for campo in ("whatsapp", "telefono"):
        v = getattr(data, campo)
        if v:
            setattr(data, campo, _tel(v))
    if data.correo_aviso and not re.fullmatch(r"[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}", data.correo_aviso.strip()):
        raise HTTPException(400, "Revise el correo de aviso")
    horarios = []
    for i in range(7):
        h = data.horarios[i] if i < len(data.horarios) else None
        if isinstance(h, (list, tuple)) and len(h) >= 2 and h[0] and h[1]:
            if not (re.fullmatch(r"[0-2]\d:[0-5]\d", str(h[0])) and re.fullmatch(r"[0-2]\d:[0-5]\d", str(h[1]))):
                raise HTTPException(400, f"Horario del {DIAS[i]}: use HH:MM")
            horarios.append([str(h[0]), str(h[1])])
        else:
            horarios.append(None)
    if data.marca_id:
        from .marcas import marca_de
        if marca_de(s, eid, data.marca_id) is None:
            raise HTTPException(400, "La marca indicada no existe")
    if data.activo and not data.acepta_recoger and not data.acepta_domicilio and not data.acepta_coordinado:
        raise HTTPException(400, "Active al menos una forma de entrega (recoger, domicilio o por coordinar)")
    if data.terminal_id:
        if not any(int(t.get("id") or 0) == int(data.terminal_id) for t in terminales_pos(modulos.leer(s, eid, "pos_config", None))):   # 4.7: también la caja por defecto
            raise HTTPException(400, "La caja indicada no existe")
    # 3.58: SINPE, presentación, apariencia, buscadores, píxeles y dominio propio
    if data.sinpe_numero:
        data.sinpe_numero = _tel(data.sinpe_numero)
    if data.pago_sinpe and not data.sinpe_numero:
        raise HTTPException(400, "Para recibir SINPE Móvil indique el número (8 dígitos)")
    if data.presentacion not in PRESENTACIONES:
        raise HTTPException(400, "Presentación desconocida (catálogo o menú)")
    if data.tema not in TEMAS:
        raise HTTPException(400, "Tema desconocido (claro u oscuro)")
    if data.fuente and data.fuente not in FUENTES:
        raise HTTPException(400, "Tipo de letra desconocido")
    g = (data.google_id or "").strip().upper()
    if g and not re.fullmatch(r"(G|GT|AW|UA|DC)-[A-Z0-9-]{4,25}", g):
        raise HTTPException(400, "La etiqueta de Google tiene la forma G-XXXXXXXXXX")
    data.google_id = g
    m_ = re.sub(r"\D", "", data.pixel_meta or "")
    if (data.pixel_meta or "").strip() and not (8 <= len(m_) <= 20):
        raise HTTPException(400, "El píxel de Meta es un número de 15 o 16 dígitos")
    data.pixel_meta = m_
    if not ctx.puede(PERMISO_COBROS):                                  # 3.87: SINPE, tarjeta, correo de aviso, dominio y píxeles
        _conservar_cobros(n, data)
    dominio = normalizar_dominio(data.dominio or "")
    if dominio:
        if not DOMINIO_RE.fullmatch(dominio) or dominio == host_base() or (host_base() and dominio.endswith("." + host_base())):
            raise HTTPException(400, f"Escriba un dominio propio, por ejemplo www.minegocio.cr (el subdominio en {dominio_sistema()} se da solo)")
        otro = sc.exec(select(DominioNegocio).where(DominioNegocio.dominio == dominio, DominioNegocio.empresa_id != eid)).first()
        if otro:
            raise HTTPException(400, f"El dominio «{dominio}» ya está registrado por otro negocio")
    if dominio != (n.dominio or ""):
        n.dominio_verificado = None
    data.dominio = dominio
    viejo = n.slug
    for k in ("activo", "nombre", "marca_id", "bienvenida", "descripcion", "whatsapp", "telefono", "direccion", "abierto_manual", "acepta_recoger", "acepta_domicilio", "acepta_coordinado",
              "costo_envio", "minimo_pedido", "tiempo_estimado", "nota_cliente", "terminal_id", "color", "correo_aviso", "pago_tarjeta", "correo_cliente",
              "presentacion", "pago_sinpe", "sinpe_numero", "tema", "fuente", "google_id", "pixel_meta", "dominio", "mayorista", "mayorista_credito", "mayorista_mixto"):
        setattr(n, k, getattr(data, k))
    if data.agotado_auto is not None:                                 # 4.40: sin la clave (pestaña de antes de la 4.40) queda como estaba
        n.agotado_auto = bool(data.agotado_auto)
    n.mayorista_codigo = (data.mayorista_codigo or "").strip().upper()[:40]   # 3.79
    for k in ("sinpe_nombre", "nosotros", "seo_titulo", "seo_descripcion", "seo_palabras"):
        setattr(n, k, " ".join((getattr(data, k) or "").split()) if k != "nosotros" else (data.nosotros or "").strip())
    if secretos.asegurar_clave(ctx.empresa):                                    # empresa sin clave propia (muy vieja): se le crea y se guarda
        ec = sc.get(Empresa, eid)
        if ec:
            ec.clave_cifrada = ctx.empresa.clave_cifrada; sc.add(ec); sc.commit()
    for k in ("tilopay_key", "tilopay_user", "tilopay_password"):           # llaves de Tilopay del negocio: None = se dejan como están
        v = getattr(data, k)
        if v is not None:
            setattr(n, k, secretos.cifrar(ctx.empresa.clave_cifrada, v.strip()) if v.strip() else None)
            n.tilopay_probado = None
    if n.pago_tarjeta and not pagos_online.credenciales(ctx.empresa, n):
        raise HTTPException(400, "Para cobrar con tarjeta complete la llave, el usuario y la clave del API de Tilopay del negocio")
    n.slug = slug; n.redes = json.dumps({k: str(v)[:200] for k, v in (data.redes or {}).items() if k in ("instagram", "facebook", "tiktok", "sitio", "maps")}, ensure_ascii=False); n.horarios = json.dumps(horarios)
    s.add(n); s.commit(); s.refresh(n)
    fila = sc.exec(select(SlugPublico).where(SlugPublico.empresa_id == eid)).first()
    if n.activo:
        if fila:
            fila.slug = slug; sc.add(fila)
        else:
            sc.add(SlugPublico(slug=slug, empresa_id=eid))
    elif fila:
        sc.delete(fila)
    fd = sc.exec(select(DominioNegocio).where(DominioNegocio.empresa_id == eid)).first()      # dominio propio (3.58): tabla central
    if n.dominio:
        if fd:
            _olvidar_dominio(fd.dominio); fd.dominio = n.dominio; fd.slug = slug; sc.add(fd)
        else:
            sc.add(DominioNegocio(dominio=n.dominio, empresa_id=eid, slug=slug))
    elif fd:
        _olvidar_dominio(fd.dominio); sc.delete(fd)
    sc.commit(); _olvidar(slug); _olvidar(viejo); _olvidar_dominio(n.dominio)
    return _salida_negocio(s, ctx.empresa, n)


class AbiertoIn(BaseModel):
    abierto_manual: Optional[bool] = None       # None = según el horario; False = en pausa (no recibe pedidos); True = abierta siempre


@router.put("/api/pedidos/negocio/abierto")
def cambiar_abierto(data: AbiertoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """3.87: pausar o reanudar los pedidos en línea desde la bandeja (un pico de trabajo, se acabó algo). Es operación de la caja:
    solo cambia el estado manual; el resto de la página (cobro, textos, publicación) sigue siendo de quien la administra."""
    if data.abierto_manual is True and not ctx.puede("catalogos"):    # «abierta siempre» (fuera del horario) es del horario de la página
        raise HTTPException(403, "Desde la caja solo se pausan o reanudan los pedidos; abrir fuera del horario se hace en Mi página")
    n = _negocio(s, ctx.empresa.id)
    n.abierto_manual = data.abierto_manual; s.add(n); s.commit(); s.refresh(n)
    return {"abierto_manual": n.abierto_manual, "abierto": abierto_ahora(n)}


class AtiendeIn(BaseModel):
    terminal: Optional[int] = None              # 4.32: la computadora que atiende los pedidos en línea; vacío = la página web


def _auditar_pedidos(ctx: Contexto, accion: str, detalle: str) -> None:
    try:
        from .main import _auditar
        _auditar(ctx, accion, detalle)
    except Exception:  # noqa: BLE001  (la auditoría nunca convierte una operación exitosa en error)
        logging.getLogger(__name__).warning("No se pudo auditar %s", accion)


@router.put("/api/pedidos/negocio/atiende")
def cambiar_atiende(data: AtiendeIn, ctx: Contexto = Depends(gestion_cobros), s: Session = Depends(sesion_empresa)):
    """4.32 (§4.1): «Los pedidos en línea los atiende: La página web · El programa de «{nombre}»». Ruta propia (no va en NegocioIn): una pestaña
    vieja que guarda la página no lo pisa. Es de quien configura la empresa (decide dónde se cobra). Solo en la página web. Los pedidos ya
    aceptados se terminan donde están; cada pedido nuevo va al programa solo si en ese momento está conectado y con la impresión de comandas."""
    if _en_programa():
        raise HTTPException(400, TEXTO_SOLO_WEB)
    if not interruptores_encendidos():                     # revisión 4.32: con los interruptores apagados, como la 4.31 (sin esta opción)
        raise HTTPException(409, TEXTO_OPCION_APAGADA)
    eid = ctx.empresa.id
    t = int(data.terminal or 0)
    if t < 0 or (t and not any(i["terminal"] == t for i in instalaciones_vigentes(s, eid))):
        raise HTTPException(400, "Esa computadora no está conectada a la empresa: elija otra o la página web")
    n = _negocio(s, eid)
    n.atiende_terminal = t or None; s.add(n); s.commit(); s.refresh(n)
    nombre = nombre_terminal(s, eid, t) if t else ""
    _auditar_pedidos(ctx, "pedidos_atiende", f"Los pedidos en línea los atiende {('«' + nombre + '»') if t else 'la página web'}")
    return {"atiende_terminal": n.atiende_terminal or None, "atiende_nombre": nombre}


@router.post("/api/pedidos/negocio/dominio/verificar")
def verificar_dominio(ctx: Contexto = Depends(gestion_cobros), s: Session = Depends(sesion_empresa)):
    """Revisa a dónde apunta el DNS del dominio propio y lo compara con el servidor (3.58). No cambia nada: informa."""
    import socket
    n = _negocio(s, ctx.empresa.id)
    if not n.dominio:
        raise HTTPException(400, "Escriba primero el dominio propio y guarde")
    def _ips(h):
        try:
            return sorted({x[4][0] for x in socket.getaddrinfo(h, 443, proto=socket.IPPROTO_TCP)})
        except OSError:
            return []
    base = host_base(); ips_dom = _ips(n.dominio) or _ips("www." + n.dominio); ips_base = _ips(base) if base else []
    if not ips_dom:
        estado, msg = "sin_dns", f"El dominio {n.dominio} todavía no tiene registro DNS (o no se ha propagado). Cree el registro y vuelva a verificar en unos minutos."
    elif ips_base and set(ips_dom) & set(ips_base):
        estado, msg = "apunta", f"{n.dominio} ya apunta a este servidor. Falta que el proveedor del hosting lo agregue como alias del sitio (con su certificado); después, la primera visita lo marca como verificado."
    elif not ips_base:
        estado, msg = "apunta", f"{n.dominio} responde en {', '.join(ips_dom)}. Agregue el dominio como alias del sitio en el hosting."
    else:
        estado, msg = "otro", f"{n.dominio} apunta a {', '.join(ips_dom)}, no a este servidor ({', '.join(ips_base)}). Revise el registro CNAME o A."
    return {"estado": estado, "mensaje": msg, "verificado": n.dominio_verificado, "ips": ips_dom, "ips_servidor": ips_base}


# ------------------------------------------------------------------------------------------------- galería de Mi página (3.58)
@router.post("/api/pedidos/negocio/galeria")
def subir_galeria(archivo: UploadFile = File(...), ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    """4.4: sin tope de fotos (antes 8): la galería alimenta el slider del catálogo y las imágenes de la página."""
    n = _negocio(s, ctx.empresa.id); fotos = [x for x in _json(n.galeria, []) if isinstance(x, str)]
    ext = (archivo.filename or "foto.jpg").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg", "webp"):
        raise HTTPException(400, "Las fotos deben ser JPG, PNG o WEBP")
    datos = archivo.file.read(4 * 1024 * 1024 + 1)
    if len(datos) > 4 * 1024 * 1024:
        raise HTTPException(400, "Cada foto puede pesar hasta 4 MB")
    PORTADAS_DIR.mkdir(exist_ok=True)
    nombre = f"galeria_{ctx.empresa.id}_{secrets.token_hex(4)}.{ext}"
    (PORTADAS_DIR / nombre).write_bytes(datos); fotos.append(nombre); n.galeria = json.dumps(fotos); s.add(n); s.commit()
    return {"ok": True, "galeria": [{"nombre": x, "url": f"/api/pedidos/negocio/galeria/{x}?v={abs(hash(x))}"} for x in fotos]}


@router.delete("/api/pedidos/negocio/galeria/{nombre}")
def quitar_galeria(nombre: str, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id); fotos = [x for x in _json(n.galeria, []) if isinstance(x, str)]
    if nombre in fotos:
        fotos.remove(nombre); (PORTADAS_DIR / nombre).unlink(missing_ok=True); n.galeria = json.dumps(fotos); s.add(n); s.commit()
    return {"ok": True, "galeria": [{"nombre": x, "url": f"/api/pedidos/negocio/galeria/{x}?v={abs(hash(x))}"} for x in fotos]}


@router.get("/api/pedidos/negocio/galeria/{nombre}", include_in_schema=False)
def ver_galeria(nombre: str, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id)
    if nombre not in _json(n.galeria, []) or not (PORTADAS_DIR / nombre).exists():
        raise HTTPException(404)
    return FileResponse(PORTADAS_DIR / nombre, headers={"Cache-Control": "no-store"})


@router.post("/api/pedidos/negocio/portada")
def subir_portada(archivo: UploadFile = File(...), ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id)
    ext = (archivo.filename or "portada.jpg").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg", "webp"):
        raise HTTPException(400, "La portada debe ser JPG, PNG o WEBP")
    datos = archivo.file.read(4 * 1024 * 1024 + 1)
    if len(datos) > 4 * 1024 * 1024:
        raise HTTPException(400, "La portada no puede pasar de 4 MB")
    PORTADAS_DIR.mkdir(exist_ok=True)
    nombre = f"empresa_{ctx.empresa.id}.{ext}"
    if n.portada_nombre and n.portada_nombre != nombre:
        (PORTADAS_DIR / n.portada_nombre).unlink(missing_ok=True)
    (PORTADAS_DIR / nombre).write_bytes(datos); n.portada_nombre = nombre; s.add(n); s.commit()
    return {"ok": True, "portada": f"/api/pedidos/negocio/portada?v={int(time.time())}"}


@router.delete("/api/pedidos/negocio/portada")
def quitar_portada(ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id)
    if n.portada_nombre:
        (PORTADAS_DIR / n.portada_nombre).unlink(missing_ok=True); n.portada_nombre = None; s.add(n); s.commit()
    return {"ok": True}


@router.get("/api/pedidos/negocio/portada", include_in_schema=False)
def ver_portada(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id)
    if not n.portada_nombre or not (PORTADAS_DIR / n.portada_nombre).exists():
        raise HTTPException(404)
    return FileResponse(PORTADAS_DIR / n.portada_nombre, headers={"Cache-Control": "no-store"})


# ------------------------------------------------------------------------------------------------- bandeja de pedidos
class EstadoIn(BaseModel):
    estado: str
    motivo: Optional[str] = PField(None, max_length=200)
    reclama: bool = False      # 4.31: la pestaña reclama la comanda antes de imprimirla (una pestaña anterior no lo manda)
    aqui: bool = False         # 4.32: «Aceptar y atenderlo aquí»: lo atiende la página web aunque esté elegido un programa


@router.get("/api/pedidos")
def listar(estado: Optional[str] = None, desde: Optional[str] = None, hasta: Optional[str] = None, contacto_id: Optional[int] = None, telefono: Optional[str] = None,
           ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    q = select(Pedido).where(Pedido.empresa_id == eid)
    # 4.9: los pedidos de una revendedora (contacto_id) o el historial de un cliente (teléfono): sin el tope de los últimos 3 días y hasta
    # 5000 (antes la pantalla pedía todas las fechas y filtraba en el navegador, y perdía lo anterior a los 500 más nuevos)
    filtrado = contacto_id is not None or bool((telefono or "").strip())
    if contacto_id is not None:
        q = q.where(Pedido.contacto_id == contacto_id)
    if (telefono or "").strip():
        q = q.where(Pedido.telefono == _tel(telefono))
    if desde:
        q = q.where(Pedido.creado >= desde[:10])
    if hasta:
        q = q.where(Pedido.creado <= hasta[:10] + "T99")
    if not desde and not hasta and not filtrado:
        q = q.where(Pedido.creado >= (ahora_cr() - timedelta(days=3)).date().isoformat())
    ps = s.exec(q.order_by(Pedido.id.desc())).all()[:5000 if filtrado else 500]
    est = estado_efectivo(s, eid, ps)
    ens: dict = {}
    if "entregas" in planes.modulos_de(ctx.empresa):
        from . import entregas
        motos = {m.id: m for m in s.exec(select(entregas.Motorizado).where(entregas.Motorizado.empresa_id == eid)).all()}
        for x in s.exec(select(entregas.Entrega).where(entregas.Entrega.empresa_id == eid, entregas.Entrega.pedido_id.in_([p.id for p in ps] or [0]))).all():  # type: ignore[attr-defined]
            if x.estado != "cancelada" or x.pedido_id not in ens:
                ens[x.pedido_id] = {**entregas._salida_entrega(x, motos), "pin": x.pin}   # 3.87: el detalle del pedido muestra el PIN (como «Publicar express»)
    nombres = {i["terminal"]: i["nombre"] for i in instalaciones_vigentes(s, eid)} if any(int(p.atiende or 0) > 0 for p in ps) else {}   # 4.32
    out = [{**_con_atiende(s, eid, _salida_pedido(p, est[p.id]), p, nombres), "entrega": ens.get(p.id)} for p in ps]
    # 4.39 (prueba de punta a punta): el comprobante con que se cobró el pedido (Ventas en línea › Pedidos y «Detalle y bitácora» lo muestran):
    # antes se sabía que estaba cobrado pero no con cuál; una consulta para toda la lista, solo con los pedidos que tienen documento
    con_doc = list({p.documento_id for p in ps if p.documento_id})
    docs = {d_id: (tipo, cons) for d_id, tipo, cons in s.exec(select(Documento.id, Documento.tipo_documento, Documento.consecutivo).where(
        Documento.empresa_id == eid, Documento.id.in_(con_doc))).all()} if con_doc else {}  # type: ignore[union-attr]
    for o in out:
        d = docs.get(o.get("documento_id"))
        o["comprobante"] = (NOMBRES_DOC.get(d[0], "Comprobante") + " " + str(d[1] or "")[-10:]).strip() if d else ""
    if estado:
        out = [p for p in out if p["estado"] == estado]
    else:
        out = [p for p in out if p["estado"] != "pendiente_pago"]
    return out


@router.get("/api/pedidos/resumen")
def resumen(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Para el aviso de la barra y el sonido de la caja: cuántos pedidos nuevos esperan y el último id.
    4.31: también cuántas comandas de pedidos esperan imprimirse (comandas_pendientes) y en cuántos segundos la más próxima puede salir
    sola (comanda_espera_s, null si ninguna): el indicio de la estación de comandas."""
    eid = ctx.empresa.id
    nuevos = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.estado == "nuevo").order_by(Pedido.id.desc())).all()
    from . import comandas
    out = {"nuevos": len(nuevos), "ultimo_id": nuevos[0].id if nuevos else 0, "hace": nuevos[-1].creado if nuevos else None, **comandas.resumen_comandas(s, eid)}
    if en_programa_v2(eid):
        # 4.32 (§4.2): los pagados con tarjeta nunca son «nuevo»: el aviso de la caja suena también con el último pedido que entró a esta caja
        from . import pedidos_programa
        out["ultimo_entrado_id"] = pedidos_programa.ultimo_entrado_id(s, eid)
        pedidos_programa.purgar_copias(s, eid)
        # validación 4.32 (B): un pedido ya pagado con tarjeta que tomó la página web (este programa no estaba atendiendo) no entra a esta
        # caja ni saca comanda aquí: el resumen lo nombra para que la Caja y la franja avisen que hay que verlo en la página web
        desde = (ahora_cr() - timedelta(hours=12)).isoformat(timespec="seconds")
        web = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.estado == "confirmado", Pedido.pago_estado == "aprobado",
                                          or_(Pedido.atiende == None, Pedido.atiende == 0), Pedido.documento_id == None,  # noqa: E711
                                          Pedido.creado >= desde).order_by(Pedido.id)).all()
        if web:
            out["pagados_en_la_web"] = [int(p.numero or p.id) for p in web]
            out["aviso_web"] = ("El pedido en línea #%s ya está pagado y lo atiende la página web: ábrala para ver su cuenta y su comanda." % out["pagados_en_la_web"][0]
                                if len(web) == 1 else "Los pedidos en línea #%s ya están pagados y los atiende la página web: ábrala para ver sus cuentas y sus comandas."
                                % ", #".join(str(n) for n in out["pagados_en_la_web"]))
    return out


def terminales_pos(cfg) -> list:
    """4.7: las cajas tal como las ve la pantalla del punto de venta (pos/_datos.js config()): las guardadas; la configuración vieja de
    una sola caja (1.22) cuenta como la caja 1; y sin nada guardado, la «Caja 1» que la pantalla usa por defecto. Antes, una empresa que
    vendía con esa caja por defecto (sin haber guardado nunca Punto de venta › Configuración) no podía aceptar pedidos en línea:
    «Configure una caja en Punto de venta › Configuración para recibir pedidos»."""
    if isinstance(cfg, dict) and isinstance(cfg.get("terminales"), list):
        ts = [t for t in cfg["terminales"] if isinstance(t, dict)]
        if ts:
            return ts
    if isinstance(cfg, dict) and cfg:
        resto = {k: v for k, v in cfg.items() if k not in ("terminales", "nombre_caja")}
        return [{**resto, "id": 1, "nombre": cfg.get("nombre") or cfg.get("nombre_caja") or "Caja 1"}]
    return [{"id": 1, "nombre": "Caja 1"}]


def _terminal(s: Session, eid: int, n: NegocioPublico) -> Optional[dict]:
    ts = terminales_pos(modulos.leer(s, eid, "pos_config", None))
    return next((t for t in ts if n.terminal_id and int(t.get("id") or 0) == int(n.terminal_id)), ts[0])


def exigir_caja(e: Empresa) -> None:
    """4.7: los pedidos en línea entran como cuentas de la caja: sin el Punto de venta en el plan no hay dónde cobrarlos."""
    if "pos" not in planes.modulos_de(e):
        raise HTTPException(400, "Para aceptar pedidos en línea su plan necesita el Punto de venta: cada pedido entra como una cuenta de la caja, que es donde se cobra")


def _prepago(p: Pedido) -> Optional[dict]:
    """Lo que el pedido ya pagó antes de llegar a la caja: tarjeta de regalo (3.49) y/o tarjeta en línea (3.50)."""
    regalo = r2(p.tarjeta_monto or 0); online = r2(p.pago_monto or 0) if p.pago_estado == "aprobado" else 0.0
    if regalo <= 0 and online <= 0:
        return None
    return {"tarjeta": p.tarjeta_codigo or "", "monto": r2(regalo + online), "regalo": regalo, "online": online, "referencia": p.pago_referencia or "",
            "medio": "06" if p.pago_medio == "sinpe" else "02"}   # 4.9: medio del pago en línea (SINPE Móvil o tarjeta) para la caja


def modo_numerar_comanda(t) -> str:
    """4.29 (W-6): cómo numera las comandas la caja, con la misma regla que la pantalla (pos/_datos.js modoNumerarComanda): solo una
    caja de restaurante con «dia» o «continuo»; cualquier otra cosa (caja vieja sin el campo, valor raro) = no numera ('')."""
    if isinstance(t, dict) and t.get("modo") == "restaurante" and t.get("numerar_comanda") in ("dia", "continuo"):
        return t["numerar_comanda"]
    return ""


def _numero_comanda(s: Session, eid: int, t) -> Optional[int]:
    """4.29 (W-6): el número consecutivo de la comanda de un pedido en línea, con el mismo contador que la ruta de la caja
    (comandas.siguiente, POST /api/pos/comanda/numero). Si la caja no numera, None sin tocar nada. Nunca falla: cualquier error es «sin
    número» y el pedido entra igual. Lo pendiente de la sesión (el pago aprobado de Tilopay) se guarda antes, porque el contador hace commit
    y deshacer un error no debe llevarse eso."""
    modo = modo_numerar_comanda(t)
    if not modo:
        return None
    s.commit()   # fuera del try: si guardar lo pendiente falla, el error sube (como antes el commit de a_caja) y no se deshace el pago en silencio
    try:
        from . import comandas
        n, _ = comandas.siguiente(s, eid, modo)
        n = int(n)
        return n if n >= 1 else None
    except Exception as ex:  # noqa: BLE001  (el número de comanda nunca impide aceptar el pedido)
        logging.getLogger(__name__).warning("Número de comanda del pedido en línea (empresa %s): %s", eid, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return None


def a_caja(s: Session, eid: int, p: Pedido, n: NegocioPublico, origen: Optional[str] = None, listo: Optional[str] = None) -> int:
    """Crea la cuenta en espera del pedido (registro pos_espera) con la comanda enviada: la caja la cobra y el monitor la prepara.
    4.29 (W-6): si esa caja numera las comandas, las líneas que van a cocina llevan «comanda» con el número siguiente (uno para todas
    sus impresoras); si no numera, la cuenta es la de siempre (sin el campo).
    4.31: en el mismo commit que la cuenta queda la copia fija de su comanda (comandas.guardar_copia), de la que imprime la estación
    de comandas. `origen`: «pago» si el pedido sigue en pendiente_pago (tarjeta aprobada); si no, el que pasa cambiar_estado
    («aceptar» con una pestaña que reclama, «aceptar_anterior» sin ella). La copia nunca impide crear la cuenta.
    4.32: `listo` (el programa, para un pedido que llegó tarde) = desde cuándo puede salir sola su comanda (comandas.guardar_copia)."""
    t = _terminal(s, eid, n)
    if not t:
        raise HTTPException(400, "Configure una caja en Punto de venta › Configuración para recibir pedidos")
    ahora = ahora_cr().isoformat(timespec="seconds")
    numero = _numero_comanda(s, eid, t)
    con_numero = {"comanda": numero} if numero else {}
    lineas = [{"producto_id": l["producto_id"], "detalle": l["detalle"], "cabys": l.get("cabys"), "cantidad": l["cantidad"], "precio_unitario": l["precio_unitario"], "descuento": 0, "descuento_pct": 0,
               "codigo_tarifa": l.get("codigo_tarifa"), "tarifa": l.get("tarifa", 0), "es_servicio": l.get("es_servicio", False), "unidad_medida": l.get("unidad_medida", "Unid"), "precio_manual": False,
               "nota": ", ".join(x for x in (", ".join(o["nombre"] for o in (l.get("opciones") or [])), l.get("nota") or "") if x), "opciones": l.get("opciones") or [], "enviado": ahora, "ronda": 1, **con_numero} for l in _json(p.lineas, [])]
    desc = r2((p.descuento or 0) + (p.descuento_puntos or 0)); bruto = r2((p.subtotal or 0) + (p.impuestos or 0))
    if desc > 0 and bruto > 0:                                  # el descuento del cupón o de los puntos se reparte en cada línea (así lo refleja el tiquete)
        pct = round(min(100.0, desc / bruto * 100), 4); etiqueta = ("Cupón " + p.cupon_codigo) if p.cupon_codigo else "Puntos"
        for l in lineas:
            l["descuento_pct"] = pct; l["descuento"] = r2(l["cantidad"] * l["precio_unitario"] * pct / 100); l["promo"] = etiqueta
    if p.envio:
        lineas.append({"producto_id": None, "detalle": "Envío a domicilio", "cabys": "7332000000000", "cantidad": 1, "precio_unitario": r2(p.envio / 1.13), "descuento": 0, "descuento_pct": 0, "codigo_tarifa": "08", "tarifa": 13,
                       "es_servicio": True, "unidad_medida": "Sp", "precio_manual": True, "nota": "", "enviado": None, "ronda": 0})   # cargo, no va a cocina
    r = modulos._registro(s, eid, "pos_espera")
    existentes = [int(x.get("id") or 0) for x in (modulos.leer(s, eid, "pos_espera", []) or []) if isinstance(x, dict)]
    rp = modulos.rango_propio(eid)
    base = max([i for i in existentes if modulos.en_rango(i, rp)] + [(r.ultimo_id or 0) if r and modulos.en_rango(r.ultimo_id or 0, rp) else 0, rp * modulos.RANGO])
    nuevo = base + 1
    cuenta = {"id": nuevo, "nombre": f"Pedido #{p.numero} · {p.nombre}" + (" · A crédito" if p.a_credito else ""), "cliente_id": p.contacto_id, "credito": bool(p.a_credito), "lineas": lineas,
              "nota": (("A crédito (revendedora). " if p.a_credito else "") + (p.nota or "")).strip(), "servicio": False, "servicio_pct": 0, "creado": ahora, "actualizado": ahora,
              "usuario": "pedidos en línea", "total": p.total, "mesa_id": None, "terminal_id": t.get("id"), "salonero": "", "pedido": "domicilio" if p.tipo in ("domicilio", "coordinado") else "llevar",
              "canal": "online", "pedido_id": p.id, "pedido_numero": p.numero, "telefono": p.telefono, "direccion": p.direccion, "hora_entrega": p.hora_programada, "estado": "en_cocina", "mesas_ids": [], "cobros": [], "partes": None,
              "prepago": _prepago(p), "cupon": p.cupon_codigo or None, "puntos_canjeados": p.puntos_canjeados or 0}
    from . import comandas
    # 4.31: la copia se escribe justo antes de aplicar_cambios, que hace el commit de las dos (si guardar la cuenta falla, no queda copia)
    origen = "pago" if p.estado == "pendiente_pago" else (origen if origen in comandas.ORIGENES else "aceptar_anterior")
    comandas.guardar_copia(s, eid, p, cuenta, nuevo, origen, listo=listo)
    # 4.32 (contrato D-2): la cuenta, su copia y Pedido.cuenta_espera_id quedan en el mismo commit (el de aplicar_cambios). En el programa es
    # la señal de «ya tomado»: la cuenta de un pedido se crea una sola vez en su vida, aunque después se cobre y salga de pos_espera
    p.cuenta_espera_id = nuevo; s.add(p)
    _, remap = modulos.aplicar_cambios(s, eid, "pos_espera", [cuenta], [], [nuevo])
    final = int(remap.get(str(nuevo), remap.get(nuevo, nuevo)))   # aplicar_cambios da el remap con claves de texto
    if final != nuevo:
        comandas.cambiar_cuenta_copia(s, eid, p.id, nuevo, final)
        p.cuenta_espera_id = final; s.add(p)
    s.commit()
    return final


def vincular_documento(s: Session, e: Empresa, pedido_id, doc, parcial: bool = False) -> Optional[int]:
    """4.9: la caja cobró la cuenta de un pedido en línea con este comprobante (ComprobanteIn.pedido_id). Se llama dentro de la transacción de
    crear_comprobante, después del flush del documento y sin commit. Queda Pedido.documento_id (el primer documento gana: en un cobro por
    partes, la primera parte). `parcial` (ComprobanteIn.pedido_parcial: la caja lo manda cuando el cobro no cierra el pedido porque quedan
    partes o cuentas «aparte» en la espera): el pedido no cambia de estado ni se avisa al cliente. Con el cobro que lo cierra, si seguía
    «confirmado» pasa a «entregado», salvo que tenga una entrega abierta (Entregas la cierra y avisa al cliente). Un pedido a crédito solo se
    enlaza con un comprobante a nombre de su revendedora (contacto_id); cobrado a otro cliente se entrega igual, sin enlazarse (4.9). Devuelve
    el id del pedido si pasó a entregado (para avisar al cliente después del commit); si no, None.
    Antes nada escribía documento_id y el pedido quedaba «confirmado» para siempre: su total seguía en «en pedidos» además del saldo."""
    try:
        p = s.get(Pedido, int(pedido_id))
    except (TypeError, ValueError):
        return None
    eid = e.id
    if not p or p.empresa_id != eid or p.estado not in ("confirmado", "entregado") or doc is None or doc.tipo_documento not in ("01", "04"):
        return None
    if en_programa_v2(eid):
        # 4.32 (§4.5): aquí el pedido es una copia de la web: su estado lo cambia la web al enlazar el comprobante que sube. Solo queda el
        # comprobante local (campo propio del programa, el goteo no lo pisa), para que la pantalla lo muestre
        if not p.documento_id:
            p.documento_id = doc.id; s.add(p)
        return None
    if p.documento_id and (parcial or p.estado != "confirmado"):
        return None                                             # 4.9: ya enlazado y sin estado que cambiar (otra parte del mismo cobro)
    try:
        lista = [x for x in (modulos.leer(s, eid, "pos_espera", []) or []) if isinstance(x, dict)]
        cta = next((x for x in lista if p.cuenta_espera_id and x.get("id") == p.cuenta_espera_id), None)
        if cta is not None and cta.get("pedido_id") not in (None, p.id):
            return None
        otro = bool(p.contacto_id and doc.cliente_id != p.contacto_id)
        if otro and cta is None and not any(str(x.get("pedido_id") or "") == str(p.id) for x in lista):
            return None                                         # venta sin conexión reenviada a nombre de otro (ninguna cuenta del pedido en la caja): no es este pedido
        ahora = ahora_cr().isoformat(timespec="seconds"); pasa = False
        if not p.documento_id and not (otro and p.a_credito):
            p.documento_id = doc.id; p.actualizado = ahora      # el primer documento gana
        # 4.9: el comprobante de otro cliente (el cajero cambió el cliente al cobrar) no se enlaza al pedido a crédito: no es de la cuenta de la
        # revendedora ni sale en su estado de cuenta. Pero el cobro que lo cierra sí lo entrega: antes quedaba «confirmado» sin comprobante y se
        # podía cancelar ya cobrado (devolvía la tarjeta de regalo y revertía puntos y cupón)
        if p.estado == "confirmado" and not parcial:            # 4.9: solo el cobro que cierra el pedido lo entrega (y avisa al cliente)
            abierta = False
            if "entregas" in planes.modulos_de(e):
                from . import entregas
                en = entregas.entrega_de_pedido(s, eid, p.id); abierta = bool(en and en.estado in entregas.ABIERTAS)
            if not abierta:
                p.estado = "entregado"; p.entregado = ahora; p.actualizado = ahora; pasa = True
        s.add(p)
        return p.id if pasa else None
    except Exception as ex:  # noqa: BLE001  (el enlace con el pedido no detiene la venta)
        logging.getLogger(__name__).warning("Enlace del pedido %s con el comprobante %s: %s", pedido_id, getattr(doc, "id", None), ex)
        return None


# ------------------------------------------------------------------------------------------------- 4.32: pedidos que atiende el programa
# Plan reingenieria_432 §3, §4.1 a §4.8 y contrato_432. Todo esto corre en la WEB (en el programa, _en_programa() lo apaga): quién atiende
# cada pedido (Pedido.atiende), el enlace del cobro que sube del programa, el 409 de cobro y de cancelar, y el rescate del administrador.
SEGUNDOS_LLAMADA = 90        # §4.1: el programa llamó a /api/sinc/datos hace menos de esto (y con la estación de comandas viva)
MINUTOS_RESCATE = 10         # §3: «Atenderlo aquí» solo con esa computadora sin conectarse desde hace más de esto
DIAS_SIN_VENTAS_WEB = 30     # §4.1: atiende_terminal se llena solo si en estos días no se emitió ningún comprobante en la web
TEXTO_COBRO_AJENO = "Este pedido lo atiende «{nombre}»: cóbrelo allá."
TEXTO_CANCELAR_AJENO = "Este pedido lo atiende «{nombre}»: cancélelo allá, en Ventas en línea › Pedidos."
TEXTO_CANCELAR_WEB = "Este pedido lo atiende la página web: cancélelo allá."
TEXTO_ACEPTAR_WEB = "Los pedidos en línea de esta empresa los atiende la página web: acéptelo allá."
TEXTO_YA_COBRADO = "El pedido ya tiene comprobante: anule esa venta desde la caja o cobre lo que falta"
TEXTO_SOLO_WEB = "Esto se hace en la página web."
TEXTO_OPCION_APAGADA = "Esta opción no está disponible ahora."
TEXTO_COBRADO_EN_PROGRAMA = ("Este pedido ya se cobró en la computadora «{nombre}» (llegó su comprobante): no lo cobre otra vez aquí. "
                             "Revise esa venta y quite la cuenta de la caja.")
TEXTO_REEMBOLSO_PROGRAMA = "Cancelado desde «{nombre}»: devuelva el pago desde su cuenta de Tilopay (o el SINPE desde su banco)."
TEXTO_RESCATE = ("La computadora «{nombre}» no se conecta desde {hace}. Si la atiende aquí y allá ya la cobraron sin conexión, se cobraría dos veces. "
                 "¿Atenderla aquí de todos modos?")
TEXTO_RESCATE_ESPERE = ("La computadora «{nombre}» se conectó hace {hace}: el pedido sigue en su caja. Si pasan {minutos} minutos sin que se conecte, "
                        "podrá atenderlo aquí.")


def _en_programa() -> bool:
    """True en el programa de escritorio (FE_MODO_LOCAL=1, sinc.MODO_LOCAL): ahí nada de esta sección decide nada."""
    from . import sinc
    return bool(sinc.MODO_LOCAL)


def en_programa_v2(eid: int) -> bool:
    """4.32: el programa de escritorio con el canal nuevo (protocolo 2). Ahí cada pedido es una copia de la web: aceptarlo o cancelarlo se
    pide a la web en el momento (app/pedidos_programa.py) y lo de la tienda se hace en la página web. Sin el canal nuevo: False (la 4.31)."""
    if not _en_programa():
        return False
    try:
        from . import sinc_datos_programa as _sdp
        return int(_sdp.protocolo(eid) or 0) == 2
    except Exception:  # noqa: BLE001  (sin el canal nuevo, como la 4.31)
        return False


def solo_en_la_web(eid: int) -> None:
    """4.32: en el programa con el canal nuevo, lo que solo se hace en la página web (verificar un SINPE, configurar la tienda, elegir quién
    atiende, el rescate): 409 con el texto de siempre. En la web y en el programa sin el canal nuevo no hace nada."""
    if en_programa_v2(eid):
        raise HTTPException(409, TEXTO_SOLO_WEB)


def anotar_fila(s: Session, tipo: str, ref) -> None:
    """4.32: anota un dato que cambió un UPDATE crudo (el oyente de la sincronización solo ve el ORM), dentro de la transacción de `s` y antes
    de su commit. La función de verdad es sinc_datos.anotar_fila (contrato §3.1, P1); mientras ese módulo no exista, no hace nada. Nunca lanza."""
    try:
        from . import sinc_datos as _sd
        f = getattr(_sd, "anotar_fila")
    except Exception:  # noqa: BLE001  (sin el mecanismo nuevo no hay nada que anotar)
        return
    try:
        f(s, tipo, ref)
    except Exception as ex:  # noqa: BLE001
        logging.getLogger(__name__).warning("No se pudo anotar el cambio de %s %s: %s", tipo, ref, type(ex).__name__)


def interruptores_encendidos() -> bool:
    """§4.1 y §5 del contrato: FE_SINC_DATOS y FE_PEDIDOS_PROGRAMA (los dos encendidos salvo «0»); FE_SINC_DATOS=0 implica el otro apagado.
    Se leen en cada llamada (las pruebas usan monkeypatch.setenv)."""
    return os.environ.get("FE_SINC_DATOS", "1") != "0" and os.environ.get("FE_PEDIDOS_PROGRAMA", "1") != "0"


def canal_apagado() -> bool:
    """Revisión 4.32 (marcha atrás, plan §7): FE_SINC_DATOS=0. Los programas 4.32 quedan en pausa (no pueden aceptar, cancelar ni bajar
    pedidos por el canal nuevo): un pedido que ya atendía un programa se cancela, se cobra y se rescata en la web como en la 4.31. Con solo
    FE_PEDIDOS_PROGRAMA=0 el canal sigue vivo y los ya asignados se terminan donde están (contrato l.551): esto da False."""
    return os.environ.get("FE_SINC_DATOS", "1") == "0"


def _ultima_llamada(eid: int, terminal: int):
    """(hora time.time(), estacion_viva) de la última llamada de esa terminal a /api/sinc/datos, o None. Revisión 4.32 (I-1): lo más reciente
    entre lo guardado en la base de la empresa (sinc_datos.contacto_guardado: lo ven todos los procesos del servidor, la cola y el cron) y la
    memoria de este proceso (sinc_datos.ULTIMA_LLAMADA, que puede ir unos segundos adelante porque la base se escribe cada 20 s)."""
    try:
        from . import sinc_datos as _sd
    except Exception:  # noqa: BLE001
        return None
    mejor = None
    try:
        mem = getattr(_sd, "ULTIMA_LLAMADA", {}).get((int(eid), int(terminal)))
        if mem:
            mejor = (float(mem[0]), bool(mem[1]))
    except Exception:  # noqa: BLE001
        mejor = None
    leer = getattr(_sd, "contacto_guardado", None)
    if callable(leer):
        try:
            x = leer(int(eid), int(terminal))
            if x and (mejor is None or float(x[0]) > mejor[0]):
                mejor = (float(x[0]), bool(x[1]))
        except Exception as ex:  # noqa: BLE001  (si la base no contesta, queda la memoria: como hoy)
            logging.getLogger(__name__).warning("Última llamada de la terminal %s (empresa %s): %s", terminal, eid, type(ex).__name__)
    return mejor


def programa_vivo(eid: int, terminal: int) -> bool:
    """§4.1: esa terminal llamó a /api/sinc/datos en los últimos SEGUNDOS_LLAMADA segundos y en esa llamada dijo estacion_viva."""
    x = _ultima_llamada(eid, terminal)
    try:
        return bool(x) and time.time() - float(x[0]) <= SEGUNDOS_LLAMADA and bool(x[1])
    except (TypeError, ValueError, IndexError):
        return False


def atiende_para(eid: int, n: Optional[NegocioPublico], p: Pedido, terminal: Optional[int] = None) -> int:
    """§4.1: quién atiende el pedido al aceptarlo (o al aprobarse el pago): la terminal de NegocioPublico.atiende_terminal solo si el pedido no
    es a crédito, los interruptores están encendidos y (aceptado en la web o pagado) esa terminal habló con la web en los últimos 90 s con la
    estación de comandas viva. `terminal`: lo acepta ese programa (acción «aceptar»): lo atiende él solo si es la terminal elegida. Si falta
    cualquier cosa, 0: la web, como en la 4.31 (su a_caja y su comanda)."""
    if _en_programa() or p is None or p.a_credito or not interruptores_encendidos() or n is None:
        return 0
    try:
        t = int(n.atiende_terminal or 0)
    except (TypeError, ValueError):
        t = 0
    if t <= 0:
        return 0
    if terminal is not None:
        return t if int(terminal) == t else 0
    return t if programa_vivo(eid, t) else 0


def _vinculacion(s: Session, eid: int) -> dict:
    try:
        from . import sinc
        return sinc._leer(s, eid, sinc.CLAVE_VINC, {})
    except Exception:  # noqa: BLE001
        return {}


def instalaciones_vigentes(s: Session, eid: int) -> list:
    """[{terminal, nombre}] de las computadoras conectadas a la empresa (sinc_vinculacion.instalaciones; las retiradas no)."""
    out = []
    for i in _vinculacion(s, eid).get("instalaciones") or []:
        try:
            t = int(i.get("terminal") or 0) if isinstance(i, dict) else 0
        except (TypeError, ValueError):
            t = 0
        if t > 0:
            out.append({"terminal": t, "nombre": str(i.get("nombre") or "").strip()[:80] or f"Computadora {t}"})
    return out


def nombre_terminal(s: Session, eid: int, terminal) -> str:
    """Nombre de la computadora de esa terminal para los textos («Caja 1»), también si ya se retiró; si no se sabe, «Computadora N»."""
    try:
        t = int(terminal or 0)
    except (TypeError, ValueError):
        t = 0
    v = _vinculacion(s, eid)
    for i in list(v.get("instalaciones") or []) + list(v.get("retiradas") or []):
        try:
            if isinstance(i, dict) and int(i.get("terminal") or 0) == t and str(i.get("nombre") or "").strip():
                return str(i["nombre"]).strip()[:80]
        except (TypeError, ValueError):
            continue
    return f"Computadora {t}"


def _con_atiende(s: Session, eid: int, d: dict, p: Pedido, nombres: Optional[dict] = None) -> dict:
    """La salida de un pedido para las pantallas del negocio con quién lo atiende (la insignia «Lo atiende «{nombre}»», B7)."""
    t = int(p.atiende or 0)
    d["atiende"] = t
    d["atiende_nombre"] = ((nombres or {}).get(t) or nombre_terminal(s, eid, t)) if t > 0 else ""
    return d


def hay_cobro(s: Session, eid: int, pid: int) -> bool:
    """4.32: algún comprobante (de aquí o subido de un programa) se emitió con este pedido (Documento.pedido_id): ya se cobró, o una parte."""
    return s.exec(select(Documento.id).where(Documento.empresa_id == eid, Documento.pedido_id == pid)).first() is not None


def texto_cobro_ajeno(s: Session, eid: int, pedido_id) -> Optional[str]:
    """4.32: en la web, el texto del 409 si el pedido lo atiende un programa (se cobra allá); None si se puede cobrar aquí. Lee la fila de la
    base (no la de la sesión), para que la revisión después del flush vea una aceptación que llegó entre tanto."""
    if not pedido_id or _en_programa():
        return None
    from sqlalchemy import text
    try:
        fila = s.execute(text(f"SELECT atiende FROM {Pedido.__tablename__} WHERE id = :id AND empresa_id = :e"), {"id": int(pedido_id), "e": eid}).first()
    except (TypeError, ValueError):
        return None
    t = int((fila[0] if fila else 0) or 0)
    if t > 0 and not canal_apagado():                      # con FE_SINC_DATOS=0 el programa está en pausa: se cobra aquí, como la 4.31
        return TEXTO_COBRO_AJENO.format(nombre=nombre_terminal(s, eid, t))
    # Revisión 4.32 (n.º 12): ya llegó un comprobante que un programa emitió con este pedido (p. ej. lo cobró sin conexión y después se
    # rescató aquí): cobrarlo en la web sería cobrarlo dos veces
    doc = s.exec(select(Documento.origen_sinc).where(Documento.empresa_id == eid, Documento.pedido_id == int(pedido_id),
                                                     Documento.origen_sinc != None, Documento.origen_sinc != "")).first()  # noqa: E711
    if doc:
        try:
            nombre = nombre_terminal(s, eid, int(str(doc).split(":")[0]))
        except (TypeError, ValueError):
            nombre = str(doc)[:40]
        return TEXTO_COBRADO_EN_PROGRAMA.format(nombre=nombre)
    return None


def sin_revisar_existencias(s: Session, eid: int, pedido_id) -> bool:
    """4.32 (§4.5, R1-10): en el programa con el canal nuevo (protocolo 2), un comprobante que cobra un pedido en línea no revisa existencias:
    la venta ya ocurrió en la tienda (un ítem nuevo de la web puede no tener todavía su existencia aquí). En la web y en el programa sin el
    canal nuevo: False (se revisan como siempre)."""
    if not pedido_id or not _en_programa():
        return False
    try:
        from . import sinc_datos_programa as _sdp
        if int(_sdp.protocolo(eid) or 0) != 2:
            return False
    except Exception:  # noqa: BLE001  (sin el canal nuevo, como la 4.31)
        return False
    try:
        p = s.get(Pedido, int(pedido_id))
    except (TypeError, ValueError):
        return False
    if not (p is not None and p.empresa_id == eid and (p.canal or "online") == "online"):
        return False
    # Revisión 4.32 (n.º 30): solo el pedido que esta computadora atiende y tiene abierto en su caja (aceptado, suyo y con su cuenta)
    if p.estado not in ("confirmado", "entregado") or int(p.atiende or 0) <= 0:
        return False
    lista = modulos.leer(s, eid, "pos_espera", []) or []
    return any(isinstance(x, dict) and ((p.cuenta_espera_id and x.get("id") == p.cuenta_espera_id) or str(x.get("pedido_id") or "") == str(p.id))
               for x in lista)


def pedidos_programa_para(s: Session, eid: int, terminal) -> bool:
    """Contrato §2.2 (`pedidos_programa` de la respuesta de /api/sinc/datos, lo llama P1): esa terminal es la elegida para atender los pedidos
    y los dos interruptores están encendidos."""
    if not interruptores_encendidos():
        return False
    n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()
    try:
        return bool(n is not None and n.atiende_terminal and int(n.atiende_terminal) == int(terminal))
    except (TypeError, ValueError):
        return False


def fijar_atiende_al_sembrar(s: Session, eid: int, terminal) -> bool:
    """§4.1 (v2): cuando la empresa queda sembrada por su primer programa 4.32 (lo llama sinc_datos.sembrar, P1, en la transacción que
    escribe la marca, sin commit), «Los pedidos en línea los atiende» pasa a esa terminal SOLO si es la única instalación vigente, la tienda
    existe, nadie eligió antes y en los últimos DIAS_SIN_VENTAS_WEB días no se emitió ningún comprobante en la propia web
    (Documento.origen_sinc vacío, sin contar los históricos importados). En cualquier otro caso queda vacío (atiende la web, como hoy).
    True si lo fijó. Nunca lanza."""
    if _en_programa():
        return False
    from sqlalchemy import text
    try:
        t = int(terminal or 0)
        vig = instalaciones_vigentes(s, eid)
        if t <= 0 or len(vig) != 1 or vig[0]["terminal"] != t:
            return False
        desde = (ahora_cr() - timedelta(days=DIAS_SIN_VENTAS_WEB)).date().isoformat()
        if s.execute(text("SELECT 1 FROM documento WHERE empresa_id = :e AND origen_sinc IS NULL AND importado_de IS NULL AND fecha_emision >= :d LIMIT 1"),
                     {"e": eid, "d": desde}).first():
            return False
        n = s.execute(text(f"UPDATE {NegocioPublico.__tablename__} SET atiende_terminal = :t WHERE empresa_id = :e AND atiende_terminal IS NULL"),
                      {"t": t, "e": eid}).rowcount
        return bool(n)
    except Exception as ex:  # noqa: BLE001
        logging.getLogger(__name__).warning("Quién atiende los pedidos al sembrar (empresa %s): %s", eid, type(ex).__name__)
        return False


def _empresa(e) -> Optional[Empresa]:
    if isinstance(e, Empresa):
        return e
    with Session(engine) as sc:
        x = sc.get(Empresa, int(e))
        if x is not None:
            sc.expunge(x)
        return x


def enlazar_desde_programa(s: Session, e, pid: int, doc, parcial: bool, terminal: Optional[int] = None) -> Optional[int]:
    """4.32 (§4.5): en la web, el comprobante que subió el programa (sinc._guardar_documentos, dentro de su commit, sin commit propio) cobró
    el pedido `pid` que atiende un programa: es vincular_documento sin la búsqueda en pos_espera (en la web no está la cuenta). El primer
    comprobante queda enlazado (Pedido.documento_id); el cobro que cierra (no `parcial`) lo entrega, salvo una entrega abierta (Entregas lo
    cierra). Idempotente: un reenvío no hace nada nuevo. Devuelve el id del pedido si pasó a entregado (quien llama, después del commit,
    llama a tras_enlace: puntos y correo); si no, None. En el programa, o con cualquier error: None. Nunca lanza.
    Revisión 4.32 (n.º 34): `terminal` = la de la ficha de la computadora que subió el comprobante (no la que dice el cuerpo): si se da y no
    es la que atiende el pedido, no se enlaza (una computadora no cierra el pedido de otra)."""
    try:
        if _en_programa() or doc is None or getattr(doc, "tipo_documento", None) not in ("01", "04"):
            return None
        p = s.get(Pedido, int(pid))
        emp = _empresa(e)
        if p is None or emp is None or p.empresa_id != emp.id or int(p.atiende or 0) <= 0 or p.estado not in ("confirmado", "entregado"):
            return None
        if terminal is not None and int(terminal) != int(p.atiende):
            return None
        if p.documento_id and (parcial or p.estado != "confirmado"):
            return None                                             # ya enlazado y sin estado que cambiar
        ahora = ahora_cr().isoformat(timespec="seconds"); pasa = False; cambio = False
        if not p.documento_id:
            p.documento_id = doc.id; p.actualizado = ahora; cambio = True     # el primer comprobante gana
        if p.estado == "confirmado" and not parcial:
            abierta = False
            if "entregas" in planes.modulos_de(emp):
                from . import entregas
                en = entregas.entrega_de_pedido(s, emp.id, p.id); abierta = bool(en and en.estado in entregas.ABIERTAS)
            if not abierta:
                p.estado = "entregado"; p.entregado = ahora; p.actualizado = ahora; pasa = cambio = True
        if cambio:
            s.add(p)
        return p.id if pasa else None
    except Exception as ex:  # noqa: BLE001  (el enlace nunca detiene la subida del comprobante)
        logging.getLogger(__name__).warning("Enlace del pedido %s con un comprobante del programa: %s", pid, type(ex).__name__)
        return None


def tras_enlace(eid: int, pid: int) -> None:
    """4.32: después del commit del enlace que entregó el pedido: los puntos (la fórmula de «entregado»; idempotente por «pedido:<id>») y el
    correo «entregado» al cliente, desde la web. Nunca lanza."""
    try:
        from . import promociones
        with sesion_de(eid) as s:
            p = s.get(Pedido, int(pid))
            if p is None or p.empresa_id != eid or p.estado != "entregado":
                return
            promociones.acreditar(s, eid, telefono_puntos(s, p), r2((p.subtotal or 0) + (p.impuestos or 0) - (p.descuento or 0) - (p.descuento_puntos or 0)), f"pedido:{p.id}", p.nombre)
        avisar_cliente_id(eid, int(pid), "entregado")
    except Exception as ex:  # noqa: BLE001
        logging.getLogger(__name__).warning("Puntos y aviso del pedido %s entregado desde el programa: %s", pid, type(ex).__name__)


def reintentar_enlaces(s: Session, eid: int, terminal: Optional[int] = None, pedido_id: Optional[int] = None) -> list:
    """4.32 (§4.5, R3-3): el enlace que falló se repara solo. Para los pedidos «confirmado» que atiende un programa (de esa `terminal`, o
    solo `pedido_id`) con algún comprobante guardado (Documento.pedido_id), vuelve a pasar cada comprobante por enlazar_desde_programa, en
    orden. La llama sinc_datos (P1) en cada /api/sinc/datos de esa terminal y al llegar la copia o la lápida de una cuenta con pedido_id.
    Confirma ella misma y, después, tras_enlace de los que pasaron a entregado. Devuelve sus ids. Nunca lanza."""
    try:
        if _en_programa():
            return []
        q = select(Pedido.id).where(Pedido.empresa_id == eid, Pedido.estado == "confirmado", Pedido.atiende > 0)   # type: ignore[operator]
        if terminal is not None:
            q = q.where(Pedido.atiende == int(terminal))
        if pedido_id is not None:
            q = q.where(Pedido.id == int(pedido_id))
        ids = list(s.exec(q).all())
        if not ids:
            return []
        docs = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.pedido_id.in_(ids)).order_by(Documento.id)).all()   # type: ignore[union-attr]
        if not docs:
            return []
        emp = _empresa(eid); pasados = []
        for d in docs:
            r = enlazar_desde_programa(s, emp, d.pedido_id, d, bool(d.pedido_parcial))
            if r and r not in pasados:
                pasados.append(r)
        if s.dirty or s.new:
            s.commit()
        for x in pasados:
            tras_enlace(eid, x)
        return pasados
    except Exception as ex:  # noqa: BLE001
        logging.getLogger(__name__).warning("Reintento de enlaces de pedidos (empresa %s): %s", eid, type(ex).__name__)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return []


def _efectos_cancelar(s: Session, e: Empresa, n: NegocioPublico, p: Pedido, desde_programa: bool, nombre_programa: str = "") -> None:
    """La rama de cancelar de cambiar_estado (4.9-4.31), sacada sin cambiar lo que hace: la comanda ya no sale sola, se cancela la entrega,
    se devuelven cupón, puntos y tarjeta de regalo y se pide el reembolso del pago en línea. 4.32 (§4.7, R3-11): cancelado desde un
    programa (acción «cancelar» con el token de la computadora) NO llama a Tilopay: si había un pago en línea aprobado, queda
    «reembolso pendiente» y el negocio lo devuelve desde su cuenta de Tilopay o su banco. Así el token de una computadora nunca saca dinero."""
    eid = e.id
    from . import comandas, entregas, promociones
    comandas.cerrar_copia(s, eid, p.id, "cancelado")         # 4.31: su comanda ya no sale sola (va en el commit de quien llama)
    entregas.cancelar_entrega_de_pedido(s, eid, p.id)
    ref = f"pedido:{p.id}"; promociones.anular_uso(s, eid, ref); promociones.revertir(s, eid, ref)
    if p.tarjeta_codigo and p.tarjeta_monto:
        promociones.devolver_tarjeta(s, eid, p.tarjeta_codigo, p.tarjeta_monto, ref)
    if desde_programa:
        if p.pago_estado == "aprobado":
            p.pago_estado = "reembolso_pendiente"; p.pago_detalle = TEXTO_REEMBOLSO_PROGRAMA.format(nombre=nombre_programa or "el programa")
        return
    _reembolsar(e, n, p)


RECLAMO_CONFIRMAR_S = 60   # 4.29: un «Aceptar» que quedó a medias (sin cuenta en la caja) se puede retomar pasado este tiempo


def _confirmacion_pendiente(p: Pedido) -> bool:
    """4.29: «confirmado» sin cuenta en la caja ni comprobante: crear la cuenta falló y la vuelta atrás también (o el proceso se cerró en
    medio). «Aceptar» otra vez la crea.
    4.32: un pedido que atiende un programa (atiende > 0) nunca queda pendiente aquí: en la web no tiene cuenta a propósito (la cuenta y la
    comanda nacen en el programa). Antes se podía retomar a los 60 s y salían dos cuentas y dos comandas."""
    return p.estado == "confirmado" and not p.cuenta_espera_id and not p.documento_id and not int(p.atiende or 0) > 0


def _tomar_confirmacion(s: Session, pid: int, marca: str, atiende: int = 0) -> bool:
    """4.29: pasa el pedido a «confirmado» solo si sigue «nuevo», o si quedó confirmado sin cuenta y nadie lo está aceptando ahora (la marca
    en `confirmado` tiene más de RECLAMO_CONFIRMAR_S segundos o no hay marca). Comprobación y cambio en un solo UPDATE: de dos equipos que
    aceptan a la vez, uno solo lo logra. Deja `confirmado` = marca (el aceptar en curso) y lo guarda. True si lo tomó.
    4.32: en el mismo UPDATE decide quién lo atiende: `atiende` (la terminal del programa, o 0 = la web; un pedido a crédito siempre 0).
    La rama de retomar excluye los pedidos que atiende un programa (COALESCE(atiende, 0) = 0). El cambio se anota para la sincronización
    (sinc_datos.anotar_fila) antes del commit, porque el oyente no ve un UPDATE crudo."""
    from sqlalchemy import text
    vence = (ahora_cr() - timedelta(seconds=RECLAMO_CONFIRMAR_S)).isoformat(timespec="seconds")
    n = s.execute(text(f"UPDATE {Pedido.__tablename__} SET estado = 'confirmado', confirmado = :marca, atiende = CASE WHEN a_credito THEN 0 ELSE :t END "
                       "WHERE id = :id AND (estado = 'nuevo' OR "
                       "(estado = 'confirmado' AND cuenta_espera_id IS NULL AND documento_id IS NULL AND COALESCE(atiende, 0) = 0 "
                       "AND (confirmado IS NULL OR confirmado < :vence)))"),
                  {"marca": marca, "id": pid, "vence": vence, "t": int(atiende or 0)}).rowcount
    if n:
        anotar_fila(s, "pedido", pid)
    s.commit()
    return bool(n)


def _soltar_confirmacion(s: Session, pid: int, marca: str) -> None:
    """4.29: crear la cuenta falló: el pedido vuelve a «nuevo» (solo si sigue con la marca de este aceptar y sin cuenta). Si esto también
    falla, se anota y sigue el error original; el pedido queda «confirmado» sin cuenta y «Aceptar» lo retoma pasado RECLAMO_CONFIRMAR_S (_tomar_confirmacion)."""
    from sqlalchemy import text
    try:
        s.rollback()
        s.execute(text(f"UPDATE {Pedido.__tablename__} SET estado = 'nuevo', confirmado = NULL WHERE id = :id AND estado = 'confirmado' "
                       "AND cuenta_espera_id IS NULL AND confirmado = :marca"), {"id": pid, "marca": marca})
        anotar_fila(s, "pedido", pid)                           # 4.32: el oyente no ve el UPDATE crudo
        s.commit()
    except Exception as ex:  # noqa: BLE001  (no tapa el error de crear la cuenta)
        logging.getLogger(__name__).warning("Pedido %s: no se pudo volver a «nuevo» tras fallar la cuenta en la caja: %s", pid, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass


@router.put("/api/pedidos/{pid}/estado")
def cambiar_estado(pid: int, data: EstadoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return _cambiar_estado(pid, data, ctx, s)


def _cambiar_estado(pid: int, data: EstadoIn, ctx: Contexto, s: Session, terminal: Optional[int] = None):
    """La ruta PUT /api/pedidos/{pid}/estado. 4.32: `terminal` = lo pide el programa de esa terminal (acciones «aceptar» y «cancelar» de
    app/pedidos_programa.py, con el token de la computadora): al aceptar, el pedido queda de ese programa (atiende) y aquí no se crea la
    cuenta; al cancelar, no se pide el reembolso a Tilopay."""
    if terminal is None and en_programa_v2(ctx.empresa.id):
        from . import pedidos_programa                            # 4.32 (§4.3, §4.7): en el programa se pide a la web en el momento
        return pedidos_programa.cambiar_en_programa(pid, data, ctx, s)
    eid = ctx.empresa.id; p = s.get(Pedido, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    if data.estado not in ESTADOS:
        raise HTTPException(400, "Estado desconocido")
    ahora = ahora_cr().isoformat(timespec="seconds")
    if data.estado == "confirmado":
        if p.estado != "nuevo" and not _confirmacion_pendiente(p):
            raise HTTPException(400, f"El pedido está «{NOMBRES_ESTADO.get(p.estado, p.estado)}»; solo se confirma un pedido nuevo")
        exigir_caja(ctx.empresa)                                  # 4.7: mensaje claro si el plan no trae el Punto de venta
        # 4.32 (§4.1): quién lo atiende se decide aquí y se guarda en el mismo UPDATE que lo toma; «Aceptar y atenderlo aquí» (aqui) = la web
        t = 0 if data.aqui else atiende_para(eid, _negocio(s, eid), p, terminal)
        if terminal is not None and t != int(terminal):
            raise HTTPException(409, TEXTO_ACEPTAR_WEB)
        # 4.29: dos equipos que aceptan a la vez: el cambio a «confirmado» se hace en un solo UPDATE condicionado; solo quien lo logra crea
        # la cuenta (e imprime la comanda). Si crear la cuenta falla, el pedido vuelve a «nuevo»; si eso también falla (o el proceso se
        # cierra en medio), queda «confirmado» sin cuenta y «Aceptar» lo retoma.
        if not _tomar_confirmacion(s, p.id, ahora, t):
            s.refresh(p)
            extra = (". Otro equipo lo está aceptando: si en un minuto no aparece en la caja, toque «Aceptar» otra vez" if _confirmacion_pendiente(p) else "")
            raise HTTPException(400, f"El pedido está «{NOMBRES_ESTADO.get(p.estado, p.estado)}»; solo se confirma un pedido nuevo{extra}")
        p.atiende = 0 if p.a_credito else t                       # lo mismo que acaba de guardar el UPDATE (CASE WHEN a_credito THEN 0)
        if not p.atiende:
            try:
                p.cuenta_espera_id = a_caja(s, eid, p, _negocio(s, eid), "aceptar" if data.reclama else "aceptar_anterior")   # 4.31
            except Exception:
                _soltar_confirmacion(s, p.id, ahora)
                raise
        # 4.32 (§4.3): con atiende > 0 la cuenta, la copia de la comanda y su número nacen en ese programa cuando le llega el pedido; aquí no
        p.estado = "confirmado"; p.confirmado = ahora
        if p.tipo in ("domicilio", "coordinado") and "entregas" in planes.modulos_de(ctx.empresa):
            from . import entregas
            s.add(p); s.commit(); entregas.crear_entrega(s, eid, p)
    elif data.estado == "cancelado":
        if p.estado in ("cancelado", "entregado"):
            raise HTTPException(400, "Ese pedido ya está cerrado")
        if int(p.atiende or 0) > 0 and not _en_programa() and (terminal is None or int(terminal) != int(p.atiende)) and not canal_apagado():
            # 4.32 (§4.7): lo atiende un programa: allá están su cuenta y sus cobros; aquí solo tras el rescate del administrador
            raise HTTPException(409, TEXTO_CANCELAR_AJENO.format(nombre=nombre_terminal(s, eid, p.atiende)))
        if p.documento_id:
            # 4.9: ya se cobró en la caja (o una parte: pedido_parcial, o espera una entrega abierta): cancelarlo devolvía la tarjeta de regalo ya
            # aplicada al tiquete y dejaba las otras partes a crédito en la caja de un pedido «Cancelado»
            raise HTTPException(400, TEXTO_YA_COBRADO)
        if not (data.motivo or "").strip():
            raise HTTPException(400, "Indique el motivo de la cancelación")
        # 4.9: todas sus cuentas de la caja: la de cuenta_espera_id y las partes / cuentas «aparte» con su pedido_id (antes solo la primera:
        # las partes quedaban en la caja y se podían fiar a la revendedora de un pedido cancelado)
        lista = modulos.leer(s, eid, "pos_espera", []) or []
        ctas = [x for x in lista if isinstance(x, dict) and ((p.cuenta_espera_id and x.get("id") == p.cuenta_espera_id) or str(x.get("pedido_id") or "") == str(p.id))]
        if p.a_credito and p.estado == "confirmado" and p.cuenta_espera_id and _prepago(p) and not any(_prepago_de_cuenta(x) > 0 for x in ctas):
            # 4.9: la cuenta que llevaba la tarjeta de regalo ya no está en la caja: se cobró (a otro cliente, por eso sin documento_id) y la
            # tarjeta ya se aplicó a ese tiquete; cancelar la devolvía otra vez
            raise HTTPException(400, "La parte del pedido pagada con tarjeta de regalo ya se cobró en la caja: anule esa venta desde la caja")
        if any(x.get("cobros") or [] for x in ctas):
            raise HTTPException(400, "La cuenta ya tiene cobros en la caja: anule la venta desde la caja")
        if hay_cobro(s, eid, p.id):
            # 4.32 (R1-4): cualquier comprobante con este pedido (también el de una parte o una cuenta «aparte», o uno subido de un programa
            # cuyo enlace falló) ya cobró algo. Va después de los avisos de la 4.9, que dicen más
            raise HTTPException(409, TEXTO_YA_COBRADO)
        if ctas:
            modulos.aplicar_cambios(s, eid, "pos_espera", [], [x["id"] for x in ctas], [])
        p.estado = "cancelado"; p.motivo = data.motivo.strip()
        _efectos_cancelar(s, ctx.empresa, _negocio(s, eid), p, desde_programa=terminal is not None,
                          nombre_programa=nombre_terminal(s, eid, terminal) if terminal is not None else "")
    elif data.estado == "entregado":
        if p.estado == "cancelado":
            raise HTTPException(400, "Un pedido cancelado no se puede entregar")
        p.estado = "entregado"; p.entregado = ahora
        from . import promociones
        promociones.acreditar(s, eid, telefono_puntos(s, p), r2((p.subtotal or 0) + (p.impuestos or 0) - (p.descuento or 0) - (p.descuento_puntos or 0)), f"pedido:{p.id}", p.nombre)   # 3.87: a la cuenta con que se pidió
        if p.cuenta_espera_id:
            from . import comandas   # 4.31 (L-9): la cuenta se lee dentro del bloqueo: no pisa un plato que la caja guardó en ese instante
            comandas.reescribir_cuentas(s, eid, lambda x: x.get("id") == p.cuenta_espera_id,
                                        lambda c: None if c.get("estado") == "entregado" else {**c, "estado": "entregado", "hora_entregado": ahora})
    else:
        raise HTTPException(400, "En preparación y Listo los pone la caja o el monitor de preparación")
    p.actualizado = ahora; s.add(p); s.commit(); s.refresh(p)
    avisar_cliente(ctx.empresa, _negocio(s, eid), p, data.estado)
    out = _con_atiende(s, eid, _salida_pedido(p, estado_efectivo(s, eid, [p])[p.id]), p)
    if "entregas" in planes.modulos_de(ctx.empresa):
        from . import entregas
        en = entregas.entrega_de_pedido(s, eid, p.id)
        out["entrega"] = entregas._salida_entrega(en, {m.id: m for m in s.exec(select(entregas.Motorizado).where(entregas.Motorizado.empresa_id == eid)).all()}) if en else None
    return out


class RescateIn(BaseModel):
    confirmo: bool = False     # 4.32: la persona leyó la advertencia de cobro doble y la aceptó
    reclama: bool = False      # como EstadoIn.reclama: la pestaña reclama la comanda antes de imprimirla


def _hace(segundos: float) -> str:
    """«3 minutos», «1 hora», «2 días» (singular y plural)."""
    m = max(1, int(segundos // 60))
    if m < 60:
        return f"{m} minuto" + ("" if m == 1 else "s")
    h = m // 60
    if h < 48:
        return f"{h} hora" + ("" if h == 1 else "s")
    d = h // 24
    return f"{d} días"


def segundos_sin_contacto(s: Session, eid: int, terminal: int) -> Optional[float]:
    """Cuánto hace que esa computadora habló con la web: lo más reciente entre su ficha (sinc_vinculacion: último contacto, bajada o subida;
    se guarda en la base) y su última llamada a /api/sinc/datos (en memoria de este proceso). None si nunca se supo."""
    ultimo = None
    v = _vinculacion(s, eid)
    for i in list(v.get("instalaciones") or []) + list(v.get("retiradas") or []):
        try:
            if not isinstance(i, dict) or int(i.get("terminal") or 0) != int(terminal):
                continue
        except (TypeError, ValueError):
            continue
        for k in ("ultimo_contacto", "ultima_bajada", "ultima_subida"):
            try:
                x = datetime.fromisoformat(str(i.get(k) or "")).timestamp() if i.get(k) else None
            except ValueError:
                x = None
            if x is not None and (ultimo is None or x > ultimo):
                ultimo = x
    mem = _ultima_llamada(eid, terminal)
    try:
        if mem and (ultimo is None or float(mem[0]) > ultimo):
            ultimo = float(mem[0])
    except (TypeError, ValueError, IndexError):
        pass
    return None if ultimo is None else max(0.0, time.time() - ultimo)


@router.post("/api/pedidos/{pid}/atender-aqui")
def atender_aqui(pid: int, data: RescateIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """4.32 (§3, rescate): «Atenderlo aquí» en la web para un pedido que atiende un programa que dejó de conectarse. Es el único cambio de
    dueño: solo el administrador, con MINUTOS_RESCATE sin contacto de esa computadora y con la advertencia de cobro doble aceptada
    (`confirmo`). Un UPDATE condicionado (atiende = t → 0) anotado para la sincronización; después se acepta aquí como hoy (cuenta y comanda
    en la web). Cuando el programa vuelve, quita su cuenta si no tiene cobros o deja el aviso «cobrado fuera» (parte programa)."""
    if _en_programa():
        raise HTTPException(400, TEXTO_SOLO_WEB)
    if ctx.token_api is not None or not ctx.puede("configurar"):
        raise HTTPException(403, "Solo el administrador de la empresa puede atender aquí un pedido de otra computadora")
    eid = ctx.empresa.id; p = s.get(Pedido, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    t = int(p.atiende or 0)
    if p.estado != "confirmado" or t <= 0:
        raise HTTPException(400, "Este pedido no lo atiende otra computadora")
    if p.documento_id or hay_cobro(s, eid, p.id):
        raise HTTPException(409, TEXTO_YA_COBRADO)
    nombre = nombre_terminal(s, eid, t)
    hace = segundos_sin_contacto(s, eid, t)
    # revisión 4.32 (n.º 7): con FE_SINC_DATOS=0 el programa está en pausa y nunca lo baja (aunque siga conectándose por lo de siempre):
    # no se esperan los 10 minutos; la advertencia de cobro doble sí
    if hace is not None and hace < MINUTOS_RESCATE * 60 and not canal_apagado():
        raise HTTPException(409, TEXTO_RESCATE_ESPERE.format(nombre=nombre, hace=_hace(hace), minutos=MINUTOS_RESCATE))
    if not data.confirmo:
        raise HTTPException(409, {"codigo": "confirmar", "mensaje": TEXTO_RESCATE.format(nombre=nombre, hace=("hace " + _hace(hace)) if hace is not None else "hace mucho")})
    from sqlalchemy import text
    n = s.execute(text(f"UPDATE {Pedido.__tablename__} SET atiende = 0, confirmado = NULL WHERE id = :id AND empresa_id = :e AND atiende = :t "
                       "AND estado = 'confirmado' AND documento_id IS NULL AND cuenta_espera_id IS NULL"), {"id": p.id, "e": eid, "t": t}).rowcount
    if n:
        anotar_fila(s, "pedido", p.id)                          # el cambio de dueño tiene versión y baja al programa
    s.commit()
    if not n:
        raise HTTPException(409, "El pedido cambió mientras tanto: actualice la lista")
    s.refresh(p)
    _auditar_pedidos(ctx, "pedido_rescate", f"Pedido #{p.numero}: se atiende en la página web (lo atendía «{nombre}», sin conexión)")
    return _cambiar_estado(p.id, EstadoIn(estado="confirmado", reclama=data.reclama, aqui=True), ctx, s)


class ComandaImpresaIn(BaseModel):
    lineas: list[int] = PField(default_factory=list, max_length=500)   # posiciones (desde 0) en las líneas de la cuenta


@router.post("/api/pedidos/{pid}/comanda/impresa")
def comanda_impresa(pid: int, data: ComandaImpresaIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """4.29 (W-2, W-4): el equipo que aceptó el pedido imprimió su comanda. Esas líneas de la cuenta de la caja quedan con «impreso»: true,
    la misma marca que deja «Imprimir» en Punto de venta › Cocina (ahí la comanda se ve «Impresa» y se puede reimprimir a propósito).
    Solo se marcan líneas ya enviadas a cocina; las que no se imprimieron quedan sin marcar. Nada más cambia en la cuenta.
    4.31: lo hace comandas.marcar_impresas (mismo contrato), que además deja «impresa» esos platos en la copia de la comanda (la estación
    de comandas no los vuelve a imprimir) y guarda la cuenta con la fusión del servidor (L-9)."""
    eid = ctx.empresa.id; p = s.get(Pedido, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Pedido no encontrado")
    from . import comandas
    r = comandas.marcar_impresas(s, eid, p.id, posiciones=list(data.lineas), cuenta_id=p.cuenta_espera_id)
    if not r["cuenta"]:
        return {"ok": False, "marcadas": 0}
    return {"ok": True, "marcadas": r["marcadas"]}


@router.get("/api/pedidos/clientes")
def clientes_finales(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    if solo_pos(ctx.permisos):            # 4.5: la pantalla Clientes no se abre en modo cajero; la API tampoco (teléfonos, direcciones, compras y último acceso)
        raise HTTPException(403, "Su rol no tiene acceso a los clientes de la página en línea")
    cs = s.exec(select(ClienteFinal).where(ClienteFinal.empresa_id == ctx.empresa.id, ClienteFinal.telefono != "").order_by(ClienteFinal.id.desc())).all()[:500]   # 3.87: sin los restablecidos
    # 3.57: con sus pedidos (por teléfono: también los hechos antes de registrarse), lo comprado y el último pedido
    stats: dict = {}
    for p in s.exec(select(Pedido).where(Pedido.empresa_id == ctx.empresa.id)).all():
        if p.estado in ("cancelado", "pendiente_pago"):
            continue
        st = stats.setdefault(_tel(p.telefono), {"pedidos": 0, "total": 0.0, "ultimo": ""})
        st["pedidos"] += 1; st["total"] = r2(st["total"] + float(p.total or 0)); st["ultimo"] = max(st["ultimo"], p.creado or "")
    return [{"id": c.id, "telefono": c.telefono, "nombre": c.nombre, "direcciones": _json(c.direcciones, []), "creado": c.creado, "ultimo_acceso": c.ultimo_acceso,
             "pedidos": stats.get(c.telefono, {}).get("pedidos", 0), "total": stats.get(c.telefono, {}).get("total", 0.0), "ultimo_pedido": stats.get(c.telefono, {}).get("ultimo") or None} for c in cs]


@router.delete("/api/pedidos/clientes/{cid}")
def restablecer_acceso(cid: int, request: Request, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    """3.87: el negocio libera el teléfono de un cliente de la página (otra persona creó el acceso con ese número, o el cliente olvidó
    la clave): el acceso queda retirado, sus sesiones dejan de valer y quien sea dueño del teléfono crea uno nuevo. La fila no se borra
    (su número no se reutiliza, así que ningún acceso nuevo hereda sus pedidos ni sus sesiones); los pedidos quedan en la bandeja y
    cada uno vuelve a la cuenta nueva del mismo teléfono cuando su dueño abre el enlace de seguimiento (seguimiento()).
    Permiso 'catalogos' (Clientes e ítems): el mismo de Contactos, donde se registra la revendedora con su celular y su crédito."""
    _admin(ctx); eid = ctx.empresa.id
    c = s.get(ClienteFinal, cid)
    if not c or c.empresa_id != eid or not c.telefono:
        raise HTTPException(404, "Ese acceso no existe o ya se restableció")
    tel = c.telefono
    c.telefono = ""; c.pin_hash = ""; c.nombre = ""; c.direcciones = "[]"; c.contacto_id = None; c.intentos = 0; c.bloqueado_hasta = None
    s.add(c); s.commit()
    from .auth import auditar
    with Session(engine) as sc:
        auditar(sc, "cliente_web_restablecido", f"Acceso del teléfono {tel} restablecido en la página del negocio", ctx.usuario if getattr(ctx.usuario, "id", None) else None,
                eid, request, correo=getattr(ctx.usuario, "correo", None))
    return {"ok": True, "telefono": tel}


@router.get("/api/pedidos/revendedoras")
def revendedoras(ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    """3.87: contactos que pueden entrar al catálogo mayorista (clientes activos con celular o teléfono), con su código personal para
    enviárselo por WhatsApp a su propio celular, su lista de precios y si ya crearon su acceso. Permiso 'catalogos': quien registra
    a la revendedora en Contactos (Administrador, Avanzado, Vendedor, Supervisor de caja…) le da su código; la caja no lo ve."""
    _admin(ctx); eid = ctx.empresa.id; n = _negocio(s, eid)
    con_acceso = {cf.contacto_id for cf in s.exec(select(ClienteFinal).where(ClienteFinal.empresa_id == eid, ClienteFinal.contacto_id != None)).all() if cf.telefono}  # noqa: E711
    extra = modulos.leer(s, eid, "contactos_extra", {}) or {}
    listas = {int(x.get("id") or 0): str(x.get("nombre") or "") for x in (modulos.leer(s, eid, "listas_precios", []) or []) if isinstance(x, dict) and not x.get("principal")}
    out = []
    for c in s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.activo == True)).all():  # noqa: E712
        tel = next((t for t in (_digitos_tel(c.celular), _digitos_tel(c.telefono)) if len(t) == 8), "")
        if not tel or (c.tipo or "Cliente") not in ("Cliente", "Ambos"):
            continue
        ex = (extra.get(str(c.id)) if isinstance(extra, dict) else None) or {}
        try:
            lista = listas.get(int((ex or {}).get("lista_precios_id") or 0), "")
        except (TypeError, ValueError, AttributeError):
            lista = ""
        out.append({"contacto_id": c.id, "nombre": c.nombre_comercial or c.nombre, "telefono": tel, "lista": lista, "limite_credito": r2(c.limite_credito or 0),
                    "codigo": codigo_revendedora(eid, c.id, n.mayorista_codigo), "con_acceso": c.id in con_acceso})
    out.sort(key=lambda x: (not x["lista"], (x["nombre"] or "").lower()))
    return out[:1000]


# ------------------------------------------------------------------------------------------ 4.9: revendedoras y estados de cuenta
# Contactos › Revendedoras y saldos (lista con el crédito de cada una), la tarjeta «Cuenta del cliente» de la ficha del contacto y el estado
# de cuenta de un cliente (lo que ha pedido por la página, sus documentos, cobros y artículos). Sirven también para los clientes con fiado de
# la caja: no exigen Pedidos en línea (sin ese módulo, los pedidos salen vacíos).
PERMISOS_CUENTAS = ("facturar", "cobros", "catalogos", "ver_todo")
NOMBRES_DOC = {"01": "Factura electrónica", "02": "Nota de débito", "03": "Nota de crédito", "04": "Tiquete", "09": "Factura de exportación"}
NOMBRES_MEDIO = {"01": "efectivo", "02": "tarjeta", "03": "cheque", "04": "transferencia", "06": "SINPE Móvil"}


def lector_cuentas(ctx: Contexto = Depends(contexto)) -> Contexto:
    """4.9: quién lee las cuentas de los clientes: quien factura, cobra, lleva los clientes o ve todo. No el modo cajero ni los roles de un
    solo módulo (Camarera, Técnico, solo RRHH…)."""
    if solo_pos(ctx.permisos) or solo_modulo(ctx.permisos) or not any(ctx.puede(x) for x in PERMISOS_CUENTAS):
        raise HTTPException(403, "Su rol no tiene acceso a las cuentas de los clientes")
    return ctx


def _contacto_de(s: Session, eid: int, cid: int) -> Cliente:
    c = s.get(Cliente, cid)
    if not c or c.empresa_id != eid:
        raise HTTPException(404, "Contacto no encontrado")
    return c


def _telefono_contacto(c: Cliente) -> str:
    """4.9: celular o teléfono de 8 dígitos del contacto (vacío si no tiene)."""
    return next((t for t in (_digitos_tel(c.celular), _digitos_tel(c.telefono)) if len(t) == 8), "")


def _listas_contactos(s: Session, eid: int):
    """4.9: función contacto → nombre de su lista de precios (vacío = la general), con dos lecturas para toda la lista (como revendedoras())."""
    extra = modulos.leer(s, eid, "contactos_extra", {}) or {}
    try:
        listas = {int(x.get("id") or 0): str(x.get("nombre") or "") for x in (modulos.leer(s, eid, "listas_precios", []) or []) if isinstance(x, dict) and not x.get("principal")}
    except (TypeError, ValueError):
        listas = {}

    def nombre(c: Cliente) -> str:
        ex = (extra.get(str(c.id)) if isinstance(extra, dict) else None) or {}
        try:
            return listas.get(int((ex or {}).get("lista_precios_id") or 0), "")
        except (TypeError, ValueError, AttributeError):
            return ""
    return nombre


def _visible_sucursal(ctx: Contexto):
    """4.9: filtro de documentos del usuario amarrado a una sucursal (como _documento_ctx de main.py: solo los de ella); None = ve todos."""
    suc = getattr(ctx, "sucursal", None)
    if suc is None or not getattr(ctx, "sucursal_fija", False):
        return None
    from . import sucursales
    return lambda d: sucursales.pertenece(d, suc)


def _fecha_param(v: Optional[str], campo: str) -> Optional[str]:
    v = (v or "").strip()[:10]
    if not v:
        return None
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        raise HTTPException(400, f"La fecha «{campo}» debe tener el formato AAAA-MM-DD")
    return v


def _lotes(ids, n: int = 500):
    ids = list(ids)
    for i in range(0, len(ids), n):
        yield ids[i:i + n]


def _monto_en(v, moneda: str) -> str:
    """4.9: monto para el mensaje de WhatsApp en la moneda principal (₡12.345 o $1.234,50)."""
    m = (moneda or "CRC").upper()
    if m == "CRC":
        return _monto(v)
    return {"USD": "$", "EUR": "€"}.get(m, m + " ") + f"{float(v or 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _fecha_corta(f) -> str:
    f = str(f or "")[:10]
    return f"{f[8:10]}/{f[5:7]}/{f[:4]}" if len(f) == 10 else f


def _texto_estado_cuenta(nombre: str, negocio: str, cr: dict, moneda: str) -> str:
    """4.9: mensaje de WhatsApp con el estado de cuenta: saldo, vencido, en pedidos, límite y disponible, y los documentos pendientes."""
    m = lambda v: _monto_en(v, moneda)  # noqa: E731
    partes = [f"Hola {nombre}, le saludamos de {negocio}." if negocio else f"Hola {nombre}.", f"Su estado de cuenta al {ahora_cr().strftime('%d/%m/%Y')}:",
              f"• Saldo pendiente: {m(cr.get('saldo'))}"]
    if cr.get("vencido"):
        partes.append(f"• Vencido: {m(cr['vencido'])}")
    if cr.get("en_pedidos"):
        partes.append(f"• En pedidos por facturar: {m(cr['en_pedidos'])}")
    if cr.get("permitido"):
        partes.append(f"• Límite de crédito: {m(cr.get('limite'))} · disponible: {m(cr.get('disponible'))}")
    docs = cr.get("documentos") or []
    if docs:
        partes.append("Documentos pendientes:")
        for d in docs[:10]:
            partes.append(f"- {str(d.get('consecutivo') or '')[-10:]} del {_fecha_corta(d.get('fecha'))}: saldo {m(d.get('saldo'))}" + (f" (vence {_fecha_corta(d['vence'])})" if d.get("vence") else ""))
        if len(docs) > 10:
            partes.append(f"… y {len(docs) - 10} más")
    partes.append("Cualquier consulta, con gusto le atendemos.")
    return "\n".join(partes)


@router.get("/api/revendedoras")
def lista_revendedoras(q: Optional[str] = None, ctx: Contexto = Depends(lector_cuentas), s: Session = Depends(sesion_empresa)):
    """4.9: Contactos › Revendedoras y saldos. Clientes activos con límite de crédito, con pedidos de la página, con acceso de revendedora o con
    saldo a crédito abierto, cada uno con su crédito (creditos_contactos, agrupado) y sus pedidos. Sin códigos de acceso (esos siguen en
    /api/pedidos/revendedoras, para quien registra a la revendedora)."""
    e = ctx.empresa; eid = e.id; con_ped = "pedidos_online" in planes.modulos_de(e)
    cs = [c for c in s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.activo == True)).all() if (c.tipo or "Cliente") in ("Cliente", "Ambos")]  # noqa: E712
    texto = (q or "").strip().lower()
    if texto:
        dig = re.sub(r"\D", "", texto)
        cs = [c for c in cs if texto in " ".join(str(x or "") for x in (c.nombre, c.nombre_comercial, c.numero_id, c.correo)).lower()
              or (len(dig) >= 3 and (dig in _digitos_tel(c.celular) or dig in _digitos_tel(c.telefono)))]
    stats: dict = {}; con_pedido: set = set(); con_acceso: set = set()
    if con_ped:
        for p in s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.contacto_id != None)).all():  # noqa: E711
            con_pedido.add(p.contacto_id)
            if p.estado in ("cancelado", "pendiente_pago"):
                continue
            st = stats.setdefault(p.contacto_id, {"pedidos": 0, "pedidos_credito": 0, "total": 0.0, "ultimo": ""})
            st["pedidos"] += 1; st["pedidos_credito"] += 1 if p.a_credito else 0; st["total"] = r2(st["total"] + float(p.total or 0)); st["ultimo"] = max(st["ultimo"], p.creado or "")
        con_acceso = {cf.contacto_id for cf in s.exec(select(ClienteFinal).where(ClienteFinal.empresa_id == eid, ClienteFinal.contacto_id != None)).all() if cf.telefono}  # noqa: E711
    cred = creditos_contactos(s, eid, cs, e.ambiente, con_pedidos=con_ped, max_docs=0)
    lista = _listas_contactos(s, eid); out = []
    for c in cs:
        cr = cred[c.id]
        if not (cr["limite"] > 0 or c.id in con_pedido or c.id in con_acceso or cr["saldo"] > 0.009):
            continue
        st = stats.get(c.id) or {}
        out.append({"contacto_id": c.id, "nombre": c.nombre_comercial or c.nombre, "identificacion": c.numero_id or "", "telefono": _telefono_contacto(c) or str(c.celular or c.telefono or ""),
                    "correo": c.correo or "", "lista": lista(c), "limite": cr["limite"], "saldo": cr["saldo"], "vencido": cr["vencido"], "en_pedidos": cr["en_pedidos"],
                    "disponible": cr["disponible"], "pedidos": st.get("pedidos", 0), "pedidos_credito": st.get("pedidos_credito", 0), "total_pedidos": st.get("total", 0.0),
                    "ultimo_pedido": st.get("ultimo") or None, "con_acceso": c.id in con_acceso})
    out.sort(key=lambda x: (x["nombre"] or "").lower())
    return out[:2000]


@router.get("/api/revendedoras/{cid}/credito")
def credito_revendedora(cid: int, ctx: Contexto = Depends(lector_cuentas), s: Session = Depends(sesion_empresa)):
    """4.9: tarjeta «Cuenta del cliente» de la ficha del contacto: límite, saldo, en pedidos, disponible, vencido y documentos abiertos;
    `revendedora`: si compra por la página (tiene acceso vinculado o pedidos)."""
    e = ctx.empresa; eid = e.id; c = _contacto_de(s, eid, cid); con_ped = "pedidos_online" in planes.modulos_de(e)
    cr = credito_contacto(s, eid, c, e.ambiente, con_pedidos=con_ped, visible=_visible_sucursal(ctx))
    rev = bool(con_ped and (s.exec(select(ClienteFinal.id).where(ClienteFinal.empresa_id == eid, ClienteFinal.contacto_id == cid, ClienteFinal.telefono != "")).first()
                            or s.exec(select(Pedido.id).where(Pedido.empresa_id == eid, Pedido.contacto_id == cid)).first()))
    return {**cr, "revendedora": rev}


def _en_estado_cuenta(d, ambiente) -> bool:
    """4.9: si un comprobante entra al estado de cuenta, con las reglas del crédito (creditos_contactos): del ambiente de Hacienda activo y sin
    los rechazados. Un cargo en «error» (envío fallido, se reintenta) se sigue debiendo y sale, como en credito.saldo (antes el estado de
    cuenta lo quitaba y no cuadraba con el crédito). Diferencia intencional: la nota de crédito (03) en «error» no sale, porque no rebaja el
    saldo de la factura (recalcular_acreditado solo cuenta las aceptadas o internas; las que esperan respuesta sí salen, como en Reportes)."""
    est = d.estado or ""
    if d.ambiente != ambiente or est == "rechazado":
        return False
    return not (d.tipo_documento == "03" and est == "error")


def _ids_facturas(pago) -> list:
    """4.9: ids de los comprobantes a los que se aplicó un cobro (Pago.facturas)."""
    out = []
    for f in _json(pago.facturas, []):
        try:
            out.append(int(f.get("id")))
        except (TypeError, ValueError, AttributeError):
            pass
    return out


def _movimiento(fecha, tipo, documento_id, pago_id, consecutivo, detalle, cargo, abono, vence=None, condicion=None, pedido_numero=None) -> dict:
    return {"fecha": fecha, "tipo": tipo, "documento_id": documento_id, "pago_id": pago_id, "consecutivo": consecutivo, "detalle": detalle, "cargo": cargo, "abono": abono,
            "saldo": 0.0, "vence": vence, "condicion": condicion, "pedido_numero": pedido_numero}


@router.get("/api/revendedoras/{cid}/estado-cuenta")
def estado_cuenta(cid: int, desde: Optional[str] = None, hasta: Optional[str] = None, ctx: Contexto = Depends(lector_cuentas), s: Session = Depends(sesion_empresa)):
    """4.9: estado de cuenta de un cliente (revendedora o cliente con fiado de la caja): su crédito a hoy (toda la cuenta), los pedidos de la
    página en el rango, los movimientos con saldo corrido desde el saldo anterior (mismas reglas que Reportes › Estado de cuenta del cliente:
    01/02/04/09 cargan, 03 abona, la venta de contado se paga al emitirse y cada cobro del cliente abona), los artículos comprados y lo que
    falta facturar de sus pedidos a crédito. Sin fechas = toda la historia. Montos en la moneda principal. El usuario amarrado a una sucursal
    solo ve los documentos y cobros de ella (sucursal_parcial). 4.9: cuadra con el bloque de crédito (_en_estado_cuenta): un cargo en «error»
    sale (se sigue debiendo; Reportes lo quita) y los cobros aplicados solo a comprobantes que no salen (otro ambiente, rechazados) tampoco."""
    e = ctx.empresa; eid = e.id; c = _contacto_de(s, eid, cid)
    d1, d2 = _fecha_param(desde, "desde"), _fecha_param(hasta, "hasta")
    if d1 and d2 and d1 > d2:
        d1, d2 = d2, d1
    en_rango = lambda f: (not d1 or f >= d1) and (not d2 or f <= d2)  # noqa: E731
    principal = moneda_principal(s, eid); conv = conversor(s, eid, principal)
    con_ped = "pedidos_online" in planes.modulos_de(e)
    visible = _visible_sucursal(ctx); ver = visible or (lambda d: True)
    espera = (modulos.leer(s, eid, "pos_espera", []) or []) if con_ped else []
    pend = pedidos_en_credito(s, eid, [cid], espera) if con_ped else {}
    credito = credito_contacto(s, eid, c, e.ambiente, principal=principal, pendientes=pend, max_docs=None, visible=visible)
    # documentos del ambiente activo (4.9: _en_estado_cuenta, sin rechazados; los cargos en «error» sí, como en el crédito) y cobros del cliente
    docs = [d for d in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.cliente_id == cid, Documento.ambiente == e.ambiente,
                                                      Documento.tipo_documento.in_(TIPOS_SALDO + ("03",)))  # type: ignore[attr-defined]
                              .order_by(Documento.fecha_emision, Documento.id)).all() if _en_estado_cuenta(d, e.ambiente) and ver(d)]
    pagos = [p for p in s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid, modulos.Pago.cliente_id == cid).order_by(modulos.Pago.fecha, modulos.Pago.numero)).all()
             if float(p.monto or 0) > 0]
    if visible is not None:
        from .main import _pagos_visibles
        pagos = _pagos_visibles(ctx, s, pagos)
    # 4.9: sin los cobros aplicados solo a comprobantes que este estado de cuenta no carga (de otro ambiente de Hacienda o rechazados: los de
    # pruebas antes de pasar a producción, un tiquete rechazado y vuelto a emitir): su cargo no está y el abono dejaba el saldo corrido por
    # debajo del crédito (hasta negativo). Quedan los cobros sin facturas (anticipos) y los aplicados a un cargo en «error» (ese cargo sale).
    fac_pago = {p.id: _ids_facturas(p) for p in pagos}
    fuera: set = set()
    for lote in _lotes({i for x in fac_pago.values() for i in x}):
        fuera |= {d.id for d in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.id.in_(lote))).all()  # type: ignore[union-attr]
                  if not _en_estado_cuenta(d, e.ambiente)}
    pagos = [p for p in pagos if not fac_pago[p.id] or not all(i in fuera for i in fac_pago[p.id])]
    ped_de_doc: dict = {}
    for lote in _lotes([d.id for d in docs]):
        for p in s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.documento_id.in_(lote))).all():  # type: ignore[union-attr]
            ped_de_doc.setdefault(p.documento_id, p.numero)
    aplicado: dict = {}                                         # documento → lo que le aplicaron los cobros del cliente (en su moneda)
    for p in pagos:
        for f in _json(p.facturas, []):
            try:
                aplicado[int(f.get("id"))] = aplicado.get(int(f.get("id")), 0.0) + float(f.get("monto") or 0)
            except (TypeError, ValueError, AttributeError):
                pass
    mov = []
    for d in docs:
        f = (d.fecha_emision or "")[:10]; cred_d = (d.condicion_venta or "01") in CONDICIONES_CREDITO; tot = r2(conv(d.total, d.moneda, d.tipo_cambio))
        vence = ((d.fecha_vencimiento or "")[:10] or None) if cred_d else None; cond = d.condicion_venta or "01"; ped = ped_de_doc.get(d.id)
        if d.tipo_documento == "03":
            mov.append(_movimiento(f, "abono", d.id, None, d.consecutivo, NOMBRES_DOC["03"], 0.0, tot, vence, cond, ped)); continue
        mov.append(_movimiento(f, "cargo", d.id, None, d.consecutivo, NOMBRES_DOC.get(d.tipo_documento, d.tipo_documento), tot, 0.0, vence, cond, ped))
        resto = float(d.total or 0) - aplicado.get(d.id, 0.0)
        if not cred_d and resto > 0.009:                        # venta de contado: se pagó al emitirse (lo que no cubren los cobros registrados)
            mov.append(_movimiento(f, "abono", d.id, None, d.consecutivo, "Pago de contado", 0.0, r2(conv(resto, d.moneda, d.tipo_cambio)), None, cond, ped))
    for p in pagos:
        medio = NOMBRES_MEDIO.get(p.medio_pago or "", p.medio_pago or "")
        mov.append(_movimiento((p.fecha or "")[:10], "abono", None, p.id, p.consecutivo or f"Recibo #{p.numero}",
                               ("Recibo electrónico de pago" if p.tipo == "rep" else "Pago recibido") + (f" · {medio}" if medio else ""), 0.0, r2(conv(p.monto, p.moneda, p.tipo_cambio))))
    mov.sort(key=lambda m: (m["fecha"], 0 if m["tipo"] == "cargo" else 1))     # el mismo día, los cargos antes que los abonos
    anterior = 0.0; movimientos = []
    for m in mov:
        if d1 and m["fecha"] < d1:
            anterior += m["cargo"] - m["abono"]
        elif en_rango(m["fecha"]):
            movimientos.append(m)
    saldo = r2(anterior)
    for m in movimientos:
        saldo = r2(saldo + m["cargo"] - m["abono"]); m["saldo"] = saldo
    # artículos comprados en el rango: líneas de facturas, tiquetes y exportación menos las notas de crédito, por ítem
    ventas = {d.id: d for d in docs if d.tipo_documento in ("01", "03", "04", "09") and en_rango((d.fecha_emision or "")[:10])}
    lineas: list = []
    for lote in _lotes(list(ventas)):
        lineas += s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id.in_(lote))).all()  # type: ignore[attr-defined]
    prods: dict = {}
    for lote in _lotes(list({ln.producto_id for ln in lineas if ln.producto_id})):
        prods.update({x.id: x for x in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.id.in_(lote))).all()})  # type: ignore[union-attr]
    agg: dict = {}
    for ln in lineas:
        d = ventas[ln.documento_id]; sg = -1 if d.tipo_documento == "03" else 1; pr = prods.get(ln.producto_id) if ln.producto_id else None
        k = ("p", ln.producto_id) if ln.producto_id else ("d", (ln.detalle or "").strip().lower())   # por ítem: la caja agrega la nota de la línea al detalle
        it = agg.setdefault(k, {"producto_id": ln.producto_id, "codigo": (pr.codigo or "") if pr else "", "detalle": pr.nombre if pr else (ln.detalle or "").strip(),
                                "cantidad": 0.0, "total": 0.0, "docs": set(), "ultima": ""})
        it["cantidad"] += sg * float(ln.cantidad or 0); it["total"] += sg * conv(ln.total, d.moneda, d.tipo_cambio)
        if sg > 0:
            it["docs"].add(d.id); it["ultima"] = max(it["ultima"], (d.fecha_emision or "")[:10])
    items = sorted(({"producto_id": it["producto_id"], "codigo": it["codigo"], "detalle": it["detalle"], "cantidad": round(it["cantidad"], 3), "total": r2(it["total"]),
                     "veces": len(it["docs"]), "ultima": it["ultima"] or None} for it in agg.values() if abs(it["cantidad"]) > 0.0005 or abs(it["total"]) > 0.004),
                   key=lambda x: -x["total"])
    # lo que falta facturar: líneas de los pedidos que cuentan en «en pedidos». 4.9: de un pedido que ya está en la caja, las líneas de las
    # cuentas que siguen allí (tras cobrar una parte, solo lo que falta; antes listaba todo el pedido aunque «en pedidos» contara solo el resto)
    pend_agg: dict = {}
    e_id, e_ped = _espera_por_pedido(espera)
    for p, monto_p in pend.get(cid, []):
        cs = _cuentas_del_pedido(p, e_id, e_ped) if p.estado != "nuevo" else []; suma_p = 0.0
        for ln in ([l for c_ in cs for l in (c_.get("lineas") or [])] if cs else _json(p.lineas, [])):
            if not isinstance(ln, dict):
                continue
            try:
                if ln.get("total") is not None:
                    tot = float(ln["total"])
                else:                                           # línea de la caja (sin total): como lineaTotal de caja.js
                    bruto = float(ln.get("cantidad") or 0) * float(ln.get("precio_unitario") or 0)
                    desc = bruto * float(ln.get("descuento_pct") or 0) / 100 if ln.get("descuento_pct") else float(ln.get("descuento") or 0)
                    tot = (bruto - max(0.0, min(bruto, desc))) * (1 + float(ln.get("tarifa") or 0) / 100)
                cant = float(ln.get("cantidad") or 0)
            except (TypeError, ValueError):
                continue
            it = pend_agg.setdefault(ln.get("producto_id") or str(ln.get("detalle") or "").strip().lower(), {"detalle": str(ln.get("detalle") or ""), "cantidad": 0.0, "total": 0.0})
            it["cantidad"] = round(it["cantidad"] + cant, 3); it["total"] = r2(it["total"] + tot); suma_p += tot
        if not cs and float(p.envio or 0) > 0:   # 4.9: el envío del pedido «nuevo» (al confirmarlo, la cuenta de la caja lo lleva como línea): sin él, la tarjeta de abajo salía recortada
            it = pend_agg.setdefault("envío a domicilio", {"detalle": "Envío a domicilio", "cantidad": 0.0, "total": 0.0})
            it["cantidad"] = round(it["cantidad"] + 1, 3); it["total"] = r2(it["total"] + float(p.envio)); suma_p += float(p.envio)
        desc_p = r2(float(p.descuento or 0) + float(p.descuento_puntos or 0)) if not cs else 0.0
        if desc_p > 0.009:   # 4.9: cupón o puntos del pedido «nuevo»: p.total (y en_pedidos) ya los resta y sus líneas no (en la caja la cuenta los reparte en las líneas)
            it = pend_agg.setdefault("_descuento", {"detalle": "Descuento (cupón o puntos)", "cantidad": 0.0, "total": 0.0})
            it["total"] = r2(it["total"] - desc_p); suma_p -= desc_p
        pre_p = sum(_prepago_de_cuenta(c_) for c_ in cs) if cs else float((_prepago(p) or {}).get("monto") or 0)
        dif = r2(min(pre_p, suma_p - monto_p))
        if dif > 0.009:   # 4.9: lo ya pagado con tarjeta de regalo (en_pedidos lo descuenta): la tabla suma lo mismo que «En pedidos por facturar»
            it = pend_agg.setdefault("_prepago", {"detalle": "Pagado con tarjeta de regalo", "cantidad": 0.0, "total": 0.0})
            it["total"] = r2(it["total"] - dif)
    items_pendientes = sorted(pend_agg.values(), key=lambda x: -x["total"])
    # pedidos de la página (sin los que esperan el pago en línea), más nuevos primero
    pedidos: list = []; res = {"cantidad": 0, "total": 0.0, "a_credito": 0.0, "pagados_en_linea": 0.0, "cancelados": 0}
    if con_ped:
        qp = select(Pedido).where(Pedido.empresa_id == eid, Pedido.contacto_id == cid, Pedido.estado != "pendiente_pago")
        if d1:
            qp = qp.where(Pedido.creado >= d1)
        if d2:
            qp = qp.where(Pedido.creado <= d2 + "T99")
        ps = s.exec(qp.order_by(Pedido.id.desc())).all()
        est = estado_efectivo(s, eid, ps, espera)
        dped: dict = {}
        for lote in _lotes([p.documento_id for p in ps if p.documento_id]):
            dped.update({d.id: d for d in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.id.in_(lote))).all()})  # type: ignore[union-attr]
        for p in ps:
            d = dped.get(p.documento_id) if p.documento_id else None
            # 4.9: el comprobante enlazado solo si es de este cliente: el de otro (el cajero cambió el cliente al cobrar) no muestra aquí su
            # consecutivo ni su saldo; el pedido sigue «facturado»
            doc = {"id": d.id, "consecutivo": d.consecutivo, "tipo_documento": d.tipo_documento, "condicion_venta": d.condicion_venta or "01", "total": r2(conv(d.total, d.moneda, d.tipo_cambio)),
                   "saldo": r2(conv(modulos.saldo_documento(d), d.moneda, d.tipo_cambio))} if d is not None and ver(d) and d.cliente_id == cid else None
            estado = est[p.id]
            pedidos.append({"id": p.id, "numero": p.numero, "creado": p.creado, "estado": estado, "estado_nombre": NOMBRES_ESTADO.get(estado, estado), "tipo": p.tipo,
                            "a_credito": bool(p.a_credito), "forma_pago": forma_pago(p, estado), "total": r2(p.total or 0), "facturado": bool(p.documento_id), "documento": doc,
                            "lineas": [{"detalle": ln.get("detalle"), "cantidad": ln.get("cantidad"), "total": ln.get("total")} for ln in _json(p.lineas, []) if isinstance(ln, dict)]})
            if p.estado == "cancelado":
                res["cancelados"] += 1; continue
            res["cantidad"] += 1; res["total"] = r2(res["total"] + float(p.total or 0))
            if p.a_credito:
                res["a_credito"] = r2(res["a_credito"] + float(p.total or 0))
            if p.pago_estado == "aprobado":
                res["pagados_en_linea"] = r2(res["pagados_en_linea"] + float(p.pago_monto or 0))
    tel = _telefono_contacto(c); nombre = c.nombre_comercial or c.nombre
    con_acceso = bool(con_ped and s.exec(select(ClienteFinal.id).where(ClienteFinal.empresa_id == eid, ClienteFinal.contacto_id == cid, ClienteFinal.telefono != "")).first())
    n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()     # sin crearlo (_negocio lo crea): es una consulta
    negocio = ((n.nombre if n else "") or getattr(e, "nombre_comercial", None) or e.nombre or "").strip()
    from .main import _para_cliente
    return {"contacto": {"id": c.id, "nombre": nombre, "identificacion": c.numero_id or "", "telefono": tel or str(c.celular or c.telefono or ""), "correo": c.correo or "",
                         "lista": lista_de_contacto(s, eid, c)[1], "limite_credito": r2(c.limite_credito or 0), "termino_pago_dias": c.termino_pago_dias, "con_acceso": con_acceso},
            "rango": {"desde": d1, "hasta": d2}, "moneda": principal, "credito": credito, "sucursal_parcial": visible is not None,
            "resumen_pedidos": res, "pedidos": pedidos, "saldo_anterior": r2(anterior), "movimientos": movimientos, "items": items, "items_pendientes": items_pendientes,
            "enlaces": {"whatsapp": f"https://wa.me/506{tel}?text={quote(_texto_estado_cuenta(nombre, negocio, credito, principal))}" if tel else "", "correo": _para_cliente(c)}}


# ------------------------------------------------------------------------------------------ FISITAAP › Catálogo o menú (3.57)
class CatalogoItemIn(BaseModel):
    visible_catalogo: Optional[bool] = None
    destacado: Optional[bool] = None
    agotado: Optional[bool] = None
    descripcion_publica: Optional[str] = None


class CatalogoLoteIn(BaseModel):
    ids: list[int]
    visible_catalogo: Optional[bool] = None
    destacado: Optional[bool] = None
    agotado: Optional[bool] = None


def _item_catalogo(p: Producto, disp: Optional[dict] = None) -> dict:
    # 4.40: "agotado_existencias": la página lo muestra agotado porque no hay unidades en la bodega del catálogo (la opción
    # «Mostrar agotado según existencias» encendida), aunque la casilla «agotado» esté desmarcada. Solo lectura.
    return {"id": p.id, "nombre": p.nombre, "categoria": p.categoria or "", "precio": precio_final(p), "moneda": p.moneda or "CRC",
            "foto": f"/api/productos/{p.id}/imagen" if p.imagen_nombre else None, "visible_catalogo": bool(p.visible_catalogo),
            "destacado": bool(p.destacado), "agotado": bool(p.agotado), "descripcion_publica": p.descripcion_publica or "",
            "agotado_existencias": agotado_por_existencias(p, disp or {})}


def _negocio_sin_crear(s: Session, eid: int) -> Optional[NegocioPublico]:
    """4.40: el negocio público de la empresa, sin crearlo (_negocio lo crea): para las lecturas del agotado según existencias."""
    return s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == eid)).first()


@router.get("/api/pedidos/catalogo")
def catalogo_items(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Todos los ítems a la venta (activos) con su estado en la página pública, para elegir qué se publica."""
    eid = ctx.empresa.id
    prods = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.activo == True, Producto.es_venta == True).order_by(Producto.nombre)).all()  # noqa: E712
    cats = [c["nombre"] for c in (modulos.leer(s, eid, "categorias", []) or []) if isinstance(c, dict) and c.get("nombre")]
    n = _negocio_sin_crear(s, eid)
    disp = disponibilidad(s, eid, n, prods)                       # 4.40: {} con la opción apagada
    b = _bodega_catalogo(s, eid, n) if (n is not None and n.agotado_auto) else None
    # 4.40: "agotado_auto" y "bodega" (nombre) para el título de la etiqueta «Sin existencias» de la pantalla
    return {"categorias": cats, "items": [_item_catalogo(p, disp) for p in prods], "agotado_auto": bool(n is not None and n.agotado_auto),
            "bodega": b.nombre if b is not None else None}


def _aplicar_catalogo(p: Producto, data) -> bool:
    toco = False
    if data.visible_catalogo is not None:
        p.visible_catalogo = bool(data.visible_catalogo); toco = True
    if data.destacado is not None:
        p.destacado = bool(data.destacado); toco = True
    if data.agotado is not None:
        p.agotado = bool(data.agotado); toco = True
    if getattr(data, "descripcion_publica", None) is not None:
        t = " ".join(data.descripcion_publica.split())
        if len(t) > 300:
            raise HTTPException(400, "La descripción pública no puede pasar de 300 caracteres")
        p.descripcion_publica = t or None; toco = True
    return toco


@router.put("/api/pedidos/catalogo/{pid}")
def catalogo_item(pid: int, data: CatalogoItemIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = s.get(Producto, pid)
    if not p or p.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Ítem no encontrado")
    if not _aplicar_catalogo(p, data):
        raise HTTPException(400, "Nada que cambiar")
    s.add(p); s.commit(); s.refresh(p)
    return _item_catalogo(p, disponibilidad(s, ctx.empresa.id, _negocio_sin_crear(s, ctx.empresa.id), [p]))   # 4.40: con "agotado_existencias"


@router.post("/api/pedidos/catalogo/lote")
def catalogo_lote(data: CatalogoLoteIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    if not data.ids:
        raise HTTPException(400, "Elija al menos un ítem")
    if len(data.ids) > 5000:
        raise HTTPException(400, "Demasiados ítems en una sola acción")
    cambiados = 0
    for pid in data.ids:
        p = s.get(Producto, int(pid))
        if p and p.empresa_id == ctx.empresa.id and _aplicar_catalogo(p, data):
            s.add(p); cambiados += 1
    s.commit()
    return {"ok": True, "cambiados": cambiados}


@router.get("/api/pedidos/catalogo/agotado-vista")
def agotado_vista(ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    """4.40: vista previa de «Mostrar agotado según existencias» antes de encenderla, con las existencias de ahora y la opción supuesta
    encendida: bodega que cuenta (nombre; None = no hay bodega activa), total de ítems del catálogo, cuántos saldrían agotados por
    existencias y hasta 20 nombres, cuántos no tienen existencias registradas en esa bodega (siguen disponibles) y si la empresa está
    en ambiente de pruebas de Hacienda (las ventas no rebajan existencias). Solo lee: no crea el negocio, la bodega ni existencias."""
    e = ctx.empresa; eid = e.id
    n = _negocio_sin_crear(s, eid) or NegocioPublico(empresa_id=eid)       # sin guardar
    prods = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.visible_catalogo == True, Producto.activo == True, Producto.es_venta == True)).all()  # noqa: E712
    b = _bodega_catalogo(s, eid, n)
    agotarian: list = []; sin_registro = 0
    if b is not None:
        from .inventario import existencias_catalogo
        disp = existencias_catalogo(s, eid, prods, b.id)
        for p in prods:
            if agotado_por_existencias(p, disp):
                agotarian.append(p.nombre)
            elif disp.get(p.id) is None and p.inventariable and not p.es_servicio and not p.venta_negativo:
                sin_registro += 1                  # inventariable sin fila de existencia (ni porciones de receta) en esa bodega
    agotarian.sort(key=_orden_alfabetico)          # 4.40: «Ámbar» antes que «Zafiro» (lower() ponía las tildes y la Ñ al final)
    return {"bodega": b.nombre if b is not None else None, "total": len(prods), "agotarian": len(agotarian), "ejemplos": agotarian[:20],
            "sin_registro": sin_registro, "pruebas": bool(e.ambiente != "produccion" and getattr(e, "factura_electronica", True))}


# ------------------------------------------------------------------------------------------------- pago con tarjeta en línea (3.50)
CORREO_RE = re.compile(r"[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}")


def _url_retorno(slug: str) -> str:
    from .sitio import base_url
    return f"{base_url()}/api/publico/{slug}/pago/retorno"


def _url_seguimiento(slug: str, p: Pedido, n: Optional[NegocioPublico] = None) -> str:
    from .sitio import base_url
    if n is not None and n.dominio and n.dominio_verificado:
        return f"https://{n.dominio}/#pedido={p.token}"
    return f"{base_url()}{ruta_negocio(slug)}#pedido={p.token}"   # 3.87: /t/ si el nombre quedó reservado


def _pago_aprobado(s: Session, e: Empresa, n: NegocioPublico, p: Pedido, info: dict) -> None:
    """Tilopay confirmó el pago: el pedido queda confirmado y pagado, entra a la caja con el pago aplicado y se avisa a todos."""
    ahora = ahora_cr().isoformat(timespec="seconds")
    p.pago_estado = "aprobado"; p.pago_referencia = info.get("referencia") or ""; p.pago_auth = info.get("auth") or ""; p.pago_fecha = ahora; p.pago_detalle = info.get("detalle") or ""
    if p.estado == "pendiente_pago":
        eid = p.empresa_id
        try:
            exigir_caja(e)
            t = atiende_para(eid, n, p)                           # 4.32 (§4.1): la misma regla que al aceptar
            if t > 0:
                # 4.32 (§4.3): lo atiende ese programa: allá nacen la cuenta, la copia de la comanda y su número; aquí no se llama a a_caja
                p.atiende = t; p.estado = "confirmado"; p.confirmado = ahora
            else:
                p.cuenta_espera_id = a_caja(s, eid, p, n); p.estado = "confirmado"; p.confirmado = ahora
        except HTTPException:                                     # sin Punto de venta en el plan: queda «nuevo» y el negocio lo atiende a mano
            p.estado = "nuevo"
        if p.estado == "confirmado" and p.tipo in ("domicilio", "coordinado") and "entregas" in planes.modulos_de(e):
            from . import entregas
            s.add(p); s.commit(); entregas.crear_entrega(s, eid, p)
    p.actualizado = ahora; s.add(p); s.commit(); s.refresh(p)
    nom = _nombre_negocio(s, e, n)["nombre"]
    _avisar_negocio(e, n, p, nom)
    avisar_cliente(e, n, p, "pagado")


def _verificar_pago(s: Session, e: Empresa, n: NegocioPublico, p: Pedido) -> str:
    """Consulta la orden a Tilopay y actualiza el pedido. Devuelve 'aprobado', 'rechazado', 'pendiente' o 'sin_llaves'."""
    cred = pagos_online.credenciales(e, n)
    if not cred or not p.pago_orden:
        return "sin_llaves"
    try:
        info = pagos_online.consultar(cred, p.pago_orden)
    except HTTPException:
        return "pendiente"
    if info and info["aprobado"] and abs(info["monto"] - float(p.pago_monto or 0)) < 1.0:
        _pago_aprobado(s, e, n, p, info)
        return "aprobado"
    if info and not info["aprobado"]:
        p.pago_estado = "rechazado"; p.pago_detalle = (info.get("detalle") or "Pago rechazado")[:120]; p.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(p); s.commit()
        return "rechazado"
    return "pendiente"


@router.get("/api/publico/{slug}/pago/retorno", include_in_schema=False)
def retorno_pago(slug: str, order: Optional[str] = None, code: Optional[str] = None):
    """Aquí vuelve el cliente desde Tilopay. Lo que trae la dirección no se cree: se consulta la orden al API."""
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        p = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.pago_orden == (order or "").strip())).first() if order else None
        if not p:
            return RedirectResponse(f"{ruta_negocio(slug)}#pago=perdido", status_code=303)
        n = _negocio(s, eid)
        if p.pago_estado == "aprobado":
            r = "aprobado"
        else:
            r = _verificar_pago(s, e, n, p)
            if r == "pendiente" and str(code or "") not in ("", "1"):
                p.pago_estado = "rechazado"; p.pago_detalle = "Pago no aprobado"; s.add(p); s.commit(); r = "rechazado"
        return RedirectResponse(f"{ruta_negocio(slug)}#pedido={p.token}&pago={'ok' if r == 'aprobado' else 'no' if r == 'rechazado' else 'revisando'}", status_code=303)


@router.post("/api/publico/{slug}/pedido/{token}/pagar")
def pagar_de_nuevo(slug: str, token: str, request: Request):
    """Otra página de pago para un pedido que sigue esperando (rechazado o abandonado)."""
    e, eid = _publico(slug)
    limitar_ip(request, clave="pedidos", maximo=10, ventana=600, sujeto=f"pagar:{eid}:{token}", mensaje="Demasiados intentos de pago. Espere unos minutos.")
    with sesion_de(eid) as s:
        p = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.token == token)).first()
        if not p:
            raise HTTPException(404, "Pedido no encontrado")
        n = _negocio(s, eid)
        if p.pago_estado == "aprobado" or p.estado != "pendiente_pago":
            raise HTTPException(400, "Este pedido ya no está esperando el pago")
        if _verificar_pago(s, e, n, p) == "aprobado":
            return {"pagado": True, **_salida_pedido(p)}
        cred = pagos_online.credenciales(e, n)
        if not cred:
            raise HTTPException(400, "El negocio ya no recibe pagos con tarjeta en línea")
        p.pago_orden = f"GF{eid}-{p.id}-{secrets.token_hex(3).upper()}"; p.pago_estado = "pendiente"; p.pago_detalle = ""
        url = pagos_online.iniciar_pago(cred, p, p.pago_monto, _url_retorno(slug), p.correo or (e.correo or "pedidos@" + dominio_sistema()), n.direccion or "")
        p.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(p); s.commit()
        return {"pagado": False, "pago_url": url}


def _reembolsar(e: Empresa, n: NegocioPublico, p: Pedido) -> None:
    """Pedido pagado en línea que se cancela: se pide el reembolso a Tilopay; si no se puede ahora, queda pendiente."""
    if p.pago_estado == "aprobado" and p.pago_medio == "sinpe":          # 3.58: el SINPE lo devuelve el negocio desde su banco
        p.pago_estado = "reembolso_pendiente"; p.pago_detalle = "Devuelva el SINPE al cliente desde su banco"
        return
    if p.pago_estado != "aprobado" or not p.pago_orden:
        return
    cred = pagos_online.credenciales(e, n)
    ok, detalle = pagos_online.reembolsar(cred, p.pago_orden, p.pago_monto) if cred else (False, "Sin llaves de Tilopay")
    p.pago_estado = "reembolsado" if ok else "reembolso_pendiente"; p.pago_detalle = detalle[:120]


def revisar_pagos_empresa(eid: int) -> dict:
    """Pedidos que esperan pago: se consultan a Tilopay (por si el cliente no volvió) y se cancelan los que pasaron el tiempo."""
    from . import promociones
    aprobados = cancelados = 0
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    if not e:
        return {"aprobados": 0, "cancelados": 0}
    with sesion_de(eid) as s:
        pend = s.exec(select(Pedido).where(Pedido.empresa_id == eid, Pedido.estado == "pendiente_pago")).all()
        if not pend:
            return {"aprobados": 0, "cancelados": 0}
        n = _negocio(s, eid); limite = (ahora_cr() - timedelta(minutes=pagos_online.MINUTOS_PENDIENTE)).isoformat(timespec="seconds")
        for p in pend:
            if p.pago_estado == "pendiente" and _verificar_pago(s, e, n, p) == "aprobado":
                aprobados += 1; continue
            if (p.actualizado or p.creado) < limite:
                p.estado = "cancelado"; p.motivo = "No se completó el pago en línea"; p.actualizado = ahora_cr().isoformat(timespec="seconds")
                ref = f"pedido:{p.id}"; promociones.anular_uso(s, eid, ref); promociones.revertir(s, eid, ref)
                if p.tarjeta_codigo and p.tarjeta_monto:
                    promociones.devolver_tarjeta(s, eid, p.tarjeta_codigo, p.tarjeta_monto, ref)
                s.add(p); s.commit(); cancelados += 1
    return {"aprobados": aprobados, "cancelados": cancelados}


def revisar_pagos_todas() -> dict:
    """Pasada de la cola: solo empresas con el extra de pedidos en línea y negocio con tarjeta."""
    total = {"aprobados": 0, "cancelados": 0}
    with Session(engine) as sc:
        eids = [e.id for e in sc.exec(select(Empresa)).all() if "pedidos_online" in planes.modulos_de(e)]
    for eid in eids:
        try:
            r = revisar_pagos_empresa(eid)
            total["aprobados"] += r["aprobados"]; total["cancelados"] += r["cancelados"]
        except Exception as ex:  # noqa: BLE001
            logging.getLogger(__name__).warning("Pagos en línea, empresa %s: %s", eid, ex)
    return total


@router.post("/api/pedidos/negocio/tilopay/probar")
def probar_tilopay(ctx: Contexto = Depends(gestion_cobros), s: Session = Depends(sesion_empresa)):
    n = _negocio(s, ctx.empresa.id)
    cred = pagos_online.credenciales(ctx.empresa, n) if n.pago_tarjeta else None
    if not cred:
        k, u, p = (secretos.descifrar(ctx.empresa.clave_cifrada, getattr(n, x, None)) or "" for x in ("tilopay_key", "tilopay_user", "tilopay_password"))
        if not (k and u and p):
            raise HTTPException(400, "Guarde primero la llave, el usuario y la clave del API de Tilopay")
        cred = {"key": k, "user": u, "password": p}
    pagos_online.probar(cred)
    n.tilopay_probado = ahora_cr().isoformat(timespec="seconds"); s.add(n); s.commit()
    return {"ok": True, "probado": n.tilopay_probado}


# ------------------------------------------------------------------------------------------------- correos al cliente final (3.50)
TEXTOS_CLIENTE = {
    "recibido": ("Recibimos su pedido #{n}", "Su pedido ya está en manos del negocio. Le avisamos cuando lo confirmen."),
    "pagado": ("Pago aprobado · pedido #{n}", "Su pago fue aprobado y el pedido ya está confirmado. Lo están preparando."),
    "confirmado": ("Pedido #{n} confirmado", "El negocio confirmó su pedido y ya lo está preparando."),
    "en_camino": ("Pedido #{n} en camino", "Su pedido va en camino. Tenga a mano el código de entrega que aparece en el seguimiento."),
    "entregado": ("Pedido #{n} entregado", "Su pedido fue entregado. ¡Gracias por su compra!"),
    "cancelado": ("Pedido #{n} cancelado", "El negocio canceló su pedido. Si pagó con tarjeta, el reembolso se procesa a su misma tarjeta."),
}


def avisar_cliente(e: Empresa, n: NegocioPublico, p: Pedido, evento: str) -> None:
    """Correo al cliente final por cada paso del pedido (en segundo plano, con el correo saliente de la empresa)."""
    if evento not in TEXTOS_CLIENTE or not (p.correo or "").strip() or not getattr(n, "correo_cliente", True) or not getattr(e, "smtp_host", None):
        return
    slug, nombre_negocio, color = n.slug, _nombre_negocio_simple(e, n), n.color or "#0f766e"
    rem = _remitente_negocio(e, n, nombre_negocio)                    # 3.83
    datos = {"numero": p.numero, "nombre": p.nombre, "correo": p.correo, "lineas": _json(p.lineas, []), "total": p.total, "envio": p.envio, "descuento": (p.descuento or 0) + (p.descuento_puntos or 0),
             "tarjeta_monto": p.tarjeta_monto or 0, "pago_monto": p.pago_monto if p.pago_estado == "aprobado" else 0, "tipo": NOMBRES_TIPO.get(p.tipo, p.tipo), "direccion": p.direccion, "hora": p.hora_programada,
             "motivo": p.motivo, "enlace": _url_seguimiento(slug, p, n), "token": p.token}

    def _enviar():
        try:
            from . import correo
            from .main import _cfg_smtp
            asunto, intro = TEXTOS_CLIENTE[evento]
            html, texto = _plantilla_cliente(nombre_negocio, color, asunto.format(n=datos["numero"]), intro, datos, rem=rem)
            correo.enviar(_cfg_smtp(e), [datos["correo"]], f"{asunto.format(n=datos['numero'])} · {nombre_negocio}", html, texto, [])
        except Exception:  # noqa: BLE001  (un correo fallido no detiene el pedido)
            pass
    threading.Thread(target=_enviar, daemon=True).start()


def avisar_cliente_id(eid: int, pid: int, evento: str) -> None:
    """Igual que avisar_cliente pero desde otro módulo (entregas) con solo los ids."""
    try:
        with Session(engine) as sc:
            e = sc.get(Empresa, eid)
        with sesion_de(eid) as s:
            p = s.get(Pedido, pid); n = _negocio(s, eid)
            if e and p:
                avisar_cliente(e, n, p, evento)
    except Exception:  # noqa: BLE001
        pass


def _nombre_negocio_simple(e: Empresa, n: NegocioPublico) -> str:
    return (n.nombre or e.nombre_comercial or e.nombre or "Pedidos en línea").strip()


def _plantilla_cliente(negocio: str, color: str, titulo: str, intro: str, d: dict, rem=None) -> tuple[str, str]:
    """Correo al cliente final por cada paso del pedido (3.50; diseño común 3.83)."""
    from . import correo_diseno as _dz
    rem = rem or _dz.Remitente(nombre=negocio, color=_dz._color_valido(color) or _dz.ACENTO_EMPRESA)
    lineas = [(f"{l.get('cantidad')} × {l.get('detalle')}", _monto(l.get("total")),
               " · ".join(x for x in [", ".join(o.get("nombre", "") for o in (l.get("opciones") or [])), (f"Nota: {l.get('nota')}" if l.get("nota") else "")] if x))
              for l in d["lineas"]]
    totales = []
    if d["descuento"]:
        totales.append(("Descuento", "−" + _monto(d["descuento"]), False))
    if d["envio"]:
        totales.append(("Envío", _monto(d["envio"]), False))
    totales.append(("Total", _monto(d["total"]), True))
    pagado = bool(d["tarjeta_monto"] or d["pago_monto"])
    if d["tarjeta_monto"]:
        totales.append(("Tarjeta de regalo", "−" + _monto(d["tarjeta_monto"]), False))
    if d["pago_monto"]:
        totales.append(("Pagado con tarjeta en línea", "−" + _monto(d["pago_monto"]), False))
    resto = max(0.0, float(d["total"]) - float(d["tarjeta_monto"]) - float(d["pago_monto"]))
    if pagado:
        totales.append(("Por pagar al recibir", _monto(resto), True))
    entrega = d["tipo"] + (f" · {d['direccion']}" if d["direccion"] else "") + (f" · para las {d['hora']}" if d["hora"] else "")
    html = _dz.armar(rem, titulo=titulo, asunto=titulo, preencabezado=intro, saludo=f"Hola {d['nombre']},", parrafos_txt=[intro],
                     aviso=f"Motivo: {d['motivo']}" if d.get("motivo") else "", aviso_tono="rojo",
                     datos=[("Pedido", f"#{d['numero']}"), ("Entrega", entrega)], lineas=lineas, totales=totales,
                     boton_=("Ver el estado del pedido", d["enlace"]) if d.get("enlace") else None,
                     nota=f"Este correo lo envía {negocio}. Si tiene alguna duda, responda este correo.")
    texto = (f"{negocio}\n{titulo}\n\nHola {d['nombre']}, {intro}\n" + (f"Motivo: {d['motivo']}\n" if d.get("motivo") else "")
             + "".join(f"- {l.get('cantidad')} x {l.get('detalle')}: {float(l.get('total') or 0):,.0f}\n" for l in d["lineas"])
             + f"Total: {float(d['total']):,.0f}\n" + (f"Por pagar al recibir: {resto:,.0f}\n" if pagado else "") + f"Seguimiento: {d['enlace']}\n")
    return html, texto
