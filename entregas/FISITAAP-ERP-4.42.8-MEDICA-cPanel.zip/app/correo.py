"""Envío de comprobantes por correo (SMTP configurable por empresa).

Seguridad de la conexión (`ConfigSMTP.seguridad`):
- "ssl"      → SMTP sobre TLS implícito (puerto 465, el habitual en cPanel).
- "starttls" → conexión en claro que se cifra con STARTTLS (puerto 587, Gmail/Microsoft 365).
- "ninguna"  → sin cifrado (puerto 25, solo relés internos; nunca con contraseñas reales por internet).
"""
import smtplib
import socket
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid


@dataclass
class ConfigSMTP:
    host: str
    puerto: int
    usuario: str | None
    password: str | None
    remitente: str
    seguridad: str = "ssl"          # ssl | starttls | ninguna
    nombre: str | None = None       # nombre visible del remitente
    copia: str | None = None        # copia oculta (BCC) de cada envío
    responder_a: str | None = None  # Reply-To (las respuestas van a otra cuenta, p. ej. Recursos humanos)


class ErrorCorreo(Exception):
    """Fallo de envío con mensaje entendible para el usuario."""


def _conectar(cfg: ConfigSMTP, timeout: int = 30):
    ctx = ssl.create_default_context()
    seg = (cfg.seguridad or "ssl").lower()
    if seg == "ssl":
        s = smtplib.SMTP_SSL(cfg.host, cfg.puerto, context=ctx, timeout=timeout)
    else:
        s = smtplib.SMTP(cfg.host, cfg.puerto, timeout=timeout)
        s.ehlo()
        if seg == "starttls":
            s.starttls(context=ctx)
            s.ehlo()
    if cfg.usuario:
        s.login(cfg.usuario, cfg.password or "")
    return s


def _imagenes_en_linea(msg: EmailMessage, cuerpo_html) -> None:
    """3.83: los logos del diseño (correo_diseno.CorreoHtml.imagenes) van dentro del correo como imágenes «cid:» del HTML."""
    imagenes = getattr(cuerpo_html, "imagenes", None) or []
    if not imagenes:
        return
    parte_html = msg.get_payload()[-1]                       # multipart/alternative: [texto, html]
    for cid, datos, tipo, sub in imagenes:
        parte_html.add_related(datos, maintype=tipo, subtype=sub, cid=f"<{cid}>", disposition="inline")


def _mensaje(cfg: ConfigSMTP, para: list[str], asunto: str, cuerpo_html: str, cuerpo_texto: str, adjuntos) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = formataddr((cfg.nombre, cfg.remitente)) if cfg.nombre else cfg.remitente
    msg["To"] = ", ".join(para)
    msg["Subject"] = " ".join(str(asunto or "").split())[:250]      # sin saltos de línea (un nombre de cliente con Enter rompía el envío)
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=cfg.remitente.rsplit("@", 1)[-1].rstrip(">") or None)
    if cfg.copia:
        msg["Bcc"] = cfg.copia
    if cfg.responder_a:
        msg["Reply-To"] = cfg.responder_a
    msg.set_content(cuerpo_texto)
    msg.add_alternative(str(cuerpo_html), subtype="html")
    _imagenes_en_linea(msg, cuerpo_html)
    for nombre, datos, tipo, sub in adjuntos or []:
        msg.add_attachment(datos, maintype=tipo, subtype=sub, filename=nombre)
    return msg


def _error_claro(cfg: ConfigSMTP, ex: Exception) -> ErrorCorreo:
    """Traduce una excepción SMTP/red a un ErrorCorreo con explicación para el usuario."""
    try:
        raise ex
    except smtplib.SMTPAuthenticationError as e:
        return ErrorCorreo(f"El servidor rechazó el usuario o la contraseña SMTP ({e.smtp_code}). Revise usuario (normalmente el correo "
                           f"completo) y contraseña; con Gmail/Microsoft 365 hace falta una contraseña de aplicación")
    except ssl.SSLError as e:
        return ErrorCorreo(f"Fallo de cifrado con {cfg.host}:{cfg.puerto} ({e.reason or e}). Combinaciones habituales: SSL con puerto 465, "
                           f"STARTTLS con puerto 587")
    except smtplib.SMTPNotSupportedError as e:
        return ErrorCorreo(f"El servidor no soporta la seguridad elegida ({cfg.seguridad}): {e}. Pruebe SSL/465 o STARTTLS/587")
    except smtplib.SMTPRecipientsRefused as e:
        return ErrorCorreo(f"El servidor rechazó los destinatarios: {e.recipients}")
    except smtplib.SMTPSenderRefused as e:
        return ErrorCorreo(f"El servidor rechazó el remitente {cfg.remitente} ({e.smtp_error!r}). El remitente debe ser una cuenta del "
                           f"mismo servidor")
    except smtplib.SMTPResponseException as e:
        return ErrorCorreo(f"El servidor de correo rechazó el envío (código {e.smtp_code}): {e.smtp_error.decode(errors='replace') if isinstance(e.smtp_error, bytes) else e.smtp_error}")
    except smtplib.SMTPException as e:
        return ErrorCorreo(f"Error SMTP: {e}")
    except (socket.timeout, TimeoutError):
        return ErrorCorreo(f"Tiempo de espera agotado al conectar con {cfg.host}:{cfg.puerto}. ¿Puerto bloqueado o seguridad "
                           f"incorrecta (SSL↔STARTTLS)?")
    except (ConnectionRefusedError, socket.gaierror, OSError) as e:
        return ErrorCorreo(f"No se pudo conectar con {cfg.host}:{cfg.puerto}: {e}")
    except Exception as e:  # noqa: BLE001
        return ErrorCorreo(f"No se pudo enviar el correo: {e}")


def enviar_varios(cfg: ConfigSMTP, mensajes: list[tuple[list[str], str, str, str]], timeout: int = 15) -> list:
    """Varios correos sin adjuntos con UNA sola conexión (recordatorios de cobro). mensajes: [(para, asunto, html, texto)].
    Devuelve una lista paralela con None (enviado) o el ErrorCorreo de cada uno; si la conexión o la autenticación fallan, todos
    los pendientes quedan con ese error (no se insiste 50 veces contra un servidor caído)."""
    out: list = [None] * len(mensajes)
    if not mensajes:
        return out
    try:
        with _conectar(cfg, timeout) as s:
            for i, (para, asunto, html, texto) in enumerate(mensajes):
                try:
                    s.send_message(_mensaje(cfg, para, asunto, html, texto, []), to_addrs=list(para) + ([cfg.copia] if cfg.copia else []))
                except (smtplib.SMTPServerDisconnected, socket.timeout, TimeoutError, OSError) as ex:
                    err = _error_claro(cfg, ex)
                    for j in range(i, len(mensajes)):
                        out[j] = err
                    return out
                except Exception as ex:  # noqa: BLE001  rechazo de un destinatario: solo ese correo
                    out[i] = _error_claro(cfg, ex)
    except Exception as ex:  # noqa: BLE001  no se pudo ni conectar: todos fallan con la misma causa
        err = _error_claro(cfg, ex)
        return [err] * len(mensajes)
    return out


def enviar(cfg: ConfigSMTP, para: list[str], asunto: str, cuerpo_html: str, cuerpo_texto: str,
           adjuntos: list[tuple[str, bytes, str, str]], cc: list[str] | None = None) -> None:
    """adjuntos: lista de (nombre, bytes, tipo_principal, subtipo) p.ej. ('f.pdf', b, 'application', 'pdf').
    Lanza ErrorCorreo con una explicación clara (puerto/seguridad, credenciales, conexión)."""
    msg = EmailMessage()
    msg["From"] = formataddr((cfg.nombre, cfg.remitente)) if cfg.nombre else cfg.remitente
    msg["To"] = ", ".join(para)
    if cc:                                                            # copia visible (3.38)
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = " ".join(str(asunto or "").split())[:250]
    msg["Date"] = formatdate(localtime=True)                         # sin Date/Message-ID muchos servidores lo marcan como spam
    msg["Message-ID"] = make_msgid(domain=cfg.remitente.rsplit("@", 1)[-1].rstrip(">") or None)
    if cfg.copia:
        msg["Bcc"] = cfg.copia
    if cfg.responder_a:
        msg["Reply-To"] = cfg.responder_a
    msg.set_content(cuerpo_texto)
    msg.add_alternative(str(cuerpo_html), subtype="html")
    _imagenes_en_linea(msg, cuerpo_html)
    for nombre, datos, tipo, sub in adjuntos:
        msg.add_attachment(datos, maintype=tipo, subtype=sub, filename=nombre)

    destinatarios = list(para) + list(cc or []) + ([cfg.copia] if cfg.copia else [])
    try:
        with _conectar(cfg) as s:
            s.send_message(msg, to_addrs=destinatarios)
    except smtplib.SMTPAuthenticationError as ex:
        raise ErrorCorreo(f"El servidor rechazó el usuario o la contraseña SMTP ({ex.smtp_code}). Revise usuario (normalmente el correo "
                          f"completo) y contraseña; con Gmail/Microsoft 365 hace falta una contraseña de aplicación") from ex
    except ssl.SSLError as ex:
        raise ErrorCorreo(f"Fallo de cifrado con {cfg.host}:{cfg.puerto} ({ex.reason or ex}). Combinaciones habituales: SSL con puerto 465, "
                          f"STARTTLS con puerto 587") from ex
    except smtplib.SMTPNotSupportedError as ex:
        raise ErrorCorreo(f"El servidor no soporta la seguridad elegida ({cfg.seguridad}): {ex}. Pruebe SSL/465 o STARTTLS/587") from ex
    except smtplib.SMTPRecipientsRefused as ex:
        raise ErrorCorreo(f"El servidor rechazó los destinatarios: {ex.recipients}") from ex
    except smtplib.SMTPSenderRefused as ex:
        raise ErrorCorreo(f"El servidor rechazó el remitente {cfg.remitente} ({ex.smtp_error!r}). El remitente debe ser una cuenta del "
                          f"mismo servidor") from ex
    except smtplib.SMTPResponseException as ex:        # rechazos del servidor después de conectar (antes caían en "No se pudo conectar") (R225)
        raise ErrorCorreo(f"El servidor de correo rechazó el envío (código {ex.smtp_code}): {ex.smtp_error.decode(errors='replace') if isinstance(ex.smtp_error, bytes) else ex.smtp_error}") from ex
    except smtplib.SMTPException as ex:                # el resto de errores SMTP heredan de OSError: van antes que el except genérico
        raise ErrorCorreo(f"Error SMTP: {ex}") from ex
    except (socket.timeout, TimeoutError) as ex:
        raise ErrorCorreo(f"Tiempo de espera agotado al conectar con {cfg.host}:{cfg.puerto}. ¿Puerto bloqueado o seguridad "
                          f"incorrecta (SSL↔STARTTLS)?") from ex
    except (ConnectionRefusedError, socket.gaierror, OSError) as ex:
        raise ErrorCorreo(f"No se pudo conectar con {cfg.host}:{cfg.puerto}: {ex}") from ex


def probar(cfg: ConfigSMTP, para: str, empresa: str, rem=None) -> None:
    """Envía un correo de prueba sin adjuntos para validar servidor, puerto, seguridad y credenciales."""
    from . import correo_diseno as dz
    rem = rem or dz.de_nombre(empresa)
    html = dz.armar(rem, titulo="El correo funciona", asunto=f"Prueba de correo — {empresa}", preencabezado="La configuración del correo saliente está lista.",
                    parrafos_txt=["Este es un correo de prueba. Si lo está leyendo, el correo saliente quedó bien configurado y los comprobantes, "
                                  "recordatorios y avisos van a llegar a sus clientes."],
                    datos=[("Servidor", f"{cfg.host}:{cfg.puerto}"), ("Seguridad", (cfg.seguridad or "").upper()), ("Remitente", cfg.remitente)])
    texto = (f"{empresa}\n\nCorreo de prueba del sistema de facturación. Si lo recibió, la configuración SMTP funciona.\n"
             f"Servidor {cfg.host}:{cfg.puerto} · seguridad {cfg.seguridad} · remitente {cfg.remitente}\n")
    enviar(cfg, [para], f"Prueba de correo — {empresa}", html, texto, [])


def plantilla_comprobante(empresa: str, titulo: str, consecutivo: str, total: str, clave: str,
                          con_respuesta: bool = True, enlace: str | None = None, rem=None, cliente: str = "", fecha: str = "",
                          mensaje: str = "") -> tuple[str, str]:
    from . import correo_diseno as dz
    adj = "el PDF, el XML del comprobante y la respuesta de aceptación del Ministerio de Hacienda" if con_respuesta         else "el PDF y el XML del comprobante"
    rem = rem or dz.de_nombre(empresa)
    html = dz.armar(rem, titulo=f"Le enviamos su {titulo.lower()}", asunto=f"{titulo} {consecutivo} — {empresa}", antetitulo=titulo,
                    preencabezado=f"{titulo} por {total}. Adjuntamos el PDF y el XML.",
                    saludo=(f"Hola {cliente}," if cliente else ""), mensaje=mensaje,
                    parrafos_txt=[f"Gracias por preferir {empresa}. Encontrará adjuntos {adj}."],
                    datos=[("Número", consecutivo), ("Fecha", fecha), ("Total", total)],
                    boton_=("Ver el comprobante en línea", enlace) if enlace else None,
                    nota=f"Clave numérica: {clave}")
    texto = (f"{empresa}\n\nLe adjuntamos su {titulo.lower()} N.º {consecutivo} por un total de {total}.\n"
             f"Adjuntos: {adj}.\n" + (f"Consulte el comprobante en línea: {enlace}\n" if enlace else "") + f"Clave: {clave}\n")
    return html, texto
