"""Traslados de inventario entre empresas del mismo dueño con cédulas distintas (3.69).

Para Hacienda son empresas separadas: el traslado es una factura de la empresa que entrega (A) a la que recibe (B), al costo más un
porcentaje opcional. En un solo paso:
  1. En A se emite la factura a B (cliente creado solo con los datos de la empresa) y se descuenta la bodega de origen.
  2. En B se registra la compra (registro «compras», proveedor = A creado solo), entran las existencias a la bodega de destino y se
     crean los productos que falten casando por código y luego por nombre. Cuando la factura de A llegue después a la bandeja de
     recepción de B, queda vinculada a esa compra por la clave (recepcion.py) y no se registra dos veces.
Quién puede: un usuario con acceso a ambas empresas (facturar e inventario en A; gastos e inventario en B). Es un extra del plan
(«grupo»), salvo sin plan, prueba gratis o demo.
"""
import logging
import types
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlmodel import Session, select

from . import inventario, modulos, planes
from .auth import Contexto, UsuarioEmpresa, auditar, contexto, requiere, sesion_empresa
from .config import ahora_cr
from .db import Cliente, Empresa, Producto, engine_empresa, get_session

log = logging.getLogger("facturacr.traslados")
router = APIRouter(prefix="/api/traslados", tags=["traslados"])
CLAVE_CONFIG, CLAVE_SALIDAS, CLAVE_ENTRADAS = "traslados_config", "traslados_salida", "traslados_entrada"
EMISION = "Traslado del grupo"


# ------------------------------------------------------------------------------------------------ apoyo
def config(s: Session, eid: int) -> dict:
    d = modulos.leer(s, eid, CLAVE_CONFIG, None)
    try:
        pct = float((d or {}).get("porcentaje") or 0) if isinstance(d, dict) else 0.0
    except (TypeError, ValueError):
        pct = 0.0
    return {"porcentaje": max(0.0, min(100.0, pct))}


def _poner(s: Session, eid: int, clave: str, datos):
    r = modulos._registro(s, eid, clave)
    modulos.reemplazar(s, eid, clave, datos, version=(r.version or 0) if r is not None else 0)


def _agregar(s: Session, eid: int, clave: str, item: dict) -> int:
    """Alta en una colección por id; devuelve el id que quedó (el servidor lo cambia si otro lo usó)."""
    lista = modulos.leer(s, eid, clave, []) or []
    item = dict(item); item["id"] = max([int(x.get("id") or 0) for x in lista if isinstance(x, dict)] + [0]) + 1
    _, remap = modulos.aplicar_cambios(s, eid, clave, [item], [], [item["id"]])   # el alta va en upserts y su id en nuevos; remap: {id_enviado (texto): id_asignado}
    return int(remap.get(str(item["id"]), item["id"]))


def compra_por_clave(s: Session, eid: int, clave: str) -> Optional[int]:
    """Id de la compra registrada por un traslado (o cualquier compra) con esa clave de Hacienda, para vincularla al recibirla."""
    if not clave:
        return None
    for c in modulos.leer(s, eid, "compras", []) or []:
        if isinstance(c, dict) and c.get("clave") == clave and c.get("id") is not None:
            return int(c["id"])
    return None


def extra_activo(e) -> bool:
    return "grupo" in planes.modulos_de(e)


def extra_disponible(e) -> bool:
    """3.87: el tipo de negocio puede contratar «Grupo de empresas» (Hospitalidad no: solo recibe traslados de otra empresa del grupo)."""
    return "grupo" in planes.EXTRAS_TIPO.get(planes.tipo_de(e), [])


def _exigir_extra(e):
    if not extra_activo(e):
        if not extra_disponible(e):        # 3.87: antes también le decía al hotel que lo pidiera, y su tipo de negocio no lo puede contratar
            raise HTTPException(400, "Esta versión no envía traslados entre empresas: los recibe de otra empresa suya que tenga el extra «Grupo de empresas»")
        raise HTTPException(400, "Los traslados entre empresas son el extra «Grupo de empresas» del plan: pídalo en Configuración › Suscripción y planes")


def _rol_en(sc: Session, usuario, eid: int) -> Optional[str]:
    if getattr(usuario, "es_superadmin", False):
        return "Administrador"
    if getattr(usuario, "id", None) is None:
        return None
    m = sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == usuario.id, UsuarioEmpresa.empresa_id == eid)).first()
    return m.rol if m else None


def _grupo_del_dueno(sc: Session, eid: int) -> list[Empresa]:
    """3.87: el grupo de la empresa visto por su dueño: las empresas donde algún Administrador de esta (cuenta de la empresa, activa;
    no un administrador del sistema) también es miembro con gastos e inventario."""
    from .auth import Usuario, _permisos_sesion
    ids = set()
    for m in sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == eid, UsuarioEmpresa.rol == "Administrador")).all():
        dueno = sc.get(Usuario, m.usuario_id)
        if not dueno or dueno.es_superadmin or dueno.bloqueado:
            continue
        for otra in sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == dueno.id, UsuarioEmpresa.empresa_id != eid)).all():
            if {"gastos", "inventario"} <= _permisos_sesion(sc, dueno, otra.empresa_id, otra.rol):
                ids.add(otra.empresa_id)
    return sorted((x for x in (sc.get(Empresa, i) for i in ids) if x), key=lambda x: x.nombre or "")


def destinos(sc: Session, ctx: Contexto) -> list[tuple[Empresa, str, set]]:
    """Empresas a las que este usuario puede trasladar: tiene acceso a ellas con gastos e inventario, no están bloqueadas."""
    from .auth import _permisos_sesion, admin_ve_empresa
    u = ctx.usuario
    if getattr(u, "es_superadmin", False):
        # 3.87: el administrador del sistema que da soporte dentro de la empresa ve el mismo grupo que su dueño, nunca las empresas de
        # otros clientes (antes, todas las de la plataforma) ni las que el super administrador le ocultó (antes también les escribía)
        candidatas = [x for x in _grupo_del_dueno(sc, ctx.empresa.id) if admin_ve_empresa(u, x.id)]
    else:
        if getattr(u, "id", None) is None:
            return []
        ids = [m.empresa_id for m in sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == u.id)).all()]
        candidatas = [x for x in (sc.get(Empresa, i) for i in ids) if x]
    out = []
    for e in candidatas:
        if e.id == ctx.empresa.id or e.bloqueada:
            continue
        rol = _rol_en(sc, u, e.id)
        perms = _permisos_sesion(sc, u, e.id, rol)
        if {"gastos", "inventario"} <= set(perms):          # 3.87: también para el administrador del sistema (el plan de la otra empresa manda)
            out.append((e, rol or "Administrador", set(perms)))
    return out


def _contacto(s: Session, eid: int, otra: Empresa, tipo: str) -> Cliente:
    """La otra empresa como contacto de esta (cliente en la que entrega, proveedor en la que recibe); se crea solo la primera vez."""
    from .main import _normalizar_identificacion
    num = _normalizar_identificacion(otra.tipo_id or "02", otra.numero_id or "")
    if not num:
        raise HTTPException(400, f"La empresa {otra.nombre} no tiene cédula registrada: complétela en Configuración › Empresa")
    c = s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.numero_id == num)).first()
    if c is None:
        c = Cliente(empresa_id=eid, nombre=otra.nombre, nombre_comercial=otra.nombre_comercial, tipo=tipo, tipo_id=otra.tipo_id or "02", numero_id=num,
                    correo=(otra.correo or "").strip() or None, telefono=getattr(otra, "telefono", None), provincia=otra.provincia, canton=getattr(otra, "canton", None),
                    distrito=getattr(otra, "distrito", None), direccion=(getattr(otra, "otras_senas", "") or "")[:160] or None,
                    actividad=(otra.actividad or None) if (otra.tipo_id or "02") == "02" else None)
        s.add(c); s.commit(); s.refresh(c)
    elif c.tipo != tipo and c.tipo != "Ambos":
        c.tipo = "Ambos"; s.add(c); s.commit(); s.refresh(c)
    return c


def _producto_destino(sd: Session, eid: int, d: dict) -> tuple[Producto, bool]:
    """El producto equivalente en la empresa que recibe: por código, luego por nombre; si no existe se crea copiando la ficha."""
    base = select(Producto).where(Producto.empresa_id == eid)
    p = None
    codigo = d.get("codigo") or None
    if codigo:
        from . import etiquetas
        p = sd.exec(base.where(Producto.codigo == codigo)).first()
        if p is None:                                # 4.24: el mismo código escrito distinto o un código alterno también son ese producto (no se crea otro con el código repetido)
            p = etiquetas.producto_con_codigo(sd, eid, codigo)
        # 4.24: un código generado lleva la marca de la empresa (3 dígitos que salen de su cédula y de su código de sucursal) y el id: casi nunca coincide con el de
        # otra empresa, y entonces el ítem nuevo de aquí conserva el código de allá (la etiqueta pegada allá sirve aquí). Pero dos
        # empresas con la misma marca (o una balanza) sí pueden repetirlo: si aquí lo tiene un ítem con otro nombre, es otro
        # artículo. Se sigue por el nombre y, si hay que crearlo, entra sin ese código (aquí ya es de otro ítem)
        if p is not None and etiquetas.codigo_generado(codigo) and (p.nombre or "").strip().lower() != (d["nombre"] or "").strip().lower():
            p, codigo = None, None
    if p is None:
        p = sd.exec(base.where(func.lower(Producto.nombre) == (d["nombre"] or "").lower())).first()
    if p is not None:
        return p, False
    p = Producto(empresa_id=eid, codigo=codigo, nombre=d["nombre"], cabys=d["cabys"], precio=float(d.get("precio_venta") or 0), moneda=d.get("moneda_precio") or "CRC",
                 unidad_medida=d.get("unidad_medida") or "Unid", es_servicio=False, codigo_tarifa=d.get("codigo_tarifa") or "08", tarifa=float(d.get("tarifa") if d.get("tarifa") is not None else 13),
                 otro_impuesto=d.get("otro_impuesto"), tipo="Producto", descripcion=d.get("descripcion"), categoria=d.get("categoria"), costo=float(d.get("precio_unitario") or 0),
                 inventariable=True, partida_arancelaria=d.get("partida"), es_venta=True)
    sd.add(p); sd.flush()
    return p, True


def _registrar_en_destino(sc: Session, ctx: Contexto, e: Empresa, ed: Empresa, salida: dict, bodega_destino_id: Optional[int], request: Request | None) -> dict:
    """Lado B: proveedor, productos, compra y entrada a la bodega. Devuelve lo que hay que anotar en la salida."""
    with Session(engine_empresa(ed.id)) as sd:
        prov = _contacto(sd, ed.id, e, "Proveedor")
        bodega_d = bodega_destino_id or inventario.bodega_principal(sd, ed.id).id
        bod = inventario._bodega_activa(sd, ed.id, bodega_d)
        bodega_nombre = bod.nombre
        lineas_c, creados = [], []
        for d in salida["detalle"]:
            pd, nuevo = _producto_destino(sd, ed.id, d)
            if nuevo:
                creados.append(pd.nombre)
            lineas_c.append({"producto_id": pd.id, "detalle": d["nombre"], "cabys": d["cabys"], "cantidad": d["cantidad"], "precio_unitario": d["precio_unitario"], "descuento": 0,
                             "codigo_tarifa": d["codigo_tarifa"], "tarifa": d["tarifa"], "es_servicio": False, "unidad_medida": d.get("unidad_medida") or "Unid"})
        hoy = ahora_cr().date().isoformat()
        compra = {"numero": salida["consecutivo"], "clave": salida.get("clave"), "recepcion_id": None, "proveedor_id": prov.id, "proveedor": prov.nombre, "creacion": hoy, "vencimiento": hoy,
                  "moneda": "CRC", "tipo_cambio": 1, "bodega": bodega_nombre, "lineas": lineas_c, "retenciones": [], "total": salida["total"], "pagado": 0, "emision": EMISION,
                  "fec_id": None, "fec_consecutivo": None, "terminos": "", "notas": salida.get("observaciones") or "", "ordenes_ids": [],
                  "traslado": True, "traslado_empresa_id": e.id, "traslado_empresa": e.nombre}
        compra_id = _agregar(sd, ed.id, "compras", compra)
        inventario.ingresar_por_compra(sd, ed.id, None, salida["consecutivo"], bodega_d,
                                       [{"producto_id": l["producto_id"], "cantidad": l["cantidad"], "costo": l["precio_unitario"]} for l in lineas_c], hoy)
        sd.commit()
        entrada = {"fecha": ahora_cr().isoformat(timespec="seconds"), "empresa_origen_id": e.id, "empresa_origen": e.nombre, "consecutivo": salida["consecutivo"], "clave": salida.get("clave"),
                   "compra_id": compra_id, "bodega_id": bodega_d, "bodega": bodega_nombre, "total": salida["total"], "lineas": len(lineas_c), "productos_creados": creados,
                   "usuario": getattr(ctx.usuario, "correo", None)}
        entrada_id = _agregar(sd, ed.id, CLAVE_ENTRADAS, entrada)
    auditar(sc, "traslado_recibido", f"Desde {e.nombre}: {salida['consecutivo']} · compra {compra_id} · {len(lineas_c)} líneas · ₡{salida['total']:,.0f}",
            ctx.usuario if getattr(ctx.usuario, "id", None) is not None else None, ed.id, request, correo=getattr(ctx.usuario, "correo", None))
    return {"compra_id_destino": compra_id, "entrada_id_destino": entrada_id, "bodega_destino_id": bodega_d, "bodega_destino": bodega_nombre, "productos_creados": creados, "error": None}


# ------------------------------------------------------------------------------------------------ rutas
class ConfigIn(BaseModel):
    porcentaje: float = Field(0, ge=0, le=100)


class LineaTrasladoIn(BaseModel):
    producto_id: int
    cantidad: Decimal = Field(gt=0)


class TrasladoIn(BaseModel):
    empresa_destino_id: int
    bodega_origen_id: Optional[int] = None
    bodega_destino_id: Optional[int] = None
    lineas: list[LineaTrasladoIn]
    observaciones: Optional[str] = Field(None, max_length=300)
    porcentaje: Optional[float] = Field(None, ge=0, le=100)
    clave_peticion: Optional[str] = Field(None, max_length=80)     # un reenvío tras un corte no emite otra factura


@router.get("")
def listar(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (ctx.puede("inventario") or ctx.puede("gastos") or ctx.puede("facturar")):
        raise HTTPException(403, "Su rol no ve los traslados entre empresas")
    salidas = [x for x in (modulos.leer(s, ctx.empresa.id, CLAVE_SALIDAS, []) or []) if isinstance(x, dict)]
    entradas = [x for x in (modulos.leer(s, ctx.empresa.id, CLAVE_ENTRADAS, []) or []) if isinstance(x, dict)]
    return {"salidas": sorted(salidas, key=lambda x: x.get("id") or 0, reverse=True), "entradas": sorted(entradas, key=lambda x: x.get("id") or 0, reverse=True),
            "config": config(s, ctx.empresa.id), "extra_activo": extra_activo(ctx.empresa), "extra_disponible": extra_disponible(ctx.empresa)}


@router.get("/destinos")
def ver_destinos(ctx: Contexto = Depends(contexto), sc: Session = Depends(get_session)):
    if not (ctx.puede("inventario") and ctx.puede("facturar")):
        raise HTTPException(403, "Para trasladar inventario su rol necesita facturar e inventario")
    out = []
    for e, rol, _perms in destinos(sc, ctx):
        with Session(engine_empresa(e.id)) as sd:
            bodegas = [{"id": b.id, "nombre": b.nombre, "principal": b.principal} for b in
                       sd.exec(select(inventario.Bodega).where(inventario.Bodega.empresa_id == e.id, inventario.Bodega.activa == True).order_by(inventario.Bodega.nombre)).all()]  # noqa: E712
        out.append({"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id, "rol": rol, "bodegas": bodegas})
    return out


@router.put("/config")
def guardar_config(data: ConfigIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    _poner(s, ctx.empresa.id, CLAVE_CONFIG, {"porcentaje": round(float(data.porcentaje), 2)})
    s.commit()
    return config(s, ctx.empresa.id)


@router.post("")
def crear(data: TrasladoIn, request: Request, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    from . import main as m
    if not (ctx.puede("inventario") and ctx.puede("facturar")):
        raise HTTPException(403, "Para trasladar inventario su rol necesita facturar e inventario")
    e = ctx.empresa
    _exigir_extra(e)
    if not data.lineas:
        raise HTTPException(400, "Agregue al menos un producto")
    posibles = {x[0].id: x for x in destinos(sc, ctx)}
    if data.empresa_destino_id not in posibles:
        raise HTTPException(400, "No puede trasladar a esa empresa: necesita acceso a ella con permisos de gastos e inventario")
    ed = posibles[data.empresa_destino_id][0]
    pct = Decimal(str(data.porcentaje if data.porcentaje is not None else config(s, e.id)["porcentaje"]))
    # un reenvío del mismo formulario devuelve el traslado ya hecho (la factura no se repite)
    if data.clave_peticion:
        for x in modulos.leer(s, e.id, CLAVE_SALIDAS, []) or []:
            if isinstance(x, dict) and x.get("clave_peticion") == data.clave_peticion:
                return _respuesta(x)
    lineas_fe, detalle = [], []
    for l in data.lineas:
        p = s.get(Producto, l.producto_id)
        if p is None or p.empresa_id != e.id or not p.activo:
            raise HTTPException(400, f"Producto {l.producto_id} no existe en esta empresa")
        if p.es_servicio or not p.es_venta or not p.inventariable:
            raise HTTPException(400, f"«{p.nombre}» no es mercadería inventariable: solo se trasladan productos con existencias")
        costo = Decimal(str(p.costo or 0))
        if costo <= 0:
            raise HTTPException(400, f"«{p.nombre}» no tiene costo registrado y el traslado se factura al costo: póngalo en la ficha del ítem")
        precio = (costo * (1 + pct / 100)).quantize(Decimal("0.01"))
        lineas_fe.append(m.LineaIn(producto_id=p.id, cabys=p.cabys, detalle=p.nombre, cantidad=l.cantidad, precio_unitario=precio, unidad_medida=p.unidad_medida or "Unid",
                                   es_servicio=False, codigo_tarifa=p.codigo_tarifa or "08", tarifa=Decimal(str(p.tarifa if p.tarifa is not None else 13))))
        detalle.append({"producto_id": p.id, "codigo": p.codigo, "nombre": p.nombre, "cabys": p.cabys, "cantidad": float(l.cantidad), "precio_unitario": float(precio), "costo": float(costo),
                        "codigo_tarifa": p.codigo_tarifa or "08", "tarifa": float(p.tarifa if p.tarifa is not None else 13), "unidad_medida": p.unidad_medida or "Unid",
                        "moneda_precio": p.moneda, "precio_venta": p.precio, "categoria": p.categoria, "descripcion": p.descripcion, "partida": p.partida_arancelaria, "otro_impuesto": p.otro_impuesto})
    cli = _contacto(s, e.id, ed, "Cliente")
    obs = (f"Traslado de inventario a {ed.nombre}" + (f" · {data.observaciones.strip()}" if (data.observaciones or "").strip() else ""))[:200]
    doc = m.crear_comprobante(m.ComprobanteIn(tipo_documento="01", cliente_id=cli.id, condicion_venta="01", medio_pago="04", moneda="CRC", tipo_cambio=Decimal("1"),
                                              bodega_id=data.bodega_origen_id, lineas=lineas_fe, observaciones=obs,
                                              idempotencia=f"traslado:{data.clave_peticion}" if data.clave_peticion else None), ctx, s)
    salida = {"fecha": ahora_cr().isoformat(timespec="seconds"), "empresa_destino_id": ed.id, "empresa_destino": ed.nombre, "documento_id": doc.id, "consecutivo": doc.consecutivo,
              "clave": doc.clave if doc.estado != "interno" else None, "estado": doc.estado, "total": float(doc.total), "impuesto": float(doc.impuesto or 0), "porcentaje": float(pct),
              "bodega_origen_id": data.bodega_origen_id, "bodega_destino_id": data.bodega_destino_id, "observaciones": (data.observaciones or "").strip() or None,
              "detalle": detalle, "lineas": len(detalle), "usuario": getattr(ctx.usuario, "correo", None), "clave_peticion": data.clave_peticion,
              "compra_id_destino": None, "entrada_id_destino": None, "productos_creados": [], "error": None}
    try:
        salida.update(_registrar_en_destino(sc, ctx, e, ed, salida, data.bodega_destino_id, request))
    except HTTPException as ex:
        salida["error"] = str(ex.detail)
    except Exception as ex:  # noqa: BLE001  la factura ya salió: se anota y se puede reintentar el lado de la empresa que recibe
        log.exception("Traslado %s: no se pudo registrar en la empresa %s", doc.consecutivo, ed.id)
        salida["error"] = str(ex)[:300]
    salida["id"] = _agregar(s, e.id, CLAVE_SALIDAS, salida)
    s.commit()
    auditar(sc, "traslado_enviado", f"A {ed.nombre}: {doc.consecutivo} · {len(detalle)} líneas · ₡{float(doc.total):,.0f} · costo +{float(pct):g} %" + (f" · ERROR en destino: {salida['error']}" if salida["error"] else ""),
            ctx.usuario if getattr(ctx.usuario, "id", None) is not None else None, e.id, request, correo=getattr(ctx.usuario, "correo", None))
    return _respuesta(salida)


def _respuesta(x: dict) -> dict:
    return {k: x.get(k) for k in ("id", "documento_id", "consecutivo", "clave", "estado", "total", "impuesto", "porcentaje", "empresa_destino_id", "empresa_destino",
                                 "compra_id_destino", "bodega_destino", "productos_creados", "lineas", "error")}


@router.post("/{sid}/reintentar")
def reintentar(sid: int, request: Request, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """La factura salió pero la empresa que recibe no pudo registrarla (bodega inactiva, sin acceso…): repite solo ese lado."""
    if not (ctx.puede("inventario") and ctx.puede("facturar")):
        raise HTTPException(403, "Para trasladar inventario su rol necesita facturar e inventario")
    lista = modulos.leer(s, ctx.empresa.id, CLAVE_SALIDAS, []) or []
    x = next((y for y in lista if isinstance(y, dict) and y.get("id") == sid), None)
    if x is None:
        raise HTTPException(404, "Traslado no encontrado")
    if x.get("compra_id_destino"):
        return _respuesta(x)
    posibles = {y[0].id: y for y in destinos(sc, ctx)}
    if x.get("empresa_destino_id") not in posibles:
        raise HTTPException(400, "Ya no tiene acceso a la empresa de destino")
    ed = posibles[x["empresa_destino_id"]][0]
    try:
        x.update(_registrar_en_destino(sc, ctx, ctx.empresa, ed, x, x.get("bodega_destino_id"), request))
    except HTTPException as ex:
        x["error"] = str(ex.detail)
    modulos.aplicar_cambios(s, ctx.empresa.id, CLAVE_SALIDAS, [x], [], [])
    s.commit()
    if x.get("error"):
        raise HTTPException(400, f"No se pudo registrar en {ed.nombre}: {x['error']}")
    return _respuesta(x)
