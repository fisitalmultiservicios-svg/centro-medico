"""4.31: la misma mesa abierta en dos equipos sin perder platos (diseño «la misma mesa», secciones 4.1 a 4.6).

Regla para unir dos guardados de una cuenta de la caja (`pos_espera`), escrita también en JS (pages/pos/_fusion.js) y probada con los
mismos casos (tests/test_431_fusion_casos.json). Este módulo no depende de nada del sistema: se carga en pruebas sin main.py.

- Cada línea lleva un identificador propio `lid`. Las que no lo tienen reciben uno determinista (poner_lids), igual en la pantalla y
  aquí: 'h:' + id de la cuenta + ':' + clave + ':' + enviado + ':' + k [+ ':' + d].
- Quien guarda dice qué cambió en `_fusion = {v: 1, equipo, origen, nuevas, quitadas, campos, cuenta}`; el servidor lo usa y nunca lo
  guarda (unir, recrear).
- La cuenta guarda las líneas quitadas o cobradas (`lids_quitados`, las últimas 300): no vuelven nunca, ni por un reenvío.
- Una baja con condición (cerrar) no se lleva un plato que otro equipo agregó en esos segundos.
- Nunca lanza: ante un dato raro hace lo de antes (gana el último en guardar).
- 4.31 (corrección): la línea que queda de una línea partida lleva `de` = el lid de la línea de la que sale; si otro equipo ya partió,
  cobró o quitó esa línea, el resto no se agrega otra vez (dos equipos que parten la misma línea no duplican la cantidad). Una baja que
  viene de un cobro (`cobro: true`) no deja en la cuenta conservada lo ya pagado del pedido en línea, y una cuenta recreada no toma de lo
  que llega los datos del pedido en línea de la cuenta ya cobrada.
- 4.31 (quinta vuelta), solo de la caja: `_fusion.vuelve` = {lid: cantidad}, la parte de un cobro cerrado sin cobrar que la pantalla sumó a
  esa línea; si la línea ya no llega a la cuenta, esa cantidad vuelve sola (`<lid>+v`): nunca desaparece. `_fusion.enteras` = [lid], las
  líneas que el cobro de esa pantalla cerró enteras: el resto (`de`) que otro equipo dejó al partirlas sale con lo cobrado.
- 4.31 (sexta vuelta): esa parte vuelve solo si su línea estuvo en la cuenta (otro equipo pudo partir los mismos platos a la vez).
- 4.31 (séptima vuelta): y vuelve sin la marca del 2x1 (`promo_fija`): aquí no se sabe si su par se cobró o se quitó; lo decide la caja."""
from decimal import ROUND_HALF_UP, Decimal
import math

CAMPOS_MARCA = ("preparando", "listo", "entregado", "impreso", "comanda")
ORIGENES = ("caja", "cocina", "servidor")
MAX_LAPIDAS = 300
CAMPOS_RECREADA = ("nombre", "mesa_id", "mesas_ids", "terminal_id", "salonero", "servicio", "servicio_pct", "cliente_id", "nota")
_OCULTOS = ("lids_quitados", "recreada_de")
# lo del pedido en línea que ya se aplicó al cobrar la cuenta (main.CAMPOS_PEDIDO_EN_LINEA): una cuenta recreada no lo toma de lo que llega
CAMPOS_PEDIDO_COBRADO = ("canal", "pedido_id", "pedido_numero", "prepago", "cupon", "puntos_canjeados", "credito")
# lo ya pagado que una baja por cobro deja vacío en la cuenta conservada (recrear tampoco lo lleva)
CAMPOS_PAGADOS = ("prepago", "cupon", "puntos_canjeados")


class _Raro(Exception):
    """Dato que no se puede unir con la regla: se hace lo de antes (paso 0)."""


def _es_num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _num(v) -> float:
    """Cantidad como número (como el +x de la pantalla). Sin valor: 0. Texto que no es número: dato raro."""
    if v is None:
        return 0.0
    if _es_num(v):
        return float(v)
    if isinstance(v, str):
        try:
            x = float(v.strip()) if v.strip() else 0.0
        except ValueError:
            raise _Raro("cantidad")
        if not math.isfinite(x):
            raise _Raro("cantidad")
        return x
    raise _Raro("cantidad")


def _txt_id(v) -> str:
    """Un número entero escrito sin decimales (JS String(6)); otra cosa, como texto."""
    if _es_num(v) and float(v).is_integer():
        return str(int(v))
    if v is None:
        return ""
    return str(v)


def _clave(l: dict) -> str:
    """producto_id si es un número entero; si no, el detalle (texto)."""
    p = l.get("producto_id")
    if _es_num(p) and float(p).is_integer():
        return str(int(p))
    d = l.get("detalle")
    return d if isinstance(d, str) else ""


def _enviado(l: dict) -> str:
    e = l.get("enviado")
    if not e:
        return ""
    return e if isinstance(e, str) else str(e)


def _tiene_lid(l: dict) -> bool:
    return isinstance(l.get("lid"), str) and l.get("lid") != ""


def _libre(base: str, usados: set) -> str:
    """base, o base + ':d' (d = 1, 2, 3…) hasta que quede libre."""
    if base not in usados:
        return base
    d = 1
    while f"{base}:{d}" in usados:
        d += 1
    return f"{base}:{d}"


def _lineas_con_lid(cuenta: dict) -> list:
    """Copia de las líneas de la cuenta, cada una con su `lid` (4.1). Lanza _Raro si las líneas no son una lista de objetos."""
    lineas = cuenta.get("lineas")
    if lineas is None:
        lineas = []
    if not isinstance(lineas, list) or not all(isinstance(l, dict) for l in lineas):
        raise _Raro("lineas")
    idc = _txt_id(cuenta.get("id"))
    todos = {l["lid"] for l in lineas if _tiene_lid(l)}       # un lid que ya tiene otra línea no se le da a una sin lid
    usados: set = set()
    cuenta_k: dict = {}
    out = []
    for l in lineas:
        x = dict(l)
        if _tiene_lid(l):
            if l["lid"] in usados:                             # repetido (solo por un error): la segunda recibe el desempate
                x["lid"] = _libre(l["lid"], todos | usados)
        else:
            ck = (_clave(l), _enviado(l))
            k = cuenta_k.get(ck, 0); cuenta_k[ck] = k + 1     # solo cuentan las líneas sin lid
            x["lid"] = _libre(f"h:{idc}:{ck[0]}:{ck[1]}:{k}", todos | usados)
        usados.add(x["lid"])
        out.append(x)
    return out


def poner_lids(cuenta):
    """Copia de la cuenta con un `lid` en cada línea (4.1). Si no se puede (dato raro), la devuelve igual."""
    if not isinstance(cuenta, dict):
        return cuenta
    try:
        return {**cuenta, "lineas": _lineas_con_lid(cuenta)}
    except _Raro:
        return cuenta


def _sin_fusion(x: dict) -> dict:
    return {k: v for k, v in x.items() if k != "_fusion"}


def fusion_valida(x) -> bool:
    """El elemento trae `_fusion` de esta regla (objeto con v == 1)."""
    f = x.get("_fusion") if isinstance(x, dict) else None
    return isinstance(f, dict) and f.get("v") == 1 and not isinstance(f.get("v"), bool)


def _leer_fusion(x: dict) -> dict:
    """`_fusion` validado y normalizado; _Raro si algo no tiene el tipo esperado."""
    f = x.get("_fusion")
    origen = f.get("origen")
    if origen not in ORIGENES:
        raise _Raro("origen")
    nuevas = f.get("nuevas") or []
    quitadas = f.get("quitadas") or {}
    campos = f.get("campos") or {}
    cuenta = f.get("cuenta") or []
    if not isinstance(nuevas, list) or not all(isinstance(i, str) for i in nuevas):
        raise _Raro("nuevas")
    if not isinstance(quitadas, dict) or not all(_es_num(q) for q in quitadas.values()):
        raise _Raro("quitadas")
    if not isinstance(campos, dict) or not all(isinstance(c, list) and all(isinstance(k, str) for k in c) for c in campos.values()):
        raise _Raro("campos")
    if not isinstance(cuenta, list) or not all(isinstance(k, str) for k in cuenta):
        raise _Raro("cuenta")
    vuelve = f.get("vuelve") or {}                         # 4.31 (quinta vuelta)
    enteras = f.get("enteras") or []
    if not isinstance(vuelve, dict) or not all(_es_num(q) for q in vuelve.values()):
        raise _Raro("vuelve")
    if not isinstance(enteras, list) or not all(isinstance(k, str) for k in enteras):
        raise _Raro("enteras")
    return {"origen": origen, "nuevas": set(nuevas), "quitadas": {k: float(v) for k, v in quitadas.items()},
            "campos": campos, "cuenta": set(cuenta), "vuelve": vuelve, "enteras": set(enteras)}


def _lapidas(cuenta: dict) -> list:
    v = cuenta.get("lids_quitados")
    return [i for i in v if isinstance(i, str)] if isinstance(v, list) else []


def _r3(x: float) -> float:
    return float(Decimal(str(x)).quantize(Decimal("0.001"), ROUND_HALF_UP))


def _resto(g: dict, q: float, ocupados: set):
    """Lo que queda de una línea cobrada o quitada con menos cantidad de la que tenía guardada (D-6), o None."""
    cant = _num(g.get("cantidad"))
    if cant - q > 0.0005:
        n = 1
        while f"{g['lid']}~{n}" in ocupados:
            n += 1
        lid = f"{g['lid']}~{n}"
        ocupados.add(lid)
        return {**g, "lid": lid, "cantidad": _r3(cant - q)}
    return None


def _resto_ajeno(l: dict, lap0: set, g_lids: set) -> bool:
    """La línea es lo que quedó de partir otra (`de`) y esa otra ya la partió, cobró o quitó otro equipo antes de este guardado: no se
    agrega (si no, dos equipos que parten la misma línea dejaban dos restos y la cantidad se duplicaba)."""
    de = l.get("de")
    return isinstance(de, str) and de != "" and de in lap0 and de not in g_lids


def _las_que_vuelven(f: dict, n_por: dict, out: list, tuvo, salta=frozenset()) -> None:
    """4.31 (quinta vuelta): la parte de un cobro cerrado sin cobrar que la pantalla sumó a una línea (`vuelve`) que ya no llegó a la cuenta
    (otro equipo la cobró, la partió o la quitó antes) vuelve sola: una línea nueva `<lid>+v` con esa cantidad, sin `de` y sin importe (el
    total lo rehace la pantalla). `tuvo`: los lid que la cuenta tenía o tuvo (un reenvío no la agrega dos veces); None en una cuenta
    recreada. Cambia `out`.
    4.31 (sexta vuelta): vuelve solo si esa línea estuvo en la cuenta (si no, era el resto que no se aceptó porque otro equipo partió los
    mismos platos a la vez: esa parte ya está en la del otro y se cobraba dos veces); en la recreada, no la de un resto de lo cerrado
    (`salta`).
    4.31 (séptima vuelta): sin la marca del 2x1 (`promo_fija`): aquí no se sabe si su par se cobró o se quitó. Lo decide la caja (solo con el
    cobro confirmado por el servidor la parte vuelve marcada, y no a una línea ya cobrada); esta línea la caja la calcula como cualquier otra."""
    en_out = {l["lid"] for l in out}
    for lid in sorted(f["vuelve"]):
        q, y, lv = f["vuelve"][lid], n_por.get(lid), lid + "+v"
        if y is None or lid in f["quitadas"] or not q > 0.0005 or lid in en_out or lv in en_out or lid in salta:
            continue
        if tuvo is not None and (lid not in tuvo or lv in tuvo):
            continue
        z = {k: v for k, v in y.items() if k not in ("de", "importe", "importe_de", "promo_fija")}
        c = _r3(q)
        out.append({**z, "lid": lv, "cantidad": c})
        en_out.add(lv)


def _va(l: dict) -> bool:
    """Cantidad cero o menos: la línea no va (sin cantidad sí va)."""
    return "cantidad" not in l or l.get("cantidad") is None or _num(l.get("cantidad")) > 0


def redondear(x) -> float:
    """Mitad hacia arriba a 2 decimales sobre el número escrito (Decimal(str(x)))."""
    return float(Decimal(str(x)).quantize(Decimal("0.01"), ROUND_HALF_UP))


def total_de(lineas: list):
    """Total por la suma de los `importe` (4.6), o None si alguna línea no tiene `importe` al día."""
    s = 0.0
    for l in lineas:
        imp, de = l.get("importe"), l.get("importe_de")
        if not _es_num(imp) or not isinstance(de, list) or len(de) != 4:
            return None
        if [l.get("cantidad"), l.get("precio_unitario"), l.get("descuento_pct"), l.get("descuento")] != de:
            return None
        s += float(imp)
    return redondear(s)


def _unir_cobros(g, n):
    if not isinstance(g, list):
        g = []
    if not isinstance(n, list):
        return list(g)
    def clave(c):
        if isinstance(c, dict):
            if c.get("doc_id") not in (None, ""):
                return ("d", str(c.get("doc_id")))
            if c.get("consecutivo") not in (None, ""):
                return ("c", str(c.get("consecutivo")))
        return None
    out = list(g)
    claves = {clave(c) for c in g if clave(c) is not None}
    for c in n:
        k = clave(c)
        if k is None:
            if c not in out:                               # sin doc_id ni consecutivo: solo si no hay uno igual
                out.append(c)
        elif k not in claves:
            out.append(c); claves.add(k)
    return out


def _cobradas(p) -> float:
    return _num(p.get("cobradas")) if isinstance(p, dict) else 0.0


def _paso0(guardada, nueva: dict) -> dict:
    """Sin `_fusion` válido o con datos raros: lo de antes (gana el último), conservando los dos campos ocultos de la cuenta guardada
    y anotando como quitadas las líneas guardadas que ya no vienen (D-9)."""
    res = _sin_fusion(nueva)
    if not isinstance(guardada, dict):
        return res
    if "recreada_de" not in res and "recreada_de" in guardada:
        res["recreada_de"] = guardada["recreada_de"]
    lap = _lapidas(guardada)
    for i in _lapidas(res):
        if i not in lap:
            lap.append(i)
    try:
        vienen = {l["lid"] for l in _lineas_con_lid(nueva)}
        for l in _lineas_con_lid(guardada):
            if l["lid"] not in vienen and l["lid"] not in lap:
                lap.append(l["lid"])
    except _Raro:
        pass
    if lap or "lids_quitados" in guardada or "lids_quitados" in res:
        res["lids_quitados"] = lap[-MAX_LAPIDAS:]
    return res


def _visible(c: dict) -> dict:
    return {k: v for k, v in c.items() if k not in _OCULTOS and k != "_fusion"}


def unir(guardada, nueva):
    """La regla de 4.3: (cuenta que se guarda, fusiono). `fusiono` es verdadero si lo que queda es distinto de lo que llegó (sin
    contar `_fusion`, los `lid` puestos ni los dos campos ocultos). Nunca lanza."""
    if not isinstance(nueva, dict):
        return nueva, False
    try:
        if not isinstance(guardada, dict) or not fusion_valida(nueva):
            return _paso0(guardada, nueva), False
        return _unir(guardada, nueva)
    except Exception:  # noqa: BLE001  (paso 7: ante un dato raro, lo de antes)
        try:
            return _paso0(guardada, nueva), False
        except Exception:  # noqa: BLE001
            return _sin_fusion(nueva), False


def _unir(g: dict, n: dict):
    f = _leer_fusion(n)
    origen, caja = f["origen"], f["origen"] == "caja"
    gl, nl = _lineas_con_lid(g), _lineas_con_lid(n)
    lap = _lapidas(g)
    lap_set = set(lap)
    lap0 = set(lap)                                        # las quitadas ANTES de este guardado (por otro equipo o antes)
    n_por = {l["lid"]: l for l in nl}
    g_lids = {l["lid"] for l in gl}
    ocupados = g_lids | set(n_por) | lap_set
    out = []
    for gl_ in gl:                                         # paso 2: en el orden de lo guardado
        lid = gl_["lid"]
        if lid in f["quitadas"]:
            if lid not in lap_set:
                lap.append(lid); lap_set.add(lid)
            if caja:
                r = _resto(gl_, f["quitadas"][lid], ocupados)
                if r is not None:
                    out.append(r)
            continue
        nl_ = n_por.get(lid)
        if nl_ is None:
            out.append(gl_)                                # la agregó otro equipo, o este no la conocía
            continue
        if caja and lid in f["nuevas"]:                    # reenvío de un plato propio
            x = dict(nl_)
            for k in CAMPOS_MARCA:
                if gl_.get(k) and not x.get(k):
                    x[k] = gl_[k]
            out.append(x)
            continue
        x = dict(gl_)
        cs = f["campos"].get(lid) or []
        for c in cs:
            if c == "lid" or (not caja and c not in CAMPOS_MARCA):
                continue
            if c in nl_:
                x[c] = nl_[c]
            else:
                x.pop(c, None)
        out.append(x)
    if caja:                                               # paso 3: las nuevas de este equipo, al final
        for l in nl:
            if l["lid"] not in g_lids and l["lid"] in f["nuevas"] and l["lid"] not in lap_set and not _resto_ajeno(l, lap0, g_lids):
                out.append(l)
        if f["enteras"]:
            # 4.31 (quinta vuelta): el resto (`de`) de una línea que el cobro de esta pantalla cerró entera es parte de lo cobrado: sale (lo
            # haya dejado otro equipo o venga en este guardado) y queda como quitado, así un reenvío da lo mismo
            quedan = []
            for l in out:
                de = l.get("de")
                if isinstance(de, str) and de != "" and de in f["enteras"]:
                    if l["lid"] not in lap_set:
                        lap.append(l["lid"]); lap_set.add(l["lid"])
                else:
                    quedan.append(l)
            out = quedan
    out = [l for l in out if _va(l)]                       # paso 4
    if caja:                                               # 4.31 (quinta vuelta): después del paso 4 (una línea en cero no la tapa)
        _las_que_vuelven(f, n_por, out, g_lids | lap_set)
    res = {}                                               # paso 5: campos de la cuenta
    recreada = "recreada_de" in g
    for k in list(g.keys()) + [k for k in n.keys() if k not in g]:
        if k in ("_fusion", "lineas", "lids_quitados", "recreada_de", "total"):
            continue
        if recreada and k in CAMPOS_PEDIDO_COBRADO and k not in g:
            continue                                       # la cuenta recreada no hereda lo pagado ni el enlace de la ya cobrada
        if k == "cobros":
            res[k] = _unir_cobros(g.get(k), n.get(k)) if k in g else n.get(k)
        elif k == "partes":
            if k not in g:
                res[k] = n.get(k)
            elif "partes" in f["cuenta"]:
                p, gp = n.get("partes"), g.get("partes")
                if p is None and _cobradas(gp) > 0:
                    res[k] = gp
                elif isinstance(p, dict) and isinstance(gp, dict) and ("cobradas" in p or "cobradas" in gp):
                    c = max(_cobradas(p), _cobradas(gp))
                    res[k] = {**p, "cobradas": int(c) if float(c).is_integer() else c}
                else:
                    res[k] = p
            else:
                res[k] = g[k]
        elif k in ("actualizado", "usuario"):
            res[k] = n[k] if k in n else g[k]
        elif k in f["cuenta"]:
            if k in n:
                res[k] = n[k]
        elif k in g:
            res[k] = g[k]
        else:
            res[k] = n[k]
    res["lineas"] = out
    if lap or "lids_quitados" in g:                        # sin lápidas no se agrega la lista vacía
        res["lids_quitados"] = lap[-MAX_LAPIDAS:]
    if "recreada_de" in g:
        res["recreada_de"] = g["recreada_de"]
    cambio_lineas = out != nl
    t = total_de(out) if cambio_lineas else None           # 4.6: solo si la fusión cambió las líneas
    if t is not None:
        res["total"] = t
    elif "total" in n:
        res["total"] = n["total"]
    elif "total" in g:
        res["total"] = g["total"]
    fusiono = _visible(res) != _visible({**n, "lineas": nl})
    return res, fusiono


def cerrar(guardada, condicion):
    """Baja condicional (4.4): None si no queda nada más (se borra como antes); si quedó algo, la cuenta con lo que quedó. Si la baja
    viene de un cobro (`cobro: true`), la cuenta que queda no lleva lo ya pagado del pedido en línea (prepago, cupón, puntos) ni el resto
    (`de`) de una línea que ese cobro cerró entera (otro equipo la partió mientras tanto: ese resto es parte de lo cobrado)."""
    try:
        if not isinstance(guardada, dict) or not isinstance(condicion, dict) or condicion.get("v") != 1:
            return None
        quitadas = condicion.get("quitadas") or {}
        if not isinstance(quitadas, dict) or not all(_es_num(q) for q in quitadas.values()):
            return None
        gl = _lineas_con_lid(guardada)
        lap = _lapidas(guardada)
        lap_set = set(lap)
        ocupados = {l["lid"] for l in gl} | lap_set
        cobro = condicion.get("cobro") is True
        quedan = []
        for l in gl:
            if l["lid"] in quitadas:
                if l["lid"] not in lap_set:
                    lap.append(l["lid"]); lap_set.add(l["lid"])
                r = _resto(l, float(quitadas[l["lid"]]), ocupados)
                if r is not None:
                    quedan.append(r)
            elif cobro and isinstance(l.get("de"), str) and l["de"] != "" and l["de"] in quitadas:
                # 4.31 (cuarta vuelta): el resto que otro equipo dejó al partir una línea que este cobro cerró entera es parte de lo cobrado
                if l["lid"] not in lap_set:
                    lap.append(l["lid"]); lap_set.add(l["lid"])
            else:
                quedan.append(l)
        quedan = [l for l in quedan if _va(l)]
        if not quedan:
            return None
        res = {**_sin_fusion(guardada), "lineas": quedan}
        if cobro:                                          # ya se aplicó en el cobro: no se cobra ni se registra otra vez
            for k in CAMPOS_PAGADOS:                       # vacíos (no borrados): un guardado atrasado no los vuelve a poner (paso 5)
                if k in res:
                    res[k] = 0 if k == "puntos_canjeados" else None
        if lap or "lids_quitados" in guardada:
            res["lids_quitados"] = lap[-MAX_LAPIDAS:]
        t = total_de(quedan)
        if t is not None:
            res["total"] = t
        return res
    except Exception:  # noqa: BLE001  (dato raro: se borra como antes)
        return None


def recrear(nueva, id_viejo, id_nuevo):
    """4.5: un guardado de la caja que llega a una cuenta ya cerrada deja lo que ese equipo agregó en una cuenta nueva de la misma
    mesa. None si no corresponde (otro origen, nada agregado o dato raro)."""
    try:
        if not isinstance(nueva, dict) or not fusion_valida(nueva):
            return None
        f = _leer_fusion(nueva)
        if f["origen"] != "caja":
            return None
        nl = _lineas_con_lid(nueva)
        # 4.31 (tercera vuelta): el resto de una línea partida (`de`) cuya línea de origen esta pantalla tenía guardada (la quita en este
        # guardado) era de la cuenta ya cobrada o cerrada: no pasa a la nueva (se cobraba dos veces) y queda como quitado
        # 4.31 (quinta vuelta): también el de una línea que el cobro de esta pantalla cerró entera (`enteras`); y la parte de un cobro cerrado
        # sin cobrar que se sumó a una línea de la cuenta cerrada (`vuelve`) pasa sola a la nueva
        resto_de_cerrada = {l["lid"] for l in nl if isinstance(l.get("de"), str) and l["de"] != "" and (l["de"] in f["quitadas"] or l["de"] in f["enteras"])}
        lineas = [l for l in nl if l["lid"] in f["nuevas"] and _va(l) and l["lid"] not in resto_de_cerrada]
        _las_que_vuelven(f, {l["lid"]: l for l in nl}, lineas, None, resto_de_cerrada)
        if not lineas:
            return None
        res = {"id": id_nuevo}
        for k in CAMPOS_RECREADA:
            if k in nueva:
                res[k] = nueva[k]
        res["lineas"] = lineas
        res["cobros"] = []
        res["partes"] = None
        res["recreada_de"] = id_viejo
        quitados = [l["lid"] for l in nl if l["lid"] not in f["nuevas"] or l["lid"] in resto_de_cerrada][-MAX_LAPIDAS:]
        if quitados:                                       # sin lápidas no se agrega la lista vacía
            res["lids_quitados"] = quitados
        t = total_de(lineas)
        if t is not None:
            res["total"] = t
        return res
    except Exception:  # noqa: BLE001
        return None


def es_recreada_de(datos, iid) -> bool:
    """La cuenta `datos` es la que se recreó para la cuenta cerrada `iid`."""
    if not isinstance(datos, dict):
        return False
    r = datos.get("recreada_de")
    return _es_num(r) and _es_num(iid) and float(r) == float(iid)
