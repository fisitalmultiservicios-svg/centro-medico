"""Sitio público de FISITAAP by Brillante Agencia (1.36; varias páginas desde la 1.38): páginas informativas en la raíz del dominio, planes y contacto
editables por el administrador del sistema (data/sitio.json) y solicitudes del formulario de contacto (tabla central SolicitudContacto,
con el origen de la visita para medir redes y anuncios). El sistema vive en /app/.

Cada página es un archivo de app/sitio_web/ con sus datos en un comentario inicial (titulo, descripcion, imagen, miga, padre, software,
script); base.html pone la cabecera, el pie, las etiquetas para buscadores y redes (canónica, Open Graph) y los datos estructurados
(Organization, SoftwareApplication con precios en colones, FAQPage armado de los <details> de la página y BreadcrumbList).

La página se arma en el servidor (buena para buscadores y funciona sin JavaScript). Las solicitudes se guardan siempre y se avisan por
correo a los correos de ventas con el SMTP de la plataforma (FE_SMTP_*) o, si no está, con el de la empresa indicada en la configuración.
"""
import copy
import json
import logging
import os
import re
import threading
import time
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, Response
from pydantic import BaseModel, Field
from sqlmodel import Field as SField, Session, SQLModel, select

from .config import DATA_DIR, nombre_sistema, dominio_sistema, correo_ventas
from .auth import superadmin
from .db import central, engine, get_session

log = logging.getLogger(__name__)
ARCHIVO = DATA_DIR / "sitio.json"
WEB = Path(__file__).parent / "sitio_web"
# ruta pública → archivo de app/sitio_web (el orden es el del sitemap)
PAGINAS = {
    "/": "inicio", "/factura-electronica": "factura-electronica", "/punto-de-venta": "punto-de-venta", "/ventas-en-linea": "ventas-en-linea", "/hotel": "hotel", "/restaurante": "restaurante", "/servicios": "servicios", "/planillas": "planillas",
    "/exoneraciones": "exoneraciones", "/contabilidad": "contabilidad", "/precios": "precios", "/prueba-gratis": "prueba-gratis",
    "/cambiar-de-sistema": "cambiar-de-sistema", "/herramientas/calculadora-aguinaldo": "calculadora-aguinaldo",
    "/guias": "guias", "/guias/requisitos-factura-electronica": "guia-requisitos-factura-electronica",
    "/guias/aceptar-facturas-de-proveedores": "guia-aceptar-facturas-de-proveedores",
    "/guias/planilla-paso-a-paso": "guia-planilla-paso-a-paso",
}
# páginas «padre» de las migas que tienen dirección propia (las demás se muestran sin enlace)
PADRES = {"Guías": "/guias"}
ITCORESYNC = {"@type": "Organization", "name": "IT Core Sync S.R.L.", "url": "https://www.itcoresync.com/"}
BRILLANTE = {"@type": "Organization", "name": "Brillante Agencia", "url": "https://brillanteagencia.com/"}

DEFECTO = {
    "contacto": {"whatsapp": "62281597", "correos": ["ventas@itcoresync.com"], "correo_empresa_id": None},
    # Planes por tipo de negocio (3.16, decisiones de Norman 19/10/2026): facturación con límite de documentos (mensual o prepago
    # anual, como GTI), punto de venta mensual sin límite, hotelería por habitación. Extras iguales para todos.
    "planes": {
        "facturacion": [
            {"nombre": "Básico", "precio": 2500, "periodo": "mes", "documentos": "10 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Facturas, tiquetes y notas electrónicas 4.4", "Clientes, ítems y cobros", "Exoneraciones verificadas con Hacienda"]},
            {"nombre": "Emprendedor", "precio": 4900, "periodo": "mes", "documentos": "50 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Facturas, tiquetes y notas electrónicas 4.4", "Inventario con bodegas, cotizaciones y remisiones", "Cobros, gastos, bancos y recepción de comprobantes", "Exoneraciones verificadas con Hacienda"]},
            {"nombre": "Pospago 250", "precio": 9900, "periodo": "mes", "documentos": "250 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": True,
             "incluye": ["Todo lo de Emprendedor", "Declaración de IVA (D-104)", "Facturas recurrentes y estados de cuenta"]},
            {"nombre": "Pospago 500", "precio": 19900, "periodo": "mes", "documentos": "500 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Todo lo de Pospago 250"]},
            {"nombre": "Pospago 1.000", "precio": 32900, "periodo": "mes", "documentos": "1.000 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Todo lo de Pospago 250"]},
            {"nombre": "Prepago 24", "precio": 12900, "periodo": "anio", "documentos": "24 documentos al año", "usuarios": "Pago único, vigencia 1 año", "destacado": False,
             "incluye": ["Todo lo de Emprendedor", "Los documentos sin usar vencen al año"]},
            {"nombre": "Prepago 60", "precio": 19900, "periodo": "anio", "documentos": "60 documentos al año", "usuarios": "Pago único, vigencia 1 año", "destacado": False,
             "incluye": ["Todo lo de Emprendedor", "Los documentos sin usar vencen al año"]},
            {"nombre": "Prepago 150", "precio": 27900, "periodo": "anio", "documentos": "150 documentos al año", "usuarios": "Pago único, vigencia 1 año", "destacado": False,
             "incluye": ["Todo lo de Emprendedor", "Los documentos sin usar vencen al año"]},
            {"nombre": "Persona física ilimitado", "precio": 6900, "periodo": "mes", "documentos": "Documentos ilimitados", "usuarios": "Solo cédula física", "destacado": False,
             "incluye": ["Todo lo de Emprendedor"]},
            {"nombre": "Régimen simplificado", "precio": 2500, "periodo": "mes", "documentos": "Documentos ilimitados", "usuarios": "Solo régimen simplificado", "destacado": False,
             "incluye": ["Facturas, tiquetes y notas electrónicas 4.4", "Clientes, ítems y cobros"]},
        ],
        "comercio": [
            {"nombre": "Punto de venta básico", "precio": 9900, "periodo": "mes", "documentos": "500 documentos al mes", "usuarios": "1 caja · usuarios sin límite", "destacado": False,
             "incluye": ["Toda la facturación electrónica 4.4", "Caja, cierres, 10 % de servicio y propinas", "Inventario con bodegas", "Instalación local: vende sin internet"]},
            {"nombre": "Punto de venta", "precio": 19900, "periodo": "mes", "documentos": "Documentos ilimitados", "usuarios": "2 cajas · usuarios sin límite", "destacado": True,
             "incluye": ["Toda la facturación electrónica 4.4", "Caja, cierres, 10 % de servicio y propinas", "Inventario, recetas, comandas e impresión térmica", "Instalación local y red local: vende sin internet"]},
        ],
        # Restaurante · FISITAAP y Servicios/IT · TiKe (3.51): paquetes por tipo de empresa
        "restaurante": [
            {"nombre": "Restaurante básico · FISITAAP", "precio": 19900, "periodo": "mes", "documentos": "500 documentos al mes", "usuarios": "1 caja · usuarios sin límite", "destacado": False,
             "incluye": ["Punto de venta con mesas, comandas y monitor de preparación", "Catálogo en línea con pedidos a la caja y WhatsApp", "Opciones de cada plato, cupones y puntos", "Toda la facturación electrónica 4.4"]},
            {"nombre": "Restaurante · FISITAAP", "precio": 29900, "periodo": "mes", "documentos": "Documentos ilimitados", "usuarios": "2 cajas · usuarios sin límite", "destacado": True,
             "incluye": ["Todo lo del básico", "Pago con tarjeta en el carrito con su propia cuenta de Tilopay", "Tarjetas de regalo y correos al cliente", "Instalación local y red local: vende sin internet"]},
        ],
        "servicios": [
            {"nombre": "Servicios Emprendedor", "precio": 14900, "periodo": "mes", "documentos": "50 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Facturas, tiquetes y notas electrónicas 4.4", "TiKe: tickets de soporte con prioridades y SLA", "Portal del cliente para abrir y seguir tickets"]},
            {"nombre": "Servicios 250", "precio": 19900, "periodo": "mes", "documentos": "250 documentos al mes", "usuarios": "Usuarios sin límite", "destacado": True,
             "incluye": ["Todo lo de Emprendedor", "Contratos de soporte y bolsa de horas", "Equipos del cliente y facturar desde el ticket"]},
            {"nombre": "Servicios ilimitado", "precio": 29900, "periodo": "mes", "documentos": "Documentos ilimitados", "usuarios": "Usuarios sin límite", "destacado": False,
             "incluye": ["Todo lo de Servicios 250", "Documentación del cliente: contraseñas cifradas, procedimientos, redes y vencimientos"]},
        ],
        "hospitalidad": {"por_habitacion": 6000, "minimo": 6, "extra_habitacion": 1000, "precio_40": 300000, "precio_50": 360000, "canales_usd": 100, "destacado": True,
                         "incluye": ["Recepción, reservas, calendario y huéspedes", "Cuentas del huésped, depósitos en garantía y cierre del día", "Ama de llaves y mantenimiento", "Agencias, grupos y rooming list", "Toda la facturación electrónica 4.4", "Instalación local y red local: trabaja sin internet"],
                         "canales": "Integración con el administrador de canales (Booking, Expedia, Airbnb): USD 100 al mes en cualquier paquete"},
    },
    "adicionales": [
        {"nombre": "Contabilidad (enciende Reportes)", "precio": "₡9.900 al mes"},
        {"nombre": "Recursos humanos, hasta 10 empleados (enciende Reportes)", "precio": "₡10.000 al mes + ₡1.000 por empleado adicional"},
        {"nombre": "Extras del hotel (punto de venta, hotel completo, contabilidad, recursos humanos)", "precio": "₡1.000 por habitación al mes cada uno; incluidos desde 40 habitaciones"},
        {"nombre": "Integración con administrador de canales (hotel)", "precio": "USD 100 al mes"},
        {"nombre": "Caja adicional de punto de venta", "precio": "₡2.500 al mes"},
        {"nombre": "Paquete de 100 documentos (facturación)", "precio": "₡2.500, pago único"},
        {"nombre": "Empresa adicional", "precio": "50 % del plan"},
    ],
    "anual": "Pague el año completo y reciba 2 meses gratis.",
    # 3.58: portal TiKe de IT Core Sync para el enlace «Ayuda y soporte» de la aplicación (/soporte/<slug>) y su WhatsApp
    "soporte": {"slug": "", "whatsapp": ""},
    # 3.68: prueba gratis automática (el formulario crea el usuario y la empresa al instante y manda el acceso por correo) y
    # verificación Turnstile de Cloudflare (clave del sitio pública; la secreta se guarda cifrada con la clave maestra)
    # 3.84: turnstile_login = pedir la misma verificación al iniciar sesión y al recuperar la contraseña
    "prueba": {"automatica": False, "dias": 30, "turnstile_sitio": "", "turnstile_secreto": "", "turnstile_login": False},
}

# tipos de negocio como los ve el cliente en el formulario (los códigos son los de auth.TIPOS_NEGOCIO)
TIPOS_PUBLICO = [("facturacion", "Facturación y oficina"), ("comercio", "Comercio con punto de venta"), ("restaurante", "Restaurante, soda o cafetería"),
                 ("hospitalidad", "Hotel o cabinas"), ("servicios", "Servicios e IT con tickets de soporte")]


class SolicitudContacto(SQLModel, table=True):
    id: Optional[int] = SField(default=None, primary_key=True)
    nombre: str
    empresa: Optional[str] = None
    correo: str
    telefono: Optional[str] = None
    plan: Optional[str] = None
    mensaje: Optional[str] = None
    ip: Optional[str] = None
    origen: Optional[str] = None           # utm de la visita (facebook / instagram / anuncio…) o el sitio de donde vino
    pagina: Optional[str] = None           # página del sitio desde la que se envió
    atendida: bool = False
    notificada: bool = False
    acepta_novedades: bool = False         # marcó «Quiero recibir novedades» (permiso para publicidad, 3.39)
    cedula: Optional[str] = None           # 3.68: cédula física o jurídica (modo automático)
    tipo_negocio: Optional[str] = None     # 3.68: tipo elegido en el formulario
    empresa_id: Optional[int] = None       # 3.68: empresa de prueba creada automáticamente
    resultado: Optional[str] = None        # 3.68: qué pasó con la prueba automática (creada, ya tenía cuenta, sin correo…)
    creado: datetime = SField(default_factory=lambda: datetime.now(timezone.utc))


central(SolicitudContacto)


# ------------------------------------------------------------------------------------------------ configuración
def leer() -> dict:
    cfg = copy.deepcopy(DEFECTO)
    cfg["contacto"]["correos"] = [correo_ventas()] + [c for c in cfg["contacto"]["correos"] if c != correo_ventas()]   # 3.77: el de la consola
    try:
        guardado = json.loads(ARCHIVO.read_text(encoding="utf-8"))
        if isinstance(guardado, dict):
            for k in ("planes", "adicionales", "anual"):
                if k in guardado:
                    cfg[k] = guardado[k]
            if not isinstance(cfg.get("planes"), dict):          # guardado con la estructura anterior (una sola lista): se parte de los nuevos
                cfg["planes"] = copy.deepcopy(DEFECTO["planes"])
            for k in ("facturacion", "comercio", "restaurante", "hospitalidad", "servicios"):
                cfg["planes"].setdefault(k, copy.deepcopy(DEFECTO["planes"][k]))
            if isinstance(guardado.get("contacto"), dict):
                cfg["contacto"].update(guardado["contacto"])
            if isinstance(guardado.get("soporte"), dict):
                cfg["soporte"].update({k: str(v or "") for k, v in guardado["soporte"].items() if k in ("slug", "whatsapp")})
            if isinstance(guardado.get("prueba"), dict):
                p = guardado["prueba"]
                try:
                    dias = int(p.get("dias") or 30)
                except (TypeError, ValueError):
                    dias = 30
                cfg["prueba"].update({"automatica": bool(p.get("automatica")), "dias": dias, "turnstile_sitio": str(p.get("turnstile_sitio") or ""),
                                      "turnstile_secreto": str(p.get("turnstile_secreto") or ""), "turnstile_login": bool(p.get("turnstile_login"))})
    except (OSError, ValueError):
        pass
    return cfg


def soporte() -> dict:
    """Enlace de ayuda (3.58): dirección pública del portal TiKe de soporte del sistema y su WhatsApp, o vacíos si no se configuró."""
    sp = leer().get("soporte") or {}
    slug = str(sp.get("slug") or "").strip()
    return {"soporte_url": f"{base_url()}/soporte/{slug}" if slug else "", "soporte_whatsapp": str(sp.get("whatsapp") or "").strip()}


def _texto(v, maximo: int) -> str:
    return re.sub(r"\s+", " ", str(v or "")).strip()[:maximo]


def validar(data: dict) -> dict:
    """Normaliza lo que manda el panel: textos acotados, precios numéricos, correos válidos y WhatsApp de 8 dígitos."""
    c = data.get("contacto") or {}
    wa = re.sub(r"\D", "", str(c.get("whatsapp") or ""))
    if wa.startswith("506") and len(wa) == 11:
        wa = wa[3:]
    if wa and len(wa) != 8:
        raise HTTPException(400, "El WhatsApp debe tener 8 dígitos (sin el 506)")
    correos = [x.strip().lower() for x in (c.get("correos") or []) if str(x).strip()][:4]
    for x in correos:
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", x):
            raise HTTPException(400, f"Correo de ventas no válido: {x}")
    empresa_id = c.get("correo_empresa_id")
    try:
        empresa_id = int(empresa_id) if empresa_id not in (None, "", 0, "0") else None
    except (TypeError, ValueError):
        raise HTTPException(400, "Empresa para enviar los avisos no válida")
    entrada = data.get("planes") or {}
    if not isinstance(entrada, dict):
        raise HTTPException(400, "Los planes van por tipo de negocio")
    planes: dict = {}
    for tipo in ("facturacion", "comercio", "restaurante", "servicios"):
        lista = []
        for p in (entrada.get(tipo) or [])[:10]:
            nombre = _texto(p.get("nombre"), 40)
            if not nombre:
                continue
            try:
                precio = float(p.get("precio"))
            except (TypeError, ValueError):
                raise HTTPException(400, f"El precio del plan {nombre} debe ser un número")
            if not (0 <= precio < 10_000_000):
                raise HTTPException(400, f"Precio fuera de rango en el plan {nombre}")
            incluye = [_texto(x, 90) for x in (p.get("incluye") or []) if _texto(x, 90)][:10]
            lista.append({"nombre": nombre, "precio": round(precio, 2), "periodo": "anio" if p.get("periodo") == "anio" else "mes",
                          "documentos": _texto(p.get("documentos"), 60), "usuarios": _texto(p.get("usuarios"), 40), "destacado": bool(p.get("destacado")), "incluye": incluye})
        if not lista and tipo in ("facturacion", "comercio"):
            raise HTTPException(400, f"Debe haber al menos un plan de {tipo}")
        planes[tipo] = lista                                   # restaurante y servicios pueden quedar vacíos: la sección no se muestra (3.51)
    h = entrada.get("hospitalidad") or {}
    try:
        por_hab, minimo = float(h.get("por_habitacion") or 0), int(h.get("minimo") or 0)
    except (TypeError, ValueError):
        raise HTTPException(400, "Hotelería: el precio por habitación y el mínimo deben ser números")
    if not (0 < por_hab < 10_000_000) or not (0 <= minimo < 10_000):
        raise HTTPException(400, "Hotelería: precio por habitación o mínimo fuera de rango")
    try:
        extra_hab, p40, p50, cu = float(h.get("extra_habitacion") or 0), float(h.get("precio_40") or 0), float(h.get("precio_50") or 0), float(h.get("canales_usd") or 0)
    except (TypeError, ValueError):
        raise HTTPException(400, "Hotelería: los precios de extras, paquetes y canales deben ser números")
    if not all(0 <= x < 10_000_000 for x in (extra_hab, p40, p50, cu)):
        raise HTTPException(400, "Hotelería: precio fuera de rango")
    planes["hospitalidad"] = {"por_habitacion": round(por_hab, 2), "minimo": minimo, "extra_habitacion": round(extra_hab, 2), "precio_40": round(p40, 2), "precio_50": round(p50, 2),
                              "canales_usd": round(cu, 2), "destacado": True,
                              "incluye": [_texto(x, 90) for x in (h.get("incluye") or []) if _texto(x, 90)][:10], "canales": _texto(h.get("canales"), 160)}
    adicionales = [{"nombre": _texto(a.get("nombre"), 70), "precio": _texto(a.get("precio"), 50)}
                   for a in (data.get("adicionales") or [])[:12] if _texto(a.get("nombre"), 70)]
    sp = data.get("soporte") if isinstance(data.get("soporte"), dict) else {}
    slug_sp = _texto(sp.get("slug"), 60).lower().strip("/").replace("soporte/", "")
    if slug_sp and not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,59}", slug_sp):
        raise HTTPException(400, "La dirección del portal de soporte solo lleva letras minúsculas, números y guiones")
    wa_sp = re.sub(r"\D", "", str(sp.get("whatsapp") or ""))
    if wa_sp.startswith("506") and len(wa_sp) == 11:
        wa_sp = wa_sp[3:]
    if wa_sp and len(wa_sp) != 8:
        raise HTTPException(400, "El WhatsApp de soporte debe tener 8 dígitos (sin el 506)")
    pr = data.get("prueba") if isinstance(data.get("prueba"), dict) else {}
    try:
        dias = int(pr.get("dias") or 30)
    except (TypeError, ValueError):
        raise HTTPException(400, "Los días de la prueba gratis deben ser un número")
    if not (7 <= dias <= 90):
        raise HTTPException(400, "La prueba gratis dura entre 7 y 90 días")
    ts_sitio = _texto(pr.get("turnstile_sitio"), 100)
    if ts_sitio and not re.fullmatch(r"[0-9A-Za-z_-]{10,100}", ts_sitio):
        raise HTTPException(400, "La clave del sitio de Turnstile no tiene el formato esperado")
    ts_secreto = _texto(pr.get("turnstile_secreto"), 120)
    if ts_secreto:
        from . import secretos
        ts_cifrado = secretos._maestra.encrypt(ts_secreto.encode()).decode()
    else:
        ts_cifrado = (leer().get("prueba") or {}).get("turnstile_secreto") or "" if ts_sitio else ""   # vacía = se conserva la guardada
    prueba = {"automatica": bool(pr.get("automatica")), "dias": dias, "turnstile_sitio": ts_sitio, "turnstile_secreto": ts_cifrado,
              "turnstile_login": bool(pr.get("turnstile_login")) and bool(ts_sitio)}      # 3.84: sin clave del sitio no hay verificación que pedir
    return {"contacto": {"whatsapp": wa, "correos": correos, "correo_empresa_id": empresa_id}, "planes": planes,
            "adicionales": adicionales, "anual": _texto(data.get("anual"), 120), "soporte": {"slug": slug_sp, "whatsapp": wa_sp}, "prueba": prueba}


def publico(cfg: dict) -> dict:
    """Lo que ve el panel: nunca la clave secreta de Turnstile, solo si hay una guardada."""
    c = copy.deepcopy(cfg)
    p = c.setdefault("prueba", copy.deepcopy(DEFECTO["prueba"]))
    p["turnstile_configurado"] = bool(p.pop("turnstile_secreto", ""))
    return c


# ------------------------------------------------------------------------------------------------ Turnstile (3.68)
TURNSTILE_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify"


def turnstile_sitio(cfg: dict | None = None) -> str:
    return str(((cfg or leer()).get("prueba") or {}).get("turnstile_sitio") or "").strip()


def _turnstile_secreto(cfg: dict) -> str:
    v = (cfg.get("prueba") or {}).get("turnstile_secreto") or ""
    if not v:
        return os.getenv("FE_TURNSTILE_SECRETO", "").strip()
    try:
        from . import secretos
        return secretos._maestra.decrypt(v.encode()).decode()
    except Exception:  # noqa: BLE001  clave maestra distinta: se avisa y se deja pasar como si no hubiera verificación
        log.warning("No se pudo descifrar la clave secreta de Turnstile: vuelva a guardarla en Administración › Sitio web")
        return ""


def _consultar_cloudflare(secreto: str, token: str, ip: str) -> bool:
    import httpx
    r = httpx.post(TURNSTILE_URL, data={"secret": secreto, "response": token[:4096], "remoteip": ip or ""}, timeout=10)
    return bool(r.json().get("success"))


def verificar_turnstile(token: str | None, ip: str | None, cfg: dict) -> bool:
    """True si Cloudflare confirma que la persona pasó la verificación. Sin clave del sitio o sin secreta no se exige."""
    secreto = _turnstile_secreto(cfg)
    if not turnstile_sitio(cfg) or not secreto:
        return True
    if not token:
        return False
    try:
        return _consultar_cloudflare(secreto, token, ip or "")
    except Exception:  # noqa: BLE001
        log.warning("Turnstile no respondió; se rechaza el envío para no dejar pasar robots", exc_info=True)
        return False


# ------------------------------------------------------------------------------------------------ Turnstile al iniciar sesión (3.84)
_CF_RESPONDIO = [0.0]          # última vez que Cloudflare le contestó al servidor (un intento sin token no lo consulta cada vez)
_ERRORES_DE_CLAVES = {"missing-input-secret", "invalid-input-secret"}


def _siteverify(secreto: str, token: str, ip: str) -> dict:
    """Respuesta de Cloudflare a la verificación del token (lanza si Cloudflare no responde)."""
    import httpx
    r = httpx.post(TURNSTILE_URL, data={"secret": secreto, "response": token[:4096], "remoteip": ip or ""}, timeout=8)
    j = r.json()
    _CF_RESPONDIO[0] = time.time()
    return j if isinstance(j, dict) else {}


def login_apagado_por_variable() -> bool:
    """FE_TURNSTILE_LOGIN=0 en el servidor apaga la verificación del inicio de sesión sin entrar al panel (por si las claves
    dejan de servir y nadie puede entrar)."""
    return os.getenv("FE_TURNSTILE_LOGIN", "").strip().lower() in ("0", "no", "apagado", "false", "off")


def turnstile_login(cfg: dict | None = None) -> str:
    """Clave del sitio si el inicio de sesión y la recuperación de contraseña piden la verificación; vacía si no."""
    if login_apagado_por_variable():
        return ""
    cfg = cfg or leer()
    if not (cfg.get("prueba") or {}).get("turnstile_login"):
        return ""
    ts = turnstile_sitio(cfg)
    return ts if ts and _turnstile_secreto(cfg) else ""


def verificar_login(token: str | None, ip: str | None, accion: str) -> tuple[bool, str]:
    """(pasa, nota) para el inicio de sesión («login») y la recuperación de contraseña («recuperar»).
    nota: "" | "sin_token" | "no_paso" | "sin_respuesta" | "claves".
    A diferencia del formulario público, si Cloudflare no le responde AL SERVIDOR (caída, red) o dice que la clave secreta no
    sirve, se deja pasar y se anota: eso no lo puede provocar quien ataca, y una caída de Cloudflare no debe dejar a todos sin
    poder entrar. Los límites por conexión y por cuenta siguen igual. Sin token solo pasa si Cloudflare tampoco responde."""
    cfg = leer()
    if not turnstile_login(cfg):
        return True, ""
    secreto, token = _turnstile_secreto(cfg), (token or "").strip()
    try:
        if not token:
            if time.time() - _CF_RESPONDIO[0] > 120:
                _siteverify(secreto, "sin-token", ip or "")
            return False, "sin_token"
        r = _siteverify(secreto, token, ip or "")
    except Exception:  # noqa: BLE001
        log.warning("Turnstile no respondió al verificar un inicio de sesión; se deja pasar (siguen los límites de intentos)", exc_info=True)
        return True, "sin_respuesta"
    if r.get("success") and (not r.get("action") or r.get("action") == accion):
        return True, ""
    if _ERRORES_DE_CLAVES & set(r.get("error-codes") or []):
        log.warning("Cloudflare dice que la clave secreta de Turnstile no sirve: revísela en Administración › Sitio web")
        return True, "claves"
    return False, "no_paso"


def probar_claves(cfg: dict, token: str, ip: str | None) -> None:
    """Antes de activar la verificación del inicio de sesión (o de cambiarle las claves): el token de la prueba que se hizo en
    el panel tiene que pasar con ESTAS claves. Así nadie se queda sin poder entrar por una clave mal copiada."""
    secreto = _turnstile_secreto(cfg)
    if not turnstile_sitio(cfg) or not secreto:
        raise HTTPException(400, "Para pedir la verificación al iniciar sesión hacen falta la clave del sitio y la clave secreta de Turnstile")
    if not token:
        raise HTTPException(400, "Antes de activarla toque «Probar la verificación» y espere el visto bueno: así se confirma que las claves "
                                 "sirven en este dominio y nadie se queda sin poder entrar")
    try:
        r = _siteverify(secreto, token, ip or "")
    except Exception:  # noqa: BLE001
        raise HTTPException(400, "Cloudflare no respondió para comprobar las claves; intente de nuevo en un momento")
    if not r.get("success"):
        raise HTTPException(400, "La verificación de prueba no pasó con estas claves: revise que la clave secreta sea la del mismo widget "
                                 "y que este dominio esté en su lista en Cloudflare. Toque «Probar la verificación» otra vez")


def guardar(cfg: dict):
    tmp = ARCHIVO.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(ARCHIVO)


# ------------------------------------------------------------------------------------------------ página
def _colones(v: float) -> str:
    return "₡" + f"{v:,.0f}".replace(",", ".")


_META = re.compile(r"\A<!--(.*?)-->\s*", re.S)
_FAQ = re.compile(r"<details><summary>(.*?)</summary><p>(.*?)</p></details>", re.S)
_ETIQUETA = re.compile(r"<[^>]+>")
# 4.5: Google muestra unos 60 caracteres del <title> y unos 160 de la descripción (lo demás lo corta él, a media palabra). Se
# ajustan aquí, al armar la cabecera; el cuerpo de la página no cambia. El título suelta primero la marca repetida al final
# (« · FISITAAP by Brillante Agencia»: og:site_name ya la lleva) y, si aún sobra, corta en una palabra con «…»; la descripción
# cierra en la última frase completa que quepa o, si no la hay, en una palabra con «…».
TITULO_MAX, DESCRIPCION_MAX = 60, 160


def _cortar(texto: str, maximo: int) -> str:
    """Corta en el último espacio antes del máximo (el «…» final cuenta) sin dejar un signo suelto."""
    if len(texto) <= maximo:
        return texto
    corte = texto[:maximo - 1]
    if corte.rfind(" ") > maximo // 2:
        corte = corte[:corte.rfind(" ")]
    return corte.rstrip(" ·,;:.-") + "…"


def titulo_seo(titulo: str) -> str:
    t = " ".join((titulo or "").split())
    if len(t) <= TITULO_MAX:
        return t
    partes = [p.strip() for p in t.split(" · ") if p.strip()]
    ultimo = partes[-1].lower()
    if len(partes) > 1 and (ultimo == nombre_sistema().lower() or "fisitaap" in ultimo):
        t = " · ".join(partes[:-1])
    return _cortar(t, TITULO_MAX)


def descripcion_seo(descripcion: str) -> str:
    d = " ".join((descripcion or "").split())
    if len(d) <= DESCRIPCION_MAX:
        return d
    i = d[:DESCRIPCION_MAX + 1].rfind(". ")
    if i >= DESCRIPCION_MAX // 2:
        return d[:i + 1]
    return _cortar(d, DESCRIPCION_MAX)


def _pagina(nombre: str) -> tuple[dict, str]:
    """Contenido de app/sitio_web/<nombre>.html y sus datos del comentario inicial («clave: valor» por línea)."""
    t = (WEB / f"{nombre}.html").read_text(encoding="utf-8")
    meta = {}
    m = _META.match(t)
    if m:
        for linea in m.group(1).strip().splitlines():
            k, _, v = linea.partition(":")
            if k.strip():
                meta[k.strip()] = v.strip()
        t = t[m.end():]
    return meta, t


def base_url() -> str:
    from .config import URL_PUBLICA
    return URL_PUBLICA or "https://" + dominio_sistema()


def _jsonld(cfg: dict, meta: dict, ruta: str, contenido: str) -> str:
    raiz = base_url()
    wa = (cfg.get("contacto") or {}).get("whatsapp") or ""
    org = {"@type": "Organization", "@id": raiz + "/#organizacion", "name": nombre_sistema(), "url": raiz + "/",
           "logo": raiz + "/img/fisitaap-icono-512.png", "image": raiz + "/img/sitio/og-fisitaap-erp.jpg", "areaServed": "CR",
           "parentOrganization": ITCORESYNC}
    if wa:
        org["contactPoint"] = {"@type": "ContactPoint", "telephone": f"+506-{wa[:4]}-{wa[4:]}", "contactType": "sales",
                               "areaServed": "CR", "availableLanguage": "es"}
    grafo = [org]
    precios = [p["precio"] for k in ("facturacion", "comercio", "restaurante", "servicios") for p in (cfg["planes"].get(k) or []) if isinstance(p.get("precio"), (int, float))]
    if meta.get("software") == "si" and precios:
        grafo.append({"@type": "SoftwareApplication", "name": nombre_sistema(), "applicationCategory": "BusinessApplication",
                      "operatingSystem": "Web", "url": raiz + "/", "inLanguage": "es-CR", "publisher": {"@id": raiz + "/#organizacion"},
                      "provider": ITCORESYNC, "creator": BRILLANTE, "image": raiz + "/img/sitio/og-fisitaap-erp.jpg",
                      "offers": {"@type": "AggregateOffer", "priceCurrency": "CRC", "lowPrice": min(precios), "highPrice": max(precios),
                                 "offerCount": len(precios)}})
    preguntas = [{"@type": "Question", "name": _ETIQUETA.sub("", q).strip(),
                  "acceptedAnswer": {"@type": "Answer", "text": _ETIQUETA.sub("", r).strip()}} for q, r in _FAQ.findall(contenido)]
    if preguntas:
        grafo.append({"@type": "FAQPage", "mainEntity": preguntas})
    if meta.get("articulo") == "si":
        art = {"@type": "Article", "headline": _ETIQUETA.sub("", (re.search(r"<h1[^>]*>(.*?)</h1>", contenido, re.S) or [None, meta.get("titulo") or ""])[1]).strip(),
               "description": meta.get("descripcion") or "", "inLanguage": "es-CR", "url": raiz + ruta,
               "mainEntityOfPage": raiz + ruta, "image": raiz + (meta.get("imagen") or "/img/sitio/og-fisitaap-erp.jpg"),
               "author": {"@id": raiz + "/#organizacion"}, "publisher": {"@id": raiz + "/#organizacion"}}
        if meta.get("fecha"):
            art["datePublished"] = art["dateModified"] = meta["fecha"]
        grafo.append(art)
    if ruta != "/":
        migas = [{"@type": "ListItem", "position": 1, "name": "Inicio", "item": raiz + "/"}]
        if meta.get("padre") and PADRES.get(meta["padre"]):   # 3.87: una miga intermedia sin página propia no va (Google la marca como error)
            migas.append({"@type": "ListItem", "position": 2, "name": meta["padre"], "item": raiz + PADRES[meta["padre"]]})
        # 4.5: la última miga toma el título si la página no trae «miga:»; una miga sin nombre o sin dirección no va (Google la marca como error)
        migas.append({"@type": "ListItem", "position": len(migas) + 1, "name": meta.get("miga") or titulo_seo(meta.get("titulo") or "").split(" · ")[0] or nombre_sistema(), "item": raiz + ruta})
        migas = [m for m in migas if m.get("name") and m.get("item")]
        for i, m in enumerate(migas, 1):
            m["position"] = i
        grafo.append({"@type": "BreadcrumbList", "itemListElement": migas})
    datos = json.dumps({"@context": "https://schema.org", "@graph": grafo}, ensure_ascii=False).replace("</", "<\\/")
    return f'<script type="application/ld+json">{datos}</script>'


def _formulario(cfg: dict, con_seccion: bool) -> str:
    e = escape
    # 3.87: también los planes de restaurante y de servicios (sus tarjetas llevan a /prueba-gratis?plan=… y el plan quedaba en blanco)
    nombres_planes = list(dict.fromkeys(p["nombre"] for k in ("facturacion", "comercio", "restaurante", "servicios") for p in (cfg["planes"].get(k) or []))) + ["Hotelería", "Hotelería con canales"]
    opciones = "".join(f'<option>{e(n)}</option>' for n in nombres_planes)
    auto = bool((cfg.get("prueba") or {}).get("automatica"))
    ts = turnstile_sitio(cfg)
    widget = f'<div class="cf-turnstile" data-sitekey="{e(ts)}" data-language="es" data-theme="light"></div>' if ts else ""
    if auto:   # 3.68: la cuenta se crea sola, así que se piden los datos de la empresa (y los robots no los llenan bien)
        tipos = "".join(f'<option value="{k}">{e(v)}</option>' for k, v in TIPOS_PUBLICO)
        form = ('<form class="formulario" id="formulario" novalidate data-auto="1">'
                '<div class="dos-campos"><label>Su nombre<input name="nombre" required maxlength="80" autocomplete="name"></label>'
                '<label>Empresa o nombre comercial<input name="empresa" required maxlength="100" autocomplete="organization"></label></div>'
                '<div class="dos-campos"><label>Cédula física o jurídica<input name="cedula" required maxlength="12" inputmode="numeric" placeholder="Solo números"></label>'
                '<label>Teléfono o WhatsApp<input name="telefono" required maxlength="30" autocomplete="tel" inputmode="tel" placeholder="8 dígitos"></label></div>'
                '<div class="dos-campos"><label>Correo<input name="correo" type="email" required maxlength="120" autocomplete="email"></label>'
                f'<label>Tipo de negocio<select name="tipo" required><option value="">Elija…</option>{tipos}</select></label></div>'
                f'<label>¿Qué le interesa?<select name="plan"><option>Prueba gratis de 1 mes</option><option value="">Solo información</option>{opciones}</select></label>'
                '<label>¿A qué se dedica su empresa?<textarea name="mensaje" rows="3" required minlength="15" maxlength="1500" placeholder="Por ejemplo: ferretería en Cartago con dos cajas; facturamos a crédito a empresas"></textarea></label>'
                '<label class="casilla"><input type="checkbox" name="novedades" value="1"> Quiero recibir novedades y promociones por correo (puede darse de baja cuando quiera)</label>'
                '<label class="trampa" aria-hidden="true">Sitio web<input name="web" tabindex="-1" autocomplete="off"></label>'
                f'{widget}<button class="btn grande" type="submit">Crear mi prueba gratis</button>'
                '<p class="estado" id="estado" role="status"></p>'
                f'<p class="nota">Su acceso llega al correo en un minuto. Usamos sus datos solo para crear su cuenta en {escape(nombre_sistema())} y contactarle. <a href="/terminos.html">Privacidad</a>.</p></form>')
    else:
        form = ('<form class="formulario" id="formulario" novalidate>'
                '<div class="dos-campos"><label>Nombre<input name="nombre" required maxlength="80" autocomplete="name"></label>'
                '<label>Empresa<input name="empresa" maxlength="100" autocomplete="organization"></label></div>'
                '<div class="dos-campos"><label>Correo<input name="correo" type="email" required maxlength="120" autocomplete="email"></label>'
                '<label>Teléfono o WhatsApp<input name="telefono" maxlength="30" autocomplete="tel" inputmode="tel"></label></div>'
                f'<label>¿Qué le interesa?<select name="plan"><option>Prueba gratis de 1 mes</option><option value="">Solo información</option>{opciones}</select></label>'
                '<label>Mensaje<textarea name="mensaje" rows="3" maxlength="1500" placeholder="¿A qué se dedica su empresa y qué necesita?"></textarea></label>'
                '<label class="casilla"><input type="checkbox" name="novedades" value="1"> Quiero recibir novedades y promociones por correo (puede darse de baja cuando quiera)</label>'
                '<label class="trampa" aria-hidden="true">Sitio web<input name="web" tabindex="-1" autocomplete="off"></label>'
                f'{widget}<button class="btn grande" type="submit">Quiero mi prueba gratis</button>'
                '<p class="estado" id="estado" role="status"></p>'
                f'<p class="nota">Usamos sus datos solo para contactarle sobre {escape(nombre_sistema())}. <a href="/terminos.html">Privacidad</a>.</p></form>')
    if not con_seccion:
        return form
    return ('<section id="contacto" class="seccion"><div class="contenedor dos"><div><h2>Hablemos</h2>'
            '<p class="sub izq">Cuéntenos de su negocio y le mostramos el sistema. Sin compromiso.</p>'
            '<!--WA--><a class="btn grande wa" href="{{WHATSAPP_URL}}" target="_blank" rel="noopener">WhatsApp {{WHATSAPP}}</a><!--/WA-->'
            f'<div class="correos">{{{{CORREOS}}}}</div></div>{form}</div></section>')


def render(ruta: str = "/", pagina: Optional[str] = None) -> str:
    from .config import AVISO_ENTORNO
    cfg = leer()
    e = escape
    meta, contenido = _pagina(pagina or PAGINAS[ruta])
    def tarjeta(p, periodo_txt):
        items = "".join(f"<li>{e(x)}</li>" for x in p["incluye"])
        return (f'<article class="plan{" destacado" if p.get("destacado") else ""}">'
                + ('<span class="cinta">Más elegido</span>' if p.get("destacado") else "")
                + f'<h3>{e(p["nombre"])}</h3><div class="precio">{e(_colones(p["precio"]))}<small> {periodo_txt}</small></div>'
                f'<p class="cupo">{e(p["documentos"])} · {e(p["usuarios"])}</p><ul>{items}</ul>'
                f'<a class="btn {"" if p.get("destacado") else "sec"}" href="/prueba-gratis?plan={quote(p["nombre"])}" data-plan="{e(p["nombre"])}">Probar gratis</a></article>')
    pl = cfg["planes"]
    fac = [tarjeta(p, "/mes + IVA" if p.get("periodo") != "anio" else "/año + IVA") for p in pl["facturacion"]]
    com = [tarjeta(p, "/mes + IVA") for p in pl["comercio"]]
    rest = [tarjeta(p, "/mes + IVA") for p in (pl.get("restaurante") or [])]
    serv = [tarjeta(p, "/mes + IVA" if p.get("periodo") != "anio" else "/año + IVA") for p in (pl.get("servicios") or [])]
    h = pl["hospitalidad"]
    items_h = "".join(f"<li>{e(x)}</li>" for x in h.get("incluye") or [])
    ph, xh = float(h["por_habitacion"]), float(h.get("extra_habitacion") or 0)
    filas = "".join(f"<tr><td>Hasta {n} habitaciones</td><td>{e(_colones(ph * n))}</td><td>{e(_colones(xh * n))} cada uno</td><td>{e(_colones(ph * n + xh * n * 4))}</td></tr>" for n in (6, 10, 15, 20, 30))
    filas += (f"<tr><td>Hasta 40 habitaciones</td><td>{e(_colones(h.get('precio_40') or 0))}</td><td>Incluidos</td><td>{e(_colones(h.get('precio_40') or 0))}</td></tr>"
              f"<tr><td>Hasta 50 habitaciones</td><td>{e(_colones(h.get('precio_50') or 0))}</td><td>Incluidos</td><td>{e(_colones(h.get('precio_50') or 0))}</td></tr>"
              f"<tr><td>Más de 50 habitaciones</td><td colspan=\"3\">Cotización</td></tr>")
    hotel = (f'<article class="plan destacado"><span class="cinta">Por habitación</span><h3>Hotelería</h3>'
             f'<div class="precio">{e(_colones(ph))}<small> por habitación /mes + IVA</small></div>'
             f'<p class="cupo">Mínimo {h["minimo"]} habitaciones · cada extra {e(_colones(xh))} por habitación · desde 40 habitaciones todo incluido</p><ul>{items_h}</ul>'
             f'<a class="btn" href="/prueba-gratis?plan=Hoteler%C3%ADa" data-plan="Hotelería">Probar gratis</a></article>'
             f'<article class="plan"><h3>Paquetes y extras del hotel</h3>'
             f'<table class="tabla-planes"><thead><tr><th>Paquete</th><th>Base al mes</th><th>Cada extra</th><th>Con los 4 extras</th></tr></thead><tbody>{filas}</tbody></table>'
             f'<p class="cupo">Extras: Punto de venta · Hotel completo (servicios, eventos, lavandería y seguridad) · Contabilidad · Recursos humanos</p>'
             f'<p class="cupo">{e(h.get("canales") or "")}</p>'
             f'<a class="btn sec" href="/prueba-gratis?plan=Hoteler%C3%ADa%20con%20canales" data-plan="Hotelería con canales">Solicitar cotización</a></article>')
    adicionales = "".join(f'<li><span>{e(a["nombre"])}</span><b>{e(a["precio"])}</b></li>' for a in cfg["adicionales"])
    bloque_planes = (f'<h2 id="facturacion">Facturación electrónica</h2><p class="sub">Elija por la cantidad de documentos que emite. Sin límite de usuarios.</p><div class="grid-planes">{"".join(fac)}</div>'
                     f'<h2 id="punto-de-venta">Punto de venta</h2><p class="sub">Comercios y tiendas: documentos ilimitados, pago mensual.</p><div class="grid-planes">{"".join(com)}</div>'
                     + (f'<h2 id="restaurante">Restaurante · FISITAAP</h2><p class="sub">Punto de venta con mesas y monitor de preparación, más el catálogo en línea con pedidos a la caja. Entregas con motorizados se agregan como extra.</p><div class="grid-planes">{"".join(rest)}</div>' if rest else "")
                     + (f'<h2 id="servicios">Servicios e IT · TiKe</h2><p class="sub">Para empresas que atienden solicitudes de soporte: facturación electrónica más TiKe, el módulo de tickets, contratos y documentación del cliente.</p><div class="grid-planes">{"".join(serv)}</div>' if serv else "")
                     +
                     f'<h2 id="hoteleria">Hotelería</h2><p class="sub">Se paga por habitación. Punto de venta, contabilidad y planilla se agregan como extras.</p><div class="grid-planes">{hotel}</div>'
                     f'<div class="adicionales"><h3>Extras y adicionales</h3><ul>{adicionales}</ul>'
                     '<p class="nota">Los precios pueden ajustarse al vencimiento de cada período, con aviso previo, según los '
                     '<a href="/terminos.html">términos del servicio</a>.</p></div>')
    cta = ('<section class="cta"><div class="contenedor fila-cta"><div><h2>Pruébelo gratis durante 1 mes</h2>'
           '<p>Sin tarjeta. Le ayudamos a configurar su empresa y su llave de Hacienda.</p></div>'
           '<div class="acciones"><a class="btn grande" href="/prueba-gratis">Quiero mi prueba gratis</a>'
           '<!--WA--><a class="btn grande sec" href="{{WHATSAPP_URL}}" target="_blank" rel="noopener">WhatsApp</a><!--/WA--></div></div></section>')
    c = cfg["contacto"]
    wa = c.get("whatsapp") or ""
    wa_url = (f"https://wa.me/506{wa}?text=" + quote("Hola, quiero información sobre " + nombre_sistema())) if wa else ""
    wa_txt = f"{wa[:4]} {wa[4:]}" if len(wa) == 8 else wa
    correos = "".join(f'<a href="mailto:{e(x)}">{e(x)}</a>' for x in c.get("correos") or [])
    raiz = base_url()
    imagen = meta.get("imagen") or "/img/sitio/og-fisitaap-erp.jpg"
    migas = ""
    if ruta != "/":
        padre_url = PADRES.get(meta.get("padre") or "")
        medio = ((f'<a href="{e(padre_url)}">{e(meta["padre"])}</a> › ' if padre_url else f'<span>{e(meta["padre"])}</span> › ')
                 if meta.get("padre") else "")
        migas = f'<nav class="migas contenedor" aria-label="Ruta"><a href="/">Inicio</a> › {medio}<span>{e(meta.get("miga") or "")}</span></nav>'
    html = (WEB / "base.html").read_text(encoding="utf-8").replace("{{CONTENIDO}}", contenido)
    reemplazos = {
        "{{TITULO}}": e(titulo_seo(meta.get("titulo") or nombre_sistema())), "{{DESCRIPCION}}": e(descripcion_seo(meta.get("descripcion") or "")),   # 4.5: ≤ 60 y ≤ 160
        "{{CANONICA}}": e(raiz + ruta), "{{OG_IMAGEN}}": e(raiz + imagen), "{{ROBOTS}}": "noindex" if AVISO_ENTORNO else "index, follow",
        "{{JSONLD}}": _jsonld(cfg, meta, ruta, contenido), "{{MIGAS}}": migas,
        "{{SCRIPTS}}": (f'<script src="{e(meta["script"])}"></script>' if meta.get("script") else "")
                       + ('<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>' if turnstile_sitio(cfg) else ""),
        "{{FORMULARIO_SOLO}}": _formulario(cfg, False), "{{FORMULARIO}}": _formulario(cfg, True), "{{CTA}}": cta,
        "{{PLANES_BLOQUE}}": bloque_planes,
        "{{AVISO}}": f'<div class="aviso-entorno">{e(AVISO_ENTORNO)}</div>' if AVISO_ENTORNO else "",
        "{{ANUAL}}": e(cfg.get("anual") or ""), "{{WHATSAPP_URL}}": e(wa_url), "{{WHATSAPP}}": e(wa_txt), "{{CORREOS}}": correos,
        "{{ANIO}}": str(datetime.now().year), "{{DOMINIO}}": e(dominio_sistema()),   # 3.77: dominio del sistema en la página pública
    }
    for k, v in reemplazos.items():
        html = html.replace(k, v)
    if not wa:
        html = re.sub(r"<!--WA-->.*?<!--/WA-->", "", html, flags=re.S)
    # 3.68: textos según el modo de la prueba (los bloques <!--AUTO--> y <!--MANUAL--> de las páginas)
    quitar = "MANUAL" if (cfg.get("prueba") or {}).get("automatica") else "AUTO"
    html = re.sub(rf"<!--{quitar}-->.*?<!--/{quitar}-->", "", html, flags=re.S)
    html = html.replace("<!--AUTO-->", "").replace("<!--/AUTO-->", "").replace("<!--MANUAL-->", "").replace("<!--/MANUAL-->", "")
    return html


# 3.87: «no encontrada» sin la marca ni la venta del sistema, para lo que ven los clientes de un negocio (su dominio o subdominio, la
# página /t/<negocio> y los enlaces /p/ de los comprobantes): solo el mensaje y, en el dominio del negocio, el enlace a su inicio
_HTML_404_NEUTRA = """<!doctype html><html lang="es-CR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Página no encontrada</title><meta name="robots" content="noindex"><link rel="icon" href="data:,">
<style>body{{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f3f4f6;margin:0;color:#1d2433}}.c{{max-width:520px;margin:48px 16px;background:#fff;border-radius:12px;
padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06);text-align:center}}@media (min-width:560px){{.c{{margin:48px auto}}}}h1{{font-size:21px;margin:0 0 10px}}p{{color:#4b5563;line-height:1.5}}
.b{{display:inline-block;margin-top:10px;padding:10px 18px;border-radius:8px;background:#1f4965;color:#fff;text-decoration:none;font-weight:600}}</style></head>
<body><main class="c"><h1>No encontramos esta página</h1><p>{mensaje}</p>{inicio}</main></body></html>"""


def render_404(mensaje: str = "", neutra: bool = False, con_inicio: bool = False) -> str:
    """3.87: página «no encontrada» del sitio (app/sitio_web/404.html) con la cabecera, el pie y las páginas principales, para quien
    navega a una dirección que no existe (antes veía {"detail":"Not Found"}). Sin canónica, og:url, datos para buscadores ni
    Turnstile, y fuera de los buscadores. neutra=True: la variante sin la marca del sistema (ver _HTML_404_NEUTRA)."""
    if neutra:
        return _HTML_404_NEUTRA.format(mensaje=escape(mensaje or "La dirección que abrió no existe o cambió."),
                                       inicio='<a class="b" href="/">Ir al inicio</a>' if con_inicio else "")
    html = render("/", pagina="404")
    html = html.replace("{{MENSAJE}}", escape(mensaje or "La dirección que abrió no existe o cambió. Estas son las páginas principales del sitio."))
    html = re.sub(r'<link rel="canonical"[^>]*>\n?', "", html)
    html = re.sub(r'<meta property="og:url"[^>]*>\n?', "", html)                       # 3.87: no es la página de inicio
    html = re.sub(r'<script type="application/ld\+json">.*?</script>\n?', "", html, flags=re.S)
    html = re.sub(r'<meta name="robots" content="[^"]*">', '<meta name="robots" content="noindex">', html)
    return html.replace('<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>', "")


def robots() -> str:
    return f"User-agent: *\nAllow: /\nDisallow: /app/\nDisallow: /api/\nDisallow: /p/\n\nSitemap: {base_url()}/sitemap.xml\n"


def sitemap() -> str:
    def fecha(nombre: str) -> str:
        try:
            return datetime.fromtimestamp((WEB / f"{nombre}.html").stat().st_mtime).date().isoformat()
        except OSError:
            return datetime.now().date().isoformat()
    urls = "".join(f"<url><loc>{escape(base_url() + r)}</loc><lastmod>{fecha(n)}</lastmod></url>" for r, n in PAGINAS.items())
    return f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>\n'


# ------------------------------------------------------------------------------------------------ avisos por correo
def _smtp(s: Session, cfg: dict):
    import os
    from . import correo as _correo
    host = (os.getenv("FE_SMTP_HOST") or "").strip()
    if host:
        seg = (os.getenv("FE_SMTP_SEGURIDAD") or "ssl").strip().lower()
        try:
            puerto = int(os.getenv("FE_SMTP_PUERTO") or (465 if seg == "ssl" else 587))
        except ValueError:
            puerto = 465
        return _correo.ConfigSMTP(host, puerto, os.getenv("FE_SMTP_USUARIO") or None, os.getenv("FE_SMTP_PASSWORD") or None,
                                  (os.getenv("FE_SMTP_REMITENTE") or os.getenv("FE_SMTP_USUARIO") or "").strip(), seguridad=seg, nombre=nombre_sistema())
    eid = (cfg.get("contacto") or {}).get("correo_empresa_id")
    if not eid:
        return None
    from .db import Empresa
    from .main import _cfg_smtp
    e = s.get(Empresa, eid)
    if not e or not (e.smtp_host and e.smtp_remitente):
        return None
    return _cfg_smtp(e)


def _avisar(sid: int):
    from . import correo as _correo
    try:
        with Session(engine) as s:
            sol = s.get(SolicitudContacto, sid)
            cfg = leer()
            destinos = (cfg.get("contacto") or {}).get("correos") or []
            smtp = _smtp(s, cfg) if destinos else None
            if not (sol and smtp):
                return
            tipo = dict(TIPOS_PUBLICO).get(sol.tipo_negocio or "", sol.tipo_negocio)
            filas = [("Nombre", sol.nombre), ("Empresa", sol.empresa), ("Cédula", sol.cedula), ("Correo", sol.correo), ("Teléfono", sol.telefono),
                     ("Tipo de negocio", tipo), ("Plan de interés", sol.plan), ("Mensaje", sol.mensaje), ("Origen de la visita", sol.origen), ("Página", sol.pagina),
                     ("Prueba gratis", sol.resultado)]
            titulo = ("Prueba creada sola" if sol.empresa_id else "Nueva solicitud") + " desde " + (base_url().replace("https://", "").replace("http://", "") or "el sitio")
            texto = titulo + "\n\n" + "\n".join(f"{k}: {v or '—'}" for k, v in filas)
            from . import correo_diseno as _dz                            # 3.83: diseño común
            html = _dz.armar(_dz.plataforma(), titulo=titulo, antetitulo="Sitio público", preencabezado=f"{sol.nombre} · {sol.correo or sol.telefono or ''}",
                             datos=[(k, v) for k, v in filas if k != "Mensaje"], cita=sol.mensaje or "", cita_autor="Mensaje" if sol.mensaje else "",
                             nota="Atiéndala en Panel de administración › Solicitudes de contacto.")
            asunto = (f"Prueba creada sola: {sol.nombre}" if sol.empresa_id else f"Solicitud de {sol.nombre} ({sol.plan or 'sin plan'})") + f" · {nombre_sistema()}"
            _correo.enviar(smtp, destinos, asunto, html, texto, [])
            sol.notificada = True; s.add(sol); s.commit()
    except Exception:  # noqa: BLE001  la solicitud ya quedó guardada; el aviso es un extra
        log.exception("No se pudo avisar la solicitud de contacto %s", sid)


# ------------------------------------------------------------------------------------------------ rutas
router = APIRouter()


def _ruta_pagina(ruta: str):
    def ver():
        r = HTMLResponse(render(ruta))
        if turnstile_sitio():
            r.headers["X-Pagina-Turnstile"] = "1"       # la política de seguridad deja cargar el widget de Cloudflare (3.68)
        return r
    ver.__name__ = "pagina_" + (ruta.strip("/").replace("/", "_").replace("-", "_") or "inicio")
    router.add_api_route(ruta, ver, methods=["GET", "HEAD"], response_class=HTMLResponse, include_in_schema=False)


for _r in PAGINAS:
    _ruta_pagina(_r)


@router.api_route("/robots.txt", methods=["GET", "HEAD"], response_class=PlainTextResponse, include_in_schema=False)
def ver_robots():
    from .config import AVISO_ENTORNO
    if AVISO_ENTORNO:                      # labs u otro ambiente de pruebas: que los buscadores no lo indexen
        return PlainTextResponse("User-agent: *\nDisallow: /\n")
    return PlainTextResponse(robots())


@router.api_route("/sitemap.xml", methods=["GET", "HEAD"], include_in_schema=False)
def ver_sitemap():
    return Response(sitemap(), media_type="application/xml")


class ContactoIn(BaseModel):
    nombre: str = Field(min_length=2, max_length=80)
    empresa: Optional[str] = Field(None, max_length=100)
    correo: str = Field(min_length=5, max_length=120)
    telefono: Optional[str] = Field(None, max_length=30)
    plan: Optional[str] = Field(None, max_length=40)
    mensaje: Optional[str] = Field(None, max_length=1500)
    origen: Optional[str] = Field(None, max_length=200)
    pagina: Optional[str] = Field(None, max_length=200)
    novedades: Optional[bool] = None      # casilla «Quiero recibir novedades y promociones» (3.39)
    web: Optional[str] = None             # trampa para robots: un humano no la ve ni la llena
    segundos: Optional[float] = None      # tiempo desde que se abrió la página (un robot envía al instante)
    cedula: Optional[str] = Field(None, max_length=20)      # 3.68 (modo automático)
    tipo: Optional[str] = Field(None, max_length=20)        # 3.68: código de auth.TIPOS_NEGOCIO
    turnstile: Optional[str] = Field(None, max_length=4096) # 3.68: respuesta del widget de Cloudflare


def _exigir_datos_prueba(data: "ContactoIn") -> dict:
    """En modo automático la cuenta se crea sola: se exigen los datos de la empresa (y un robot rara vez los trae bien)."""
    from .auth import TIPOS_NEGOCIO
    if len(_texto(data.empresa, 100)) < 3:
        raise HTTPException(400, "Escriba el nombre de su empresa o nombre comercial")
    ced = re.sub(r"\D", "", data.cedula or "")
    if not (9 <= len(ced) <= 12):
        raise HTTPException(400, "Escriba su cédula física (9 dígitos) o jurídica (10 dígitos), solo números")
    tel = re.sub(r"\D", "", data.telefono or "")
    if tel.startswith("506") and len(tel) == 11:
        tel = tel[3:]
    if len(tel) != 8:
        raise HTTPException(400, "Escriba un teléfono o WhatsApp de 8 dígitos")
    tipo = (data.tipo or "").strip()
    if tipo not in TIPOS_NEGOCIO:
        raise HTTPException(400, "Elija el tipo de negocio")
    if len(_texto(data.mensaje, 1500)) < 15:
        raise HTTPException(400, "Cuéntenos en una línea a qué se dedica su empresa")
    return {"cedula": ced, "telefono": tel, "tipo": tipo}


def _prueba_automatica(s: Session, sol: SolicitudContacto, request: Request, cfg: dict) -> dict | None:
    """Crea el usuario y la empresa de prueba y manda la bienvenida. Si algo lo impide, deja la solicitud con el motivo para
    atenderla a mano (nunca se crea una segunda cuenta para el mismo correo ni una empresa repetida por cédula)."""
    from . import auth, demo
    from .db import Empresa

    def dejar(motivo: str):
        sol.resultado = motivo; s.add(sol); s.commit()
        return None
    try:
        auth.limitar_ip(request, "prueba_auto", 3, 86400, "Varias pruebas desde la misma conexión")
    except HTTPException:
        return dejar("Varias pruebas en un día desde la misma conexión: revisar y crearla a mano")
    if not _smtp(s, cfg):
        return dejar("No se creó sola: falta el correo para enviar el acceso (Sitio web › correo de avisos)")
    if s.exec(select(auth.Usuario).where(auth.Usuario.correo == sol.correo)).first():
        return dejar("Ese correo ya tiene cuenta en el sistema: atender a mano")
    if sol.cedula and s.exec(select(Empresa).where(Empresa.numero_id == sol.cedula)).first():
        return dejar("Ya existe una empresa con esa cédula: atender a mano")
    try:
        info = demo.crear_prueba(s, sol.correo, sol.nombre, sol.empresa or sol.nombre, sol.cedula or "", int(cfg["prueba"].get("dias") or 30),
                                 tipo_negocio=sol.tipo_negocio or "facturacion")
    except HTTPException as ex:
        return dejar(f"No se pudo crear la prueba: {ex.detail}")
    enviado = demo._bienvenida(info, sol.nombre)
    sol.empresa_id = info["empresa_id"]; sol.atendida = bool(enviado)
    sol.resultado = "Prueba creada automáticamente" + ("" if enviado else "; el correo de bienvenida NO salió: restablezca la contraseña y envíe el acceso a mano")
    s.add(sol); s.commit()
    auth.auditar(s, "prueba_creada", f"Automática desde el sitio: {sol.correo}: empresa {info['empresa_id']} hasta {info['vence']}", None, info["empresa_id"], request, correo=sol.correo)
    info["correo_enviado"] = bool(enviado)
    return info


@router.post("/api/contacto")
def contacto(data: ContactoIn, request: Request, s: Session = Depends(get_session)):
    from . import auth
    auth.limitar_ip(request, "contacto", 5, 3600, "Ya recibimos varias solicitudes desde su conexión; le contactaremos pronto")
    if (data.web or "").strip() or (data.segundos is not None and data.segundos < 3):
        return {"ok": True}                # robot: se responde igual para no darle pistas, pero no se guarda
    correo = data.correo.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", correo):
        raise HTTPException(400, "Revise el correo electrónico")
    cfg = leer()
    if not verificar_turnstile(data.turnstile, auth._ip(request), cfg):
        raise HTTPException(400, "No pudimos confirmar que no es un robot. Recargue la página e intente de nuevo.")
    auto = bool((cfg.get("prueba") or {}).get("automatica")) and bool(_texto(data.plan, 40)) and not auth._es_local()     # «Solo información» no crea cuenta; 4.25: en el programa nunca
    extra = _exigir_datos_prueba(data) if auto else {"cedula": re.sub(r"\D", "", data.cedula or "")[:12] or None, "telefono": _texto(data.telefono, 30) or None,
                                                      "tipo": (data.tipo or "").strip()[:20] or None}
    sol = SolicitudContacto(nombre=_texto(data.nombre, 80), empresa=_texto(data.empresa, 100) or None, correo=correo,
                            telefono=extra["telefono"] or None, plan=_texto(data.plan, 40) or None,
                            mensaje=(data.mensaje or "").strip()[:1500] or None, ip=(auth._ip(request) or "")[:60],
                            origen=_texto(data.origen, 120) or None, pagina=_texto(data.pagina, 80) or None, acepta_novedades=bool(data.novedades),
                            cedula=extra["cedula"] or None, tipo_negocio=extra["tipo"] or None)
    s.add(sol); s.commit(); s.refresh(sol)
    if sol.acepta_novedades:
        from . import publicidad
        publicidad.desde_sitio(correo, sol.nombre, sol.empresa)
    info = _prueba_automatica(s, sol, request, cfg) if auto else None
    threading.Thread(target=_avisar, args=(sol.id,), daemon=True).start()
    return {"ok": True, "prueba": bool(info), "correo_enviado": bool(info and info.get("correo_enviado"))}


@router.get("/api/admin/sitio")
def ver_sitio(a=Depends(superadmin)):
    return publico(leer())


@router.put("/api/admin/sitio")
def editar_sitio(data: dict, request: Request, s: Session = Depends(get_session), a=Depends(superadmin)):
    antes = leer().get("prueba") or {}
    cfg = validar(data)
    p = cfg["prueba"]
    if p["turnstile_login"] and (not antes.get("turnstile_login") or p["turnstile_sitio"] != antes.get("turnstile_sitio")
                                 or p["turnstile_secreto"] != antes.get("turnstile_secreto")):
        from .auth import _ip                        # 3.84: activarla o cambiarle las claves exige una prueba que pase
        pr = data.get("prueba") if isinstance(data.get("prueba"), dict) else {}
        probar_claves(cfg, str(pr.get("turnstile_prueba") or "")[:4096], _ip(request))
    guardar(cfg)
    from .auth import auditar
    auditar(s, "sitio_editado", f"Planes: {', '.join(p['nombre'] for p in cfg['planes']['facturacion'] + cfg['planes']['comercio'])}; hotel ₡{cfg['planes']['hospitalidad']['por_habitacion']}/habitación"
            + ("; prueba gratis automática" if cfg["prueba"]["automatica"] else "") + ("; Turnstile" if cfg["prueba"]["turnstile_sitio"] else "")
            + ("; verificación al iniciar sesión" if cfg["prueba"]["turnstile_login"] else ""), a)
    s.commit()
    return publico(cfg)


@router.get("/api/admin/contactos")
def ver_contactos(s: Session = Depends(get_session), a=Depends(superadmin)):
    return s.exec(select(SolicitudContacto).order_by(SolicitudContacto.id.desc()).limit(300)).all()


class AtendidaIn(BaseModel):
    atendida: bool


@router.put("/api/admin/contactos/{cid}")
def marcar_contacto(cid: int, data: AtendidaIn, s: Session = Depends(get_session), a=Depends(superadmin)):
    sol = s.get(SolicitudContacto, cid)
    if not sol:
        raise HTTPException(404, "Solicitud no encontrada")
    sol.atendida = data.atendida; s.add(sol); s.commit()
    return {"ok": True}
