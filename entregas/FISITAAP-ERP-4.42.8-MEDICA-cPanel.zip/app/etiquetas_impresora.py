# -*- coding: utf-8 -*-
"""4.24 · Etiquetas de productos: lo que comparten el servidor (el PDF y las rutas de app/etiquetas.py) y el servicio de impresión
local (app/escpos.py, dentro del agente suelto y del programa de escritorio): las medidas y los modelos de impresora predefinidos,
los topes, el código de barras propio (EAN-13 de uso interno) y los armadores del trabajo en el lenguaje de la impresora de
etiquetas (TSPL y ZPL).

Solo funciones puras y la biblioteca estándar: no depende de nada más del sistema. La misma lista de medidas, formatos y modelos
está en la pantalla (app/static/js/pages/inventario/_etiquetas.js); tests/test_424_etiquetas.py comprueba que sean iguales."""
import unicodedata

# ---------------------------------------------------------------------------------------------- medidas, formatos y topes
MEDIDAS = ((30, 20), (40, 25), (40, 30), (50, 25), (50, 30), (58, 40), (60, 40), (76, 51), (100, 50), (100, 150))   # ancho × alto, mm
ANCHO_MIN, ANCHO_MAX = 20, 110          # medida «Personalizada»
ALTO_MIN, ALTO_MAX = 15, 160
COPIAS_MAX = 500                        # de un mismo producto
ETIQUETAS_MAX = 3000                    # de un mismo pedido
FORMATOS = ("nombre_codigo", "nombre_codigo_precio", "solo_codigo")
LENGUAJES = ("tspl", "zpl", "pdf")      # pdf = «Controlador de Windows»: no pasa por los armadores, se imprime el PDF
SEPARACION_MM = 2                       # entre etiquetas, por omisión
ALTERNOS_MAX = 5                        # códigos alternos que guarda un producto
CODIGO_MAX = 20                         # largo del código de un producto (va en CodigoComercial de la factura)

# Modelos predefinidos de impresora de etiquetas. `densidad` es la de fábrica (None = la que tenga puesta la impresora);
# `ancho_max_mm` es solo para avisar en la pantalla.
MODELOS = (
    {"id": "3nstar-ldt124", "nombre": "3nStar LDT124", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 104, "densidad": 8},
    {"id": "3nstar-ldt114", "nombre": "3nStar LDT114", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 104, "densidad": 8},
    {"id": "tsc-te200", "nombre": "TSC TE200", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "tsc-ttp244pro", "nombre": "TSC TTP-244 Pro", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "tsc-da210", "nombre": "TSC DA210", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "xprinter-xp365b", "nombre": "Xprinter XP-365B", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "xprinter-xp420b", "nombre": "Xprinter XP-420B", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "gprinter-gp1324d", "nombre": "Gprinter GP-1324D", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "zebra-zd220", "nombre": "Zebra ZD220", "lenguaje": "zpl", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
    {"id": "zebra-zd230", "nombre": "Zebra ZD230", "lenguaje": "zpl", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
    {"id": "zebra-zd420", "nombre": "Zebra ZD420", "lenguaje": "zpl", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
    {"id": "zebra-gk420", "nombre": "Zebra GK420", "lenguaje": "zpl", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
    {"id": "otra-tspl", "nombre": "Otra con TSPL", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 110, "densidad": 8},
    {"id": "otra-zpl", "nombre": "Otra con ZPL", "lenguaje": "zpl", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
    {"id": "otra-pdf", "nombre": "Otra, con controlador de Windows (PDF)", "lenguaje": "pdf", "dpi": 203, "ancho_max_mm": 110, "densidad": None},
)


# ---------------------------------------------------------------------------------------------- códigos
def norm_codigo(codigo) -> str:
    """Un código como se compara: sin espacios a los lados y sin distinguir mayúsculas ('' = sin código)."""
    return str(codigo if codigo is not None else "").strip().lower()


def digito_ean13(doce) -> int:
    """Dígito verificador de un EAN-13 a partir de sus 12 primeros dígitos."""
    return (10 - sum(int(c) * (3 if i % 2 else 1) for i, c in enumerate(str(doce))) % 10) % 10


def es_ean13(codigo) -> bool:
    """13 dígitos con el dígito verificador correcto."""
    c = str(codigo if codigo is not None else "")
    return len(c) == 13 and c.isascii() and c.isdigit() and digito_ean13(c[:12]) == int(c[12])


def simbologia(codigo) -> str:
    """'ean13' cuando el código son 13 dígitos con su dígito verificador correcto; si no, 'code128'."""
    return "ean13" if es_ean13(codigo) else "code128"


ID_PROPIO_MAX = 99_999_999              # el id más grande que cabe en el EAN-13 propio (8 dígitos)


def marca_empresa(numero_id, sucursal=None) -> str:
    """La marca de la empresa en sus códigos generados: los 3 últimos dígitos de su cédula (solo los dígitos; con ceros a la
    izquierda si hay menos de 3; «000» si no tiene cédula). Es la misma en la nube y en el programa local de esa empresa.
    Las sucursales de una misma cédula se llevan como empresas aparte: para que no reciban la misma marca se le suma el código
    de sucursal de la empresa menos 1 (Empresa.sucursal; sin dato, 1: la marca son los 3 dígitos tal cual) y se toman los 3
    últimos dígitos. Límite conocido: dos empresas con la misma cédula Y el mismo código de sucursal tienen la misma marca."""
    digitos = "".join(ch for ch in str(numero_id if numero_id is not None else "") if ch in "0123456789")
    try:
        suc = int(sucursal)
    except (TypeError, ValueError, OverflowError):
        suc = 1
    return str((int(digitos[-3:] or 0) + max(suc, 1) - 1) % 1000).zfill(3)


def codigo_barras_propio(pid, marca) -> str:
    """Código de barras propio de un producto: EAN-13 de uso interno = «2» + la marca de la empresa (3 dígitos, marca_empresa) +
    su id con ceros a la izquierda hasta 8 dígitos + dígito verificador. El id es único por empresa y nunca se reutiliza (cada
    instalación local tiene su rango de ids), así que el código no se repite, ni sin conexión; la marca hace que el producto 37
    de una empresa y el 37 de otra del grupo no reciban el mismo. Un id que no cabe en 8 dígitos (instalación local con
    terminal 10 o más): «P» + marca + «-» + id (se imprime en Code128)."""
    n, m = int(pid), str(marca if marca is not None else "")
    if n < 0:
        raise ValueError("El id del producto no puede ser negativo")
    if len(m) != 3 or any(ch not in "0123456789" for ch in m):
        raise ValueError("La marca de la empresa son 3 dígitos")
    if n > ID_PROPIO_MAX:
        return f"P{m}-{n}"
    doce = "2" + m + str(n).zfill(8)
    return doce + str(digito_ean13(doce))


def es_codigo_propio(codigo, pid) -> bool:
    """¿Ese código es el generado de ese producto? Un EAN-13 válido que empieza con «2» y cuyos dígitos 5 a 12 son su id, o la
    forma «P…-id», con CUALQUIER marca: si la empresa corrige su cédula, los códigos que ya generó siguen siendo los propios."""
    c = norm_codigo(codigo)
    try:
        n = int(pid)
    except (TypeError, ValueError):
        return False
    if n < 0:
        return False
    if n > ID_PROPIO_MAX:
        return len(c) > 5 and c[0] == "p" and all(ch in "0123456789" for ch in c[1:4]) and c[4:] == f"-{n}"
    return es_ean13(c) and c[0] == "2" and c[4:12] == str(n).zfill(8)


def medida_valida(ancho_mm, alto_mm) -> bool:
    try:
        a, h = float(ancho_mm), float(alto_mm)
    except (TypeError, ValueError):
        return False
    return ANCHO_MIN <= a <= ANCHO_MAX and ALTO_MIN <= h <= ALTO_MAX


def limpiar(texto, tope: int = 80) -> str:
    """Texto que va en una etiqueta: sin saltos ni caracteres de control, sin la comilla doble ni los signos que los lenguajes
    de las impresoras usan como órdenes (^ ~ \\), con los espacios compactados y recortado a `tope`. «₡» pasa a «¢», que es
    el que traen las letras de las impresoras y del PDF."""
    t = unicodedata.normalize("NFC", str(texto if texto is not None else ""))
    out = []
    for ch in t:
        if ch == '"':
            ch = "'"
        elif ch in "^~":
            ch = " "
        elif ch == "\\":
            ch = "/"
        elif ch == "₡":
            ch = "¢"
        elif unicodedata.category(ch)[0] in "CZ":        # controles, saltos y separadores: un espacio
            ch = " "
        out.append(ch)
    return " ".join("".join(out).split())[:max(0, int(tope))].strip()


# ---------------------------------------------------------------------------------------------- el trabajo en el lenguaje de la impresora
# Las órdenes se arman AQUÍ a partir de datos (nombre, código, precio, copias y medidas); la pantalla nunca manda órdenes. Solo se
# usan las más básicas y documentadas de cada lenguaje:
#   TSPL: SIZE, GAP, DIRECTION, CODEPAGE, DENSITY, CLS, TEXT, BARCODE, PRINT.
#   ZPL:  ^XA, ^PO, ^CI28, ^PW, ^LL, ^FO, ^A0, ^FB, ^FD, ^FS, ^BY, ^BC, ^BE, ^PQ, ^XZ (y ~SD solo si se pide una densidad).
# El número legible lo escribe el sistema como un texto debajo de las barras (no el de la impresora): así sale igual en todas.
DPI_VALIDOS = (203, 300, 600)
DENSIDAD_MAX = {"tspl": 15, "zpl": 30}
NO_EN_BARRAS = '"^~>\\'                 # signos que TSPL o ZPL leen como órdenes: un código que los lleve no se manda a la impresora
FUENTES_TSPL = (("3", 2, 32, 48), ("3", 1, 16, 24), ("2", 1, 12, 20), ("1", 1, 8, 12))   # (letra, multiplicador, ancho y alto de un carácter en puntos)
FUENTES_ZPL = (48, 28, 22, 18)          # alto de la letra 0 en puntos, a 203 dpi (se escala con la resolución)


def _puntos(mm, dpi) -> int:
    return int(round(float(mm) * dpi / 25.4))


def _mm(v) -> str:
    return f"{float(v):g}"


def puntos_del_modulo(disponible, modulos, dpi, ean) -> int:
    """Ancho de la barra más angosta (el módulo) en puntos ENTEROS de la impresora, según su resolución: el mayor que quepa en
    `disponible` (puntos de ancho de la etiqueta) con sus `modulos` (barras + zona quieta), desde 0,5 mm (203 → 4 puntos; 300 → 6;
    600 → 12; en Code128, 0,375 mm: 3, 4 y 9) bajando de uno en uno hasta 0,12 mm (203 → 1; 300 → 2; 600 → 3): más fino no lo lee
    el lector. 0 si no cabe ni el menor. Es la misma regla para el envío directo (plan_etiqueta) y para el PDF (app/etiquetas.py)."""
    mayor = int(round((0.5 if ean else 0.375) * dpi / 25.4))
    menor = 0.12 * dpi / 25.4
    menor = int(menor) + (menor > int(menor))                      # hacia arriba
    return next((k for k in range(mayor, menor - 1, -1) if modulos * k <= disponible + 1e-9), 0)


def codigo_imprimible(codigo) -> bool:
    """Un código que la impresora puede poner en barras: caracteres ASCII visibles y sin los signos que son órdenes."""
    c = str(codigo if codigo is not None else "")
    return bool(c) and all(32 <= ord(ch) <= 126 and ch not in NO_EN_BARRAS for ch in c)


def _envolver(texto, cols, renglones):
    """Parte un texto en renglones de hasta `cols` caracteres cortando por palabras → (los primeros `renglones`, ¿cupo entero?)."""
    cols = max(1, int(cols))
    lineas, linea = [], ""
    for palabra in str(texto).split(" "):
        while len(palabra) > cols:
            if linea:
                lineas.append(linea); linea = ""
            lineas.append(palabra[:cols]); palabra = palabra[cols:]
        if not linea:
            linea = palabra
        elif len(linea) + 1 + len(palabra) <= cols:
            linea += " " + palabra
        else:
            lineas.append(linea); linea = palabra
    if linea:
        lineas.append(linea)
    return lineas[:renglones], len(lineas) <= renglones


def plan_etiqueta(nombre, codigo, precio, ancho_mm, alto_mm, dpi, fuentes) -> dict:
    """Dónde va cada cosa en una etiqueta, en puntos de la impresora (origen arriba a la izquierda): el nombre arriba en hasta
    2 renglones (con la letra más grande de `fuentes` en que quepa entero; si en ninguna, la más chica y recortado), las barras
    al centro con su zona quieta, el número legible debajo y el precio al pie. `fuentes` = [(clave, ancho, alto de un carácter)]
    de mayor a menor. ValueError si el código no cabe a lo ancho o la etiqueta es muy baja."""
    W, H = _puntos(ancho_mm, dpi), _puntos(alto_mm, dpi)
    m = _puntos(1.5 if alto_mm >= 20 else 1.0, dpi)                 # margen
    g = max(2, _puntos(0.5, dpi))                                    # aire entre renglones y bloques
    util = W - 2 * m
    ean = es_ean13(codigo)
    modulos = 95 if ean else 11 * (len(codigo) + 2) + 13            # Code128 en el juego B: inicio + un símbolo por carácter + verificador (11 c/u) + parada (13)
    quieta = 22 if ean else 20                                      # módulos en blanco que exige el lector, sumando los dos lados
    n = puntos_del_modulo(W, modulos + quieta, dpi, ean)             # a 203 puntos por pulgada: 4, 3, 2 o 1 (Code128: 3, 2 o 1)
    if not n:
        raise ValueError(f"El código {codigo} no cabe en una etiqueta de {_mm(ancho_mm)} mm de ancho: use una etiqueta más ancha")
    tope_letra = max(H // 8, fuentes[-1][2])                         # la letra no se come la etiqueta
    posibles = [f for f in fuentes if f[2] <= tope_letra] or [fuentes[-1]]
    chicas = [f for f in posibles if f[2] <= _puntos(2.5, dpi)] or [posibles[-1]]      # el número legible, en letra de hasta 2,5 mm de alto
    f_num = next((f for f in chicas if len(codigo) * f[1] <= util), chicas[-1])
    f_pre = next((f for f in posibles if len(precio) * f[1] <= util), posibles[-1]) if precio else None
    fijo = 2 * m + f_num[2] + g + ((f_pre[2] + g) if f_pre else 0)
    minimo = _puntos(5, dpi)
    lineas, f_nom = [], posibles[-1]
    if nombre:
        elegido = None
        for f in posibles:                                           # la letra más grande en que el nombre cabe entero en 2 renglones y deja barras
            ls, cabe = _envolver(nombre, util // f[1], 2)
            if cabe and H - fijo - len(ls) * (f[2] + g) >= minimo:
                elegido = (ls, f); break
        if elegido is None:                                          # no cabe entero: la más chica, recortado; en una etiqueta baja, un solo renglón
            f = posibles[-1]
            ls, _ = _envolver(nombre, util // f[1], 2)
            if len(ls) > 1 and H - fijo - len(ls) * (f[2] + g) < minimo:
                ls = ls[:1]
            elegido = (ls, f)
        lineas, f_nom = elegido
    alto_barras = H - fijo - len(lineas) * (f_nom[2] + g)
    if alto_barras < _puntos(3, dpi):
        raise ValueError(f"Una etiqueta de {_mm(alto_mm)} mm de alto es muy baja para ese formato: elija otra medida o «Solo el código de barras»")
    alto_barras = min(alto_barras, _puntos(25, dpi))
    total = len(lineas) * (f_nom[2] + g) + alto_barras + g + f_num[2] + ((g + f_pre[2]) if f_pre else 0)
    y = m + max(0, (H - 2 * m - total) // 2)                         # el bloque, centrado a lo alto
    centro = lambda texto, f: max(0, (W - len(texto) * f[1]) // 2)   # noqa: E731
    out = {"W": W, "H": H, "ean": ean, "n": n, "nombre": [], "f_nombre": f_nom, "f_numero": f_num, "f_precio": f_pre, "precio": None}
    for ln in lineas:
        out["nombre"].append((ln, centro(ln, f_nom), y)); y += f_nom[2] + g
    out["barras"] = ((W - modulos * n) // 2, y, alto_barras); y += alto_barras + g
    numero = codigo[:max(1, util // f_num[1])]
    out["numero"] = (numero, centro(numero, f_num), y); y += f_num[2]
    if f_pre:
        y += g
        texto = precio[:max(1, util // f_pre[1])]
        out["precio"] = (texto, centro(texto, f_pre), y)
    return out


def _datos_etiqueta(e: dict) -> tuple:
    codigo = str(e.get("codigo") if e.get("codigo") is not None else "").strip()
    if not codigo_imprimible(codigo):
        raise ValueError(f"El código «{limpiar(codigo, 40)}» no se puede imprimir en barras: solo letras sin tilde, números y signos corrientes" if codigo else "Hay un producto sin código: genérele uno antes de imprimir su etiqueta")
    try:
        copias = int(e.get("copias") if e.get("copias") is not None else 1)
    except (TypeError, ValueError):
        copias = 0
    if not 1 <= copias <= COPIAS_MAX:
        raise ValueError(f"Las copias de cada producto van de 1 a {COPIAS_MAX}")
    return limpiar(e.get("nombre"), 120), codigo, limpiar(e.get("precio"), 24), copias


def tspl(etiquetas: list, ancho_mm, alto_mm, separacion_mm=SEPARACION_MM, densidad=8, dpi: int = 203, girar: bool = False) -> bytes:
    """El trabajo en TSPL (3nStar, TSC, Xprinter, Gprinter…): una etiqueta por cada {nombre, codigo, precio, copias}, con tantas
    copias como pida (PRINT 1,copias). Las tildes y la ñ van con CODEPAGE 1252. `girar` = la impresión sale girada 180° (para
    la impresora en la que la etiqueta sale de cabeza): DIRECTION 0 en vez de 1. Bytes listos para mandar crudos a la impresora."""
    fuentes = [((f, mul), ancho, alto) for f, mul, ancho, alto in FUENTES_TSPL]
    out = [f"SIZE {_mm(ancho_mm)} mm,{_mm(alto_mm)} mm", f"GAP {_mm(separacion_mm)} mm,0 mm", "DIRECTION 0" if girar else "DIRECTION 1", "CODEPAGE 1252"]
    if densidad is not None:
        out.append(f"DENSITY {int(densidad)}")
    for e in etiquetas:
        nombre, codigo, precio, copias = _datos_etiqueta(e)
        p = plan_etiqueta(nombre, codigo, precio, ancho_mm, alto_mm, dpi, fuentes)
        out.append("CLS")

        def texto(dato, f):
            (letra, mul), (t, x, y) = f[0], dato
            out.append(f'TEXT {x},{y},"{letra}",0,{mul},{mul},"{t}"')
        for dato in p["nombre"]:
            texto(dato, p["f_nombre"])
        x, y, alto = p["barras"]
        # EAN13 recibe los 12 primeros dígitos (el verificador lo calcula la impresora y es el mismo); 128 escoge solo su juego
        out.append(f'BARCODE {x},{y},"EAN13",{alto},0,0,{p["n"]},{p["n"]},"{codigo[:12]}"' if p["ean"] else f'BARCODE {x},{y},"128",{alto},0,0,{p["n"]},{p["n"]},"{codigo}"')
        texto(p["numero"], p["f_numero"])
        if p["precio"]:
            texto(p["precio"], p["f_precio"])
        out.append(f"PRINT 1,{copias}")
    return ("\r\n".join(out) + "\r\n").encode("cp1252", errors="replace")


def zpl(etiquetas: list, ancho_mm, alto_mm, densidad=None, dpi: int = 203, girar: bool = False) -> bytes:
    """El trabajo en ZPL (Zebra): un formato ^XA…^XZ por cada {nombre, codigo, precio, copias}, con ^PQ copias. Las tildes y la ñ
    van en UTF-8 (^CI28). La separación entre etiquetas la mide la propia impresora (no se manda). `girar` = la impresión sale
    girada 180°: ^POI en vez de ^PON, justo después de ^XA."""
    esc = dpi / 203.0
    fuentes = [(max(10, int(round(h * esc))), max(6, int(round(h * esc * 0.6))), max(10, int(round(h * esc)))) for h in FUENTES_ZPL]   # (alto, ancho medio estimado de un carácter, alto)
    out = []
    if densidad is not None:
        out.append(f"~SD{int(densidad):02d}")
    for e in etiquetas:
        nombre, codigo, precio, copias = _datos_etiqueta(e)
        p = plan_etiqueta(nombre, codigo, precio, ancho_mm, alto_mm, dpi, fuentes)
        W = p["W"]
        out += ["^XA", "^POI" if girar else "^PON", "^CI28", f"^PW{W}", f"^LL{p['H']}"]

        def texto(dato, f):                                         # centrado por la impresora en un bloque del ancho de la etiqueta
            t, _x, y = dato
            out.append(f"^FO0,{y}^A0N,{f[0]},{f[0]}^FB{W},1,0,C^FD{t}\\&^FS")
        for dato in p["nombre"]:
            texto(dato, p["f_nombre"])
        x, y, alto = p["barras"]
        out.append(f"^FO{x},{y}^BY{p['n']}^BEN,{alto},N,N^FD{codigo[:12]}^FS" if p["ean"] else f"^FO{x},{y}^BY{p['n']}^BCN,{alto},N,N,N^FD{codigo}^FS")
        texto(p["numero"], p["f_numero"])
        if p["precio"]:
            texto(p["precio"], p["f_precio"])
        out += [f"^PQ{copias}", "^XZ"]
    return ("\n".join(out) + "\n").encode("utf-8")


def trabajo_etiquetas(trabajo: dict) -> tuple:
    """Trabajo de etiquetas que llega al servicio de impresión local →  (impresora {conexion, direccion}, bytes para mandarle).
    {conexion: usb|red, direccion, lenguaje: tspl|zpl, ancho_mm, alto_mm, separacion_mm, densidad, dpi, girar, etiquetas: [{nombre, codigo, precio?, copias}]}
    Valida los mismos topes del PDF (medida, 1 a 500 copias por producto, hasta 3.000 por pedido). ValueError con el motivo."""
    if not isinstance(trabajo, dict):
        raise ValueError("El trabajo de etiquetas no es válido")
    lenguaje = str(trabajo.get("lenguaje") or "").lower()
    if lenguaje not in ("tspl", "zpl"):
        raise ValueError("El envío directo de etiquetas es para impresoras con TSPL o ZPL; las demás imprimen el PDF con su controlador")
    conexion = str(trabajo.get("conexion") or "").lower()
    if conexion not in ("usb", "red"):
        raise ValueError("La impresora de etiquetas debe estar conectada por USB (su nombre en Windows) o por red (su dirección IP)")
    if conexion == "usb" and not str(trabajo.get("direccion") or "").strip():      # sin nombre saldría por la impresora predeterminada de Windows (la de tiquetes o la de la oficina)
        raise ValueError("Indique el nombre de la impresora de etiquetas en Windows")
    ancho, alto = trabajo.get("ancho_mm"), trabajo.get("alto_mm")
    if not medida_valida(ancho, alto):
        raise ValueError(f"La medida de la etiqueta va de {ANCHO_MIN} a {ANCHO_MAX} mm de ancho y de {ALTO_MIN} a {ALTO_MAX} mm de alto")
    ancho, alto = float(ancho), float(alto)
    try:
        sep = float(trabajo.get("separacion_mm") if trabajo.get("separacion_mm") not in (None, "") else SEPARACION_MM)
        dpi = int(trabajo.get("dpi") or 203)
        densidad = None if trabajo.get("densidad") in (None, "") else int(trabajo.get("densidad"))
    except (TypeError, ValueError):
        raise ValueError("La separación, la densidad y la resolución de la impresora deben ser números")
    if not 0 <= sep <= 20:
        raise ValueError("La separación entre etiquetas va de 0 a 20 mm")
    if dpi not in DPI_VALIDOS:
        raise ValueError("La resolución de la impresora debe ser 203, 300 o 600 puntos por pulgada")
    if densidad is not None and not 0 <= densidad <= DENSIDAD_MAX[lenguaje]:
        raise ValueError(f"La densidad va de 0 a {DENSIDAD_MAX[lenguaje]}")
    etiquetas = trabajo.get("etiquetas")
    if not isinstance(etiquetas, list) or not etiquetas or not all(isinstance(e, dict) for e in etiquetas):
        raise ValueError("No hay etiquetas por imprimir")
    if len(etiquetas) > ETIQUETAS_MAX or sum(_datos_etiqueta(e)[3] for e in etiquetas) > ETIQUETAS_MAX:
        raise ValueError(f"Un pedido lleva hasta {ETIQUETAS_MAX} etiquetas: imprímalas en varias tandas")
    girar = trabajo.get("girar") is True                           # la impresión girada 180° (casilla de la impresora); sin el dato, normal
    datos = tspl(etiquetas, ancho, alto, sep, densidad, dpi, girar) if lenguaje == "tspl" else zpl(etiquetas, ancho, alto, densidad, dpi, girar)
    return {"conexion": conexion, "direccion": str(trabajo.get("direccion") or "").strip()}, datos
