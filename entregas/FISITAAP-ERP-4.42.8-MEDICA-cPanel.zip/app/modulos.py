"""Módulos comerciales sin integración con Hacienda, guardados en el servidor por empresa.

- Registro: datos JSON por clave (cotizaciones, remisiones, compras, órdenes, bancos, contabilidad, tareas, listas de
  configuración…). Dos formas:
  * colección (coleccion=True): lista de objetos con id; cada elemento es una fila de RegistroItem. La interfaz envía solo
    lo que cambió (POST /api/registros/{clave}/cambios: altas, cambios y bajas por id), así dos usuarios que trabajan a la
    vez no se borran el trabajo y no hay tope de tamaño para la lista completa.
  * valor (coleccion=False): cualquier otro JSON (objetos de configuración, listas sin id). Se reemplaza completo con
    control de versión: si otro lo cambió desde que se leyó, el servidor responde 409 con la versión actual y la interfaz
    fusiona y reintenta.
  version sube en cada cambio; la interfaz la usa para refrescar solo lo que cambió (GET /api/registros/versiones).
- Pago: pagos recibidos (recibo de caja / REP) aplicados a facturas; actualiza Documento.pagado.
- Recurrente + FacturaPendiente: facturas recurrentes. El servidor genera, en la fecha programada, una factura PENDIENTE
  DE EMITIR (no consume consecutivo); el usuario la revisa, la emite (POST /api/comprobantes con pendiente_id) o la pospone.
"""
import calendar
import json
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import UniqueConstraint, func, update
from sqlmodel import Field, SQLModel, select

from .db import Documento, por_empresa

PERIODOS = {"diaria": (0, 1), "semanal": (0, 7), "quincenal": (0, 15), "mensual": (1, 0), "bimensual": (2, 0),
            "trimestral": (3, 0), "semestral": (6, 0), "anual": (12, 0)}      # (meses, días)


class Registro(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    clave: str = Field(index=True)
    datos: str = "[]"                      # JSON (solo en registros de tipo valor; las colecciones viven en RegistroItem)
    version: int = 0
    coleccion: bool = False
    ultimo_id: int = 0                     # mayor id que tuvo la colección: un id borrado no se vuelve a dar a otro elemento
    actualizado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class RegistroItem(SQLModel, table=True):
    """Un elemento de un registro de tipo colección (por ejemplo, un asiento, una compra o un movimiento bancario)."""
    __table_args__ = (UniqueConstraint("empresa_id", "clave", "item_id", name="ux_registroitem"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    clave: str = Field(index=True)
    item_id: int
    orden: int = 0
    datos: str = "{}"
    actualizado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Pago(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    numero: int = 1
    tipo: str = "caja"                     # caja | rep
    consecutivo: Optional[str] = None
    cliente_id: Optional[int] = None
    cliente_nombre: Optional[str] = None
    cliente_cedula: Optional[str] = None
    detalles: str = ""
    fecha: str = ""
    cuenta: str = ""
    condicion_venta: str = "01"
    medio_pago: str = "04"
    moneda: str = "CRC"
    tipo_cambio: float = 1
    monto: float = 0
    estado: str = "No conciliado"
    notas: str = ""
    facturas: str = "[]"                   # JSON [{id, consecutivo, monto}]
    documentos: str = "[]"                 # JSON [{id, consecutivo, clave, estado}] REP emitidos por este pago
    usuario: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    origen_sinc: Optional[str] = None      # nube: «terminal:id local» del cobro que subió una instalación local (3.13)
    sinc_en: Optional[str] = None          # instalación local: cuándo subió a la nube
    idempotencia: Optional[str] = None     # 4.8: clave del cobro que manda la caja; si llega repetida se devuelve el ya registrado (índice único ux_pago_idem)


class Recurrente(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str = ""
    cliente_id: Optional[int] = None
    cliente_nombre: Optional[str] = None
    tipo_documento: str = "01"
    condicion_venta: str = "01"
    condicion_venta_otros: Optional[str] = None   # descripción con la condición 99 (se copia a cada factura pendiente)
    plazo_credito: Optional[int] = None
    medio_pago: str = "01"
    medio_pago_otros: Optional[str] = None        # descripción con el medio 99
    moneda: str = "CRC"
    periodicidad: str = "mensual"
    dia_emision: int = 1
    mes_emision: Optional[int] = None      # 1-12: mes de la (primera) emisión en bimestral/trimestral/semestral/anual (3.30)
    dia_semana: Optional[int] = None       # 0 = lunes … 6 = domingo, en semanal (3.30)
    dia_emision2: Optional[int] = None     # quincenal: segundo día del mes (con dia_emision el primero); vacío = cada 15 días (3.30)
    actividad_emisor: Optional[str] = None # actividad económica con que se emite (vacío = la principal) (3.30)
    dias_vencimiento: Optional[int] = None # cada factura vence N días después de su emisión (a crédito = el plazo) (3.31)
    inicio: str = ""                       # YYYY-MM-DD
    fin: Optional[str] = None
    proxima: Optional[str] = None          # próxima fecha a generar
    lineas: str = "[]"                     # JSON (mismo formato que el formulario de factura)
    observaciones: Optional[str] = None
    terminos: Optional[str] = None
    vendedor: Optional[str] = None
    activa: bool = True
    exoneracion_id: Optional[int] = None    # exoneración del cliente para cada factura; 0 = no aplicar; vacío = la vigente del cliente
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class FacturaPendiente(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    recurrente_id: int = Field(index=True)
    fecha_programada: str = ""
    periodo: str = ""                      # fecha del período original (no cambia al posponer) (R191)
    estado: str = "pendiente"              # pendiente | emitida | omitida
    documento_id: Optional[int] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Borrador(SQLModel, table=True):
    """Comprobante guardado SIN emitir: no consume consecutivo, no se firma, no descuenta inventario y la cola no lo ve.
    Guarda el formulario tal cual (JSON) y al pulsar Emitir se envía como un comprobante normal (antes «Guardar sin emitir»
    firmaba el comprobante y la cola lo mandaba a Hacienda en minutos)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    tipo_documento: str = "01"
    cliente_id: Optional[int] = None
    receptor_nombre: Optional[str] = None
    moneda: str = "CRC"
    total: float = 0                      # estimado con los datos del formulario (para la lista)
    datos: str = "{}"                     # ComprobanteIn tal cual lo mandó el formulario
    usuario: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    actualizado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


por_empresa(Registro, RegistroItem, Pago, Recurrente, FacturaPendiente, Borrador)

LIMITE_VALOR = 2_000_000          # bytes de un registro de tipo valor
LIMITE_ITEM = 2_000_000           # bytes de un elemento de colección (igual que el tope viejo de un registro completo: la migración nunca falla por tamaño)


class RecargarPagina(Exception):
    """Una pestaña con la versión anterior del sistema quiso reemplazar un registro sin versión (pisaría lo de otros).
    `guardadas`: altas de esa pestaña que sí se guardaron (para que no se pierdan ni se repitan); `descartadas`: elementos
    de esa pestaña que el servidor no tiene y no se pudieron guardar (el usuario debe revisarlos)."""
    def __init__(self, guardadas: int = 0, descartadas: int = 0):
        super().__init__("recargar"); self.guardadas, self.descartadas = guardadas, descartadas


class ConflictoRegistro(Exception):
    """Otro usuario cambió el registro desde que se leyó: lleva la versión actual para fusionar."""
    def __init__(self, datos, version):
        super().__init__("conflicto"); self.datos, self.version = datos, version


def _id_entero(v) -> Optional[int]:
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, str) and v.strip().lstrip("-").isdigit():
        return int(v.strip())
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return None


ID_MAXIMO = 2 ** 53 - 1                 # el navegador no representa enteros más grandes sin perder precisión
SALTO_MAXIMO = 1_000_000                # un alta no puede saltar más que esto por encima del mayor id usado: un id enorme
                                        # dejaba el tope de la colección sin espacio y ninguna alta se podía guardar
RANGO = 10_000_000                      # ids por instalación (3.13): la nube da ids de 1 a 9 999 999; una instalación local con
                                        # terminal t los da desde t·10 000 000. Así lo que crea cada una nunca choca al sincronizar.
_rangos: dict[int, int] = {}            # {empresa_id: rango propio}; en la nube siempre 0 (lo fija sinc en la instalación local)


def rango_propio(eid: int) -> int:
    return _rangos.get(eid, 0)


def fijar_rango(eid: int, rango: int) -> None:
    _rangos[eid] = int(rango or 0)


def en_rango(iid, rango: int) -> bool:
    """Si el id pertenece al rango de esa instalación (0 = la nube)."""
    return iid is not None and int(iid) // RANGO == int(rango)


al_borrar = None        # instalación local (3.14): sinc registra las bajas (lápidas) para avisar a las otras computadoras del local
# 4.31: {clave: módulo con unir, cerrar, recrear, es_recreada_de, fusion_valida} — main.py registra fusion_cuentas para pos_espera.
# aplicar_cambios fusiona dentro del bloqueo los guardados de esas claves (la misma cuenta guardada desde dos equipos no pierde platos)
FUSIONES: dict = {}


def _validar_id(iid) -> int:
    """Id de un elemento que se guarda: entero en el rango que el navegador maneja (un id enorme subía el tope de la
    colección al máximo y desde ahí ninguna alta se podía guardar)."""
    if iid is None or abs(iid) > ID_MAXIMO:
        raise ValueError("Cada elemento necesita un id entero válido")
    return iid


def es_lista_ids(v) -> bool:
    """Lista de objetos con id entero: se guarda como colección (un elemento por fila)."""
    return isinstance(v, list) and all(isinstance(x, dict) and _id_entero(x.get("id")) is not None for x in v)


def _registro(s, eid: int, clave: str):
    return s.exec(select(Registro).where(Registro.empresa_id == eid, Registro.clave == clave).order_by(Registro.id)).first()


def _items(s, eid: int, clave: str) -> list:
    filas = s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)
                   .order_by(RegistroItem.orden, RegistroItem.item_id)).all()
    out = []
    for f in filas:
        try:
            out.append(json.loads(f.datos))
        except ValueError:
            continue
    return out


def leer(s, eid: int, clave: str, defecto=None):
    """Datos actuales de un registro (colección armada en orden o valor)."""
    r = _registro(s, eid, clave)
    if not r:
        return defecto
    if r.coleccion:
        return _items(s, eid, clave)
    try:
        return json.loads(r.datos)
    except ValueError:
        return defecto


def leer_todo(s, eid: int) -> tuple[dict, dict]:
    """{clave: datos} y {clave: version} de toda la empresa (las colecciones se arman en una sola consulta)."""
    datos, versiones = {}, {}
    regs = s.exec(select(Registro).where(Registro.empresa_id == eid).order_by(Registro.id)).all()
    agrupados: dict[str, list] = {}
    for f in s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid).order_by(RegistroItem.clave, RegistroItem.orden, RegistroItem.item_id)).all():
        try:
            agrupados.setdefault(f.clave, []).append(json.loads(f.datos))
        except ValueError:
            continue
    for r in regs:
        if r.clave in datos:
            continue                                   # duplicado viejo: vale el primero
        if r.coleccion:
            datos[r.clave] = agrupados.get(r.clave, [])
        else:
            try:
                datos[r.clave] = json.loads(r.datos)
            except ValueError:
                continue
        versiones[r.clave] = r.version or 0
    return datos, versiones


def leer_todo_texto(s, eid: int, permitido=None, ventanas: dict | None = None) -> tuple[str, dict, dict]:
    """Como leer_todo, pero devuelve el objeto {clave: datos} ya como texto JSON (3.72): los elementos de las colecciones se guardan
    en JSON y se concatenan tal cual, sin parsear y volver a serializar. Con `permitido(clave)` se omiten las claves que no se
    pueden leer. `ventanas` = {clave: "AAAA-MM-DD"} (3.73): de esa colección solo van los elementos con fecha (hora o fecha) desde ese
    día; los demás se cuentan en `parciales` y la pantalla que los necesite los pide completos. 3.87: o {clave: función(elemento)}
    con los que sí van (lo que ese rol puede leer; no se cuentan como parciales). Devuelve (texto, {clave: version},
    {clave: {desde, omitidos}})."""
    regs = s.exec(select(Registro.clave, Registro.coleccion, Registro.datos, Registro.version).where(Registro.empresa_id == eid).order_by(Registro.id)).all()
    agrupados: dict[str, list] = {}
    omitidos: dict[str, int] = {}
    ventanas = ventanas or {}
    for clave, datos in s.exec(select(RegistroItem.clave, RegistroItem.datos).where(RegistroItem.empresa_id == eid)
                               .order_by(RegistroItem.clave, RegistroItem.orden, RegistroItem.item_id)).all():
        try:
            obj = json.loads(datos)                    # un elemento dañado se omite, como en leer_todo
        except ValueError:
            continue
        if callable(ventanas.get(clave)) and not ventanas[clave](obj):   # 3.87: filtro por elemento (lo que lee el Cajero); no es «parcial»
            continue
        if isinstance(ventanas.get(clave), str) and isinstance(obj, dict):
            f = str(obj.get("hora") or obj.get("fecha") or "")[:10]
            if f and f < ventanas[clave]:
                omitidos[clave] = omitidos.get(clave, 0) + 1
                continue
        agrupados.setdefault(clave, []).append(datos)
    partes, versiones, vistos = [], {}, set()
    for clave, coleccion, datos, version in regs:
        if clave in vistos or (permitido is not None and not permitido(clave)):
            continue
        vistos.add(clave)
        if coleccion:
            partes.append(json.dumps(clave) + ":[" + ",".join(agrupados.get(clave, [])) + "]")
        else:
            try:
                json.loads(datos)
            except ValueError:
                continue
            partes.append(json.dumps(clave) + ":" + datos)
        versiones[clave] = version or 0
    parciales = {k: {"desde": ventanas[k], "omitidos": n} for k, n in omitidos.items() if n and k in versiones}
    return "{" + ",".join(partes) + "}", versiones, parciales


def versiones(s, eid: int) -> dict:
    out = {}
    for r in s.exec(select(Registro).where(Registro.empresa_id == eid).order_by(Registro.id)).all():
        out.setdefault(r.clave, r.version or 0)
    return out


def _bloquear(s, r: Registro):
    """Toma el bloqueo de escritura de la base ANTES de leer los elementos: dos procesos que cambian la misma colección
    se ordenan (el segundo lee lo que confirmó el primero) en lugar de chocar al escribir."""
    s.execute(update(Registro).where(Registro.id == r.id).values(version=Registro.version))
    s.refresh(r)


def topes(s, eid: int) -> dict:
    """{clave: mayor id que tuvo la colección}: el navegador da ids nuevos por encima (no reutiliza uno borrado)."""
    return {r.clave: r.ultimo_id for r in s.exec(select(Registro).where(Registro.empresa_id == eid, Registro.coleccion == True)).all()  # noqa: E712
            if r.ultimo_id}


def _json(x) -> str:
    """JSON para guardar. NaN e Infinity no son JSON válido: guardados, dejaban sin respuesta la lectura de los registros."""
    try:
        return json.dumps(x, ensure_ascii=False, allow_nan=False)
    except ValueError:
        raise ValueError("Hay un número no válido (NaN o infinito) en los datos")


def _texto_item(x: dict) -> str:
    t = _json(x)
    if len(t.encode("utf-8")) > LIMITE_ITEM:
        raise ValueError(f"Un elemento supera el tamaño máximo ({LIMITE_ITEM // 1_000_000} MB)")
    return t


def _escribir_coleccion(s, r: Registro, lista: list):
    """Reemplaza todos los elementos de la colección por `lista` (ids repetidos reciben uno nuevo)."""
    for f in s.exec(select(RegistroItem).where(RegistroItem.empresa_id == r.empresa_id, RegistroItem.clave == r.clave)).all():
        s.delete(f)
    s.flush()
    # 4.9: el id nuevo de un repetido sale del rango propio (antes, del mayor de todos: con elementos sincronizados de otra
    # instalación caía en el rango de ella) y por encima del mayor que tuvo la colección (no repite uno borrado)
    rp = rango_propio(r.empresa_id)
    ult = r.ultimo_id or 0
    usados = set()
    maximo = max([i for i in (_id_entero(x.get("id")) for x in lista) if i is not None and en_rango(i, rp)] + [ult if en_rango(ult, rp) else 0, rp * RANGO])
    ahora = datetime.now(timezone.utc)
    for i, x in enumerate(lista):
        iid = _validar_id(_id_entero(x.get("id")))
        if iid in usados:
            maximo += 1; iid = maximo; x = {**x, "id": iid}
        usados.add(iid)
        s.add(RegistroItem(empresa_id=r.empresa_id, clave=r.clave, item_id=iid, orden=i, datos=_texto_item(x), actualizado=ahora))
    r.coleccion = True; r.datos = "[]"; r.ultimo_id = max([r.ultimo_id or 0] + [i for i in usados if en_rango(i, rp)])


# Plantilla inicial del punto de venta para restaurantes (3.58): una caja en modo restaurante con 6 mesas en cuadrícula, con las
# mismas llaves que terminalCompleta y mesasEnCuadricula de pages/pos/_datos.js, para que el plano ya exista al entrar.
TERMINAL_BASE = {
    "id": 1, "nombre": "Caja 1", "modo": "mostrador", "tipo_documento": "04", "bodega_id": None, "cuentas": {"01": "", "02": "", "06": "", "04": "", "03": "", "99": "", "USD": ""},
    "imprimir_auto": True, "formato": "tiquete", "ancho_ticket": 80, "servicio_pct": 0, "servicio_detalle": "Impuesto de servicio 10 %",
    "precio_editable": True, "descuento_max_pct": 100, "mostrar_imagenes": True, "mostrar_existencias": True, "pedir_apertura": True, "enviar_hacienda": True,
    "cliente_defecto_id": None, "columnas": 4, "vendedor": "", "fiado": True, "categorias": [], "mesas": [], "sectores": [], "plano_aspecto": "5/3",
    "destinos": {}, "modificadores": [], "saloneros": [],
}


def mesas_en_cuadricula(n: int, desde: int = 1) -> list:
    import math
    cols = max(3, min(10, math.ceil(math.sqrt(n * 5 / 3)))); filas = max(1, math.ceil(n / cols))
    w = min(12, 84 // cols); gx = (100 - cols * w) / (cols + 1); h = min(18, 88 // filas); gy = max(2, (100 - filas * h) / (filas + 1))
    out = []
    for i in range(n):
        c, f = i % cols, i // cols
        out.append({"id": desde + i, "nombre": f"Mesa {desde + i}", "x": round(gx + c * (w + gx)), "y": round(gy + f * (h + gy)), "w": w, "h": h,
                    "forma": "cuadrada", "asientos": 4, "sector_id": None, "rot": 0, "deco": False})
    return out


def plantilla_restaurante(s, eid: int, mesas: int = 6) -> bool:
    """Siembra pos_config con «Caja salón» en modo restaurante y las mesas iniciales. No toca nada si la empresa ya tiene cajas."""
    if _registro(s, eid, "pos_config") is not None:
        return False
    caja = {**TERMINAL_BASE, "id": 1, "nombre": "Caja salón", "modo": "restaurante", "servicio_pct": 10, "mesas": mesas_en_cuadricula(mesas), "cuentas": dict(TERMINAL_BASE["cuentas"])}
    reemplazar(s, eid, "pos_config", {"terminales": [caja]}, version=0)
    cuenta_efectivo_inicial(s, eid)
    return True


def cuenta_efectivo_inicial(s, eid: int) -> bool:
    """3.87: la caja (la de salón y la del comercio y el hotel nuevos) nace con dónde guardar el efectivo. Sin ninguna cuenta en Bancos, cada cobro de la caja quedaba «Sin
    cuenta para Efectivo» y el tiquete de contado con pagado 0. Se crea «Caja general» (Efectivo, colones, saldo 0) solo si la
    empresa todavía no tiene Bancos; la caja la encuentra sola por ser la de efectivo en colones (cuentas['01'] queda vacío, así
    un cambio de nombre no la desconecta). No es una fila de ejemplo: no lleva la marca ni los datos de la semilla de Bancos."""
    if _registro(s, eid, "bancos") is not None:
        return False
    from .config import ahora_cr
    reemplazar(s, eid, "bancos", [{"id": 1, "nombre": "Caja general", "tipo": "Efectivo", "moneda": "CRC", "numero": "", "saldo_inicial": 0,
                                   "fecha_saldo": ahora_cr().date().isoformat(), "descripcion": "Efectivo del negocio", "principal": False, "cuenta_contable": ""}], version=0)
    return True


def reemplazar(s, eid: int, clave: str, datos, version: Optional[int] = None) -> int:
    """Escribe el registro completo. Con `version`, solo si nadie lo cambió desde entonces (si no, ConflictoRegistro).
    version=0 significa «la clave no existe todavía»: si otro usuario ya la creó, es conflicto (no se pisa)."""
    r = _registro(s, eid, clave)
    if r is None:
        if version not in (None, 0):
            raise ConflictoRegistro(None, 0)
        r = Registro(empresa_id=eid, clave=clave, version=0); s.add(r); s.flush()
    if version is None and (r.version or 0) > 0:
        # Solo la versión anterior del navegador guarda sin versión (el registro completo, leído al abrir la pestaña):
        # reemplazarlo borraría o pisaría lo que otros cambiaron después (listas, contadores de numeración, monedas…).
        # Se pide recargar la página. Las altas nuevas de esa pestaña (id por encima de todos los usados) sí se guardan,
        # para no perder por ejemplo una compra cuya factura de compra ya salió a Hacienda.
        guardadas = descartadas = 0
        try:
            actual = None if r.coleccion else json.loads(r.datos)
        except ValueError:
            actual = None
        # colección, o lista vacía guardada como valor (la versión nueva crea así las listas vacías)
        if es_lista_ids(datos) and (r.coleccion or actual in ([], None) or es_lista_ids(actual)):
            filas = s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)).all()
            usados = {f.item_id for f in filas}
            if not r.coleccion and isinstance(actual, list):
                usados |= {_id_entero(x.get("id")) for x in actual}
            tope = max(list(usados) + [r.ultimo_id or 0, 0])
            altas = [x for x in datos if (_id_entero(x.get("id")) or 0) > tope]
            # Lo que no se guarda: si su contenido no está en el servidor (ni con su id ni con otro), es algo que la pestaña
            # tenía distinto (alta que chocó con un id ya usado, edición, o algo que otro borró): el usuario debe revisarlo.
            sin_id = lambda d: json.dumps({k: v for k, v in d.items() if k != "id"}, sort_keys=True)  # noqa: E731
            por_id = {f.item_id: json.loads(f.datos) for f in filas}
            textos = {sin_id(d) for d in por_id.values()}
            descartadas = sum(1 for x in datos if (_id_entero(x.get("id")) or 0) <= tope
                              and por_id.get(_id_entero(x.get("id"))) != x and sin_id(x) not in textos)
            if altas:
                aplicar_cambios(s, eid, clave, altas, [], [x["id"] for x in altas]); guardadas = len(altas)
        raise RecargarPagina(guardadas, descartadas)
    if version is not None and (r.version or 0) != version:
        raise ConflictoRegistro(leer(s, eid, clave), r.version or 0)
    nueva = (r.version or 0) + 1
    # actualización condicional: si otro proceso escribió entre la lectura y aquí, no afecta filas → conflicto
    res = s.execute(update(Registro).where(Registro.id == r.id, Registro.version == (r.version or 0)).values(version=nueva, actualizado=datetime.now(timezone.utc)))
    if res.rowcount != 1:
        s.rollback()
        raise ConflictoRegistro(leer(s, eid, clave), (_registro(s, eid, clave).version or 0))
    s.refresh(r)
    if r.coleccion or (es_lista_ids(datos) and datos):
        if not es_lista_ids(datos):
            raise ValueError("Esta clave guarda una lista de elementos con id")
        _escribir_coleccion(s, r, datos)
    else:
        texto = _json(datos)
        if len(texto.encode("utf-8")) > LIMITE_VALOR:
            raise ValueError(f"El registro '{clave}' supera el tamaño máximo")
        r.datos = texto
    s.add(r); s.commit()
    return nueva


def aplicar_cambios(s, eid: int, clave: str, upserts: list, deletes: list, nuevos: list, condiciones: Optional[dict] = None,
                    informe: Optional[dict] = None) -> tuple[int, dict]:
    """Altas, cambios y bajas por id en una colección.
    - Alta con un id que ya existe: si el contenido es idéntico es un reintento (respuesta perdida) y no se duplica; si no,
      otro usuario usó ese id y el alta recibe uno libre ({id_enviado: id_asignado}).
    - Cambio de un elemento que ya no existe (otro lo borró): gana el borrado, no se revive.
    - Cambios a un mismo elemento: gana el último en guardar ese elemento.
    - 4.31, solo claves con FUSIONES (pos_espera): el cambio se une con lo guardado (fus.unir); un cambio con `_fusion` a una cuenta
      ya cerrada deja lo agregado en una cuenta nueva (fus.recrear, con remap); una baja con `condiciones[str(id)]` no se borra si
      quedó algo de otro equipo (fus.cerrar). `informe` recibe {"fusionados": [id], "conservados": [id]}. `_fusion` nunca se guarda."""
    fus = FUSIONES.get(clave)
    if informe is not None:
        informe.setdefault("fusionados", []); informe.setdefault("conservados", [])
    r = _registro(s, eid, clave)
    if r is None:
        r = Registro(empresa_id=eid, clave=clave, version=0, coleccion=True, datos="[]"); s.add(r); s.flush()
    else:
        _bloquear(s, r)
    if not r.coleccion:
        try:
            actual = json.loads(r.datos)
        except ValueError:
            actual = []
        if actual in ([], {}, None) or es_lista_ids(actual):
            _escribir_coleccion(s, r, actual if isinstance(actual, list) else [])
            s.flush()
        else:
            raise ValueError("Esta clave no guarda una lista de elementos con id")
    filas = {f.item_id: f for f in s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)).all()}
    previas = set(filas)                                     # las que había antes de este lote
    nuevos_set = {_id_entero(i) for i in nuevos}
    # ids ya usados alguna vez (aunque se hayan borrado): los ids que asigna el servidor (remaps y movimientos bancarios)
    # nunca repiten uno borrado. Las altas del navegador conservan su id si está libre (los números CE-, PL-… salen de él).
    # Solo cuentan los ids del rango propio: los que llegaron sincronizados de una instalación local (u, en la local, los de la
    # nube) viven en otro rango y no deben empujar el tope ni recibir ids reasignados (3.13).
    rp = rango_propio(eid)
    propias = [i for i in filas if en_rango(i, rp)]
    ultimo = (r.ultimo_id or 0) if en_rango(r.ultimo_id or 0, rp) else rp * RANGO
    tope = max(propias + [ultimo, rp * RANGO])
    maximo = tope
    orden = max([f.orden for f in filas.values()] + [-1])
    remap, ahora = {}, datetime.now(timezone.utc)
    for x in upserts:
        if not isinstance(x, dict) or _id_entero(x.get("id")) is None:
            raise ValueError("Cada elemento necesita un id entero")
        iid = _validar_id(_id_entero(x["id"]))
        if fus is not None:                                  # 4.31: fusión de la cuenta (pos_espera), dentro del bloqueo
            if iid in nuevos_set:
                x = {k: v for k, v in x.items() if k != "_fusion"}          # las altas no se fusionan
            elif iid in filas:
                try:
                    previo = json.loads(filas[iid].datos)
                except ValueError:
                    previo = None
                x, fusiono = fus.unir(previo, x)
                if fusiono and informe is not None:
                    informe["fusionados"].append(iid)
            elif fus.fusion_valida(x):
                # cuenta ya cerrada (4.5): a la recreada de ella si ya existe (un reenvío no crea otra), o a una nueva en la mesa
                destino = None
                for i, f in filas.items():
                    try:
                        if fus.es_recreada_de(json.loads(f.datos), iid):
                            destino = i; break
                    except ValueError:
                        continue
                if destino is not None:
                    unida, _ = fus.unir(json.loads(filas[destino].datos), {**x, "id": destino})
                    f = filas[destino]; f.datos = _texto_item(unida); f.actualizado = ahora; s.add(f)
                    remap[iid] = destino
                    if informe is not None:
                        informe["fusionados"].append(destino)
                    continue
                rec = fus.recrear(x, iid, maximo + 1)
                if rec is None:
                    continue                                 # gana el borrado, como siempre
                maximo += 1; orden += 1
                f = RegistroItem(empresa_id=eid, clave=clave, item_id=maximo, orden=orden, datos=_texto_item(rec), actualizado=ahora)
                s.add(f); filas[maximo] = f
                remap[iid] = maximo
                if informe is not None:
                    informe["fusionados"].append(maximo)
                continue
            else:
                x = {k: v for k, v in x.items() if k != "_fusion"}
        texto = _texto_item(x)
        if iid in nuevos_set and iid in previas and filas.get(iid) is not None and filas[iid].datos == texto:
            continue                                        # reintento de un alta ya guardada (respuesta perdida): no duplicar
        if iid in nuevos_set and iid not in filas and (not en_rango(iid, rp) or iid > tope + SALTO_MAXIMO):
            raise ValueError("Cada elemento necesita un id entero válido")       # el navegador da ids del rango propio
        if iid in nuevos_set and (iid in filas or iid <= ultimo):
            # id que ya tiene otro elemento (de otro usuario o de otra alta de este lote), o que tuvo uno ya borrado (una
            # edición vieja de ese elemento caería sobre esta alta): recibe un id libre que nunca se usó. El navegador da
            # los ids por encima del tope (mock.nextId), así que esto solo pasa si su tope estaba desactualizado.
            maximo = max(maximo, iid) + 1
            remap[iid] = maximo; x = {**x, "id": maximo}; iid = maximo
        elif iid not in filas and iid not in nuevos_set:    # lo borró otro usuario (o el servidor): gana el borrado
            continue
        if iid in filas:
            f = filas[iid]; f.datos = _texto_item(x); f.actualizado = ahora; s.add(f)
        else:
            orden += 1
            f = RegistroItem(empresa_id=eid, clave=clave, item_id=iid, orden=orden, datos=_texto_item(x), actualizado=ahora)
            s.add(f); filas[iid] = f
        if en_rango(iid, rp):
            maximo = max(maximo, iid)
    borrados = []
    for i in deletes:
        iid = _id_entero(i)
        if iid in filas and iid not in remap.values():
            cond = condiciones.get(str(iid)) if fus is not None and isinstance(condiciones, dict) else None
            if cond is not None:                             # 4.31: baja condicional; si quedó algo de otro equipo, la cuenta sigue con eso
                try:
                    previo = json.loads(filas[iid].datos)
                except ValueError:
                    previo = None
                resto = fus.cerrar(previo, cond)
                if resto is not None:
                    f = filas[iid]; f.datos = _texto_item(resto); f.actualizado = ahora; s.add(f)
                    if informe is not None:
                        informe["conservados"].append(iid)
                    continue
            s.delete(filas.pop(iid)); borrados.append(iid)
    if borrados and al_borrar is not None:
        try:
            al_borrar(s, eid, clave, borrados)
        except Exception:  # noqa: BLE001  la lápida es un aviso; la baja no se pierde por ella
            pass
    from sqlalchemy import func
    alto = max([maximo, tope] + propias)
    s.execute(update(Registro).where(Registro.id == r.id).values(version=Registro.version + 1, actualizado=ahora,
                                                                 ultimo_id=func.max(func.coalesce(Registro.ultimo_id, 0), alto)))
    s.commit(); s.refresh(r)
    return r.version, {str(k): v for k, v in remap.items()}


def aplicar_sinc(s, eid: int, clave: str, upserts: list, vivos, rango: int) -> dict:
    """Elementos que llegan sincronizados de otra instalación (3.13): altas y cambios conservan su id (todos deben estar en el
    rango de esa instalación; los demás se ignoran) y, si viene `vivos` (los ids que esa instalación todavía tiene), los de su
    rango que ya no están se borran. No toca el tope propio de la colección."""
    r = _registro(s, eid, clave)
    if r is None:
        r = Registro(empresa_id=eid, clave=clave, version=0, coleccion=True, datos="[]"); s.add(r); s.flush()
    else:
        _bloquear(s, r)
    if not r.coleccion:
        try:
            actual = json.loads(r.datos)
        except ValueError:
            actual = []
        if actual in ([], {}, None) or es_lista_ids(actual):
            _escribir_coleccion(s, r, actual if isinstance(actual, list) else [])
            s.flush()
        else:
            raise ValueError("Esta clave no guarda una lista de elementos con id")
    filas = {f.item_id: f for f in s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)).all()}
    orden = max([f.orden for f in filas.values()] + [-1])
    ahora = datetime.now(timezone.utc)
    altas = cambios = bajas = 0
    ignorados = []
    for x in upserts:
        iid = _id_entero(x.get("id")) if isinstance(x, dict) else None
        if iid is None or not en_rango(iid, rango):
            ignorados.append(x.get("id") if isinstance(x, dict) else None); continue
        texto = _texto_item(x)
        if iid in filas:
            if filas[iid].datos != texto:
                filas[iid].datos = texto; filas[iid].actualizado = ahora; s.add(filas[iid]); cambios += 1
        else:
            orden += 1
            f = RegistroItem(empresa_id=eid, clave=clave, item_id=iid, orden=orden, datos=texto, actualizado=ahora)
            s.add(f); filas[iid] = f; altas += 1
    if vivos is not None:
        vivos_set = {_id_entero(i) for i in vivos}
        for iid, f in list(filas.items()):
            if en_rango(iid, rango) and iid not in vivos_set:
                s.delete(f); filas.pop(iid); bajas += 1
    if altas or cambios or bajas:
        s.execute(update(Registro).where(Registro.id == r.id).values(version=Registro.version + 1, actualizado=ahora))
    s.commit()
    return {"altas": altas, "cambios": cambios, "bajas": bajas, "ignorados": ignorados}


def _fecha(v):
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def aplicar_red(s, eid: int, clave: str, upserts: list, vivos, rango_emisor: int, borrados: list) -> dict:
    """Cambios que llegan de otra computadora del mismo local (3.14). Cualquier elemento, de cualquier rango: gana el último
    cambio por su fecha (`_actualizado` del emisor contra la fila propia). `vivos` son los ids del rango del emisor que
    siguen vivos allá (los demás de ese rango se borran); `borrados` son lápidas [{id, ts}] de cualquier rango (se borra si la
    fila propia es anterior). Devuelve además los ids del rango propio tocados, que hay que volver a subir a la nube."""
    r = _registro(s, eid, clave)
    if r is None:
        r = Registro(empresa_id=eid, clave=clave, version=0, coleccion=True, datos="[]"); s.add(r); s.flush()
    else:
        _bloquear(s, r)
    if not r.coleccion:
        try:
            actual = json.loads(r.datos)
        except ValueError:
            actual = []
        if actual in ([], {}, None) or es_lista_ids(actual):
            _escribir_coleccion(s, r, actual if isinstance(actual, list) else [])
            s.flush()
        else:
            raise ValueError("Esta clave no guarda una lista de elementos con id")
    rp = rango_propio(eid)
    filas = {f.item_id: f for f in s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)).all()}
    orden = max([f.orden for f in filas.values()] + [-1])
    altas = cambios = bajas = 0
    propios = []
    for x in upserts:
        if not isinstance(x, dict):
            continue
        iid = _id_entero(x.get("id"))
        if iid is None:
            continue
        cuando = _fecha(x.get("_actualizado")) or datetime.now(timezone.utc)
        x = {k: v for k, v in x.items() if k != "_actualizado"}
        texto = _texto_item(x)
        if iid in filas:
            f = filas[iid]
            if f.datos == texto:
                continue
            if (_fecha(f.actualizado) or datetime.min.replace(tzinfo=timezone.utc)) >= cuando:
                continue                                          # lo nuestro es más nuevo: gana
            f.datos = texto; f.actualizado = cuando; s.add(f); cambios += 1
        else:
            orden += 1
            s.add(RegistroItem(empresa_id=eid, clave=clave, item_id=iid, orden=orden, datos=texto, actualizado=cuando)); altas += 1
        if en_rango(iid, rp):
            propios.append(iid)
    for b in borrados or []:
        iid = _id_entero(b.get("id")) if isinstance(b, dict) else None
        ts = _fecha(b.get("ts")) if isinstance(b, dict) else None
        if iid in filas and ts and (_fecha(filas[iid].actualizado) or datetime.min.replace(tzinfo=timezone.utc)) < ts:
            s.delete(filas.pop(iid)); bajas += 1
            if en_rango(iid, rp):
                propios.append(iid)
    if vivos is not None:
        vivos_set = {_id_entero(i) for i in vivos}
        for iid, f in list(filas.items()):
            if en_rango(iid, rango_emisor) and iid not in vivos_set:
                s.delete(f); filas.pop(iid); bajas += 1
    if altas or cambios or bajas:
        s.execute(update(Registro).where(Registro.id == r.id).values(version=Registro.version + 1, actualizado=datetime.now(timezone.utc)))
    s.commit()
    return {"altas": altas, "cambios": cambios, "bajas": bajas, "propios": propios}


def _mismo_id(a, b) -> bool:
    """Ids de una sub-lista comparados como enteros si los dos lo son (2 y "2" son el mismo), si no como texto."""
    ia, ib = _id_entero(a), _id_entero(b)
    return ia == ib if ia is not None and ib is not None else str(a) == str(b)


def aplicar_elemento(s, eid: int, clave: str, iid: int, datos: Optional[dict]) -> bool:
    """4.32 (sinc_datos): escribe UN elemento de una colección con su id, sin reasignarlo. Lo usa el mecanismo nuevo para lo que llega del
    otro lado: sin FUSIONES, sin al_borrar y sin la regla de rango de las altas del navegador (aplicar_cambios). `datos=None` quita el
    elemento. Bloquea el registro antes de leer; si no existe lo crea como colección; si es un valor con lista de ids, lo pasa a colección
    como aplicar_cambios. Sube la versión y `actualizado`; `ultimo_id` sube solo con un id del rango propio. NO confirma (lo hace quien
    llama). True si cambió algo."""
    iid = _validar_id(_id_entero(iid))
    r = _registro(s, eid, clave)
    if r is None:
        if datos is None:
            return False
        r = Registro(empresa_id=eid, clave=clave, version=0, coleccion=True, datos="[]"); s.add(r); s.flush()
    else:
        _bloquear(s, r)
    cambio = False
    if not r.coleccion:
        try:
            actual = json.loads(r.datos)
        except ValueError:
            actual = []
        if actual in ([], {}, None) or es_lista_ids(actual):
            _escribir_coleccion(s, r, actual if isinstance(actual, list) else [])
            s.add(r); s.flush()
            cambio = bool(actual)
        else:
            raise ValueError("Esta clave no guarda una lista de elementos con id")
    f = s.exec(select(RegistroItem).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave, RegistroItem.item_id == iid)).first()
    ahora = datetime.now(timezone.utc)
    if datos is None:
        if f is not None:
            s.delete(f); cambio = True
    else:
        if not isinstance(datos, dict):
            raise ValueError("Cada elemento necesita un id entero")
        texto = _texto_item({**datos, "id": iid})
        if f is not None:
            if f.datos != texto:
                f.datos = texto; f.actualizado = ahora; s.add(f); cambio = True
        else:
            orden = s.exec(select(func.max(RegistroItem.orden)).where(RegistroItem.empresa_id == eid, RegistroItem.clave == clave)).first()
            s.add(RegistroItem(empresa_id=eid, clave=clave, item_id=iid, orden=(orden if orden is not None else -1) + 1, datos=texto, actualizado=ahora))
            cambio = True
    if not cambio:
        return False
    valores = {"version": Registro.version + 1, "actualizado": ahora}
    if datos is not None and en_rango(iid, rango_propio(eid)):
        valores["ultimo_id"] = func.max(func.coalesce(Registro.ultimo_id, 0), iid)
    s.execute(update(Registro).where(Registro.id == r.id).values(**valores))
    s.expire(r, ["version", "actualizado", "ultimo_id"])
    return True


def aplicar_llave(s, eid: int, clave: str, llave: str, valor, partir: Optional[dict] = None) -> bool:
    """4.32 (sinc_datos): escribe una parte de un registro de valor que es un objeto, sin ConflictoRegistro (bloquea con _bloquear):
    - `llave` normal («152»): obj[llave] = valor; valor=None la quita.
    - «lista#id» (con `partir` = {lista: campo_id}): en obj[lista] reemplaza, agrega al final o (con None) quita el elemento con ese id.
    - «_»: reemplaza todas las llaves de primer nivel MENOS las listas de `partir` por las de `valor` (un objeto).
    Crea el registro de valor si falta y `valor` no es None; sube la versión. NO confirma. True si cambió algo."""
    r = _registro(s, eid, clave)
    if r is None:
        if valor is None:
            return False
        r = Registro(empresa_id=eid, clave=clave, version=0, coleccion=False, datos="{}"); s.add(r); s.flush()
    else:
        _bloquear(s, r)
    if r.coleccion:
        raise ValueError("Esta clave guarda una lista de elementos con id")
    try:
        obj = json.loads(r.datos)
    except ValueError:
        obj = {}
    if obj in ([], None):
        obj = {}
    if not isinstance(obj, dict):
        raise ValueError("Esta clave no guarda un objeto")
    partir = partir or {}
    nuevo = dict(obj)
    if llave == "_":
        if valor is not None and not isinstance(valor, dict):
            raise ValueError("El valor debe ser un objeto")
        nuevo = {k: v for k, v in (valor or {}).items() if k not in partir}
        for k in partir:
            if k in obj:
                nuevo[k] = obj[k]
    elif "#" in llave:
        lista, _, sid = llave.partition("#")
        campo = partir.get(lista)
        if not campo:
            raise ValueError("Esta parte no se puede partir")
        elems = [x for x in (obj.get(lista) or [])] if isinstance(obj.get(lista), list) else []
        pos = next((i for i, x in enumerate(elems) if isinstance(x, dict) and _mismo_id(x.get(campo), sid)), None)
        if valor is None:
            if pos is None:
                return False
            del elems[pos]
        else:
            if not isinstance(valor, dict):
                raise ValueError("Cada elemento necesita un id entero")
            if pos is None:
                elems.append(valor)
            else:
                elems[pos] = valor
        nuevo[lista] = elems
    elif valor is None:
        if llave not in obj:
            return False
        del nuevo[llave]
    else:
        nuevo[llave] = valor
    if nuevo == obj:
        return False
    texto = _json(nuevo)
    if len(texto.encode("utf-8")) > LIMITE_VALOR:
        raise ValueError(f"El registro '{clave}' supera el tamaño máximo")
    r.datos = texto; r.version = (r.version or 0) + 1; r.actualizado = datetime.now(timezone.utc); s.add(r)
    return True


def migrar_registros(s) -> int:
    """Una vez por base: quita registros duplicados por (empresa, clave) y pasa a colección las listas de objetos con id."""
    from sqlalchemy import text
    n = 0
    vistos = {}
    for r in s.exec(select(Registro).order_by(Registro.actualizado.desc(), Registro.id.desc())).all():
        k = (r.empresa_id, r.clave)
        if k in vistos:
            s.delete(r); n += 1
        else:
            vistos[k] = r
    s.commit()
    s.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ux_registro_clave ON registro(empresa_id, clave)"))
    # toda clave guardada tiene versión >= 1: así «versión 0» significa siempre «la clave no existe»
    s.execute(text("UPDATE registro SET version = 1 WHERE version IS NULL OR version < 1"))
    s.commit()
    for r in list(vistos.values()):
        if r.coleccion:
            continue
        try:
            actual = json.loads(r.datos)
        except ValueError:
            continue
        if isinstance(actual, list) and actual and es_lista_ids(actual):
            try:                                            # una clave que no se pueda convertir queda como estaba (valor)
                _escribir_coleccion(s, r, actual); s.add(r); s.commit(); n += 1
            except Exception:  # noqa: BLE001
                s.rollback()
    return n


# ----------------------------------------------------------------------------- recurrentes
def _dia(anio: int, mes: int, dia: int) -> date:
    return date(anio, mes, min(max(dia or 1, 1), calendar.monthrange(anio, mes)[1]))


def _quincenas(anio: int, mes: int, d1: int, d2: int) -> list:
    return sorted({_dia(anio, mes, d1), _dia(anio, mes, d2)})


def _sumar(fecha: date, periodicidad: str, dia_emision: int, dia2: "int | None" = None) -> date:
    meses, dias = PERIODOS.get(periodicidad, (1, 0))
    if periodicidad == "quincenal" and dia2:  # dos días fijos del mes (p. ej. 15 y último) (3.30)
        sig = date(fecha.year + (fecha.month == 12), fecha.month % 12 + 1, 1)
        for c in _quincenas(fecha.year, fecha.month, dia_emision, dia2) + _quincenas(sig.year, sig.month, dia_emision, dia2):
            if c > fecha:
                return c
    if dias:
        return fecha + timedelta(days=dias)
    m = fecha.month - 1 + meses
    anio, mes = fecha.year + m // 12, m % 12 + 1
    return date(anio, mes, min(max(dia_emision or fecha.day, 1), calendar.monthrange(anio, mes)[1]))


def primera_fecha(inicio: str, periodicidad: str, dia_emision: int, desde: "date | None" = None, mes: "int | None" = None,
                  dia_semana: "int | None" = None, dia2: "int | None" = None) -> date:
    """Primera fecha programada; con `desde`, la primera igual o posterior a esa fecha (nunca hacia atrás) (R189, R190)."""
    d = _primera_fecha_base(inicio, periodicidad, dia_emision, mes, dia_semana, dia2)
    guard = 0
    while desde and d < desde and guard < 2000:
        d = _sumar(d, periodicidad, dia_emision, dia2); guard += 1
    return d


def primera_de(r, desde: "date | None" = None) -> date:
    return primera_fecha(r.inicio, r.periodicidad, r.dia_emision, desde=desde, mes=getattr(r, "mes_emision", None),
                         dia_semana=getattr(r, "dia_semana", None), dia2=getattr(r, "dia_emision2", None))


def proximas_fechas(r, n: int = 4) -> list:
    """Las primeras `n` fechas programadas desde el inicio (sin pasar del fin): vista previa del calendario (3.30)."""
    out, d = [], primera_de(r)
    fin = date.fromisoformat(r.fin) if getattr(r, "fin", None) else None
    while len(out) < n and (fin is None or d <= fin):
        out.append(d)
        d = _sumar(d, r.periodicidad, r.dia_emision, getattr(r, "dia_emision2", None))
    return out


def _primera_fecha_base(inicio: str, periodicidad: str, dia_emision: int, mes: "int | None" = None,
                        dia_semana: "int | None" = None, dia2: "int | None" = None) -> date:
    d = date.fromisoformat(inicio)
    if periodicidad == "semanal" and dia_semana is not None:      # el primer <día de la semana> desde el inicio (3.30)
        return d + timedelta(days=(int(dia_semana) - d.weekday()) % 7)
    if periodicidad == "quincenal" and dia2:                      # el primero de los dos días del mes desde el inicio (3.30)
        return _sumar(d - timedelta(days=1), periodicidad, dia_emision, dia2)
    meses = PERIODOS.get(periodicidad, (1, 0))[0]
    if meses > 1 and mes:                                         # el ciclo arranca en el mes elegido (anual: ese mes cada año) (3.30)
        for k in range(0, 25):
            m = d.month - 1 + k
            anio, mm = d.year + m // 12, m % 12 + 1
            if (mm - int(mes)) % meses == 0:
                c = _dia(anio, mm, dia_emision or 1)
                if c >= d:
                    return c
    if PERIODOS.get(periodicidad, (1, 0))[0] and dia_emision:
        candidata = date(d.year, d.month, min(dia_emision, calendar.monthrange(d.year, d.month)[1]))
        return candidata if candidata >= d else _sumar(candidata, periodicidad, dia_emision)
    return d


def procesar_recurrentes(s, empresa_id: int, hoy: date) -> int:
    """Crea las facturas pendientes cuya fecha programada ya llegó (una por fecha). Devuelve cuántas creó."""
    creadas = 0
    for r in s.exec(select(Recurrente).where(Recurrente.empresa_id == empresa_id, Recurrente.activa == True)).all():  # noqa: E712
        if not r.inicio:
            continue
        prox = date.fromisoformat(r.proxima) if r.proxima else primera_de(r)
        fin = date.fromisoformat(r.fin) if r.fin else None
        guard = 0
        while prox <= hoy and (fin is None or prox <= fin) and guard < 400:
            iso = prox.isoformat()
            existe = s.exec(select(FacturaPendiente).where(FacturaPendiente.recurrente_id == r.id,
                                                           (FacturaPendiente.periodo == iso) | (FacturaPendiente.fecha_programada == iso))).first()
            if not existe:
                s.add(FacturaPendiente(empresa_id=empresa_id, recurrente_id=r.id, fecha_programada=iso, periodo=iso))
                creadas += 1
            prox = _sumar(prox, r.periodicidad, r.dia_emision, r.dia_emision2)
            guard += 1
        if fin is not None and prox > fin:
            r.activa = False                 # terminó su vigencia
        r.proxima = prox.isoformat()
        s.add(r)
    s.commit()
    return creadas


def recurrente_dict(r: Recurrente) -> dict:
    d = r.model_dump()
    d["lineas"] = json.loads(r.lineas or "[]")
    return d


def pago_dict(p: Pago) -> dict:
    d = p.model_dump()
    d["facturas"] = json.loads(p.facturas or "[]")
    d["documentos"] = json.loads(p.documentos or "[]")
    return d


def aplicar_pago(s, empresa_id: int, facturas: list[dict], signo: int = 1) -> None:
    """Suma (signo=1) o resta (signo=-1) los montos aplicados en Documento.pagado."""
    for f in facturas:
        d = s.get(Documento, int(f["id"]))
        if d and d.empresa_id == empresa_id:
            d.pagado = round(max(0.0, (d.pagado or 0) + signo * float(f["monto"])), 2)
            s.add(d)


def saldo_documento(d) -> float:
    """Lo que falta cobrar de una factura: total − cobros − notas de crédito aceptadas (nunca negativo)."""
    return round(max(0.0, float(d.total or 0) - float(d.pagado or 0) - float(getattr(d, "acreditado", 0) or 0)), 2)


def recalcular_acreditado(s, eid: int, clave: Optional[str] = None) -> int:
    """Recalcula Documento.acreditado de la factura con esa clave (o de todas las que tienen notas): suma de las notas de
    crédito (03) ACEPTADAS por Hacienda (o internas, sin facturación electrónica: 3.87) que la referencian, del mismo ambiente, convertidas a la moneda de la factura con los
    tipos de cambio de ambos comprobantes. Se recalcula desde cero (no se acumula), así que repetirlo no cambia nada."""
    q = select(Documento).where(Documento.empresa_id == eid, Documento.tipo_documento == "03", Documento.referencia_clave != None)  # noqa: E711
    if clave:
        q = q.where(Documento.referencia_clave == clave)
    notas = s.exec(q).all()
    por_clave: dict = {}
    for nc in notas:                                   # agrupadas una vez (antes cada factura recorría todas las notas)
        por_clave.setdefault(nc.referencia_clave, []).append(nc)
    claves = {clave} if clave else set(por_clave)
    facturas = {f.clave: f for f in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave.in_(list(claves)))).all()} if claves else {}
    n = 0
    for c in claves:
        f = facturas.get(c)
        if f is None or f.tipo_documento == "03":
            continue
        total = 0.0
        for nc in por_clave.get(c, []):
            if nc.estado not in ("aceptado", "interno") or nc.ambiente != f.ambiente:   # 3.87: la interna (sin facturación electrónica) también rebaja
                continue
            monto = float(nc.total or 0)
            if (nc.moneda or "CRC") != (f.moneda or "CRC"):
                monto = monto * float(nc.tipo_cambio or 1) / float(f.tipo_cambio or 1)
            total += monto
        total = round(total, 2)
        if abs((f.acreditado or 0) - total) > 0.004:
            f.acreditado = total; s.add(f); n += 1
    if n:
        s.commit()
    return n


def rellenar_referencias(s, xml_dir) -> int:
    """Notas de crédito y débito emitidas antes de guardar la clave de referencia: se lee del XML una vez y se recalcula lo
    acreditado de sus facturas (para que una factura anulada con nota de crédito deje de aparecer por cobrar)."""
    from lxml import etree
    n = 0
    for d in s.exec(select(Documento).where(Documento.tipo_documento.in_(("02", "03")), Documento.referencia_clave == None)).all():  # noqa: E711
        if not d.xml_nombre:
            continue
        try:
            ref = etree.fromstring((xml_dir / d.xml_nombre).read_bytes()).findtext(".//{*}InformacionReferencia/{*}Numero")
        except Exception:  # noqa: BLE001
            continue
        if ref and len(ref.strip()) == 50:
            d.referencia_clave = ref.strip(); s.add(d); n += 1
    if n:
        s.commit()
    for eid in {d.empresa_id for d in s.exec(select(Documento).where(Documento.tipo_documento == "03")).all()}:
        recalcular_acreditado(s, eid)
    return n


def reponer_pendientes(s) -> int:
    """Facturas pendientes que quedaron en 'emitiendo' sin documento (proceso interrumpido) vuelven a 'pendiente'."""
    from sqlalchemy import text
    r = s.execute(text("UPDATE facturapendiente SET estado = 'pendiente' WHERE estado = 'emitiendo' AND documento_id IS NULL"))
    if r.rowcount:
        s.commit()
    return r.rowcount


def migrar_secuencias(s, ambiente: str) -> int:
    """Secuencias de versiones anteriores (sin ambiente): pasan al ambiente actual de la empresa. Desde la 1.14 cada ambiente
    lleva su serie, así que cambiar entre pruebas y producción no reinicia ni pisa la numeración fijada a mano."""
    from sqlalchemy import text
    r = s.execute(text("UPDATE secuencia SET ambiente = :a WHERE ambiente = '' OR ambiente IS NULL"), {"a": ambiente})
    if r.rowcount:
        s.commit()
    return r.rowcount


def corregir_tipo_servicio(s) -> int:
    """Servicios importados por CSV que quedaron con tipo 'Producto' (el importador no mandaba el tipo): al editarlos pasaban
    a mercancía y Hacienda recibía el monto en TotalMercancias. Se corrigen una vez por arranque."""
    from .db import Producto
    n = 0
    for p in s.exec(select(Producto).where(Producto.es_servicio == True, Producto.tipo == "Producto")).all():  # noqa: E712
        p.tipo = "Servicio"; p.inventariable = False; s.add(p); n += 1
    if n:
        s.commit()
    return n


def corregir_unidades(s, unidades: frozenset) -> int:
    """Productos guardados con unidades en minúscula de versiones anteriores ('g', 'm', 'd'): se pasan a la unidad oficial
    (Hacienda distingue mayúsculas y rechazaba el comprobante). Una sola vez por arranque; solo toca los que no coinciden."""
    from sqlalchemy import or_
    from .db import Producto
    por_minuscula = {u.lower(): u for u in unidades}
    n = 0
    for p in s.exec(select(Producto)).all():
        u = p.unidad_medida or ""
        if u in unidades:
            continue
        nueva = por_minuscula.get(u.lower()) or ("Unid" if not u else None)
        if nueva:
            p.unidad_medida = nueva; s.add(p); n += 1
    if n:
        s.commit()
    return n




def rellenar_tipo_cambio(s, xml_dir) -> int:
    """Comprobantes en otra moneda emitidos antes de existir la columna tipo_cambio: se lee del XML una vez (consolidación en colones)."""
    from lxml import etree
    n = 0
    for d in s.exec(select(Documento).where(Documento.moneda != "CRC")).all():
        if (d.tipo_cambio or 1) != 1 or not d.xml_nombre:
            continue
        try:
            tc = etree.fromstring((xml_dir / d.xml_nombre).read_bytes()).findtext(".//{*}ResumenFactura/{*}CodigoTipoMoneda/{*}TipoCambio")
        except Exception:  # noqa: BLE001
            continue
        if tc:
            d.tipo_cambio = float(tc); s.add(d); n += 1
    if n:
        s.commit()
    return n


def rellenar_condicion_venta(s, xml_dir) -> int:
    """Comprobantes emitidos antes de existir la columna condicion_venta: se lee del XML una sola vez (para saber si procede REP)."""
    from lxml import etree
    n = 0
    for d in s.exec(select(Documento).where(Documento.condicion_venta == None)).all():  # noqa: E711
        if not d.xml_nombre:
            continue
        try:
            cond = etree.fromstring((xml_dir / d.xml_nombre).read_bytes()).findtext("{*}CondicionVenta")
        except Exception:  # noqa: BLE001
            continue
        if cond:
            d.condicion_venta = cond; s.add(d); n += 1
    if n:
        s.commit()
    return n


def cuenta_banco(s, eid: int, cuenta: str) -> Optional[dict]:
    """La cuenta de Bancos con ese nombre, o None si es un nombre genérico (sin cuenta creada)."""
    return next((x for x in (leer(s, eid, "bancos", []) or []) if isinstance(x, dict) and x.get("nombre") == cuenta), None)


def convertir_a_cuenta(monto: float, moneda: Optional[str], tipo_cambio, moneda_cuenta: Optional[str]) -> tuple[float, dict]:
    """Monto expresado en la moneda de la cuenta. Si el documento está en otra moneda y la cuenta en colones, se convierte
    con el tipo de cambio del documento (colones por unidad). Otras combinaciones (colones a una cuenta en dólares, dólares a
    una en euros) no se pueden convertir con ese dato: ValueError con el mensaje para el usuario. Devuelve (monto, origen):
    origen trae moneda, monto y tipo de cambio del documento cuando hubo conversión."""
    import math
    mc = (moneda_cuenta or "CRC").upper()
    md = (moneda or mc).upper()
    if md == mc:
        return round(float(monto), 2), {}
    if mc == "CRC":
        try:
            tc = float(tipo_cambio or 0)
        except (TypeError, ValueError):
            tc = 0
        if not math.isfinite(tc) or tc <= 0 or tc == 1:
            raise ValueError(f"Falta el tipo de cambio de {md} para registrarlo en una cuenta en colones")
        return round(float(monto) * tc, 2), {"moneda_origen": md, "monto_origen": round(float(monto), 2), "tipo_cambio": tc}
    raise ValueError(f"La cuenta está en {mc} y el movimiento en {md}: elija una cuenta en {md} o en colones")


def validar_cuenta_moneda(s, eid: int, cuenta: str, moneda: Optional[str], tipo_cambio) -> None:
    """ValueError si el dinero no se puede registrar en esa cuenta por su moneda (antes de crear el cobro o el pago)."""
    b = cuenta_banco(s, eid, cuenta)
    if b is not None:
        convertir_a_cuenta(1.0, moneda, tipo_cambio, b.get("moneda") or "CRC")


def registrar_movimiento_banco(s, eid: int, cuenta: str, monto: float, fecha: str, descripcion: str, ref: str, reemplazar: bool = False,
                               moneda: Optional[str] = None, tipo_cambio=None) -> bool:
    """Agrega el movimiento (+ entrada, − salida) en la cuenta de Bancos con ese nombre. Idempotente por `ref`; con
    reemplazar=True un movimiento con esa ref se sustituye (otra cuenta, monto o fecha). Si la cuenta no existe en Bancos
    (nombre genérico), no hace nada. `moneda`/`tipo_cambio` son los del documento: el monto se pasa a la moneda de la cuenta
    (antes un cobro de $100 en una cuenta en colones sumaba ₡100); si no se puede, ValueError."""
    import math
    from sqlalchemy.exc import IntegrityError
    from sqlalchemy.orm.exc import StaleDataError
    b = cuenta_banco(s, eid, cuenta)
    if not b or not monto or not math.isfinite(float(monto)):
        return False
    monto, origen = convertir_a_cuenta(float(monto), moneda, tipo_cambio, b.get("moneda") or "CRC")
    if origen:
        descripcion = f"{descripcion} ({origen['moneda_origen']} {abs(origen['monto_origen']):,.2f} × {origen['tipo_cambio']:,.2f})"
    if not monto:
        return False
    for intento in range(3):              # otro proceso dio el mismo id nuevo a la vez: se vuelve a leer y se reintenta
        try:
            # lectura y escritura en la misma transacción con el bloqueo tomado: dos reemplazos de la misma ref no dejan dos.
            # Primer movimiento de la empresa: se crea el registro (eso ya toma el bloqueo; si otro lo crea a la vez, reintento).
            r = _registro(s, eid, "movimientos")
            if r is None:
                r = Registro(empresa_id=eid, clave="movimientos", version=0, coleccion=True, datos="[]"); s.add(r); s.flush()
            else:
                _bloquear(s, r)
            movs = leer(s, eid, "movimientos", []) or []
            previos = [m for m in movs if isinstance(m, dict) and m.get("ref") == ref] if isinstance(movs, list) else []
            if not isinstance(movs, list) or (previos and not reemplazar):
                s.rollback()              # suelta el bloqueo
                return False
            # 4.9: el id sale del rango propio. En una instalación local vinculada salía 1 (o el mayor de otro rango), aplicar_cambios
            # lo rechazaba por estar fuera de su rango y el cobro quedaba sin su movimiento en Bancos
            rp, ult = rango_propio(eid), r.ultimo_id or 0
            nuevo = max([i for i in (_id_entero(m.get("id")) for m in movs if isinstance(m, dict)) if i is not None and en_rango(i, rp)]
                        + [ult if en_rango(ult, rp) else 0, rp * RANGO]) + 1
            aplicar_cambios(s, eid, "movimientos", [{"id": nuevo, "banco_id": b.get("id"), "fecha": fecha, "descripcion": descripcion,
                                                     "monto": round(float(monto), 2), "conciliado": False, "ref": ref, **origen}],
                            [m.get("id") for m in previos], [nuevo])
            return True
        except (IntegrityError, StaleDataError):
            s.rollback()
            if intento == 2:
                raise
        except Exception:
            s.rollback()
            raise
    return False


def quitar_movimientos_banco(s, eid: int, ref) -> int:
    refs = {ref} if isinstance(ref, str) else set(ref)
    r = _registro(s, eid, "movimientos")
    if r is None:
        return 0
    _bloquear(s, r)
    movs = leer(s, eid, "movimientos", []) or []
    ids = [m.get("id") for m in movs if isinstance(m, dict) and m.get("ref") in refs]
    if ids:
        aplicar_cambios(s, eid, "movimientos", [], ids, [])
    else:
        s.rollback()                      # nada que quitar: se suelta el bloqueo
    return len(ids)
