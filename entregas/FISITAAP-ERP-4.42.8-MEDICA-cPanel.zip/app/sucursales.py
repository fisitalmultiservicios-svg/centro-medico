"""Sucursales dentro de una misma empresa (3.66).

Una sola cuenta y una sola cédula; cada sucursal con su código de Hacienda (001, 002…), su bodega, sus cajas y su gente.
- Se comparten catálogo, precios, clientes, contabilidad, bancos, RRHH y la configuración general.
- Es propio de cada sucursal: el consecutivo de Hacienda (la clave lleva el código de sucursal y la numeración es por
  sucursal), las cajas marcadas con la sucursal (pos_config.terminales[].sucursal_id), la bodega que rebaja al vender
  (Sucursal.bodega_id) y los usuarios amarrados a ella (UsuarioEmpresa.sucursal_id).
- La empresa que ya existe pasa a ser la sucursal principal (código = Empresa.sucursal) sin tocar nada.
- La sucursal activa de una petición: la fija del usuario (membresía) manda; si no tiene, la cabecera X-Sucursal (el
  selector de la barra); sin nada = todas (consolidado): se emite con la principal y se ve todo.
- Las sucursales adicionales son un extra del plan («sucursales»), salvo sin plan, prueba gratis o demo.
- 3.82: cada sucursal puede llevar su marca (logo y nombre comercial, Sucursal.marca_id): lo que se emite en ella sale con
  esa marca si no se elige otra. Sin marca = la predeterminada. Sin sucursal activa (Todas) se emite con la principal.
"""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from .auth import Contexto, UsuarioEmpresa, contexto, requiere, sesion_empresa
from .config import ahora_cr
from .db import Documento, por_empresa

router = APIRouter(prefix="/api/sucursales", tags=["sucursales"])


class Sucursal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    codigo: int = 1                              # código de sucursal de Hacienda (3 dígitos del consecutivo)
    nombre: str
    direccion: Optional[str] = None
    telefono: Optional[str] = None
    bodega_id: Optional[int] = None              # bodega que rebajan las ventas de esta sucursal (vacío = la principal)
    marca_id: Optional[int] = None               # 3.82: marca con que salen sus comprobantes (vacío = la predeterminada)
    principal: bool = False
    activa: bool = True
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


por_empresa(Sucursal)


class SucursalIn(BaseModel):
    codigo: int = PField(ge=1, le=999)
    nombre: str = PField(min_length=2, max_length=80)
    direccion: Optional[str] = PField(None, max_length=250)
    telefono: Optional[str] = PField(None, max_length=20)
    bodega_id: Optional[int] = None
    marca_id: Optional[int] = None
    activa: bool = True


def listar(s: Session, eid: int) -> list[Sucursal]:
    return list(s.exec(select(Sucursal).where(Sucursal.empresa_id == eid).order_by(Sucursal.principal.desc(), Sucursal.codigo)).all())


def asegurar_principal(s: Session, e) -> Sucursal:
    """La sucursal principal existe desde que la empresa usa sucursales: hereda el código de Empresa.sucursal."""
    p = s.exec(select(Sucursal).where(Sucursal.empresa_id == e.id, Sucursal.principal == True)).first()  # noqa: E712
    if p is None:
        p = Sucursal(empresa_id=e.id, codigo=int(getattr(e, "sucursal", 1) or 1), nombre="Principal", principal=True, activa=True)
        s.add(p); s.commit(); s.refresh(p)
    return p


def por_id(s: Session, eid: int, sid) -> Optional[Sucursal]:
    try:
        sid = int(sid)
    except (TypeError, ValueError):
        return None
    x = s.get(Sucursal, sid)
    return x if x is not None and x.empresa_id == eid and x.activa else None


def _de_la_empresa(s: Session, eid: int, sid) -> Optional[Sucursal]:
    """La sucursal de la empresa aunque esté desactivada (3.87)."""
    try:
        x = s.get(Sucursal, int(sid))
    except (TypeError, ValueError):
        return None
    return x if x is not None and x.empresa_id == eid else None


def resolver(s: Session, eid: int, cabecera: Optional[str], fija: Optional[int]) -> Optional[Sucursal]:
    """Sucursal activa de la petición: la fija de la membresía manda; si no, la cabecera X-Sucursal; si no, None (todas).
    3.87: la fija manda aunque esté desactivada: el usuario sigue limitado a ella (consulta lo suyo, pero no emite) hasta que lo
    reasignen. Antes quedaba sin sucursal: veía las de todas y emitía con la principal y su bodega."""
    if fija:
        return _de_la_empresa(s, eid, fija)
    if cabecera and str(cabecera).strip().isdigit():
        return por_id(s, eid, int(cabecera))
    return None


def pertenece(d, suc: Sucursal) -> bool:
    """Un comprobante (objeto o dict, 3.72) es de la sucursal si lo dice su columna o, en los anteriores a 3.66, por el código en el consecutivo."""
    g = d.get if isinstance(d, dict) else (lambda k, v=None: getattr(d, k, v))
    if g("sucursal_id"):
        return g("sucursal_id") == suc.id
    cons = g("consecutivo") or ""
    return bool(cons) and cons[:3] == f"{suc.codigo:03d}"


def filtrar(docs: list, suc: Optional[Sucursal]) -> list:
    return [d for d in docs if pertenece(d, suc)] if suc else list(docs)


def marca_de(s: Session, eid: int, suc: Optional[Sucursal]):
    """3.82: la marca de la sucursal que emite (sin sucursal activa, la principal) si existe y está activa; None = la predeterminada."""
    from .marcas import marca_de as _marca
    x = suc if suc is not None else s.exec(select(Sucursal).where(Sucursal.empresa_id == eid, Sucursal.principal == True)).first()  # noqa: E712
    m = _marca(s, eid, getattr(x, "marca_id", None)) if x is not None else None
    return m if m is not None and m.activa else None


def _validar_marca(s: Session, eid: int, marca_id) -> None:
    if marca_id:
        from .marcas import validar_marca
        validar_marca(s, eid, marca_id, "la sucursal")


def resumen_sesion(s_central: Session, eid: int, membresia: Optional[UsuarioEmpresa]) -> dict:
    """Lo que la sesión necesita para el selector: sucursales activas (si la empresa las usa) y la fija del usuario."""
    from .db import engine_empresa
    fija = getattr(membresia, "sucursal_id", None) if membresia else None
    try:
        with Session(engine_empresa(eid)) as se:
            todas = listar(se, eid)
    except Exception:  # noqa: BLE001  (base aún no creada o similar: sin sucursales)
        todas = []
    lista = [x for x in todas if x.activa or x.id == fija]   # 3.87: la fija aunque esté desactivada (la barra la sigue mostrando)
    # 4.34: el código de la fija (3 dígitos, el de sus consecutivos) también cuando la lista sale vacía (una sola sucursal activa): con él
    # Punto de venta › Ventas de caja ofrece ver e imprimir solo lo que _documento_ctx le abre (sucursales.pertenece)
    codigo_fija = next((f"{x.codigo:03d}" for x in todas if fija and x.id == fija), None)
    if len(lista) <= 1:
        lista = []
    # 3.87: con su bodega, para que la caja y la factura propongan la de la sucursal (antes la principal)
    return {"sucursales": [{"id": x.id, "codigo": x.codigo, "nombre": x.nombre, "principal": x.principal, "marca_id": x.marca_id, "bodega_id": x.bodega_id,
                            "activa": x.activa} for x in lista],
            "sucursal_fija": fija, "sucursal_fija_codigo": codigo_fija}


def _dict(x: Sucursal) -> dict:
    return x.model_dump()


# ----------------------------------------------------------------------------- rutas
@router.get("")
def get_sucursales(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    asegurar_principal(s, ctx.empresa)
    activa = ctx.sucursal
    return {"sucursales": [_dict(x) for x in listar(s, ctx.empresa.id)], "activa": activa.id if activa else None,
            "fija": bool(activa) and getattr(ctx, "sucursal_fija", False)}


@router.post("")
def crear_sucursal(data: SucursalIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    from . import planes
    e = ctx.empresa
    asegurar_principal(s, e)
    if "sucursales" not in planes.modulos_de(e):
        raise HTTPException(400, "Las sucursales adicionales son un extra del plan: pídalo en Configuración › Suscripción y planes")
    if any(x.codigo == data.codigo for x in listar(s, e.id)):
        raise HTTPException(400, f"Ya hay una sucursal con el código {data.codigo:03d}")
    if data.bodega_id:
        from . import inventario
        inventario._bodega_activa(s, e.id, data.bodega_id)
    _validar_marca(s, e.id, data.marca_id)
    x = Sucursal(empresa_id=e.id, codigo=data.codigo, nombre=data.nombre.strip(), direccion=(data.direccion or "").strip() or None,
                 telefono=(data.telefono or "").strip() or None, bodega_id=data.bodega_id, marca_id=data.marca_id or None, activa=data.activa)
    s.add(x); s.commit(); s.refresh(x)
    return _dict(x)


@router.put("/{sid}")
def editar_sucursal(sid: int, data: SucursalIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    x = s.get(Sucursal, sid)
    if x is None or x.empresa_id != e.id:
        raise HTTPException(404, "Sucursal no encontrada")
    if any(o.codigo == data.codigo and o.id != x.id for o in listar(s, e.id)):
        raise HTTPException(400, f"Ya hay una sucursal con el código {data.codigo:03d}")
    if x.principal and not data.activa:
        raise HTTPException(400, "La sucursal principal no se desactiva")
    if data.bodega_id:
        from . import inventario
        inventario._bodega_activa(s, e.id, data.bodega_id)
    _validar_marca(s, e.id, data.marca_id)
    if x.codigo != data.codigo and s.exec(select(Documento.id).where(Documento.empresa_id == e.id, Documento.sucursal_id == x.id)).first():
        raise HTTPException(400, "Esta sucursal ya emitió comprobantes con su código; no se puede cambiar")
    x.codigo, x.nombre, x.direccion, x.telefono, x.bodega_id, x.activa = data.codigo, data.nombre.strip(), (data.direccion or "").strip() or None, (data.telefono or "").strip() or None, data.bodega_id, data.activa
    x.marca_id = data.marca_id or None
    s.add(x); s.commit(); s.refresh(x)
    if x.principal:                                                  # el código de la principal es el de la empresa (consecutivos sin sucursal activa)
        e.sucursal = x.codigo
        _guardar_codigo_principal(e.id, x.codigo)
    return _dict(x)


def _central():
    from .db import engine
    return Session(engine)


def _guardar_codigo_principal(eid: int, codigo: int) -> None:
    from .db import Empresa
    with _central() as sc:
        e = sc.get(Empresa, eid)
        if e is not None and e.sucursal != codigo:
            e.sucursal = codigo; sc.add(e); sc.commit()


@router.delete("/{sid}")
def borrar_sucursal(sid: int, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    x = s.get(Sucursal, sid)
    if x is None or x.empresa_id != e.id:
        raise HTTPException(404, "Sucursal no encontrada")
    if x.principal:
        raise HTTPException(400, "La sucursal principal no se elimina")
    if s.exec(select(Documento.id).where(Documento.empresa_id == e.id, Documento.sucursal_id == x.id)).first():
        raise HTTPException(400, "Esta sucursal ya emitió comprobantes: desactívela en vez de eliminarla")
    with _central() as sc:
        for m in sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.empresa_id == e.id, UsuarioEmpresa.sucursal_id == x.id)).all():
            m.sucursal_id = None; sc.add(m)
        sc.commit()
    s.delete(x); s.commit()
    return {"ok": True}


@router.get("/ventas")
def ventas_por_sucursal(desde: Optional[str] = None, hasta: Optional[str] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Ventas del período por sucursal (en colones, con el tipo de cambio de cada comprobante): para Reportes › Ventas por sucursal."""
    from . import resumen
    if not (ctx.puede("reportes") or ctx.puede("ver_todo")):
        raise HTTPException(403, "Su rol no tiene acceso a los reportes")
    e = ctx.empresa
    try:
        d1, d2, _, _ = resumen.rango("rango", ahora_cr().date(), desde or "2000-01-01", hasta or ahora_cr().date().isoformat())
    except ValueError:
        raise HTTPException(400, "Fechas inválidas (use AAAA-MM-DD)")
    lista = listar(s, e.id)
    fija = ctx.sucursal if getattr(ctx, "sucursal_fija", False) else None   # 3.87: el amarrado a una sucursal solo ve la suya (como /api/resumen y la lista)
    if fija is not None:
        lista = [x for x in lista if x.id == fija.id]
    filas = {x.id: {"id": x.id, "codigo": f"{x.codigo:03d}", "sucursal": x.nombre, "documentos": 0, "subtotal": 0.0, "impuesto": 0.0, "total": 0.0} for x in lista}
    otras = {"id": 0, "codigo": "—", "sucursal": "Sin sucursal", "documentos": 0, "subtotal": 0.0, "impuesto": 0.0, "total": 0.0}
    docs = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente)).all()
    for d in docs:
        if d.tipo_documento not in resumen.VENTAS and d.tipo_documento != "03":
            continue
        if (d.estado or "") in resumen.EXCLUIR_ESTADOS or not (d1 <= (d.fecha_emision or "")[:10] <= d2):
            continue
        if fija is not None and not pertenece(d, fija):
            continue
        fila = next((filas[x.id] for x in lista if pertenece(d, x)), otras)
        sg = -1 if d.tipo_documento == "03" else 1
        tc = float(d.tipo_cambio or 1) if (d.moneda or "CRC") != "CRC" else 1.0
        total = sg * float(d.total or 0) * tc
        imp = sg * float(d.impuesto or 0) * tc
        fila["documentos"] += 1
        fila["total"] = round(fila["total"] + total, 2)
        fila["impuesto"] = round(fila["impuesto"] + imp, 2)
        fila["subtotal"] = round(fila["subtotal"] + total - imp - sg * float(d.otros_impuestos or 0) * tc, 2)
    out = [f for f in filas.values()] + ([otras] if otras["documentos"] else [])
    return {"desde": d1, "hasta": d2, "filas": out}
