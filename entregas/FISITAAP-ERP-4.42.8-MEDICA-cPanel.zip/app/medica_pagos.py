"""Pago web con la cuenta Tilopay del negocio y conciliación en el ERP."""
import math
from datetime import datetime
from types import SimpleNamespace
from typing import Annotated
from urllib.parse import urlsplit
from uuid import uuid4

from fastapi import Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, text
from sqlmodel import Field as Col, SQLModel

from . import modulos, pagos_online, pedidos
from .config import URL_PUBLICA
from .db import por_empresa, sesion_de
from .medica import Base, Central, Cita, Recepcion, _ahora, _evento, router
from .medica_portal import _empresa, _paciente, _registro_portal, portal
from .medica_servicios import Cargo, _cargo, _documento


class PagoWeb(SQLModel, table=True):
    __tablename__ = "medica_pago_web"
    cargo_id: int = Col(primary_key=True)
    documento_id: int
    orden: str = Col(unique=True)
    monto: float
    estado: str
    url: str | None = None
    referencia: str | None = None
    pago_id: int | None = None
    creado: datetime = Col(sa_type=DateTime)


por_empresa(PagoWeb)


def _tilopay(s, e):
    negocio = pedidos._negocio_sin_crear(s, e.id)
    cred = pagos_online.credenciales(e, negocio) if negocio else None
    if not cred:
        raise HTTPException(409, "Configure Tilopay en Ventas en línea para habilitar el pago web")
    return cred


def _url_https(url):
    if not url:
        return False
    try:
        partes = urlsplit(url)
        return partes.scheme == "https" and bool(partes.hostname) and not partes.username and not partes.password
    except ValueError:
        return False


def _visible(s, paciente, cargo_id, eid):
    cargo = s.get(Cargo, cargo_id)
    cita = s.get(Cita, cargo.cita_id) if cargo and not cargo.privado_portal else None
    d = _documento(s, eid, cargo) if cita and cita.paciente_id == paciente.id and cita.sede == paciente.sede else None
    if not d or d.cliente_id != paciente.cliente_id:
        raise HTTPException(404, "Comprobante no disponible")
    return d


def _saldado(d):
    return round(modulos.saldo_documento(d), 2) <= 0


@portal.post("/api/medica/portal/{eid}/facturas/{cargo_id}/pagar")
def iniciar(eid: int, cargo_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    if not _url_https(URL_PUBLICA):
        raise HTTPException(409, "Configure FE_URL_PUBLICA con la URL HTTPS del ERP")
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        p = _paciente(s, eid, x_medica_portal)
        d = _visible(s, p, cargo_id, eid)
        monto = round(modulos.saldo_documento(d), 2)
        if d.estado not in {"aceptado", "interno"} or d.condicion_venta != "02" or d.moneda != "CRC" or monto <= 0:
            raise HTTPException(409, "El pago web aplica a facturas a crédito vigentes con saldo en colones")
        intento = s.get(PagoWeb, cargo_id)
        if intento:
            if intento.estado == "pendiente" and intento.url and intento.monto == monto:
                return {"url": intento.url}
            raise HTTPException(409, "Ya hay una orden de pago. Consulte su estado o contacte a recepción")
        cred = _tilopay(s, e)
        if "@" not in (p.correo or ""):
            raise HTTPException(422, "Solicite a recepción que registre un correo válido")
        intento = PagoWeb(cargo_id=cargo_id, documento_id=d.id, orden=f"FM{eid}-{uuid4().hex}", monto=monto,
                          estado="solicitado", creado=_ahora())
        s.add(intento)
        datos = SimpleNamespace(nombre=d.receptor_nombre or p.nombre, direccion="", telefono=p.telefono,
                                pago_orden=intento.orden, token=uuid4().hex)
        destino = p.correo
        _registro_portal(s, p.id, "portal.pago_iniciado", cargo_id)
        s.commit()

        # Si se pierde la respuesta externa, se conserva la orden para consultarla. No se crea otra.
        url = pagos_online.iniciar_pago(cred, datos, monto, f"{URL_PUBLICA}/medica/portal/{eid}", destino)
        if not _url_https(url):
            raise HTTPException(502, "La pasarela no devolvió una dirección HTTPS")
        intento.url = url
        intento.estado = "pendiente"
        s.commit()
        return {"url": url}


def _verificar(s, e, intento):
    if intento.pago_id:
        return {"estado": "conciliado", "pago_id": intento.pago_id}
    cred = _tilopay(s, e)
    info = pagos_online.consultar(cred, intento.orden)
    if not info or not info["aprobado"]:
        return {"estado": "sin confirmación"}
    if not math.isfinite(info["monto"]) or round(info["monto"], 2) != intento.monto:
        return {"estado": "monto discrepante"}
    return {"estado": "aprobado", "referencia": info["referencia"]}


@portal.get("/api/medica/portal/{eid}/facturas/{cargo_id}/pago")
def estado(eid: int, cargo_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        d = _visible(s, p, cargo_id, eid)
        intento = s.get(PagoWeb, cargo_id)
        if not intento:
            return {"estado": "sin orden", "pagable": not _saldado(d) and d.condicion_venta == "02"}
        return _verificar(s, e, intento)


class ConciliarIn(BaseModel):
    cuenta: str = Field(default="", max_length=80)


@router.post("/cargos/{cargo_id}/conciliar")
def conciliar(cargo_id: int, data: ConciliarIn, ctx: Recepcion, s: Base):
    from .main import PagoIn, _pago_por_idempotencia, crear_pago

    ctx.exigir("cobros")
    cargo = _cargo(s, ctx, cargo_id)
    intento = s.get(PagoWeb, cargo.id)
    if not intento:
        raise HTTPException(404, "Este cargo no tiene orden de pago web")
    estado = _verificar(s, ctx.empresa, intento)
    if estado["estado"] != "aprobado":
        return estado
    s.rollback()
    s.exec(text("BEGIN IMMEDIATE"))
    intento = s.get(PagoWeb, cargo_id)
    cargo = _cargo(s, ctx, cargo_id)
    if intento.pago_id:
        return {"estado": "conciliado", "pago_id": intento.pago_id}
    idem = f"medica-tilopay:{intento.orden}"
    previo = _pago_por_idempotencia(s, ctx.empresa.id, idem)
    d = _documento(s, ctx.empresa.id, cargo)
    if not previo and (not d or d.id != intento.documento_id or d.estado not in {"aceptado", "interno"}
                       or round(modulos.saldo_documento(d), 2) < intento.monto):
        raise HTTPException(409, "Tilopay confirmó el pago, pero el saldo cambió. Revise el abono o reembolso con el proveedor")
    pago = previo or crear_pago(PagoIn(
        cliente_id=d.cliente_id, fecha=_ahora().date().isoformat(), cuenta=data.cuenta, medio_pago="02",
        monto=intento.monto, detalles="Pago web Tilopay", facturas=[{"id": d.id, "monto": intento.monto}],
        idempotencia=idem, notas=f"Orden {intento.orden}",
    ), ctx, s)
    intento.pago_id = pago["id"]
    intento.estado = "conciliado"
    intento.referencia = estado.get("referencia")
    _evento(s, ctx, "cargo.pago_conciliado", cargo_id)
    s.commit()
    return {"estado": intento.estado, "pago_id": intento.pago_id}
