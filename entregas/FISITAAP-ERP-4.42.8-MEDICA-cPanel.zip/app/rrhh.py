"""Recursos humanos (Costa Rica): tablas de referencia y cálculos de planilla, vacaciones, provisiones y liquidación.

Normativa aplicada: Código de Trabajo (art. 28 preaviso, art. 29 cesantía, art. 153 vacaciones, jornadas arts. 136-143),
Ley 2412 (aguinaldo: un doceavo de lo devengado de diciembre a noviembre), reglamentos de la CCSS (cuotas obrero y patronal),
Ley 7983 de Protección al Trabajador (FCL y ROP), Ley del Impuesto sobre la Renta art. 33 (retención a salarios por tramos
mensuales) y Decreto de salarios mínimos del MTSS (categorías genéricas).

Las tasas, tramos y salarios mínimos cambian cada año. Los valores de este archivo son de REFERENCIA para 2026 y la empresa los
ajusta en Recursos humanos › Parámetros (registro 'rrhh_parametros'); nada se calcula con una tasa que la empresa no pueda ver y
corregir. Todos los cálculos son funciones puras (probadas en tests/test_rrhh.py)."""
import csv
import io
import math
import re
import unicodedata
import zipfile
from copy import deepcopy
from calendar import monthrange
from datetime import date, datetime, timedelta
from itertools import islice

from .config import ahora_cr
from typing import Any, Optional

# ----------------------------------------------------------------------------- parámetros de referencia
PARAMETROS = {
    "vigencia": "Tasas CCSS 2026, tramos de renta del Decreto 45333-H y salarios mínimos del Decreto 45303-MTSS (2026). Si cambian, edítelos en Parámetros",     # (R305)
    # Cuota obrera (se descuenta al trabajador) 2026: SEM 5,50 % + IVM 4,33 % + Banco Popular 1,00 % = 10,83 %
    "obrero": {"sem": 5.50, "ivm": 4.33, "banco_popular": 1.00},
    # Cuota patronal 2026 (CCSS + Ley de Protección al Trabajador): SEM 9,25 + IVM 5,58 + Banco Popular 0,25 + FODESAF 5,00 + IMAS 0,50
    # + INA 1,50 + FCL 1,50 + ROP–Operadora de pensiones 2,00 + ROP–Banco Popular (LPT) 0,25 = 25,83 %; el INS (riesgos del trabajo,
    # ~1 % según la actividad) va aparte: con él, el 26,83 % que citan las tablas (R314)
    "patrono": {"sem": 9.25, "ivm": 5.58, "banco_popular": 0.25, "fodesaf": 5.00, "imas": 0.50, "ina": 1.50, "fcl": 1.50, "rop_opc": 2.00, "rop_bp": 0.25},
    "anio": 2026,                 # 3.89: año de estos valores de referencia; la planilla de otro año avisa que hay que revisarlos
    # 3.89: base mínima contributiva de la CCSS 2026 (referencia, confirmar con la CCSS). 4.7: con aplicar_base_minima las cuotas
    # SEM e IVM se calculan sobre el mayor entre el salario del período y la base de cada régimen; apagado (por defecto) solo avisa,
    # como antes, hasta que el contador confirme. La diferencia de la cuota OBRERA la paga quien diga base_minima_diferencia:
    # 'patrono' (por defecto: al trabajador no se le rebaja más que antes) o 'trabajador' (línea aparte en su colilla)
    "base_minima": {"sem": 333328, "ivm": 311990},
    "aplicar_base_minima": False, "base_minima_diferencia": "patrono",
    "ins_riesgos": 1.00,          # póliza de riesgos del trabajo del INS: % sobre la planilla según la actividad (la empresa pone el suyo)
    # 4.7: el 1 % del INS que completa el 26,83 % de las tablas, como línea propia (por confirmar con el contador). En 0 el 26,83 %
    # se completa con la póliza de riesgos de arriba, como siempre; si el contador confirma que es un cobro APARTE, se pone 1,00
    "ins_adicional": 0.0,
    "paga_ina": True,             # 4.7: la empresa que no cotiza al INA (por su actividad o tamaño) lo apaga sin tocar la tasa oficial
    # Reserva mensual recomendada sobre el salario bruto para cubrir obligaciones futuras
    "provisiones": {"aguinaldo": 8.33, "vacaciones": 4.17, "cesantia": 5.33, "preaviso": 0.0, "otros": 0.0},
    # Impuesto sobre la renta a salarios: tramos MENSUALES [límite superior, %]; el último sin límite
    # Decreto 45333-H (2026): tramos mensuales y créditos familiares
    "renta": {"tramos": [[918000, 0], [1347000, 10], [2364000, 15], [4727000, 20], [None, 25]], "credito_hijo": 1710, "credito_conyuge": 2590},
    # Jornadas ordinarias (horas por día y por semana): diurna 8/48, mixta 7/42, nocturna 6/36
    "jornadas": {"diurna": {"dia": 8, "semana": 48}, "mixta": {"dia": 7, "semana": 42}, "nocturna": {"dia": 6, "semana": 36}, "medio_tiempo": {"dia": 4, "semana": 24}},
    "dias_vacaciones_por_mes": 1.0,       # 12 días hábiles por cada 50 semanas (Código de Trabajo art. 153): un día por mes trabajado
    "hora_extra_factor": 1.5,             # tiempo y medio (art. 139)
    "feriado_factor": 2.0,                # día feriado de pago obligatorio trabajado: se paga doble (art. 152)
    "dias_mes": 30,                       # para pasar de salario mensual a diario
    # Incapacidades: lo que paga el patrono (el resto lo paga la CCSS o el INS y no es salario). Enfermedad (CCSS): el patrono
    # paga el 50 % de los primeros 3 días (art. 79 CT) y la CCSS el 60 % desde el 4.º; riesgo del trabajo (INS): el patrono
    # paga el día del accidente y el INS desde el siguiente. Maternidad (art. 95 CT): el salario COMPLETO sigue cotizando a la
    # CCSS (obrera y patronal) y cuenta para aguinaldo, vacaciones y cesantía; el patrono paga el 50 % y la CCSS el otro 50 %
    # directamente a la trabajadora, así que esa parte se descuenta del neto (no es ausencia ni subsidio no salarial).
    "incapacidad": {"enfermedad_dias_patrono": 3, "enfermedad_pct": 50.0, "riesgo_dias_patrono": 1, "riesgo_pct": 100.0, "maternidad_pct": 50.0},
    # 4.7: embargos por deudas comunes (art. 172 del Código de Trabajo, por validar con abogado): nada hasta el menor salario mínimo,
    # tramo1_pct de lo que pase de ese mínimo hasta multiplo_minimo veces y tramo2_pct de lo que pase de ahí (1/8 = 12,5 %, 1/4 = 25 %).
    # embargo_modo 'avisar' (por defecto, como antes: rebaja lo que diga el juzgado y avisa) o 'limitar' (no rebaja más que esa porción)
    "embargo": {"tramo1_pct": 12.5, "tramo2_pct": 25.0, "multiplo_minimo": 3.0}, "embargo_modo": "avisar",
    "pension_aviso_pct": 50.0,    # 4.7: la pensión alimentaria avisa cuando pasa de este % del salario después de la CCSS y la renta
    # 4.21: aprobación de la planilla antes de pagarla (de la empresa; las dos apagadas: la planilla se paga como siempre). Con la
    # primera, «Marcar pagada» exige que la planilla esté Aprobada; con la segunda, además, no la aprueba quien la generó o corrigió
    "exigir_aprobacion_planilla": False, "aprobacion_otro_usuario": False,
}
TIPOS_AUSENCIA = {"incapacidad_ccss": "Incapacidad por enfermedad (CCSS)", "incapacidad_ins": "Incapacidad por riesgo del trabajo (INS)",
                  "maternidad": "Licencia de maternidad", "permiso_sin_goce": "Permiso sin goce de salario", "injustificada": "Ausencia injustificada",
                  "permiso_con_goce": "Permiso con goce de salario"}

PERIODOS = {"semanal": 52 / 12, "bisemanal": 26 / 12, "quincenal": 2.0, "mensual": 1.0, "manual": 1.0}   # períodos de pago por mes
NOMBRE_PERIODO = {"semanal": "Semanal", "bisemanal": "Bisemanal (cada 14 días)", "quincenal": "Quincenal", "mensual": "Mensual", "manual": "Manual"}
MOTIVOS = {"despido_con": "Despido con responsabilidad patronal", "renuncia": "Renuncia", "despido_sin": "Despido sin responsabilidad patronal (causa justificada)",
           "fin_contrato": "Fin de contrato a plazo u obra", "pension_muerte": "Pensión o fallecimiento"}

# Categorías genéricas del Decreto 45303-MTSS (salarios mínimos 2026, Alcance 156 a La Gaceta 229 del 5/12/2025, rige desde el 1/1/2026;
# lista oficial mtss.go.cr/temas-laborales/salarios). Se editan en Parámetros. TESP = genérico especializado (TOEG).
CATEGORIAS = [
    {"codigo": "TONC", "nombre": "Trabajador en ocupación no calificada", "base": "dia", "monto": 12436.41},
    {"codigo": "TOSC", "nombre": "Trabajador en ocupación semicalificada", "base": "dia", "monto": 13523.69},
    {"codigo": "TOC", "nombre": "Trabajador en ocupación calificada", "base": "dia", "monto": 13991.86},
    {"codigo": "TOE", "nombre": "Trabajador en ocupación especializada", "base": "dia", "monto": 16244.50},
    {"codigo": "GNC", "nombre": "Trabajador no calificado (genérico mensual)", "base": "mes", "monto": 373092.30},
    {"codigo": "GSC", "nombre": "Trabajador semicalificado (genérico mensual)", "base": "mes", "monto": 405710.70},
    {"codigo": "GC", "nombre": "Trabajador calificado (genérico mensual)", "base": "mes", "monto": 419755.80},
    {"codigo": "TMED", "nombre": "Técnico medio de educación diversificada", "base": "mes", "monto": 496838.17},
    {"codigo": "TESP", "nombre": "Trabajador de especialización superior", "base": "mes", "monto": 487335.00},
    {"codigo": "TES", "nombre": "Técnico de educación superior", "base": "mes", "monto": 542096.58},
    {"codigo": "DES", "nombre": "Diplomado de educación superior", "base": "mes", "monto": 585484.58},
    {"codigo": "BU", "nombre": "Bachiller universitario", "base": "mes", "monto": 664078.07},
    {"codigo": "LU", "nombre": "Licenciado universitario", "base": "mes", "monto": 796921.00},
    {"codigo": "SD", "nombre": "Servicio doméstico", "base": "mes", "monto": 268731.31},
]

# Puestos frecuentes y la categoría del decreto con la que se comparan (orientación; el puesto se puede escribir libre)
PUESTOS = [
    ("Peón de construcción", "TONC"), ("Misceláneo / limpieza", "TONC"), ("Guarda de seguridad", "TOSC"), ("Camarero(a) de hotel", "TONC"),
    ("Salonero(a)", "TOSC"), ("Bartender", "TOSC"), ("Cocinero(a)", "TOC"), ("Ayudante de cocina", "TONC"), ("Recepcionista", "TOSC"),
    ("Cajero(a)", "TOSC"), ("Dependiente de tienda", "TOSC"), ("Bodeguero(a)", "TOSC"), ("Chofer de vehículo liviano", "TOSC"),
    ("Chofer de vehículo pesado", "TOC"), ("Mensajero(a)", "TONC"), ("Operario(a) de producción", "TOSC"), ("Mecánico(a) automotriz", "TOC"),
    ("Electricista", "TOC"), ("Fontanero(a)", "TOC"), ("Soldador(a)", "TOC"), ("Albañil", "TOSC"), ("Carpintero(a)", "TOC"), ("Pintor(a)", "TOSC"),
    ("Jardinero(a)", "TONC"), ("Agricultor(a) / peón agrícola", "TONC"), ("Guía turístico", "TOE"), ("Instructor(a) de surf", "TOE"),
    ("Asistente administrativo(a)", "TMED"), ("Secretario(a)", "TMED"), ("Oficinista", "TOSC"), ("Asistente contable", "TMED"),
    ("Técnico(a) en contabilidad", "TES"), ("Contador(a) (bachiller)", "BU"), ("Contador(a) (licenciado)", "LU"), ("Vendedor(a)", "TOSC"),
    ("Ejecutivo(a) de ventas", "TMED"), ("Supervisor(a)", "TOE"), ("Encargado(a) de local", "TOE"), ("Gerente / administrador(a)", "LU"),
    ("Técnico(a) en soporte informático", "TES"), ("Desarrollador(a) de software", "BU"), ("Ingeniero(a) (licenciado)", "LU"),
    ("Diseñador(a) gráfico", "DES"), ("Community manager", "DES"), ("Enfermero(a) auxiliar", "TMED"), ("Enfermero(a) (bachiller)", "BU"),
    ("Médico(a)", "LU"), ("Abogado(a)", "LU"), ("Docente / instructor(a)", "BU"), ("Estilista", "TOC"), ("Masajista", "TOC"),
    ("Trabajador(a) doméstico(a)", "SD"), ("Niñera", "SD"), ("Pescador(a)", "TONC"), ("Capitán de embarcación", "TOE"), ("Otro (escribir)", "GNC"),
]


MOTOR_VERSION = "4.7"         # 4.7: versión del motor de planilla; queda guardada con cada planilla (parametros_usados)
ANIO_SIN_MARCA = 2026         # 4.7: los parámetros que una empresa guardó antes de la 4.7 no traen el año: son de 2026
# 4.7: qué pasa con lo que guardó la empresa cuando el sistema trae los valores oficiales de un año nuevo (PARAMETROS['anio']).
# LEGALES: los fija la ley o un decreto y pueden cambiar cada año (cuotas de la CCSS y de la LPT, tramos y créditos de renta, base
# mínima, salarios mínimos, jornadas, factores de extras y feriados, días por mes y de vacaciones, fracciones del art. 172 y el aviso
# de la pensión): si se guardaron en un año anterior se ignoran, se usan los oficiales y se avisa. EMPRESA: propios de la empresa
# (póliza de riesgos del INS, INS aparte, si paga INA, reservas, lo que completa de las incapacidades y sus opciones de base mínima
# y de embargos): se conservan siempre. Una clave que no esté en CLAVES_EMPRESA se trata como legal (lo más prudente).
CLAVES_LEGALES = ("obrero", "patrono", "renta", "base_minima", "categorias", "jornadas", "hora_extra_factor", "feriado_factor", "dias_mes",
                  "dias_vacaciones_por_mes", "embargo", "pension_aviso_pct")
CLAVES_EMPRESA = ("ins_riesgos", "ins_adicional", "paga_ina", "provisiones", "incapacidad", "aplicar_base_minima", "base_minima_diferencia",
                  "embargo_modo", "exigir_aprobacion_planilla", "aprobacion_otro_usuario")   # 4.21: la aprobación de la planilla es de la empresa
_CLAVES_META = ("anio", "vigencia", "anio_guardado", "avisos_parametros", "parametros_ignorados")   # nunca vienen de la empresa


def _hojas(d: Any, prefijo: str = "") -> dict:
    """4.7: {ruta con puntos: valor} de un diccionario anidado (una lista, como los tramos de renta, es un solo valor)."""
    if not isinstance(d, dict):
        return {prefijo: d}
    out: dict = {}
    for k, v in d.items():
        out.update(_hojas(v, f"{prefijo}.{k}" if prefijo else str(k)))
    return out


def _valor_ruta(params: dict, ruta: str) -> Any:
    """4.7: valor de una ruta con puntos ('obrero.sem'; 'categorias.TONC' es el monto de esa categoría)."""
    partes = ruta.split(".")
    if partes[0] == "categorias" and len(partes) == 2:
        return next((c.get("monto") for c in params.get("categorias") or [] if c.get("codigo") == partes[1]), None)
    v: Any = params
    for k in partes:
        v = v.get(k) if isinstance(v, dict) else None
    return v


def _iguales(a: Any, b: Any) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) < 1e-9
    return a == b


def parametros_efectivos(ajustes: Optional[dict]) -> dict:
    """Parámetros de referencia con los ajustes de la empresa (mezcla por nivel; las listas se reemplazan completas).
    4.7: la empresa guarda solo lo que cambió y el año ('anio') en que lo guardó. Si ese año es anterior al de PARAMETROS, lo LEGAL
    guardado se ignora (se usan los valores oficiales) y se avisa; lo de la EMPRESA se conserva siempre. Además del juego efectivo
    devuelve 'anio_guardado', 'avisos_parametros' (textos para la pantalla y la planilla) y 'parametros_ignorados' [{clave, valor, oficial}]."""
    base = deepcopy(PARAMETROS)
    base["categorias"] = deepcopy(CATEGORIAS)
    base["anio_guardado"], base["avisos_parametros"], base["parametros_ignorados"] = None, [], []
    if not isinstance(ajustes, dict):
        return base

    def mezclar(dest: dict, src: dict):
        for k, v in src.items():
            if isinstance(v, dict) and isinstance(dest.get(k), dict):
                mezclar(dest[k], v)
            elif v == "" and isinstance(dest.get(k), (int, float)):
                dest[k] = 0                        # tasa vacía = 0 (antes rompía los cálculos) (R155)
            elif v is not None:
                dest[k] = v
    aj = {k: v for k, v in ajustes.items() if k != "categorias" and k not in _CLAVES_META}
    if isinstance(aj.get("patrono"), dict) and "rop" in aj["patrono"]:       # parámetros guardados con el ROP viejo (3,25 sin desglose)
        viejo = aj["patrono"].pop("rop")
        if "rop_opc" not in aj["patrono"] and "rop_bp" not in aj["patrono"]:
            try:
                total = float(viejo or 0)
            except (TypeError, ValueError):
                total = 0.0
            if total and abs(total - 3.25) > 0.001:                          # un valor propio se reparte en la misma proporción
                aj["patrono"]["rop_bp"] = round(total * 0.25 / 2.25, 2); aj["patrono"]["rop_opc"] = round(total - aj["patrono"]["rop_bp"], 2)
    montos = ajustes.get("categorias") if isinstance(ajustes.get("categorias"), dict) else {}
    # 4.7: año en que la empresa guardó; si es anterior al de los valores oficiales, lo legal que guardó no se aplica
    try:
        anio_g = int(ajustes.get("anio") or ANIO_SIN_MARCA)
    except (TypeError, ValueError):
        anio_g = ANIO_SIN_MARCA
    base["anio_guardado"] = anio_g
    if anio_g < int(PARAMETROS["anio"]):
        viejos = _hojas({k: aj.pop(k) for k in list(aj) if k not in CLAVES_EMPRESA})
        viejos.update({f"categorias.{c}": v for c, v in montos.items()})
        for ruta, valor in viejos.items():
            oficial = _valor_ruta(base, ruta)
            if not _iguales(valor, oficial):
                base["parametros_ignorados"].append({"clave": ruta, "valor": valor, "oficial": oficial})
        if base["parametros_ignorados"]:
            base["avisos_parametros"].append(f"Sus parámetros personalizados de {anio_g} no se aplican: se usan los oficiales de "
                                             f"{PARAMETROS['anio']}; revíselos y guárdelos de nuevo.")
        montos = {}
    mezclar(base, aj)
    for c in base["categorias"]:
        if c["codigo"] in montos:
            try:
                c["monto"] = float(montos[c["codigo"]])
            except (TypeError, ValueError):
                pass
    # 4.7: opciones con valores fijos; un valor desconocido regresa al de por defecto (el más prudente)
    if base.get("base_minima_diferencia") not in ("patrono", "trabajador"):
        base["base_minima_diferencia"] = "patrono"
    if base.get("embargo_modo") not in ("avisar", "limitar"):
        base["embargo_modo"] = "avisar"
    base["aplicar_base_minima"] = base.get("aplicar_base_minima") in (True, 1, "si", "sí", "true")
    base["paga_ina"] = base.get("paga_ina") not in (False, 0, "no", "false")
    for k in ("exigir_aprobacion_planilla", "aprobacion_otro_usuario"):      # 4.21: apagadas salvo un sí explícito
        base[k] = base.get(k) in (True, 1, "si", "sí", "true")
    return base


def parametros_usados(params: dict) -> dict:
    """4.7: con qué se calculó una planilla: el juego efectivo (sin los avisos), su año y la versión del motor."""
    out = {k: deepcopy(v) for k, v in params.items() if k not in ("avisos_parametros", "parametros_ignorados")}
    out["anio"], out["motor"] = params.get("anio"), MOTOR_VERSION
    return out


def tasa_total(d: dict) -> float:
    return round(sum(float(v or 0) for v in d.values()), 4)


def r2(x: float) -> float:
    return round(float(x or 0) + 1e-9, 2)


# ----------------------------------------------------------------------------- salario
def horas_semana(emp: dict, params: dict) -> float:
    h = emp.get("horas_semana")
    if h:
        return float(h)
    return float(params["jornadas"].get(emp.get("jornada") or "diurna", params["jornadas"]["diurna"])["semana"])


def salario_mensual(emp: dict, params: dict) -> float:
    """Salario mensual ordinario: por hora × horas de la jornada × 30 días (misma base que el salario diario y el mínimo
    mensual del MTSS; antes × 52/12 semanas = 208 h), o el mensual fijo."""
    if (emp.get("modo_salario") or "hora") == "mensual":
        return r2(emp.get("salario_mensual") or 0)
    return r2(float(emp.get("salario_hora") or 0) * horas_dia(emp, params) * float(params["dias_mes"]))


def horas_dia(emp: dict, params: dict) -> float:
    j = params["jornadas"].get(emp.get("jornada") or "diurna", params["jornadas"]["diurna"])
    hs = horas_semana(emp, params)
    return float(j["dia"]) if hs == float(j["semana"]) else (hs / 6 if hs else float(j["dia"]))


def salario_hora(emp: dict, params: dict) -> float:
    """Hora ordinaria de un salario mensual: mensual ÷ 30 ÷ horas de la jornada (criterio MTSS). Antes se dividía entre
    52/12 semanas (208 h), un 15 % más cara que la base diaria usada en la liquidación."""
    if (emp.get("modo_salario") or "hora") == "mensual":
        hd = horas_dia(emp, params)
        return r2(float(emp.get("salario_mensual") or 0) / float(params["dias_mes"]) / hd) if hd else 0.0
    return r2(emp.get("salario_hora") or 0)


def salario_diario(emp: dict, params: dict, mensual: Optional[float] = None) -> float:
    """Salario diario para preaviso, cesantía y vacaciones: por hora × horas de la jornada; mensual ÷ 30."""
    if (emp.get("modo_salario") or "hora") != "mensual" and mensual is None:
        return r2(float(emp.get("salario_hora") or 0) * horas_dia(emp, params))
    return r2(float(mensual if mensual is not None else salario_mensual(emp, params)) / float(params["dias_mes"]))


def horas_periodo(emp: dict, params: dict, periodo: str) -> float:
    hs, hm = horas_semana(emp, params), horas_dia(emp, params) * float(params["dias_mes"])   # mes = jornada × 30 días
    return {"semanal": hs, "bisemanal": hs * 2, "quincenal": hm / 2, "mensual": hm, "manual": hs}[periodo]


def minimo_mensual(categoria: Optional[str], params: dict, emp: Optional[dict] = None) -> Optional[float]:
    """Mínimo mensual de la categoría, prorrateado a la jornada del empleado (medio tiempo = la mitad) (R157)."""
    for c in params.get("categorias", []):
        if c["codigo"] == categoria:
            m = r2(c["monto"] * params["dias_mes"]) if c["base"] == "dia" else r2(c["monto"])
            if emp:
                completa = float(params["jornadas"]["diurna"]["semana"])          # la jornada completa de referencia (48 h), no la propia
                hs = horas_semana(emp, params)
                if hs and hs < completa:
                    m = r2(m * hs / completa)
            return m
    return None


# ----------------------------------------------------------------------------- renta
def renta_mensual(bruto_mensual: float, params: dict, hijos: int = 0, conyuge: bool = False) -> float:
    """Impuesto sobre la renta al salario (art. 33): tramos progresivos mensuales menos créditos familiares."""
    tramos = params["renta"]["tramos"]
    restante, anterior, impuesto = float(bruto_mensual or 0), 0.0, 0.0
    for limite, pct in tramos:
        tope = float(limite) if limite is not None else float("inf")
        porcion = max(0.0, min(restante, tope) - anterior)
        impuesto += porcion * float(pct) / 100
        anterior = tope
        if restante <= tope:
            break
    impuesto -= float(params["renta"].get("credito_hijo") or 0) * max(0, int(hijos or 0))
    if conyuge:
        impuesto -= float(params["renta"].get("credito_conyuge") or 0)
    return r2(max(0.0, impuesto))


def embargable_mensual(liquido_mes: float, menor_minimo: float, params: Optional[dict] = None) -> float:
    """3.90: lo máximo que se puede embargar por deudas comunes (art. 172 del Código de Trabajo) sobre el salario líquido del mes
    (después de la CCSS y la renta): nada hasta el menor salario mínimo; 1/8 de lo que pase de ese mínimo hasta 3 veces el
    mínimo, y 1/4 de lo que pase de 3 veces. La pensión alimentaria no sigue esta regla (tiene su propio tope)."""
    # 4.7: las fracciones y el múltiplo son parámetros (params['embargo']); sin ellos, los de la ley: 1/8, 1/4 y 3 veces
    e = (params or {}).get("embargo") or {}
    f1, f2 = float(e.get("tramo1_pct", 12.5) or 0) / 100, float(e.get("tramo2_pct", 25.0) or 0) / 100
    veces = max(1.0, float(e.get("multiplo_minimo", 3.0) or 3.0))
    if not menor_minimo or liquido_mes <= menor_minimo:
        return 0.0
    tramo1 = min(liquido_mes, veces * menor_minimo) - menor_minimo
    tramo2 = max(0.0, liquido_mes - veces * menor_minimo)
    return r2(tramo1 * f1 + tramo2 * f2)


def menor_minimo(params: dict) -> float:
    """3.90: el menor salario mínimo mensual de las categorías cargadas (referencia del art. 172)."""
    montos = [float(c["monto"]) * float(params["dias_mes"]) if c.get("base") == "dia" else float(c["monto"]) for c in params.get("categorias", []) if c.get("monto")]
    return r2(min(montos)) if montos else 0.0


# ----------------------------------------------------------------------------- nómina de un período
def _montos_lista(items, bruto: float) -> list[dict]:
    """Conceptos con monto fijo o porcentaje del bruto, con tope opcional (saldo de un préstamo). Devuelve [{concepto, monto, ...}]."""
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        pct = it.get("pct")
        try:
            monto = r2(float(bruto) * float(pct) / 100) if pct not in (None, "") else r2(it.get("monto") or 0)
            tope = it.get("tope")
            if tope not in (None, ""):
                monto = min(monto, r2(float(tope)))
        except (TypeError, ValueError):
            monto = 0.0
        if monto <= 0:
            continue
        out.append({**{k: v for k, v in it.items() if k in ("id", "concepto", "categoria", "pct", "salarial")}, "concepto": str(it.get("concepto") or "Concepto")[:80], "monto": monto})
    return out


def subsidio_incapacidad(tipo: str, dias: float, diario: float, params: dict, pct_patrono: Optional[float] = None, dias_desde_inicio: float = 0) -> dict:
    """Parte de una incapacidad que paga el patrono (no es salario: no cotiza ni paga renta). `dias` son los días de la incapacidad
    que caen en el período; `dias_desde_inicio` los que ya pasaron de la incapacidad antes del período (para los primeros N días)."""
    inc = params.get("incapacidad") or {}
    dias = max(0.0, float(dias or 0)); d0 = max(0.0, float(dias_desde_inicio or 0))
    if tipo == "incapacidad_ccss":
        tope, pct = float(inc.get("enfermedad_dias_patrono") or 0), float(inc.get("enfermedad_pct") or 0)
        dp = max(0.0, min(dias, tope - d0))
    elif tipo == "incapacidad_ins":
        tope, pct = float(inc.get("riesgo_dias_patrono") or 0), float(inc.get("riesgo_pct") or 0)
        dp = max(0.0, min(dias, tope - d0))
    elif tipo == "maternidad":
        dp, pct = dias, float(inc.get("maternidad_pct") or 0)
    else:
        return {"dias_patrono": 0.0, "pct": 0.0, "monto": 0.0}
    if pct_patrono not in (None, ""):
        pct = float(pct_patrono)
    return {"dias_patrono": r2(dp), "pct": pct, "monto": r2(float(diario or 0) * dp * pct / 100)}


# 4.7: orden en que se aplican los rebajos después de la CCSS y la renta cuando el salario no alcanza para todos: pensión alimentaria
# → embargos → asociación solidarista → préstamos → adelantos → seguros, sindicato y otros (la pensión primero; por validar con
# abogado). 'maternidad' (la parte de la licencia que la CCSS le paga directamente a la trabajadora) va antes que todo porque no es
# dinero que pague la empresa. 'manual' es el monto de la columna «Deducciones» de la planilla, que no dice qué es: va de último.
# Una categoría desconocida cuenta como 'otro'; dentro de cada categoría se respeta el orden en que llegan (el de registro).
ORDEN_REBAJOS = ("maternidad", "pension", "embargo", "asociacion", "prestamo", "adelanto", "seguro", "sindicato", "otro", "manual")
# qué quedó sin rebajar y qué hacer, en lenguaje claro (por categoría)
_NO_CUPO = {
    "maternidad": ("de la parte de la licencia de maternidad que paga la CCSS", "revísela con su contador antes de pagar"),
    "pension": ("de pensión alimentaria", "páguela aparte o agréguela a la siguiente planilla"),
    "embargo": ("del embargo", "deposítelo aparte o agréguelo a la siguiente planilla"),
    "asociacion": ("del aporte a la asociación solidarista", "cóbrelo aparte o agréguelo a la siguiente planilla"),
    "prestamo": ("del préstamo", "su saldo se conserva y se rebaja en las siguientes planillas"),
    "adelanto": ("del adelanto", "su saldo se conserva y se rebaja en las siguientes planillas"),
    "manual": ("de las otras deducciones de la planilla", "cóbrelas aparte o agréguelas a la siguiente planilla"),
}


def tasas_patrono(params: dict) -> dict:
    """4.7: tasas patronales que se cobran (sin la póliza del INS, que va aparte): el INA en 0 si la empresa no lo paga (paga_ina)."""
    return {k: (0.0 if k == "ina" and not params.get("paga_ina", True) else float(t or 0)) for k, t in (params.get("patrono") or {}).items()}


def _colones(v: Any) -> str:
    """4.7: monto como en la pantalla (₡1.234,56)."""
    return "₡" + f"{float(v or 0):,.2f}".replace(",", " ").replace(".", ",").replace(" ", ".")


def _num(v: Any) -> str:
    return f"{float(v or 0):g}".replace(".", ",")


def _texto_no_aplicado(x: dict) -> str:
    que, accion = _NO_CUPO.get(x.get("categoria"), (f"de «{x.get('concepto')}»", "cóbrelo aparte o agréguelo a la siguiente planilla"))
    if x.get("categoria") in _NO_CUPO and x.get("categoria") != "manual" and x.get("concepto"):
        que += f" («{x['concepto']}»)"
    if x.get("motivo") == "art172":
        return (f"No se rebajaron {_colones(x['monto'])} {que}: pasan de la porción embargable del artículo 172 del Código de Trabajo "
                f"en este período. Confirme el monto con la orden del juzgado.")
    return f"Quedó sin rebajar {_colones(x['monto'])} {que} porque el salario no alcanzó: {accion}."


def _aplicar_rebajos(detalle: list, manual: float, disponible: float, embargo_max: Optional[float]) -> tuple:
    """4.7: aplica los rebajos en el orden de ORDEN_REBAJOS hasta donde alcance `disponible` (el neto nunca queda negativo). Con
    embargo_max (embargo_modo 'limitar') los embargos juntos no pasan de esa porción. Devuelve (rebajos aplicados con su monto real,
    lo aplicado de la deducción manual, no_aplicado [{concepto, categoria, monto, motivo, id}])."""
    rango = {c: i for i, c in enumerate(ORDEN_REBAJOS)}
    cola = [(rango.get(d.get("categoria"), rango["otro"]), n, d) for n, d in enumerate(detalle)]
    if manual > 0:
        cola.append((rango["manual"], len(cola), {"concepto": "Otras deducciones", "categoria": "manual", "monto": r2(manual), "_manual": True}))
    cola.sort(key=lambda x: (x[0], x[1]))
    restante, tope_emb = r2(disponible), (None if embargo_max is None else max(0.0, r2(embargo_max)))
    aplicados, no_aplicado, manual_aplicado = [], [], 0.0
    for _, _, d in cola:
        pedido = r2(d["monto"])
        cabe, motivo = min(pedido, restante), "salario"
        es_embargo = d.get("categoria") == "embargo" and tope_emb is not None
        if es_embargo and tope_emb < cabe:
            cabe, motivo = tope_emb, "art172"
        cabe = r2(max(0.0, cabe))
        restante = r2(restante - cabe)
        if es_embargo:
            tope_emb = r2(tope_emb - cabe)
        if d.get("_manual"):
            manual_aplicado = cabe
        elif cabe > 0:
            aplicados.append({**d, "monto": cabe})
        falta = r2(pedido - cabe)
        if falta > 0:
            x = {"concepto": str(d.get("concepto") or "Concepto"), "categoria": d.get("categoria") or "otro", "monto": falta, "motivo": motivo}
            if d.get("id") is not None:
                x["id"] = d["id"]
            no_aplicado.append(x)
    return aplicados, manual_aplicado, no_aplicado


def _base_minima_ccss(params: dict, bruto: float, factor: float, dias_ausencia: float, novedades: Optional[list], deducciones: Optional[list],
                      periodo: str = "mensual", mes: Optional[dict] = None) -> dict:
    """4.7: base mínima contributiva del período (solo con aplicar_base_minima). Devuelve {'base': {régimen: base del período} de los
    regímenes (SEM, IVM) en que el salario del período es menor, 'excepcion': texto o None}. Excepciones del SPEC (por confirmar con el
    contador): no se aplica si la fila trae días sin salario (incapacidad, permiso sin goce o ausencia), una licencia de maternidad,
    un ingreso o una salida en el período; en esos casos solo se avisa. Tampoco en el período manual (su factor lo pone la pantalla
    por días: se avisa y las cuotas van sobre el salario del período).
    4.7 (C15): la CCSS cobra la base sobre el salario del MES. Con `mes` ({'bruto_mes_previo': lo ya pagado al empleado en el mes
    calendario de la planilla, en planillas pagadas; 'cierra_mes': si esta planilla cierra el mes}, que manda la pantalla) la base se
    compara con lo pagado en el mes más esta planilla y la diferencia se cobra UNA vez, en la planilla que cierra el mes: sus cuotas
    van sobre la base mensual menos lo ya pagado (así el mes suma la base completa); en las demás planillas del mes no se cobra y solo
    se avisa si la planilla va por debajo de la parte de la base que le toca (base ÷ períodos del mes). El ingreso y la salida se miran
    en el mes ('ingreso_mes', 'salida_mes') y el período manual no es excepción (no usa su factor).
    Sin `mes` (llamadas de antes) se compara por período, como antes; devuelve además 'salario_mes' cuando se evaluó por mes."""
    nada: dict = {"base": {}, "excepcion": None}
    if not params.get("aplicar_base_minima") or bruto <= 0:
        return nada
    mensual = isinstance(mes, dict) and mes.get("bruto_mes_previo") is not None
    previo = max(0.0, float(mes.get("bruto_mes_previo") or 0)) if mensual else 0.0
    fac = float(factor or 1) or 1.0
    montos = {}
    for k in ("sem", "ivm"):
        try:
            b = float((params.get("base_minima") or {}).get(k) or 0)
        except (TypeError, ValueError):
            b = 0.0
        if b > 0:
            montos[k] = b
    if mensual:          # lo que le falta al mes para la base: la planilla que cierra el mes cotiza sobre eso
        bases = {k: r2(b - previo) for k, b in montos.items() if previo + bruto + 0.005 < r2(b)}
    else:
        bases = {k: r2(b / fac) for k, b in montos.items() if bruto + 0.005 < r2(b / fac)}
    if not bases:
        return nada
    if mensual and not mes.get("cierra_mes"):
        if not any(bruto + 0.005 < r2(b / fac) for b in montos.values()):
            return nada                          # va al ritmo de la base: nada que avisar todavía
        return {"base": {}, "excepcion": f"El salario de esta planilla ({_colones(bruto)}) va por debajo de la base mínima contributiva de "
                                         "la CCSS: la base se revisa con el salario del mes completo en la planilla que cierra el mes, y la "
                                         "diferencia se cobra ahí una sola vez si hace falta. Las cuotas de esta planilla van sobre su salario."}
    if periodo == "manual" and not mensual:
        return {"base": {}, "excepcion": "No se aplicó la base mínima contributiva de la CCSS porque la planilla es de período manual: las "
                                         "cuotas van sobre el salario del período. Revíselo con su contador."}
    tipos = {str(x.get("tipo") if isinstance(x, dict) else x) for x in (novedades if isinstance(novedades, list) else []) if x}
    if any(isinstance(d, dict) and d.get("categoria") == "maternidad" for d in deducciones or []):
        tipos.add("maternidad")
    motivos = []
    donde = "en el mes" if mensual else "en este período"
    if "ingreso" in tipos or (mensual and "ingreso_mes" in tipos):
        motivos.append("ingresó " + donde)
    if "salida" in tipos or (mensual and "salida_mes" in tipos):     # 4.7: salió antes de terminar el período (o el mes): no cotiza el mes completo
        motivos.append("salió " + donde)
    if tipos & {"incapacidad_ccss", "incapacidad_ins", "maternidad"}:
        motivos.append("tiene una incapacidad o licencia en el período")
    if "permiso_sin_goce" in tipos:
        motivos.append("tiene un permiso sin goce de salario")
    if float(dias_ausencia or 0) > 0 and not motivos:
        motivos.append("tiene días sin salario en el período")
    if motivos:
        return {"base": {}, "excepcion": "No se aplicó la base mínima contributiva de la CCSS porque la persona " + " y ".join(motivos)
                + ": las cuotas van sobre el salario del período. Revíselo con su contador."}
    return {"base": bases, "excepcion": None, **({"salario_mes": r2(previo + bruto)} if mensual else {})}


def _jornadas_largas(horas_detalle: Any, hd: float) -> list:
    """4.7: días con más de 12 horas entre la jornada y las extras (art. 136 del Código de Trabajo), si la fila trae el detalle.
    4.7 (D2): el detalle no dice si ese día hubo jornada ordinaria (un día libre trabajado se registra como hora extra y el sistema no
    sabe cuál es el día libre de cada persona). Por eso, lo más prudente: si las horas registradas solas (feriado más extras, o solo
    extras) ya pasan de 12, se avisa sin condición; si pasan de 12 solo al sumarles la jornada ordinaria (hd), se avisa como posible
    («si ese día también trabajó su jornada») y se pide revisarlo, en vez de afirmar algo que en un día libre no pasó."""
    dias: dict = {}
    for x in horas_detalle if isinstance(horas_detalle, list) else []:
        if not isinstance(x, dict) or not x.get("fecha"):
            continue
        try:
            n = max(0.0, float(x.get("horas") or 0))
        except (TypeError, ValueError):
            continue
        d = dias.setdefault(str(x["fecha"])[:10], {"extra": 0.0, "feriado": 0.0})
        d["feriado" if x.get("tipo") == "feriado" else "extra"] += n
    out = []
    jornada = max(0.0, float(hd or 0))
    for f, d in sorted(dias.items()):
        fecha = f"{f[8:10]}/{f[5:7]}/{f[:4]}" if len(f) == 10 else f
        if d["feriado"]:
            total = d["feriado"] + d["extra"]
            if total > 12 + 1e-9:
                out.append({"tipo": "jornada", "texto": f"El {fecha} suma {_num(total)} horas entre el feriado trabajado y las extras: pasa del "
                                                         f"máximo de 12 horas al día (artículo 136 del Código de Trabajo)."})
        elif d["extra"] > 12 + 1e-9:
            out.append({"tipo": "jornada", "texto": f"El {fecha} suma {_num(d['extra'])} horas extra: pasa del máximo de 12 horas al día "
                                                     f"(artículo 136 del Código de Trabajo)."})
        elif jornada + d["extra"] > 12 + 1e-9:
            out.append({"tipo": "jornada", "texto": f"El {fecha} suma {_num(jornada + d['extra'])} horas si ese día también trabajó su jornada "
                                                     f"ordinaria ({_num(jornada)} h) además de las {_num(d['extra'])} horas extra: pasaría del máximo "
                                                     f"de 12 horas al día (artículo 136 del Código de Trabajo). Revíselo; si era su día libre, no aplica."})
    return out


def _avisos_nomina(sm: float, minimo: Optional[float], bm: float, bmc: dict, dif_trabajador: float, dif_patrono: float, embargos: float,
                   embargo_max: Optional[float], embargo_excede: bool, pensiones: float, pension_excede: bool, params: dict,
                   no_aplicado: list, horas_detalle: Any, hd: float) -> list:
    """4.7: avisos de una fila de planilla en lenguaje claro [{tipo, texto}]; la planilla guardada los conserva."""
    av = []
    if minimo and sm + 0.5 < minimo:
        av.append({"tipo": "bajo_minimo", "texto": f"El salario mensual ({_colones(sm)}) está por debajo del mínimo de su categoría ({_colones(minimo)})."})
    if bmc["base"]:
        if bmc.get("salario_mes") is not None:      # 4.7 (C15): evaluada con el salario del mes, en la planilla que cierra el mes
            t = (f"Las cuotas de la CCSS (SEM e IVM) se calcularon sobre la base mínima contributiva porque el salario del mes "
                 f"({_colones(bmc['salario_mes'])}) es menor: esta planilla, que cierra el mes, completa la base del mes.")
        else:
            t = "Las cuotas de la CCSS (SEM e IVM) se calcularon sobre la base mínima contributiva porque el salario del período es menor."
        if dif_trabajador:
            t += f" La diferencia de la cuota del trabajador ({_colones(dif_trabajador)}) se le rebaja aparte en su colilla."
        if dif_patrono:
            t += f" La empresa paga {'lo que no cupo en su salario' if dif_trabajador else 'la diferencia de la cuota del trabajador'} ({_colones(dif_patrono)})."
        av.append({"tipo": "base_minima", "texto": t})
    elif bmc["excepcion"]:
        av.append({"tipo": "base_minima", "texto": bmc["excepcion"]})
    elif bm and sm + 0.5 < bm and not params.get("aplicar_base_minima"):
        av.append({"tipo": "base_minima", "texto": f"El salario mensual está bajo la base mínima contributiva de la CCSS ({_colones(bm)}): la CCSS puede "
                                                   f"cobrar las cuotas sobre esa base. Revíselo con su contador; si lo confirma, actívelo en Recursos humanos › Parámetros."})
    if embargo_excede:
        av.append({"tipo": "embargo", "texto": f"El embargo ({_colones(embargos)}) supera lo que permite el artículo 172 del Código de Trabajo en este "
                                               f"período ({_colones(embargo_max or 0)}). Confirme el monto con la orden del juzgado."})
    if pension_excede:
        av.append({"tipo": "pension", "texto": f"La pensión alimentaria ({_colones(pensiones)}) pasa del {_num(params.get('pension_aviso_pct') or 50)} % del "
                                               f"salario después de la CCSS y la renta. Confirme el monto con la orden del juzgado."})
    for x in no_aplicado:
        av.append({"tipo": "no_aplicado", "texto": _texto_no_aplicado(x)})
    return av + _jornadas_largas(horas_detalle, hd)


def _novedades_fila(f: dict, emp: dict) -> list:
    """4.7: novedades del período que trae una fila de planilla: su lista 'novedades', los tipos de sus 'ausencias', un ingreso
    posterior a su 'desde' y una salida antes de su 'hasta' (según las fechas de la ficha del empleado; la pantalla manda las del
    período). Salir el último día del período no cuenta: lo trabajó completo."""
    nov = f.get("novedades")
    out = [x for x in (nov if isinstance(nov, list) else []) if isinstance(x, (str, dict))]
    out += [{"tipo": a.get("tipo")} for a in (f.get("ausencias") if isinstance(f.get("ausencias"), list) else []) if isinstance(a, dict) and a.get("tipo")]
    fi, fs, d0, d1 = _fecha(emp.get("fecha_ingreso")), _fecha(emp.get("fecha_salida")), _fecha(f.get("desde")), _fecha(f.get("hasta"))
    if fi and d0 and fi > d0:
        out.append("ingreso")
    if fs and d0 and d1 and d0 <= fs < d1:
        out.append("salida")
    return out


def _novedades_mes(f: dict, emp: dict) -> list:
    """4.7 (C15): con la base mínima por mes, un ingreso o una salida dentro del mes calendario de la planilla ('hasta'), aunque sea en
    otro período del mes: el mes no está completo y la base no se completa (se avisa). Salir el último día del mes no cuenta."""
    d1 = _fecha(f.get("hasta"))
    if not d1:
        return []
    ini, fin = d1.replace(day=1), d1.replace(day=monthrange(d1.year, d1.month)[1])
    fi, fs = _fecha(emp.get("fecha_ingreso")), _fecha(emp.get("fecha_salida"))
    out = []
    if fi and ini < fi <= fin:
        out.append("ingreso_mes")
    if fs and ini <= fs < fin:
        out.append("salida_mes")
    return out


def _mes_fila(f: dict) -> dict:
    """4.7 (C15): base mínima por MES. Con aplicar_base_minima la pantalla manda en cada fila 'bruto_mes_previo' (el salario ya pagado al
    empleado en el mes calendario de 'hasta', en planillas pagadas ordinarias y complementarias, sin la que se corrige) y 'cierra_mes'
    (la planilla cierra el mes). Sin 'bruto_mes_previo' (llamadas de antes) queda vacío y la base se evalúa por período, como antes; sin
    'cierra_mes' se toma como que no cierra el mes (solo se avisa, no se cobra). Un dato que no es un monto se rechaza."""
    if f.get("bruto_mes_previo") in (None, ""):
        return {}
    try:
        v = float(f.get("bruto_mes_previo") or 0)
    except (TypeError, ValueError):
        v = -1.0
    if not 0 <= v < 1e13:                         # también NaN e infinito
        raise ValueError("Fila de la planilla: «bruto_mes_previo» debe ser un monto válido")
    return {"bruto_mes_previo": v, "cierra_mes": f.get("cierra_mes") in (True, 1, "1", "si", "sí", "true")}


def _previo_fila(f: dict) -> dict:
    """4.7: lo ya pagado en el mes que trae la fila de una planilla COMPLEMENTARIA (bruto_previo, renta_previa y la estimación de lo que
    falta del mes, bruto_resto_mes y renta_resto_mes); vacío en una planilla normal. Un dato que no es un monto se rechaza."""
    if f.get("bruto_previo") in (None, ""):
        return {}

    def monto(k: str) -> float:
        try:
            v = float(f.get(k) or 0)
        except (TypeError, ValueError):
            v = -1.0
        if not 0 <= v < 1e13:                     # también NaN e infinito
            raise ValueError(f"Fila de la planilla: «{k}» debe ser un monto válido")
        return v
    return {k: monto(k) for k in ("bruto_previo", "renta_previa", "bruto_resto_mes", "renta_resto_mes")}


def renta_complementaria(bruto: float, bruto_previo: float, renta_previa: float, params: dict, hijos: int = 0, conyuge: bool = False,
                         bruto_resto: float = 0, renta_resto: float = 0) -> dict:
    """4.7: renta de una planilla COMPLEMENTARIA (pagos adicionales de un período que ya tiene su planilla). La retención a los
    salarios es MENSUAL (art. 33): antes la complementaria se calculaba sola, el tramo exento y los créditos se aplicaban otra vez y se
    retenía de menos.
    REGLA: renta = renta_mensual(bruto_previo + bruto_resto + bruto) − renta_previa − renta_resto, nunca negativa.
    bruto_previo / renta_previa: lo ya pagado y retenido al empleado en el mes (las planillas pagadas que cierran en el mes, también
    otras complementarias). bruto_resto / renta_resto: lo ordinario del mes que falta pagar, estimado por la pantalla en la misma
    proporción de lo pagado (p. ej. solo se pagó la primera quincena: la segunda se estima igual, con la renta que retendrá); en 0 la
    regla queda en lo ya pagado más esta planilla. Los créditos por hijos y cónyuge se aplican una sola vez, sobre el mes."""
    bp, rp = max(0.0, float(bruto_previo or 0)), max(0.0, float(renta_previa or 0))
    br, rr = max(0.0, float(bruto_resto or 0)), max(0.0, float(renta_resto or 0))
    base = r2(bp + br + max(0.0, float(bruto or 0)))
    mes = renta_mensual(base, params, hijos, conyuge)
    return {"bruto_previo": r2(bp), "renta_previa": r2(rp), "bruto_resto": r2(br), "renta_resto": r2(rr), "base_mes": base, "renta_mes": mes,
            "renta": r2(max(0.0, mes - rp - rr))}


def calcular_nomina(emp: dict, params: dict, periodo: str = "mensual", horas: Optional[float] = None, horas_extra: float = 0,
                    otros_ingresos: float = 0, otras_deducciones: float = 0, factor_manual: Optional[float] = None,
                    dias_ausencia: float = 0, horas_feriado: float = 0, no_salariales: float = 0,
                    deducciones: Optional[list] = None, ingresos: Optional[list] = None, novedades: Optional[list] = None,
                    horas_detalle: Optional[list] = None, bruto_previo: Optional[float] = None, renta_previa: float = 0,
                    bruto_resto_mes: float = 0, renta_resto_mes: float = 0, bruto_mes_previo: Optional[float] = None,
                    cierra_mes: Optional[bool] = None) -> dict:
    """dias_ausencia: días sin goce de salario (permisos, ausencias injustificadas, incapacidades) que se restan del ordinario.
    horas_feriado: horas trabajadas en feriado de pago obligatorio (se pagan con el recargo del factor). no_salariales: montos que
    recibe el empleado sin ser salario (subsidio patronal de incapacidad, viáticos): van al neto, no cotizan ni pagan renta.
    deducciones / ingresos: listas de conceptos [{concepto, monto | pct, tope, salarial}] (préstamos, embargos, pensión,
    asociación solidarista, bonificaciones…); se suman a otras_deducciones / otros_ingresos y se devuelven con su monto.
    4.7: los rebajos se aplican en el orden de ORDEN_REBAJOS hasta donde alcance el salario después de la CCSS y la renta (el neto
    nunca queda negativo); lo que no cupo sale en 'no_aplicado' y en 'avisos'. novedades: lo que pasó en el período según la fila
    ('ingreso', 'salida', 'incapacidad_ccss', 'incapacidad_ins', 'maternidad', 'permiso_sin_goce'; texto o {tipo}) para las
    excepciones de la base mínima. horas_detalle: [{fecha, tipo, horas}] de las horas extra y de feriado registradas (avisa los
    días de más de 12 h).
    bruto_previo, renta_previa, bruto_resto_mes y renta_resto_mes: solo en una planilla COMPLEMENTARIA (sin bruto_previo es una planilla
    normal): la renta va sobre el mes (renta_complementaria; si a la persona no se le ha pagado nada en el mes, como en una planilla
    normal) y la base mínima no se vuelve a cobrar.
    bruto_mes_previo y cierra_mes (4.7, C15; solo con aplicar_base_minima): lo ya pagado al empleado en el mes calendario de la planilla
    y si esta planilla cierra el mes: la base mínima se evalúa con el salario del mes y se cobra solo en la que cierra el mes. Sin
    bruto_mes_previo, por período, como antes."""
    if periodo not in PERIODOS:
        raise ValueError("Período de pago inválido")
    sh = salario_hora(emp, params)
    modo = emp.get("modo_salario") or "hora"
    if periodo == "manual":
        h = float(horas if horas is not None else horas_periodo(emp, params, "semanal"))
        ordinario = r2(sh * h)
        factor = float(factor_manual or 1)
    elif modo == "mensual" and horas is None:
        h = horas_periodo(emp, params, periodo)
        ordinario = r2(salario_mensual(emp, params) / PERIODOS[periodo])
        factor = PERIODOS[periodo]
    else:
        h = float(horas if horas is not None else horas_periodo(emp, params, periodo))
        ordinario = r2(sh * h)
        factor = PERIODOS[periodo]
    horas_extra, horas_feriado = max(0.0, float(horas_extra or 0)), max(0.0, float(horas_feriado or 0))      # negativos = 0 (no suben el salario)
    dias_ausencia, no_salariales = max(0.0, float(dias_ausencia or 0)), max(0.0, float(no_salariales or 0))
    otros_ingresos, otras_deducciones = max(0.0, float(otros_ingresos or 0)), max(0.0, float(otras_deducciones or 0))
    extras = r2(sh * float(params["hora_extra_factor"]) * horas_extra)
    feriado = r2(sh * max(0.0, float(params.get("feriado_factor") or 2) - 1) * horas_feriado)
    diario = salario_diario(emp, params)
    descuento_ausencia = r2(min(ordinario, diario * dias_ausencia)) if dias_ausencia else 0.0
    ordinario = r2(ordinario - descuento_ausencia)
    ingresos_det = _montos_lista(ingresos, ordinario + extras + feriado)   # un ingreso en % (comisión) se calcula sobre el salario del período
    ing_salarial = r2(sum(i["monto"] for i in ingresos_det if i.get("salarial", True) not in (False, 0, "no")))
    ing_no_salarial = r2(sum(i["monto"] for i in ingresos_det if i.get("salarial", True) in (False, 0, "no")))
    total_otros_ingresos = r2(float(otros_ingresos or 0) + ing_salarial)
    bruto = r2(ordinario + extras + feriado + total_otros_ingresos)
    obrero = {k: r2(bruto * float(t or 0) / 100) for k, t in params["obrero"].items()}
    # 4.7: base mínima contributiva (solo con aplicar_base_minima): SEM e IVM sobre el mayor entre el salario y la base del régimen
    mes_bm = {"bruto_mes_previo": bruto_mes_previo, "cierra_mes": bool(cierra_mes)} if bruto_mes_previo is not None else None
    bmc = _base_minima_ccss(params, bruto, factor, dias_ausencia, novedades, deducciones, periodo, mes_bm)
    if bruto_previo is not None and (bmc["base"] or bmc["excepcion"]):
        # 4.7: una complementaria (pagos adicionales del período) no vuelve a cobrar la base mínima: va con la planilla original
        bmc = {"base": {}, "excepcion": "La base mínima contributiva de la CCSS no se aplica en una planilla complementaria: las cuotas van "
                                         "sobre lo pagado en ella y la base se revisa con la planilla original del período."}
    dif_obrera = 0.0
    for k, b in bmc["base"].items():
        if k in obrero:
            dif_obrera = r2(dif_obrera + max(0.0, r2(b * float(params["obrero"][k] or 0) / 100) - obrero[k]))
    total_obrero = r2(sum(obrero.values()))
    renta_comp = None
    if not emp.get("aplica_renta", True):
        renta = 0.0
    elif bruto_previo is not None and (float(bruto_previo or 0) > 0 or float(bruto_resto_mes or 0) > 0):
        # 4.7: complementaria: renta del mes completo menos lo ya retenido (renta_complementaria); nunca más de lo que le queda.
        # Sin nada pagado en el mes a la persona (la original aún sin pagar, o no estaba en ella) sigue como una planilla normal
        # (abajo): la regla sola tomaría lo de esta planilla como el salario de todo el mes y retendría de menos
        renta_comp = renta_complementaria(bruto, bruto_previo, renta_previa, params, int(emp.get("hijos") or 0), bool(emp.get("conyuge")),
                                          bruto_resto_mes, renta_resto_mes)
        renta = r2(min(renta_comp["renta"], max(0.0, bruto - total_obrero)))
    else:
        renta = r2(renta_mensual(bruto * factor, params, int(emp.get("hijos") or 0), bool(emp.get("conyuge"))) / factor)
    # la diferencia de la cuota obrera la paga quien diga base_minima_diferencia; la parte del trabajador no pasa de lo que le queda
    # después de la CCSS y la renta (el resto lo paga la empresa: la CCSS la cobra igual)
    dif_trabajador = 0.0
    if dif_obrera and params.get("base_minima_diferencia") == "trabajador":
        dif_trabajador = r2(min(dif_obrera, max(0.0, bruto - total_obrero - renta)))
        if dif_trabajador > 0:
            obrero["base_minima"] = dif_trabajador
            total_obrero = r2(total_obrero + dif_trabajador)
    dif_patrono = r2(dif_obrera - dif_trabajador)
    deducciones_det = _montos_lista(deducciones, bruto)
    total_no_salarial = r2(no_salariales + ing_no_salarial)
    # 4.7: después de la CCSS y la renta, los rebajos van en el orden de ORDEN_REBAJOS (la pensión alimentaria primero) hasta donde
    # alcance; nunca dejan el neto por debajo de cero y lo que no cupo se devuelve en no_aplicado con su aviso. El detalle devuelto
    # es lo retenido de verdad (los saldos de préstamos y adelantos se rebajan solo por eso, como antes).
    disponible = max(0.0, r2(bruto - total_obrero - renta))
    fac = float(factor or 1) or 1.0
    emb_pedido = r2(sum(d["monto"] for d in deducciones_det if d.get("categoria") == "embargo"))
    # 4.7: porción embargable del art. 172 sobre el salario del MES (lo del período × los períodos por mes, como la renta) y llevada al
    # período; la 3.90 dividía en vez de multiplicar y en una planilla semanal, bisemanal o quincenal la porción salía casi en cero
    embargo_max = r2(embargable_mensual(disponible * fac, menor_minimo(params), params) / fac) if emb_pedido else None
    limitar = params.get("embargo_modo") == "limitar"
    deducciones_det, manual, no_aplicado = _aplicar_rebajos(deducciones_det, otras_deducciones, disponible, embargo_max if limitar else None)
    total_otras = r2(manual + sum(d["monto"] for d in deducciones_det))
    neto = r2(max(0.0, r2(bruto - total_obrero - renta - total_otras)) + total_no_salarial)
    otras_deducciones = total_otras
    # 4.7: la empresa que no paga INA lo apaga en Parámetros (paga_ina); con la base mínima, SEM e IVM patronales van sobre la base
    tasas_pat = tasas_patrono(params)
    patrono = {k: r2(bruto * t / 100) for k, t in tasas_pat.items()}
    for k, b in bmc["base"].items():
        if k in tasas_pat:
            patrono[k] = r2(b * tasas_pat[k] / 100)
    ins_pct = float(emp.get("ins_riesgos") if emp.get("ins_riesgos") not in (None, "") else params["ins_riesgos"])
    patrono["ins_riesgos"] = r2(bruto * ins_pct / 100)
    ins_ad = float(params.get("ins_adicional") or 0)      # 4.7: el 1 % del INS aparte de la póliza (por confirmar con el contador)
    if ins_ad > 0:
        patrono["ins_adicional"] = r2(bruto * ins_ad / 100)
    if dif_patrono > 0:
        patrono["base_minima_obrera"] = dif_patrono      # 4.7: la diferencia de la cuota obrera por la base mínima, a cargo de la empresa
    total_patronal = r2(sum(patrono.values()))
    provisiones = {k: r2(bruto * float(t) / 100) for k, t in params["provisiones"].items()}
    total_provisiones = r2(sum(provisiones.values()))
    minimo = minimo_mensual(emp.get("categoria"), params, emp)
    bm = max([float(v or 0) for v in (params.get("base_minima") or {}).values()] or [0])
    # 3.90: embargos y pensión alimentaria contra lo que permite la ley (el monto lo fija el juzgado; 4.7: con embargo_modo 'limitar'
    # el embargo ya se limitó arriba y lo que no se rebajó sale en no_aplicado)
    liquido = disponible
    embargos = r2(sum(d["monto"] for d in deducciones_det if d.get("categoria") == "embargo"))
    pensiones = r2(sum(d["monto"] for d in deducciones_det if d.get("categoria") == "pension"))
    embargo_excede = bool(embargos and embargos > (embargo_max or 0) + 0.5)
    pension_excede = bool(pensiones and pensiones > liquido * float(params.get("pension_aviso_pct") or 50) / 100 + 0.5)
    avisos = _avisos_nomina(salario_mensual(emp, params), minimo, bm, bmc, dif_trabajador, dif_patrono, embargos, embargo_max, embargo_excede,
                            pensiones, pension_excede, params, no_aplicado, horas_detalle, horas_dia(emp, params))
    return {
        "periodo": periodo, "horas": r2(h), "horas_extra": r2(horas_extra or 0), "salario_hora": sh, "ordinario": ordinario, "extras": extras,
        "horas_feriado": r2(horas_feriado or 0), "feriado": feriado, "dias_ausencia": r2(dias_ausencia or 0), "descuento_ausencia": descuento_ausencia,
        "otros_ingresos": total_otros_ingresos, "bruto": bruto, "no_salariales": total_no_salarial,
        "detalle_ingresos": ingresos_det, "detalle_deducciones": deducciones_det,
        "obrero": obrero, "total_obrero": total_obrero, "pct_obrero": tasa_total(params["obrero"]), "renta": renta,
        "otras_deducciones": r2(otras_deducciones or 0), "total_deducciones": r2(total_obrero + renta + float(otras_deducciones or 0)), "neto": neto,
        "bajo_minimo": bool(minimo and salario_mensual(emp, params) + 0.5 < minimo),
        "patrono": patrono, "total_patronal": total_patronal, "pct_patronal": r2(tasa_total(tasas_pat) + ins_pct + ins_ad),
        "provisiones": provisiones, "total_provisiones": total_provisiones, "pct_provisiones": tasa_total(params["provisiones"]),
        "costo_total": r2(bruto + total_patronal + total_provisiones), "factor_mes": r2(factor),
        "salario_mensual": salario_mensual(emp, params), "minimo_mensual": minimo,
        "bajo_base_minima": bool(bm and salario_mensual(emp, params) + 0.5 < bm), "base_minima": bm or None,   # 3.89: aviso (4.7: con aplicar_base_minima sí cobra)
        "embargo_maximo": embargo_max, "embargo_excede": embargo_excede, "pension_excede": pension_excede,
        # 4.7: rebajos que no cupieron, avisos en lenguaje claro (se guardan con la planilla) y la base mínima aplicada
        "no_aplicado": no_aplicado, "avisos": avisos, "horas_dia": r2(horas_dia(emp, params)), "base_minima_aplicada": bool(bmc["base"]),
        "base_minima_detalle": ({"base": bmc["base"], "diferencia_obrera": dif_obrera, "paga_trabajador": dif_trabajador, "paga_patrono": dif_patrono,
                                 "salario_mes": bmc.get("salario_mes")}
                                if bmc["base"] else None),
        "renta_complementaria": renta_comp,      # 4.7: cómo se calculó la renta de una complementaria (None en una planilla normal o sin nada pagado en el mes)
    }


def calcular_planilla(filas: list[dict], params: dict, periodo: str) -> dict:
    out, tot = [], {"bruto": 0.0, "total_obrero": 0.0, "renta": 0.0, "otras_deducciones": 0.0, "neto": 0.0, "total_patronal": 0.0, "total_provisiones": 0.0, "costo_total": 0.0, "no_salariales": 0.0}
    for n_fila, f in enumerate(filas, start=1):
        emp = f.get("empleado") if isinstance(f, dict) else None
        if not isinstance(emp, dict):
            raise ValueError(f"Fila {n_fila}: falta el empleado")
        mes = _mes_fila(f)                     # 4.7 (C15): base mínima por mes, si la pantalla manda lo ya pagado en el mes
        nov = _novedades_fila(f, emp) + (_novedades_mes(f, emp) if mes else [])
        r = calcular_nomina(emp, params, periodo, f.get("horas"), f.get("horas_extra") or 0, f.get("otros_ingresos") or 0, f.get("otras_deducciones") or 0, f.get("factor_manual"),
                            f.get("dias_ausencia") or 0, f.get("horas_feriado") or 0, f.get("no_salariales") or 0, f.get("deducciones"), f.get("ingresos"),
                            novedades=nov, horas_detalle=f.get("horas_detalle"), **_previo_fila(f), **mes)
        r["empleado_id"] = emp.get("id"); r["nombre"] = emp.get("nombre_completo") or emp.get("nombre")
        out.append(r)
        for k in tot:
            tot[k] = r2(tot[k] + r[k])
    # 4.7: avisos generales (parámetros de un año anterior) y con qué parámetros se calculó, para guardarlos con la planilla
    return {"filas": out, "totales": tot, "empleados": len(out), "anio_parametros": params.get("anio"),
            "avisos": [{"tipo": "parametros", "texto": t} for t in params.get("avisos_parametros") or []], "parametros_usados": parametros_usados(params)}


# ----------------------------------------------------------------------------- tiempo trabajado, vacaciones
def _fecha(v: Any) -> Optional[date]:
    if not v:
        return None
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


def meses_completos(desde: Any, hasta: Any) -> int:
    d1, d2 = _fecha(desde), _fecha(hasta)
    if not d1 or not d2 or d2 < d1:
        return 0
    m = (d2.year - d1.year) * 12 + (d2.month - d1.month)
    # si el día de ingreso no existe en el mes final (31 → febrero), el último día del mes completa el mes (R307)
    if d2.day < d1.day and d2.day != monthrange(d2.year, d2.month)[1]:
        m -= 1
    return max(0, m)


def antiguedad(desde: Any, hasta: Any) -> dict:
    d1, d2 = _fecha(desde), _fecha(hasta)
    dias = (d2 - d1).days if d1 and d2 and d2 >= d1 else 0
    meses = meses_completos(desde, hasta)
    return {"dias": dias, "meses": meses, "anios": meses // 12, "anios_decimal": round(dias / 365, 4)}


def vacaciones(fecha_ingreso: Any, hasta: Any, dias_disfrutados: float, params: dict) -> dict:
    """Días ganados: 12 (× días por mes) por cada bloque completo de 50 semanas (Código de Trabajo art. 153) más un día por
    cada mes completo de la fracción restante; saldo = ganados − disfrutados (R306)."""
    d1, d2 = _fecha(fecha_ingreso), _fecha(hasta)
    por_mes = float(params.get("dias_vacaciones_por_mes") or 1)
    if not d1 or not d2 or d2 < d1:
        return {"meses": 0, "dias_ganados": 0.0, "dias_disfrutados": r2(dias_disfrutados or 0), "saldo": r2(-float(dias_disfrutados or 0))}
    bloques = (d2 - d1).days // 350                     # 50 semanas = 350 días
    inicio_resto = d1 + timedelta(days=bloques * 350)
    meses_resto = meses_completos(inicio_resto, d2)
    m = meses_completos(fecha_ingreso, hasta)
    ganados = r2(bloques * 12 * por_mes + meses_resto * por_mes)
    return {"meses": m, "dias_ganados": ganados, "dias_disfrutados": r2(dias_disfrutados or 0), "saldo": r2(ganados - float(dias_disfrutados or 0))}


# ----------------------------------------------------------------------------- liquidación (Código de Trabajo arts. 28 y 29)
def dias_preaviso(meses: int) -> int:
    if meses < 3:
        return 0
    if meses < 6:
        return 7
    if meses < 12:
        return 15
    return 30


def dias_cesantia_por_anio(anios: int) -> float:
    """Art. 29: días de cesantía por cada año trabajado según los años de antigüedad (tope 8 años)."""
    tabla = {1: 19.5, 2: 20, 3: 20.5, 4: 21, 5: 21.24, 6: 21.5, 7: 22, 8: 22, 9: 22, 10: 21.5, 11: 21, 12: 20.5}   # año 5: 21,24 (R146)
    return float(tabla.get(anios, 20 if anios >= 13 else 0))


def dias_cesantia(meses: int, anios_decimal: float) -> float:
    if meses < 3:
        return 0.0
    if meses < 6:
        return 7.0
    if meses < 12:
        return 14.0
    anios = int(anios_decimal)
    return round(dias_cesantia_por_anio(max(1, anios)) * min(anios_decimal, 8.0), 2)


def _tasa_patronal_liquidacion(params: dict) -> float:
    """4.7: % patronal sobre lo salarial de la liquidación con las mismas reglas que la planilla y que /api/rrhh/parametros: las cuotas
    que se cobran (tasas_patrono: el INA en 0 si la empresa no lo paga) más el INS aparte de la póliza (ins_adicional). La póliza de
    riesgos del INS no va aquí (los informes la estiman aparte). Con los parámetros de defecto da lo mismo que antes (25,83 %)."""
    return round(tasa_total(tasas_patrono(params)) + float(params.get("ins_adicional") or 0), 4)


def liquidacion(emp: dict, params: dict, fecha_salida: str, motivo: str, dias_vac_disfrutados: float = 0, dias_pendientes: float = 0,
                salario_promedio_mensual: Optional[float] = None, preaviso_otorgado: bool = False, devengado_aguinaldo: Optional[float] = None,
                bruto_previo: Optional[float] = None, renta_previa: float = 0) -> dict:
    """devengado_aguinaldo: salarios brutos pagados en planillas desde el 1 de diciembre anterior (o el ingreso): si se indica, el
    aguinaldo proporcional es ese monto entre 12 (Ley 2412) en vez de estimarlo con el salario actual.
    bruto_previo / renta_previa (4.7, C1): lo ya pagado y retenido al empleado en el mes de la salida (planillas pagadas que cierran en
    ese mes). La renta de lo salarial de la liquidación (salario pendiente y vacaciones) va sobre el mes completo; sin ellos (llamadas
    de antes) se calcula como si en el mes no se le hubiera pagado nada más."""
    if motivo not in MOTIVOS:
        raise ValueError("Motivo de salida inválido")
    a = antiguedad(emp.get("fecha_ingreso"), fecha_salida)
    mensual = r2(salario_promedio_mensual if salario_promedio_mensual else salario_mensual(emp, params))
    diario = salario_diario(emp, params, salario_promedio_mensual if salario_promedio_mensual else None)
    con_responsabilidad = motivo in ("despido_con", "pension_muerte")
    d_pre = dias_preaviso(a["meses"]) if (motivo == "despido_con" and not preaviso_otorgado) else 0
    d_ces = dias_cesantia(a["meses"], a["anios_decimal"]) if con_responsabilidad else 0.0
    vac = vacaciones(emp.get("fecha_ingreso"), fecha_salida, dias_vac_disfrutados, params)
    d_vac = max(0.0, vac["saldo"])
    # aguinaldo proporcional: lo devengado desde el 1 de diciembre anterior (o desde el ingreso) hasta la salida, entre 12
    fs = _fecha(fecha_salida)
    if not fs:
        raise ValueError("Indique una fecha de salida válida (AAAA-MM-DD)")      # antes se calculaba con la fecha del servidor (R308)
    if fs > ahora_cr().date() + timedelta(days=366):
        raise ValueError("La fecha de salida no puede estar a más de un año")
    inicio_periodo = date(fs.year - 1 if fs.month < 12 else fs.year, 12, 1)
    fi = _fecha(emp.get("fecha_ingreso")) or inicio_periodo
    desde_ag = max(inicio_periodo, fi)
    # meses completos reales (del día N al día N del mes siguiente) más los días sueltos entre 30 (R148)
    from calendar import monthrange as _mr
    fin = fs + timedelta(days=1)
    meses_c = (fin.year - desde_ag.year) * 12 + fin.month - desde_ag.month - (1 if fin.day < desde_ag.day else 0)
    y, mth = desde_ag.year + (desde_ag.month - 1 + meses_c) // 12, (desde_ag.month - 1 + meses_c) % 12 + 1
    ancla = date(y, mth, min(desde_ag.day, _mr(y, mth)[1]))
    meses_ag = max(0.0, meses_c + max(0, (fin - ancla).days) / 30)
    aguinaldo = r2(mensual * meses_ag / 12)
    base_ag = f"Devengado desde {desde_ag.isoformat()} entre 12"
    if devengado_aguinaldo is not None and float(devengado_aguinaldo) > 0:
        pendiente = r2(diario * float(dias_pendientes or 0))                      # lo que paga esta liquidación también es salario devengado
        aguinaldo = r2((float(devengado_aguinaldo) + pendiente) / 12)
        base_ag = f"Salarios pagados en planillas desde {desde_ag.isoformat()} ({float(devengado_aguinaldo):,.2f})" + (f" más salario pendiente ({pendiente:,.2f})" if pendiente else "") + " entre 12"
    rubros = [
        {"rubro": "Salario pendiente", "dias": r2(dias_pendientes or 0), "monto": r2(diario * float(dias_pendientes or 0)), "base": "Días trabajados y no pagados"},
        {"rubro": "Preaviso (art. 28)", "dias": d_pre, "monto": r2(diario * d_pre), "base": "Solo despido con responsabilidad patronal sin preaviso otorgado"},
        {"rubro": "Auxilio de cesantía (art. 29)", "dias": d_ces, "monto": r2(diario * d_ces), "base": "Despido con responsabilidad, pensión o fallecimiento; tope 8 años"},
        {"rubro": "Vacaciones no disfrutadas (art. 153)", "dias": d_vac, "monto": r2(diario * d_vac), "base": f"{vac['dias_ganados']} ganados − {vac['dias_disfrutados']} disfrutados"},
        {"rubro": "Aguinaldo proporcional (Ley 2412)", "dias": r2(meses_ag * 30), "monto": aguinaldo, "base": base_ag},
    ]
    # CCSS obrera sobre lo que es salario: salario pendiente y vacaciones pagadas (preaviso, cesantía y aguinaldo no cotizan) (R147)
    base_ccss = r2(sum(x["monto"] for x in rubros if x["rubro"].startswith(("Salario pendiente", "Vacaciones"))))
    pct_obrero, pct_patronal = tasa_total(params["obrero"]), _tasa_patronal_liquidacion(params)
    ccss_obrera = r2(base_ccss * pct_obrero / 100)
    if ccss_obrera:
        rubros.append({"rubro": "Deducción CCSS obrera", "dias": 0, "monto": -ccss_obrera, "base": f"{pct_obrero} % sobre salario pendiente y vacaciones ({base_ccss:,.2f})"})
    # 4.7: la patronal con las mismas tasas que la planilla (sin el INA si la empresa no lo paga, más ins_adicional); antes
    # tasa_total(params['patrono']) ignoraba paga_ina e ins_adicional. Con los parámetros de defecto el resultado no cambia
    ccss_patronal = r2(base_ccss * pct_patronal / 100)
    # 4.7 (C1): impuesto sobre la renta de lo salarial (salario pendiente y vacaciones). La retención es MENSUAL (art. 33): va sobre lo
    # ya pagado al empleado en el mes de la salida más lo salarial de esta liquidación, con los mismos tramos y créditos (hijos y
    # cónyuge) que la planilla, menos lo ya retenido en el mes (renta_complementaria); nunca más que lo salarial después de la CCSS.
    # El preaviso, la cesantía y el aguinaldo no son salario: no pagan esta renta. Se rebaja del total como un rubro de deducción.
    renta, renta_det = 0.0, None
    if base_ccss > 0 and emp.get("aplica_renta", True):
        try:
            bp, rp = float(bruto_previo or 0), float(renta_previa or 0)
        except (TypeError, ValueError):
            bp = rp = -1.0
        if not (0 <= bp < 1e13 and 0 <= rp < 1e13):            # también NaN e infinito
            raise ValueError("Lo ya pagado en el mes de la salida debe ser un monto válido")
        renta_det = renta_complementaria(base_ccss, bp, rp, params, int(emp.get("hijos") or 0), bool(emp.get("conyuge")))
        renta = r2(min(renta_det["renta"], max(0.0, base_ccss - ccss_obrera)))
        if renta > 0:
            ya = f"lo ya pagado en el mes ({_colones(bp)}) más " if bp else ""
            rubros.append({"rubro": "Deducción impuesto sobre la renta", "dias": 0, "monto": -renta, "categoria": "renta",
                           "base": f"Tramos del mes sobre {_colones(renta_det['base_mes'])} ({ya}salario pendiente y vacaciones "
                                   f"{_colones(base_ccss)}): {_colones(renta_det['renta_mes'])}" + (f" menos {_colones(rp)} ya retenidos" if rp else "")})
    total = r2(sum(x["monto"] for x in rubros))
    return {"motivo": motivo, "motivo_nombre": MOTIVOS[motivo], "fecha_salida": fs.isoformat(), "antiguedad": a, "salario_mensual": mensual, "salario_diario": diario,
            "rubros": rubros, "total": total, "vacaciones": vac, "con_responsabilidad": con_responsabilidad, "ccss_obrera": ccss_obrera, "ccss_patronal": ccss_patronal, "base_ccss": base_ccss,
            "ccss_obrera_pct": pct_obrero, "ccss_patronal_pct": pct_patronal, "renta": renta, "renta_detalle": renta_det,
            "nota": "El aguinaldo y las vacaciones proporcionales se pagan en toda salida; preaviso y cesantía solo con responsabilidad patronal. En renuncia el trabajador puede retirar su FCL en la operadora de pensiones."}


def provision_mensual(bruto_mensual: float, params: dict) -> dict:
    prov = {k: r2(float(bruto_mensual or 0) * float(t) / 100) for k, t in params["provisiones"].items()}
    return {"detalle": prov, "total": r2(sum(prov.values())), "pct": tasa_total(params["provisiones"])}


# ----------------------------------------------------------------------------- importación de empleados desde Excel o CSV (4.21)
# Solo altas. Todo lo de aquí es validación de FORMATO (largo de la identificación según su tipo, dígito de control del IBAN, fechas,
# números y las listas de opciones de la ficha): no compara salarios con mínimos ni aplica ninguna regla de la norma laboral.
MAX_BYTES_IMPORTAR = 2 * 1024 * 1024
MAX_FILAS_IMPORTAR = 500
# Lo que se lee del archivo va acotado (leer_xlsx_empleados y leer_csv_empleados): hasta MAX_FILAS_LEER filas y, de cada una,
# MAX_COLUMNAS_LEER celdas (la plantilla trae 26 columnas); y un Excel que al descomprimirse pasa de MAX_BYTES_XLSX_ABIERTO no se abre.
# Sin esos topes, un Excel de 50 KB con una celda en la última columna se volvía una tabla de 80 millones de celdas vacías (casi
# 700 MB de memoria), y un CSV de 2 MB con un millón de líneas, más de 300 MB.
MAX_BYTES_XLSX_ABIERTO = 25 * 1024 * 1024
MAX_FILAS_LEER = 5000
MAX_COLUMNAS_LEER = 200
MAX_SALARIO_IMPORTAR = 10 ** 12         # tope de cordura (no es una regla laboral): más que eso es una celda mal escrita
MAX_LETRAS_MENSAJE = 200                # cada mensaje de la revisión cabe en una celda del PDF (el reporte las corta en 200 letras)
COLUMNAS_IMPORTAR = ("nombre", "apellidos", "apellido1", "apellido2", "tipo_id", "numero_id", "nacimiento", "correo", "telefono", "puesto", "categoria",
                     "departamento", "fecha_ingreso", "jornada", "horas_semana", "modo_salario", "salario", "periodo_pago", "forma_pago", "cuenta_iban",
                     "hijos", "conyuge", "aplica_renta", "codigo_reloj", "tipo_contrato", "fecha_fin_contrato")
OBLIGATORIAS_IMPORTAR = ("nombre", "tipo_id", "numero_id", "fecha_ingreso", "modo_salario", "salario")
_TIPOS_ID_IMPORTAR = {"01": "01", "1": "01", "cedula": "01", "cedula fisica": "01", "cedula de identidad": "01", "fisica": "01",
                      "03": "03", "3": "03", "dimex": "03", "04": "04", "4": "04", "nite": "04",
                      "05": "05", "5": "05", "extranjero": "05", "extranjero no domiciliado": "05", "pasaporte": "05"}
_JORNADAS_IMPORTAR = {"diurna": "diurna", "mixta": "mixta", "nocturna": "nocturna", "medio_tiempo": "medio_tiempo", "medio tiempo": "medio_tiempo"}
_MODOS_IMPORTAR = {"hora": "hora", "por hora": "hora", "mensual": "mensual", "mensual fijo": "mensual", "mes": "mensual", "por mes": "mensual"}
_PERIODOS_IMPORTAR = {"semanal": "semanal", "bisemanal": "bisemanal", "quincenal": "quincenal", "mensual": "mensual", "manual": "manual"}
_FORMAS_IMPORTAR = {"transferencia": "transferencia", "deposito": "transferencia", "transferencia / deposito": "transferencia", "efectivo": "efectivo",
                    "cheque": "cheque", "sinpe": "sinpe", "sinpe movil": "sinpe"}
_CONTRATOS_IMPORTAR = {"indefinido": "indefinido", "tiempo indefinido": "indefinido", "plazo_fijo": "plazo_fijo", "plazo fijo": "plazo_fijo", "obra": "obra",
                       "obra determinada": "obra", "temporal": "temporal", "temporal / por temporada": "temporal", "por temporada": "temporal"}


def _clave_imp(v) -> str:
    """Texto para comparar: sin tildes, en minúsculas y sin espacios de sobra."""
    t = "".join(c for c in unicodedata.normalize("NFD", str(v if v is not None else "")) if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", t).strip().lower()


def _texto_imp(v) -> str:
    """Texto de una celda. Excel guarda 101110111 como número (101110111.0): queda sin decimales; una fecha, como AAAA-MM-DD."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "si" if v else "no"
    if isinstance(v, float) and math.isfinite(v) and v.is_integer():
        return str(int(v))
    if isinstance(v, (datetime, date)):
        return v.isoformat()[:10]
    return str(v).strip()


def csv_a_utf8(datos: bytes) -> bytes:
    """El CSV que Excel guarda en Windows suele venir en Windows-1252 y no en UTF-8: leído como UTF-8, «María» perdía la tilde.
    Si no es UTF-8 válido se toma como Windows-1252."""
    try:
        datos.decode("utf-8-sig")
        return datos
    except UnicodeDecodeError:
        return datos.decode("cp1252", errors="replace").encode("utf-8")


def leer_csv_empleados(datos: bytes) -> list:
    """Las filas (listas de celdas) de un CSV separado por «;» o por «,» (el que más aparezca en la primera línea), en UTF-8 o en
    Windows-1252. Como importacion_items._leer_csv, pero acotado: se leen hasta MAX_FILAS_LEER filas (un archivo de 2 MB puede traer
    un millón de líneas, que en memoria son cientos de MB). ValueError con el motivo si no se deja leer (por ejemplo, unas comillas
    sin cerrar que se tragan el resto del archivo)."""
    texto = csv_a_utf8(datos).decode("utf-8-sig", errors="replace")
    primera = texto.split("\n", 1)[0]
    sep = ";" if primera.count(";") >= primera.count(",") else ","
    try:
        return [list(r) for r in islice(csv.reader(io.StringIO(texto), delimiter=sep), MAX_FILAS_LEER)]
    except csv.Error:
        raise ValueError("No se pudo leer el archivo CSV: ábralo en Excel, guárdelo de nuevo como CSV o como «Libro de Excel (.xlsx)» y súbalo otra vez")


_NO_SE_LEE_XLSX = "No se pudo leer el archivo de Excel: guárdelo de nuevo como «Libro de Excel (.xlsx)» o como CSV y súbalo otra vez"
_XLSX_NO_VALIDO = ("El archivo no es un Excel válido (trae contenido que un libro de Excel no lleva): guárdelo de nuevo desde Excel como "
                   "«Libro de Excel (.xlsx)» o como CSV y súbalo otra vez")
_DTD_XML = re.compile(rb"<!(?:DOCTYPE|ENTITY)", re.I)


def _parte_xml_rara(parte: bytes) -> bool:
    """4.22: ¿esta parte XML de un .xlsx trae algo que un libro de Excel de verdad nunca lleva? Una declaración de tipo de documento
    o de entidades (<!DOCTYPE, <!ENTITY: por ahí entran las entidades que se expanden sin fin o que leen otros archivos), o un
    comienzo que no es UTF-8: la marca de UTF-16 (FE FF o FF FE) o un byte nulo entre los cuatro primeros (UTF-16 o UTF-32 sin
    marca), con los que esas declaraciones no se verían al buscarlas."""
    return parte[:2] in (b"\xfe\xff", b"\xff\xfe") or b"\x00" in parte[:4] or _DTD_XML.search(parte) is not None


def leer_xlsx_empleados(datos: bytes) -> list:
    """Las filas (listas de celdas) de la primera hoja del Excel que no sea «Instrucciones», leídas en memoria. Como
    importacion_items._leer_xlsx, pero acotado: no abre un libro que descomprimido pasa de MAX_BYTES_XLSX_ABIERTO y recorre hasta
    MAX_FILAS_LEER filas y MAX_COLUMNAS_LEER columnas de la hoja (lo que haya más allá no se lee). ValueError con el motivo, en
    español, si el archivo no se puede leer (no es un libro de Excel, está dañado o no tiene hojas).
    4.22: antes de abrir el libro se recorren sus partes .xml y .rels (ya acotadas por el tope de arriba) y no se abre si alguna
    trae <!DOCTYPE o <!ENTITY o no viene en UTF-8 (_parte_xml_rara): así no depende de cómo trate las entidades la versión de la
    biblioteca de XML que tenga el hospedaje."""
    raro = False
    try:
        with zipfile.ZipFile(io.BytesIO(datos)) as z:
            partes = z.infolist()
            abierto = sum(i.file_size for i in partes)
            if abierto <= MAX_BYTES_XLSX_ABIERTO:
                raro = any(_parte_xml_rara(z.read(i)) for i in partes if i.filename.lower().endswith((".xml", ".rels")) and not i.filename.lower().startswith("customxml/"))   # openpyxl no lee customXml/ (Office lo puede guardar en UTF-16)
    except Exception:  # noqa: BLE001
        raise ValueError(_NO_SE_LEE_XLSX)
    if abierto > MAX_BYTES_XLSX_ABIERTO:
        raise ValueError("El archivo de Excel es demasiado grande al abrirlo: deje solo la hoja con los empleados o guárdelo como CSV")
    if raro:
        raise ValueError(_XLSX_NO_VALIDO)
    libro = None
    try:
        from openpyxl import load_workbook
        libro = load_workbook(io.BytesIO(datos), read_only=True, data_only=True)
        hoja = next((h for h in libro.worksheets if _clave_imp(h.title) not in ("instrucciones", "instructions")), None) or libro.worksheets[0]
        return [list(f) for f in hoja.iter_rows(values_only=True, max_row=MAX_FILAS_LEER, max_col=MAX_COLUMNAS_LEER)]
    except Exception:  # noqa: BLE001  una hoja dañada o una celda imposible falla al recorrerla, no al abrir el libro
        raise ValueError(_NO_SE_LEE_XLSX)
    finally:
        if libro is not None:
            try:
                libro.close()
            except Exception:  # noqa: BLE001
                pass


def validar_identificacion(tipo_id, numero) -> Optional[str]:
    """El problema de formato de una identificación según su tipo, o None si está bien. La misma regla de la ficha del empleado:
    cédula física (01) de 9 dígitos, DIMEX (03) de 11 o 12 dígitos, NITE (04) y extranjero (05) de 1 a 20 letras o números."""
    n = str(numero if numero is not None else "")
    if tipo_id == "01":
        return None if re.fullmatch(r"[0-9]{9}", n) else "la cédula física debe tener 9 dígitos, sin guiones"
    if tipo_id == "03":
        return None if re.fullmatch(r"[0-9]{11,12}", n) else "el DIMEX debe tener 11 o 12 dígitos"
    if tipo_id in ("04", "05"):
        return None if re.fullmatch(r"[A-Za-z0-9]{1,20}", n) else "la identificación debe tener de 1 a 20 letras o números, sin guiones ni espacios"
    return "el tipo de identificación no es válido (Cédula, DIMEX, NITE o Extranjero)"


def iban_cr_valido(v) -> bool:
    """¿Es un IBAN de Costa Rica bien formado? «CR» + 20 dígitos y dígitos de control correctos (ISO 13616: módulo 97 = 1). Es el
    estándar bancario de la cuenta, no una norma laboral. No dice si la cuenta existe."""
    t = re.sub(r"\s+", "", str(v if v is not None else "")).upper()
    if not re.fullmatch(r"CR[0-9]{20}", t):                # [0-9] y no \d: los dígitos de otros alfabetos no son una cuenta
        return False
    return int(t[4:] + "1227" + t[2:4]) % 97 == 1          # C = 12, R = 27


def numero_importado(v) -> Optional[float]:
    """Número de una celda: 450000, «450000,50», «450.000,50», «1,234,567.89» o «₡ 450 000». None si está vacía. ValueError si no es
    un número, o si un único punto o coma seguido de tres dígitos no deja saber si separa miles o decimales («450.000»)."""
    if v is None:
        return None
    if isinstance(v, bool):
        raise ValueError("no es un número")
    if isinstance(v, (int, float)):
        try:
            n = float(v)
        except OverflowError:                                # un entero de cientos de dígitos en una celda de Excel
            raise ValueError("no es un número")
        if not math.isfinite(n):
            raise ValueError("no es un número")
        return n
    t = re.sub(r"[\s₡¢$]", "", str(v))
    if not t:
        return None
    if not re.fullmatch(r"-?\d[\d.,]*", t):
        raise ValueError("no es un número")
    puntos, comas = t.count("."), t.count(",")
    if puntos and comas:
        dec = "," if t.rfind(",") > t.rfind(".") else "."
        if t.count(dec) > 1:
            raise ValueError("no es un número")
        t = t.replace("." if dec == "," else ",", "").replace(dec, ".")
    elif puntos + comas > 1:                                 # varios iguales: separan miles
        sep = "." if puntos else ","
        partes = t.lstrip("-").split(sep)
        if not (1 <= len(partes[0]) <= 3 and all(len(p) == 3 for p in partes[1:])):
            raise ValueError("no es un número")
        t = t.replace(sep, "")
    elif puntos + comas == 1:
        sep = "." if puntos else ","
        entero, decimales = t.lstrip("-").split(sep)
        if len(decimales) == 3 and 1 <= len(entero) <= 3 and not entero.startswith("0"):
            raise ValueError("no se sabe si el separador es de miles o de decimales: escríbalo sin separador de miles (450000) o con dos decimales (450000,00)")
        t = t.replace(sep, ".")
    n = float(t)
    if not math.isfinite(n):                                 # cientos de dígitos: float() devuelve infinito, que no se puede guardar
        raise ValueError("no es un número")
    return n


def _fecha_importada(v) -> Optional[str]:
    """AAAA-MM-DD de una celda de fecha de Excel, de «AAAA-MM-DD» o de «DD/MM/AAAA». None si está vacía; ValueError si no es una fecha."""
    if isinstance(v, datetime):
        f = v.date()
    elif isinstance(v, date):
        f = v
    else:
        t = _texto_imp(v)
        if not t:
            return None
        m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", t)
        if m:
            a, mes, dia = int(m.group(1)), int(m.group(2)), int(m.group(3))
        else:
            m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", t)
            if not m:
                raise ValueError("fecha no válida")
            dia, mes, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
        f = date(a, mes, dia)                                # ValueError si no existe en el calendario
    if not 1900 <= f.year <= 2100:
        raise ValueError("fecha no válida")
    return f.isoformat()


def _si_no_importado(v) -> Optional[bool]:
    t = _clave_imp(_texto_imp(v))
    if not t:
        return None
    if t in ("si", "s", "1", "true", "verdadero", "x", "yes"):
        return True
    if t in ("no", "n", "0", "false", "falso"):
        return False
    raise ValueError("debe ser Sí o No")


def _entero(n: float):
    return int(n) if float(n).is_integer() else n


def normalizar_fila_empleado(fila: dict, params: dict, departamentos: list) -> tuple:
    """Una fila del archivo (valores por columna de COLUMNAS_IMPORTAR) → (empleado con la forma de una ficha nueva, errores, avisos).
    Convierte Sí/No, fechas (AAAA-MM-DD o DD/MM/AAAA), números con coma decimal, el tipo de identificación por nombre o código, y
    la jornada, el modo de salario, el período, la forma de pago y el tipo de contrato por su nombre. La categoría debe existir en
    los parámetros (vacía, toma la del puesto o la de una ficha nueva y avisa); el departamento se busca por nombre (si no existe,
    queda como texto y avisa). Con errores, la fila no se importa. Solo formato: no compara el salario con ningún mínimo."""
    err, avi = [], []

    def texto(k, tope, nombre):
        t = _texto_imp(fila.get(k))
        if len(t) > tope:
            err.append(f"{nombre} demasiado largo (máximo {tope} letras)")
            return t[:tope]
        return t

    def opcion(k, opciones, defecto, nombre, validas):
        t = _clave_imp(_texto_imp(fila.get(k)))
        if not t:
            return defecto
        if t not in opciones:
            err.append(f"{nombre} «{_texto_imp(fila.get(k))[:40]}» no es válido: use {validas}")
            return defecto
        return opciones[t]

    def fecha(k, nombre):
        try:
            return _fecha_importada(fila.get(k)) or ""
        except ValueError:
            err.append(f"{nombre} «{_texto_imp(fila.get(k))[:40]}» no es una fecha válida: use AAAA-MM-DD o DD/MM/AAAA")
            return ""

    def si_no(k, defecto, nombre):
        try:
            v = _si_no_importado(fila.get(k))
        except ValueError:
            err.append(f"{nombre}: escriba Sí o No")
            return defecto
        return defecto if v is None else v

    nombre = texto("nombre", 80, "nombre")
    a1, a2 = texto("apellido1", 60, "primer apellido"), texto("apellido2", 60, "segundo apellido")
    apellidos = texto("apellidos", 120, "apellidos") or " ".join(x for x in (a1, a2) if x)
    if not nombre:
        err.append("falta el nombre")
    crudo_tipo = _clave_imp(_texto_imp(fila.get("tipo_id")))
    tipo = _TIPOS_ID_IMPORTAR.get(crudo_tipo)
    if not crudo_tipo:
        err.append("falta el tipo de identificación (Cédula, DIMEX, NITE o Extranjero)")
    elif tipo is None:
        err.append(f"tipo de identificación «{_texto_imp(fila.get('tipo_id'))[:40]}» no es válido: use Cédula, DIMEX, NITE o Extranjero (o 01, 03, 04, 05)")
    numero = re.sub(r"[^A-Za-z0-9]", "", _texto_imp(fila.get("numero_id"))).upper()
    if not numero:
        err.append("falta el número de identificación")
    elif tipo:
        problema = validar_identificacion(tipo, numero)
        if problema:
            err.append(problema + (" (si Excel le quitó ceros a la izquierda, escriba la celda como texto)" if tipo in ("01", "03") and numero.isdigit() else ""))
    nacimiento = fecha("nacimiento", "fecha de nacimiento")
    correo = texto("correo", 120, "correo").lower()
    if correo and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", correo):
        err.append("el correo no tiene un formato válido")
    telefono = texto("telefono", 20, "teléfono")
    puesto = texto("puesto", 80, "puesto")
    # categoría del decreto: por código o por nombre; vacía, la del puesto (si es uno de la lista) o la de una ficha nueva
    categorias = [c for c in (params.get("categorias") or CATEGORIAS) if isinstance(c, dict)]
    crudo_cat = _clave_imp(_texto_imp(fila.get("categoria")))
    categoria = next((c["codigo"] for c in categorias if crudo_cat and crudo_cat in (_clave_imp(c.get("codigo")), _clave_imp(c.get("nombre")))), None)
    if crudo_cat and categoria is None:
        err.append(f"categoría «{_texto_imp(fila.get('categoria'))[:40]}» no existe en Recursos humanos › Parámetros: use su código ({', '.join(str(c.get('codigo')) for c in categorias[:20])})")
    elif not crudo_cat:
        del_puesto = next((c for n, c in PUESTOS if _clave_imp(n) == _clave_imp(puesto)), None) if puesto else None
        categoria = del_puesto if del_puesto and any(c.get("codigo") == del_puesto for c in categorias) else "TOSC"
        avi.append(f"sin categoría: quedó {categoria}; revísela en la ficha")
    crudo_depto = texto("departamento", 80, "departamento")
    depto = next((d for d in departamentos if isinstance(d, dict) and d.get("nombre") and _clave_imp(d.get("nombre")) == _clave_imp(crudo_depto)), None) if crudo_depto else None
    if crudo_depto and depto is None:
        avi.append(f"el departamento «{crudo_depto[:40]}» no existe: queda como texto; créelo en Horarios de trabajo y asígnelo en la ficha")
    ingreso = fecha("fecha_ingreso", "fecha de ingreso")
    if not ingreso and not _texto_imp(fila.get("fecha_ingreso")):
        err.append("falta la fecha de ingreso")
    jornada = opcion("jornada", _JORNADAS_IMPORTAR, "diurna", "jornada", "diurna, mixta, nocturna o medio_tiempo")
    horas = None
    try:
        horas = numero_importado(fila.get("horas_semana"))
    except ValueError:
        err.append("horas por semana: no es un número")
    if horas is None:
        horas = float(((params.get("jornadas") or PARAMETROS["jornadas"]).get(jornada) or PARAMETROS["jornadas"]["diurna"])["semana"])
    elif not 0 < horas <= 168:
        err.append("horas por semana: debe ser un número mayor que 0 (una semana tiene 168 horas)")
    crudo_modo = _clave_imp(_texto_imp(fila.get("modo_salario")))
    modo = _MODOS_IMPORTAR.get(crudo_modo)
    if not crudo_modo:
        err.append("falta el modo de salario (hora o mensual)")
    elif modo is None:
        err.append(f"modo de salario «{_texto_imp(fila.get('modo_salario'))[:40]}» no es válido: use hora o mensual")
    salario = None
    try:
        salario = numero_importado(fila.get("salario"))
        if salario is None:
            err.append("falta el salario")
        elif salario < 0:
            err.append("el salario no puede ser negativo")
        elif salario == 0:
            err.append("el salario debe ser mayor que cero")
        elif salario > MAX_SALARIO_IMPORTAR:
            err.append("el salario es demasiado grande: revise la celda")
    except ValueError as ex:
        err.append(f"salario «{_texto_imp(fila.get('salario'))[:40]}»: {ex}")
    periodo = opcion("periodo_pago", _PERIODOS_IMPORTAR, "quincenal", "período de pago", "semanal, bisemanal, quincenal, mensual o manual")
    forma = opcion("forma_pago", _FORMAS_IMPORTAR, "transferencia", "forma de pago", "transferencia, efectivo, cheque o sinpe")
    iban = re.sub(r"\s+", "", _texto_imp(fila.get("cuenta_iban"))).upper()
    if iban and not re.fullmatch(r"CR[0-9]{20}", iban):
        err.append("IBAN inválido (debe ser CR seguido de 20 dígitos)")
    elif iban and not iban_cr_valido(iban):
        err.append("IBAN inválido (dígito de control)")
    hijos = 0
    try:
        h = numero_importado(fila.get("hijos"))
        if h is not None and (h < 0 or h > 30 or not float(h).is_integer()):
            err.append("hijos: debe ser un número entero de 0 a 30")
        elif h is not None:
            hijos = int(h)
    except ValueError:
        err.append("hijos: no es un número")
    conyuge = si_no("conyuge", False, "cónyuge")
    renta = si_no("aplica_renta", True, "aplica_renta")
    reloj = _texto_imp(fila.get("codigo_reloj"))
    if reloj:
        if not re.fullmatch(r"[0-9]{1,4}", reloj) or int(reloj) == 0:
            err.append("el código de reloj debe ser un número de 1 a 4 dígitos (por ejemplo 1, 01 o 0001)")
            reloj = ""
        else:
            reloj = reloj.zfill(4)
    contrato = opcion("tipo_contrato", _CONTRATOS_IMPORTAR, "indefinido", "tipo de contrato", "indefinido, plazo_fijo, obra o temporal")
    fin = fecha("fecha_fin_contrato", "fecha de fin del contrato")
    if contrato == "indefinido":
        fin = ""
    elif fin and ingreso and fin < ingreso:
        err.append("la fecha de fin del contrato no puede ser anterior al ingreso")
    sal = _entero(salario) if salario is not None and 0 < salario <= MAX_SALARIO_IMPORTAR else None
    emp = {"nombre": nombre, "apellidos": apellidos, "apellido1": a1, "apellido2": a2, "tipo_id": tipo or "01", "numero_id": numero, "nacimiento": nacimiento,
           "nacionalidad": "Costarricense" if tipo == "01" else "", "correo": correo, "telefono": telefono, "direccion": "", "emergencia_nombre": "",
           "emergencia_telefono": "", "hijos": hijos, "conyuge": conyuge, "puesto": puesto, "categoria": categoria or "TOSC", "fecha_ingreso": ingreso,
           "jornada": jornada, "horas_semana": _entero(horas), "modo_salario": modo or "hora", "salario_hora": sal if modo != "mensual" else None,
           "salario_mensual": sal if modo == "mensual" else None, "periodo_pago": periodo, "forma_pago": forma, "cuenta_iban": iban, "aplica_renta": renta,
           "ins_riesgos": None, "activo": True, "fecha_salida": "", "notas": "", "tipo_contrato": contrato, "fecha_fin_contrato": fin,
           "departamento": depto["nombre"] if depto else crudo_depto, "departamento_id": depto.get("id") if depto else None, "supervisor": "", "codigo_reloj": reloj,
           "vence_id": "", "vence_permiso": ""}      # 4.22: vencimientos de la identificación y del permiso (se llenan en la ficha)
    return emp, err, avi


def _columna_imp(v) -> str:
    """Nombre de columna de un encabezado: sin tildes, mayúsculas ni signos («Número ID *» → numero_id)."""
    return re.sub(r"[^a-z0-9]+", "_", _clave_imp(_texto_imp(v))).strip("_")


def filas_importar_empleados(tabla: list) -> tuple:
    """La tabla leída del archivo (lista de filas de celdas) → (filas como diccionarios por columna, con `_fila` = número de fila en
    el archivo; encabezados que no se usan). El encabezado es la primera fila que trae «nombre» y «numero_id» (el Excel de la
    plantilla lleva un título encima). ValueError con el motivo si está vacío, si no hay encabezados, si faltan columnas obligatorias
    (se dicen cuáles: no se adivina), si una columna viene repetida o si trae más de MAX_FILAS_IMPORTAR empleados. De cada fila
    cuentan las primeras MAX_COLUMNAS_LEER celdas."""
    filas = [(n, list(f[:MAX_COLUMNAS_LEER])) for n, f in enumerate(tabla or [], start=1) if isinstance(f, (list, tuple))]
    filas = [(n, f) for n, f in filas if any(_texto_imp(c) for c in f)]
    if not filas:
        raise ValueError("El archivo está vacío")
    pos = next((i for i, (_, f) in enumerate(filas[:15]) if {"nombre", "numero_id"} <= {_columna_imp(c) for c in f}), None)
    if pos is None:
        raise ValueError("No se encontraron los encabezados de la plantilla (nombre, tipo_id, numero_id, fecha_ingreso, modo_salario, salario…): "
                         "descargue la plantilla y copie ahí sus datos sin cambiar la fila de encabezados")
    cab = [_columna_imp(c) for c in filas[pos][1]]
    faltan = [c for c in OBLIGATORIAS_IMPORTAR if c not in cab]
    if faltan:
        raise ValueError("Al archivo le faltan columnas obligatorias: " + ", ".join(faltan) + ". Use los encabezados de la plantilla")
    repetida = next((c for c in COLUMNAS_IMPORTAR if cab.count(c) > 1), None)
    if repetida:
        raise ValueError(f"La columna «{repetida}» está dos veces en el archivo: deje una sola")
    datos = filas[pos + 1:]
    if not datos:
        raise ValueError("El archivo solo trae los encabezados: agregue una fila por empleado")
    if len(datos) > MAX_FILAS_IMPORTAR:
        mas = "más de " if len(tabla) >= MAX_FILAS_LEER else ""       # los lectores se detienen en MAX_FILAS_LEER: de ahí en adelante no se cuenta
        raise ValueError(f"El archivo trae {mas}{len(datos)} filas y se importan hasta {MAX_FILAS_IMPORTAR} por archivo: divídalo en varios")
    idx = {c: i for i, c in enumerate(cab) if c in COLUMNAS_IMPORTAR}
    ignoradas = [_texto_imp(filas[pos][1][i])[:40] for i, c in enumerate(cab) if c and c not in COLUMNAS_IMPORTAR][:30]
    return [{"_fila": n, **{c: (f[i] if i < len(f) else None) for c, i in idx.items()}} for n, f in datos], ignoradas


def clave_identificacion(v) -> str:
    """4.22: una identificación lista para compararla con otra: sin guiones, espacios ni otros signos, en mayúsculas y, si quedan
    solo dígitos, sin ceros a la izquierda. Una ficha vieja guardada como «01-1011-0111» (la cédula con el cero de las diez
    posiciones) y una fila del archivo con «110110111» son la misma persona. Solo sirve para comparar: no cambia lo que se guarda."""
    k = re.sub(r"[^A-Za-z0-9]", "", str(v if v is not None else "")).upper()
    return (k.lstrip("0") or "0") if re.fullmatch(r"[0-9]+", k) else k


def revisar_importacion_empleados(filas: list, existentes: list, params: dict, departamentos: list) -> dict:
    """Valida las filas de un archivo de empleados contra sí mismas y contra los empleados que ya existen. Devuelve
    {filas: [{fila, nombre, numero_id, estado, errores, avisos}], empleados: [los que se pueden importar, en orden], validas,
    con_error, con_avisos}. Además del formato de cada fila (normalizar_fila_empleado): la identificación y el código de reloj no se
    repiten dentro del archivo (la primera fila queda; las siguientes dicen en cuál está) ni son de un empleado que ya existe, activo
    o inactivo (un recontratado se reactiva desde su ficha). Las identificaciones se comparan con clave_identificacion (4.22: sin
    guiones y, las de solo dígitos, sin ceros a la izquierda), tanto contra los existentes como dentro del archivo. La fila de
    ejemplo de la plantilla nunca se importa. Cada mensaje sale con MAX_LETRAS_MENSAJE letras como máximo."""
    nombre_de = lambda e: " ".join(str(e.get(k) or "").strip() for k in ("nombre", "apellidos")).strip() or "otro empleado"   # noqa: E731
    corto = lambda m: m if len(m) <= MAX_LETRAS_MENSAJE else m[:MAX_LETRAS_MENSAJE - 1] + "…"                                 # noqa: E731
    existentes = [e for e in (existentes or []) if isinstance(e, dict)]
    departamentos = [d for d in (departamentos or []) if isinstance(d, dict)]
    por_numero = {}
    for e in existentes:
        k = clave_identificacion(e.get("numero_id") or "")
        if k:
            por_numero.setdefault(k, e)
    por_reloj = {str(e.get("codigo_reloj")).strip().zfill(4): e for e in existentes if str(e.get("codigo_reloj") or "").strip()}
    vistos_numero, vistos_reloj, out, empleados = {}, {}, [], []
    for f in filas:
        n = f.get("_fila")
        if _clave_imp(_texto_imp(f.get("nombre"))).startswith("ejemplo"):
            out.append({"fila": n, "nombre": _texto_imp(f.get("nombre"))[:120], "numero_id": _texto_imp(f.get("numero_id"))[:20], "estado": "Con errores",
                        "errores": ["es la fila de ejemplo de la plantilla: bórrela o cámbiela por un empleado"], "avisos": []})
            continue
        emp, err, avi = normalizar_fila_empleado(f, params, departamentos)
        numero, reloj = emp["numero_id"], emp["codigo_reloj"]
        if numero:
            clave = clave_identificacion(numero)
            if clave in vistos_numero:
                err.append(f"identificación repetida en el archivo, fila {vistos_numero[clave]}")
            else:
                vistos_numero[clave] = n
                ya = por_numero.get(clave)
                if ya is not None:
                    err.append("ya existe: " + nombre_de(ya) + (" (está inactivo: reactívelo desde su ficha)" if ya.get("activo") is False else ""))
        if reloj:
            if reloj in vistos_reloj:
                err.append(f"código de reloj {reloj} repetido en el archivo, fila {vistos_reloj[reloj]}")
            else:
                vistos_reloj[reloj] = n
                ya = por_reloj.get(reloj)
                if ya is not None:
                    err.append(f"código de reloj {reloj} ya es de {nombre_de(ya)}")
        out.append({"fila": n, "nombre": (" ".join(x for x in (emp["nombre"], emp["apellidos"]) if x) or "—")[:120], "numero_id": numero[:20],
                    "estado": "Con errores" if err else "Con avisos" if avi else "Lista", "errores": [corto(m) for m in err], "avisos": [corto(m) for m in avi]})
        if not err:
            empleados.append(emp)
    return {"filas": out, "empleados": empleados, "validas": len(empleados), "con_error": sum(1 for x in out if x["estado"] == "Con errores"),
            "con_avisos": sum(1 for x in out if x["estado"] == "Con avisos")}


# ----------------------------------------------------------------------------- cargas del mes por pagar (4.22)
# Lo que la empresa debe por las planillas y las liquidaciones de un mes: a la CCSS (la cuota obrera retenida y las cargas patronales),
# al INS (riesgos del trabajo) y a Hacienda (la renta retenida a los salarios). Aquí NO se calcula ninguna tasa: se suman los mismos
# campos guardados con que el asiento automático acredita esos pasivos (asientoPlanilla y asientoLiquidacion, en
# static/js/pages/contabilidad/automaticos.js), con sus mismas reglas y su mismo redondeo, para que el pago de las cargas cancele
# exactamente lo que quedó en los libros. Si ese asiento cambia, esto cambia con él (tests/test_rrhh_pago_cargas.py los compara).
TIPOS_CARGA = {"ccss": "CCSS", "ins": "INS", "renta": "Renta"}
NOMBRE_CARGA = {"ccss": "CCSS (cuota obrera y cargas patronales)", "ins": "INS (riesgos del trabajo)", "renta": "Renta retenida a los salarios"}
# El mes (AAAA-MM) en que sale el pago de las cargas: noviembre de 2026. Las cargas de los meses ANTERIORES se pagaban fuera de esta
# función (a mano: un movimiento en Bancos y un asiento manual), y el sistema no tiene cómo saber si ya están pagadas. Por eso no se
# ofrecen como «pendientes» y registrarlas aquí pide una confirmación aparte: sin ella una empresa con años de planillas las «pondría
# al día» y duplicaría salidas en Bancos y asientos, y un pago registrado no se elimina. Es una fecha del producto, no una regla
# laboral: no se mueve con las versiones siguientes.
MES_INICIO_PAGO_CARGAS = "2026-11"
_NUMERO_JS = re.compile(r"[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?")
_ES_ASOCIACION = re.compile(r"asociaci|solidari|(^|[^a-z])ase([^a-z]|\Z)", re.I | re.A)      # «esAse» del asiento: el aporte patronal a la asociación solidarista


def _num_js(v: Any) -> float:
    """El número de un campo guardado como lo lee el navegador con «+v || 0»: un número, o un texto que sea un número; lo demás
    (vacío, nulo, otro texto, una lista o un objeto) vale 0."""
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    try:
        if isinstance(v, (int, float)):
            n = float(v)
        elif isinstance(v, str) and _NUMERO_JS.fullmatch(v.strip()):
            n = float(v.strip())
        else:
            return 0.0
    except OverflowError:
        return 0.0
    return n if math.isfinite(n) else 0.0


def _r2_js(n: float) -> float:
    """Redondeo a dos decimales del asiento (Math.round(n * 100) / 100: el medio céntimo sube siempre)."""
    x = n * 100
    piso = math.floor(x)
    return (piso + 1 if x - piso >= 0.5 else piso) / 100


def _suma_js(valores) -> float:
    """Suma de izquierda a derecha, como el reduce del asiento (sum() de Python compensa el error de redondeo y puede diferir)."""
    s = 0.0
    for x in valores:
        s += x
    return s


def pasivos_planilla(pl: Any) -> Optional[dict]:
    """Lo que el asiento de una planilla deja por pagar: {ccss_obrero, ccss_patronal, ins, renta}. None si la planilla no lleva
    asiento (sin id, sin totales o con el bruto en cero). Como asientoPlanilla: la cuota obrera es totales.total_obrero; la renta,
    totales.renta; el INS, la suma de patrono.ins_riesgos de las filas; y las cargas patronales, totales.total_patronal menos ese
    INS y menos el aporte patronal a la asociación solidarista que venga dentro de las cargas (va a otra cuenta). El INS aparte de
    la póliza (ins_adicional) queda dentro de las cargas patronales, como en el asiento."""
    t = pl.get("totales") if isinstance(pl, dict) else None
    if not isinstance(t, dict) or not pl.get("id") or not _num_js(t.get("bruto")) > 0:
        return None
    patronos = [f.get("patrono") if isinstance(f.get("patrono"), dict) else {} for f in (pl.get("filas") if isinstance(pl.get("filas"), list) else []) if isinstance(f, dict)]
    asociacion = _suma_js(_r2_js(_suma_js(_num_js(v) for k, v in p.items() if _ES_ASOCIACION.search(str(k or "")))) for p in patronos)
    ins = _r2_js(_suma_js(_num_js(p.get("ins_riesgos")) for p in patronos))
    return {"ccss_obrero": _r2_js(_num_js(t.get("total_obrero"))), "ccss_patronal": _r2_js(_num_js(t.get("total_patronal")) - ins - asociacion), "ins": ins,
            "renta": _r2_js(_num_js(t.get("renta")))}


def pasivos_liquidacion(lq: Any) -> Optional[dict]:
    """Lo que el asiento de una liquidación deja por pagar: {ccss_obrero, ccss_patronal, ins, renta}. None si no lleva asiento (sin
    id o con el total en cero). Como asientoLiquidacion: los rubros negativos de CCSS y de renta (por su categoría si la traen; si
    no, por su nombre) son la cuota obrera y la renta retenidas, y ccss_patronal es la carga patronal. La liquidación no deja INS."""
    if not isinstance(lq, dict) or not lq.get("id") or not _num_js(lq.get("total")) > 0:
        return None
    rebajos = {"ccss_obrero": 0.0, "renta": 0.0}
    for r in (lq.get("rubros") if isinstance(lq.get("rubros"), list) else []):
        m = _num_js(r.get("monto")) if isinstance(r, dict) else 0.0
        if not m < 0:
            continue
        cat = r.get("categoria")
        if cat:
            cuenta = "ccss_obrero" if cat == "ccss" else "renta" if cat == "renta" else None
        else:
            nombre = str(r.get("rubro") or "")
            cuenta = "ccss_obrero" if re.search("ccss", nombre, re.I | re.A) else "renta" if re.search("renta", nombre, re.I | re.A) else None
        if cuenta:
            rebajos[cuenta] -= m
    positivo = lambda n: n if n > 0 else 0.0                                              # noqa: E731  el asiento solo lleva la línea si el monto es mayor que cero
    return {"ccss_obrero": positivo(_r2_js(rebajos["ccss_obrero"])), "ccss_patronal": positivo(_r2_js(_num_js(lq.get("ccss_patronal")))), "ins": 0.0,
            "renta": positivo(_r2_js(rebajos["renta"]))}


def _mes_de(doc: dict, *campos: str) -> str:
    """El mes (AAAA-MM) de la fecha con que el asiento registra el documento: el primero de `campos` que tenga valor."""
    return str(next((doc.get(k) for k in campos if doc.get(k)), ""))[:7]


def _pagado(_clave: str, x: Any) -> bool:
    """¿La planilla o la liquidación ya se pagó? Estado Pagada (sin importar mayúsculas ni espacios) o con fecha de pago: la regla
    del servidor (main._rrhh_pagado, que es la que main le pasa a cargas_mes)."""
    return isinstance(x, dict) and (str(x.get("estado") or "").strip().lower() in ("pagada", "pagado") or bool(x.get("pagada_en")))


def cargas_mes(mes: str, planillas: Any, liquidaciones: Any, pagada=None) -> dict:
    """Las cargas de un mes (AAAA-MM) según lo guardado: la suma de los pasivos de las planillas PAGADAS cuyo período cierra en el
    mes (`hasta`; sin ella, `fecha`) y de las liquidaciones PAGADAS con salida en el mes (`fecha_salida`; sin ella, `fecha`), que son
    las fechas con que el asiento las registra. Devuelve {mes, ccss_obrero, ccss_patronal, ccss (las dos), ins, renta, planillas y
    liquidaciones (los ids que suman), sin_pagar: {planillas, liquidaciones} (los números de las del mes que no están pagadas: con
    alguna, las cargas del mes todavía no se pueden dar por completas)}. `pagada(clave, documento)`: cuándo cuenta como pagado."""
    pagada = pagada or _pagado
    tot = {"ccss_obrero": 0.0, "ccss_patronal": 0.0, "ins": 0.0, "renta": 0.0}
    ids: dict = {"planillas": [], "liquidaciones": []}
    sin: dict = {"planillas": [], "liquidaciones": []}
    for clave, lista, campos, pasivos in (("planillas", planillas, ("hasta", "fecha"), pasivos_planilla), ("liquidaciones", liquidaciones, ("fecha_salida", "fecha"), pasivos_liquidacion)):
        del_mes = [d for d in (lista if isinstance(lista, list) else []) if isinstance(d, dict) and _mes_de(d, *campos) == mes]
        for d in sorted(del_mes, key=lambda d: (d["id"] if isinstance(d.get("id"), int) else 0, str(d.get("id")))):   # por id: el orden en que se crearon
            if not pagada(clave, d):
                sin[clave].append(str(d.get("numero") or d.get("id") or "sin número")[:40])
                continue
            p = pasivos(d)
            if p is None:
                continue
            ids[clave].append(d.get("id"))
            for k in tot:
                tot[k] += p[k]
    tot = {k: _r2_js(v) for k, v in tot.items()}
    return {"mes": mes, **tot, "ccss": _r2_js(tot["ccss_obrero"] + tot["ccss_patronal"]), "planillas": ids["planillas"], "liquidaciones": ids["liquidaciones"], "sin_pagar": sin}


def monto_carga(cargas: dict, tipo: str) -> float:
    """El monto por pagar de un tipo de carga ('ccss', 'ins' o 'renta') dentro de lo que devuelve cargas_mes."""
    if tipo not in TIPOS_CARGA:
        raise ValueError("El tipo de carga no es válido: CCSS, INS o Renta")
    return float(cargas.get(tipo) or 0)
