# -*- coding: utf-8 -*-
"""Sincronización entre la nube y las instalaciones locales (etapa 2 del instalable, 3.12; etapa 2b, 3.13).

Una instalación local es el mismo sistema corriendo en una computadora del negocio (FE_MODO_LOCAL=1), con su propia base de
datos, que sigue trabajando sin internet. Se vincula a la empresa de la nube con un código de un solo uso que genera un
administrador en Configuración › Instalación local; a cambio recibe un token de API de la empresa, sus datos, sus credenciales
de Hacienda (usuario, clave y llave .p12 con PIN) y un número de terminal propio para que los consecutivos nunca choquen.

Cada pocos minutos, mientras haya internet, la instalación local:
  - SUBE a la nube lo que creó: clientes e ítems nuevos, los comprobantes que emitió (XML firmado, respuesta de Hacienda y
    estado), los cobros recibidos y los registros operativos (cajas y ventas del punto de venta, reservas, huéspedes, folios,
    depósitos, cierres, reportes de habitación, agenda de servicios, eventos, preventivo y seguridad). La nube los guarda tal
    cual, sin renumerar, y rebaja su propio inventario como si los hubiera emitido ella.
  - BAJA de la nube los catálogos (clientes, ítems, bodegas y los registros de configuración), los datos de la empresa y las
    existencias, que quedan iguales a las de la nube (la nube es la que manda en inventario).
Los ids nunca chocan porque cada instalación crea los suyos en su propio rango (modulos.RANGO): la nube de 1 a 9 999 999 y la
terminal t desde t·10 000 000. Lo que crea una instalación es de ella: la nube lo ve y lo reporta; los cambios que la nube haga
a esos elementos no bajan (etapa 3).

Red local (etapa 3, 3.14): las computadoras del mismo local se mandan directamente lo que cambia, sin pasar por la nube ni
necesitar internet: cada una tiene en Configuración › Instalación local la lista de las demás (dirección http://IP:8020) y una
misma clave de red. Cada 30 segundos manda a cada una sus comprobantes nuevos (XML incluido), sus clientes e ítems nuevos y los
cambios de los registros operativos (cajas, ventas, cuentas abiertas, reservas, folios…) de cualquier rango: gana el último
cambio por fecha, y las bajas viajan como lápidas. Lo que una computadora recibe de otra no lo sube a la nube (lo sube la que
lo creó), salvo los elementos propios que otra computadora editó, que vuelven a subir. Ninguna computadora es indispensable.

Lado nube: POST /api/sinc/codigo (administrador), POST /api/sinc/canje (sin sesión, con el código), GET /api/sinc/catalogo,
POST /api/sinc/documentos y POST /api/sinc/cambios (con el token de la instalación).  Lado local: /api/sinc/local/* y el hilo
`sincronizar`.  Entre computadoras: GET/POST /api/sinc/red/{cédula}/{ping,cambios} con la clave de red.

4.9 (programa local FISITAAP, etapa 0 del plan sin internet):
  - Revocación solo explícita: la nube responde a una instalación revocada con detail.codigo «instalacion_revocada» en sus
    endpoints de sincronización; solo eso lleva al aviso, al bloqueo y al borrado. Cualquier otro 401/403 (empresa bloqueada
    por cobro, cortafuegos, token rechazado, una nube anterior) deja la instalación «sin acceso a la nube»: avisa, sigue
    trabajando, reintenta y nunca se bloquea ni borra nada. Una «revocación» anotada por una versión anterior sin esa señal
    se convierte en «sin acceso» al arrancar.
  - La terminal y la sucursal de la instalación quedan fijas al vincular (eventos de SQLAlchemy: ninguna ruta las cambia
    después; en la nube, la terminal de la empresa no puede tomar la de una instalación).
  - Los clientes e ítems nuevos reciben el siguiente id de SU rango (también en la nube), aunque la tabla tenga filas de otros
    rangos: antes los daba SQLite (el mayor + 1) y caían en el rango de otra instalación. También desvinculada (el rango sigue).
  - Las fechas del plan bajan también vacías (la nube las borra al cobrar el plan o al convertir la prueba) y, en la instalación,
    una fecha ya pasada solo bloquea si la nube la confirmó después de pasar (fecha_confirmada): sin poder confirmarla (sin
    internet, sin acceso) la copia local puede estar vieja y la computadora sigue trabajando.
  - La nube aplica el resultado de Hacienda que sube la instalación (un rechazo revierte el inventario; una nota de crédito
    recalcula el saldo de su factura) y retoma lo subido que su instalación dejó de mover (cola.retomables, instalaciones_vivas).
  - Lo que sube una instalación mueve el inventario de la nube con la misma regla de la emisión (producción o interno; compras 08;
    notas de crédito solo si devuelven mercadería), porque esa existencia es la que después baja a todas las computadoras.
  - En la red local, lo que dejó firmado o enviado una computadora sin contacto en el plazo de cola.HORAS_RETOMAR lo retoma otra
    (cola.retomables, computadoras_vivas); cada computadora, aunque no tenga novedades, avisa que sigue viva (_toca_latido).
"""
import base64
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import random
import secrets
import socket
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from urllib.parse import urlparse

import httpx
from fastapi import APIRouter, Body, Cookie, Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ValidationError
from pydantic import Field as PField
from sqlalchemy import Index
from sqlalchemy import event
from sqlalchemy import func as sa_func
from sqlalchemy import inspect as sa_inspect
from sqlalchemy import text as _sql
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlmodel import Field, Session, SQLModel, select

from . import modulos, secretos, inventario
from . import sinc_diario as diario
from . import sinc_datos  # noqa: F401  4.32: registra sinc_dato/sinc_cambio/sinc_pisado antes del primer engine_empresa (contrato §4.1, D-12)
from . import auth as _auth
from .auth import (Contexto, Empresa, PERMISOS_API, TOKEN_EMPRESA, TokenApi, _hash_token_api, auditar, contexto, get_session, limitar_ip,
                   requiere, sesion_empresa, tipo_negocio_de)
from .config import DATA_DIR, TZ_CR, ahora_cr, dominio_sistema
from .db import Auditoria, Cliente, Documento, DocumentoLinea, Producto, Secuencia, central, engine, engine_empresa
from .modulos import RANGO, en_rango
from .sinc_diario import SincDiario
from .sucursales import Sucursal

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/sinc", tags=["sinc"])
XML_DIR, CERT_DIR = DATA_DIR / "xml", DATA_DIR / "certs"
MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"
CLAVE_VINC, CLAVE_LOCAL = "sinc_vinculacion", "sinc_local"
# registros de configuración que bajan de la nube a la instalación local (la nube manda en ellos)
CLAVES_CATALOGO = ("categorias", "items_extra", "listas_precios", "recetas", "pos_config", "pos_impresoras", "pos_promos", "pos_modificadores", "monedas", "terminos_pago",
                   "vendedores", "otros_cargos", "config_documentos", "config_documentos_opciones", "impuestos", "retenciones",
                   "campos_adicionales", "atributos", "variantes", "contactos_extra", "plantillas", "empresa_extra", "numeracion-",
                   "hotel_config", "hotel_categorias", "hotel_habitaciones", "hotel_tipos_problema", "hotel_agencias", "hotel_servicios",
                   "hotel_salones", "centros_costo", "param_contable", "catalogo", "catalogo_version", "numeraciones_contables", "inventario_config")
# registros operativos que suben de la instalación local a la nube (colecciones con id; cada instalación sube los de su rango)
CLAVES_OPERATIVAS = ("pos_cajas", "pos_ventas", "hotel_reservas", "hotel_huespedes", "hotel_folios", "hotel_depositos", "hotel_cierres",
                     "hotel_reportes", "hotel_servicios_agenda", "hotel_eventos", "hotel_preventivo",
                     "hotel_seg_bitacora", "hotel_seg_incidentes", "hotel_seg_objetos", "hotel_seg_visitantes")
# entre computadoras del local viajan además las cuentas abiertas del punto de venta (mesas y cuentas en espera)
CLAVES_RED = CLAVES_OPERATIVAS + ("pos_espera",)
CLAVE_BORRADOS, CLAVE_RED_RECIBIDO = "sinc_borrados", "sinc_red_recibido"
# 4.25 (tanda 8): registros de ESTA computadora (la impresión de cada equipo, app/agente_local.py). No están en CLAVES_CATALOGO, ni en
# CLAVES_OPERATIVAS, ni en CLAVES_RED: no suben, no bajan y no se comparten por la red del local; y si una nube los mandara, la
# bajada no los escribe.
CLAVES_DEL_EQUIPO = ("equipo_impresion",)
# 4.29 (encargo C, B-1 a B-4): siembra de Bancos en una computadora recién conectada. El registro «bancos» NO está en ninguna lista de
# arriba (no sube, no baja como catálogo y no viaja por la red del local). La nube manda sus cuentas en un campo APARTE de la respuesta
# de GET /api/sinc/catalogo (no dentro de «registros»: un programa anterior aplicaría eso como «la nube manda» y pisaría sus cuentas) y
# el programa las guarda una sola vez, solo si todavía no tiene el registro «bancos» (_sembrar_bancos).
CAMPO_BANCOS_INICIALES = "bancos_iniciales"
CAMPOS_BANCO_INICIAL = ("nombre", "tipo", "moneda", "numero", "descripcion", "cuenta_contable", "principal")
TIPOS_CON_CAJA = ("restaurante", "comercio", "hospitalidad")   # los tipos que en la web nacen con «Caja general» (auth.crear_empresa)
IMPRESORAS_DE_LA_WEB = ("Las impresoras de la empresa se crean y se cambian en la página web. Aquí puede indicar cómo está conectada cada una "
                        "en esta computadora, o agregar una impresora solo de esta computadora.")


def impresoras_de_la_web(s, eid: int) -> bool:
    """4.25 (tanda 8, E-6): ¿las impresoras de la empresa (pos_impresoras) las manda la web? Sí en el programa conectado a la web
    cuando la web ya mandó su lista (la bajada lo anota en «impresoras_web»). Programa sin conectar (o desvinculado): no."""
    if not MODO_LOCAL:
        return False
    if _canal().registro_por_canal(eid, "pos_impresoras"):
        return False                                                   # 4.32: las impresoras se cambian aquí y viajan por /api/sinc/datos (sin el 409)
    cfg = _cfg_local(s, eid)
    return bool(cfg.get("vinculado") and cfg.get("impresoras_web"))


def _canal():
    """4.32: el canal nuevo del programa (app/sinc_datos_programa.py); se importa al usarlo."""
    from . import sinc_datos_programa
    return sinc_datos_programa


def movimientos_pos(s, eid: int, clave: str, items: list) -> int:
    """Movimientos de Bancos que una caja genera aparte del cobro (3.20): el cambio de dólares (entran dólares a la caja en
    dólares y sale su equivalente en colones de la gaveta: el vuelto) y los retiros depositados al banco. En la nube se crean
    a partir de las ventas y sesiones que suben de una instalación local (los movimientos no viajan); con las mismas
    referencias que usa el navegador, así que no se duplican. Devuelve cuántos se registraron."""
    n = 0
    for x in items:
        if not isinstance(x, dict):
            continue
        if clave == "pos_ventas":
            u = x.get("usd")
            if not (isinstance(u, dict) and float(u.get("monto_usd") or 0) > 0 and float(u.get("tc") or 0) > 0):
                continue
            ref = f"pos:cambio:{x.get('consecutivo') or x.get('id')}"
            fecha = str(x.get("hora") or "")[:10]
            detalle = f"Dólares recibidos · {str(x.get('consecutivo') or '')[-10:]}"
            if u.get("cuenta_usd") and modulos.registrar_movimiento_banco(s, eid, u["cuenta_usd"], float(u["monto_usd"]), fecha, detalle, ref + ":usd", moneda="USD", tipo_cambio=float(u["tc"])):
                n += 1
            if u.get("cuenta_crc") and modulos.registrar_movimiento_banco(s, eid, u["cuenta_crc"], -round(float(u["monto_usd"]) * float(u["tc"]), 2), fecha, detalle + " · equivalente en colones (vuelto)", ref + ":crc", moneda="CRC", tipo_cambio=1):
                n += 1
        else:
            for i, r in enumerate(x.get("retiros") or []):
                if not (isinstance(r, dict) and r.get("cuenta_destino") and float(r.get("monto") or 0) > 0):
                    continue
                ref = f"pos:retiro:{x.get('id')}:{i}"
                fecha = str(r.get("hora") or "")[:10]
                detalle = f"Retiro de la caja {x.get('caja') or ''} · {r.get('motivo') or ''}"
                if r.get("cuenta_origen") and modulos.registrar_movimiento_banco(s, eid, r["cuenta_origen"], -float(r["monto"]), fecha, detalle, ref + ":salida", moneda="CRC", tipo_cambio=1):
                    n += 1
                if modulos.registrar_movimiento_banco(s, eid, r["cuenta_destino"], float(r["monto"]), fecha, detalle, ref + ":entrada", moneda="CRC", tipo_cambio=1):
                    n += 1
    return n
ESTADOS_FINALES = ("aceptado", "rechazado", "anulado")
TIEMPO = httpx.Timeout(300, connect=10)            # sin internet, la nube no contesta: no esperar minutos por cada intento
DIAS_BLOQUEO, DIAS_BORRADO = 3, 30                 # instalación revocada (4.9: solo de forma explícita): se bloquea a los 3 días de enterarse y borra sus datos a los 30 del bloqueo
CODIGO_REVOCADA = "instalacion_revocada"           # 4.9: la señal explícita de la nube (detail.codigo) de que esta instalación fue revocada


class Revocada(Exception):
    """4.9: la nube dijo de forma explícita que esta instalación fue revocada (respuesta 4xx con detail.codigo
    «instalacion_revocada»). Solo esto lleva al aviso, al bloqueo a los 3 días y al borrado a los 30.
    4.25 (D-O): `motivo` es el detail.motivo de la web; «sin_estrenar» = la web descartó sola una conexión que no usó su token a tiempo
    (no la revocó una persona): la empresa queda desvinculada, sin cuenta de bloqueo."""

    def __init__(self, mensaje: str = "", motivo: Optional[str] = None):
        super().__init__(mensaje)
        self.motivo = motivo


class SinAcceso(Exception):
    """4.9: la nube negó el acceso (401/403) sin decir que la instalación fue revocada: empresa bloqueada por cobro, cortafuegos del
    hosting, token rechazado por otra causa o una nube anterior a la 4.9. La instalación avisa, sigue trabajando y reintenta;
    nunca se bloquea ni se borra nada por esto."""
CAMPOS_REF_DOC = ("doc_id", "documento_id")        # campos de esos registros que apuntan a un comprobante (id local → id en la nube)
CAMPOS_EMPRESA = ("nombre", "nombre_comercial", "tipo_id", "numero_id", "actividad", "provincia", "canton", "distrito", "barrio", "otras_senas",
                  "telefono", "correo", "proveedor_sistemas", "ambiente", "sucursal", "tipo_negocio", "registro_fiscal_8707",
                  "factura_electronica",      # 4.21: el interruptor de la nube baja a la computadora (un «No contribuyente» queda apagado en las dos)
                  "plan", "extras", "docs_extra", "plan_inicio", "habitaciones", "cajas", "limite_usuarios", "vence", "prueba_hasta",   # plan (3.16)
                  "plan_dias_gracia")         # 4.28 (P-7): baja con los días de gracia EFECTIVOS de la empresa (_datos_empresa); un programa anterior lo ignora
# 4.9 (E1/E4): vacío en la nube = sin plan, sin vencimiento o prueba ya convertida (planes.registrar_pago, demo): tiene que bajar vacío.
# Antes solo bajaba lo que traía valor y la computadora conservaba para siempre la fecha vieja (y se bloqueaba al llegar).
NULABLES_EMPRESA = ("plan", "plan_inicio", "vence", "prueba_hasta")
DIAS_GRACIA_PLAN = 7                                                     # etapa 1 (decisión 11 del plan): plan o prueba vencidos sin poder confirmar con la nube
_ERROR_RED = httpx.TransportError                                        # etapa 1: sin internet o nube caída (se toma aquí: las pruebas sustituyen httpx)
CAMPOS_DOC = ("tipo_documento", "clave", "consecutivo", "fecha_emision", "receptor_nombre", "moneda", "tipo_cambio", "total", "impuesto", "estado",
              "ambiente", "mensaje_hacienda", "terminos", "orden_compra", "vendedor", "fecha_vencimiento", "pagado", "acreditado", "referencia_clave",
              "referencia_codigo", "condicion_venta", "otros_cargos", "exoneracion_numero", "iva_exonerado", "creado")
CAMPOS_LINEA = ("numero", "producto_id", "cabys", "detalle", "cantidad", "unidad_medida", "precio_unitario", "descuento", "codigo_tarifa", "tarifa",
                "impuesto", "total", "iva_exonerado", "tarifa_exonerada")
CAMPOS_PAGO = ("tipo", "consecutivo", "cliente_id", "cliente_nombre", "cliente_cedula", "detalles", "fecha", "cuenta", "condicion_venta", "medio_pago",
               "moneda", "tipo_cambio", "monto", "estado", "notas", "usuario")
VENTAS = ("01", "04", "09")
ORIGEN_NUBE = "nube"                                                     # etapa 2a: origen_sinc de lo que baja de la nube a una instalación
LIMITE_NOVEDADES, BYTES_NOVEDADES, PAGINAS_POR_CICLO, INTENTOS_BAJADA = 200, 6_000_000, 10, 5
ERRORES_PASAJEROS = ("locked", "busy", "no space", "disk", "permission", "denied", "i/o", "timeout", "timed out", "unable to open")   # en estos nunca se salta un paquete
_AUSENTE = object()


def _ahora():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _hash(texto: str) -> str:
    return hashlib.sha256(texto.encode()).hexdigest()


def _huella(d: dict) -> str:
    """Resumen corto del contenido de una fila: para subir solo lo que cambió desde la última subida."""
    # 4.6: las columnas nuevas vacías (None) no cuentan: agregar una columna no vuelve a subir todo el catálogo
    return hashlib.sha1(json.dumps({k: v for k, v in d.items() if v is not None}, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _leer(s, eid, clave, defecto):
    v = modulos.leer(s, eid, clave, None)
    return v if isinstance(v, type(defecto)) else defecto


def _escribir(s, eid, clave, datos):
    r = modulos._registro(s, eid, clave)
    modulos.reemplazar(s, eid, clave, datos, version=(r.version or 0) if r else 0)


def _version_sistema() -> str:
    try:
        from .version import actual as _va
        return str((_va() or {}).get("version") or "")
    except Exception:  # noqa: BLE001
        return ""


# ======================================================================================================================
# LADO NUBE
# ======================================================================================================================
class CodigoIn(BaseModel):
    nombre: str = ""


_ALFABETO_CODIGO = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"     # sin 0, O, 1 ni I: se confunden al copiarlo a mano
AVISO_CANJE = "Demasiados intentos de vinculación; espere unos minutos"


def _codigo_nuevo(eid: int) -> str:
    """4.15: el código entrega la clave de Hacienda, la llave .p12 y su PIN. Antes eran 24 bits; ahora 16 caracteres (80 bits)."""
    c = "".join(secrets.choice(_ALFABETO_CODIGO) for _ in range(16))
    return f"L{eid}-{c[:4]}-{c[4:8]}-{c[8:12]}-{c[12:]}"


def _url_nube_segura(url: str) -> bool:
    """4.15: la respuesta del canje trae secretos, así que solo viaja por https. http únicamente hacia esta misma computadora (pruebas) o con FE_SINC_HTTP=1."""
    try:
        u = urlparse(url)
        anfitrion = u.hostname
    except ValueError:                                                   # corchetes mal formados, por ejemplo
        return False
    if u.scheme == "https" and anfitrion:
        return True
    return u.scheme == "http" and bool(anfitrion) and (anfitrion in ("localhost", "127.0.0.1", "::1") or os.environ.get("FE_SINC_HTTP") == "1")


def _url_nube_fija() -> str:
    """4.25: la dirección de la web a la que el programa puede mandar datos de ingreso: FE_NUBE_URL o «https://fisitaap.com». Si
    FE_NUBE_URL no pasa _url_nube_segura queda vacía (lo más estricto: a una dirección dudosa no se manda nada)."""
    url = (os.environ.get("FE_NUBE_URL") or "").strip().rstrip("/") or "https://fisitaap.com"
    if _url_nube_segura(url):
        return url
    log.warning("FE_NUBE_URL no es una dirección segura (https): no se usa")
    return ""


URL_NUBE = _url_nube_fija()


def _solo_nube() -> None:
    """4.25: las rutas que solo atiende la web contestan 404 en un programa local real (FE_MODO_LOCAL=1). Sirve como dependencia
    (va primero) o llamada directa."""
    if _auth._es_local():
        raise HTTPException(404, "Not Found")


@router.post("/codigo")
def generar_codigo(data: CodigoIn, _nube: None = Depends(_solo_nube), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Código de vinculación de un solo uso (15 minutos) para una instalación local. Lo genera un administrador con sesión."""
    if ctx.token_api is not None:
        raise HTTPException(403, "El código de vinculación lo genera un administrador con sesión, no un token")
    if ctx.empresa.es_demo:
        raise HTTPException(400, "La empresa demo no se instala localmente")
    eid = ctx.empresa.id
    v = _leer(s, eid, CLAVE_VINC, {})
    codigos = [c for c in v.get("codigos", []) if c.get("vence", "") > _ahora()]
    codigo = _codigo_nuevo(eid)
    vence = (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat(timespec="seconds")
    codigos.append({"hash": _hash(codigo), "vence": vence, "usuario_id": ctx.usuario.id, "nombre": (data.nombre or "").strip()[:60]})
    v["codigos"] = codigos[-5:]
    _escribir(s, eid, CLAVE_VINC, v); s.commit()
    auditar(sc, "sinc_codigo", "Código de vinculación generado para una instalación local", ctx.usuario, eid, ctx.request)
    return {"codigo": codigo, "vence": vence}


class CanjeIn(BaseModel):
    codigo: str
    nombre: str = ""
    terminal_anterior: Optional[int] = None       # revinculación: la terminal que esta computadora tenía antes de ser revocada
    secuencias: dict = {}                         # {tipo: último consecutivo emitido aquí}: prueba de que conserva sus datos
    cedula: Optional[str] = PField(default=None, max_length=30)   # 4.25 (9b, D-P): la empresa local donde se canjea ya tiene datos de esta cédula


# 4.25 (9b, D-P): un código o una aprobación de OTRA empresa nunca reemplaza a una empresa que ya tiene datos en la computadora.
MENSAJE_CODIGO_OTRA = ("Ese código es de otra empresa (cédula {cedula}). Esta computadora ya tiene datos de la empresa {local}: solo se puede "
                       "volver a conectar a esa. Para agregar otra empresa a esta computadora use «Conectar otra empresa en esta computadora».")


def _conserva_datos(s, eid: int, terminal: int, secuencias: dict) -> bool:
    """La computadora que vuelve conserva lo que esa terminal ya emitió (sus consecutivos van por delante de los que la nube
    recibió de ella). Si no, la numeración volvería a empezar y chocaría: recibe terminal nueva."""
    t = f"{int(terminal):05d}"
    maximos: dict = {}
    for c in s.exec(select(Documento.consecutivo).where(Documento.empresa_id == eid, Documento.consecutivo.like(f"___{t}%"))).all():
        c = str(c or "")
        if len(c) == 20 and c[3:8] == t and c[10:].isdigit():
            maximos[c[8:10]] = max(maximos.get(c[8:10], 0), int(c[10:]))
    return all(int((secuencias or {}).get(tipo) or 0) >= n for tipo, n in maximos.items())


@router.post("/canje")
def canjear_codigo(data: CanjeIn, request: Request, _nube: None = Depends(_solo_nube), sc: Session = Depends(get_session)):
    """La instalación local entrega el código y recibe el token, los datos de la empresa, sus credenciales de Hacienda y su terminal."""
    limitar_ip(request, "sinc", 10, 900, AVISO_CANJE, registrar=False)     # 4.15: tope persistente y común a todos los procesos; solo cuentan los fallos

    def invalido(texto: str) -> HTTPException:
        limitar_ip(request, "sinc", 10, 900, AVISO_CANJE)
        return HTTPException(400, texto)
    codigo = (data.codigo or "").strip().upper()
    try:
        eid = int(codigo.split("-")[0].lstrip("L"))
    except ValueError:
        raise invalido("Código inválido")
    e = sc.get(Empresa, eid)
    if not e or e.bloqueada:
        raise invalido("Código inválido")
    with Session(engine_empresa(eid)) as s:
        v = _leer(s, eid, CLAVE_VINC, {})
        h = _hash(codigo)
        vivo = [c for c in v.get("codigos", []) if c.get("hash") == h and c.get("vence", "") > _ahora()]
        if not vivo:
            raise invalido("Código inválido o vencido: genere otro en la nube")
        local = _digitos(data.cedula)[:12]
        if local and local != _digitos(e.numero_id):
            # 4.25 (9b, D-P): la computadora ya tiene datos de otra empresa: no nace ninguna instalación (antes de crear el token) y el
            # código sigue sirviendo para la computadora correcta. No cuenta como fallo: el código era bueno.
            raise HTTPException(409, {"codigo": "otra_empresa", "cedula": _digitos(e.numero_id),
                                      "mensaje": MENSAJE_CODIGO_OTRA.format(cedula=_digitos(e.numero_id) or "sin cédula", local=f"con cédula {local}")})
        c = vivo[0]
        v["codigos"] = [x for x in v.get("codigos", []) if x.get("hash") != h]
        por = None
        if c.get("usuario_id"):
            quien = sc.get(_auth.Usuario, int(c["usuario_id"]))
            por = quien.correo if quien is not None else None
        return _alta_instalacion(sc, s, e, v, nombre=(data.nombre or c.get("nombre") or ""), terminal_anterior=data.terminal_anterior,
                                 secuencias=data.secuencias, request=request, por=por)


def _alta_instalacion(sc, s, e, v: dict, *, nombre: str, terminal_anterior=None, secuencias=None, request=None, usuario=None,
                      origen: str = "codigo", reemplaza_sin_estrenar: bool = False, por: Optional[str] = None, detalle: str = "") -> dict:
    """La instalación nueva de la empresa `e`: número de terminal (máximo + 1, o la anterior si demuestra que conserva sus datos), token
    de la empresa, ficha en sinc_vinculacion (`v`, ya leído en `s`), auditoría «sinc_vinculada» y lo que recibe la computadora (token,
    terminal, nombre, datos de la empresa y credenciales). Sale de canjear_codigo (4.25) para que la use también la conexión aprobada
    en la página web: con origen «conexion» la auditoría lleva a la PERSONA que aprobó (`usuario`) y el `detalle` de las conexiones;
    con reemplaza_sin_estrenar, la terminal anterior de una instalación de conexión que nunca usó su token se revoca y se reutiliza (un
    reintento de la misma computadora no gasta otra terminal). La ficha gana dos claves opcionales: `origen` y `por` (correo de quien
    aprobó o generó el código).
    4.25 (E-5): si algo falla DESPUÉS de crear el token, ese token se revoca (nunca salió del servidor) y el error sigue hacia arriba."""
    eid = e.id
    if origen == "conexion":
        _descartar_sin_estrenar(sc, s, eid, v, forzar=True)
    instalaciones = v.get("instalaciones", [])
    retiradas = v.get("retiradas", [])
    terminal = max([int(e.terminal or 1)] + [int(i.get("terminal") or 1) for i in instalaciones] + [int(i.get("terminal") or 1) for i in retiradas]) + 1
    reusa = reemplazo = None
    if terminal_anterior and reemplaza_sin_estrenar:
        reemplazo = next((i for i in instalaciones if isinstance(i, dict) and int(i.get("terminal") or 0) == int(terminal_anterior)
                          and i.get("origen") == "conexion" and i.get("token_id")), None)
        if reemplazo is not None and _revocar_sin_uso(sc, int(reemplazo["token_id"])):
            terminal = int(reemplazo["terminal"])
            instalaciones = [i for i in instalaciones if i is not reemplazo]
            auditar(sc, "sinc_descartada", f"Instalación local «{reemplazo.get('nombre')}» (terminal {terminal}) sin estrenar: la reemplaza un "
                    "reintento de la misma computadora", usuario, eid, request)
        else:
            reemplazo = None
    if terminal_anterior and reemplazo is None:
        # vuelve una computadora revocada: conserva su terminal solo si demuestra que conserva sus datos (R: nunca repetir consecutivos)
        reusa = next((x for x in retiradas if int(x.get("terminal") or 0) == int(terminal_anterior)), None)
        if reusa is not None and _conserva_datos(s, eid, int(terminal_anterior), secuencias or {}):
            terminal = int(reusa["terminal"]); retiradas = [x for x in retiradas if x is not reusa]
        else:
            reusa = None
    # token de la empresa (no depende de ninguna persona), con permisos fijos para lo que una instalación necesita
    token = "fcr_" + secrets.token_urlsafe(32)
    nombre = (nombre or (reusa or {}).get("nombre") or f"Instalación local {terminal}").strip()[:60]
    permisos = [p for p in PERMISOS_API if p not in ("ver_todo",)]
    t = TokenApi(empresa_id=eid, usuario_id=TOKEN_EMPRESA, nombre=f"Instalación local · {nombre}", prefijo=token[:12],
                 hash=_hash_token_api(token), permisos=json.dumps(permisos))
    sc.add(t); sc.commit(); sc.refresh(t)
    tid = t.id
    try:
        ficha = {"terminal": terminal, "nombre": nombre, "token_id": t.id, "prefijo": t.prefijo, "creado": _ahora(),
                 "ultima_bajada": None, "ultima_subida": None, "documentos": 0, "pagos": 0, "registros": 0, "catalogos": 0, "version": None,
                 "revinculada": bool(reusa), "origen": origen}
        if por:
            ficha["por"] = por
        if origen == "conexion":
            # 4.25 (D-E, revisión de las tandas 4b a 6): la conexión solo la hace un programa 4.25 o posterior (VERSION_CONEXION), que
            # valida el ingreso en línea: la política de hash rige desde su primer catálogo, mande o no la cabecera (sin la marca, quien
            # tuviera el token recibía los hash reales de todo el personal hasta el primer ingreso en línea)
            ficha["ingreso_en_linea"] = True
        instalaciones.append(ficha)
        v["instalaciones"] = instalaciones; v["retiradas"] = retiradas
        diario.sembrar(s)                                          # etapa 2a: lo anterior a la vinculación también baja, como historia
        _escribir(s, eid, CLAVE_VINC, v); s.commit()
        credenciales = _credenciales_de(e)
        texto = f"Instalación local «{nombre}» {'revinculada' if reusa else 'vinculada'} como terminal {terminal} (token {t.prefijo}…)"
        if origen == "conexion":
            texto += " · aprobada en la página web" + (f" · {detalle}" if detalle else "")
        auditar(sc, "sinc_vinculada", texto, usuario if origen == "conexion" else None, eid, request)
        return {"token": token, "terminal": terminal, "nombre": nombre, "revinculada": bool(reusa), "empresa": _datos_empresa(e, request), "credenciales": credenciales,
                "credenciales_huella": _huella_credenciales(e)}
    except Exception:
        _revocar_token_fallido(tid)
        raise


def _revocar_token_fallido(tid: int) -> None:
    """4.25 (E-5): el alta de una instalación falló después de crear su token: se revoca (nunca salió del servidor). Con una sesión propia:
    la del alta puede haber quedado a medias."""
    try:
        with Session(engine) as x:
            x.execute(_sql("UPDATE tokenapi SET revocado=1 WHERE id=:id"), {"id": int(tid)}); x.commit()
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc: no se pudo revocar el token de un alta fallida (%s)", type(ex).__name__)


def _revocar_sin_uso(sc, tid: int) -> bool:
    """4.25 (E-5): revoca el token de una instalación solo si NUNCA se usó (atómico: si el programa hace su primera llamada al mismo
    tiempo, gana el uso). True si lo revocó."""
    r = sc.execute(_sql("UPDATE tokenapi SET revocado=1 WHERE id=:id AND ultimo_uso IS NULL AND revocado=0"), {"id": int(tid)})
    sc.commit()
    return (r.rowcount or 0) == 1


def _entiende_gracia(request: Optional[Request]) -> bool:
    """4.28 (C1): la llamada viene de un programa 4.28 o posterior, que entiende los días de gracia del plan (cabecera CABECERA_PLAN con
    PROTOCOLO_PLAN o más). Sin la cabecera, o con un valor que no se entiende, es un programa anterior (o cualquier otro cliente)."""
    try:
        return request is not None and int(str(request.headers.get(CABECERA_PLAN) or "0").strip()) >= PROTOCOLO_PLAN
    except (ValueError, AttributeError):
        return False


def _datos_empresa(e: Empresa, request: Optional[Request] = None) -> dict:
    d = {k: getattr(e, k, None) for k in CAMPOS_EMPRESA}
    d["tipo_negocio"] = tipo_negocio_de(e)
    try:                                       # 4.28 (P-7): los de la empresa o, vacíos, los generales de la nube (la computadora no los conoce)
        from . import planes as _pl
        n = _pl.dias_gracia(e)
        if _entiende_gracia(request):
            d["plan_dias_gracia"] = n
        else:
            # 4.28 (C1): un programa anterior no conoce los días de gracia y da el plan por vencido el día después de `vence`: le baja como
            # `vence` el último día de gracia (y 0 días), para que quede en solo consulta el mismo día que la web. Con 0 días de gracia,
            # o sin fecha, recibe lo mismo que en la 4.27 (P-1).
            d["plan_dias_gracia"] = 0
            if n and d.get("vence"):
                d["vence"] = _pl.gracia_hasta(e) or d["vence"]
    except Exception:  # noqa: BLE001
        d["plan_dias_gracia"] = 0
    return d


def _credenciales_de(e) -> dict:
    """Etapa 1: credenciales de Hacienda de la empresa (usuario, clave, llave .p12 y ambiente) para entregarlas a su instalación."""
    cred = {"usuario_hacienda": e.usuario_hacienda, "password_hacienda": secretos.descifrar(e.clave_cifrada, e.password_hacienda),
            "p12_b64": None, "p12_pin": None, "p12_vence": getattr(e, "p12_vence", None), "ambiente": e.ambiente}
    if e.p12_nombre and (CERT_DIR / e.p12_nombre).exists():
        try:
            cred["p12_b64"] = base64.b64encode(secretos.descifrar_archivo(e.clave_cifrada, (CERT_DIR / e.p12_nombre).read_bytes())).decode()
            cred["p12_pin"] = secretos.descifrar(e.clave_cifrada, e.p12_pin)
        except Exception as ex:  # noqa: BLE001
            log.warning("credenciales: no se pudo abrir la llave de la empresa %s: %s", e.id, ex)
    return cred


def _huella_credenciales(e) -> str:
    """Etapa 1: cambia cuando cambian el usuario, la clave, la llave o el ambiente; así la instalación solo pide las credenciales si hace falta."""
    h = hashlib.sha256()
    for x in (e.usuario_hacienda, e.password_hacienda, e.p12_nombre, e.p12_pin, getattr(e, "p12_vence", None), e.ambiente):
        h.update(str(x or "").encode("utf-8") + b"|")
    if e.p12_nombre and (CERT_DIR / e.p12_nombre).exists():
        h.update((CERT_DIR / e.p12_nombre).read_bytes())
    return h.hexdigest()


def _aplicar_credenciales(e, cred: dict) -> None:
    """Etapa 1: guarda en la instalación las credenciales que mandó la nube (al vincular y cuando cambian)."""
    if cred.get("usuario_hacienda"):
        e.usuario_hacienda = cred["usuario_hacienda"]
    if cred.get("password_hacienda"):
        e.password_hacienda = secretos.cifrar(e.clave_cifrada, cred["password_hacienda"])
    if cred.get("ambiente"):
        e.ambiente = cred["ambiente"]
    if cred.get("p12_b64") and cred.get("p12_pin"):
        nombre = f"empresa_{e.id}.p12"
        (CERT_DIR / nombre).write_bytes(secretos.cifrar_archivo(e.clave_cifrada, base64.b64decode(cred["p12_b64"])))
        e.p12_nombre, e.p12_pin = nombre, secretos.cifrar(e.clave_cifrada, cred["p12_pin"])
        if cred.get("p12_vence") and hasattr(e, "p12_vence"):
            e.p12_vence = cred["p12_vence"]


def _huella_mfa(u) -> str:
    """4.25 (D-D): huella de los dos pasos vigentes en la web (HMAC con la llave de la nube sobre la persona y su secreto): cambia si la
    persona vuelve a activar los dos pasos con otro teléfono. Vacía si no los usa. Nunca dice nada del secreto."""
    if not (getattr(u, "mfa_activo", False) and getattr(u, "mfa_secret", None)):
        return ""
    try:
        secreto = _auth._descifrar_mfa(u.mfa_secret) or u.mfa_secret
    except Exception:  # noqa: BLE001
        secreto = u.mfa_secret
    return _auth._b64(hmac.new(_auth.SECRET, f"mfa|{u.id}|{secreto}".encode(), hashlib.sha256).digest()[:12])


def _ficha_usuario(sc, u, m, eid: int) -> dict:
    """Etapa 1 y 4.25 (D-D, nube): la fila de una persona de la empresa `eid` para su instalación (catálogo, usuarios, ingreso y ficha)
    con los hash tal cual (la política de qué hash baja la aplica _con_politica). Además: mfa (huella de los dos pasos de la web; vacía si
    no los usa), mfa_entrar (la web le pide código para entrar: los usa, o su rol se los exige y no los tiene cubiertos), mfa_rrhh (la
    regla de dos pasos de Recursos humanos queda cubierta en ESTA empresa) y temporal (contraseña temporal sin cambiar). Nunca el
    secreto ni los códigos de respaldo."""
    A = _auth
    exigida = (not u.mfa_activo) and A.mfa_obligatorio(sc, u) and not A.mfa_cubierto(sc, u)
    return {"correo": u.correo, "nombre": u.nombre, "password_hash": u.password_hash, "pin_hash": u.pin_hash, "bloqueado": bool(u.bloqueado),
            "terminos_version": u.terminos_version, "paleta": u.paleta, "rol": m.rol, "sucursal_id": m.sucursal_id, "modulos_ocultos": m.modulos_ocultos,
            "mfa": _huella_mfa(u), "mfa_entrar": bool(u.mfa_activo) or exigida, "mfa_rrhh": bool(A.rrhh_con_mfa(u, m.rol, sc, eid)),
            "temporal": bool(u.debe_cambiar_password)}


def _usuarios_empresa(eid: int) -> dict:
    """Etapa 1 (nube): usuarios y roles de la empresa para su instalación. Sin los administradores del sistema ni secretos de dos pasos.
    4.25: cada fila es la ficha de _ficha_usuario (con mfa, mfa_entrar, mfa_rrhh y temporal)."""
    with Session(engine) as sc:
        filas = sc.exec(select(_auth.UsuarioEmpresa, _auth.Usuario).where(_auth.UsuarioEmpresa.empresa_id == eid, _auth.UsuarioEmpresa.usuario_id == _auth.Usuario.id)).all()
        roles = sc.exec(select(_auth.RolEmpresa).where(_auth.RolEmpresa.empresa_id == eid)).all()
        return {"usuarios": [_ficha_usuario(sc, u, m, eid)
                             for m, u in filas if not u.es_superadmin],
                "roles": [{"nombre": r.nombre, "descripcion": r.descripcion, "permisos": r.permisos} for r in roles]}


# 4.25 (D-E): qué hash baja a cada instalación. La nube anota en auth.IngresoPrograma quién ya entró EN LÍNEA en cada instalación; a esa
# instalación solo le bajan el hash de la contraseña y del PIN de esas personas. A las demás les baja HASH_INSERVIBLE: no vacío (un hash
# vacío hace que la bajada de una versión anterior las salte y les borre la membresía) y nunca verifica. Solo para las instalaciones que
# avisan que validan el ingreso en línea (cabecera CABECERA_INGRESO con PROTOCOLO_INGRESO o más, en sus llamadas a la nube): las anteriores
# siguen recibiendo los hash como antes (si no, nadie podría entrar en ellas: no saben pedirle el ingreso a la nube). La cabecera vale
# para ESA respuesta y no deja marca (la puede mandar cualquiera que tenga el token). La instalación queda anotada para siempre
# (ingreso_en_linea en sinc_vinculacion: ya no recibe los hash aunque no mande la cabecera) solo cuando una persona entró en línea por
# ella (_aceptar_ingreso): hacen falta el token y una contraseña válida, y es la prueba de que ese programa sí sabe validar en línea.
# Las que nacen por la conexión aprobada en la página web (_alta_instalacion con origen «conexion») nacen ya anotadas: ese camino solo lo
# usa un programa que valida en línea.
HASH_INSERVIBLE = "scrypt$!$!"
CABECERA_INGRESO = "X-Fisitaap-Ingreso"
PROTOCOLO_INGRESO = 1
# 4.28 (C1): el programa 4.28 o posterior avisa con esta cabecera, en cada llamada en la que recibe los datos de la empresa (canje del
# código, conexión aprobada en la página web y bajada del catálogo), que entiende los días de gracia del plan. Solo a él le baja la fecha
# `vence` real y `plan_dias_gracia`; a los demás, en `vence` el último día de gracia y 0 días (_datos_empresa).
CABECERA_PLAN = "X-Fisitaap-Plan"
PROTOCOLO_PLAN = 1
INGRESO_EN_LINEA = True       # 4.25 (tanda 3): el programa le pide el ingreso a la nube (ganchos de abajo); con False vuelve a validar solo con lo guardado


def _valida_en_linea(cfg: dict) -> bool:
    """4.25 (D-J, programa): esta computadora puede validar el ingreso en línea: el programa ya lo pide (INGRESO_EN_LINEA) y su dirección
    guardada es la de la web (URL_NUBE; no cuentan las mayúsculas ni la barra final). Solo entonces avisa a la nube con la cabecera. Si
    está conectada a otra dirección, o URL_NUBE quedó vacía, no manda contraseñas a nadie y valida con lo guardado: tiene que seguir
    bajando los hash (con la política encima nadie podría entrar)."""
    return bool(INGRESO_EN_LINEA and URL_NUBE and str(cfg.get("url") or "").strip().rstrip("/").lower() == URL_NUBE.lower())


def _validados(sc, token_id: int) -> set:
    """4.25 (D-E): ids de las personas que ya entraron en línea en la instalación de ese token."""
    return set(sc.exec(select(_auth.IngresoPrograma.usuario_id).where(_auth.IngresoPrograma.token_id == int(token_id))).all())


def _anotar_validado(sc, token_id: int, usuario_id: int) -> None:
    """4.25 (D-E): la persona entró en línea en esa instalación (una fila por instalación y persona; la fecha se actualiza)."""
    from sqlalchemy.exc import IntegrityError
    fila = sc.exec(select(_auth.IngresoPrograma).where(_auth.IngresoPrograma.token_id == int(token_id), _auth.IngresoPrograma.usuario_id == int(usuario_id))).first()
    if fila is None:
        fila = _auth.IngresoPrograma(token_id=int(token_id), usuario_id=int(usuario_id))
    fila.fecha = datetime.now(timezone.utc)
    sc.add(fila)
    try:
        sc.commit()
    except IntegrityError:                                              # otro ingreso de la misma persona la anotó un instante antes
        sc.rollback()


def _con_politica(sc, usuarios: list, token_id: int) -> list:
    """4.25 (D-E): las fichas con el hash real solo para quien ya entró en línea en esa instalación; a las demás, HASH_INSERVIBLE en la
    contraseña y en el PIN (si tiene PIN). Devuelve copias: no toca la lista recibida."""
    ids = _validados(sc, token_id)
    correos = {c.lower() for c in sc.exec(select(_auth.Usuario.correo).where(_auth.Usuario.id.in_(list(ids)))).all()} if ids else set()
    salida = []
    for x in usuarios:
        x = dict(x)
        if str(x.get("correo") or "").lower() not in correos:
            x["password_hash"] = HASH_INSERVIBLE
            x["pin_hash"] = HASH_INSERVIBLE if x.get("pin_hash") else None
        salida.append(x)
    return salida


def _avisa_ingreso(request: Optional[Request]) -> bool:
    """4.25: la llamada viene de un programa que valida el ingreso en línea (cabecera CABECERA_INGRESO con PROTOCOLO_INGRESO o más). Sin
    la cabecera, o con un valor que no se entiende, es un programa anterior."""
    try:
        return request is not None and int(str(request.headers.get(CABECERA_INGRESO) or "0").strip()) >= PROTOCOLO_INGRESO
    except ValueError:
        return False


def _hash_de_otra(sc, uid: int, eid: int) -> bool:
    """4.25 (revisión de las tandas 3 y 4): la web le manda el hash real de esa persona a OTRA empresa vinculada de esta computadora (ya
    entró en línea por la instalación de esa empresa: hash_nube en su membresía) y esa empresa sigue vinculada aquí (su bajada lo
    mantiene al día). La tabla de usuarios es una sola para todas las empresas de la computadora, y la web decide qué hash baja por
    instalación (D-E): sin esto, la ficha «inservible» de una empresa pisaría en cada ciclo el hash real que manda la otra."""
    A = _auth
    otras = {m.empresa_id for m in sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.usuario_id == uid, A.UsuarioEmpresa.empresa_id != eid)).all()
             if m.hash_nube}
    return bool(otras) and any(e in otras for e, _c, _t in _vinculadas())


def _convertir_admin_local(sc, u, eid: int) -> None:
    """4.25 (tanda 6, E-13): el administrador del sistema de ESTA computadora tiene el mismo correo que una persona que manda la web: deja
    de ser administrador del sistema (sin empresas ocultas ni los dos pasos de esta computadora) y sigue como cuenta de la web; quien
    llama cierra sus sesiones. Se audita sin commit (lo hace quien llama). Solo en el programa real sin FE_LOCAL_ADMIN=1."""
    u.es_superadmin, u.admin_principal, u.empresas_ocultas = False, False, "[]"
    u.mfa_activo, u.mfa_secret, u.mfa_pendiente, u.mfa_respaldo, u.mfa_ultimo, u.mfa_fallidos = False, None, None, None, None, 0
    sc.add(u)
    sc.add(Auditoria(accion="cuenta_local_convertida", detalle="El administrador del sistema de esta computadora tiene el mismo correo que una cuenta de "
                     "la página web: queda como una cuenta normal de la web (entra con la contraseña y los dos pasos de la web)",
                     usuario_id=u.id, correo=u.correo, empresa_id=eid))


def _huella_password(h: str) -> str:
    """4.25 (9b, D-Q): huella de un hash real de contraseña: HMAC-SHA256 con la llave local (auth.SECRET). Nunca se guarda el hash mismo."""
    return hmac.new(_auth.SECRET, ("password|" + str(h or "")).encode(), hashlib.sha256).hexdigest()


def _cambia_password(u, nuevo: str) -> bool:
    """4.25 (9b, D-Q): llega `nuevo` para la persona `u`: ¿es un cambio REAL de contraseña (se cierran sus sesiones)? No, si no llega un
    hash real o es el mismo. Sí, si antes había otro hash real. Si antes había el inservible (o nada), no solo si la huella guardada al
    quitarle el real coincide con la del que llega (es la misma contraseña); sin huella, o si no coincide, sí (lo más estricto)."""
    if not _hash_utilizable(nuevo) or u.password_hash == nuevo:
        return False
    if _hash_utilizable(u.password_hash):
        return True
    h = getattr(u, "huella_password", None)
    return not (h and hmac.compare_digest(str(h), _huella_password(nuevo)))


def _poner_password(u, nuevo: str) -> None:
    """4.25 (9b, D-Q): escribe el hash de contraseña de quien viene de la web. Si un hash real se cambia por uno que no sirve (el
    inservible), guarda antes su huella; si llega uno real, la huella ya no hace falta."""
    if _hash_utilizable(u.password_hash) and not _hash_utilizable(nuevo):
        u.huella_password = _huella_password(u.password_hash)
    elif _hash_utilizable(nuevo):
        u.huella_password = None
    u.password_hash = nuevo


def _aplicar_usuario(sc, eid: int, x: dict):
    """Etapa 1 y 4.25 (instalación, D-E/D-F): aplica la ficha de UNA persona que manda la nube (bajada o ingreso en línea) en la empresa
    `eid`: crea o actualiza por correo y guarda lo que manda la nube tal cual, también el hash inservible (una ficha sin hash queda con
    HASH_INSERVIBLE: sigue en la empresa y no puede entrar con lo guardado). Guarda lo que dijo la web de los dos pasos y de la
    contraseña temporal. Cierra las sesiones de la persona cuando cambia su contraseña (otro hash real), se bloquea o cambia de rol.
    Nunca toca a un administrador del sistema de esta computadora (devuelve None). Devuelve el Usuario (sin commit: lo hace quien llama).
    Revisión de las tandas 3 y 4: (1) el paso al hash inservible no es un cambio de contraseña (es la primera bajada con la política de
    D-E, al actualizar el programa): se guarda, pero no cierra sesiones; (2) con varias empresas vinculadas aquí, el «inservible» de
    una no pisa el hash real (ni el PIN) que manda otra (_hash_de_otra); (3) lo que dijo la web de Recursos humanos es de ESTA empresa:
    va en la membresía, no en la persona."""
    A = _auth
    correo = str(x.get("correo") or "").lower().strip()
    if not correo:
        return None
    u = sc.exec(select(A.Usuario).where(A.Usuario.correo == correo)).first()
    convertida = False
    if u is not None and u.es_superadmin:
        if not A._local_cerrado():                                       # fuera del programa real (o con FE_LOCAL_ADMIN=1): se salta, como siempre
            return None
        _convertir_admin_local(sc, u, eid)                               # 4.25 (tanda 6, E-13): queda como una cuenta normal de la web
        convertida = True
    nuevo, pin = str(x.get("password_hash") or "") or HASH_INSERVIBLE, x.get("pin_hash")
    real = nuevo != HASH_INSERVIBLE                                      # la web le manda a ESTA instalación el hash real: la persona ya entró en línea por ella
    if u is None:
        u = A.Usuario(correo=correo, nombre=x.get("nombre") or correo, password_hash=nuevo); sc.add(u); sc.flush()
        cerrar = False
    else:
        if not real and (u.password_hash or HASH_INSERVIBLE) != HASH_INSERVIBLE and _hash_de_otra(sc, u.id, eid):
            nuevo, pin = u.password_hash, u.pin_hash                     # lo mantiene al día la otra empresa: aquí no cambia nada
        # 4.25 (X2-E): también si cambió la contraseña; 9b (D-Q): un cambio REAL (_cambia_password), no el vaivén real → inservible → el mismo
        cerrar = (bool(x.get("bloqueado")) and not u.bloqueado) or _cambia_password(u, nuevo)
        cerrar = cerrar or convertida
    _poner_password(u, nuevo)
    u.nombre, u.pin_hash, u.bloqueado = x.get("nombre") or u.nombre, pin, bool(x.get("bloqueado"))
    u.de_nube, u.debe_cambiar_password = True, False                     # la contraseña se cambia en la web: aquí la pisaría la siguiente bajada
    if "mfa" in x or "temporal" in x:                                    # 4.25 (D-D): solo una nube 4.25 o posterior los manda
        u.mfa_nube = str(x.get("mfa") or "") or None
        u.mfa_entrar_nube, u.temporal_nube = bool(x.get("mfa_entrar")), bool(x.get("temporal"))
    if x.get("terminos_version") and u.terminos_version != A.TERMINOS_VERSION:   # 4.12: si ya aceptó los vigentes aquí, una versión vieja de la nube no los deshace
        u.terminos_version = x["terminos_version"]
        u.terminos_fecha = u.terminos_fecha or datetime.now(timezone.utc)
    u.paleta = x.get("paleta") or u.paleta
    sc.add(u)
    m = sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.usuario_id == u.id, A.UsuarioEmpresa.empresa_id == eid)).first()
    if m is None:
        m = A.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=x.get("rol") or "Cajero")
    elif m.rol != x.get("rol"):
        cerrar = True
    m.rol, m.sucursal_id, m.modulos_ocultos = x.get("rol") or m.rol, x.get("sucursal_id"), x.get("modulos_ocultos")
    m.hash_nube = real
    if "mfa" in x or "temporal" in x:
        m.mfa_rrhh_nube = bool(x.get("mfa_rrhh"))                        # calculado en la web para la empresa de esta ficha
    sc.add(m); sc.flush()
    if cerrar:
        A._revocar_sesiones(sc, u.id)
    return u


def _bajar_usuarios(sc, eid: int, j: dict) -> None:
    """Etapa 1 (instalación): los usuarios, roles y bloqueos de la empresa los manda la nube. Crea o actualiza por correo (_aplicar_usuario),
    cierra las sesiones de quien se bloqueó, cambió de contraseña o de rol, o salió, y nunca toca a un administrador del sistema ni a quien
    se creó solo aquí. 4.25 (D-F): toda persona que manda la nube queda en la empresa aunque no pueda entrar (hash inservible)."""
    lista = j.get("usuarios")
    if not isinstance(lista, list):
        return
    A = _auth
    vivos = set()
    for r in j.get("roles") or []:
        fila = sc.exec(select(A.RolEmpresa).where(A.RolEmpresa.empresa_id == eid, A.RolEmpresa.nombre == r.get("nombre"))).first()
        if fila is None:
            fila = A.RolEmpresa(empresa_id=eid, nombre=r.get("nombre"))
        fila.descripcion, fila.permisos = r.get("descripcion"), r.get("permisos") or "[]"
        sc.add(fila)
    for x in lista:
        u = _aplicar_usuario(sc, eid, x) if isinstance(x, dict) else None
        if u is not None:
            vivos.add(u.id)
    for m in sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.empresa_id == eid)).all():      # los que la nube ya no tiene en la empresa
        u = sc.get(A.Usuario, m.usuario_id)
        if u is not None and u.de_nube and not u.es_superadmin and u.id not in vivos:
            sc.delete(m); sc.flush()
            A._revocar_sesiones(sc, u.id)
    sc.commit()


def _mas_habiles(d, n: int):
    """Etapa 1: `n` días hábiles después de `d` (lunes a viernes). Los feriados no se descuentan: el plazo real nunca es más corto."""
    while n > 0:
        d += timedelta(days=1)
        if d.weekday() < 5:
            n -= 1
    return d


def franja_local(s, e) -> dict:
    """Etapa 1: el estado único de esta computadora para la franja de la aplicación: conexión con la nube y plazo de Hacienda (emisión + 2 días
    hábiles). Nivel: None (sin aviso), info, alerta (faltan 24 h o menos) o vencido. Nunca bloquea ventas: el sistema solo puede avisar."""
    from . import cola
    cfg = _cfg_local(s, e.id)
    ahora = ahora_cr()
    desde = cfg.get("sin_conexion_desde") if cfg.get("vinculado") else None
    docs = s.exec(select(Documento.fecha_emision).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente, Documento.estado == "firmado", cola.solo_propios())).all()
    n = len(docs)
    por_subir = 0
    if desde:                                                            # 4.14: lo que queda por subir, para la franja
        por_subir = len(s.exec(select(Documento.id).where((Documento.sinc_en == None) | (Documento.sinc_estado != Documento.estado))).all()) + len(s.exec(select(modulos.Pago.id).where(modulos.Pago.sinc_en == None)).all())  # noqa: E711
    vence, horas = None, None
    if n:
        viejo = min(str(x)[:10] for x in docs if x) if any(docs) else ahora.strftime("%Y-%m-%d")
        vence = _mas_habiles(datetime.fromisoformat(viejo).date(), 2)
        horas = (datetime(vence.year, vence.month, vence.day, 23, 59, 59, tzinfo=ahora.tzinfo) - ahora).total_seconds() / 3600
    plazo = vence.strftime("%d/%m/%Y") if vence else ""
    descartada = _conexion_descartada(cfg)                               # 4.25 (D-O): la web descartó sola la conexión: que lo vea todo el que entra
    nivel = "vencido" if (n and horas < 0) else "alerta" if (n and horas <= 24) else "info" if (desde or descartada) else None
    atrasados = usuarios_atrasados(cfg, bool(e.bloqueada))               # 4.25 (D-F): para el aviso de la pantalla (tanda 4)
    if nivel is None:
        return {"nivel": None, "conectado": True, "pendientes": n, "vence": plazo, "usuarios_atrasados": atrasados}
    partes = []
    if descartada:
        partes.append("La página web descartó la conexión de esta computadora porque no se terminó a tiempo. Sigue vendiendo, firmando e imprimiendo, "
                      "pero no sube ni baja nada de la página web (ventas, precios, usuarios) hasta que un administrador la conecte de nuevo en "
                      "Configuración › Instalación local.")
    if desde:
        try:
            cuando = datetime.fromisoformat(desde).astimezone(ahora.tzinfo).strftime("%d/%m/%Y %H:%M")
        except ValueError:
            cuando = ""
        partes.append(f"Sin conexión con la nube desde el {cuando}. Esta computadora sigue vendiendo, firmando e imprimiendo; {por_subir} cambio(s) por subir a la nube, que suben solos cuando regrese.")
    if n:
        partes.append(f"{n} comprobante(s) por enviar a Hacienda: el más viejo vence el {plazo}." if nivel != "vencido"
                      else f"{n} comprobante(s) ya pasaron el plazo de 2 días hábiles para enviarse a Hacienda (venció el {plazo}). Revise la conexión hoy mismo.")
    titulo = {"info": "Computadora sin conectar." if descartada else "Sin conexión.", "alerta": "Plazo de Hacienda por vencer.", "vencido": "Plazo de Hacienda vencido."}[nivel]
    return {"nivel": nivel, "conectado": not desde and not descartada, "pendientes": n, "por_subir": por_subir, "vence": plazo, "titulo": titulo, "texto": " ".join(partes),
            "usuarios_atrasados": atrasados}


_SITUACION = {"t": -1e9, "v": "1"}


def _alcanza(host: str) -> bool:
    try:
        with socket.create_connection((host, 443), timeout=1):
            return True
    except OSError:
        return False


def situacion_emision() -> str:
    """4.13 (confirmado por el contador el 8/11): 3 solo si el problema es el internet de esta computadora. Si alcanza a Hacienda, o si tiene
    internet y la caída es de Hacienda, sale 1: se firma, se guarda y se reenvía al restablecerse el enlace. En la nube siempre 1. Se revisa
    como mucho cada 30 s para no demorar las ventas. FE_SITUACION_3=0 lo apaga."""
    if not MODO_LOCAL or os.environ.get("FE_SITUACION_3", "1") == "0":
        return "1"
    if time.monotonic() - _SITUACION["t"] < 30:
        return _SITUACION["v"]
    v = "1" if any(_alcanza(h) for h in ("api.comprobanteselectronicos.go.cr", "1.1.1.1", "8.8.8.8")) else "3"
    _SITUACION.update(t=time.monotonic(), v=v)
    return v


def correo_en_nube(eid: int) -> bool:
    """4.12: ¿los correos a clientes los manda la nube? Solo si la instalación está vinculada y la nube tiene correo configurado."""
    try:
        with Session(engine_empresa(eid)) as s:
            cfg = _cfg_local(s, eid)
            return bool(cfg.get("vinculado") and cfg.get("correo_nube"))
    except Exception:  # noqa: BLE001
        return False


def vinculada(eid: int) -> bool:
    """Etapa 1: ¿esta instalación está vinculada a la nube? Entonces los correos a clientes los manda la nube."""
    try:
        with Session(engine_empresa(eid)) as s:
            return bool(_cfg_local(s, eid).get("vinculado"))
    except Exception:  # noqa: BLE001
        return False


# 4.31 (16a): en el programa CONECTADO, los datos de la empresa que manda la web (CAMPOS_EMPRESA) no se cambian aquí: la bajada siguiente
# los pisaba en silencio. Configuración › Empresa y › Facturación electrónica mandan la empresa entera más `antes` (lo que tenían esos
# campos al cargarse la pantalla). Un campo igual a `antes` se ignora (no se escribe ni da error, aunque la base ya tenga otro valor por
# una bajada); uno que la persona cambió da 409. Una pantalla vieja (sin `antes`): se ignoran y la respuesta lo avisa. La sucursal (y la
# terminal, que no es de CAMPOS_EMPRESA) siguen con su propia regla (_empresa_fija: 400 «quedaron fijas»).
MENSAJE_SOLO_WEB_EMPRESA = "Se cambia en la página web ({web})."
AVISO_EMPRESA_WEB = ("Los datos de la empresa que manda la página web (nombre, identificación, actividad, dirección, contacto, ambiente y "
                     "facturación electrónica) no se cambiaron aquí: se cambian en la página web ({web}).")
CAMPOS_EMPRESA_WEB = tuple(k for k in CAMPOS_EMPRESA if k != "sucursal")


def _comparable_empresa(k: str, v) -> str:
    """Un valor de la empresa para comparar lo que manda la pantalla con lo que tenía (o con la base): vacío y nulo son lo mismo; la
    cédula y el proveedor de sistemas se comparan solo por letras y dígitos (el servidor los normaliza igual)."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    t = str(v).strip()
    if k in ("numero_id", "proveedor_sistemas"):
        t = "".join(ch for ch in t if ch.isalnum()).upper()
    return t


def campos_de_la_web(e, data) -> Optional[dict]:
    """4.31 (16a): para PUT /api/empresa (main.put_empresa). Fuera del programa, o en un programa sin conectar: None (nada cambia). En el
    programa conectado: 409 si la persona cambió algún campo de CAMPOS_EMPRESA (lo que manda ≠ `antes` y ≠ lo guardado); si no, pone en
    `data` lo guardado en esos campos (así no se validan ni se escriben) y devuelve {ignorados, aviso}."""
    if not MODO_LOCAL or e is None or not vinculada(int(e.id)):
        return None
    antes = getattr(data, "antes", None)
    campos = [k for k in CAMPOS_EMPRESA_WEB if k in type(data).model_fields and hasattr(e, k)]
    if isinstance(antes, dict):
        cambiados = [k for k in campos if k in antes and _comparable_empresa(k, getattr(data, k, None)) != _comparable_empresa(k, antes.get(k))
                     and _comparable_empresa(k, getattr(data, k, None)) != _comparable_empresa(k, getattr(e, k, None))]
        if cambiados:
            raise HTTPException(409, {"codigo": "solo_web_empresa", "campos": cambiados, "mensaje": MENSAJE_SOLO_WEB_EMPRESA.format(web=_web())})
    distintos = [k for k in campos if _comparable_empresa(k, getattr(data, k, None)) != _comparable_empresa(k, getattr(e, k, None))]
    for k in campos:
        setattr(data, k, getattr(e, k, None))
    return {"ignorados": campos, "aviso": AVISO_EMPRESA_WEB.format(web=_web()) if distintos and not isinstance(antes, dict) else None}


def _instalacion_de(v: dict, ctx: Contexto):
    pref = ctx.token_api.prefijo if ctx.token_api is not None else None
    return next((i for i in v.get("instalaciones", []) if pref and i.get("prefijo") == pref), None)


def _anotar_instalacion(s, eid, ctx, **cambios):
    """Actualiza la ficha de la instalación que llama (última bajada/subida, contadores, versión)."""
    v = _leer(s, eid, CLAVE_VINC, {})
    inst = _instalacion_de(v, ctx)
    if not inst:
        return
    inst["ultimo_contacto"] = _ahora()       # 4.9 (E3): en cada llamada de la instalación (bajar o subir): la nube sabe que sigue viva
    for k, x in cambios.items():
        if k.startswith("mas_"):
            inst[k[4:]] = int(inst.get(k[4:]) or 0) + int(x)
        elif x is not None:
            inst[k] = x
    _escribir(s, eid, CLAVE_VINC, v); s.commit()


def instalaciones_vivas(s, eid: int, desde: str) -> tuple[set, set]:
    """4.9 (E3, lado nube): terminales y nombres (como los guarda origen_sinc, 40 caracteres) de las instalaciones vigentes que
    hablaron con la nube desde `desde` (ISO UTC): último contacto (cualquier bajada o subida, cada pocos minutos mientras
    sincroniza), última bajada o subida, o su alta. Una instalación retirada (revocada) no cuenta. Lo usa cola.retomables."""
    v = _leer(s, eid, CLAVE_VINC, {})
    terminales, nombres = set(), set()
    for i in v.get("instalaciones") or []:
        if not isinstance(i, dict):
            continue
        ultimo = max(str(i.get(k) or "") for k in ("ultimo_contacto", "ultima_bajada", "ultima_subida", "creado"))
        if ultimo >= desde:
            terminales.add(int(i.get("terminal") or 0))
            if i.get("nombre"):
                nombres.add(str(i["nombre"])[:40])
    return terminales, nombres


def _revocacion_explicita(authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)) -> None:
    """4.9 (lado nube, contrato 5a): la señal explícita de revocación para la instalación local. El token de la empresa de una
    instalación revocada en Configuración › Instalación local (quitar_instalacion) recibe 401 con detail.codigo
    «instalacion_revocada» antes de cualquier otra revisión. Un 401/403 sin ese código (empresa bloqueada, token desconocido,
    cortafuegos) no es revocación: la instalación solo avisa y reintenta. Sigue siendo 401 para que una versión anterior del
    programa local se entere igual que antes. Va como primera dependencia de los endpoints que usa la instalación.
    4.25 (D-O): si la web descartó SOLA esa instalación (_descartar_sin_estrenar: ficha retirada con el id de ese token y motivo
    «sin_estrenar» en la configuración de SU empresa), el detalle agrega motivo «sin_estrenar»; si no se puede saber, va sin motivo. El
    código y el 401 no cambian (un programa anterior no mira el motivo)."""
    if not authorization or not authorization.lower().startswith("bearer fcr_"):
        return
    t = sc.exec(select(TokenApi).where(TokenApi.hash == _hash_token_api(authorization.split(" ", 1)[1].strip()))).first()
    if t is not None and t.revocado and t.usuario_id == TOKEN_EMPRESA:
        detalle = {"codigo": CODIGO_REVOCADA, "mensaje": "Esta instalación fue revocada en la nube. Para que vuelva a sincronizar, un administrador "
                   "genera un código nuevo en Configuración › Instalación local y la vincula de nuevo."}
        if _descartada_sin_estrenar(t):
            detalle["motivo"] = MOTIVO_SIN_ESTRENAR
        raise HTTPException(401, detalle)


MOTIVO_SIN_ESTRENAR = "sin_estrenar"                # 4.25 (D-O): detail.motivo de la señal de revocación cuando la web descartó sola la conexión


def _descartada_sin_estrenar(t) -> bool:
    """4.25 (D-O): el token revocado `t` es el de una instalación que la web descartó sola (_descartar_sin_estrenar anota en `retiradas` el
    id del token y el motivo). Se busca SOLO en la configuración de la empresa del token. Ante cualquier duda, False (revocación de siempre)."""
    try:
        eid, tid = int(t.empresa_id or 0), int(t.id or 0)
        if not eid or not tid:
            return False
        with Session(engine_empresa(eid)) as s:
            v = _leer(s, eid, CLAVE_VINC, {})
        return any(isinstance(x, dict) and x.get("motivo") == MOTIVO_SIN_ESTRENAR and int(x.get("token_id") or 0) == tid
                   for x in v.get("retiradas") or [])
    except Exception as ex:  # noqa: BLE001
        log.info("sinc: no se pudo saber si la instalación se descartó sola (%s)", type(ex).__name__)
        return False


def _cuentas_iniciales(lista) -> list:
    """4.29 (B-2): las cuentas de Bancos para sembrar, limpias: solo nombre, tipo, moneda, número, descripción, cuenta contable y
    principal (más su id), sin saldos ni movimientos, sin filas de ejemplo (marca «ejemplo», como api.js mock.ejemplos) y sin nombres
    vacíos o repetidos. Sirve a los dos lados: la nube arma con esto lo que manda y el programa vuelve a limpiar lo que recibe."""
    out, nombres, ids = [], set(), set()
    for x in (lista if isinstance(lista, list) else [])[:500]:
        if not isinstance(x, dict) or x.get("ejemplo") is True:
            continue
        nombre = str(x.get("nombre") or "").strip()
        if not nombre or nombre in nombres:
            continue
        c = {"nombre": nombre, "tipo": str(x.get("tipo") or "Banco"), "moneda": str(x.get("moneda") or "CRC").upper(), "numero": str(x.get("numero") or ""),
             "descripcion": str(x.get("descripcion") or ""), "cuenta_contable": str(x.get("cuenta_contable") or ""), "principal": x.get("principal") is True}
        iid = modulos._id_entero(x.get("id"))
        if iid is not None and 0 < iid < 2 ** 53 and iid not in ids:
            c = {"id": iid, **c}
            ids.add(iid)
        nombres.add(nombre)
        out.append(c)
    libre = max(ids, default=0)
    for c in out:                                                # un id faltante o repetido recibe uno nuevo por encima de todos
        if "id" not in c:
            libre += 1
            c["id"] = libre
    return [{"id": c["id"], **{k: c[k] for k in CAMPOS_BANCO_INICIAL}} for c in out]


def _bancos_iniciales(s, eid: int) -> list:
    """4.29 (B-2, lado nube): las cuentas de Bancos de la empresa para que una computadora recién conectada nazca con ellas. Nunca hace
    fallar la bajada del catálogo: ante cualquier error, lista vacía (el programa cae entonces en «Caja general», B-3)."""
    try:
        return _cuentas_iniciales(modulos.leer(s, eid, "bancos", None))
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc: cuentas de Bancos para la instalación (empresa %s): %s", eid, type(ex).__name__)
        return []


def _sembrar_bancos(s, e: Empresa, j: dict) -> str:
    """4.29 (B-1 a B-4, lado programa): siembra el registro «bancos» SOLO si esta computadora todavía no lo tiene (aunque esté vacío o
    sea distinto del de la web, si existe no se toca jamás). Con las cuentas que mandó la web (campo bancos_iniciales): las copia con
    saldo inicial 0 y la fecha de hoy (los saldos y movimientos de la web no se copian: el programa lleva los suyos). Si la web no mandó
    ninguna (no tiene cuentas, o es una web anterior que no manda el campo) y la empresa es de un tipo que en la web nace con «Caja
    general», la crea con modulos.cuenta_efectivo_inicial. Devuelve «web», «caja_general» o «» (no hizo nada)."""
    eid = e.id
    if modulos._registro(s, eid, "bancos") is not None:
        return ""
    cuentas = _cuentas_iniciales(j.get(CAMPO_BANCOS_INICIALES) if isinstance(j, dict) else None)
    if cuentas:
        hoy = ahora_cr().date().isoformat()
        modulos.reemplazar(s, eid, "bancos", [{**c, "saldo_inicial": 0, "fecha_saldo": hoy} for c in cuentas], version=0)   # version=0: solo si no existe
        s.commit()
        return "web"
    if tipo_negocio_de(e) in TIPOS_CON_CAJA and modulos.cuenta_efectivo_inicial(s, eid):
        s.commit()
        return "caja_general"
    return ""


@router.get("/catalogo")
def catalogo(_rev: None = Depends(_revocacion_explicita), ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """Datos de la empresa, clientes, ítems, bodegas, existencias y registros de configuración para la instalación local."""
    if _auth.solo_pos(ctx.permisos):          # 3.87: trae costos y el catálogo contable; el token de la instalación nunca es «solo caja»
        raise HTTPException(403, "Su rol no usa la instalación local")
    eid = ctx.empresa.id
    _anotar_instalacion(s, eid, ctx, ultima_bajada=_ahora())     # antes de leer: su commit vence los objetos ya cargados
    v = _leer(s, eid, CLAVE_VINC, {})
    inst = _instalacion_de(v, ctx) or {}
    instalacion = {"nombre": inst.get("nombre"), "terminal": inst.get("terminal"), "revocadas": [int(x.get("terminal") or 0) for x in v.get("retiradas", [])]}
    registros = {}
    for clave in CLAVES_CATALOGO:
        if clave.endswith("-"):   # prefijo: todas las claves que empiecen así (numeración por tipo)
            for r in s.exec(select(modulos.Registro).where(modulos.Registro.empresa_id == eid)).all():
                if r.clave.startswith(clave):
                    registros[r.clave] = modulos.leer(s, eid, r.clave, None)
            continue
        v = modulos.leer(s, eid, clave, None)
        if v is not None:
            registros[clave] = v
    bodegas = s.exec(select(inventario.Bodega).where(inventario.Bodega.empresa_id == eid)).all()
    bids = {b.id for b in bodegas}
    existencias = [{"producto_id": x.producto_id, "bodega_id": x.bodega_id, "cantidad": x.cantidad, "costo_promedio": x.costo_promedio}
                   for x in s.exec(select(inventario.Existencia)).all() if x.bodega_id in bids]
    extra = {"credenciales_huella": _huella_credenciales(ctx.empresa), "correo_nube": bool(ctx.empresa.smtp_host and ctx.empresa.smtp_remitente), **_usuarios_empresa(eid)} if inst else {}   # etapa 1: solo al token de una instalación
    if inst and (inst.get("ingreso_en_linea") or _avisa_ingreso(ctx.request)):   # 4.25 (D-E): el hash real solo de quien ya entró en línea en ella (la cabecera sola no deja marca)
        with Session(engine) as sc:
            extra["usuarios"] = _con_politica(sc, extra["usuarios"], ctx.token_api.id)
    if inst:                                                     # 4.29 (B-2): solo al token de una instalación; campo aparte, fuera de «registros»
        extra[CAMPO_BANCOS_INICIALES] = _bancos_iniciales(s, eid)
    return {"hora": _ahora(), "empresa": _datos_empresa(ctx.empresa, ctx.request),
            "clientes": [c.model_dump() for c in s.exec(select(Cliente)).all()],
            "productos": [p.model_dump() for p in s.exec(select(Producto)).all()],
            "bodegas": [b.model_dump() for b in bodegas], "existencias": existencias, "registros": registros, "instalacion": instalacion, "datos_v2": sinc_datos.encendido(), **extra}


@router.get("/credenciales")
def credenciales_instalacion(_rev: None = Depends(_revocacion_explicita), ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """Etapa 1: las credenciales de Hacienda vigentes, solo para el token de una instalación de esta empresa."""
    if not _instalacion_de(_leer(s, ctx.empresa.id, CLAVE_VINC, {}), ctx):
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    return {"credenciales": _credenciales_de(ctx.empresa), "huella": _huella_credenciales(ctx.empresa)}


ESTADOS_EFECTO = ("aceptado", "rechazado")                     # 4.9 (E6): resultados de Hacienda cuyos efectos se aplican al recibirlos
PREVIOS_EFECTO = ("generado", "firmado", "enviado", "error", "interno")    # estados desde los que esos efectos todavía no se aplicaron (4.9, R2: anular un interno también revierte)


def _aplicar_resultado(s, eid: int, doc: Documento, previo: str, final: str) -> None:
    """4.9 (5b, E6): el resultado de Hacienda que sube quien emitió el comprobante tiene aquí los mismos efectos que si este servidor
    lo hubiera consultado (main._aplicar_estado_hacienda): un rechazo revierte el inventario rebajado al recibirlo y libera lo cobrado
    de TiKe; una nota de crédito aceptada o rechazada recalcula el saldo de la factura que corrige. Desde la 4.9 este servidor ya no
    consulta lo que emitió otro, así que sin esto la reversión no se hacía nunca y _bajar_existencias además le deshacía a la
    instalación la suya. No manda correos (los manda quien lo emitió). Una reversión ya hecha no se repite (la función revisa los
    movimientos «REV» y solo actúa en una transición real)."""
    from types import SimpleNamespace
    from .main import _aplicar_estado_hacienda
    mensaje = doc.mensaje_hacienda
    doc.estado = previo
    _aplicar_estado_hacienda(s, SimpleNamespace(id=eid), doc, {"estado": final, "detalle": mensaje})
    if mensaje:
        doc.mensaje_hacienda = mensaje
    s.add(doc); s.flush()


def _guardar_documentos(s, eid: int, documentos: list, terminal: str, de_red: bool = False, desde_nube: bool = False,
                        terminal_ficha: Optional[int] = None) -> tuple[list, list]:
    """Comprobantes emitidos en otra instalación: se guardan tal cual (XML firmado, respuesta y estado), sin numerar ni enviar.
    Con de_red (vienen de otra computadora del local) quedan marcados como ya subidos: los sube a la nube la que los emitió.
    4.9 (E6): el resultado de Hacienda que traen se aplica aquí (_aplicar_resultado); uno que llega ya rechazado no rebaja
    inventario; una copia atrasada (firmado/enviado) no le quita el resultado que ya tenía; y cada comprobante se guarda por
    separado (antes un error deshacía los anteriores del lote, que igual se daban por recibidos y ya no volvían a subir).
    4.9 (R1): el inventario se mueve con la misma regla de la emisión (main.py, crear_comprobante)."""
    recibidos, errores = [], []
    for d in documentos or []:
        try:
            clave = str(d.get("clave") or "")
            if len(clave) != 50:
                raise ValueError("clave inválida")
            doc = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
            nuevo = doc is None
            antes = None if nuevo else doc.estado                       # 4.9 (E6)
            mensaje_antes = None if nuevo else doc.mensaje_hacienda
            historia = desde_nube and bool(d.get("historia"))            # etapa 2a: anterior a la vinculación: se ve, pero sus efectos ya están en la foto inicial
            if nuevo:
                doc = Documento(empresa_id=eid, clave=clave, origen_sinc=terminal)
            for k in CAMPOS_DOC:
                # creado: la fecha de alta en la nube es la de hoy; pagado: lo lleva la nube con los cobros que la instalación sube (3.13)
                if k in d and k not in ("clave", "creado", "pagado") and d[k] is not None:
                    setattr(doc, k, d[k])
            if antes in ESTADOS_EFECTO and doc.estado in ("generado", "firmado", "enviado"):
                doc.estado = antes            # 4.9: una copia atrasada no le quita el resultado de Hacienda (p. ej. la nube lo retomó: cola.retomables)
            if desde_nube and not nuevo and not doc.origen_sinc and doc.estado not in ESTADOS_EFECTO:
                doc.estado, doc.mensaje_hacienda = antes, mensaje_antes   # 4.16: lo emitido aquí: de la nube solo cuenta un resultado final
            if desde_nube and nuevo and d.get("pagado_base"):
                doc.pagado = float(d["pagado_base"])                      # 4.16: lo cobrado sin cobro registrado (históricos importados); los cobros suman encima
            if isinstance(doc.otros_cargos, (list, dict)):
                doc.otros_cargos = json.dumps(doc.otros_cargos)
            archivable = _clave_valida(clave)                          # 4.25: solo una clave de 50 dígitos arma el nombre de un archivo
            if d.get("xml_b64") and archivable:
                doc.xml_nombre = _guardar_xml(clave, base64.b64decode(d["xml_b64"]))
            if d.get("respuesta_b64") and archivable:
                doc.respuesta_nombre = _guardar_xml(clave, base64.b64decode(d["respuesta_b64"]), respuesta=True)
            if desde_nube and d.get("sin_xml") and archivable:         # etapa 2a (decisión 8): el XML viejo se baja la primera vez que se pide (traer_archivos)
                doc.xml_nombre = doc.xml_nombre or f"{clave}.xml"
                if d.get("tiene_respuesta"):
                    doc.respuesta_nombre = doc.respuesta_nombre or f"{clave}_respuesta.xml"
            if d.get("correo_enviado") and not str(d["correo_enviado"]).startswith("enviando"):
                doc.correo_enviado = d["correo_enviado"]                 # etapa 2a: así la computadora sabe que la nube ya lo envió
            if d.get("cliente_numero_id"):
                cl = s.exec(select(Cliente).where(Cliente.numero_id == str(d["cliente_numero_id"]))).first()
                doc.cliente_id = cl.id if cl else None
            doc.sinc_en = _ahora()
            if not desde_nube:                                         # 4.16: uno emitido aquí no se vuelve «de la nube» al bajar su copia
                doc.origen_sinc = doc.origen_sinc or terminal
            if de_red and (not desde_nube or d.get("estado") == doc.estado):   # etapa 2a: si aquí va adelante de la copia que bajó, lo suyo todavía tiene que subir
                doc.sinc_estado = doc.estado
            s.add(doc); s.flush()
            if nuevo:
                lineas = []
                for i, l in enumerate(d.get("lineas") or [], 1):
                    pid = l.get("producto_id")
                    if pid and not s.get(Producto, int(pid)):
                        pid = None
                    lineas.append(DocumentoLinea(documento_id=doc.id, **{k: l.get(k) for k in CAMPOS_LINEA if k in l and k != "producto_id"}, producto_id=pid))
                for ln in lineas:
                    if not ln.numero:
                        ln.numero = len(lineas)
                    s.add(ln)
                # 4.9 (E6): uno que llega ya rechazado no mueve nada (la venta no existió; antes se rebajaba y nunca se revertía)
                # 4.9 (R1): la regla de la emisión, no solo «producción»: también lo interno (sin facturación electrónica, con el ambiente por
                # omisión), la factura de compra 08 (entra con su costo) y la nota de crédito solo si devuelve mercadería. Esta existencia es
                # la que _bajar_existencias iguala en todas las computadoras: con otra regla, la bajada les deshacía la venta o la compra.
                if ((doc.ambiente or "") == "produccion" or doc.estado == "interno") and doc.estado != "rechazado" and not historia:
                    fecha = str(doc.fecha_emision or "")[:10]
                    bodega = modulos._id_entero(d.get("bodega_id"))   # 4.9 (F1)
                    if bodega and s.get(inventario.Bodega, bodega) is None:
                        bodega = None
                    if doc.tipo_documento == "08":
                        compra = [{"producto_id": ln.producto_id, "cantidad": ln.cantidad,
                                   "costo": (float(ln.precio_unitario or 0) * float(ln.cantidad) - float(ln.descuento or 0)) / float(ln.cantidad) if ln.cantidad else 0}
                                  for ln in lineas if ln.producto_id]
                        inventario.ingresar_por_compra(s, eid, doc.id, doc.consecutivo or "", bodega, compra, fecha, float(doc.tipo_cambio or 1) if (doc.moneda or "CRC") != "CRC" else 1.0)
                    elif doc.tipo_documento in VENTAS or (doc.tipo_documento == "03" and (doc.referencia_codigo or "01") in ("01", "06", "13")):
                        inventario.descontar_por_venta(s, eid, doc.id, doc.consecutivo or "", bodega, [{"producto_id": ln.producto_id, "cantidad": ln.cantidad} for ln in lineas if ln.producto_id],
                                                       fecha, devolucion=doc.tipo_documento == "03", permitir_negativo=True)
            enlazado = None                                            # 4.32 (§4.5): el pedido en línea que cobró este comprobante
            ped = d.get("pedido") if isinstance(d.get("pedido"), dict) else None
            if ped and modulos._id_entero(ped.get("id")):
                ajeno = False
                if terminal_ficha and not desde_nube and not de_red:
                    # revisión n.º 34: el pedido que atiende OTRA computadora no se guarda ni se enlaza con este comprobante. Con atiende = 0
                    # (pedido rescatado) sí se guarda Documento.pedido_id: de eso depende el aviso de «ya cobrado» (n.º 12)
                    from . import pedidos as _ped
                    _pp = s.get(_ped.Pedido, modulos._id_entero(ped.get("id")))
                    ajeno = bool(_pp is not None and _pp.empresa_id == eid and int(_pp.atiende or 0) > 0 and int(_pp.atiende) != int(terminal_ficha))
                if not ajeno:
                    doc.pedido_id = modulos._id_entero(ped.get("id")); doc.pedido_parcial = bool(ped.get("parcial")); s.add(doc)
                    if not desde_nube and not de_red:
                        from . import pedidos as _ped
                        enlazado = _ped.enlazar_desde_programa(s, eid, doc.pedido_id, doc, doc.pedido_parcial,
                                                               terminal=terminal_ficha)   # nunca lanza; en el programa no hace nada
            previo = "enviado" if nuevo else antes
            if doc.estado in ESTADOS_EFECTO and previo in PREVIOS_EFECTO and not historia:
                _aplicar_resultado(s, eid, doc, previo, doc.estado)      # 4.9 (E6): aceptado/rechazado que subió quien lo emitió
            elif nuevo and doc.estado == "interno" and doc.tipo_documento == "03" and doc.referencia_clave:
                modulos.recalcular_acreditado(s, eid, doc.referencia_clave)   # 4.9 (R2): la nota interna no espera a Hacienda: rebaja ya el saldo (como en la emisión)
            s.commit()                                                     # 4.9: uno por uno (un error ya no deshace los anteriores)
            if enlazado:
                _ped.tras_enlace(eid, enlazado)                            # 4.32: puntos y correo «entregado», después del commit (nunca lanza)
            if doc.estado == "rechazado" and previo in PREVIOS_EFECTO and not historia:
                from .main import revertir_cobros_rechazado
                revertir_cobros_rechazado(s, eid, doc, previo)             # 4.15: la copia del cobro que ya había subido
            recibidos.append(clave)
        except Exception as ex:  # noqa: BLE001
            s.rollback(); errores.append({"clave": d.get("clave"), "error": str(ex)[:200]})
    s.commit()
    return recibidos, errores


@router.post("/documentos")
def recibir_documentos(_rev: None = Depends(_revocacion_explicita), cuerpo: dict = Body(...), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """Comprobantes emitidos en una instalación local (nube)."""
    eid = ctx.empresa.id
    from . import avisos_dueno as _avisos                 # 3.87: los rechazos que la instalación consultó se avisan al dueño desde la nube
    antes = _avisos.estados_de(s, eid, cuerpo.get("documentos") or [])
    inst = _instalacion_de(_leer(s, eid, CLAVE_VINC, {}), ctx) or {}
    with diario.aplicando(int(inst.get("terminal") or 0)):             # etapa 2a: no se le devuelve a quien lo subió
        recibidos, errores = _guardar_documentos(s, eid, cuerpo.get("documentos") or [], str(cuerpo.get("terminal") or "local")[:40],
                                                 terminal_ficha=int(inst.get("terminal") or 0) or None)   # revisión n.º 34: la de la ficha
    _avisos.tras_subida(ctx.empresa, antes, recibidos)
    pedidos = [x.get("clave") for x in cuerpo.get("documentos") or [] if isinstance(x, dict) and x.get("pedir_correo") and x.get("clave") in recibidos]
    if pedidos and not MODO_LOCAL:                                       # etapa 1: el correo al cliente lo manda la nube (una sola vez: _programar lo reclama)
        from .main import _programar_correo_automatico
        for d in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave.in_(pedidos), Documento.estado == "aceptado")).all():  # type: ignore[union-attr]
            _programar_correo_automatico(ctx.empresa, d, None)
    _anotar_instalacion(s, eid, ctx, ultima_subida=_ahora(), mas_documentos=len(recibidos), version=str(cuerpo.get("version") or "") or None)
    return {"recibidos": recibidos, "errores": errores}


def _upsert(s, modelo, filas: list[dict], eid: int) -> int:
    """Altas y cambios por id de clientes, ítems o bodegas. La fila queda de la empresa de esta base (en la instalación local el
    id de la empresa no es el de la nube)."""
    n = 0
    for d in filas:
        if not isinstance(d, dict) or not d.get("id"):
            continue
        obj = s.get(modelo, int(d["id"]))
        if obj is None:
            obj = modelo(**{k: v for k, v in d.items() if k in modelo.model_fields})
        else:
            for k, v in d.items():
                if k == "direcciones" and v is None and getattr(obj, k, None):
                    continue                      # 4.6: una copia que no trae direcciones (versión anterior) no borra las guardadas
                if k in modelo.model_fields and k != "id":
                    setattr(obj, k, v)
        obj.empresa_id = eid
        s.add(obj); n += 1
    return n


def _upsert_productos(s, filas: list[dict], eid: int) -> int:
    """_upsert de ítems que manda OTRA computadora (a la web, /api/sinc/cambios; o a esta, por la red del local, /red/…/cambios), con la
    protección de códigos de la 4.24: quien manda el ítem entero puede no haber visto el código que se le puso aquí (p. ej. «Generar
    códigos de barras», con etiquetas ya pegadas): el código que tenía la fila no se pierde, queda como código alterno.
    «Eliminar» del otro lado un ítem con ventas lo deja inactivo y sin código ni códigos alternos para LIBERARLOS (U12): no es un código que
    no haya visto, así que aquí también queda libre (no vuelve como código alterno)."""
    from . import etiquetas
    desplazados = {}
    for d in filas:
        obj = s.get(Producto, int(d["id"])) if isinstance(d, dict) and d.get("id") and "codigo" in d else None
        liberado = d.get("activo") is False and not str(d.get("codigo") or "").strip() and "codigos_alternos" in d and not str(d.get("codigos_alternos") or "").strip()
        if obj is not None and not liberado and (obj.codigo or "").strip() and (obj.codigo or "").strip().lower() != str(d.get("codigo") or "").strip().lower():
            desplazados[obj.id] = obj.codigo
    n = _upsert(s, Producto, filas, eid)
    for pid, codigo_anterior in desplazados.items():
        etiquetas.agregar_alterno(s.get(Producto, pid), codigo_anterior)
    return n


@router.post("/cambios")
def recibir_cambios(_rev: None = Depends(_revocacion_explicita), cuerpo: dict = Body(...), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """Lo que creó la instalación local (3.13): clientes e ítems nuevos, cobros recibidos y registros operativos. Todo con ids
    del rango de su terminal; los que ya no están en `*_vivos` se dan de baja. Los cobros se aplican a los comprobantes por su
    clave (ya subidos) y entran en Bancos como un cobro de la nube."""
    eid = ctx.empresa.id
    v = _leer(s, eid, CLAVE_VINC, {})
    inst = _instalacion_de(v, ctx)
    if not inst:
        raise HTTPException(403, "Esta instalación no está vinculada (genere un código nuevo en la nube)")
    terminal = int(inst.get("terminal") or 0)
    if terminal < 1 or (cuerpo.get("terminal") is not None and int(cuerpo["terminal"]) != terminal):
        raise HTTPException(400, f"La terminal no coincide con la vinculada ({terminal})")
    nombre_inst = str(inst.get("nombre") or f"terminal {terminal}")
    with diario.aplicando(terminal):                                   # etapa 2a: no se le devuelve a quien lo subió
        return _aplicar_cambios_instalacion(s, ctx, eid, terminal, nombre_inst, cuerpo)


def _pago_de_ref(s, eid: int, ref: str, propias: set | None = None):
    """El cobro con esa identidad: copia de otro lado (origen_sinc) o nacido en esta base (terminal propia, id y el segundo en que nació)."""
    p = s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid, modulos.Pago.origen_sinc == ref)).first()
    if p is not None:
        return p
    partes = str(ref).split(":")
    if len(partes) == 3 and all(x.isdigit() for x in partes) and int(partes[0]) in (propias or {modulos.rango_propio(eid)}):
        p = s.get(modulos.Pago, int(partes[1]))
        if p is not None and not p.origen_sinc and diario.sello(p) == int(partes[2]):
            return p
    return None


def _borrar_cobro_por_ref(s, eid: int, ref: str, permitidos: tuple | None = None, propias: set | None = None) -> bool:
    """Etapa 2a: la baja de un cobro hecha del otro lado: sale su movimiento de Bancos, se rebaja lo aplicado y se borra. Una computadora no borra
    en la nube un cobro conciliado (la regla de la 4.15): queda auditado para revisarlo."""
    from .main import _ref_pago
    if permitidos is not None and not str(ref).startswith(permitidos):
        return False
    p = _pago_de_ref(s, eid, ref, propias)
    if p is None:
        return False
    pid, facturas = p.id, json.loads(p.facturas or "[]")
    refs = [_ref_pago(p), f"pago:{pid}"]
    if permitidos is not None and (p.estado == "Conciliado" or any(isinstance(m, dict) and m.get("ref") in refs and m.get("conciliado") for m in modulos.leer(s, eid, "movimientos", []) or [])):
        with Session(engine) as sc:
            auditar(sc, "sinc_baja_conciliado", f"Una computadora borró el cobro #{p.numero}, pero aquí está conciliado y no se tocó: revíselo", None, eid, None)
        return False
    modulos.quitar_movimientos_banco(s, eid, refs)
    p = s.get(modulos.Pago, pid)
    if p is None:
        return False
    modulos.aplicar_pago(s, eid, facturas, -1)
    s.delete(p); s.commit()
    return True


def _guardar_pago(s, eid: int, p: dict, origen: str, etiqueta: str, mapa_doc: dict, historia: bool = False, respetar_numero: bool = False, propias: set | None = None) -> bool:
    """El cobro que llega de otro lado, con sus comprobantes por clave. Reintentar no lo duplica. La historia no vuelve a mover Bancos."""
    if _pago_de_ref(s, eid, origen, propias) is not None:
        return False
    facturas = []
    for f in p.get("facturas") or []:
        did = mapa_doc.get(f.get("clave")) if f.get("clave") else None
        if did is None and f.get("clave"):
            d0 = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == f["clave"])).first()
            did = d0.id if d0 else None
        if did is None:
            raise ValueError(f"el comprobante {f.get('consecutivo') or f.get('clave')} todavía no está en la nube")
        d0 = s.get(Documento, did)
        if d0.estado == "rechazado" and not respetar_numero:           # 4.16: subió tarde: la computadora lo revierte al bajarle el rechazo, en este mismo ciclo
            raise ValueError(f"Hacienda rechazó el comprobante {d0.consecutivo}: el cobro no se registra")
        facturas.append({"id": did, "consecutivo": d0.consecutivo, "monto": round(float(f.get("monto") or 0), 2)})
    documentos = []
    for x in p.get("documentos") or []:
        d0 = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == str(x.get("clave") or ""))).first()
        documentos.append({"id": d0.id if d0 else None, "consecutivo": x.get("consecutivo"), "clave": x.get("clave"), "estado": x.get("estado")})
    numero = (max((q.numero for q in s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid)).all()), default=0) or 0) + 1
    pedido = modulos._id_entero(p.get("numero")) if respetar_numero else None
    if pedido and not s.exec(select(modulos.Pago.id).where(modulos.Pago.empresa_id == eid, modulos.Pago.numero == pedido)).first():
        numero = pedido
    campos = {k: p.get(k) for k in CAMPOS_PAGO if p.get(k) is not None}
    campos["monto"] = round(float(campos.get("monto") or 0), 2)
    if campos.get("cliente_id") and not s.get(Cliente, int(campos["cliente_id"])):
        campos["cliente_id"] = None
    pago = modulos.Pago(empresa_id=eid, numero=numero, **campos, facturas=json.dumps(facturas), documentos=json.dumps(documentos),
                        origen_sinc=origen, sinc_en=_ahora())
    modulos.aplicar_pago(s, eid, facturas, +1)
    s.add(pago); s.commit(); s.refresh(pago)
    if historia:
        return True
    try:
        ref = f"pago:{pago.id}:{int(pago.creado.replace(tzinfo=pago.creado.tzinfo or timezone.utc).timestamp())}"
        desc = (f"{'Recibo electrónico de pago' if pago.tipo == 'rep' else 'Recibo de caja'} #{numero} · {etiqueta}"
                + (f" · {pago.cliente_nombre}" if pago.cliente_nombre else "") + (f" · {pago.detalles}" if pago.detalles else ""))
        modulos.registrar_movimiento_banco(s, eid, pago.cuenta, float(pago.monto), pago.fecha, desc, ref, moneda=pago.moneda, tipo_cambio=pago.tipo_cambio)
        s.commit()
    except Exception as ex:  # noqa: BLE001  el cobro queda registrado aunque el movimiento falle
        log.warning("sinc: movimiento bancario del cobro %s: %s", pago.id, ex); s.rollback()
    return True


def _aplicar_cambios_instalacion(s, ctx, eid: int, terminal: int, nombre_inst: str, cuerpo: dict) -> dict:
    out = {"terminal": terminal, "clientes": 0, "productos": 0, "registros": {}, "pagos": [], "pagos_borrados": 0, "errores": []}
    # ---- clientes e ítems creados en la instalación (ids de su rango) ----
    for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
        if clave not in cuerpo and clave + "_vivos" not in cuerpo:
            continue
        if not ctx.puede("catalogos"):
            out["errores"].append({"parte": clave, "error": "El token no puede crear clientes ni ítems"}); continue
        try:
            filas = [d for d in cuerpo.get(clave) or [] if isinstance(d, dict) and en_rango(modulos._id_entero(d.get("id")), terminal)]
            out[clave] = _upsert_productos(s, filas, eid) if modelo is Producto else _upsert(s, modelo, filas, eid)
            if clave + "_vivos" in cuerpo:
                vivos = {int(i) for i in cuerpo.get(clave + "_vivos") or []}
                for obj in s.exec(select(modelo)).all():
                    if en_rango(obj.id, terminal) and obj.id not in vivos and obj.activo:
                        obj.activo = False; s.add(obj)      # borrado en la instalación: aquí se desactiva (puede estar facturado)
            s.commit()
        except Exception as ex:  # noqa: BLE001
            s.rollback(); out["errores"].append({"parte": clave, "error": str(ex)[:200]})
    # ---- comprobantes referidos por id local: se traducen por su clave ----
    claves_doc = {str(k): x for k, x in (cuerpo.get("claves_doc") or {}).items() if x}
    mapa_doc = {}
    if claves_doc:
        for d in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave.in_(list(set(claves_doc.values()))))).all():
            mapa_doc[d.clave] = d.id
    # ---- registros operativos ----
    for clave, cambio in (cuerpo.get("registros") or {}).items():
        if clave not in CLAVES_OPERATIVAS or not isinstance(cambio, dict):
            out["registros"][clave] = {"error": "Este registro no se sincroniza"}; continue
        if not ctx.puede("escribir"):
            out["registros"][clave] = {"error": "El token no puede escribir registros"}; continue
        items, rechazados = [], []
        for x in cambio.get("items") or []:
            if not isinstance(x, dict):
                continue
            x = dict(x)
            falta = False
            for campo in CAMPOS_REF_DOC:
                if x.get(campo):
                    cl = claves_doc.get(str(x[campo]))
                    if cl and cl in mapa_doc:
                        x[campo] = mapa_doc[cl]
                    else:
                        falta = True        # su comprobante todavía no está en la nube: se reintenta en la próxima subida
            if falta:
                rechazados.append(x.get("id")); continue
            items.append(x)
        try:
            res = modulos.aplicar_sinc(s, eid, clave, items, cambio.get("vivos"), terminal)
            res["rechazados"] = rechazados
            out["registros"][clave] = res
            if clave in ("pos_ventas", "pos_cajas"):
                movimientos_pos(s, eid, clave, items)          # dólares recibidos y retiros al banco de la caja local (3.20)
        except Exception as ex:  # noqa: BLE001
            s.rollback(); out["registros"][clave] = {"error": str(ex)[:200]}
    # ---- cobros borrados en la instalación (etapa 2a): los suyos y los que le bajaron de la nube; antes de las altas, por si SQLite reutilizó el id ----
    for ref in cuerpo.get("pagos_borrados") or []:
        try:
            if not ctx.puede("cobros"):
                raise ValueError("El token no puede registrar cobros")
            if _borrar_cobro_por_ref(s, eid, str(ref), (f"{terminal}:", "0:")):
                out["pagos_borrados"] += 1
        except Exception as ex:  # noqa: BLE001
            s.rollback(); out["errores"].append({"parte": "pagos_borrados", "id": ref, "error": str(ex)[:200]})
    # ---- cobros recibidos ----
    for p in cuerpo.get("pagos") or []:
        try:
            if not ctx.puede("cobros"):
                raise ValueError("El token no puede registrar cobros")
            lid = int(p["id"])
            _guardar_pago(s, eid, p, f"{terminal}:{lid}:{int(p.get('sello') or 0)}", nombre_inst, mapa_doc)
            out["pagos"].append(lid)
        except Exception as ex:  # noqa: BLE001
            s.rollback(); out["errores"].append({"parte": "pagos", "id": p.get("id") if isinstance(p, dict) else None, "error": str(ex)[:200]})
    n_reg = sum(int(x.get("altas", 0)) + int(x.get("cambios", 0)) + int(x.get("bajas", 0)) for x in out["registros"].values() if isinstance(x, dict))
    _anotar_instalacion(s, eid, ctx, ultima_subida=_ahora(), mas_pagos=len(out["pagos"]), mas_registros=n_reg, mas_catalogos=out["clientes"] + out["productos"],
                        version=str(cuerpo.get("version") or "") or None)
    return out


def _es_historia(creado, vinculada) -> bool:
    if vinculada is None or not isinstance(creado, datetime):
        return False
    # la vinculación se anota al segundo: lo creado dentro de ese mismo segundo cuenta como anterior
    return (creado if creado.tzinfo else creado.replace(tzinfo=timezone.utc)).replace(microsecond=0) <= vinculada


@router.get("/novedades")
def novedades(desde: int = 0, _rev: None = Depends(_revocacion_explicita), ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """Etapa 2a: lo que cambió en esta empresa después del número de avance `desde`, sin lo que produjo la propia instalación. No escribe nada: es lo que
    cada computadora pregunta cada pocos segundos. Lo anterior a su vinculación va marcado como historia y sin XML."""
    eid = ctx.empresa.id
    inst = _instalacion_de(_leer(s, eid, CLAVE_VINC, {}), ctx)
    if not inst:
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    terminal, vinculada = int(inst.get("terminal") or 0), _parse(inst.get("creado"))
    tope = int(s.exec(select(sa_func.max(SincDiario.id))).one() or 0)
    if desde > tope:                                                   # 4.16: se restauró un respaldo y la numeración volvió atrás: aplicar de nuevo no duplica
        desde = 0
    filas = s.exec(select(SincDiario).where(SincDiario.id > desde, SincDiario.origen != terminal).order_by(SincDiario.id).limit(LIMITE_NOVEDADES)).all()
    docs, pagos, borrados, cursor, peso, cortado = {}, [], [], int(desde), 0, False

    cobrado: dict = {}

    def cobros() -> dict:
        if not cobrado:
            cobrado[0] = 0.0
            for texto in s.exec(select(modulos.Pago.facturas).where(modulos.Pago.empresa_id == eid)).all():
                for x in json.loads(texto or "[]"):
                    i = modulos._id_entero(x.get("id"))
                    if i:
                        cobrado[i] = cobrado.get(i, 0.0) + float(x.get("monto") or 0)
        return cobrado

    def poner(d: Documento) -> int:
        if d.clave in docs:
            return 0
        hist = _es_historia(d.creado, vinculada)
        dd = _doc_a_dict(s, d, con_xml=not hist)
        dd["historia"] = hist
        if hist:
            dd["sin_xml"], dd["tiene_respuesta"] = bool(d.xml_nombre), bool(d.respuesta_nombre)
            dd["pagado_base"] = max(0.0, round(float(d.pagado or 0) - cobros().get(d.id, 0.0), 2))
        docs[d.clave] = dd
        return len(dd.get("xml_b64") or "") + len(dd.get("respuesta_b64") or "") + 1500
    for f in filas:
        if peso > BYTES_NOVEDADES:
            cortado = True
            break
        cursor = f.id
        if f.tipo == "documento":
            d = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == f.ref)).first()
            if d is not None:
                peso += poner(d)
        elif f.tipo == "pago" and f.borrado:
            borrados.append(f.ref)
        elif f.tipo == "pago":
            p = _pago_de_ref(s, eid, f.ref)
            if p is None:
                continue
            dd = _pago_a_dict(s, p)
            dd["ref"], dd["historia"] = f.ref, _es_historia(p.creado, vinculada)
            pagos.append(dd)
            for x in json.loads(p.facturas or "[]"):               # sus comprobantes van en el mismo paquete: su propia línea puede venir después
                d = s.get(Documento, int(x.get("id") or 0)) if x.get("id") else None
                if d is not None and not (str(d.consecutivo or "")[3:8].isdigit() and int(str(d.consecutivo)[3:8]) == terminal):   # el emitido por quien pregunta ya lo tiene
                    peso += poner(d)
    mas = cortado or len(filas) >= LIMITE_NOVEDADES
    pids = {int(l["producto_id"]) for d in docs.values() for l in d["lineas"] if l.get("producto_id")}
    cids = {x.cliente_id for x in s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave.in_(list(docs)))).all() if x.cliente_id} if docs else set()
    return {"cursor": cursor if mas else max(cursor, tope), "mas": mas, "documentos": list(docs.values()), "pagos": pagos, "pagos_borrados": borrados,
            "productos": [p.model_dump() for p in s.exec(select(Producto).where(Producto.id.in_(pids))).all()] if pids else [],
            "clientes": [c.model_dump() for c in s.exec(select(Cliente).where(Cliente.id.in_(cids))).all()] if cids else []}


@router.get("/xml/{clave}")
def xml_de_comprobante(clave: str, _rev: None = Depends(_revocacion_explicita), ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """Etapa 2a (decisión 8): el XML y la respuesta de un comprobante viejo, la primera vez que la computadora los necesita."""
    if not _instalacion_de(_leer(s, ctx.empresa.id, CLAVE_VINC, {}), ctx):
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    d = s.exec(select(Documento).where(Documento.empresa_id == ctx.empresa.id, Documento.clave == clave)).first()
    if d is None:
        raise HTTPException(404, "Comprobante no encontrado")
    salida = {}
    for nombre, campo in ((d.xml_nombre, "xml_b64"), (d.respuesta_nombre, "respuesta_b64")):
        if nombre and (XML_DIR / nombre).exists():
            salida[campo] = base64.b64encode((XML_DIR / nombre).read_bytes()).decode()
    return salida


# 4.25 (X3): XML viejos en lote, para que la exportación del programa traiga los que le faltan en una sola llamada por tanda.
LOTE_XML, PLAZO_XML, MAX_CLAVES_XML = 25, 45, 100
LIMITE_XML = (60, 300)                                   # llamadas por instalación cada 5 minutos (una exportación completa usa de 4 a 8)
INTENTOS_XML, PAUSA_XML = 3, 0.2                         # renombrado del XML en Windows (archivo abierto o antivirus): reintentos y pausa


def _clave_valida(clave) -> bool:
    """4.25: una clave de Hacienda son 50 dígitos. Solo una clave así se usa para armar el nombre de un archivo."""
    return isinstance(clave, str) and len(clave) == 50 and clave.isascii() and clave.isdigit()


def _guardar_xml(clave: str, contenido: bytes, respuesta: bool = False) -> str:
    """4.25: escribe el XML (o la respuesta de Hacienda) de un comprobante SIEMPRE dentro de la carpeta de XML, con el nombre armado
    aquí con la clave de 50 dígitos (clave.xml o clave_respuesta.xml), primero a un temporal y después renombrando: un corte a
    medio escribir no deja un archivo dañado con el nombre bueno. Devuelve el nombre.
    En Windows el renombrado falla (PermissionError) si el XML de destino está abierto por otro lector o el antivirus retiene el
    temporal: se reintenta INTENTOS_XML veces con una pausa corta y, si sigue fallando, se escribe directo como antes de la 4.25. El
    temporal nunca queda en la carpeta."""
    if not _clave_valida(clave):
        raise ValueError("clave inválida")
    return _escribir_xml(f"{clave}_respuesta.xml" if respuesta else f"{clave}.xml", contenido)


def _nombre_xml_simple(nombre) -> bool:
    """4b (Q10): un nombre de archivo simple que queda DENTRO de la carpeta de XML: sin separadores, sin «..», sin unidad ni ruta
    absoluta (los nombres anotados de un comprobante bajaron de la web)."""
    if not isinstance(nombre, str) or not nombre or nombre in (".", "..") or len(nombre) > 200:
        return False
    if any(c in nombre for c in ('/', '\\', ':', '\x00')) or nombre != nombre.strip() or nombre.startswith(".") or nombre.endswith("."):
        return False
    try:
        return (XML_DIR / nombre).resolve().parent == XML_DIR.resolve()
    except (OSError, ValueError):
        return False


def _escribir_xml(nombre: str, contenido: bytes) -> str:
    """La parte común de _guardar_xml: escribe `nombre` (ya revisado) dentro de la carpeta de XML por un temporal y un renombrado."""
    if not _nombre_xml_simple(nombre):
        raise ValueError("nombre de archivo inválido")
    temporal = XML_DIR / f".{nombre}.{secrets.token_hex(6)}.tmp"
    try:
        temporal.write_bytes(contenido)
        for intento in range(INTENTOS_XML):
            try:
                os.replace(temporal, XML_DIR / nombre)
                break
            except PermissionError:
                if intento < INTENTOS_XML - 1:
                    time.sleep(PAUSA_XML)
        else:
            (XML_DIR / nombre).write_bytes(contenido)
    finally:
        try:
            temporal.unlink(missing_ok=True)
        except OSError:                                                  # lo retiene el antivirus un instante más
            time.sleep(PAUSA_XML)
            temporal.unlink(missing_ok=True)
    return nombre


class ClavesXmlIn(BaseModel):
    claves: list = []


@router.post("/xml")
def xml_en_lote(data: ClavesXmlIn, request: Request, _nube: None = Depends(_solo_nube), _rev: None = Depends(_revocacion_explicita),
                ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """4.25 (X3): el XML y la respuesta de varios comprobantes viejos (hasta 100 claves de 50 dígitos), solo para el token de una
    instalación de esta empresa y solo de comprobantes de esta empresa. Devuelve {archivos: {clave: {xml_b64, respuesta_b64}},
    no_estan: [...], pendientes: [...]}: lo que no cupo en BYTES_NOVEDADES va en pendientes y se pide en la llamada siguiente.
    No se audita cada lote (es tráfico de sincronización, como la ruta de un comprobante suelto)."""
    eid = ctx.empresa.id
    if not _instalacion_de(_leer(s, eid, CLAVE_VINC, {}), ctx):
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    limitar_ip(request, "sinc_xml", maximo=LIMITE_XML[0], ventana=LIMITE_XML[1], sujeto=f"inst{ctx.token_api.id}",
               mensaje="Demasiadas solicitudes de comprobantes; espere unos minutos")
    claves = data.claves
    if not isinstance(claves, list) or len(claves) > MAX_CLAVES_XML:
        raise HTTPException(400, f"Envíe una lista de hasta {MAX_CLAVES_XML} claves")
    if not all(_clave_valida(c) for c in claves):
        raise HTTPException(400, "Cada clave debe tener 50 dígitos")
    archivos, no_estan, pendientes, peso = {}, [], [], 0
    for clave in dict.fromkeys(claves):
        if pendientes:                                                     # ya no cupo uno: los demás también van para después
            pendientes.append(clave); continue
        d = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
        salida = {}
        for nombre, campo in (((d.xml_nombre, "xml_b64"), (d.respuesta_nombre, "respuesta_b64")) if d is not None else ()):
            if nombre and (XML_DIR / nombre).is_file():
                salida[campo] = base64.b64encode((XML_DIR / nombre).read_bytes()).decode()
        if not salida:
            no_estan.append(clave); continue
        tam = sum(len(v) for v in salida.values()) + 200
        if archivos and peso + tam > BYTES_NOVEDADES:                     # siempre va al menos uno: la siguiente llamada avanza
            pendientes.append(clave); continue
        archivos[clave], peso = salida, peso + tam
    return {"archivos": archivos, "no_estan": no_estan, "pendientes": pendientes}


# ----------------------------------------------------------------------------------------------------------------------
# 4.25 (tanda 9): cambios hechos en el programa a ítems que NO son de su rango (creados en la web o en otra computadora). Antes se
# guardaban solo en la computadora y la bajada siguiente los pisaba sin aviso. Ahora el programa conectado los manda a la web EN EL
# MOMENTO (POST /api/sinc/producto) y, si la web los acepta, aplica aquí las filas que la web devuelve; sin internet no se guardan y
# la pantalla lo dice (no hay cola). Los ítems del rango propio siguen como siempre (se guardan aquí y suben en el ciclo).
RUTA_PRODUCTO = "/api/sinc/producto"
OPERACIONES_PRODUCTO = ("editar", "generar", "lote", "eliminar")
LIMITE_PRODUCTO = (120, 300)                 # llamadas por instalación cada 5 minutos (clave persistente «sinc_producto»)
MAX_IDS_PRODUCTO = 500                       # ítems por llamada en «generar» y «lote» (el programa manda en bloques)
PLAZO_PRODUCTO = 15                          # segundos que el programa espera a la web
LARGO_POR = 80                               # «por»: quién lo hizo en el programa (solo texto para la auditoría)
NO_EXISTE_EN_WEB = "Este ítem ya no existe en la página web"
MENSAJE_ITEM_WEB = ("No se pudo guardar: este ítem se creó en la página web y sus cambios se guardan allá. Revise la conexión a internet "
                    "e inténtelo de nuevo.")
PLAN_VENCIDO_PRODUCTO = "El plan de la empresa está vencido: los ítems de la página web no se pueden cambiar hasta renovarlo."     # 9b (U15)
PLAN_SIN_CATALOGO = "El plan de la empresa no incluye el catálogo de ítems."                                                       # 9b (U15)


class ProductoWebIn(BaseModel):
    operacion: str
    id: Optional[int] = None
    ids: Optional[list[int]] = None
    cambios: Optional[dict] = None
    reemplazar: bool = False
    por: Optional[str] = None
    con_historial: bool = False              # «eliminar»: el ítem tiene ventas o movimientos en esa computadora (pueden no haber subido)


def _texto_por(v) -> Optional[str]:
    """4.25 (F-4): el «por» que manda el programa, como texto de una línea y hasta LARGO_POR caracteres. Nunca decide permisos."""
    if not isinstance(v, str):
        return None
    t = " ".join("".join(ch if ch.isprintable() else " " for ch in v).split())[:LARGO_POR]
    return t or None


def _filas_producto(s, eid: int, ids) -> list:
    """Filas completas (como las baja el catálogo) de los ítems de la empresa con esos ids, en ese orden."""
    salida = []
    for i in dict.fromkeys(int(x) for x in ids):
        p = s.get(Producto, i)
        if p is not None and p.empresa_id == eid:
            salida.append(p.model_dump())
    return salida


@router.post("/producto")
def producto_desde_programa(request: Request, _nube: None = Depends(_solo_nube), _rev: None = Depends(_revocacion_explicita),
                            cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """4.25 (tanda 9, F-3, lado web): un cambio hecho en el programa a ítems que no son de su rango {operacion: editar | generar | lote |
    eliminar, …}. Solo para el token de una instalación de ESTA empresa (403 si no) y solo sobre ítems de esta empresa. Ejecuta las
    MISMAS funciones que las rutas web (editar_producto, generar_codigos, lote_productos, borrar_producto) con el contexto del token: sus
    errores (400, 404, 409 con su texto) salen tal cual. Devuelve {resultado: lo que devolvió la función, productos: [fila completa de
    cada ítem que cambió]}. El cuerpo se valida por dentro: un error nunca repite lo enviado."""
    from . import etiquetas as _etq
    from . import main as _m
    eid = ctx.empresa.id
    if not _instalacion_de(_leer(s, eid, CLAVE_VINC, {}), ctx):
        raise HTTPException(403, "Solo para instalaciones vinculadas")
    limitar_ip(request, "sinc_producto", maximo=LIMITE_PRODUCTO[0], ventana=LIMITE_PRODUCTO[1], sujeto=f"inst{ctx.token_api.id}",
               mensaje="Demasiados cambios de ítems seguidos desde esta computadora; espere unos minutos")
    if not ctx.puede("catalogos"):                                     # lo mismo que /api/sinc/cambios exige para crear ítems
        raise HTTPException(403, "El token no puede cambiar ítems")
    # 4.25 (9b, U15): el plan manda como en la página: vencido (modo lectura) o sin el catálogo de ítems, 409 con un texto llano que el
    # programa muestra tal cual. (planes.verificar_vigencia deja pasar todo /api/sinc/ —RUTAS_LECTURA, para que la sincronización siga
    # con el plan vencido—, así que aquí se pregunta lo mismo que ella pregunta: planes.vencido.)
    from . import planes as _planes
    if _planes.vencido(ctx.empresa):
        raise HTTPException(409, PLAN_VENCIDO_PRODUCTO)
    if "catalogos" not in _planes.filtrar_permisos(ctx.empresa, {"catalogos"}):
        raise HTTPException(409, PLAN_SIN_CATALOGO)
    try:
        data = ProductoWebIn.model_validate(cuerpo)
    except ValidationError:
        raise HTTPException(400, "El pedido no es válido")
    if data.operacion not in OPERACIONES_PRODUCTO:
        raise HTTPException(400, "Operación desconocida")
    ctx.por_programa = _texto_por(data.por)                            # F-4: solo va al detalle de la auditoría (main._auditar)
    if data.operacion in ("editar", "eliminar"):
        if data.id is None:
            raise HTTPException(400, "Falta el ítem")
        pid = int(data.id)
        if data.operacion == "editar":
            if not isinstance(data.cambios, dict):
                raise HTTPException(400, "Faltan los cambios del ítem")
            previo = _m._producto(s, eid, pid)
            antes = dict(previo.model_dump()) if previo is not None else {}  # 4.25 (9c, P2): la fila ANTES del cambio (una copia)
            try:
                p = _m.editar_producto(pid, data.cambios, ctx=ctx, s=s)
            except HTTPException as ex:
                if ex.status_code == 404 and ex.detail in (None, "Not Found"):
                    raise HTTPException(404, NO_EXISTE_EN_WEB)       # con texto: el programa lo distingue de una web sin esta ruta
                raise
            # 4.25 (9c, P2): la auditoría nombra solo los campos cuyo valor cambió de verdad (no todos los que mandó la pantalla al guardar
            # la ficha completa); si no cambió ninguno, no audita
            despues = p.model_dump()
            cambiados = sorted(k for k in despues if k not in ("id", "empresa_id") and despues.get(k) != antes.get(k))
            if cambiados:
                _m._auditar(ctx, "producto_editado_programa", f"«{p.nombre}» (ítem {pid}) cambiado desde el programa: " + ", ".join(cambiados)[:300])
            return {"resultado": despues, "productos": _filas_producto(s, eid, [pid])}
        p = _m._producto(s, eid, pid)
        if p is None:                                                  # solo ítems de esta empresa (la ruta web contestaría «ok»)
            raise HTTPException(404, NO_EXISTE_EN_WEB)
        # con_historial: el ítem tiene ventas o movimientos en esa computadora que la web puede no tener todavía: la misma regla de la
        # ruta web para un ítem con ventas (queda inactivo y con el código libre), nunca se borra
        nombre = p.nombre                                              # 9b (U14): antes de borrar (después ya no está)
        res = _m._borrar_producto_aqui(s, ctx, p, con_historial=True) if data.con_historial else _m.borrar_producto(pid, ctx=ctx, s=s)
        _m._auditar(ctx, "producto_eliminado_programa", f"«{nombre}» (ítem {pid}) "
                    + ("desactivado" if isinstance(res, dict) and res.get("desactivado") else "eliminado") + " desde el programa")
        return {"resultado": res, "productos": _filas_producto(s, eid, [pid])}     # sin fila: la web lo eliminó
    ids = list(dict.fromkeys(int(i) for i in (data.ids or [])))
    if not ids:
        raise HTTPException(400, "Elija al menos un ítem")
    if len(ids) > MAX_IDS_PRODUCTO:
        raise HTTPException(400, f"Envíe hasta {MAX_IDS_PRODUCTO} ítems por llamada")
    if data.operacion == "generar":
        res = _etq.generar_codigos(_etq.GenerarIn(ids=ids, reemplazar=bool(data.reemplazar)), ctx=ctx, s=s)
        return {"resultado": res, "productos": _filas_producto(s, eid, [int(k) for k in (res.get("codigos") or {})])}
    cambios = {k: v for k, v in (data.cambios or {}).items() if k in _m.LoteProductosIn.model_fields and k != "ids"}
    try:
        lote = _m.LoteProductosIn.model_validate({**cambios, "ids": ids})
    except ValidationError:
        raise HTTPException(400, "Los cambios del lote no son válidos")
    res = _m.lote_productos(lote, ctx=ctx, s=s)
    return {"resultado": res, "productos": _filas_producto(s, eid, ids)}


# ---- lado programa (F-1, F-5): el punto de decisión es uno solo, es_ajeno(rango_web(eid), id) ----
def rango_web(eid: int) -> Optional[int]:
    """4.25 (tanda 9): None si los cambios de ítems se guardan aquí como siempre (la web, o un programa SIN conectar: sin vinculación,
    sin token o sin dirección, también la computadora que la web desconectó sola); si no, la terminal de esta computadora (su rango).
    Una computadora revocada cuenta como conectada: sus cambios a ítems ajenos no se guardan (producto_en_la_web contesta 503)."""
    if not MODO_LOCAL:
        return None
    if _canal().por_canal(eid, "producto"):
        return None                                                    # 4.32 (contrato §3.5): los ítems viajan por /api/sinc/datos; se guardan aquí y suben solos
    try:
        with Session(engine_empresa(eid)) as s:
            cfg = _cfg_local(s, eid)
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc: no se pudo leer la conexión de la empresa %s (%s)", eid, type(ex).__name__)
        return -1                                                      # no se sabe: lo más estricto (nada ajeno se guarda aquí)
    if not (cfg.get("vinculado") and cfg.get("token") and cfg.get("url")):
        return None
    return int(cfg.get("terminal") or 0)


def es_ajeno(rango: Optional[int], pid) -> bool:
    """¿Este programa está conectado y este id no es de su rango? (rango < 1: conectado sin terminal conocida: todo es ajeno)."""
    return rango is not None and not (rango >= 1 and en_rango(pid, rango))


def va_a_la_web(eid: int, pid) -> bool:
    return es_ajeno(rango_web(eid), pid)


def separar_ajenos(eid: int, ids) -> tuple[list, list]:
    """(propios, ajenos) de una lista de ids, con la misma decisión que va_a_la_web."""
    rango = rango_web(eid)
    propios, ajenos = [], []
    for i in ids:
        (ajenos if es_ajeno(rango, i) else propios).append(i)
    return propios, ajenos


def _fallo_item_web(motivo: str) -> HTTPException:
    log.warning("Cambio de un ítem de la web desde el programa: no se guardó (%s)", motivo)
    return HTTPException(503, MENSAJE_ITEM_WEB)


def producto_en_la_web(eid: int, operacion: str, cuerpo: dict) -> dict:
    """4.25 (tanda 9, F-5): manda a la web (POST /api/sinc/producto, con la dirección y el token de la vinculación, plazo PLAZO_PRODUCTO)
    un cambio a ítems que no son de esta computadora. Devuelve {resultado, productos} de la web. Si la web contestó 400, 404 o 409 con su
    texto, lanza ese mismo error; cualquier otra cosa (sin internet, tiempo agotado, 5xx, 401, 403, 404 o 405 de una web anterior, 429,
    respuesta inesperada, instalación revocada) lanza 503 con MENSAJE_ITEM_WEB. No escribe nada aquí (quien llama aplica las filas). Ni el
    cuerpo ni el detalle de una respuesta de error van al registro ni a la configuración: solo el tipo del error o el código HTTP."""
    try:
        with Session(engine_empresa(eid)) as s:
            cfg = _cfg_local(s, eid)
        if cfg.get("revocada_en"):
            raise _fallo_item_web("instalación revocada")
        if not (cfg.get("vinculado") and cfg.get("token") and cfg.get("url")):
            raise _fallo_item_web("sin conexión con la web")
        with Session(engine) as sc:
            e = sc.get(Empresa, eid)
            clave = e.clave_cifrada if e is not None else None
        token = secretos.descifrar(clave, cfg["token"])
    except HTTPException:
        raise
    except Exception as ex:  # noqa: BLE001
        raise _fallo_item_web(f"no se pudo leer la conexión: {type(ex).__name__}")
    # 4.25 (9c, P3): el plazo de conexión, como _preguntar: 2 s si la sincronización ya sabe que no hay internet, 4 s si no
    espera = httpx.Timeout(PLAZO_PRODUCTO, connect=2.0 if cfg.get("sin_conexion_desde") else 4.0)
    try:
        r = httpx.post(str(cfg["url"]).rstrip("/") + RUTA_PRODUCTO, headers={"Authorization": "Bearer " + token},
                       json={**cuerpo, "operacion": operacion}, timeout=espera)
    except Exception as ex:  # noqa: BLE001  sin internet, tiempo agotado, la web no atendió
        raise _fallo_item_web(type(ex).__name__)
    estado = getattr(r, "status_code", 0)
    j = None
    try:
        j = r.json()
    except Exception:  # noqa: BLE001
        j = None
    if estado == 200:
        if isinstance(j, dict) and "resultado" in j and isinstance(j.get("productos"), list) and all(isinstance(x, dict) and x.get("id") for x in j["productos"]):
            return j
        raise _fallo_item_web("respuesta inesperada")
    detalle = j.get("detail") if isinstance(j, dict) else None
    if estado in (400, 404, 409) and isinstance(detalle, str) and detalle.strip() and detalle != "Not Found":
        raise HTTPException(estado, detalle[:500])                     # el error de la función web, tal cual (aquí no cambia nada)
    raise _fallo_item_web(f"la web respondió {estado}")


def aplicar_filas_web(s, eid: int, filas: list, ids=None) -> int:
    """Aplica aquí las filas que devolvió la web (solo las de los ids pedidos y que no son de esta computadora). No confirma."""
    rango = rango_web(eid)
    pedidos = {int(i) for i in ids} if ids is not None else None
    validas = [d for d in filas if isinstance(d, dict) and modulos._id_entero(d.get("id")) is not None
               and (pedidos is None or int(d["id"]) in pedidos) and es_ajeno(rango, int(d["id"]))]
    return _upsert(s, Producto, validas, eid)


# ----------------------------------------------------------------------------------------------------------------------
# 4.25 (X2, lado nube): ingreso diario del programa local con la cuenta de la web. Rutas solo de la web (_solo_nube: 404 en un programa
# local real) para el token de una instalación, que se reconoce aquí mismo sin pasar por contexto() (así funcionan con la empresa
# bloqueada). Contestan SIEMPRE 200 con un sobre fijo {servicio: «fisitaap-ingreso», ingreso: ok | dos_pasos | rechazado | sin_acceso,
# motivo, mensaje, version, …} (D-A); la única excepción es la señal explícita de siempre para una instalación revocada (401 con
# detail.codigo «instalacion_revocada»). Topes por instalación, no por conexión de internet (D-C): «login» y «mfa» con el sujeto
# «inst<token_id>» y los fallos en «inst<token_id>|correo»; no se leen ni se escriben los contadores por correo o por conexión del
# ingreso web y no se manda el correo de «conexión nueva». Nunca se anotan la contraseña ni el código.
SERVICIO_INGRESO = "fisitaap-ingreso"
TIPO_MFA_PROG = "mfa_prog"                         # token del segundo paso: 5 minutos, atado a la instalación; no sirve en /api/auth/mfa/verificar
LIMITE_USUARIOS = (60, 300)                        # bajadas de usuarios por instalación cada 5 minutos (el ciclo usa una cada 2); clave «sinc_usuarios»
LIMITE_FICHA = (300, 300)                          # fichas de una persona por instalación cada 5 minutos (una por cada entrada con PIN de caja); clave propia «sinc_usuario»
AVISO_USUARIOS = "Demasiadas consultas de usuarios; espere unos minutos"
MENSAJES_INGRESO = {
    "credenciales": "Correo o contraseña incorrectos",
    "espera": "Demasiados intentos fallidos. Intente de nuevo en unos minutos.",
    "tope": "Hay demasiados ingresos seguidos desde esta computadora. Espere unos minutos e intente de nuevo.",
    "bloqueado": "Su cuenta está bloqueada. Contacte al administrador del sistema.",
    "temporal": "Entre una vez a fisitaap.com para cambiar su contraseña temporal. Después puede entrar aquí con la nueva.",
    "dos_pasos_falta": "Su cuenta necesita la verificación en dos pasos. Actívela en fisitaap.com (Mi perfil) y vuelva a entrar aquí.",
    "codigo": "Código de verificación incorrecto",
    "vencido": "El tiempo para el código de verificación expiró; escriba de nuevo su contraseña.",
    "error": "No se pudo confirmar su ingreso; intente de nuevo.",
    "token": "Esta computadora no está vinculada a la web; vuelva a conectarla.",
}
# Tope general del ingreso por instalación (D-C): por una instalación entran todas las cajas y tabletas del local (programa con --red) y
# el tope cuenta también los ingresos buenos, así que no puede ser el de una sola conexión de la web (30): con ese, un cambio de turno
# o un aparato de la red del local dejaban a todos afuera. Al pasarlo el sobre dice «rechazado» con motivo «tope» (no es la «espera»
# de un correo ni un fallo de nadie: el programa no entra con lo guardado y vuelve a intentar, como en D-G c).
TOPE_INGRESO = (300, 300, MENSAJES_INGRESO["tope"])


class _NoReconocido(Exception):
    """4.25: el token no es el de una instalación vigente de una empresa (ni token, token de una persona, desconocido o sin instalación)."""


def _sobre(ingreso: str, motivo: Optional[str] = None, mensaje: Optional[str] = None, **extra) -> dict:
    """4.25 (D-A): la respuesta fija de las rutas de ingreso del programa. `version` es la de la web (para el programa, D-G e)."""
    return {"servicio": SERVICIO_INGRESO, "ingreso": ingreso, "motivo": motivo,
            "mensaje": mensaje if mensaje is not None else MENSAJES_INGRESO.get(motivo or "", ""), "version": _version_sistema(), **extra}


def _instalacion_por_token(authorization: Optional[str], sc) -> tuple:
    """4.25 (D-B 1): reconoce por su cuenta el token de una instalación (sin contexto(): vale con la empresa bloqueada). Devuelve
    (token, empresa, ficha de la instalación). Una instalación revocada recibe la señal explícita de siempre (HTTPException 401); todo
    lo demás que no sea una instalación vigente lanza _NoReconocido."""
    if not authorization or not authorization.lower().startswith("bearer fcr_"):
        raise _NoReconocido()
    _revocacion_explicita(authorization, sc)
    t = sc.exec(select(TokenApi).where(TokenApi.hash == _hash_token_api(authorization.split(" ", 1)[1].strip()))).first()
    if t is None or t.revocado or t.usuario_id != TOKEN_EMPRESA:
        raise _NoReconocido()
    e = sc.get(Empresa, t.empresa_id)
    if e is None:
        raise _NoReconocido()
    with Session(engine_empresa(e.id)) as s:
        v = _leer(s, e.id, CLAVE_VINC, {})
    inst = next((i for i in v.get("instalaciones", []) if isinstance(i, dict) and i.get("prefijo") == t.prefijo and int(i.get("token_id") or 0) == t.id), None)
    if inst is None:
        raise _NoReconocido()
    if t.ultimo_uso is None:                                            # tanda 5: el token ya habló con la nube (no se descarta «sin estrenar»)
        t.ultimo_uso = datetime.now(timezone.utc); sc.add(t); sc.commit()
    return t, e, inst


def _atender(authorization: Optional[str], sc, hacer) -> dict:
    """4.25 (D-A): corre `hacer(token, empresa, instalación)` y convierte todo en el sobre: el tope general de la instalación (429 con el
    mensaje de TOPE_INGRESO) en «tope»; cualquier otro 429 en «espera»; cualquier otro error en «rechazado» con motivo «error» (lo más
    estricto: no entra con lo guardado; se intenta de nuevo). Solo el tipo del error va al registro."""
    try:
        t, e, inst = _instalacion_por_token(authorization, sc)
    except _NoReconocido:
        return _sobre("sin_acceso", "token")
    except HTTPException:
        raise                                                          # la señal explícita de instalación revocada
    except Exception as ex:  # noqa: BLE001
        log.warning("Ingreso del programa local: no se pudo reconocer la instalación (%s)", type(ex).__name__)
        return _sobre("rechazado", "error")
    try:
        return hacer(t, e, inst)
    except HTTPException as ex:
        try:
            sc.rollback()
        except Exception:  # noqa: BLE001
            pass
        if ex.status_code == 429:
            if ex.detail == TOPE_INGRESO[2]:
                return _sobre("rechazado", "tope", TOPE_INGRESO[2])
            return _sobre("rechazado", "espera", ex.detail if isinstance(ex.detail, str) else None)
        log.warning("Ingreso del programa local: respuesta inesperada %s", ex.status_code)
        return _sobre("rechazado", "error")
    except Exception as ex:  # noqa: BLE001
        try:
            sc.rollback()
        except Exception:  # noqa: BLE001
            pass
        log.warning("Ingreso del programa local: error %s", type(ex).__name__)
        return _sobre("rechazado", "error")


def _texto(cuerpo, campo: str, largo: int) -> str:
    v = cuerpo.get(campo) if isinstance(cuerpo, dict) else None
    return v[:largo] if isinstance(v, str) else ""


def _membresia(sc, u, eid: int):
    """4.25 (D-B 3): la membresía de la persona en la empresa del token, o None si no existe, es administrador del sistema o no es miembro."""
    if u is None or u.es_superadmin:
        return None
    return sc.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id, _auth.UsuarioEmpresa.empresa_id == eid)).first()


def _donde(inst: dict) -> str:
    return f"Programa local «{inst.get('nombre') or 'sin nombre'}» (terminal {inst.get('terminal')})"


def _fallo_sin_cuenta(sc, request: Request, correo: str, password: str, sujeto: str, u) -> None:
    """4.25 (D-B 3): correo que no existe, administrador del sistema o persona de otra empresa: lo mismo que una contraseña mala (el tope,
    la espera, el cálculo lento con el hash ficticio, el fallo en el contador de la instalación y la auditoría), sin mirar su contraseña
    ni limpiar sus contadores."""
    limitar_ip(request, _auth.clave_contador("login", sujeto), *TOPE_INGRESO, sujeto=sujeto)     # claves propias de la instalación
    fallo = _auth.clave_contador("login_fallo", sujeto)
    por_inst = f"{sujeto}|{correo}"[:300]
    fin = _auth._fin_espera(sc, fallo, por_inst)
    if fin > time.time():
        restante = int((fin - time.time()) // 60) + 1
        auditar(sc, "login_bloqueado", f"Intento durante bloqueo temporal ({restante} min restantes)", u, request=request, correo=correo[:254])
        raise HTTPException(429, f"Demasiados intentos fallidos. Intente de nuevo en {restante} minutos.")
    _auth._verificar_lento(password, None)
    sc.add(_auth.IntentoIp(clave=fallo, ip=por_inst, momento=time.time())); sc.commit()
    auditar(sc, "login_fallido", "Correo o contraseña incorrectos", u, request=request, correo=correo)


def _marcar_ingreso_en_linea(t, e, inst: dict) -> None:
    """4.25 (D-E): anota para siempre en la ficha de la instalación (sinc_vinculacion) que por ella ya entró alguien en línea: desde
    ahora su catálogo baja con la política de hash aunque no mande la cabecera. Solo se llama con un ingreso aceptado."""
    if inst.get("ingreso_en_linea"):
        return
    with Session(engine_empresa(e.id)) as s:
        v = _leer(s, e.id, CLAVE_VINC, {})
        fila = next((i for i in v.get("instalaciones", []) if isinstance(i, dict) and i.get("prefijo") == t.prefijo and int(i.get("token_id") or 0) == t.id), None)
        if fila is not None and not fila.get("ingreso_en_linea"):
            fila["ingreso_en_linea"] = True
            _escribir(s, e.id, CLAVE_VINC, v); s.commit()


def _aceptar_ingreso(sc, request: Request, t, e, inst: dict, u, m) -> dict:
    """4.25 (instrucción 4): ingreso aceptado desde una instalación: último acceso, auditoría «login_programa» con el programa y la
    terminal, la persona queda validada en esa instalación (desde ahora le baja su hash real), la instalación queda marcada y vuelve su
    ficha con el hash real. Sin sesión en la web y sin el correo de «conexión nueva». La acción de la auditoría no es «login» a propósito
    (D-C): con «login» la web tomaría la conexión del local como una desde donde la persona ya entró (auth._ip_conocida y
    auth._avisar_ip_nueva leen esa acción)."""
    u.ultimo_acceso = datetime.now(timezone.utc); sc.add(u); sc.commit()
    auditar(sc, "login_programa", _donde(inst), u, e.id, request)
    _anotar_validado(sc, t.id, u.id)
    _marcar_ingreso_en_linea(t, e, inst)
    return _sobre("ok", usuario=_ficha_usuario(sc, u, m, e.id), empresa_bloqueada=bool(e.bloqueada))


@router.post("/ingreso")
def ingreso_programa(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None),
                     authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)):
    """4.25 (X2): el programa local valida en la web el ingreso de una persona {correo, password}. Orden (D-B): instalación, tope por
    instalación, membresía en la empresa del token ANTES de mirar la contraseña (si no la tiene: igual que una contraseña mala),
    contraseña y, solo para miembros, bloqueado, temporal, dos pasos (token «mfa_prog») y dos pasos que faltan."""
    def hacer(t, e, inst):
        correo, password = _texto(cuerpo, "correo", 254).lower().strip(), _texto(cuerpo, "password", 1024)
        sujeto = f"inst{t.id}"
        u = sc.exec(select(_auth.Usuario).where(_auth.Usuario.correo == correo)).first() if correo else None
        m = _membresia(sc, u, e.id)
        if m is None:
            _fallo_sin_cuenta(sc, request, correo, password, sujeto, u)
            return _sobre("rechazado", "credenciales")
        try:
            u = _auth.validar_ingreso(sc, request, correo, password, recuadro=False, sujeto=sujeto, tope=TOPE_INGRESO)
        except HTTPException as ex:
            if ex.status_code == 401:
                return _sobre("rechazado", "credenciales")
            if ex.status_code == 403:
                return _sobre("rechazado", "bloqueado")
            raise
        if u.debe_cambiar_password:
            auditar(sc, "login_rechazado", f"Contraseña temporal sin cambiar: {_donde(inst)}", u, e.id, request)
            return _sobre("rechazado", "temporal")
        if u.mfa_activo:
            return _sobre("dos_pasos", token=_auth.firmar({"tipo": TIPO_MFA_PROG, "uid": u.id, "inst": t.id, "eid": e.id}, _auth.DURACION_MFA))
        if _auth.mfa_obligatorio(sc, u) and not _auth.mfa_cubierto(sc, u):
            auditar(sc, "login_rechazado", f"Falta la verificación en dos pasos: {_donde(inst)}", u, e.id, request)
            return _sobre("rechazado", "dos_pasos_falta")
        return _aceptar_ingreso(sc, request, t, e, inst, u, m)
    return _atender(authorization, sc, hacer)


@router.post("/ingreso/dos-pasos")
def ingreso_programa_dos_pasos(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None),
                               authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)):
    """4.25 (X2): segundo paso del ingreso del programa {token, codigo}, con el token «mfa_prog» de 5 minutos que entregó /ingreso a ESTA
    instalación. Los códigos malos cuentan en la cuenta de la persona como en la web; el tope general es por instalación."""
    def hacer(t, e, inst):
        try:
            u = _auth.validar_segundo_factor(sc, request, _texto(cuerpo, "token", 4096), _texto(cuerpo, "codigo", 64), tipo=TIPO_MFA_PROG,
                                             sujeto=f"inst{t.id}", atado={"inst": t.id, "eid": e.id})
        except HTTPException as ex:
            if ex.status_code == 401:
                detalle = ex.detail if isinstance(ex.detail, str) else ""
                return _sobre("rechazado", "vencido") if "expiró" in detalle else _sobre("rechazado", "codigo", detalle or None)
            raise
        m = _membresia(sc, u, e.id)                                    # pudo cambiar en estos minutos: lo más estricto
        if m is None:
            return _sobre("rechazado", "credenciales")
        if u.bloqueado:
            auditar(sc, "login_rechazado", f"Cuenta bloqueada por el administrador: {_donde(inst)}", u, e.id, request)
            return _sobre("rechazado", "bloqueado")
        if u.debe_cambiar_password:
            return _sobre("rechazado", "temporal")
        return _aceptar_ingreso(sc, request, t, e, inst, u, m)
    return _atender(authorization, sc, hacer)


def _tope_usuarios(request: Request, clave: str, limite: tuple, t) -> Optional[dict]:
    """4.25: tope por instalación de las rutas de fichas y de usuarios, cada una con su clave (las fichas del PIN de caja no le gastan
    el cupo a la bajada del ciclo). Pasado el tope devuelve el sobre «sin_acceso» con motivo «tope»: no es un «rechazado» (no dice nada de
    la persona), así que el programa sigue con lo guardado (D-G b) en lugar de negar la entrada. Si hay cupo, None."""
    try:
        limitar_ip(request, clave, limite[0], limite[1], AVISO_USUARIOS, f"inst{t.id}")
    except HTTPException:
        return _sobre("sin_acceso", "tope", AVISO_USUARIOS)
    return None


@router.post("/usuario")
def ficha_programa(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None),
                   authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)):
    """4.25 (D-H, X2-F): la ficha de UNA persona de la empresa del token {correo} (en el cuerpo: no queda en los registros del hosting).
    Si no existe, es administrador del sistema o no es miembro de esta empresa: miembro false y sin ficha (lo mismo en los tres casos).
    El hash, con la política de la instalación (D-E)."""
    def hacer(t, e, inst):
        tope = _tope_usuarios(request, "sinc_usuario", LIMITE_FICHA, t)
        if tope:
            return tope
        correo = _texto(cuerpo, "correo", 254).lower().strip()
        u = sc.exec(select(_auth.Usuario).where(_auth.Usuario.correo == correo)).first() if correo else None
        m = _membresia(sc, u, e.id)
        if m is None:
            return _sobre("ok", miembro=False, usuario=None, empresa_bloqueada=bool(e.bloqueada))
        return _sobre("ok", miembro=True, usuario=_con_politica(sc, [_ficha_usuario(sc, u, m, e.id)], t.id)[0], empresa_bloqueada=bool(e.bloqueada))
    return _atender(authorization, sc, hacer)


@router.post("/usuarios")
def usuarios_programa(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None),
                      authorization: Optional[str] = Header(default=None), sc: Session = Depends(get_session)):
    """4.25 (D-F): bajada liviana de usuarios y roles de la empresa del token {huella}: con la huella de la última bajada buena contesta
    sin_cambios; si no, la lista (fichas con la política de hash de la instalación, D-E) y su huella nueva. No pasa por contexto(): vale
    con la empresa bloqueada."""
    def hacer(t, e, inst):
        tope = _tope_usuarios(request, "sinc_usuarios", LIMITE_USUARIOS, t)
        if tope:
            return tope
        datos = _usuarios_empresa(e.id)
        datos["usuarios"] = _con_politica(sc, datos["usuarios"], t.id)
        huella = hashlib.sha256(json.dumps(datos, sort_keys=True, default=str).encode()).hexdigest()
        if _texto(cuerpo, "huella", 128) == huella:
            return _sobre("ok", sin_cambios=True, huella=huella, empresa_bloqueada=bool(e.bloqueada))
        return _sobre("ok", sin_cambios=False, huella=huella, usuarios=datos["usuarios"], roles=datos["roles"], empresa_bloqueada=bool(e.bloqueada))
    return _atender(authorization, sc, hacer)


@router.get("/instalaciones")
def instalaciones(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Las instalaciones de la empresa. 4.25 (tanda 5): antes descarta las conectadas por la página web que no estrenaron su token en
    MINUTOS_SIN_ESTRENAR (como mucho una vez por minuto) y marca `sin_estrenar` en las de conexión que todavía no hablaron con la web
    (la marca no se guarda en la ficha)."""
    if not MODO_LOCAL:
        try:
            _descartar_sin_estrenar(sc, s, ctx.empresa.id)
        except Exception as ex:  # noqa: BLE001  un descarte que no pudo correr no impide ver la lista
            sc.rollback(); s.rollback()
            log.warning("sinc: descarte de instalaciones sin estrenar (%s)", type(ex).__name__)
    s.expire_all()
    v = _leer(s, ctx.empresa.id, CLAVE_VINC, {})
    lista = [dict(i) for i in v.get("instalaciones", []) if isinstance(i, dict)]
    ids = [int(i["token_id"]) for i in lista if i.get("origen") == "conexion" and i.get("token_id")]
    sin_uso = {t.id for t in sc.exec(select(TokenApi).where(TokenApi.id.in_(ids))).all() if t.ultimo_uso is None} if ids else set()
    for i in lista:
        if i.get("origen") == "conexion":
            i["sin_estrenar"] = int(i.get("token_id") or 0) in sin_uso
    return {"modo_local": MODO_LOCAL, "instalaciones": lista, "codigos_vigentes": len([c for c in v.get("codigos", []) if c.get("vence", "") > _ahora()])}


class NombreIn(BaseModel):
    nombre: str


@router.put("/instalaciones/{terminal}")
def renombrar_instalacion(terminal: int, data: NombreIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Nuevo nombre para una instalación; le baja en su siguiente sincronización."""
    nombre = (data.nombre or "").strip()[:60]
    if len(nombre) < 2:
        raise HTTPException(400, "Indique el nombre de la instalación")
    v = _leer(s, ctx.empresa.id, CLAVE_VINC, {})
    inst = next((i for i in v.get("instalaciones", []) if int(i.get("terminal") or 0) == terminal), None)
    if not inst:
        raise HTTPException(404, "Instalación no encontrada")
    viejo = inst.get("nombre"); inst["nombre"] = nombre
    _escribir(s, ctx.empresa.id, CLAVE_VINC, v); s.commit()
    t = sc.get(TokenApi, inst.get("token_id")) if inst.get("token_id") else None
    if t:
        t.nombre = f"Instalación local · {nombre}"; sc.add(t); sc.commit()
    auditar(sc, "sinc_renombrada", f"Instalación local «{viejo}» (terminal {terminal}) ahora se llama «{nombre}»", ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True, "instalaciones": v.get("instalaciones", [])}


@router.delete("/instalaciones/{terminal}")
def quitar_instalacion(terminal: int, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Revoca el token de una instalación local; lo que ya subió se conserva y su número de terminal no se vuelve a dar."""
    v = _leer(s, ctx.empresa.id, CLAVE_VINC, {})
    inst = next((i for i in v.get("instalaciones", []) if int(i.get("terminal") or 0) == terminal), None)
    if not inst:
        raise HTTPException(404, "Instalación no encontrada")
    t = sc.get(TokenApi, inst.get("token_id")) if inst.get("token_id") else None
    if t:
        t.revocado = True; sc.add(t); sc.commit()
        for x in sc.exec(select(_auth.IngresoPrograma).where(_auth.IngresoPrograma.token_id == t.id)).all():   # 4.25 (D-E)
            sc.delete(x)
        sc.commit()
    v["instalaciones"] = [i for i in v["instalaciones"] if i is not inst]
    v["retiradas"] = (v.get("retiradas") or []) + [{"terminal": terminal, "nombre": inst.get("nombre"), "retirada": _ahora()}]
    _escribir(s, ctx.empresa.id, CLAVE_VINC, v); s.commit()
    auditar(sc, "sinc_desvinculada", f"Instalación local «{inst.get('nombre')}» (terminal {terminal}) desvinculada", ctx.usuario, ctx.empresa.id, ctx.request)
    return {"ok": True}


# ----------------------------------------------------------------------------------------------------------------------
# 4.25 (tanda 5, X1a, lado nube): CONECTAR UNA COMPUTADORA NUEVA con la cuenta de la web («autorización de dispositivo», RFC 8628).
# Tres piezas: (a) SECRETO que genera y conserva solo el programa; la nube guarda únicamente su sha256 (secreto_hash). (b) CÓDIGO
# XXXX-XXXX que ve la persona: solo sirve para que alguien CON SESIÓN encuentre el pase (HMAC con la llave del servidor). (c) NÚMERO DE
# COMPROBACIÓN de 3 cifras (E-1, al revés del diseño): se genera al APROBAR, lo muestra la PÁGINA WEB y la persona lo escribe en el
# PROGRAMA; «recoger» exige {secreto, numero}, 3 intentos por pase, guardado como HMAC(llave, id del pase | número). Así, quien inicia el
# pase en su propia computadora necesita que la víctima le devuelva un dato que la página muestra junto a la advertencia.
# Rutas que llama el PROGRAMA (sin sesión, contestan el sobre {servicio: «fisitaap-conexion», estado, mensaje, …}): iniciar, recoger y
# cancelar. Rutas de la PÁGINA WEB (con sesión): consultar, aprobar, seguimiento, detener y los avisos a los administradores (E-7). Todas
# solo en la web (_solo_nube: 404 en un programa local real). Un solo uso de verdad: cada cambio de estado es un UPDATE … WHERE estado=…
# con filas afectadas == 1 (E-5). En reposo no hay ningún secreto: ni token, ni credenciales, ni el código ni el número en claro.
# Conexión distinta entre el programa y quien aprueba (o que no se puede saber): la entrega se RETIENE SEGUNDOS_RETENCION (E-2), en ese
# momento se avisa a los administradores y la página ofrece «Cancelar».
SERVICIO_CONEXION = "fisitaap-conexion"
MINUTOS_PASE = 10                 # vida de un pase pendiente desde que el programa lo pide
SEGUNDOS_RECOGER = 120            # al aprobar: tiempo para recogerlo (contado desde el fin de la retención, si la hay)
SEGUNDOS_RETENCION = 300          # E-2: conexión distinta o desconocida
MINUTOS_SIN_ESTRENAR = 10         # instalación de conexión cuyo token nunca habló con la web: se descarta
INTENTOS_NUMERO = 3               # números de comprobación errados por pase (al tercero, anulado)
INTERVALO_SONDEO = 3              # segundos entre consultas del programa
PASES_POR_CONEXION = 10           # E-3: pases vivos (vence > ahora) iniciados desde una misma conexión (en IPv6, su /64)
TOPE_INICIAR = (30, 900)          # pedidos a iniciar por conexión cada 15 minutos (clave persistente «sinc_par»)
TOPE_CODIGOS_USUARIO = (10, 900)  # códigos que no existen por persona cada 15 minutos (clave «sinc_cod», sujeto u<id>)
TOPE_CODIGOS_CONEXION = (30, 900) # códigos que no existen por conexión cada 15 minutos: solo se aplica después de un fallo (E-6)
TOPE_SECRETOS = (10, 900)         # secretos que no existen por conexión cada 15 minutos (clave «sinc_rec»: recoger y cancelar)
TOPE_RECOGER = (600, 900)         # llamadas a recoger por conexión cada 15 minutos (en memoria)
TECHO_PASES = 20000               # E-3: pendientes vivos en toda la plataforma; al llegar se desalojan los más viejos que nadie consultó
VERSION_CONEXION = (4, 25)        # programa más viejo: estado «programa_viejo»
NOMBRE_COMPUTADORA = "Computadora nueva"
MENSAJES_CONEXION = {
    "pendiente": "Estamos esperando que la aprueben en la página web.",
    "retenida": "Aprobada. Por seguridad se completa en unos minutos.",
    "aprobada": "Aprobada en la página web. Confirme que es su empresa y escriba el número de comprobación que muestra la página.",
    "numero_errado": "Ese no es el número que muestra la página web. Revíselo e intente de nuevo.",
    "conectada": "Listo: esta computadora quedó conectada.",
    "entregada": "Esta conexión ya se entregó. Empiece de nuevo.",
    "rechazada": "Un administrador rechazó esta conexión en la página web. Si fue un error, empiece de nuevo.",
    "cancelada": "La conexión se canceló. Empiece de nuevo.",
    "anulada": "Por seguridad esta conexión se anuló. Empiece de nuevo.",
    "vencida": "El código venció antes de que lo aprobaran. Empiece de nuevo: es rápido.",
    "desconocido": "No se pudo terminar de conectar. Empiece de nuevo.",
    "invalido": "No se pudo terminar de conectar. Empiece de nuevo.",
    "repetido": "No se pudo terminar de conectar. Empiece de nuevo.",
    "tope": "Se intentó demasiadas veces. Espere unos minutos e intente de nuevo.",
    "programa_viejo": "Este programa es de una versión anterior: descargue la versión nueva desde la página web e intente de nuevo.",
    "error": "No se pudo terminar de conectar. Intente de nuevo.",
}
MENSAJES_WEB_CONEXION = {
    "no_existe": "Ese código no existe o ya venció. Revise el código en la pantalla del programa o empiece de nuevo desde ahí.",
    "vencido": "Ese código venció o ya se usó. Empiece de nuevo desde el programa.",
    "ya_resuelto": "Esta computadora ya fue aprobada o rechazada. Si todavía no entra, empiece de nuevo desde el programa.",
    "sin_permiso": "Solo un administrador de la empresa puede conectar una computadora. Pídale a un administrador que entre a esta página y la apruebe.",
    "soporte": "El personal de soporte no conecta computadoras por aquí. Use «Otra forma de conectar (soporte)» en Configuración › Instalación local.",
    "cedula_distinta": "Esa computadora ya tiene datos de otra empresa (cédula {cedula}). Solo se puede conectar a esa empresa.",
    "empresa_distinta": "Usted tiene abierta otra empresa. Elija la empresa de nuevo e intente otra vez.",
    "tope": "Se intentó demasiadas veces. Espere unos minutos.",
    "demo": "La empresa de demostración no se conecta a computadoras.",
    "token": "La conexión de una computadora la aprueba una persona con sesión, no un token.",
    "ocupada": "El sistema está ocupado; intente de nuevo en unos segundos.",
    "en_curso": "La computadora se está terminando de conectar; intente de nuevo en unos segundos.",
    # 4.31 (16a): la computadora trae ventas de esta empresa y nunca estuvo conectada a ella (protege también a los programas 4.25 a 4.30)
    "datos_locales": "Esta computadora ya tiene ventas de esta empresa que no están en la página web. Si la conecta así, se pierden o se duplican. Escriba a soporte.",
}
AVISO_CONECTADA = ("Se conectó la computadora «{nombre}», aprobada por {aprobo}: ¿la reconoce? Si no la reconoce, toque «Revocar», cambie la clave "
                   "de Hacienda y genere una llave criptográfica nueva (la anterior también se entregó).")
AVISO_POR_COMPLETAR = ("Se aprobó conectar la computadora «{nombre}», aprobada por {aprobo}; todavía no terminó de conectarse. ¿La reconoce? Si no "
                       "la reconoce, toque «Revocar» y no recibirá nada.")


class SincPase(SQLModel, table=True):
    """4.25 (tanda 5): un pase para conectar una computadora nueva. Sin ningún secreto en claro (ver arriba). Fechas en segundos epoch
    (como IntentoIp.momento) para comparar en SQL. Se conservan 24 horas para soporte."""
    __table_args__ = (Index("ix_sincpase_codigo_estado", "codigo_hash", "estado"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    secreto_hash: str = Field(index=True, unique=True)   # sha256 del secreto del programa
    codigo_hash: str                                       # HMAC del código XXXX-XXXX
    numero_hash: Optional[str] = None                      # HMAC(id | número): se pone al aprobar
    nombre: str = ""                                       # nombre de la computadora, ya limpio (escrito por quien la conecta: no verificado)
    cedula: Optional[str] = None                           # solo dígitos: la computadora ya tiene datos de esa empresa
    version: Optional[str] = None
    estado: str = Field(default="pendiente", index=True)  # pendiente | aprobado | entregado | rechazado | cancelado | anulado | vencido
    intentos: int = 0                                      # números de comprobación errados
    empresa_id: Optional[int] = None
    usuario_id: Optional[int] = None                       # quien aprobó o rechazó
    token_id: Optional[int] = None                         # la instalación que nació del pase
    ip: Optional[str] = None                               # desde donde lo pidió el programa
    red: Optional[str] = Field(default=None, index=True)   # sujeto de los topes por conexión (en IPv6, el /64)
    ip_aprueba: Optional[str] = None
    misma_conexion: bool = False
    creado: float = 0
    vence: float = 0
    consultado: Optional[float] = None
    aprobado: Optional[float] = None
    retener_hasta: Optional[float] = None                  # E-2: la entrega espera hasta aquí
    entregado: Optional[float] = None
    # 4.31 (16a): lo que dijo el programa al sondear (recoger) un pase CON cédula: 0 = esa computadora nunca estuvo conectada; N = su
    # terminal anterior. None = todavía no sondeó (la entrega lo vuelve a revisar con lo que manda en ese momento).
    terminal_previa: Optional[int] = None


class SincAviso(SQLModel, table=True):
    """4.25 (tanda 5, E-7): aviso dentro del sistema para cada administrador de la empresa: «Se conectó la computadora X, aprobada por Y:
    ¿la reconoce?» hasta que conteste («si» o «revocar»). No depende del correo."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    usuario_id: int = Field(index=True)
    pase_id: int = Field(index=True)
    token_id: Optional[int] = None
    nombre: str = ""
    aprobo: str = ""
    creado: float = 0
    respuesta: Optional[str] = None
    respondido: Optional[float] = None


central(SincPase, SincAviso)
_LIMPIEZA_PASES = [0.0]
_DESCARTE: dict = {}


def _sobre_conexion(estado: str, mensaje: Optional[str] = None, **extra) -> dict:
    """El sobre fijo de las rutas que llama el programa: el programa solo obedece respuestas con este `servicio` (un portal de wifi, un
    cortafuegos o una web vieja no se confunden con un rechazo)."""
    return {"servicio": SERVICIO_CONEXION, "estado": estado, "mensaje": mensaje if mensaje is not None else MENSAJES_CONEXION.get(estado, ""),
            "version": _version_sistema(), **extra}


def _respuesta_conexion(status: int, estado: str, **extra):
    return JSONResponse(status_code=status, content=_sobre_conexion(estado, **extra))


def _error_web(status: int, codigo: str, **formato) -> HTTPException:
    return HTTPException(status, {"codigo": codigo, "mensaje": MENSAJES_WEB_CONEXION[codigo].format(**formato) if formato else MENSAJES_WEB_CONEXION[codigo]})


def _leer_cuerpo(modelo, cuerpo):
    """El cuerpo de una ruta sin sesión con su modelo (largos máximos); None si no cumple. Nunca devuelve el detalle de pydantic: un 422
    copiaría lo enviado (el secreto) en la respuesta."""
    try:
        return modelo.model_validate(cuerpo if isinstance(cuerpo, dict) else {})
    except ValidationError:
        return None


def _digitos(texto) -> str:
    return "".join(ch for ch in str(texto or "") if ch in "0123456789")


def _nombre_computadora(texto) -> str:
    """Nombre de la computadora limpio AL RECIBIRLO: solo letras, números, espacios, guion, paréntesis y #; sin puntos, dos puntos,
    barras ni arrobas (nada que se lea como una dirección: E-7); espacios colapsados; 60 caracteres; vacío → «Computadora nueva»."""
    limpio = "".join(ch if (ch.isalpha() or ch in "0123456789 -()#") else " " for ch in str(texto or "")[:200])
    limpio = " ".join(limpio.split())[:60].strip()
    return limpio or NOMBRE_COMPUTADORA


def _codigo_conexion() -> str:
    c = "".join(secrets.choice(_ALFABETO_CODIGO) for _ in range(8))
    return f"{c[:4]}-{c[4:]}"


def _normalizar_codigo(texto) -> Optional[str]:
    t = "".join(ch for ch in str(texto or "").upper() if ch.isalnum())
    if len(t) != 8 or any(ch not in _ALFABETO_CODIGO for ch in t):
        return None
    return f"{t[:4]}-{t[4:]}"


def _hmac_pase(texto: str) -> str:
    return hmac.new(_auth.SECRET, texto.encode(), hashlib.sha256).hexdigest()


def _hash_codigo(codigo: str) -> str:
    return _hmac_pase("conexion|codigo|" + codigo)


def _hash_numero(pid: int, numero: str) -> str:
    return _hmac_pase(f"conexion|numero|{int(pid)}|{numero}")


def _ip_publica(ip):
    """La dirección si es pública; None si está vacía, no se entiende o es privada, de bucle, local, reservada o de difusión (puede ser
    la del proxy del hosting, igual para todos)."""
    try:
        a = ipaddress.ip_address(str(ip or "").strip())
    except ValueError:
        return None
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    if a.is_private or a.is_loopback or a.is_link_local or a.is_unspecified or a.is_reserved or a.is_multicast:
        return None
    return a


def _misma_conexion(a, b) -> bool:
    """E-2: el programa y quien aprueba usan la misma conexión a internet (IPv4 igual; IPv6 en el mismo /64). Si alguna no se puede
    saber (vacía, privada, de bucle…), es «distinta», nunca «misma»."""
    def red(ip):
        x = _ip_publica(ip)
        if x is None:
            return None
        return str(ipaddress.ip_network(f"{x}/64", strict=False)) if x.version == 6 else str(x)
    ra, rb = red(a), red(b)
    return bool(ra) and ra == rb


def _sujeto_conexion(request) -> str:
    """Sujeto de los topes por conexión (E-3): en IPv6 su /64; si no, la dirección tal cual (como los demás topes de la web)."""
    ip = _auth._ip(request) or "?"
    try:
        a = ipaddress.ip_address(ip)
        if a.version == 6 and not a.ipv4_mapped:
            return "red6:" + str(ipaddress.ip_network(f"{a}/64", strict=False))
    except ValueError:
        pass
    return ip[:120]


def _pase(sc, **filtro) -> Optional[dict]:
    """Lee un pase (como diccionario) y CIERRA la lectura: el siguiente UPDATE empieza una transacción nueva (con SQLite en modo WAL, escribir
    sobre una lectura vieja da «database is locked» de inmediato: E-5)."""
    q = select(SincPase)
    for k, v in filtro.items():
        q = q.where(getattr(SincPase, k) == v)
    p = sc.exec(q.order_by(SincPase.id.desc())).first()
    d = p.model_dump() if p is not None else None
    sc.commit()
    return d


def _limpiar_pases(sc, ahora: float) -> None:
    """Como mucho cada 10 minutos por proceso: borra los pases de más de 24 horas, marca vencidos los que pasaron su plazo y quita los
    avisos ya contestados hace más de 30 días o de pases que ya no existen y nunca dieron una instalación."""
    if ahora - _LIMPIEZA_PASES[0] < 600:
        return
    _LIMPIEZA_PASES[0] = ahora
    sc.execute(_sql("DELETE FROM sincpase WHERE creado < :t"), {"t": ahora - 86400})
    sc.execute(_sql("UPDATE sincpase SET estado='vencido' WHERE estado IN ('pendiente','aprobado') AND vence < :t"), {"t": ahora})
    sc.execute(_sql("DELETE FROM sincaviso WHERE (respuesta IS NOT NULL AND respondido < :t) OR "
                    "(token_id IS NULL AND pase_id NOT IN (SELECT id FROM sincpase))"), {"t": ahora - 30 * 86400})
    sc.commit()


def _desalojar(sc, ahora: float) -> None:
    """E-3: sin tope global duro. Con TECHO_PASES pendientes vivos se vencen los más viejos que nadie consultó (nunca se rechaza a todos)."""
    n = int(sc.execute(_sql("SELECT COUNT(*) FROM sincpase WHERE estado='pendiente' AND vence > :t"), {"t": ahora}).scalar() or 0)
    if n < TECHO_PASES:
        sc.commit()
        return
    sc.execute(_sql("UPDATE sincpase SET estado='vencido' WHERE id IN (SELECT id FROM sincpase WHERE estado='pendiente' AND vence > :t "
                    "AND consultado IS NULL ORDER BY creado LIMIT :n)"), {"t": ahora, "n": n - TECHO_PASES + 1})
    sc.commit()


def _estado_programa(p: dict, ahora: float) -> str:
    """El estado que ve el programa."""
    e = p.get("estado")
    if e == "pendiente":
        return "pendiente" if p["vence"] > ahora else "vencida"
    if e == "aprobado":
        if p["vence"] <= ahora:
            return "vencida"
        if not p.get("numero_hash"):
            return "pendiente"                                           # la aprobación todavía se está escribiendo
        if p.get("retener_hasta") and p["retener_hasta"] > ahora:
            return "retenida"
        return "aprobada"
    return {"entregado": "entregada", "rechazado": "rechazada", "cancelado": "cancelada", "anulado": "anulada", "bloqueado": "anulada"}.get(e, "vencida")


def _admins_empresa(sc, eid: int) -> list:
    """Las personas de la empresa cuyo rol trae «configurar», sin bloqueo y que no son administradores del sistema."""
    A = _auth
    filas = sc.exec(select(A.UsuarioEmpresa, A.Usuario).where(A.UsuarioEmpresa.empresa_id == eid, A.UsuarioEmpresa.usuario_id == A.Usuario.id)).all()
    return [u for m, u in filas if not u.bloqueado and not u.es_superadmin and "configurar" in A.permisos_de_rol(sc, eid, m.rol)]


def _cuenta_en_regla(sc, u) -> None:
    """E-6: revisión EXPRESA de la cuenta para consultar y aprobar: administrador del sistema rechazado, dos pasos, contraseña temporal y
    términos (superadmin() no revisa los términos: se escribe aquí)."""
    if u.es_superadmin or _auth._soporte_de(u):     # 4.35: tampoco al entrar como la persona (RUTAS_NO_SUPLANTADA ya lo rechaza antes)
        raise _error_web(403, "soporte")
    _auth._exigir_mfa(sc, u)
    if u.debe_cambiar_password:
        raise HTTPException(403, {"codigo": "cambiar_password", "mensaje": "Debe cambiar la contraseña temporal antes de continuar"})
    if _auth.terminos_pendientes(u):
        raise HTTPException(403, {"codigo": "aceptar_terminos", "mensaje": "Debe aceptar los términos del servicio antes de continuar"})


def _tope_codigos(request: Request, u) -> None:
    """Antes de buscar: la persona no pasó su tope de códigos que no existen (solo se cuentan los fallos)."""
    try:
        limitar_ip(request, "sinc_cod", *TOPE_CODIGOS_USUARIO, MENSAJES_WEB_CONEXION["tope"], sujeto=f"u{u.id}", registrar=False)
    except HTTPException:
        raise _error_web(429, "tope")


def _fallo_codigo(request: Request, u) -> None:
    """Un código que no existe: cuenta para la persona y, solo ahora (E-6), para la conexión."""
    try:
        limitar_ip(request, "sinc_cod", *TOPE_CODIGOS_USUARIO, MENSAJES_WEB_CONEXION["tope"], sujeto=f"u{u.id}")
        limitar_ip(request, "sinc_cod", *TOPE_CODIGOS_CONEXION, MENSAJES_WEB_CONEXION["tope"], sujeto="c:" + _sujeto_conexion(request))
    except HTTPException:
        raise _error_web(429, "tope")


def _empresas_para_aprobar(sc, u, cedula: Optional[str]) -> list:
    """Las empresas a las que la persona puede conectar la computadora: membresía propia con «configurar», no bloqueada, no demo, sin la
    prueba vencida y, si el pase trae cédula, solo la de esa cédula (comparada por dígitos)."""
    A = _auth
    salida = []
    for m in sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.usuario_id == u.id)).all():
        e = sc.get(Empresa, m.empresa_id)
        if e is None or e.bloqueada or e.es_demo or A.prueba_vencida(e) or "configurar" not in A.permisos_de_rol(sc, e.id, m.rol):
            continue
        if cedula and _digitos(e.numero_id) != cedula:
            continue
        salida.append({"id": e.id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id})
    return salida


def _terminales_de(eid: int) -> set:
    """4.31 (16a): las terminales de las computadoras que estuvieron conectadas a esta empresa de la web (vigentes y retiradas)."""
    with Session(engine_empresa(int(eid))) as s:
        v = _leer(s, int(eid), CLAVE_VINC, {})
    return {int(i.get("terminal") or 0) for i in list(v.get("instalaciones") or []) + list(v.get("retiradas") or []) if isinstance(i, dict)} - {0}


def _trae_datos_ajenos(eid: int, cedula, terminal) -> Optional[bool]:
    """4.31 (16a, guarda de la web): ¿la computadora del pase trae datos de esta empresa que la página web no tiene? Solo con cédula (el
    programa la manda cuando ya tiene datos: algún comprobante o una terminal anotada, _datos_para_conexion). `terminal` es lo que dice el
    programa: None = todavía no se sabe; 0 = nunca estuvo conectado; N = su terminal anterior, que tiene que ser de una computadora de
    ESTA empresa (vigente o retirada). Así sigue igual la conexión normal (sin cédula) y la de una computadora que vuelve. Si la empresa
    no se puede leer, True (lo más estricto). Protege también a los programas 4.25 a 4.30, que no tienen la guarda propia."""
    if not _digitos(cedula):
        return False
    if terminal is None:
        return None
    try:
        t = int(terminal)
        return t <= 0 or t not in _terminales_de(eid)
    except Exception as ex:  # noqa: BLE001
        log.info("Conexión de una computadora: no se pudo revisar la empresa %s (%s)", eid, type(ex).__name__)
        return True


def _codigo_resuelto(sc, ch: str) -> bool:
    """El código existió en las últimas 24 horas (venció o ya se usó): «venció», sin contar como fallo (E-6)."""
    hay = sc.exec(select(SincPase.id).where(SincPase.codigo_hash == ch)).first() is not None
    sc.commit()
    return hay


def _en_hilo(fn) -> None:
    threading.Thread(target=fn, daemon=True).start()


def _smtp_aviso(sc, e: Empresa, aprobador):
    """E-7: el correo de la plataforma o, si no hay, el de la EMPRESA QUE SE CONECTA (nunca el de otra empresa de la persona)."""
    if (os.getenv("FE_SMTP_HOST") or "").strip():
        return _auth._cfg_smtp_plataforma(sc, aprobador)
    if not (e.smtp_host and e.smtp_remitente):
        return None
    from . import correo
    try:
        return correo.ConfigSMTP(e.smtp_host, e.smtp_puerto or (465 if (e.smtp_seguridad or "ssl") == "ssl" else 587), e.smtp_usuario,
                                 secretos.descifrar(e.clave_cifrada, e.smtp_password), e.smtp_remitente, seguridad=e.smtp_seguridad or "ssl",
                                 nombre=e.smtp_nombre or None)
    except Exception:  # noqa: BLE001
        return None


def _avisar_conexion(sc, e: Empresa, aprobador, nombre: str, retenida: bool) -> None:
    """E-7: correo a los administradores de la empresa (rol con «configurar», sin bloqueo). Sin secretos, código ni número. Con conexión
    distinta sale al aprobar (la entrega espera SEGUNDOS_RETENCION y todavía se puede cancelar); con la misma, al entregarse."""
    destinos = [u.correo for u in _admins_empresa(sc, e.id) if u.correo]
    cfg = _smtp_aviso(sc, e, aprobador) if destinos else None
    if cfg is None:
        return
    from . import correo
    from . import correo_diseno as _dz
    web = ("https://" + dominio_sistema()) if dominio_sistema() else "la página web"
    cuando = ahora_cr().strftime("%d/%m/%Y %H:%M") + " (hora de Costa Rica)"
    quien = f"{aprobador.nombre} ({aprobador.correo})"
    if retenida:
        asunto = f"Se aprobó conectar una computadora nueva a {e.nombre}"
        parrafo = (f"{quien} aprobó conectar la computadora «{nombre}» a {e.nombre} el {cuando}. Esa computadora no usa la misma conexión a "
                   f"internet que quien la aprobó: por seguridad la conexión se completa en {SEGUNDOS_RETENCION // 60} minutos.")
        aviso = (f"Si usted no reconoce esta computadora, entre a {web}, vaya a Configuración › Instalación local y toque «Revocar» en el aviso "
                 "de computadora nueva. Si ya se completó, cambie la clave de Hacienda y genere una llave criptográfica nueva (la anterior "
                 "también se entregó).")
    else:
        asunto = f"Se conectó una computadora nueva a {e.nombre}"
        parrafo = (f"{quien} aprobó conectar la computadora «{nombre}» a {e.nombre} el {cuando}. Desde ahora esa computadora puede facturar a "
                   "nombre de la empresa.")
        aviso = (f"Si usted no reconoce esta computadora, entre a {web}, vaya a Configuración › Instalación local y toque «Revocar»; después "
                 "cambie la clave de Hacienda y genere una llave criptográfica nueva (la anterior también se entregó).")
    html = _dz.armar(_dz.plataforma(), titulo=asunto, asunto=asunto, preencabezado=parrafo[:120], parrafos_txt=[parrafo],
                     datos=[("Computadora (nombre escrito por quien la conecta)", nombre), ("Aprobada por", quien), ("Fecha", cuando)],
                     aviso=aviso, aviso_tono="ambar")
    texto = f"{parrafo}\n\n{aviso}"

    def _enviar():
        for d in destinos:
            try:
                correo.enviar(cfg, [d], asunto, html, texto, [])
            except Exception:  # noqa: BLE001
                pass
    _en_hilo(_enviar)


def _crear_avisos(sc, eid: int, pid: int, nombre: str, aprobador) -> None:
    for a in _admins_empresa(sc, eid):
        sc.add(SincAviso(empresa_id=eid, usuario_id=a.id, pase_id=pid, nombre=nombre, aprobo=f"{aprobador.nombre} ({aprobador.correo})", creado=time.time()))
    sc.commit()


def _resolver_avisos(sc, pid: int, respuesta: str) -> None:
    sc.execute(_sql("UPDATE sincaviso SET respuesta=:r, respondido=:t WHERE pase_id=:p AND respuesta IS NULL"), {"r": respuesta, "t": time.time(), "p": int(pid)})
    sc.commit()


def _retirar_por_token(s, eid: int, tid: int, **extra) -> Optional[dict]:
    """Saca la ficha de la instalación de ese token de `instalaciones` y la pasa a `retiradas` (su número no se vuelve a dar a otra
    computadora; la misma lo recupera con terminal_anterior). Relee el registro justo antes de escribir."""
    s.expire_all()
    v = _leer(s, eid, CLAVE_VINC, {})
    inst = next((i for i in v.get("instalaciones", []) if isinstance(i, dict) and int(i.get("token_id") or 0) == int(tid)), None)
    if inst is None:
        return None
    v["instalaciones"] = [i for i in v["instalaciones"] if i is not inst]
    v["retiradas"] = (v.get("retiradas") or []) + [{"terminal": int(inst.get("terminal") or 0), "nombre": inst.get("nombre"), "retirada": _ahora(), **extra}]
    _escribir(s, eid, CLAVE_VINC, v); s.commit()
    return inst


def _descartar_sin_estrenar(sc, s, eid: int, v: Optional[dict] = None, forzar: bool = False) -> bool:
    """4.25 (tanda 5, E-5): instalaciones de origen «conexion» con más de MINUTOS_SIN_ESTRENAR desde su alta cuyo token nunca habló con la
    web: el token se revoca con un UPDATE atómico (… AND ultimo_uso IS NULL) y solo si afectó una fila la ficha pasa a `retiradas` con
    motivo «sin_estrenar» y se audita «sinc_descartada». Sin `forzar` corre como mucho una vez por minuto por empresa (lo llama un GET).
    Con `v` trabaja sobre ese registro ya leído (lo cambia y lo escribe). True si descartó alguna."""
    ahora = time.time()
    if not forzar and ahora - _DESCARTE.get(eid, 0.0) < 60:
        return False
    _DESCARTE[eid] = ahora
    propio = v is None
    v = _leer(s, eid, CLAVE_VINC, {}) if propio else v
    limite = (datetime.now(timezone.utc) - timedelta(minutes=MINUTOS_SIN_ESTRENAR)).isoformat(timespec="seconds")
    candidatas = [i for i in v.get("instalaciones", []) if isinstance(i, dict) and i.get("origen") == "conexion" and i.get("token_id")
                  and str(i.get("creado") or "") < limite]
    hubo = []
    for i in candidatas:
        if not _revocar_sin_uso(sc, int(i["token_id"])):
            continue
        v["instalaciones"] = [x for x in v.get("instalaciones", []) if x is not i]
        # 4.25 (D-O): con el id del token, para que la señal de revocación diga que fue un descarte y no una persona
        v["retiradas"] = (v.get("retiradas") or []) + [{"terminal": int(i.get("terminal") or 0), "nombre": i.get("nombre"), "retirada": _ahora(),
                                                        "motivo": MOTIVO_SIN_ESTRENAR, "token_id": int(i["token_id"])}]
        hubo.append(i)
    if hubo:
        _escribir(s, eid, CLAVE_VINC, v); s.commit()
        for i in hubo:
            auditar(sc, "sinc_descartada", f"Instalación local «{i.get('nombre')}» (terminal {i.get('terminal')}) descartada: no habló con la web en "
                    f"los {MINUTOS_SIN_ESTRENAR} minutos después de conectarse", None, eid, None)
    return bool(hubo)


def _motivo_no_entrega(sc, e, aprobador) -> Optional[str]:
    """Revisión final antes de entregar (la aprobación pudo ser hace minutos): la empresa existe, no está bloqueada ni es demo ni tiene la
    prueba vencida, y quien aprobó sigue sin bloqueo, no es administrador del sistema, es miembro y su rol trae «configurar»."""
    A = _auth
    if e is None or e.bloqueada or e.es_demo or A.prueba_vencida(e):
        return "la empresa ya no se puede conectar"
    if aprobador is None or aprobador.bloqueado or aprobador.es_superadmin or aprobador.debe_cambiar_password:
        return "quien la aprobó ya no puede aprobarla"
    m = sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.usuario_id == aprobador.id, A.UsuarioEmpresa.empresa_id == e.id)).first()
    if m is None or "configurar" not in A.permisos_de_rol(sc, e.id, m.rol):
        return "quien la aprobó ya no administra la empresa"
    return None


def _confirmacion(sc, p: dict) -> dict:
    """E-4: lo que el programa muestra antes de aplicar («Sí, es mi empresa»): nombre legal, cédula y quien aprobó. Sin secretos."""
    e = sc.get(Empresa, p["empresa_id"]) if p.get("empresa_id") else None
    u = sc.get(_auth.Usuario, p["usuario_id"]) if p.get("usuario_id") else None
    d = {"empresa": {"nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "numero_id": e.numero_id} if e else None,
         "aprobo": {"correo": u.correo, "nombre": u.nombre} if u else None, "intentos_restantes": max(0, INTENTOS_NUMERO - int(p.get("intentos") or 0))}
    sc.commit()
    return d


class ConexionIniciarIn(BaseModel):
    secreto_hash: str = PField(max_length=64)
    nombre: str = PField(default="", max_length=200)
    cedula: Optional[str] = PField(default=None, max_length=30)
    version: Optional[str] = PField(default=None, max_length=30)


class ConexionRecogerIn(BaseModel):
    secreto: str = PField(max_length=128)
    numero: Optional[str] = PField(default=None, max_length=10)
    confirmar: bool = False
    terminal_anterior: Optional[int] = PField(default=None, ge=0, le=99999)
    secuencias: dict = PField(default_factory=dict, max_length=40)
    version: Optional[str] = PField(default=None, max_length=30)


class ConexionSecretoIn(BaseModel):
    secreto: str = PField(max_length=128)


class ConexionCodigoIn(BaseModel):
    codigo: str = PField(max_length=20)


class ConexionAprobarIn(BaseModel):
    codigo: str = PField(max_length=20)
    empresa_id: int
    aprobar: bool = True


class ConexionPaseIn(BaseModel):
    pase: int


class AvisoRespuestaIn(BaseModel):
    respuesta: str = PField(max_length=10)


@router.post("/conexion/iniciar")
def conexion_iniciar(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None), sc: Session = Depends(get_session)):
    """Lo llama el PROGRAMA, sin sesión: {secreto_hash (sha256 hex de su secreto), nombre, cedula?, version}. Devuelve el código para la
    página web; NUNCA un número (E-1) ni ningún secreto. Sin tope global duro (E-3): tope por conexión (en IPv6 el /64) de pases vivos y de
    pedidos. No audita (una ruta abierta no escribe auditoría): el pase mismo queda 24 horas."""
    d = _leer_cuerpo(ConexionIniciarIn, cuerpo)
    if d is None or len(d.secreto_hash) != 64 or any(ch not in "0123456789abcdef" for ch in d.secreto_hash):
        return _respuesta_conexion(400, "invalido")
    if _version_tupla(d.version) < VERSION_CONEXION:
        return _sobre_conexion("programa_viejo")
    sujeto = _sujeto_conexion(request)
    try:
        limitar_ip(request, "sinc_par", *TOPE_INICIAR, MENSAJES_CONEXION["tope"], sujeto=sujeto)
    except HTTPException:
        return _respuesta_conexion(429, "tope")
    ahora = time.time()
    try:
        _limpiar_pases(sc, ahora)
        vivos = int(sc.execute(_sql("SELECT COUNT(*) FROM sincpase WHERE red=:r AND estado IN ('pendiente','aprobado') AND vence > :t"),
                               {"r": sujeto, "t": ahora}).scalar() or 0)
        sc.commit()
        if vivos >= PASES_POR_CONEXION:
            return _respuesta_conexion(429, "tope")
        _desalojar(sc, ahora)
        if _pase(sc, secreto_hash=d.secreto_hash) is not None:
            return _respuesta_conexion(409, "repetido")
        for _ in range(8):                                                # un código pendiente y vigente igual: se genera otro
            codigo = _codigo_conexion()
            ch = _hash_codigo(codigo)
            choca = sc.exec(select(SincPase.id).where(SincPase.codigo_hash == ch, SincPase.estado == "pendiente", SincPase.vence > ahora)).first()
            sc.commit()
            if choca is None:
                break
        else:
            return _respuesta_conexion(503, "error")
        ip = _auth._ip(request)
        sc.add(SincPase(secreto_hash=d.secreto_hash, codigo_hash=ch, nombre=_nombre_computadora(d.nombre), cedula=_digitos(d.cedula)[:12] or None,
                        version=(d.version or "").strip()[:30] or None, ip=(ip or None) and ip[:64], red=sujeto, creado=ahora, vence=ahora + MINUTOS_PASE * 60))
        sc.commit()
    except IntegrityError:
        sc.rollback()
        return _respuesta_conexion(409, "repetido")
    except OperationalError:
        sc.rollback()
        return _respuesta_conexion(503, "error")
    return _sobre_conexion("pendiente", codigo=codigo, segundos=MINUTOS_PASE * 60, intervalo=INTERVALO_SONDEO)


@router.post("/conexion/consultar")
def conexion_consultar(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None), u=Depends(_auth.solo_usuario),
                       sc: Session = Depends(get_session)):
    """Lo llama la PÁGINA WEB con sesión: {codigo} (por POST: no queda en los registros del hosting). Busca SOLO un pase pendiente y
    vigente; un código que venció o ya se usó contesta «vencido» sin contar como fallo; uno que no existe cuenta para la persona y, después
    del fallo, para la conexión (E-6). Devuelve el nombre de la computadora, hace cuánto la pidió, si comparte conexión (nunca la IP), la
    cédula que trae y las empresas PROPIAS de la persona a las que puede conectarla. Nunca el número ni el secreto. No hay ninguna ruta
    que liste pases."""
    _cuenta_en_regla(sc, u)
    _tope_codigos(request, u)
    d = _leer_cuerpo(ConexionCodigoIn, cuerpo)
    codigo = _normalizar_codigo(d.codigo if d else "")
    ahora = time.time()
    ch = _hash_codigo(codigo) if codigo else None
    p = _pase(sc, codigo_hash=ch, estado="pendiente") if ch else None
    if p is None or p["vence"] <= ahora:
        if ch and _codigo_resuelto(sc, ch):
            raise _error_web(410, "vencido")
        _fallo_codigo(request, u)
        raise _error_web(404, "no_existe")
    try:
        sc.execute(_sql("UPDATE sincpase SET consultado=:t WHERE id=:id"), {"t": ahora, "id": p["id"]}); sc.commit()
    except OperationalError:
        sc.rollback()
    empresas = _empresas_para_aprobar(sc, u, p.get("cedula"))
    for x in empresas:                                                    # 4.31 (16a): la pantalla no ofrece aprobar (aprobar da 409)
        x["bloqueada"] = _trae_datos_ajenos(x["id"], p.get("cedula"), p.get("terminal_previa")) is True
    return {"codigo": codigo, "nombre": p["nombre"], "hace_minutos": max(0, int((ahora - p["creado"]) // 60)), "segundos": int(p["vence"] - ahora),
            "misma_conexion": _misma_conexion(p.get("ip"), _auth._ip(request)), "cedula": p.get("cedula"),
            "empresas": empresas, "bloqueo": MENSAJES_WEB_CONEXION["datos_locales"] if any(x["bloqueada"] for x in empresas) else None}


@router.post("/conexion/aprobar")
def conexion_aprobar(data: ConexionAprobarIn, request: Request, _nube: None = Depends(_solo_nube), ctx: Contexto = Depends(contexto),
                     s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Lo llama la PÁGINA WEB: {codigo, empresa_id, aprobar}. Exige lo mismo que generar el código (contexto(): sesión, dos pasos,
    contraseña temporal, términos, empresa en regla, membresía y pestaña) más «configurar», y rechaza de forma expresa el token de API y al
    administrador del sistema. El pase queda atado a la empresa ACTIVA de esa llamada, que debe ser la `empresa_id` que mostró la pantalla
    (409 «empresa_distinta»). Reclama primero (UPDATE … WHERE estado='pendiente' AND vence>ahora, con la cédula), y recién después lee y
    genera el NÚMERO DE COMPROBACIÓN que la página muestra (E-1). Con conexión distinta o desconocida la entrega se retiene (E-2)."""
    u = ctx.usuario
    if ctx.token_api is not None:
        raise _error_web(403, "token")
    if u.es_superadmin:
        raise _error_web(403, "soporte")
    if not ctx.puede("configurar"):
        raise _error_web(403, "sin_permiso")
    _cuenta_en_regla(sc, u)
    e = ctx.empresa
    if e.es_demo:
        raise _error_web(400, "demo")
    if int(data.empresa_id) != int(e.id):
        raise _error_web(409, "empresa_distinta")
    _tope_codigos(request, u)
    codigo = _normalizar_codigo(data.codigo)
    ch = _hash_codigo(codigo) if codigo else None
    ahora = time.time()
    ip = _auth._ip(request)
    n = 0
    if ch and data.aprobar:
        # 4.31 (16a): el programa ya dijo (al sondear) que esta computadora tiene ventas de esta empresa y nunca estuvo conectada a ella:
        # no se aprueba (rechazar sí). Si todavía no lo dijo, lo revisa la entrega con lo que manda en ese momento (conexion_recoger).
        previo = _pase(sc, codigo_hash=ch, estado="pendiente")
        if (previo is not None and previo["vence"] > ahora and previo.get("cedula") and previo.get("cedula") == _digitos(e.numero_id)
                and _trae_datos_ajenos(e.id, previo.get("cedula"), previo.get("terminal_previa")) is True):
            auditar(sc, "sinc_conexion_bloqueada", f"No se aprobó la computadora «{previo['nombre']}»: trae ventas de esta empresa que no están en la página web "
                    "(nunca estuvo conectada a ella)", u, e.id, request)
            raise _error_web(409, "datos_locales")
    if ch:
        try:
            if data.aprobar:
                r = sc.execute(_sql("UPDATE sincpase SET estado='aprobado', empresa_id=:e, usuario_id=:u, aprobado=:t, ip_aprueba=:ip, vence=:v "
                                    "WHERE codigo_hash=:h AND estado='pendiente' AND vence > :t AND (cedula IS NULL OR cedula='' OR cedula=:ced)"),
                               {"e": e.id, "u": u.id, "t": ahora, "ip": (ip or None) and ip[:64], "v": ahora + SEGUNDOS_RECOGER, "h": ch, "ced": _digitos(e.numero_id)})
            else:
                r = sc.execute(_sql("UPDATE sincpase SET estado='rechazado', empresa_id=:e, usuario_id=:u, aprobado=:t, ip_aprueba=:ip "
                                    "WHERE codigo_hash=:h AND estado='pendiente' AND vence > :t"),
                               {"e": e.id, "u": u.id, "t": ahora, "ip": (ip or None) and ip[:64], "h": ch})
            n = r.rowcount or 0
            sc.commit()
        except OperationalError:
            sc.rollback()
            raise _error_web(503, "ocupada")
    if n != 1:
        p = _pase(sc, codigo_hash=ch) if ch else None
        if p is None:
            _fallo_codigo(request, u)
            raise _error_web(404, "no_existe")
        if p["estado"] == "pendiente" and p["vence"] > ahora and p.get("cedula"):
            raise _error_web(409, "cedula_distinta", cedula=p["cedula"])
        if p["estado"] in ("pendiente", "vencido") or p["vence"] <= ahora:
            raise _error_web(410, "vencido")
        raise _error_web(409, "ya_resuelto")
    p = _pase(sc, codigo_hash=ch, usuario_id=u.id, aprobado=ahora)
    if not data.aprobar:
        auditar(sc, "sinc_conexion_rechazada", f"Conexión de la computadora «{p['nombre']}» rechazada por {u.nombre} en la página web", u, e.id, request)
        return {"estado": "rechazado"}
    numero = str(secrets.randbelow(900) + 100)
    misma = _misma_conexion(p.get("ip"), ip)
    retener = None if misma else ahora + SEGUNDOS_RETENCION
    vence = (retener or ahora) + SEGUNDOS_RECOGER
    try:
        sc.execute(_sql("UPDATE sincpase SET numero_hash=:nh, misma_conexion=:m, retener_hasta=:r, vence=:v WHERE id=:id AND estado='aprobado' AND numero_hash IS NULL"),
                   {"nh": _hash_numero(p["id"], numero), "m": misma, "r": retener, "v": vence, "id": p["id"]})
        sc.commit()
    except OperationalError:
        sc.rollback()
        raise _error_web(503, "ocupada")
    desde = "la misma conexión" if misma else "otra conexión a internet (o una que no se pudo comprobar)"
    auditar(sc, "sinc_conexion_aprobada", f"Computadora «{p['nombre']}» aprobada para conectarse a {e.nombre} por {u.nombre} ({u.correo}) desde su "
            f"conexión; la computadora la pidió desde {desde}" + (f"; la entrega se retiene {SEGUNDOS_RETENCION // 60} minutos" if retener else ""), u, e.id, request)
    try:
        _crear_avisos(sc, e.id, p["id"], p["nombre"], u)
        if retener:
            _avisar_conexion(sc, e, u, p["nombre"], retenida=True)
        _descartar_sin_estrenar(sc, s, e.id, forzar=True)
    except Exception as ex:  # noqa: BLE001  el aviso no impide la aprobación
        sc.rollback()
        log.warning("Conexión de una computadora: aviso a los administradores (%s)", type(ex).__name__)
    return {"estado": "aprobado", "numero": numero, "pase": p["id"], "nombre": p["nombre"], "empresa": e.nombre, "misma_conexion": misma,
            "retenida": bool(retener), "segundos_retencion": SEGUNDOS_RETENCION if retener else 0, "segundos": int(vence - ahora)}


def _estado_web(p: dict, ahora: float) -> str:
    if p["estado"] == "entregado":
        return "entregada" if p.get("token_id") else "en_curso"
    if p["estado"] == "aprobado" and p["vence"] > ahora:
        return "retenida" if (p.get("retener_hasta") or 0) > ahora else "aprobada"
    return {"rechazado": "rechazada", "cancelado": "cancelada", "anulado": "anulada", "bloqueado": "bloqueada"}.get(p["estado"], "vencida")   # 4.31 (16a): bloqueada


def _pase_de_admin(sc, u, pid: int) -> dict:
    """El pase, solo para quien lo aprobó o para un administrador (con «configurar») de su empresa; si no, 404."""
    p = _pase(sc, id=int(pid))
    if p is None or not p.get("empresa_id"):
        raise HTTPException(404, "No encontrado")
    if p.get("usuario_id") != u.id and u.id not in {a.id for a in _admins_empresa(sc, int(p["empresa_id"]))}:
        raise HTTPException(404, "No encontrado")
    return p


@router.post("/conexion/seguimiento")
def conexion_seguimiento(data: ConexionPaseIn, _nube: None = Depends(_solo_nube), u=Depends(_auth.solo_usuario), sc: Session = Depends(get_session)):
    """E-15: la página consulta el pase que aprobó hasta verlo «entregada» antes de decir «Listo». Estados: aprobada | retenida | en_curso |
    entregada | cancelada | anulada | rechazada | vencida | bloqueada (4.31, 16a: la computadora trae ventas que la web no tiene)."""
    _cuenta_en_regla(sc, u)
    p = _pase_de_admin(sc, u, data.pase)
    ahora = time.time()
    return {"estado": _estado_web(p, ahora), "segundos_retencion": max(0, int((p.get("retener_hasta") or 0) - ahora))}


@router.post("/conexion/detener")
def conexion_detener(data: ConexionPaseIn, request: Request, _nube: None = Depends(_solo_nube), u=Depends(_auth.solo_usuario), sc: Session = Depends(get_session)):
    """E-2: «Cancelar» de la página (quien aprobó o un administrador de la empresa): anula un pase aprobado que todavía no se entregó
    (por ejemplo, durante la retención)."""
    _cuenta_en_regla(sc, u)
    p = _pase_de_admin(sc, u, data.pase)
    try:
        r = sc.execute(_sql("UPDATE sincpase SET estado='cancelado' WHERE id=:id AND estado='aprobado'"), {"id": p["id"]})
        n = r.rowcount or 0
        sc.commit()
    except OperationalError:
        sc.rollback()
        raise _error_web(503, "ocupada")
    if n == 1:
        _resolver_avisos(sc, p["id"], "cancelada")
        auditar(sc, "sinc_conexion_cancelada", f"Conexión de la computadora «{p['nombre']}» cancelada por {u.nombre} antes de entregarse", u, p["empresa_id"], request)
        return {"estado": "cancelada"}
    return {"estado": _estado_web(_pase(sc, id=p["id"]) or p, time.time())}


@router.post("/conexion/recoger")
def conexion_recoger(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None), sc: Session = Depends(get_session)):
    """Lo llama el PROGRAMA con su secreto: {secreto, numero?, confirmar?, terminal_anterior?, secuencias?, version?}. Contesta 200 con el
    sobre (estado pendiente | retenida | aprobada | numero_errado | conectada | entregada | rechazada | cancelada | anulada | vencida), o 404
    «desconocido» con un secreto que no existe (cuenta en «sinc_rec»). «aprobada» trae SOLO la confirmación (E-4: empresa, cédula y quien
    aprobó); con {numero, confirmar: true} y el número correcto se reclama el pase (UPDATE … WHERE estado='aprobado', E-5), se revisa de
    nuevo la empresa y quien aprobó, nace la instalación y la respuesta «conectada» trae, UNA sola vez, lo mismo que el canje más los
    usuarios (con el hash inservible y sin PIN), los roles y quién aprobó. Base ocupada: «pendiente» (el siguiente sondeo reintenta)."""
    sujeto = _sujeto_conexion(request)
    try:
        limitar_ip(request, "sinc_rec", *TOPE_SECRETOS, MENSAJES_CONEXION["tope"], sujeto=sujeto, registrar=False)
        limitar_ip(request, "sinc_recoger", *TOPE_RECOGER, MENSAJES_CONEXION["tope"], sujeto=sujeto)
    except HTTPException:
        return _respuesta_conexion(429, "tope")
    d = _leer_cuerpo(ConexionRecogerIn, cuerpo)
    p = None
    try:
        p = _pase(sc, secreto_hash=_hash(d.secreto)) if d is not None and d.secreto else None
    except OperationalError:
        sc.rollback()
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO)
    if p is None:
        try:
            limitar_ip(request, "sinc_rec", *TOPE_SECRETOS, MENSAJES_CONEXION["tope"], sujeto=sujeto)
        except HTTPException:
            return _respuesta_conexion(429, "tope")
        return _respuesta_conexion(404, "desconocido" if d is not None else "invalido")
    ahora = time.time()
    estado = _estado_programa(p, ahora)
    if p.get("estado") == "bloqueado":                                   # 4.31 (16a): detenida por traer ventas que la web no tiene
        return _sobre_conexion("anulada", mensaje=MENSAJES_WEB_CONEXION["datos_locales"], motivo="datos_locales")
    if p.get("cedula") and p.get("terminal_previa") is None and estado in ("pendiente", "retenida", "aprobada"):
        _anotar_terminal_previa(sc, p, d)
    if estado in ("retenida", "aprobada") and p.get("cedula") and _trae_datos_ajenos(int(p["empresa_id"]), p["cedula"], int(d.terminal_anterior or 0)) is True:
        return _bloquear_pase(sc, p, request)                            # 4.31 (16a): antes del número y de la entrega
    if estado == "pendiente":
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO, segundos=max(0, int(p["vence"] - ahora)))
    numero = _digitos(d.numero)
    if estado == "retenida":
        # 4.25 (9b, U6): un número que llega durante la retención se comprueba en el momento: errado cuenta el intento y se dice ya (a los
        # 3, anulado), sin entregar nada y sin acortar la retención; el correcto sigue «retenida» hasta que termine la espera
        if d.confirmar and numero and not hmac.compare_digest(_hash_numero(p["id"], numero), str(p.get("numero_hash") or "")):
            return _numero_errado_pase(sc, p, request)
        return _sobre_conexion("retenida", intervalo=INTERVALO_SONDEO, segundos=int(p["retener_hasta"] - ahora) + 1, **_confirmacion(sc, p))
    if estado != "aprobada":
        return _sobre_conexion(estado)
    if not (d.confirmar and numero):
        return _sobre_conexion("aprobada", intervalo=INTERVALO_SONDEO, segundos=max(0, int(p["vence"] - ahora)), **_confirmacion(sc, p))
    nh = _hash_numero(p["id"], numero)
    if not hmac.compare_digest(nh, str(p.get("numero_hash") or "")):
        return _numero_errado_pase(sc, p, request)
    return _entregar_pase(sc, p, d, nh, request)


def _numero_errado_pase(sc, p: dict, request) -> dict:
    """Un número de comprobación equivocado: cuenta el intento (al INTENTOS_NUMERO, anulado), lo audita sin el número y contesta
    «numero_errado» con los intentos que quedan. (4.25, 9b: sale de conexion_recoger; vale también durante la retención.)"""
    try:
        sc.execute(_sql("UPDATE sincpase SET intentos=intentos+1, estado=CASE WHEN intentos+1 >= :max THEN 'anulado' ELSE estado END "
                        "WHERE id=:id AND estado='aprobado'"), {"max": INTENTOS_NUMERO, "id": p["id"]})
        sc.commit()
    except OperationalError:
        sc.rollback()
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO)
    q = _pase(sc, id=p["id"]) or p
    anulado = q["estado"] == "anulado"
    auditar(sc, "sinc_conexion_fallida", f"Número de comprobación equivocado en la computadora «{p['nombre']}» (intento {q['intentos']} de "
            f"{INTENTOS_NUMERO})" + ("; el código quedó anulado" if anulado else ""), None, p.get("empresa_id"), request)
    if anulado:
        return _sobre_conexion("anulada", mensaje="Se escribió tres veces un número que no era. Por seguridad el código se anuló. Empiece de nuevo.")
    if q["estado"] != "aprobado":
        return _sobre_conexion(_estado_programa(q, time.time()))
    return _sobre_conexion("numero_errado", intentos_restantes=max(0, INTENTOS_NUMERO - int(q["intentos"] or 0)))


def _anotar_terminal_previa(sc, p: dict, d) -> None:
    """4.31 (16a): lo que dice el programa al sondear un pase CON cédula queda en el pase (una sola vez): 0 = esa computadora nunca estuvo
    conectada; N = su terminal anterior. Así la página web ya lo sabe al consultar y al aprobar. Base ocupada: el siguiente sondeo."""
    try:
        sc.execute(_sql("UPDATE sincpase SET terminal_previa=:t WHERE id=:id AND terminal_previa IS NULL"),
                   {"t": int(getattr(d, "terminal_anterior", None) or 0), "id": p["id"]})
        sc.commit()
    except OperationalError:
        sc.rollback()


def _bloquear_pase(sc, p: dict, request) -> dict:
    """4.31 (16a): la entrega de un pase aprobado se detiene: la computadora trae ventas de esta empresa y nunca estuvo conectada a ella (o
    su terminal no es de ninguna computadora de esta empresa). No nace ninguna instalación ni viaja nada; el pase queda «bloqueado» (la
    página lo ve en el seguimiento), los avisos se resuelven y se audita. El programa recibe «anulada» con el texto (un programa 4.25 a
    4.30 muestra su propio «se anuló»: no recibió nada). Base ocupada: «pendiente» (el siguiente sondeo lo repite)."""
    try:
        r = sc.execute(_sql("UPDATE sincpase SET estado='bloqueado' WHERE id=:id AND estado='aprobado'"), {"id": p["id"]})
        n = r.rowcount or 0
        sc.commit()
    except OperationalError:
        sc.rollback()
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO)
    if n == 1:
        _resolver_avisos(sc, p["id"], "anulada")
        auditar(sc, "sinc_conexion_bloqueada", f"La computadora «{p['nombre']}» no se conectó: trae ventas de esta empresa que no están en la página web "
                "(nunca estuvo conectada a ella)", None, p.get("empresa_id"), request)
    else:
        q = _pase(sc, id=p["id"]) or p
        if q["estado"] != "bloqueado":
            return _sobre_conexion(_estado_programa(q, time.time()))
    return _sobre_conexion("anulada", mensaje=MENSAJES_WEB_CONEXION["datos_locales"], motivo="datos_locales")


def _entregar_pase(sc, p: dict, d, nh: str, request) -> dict:
    """El número es el de la página: se reclama el pase (un solo uso de verdad), se revisan otra vez la empresa y quien aprobó, nace la
    instalación y se contesta «conectada» (4.25, 9b: sale de conexion_recoger sin cambios)."""
    # el número es el de la página: se reclama el pase (un solo uso de verdad)
    try:
        r = sc.execute(_sql("UPDATE sincpase SET estado='entregado', entregado=:t WHERE id=:id AND estado='aprobado' AND vence > :t AND numero_hash=:nh "
                            "AND (retener_hasta IS NULL OR retener_hasta <= :t)"), {"t": time.time(), "id": p["id"], "nh": nh})
        n = r.rowcount or 0
        sc.commit()
    except OperationalError:
        sc.rollback()
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO)
    if n != 1:
        q = _pase(sc, id=p["id"]) or p
        return _sobre_conexion(_estado_programa(q, time.time()))
    try:
        e = sc.get(Empresa, int(p["empresa_id"]))
        aprobador = sc.get(_auth.Usuario, int(p["usuario_id"]))
        motivo = _motivo_no_entrega(sc, e, aprobador)
        if motivo:
            sc.execute(_sql("UPDATE sincpase SET estado='anulado' WHERE id=:id AND estado='entregado' AND token_id IS NULL"), {"id": p["id"]}); sc.commit()
            _resolver_avisos(sc, p["id"], "anulada")
            auditar(sc, "sinc_conexion_anulada", f"La computadora «{p['nombre']}» no se conectó: {motivo}", None, p["empresa_id"], request)
            return _sobre_conexion("anulada")
        sec = {str(k)[:4]: int(x) for k, x in (d.secuencias or {}).items() if isinstance(x, int) and not isinstance(x, bool)}
        detalle = (f"aprobada por {aprobador.nombre} ({aprobador.correo}) desde su conexión; recogida desde "
                   + ("la misma conexión" if _misma_conexion(p.get("ip_aprueba"), _auth._ip(request)) else "otra conexión a internet (o una que no se pudo comprobar)"))
        datos = _usuarios_empresa(e.id)                                 # antes del alta: después ya no hay vuelta atrás
        with Session(engine_empresa(e.id)) as s:
            v = _leer(s, e.id, CLAVE_VINC, {})
            alta = _alta_instalacion(sc, s, e, v, nombre=p["nombre"], terminal_anterior=d.terminal_anterior, secuencias=sec, request=request,
                                     usuario=aprobador, origen="conexion", reemplaza_sin_estrenar=True, por=aprobador.correo, detalle=detalle)
    except Exception as ex:  # noqa: BLE001
        try:
            sc.rollback()
        except Exception:  # noqa: BLE001
            pass
        log.warning("Conexión de una computadora: no se pudo terminar la entrega (%s)", type(ex).__name__)
        try:                                                             # el token (si nació) ya se revocó en _alta_instalacion
            sc.execute(_sql("UPDATE sincpase SET estado='aprobado', entregado=NULL, token_id=NULL WHERE id=:id AND estado='entregado'"), {"id": p["id"]})
            sc.commit()
        except Exception:  # noqa: BLE001
            sc.rollback()
        return _sobre_conexion("pendiente", intervalo=INTERVALO_SONDEO)
    # la instalación ya existe: desde aquí nada impide la entrega (el token viaja una sola vez, en esta respuesta)
    try:
        tid = sc.exec(select(TokenApi.id).where(TokenApi.hash == _hash_token_api(alta["token"]))).first()
        sc.execute(_sql("UPDATE sincpase SET token_id=:tid WHERE id=:id"), {"tid": tid, "id": p["id"]})
        sc.execute(_sql("UPDATE sincaviso SET token_id=:tid WHERE pase_id=:id"), {"tid": tid, "id": p["id"]})
        sc.commit()
        if p.get("misma_conexion"):                                      # con conexión distinta el correo ya salió al aprobar (E-2)
            _avisar_conexion(sc, e, aprobador, p["nombre"], retenida=False)
    except Exception as ex:  # noqa: BLE001
        sc.rollback()
        log.warning("Conexión de una computadora: anotar la instalación en el pase o avisar (%s)", type(ex).__name__)
    usuarios = [{**f, "password_hash": HASH_INSERVIBLE, "pin_hash": None} for f in datos["usuarios"]]
    return _sobre_conexion("conectada", **alta, usuarios=usuarios, roles=datos["roles"], aprobo={"correo": aprobador.correo, "nombre": aprobador.nombre})


@router.post("/conexion/cancelar")
def conexion_cancelar(request: Request, _nube: None = Depends(_solo_nube), cuerpo: Any = Body(default=None), sc: Session = Depends(get_session)):
    """Lo llama el PROGRAMA con su secreto (también cuando la persona dice que no es su empresa, E-4): anula un pase pendiente o aprobado
    que no se entregó. Siempre 200 «cancelada»; comparte el tope de secretos que no existen («sinc_rec»). Solo audita (texto fijo) si el
    pase ya estaba aprobado para una empresa."""
    sujeto = _sujeto_conexion(request)
    try:
        limitar_ip(request, "sinc_rec", *TOPE_SECRETOS, MENSAJES_CONEXION["tope"], sujeto=sujeto, registrar=False)
    except HTTPException:
        return _respuesta_conexion(429, "tope")
    d = _leer_cuerpo(ConexionSecretoIn, cuerpo)
    sh = _hash(d.secreto) if d is not None and d.secreto else None
    n = 0
    if sh:
        try:
            r = sc.execute(_sql("UPDATE sincpase SET estado='cancelado' WHERE secreto_hash=:h AND estado IN ('pendiente','aprobado')"), {"h": sh})
            n = r.rowcount or 0
            sc.commit()
        except OperationalError:
            sc.rollback()
            return _respuesta_conexion(503, "error")
    p = _pase(sc, secreto_hash=sh) if sh else None
    if p is None:
        try:
            limitar_ip(request, "sinc_rec", *TOPE_SECRETOS, MENSAJES_CONEXION["tope"], sujeto=sujeto)
        except HTTPException:
            return _respuesta_conexion(429, "tope")
    elif n == 1 and p.get("empresa_id"):
        _resolver_avisos(sc, p["id"], "cancelada")
        auditar(sc, "sinc_conexion_cancelada", f"La computadora «{p['nombre']}» canceló la conexión antes de recibir los datos", None, p["empresa_id"], request)
    return _sobre_conexion("cancelada")


def _estado_aviso(sc, a: SincAviso, ahora: float) -> Optional[str]:
    """«conectada» (la instalación vive), «por_completar» (aprobada, todavía sin entregar) o None (ya no aplica: se canceló, venció, se
    anuló o la instalación se revocó o descartó)."""
    tid = a.token_id
    p = None
    if not tid:
        p = sc.get(SincPase, a.pase_id)
        if p is None:
            return None
        if p.estado == "entregado":
            if not p.token_id:
                return "por_completar"
            tid = p.token_id
        elif p.estado == "aprobado" and p.vence > ahora:
            return "por_completar"
        else:
            return None
    t = sc.get(TokenApi, int(tid))
    return "conectada" if (t is not None and not t.revocado) else None


@router.get("/conexion/avisos")
def conexion_avisos(_nube: None = Depends(_solo_nube), ctx: Contexto = Depends(requiere("configurar")), sc: Session = Depends(get_session)):
    """E-7: los avisos pendientes de computadoras nuevas de la empresa activa para quien entra (cada administrador ve los suyos hasta
    contestar). La pantalla es de la tanda 7."""
    if ctx.token_api is not None or ctx.usuario.es_superadmin or ctx.soporte:      # 4.35: ni al entrar como la persona («Entrar como»)
        return {"avisos": []}
    ahora = time.time()
    salida = []
    for a in sc.exec(select(SincAviso).where(SincAviso.empresa_id == ctx.empresa.id, SincAviso.usuario_id == ctx.usuario.id,
                                            SincAviso.respuesta == None).order_by(SincAviso.id)).all():  # noqa: E711
        estado = _estado_aviso(sc, a, ahora)
        if estado is None:
            continue
        texto = (AVISO_CONECTADA if estado == "conectada" else AVISO_POR_COMPLETAR).format(nombre=a.nombre, aprobo=a.aprobo)
        salida.append({"id": a.id, "nombre": a.nombre, "aprobo": a.aprobo, "estado": estado, "creado": datetime.fromtimestamp(a.creado, timezone.utc).isoformat(timespec="seconds"),
                       "texto": texto})
    return {"avisos": salida}


@router.post("/conexion/avisos/{aid}")
def conexion_aviso_responder(aid: int, data: AvisoRespuestaIn, request: Request, _nube: None = Depends(_solo_nube), ctx: Contexto = Depends(requiere("configurar")),
                             s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """E-7: «si» (la reconoce: deja de verlo esa persona) o «revocar» (anula el pase si todavía no se entregó o revoca la instalación que
    nació de él; el aviso se cierra para todos)."""
    a = sc.get(SincAviso, aid)
    if a is None or a.usuario_id != ctx.usuario.id or a.empresa_id != ctx.empresa.id or ctx.token_api is not None:
        raise HTTPException(404, "Aviso no encontrado")
    if data.respuesta not in ("si", "revocar"):
        raise HTTPException(400, "Respuesta no válida")
    if a.respuesta:
        return {"ok": True, "estado": a.respuesta}
    eid, pid, nombre = ctx.empresa.id, a.pase_id, a.nombre
    if data.respuesta == "si":
        a.respuesta, a.respondido = "si", time.time(); sc.add(a); sc.commit()
        auditar(sc, "sinc_aviso_reconocida", f"{ctx.usuario.nombre} reconoce la computadora «{nombre}»", ctx.usuario, eid, request)
        return {"ok": True, "estado": "si"}
    try:
        r = sc.execute(_sql("UPDATE sincpase SET estado='cancelado' WHERE id=:id AND estado='aprobado'"), {"id": pid})
        n = r.rowcount or 0
        sc.commit()
    except OperationalError:
        sc.rollback()
        raise _error_web(503, "ocupada")
    if n == 1:
        _resolver_avisos(sc, pid, "revocar")
        auditar(sc, "sinc_conexion_cancelada", f"Conexión de la computadora «{nombre}» cancelada por {ctx.usuario.nombre} desde el aviso de computadora nueva",
                ctx.usuario, eid, request)
        return {"ok": True, "estado": "cancelada"}
    p = _pase(sc, id=pid)
    tid = a.token_id or (p or {}).get("token_id")
    if not tid:
        if p is not None and p["estado"] == "entregado":
            raise _error_web(409, "en_curso")
        _resolver_avisos(sc, pid, "revocar")
        return {"ok": True, "estado": "sin_efecto"}
    t = sc.get(TokenApi, int(tid))
    if t is not None and t.empresa_id == eid and not t.revocado:
        t.revocado = True; sc.add(t); sc.commit()
        for x in sc.exec(select(_auth.IngresoPrograma).where(_auth.IngresoPrograma.token_id == t.id)).all():
            sc.delete(x)
        sc.commit()
    inst = _retirar_por_token(s, eid, int(tid))
    _resolver_avisos(sc, pid, "revocar")
    if inst is not None:
        auditar(sc, "sinc_desvinculada", f"Instalación local «{inst.get('nombre')}» (terminal {inst.get('terminal')}) revocada desde el aviso de computadora nueva",
                ctx.usuario, eid, request)
    return {"ok": True, "estado": "revocada"}


# ======================================================================================================================
# LADO LOCAL
# ======================================================================================================================
def _cfg_local(s, eid):
    return _leer(s, eid, CLAVE_LOCAL, {})


def _subidos(cfg) -> dict:
    sub = cfg.get("subidos")
    if not isinstance(sub, dict):
        sub = {"documentos": int(sub or 0)}
    for k in ("documentos", "pagos", "registros", "clientes", "productos"):
        sub.setdefault(k, 0)
    return sub


def _estado_local(s, eid, e: Empresa | None = None) -> dict:
    cfg = _cfg_local(s, eid)
    pend = s.exec(select(Documento).where(Documento.sinc_en == None)).all() if cfg.get("vinculado") else []  # noqa: E711
    pagos = s.exec(select(modulos.Pago).where(modulos.Pago.sinc_en == None)).all() if cfg.get("vinculado") else []  # noqa: E711
    red = cfg.get("red") or {}
    rev, bloq = _parse(cfg.get("revocada_en")), _parse(cfg.get("bloqueada_en"))
    return {"modo_local": MODO_LOCAL, "vinculado": bool(cfg.get("vinculado")), "url": cfg.get("url"), "nombre": cfg.get("nombre"), "terminal": cfg.get("terminal"),
            "revocada_en": cfg.get("revocada_en"), "bloqueada_en": cfg.get("bloqueada_en"), "respaldo": cfg.get("respaldo"), "revinculada": bool(cfg.get("revinculada")),
            "bloquea_el": (rev + timedelta(days=DIAS_BLOQUEO)).isoformat(timespec="seconds") if rev and not bloq else None,
            "elimina_el": (bloq + timedelta(days=DIAS_BORRADO)).isoformat(timespec="seconds") if bloq else None,
            "sin_acceso_desde": cfg.get("sin_acceso_desde"), "sin_acceso_motivo": cfg.get("sin_acceso_motivo"),     # 4.9: la nube niega el acceso sin revocar
            "fijas": {"terminal": cfg.get("terminal"), "sucursal": cfg.get("sucursal")} if cfg.get("terminal") else None,   # 4.9: no se editan
            "ultima_bajada": cfg.get("ultima_bajada"), "ultima_subida": cfg.get("ultima_subida"), "ultimo_error": cfg.get("ultimo_error"),
            "descartada": _conexion_descartada(cfg),                     # 4.25 (D-O): la web descartó sola la conexión; hay que conectarla de nuevo
            "pendientes": len(pend), "pagos_pendientes": len(pagos), "clientes": cfg.get("clientes"), "productos": cfg.get("productos"),
            "existencias": cfg.get("existencias"), "aviso": cfg.get("aviso_bajada") or cfg.get("aviso"), "subidos": _subidos(cfg), "sincronizando": _en_curso.get(eid, False),
            "usuarios_bajada": cfg.get("usuarios_bajada"), "usuarios_atrasados": usuarios_atrasados(cfg, bool(e is not None and e.bloqueada)),       # 4.25 (D-F)
            "direcciones": _direcciones() if MODO_LOCAL else [],
            "red": {"clave_definida": bool(red.get("clave_hash")), "pcs": [_pc_publico(pc) for pc in red.get("pcs") or []],
                    "recibido_de": (_leer(s, eid, CLAVE_RED_RECIBIDO, {}).get("de") or {})}}


def _direcciones() -> list:
    """Direcciones por las que las otras computadoras del local pueden llegar a esta (IP de la red local + puerto)."""
    try:
        puerto = int((os.environ.get("FE_URL_PUBLICA") or "").rsplit(":", 1)[-1].strip("/") or 8020)
    except ValueError:
        puerto = 8020
    ips = []
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except Exception:  # noqa: BLE001
        pass
    return [f"http://{ip}:{puerto}" for ip in ips]


# Tanda 4 (4.25): revisión general de Host y Origin en el programa local real (auth._es_local()). Con el ingreso validado en la web, el
# /api/auth/login del programa reenvía contraseñas a la nube: una página ajena cuyo nombre apunte a 127.0.0.1 (cambio de DNS) no debe
# poder usarlo. 4b (Q9): un ataque de cambio de DNS siempre llega con el NOMBRE del atacante en Host, y una IP escrita no se puede
# redirigir; por eso el Host vale si es (a) cualquier IP literal, IPv4 o IPv6, (b) localhost o (c) el nombre de ESTA computadora de una
# sola etiqueta (socket.gethostname() hasta el primer punto, sin distinguir mayúsculas) o ese nombre con «.local»; cualquier otro nombre
# no (así funcionan varios adaptadores de red, una VPN y http://CAJA1:8020). Si la petición trae Origin, su servidor tiene que ser el
# mismo del Host. Una petición sin Origin (otra computadora del local por /api/sinc/red/..., un guion) pasa. El cliente «testclient» de
# las pruebas no se revisa (las que encienden FE_MODO_LOCAL hablan con Host «testserver»), pero SOLO dentro de las pruebas (variable
# VAR_PRUEBAS, que pone tests/conftest.py y nada más): el nombre del cliente sí puede llegar por la red, porque uvicorn (proxy_headers,
# activo por omisión) lo cambia por lo que diga X-Forwarded-For en las conexiones que llegan desde 127.0.0.1, y una página ajena cuyo
# nombre apunte a 127.0.0.1 puede mandar «X-Forwarded-For: testclient».
VAR_PRUEBAS = "FE_PRUEBAS_TESTCLIENT"
MENSAJE_HOST = "Esta dirección no está permitida para el programa de esta computadora. Ábralo con http://127.0.0.1 o con la dirección que muestra el programa."
MENSAJE_ORIGEN = "Esta petición viene de otra página y no está permitida en el programa de esta computadora."
_EQUIPO: dict = {"v": None}                       # el nombre de esta computadora, calculado una vez (no en cada petición)


def _nombre_equipo() -> str:
    """El nombre de esta computadora en minúsculas y de una sola etiqueta (hasta el primer punto); vacío si no se puede saber."""
    if _EQUIPO["v"] is None:
        try:
            nombre = (socket.gethostname() or "").strip().split(".", 1)[0].lower()
        except Exception:  # noqa: BLE001
            nombre = ""
        _EQUIPO["v"] = nombre
    return _EQUIPO["v"]


def _host_permitido(nombre: str) -> bool:
    """4b (Q9): una IP literal, localhost, o el nombre de esta computadora (solo o con «.local»)."""
    try:
        ipaddress.ip_address(nombre)
        return True
    except ValueError:
        pass
    if nombre == "localhost":
        return True
    equipo = _nombre_equipo()
    return bool(equipo) and nombre in (equipo, equipo + ".local")


def _servidor(valor: str, esquema: str) -> tuple | None:
    """(esquema, nombre, puerto) de un Host («nombre[:puerto]», con el esquema de la petición) o de un Origin («esquema://nombre[:puerto]»);
    None si no se entiende."""
    try:
        p = urlparse(valor if "://" in valor else f"{esquema}://{valor}")
        if not p.hostname or p.path not in ("", "/") or p.query or p.params or p.username is not None or p.password is not None:
            return None
        return p.scheme.lower(), p.hostname.lower(), p.port or (443 if p.scheme.lower() == "https" else 80)
    except ValueError:
        return None


def revisar_host_origen(request) -> str | None:
    """None si la petición puede seguir; si no, el mensaje del rechazo (403). Solo en el programa local real."""
    if not _auth._es_local():
        return None
    cliente = request.client.host if request.client else ""
    if cliente == "testclient" and os.environ.get(VAR_PRUEBAS) == "1":   # solo en las pruebas: el nombre solo no basta (ver arriba)
        return None
    esquema = request.url.scheme or "http"
    host = _servidor(request.headers.get("host") or "", esquema)
    if host is None or not _host_permitido(host[1]):
        return MENSAJE_HOST
    origen = request.headers.get("origin")
    if origen is not None and _servidor(origen.strip(), esquema) != host:
        return MENSAJE_ORIGEN
    return None


def _pc_publico(pc: dict) -> dict:
    return {k: pc.get(k) for k in ("nombre", "url", "ultimo_ok", "ultimo_error", "enviados", "terminal", "version")}


class VincularIn(BaseModel):
    url: str = ""                 # 4.25 (tanda 6): opcional; en el programa real se ignora (siempre URL_NUBE)
    codigo: str
    nombre: str = ""


@router.get("/local/aviso")
def aviso_franja(ctx: Contexto = Depends(requiere("ver")), s: Session = Depends(sesion_empresa)):
    """Etapa 1: franja de la aplicación en la instalación (conexión y plazo de Hacienda). En la nube no hay franja."""
    if not MODO_LOCAL:
        return {"nivel": None}
    return franja_local(s, ctx.empresa)


@router.get("/local/estado")
def estado_local(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    return _estado_local(s, ctx.empresa.id)


def _fijar_rango_local(s, eid: int, terminal: int):
    """Desde ahora los ids nuevos de esta empresa (registros, clientes e ítems) salen del rango de su terminal."""
    from sqlalchemy import text
    modulos.fijar_rango(eid, terminal)
    base = int(terminal) * RANGO
    if not s.execute(text("SELECT name FROM sqlite_master WHERE name='sqlite_sequence'")).scalar():
        return
    for tabla in ("cliente", "producto"):
        actual = s.execute(text("SELECT seq FROM sqlite_sequence WHERE name=:n"), {"n": tabla}).scalar()
        if actual is None:
            s.execute(text("INSERT INTO sqlite_sequence(name, seq) VALUES (:n, :v)"), {"n": tabla, "v": base})
        elif int(actual) < base:
            s.execute(text("UPDATE sqlite_sequence SET seq=:v WHERE name=:n"), {"n": tabla, "v": base})
    s.commit()


def cargar_rangos():
    """Al arrancar la instalación local: el rango de ids de cada empresa vinculada (su terminal), su estado frente a la nube y
    (4.9) la terminal y la sucursal fijas. Una «revocación» anotada sin la señal explícita de la nube pasa a «sin acceso».
    4.9: una empresa que falla no deja sin rango a las demás; (E2) el rango se fija también desvinculada; (E5) si la terminal
    de la empresa no es la fija, vuelve a la fija."""
    if not MODO_LOCAL:
        return
    try:
        with Session(engine) as sc:
            empresas = [(x.id, int(x.sucursal or 1), int(x.terminal or 0)) for x in sc.exec(select(Empresa)).all()]
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc: rangos de ids: %s", ex)
        return
    for eid, sucursal, terminal_bd in empresas:
        try:
            with Session(engine_empresa(eid)) as s:
                cfg = _cfg_local(s, eid)
                cambio = _normalizar_revocacion(cfg)
                if cfg.get("terminal") and not cfg.get("sucursal"):
                    cfg["sucursal"] = sucursal; cambio = True       # 4.9: vinculada con una versión anterior: queda fija la que tiene
                if cambio:
                    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
                if cfg.get("terminal"):
                    # 4.9 (E2): también desvinculada («seguirá trabajando sola»): sus clientes e ítems nuevos siguen en el rango de su
                    # terminal. Antes, al reiniciar desvinculada, el rango quedaba en 0, los ids caían en el de la nube y, al vincularla
                    # de nuevo, la bajada de la nube los pisaba (facturas apuntando a otro cliente, precio y existencias de otro ítem).
                    _fijar_rango_local(s, eid, int(cfg["terminal"]))
                _cargar_estado(eid, cfg)
            if cfg.get("terminal") and terminal_bd != int(cfg["terminal"]):
                _volver_a_terminal_fija(eid, int(cfg["terminal"]))
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc: rangos de ids de la empresa %s: %s", eid, ex)
    _cuentas_al_arrancar()


def _cuentas_al_arrancar() -> None:
    """4.25 (tanda 6, E-13): al arrancar el programa, las sesiones (y los tokens de API) de las cuentas creadas en esta computadora que ya
    no entran se cierran; con FE_LOCAL_ADMIN=1 (modo soporte) queda en la auditoría que el programa arrancó así."""
    try:
        with Session(engine) as sc:
            if _auth._es_local() and os.environ.get("FE_LOCAL_ADMIN") == "1":
                auditar(sc, "sinc_local_modo_soporte", "El programa arrancó en modo soporte (FE_LOCAL_ADMIN=1): las cuentas creadas en esta computadora y la "
                        "creación de cuentas vuelven a funcionar como antes de la 4.25", None, None, None)
                log.warning("Programa en modo soporte (FE_LOCAL_ADMIN=1)")
            n = cerrar_cuentas_retiradas(sc)
            if n:
                log.info("Programa: se cerraron las sesiones de %s cuenta(s) creadas en esta computadora", n)
    except Exception as ex:  # noqa: BLE001
        log.warning("Programa: cuentas al arrancar (%s)", type(ex).__name__)


def _volver_a_terminal_fija(eid: int, fija: int) -> None:
    """4.9 (E5): la terminal de la empresa vuelve a la que quedó fija al vincular. En la 1.46/4.8 se podía cambiar a mano después de
    vincular (p. ej. a la de otra instalación, con la que chocaban sus consecutivos) y desde la 4.9 ya no se podía corregir. Volver
    es seguro: la numeración (Secuencia) va por tipo, ambiente y sucursal, así que sigue después del último número emitido con
    cualquiera de las dos terminales; y la fija es la que la nube le dio solo a esta instalación."""
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        if e is None or int(e.terminal or 0) == int(fija):
            return
        antes = int(e.terminal or 0)
        e.terminal = int(fija); sc.add(e); sc.commit()
        auditar(sc, "sinc_local_terminal", f"La terminal de la empresa estaba en {antes:05d}, distinta de la {int(fija):05d} que quedó fija al vincular esta "
                "instalación con la nube: vuelve a la fija (con otra se repetían consecutivos de Hacienda)", None, eid, None)
    log.warning("sinc empresa %s: la terminal %s vuelve a la fija %s", eid, antes, fija)


def _prueba_de_datos(s, eid: int, cfg_vieja: dict) -> dict:
    """Lo que la computadora manda al vincularse de nuevo: su terminal anterior y sus últimos consecutivos por tipo, para conservar la
    terminal demostrando que conserva sus datos. Vacío si nunca estuvo vinculada. (4.25: sale de vincular.)"""
    if not cfg_vieja.get("terminal"):
        return {}
    secuencias: dict = {}
    for sq in s.exec(select(Secuencia).where(Secuencia.empresa_id == eid)).all():
        secuencias[sq.tipo_documento] = max(int(secuencias.get(sq.tipo_documento) or 0), int(sq.ultimo or 0))
    return {"terminal_anterior": int(cfg_vieja["terminal"]), "secuencias": secuencias}


def _aplicar_vinculacion(s, sc, eid: int, j: dict, url: str, nombre: str, cfg_vieja: dict) -> Empresa:
    """Guarda en esta computadora lo que mandó la nube al vincular (`j`: datos de la empresa, terminal, credenciales y token) y deja la
    configuración local nueva (conserva la red local y, si volvió con su terminal, por dónde iba). Devuelve la Empresa. (4.25: sale de
    vincular.)"""
    e = sc.get(Empresa, eid)
    secretos.asegurar_clave(e)
    _vinculando.add(e.id)                     # 4.9 (5c): solo la vinculación cambia la terminal y la sucursal fijas
    try:
        for k, v in (j.get("empresa") or {}).items():
            if k in CAMPOS_EMPRESA and (v is not None or k in NULABLES_EMPRESA) and hasattr(e, k):     # 4.9 (E1): también vacías
                setattr(e, k, v)
        e.terminal = int(j.get("terminal") or e.terminal or 2)
        _aplicar_credenciales(e, j.get("credenciales") or {})
        sc.add(e); sc.commit()
    finally:
        _vinculando.discard(e.id)
    cfg = {"vinculado": True, "url": url, "token": secretos.cifrar(e.clave_cifrada, j["token"]), "terminal": e.terminal, "nombre": j.get("nombre") or nombre,
           "sucursal": int(e.sucursal or 1),                                                # 4.9: fija desde ahora (con la terminal)
           "vinculada_en": _ahora(), "ultima_bajada": None, "ultima_subida": None, "ultimo_error": None, "revinculada": bool(j.get("revinculada")), "cred_huella": j.get("credenciales_huella")}
    if cfg_vieja.get("red"):
        cfg["red"] = {k: x for k, x in cfg_vieja["red"].items() if k != "revocadas"}      # la red local se conserva
    if j.get("revinculada"):
        for k in ("huellas", "registros_desde", "registros_subidos", "reintentos", "subidos", "cursor_bajada", "cursor_bajas"):
            if k in cfg_vieja:
                cfg[k] = cfg_vieja[k]                                                       # misma terminal: sigue donde iba
    anteriores = {int(x) for x in cfg_vieja.get("terminales_anteriores") or []} | ({int(cfg_vieja["terminal"])} if cfg_vieja.get("terminal") else set())
    anteriores.discard(int(e.terminal))
    if anteriores:
        cfg["terminales_anteriores"] = sorted(anteriores)                # 4.16: lo que nació aquí con otra terminal no se toma como ajeno al bajar
    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
    _fijar_rango_local(s, eid, e.terminal)
    _cargar_estado(eid, cfg)
    _VINC_ALGUNA[int(eid)] = (True, time.time())          # 4.25 (6b, R4): un «no» guardado antes ya no vale (cerrar_cuentas_retiradas corre ahora)
    return e


def _cedula_con_datos(sc, eid: int) -> Optional[str]:
    """4.25 (9b, D-P): la cédula (solo dígitos) de la empresa local si ya tiene datos, con la misma regla de la conexión nueva
    (_otra_empresa): terminal anotada o algún comprobante, y una cédula. None si no tiene datos o no tiene cédula."""
    e = sc.get(Empresa, eid)
    ced = _digitos(e.numero_id if e is not None else None)[:12]
    if not ced:
        return None
    cfg, docs = _tiene_datos(eid)
    return ced if (cfg.get("terminal") or docs) else None


def _mensaje_codigo_otra(cedula: str, e) -> str:
    nombre = (getattr(e, "nombre", None) or getattr(e, "nombre_comercial", None) or "").strip() or f"con cédula {_digitos(getattr(e, 'numero_id', ''))}"
    return MENSAJE_CODIGO_OTRA.format(cedula=cedula or "sin cédula", local=nombre)


@router.post("/local/vincular")
def vincular(data: VincularIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    if not MODO_LOCAL:
        raise HTTPException(400, "Esta instalación es la nube: los códigos se generan aquí y se canjean en la instalación local")
    # 4.25 (tanda 6): en el programa real la dirección es siempre la de la web (URL_NUBE) y la que llegue se ignora; fuera de él (pruebas)
    # vale la que mandan o, si no mandan ninguna, URL_NUBE.
    url = URL_NUBE if _auth._es_local() else ((data.url or "").strip().rstrip("/") or URL_NUBE)
    url = (url or "").strip().rstrip("/")
    if not _url_nube_segura(url):
        raise HTTPException(400, f"Indique la dirección segura de la nube, por ejemplo https://{dominio_sistema()}")
    if os.environ.get("FE_LOCAL_ADMIN") != "1":
        # 4.31 (16a): «Tengo un código» con datos que nunca subieron se detiene igual que «Conectar con mi cuenta»; solo soporte (modo
        # soporte, FE_LOCAL_ADMIN=1, auditado al arrancar) puede seguir
        _parar_con_datos_locales(sc, [ctx.empresa.id], ctx.usuario, ctx.request)
    cfg_vieja = _cfg_local(s, ctx.empresa.id)
    cuerpo = {"codigo": data.codigo.strip(), "nombre": data.nombre.strip()}
    cuerpo.update(_prueba_de_datos(s, ctx.empresa.id, cfg_vieja))
    local = _cedula_con_datos(sc, ctx.empresa.id)                         # 4.25 (9b, D-P): la web no crea una instalación que nadie va a usar
    if local:
        cuerpo["cedula"] = local
    try:
        r = httpx.post(url + "/api/sinc/canje", headers={CABECERA_PLAN: str(PROTOCOLO_PLAN)}, json=cuerpo, timeout=60)   # 4.28 (C1)
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(502, f"No se pudo conectar con la nube: {ex}")
    if r.status_code != 200:
        try:
            det = r.json().get("detail")
        except Exception:  # noqa: BLE001
            det = r.text[:200]
        if r.status_code == 409 and isinstance(det, dict) and det.get("codigo") == "otra_empresa":
            raise HTTPException(409, _mensaje_codigo_otra(_digitos(det.get("cedula"))[:12], ctx.empresa))
        raise HTTPException(400, f"La nube rechazó el código: {det}")
    j = r.json()
    otra = _digitos((j.get("empresa") or {}).get("numero_id") if isinstance(j, dict) else None)[:12]
    if local and otra != local:
        # 4.25 (9b, D-P): una web anterior no revisa la cédula: aquí no se aplica nada (la instalación que nació allá no se usa)
        auditar(sc, "sinc_local_codigo_otra", f"Se rechazó un código de otra empresa (cédula {otra or 'sin cédula'}): esta computadora ya tiene datos de "
                f"la cédula {local}", ctx.usuario, ctx.empresa.id, ctx.request)
        raise HTTPException(409, _mensaje_codigo_otra(otra, ctx.empresa))
    e = _aplicar_vinculacion(s, sc, ctx.empresa.id, j, url, data.nombre, cfg_vieja)
    auditar(sc, "sinc_local_vinculada", f"{'Revinculada' if j.get('revinculada') else 'Vinculada'} a {url} como terminal {e.terminal}", ctx.usuario, e.id, ctx.request)
    cerrar_cuentas_retiradas(sc)                                         # 4.25 (E-13): las cuentas creadas aquí dejan de entrar
    threading.Thread(target=sincronizar, args=(ctx.empresa.id,), daemon=True).start()
    return _estado_local(s, ctx.empresa.id)


@router.post("/local/ahora")
def sincronizar_ahora(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    if not MODO_LOCAL:
        raise HTTPException(400, "Solo en una instalación local")
    sincronizar(ctx.empresa.id)
    return _estado_local(s, ctx.empresa.id)


@router.post("/local/desvincular")
def desvincular(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    cfg = _cfg_local(s, ctx.empresa.id)
    cfg.update({"vinculado": False, "token": None})
    cfg.pop("sin_acceso_desde", None); cfg.pop("sin_acceso_motivo", None)      # 4.9 (R5): ya no intenta llegar a la nube: la franja «sin acceso» se quita
    _escribir(s, ctx.empresa.id, CLAVE_LOCAL, cfg); s.commit()
    _cargar_estado(ctx.empresa.id, cfg)
    auditar(sc, "sinc_local_desvinculada", "Instalación local desvinculada de la nube", ctx.usuario, ctx.empresa.id, ctx.request)
    return _estado_local(s, ctx.empresa.id)


# ======================================================================================================================
# 4.25 (tanda 6, X1b, PROGRAMA): conectar esta computadora con la cuenta de la web
# ======================================================================================================================
# El programa pide un pase a la web (POST /api/sinc/conexion/iniciar, solo a URL_NUBE) con el sha256 de un SECRETO que vive solo en la
# memoria de este proceso (_conexiones: nunca va al navegador, al disco ni a los registros) y muestra el código; un administrador lo
# aprueba en la página web, que le muestra un NÚMERO DE COMPROBACIÓN (E-1). El programa sondea (hilo _esperar_conexion o, sin hilo, la
# ruta de estado) y, cuando la web contesta «aprobada», muestra la empresa, la cédula y quién aprobó (E-4); la persona confirma «Sí, es
# mi empresa» y escribe el número; con eso recoge la instalación y la aplica (_aplicar_conexion, con el candado del ciclo de
# sincronización: E-9). Si la aplicación falla a medias, la respuesta recogida queda en memoria y se reintenta sin volver a la web.
# Una computadora «sin estrenar» (_sin_estrenar, E-11) puede empezar sin sesión, pero solo desde ella misma (_misma_computadora); con
# usuarios que pueden entrar, hace falta sesión con «configurar». Si el programa se reinicia a medias, la memoria se pierde (410
# «intento_perdido»): en la web el pase vence solo y la instalación, si llegó a nacer y nadie la usó, se descarta.
INTERVALO_LOCAL = 3                # segundos mínimos entre dos pasos (la ruta de estado da ella misma un paso si el hilo no lo dio)
SEGUNDOS_GRACIA_CONEXION = 130     # E-15: después del plazo de la web se sigue sondeando (la web da 120 s para recoger)
MAX_CONEXIONES = 5                 # intentos vivos a la vez en la memoria del programa
TOPE_INICIAR_LOCAL = (10, 600)     # inicios cada 10 minutos (en memoria)
SEGUNDOS_INFORME = 300             # un intento terminado se conserva 5 minutos para que la pantalla vea el final
ESPERA_CANDADO = 120               # E-9: segundos que _aplicar_conexion espera a que termine un ciclo de sincronización
HILO_CONEXION = True               # las pruebas lo apagan: los pasos los da la ruta de estado y nada corre en segundo plano
FINALES_LOCAL = ("lista", "rechazada", "vencida", "anulada", "cancelada", "perdida", "otra_empresa", "ya_esta")
MENSAJE_OTRA_COMPUTADORA = ("Esta computadora todavía no está conectada. Abra el programa en la computadora donde está instalado (con su acceso "
                            "directo «FISITAAP Local») y conéctela desde ahí.")
MENSAJE_SIN_WEB = "No se pudo llegar a {web}. Revise la conexión a internet de esta computadora e intente de nuevo."
MENSAJE_INTENTO_PERDIDO = "El programa se cerró mientras esperaba. Empiece de nuevo."
MENSAJE_BAJANDO = "Esta computadora todavía está bajando los datos de su empresa. Espere un minuto e intente de nuevo."
MENSAJES_LOCAL = {
    "esperando": "Estamos esperando que la aprueben en la página web.",
    "retenida": "Aprobada. Por seguridad se completa en unos minutos.",
    "confirmar": "Aprobada en la página web. Revise que sea su empresa y escriba el número de comprobación que muestra la página.",
    "aplicando": "Aprobada. Bajando los datos de su empresa… No cierre el programa; puede tardar un minuto.",
    "lista": "Listo. Esta computadora quedó conectada a {empresa}. Ahora entre con su correo y su contraseña de {web}.",
    "rechazada": "Un administrador rechazó esta conexión en la página web. Si fue un error, empiece de nuevo.",
    "vencida": "El código venció antes de que lo aprobaran. Empiece de nuevo: es rápido.",
    "anulada": "Por seguridad esta conexión se anuló. Empiece de nuevo.",
    "anulada_numero": "Se escribió tres veces un número que no era. Por seguridad el código se anuló. Empiece de nuevo.",
    "cancelada": "La conexión se canceló. Esta computadora no recibió nada. Si fue un error, empiece de nuevo.",
    "fallo": "La computadora fue aprobada, pero no se pudieron guardar los datos (puede faltar espacio en el disco). Toque «Reintentar».",
    "perdida": "No se pudo terminar de conectar. Empiece de nuevo.",
    "otra_empresa": "Esta computadora ya tiene datos de otra empresa. Solo se puede conectar a esa misma empresa.",
    "ya_esta": "Esa empresa ya está en esta computadora: ábrala y use «Conectar con mi cuenta».",            # 4.25 (9b, U5)
    "lista_otra": "Listo. La empresa {empresa} quedó en esta computadora. Para trabajar con ella, elíjala en el menú de su empresa, arriba.",   # 9c (P9)
    # 4.25 (9c, P10): reconexión de la misma empresa empezada CON sesión (quien la hizo ya entró: no se le pide «entrar»)
    "lista_reconexion": ("Listo. Esta computadora quedó conectada de nuevo a {empresa}. Cada persona tiene que entrar una vez con su contraseña, "
                         "con internet, para usar su PIN de nuevo y poder entrar sin internet aquí."),
    # 4.25 (9c, P6): «Conectar otra empresa» aprobada para una empresa sin cédula: no se sabe si ya está aquí; termina cancelado
    "sin_cedula": "Esa empresa no tiene cédula registrada en la página web: complete sus datos allá e inténtelo de nuevo.",
    # 4.25 (9c, P5): número equivocado durante la espera de seguridad (el error va aparte, en «error»)
    "retenida_numero_errado": "La conexión sigue en espera por seguridad: corrija el número de comprobación y escríbalo de nuevo.",
    "sin_internet": "Se fue la conexión a internet. Revise el cable o el wifi; seguimos intentando.",
    "numero_errado": "Ese no es el número que muestra la página web. Revíselo e intente de nuevo.",
    "tope": "Se intentó demasiadas veces. Espere unos minutos e intente de nuevo.",
    # 4.31 (16a): la compañía de esta computadora tiene datos y nunca se conectó (la para el programa antes de pedir el pase; o la web)
    "datos_locales": "Esta empresa tiene datos que no están en la página web. Si la conecta así, se pierden. No la conecte: escriba a soporte para pasarla a la página web.",
}
_conexiones: dict = {}
_conexiones_lock = threading.Lock()
_purgados: dict = {}               # 4.25 (6b, R5): {intento: momento} de los que se purgaron por tiempo SIN terminar
SEGUNDOS_PURGADOS = 3600           # cuánto se recuerda un intento purgado así (solo para el mensaje)
SEGUNDOS_REINTENTO_FALLO = 60      # 4.25 (6b, R5): en «fallo», el hilo y la ruta de estado reintentan como mucho una vez por minuto
MENSAJE_INTENTO_VENCIDO = "No se pudo terminar de conectar: empiece de nuevo."


def _solo_programa() -> None:
    """Las rutas de conexión del PROGRAMA no existen en la web."""
    if not MODO_LOCAL:
        raise HTTPException(404, "Not Found")


def _web() -> str:
    """El nombre de la página web (para los textos): el anfitrión de URL_NUBE, con su puerto cuando lo trae (4.25, 9b: U7)."""
    try:
        u = urlparse(URL_NUBE)
        anfitrion = u.hostname
        if not anfitrion:
            return "la página web"
        if ":" in anfitrion:
            anfitrion = f"[{anfitrion}]"                                   # IPv6
        return f"{anfitrion}:{u.port}" if u.port else anfitrion
    except ValueError:
        return "la página web"


def pagina_web() -> Optional[str]:
    """4.25 (9b, U7): la dirección completa de la página web (URL_NUBE) si es segura; si no, None."""
    url = (URL_NUBE or "").strip().rstrip("/")
    return url if url and _url_nube_segura(url) else None


def _hash_utilizable(h) -> bool:
    """Un hash de contraseña o de PIN con el que se puede entrar (ni vacío ni el inservible)."""
    return bool(h) and h != HASH_INSERVIBLE


def _sin_estrenar(sc) -> bool:
    """E-11: esta computadora está «sin estrenar»: no hay ninguna membresía cuyo usuario tenga un hash de contraseña utilizable, ni se
    abrió nunca una sesión (ni sesiones guardadas ni ingresos en la auditoría, que dura más que las sesiones). Puede haber empresas
    locales vacías o con miembros que todavía no pueden entrar (los que trajo una conexión anterior)."""
    A = _auth
    if sc.exec(select(A.Sesion.id).limit(1)).first() is not None:
        return False
    if sc.exec(select(Auditoria.id).where(Auditoria.accion.in_(("login", "setup_admin"))).limit(1)).first() is not None:
        return False
    for _m, u in sc.exec(select(A.UsuarioEmpresa, A.Usuario).where(A.UsuarioEmpresa.usuario_id == A.Usuario.id)).all():
        if _hash_utilizable(u.password_hash):
            return False
    return True


def _misma_computadora(request) -> bool:
    """La petición sale de esta misma computadora: el socket (request.client.host; local.py arranca el servidor sin proxy_headers, E-14,
    así que ninguna cabecera X-Forwarded-For lo cambia) es 127.0.0.1 o ::1; el Host es 127.0.0.1, localhost o ::1; si viene Origin, es
    el mismo servidor del Host; si viene Sec-Fetch-Site, es same-origin o none. El cliente «testclient» con Host «testserver» vale SOLO
    dentro de las pruebas (VAR_PRUEBAS, como revisar_host_origen)."""
    cliente = (request.client.host if getattr(request, "client", None) else "") or ""
    pruebas = cliente == "testclient" and os.environ.get(VAR_PRUEBAS) == "1"
    if not pruebas and cliente not in ("127.0.0.1", "::1"):
        return False
    esquema = (getattr(getattr(request, "url", None), "scheme", None) or "http")
    host = _servidor(request.headers.get("host") or "", esquema)
    if host is None or host[1] not in (("127.0.0.1", "localhost", "::1") + (("testserver",) if pruebas else ())):
        return False
    origen = request.headers.get("origin")
    if origen is not None and _servidor(origen.strip(), esquema) != host:
        return False
    sitio = request.headers.get("sec-fetch-site")
    if sitio is not None and sitio.strip().lower() not in ("same-origin", "none"):
        return False
    return True


def _quien_conecta(request, authorization, cookie, sc):
    """Quién puede empezar una conexión: en una computadora sin estrenar, cualquiera FRENTE A ELLA (sin sesión: devuelve None); si no,
    una sesión con «configurar» (no un token de API)."""
    if _sin_estrenar(sc):
        if not _misma_computadora(request):
            raise HTTPException(403, {"codigo": "otra_computadora", "mensaje": MENSAJE_OTRA_COMPUTADORA})
        return None
    ctx = contexto(request, authorization, cookie, sc)
    if ctx.token_api is not None:
        raise HTTPException(403, "La conexión la empieza una persona con sesión, no un token")
    ctx.exigir("configurar")
    return ctx


def _llamar_conexion(ruta: str, cuerpo: dict, plazo: float = 60) -> tuple:
    """Una llamada de conexión a la web, SOLO a URL_NUBE (https, o http con FE_SINC_HTTP=1 para pruebas). No usa _post (copia el detalle
    de la respuesta, y un 422 de FastAPI devuelve lo enviado, secreto incluido). Devuelve ("sobre", estado_http, j) si la respuesta trae
    el sobre `servicio: fisitaap-conexion`; ("sin_internet", 0, None) ante un error de red; ("sin_respuesta", estado_http, None) para
    cualquier otra cosa (un portal de wifi, un cortafuegos, una web vieja). Al registro va solo el tipo del error o el número de estado."""
    if not URL_NUBE or not _url_nube_segura(URL_NUBE):
        log.warning("Conexión de esta computadora: la dirección de la web no es segura (FE_NUBE_URL)")
        return ("sin_respuesta", 0, None)
    try:
        r = httpx.post(URL_NUBE.rstrip("/") + ruta, headers={CABECERA_PLAN: str(PROTOCOLO_PLAN)}, json=cuerpo,   # 4.28 (C1): «conectada» trae la empresa
                       timeout=httpx.Timeout(plazo, connect=min(10, plazo)))
    except _ERROR_RED as ex:
        log.info("Conexión de esta computadora: sin respuesta de la web (%s)", type(ex).__name__)
        return ("sin_internet", 0, None)
    except Exception as ex:  # noqa: BLE001
        log.info("Conexión de esta computadora: la web no atendió (%s)", type(ex).__name__)
        return ("sin_respuesta", 0, None)
    estado = int(getattr(r, "status_code", 0) or 0)
    try:
        j = r.json()
    except Exception:  # noqa: BLE001
        j = None
    if isinstance(j, dict) and j.get("servicio") == SERVICIO_CONEXION and isinstance(j.get("estado"), str):
        return ("sobre", estado, j)
    log.info("Conexión de esta computadora: respuesta que no es de la web (%s)", estado)
    return ("sin_respuesta", estado, None)


def _tiene_datos(eid: int) -> tuple:
    """(cfg, comprobantes): la configuración local de la empresa y si tiene algún comprobante."""
    with Session(engine_empresa(eid)) as s:
        return _cfg_local(s, eid), s.exec(select(Documento.id).limit(1)).first() is not None


def _datos_sin_subir(eid: int) -> bool:
    """4.31 (16a): la compañía de esta computadora NUNCA se conectó (su configuración local no tiene terminal anotada) y ya tiene datos
    propios: algún comprobante, cliente o ítem. Si se conecta así, la conexión le pone los datos de la empresa de la web, sus clientes,
    ítems y registros nunca suben (rango 0) y la web da los mismos números: se pierden. Si no se puede leer, True (lo más estricto)."""
    try:
        with Session(engine_empresa(int(eid))) as s:
            if _cfg_local(s, int(eid)).get("terminal"):
                return False
            return any(s.exec(select(m.id).limit(1)).first() is not None for m in (Documento, Cliente, Producto))
    except Exception as ex:  # noqa: BLE001
        log.info("Conexión de esta computadora: no se pudo revisar la empresa %s (%s)", eid, type(ex).__name__)
        return True


def _parar_con_datos_locales(sc, eids: list, usuario=None, request=None) -> None:
    """4.31 (16a): «Conectar con mi cuenta» (y «Tengo un código», salvo en modo soporte) se detiene ANTES de pedir nada a la web si alguna
    de esas empresas tiene datos que nunca subieron (_datos_sin_subir): 409 con el texto. Lo audita."""
    for x in eids:
        if _datos_sin_subir(x):
            try:
                auditar(sc, "sinc_local_conexion_detenida", "No se conectó esta computadora: la empresa tiene datos que no están en la página web", usuario, x, request)
            except Exception as ex:  # noqa: BLE001  la auditoría no cambia la respuesta
                log.info("Conexión de esta computadora: auditoría de la parada (%s)", type(ex).__name__)
            raise HTTPException(409, {"codigo": "datos_locales", "mensaje": MENSAJES_LOCAL["datos_locales"]})


def _vacias(sc) -> list:
    """Empresas locales sin ninguna membresía de alguien que pueda entrar (hash utilizable)."""
    A = _auth
    llenas = {m.empresa_id for m, u in sc.exec(select(A.UsuarioEmpresa, A.Usuario).where(A.UsuarioEmpresa.usuario_id == A.Usuario.id)).all()
              if _hash_utilizable(u.password_hash)}
    return [e for e in sc.exec(select(Empresa).order_by(Empresa.id)).all() if e.id not in llenas]


def _datos_para_conexion(sc, eid: Optional[int]) -> tuple:
    """(cédula, prueba de datos, empresa): lo que manda el programa al iniciar (cédula) y al recoger (terminal_anterior y secuencias) para
    una empresa local que ya tiene datos: terminal anotada, o cédula y algún comprobante (decisión 8). Con sesión, la empresa del
    intento; sin sesión, la primera empresa sin miembros que puedan entrar que tenga esos datos (una conexión que no terminó la vez
    anterior). Sin datos: (None, {}, None)."""
    candidatas = [eid] if eid else [e.id for e in _vacias(sc)]
    for x in candidatas:
        e = sc.get(Empresa, x)
        if e is None:
            continue
        cfg, docs = _tiene_datos(x)
        if cfg.get("terminal") or (_digitos(e.numero_id) and docs):
            with Session(engine_empresa(x)) as s:
                prueba = _prueba_de_datos(s, x, cfg)
            return (_digitos(e.numero_id)[:12] or None), prueba, x
    return None, {}, None


def _purgar_conexiones() -> None:
    """Saca de la memoria los intentos que ya informaron su final (o que pasaron su plazo hace más de SEGUNDOS_INFORME)."""
    ahora = time.time()
    with _conexiones_lock:
        for k, st in list(_conexiones.items()):
            if st["estado"] in FINALES_LOCAL and ahora - (st.get("fin") or ahora) > SEGUNDOS_INFORME:
                _conexiones.pop(k, None)
            elif ahora > st["limite"] + SEGUNDOS_INFORME:
                _conexiones.pop(k, None)
                if st["estado"] not in FINALES_LOCAL:
                    _purgados[k] = ahora                                  # 4.25 (6b, R5): no terminó; la ruta lo dice así (no «se cerró»)
        for k in [k for k, t in _purgados.items() if ahora - t > SEGUNDOS_PURGADOS]:
            _purgados.pop(k, None)


def _terminar(st: dict, estado: str, clave_mensaje: Optional[str] = None) -> None:
    """Estado final: el secreto, el número y la respuesta recogida salen de la memoria."""
    st["estado"], st["fin"] = estado, time.time()
    st["mensaje_clave"] = clave_mensaje or estado
    st["secreto"] = st["numero"] = st["j"] = None


def _en_fondo(fn) -> None:
    """En un hilo (el programa no espera); en las pruebas (sin hilos), en el momento."""
    if HILO_CONEXION:
        threading.Thread(target=fn, daemon=True).start()
    else:
        fn()


def _cancelar_en_nube(secreto: Optional[str]) -> None:
    if secreto:
        _en_fondo(lambda: _llamar_conexion("/api/sinc/conexion/cancelar", {"secreto": secreto}))


def _confirmacion_de(j: dict) -> Optional[dict]:
    """E-4: la empresa (nombre legal, comercial y cédula) y quién aprobó, tal como los manda la web; None si no vienen bien."""
    e, a = j.get("empresa"), j.get("aprobo")
    if not (isinstance(e, dict) and isinstance(a, dict) and isinstance(a.get("correo"), str) and a.get("correo")):
        return None
    return {"empresa": {"nombre": str(e.get("nombre") or "")[:200], "nombre_comercial": str(e.get("nombre_comercial") or "")[:200],
                        "numero_id": str(e.get("numero_id") or "")[:30]},
            "aprobo": {"correo": str(a["correo"])[:254].lower().strip(), "nombre": str(a.get("nombre") or "")[:120]}}


def _de_un_intento() -> set:
    """4.25 (9b, U5): las empresas que tiene tomadas un intento vivo (sin terminar): la que tiene abierta quien conecta y la empresa a la
    que ya le está aplicando su conexión («aplicando» o «fallo», que reintenta solo)."""
    with _conexiones_lock:
        vivos = [st for st in _conexiones.values() if st["estado"] not in FINALES_LOCAL]
    return {int(x) for st in vivos for x in (st.get("eid"), st.get("eid_destino")) if x}


def _huerfanas(sc, ced: str) -> list:
    """4.25 (9b, U5): las empresas de esta computadora con esa cédula que NO cuentan como «ya está» y que «Conectar otra empresa» vuelve a
    usar como destino, porque nadie puede abrirlas para usar «Conectar con mi cuenta»: no tienen ninguna membresía, no están vinculadas,
    no tienen ningún comprobante y ningún intento vivo las tiene tomadas. Es lo que queda cuando «Conectar otra empresa» crea la empresa
    y no llega a vincularla (el intento se cancela con «Empezar de nuevo» o se pierde al cerrar el programa), o cuando la web deshace esa
    primera conexión (E-10: sin membresías ni token, con la terminal anotada). Con comprobantes o con alguna membresía NO: cuenta como que
    ya está. Si la empresa no se puede leer, también (lo más estricto)."""
    if not ced:
        return []
    A = _auth
    tomadas, salida = _de_un_intento(), []
    for e in sc.exec(select(Empresa).order_by(Empresa.id)).all():
        if _digitos(e.numero_id) != ced or e.id in tomadas:
            continue
        if sc.exec(select(A.UsuarioEmpresa.id).where(A.UsuarioEmpresa.empresa_id == e.id).limit(1)).first() is not None:
            continue
        try:
            cfg, docs = _tiene_datos(e.id)
        except Exception as ex:  # noqa: BLE001
            log.info("Conexión de esta computadora: no se pudo leer la empresa %s (%s)", e.id, type(ex).__name__)
            continue
        if not cfg.get("vinculado") and not docs:
            salida.append(e.id)
    return salida


def _empresa_con_cedula(sc, ced: str) -> Optional[int]:
    """4.25 (9b, U5): la empresa de esta computadora con esa cédula (comparada por dígitos), o None. No cuenta la que quedó de un
    intento que no terminó (_huerfanas): esa se vuelve a usar."""
    if not ced:
        return None
    libres = None
    for e in sc.exec(select(Empresa).order_by(Empresa.id)).all():
        if _digitos(e.numero_id) == ced:
            if libres is None:
                libres = set(_huerfanas(sc, ced))
            if e.id not in libres:
                return e.id
    return None


def _cedula_de(conf: dict) -> str:
    """4.25 (9c, P6): la cédula (solo dígitos, hasta 12) de la empresa aprobada; '' si no viene."""
    e = (conf or {}).get("empresa")
    return _digitos((e if isinstance(e, dict) else {}).get("numero_id"))[:12]


def _ya_esta(conf: dict) -> bool:
    """4.25 (9b, U5): «Conectar otra empresa»: la empresa aprobada ya está en esta computadora."""
    with Session(engine) as sc:
        return _empresa_con_cedula(sc, _digitos(((conf or {}).get("empresa") or {}).get("numero_id"))[:12]) is not None


def _otra_empresa(st: dict, conf: dict) -> bool:
    """La empresa local a la que va la conexión ya tiene datos (terminal anotada, o cédula y comprobantes) de OTRA cédula. 4.25 (9b, U5):
    «Conectar otra empresa» no va a ninguna empresa local que ya exista (ver _ya_esta), salvo la que dejó un intento suyo que no terminó
    (_huerfanas: misma cédula)."""
    if st.get("otra"):
        return False
    destino = st.get("eid") or st.get("eid_dato")
    if not destino:
        return False
    with Session(engine) as sc:
        e = sc.get(Empresa, destino)
    if e is None or not _digitos(e.numero_id):
        return False
    cfg, docs = _tiene_datos(destino)
    return bool(cfg.get("terminal") or docs) and _digitos(e.numero_id) != _digitos(conf["empresa"]["numero_id"])


def _vista(st: dict) -> dict:
    """Lo que ve el navegador de un intento. Nunca el secreto, el número, el token ni credenciales."""
    ahora = time.time()
    estado = st["estado"]
    clave = st.get("mensaje_clave") or estado
    salida = {"intento": st["intento"], "estado": estado, "codigo": st["codigo"], "nombre": st["nombre"],
              "segundos": max(0, int(st["vence"] - ahora)), "sin_internet": bool(st.get("sin_internet")),
              "url": st["url"], "web": _web()}
    if st.get("uid") is not None:
        salida["con_sesion"] = True                                      # 4.25 (9c, P10): el intento se empezó con sesión
    if st.get("confirmacion"):
        salida.update(st["confirmacion"])
    if estado in ("confirmar", "retenida"):
        salida["intentos_restantes"] = st.get("intentos_restantes")
        salida["numero_escrito"] = bool(st.get("numero"))
        if st.get("error") == "numero_errado":
            salida["error"] = MENSAJES_LOCAL["numero_errado"]
    if estado == "lista":
        salida["empresa_id"] = st.get("eid_destino")
        salida["otra_empresa"] = bool(st.get("otra"))                    # 4.25 (9b, U5)
        salida["reconexion"] = bool(st.get("reconexion"))                # 4.25 (9b, U9c): la empresa ya había estado conectada aquí
        try:
            with Session(engine_empresa(int(st["eid_destino"]))) as s:
                salida["bajada"] = bool(_cfg_local(s, int(st["eid_destino"])).get("ultima_bajada"))
        except Exception:  # noqa: BLE001
            salida["bajada"] = False
    texto = MENSAJES_LOCAL.get(clave) or MENSAJES_LOCAL.get(estado) or ""
    if estado == "retenida" and st.get("error") == "numero_errado":
        texto = MENSAJES_LOCAL["retenida_numero_errado"]                 # 4.25 (9c, P5): no «Aprobada…» junto al error
    if st.get("sin_internet") and estado not in FINALES_LOCAL:
        texto = MENSAJES_LOCAL["sin_internet"]
    salida["mensaje"] = texto.format(empresa=(st.get("confirmacion") or {}).get("empresa", {}).get("nombre") or "su empresa", web=_web())
    return salida


def _tomar_candado(eid: int) -> None:
    """E-9: el mismo candado que el ciclo de sincronización (_lock y _en_curso[eid]); espera a que el ciclo termine."""
    fin = time.time() + ESPERA_CANDADO
    while True:
        with _lock:
            if not _en_curso.get(eid):
                _en_curso[eid] = True
                _dueno[eid] = threading.get_ident()                       # 4.35: el finally de sincronizar ya no se lo quita
                return
        if time.time() > fin:
            raise TimeoutError("la sincronización no terminó")
        time.sleep(0.2)


def _soltar_candado(eid: int) -> None:
    with _lock:
        _en_curso[eid] = False


def _validar_recogida(j: dict, primera: bool, aprobo: str) -> None:
    """E-12: ANTES de escribir nada: la respuesta trae token, terminal y empresa; en una primera conexión, una lista de usuarios no
    vacía que incluye a quien aprobó. ValueError si no (no se reintenta: la web ya no la vuelve a mandar)."""
    tok = j.get("token")
    if not (isinstance(tok, str) and tok.startswith("fcr_") and len(tok) < 200):
        raise ValueError("token")
    try:
        if int(j.get("terminal")) < 1:
            raise ValueError("terminal")
    except (TypeError, ValueError):
        raise ValueError("terminal")
    if not isinstance(j.get("empresa"), dict):
        raise ValueError("empresa")
    if primera:
        lista = j.get("usuarios")
        if not isinstance(lista, list) or not lista or not all(isinstance(x, dict) for x in lista):
            raise ValueError("usuarios")
        if not aprobo or aprobo not in {str(x.get("correo") or "").lower().strip() for x in lista}:
            raise ValueError("usuarios")


def _empresa_para_conexion(sc, st: dict, j: dict) -> int:
    """(a) La empresa local donde se aplica la conexión: la del intento si se empezó con sesión; si no, una empresa sin miembros que
    puedan entrar con la misma cédula, o la única así sin comprobantes; si no hay, una nueva SIN tipo de negocio (sin mesas, «Caja
    general» ni módulos apagados: el tipo llega después con los datos de la empresa). Un reintento usa la misma."""
    for x in (st.get("eid_destino"), None if st.get("otra") else st.get("eid")):
        if x and sc.get(Empresa, int(x)) is not None:
            return int(x)
    datos = j.get("empresa") or {}
    ced = _digitos(datos.get("numero_id"))
    if st.get("otra"):                                                   # 4.25 (9b, U5): «Conectar otra empresa»: una empresa nueva…
        libres = _huerfanas(sc, ced[:12])                                # …o la que dejó un intento que no terminó (como `misma`, abajo)
        if libres:
            return libres[0]
        e = _auth.crear_empresa(sc, str(datos.get("nombre") or "Empresa")[:200], str(datos.get("correo") or "")[:254], ced[:12])
        return e.id
    vacias = _vacias(sc)
    misma = [e for e in vacias if ced and _digitos(e.numero_id) == ced]
    if misma:
        return misma[0].id
    if len(vacias) == 1:
        cfg, docs = _tiene_datos(vacias[0].id)
        if not docs and not cfg.get("terminal"):
            return vacias[0].id
    e = _auth.crear_empresa(sc, str(datos.get("nombre") or "Empresa")[:200], str(datos.get("correo") or "")[:254], ced[:12])
    return e.id


def _aplicar_usuarios_recogida(sc, eid: int, j: dict) -> list:
    """(c) Los usuarios y roles que trajo la recogida, en una PRIMERA conexión (E-11/E-12): a quien ya existe aquí con un hash utilizable
    solo se le actualizan el rol y el bloqueo (nunca se reemplaza un hash ni un PIN utilizable por el inservible); los demás quedan con
    HASH_INSERVIBLE (entran en línea con su contraseña de la web). Nunca toca a un administrador del sistema de esta computadora. Un
    solo commit al final; las sesiones que haya que cerrar se cierran después. Devuelve los ids de las membresías que creó."""
    A = _auth
    for r in j.get("roles") or []:
        if not isinstance(r, dict) or not r.get("nombre"):
            continue
        fila = sc.exec(select(A.RolEmpresa).where(A.RolEmpresa.empresa_id == eid, A.RolEmpresa.nombre == r.get("nombre"))).first()
        if fila is None:
            fila = A.RolEmpresa(empresa_id=eid, nombre=r.get("nombre"))
        fila.descripcion, fila.permisos = r.get("descripcion"), r.get("permisos") or "[]"
        sc.add(fila)
    creadas, cerrar = [], set()
    for x in j.get("usuarios") or []:
        correo = str(x.get("correo") or "").lower().strip()
        if not correo:
            continue
        u = sc.exec(select(A.Usuario).where(A.Usuario.correo == correo)).first()
        if u is not None and u.es_superadmin:
            continue
        m = sc.exec(select(A.UsuarioEmpresa).where(A.UsuarioEmpresa.usuario_id == u.id, A.UsuarioEmpresa.empresa_id == eid)).first() if u is not None else None
        rol = x.get("rol") or (m.rol if m is not None else "Cajero")
        if u is not None and _hash_utilizable(u.password_hash):          # E-11: ya puede entrar aquí: solo rol y bloqueo
            if bool(x.get("bloqueado")) and not u.bloqueado:
                cerrar.add(u.id)
            u.bloqueado = bool(x.get("bloqueado")); sc.add(u)
            if m is None:
                m = A.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol); sc.add(m); sc.flush(); creadas.append(m.id)
            elif m.rol != rol:
                cerrar.add(u.id); m.rol = rol; sc.add(m)
            continue
        if u is None:
            u = A.Usuario(correo=correo, nombre=x.get("nombre") or correo, password_hash=HASH_INSERVIBLE); sc.add(u); sc.flush()
        u.nombre = x.get("nombre") or u.nombre
        _poner_password(u, HASH_INSERVIBLE)                              # 9b (D-Q): aquí nunca había un hash utilizable (ver arriba)
        u.pin_hash = u.pin_hash if _hash_utilizable(u.pin_hash) else None
        u.bloqueado, u.de_nube, u.debe_cambiar_password = bool(x.get("bloqueado")), True, False
        if "mfa" in x or "temporal" in x:
            u.mfa_nube = str(x.get("mfa") or "") or None
            u.mfa_entrar_nube, u.temporal_nube = bool(x.get("mfa_entrar")), bool(x.get("temporal"))
        if x.get("terminos_version") and u.terminos_version != A.TERMINOS_VERSION:
            u.terminos_version = x["terminos_version"]
            u.terminos_fecha = u.terminos_fecha or datetime.now(timezone.utc)
        u.paleta = x.get("paleta") or u.paleta
        sc.add(u)
        nueva = m is None
        if nueva:
            m = A.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol)
        m.rol, m.sucursal_id, m.modulos_ocultos, m.hash_nube = rol, x.get("sucursal_id"), x.get("modulos_ocultos"), False
        if "mfa" in x or "temporal" in x:
            m.mfa_rrhh_nube = bool(x.get("mfa_rrhh"))
        sc.add(m); sc.flush()
        if nueva:
            creadas.append(m.id)
    sc.commit()
    for uid in cerrar:
        A._revocar_sesiones(sc, uid)
    return creadas


def _aplicar_conexion(st: dict) -> None:
    """Aplica en esta computadora lo que recogió la conexión (st["j"]), en este orden para que un fallo deje la computadora todavía «sin
    estrenar»: validar (E-12), (a) la empresa destino, (b) _aplicar_vinculacion (repetible: reescribe la misma configuración) con la marca
    «primera» (E-10) si la computadora estaba sin estrenar, (c) los usuarios de la recogida (solo en una primera conexión: en una
    reconexión los trae la bajada de usuarios, E-11). Con el candado del ciclo de sincronización (E-9). Si algo falla, el intento queda en
    «fallo» con la respuesta en memoria y el siguiente paso (o «Reintentar») repite sin volver a la web."""
    j = st.get("j")
    if not isinstance(j, dict):
        _terminar(st, "perdida")
        return
    st["estado"] = "aplicando"
    eid = None
    try:
        with Session(engine) as sc:
            if "primera" not in st:
                # 4.25 (9b, U5): «Conectar otra empresa» se aplica exactamente como una PRIMERA conexión de esa empresa
                st["primera"] = True if st.get("otra") else (_sin_estrenar(sc) if st.get("eid") is None else False)
            primera = bool(st["primera"])
            aprobo = str((j.get("aprobo") or {}).get("correo") or "").lower().strip()
            try:
                _validar_recogida(j, primera, aprobo)
            except ValueError as ex:
                log.warning("Conexión de esta computadora: la respuesta de la web no se puede aplicar (%s)", ex)
                auditar(sc, "sinc_local_conexion_fallida", f"La respuesta de la página web no se pudo aplicar ({ex})", None, st.get("eid"), None)
                _terminar(st, "perdida")
                return
            if st.get("otra") and not st.get("eid_destino") and not _cedula_de({"empresa": j.get("empresa")}):
                # 4.25 (9c, P6): la entrega trae la empresa sin cédula: no se crea nada (la instalación que nació en la web no se usa)
                auditar(sc, "sinc_local_conexion_fallida", "La empresa aprobada no tiene cédula en la página web: no se aplicó la conexión", None, st.get("eid"), None)
                _terminar(st, "cancelada", "sin_cedula")
                return
            if st.get("otra") and not st.get("eid_destino") and _ya_esta({"empresa": j.get("empresa")}):
                # 4.25 (9b, U5, lo más estricto): la empresa llegó a esta computadora mientras tanto: no se aplica nada (la instalación
                # que nació en la web nunca usa su token y la web la descarta sola)
                auditar(sc, "sinc_local_conexion_fallida", "La empresa aprobada ya está en esta computadora: no se aplicó la conexión", None, st.get("eid"), None)
                _terminar(st, "ya_esta")
                return
            eid = _empresa_para_conexion(sc, st, j)
            st["eid_destino"] = eid
            _tomar_candado(eid)
            try:
                url = URL_NUBE.rstrip("/")
                with Session(engine_empresa(eid)) as s:
                    cfg_vieja = _cfg_local(s, eid)
                    if "reconexion" not in st:                          # 4.25 (9b, U9c): la empresa ya había estado conectada aquí
                        st["reconexion"] = bool(cfg_vieja.get("terminal")) and not primera
                    e = _aplicar_vinculacion(s, sc, eid, j, url, st["nombre"], cfg_vieja)
                    cfg = _cfg_local(s, eid)
                    cfg["origen"], cfg["aprobo"] = "conexion", aprobo
                    if primera:
                        cfg["primera"] = {"membresias": []}
                    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
                    if primera:
                        ids = _aplicar_usuarios_recogida(sc, eid, j)
                        s.expire_all()
                        cfg = _cfg_local(s, eid)
                        cfg["primera"] = {"membresias": ids}
                        _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
                    _cargar_estado(eid, cfg)
                    terminal = e.terminal
            finally:
                _soltar_candado(eid)
            quien = sc.get(_auth.Usuario, int(st["uid"])) if st.get("uid") else None
            auditar(sc, "sinc_local_vinculada", f"{'Revinculada' if j.get('revinculada') else 'Vinculada'} a {url} como terminal {terminal} · aprobada en la "
                    f"página web por {aprobo}", quien, eid, None, correo=None if quien else aprobo)
            cerrar_cuentas_retiradas(sc)
    except Exception as ex:  # noqa: BLE001
        log.warning("Conexión de esta computadora: no se pudo aplicar (%s)", type(ex).__name__)
        st["estado"], st["fallo_en"] = "fallo", time.time()             # 4.25 (6b, R5): el sondeo no reintenta antes de un minuto
        if not st.get("fallo_auditado"):                                 # una sola fila de auditoría por intento
            try:
                with Session(engine) as sc:
                    auditar(sc, "sinc_local_conexion_fallida", f"La computadora fue aprobada, pero no se pudo guardar la conexión ({type(ex).__name__})", None, eid, None)
                st["fallo_auditado"] = True
            except Exception:  # noqa: BLE001
                pass
        return
    st["confirmacion"] = st.get("confirmacion") or _confirmacion_de(j)
    # 4.25 (9c, P10): una reconexión de la misma empresa empezada con sesión no le pide «entrar» a quien ya tiene la sesión abierta
    reconexion_con_sesion = st.get("uid") is not None and st.get("eid") is not None and bool(st.get("reconexion"))
    _terminar(st, "lista", "lista_otra" if st.get("otra") else ("lista_reconexion" if reconexion_con_sesion else None))
    if HILO_CONEXION:
        threading.Thread(target=sincronizar, args=(eid,), daemon=True).start()      # la primera bajada


def _paso(st: dict, reintentar: bool = False) -> None:
    """Un paso del sondeo (con el candado del intento tomado): pregunta a la web por el pase y actúa según el sobre. Lo que no es el sobre
    («sin respuesta») nunca es una aprobación ni un rechazo: se sigue esperando. 4.25 (6b, R5): en «fallo» el sondeo reintenta como mucho
    una vez por minuto; «Reintentar» (reintentar=True) lo hace en el momento."""
    estado = st["estado"]
    if estado in FINALES_LOCAL:
        return
    if estado == "fallo" and not reintentar and time.time() - float(st.get("fallo_en") or 0) < SEGUNDOS_REINTENTO_FALLO:
        return
    if estado in ("aplicando", "fallo"):
        _aplicar_conexion(st)
        return
    ahora = time.time()
    if ahora > st["limite"]:
        _cancelar_en_nube(st.get("secreto"))
        _terminar(st, "vencida")
        return
    cuerpo = {"secreto": st["secreto"], "version": _version_sistema(), **(st.get("prueba") or {})}
    if st.get("numero"):
        cuerpo.update(numero=st["numero"], confirmar=True)
    tipo, http, j = _llamar_conexion("/api/sinc/conexion/recoger", cuerpo)
    if tipo != "sobre":
        st["sin_internet"] = tipo == "sin_internet"
        return
    st["sin_internet"] = False
    e = j["estado"]
    if e == "tope":
        st["intervalo"] = min(15, int(st.get("intervalo") or INTERVALO_SONDEO) * 2)
        return
    if e == "pendiente":
        return
    if e in ("retenida", "aprobada"):
        conf = _confirmacion_de(j)
        if conf is None:
            return
        if _otra_empresa(st, conf):
            _cancelar_en_nube(st.get("secreto"))
            _terminar(st, "otra_empresa")
            return
        if st.get("otra") and not _cedula_de(conf):
            # 4.25 (9c, P6, lo más estricto): sin cédula no se puede saber si esa empresa ya está en esta computadora: no se crea nada
            _cancelar_en_nube(st.get("secreto"))
            _terminar(st, "cancelada", "sin_cedula")
            return
        if st.get("otra") and _ya_esta(conf):                           # 4.25 (9b, U5): esa empresa ya está aquí: se usa «Conectar con mi cuenta»
            _cancelar_en_nube(st.get("secreto"))
            _terminar(st, "ya_esta")
            return
        st["confirmacion"] = conf
        if isinstance(j.get("intentos_restantes"), int):
            st["intentos_restantes"] = j["intentos_restantes"]
        try:
            seg = max(0, min(int(j.get("segundos") or 0), 3600))
        except (TypeError, ValueError):
            seg = 0
        st["limite"] = max(st["limite"], ahora + seg + SEGUNDOS_GRACIA_CONEXION + (SEGUNDOS_RECOGER if e == "retenida" else 0))
        st["estado"] = "retenida" if e == "retenida" else "confirmar"
        if e == "aprobada" and st.get("numero"):                          # se mandó el número y la web no lo tomó: que lo escriba de nuevo
            st["numero"] = None
        return
    if e == "numero_errado":
        # 4.25 (9b, U6): durante la retención la web lo dice en el momento: sigue «retenida», con el error, y se puede escribir de nuevo
        st["numero"], st["error"] = None, "numero_errado"
        st["estado"] = "retenida" if st["estado"] == "retenida" else "confirmar"
        if isinstance(j.get("intentos_restantes"), int):
            st["intentos_restantes"] = j["intentos_restantes"]
        return
    if e == "conectada":
        if http != 200 or not isinstance(j.get("token"), str):
            _terminar(st, "perdida")
            return
        st["j"], st["numero"], st["error"] = j, None, None
        _aplicar_conexion(st)
        return
    if e == "anulada":
        if j.get("motivo") == "datos_locales":                           # 4.31 (16a): la web la detuvo (trae ventas que la web no tiene)
            _terminar(st, "anulada", "datos_locales")
            return
        _terminar(st, "anulada", "anulada_numero" if st.get("error") == "numero_errado" else "anulada")
        return
    final = {"rechazada": "rechazada", "cancelada": "cancelada", "vencida": "vencida", "entregada": "perdida", "desconocido": "perdida",
             "invalido": "perdida", "repetido": "perdida", "programa_viejo": "perdida"}.get(e)
    if final:
        _terminar(st, final)


def _paso_conexion(intento: str, esperar: bool = False, reintentar: bool = False) -> None:
    """Un paso del intento, con su candado (sin dos pasos a la vez: el hilo y la ruta de estado comparten el intento)."""
    st = _conexiones.get(intento)
    if st is None:
        return
    tomado = st["candado"].acquire(timeout=ESPERA_CANDADO + 60) if esperar else st["candado"].acquire(blocking=False)
    if not tomado:
        return
    try:
        _paso(st, reintentar)
    finally:
        st["ultimo"] = time.time()
        st["candado"].release()


def _esperar_conexion(intento: str) -> None:
    """El hilo de sondeo del PROGRAMA (la pestaña del navegador puede estar oculta): un paso cada `intervalo` hasta un estado final o el
    plazo (vence + SEGUNDOS_GRACIA_CONEXION, más la retención)."""
    while True:
        st = _conexiones.get(intento)
        if st is None or st["estado"] in FINALES_LOCAL or time.time() > st["limite"] + SEGUNDOS_INFORME:
            return
        time.sleep(max(1, int(st.get("intervalo") or INTERVALO_SONDEO)))
        try:
            _paso_conexion(intento)
        except Exception as ex:  # noqa: BLE001
            log.warning("Conexión de esta computadora: sondeo (%s)", type(ex).__name__)


def _intento_de(request, authorization, cookie, sc, intento: str) -> dict:
    """El intento, solo para quien lo empezó: sin sesión, desde esta misma computadora; con sesión, la misma persona en la misma empresa.
    410 «intento_perdido» si no está en memoria (el programa se reinició) o no es de quien pregunta."""
    _purgar_conexiones()
    st = _conexiones.get(str(intento or "")[:64])
    if st is None:
        vencido = str(intento or "")[:64] in _purgados                   # 4.25 (6b, R5): se purgó por tiempo sin terminar (el programa no se cerró)
        raise HTTPException(410, {"codigo": "intento_perdido", "mensaje": MENSAJE_INTENTO_VENCIDO if vencido else MENSAJE_INTENTO_PERDIDO})
    if st.get("eid") is None:
        if not _misma_computadora(request):
            raise HTTPException(403, {"codigo": "otra_computadora", "mensaje": MENSAJE_OTRA_COMPUTADORA})
        return st
    ctx = contexto(request, authorization, cookie, sc)
    if ctx.token_api is not None or ctx.usuario.id != st.get("uid") or ctx.empresa.id != st.get("eid"):
        raise HTTPException(410, {"codigo": "intento_perdido", "mensaje": MENSAJE_INTENTO_PERDIDO})
    return st


def _tope_iniciar_local(registrar: bool) -> None:
    """4.25 (6b, R2): tope de inicios del programa (en memoria). Con registrar=False solo revisa el cupo; el inicio se cuenta cuando la web
    lo aceptó (un intento sin internet no gasta cupo)."""
    try:
        limitar_ip(None, "conexion_local", *TOPE_INICIAR_LOCAL, MENSAJES_LOCAL["tope"], sujeto="programa", registrar=registrar)
    except HTTPException:
        raise HTTPException(429, MENSAJES_LOCAL["tope"])


SEGUNDOS_CANCELAR_VIEJO = 2        # 4.25 (6b, R2): el aviso de cancelación de un intento abandonado no espera más que esto


def _numero_escrito(st: dict) -> bool:
    """4.25 (7b, T5): la persona ya escribió el número de comprobación en este intento (retenido con el número, aplicando, o «fallo»
    después de recibir la conexión): un inicio nuevo sin sesión no lo cancela, lo retoma."""
    return st["estado"] in ("aplicando", "fallo") or (st["estado"] in ("confirmar", "retenida") and bool(st.get("numero")))


def _intento_para_retomar() -> Optional[dict]:
    """4.25 (7b, T5): el intento SIN sesión, sin terminar y con el número ya escrito (el más reciente), o None."""
    with _conexiones_lock:
        con_numero = [st for st in _conexiones.values() if st.get("eid") is None and st["estado"] not in FINALES_LOCAL and _numero_escrito(st)]
    return max(con_numero, key=lambda x: x.get("creado") or 0) if con_numero else None


def _cancelar_anteriores_sin_sesion() -> int:
    """4.25 (6b, R2): al empezar un intento nuevo SIN sesión (solo desde esta misma computadora), los intentos anteriores sin sesión que
    no terminaron se cancelan: aviso de cancelación a la web (en segundo plano y con un plazo corto) y _terminar, en lugar de ocupar cupo
    de MAX_CONEXIONES hasta vencer. No se tocan los intentos con sesión ni uno que se está aplicando en este momento. Devuelve cuántos.
    4.25 (7b, T5): tampoco uno en el que la persona ya escribió el número (_numero_escrito): ese lo retoma «iniciar»."""
    with _conexiones_lock:
        viejos = [st for st in _conexiones.values() if st.get("eid") is None and st["estado"] not in FINALES_LOCAL and not _numero_escrito(st)]
    n = 0
    for st in viejos:
        if not st["candado"].acquire(timeout=SEGUNDOS_CANCELAR_VIEJO):
            continue                                                      # está dando un paso largo: queda como está
        try:
            if st["estado"] in FINALES_LOCAL or _numero_escrito(st):
                continue
            secreto = st.get("secreto")
            if secreto:
                _en_fondo(lambda x=secreto: _llamar_conexion("/api/sinc/conexion/cancelar", {"secreto": x}, plazo=SEGUNDOS_CANCELAR_VIEJO))
            _terminar(st, "cancelada")
            n += 1
        finally:
            st["candado"].release()
    if n:
        log.info("Conexión de esta computadora: se cancelaron %s intento(s) anteriores sin terminar", n)
    return n


class ConexionLocalIn(BaseModel):
    nombre: str = PField(default="", max_length=200)
    otra_empresa: bool = False         # 4.25 (9b, U5): «Conectar otra empresa en esta computadora» (con sesión; no va atado a la empresa abierta)


class IntentoIn(BaseModel):
    intento: str = PField(max_length=64)


class ConfirmarConexionIn(BaseModel):
    intento: str = PField(max_length=64)
    numero: str = PField(default="", max_length=10)
    es_mia: bool = True


@router.post("/local/conexion/iniciar")
def conexion_local_iniciar(request: Request, _p: None = Depends(_solo_programa), cuerpo: Any = Body(default=None),
                           authorization: Optional[str] = Header(default=None), facturacr_token: Optional[str] = Cookie(default=None),
                           sc: Session = Depends(get_session)):
    """PROGRAMA: {nombre}. Sin sesión SOLO si la computadora está sin estrenar y la petición sale de ella misma; si no, sesión con
    «configurar». Pide el pase a la web y devuelve {intento, codigo, segundos, vence, url, web}: la dirección se arma con URL_NUBE, nunca
    con algo de la respuesta. El secreto no sale de la memoria del programa; el número de comprobación lo muestra la PÁGINA (E-1)."""
    # 4.25 (9b, U5): con {otra_empresa: true} es «Conectar otra empresa en esta computadora»: SIEMPRE con sesión y «configurar» (nunca un
    # token), no manda cédula a la web y, al aplicarse, crea una empresa local nueva como en una primera conexión (si esa cédula ya está
    # en esta computadora, se cancela con «ya_esta»). La empresa abierta y la sesión de quien conecta no cambian.
    otra = isinstance(cuerpo, dict) and cuerpo.get("otra_empresa") is True
    if otra:
        ctx = contexto(request, authorization, facturacr_token, sc)
        if ctx.token_api is not None:
            raise HTTPException(403, "La conexión la empieza una persona con sesión, no un token")
        ctx.exigir("configurar")
    else:
        ctx = _quien_conecta(request, authorization, facturacr_token, sc)
    d = _leer_cuerpo(ConexionLocalIn, cuerpo)
    if d is None:
        raise HTTPException(400, "Datos no válidos")
    _purgar_conexiones()
    if ctx is None:
        previo = _intento_para_retomar()                                  # 4.25 (7b, T5): ya escribió el número: no se crea otro pase
        if previo is not None:
            return {**_vista(previo), "retomado": True}
    if not otra:
        # 4.31 (16a): una compañía de esta computadora con datos que nunca subieron no se conecta así (se perderían): con sesión, la
        # empresa abierta; sin sesión, cualquier empresa sin miembros que puedan entrar (la conexión puede caer en ella)
        _parar_con_datos_locales(sc, [ctx.empresa.id] if ctx is not None else [e.id for e in _vacias(sc)],
                                 ctx.usuario if ctx is not None else None, request)
    _tope_iniciar_local(registrar=False)                                  # 4.25 (6b, R2): se revisa aquí y se cuenta solo si la web aceptó
    if ctx is None:
        _cancelar_anteriores_sin_sesion()                                 # 4.25 (6b, R2): los de antes no ocupan cupo hasta vencer
    with _conexiones_lock:
        if len([x for x in _conexiones.values() if x["estado"] not in FINALES_LOCAL]) >= MAX_CONEXIONES:
            raise HTTPException(429, MENSAJES_LOCAL["tope"])
    eid = ctx.empresa.id if ctx is not None else None
    cedula, prueba, eid_dato = (None, {}, None) if otra else _datos_para_conexion(sc, eid)
    secreto = "fcs_" + secrets.token_urlsafe(32)
    nombre = _nombre_computadora(d.nombre)
    tipo, http, j = _llamar_conexion("/api/sinc/conexion/iniciar", {"secreto_hash": _hash(secreto), "nombre": nombre, "cedula": cedula,
                                                                    "version": _version_sistema()})
    if tipo != "sobre":
        raise HTTPException(502, MENSAJE_SIN_WEB.format(web=_web()))
    if j["estado"] == "tope":
        raise HTTPException(429, MENSAJES_LOCAL["tope"])
    if j["estado"] == "programa_viejo":
        raise HTTPException(409, {"codigo": "programa_viejo", "mensaje": MENSAJES_CONEXION["programa_viejo"]})
    codigo = _normalizar_codigo(j.get("codigo"))
    if http != 200 or j["estado"] != "pendiente" or codigo is None:
        raise HTTPException(502, MENSAJE_SIN_WEB.format(web=_web()))
    try:
        _tope_iniciar_local(registrar=True)                               # la web aceptó el inicio: ahora sí cuenta
    except HTTPException:
        _cancelar_en_nube(secreto)                                        # otro inicio ganó el último cupo mientras tanto: este no sigue
        raise
    try:
        segundos = max(60, min(int(j.get("segundos") or MINUTOS_PASE * 60), 3600))
        intervalo = max(2, min(int(j.get("intervalo") or INTERVALO_SONDEO), 15))
    except (TypeError, ValueError):
        segundos, intervalo = MINUTOS_PASE * 60, INTERVALO_SONDEO
    ahora = time.time()
    intento = secrets.token_urlsafe(16)                                   # 128 bits: la llave del intento para la pestaña
    url = URL_NUBE.rstrip("/") + "/app/#/conectar?c=" + codigo
    st = {"intento": intento, "secreto": secreto, "codigo": codigo, "nombre": nombre, "eid": eid, "uid": ctx.usuario.id if ctx is not None else None,
          "eid_dato": eid_dato, "prueba": prueba, "otra": otra, "estado": "esperando", "creado": ahora, "vence": ahora + segundos,
          "limite": ahora + segundos + SEGUNDOS_GRACIA_CONEXION, "ultimo": ahora, "intervalo": intervalo, "url": url, "numero": None, "j": None,
          "candado": threading.Lock()}
    with _conexiones_lock:
        _conexiones[intento] = st
    if HILO_CONEXION:
        threading.Thread(target=_esperar_conexion, args=(intento,), name="conexion-local", daemon=True).start()
    return {"intento": intento, "codigo": codigo, "segundos": segundos,
            "vence": datetime.fromtimestamp(ahora + segundos, timezone.utc).isoformat(timespec="seconds"), "url": url, "web": _web()}


@router.post("/local/conexion/estado")
def conexion_local_estado(data: IntentoIn, request: Request, _p: None = Depends(_solo_programa), authorization: Optional[str] = Header(default=None),
                          facturacr_token: Optional[str] = Cookie(default=None), sc: Session = Depends(get_session)):
    """PROGRAMA: lo que hay en memoria del intento y, si pasaron más de INTERVALO_LOCAL segundos desde el último paso, un paso más (así
    funciona también sin el hilo). Estados: esperando | retenida | confirmar | aplicando | fallo | lista (con bajada) | rechazada |
    vencida | anulada | cancelada | perdida | otra_empresa. 410 «intento_perdido» si el programa se reinició."""
    st = _intento_de(request, authorization, facturacr_token, sc, data.intento)
    if time.time() - st.get("ultimo", 0) >= INTERVALO_LOCAL:
        _paso_conexion(st["intento"])
    return _vista(st)


@router.post("/local/conexion/confirmar")
def conexion_local_confirmar(data: ConfirmarConexionIn, request: Request, _p: None = Depends(_solo_programa),
                             authorization: Optional[str] = Header(default=None), facturacr_token: Optional[str] = Cookie(default=None),
                             sc: Session = Depends(get_session)):
    """PROGRAMA (E-4): la persona vio la empresa, la cédula y quién aprobó. {es_mia: false} cancela el pase en la web y no se crea nada;
    {es_mia: true, numero} manda el número de comprobación que muestra la página (durante la retención queda en memoria hasta que la
    web entregue)."""
    st = _intento_de(request, authorization, facturacr_token, sc, data.intento)
    if not st["candado"].acquire(timeout=ESPERA_CANDADO + 60):
        raise HTTPException(409, "La computadora se está terminando de conectar; espere un momento")
    try:
        if st["estado"] not in ("confirmar", "retenida"):
            return _vista(st)
        if not data.es_mia:
            _cancelar_en_nube(st.get("secreto"))
            _terminar(st, "cancelada")
            return _vista(st)
        numero = _digitos(data.numero)
        if len(numero) != 3:
            raise HTTPException(400, "Escriba las 3 cifras del número de comprobación que muestra la página web")
        st["numero"], st["error"] = numero, None
        _paso(st)                                                         # 4.25 (9b, U6): también en la retención (la web lo revisa ya)
        st["ultimo"] = time.time()
    finally:
        st["candado"].release()
    return _vista(st)


@router.post("/local/conexion/reintentar")
def conexion_local_reintentar(data: IntentoIn, request: Request, _p: None = Depends(_solo_programa),
                              authorization: Optional[str] = Header(default=None), facturacr_token: Optional[str] = Cookie(default=None),
                              sc: Session = Depends(get_session)):
    """PROGRAMA: «Reintentar» tras un fallo a medias: repite la aplicación con la respuesta que ya está en memoria (sin volver a la web)."""
    st = _intento_de(request, authorization, facturacr_token, sc, data.intento)
    if st["estado"] == "fallo":
        _paso_conexion(st["intento"], esperar=True, reintentar=True)   # 4.25 (6b, R5): en el momento (el sondeo, una vez por minuto)
    return _vista(st)


@router.post("/local/conexion/cancelar")
def conexion_local_cancelar(data: IntentoIn, request: Request, _p: None = Depends(_solo_programa),
                            authorization: Optional[str] = Header(default=None), facturacr_token: Optional[str] = Cookie(default=None),
                            sc: Session = Depends(get_session)):
    """PROGRAMA: borra el intento de la memoria y avisa a la web (cancelar) sin esperar su respuesta."""
    try:
        st = _intento_de(request, authorization, facturacr_token, sc, data.intento)
    except HTTPException as ex:
        if ex.status_code == 410:
            return {"ok": True}
        raise
    with _conexiones_lock:
        _conexiones.pop(st["intento"], None)
    if st["estado"] not in FINALES_LOCAL and st["estado"] not in ("aplicando", "fallo"):
        _cancelar_en_nube(st.get("secreto"))
    st["secreto"] = st["numero"] = st["j"] = None
    return {"ok": True}


@router.get("/local/cuentas")
def cuentas_locales(_p: None = Depends(_solo_programa), ctx: Contexto = Depends(requiere("configurar")), sc: Session = Depends(get_session)):
    """PROGRAMA (solo lectura): las cuentas que existen solo en esta computadora (no vienen de la web) de la empresa activa, y los
    administradores del sistema de esta computadora. Ya no pueden entrar (E-13) salvo con FE_LOCAL_ADMIN=1."""
    A = _auth
    filas = []
    for m, u in sc.exec(select(A.UsuarioEmpresa, A.Usuario).where(A.UsuarioEmpresa.empresa_id == ctx.empresa.id, A.UsuarioEmpresa.usuario_id == A.Usuario.id)).all():
        if not u.de_nube and not u.es_superadmin:
            filas.append({"correo": u.correo, "nombre": u.nombre, "rol": m.rol, "admin_sistema": False})
    for u in sc.exec(select(A.Usuario).where(A.Usuario.es_superadmin == True)).all():  # noqa: E712
        filas.append({"correo": u.correo, "nombre": u.nombre, "rol": None, "admin_sistema": True})
    return {"cuentas": filas, "retiradas": A._local_cerrado()}


def _cfgs_empresas() -> list:
    """[(eid, cfg)] de todas las empresas de esta computadora en UNA pasada (las que no se pueden leer no cuentan)."""
    salida = []
    try:
        with Session(engine) as sc:
            eids = [e.id for e in sc.exec(select(Empresa)).all()]
    except Exception as ex:  # noqa: BLE001
        log.info("Programa: no se pudieron leer las empresas (%s)", type(ex).__name__)
        return salida
    for eid in eids:
        try:
            with Session(engine_empresa(eid)) as s:
                salida.append((eid, _cfg_local(s, eid)))
        except Exception as ex:  # noqa: BLE001
            log.info("Programa: la configuración de la empresa %s no se pudo leer (%s)", eid, type(ex).__name__)
    return salida


def resumen_ingreso(sc, request, cfgs: Optional[list] = None) -> dict:
    """Bloque `local` de GET /api/auth/estado en el programa: nueva (sin estrenar), vinculada (alguna empresa vinculada), admin_local
    (FE_LOCAL_ADMIN=1: modo soporte), web (anfitrión de URL_NUBE, para los textos) y equipo (nombre de Windows, solo a la misma
    computadora). 4.25 (9b, U7): web con el puerto cuando lo hay, y pagina (la dirección completa de la página web, URL_NUBE, solo si es
    segura) para «¿Olvidó su contraseña?» y los enlaces cuando todavía no hay pagina_web."""
    cfgs = _cfgs_empresas() if cfgs is None else cfgs
    equipo = None
    if _misma_computadora(request):
        try:
            equipo = (socket.gethostname() or "")[:60] or None
        except Exception:  # noqa: BLE001
            equipo = None
    return {"nueva": _sin_estrenar(sc), "vinculada": any(cfg.get("vinculado") for _e, cfg in cfgs),
            "admin_local": os.environ.get("FE_LOCAL_ADMIN") == "1", "web": _web(), "pagina": pagina_web(), "equipo": equipo}


_VINC_ALGUNA: dict = {}               # {eid: (valor, momento)}: «vinculada alguna vez» (un True no cambia; un False se vuelve a leer a los 30 s)


def vinculada_alguna_vez(eid: int) -> Optional[bool]:
    """E-13: la empresa se vinculó alguna vez en esta computadora: su configuración guardada tiene terminal anotada (no se mira el
    diccionario en memoria _fijas: si la carga de una empresa falló al arrancar, quedaría vacío).
    4.25 (6b, R3): tres respuestas. True (la terminal anotada se leyó de verdad), False (se leyó y no hay) y None («no se sabe»: la base
    no se pudo abrir o el registro guardado no se pudo interpretar). «No se sabe» no es «retirada»: quien pregunta no deja pasar la
    petición pero no revoca nada; y no se guarda en la memoria (se vuelve a leer en la próxima)."""
    v, t = _VINC_ALGUNA.get(int(eid), (None, 0.0))
    if v is True or (v is False and time.time() - t < 30):
        return v
    try:
        with Session(engine_empresa(int(eid))) as s:
            r = modulos._registro(s, int(eid), CLAVE_LOCAL)
            if r is None:
                v = False
            else:
                datos = json.loads(r.datos) if not r.coleccion else None
                if not isinstance(datos, dict):
                    return None
                v = bool(datos.get("terminal"))
    except Exception as ex:  # noqa: BLE001
        log.info("Programa: no se pudo saber si la empresa %s se vinculó (%s)", eid, type(ex).__name__)
        return None
    _VINC_ALGUNA[int(eid)] = (v, time.time())
    return v


def hay_vinculada() -> Optional[bool]:
    """E-13: alguna empresa de esta computadora se vinculó alguna vez. 4.25 (6b, R3): True si alguna se leyó vinculada; None si ninguna
    lo está pero alguna (o la lista de empresas) no se pudo leer; False si se leyeron todas y ninguna."""
    try:
        with Session(engine) as sc:
            eids = [e.id for e in sc.exec(select(Empresa)).all()]
    except Exception as ex:  # noqa: BLE001
        log.info("Programa: no se pudieron leer las empresas (%s)", type(ex).__name__)
        return None
    duda = False
    for eid in eids:
        v = vinculada_alguna_vez(eid)
        if v is True:
            return True
        duda = duda or v is None
    return None if duda else False


def cerrar_cuentas_retiradas(sc) -> int:
    """E-13: cierra las sesiones y revoca los tokens de API de las cuentas creadas en esta computadora que ya no entran (al vincular y
    al arrancar el programa). Sin efecto fuera del programa o con FE_LOCAL_ADMIN=1. Devuelve cuántas cuentas cerró."""
    A = _auth
    if not A._local_cerrado():
        return 0
    n = 0
    for u in sc.exec(select(A.Usuario).where(A.Usuario.de_nube == False)).all():  # noqa: E712
        if A._cuenta_local_retirada(sc, u) is True:                      # 4.25 (6b, R3): «no se sabe» no cierra nada
            vivas = sc.exec(select(A.Sesion.id).where(A.Sesion.usuario_id == u.id, A.Sesion.revocada == False).limit(1)).first()  # noqa: E712
            tokens = A._revocar_tokens_api(sc, u.id)
            if vivas is not None:
                A._revocar_sesiones(sc, u.id)
            if vivas is not None or tokens:
                n += 1
    return n


def _quitar_primera(eid: int) -> None:
    """E-10: la marca «primera» se quita en el primer ingreso (y en la primera bajada buena, dentro de sincronizar)."""
    try:
        with Session(engine_empresa(int(eid))) as s:
            cfg = _cfg_local(s, int(eid))
            if "primera" in cfg:
                cfg.pop("primera", None)
                _escribir(s, int(eid), CLAVE_LOCAL, cfg); s.commit()
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc empresa %s: no se pudo quitar la marca de primera conexión (%s)", eid, type(ex).__name__)


def _deshacer_conexion(s, sc, eid: int, cfg: dict) -> bool:
    """E-10: la web revocó o descartó una PRIMERA conexión (marca «primera») antes de su primera bajada buena y antes de que alguien
    entrara: se quitan SOLO las membresías que creó esa conexión (los ids de la marca), la configuración queda desvinculada (sin token,
    conservando la terminal) y la computadora vuelve a poder conectarse. Quien llama ya comprobó que el token es el de la llamada (E-9).
    Sin la marca: False (rige el camino de siempre: aviso y 3 días)."""
    marca = cfg.get("primera")
    if not isinstance(marca, dict):
        return False
    A = _auth
    ids = [int(x) for x in (marca.get("membresias") or []) if isinstance(x, int) and not isinstance(x, bool)]
    for mid in ids:                     # nadie entró todavía (el primer ingreso quita la marca): no hay sesiones que cerrar por esto
        m = sc.get(A.UsuarioEmpresa, mid)
        if m is not None and m.empresa_id == eid:
            sc.delete(m)
    sc.commit()
    for k in ("primera", "revocada_en", "revocacion_explicita", "bloqueada_en", "sin_acceso_desde", "sin_acceso_motivo"):
        cfg.pop(k, None)
    cfg.update({"vinculado": False, "token": None})
    cfg["ultimo_error"] = f"{_ahora()[:19]} La página web descartó esta conexión antes de terminar: conecte la computadora de nuevo."
    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
    _cargar_estado(eid, cfg)
    auditar(sc, "sinc_local_conexion_deshecha", f"La página web revocó la conexión antes de la primera bajada: se quitaron las {len(ids)} membresía(s) que "
            "trajo y la computadora puede conectarse de nuevo", None, eid, None)
    log.warning("sinc empresa %s: conexión deshecha (revocada antes de la primera bajada)", eid)
    return True


MENSAJE_CONEXION_DESCARTADA = "La página web descartó esta conexión porque no se terminó a tiempo. Conecte la computadora de nuevo."


def _desvincular_descartada(s, sc, eid: int, cfg: dict) -> None:
    """4.25 (D-O): la web descartó SOLA esta conexión (señal de revocación con motivo «sin_estrenar»: no usó su token nuevo a tiempo). No es
    una revocación: la empresa queda desvinculada (sin token) SIN revocada_en, revocacion_explicita ni cuenta de bloqueo; se conservan la
    terminal, las membresías y los datos, y la computadora se puede conectar de nuevo. Quien llama ya comprobó el token (E-9) y la marca
    «primera» (E-10)."""
    for k in ("revocada_en", "revocacion_explicita", "bloqueada_en", "sin_acceso_desde", "sin_acceso_motivo"):
        cfg.pop(k, None)
    cfg.update({"vinculado": False, "token": None})
    cfg["ultimo_error"] = MENSAJE_CONEXION_DESCARTADA
    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
    _cargar_estado(eid, cfg)
    auditar(sc, "sinc_local_conexion_descartada", "La página web descartó la conexión de esta computadora porque no se terminó a tiempo (no es una "
            "revocación): quedó desvinculada, con sus datos, y se puede conectar de nuevo", None, eid, None)
    log.warning("sinc empresa %s: la web descartó la conexión (no se terminó a tiempo): queda desvinculada", eid)


def _conexion_descartada(cfg: dict) -> bool:
    """4.25 (D-O): la web descartó sola la conexión de esta computadora (_desvincular_descartada) y nadie la conectó de nuevo: no sube ni
    baja nada. Lo avisan la franja de la aplicación y Configuración › Instalación local. Vincular de nuevo limpia ultimo_error; una
    desvinculación hecha por una persona no deja ese texto."""
    return not cfg.get("vinculado") and cfg.get("ultimo_error") == MENSAJE_CONEXION_DESCARTADA


_en_curso: dict[int, bool] = {}
_lock = threading.Lock()
# 4.35: el hilo que tomó _en_curso por última vez (sincronizar, subida_final_vieja, _tomar_candado). sincronizar suelta el candado antes de
# armar su respuesta (_estado_local) y su finally lo volvía a poner en False: si en ese rato lo tomó quien espera (con pasos de 0,2 s), se lo
# quitaba a media subida. Ahora ese finally solo lo suelta si sigue siendo de su hilo.
_dueno: dict[int, int] = {}


def _codigo_nube(r) -> Optional[str]:
    """detail.codigo de una respuesta de la nube ({codigo, mensaje}), si lo trae."""
    try:
        det = r.json().get("detail")
    except Exception:  # noqa: BLE001
        return None
    return str(det.get("codigo") or "") if isinstance(det, dict) else None


def _motivo_nube(r) -> Optional[str]:
    """4.25 (D-O): detail.motivo de la señal de revocación, si lo trae (solo se reconoce «sin_estrenar»)."""
    try:
        det = r.json().get("detail")
    except Exception:  # noqa: BLE001
        return None
    return MOTIVO_SIN_ESTRENAR if isinstance(det, dict) and det.get("motivo") == MOTIVO_SIN_ESTRENAR else None


def _revisar_respuesta(r, ruta: str) -> None:
    """4.9 (5a): solo la señal explícita de la nube (4xx con detail.codigo «instalacion_revocada») es revocación; cualquier otro
    401/403 es «sin acceso a la nube» (se avisa y se reintenta; nunca se bloquea ni se borra nada)."""
    if 400 <= r.status_code < 500 and _codigo_nube(r) == CODIGO_REVOCADA:
        raise Revocada(_detalle(r), motivo=_motivo_nube(r))
    if r.status_code in (401, 403):
        raise SinAcceso(f"respondió {r.status_code} en {ruta}: {_detalle(r)}")


def _post(url, cab, ruta, cuerpo, timeout=TIEMPO):
    r = httpx.post(url + ruta, headers=cab, json=cuerpo, timeout=timeout)
    _revisar_respuesta(r, ruta)
    if r.status_code != 200:
        try:
            det = r.json().get("detail")
        except Exception:  # noqa: BLE001
            det = r.text[:200]
        raise RuntimeError(f"la nube respondió {r.status_code} en {ruta}: {det}")
    return r.json()


def _subir_catalogos(s, eid, cfg, url, cab, rango, fotos: Optional[dict] = None) -> int:
    """Clientes e ítems creados en la instalación (ids de su rango) que cambiaron desde la última subida; con la lista de los
    que siguen vivos, para que la nube desactive los borrados. 4.32 (revisión n.º 32): con `fotos` ({}), deja ahí lo que leyó y subió
    ({"clientes"/"productos": {id: fila}}) para que sinc_datos_programa._probar encole lo que cambió mientras subía."""
    huellas = cfg.setdefault("huellas", {})
    cuerpo, nuevas = {"terminal": rango, "version": _version_sistema()}, {}
    hay = False
    canal = {c for t, c in (("cliente", "clientes"), ("producto", "productos")) if _canal().por_canal(eid, t)}
    for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
        h = huellas.get(clave) or {}
        if clave in canal:                                             # 4.32: con el protocolo 2 viaja por /api/sinc/datos (salvo la última subida, plan §2.8)
            nuevas[clave] = h
            continue
        filas = [o for o in s.exec(select(modelo)).all() if en_rango(o.id, rango)]
        cambiados, nuevas[clave] = [], {}
        for o in filas:
            d = o.model_dump(); hu = _huella(d)
            nuevas[clave][str(o.id)] = hu
            if fotos is not None:
                fotos.setdefault(clave, {})[str(o.id)] = d
            if h.get(str(o.id)) != hu:
                cambiados.append(d)
        if cambiados or set(h) - set(nuevas[clave]):
            hay = True
        cuerpo[clave] = cambiados
        cuerpo[clave + "_vivos"] = [o.id for o in filas]
    if not hay:
        return 0
    j = _post(url, cab, "/api/sinc/cambios", cuerpo)
    fallidas = {x.get("parte") for x in j.get("errores") or []}
    n = 0
    for clave in ("clientes", "productos"):
        if clave not in fallidas:
            huellas[clave] = nuevas[clave]; n += int(j.get(clave) or 0)
    if fallidas:
        raise RuntimeError("; ".join(f"{x.get('parte')}: {x.get('error')}" for x in j.get("errores") or []))
    return n


# 4.35 (arnés S12, exe 4.34): la última subida vieja ya no se rinde al instante si el ciclo de sincronización (sincronizar, cada 15 s) tiene el
# candado: lo espera hasta este plazo, con pasos de 0,2 s. Antes, _probar reintentaba a los 15 s y quedaba en fase con ese ciclo (los dos con el
# mismo período): «no se pudo hacer» una y otra vez y nunca pasaba al canal nuevo. Plazo CORTO: el hilo sinc-datos atiende a todas las
# empresas una por una y, mientras espera, las demás (pedidos web, ops de la caja) no avanzan; si se vence, _probar vuelve a probar a los 2 s
# sin volver a preguntarle a la web (RECORDAR_CANAL), y eso ya rompe la fase con el ciclo viejo.
ESPERA_SUBIDA_FINAL = 2
_subida_final_ocupada: set = set()   # 4.35: empresas cuya última subida vieja se rindió porque otro ciclo tuvo el candado más que el plazo


def subida_final_ocupada(eid: int) -> bool:
    """4.35: ¿la última subida_final_vieja de esta empresa devolvió False porque otro ciclo tuvo el candado más que ESPERA_SUBIDA_FINAL? Lo lee
    (y lo borra) sinc_datos_programa._probar para volver a probar pronto en vez de a los 15 s."""
    with _lock:
        ocupada = eid in _subida_final_ocupada
        _subida_final_ocupada.discard(eid)
        return ocupada


def subida_final_vieja(eid: int, fotos: Optional[dict] = None) -> bool:
    """4.32 (plan §2.8, paso 1 de la carga inicial): una última subida de clientes e ítems propios por el camino de siempre (/api/sinc/cambios),
    justo antes de pasar al protocolo 2, para que lo propio pendiente salga como siempre. True si subió (o no había nada). False si no se pudo
    (sin conexión, la web lo rechazó, sin conectar, o 4.35: otro ciclo siguió con el candado más que ESPERA_SUBIDA_FINAL, y entonces
    subida_final_ocupada(eid) da True): el canal nuevo vuelve a probar después. Ni el token ni el detalle de la respuesta van al registro.
    4.35: la llama solo sinc_datos_programa._probar, en el hilo sinc-datos, que nunca tiene este candado (_en_curso) tomado: la espera no puede
    ser contra sí mismo. Mientras espera no tiene el candado ni una sesión de base abierta: si el programa se cierra en ese rato no queda nada
    tomado."""
    fin = time.monotonic() + ESPERA_SUBIDA_FINAL                      # monotonic: un cambio de hora del equipo no alarga ni corta la espera
    with _lock:
        _subida_final_ocupada.discard(eid)
    while True:
        with _lock:
            if not _en_curso.get(eid):
                _en_curso[eid] = True
                _dueno[eid] = threading.get_ident()                       # 4.35: el finally de sincronizar ya no se lo quita
                break
        if time.monotonic() >= fin:
            with _lock:
                _subida_final_ocupada.add(eid)
            log.info("sinc empresa %s: la última subida por el camino anterior esperó %s s a que terminara otro ciclo de sincronización", eid,
                     ESPERA_SUBIDA_FINAL)
            return False
        time.sleep(0.2)
    try:
        with Session(engine_empresa(eid)) as s, Session(engine) as sc:
            cfg = _cfg_local(s, eid)
            inicial = json.loads(json.dumps(cfg, default=str))
            e = sc.get(Empresa, eid)
            rango = int(cfg.get("terminal") or 0)
            if e is None or e.bloqueada or cfg.get("revocada_en") or rango < 1 or not (cfg.get("vinculado") and cfg.get("token") and cfg.get("url")):
                return False
            cab = {"Authorization": "Bearer " + secretos.descifrar(e.clave_cifrada, cfg["token"])}
            if _valida_en_linea(cfg):
                cab[CABECERA_INGRESO] = str(PROTOCOLO_INGRESO)
            try:
                n = _subir_catalogos(s, eid, cfg, cfg["url"], cab, rango, fotos=fotos)
            except Exception as ex:  # noqa: BLE001
                s.rollback()
                log.warning("sinc empresa %s: última subida de clientes e ítems por el camino anterior (%s)", eid, type(ex).__name__)
                return False
            if n:
                sub = _subidos(cfg)
                sub["clientes"] += n
                cfg["subidos"] = sub
            _guardar_cfg(s, eid, cfg, inicial)
            return True
    finally:
        _en_curso[eid] = False


def _parse(iso: str | None):
    if not iso:
        return None
    try:
        d = datetime.fromisoformat(iso)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _subir_registros(s, eid, cfg, url, cab, rango) -> int:
    """Registros operativos: los elementos del rango propio que cambiaron desde la última subida (más los que la nube pidió
    reintentar) y la lista de ids vivos de cada registro, para que la nube borre los que ya no están."""
    desde = _parse(cfg.get("registros_desde"))
    if desde:
        desde -= timedelta(seconds=2)
    corte = datetime.now(timezone.utc)
    reint = {k: list(v) for k, v in (cfg.get("reintentos") or {}).items()}
    de_red = (_leer(s, eid, CLAVE_RED_RECIBIDO, {}).get("pendientes") or {})      # elementos propios que otra computadora editó
    for k, ids in de_red.items():
        reint[k] = list(reint.get(k) or []) + [int(i) for i in ids]
    subidas = cfg.setdefault("registros_subidos", {})
    regs, claves_doc = {}, {}
    for clave in CLAVES_OPERATIVAS:
        r = modulos._registro(s, eid, clave)
        if not r or not r.coleccion:
            continue
        filas = [f for f in s.exec(select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == eid, modulos.RegistroItem.clave == clave)).all()
                 if en_rango(f.item_id, rango)]
        if not filas and not subidas.get(clave):
            continue                                  # nunca tuvo nada propio
        items = []
        for f in filas:
            act = f.actualizado
            if isinstance(act, datetime) and act.tzinfo is None:
                act = act.replace(tzinfo=timezone.utc)
            if desde is None or not isinstance(act, datetime) or act >= desde or f.item_id in (reint.get(clave) or []):
                try:
                    items.append(json.loads(f.datos))
                except ValueError:
                    continue
        for x in items:
            for campo in CAMPOS_REF_DOC:
                if x.get(campo):
                    claves_doc[str(x[campo])] = None
        regs[clave] = {"items": items, "vivos": [f.item_id for f in filas]}
    if not regs:
        return 0
    for lid in list(claves_doc):
        d = s.get(Documento, int(lid)) if str(lid).isdigit() else None
        claves_doc[lid] = d.clave if d else None
    j = _post(url, cab, "/api/sinc/cambios", {"terminal": rango, "version": _version_sistema(), "registros": regs, "claves_doc": claves_doc})
    n, reintentos, errores = 0, {}, []
    for clave, res in (j.get("registros") or {}).items():
        if not isinstance(res, dict):
            continue
        if res.get("error"):
            errores.append(f"{clave}: {res['error']}")
            reintentos[clave] = [x.get("id") for x in regs.get(clave, {}).get("items", []) if isinstance(x, dict)]
            continue
        subidas[clave] = True
        n += int(res.get("altas", 0)) + int(res.get("cambios", 0)) + int(res.get("bajas", 0))
        if res.get("rechazados"):
            reintentos[clave] = [i for i in res["rechazados"] if i is not None]
    cfg["reintentos"] = reintentos
    cfg["registros_desde"] = corte.isoformat(timespec="seconds")
    if de_red:
        _quitar_pendientes_red(s, eid, {k: v for k, v in de_red.items() if k not in reintentos})
    if errores:
        raise RuntimeError("; ".join(errores))
    return n


def _pago_a_dict(s, p) -> dict:
    d = {k: getattr(p, k, None) for k in CAMPOS_PAGO}
    d["id"], d["numero"], d["sello"] = p.id, p.numero, diario.sello(p)
    facturas = []
    for f in json.loads(p.facturas or "[]"):
        doc = s.get(Documento, int(f.get("id") or 0)) if f.get("id") else None
        facturas.append({**f, "clave": doc.clave if doc else None})
    d["facturas"], d["documentos"] = facturas, json.loads(p.documentos or "[]")
    return d


def _subir_pagos(s, eid, cfg, url, cab, rango) -> int:
    """Cobros registrados en la instalación que no han subido, con sus comprobantes por clave, y (etapa 2a) las bajas hechas aquí."""
    pend = s.exec(select(modulos.Pago).where(modulos.Pago.sinc_en == None)).all()  # noqa: E711
    bajas = s.exec(select(SincDiario).where(SincDiario.tipo == "pago", SincDiario.borrado == True, SincDiario.origen == rango,  # noqa: E712
                                            SincDiario.id > int(cfg.get("cursor_bajas") or 0)).order_by(SincDiario.id)).all()
    if not pend and not bajas:
        return 0
    lista = [_pago_a_dict(s, p) for p in pend]
    j = _post(url, cab, "/api/sinc/cambios", {"terminal": rango, "version": _version_sistema(), "pagos": lista, "pagos_borrados": [b.ref for b in bajas]})
    if bajas and not any(x.get("parte") == "pagos_borrados" for x in j.get("errores") or []):
        cfg["cursor_bajas"] = bajas[-1].id
    ok = {int(i) for i in j.get("pagos") or []}
    n = int(j.get("pagos_borrados") or 0)
    for p in pend:
        if p.id in ok:
            p.sinc_en = _ahora(); s.add(p); n += 1
    s.commit()
    errs = [x for x in j.get("errores") or [] if x.get("parte") in ("pagos", "pagos_borrados")]
    if errs:
        raise RuntimeError("; ".join(f"cobro {x.get('id')}: {x.get('error')}" for x in errs))
    return n


def _bodega_del_documento(s, did: int):
    """4.9 (F1): la bodega de la que salió (o entró) la mercadería de este comprobante: la del primer movimiento. Sin ella, quien lo
    recibe rebajaba la bodega principal y _bajar_existencias le deshacía la venta a la bodega de la caja o de la sucursal."""
    mov = s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.documento_id == did).order_by(inventario.MovimientoInventario.id)).first()
    return mov.bodega_id if mov else None


def _huerfanos_red(s, eid: int) -> list:
    """4.9 (F2): copias ya finales (interno, aceptado…) recibidas por la red local de una computadora sin contacto desde hace
    HORAS_RETOMAR: esa computadora ya no las va a subir, así que las sube esta (una sola vez: ultimo_intento queda marcado)."""
    from . import cola
    limite = (datetime.now(timezone.utc) - timedelta(hours=cola.HORAS_RETOMAR)).isoformat(timespec="seconds")
    docs = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.origen_sinc != None, Documento.origen_sinc != "", Documento.origen_sinc != ORIGEN_NUBE, Documento.estado.notin_(("firmado", "enviado")),  # noqa: E711
                                          Documento.sinc_estado == Documento.estado, Documento.ultimo_intento == None, Documento.sinc_en < limite)).all()  # noqa: E711
    if not docs:
        return []
    terminales, nombres = computadoras_vivas(s, eid, limite)
    return [d for d in docs if cola._terminal_de(d) not in terminales and str(d.origen_sinc or "")[:40] not in nombres]


def _doc_a_dict(s, d, con_xml: bool = True) -> dict:
    """Un comprobante listo para viajar (etapa 2a: en los dos sentidos)."""
    j_ = lambda v: v.isoformat(timespec="seconds") if isinstance(v, datetime) else v  # noqa: E731
    dd = {k: j_(getattr(d, k, None)) for k in CAMPOS_DOC}
    dd["correo_enviado"] = d.correo_enviado
    dd["lineas"] = [{k: getattr(l, k, None) for k in CAMPOS_LINEA} for l in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == d.id)).all()]
    dd["bodega_id"] = _bodega_del_documento(s, d.id)                   # 4.9 (F1): la bodega de la que salió
    if getattr(d, "pedido_id", None):
        dd["pedido"] = {"id": int(d.pedido_id), "parcial": bool(d.pedido_parcial)}   # 4.32 (§4.5): el pedido en línea que cobró (llave aparte, no en CAMPOS_DOC)
    if d.cliente_id:
        cl = s.get(Cliente, d.cliente_id)
        dd["cliente_numero_id"] = cl.numero_id if cl else None
    if con_xml and d.xml_nombre and (XML_DIR / d.xml_nombre).exists():
        dd["xml_b64"] = base64.b64encode((XML_DIR / d.xml_nombre).read_bytes()).decode()
    if con_xml and d.respuesta_nombre and (XML_DIR / d.respuesta_nombre).exists():
        dd["respuesta_b64"] = base64.b64encode((XML_DIR / d.respuesta_nombre).read_bytes()).decode()
    return dd


def _subir_documentos(s, eid, cfg, url, cab) -> int:
    pend = s.exec(select(Documento).where((Documento.sinc_en == None) | (Documento.sinc_estado != Documento.estado))).all()  # noqa: E711
    huerfanos = _huerfanos_red(s, eid)                                 # 4.9 (F2)
    pend = list(pend) + [d for d in huerfanos if d not in pend]
    espera = _canal().documentos_en_espera(s, eid, pend)               # 4.32 (plan §2.7 y §5.3 paso 2): con un alta todavía sin veredicto, a la vuelta siguiente
    if espera:
        pend = [d for d in pend if d.id not in espera]
    subidos = 0
    for i in range(0, len(pend), 50):
        lote = pend[i:i + 50]
        docs = []
        for d in lote:
            dd = _doc_a_dict(s, d)
            # 4.12: la nube solo manda el correo de lo aceptado que nadie ha enviado y se emitió desde la vinculación (no el historial viejo)
            dd["pedir_correo"] = d.estado == "aceptado" and not d.correo_enviado and str(d.fecha_emision or "")[:10] >= str(cfg.get("vinculada_en") or "")[:10]
            docs.append(dd)
        j = _post(url, cab, "/api/sinc/documentos", {"terminal": cfg.get("nombre") or f"terminal {cfg.get('terminal')}", "version": _version_sistema(), "documentos": docs})
        ok = set(j.get("recibidos") or [])
        for d in lote:
            if d.clave in ok:
                d.sinc_en = _ahora(); d.sinc_estado = d.estado; subidos += 1
                if d in huerfanos:
                    d.ultimo_intento = _ahora()                         # 4.9 (F2): ya se subió: no se vuelve a tomar
                s.add(d)
        s.commit()
    return subidos


def _sin_subir(s, eid: int) -> set:
    """4.9 (E6): ítems (y los ingredientes de sus recetas) de comprobantes que mueven inventario (ventas, notas de crédito y, 4.9 R1,
    compras 08; de producción o internos) cuyo estado actual la nube todavía no tiene: nuevos sin subir o con un cambio de estado sin
    subir (la reversión de un rechazo o de una anulación hecha aquí; sinc_estado «interno»: el que se anuló ya no está en ese estado)."""
    ids = {int(x) for x in s.exec(select(DocumentoLinea.producto_id).join(Documento, Documento.id == DocumentoLinea.documento_id).where(
        (Documento.sinc_en == None) | (Documento.sinc_estado != Documento.estado),  # noqa: E711
        Documento.tipo_documento.in_(VENTAS + ("03", "08")),
        (Documento.ambiente == "produccion") | (Documento.estado == "interno") | (Documento.sinc_estado == "interno"),
        DocumentoLinea.producto_id != None)).all() if x}  # noqa: E711
    if ids:
        recs, pila = inventario.recetas(s, eid), list(ids)
        while pila:
            for ing in (recs.get(pila.pop()) or {}).get("ingredientes") or []:
                i = modulos._id_entero(ing.get("producto_id")) if isinstance(ing, dict) else None
                if i and i not in ids:
                    ids.add(i); pila.append(i)
    return ids


def _bajar_existencias(s, eid, j: dict, rango) -> int:
    """Las existencias de la instalación quedan iguales a las de la nube (que ya rebajó lo que esta instalación subió): la
    diferencia se registra como ajuste. Un ítem propio que la nube todavía no tiene conserva su existencia local.
    4.9: tampoco se igualan (E2) los ítems que la nube no conoce (p. ej. creados aquí mientras estuvo desvinculada: quedaban en 0) ni
    (E6) los de un comprobante cuyo estado actual la nube todavía no tiene (_sin_subir): igualarlos deshacía aquí una venta nueva o
    la reversión de un rechazo; se igualan en la bajada siguiente, ya subido."""
    bodegas, existencias = j.get("bodegas"), j.get("existencias")
    if bodegas is None or existencias is None:
        return 0
    _upsert(s, inventario.Bodega, bodegas, eid); s.flush()
    bids = {int(b["id"]) for b in bodegas if b.get("id")}
    try:
        from . import sinc_completar
        sinc_completar.recordar_bodegas_web(s, eid, bids)   # n.º 26: la primera subida anota lo de bodegas que la web no tiene
    except Exception:  # noqa: BLE001
        pass
    productos = {p.id: p for p in s.exec(select(Producto)).all()}
    nube = {(int(x["producto_id"]), int(x["bodega_id"])): x for x in existencias if x.get("producto_id") and int(x.get("bodega_id") or 0) in bids}
    locales = {(x.producto_id, x.bodega_id) for x in s.exec(select(inventario.Existencia)).all() if x.bodega_id in bids}
    conocidos = ({modulos._id_entero(x.get("id")) for x in j["productos"] if isinstance(x, dict)}
                 if isinstance(j.get("productos"), list) else None)
    sin_subir = _sin_subir(s, eid)
    hoy = ahora_cr().strftime("%Y-%m-%d")
    ajustes = 0
    for pid, bid in set(nube) | locales:
        p = productos.get(pid)
        if not p or p.es_servicio or not p.inventariable:
            continue
        if (pid, bid) not in nube and (en_rango(pid, rango) or (conocidos is not None and pid not in conocidos)):
            continue
        if pid in sin_subir:
            continue
        objetivo = float(nube[(pid, bid)].get("cantidad") or 0) if (pid, bid) in nube else 0.0
        costo = nube[(pid, bid)].get("costo_promedio") if (pid, bid) in nube else None
        ex = inventario.existencia(s, pid, bid)
        delta = round(objetivo - float(ex.cantidad or 0), 6)
        if abs(delta) > 1e-9:
            inventario.registrar_movimiento(s, producto=p, bodega_id=bid, tipo="ajuste", cantidad=delta, fecha=hoy,
                                            costo_unitario=float(costo) if (delta > 0 and costo is not None) else None,
                                            referencia="Sincronización con la nube", observaciones="Existencia igualada a la de la nube", permitir_negativo=True)
            ajustes += 1
        if costo is not None and abs(float(ex.costo_promedio or 0) - float(costo)) > 1e-9:
            ex.costo_promedio = float(costo); s.add(ex)
    s.commit()
    return ajustes


def _detalle(r) -> str:
    try:
        det = r.json().get("detail")
    except Exception:  # noqa: BLE001
        return r.text[:200]
    if isinstance(det, dict):                      # 4.9: {codigo, mensaje}
        return str(det.get("mensaje") or det.get("codigo") or det)
    return str(det)


def _bajar(s, sc, e: Empresa, cfg, url, cab, rango) -> None:
    r = httpx.get(url + "/api/sinc/catalogo", headers={**cab, CABECERA_PLAN: str(PROTOCOLO_PLAN)}, timeout=TIEMPO)   # 4.28 (C1): entiende la gracia
    _revisar_respuesta(r, "/api/sinc/catalogo")
    r.raise_for_status()
    j = r.json()
    inst = j.get("instalacion") or {}
    if inst.get("nombre"):
        cfg["nombre"] = inst["nombre"]                                   # renombrada en la nube
    cfg.setdefault("red", {})["revocadas"] = [int(x) for x in inst.get("revocadas") or []]
    for k, v in (j.get("empresa") or {}).items():
        # 4.9 (E1/E4): las fechas del plan bajan también vacías (al cobrar el plan la nube borra la prueba)
        if k in CAMPOS_EMPRESA and k not in ("sucursal",) and (v is not None or k in NULABLES_EMPRESA) and hasattr(e, k):
            setattr(e, k, v)
    cfg["correo_nube"] = bool(j.get("correo_nube"))                      # 4.12: sin correo configurado en la nube, sigue enviando esta computadora
    h = j.get("credenciales_huella")
    if h and h != cfg.get("cred_huella"):                                # etapa 1: credenciales, llave .p12 y ambiente bajan cuando cambian
        rc = httpx.get(url + "/api/sinc/credenciales", headers=cab, timeout=TIEMPO)
        _revisar_respuesta(rc, "/api/sinc/credenciales")
        rc.raise_for_status()
        _aplicar_credenciales(e, rc.json().get("credenciales") or {})
        cfg["cred_huella"] = h
    sc.add(e); sc.commit()
    _bajar_usuarios(sc, e.id, j)                                         # etapa 1: usuarios, roles y bloqueos
    from . import sinc_datos_programa as _sdp
    _sdp.senal_catalogo(e.id, j.get("datos_v2"))                         # 4.32 (contrato §5): sin la señal datos_v2 de la web, el canal nuevo queda en pausa
    pausa = _sdp.en_pausa(e.id)                                          # 4.32: en pausa se baja lo declarado salvo lo propio pendiente (y sin revivir lápidas)
    canal = {c for t, c in (("cliente", "clientes"), ("producto", "productos")) if _sdp.por_canal(e.id, t)}
    huellas = cfg.get("huellas") or {}
    for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
        filas = []
        for d in j.get(clave) or []:
            iid = modulos._id_entero(d.get("id")) if isinstance(d, dict) else None
            if iid is not None and en_rango(iid, rango):
                obj = s.get(modelo, iid)                     # fila propia: si tiene un cambio local sin subir, el local manda
                if obj is not None and (huellas.get(clave) or {}).get(str(iid)) != _huella(obj.model_dump()):
                    continue
            filas.append(d)
        if clave in canal:                                               # 4.32: con el protocolo 2 lo trae el goteo de /api/sinc/datos
            if pausa:
                with diario.aplicando(0):                                # en pausa: lo de la web, salvo lo pendiente; sin volver a la cola
                    cfg[clave] = _upsert(s, modelo, _sdp.filas_en_pausa(s, e.id, clave[:-1], filas), e.id)
                    s.commit()
            continue
        cfg[clave] = _upsert(s, modelo, filas, e.id)
    registros = j.get("registros") or {}
    saltar = _sdp.claves_declaradas() if _sdp.protocolo(e.id) == 2 and not pausa else set()   # 4.32: con el protocolo 2, lo declarado lo trae el goteo (no se pisa aquí)
    cfg["impresoras_web"] = isinstance(registros, dict) and "pos_impresoras" in registros   # 4.25 (tanda 8, E-6): la web ya mandó su lista de impresoras
    for clave, datos in (registros.items() if isinstance(registros, dict) else ()):
        if clave in CLAVES_DEL_EQUIPO or clave in saltar:                # 4.25 (tanda 8): lo de esta computadora no lo pisa la web; 4.32: lo declarado viene por /api/sinc/datos
            continue
        if pausa and clave in _sdp.claves_declaradas():                  # 4.32, pausa: lo de la web salvo lo propio pendiente, dentro de aplicando (no vuelve a la cola)
            try:
                datos = _sdp.registro_en_pausa(s, e.id, clave, datos)
                if datos is not _sdp.NO_ESCRIBIR:
                    with diario.aplicando(0):
                        _escribir(s, e.id, clave, datos)
            except Exception as ex:  # noqa: BLE001
                s.rollback(); log.warning("sinc: registro %s no se pudo escribir (%s)", clave, type(ex).__name__)
            continue
        try:
            _escribir(s, e.id, clave, datos)
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc: registro %s no se pudo escribir: %s", clave, ex)
    s.commit()
    try:                                                                 # 4.29 (B-1 a B-4): solo siembra si no hay «bancos»; nunca frena la bajada
        _sembrar_bancos(s, e, j)
    except Exception as ex:  # noqa: BLE001
        s.rollback(); log.warning("sinc: cuentas iniciales de Bancos: %s", type(ex).__name__)
    cfg["aviso"] = None
    try:
        cfg["existencias"] = _bajar_existencias(s, e.id, j, rango)
    except Exception as ex:  # noqa: BLE001
        s.rollback(); log.warning("sinc: existencias: %s", ex); cfg["aviso"] = f"existencias: {str(ex)[:200]}"
    cfg["ultima_bajada"] = _ahora()


def _guardar_cfg(s, eid: int, cfg: dict, inicial: dict) -> None:
    """4.16: guarda solo lo que cambió este ciclo sobre la configuración vigente: una desvinculación o un cambio de la red hechos mientras el ciclo corría no se pierden."""
    cambios = [k for k in set(cfg) | set(inicial) if cfg.get(k, _AUSENTE) != inicial.get(k, _AUSENTE)]
    if not cambios:
        return
    s.expire_all()
    actual = _cfg_local(s, eid)
    for k in cambios:
        if k in cfg:
            actual[k] = cfg[k]
        else:
            actual.pop(k, None)
    _escribir(s, eid, CLAVE_LOCAL, actual); s.commit()
    inicial.clear(); inicial.update(json.loads(json.dumps(cfg, default=str)))


def _bajar_novedades(s, eid: int, cfg: dict, url: str, cab: dict, inicial: dict) -> int:
    """Etapa 2a: lo que cambió en la nube desde el último avance: comprobantes y cobros, también sus bajas. Va dentro de aplicando(0) para no devolverlo.
    Un paquete con errores se reintenta sin avanzar. Un problema pasajero (base ocupada, disco) nunca lo salta; un dato malo, a los INTENTOS_BAJADA: queda
    anotado y a la vista, para que no detenga lo demás."""
    n = 0
    propias = {int(cfg.get("terminal") or 0)} | {int(x) for x in cfg.get("terminales_anteriores") or []}   # 4.16: lo nacido aquí con una terminal anterior sigue siendo de aquí
    for _ in range(PAGINAS_POR_CICLO):
        desde = int(cfg.get("cursor_bajada") or 0)
        r = httpx.get(f"{url}/api/sinc/novedades?desde={desde}", headers=cab, timeout=TIEMPO)
        _revisar_respuesta(r, "/api/sinc/novedades")
        if r.status_code == 404:                                         # nube anterior a esta versión
            return n
        r.raise_for_status()
        j = r.json()
        errores: list = []
        with diario.aplicando(0):
            for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
                faltan = [x for x in j.get(clave) or [] if isinstance(x, dict) and x.get("id") and s.get(modelo, int(x["id"])) is None]
                if faltan and _canal().por_canal(eid, clave[:-1]):     # 4.32: un ítem o cliente eliminado por el canal nuevo no revive por un comprobante
                    faltan = _canal().filas_en_pausa(s, eid, clave[:-1], faltan)
                if faltan:
                    _upsert(s, modelo, faltan, eid); s.commit()
            recibidos, errs = _guardar_documentos(s, eid, j.get("documentos") or [], ORIGEN_NUBE, de_red=True, desde_nube=True)
            n += len(recibidos); errores += [f"comprobante {e.get('clave')}: {e.get('error')}" for e in errs]
            for ref in j.get("pagos_borrados") or []:
                try:
                    n += int(_borrar_cobro_por_ref(s, eid, str(ref), propias=propias))
                except Exception as ex:  # noqa: BLE001
                    s.rollback(); errores.append(f"baja del cobro {ref}: {str(ex)[:150]}")
            for p in j.get("pagos") or []:
                try:
                    n += int(_guardar_pago(s, eid, p, str(p.get("ref")), "Nube", {}, historia=bool(p.get("historia")), respetar_numero=True, propias=propias))
                except Exception as ex:  # noqa: BLE001
                    s.rollback(); errores.append(f"cobro {p.get('ref')}: {str(ex)[:150]}")
        if errores:
            fallo = cfg.get("fallo_bajada") or {}
            veces = int(fallo.get("veces") or 0) + 1 if fallo.get("cursor") == desde else 1
            texto = "; ".join(errores)
            if veces < INTENTOS_BAJADA or any(x in texto.lower() for x in ERRORES_PASAJEROS):
                cfg["fallo_bajada"] = {"cursor": desde, "veces": veces}
                raise RuntimeError(texto[:300])
            log.warning("sinc empresa %s: se salta el paquete %s: %s", eid, desde, errores)
            cfg["aviso_bajada"] = f"Datos que no se pudieron bajar: {texto[:200]}"
            cfg["saltados"] = ((cfg.get("saltados") or []) + errores)[-100:]
        cfg.pop("fallo_bajada", None)
        if int(j.get("cursor") or desde) != desde:
            cfg["cursor_bajada"] = int(j["cursor"])
            _guardar_cfg(s, eid, cfg, inicial)                           # el avance se guarda por paquete: un corte no repite lo ya aplicado
        if not j.get("mas"):
            break
    return n


def traer_archivos(eid: int, d: Documento) -> None:
    """Etapa 2a (decisión 8): el XML de un comprobante que bajó como historia se trae de la nube la primera vez que se pide. Sin conexión no hace nada:
    quien llama responde que el archivo no está disponible."""
    if not MODO_LOCAL or not d.xml_nombre:
        return
    # 4b (Q10): la clave (50 dígitos) y los nombres anotados (bajaron de la web) se revisan antes de pedir o escribir nada
    if not _clave_valida(d.clave) or not _nombre_xml_simple(d.xml_nombre) or (d.respuesta_nombre and not _nombre_xml_simple(d.respuesta_nombre)):
        log.info("No se pidió el XML de un comprobante: su clave o el nombre de sus archivos no es válido")
        return
    if (XML_DIR / d.xml_nombre).exists() and (not d.respuesta_nombre or (XML_DIR / d.respuesta_nombre).exists()):
        return
    try:
        with Session(engine_empresa(eid)) as s, Session(engine) as sc:
            cfg, e = _cfg_local(s, eid), sc.get(Empresa, eid)
            if not cfg.get("vinculado") or not cfg.get("token") or e is None:
                return
            r = httpx.get(f"{cfg['url']}/api/sinc/xml/{d.clave}", headers={"Authorization": "Bearer " + secretos.descifrar(e.clave_cifrada, cfg["token"])},
                          timeout=httpx.Timeout(30, connect=5))
        if r.status_code != 200:
            return
        j = r.json()
        if not isinstance(j, dict):
            return
        if j.get("xml_b64") and not (XML_DIR / d.xml_nombre).exists():
            _escribir_xml(d.xml_nombre, base64.b64decode(j["xml_b64"]))
        if j.get("respuesta_b64") and d.respuesta_nombre and not (XML_DIR / d.respuesta_nombre).exists():
            _escribir_xml(d.respuesta_nombre, base64.b64decode(j["respuesta_b64"]))
    except Exception as ex:  # noqa: BLE001
        log.info("No se pudo traer el XML de %s (%s)", d.clave, type(ex).__name__)   # ni el contenido ni el texto de la respuesta


MOTIVOS_XML = {
    "sin internet": "no se pudo traer de la web: sin internet. Vuelva a exportar cuando haya conexión.",
    "tiempo": "no se pudo traer de la web: se acabó el tiempo para traerlos. Vuelva a exportar o exporte un período más corto.",
    "sin acceso": "no se pudo traer de la web: la web no atendió a esta computadora. Revise Configuración › Instalación local y vuelva a exportar.",
}
NO_ESTA_XML = "no está en la web"
AJENO_XML = "lo que llegó de la web no corresponde a este comprobante: no se guardó"
CLAVE_MALA_XML = "la clave del comprobante no es válida: no se puede pedir a la web"
SOLO_RESPUESTA_XML = "falta solo la respuesta de Hacienda (el XML sí está)"


def _faltan_archivos(d) -> list:
    """Los archivos de un comprobante que tienen nombre anotado y no están en la carpeta: [(nombre, es_respuesta)]."""
    return [(n, r) for n, r in ((d.xml_nombre, False), (d.respuesta_nombre, True)) if n and not (XML_DIR / n).exists()]


def traer_archivos_lote(eid: int, docs, plazo: float | None = None) -> dict:
    """4.25 (X3): antes de exportar, el programa trae de la web en lotes de LOTE_XML los XML y respuestas que les faltan a `docs`
    (los comprobantes viejos bajan sin archivo). En la web (sin modo local) o si no falta ninguno vuelve de inmediato sin llamar a
    nadie. Se detiene al primer error de red («sin internet»), al agotar el plazo («tiempo») o si la web no atiende («sin acceso»).
    Si la web es anterior a esta versión (404 o 405) pide uno por uno dentro del mismo plazo. Solo pide claves de 50 dígitos y cuyos
    nombres anotados son los de siempre (clave.xml y clave_respuesta.xml); solo guarda lo que no estaba, si el contenido trae la
    clave pedida, con _guardar_xml. Nunca lanza. Devuelve {faltaban, traidos, sin_traer, sin_respuesta, motivo, por_clave: {clave: texto}}.
    Revisión 4.25: una computadora sin vincular (sin vinculación, token o dirección) devuelve lo mismo que la web (sin motivo ni
    por_clave): FALTANTES.txt y el aviso salen como antes. «Traído» es el comprobante cuyo XML quedó en disco; `sin_traer` cuenta solo
    los XML que faltan y `sin_respuesta` los que tienen el XML pero no la respuesta de Hacienda («falta solo la respuesta»)."""
    res = {"faltaban": 0, "traidos": 0, "sin_traer": 0, "sin_respuesta": 0, "motivo": None, "por_clave": {}}
    if not MODO_LOCAL:
        return res
    url = cab = None
    leida = True
    try:
        with Session(engine_empresa(eid)) as s, Session(engine) as sc:
            cfg, e = _cfg_local(s, eid), sc.get(Empresa, eid)
            if cfg.get("vinculado") and cfg.get("token") and cfg.get("url") and e is not None:
                url, cab = str(cfg["url"]).rstrip("/"), {"Authorization": "Bearer " + secretos.descifrar(e.clave_cifrada, cfg["token"])}
    except Exception as ex:  # noqa: BLE001
        leida = False
        log.info("No se pudo leer la vinculación para traer los XML: %s", type(ex).__name__)
    if leida and not url:                                                # sin vincular: como en la web
        return res
    pend = {d.clave: d for d in (docs or []) if d.clave and _faltan_archivos(d)}
    res["faltaban"] = len(pend)
    if not pend:
        return res
    faltaba_xml = {clave for clave, d in pend.items() if any(not r for _n, r in _faltan_archivos(d))}
    plazo = PLAZO_XML if plazo is None else plazo
    fin = time.monotonic() + max(0.0, float(plazo))
    malas, ajenas, atendidas = set(), set(), set()
    cola = []
    for clave, d in pend.items():
        if _clave_valida(clave) and all(n == (f"{clave}_respuesta.xml" if r else f"{clave}.xml") for n, r in _faltan_archivos(d)):
            cola.append(clave)
        else:
            malas.add(clave)

    def guardar(clave: str, datos) -> None:
        atendidas.add(clave)
        if not isinstance(datos, dict):
            return
        for nombre, es_resp in _faltan_archivos(pend[clave]):
            valor = datos.get("respuesta_b64" if es_resp else "xml_b64")
            if not isinstance(valor, str) or not valor:
                continue
            try:
                contenido = base64.b64decode(valor, validate=True)
            except Exception:  # noqa: BLE001
                ajenas.add(clave); continue
            if clave.encode() not in contenido:                            # solo si el contenido es el del comprobante pedido
                ajenas.add(clave); continue
            _guardar_xml(clave, contenido, respuesta=es_resp)

    motivo = None
    if cola:
        if not url:
            motivo = "sin acceso"
        viejo = False
        while url and cola:
            restante = fin - time.monotonic()
            if restante <= 0:
                motivo = "tiempo"; break
            espera = httpx.Timeout(min(30.0, max(1.0, restante)), connect=min(5.0, max(1.0, restante)))
            try:
                if not viejo:
                    lote = cola[:LOTE_XML]
                    r = httpx.post(f"{url}/api/sinc/xml", headers=cab, json={"claves": lote}, timeout=espera)
                    if r.status_code in (404, 405) and _codigo_nube(r) != CODIGO_REVOCADA:   # web anterior a la 4.25: uno por uno
                        viejo = True; continue
                    j = r.json() if r.status_code == 200 else None
                    if not isinstance(j, dict) or not isinstance(j.get("archivos"), dict):
                        motivo = "sin acceso"; break
                    archivos = j["archivos"]
                    pendientes = [c for c in dict.fromkeys(j.get("pendientes") or []) if c in lote and c not in archivos]
                    for c in lote:
                        if c in archivos:
                            guardar(c, archivos[c])
                        elif c not in pendientes:
                            atendidas.add(c)                               # no está en la web
                    cola = pendientes + cola[len(lote):]
                    if pendientes and not any(c in archivos for c in lote):
                        motivo = "sin acceso"; break                       # sin avance: no se insiste
                else:
                    clave = cola[0]
                    r = httpx.get(f"{url}/api/sinc/xml/{clave}", headers=cab, timeout=espera)
                    if r.status_code == 404 and _codigo_nube(r) != CODIGO_REVOCADA:
                        atendidas.add(clave); cola.pop(0); continue
                    if r.status_code != 200:
                        motivo = "sin acceso"; break
                    guardar(clave, r.json()); cola.pop(0)
            except _ERROR_RED as ex:
                log.info("Sin conexión con la web al traer los XML: %s", type(ex).__name__)
                motivo = "sin internet"; break
            except Exception as ex:  # noqa: BLE001
                log.info("La web no atendió la solicitud de XML: %s", type(ex).__name__)
                motivo = "sin acceso"; break
    for clave, d in pend.items():
        faltan = _faltan_archivos(d)
        if not faltan:
            res["traidos"] += 1; continue
        if all(r for _n, r in faltan):                                   # el XML está: falta solo la respuesta de Hacienda
            res["sin_respuesta"] += 1
            if clave in faltaba_xml:
                res["traidos"] += 1                                      # el XML sí llegó
            res["por_clave"][clave] = SOLO_RESPUESTA_XML
            continue
        res["sin_traer"] += 1
        if clave in malas:
            res["por_clave"][clave] = CLAVE_MALA_XML
        elif clave in ajenas:
            res["por_clave"][clave] = AJENO_XML
        elif clave in atendidas:
            res["por_clave"][clave] = NO_ESTA_XML
        else:
            res["por_clave"][clave] = MOTIVOS_XML[motivo or "sin acceso"]
            res["motivo"] = motivo or "sin acceso"
    return res


MENSAJE_SIN_CONEXION_CICLO = "Sin conexión con la página web: se vuelve a intentar sola."      # 4.25 (9b, U11)
# 4.25 (9c, P4): lo que queda en ultimo_error cuando una persona revocó esta computadora en la web (empieza como antes de la 4.25)
MENSAJE_REVOCADA_CICLO = ("Esta instalación fue revocada en la nube. Para seguir, un administrador la conecta de nuevo en Configuración › "
                          "Instalación local («Conectar con mi cuenta»).")


def sincronizar(eid: int, nube: bool = True, red: bool = True, ligero: bool = False) -> dict:
    """Sube lo que creó la instalación local y baja catálogos y existencias de una empresa (nube), y manda sus cambios a las
    otras computadoras del local (red). Devuelve el estado; nunca lanza."""
    with _lock:
        if _en_curso.get(eid):
            return {"sincronizando": True}
        _en_curso[eid] = True
        _dueno[eid] = threading.get_ident()                               # 4.35
    try:
        with Session(engine_empresa(eid)) as s, Session(engine) as sc:
            cfg = _cfg_local(s, eid)
            inicial = json.loads(json.dumps(cfg, default=str))
            e = sc.get(Empresa, eid)
            if e is None or e.bloqueada:
                _en_curso[eid] = False
                return _estado_local(s, eid, e)
            rango = int(cfg.get("terminal") or 0) if cfg.get("vinculado") else 0
            if rango and modulos.rango_propio(eid) != rango:
                _fijar_rango_local(s, eid, rango)
            if _normalizar_revocacion(cfg):
                # 4.9: una «revocación» que anotó una versión anterior sin la señal explícita de la nube no cuenta: se desbloquea
                _guardar_cfg(s, eid, cfg, inicial)
                _cargar_estado(eid, cfg)
                auditar(sc, "sinc_local_sin_acceso", "Una versión anterior tomó un acceso negado de la nube como revocación: la instalación vuelve a "
                        "trabajar y a intentar sincronizar (solo una revocación explícita de la nube la bloquea)", None, eid, None)
            if cfg.get("revocada_en"):
                # revocada en la nube: no sincroniza ni con la nube ni con la red; a los 3 días se bloquea; a los 30 borra sus datos
                if _revisar_revocada(sc, e, cfg):
                    _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
                    _en_curso[eid] = False
                    _eliminar.append(eid)
                    return _estado_local(s, eid, e)
                _escribir(s, eid, CLAVE_LOCAL, cfg); s.commit()
                _en_curso[eid] = False
                return _estado_local(s, eid, e)
            if red and (cfg.get("red") or {}).get("pcs"):
                enviar_red(s, e, cfg, rango)
                _guardar_cfg(s, eid, cfg, inicial)
            if not nube and not ligero:
                _en_curso[eid] = False
                return _estado_local(s, eid, e)
            if not cfg.get("vinculado") or not cfg.get("token"):
                _en_curso[eid] = False
                return _estado_local(s, eid, e)
            token_guardado = cfg["token"]                                # 4.25 (E-9): el token (cifrado) con el que se hace este ciclo
            token = secretos.descifrar(e.clave_cifrada, cfg["token"])
            cab = {"Authorization": "Bearer " + token}
            if _valida_en_linea(cfg):                                    # 4.25 (D-E): la nube aplica la política de hash a este programa (solo si puede validar en línea)
                cab[CABECERA_INGRESO] = str(PROTOCOLO_INGRESO)
            url = cfg["url"]
            sub, errores = _subidos(cfg), []
            sub_antes = dict(sub)
            try:
                # ---- 4.25 (D-F): usuarios primero, con la llamada liviana: llega aunque fallen las novedades o la empresa esté bloqueada en la web ----
                if nube and _valida_en_linea(cfg):
                    try:
                        _bajar_usuarios_ligero(sc, e, cfg, token)
                    except (Revocada, SinAcceso):
                        raise
                    except Exception as ex:  # noqa: BLE001
                        sc.rollback(); log.warning("sinc empresa %s, bajar usuarios: %s", eid, type(ex).__name__)
                    if usuarios_atrasados(cfg):
                        log.warning("sinc empresa %s: la última bajada de usuarios buena tiene más de %s minutos", eid, MINUTOS_USUARIOS)
                # ---- subir: primero clientes e ítems nuevos (los comprobantes los usan), luego comprobantes, cobros y registros ----
                for nombre, fn in (("clientes e ítems", lambda: _subir_catalogos(s, eid, cfg, url, cab, rango)),
                                   ("comprobantes", lambda: _subir_documentos(s, eid, cfg, url, cab)),
                                   ("cobros", lambda: _subir_pagos(s, eid, cfg, url, cab, rango)),
                                   ("registros", lambda: _subir_registros(s, eid, cfg, url, cab, rango))):
                    if nombre == "registros" and not nube:               # etapa 2a: en el ciclo corto solo lo que no gasta red si no hay nada
                        continue
                    try:
                        n = fn()
                        if nombre == "clientes e ítems":
                            sub["clientes"] += n
                        else:
                            sub[{"comprobantes": "documentos", "cobros": "pagos", "registros": "registros"}[nombre]] += n
                    except (Revocada, SinAcceso):
                        raise
                    except Exception as ex:  # noqa: BLE001
                        s.rollback(); errores.append(f"{nombre}: {str(ex)[:200]}")
                        log.warning("sinc empresa %s, subir %s: %s", eid, nombre, ex)
                if nube or sub != sub_antes:
                    cfg["ultima_subida"] = _ahora(); cfg["subidos"] = sub
                # ---- bajar: primero lo nuevo de la nube (sus comprobantes mueven el inventario de aquí); cada 2 minutos, catálogos, configuración y existencias ----
                _bajar_novedades(s, eid, cfg, url, cab, inicial)
                if nube:
                    _bajar(s, sc, e, cfg, url, cab, rango)
                    cfg.pop("primera", None)                             # 4.25 (E-10): la primera bajada buena quita la marca de primera conexión
                cfg["ultimo_error"] = "; ".join(errores)[:400] if errores else None
                cfg.pop("sin_conexion_desde", None)                      # etapa 1: hubo conexión
                if cfg.get("sin_acceso_desde"):                  # 4.9: la nube volvió a dar acceso
                    auditar(sc, "sinc_local_acceso", f"La nube volvió a dar acceso a esta instalación (sin acceso desde {str(cfg['sin_acceso_desde'])[:19]})", None, eid, None)
                    cfg.pop("sin_acceso_desde", None); cfg.pop("sin_acceso_motivo", None)
            except Revocada as ex:
                s.rollback()
                # 4.25 (E-9): si mientras corría el ciclo la configuración pasó a otra conexión (otro token), la revocación es del token
                # viejo: no se escribe nada. E-10: una primera conexión revocada antes de su primera bajada se deshace.
                s.expire_all()
                actual = _cfg_local(s, eid)
                if actual.get("token") != token_guardado:
                    log.warning("sinc empresa %s: la web revocó un token que ya no es el de esta computadora: no se cambia nada", eid)
                    _en_curso[eid] = False
                    return _estado_local(s, eid, e)
                if _deshacer_conexion(s, sc, eid, actual):
                    _en_curso[eid] = False
                    return _estado_local(s, eid, e)
                if ex.motivo == MOTIVO_SIN_ESTRENAR:                  # 4.25 (D-O): un descarte automático de la web no es una revocación
                    _desvincular_descartada(s, sc, eid, actual)
                    _en_curso[eid] = False
                    return _estado_local(s, eid, e)
                cfg["revocada_en"] = cfg.get("revocada_en") or _ahora()
                cfg["revocacion_explicita"] = True               # 4.9: la nube lo dijo con su código; solo así cuentan el bloqueo y el borrado
                cfg.pop("sin_acceso_desde", None); cfg.pop("sin_acceso_motivo", None)
                # 4.25 (9c, P4): un texto propio, completo y llano con la salida de la 4.25 (no se copia ni se recorta el de la web)
                cfg["ultimo_error"] = f"{_ahora()[:19]} {MENSAJE_REVOCADA_CICLO}"
                _cargar_estado(eid, cfg)
                auditar(sc, "sinc_local_revocada", "La nube revocó esta instalación: se bloqueará en 3 días si no se vincula de nuevo", None, eid, None)
                log.warning("sinc empresa %s: revocada en la nube", eid)
            except SinAcceso as ex:
                # 4.9 (5a): acceso negado sin revocación explícita: aviso, se sigue trabajando y reintentando; nunca bloqueo ni borrado
                s.rollback()
                primera = not cfg.get("sin_acceso_desde")
                cfg["sin_acceso_desde"] = cfg.get("sin_acceso_desde") or _ahora()
                cfg["sin_acceso_motivo"] = str(ex)[:200]
                cfg["ultimo_error"] = (f"{_ahora()[:19]} Sin acceso a la nube: {str(ex)[:160]}. Esta computadora sigue trabajando con sus datos y vuelve a "
                                       "intentar sola; no se bloquea ni se borra nada.")[:400]
                if primera:
                    auditar(sc, "sinc_local_sin_acceso", f"La nube negó el acceso sin revocar la instalación ({str(ex)[:150]}): sigue trabajando y reintenta", None, eid, None)
                log.warning("sinc empresa %s: sin acceso a la nube: %s", eid, ex)
            except Exception as ex:  # noqa: BLE001
                s.rollback()
                if isinstance(ex, _ERROR_RED):
                    cfg["sin_conexion_desde"] = cfg.get("sin_conexion_desde") or _ahora()   # etapa 1: para la franja
                    # 4.25 (9b, U11): un texto llano para la persona; el detalle técnico va solo al registro (el tipo de la excepción)
                    cfg["ultimo_error"] = MENSAJE_SIN_CONEXION_CICLO
                    log.warning("sinc empresa %s: sin conexión con la página web (%s)", eid, type(ex).__name__)
                else:
                    cfg["ultimo_error"] = f"{_ahora()[:19]} {'; '.join(errores + [str(ex)[:200]])}"[:400]
                    log.warning("sinc empresa %s: %s", eid, ex)
            _guardar_cfg(s, eid, cfg, inicial)                           # etapa 2a: el ciclo corto sin novedades no escribe
            _cargar_estado(eid, cfg)
            _en_curso[eid] = False
            return _estado_local(s, eid, e)
    finally:
        with _lock:
            if _dueno.get(eid) == threading.get_ident():                 # 4.35: si ya lo tomó otro (tras soltarlo arriba), es suyo
                _en_curso[eid] = False
        while _eliminar:
            _eliminar_datos(_eliminar.pop())


def _bucle():
    paso = max(5, int(os.environ.get("FE_SINC_LIGERO_SEGUNDOS", "15")))   # etapa 2a: la web ve lo de aquí en segundos
    time.sleep(20 + random.uniform(0, paso))                             # repartidas: no todas las computadoras preguntan a la vez
    cada_red = max(1, int(os.environ.get("FE_RED_SEGUNDOS", "30")) // paso)
    cada_nube = max(1, int(os.environ.get("FE_SINC_SEGUNDOS", "120")) // paso)
    tic = 0
    while True:
        try:
            with Session(engine) as sc:
                eids = [x.id for x in sc.exec(select(Empresa)).all()]
            for eid in eids:
                sincronizar(eid, nube=(tic % cada_nube == 0), red=(tic % cada_red == 0), ligero=True)
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc bucle: %s", ex)
        tic += 1
        time.sleep(paso)


_hilo = False


def iniciar_hilo():
    global _hilo
    if _hilo or not MODO_LOCAL or os.environ.get("FE_SINC_HILO", "1") == "0":
        return
    _hilo = True
    threading.Thread(target=_bucle, name="sinc-local", daemon=True).start()


# ======================================================================================================================
# RED LOCAL: entre computadoras del mismo local (3.14)
# ======================================================================================================================
def _registrar_borrados(s, eid: int, clave: str, ids: list) -> None:
    """Lápidas de las bajas hechas en esta computadora (se mandan a las demás; se guardan 7 días)."""
    if clave not in CLAVES_RED:
        return
    ahora = datetime.now(timezone.utc)
    limite = (ahora - timedelta(days=7)).isoformat()
    for _ in range(3):
        try:
            v = _leer(s, eid, CLAVE_BORRADOS, {})
            v = {k: {i: ts for i, ts in d.items() if ts >= limite} for k, d in v.items() if isinstance(d, dict)}
            v.setdefault(clave, {}).update({str(int(i)): ahora.isoformat() for i in ids})      # con microsegundos: decide quién gana
            _escribir(s, eid, CLAVE_BORRADOS, v)
            return
        except modulos.ConflictoRegistro:
            s.rollback()


if MODO_LOCAL:
    modulos.al_borrar = _registrar_borrados


def _anotar_recibido(eid: int, de: str, terminal, propios: dict) -> None:
    """Registro aparte (lo escriben las peticiones de otras computadoras, no el hilo): de quién se recibió y qué elementos
    propios cambió otra computadora (hay que volver a subirlos a la nube)."""
    with Session(engine_empresa(eid)) as s:
        for _ in range(3):
            try:
                v = _leer(s, eid, CLAVE_RED_RECIBIDO, {})
                v.setdefault("de", {})[de] = {"ultimo": _ahora(), "terminal": terminal}
                pend = v.setdefault("pendientes", {})
                for clave, ids in propios.items():
                    pend[clave] = sorted(set(int(i) for i in (pend.get(clave) or [])) | set(int(i) for i in ids))
                _escribir(s, eid, CLAVE_RED_RECIBIDO, v); s.commit()
                return
            except modulos.ConflictoRegistro:
                s.rollback()


def computadoras_vivas(s, eid: int, desde: str) -> tuple[set, set]:
    """4.9 (R3, lado red local): terminales y nombres (como los guarda origen_sinc, 40 caracteres) de las otras computadoras del
    local con las que hubo contacto desde `desde` (ISO UTC), en cualquiera de los dos sentidos: las que mandaron algo aquí
    (_anotar_recibido) y las que contestaron a lo que se les mandó (enviar_red). Sin novedades igual dan señal (_toca_latido). Una
    computadora sin vincular no tiene terminal (llega 0): para ella cuenta el nombre. Lo usa cola.retomables."""
    terminales, nombres = set(), set()
    for nombre, x in (_leer(s, eid, CLAVE_RED_RECIBIDO, {}).get("de") or {}).items():
        if isinstance(x, dict) and str(x.get("ultimo") or "") >= desde:
            if x.get("terminal"):
                terminales.add(int(x["terminal"]))
            else:
                nombres.add(str(nombre)[:40])         # 4.9 (F3): solo sin terminal
    for pc in (_cfg_local(s, eid).get("red") or {}).get("pcs") or []:
        if isinstance(pc, dict) and str(pc.get("ultimo_ok") or "") >= desde:
            if pc.get("terminal"):
                terminales.add(int(pc["terminal"]))
            else:
                nombres.update(str(pc[k])[:40] for k in ("nombre", "nombre_red") if pc.get(k))
    return terminales, nombres


def _quitar_pendientes_red(s, eid: int, subidos: dict) -> None:
    for _ in range(3):
        try:
            v = _leer(s, eid, CLAVE_RED_RECIBIDO, {})
            pend = v.get("pendientes") or {}
            for clave, ids in subidos.items():
                if clave in pend:
                    pend[clave] = [i for i in pend[clave] if int(i) not in set(int(x) for x in ids)]
                    if not pend[clave]:
                        pend.pop(clave)
            v["pendientes"] = pend
            _escribir(s, eid, CLAVE_RED_RECIBIDO, v); s.commit()
            return
        except modulos.ConflictoRegistro:
            s.rollback()


def _eid_red(sc, numero_id: str):
    """La empresa de esta computadora con esa cédula (la misma empresa en todas las computadoras del local)."""
    e = sc.exec(select(Empresa).where(Empresa.numero_id == str(numero_id))).first()
    return e.id if e else None


def _autenticar_red(request: Request, numero_id: str, sc: Session):
    """Otra computadora del local: cédula de la empresa en la ruta y la clave de red en la cabecera X-Clave-Red."""
    if not MODO_LOCAL:
        raise HTTPException(404, "No encontrado")
    clave = (request.headers.get("x-clave-red") or "").strip()
    eid = _eid_red(sc, numero_id)
    if not eid or not clave:
        limitar_ip(request, "sinc_red", 20, 600, "Demasiados intentos; espere unos minutos")
        raise HTTPException(403, "Clave de red o empresa incorrecta")
    with Session(engine_empresa(eid)) as s:
        red = (_cfg_local(s, eid).get("red") or {})
    if not red.get("clave_hash") or not secrets.compare_digest(_hash(clave), red["clave_hash"]):
        limitar_ip(request, "sinc_red", 20, 600, "Demasiados intentos; espere unos minutos")
        raise HTTPException(403, "Clave de red o empresa incorrecta")
    return eid


@router.get("/red/{numero_id}/ping")
def red_ping(numero_id: str, request: Request, sc: Session = Depends(get_session)):
    eid = _autenticar_red(request, numero_id, sc)
    with Session(engine_empresa(eid)) as s:
        cfg = _cfg_local(s, eid)
    return {"ok": True, "nombre": cfg.get("nombre") or socket.gethostname(), "terminal": cfg.get("terminal"), "version": _version_sistema(), "vinculada": bool(cfg.get("vinculado"))}


@router.post("/red/{numero_id}/cambios")
def red_cambios(numero_id: str, request: Request, cuerpo: dict = Body(...), sc: Session = Depends(get_session)):
    """Cambios que manda otra computadora del local: clientes e ítems de su rango, comprobantes que emitió y registros
    operativos de cualquier rango (gana el último cambio por fecha; las bajas llegan como lápidas)."""
    eid = _autenticar_red(request, numero_id, sc)
    terminal = int(cuerpo.get("terminal") or 0)
    nombre = str(cuerpo.get("nombre") or f"terminal {terminal}")[:40]
    out = {"clientes": 0, "productos": 0, "documentos": [], "registros": {}, "errores": []}
    propios: dict = {}
    with Session(engine_empresa(eid)) as s:
        cfg = _cfg_local(s, eid)
        if cfg.get("revocada_en"):
            raise HTTPException(403, "Esta computadora fue revocada en la nube y ya no participa en la red local")
        if terminal and terminal in {int(x) for x in (cfg.get("red") or {}).get("revocadas") or []}:
            raise HTTPException(403, "Esa computadora fue revocada en la nube: sus cambios no se aceptan")
        out["terminal"] = cfg.get("terminal")
        out["nombre"] = cfg.get("nombre") or socket.gethostname()     # 4.9 (R3): el nombre con el que esta computadora firma lo que manda
        for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
            if clave not in cuerpo and clave + "_vivos" not in cuerpo:
                continue
            if _canal().por_canal(eid, clave[:-1]):                     # 4.32: con el protocolo 2 llegan por la web (/api/sinc/datos), no por la red
                # revisión n.º 31: solo se crean los que aquí no existen (una venta de esa computadora que llega en el mismo envío no queda
                # sin ítem ni cliente); dentro de aplicando: no entran a la cola. Los cambios y las bajas los trae el goteo de la web.
                try:
                    filas = [d for d in cuerpo.get(clave) or [] if isinstance(d, dict) and terminal and en_rango(modulos._id_entero(d.get("id")), terminal)
                             and s.get(modelo, modulos._id_entero(d.get("id"))) is None]
                    if filas:
                        with diario.aplicando(0):
                            out[clave] = _upsert_productos(s, filas, eid) if modelo is Producto else _upsert(s, modelo, filas, eid)
                            s.commit()
                except Exception as ex:  # noqa: BLE001
                    s.rollback(); out["errores"].append({"parte": clave, "error": str(ex)[:200]})
                continue
            try:
                filas = [d for d in cuerpo.get(clave) or [] if isinstance(d, dict) and terminal and en_rango(modulos._id_entero(d.get("id")), terminal)]
                out[clave] = _upsert_productos(s, filas, eid) if modelo is Producto else _upsert(s, modelo, filas, eid)   # 4.25 (tanda 9): con la protección de códigos
                if clave + "_vivos" in cuerpo and terminal:
                    vivos = {int(i) for i in cuerpo.get(clave + "_vivos") or []}
                    for obj in s.exec(select(modelo)).all():
                        if en_rango(obj.id, terminal) and obj.id not in vivos and obj.activo:
                            obj.activo = False; s.add(obj)
                s.commit()
            except Exception as ex:  # noqa: BLE001
                s.rollback(); out["errores"].append({"parte": clave, "error": str(ex)[:200]})
        if cuerpo.get("documentos"):
            recibidos, errores = _guardar_documentos(s, eid, cuerpo["documentos"], nombre, de_red=True)
            out["documentos"] = recibidos; out["errores"] += errores
        for clave, cambio in (cuerpo.get("registros") or {}).items():
            if clave not in CLAVES_RED or not isinstance(cambio, dict):
                out["registros"][clave] = {"error": "Este registro no se comparte"}; continue
            try:
                res = modulos.aplicar_red(s, eid, clave, cambio.get("items") or [], cambio.get("vivos") if terminal else None, terminal, cambio.get("borrados") or [])
                if res.get("propios") and clave in CLAVES_OPERATIVAS:     # lo propio que otra PC cambió vuelve a subir a la nube
                    propios[clave] = res["propios"]
                out["registros"][clave] = {k: res[k] for k in ("altas", "cambios", "bajas")}
            except Exception as ex:  # noqa: BLE001
                s.rollback(); out["registros"][clave] = {"error": str(ex)[:200]}
    _anotar_recibido(eid, nombre, terminal, propios)
    return out


class RedIn(BaseModel):
    clave: Optional[str] = None            # nueva clave de red (vacío: se conserva la actual)
    pcs: list[dict] = []                   # [{nombre, url}]


@router.get("/local/red")
def red_estado(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    if not MODO_LOCAL:
        raise HTTPException(400, "Solo en una instalación local")
    return _estado_local(s, ctx.empresa.id)


@router.post("/local/red")
def red_guardar(data: RedIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Guarda la clave de red (la misma en todas las computadoras del local) y la lista de las otras computadoras."""
    if not MODO_LOCAL:
        raise HTTPException(400, "Solo en una instalación local")
    e = sc.get(Empresa, ctx.empresa.id)
    secretos.asegurar_clave(e); sc.add(e); sc.commit()
    cfg = _cfg_local(s, ctx.empresa.id)
    red = cfg.setdefault("red", {})
    if data.clave is not None and data.clave.strip():
        clave = data.clave.strip()
        if len(clave) < 6:
            raise HTTPException(400, "La clave de red debe tener al menos 6 caracteres")
        red["clave"] = secretos.cifrar(e.clave_cifrada, clave); red["clave_hash"] = _hash(clave)
    viejos = {pc.get("url"): pc for pc in red.get("pcs") or []}
    pcs = []
    for x in data.pcs:
        url = str(x.get("url") or "").strip().rstrip("/")
        if not url:
            continue
        if not url.startswith("http"):
            url = "http://" + url
        if url.count(":") < 2:
            url += ":8020"
        pc = viejos.get(url) or {"url": url, "cursor": {}, "enviados": {"documentos": 0, "registros": 0, "catalogos": 0}}
        pc["nombre"] = str(x.get("nombre") or "").strip()[:40] or pc.get("nombre") or url
        pcs.append(pc)
    red["pcs"] = pcs
    _escribir(s, ctx.empresa.id, CLAVE_LOCAL, cfg); s.commit()
    auditar(sc, "sinc_red", f"Red local: {len(pcs)} computadoras" + (", clave de red cambiada" if data.clave else ""), ctx.usuario, ctx.empresa.id, ctx.request)
    return _estado_local(s, ctx.empresa.id)


class ProbarIn(BaseModel):
    url: str


@router.post("/local/red/probar")
def red_probar(data: ProbarIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    if not MODO_LOCAL:
        raise HTTPException(400, "Solo en una instalación local")
    e = sc.get(Empresa, ctx.empresa.id)
    cfg = _cfg_local(s, ctx.empresa.id)
    red = cfg.get("red") or {}
    if not red.get("clave"):
        raise HTTPException(400, "Defina primero la clave de red")
    url = data.url.strip().rstrip("/")
    try:
        r = httpx.get(f"{url}/api/sinc/red/{e.numero_id}/ping", headers={"X-Clave-Red": secretos.descifrar(e.clave_cifrada, red["clave"])}, timeout=httpx.Timeout(15, connect=5))
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(502, f"No se pudo conectar con {url}: {ex}")
    if r.status_code != 200:
        try:
            det = r.json().get("detail")
        except Exception:  # noqa: BLE001
            det = r.text[:200]
        raise HTTPException(400, f"{url} respondió {r.status_code}: {det}")
    return r.json()


@router.post("/local/red/ahora")
def red_ahora(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    if not MODO_LOCAL:
        raise HTTPException(400, "Solo en una instalación local")
    sincronizar(ctx.empresa.id, nube=False, red=True)
    return _estado_local(s, ctx.empresa.id)


MINUTOS_LATIDO_RED = 5


def _toca_latido(cur: dict) -> bool:
    """4.9 (R3): una computadora sin nada que mandar igual da señal de vida cada MINUTOS_LATIDO_RED (un envío sin cambios), para que
    las demás no le retomen lo que emitió (cola.retomables): nunca dos emisores a la vez. La primera vez solo anota la hora."""
    ultimo, ahora = _parse(cur.get("latido")), datetime.now(timezone.utc)
    if ultimo and ahora - ultimo < timedelta(minutes=MINUTOS_LATIDO_RED):
        return False
    cur["latido"] = ahora.isoformat(timespec="seconds")
    return ultimo is not None


def _payload_red(s, eid: int, cfg: dict, pc: dict, rango: int) -> dict | None:
    """Lo que esta computadora todavía no le ha mandado a `pc`: comprobantes propios nuevos o con cambio de estado, clientes
    e ítems propios cambiados, y los cambios de registros (de cualquier rango) desde el último envío, con lápidas."""
    cur = pc.setdefault("cursor", {})
    cuerpo = {"terminal": rango, "nombre": cfg.get("nombre") or socket.gethostname(), "version": _version_sistema()}
    hay = False
    # clientes e ítems propios
    if rango:
        huellas = cur.setdefault("huellas", {})
        for modelo, clave in ((Cliente, "clientes"), (Producto, "productos")):
            h = huellas.get(clave) or {}
            filas = [o for o in s.exec(select(modelo)).all() if en_rango(o.id, rango)]
            nuevas, cambiados = {}, []
            for o in filas:
                d = o.model_dump(); hu = _huella(d); nuevas[str(o.id)] = hu
                if h.get(str(o.id)) != hu:
                    cambiados.append(d)
            if cambiados or set(h) - set(nuevas):
                hay = True
                cuerpo[clave] = cambiados; cuerpo[clave + "_vivos"] = [o.id for o in filas]
                cur.setdefault("_huellas_nuevas", {})[clave] = nuevas
    # comprobantes propios: nuevos (id mayor que el último mandado) y los mandados que cambiaron de estado
    doc_id = int(cur.get("doc_id") or 0)
    en_proceso = {int(k): v for k, v in (cur.get("en_proceso") or {}).items()}
    docs = [d for d in s.exec(select(Documento).where(Documento.origen_sinc == None, Documento.id > doc_id).order_by(Documento.id)).all()][:100]  # noqa: E711
    for did, est in list(en_proceso.items()):
        d = s.get(Documento, did)
        if d is None:
            en_proceso.pop(did)
        elif d.estado != est:
            docs.append(d)
    if docs:
        hay = True
        j_ = lambda v: v.isoformat(timespec="seconds") if isinstance(v, datetime) else v  # noqa: E731
        lista = []
        for d in docs:
            dd = {k: j_(getattr(d, k, None)) for k in CAMPOS_DOC}
            dd["lineas"] = [{k: getattr(l, k, None) for k in CAMPOS_LINEA} for l in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == d.id)).all()]
            dd["bodega_id"] = _bodega_del_documento(s, d.id)   # 4.9 (F1): la bodega de la que salió
            if d.cliente_id:
                cl = s.get(Cliente, d.cliente_id)
                dd["cliente_numero_id"] = cl.numero_id if cl else None
            if d.xml_nombre and (XML_DIR / d.xml_nombre).exists():
                dd["xml_b64"] = base64.b64encode((XML_DIR / d.xml_nombre).read_bytes()).decode()
            if d.respuesta_nombre and (XML_DIR / d.respuesta_nombre).exists():
                dd["respuesta_b64"] = base64.b64encode((XML_DIR / d.respuesta_nombre).read_bytes()).decode()
            lista.append(dd)
        cuerpo["documentos"] = lista
        cur["_docs_enviados"] = [(d.id, d.estado, d.clave) for d in docs]
    # registros: cambios desde el último envío (cualquier rango) + vivos propios + lápidas
    desde = _parse(cur.get("registros_desde"))
    if desde:
        desde -= timedelta(seconds=2)
    corte = datetime.now(timezone.utc)
    lapidas = _leer(s, eid, CLAVE_BORRADOS, {})
    enviadas = set(cur.get("claves") or [])
    regs = {}
    for clave in CLAVES_RED:
        r = modulos._registro(s, eid, clave)
        if not r or not r.coleccion:
            continue
        filas = s.exec(select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == eid, modulos.RegistroItem.clave == clave)).all()
        items = []
        for f in filas:
            act = f.actualizado
            if isinstance(act, datetime) and act.tzinfo is None:
                act = act.replace(tzinfo=timezone.utc)
            if desde is None or not isinstance(act, datetime) or act >= desde:
                try:
                    items.append({**json.loads(f.datos), "_actualizado": act.isoformat() if isinstance(act, datetime) else None})
                except ValueError:
                    continue
        borr = [{"id": int(i), "ts": ts} for i, ts in (lapidas.get(clave) or {}).items() if desde is None or (_parse(ts) or corte) >= desde]
        vivos = [f.item_id for f in filas if rango and en_rango(f.item_id, rango)]
        if items or borr or vivos or clave in enviadas:
            regs[clave] = {"items": items, "vivos": vivos if rango else None, "borrados": borr}
            enviadas.add(clave)
    if regs:
        hay = True
        cuerpo["registros"] = regs
    cur["_registros_corte"] = corte.isoformat(timespec="seconds"); cur["_claves"] = sorted(enviadas)
    return cuerpo if (hay or _toca_latido(cur)) else None


def enviar_red(s, e: Empresa, cfg: dict, rango: int) -> None:
    """Manda a cada computadora del local lo que le falta. Cada una lleva su propio cursor; si no contesta, se reintenta."""
    red = cfg.get("red") or {}
    if not red.get("clave") or cfg.get("revocada_en"):
        return
    try:
        clave = secretos.descifrar(e.clave_cifrada, red["clave"])
    except Exception as ex:  # noqa: BLE001
        log.warning("red local: clave ilegible: %s", ex); return
    cab = {"X-Clave-Red": clave}
    revocadas = {int(x) for x in red.get("revocadas") or []}
    for pc in red.get("pcs") or []:
        cur = pc.setdefault("cursor", {})
        if pc.get("terminal") and int(pc["terminal"]) in revocadas:
            pc["ultimo_error"] = "Esa computadora fue revocada en la nube: no se le manda nada"
            continue
        try:
            cuerpo = _payload_red(s, e.id, cfg, pc, rango)
            if cuerpo is None:
                pc["ultimo_error"] = None
                continue
            r = httpx.post(f"{pc['url']}/api/sinc/red/{e.numero_id}/cambios", headers=cab, json=cuerpo, timeout=httpx.Timeout(120, connect=5))
            if r.status_code != 200:
                try:
                    det = r.json().get("detail")
                except Exception:  # noqa: BLE001
                    det = r.text[:200]
                raise RuntimeError(f"respondió {r.status_code}: {det}")
            j = r.json()
            if j.get("terminal"):
                pc["terminal"] = int(j["terminal"])
            if j.get("nombre"):
                pc["nombre_red"] = str(j["nombre"])[:40]        # 4.9 (R3): con este nombre llegan sus comprobantes (origen_sinc); `nombre` es el que se le puso en esta lista
            errores = [f"{x.get('parte') or x.get('clave')}: {x.get('error')}" for x in j.get("errores") or []]
            errores += [f"{k}: {v['error']}" for k, v in (j.get("registros") or {}).items() if isinstance(v, dict) and v.get("error")]
            env = pc.setdefault("enviados", {"documentos": 0, "registros": 0, "catalogos": 0})
            fallidas = {x.get("parte") for x in j.get("errores") or []}
            for clave, nuevas in (cur.pop("_huellas_nuevas", None) or {}).items():
                if clave not in fallidas:
                    cur.setdefault("huellas", {})[clave] = nuevas; env["catalogos"] += int(j.get(clave) or 0)
            ok = set(j.get("documentos") or [])
            en_proceso = {str(k): v for k, v in (cur.get("en_proceso") or {}).items()}
            for did, est, cl in cur.pop("_docs_enviados", None) or []:
                if cl in ok:
                    cur["doc_id"] = max(int(cur.get("doc_id") or 0), did); env["documentos"] += 1
                    if est in ESTADOS_FINALES:
                        en_proceso.pop(str(did), None)
                    else:
                        en_proceso[str(did)] = est
            cur["en_proceso"] = en_proceso
            if not any(isinstance(v, dict) and v.get("error") for v in (j.get("registros") or {}).values()):
                cur["registros_desde"] = cur.pop("_registros_corte", None) or cur.get("registros_desde")
                cur["claves"] = cur.pop("_claves", None) or cur.get("claves") or []
            else:
                cur.pop("_registros_corte", None); cur.pop("_claves", None)
            env["registros"] += sum(int(v.get("altas", 0)) + int(v.get("cambios", 0)) + int(v.get("bajas", 0)) for v in (j.get("registros") or {}).values() if isinstance(v, dict))
            pc["ultimo_ok"] = _ahora(); pc["ultimo_error"] = "; ".join(errores)[:300] if errores else None
        except Exception as ex:  # noqa: BLE001
            cur.pop("_huellas_nuevas", None); cur.pop("_docs_enviados", None); cur.pop("_registros_corte", None); cur.pop("_claves", None)
            pc["ultimo_error"] = f"{_ahora()[:19]} {str(ex)[:200]}"
            log.info("red local: %s: %s", pc.get("nombre"), ex)


# ======================================================================================================================
# INSTALACIÓN REVOCADA: aviso, bloqueo a los 3 días (con respaldo) y borrado de sus datos a los 30 (3.15)
# ======================================================================================================================
_inst_estado: dict[int, dict] = {}       # {eid: {revocada_en, bloqueada_en, nombre}}: lo consultan los ganchos de auth en cada petición
_eliminar: list[int] = []                # empresas cuyos datos se borran al cerrar la sesión de sincronización


def _cargar_estado(eid: int, cfg: dict) -> None:
    _inst_estado[eid] = {"revocada_en": cfg.get("revocada_en"), "bloqueada_en": cfg.get("bloqueada_en"), "nombre": cfg.get("nombre"),
                         "sin_acceso_desde": cfg.get("sin_acceso_desde"), "sin_acceso_motivo": cfg.get("sin_acceso_motivo"),
                         "ultima_bajada": cfg.get("ultima_bajada")}         # 4.9 (E1/E4): para fecha_confirmada
    if cfg.get("terminal"):          # 4.9 (5c): vinculada alguna vez: la terminal y la sucursal quedan fijas
        _fijas[eid] = {"terminal": int(cfg["terminal"]), "sucursal": int(cfg["sucursal"]) if cfg.get("sucursal") else None}
    else:
        _fijas.pop(eid, None)


def _normalizar_revocacion(cfg: dict) -> bool:
    """4.9 (5a): una «revocación» anotada sin la señal explícita de la nube (las versiones anteriores tomaban cualquier 401/403
    como revocación: una empresa bloqueada por cobro o el cortafuegos del hosting bastaban) pasa a «sin acceso a la nube»: se
    quitan la revocación y el bloqueo (el respaldo se conserva), no se borra nada y se vuelve a preguntar a la nube. Si la nube
    la revocó de verdad, lo dirá con su código y empieza de nuevo el plazo. Devuelve si cambió algo."""
    if not cfg.get("revocada_en") or cfg.get("revocacion_explicita"):
        return False
    cfg["sin_acceso_desde"] = cfg.get("sin_acceso_desde") or cfg["revocada_en"]
    cfg["sin_acceso_motivo"] = "Una versión anterior tomó un acceso negado de la nube como revocación; solo cuenta la revocación explícita de la nube"
    cfg.pop("revocada_en", None); cfg.pop("bloqueada_en", None)
    return True


def sin_acceso(eid: int):
    """4.9: {desde, motivo} si la nube niega el acceso a esta instalación sin haberla revocado (para una franja de aviso); si no, None."""
    st = _inst_estado.get(eid) or {}
    if not st.get("sin_acceso_desde") or st.get("revocada_en"):
        return None
    return {"desde": st.get("sin_acceso_desde"), "motivo": st.get("sin_acceso_motivo")}


def bloqueada(eid: int) -> bool:
    return bool((_inst_estado.get(eid) or {}).get("bloqueada_en"))


def fecha_confirmada(eid: int, fecha, dias_gracia: int = 0) -> bool:
    """4.9 (E1/E4): ¿la nube confirmó esta fecha del plan (vence o prueba_hasta) DESPUÉS de que pasó? En la instalación local esas
    fechas son una copia de la nube y pueden estar viejas: la empresa pudo pagar (la nube borra la prueba y corre el vencimiento)
    mientras esta computadora no tenía internet o la nube le negaba el acceso. Cuenta como confirmada si la última bajada buena de
    la nube (que trae las fechas vigentes, también vacías) es de un día posterior a la fecha. Sin confirmación la computadora sigue
    trabajando: nunca deja de vender por una fecha que la nube pudo haber borrado (contrato 5a: sin acceso a la nube se sigue
    trabajando). Confirmada, queda como en la web (plan vencido: solo lectura; prueba vencida: sin acceso). En la nube siempre vale."""
    if not MODO_LOCAL:
        return True
    v = str(fecha or "")[:10]
    if not v:
        return False
    # 4.28 (P-7): con días de gracia del plan (los que bajó la nube), la espera sin conexión es el mayor entre 7 y esos días, y la nube
    # tiene que confirmar la fecha después de terminada la gracia
    gracia = max(0, int(dias_gracia or 0))
    try:                                                                 # etapa 1 (decisión 11): sin conexión, hasta 7 días de gracia después de la fecha
        if (ahora_cr().date() - datetime.fromisoformat(v).date()).days > max(DIAS_GRACIA_PLAN, gracia) and vinculada(eid):   # sin vincular no hay nube que confirme: tiene que poder vincularse
            return True
        if gracia:
            v = (datetime.fromisoformat(v).date() + timedelta(days=gracia)).isoformat()
    except ValueError:
        return False
    st = _inst_estado.get(eid)
    if st is None:
        try:
            with Session(engine_empresa(eid)) as s:
                ub = _cfg_local(s, eid).get("ultima_bajada")
        except Exception:  # noqa: BLE001
            return False
    else:
        ub = st.get("ultima_bajada")
    d = _parse(ub)
    return bool(d) and d.astimezone(TZ_CR).date().isoformat() > v


_prueba_vencida_nube = _auth.prueba_vencida


def _prueba_vencida_local(e) -> bool:
    """4.9 (E1): en la instalación local, la prueba gratis vencida solo cierra el acceso si la nube lo confirmó (fecha_confirmada).
    Con la copia vieja de una empresa que ya pagó, todo usuario recibía 403 «Su prueba gratis terminó» hasta que la computadora
    volviera a llegar a la nube. Reemplaza a auth.prueba_vencida en la instalación (la usan auth.contexto y la información de la sesión)."""
    return _prueba_vencida_nube(e) and fecha_confirmada(e.id, e.prueba_hasta)


def _revisar_revocada(sc, e: Empresa, cfg: dict) -> bool:
    """Instalación revocada: al cumplirse DIAS_BLOQUEO se bloquea (con respaldo); al cumplirse DIAS_BORRADO del bloqueo devuelve
    True para que se borren sus datos."""
    ahora = datetime.now(timezone.utc)
    rev, bloq = _parse(cfg.get("revocada_en")), _parse(cfg.get("bloqueada_en"))
    if rev and not bloq and ahora >= rev + timedelta(days=DIAS_BLOQUEO):
        cfg["bloqueada_en"] = _ahora()
        try:
            from . import respaldo
            cfg["respaldo"] = str(respaldo.ejecutar())
        except Exception as ex:  # noqa: BLE001
            cfg["respaldo"] = None; log.warning("sinc: respaldo al bloquear la empresa %s: %s", e.id, ex)
        auditar(sc, "sinc_local_bloqueada", f"Instalación revocada hace {DIAS_BLOQUEO} días: la empresa queda bloqueada en esta computadora (respaldo: {cfg.get('respaldo') or 'no se pudo'})", None, e.id, None)
        bloq = _parse(cfg["bloqueada_en"])
    _cargar_estado(e.id, cfg)
    return bool(bloq and ahora >= bloq + timedelta(days=DIAS_BORRADO))


def _eliminar_datos(eid: int) -> None:
    """Borra la base y la llave de la empresa en esta computadora (el respaldo del bloqueo se conserva) y la deja bloqueada."""
    from .db import EMPRESAS_DIR, _engines
    try:
        with Session(engine) as sc:
            e = sc.get(Empresa, eid)
            if e is None:
                return
            if e.p12_nombre:
                (CERT_DIR / e.p12_nombre).unlink(missing_ok=True)
            e.bloqueada = True; e.bloqueo_motivo = f"Instalación revocada en la nube: sus datos en esta computadora se borraron el {ahora_cr():%d/%m/%Y}."
            e.usuario_hacienda = None; e.password_hacienda = None; e.p12_nombre = None; e.p12_pin = None
            sc.add(e); sc.commit()
            auditar(sc, "sinc_local_eliminada", "Datos de la empresa borrados en esta computadora (instalación revocada hace más de 30 días)", None, eid, None)
        hit = _engines.pop(eid, None)
        if hit is not None:
            hit[0].dispose()
        for suf in ("", "-wal", "-shm"):
            (EMPRESAS_DIR / f"empresa_{eid}.db{suf}").unlink(missing_ok=True)
        _inst_estado[eid] = {"revocada_en": _ahora(), "bloqueada_en": _ahora(), "eliminada": True}
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc: no se pudieron borrar los datos de la empresa %s: %s", eid, ex)


# ======================================================================================================================
# 4.25 (X2, LADO DEL PROGRAMA): ingreso diario con la cuenta de la web
# ======================================================================================================================
# Ganchos de auth (los instala el programa local, abajo): el ingreso de quien viene de la nube (o no existe aquí) se pregunta a la web
# por /api/sinc/ingreso, SOLO a URL_NUBE (D-J: _valida_en_linea), con el token de cada empresa vinculada donde la persona es miembro
# (o de todas si aquí no existe) hasta la primera que la reconozca (D-K). Cómo se lee la respuesta (D-G): un sobre válido se obedece y
# un «rechazado» nunca cae a lo guardado; sin respuesta (red, tiempo, 5xx, algo que no es el sobre, instalación revocada o token no
# reconocido) se valida con lo guardado (D-I: solo quien tiene aquí un hash utilizable; quien usa dos pasos no entra sin internet en
# esta versión); 429 y 422 (y el sobre «rechazado» con motivo «tope» o «error») no entran, tras un reintento; 404 o 405, con lo
# guardado solo si la web anotada es anterior a la 4.25. Las cuentas creadas en esta computadora siguen el camino de siempre (D-M).
# Nunca se anotan la contraseña ni el código: al registro solo va el tipo del error; las respuestas de la web no se copian.
VERSION_INGRESO = (4, 25)                                  # la versión de la web que trae las rutas de ingreso del programa (D-G e)
MINUTOS_USUARIOS = 10                                      # D-F: aviso si la última bajada de usuarios buena es más vieja, habiendo internet
NO_CONFIRMADO = "No se pudo confirmar su ingreso; intente de nuevo."
SIN_CONEXION_CODIGO = "No se pudo comprobar el código porque se fue la conexión. Intente de nuevo."
SIN_INTERNET_MFA = ("Sin internet no podemos pedirle su código de verificación. Sin internet solo puede entrar desde un navegador donde ya "
                    "haya entrado con internet y con su código en los últimos 30 días; desde este, vuelva a intentar cuando haya internet.")
OTRA_DIRECCION = "Esta computadora está conectada a otra dirección; vuelva a conectarla."
SIN_VALIDAR_AQUI = "Para entrar sin internet en esta computadora, primero tiene que haber entrado aquí una vez con internet."
SIN_CONECTAR_AQUI = ("Esta computadora no está conectada a la página web y aquí no quedó guardado su ingreso. Un administrador tiene que "
                     "conectarla de nuevo en Configuración › Instalación local.")          # 4.25 (9c, P7)
_TIEMPO_AGOTADO = httpx.TimeoutException                   # se toma aquí: las pruebas sustituyen httpx
_RUTA_INGRESO, _RUTA_DOS_PASOS, _RUTA_FICHA, _RUTA_USUARIOS = "/api/sinc/ingreso", "/api/sinc/ingreso/dos-pasos", "/api/sinc/usuario", "/api/sinc/usuarios"


def _version_tupla(v) -> tuple:
    try:
        return tuple(int(x) for x in str(v or "").strip().split(".")[:2])
    except ValueError:
        return ()


def _nube_anterior(cfg: dict) -> bool:
    """D-G (e): la versión de la web anotada en la última bajada de usuarios es anterior a la que trae las rutas de ingreso. Sin versión
    anotada (nunca contestó la bajada liviana, que solo tiene una web 4.25 o posterior) cuenta como anterior."""
    v = _version_tupla(cfg.get("version_nube"))
    return not v or v < VERSION_INGRESO


def _contacto_reciente(cfg: dict) -> bool:
    """La sincronización habló con la web en los últimos 5 minutos (para un reintento tras un tiempo agotado)."""
    if cfg.get("sin_conexion_desde"):
        return False
    fechas = [d for d in (_parse(cfg.get(k)) for k in ("ultima_bajada", "ultima_subida", "usuarios_bajada")) if d]
    return bool(fechas) and (datetime.now(timezone.utc) - max(fechas)).total_seconds() < 300


def usuarios_atrasados(cfg: dict, bloqueada: bool = False) -> bool:
    """D-F: habiendo internet (la sincronización no anotó sin_conexion_desde), la última bajada de usuarios buena tiene más de
    MINUTOS_USUARIOS minutos (o no hubo ninguna desde la vinculación). Solo en una computadora que valida en línea.
    4b (Q5): tampoco cuando `sincronizar` sale antes de la bajada liviana por una razón que ya tiene su propio aviso: la instalación
    revocada (revocada_en: franja de instalación revocada) o la empresa bloqueada en esta computadora (`bloqueada`: el aviso del
    bloqueo; quien llama pasa Empresa.bloqueada)."""
    if not cfg.get("vinculado") or cfg.get("sin_conexion_desde") or not _valida_en_linea(cfg):
        return False
    if cfg.get("revocada_en") or bloqueada:
        return False
    d = _parse(cfg.get("usuarios_bajada")) or _parse(cfg.get("vinculada_en"))
    return not d or (datetime.now(timezone.utc) - d).total_seconds() > MINUTOS_USUARIOS * 60


def _es_sobre(j) -> bool:
    return isinstance(j, dict) and j.get("servicio") == SERVICIO_INGRESO and j.get("ingreso") in ("ok", "dos_pasos", "rechazado", "sin_acceso")


def _cabecera_ingreso(token: str) -> dict:
    return {"Authorization": "Bearer " + token, CABECERA_INGRESO: str(PROTOCOLO_INGRESO)}


def _vinculadas() -> list:
    """Las empresas vinculadas de esta computadora: [(eid, cfg, token)]. Una que no se puede leer no cuenta."""
    salida = []
    try:
        with Session(engine) as sc:
            empresas = [(e.id, e.clave_cifrada) for e in sc.exec(select(Empresa)).all()]
    except Exception as ex:  # noqa: BLE001
        log.warning("Ingreso del programa: no se pudieron leer las empresas (%s)", type(ex).__name__)
        return salida
    for eid, clave in empresas:
        try:
            with Session(engine_empresa(eid)) as s:
                cfg = _cfg_local(s, eid)
            if cfg.get("vinculado") and cfg.get("token") and cfg.get("url") and not cfg.get("revocada_en"):
                salida.append((eid, cfg, secretos.descifrar(clave, cfg["token"])))
        except Exception as ex:  # noqa: BLE001
            log.warning("Ingreso del programa: la vinculación de la empresa %s no se pudo leer (%s)", eid, type(ex).__name__)
    return salida


def _preguntar(cfg: dict, token: str, ruta: str, cuerpo: dict, plazo: float = 10.0) -> tuple:
    """Una llamada de ingreso a la web (solo a URL_NUBE) y cómo leerla (D-G): ("sobre", j), ("guardado", motivo) o ("no_entra", mensaje).
    Reintenta una vez ante 429, 422 o el sobre «rechazado» con motivo «tope» o «error», y tras un tiempo agotado si la sincronización
    tuvo contacto hace poco. Nada de la respuesta ni del cuerpo va al registro."""
    espera = httpx.Timeout(plazo, connect=2.0 if cfg.get("sin_conexion_desde") else 4.0)
    for intento in range(2):
        try:
            r = httpx.post(URL_NUBE.rstrip("/") + ruta, headers=_cabecera_ingreso(token), json=cuerpo, timeout=espera)
        except _ERROR_RED as ex:
            if isinstance(ex, _TIEMPO_AGOTADO) and intento == 0 and _contacto_reciente(cfg):
                continue
            log.info("Ingreso del programa: sin respuesta de la web (%s)", type(ex).__name__)
            return ("guardado", "sin internet")
        except Exception as ex:  # noqa: BLE001
            log.info("Ingreso del programa: la web no atendió (%s)", type(ex).__name__)
            return ("guardado", "la web no atendió")
        estado = getattr(r, "status_code", 0)
        j = None
        if estado == 200:
            try:
                j = r.json()
            except Exception:  # noqa: BLE001
                j = None
        if estado == 200 and _es_sobre(j):
            if j["ingreso"] == "rechazado" and j.get("motivo") in ("tope", "error"):
                if intento == 0:
                    continue
                return ("no_entra", str(j.get("mensaje") or NO_CONFIRMADO)[:300])
            return ("sobre", j)
        if estado in (429, 422):
            if intento == 0:
                continue
            log.info("Ingreso del programa: la web respondió %s", estado)
            return ("no_entra", NO_CONFIRMADO)
        if 400 <= estado < 500 and _codigo_nube(r) == CODIGO_REVOCADA:
            return ("guardado", "instalación revocada")
        if estado in (404, 405):
            log.info("Ingreso del programa: la web respondió %s", estado)
            return ("guardado", "web anterior") if _nube_anterior(cfg) else ("no_entra", NO_CONFIRMADO)
        log.info("Ingreso del programa: respuesta que no es de la web (%s)", estado)
        return ("guardado", "la web no atendió")
    return ("guardado", "sin internet")


def _ficha_de(cfg: dict, token: str, correo: str):
    """D-H: la ficha de una persona en la empresa de esa vinculación (POST /api/sinc/usuario, correo en el cuerpo). Devuelve el sobre
    «ok» ({miembro, usuario}) o None si no se pudo saber."""
    tipo, j = _preguntar(cfg, token, _RUTA_FICHA, {"correo": correo}, plazo=5.0)
    return j if tipo == "sobre" and j.get("ingreso") == "ok" and isinstance(j.get("miembro"), bool) else None


def _quitar_membresia(s, u, eid: int) -> None:
    m = s.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id, _auth.UsuarioEmpresa.empresa_id == eid)).first()
    if m is not None:
        s.delete(m); s.commit()
    _auth._revocar_sesiones(s, u.id)


def _rechazo_credenciales(s, request, u, correo: str, password: str, eids: list, vinc: dict) -> None:
    """D-H y D-K: la web contestó «credenciales» en empresas donde la persona es miembro aquí. Se pide su ficha en cada una: si ya no
    es miembro, se quita SOLO esa membresía (su «credenciales» no dice nada de la contraseña); si lo es, se aplica la ficha. Si alguna
    empresa donde sigue siendo miembro (o de la que no se pudo saber) la rechazó y la contraseña escrita todavía coincide con lo guardado
    (la cambiaron en la web y aún no bajó), lo guardado deja de servir y se cierran sus sesiones. Se compara con lo que había guardado
    ANTES de aplicar las fichas: una ficha que solo trae el hash inservible (D-E) ya no cierra sesiones por sí sola (_aplicar_usuario)."""
    invalidar, antes = False, u.password_hash or HASH_INSERVIBLE
    for eid in eids:
        cfg, token = vinc[eid]
        try:
            j = _ficha_de(cfg, token, correo)
            if j is not None and j["miembro"] is False:
                _quitar_membresia(s, u, eid)
                continue
            invalidar = True
            if j is not None and isinstance(j.get("usuario"), dict) and str(j["usuario"].get("correo") or "").lower().strip() == correo:
                _aplicar_usuario(s, eid, j["usuario"]); s.commit()
        except Exception as ex:  # noqa: BLE001
            invalidar = True
            s.rollback(); log.warning("Ingreso del programa: no se pudo aplicar la ficha (%s)", type(ex).__name__)
    s.refresh(u)
    if invalidar and antes != HASH_INSERVIBLE and u.password_hash in (antes, HASH_INSERVIBLE) and _auth.verificar_password(password, antes):
        if u.password_hash != HASH_INSERVIBLE:
            _poner_password(u, HASH_INSERVIBLE); s.add(u); s.commit()        # 9b (D-Q): con su huella (el real que llegue después será otro)
        _auth._revocar_sesiones(s, u.id)
        auditar(s, "login_rechazado", "La web rechazó una contraseña que esta computadora tenía guardada: lo guardado deja de servir y se cerraron sus sesiones", u, request=request)


def _bajando(s, u) -> bool:
    """4.25 (tanda 6, E-11): la persona es miembro de una empresa conectada aquí por primera vez que todavía no terminó su primera
    bajada buena (marca «primera» de _aplicar_conexion: computadora recién conectada; los hash llegan con la bajada o con el ingreso en
    línea)."""
    for m in s.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id)).all():
        try:
            with Session(engine_empresa(m.empresa_id)) as se:
                cfg = _cfg_local(se, m.empresa_id)
        except Exception:  # noqa: BLE001
            continue
        if cfg.get("vinculado") and isinstance(cfg.get("primera"), dict) and not cfg.get("ultima_bajada"):
            return True
    return False


MOTIVOS_SIN_RESPUESTA = ("sin internet", "la web no atendió")       # 4.25 (9c, P7): la web se consultó y no contestó


def _sin_validar(motivo: str) -> str:
    """4.25 (9c, P7): el texto del 403 de quien no puede entrar con lo guardado (sin contar fallo). SIN_VALIDAR_AQUI solo cuando la web se
    consultó y no contestó; si no se consultó porque esta computadora no está conectada (sin vinculación, instalación revocada, otra
    dirección, la web no reconoció esta computadora, web anterior), SIN_CONECTAR_AQUI."""
    return SIN_VALIDAR_AQUI if motivo in MOTIVOS_SIN_RESPUESTA else SIN_CONECTAR_AQUI


def _con_lo_guardado(s, request, u, password: str, estado: dict, motivo: str, exigir_validado: bool = False):
    """D-I: sin respuesta de la web, entra solo quien tiene aquí un hash utilizable (ya entró en línea en esta computadora); la contraseña
    temporal no entra sin internet. Quien usa los dos pasos de la web entra solo desde un navegador con la marca vigente de que ya pasó su
    código ahí con internet (auth.mfa_aqui_vigente, tanda 4); desde otro navegador, no. A quien la web le exige los dos pasos y no los
    tiene, no entra. Revisión de las tandas 3 y 4: si la web todavía no dijo que la persona usa los suyos (sin huella: computadora
    conectada a otra dirección, sin vinculación, web anterior o sin internet desde antes de la primera ficha) y aquí tiene activos los
    dos pasos de ESTA computadora (el programa se los exigía antes de la 4.25), la contraseña sola no entra: se devuelve el segundo
    paso de aquí (token «mfa» de siempre, que resuelve auth.mfa_verificar) con la marca de que la sesión se abre con lo guardado.
    4b (Q2, D-I explícita): con `exigir_validado` (alguna empresa candidata valida en línea contra una web 4.25 o posterior) entra solo
    quien ya tiene nube_validado; si no, 403 SIN_VALIDAR_AQUI, sin contar fallo y después de comprobar la contraseña."""
    if u is None:
        _auth._verificar_lento(password, None)
        return None
    if not _hash_utilizable(u.password_hash) and _bajando(s, u):
        # 4.25 (tanda 6, E-11): su hash todavía no bajó a esta computadora recién conectada: no es un fallo (ni se puede comprobar)
        _auth._verificar_lento(password, None)
        raise HTTPException(503, MENSAJE_BAJANDO)
    if u.de_nube and not _hash_utilizable(u.password_hash):
        # 4.25 (9b, D-R): viene de la web y aquí solo tiene la contraseña inservible (nunca entró en línea en esta computadora, o la
        # política se la quitó): sin la web no hay nada que comprobar ni contraseña que adivinar. Se dice el motivo, sin contar fallo, y
        # gastando el mismo tiempo que una comprobación. (Dice que el correo existe en esta computadora: el PIN ya lo decía.)
        _auth._verificar_lento(password, None)
        raise HTTPException(403, _sin_validar(motivo))
    if not _auth._verificar_lento(password, u.password_hash or HASH_INSERVIBLE):
        return None
    if u.temporal_nube:
        raise HTTPException(403, MENSAJES_INGRESO["temporal"])
    if exigir_validado and not u.nube_validado:
        raise HTTPException(403, _sin_validar(motivo))
    if u.mfa_nube:
        if not _auth.mfa_aqui_vigente(request, u):
            raise HTTPException(403, SIN_INTERNET_MFA)
    elif u.mfa_entrar_nube:
        raise HTTPException(403, MENSAJES_INGRESO["dos_pasos_falta"])
    estado["sin_nube"] = True
    if motivo == "otra dirección":
        estado["aviso"] = OTRA_DIRECCION
        estado["detalle"] = "Sin confirmar con la web (esta computadora está conectada a otra dirección): validado con lo guardado en esta computadora"
    elif motivo == "sin internet":
        estado["detalle"] = "Sin internet: validado con lo guardado en esta computadora"
    else:
        estado["detalle"] = f"Sin confirmar con la web ({motivo}): validado con lo guardado en esta computadora"
    if u.mfa_activo and not u.mfa_nube:                                  # los dos pasos de esta computadora siguen valiendo (ver arriba)
        if u.bloqueado:                                                  # como en el ingreso de siempre: antes de pedir el código
            auditar(s, "login_rechazado", "Cuenta bloqueada por el administrador", u, request=request)
            raise HTTPException(403, MENSAJES_INGRESO["bloqueado"])
        return {"mfa_requerido": True,
                "token_mfa": _auth.firmar({"tipo": "mfa", "uid": u.id, "sin_nube": True, "detalle": estado["detalle"]}, _auth.DURACION_MFA)}
    return u


def _aceptar_ficha(s, eid: int, j: dict, correo: str, password: str | None):
    """Sobre «ok»: la ficha tiene que ser del correo escrito y, en el primer paso, la contraseña escrita tiene que coincidir con el hash
    recibido; si no, no se guarda nada y no entra. Si cuadra, se aplica (crea a la persona si aquí no existía) y queda nube_validado."""
    f = j.get("usuario")
    if (not isinstance(f, dict) or str(f.get("correo") or "").lower().strip() != correo
            or (password is not None and not _auth.verificar_password(password, str(f.get("password_hash") or "")))):
        log.warning("Ingreso del programa: la web contestó «ok» con una ficha que no cuadra")
        raise HTTPException(503, NO_CONFIRMADO)
    u = _aplicar_usuario(s, eid, f)
    if u is None:
        raise HTTPException(503, NO_CONFIRMADO)
    u.nube_validado = datetime.now(timezone.utc)
    s.add(u); s.commit(); s.refresh(u)
    _quitar_primera(eid)                                                 # 4.25 (E-10): alguien ya entró: la conexión ya no se deshace
    return u


def _solo_de_revocadas(u, miembro_de: set, vinc: dict) -> bool:
    """4.25 (corrección de la 9c): en una computadora con varias empresas, la persona existe aquí y, de las empresas donde es miembro,
    ninguna está conectada y alguna tiene la conexión revocada (la que _vinculadas no cuenta). Su ingreso NO se pregunta a la web con la
    llave de otra empresa: esa no la reconoce («credenciales» sin mirar la contraseña), y aquí y en la web se le contarían fallos hasta
    dejarla esperando 15 minutos. Sigue el camino de una computadora que no está conectada (_con_lo_guardado)."""
    if u is None or not vinc or any(eid in vinc for eid in miembro_de):
        return False
    for eid in miembro_de:
        try:
            with Session(engine_empresa(eid)) as se:
                cfg = _cfg_local(se, eid)
        except Exception:  # noqa: BLE001
            continue
        if cfg.get("vinculado") and cfg.get("revocada_en"):
            return True
    return False


def _comprobar_en_nube(s, request, correo: str, password: str, u, estado: dict):
    """El `comprobar` de auth.validar_ingreso para quien viene de la nube o no existe aquí (ver arriba)."""
    vinc = {eid: (cfg, token) for eid, cfg, token in _vinculadas()}
    miembro_de = set()
    if u is not None:
        miembro_de = {m.empresa_id for m in s.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id)).all()}
    candidatas = [eid for eid in vinc if eid in miembro_de] or list(vinc)
    revocada = _solo_de_revocadas(u, miembro_de, vinc)                   # corrección de la 9c: no se pregunta con la llave de otra empresa
    guardado, rechazos = ("instalación revocada" if revocada else None), []
    for eid in ([] if revocada else candidatas):
        cfg, token = vinc[eid]
        if not _valida_en_linea(cfg):                                    # D-J: la contraseña solo va a URL_NUBE
            guardado = guardado or "otra dirección"
            continue
        tipo, j = _preguntar(cfg, token, _RUTA_INGRESO, {"correo": correo, "password": password})
        if tipo == "no_entra":
            raise HTTPException(503, j)
        if tipo == "guardado":
            guardado = guardado or j
            continue
        if j["ingreso"] == "ok":
            estado["detalle"] = "Validado en la web"
            return _aceptar_ficha(s, eid, j, correo, password)
        if j["ingreso"] == "dos_pasos":
            if not isinstance(j.get("token"), str) or not j["token"]:
                raise HTTPException(503, NO_CONFIRMADO)
            return {"mfa_requerido": True, "token_mfa": _auth.firmar({"tipo": _auth.TIPO_MFA_NUBE, "t": j["token"], "eid": eid, "correo": correo}, _auth.DURACION_MFA)}
        if j["ingreso"] == "sin_acceso":                                 # token no reconocido: como en la 4.9 (D-G d)
            guardado = guardado or "la web no reconoció esta computadora"
            continue
        motivo, mensaje = j.get("motivo"), str(j.get("mensaje") or "")[:300]
        if motivo == "credenciales":
            if u is not None and eid in miembro_de:
                rechazos.append(eid)
            continue
        miembro = u is not None and eid in miembro_de
        if motivo == "bloqueado":                                        # 4.25 (9b, U8): también en la auditoría de esta computadora
            auditar(s, "login_rechazado", "Cuenta bloqueada por el administrador", u, request=request, correo=None if u is not None else correo[:254])
        if motivo == "bloqueado" and miembro:
            u.bloqueado = True; s.add(u); s.commit()
            _auth._revocar_sesiones(s, u.id)
        elif motivo == "temporal" and miembro:
            u.temporal_nube = True; s.add(u); s.commit()
        raise HTTPException(429 if motivo == "espera" else 401 if motivo in ("codigo", "vencido") else 403,
                            mensaje or MENSAJES_INGRESO.get(motivo or "", NO_CONFIRMADO))
    if rechazos:
        _rechazo_credenciales(s, request, u, correo, password, rechazos, vinc)
        return False
    if guardado is not None or not vinc:
        # 4b (Q2): si alguna candidata valida en línea contra una web 4.25 o posterior, lo guardado solo vale a quien ya entró aquí en línea
        exigir = any(_valida_en_linea(vinc[eid][0]) and not _nube_anterior(vinc[eid][0]) for eid in candidatas)
        return _con_lo_guardado(s, request, u, password, estado, guardado or "sin vinculación", exigir_validado=exigir)
    return False


def _ingreso_nube(s, request, response, data):
    """Gancho auth.ingreso_nube (login). None = camino de siempre (cuenta creada en esta computadora, D-M)."""
    correo = (data.correo or "").lower().strip()
    u = s.exec(select(_auth.Usuario).where(_auth.Usuario.correo == correo)).first() if correo else None
    if u is not None and not u.de_nube:
        if _auth._cuenta_local_retirada(s, u) is True and any(_valida_en_linea(cfg) for _e, cfg, _t in _vinculadas()):
            return _ingreso_cuenta_retirada(s, request, response, data, correo)     # 4.25 (9b, U4)
        return None
    estado: dict = {}
    password = data.password or ""
    r = _auth.validar_ingreso(s, request, data.correo, password, data.turnstile,
                              comprobar=lambda ul: _comprobar_en_nube(s, request, correo, password, ul, estado))
    if isinstance(r, dict):
        return r
    salida = _auth._entrar(s, r, request, response, sin_nube=bool(estado.get("sin_nube")), detalle=estado.get("detalle"))
    if estado.get("aviso"):
        salida["aviso_ingreso"] = estado["aviso"]
    return salida


def _web_o_local(s, request, correo: str, password: str, u, estado: dict):
    """4.25 (9b, U4): el `comprobar` de auth.validar_ingreso para una cuenta creada en esta computadora que ya está retirada (E-13), con
    alguna empresa vinculada que valida en línea. Primero se pregunta a la web con lo que escribió: si la acepta, sigue el camino de quien
    viene de la web (_aceptar_ficha: la cuenta queda convertida, como en la bajada); si pide su segundo paso, el token de la web. Si la web
    la rechaza por credenciales, no contesta o no confirma, sigue el camino local de siempre (la contraseña de esta computadora; quien
    llama termina en el 403 de cuenta retirada o en el 401): ese rechazo no cuenta fallo por sí solo ni deja nada inservible. Otro
    rechazo de la web con la contraseña de la web (bloqueo, espera, temporal, dos pasos que faltan) no entra, con el mensaje de la web."""
    vinc = {eid: (cfg, token) for eid, cfg, token in _vinculadas()}
    miembro_de = {m.empresa_id for m in s.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id)).all()}
    for eid in [e for e in vinc if e in miembro_de] or list(vinc):
        cfg, token = vinc[eid]
        if not _valida_en_linea(cfg):                                    # D-J: la contraseña solo va a URL_NUBE
            continue
        tipo, j = _preguntar(cfg, token, _RUTA_INGRESO, {"correo": correo, "password": password})
        if tipo != "sobre":
            continue
        if j["ingreso"] == "ok":
            estado["detalle"] = "Validado en la web (la cuenta creada en esta computadora queda como cuenta de la web)"
            return _aceptar_ficha(s, eid, j, correo, password)
        if j["ingreso"] == "dos_pasos":
            if not isinstance(j.get("token"), str) or not j["token"]:
                raise HTTPException(503, NO_CONFIRMADO)
            return {"mfa_requerido": True, "token_mfa": _auth.firmar({"tipo": _auth.TIPO_MFA_NUBE, "t": j["token"], "eid": eid, "correo": correo}, _auth.DURACION_MFA)}
        motivo = j.get("motivo")
        if j["ingreso"] == "rechazado" and motivo in ("bloqueado", "espera", "temporal", "dos_pasos_falta"):
            if motivo == "bloqueado":
                auditar(s, "login_rechazado", "Cuenta bloqueada por el administrador (según la página web)", u, request=request)
            raise HTTPException(429 if motivo == "espera" else 403, str(j.get("mensaje") or "")[:300] or MENSAJES_INGRESO.get(motivo, NO_CONFIRMADO))
    return u if _auth._verificar_lento(password, u.password_hash) else None


def _ingreso_cuenta_retirada(s, request, response, data, correo: str):
    """4.25 (9b, U4): ingreso de una cuenta creada aquí y ya retirada (ver _web_o_local). El tope general se cuenta una sola vez."""
    estado: dict = {}
    password = data.password or ""
    r = _auth.validar_ingreso(s, request, data.correo, password, data.turnstile,
                              comprobar=lambda ul: _web_o_local(s, request, correo, password, ul, estado))
    if isinstance(r, dict):
        return r
    if not r.de_nube:                                                    # camino local de siempre (auth.login): termina en el 403 de cuenta retirada
        _auth._rechazar_cuenta_local(s, r, request)
        if r.mfa_activo:
            return {"mfa_requerido": True, "token_mfa": _auth.firmar({"tipo": "mfa", "uid": r.id}, _auth.DURACION_MFA)}
        return _auth._entrar(s, r, request, response)
    return _auth._entrar(s, r, request, response, detalle=estado.get("detalle"))


def _dos_pasos_nube(s, request, response, datos: dict, codigo: str):
    """Gancho auth.dos_pasos_nube (mfa/verificar con el token «mfa_nube»): el código se comprueba en la web, nunca aquí ni con lo guardado.
    Sin respuesta de la web: «se fue la conexión» (no entra)."""
    eid, correo, tok = datos.get("eid"), str(datos.get("correo") or ""), datos.get("t")
    vinc = {e: (cfg, token) for e, cfg, token in _vinculadas()}
    if eid not in vinc or not isinstance(tok, str) or not _valida_en_linea(vinc[eid][0]):
        raise HTTPException(401, "El tiempo para el segundo factor expiró; inicie sesión de nuevo")
    cfg, token = vinc[eid]
    tipo, j = _preguntar(cfg, token, _RUTA_DOS_PASOS, {"token": tok, "codigo": (codigo or "")[:64]})
    if tipo != "sobre" or j["ingreso"] in ("sin_acceso", "dos_pasos"):
        raise HTTPException(503, SIN_CONEXION_CODIGO if tipo != "no_entra" else j)
    if j["ingreso"] == "ok":
        u = _aceptar_ficha(s, eid, j, correo, None)
        if u.bloqueado:
            raise HTTPException(403, MENSAJES_INGRESO["bloqueado"])
        salida = _auth._entrar(s, u, request, response, detalle="Validado en la web (con su código de verificación)")
        _auth.marcar_mfa_aqui(request, response, u)                     # tanda 4 (D-I): este navegador ya pasó su código aquí con internet
        return salida
    motivo, mensaje = j.get("motivo"), str(j.get("mensaje") or "")[:300]
    if motivo in ("codigo", "vencido", "credenciales"):
        u = s.exec(select(_auth.Usuario).where(_auth.Usuario.correo == correo)).first() if correo else None
        auditar(s, "mfa_fallido", "La web rechazó el código de verificación", u, request=request, correo=correo[:254] or None)
    raise HTTPException(429 if motivo == "espera" else 401 if motivo in ("codigo", "vencido", "credenciales") else 403,
                        mensaje or MENSAJES_INGRESO.get(motivo or "", NO_CONFIRMADO))


def refrescar_para_pin(s, u):
    """Tanda 4 (X2-F): antes de comparar el PIN de caja de quien viene de la nube, su ficha fresca en cada empresa vinculada donde es
    miembro aquí (POST /api/sinc/usuario con el correo en el cuerpo; nunca el PIN). Si la web dice que ya no es miembro, se quita SOLO esa
    membresía; si lo es, se aplica la ficha (un bloqueo, un PIN nuevo o el hash inservible valen de inmediato). Sin respuesta, o en una
    computadora que no valida en línea (D-J), se sigue con lo guardado. Devuelve (usuario releído, fresca): fresca dice si la web contestó
    al menos una ficha y se aplicó (4b, Q4: sin ninguna, la sesión del PIN se abre marcada sin_nube)."""
    vinc = {eid: (cfg, token) for eid, cfg, token in _vinculadas()}
    miembro_de = {m.empresa_id for m in s.exec(select(_auth.UsuarioEmpresa).where(_auth.UsuarioEmpresa.usuario_id == u.id)).all()}
    correo = (u.correo or "").lower().strip()
    fresca = False
    for eid in [e for e in vinc if e in miembro_de]:
        cfg, token = vinc[eid]
        if not _valida_en_linea(cfg):
            continue
        try:
            j = _ficha_de(cfg, token, correo)
            if j is None:
                continue
            if j["miembro"] is False:
                _quitar_membresia(s, u, eid)
                fresca = True
            elif isinstance(j.get("usuario"), dict) and str(j["usuario"].get("correo") or "").lower().strip() == correo:
                _aplicar_usuario(s, eid, j["usuario"]); s.commit()
                fresca = True
        except Exception as ex:  # noqa: BLE001
            s.rollback(); log.warning("PIN de caja: no se pudo aplicar la ficha (%s)", type(ex).__name__)
    s.refresh(u)
    return u, fresca


def estado_ingreso(cfgs: Optional[list] = None) -> dict:
    """Tanda 4 (pantalla de ingreso del programa): desde cuándo alguna empresa vinculada está sin internet (sin_conexion_desde de la
    sincronización; None si hay conexión) y la página web donde se recupera la contraseña (URL_NUBE; None si no es segura).
    4b (Q6): la página web solo si alguna empresa vinculada y no revocada valida en línea (_valida_en_linea); si no hay ninguna (programa
    sin vincular, conectado a otra dirección), None: la pantalla de ingreso ofrece la recuperación local de siempre."""
    desde, en_linea = [], False
    try:
        for _eid, cfg in (_cfgs_empresas() if cfgs is None else cfgs):    # tanda 6: la misma pasada que el bloque `local` de /api/auth/estado
            if cfg.get("vinculado") and cfg.get("sin_conexion_desde") and not cfg.get("revocada_en"):
                desde.append(str(cfg["sin_conexion_desde"]))
            if cfg.get("vinculado") and not cfg.get("revocada_en") and _valida_en_linea(cfg):
                en_linea = True
    except Exception as ex:  # noqa: BLE001
        log.info("Ingreso del programa: no se pudo leer el estado de la conexión (%s)", type(ex).__name__)
    return {"sin_internet_desde": min(desde) if desde else None, "pagina_web": (URL_NUBE.rstrip("/") or None) if en_linea else None}


def _bajar_usuarios_ligero(sc, e: Empresa, cfg: dict, token: str) -> bool:
    """D-F: la bajada liviana de usuarios (POST /api/sinc/usuarios con la huella de la última buena: casi siempre «sin cambios»). Corre
    PRIMERO en cada ciclo de 2 minutos, antes de subir y de las novedades, y vale con la empresa bloqueada en la web. Anota la fecha de
    la última bajada buena y la versión de la web. Solo en una computadora que valida en línea (si no, la política de hash dejaría a
    todos sin poder entrar). Una revocación explícita (o un 401/403 de un cortafuegos) sube como en el resto del ciclo."""
    r = httpx.post(URL_NUBE.rstrip("/") + _RUTA_USUARIOS, headers=_cabecera_ingreso(token), json={"huella": str(cfg.get("usuarios_huella") or "")},
                   timeout=httpx.Timeout(30, connect=10))
    _revisar_respuesta(r, _RUTA_USUARIOS)
    j = None
    if r.status_code == 200:
        try:
            j = r.json()
        except Exception:  # noqa: BLE001
            j = None
    if not _es_sobre(j) or j.get("ingreso") != "ok":
        log.info("sinc empresa %s: la bajada de usuarios no se pudo hacer (%s)", e.id, getattr(r, "status_code", 0))
        return False
    if j.get("version"):
        cfg["version_nube"] = str(j["version"])[:20]
    if not j.get("sin_cambios"):
        if not isinstance(j.get("usuarios"), list):
            return False
        _bajar_usuarios(sc, e.id, j)
        cfg["usuarios_huella"] = str(j.get("huella") or "")[:128]
    cfg["usuarios_bajada"] = _ahora()
    return True


RUTAS_BLOQUEADA = ("/api/sinc/local", "/api/auth/", "/api/version", "/api/novedades", "/api/empresa")


def _bloqueo_local(request, e: Empresa, u, permisos) -> None:
    """Gancho de auth.contexto: con la empresa bloqueada solo entra un administrador, y solo a lo necesario para revincular."""
    if not bloqueada(e.id):
        return
    ruta = request.url.path if request is not None else ""
    if ("configurar" in permisos or getattr(u, "es_superadmin", False)) and (ruta.startswith(RUTAS_BLOQUEADA) or (ruta.startswith("/api/registros") and request.method == "GET")):
        return
    raise HTTPException(403, {"codigo": "instalacion_bloqueada",
                              "mensaje": "Esta instalación fue revocada en la nube y está bloqueada. Un administrador puede volver a vincularla en Configuración › Instalación local."})


def _aviso_local(eid: int):
    """Gancho de auth: lo que la aplicación muestra en su franja (revocada, bloqueada, fechas)."""
    st = _inst_estado.get(eid)
    if not st or not st.get("revocada_en"):
        return None
    rev, bloq = _parse(st.get("revocada_en")), _parse(st.get("bloqueada_en"))
    return {"nombre": st.get("nombre"), "revocada_en": st.get("revocada_en"), "bloqueada_en": st.get("bloqueada_en"),
            "bloquea_el": (rev + timedelta(days=DIAS_BLOQUEO)).isoformat(timespec="seconds") if rev and not bloq else None,
            "elimina_el": (bloq + timedelta(days=DIAS_BORRADO)).isoformat(timespec="seconds") if bloq else None, "eliminada": bool(st.get("eliminada"))}


if MODO_LOCAL:
    _auth.bloqueo_local = _bloqueo_local
    _auth.aviso_local = _aviso_local
    _auth.prueba_vencida = _prueba_vencida_local      # 4.9 (E1): ver _prueba_vencida_local
    _auth.ingreso_nube = _ingreso_nube                # 4.25 (X2): el ingreso de quien viene de la nube lo valida la web
    _auth.dos_pasos_nube = _dos_pasos_nube


# ======================================================================================================================
# TERMINAL Y SUCURSAL FIJAS (4.9, contrato 5c)
# ======================================================================================================================
# Antes se podían cambiar en Configuración › Hacienda (PUT /api/empresa) o con el código de la sucursal principal, y una
# instalación con otra terminal repetía consecutivos. Los eventos de SQLAlchemy cubren cualquier ruta que guarde la empresa.
_fijas: dict[int, dict] = {}          # {eid: {terminal, sucursal}}: instalación vinculada alguna vez (las carga _cargar_estado)
_vinculando: set = set()              # empresas en plena vinculación: solo ahí cambian la terminal y la sucursal


def fijas(eid: int):
    """4.9: {terminal, sucursal} fijas de esta instalación (vinculada alguna vez); None si se pueden editar."""
    return (_fijas.get(eid) or None) if MODO_LOCAL else None


def _empresa_fija(mapper, connection, target) -> None:
    """Antes de guardar una empresa. En la instalación local vinculada, la terminal y la sucursal no cambian (solo la
    vinculación las fija). En la nube, la terminal de la empresa no puede tomar la de una de sus instalaciones (vigente o
    retirada): sus consecutivos chocarían."""
    st = sa_inspect(target)
    if not (st.attrs.terminal.history.has_changes() or st.attrs.sucursal.history.has_changes()):
        return
    tabla = mapper.local_table.name
    fila = connection.execute(_sql(f'SELECT terminal, sucursal FROM "{tabla}" WHERE id = :i'), {"i": target.id}).first()
    if fila is None:
        return
    t_cambia = int(target.terminal or 0) != int(fila[0] or 0)
    s_cambia = int(target.sucursal or 0) != int(fila[1] or 0)
    if not (t_cambia or s_cambia):
        return
    if MODO_LOCAL:
        fija = _fijas.get(target.id)
        if not fija or target.id in _vinculando:
            return
        t_ok = not t_cambia or int(target.terminal or 0) == int(fija.get("terminal") or 0)
        s_ok = not s_cambia or (bool(fija.get("sucursal")) and int(target.sucursal or 0) == int(fija["sucursal"]))
        if t_ok and s_ok:
            return        # 4.9 (E5): volver a los valores fijos sí se permite (una computadora migrada con la terminal editada en la 4.8)
        raise HTTPException(400, f"La terminal ({int(fija.get('terminal') or fila[0] or 1):05d}) y la sucursal ({int(fija.get('sucursal') or fila[1] or 1):03d}) "
                                 "de esta instalación quedaron fijas al vincularla con la nube y no se pueden cambiar: con otro número se repetirían "
                                 "consecutivos de Hacienda.")
    if t_cambia:
        with Session(engine_empresa(target.id)) as s:
            v = _leer(s, target.id, CLAVE_VINC, {})
        usadas = {int(i.get("terminal") or 0) for i in list(v.get("instalaciones") or []) + list(v.get("retiradas") or []) if isinstance(i, dict)}
        if int(target.terminal or 0) in usadas:
            raise HTTPException(400, f"La terminal {int(target.terminal):05d} es de una instalación local de esta empresa (Configuración › Instalación local): "
                                     "la nube no puede usarla porque se repetirían consecutivos de Hacienda.")


def _principal_fija(mapper, connection, target) -> None:
    """La sucursal principal lleva el código de sucursal de la empresa: en una instalación vinculada no cambia (salvo para
    igualarlo al fijo). Se revisa antes de guardar la sucursal, para que no quede a medias con la empresa."""
    if not MODO_LOCAL or not getattr(target, "principal", False):
        return
    eid = getattr(target, "empresa_id", None)
    if eid not in _fijas or eid in _vinculando or not sa_inspect(target).attrs.codigo.history.has_changes():
        return
    actual = connection.execute(_sql(f'SELECT codigo FROM "{mapper.local_table.name}" WHERE id = :i'), {"i": target.id}).scalar()
    nuevo, fija = int(target.codigo or 0), (_fijas.get(eid) or {}).get("sucursal")
    if actual is None or int(actual) == nuevo or (fija and nuevo == int(fija)):
        return
    raise HTTPException(400, f"El código de la sucursal principal ({int(actual):03d}) quedó fijo al vincular esta instalación con la nube: con otro "
                             "código se repetirían consecutivos de Hacienda.")


event.listen(Empresa, "before_update", _empresa_fija)
event.listen(Sucursal, "before_update", _principal_fija)


# ======================================================================================================================
# IDS PROPIOS DE CLIENTES E ÍTEMS (4.9, contrato 5d)
# ======================================================================================================================
# Antes los daba SQLite (rowid o AUTOINCREMENT: el mayor + 1). Al bajar de la nube los clientes e ítems de las otras
# instalaciones (o recibirlos por la red local) entran filas con ids de otros rangos, y el siguiente id salía en el rango de la
# terminal más alta. En la nube, después de recibir lo de una instalación, sus clientes nuevos salían en el rango de esa
# instalación (y la siguiente subida de ella los desactivaba). Ahora cada alta sin id recibe el siguiente de SU rango
# (modulos.rango_propio: 0 en la nube, de 1 a 9 999 999; terminal t, desde t·10 000 000 + 1) y nunca repite uno ya dado.
TABLA_IDS = "sinc_id_propio"


def _siguiente_id_propio(conn, tabla: str, rango: int) -> int:
    """Siguiente id del rango en la tabla. Primero escribe (toma el bloqueo de escritura, como _siguiente_numero): dos altas a la
    vez nunca reciben el mismo. El último dado queda en sinc_id_propio, así un id borrado no se repite; la primera vez parte del
    mayor id del rango (y del sqlite_sequence de AUTOINCREMENT si está en el rango)."""
    lo = int(rango) * RANGO
    hi = lo + RANGO
    p = {"t": tabla, "r": int(rango), "lo": lo, "hi": hi}
    conn.execute(_sql(f"CREATE TABLE IF NOT EXISTS {TABLA_IDS} (tabla TEXT NOT NULL, rango INTEGER NOT NULL, ultimo INTEGER NOT NULL, PRIMARY KEY (tabla, rango))"))
    conn.execute(_sql(f"INSERT INTO {TABLA_IDS} (tabla, rango, ultimo) SELECT :t, :r, :lo WHERE NOT EXISTS (SELECT 1 FROM {TABLA_IDS} WHERE tabla = :t AND rango = :r)"), p)
    seq = ""
    if conn.execute(_sql("SELECT 1 FROM sqlite_master WHERE name = 'sqlite_sequence'")).first():
        seq = ", COALESCE((SELECT seq FROM sqlite_sequence WHERE name = :t AND seq > :lo AND seq < :hi), 0)"
    conn.execute(_sql(f'UPDATE {TABLA_IDS} SET ultimo = MAX(ultimo, COALESCE((SELECT MAX(id) FROM "{tabla}" WHERE id > :lo AND id < :hi), 0){seq}) + 1 '
                      "WHERE tabla = :t AND rango = :r"), p)
    nuevo = int(conn.execute(_sql(f"SELECT ultimo FROM {TABLA_IDS} WHERE tabla = :t AND rango = :r"), p).scalar_one())
    if nuevo >= hi:
        raise HTTPException(400, f"Se agotaron los números de {tabla} de esta instalación (terminal {rango})")
    return nuevo


def _asignar_id_propio(mapper, connection, target) -> None:
    """Antes de insertar un cliente o un ítem sin id (cualquier ruta: alta, importación, compras, traslados…): el siguiente id
    de su rango. Los que llegan sincronizados ya traen su id y no se tocan."""
    if getattr(target, "id", None) is not None:
        return
    eid = getattr(target, "empresa_id", None)
    rango = modulos.rango_propio(int(eid)) if eid is not None else 0
    target.id = _siguiente_id_propio(connection, mapper.local_table.name, rango)


event.listen(Cliente, "before_insert", _asignar_id_propio)
event.listen(Producto, "before_insert", _asignar_id_propio)
