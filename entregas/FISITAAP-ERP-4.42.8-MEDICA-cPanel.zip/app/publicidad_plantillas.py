"""Plantillas de campañas de publicidad (3.40). Se abren en el editor de la consola y se pueden cambiar antes de enviar.
{sitio} = dirección del sitio; {whatsapp} = enlace de WhatsApp de ventas (configuración del sitio). {nombre} se cambia al enviar.
Todo lo que dicen sale de lo que el sistema hace y de lo que la página ya promete (sin precios: cambian con el tiempo)."""

PLANTILLAS = [
    {
        "id": "migracion", "nombre": "Cambiarse de sistema: 2 meses gratis", "tema": "fisitaap",
        "descripcion": "Para empresas que usan otro sistema. Reconoce lo difícil del cambio y ofrece 2 meses de prueba con la migración acompañada.",
        "asunto": "{nombre}, cambiarse de sistema no tiene que ser complicado",
        "preencabezado": "Le damos 2 meses gratis y le ayudamos a pasar sus datos.",
        "antetitulo": "Para empresas que piensan cambiar de sistema",
        "titulo": "Sabemos lo complicado que es migrar. Por eso le damos 2 meses gratis.",
        "cuerpo": """Hola {nombre},

Sabemos lo complicado que puede ser pasar a un sistema nuevo: datos que hay que mover, personas que hay que capacitar y el temor de que una factura salga mal en medio del cambio.

Confiamos en nuestra plataforma y creemos que puede ser realmente de valor para su empresa. Por eso queremos que la pruebe **gratis durante 2 meses**, sin arriesgar nada.

* 2 meses | de prueba gratis
* Sin tarjeta | ni contrato de permanencia
* 4.4 | comprobantes al día con Hacienda

## Así hacemos el cambio con usted
1. **Usted exporta sus datos.** Clientes, productos y saldos en Excel o CSV; la mayoría de sistemas lo permiten.
2. **Nosotros los cargamos.** Revisamos cédulas, códigos CABYS y actividades económicas para evitar rechazos.
3. **Configuramos su llave de Hacienda** y su consecutivo, para que su primera factura salga sin problemas.
4. **Factura en paralelo** en el ambiente de pruebas el tiempo que necesite antes de pasar a producción.

## Todo en un solo sistema
✓ Facturación electrónica, inventario y punto de venta
✓ Gastos, bancos y contabilidad con el IVA por tarifa
✓ Planillas con CCSS, renta y aguinaldo calculados
✓ Soporte en Costa Rica por WhatsApp y correo

> Sus facturas anteriores no se pierden: siguen en Hacienda y en su sistema actual. En FISITAAP by Brillante Agencia empieza con sus clientes, productos y saldos pendientes.

Si le interesa, responda este correo o toque el botón y le ayudamos a empezar esta misma semana.""",
        "boton_texto": "Quiero mis 2 meses gratis", "boton_url": "{sitio}/prueba-gratis",
    },
    {
        "id": "presentacion", "nombre": "Presentación de FISITAAP by Brillante Agencia", "tema": "azul",
        "descripcion": "Primer contacto con un prospecto: qué es el sistema, qué incluye y por qué escogerlo.",
        "asunto": "{nombre}, facture, cobre y pague planilla desde un solo lugar",
        "preencabezado": "Factura electrónica, inventario, contabilidad y planillas juntos. Hecho en Costa Rica.",
        "antetitulo": "Hecho en Costa Rica",
        "titulo": "Un solo sistema para facturar, cobrar y pagar su planilla",
        "cuerpo": """Hola {nombre},

Le escribimos de FISITAAP by Brillante Agencia. Ayudamos a empresas costarricenses a dejar de pasar datos de un programa a otro: todo lo que su negocio necesita para cumplir con Hacienda y la CCSS está en el mismo lugar.

## Lo que incluye
✓ **Factura electrónica 4.4:** facturas, tiquetes, notas de crédito y débito, factura de compra y de exportación
✓ **Inventario** con bodegas, cotizaciones y remisiones
✓ **Punto de venta** con tiquete térmico, mesas y cierre de caja
✓ **Contabilidad:** asientos automáticos, IVA por tarifa y conciliación bancaria
✓ **Planillas** con CCSS, renta, vacaciones y aguinaldo

* Colones | precios sin cobros en dólares
* En la nube | entre desde cualquier lugar
* Soporte | local por WhatsApp y correo

> Cada factura muestra su estado ante Hacienda y se envía sola al cliente cuando la aceptan.

¿Le mostramos el sistema con los datos de su negocio? Responda este correo y coordinamos una llamada corta.""",
        "boton_texto": "Ver planes y precios", "boton_url": "{sitio}/precios",
    },
    {
        "id": "hoteles", "nombre": "Hoteles: todo en un solo sistema", "tema": "vino",
        "descripcion": "Para hoteles, cabinas y hostales: recepción, ama de llaves, restaurante y facturación conectados.",
        "asunto": "{nombre}, su hotel completo en un solo sistema",
        "preencabezado": "Recepción, ama de llaves, restaurante y factura electrónica, conectados.",
        "antetitulo": "Para hoteles, cabinas y hostales",
        "titulo": "De la reservación a la factura, sin pasar datos a mano",
        "cuerpo": """Hola {nombre},

En un hotel pasan muchas cosas a la vez: llegadas, salidas, habitaciones por limpiar, consumos del restaurante y la factura de cada huésped. FISITAAP by Brillante Agencia las une en un mismo sistema.

## Lo que su equipo tendrá a mano
✓ **Recepción y reservaciones** con el estado de cada habitación
✓ **Calendarios de canales** por iCal para evitar sobreventas
✓ **Ama de llaves y mantenimiento:** tareas e incidencias desde el teléfono
✓ **Punto de venta del restaurante** con cargos a la habitación
✓ **Factura electrónica al hacer el checkout**, con exoneraciones verificadas

1. **El huésped reserva** y la habitación queda bloqueada.
2. **Recepción hace el check-in** y ama de llaves ve qué preparar.
3. **Los consumos se cargan** a la cuenta de la habitación.
4. **Al salir, una sola factura** con todo, enviada al correo del huésped.

> Cada área ve solo lo suyo: la camarera no ve la contabilidad y el contador no tiene que pedir reportes a nadie.

Si quiere, le preparamos una demostración con habitaciones de ejemplo parecidas a las de su hotel.""",
        "boton_texto": "Quiero ver una demostración", "boton_url": "{whatsapp}",
    },
    {
        "id": "punto_de_venta", "nombre": "Comercios: punto de venta rápido", "tema": "ambar",
        "descripcion": "Para tiendas, sodas y restaurantes: venta rápida en el mostrador con inventario y factura electrónica.",
        "asunto": "{nombre}, venda más rápido en el mostrador",
        "preencabezado": "Venta rápida, cobros mixtos, mesas y tiquete térmico. El inventario se rebaja solo.",
        "antetitulo": "Para tiendas, sodas y restaurantes",
        "titulo": "Un punto de venta hecho para el mostrador",
        "cuerpo": """Hola {nombre},

Cuando hay fila, cada segundo cuenta. El punto de venta de FISITAAP by Brillante Agencia está pensado para cobrar rápido y que todo lo demás se haga solo.

* Rápido | busque por nombre o código de barras
* Mixto | efectivo, tarjeta y SINPE en un solo cobro
* Al día | el inventario se rebaja con cada venta

## Lo que trae
✓ Tiquete en impresora térmica y factura electrónica cuando el cliente la pide
✓ Restaurante con mesas y comandas
✓ Apertura y cierre de caja con el detalle por medio de pago
✓ Clientes exonerados sin errores ni rechazos
✓ Los productos más vendidos, en el resumen de su negocio

> Sus ventas del mostrador entran solas a la contabilidad y al IVA del mes.

Pruébelo con sus propios productos: le ayudamos a cargarlos desde Excel.""",
        "boton_texto": "Ver el punto de venta", "boton_url": "{sitio}/punto-de-venta",
    },
    {
        "id": "pedidos_online", "nombre": "Pedidos en línea con FISITAAP", "tema": "fisitaap",
        "descripcion": "Para clientes actuales con comercio o restaurante: ofrecer el módulo de catálogo en línea, pedidos, entregas y pago con tarjeta.",
        "asunto": "{nombre}, sus clientes ya pueden pedirle desde el celular",
        "preencabezado": "Catálogo en línea, pedidos a la caja, entregas con motorizado y pago con tarjeta. Todo dentro de su sistema.",
        "antetitulo": "Nuevo en su sistema · FISITAAP",
        "titulo": "Reciba pedidos en línea sin pagar comisiones por pedido",
        "cuerpo": """Hola {nombre},

Sus clientes ya piden comida y productos desde el celular. Con el módulo **Pedidos en línea con FISITAAP** lo hacen directo con usted, sin aplicaciones intermediarias que le cobren un porcentaje de cada venta.

## Lo que incluye
✓ **Catálogo en línea** con su marca, fotos y precios: {sitio}/su-negocio
✓ **Pedidos que entran a la caja** y al monitor de preparación, con aviso sonoro
✓ **Opciones de cada plato** (tamaño, extras, término), cupones y puntos de fidelidad
✓ **Pago con tarjeta** desde el carrito con su propia cuenta de Tilopay
✓ **Entregas** con zonas, motorizados, código de entrega y seguimiento en el mapa
✓ **Correos al cliente** por cada paso del pedido

* Sin comisiones | por pedido
* Su marca | en su propia página
* Desde la caja | que ya usa

> Se activa como extra de su plan actual y queda listo el mismo día: solo marca los ítems que salen en el catálogo y publica.

¿Quiere verlo con su menú? Responda este correo y lo dejamos publicado con usted.""",
        "boton_texto": "Quiero recibir pedidos en línea", "boton_url": "{sitio}/precios",
    },
    {
        "id": "aguinaldo", "nombre": "Planillas: el aguinaldo sin enredos", "tema": "azul",
        "descripcion": "Para enviar en noviembre: el aguinaldo y la planilla calculados, con la calculadora gratuita del sitio.",
        "asunto": "{nombre}, el aguinaldo ya viene: calcúlelo en un minuto",
        "preencabezado": "Se paga en los primeros 20 días de diciembre. Le dejamos una calculadora gratuita.",
        "antetitulo": "Planillas",
        "titulo": "El aguinaldo, calculado sin enredos",
        "cuerpo": """Hola {nombre},

Se acerca diciembre y con él el aguinaldo, que en Costa Rica se paga dentro de los **primeros 20 días de diciembre**. Le dejamos una calculadora gratuita para que lo saque en un minuto.

* 1/12 | de lo ganado de diciembre a noviembre
* 20 de diciembre | fecha límite de pago
* Gratis | la calculadora del sitio

## Y si quiere que la planilla se haga sola
✓ Planilla por período con CCSS y riesgos del trabajo
✓ Retención de renta según el tramo de cada persona
✓ Vacaciones al día y según la ley
✓ Aguinaldo y liquidaciones calculados
✓ Comprobantes de pago por correo para cada colaborador

> Lo que se reporta a la CCSS queda ya sumado, y la planilla genera su asiento contable sin digitar nada.""",
        "boton_texto": "Usar la calculadora de aguinaldo", "boton_url": "{sitio}/herramientas/calculadora-aguinaldo",
    },
    {
        "id": "exoneraciones", "nombre": "Exoneraciones sin rechazos", "tema": "grafito",
        "descripcion": "Para empresas que venden a clientes exonerados: la exoneración se verifica con Hacienda y se avisa antes de vencer.",
        "asunto": "{nombre}, facture a clientes exonerados sin rechazos",
        "preencabezado": "El sistema consulta la exoneración en Hacienda y le avisa antes de que venza.",
        "antetitulo": "Exoneraciones",
        "titulo": "Facture a clientes exonerados sin errores ni rechazos",
        "cuerpo": """Hola {nombre},

Una exoneración mal aplicada es una factura rechazada y un cliente esperando. En FISITAAP by Brillante Agencia la exoneración se revisa antes de facturar, no después.

1. **Registre la exoneración en el cliente** una sola vez.
2. **El sistema la consulta en Hacienda** y confirma que está vigente.
3. **Facture como siempre:** se aplica solo en los CABYS autorizados.
4. **Le avisamos antes de que venza** para que la renueve a tiempo.

✓ Comprobante con los datos correctos de la exoneración
✓ Notas de crédito coherentes con la factura original
✓ También en el punto de venta y en el hotel

> Si la exoneración venció o no cubre un producto, el sistema le avisa antes de enviar la factura.""",
        "boton_texto": "Ver cómo funciona", "boton_url": "{sitio}/exoneraciones",
    },
    {
        "id": "contabilidad", "nombre": "Cierre de mes sin digitar dos veces", "tema": "fisitaap",
        "descripcion": "Para dueños y contadores: asientos automáticos, IVA por tarifa, bancos y acceso para el contador.",
        "asunto": "{nombre}, cierre el mes sin digitar dos veces",
        "preencabezado": "Asientos automáticos, IVA por tarifa y conciliación bancaria. Su contador entra con su propio usuario.",
        "antetitulo": "Contabilidad e IVA",
        "titulo": "Contabilidad e IVA al día, sin digitar dos veces",
        "cuerpo": """Hola {nombre},

Cada factura, gasto y pago de planilla genera su asiento solo. Al final del mes, los números ya están donde tienen que estar.

* Automático | asientos de ventas, gastos y planilla
* Por tarifa | el IVA listo para la declaración
* Conciliado | bancos contra movimientos

## Lo que cambia en su cierre
✓ Las facturas de sus proveedores se aceptan y se registran a tiempo
✓ El IVA del mes se arma por tarifa, sin hojas de cálculo
✓ Bancos y conciliación en la misma pantalla
✓ Estado de resultados y balance cuando los necesite

" Lo mejor del cierre es no tener que perseguir a nadie por un papel. | Equipo de FISITAAP by Brillante Agencia

> Su contador puede entrar con su propio usuario y solo ver lo que le corresponde.""",
        "boton_texto": "Conocer la contabilidad", "boton_url": "{sitio}/contabilidad",
    },
    {
        "id": "prueba_por_vencer", "nombre": "Su prueba termina pronto", "tema": "ambar",
        "descripcion": "Para empresas en prueba gratis: recordatorio amable de que termina, lo que conserva y cómo activar.",
        "asunto": "{nombre}, su prueba de FISITAAP by Brillante Agencia termina pronto",
        "preencabezado": "Si le gustó, active su plan y conserve todo lo que hizo. Si tiene dudas, le ayudamos.",
        "antetitulo": "Su prueba gratis",
        "titulo": "Su prueba termina pronto. Todo lo que hizo se queda.",
        "cuerpo": """Hola {nombre},

Gracias por probar FISITAAP by Brillante Agencia. Su prueba gratis está por terminar y queremos que decida con toda la información.

✓ Sus clientes, productos y facturas **se conservan** al activar el plan
✓ Pasamos su empresa del ambiente de pruebas a producción con usted
✓ Puede cambiar de plan más adelante si su negocio crece

## Para activar
1. **Escríbanos** por WhatsApp o responda este correo.
2. **Escoja el plan** que se ajusta a su cantidad de documentos.
3. **Listo:** sigue trabajando donde se quedó, sin volver a cargar nada.

> ¿Le faltó probar algo o algo no le quedó claro? Respóndanos: preferimos una pregunta a que se quede con la duda.""",
        "boton_texto": "Activar mi plan", "boton_url": "{whatsapp}",
    },
    {
        "id": "novedades", "nombre": "Boletín de novedades", "tema": "grafito",
        "descripcion": "Para clientes: las mejoras recientes del sistema. Ajuste los puntos antes de enviar.",
        "asunto": "Novedades de FISITAAP by Brillante Agencia: lo nuevo de este mes",
        "preencabezado": "Reenvío de facturas con copia, clientes sin cédula en tiquetes, descuentos en porcentaje y más.",
        "antetitulo": "Novedades del mes",
        "titulo": "Lo nuevo en FISITAAP by Brillante Agencia",
        "cuerpo": """Hola {nombre},

Estas son las mejoras que llegaron al sistema en las últimas semanas. Ya están disponibles en su cuenta, no tiene que hacer nada.

## Facturas por correo con copia
Ahora puede reenviar cualquier factura y poner en copia a otras personas. En cada contacto puede indicar a qué correo enviar las facturas y quién recibe copia siempre.

## Clientes sin cédula en los tiquetes
Para ventas al público ya puede registrar contactos sin identificación y emitirles tiquete electrónico.

## Descuentos en porcentaje y margen de ganancia
En cotizaciones y facturas el descuento se aplica como porcentaje sobre el precio sin IVA, y el total de descuentos aparece abajo. En los productos ve el margen y el markup al poner costo y precio.

## Facturas recurrentes más precisas
Puede escoger el día exacto de cada envío y el vencimiento se calcula a partir de cada emisión.

---
¿Tiene una idea para mejorar el sistema? Responda este correo: muchas de estas mejoras salieron de sugerencias de clientes.""",
        "boton_texto": "Entrar a FISITAAP by Brillante Agencia", "boton_url": "{sitio}/app/",
    },
    {
        "id": "reactivacion", "nombre": "¿Le quedó alguna duda?", "tema": "vino",
        "descripcion": "Para prospectos que preguntaron y no siguieron: retomar la conversación sin presionar.",
        "asunto": "{nombre}, ¿le quedó alguna duda sobre FISITAAP by Brillante Agencia?",
        "preencabezado": "Le ofrecemos una llamada corta, sin compromiso, con los datos de su negocio.",
        "antetitulo": "Seguimos en contacto",
        "titulo": "¿Le quedó alguna duda? Conversemos 20 minutos.",
        "cuerpo": """Hola {nombre},

Hace un tiempo nos pidió información sobre FISITAAP by Brillante Agencia y no queremos que se quede con preguntas sin responder.

Muchas empresas nos cuentan que lo que las frena no es el precio, sino la duda: si el cambio será difícil, si su contador podrá usarlo o si sus datos estarán seguros.

✓ **El cambio:** cargamos sus datos y configuramos Hacienda con usted
✓ **Su contador:** entra con su propio usuario y ve lo que le corresponde
✓ **Sus datos:** cada empresa tiene su propia base de datos y las credenciales van cifradas

" Preferimos que nos pregunte antes de que se quede con la duda. | Equipo de FISITAAP by Brillante Agencia

Le proponemos una llamada de 20 minutos, sin compromiso, para mostrarle el sistema con ejemplos parecidos a su negocio.""",
        "boton_texto": "Agendar una llamada", "boton_url": "{whatsapp}",
    },
]
