"""TiKe · Tickets de soporte (3.52, fase 6 de la fusión). Módulo «tike»: para empresas de servicios e IT que reciben solicitudes.

Qué hay
- Tickets TK-0001 con cliente (de Contactos) y persona que solicita, asunto, descripción, categoría, prioridad (baja, media, alta,
  crítica) y estado: nuevo → asignado → en_proceso → espera_cliente → resuelto → cerrado. Técnico asignado y vencimiento según el
  SLA de la prioridad (horas corridas, configurables). Bitácora con notas internas, respuestas al cliente (salen por correo), tiempo
  trabajado en minutos, cambios de estado y adjuntos.
- Entradas: desde el sistema, desde el portal del cliente (/soporte/<slug>: correo + clave, o el enlace con token que llega en cada
  correo) y por correo (buzón IMAP propio del soporte: un correo nuevo abre un ticket; una respuesta con [TK-0001] en el asunto o en
  hilo se pega a la bitácora). El buzón se revisa en cada pasada de la cola.
- Correos al cliente con el correo saliente de la empresa: recibido, respuesta del técnico, resuelto (pide calificación), cerrado.
  Aviso al correo del equipo por cada ticket nuevo.
Fase 7 agrega contratos, equipos y facturar desde el ticket; fase 8, la documentación del cliente."""
import email
import email.header
import email.utils
import imaplib
import json
import logging
import re
import secrets
import ssl
import threading
from datetime import timedelta
from html import escape
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from . import planes, secretos
from .auth import Contexto, Usuario, UsuarioEmpresa, abrir, firmar, hash_password, limitar_ip, permisos_de_rol, requiere, sesion_empresa, verificar_password
from .config import DATA_DIR, ahora_cr, nombre_sistema
from .db import Cliente, Empresa, central, engine, get_session, por_empresa, sesion_de

log = logging.getLogger(__name__)
router = APIRouter(tags=["tike"])

PRIORIDADES = ("baja", "media", "alta", "critica")
NOMBRES_PRIORIDAD = {"baja": "Baja", "media": "Media", "alta": "Alta", "critica": "Crítica"}
ESTADOS = ("nuevo", "asignado", "en_proceso", "espera_cliente", "resuelto", "cerrado")
NOMBRES_ESTADO = {"nuevo": "Nuevo", "asignado": "Asignado", "en_proceso": "En proceso", "espera_cliente": "En espera del cliente", "resuelto": "Resuelto", "cerrado": "Cerrado"}
ABIERTOS = ("nuevo", "asignado", "en_proceso", "espera_cliente")
SLA_DEFECTO = {"baja": 168, "media": 72, "alta": 24, "critica": 4}          # horas corridas
CATEGORIAS_DEFECTO = ["Soporte técnico", "Redes e internet", "Correo y cuentas", "Impresoras", "Software", "Facturación", "Otro"]
RESERVADOS_SLUG = {"app", "api", "admin", "soporte", "t", "p", "js", "css", "img", "static", "login", "precios", "contacto", "www", "mail"}
SLUG_RE = re.compile(r"[a-z0-9][a-z0-9-]{1,59}")
CORREO_RE = re.compile(r"[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}")
MAX_ADJUNTO = 8 * 1024 * 1024
TOKEN_DIAS = 30


# ------------------------------------------------------------------------------------------------- tablas
class TikeConfig(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    prefijo: str = "TK"
    categorias: str = "[]"                        # JSON [str]
    sla: str = "{}"                               # JSON {prioridad: horas}
    correo_aviso: Optional[str] = None            # a dónde avisar cada ticket nuevo (vacío = correo de la empresa)
    firma: str = ""                               # pie de los correos al cliente
    portal_activo: bool = False
    slug: str = ""                                # /soporte/<slug>
    portal_titulo: str = ""                       # vacío = «Soporte · <empresa>»
    portal_texto: str = ""
    buzon_activo: bool = False
    imap_host: Optional[str] = None
    imap_puerto: int = 993
    imap_seguridad: str = "ssl"                   # ssl | starttls | ninguna
    imap_usuario: Optional[str] = None
    imap_password: Optional[str] = None           # cifrado con la clave de la empresa
    imap_carpeta: str = "INBOX"
    buzon_ultimo: Optional[str] = None
    buzon_error: Optional[str] = None
    producto_horas_id: Optional[int] = None       # ítem de inventario (servicio) con que se facturan las horas (3.53)
    claves_2fa: bool = True                       # ver contraseñas exige un código de dos pasos (3.54)
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class Ticket(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    numero: int = Field(index=True)
    codigo: str = Field(index=True)               # TK-0001
    token: str = Field(index=True)                # enlace del cliente en los correos
    cliente_id: Optional[int] = Field(default=None, index=True)
    cliente_nombre: str = ""
    solicitante: str = ""                         # persona que pide
    correo: str = ""
    telefono: str = ""
    asunto: str
    descripcion: str = ""
    categoria: str = ""
    prioridad: str = "media"
    estado: str = "nuevo"
    tecnico_id: Optional[int] = Field(default=None, index=True)
    tecnico_nombre: str = ""
    vence: Optional[str] = None                   # SLA
    origen: str = "sistema"                       # sistema | portal | correo
    mensaje_id: str = ""                          # Message-ID del correo que lo abrió (para enhebrar respuestas)
    minutos: int = 0
    calificacion: Optional[int] = None
    calificacion_nota: str = ""
    motivo_cierre: str = ""
    equipo_id: Optional[int] = None               # fase 7
    contrato_id: Optional[int] = None             # fase 7
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    actualizado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    primera_respuesta: Optional[str] = None
    resuelto_en: Optional[str] = None
    cerrado_en: Optional[str] = None


class TicketEntrada(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    ticket_id: int = Field(index=True)
    tipo: str = "nota"                            # nota | respuesta | cliente | cambio | sistema
    publico: bool = False                         # lo ve el cliente
    texto: str = ""
    minutos: int = 0
    usuario: str = ""
    origen: str = "sistema"                       # sistema | portal | correo
    adjuntos: str = "[]"                          # JSON [{nombre, archivo, tamano}]
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class AccesoPortal(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cliente_id: Optional[int] = None
    correo: str = Field(index=True)
    nombre: str = ""
    clave_hash: str = ""
    activo: bool = True
    debe_cambiar: bool = True
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    ultimo_acceso: Optional[str] = None


class TikeSlug(SQLModel, table=True):
    """Central: slug del portal → empresa (independiente del slug de la tienda de FISITAAP)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    slug: str = Field(index=True, unique=True)
    empresa_id: int = Field(index=True)


por_empresa(TikeConfig, Ticket, TicketEntrada, AccesoPortal)
central(TikeSlug)


# ------------------------------------------------------------------------------------------------- utilidades
def _json(v, defecto):
    try:
        x = json.loads(v or "")
        return x if isinstance(x, type(defecto)) else defecto
    except (ValueError, TypeError):
        return defecto


def _config(s: Session, eid: int) -> TikeConfig:
    c = s.exec(select(TikeConfig).where(TikeConfig.empresa_id == eid)).first()
    if not c:
        c = TikeConfig(empresa_id=eid, categorias=json.dumps(CATEGORIAS_DEFECTO, ensure_ascii=False), sla=json.dumps(SLA_DEFECTO))
        s.add(c); s.commit(); s.refresh(c)
    return c


def sla_horas(cfg: TikeConfig, prioridad: str) -> float:
    d = _json(cfg.sla, {})
    try:
        return float(d.get(prioridad, SLA_DEFECTO.get(prioridad, 72)))
    except (TypeError, ValueError):
        return float(SLA_DEFECTO.get(prioridad, 72))


def _vence(cfg: TikeConfig, prioridad: str, desde: Optional[str] = None) -> str:
    base = ahora_cr() if not desde else ahora_cr().fromisoformat(desde)
    return (base + timedelta(hours=sla_horas(cfg, prioridad))).isoformat(timespec="seconds")


def _codigo(cfg: TikeConfig, numero: int) -> str:
    return f"{(cfg.prefijo or 'TK').upper()}-{numero:04d}"


def _siguiente_numero(s: Session, eid: int) -> int:
    u = s.exec(select(Ticket).where(Ticket.empresa_id == eid).order_by(Ticket.numero.desc())).first()
    return (u.numero if u else 0) + 1


def _salida(t: Ticket, entradas: Optional[list] = None, para_cliente: bool = False) -> dict:
    ahora = ahora_cr().isoformat(timespec="seconds")
    d = {"id": t.id, "numero": t.numero, "codigo": t.codigo, "cliente_id": t.cliente_id, "cliente_nombre": t.cliente_nombre, "solicitante": t.solicitante, "correo": t.correo, "telefono": t.telefono,
         "asunto": t.asunto, "descripcion": t.descripcion, "categoria": t.categoria, "prioridad": t.prioridad, "prioridad_nombre": NOMBRES_PRIORIDAD.get(t.prioridad, t.prioridad),
         "estado": t.estado, "estado_nombre": NOMBRES_ESTADO.get(t.estado, t.estado), "abierto": t.estado in ABIERTOS, "tecnico_id": t.tecnico_id, "tecnico_nombre": t.tecnico_nombre,
         "vence": t.vence, "vencido": bool(t.vence and t.estado in ABIERTOS and t.vence < ahora), "origen": t.origen, "minutos": t.minutos, "calificacion": t.calificacion, "calificacion_nota": t.calificacion_nota,
         "motivo_cierre": t.motivo_cierre, "equipo_id": t.equipo_id, "contrato_id": t.contrato_id, "creado": t.creado, "actualizado": t.actualizado, "primera_respuesta": t.primera_respuesta,
         "resuelto_en": t.resuelto_en, "cerrado_en": t.cerrado_en}
    if not para_cliente:
        d["token"] = t.token
    if entradas is not None:
        d["entradas"] = [_salida_entrada(x) for x in entradas if (x.publico or not para_cliente)]
    return d


def _salida_entrada(x: TicketEntrada) -> dict:
    return {"id": x.id, "tipo": x.tipo, "publico": x.publico, "texto": x.texto, "minutos": x.minutos, "usuario": x.usuario, "origen": x.origen, "adjuntos": _json(x.adjuntos, []), "creado": x.creado}


def _registrar(s: Session, t: Ticket, tipo: str, texto: str, usuario: str, publico: bool = False, minutos: int = 0, origen: str = "sistema", adjuntos: Optional[list] = None) -> TicketEntrada:
    x = TicketEntrada(empresa_id=t.empresa_id, ticket_id=t.id, tipo=tipo, publico=publico, texto=texto, minutos=max(0, int(minutos or 0)), usuario=usuario, origen=origen, adjuntos=json.dumps(adjuntos or [], ensure_ascii=False))
    s.add(x)
    if minutos:
        t.minutos = int(t.minutos or 0) + int(minutos)
    t.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(t); s.commit(); s.refresh(x); s.refresh(t)
    return x


def _cambiar_estado(s: Session, t: Ticket, estado: str, usuario: str, motivo: str = "", origen: str = "sistema") -> None:
    if estado not in ESTADOS:
        raise HTTPException(400, "Estado desconocido")
    if t.estado == "cerrado" and estado != "cerrado":
        raise HTTPException(400, "Un ticket cerrado no se reabre: abra uno nuevo")
    if estado == "asignado" and not t.tecnico_id:
        raise HTTPException(400, "Asigne un técnico primero")
    ahora = ahora_cr().isoformat(timespec="seconds"); anterior = t.estado
    t.estado = estado
    if estado == "resuelto":
        t.resuelto_en = ahora
    if estado == "cerrado":
        t.cerrado_en = ahora; t.motivo_cierre = (motivo or "").strip()[:200]
    s.add(t)
    _registrar(s, t, "cambio", f"{NOMBRES_ESTADO.get(anterior, anterior)} → {NOMBRES_ESTADO.get(estado, estado)}" + (f": {motivo.strip()}" if motivo and motivo.strip() else ""), usuario, publico=estado in ("resuelto", "cerrado", "espera_cliente"), origen=origen)


def _titulo_portal(e: Empresa, cfg: TikeConfig) -> str:
    return (cfg.portal_titulo or "").strip() or f"Soporte · {e.nombre_comercial or e.nombre}"


def _enlace_portal(cfg: TikeConfig, t: Ticket) -> str:
    from .sitio import base_url
    return f"{base_url()}/soporte/{cfg.slug}#t={t.token}" if cfg.portal_activo and cfg.slug else ""


# ------------------------------------------------------------------------------------------------- correos
TEXTOS = {
    "recibido": ("Recibimos su solicitud", "Abrimos el ticket {codigo} con su solicitud. Le avisaremos por este medio cada vez que haya una novedad."),
    "respuesta": ("Respuesta a su ticket", "El técnico respondió a su ticket {codigo}:"),
    "resuelto": ("Su ticket quedó resuelto", "Marcamos el ticket {codigo} como resuelto. Si todo quedó bien, califique la atención; si no, respóndanos y lo retomamos."),
    "cerrado": ("Ticket cerrado", "El ticket {codigo} quedó cerrado. Gracias por su confianza."),
    "espera_cliente": ("Necesitamos algo de su parte", "El ticket {codigo} está en espera de su respuesta. Respóndanos para continuar."),
}


def _avisar_cliente(e: Empresa, cfg: TikeConfig, t: Ticket, evento: str, texto_extra: str = "") -> None:
    """Correo al solicitante (en segundo plano, con el correo saliente de la empresa). Asunto con [TK-0001] para enhebrar respuestas."""
    if evento not in TEXTOS or not (t.correo or "").strip() or not getattr(e, "smtp_host", None):
        return
    titulo, intro = TEXTOS[evento]; intro = intro.format(codigo=t.codigo)
    datos = {"para": t.correo, "codigo": t.codigo, "asunto": t.asunto, "nombre": t.solicitante or t.cliente_nombre or "cliente", "enlace": _enlace_portal(cfg, t), "firma": cfg.firma or "", "empresa": e.nombre_comercial or e.nombre,
             "mensaje_id": t.mensaje_id}
    from . import correo_diseno as _dz
    rem = _dz.de_empresa(e)                                           # 3.83: logo y color de la empresa

    def _enviar():
        try:
            from . import correo
            from .main import _cfg_smtp
            html = _dz.armar(rem, titulo=titulo, antetitulo=f"Ticket {datos['codigo']}", asunto=f"[{datos['codigo']}] {titulo}", preencabezado=intro,
                             saludo=f"Hola {datos['nombre']},", parrafos_txt=[intro],
                             cita=texto_extra, cita_autor="Respuesta del equipo de soporte" if evento == "respuesta" and texto_extra else "",
                             datos=[("Ticket", datos["codigo"]), ("Asunto", datos["asunto"])],
                             boton_=("Ver el ticket y responder", datos["enlace"]) if datos["enlace"] else None,
                             despues=[datos["firma"]] if datos["firma"] else [],
                             nota="" if datos["enlace"] else "Para responder, conteste este correo sin cambiar el asunto.")
            texto = f"Hola {datos['nombre']}, {intro}\n" + (texto_extra + "\n" if texto_extra else "") + (f"Ver el ticket: {datos['enlace']}\n" if datos["enlace"] else "Para responder, conteste este correo sin cambiar el asunto.\n") + (datos["firma"] + "\n" if datos["firma"] else "")
            correo.enviar(_cfg_smtp(e), [datos["para"]], f"[{datos['codigo']}] {titulo} · {datos['asunto'][:80]}", html, texto, [])
        except Exception:  # noqa: BLE001  (un correo fallido no detiene el ticket)
            pass
    threading.Thread(target=_enviar, daemon=True).start()


def _avisar_equipo(e: Empresa, cfg: TikeConfig, t: Ticket) -> None:
    para = (cfg.correo_aviso or e.correo or "").strip()
    if not para or not getattr(e, "smtp_host", None):
        return
    datos = {"para": para, "codigo": t.codigo, "asunto": t.asunto, "cliente": t.cliente_nombre or t.solicitante, "prioridad": NOMBRES_PRIORIDAD.get(t.prioridad, t.prioridad), "descripcion": t.descripcion, "origen": t.origen}
    from . import correo_diseno as _dz
    rem = _dz.de_empresa(e)                                           # 3.83

    def _enviar():
        try:
            from . import correo
            from .main import _cfg_smtp
            html = _dz.armar(rem, titulo=f"Ticket nuevo {datos['codigo']}", antetitulo=f"Prioridad {datos['prioridad']}", asunto=f"[{datos['codigo']}] Ticket nuevo",
                             preencabezado=f"{datos['cliente']}: {datos['asunto']}",
                             parrafos_txt=[f"Entró un ticket de **{datos['cliente']}** por {datos['origen']}."],
                             datos=[("Ticket", datos["codigo"]), ("Prioridad", datos["prioridad"]), ("Asunto", datos["asunto"])],
                             cita=(datos["descripcion"] or "")[:1500], cita_autor="Descripción",
                             despues=[f"Atiéndalo en {nombre_sistema()} › TiKe."])
            correo.enviar(_cfg_smtp(e), [datos["para"]], f"[{datos['codigo']}] Ticket nuevo · {datos['asunto'][:80]}", html, f"Ticket {datos['codigo']} de {datos['cliente']}: {datos['asunto']}\n\n{datos['descripcion']}", [])
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=_enviar, daemon=True).start()


# ------------------------------------------------------------------------------------------------- crear ticket (común a sistema, portal y correo)
def crear_ticket(s: Session, e: Empresa, cfg: TikeConfig, *, asunto: str, descripcion: str = "", cliente_id: Optional[int] = None, solicitante: str = "", correo: str = "", telefono: str = "",
                 categoria: str = "", prioridad: str = "media", origen: str = "sistema", usuario: str = "", mensaje_id: str = "", tecnico_id: Optional[int] = None, tecnico_nombre: str = "", avisar: bool = True,
                 equipo_id: Optional[int] = None, contrato_id: Optional[int] = None) -> Ticket:
    eid = e.id
    asunto = " ".join((asunto or "").split())[:160]
    if len(asunto) < 3:
        raise HTTPException(400, "Escriba el asunto del ticket")
    if prioridad not in PRIORIDADES:
        raise HTTPException(400, "Prioridad desconocida")
    cliente_nombre = ""
    if cliente_id:
        c = s.get(Cliente, cliente_id)
        if not c or c.empresa_id != eid:
            raise HTTPException(400, "El cliente indicado no existe")
        cliente_nombre = c.nombre_comercial or c.nombre
        correo = correo or (c.correo or "")
        telefono = telefono or (str(c.celular or c.telefono or "") if (c.celular or c.telefono) else "")
    correo = (correo or "").strip().lower()[:120]
    if correo and not CORREO_RE.fullmatch(correo):
        raise HTTPException(400, "Revise el correo del solicitante")
    from . import tike_contratos as _tc
    if equipo_id:
        q = s.get(_tc.Equipo, equipo_id)
        if not q or q.empresa_id != eid:
            raise HTTPException(400, "El equipo indicado no existe")
        if cliente_id and q.cliente_id != cliente_id:
            raise HTTPException(400, "Ese equipo es de otro cliente")
        cliente_id = cliente_id or q.cliente_id
        if cliente_id and not cliente_nombre:
            c = s.get(Cliente, cliente_id); cliente_nombre = (c.nombre_comercial or c.nombre) if c else ""
    if contrato_id:
        ct = s.get(_tc.Contrato, contrato_id)
        if not ct or ct.empresa_id != eid or (cliente_id and ct.cliente_id != cliente_id):
            raise HTTPException(400, "El contrato indicado no es de ese cliente")
    elif cliente_id:
        ct = _tc.contrato_vigente(s, eid, cliente_id); contrato_id = ct.id if ct else None       # con contrato vigente, el ticket descuenta de su bolsa
    n = _siguiente_numero(s, eid)
    t = Ticket(empresa_id=eid, numero=n, codigo=_codigo(cfg, n), token=secrets.token_urlsafe(12), cliente_id=cliente_id, cliente_nombre=cliente_nombre, solicitante=" ".join((solicitante or "").split())[:80],
               correo=correo, telefono=(telefono or "").strip()[:20], asunto=asunto, descripcion=(descripcion or "").strip()[:5000], categoria=(categoria or "").strip()[:60], prioridad=prioridad,
               estado="asignado" if tecnico_id else "nuevo", tecnico_id=tecnico_id, tecnico_nombre=tecnico_nombre if tecnico_id else "", vence=_vence(cfg, prioridad), origen=origen, mensaje_id=(mensaje_id or "")[:200],
               equipo_id=equipo_id, contrato_id=contrato_id)
    s.add(t); s.commit(); s.refresh(t)
    _registrar(s, t, "sistema", f"Ticket abierto por {origen}" + (f" · asignado a {tecnico_nombre}" if tecnico_id else ""), usuario or (solicitante or "cliente"), publico=False, origen=origen)
    if avisar:
        _avisar_cliente(e, cfg, t, "recibido")
        _avisar_equipo(e, cfg, t)
    return t


# ------------------------------------------------------------------------------------------------- API del negocio
def admin(ctx: Contexto = Depends(requiere("tike"))) -> Contexto:
    planes.exigir_modulo(ctx.empresa, "tike")
    return ctx


class ConfigIn(BaseModel):
    prefijo: Optional[str] = PField("TK", min_length=1, max_length=6)
    categorias: list = PField(default_factory=list, max_length=40)
    sla: dict = PField(default_factory=dict)
    correo_aviso: Optional[str] = PField(None, max_length=120)
    firma: Optional[str] = PField("", max_length=600)
    portal_activo: bool = False
    slug: Optional[str] = PField("", max_length=60)
    portal_titulo: Optional[str] = PField("", max_length=80)
    portal_texto: Optional[str] = PField("", max_length=400)
    buzon_activo: bool = False
    imap_host: Optional[str] = PField(None, max_length=120)
    imap_puerto: Optional[int] = PField(993, ge=1, le=65535)
    imap_seguridad: Optional[str] = PField("ssl", max_length=10)
    imap_usuario: Optional[str] = PField(None, max_length=120)
    imap_password: Optional[str] = PField(None, max_length=200)     # None = no tocar; "" = borrar
    imap_carpeta: Optional[str] = PField("INBOX", max_length=60)
    producto_horas_id: Optional[int] = None                          # 3.53
    claves_2fa: bool = True                                          # 3.54


def _salida_config(e: Empresa, cfg: TikeConfig) -> dict:
    from .sitio import base_url
    return {"prefijo": cfg.prefijo, "categorias": _json(cfg.categorias, []), "sla": {p: sla_horas(cfg, p) for p in PRIORIDADES}, "correo_aviso": cfg.correo_aviso, "firma": cfg.firma,
            "portal_activo": cfg.portal_activo, "slug": cfg.slug, "portal_titulo": cfg.portal_titulo, "portal_texto": cfg.portal_texto, "portal_url": f"{base_url()}/soporte/{cfg.slug}" if cfg.slug else None,
            "buzon_activo": cfg.buzon_activo, "imap_host": cfg.imap_host, "imap_puerto": cfg.imap_puerto, "imap_seguridad": cfg.imap_seguridad, "imap_usuario": cfg.imap_usuario, "imap_carpeta": cfg.imap_carpeta,
            "clave_guardada": bool(cfg.imap_password), "buzon_ultimo": cfg.buzon_ultimo, "buzon_error": cfg.buzon_error, "estados": [[k, v] for k, v in NOMBRES_ESTADO.items()], "prioridades": [[k, v] for k, v in NOMBRES_PRIORIDAD.items()],
            "producto_horas_id": cfg.producto_horas_id, "claves_2fa": cfg.claves_2fa}


@router.get("/api/tike/config")
def ver_config(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return _salida_config(ctx.empresa, _config(s, ctx.empresa.id))


@router.put("/api/tike/config")
def guardar_config(data: ConfigIn, request: Request, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    eid = ctx.empresa.id; cfg = _config(s, eid)
    # 3.87: antes de guardar nada (el portal se confirma más abajo): quitar los dos pasos para ver contraseñas es solo de quien configura
    # la empresa (el Técnico de soporte, que ni las ve, podía apagarlo y dejarlas a la vista de cualquiera con el permiso); encenderlo
    # sí lo puede cualquiera con TiKe. El ítem con que se cobran las horas lo cambia solo quien factura.
    if cfg.claves_2fa and not data.claves_2fa and not ctx.puede("configurar"):
        raise HTTPException(403, "Solo el administrador puede quitar el código de dos pasos para ver contraseñas")
    if (data.producto_horas_id or None) != (cfg.producto_horas_id or None) and not ctx.puede("facturar"):
        raise HTTPException(403, "Su rol no puede cambiar el ítem con que se facturan las horas")
    cambia_2fa = bool(cfg.claves_2fa) != bool(data.claves_2fa)
    cfg.prefijo = re.sub(r"[^A-Za-z0-9]", "", data.prefijo or "TK").upper()[:6] or "TK"
    cats = []
    for c in data.categorias:
        c = " ".join(str(c or "").split())[:60]
        if c and c not in cats:
            cats.append(c)
    cfg.categorias = json.dumps(cats or CATEGORIAS_DEFECTO, ensure_ascii=False)
    sla = {}
    for p in PRIORIDADES:
        try:
            h = float(data.sla.get(p, SLA_DEFECTO[p]))
        except (TypeError, ValueError):
            raise HTTPException(400, f"SLA de prioridad {NOMBRES_PRIORIDAD[p]}: use horas")
        if not (0.5 <= h <= 24 * 90):
            raise HTTPException(400, f"SLA de prioridad {NOMBRES_PRIORIDAD[p]}: entre media hora y 90 días")
        sla[p] = h
    cfg.sla = json.dumps(sla)
    if data.correo_aviso and not CORREO_RE.fullmatch(data.correo_aviso.strip()):
        raise HTTPException(400, "Revise el correo de aviso")
    cfg.correo_aviso = (data.correo_aviso or "").strip().lower() or None
    cfg.firma = (data.firma or "").strip(); cfg.portal_titulo = (data.portal_titulo or "").strip(); cfg.portal_texto = (data.portal_texto or "").strip()
    slug = (data.slug or "").strip().lower()
    if slug and (not SLUG_RE.fullmatch(slug) or slug in RESERVADOS_SLUG or "--" in slug):
        raise HTTPException(400, "La dirección del portal solo lleva letras minúsculas, números y guiones (2 a 60)")
    if slug:
        otro = sc.exec(select(TikeSlug).where(TikeSlug.slug == slug, TikeSlug.empresa_id != eid)).first()
        if otro:
            raise HTTPException(400, f"La dirección «{slug}» ya la usa otra empresa; elija otra")
    if data.portal_activo and not slug:
        raise HTTPException(400, "Para publicar el portal indique su dirección")
    cfg.slug = slug; cfg.portal_activo = bool(data.portal_activo and slug)
    fila = sc.exec(select(TikeSlug).where(TikeSlug.empresa_id == eid)).first()
    if cfg.portal_activo:
        if fila:
            fila.slug = slug; sc.add(fila)
        else:
            sc.add(TikeSlug(slug=slug, empresa_id=eid))
    elif fila:
        sc.delete(fila)
    sc.commit()
    cfg.imap_host = (data.imap_host or "").strip() or None; cfg.imap_puerto = int(data.imap_puerto or 993); cfg.imap_seguridad = data.imap_seguridad if data.imap_seguridad in ("ssl", "starttls", "ninguna") else "ssl"
    cfg.imap_usuario = (data.imap_usuario or "").strip() or None; cfg.imap_carpeta = (data.imap_carpeta or "INBOX").strip() or "INBOX"
    if data.imap_password is not None:
        if secretos.asegurar_clave(ctx.empresa):
            ec = sc.get(Empresa, eid)
            if ec:
                ec.clave_cifrada = ctx.empresa.clave_cifrada; sc.add(ec); sc.commit()
        cfg.imap_password = secretos.cifrar(ctx.empresa.clave_cifrada, data.imap_password.strip()) if data.imap_password.strip() else None
    if data.producto_horas_id:
        from .db import Producto
        p = s.get(Producto, data.producto_horas_id)
        if not p or p.empresa_id != eid:
            raise HTTPException(400, "El ítem para facturar horas no existe")
    cfg.producto_horas_id = data.producto_horas_id or None
    cfg.claves_2fa = bool(data.claves_2fa)
    cfg.buzon_activo = bool(data.buzon_activo and cfg.imap_host and cfg.imap_usuario and cfg.imap_password)
    if data.buzon_activo and not cfg.buzon_activo:
        raise HTTPException(400, "Para leer el buzón complete servidor, usuario y contraseña")
    s.add(cfg); s.commit(); s.refresh(cfg)
    if cambia_2fa:                                    # 3.87: queda en la auditoría quién encendió o apagó la regla
        try:
            from .auth import auditar
            uid = getattr(ctx.usuario, "id", None)
            auditar(sc, "tike_claves_2fa", "Ver contraseñas exige dos pasos: " + ("sí" if cfg.claves_2fa else "no"), sc.get(Usuario, uid) if uid else None, eid, request,
                    correo=getattr(ctx.usuario, "correo", None))
        except Exception:  # noqa: BLE001  (la auditoría no detiene el guardado)
            log.warning("TiKe: no se pudo auditar el cambio de claves_2fa en la empresa %s", eid)
    return _salida_config(ctx.empresa, cfg)


@router.get("/api/tike/tecnicos")
def tecnicos(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Usuarios de la empresa que pueden atender tickets (permiso tike)."""
    eid = ctx.empresa.id; out = []
    filas = sc.exec(select(Usuario, UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == Usuario.id, UsuarioEmpresa.empresa_id == eid)).all()
    for u, ue in filas:
        if u.bloqueado:
            continue
        if u.es_superadmin or "tike" in permisos_de_rol(sc, eid, ue.rol):
            out.append({"id": u.id, "nombre": u.nombre, "correo": u.correo, "rol": ue.rol})
    yo = ctx.usuario
    if getattr(yo, "id", None) and not any(x["id"] == yo.id for x in out):          # quien entra siempre puede tomar tickets (superadmin, cuentas de prueba)
        out.append({"id": yo.id, "nombre": yo.nombre, "correo": getattr(yo, "correo", ""), "rol": ctx.rol})
    return sorted(out, key=lambda x: x["nombre"].lower())


class TicketIn(BaseModel):
    asunto: str = PField(min_length=3, max_length=160)
    descripcion: Optional[str] = PField("", max_length=5000)
    cliente_id: Optional[int] = None
    solicitante: Optional[str] = PField("", max_length=80)
    correo: Optional[str] = PField("", max_length=120)
    telefono: Optional[str] = PField("", max_length=20)
    categoria: Optional[str] = PField("", max_length=60)
    prioridad: str = "media"
    tecnico_id: Optional[int] = None
    equipo_id: Optional[int] = None                                  # 3.53
    contrato_id: Optional[int] = None


def _tecnico(ctx: Contexto, sc: Session, tecnico_id: Optional[int]) -> tuple[Optional[int], str]:
    if not tecnico_id:
        return None, ""
    if getattr(ctx.usuario, "id", None) == tecnico_id:
        return tecnico_id, ctx.usuario.nombre
    u = sc.get(Usuario, tecnico_id)
    ue = sc.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.usuario_id == tecnico_id, UsuarioEmpresa.empresa_id == ctx.empresa.id)).first()
    if not u or not ue:
        raise HTTPException(400, "Ese usuario no pertenece a la empresa")
    # 3.87: solo quien atiende tickets (permiso tike, la misma regla de la lista de técnicos); antes se aceptaba, por ejemplo, un
    # Vendedor, que después no podía ni abrir el ticket
    if u.bloqueado or not (u.es_superadmin or "tike" in permisos_de_rol(sc, ctx.empresa.id, ue.rol)):
        raise HTTPException(400, "Ese usuario no atiende tickets: elija a alguien con acceso a TiKe")
    return u.id, u.nombre


@router.post("/api/tike/tickets")
def nuevo_ticket(data: TicketIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    cfg = _config(s, ctx.empresa.id)
    tid, tnom = _tecnico(ctx, sc, data.tecnico_id)
    t = crear_ticket(s, ctx.empresa, cfg, asunto=data.asunto, descripcion=data.descripcion or "", cliente_id=data.cliente_id, solicitante=data.solicitante or "", correo=data.correo or "", telefono=data.telefono or "",
                     categoria=data.categoria or "", prioridad=data.prioridad, origen="sistema", usuario=ctx.usuario.nombre, tecnico_id=tid, tecnico_nombre=tnom, equipo_id=data.equipo_id, contrato_id=data.contrato_id)
    return _con_entradas(s, t)


@router.get("/api/tike/tickets")
def listar(estado: Optional[str] = None, tecnico_id: Optional[int] = None, cliente_id: Optional[int] = None, q: Optional[str] = None, abiertos: int = 0, desde: Optional[str] = None, hasta: Optional[str] = None,
           ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    qy = select(Ticket).where(Ticket.empresa_id == eid)
    if estado:
        qy = qy.where(Ticket.estado == estado)
    if abiertos:
        qy = qy.where(Ticket.estado.in_(ABIERTOS))  # type: ignore[attr-defined]
    if tecnico_id:
        qy = qy.where(Ticket.tecnico_id == tecnico_id)
    if cliente_id:
        qy = qy.where(Ticket.cliente_id == cliente_id)
    if desde:
        qy = qy.where(Ticket.creado >= desde[:10])
    if hasta:
        qy = qy.where(Ticket.creado <= hasta[:10] + "T99")
    ts = s.exec(qy.order_by(Ticket.id.desc())).all()
    if q:
        ql = q.strip().lower()
        ts = [t for t in ts if ql in (t.asunto or "").lower() or ql in (t.codigo or "").lower() or ql in (t.cliente_nombre or "").lower() or ql in (t.solicitante or "").lower() or ql in (t.descripcion or "").lower()]
    return [_salida(t) for t in ts[:500]]


@router.get("/api/tike/resumen")
def resumen(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; ahora = ahora_cr().isoformat(timespec="seconds")
    ts = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.estado.in_(ABIERTOS))).all()  # type: ignore[attr-defined]
    por_estado = {k: 0 for k in ESTADOS}; por_tecnico: dict = {}; vencidos = 0; por_vencer = 0
    for t in ts:
        por_estado[t.estado] = por_estado.get(t.estado, 0) + 1
        k = t.tecnico_nombre or "Sin asignar"; por_tecnico[k] = por_tecnico.get(k, 0) + 1
        if t.vence and t.vence < ahora:
            vencidos += 1
        elif t.vence and t.vence < (ahora_cr() + timedelta(hours=4)).isoformat(timespec="seconds"):
            por_vencer += 1
    mes = ahora_cr().strftime("%Y-%m")
    cerrados_mes = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.estado.in_(("resuelto", "cerrado")), Ticket.actualizado >= mes)).all()  # type: ignore[attr-defined]
    calif = [t.calificacion for t in cerrados_mes if t.calificacion]
    return {"abiertos": len(ts), "por_estado": por_estado, "por_tecnico": por_tecnico, "vencidos": vencidos, "por_vencer": por_vencer, "resueltos_mes": len(cerrados_mes),
            "calificacion_mes": round(sum(calif) / len(calif), 1) if calif else None, "minutos_mes": sum(t.minutos or 0 for t in cerrados_mes)}


def _ticket(s: Session, eid: int, tid: int) -> Ticket:
    t = s.get(Ticket, tid)
    if not t or t.empresa_id != eid:
        raise HTTPException(404, "Ticket no encontrado")
    return t


def _con_entradas(s: Session, t: Ticket) -> dict:
    d = _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all())
    from . import tike_contratos as _tc
    q = s.get(_tc.Equipo, t.equipo_id) if t.equipo_id else None
    ct = s.get(_tc.Contrato, t.contrato_id) if t.contrato_id else None
    d["equipo"] = {"id": q.id, "codigo": q.codigo, "nombre": q.nombre, "tipo": q.tipo, "serie": q.serie} if q else None
    d["contrato"] = {"id": ct.id, "nombre": ct.nombre or _tc.NOMBRES_TIPO_CONTRATO.get(ct.tipo, ct.tipo), "tipo": ct.tipo, "consumo": _tc.consumo(s, t.empresa_id, ct)} if ct else None
    d["items"] = [_tc._salida_item(x) for x in s.exec(select(_tc.TicketItem).where(_tc.TicketItem.ticket_id == t.id).order_by(_tc.TicketItem.id)).all()]
    try:                    # 3.87: lo que queda por cobrar; sin nada pendiente, el botón «Facturar desde el ticket» no aparece
        h = _tc.horas_facturables(s, t.empresa_id, t)
        d["por_cobrar"] = {"horas": h["horas"], "ya_horas": h.get("ya_horas", 0), "repuestos": sum(1 for x in d["items"] if not x["facturado"])}
    except Exception:  # noqa: BLE001  (la ficha del ticket se ve aunque el cálculo falle)
        log.warning("TiKe: no se pudo calcular lo pendiente del ticket %s", t.id); d["por_cobrar"] = None
    return d


@router.get("/api/tike/tickets/{tid}")
def ver_ticket(tid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return _con_entradas(s, _ticket(s, ctx.empresa.id, tid))


class TicketEdicionIn(BaseModel):
    asunto: Optional[str] = PField(None, min_length=3, max_length=160)
    descripcion: Optional[str] = PField(None, max_length=5000)
    cliente_id: Optional[int] = None
    solicitante: Optional[str] = PField(None, max_length=80)
    correo: Optional[str] = PField(None, max_length=120)
    telefono: Optional[str] = PField(None, max_length=20)
    categoria: Optional[str] = PField(None, max_length=60)
    prioridad: Optional[str] = None
    equipo_id: Optional[int] = None                                  # 3.53: 0 = quitar
    contrato_id: Optional[int] = None


@router.put("/api/tike/tickets/{tid}")
def editar_ticket(tid: int, data: TicketEdicionIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; t = _ticket(s, eid, tid); cfg = _config(s, eid); cambios = []
    if t.estado == "cerrado":
        raise HTTPException(400, "Un ticket cerrado no se edita")
    if data.prioridad is not None and data.prioridad != t.prioridad:
        if data.prioridad not in PRIORIDADES:
            raise HTTPException(400, "Prioridad desconocida")
        cambios.append(f"prioridad {NOMBRES_PRIORIDAD[t.prioridad]} → {NOMBRES_PRIORIDAD[data.prioridad]}"); t.prioridad = data.prioridad; t.vence = _vence(cfg, data.prioridad, t.creado)
    if data.cliente_id is not None and data.cliente_id != t.cliente_id:
        if data.cliente_id:
            c = s.get(Cliente, data.cliente_id)
            if not c or c.empresa_id != eid:
                raise HTTPException(400, "El cliente indicado no existe")
            t.cliente_id, t.cliente_nombre = c.id, c.nombre_comercial or c.nombre
        else:
            t.cliente_id, t.cliente_nombre = None, ""
        cambios.append("cliente")
    for k in ("asunto", "descripcion", "solicitante", "telefono", "categoria"):
        v = getattr(data, k)
        if v is not None and v.strip() != (getattr(t, k) or ""):
            setattr(t, k, " ".join(v.split())[:160] if k == "asunto" else v.strip()); cambios.append(k)
    if data.correo is not None and data.correo.strip().lower() != (t.correo or ""):
        v = data.correo.strip().lower()
        if v and not CORREO_RE.fullmatch(v):
            raise HTTPException(400, "Revise el correo")
        t.correo = v; cambios.append("correo")
    from . import tike_contratos as _tc
    if data.equipo_id is not None and (data.equipo_id or None) != t.equipo_id:
        if data.equipo_id:
            q = s.get(_tc.Equipo, data.equipo_id)
            if not q or q.empresa_id != eid or (t.cliente_id and q.cliente_id != t.cliente_id):
                raise HTTPException(400, "Ese equipo no existe o es de otro cliente")
            if not t.cliente_id:
                c = s.get(Cliente, q.cliente_id); t.cliente_id, t.cliente_nombre = q.cliente_id, (c.nombre_comercial or c.nombre) if c else ""
        t.equipo_id = data.equipo_id or None; cambios.append("equipo")
    if data.contrato_id is not None and (data.contrato_id or None) != t.contrato_id:
        # 3.87: con horas ya cobradas, cambiar el contrato volvería a ofrecerlas por otro lado (bolsa o sin contrato) y la bolsa del
        # contrato dejaría de cuadrar con lo facturado. Mientras el borrador no se emita, eliminarlo libera las horas; ya emitido, no.
        cobros = [x for x in s.exec(select(_tc.TicketCobro).where(_tc.TicketCobro.empresa_id == eid, _tc.TicketCobro.ticket_id == t.id)).all() if x.minutos]
        if any(_tc.cobro_en_borrador(s, eid, x) for x in cobros):
            raise HTTPException(400, "Este ticket ya tiene horas en un borrador de factura: para cambiarle el contrato elimine primero ese borrador")
        if cobros:
            raise HTTPException(400, "Las horas de este ticket ya se facturaron con el contrato que tiene: el contrato ya no se puede cambiar")
        if data.contrato_id:
            ct = s.get(_tc.Contrato, data.contrato_id)
            if not ct or ct.empresa_id != eid or ct.cliente_id != t.cliente_id:
                raise HTTPException(400, "Ese contrato no es del cliente del ticket")
        t.contrato_id = data.contrato_id or None; cambios.append("contrato")
    if cambios:
        s.add(t); _registrar(s, t, "cambio", "Editado: " + ", ".join(cambios), ctx.usuario.nombre)
    return _con_entradas(s, t)


class AsignarIn(BaseModel):
    tecnico_id: Optional[int] = None


@router.post("/api/tike/tickets/{tid}/asignar")
def asignar(tid: int, data: AsignarIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    t = _ticket(s, ctx.empresa.id, tid)
    if t.estado in ("resuelto", "cerrado"):
        raise HTTPException(400, "El ticket ya está resuelto o cerrado")
    uid, nombre = _tecnico(ctx, sc, data.tecnico_id)
    anterior = t.tecnico_nombre or "sin asignar"
    t.tecnico_id, t.tecnico_nombre = uid, nombre
    if uid and t.estado == "nuevo":
        t.estado = "asignado"
    if not uid and t.estado == "asignado":
        t.estado = "nuevo"
    s.add(t); _registrar(s, t, "cambio", f"Asignado: {anterior} → {nombre or 'sin asignar'}", ctx.usuario.nombre)
    return _con_entradas(s, t)


class EstadoIn(BaseModel):
    estado: str
    motivo: Optional[str] = PField("", max_length=200)


@router.post("/api/tike/tickets/{tid}/estado")
def estado(tid: int, data: EstadoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; t = _ticket(s, eid, tid); cfg = _config(s, eid)
    if data.estado == "cerrado" and t.estado not in ("resuelto", "cerrado") and not (data.motivo or "").strip():
        raise HTTPException(400, "Para cerrar un ticket sin resolver indique el motivo")
    _cambiar_estado(s, t, data.estado, ctx.usuario.nombre, data.motivo or "")
    if data.estado in ("resuelto", "cerrado", "espera_cliente"):
        _avisar_cliente(ctx.empresa, cfg, t, data.estado, (data.motivo or "").strip())
    return _con_entradas(s, t)


class EntradaIn(BaseModel):
    tipo: str = "nota"                      # nota (interna) | respuesta (al cliente, sale por correo) | visita (llegada al sitio, 3.53)
    texto: str = PField("", max_length=5000)
    minutos: Optional[int] = PField(0, ge=0, le=24 * 60)
    estado: Optional[str] = None            # opcional: cambiar el estado en el mismo paso


@router.post("/api/tike/tickets/{tid}/entradas")
def nueva_entrada(tid: int, data: EntradaIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; t = _ticket(s, eid, tid); cfg = _config(s, eid)
    if t.estado == "cerrado":
        raise HTTPException(400, "Un ticket cerrado no recibe más entradas")
    if data.tipo not in ("nota", "respuesta", "visita"):
        raise HTTPException(400, "Tipo de entrada desconocido")
    if data.tipo == "visita":
        data.texto = data.texto.strip() or "Llegada al sitio"
        if t.estado in ("nuevo", "asignado"):
            t.estado = "en_proceso"
    if not data.texto.strip():
        raise HTTPException(400, "Escriba el texto")
    if data.tipo == "respuesta" and not t.primera_respuesta:
        t.primera_respuesta = ahora_cr().isoformat(timespec="seconds")
    if t.estado in ("nuevo", "asignado") and data.tipo == "respuesta":            # responder al cliente = ya se está trabajando
        t.estado = "en_proceso"
    _registrar(s, t, data.tipo, data.texto.strip(), ctx.usuario.nombre, publico=data.tipo in ("respuesta", "visita"), minutos=data.minutos or 0)
    if data.estado and data.estado != t.estado:
        _cambiar_estado(s, t, data.estado, ctx.usuario.nombre)
    if data.tipo == "respuesta":
        _avisar_cliente(ctx.empresa, cfg, t, "resuelto" if data.estado == "resuelto" else "espera_cliente" if data.estado == "espera_cliente" else "respuesta", data.texto.strip())
    elif data.estado in ("resuelto", "cerrado", "espera_cliente"):
        _avisar_cliente(ctx.empresa, cfg, t, data.estado)
    return _con_entradas(s, t)


def _carpeta(eid: int, tid: int) -> Path:
    p = DATA_DIR / "empresas" / str(eid) / "tike" / str(tid)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _nombre_seguro(nombre: str) -> str:
    n = re.sub(r"[^A-Za-z0-9._-]+", "_", (nombre or "archivo").strip())[:80].strip("._") or "archivo"
    return n


@router.post("/api/tike/tickets/{tid}/adjuntos")
def subir_adjunto(tid: int, archivo: UploadFile = File(...), ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; t = _ticket(s, eid, tid)
    datos = archivo.file.read(MAX_ADJUNTO + 1)
    if len(datos) > MAX_ADJUNTO:
        raise HTTPException(400, "El adjunto no puede pasar de 8 MB")
    if not datos:
        raise HTTPException(400, "El archivo está vacío")
    nombre = _nombre_seguro(archivo.filename or "archivo"); fisico = f"{secrets.token_hex(4)}-{nombre}"
    (_carpeta(eid, t.id) / fisico).write_bytes(datos)
    x = _registrar(s, t, "nota", f"Adjunto: {nombre}", ctx.usuario.nombre, publico=False, adjuntos=[{"nombre": nombre, "archivo": fisico, "tamano": len(datos)}])
    return _salida_entrada(x)


@router.get("/api/tike/tickets/{tid}/adjuntos/{archivo}", include_in_schema=False)
def ver_adjunto(tid: int, archivo: str, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; _ticket(s, eid, tid)
    ruta = _carpeta(eid, tid) / _nombre_seguro(archivo)
    if not ruta.is_file():
        raise HTTPException(404, "Adjunto no encontrado")
    return FileResponse(ruta, filename=archivo.split("-", 1)[-1] if "-" in archivo else archivo)


# ------------------------------------------------------------------------------------------------- accesos al portal (los crea el negocio)
class AccesoIn(BaseModel):
    correo: str = PField(min_length=5, max_length=120)
    nombre: Optional[str] = PField("", max_length=80)
    cliente_id: Optional[int] = None
    clave: Optional[str] = PField(None, min_length=6, max_length=60)   # vacío = se genera una temporal


def _salida_acceso(a: AccesoPortal) -> dict:
    return {"id": a.id, "correo": a.correo, "nombre": a.nombre, "cliente_id": a.cliente_id, "activo": a.activo, "debe_cambiar": a.debe_cambiar, "creado": a.creado, "ultimo_acceso": a.ultimo_acceso}


@router.get("/api/tike/accesos")
def listar_accesos(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return [_salida_acceso(a) for a in s.exec(select(AccesoPortal).where(AccesoPortal.empresa_id == ctx.empresa.id).order_by(AccesoPortal.id.desc())).all()]


def _enviar_clave(e: Empresa, cfg: TikeConfig, correo_para: str, nombre: str, clave: str) -> None:
    if not getattr(e, "smtp_host", None):
        return
    from .sitio import base_url
    url = f"{base_url()}/soporte/{cfg.slug}" if cfg.slug else base_url()
    from . import correo_diseno as _dz
    rem = _dz.de_empresa(e)                                           # 3.83

    def _enviar():
        try:
            from . import correo
            from .main import _cfg_smtp
            html = _dz.armar(rem, titulo="Su acceso al portal de soporte", asunto="Su acceso al portal de soporte", saludo=f"Hola {nombre or ''},",
                             preencabezado="Ya puede abrir y seguir sus tickets en línea.",
                             parrafos_txt=[f"Ya tiene acceso al portal de soporte de **{rem.nombre}**. Desde ahí abre tickets nuevos y ve la respuesta de cada uno."],
                             datos=[("Correo", correo_para), ("Clave temporal", clave)], boton_=("Entrar al portal de soporte", url),
                             despues=["Se le pedirá cambiar la clave al entrar."])
            correo.enviar(_cfg_smtp(e), [correo_para], f"Su acceso al portal de soporte · {e.nombre_comercial or e.nombre}", html, f"Portal de soporte: {url}\nCorreo: {correo_para}\nClave temporal: {clave}\n", [])
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=_enviar, daemon=True).start()


@router.post("/api/tike/accesos")
def crear_acceso(data: AccesoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; cfg = _config(s, eid)
    correo_c = data.correo.strip().lower()
    if not CORREO_RE.fullmatch(correo_c):
        raise HTTPException(400, "Revise el correo")
    if s.exec(select(AccesoPortal).where(AccesoPortal.empresa_id == eid, AccesoPortal.correo == correo_c)).first():
        raise HTTPException(400, "Ese correo ya tiene acceso")
    nombre = (data.nombre or "").strip()
    if data.cliente_id:
        c = s.get(Cliente, data.cliente_id)
        if not c or c.empresa_id != eid:
            raise HTTPException(400, "El cliente indicado no existe")
        nombre = nombre or c.nombre_comercial or c.nombre
    clave = data.clave or secrets.token_urlsafe(6)
    a = AccesoPortal(empresa_id=eid, cliente_id=data.cliente_id, correo=correo_c, nombre=nombre[:80], clave_hash=hash_password(clave), debe_cambiar=True)
    s.add(a); s.commit(); s.refresh(a)
    _enviar_clave(ctx.empresa, cfg, correo_c, nombre, clave)
    return {**_salida_acceso(a), "clave_temporal": clave if not data.clave else None}


@router.post("/api/tike/accesos/{aid}/clave")
def nueva_clave_acceso(aid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; a = s.get(AccesoPortal, aid)
    if not a or a.empresa_id != eid:
        raise HTTPException(404, "Acceso no encontrado")
    clave = secrets.token_urlsafe(6); a.clave_hash = hash_password(clave); a.debe_cambiar = True; a.activo = True; s.add(a); s.commit()
    _enviar_clave(ctx.empresa, _config(s, eid), a.correo, a.nombre, clave)
    return {**_salida_acceso(a), "clave_temporal": clave}


@router.delete("/api/tike/accesos/{aid}")
def quitar_acceso(aid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    a = s.get(AccesoPortal, aid)
    if not a or a.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Acceso no encontrado")
    a.activo = False; s.add(a); s.commit()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- buzón IMAP
def _mensajes_buzon(cfg: TikeConfig, password: str, limite: int = 50) -> list[bytes]:
    """Correos sin leer del buzón de soporte (se marcan leídos al traerlos). Las pruebas sustituyen esta función."""
    host, puerto = cfg.imap_host, int(cfg.imap_puerto or 993); seg = (cfg.imap_seguridad or "ssl").lower()
    ctx = ssl.create_default_context()
    try:
        if seg == "ssl":
            M = imaplib.IMAP4_SSL(host, puerto, ssl_context=ctx, timeout=40)
        else:
            M = imaplib.IMAP4(host, puerto, timeout=40)
            if seg == "starttls":
                M.starttls(ssl_context=ctx)
        M.login(cfg.imap_usuario, password)
    except imaplib.IMAP4.error as ex:
        raise RuntimeError(f"El servidor rechazó el usuario o la contraseña del buzón ({ex})")
    except (OSError, ssl.SSLError) as ex:
        raise RuntimeError(f"No se pudo conectar con {host}:{puerto} ({ex}). Revise servidor, puerto y seguridad")
    try:
        typ, _ = M.select(cfg.imap_carpeta or "INBOX")
        if typ != "OK":
            raise RuntimeError(f"No existe la carpeta {cfg.imap_carpeta or 'INBOX'} en el buzón")
        typ, datos = M.search(None, "UNSEEN")
        ids = datos[0].split() if typ == "OK" and datos and datos[0] else []
        out = []
        for uid in ids[:limite]:
            typ, partes = M.fetch(uid, "(RFC822)")
            if typ == "OK" and partes and isinstance(partes[0], tuple):
                out.append(partes[0][1])
                M.store(uid, "+FLAGS", "\\Seen")
        return out
    finally:
        try:
            M.logout()
        except Exception:  # noqa: BLE001
            pass


def _decodificar(v) -> str:
    if not v:
        return ""
    try:
        partes = email.header.decode_header(v)
        return "".join(p.decode(enc or "utf-8", "replace") if isinstance(p, bytes) else p for p, enc in partes)
    except Exception:  # noqa: BLE001
        return str(v)


def _cuerpo(msg) -> str:
    texto = ""
    for parte in msg.walk():
        if parte.get_content_type() == "text/plain" and not parte.get_filename():
            try:
                texto += (parte.get_payload(decode=True) or b"").decode(parte.get_content_charset() or "utf-8", "replace")
            except Exception:  # noqa: BLE001
                pass
    if not texto:
        for parte in msg.walk():
            if parte.get_content_type() == "text/html" and not parte.get_filename():
                try:
                    h = (parte.get_payload(decode=True) or b"").decode(parte.get_content_charset() or "utf-8", "replace")
                    texto = re.sub(r"<[^>]+>", " ", re.sub(r"(?is)<(script|style).*?</\1>", "", h))
                    texto = re.sub(r"[ \t]+", " ", re.sub(r"&nbsp;", " ", texto)).strip()
                except Exception:  # noqa: BLE001
                    pass
    # se corta lo citado de la respuesta anterior (lo más común)
    lineas = []
    for ln in texto.replace("\r", "").split("\n"):
        if re.match(r"^(El .* escribió:|On .* wrote:|-----\s*Mensaje original|From: |De: )", ln.strip()):
            break
        if ln.strip().startswith(">"):
            continue
        lineas.append(ln)
    return "\n".join(lineas).strip()[:5000]


def procesar_correo(s: Session, e: Empresa, cfg: TikeConfig, crudo: bytes) -> str:
    """Un correo del buzón: respuesta a un ticket ([TK-0001] en el asunto o en hilo) o ticket nuevo. Devuelve 'respuesta', 'nuevo' o 'ignorado'."""
    msg = email.message_from_bytes(crudo)
    asunto = _decodificar(msg.get("Subject")) or "(sin asunto)"
    nombre_de, correo_de = email.utils.parseaddr(_decodificar(msg.get("From")))
    correo_de = (correo_de or "").strip().lower()
    if not correo_de or correo_de == (cfg.imap_usuario or "").lower() or "mailer-daemon" in correo_de or msg.get("Auto-Submitted", "no").lower() not in ("no", ""):
        return "ignorado"
    mensaje_id = (msg.get("Message-ID") or "").strip()[:200]
    cuerpo = _cuerpo(msg) or "(sin texto)"
    eid = e.id
    m = re.search(rf"\[({re.escape((cfg.prefijo or 'TK').upper())}-\d{{4,}})\]", asunto.upper())
    t = None
    if m:
        t = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.codigo == m.group(1))).first()
    if not t:
        refs = " ".join(x for x in (msg.get("In-Reply-To") or "", msg.get("References") or "") if x)
        if refs:
            for cand in s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.mensaje_id != "")).all():
                if cand.mensaje_id and cand.mensaje_id in refs:
                    t = cand; break
    if t:
        if t.estado == "cerrado":
            t = None                                            # cerrado: se abre uno nuevo
        else:
            _registrar(s, t, "cliente", cuerpo, nombre_de or correo_de, publico=True, origen="correo")
            if t.estado in ("espera_cliente", "resuelto"):
                _cambiar_estado(s, t, "en_proceso" if t.tecnico_id else "nuevo", nombre_de or correo_de, "el cliente respondió por correo", origen="correo")
            return "respuesta"
    cliente = s.exec(select(Cliente).where(Cliente.empresa_id == eid, Cliente.correo == correo_de)).first()
    if not cliente:
        acc = s.exec(select(AccesoPortal).where(AccesoPortal.empresa_id == eid, AccesoPortal.correo == correo_de, AccesoPortal.cliente_id.isnot(None))).first()  # type: ignore[union-attr]
        cliente = s.get(Cliente, acc.cliente_id) if acc else None
    crear_ticket(s, e, cfg, asunto=asunto[:160], descripcion=cuerpo, cliente_id=cliente.id if cliente else None, solicitante=nombre_de or "", correo=correo_de, origen="correo", usuario=nombre_de or correo_de, mensaje_id=mensaje_id)
    return "nuevo"


def leer_buzon_empresa(eid: int) -> dict:
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    if not e:
        return {"nuevos": 0, "respuestas": 0}
    with sesion_de(eid) as s:
        cfg = _config(s, eid)
        if not cfg.buzon_activo or not cfg.imap_password:
            return {"nuevos": 0, "respuestas": 0}
        try:
            clave = secretos.descifrar(e.clave_cifrada, cfg.imap_password) or ""
            mensajes = _mensajes_buzon(cfg, clave)
        except Exception as ex:  # noqa: BLE001
            cfg.buzon_error = str(ex)[:300]; cfg.buzon_ultimo = ahora_cr().isoformat(timespec="seconds"); s.add(cfg); s.commit()
            raise HTTPException(502, cfg.buzon_error)
        r = {"nuevos": 0, "respuestas": 0, "ignorados": 0}
        for crudo in mensajes:
            try:
                k = procesar_correo(s, e, cfg, crudo)
            except Exception as ex:  # noqa: BLE001
                log.warning("TiKe buzón empresa %s: %s", eid, ex); k = "ignorado"
            r["nuevos" if k == "nuevo" else "respuestas" if k == "respuesta" else "ignorados"] += 1
        cfg.buzon_error = None; cfg.buzon_ultimo = ahora_cr().isoformat(timespec="seconds"); s.add(cfg); s.commit()
        return r


def leer_buzones_todas() -> int:
    total = 0
    with Session(engine) as sc:
        eids = [e.id for e in sc.exec(select(Empresa)).all() if "tike" in planes.modulos_de(e)]
    for eid in eids:
        try:
            r = leer_buzon_empresa(eid); total += r.get("nuevos", 0) + r.get("respuestas", 0)
        except Exception as ex:  # noqa: BLE001
            log.warning("TiKe buzón empresa %s: %s", eid, ex)
    return total


@router.post("/api/tike/buzon/leer")
def leer_buzon_ahora(ctx: Contexto = Depends(admin)):
    return leer_buzon_empresa(ctx.empresa.id)


@router.post("/api/tike/buzon/probar")
def probar_buzon(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    cfg = _config(s, ctx.empresa.id)
    if not (cfg.imap_host and cfg.imap_usuario and cfg.imap_password):
        raise HTTPException(400, "Guarde primero servidor, usuario y contraseña del buzón")
    try:
        clave = secretos.descifrar(ctx.empresa.clave_cifrada, cfg.imap_password) or ""
        n = len(_mensajes_buzon(cfg, clave, limite=0))
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(502, str(ex)[:300])
    return {"ok": True, "sin_leer": n}


# ------------------------------------------------------------------------------------------------- portal del cliente (público)
PAGINA = """<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{titulo}</title><meta name="robots" content="noindex"><link rel="icon" href="/img/fisitaap-icono.svg"><link rel="stylesheet" href="/tienda.css"><link rel="stylesheet" href="/soporte.css">
</head><body><div id="app" data-slug="{slug}" v-cloak></div><script type="module" src="/js/soporte.js"></script></body></html>"""


def _portal(slug: str) -> tuple[Empresa, int, TikeConfig]:
    with Session(engine) as sc:
        fila = sc.exec(select(TikeSlug).where(TikeSlug.slug == slug)).first()
        e = sc.get(Empresa, fila.empresa_id) if fila else None
    if not fila or not e or "tike" not in planes.modulos_de(e):
        raise HTTPException(404, "Portal no encontrado")
    with sesion_de(fila.empresa_id) as s:
        cfg = _config(s, fila.empresa_id)
        if not cfg.portal_activo or cfg.slug != slug:
            raise HTTPException(404, "Portal no encontrado")
    return e, fila.empresa_id, cfg


@router.get("/soporte/{slug}", response_class=HTMLResponse, include_in_schema=False)
def pagina_portal(slug: str):
    e, eid, cfg = _portal(slug)
    return HTMLResponse(PAGINA.format(titulo=escape(_titulo_portal(e, cfg)), slug=escape(slug)))


@router.get("/api/soporte/{slug}")
def info_portal(slug: str):
    e, eid, cfg = _portal(slug)
    return {"slug": slug, "titulo": _titulo_portal(e, cfg), "texto": cfg.portal_texto, "empresa": e.nombre_comercial or e.nombre, "categorias": _json(cfg.categorias, []), "prioridades": [[k, v] for k, v in NOMBRES_PRIORIDAD.items()],
            "estados": [[k, v] for k, v in NOMBRES_ESTADO.items()], "correo": e.correo, "telefono": str(getattr(e, "telefono", "") or "")}


class PortalAccesoIn(BaseModel):
    correo: str = PField(min_length=5, max_length=120)
    clave: str = PField(min_length=4, max_length=60)


class PortalClaveIn(BaseModel):
    clave_actual: str = PField(min_length=4, max_length=60)
    clave_nueva: str = PField(min_length=8, max_length=60)


def _acceso_token(x_portal: str | None, eid: int) -> Optional[int]:
    d = abrir(x_portal) if x_portal else None
    return int(d["aid"]) if d and d.get("tipo") == "portal" and int(d.get("eid", 0)) == eid else None


def _acceso(s: Session, eid: int, x_portal: str | None, temporal: bool = False) -> AccesoPortal:
    aid = _acceso_token(x_portal, eid)
    a = s.get(AccesoPortal, aid) if aid else None
    if not a or a.empresa_id != eid or not a.activo:
        raise HTTPException(401, "Ingrese con su correo y clave")
    if a.debe_cambiar and not temporal:            # 3.87: con la clave temporal solo se cambia la clave (antes bastaba recargar)
        raise HTTPException(403, {"codigo": "cambiar_clave", "mensaje": "Su clave es temporal: elija una nueva para seguir"})
    return a


@router.post("/api/soporte/{slug}/acceso")
def acceso_portal(slug: str, data: PortalAccesoIn, request: Request):
    e, eid, cfg = _portal(slug)
    correo_c = data.correo.strip().lower()
    limitar_ip(request, clave="tike", maximo=12, ventana=600, sujeto=f"portal:{eid}:{correo_c}", mensaje="Demasiados intentos. Espere unos minutos.")
    with sesion_de(eid) as s:
        a = s.exec(select(AccesoPortal).where(AccesoPortal.empresa_id == eid, AccesoPortal.correo == correo_c)).first()
        if not a or not a.activo or not verificar_password(data.clave, a.clave_hash):
            raise HTTPException(401, "Correo o clave incorrectos")
        a.ultimo_acceso = ahora_cr().isoformat(timespec="seconds"); s.add(a); s.commit()
        return {"token": firmar({"tipo": "portal", "eid": eid, "aid": a.id}, TOKEN_DIAS * 86400), "nombre": a.nombre, "correo": a.correo, "debe_cambiar": a.debe_cambiar}


@router.post("/api/soporte/{slug}/clave")
def cambiar_clave_portal(slug: str, data: PortalClaveIn, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal, temporal=True)
        if not verificar_password(data.clave_actual, a.clave_hash):
            raise HTTPException(400, "La clave actual no coincide")
        a.clave_hash = hash_password(data.clave_nueva); a.debe_cambiar = False; s.add(a); s.commit()
        return {"ok": True}


def _mis_tickets(s: Session, eid: int, a: AccesoPortal) -> list[Ticket]:
    q = select(Ticket).where(Ticket.empresa_id == eid)
    if a.cliente_id:
        ts = s.exec(q.where((Ticket.cliente_id == a.cliente_id) | (Ticket.correo == a.correo)).order_by(Ticket.id.desc())).all()  # type: ignore[operator]
    else:
        ts = s.exec(q.where(Ticket.correo == a.correo).order_by(Ticket.id.desc())).all()
    return ts


@router.get("/api/soporte/{slug}/tickets")
def portal_tickets(slug: str, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal)
        return [_salida(t, para_cliente=True) for t in _mis_tickets(s, eid, a)[:200]]


class PortalTicketIn(BaseModel):
    asunto: str = PField(min_length=3, max_length=160)
    descripcion: str = PField(min_length=3, max_length=5000)
    categoria: Optional[str] = PField("", max_length=60)
    prioridad: str = "media"
    telefono: Optional[str] = PField("", max_length=20)
    equipo_token: Optional[str] = PField(None, max_length=40)          # 3.53: QR pegado en el equipo


@router.get("/api/soporte/{slug}/equipo/{token}")
def portal_equipo(slug: str, token: str):
    e, eid, cfg = _portal(slug)
    from . import tike_contratos as _tc
    with sesion_de(eid) as s:
        q = _tc.equipo_por_token(s, eid, token)
        if not q:
            raise HTTPException(404, "Equipo no encontrado")
        c = s.get(Cliente, q.cliente_id)
        return {"codigo": q.codigo, "nombre": q.nombre, "tipo": q.tipo, "cliente": (c.nombre_comercial or c.nombre) if c else ""}


@router.post("/api/soporte/{slug}/tickets")
def portal_nuevo(slug: str, data: PortalTicketIn, request: Request, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    limitar_ip(request, clave="tike", maximo=20, ventana=3600, sujeto=f"portal-nuevo:{eid}", mensaje="Demasiados tickets seguidos. Espere unos minutos.")
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal)
        prioridad = data.prioridad if data.prioridad in ("baja", "media", "alta") else "media"      # crítica solo la pone el técnico
        equipo_id = None
        if data.equipo_token:
            from . import tike_contratos as _tc
            q = _tc.equipo_por_token(s, eid, data.equipo_token)
            if q and (not a.cliente_id or q.cliente_id == a.cliente_id):
                equipo_id = q.id
        t = crear_ticket(s, e, cfg, asunto=data.asunto, descripcion=data.descripcion, cliente_id=a.cliente_id, solicitante=a.nombre, correo=a.correo, telefono=data.telefono or "", categoria=data.categoria or "",
                         prioridad=prioridad, origen="portal", usuario=a.nombre or a.correo, equipo_id=equipo_id)
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


def _ticket_cliente(s: Session, eid: int, a: AccesoPortal, tid: int) -> Ticket:
    t = s.get(Ticket, tid)
    if not t or t.empresa_id != eid or not ((a.cliente_id and t.cliente_id == a.cliente_id) or (t.correo and t.correo == a.correo)):
        raise HTTPException(404, "Ticket no encontrado")
    return t


@router.get("/api/soporte/{slug}/tickets/{tid}")
def portal_ver(slug: str, tid: int, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal); t = _ticket_cliente(s, eid, a, tid)
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


class PortalRespuestaIn(BaseModel):
    texto: str = PField(min_length=1, max_length=5000)


class PortalCalificacionIn(BaseModel):
    puntos: int = PField(ge=1, le=5)
    comentario: Optional[str] = PField("", max_length=400)


def _responder_cliente(s: Session, t: Ticket, texto: str, quien: str, origen: str) -> None:
    if t.estado == "cerrado":
        raise HTTPException(400, "Este ticket ya está cerrado: abra uno nuevo")
    _registrar(s, t, "cliente", texto.strip(), quien, publico=True, origen=origen)
    if t.estado in ("espera_cliente", "resuelto"):
        _cambiar_estado(s, t, "en_proceso" if t.tecnico_id else "nuevo", quien, "el cliente respondió", origen=origen)


def _calificar(s: Session, t: Ticket, puntos: int, comentario: str, quien: str, origen: str) -> None:
    if t.estado not in ("resuelto", "cerrado"):
        raise HTTPException(400, "Solo se califica un ticket resuelto")
    t.calificacion = puntos; t.calificacion_nota = (comentario or "").strip()[:400]
    if t.estado == "resuelto":
        _cambiar_estado(s, t, "cerrado", quien, "cerrado por el cliente al calificar", origen=origen)
    else:
        s.add(t); s.commit()
    _registrar(s, t, "sistema", f"Calificación del cliente: {puntos}/5" + (f" · {t.calificacion_nota}" if t.calificacion_nota else ""), quien, publico=True, origen=origen)


@router.post("/api/soporte/{slug}/tickets/{tid}/responder")
def portal_responder(slug: str, tid: int, data: PortalRespuestaIn, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal); t = _ticket_cliente(s, eid, a, tid)
        _responder_cliente(s, t, data.texto, a.nombre or a.correo, "portal")
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


@router.post("/api/soporte/{slug}/tickets/{tid}/calificar")
def portal_calificar(slug: str, tid: int, data: PortalCalificacionIn, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal); t = _ticket_cliente(s, eid, a, tid)
        _calificar(s, t, data.puntos, data.comentario or "", a.nombre or a.correo, "portal")
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


# enlace del correo: ver y responder sin clave, solo con el token del ticket
def _por_token(s: Session, eid: int, token: str) -> Ticket:
    t = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.token == token)).first()
    if not t:
        raise HTTPException(404, "Ticket no encontrado")
    return t


@router.get("/api/soporte/{slug}/t/{token}")
def token_ver(slug: str, token: str):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        t = _por_token(s, eid, token)
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


@router.post("/api/soporte/{slug}/t/{token}/responder")
def token_responder(slug: str, token: str, data: PortalRespuestaIn, request: Request):
    e, eid, cfg = _portal(slug)
    limitar_ip(request, clave="tike", maximo=30, ventana=3600, sujeto=f"token:{eid}:{token}", mensaje="Demasiadas respuestas seguidas.")
    with sesion_de(eid) as s:
        t = _por_token(s, eid, token)
        _responder_cliente(s, t, data.texto, t.solicitante or t.correo or "cliente", "portal")
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)


@router.post("/api/soporte/{slug}/t/{token}/calificar")
def token_calificar(slug: str, token: str, data: PortalCalificacionIn):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        t = _por_token(s, eid, token)
        _calificar(s, t, data.puntos, data.comentario or "", t.solicitante or t.correo or "cliente", "portal")
        return _salida(t, s.exec(select(TicketEntrada).where(TicketEntrada.ticket_id == t.id).order_by(TicketEntrada.id)).all(), para_cliente=True)
