"""Diseño de los correos de publicidad (3.40): HTML de correo hecho solo con tablas, colores y texto, SIN imágenes externas, para que se
vea completo apenas se abre (Gmail y Outlook bloquean las imágenes externas hasta que el lector las permite) y no pese. 3.83: el
encabezado lleva el logo de FISITAAP dentro del correo (imagen «cid:», no se descarga de ningún lado) en vez del nombre en letras.

Formato del texto de la campaña (una marca por línea; línea en blanco = bloque nuevo):
  ## Subtítulo
  > Recuadro destacado
  - Lista con viñetas
  ✓ Lista con marcas de verificación (también «+ »)
  1. Pasos numerados («**Título.** detalle» pone el título en negrita)
  * 2 meses | Gratis, sin tarjeta          → cifras grandes en columnas (hasta 3 por fila)
  " Texto de la cita | Quién lo dice       → cita
  ---                                      → separador
  **negrita**, [texto del enlace](https://…) y direcciones https sueltas se vuelven enlaces.
"""
import html as _html
import re

TEMAS = {
    "fisitaap": {"nombre": "FISITAAP", "oscuro": "#08142f", "acento": "#1450f5", "suave": "#eef3ff", "borde": "#cddafb", "claro": "#7fd9b4"},
    "verde": {"nombre": "Verde", "oscuro": "#0f3d36", "acento": "#0f766e", "suave": "#e9f4f1", "borde": "#bfe0d9", "claro": "#9fd8cc"},
    "azul": {"nombre": "Azul", "oscuro": "#13294f", "acento": "#1d5fd1", "suave": "#ebf2fd", "borde": "#c2d5f5", "claro": "#a9c6f5"},
    "ambar": {"nombre": "Ámbar", "oscuro": "#43290a", "acento": "#b45309", "suave": "#fdf4e6", "borde": "#f1d5a6", "claro": "#f5c98a"},
    "vino": {"nombre": "Vino", "oscuro": "#46102a", "acento": "#a3204f", "suave": "#fcedf2", "borde": "#efc3d3", "claro": "#f2a9c3"},
    "grafito": {"nombre": "Grafito", "oscuro": "#1f2933", "acento": "#0f766e", "suave": "#eef1f4", "borde": "#d3d9df", "claro": "#9fd8cc"},
}
FUENTE = "Arial,Helvetica,sans-serif"
TEXTO = "#24302d"
GRIS = "#66736f"
e = _html.escape


def tema(nombre) -> dict:
    return TEMAS.get(nombre or "fisitaap") or TEMAS["fisitaap"]


def _enlinea(t: str, tm: dict) -> str:
    """Una línea de texto → HTML seguro con **negrita**, [texto](url) y direcciones sueltas como enlace."""
    t = e(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\[([^\]]{1,120})\]\(((?:https?://|mailto:)[^\s)]{3,500})\)",
               lambda m: f'<a href="{m.group(2)}" style="color:{tm["acento"]};font-weight:bold">{m.group(1)}</a>', t)
    return re.sub(r'(?<![">])(https?://[^\s<]+[^\s<.,;:!?)])', rf'<a href="\1" style="color:{tm["acento"]}">\1</a>', t)


def _tipo(linea: str) -> str:
    x = linea.strip()
    if re.fullmatch(r"-{3,}", x):
        return "sep"
    if x.startswith("## "):
        return "h2"
    if x.startswith("> "):
        return "nota"
    if re.match(r"^[-•]\s+", x):
        return "lista"
    if re.match(r"^[✓✔+]\s+", x):
        return "check"
    if re.match(r"^\d{1,2}[.)]\s+", x):
        return "paso"
    if x.startswith("* "):
        return "cifra"
    if x.startswith('" ') or x.startswith("“"):
        return "cita"
    return "p"


def _sin_marca(linea: str) -> str:
    return re.sub(r'^\s*(## |> |[-•]\s+|[✓✔+]\s+|\d{1,2}[.)]\s+|\* |" |“)', "", linea).strip().rstrip("”")


def _grupos(texto: str) -> list[tuple[str, list[str]]]:
    """Líneas consecutivas del mismo tipo forman un bloque; la línea en blanco corta."""
    out: list[tuple[str, list[str]]] = []
    previo = None
    for linea in (texto or "").replace("\r", "").split("\n"):
        if not linea.strip():
            previo = None
            continue
        t = _tipo(linea)
        if t in ("h2", "sep") or t != previo or not out:
            out.append((t, [linea]))
        else:
            out[-1][1].append(linea)
        previo = t if t not in ("h2", "sep") else None
    return out


def cuerpo_html(texto: str, tm: dict) -> str:
    partes = []
    for tipo, filas in _grupos(texto):
        limpias = [_sin_marca(x) for x in filas]
        if tipo == "h2":
            partes.append(f'<h2 style="margin:26px 0 10px;font-family:{FUENTE};font-size:19px;line-height:1.3;color:{tm["oscuro"]}">{_enlinea(limpias[0], tm)}</h2>')
        elif tipo == "sep":
            partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:22px 0"><tr><td style="border-top:1px solid {tm["borde"]};font-size:0;line-height:0">&nbsp;</td></tr></table>')
        elif tipo == "nota":
            partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:6px 0 18px"><tr>'
                          f'<td width="4" style="background:{tm["acento"]};font-size:0">&nbsp;</td>'
                          f'<td style="background:{tm["suave"]};padding:14px 18px;font-family:{FUENTE};font-size:15px;line-height:1.55;color:{tm["oscuro"]}">'
                          + "<br>".join(_enlinea(x, tm) for x in limpias) + "</td></tr></table>")
        elif tipo == "lista":
            partes.append('<ul style="margin:0 0 16px;padding-left:22px">' + "".join(f'<li style="margin:0 0 7px">{_enlinea(x, tm)}</li>' for x in limpias) + "</ul>")
        elif tipo == "check":
            filas_html = "".join(
                f'<tr><td width="30" valign="top" style="padding:2px 10px 10px 0"><table role="presentation" cellspacing="0" cellpadding="0"><tr>'
                f'<td width="22" height="22" align="center" style="background:{tm["acento"]};border-radius:11px;color:#ffffff;font-family:{FUENTE};font-size:13px;font-weight:bold;line-height:22px">&#10003;</td></tr></table></td>'
                f'<td valign="top" style="padding:2px 0 10px;font-family:{FUENTE};font-size:15px;line-height:1.5;color:{TEXTO}">{_enlinea(x, tm)}</td></tr>' for x in limpias)
            partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:4px 0 12px">{filas_html}</table>')
        elif tipo == "paso":
            filas_html = "".join(
                f'<tr><td width="44" valign="top" style="padding:0 12px 14px 0"><table role="presentation" cellspacing="0" cellpadding="0"><tr>'
                f'<td width="32" height="32" align="center" style="background:{tm["oscuro"]};border-radius:16px;color:#ffffff;font-family:{FUENTE};font-size:15px;font-weight:bold;line-height:32px">{i}</td></tr></table></td>'
                f'<td valign="top" style="padding:5px 0 14px;font-family:{FUENTE};font-size:15px;line-height:1.5;color:{TEXTO}">{_enlinea(x, tm)}</td></tr>' for i, x in enumerate(limpias, 1))
            partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:6px 0 10px">{filas_html}</table>')
        elif tipo == "cifra":
            for i in range(0, len(limpias), 3):
                fila = limpias[i:i + 3]
                ancho = int(100 / len(fila))
                celdas = []
                for j, x in enumerate(fila):
                    valor, _, texto_c = x.partition("|")
                    celdas.append(f'<td width="{ancho}%" valign="top" align="center" style="background:{tm["suave"]};border:1px solid {tm["borde"]};border-radius:10px;padding:16px 8px">'
                                  f'<div style="font-family:{FUENTE};font-size:26px;line-height:1.15;font-weight:bold;color:{tm["acento"]}">{_enlinea(valor.strip(), tm)}</div>'
                                  f'<div style="font-family:{FUENTE};font-size:13px;line-height:1.4;color:{GRIS};margin-top:6px">{_enlinea(texto_c.strip(), tm)}</div></td>')
                    if j < len(fila) - 1:
                        celdas.append('<td width="10" style="font-size:0">&nbsp;</td>')
                partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:8px 0 18px"><tr>{"".join(celdas)}</tr></table>')
        elif tipo == "cita":
            for x in limpias:
                dicho, _, quien = x.partition("|")
                partes.append(f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:10px 0 20px"><tr><td style="padding:4px 0 4px 18px;border-left:3px solid {tm["claro"]}">'
                              f'<div style="font-family:Georgia,\'Times New Roman\',serif;font-size:18px;line-height:1.5;font-style:italic;color:{tm["oscuro"]}">“{_enlinea(dicho.strip().strip(chr(34)), tm)}”</div>'
                              + (f'<div style="font-family:{FUENTE};font-size:13px;color:{GRIS};margin-top:8px">— {_enlinea(quien.strip(), tm)}</div>' if quien.strip() else "")
                              + "</td></tr></table>")
        else:
            partes.append(f'<p style="margin:0 0 16px">' + "<br>".join(_enlinea(x.strip(), tm) for x in filas) + "</p>")
    return "".join(partes)


def cuerpo_texto(texto: str) -> str:
    """Versión de texto plano (la usan los lectores que no muestran HTML y los filtros de spam)."""
    out = []
    for tipo, filas in _grupos(texto):
        limpias = [re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", re.sub(r"\*\*(.+?)\*\*", r"\1", _sin_marca(x))) for x in filas]
        if tipo == "h2":
            out.append(limpias[0].upper())
        elif tipo == "sep":
            out.append("----------")
        elif tipo in ("lista", "check"):
            out.append("\n".join(("- " if tipo == "lista" else "✓ ") + x for x in limpias))
        elif tipo == "paso":
            out.append("\n".join(f"{i}. {x}" for i, x in enumerate(limpias, 1)))
        elif tipo == "cifra":
            out.append("\n".join(" ".join(p.strip() for p in x.split("|")) for x in limpias))
        elif tipo == "cita":
            out.append("\n".join(f'"{x.partition("|")[0].strip()}"' + (f' — {x.partition("|")[2].strip()}' if x.partition("|")[2].strip() else "") for x in limpias))
        else:
            out.append("\n".join(limpias))
    return "\n\n".join(out)


def boton(texto: str, url: str, tm: dict) -> str:
    """Botón «a prueba de Outlook»: celda con fondo de color (no depende de imágenes ni de CSS avanzado)."""
    return (f'<table role="presentation" cellspacing="0" cellpadding="0" style="margin:24px 0 8px"><tr>'
            f'<td align="center" bgcolor="{tm["acento"]}" style="background:{tm["acento"]};border-radius:8px">'
            f'<a href="{e(url)}" style="display:inline-block;padding:14px 26px;font-family:{FUENTE};font-size:16px;font-weight:bold;color:#ffffff;text-decoration:none;border-radius:8px">{e(texto)}</a>'
            "</td></tr></table>")


def documento(*, asunto: str, antetitulo: str, titulo: str, cuerpo: str, preencabezado: str, imagen_url, boton_texto, boton_url,
              tema_nombre, pie: str, base: str, url_baja: str) -> str:
    tm = tema(tema_nombre)
    sitio = base.replace("https://", "").replace("http://", "")
    pre = (f'<div style="display:none;max-height:0;overflow:hidden;mso-hide:all;font-size:1px;line-height:1px;color:#f3f5f4">{e(preencabezado)}'
           + "&#8199;&#65279;&#847;" * 40 + "</div>") if preencabezado else ""
    from . import correo_diseno as _dz                     # 3.83: logo de FISITAAP dentro del correo
    imagenes = []
    logo = _dz._placa(_dz.LOGO_PLATAFORMA, 200, 62, placa=False) if _dz.LOGO_PLATAFORMA.exists() else None
    if logo:
        cid = "logo-" + __import__("hashlib").sha1(logo[0]).hexdigest()[:12] + "@fisitaap"
        imagenes.append((cid, logo[0], "image", "png"))
        marca = f'<img src="cid:{cid}" width="{logo[1]}" height="{logo[2]}" alt="FISITAAP" style="display:block;border:0;outline:none;width:{logo[1]}px;height:{logo[2]}px">'
    else:
        marca = f'<span style="font-family:{FUENTE};font-size:21px;font-weight:bold;color:#ffffff">FISITAAP</span>'
    from .config import FIRMA_MARCA
    if FIRMA_MARCA:                                          # 3.86: «by Brillante Agencia» bajo el logo
        marca += f'<div style="font-family:{FUENTE};font-size:12px;font-weight:bold;letter-spacing:0.3px;color:#c9d7e3;margin:8px 0 0">{e(FIRMA_MARCA)}</div>'
    heroe = ""
    if titulo or antetitulo:
        heroe = (f'<tr><td bgcolor="{tm["oscuro"]}" style="background:{tm["oscuro"]};padding:8px 32px 34px">'
                 + (f'<div style="font-family:{FUENTE};font-size:12px;font-weight:bold;letter-spacing:1.5px;text-transform:uppercase;color:{tm["claro"]};margin:0 0 10px">{e(antetitulo)}</div>' if antetitulo else "")
                 + (f'<h1 style="margin:0;font-family:{FUENTE};font-size:28px;line-height:1.25;font-weight:bold;color:#ffffff">{e(titulo)}</h1>' if titulo else "")
                 + "</td></tr>")
    imagen = f'<tr><td><img src="{e(imagen_url)}" width="600" alt="" style="display:block;width:100%;height:auto;border:0"></td></tr>' if imagen_url else ""
    btn = boton(boton_texto.strip(), boton_url, tm) if (boton_texto or "").strip() and boton_url else ""
    return _dz._html_con(
        '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light">'
        f'<title>{e(asunto)}</title></head><body style="margin:0;padding:0;background:#f3f5f4;-webkit-text-size-adjust:100%">{pre}'
        '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="#f3f5f4" style="background:#f3f5f4"><tr><td align="center" style="padding:24px 10px">'
        f'<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:14px;overflow:hidden;font-family:{FUENTE};color:{TEXTO}">'
        f'<tr><td bgcolor="{tm["oscuro"]}" style="background:{tm["oscuro"]};padding:22px 32px 18px">{marca}</td></tr>'
        + heroe + imagen
        + f'<tr><td style="padding:30px 32px 14px;font-family:{FUENTE};font-size:15px;line-height:1.6;color:{TEXTO}">{cuerpo_html(cuerpo, tm)}{btn}</td></tr>'
        + f'<tr><td style="padding:0 32px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td style="border-top:1px solid #e3e8e6;font-size:0;line-height:0">&nbsp;</td></tr></table></td></tr>'
        + f'<tr><td style="padding:18px 32px 26px;font-family:{FUENTE};font-size:12px;line-height:1.6;color:{GRIS}">'
        f'<b style="color:{tm["oscuro"]}">{e(pie)}</b><br><a href="{e(base)}" style="color:{GRIS}">{e(sitio)}</a><br>'
        f'Recibe este correo porque es cliente o pidió información de FISITAAP by Brillante Agencia. '
        f'Si no desea recibir más correos como este, <a href="{e(url_baja)}" style="color:{GRIS}">dese de baja aquí</a>.'
        '</td></tr></table></td></tr></table></body></html>', imagenes)
