# -*- coding: utf-8 -*-
"""4.24 · Etiquetas de productos con código de barras (servidor).

- El código de barras es el «Código» del producto (Producto.codigo) y no se repite: aquí están la regla y las ayudas que usan
  todas las rutas que crean o cambian productos (main.py, compras_inventario.py, traslados.py). No hay índice único en la base
  (en producción puede haber repetidos de antes): solo se impide PONER o CAMBIAR a un código que ya tiene otro producto.
- Códigos alternos (Producto.codigos_alternos, texto separado por comas, hasta 5): el código que se reemplazó sigue encontrando
  el producto en la caja.
- Rutas: GET /api/productos/codigos/repetidos, POST /api/productos/codigos/generar y POST /api/productos/etiquetas (PDF a la
  medida de la etiqueta). Las medidas, los formatos y los topes son los de app/etiquetas_impresora.py."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select

from . import etiquetas_impresora as ei
from .auth import Contexto, contexto, requiere, sesion_empresa
from .db import Producto

router = APIRouter(tags=["etiquetas"])


# ---------------------------------------------------------------------------------------------- códigos alternos
def alternos(p) -> list[str]:
    """Códigos alternos del producto, el más reciente primero."""
    return [x for x in (c.strip() for c in str(getattr(p, "codigos_alternos", None) or "").split(",")) if x]


def _unir(codigos, actual=None) -> Optional[str]:
    """Lista de códigos → texto de la columna: sin vacíos, sin repetidos (sin distinguir mayúsculas), sin el código actual del
    producto y hasta ALTERNOS_MAX (salen los más viejos). Un código con una coma no se puede guardar en la lista: se deja fuera."""
    out, vistos = [], {ei.norm_codigo(actual)} - {""}
    for c in codigos:
        c = str(c if c is not None else "").strip()
        k = c.lower()
        if not c or "," in c or k in vistos:
            continue
        vistos.add(k); out.append(c)
    return ",".join(out[:ei.ALTERNOS_MAX]) or None


def agregar_alterno(p, codigo) -> None:
    """El código que se reemplaza entra de primero en los alternos del producto."""
    p.codigos_alternos = _unir([codigo] + alternos(p), p.codigo)


# ---------------------------------------------------------------------------------------------- el código no se repite
def _codigos_de_la_empresa(s: Session, eid: int) -> list:
    """(id, nombre, codigo, codigos_alternos, activo) de los productos de la empresa que tienen código o códigos alternos (también
    los inactivos: conservan su código). Sin autoflush: quien pregunta puede tener a medio cambiar el producto que está guardando."""
    with s.no_autoflush:
        return list(s.exec(select(Producto.id, Producto.nombre, Producto.codigo, Producto.codigos_alternos, Producto.activo).where(
            Producto.empresa_id == eid, (Producto.codigo.is_not(None)) | (Producto.codigos_alternos.is_not(None)))).all())


def otro_con_codigo(s: Session, eid: int, codigo, excepto_id=None, filas=None) -> Optional[tuple]:
    """(id, nombre, activo) del primer OTRO producto de la empresa que ya usa ese código, como código (primero) o como código
    alterno; None si está libre. Compara sin espacios a los lados y sin distinguir mayúsculas."""
    c = ei.norm_codigo(codigo)
    if not c:
        return None
    por_alterno = None
    for pid, nombre, cod, alt, activo in (filas if filas is not None else _codigos_de_la_empresa(s, eid)):
        if pid == excepto_id:
            continue
        if ei.norm_codigo(cod) == c:
            return (pid, nombre, activo)
        if por_alterno is None and alt and c in {ei.norm_codigo(a) for a in str(alt).split(",")}:
            por_alterno = (pid, nombre, activo)
    return por_alterno


def mensaje_repetido(codigo, nombre, activo=True) -> str:
    """El mensaje del choque. Si el otro producto está INACTIVO lo dice: el usuario no lo ve en la lista de activos."""
    return f"Ya existe otro producto con el código {str(codigo).strip()}: {nombre}" + (" (está inactivo: actívelo o cámbiele el código)" if activo is not None and not activo else "")


def exigir_codigo_libre(s: Session, eid: int, codigo, excepto_id=None, prefijo: str = "") -> None:
    """409 si OTRO producto de la empresa ya tiene ese código (o lo tiene como código alterno)."""
    otro = otro_con_codigo(s, eid, codigo, excepto_id)
    if otro is not None:
        raise HTTPException(409, prefijo + mensaje_repetido(codigo, otro[1], otro[2]))


def producto_con_codigo(s: Session, eid: int, codigo) -> Optional[Producto]:
    """El producto de la empresa que responde a ese código (por su código o por un código alterno), o None."""
    otro = otro_con_codigo(s, eid, codigo)
    return s.get(Producto, otro[0]) if otro is not None else None


def codigo_generado(codigo) -> bool:
    """Un código con la forma de los generados (codigo_barras_propio): un EAN-13 de uso interno (empieza con «2») o «P» + 3
    dígitos + «-» + número. Lleva la marca de la empresa (3 dígitos, de su cédula y su código de sucursal) y el id del producto: dos empresas con la
    misma marca, o una balanza que usa ese rango, pueden dar el mismo código a OTRO artículo, así que por sí solo no identifica
    un ítem que viene de otra empresa (traslados, o un archivo de ítems exportado allá)."""
    c = ei.norm_codigo(codigo)
    if ei.es_ean13(c):
        return c.startswith("2")
    return len(c) > 5 and c[0] == "p" and c[4] == "-" and (c[1:4] + c[5:]).isascii() and (c[1:4] + c[5:]).isdigit()


def aplicar_cambio_de_codigo(s: Session, eid: int, p: Producto, codigo_antes, cuerpo: Optional[dict]) -> None:
    """Cambio de un producto por PUT /api/productos/{id}, ya con los campos nuevos puestos en `p` y antes de guardar:
    - `codigos_alternos` en el cuerpo (lista o texto con comas) reemplaza la lista (la ficha quita uno); un alterno que el
      producto no tenía tampoco puede ser de otro producto;
    - si el código cambia, no puede tenerlo otro producto (409 con su nombre); con `conservar_codigo_anterior` el anterior
      queda como código alterno («Registrar código», «Generar»);
    - un cambio que no toca el código no se revisa, aunque ese código esté repetido desde antes."""
    cuerpo = cuerpo or {}
    if "codigos_alternos" in cuerpo:
        v = cuerpo.get("codigos_alternos")
        pedidos = [str(x if x is not None else "").strip() for x in (v if isinstance(v, (list, tuple)) else str(v or "").split(","))]
        pedidos = [x for x in pedidos if x]
        if len(pedidos) > ei.ALTERNOS_MAX:
            raise HTTPException(400, f"Un producto guarda hasta {ei.ALTERNOS_MAX} códigos alternos")
        tenia = {ei.norm_codigo(a) for a in alternos(p)}
        for a in pedidos:
            if ei.norm_codigo(a) in tenia:               # los que ya tenía se quedan como están
                continue
            if "," in a or len(a) > ei.CODIGO_MAX:
                raise HTTPException(400, f"Un código alterno no puede llevar comas ni pasar de {ei.CODIGO_MAX} caracteres")
            exigir_codigo_libre(s, eid, a, p.id)
        p.codigos_alternos = _unir(pedidos)
    nuevo = str(p.codigo if p.codigo is not None else "").strip() or None
    if ei.norm_codigo(nuevo) != ei.norm_codigo(codigo_antes):
        if nuevo:
            exigir_codigo_libre(s, eid, nuevo, p.id)
        anterior = str(codigo_antes if codigo_antes is not None else "").strip()
        lista = alternos(p)
        if cuerpo.get("conservar_codigo_anterior") and anterior:
            lista = [anterior] + lista
        p.codigos_alternos = _unir(lista, nuevo)
    if "codigo" in cuerpo:
        p.codigo = nuevo


# ---------------------------------------------------------------------------------------------- repetidos que ya existan
@router.get("/api/productos/codigos/repetidos")
def codigos_repetidos(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Códigos que hoy tienen dos o más productos (de antes de la regla): la caja toma el primero que encuentra."""
    grupos: dict[str, list] = {}
    for pid, nombre, cod, _alt, _activo in sorted(_codigos_de_la_empresa(s, ctx.empresa.id), key=lambda f: (str(f[1] or "").lower(), f[0])):
        c = ei.norm_codigo(cod)
        if c:
            grupos.setdefault(c, []).append({"id": pid, "nombre": nombre, "codigo": str(cod).strip()})
    rep = [{"codigo": g[0]["codigo"], "productos": g} for g in grupos.values() if len(g) > 1]
    rep.sort(key=lambda g: g["codigo"].lower())
    return {"grupos": rep, "codigos": len(rep), "productos": sum(len(g["productos"]) for g in rep)}


# ---------------------------------------------------------------------------------------------- código autogenerado
class GenerarIn(BaseModel):
    ids: Optional[list[int]] = None
    todos: bool = False                 # todos los productos de la empresa
    reemplazar: bool = False            # también a los que ya tienen código (el anterior queda como código alterno)


@router.post("/api/productos/codigos/generar")
def generar_codigos(data: GenerarIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    """Pone a cada producto su código de barras propio (etiquetas_impresora.codigo_barras_propio). Sin `reemplazar`, solo a los
    que NO tienen código; con `reemplazar`, también a los que ya tienen, y el anterior queda como código alterno. Si el código
    propio de un producto ya lo tiene otro (alguien lo escribió a mano) no se pisa: se informa. Nunca corre sola: es la acción
    «Generar códigos de barras» que dispara el usuario."""
    eid = ctx.empresa.id
    if data.todos:
        productos = list(s.exec(select(Producto).where(Producto.empresa_id == eid).order_by(Producto.id)).all())
    else:
        ids = list(dict.fromkeys(int(i) for i in (data.ids or [])))
        if not ids:
            raise HTTPException(400, "Elija al menos un producto")
        if len(ids) > 5000:
            raise HTTPException(400, "Demasiados productos en una sola acción")
        productos = [p for p in (s.get(Producto, i) for i in ids) if p is not None and p.empresa_id == eid]
    from . import sinc
    propios, ajenos = sinc.separar_ajenos(eid, [p.id for p in productos])
    if not ajenos:
        return _generar_aqui(productos, data, ctx, s)
    # 4.25 (tanda 9, F-7): los productos de esta computadora se generan aquí como siempre; los demás, en la web (en bloques)
    ajenos_set = set(ajenos)
    res = _generar_aqui([p for p in productos if p.id not in ajenos_set], data, ctx, s) if propios else {"ok": True, "cambiados": 0, "sin_cambio": 0, "no_se_pudo": [], "codigos": {}}
    res["no_se_pudo"] = list(res["no_se_pudo"])
    marca = ei.marca_empresa(ctx.empresa.numero_id, ctx.empresa.sucursal)
    filas = _codigos_de_la_empresa(s, eid)
    por_id = {p.id: p for p in productos}
    enviar = []
    for i in ajenos:
        p = por_id[i]
        propio, actual = ei.codigo_barras_propio(p.id, marca), str(p.codigo if p.codigo is not None else "").strip()
        otro = None if ei.es_codigo_propio(actual, p.id) or (actual and not data.reemplazar) else otro_con_codigo(s, eid, propio, p.id, filas)
        if otro is not None:                                            # F-6: si OTRO producto de aquí ya lo tiene, no se llama
            res["no_se_pudo"].append({"id": p.id, "nombre": p.nombre, "codigo": propio, "motivo": mensaje_repetido(propio, otro[1], otro[2])})
        else:
            enviar.append(p.id)
    sin_guardar, motivo = [], ""
    for k in range(0, len(enviar), sinc.MAX_IDS_PRODUCTO):
        bloque = enviar[k:k + sinc.MAX_IDS_PRODUCTO]
        if motivo:
            sin_guardar += bloque; continue
        try:
            j = sinc.producto_en_la_web(eid, "generar", {"ids": bloque, "reemplazar": bool(data.reemplazar), "por": _quien(ctx)})
        except HTTPException as ex:
            motivo = ex.detail if ex.status_code != 503 and isinstance(ex.detail, str) else sinc.MENSAJE_ITEM_WEB
            sin_guardar += bloque; continue
        sinc.aplicar_filas_web(s, eid, j["productos"], bloque); s.commit()
        r = j["resultado"] if isinstance(j.get("resultado"), dict) else {}
        res["cambiados"] += int(r.get("cambiados") or 0); res["sin_cambio"] += int(r.get("sin_cambio") or 0)
        res["no_se_pudo"] += [x for x in r.get("no_se_pudo") or [] if isinstance(x, dict)]
        res["codigos"].update({str(a): str(b) for a, b in (r.get("codigos") or {}).items() if str(a) in {str(x) for x in bloque}})
    for i in sin_guardar:
        res["no_se_pudo"].append({"id": i, "nombre": por_id[i].nombre, "codigo": "", "motivo": motivo, "web": True})   # 9b (U18): la pantalla los separa
    if sin_guardar:
        res["no_guardados"] = len(sin_guardar)
        n = len(sin_guardar)
        res["aviso"] = f"{n} {'producto creado' if n == 1 else 'productos creados'} en la página web no {'se cambió' if n == 1 else 'se cambiaron'}. {motivo}"
    res["no_se_pudo"] = res["no_se_pudo"][:300]
    return res


def _quien(ctx) -> str:
    from .main import _quien_programa
    return _quien_programa(ctx)


def _generar_aqui(productos: list, data: GenerarIn, ctx: Contexto, s: Session) -> dict:
    eid = ctx.empresa.id
    duenos: dict[str, list] = {}                       # código o código alterno → [(id, nombre, activo)] de quienes lo usan hoy
    for pid, nombre, cod, alt, activo in _codigos_de_la_empresa(s, eid):
        for c in {ei.norm_codigo(cod)} | {ei.norm_codigo(a) for a in str(alt or "").split(",")}:
            if c:
                duenos.setdefault(c, []).append((pid, nombre, activo))
    cambiados, sin_cambio, no_se_pudo, codigos = 0, 0, [], {}
    marca = ei.marca_empresa(ctx.empresa.numero_id, ctx.empresa.sucursal)    # cédula y código de sucursal: el código no coincide con el de otra empresa del grupo
    for p in productos:
        propio = ei.codigo_barras_propio(p.id, marca)
        actual = str(p.codigo if p.codigo is not None else "").strip()
        if ei.es_codigo_propio(actual, p.id) or (actual and not data.reemplazar):   # ya tiene el suyo (con cualquier marca: no se le vuelve a cambiar si la empresa corrigió su cédula)
            sin_cambio += 1
            continue
        otros = [(n, a) for i, n, a in duenos.get(ei.norm_codigo(propio), []) if i != p.id]
        if otros:
            no_se_pudo.append({"id": p.id, "nombre": p.nombre, "codigo": propio, "motivo": mensaje_repetido(propio, *otros[0])})
            continue
        p.codigo = propio
        if actual:
            agregar_alterno(p, actual)
        s.add(p); cambiados += 1; codigos[str(p.id)] = propio
    s.commit()
    from .main import _auditar
    _auditar(ctx, "productos_codigos", f"{cambiados} código(s) de barras generados "
             + ("reemplazando los que ya tenían (el anterior queda como código alterno)" if data.reemplazar else "solo a los productos que no tenían código")
             + (f"; {len(no_se_pudo)} sin generar porque su código ya es de otro producto" if no_se_pudo else ""))
    return {"ok": True, "cambiados": cambiados, "sin_cambio": sin_cambio, "no_se_pudo": no_se_pudo[:300], "codigos": codigos}


# ---------------------------------------------------------------------------------------------- etiquetas en PDF
_SIMBOLO = {"CRC": "¢", "USD": "$", "EUR": "€"}      # Helvetica no trae «₡»; «¢» es la notación aceptada en Costa Rica (como en el tiquete)
CARTA_MM = (215.9, 279.4)


def texto_precio(valor, moneda="CRC") -> str:
    """Precio como va en la etiqueta: símbolo de la moneda y formato de Costa Rica (¢1.234,56)."""
    n = f"{float(valor or 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    m = str(moneda or "CRC").upper()
    return (_SIMBOLO[m] if m in _SIMBOLO else m + " ") + n


def _imprimible(codigo) -> bool:
    """Un código que se puede poner en barras (Code128): solo caracteres ASCII visibles."""
    c = str(codigo or "")
    return bool(c) and all(32 <= ord(ch) <= 126 for ch in c)


def _latin(texto, tope=200) -> str:
    """Texto para las letras del PDF (Helvetica): limpio y solo con lo que esa letra sabe dibujar."""
    return ei.limpiar(texto, tope).encode("cp1252", "replace").decode("cp1252")


def pdf_etiquetas(etiquetas: list[dict], ancho_mm: float, alto_mm: float, hoja: Optional[str] = None, dpi: int = 203) -> bytes:
    """PDF de etiquetas. `etiquetas` = [{nombre, codigo, precio, copias}] (nombre o precio vacíos = no se imprimen).
    Sin `hoja`: UNA etiqueta por página, y la página mide lo que la etiqueta (para la impresora de etiquetas con su
    controlador). Con hoja='carta': las mismas etiquetas en cuadrícula sobre hoja carta, con guías de corte (impresora común).
    Arriba el nombre (hasta 2 renglones; la letra se achica si no cabe), al centro el código de barras con su zona quieta
    (EAN-13 si el código lo es; si no, Code128), debajo el número legible y, si viene, el precio. `dpi` = la resolución de la
    impresora que lo va a imprimir (203 si no se sabe): las barras miden puntos enteros de esa resolución."""
    from reportlab.graphics import renderPDF
    from reportlab.graphics.barcode import code128, eanbc
    from reportlab.graphics.shapes import Drawing
    from reportlab.lib.units import mm
    from reportlab.lib.utils import simpleSplit
    from reportlab.pdfbase.pdfmetrics import stringWidth
    from reportlab.pdfgen import canvas
    import io

    W, H = float(ancho_mm) * mm, float(alto_mm) * mm
    M = (1.5 if alto_mm >= 20 else 1.0) * mm                    # margen de la etiqueta
    G = 0.6 * mm                                                # aire entre bloques
    util = W - 2 * M

    def plan(nombre, codigo, precio):
        """Tamaños de una etiqueta: [(renglones del nombre, tamaño)], barras (tipo, ancho del módulo, alto) y tamaños del número y del precio."""
        f_num = max(5.5, min(9.0, H * 0.09))
        f_pre = max(7.0, min(14.0, H * 0.13)) if precio else 0
        if stringWidth(codigo, "Helvetica", f_num) > util:                                  # el número siempre cabe
            f_num = max(4.0, f_num * util / stringWidth(codigo, "Helvetica", f_num))
        ean = ei.es_ean13(codigo)
        if ean:
            modulos, quieta = 95, 22                                                        # 11 módulos a la izquierda y 7 a la derecha; centrado, 11 por lado
        else:
            modulos, quieta = code128.Code128(codigo, barWidth=1, quiet=False).width, 20   # con barWidth=1 el ancho es el número de módulos
        # el módulo (la barra más angosta) mide un número entero de puntos de la impresora (203 por pulgada si no se sabe otra), con
        # la misma regla del envío directo: con una fracción, al imprimir el PDF unas barras salían de un punto más que otras y el lector fallaba
        puntos = ei.puntos_del_modulo(float(ancho_mm) * dpi / 25.4, modulos + quieta, dpi, ean)
        modulo = puntos * 25.4 / dpi * mm
        if puntos < 1:
            raise ValueError(f"El código {codigo} no cabe en una etiqueta de {ancho_mm:g} mm de ancho: use una etiqueta más ancha")
        fijo = 2 * M + f_num * 1.15 + G + (f_pre * 1.15 + G if precio else 0)

        def ajustar(tope):
            """El nombre en hasta `tope` renglones: la letra se achica hasta que quepa (mínimo 5 puntos); si ni así, se recorta con «…»."""
            tam = max(6.0, min(12.0, H * 0.11))
            while True:
                lineas = simpleSplit(nombre, "Helvetica-Bold", tam, util)
                if (len(lineas) <= tope and all(stringWidth(x, "Helvetica-Bold", tam) <= util for x in lineas)) or tam <= 5.0:
                    break
                tam = max(5.0, tam - 0.5)
            sobra = len(lineas) > tope
            lineas = lineas[:tope]
            for i, ln in enumerate(lineas):
                if stringWidth(ln, "Helvetica-Bold", tam) > util or (sobra and i == len(lineas) - 1):
                    while ln and stringWidth(ln + "…", "Helvetica-Bold", tam) > util:
                        ln = ln[:-1]
                    lineas[i] = ln.rstrip() + "…"
            return lineas, tam

        def alto_de_barras(lineas, tam):
            return H - fijo - (len(lineas) * tam * 1.15 + G if lineas else 0)

        lineas, tam = ajustar(2) if nombre else ([], 0.0)
        if len(lineas) > 1 and alto_de_barras(lineas, tam) < 5 * mm:                         # etiqueta baja: el nombre en un solo renglón, las barras primero
            lineas, tam = ajustar(1)
        alto_barras = alto_de_barras(lineas, tam)
        if alto_barras < 3 * mm:
            raise ValueError(f"Una etiqueta de {alto_mm:g} mm de alto es muy baja para ese formato: elija otra medida o «Solo el código de barras»")
        return {"lineas": lineas, "tam": tam, "ean": ean, "modulo": modulo, "modulos": modulos, "alto_barras": min(alto_barras, 25 * mm), "f_num": f_num, "f_pre": f_pre}

    def dibujar(cv, x0, y0, e, p):
        """Una etiqueta en el recuadro (x0, y0, W, H); el origen del PDF está abajo a la izquierda."""
        total = (len(p["lineas"]) * p["tam"] * 1.15 + G if p["lineas"] else 0) + p["alto_barras"] + G + p["f_num"] * 1.15 + (G + p["f_pre"] * 1.15 if p["f_pre"] else 0)
        y = y0 + H - M - max(0.0, (H - 2 * M - total) / 2)          # tope del bloque, centrado en la etiqueta
        xc = x0 + W / 2
        cv.setFillColorRGB(0, 0, 0)
        if p["lineas"]:
            cv.setFont("Helvetica-Bold", p["tam"])
            for ln in p["lineas"]:
                y -= p["tam"] * 1.15
                cv.drawCentredString(xc, y + p["tam"] * 0.25, ln)
            y -= G
        y -= p["alto_barras"]
        xb = xc - p["modulos"] * p["modulo"] / 2
        if p["ean"]:
            d = Drawing(p["modulos"] * p["modulo"], p["alto_barras"])
            d.add(eanbc.Ean13BarcodeWidget(e["codigo"][:12], barWidth=p["modulo"], barHeight=p["alto_barras"], humanReadable=False, quiet=False))
            renderPDF.draw(d, cv, xb, y)
        else:
            code128.Code128(e["codigo"], barWidth=p["modulo"], barHeight=p["alto_barras"], quiet=False).drawOn(cv, xb, y)
        y -= G + p["f_num"] * 1.15
        cv.setFont("Helvetica", p["f_num"]); cv.drawCentredString(xc, y + p["f_num"] * 0.25, e["codigo"])
        if p["f_pre"]:
            y -= G + p["f_pre"] * 1.15
            cv.setFont("Helvetica-Bold", p["f_pre"]); cv.drawCentredString(xc, y + p["f_pre"] * 0.25, e["precio"])

    listas = []
    for e in etiquetas:
        e = {"nombre": _latin(e.get("nombre")), "codigo": str(e.get("codigo") or "").strip(), "precio": _latin(e.get("precio"), 30), "copias": int(e.get("copias") or 1)}
        listas.append((e, plan(e["nombre"], e["codigo"], e["precio"])))
    buf = io.BytesIO()
    if hoja == "carta":
        PW, PH = CARTA_MM[0] * mm, CARTA_MM[1] * mm
        sep = 2 * mm
        cols = max(1, int((PW - 12 * mm + sep) // (W + sep))); filas = max(1, int((PH - 16 * mm + sep) // (H + sep)))
        mx, my = (PW - cols * W - (cols - 1) * sep) / 2, (PH - filas * H - (filas - 1) * sep) / 2
        cv = canvas.Canvas(buf, pagesize=(PW, PH)); cv.setTitle("Etiquetas de productos")
        n = 0
        for e, p in listas:
            for _ in range(e["copias"]):
                if n and n % (cols * filas) == 0:
                    cv.showPage()
                c, f = (n % (cols * filas)) % cols, (n % (cols * filas)) // cols
                x0, y0 = mx + c * (W + sep), PH - my - (f + 1) * H - f * sep
                cv.setStrokeColorRGB(0.75, 0.75, 0.75); cv.setLineWidth(0.3); cv.setDash(1, 2); cv.rect(x0, y0, W, H); cv.setDash()   # guía de corte
                dibujar(cv, x0, y0, e, p)
                n += 1
    else:
        cv = canvas.Canvas(buf, pagesize=(W, H)); cv.setTitle("Etiquetas de productos")
        primera = True
        for e, p in listas:
            for _ in range(e["copias"]):
                if not primera:
                    cv.showPage()
                primera = False
                dibujar(cv, 0, 0, e, p)
    cv.save()
    return buf.getvalue()


class ItemEtiquetaIn(BaseModel):
    id: int
    copias: int = 1


class EtiquetasIn(BaseModel):
    items: list[ItemEtiquetaIn] = []
    formato: str = "nombre_codigo"
    ancho_mm: float = 50
    alto_mm: float = 30
    hoja: Optional[str] = None          # 'carta' = cuadrícula en hoja carta (impresora común); vacío = una etiqueta por página
    prueba: bool = False                # etiqueta de prueba (Configuración › Impresoras), sin productos
    dpi: Optional[int] = None           # resolución de la impresora de etiquetas elegida (203, 300 o 600); sin dato, 203


def validar_pedido(formato, ancho_mm, alto_mm, copias: list) -> None:
    """Topes comunes del PDF y del envío directo: formato, medida, 1 a COPIAS_MAX por producto y hasta ETIQUETAS_MAX por pedido."""
    if formato not in ei.FORMATOS:
        raise HTTPException(400, "El formato de la etiqueta no existe")
    if not ei.medida_valida(ancho_mm, alto_mm):
        raise HTTPException(400, f"La medida de la etiqueta va de {ei.ANCHO_MIN} a {ei.ANCHO_MAX} mm de ancho y de {ei.ALTO_MIN} a {ei.ALTO_MAX} mm de alto")
    if not copias:
        raise HTTPException(400, "Elija al menos un producto")
    if any(n < 1 or n > ei.COPIAS_MAX for n in copias):
        raise HTTPException(400, f"Las copias de cada producto van de 1 a {ei.COPIAS_MAX}")
    if sum(copias) > ei.ETIQUETAS_MAX:
        raise HTTPException(400, f"Un pedido lleva hasta {ei.ETIQUETAS_MAX:,} etiquetas: imprímalas en varias tandas".replace(",", "."))


@router.post("/api/productos/etiquetas")
def etiquetas_pdf(data: EtiquetasIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Etiquetas de los productos en PDF, a la medida de la etiqueta (o en hoja carta): nombre, código de barras y, según el
    formato, el precio con IVA. Tantas de cada producto como copias. Un producto sin código no se imprime: primero se le genera."""
    from fastapi.responses import Response
    if data.hoja not in (None, "", "carta"):
        raise HTTPException(400, "La hoja solo puede ser carta")
    if data.dpi is not None and data.dpi not in ei.DPI_VALIDOS:
        raise HTTPException(400, "La resolución de la impresora debe ser 203, 300 o 600 puntos por pulgada")
    if data.prueba:
        validar_pedido(data.formato, data.ancho_mm, data.alto_mm, [1])
        lista = [{"nombre": "" if data.formato == "solo_codigo" else "Etiqueta de prueba áéíóú ñ", "codigo": ei.codigo_barras_propio(0, "000"),
                  "precio": texto_precio(1500) if data.formato == "nombre_codigo_precio" else "", "copias": 1}]
    else:
        validar_pedido(data.formato, data.ancho_mm, data.alto_mm, [int(i.copias) for i in data.items])
        from .pedidos import precio_final
        lista, sin_codigo = [], []
        for it in data.items:
            p = s.get(Producto, int(it.id))
            if p is None or p.empresa_id != ctx.empresa.id:
                raise HTTPException(404, f"El producto {it.id} no existe")
            codigo = str(p.codigo or "").strip()
            if not codigo:
                sin_codigo.append(p.nombre); continue
            if not _imprimible(codigo):
                raise HTTPException(400, f"El código {codigo} de «{p.nombre}» tiene letras o signos que no caben en un código de barras: cámbielo o genérele uno")
            lista.append({"nombre": "" if data.formato == "solo_codigo" else p.nombre, "codigo": codigo,
                          "precio": texto_precio(precio_final(p), p.moneda) if data.formato == "nombre_codigo_precio" else "", "copias": int(it.copias)})
        if sin_codigo:
            n = len(sin_codigo)
            raise HTTPException(400, (f"«{sin_codigo[0]}» no tiene código" if n == 1 else f"{n} productos no tienen código ({', '.join(sin_codigo[:3])}{'…' if n > 3 else ''})")
                                + ": genere primero el código de barras (Ítems › Generar códigos de barras)")
    try:
        contenido = pdf_etiquetas(lista, data.ancho_mm, data.alto_mm, "carta" if data.hoja == "carta" else None, data.dpi or 203)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    return Response(contenido, media_type="application/pdf", headers={"Content-Disposition": 'inline; filename="etiquetas.pdf"'})
