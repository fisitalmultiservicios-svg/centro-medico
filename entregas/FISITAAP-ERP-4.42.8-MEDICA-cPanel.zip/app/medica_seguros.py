"""Oferta de planes y solicitudes. La póliza se registra en la cobertura del expediente."""
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated

from fastapi import Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, text
from sqlmodel import Field as Col, SQLModel, select

from .db import Producto, por_empresa, sesion_de
from .medica import Base, Central, Nombre, Paciente, Recepcion, _ahora, _buscar, _evento, _sede, router
from .medica_operacion import Cobertura, Gestor, Registro, cifrar
from .medica_portal import _empresa, _paciente, _registro_portal, portal


class PlanSeguro(SQLModel, table=True):
    __tablename__ = "medica_plan_seguro"

    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    aseguradora_id: int
    producto_id: int | None = None
    nombre: str
    descripcion: str
    copago: float = 0
    deducible: float = 0
    max_atenciones: int = 0
    publica: bool = False
    activa: bool = True


class SolicitudSeguro(SQLModel, table=True):
    __tablename__ = "medica_solicitud_seguro"

    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    plan_id: int
    paciente_id: int
    estado: str = "pendiente"
    cobertura_id: int | None = None
    creada: datetime = Col(sa_type=DateTime)


por_empresa(PlanSeguro, SolicitudSeguro)


class PlanIn(BaseModel):
    aseguradora_id: int
    producto_id: int | None = None
    nombre: Nombre
    descripcion: str = Field(default="", max_length=3000)
    copago: Decimal = Field(default=Decimal("0"), ge=0, le=100000000, decimal_places=2)
    deducible: Decimal = Field(default=Decimal("0"), ge=0, le=100000000, decimal_places=2)
    max_atenciones: int = Field(default=0, ge=0, le=10000)
    publica: bool = False
    activa: bool = True


def _planes(s, sede):
    return select(PlanSeguro, Registro.nombre).join(Registro, Registro.id == PlanSeguro.aseguradora_id).where(
        PlanSeguro.sede == sede, Registro.sede == sede)


def _precio(s, plan, eid):
    prod = s.get(Producto, plan.producto_id) if plan.producto_id else None
    return {"precio": prod.precio, "moneda": prod.moneda} if prod and prod.empresa_id == eid and prod.activo else {}


@router.get("/seguros/planes")
def planes_seguros(ctx: Gestor, s: Base):
    return [{**p.model_dump(), "aseguradora": nombre, **_precio(s, p, ctx.empresa.id)}
            for p, nombre in s.exec(_planes(s, _sede(ctx)).order_by(PlanSeguro.nombre).limit(250))]


def _guardar(data, ctx, s, fila=None):
    r = _buscar(s, Registro, data.aseguradora_id, ctx)
    if r.tipo != "aseguradora" or r.estado != "activo":
        raise HTTPException(422, "Seleccione una aseguradora activa")
    if data.producto_id:
        p = s.get(Producto, data.producto_id)
        if not p or p.empresa_id != ctx.empresa.id or not p.activo or not p.es_venta or not p.es_servicio:
            raise HTTPException(422, "Seleccione un servicio activo del catálogo ERP")
    if fila:
        fila.sqlmodel_update(data.model_dump())
    else:
        fila = PlanSeguro(sede=_sede(ctx), **data.model_dump())
        s.add(fila)
    s.flush()
    _evento(s, ctx, "seguro.plan_guardado", fila.id)
    s.commit()
    s.refresh(fila)
    return fila


@router.post("/seguros/planes", status_code=201)
def nuevo_plan(data: PlanIn, ctx: Gestor, s: Base):
    return _guardar(data, ctx, s)


@router.put("/seguros/planes/{pid}")
def editar_plan(pid: int, data: PlanIn, ctx: Gestor, s: Base):
    return _guardar(data, ctx, s, _buscar(s, PlanSeguro, pid, ctx))


@router.get("/seguros/solicitudes")
def solicitudes(ctx: Recepcion, s: Base):
    q = select(SolicitudSeguro, Paciente.nombre, PlanSeguro.nombre).join(
        Paciente, Paciente.id == SolicitudSeguro.paciente_id
    ).join(PlanSeguro, PlanSeguro.id == SolicitudSeguro.plan_id).where(SolicitudSeguro.sede == _sede(ctx))
    return [{**f.model_dump(), "paciente": paciente, "plan": plan}
            for f, paciente, plan in s.exec(q.order_by(SolicitudSeguro.id.desc()).limit(250))]


class ResolucionIn(BaseModel):
    poliza: str = Field(min_length=2, max_length=120)
    vigencia_desde: date
    vigencia_hasta: date
    autorizacion: str = Field(default="", max_length=120)


@router.post("/seguros/solicitudes/{sid}/vincular")
def vincular(sid: int, data: ResolucionIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    solicitud = _buscar(s, SolicitudSeguro, sid, ctx)
    if solicitud.cobertura_id:
        return {"cobertura_id": solicitud.cobertura_id}
    if data.vigencia_hasta < data.vigencia_desde:
        raise HTTPException(422, "Revise las fechas de vigencia")
    plan = _buscar(s, PlanSeguro, solicitud.plan_id, ctx)
    aseguradora = _buscar(s, Registro, plan.aseguradora_id, ctx)
    _buscar(s, Paciente, solicitud.paciente_id, ctx)
    if not plan.activa or aseguradora.estado != "activo":
        raise HTTPException(409, "El plan o la aseguradora está inactiva")
    cobertura = Cobertura(
        sede=solicitud.sede, paciente_id=solicitud.paciente_id, convenio_id=plan.aseguradora_id,
        vigencia_desde=data.vigencia_desde, vigencia_hasta=data.vigencia_hasta, tipo="asegurado",
        datos=cifrar(ctx.empresa, {"poliza": data.poliza, "autorizacion": data.autorizacion,
                                   "plan": plan.nombre, "plan_id": plan.id, "servicios": plan.descripcion}),
        copago=plan.copago, deducible=plan.deducible, max_atenciones=plan.max_atenciones,
    )
    s.add(cobertura)
    s.flush()
    solicitud.cobertura_id, solicitud.estado = cobertura.id, "vinculada"
    _evento(s, ctx, "seguro.poliza_vinculada", solicitud.id)
    identificador = cobertura.id
    s.commit()
    return {"cobertura_id": identificador}


@portal.get("/api/medica/portal/{eid}/seguros")
def catalogo_web(eid: int, sc: Central):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        q = select(PlanSeguro, Registro.nombre).join(Registro, Registro.id == PlanSeguro.aseguradora_id).where(
            PlanSeguro.activa.is_(True), PlanSeguro.publica.is_(True), Registro.estado == "activo",
            PlanSeguro.sede == Registro.sede,
        )
        return [{"id": p.id, "nombre": p.nombre, "descripcion": p.descripcion, "aseguradora": nombre,
                 "copago": p.copago, "deducible": p.deducible, "sede": p.sede, **_precio(s, p, eid)}
                for p, nombre in s.exec(q.order_by(PlanSeguro.nombre).limit(100))]


@portal.post("/api/medica/portal/{eid}/seguros/{plan_id}/solicitar", status_code=201)
def solicitar(eid: int, plan_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        paciente = _paciente(s, eid, x_medica_portal)
        plan = s.get(PlanSeguro, plan_id)
        if not plan or plan.sede != paciente.sede or not plan.publica or not plan.activa:
            raise HTTPException(404, "Plan no disponible para su expediente")
        entidad = s.get(Registro, plan.aseguradora_id)
        if not entidad or entidad.estado != "activo":
            raise HTTPException(409, "Esta aseguradora ya no está disponible")
        actual = s.exec(select(SolicitudSeguro).where(
            SolicitudSeguro.plan_id == plan_id, SolicitudSeguro.paciente_id == paciente.id,
            SolicitudSeguro.estado == "pendiente",
        )).first()
        if actual:
            return {"id": actual.id, "estado": actual.estado}
        fila = SolicitudSeguro(sede=paciente.sede, plan_id=plan_id, paciente_id=paciente.id, creada=_ahora())
        s.add(fila)
        s.flush()
        _registro_portal(s, paciente.id, "portal.seguro_solicitado", fila.id)
        salida = {"id": fila.id, "estado": fila.estado}
        s.commit()
        return salida
