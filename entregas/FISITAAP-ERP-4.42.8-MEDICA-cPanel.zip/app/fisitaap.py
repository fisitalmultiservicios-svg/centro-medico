"""FISITAAP embebido (3.74): lo que las pantallas de FISITAAP necesitan y el ERP no tenía como tal.

FISITAAP vive en /app/fisitaap/ con sus hojas de estilo originales; sus pantallas usan las APIs del ERP (pedidos, entregas,
promociones, inventario…) y, para lo que solo existe en FISITAAP, estas rutas:
- Resumen y KPIs: ventas del día o del período (documentos emitidos) y pedidos web, con gráfica.
- Configurador (recorrido guiado) y su invitación en la bienvenida.
- Contactos: mensajes del formulario de la página pública, con estado nuevo / leído / resuelto.
- Promociones por producto (precio especial o 2 × 1 con vigencia) que aplica el catálogo público.
- Extras y opcionales de FISITAAP sobre los grupos de modificadores del punto de venta (mismo registro pos_modificadores).
Todo se guarda en los registros por empresa (fis_*) o en los que ya existían."""
import re
from collections import defaultdict
from datetime import date, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlmodel import Session, select

from . import entregas as _entregas
from . import inventario, modulos, pedidos, promociones
from .auth import Contexto, limitar_ip, requiere, sesion_empresa, solo_pos
from .config import ahora_cr
from .db import Documento, DocumentoLinea, Producto, sesion_de

router = APIRouter(tags=["fisitaap"])
DIAS = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"]
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
VENTA = ("01", "04")                                  # factura y tiquete: lo que FISITAAP llama «ventas registradas»


def admin(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    return ctx


def gestion(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    """3.87: promociones, extras, opcionales, ajustes y diseño de la página: quien administra ítems y precios ('catalogos', como los
    combos), no el Cajero ni un rol de solo caja. Las lecturas siguen con 'pos' (la caja y Express pendientes las usan)."""
    ctx.exigir("catalogos")
    return ctx


def dueno(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    """3.87: el configurador (recorrido guiado) es del dueño, como ya lo muestra la interfaz."""
    ctx.exigir("configurar")
    return ctx


def sin_cajero(ctx: Contexto = Depends(admin)) -> Contexto:
    """4.5: resumen, KPIs, configurador, contactos, ajustes y diseño: lecturas que fis/app.js ya no abre en modo cajero (solo Pedidos,
    el detalle y Express pendientes) y que la API seguía respondiendo. Un rol de solo caja recibe 403 (inventario._sin_cajero); los
    demás lectores siguen con 'pos'. Promociones, modificadores, combos y Express pendientes quedan como estaban: la operación los usa."""
    inventario._sin_cajero(ctx, "esta parte de Ventas en línea")
    return ctx


def r2(x) -> float:
    return round(float(x or 0) + 1e-9, 2)


def hoy_texto(d=None) -> str:
    d = d or ahora_cr()
    return f"{DIAS[(d.weekday() + 1) % 7]}, {d.day} de {MESES[d.month - 1]}"


# ------------------------------------------------------------------------------------------------- registros fis_*
def _nuevo_id(s: Session, eid: int, clave: str, lista: list) -> int:
    rp = modulos.rango_propio(eid)
    r = modulos._registro(s, eid, clave)
    usados = [int(x.get("id") or 0) for x in lista if isinstance(x, dict)]
    base = max([i for i in usados if modulos.en_rango(i, rp)] + [(r.ultimo_id or 0) if r and modulos.en_rango(r.ultimo_id or 0, rp) else 0, rp * modulos.RANGO])
    return base + 1


def _reemplazar(s: Session, eid: int, clave: str, datos) -> int:
    """Guarda un valor o una lista completa con la versión actual del registro (sin versión, un registro ya escrito pide recargar)."""
    r = modulos._registro(s, eid, clave)
    return modulos.reemplazar(s, eid, clave, datos, (r.version or 0) if r else None)


def _lista(s: Session, eid: int, clave: str) -> list:
    return [x for x in (modulos.leer(s, eid, clave, []) or []) if isinstance(x, dict)]


def _alta(s: Session, eid: int, clave: str, item: dict) -> dict:
    lista = _lista(s, eid, clave)
    item["id"] = _nuevo_id(s, eid, clave, lista)
    _, remap = modulos.aplicar_cambios(s, eid, clave, [item], [], [item["id"]])
    nuevo = remap.get(str(item["id"]), remap.get(item["id"], item["id"]))
    item["id"] = int(nuevo)
    s.commit()
    return item


def _cambio(s: Session, eid: int, clave: str, item: dict) -> dict:
    modulos.aplicar_cambios(s, eid, clave, [item], [], [])
    s.commit()
    return item


def _baja(s: Session, eid: int, clave: str, iid: int) -> None:
    modulos.aplicar_cambios(s, eid, clave, [], [iid], [])
    s.commit()


def _buscar(s: Session, eid: int, clave: str, iid: int) -> dict:
    for x in _lista(s, eid, clave):
        if int(x.get("id") or 0) == int(iid):
            return x
    raise HTTPException(404, "No existe")


# ------------------------------------------------------------------------------------------------- ventas (documentos)
def _ventas(s: Session, eid: int, d1: str, d2: str, sucursal_id: Optional[int] = None) -> list:
    """Documentos de venta (factura y tiquete) emitidos en [d1, d2) que no fueron rechazados por Hacienda."""
    q = select(Documento).where(Documento.empresa_id == eid, Documento.tipo_documento.in_(VENTA), Documento.fecha_emision >= d1, Documento.fecha_emision < d2, Documento.estado != "rechazado")
    if sucursal_id:
        q = q.where(Documento.sucursal_id == sucursal_id)
    return s.exec(q).all()


def _total_crc(d: Documento) -> float:
    return float(d.total or 0) * (float(d.tipo_cambio or 1) if d.moneda and d.moneda != "CRC" else 1.0)


def _serie(docs: list, modo: str, d1: str, dias: int) -> list:
    """Puntos de la gráfica: por hora (hoy) o por día (semana, mes, período)."""
    if modo == "hora":
        por = defaultdict(float)
        for d in docs:
            por[int((d.fecha_emision or "T00")[11:13] or 0)] += _total_crc(d)
        horas = sorted(set([6, 9, 12, 15, 18, 21] + [h for h, v in por.items() if v]))
        return [{"label": f"{h}:00", "total": r2(sum(v for k, v in por.items() if k <= h and (h == horas[0] or k > horas[horas.index(h) - 1])))} for h in horas]
    por = defaultdict(float)
    for d in docs:
        por[(d.fecha_emision or "")[:10]] += _total_crc(d)
    base = date.fromisoformat(d1[:10])
    return [{"label": (base + timedelta(days=i)).strftime("%d/%m"), "total": r2(por.get((base + timedelta(days=i)).isoformat(), 0))} for i in range(dias)]


@router.get("/api/fisitaap/resumen")
def resumen(periodo: str = "today", sucursal_id: Optional[int] = None, ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    """Lo que muestra el Resumen de FISITAAP: ventas de hoy, pedidos activos, ticket promedio, clientes atendidos, la gráfica
    del período (hoy, semana, mes), los pedidos que necesitan atención y los productos por revisar."""
    eid = ctx.empresa.id
    ahora = ahora_cr(); hoy = ahora.date()
    d_hoy = hoy.isoformat()
    docs_hoy = _ventas(s, eid, d_hoy, (hoy + timedelta(days=1)).isoformat(), sucursal_id)
    total = r2(sum(_total_crc(d) for d in docs_hoy)); n = len(docs_hoy)
    activos = [p for p in s.exec(select(pedidos.Pedido).where(pedidos.Pedido.empresa_id == eid, pedidos.Pedido.estado.in_(("pendiente_pago", "nuevo", "confirmado", "en_preparacion", "listo"))).order_by(pedidos.Pedido.id.desc())).all()]
    efectivo = pedidos.estado_efectivo(s, eid, activos)
    pendientes = [pedidos._salida_pedido(p, efectivo.get(p.id)) for p in activos][:3]
    if periodo == "week":
        base = hoy - timedelta(days=6); serie = _serie(_ventas(s, eid, base.isoformat(), (hoy + timedelta(days=1)).isoformat(), sucursal_id), "dia", base.isoformat(), 7)
    elif periodo == "month":
        base = hoy - timedelta(days=29); serie = _serie(_ventas(s, eid, base.isoformat(), (hoy + timedelta(days=1)).isoformat(), sucursal_id), "dia", base.isoformat(), 30)
    else:
        periodo = "today"; serie = _serie(docs_hoy, "hora", d_hoy, 1)
    try:
        existencias = inventario._existencias(s, eid, None, None)
        inventariables = {p.id for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.activo == True, Producto.inventariable == True, Producto.es_servicio == False)).all()}  # noqa: E712
        bajo = sum(1 for x in existencias if x.get("producto_id") in inventariables and float(x.get("cantidad") or 0) <= 0)
    except Exception:   # noqa: BLE001  (sin inventario configurado no hay nada que revisar)
        bajo = 0
    return {"hoy": hoy_texto(ahora), "ventas": {"total": total, "n": n, "ticket": r2(total / n) if n else 0.0},
            "pedidos": {"activos": len(activos), "nuevos": sum(1 for p in activos if p.estado == "nuevo"), "pendientes": pendientes},
            "periodo": periodo, "grafica": serie, "bajo_minimo": bajo, "sucursales": [{"id": x.id, "nombre": x.nombre} for x in _sucursales(s, eid)]}


def _sucursales(s: Session, eid: int) -> list:
    try:
        from . import sucursales as _suc
        return [x for x in _suc.listar(s, eid) if getattr(x, "activa", True)]
    except Exception:   # noqa: BLE001
        return []


@router.get("/api/fisitaap/kpis")
def kpis(desde: Optional[str] = None, hasta: Optional[str] = None, sucursal_id: Optional[int] = None, ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    """KPIs de FISITAAP: ventas registradas por día, pedidos web por día (sus importes aparte), ticket promedio y productos más
    vendidos del período (por defecto, los últimos 30 días)."""
    eid = ctx.empresa.id
    hoy = ahora_cr().date()
    try:
        from datetime import date
        d2 = date.fromisoformat((hasta or hoy.isoformat())[:10]); d1 = date.fromisoformat((desde or (d2 - timedelta(days=29)).isoformat())[:10])
    except ValueError:
        raise HTTPException(400, "Fechas inválidas")
    if d1 > d2:
        raise HTTPException(400, "El inicio debe ser anterior al fin")
    if (d2 - d1).days > 366:
        raise HTTPException(400, "Máximo un año")
    dias = (d2 - d1).days + 1
    docs = _ventas(s, eid, d1.isoformat(), (d2 + timedelta(days=1)).isoformat(), sucursal_id)
    por_dia = defaultdict(lambda: {"total": 0.0, "n": 0})
    for d in docs:
        x = por_dia[(d.fecha_emision or "")[:10]]; x["total"] += _total_crc(d); x["n"] += 1
    ventas = [{"dia": (d1 + timedelta(days=i)).isoformat(), **{k: (r2(v) if k == "total" else v) for k, v in por_dia.get((d1 + timedelta(days=i)).isoformat(), {"total": 0.0, "n": 0}).items()}} for i in range(dias)]
    ped = s.exec(select(pedidos.Pedido).where(pedidos.Pedido.empresa_id == eid, pedidos.Pedido.creado >= d1.isoformat(), pedidos.Pedido.creado < (d2 + timedelta(days=1)).isoformat(), pedidos.Pedido.estado != "cancelado")).all()
    por_dia_p = defaultdict(lambda: {"total": 0.0, "n": 0})
    for p in ped:
        x = por_dia_p[(p.creado or "")[:10]]; x["total"] += float(p.total or 0); x["n"] += 1
    pedidos_web = [{"dia": (d1 + timedelta(days=i)).isoformat(), **{k: (r2(v) if k == "total" else v) for k, v in por_dia_p.get((d1 + timedelta(days=i)).isoformat(), {"total": 0.0, "n": 0}).items()}} for i in range(dias)]
    total = r2(sum(x["total"] for x in ventas)); n = sum(x["n"] for x in ventas)
    # productos más vendidos: líneas de los documentos del período (neto, sin impuestos)
    ids = [d.id for d in docs]
    top = defaultdict(lambda: {"cantidad": 0.0, "monto": 0.0})
    if ids:
        for i in range(0, len(ids), 500):
            for l in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id.in_(ids[i:i + 500]))).all():
                x = top[l.detalle or "—"]; x["cantidad"] += float(l.cantidad or 0); x["monto"] += max(0.0, float(l.cantidad or 0) * float(l.precio_unitario or 0) - float(l.descuento or 0))
    productos = sorted(({"nombre": k, "cantidad": r2(v["cantidad"]), "monto": r2(v["monto"])} for k, v in top.items()), key=lambda x: -x["monto"])[:20]
    return {"desde": d1.isoformat(), "hasta": d2.isoformat(), "ventas": ventas, "pedidos": pedidos_web, "total": total, "n": n, "ticket": r2(total / n) if n else 0.0,
            "pedidos_n": sum(x["n"] for x in pedidos_web), "pedidos_total": r2(sum(x["total"] for x in pedidos_web)), "productos": productos,
            "sucursales": [{"id": x.id, "nombre": x.nombre} for x in _sucursales(s, eid)]}


# ------------------------------------------------------------------------------------------------- configurador
PASOS = [["Datos del negocio", "Nombre, contacto, horario, logo y medios de pago.", "#/configuracion"],
         ["Sucursales y zonas", "Configura dónde vendes y las zonas donde entregas.", "#/delivery"],
         ["Roles y permisos", "Define qué puede hacer cada persona.", "/app/#/configuracion"],
         ["Control de personal", "Registra primero a las personas, sin crear credenciales.", "/app/#/rrhh/empleados"],
         ["Usuarios", "Crea los accesos de empleados existentes y asigna sus perfiles.", "/app/#/configuracion"],
         ["Categorías", "Organiza tus productos para encontrarlos fácilmente.", "/app/#/inventario/items"],
         ["Extras y opcionales", "Crea grupos como Tallas y Colores antes de crear los productos.", "#/opcionales"],
         ["Productos", "Agrega productos o importa el machote de Excel y asigna los grupos.", "#/productos"],
         ["Diseño web", "Personaliza imágenes, textos y colores de tu tienda.", "#/contenido"],
         ["Caja e impresión", "Vincula el equipo instalado y configura su caja.", "/app/#/pos/configuracion"],
         ["Prueba tu tienda", "Abre el catálogo y comprueba precios, opciones y contacto.", "tienda"]]


class ConfiguradorIn(BaseModel):
    accion: str                      # next | back | pause | reset
    paso: Optional[int] = None


def _configurador(s: Session, eid: int) -> dict:
    c = modulos.leer(s, eid, "fis_configurador", None) or {}
    if not isinstance(c, dict):
        c = {}
    c.setdefault("paso", 0); c.setdefault("pausado", False); c.setdefault("completado", None)
    c.setdefault("iniciado", ahora_cr().isoformat(timespec="seconds"))
    return c


def _salida_configurador(c: dict) -> dict:
    iniciado = c.get("iniciado") or ""
    invitar = (not c.get("pausado")) and not c.get("completado") and iniciado[:10] >= (ahora_cr() - timedelta(days=3)).date().isoformat()
    return {"paso": int(c.get("paso") or 0), "pausado": bool(c.get("pausado")), "completado": c.get("completado"), "invitar": invitar, "pasos": PASOS, "total": len(PASOS)}


@router.get("/api/fisitaap/configurador")
def configurador(ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5: el GET también escribe el registro fis_configurador
    c = _configurador(s, ctx.empresa.id)
    _reemplazar(s, ctx.empresa.id, "fis_configurador", c); s.commit()
    return _salida_configurador(c)


@router.put("/api/fisitaap/configurador")
def configurador_cambiar(body: ConfiguradorIn, ctx: Contexto = Depends(dueno), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; c = _configurador(s, eid); paso = int(c.get("paso") or 0)
    if body.accion == "pause":
        c["pausado"] = True
    elif body.accion == "next":
        if body.paso is not None and int(body.paso) != paso:
            raise HTTPException(409, "El configurador cambió en otra pestaña; recargue")
        paso = min(len(PASOS), paso + 1); c.update({"paso": paso, "pausado": False, "completado": ahora_cr().isoformat(timespec="seconds") if paso == len(PASOS) else None})
    elif body.accion == "back":
        c.update({"paso": max(0, paso - 1), "pausado": False, "completado": None})
    elif body.accion == "reset":
        c.update({"paso": 0, "pausado": False, "completado": None, "iniciado": ahora_cr().isoformat(timespec="seconds")})
    else:
        raise HTTPException(400, "Acción desconocida")
    _reemplazar(s, eid, "fis_configurador", c); s.commit()
    return _salida_configurador(c)


# ------------------------------------------------------------------------------------------------- contactos de la página
ESTADOS_CONTACTO = {"new": "Nuevo", "read": "Leído", "resolved": "Resuelto"}
CORREO_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ContactoIn(BaseModel):
    nombre: str
    correo: str = ""
    telefono: str = ""
    asunto: str = ""
    mensaje: str


class EstadoContactoIn(BaseModel):
    estado: str


@router.post("/api/publico/{slug}/contacto")
def contacto_publico(slug: str, body: ContactoIn, request: Request):
    """Formulario «Contáctanos» de la página del negocio: queda en FISITAAP › Contactos."""
    limitar_ip(request, "contacto_web", 5, 3600)
    e, eid = pedidos._publico(slug)
    nombre = body.nombre.strip()[:120]; mensaje = body.mensaje.strip()[:4000]; correo = body.correo.strip()[:120]
    if len(nombre) < 2 or len(mensaje) < 5:
        raise HTTPException(400, "Escriba su nombre y el mensaje")
    if correo and not CORREO_RE.match(correo):
        raise HTTPException(400, "Revise el correo")
    with sesion_de(eid) as s:
        n = pedidos._negocio(s, eid)
        if not n.activo or n.slug != slug:
            raise HTTPException(404, "Este negocio no está publicado")
        item = {"nombre": nombre, "correo": correo, "telefono": re.sub(r"\D", "", body.telefono)[:12], "asunto": (body.asunto.strip() or "Consulta desde la página")[:150],
                "mensaje": mensaje, "estado": "new", "creado": ahora_cr().isoformat(timespec="seconds")}
        _alta(s, eid, "fis_contactos", item)
    return {"ok": True}


@router.get("/api/fisitaap/contactos")
def contactos(q: str = "", estado: str = "", ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    lista = _lista(s, ctx.empresa.id, "fis_contactos")
    q = (q or "").strip().lower()[:100]
    out = [x for x in lista if (not estado or x.get("estado") == estado) and (not q or any(q in str(x.get(k) or "").lower() for k in ("nombre", "correo", "asunto", "mensaje")))]
    out.sort(key=lambda x: (x.get("creado") or "", x.get("id") or 0), reverse=True)
    return {"lista": out[:200], "estados": ESTADOS_CONTACTO, "nuevos": sum(1 for x in lista if x.get("estado") == "new")}


@router.put("/api/fisitaap/contactos/{cid}")
def contacto_estado(cid: int, body: EstadoContactoIn, ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    if body.estado not in ESTADOS_CONTACTO:
        raise HTTPException(400, "Estado no disponible")
    x = _buscar(s, ctx.empresa.id, "fis_contactos", cid)
    x["estado"] = body.estado
    return _cambio(s, ctx.empresa.id, "fis_contactos", x)


# ------------------------------------------------------------------------------------------------- promociones por producto
class PromocionIn(BaseModel):
    producto_id: int
    tipo: str = "special"            # special (precio especial) | bogo (2 × 1)
    valor: float = 0
    desde: str = ""                  # AAAA-MM-DDTHH:MM o vacío
    hasta: str = ""


def _fecha_ok(v: str) -> str:
    v = (v or "").strip()
    if not v:
        return ""
    if not re.match(r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?$", v):
        raise HTTPException(400, "Fecha inválida")
    return v if "T" in v else v + "T00:00"


def promociones_vigentes(s: Session, eid: int, ahora: Optional[str] = None) -> dict:
    """{producto_id: promoción activa y vigente} para el catálogo público y la caja."""
    ahora = ahora or ahora_cr().isoformat(timespec="minutes")
    out = {}
    for p in sorted(_lista(s, eid, "fis_promociones"), key=lambda x: -int(x.get("id") or 0)):
        if not p.get("activa", True):
            continue
        if (p.get("desde") and p["desde"] > ahora) or (p.get("hasta") and p["hasta"] < ahora):
            continue
        out.setdefault(int(p.get("producto_id") or 0), p)
    return out


def precio_con_promocion(precio: float, cantidad: float, promo: Optional[dict]) -> tuple[float, str]:
    """(precio unitario efectivo, etiqueta). 2 × 1: cada dos unidades pagan una; precio especial: sustituye el precio."""
    if not promo:
        return float(precio), ""
    if promo.get("tipo") == "bogo":
        c = max(1.0, float(cantidad or 1)); pagadas = c - int(c // 2)
        return r2(float(precio) * pagadas / c), "2 × 1"
    v = float(promo.get("valor") or 0)
    return (r2(v), "Precio especial") if v > 0 else (float(precio), "")


@router.get("/api/fisitaap/promociones")
def listar_promociones(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    nombres = {p.id: p.nombre for p in s.exec(select(Producto).where(Producto.empresa_id == eid)).all()}
    lista = [x for x in _lista(s, eid, "fis_promociones") if x.get("activa", True)]
    for x in lista:
        x["producto"] = nombres.get(int(x.get("producto_id") or 0), "(ítem eliminado)")
    lista.sort(key=lambda x: -int(x.get("id") or 0))
    return lista


@router.post("/api/fisitaap/promociones")
def crear_promocion(body: PromocionIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    p = s.get(Producto, body.producto_id)
    if not p or p.empresa_id != eid:
        raise HTTPException(400, "Producto no disponible")
    tipo = "bogo" if body.tipo == "bogo" else "special"
    if tipo == "special" and body.valor <= 0:
        raise HTTPException(400, "Escriba el precio especial")
    desde, hasta = _fecha_ok(body.desde), _fecha_ok(body.hasta)
    if desde and hasta and desde > hasta:
        raise HTTPException(400, "El final debe ser posterior al inicio")
    for x in _lista(s, eid, "fis_promociones"):          # una promoción activa por producto (como FISITAAP)
        if int(x.get("producto_id") or 0) == p.id and x.get("activa", True):
            x["activa"] = False; modulos.aplicar_cambios(s, eid, "fis_promociones", [x], [], [])
    item = {"producto_id": p.id, "tipo": tipo, "valor": r2(body.valor) if tipo == "special" else 0, "desde": desde, "hasta": hasta, "activa": True,
            "creada": ahora_cr().isoformat(timespec="seconds"), "usuario": ctx.usuario.correo}
    item = _alta(s, eid, "fis_promociones", item)
    item["producto"] = p.nombre
    return item


@router.delete("/api/fisitaap/promociones/{pid}")
def desactivar_promocion(pid: int, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    x = _buscar(s, ctx.empresa.id, "fis_promociones", pid)
    x["activa"] = False
    _cambio(s, ctx.empresa.id, "fis_promociones", x)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- extras y opcionales
# Los extras (un elemento con precio) y los grupos de opcionales (Tallas: S, M, L) de FISITAAP son grupos de modificadores del punto de
# venta (registro pos_modificadores): la caja y el catálogo ya los entienden. FISITAAP agrega el tipo, la asignación a productos y a
# categorías completas; `promociones.grupos_de_producto` las honra.
class ExtraIn(BaseModel):
    nombre: str
    precio: float = 0
    obligatorio: bool = False
    productos: list[int] = []
    categorias: list[str] = []


class OpcionalIn(BaseModel):
    nombre: str
    opciones: list[dict] = []        # [{id?, nombre}]
    obligatorio: bool = False
    multiple: bool = False
    productos: list[int] = []
    categorias: list[str] = []


def _grupos(s: Session, eid: int) -> list:
    return [g for g in (modulos.leer(s, eid, "pos_modificadores", []) or []) if isinstance(g, dict) and g.get("id") is not None]


def _guardar_grupos(s: Session, eid: int, grupos: list) -> None:
    _reemplazar(s, eid, "pos_modificadores", grupos); s.commit()


def _nuevo_id_grupo(grupos: list, usados_ops: Optional[set] = None) -> int:
    ids = [int(g.get("id") or 0) for g in grupos] + [int(o.get("id") or 0) for g in grupos for o in (g.get("opciones") or []) if isinstance(o, dict)] + list(usados_ops or [])
    return max(ids + [0]) + 1


def _asignacion(s: Session, eid: int, g: dict) -> dict:
    return {"productos": [int(x) for x in (g.get("productos") or [])], "categorias": [str(x) for x in (g.get("categorias") or [])]}


def _salida_grupo(g: dict) -> dict:
    ops = [o for o in (g.get("opciones") or []) if isinstance(o, dict)]
    return {"id": g["id"], "nombre": g.get("nombre") or "", "tipo": g.get("tipo") or ("extra" if len(ops) == 1 and g.get("maximo", 1) == 1 and g.get("fis") else "opcional"),
            "precio": float((ops[0].get("precio") if ops else 0) or 0), "obligatorio": int(g.get("minimo") or 0) > 0, "multiple": int(g.get("maximo") or 1) != 1,
            "opciones": [{"id": o.get("id"), "nombre": o.get("nombre") or "", "precio": float(o.get("precio") or 0)} for o in ops],
            "productos": [int(x) for x in (g.get("productos") or [])], "categorias": [str(x) for x in (g.get("categorias") or [])], "activo": g.get("activo", True) is not False}


@router.get("/api/fisitaap/modificadores")
def listar_modificadores(tipo: str = "", ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Extras y opcionales de FISITAAP (y los grupos creados desde la caja, como opcionales) con los productos y categorías del negocio."""
    eid = ctx.empresa.id
    grupos = [_salida_grupo(g) for g in _grupos(s, eid) if g.get("activo", True) is not False]
    if tipo:
        grupos = [g for g in grupos if g["tipo"] == tipo]
    prods = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.activo == True, Producto.es_venta == True).order_by(Producto.nombre)).all()  # noqa: E712
    cats = sorted({(p.categoria or "").strip() for p in prods if (p.categoria or "").strip()})
    return {"grupos": sorted(grupos, key=lambda g: g["nombre"].lower()), "productos": [{"id": p.id, "nombre": p.nombre, "codigo": p.codigo or "", "categoria": p.categoria or ""} for p in prods], "categorias": cats}


def _validar_asignacion(s: Session, eid: int, productos: list, categorias: list) -> tuple[list, list]:
    ids = sorted({int(x) for x in productos if x})
    if ids:
        validos = {p.id for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.id.in_(ids))).all()}
        if validos != set(ids):
            raise HTTPException(400, "Producto no disponible")
    return ids, sorted({str(c).strip() for c in categorias if str(c).strip()})


@router.post("/api/fisitaap/extras")
def crear_extra(body: ExtraIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    return _guardar_extra(None, body, ctx, s)


@router.put("/api/fisitaap/extras/{gid}")
def cambiar_extra(gid: int, body: ExtraIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    return _guardar_extra(gid, body, ctx, s)


def _guardar_extra(gid: Optional[int], body: ExtraIn, ctx: Contexto, s: Session) -> dict:
    eid = ctx.empresa.id; nombre = body.nombre.strip()[:120]
    if not nombre:
        raise HTTPException(400, "Escribe el nombre.")
    productos, categorias = _validar_asignacion(s, eid, body.productos, body.categorias)
    grupos = _grupos(s, eid)
    g = next((x for x in grupos if gid is not None and int(x["id"]) == int(gid)), None)
    if gid is not None and not g:
        raise HTTPException(404, "Elemento no disponible.")
    if g is None:
        g = {"id": _nuevo_id_grupo(grupos), "opciones": [], "activo": True}; grupos.append(g)
    op = (g.get("opciones") or [{}])[0] if g.get("opciones") else {}
    if not op.get("id"):
        op = {"id": _nuevo_id_grupo(grupos)}
    op.update({"nombre": nombre, "precio": r2(body.precio)})
    g.update({"nombre": nombre, "tipo": "extra", "fis": True, "minimo": 1 if body.obligatorio else 0, "maximo": 1, "opciones": [op], "productos": productos, "categorias": categorias, "activo": True})
    _guardar_grupos(s, eid, grupos)
    return _salida_grupo(g)


@router.post("/api/fisitaap/opcionales")
def crear_opcional(body: OpcionalIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    return _guardar_opcional(None, body, ctx, s)


@router.put("/api/fisitaap/opcionales/{gid}")
def cambiar_opcional(gid: int, body: OpcionalIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    return _guardar_opcional(gid, body, ctx, s)


def _guardar_opcional(gid: Optional[int], body: OpcionalIn, ctx: Contexto, s: Session) -> dict:
    eid = ctx.empresa.id; nombre = body.nombre.strip()[:120]
    if not nombre:
        raise HTTPException(400, "Escribe un nombre de grupo de hasta 120 caracteres, por ejemplo Tallas o Colores.")
    if len(body.opciones) > 50:
        raise HTTPException(400, "El grupo permite hasta 50 opciones.")
    productos, categorias = _validar_asignacion(s, eid, body.productos, body.categorias)
    grupos = _grupos(s, eid)
    g = next((x for x in grupos if gid is not None and int(x["id"]) == int(gid)), None)
    if gid is not None and not g:
        raise HTTPException(404, "Grupo no disponible para este negocio.")
    if g is None:
        if any((x.get("nombre") or "").strip().lower() == nombre.lower() and x.get("activo", True) is not False and x.get("tipo") != "extra" for x in grupos):
            raise HTTPException(400, "Ya existe ese grupo. Usa Editar para agregar sus opciones.")
        g = {"id": _nuevo_id_grupo(grupos), "opciones": [], "activo": True}; grupos.append(g)
    conocidas = {int(o.get("id")): o for o in (g.get("opciones") or []) if isinstance(o, dict) and o.get("id") is not None}
    vistos, ops = set(), []
    for l in body.opciones:
        n = str(l.get("nombre") or "").strip()[:120]
        if not n:
            continue
        if n.lower() in vistos:
            raise HTTPException(400, "No repitas opciones dentro del mismo grupo.")
        vistos.add(n.lower())
        oid = int(l.get("id") or 0)
        if oid and oid not in conocidas:
            raise HTTPException(400, "Una opción no pertenece a este grupo.")
        o = conocidas[oid] if oid else {"id": _nuevo_id_grupo(grupos, {x["id"] for x in ops if x.get("id")})}
        o.update({"nombre": n, "precio": float(l.get("precio") or 0)})
        ops.append(o)
    if not ops:
        raise HTTPException(400, "Agrega al menos una opción al grupo.")
    g.update({"nombre": nombre, "tipo": "opcional", "fis": True, "minimo": 1 if body.obligatorio else 0, "maximo": len(ops) if body.multiple else 1, "opciones": ops, "productos": productos, "categorias": categorias, "activo": True})
    _guardar_grupos(s, eid, grupos)
    return _salida_grupo(g)


@router.delete("/api/fisitaap/modificadores/{gid}")
def desactivar_modificador(gid: int, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; grupos = _grupos(s, eid)
    g = next((x for x in grupos if int(x["id"]) == int(gid)), None)
    if not g:
        raise HTTPException(404, "Elemento no disponible.")
    g["activo"] = False
    _guardar_grupos(s, eid, grupos)
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- Express pendientes e invitaciones
class InvitacionIn(BaseModel):
    telefono: str
    nombre: str = ""


@router.get("/api/fisitaap/express/pendientes")
def express_pendientes(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Entregas sin motorizado (pendientes o liberadas) con los datos del pedido, como «Express pendientes» de FISITAAP."""
    eid = ctx.empresa.id
    ent = s.exec(select(_entregas.Entrega).where(_entregas.Entrega.empresa_id == eid, _entregas.Entrega.estado.in_(("pendiente", "liberada"))).order_by(_entregas.Entrega.id.desc())).all()
    motos = [m for m in s.exec(select(_entregas.Motorizado).where(_entregas.Motorizado.empresa_id == eid, _entregas.Motorizado.activo == True)).all()]  # noqa: E712
    return {"entregas": [{"id": x.id, "pedido_id": x.pedido_id, "pedido_numero": x.pedido_numero, "estado": x.estado, "estado_nombre": _entregas.NOMBRES_ESTADO.get(x.estado, x.estado), "cliente": x.nombre_cliente,
                          "telefono": x.telefono_cliente, "direccion": x.direccion, "zona": x.zona_nombre, "monto_envio": x.monto_envio, "pago_motorizado": x.pago_motorizado, "creada": x.creada} for x in ent],
            "motorizados": [{"id": m.id, "nombre": m.nombre, "telefono": m.telefono, "vehiculo": m.vehiculo} for m in motos]}


# ------------------------------------------------------------------------------------------------- combos (producto Combo + receta del ERP)
# Un combo de FISITAAP es un ítem del ERP de tipo «Combo» con su ficha técnica (registro recetas): al venderlo se rebajan los
# componentes, como ya hace el ERP con cualquier receta.
class ComboIn(BaseModel):
    id: Optional[int] = None
    nombre: str
    precio: float = 0
    tarifa: float = 13
    descripcion: str = ""
    componentes: list[dict] = []     # [{producto_id, cantidad}]


def _recetas(s: Session, eid: int) -> list:
    return [r for r in (modulos.leer(s, eid, "recetas", []) or []) if isinstance(r, dict)]


@router.get("/api/fisitaap/combos")
def listar_combos(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    prods = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.activo == True).order_by(Producto.nombre)).all()  # noqa: E712
    recs = {int(r.get("producto_id") or 0): r for r in _recetas(s, eid)}
    simples = [{"id": p.id, "nombre": p.nombre, "costo": float(p.costo or 0)} for p in prods if p.tipo != "Combo" and p.es_venta and not p.es_servicio]
    if solo_pos(ctx.permisos):          # 3.87: la caja no recibe el costo de los ítems (como en /api/productos); armar combos es de 'catalogos'
        simples = [{k: v for k, v in x.items() if k != "costo"} for x in simples]
    combos = []
    for p in prods:
        if p.tipo != "Combo":
            continue
        r = recs.get(p.id) or {}
        combos.append({"id": p.id, "nombre": p.nombre, "precio": float(p.precio or 0), "tarifa": float(p.tarifa or 0), "descripcion": p.descripcion or "", "visible": bool(p.visible_catalogo),
                       "componentes": [{"producto_id": int(i.get("producto_id") or 0), "cantidad": float(i.get("cantidad") or 0)} for i in (r.get("ingredientes") or []) if isinstance(i, dict)]})
    return {"combos": combos, "productos": simples}


@router.post("/api/fisitaap/combos")
def guardar_combo(body: ComboIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; nombre = body.nombre.strip()[:190]
    if not nombre:
        raise HTTPException(400, "Escribe un nombre.")
    if body.precio < 0 or not (0 <= body.tarifa <= 100):
        raise HTTPException(400, "Revisa el precio y el impuesto.")
    comp = {}
    for l in body.componentes:
        pid = int(l.get("producto_id") or 0); q = float(l.get("cantidad") or 0)
        if pid and q > 0:
            comp[pid] = round(comp.get(pid, 0) + q, 3)
    if not comp:
        raise HTTPException(400, "Selecciona los productos del combo.")
    partes = {p.id: p for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.id.in_(list(comp)))).all()}
    if len(partes) != len(comp) or any(p.tipo == "Combo" or p.es_servicio for p in partes.values()):
        raise HTTPException(400, "Los componentes deben ser productos simples de este negocio.")
    costo = round(sum(float(partes[pid].costo or 0) * q for pid, q in comp.items()), 4)
    primero = partes[next(iter(comp))]
    if body.id:
        p = s.get(Producto, body.id)
        if not p or p.empresa_id != eid or p.tipo != "Combo":
            raise HTTPException(404, "Combo no disponible.")
    else:
        p = Producto(empresa_id=eid, nombre=nombre, cabys=primero.cabys, precio=0, moneda=primero.moneda or "CRC", unidad_medida="Unid", es_servicio=False, codigo_tarifa="08", tarifa=13,
                     tipo="Combo", categoria="Combos", inventariable=False, es_venta=True, visible_catalogo=True)
    p.nombre = nombre; p.precio = r2(body.precio); p.tarifa = float(body.tarifa); p.codigo_tarifa = "08" if body.tarifa == 13 else ("01" if body.tarifa == 0 else p.codigo_tarifa)
    p.descripcion = body.descripcion.strip()[:500] or None; p.costo = costo; p.categoria = p.categoria or "Combos"; p.activo = True; p.visible_catalogo = True
    s.add(p); s.flush()
    receta = {"id": p.id, "producto_id": p.id, "nombre": nombre, "categoria": p.categoria, "vender": True, "precio": p.precio, "cabys": p.cabys, "codigo_tarifa": p.codigo_tarifa,
              "ingredientes": [{"producto_id": pid, "cantidad": q, "unidad": "unid"} for pid, q in comp.items()], "rendimiento": 1, "notas": "Combo de FISITAAP"}
    existe = any(int(r.get("producto_id") or 0) == p.id for r in _recetas(s, eid))
    modulos.aplicar_cambios(s, eid, "recetas", [receta], [], [] if existe else [p.id])
    s.commit(); s.refresh(p)
    return {"id": p.id, "nombre": p.nombre, "precio": float(p.precio), "tarifa": float(p.tarifa), "descripcion": p.descripcion or "", "visible": True, "componentes": [{"producto_id": pid, "cantidad": q} for pid, q in comp.items()], "costo": costo}


@router.delete("/api/fisitaap/combos/{pid}")
def ocultar_combo(pid: int, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = s.get(Producto, pid)
    if not p or p.empresa_id != ctx.empresa.id or p.tipo != "Combo":
        raise HTTPException(404, "Combo no disponible.")
    p.visible_catalogo = False; p.activo = False
    s.add(p); s.commit()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- extras y opcionales de un producto
class AsignacionIn(BaseModel):
    grupos: list[int] = []


@router.get("/api/fisitaap/productos/{pid}/modificadores")
def modificadores_producto(pid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    p = s.get(Producto, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Registro no disponible.")
    ex = (modulos.leer(s, eid, "items_extra", {}) or {}).get(str(pid)) or {}
    manuales = [int(g) for g in (ex.get("modificadores") or [])]
    grupos = [_salida_grupo(g) for g in _grupos(s, eid) if g.get("activo", True) is not False]
    for g in grupos:
        g["manual"] = g["id"] in manuales
        g["heredado"] = bool(p.categoria and p.categoria in g["categorias"]) or pid in g["productos"]
    return {"producto": {"id": p.id, "nombre": p.nombre, "categoria": p.categoria or ""}, "grupos": grupos}


@router.put("/api/fisitaap/productos/{pid}/modificadores")
def asignar_modificadores(pid: int, body: AsignacionIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    p = s.get(Producto, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Registro no disponible.")
    validos = {int(g["id"]) for g in _grupos(s, eid) if g.get("activo", True) is not False}
    ids = sorted({int(x) for x in body.grupos if int(x) in validos})
    if len(ids) != len({int(x) for x in body.grupos}):
        raise HTTPException(400, "Extra no disponible para este negocio.")
    extra = modulos.leer(s, eid, "items_extra", {}) or {}
    if not isinstance(extra, dict):
        extra = {}
    ex = dict(extra.get(str(pid)) or {}); ex["modificadores"] = ids; extra[str(pid)] = ex
    _reemplazar(s, eid, "items_extra", extra); s.commit()
    return {"ok": True, "grupos": ids}


# ------------------------------------------------------------------------------------------------- ajustes y diseño de FISITAAP
# Lo que la página pública y Generales de FISITAAP guardan además del negocio (NegocioPublico): métodos de pago anunciados, texto
# del horario, mapa incrustado, mensaje al suspender, y el diseño de la página (portada, Nosotros, servicios, slider del catálogo,
# contacto, colores y botones). Un solo registro por empresa.
DISENO_CAMPOS = ["hero_title", "hero_text", "about_label", "about_title", "about_text", "about_promise_1", "about_promise_2", "about_promise_3", "about_button_label",
                 "services_title", "service_1_title", "service_1_text", "service_2_title", "service_2_text", "service_3_title", "service_3_text", "contact_title", "contact_text",
                 "catalog_intro_title", "catalog_intro_text", "catalog_intro_title_2", "catalog_intro_text_2", "catalog_intro_title_3", "catalog_intro_text_3", "hero_button_label", "catalog_button_label"]
DISENO_IMAGENES = ["hero_image", "about_image", "service_1_image", "service_2_image", "service_3_image", "catalog_intro_image", "catalog_intro_image_2", "catalog_intro_image_3"]
DISENO_DEFECTO = {"about_label": "NOSOTROS", "about_promise_1": "Atención personal", "about_promise_2": "Variedad", "about_promise_3": "Compromiso", "about_button_label": "Explorar catálogo",
                  "hero_title": "Lo que necesitas, más cerca de ti.", "hero_text": "Productos y atención cercana para tu día a día.", "about_title": "Un negocio cercano. Una atención que se nota.",
                  "services_title": "Productos y servicios", "contact_title": "Conversemos. Será un gusto atenderte.", "service_1_title": "Nuestros productos", "service_1_text": "Conoce nuestro catálogo.",
                  "service_2_title": "Atención personalizada", "service_2_text": "Consulta y encuentra lo que necesitas.", "service_3_title": "Pedidos y entregas", "service_3_text": "Revisa las opciones del negocio.",
                  "catalog_intro_text": "Elige una categoría y agrega tus productos.", "hero_button_label": "Ver catálogo o menú", "catalog_button_label": "Ver catálogo completo →",
                  "catalog_intro_mode": "custom", "catalog_slide_seconds": 5, "catalog_text_color": "#ffffff", "accent_color": "#dfe9c8"}
METODOS_PAGO = ["SINPE Móvil", "Efectivo", "Tarjeta al recibir", "Transferencia"]
MAPA_RE = re.compile(r"src=[\"']https://(?:www\.)?google\.com/maps/embed(?:[/?])[^\"']*[\"']", re.I)


def leer_diseno(s: Session, eid: int) -> dict:
    d = modulos.leer(s, eid, "fis_diseno", None) or {}
    if not isinstance(d, dict):
        d = {}
    out = {**DISENO_DEFECTO, **{k: v for k, v in d.items() if v is not None}}
    for k in DISENO_IMAGENES:
        out.setdefault(k, "")
    return out


def leer_ajustes(s: Session, eid: int) -> dict:
    a = modulos.leer(s, eid, "fis_ajustes", None) or {}
    if not isinstance(a, dict):
        a = {}
    return {"metodos_pago": [m for m in (a.get("metodos_pago") or METODOS_PAGO) if m in METODOS_PAGO] or METODOS_PAGO, "horario_texto": a.get("horario_texto") or "", "mapa_embed": a.get("mapa_embed") or "",
            "mensaje_suspendido": a.get("mensaje_suspendido") or "", "correo_contacto": a.get("correo_contacto") or "", "cedula_requerida": bool(a.get("cedula_requerida")), "tiktok": a.get("tiktok") or "",
            "precios_con_iva": a.get("precios_con_iva", True) is not False, "pedidos_aceptacion": a.get("pedidos_aceptacion", True) is not False}


class AjustesIn(BaseModel):
    metodos_pago: list[str] = METODOS_PAGO
    horario_texto: str = ""
    mapa_embed: str = ""
    mensaje_suspendido: str = ""
    correo_contacto: str = ""
    cedula_requerida: bool = False
    tiktok: str = ""
    precios_con_iva: bool = True
    pedidos_aceptacion: bool = True


@router.get("/api/fisitaap/ajustes")
def ajustes(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):   # 4.5: se deja como estaba (lo mismo sale en la página pública: no es sensible)
    return leer_ajustes(s, ctx.empresa.id)


@router.put("/api/fisitaap/ajustes")
def guardar_ajustes(body: AjustesIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    metodos = [m for m in body.metodos_pago if m in METODOS_PAGO]
    if not metodos:
        raise HTTPException(400, "Selecciona al menos un método de pago y una forma de entrega.")
    correo = body.correo_contacto.strip()[:190]
    if correo and not CORREO_RE.match(correo):
        raise HTTPException(400, "Escribe un correo de contacto válido.")
    mapa = body.mapa_embed.strip()[:5000]
    if mapa and not MAPA_RE.search(mapa):
        raise HTTPException(400, "En Google Maps usa Compartir → Insertar un mapa → Copiar HTML y pega ese código.")
    tiktok = body.tiktok.strip()[:1000]
    if tiktok and not re.match(r"^https?://", tiktok, re.I):
        raise HTTPException(400, "Usa un enlace http o https válido en redes sociales.")
    a = {"metodos_pago": metodos, "horario_texto": body.horario_texto.strip()[:1000], "mapa_embed": mapa, "mensaje_suspendido": body.mensaje_suspendido.strip()[:1000], "correo_contacto": correo,
         "cedula_requerida": bool(body.cedula_requerida), "tiktok": tiktok, "precios_con_iva": bool(body.precios_con_iva), "pedidos_aceptacion": bool(body.pedidos_aceptacion)}
    _reemplazar(s, ctx.empresa.id, "fis_ajustes", a); s.commit()
    return leer_ajustes(s, ctx.empresa.id)


class DisenoIn(BaseModel):
    campos: dict = {}


@router.get("/api/fisitaap/diseno")
def diseno(ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    return leer_diseno(s, ctx.empresa.id)


@router.put("/api/fisitaap/diseno")
def guardar_diseno(body: DisenoIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    d = modulos.leer(s, eid, "fis_diseno", None) or {}
    if not isinstance(d, dict):
        d = {}
    c = body.campos or {}
    for k in DISENO_CAMPOS:
        if k in c:
            tope = 80 if (k.endswith("label") or k.startswith("about_promise_")) else 3000
            d[k] = str(c[k] or "").strip()[:tope]
    for k in DISENO_IMAGENES:
        if k in c:
            d[k] = str(c[k] or "").strip()[:200]      # nombre de archivo de la galería del negocio (o vacío)
    if "catalog_intro_mode" in c:
        if c["catalog_intro_mode"] not in ("auto", "custom", "hidden"):
            raise HTTPException(400, "Selecciona cómo mostrar la portada del catálogo.")
        d["catalog_intro_mode"] = c["catalog_intro_mode"]
    if "catalog_slide_seconds" in c:
        try:
            seg = int(c["catalog_slide_seconds"])
        except (TypeError, ValueError):
            seg = 0
        if not 2 <= seg <= 60:
            raise HTTPException(400, "El tiempo entre imágenes debe estar entre 2 y 60 segundos.")
        d["catalog_slide_seconds"] = seg
    for k in ("catalog_text_color", "accent_color"):
        if k in c:
            if not re.match(r"^#[0-9a-fA-F]{6}$", str(c[k] or "")):
                raise HTTPException(400, "Selecciona colores válidos.")
            d[k] = str(c[k])
    _reemplazar(s, eid, "fis_diseno", d); s.commit()
    return leer_diseno(s, eid)
