"""Avisos por correo al dueño (3.87).

1. Rechazo de Hacienda: cuando un comprobante de PRODUCCIÓN pasa a «rechazado» o «error» (al consultarlo o al enviarlo), se
   avisa al correo de la empresa y a los usuarios que facturan o configuran: consecutivo, cliente, monto y el motivo de Hacienda
   en palabras simples, con un botón para abrir el comprobante. Sale por el correo de la plataforma (llega aunque la empresa no
   tenga correo saliente propio) o, sin él, por el de la empresa. Lo manda solo la nube: la instalación local no avisa, y lo que
   ella sube ya rechazado se avisa al recibirlo (tras_subida). Se llama DESPUÉS del commit del estado: si el correo falla, el
   comprobante queda igual y el fallo queda en la auditoría. No se avisa en pruebas (sandbox), en la empresa demo, con el
   interruptor apagado (Configuración › Facturación electrónica) ni cuando el usuario anula a propósito (la anulación no pasa
   por aquí y su mensaje «Anulado por el usuario» se descarta).
   Una ráfaga de rechazos (un dato mal configurado repite el rechazo en todas las ventas del día) no llena el buzón: a lo sumo
   un correo cada ESPERA_MIN minutos por empresa; lo que llega mientras tanto queda «pendiente» y la siguiente pasada de la cola
   lo manda junto, en un solo correo.
2. Atascados: una vez al día, la pasada de la cola avisa los comprobantes que siguen «firmado» o «enviado» más de 24 horas
   (cada comprobante una sola vez).
3. Cierre de caja (reporte Z) por correo a «Enviar el cierre a» de la caja (POST /api/pos/cierres/correo). El destinatario lo
   fija la configuración de la caja (solo quien configura la cambia), nunca la petición. Sale SOLO por el correo saliente de la
   empresa, como el cierre del hotel: el texto y el PDF los arma el navegador y el destinatario lo elige la empresa, así que
   nunca va por el correo de la plataforma (sería un relevo de correo con su nombre para cualquier cuenta de prueba).

La marca de cada comprobante va en Documento.aviso_enviado: «rechazado:<fecha>», «error:<fecha>», «atascado:<fecha>»,
«pendiente:<estado>:<fecha>» (lo junta la cola) u «omitido:<estado>:<fecha>» (pendiente que ya no corresponde mandar).
"""
import logging
import os
import re
import threading
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import and_, or_, text
from sqlmodel import Session, select

from . import correo, correo_diseno as _dz, modulos, reportes
from .auth import Contexto, auditar, limitar_ip, requiere, sesion_empresa
from .config import URL_PUBLICA, ahora_cr
from .db import Documento, Empresa, engine, engine_empresa, get_session
from .fe import pdf as _pdf

log = logging.getLogger(__name__)
router = APIRouter(tags=["avisos al dueño"])
ESTADOS_AVISO = ("rechazado", "error")
ESPERA_MIN = 10                  # minutos entre dos avisos de rechazo de una misma empresa (lo que llega mientras tanto se junta)
REINTENTO_MIN = 30               # tras un correo fallido no se reintenta antes (un servidor de correo caído no frena la cola)
VENTANA_DIAS = 30                # comprobantes que se revisan como atascados
NOMBRE_TIPO = {"01": "Factura electrónica", "02": "Nota de débito", "03": "Nota de crédito", "04": "Tiquete electrónico",
               "08": "Factura de compra", "09": "Factura de exportación", "10": "Recibo de pago"}
_fallo: dict = {}                # empresa → último correo fallido (en este proceso)
_revisado: dict = {}             # empresa → día en que ya se revisaron los atascados (en este proceso)
MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"   # 3.87: la instalación local no avisa (lo hace la nube, ver tras_subida)

# (patrón en la respuesta de Hacienda, explicación sencilla); el primero que coincide. 3.87: «correo» va antes que «receptor»
# («El correo del receptor…»), «firma» es la palabra sola (no «firmado») e «IVA» también («exclusiva» o «respectiva» no son IVA)
_MOTIVOS = [
    (r"tel[eé]fono", "El teléfono de la empresa o del cliente no tiene el formato que pide Hacienda (8 dígitos, sin guiones ni el 506)."),
    (r"actividad", "El código de actividad económica no corresponde a la empresa o al cliente ante Hacienda."),
    (r"cabys", "Un código CABYS de las líneas no existe o no corresponde al impuesto indicado."),
    (r"\bfirma\b|certificado|llave|signature", "La firma del comprobante no es válida: revise que la llave criptográfica cargada sea la vigente y la del ambiente correcto."),
    (r"exoner", "La exoneración aplicada no es válida o ya venció."),
    (r"correo|e-?mail", "Un correo electrónico del comprobante no es válido."),
    (r"receptor|identificaci[oó]n|c[eé]dula", "La identificación del cliente no es válida o no está inscrita en Hacienda."),
    (r"24 horas|no registra", "Hacienda no registra este comprobante: hay que enviarlo de nuevo."),
    (r"fecha", "La fecha del comprobante está fuera del plazo que acepta Hacienda."),
    (r"consecutivo|clave", "La numeración (consecutivo o clave) del comprobante no es la que espera Hacienda."),
    (r"impuesto|tarifa|\biva\b", "Los impuestos o la tarifa de IVA de una línea no coinciden con lo que pide Hacienda."),
]


def motivo_simple(detalle: Optional[str]) -> str:
    """La respuesta de Hacienda en palabras simples (el texto original va aparte en el correo)."""
    t = str(detalle or "").lower()
    for patron, explicacion in _MOTIVOS:
        if re.search(patron, t):
            return explicacion
    return "Hacienda no aceptó el comprobante. El detalle de su respuesta va abajo."


# ----------------------------------------------------------------------------- utilidades
def _marca(estado: str, ahora: datetime) -> str:
    return f"{estado}:{ahora.isoformat(timespec='seconds')}"


def _fecha_marca(m: Optional[str], tz=None) -> Optional[datetime]:
    """Fecha de una marca «estado:fecha» o «pendiente:estado:fecha»."""
    if not m:
        return None
    partes = m.split(":", 2) if m.startswith(("pendiente:", "omitido:")) else m.split(":", 1)
    try:
        f = datetime.fromisoformat(partes[-1])
    except ValueError:
        return None
    return f.replace(tzinfo=tz) if f.tzinfo is None and tz is not None else f


def _empresa(eid: int) -> Optional[Empresa]:
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        if e:
            sc.expunge(e)
        return e


def aplica(e: Optional[Empresa], d: Optional[Documento] = None) -> bool:
    """Solo producción, nunca la demo ni con el interruptor apagado; nunca lo anulado a propósito ni lo importado."""
    if MODO_LOCAL or not e or e.es_demo or e.bloqueada or (e.ambiente or "") != "produccion" or getattr(e, "aviso_rechazo", True) is False:
        return False                     # 3.87: en la instalación local no (la nube tiene el correo y recibe lo que ella sube)
    if d is not None and ((d.ambiente or "") != "produccion" or d.importado_de or str(d.mensaje_hacienda or "").startswith("Anulado por el usuario")):
        return False
    return True


def destinatarios(e: Empresa) -> list[str]:
    """El correo de la empresa y los usuarios que facturan o configuran (sin bloqueados ni administradores del sistema)."""
    from . import auth
    from .main import _RE_CORREO, _correos_de
    out = list(_correos_de(e.correo or ""))
    with Session(engine) as sc:
        for m in sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == e.id)).all():
            u = sc.get(auth.Usuario, m.usuario_id)
            if u and not u.bloqueado and not u.es_superadmin and {"facturar", "configurar"} & auth.permisos_de_rol(sc, e.id, m.rol):
                out.append(u.correo)
    limpio: list[str] = []
    for c in out:
        c = (c or "").strip().lower()
        if c and _RE_CORREO.fullmatch(c) and c not in limpio:
            limpio.append(c)
    return limpio[:20]


def _smtp_plataforma():
    from . import sitio
    try:
        with Session(engine) as sc:
            cfg = sitio._smtp(sc, sitio.leer())
    except Exception:  # noqa: BLE001
        log.exception("Aviso al dueño: no se pudo leer el correo de la plataforma")
        return None
    if cfg:
        cfg.copia = None                 # 3.87: sin la copia oculta de la empresa de contacto del sitio (traería los avisos de todos)
    return cfg


def _smtp_empresa(e: Empresa):
    from .main import _cfg_smtp
    if not (e.smtp_host and e.smtp_remitente):
        return None
    try:
        cfg = _cfg_smtp(e)
    except HTTPException:
        return None
    cfg.copia = None                     # un aviso interno no va a la copia oculta de los comprobantes
    return cfg


def smtp_para(e: Empresa):
    """Correo saliente de los avisos de Hacienda (texto fijo del sistema): el de la plataforma y, si no hay, el de la empresa."""
    return _smtp_plataforma() or _smtp_empresa(e)


def _auditar(eid: int, accion: str, detalle: str) -> None:
    try:
        with Session(engine) as sc:
            auditar(sc, accion, detalle[:500], None, eid, None, "sistema (avisos al dueño)")
    except Exception:  # noqa: BLE001
        log.exception("No se pudo auditar %s", accion)


def _fecha_es(iso: Optional[str]) -> str:
    f = str(iso or "")[:10]
    return f"{f[8:10]}/{f[5:7]}/{f[:4]}" if len(f) == 10 else ""


def _dato(d: Documento) -> dict:
    return {"id": d.id, "consecutivo": d.consecutivo, "tipo": NOMBRE_TIPO.get(d.tipo_documento, "Comprobante"), "cliente": d.receptor_nombre or "Consumidor final",
            "monto": _pdf.fmt(d.total or 0, d.moneda or "CRC"), "fecha": _fecha_es(d.fecha_emision), "estado": d.estado,
            "detalle": str(d.mensaje_hacienda or "").strip()[:600]}


def _enlace(did: Optional[int] = None) -> str:
    if not URL_PUBLICA:
        return ""
    return f"{URL_PUBLICA}/app/#/ventas/facturas" + (f"/{did}" if did else "")


# ----------------------------------------------------------------------------- correos
def correo_rechazos(e: Empresa, docs: list[dict]) -> tuple[str, str, str]:
    """(asunto, html, texto) del aviso de uno o varios comprobantes rechazados o con error."""
    nombre = e.nombre_comercial or e.nombre
    rem = _dz.de_empresa(e)
    pie = f"Recibe este aviso porque factura o administra {nombre}. Se apaga en Configuración › Facturación electrónica."
    if len(docs) == 1:
        d = docs[0]
        rechazado = d["estado"] == "rechazado"
        titulo = "Hacienda rechazó un comprobante" if rechazado else "Un comprobante no llegó a Hacienda"
        asunto = (f"Hacienda rechazó {d['consecutivo']}" if rechazado else f"Hacienda no recibió {d['consecutivo']}") + f" · {nombre}"
        motivo = motivo_simple(d["detalle"])
        que_hacer = ("Mientras no se corrija, esta venta no tiene un comprobante válido ante Hacienda. Corrija el dato que se indica y emita "
                     "un comprobante nuevo; si la venta rebajó inventario, el sistema ya lo devolvió, y si tenía un cobro, ya salió de Bancos: regístrelo de nuevo al emitir el corregido.") if rechazado else \
                    ("Hacienda no recibió este comprobante. Corrija el dato que se indica y vuelva a enviarlo desde la lista de comprobantes, "
                     "o anúlelo y emita uno nuevo.")
        datos = [("Comprobante", f"{d['tipo']} {d['consecutivo']}"), ("Cliente", d["cliente"]), ("Monto", d["monto"]), ("Fecha", d["fecha"]),
                 ("Respuesta de Hacienda", d["detalle"])]
        # orden: el motivo en palabras simples, los datos (con la respuesta original), el botón y qué hacer
        html = _dz.armar(rem, titulo=titulo, antetitulo="Aviso de Hacienda", asunto=asunto, preencabezado=f"{d['consecutivo']} · {d['cliente']} · {d['monto']}",
                         aviso=motivo, aviso_tono="rojo", datos=datos, boton_=("Ver el comprobante", _enlace(d["id"])) if _enlace() else None,
                         despues=[que_hacer], nota=pie)
        texto = (f"{titulo}\n\nMotivo: {motivo}\n\n" + "\n".join(f"{k}: {v}" for k, v in datos if v) + f"\n\n{que_hacer}\n"
                 + (f"\nVer el comprobante: {_enlace(d['id'])}\n" if _enlace() else "") + f"\n{pie}\n")
        return asunto[:200], html, texto
    n = len(docs)
    titulo = f"Hacienda rechazó {n} comprobantes"
    asunto = f"Hacienda rechazó {n} comprobantes · {nombre}"
    lineas = [(f"{d['tipo']} {d['consecutivo']} · {d['cliente']}", d["monto"], motivo_simple(d["detalle"])) for d in docs[:40]]
    explicacion = ("Mientras no se corrijan, estas ventas no tienen un comprobante válido ante Hacienda. Si todos tienen el mismo motivo, "
                   "seguramente es un dato de la configuración (teléfono, actividad económica, llave criptográfica): corríjalo una vez y emita "
                   "los comprobantes de nuevo.")
    html = _dz.armar(rem, titulo=titulo, antetitulo="Aviso de Hacienda", asunto=asunto, preencabezado=f"{n} comprobantes con rechazo o error",
                     parrafos_txt=[explicacion], lineas=lineas, boton_=("Ver los comprobantes", _enlace()) if _enlace() else None,
                     despues=[f"Y {n - 40} más en la lista de comprobantes."] if n > 40 else [], nota=pie)
    texto = (f"{titulo}\n\n" + "\n".join(f"- {a} · {m}: {x}" for a, m, x in lineas) + f"\n\n{explicacion}\n"
             + (f"\nVer los comprobantes: {_enlace()}\n" if _enlace() else "") + f"\n{pie}\n")
    return asunto[:200], html, texto


def correo_atascados(e: Empresa, docs: list[dict]) -> tuple[str, str, str]:
    nombre = e.nombre_comercial or e.nombre
    n = len(docs)
    titulo = "Comprobantes sin respuesta de Hacienda" if n != 1 else "Un comprobante sin respuesta de Hacienda"
    asunto = f"{n} comprobante{'s' if n != 1 else ''} sin respuesta de Hacienda · {nombre}"
    lineas = [(f"{d['tipo']} {d['consecutivo']} · {d['cliente']}", d["monto"], f"Emitido el {d['fecha']}" if d["fecha"] else "") for d in docs[:40]]
    # 3.87: en singular cuando es uno (el título y el asunto ya lo estaban; el párrafo decía siempre «Estos comprobantes…»)
    explicacion = (("Este comprobante sigue esperando a Hacienda desde hace más de un día. Normalmente se resuelve solo" if n == 1 else
                    "Estos comprobantes siguen esperando a Hacienda desde hace más de un día. Normalmente se resuelven solos")
                   + " cuando Hacienda vuelve a responder; si pasan varios días, revise la conexión con Hacienda (usuario, contraseña y llave "
                   "criptográfica) en Configuración › Facturación electrónica.")
    pie = f"Recibe este aviso porque factura o administra {nombre}. Se apaga en Configuración › Facturación electrónica."
    html = _dz.armar(_dz.de_empresa(e), titulo=titulo, antetitulo="Aviso de Hacienda", asunto=asunto, preencabezado=f"{n} esperando respuesta más de 24 horas",
                     parrafos_txt=[explicacion], lineas=lineas,
                     boton_=(("Ver el comprobante", _enlace(docs[0]["id"])) if n == 1 else ("Ver los comprobantes", _enlace())) if _enlace() else None,   # 3.87: uno, al comprobante
                     despues=[f"Y {n - 40} más en la lista de comprobantes."] if n > 40 else [], nota=pie)
    texto = f"{titulo}\n\n" + "\n".join(f"- {a} · {m} {x}" for a, m, x in lineas) + f"\n\n{explicacion}\n\n{pie}\n"
    return asunto[:200], html, texto


# ----------------------------------------------------------------------------- rechazos
def _marcar_pendiente(eid: int, did: int, estado: str, ahora: datetime) -> None:
    with Session(engine_empresa(eid)) as se:
        se.execute(text("UPDATE documento SET aviso_enviado = :m WHERE id = :id AND estado = :e AND "
                        "(aviso_enviado IS NULL OR (aviso_enviado NOT LIKE :ya AND aviso_enviado NOT LIKE 'pendiente:%'))"),
                   {"m": f"pendiente:{estado}:{ahora.isoformat(timespec='seconds')}", "id": did, "e": estado, "ya": estado + ":%"})
        se.commit()


def enviar_pendientes(eid: int, ahora: Optional[datetime] = None) -> int:
    """Manda en un solo correo los rechazos pendientes de la empresa si pasó la espera desde el último aviso. Devuelve cuántos
    comprobantes avisó. Lo que ya no corresponde (se corrigió, se anuló, se apagó el aviso, de más de un día) queda «omitido»."""
    ahora = ahora or ahora_cr()
    with Session(engine_empresa(eid)) as se:
        pend = se.exec(select(Documento).where(Documento.empresa_id == eid, Documento.aviso_enviado.like("pendiente:%"))).all()
        if not pend:
            return 0                                   # lo normal en cada pasada: nada pendiente, sin más consultas
        e = _empresa(eid)
        vigentes, omitir = [], []
        for d in pend:
            f = _fecha_marca(d.aviso_enviado, ahora.tzinfo)
            if not aplica(e, d) or d.estado not in ESTADOS_AVISO or (f is not None and ahora - f > timedelta(days=1)):
                omitir.append((d.id, d.aviso_enviado))
            else:
                vigentes.append(d)
        for did, antes in omitir:
            se.execute(text("UPDATE documento SET aviso_enviado = :m WHERE id = :id AND aviso_enviado = :antes"),
                       {"m": "omitido:" + antes.split(":", 1)[1], "id": did, "antes": antes})
        se.commit()
        if not vigentes:
            return 0
        f_fallo = _fallo.get(eid)
        if f_fallo and ahora - f_fallo < timedelta(minutes=REINTENTO_MIN):
            return 0
        # 3.87: la espera se mide con la marca del último aviso, no con la fecha de emisión: una cola detenida que se reanuda con
        # comprobantes de hace más de 30 días también se junta (las marcas llevan la hora ISO con el mismo desfase: se comparan como texto)
        limite = (ahora - timedelta(minutes=ESPERA_MIN)).isoformat(timespec="seconds")
        reciente = se.exec(select(Documento.id).where(Documento.empresa_id == eid, or_(
            and_(Documento.aviso_enviado.like("rechazado:%"), Documento.aviso_enviado >= "rechazado:" + limite),
            and_(Documento.aviso_enviado.like("error:%"), Documento.aviso_enviado >= "error:" + limite)))).first()
        if reciente is not None:
            return 0                                   # se acaba de avisar: lo junta la siguiente pasada de la cola
        tomados = []
        for d in vigentes:                             # reclamo condicionado: dos procesos no mandan el mismo aviso
            m = _marca(d.estado, ahora)
            if se.execute(text("UPDATE documento SET aviso_enviado = :m WHERE id = :id AND aviso_enviado = :antes"),
                          {"m": m, "id": d.id, "antes": d.aviso_enviado}).rowcount:
                tomados.append((_dato(d), d.aviso_enviado, m))
        se.commit()
    if not tomados:
        return 0
    docs = [t[0] for t in tomados]
    try:
        para = destinatarios(e)
        cfg = smtp_para(e) if para else None
        if not para or not cfg:
            _auditar(eid, "aviso_rechazo_omitido", ", ".join(d["consecutivo"] for d in docs) + (": sin correo saliente" if para else ": sin destinatarios"))
            return 0
        asunto, html, texto = correo_rechazos(e, docs)
        correo.enviar(cfg, para, asunto, html, texto, [])
    except Exception as ex:  # noqa: BLE001  el comprobante queda igual; se reintenta más tarde (pendiente de nuevo)
        _fallo[eid] = ahora
        with Session(engine_empresa(eid)) as se:
            for _d, antes, m in tomados:
                se.execute(text("UPDATE documento SET aviso_enviado = :antes WHERE id = :id AND aviso_enviado = :m"), {"antes": antes, "id": _d["id"], "m": m})
            se.commit()
        _auditar(eid, "aviso_rechazo_fallido", f"{', '.join(d['consecutivo'] for d in docs)}: {getattr(ex, 'detail', None) or ex}")
        return 0
    _fallo.pop(eid, None)
    _auditar(eid, "aviso_rechazo", f"{', '.join(d['consecutivo'] for d in docs)} ({', '.join(sorted({d['estado'] for d in docs}))}) avisado a {', '.join(para)}")
    return len(docs)


def programar_rechazo(e: Empresa, d: Documento, sincrono: bool = False) -> None:
    """Se llama después del commit cuando un comprobante RECIÉN pasó a rechazado o error. Nunca lanza: el aviso es un extra."""
    try:
        if d.estado not in ESTADOS_AVISO or not aplica(e, d):
            return
        eid, did, estado = int(e.id), int(d.id), d.estado
    except Exception:  # noqa: BLE001
        return

    def _tarea():
        try:
            ahora = ahora_cr()
            _marcar_pendiente(eid, did, estado, ahora)
            enviar_pendientes(eid, ahora)
        except Exception:  # noqa: BLE001
            log.exception("Aviso de rechazo, empresa %s, comprobante %s", eid, did)

    if sincrono:
        _tarea()
    else:
        threading.Thread(target=_tarea, daemon=True).start()


def estados_de(s: Session, eid: int, documentos: list) -> dict:
    """Nube, antes de guardar lo que sube una instalación local: el estado que tenía aquí cada comprobante (por clave)."""
    try:
        claves = [str(d["clave"]) for d in documentos or [] if isinstance(d, dict) and d.get("clave")]
        if not claves:
            return {}
        filas = s.exec(select(Documento.clave, Documento.estado).where(Documento.empresa_id == eid, Documento.clave.in_(claves))).all()
        return {c: est for c, est in filas}
    except Exception:  # noqa: BLE001  el aviso es un extra: nunca frena la sincronización
        log.exception("Aviso de rechazo: estados previos de la subida, empresa %s", eid)
        return {}


def tras_subida(e: Empresa, antes: dict, recibidos: list, sincrono: bool = False) -> None:
    """3.87, nube: la instalación local consulta a Hacienda y sube el estado, pero no avisa (aplica()). Los comprobantes que llegan
    rechazados o con error, y aquí no lo estaban, se avisan desde aquí, juntos como una ráfaga. Nunca lanza."""
    try:
        if not recibidos or not aplica(e):
            return
        eid = int(e.id)
        claves = list(recibidos)
    except Exception:  # noqa: BLE001
        return

    def _tarea():
        try:
            ahora, emp = ahora_cr(), _empresa(eid)
            with Session(engine_empresa(eid)) as se:
                docs = se.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave.in_(claves))).all()
                nuevos = [(d.id, d.estado) for d in docs if d.estado in ESTADOS_AVISO and antes.get(d.clave) != d.estado and aplica(emp, d)]
            for did, estado in nuevos:
                _marcar_pendiente(eid, did, estado, ahora)
            if nuevos:
                enviar_pendientes(eid, ahora)
        except Exception:  # noqa: BLE001
            log.exception("Aviso de rechazo de lo que subió la instalación local, empresa %s", eid)

    if sincrono:
        _tarea()
    else:
        threading.Thread(target=_tarea, daemon=True).start()


# ----------------------------------------------------------------------------- atascados
def _desde_cuando(d: Documento, tz) -> Optional[datetime]:
    try:
        f = datetime.fromisoformat(str(d.fecha_envio or d.fecha_emision))
    except (TypeError, ValueError):
        return None
    return f.replace(tzinfo=tz) if f.tzinfo is None else f


def avisar_atascados(eid: int, ahora: Optional[datetime] = None) -> int:
    """Una vez al día: los comprobantes que siguen «firmado» o «enviado» más de 24 horas, cada uno una sola vez."""
    ahora = ahora or ahora_cr()
    hoy = ahora.date().isoformat()
    if _revisado.get(eid) == hoy:
        return 0
    e = _empresa(eid)
    if not aplica(e):
        _revisado[eid] = hoy
        return 0
    desde = (ahora - timedelta(days=VENTANA_DIAS)).date().isoformat()
    limite = ahora - timedelta(hours=24)
    with Session(engine_empresa(eid)) as se:
        hechos = se.exec(select(Documento.aviso_enviado).where(Documento.empresa_id == eid, Documento.fecha_emision >= desde,
                                                               Documento.aviso_enviado.like("atascado:%"))).all()
        if any((f := _fecha_marca(m, ahora.tzinfo)) is not None and f.date().isoformat() == hoy for m in hechos):
            _revisado[eid] = hoy                       # otro proceso ya mandó el de hoy
            return 0
        cand = se.exec(select(Documento).where(Documento.empresa_id == eid, Documento.ambiente == "produccion", Documento.estado.in_(("firmado", "enviado")),
                                               Documento.aviso_enviado == None, Documento.fecha_emision >= desde)  # noqa: E711
                       .order_by(Documento.id)).all()
        lista = [d for d in cand if aplica(e, d) and (f := _desde_cuando(d, ahora.tzinfo)) is not None and f <= limite]
        _revisado[eid] = hoy
        if not lista:
            return 0
        m = _marca("atascado", ahora)
        tomados = []
        for d in lista:
            if se.execute(text("UPDATE documento SET aviso_enviado = :m WHERE id = :id AND aviso_enviado IS NULL"), {"m": m, "id": d.id}).rowcount:
                tomados.append(_dato(d))
        se.commit()
    if not tomados:
        return 0
    try:
        para = destinatarios(e)
        cfg = smtp_para(e) if para else None
        if not para or not cfg:
            return 0                                    # sin a quién o sin correo: quedan marcados (Inicio los sigue mostrando)
        asunto, html, texto = correo_atascados(e, tomados)
        correo.enviar(cfg, para, asunto, html, texto, [])
    except Exception as ex:  # noqa: BLE001  se libera la marca: mañana se intenta otra vez
        with Session(engine_empresa(eid)) as se:
            for d in tomados:
                se.execute(text("UPDATE documento SET aviso_enviado = NULL WHERE id = :id AND aviso_enviado = :m"), {"id": d["id"], "m": m})
            se.commit()
        _auditar(eid, "aviso_atascados_fallido", f"{len(tomados)} comprobante(s): {getattr(ex, 'detail', None) or ex}")
        return 0
    _auditar(eid, "aviso_atascados", f"{len(tomados)} comprobante(s) sin respuesta de Hacienda avisados a {', '.join(para)}")
    return len(tomados)


def pasada(ahora: Optional[datetime] = None) -> list[dict]:
    """La llama la cola de Hacienda en cada pasada: rechazos juntados (pendientes) y, una vez al día, los atascados."""
    out = []
    with Session(engine) as sc:
        ids = [e.id for e in sc.exec(select(Empresa).where(Empresa.bloqueada == False, Empresa.ambiente == "produccion")).all()]  # noqa: E712
    for eid in ids:
        try:
            r = {"empresa_id": eid, "rechazos": enviar_pendientes(eid, ahora), "atascados": avisar_atascados(eid, ahora)}
            if r["rechazos"] or r["atascados"]:
                out.append(r)
        except Exception as ex:  # noqa: BLE001  una empresa con error no frena a las demás
            log.exception("Avisos al dueño, empresa %s", eid)
            out.append({"empresa_id": eid, "error": str(ex)[:200]})
    return out


class AvisoRechazoIn(BaseModel):
    activo: bool


@router.put("/api/empresa/aviso-rechazo")
def put_aviso_rechazo(data: AvisoRechazoIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    """Interruptor «Avisarme por correo si Hacienda rechaza un comprobante» (Configuración › Facturación electrónica)."""
    e = s.get(Empresa, ctx.empresa.id)
    e.aviso_rechazo = bool(data.activo)
    s.add(e); s.commit()
    auditar(s, "config_empresa", f"Aviso por correo de rechazos de Hacienda {'encendido' if e.aviso_rechazo else 'apagado'}", ctx.usuario, e.id, ctx.request)
    return {"ok": True, "aviso_rechazo": e.aviso_rechazo}


# ----------------------------------------------------------------------------- cierre de caja (Z) por correo
class CierreCajaCorreoIn(BaseModel):
    caja_id: int                                   # sesión de caja (registro pos_cajas)
    titulo: str = Field(max_length=120)
    subtitulo: Optional[str] = Field(None, max_length=300)
    periodo: Optional[str] = Field(None, max_length=80)
    kpis: list[reportes.KpiIn] = Field(default_factory=list, max_length=8)
    secciones: list[reportes.SeccionIn] = Field(default_factory=list, max_length=12)
    nota: Optional[str] = Field(None, max_length=300)


def terminal_de(cfg, caja: dict) -> dict:
    """La caja (terminal de pos_config) de una sesión: por su id o, en sesiones viejas, por el nombre."""
    if not isinstance(cfg, dict):
        return {}
    terminales = cfg.get("terminales")
    if not isinstance(terminales, list) or not terminales:
        return cfg                                     # configuración de una sola caja (versiones anteriores)
    tid = caja.get("terminal_id")
    t = next((t for t in terminales if isinstance(t, dict) and tid is not None and str(t.get("id")) == str(tid)), None)
    if t is None:
        t = next((t for t in terminales if isinstance(t, dict) and (t.get("nombre") or "") == (caja.get("caja") or "")), None)
    return t or {}


@router.post("/api/pos/cierres/correo")
def cierre_caja_correo(data: CierreCajaCorreoIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """Manda el reporte de cierre (Z) en PDF a «Enviar el cierre a» de la caja. El PDF es el mismo que se descarga en Cierres de caja;
    el destinatario sale de la configuración de la caja. Si el correo falla, el cierre queda igual (la caja ya está cerrada)."""
    from .main import _auditar as _auditar_ctx, _correos_validos
    e = ctx.empresa
    limitar_ip(ctx.request, "cierre_caja_correo", 30, 3600, "Demasiados envíos del cierre en poco tiempo; espere unos minutos", f"u{getattr(ctx.usuario, 'id', None)}")
    caja = next((x for x in (modulos.leer(s, e.id, "pos_cajas", []) or []) if isinstance(x, dict) and str(x.get("id")) == str(data.caja_id)), None)
    if not caja:
        raise HTTPException(404, "Sesión de caja no encontrada")
    if caja.get("estado") != "Cerrada":
        raise HTTPException(409, "La caja todavía está abierta: el reporte de cierre se envía al cerrarla")
    t = terminal_de(modulos.leer(s, e.id, "pos_config", None), caja)
    para = _correos_validos(str(t.get("correo_cierre") or ""), "Enviar el cierre a")[:10]
    if not para:
        raise HTTPException(400, "Indique «Enviar el cierre a» en Punto de venta › Configuración de la caja")
    rep = reportes.ReporteIn(titulo=data.titulo, subtitulo=data.subtitulo, periodo=data.periodo, kpis=data.kpis, secciones=data.secciones,
                             nota=data.nota, archivo=f"cierre_caja_{data.caja_id}")
    reportes._validar(rep)
    if sum(len(x.filas) * len(x.columnas) for x in rep.secciones) > 30000:
        raise HTTPException(400, "El cierre es muy grande para enviarlo en PDF (más de 30.000 celdas): descárguelo en Word")
    # 3.87: SOLO el correo saliente de la empresa (como el cierre del hotel), nunca el de la plataforma: el texto, los enlaces y el PDF
    # los arma el navegador y el destinatario lo elige la empresa; por la plataforma sería un relevo de correo con su nombre
    cfg = _smtp_empresa(e)
    if not cfg:
        raise HTTPException(400, "Configure el correo saliente de la empresa (Configuración › Facturación electrónica › Correo saliente)")
    contenido = reportes._pdf(rep, e, _pdf.logo_empresa(e))
    nombre_caja = str(caja.get("caja") or t.get("nombre") or "Caja")
    fecha = _fecha_es(caja.get("fecha"))
    nombre = e.nombre_comercial or e.nombre
    datos = [("Caja", nombre_caja), ("Cajero", str(caja.get("usuario") or "")), ("Fecha", fecha)] + [(k.t, k.v) for k in data.kpis]
    aviso = ""
    try:
        dif = float(caja.get("diferencia"))
        if abs(dif) > 0.005:
            aviso = f"El efectivo contado no coincide con el esperado: diferencia de {_pdf.fmt(dif, 'CRC', con_codigo=False)}."
    except (TypeError, ValueError):
        pass
    asunto = f"Cierre de caja {nombre_caja} · {fecha} · {nombre}"[:200]
    nota = "El detalle completo (arqueo, ventas por medio de pago, retiros, propinas y anulaciones) va en el PDF adjunto."
    html = _dz.armar(_dz.de_empresa(e), titulo=f"Cierre de caja · {nombre_caja}", antetitulo="Reporte de cierre (Z)", asunto=asunto,
                     preencabezado=" · ".join(f"{k}: {v}" for k, v in datos[3:5]), aviso=aviso, aviso_tono="ambar", datos=datos, nota=nota)
    texto = f"Cierre de caja · {nombre_caja}\n\n" + "\n".join(f"{k}: {v}" for k, v in datos if v) + (f"\n\n{aviso}" if aviso else "") + f"\n\n{nota}\n"
    try:
        correo.enviar(cfg, para, asunto, html, texto, [(f"cierre_caja_{data.caja_id}.pdf", contenido, "application", "pdf")])
    except Exception as ex:  # noqa: BLE001
        _auditar_ctx(ctx, "pos_cierre_correo_fallido", f"Cierre de {nombre_caja} ({caja.get('fecha')}): {str(ex)[:200]}")
        raise HTTPException(502, f"La caja quedó cerrada, pero el correo del cierre no salió: {str(ex)[:200]}")
    _auditar_ctx(ctx, "pos_cierre_correo", f"Cierre de {nombre_caja} ({caja.get('fecha')}) enviado a {', '.join(para)}")
    return {"ok": True, "para": para}
