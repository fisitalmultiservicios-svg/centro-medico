"""Publicidad por correo de FISITAAP by Brillante Agencia (3.39). Solo el administrador del sistema (consola › Publicidad).

Qué hace
- Lista propia de contactos (tabla central PubContacto): se agregan a mano, pegando una lista o un CSV, desde las solicitudes del
  sitio y desde los administradores de las empresas clientes. Cada contacto guarda de dónde salió y con qué permiso:
    «expreso»  = pidió recibir novedades (casilla del formulario del sitio, o lo dijo de otra forma);
    «relacion» = cliente o prospecto que ya tuvo trato con nosotros (se le puede escribir de servicios parecidos con opción de baja).
  Las etiquetas sirven para mandar una campaña solo a un grupo (hoteles, clientes, prospectos…).
- Campañas (PubCampana): asunto, título, texto con formato sencillo (**negrita**, listas con «- », enlaces), imagen y botón opcionales.
  Se pueden probar mandándolas a un correo, y al enviarlas se crea un PubEnvio por contacto activo del público elegido.
- El envío va por lotes con un tope por hora (cPanel limita los correos por hora del dominio y pasarse bloquea TODO el correo,
  incluidas las facturas). Cada pasada de la cola (cada 5 min) manda lo que permite el tope; nada se manda dos veces (cada envío se
  reclama con un UPDATE condicional, seguro entre procesos).
- Todo correo lleva el enlace para darse de baja y las cabeceras List-Unsubscribe / List-Unsubscribe-Post (baja con un clic, la
  piden Gmail y Yahoo a quien manda correo masivo). La baja es inmediata y los envíos pendientes a ese contacto se omiten.
- Correo de salida: el del sistema (FE_SMTP_*) o, mejor, una cuenta aparte configurada aquí (cifrada con la clave maestra en
  data/publicidad.json), para que un reclamo por publicidad no afecte los correos de facturas y contraseñas.
"""
import hashlib
import hmac
import html as _html
import json
import logging
import os
import re
import smtplib
import socket
import threading
from datetime import datetime, timedelta, timezone
from email.utils import formataddr
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field as PField
from sqlalchemy import func, text as _sql
from sqlmodel import Field, Session, SQLModel, select

from . import correo as _correo, secretos
from . import publicidad_diseno as _diseno
from .auth import SECRET, Usuario, superadmin as _superadmin
from .config import DATA_DIR, ahora_cr, nombre_sistema
from .db import central, engine, get_session

log = logging.getLogger(__name__)
router = APIRouter(tags=["publicidad"])
NO_VE_TODAS = ("Publicidad usa una sola lista de contactos y de campañas para toda la plataforma, que incluye las empresas que usted no "
               "administra: solo la maneja un administrador del sistema que ve todas las empresas")


def superadmin(a: Usuario = Depends(_superadmin), s: Session = Depends(get_session)) -> Usuario:
    """3.87 (admin_sistema:5): toda la consola de Publicidad pide, además, ver todas las empresas, como el respaldo general. La lista de
    contactos y los envíos no son de ninguna empresa (el contacto guarda solo un texto libre como empresa), así que a un administrador
    con empresas ocultas no se le pueden recortar sin dejar rastros: le nombraba empresas ocultas, traía con «Traer clientes del
    sistema» a los administradores de ellas y les mandaba sus campañas. Un id de una empresa ya eliminada no cuenta."""
    from .auth import empresas_ocultas_de
    from .db import Empresa
    ocultas = empresas_ocultas_de(a)
    if ocultas and s.exec(select(Empresa.id).where(Empresa.id.in_(list(ocultas))).limit(1)).first() is not None:  # type: ignore[attr-defined]
        raise HTTPException(403, NO_VE_TODAS)
    return a


ARCHIVO = DATA_DIR / "publicidad.json"
RE_CORREO = re.compile(r"[^@\s,;<>\"'()]+@[^@\s,;<>\"'()]+\.[A-Za-z]{2,}")
PERMISOS = {"expreso": "Pidió recibir novedades", "relacion": "Cliente o prospecto con trato previo"}
MAX_CONTACTOS = 20000
MAX_POR_PASADA = 300


def _ahora() -> datetime:
    return datetime.now(timezone.utc)


class PubContacto(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    correo: str = Field(index=True, unique=True)
    nombre: Optional[str] = None
    empresa: Optional[str] = None
    etiquetas: Optional[str] = None          # «hoteles, clientes» (minúsculas, sin repetir)
    origen: str = "manual"                   # manual | importado | sitio | plataforma
    permiso: str = "relacion"                # expreso | relacion
    estado: str = "activo"                   # activo | baja | rebotado
    baja_en: Optional[datetime] = None
    nota: Optional[str] = None
    creado: datetime = Field(default_factory=_ahora)


class PubCampana(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str
    asunto: str
    titulo: Optional[str] = None
    antetitulo: Optional[str] = None         # texto pequeño sobre el título (3.40)
    preencabezado: Optional[str] = None      # lo que muestra la bandeja junto al asunto (3.40)
    tema: str = "fisitaap"                   # colores del correo (publicidad_diseno.TEMAS)
    cuerpo: str = ""
    imagen_url: Optional[str] = None
    boton_texto: Optional[str] = None
    boton_url: Optional[str] = None
    etiquetas: Optional[str] = None          # público: contactos con ALGUNA de estas etiquetas (vacío = todos los activos)
    estado: str = "borrador"                 # borrador | enviando | pausada | enviada | cancelada
    total: int = 0
    enviados: int = 0
    fallidos: int = 0
    omitidos: int = 0
    ultimo_error: Optional[str] = None
    creada: datetime = Field(default_factory=_ahora)
    iniciada: Optional[datetime] = None
    terminada: Optional[datetime] = None


class PubEnvio(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    campana_id: int = Field(index=True)
    contacto_id: int = Field(index=True)
    correo: str
    estado: str = Field(default="pendiente", index=True)   # pendiente | enviando | enviado | fallido | omitido
    error: Optional[str] = None
    enviado_en: Optional[datetime] = Field(default=None, index=True)


central(PubContacto, PubCampana, PubEnvio)


# ----------------------------------------------------------------------------------------------------- utilidades
def _txt(v, maximo: int) -> str:
    return " ".join(str(v or "").split())[:maximo]


def _etiquetas(v) -> Optional[str]:
    lista = v if isinstance(v, list) else re.split(r"[,;\n]+", str(v or ""))
    out = list(dict.fromkeys(_txt(x, 40).lower() for x in lista if _txt(x, 40)))[:20]
    return ", ".join(out) or None


def _lista_etiquetas(v: Optional[str]) -> list[str]:
    return [x.strip() for x in (v or "").split(",") if x.strip()]


def _url_ok(v: Optional[str]) -> Optional[str]:
    v = (v or "").strip()
    if not v:
        return None
    if not re.fullmatch(r"https?://[^\s<>\"']{3,500}", v):
        raise HTTPException(400, f"Dirección no válida: {v[:80]} (debe empezar con https://)")
    return v


def _base() -> str:
    from .sitio import base_url
    return base_url()


def token_baja(cid: int) -> str:
    firma = hmac.new(SECRET, f"pub-baja:{cid}".encode(), hashlib.sha256).hexdigest()[:24]
    return f"{cid}.{firma}"


def _cid_de_token(token: str) -> Optional[int]:
    try:
        cid = int(str(token).split(".", 1)[0])
    except ValueError:
        return None
    return cid if hmac.compare_digest(token_baja(cid), str(token)) else None


# ----------------------------------------------------------------------------------------------------- configuración
DEFECTO = {"usar_sistema": True, "por_hora": 100, "pie": "{sistema} · Facturación electrónica en Costa Rica", "smtp": {}}   # {sistema} = nombre del sistema (3.51)


def leer_config() -> dict:
    cfg = json.loads(json.dumps(DEFECTO))
    try:
        cfg.update(json.loads(ARCHIVO.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return cfg


def _guardar_config(cfg: dict):
    tmp = ARCHIVO.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg), encoding="utf-8")
    os.replace(tmp, ARCHIVO)
    try:
        os.chmod(ARCHIVO, 0o600)
    except OSError:
        pass


def _descifrar(v: Optional[str]) -> str:
    if not v:
        return ""
    try:
        return secretos._maestra.decrypt(v.encode()).decode()
    except Exception:  # noqa: BLE001
        return ""


def _smtp_sistema() -> Optional[_correo.ConfigSMTP]:
    host = (os.getenv("FE_SMTP_HOST") or "").strip()
    if not host:
        return None
    seg = (os.getenv("FE_SMTP_SEGURIDAD") or "ssl").strip().lower()
    try:
        puerto = int(os.getenv("FE_SMTP_PUERTO") or (465 if seg == "ssl" else 587))
    except ValueError:
        puerto = 465
    return _correo.ConfigSMTP(host, puerto, os.getenv("FE_SMTP_USUARIO") or None, os.getenv("FE_SMTP_PASSWORD") or None,
                              (os.getenv("FE_SMTP_REMITENTE") or os.getenv("FE_SMTP_USUARIO") or "").strip(), seguridad=seg, nombre=nombre_sistema())


def _pie(cfg: dict) -> str:
    """Pie de los correos: {sistema} se cambia por el nombre del sistema (3.51)."""
    return str(cfg.get("pie") or DEFECTO["pie"]).replace("{sistema}", nombre_sistema())


def config_smtp(cfg: Optional[dict] = None) -> Optional[_correo.ConfigSMTP]:
    cfg = cfg or leer_config()
    if cfg.get("usar_sistema"):
        return _smtp_sistema()
    m = cfg.get("smtp") or {}
    if not (m.get("host") and m.get("remitente")):
        return None
    seg = m.get("seguridad") or "ssl"
    return _correo.ConfigSMTP(m["host"], int(m.get("puerto") or (465 if seg == "ssl" else 587)), m.get("usuario") or None,
                              _descifrar(m.get("password")) or None, m["remitente"], seguridad=seg, nombre=m.get("nombre") or nombre_sistema(),
                              responder_a=m.get("responder_a") or None)


def _resumen_config() -> dict:
    cfg = leer_config()
    m = cfg.get("smtp") or {}
    sis = _smtp_sistema()
    return {"usar_sistema": bool(cfg.get("usar_sistema")), "por_hora": int(cfg.get("por_hora") or 100), "pie": cfg.get("pie") or "",
            "sistema_disponible": bool(sis), "sistema_remitente": sis.remitente if sis else None,
            "smtp": {"host": m.get("host") or "", "puerto": m.get("puerto") or 465, "usuario": m.get("usuario") or "", "remitente": m.get("remitente") or "",
                     "nombre": m.get("nombre") or nombre_sistema(), "seguridad": m.get("seguridad") or "ssl", "responder_a": m.get("responder_a") or "",
                     "clave_guardada": bool(_descifrar(m.get("password")))},
            "listo": bool(config_smtp(cfg)), "actualizado": cfg.get("actualizado")}


# ----------------------------------------------------------------------------------------------------- contenido
def _personalizar(t: str, c: Optional[PubContacto]) -> str:
    """{nombre} (solo el primer nombre) y {empresa}. Si el contacto no los tiene, se quitan sin dejar «, su hotel…» ni «Hola ,»."""
    nombre = ((c.nombre or "").split() or [""])[0] if c else ""
    empresa = ((c.empresa or "") if c else "").strip()
    lineas = []
    for x in (t or "").split("\n"):
        for clave, valor in (("{nombre}", nombre), ("{empresa}", empresa)):
            if clave not in x:
                continue
            if valor:
                x = x.replace(clave, valor)
                continue
            al_inicio = x.lstrip().startswith(clave)
            x = re.sub(r"^(\s*)" + re.escape(clave) + r"\s*[,:;]?\s*", r"\1", x)       # «{nombre}, su hotel…» → «Su hotel…»
            x = re.sub(r"[ \t]*" + re.escape(clave), "", x)                              # «Hola {nombre}» → «Hola»
            if al_inicio:
                i = len(x) - len(x.lstrip())
                x = x[:i] + x[i:i + 1].upper() + x[i + 1:]
        lineas.append(re.sub(r"[ \t]+([,.!?])", r"\1", x))
    return "\n".join(lineas)


def armar(camp: dict, c: Optional[PubContacto], url_baja: str, pie: str) -> tuple[str, str, str]:
    """(asunto, html, texto) de una campaña para un contacto. Diseño sin imágenes externas en publicidad_diseno (3.40; logo «cid:» 3.83)."""
    p = lambda k: _personalizar(camp.get(k) or "", c).strip()            # noqa: E731
    asunto = _txt(p("asunto"), 200)
    titulo, antetitulo, cuerpo, pre = p("titulo"), p("antetitulo"), p("cuerpo"), p("preencabezado")
    base = _base()
    boton = (camp.get("boton_texto") or "").strip() and camp.get("boton_url")
    html = _diseno.documento(asunto=asunto, antetitulo=antetitulo, titulo=titulo, cuerpo=cuerpo, preencabezado=pre, imagen_url=camp.get("imagen_url"),
                             boton_texto=camp.get("boton_texto"), boton_url=camp.get("boton_url"), tema_nombre=camp.get("tema"), pie=pie, base=base, url_baja=url_baja)
    texto = "\n\n".join(x for x in [antetitulo.upper() if antetitulo else "", titulo, _diseno.cuerpo_texto(cuerpo),
                                    f"{camp['boton_texto'].strip()}: {camp['boton_url']}" if boton else "",
                                    f"--\n{pie}\n{base}\nPara no recibir más correos como este: {url_baja}"] if x)
    return asunto, html, texto


def _mensaje(cfg: _correo.ConfigSMTP, para: str, asunto: str, html: str, texto: str, url_baja: str):
    msg = _correo._mensaje(cfg, [para], asunto, html, texto, [])
    msg["List-Unsubscribe"] = f"<{url_baja}>"
    msg["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
    return msg


# ----------------------------------------------------------------------------------------------------- envío por lotes
_proc = threading.Lock()


def _enviados_ultima_hora(s: Session) -> int:
    desde = _ahora() - timedelta(hours=1)
    return s.exec(select(func.count()).select_from(PubEnvio).where(PubEnvio.enviado_en >= desde)).one()


def _cerrar_terminadas(s: Session):
    for camp in s.exec(select(PubCampana).where(PubCampana.estado == "enviando")).all():
        _contar(s, camp)
        pend = s.exec(select(func.count()).select_from(PubEnvio).where(PubEnvio.campana_id == camp.id, PubEnvio.estado.in_(["pendiente", "enviando"]))).one()
        if not pend:
            camp.estado, camp.terminada = "enviada", _ahora()
        s.add(camp)
    s.commit()


def _contar(s: Session, camp: PubCampana):
    filas = dict(s.exec(select(PubEnvio.estado, func.count()).where(PubEnvio.campana_id == camp.id).group_by(PubEnvio.estado)).all())
    camp.enviados, camp.fallidos, camp.omitidos = filas.get("enviado", 0), filas.get("fallido", 0), filas.get("omitido", 0)


def procesar(conexion=None) -> dict:
    """Una pasada: manda lo que permita el tope por hora de las campañas en curso (las más viejas primero)."""
    if not _proc.acquire(blocking=False):
        return {"omitido": "otra pasada en curso"}
    try:
        cfg_d = leer_config()
        with Session(engine) as s:
            activas = s.exec(select(PubCampana).where(PubCampana.estado == "enviando").order_by(PubCampana.id)).all()
            if not activas:
                return {"enviados": 0}
            smtp = config_smtp(cfg_d)
            if not smtp:
                for c in activas:
                    c.ultimo_error = "No hay correo de salida configurado para publicidad"
                    s.add(c)
                s.commit()
                return {"enviados": 0, "error": "sin correo de salida"}
            cupo = min(MAX_POR_PASADA, max(0, int(cfg_d.get("por_hora") or 100) - _enviados_ultima_hora(s)))
            if not cupo:
                return {"enviados": 0, "espera": "tope por hora"}
            ids = [c.id for c in activas]
            lote = s.exec(select(PubEnvio).where(PubEnvio.campana_id.in_(ids), PubEnvio.estado == "pendiente").order_by(PubEnvio.campana_id, PubEnvio.id).limit(cupo)).all()
            camps = {c.id: c for c in activas}
            contenido = {c.id: c.model_dump() for c in activas}      # copia antes del primer commit (después los objetos quedan vacíos)
            pie = _pie(cfg_d)
            enviados = fallidos = 0
            try:
                cx = conexion or _correo._conectar(smtp, 20)
            except Exception as ex:  # noqa: BLE001
                err = str(_correo._error_claro(smtp, ex))[:300]
                for c in activas:
                    c.ultimo_error = err
                    s.add(c)
                s.commit()
                return {"enviados": 0, "error": err}
            try:
                for env in lote:
                    r = s.connection().execute(_sql("UPDATE pubenvio SET estado='enviando' WHERE id=:i AND estado='pendiente'"), {"i": env.id})
                    s.commit()
                    if r.rowcount != 1:
                        continue                                   # otro proceso lo tomó
                    s.refresh(env)
                    cont = s.get(PubContacto, env.contacto_id)
                    if not cont or cont.estado != "activo":
                        env.estado, env.error = "omitido", "dado de baja" if cont and cont.estado == "baja" else "contacto no disponible"
                        s.add(env); s.commit()
                        continue
                    camp = camps[env.campana_id]
                    url_baja = f"{_base()}/p/baja/{token_baja(cont.id)}"
                    asunto, html, texto = armar(contenido[env.campana_id], cont, url_baja, pie)
                    try:
                        cx.send_message(_mensaje(smtp, cont.correo, asunto, html, texto, url_baja), to_addrs=[cont.correo])
                        env.estado, env.enviado_en, env.error = "enviado", _ahora(), None
                        enviados += 1
                    except (smtplib.SMTPServerDisconnected, socket.timeout, TimeoutError, ConnectionError) as ex:
                        env.estado = "pendiente"                   # se cayó la conexión: se reintenta en la próxima pasada
                        camp.ultimo_error = str(_correo._error_claro(smtp, ex))[:300]
                        s.add(env); s.add(camp); s.commit()
                        break
                    except Exception as ex:  # noqa: BLE001  rechazo de ese destinatario
                        env.estado, env.enviado_en, env.error = "fallido", _ahora(), str(_correo._error_claro(smtp, ex))[:300]
                        fallidos += 1
                        if isinstance(ex, smtplib.SMTPRecipientsRefused):
                            cont.estado = "rebotado"
                            s.add(cont)
                    s.add(env); s.commit()
            finally:
                if conexion is None:
                    try:
                        cx.quit()
                    except Exception:  # noqa: BLE001
                        pass
            for c in activas:
                if enviados:
                    c.ultimo_error = None if not fallidos else c.ultimo_error
                s.add(c)
            s.commit()
            _cerrar_terminadas(s)
            return {"enviados": enviados, "fallidos": fallidos}
    finally:
        _proc.release()


def procesar_seguro():
    try:
        procesar()
    except Exception:  # noqa: BLE001
        log.exception("Publicidad: fallo en la pasada")


# ----------------------------------------------------------------------------------------------------- alta de contactos
def agregar(s: Session, correo: str, nombre=None, empresa=None, etiquetas=None, origen="manual", permiso="relacion", reactivar=False) -> str:
    """'nuevo' | 'actualizado' | 'existe' | 'baja' (no se reactiva a quien se dio de baja, salvo que lo pida él mismo)."""
    correo = (correo or "").strip().lower()
    if not RE_CORREO.fullmatch(correo) or len(correo) > 150:
        return "invalido"
    c = s.exec(select(PubContacto).where(PubContacto.correo == correo)).first()
    if c:
        if c.estado == "baja" and not reactivar:
            return "baja"
        cambio = False
        if nombre and not c.nombre:
            c.nombre, cambio = _txt(nombre, 80), True
        if empresa and not c.empresa:
            c.empresa, cambio = _txt(empresa, 100), True
        if etiquetas:
            nuevas = _etiquetas(_lista_etiquetas(c.etiquetas) + _lista_etiquetas(_etiquetas(etiquetas)))
            if nuevas != c.etiquetas:
                c.etiquetas, cambio = nuevas, True
        if permiso == "expreso" and c.permiso != "expreso":
            c.permiso, cambio = "expreso", True
        if reactivar and c.estado != "activo":
            c.estado, c.baja_en, cambio = "activo", None, True
        if cambio:
            s.add(c)
        return "actualizado" if cambio else "existe"
    if s.exec(select(func.count()).select_from(PubContacto)).one() >= MAX_CONTACTOS:
        raise HTTPException(400, f"La lista llegó al máximo de {MAX_CONTACTOS} contactos")
    s.add(PubContacto(correo=correo, nombre=_txt(nombre, 80) or None, empresa=_txt(empresa, 100) or None, etiquetas=_etiquetas(etiquetas),
                      origen=origen, permiso=permiso if permiso in PERMISOS else "relacion"))
    return "nuevo"


def desde_sitio(correo: str, nombre: str, empresa: Optional[str]):
    """Formulario del sitio con la casilla «Quiero recibir novedades» marcada: permiso expreso."""
    try:
        with Session(engine) as s:
            agregar(s, correo, nombre, empresa, "sitio", "sitio", "expreso", reactivar=True)
            s.commit()
    except Exception:  # noqa: BLE001
        log.exception("Publicidad: no se pudo agregar el contacto del sitio")


def _filas_import(texto: str) -> list[tuple[str, str, str]]:
    """Cada línea: correo[,nombre[,empresa]] en cualquier orden (CSV con ; o ,), o un texto cualquiera con correos sueltos."""
    out = []
    for linea in (texto or "").splitlines():
        correos = RE_CORREO.findall(linea)
        if len(correos) == 1:                      # una fila de CSV: lo que no es correo es nombre y empresa, en ese orden
            partes = [p.strip().strip('"').strip() for p in re.split(r"[;,\t]", linea)]
            resto = [p for p in partes if p and "@" not in p]
            out.append((correos[0], resto[0] if resto else "", resto[1] if len(resto) > 1 else ""))
        else:                                      # texto con varios correos sueltos
            out.extend((m, "", "") for m in correos)
    return out


# ----------------------------------------------------------------------------------------------------- API de la consola
class ContactoIn(BaseModel):
    correo: str = PField(max_length=150)
    nombre: Optional[str] = PField(None, max_length=80)
    empresa: Optional[str] = PField(None, max_length=100)
    etiquetas: Optional[str] = PField(None, max_length=400)
    permiso: str = "relacion"
    estado: Optional[str] = None
    nota: Optional[str] = PField(None, max_length=300)


class ImportarIn(BaseModel):
    texto: str = PField(max_length=2_000_000)
    etiquetas: Optional[str] = PField(None, max_length=400)
    permiso: str = "relacion"


class CampanaIn(BaseModel):
    nombre: str = PField(min_length=1, max_length=120)
    asunto: str = PField(min_length=1, max_length=200)
    titulo: Optional[str] = PField(None, max_length=200)
    antetitulo: Optional[str] = PField(None, max_length=80)
    preencabezado: Optional[str] = PField(None, max_length=200)
    tema: Optional[str] = PField("fisitaap", max_length=20)
    cuerpo: str = PField("", max_length=20000)
    imagen_url: Optional[str] = PField(None, max_length=500)
    boton_texto: Optional[str] = PField(None, max_length=60)
    boton_url: Optional[str] = PField(None, max_length=500)
    etiquetas: Optional[str] = PField(None, max_length=400)


def _auditar(s: Session, accion: str, detalle: str, a: Usuario, request: Optional[Request] = None):
    from .auth import auditar
    auditar(s, accion, detalle[:500], a, None, request)


def _publico(s: Session, etiquetas: Optional[str]) -> list[PubContacto]:
    activos = s.exec(select(PubContacto).where(PubContacto.estado == "activo").order_by(PubContacto.id)).all()
    quiere = set(_lista_etiquetas(_etiquetas(etiquetas)))
    return [c for c in activos if not quiere or quiere & set(_lista_etiquetas(c.etiquetas))]


@router.get("/api/admin/publicidad/resumen")
def resumen(_: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    por_estado = dict(s.exec(select(PubContacto.estado, func.count()).group_by(PubContacto.estado)).all())
    etiquetas: dict[str, int] = {}
    for et in s.exec(select(PubContacto.etiquetas).where(PubContacto.estado == "activo")).all():
        for t in _lista_etiquetas(et):
            etiquetas[t] = etiquetas.get(t, 0) + 1
    return {"activos": por_estado.get("activo", 0), "bajas": por_estado.get("baja", 0), "rebotados": por_estado.get("rebotado", 0),
            "etiquetas": sorted(etiquetas.items(), key=lambda x: (-x[1], x[0])), "ultima_hora": _enviados_ultima_hora(s), "config": _resumen_config()}


@router.get("/api/admin/publicidad/contactos")
def contactos(_: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    return s.exec(select(PubContacto).order_by(PubContacto.id.desc()).limit(MAX_CONTACTOS)).all()


@router.post("/api/admin/publicidad/contactos")
def crear_contacto(data: ContactoIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    r = agregar(s, data.correo, data.nombre, data.empresa, data.etiquetas, "manual", data.permiso)
    if r == "invalido":
        raise HTTPException(400, "Revise el correo: " + data.correo[:80])
    if r == "baja":
        raise HTTPException(400, "Ese correo se dio de baja. Solo se reactiva si la persona lo vuelve a pedir (ábralo y cambie el estado).")
    s.commit()
    _auditar(s, "publicidad_contacto", f"Contacto {data.correo.strip().lower()} ({r})", a, request)
    return {"resultado": r}


@router.put("/api/admin/publicidad/contactos/{cid}")
def editar_contacto(cid: int, data: ContactoIn, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubContacto, cid)
    if not c:
        raise HTTPException(404, "Contacto no encontrado")
    correo = data.correo.strip().lower()
    if not RE_CORREO.fullmatch(correo):
        raise HTTPException(400, "Revise el correo")
    if correo != c.correo and s.exec(select(PubContacto).where(PubContacto.correo == correo)).first():
        raise HTTPException(400, "Ya hay otro contacto con ese correo")
    c.correo, c.nombre, c.empresa = correo, _txt(data.nombre, 80) or None, _txt(data.empresa, 100) or None
    c.etiquetas, c.nota = _etiquetas(data.etiquetas), _txt(data.nota, 300) or None
    c.permiso = data.permiso if data.permiso in PERMISOS else c.permiso
    if data.estado in ("activo", "baja") and data.estado != c.estado:
        c.estado, c.baja_en = data.estado, (_ahora() if data.estado == "baja" else None)
    s.add(c); s.commit(); s.refresh(c)
    return c


@router.delete("/api/admin/publicidad/contactos/{cid}")
def borrar_contacto(cid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubContacto, cid)
    if not c:
        raise HTTPException(404, "Contacto no encontrado")
    s.exec(_sql("UPDATE pubenvio SET estado='omitido', error='contacto borrado' WHERE contacto_id=:c AND estado='pendiente'").bindparams(c=cid))
    s.delete(c); s.commit()
    _auditar(s, "publicidad_contacto_borrado", f"Contacto {c.correo} borrado", a, request)
    return {"ok": True}


@router.post("/api/admin/publicidad/contactos/importar")
def importar(data: ImportarIn, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    if data.permiso not in PERMISOS:
        raise HTTPException(400, "Indique cómo obtuvo estos correos")
    filas = _filas_import(data.texto)
    if not filas:
        raise HTTPException(400, "No se encontró ningún correo en lo que pegó")
    cuenta: dict[str, int] = {}
    for correo, nombre, empresa in filas[:MAX_CONTACTOS]:
        r = agregar(s, correo, nombre, empresa, data.etiquetas, "importado", data.permiso)
        cuenta[r] = cuenta.get(r, 0) + 1
    s.commit()
    _auditar(s, "publicidad_importar", f"Importación: {cuenta}", a, request)
    return cuenta


@router.post("/api/admin/publicidad/contactos/importar-sitio")
def importar_sitio(request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Personas que escribieron por el formulario del sitio: «prospectos». Las que marcaron la casilla, con permiso expreso."""
    from .sitio import SolicitudContacto
    cuenta: dict[str, int] = {}
    for sol in s.exec(select(SolicitudContacto)).all():
        r = agregar(s, sol.correo, sol.nombre, sol.empresa, "prospectos", "sitio", "expreso" if getattr(sol, "acepta_novedades", False) else "relacion")
        cuenta[r] = cuenta.get(r, 0) + 1
    s.commit()
    _auditar(s, "publicidad_importar", f"Desde solicitudes del sitio: {cuenta}", a, request)
    return cuenta


@router.post("/api/admin/publicidad/contactos/importar-clientes")
def importar_clientes(request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    """Administradores de las empresas que usan el sistema (sin empresas de demostración): etiqueta «clientes» o «pruebas»."""
    from .auth import UsuarioEmpresa
    from .db import Empresa
    cuenta: dict[str, int] = {}
    for m in s.exec(select(UsuarioEmpresa).where(UsuarioEmpresa.rol == "Administrador")).all():
        u, e = s.get(Usuario, m.usuario_id), s.get(Empresa, m.empresa_id)
        if not u or not e or u.es_superadmin or getattr(e, "es_demo", False) or u.correo.endswith(".test"):
            continue
        r = agregar(s, u.correo, u.nombre, e.nombre_comercial or e.nombre, "pruebas" if getattr(e, "prueba_hasta", None) else "clientes", "plataforma", "relacion")
        cuenta[r] = cuenta.get(r, 0) + 1
    s.commit()
    _auditar(s, "publicidad_importar", f"Desde empresas clientes: {cuenta}", a, request)
    return cuenta


@router.get("/api/admin/publicidad/config")
def ver_config(_: Usuario = Depends(superadmin)):
    return _resumen_config()


@router.put("/api/admin/publicidad/config")
def guardar_config(data: dict, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    cfg = leer_config()
    data = data or {}
    cfg["usar_sistema"] = bool(data.get("usar_sistema"))
    try:
        cfg["por_hora"] = max(10, min(1000, int(data.get("por_hora") or 100)))
    except (TypeError, ValueError):
        raise HTTPException(400, "El tope por hora debe ser un número")
    cfg["pie"] = _txt(data.get("pie"), 300) or DEFECTO["pie"]
    m = dict(cfg.get("smtp") or {})
    d = data.get("smtp") or {}
    for k, n in (("host", 120), ("usuario", 150), ("remitente", 150), ("nombre", 80), ("responder_a", 150)):
        m[k] = _txt(d.get(k), n)
    for k in ("remitente", "responder_a"):
        if m[k] and not RE_CORREO.fullmatch(m[k].lower()):
            raise HTTPException(400, f"Revise el correo: {m[k]}")
    m["seguridad"] = d.get("seguridad") if d.get("seguridad") in ("ssl", "starttls", "ninguna") else "ssl"
    try:
        m["puerto"] = int(d.get("puerto") or (465 if m["seguridad"] == "ssl" else 587))
    except (TypeError, ValueError):
        raise HTTPException(400, "Revise el puerto")
    clave = str(d.get("password") or "")
    if clave:
        m["password"] = secretos._maestra.encrypt(clave[:200].encode()).decode()
    cfg["smtp"] = m
    if not cfg["usar_sistema"] and not (m.get("host") and m.get("remitente")):
        raise HTTPException(400, "Complete el servidor y el remitente de la cuenta de publicidad, o use el correo del sistema")
    cfg["actualizado"] = ahora_cr().isoformat(timespec="seconds")
    _guardar_config(cfg)
    _auditar(s, "publicidad_config", "Correo de salida: " + ("el del sistema" if cfg["usar_sistema"] else m["remitente"]) + f"; tope {cfg['por_hora']}/hora", a, request)
    return _resumen_config()


@router.get("/api/admin/publicidad/campanas")
def campanas(_: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    out = []
    for c in s.exec(select(PubCampana).order_by(PubCampana.id.desc())).all():
        if c.estado in ("enviando", "pausada"):
            _contar(s, c)
        out.append(c.model_dump() | {"pendientes": max(0, c.total - c.enviados - c.fallidos - c.omitidos) if c.estado in ("enviando", "pausada") else 0})
    return out


def _validar_campana(data: CampanaIn) -> dict:
    d = data.model_dump()
    d["imagen_url"], d["boton_url"] = _url_ok(d.get("imagen_url")), _url_ok(d.get("boton_url"))
    if (d.get("boton_texto") or "").strip() and not d["boton_url"]:
        raise HTTPException(400, "El botón necesita una dirección (https://…)")
    d["etiquetas"] = _etiquetas(d.get("etiquetas"))
    d["nombre"], d["asunto"], d["titulo"] = _txt(d["nombre"], 120), _txt(d["asunto"], 200), _txt(d.get("titulo"), 200) or None
    d["boton_texto"] = _txt(d.get("boton_texto"), 60) or None
    d["antetitulo"], d["preencabezado"] = _txt(d.get("antetitulo"), 80) or None, _txt(d.get("preencabezado"), 200) or None
    d["tema"] = d.get("tema") if d.get("tema") in _diseno.TEMAS else "fisitaap"
    return d


@router.post("/api/admin/publicidad/campanas")
def crear_campana(data: CampanaIn, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = PubCampana(**_validar_campana(data))
    s.add(c); s.commit(); s.refresh(c)
    return c


@router.put("/api/admin/publicidad/campanas/{cid}")
def editar_campana(cid: int, data: CampanaIn, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubCampana, cid)
    if not c:
        raise HTTPException(404, "Campaña no encontrada")
    if c.estado != "borrador":
        raise HTTPException(400, "Esta campaña ya se envió. Duplíquela para hacer otra parecida.")
    for k, v in _validar_campana(data).items():
        setattr(c, k, v)
    s.add(c); s.commit(); s.refresh(c)
    return c


@router.post("/api/admin/publicidad/campanas/{cid}/duplicar")
def duplicar(cid: int, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubCampana, cid)
    if not c:
        raise HTTPException(404, "Campaña no encontrada")
    n = PubCampana(nombre=_txt(c.nombre + " (copia)", 120), asunto=c.asunto, titulo=c.titulo, cuerpo=c.cuerpo, imagen_url=c.imagen_url,
                   boton_texto=c.boton_texto, boton_url=c.boton_url, etiquetas=c.etiquetas, antetitulo=c.antetitulo,
                   preencabezado=c.preencabezado, tema=c.tema or "fisitaap")
    s.add(n); s.commit(); s.refresh(n)
    return n


@router.delete("/api/admin/publicidad/campanas/{cid}")
def borrar_campana(cid: int, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubCampana, cid)
    if not c:
        raise HTTPException(404, "Campaña no encontrada")
    if c.estado in ("enviando", "pausada"):
        raise HTTPException(400, "Cancele primero el envío")
    s.exec(_sql("DELETE FROM pubenvio WHERE campana_id=:c").bindparams(c=cid))
    s.delete(c); s.commit()
    return {"ok": True}


@router.get("/api/admin/publicidad/plantillas")
def plantillas(_: Usuario = Depends(superadmin)):
    """Las 10 plantillas listas para editar (3.40), con la dirección del sitio y el WhatsApp de ventas ya puestos."""
    from .publicidad_plantillas import PLANTILLAS
    from . import sitio
    wa = re.sub(r"\D", "", str((sitio.leer().get("contacto") or {}).get("whatsapp") or ""))
    wa_url = f"https://wa.me/506{wa}" if len(wa) == 8 else (f"https://wa.me/{wa}" if wa else _base() + "/prueba-gratis")
    def poner(v):
        return v.replace("{sitio}", _base()).replace("{whatsapp}", wa_url) if isinstance(v, str) else v
    return {"plantillas": [{k: poner(v) for k, v in p.items()} for p in PLANTILLAS],
            "temas": [{"id": k, "nombre": t["nombre"], "color": t["acento"], "oscuro": t["oscuro"]} for k, t in _diseno.TEMAS.items()]}


@router.post("/api/admin/publicidad/vista-previa")
def vista_previa(data: CampanaIn, _: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    d = _validar_campana(data)
    ejemplo = s.exec(select(PubContacto).where(PubContacto.estado == "activo", PubContacto.nombre != None).limit(1)).first()  # noqa: E711
    asunto, html, _t = armar(d, ejemplo or PubContacto(correo="ejemplo@example.test", nombre="María", empresa="Su empresa"),
                             f"{_base()}/p/baja/ejemplo", _pie(leer_config()))
    from . import correo_diseno as _dz
    return {"asunto": asunto, "html": _dz.para_navegador(html), "publico": len(_publico(s, d["etiquetas"]))}   # 3.83: el logo se ve en la vista previa


class PruebaIn(CampanaIn):
    para: str = PField(max_length=150)


@router.post("/api/admin/publicidad/prueba")
def enviar_prueba(data: PruebaIn, a: Usuario = Depends(superadmin)):
    para = data.para.strip().lower()
    if not RE_CORREO.fullmatch(para):
        raise HTTPException(400, "Revise el correo de prueba")
    cfg = config_smtp()
    if not cfg:
        raise HTTPException(400, "Configure primero el correo de salida (pestaña Configuración)")
    d = _validar_campana(data)
    url = f"{_base()}/p/baja/prueba"
    asunto, html, texto = armar(d, PubContacto(correo=para, nombre=a.nombre, empresa=""), url, _pie(leer_config()))
    try:
        with _correo._conectar(cfg, 20) as cx:
            cx.send_message(_mensaje(cfg, para, "[PRUEBA] " + asunto, html, texto, url), to_addrs=[para])
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(502, str(_correo._error_claro(cfg, ex)))
    return {"ok": True}


@router.post("/api/admin/publicidad/campanas/{cid}/enviar")
def enviar(cid: int, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubCampana, cid)
    if not c:
        raise HTTPException(404, "Campaña no encontrada")
    if c.estado != "borrador":
        raise HTTPException(400, "Esta campaña ya se envió")
    if not config_smtp():
        raise HTTPException(400, "Configure primero el correo de salida (pestaña Configuración)")
    publico = _publico(s, c.etiquetas)
    if not publico:
        raise HTTPException(400, "No hay contactos activos en el público elegido")
    for x in publico:
        s.add(PubEnvio(campana_id=c.id, contacto_id=x.id, correo=x.correo))
    c.estado, c.total, c.iniciada, c.ultimo_error = "enviando", len(publico), _ahora(), None
    s.add(c); s.commit()
    _auditar(s, "publicidad_enviar", f"Campaña «{c.nombre}» a {len(publico)} contacto(s)" + (f" con etiquetas {c.etiquetas}" if c.etiquetas else ""), a, request)
    threading.Thread(target=procesar_seguro, daemon=True).start()
    return {"total": len(publico), "por_hora": int(leer_config().get("por_hora") or 100)}


@router.post("/api/admin/publicidad/campanas/{cid}/{accion}")
def cambiar_estado(cid: int, accion: str, request: Request, a: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    c = s.get(PubCampana, cid)
    if not c:
        raise HTTPException(404, "Campaña no encontrada")
    if accion == "pausar" and c.estado == "enviando":
        c.estado = "pausada"
    elif accion == "reanudar" and c.estado == "pausada":
        c.estado = "enviando"
    elif accion == "cancelar" and c.estado in ("enviando", "pausada"):
        s.exec(_sql("UPDATE pubenvio SET estado='omitido', error='campaña cancelada' WHERE campana_id=:c AND estado='pendiente'").bindparams(c=cid))
        c.estado, c.terminada = "cancelada", _ahora()
    else:
        raise HTTPException(400, "Acción no disponible en el estado actual")
    _contar(s, c)
    s.add(c); s.commit(); s.refresh(c)
    out = c.model_dump()
    _auditar(s, "publicidad_" + accion, f"Campaña «{c.nombre}»", a, request)
    if accion == "reanudar":
        threading.Thread(target=procesar_seguro, daemon=True).start()
    return out


@router.post("/api/admin/publicidad/procesar")
def procesar_ahora(_: Usuario = Depends(superadmin)):
    return procesar()


@router.get("/api/admin/publicidad/campanas/{cid}/envios")
def envios(cid: int, _: Usuario = Depends(superadmin), s: Session = Depends(get_session)):
    return s.exec(select(PubEnvio).where(PubEnvio.campana_id == cid).order_by(PubEnvio.id)).all()


# ----------------------------------------------------------------------------------------------------- baja pública
def _pagina(titulo: str, cuerpo: str) -> HTMLResponse:
    return HTMLResponse(
        '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<meta name="robots" content="noindex"><title>{_html.escape(titulo)} · {_html.escape(nombre_sistema())}</title>'
        '<style>body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f3f5f4;color:#1f2a27}main{max-width:460px;margin:60px auto;'
        'background:#fff;border-radius:10px;padding:28px 26px;box-shadow:0 1px 3px rgba(0,0,0,.08)}h1{font-size:21px;margin:0 0 12px;color:#0f3d36}'
        'button{background:#0f766e;color:#fff;border:0;border-radius:8px;padding:12px 20px;font-size:15px;cursor:pointer}p{line-height:1.5}'
        'a{color:#0f766e}</style></head><body><main>' + f'<h1>{_html.escape(titulo)}</h1>{cuerpo}</main></body></html>')


@router.get("/p/baja/{token}", include_in_schema=False)
def ver_baja(token: str, s: Session = Depends(get_session)):
    cid = _cid_de_token(token)
    c = s.get(PubContacto, cid) if cid else None
    if not c:
        return _pagina("Enlace no válido", "<p>Este enlace no es válido o ya no existe. Si quiere dejar de recibir nuestros correos, respóndanos y lo quitamos.</p>")
    if c.estado == "baja":
        return _pagina("Ya está dado de baja", f"<p>No le enviaremos más correos de publicidad a <b>{_html.escape(c.correo)}</b>.</p>")
    return _pagina("Darse de baja", f"<p>¿Quiere dejar de recibir correos de publicidad de {_html.escape(nombre_sistema())} en <b>{_html.escape(c.correo)}</b>?</p>"
                                    f'<form method="post" action="/p/baja/{_html.escape(token)}"><button type="submit">Sí, darme de baja</button></form>'
                                    "<p style=\"font-size:13px;color:#6b7a76\">Si usa nuestro sistema, los correos de sus facturas y de su cuenta siguen llegando.</p>")


@router.post("/p/baja/{token}", include_in_schema=False)
def baja(token: str, s: Session = Depends(get_session)):
    """Botón de la página o baja con un clic del programa de correo (List-Unsubscribe-Post)."""
    cid = _cid_de_token(token)
    c = s.get(PubContacto, cid) if cid else None
    if not c:
        return _pagina("Enlace no válido", "<p>Este enlace no es válido o ya no existe.</p>")
    if c.estado != "baja":
        c.estado, c.baja_en = "baja", _ahora()
        s.add(c)
        s.exec(_sql("UPDATE pubenvio SET estado='omitido', error='dado de baja' WHERE contacto_id=:c AND estado='pendiente'").bindparams(c=c.id))
        s.commit()
    return _pagina("Listo, se dio de baja", f"<p>No le enviaremos más correos de publicidad a <b>{_html.escape(c.correo)}</b>. Disculpe la molestia.</p>")
