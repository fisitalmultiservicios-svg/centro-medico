"""TiKe · contratos, equipos y facturación desde el ticket (3.53, fase 7).

- Contratos de soporte por cliente: bolsa de horas o cantidad de visitas por periodo (mensual o anual), tarifa por hora y por
  visita fuera de contrato, cuota fija (se factura sola con una factura recurrente del sistema), vigencia y renovación. Cada
  entrada de tiempo de un ticket con contrato descuenta de la bolsa; el consumo se ve por periodo y avisa cuando queda poco.
- Equipos del cliente: inventario (tipo, marca, modelo, serie, ubicación, garantía) con historial de tickets y un código QR para
  pegar en el equipo: al escanearlo se abre el portal con el equipo ya elegido.
- Facturar desde el ticket: las horas fuera de contrato y los repuestos (ítems del inventario) pasan a un borrador de factura o
  tiquete con un clic; el borrador se abre en el formulario de ventas para revisarlo y emitirlo.
- Reportes: tiempo por técnico, cumplimiento del SLA, tickets por cliente y categoría, horas por contrato y calificación."""
import io
import json
import logging
import secrets
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field as PField
from sqlalchemy import text
from sqlmodel import Field, Session, SQLModel, select

from . import modulos
from .auth import Contexto, sesion_empresa
from .config import ahora_cr
from .db import Cliente, Documento, Producto, por_empresa, sesion_de   # 4.5: Documento, para liberar lo cobrado al anular la factura del ticket
from .tike import ABIERTOS, NOMBRES_ESTADO, Ticket, TicketEntrada, TikeConfig, _config, _registrar, _salida, _ticket, admin

log = logging.getLogger(__name__)
router = APIRouter(tags=["tike"])

TIPOS_CONTRATO = ("horas", "visitas", "ilimitado")
NOMBRES_TIPO_CONTRATO = {"horas": "Bolsa de horas", "visitas": "Visitas", "ilimitado": "Ilimitado"}
PERIODOS = ("mensual", "anual")
TIPOS_EQUIPO = ["Computadora", "Portátil", "Servidor", "Impresora", "Router", "Switch", "Cámara", "Teléfono", "UPS", "Otro"]


# ------------------------------------------------------------------------------------------------- tablas
class Contrato(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cliente_id: int = Field(index=True)
    cliente_nombre: str = ""
    nombre: str = ""
    tipo: str = "horas"                           # horas | visitas | ilimitado
    cantidad: float = 0                           # horas o visitas incluidas por periodo
    periodo: str = "mensual"
    tarifa_hora: float = 0                        # fuera de contrato (sin IVA)
    tarifa_visita: float = 0
    cuota: float = 0                              # cuota fija por periodo (sin IVA); 0 = no se factura sola
    producto_id: Optional[int] = None             # ítem de inventario con que se factura la cuota
    recurrente_id: Optional[int] = None           # factura recurrente que cobra la cuota
    dia_cobro: int = 1
    inicio: str = ""
    fin: Optional[str] = None
    renovacion_auto: bool = True
    notas: str = ""
    activo: bool = True
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class Equipo(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cliente_id: int = Field(index=True)
    codigo: str = ""                              # EQ-0001
    token: str = Field(index=True)                # para el QR
    nombre: str
    tipo: str = "Computadora"
    marca: str = ""
    modelo: str = ""
    serie: str = ""
    ubicacion: str = ""
    fecha_compra: Optional[str] = None
    garantia_hasta: Optional[str] = None
    notas: str = ""
    activo: bool = True
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class TicketItem(SQLModel, table=True):
    """Repuesto o material usado en un ticket; se factura desde el ticket."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    ticket_id: int = Field(index=True)
    producto_id: Optional[int] = None
    detalle: str = ""
    cantidad: float = 1
    precio_unitario: float = 0                    # sin IVA
    facturado: bool = False
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


por_empresa(Contrato, Equipo, TicketItem)


class TicketCobro(SQLModel, table=True):
    """3.87: lo que ya pasó de un ticket a un borrador de factura: minutos de horas y repuestos. Con esto la previa y «Facturar desde el
    ticket» no vuelven a cobrar la misma hora ni reparten el excedente de la bolsa una vez por ticket. Si el borrador se elimina sin
    emitirse, la fila se borra y todo vuelve a quedar por cobrar (al emitir, el borrador se va pero la fila queda)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    ticket_id: int = Field(index=True)
    contrato_id: Optional[int] = Field(default=None, index=True)   # contrato de horas con que se calculó; None = sin contrato
    periodo: str = ""                                               # «desde» del periodo del contrato (AAAA-MM-DD)
    minutos: int = 0                                                # horas cobradas, en minutos
    items: str = "[]"                                               # JSON [id de TicketItem] que pasaron al borrador
    borrador_id: Optional[int] = Field(default=None, index=True)
    documento_id: Optional[int] = None                              # 4.5: comprobante emitido desde ese borrador; al anularlo (directo, rechazo o nota de crédito por el total) la fila se libera
    borrador_marca: str = ""                                        # creación del borrador: un número que SQLite reutiliza no libera esto
    usuario: str = ""
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


por_empresa(TicketCobro)        # 3.87: engine_empresa la crea en las bases nuevas y en las que ya existían (create_all)


# ------------------------------------------------------------------------------------------------- contratos
def _periodo_actual(c: Contrato, hoy: Optional[date] = None) -> tuple[str, str]:
    """[desde, hasta) del periodo en curso del contrato, alineado a su fecha de inicio."""
    hoy = hoy or ahora_cr().date()
    try:
        ini = date.fromisoformat(c.inicio[:10])
    except (ValueError, TypeError):
        ini = hoy.replace(day=1)
    if c.periodo == "anual":
        a = hoy.year if (hoy.month, hoy.day) >= (ini.month, ini.day) else hoy.year - 1
        d = ini.replace(year=a)
        try:
            h = d.replace(year=a + 1)
        except ValueError:
            h = d + timedelta(days=365)
        return d.isoformat(), h.isoformat()
    dia = min(ini.day, 28)
    d = hoy.replace(day=dia) if hoy.day >= dia else (hoy.replace(day=1) - timedelta(days=1)).replace(day=dia)
    h = (d.replace(day=28) + timedelta(days=4)).replace(day=dia)
    return d.isoformat(), h.isoformat()


def consumo(s: Session, eid: int, c: Contrato) -> dict:
    desde, hasta = _periodo_actual(c)
    ts = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.contrato_id == c.id)).all()
    ids = [t.id for t in ts]
    minutos = 0; visitas = 0
    if ids:
        for x in s.exec(select(TicketEntrada).where(TicketEntrada.empresa_id == eid, TicketEntrada.ticket_id.in_(ids), TicketEntrada.creado >= desde, TicketEntrada.creado < hasta)).all():  # type: ignore[attr-defined]
            minutos += int(x.minutos or 0)
            if x.tipo == "visita":
                visitas += 1
    horas = round(minutos / 60, 2)
    usado = horas if c.tipo == "horas" else visitas if c.tipo == "visitas" else 0
    incluido = float(c.cantidad or 0) if c.tipo != "ilimitado" else None
    return {"desde": desde, "hasta": hasta, "minutos": minutos, "horas": horas, "visitas": visitas, "usado": usado, "incluido": incluido,
            "restante": None if incluido is None else round(max(0.0, incluido - usado), 2), "excedente": 0 if incluido is None else round(max(0.0, usado - incluido), 2),
            "tickets": len(ts), "alerta": incluido is not None and incluido > 0 and usado >= incluido * 0.8}


def _salida_contrato(s: Session, eid: int, c: Contrato, con_consumo: bool = True) -> dict:
    d = {k: getattr(c, k) for k in ("id", "cliente_id", "cliente_nombre", "nombre", "tipo", "cantidad", "periodo", "tarifa_hora", "tarifa_visita", "cuota", "producto_id", "recurrente_id", "dia_cobro", "inicio", "fin", "renovacion_auto", "notas", "activo", "creado")}
    d["tipo_nombre"] = NOMBRES_TIPO_CONTRATO.get(c.tipo, c.tipo)
    hoy = ahora_cr().date().isoformat()
    d["vigente"] = bool(c.activo and (not c.inicio or c.inicio <= hoy) and (not c.fin or c.fin >= hoy or c.renovacion_auto))
    if con_consumo:
        d["consumo"] = consumo(s, eid, c)
    return d


def _cobro_visible(ctx: Contexto, d: dict) -> dict:
    """3.87: tarifas y cuota son condiciones de cobro: las ve quien factura (o ve todo). El Técnico de soporte («sin facturación ni
    caja») ve el contrato, su vigencia y su consumo, y lo elige en el ticket, sin montos (antes recibía tarifas y cuotas)."""
    return d if (ctx.puede("facturar") or ctx.puede("ver_todo")) else {**d, "tarifa_hora": None, "tarifa_visita": None, "cuota": None}


def contrato_vigente(s: Session, eid: int, cliente_id: Optional[int]) -> Optional[Contrato]:
    if not cliente_id:
        return None
    hoy = ahora_cr().date().isoformat()
    for c in s.exec(select(Contrato).where(Contrato.empresa_id == eid, Contrato.cliente_id == cliente_id, Contrato.activo == True).order_by(Contrato.id.desc())).all():  # noqa: E712
        if (not c.inicio or c.inicio <= hoy) and (not c.fin or c.fin >= hoy or c.renovacion_auto):
            return c
    return None


class ContratoIn(BaseModel):
    cliente_id: int
    nombre: Optional[str] = PField("", max_length=80)
    tipo: str = "horas"
    cantidad: float = PField(0, ge=0, le=100000)
    periodo: str = "mensual"
    tarifa_hora: float = PField(0, ge=0, le=1e7)
    tarifa_visita: float = PField(0, ge=0, le=1e7)
    cuota: float = PField(0, ge=0, le=1e8)
    producto_id: Optional[int] = None
    dia_cobro: int = PField(1, ge=1, le=28)
    inicio: str = PField(min_length=10, max_length=10)
    fin: Optional[str] = PField(None, max_length=10)
    renovacion_auto: bool = True
    notas: Optional[str] = PField("", max_length=600)
    activo: bool = True
    facturar_cuota: bool = True                   # crea/actualiza la factura recurrente de la cuota


def _linea_producto(p: Producto, cantidad: float, precio: Optional[float] = None, detalle: Optional[str] = None) -> dict:
    return {"producto_id": p.id, "detalle": detalle or p.nombre, "cabys": p.cabys, "cantidad": cantidad, "precio_unitario": float(precio if precio is not None else p.precio), "descuento": 0,
            "unidad_medida": p.unidad_medida or ("Sp" if p.es_servicio else "Unid"), "es_servicio": bool(p.es_servicio), "codigo_tarifa": p.codigo_tarifa or "08", "tarifa": float(p.tarifa or 0)}


def _recurrente_cuota(s: Session, eid: int, c: Contrato, cliente: Cliente, usuario: str) -> None:
    """Factura recurrente mensual/anual con la cuota del contrato (se crea, actualiza o apaga según el contrato)."""
    r = s.get(modulos.Recurrente, c.recurrente_id) if c.recurrente_id else None
    if r and r.empresa_id != eid:
        r = None
    if not (c.cuota and c.cuota > 0 and c.activo):
        if r:
            r.activa = False; s.add(r)
        return
    p = s.get(Producto, c.producto_id) if c.producto_id else None
    if p and p.empresa_id != eid:
        p = None
    if p:
        linea = _linea_producto(p, 1, c.cuota, f"{p.nombre} · contrato {c.nombre or NOMBRES_TIPO_CONTRATO.get(c.tipo, '')}".strip())
    else:
        linea = {"producto_id": None, "detalle": f"Contrato de soporte {c.nombre or NOMBRES_TIPO_CONTRATO.get(c.tipo, '')}".strip(), "cabys": "8313300000000", "cantidad": 1, "precio_unitario": float(c.cuota), "descuento": 0,
                 "unidad_medida": "Sp", "es_servicio": True, "codigo_tarifa": "08", "tarifa": 13.0}
    if not r:
        r = modulos.Recurrente(empresa_id=eid, nombre=f"Contrato de soporte · {cliente.nombre_comercial or cliente.nombre}"[:80], cliente_id=cliente.id, cliente_nombre=cliente.nombre, tipo_documento="01",
                               condicion_venta="01", medio_pago="01", moneda="CRC", periodicidad="mensual", dia_emision=1, inicio=c.inicio, lineas="[]", activa=True)
    r.cliente_id, r.cliente_nombre = cliente.id, cliente.nombre
    r.periodicidad = "anual" if c.periodo == "anual" else "mensual"; r.dia_emision = int(c.dia_cobro or 1); r.inicio = c.inicio; r.fin = c.fin; r.activa = True
    r.lineas = json.dumps([linea], ensure_ascii=False); r.observaciones = f"Cuota del contrato de soporte TiKe ({NOMBRES_TIPO_CONTRATO.get(c.tipo, c.tipo)})"; r.vendedor = usuario
    if c.periodo == "anual":
        try:
            r.mes_emision = int(c.inicio[5:7])
        except ValueError:
            pass
    s.add(r); s.commit(); s.refresh(r)
    c.recurrente_id = r.id


@router.get("/api/tike/contratos")
def listar_contratos(cliente_id: Optional[int] = None, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    q = select(Contrato).where(Contrato.empresa_id == eid)
    if cliente_id:
        q = q.where(Contrato.cliente_id == cliente_id)
    return [_cobro_visible(ctx, _salida_contrato(s, eid, c)) for c in s.exec(q.order_by(Contrato.activo.desc(), Contrato.id.desc())).all()]


def _guardar_contrato(s: Session, ctx: Contexto, c: Contrato, data: ContratoIn) -> Contrato:
    eid = ctx.empresa.id
    if data.tipo not in TIPOS_CONTRATO or data.periodo not in PERIODOS:
        raise HTTPException(400, "Tipo o periodo del contrato desconocido")
    cli = s.get(Cliente, data.cliente_id)
    if not cli or cli.empresa_id != eid:
        raise HTTPException(400, "El cliente indicado no existe")
    for f in (data.inicio, data.fin):
        if f:
            try:
                date.fromisoformat(f[:10])
            except ValueError:
                raise HTTPException(400, "Fechas con formato AAAA-MM-DD")
    if data.fin and data.fin < data.inicio:
        raise HTTPException(400, "La fecha final no puede ser antes del inicio")
    if data.tipo != "ilimitado" and data.cantidad <= 0:
        raise HTTPException(400, "Indique las horas o visitas incluidas por periodo")
    if data.producto_id:
        p = s.get(Producto, data.producto_id)
        if not p or p.empresa_id != eid:
            raise HTTPException(400, "El ítem para facturar la cuota no existe")
    for k in ("cliente_id", "tipo", "cantidad", "periodo", "tarifa_hora", "tarifa_visita", "cuota", "producto_id", "dia_cobro", "inicio", "fin", "renovacion_auto", "activo"):
        setattr(c, k, getattr(data, k))
    c.nombre = (data.nombre or "").strip()[:80]; c.notas = (data.notas or "").strip(); c.cliente_nombre = cli.nombre_comercial or cli.nombre
    if data.facturar_cuota:
        _recurrente_cuota(s, eid, c, cli, ctx.usuario.nombre)
    elif c.recurrente_id:
        r = s.get(modulos.Recurrente, c.recurrente_id)
        if r and r.empresa_id == eid:
            r.activa = False; s.add(r)
    s.add(c); s.commit(); s.refresh(c)
    return c


@router.post("/api/tike/contratos")
def nuevo_contrato(data: ContratoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    # 3.87: un contrato fija condiciones de cobro (cuota con factura recurrente, tarifas, vigencia): solo quien factura lo crea o
    # lo cambia. El Técnico de soporte («sin facturación ni caja») sigue viéndolos y eligiéndolos en el ticket.
    ctx.exigir("facturar")
    c = _guardar_contrato(s, ctx, Contrato(empresa_id=ctx.empresa.id, cliente_id=data.cliente_id, inicio=data.inicio), data)
    return _salida_contrato(s, ctx.empresa.id, c)


@router.put("/api/tike/contratos/{cid}")
def editar_contrato(cid: int, data: ContratoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar")                            # 3.87: ver nuevo_contrato
    c = s.get(Contrato, cid)
    if not c or c.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Contrato no encontrado")
    return _salida_contrato(s, ctx.empresa.id, _guardar_contrato(s, ctx, c, data))


@router.get("/api/tike/contratos/{cid}")
def ver_contrato(cid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; c = s.get(Contrato, cid)
    if not c or c.empresa_id != eid:
        raise HTTPException(404, "Contrato no encontrado")
    d = _cobro_visible(ctx, _salida_contrato(s, eid, c))
    d["tickets"] = [_salida(t) for t in s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.contrato_id == c.id).order_by(Ticket.id.desc())).all()[:200]]
    return d


# ------------------------------------------------------------------------------------------------- equipos
class EquipoIn(BaseModel):
    cliente_id: int
    nombre: str = PField(min_length=2, max_length=80)
    tipo: Optional[str] = PField("Computadora", max_length=30)
    marca: Optional[str] = PField("", max_length=60)
    modelo: Optional[str] = PField("", max_length=60)
    serie: Optional[str] = PField("", max_length=80)
    ubicacion: Optional[str] = PField("", max_length=120)
    fecha_compra: Optional[str] = PField(None, max_length=10)
    garantia_hasta: Optional[str] = PField(None, max_length=10)
    notas: Optional[str] = PField("", max_length=1000)
    activo: bool = True


def _salida_equipo(e: Equipo, tickets: Optional[list] = None) -> dict:
    hoy = ahora_cr().date().isoformat()
    d = {k: getattr(e, k) for k in ("id", "cliente_id", "codigo", "nombre", "tipo", "marca", "modelo", "serie", "ubicacion", "fecha_compra", "garantia_hasta", "notas", "activo", "creado")}
    d["garantia_vencida"] = bool(e.garantia_hasta and e.garantia_hasta < hoy)
    d["garantia_por_vencer"] = bool(e.garantia_hasta and hoy <= e.garantia_hasta <= (ahora_cr().date() + timedelta(days=30)).isoformat())
    if tickets is not None:
        d["tickets"] = tickets
    return d


def _equipo(s: Session, eid: int, qid: int) -> Equipo:
    e = s.get(Equipo, qid)
    if not e or e.empresa_id != eid:
        raise HTTPException(404, "Equipo no encontrado")
    return e


@router.get("/api/tike/equipos")
def listar_equipos(cliente_id: Optional[int] = None, q: Optional[str] = None, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    qy = select(Equipo).where(Equipo.empresa_id == eid)
    if cliente_id:
        qy = qy.where(Equipo.cliente_id == cliente_id)
    es = s.exec(qy.order_by(Equipo.id.desc())).all()
    if q:
        ql = q.lower()
        es = [e for e in es if any(ql in (getattr(e, k) or "").lower() for k in ("nombre", "codigo", "marca", "modelo", "serie", "ubicacion"))]
    abiertos: dict = {}
    for t in s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.equipo_id.isnot(None), Ticket.estado.in_(ABIERTOS))).all():  # type: ignore[union-attr,attr-defined]
        abiertos[t.equipo_id] = abiertos.get(t.equipo_id, 0) + 1
    return [{**_salida_equipo(e), "tickets_abiertos": abiertos.get(e.id, 0)} for e in es[:1000]]


def _guardar_equipo(s: Session, eid: int, e: Equipo, data: EquipoIn) -> Equipo:
    cli = s.get(Cliente, data.cliente_id)
    if not cli or cli.empresa_id != eid:
        raise HTTPException(400, "El cliente indicado no existe")
    for f in (data.fecha_compra, data.garantia_hasta):
        if f:
            try:
                date.fromisoformat(f[:10])
            except ValueError:
                raise HTTPException(400, "Fechas con formato AAAA-MM-DD")
    for k in ("cliente_id", "nombre", "tipo", "marca", "modelo", "serie", "ubicacion", "fecha_compra", "garantia_hasta", "notas", "activo"):
        v = getattr(data, k)
        setattr(e, k, v.strip() if isinstance(v, str) else v)
    if not e.codigo:
        u = s.exec(select(Equipo).where(Equipo.empresa_id == eid).order_by(Equipo.id.desc())).first()
        n = int((u.codigo or "EQ-0000").split("-")[-1]) + 1 if u and u.codigo else 1
        e.codigo = f"EQ-{n:04d}"
    s.add(e); s.commit(); s.refresh(e)
    return e


@router.post("/api/tike/equipos")
def nuevo_equipo(data: EquipoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return _salida_equipo(_guardar_equipo(s, ctx.empresa.id, Equipo(empresa_id=ctx.empresa.id, cliente_id=data.cliente_id, nombre=data.nombre, token=secrets.token_urlsafe(9)), data))


@router.put("/api/tike/equipos/{qid}")
def editar_equipo(qid: int, data: EquipoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    return _salida_equipo(_guardar_equipo(s, ctx.empresa.id, _equipo(s, ctx.empresa.id, qid), data))


@router.get("/api/tike/equipos/{qid}")
def ver_equipo(qid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; e = _equipo(s, eid, qid)
    ts = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.equipo_id == e.id).order_by(Ticket.id.desc())).all()
    return {**_salida_equipo(e, [_salida(t) for t in ts[:200]]), "qr_url": _url_qr(s, eid, e)}


def _url_qr(s: Session, eid: int, e: Equipo) -> str:
    from .sitio import base_url
    cfg = _config(s, eid)
    return f"{base_url()}/soporte/{cfg.slug}#eq={e.token}" if cfg.portal_activo and cfg.slug else f"{base_url()}/app#/tike/equipos/{e.id}"


@router.get("/api/tike/equipos/{qid}/qr.png", include_in_schema=False)
def qr_equipo(qid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    import qrcode
    e = _equipo(s, ctx.empresa.id, qid)
    buf = io.BytesIO(); qrcode.make(_url_qr(s, ctx.empresa.id, e)).save(buf, format="PNG")
    return Response(buf.getvalue(), media_type="image/png", headers={"Content-Disposition": f'inline; filename="{e.codigo or "equipo"}.png"'})


def equipo_por_token(s: Session, eid: int, token: str) -> Optional[Equipo]:
    e = s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.token == token)).first()
    return e if e and e.activo else None


# ------------------------------------------------------------------------------------------------- repuestos y facturar desde el ticket
class ItemIn(BaseModel):
    producto_id: Optional[int] = None
    detalle: Optional[str] = PField("", max_length=160)
    cantidad: float = PField(1, gt=0, le=100000)
    precio_unitario: Optional[float] = PField(None, ge=0, le=1e9)


def _salida_item(x: TicketItem) -> dict:
    return {"id": x.id, "producto_id": x.producto_id, "detalle": x.detalle, "cantidad": x.cantidad, "precio_unitario": x.precio_unitario, "total": round(x.cantidad * x.precio_unitario, 2), "facturado": x.facturado, "creado": x.creado}


@router.get("/api/tike/tickets/{tid}/items")
def listar_items(tid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    _ticket(s, ctx.empresa.id, tid)
    return [_salida_item(x) for x in s.exec(select(TicketItem).where(TicketItem.ticket_id == tid).order_by(TicketItem.id)).all()]


@router.post("/api/tike/tickets/{tid}/items")
def nuevo_item(tid: int, data: ItemIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; t = _ticket(s, eid, tid)
    if t.estado == "cerrado":
        raise HTTPException(400, "Un ticket cerrado no recibe repuestos")
    detalle = (data.detalle or "").strip(); precio = data.precio_unitario
    if data.producto_id:
        p = s.get(Producto, data.producto_id)
        if not p or p.empresa_id != eid:
            raise HTTPException(400, "El ítem indicado no existe")
        detalle = detalle or p.nombre
        if precio is None:
            precio = float(p.precio)
    if not detalle:
        raise HTTPException(400, "Indique el repuesto o elija un ítem del inventario")
    x = TicketItem(empresa_id=eid, ticket_id=tid, producto_id=data.producto_id, detalle=detalle[:160], cantidad=float(data.cantidad), precio_unitario=float(precio or 0))
    s.add(x); s.commit(); s.refresh(x)
    _registrar(s, t, "nota", f"Repuesto: {x.cantidad:g} × {x.detalle}", ctx.usuario.nombre)
    return _salida_item(x)


@router.delete("/api/tike/tickets/{tid}/items/{iid}")
def quitar_item(tid: int, iid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; _ticket(s, eid, tid); x = s.get(TicketItem, iid)
    if not x or x.ticket_id != tid:
        raise HTTPException(404, "Repuesto no encontrado")
    if x.facturado:
        raise HTTPException(400, "Ese repuesto ya se facturó")
    s.delete(x); s.commit()
    return {"ok": True}


def _h(minutos: int) -> str:
    return f"{round(minutos / 60, 2):g}"


def horas_facturables(s: Session, eid: int, t: Ticket) -> dict:
    """Horas del ticket que se cobran: todas si no hay contrato; con contrato de horas, solo lo que exceda la bolsa del periodo
    (contando lo ya consumido por otros tickets); con contrato de visitas o ilimitado, nada por horas.
    3.87: descuenta lo que ya pasó a un borrador (TicketCobro). Antes la previa volvía a ofrecer las horas ya facturadas y, con varios
    tickets en la misma bolsa, cada uno cobraba el excedente completo del periodo. Ahora: sin contrato, las horas del ticket menos las
    ya cobradas; con bolsa de horas, lo pendiente del ticket en el periodo sin pasar de lo que falta cobrar del excedente del contrato.
    «minutos» es lo mismo que «horas», exacto, para registrar lo cobrado sin redondeos.
    3.87: «cobrado_marca» resume lo ya cobrado del ticket (y del periodo del contrato): si cambia entre la previa y el envío, otra
    persona facturó mientras tanto (ver facturar_ticket)."""
    minutos = int(t.minutos or 0); c = s.get(Contrato, t.contrato_id) if t.contrato_id else None
    tarifa = float(c.tarifa_hora) if c and c.tarifa_hora else None
    ya_t = sum(int(x.minutos or 0) for x in s.exec(select(TicketCobro).where(TicketCobro.empresa_id == eid, TicketCobro.ticket_id == t.id)).all())
    base = {"tarifa": tarifa, "ya_horas": round(ya_t / 60, 2), "contrato_id": None, "periodo": "", "cobrado_marca": str(ya_t)}
    ya_txt = f"; ya se pasaron {_h(ya_t)} h de este ticket a borradores" if ya_t else ""
    if not c:
        pend = max(0, minutos - ya_t)
        return {**base, "horas": round(pend / 60, 2), "minutos": pend, "contrato": None, "motivo": "sin contrato: se cobran todas las horas" + ya_txt}
    nombre = c.nombre or NOMBRES_TIPO_CONTRATO.get(c.tipo, c.tipo)
    if c.tipo == "ilimitado":
        return {**base, "horas": 0, "minutos": 0, "contrato": nombre, "motivo": "contrato ilimitado: no se cobran horas"}
    if c.tipo == "visitas":
        cons = consumo(s, eid, c)
        return {**base, "horas": 0, "minutos": 0, "contrato": nombre, "visitas_excedentes": cons["excedente"], "tarifa_visita": float(c.tarifa_visita or 0), "motivo": "contrato por visitas: se cobran las visitas que excedan"}
    cons = consumo(s, eid, c); desde, hasta = cons["desde"], cons["hasta"]
    del_periodo = s.exec(select(TicketCobro).where(TicketCobro.empresa_id == eid, TicketCobro.contrato_id == c.id, TicketCobro.periodo == desde)).all()
    ya_c = sum(int(x.minutos or 0) for x in del_periodo)                                     # excedente ya cobrado por cualquier ticket del contrato
    ya_t_per = sum(int(x.minutos or 0) for x in del_periodo if x.ticket_id == t.id)
    min_t_per = sum(int(x.minutos or 0) for x in s.exec(select(TicketEntrada).where(TicketEntrada.empresa_id == eid, TicketEntrada.ticket_id == t.id,
                                                                                    TicketEntrada.creado >= desde, TicketEntrada.creado < hasta)).all())
    exced = max(0, int(cons["minutos"]) - int(round(float(c.cantidad or 0) * 60)))      # excedente del periodo, en minutos
    pend = max(0, min(exced - ya_c, min_t_per - ya_t_per, minutos - ya_t))
    return {**base, "horas": round(pend / 60, 2), "minutos": pend, "contrato": nombre, "contrato_id": c.id, "periodo": desde, "cobrado_marca": f"{ya_t}:{ya_c}",
            "motivo": f"bolsa de {cons['incluido']:g} h: usadas {cons['horas']:g}; se cobra solo el excedente" + (f" ({_h(exced)} h en el periodo, {_h(ya_c)} h ya pasaron a borradores)" if ya_c else "")}


class FacturarIn(BaseModel):
    tipo_documento: str = "01"                    # 01 factura | 04 tiquete
    incluir_horas: bool = True
    horas: Optional[float] = PField(None, ge=0, le=10000)     # vacío = las calculadas
    tarifa_hora: Optional[float] = PField(None, ge=0, le=1e7)
    incluir_items: bool = True
    condicion_venta: str = "01"
    plazo_credito: Optional[int] = PField(None, ge=0, le=365)
    cobrado_visto: Optional[str] = PField(None, max_length=40)    # 3.87: «cobrado_marca» de la previa que vio el usuario


@router.get("/api/tike/tickets/{tid}/facturar")
def previa_facturar(tid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar")            # 3.87: facturar desde el ticket es de quien factura (el Técnico de soporte creaba borradores)
    eid = ctx.empresa.id; t = _ticket(s, eid, tid); cfg = _config(s, eid)
    items = [x for x in s.exec(select(TicketItem).where(TicketItem.ticket_id == tid)).all() if not x.facturado]
    h = horas_facturables(s, eid, t)
    p = s.get(Producto, cfg.producto_horas_id) if getattr(cfg, "producto_horas_id", None) else None
    return {**h, "items": [_salida_item(x) for x in items], "producto_horas": {"id": p.id, "nombre": p.nombre, "precio": p.precio} if p else None, "cliente_id": t.cliente_id, "cliente_nombre": t.cliente_nombre,
            "tarifa_sugerida": h["tarifa"] if h.get("tarifa") else (float(p.precio) if p else None)}


@router.post("/api/tike/tickets/{tid}/facturar")
def facturar_ticket(tid: int, data: FacturarIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Arma un borrador de factura (o tiquete) con las horas fuera de contrato y los repuestos; se abre en Ventas para emitirlo."""
    from .main import ComprobanteIn, _exo_borrador, _total_borrador
    ctx.exigir("facturar")                            # 3.87: ver previa_facturar
    eid = ctx.empresa.id; t = _ticket(s, eid, tid); cfg = _config(s, eid)
    if data.tipo_documento not in ("01", "04"):
        raise HTTPException(400, "Solo factura (01) o tiquete (04)")
    if data.tipo_documento == "01" and not t.cliente_id:
        raise HTTPException(400, "Para facturar elija el cliente del catálogo en el ticket (o emita un tiquete)")
    # 3.87: se toma la escritura de la base ANTES de calcular lo pendiente: un doble clic o dos usuarios a la vez esperan su turno y el
    # segundo ya ve lo que cobró el primero (sin esto los dos calculaban la misma hora). Va con una sentencia UPDATE que siempre se
    # ejecuta: asignar el atributo no basta, porque si el ticket ya tenía la hora de este mismo segundo SQLAlchemy no manda nada y no
    # se toma el bloqueo. Después se relee el ticket (sus minutos pueden haber cambiado mientras se esperaba).
    s.execute(text(f"UPDATE {Ticket.__tablename__} SET actualizado = :a WHERE id = :i"), {"a": ahora_cr().isoformat(timespec="seconds"), "i": t.id})
    s.refresh(t)
    cliente = s.get(Cliente, t.cliente_id) if t.cliente_id else None
    lineas: list[dict] = []
    h: dict = {}; cobro_min = 0
    if data.incluir_horas:
        h = horas_facturables(s, eid, t)
        # 3.87: si mientras el diálogo estaba abierto otra persona pasó horas de este ticket (o de su bolsa) a un borrador, lo que se ve
        # ya no vale: se pide abrirlo de nuevo en vez de cobrar otra vez lo mismo. Pedir MÁS horas de las pendientes sí se permite (hora
        # mínima, tarifa fija, contrato por visitas): lo cobrado queda registrado y el max(0, …) de horas_facturables no lo ofrece de nuevo.
        if data.cobrado_visto is not None and data.cobrado_visto != h["cobrado_marca"]:
            raise HTTPException(409, "Mientras tanto se pasaron horas de este ticket (o de su contrato) a otro borrador: cierre y vuelva a abrir «Facturar desde el ticket» para ver lo que queda por cobrar")
        horas = float(data.horas) if data.horas is not None else float(h["horas"])
        p = s.get(Producto, cfg.producto_horas_id) if getattr(cfg, "producto_horas_id", None) else None
        if p and p.empresa_id != eid:
            p = None
        tarifa = data.tarifa_hora if data.tarifa_hora is not None else (h["tarifa"] if h.get("tarifa") else (float(p.precio) if p else None))
        if horas > 0:
            if tarifa is None:
                raise HTTPException(400, "Indique la tarifa por hora (en el contrato, en TiKe › Configuración con el ítem de horas, o aquí)")
            if p:
                lineas.append(_linea_producto(p, horas, tarifa, f"{p.nombre} · {t.codigo} {t.asunto}"[:160]))
            else:
                lineas.append({"producto_id": None, "detalle": f"Soporte técnico · {t.codigo} {t.asunto}"[:160], "cabys": "8313300000000", "cantidad": horas, "precio_unitario": float(tarifa), "descuento": 0, "unidad_medida": "Sp", "es_servicio": True, "codigo_tarifa": "08", "tarifa": 13.0})
            # 3.87: se registra lo que de verdad se cobró: lo pendiente exacto, menos (el resto sigue pendiente) o más (hora mínima, tarifa
            # fija, horas en un contrato por visitas: lo de más deja el pendiente en 0 y nada se cobra dos veces)
            cobro_min = int(h["minutos"]) if abs(horas - float(h["horas"])) < 0.005 else max(1, int(round(horas * 60)))
    items = []
    if data.incluir_items:
        items = [x for x in s.exec(select(TicketItem).where(TicketItem.ticket_id == tid)).all() if not x.facturado]
        for x in items:
            p = s.get(Producto, x.producto_id) if x.producto_id else None
            if p and p.empresa_id == eid:
                lineas.append(_linea_producto(p, x.cantidad, x.precio_unitario, x.detalle))
            else:
                lineas.append({"producto_id": None, "detalle": x.detalle, "cabys": "4524100000000", "cantidad": x.cantidad, "precio_unitario": x.precio_unitario, "descuento": 0, "unidad_medida": "Unid", "es_servicio": False, "codigo_tarifa": "08", "tarifa": 13.0})
    if not lineas:
        raise HTTPException(400, "No hay nada que facturar: ni horas fuera de contrato ni repuestos")
    comp = ComprobanteIn(tipo_documento=data.tipo_documento, cliente_id=t.cliente_id, condicion_venta=data.condicion_venta, plazo_credito=data.plazo_credito, medio_pago="01", moneda="CRC",
                         lineas=[{**l, "cantidad": Decimal(str(l["cantidad"])), "precio_unitario": Decimal(str(l["precio_unitario"])), "descuento": Decimal("0"), "tarifa": Decimal(str(l["tarifa"]))} for l in lineas],
                         observaciones=f"Ticket {t.codigo}: {t.asunto}"[:300], extra={"tike_ticket_id": t.id, "tike_codigo": t.codigo})
    b = modulos.Borrador(empresa_id=eid, tipo_documento=comp.tipo_documento, cliente_id=cliente.id if cliente else None, receptor_nombre=cliente.nombre if cliente else None, moneda="CRC",
                         total=_total_borrador(comp, _exo_borrador(s, eid, comp, cliente)), datos=comp.model_dump_json(), usuario=getattr(ctx.usuario, "correo", "") or ctx.usuario.nombre)
    s.add(b); s.flush()                               # 3.87: el número del borrador va en el registro de lo cobrado
    for x in items:
        x.facturado = True; s.add(x)
    if cobro_min or items:                            # 3.87: mismo commit que el borrador y los repuestos
        s.add(TicketCobro(empresa_id=eid, ticket_id=t.id, contrato_id=h.get("contrato_id") if cobro_min else None, periodo=(h.get("periodo") or "") if cobro_min else "",
                          minutos=cobro_min, items=json.dumps([x.id for x in items]), borrador_id=b.id, borrador_marca=_marca_borrador(b), usuario=ctx.usuario.nombre))
    s.commit(); s.refresh(b)
    _registrar(s, t, "sistema", f"Borrador de {'factura' if comp.tipo_documento == '01' else 'tiquete'} #{b.id} creado con {len(lineas)} línea(s) por ₡{float(b.total or 0):,.0f}"
               + (f" ({_h(cobro_min)} h)" if cobro_min else ""), ctx.usuario.nombre)
    return {"borrador_id": b.id, "total": b.total, "lineas": len(lineas), "ruta": f"/ventas/facturas/nueva?borrador={b.id}"}


def _marca_borrador(b) -> str:
    """3.87: fecha de creación del borrador como texto, sin zona (igual en memoria que leída de la base). SQLite puede darle el mismo
    número a un borrador nuevo cuando el anterior se emitió; la marca evita que eliminar el nuevo libere lo cobrado por el viejo."""
    c = getattr(b, "creado", None)
    return c.replace(tzinfo=None).isoformat() if hasattr(c, "tzinfo") else str(c or "")


def cobro_en_borrador(s: Session, eid: int, f: "TicketCobro") -> bool:
    """3.87: el borrador de este cobro sigue sin emitir (existe y es el mismo, no uno nuevo que recibió su número)."""
    b = s.get(modulos.Borrador, f.borrador_id) if f.borrador_id else None
    return bool(b and b.empresa_id == eid and _marca_borrador(b) == f.borrador_marca)


def liberar_borrador(s: Session, eid: int, b, usuario: str = "") -> int:
    """3.87: el borrador que salió de un ticket se eliminó sin emitir: sus horas y repuestos vuelven a quedar por cobrar y la bitácora
    del ticket lo dice. Al emitir, el borrador también se borra, pero por otro camino que no pasa por aquí (lo cobrado se queda).
    No confirma: lo hace quien elimina el borrador, en el mismo commit."""
    n = 0; marca = _marca_borrador(b)
    for f in s.exec(select(TicketCobro).where(TicketCobro.empresa_id == eid, TicketCobro.borrador_id == b.id)).all():
        if f.borrador_marca != marca:
            continue
        try:
            ids = [int(i) for i in json.loads(f.items or "[]")]
        except (TypeError, ValueError):
            ids = []
        repuestos = 0
        for iid in ids:
            x = s.get(TicketItem, iid)
            if x and x.ticket_id == f.ticket_id and x.facturado:
                x.facturado = False; s.add(x); repuestos += 1
        t = s.get(Ticket, f.ticket_id)
        if t and t.empresa_id == eid:
            partes = ([f"{_h(f.minutos)} h"] if f.minutos else []) + ([f"{repuestos} repuesto(s)"] if repuestos else [])
            s.add(TicketEntrada(empresa_id=eid, ticket_id=t.id, tipo="sistema", texto=f"Borrador #{b.id} eliminado sin emitir: " + (" y ".join(partes) or "nada") + " vuelven a quedar por cobrar",
                                usuario=usuario or "sistema"))
        s.delete(f); n += 1
    return n


def ligar_documento(s: Session, eid: int, b, documento_id: int) -> int:
    """4.5: el borrador que salió de un ticket se emitió: lo cobrado queda ligado al comprobante, para que anularlo lo devuelva
    (liberar_documento). Solo las filas de ese mismo borrador (marca), no las de uno viejo que recibió el mismo número. No confirma:
    va en el commit de crear_comprobante."""
    n = 0; marca = _marca_borrador(b)
    for f in s.exec(select(TicketCobro).where(TicketCobro.empresa_id == eid, TicketCobro.borrador_id == b.id)).all():
        if f.borrador_marca == marca:
            f.documento_id = documento_id; s.add(f); n += 1
    return n


def liberar_documento(s: Session, eid: int, d, usuario: str = "", motivo: str = "anulado") -> int:
    """4.5: la factura o tiquete emitido desde un ticket se anuló (anulación directa, rechazo de Hacienda o nota de crédito por el total):
    sus horas y repuestos vuelven a quedar por cobrar y la bitácora del ticket lo dice. Antes TicketCobro quedaba para siempre y el
    ticket no se podía volver a facturar. No confirma: lo hace quien cambia el estado del comprobante, en el mismo commit."""
    n = 0
    for f in s.exec(select(TicketCobro).where(TicketCobro.empresa_id == eid, TicketCobro.documento_id == d.id)).all():
        try:
            ids = [int(i) for i in json.loads(f.items or "[]")]
        except (TypeError, ValueError):
            ids = []
        repuestos = 0
        for iid in ids:
            x = s.get(TicketItem, iid)
            if x and x.ticket_id == f.ticket_id and x.facturado:
                x.facturado = False; s.add(x); repuestos += 1
        t = s.get(Ticket, f.ticket_id)
        if t and t.empresa_id == eid:
            partes = ([f"{_h(f.minutos)} h"] if f.minutos else []) + ([f"{repuestos} repuesto(s)"] if repuestos else [])
            s.add(TicketEntrada(empresa_id=eid, ticket_id=t.id, tipo="sistema", texto=f"Comprobante {d.consecutivo} {motivo}: " + (" y ".join(partes) or "nada") + " vuelven a quedar por cobrar",
                                usuario=usuario or "sistema"))
        s.delete(f); n += 1
    return n


def liberar_si_acreditada(s: Session, eid: int, clave: str, usuario: str = "") -> int:
    """4.5: después de modulos.recalcular_acreditado: si las notas de crédito cubren la factura completa, lo cobrado de sus tickets vuelve
    a quedar por cobrar (una nota parcial no libera nada: la factura sigue cobrando esas horas). Confirma, porque recalcular_acreditado
    ya confirmó lo suyo."""
    f = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
    if f is None or f.tipo_documento not in ("01", "04") or float(f.total or 0) - float(f.acreditado or 0) > 0.004:
        return 0
    n = liberar_documento(s, eid, f, usuario, "acreditado por completo con nota de crédito")
    if n:
        s.commit()
    return n


# ------------------------------------------------------------------------------------------------- reportes
@router.get("/api/tike/reportes")
def reportes(desde: Optional[str] = None, hasta: Optional[str] = None, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    hoy = ahora_cr().date()
    desde = (desde or hoy.replace(day=1).isoformat())[:10]; hasta = (hasta or hoy.isoformat())[:10]
    ts = s.exec(select(Ticket).where(Ticket.empresa_id == eid, Ticket.creado >= desde, Ticket.creado <= hasta + "T99")).all()
    ids = [t.id for t in ts]
    entradas = s.exec(select(TicketEntrada).where(TicketEntrada.empresa_id == eid, TicketEntrada.creado >= desde, TicketEntrada.creado <= hasta + "T99")).all()
    por_tecnico: dict = {}
    for x in entradas:
        if x.minutos:
            k = x.usuario or "—"; por_tecnico[k] = por_tecnico.get(k, 0) + int(x.minutos)
    por_cliente: dict = {}; por_categoria: dict = {}; por_prioridad: dict = {}
    cumplidos = vencidos = 0; calif = []; primera: list = []
    for t in ts:
        k = t.cliente_nombre or t.solicitante or "Sin cliente"; por_cliente[k] = por_cliente.get(k, 0) + 1
        k = t.categoria or "Sin categoría"; por_categoria[k] = por_categoria.get(k, 0) + 1
        por_prioridad[t.prioridad] = por_prioridad.get(t.prioridad, 0) + 1
        fin = t.resuelto_en or t.cerrado_en
        if t.vence and fin:
            if fin <= t.vence:
                cumplidos += 1
            else:
                vencidos += 1
        elif t.vence and t.estado in ABIERTOS and t.vence < ahora_cr().isoformat(timespec="seconds"):
            vencidos += 1
        if t.calificacion:
            calif.append(t.calificacion)
        if t.primera_respuesta:
            try:
                primera.append((ahora_cr().fromisoformat(t.primera_respuesta) - ahora_cr().fromisoformat(t.creado)).total_seconds() / 3600)
            except ValueError:
                pass
    contratos = [{**_salida_contrato(s, eid, c, True)} for c in s.exec(select(Contrato).where(Contrato.empresa_id == eid, Contrato.activo == True)).all()]  # noqa: E712
    por_estado = {k: 0 for k in NOMBRES_ESTADO}
    for t in ts:
        por_estado[t.estado] = por_estado.get(t.estado, 0) + 1
    return {"desde": desde, "hasta": hasta, "tickets": len(ts), "por_estado": por_estado, "por_tecnico_minutos": dict(sorted(por_tecnico.items(), key=lambda kv: -kv[1])),
            "por_cliente": dict(sorted(por_cliente.items(), key=lambda kv: -kv[1])[:30]), "por_categoria": dict(sorted(por_categoria.items(), key=lambda kv: -kv[1])), "por_prioridad": por_prioridad,
            "sla": {"cumplidos": cumplidos, "vencidos": vencidos, "porcentaje": round(cumplidos * 100 / (cumplidos + vencidos), 1) if (cumplidos + vencidos) else None},
            "calificacion": {"promedio": round(sum(calif) / len(calif), 2) if calif else None, "cantidad": len(calif)},
            "primera_respuesta_horas": round(sum(primera) / len(primera), 1) if primera else None, "minutos_total": sum(por_tecnico.values()),
            "contratos": [{"id": c["id"], "cliente_nombre": c["cliente_nombre"], "nombre": c["nombre"], "tipo_nombre": c["tipo_nombre"], "consumo": c["consumo"], "cuota": _cobro_visible(ctx, c)["cuota"]} for c in contratos]}
