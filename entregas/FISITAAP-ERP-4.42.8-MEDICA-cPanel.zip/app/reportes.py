"""Reportes formateados (PDF y Word) con el encabezado de la empresa.

La interfaz manda las columnas, las filas y los totales tal como se ven en pantalla (ya formateados) y aquí se arma
un documento con logo, nombre, cédula, dirección y contacto de la empresa, título, período, cifras clave, la tabla
y el pie con la fecha de generación. El .docx se escribe a mano (Office Open XML mínimo) para no depender de más
paquetes en el servidor.
"""
import io
import re
import threading
import zipfile
from pathlib import Path
from typing import Optional
from xml.sax.saxutils import escape as _x

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from . import ubicaciones
from .auth import Contexto, contexto, limitar_ip
from .config import ahora_cr
from .fe.pdf import TIPO_ID, _esc as _esc_base, logo_empresa

router = APIRouter(prefix="/api/reportes", tags=["reportes"])

# 3.87: reportlab se importa la primera vez que se arma un PDF (_reportlab), no al arrancar el servidor; hasta entonces estos nombres valen None
colors = TA_RIGHT = landscape = letter = ParagraphStyle = mm = Image = Paragraph = SimpleDocTemplate = Spacer = Table = TableStyle = None
PageBreak = None                                  # 4.42: salto de página entre los documentos de _pdf_varios
VERDE = GRIS = GRIS_CLARO = LINEA = None
_rl_listo = False
_rl_cerrojo = threading.Lock()
MAX_FILAS = 5000


def _reportlab():
    global _rl_listo
    if _rl_listo:
        return
    with _rl_cerrojo:
        if _rl_listo:
            return
        from reportlab.lib import colors as _colors
        from reportlab.lib.enums import TA_RIGHT as _ta_right
        from reportlab.lib.pagesizes import landscape as _landscape, letter as _letter
        from reportlab.lib.styles import ParagraphStyle as _ps
        from reportlab.lib.units import mm as _mm
        from reportlab.platypus import Image as _im, Paragraph as _pa, SimpleDocTemplate as _sd, Spacer as _sp, Table as _ta, TableStyle as _ts
        from reportlab.platypus import PageBreak as _pb
        globals().update(colors=_colors, TA_RIGHT=_ta_right, landscape=_landscape, letter=_letter, ParagraphStyle=_ps, mm=_mm, Image=_im, Paragraph=_pa,
                         SimpleDocTemplate=_sd, Spacer=_sp, Table=_ta, TableStyle=_ts, PageBreak=_pb,
                         VERDE=_colors.HexColor("#0f766e"), GRIS=_colors.HexColor("#555555"), GRIS_CLARO=_colors.HexColor("#f3f4f6"), LINEA=_colors.HexColor("#e5e7eb"))
        _rl_listo = True


class ColumnaIn(BaseModel):
    key: str = Field(max_length=60)
    label: str = Field(max_length=80)
    num: bool = False


class KpiIn(BaseModel):
    t: str = Field(max_length=80)
    v: str = Field(max_length=80)


class TipoCambioPie(BaseModel):
    """4.18: la compra y la venta del BCCR que van al pie del reporte (la venta en negrita)."""
    fecha: str = Field(max_length=10)
    compra: float
    venta: float


def _cr(n: float) -> str:
    return f"{float(n):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _pie_tc(tc: TipoCambioPie) -> tuple:
    f = "/".join(reversed(tc.fecha.split("-")))
    return f"Tipo de cambio de referencia del Banco Central de Costa Rica al {f}: compra ₡{_cr(tc.compra)} · ", f"venta ₡{_cr(tc.venta)}", " (la que se usa)"


class SeccionIn(BaseModel):
    titulo: str = Field(max_length=120)
    columnas: list[ColumnaIn] = Field(min_length=1, max_length=30)
    filas: list[dict] = Field(default_factory=list, max_length=MAX_FILAS)
    totales: list[KpiIn] = Field(default_factory=list, max_length=12)
    nota: Optional[str] = Field(None, max_length=300)


class FirmaIn(BaseModel):
    """4.21: línea de firma al final del documento (constancia salarial): nombre y cargo de quien firma, los dos opcionales."""
    nombre: str = Field("", max_length=90)
    cargo: str = Field("", max_length=90)


class ReporteIn(BaseModel):
    titulo: str = Field(max_length=120)
    subtitulo: Optional[str] = Field(None, max_length=300)
    periodo: Optional[str] = Field(None, max_length=80)
    columnas: list[ColumnaIn] = Field(default_factory=list, max_length=30)
    filas: list[dict] = Field(default_factory=list, max_length=MAX_FILAS)
    kpis: list[KpiIn] = Field(default_factory=list, max_length=8)
    totales: list[KpiIn] = Field(default_factory=list, max_length=12)
    nota: Optional[str] = Field(None, max_length=300)
    archivo: str = Field("reporte", max_length=80)
    tipo_cambio: Optional[TipoCambioPie] = None
    secciones: list[SeccionIn] = Field(default_factory=list, max_length=12)   # documentos con varias tablas (ficha del empleado)
    firma: Optional[FirmaIn] = None            # 4.21: sin firma (lo de siempre) el documento sale igual que antes


_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _esc(texto):
    """4.22: texto de una celda, un rótulo o un total del PDF. Helvetica no trae «₡» y el PDF lo pintaba como un cuadro negro en
    todos los reportes: se escribe «¢», como en el PDF de la factura (fe/pdf.py). El Word y el Excel no pasan por aquí."""
    return _esc_base(texto.replace("₡", "¢") if isinstance(texto, str) else texto)


def _celda(v) -> str:
    if v is None or v is False:
        return ""
    return _CONTROL.sub("", str(v))[:200]      # XML 1.0 no admite caracteres de control (Word diría "archivo dañado")


def _empresa_lineas(e) -> list[str]:
    """Nombre, cédula, dirección y contacto para el encabezado."""
    nombre = e.nombre_comercial or e.nombre
    out = [nombre]
    if e.nombre_comercial and e.nombre_comercial != e.nombre:
        out.append(e.nombre)
    out.append(f"{TIPO_ID.get(e.tipo_id, 'Identificación')} {e.numero_id}")
    ubic = ubicaciones.nombre(e.provincia, e.canton, e.distrito)
    direccion = ", ".join(x for x in [ubic, e.otras_senas] if x)
    if direccion:
        out.append(direccion)
    contacto = "   ·   ".join(x for x in [f"Tel. {e.telefono}" if e.telefono else "", e.correo or "", getattr(e, "sitio_web", "") or ""] if x)
    if contacto:
        out.append(contacto)
    return out


def _pesos(cols):
    """Ancho relativo por columna: numéricas angostas, la primera de texto se lleva el resto."""
    pesos = [1.0 if c.num else 1.6 for c in cols]
    texto = [i for i, c in enumerate(cols) if not c.num]
    if texto:
        pesos[texto[0]] = 2.6
    return pesos


# ----------------------------------------------------------------------------- PDF
def _max_columnas(d: ReporteIn) -> int:
    return max([len(d.columnas)] + [len(s.columnas) for s in d.secciones])


def _validar(d: ReporteIn):
    if not d.columnas and not d.secciones:
        raise HTTPException(400, "El reporte no tiene columnas")


# 4.42: _pdf quedó partido en «armar el contenido» (_estilos, _encabezado, _flujo) y «construir el documento» (_construir), para poder
# juntar varios reportes en un solo PDF (_pdf_varios: los comprobantes de pago para imprimir). Lo que produce _pdf NO cambió: los
# mismos textos, en el mismo orden, y el mismo archivo byte a byte (tests/test_442_listapago.py lo compara con el _pdf de la 4.41).
def _estilos() -> tuple:
    """4.42: los estilos de texto de un reporte en PDF (se arman después de _reportlab())."""
    base = ParagraphStyle("b", fontName="Helvetica", fontSize=8.5, leading=11, textColor=colors.HexColor("#1d2433"))
    small = ParagraphStyle("s", parent=base, fontSize=7.5, leading=9.5, textColor=GRIS)
    h_emp = ParagraphStyle("he", parent=base, fontName="Helvetica-Bold", fontSize=13, leading=16)
    h_tit = ParagraphStyle("ht", parent=base, fontName="Helvetica-Bold", fontSize=15, leading=18, textColor=VERDE, alignment=TA_RIGHT)
    right_small = ParagraphStyle("rs", parent=small, alignment=TA_RIGHT)
    head = ParagraphStyle("hd", parent=base, fontName="Helvetica-Bold", fontSize=8, leading=10, textColor=colors.white)
    head_r = ParagraphStyle("hdr", parent=head, alignment=TA_RIGHT)
    cel_r = ParagraphStyle("cr", parent=base, alignment=TA_RIGHT)
    kpi_v = ParagraphStyle("kv", parent=base, fontName="Helvetica-Bold", fontSize=11, leading=14)
    h_sec = ParagraphStyle("hs", parent=base, fontName="Helvetica-Bold", fontSize=10.5, leading=13, textColor=VERDE)
    return base, small, h_emp, h_tit, right_small, head, head_r, cel_r, kpi_v, h_sec


_LOGO_PX = (800, 240)       # el logo se dibuja de 18 mm de alto y hasta 60 mm de ancho: con estos puntos (ancho, alto) sale nítido en papel


def _logo_reducido(logo_path: Optional[Path]) -> Optional[tuple]:
    """4.42: (PNG en memoria, ancho / alto del original): el logo reducido al tamaño en que se dibuja, para un PDF de muchos
    documentos (_pdf_varios). Cada encabezado crea su propia imagen y reportlab vuelve a decodificar el PNG entero en cada una: con
    un logo grande (subir_logo lo guarda tal como llega) el PDF de los comprobantes tardaba varias veces más. None cuando no hace
    falta o no se puede (sin logo, un JPG —va incrustado tal cual, no se decodifica—, uno que ya es pequeño o un archivo que no se
    deja abrir): entonces cada encabezado usa el archivo, como en _pdf."""
    try:
        if not logo_path or not Path(logo_path).exists() or Path(logo_path).suffix.lower() in (".jpg", ".jpeg"):
            return None
        from PIL import Image as _Imagen
        with _Imagen.open(str(logo_path)) as im:
            ancho, alto = im.size
            escala = min(_LOGO_PX[0] / float(ancho), _LOGO_PX[1] / float(alto))
            if escala >= 1:
                return None
            if im.mode not in ("RGB", "RGBA"):
                im = im.convert("RGBA")
            buf = io.BytesIO()
            im.resize((max(1, round(ancho * escala)), max(1, round(alto * escala))), getattr(_Imagen, "Resampling", _Imagen).LANCZOS).save(buf, format="PNG")
        return buf.getvalue(), ancho / float(alto)
    except Exception:
        return None


def _encabezado(d: ReporteIn, e, logo_path: Optional[Path], ancho, logo_listo: Optional[tuple] = None) -> tuple:
    """4.42: el principio de un reporte en PDF: logo y datos de la empresa a la izquierda; título, período y «Generado el» a la
    derecha; debajo el subtítulo y las cifras clave. Devuelve (contenido, líneas de la empresa). `ancho` es el ancho útil de la hoja.
    `logo_listo`: el logo ya reducido (_logo_reducido) cuando el PDF junta muchos documentos; sin él se lee `logo_path`, como siempre."""
    base, small, h_emp, h_tit, right_small, head, head_r, cel_r, kpi_v, h_sec = _estilos()

    flow = []
    logo = None
    if logo_listo is not None:                        # el mismo logo reducido para todos los documentos del PDF; se dibuja del mismo tamaño
        try:
            logo = Image(io.BytesIO(logo_listo[0]))
            logo.drawHeight = 18 * mm
            logo.drawWidth = min(18 * mm * logo_listo[1], 60 * mm)
            logo.hAlign = "LEFT"
        except Exception:
            logo = None
    elif logo_path and Path(logo_path).exists():
        try:
            logo = Image(str(logo_path))
            ratio = logo.imageWidth / float(logo.imageHeight)
            logo.drawHeight = 18 * mm
            logo.drawWidth = min(18 * mm * ratio, 60 * mm)
            logo.hAlign = "LEFT"
        except Exception:
            logo = None
    lineas = _empresa_lineas(e)
    izq = [Paragraph(_esc(lineas[0]), h_emp)] + [Paragraph(_esc(x), small) for x in lineas[1:]]
    der = [Paragraph(_esc(d.titulo), h_tit)]
    if d.periodo:
        der.append(Paragraph("Período: " + _esc(d.periodo), right_small))
    der.append(Paragraph("Generado el " + ahora_cr().strftime("%d/%m/%Y %H:%M"), right_small))
    col_logo = (logo.drawWidth + 4 * mm) if logo else 0
    enc = Table([[logo or "", izq, der]], colWidths=[col_logo, ancho * 0.55 - col_logo, ancho * 0.45])
    enc.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                             ("LINEBELOW", (0, 0), (-1, 0), 1.2, VERDE), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    flow += [enc, Spacer(1, 3 * mm)]
    if d.subtitulo:
        flow += [Paragraph(_esc(d.subtitulo), small), Spacer(1, 2 * mm)]
    if d.kpis:
        celdas = [[Paragraph(_esc(k.t), small), Paragraph(_esc(k.v), kpi_v)] for k in d.kpis]
        kt = Table([celdas], colWidths=[ancho / len(celdas)] * len(celdas))
        kt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), GRIS_CLARO), ("BOX", (0, 0), (-1, -1), 0.5, LINEA), ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.white),
                                ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
        flow += [kt, Spacer(1, 4 * mm)]
    return flow, lineas


def _flujo(d: ReporteIn, e, logo_path: Optional[Path], ancho, logo_listo: Optional[tuple] = None) -> tuple:
    """4.42: el contenido completo de un reporte en PDF, sin construir el documento: el encabezado (_encabezado), la tabla o las
    secciones con sus totales y notas, la firma y el pie del tipo de cambio. Devuelve (contenido, líneas de la empresa)."""
    base, small, h_emp, h_tit, right_small, head, head_r, cel_r, kpi_v, h_sec = _estilos()
    flow, lineas = _encabezado(d, e, logo_path, ancho, logo_listo)

    def tabla_de(cols, filas, totales, nota):
        cab = [Paragraph(_esc(c.label), head_r if c.num else head) for c in cols]
        datos = [cab] + [[Paragraph(_esc(_celda(f.get(c.key))), cel_r if c.num else base) for c in cols] for f in filas]
        if not filas:
            datos.append([Paragraph("Sin datos para el período", small)] + [""] * (len(cols) - 1))
        pesos = _pesos(cols)
        tot = sum(pesos)
        tabla = Table(datos, colWidths=[ancho * p / tot for p in pesos], repeatRows=1)
        est = [("BACKGROUND", (0, 0), (-1, 0), VERDE), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINEA),
               ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5), ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
        for i in range(2, len(datos), 2):
            est.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f9fafb")))
        if not filas:
            est.append(("SPAN", (0, 1), (-1, 1)))
        tabla.setStyle(TableStyle(est))
        out = [tabla]
        if totales:
            tt = Table([[Paragraph(_esc(t.t), small), Paragraph("<b>" + _esc(t.v) + "</b>", cel_r)] for t in totales], colWidths=[ancho * 0.72, ancho * 0.28], hAlign="RIGHT")
            tt.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, 0), 0.8, VERDE), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
            out += [Spacer(1, 2 * mm), tt]
        if nota:
            out += [Spacer(1, 3 * mm), Paragraph(_esc(nota), small)]
        return out

    if d.secciones:                                   # documento de varias tablas: cada sección con su título
        for i, sec in enumerate(d.secciones):
            if i:
                flow.append(Spacer(1, 5 * mm))
            flow.append(Paragraph(_esc(sec.titulo), h_sec))
            flow.append(Spacer(1, 1.5 * mm))
            flow += tabla_de(sec.columnas, sec.filas, sec.totales, sec.nota)
        if d.nota:
            flow += [Spacer(1, 3 * mm), Paragraph(_esc(d.nota), small)]
    else:
        flow += tabla_de(d.columnas, d.filas, d.totales, d.nota)
    if d.firma:                                       # 4.21: espacio para firmar, la línea y debajo el nombre y el cargo
        flow += [Spacer(1, 18 * mm), Paragraph("_" * 45, small), Paragraph(_esc(_celda(d.firma.nombre).strip() or "Firma"), small)]
        if d.firma.cargo.strip():
            flow.append(Paragraph(_esc(_celda(d.firma.cargo).strip()), small))
    if d.tipo_cambio:
        a, b, c = _pie_tc(d.tipo_cambio)
        flow += [Spacer(1, 3 * mm), Paragraph(_esc(a.replace("₡", "¢")) + "<b>" + _esc(b.replace("₡", "¢")) + "</b>" + _esc(c), small)]     # Helvetica no trae ₡ (ver fe/pdf.py)
    return flow, lineas


def _construir(flow: list, pagina, titulo: str, autor: str, pie: str) -> bytes:
    """4.42: el archivo PDF de un contenido ya armado (_flujo): la hoja, los márgenes y el pie de cada página (`pie` a la izquierda y
    «Página N» a la derecha)."""
    buf = io.BytesIO()
    MARGEN = 12 * mm
    doc = SimpleDocTemplate(buf, pagesize=pagina, leftMargin=MARGEN, rightMargin=MARGEN, topMargin=MARGEN, bottomMargin=14 * mm,
                            title=titulo, author=autor, subject="Reporte")

    def _pie(canv, _doc):
        canv.saveState()
        canv.setFont("Helvetica", 7)
        canv.setFillColor(GRIS)
        canv.drawString(MARGEN, 8 * mm, pie[:150])
        canv.drawRightString(pagina[0] - MARGEN, 8 * mm, f"Página {_doc.page}")
        canv.restoreState()

    doc.build(flow, onFirstPage=_pie, onLaterPages=_pie)
    return buf.getvalue()


def _pdf(d: ReporteIn, e, logo_path: Optional[Path]) -> bytes:
    _reportlab()
    pagina = landscape(letter) if _max_columnas(d) > 6 else letter
    MARGEN = 12 * mm
    flow, lineas = _flujo(d, e, logo_path, pagina[0] - 2 * MARGEN)
    return _construir(flow, pagina, d.titulo, e.nombre, f"{lineas[0]}  ·  {d.titulo}")


class FilaFirmaIn(BaseModel):
    nombre: str = Field(max_length=90)
    numero_id: str = Field("", max_length=30)


class HojaFirmasIn(BaseModel):
    """4.42: hoja de firmas de recibido que cierra un PDF de varios documentos (_pdf_varios): una línea por persona para firmar y
    fechar. No lleva montos: la firman todos en la misma hoja y cada quien vería lo que cobran los demás."""
    titulo: str = Field(max_length=120)
    subtitulo: Optional[str] = Field(None, max_length=300)
    periodo: Optional[str] = Field(None, max_length=80)
    texto: str = Field("", max_length=300)
    filas: list[FilaFirmaIn] = Field(default_factory=list, max_length=MAX_FILAS)


def _hoja_firmas(h: HojaFirmasIn, e, logo_path: Optional[Path], ancho, logo_listo: Optional[tuple] = None) -> list:
    """4.42: el contenido de la hoja de firmas: el encabezado de siempre, el texto de lo que se firma y la tabla N.º · Nombre ·
    Identificación · Firma · Fecha, con renglones altos para firmar a mano y el encabezado repetido en cada página."""
    base, small, h_emp, h_tit, right_small, head, head_r, cel_r, kpi_v, h_sec = _estilos()
    flow, _lineas = _encabezado(ReporteIn(titulo=h.titulo, subtitulo=h.subtitulo, periodo=h.periodo), e, logo_path, ancho, logo_listo)
    if h.texto.strip():
        flow += [Paragraph(_esc(_celda(h.texto.strip())), base), Spacer(1, 3 * mm)]
    datos = [[Paragraph(_esc(t), head) for t in ("N.º", "Nombre", "Identificación", "Firma", "Fecha")]]
    for i, f in enumerate(h.filas, start=1):
        datos.append([Paragraph(str(i), base), Paragraph(_esc(_celda(f.nombre)), base), Paragraph(_esc(_celda(f.numero_id).strip() or "—"), base), Spacer(1, 9 * mm), ""])
    if not h.filas:
        datos.append([Paragraph("Sin personas en esta hoja", small), "", "", "", ""])
    pesos = (10, 66, 34, 55, 26)
    tabla = Table(datos, colWidths=[ancho * p / sum(pesos) for p in pesos], repeatRows=1)
    tabla.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), VERDE), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#9ca3af")),
                               ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5), ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
                              + ([] if h.filas else [("SPAN", (0, 1), (-1, 1))])))
    flow.append(tabla)
    return flow


def _pdf_varios(docs: list, e, logo_path: Optional[Path], titulo: str, firmas: Optional[HojaFirmasIn] = None) -> bytes:
    """4.42: varios reportes en UN solo PDF, cada uno desde una página nueva y armado igual que con _pdf (_flujo), y al final, si se
    pide, la hoja de firmas en su propia página. `titulo` nombra el archivo y va en el pie de todas las páginas («Empresa · título»).
    La hoja es carta vertical, u horizontal si algún reporte tiene más de 6 columnas. El logo se prepara UNA vez para todo el PDF
    (_logo_reducido) y cada documento lo dibuja del mismo tamaño que en _pdf."""
    _reportlab()
    if not docs:
        raise HTTPException(400, "No hay documentos para juntar en el PDF")
    pagina = landscape(letter) if max(_max_columnas(d) for d in docs) > 6 else letter
    MARGEN = 12 * mm
    ancho = pagina[0] - 2 * MARGEN
    logo_listo = _logo_reducido(logo_path)
    flow = []
    for i, d in enumerate(docs):
        if i:
            flow.append(PageBreak())
        flow += _flujo(d, e, logo_path, ancho, logo_listo)[0]
    if firmas is not None:
        flow.append(PageBreak())
        flow += _hoja_firmas(firmas, e, logo_path, ancho, logo_listo)
    return _construir(flow, pagina, titulo, e.nombre, f"{_empresa_lineas(e)[0]}  ·  {titulo}")


# ----------------------------------------------------------------------------- DOCX (Office Open XML mínimo)
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _run(texto, b=False, size=None, color=None):
    rpr = ""
    if b:
        rpr += "<w:b/>"
    if color:
        rpr += f'<w:color w:val="{color}"/>'
    if size:
        rpr += f'<w:sz w:val="{int(size * 2)}"/>'
    return f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{_x(_CONTROL.sub("", str(texto)))}</w:t></w:r>'


def _p(texto="", b=False, size=None, color=None, align=None, after=60, runs=None):
    ppr = f'<w:pPr><w:spacing w:after="{after}"/>' + (f'<w:jc w:val="{align}"/>' if align else "") + "</w:pPr>"
    return f"<w:p>{ppr}{runs if runs is not None else _run(texto, b, size, color)}</w:p>"


def _tc(contenido, ancho, fill=None, align=None, b=False, size=None, color=None):
    tcpr = f'<w:tcPr><w:tcW w:w="{int(ancho)}" w:type="dxa"/><w:tcBorders><w:bottom w:val="single" w:sz="4" w:space="0" w:color="E5E7EB"/></w:tcBorders>'
    tcpr += (f'<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/>' if fill else "")   # orden del esquema: tcW, tcBorders, shd, tcMar
    tcpr += '<w:tcMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tcMar></w:tcPr>'
    return f"<w:tc>{tcpr}{_p(contenido, b=b, size=size, color=color, align=align, after=40)}</w:tc>"


def _grid(anchos):
    return "<w:tblGrid>" + "".join(f'<w:gridCol w:w="{int(a)}"/>' for a in anchos) + "</w:tblGrid>"


def _docx(d: ReporteIn, e, logo_path: Optional[Path]) -> bytes:
    apaisado = _max_columnas(d) > 6
    w_pag, h_pag = (15840, 12240) if apaisado else (12240, 15840)
    margen = 900
    ancho = w_pag - 2 * margen
    lineas = _empresa_lineas(e)
    cuerpo = []
    logo_bytes = None
    ext = "png"
    cx = cy = 0
    if logo_path and Path(logo_path).exists():
        try:
            from reportlab.lib.utils import ImageReader
            logo_bytes = Path(logo_path).read_bytes()
            ext = Path(logo_path).suffix.lower().lstrip(".") or "png"
            if ext == "jpg":
                ext = "jpeg"
            iw, ih = ImageReader(str(logo_path)).getSize()
            cy = 640080                                   # 18 mm en EMU
            cx = min(int(cy * iw / float(ih)), 2160000)   # máximo 60 mm de ancho
        except Exception:
            logo_bytes = None
    if logo_bytes:
        cuerpo.append(
            f'<w:p><w:pPr><w:spacing w:after="60"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
            f'<wp:docPr id="1" name="Logo"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            f'<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            f'<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="logo.{ext}"/><pic:cNvPicPr/></pic:nvPicPr>'
            f'<pic:blipFill><a:blip r:embed="rIdLogo"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
            f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
            f'</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>')
    # encabezado: empresa (izq) | título (der) en una tabla con línea verde abajo
    izq = _p(lineas[0], b=True, size=13, after=20) + "".join(_p(x, size=8, color="555555", after=0) for x in lineas[1:])
    der = _p(d.titulo, b=True, size=15, color="0F766E", align="right", after=20)
    if d.periodo:
        der += _p("Período: " + d.periodo, size=8, color="555555", align="right", after=0)
    der += _p("Generado el " + ahora_cr().strftime("%d/%m/%Y %H:%M"), size=8, color="555555", align="right", after=0)
    w1, w2 = int(ancho * 0.55), int(ancho * 0.45)
    cuerpo.append(f'<w:tbl><w:tblPr><w:tblW w:w="{ancho}" w:type="dxa"/><w:tblBorders><w:bottom w:val="single" w:sz="12" w:space="0" w:color="0F766E"/></w:tblBorders></w:tblPr>'
                  + _grid([w1, w2]) + f'<w:tr><w:tc><w:tcPr><w:tcW w:w="{w1}" w:type="dxa"/></w:tcPr>{izq}</w:tc>'
                  f'<w:tc><w:tcPr><w:tcW w:w="{w2}" w:type="dxa"/></w:tcPr>{der}</w:tc></w:tr></w:tbl>')
    cuerpo.append(_p("", after=120))
    if d.subtitulo:
        cuerpo.append(_p(d.subtitulo, size=8, color="555555", after=120))
    if d.kpis:
        wk = int(ancho / len(d.kpis))
        celdas = "".join(f'<w:tc><w:tcPr><w:tcW w:w="{wk}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/></w:tcPr>'
                         f'{_p(k.t, size=8, color="555555", after=0)}{_p(k.v, b=True, size=11, after=40)}</w:tc>' for k in d.kpis)
        cuerpo.append(f'<w:tbl><w:tblPr><w:tblW w:w="{ancho}" w:type="dxa"/></w:tblPr>' + _grid([wk] * len(d.kpis)) + f"<w:tr>{celdas}</w:tr></w:tbl>")
        cuerpo.append(_p("", after=120))
    def tabla_docx(cols, filas_d, totales, nota):
        pesos = _pesos(cols)
        tot = sum(pesos)
        anchos = [int(ancho * p / tot) for p in pesos]
        filas = ["<w:tr><w:trPr><w:tblHeader/></w:trPr>" + "".join(_tc(c.label, a, fill="0F766E", b=True, size=8, color="FFFFFF", align="right" if c.num else None) for c, a in zip(cols, anchos)) + "</w:tr>"]
        for i, f in enumerate(filas_d):
            fill = "F9FAFB" if i % 2 else None
            filas.append("<w:tr>" + "".join(_tc(_celda(f.get(c.key)), a, fill=fill, size=8, align="right" if c.num else None) for c, a in zip(cols, anchos)) + "</w:tr>")
        if not filas_d:
            filas.append("<w:tr>" + _tc("Sin datos para el período", anchos[0], size=8, color="555555") + "".join(_tc("", a, size=8) for a in anchos[1:]) + "</w:tr>")
        out = [f'<w:tbl><w:tblPr><w:tblW w:w="{ancho}" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr>' + _grid(anchos) + "".join(filas) + "</w:tbl>"]
        if totales:
            out.append(_p("", after=80))
            for t in totales:
                out.append(_p(align="right", after=20, runs=_run(t.t + ":  ", size=8, color="555555") + _run(t.v, b=True, size=10)))
        if nota:
            out.append(_p(nota, size=8, color="555555", after=120))
        return out

    if d.secciones:
        for i, sec in enumerate(d.secciones):
            cuerpo.append(_p(sec.titulo, b=True, size=10.5, color="0F766E", after=60))
            cuerpo += tabla_docx(sec.columnas, sec.filas, sec.totales, sec.nota)
            cuerpo.append(_p("", after=160))
        if d.nota:
            cuerpo.append(_p(d.nota, size=8, color="555555", after=120))
    else:
        cuerpo += tabla_docx(d.columnas, d.filas, d.totales, d.nota)
    if d.firma:                                       # 4.21: espacio para firmar, la línea y debajo el nombre y el cargo
        cuerpo += [_p("", after=720), _p("_" * 45, size=9, color="555555", after=20), _p(d.firma.nombre.strip() or "Firma", size=9, after=0)]
        if d.firma.cargo.strip():
            cuerpo.append(_p(d.firma.cargo.strip(), size=9, color="555555", after=120))
    if d.tipo_cambio:
        a, b, c = _pie_tc(d.tipo_cambio)
        cuerpo.append(_p(runs=_run(a, False, 8, "555555") + _run(b, True, 8, "111111") + _run(c, False, 8, "555555"), after=120))
    pie = (f'<w:ftr xmlns:w="{W_NS}"><w:p><w:pPr><w:jc w:val="right"/></w:pPr>{_run(lineas[0] + "  ·  " + d.titulo + "  ·  Página ", size=7, color="555555")}'
           '<w:r><w:rPr><w:sz w:val="14"/><w:color w:val="555555"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>'
           '<w:r><w:rPr><w:sz w:val="14"/><w:color w:val="555555"/></w:rPr><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>'
           '<w:r><w:rPr><w:sz w:val="14"/><w:color w:val="555555"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>')
    sect = (f'<w:sectPr><w:footerReference w:type="default" r:id="rIdPie"/><w:pgSz w:w="{w_pag}" w:h="{h_pag}"' + (' w:orient="landscape"' if apaisado else "")
            + f'/><w:pgMar w:top="{margen}" w:right="{margen}" w:bottom="{margen}" w:left="{margen}" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr>')
    documento = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 f'<w:document xmlns:w="{W_NS}" xmlns:r="{R_NS}" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><w:body>'
                 + "".join(cuerpo) + sect + "</w:body></w:document>")
    estilos = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               f'<w:styles xmlns:w="{W_NS}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>'
               '<w:sz w:val="20"/><w:lang w:val="es-CR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault>'
               '</w:docDefaults></w:styles>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'<Relationship Id="rId1" Type="{R_NS}/styles" Target="styles.xml"/>'
            f'<Relationship Id="rIdPie" Type="{R_NS}/footer" Target="footer1.xml"/>'
            + (f'<Relationship Id="rIdLogo" Type="{R_NS}/image" Target="media/logo.{ext}"/>' if logo_bytes else "")
            + "</Relationships>")
    tipos = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
             '<Default Extension="png" ContentType="image/png"/><Default Extension="jpeg" ContentType="image/jpeg"/>'
             '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
             '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
             '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
    raiz = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'<Relationship Id="rId1" Type="{R_NS}/officeDocument" Target="word/document.xml"/></Relationships>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", tipos)
        z.writestr("_rels/.rels", raiz)
        z.writestr("word/document.xml", documento)
        z.writestr("word/styles.xml", estilos)
        z.writestr("word/footer1.xml", pie)
        z.writestr("word/_rels/document.xml.rels", rels)
        if logo_bytes:
            z.writestr(f"word/media/logo.{ext}", logo_bytes)
    return buf.getvalue()


def _nombre_archivo(base: str, ext: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", base).strip("_") or "reporte"
    return f"{s}.{ext}"


@router.post("/pdf")
def reporte_pdf(d: ReporteIn, ctx: Contexto = Depends(contexto)):
    """PDF formateado del reporte que se ve en pantalla (cualquier usuario con sesión en la empresa)."""
    limitar_ip(ctx.request, "reporte", 20, 300, "Demasiados reportes en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    _validar(d)
    if (len(d.filas) * len(d.columnas) + sum(len(s.filas) * len(s.columnas) for s in d.secciones)) > 30000:              # el PDF dibuja cada celda: 5.000×30 tardaba ~1 min
        raise HTTPException(400, "El reporte es muy grande para PDF (más de 30.000 celdas): descárguelo en Word o CSV, o acorte el período")
    contenido = _pdf(d, ctx.empresa, logo_empresa(ctx.empresa))
    return Response(contenido, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{_nombre_archivo(d.archivo, "pdf")}"'})


class ColumnaXlsxIn(ColumnaIn):
    sumar: bool = False        # 3.98: fila de total con SUMA
    fecha: bool = False


class ExcelIn(BaseModel):
    titulo: str = Field(max_length=120)
    subtitulo: Optional[str] = Field(None, max_length=300)
    periodo: Optional[str] = Field(None, max_length=120)
    columnas: list[ColumnaXlsxIn] = Field(min_length=1, max_length=40)
    filas: list[dict] = Field(default_factory=list, max_length=20000)
    archivo: Optional[str] = Field(None, max_length=80)
    tipo_cambio: Optional[TipoCambioPie] = None


def _numero(v):
    """3.98: número de una celda (acepta 1234.5, «1.234,50» o «₡1 234,50»); None si no es número."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = re.sub(r"[^0-9,.\-]", "", str(v or ""))
    if not s or s in ("-", ".", ","):
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _xlsx(d: ExcelIn, empresa) -> bytes:
    """3.98: el reporte en Excel listo para usar: título, empresa y periodo, encabezado con formato, números como números con
    separador de miles, filtro, encabezado fijo, ancho de columnas y fila de totales. Los textos nunca se toman como fórmulas."""
    return _xlsx_libro([d], empresa)


def _xlsx_libro(hojas: list, empresa, nombres: Optional[list] = None) -> bytes:
    """4.42: un libro de Excel con varias hojas, cada una un reporte armado igual que con _xlsx (que es el libro de una sola hoja).
    `hojas`: [ExcelIn]; `nombres`: el nombre de cada hoja (sin él, el título del reporte)."""
    from openpyxl import Workbook
    wb = Workbook()
    for i, d in enumerate(hojas):
        _hoja_xlsx(wb.create_sheet() if i else wb.active, d, empresa, nombres[i] if nombres else None)
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


_NO_XML = re.compile("[" + chr(0xFFFE) + chr(0xFFFF) + "]")      # los dos caracteres que el archivo de Excel (XML) tampoco admite


def _texto_xlsx(v) -> str:
    """4.42: el texto de una celda de Excel sin los caracteres que el archivo no admite: los de control (los mismos de _celda: un
    salto de línea manual pegado desde Word, por ejemplo) y U+FFFE y U+FFFF. Con uno solo, openpyxl no arma el libro y la descarga
    entera fallaba. Un texto normal queda igual."""
    return _NO_XML.sub("", _CONTROL.sub("", "" if v is None else str(v)))


def _hoja_xlsx(ws, d: ExcelIn, empresa, nombre: Optional[str] = None):
    """4.42: llena una hoja con un reporte (lo que hacía _xlsx con su única hoja). Todo texto que viene de los datos (el nombre de
    la hoja, los renglones del título, los rótulos y las celdas) pasa por _texto_xlsx."""
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    ws.title = (re.sub(r"[\[\]:*?/\\]", " ", _texto_xlsx(nombre or d.titulo)).strip() or "Reporte")[:31]
    fila = 1
    for texto, fuente in ((d.titulo, Font(bold=True, size=14)), (getattr(empresa, "nombre_comercial", None) or getattr(empresa, "nombre", None), Font(size=11)),
                          (d.periodo, Font(size=10, color="555555")), (d.subtitulo, Font(size=10, color="555555"))):
        if texto:
            c = ws.cell(row=fila, column=1, value=_texto_xlsx(texto)); c.data_type = "s"; c.font = fuente
            fila += 1
    fila += 1
    enc = fila
    relleno, borde = PatternFill("solid", fgColor="19384D"), Border(bottom=Side(style="thin", color="999999"))
    for j, col in enumerate(d.columnas, start=1):
        c = ws.cell(row=enc, column=j, value=_texto_xlsx(col.label)); c.data_type = "s"
        c.font, c.fill, c.alignment = Font(bold=True, color="FFFFFF"), relleno, Alignment(horizontal="right" if col.num else "left", vertical="center", wrap_text=True)
    anchos = [len(col.label) for col in d.columnas]
    for i, r in enumerate(d.filas, start=enc + 1):
        for j, col in enumerate(d.columnas, start=1):
            v = r.get(col.key) if isinstance(r, dict) else None
            n = _numero(v) if col.num else None
            if n is not None:
                c = ws.cell(row=i, column=j, value=n); c.number_format = "#,##0.00"
                largo = len(f"{n:,.2f}")
            else:
                texto = _texto_xlsx(v)
                c = ws.cell(row=i, column=j, value=texto); c.data_type = "s"     # nunca fórmula (un nombre que empiece con «=»)
                largo = len(texto)
            anchos[j - 1] = max(anchos[j - 1], largo)
    ultima = enc + len(d.filas)
    if d.filas and any(col.sumar for col in d.columnas):
        t = ultima + 1
        c = ws.cell(row=t, column=1, value="Total"); c.font = Font(bold=True)
        for j, col in enumerate(d.columnas, start=1):
            if col.sumar and j > 1:
                letra = get_column_letter(j)
                c = ws.cell(row=t, column=j, value=f"=SUM({letra}{enc + 1}:{letra}{ultima})")
                c.number_format, c.font, c.border = "#,##0.00", Font(bold=True), Border(top=Side(style="thin", color="333333"))
    if d.tipo_cambio:                                  # 4.18: al pie, la compra y la venta del BCCR; la venta en negrita
        pie = ultima + 3
        ws.cell(row=pie, column=1, value="Tipo de cambio de referencia del Banco Central de Costa Rica al " + "/".join(reversed(_texto_xlsx(d.tipo_cambio.fecha).split("-")))).font = Font(size=10, color="555555")
        ws.cell(row=pie + 1, column=1, value="Compra")
        ws.cell(row=pie + 1, column=2, value=d.tipo_cambio.compra).number_format = "#,##0.00"
        ws.cell(row=pie + 2, column=1, value="Venta (la que se usa)").font = Font(bold=True)
        v = ws.cell(row=pie + 2, column=2, value=d.tipo_cambio.venta); v.number_format, v.font = "#,##0.00", Font(bold=True)
    for j, ancho in enumerate(anchos, start=1):
        ws.column_dimensions[get_column_letter(j)].width = min(max(10, ancho + 2), 60)
    ws.freeze_panes = ws.cell(row=enc + 1, column=1)
    if d.filas:
        ws.auto_filter.ref = f"A{enc}:{get_column_letter(len(d.columnas))}{ultima}"
    ws.cell(row=enc, column=1).border = borde


@router.post("/xlsx")
def reporte_xlsx(d: ExcelIn, ctx: Contexto = Depends(contexto)):
    """3.98: el reporte en Excel (.xlsx) con formato (en lugar del CSV, que según la configuración regional de Excel se abre en una sola columna)."""
    limitar_ip(ctx.request, "reporte", 20, 300, "Demasiados reportes en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    contenido = _xlsx(d, ctx.empresa)
    return Response(contenido, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{_nombre_archivo(d.archivo, "xlsx")}"'})


@router.post("/docx")
def reporte_docx(d: ReporteIn, ctx: Contexto = Depends(contexto)):
    """Mismo reporte en Word (.docx)."""
    _validar(d)
    limitar_ip(ctx.request, "reporte", 20, 300, "Demasiados reportes en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    contenido = _docx(d, ctx.empresa, logo_empresa(ctx.empresa))
    return Response(contenido, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    headers={"Content-Disposition": f'attachment; filename="{_nombre_archivo(d.archivo, "docx")}"'})
