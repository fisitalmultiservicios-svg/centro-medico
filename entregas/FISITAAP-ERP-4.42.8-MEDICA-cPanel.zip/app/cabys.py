"""Catálogo CABYS (Catálogo de Bienes y Servicios) del BCCR/Hacienda.

Se importa desde el Excel oficial (catalogos/cabys.xlsx, hoja "Catálogo") a la tabla `cabys` para buscar
sin depender de internet. Fuente: https://sdd.bccr.fi.cr/es/IndicadoresEconomicos/Inicio/Documento/1947
"""
import logging
from pathlib import Path

from sqlmodel import Session, select, text

from .config import BASE_DIR, DATA_DIR
from .db import Cabys, engine

log = logging.getLogger(__name__)
XLSX = BASE_DIR / "catalogos" / "cabys.xlsx"
CSV = BASE_DIR / "catalogos" / "cabys.csv.gz"     # 3.72: el mismo catálogo en CSV comprimido (0,4 MB y se lee en una fracción de segundo); lo genera tools/convertir_cabys.py


def normalizar(texto: str) -> str:
    """Minúsculas y sin tildes, para que 'portatil' encuentre 'portátil'."""
    import unicodedata
    t = unicodedata.normalize("NFKD", texto or "")
    return "".join(c for c in t if not unicodedata.combining(c)).lower()


def raiz(palabra: str) -> str:
    """Quita terminaciones de género/número para que 'computadora' encuentre 'computadores'."""
    for suf in ("ciones", "cion", "es", "s", "a", "o"):
        if len(palabra) > 5 and palabra.endswith(suf):
            return palabra[: -len(suf)]
    return palabra


def leer_impuesto(valor) -> float | None:
    """Tarifa de IVA de una fila del Excel oficial: 0.13 → 13; 'Exento' → 0; '13%' → 13; '1%' → 1; 'na' o vacío → None.
    Antes cualquier texto caía en 13 % (885 códigos exentos y 21 del 1 % quedaron con 13 %)."""
    if valor is None:
        return None
    if isinstance(valor, (int, float)):
        v = float(valor)
        return round(v * 100, 2) if v <= 1 else round(v, 2)
    s = str(valor).strip().lower().replace(",", ".")
    if not s or s in ("na", "n/a", "nd", "-"):
        return None
    if s.startswith("exen"):
        return 0.0
    s = s.rstrip("%").strip()
    try:
        v = float(s)
    except ValueError:
        return None
    return round(v, 2) if "%" in str(valor) or v > 1 else round(v * 100, 2)


VERSION_CATALOGO = 2                                    # sube cuando cambia la forma de leer el Excel (reimporta en el arranque)


def _filas_excel(ruta: Path):
    """(codigo, descripcion, impuesto crudo, categoria, subcategoria, nombre corto, incluye, excluye) desde el Excel oficial."""
    import openpyxl
    wb = openpyxl.load_workbook(ruta, read_only=True)
    ws = wb["Catálogo"]
    for row in ws.iter_rows(min_row=3, values_only=True):
        yield (str(row[16] or "").strip(), str(row[17] or "").strip(), row[18], str(row[1] or "").strip(), str(row[3] or "").strip(),
               str(row[15] or ""), str(row[19]).strip() if row[19] else "", str(row[20]).strip() if row[20] else "")


def _filas_csv(ruta: Path):
    """Las mismas columnas desde catalogos/cabys.csv.gz (3.72), generado por tools/convertir_cabys.py."""
    import csv
    import gzip
    with gzip.open(ruta, "rt", encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            yield (r.get("codigo", ""), r.get("descripcion", ""), r.get("impuesto") or None, r.get("categoria", ""), r.get("subcategoria", ""),
                   r.get("nombre_corto", ""), r.get("incluye", ""), r.get("excluye", ""))


def importar_excel(ruta: Path = XLSX, reemplazar: bool = False) -> int:
    """Carga el catálogo en la base de datos. Devuelve la cantidad de códigos importados. Con el catálogo en csv.gz (3.72) lo usa;
    si no, lee el Excel oficial."""
    if ruta == XLSX and CSV.exists():
        origen, lector = CSV, _filas_csv
    elif ruta.exists():
        origen, lector = ruta, _filas_excel
    else:
        log.warning("No se encontró %s; la búsqueda CABYS usará la API de Hacienda", ruta)
        return 0
    with Session(engine) as s:
        if not reemplazar and s.exec(select(Cabys.codigo).limit(1)).first():
            return 0
    # 1) Leer el catálogo SIN transacción abierta (el Excel tarda varios segundos; no debe retener el lock de la base).
    filas = []
    for codigo, desc, crudo, categoria, subcategoria, corto, incluye, excluye in lector(origen):
        if len(codigo) != 13 or not codigo.isdigit():
            continue
        impuesto = leer_impuesto(crudo)
        if impuesto is None:
            continue                                    # sin tarifa conocida: no se ofrece (antes quedaba como 13 %)
        incluye = incluye or None
        filas.append(Cabys(
            codigo=codigo, descripcion=desc, impuesto=impuesto, categoria=categoria, subcategoria=subcategoria,
            incluye=incluye, excluye=excluye or None,
            busqueda=normalizar(f"{desc} {corto} {incluye or ''}"),
        ))
    # 2) Reemplazar el catálogo en UNA transacción corta: otro proceso nunca ve la tabla a medias y, si dos procesos
    #    importan a la vez en el primer arranque, el segundo falla por UNIQUE y se descarta sin dejar daño.
    with Session(engine) as s:
        if not reemplazar and s.exec(select(Cabys.codigo).limit(1)).first():
            return 0
        s.exec(text("DELETE FROM cabys"))
        for i in range(0, len(filas), 2000):
            s.add_all(filas[i:i + 2000]); s.flush()
        s.commit()
        log.info("CABYS importado: %d códigos", len(filas))
        return len(filas)


def importar_si_cambio(ruta: Path = XLSX) -> int:
    """Importa el catálogo si la tabla está vacía o si se importó con una versión anterior de la lectura (marca en un
    archivo junto a la base). Así una corrección en cómo se interpreta el Excel llega a las instalaciones ya cargadas."""
    marca = DATA_DIR / "cabys.version"
    try:
        actual = int(marca.read_text().strip() or 0)
    except (OSError, ValueError):
        actual = 0
    n = importar_excel(ruta, reemplazar=actual != VERSION_CATALOGO)
    if actual != VERSION_CATALOGO:
        try:
            marca.write_text(str(VERSION_CATALOGO))
        except OSError:
            pass
    return n


def buscar(q: str, top: int = 25) -> list[dict]:
    q = (q or "").strip()
    if not q:
        return []
    with Session(engine) as s:
        if q.isdigit():
            rows = s.exec(select(Cabys).where(Cabys.codigo.startswith(q)).limit(top)).all()
        else:
            palabras = [raiz(p) for p in normalizar(q).split() if p]
            stmt = select(Cabys)
            for p in palabras:
                stmt = stmt.where(Cabys.busqueda.like(f"%{p}%"))
            rows = s.exec(stmt.limit(top * 12)).all()
            # Relevancia antes de cortar: palabra completa al inicio de una palabra de la descripción > en la descripción >
            # solo en "incluye" (antes se tomaban los primeros 100 por código y después se ordenaban) (R284)
            def _clave(r):
                desc = " " + normalizar(r.descripcion) + " "
                inicio = all((" " + p) in desc for p in palabras)
                dentro = all(p in desc for p in palabras)
                return (0 if inicio else 1 if dentro else 2, len(r.descripcion))
            rows.sort(key=_clave)
            rows = rows[:top]
        return [r.model_dump(exclude={"busqueda"}) for r in rows]


def obtener(codigo: str) -> dict | None:
    with Session(engine) as s:
        r = s.get(Cabys, codigo)
        return r.model_dump(exclude={"busqueda"}) if r else None


def disponible() -> bool:
    with Session(engine) as s:
        return s.exec(select(Cabys.codigo).limit(1)).first() is not None
