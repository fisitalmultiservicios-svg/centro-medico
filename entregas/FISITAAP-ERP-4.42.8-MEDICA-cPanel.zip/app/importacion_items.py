"""Importar ítems desde Excel o CSV (3.58): lectura del archivo en el servidor, con las mismas columnas que la plantilla de
Inventario › Importar y actualizar ítems. Columnas (cabecera en la primera fila, sin tildes ni mayúsculas): nombre, codigo,
cabys, precio, unidad, tipo, tarifa, moneda, categoria, costo, descripcion y, opcionales, existencia (cantidad inicial en la
bodega principal, solo al crear), visible (si/no → se muestra en la página de FISITAAP) y (3.87) minimo y maximo: existencia
mínima y máxima del ítem para Inventario › Por reponer (vacías = sin aviso).

La tarifa sigue las mismas reglas que la importación por CSV en el navegador (leerTarifa): un código de dos dígitos ('08'),
un dígito al que Excel le quitó el cero ('8' → '08'), o un porcentaje ('13', '13%', '0,5') solo si corresponde a UN código.
Nada se asume como 13 % salvo la celda vacía; la fila ambigua se rechaza."""
import csv
import io
import re
import unicodedata
from typing import Optional

TARIFA_PCT = {"08": 13.0, "04": 4.0, "03": 2.0, "02": 1.0, "09": 0.5, "07": 8.0, "01": 0.0, "10": 0.0, "11": 0.0}
COLUMNAS = ("nombre", "codigo", "cabys", "precio", "unidad", "tipo", "tarifa", "moneda", "categoria", "costo", "descripcion", "existencia", "visible", "minimo", "maximo")
MAX_FILAS = 5000
MAX_BYTES = 10 * 1024 * 1024
EJEMPLOS = [   # 3.87: CABYS que existen en el catálogo oficial (antes 2 de 3 no existían y la plantilla tal cual daba error)
    ["Cemento gris 50 kg", "CEM-50", "3744001009900", 9500, "Unid", "Producto", "08", "CRC", "Construcción", 7200, "Saco de 50 kg", 20, "no", 5, 40],
    ["Consultoría contable", "SERV-01", "8222100000000", 45000, "h", "Servicio", "08", "CRC", "Servicios", "", "", "", "no", "", ""],
    ["Disco SSD 1 TB", "SSD-1T", "4755000000100", 89.90, "Unid", "Producto", "08", "USD", "Computo", 62, "", 5, "si", "", ""],
]
INSTRUCCIONES = [
    "Cómo llenar la plantilla",
    "• Una fila por ítem. La primera fila (cabeceras) no se cambia.",
    "• nombre, cabys y precio son obligatorios (el cabys no, si la facturación electrónica está apagada). El CABYS lleva 13 dígitos y debe existir en el catálogo de Hacienda.",
    "• precio y costo van sin IVA y sin símbolos (9500 o 89.90).",
    "• unidad: la de Hacienda (Unid, Sp, h, Kg, L, m…). Vacío = Unid.",
    "• tipo: Producto o Servicio. Los servicios no llevan inventario.",
    "• tarifa: código de IVA de Hacienda: 08 = 13 %, 04 = 4 %, 03 = 2 %, 02 = 1 %, 09 = 0,5 %, 07 = 8 %, 01 = 0 %, 10 = exento, 11 = 0 % sin crédito. Vacío = 13 %.",
    "• moneda: CRC o USD (vacío = la moneda principal de la empresa).",
    "• categoria, costo y descripcion son opcionales.",
    "• existencia: cantidad inicial en la bodega principal; solo se usa al crear el ítem (no al actualizar).",
    "• visible: si o no. «si» muestra el ítem en la página de FISITAAP (catálogo o menú).",
    "• minimo y maximo: existencia mínima y máxima (opcionales). Al llegar al mínimo el ítem sale en Inventario › Por reponer; se sugiere pedir hasta el máximo (sin máximo, hasta el doble del mínimo).",
    "• Modo «actualizar»: si ya existe un ítem con el mismo código (o, sin código, con el mismo nombre) se actualizan precio, costo, categoría, descripción, tarifa y unidad; si no existe, se crea.",
]


def _sin_tilde(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(s or "")) if unicodedata.category(c) != "Mn")


def _clave(s) -> str:
    return _sin_tilde(str(s or "")).strip().lower()


def _texto(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def numero(v) -> Optional[float]:
    """Número de una celda: acepta coma decimal y separadores de miles; None si está vacía; ValueError si no es número."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip().replace("₡", "").replace("$", "").replace(" ", "")
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    return float(t)


def leer_tarifa(valor) -> dict:
    """{codigo_tarifa, defecto?} o {problema}: mismas reglas que leerTarifa de gestion.js."""
    crudo = _texto(valor)
    con_pct = "%" in crudo
    t = crudo.replace("%", "").strip()
    if not t:
        return {"codigo_tarifa": "08", "defecto": True}
    if not con_pct and re.fullmatch(r"\d{2}", t) and t in TARIFA_PCT:
        return {"codigo_tarifa": t}
    if not con_pct and re.fullmatch(r"\d", t) and ("0" + t) in TARIFA_PCT:
        return {"codigo_tarifa": "0" + t}
    try:
        pct = float(t.replace(",", "."))
    except ValueError:
        return {"problema": f"tarifa «{crudo}» no válida: use el código de IVA (01 exento, 02 1 %, 03 2 %, 04 4 %, 07 8 %, 08 13 %, 09 0,5 %, 10 o 11 0 %)"}
    cands = [k for k, v in TARIFA_PCT.items() if v == pct]
    if len(cands) == 1:
        return {"codigo_tarifa": cands[0]}
    return {"problema": f"tarifa «{crudo}» ambigua: indique el código ({', '.join(cands)})" if cands else f"tarifa «{crudo}» no corresponde a ningún código de IVA"}


def _si(v) -> Optional[bool]:
    t = _clave(v)
    if not t:
        return None
    if t in ("si", "s", "1", "true", "x", "verdadero", "yes"):
        return True
    if t in ("no", "n", "0", "false", "falso"):
        return False
    return None


def leer_archivo(nombre: str, datos: bytes) -> list[dict]:
    """Filas del archivo como diccionarios por columna (claves de COLUMNAS). ValueError con el motivo si no se puede leer."""
    if len(datos) > MAX_BYTES:
        raise ValueError("El archivo no puede pasar de 10 MB")
    ext = (nombre or "").rsplit(".", 1)[-1].lower()
    if ext in ("xlsx", "xlsm"):
        filas = _leer_xlsx(datos)
    elif ext in ("csv", "txt"):
        filas = _leer_csv(datos)
    elif ext == "xls":
        raise ValueError("El formato .xls (Excel antiguo) no se admite: guarde el archivo como .xlsx o CSV")
    else:
        raise ValueError("Suba un archivo Excel (.xlsx) o CSV")
    filas = [f for f in filas if any(_texto(c) for c in f)]
    if not filas:
        raise ValueError("El archivo está vacío")
    if len(filas) > MAX_FILAS + 1:
        raise ValueError(f"El archivo tiene más de {MAX_FILAS} filas; divídalo en varios")
    cab = [_clave(c) for c in filas[0]]
    con_cabecera = "nombre" in cab
    idx = {k: cab.index(k) for k in COLUMNAS if k in cab} if con_cabecera else {k: i for i, k in enumerate(COLUMNAS[:11])}
    out = []
    for n, fila in enumerate(filas[1:] if con_cabecera else filas, start=2 if con_cabecera else 1):
        d = {"_fila": n}
        for k, i in idx.items():
            d[k] = fila[i] if i < len(fila) else None
        out.append(d)
    return out


def _leer_xlsx(datos: bytes) -> list[list]:
    try:
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(datos), read_only=True, data_only=True)
    except Exception as ex:  # noqa: BLE001
        raise ValueError(f"No se pudo leer el archivo de Excel ({ex})")
    hoja = wb.worksheets[0]
    for h in wb.worksheets:                              # la plantilla trae una hoja «Instrucciones»: se usa la hoja de ítems
        if _clave(h.title) not in ("instrucciones", "instructions"):
            hoja = h
            break
    filas = []
    for fila in hoja.iter_rows(values_only=True):
        filas.append([c for c in fila])
        if len(filas) > MAX_FILAS + 1:
            break
    wb.close()
    return filas


def _leer_csv(datos: bytes) -> list[list]:
    texto = datos.decode("utf-8-sig", errors="replace")
    primera = texto.splitlines()[0] if texto.splitlines() else ""
    sep = ";" if primera.count(";") >= primera.count(",") else ","
    return [list(r) for r in csv.reader(io.StringIO(texto), delimiter=sep)]


def plantilla_xlsx() -> bytes:
    """Plantilla con cabeceras, tres ejemplos y una hoja de instrucciones."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active; ws.title = "Ítems"
    ws.append(list(COLUMNAS))
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="0F766E")
    for e in EJEMPLOS:
        ws.append(e)
    anchos = {"A": 28, "B": 12, "C": 16, "D": 10, "E": 8, "F": 10, "G": 8, "H": 8, "I": 16, "J": 10, "K": 30, "L": 11, "M": 8, "N": 9, "O": 9}
    for k, v in anchos.items():
        ws.column_dimensions[k].width = v
    ws.freeze_panes = "A2"
    for col in ("C",):                                   # el CABYS como texto: Excel no debe convertirlo a número
        for celda in ws[col][1:]:
            celda.number_format = "@"
    wi = wb.create_sheet("Instrucciones")
    for i, linea in enumerate(INSTRUCCIONES, start=1):
        wi.cell(row=i, column=1, value=linea).font = Font(bold=(i == 1), size=12 if i == 1 else 11)
    wi.column_dimensions["A"].width = 120
    buf = io.BytesIO(); wb.save(buf)
    return buf.getvalue()
