"""Cifrado de secretos en reposo.

- Clave maestra del servidor: variable de entorno FE_MASTER_KEY (recomendado en cPanel) o `data/master.key`.
- Cada empresa tiene su propia clave (Fernet), generada al crearla y guardada en la base central cifrada con la maestra.
- Con la clave de la empresa se cifran: PIN del .p12, contraseña ATV, contraseña SMTP y el archivo .p12 en disco.
Los valores cifrados llevan el prefijo "enc:" para distinguirlos de texto plano heredado (que se cifra al arrancar).
"""
import base64
import logging
import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from .config import DATA_DIR

_MASTER_FILE = DATA_DIR / "master.key"
PREFIJO = "enc:"
CABECERA_ARCHIVO = b"FCR1"
log = logging.getLogger(__name__)

MENSAJE_MAESTRA = ("La clave maestra (FE_MASTER_KEY o data/master.key) no es la que cifró los secretos de esta empresa. "
                   "Si cambió la variable en el servidor, restaure la anterior; si se perdió, vuelva a cargar el .p12, "
                   "la contraseña de Hacienda y la de SMTP en Configuración.")


def _clave_maestra() -> bytes:
    if os.getenv("FE_MASTER_KEY"):
        return os.environ["FE_MASTER_KEY"].strip().encode()
    if _MASTER_FILE.exists():
        return _MASTER_FILE.read_bytes().strip()
    if os.getenv("FE_ENTORNO", "").lower() in ("produccion", "production", "prod"):
        log.warning("FE_MASTER_KEY no está definida: se generará data/master.key. En cPanel defina la variable en "
                    "Setup Python App › Environment variables y guárdela en un lugar seguro.")
    k = Fernet.generate_key()
    # Creación atómica: con varios procesos arrancando a la vez solo uno escribe; los demás releen el archivo.
    try:
        fd = os.open(_MASTER_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(k)
    except FileExistsError:
        k = _MASTER_FILE.read_bytes().strip()
    return k


def _fernet_maestra() -> Fernet:
    k = _clave_maestra()
    try:
        return Fernet(k)
    except (ValueError, TypeError) as ex:
        raise RuntimeError(
            "FE_MASTER_KEY inválida: debe ser una clave Fernet de 44 caracteres. Genere una con "
            "python -c \"from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())\" "
            "(no use el valor de FE_SECRET_KEY)") from ex


_maestra = _fernet_maestra()


def nueva_clave_empresa() -> str:
    """Devuelve la clave de una empresa nueva, ya cifrada con la maestra (lista para guardarse en Empresa.clave_cifrada)."""
    return _maestra.encrypt(Fernet.generate_key()).decode()


def fernet_empresa(clave_cifrada: str) -> Fernet:
    try:
        return Fernet(_maestra.decrypt(clave_cifrada.encode()))
    except InvalidToken as ex:
        raise ValueError(MENSAJE_MAESTRA) from ex


def cifrar(clave_cifrada: str, texto: str | None) -> str | None:
    """Cifra SIEMPRE el texto recibido (una contraseña que empiece por 'enc:' también). La detección del prefijo queda
    solo en la migración (cifrar_secretos_empresa) (R294)."""
    if texto is None or texto == "":
        return texto
    return PREFIJO + fernet_empresa(clave_cifrada).encrypt(texto.encode()).decode()


def descifrar(clave_cifrada: str | None, valor: str | None) -> str | None:
    if not valor:
        return valor
    if not valor.startswith(PREFIJO):
        return valor                      # texto plano heredado
    if not clave_cifrada:
        raise ValueError("La empresa no tiene clave de cifrado")
    try:
        return fernet_empresa(clave_cifrada).decrypt(valor[len(PREFIJO):].encode()).decode()
    except InvalidToken as ex:
        raise ValueError("No se pudo descifrar el secreto (clave de empresa incorrecta). " + MENSAJE_MAESTRA) from ex


def cifrar_archivo(clave_cifrada: str, datos: bytes) -> bytes:
    if datos.startswith(CABECERA_ARCHIVO):
        return datos
    return CABECERA_ARCHIVO + fernet_empresa(clave_cifrada).encrypt(datos)


def descifrar_archivo(clave_cifrada: str | None, datos: bytes) -> bytes:
    if not datos.startswith(CABECERA_ARCHIVO):
        return datos                      # archivo heredado sin cifrar
    try:
        return fernet_empresa(clave_cifrada).decrypt(datos[len(CABECERA_ARCHIVO):])
    except InvalidToken as ex:
        raise ValueError("No se pudo descifrar el archivo .p12. " + MENSAJE_MAESTRA) from ex


def asegurar_clave(e) -> bool:
    """Garantiza que la empresa tenga clave propia; devuelve True si la creó."""
    if not e.clave_cifrada:
        e.clave_cifrada = nueva_clave_empresa()
        return True
    return False


def cifrar_secretos_empresa(e, ruta_certificados: Path) -> bool:
    """Cifra en sitio los secretos en texto plano de una empresa (migración). Devuelve True si cambió algo."""
    cambio = asegurar_clave(e)
    for campo in ("password_hacienda", "p12_pin", "smtp_password"):
        v = getattr(e, campo)
        if v and not v.startswith(PREFIJO):
            setattr(e, campo, cifrar(e.clave_cifrada, v)); cambio = True
    if e.p12_nombre:
        p = ruta_certificados / e.p12_nombre
        if p.exists():
            datos = p.read_bytes()
            if not datos.startswith(CABECERA_ARCHIVO):
                p.write_bytes(cifrar_archivo(e.clave_cifrada, datos)); cambio = True
    return cambio
