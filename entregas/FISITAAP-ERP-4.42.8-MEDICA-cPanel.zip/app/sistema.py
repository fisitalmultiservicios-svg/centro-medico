"""Nombre y lema del sistema en un solo lugar (3.51, fase 5 de la fusión con FISITAAP).

Hoy el producto se llama FISITAAP by Brillante Agencia. Cuando Norman decida la marca del ERP, el administrador del sistema la cambia desde la
consola (Sitio web › Nombre del sistema) y todo lo que el código escribe (correos, asuntos, página pública, títulos) usa el nombre
nuevo sin tocar código. Se guarda en data/sistema.json; FE_NOMBRE_SISTEMA sirve de valor inicial en el servidor.

3.77: también el dominio público (fisitaap.com) y el correo de ventas; lo demás del código los lee con config.dominio_sistema() y
config.correo_ventas() en vez de escribir grupofactura.com."""
import json
import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .auth import superadmin
from .config import DATA_DIR, _sistema_cache, sistema

router = APIRouter(tags=["sistema"])
ARCHIVO = DATA_DIR / "sistema.json"


class SistemaIn(BaseModel):
    nombre: str = Field(min_length=2, max_length=40)
    eslogan: Optional[str] = Field("", max_length=90)
    dominio: Optional[str] = Field("", max_length=80)          # 3.77: fisitaap.com (sin https ni barras); vacío = el de la dirección pública
    correo_ventas: Optional[str] = Field("", max_length=120)   # vacío = ventas@dominio


@router.get("/api/sistema")
def ver_sistema():
    """Público: lo que la pantalla de entrada y el título necesitan antes de iniciar sesión. Con el enlace de ayuda (3.58)."""
    from . import sitio
    try:
        return {**sistema(), **sitio.soporte()}
    except Exception:  # noqa: BLE001  (la configuración del sitio no debe tumbar la pantalla de entrada)
        return sistema()


@router.get("/api/admin/sistema")
def admin_ver_sistema(_=Depends(superadmin)):
    return sistema()


@router.put("/api/admin/sistema")
def admin_guardar_sistema(data: SistemaIn, _=Depends(superadmin)):
    nombre = re.sub(r"\s+", " ", data.nombre).strip()
    if re.search(r"[<>\"\\]", nombre):
        raise HTTPException(400, "El nombre no puede llevar comillas ni los signos < >")
    dominio = re.sub(r"^https?://", "", (data.dominio or "").strip().lower()).strip("/")
    if dominio and not re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", dominio):
        raise HTTPException(400, "El dominio va sin https ni barras, por ejemplo fisitaap.com")
    correo = (data.correo_ventas or "").strip()
    if correo and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", correo, re.I):
        raise HTTPException(400, "El correo de ventas no es válido")
    cfg = {"nombre": nombre, "eslogan": re.sub(r"\s+", " ", data.eslogan or "").strip(), "dominio": dominio, "correo_ventas": correo}
    previo = _leer()
    if isinstance(previo.get(CLAVE_COBRO), dict):          # 4.28: el vencimiento y la gracia de los planes viven en el mismo archivo
        cfg[CLAVE_COBRO] = previo[CLAVE_COBRO]
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVO.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    _sistema_cache.clear()
    return sistema()


# ----------------------------------------------------------------------------- vencimiento y gracia de los planes (4.28)
# {"cobro_plan": {"dia_vence": 1..28 | null, "dias_gracia": 0..60}} en data/sistema.json. Sin la clave = como antes de la 4.28: cada
# empresa conserva su fecha y 0 días de gracia. Lo cambia solo el administrador del sistema (auth: /api/admin/cobro-plan).
CLAVE_COBRO = "cobro_plan"
_cache_cobro: dict = {}


def _leer() -> dict:
    try:
        d = json.loads(ARCHIVO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return d if isinstance(d, dict) else {}


def _limpio(d) -> dict:
    d = d if isinstance(d, dict) else {}
    try:
        dia = int(d.get("dia_vence")) if d.get("dia_vence") not in (None, "") else None
    except (TypeError, ValueError):
        dia = None
    try:
        gracia = int(d.get("dias_gracia") or 0)
    except (TypeError, ValueError):
        gracia = 0
    return {"dia_vence": dia if dia and 1 <= dia <= 28 else None, "dias_gracia": max(0, min(gracia, 60))}


def cobro_plan() -> dict:
    """{'dia_vence': int | None, 'dias_gracia': int}. Se relee solo cuando el archivo cambia (la consulta corre en cada petición)."""
    try:
        st = ARCHIVO.stat()
        firma = (str(ARCHIVO), st.st_mtime_ns, st.st_size)
    except OSError:
        return {"dia_vence": None, "dias_gracia": 0}
    if _cache_cobro.get("firma") != firma:
        _cache_cobro.update(firma=firma, valor=_limpio(_leer().get(CLAVE_COBRO)))
    return dict(_cache_cobro["valor"])


def guardar_cobro_plan(dia_vence, dias_gracia) -> dict:
    """Guarda solo la clave cobro_plan, sin tocar el nombre, el dominio ni el correo de ventas."""
    d = _leer()
    d[CLAVE_COBRO] = _limpio({"dia_vence": dia_vence, "dias_gracia": dias_gracia})
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVO.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    _cache_cobro.clear()
    _sistema_cache.clear()
    return cobro_plan()
