"""Exoneraciones de IVA de los clientes (Anexos v4.4, nodo Exoneracion; notas 10.1 y 23).

Cada cliente puede tener uno o varios documentos de exoneración o autorización. Los que emite Hacienda (EXONET, códigos 04 y 11)
se consultan en la API pública https://api.hacienda.go.cr/fe/ex?autorizacion=<número>: se guarda lo que responde Hacienda (no lo
que escribe el usuario), se comprueba que la identificación del beneficiario sea la del cliente y que esté vigente, y antes de
facturar se vuelve a consultar si la última verificación tiene más de 24 horas. Los demás tipos (diplomáticos, ley especial,
zona franca, otros…) no tienen consulta pública: se registran a mano con sus datos y el PDF de respaldo.

Al facturar, la exoneración se aplica solo a las líneas gravadas cuyo CABYS está autorizado (si el documento trae lista de
CABYS) y nunca por encima de la tarifa de la línea. El PDF del documento se guarda en data/exoneraciones/empresa_<id>/.
"""
import json
import re
import zlib
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlmodel import Field, Session, SQLModel, select

from .auth import Contexto, contexto, requiere, sesion_empresa
from .config import DATA_DIR, ahora_cr
from .db import Cliente, Documento, por_empresa

API_EXONERACION = "https://api.hacienda.go.cr/fe/ex"          # ?autorizacion=AL-00020402-24
DIR_EXO = DATA_DIR / "exoneraciones"
DIR_EXO.mkdir(exist_ok=True)
MAX_PDF = 5 * 1024 * 1024
REVERIFICAR = timedelta(hours=24)

# Nota 10.1: tipo de documento de exoneración o autorización
TIPOS = {"01": "Compras autorizadas por la Dirección General de Tributación", "02": "Ventas exentas a diplomáticos",
         "03": "Autorizado por ley especial", "04": "Exenciones Dirección General de Hacienda (autorización local genérica)",
         "05": "Transitorio V (servicios de ingeniería, arquitectura, topografía y obra civil)", "06": "Servicios turísticos inscritos ante el ICT",
         "07": "Transitorio XVII (recolección, clasificación y almacenamiento de reciclables)", "08": "Exoneración a zona franca",
         "09": "Exoneración de servicios complementarios para la exportación (art. 11 RLIVA)", "10": "Órgano de las corporaciones municipales",
         "11": "Exenciones Dirección General de Hacienda (autorización de impuesto local concreta)", "99": "Otros"}
SOLO_NOTAS = {"01", "05", "06", "07", "11"}        # nota 10.1: solo en notas de crédito o débito
CON_ARTICULO = {"02", "03", "06", "07", "08"}      # el artículo de la ley es obligatorio
DE_HACIENDA = {"04", "11"}                         # se validan contra Hacienda: no se registran a mano
# Nota 23: institución que emitió la exoneración
INSTITUCIONES = {"01": "Ministerio de Hacienda", "02": "Ministerio de Relaciones Exteriores y Culto", "03": "Ministerio de Agricultura y Ganadería",
                 "04": "Ministerio de Economía, Industria y Comercio", "05": "Cruz Roja Costarricense", "06": "Benemérito Cuerpo de Bomberos de Costa Rica",
                 "07": "Asociación Obras del Espíritu Santo", "08": "Federación Cruzada Nacional de Protección al Anciano (Fecrunapa)",
                 "09": "Escuela de Agricultura de la Región Húmeda (EARTH)", "10": "Instituto Centroamericano de Administración de Empresas (INCAE)",
                 "11": "Junta de Protección Social (JPS)", "12": "Autoridad Reguladora de los Servicios Públicos (Aresep)", "99": "Otros"}
DOCS_CON_EXONERACION = {"01", "02", "03", "04"}    # FE, ND, NC, TE (la FEE y la FEC no la usan en este sistema)


class ExoneracionCliente(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cliente_id: int = Field(index=True)
    origen: str = "hacienda"                    # hacienda (consultada en la API) | manual
    tipo: str = "04"                            # nota 10.1
    tipo_otro: Optional[str] = None             # obligatorio con 99
    numero: str
    articulo: Optional[int] = None
    inciso: Optional[int] = None
    institucion: str = "01"                     # nota 23
    institucion_otro: Optional[str] = None      # obligatorio con 99
    nombre_institucion: Optional[str] = None
    fecha_emision: str = ""                     # AAAA-MM-DDTHH:MM:SS (lo que dice el documento)
    fecha_vencimiento: Optional[str] = None     # AAAA-MM-DD; vacío = sin vencimiento indicado
    tarifa: float = 13                          # puntos de IVA exonerados (13 = todo el 13 %)
    cabys: Optional[str] = None                 # JSON [códigos] autorizados
    posee_cabys: bool = False                   # True: solo aplica a esos CABYS
    identificacion: Optional[str] = None        # beneficiario según el documento
    tipo_autorizacion: Optional[str] = None
    descripcion_tipo: Optional[str] = None
    verificada_en: Optional[datetime] = None    # última consulta exitosa a Hacienda (UTC)
    pdf_nombre: Optional[str] = None
    activa: bool = True
    notas: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


por_empresa(ExoneracionCliente)


# ------------------------------------------------------------------------------------------------ utilidades
def normalizar_numero(n: str) -> str:
    return re.sub(r"\s+", "", str(n or "")).upper()[:40]


def _ident(x) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", str(x or "")).upper().lstrip("0")


def misma_identificacion(a, b) -> bool:
    return bool(_ident(a)) and _ident(a) == _ident(b)


def _fecha(x) -> Optional[str]:
    v = str(x or "").strip()
    if not re.match(r"\d{4}-\d{2}-\d{2}", v):
        return None
    try:
        date.fromisoformat(v[:10])
    except ValueError:
        return None
    return v[:10]


def _fecha_hora(x) -> Optional[str]:
    v = str(x or "").strip()
    if not _fecha(v):
        return None
    m = re.match(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})", v)
    return m.group(1) if m else v[:10] + "T00:00:00"


def fecha_xml(x: str) -> str:
    """FechaEmisionEX (xs:dateTime con zona): la de Hacienda viene sin zona; se toma como hora de Costa Rica."""
    v = str(x or "").strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})", v):
        return v
    return (_fecha_hora(v) or "2000-01-01T00:00:00") + "-06:00"


def tarifa_de_hacienda(pct) -> Decimal:
    """porcentajeExoneracion de la API: en v4.4 son puntos de la tarifa (13 = todo el 13 %). Si viniera como porcentaje del
    impuesto (más de 13, p. ej. 100 o 50) se convierte a puntos sobre el 13 %."""
    try:
        p = Decimal(str(pct))
        if not p.is_finite():
            return Decimal(0)
    except Exception:  # noqa: BLE001
        return Decimal(0)
    if p > 13:
        p = Decimal(13) * min(p, Decimal(100)) / 100
    return max(Decimal(0), min(p, Decimal(13))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def lista_cabys(x) -> list[str]:
    if isinstance(x, str):
        try:
            x = json.loads(x)
        except ValueError:
            x = re.findall(r"\d{13}", x)
    if not isinstance(x, (list, tuple)):
        return []
    out = []
    for c in x:
        if isinstance(c, dict):
            c = c.get("codigo") or c.get("cabys") or ""
        c = re.sub(r"\D", "", str(c))
        if len(c) == 13 and c not in out:
            out.append(c)
    return out


def consultar(numero: str, timeout: float = 15) -> Optional[dict]:
    """Consulta la API pública de Hacienda. None si el número no existe; RuntimeError si Hacienda no responde."""
    n = normalizar_numero(numero)
    if not re.fullmatch(r"[A-Z0-9-]{3,40}", n):
        raise ValueError("El número de documento solo puede tener letras, dígitos y guiones (3 a 40)")
    try:
        r = httpx.get(API_EXONERACION, params={"autorizacion": n}, timeout=timeout)
    except httpx.HTTPError as ex:
        raise RuntimeError(f"Hacienda no respondió la consulta de exoneraciones ({type(ex).__name__}); intente en unos minutos")
    if r.status_code == 404:
        return None
    if r.status_code != 200:
        raise RuntimeError(f"Hacienda respondió {r.status_code} a la consulta de exoneraciones; intente en unos minutos")
    try:
        d = r.json()
    except ValueError:
        raise RuntimeError("Hacienda devolvió una respuesta que no se pudo leer; intente en unos minutos")
    if not isinstance(d, dict) or not (d.get("numeroDocumento") or d.get("autorizacion")):
        return None
    td = d.get("tipoDocumento") or {}
    tipo = str((td.get("codigo") if isinstance(td, dict) else td) or "04").zfill(2)
    inst = str(d.get("CodigoInstitucion") or d.get("codigoInstitucion") or "01").zfill(2)
    cabys = lista_cabys(d.get("cabys"))
    return {
        "numero": normalizar_numero(d.get("numeroDocumento") or n), "identificacion": str(d.get("identificacion") or ""),
        "tarifa": float(tarifa_de_hacienda(d.get("porcentajeExoneracion"))), "porcentaje_hacienda": d.get("porcentajeExoneracion"),
        "fecha_emision": _fecha_hora(d.get("fechaEmision")), "fecha_vencimiento": _fecha(d.get("fechaVencimiento")),
        "tipo": tipo if tipo in TIPOS else "04", "descripcion_tipo": (td.get("descripcion") if isinstance(td, dict) else None) or TIPOS.get(tipo),
        "institucion": inst if inst in INSTITUCIONES else "99", "nombre_institucion": d.get("nombreInstitucion") or INSTITUCIONES.get(inst),
        "cabys": cabys, "posee_cabys": bool(d.get("poseeCabys")) or bool(cabys), "tipo_autorizacion": d.get("tipoAutorizacion"),
        "autorizacion": d.get("autorizacion"), "codigo_cfia": d.get("codigoProyectoCFIA"),
    }


PATRON_NUMERO = re.compile(rb"(?<![A-Z0-9])([A-Z]{2}-\d{8}-\d{2})(?![0-9])")


def extraer_numero_pdf(datos: bytes, nombre: str = "") -> list[str]:
    """Busca números de autorización de EXONET (p. ej. AL-00020402-24) en el PDF: texto plano, flujos comprimidos (FlateDecode)
    y el nombre del archivo. Sin librerías externas: si el PDF es una imagen escaneada no se encuentra nada y se escribe a mano."""
    textos = [(nombre or "").upper().encode("utf-8", "ignore"), datos]
    total, pos, flujos = 0, 0, 0
    patron = re.compile(rb"stream\r?\n")
    while flujos < 500:                       # recorrido lineal: cada flujo se busca después del anterior (antes era cuadrático)
        m = patron.search(datos, pos)
        if not m:
            break
        ini = m.end()
        fin = datos.find(b"endstream", ini)
        if fin < 0:
            break
        pos = fin + 9; flujos += 1
        try:
            t = zlib.decompressobj().decompress(datos[ini:fin], 8 * 1024 * 1024)
        except zlib.error:
            continue
        total += len(t)
        textos.append(t)
        if total > 40 * 1024 * 1024:          # tope de memoria por PDF
            break
    encontrados: list[str] = []
    for t in textos:
        # texto partido por el operador TJ: [(AL-0002)12(0402-24)] TJ → se unen los fragmentos
        unido = re.sub(rb"\)\s*-?\d+(?:\.\d+)?\s*\(", b"", t)
        for cand in (t, unido, t.replace(b"\x00", b"")):
            for x in PATRON_NUMERO.findall(cand):
                s = x.decode()
                if s not in encontrados:
                    encontrados.append(s)
    return encontrados[:10]


def estado(x: "ExoneracionCliente", hoy: Optional[date] = None) -> str:
    hoy = hoy or ahora_cr().date()
    if not x.activa:
        return "inactiva"
    if x.fecha_vencimiento:
        try:
            v = date.fromisoformat(x.fecha_vencimiento[:10])
        except ValueError:
            return "vigente"
        if v < hoy:
            return "vencida"
        if v <= hoy + timedelta(days=30):
            return "por_vencer"
    return "vigente"


def a_dict(x: ExoneracionCliente) -> dict:
    d = x.model_dump()
    d["cabys"] = lista_cabys(x.cabys)
    d["estado"] = estado(x)
    d["tipo_nombre"] = TIPOS.get(x.tipo, x.tipo)
    d["institucion_nombre"] = x.nombre_institucion or INSTITUCIONES.get(x.institucion, x.institucion)
    d["solo_notas"] = x.tipo in SOLO_NOTAS
    d["tiene_pdf"] = bool(x.pdf_nombre)
    d.pop("pdf_nombre", None)
    return d


def _dir(eid: int):
    d = DIR_EXO / f"empresa_{eid}"
    d.mkdir(exist_ok=True)
    return d


def _cliente(s: Session, eid: int, cid: int) -> Cliente:
    c = s.get(Cliente, cid)
    if not c or c.empresa_id != eid:
        raise HTTPException(404, "Cliente no encontrado")
    return c


def _registro(s: Session, eid: int, xid: int) -> ExoneracionCliente:
    x = s.get(ExoneracionCliente, xid)
    if not x or x.empresa_id != eid:
        raise HTTPException(404, "Exoneración no encontrada")
    return x


def _aplicar_hacienda(x: ExoneracionCliente, h: dict):
    x.origen = "hacienda"; x.numero = h["numero"]; x.tipo = h["tipo"]; x.descripcion_tipo = h.get("descripcion_tipo")
    x.tipo_otro = ((h.get("descripcion_tipo") or "Autorización de Hacienda") + "     ")[:100].strip() if h["tipo"] == "99" else None
    x.institucion = h["institucion"]; x.nombre_institucion = h.get("nombre_institucion")
    x.institucion_otro = ((h.get("nombre_institucion") or "Otra institución") + " " * 5)[:160].strip() if h["institucion"] == "99" else None
    if x.institucion_otro and len(x.institucion_otro) < 5:
        x.institucion_otro = "Institución " + x.institucion_otro
    if x.tipo_otro and len(x.tipo_otro) < 5:
        x.tipo_otro = "Documento " + x.tipo_otro
    x.fecha_emision = h.get("fecha_emision") or x.fecha_emision or ahora_cr().strftime("%Y-%m-%dT00:00:00")
    x.fecha_vencimiento = h.get("fecha_vencimiento"); x.tarifa = float(h["tarifa"])
    x.cabys = json.dumps(h.get("cabys") or []); x.posee_cabys = bool(h.get("posee_cabys"))
    x.identificacion = h.get("identificacion"); x.tipo_autorizacion = h.get("tipo_autorizacion")
    x.verificada_en = datetime.now(timezone.utc)


def _validar_hacienda(x: ExoneracionCliente, h: dict):
    if not h.get("fecha_emision"):
        raise HTTPException(400, f"Hacienda no indica la fecha de emisión del documento {x.numero}: no se puede usar en comprobantes")
    try:
        modelo_fe(x, Decimal(13))
    except ValueError as ex:
        raise HTTPException(400, f"Los datos que publica Hacienda para {x.numero} no alcanzan para el comprobante ({ex}). Consulte con la institución")


def _consultar_http(numero: str) -> dict:
    try:
        h = consultar(numero)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))
    if not h:
        raise HTTPException(404, f"Hacienda no tiene registrado el documento de exoneración {normalizar_numero(numero)}. Revise el número "
                                 "(formato AL-00000000-00) o, si no es una autorización de Hacienda, regístrelo a mano")
    return h


def _utc(d: datetime) -> datetime:
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


# ------------------------------------------------------------------------------------------------ uso al facturar
def para_documento(s: Session, eid: int, xid: int, cliente: Optional[Cliente], tipo_doc: str, heredada: bool = False):
    """Valida que la exoneración se pueda usar en este comprobante. Devuelve (registro, aviso). `heredada`: la nota usa la
    misma exoneración del comprobante que corrige (se acepta aunque ya haya vencido o esté desactivada)."""
    x = _registro(s, eid, xid)
    if not cliente or x.cliente_id != cliente.id:
        raise HTTPException(400, "La exoneración elegida no pertenece al cliente del comprobante")
    if tipo_doc not in DOCS_CON_EXONERACION:
        raise HTTPException(400, "Este tipo de comprobante no admite exoneración (solo factura, tiquete y notas de crédito o débito)")
    if x.tipo in SOLO_NOTAS and tipo_doc not in ("02", "03"):
        raise HTTPException(400, f"Una exoneración tipo {x.tipo} ({TIPOS.get(x.tipo)}) solo se usa en notas de crédito o débito (nota 10.1 de Hacienda)")
    if not misma_identificacion(cliente.numero_id, x.identificacion or cliente.numero_id):
        raise HTTPException(400, f"El documento {x.numero} es de la identificación {x.identificacion}, no de {cliente.numero_id}")
    aviso = None
    if heredada:
        return x, aviso
    if not x.activa:
        raise HTTPException(400, f"La exoneración {x.numero} está desactivada en la ficha del cliente")
    if x.origen == "hacienda" and (not x.verificada_en or datetime.now(timezone.utc) - _utc(x.verificada_en) > REVERIFICAR):
        try:
            h = consultar(x.numero, timeout=8)
        except (RuntimeError, ValueError):
            h = False
            if x.verificada_en:
                aviso = f"Hacienda no respondió: se usó la exoneración {x.numero} con los datos verificados el {_utc(x.verificada_en).astimezone(ahora_cr().tzinfo):%d/%m/%Y}"
        if h is None:
            x.activa = False; s.add(x); s.commit()
            raise HTTPException(400, f"Hacienda ya no reporta el documento de exoneración {x.numero}: se desactivó en la ficha del cliente")
        if h:
            if not misma_identificacion(h.get("identificacion"), cliente.numero_id):
                raise HTTPException(400, f"Según Hacienda, el documento {x.numero} es de la identificación {h.get('identificacion')}, no de este cliente")
            _aplicar_hacienda(x, h); s.add(x); s.commit(); s.refresh(x)
    if estado(x) == "vencida":
        v = x.fecha_vencimiento
        raise HTTPException(400, f"La exoneración {x.numero} venció el {v[8:10]}/{v[5:7]}/{v[:4]}")
    if float(x.tarifa or 0) <= 0:
        raise HTTPException(400, f"La exoneración {x.numero} no indica tarifa exonerada")
    return x, aviso


def cubre(x: ExoneracionCliente, cabys: str) -> bool:
    return not x.posee_cabys or cabys in lista_cabys(x.cabys)


def modelo_fe(x: ExoneracionCliente, tarifa_linea: Decimal, tarifa_exonerada: Optional[Decimal] = None):
    """Nodo Exoneracion de una línea: tarifa exonerada = la del documento (o la que se indique, p. ej. la que llevó la factura que
    corrige una nota), nunca mayor que la de la línea."""
    from .fe.modelos import Exoneracion
    base = Decimal(str(x.tarifa)) if tarifa_exonerada is None else Decimal(str(tarifa_exonerada))
    t = min(base, Decimal(tarifa_linea)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return Exoneracion(tipo=x.tipo, tipo_otro=x.tipo_otro if x.tipo == "99" else None, numero=x.numero,
                       articulo=x.articulo, inciso=x.inciso, institucion=x.institucion,
                       institucion_otro=x.institucion_otro if x.institucion == "99" else None,
                       fecha_emision=fecha_xml(x.fecha_emision), tarifa=t)


# ------------------------------------------------------------------------------------------------ rutas
router = APIRouter(tags=["exoneraciones"])


class ConsultaIn(BaseModel):
    numero: str


class ExoneracionIn(BaseModel):
    origen: str = "hacienda"
    numero: str
    tipo: Optional[str] = None
    tipo_otro: Optional[str] = None
    articulo: Optional[int] = None
    inciso: Optional[int] = None
    institucion: Optional[str] = None
    institucion_otro: Optional[str] = None
    fecha_emision: Optional[str] = None
    fecha_vencimiento: Optional[str] = None
    tarifa: Optional[float] = None
    cabys: Optional[list[str]] = None
    notas: Optional[str] = None
    activa: Optional[bool] = None


def _validar_manual(x: ExoneracionCliente):
    if x.tipo not in TIPOS:
        raise HTTPException(400, "Tipo de documento de exoneración no válido (nota 10.1)")
    if x.tipo in DE_HACIENDA:
        raise HTTPException(400, "Las autorizaciones de Hacienda (tipos 04 y 11) se registran consultándolas en Hacienda con su número")
    if x.institucion not in INSTITUCIONES:
        raise HTTPException(400, "Institución no válida (nota 23)")
    if not 3 <= len(x.numero or "") <= 40:
        raise HTTPException(400, "El número de documento debe tener entre 3 y 40 caracteres")
    if x.tipo == "99" and not 5 <= len((x.tipo_otro or "").strip()) <= 100:
        raise HTTPException(400, "Con el tipo 99 (Otros) describa el tipo de documento (5 a 100 caracteres)")
    if x.institucion == "99" and not 5 <= len((x.institucion_otro or "").strip()) <= 160:
        raise HTTPException(400, "Con la institución 99 (Otros) escriba su nombre (5 a 160 caracteres)")
    if x.tipo in CON_ARTICULO and not x.articulo:
        raise HTTPException(400, f"Con el tipo {x.tipo} ({TIPOS[x.tipo]}) indique el artículo de la ley")
    for campo, nombre in (("articulo", "artículo"), ("inciso", "inciso")):
        v = getattr(x, campo)
        if v is not None and not (0 <= v <= 999999):
            raise HTTPException(400, f"El {nombre} debe ser un número de hasta 6 dígitos")
    if not _fecha_hora(x.fecha_emision):
        raise HTTPException(400, "Indique la fecha de emisión del documento de exoneración")
    if x.fecha_vencimiento and x.fecha_vencimiento < x.fecha_emision[:10]:
        raise HTTPException(400, "La fecha de vencimiento es anterior a la de emisión")
    t = float(x.tarifa or 0)
    if not (0 < t <= 13) or round(t, 2) != t:
        raise HTTPException(400, "La tarifa exonerada son los puntos de IVA que no se cobran: mayor que 0 y hasta 13, con dos decimales como máximo")


def _puede_usar(ctx: Contexto) -> bool:
    """Quien administra catálogos, factura o cobra en la caja: ve las exoneraciones y registra las que Hacienda verifica."""
    return ctx.puede("catalogos") or ctx.puede("facturar") or ctx.puede("pos")


def _exigir_lectura(ctx: Contexto):
    if not _puede_usar(ctx):
        raise HTTPException(403, "Su rol no tiene acceso a las exoneraciones de los clientes")


@router.get("/api/clientes/{cid}/exoneraciones")
def listar(cid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _exigir_lectura(ctx)
    _cliente(s, ctx.empresa.id, cid)
    q = select(ExoneracionCliente).where(ExoneracionCliente.empresa_id == ctx.empresa.id, ExoneracionCliente.cliente_id == cid)
    return [a_dict(x) for x in s.exec(q.order_by(ExoneracionCliente.id.desc())).all()]


@router.post("/api/exoneraciones/consultar")
def consultar_ruta(data: ConsultaIn, ctx: Contexto = Depends(contexto)):
    from . import auth
    auth.limitar_ip(ctx.request, "consulta", 60, 300, "Demasiadas consultas a Hacienda en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    h = _consultar_http(data.numero)
    return {**h, "tipo_nombre": TIPOS.get(h["tipo"]), "vencida": bool(h.get("fecha_vencimiento") and h["fecha_vencimiento"] < ahora_cr().strftime("%Y-%m-%d"))}


@router.post("/api/exoneraciones/leer-pdf")
def leer_pdf(archivo: UploadFile = File(...), ctx: Contexto = Depends(contexto)):
    _exigir_lectura(ctx)
    from . import auth
    auth.limitar_ip(ctx.request, "leer_pdf", 30, 300, "Demasiados PDF en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    datos = archivo.file.read(MAX_PDF + 1)
    if len(datos) > MAX_PDF:
        raise HTTPException(413, "El PDF supera 5 MB")
    if not datos.startswith(b"%PDF"):
        raise HTTPException(400, "El archivo no es un PDF")
    return {"numeros": extraer_numero_pdf(datos, archivo.filename or "")}


@router.post("/api/clientes/{cid}/exoneraciones")
def crear(cid: int, data: ExoneracionIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    # una autorización verificada con Hacienda la registra también quien factura o cobra en la caja (al momento de vender);
    # el registro manual (sin consulta) sigue siendo de quien administra los catálogos
    if not (ctx.puede("catalogos") or (data.origen == "hacienda" and _puede_usar(ctx))):
        raise HTTPException(403, "Su rol no puede registrar exoneraciones" + ("" if data.origen == "hacienda" else " a mano"))
    c = _cliente(s, ctx.empresa.id, cid)
    if not (c.numero_id or "").strip():
        raise HTTPException(400, "Este contacto no tiene identificación: agréguela antes de registrarle una exoneración")
    # el número de Hacienda se normaliza (AL-00020402-24); el de un registro manual (p. ej. «Ley 7210») se guarda como se escribió
    numero = normalizar_numero(data.numero) if data.origen == "hacienda" else re.sub(r"\s+", " ", (data.numero or "").strip())[:40]
    ya = s.exec(select(ExoneracionCliente).where(ExoneracionCliente.empresa_id == ctx.empresa.id, ExoneracionCliente.cliente_id == cid,
                                                  ExoneracionCliente.numero == numero)).first()
    if ya:
        raise HTTPException(409, f"El documento {numero} ya está registrado para este cliente")
    x = ExoneracionCliente(empresa_id=ctx.empresa.id, cliente_id=cid, numero=numero, notas=(data.notas or "").strip()[:500] or None)
    if data.origen == "hacienda":
        from . import auth
        auth.limitar_ip(ctx.request, "consulta", 60, 300, "Demasiadas consultas a Hacienda en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
        h = _consultar_http(numero)
        if not misma_identificacion(h.get("identificacion"), c.numero_id):
            raise HTTPException(400, f"Según Hacienda, el documento {h['numero']} es de la identificación {h.get('identificacion') or '(sin dato)'}, "
                                     f"no de {c.nombre} ({c.numero_id}). No se puede registrar en este cliente")
        if h.get("fecha_vencimiento") and h["fecha_vencimiento"] < ahora_cr().strftime("%Y-%m-%d"):
            raise HTTPException(400, f"Según Hacienda, el documento {h['numero']} venció el {h['fecha_vencimiento']}")
        if float(h["tarifa"]) <= 0:
            raise HTTPException(400, f"Hacienda no indica un porcentaje de exoneración para {h['numero']}")
        _aplicar_hacienda(x, h)
        _validar_hacienda(x, h)
        otro = s.exec(select(ExoneracionCliente).where(ExoneracionCliente.empresa_id == ctx.empresa.id, ExoneracionCliente.cliente_id == cid,
                                                        ExoneracionCliente.numero == x.numero)).first()
        if otro:
            raise HTTPException(409, f"El documento {x.numero} ya está registrado para este cliente")
    elif data.origen == "manual":
        x.origen = "manual"; x.tipo = (data.tipo or "").zfill(2); x.tipo_otro = (data.tipo_otro or "").strip() or None
        x.articulo, x.inciso = data.articulo, data.inciso
        x.institucion = (data.institucion or "01").zfill(2); x.institucion_otro = (data.institucion_otro or "").strip() or None
        x.nombre_institucion = x.institucion_otro if x.institucion == "99" else INSTITUCIONES.get(x.institucion)
        x.fecha_emision = _fecha_hora(data.fecha_emision) or ""; x.fecha_vencimiento = _fecha(data.fecha_vencimiento)
        x.tarifa = float(data.tarifa or 0); x.identificacion = c.numero_id
        cab = lista_cabys(data.cabys or [])
        x.cabys = json.dumps(cab); x.posee_cabys = bool(cab)
        x.descripcion_tipo = TIPOS.get(x.tipo)
        _validar_manual(x)
    else:
        raise HTTPException(400, "Origen no válido (hacienda o manual)")
    s.add(x); s.commit(); s.refresh(x)
    _auditar(ctx, "exoneracion_registrar", f"Cliente {c.nombre} ({c.numero_id}): documento {x.numero} tipo {x.tipo} tarifa {x.tarifa:g} ({x.origen})")
    return a_dict(x)


@router.put("/api/exoneraciones/{xid}")
def editar(xid: int, data: ExoneracionIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    x = _registro(s, ctx.empresa.id, xid)
    if data.activa is not None:
        x.activa = bool(data.activa)
    if data.notas is not None:
        x.notas = data.notas.strip()[:500] or None
    if x.origen == "manual" and data.tipo:   # los datos de una autorización de Hacienda solo cambian al volver a consultarla
        x.tipo = data.tipo.zfill(2)
        x.tipo_otro = (data.tipo_otro or "").strip() or None
        x.articulo, x.inciso = data.articulo, data.inciso
        if data.institucion:
            x.institucion = data.institucion.zfill(2)
        x.institucion_otro = (data.institucion_otro or "").strip() or None
        x.nombre_institucion = x.institucion_otro if x.institucion == "99" else INSTITUCIONES.get(x.institucion)
        if data.fecha_emision:
            x.fecha_emision = _fecha_hora(data.fecha_emision) or x.fecha_emision
        x.fecha_vencimiento = _fecha(data.fecha_vencimiento)
        if data.tarifa is not None:
            x.tarifa = float(data.tarifa)
        if data.cabys is not None:
            cab = lista_cabys(data.cabys); x.cabys = json.dumps(cab); x.posee_cabys = bool(cab)
        x.descripcion_tipo = TIPOS.get(x.tipo)
        _validar_manual(x)
    s.add(x); s.commit(); s.refresh(x)
    _auditar(ctx, "exoneracion_editar", f"Documento {x.numero} ({'activa' if x.activa else 'inactiva'})")
    return a_dict(x)


@router.post("/api/exoneraciones/{xid}/verificar")
def verificar(xid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not _puede_usar(ctx):
        raise HTTPException(403, "Su rol no puede verificar exoneraciones")
    x = _registro(s, ctx.empresa.id, xid)
    if x.origen != "hacienda":
        raise HTTPException(400, "Este documento se registró a mano: Hacienda no publica consulta para su tipo")
    from . import auth
    auth.limitar_ip(ctx.request, "consulta", 60, 300, "Demasiadas consultas a Hacienda en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    c = _cliente(s, ctx.empresa.id, x.cliente_id)
    h = _consultar_http(x.numero)
    if not misma_identificacion(h.get("identificacion"), c.numero_id):
        raise HTTPException(400, f"Según Hacienda, el documento {x.numero} es de la identificación {h.get('identificacion')}, no de este cliente")
    _aplicar_hacienda(x, h)
    _validar_hacienda(x, h)
    s.add(x); s.commit(); s.refresh(x)
    return a_dict(x)


@router.delete("/api/exoneraciones/{xid}")
def borrar(xid: int, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    x = _registro(s, ctx.empresa.id, xid)
    usada = s.exec(select(Documento.id).where(Documento.empresa_id == ctx.empresa.id, Documento.exoneracion_id == x.id)).first()
    if usada:                                # los comprobantes emitidos la citan: se conserva desactivada (con su PDF)
        x.activa = False; s.add(x); s.commit()
        _auditar(ctx, "exoneracion_desactivar", f"Documento {x.numero} (usado en comprobantes: se conserva desactivado)")
        return {"ok": True, "desactivada": True}
    pdf = x.pdf_nombre
    s.delete(x); s.commit()
    if pdf:
        try:
            (_dir(ctx.empresa.id) / pdf).unlink(missing_ok=True)
        except OSError:
            pass
    _auditar(ctx, "exoneracion_eliminar", f"Documento {x.numero}")
    return {"ok": True, "desactivada": False}


@router.post("/api/exoneraciones/{xid}/pdf")
def subir_pdf(xid: int, archivo: UploadFile = File(...), ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    x = _registro(s, ctx.empresa.id, xid)
    # quien factura o cobra solo agrega el PDF que falta (al registrarla); reemplazarlo es de quien administra los catálogos
    if not (ctx.puede("catalogos") or (_puede_usar(ctx) and not x.pdf_nombre)):
        raise HTTPException(403, "Su rol no puede cambiar el PDF de esta exoneración")
    datos = archivo.file.read(MAX_PDF + 1)
    if len(datos) > MAX_PDF:
        raise HTTPException(413, "El PDF supera 5 MB")
    if not datos.startswith(b"%PDF"):
        raise HTTPException(400, "El archivo no es un PDF")
    nombre = f"exoneracion_{x.id}.pdf"
    (_dir(ctx.empresa.id) / nombre).write_bytes(datos)
    x.pdf_nombre = nombre; s.add(x); s.commit()
    _auditar(ctx, "exoneracion_pdf", f"Documento {x.numero}: PDF cargado")
    return {"ok": True}


@router.get("/api/exoneraciones/{xid}/pdf")
def ver_pdf(xid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _exigir_lectura(ctx)
    x = _registro(s, ctx.empresa.id, xid)
    if not x.pdf_nombre or not re.fullmatch(r"exoneracion_\d+\.pdf", x.pdf_nombre) or not (_dir(ctx.empresa.id) / x.pdf_nombre).exists():
        raise HTTPException(404, "Sin PDF")
    return FileResponse(_dir(ctx.empresa.id) / x.pdf_nombre, media_type="application/pdf",
                        filename=f"exoneracion_{re.sub(r'[^A-Za-z0-9-]', '_', x.numero)}.pdf")


def _auditar(ctx: Contexto, accion: str, detalle: str):
    from .main import _auditar as aud
    aud(ctx, accion, detalle)
