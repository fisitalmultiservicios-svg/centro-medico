# -*- coding: utf-8 -*-
"""4.32 (bloque B6): la primera subida de la compañía armada ANTES de conectar (el cliente real: plan §5.3, contrato §2.6 y §3.6).

Sus ítems y clientes de antes son del rango 0, el mismo de la web, y nunca subieron. La web no puede saber sola cuáles son de la computadora
(la web borra de verdad lo que no tiene historia y la computadora conserva su copia), así que la decisión de «es de esta computadora» la toma el
programa con dos pruebas; la web solo acepta esas altas dentro de la carga inicial, en el rango 0, con la reserva hecha y siendo la única
instalación vigente. Nada de este módulo confirma ventas, cobros ni cierres de caja ni toca Bancos.

Lado web (lo llaman las rutas de app/sinc_datos.py, P1):
- reservar(...)               «reservar» de POST /api/sinc/datos: devuelve `max_dado` por tabla y sube el contador de ids del rango 0.
- max_dado(...)               lo mismo, solo lectura (POST /api/sinc/datos/filas).
- revisar_alta_rango0(...)    None si la web acepta el alta de un ítem o cliente del rango 0 con su mismo id; si no, el motivo.
- existencia_inicial(...)     el ajuste «Existencia del programa al conectarse» del ítem que sube (inventario.registrar_movimiento).
- id_nuevo_elemento(...)      id libre del rango de la terminal para un elemento de registro que choca (estado «renumerar»).
- accion_reenlazar(...)       acción «reenlazar» (tipo "_carga"): líneas, comprobantes y cobros viejos con el ítem o cliente vacío.

Lado programa (los usa la carga inicial, días 6-7; funciones sin red, probadas aquí):
- usados_antes_de_vincular, es_de_esta_computadora, clasificar   la prueba de «es local» y el veredicto de /datos/filas.
- pendiente_por_producto, existencias_para_alta                  la existencia del alta con lo vendido y todavía no subido sumado de vuelta.
- cambiar_id_elemento                                            el elemento de registro que la web guardó con otro id.
- heuristica_lineas, heuristica_recetas_extras                   la lista de choques (solo para leer).
- anotar_choque, lista_choques, guardar_heuristicas             la lista de choques guardada (tabla propia sinc_choque).
- pedido_reserva, al_reservar, paso_carga (paso_filas, paso_reenlace)  la carga inicial (gancho de sinc_datos_programa).
- retencion, completar_ops, avisar_renumerado                    ganchos: retención de comprobantes, _tomar_ops y «renumerar».
"""
import json
import logging
import math
import re
import unicodedata
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import text as _sql
from sqlmodel import Session, select

from . import inventario, modulos
from .db import Cliente, Documento, DocumentoLinea, Producto
from .modulos import RANGO

log = logging.getLogger(__name__)

TABLAS_RESERVA = ("producto", "cliente")          # solo estas dos usan sinc_id_propio (sinc._asignar_id_propio); los registros no
MODELOS = {"producto": Producto, "cliente": Cliente}
TABLA_IDS = "sinc_id_propio"                      # = sinc.TABLA_IDS (sinc._siguiente_id_propio)
TABLA_CARGA = "sinc_carga_inicial"                # web: la reserva de cada terminal (prueba de que su carga inicial empezó)
REFERENCIA_INICIAL = "Existencia del programa al conectarse"
CANTIDAD_MAXIMA = 1e12                            # como inventario.LineaAjusteIn (le=1e12)
LIMITE_REENLACE = 5000                            # comprobantes por llamada (la ruta ya corta el cuerpo en 256 KB)
LIMITE_LISTA = 500                                # filas de «faltan» y «choques» en la respuesta
TOPE_RESERVA = 1_000_000                          # revisión n.º 27: «reservar» no acepta un número más alto que lo vivo + esto
VENTAS = ("01", "04", "09")                       # = sinc.VENTAS


# ======================================================================================================================
# Ayudas
# ======================================================================================================================
def _entero(v) -> Optional[int]:
    return modulos._id_entero(v)


def _numero(v) -> Optional[float]:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    f = float(v)
    return f if math.isfinite(f) else None


def unica_vigente(v: dict, inst: Optional[dict]) -> bool:
    """La instalación `inst` es la ÚNICA vigente de la empresa (la ficha `sinc_vinculacion` = `v`): `instalaciones` tiene una sola ficha y es
    la suya (por prefijo del token). Las retiradas no cuentan."""
    if not isinstance(inst, dict) or not isinstance(v, dict):
        return False
    vigentes = [i for i in (v.get("instalaciones") or []) if isinstance(i, dict)]
    return len(vigentes) == 1 and bool(inst.get("prefijo")) and vigentes[0].get("prefijo") == inst.get("prefijo")


def _terminal(inst: Optional[dict]) -> int:
    return int((inst or {}).get("terminal") or 0)


def _crear_tabla_carga(s) -> None:
    s.execute(_sql(f"CREATE TABLE IF NOT EXISTS {TABLA_CARGA} (terminal INTEGER NOT NULL, tabla TEXT NOT NULL, max_dado INTEGER NOT NULL, "
                   "pedido INTEGER NOT NULL, cuando TEXT NOT NULL, PRIMARY KEY (terminal, tabla))"))


def _existe_tabla(s, nombre: str) -> bool:
    return s.execute(_sql("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = :n"), {"n": nombre}).first() is not None


def _reserva(s, terminal: int, tabla: str):
    """(max_dado, pedido) de la reserva guardada de esa terminal, o None."""
    if not terminal or not _existe_tabla(s, TABLA_CARGA):
        return None
    f = s.execute(_sql(f"SELECT max_dado, pedido FROM {TABLA_CARGA} WHERE terminal = :t AND tabla = :b"), {"t": terminal, "b": tabla}).first()
    return (int(f[0]), int(f[1])) if f else None


def _max_vivo(s, tabla: str) -> int:
    """MAX(ultimo, MAX(id)) del rango 0 (lo más alto que la web llegó a repartir) para `tabla` en (producto, cliente)."""
    alto = int(s.execute(_sql(f'SELECT COALESCE((SELECT MAX(id) FROM "{tabla}" WHERE id > 0 AND id < {RANGO}), 0)')).scalar_one() or 0)
    if _existe_tabla(s, TABLA_IDS):
        f = s.execute(_sql(f"SELECT ultimo FROM {TABLA_IDS} WHERE tabla = :t AND rango = 0"), {"t": tabla}).first()
        if f is not None:
            alto = max(alto, int(f[0] or 0))
    return alto


# ======================================================================================================================
# LADO WEB · reservar y max_dado (contrato §2.6 y §2.3)
# ======================================================================================================================
def max_dado(s, eid: int, inst: Optional[dict] = None) -> dict:
    """Solo lectura: {"producto": N, "cliente": M}. Si esa terminal ya reservó, devuelve el `max_dado` que se le dio entonces (el de ANTES de
    reservar): después de la reserva el contador vale lo pedido y la prueba «id mayor que max_dado» ya no serviría."""
    out = {}
    for tabla in TABLAS_RESERVA:
        r = _reserva(s, _terminal(inst), tabla)
        out[tabla] = r[0] if r else _max_vivo(s, tabla)
    return out


def reservar(s, eid: int, inst: Optional[dict], v: dict, pedido: dict) -> Optional[dict]:
    """«reservar» del cuerpo de POST /api/sinc/datos (solo en la carga inicial): {"producto": int, "cliente": int}, el mayor id del rango 0 que
    tiene el programa. Solo si `inst` es la única instalación vigente (si no: {} y nada se toca). Por tabla:
    1. crea sinc_id_propio y su fila (tabla, 0) si faltan (las dos sentencias de sinc._siguiente_id_propio; la primera escritura toma el
       bloqueo de escritura antes de leer);
    2. max_dado = MAX(ultimo, MAX(id) del rango 0), leído ANTES de reservar;
    3. UPDATE sinc_id_propio SET ultimo = MAX(ultimo, :pedido): desde aquí la web nunca crea un ítem o cliente con un id que el programa tiene.
    Todo en una transacción, que se confirma aquí. Un reintento (respuesta perdida) devuelve el mismo `max_dado` de la primera vez y NO vuelve
    a tocar el contador (revisión n.º 27: una reserva hecha no se agranda). Un número más alto que lo vivo + TOPE_RESERVA no se reserva (dejaría
    a la web sin números para crear ítems o clientes).
    Devuelve {"producto": {"max_dado": N}, "cliente": {"max_dado": M}} (solo las tablas pedidas y válidas). Revisión n.º 25: con un error
    pasajero devuelve None (no {}: {} quiere decir «no es la única instalación» y el programa lo guardaría como respuesta)."""
    if not unica_vigente(v, inst) or not isinstance(pedido, dict):
        return {}
    terminal = _terminal(inst)
    if terminal < 1:
        return {}
    out = {}
    try:
        _crear_tabla_carga(s)
        s.execute(_sql(f"CREATE TABLE IF NOT EXISTS {TABLA_IDS} (tabla TEXT NOT NULL, rango INTEGER NOT NULL, ultimo INTEGER NOT NULL, PRIMARY KEY (tabla, rango))"))
        for tabla in TABLAS_RESERVA:
            if tabla not in pedido:
                continue
            n = _entero(pedido.get(tabla))
            if n is None or n < 0 or n >= RANGO:
                continue
            p = {"t": tabla, "n": n}
            s.execute(_sql(f"INSERT INTO {TABLA_IDS} (tabla, rango, ultimo) SELECT :t, 0, 0 WHERE NOT EXISTS (SELECT 1 FROM {TABLA_IDS} WHERE tabla = :t AND rango = 0)"), p)
            previa = _reserva(s, terminal, tabla)
            if previa is not None:                     # n.º 27: la reserva ya está hecha; un reintento no mueve el contador
                out[tabla] = {"max_dado": previa[0]}
                continue
            dado = _max_vivo(s, tabla)
            if n > dado + TOPE_RESERVA:                # n.º 27: un número absurdo no se reserva (esa tabla queda sin reserva)
                log.warning("sinc_completar: reserva de %s fuera de lo razonable (terminal %s)", tabla, terminal)
                continue
            s.execute(_sql(f"UPDATE {TABLA_IDS} SET ultimo = MAX(ultimo, :n) WHERE tabla = :t AND rango = 0"), p)
            s.execute(_sql(f"INSERT INTO {TABLA_CARGA} (terminal, tabla, max_dado, pedido, cuando) VALUES (:term, :t, :d, :n, :c) "
                           "ON CONFLICT(terminal, tabla) DO UPDATE SET pedido = MAX(pedido, excluded.pedido)"),
                      {"term": terminal, "t": tabla, "d": dado, "n": n, "c": datetime.now(timezone.utc).isoformat(timespec="seconds")})
            out[tabla] = {"max_dado": dado}
        s.commit()
    except Exception:  # noqa: BLE001
        s.rollback()
        log.exception("sinc_completar: no se pudo reservar")
        return None                                    # n.º 25: pasajero; no es «no es la única instalación»
    return out


# ======================================================================================================================
# LADO WEB · altas del rango 0 en la carga inicial (plan §5.3 paso 3a)
# ======================================================================================================================
def revisar_alta_rango0(s, eid: int, inst: Optional[dict], v: dict, tipo: str, iid) -> Optional[str]:
    """Para aplicar_op (P1), op «alta» de `producto` o `cliente` con un id del rango 0 (1 a 9 999 999). None = se acepta con su mismo id.
    Si no, el motivo del rechazo: «eliminado» si la web tiene la lápida de ese dato (nada con lápida revive, I7); «no_valido» en lo demás:
    otra tabla, fuera del rango 0, no es la única instalación vigente, la terminal no reservó (no está en su carga inicial), el id es mayor
    que lo que reservó (la web podría darlo después) o la web ya tiene una fila con ese id (eso es un choque, no un alta)."""
    n = _entero(iid)
    if tipo not in TABLAS_RESERVA or n is None or n < 1 or n >= RANGO:
        return "no_valido"
    if _existe_tabla(s, "sinc_dato"):
        f = s.execute(_sql("SELECT borrado FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": str(n)}).first()
        if f is not None and f[0]:
            return "eliminado"
    if not unica_vigente(v, inst):
        return "no_valido"
    r = _reserva(s, _terminal(inst), tipo)
    if r is None or n > r[1]:
        return "no_valido"
    if s.get(MODELOS[tipo], n) is not None:
        return "no_valido"
    return None


def existencia_inicial(s, eid: int, producto: Producto, existencias) -> int:
    """El alta de un ítem en la carga inicial trae su existencia (`existencias: [{bodega_id, cantidad, costo_promedio}]`, ya con lo vendido y
    todavía no subido sumado de vuelta por el programa). Se registra con inventario.registrar_movimiento, tipo «inicial», referencia «Existencia
    del programa al conectarse»: el UPDATE atómico de la existencia, el costo promedio y la capa de costo (PEPS/UEPS), igual que cualquier
    entrada. Una cantidad negativa (vendido sin existencia) entra con permitir_negativo. Revisión n.º 26: de una bodega que la web no tiene
    solo entra a la principal lo `pendiente` (las ventas retenidas, que al subir la web descuenta de la principal); su existencia NO (el
    programa la conserva en esa bodega, que la bajada no iguala: sumarla a la principal la dejaba contada dos veces). No confirma (va en la transacción del alta). Un servicio o un ítem no
    inventariable no registra nada. Si ese ítem ya tiene su ajuste inicial, no se repite. Devuelve cuántos movimientos registró."""
    if producto is None or producto.es_servicio or not producto.inventariable or not isinstance(existencias, list):
        return 0
    if s.exec(select(inventario.MovimientoInventario.id).where(inventario.MovimientoInventario.producto_id == producto.id,
                                                              inventario.MovimientoInventario.referencia == REFERENCIA_INICIAL)).first() is not None:
        return 0
    por_bodega: dict[int, list] = {}
    principal = None
    for x in existencias[:200]:
        if not isinstance(x, dict):
            continue
        cant = _numero(x.get("cantidad"))
        costo = _numero(x.get("costo_promedio"))
        if cant is None or abs(cant) > CANTIDAD_MAXIMA:
            continue
        costo = costo if costo is not None and 0 <= costo <= CANTIDAD_MAXIMA else None
        bid = _entero(x.get("bodega_id"))
        b = s.get(inventario.Bodega, bid) if bid else None
        if b is None or (b.empresa_id not in (None, eid)):
            cant = _numero(x.get("pendiente"))        # n.º 26: solo lo retenido; sin el dato (o raro), nada
            if cant is None or abs(cant) > CANTIDAD_MAXIMA or abs(cant) < 1e-9:
                continue
            costo = None
            if principal is None:
                principal = inventario.bodega_principal(s, eid).id
            bid = principal
        acc = por_bodega.setdefault(bid, [0.0, None])
        acc[0] += cant
        if costo is not None:
            acc[1] = costo
    fecha = datetime.now(timezone.utc).astimezone(_tz_cr()).strftime("%Y-%m-%d")
    n = 0
    for bid, (cant, costo) in por_bodega.items():
        cant = round(cant, 6)
        if abs(cant) > 1e-9:
            inventario.registrar_movimiento(s, producto=producto, bodega_id=bid, tipo="inicial", cantidad=cant, fecha=fecha,
                                            costo_unitario=costo if (cant > 0 and costo is not None) else None, referencia=REFERENCIA_INICIAL,
                                            observaciones=REFERENCIA_INICIAL, permitir_negativo=True)
            n += 1
        if costo is not None:
            ex = inventario.existencia(s, producto.id, bid)
            if abs(float(ex.costo_promedio or 0) - costo) > 1e-9:
                ex.costo_promedio = costo; s.add(ex)
    if n:
        s.flush()
    return n


def _tz_cr():
    from .config import TZ_CR
    return TZ_CR


# ======================================================================================================================
# LADO WEB · elementos de registro que chocan (estado «renumerar», plan §5.3 paso 3c)
# ======================================================================================================================
def id_nuevo_elemento(s, eid: int, clave: str, terminal: int) -> int:
    """Un id libre del rango de `terminal` en la colección `clave` (para el alta de un elemento cuyo id ya existe en la web con otro contenido
    o con lápida): uno más que el mayor id de ese rango que la web tiene o tuvo (Registro.ultimo_id si está en ese rango, las filas de la
    colección y las líneas de sinc_dato de ese tipo, vivas o con lápida). Nunca devuelve un id ya usado en la web. No escribe nada."""
    t = int(terminal or 0)
    lo, hi = t * RANGO, (t + 1) * RANGO
    alto = lo
    r = modulos._registro(s, eid, clave)
    if r is not None:
        if lo < int(r.ultimo_id or 0) < hi:
            alto = max(alto, int(r.ultimo_id))
        if r.coleccion:
            m = s.execute(_sql("SELECT MAX(item_id) FROM registroitem WHERE empresa_id = :e AND clave = :c AND item_id > :lo AND item_id < :hi"),
                          {"e": eid, "c": clave, "lo": lo, "hi": hi}).scalar_one()
            alto = max(alto, int(m or 0))
        else:
            try:
                datos = json.loads(r.datos or "[]")
            except ValueError:
                datos = []
            for x in datos if isinstance(datos, list) else []:
                i = _entero(x.get("id")) if isinstance(x, dict) else None
                if i is not None and lo < i < hi:
                    alto = max(alto, i)
    if _existe_tabla(s, "sinc_dato"):
        for (ref,) in s.execute(_sql("SELECT ref FROM sinc_dato WHERE tipo <> '_'")).all():
            i = _entero(ref)
            if i is not None and lo < i < hi:
                alto = max(alto, i)
    nuevo = alto + 1
    if nuevo >= hi:
        raise ValueError("Se agotaron los números de esta instalación")
    return nuevo


# ======================================================================================================================
# LADO WEB · acción «reenlazar» (plan §5.3 paso 4, contrato §3.6)
# ======================================================================================================================
def _texto_lista(lista: list, x) -> None:
    if len(lista) < LIMITE_LISTA:
        lista.append(x)


def accion_reenlazar(s: Session, eid: int, ctx, ref: str, datos: dict, por: Optional[str]) -> dict:
    """Acción del núcleo {"tipo": "_carga", "ref": "_", "accion": "reenlazar"}. `datos` = {"comprobantes": [{"clave", "lineas": [{"numero",
    "producto_id"}], "cliente_id"}], "cobros": [{"referencia", "cliente_id"}]}.
    - Línea: pone `producto_id` SOLO si está vacío en la web y el ítem existe. Si apunta a OTRO ítem no se toca: va a `choques`.
    - Comprobante: `Documento.cliente_id` solo si está vacío y el cliente existe; si es otro, a `choques`.
    - Cobro (por su referencia «terminal:id:sello», Pago.origen_sinc): `Pago.cliente_id` igual.
    - Revisión n.º 5: lo vacío se llena SOLO si el ítem o cliente de la web con ese número es el MISMO de la venta: el nombre del ítem coincide
      con el de la línea (mismo_producto) y el del cliente con el receptor del comprobante o el cliente del cobro, o la cédula del cobro con la
      suya (mismo_cliente). Ese número hoy puede ser OTRO dato (creado en la web después y ya copiado por la 4.31): no se enlaza por si acaso;
      va a `choques` con "web": None y "motivo": "nombre" (en el programa, a la lista como «reenlace_nombre»).
    - Solo comprobantes que subió un programa (origen_sinc) y cobros con referencia de esta terminal o del rango 0 (los de antes de conectar;
      revisión n.º 35: estos solo si es la única instalación vigente).
    - NO mueve inventario: la existencia que subió con el alta ya trae esas ventas restadas. Tampoco Bancos ni saldos.
    - Idempotente: un reenvío no cambia nada. Un comprobante que la web todavía no tiene va a `faltan` (subirá por su camino).
    Confirma al final. Devuelve {"lineas", "comprobantes", "cobros", "faltan", "choques"} (cuentas y listas cortas, sin datos personales)."""
    from . import sinc
    if not isinstance(datos, dict):
        raise _error(400, "Faltan los datos para completar las ventas anteriores.")
    comprobantes = datos.get("comprobantes") or []
    cobros = datos.get("cobros") or []
    if not isinstance(comprobantes, list) or not isinstance(cobros, list) or len(comprobantes) > LIMITE_REENLACE or len(cobros) > LIMITE_REENLACE:
        raise _error(400, "Faltan los datos para completar las ventas anteriores.")
    vinc = sinc._leer(s, eid, sinc.CLAVE_VINC, {}) if ctx is not None else {}
    inst = sinc._instalacion_de(vinc, ctx) if ctx is not None else None
    terminal = _terminal(inst)
    if terminal < 1:
        raise _error(403, "Solo para instalaciones vinculadas")
    out = {"lineas": 0, "comprobantes": 0, "cobros": 0, "faltan": [], "choques": []}
    cache: dict = {}

    def obj(modelo, i):
        k = (modelo.__name__, i)
        if k not in cache:
            o = s.get(modelo, i)
            cache[k] = o if (o is not None and getattr(o, "empresa_id", eid) == eid) else None
        return cache[k]

    for c in comprobantes:
        if not isinstance(c, dict):
            continue
        clave = str(c.get("clave") or "")
        if len(clave) != 50:
            continue
        doc = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
        if doc is None:
            _texto_lista(out["faltan"], clave); continue
        if not doc.origen_sinc:
            continue                                   # emitido en la web: no es de ningún programa
        lineas = {ln.numero: ln for ln in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == doc.id)).all()}
        for x in c.get("lineas") or []:
            if not isinstance(x, dict):
                continue
            num, pid = _entero(x.get("numero")), _entero(x.get("producto_id"))
            ln = lineas.get(num) if num is not None else None
            if ln is None or pid is None or pid < 1:
                continue
            if ln.producto_id is None:
                p = obj(Producto, pid)
                if p is None:
                    continue
                if mismo_producto(p, ln.detalle):
                    ln.producto_id = pid; s.add(ln); out["lineas"] += 1
                else:
                    _texto_lista(out["choques"], {"tipo": "linea", "clave": clave, "numero": num, "web": None, "programa": pid, "motivo": "nombre"})
            elif int(ln.producto_id) != pid:
                _texto_lista(out["choques"], {"tipo": "linea", "clave": clave, "numero": num, "web": int(ln.producto_id), "programa": pid})
        cid = _entero(c.get("cliente_id"))
        if cid is not None and cid > 0:
            if doc.cliente_id is None:
                c_ = obj(Cliente, cid)
                if c_ is not None and mismo_cliente(c_, doc.receptor_nombre):
                    doc.cliente_id = cid; s.add(doc); out["comprobantes"] += 1
                elif c_ is not None:
                    _texto_lista(out["choques"], {"tipo": "comprobante", "clave": clave, "web": None, "programa": cid, "motivo": "nombre"})
            elif int(doc.cliente_id) != cid:
                _texto_lista(out["choques"], {"tipo": "comprobante", "clave": clave, "web": int(doc.cliente_id), "programa": cid})
    prefijos = (f"{terminal}:", "0:") if unica_vigente(vinc, inst) else (f"{terminal}:",)   # n.º 35
    for c in cobros:
        if not isinstance(c, dict):
            continue
        referencia = str(c.get("referencia") or "")[:60]
        cid = _entero(c.get("cliente_id"))
        if not referencia.startswith(prefijos) or cid is None or cid < 1:
            continue
        p = s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid, modulos.Pago.origen_sinc == referencia)).first()
        if p is None:
            _texto_lista(out["faltan"], referencia); continue
        if p.cliente_id is None:
            c_ = obj(Cliente, cid)
            if c_ is not None and mismo_cliente(c_, p.cliente_nombre, p.cliente_cedula):
                p.cliente_id = cid; s.add(p); out["cobros"] += 1
            elif c_ is not None:
                _texto_lista(out["choques"], {"tipo": "cobro", "referencia": referencia, "web": None, "programa": cid, "motivo": "nombre"})
        elif int(p.cliente_id) != cid:
            _texto_lista(out["choques"], {"tipo": "cobro", "referencia": referencia, "web": int(p.cliente_id), "programa": cid})
    s.commit()
    return out


def mismo_producto(p, detalle) -> bool:
    """Revisión n.º 5: el ítem `p` es el de una línea con ese `detalle` (sin las opciones entre paréntesis ni el combo, por nombre normalizado)."""
    if p is None:
        return False
    actual = normal(p.nombre)
    base, _ = _base_detalle(detalle)
    return bool(actual) and (normal(base) == actual or normal(detalle) == actual)


def mismo_cliente(c, nombre, cedula=None) -> bool:
    """Revisión n.º 5: el cliente `c` es el de un comprobante o cobro con ese nombre (o esa cédula). Sin nombre ni cédula no se puede saber: False."""
    if c is None:
        return False
    ced = re.sub(r"\D", "", str(cedula or ""))
    if ced and ced == re.sub(r"\D", "", str(getattr(c, "numero_id", "") or "")):
        return True
    n = normal(nombre)
    return bool(n) and n in {normal(getattr(c, "nombre", "")), normal(getattr(c, "nombre_comercial", ""))}


def _error(codigo: int, texto: str):
    from fastapi import HTTPException
    return HTTPException(codigo, texto)


# ======================================================================================================================
# LADO PROGRAMA · la prueba de «es de esta computadora» y el veredicto de /datos/filas (plan §5.3 paso 3a y 3d)
# ======================================================================================================================
def _fecha(texto) -> Optional[datetime]:
    """Una fecha ISO (con o sin zona; sin zona = hora de Costa Rica) en UTC, o None."""
    if isinstance(texto, datetime):
        d = texto
    else:
        t = str(texto or "").strip()
        if not t:
            return None
        try:
            d = datetime.fromisoformat(t.replace("Z", "+00:00"))
        except ValueError:
            try:
                d = datetime.fromisoformat(t[:10])
            except ValueError:
                return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=_tz_cr())
    return d.astimezone(timezone.utc)


def usados_antes_de_vincular(s, eid: int, vinculada_en) -> dict:
    """{"producto": {ids}, "cliente": {ids}} usados por comprobantes EMITIDOS EN ESTA COMPUTADORA (Documento.origen_sinc nulo) con fecha de
    emisión anterior a `vinculada_en` (sinc_local.vinculada_en): la línea con su ítem y el comprobante con su cliente. Es la prueba (1) de
    que un ítem o cliente del rango 0 es de esta computadora. Sin `vinculada_en` no hay prueba (conjuntos vacíos)."""
    corte = _fecha(vinculada_en)
    out = {"producto": set(), "cliente": set()}
    if corte is None:
        return out
    docs = s.exec(select(Documento.id, Documento.fecha_emision, Documento.cliente_id).where(Documento.empresa_id == eid, Documento.origen_sinc == None)).all()  # noqa: E711
    antes = []
    for did, fecha, cid in docs:
        f = _fecha(fecha)
        if f is not None and f < corte:
            antes.append(did)
            if cid and 0 < int(cid) < RANGO:
                out["cliente"].add(int(cid))
    for i in range(0, len(antes), 500):
        for (pid,) in s.execute(select(DocumentoLinea.producto_id).where(DocumentoLinea.documento_id.in_(antes[i:i + 500]), DocumentoLinea.producto_id != None)).all():  # noqa: E711
            if pid and 0 < int(pid) < RANGO:
                out["producto"].add(int(pid))
    return out


def es_de_esta_computadora(iid, usados_antes: set, max_dado_web) -> bool:
    """Prueba de que un ítem o cliente del rango 0 que la web no tiene («nunca») es de esta computadora: (1) lo usa un comprobante emitido aquí
    antes de conectar, o (2) su id es mayor que el `max_dado` que devolvió la web al reservar (la web nunca repartió ese número)."""
    n = _entero(iid)
    if n is None or n < 1 or n >= RANGO:
        return False
    if n in (usados_antes or set()):
        return True
    m = _entero(max_dado_web)
    return m is not None and n > m


def clasificar(estado: str, iid, usados_antes: set, max_dado_web, igual: bool = False) -> str:
    """Veredicto de la carga inicial para un ítem o cliente del rango 0 con v=0, según la respuesta de /datos/filas:
    - «nunca» con prueba de ser de aquí → "subir" (alta con su mismo id, con su existencia si es un ítem);
    - «nunca» sin prueba → "eliminado_web" (a la lista de choques como «¿eliminado en la página web?»; sigue aquí, no sube);
    - «existe» con el mismo contenido → "igual" (solo se anota la versión); con otro contenido → "choque" (a la lista);
    - «borrado» → "borrado" (se aplica la regla local: con historia queda inactivo).
    Cualquier otro estado → "esperar" (se pregunta otra vez)."""
    if estado == "nunca":
        return "subir" if es_de_esta_computadora(iid, usados_antes, max_dado_web) else "eliminado_web"
    if estado == "existe":
        return "igual" if igual else "choque"
    if estado == "borrado":
        return "borrado"
    return "esperar"


# ======================================================================================================================
# LADO PROGRAMA · la existencia del alta con lo pendiente sumado (plan §5.3 paso 3b)
# ======================================================================================================================
def pendiente_por_producto(s, eid: int) -> dict:
    """{(producto_id, bodega_id): cantidad} que hay que SUMAR DE VUELTA a la existencia local de un ítem al armar su alta: lo que movieron aquí
    los comprobantes que todavía no subieron nunca (Documento.sinc_en nulo) y que la web va a mover al recibirlos (ventas, notas de crédito y
    compras 08; de producción o internos; no rechazados: la regla de sinc._guardar_documentos). Se lee de los movimientos de inventario de esos
    comprobantes, así cuentan también los ingredientes de las recetas con su conversión de unidades: una venta de −2 suma +2; una devolución
    o compra de +3 suma −3."""
    docs = s.exec(select(Documento.id).where(
        Documento.empresa_id == eid, Documento.sinc_en == None,  # noqa: E711
        Documento.tipo_documento.in_(VENTAS + ("03", "08")),
        (Documento.ambiente == "produccion") | (Documento.estado == "interno"),
        Documento.estado != "rechazado")).all()
    ids = [int(d) for d in docs]
    out: dict = {}
    M = inventario.MovimientoInventario
    for i in range(0, len(ids), 500):
        for pid, bid, cant in s.execute(select(M.producto_id, M.bodega_id, M.cantidad).where(M.documento_id.in_(ids[i:i + 500]))).all():
            k = (int(pid), int(bid))
            out[k] = round(out.get(k, 0.0) - float(cant or 0), 6)
    return out


def existencias_para_alta(s, eid: int, pid: int, pendiente: Optional[dict] = None) -> list:
    """`existencias` del alta de un ítem: [{bodega_id, cantidad, costo_promedio, pendiente}] con la existencia local de cada bodega MÁS lo
    pendiente de esa bodega (pendiente_por_producto), y lo pendiente aparte. Se lee al armar la operación. Los comprobantes retenidos subirán
    después con el producto_id ya conocido y la web los descontará: si la existencia del alta ya los trajera restados, se restarían dos veces.
    `pendiente` aparte (revisión n.º 26): de una bodega que la web no tiene, la web solo toma eso (existencia_inicial)."""
    pend = pendiente if pendiente is not None else pendiente_por_producto(s, eid)
    por_bodega: dict[int, list] = {}
    for ex in s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == int(pid))).all():
        por_bodega[int(ex.bodega_id)] = [float(ex.cantidad or 0), float(ex.costo_promedio or 0), 0.0]
    for (p, b), q in pend.items():
        if p == int(pid):
            x = por_bodega.setdefault(b, [0.0, 0.0, 0.0])
            x[0] += q
            x[2] += q
    return [{"bodega_id": b, "cantidad": round(q, 6), "costo_promedio": round(c, 6), "pendiente": round(pe, 6)}
            for b, (q, c, pe) in sorted(por_bodega.items()) if abs(q) > 1e-9 or c > 0]


TABLA_BODEGAS_WEB = "sinc_bodega_web"


def recordar_bodegas_web(s, eid: int, bids) -> None:
    """Revisión n.º 26 (gancho para sinc._bajar_existencias, en el programa): las bodegas que mandó la web en la última bajada. Con eso la
    primera subida anota en la lista de choques la existencia de un ítem en una bodega que la web no tiene. No confirma."""
    ids = sorted({i for i in (_entero(b) for b in (bids or [])) if i is not None and i > 0})
    if not ids:
        return
    conn = s.connection()
    conn.execute(_sql(f"CREATE TABLE IF NOT EXISTS {TABLA_BODEGAS_WEB} (id INTEGER PRIMARY KEY)"))
    conn.execute(_sql(f"DELETE FROM {TABLA_BODEGAS_WEB}"))
    for i in ids:
        conn.execute(_sql(f"INSERT INTO {TABLA_BODEGAS_WEB} (id) VALUES (:i)"), {"i": i})


def bodegas_sin_web(s, eid: int, pid: int) -> list:
    """[{bodega, cantidad}] de la existencia local del ítem en bodegas que la web no tiene (según recordar_bodegas_web). Vacío si no se sabe."""
    if not _existe_tabla(s, TABLA_BODEGAS_WEB):
        return []
    web = {int(i) for (i,) in s.connection().execute(_sql(f"SELECT id FROM {TABLA_BODEGAS_WEB}")).all()}
    if not web:
        return []
    out = []
    for ex in s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == int(pid))).all():
        if int(ex.bodega_id) not in web and abs(float(ex.cantidad or 0)) > 1e-9:
            b = s.get(inventario.Bodega, ex.bodega_id)
            out.append({"bodega": (getattr(b, "nombre", None) or str(ex.bodega_id))[:60], "cantidad": round(float(ex.cantidad or 0), 6)})
    return out


# ======================================================================================================================
# LADO PROGRAMA · elemento de registro con id nuevo (plan §5.3 paso 3c, estado «renumerar»)
# ======================================================================================================================
def cambiar_id_elemento(s, eid: int, clave: str, viejo: int, nuevo: int) -> bool:
    """El elemento `viejo` de la colección `clave` pasa a llamarse `nuevo` (la web lo guardó con un id nuevo del rango de esta terminal porque
    el suyo ya existía allá con otro contenido). Cambia la fila y el `id` de su contenido; sube `ultimo_id` si `nuevo` está en el rango propio.
    No hace nada si `viejo` no existe o `nuevo` ya está usado. El que llama lo hace dentro de sinc_diario.aplicando(0) y confirma. True si
    cambió."""
    v, n = _entero(viejo), _entero(nuevo)
    if v is None or n is None or v == n:
        return False
    r = modulos._registro(s, eid, clave)
    if r is None or not r.coleccion:
        return False
    modulos._bloquear(s, r)
    filas = {f.item_id: f for f in s.exec(select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == eid, modulos.RegistroItem.clave == clave,
                                                                               modulos.RegistroItem.item_id.in_([v, n]))).all()}
    if v not in filas or n in filas:
        return False
    f = filas[v]
    try:
        x = json.loads(f.datos)
    except ValueError:
        x = {}
    if isinstance(x, dict):
        x["id"] = n
    f.item_id = n; f.datos = modulos._texto_item(x) if isinstance(x, dict) else f.datos
    f.actualizado = datetime.now(timezone.utc); s.add(f)
    r.version = int(r.version or 0) + 1
    if modulos.en_rango(n, modulos.rango_propio(eid)):
        r.ultimo_id = max(int(r.ultimo_id or 0), n)
    s.add(r); s.flush()
    return True


# ======================================================================================================================
# Lista de choques (solo para leer): las dos heurísticas (plan §5.3 paso 6)
# ======================================================================================================================
_NOTA = re.compile(r"\s*\([^()]*\)\s*$")


def normal(nombre) -> str:
    """Nombre normalizado para comparar: sin tildes, en minúsculas, solo letras y dígitos separados por un espacio."""
    t = unicodedata.normalize("NFKD", str(nombre or "")).encode("ascii", "ignore").decode().lower()
    return " ".join(re.findall(r"[a-z0-9]+", t))


def _base_detalle(detalle: str) -> tuple[str, bool]:
    """(nombre del ítem en la línea, si llevaba opciones u observaciones). La caja escribe «Nombre (opciones)» (caja.js: detalle + ' (' + nota + ')')
    y los combos «Ítem · Combo»."""
    d = str(detalle or "").strip()
    con_nota = bool(_NOTA.search(d))
    d = _NOTA.sub("", d)
    if " · " in d:
        d = d.split(" · ", 1)[0]
    return d, con_nota


def _lineas_por_producto(s, eid: int, solo_locales: bool) -> dict:
    q = select(DocumentoLinea.producto_id, DocumentoLinea.detalle).join(Documento, Documento.id == DocumentoLinea.documento_id).where(
        Documento.empresa_id == eid, DocumentoLinea.producto_id != None)  # noqa: E711
    if solo_locales:
        q = q.where(Documento.origen_sinc == None)  # noqa: E711
    out: dict[int, list] = {}
    for pid, det in s.execute(q).all():
        out.setdefault(int(pid), []).append(det or "")
    return out


def heuristica_lineas(s, eid: int, solo_locales: bool = True) -> list:
    """Ítems probablemente pisados antes de la 4.32 (el _bajar 4.31 escribió encima otro ítem de la web con el mismo id): el nombre que
    tienen hoy no coincide con el de las líneas de sus comprobantes (sin las opciones entre paréntesis ni el combo), comparando por nombre
    normalizado. La línea del comprobante no guarda el código del ítem, así que el código no entra en la comparación. Con `solo_locales`, solo
    los comprobantes emitidos en esta computadora. Devuelve [{tipo: "producto", ref, nombre, en_ventas, ventas, coinciden}] (solo los que
    no coinciden en ninguna línea), ordenado por id."""
    out = []
    lineas = _lineas_por_producto(s, eid, solo_locales)
    for pid in sorted(lineas):
        p = s.get(Producto, pid)
        if p is None:
            continue
        actual = normal(p.nombre)
        nombres: dict[str, int] = {}
        coinciden = 0
        for det in lineas[pid]:
            base, _ = _base_detalle(det)
            if normal(base) == actual or normal(det) == actual:
                coinciden += 1
            else:
                nombres[base] = nombres.get(base, 0) + 1
        if coinciden == 0 and nombres:
            en_ventas = max(nombres.items(), key=lambda kv: kv[1])[0]
            out.append({"tipo": "producto", "ref": str(pid), "nombre": p.nombre, "en_ventas": en_ventas[:120], "ventas": len(lineas[pid]), "coinciden": 0})
    return out


def heuristica_recetas_extras(s, eid: int, solo_locales: bool = True) -> list:
    """Ítems con ventas que llevaban opciones u observaciones (línea «Nombre (…)») y que hoy no tienen receta ni extras: `recetas` e `items_extra`
    usan el id del ítem como llave y el _bajar 4.31 los reemplazó enteros con los de la web. «Extras» cuenta la asignación manual
    (items_extra[id].modificadores) y los grupos de opciones activos (pos_modificadores) que nombran el ítem o su categoría. Devuelve
    [{tipo: "producto", ref, nombre, ventas_con_opciones}], ordenado por id."""
    recetas = {int(k) for k in inventario.recetas(s, eid)}
    extras = inventario.extras_items(s, eid)
    grupos = [g for g in (modulos.leer(s, eid, "pos_modificadores", []) or []) if isinstance(g, dict) and g.get("activo", True) is not False]
    out = []
    lineas = _lineas_por_producto(s, eid, solo_locales)
    for pid in sorted(lineas):
        con_opciones = sum(1 for det in lineas[pid] if _base_detalle(det)[1])
        if not con_opciones or pid in recetas:
            continue
        p = s.get(Producto, pid)
        if p is None:
            continue
        ex = extras.get(str(pid)) if isinstance(extras, dict) else None
        if isinstance(ex, dict) and ex.get("modificadores"):
            continue
        if any(pid in [_entero(x) for x in (g.get("productos") or [])] or (p.categoria and p.categoria in (g.get("categorias") or [])) for g in grupos):
            continue
        out.append({"tipo": "producto", "ref": str(pid), "nombre": p.nombre, "ventas_con_opciones": con_opciones})
    return out


# ======================================================================================================================
# LADO PROGRAMA · lista de choques (solo para leer; tabla propia «sinc_choque», en el programa)
# ======================================================================================================================
TABLA_CHOQUES = "sinc_choque"
CLASES_CHOQUE = {
    "eliminado_web": "¿Eliminado en la página web? Está en esta computadora y la página web no lo tiene.",
    "choque": "La página web tiene otro dato con el mismo número.",
    "no_subio": "No se pudo subir a la página web: esta computadora no es la única instalación conectada.",
    "renumerado": "Se subió a la página web con otro número porque ese ya estaba ocupado allá.",
    "reenlace": "Una venta o un cobro de la página web apunta a otro ítem o cliente.",
    "no_aceptado": "La página web no aceptó este dato al subirlo; sigue solo en esta computadora.",
    "reenlace_nombre": "Una venta o un cobro de antes de conectar no se unió a su ítem o cliente: el que hoy tiene ese número se llama distinto.",
    "bodega_sin_web": "Este ítem tiene existencia en una bodega que la página web no tiene: esa cantidad quedó solo en esta computadora.",
    "pisado_antes": "El nombre de este ítem no coincide con el de sus ventas: puede haber sido reemplazado por otro de la página web.",
    "sin_receta": "Este ítem se vendió con opciones y hoy no tiene receta ni extras.",
    "pisado_carga": "Al conectar, la página web tenía otro dato con el mismo número y quedó el de la página web (el de aquí está en el detalle).",
}


def _crear_tabla_choques(s) -> None:
    s.connection().execute(_sql(f"CREATE TABLE IF NOT EXISTS {TABLA_CHOQUES} (id INTEGER PRIMARY KEY, cuando TEXT NOT NULL, clase TEXT NOT NULL, "
                                "tipo TEXT NOT NULL, ref TEXT NOT NULL, nombre TEXT NOT NULL DEFAULT '', detalle TEXT NOT NULL DEFAULT '{}', "
                                "UNIQUE (clase, tipo, ref))"))


def anotar_choque(s, clase: str, tipo: str, ref, nombre: str = "", detalle=None) -> None:
    """Una fila de la lista de choques (una por clase, tipo y ref: repetirla la actualiza). No confirma: va en la transacción de `s`."""
    _crear_tabla_choques(s)
    s.connection().execute(_sql(
        f"INSERT INTO {TABLA_CHOQUES} (cuando, clase, tipo, ref, nombre, detalle) VALUES (:c, :cl, :t, :r, :n, :d) "
        "ON CONFLICT(clase, tipo, ref) DO UPDATE SET cuando = excluded.cuando, nombre = excluded.nombre, detalle = excluded.detalle"),
        {"c": datetime.now(timezone.utc).isoformat(timespec="seconds"), "cl": str(clase)[:30], "t": str(tipo)[:30], "r": str(ref)[:60],
         "n": str(nombre or "")[:120], "d": json.dumps(detalle if detalle is not None else {}, ensure_ascii=False, default=str)})


def lista_choques(s, eid: int = 0) -> list:
    """La lista de choques guardada: [{clase, texto, tipo, ref, nombre, detalle, cuando}] por clase y ref. Solo para leer."""
    if not _existe_tabla(s, TABLA_CHOQUES):
        return []
    out = []
    for cuando, clase, tipo, ref, nombre, detalle in s.connection().execute(_sql(
            f"SELECT cuando, clase, tipo, ref, nombre, detalle FROM {TABLA_CHOQUES} ORDER BY clase, tipo, CAST(ref AS INTEGER), ref")).all():
        try:
            det = json.loads(detalle or "{}")
        except ValueError:
            det = {}
        out.append({"clase": clase, "texto": CLASES_CHOQUE.get(clase, ""), "tipo": tipo, "ref": ref, "nombre": nombre, "detalle": det, "cuando": cuando})
    return out


def guardar_heuristicas(s, eid: int) -> int:
    """Pasa a la lista de choques las dos heurísticas (ítems pisados antes de la 4.32; ventas con opciones sin receta ni extras). No confirma."""
    n = 0
    for x in heuristica_lineas(s, eid):
        anotar_choque(s, "pisado_antes", "producto", x["ref"], x["nombre"], {"en_ventas": x["en_ventas"], "ventas": x["ventas"]})
        n += 1
    for x in heuristica_recetas_extras(s, eid):
        anotar_choque(s, "sin_receta", "producto", x["ref"], x["nombre"], {"ventas_con_opciones": x["ventas_con_opciones"]})
        n += 1
    return n


# ======================================================================================================================
# LADO PROGRAMA · la primera subida dentro de la carga inicial de app/sinc_datos_programa.py (P2: _avanzar_carga manda en «carga»)
#   «pendiente»: la llamada lleva `reservar` y se guarda `reservado`  ->  «filas»: lo del rango propio (P2)  ->
#   «reenlace»: paso_carga = /datos/filas del rango 0 y sus altas («completar»: "reenlace"), y con todas las altas con veredicto,
#   «reenlazar» y las heurísticas («completar»: "hecha")  ->  «hecha».
# ======================================================================================================================
LOTE_FILAS = 500                                   # contrato §2.3: hasta 500 refs por llamada
LOTE_REENLACE = 200_000                            # bytes por llamada de «reenlazar» (la ruta corta en 256 KB)


def _sdp():
    from . import sinc_datos_programa
    return sinc_datos_programa


def _sdatos():
    from . import sinc_datos
    return sinc_datos


def _estado(eid: int) -> dict:
    """sinc_datos_estado si el programa habla el protocolo 2; {} con el de la 4.31."""
    try:
        sdp = _sdp()
        if sdp.protocolo(eid) != sdp.PROTOCOLO:
            return {}
        return sdp.estado(eid)
    except Exception:  # noqa: BLE001
        return {}


# Validación f3 (recetas): registros de sinc.CLAVES_CATALOGO cuyos elementos hechos aquí antes de conectar SÍ suben en la carga inicial.
# Las recetas: sin ellas la web rebaja el plato y no sus ingredientes, y la bajada de existencias deshacía aquí el consumo. Si en la web ya
# hay otra receta con el mismo número o para el mismo plato, no sube: va a la lista de choques con los dos contenidos.
TIPOS_CATALOGO_CARGA = ("receta",)


def _tipos_carga() -> list:
    """Datos que entran en la carga inicial: ítems y clientes (si están declarados) y los elementos de registros que viajan en los dos
    sentidos y que el _bajar 4.31 no igualaba (no están en sinc.CLAVES_CATALOGO), más las recetas (TIPOS_CATALOGO_CARGA)."""
    from . import sinc
    sd, sdp = _sdatos(), _sdp()
    out = []
    for d in list(sd.DATOS.values()):
        if d.escribe != "todos" or d.viaja != "dos":
            continue
        if d.tipo in TABLAS_RESERVA and d.modelo is MODELOS[d.tipo]:
            out.append(d)
        elif d.modelo is None and sdp._forma(d) == "elemento" and (d.registro not in sinc.CLAVES_CATALOGO or d.tipo in TIPOS_CATALOGO_CARGA):
            out.append(d)
    return out


def _conocidas(s, tipo: str) -> set:
    """refs de ese tipo que ya tienen aquí versión de la web (v > 0) o lápida."""
    if not _existe_tabla(s, "sinc_dato"):
        return set()
    return {r for (r,) in s.connection().execute(_sql("SELECT ref FROM sinc_dato WHERE tipo = :t AND (v > 0 OR borrado)"), {"t": tipo}).all()}


def candidatos(s, eid: int, tipos: Optional[list] = None) -> list:
    """[(Dato, ref)] de la carga inicial: ítems, clientes y elementos de registro del RANGO 0 que la web nunca le mandó a esta computadora
    (v = 0, sin lápida) y sin operación propia pendiente. Lo del rango de la terminal lo pregunta sinc_datos_programa._paso_filas."""
    pend = set()
    if _existe_tabla(s, "sinc_cambio"):
        sdp = _sdp()
        pend = {(t, str(r)) for t, r in s.connection().execute(_sql("SELECT tipo, ref FROM sinc_cambio WHERE estado IN (:a, :e)"),
                                                               {"a": sdp.ABIERTA, "e": sdp.ENVIADA}).all()}
    out = []
    for d in (tipos if tipos is not None else _tipos_carga()):
        ya = _conocidas(s, d.tipo)
        if d.modelo is not None:
            ids = [int(i) for (i,) in s.execute(_sql(f'SELECT id FROM "{d.modelo.__tablename__}" WHERE id > 0 AND id < {RANGO} ORDER BY id')).all()]
        else:
            ids = sorted(i for i in (_entero(x.get("id")) for x in (modulos.leer(s, eid, d.registro, []) or []) if isinstance(x, dict))
                         if i is not None and 0 < i < RANGO)
        out.extend((d, str(i)) for i in ids if str(i) not in ya and (d.tipo, str(i)) not in pend)
    return out


VACIOS_RESERVA = 2                                 # revisión n.º 25: veces que la web debe contestar {} para creer «no es la única instalación»


def _antes_del_rango0(est: dict) -> bool:
    """La carga inicial todavía no preguntó por el rango 0 (paso_filas sin hacer)."""
    carga = est.get("carga")
    return carga in ("pendiente", "filas") or (carga == "reenlace" and est.get("completar") not in ("reenlace", "hecha"))


def reserva_lista(est: dict) -> bool:
    """Revisión n.º 25: ya hay respuesta firme de «reservar»: con números, o {} repetido VACIOS_RESERVA veces (un {} suelto puede ser un error
    pasajero de la web)."""
    r = est.get("reservado")
    if not isinstance(r, dict):
        return False
    return bool(r) or int(est.get("reservado_vacios") or 0) >= VACIOS_RESERVA


def pedido_reserva(eid: int) -> Optional[dict]:
    """`reservar` del cuerpo de POST /api/sinc/datos mientras la carga no preguntó por el rango 0 y todavía no hay respuesta firme (la web la
    repite igual: idempotente): el mayor id del rango 0 de ítems y clientes. None fuera de eso o con el protocolo de la 4.31."""
    est = _estado(eid)
    if not est or not _antes_del_rango0(est) or reserva_lista(est):
        return None
    from .db import engine_empresa
    with Session(engine_empresa(eid)) as s:
        return {t: int(s.execute(_sql(f'SELECT COALESCE(MAX(id), 0) FROM "{t}" WHERE id > 0 AND id < {RANGO}')).scalar_one() or 0) for t in TABLAS_RESERVA}


def al_reservar(eid: int, reservado) -> None:
    """La respuesta trajo `reservado` (contrato §2.2): se guarda en sinc_datos_estado («reservado»: {tabla: max_dado}). {} = no es la única
    instalación vigente: nada del rango 0 sube con su id (queda en la lista como «no_subio»). Una respuesta con números no se cambia después.
    Revisión n.º 25: un {} sí se reemplaza por una respuesta con números, y se cuenta («reservado_vacios»): paso_carga no lo da por firme
    hasta que se repite (un error pasajero de la web también contestaba {})."""
    est = _estado(eid)
    if not est or not isinstance(reservado, dict) or not _antes_del_rango0(est):
        return
    previo = est.get("reservado")
    if isinstance(previo, dict) and previo:
        return
    r = {}
    for t in TABLAS_RESERVA:
        x = reservado.get(t) if isinstance(reservado, dict) else None
        m = _entero(x.get("max_dado")) if isinstance(x, dict) else None
        if m is not None:
            r[t] = m
    if r:
        _sdp()._guardar_estado(eid, reservado=r)
    else:
        _sdp()._guardar_estado(eid, reservado={}, reservado_vacios=int(est.get("reservado_vacios") or 0) + 1)


def altas_sin_veredicto(s) -> bool:
    """Hay altas de ítems o clientes del rango 0 (solo las hace la carga inicial) todavía sin veredicto de la web."""
    if not _existe_tabla(s, "sinc_cambio"):
        return False
    sdp = _sdp()
    return s.connection().execute(_sql(
        "SELECT 1 FROM sinc_cambio WHERE op = 'alta' AND tipo IN ('producto', 'cliente') AND estado IN (:a, :e) "
        f"AND CAST(ref AS INTEGER) > 0 AND CAST(ref AS INTEGER) < {RANGO} LIMIT 1"), {"a": sdp.ABIERTA, "e": sdp.ENVIADA}).first() is not None


def _rango0_sin_version(s, tipo: str) -> set:
    ya = {int(r) for r in _conocidas(s, tipo) if str(r).isdigit()}
    return {int(i) for (i,) in s.execute(_sql(f'SELECT id FROM "{tipo}" WHERE id > 0 AND id < {RANGO}')).all()} - ya


def retencion(s, eid: int) -> dict:
    """Gancho de sinc_datos_programa.registrar_retencion (plan §5.3 paso 2): {"producto": ids, "cliente": ids} del rango 0 que la web todavía
    no le mandó a esta computadora (v = 0), mientras la primera subida no haya encolado sus altas (carga «pendiente» o «filas», o «reenlace»
    con la pregunta del rango 0 sin hacer). Sus comprobantes esperan (documentos_en_espera, con los ingredientes de las recetas): subirlos
    antes dejaba sus líneas sin ítem en la web. Después, las altas encoladas las retiene el propio sinc_datos_programa hasta su veredicto.
    Vacío en pausa (sube como la 4.31) y con la carga hecha."""
    est = _estado(eid)
    if not est or est.get("pausa_desde"):
        return {}
    carga = est.get("carga")
    out = {}
    if carga in ("pendiente", "filas") or (carga == "reenlace" and est.get("completar") not in ("reenlace", "hecha")):
        out = {t: _rango0_sin_version(s, t) for t in TABLAS_RESERVA}
    platos = _platos_con_receta_en_cola(s)
    if platos:                                     # f3: la venta de un plato espera a que su receta llegue a la web
        out["producto"] = set(out.get("producto") or set()) | platos
    return out


def _platos_con_receta_en_cola(s) -> set:
    """f3: los platos (producto_id) de las recetas cuya alta de la carga inicial todavía no tiene veredicto de la web. Si su venta subiera
    antes, la web rebajaría el plato y no sus ingredientes, y la bajada de existencias deshacía aquí el consumo."""
    if not _existe_tabla(s, "sinc_cambio"):
        return set()
    sdp = _sdp()
    out = set()
    for (datos,) in s.connection().execute(_sql("SELECT datos FROM sinc_cambio WHERE tipo = 'receta' AND op = 'alta' AND estado IN (:a, :e)"),
                                           {"a": sdp.ABIERTA, "e": sdp.ENVIADA}).all():
        try:
            fila = (json.loads(datos or "{}") or {}).get("fila")
        except (ValueError, AttributeError):
            continue
        pid = _entero(fila.get("producto_id")) if isinstance(fila, dict) else None
        if pid is not None:
            out.add(pid)
    return out


def completar_ops(s, eid: int, ops: list) -> None:
    """Al armar las ops que salen (sinc_datos_programa._tomar_ops): el alta de un ítem del rango 0 (solo la hace la carga inicial) lleva
    `existencias` con lo pendiente sumado (plan §5.3 paso 3b). Se lee cada vez que sale: un reenvío lleva la cuenta del momento, que no cambia
    con las ventas nuevas (bajan la existencia y suben lo pendiente por igual). Cambia `ops` en memoria. Nunca lanza."""
    try:
        pend = None
        for o in ops:
            n = _entero(o.get("ref"))
            if o.get("tipo") != "producto" or o.get("op") != "alta" or n is None or not 0 < n < RANGO or not isinstance(o.get("datos"), dict):
                continue
            if pend is None:
                pend = pendiente_por_producto(s, eid)
            o["datos"] = {**o["datos"], "existencias": existencias_para_alta(s, eid, n, pend)}
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_completar: no se pudo agregar la existencia del alta (%s)", type(ex).__name__)


def _pedir_filas_web(eid: int, refs: list) -> dict:
    """POST /api/sinc/datos/filas (contrato §2.3). Sin respuesta válida: sinc_datos_programa.SinConexionWeb (se pregunta en la vuelta
    siguiente). Ni el token ni el cuerpo van al registro."""
    import httpx
    sdp = _sdp()
    con = sdp._conexion(eid)
    if con is None:
        raise sdp.SinConexionWeb("sin conectar")
    url, token, _ = con
    codigo = None
    try:
        r = httpx.post(url + sdp.RUTA_FILAS, headers={"Authorization": "Bearer " + token}, json={"refs": refs}, timeout=httpx.Timeout(20, connect=3.0))
        codigo = r.status_code
        j = r.json() if codigo == 200 else None
    except Exception as ex:  # noqa: BLE001
        raise sdp.SinConexionWeb(type(ex).__name__) from None
    if not isinstance(j, dict) or not isinstance(j.get("filas"), list):
        raise sdp.SinConexionWeb(str(codigo))
    return j


def _vinculada_en(s, eid: int):
    from . import sinc
    return (sinc._cfg_local(s, eid) or {}).get("vinculada_en")


def _receta_de_la_web(s, eid: int, d, ref: str, local) -> bool:
    """f3: aquí ya hay otra receta, con versión de la web, para el mismo plato que `local` (la relectura la bajó)."""
    pid = _entero(local.get("producto_id")) if isinstance(local, dict) else None
    if pid is None:
        return False
    ya = _conocidas(s, d.tipo)
    return any(isinstance(x, dict) and str(_entero(x.get("id"))) in ya and str(_entero(x.get("id"))) != ref and _entero(x.get("producto_id")) == pid
               for x in (modulos.leer(s, eid, d.registro, []) or []))


def paso_filas(eid: int, pedir_filas=None) -> dict:
    """Carga «filas» (plan §5.3 pasos 3a y 3d): pregunta a la web por cada candidato y decide con clasificar: «subir» encola el alta con su
    mismo id (ítem o cliente: solo si la web reservó esa tabla; elemento: alta normal, la web le da otro id si choca); «eliminado_web»,
    «choque» y «no_subio» van a la lista y siguen aquí; «igual» y «borrado» se aplican aquí como cualquier fila de la web (borrado: la regla
    local, con historia queda inactivo). Devuelve las cuentas. Lanza SinConexionWeb (la carga sigue en «filas»)."""
    from .db import engine_empresa
    from . import sinc_diario
    sd, sdp = _sdatos(), _sdp()
    pedir = pedir_filas or (lambda refs: _pedir_filas_web(eid, refs))
    reservado = _estado(eid).get("reservado") or {}
    cuentas = {"subir": 0, "eliminado_web": 0, "choque": 0, "no_subio": 0, "igual": 0, "borrado": 0, "esperar": 0}
    with Session(engine_empresa(eid)) as s:
        cands = candidatos(s, eid)
        usados = usados_antes_de_vincular(s, eid, _vinculada_en(s, eid))
    for i in range(0, len(cands), LOTE_FILAS):
        lote = cands[i:i + LOTE_FILAS]
        j = pedir([{"tipo": d.tipo, "ref": ref} for d, ref in lote])
        resp = {(f.get("tipo"), str(f.get("ref"))): f for f in j.get("filas") or [] if isinstance(f, dict)}
        maximos = j.get("max_dado") if isinstance(j.get("max_dado"), dict) else {}
        for d, ref in lote:
            f = resp.get((d.tipo, ref)) or {}
            estado = f.get("estado")
            with Session(engine_empresa(eid)) as s:
                local = sdp.contenido_local(s, eid, d, ref)
                if local is None:
                    continue
                igual = estado == "existe" and isinstance(f.get("datos"), dict) and sd.huella(d, f["datos"]) == sd.huella(d, local)
                if d.modelo is not None:
                    clase = clasificar(estado, ref, usados.get(d.tipo, set()), maximos.get(d.tipo), igual)
                    if clase == "subir" and _entero(reservado.get(d.tipo)) is None:
                        clase = "no_subio"
                else:
                    clase = {"nunca": "subir", "existe": "igual" if igual else "subir", "borrado": "borrado"}.get(estado, "esperar")
                    if d.tipo in TIPOS_CATALOGO_CARGA and clase == "subir" and (estado == "existe" or _receta_de_la_web(s, eid, d, ref, local)):
                        clase = "choque"           # f3: otra receta en la web con ese número o para el mismo plato: no se duplica
                cuentas[clase] += 1
                nombre = sdp._nombre(local)
                if clase == "subir":
                    sdp.anotar(s, eid, d.tipo, ref, None, local)
                    if d.tipo == "producto":               # n.º 26: lo de una bodega que la web no tiene no sube
                        fuera = bodegas_sin_web(s, eid, int(ref))
                        if fuera:
                            anotar_choque(s, "bodega_sin_web", d.tipo, ref, nombre, {"bodegas": fuera})
                    s.commit()
                elif clase == "choque" and d.tipo in TIPOS_CATALOGO_CARGA:
                    anotar_choque(s, clase, d.tipo, ref, nombre, {"programa": local, "web": f.get("datos") if estado == "existe" else None})
                    s.commit()
                elif clase in ("eliminado_web", "choque", "no_subio"):
                    anotar_choque(s, clase, d.tipo, ref, nombre, {"web": sdp._nombre(f.get("datos"))} if clase == "choque" else {})
                    s.commit()
                elif clase in ("igual", "borrado") and int(f.get("v") or 0) > 0:
                    fila = {"tipo": d.tipo, "ref": ref, "v": int(f["v"]), "borrado": clase == "borrado",
                            "datos": f.get("datos") if clase == "igual" else None, "campos": {}}
                    with sinc_diario.aplicando(0):
                        sdp.aplicar_canonico(s, eid, fila)
                        s.commit()
    return cuentas


def datos_reenlace(s, eid: int) -> dict:
    """`datos` de la acción «reenlazar» (contrato §3.6): todo comprobante emitido aquí que ya subió, con sus líneas con ítem y su cliente, y
    todo cobro de aquí con cliente. La web solo llena lo vacío.
    Revisión n.º 5: el número del ítem o cliente de una venta vieja hoy puede ser OTRO dato (la 4.31 copió encima el de la web). Solo se
    manda la línea cuyo ítem de hoy se llama como la línea, y el cliente que coincide con el receptor del comprobante o el cliente del cobro
    (mismo_producto, mismo_cliente; la web lo revisa otra vez). Lo demás va en "saltados" ({tipo, ref, nombre, detalle} por ítem o cliente:
    paso_reenlace lo pasa a la lista como «reenlace_nombre»); "saltados" no viaja."""
    from . import sinc_diario
    docs = s.exec(select(Documento.id, Documento.clave, Documento.cliente_id, Documento.receptor_nombre).where(
        Documento.empresa_id == eid, Documento.origen_sinc == None, Documento.sinc_en != None)).all()  # noqa: E711
    saltados: dict = {}
    cache: dict = {}

    def obj(modelo, i):
        k = (modelo.__name__, i)
        if k not in cache:
            cache[k] = s.get(modelo, i)
        return cache[k]

    def saltar(tipo: str, i: int, en_ventas, cuenta: str) -> None:
        o = obj(Producto if tipo == "producto" else Cliente, i)
        x = saltados.setdefault((tipo, i), {"tipo": tipo, "ref": str(i), "nombre": (getattr(o, "nombre", "") or "") if o is not None else "",
                                            "detalle": {"en_ventas": str(en_ventas or "")[:120]}})
        x["detalle"][cuenta] = x["detalle"].get(cuenta, 0) + 1

    lineas: dict = {}
    ids = [int(d[0]) for d in docs]
    for i in range(0, len(ids), 500):
        for did, num, pid, det in s.execute(select(DocumentoLinea.documento_id, DocumentoLinea.numero, DocumentoLinea.producto_id, DocumentoLinea.detalle).where(
                DocumentoLinea.documento_id.in_(ids[i:i + 500]), DocumentoLinea.producto_id != None)).all():  # noqa: E711
            if mismo_producto(obj(Producto, int(pid)), det):
                lineas.setdefault(int(did), []).append({"numero": int(num), "producto_id": int(pid)})
            else:
                saltar("producto", int(pid), _base_detalle(det)[0], "ventas")
    comprobantes = []
    for did, clave, cid, receptor in docs:
        if cid and not mismo_cliente(obj(Cliente, int(cid)), receptor):
            saltar("cliente", int(cid), receptor, "comprobantes")
            cid = None
        if len(str(clave or "")) == 50 and (lineas.get(int(did)) or cid):
            comprobantes.append({"clave": clave, "lineas": lineas.get(int(did), []), "cliente_id": int(cid) if cid else None})
    cobros = []
    for p in s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid, modulos.Pago.origen_sinc == None,  # noqa: E711
                                               modulos.Pago.cliente_id != None)).all():  # noqa: E711
        if mismo_cliente(obj(Cliente, int(p.cliente_id)), p.cliente_nombre, p.cliente_cedula):
            cobros.append({"referencia": sinc_diario.ref_pago(p), "cliente_id": int(p.cliente_id)})
        else:
            saltar("cliente", int(p.cliente_id), p.cliente_nombre, "cobros")
    return {"comprobantes": comprobantes, "cobros": cobros, "saltados": list(saltados.values())}


def lotes_reenlace(datos: dict, tope: int = LOTE_REENLACE) -> list:
    """Parte `datos` en llamadas de hasta `tope` bytes y LIMITE_REENLACE comprobantes o cobros cada una."""
    out, actual, tam = [], {"comprobantes": [], "cobros": []}, 0
    for clave in ("comprobantes", "cobros"):
        for x in datos.get(clave) or []:
            t = len(json.dumps(x))
            if (actual["comprobantes"] or actual["cobros"]) and (tam + t > tope or len(actual[clave]) >= LIMITE_REENLACE):
                out.append(actual)
                actual, tam = {"comprobantes": [], "cobros": []}, 0
            actual[clave].append(x)
            tam += t
    if actual["comprobantes"] or actual["cobros"]:
        out.append(actual)
    return out


def paso_reenlace(eid: int, pedir_accion=None) -> Optional[dict]:
    """Carga «reenlace» (plan §5.3 pasos 4 y 6): si quedan altas sin veredicto, espera (None); si no, manda «reenlazar» por lotes, pasa a la
    lista lo que la web no tocó por apuntar a otro, guarda las dos heurísticas y deja la carga «hecha». Lanza SinConexionWeb / HTTPException
    (la carga sigue en «reenlace»; la acción es idempotente)."""
    from .db import engine_empresa
    pedir = pedir_accion or _sdp().pedir_accion
    with Session(engine_empresa(eid)) as s:
        if altas_sin_veredicto(s):
            return None
        datos = datos_reenlace(s, eid)
        for x in datos.get("saltados") or []:          # n.º 5: lo que no se puede unir con seguridad, a la lista
            anotar_choque(s, "reenlace_nombre", x["tipo"], x["ref"], x["nombre"], x["detalle"])
        s.commit()
    total = {"lineas": 0, "comprobantes": 0, "cobros": 0, "choques": len(datos.get("saltados") or [])}
    for lote in lotes_reenlace(datos):
        r = (pedir(eid, "_carga", "_", "reenlazar", lote, None) or {}).get("resultado") or {}
        for k in ("lineas", "comprobantes", "cobros"):
            total[k] += int(r.get(k) or 0)
        with Session(engine_empresa(eid)) as s:
            for c in r.get("choques") or []:
                if not isinstance(c, dict):
                    continue
                ref = c.get("referencia") if c.get("tipo") == "cobro" else c.get("clave")
                if c.get("tipo") == "linea":
                    ref = f"{ref}#{c.get('numero')}"
                clase = "reenlace_nombre" if c.get("motivo") == "nombre" else "reenlace"
                anotar_choque(s, clase, str(c.get("tipo") or ""), ref, "", {"web": c.get("web"), "programa": c.get("programa")})
                total["choques"] += 1
            s.commit()
    with Session(engine_empresa(eid)) as s:
        guardar_heuristicas(s, eid)
        s.commit()
    _sdp()._guardar_estado(eid, completar="hecha")
    return total


def paso_carga(eid: int, pedir_filas=None, pedir_accion=None) -> bool:
    """Gancho de sinc_datos_programa.registrar_paso_carga: corre en la carga «reenlace» (después de las /filas del rango propio). Primero la
    pregunta del rango 0 (paso_filas, una vez: «completar» = "reenlace"), después espera el veredicto de las altas y manda «reenlazar»
    («completar» = "hecha"). True = terminó (sinc_datos_programa deja la carga «hecha»). Nunca lanza: sin conexión o con un error, False y se
    reintenta en la vuelta siguiente."""
    est = _estado(eid)
    if not est or est.get("pausa_desde"):
        return False
    try:
        if est.get("completar") == "hecha":
            return True
        if est.get("completar") != "reenlace":
            if not reserva_lista(est):             # n.º 25: sin respuesta firme de «reservar» todavía (se pide en la vuelta siguiente)
                return False
            paso_filas(eid, pedir_filas)
            _sdp()._guardar_estado(eid, completar="reenlace")
        return paso_reenlace(eid, pedir_accion) is not None
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_completar empresa %s: la primera subida sigue pendiente (%s)", eid, type(ex).__name__)
        return False


def avisar_renumerado(s, tipo: str, viejo, nuevo, nombre: str = "") -> None:
    """Contrato §2.2 «renumerar»: el elemento quedó en la web con otro id (sinc_datos_programa._renumerar ya cambió el de aquí): a la lista.
    No confirma."""
    anotar_choque(s, "renumerado", tipo, nuevo, nombre, {"antes": str(viejo)})


def lo_resuelve_la_carga(s, eid: int, d, ref: str) -> bool:
    """Gancho de sinc_datos_programa._anotar (cambios y bajas; el alta la encola paso_filas): True = el cambio local de este dato NO se encola. Es un ítem, cliente o elemento de registro de
    la carga inicial (_tipos_carga) del RANGO 0 que la web todavía no le mandó a esta computadora (v = 0, sin lápida) mientras la pregunta del
    rango 0 está sin hacer (las mismas fases que retencion). Ese id en la web puede ser OTRO dato: una op «cambio» o «baja» con base 0 le
    caería encima, y la op pendiente además lo sacaba de candidatos() y dejaba que la relectura pisara el local. Lo resuelve la carga: la
    relectura (con conservar_en_relectura) o paso_carga, que sube el contenido vigente. En pausa no aplica (sube como la 4.31)."""
    n = _entero(ref)
    if n is None or not 0 < n < RANGO:
        return False
    est = _sdp()._leer_estado(s, eid)
    carga = est.get("carga")
    if est.get("pausa_desde") or not (carga in ("pendiente", "filas") or (carga == "reenlace" and est.get("completar") not in ("reenlace", "hecha"))):
        return False
    if d.tipo not in {x.tipo for x in _tipos_carga()}:
        return False
    return str(n) not in _conocidas(s, d.tipo)


def conservar_en_relectura(s, eid: int, d, ref: str, local, entrante) -> bool:
    """Gancho de sinc_datos_programa.aplicar_canonico en la relectura desde 0 de la carga inicial (plan §2.8 paso 2 y §5.3 paso 3c): una fila
    de la web va a pisar (o borrar, `entrante` None) un dato del RANGO 0 que aquí nunca tuvo versión de la web ni operación pendiente y que
    difiere. Sin esto el elemento local se perdía antes de que paso_filas lo subiera (ya tenía versión: dejaba de ser candidato).
    - Elemento de un registro que nunca viajó (los de _tipos_carga: fis_promociones): pasa aquí a un id nuevo del rango de la terminal y se
      anota «renumerado»; las /filas del rango propio (sinc_datos_programa._paso_filas, carga «filas») lo suben con ese id. True = el local ya
      no está en `ref` (la fila de la web se escribe sin pisar nada).
    - Los demás elementos y llaves (registros de CLAVES_CATALOGO: el _bajar 4.31 ya los igualaba): a la lista de choques como «pisado_carga»
      con los dos contenidos; la web gana como en la 4.31 (y queda también en sinc_pisado). Ítems y clientes: solo sinc_pisado. False.
    Solo con la carga inicial sin terminar. Va dentro de aplicando(0) y de la transacción de quien llama; no confirma."""
    n = _entero(ref)
    if local is None or n is None or not 0 < n < RANGO:
        return False
    sdp = _sdp()
    if sdp._leer_estado(s, eid).get("carga") not in ("pendiente", "filas", "reenlace"):
        return False
    terminal = sdp._terminal(s, eid)
    if (terminal >= 1 and isinstance(local, dict) and sdp._forma(d) == "elemento"
            and d.tipo in {x.tipo for x in _tipos_carga()} and d.tipo not in TIPOS_CATALOGO_CARGA):
        nuevo = id_nuevo_elemento(s, eid, d.registro, terminal)
        sdp._escribir(s, eid, d, ref, None)
        sdp._escribir(s, eid, d, str(nuevo), {**local, "id": nuevo})
        avisar_renumerado(s, d.tipo, ref, nuevo, sdp._nombre(local))
        return True
    if entrante is not None and sdp._forma(d) in ("elemento", "llave"):
        anotar_choque(s, "pisado_carga", d.tipo, ref, sdp._nombre(local), {"programa": local, "web": entrante})
    return False


# ======================================================================================================================
# Registro de la acción del núcleo (contrato §3.6): lo hace este módulo al importarse, si app/sinc_datos ya la ofrece
# ======================================================================================================================
ACCIONES_CARGA = {"reenlazar": accion_reenlazar}

try:  # noqa: SIM105
    from . import sinc_datos as _sinc_datos            # P1; importado desde sinc_datos_decl (cruce C-?) después de sinc_datos
    if hasattr(_sinc_datos, "accion_de_carga"):
        _sinc_datos.accion_de_carga("reenlazar", accion_reenlazar)
except Exception:  # noqa: BLE001  sin el núcleo todavía (o ya registrada): la ruta la toma de ACCIONES_CARGA
    pass

try:  # noqa: SIM105  ganchos del programa (sinc_datos_programa, P2): retención de comprobantes y paso de la carga inicial
    from . import sinc_datos_programa as _sdp_mod
    _sdp_mod.registrar_retencion(retencion)
    _sdp_mod.registrar_paso_carga(paso_carga)
except Exception:  # noqa: BLE001
    log.warning("sinc_completar: no se pudieron registrar los ganchos de la carga inicial")
