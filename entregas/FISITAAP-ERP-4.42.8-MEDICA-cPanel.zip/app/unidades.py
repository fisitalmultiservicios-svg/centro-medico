"""Unidades de las recetas (3.10): un ingrediente se indica en gramos, kilos, mililitros, litros, onzas, libras o unidades y se
convierte a la unidad en que el producto lleva su inventario (la unidad de medida de Hacienda del ítem). Un producto que se
inventaría por unidad (una botella, un saco) puede declarar su contenido (750 ml, 25 000 g) en los datos adicionales del ítem.
Misma tabla que app/static/js/pages/inventario/_unidades.js: cambiar las dos juntas."""

MASA = {"g": 1.0, "kg": 1000.0, "lb": 453.592, "oz": 28.3495}            # a gramos
VOLUMEN = {"ml": 1.0, "l": 1000.0, "gal": 3785.41, "oz": 29.5735}        # a mililitros
# unidad de Hacienda del producto → (familia, factor a gramos o mililitros)
PRODUCTO = {"G": ("masa", 1.0), "Kg": ("masa", 1000.0), "L": ("vol", 1000.0), "mL": ("vol", 1.0), "Gal": ("vol", 3785.41), "Oz": ("masa", 28.3495)}
UNIDADES_RECETA = ["g", "kg", "ml", "l", "oz", "lb", "unid"]


def _familia_contenido(extra: dict):
    """Contenido declarado del ítem: {contenido: 750, contenido_unidad: 'ml'} → ('vol', 750)."""
    try:
        c = float((extra or {}).get("contenido") or 0)
    except (TypeError, ValueError):
        c = 0.0
    if c <= 0:
        return None
    u = str((extra or {}).get("contenido_unidad") or "ml").lower()
    return ("masa" if u in ("g", "kg") else "vol", c * (1000.0 if u in ("kg", "l") else 1.0))


def a_unidad_producto(cantidad: float, unidad: str | None, unidad_producto: str, extra: dict | None = None):
    """Cantidad del ingrediente expresada en la unidad del producto; None si no hay forma de convertir (se usa 1:1 y se avisa)."""
    q = float(cantidad or 0)
    u = str(unidad or "").strip().lower()
    if u in ("", "unid", "unidad", "u"):
        return q
    fam_p = PRODUCTO.get(unidad_producto)
    if fam_p is None:
        cont = _familia_contenido(extra or {})
        if not cont:
            return None
        fam_p = cont
    familia, factor = fam_p
    if familia == "masa" and u in MASA:
        return q * MASA[u] / factor
    if familia == "vol" and u in VOLUMEN:
        return q * VOLUMEN[u] / factor
    return None
