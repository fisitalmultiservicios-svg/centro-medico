// Calculadora de aguinaldo (sitio público): suma de salarios del 1 de diciembre al 30 de noviembre entre 12.
(function () {
  const raiz = document.getElementById('calculadora');
  if (!raiz) return;
  const MESES = ['Diciembre 2025', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre'];
  const grid = document.getElementById('mesesGrid');
  grid.innerHTML = MESES.map((m, i) => '<label>' + m + '<input inputmode="decimal" data-mes="' + i + '" placeholder="0"></label>').join('');
  let modo = 'fijo';
  // 3.87: también los miles con coma (450,000 · 1,250,000 · 450,000.50), que antes se leían como 450 colones; el formato de siempre
  // (450.000 · 450.000,50 · 450000,50 · 1,5) se lee igual
  const num = v => {
    let s = String(v || '').replace(/[₡\s]/g, '');
    if (/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, '');
    else s = s.replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.');
    const n = parseFloat(s); return isFinite(n) && n > 0 ? n : 0;
  };
  const col = n => { const [e, d] = n.toFixed(2).split('.'); return '₡' + e.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + d; };
  function calcular() {
    let suma = 0;
    if (modo === 'fijo') {
      const meses = Math.min(12, Math.max(0, parseFloat(document.getElementById('meses').value) || 0));
      suma = num(document.getElementById('salario').value) * meses + num(document.getElementById('extras').value);
    } else {
      grid.querySelectorAll('input').forEach(i => { suma += num(i.value); });
    }
    document.getElementById('total').textContent = col(suma / 12);
    document.getElementById('detalle').textContent = 'Total de salarios del período: ' + col(suma);
  }
  raiz.querySelectorAll('[data-modo]').forEach(b => b.addEventListener('click', () => {
    modo = b.getAttribute('data-modo');
    raiz.querySelectorAll('[data-modo]').forEach(x => { const on = x === b; x.classList.toggle('activo', on); x.setAttribute('aria-selected', on ? 'true' : 'false'); });
    raiz.querySelectorAll('[data-panel]').forEach(p => { p.hidden = p.getAttribute('data-panel') !== modo; });
    calcular();
  }));
  raiz.addEventListener('input', calcular);
  calcular();
})();
