// Componentes compartidos (Vue 3, sin compilación). Se registran globalmente en app.js.
import { fmt, money, fecha, fechaHora, demo, CAT, precioCliente, api, toast, opts, monedas, mock, hoy, otroImpDe, otroImpLinea, otroImpTexto } from './api.js';
import { store, rutaPermitida, sesion } from './app.js';

export const PageHead = {
  props: { title: String, sub: String, crumbs: Array, soon: Boolean, mock: Boolean },
  // mock: módulo con funciones limitadas. En demo (FE_DATOS_EJEMPLO=1) muestra datos de ejemplo; en producción avisa que está en desarrollo (los registros sí se guardan en el servidor, por empresa) (R233).
  computed: { esDemo() { return demo.activo; } },
  template: `
  <div>
    <div class="crumbs" v-if="crumbs && crumbs.length"><template v-for="(c,i) in crumbs" :key="i"><a v-if="c.to" :href="'#'+c.to">{{c.label}}</a><span v-else>{{c.label}}</span><span v-if="i<crumbs.length-1"> › </span></template></div>
    <div class="page-head">
      <div><h1>{{title}} <span v-if="soon" class="soon">PRÓXIMAMENTE</span><span v-else-if="mock" class="mock" :title="esDemo ? 'Esta página muestra datos de ejemplo; el backend está pendiente' : 'Módulo en desarrollo: funciones limitadas (los datos sí se guardan en el servidor)'">{{esDemo ? 'DATOS DE EJEMPLO' : 'EN DESARROLLO'}}</span></h1><p class="sub" v-if="sub">{{sub}}</p></div>
      <div class="actions"><slot></slot></div>
    </div>
  </div>`,
};

export const Field = {
  props: { label: String, req: Boolean, help: String },
  template: `<label class="field"><span :class="{req}">{{label}}</span><slot></slot><span class="help" v-if="help">{{help}}</span></label>`,
};

// El fondo cierra solo si el clic EMPEZÓ y TERMINÓ en el fondo: arrastrar una selección de texto hacia afuera ya no cierra el modal (R260)
export const Modal = {
  props: { title: String, lg: Boolean },
  emits: ['close'],
  data() { return { fondo: false }; },
  template: `
  <div class="overlay" @mousedown.self="fondo=true" @mouseup="fondo && $event.target === $event.currentTarget && $emit('close'); fondo = false">
    <div class="modal" :class="{lg}">
      <div class="m-head"><h3>{{title}}</h3><button class="x" @click="$emit('close')">×</button></div>
      <div class="m-body"><slot></slot></div>
      <div class="m-foot" v-if="$slots.foot"><slot name="foot"></slot></div>
    </div>
  </div>`,
};

export const Drawer = {
  props: { title: String },
  emits: ['close'],
  data() { return { fondo: false }; },
  template: `
  <div class="overlay" @mousedown.self="fondo=true" @mouseup="fondo && $event.target === $event.currentTarget && $emit('close'); fondo = false">
    <div class="drawer">
      <div class="m-head"><h3 style="margin:0;font-size:16px">{{title}}</h3><button class="x" style="margin-left:auto;background:none;border:0;font-size:20px;cursor:pointer" @click="$emit('close')">×</button></div>
      <div class="m-body"><slot></slot></div>
      <div class="m-foot" v-if="$slots.foot"><slot name="foot"></slot></div>
    </div>
  </div>`,
};

export const Toggle = {
  props: { modelValue: Boolean, label: String },
  emits: ['update:modelValue'],
  template: `<span class="toggle" :class="{on: modelValue}" @click="$emit('update:modelValue', !modelValue)"><i></i><span v-if="label">{{label}}</span></span>`,
};

export const Empty = {
  props: { icon: { type: String, default: '📄' }, title: String, text: String },
  template: `<div class="empty"><div class="ico">{{icon}}</div><h3>{{title}}</h3><p v-if="text">{{text}}</p><slot></slot></div>`,
};

export const Badge = {
  props: { value: String },
  computed: {
    kind() {
      const v = (this.value || '').toLowerCase();
      if (/rechaz|error|vencid|anulad|inactiv|desactiv|rebote|cerrad/.test(v)) return 'danger';   // los negativos van primero ("desactivada" contiene "activ") (R267)
      if (/no conciliad|por cobrar|por pagar|pendiente|enviad|firmad|sin facturar|sin emitir|procesando|borrador|pausad|en proceso|abierta/.test(v)) return 'warn';
      if (/acept|cobrad|pagad|activ|emitid|conciliad|aprobad|entregad|facturad|recibid|le[ií]d|completad|hecho/.test(v)) return 'ok';
      if (/generad|no electr|finalizad|archivad/.test(v)) return '';
      return 'info';
    },
  },
  template: `<span class="badge" :class="kind">{{value}}</span>`,
};

// Tabla de datos con búsqueda, paginación y acciones. columns: [{key,label,num,fmt:'money'|'date'|'badge'|fn,width}]
export const DataTable = {
  // bulkActions: [{label, kind:'danger'|'sec'|'' , confirm:'texto', handler(rows)}] — acciones sobre la selección.
  // onBulkDelete(rows): atajo para "Eliminar seleccionados" (pide confirmación).
  props: { rows: Array, columns: Array, pageSize: { type: Number, default: 10 }, selectable: Boolean, emptyTitle: { type: String, default: 'Sin registros' }, emptyText: String, search: String,
           bulkActions: { type: Array, default: () => [] }, onBulkDelete: Function },
  emits: ['row-click', 'update:selected'],
  data() { return { page: 1, size: this.pageSize, sel: [], ord: null, dir: 1 }; },   // ord/dir: columna y sentido del orden (3.29)
  computed: {
    filtered() {
      const q = (this.search || '').toLowerCase().trim();
      if (!q) return this.rows || [];
      // 4.24: `busca` en una columna = texto de más por el que también se encuentra la fila aunque no se muestre (los códigos alternos de un ítem)
      return (this.rows || []).filter(r => this.columns.some(c => String(this.cell(r, c)).toLowerCase().includes(q) || (c.busca && String(c.busca(r) ?? '').toLowerCase().includes(q))));
    },
    // orden por columna (3.29): números como números, lo demás como texto (con «numérico» para 10 después de 9); se ordena todo el
    // resultado, no solo la página visible
    ordenadas() {
      const c = this.ord && this.columns.find(x => x.key === this.ord); if (!c) return this.filtered;
      const raw = r => { const v = c.key.split('.').reduce((o, k) => (o == null ? o : o[k]), r); return c.orden ? c.orden(r) : (v === undefined || v === null ? (typeof c.fmt === 'function' ? c.fmt(v, r) : '') : v); };
      const num = v => (typeof v === 'number' ? v : (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)) ? Number(v) : null));
      const lista = this.filtered.map((r, i) => ({ r, i, v: raw(r) }));
      lista.sort((a, b) => { const na = num(a.v), nb = num(b.v); let d; if (na !== null && nb !== null) d = na - nb; else if (a.v === '' || a.v === null || a.v === undefined) d = 1; else if (b.v === '' || b.v === null || b.v === undefined) d = -1; else d = String(a.v).localeCompare(String(b.v), 'es', { numeric: true, sensitivity: 'base' }); return (d || a.i - b.i) * this.dir; });
      return lista.map(x => x.r);
    },
    pages() { return Math.max(1, Math.ceil(this.filtered.length / this.size)); },
    view() { const p = Math.min(this.page, this.pages); return this.ordenadas.slice((p - 1) * this.size, p * this.size); },
    allSel() { return this.filtered.length > 0 && this.filtered.every(r => this.sel.includes(this.key(r))); },
    someSel() { return !this.allSel && this.filtered.some(r => this.sel.includes(this.key(r))); },
    selRows() { return (this.rows || []).filter(r => this.sel.includes(this.key(r))); },
  },
  watch: {
    rows() { this.page = 1; this.sel = []; this.$emit('update:selected', []); },
    search() { this.page = 1; },
    size() { this.page = 1; },      // al cambiar "resultados por página" se vuelve a la primera (antes: "201-50 de 50 · Página 5 de 1") (R266)
    allSel(v) { if (this.$refs.master) this.$refs.master.indeterminate = !v && this.someSel; },
    someSel(v) { if (this.$refs.master) this.$refs.master.indeterminate = v; },
  },
  methods: {
    key(r) { return r.id ?? r.codigo ?? r.numero ?? JSON.stringify(r); },
    ordenar(c) { if (c.sortable === false) return; if (this.ord === c.key) { if (this.dir === 1) this.dir = -1; else { this.ord = null; this.dir = 1; } } else { this.ord = c.key; this.dir = 1; } this.page = 1; },
    isSel(r) { return this.sel.includes(this.key(r)); },
    toggle(r) { const k = this.key(r); const i = this.sel.indexOf(k); i >= 0 ? this.sel.splice(i, 1) : this.sel.push(k); this.$emit('update:selected', this.selRows); },
    // El checkbox maestro marca/desmarca TODOS los resultados filtrados (no solo la página visible)
    toggleAll() { this.sel = this.allSel ? [] : this.filtered.map(r => this.key(r)); this.$emit('update:selected', this.selRows); },
    clearSel() { this.sel = []; this.$emit('update:selected', []); },
    async runBulk(a) {
      const rows = this.selRows;
      if (a.confirm && !confirm(a.confirm.replace('{n}', rows.length))) return;
      await a.handler(rows);
      this.clearSel();
    },
    async bulkDelete() {
      const rows = this.selRows;
      if (!confirm(`¿Eliminar ${rows.length} ${rows.length === 1 ? 'registro' : 'registros'}? Esta acción no se puede deshacer.`)) return;
      await this.onBulkDelete(rows);
      this.clearSel();
    },
    cell(r, c) {
      const v = c.key.split('.').reduce((o, k) => (o == null ? o : o[k]), r);
      if (typeof c.fmt === 'function') return c.fmt(v, r);
      if (c.fmt === 'money') return money(v, r.moneda || c.moneda || 'CRC');
      if (c.fmt === 'num') return fmt(v, c.dec ?? 2);
      if (c.fmt === 'date') return fecha(v);
      return v ?? '';
    },
    isBadge(c) { return c.fmt === 'badge'; },
  },
  template: `
  <div>
    <div class="selbar" v-if="selectable && sel.length">
      <b>{{sel.length}}</b> {{sel.length===1?'seleccionado':'seleccionados'}}
      <a class="link" @click="toggleAll" v-if="!allSel">Seleccionar los {{filtered.length}} resultados</a>
      <slot name="bulk" :rows="selRows"></slot>
      <button v-for="a in bulkActions" :key="a.label" class="btn sm" :class="a.kind||'sec'" @click="runBulk(a)">{{a.label}}</button>
      <button v-if="onBulkDelete" class="btn sm danger" @click="bulkDelete">🗑 Eliminar seleccionados</button>
      <button class="btn ghost sm" style="margin-left:auto" @click="clearSel">Quitar selección</button>
    </div>
    <div class="table-wrap" v-if="filtered.length">
      <table class="tbl">
        <thead><tr>
          <th v-if="selectable" style="width:32px"><input type="checkbox" ref="master" :checked="allSel" @change="toggleAll" title="Seleccionar todos los resultados"></th>
          <th v-for="c in columns" :key="c.key" :class="{num:c.num, ordenable: c.sortable !== false, ordenada: ord===c.key}" :style="c.width?{width:c.width}:null" @click="ordenar(c)" :title="c.sortable === false ? '' : 'Ordenar por ' + c.label"><span>{{c.label}}</span><span class="orden" v-if="ord===c.key">{{dir===1 ? '▲' : '▼'}}</span></th>
          <th v-if="$slots.actions" style="text-align:right"></th>
        </tr></thead>
        <tbody>
          <tr v-for="r in view" :key="key(r)" :class="{sel: isSel(r), atenuada: r.atenuada === true}" @click="$emit('row-click', r)">
            <td v-if="selectable" @click.stop><input type="checkbox" :checked="isSel(r)" @change="toggle(r)"></td>
            <td v-for="c in columns" :key="c.key" :class="[{num:c.num}, c.class]">
              <Badge v-if="isBadge(c)" :value="String(cell(r,c))"></Badge>
              <a v-else-if="c.link" class="link" @click.stop="c.link(r)">{{cell(r,c)}}</a>
              <span v-else :class="c.mono?'mono':''">{{cell(r,c)}}</span>
            </td>
            <td v-if="$slots.actions"><div class="acts"><slot name="actions" :row="r"></slot></div></td>
          </tr>
        </tbody>
      </table>
    </div>
    <Empty v-else :title="emptyTitle" :text="emptyText"><slot name="empty"></slot></Empty>
    <div class="pager" v-if="filtered.length">
      <span>Resultados por página <select v-model.number="size"><option>10</option><option>20</option><option>50</option></select></span>
      <span>{{(page-1)*size+1}}-{{Math.min(page*size, filtered.length)}} de {{filtered.length}}</span>
      <button @click="page=Math.max(1,page-1)" :disabled="page<=1">‹</button>
      <span>Página {{page}} de {{pages}}</span>
      <button @click="page=Math.min(pages,page+1)" :disabled="page>=pages">›</button>
    </div>
  </div>`,
};

// Editor de líneas de documento (producto, cantidad, precio, descuento, IVA)
export const LineEditor = {
  props: { modelValue: Array, productos: Array, moneda: { type: String, default: 'CRC' }, conImpuesto: { type: Boolean, default: true }, conReferencia: { type: Boolean, default: false }, sinTotales: { type: Boolean, default: false }, compra: { type: Boolean, default: false }, clienteId: { type: [Number, String], default: null }, exoneracion: { type: Object, default: null } },   // exoneracion: {numero, tarifa, posee_cabys, cabys[]} del cliente   // clienteId: aplica la lista de precios del cliente al elegir un ítem   // compra: al elegir un ítem precarga el costo, no el precio de venta (R274)
  emits: ['update:modelValue'],
  // todas las tarifas del catálogo (antes faltaban 0,5 %, 8 % y «0 % sin derecho a crédito»: el selector quedaba en blanco) (R80)
  data() { return { abiertas: {}, tarifas: CAT.tarifaIvaLista.map(o => [o.value, o.label]) }; },
  computed: {
    lines: { get() { return this.modelValue; }, set(v) { this.$emit('update:modelValue', v); } },
    tcDoc() { return this.moneda && this.moneda !== 'CRC' ? (+monedas.tc(this.moneda) || 1) : 1; },   /* 3.41: montos fijos en colones */
    totales() {
      let sub = 0, desc = 0, iva = 0, exo = 0, otros = 0;
      for (const l of this.lines) {
        const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); const d = +l.descuento || 0; sub += m; desc += d;
        const oi = this.conImpuesto ? otroImpLinea(this.oiDe(l), l.cantidad, m - d, this.tcDoc) : { monto: 0, base: 0 };   /* Selectivo y específicos (3.41) */
        otros += oi.monto; iva += (m - d + oi.base) * this.tarifaNeta(l) / 100; exo += (m - d + oi.base) * this.tarifaExo(l) / 100;
      }
      return { sub, desc, neto: sub - desc, iva, exo, otros, total: sub - desc + iva + otros };
    },
  },
  methods: {
    add() { this.lines.push({ producto_id: null, detalle: '', cabys: '', cantidad: 1, precio_unitario: null, descuento: 0, descuento_pct: 0, codigo_tarifa: '08', tarifa: 13 }); },
    // 3.34: el descuento se digita en % sobre cantidad × precio (sin IVA); el monto (lo que va a Hacienda) se calcula solo
    aplicarDesc(l) {
      let p = +l.descuento_pct || 0; if (p < 0) p = 0; if (p > 100) p = 100;
      if (l.descuento_pct !== '' && l.descuento_pct !== null && +l.descuento_pct !== p) l.descuento_pct = p;
      const base = (+l.cantidad || 0) * (+l.precio_unitario || 0);
      l.descuento = Math.round(base * p) / 100;
    },
    // líneas que llegan con monto (borradores, cotizaciones viejas, recurrentes): el % se deduce sin tocar el monto guardado
    pctDesdeMonto() {
      for (const l of this.lines || []) {
        if (l.descuento_pct !== undefined && l.descuento_pct !== null && l.descuento_pct !== '') continue;
        const base = (+l.cantidad || 0) * (+l.precio_unitario || 0), d = +l.descuento || 0;
        l.descuento_pct = base > 0 && d > 0 ? Math.round(d / base * 1e6) / 1e4 : 0;
      }
    },
    rm(i) { this.lines.splice(i, 1); },
    pick(l) { this.$nextTick(() => this.aplicarDesc(l)); const p = (this.productos || []).find(x => x.id == l.producto_id); if (p) { l.detalle = p.nombre; l.cabys = p.cabys; l.precio_unitario = this.compra ? (+p.costo || p.precio) : precioCliente(p, this.clienteId, this.moneda); l.codigo_tarifa = p.codigo_tarifa; l.tarifa = p.tarifa; l.es_servicio = p.es_servicio; l.unidad_medida = p.unidad_medida; l.otro_impuesto = p.otro_impuesto || null; } },
    tar(l) { l.tarifa = CAT.tarifaPct[l.codigo_tarifa] ?? 0; },
    reprecio() { if (this.compra) return; for (const l of this.lines) { if (!l.producto_id) continue; const p = (this.productos || []).find(x => x.id == l.producto_id); if (p) l.precio_unitario = precioCliente(p, this.clienteId, this.moneda); } },
    // línea manual: el CABYS dice si es servicio (capítulos 5 a 9) y la unidad lo acompaña (R79)
    cabys(l) { if (l.producto_id) return; const s = /^[5-9]/.test(String(l.cabys || '')); l.es_servicio = s; l.unidad_medida = s ? 'Sp' : 'Unid'; },
    lt(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); const oi = this.conImpuesto ? otroImpLinea(this.oiDe(l), l.cantidad, m, this.tcDoc) : { monto: 0, base: 0 }; return m + oi.monto + (m + oi.base) * this.tarifaNeta(l) / 100; },
    oiDe(l) { return otroImpDe(l, this.productos); },
    oiTexto(l) { return otroImpTexto(this.oiDe(l)); },
    // exoneración del cliente: aplica a las líneas gravadas con CABYS autorizado (o a todas si el documento no trae lista)
    exoCubre(l) { const x = this.exoneracion; return !!x && l.codigo_tarifa !== '10' && (+l.tarifa || 0) > 0 && (!x.posee_cabys || (x.cabys || []).includes(String(l.cabys || ''))); },
    tarifaExo(l) { return this.exoCubre(l) && l.exonerar !== false ? Math.min(+this.exoneracion.tarifa || 0, +l.tarifa || 0) : 0; },
    tarifaNeta(l) { return Math.max(0, (+l.tarifa || 0) - this.tarifaExo(l)); },
  },
  // al cambiar el cliente (o la moneda) las líneas con ítem toman el precio de su lista; las escritas a mano no se tocan
  watch: { clienteId() { this.reprecio(); this.$nextTick(() => (this.lines || []).forEach(l => +l.descuento_pct && this.aplicarDesc(l))); }, moneda() { this.reprecio(); this.$nextTick(() => (this.lines || []).forEach(l => +l.descuento_pct && this.aplicarDesc(l))); },
           modelValue() { this.pctDesdeMonto(); } },
  mounted() { if (!this.lines.length) this.add(); this.pctDesdeMonto(); },
  template: `
  <div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th style="width:220px">Ítem</th><th>Detalle</th><th style="width:130px">CABYS</th><th class="num" style="width:80px">Cant.</th><th class="num" style="width:120px">Precio</th><th class="num" style="width:100px" title="Porcentaje sobre cantidad × precio, antes de IVA">Desc. %</th><th style="width:90px" v-if="conImpuesto">IVA</th><th class="num">Total</th><th></th></tr></thead>
      <tbody><tr v-for="(l,i) in lines" :key="i">
        <td><Buscador v-model="l.producto_id" :opciones="productos" :etiqueta="p => (p.codigo ? p.codigo + ' · ' : '') + p.nombre" agregar="ítem" @change="pick(l)"></Buscador></td>
        <td><input class="inp" v-model="l.detalle" style="width:100%;min-width:160px">
          <a v-if="conReferencia" class="link small" style="display:block;margin-top:3px;cursor:pointer" @click="abiertas[i]=!abiertas[i]">{{(l.referencia||l.descripcion) ? '✎ Editar' : '+ Agregar'}} referencia y/o descripción</a>
          <div v-if="conReferencia && abiertas[i]" class="grid cols-2" style="margin-top:6px;gap:8px">
            <Field label="Referencia" help="Código o número que verá el cliente"><input class="inp" v-model="l.referencia" placeholder="123"></Field>
            <Field label="Descripción del producto o servicio"><textarea class="inp" rows="2" v-model="l.descripcion" placeholder="Detalle que se imprime bajo el ítem"></textarea></Field>
          </div>
          <div v-else-if="conReferencia && (l.referencia||l.descripcion)" class="small muted" style="margin-top:2px"><span v-if="l.referencia" class="mono">{{l.referencia}}</span><span v-if="l.referencia && l.descripcion"> | </span><span v-if="l.descripcion">{{l.descripcion}}</span></div></td>
        <td><input class="inp mono" v-model="l.cabys" maxlength="13" style="width:100%" @input="cabys(l)"></td>
        <td><input class="inp" type="number" step="0.001" v-model.number="l.cantidad" @input="aplicarDesc(l)" style="width:100%;text-align:right"></td>
        <td><input class="inp" type="number" step="0.01" v-model.number="l.precio_unitario" @input="aplicarDesc(l)" style="width:100%;text-align:right"></td>
        <td><input class="inp" type="number" step="0.01" min="0" max="100" v-model.number="l.descuento_pct" @input="aplicarDesc(l)" style="width:100%;text-align:right" placeholder="0">
          <div class="small muted" style="text-align:right;margin-top:2px;white-space:nowrap" v-if="+l.descuento">-{{money(l.descuento, moneda)}}</div></td>
        <td v-if="conImpuesto"><select class="inp" v-model="l.codigo_tarifa" @change="tar(l)"><option v-for="t in tarifas" :value="t[0]">{{t[1]}}</option></select>
          <label v-if="exoneracion && exoCubre(l)" class="small" style="display:flex;gap:4px;align-items:center;margin-top:3px;cursor:pointer;white-space:nowrap" :title="'Exoneración ' + exoneracion.numero"><input type="checkbox" :checked="l.exonerar !== false" @change="l.exonerar = $event.target.checked ? undefined : false"> Exonerado {{Math.min(+exoneracion.tarifa||0, +l.tarifa||0)}} %</label>
          <div v-else-if="exoneracion && l.codigo_tarifa !== '10' && (+l.tarifa||0) > 0 && (l.cabys || l.producto_id)" class="small muted" style="margin-top:3px;white-space:nowrap" title="Ese CABYS no está en la lista autorizada del documento de exoneración">Sin exoneración</div></td>
        <td class="num">{{money(lt(l), moneda)}}</td>
        <td><button class="btn icon" @click="rm(i)" title="Quitar">✕</button></td>
      </tr></tbody>
    </table></div>
    <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="add">+ Agregar línea</button></div>
    <div class="totals" v-if="!sinTotales">
      <div><span>Subtotal</span><b>{{money(totales.sub, moneda)}}</b></div>
      <div v-if="totales.desc"><span>Descuento</span><b>-{{money(totales.desc, moneda)}}</b></div>
      <div v-if="totales.desc"><span>Subtotal con descuento</span><b>{{money(totales.neto, moneda)}}</b></div>
      <div v-if="conImpuesto && totales.exo"><span>IVA exonerado</span><b>-{{money(totales.exo, moneda)}}</b></div>
      <div v-if="conImpuesto"><span>{{totales.otros ? 'IVA' : 'Impuestos'}}</span><b>{{money(totales.iva, moneda)}}</b></div>
      <div v-if="conImpuesto && totales.otros"><span>Otros impuestos</span><b>{{money(totales.otros, moneda)}}</b></div>
      <div class="total"><span>Total</span><b>{{money(totales.total, moneda)}}</b></div>
    </div>
  </div>`,
  setup() { return { money }; },
};

export const Comments = {
  props: { saved: { type: Boolean, default: true } },
  data() { return { text: '', list: [] }; },
  template: `
  <div class="card"><h2>Comentarios <small>Disponible en una próxima versión</small></h2>
    <p class="muted small">Los comentarios internos por documento todavía no se guardan en el servidor; por eso esta sección está desactivada (R106).</p>
    <template v-if="false">
      <div v-for="(c,i) in list" :key="i" class="row" style="margin-bottom:8px;align-items:flex-start"><span class="avatar" style="width:28px;height:28px;border-radius:50%;background:var(--primary);color:#fff;display:grid;place-items:center;font-size:12px">N</span><div><div class="small muted">Tú · {{c.fecha}}</div>{{c.text}}</div></div>
      <div class="row" style="align-items:flex-start"><textarea class="inp" v-model="text" rows="2" style="flex:1" placeholder="Escribe un comentario. Menciona con @ o asigna tareas a tu equipo"></textarea><button class="btn sm" @click="if(text){list.push({text,fecha:fechaHora()});text=''}">Enviar</button></div>
    </template>
  </div>`,
};


// ---------------------------------------------------------------------------------------------------------------------------
// ListaCorreos (3.38): varios correos, uno por línea, con «+ Agregar correo» y ✕. v-model = texto separado por comas.
export const ListaCorreos = {
  props: { modelValue: String, placeholder: { type: String, default: 'correo@empresa.cr' }, agregar: { type: String, default: '+ Agregar correo' } },
  emits: ['update:modelValue'],
  data() { return { filas: this.partir(this.modelValue) }; },
  watch: { modelValue(v) { if (v !== this.unir()) this.filas = this.partir(v); } },
  methods: {
    partir(v) { const l = String(v || '').split(/[,;\s]+/).map(x => x.trim()).filter(Boolean); return l.length ? l : ['']; },
    unir() { return this.filas.map(x => x.trim()).filter(Boolean).join(', '); },
    emitir() { this.$emit('update:modelValue', this.unir()); },
    malo(x) { return !!x.trim() && !/^[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}$/.test(x.trim()); },
    mas() { this.filas.push(''); this.$nextTick(() => { const ins = this.$el.querySelectorAll('input'); if (ins.length) ins[ins.length - 1].focus(); }); },
    quitar(i) { this.filas.splice(i, 1); if (!this.filas.length) this.filas.push(''); this.emitir(); },
    pegar(i, ev) { const t = (ev.clipboardData || window.clipboardData).getData('text'); if (!/[,;\s]/.test(t.trim())) return; ev.preventDefault(); const l = this.partir(t); this.filas.splice(i, 1, ...l); this.emitir(); },
  },
  template: `
  <div class="lista-correos">
    <div v-for="(x, i) in filas" :key="i" class="row" style="gap:6px;margin-bottom:6px;flex-wrap:nowrap">
      <input type="email" v-model="filas[i]" :placeholder="placeholder" @input="emitir" @paste="pegar(i, $event)" @keydown.enter.prevent="mas" :class="{inv: malo(x)}" style="flex:1">
      <button type="button" class="btn icon" v-if="filas.length > 1 || x" @click="quitar(i)" title="Quitar">✕</button>
    </div>
    <button type="button" class="btn ghost sm" @click="mas">{{agregar}}</button>
  </div>`,
};

// ---------------------------------------------------------------------------------------------------------------------------
// Enviar comprobante por correo (3.38): para el contacto (editable), copia a sus personas asociadas y a otros correos, y un
// mensaje opcional. Se adjuntan el PDF, el XML y la respuesta de Hacienda.
export const EnviarCorreo = {
  props: { doc: Object },
  emits: ['close', 'enviado'],
  data() { return { d: null, para: '', personas: [], otros: '', mensaje: '', enviando: false }; },
  computed: {
    copias() { return [...this.personas.filter(p => p.on).map(p => p.correo), ...this.otros.split(/[,;\s]+/).map(x => x.trim()).filter(Boolean)]; },
  },
  async created() {
    try {
      this.d = await api('/api/comprobantes/' + this.doc.id + '/destinatarios');
      this.para = (this.d.para || []).join(', ');
      this.personas = (this.d.personas || []).map(p => ({ ...p, on: !!p.notificar }));
      this.otros = (this.d.cc_fijo || []).filter(c => !this.personas.some(p => p.correo === c)).join(', ');   /* «Copia (CC) de las facturas» del contacto */
    } catch (e) { toast(e.message, 'err'); this.$emit('close'); }
  },
  methods: {
    async enviar() {
      if (!this.para.trim()) return toast('Escriba el correo del destinatario', 'err');
      this.enviando = true;
      try {
        const r = await api('/api/comprobantes/' + this.doc.id + '/correo', { method: 'POST', body: { para: this.para, cc: this.copias.join(', '), mensaje: this.mensaje || null } });
        toast('Enviado a ' + r.para.join(', ') + (r.cc && r.cc.length ? ' · copia a ' + r.cc.length : ''), 'ok'); this.$emit('enviado', r);
      } catch (e) { toast(e.message, 'err'); }
      this.enviando = false;
    },
    fechaHora,
  },
  template: `
  <Modal :title="'Enviar por correo · ' + (doc.consecutivo || '')" @close="$emit('close')">
    <p class="muted" v-if="!d">Cargando…</p>
    <template v-else>
      <div class="alert info" style="margin:0 0 10px" v-if="d.correo_enviado && !String(d.correo_enviado).startsWith('enviando')">Ya se envió el {{fechaHora(d.correo_enviado)}}. Puede reenviarlo.</div>
      <Field label="Para" req><ListaCorreos v-model="para" placeholder="cliente@empresa.com" agregar="+ Agregar destinatario"></ListaCorreos></Field>
      <div style="margin-top:10px" v-if="personas.length"><div class="small muted" style="margin-bottom:4px">Copia a las personas de {{d.cliente || 'el contacto'}}</div>
        <label v-for="p in personas" :key="p.correo" class="row small" style="gap:6px;cursor:pointer;margin:3px 0"><input type="checkbox" v-model="p.on"> <b>{{p.nombre || p.correo}}</b> <span class="muted">{{p.correo}}</span></label>
      </div>
      <Field label="Copia (CC) a otros correos" help="Agregue todos los que necesite" style="margin-top:10px"><ListaCorreos v-model="otros" placeholder="contabilidad@empresa.com" agregar="+ Agregar copia"></ListaCorreos></Field>
      <Field label="Mensaje" help="Opcional; va arriba del texto del correo" style="margin-top:10px"><textarea rows="3" v-model="mensaje" maxlength="1500" placeholder="Buenos días, le reenvío la factura solicitada."></textarea></Field>
      <p class="small muted" style="margin:8px 0 0">Se adjuntan el PDF y el XML{{d.con_respuesta ? ', y la respuesta de Hacienda' : ''}}.</p>
    </template>
    <template #foot><button class="btn ghost" @click="$emit('close')">Cancelar</button><button class="btn" @click="enviar" :disabled="enviando || !d">{{enviando ? 'Enviando…' : 'Enviar'}}</button></template>
  </Modal>`,
};

// ---------------------------------------------------------------------------------------------------------------------------
// Atajo (3.37): botón que lleva a la configuración de un módulo desde su pantalla principal; solo aparece si el rol puede abrirla.
export const Atajo = {
  props: { to: String, label: String },
  computed: { ok() { return rutaPermitida(String(this.to || '').split('?')[0]); } },
  template: `<a v-if="ok" class="btn ghost" :href="'#' + to">⚙ {{label}}</a>`,
};

// Pestañas de Reportes (3.37): los reportes generales, de la caja, del hotel y de planilla se ven como una sola pantalla.
export const ReportesTabs = {
  data() { return { todas: [['/reportes', 'Generales'], ['/pos/reportes', 'Caja'], ['/hotel/reportes', 'Hotel'], ['/rrhh/informes', 'Planilla']] }; },
  computed: {
    tabs() { return this.todas.filter(([to]) => rutaPermitida(to)); },
    actual() { const h = (location.hash.slice(1) || '').split('?')[0]; return (this.todas.find(([to]) => h === to || h.startsWith(to + '/')) || [])[0]; },
  },
  template: `<div class="tabs" v-if="tabs.length > 1" style="margin-bottom:12px"><button v-for="t in tabs" :key="t[0]" type="button" :class="{on: t[0] === actual}" @click="ir(t[0])">{{t[1]}}</button></div>`,
  methods: { ir(to) { location.hash = to; } },
};

// ---------------------------------------------------------------------------------------------------------------------------
// Buscador (3.29): selector con búsqueda. Se escribe y filtra (nombre, código, cédula…), se navega con flechas y Enter; la
// primera opción es «+ Agregar…» y abre el alta rápida sin salir del formulario (cliente, proveedor o ítem) o lleva al
// formulario completo. Reemplaza al <select> en los campos de cliente, proveedor, contacto e ítem.
//   v-model           valor elegido (por defecto el id)
//   :opciones         lista de objetos
//   etiqueta/detalle  clave o función para el texto principal y el secundario (p. ej. 'nombre' y 'numero_id')
//   vacio             (sin uso desde 3.30: para dejarlo en blanco se usa la ✕; la lista empieza con «+ Agregar» y luego los registros)
//   agregar           'cliente' | 'proveedor' | 'item' | 'contacto' = qué alta rápida abre «+ Agregar»; vacío = sin esa opción
export const Buscador = {
  props: { modelValue: [Number, String, null], opciones: { type: Array, default: () => [] }, etiqueta: { type: [String, Function], default: 'nombre' }, detalle: { type: [String, Function], default: null },
           valor: { type: String, default: 'id' }, placeholder: { type: String, default: 'Escriba para buscar…' }, vacio: { type: String, default: '' }, agregar: { type: String, default: '' },
           disabled: Boolean, invalido: Boolean, maximo: { type: Number, default: 60 }, catalogo: { type: String, default: '' } },
  emits: ['update:modelValue', 'change', 'agregar'],
  data() { return { q: '', abierto: false, idx: 0, rapido: null, pos: {}, recien: null, deCatalogo: this.catalogo ? (mock.get(this.catalogo, []) || []) : null }; },
  computed: {
    fuente() { return this.deCatalogo || this.opciones || []; },
    elegido() {
      if (this.modelValue === null || this.modelValue === undefined || this.modelValue === '') return null;
      const o = this.fuente.find(o => String(o[this.valor]) === String(this.modelValue)) || (this.recien && String(this.recien[this.valor]) === String(this.modelValue) ? this.recien : null);
      if (o) return o;
      // valor guardado que ya no está en la lista (p. ej. un vendedor escrito a mano antes): se muestra tal cual en vez de quedar en blanco (3.35)
      return this.valor !== 'id' && typeof this.etiqueta === 'string' ? { [this.valor]: this.modelValue, [this.etiqueta]: this.modelValue } : null;
    },
    texto() { return this.elegido ? this.lab(this.elegido) : ''; },
    filtradas() {
      const q = this.q.trim().toLowerCase(), partes = q.split(/\s+/).filter(Boolean);
      const base = !partes.length ? this.fuente : this.fuente.filter(o => { const t = (this.lab(o) + ' ' + (this.det(o) || '') + ' ' + (o.codigo || '') + ' ' + (o.numero_id || '') + ' ' + (o.codigos_alternos || '')).toLowerCase(); return partes.every(p => t.includes(p)); });   // 4.24: también por un código alterno del ítem
      return base.slice(0, this.maximo);
    },
    items() {
      const out = [];
      if (this.agregar) out.push({ _nuevo: true });
      return out.concat(this.filtradas);
    },
    esItem() { return this.agregar === 'item' || this.agregar === 'ítem'; },
    etiquetaAgregar() { return this.esItem ? 'ítem' : (RAPIDOS[this.agregar] ? RAPIDOS[this.agregar].etiqueta : this.agregar); },
    tipoRapido() { return { cliente: 'Cliente', proveedor: 'Proveedor', contacto: 'Cliente' }[this.agregar] || null; },
  },
  watch: { modelValue() { if (!this.abierto) this.q = this.texto; }, opciones() { if (!this.abierto) this.q = this.texto; } },
  methods: {
    lab(o) { return typeof this.etiqueta === 'function' ? this.etiqueta(o) : String(o[this.etiqueta] ?? ''); },
    det(o) { if (!this.detalle) return ''; return typeof this.detalle === 'function' ? this.detalle(o) : String(o[this.detalle] ?? ''); },
    abrir() { if (this.disabled) return; if (this.catalogo) this.deCatalogo = mock.get(this.catalogo, []) || []; this.abierto = true; this.idx = 0; this.ubicar(); this.$nextTick(() => { const i = this.$refs.inp; if (i) i.select(); }); },
    cerrar() { this.abierto = false; this.q = this.texto; },
    escribir() { if (!this.abierto) this.ubicar(); this.abierto = true; this.idx = this.q.trim() && this.filtradas.length && this.agregar ? 1 : 0; },
    // 3.30: la lista flota sobre la página (fuera de tablas y tarjetas), así nada la tapa; si abajo no cabe, se abre hacia arriba
    ubicar() {
      const el = this.$refs.inp; if (!el) return;
      const r = el.getBoundingClientRect(), alto = Math.min(300, window.innerHeight * 0.5), abajo = window.innerHeight - r.bottom - 8, arriba = r.top - 8;
      const subir = abajo < Math.min(alto, 180) && arriba > abajo;
      const w = Math.max(r.width, 260);
      this.pos = { left: Math.max(4, Math.min(r.left, window.innerWidth - w - 4)) + 'px', width: w + 'px', maxHeight: Math.max(120, Math.min(alto, subir ? arriba : abajo)) + 'px',
                   ...(subir ? { bottom: (window.innerHeight - r.top + 2) + 'px' } : { top: (r.bottom + 2) + 'px' }) };
    },
    alMoverse() { if (this.abierto) this.ubicar(); },
    elegir(o) {
      if (o._nuevo) return this.nuevo();
      const v = o._vacio ? null : o[this.valor];
      this.$emit('update:modelValue', v); this.abierto = false; this.q = o._vacio ? '' : this.lab(o);
      this.$nextTick(() => this.$emit('change', v));
    },
    limpiar() { this.$emit('update:modelValue', null); this.q = ''; this.$nextTick(() => this.$emit('change', null)); },
    tecla(e) {
      if (!this.abierto && ['ArrowDown', 'ArrowUp', 'Enter'].includes(e.key)) { this.abrir(); e.preventDefault(); return; }
      if (e.key === 'ArrowDown') { this.idx = Math.min(this.items.length - 1, this.idx + 1); e.preventDefault(); this.ver(); }
      else if (e.key === 'ArrowUp') { this.idx = Math.max(0, this.idx - 1); e.preventDefault(); this.ver(); }
      else if (e.key === 'Enter') { e.preventDefault(); const o = this.items[this.idx]; if (o) this.elegir(o); }
      else if (e.key === 'Escape') { this.cerrar(); }
    },
    ver() { this.$nextTick(() => { const l = this.$refs.lista; const el = l && l.querySelector('.it.on'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' }); }); },
    nuevo() {
      this.abierto = false;
      if (this.esItem) { this.rapido = { tipo: 'item', texto: this.q.trim() }; return; }
      if (this.tipoRapido) { this.rapido = { tipo: 'contacto', texto: this.q.trim(), clase: this.tipoRapido }; return; }
      if (RAPIDOS[this.agregar]) { this.rapido = { tipo: 'catalogo', texto: this.q.trim(), def: RAPIDOS[this.agregar] }; return; }   /* 3.35 */
      this.$emit('agregar', this.q.trim());
    },
    creado(o) { this.rapido = null; this.recien = o; try { const l = this.deCatalogo || this.opciones; if (Array.isArray(l) && !l.includes(o)) l.push(o); } catch (e) { /* lista calculada: se muestra igual con «recien» */ } this.$emit('update:modelValue', o[this.valor]); this.q = this.lab(o); this.$nextTick(() => this.$emit('change', o[this.valor])); },
  },
  mounted() { this.q = this.texto; this._mov = () => this.alMoverse(); window.addEventListener('scroll', this._mov, true); window.addEventListener('resize', this._mov); },
  beforeUnmount() { window.removeEventListener('scroll', this._mov, true); window.removeEventListener('resize', this._mov); },
  template: `
  <div class="buscador" :class="{abierto, inv: invalido}">
    <div class="buscador-caja"><input ref="inp" class="inp" :class="{inv: invalido}" v-model="q" :placeholder="elegido ? '' : placeholder" :disabled="disabled" autocomplete="off" @focus="abrir" @click="!abierto && abrir()" @input="escribir" @keydown="tecla" @blur="cerrar">
      <button type="button" class="buscador-x" v-if="elegido && !disabled" @mousedown.prevent="limpiar" title="Quitar">✕</button><span class="buscador-flecha" v-else>▾</span></div>
    <Teleport to="body"><div class="buscador-lista" ref="lista" v-if="abierto" :style="pos">
      <div v-for="(o, i) in items" :key="o._nuevo ? '_n' : String(o[valor])" class="it" :class="{on: i===idx, nuevo: o._nuevo}" @mousedown.prevent="elegir(o)" @mousemove="idx=i">
        <template v-if="o._nuevo">+ Agregar {{etiquetaAgregar}}<span v-if="q.trim()"> «{{q.trim()}}»</span></template>
        <template v-else>{{lab(o)}}<span class="muted small" v-if="det(o)"> · {{det(o)}}</span></template>
      </div>
      <div class="it muted small" v-if="!filtradas.length && q.trim()">Sin coincidencias{{agregar ? ': puede agregarlo' : ''}}</div>
      <div class="it muted small" v-else-if="!fuente.length">Todavía no hay registros{{agregar ? ': agregue el primero' : ''}}</div>
      <div class="it muted small" v-else-if="fuente.length > maximo && filtradas.length >= maximo">Se muestran {{maximo}}: escriba más letras para afinar</div>
    </div></Teleport>
    <ContactoRapido v-if="rapido && rapido.tipo==='contacto'" :texto="rapido.texto" :clase="rapido.clase" @close="rapido=null" @creado="creado"></ContactoRapido>
    <ItemRapido v-if="rapido && rapido.tipo==='item'" :texto="rapido.texto" @close="rapido=null" @creado="creado"></ItemRapido>
    <CatalogoRapido v-if="rapido && rapido.tipo==='catalogo'" :def="rapido.def" :texto="rapido.texto" @close="rapido=null" @creado="creado"></CatalogoRapido>
  </div>`,
};

// ---------------------------------------------------------------------------------------------------------------------------
// Altas rápidas de catálogos (3.35): lo mínimo para seguir sin salir del formulario; «Formulario completo» lleva a su pantalla.
const _dup = (lista, nombre, que) => { if ((lista || []).some(x => String(x.nombre || '').trim().toLowerCase() === nombre.toLowerCase())) throw new Error('Ya existe ' + que + ' «' + nombre + '»'); };
export const RAPIDOS = {
  categoria: { etiqueta: 'categoría', titulo: 'Nueva categoría', ruta: '#/inventario/categorias', campos: [],
    async crear(d) { const lista = mock.get('categorias', []) || []; _dup(lista, d.nombre, 'una categoría'); const c = { id: mock.nextId(lista, 'categorias'), nombre: d.nombre, descripcion: '', imagen: '', icono: '', padre_id: null }; mock.set('categorias', [...lista, c]); return c; } },
  bodega: { etiqueta: 'bodega', titulo: 'Nueva bodega', ruta: '#/inventario/bodegas', campos: [{ key: 'direccion', label: 'Dirección', placeholder: 'Opcional' }],
    async crear(d) { return await api('/api/inventario/bodegas', { method: 'POST', body: { nombre: d.nombre, direccion: d.direccion || null, observaciones: null, principal: false, activa: true } }); } },
  cuenta: { etiqueta: 'cuenta', titulo: 'Nueva cuenta de Bancos', ruta: '#/bancos/cuentas',
    campos: [{ key: 'tipo', label: 'Tipo', opciones: [['Banco', 'Banco'], ['Efectivo', 'Efectivo (caja)']], def: 'Banco' }, { key: 'moneda', label: 'Moneda', opciones: () => monedas.opciones().map(o => [o.value, o.label]), def: () => monedas.principal().codigo }, { key: 'numero', label: 'Número de cuenta', placeholder: 'Opcional' }],
    async crear(d) { const lista = mock.get('bancos', []) || []; _dup(lista, d.nombre, 'una cuenta'); const b = { id: mock.nextId(lista, 'bancos'), nombre: d.nombre, tipo: d.tipo || 'Banco', moneda: d.moneda || monedas.principal().codigo, numero: d.numero || '', saldo_inicial: 0, fecha_saldo: hoy(), saldo: 0, descripcion: '', principal: false, cuenta_contable: '' }; mock.set('bancos', [...lista, b]); return b; } },
  departamento: { etiqueta: 'departamento', titulo: 'Nuevo departamento o área', ruta: '#/rrhh/horarios?tab=config', campos: [],
    async crear(d) { const lista = mock.get('rrhh_departamentos', []) || []; _dup(lista, d.nombre, 'un departamento'); const x = { id: mock.nextId(lista, 'rrhh_departamentos'), nombre: d.nombre, activo: true }; mock.set('rrhh_departamentos', [...lista, x]); return x; } },
  vendedor: { etiqueta: 'vendedor', titulo: 'Nuevo vendedor', ruta: '#/configuracion/vendedores', campos: [{ key: 'identificacion', label: 'Identificación', placeholder: 'Opcional' }],
    async crear(d) { const lista = mock.get('vendedores', []) || []; _dup(lista, d.nombre, 'un vendedor'); const v = { id: mock.nextId(lista, 'vendedores'), nombre: d.nombre, identificacion: d.identificacion || '', observaciones: '' }; mock.set('vendedores', [...lista, v]); return v; } },
  agencia: { etiqueta: 'agencia o empresa', titulo: 'Nueva agencia o empresa con contrato', ruta: '#/hotel/agencias', campos: [{ key: 'tipo', label: 'Tipo', opciones: [['agencia', 'Agencia'], ['empresa', 'Empresa']], def: 'agencia' }, { key: 'correo', label: 'Correo', placeholder: 'Opcional' }],
    async crear(d) { let nueva = null; mock.actualizar('hotel_agencias', l => { const lista = Array.isArray(l) ? l : []; _dup(lista, d.nombre, 'una agencia o empresa'); nueva = { id: mock.nextId(lista, 'hotel_agencias'), nombre: d.nombre, tipo: d.tipo || 'agencia', cliente_id: null, modalidad: 'neta', descuento_pct: 0, comision_pct: 10, tarifas: {}, vigencia_desde: '', vigencia_hasta: '', credito: true, dias_credito: 30, contacto: '', correo: d.correo || '', telefono: '', notas: '', activo: true, actualizado: new Date().toISOString() }; return [...lista, nueva]; }, []); return nueva; } },
};

export const CatalogoRapido = {
  props: { def: Object, texto: { type: String, default: '' } },
  emits: ['close', 'creado'],
  data() { const d = { nombre: (this.texto || '').trim() }; for (const c of this.def.campos || []) d[c.key] = typeof c.def === 'function' ? c.def() : (c.def ?? ''); return { d, guardando: false }; },
  methods: {
    ops(c) { return typeof c.opciones === 'function' ? c.opciones() : c.opciones; },
    async guardar() {
      const nombre = (this.d.nombre || '').trim(); if (nombre.length < 2) return toast('Escriba el nombre', 'err');
      this.guardando = true;
      try { const o = await this.def.crear({ ...this.d, nombre }); toast('Se agregó «' + nombre + '»', 'ok'); this.$emit('creado', o); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    completo() { if (confirm('Se abre el formulario completo en esta ventana; lo que lleva escrito en este formulario no se guarda. ¿Continuar?')) location.hash = this.def.ruta; },
  },
  template: `
  <Modal :title="def.titulo" @close="$emit('close')">
    <div class="grid cols-2">
      <Field label="Nombre" req style="grid-column:1/-1"><input v-model="d.nombre" maxlength="100" autofocus @keyup.enter="guardar"></Field>
      <Field v-for="c in def.campos" :key="c.key" :label="c.label"><select v-if="c.opciones" v-model="d[c.key]"><option v-for="o in ops(c)" :key="o[0]" :value="o[0]">{{o[1]}}</option></select><input v-else v-model="d[c.key]" :placeholder="c.placeholder || ''"></Field>
    </div>
    <p class="small muted" style="margin:6px 0 0">Lo básico para seguir. El resto se completa después en su pantalla.</p>
    <template #foot><button type="button" class="btn ghost" @click="completo">Formulario completo</button><button type="button" class="btn ghost" @click="$emit('close')">Cancelar</button><button type="button" class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
  </Modal>`,
};

// Alta rápida de contacto (3.29): lo mínimo para facturar o registrar la compra; «Formulario completo» abre Contactos con lo escrito
export const ContactoRapido = {
  props: { texto: { type: String, default: '' }, clase: { type: String, default: 'Cliente' } },
  emits: ['close', 'creado'],
  data() { const t = (this.texto || '').trim(); return { f: { tipo_id: '01', numero_id: /^\d[\d-]*$/.test(t) ? t.replace(/\D/g, '').slice(0, 12) : '', nombre: /^\d[\d-]*$/.test(t) ? '' : t, correo: '', telefono: '' }, buscando: false, guardando: false, CAT, opts }; },
  computed: { esProv() { return this.clase === 'Proveedor'; }, titulo() { return this.esProv ? 'Nuevo proveedor' : 'Nuevo cliente'; } },
  methods: {
    async hacienda() {
      const n = String(this.f.numero_id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); if (!n) return toast('Escriba la identificación', 'err');
      this.buscando = true;
      try { const d = await api('/api/hacienda/contribuyente/' + n); this.f.nombre = d.nombre || this.f.nombre; if (d.tipo_identificacion && CAT.tipoId[d.tipo_identificacion]) this.f.tipo_id = d.tipo_identificacion; toast('Datos obtenidos de Hacienda', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.buscando = false;
    },
    async guardar() {
      const f = this.f;
      if ((f.tipo_id && !f.numero_id) || !(f.nombre || '').trim()) return toast(f.tipo_id ? 'Identificación y nombre son obligatorios' : 'Indique el nombre', 'err');
      const tel = String(f.telefono || '').replace(/\D/g, '');
      if (tel && tel.length !== 8 && tel.length !== 3) return toast('El teléfono debe tener 8 dígitos (o ser un número especial de 3, como 911)', 'err');
      this.guardando = true;
      try {
        const c = await api('/api/clientes', { method: 'POST', body: { nombre: f.nombre.trim(), tipo_id: f.tipo_id || '', numero_id: f.tipo_id ? String(f.numero_id).replace(/[^A-Za-z0-9]/g, '').toUpperCase() : '', correo: (f.correo || '').trim() || null, telefono: tel ? +tel : null, tipo: this.clase, activo: true } });
        store.poner('clientes', c); toast((this.esProv ? 'Proveedor ' : 'Cliente ') + c.nombre + ' creado', 'ok'); this.$emit('creado', c);
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    completo() { location.hash = '#/contactos/nuevo?tipo=' + (this.esProv ? 'proveedor' : 'cliente') + '&nombre=' + encodeURIComponent(this.f.nombre || '') + '&numero=' + encodeURIComponent(this.f.numero_id || ''); },
  },
  template: `
  <Modal :title="titulo" @close="$emit('close')">
    <div class="grid cols-2">
      <Field label="Tipo de identificación" req><select v-model="f.tipo_id" @change="f.tipo_id || (f.numero_id = '')"><option v-for="o in opts(CAT.tipoId)" :key="o.value" :value="o.value">{{o.label}}</option><option value="">Sin identificación (solo tiquetes)</option></select></Field>
      <Field label="Identificación" :req="!!f.tipo_id"><div class="row" style="gap:6px"><input v-model="f.numero_id" style="flex:1" :placeholder="f.tipo_id ? 'Sin guiones' : 'Sin identificación'" :disabled="!f.tipo_id" autofocus><button type="button" class="btn sec sm" @click="hacienda" :disabled="buscando || !f.tipo_id" title="Trae el nombre registrado en Hacienda">{{buscando ? '…' : 'Hacienda'}}</button></div></Field>
      <Field label="Nombre" req style="grid-column:1/-1"><input v-model="f.nombre" maxlength="100"></Field>
      <Field label="Correo" help="Para enviarle los comprobantes"><input type="email" v-model="f.correo" maxlength="120"></Field>
      <Field label="Teléfono"><input v-model="f.telefono" maxlength="12" placeholder="8 dígitos"></Field>
    </div>
<p class="small muted" v-if="!f.tipo_id" style="margin:4px 0 0">Sin identificación solo se le emiten tiquetes electrónicos (con su nombre y correo). Para factura electrónica, agréguele la identificación después.</p>
    <p class="small muted" style="margin:6px 0 0">Lo básico para seguir. Dirección, actividad, lista de precios y crédito se completan después en Contactos.</p>
    <template #foot><button type="button" class="btn ghost" @click="completo">Formulario completo</button><button type="button" class="btn ghost" @click="$emit('close')">Cancelar</button><button type="button" class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
  </Modal>`,
};

// Alta rápida de ítem (3.29): nombre, tipo, precio, moneda, IVA y CABYS (con búsqueda); «Formulario completo» abre Inventario › Ítems
export const ItemRapido = {
  props: { texto: { type: String, default: '' } },
  emits: ['close', 'creado'],
  data() { return { f: { nombre: (this.texto || '').trim(), tipo: 'Producto', precio: null, moneda: monedas.principal().codigo, codigo_tarifa: '08', cabys: '', unidad_medida: 'Unid' }, cabysQ: (this.texto || '').trim(), cabysRes: [], buscando: false, guardando: false, CAT, monedasOpc: monedas.opciones() }; },
  methods: {
    async buscarCabys() {
      if (!this.cabysQ.trim()) return;
      this.buscando = true;
      try { this.cabysRes = await api('/api/hacienda/cabys?q=' + encodeURIComponent(this.cabysQ)); if (!this.cabysRes.length) toast('Sin resultados en el catálogo CABYS'); } catch (e) { toast(e.message, 'err'); }
      this.buscando = false;
    },
    usarCabys(x) { this.f.cabys = x.codigo; if (x.impuesto !== undefined && x.impuesto !== null && String(x.impuesto) !== '') { const pct = +x.impuesto; const cod = Object.entries(CAT.tarifaPct).find(([k, v]) => v === pct); if (cod) this.f.codigo_tarifa = cod[0]; } this.cabysRes = []; },
    cambioTipo() { this.f.unidad_medida = this.f.tipo === 'Servicio' ? 'Sp' : 'Unid'; },
    async guardar() {
      const f = this.f;
      if (!(f.nombre || '').trim() || f.nombre.trim().length < 3) return toast('Escriba el nombre (3 caracteres o más)', 'err');
      if (sesion.electronica ? !/^\d{13}$/.test(f.cabys || '') : (f.cabys && !/^\d{13}$/.test(f.cabys))) return toast(sesion.electronica ? 'Indique el código CABYS (13 dígitos): búsquelo por descripción' : 'El código CABYS es opcional, pero si lo escribe debe tener 13 dígitos', 'err');   /* 4.21: opcional sin facturación electrónica, como en Inventario › Ítems */
      if (!(+f.precio >= 0)) return toast('Indique el precio', 'err');
      this.guardando = true;
      try {
        const p = await api('/api/productos', { method: 'POST', body: { nombre: f.nombre.trim(), tipo: f.tipo, es_servicio: f.tipo === 'Servicio', cabys: f.cabys, precio: +f.precio || 0, moneda: f.moneda, unidad_medida: f.unidad_medida, codigo_tarifa: f.codigo_tarifa, tarifa: CAT.tarifaPct[f.codigo_tarifa] ?? 13, inventariable: f.tipo !== 'Servicio' } });
        store.poner('productos', p); toast('Ítem ' + p.nombre + ' creado', 'ok'); this.$emit('creado', p);
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    completo() { location.hash = '#/inventario/items/nuevo?nombre=' + encodeURIComponent(this.f.nombre || '') + '&cabys=' + (this.f.cabys || '') + '&tipo=' + this.f.tipo; },
  },
  template: `
  <Modal title="Nuevo ítem" @close="$emit('close')">
    <div class="grid cols-2">
      <Field label="Nombre" req style="grid-column:1/-1"><input v-model="f.nombre" maxlength="200" autofocus></Field>
      <Field label="Tipo"><select v-model="f.tipo" @change="cambioTipo"><option>Producto</option><option>Servicio</option></select></Field>
      <Field label="Unidad"><select v-model="f.unidad_medida"><option v-for="u in CAT.unidades" :key="u" :value="u">{{u}}{{CAT.unidadesNombre[u] ? ' · ' + CAT.unidadesNombre[u] : ''}}</option></select></Field>
      <Field label="Precio base (sin IVA)" req><input type="number" min="0" step="0.01" v-model.number="f.precio"></Field>
      <Field label="Moneda"><select v-model="f.moneda"><option v-for="o in monedasOpc" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
      <Field label="IVA"><select v-model="f.codigo_tarifa"><option v-for="o in CAT.tarifaIvaLista" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
      <Field label="Código CABYS" req :help="f.cabys ? 'Elegido: ' + f.cabys : 'Escriba qué es y búsquelo'"><div class="row" style="gap:6px"><input v-model="cabysQ" style="flex:1" placeholder="Ej.: disco duro, consultoría" @keyup.enter="buscarCabys"><button type="button" class="btn sec sm" @click="buscarCabys" :disabled="buscando">{{buscando ? '…' : 'Buscar'}}</button></div></Field>
    </div>
    <div class="card" v-if="cabysRes.length" style="padding:6px;max-height:180px;overflow:auto;margin-top:6px"><div v-for="x in cabysRes.slice(0, 25)" :key="x.codigo" class="row small" style="justify-content:space-between;gap:8px;padding:4px 6px;cursor:pointer;border-bottom:1px solid var(--line)" @click="usarCabys(x)"><span>{{x.descripcion}}</span><span class="mono muted">{{x.codigo}}{{x.impuesto !== undefined && x.impuesto !== null ? ' · ' + x.impuesto + ' %' : ''}}</span></div></div>
    <p class="small muted" style="margin:6px 0 0">Costo, existencias, categoría e imagen se completan después en Inventario › Ítems.</p>
    <template #foot><button type="button" class="btn ghost" @click="completo">Formulario completo</button><button type="button" class="btn ghost" @click="$emit('close')">Cancelar</button><button type="button" class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
  </Modal>`,
};
