// Bandeja de entrada — pantalla "Muy pronto" (sin backend ni datos)
export default {
  props: ['params'],
  template: `
  <div class="page">
    <PageHead title="Bandeja de entrada" sub="Centralice las notificaciones, comentarios y menciones de su equipo." soon></PageHead>
    <div class="card">
      <Empty icon="✉" title="Su bandeja está vacía por ahora" text="Aquí llegarán las notificaciones del sistema (respuestas de Hacienda, facturas vencidas, pagos recibidos), los comentarios en documentos y las menciones con @ que le haga su equipo. Podrá marcarlas como leídas, filtrarlas por tipo y abrir el documento relacionado con un clic.">
        <a class="btn sec" href="#/ventas/facturas">Ir a facturas de venta</a>
      </Empty>
    </div>
  </div>`,
};
