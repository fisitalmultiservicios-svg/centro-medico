// 4.25 (tanda 7): #/conectar en la PÁGINA WEB: un administrador aprueba la computadora nueva del programa local. Pantalla de nivel
// superior (app.js: conexion), como el selector de empresa: pasa primero por el ingreso, los dos pasos, la contraseña temporal y los
// términos, y funciona sin empresa elegida. La pantalla no decide permisos: consultar y aprobar los revisa el servidor.
// E-1: el NÚMERO DE COMPROBACIÓN lo genera la web al aprobar y se muestra AQUÍ; la persona lo escribe en el programa que tiene delante.
// E-2: si la computadora no usa la misma conexión a internet, la entrega se retiene 5 minutos y aquí se ofrece «Cancelar».
// E-15: después de aprobar se consulta el pase hasta verlo «entregada» antes de decir «Listo»; aprobar para otra empresa de la persona
// NO cambia la empresa de la sesión (se pide un token de esa empresa solo para la llamada); «Cancelar» siempre limpia lo guardado.
// Sin v-html: el nombre de la computadora (escrito por quien la conecta) se muestra con interpolación.
import { api, toast } from '../api.js';
import { sesion, conexion } from '../app.js';

const CADA_MS = 3000;                      // consulta del pase aprobado
const TOPE_SEGUIMIENTO_MS = 15 * 60000;     // retención (5 min) + plazo para recoger (2 min) con holgura
const FINALES = {
  cancelada: 'La conexión se canceló. Esa computadora no recibió nada.',
  rechazada: 'La conexión se rechazó. Esa computadora no recibió nada.',
  anulada: 'Por seguridad este código se anuló. Empiece de nuevo desde el programa.',
  vencida: 'El programa no terminó de conectarse a tiempo: la conexión venció y esa computadora no recibió nada. Empiece de nuevo desde el programa.',
  /* 4.31 (16a): la entrega se detuvo: esa computadora trae ventas de esta empresa que la página web no tiene (no recibió nada) */
  bloqueada: 'Esta computadora ya tiene ventas de esta empresa que no están en la página web. Si la conecta así, se pierden o se duplican. Escriba a soporte.',
};
const PASE_NO_EXISTE = 'Esa conexión ya no está disponible. Si la computadora no quedó conectada, empiece de nuevo desde el programa.';
const TEXTO_RETOMADO = 'Usted ya aprobó esta computadora. Si no alcanzó a escribir el número en el programa, cancele y empiece de nuevo.';

export default {
  data() {
    return { esPrograma: false, web: '', escrito: conexion.codigo || '', info: null, empresaId: null, mismo: false, paso: 'buscar', cargando: false,
      error: '', aprobada: null, seguimiento: '', segRet: 0, final: '', desde: 0, ahora: Date.now(), retomado: false,
      consultado: '', avisoOtra: '' };   // 9b: el código que esta pantalla ya buscó (U17) y en cuál empresa quedó la computadora (U13)
  },
  computed: {
    empresas() { return (this.info && this.info.empresas) || []; },
    elegida() { return this.empresas.find(e => e.id === this.empresaId) || null; },
    hace() { const n = this.info ? this.info.hace_minutos : 0; return !n ? 'hace menos de un minuto' : 'hace ' + n + (n === 1 ? ' minuto' : ' minutos'); },
    puedeAprobar() { return !!this.info && !!this.elegida && this.mismo && !this.cargando && !this.bloqueada; },
    /* 4.31 (16a): el programa ya dijo que esa computadora trae ventas de la empresa elegida que no están en la página web: no se aprueba */
    bloqueada() { return !!this.elegida && !!this.elegida.bloqueada; },
    puedeDetener() { return !this.cargando && ['aprobada', 'retenida'].includes(this.seguimiento); },
    retencion() { const s = Math.max(0, Math.round(this.segRet - (this.ahora - this.desde) / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); },
    codigoPestana() { return conexion.codigo || ''; },   // 9c (J7): el código del enlace (app.js lo toma de la dirección en cada cambio de #)
  },
  // 9c (J7): llega un código NUEVO a la misma pestaña sin recargar (solo cambia lo que va después de #) mientras se ve el seguimiento, el
  // «Listo» o el final de una computadora anterior: se olvida el pase anterior y se busca el código nuevo
  watch: { codigoPestana() { this.alCambiarCodigo(); } },
  methods: {
    nombreEmpresa(e) { return e ? (e.nombre_comercial || e.nombre) : ''; },
    // «Cancelar» y las salidas: lo guardado en el navegador se borra siempre, aunque el servidor no responda
    salir(destino) {
      this.parar();
      if (this.codigoNuevo()) { this.seguirConNuevo(); return; }   // 9b (U17): «Salir» de un pase viejo no borra un código nuevo
      conexion.limpiar();
      location.hash = destino || (sesion.empresa_id && sesion.puede('configurar') ? '/configuracion/instalacion-local' : (sesion.inicio || '/inicio'));
    },
    // 7b (T2): el código ya resuelto sale también de la dirección; si no, al recargar se volvía a guardar y a consultar
    olvidarCodigo() {
      conexion.fijar('');
      try { history.replaceState(null, '', '#/conectar'); } catch { /* sin historial: queda la marca vacía */ }
    },
    // 9b (U17): en la pestaña quedó un código distinto del que esta pantalla ya buscó (llegó en un enlace nuevo)
    codigoNuevo() {
      const n = String(conexion.codigo || '').replace(/[^A-Z0-9]/g, '');
      return !!n && ['aprobada', 'fin', 'listo'].includes(this.paso) && n !== String(this.consultado || '').replace(/[^A-Z0-9]/g, '');
    },
    alCambiarCodigo() { if (this.esPrograma || !this.codigoNuevo()) return; this.parar(); this.seguirConNuevo(); },
    seguirConNuevo() {
      conexion.fijarPase('');
      this.aprobada = null; this.retomado = false; this.seguimiento = ''; this.final = ''; this.info = null; this.error = ''; this.avisoOtra = '';
      this.escrito = conexion.codigo; this.paso = 'buscar';
      this.buscar();
    },
    // 9b (U13): «Ver las computadoras conectadas». Si la pestaña no tenía empresa elegida, se elige la empresa a la que se conectó la
    // computadora (no se cambia ninguna empresa ya elegida: E-15); con otra empresa elegida, se dice en cuál quedó
    async verComputadoras() {
      const eid = this.aprobada && this.aprobada.empresa_id;
      if (!sesion.empresa_id && eid) {
        this.parar(); conexion.limpiar();
        await sesion.cambiarEmpresa(eid);
        if (sesion.empresa_id === eid) location.hash = '/configuracion/instalacion-local';
        return;
      }
      if (sesion.empresa_id && eid && eid !== sesion.empresa_id) {
        this.avisoOtra = 'La computadora quedó conectada a ' + (this.aprobada.empresa || 'la otra empresa') + '. Para ver su lista de computadoras, cámbiese a esa empresa (arriba, en el nombre de la empresa) y abra Configuración › Instalación local.';
        return;
      }
      this.salir(sesion.empresa_id ? '/configuracion/instalacion-local' : '');
    },
    async buscar() {
      const c = String(this.escrito || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (c.length !== 8) { this.error = 'Escriba el código de 8 letras y números que aparece en la pantalla del programa.'; return; }
      this.escrito = c.slice(0, 4) + '-' + c.slice(4);
      this.consultado = this.escrito;
      conexion.fijar(this.escrito);
      await this.consultar();
    },
    async consultar() {
      this.cargando = true; this.error = '';
      try {
        this.info = await api('/api/sinc/conexion/consultar', { method: 'POST', body: { codigo: this.escrito } });
        const lista = this.info.empresas || [];
        this.empresaId = lista.length === 1 ? lista[0].id : null;     // con varias, la persona elige (el botón nombra la empresa)
        this.mismo = false; this.paso = 'revisar';
      } catch (e) {
        this.info = null; this.paso = 'buscar'; this.error = e.message;
        if (e.detail && ['no_existe', 'vencido'].includes(e.detail.codigo)) this.olvidarCodigo();   // al recargar no se vuelve a buscar ese código
      }
      this.cargando = false;
    },
    // la llamada de aprobar (o rechazar) va con un token de la empresa elegida SOLO para esa llamada: la pestaña sigue en su empresa
    async llamarAprobar(eid, si) {
      const opt = { method: 'POST', body: { codigo: this.info.codigo, empresa_id: eid, aprobar: si } };
      if (eid === sesion.empresa_id) return api('/api/sinc/conexion/aprobar', opt);
      const r = await api('/api/auth/empresa', { method: 'POST', body: { empresa_id: eid } });
      opt.headers = { Authorization: 'Bearer ' + r.token, 'X-Empresa': String(eid) };
      opt.sinSucursal = true;             // 7b (T8): la sucursal de la pestaña es de la empresa activa, no de esta
      try { return await api('/api/sinc/conexion/aprobar', opt); }
      finally {   // la cookie de descargas vuelve a la empresa de la sesión (el token de la otra empresa no se guarda en ningún lado)
        if (sesion.empresa_id) api('/api/auth/empresa', { method: 'POST', body: { empresa_id: sesion.empresa_id } }).catch(() => {});
      }
    },
    async aprobar() {
      if (!this.puedeAprobar) return toast(!this.elegida ? 'Elija la empresa a la que conecta la computadora' : 'Marque que el código es el mismo que ve en la pantalla del programa', 'err');
      this.cargando = true; this.error = '';
      try {
        const r = await this.llamarAprobar(this.elegida.id, true);
        this.aprobada = { ...r, empresa_id: this.elegida.id }; this.seguimiento = r.retenida ? 'retenida' : 'aprobada'; this.segRet = r.segundos_retencion || 0;
        this.desde = Date.now(); this.paso = 'aprobada'; this.retomado = false;
        this.olvidarCodigo();               // el código ya se usó: al recargar no se vuelve a consultar (el número no se vuelve a mostrar)
        conexion.fijarPase(r.pase);         // 7b (T2): solo el identificador del pase, nunca el número
        this.programar();
      } catch (e) { this.fallo(e); }
      this.cargando = false;
    },
    async rechazar() {
      const ids = this.empresas.map(e => e.id);
      const eid = this.empresaId || (ids.includes(sesion.empresa_id) ? sesion.empresa_id : ids[0]);
      if (!eid) { this.salir(); return; }
      this.cargando = true; this.error = '';
      try { await this.llamarAprobar(eid, false); this.final = FINALES.rechazada; this.paso = 'fin'; this.olvidarCodigo(); }
      catch (e) { this.fallo(e); }
      this.cargando = false;
    },
    fallo(e) {
      const c = e && e.detail && e.detail.codigo;
      this.error = (e && e.message) || 'No se pudo completar. Intente de nuevo.';
      if (['no_existe', 'vencido', 'ya_resuelto'].includes(c)) { this.info = null; this.paso = 'buscar'; this.olvidarCodigo(); }
    },
    programar() {
      clearTimeout(this._t);
      if (this.paso !== 'aprobada') return;
      if (Date.now() - this.desde > TOPE_SEGUIMIENTO_MS) { conexion.fijarPase(''); this.final = FINALES.vencida; this.paso = 'fin'; return; }
      this._t = setTimeout(() => this.seguir(), CADA_MS);
    },
    parar() { clearTimeout(this._t); this._t = null; },
    async seguir() {
      if (this.paso !== 'aprobada' || !this.aprobada) return;
      // corrección de la 9c: si mientras se esperaba llegó un código nuevo (J7), la respuesta del pase anterior se descarta
      const pase = this.aprobada.pase, yaEsOtro = () => this.paso !== 'aprobada' || !this.aprobada || this.aprobada.pase !== pase;
      try {
        const r = await api('/api/sinc/conexion/seguimiento', { method: 'POST', body: { pase: this.aprobada.pase } });
        if (yaEsOtro()) return;
        this.poner(r);
      } catch (e) {     // se sigue consultando: la aprobación ya quedó hecha en el servidor; un pase que ya no existe termina aquí (7b, T2)
        if (yaEsOtro()) return;
        if (e && e.status === 404) { conexion.fijarPase(''); this.final = PASE_NO_EXISTE; this.paso = 'fin'; this.aprobada = { ...this.aprobada, numero: null }; }
      }
      this.programar();
    },
    // 7b (T2): al recargar con un pase guardado se va directo al seguimiento (el número no se vuelve a mostrar: no se guarda)
    async retomar(pid) {
      this.aprobada = { pase: pid, numero: null, nombre: '', empresa: '' };
      this.retomado = true; this.seguimiento = ''; this.segRet = 0; this.desde = Date.now(); this.paso = 'aprobada';
      await this.seguir();
    },
    poner(r) {
      if (!r || !r.estado) return;
      if (r.estado === 'entregada') { this.paso = 'listo'; conexion.fijarPase(''); this.aprobada = { ...this.aprobada, numero: null }; return; }
      if (FINALES[r.estado]) { conexion.fijarPase(''); this.final = FINALES[r.estado]; this.paso = 'fin'; this.aprobada = { ...this.aprobada, numero: null }; return; }
      if (r.estado === 'retenida' && (this.seguimiento !== 'retenida' || Math.abs(r.segundos_retencion - this.segRet) > 5)) { this.segRet = r.segundos_retencion || 0; this.desde = Date.now(); }
      this.seguimiento = r.estado;
    },
    async detener() {
      if (!confirm('¿Cancelar la conexión de ' + (this.aprobada.nombre ? '«' + this.aprobada.nombre + '»' : 'esa computadora') + '? Esa computadora no recibirá nada.')) return;
      this.cargando = true; this.error = '';
      try { this.poner(await api('/api/sinc/conexion/detener', { method: 'POST', body: { pase: this.aprobada.pase } })); }
      catch (e) {     // 7b (T3): el error queda a la vista junto con «Salir», que no depende del servidor
        if (e && e.status === 404) { conexion.fijarPase(''); this.final = PASE_NO_EXISTE; this.paso = 'fin'; this.aprobada = { ...this.aprobada, numero: null }; }
        else this.error = (e && e.message) || 'No se pudo cancelar. Intente de nuevo o toque «Salir».';
      }
      this.cargando = false;
    },
  },
  async created() {
    this._reloj = setInterval(() => { this.ahora = Date.now(); }, 1000);
    try { const j = await api('/api/auth/estado'); if (j && j.local) { this.esPrograma = true; this.web = j.local.web || ''; return; } } catch { /* se sigue: el servidor decide */ }
    // 9b (U17): un código NUEVO que llega en el enlace manda sobre el pase guardado (que se olvida); el pase guardado solo se retoma
    // cuando no hay código nuevo (al aprobar, el código usado se borra de la pestaña)
    if (this.escrito) { conexion.fijarPase(''); await this.buscar(); return; }
    const pid = conexion.leerPase();
    if (pid) await this.retomar(pid);
  },
  beforeUnmount() { this.parar(); clearInterval(this._reloj); },
  template: `
  <div class="login-wrap"><div class="login-card" style="max-width:560px">
    <h1 style="font-size:20px;margin:0 0 6px">Conectar una computadora</h1>
    <template v-if="esPrograma">
      <p class="muted" style="margin:0 0 14px">Esta pantalla es de la página web. Ábrala en {{web || 'la página web'}}.</p>
      <button class="btn" style="width:100%;justify-content:center" @click="salir()">Volver</button>
    </template>
    <template v-else-if="paso === 'buscar'">
      <p class="muted small" style="margin:0 0 14px">Escriba el código que aparece en la pantalla del programa.</p>
      <Field label="Código de la computadora"><input v-model="escrito" class="mono" maxlength="12" placeholder="XXXX-XXXX" style="text-transform:uppercase;font-size:20px;letter-spacing:3px;text-align:center" autocomplete="off" @keyup.enter="buscar"></Field>
      <div class="alert err small" style="margin:12px 0 0" v-if="error">{{error}}</div>
      <button class="btn" style="width:100%;justify-content:center;margin-top:14px;padding:11px" @click="buscar" :disabled="cargando">{{cargando ? 'Buscando…' : 'Buscar'}}</button>
      <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="salir()">Cancelar</button>
    </template>
    <template v-else-if="paso === 'revisar'">
      <p style="margin:0 0 4px">La computadora «<b>{{info.nombre}}</b>» quiere conectarse a su empresa.</p>
      <p class="small muted" style="margin:0 0 4px">Nombre escrito por quien la conecta (no verificado).</p>
      <p class="small" style="margin:0 0 4px">Código: <b class="mono">{{info.codigo}}</b></p>
      <p class="small muted" style="margin:0 0 12px">Pidió conectarse {{hace}}.</p>
      <div class="alert danger small" style="margin:0 0 12px" v-if="!info.misma_conexion"><b>Atención:</b> esa computadora no está usando la misma conexión a internet que usted. Si no sabe quién la tiene, toque «No es mía».</div>
      <div class="alert warn small" style="margin:0 0 12px">Apruebe solo si usted mismo, o alguien de su confianza a quien usted se lo pidió, está frente a esa computadora en este momento. Al aprobar, esa computadora recibe los datos de su empresa y la llave con la que se firman sus facturas ante Hacienda. Nadie de soporte le va a pedir que apruebe una computadora ni que le dicte un número.</div>
      <template v-if="empresas.length > 1">
        <div class="small" style="margin:0 0 6px"><b>¿A cuál empresa la conecta?</b></div>
        <label v-for="e in empresas" :key="e.id" class="row" style="gap:8px;align-items:center;margin:0 0 6px;cursor:pointer"><input type="radio" :value="e.id" v-model="empresaId"><span>{{nombreEmpresa(e)}} <span class="muted small mono">{{e.numero_id}}</span></span></label>
      </template>
      <p class="small" style="margin:0 0 10px" v-else-if="empresas.length === 1">Se conectará a: <b>{{nombreEmpresa(empresas[0])}}</b> <span class="muted mono">{{empresas[0].numero_id}}</span></p>
      <div class="alert err small" style="margin:0 0 10px" v-else-if="info.cedula">Esa computadora ya tiene datos de otra empresa (cédula {{info.cedula}}). Solo se puede conectar a esa empresa, y usted no la administra.</div>
      <div class="alert err small" style="margin:0 0 10px" v-else>Solo un administrador de la empresa puede conectar una computadora. Pídale a un administrador que entre a esta página y la apruebe.</div>
      <div class="alert err small" style="margin:0 0 10px" v-if="bloqueada">{{info.bloqueo || textoBloqueo}}</div>
      <label class="row" style="gap:10px;align-items:flex-start;margin:6px 0 4px;cursor:pointer" v-if="empresas.length"><input type="checkbox" v-model="mismo" style="margin-top:4px"><span class="small">El código <b class="mono">{{info.codigo}}</b> es el mismo que veo en la pantalla del programa.</span></label>
      <p class="small muted" style="margin:4px 0 0" v-if="empresas.length">Al aprobar, esta página le muestra un número de comprobación que se escribe en el programa.</p>
      <div class="alert err small" style="margin:12px 0 0" v-if="error">{{error}}</div>
      <div class="row" style="gap:8px;margin-top:14px;flex-wrap:wrap" v-if="empresas.length">
        <button class="btn" style="flex:1;justify-content:center;padding:11px" @click="aprobar" :disabled="!puedeAprobar">{{elegida ? 'Conectar a ' + nombreEmpresa(elegida) : 'Conectar'}}</button>
        <button class="btn danger" style="flex:1;justify-content:center;padding:11px" @click="rechazar" :disabled="cargando">No es mía: rechazar</button>
      </div>
      <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="salir()">Cancelar</button>
    </template>
    <template v-else-if="paso === 'aprobada'">
      <template v-if="retomado">
        <div class="alert warn" style="margin:0 0 12px">{{textoRetomado}}</div>
      </template>
      <template v-else>
        <p style="margin:0 0 8px"><b>Aprobada. Vuelva al programa</b> en «{{aprobada.nombre}}» y escriba este número de comprobación:</p>
        <div class="mono" style="font-size:46px;font-weight:800;letter-spacing:12px;text-align:center;margin:6px 0 10px">{{aprobada.numero}}</div>
        <div class="alert warn small" style="margin:0 0 12px">Escríbalo solo en el programa que tiene delante; si alguien se lo pide por teléfono o mensaje, es un engaño: toque «Cancelar».</div>
      </template>
      <div class="alert danger small" style="margin:0 0 12px" v-if="seguimiento === 'retenida'"><b>Esa computadora usa otra conexión a internet</b> (o no se pudo comprobar). Por seguridad la entrega espera {{retencion}} y ya avisamos a los administradores de la empresa. Si usted no está frente a esa computadora, toque «Cancelar».</div>
      <p class="small muted" style="margin:0 0 12px" v-else-if="seguimiento === 'en_curso'">Terminando de conectar…</p>
      <p class="small muted" style="margin:0 0 12px" v-else-if="seguimiento">Esperando que el programa termine de conectarse…</p>
      <p class="small muted" style="margin:0 0 12px" v-else>Consultando el estado de la conexión…</p>
      <div class="alert err small" style="margin:0 0 12px" v-if="error">{{error}}</div>
      <button class="btn danger" style="width:100%;justify-content:center" @click="detener" :disabled="!puedeDetener">Cancelar</button>
      <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="salir()">Salir</button>
    </template>
    <template v-else-if="paso === 'listo'">
      <div class="alert ok" style="margin:0 0 10px" v-if="aprobada.nombre">Listo. «{{aprobada.nombre}}» quedó conectada a {{aprobada.empresa}}. Vuelva al programa: en unos segundos le pedirá su correo y su contraseña.</div>
      <div class="alert ok" style="margin:0 0 10px" v-else>Listo. La computadora quedó conectada. Vuelva al programa: en unos segundos le pedirá su correo y su contraseña.</div>
      <p class="small muted" style="margin:0 0 12px">Si el programa le muestra un código distinto, apruebe ese código nuevo.</p>
      <div class="alert info small" style="margin:0 0 12px" v-if="avisoOtra">{{avisoOtra}}</div>
      <button class="btn" style="width:100%;justify-content:center" @click="verComputadoras" v-if="!avisoOtra">Ver las computadoras conectadas</button>
      <button class="btn ghost" style="width:100%;justify-content:center" @click="salir()" v-else>Salir</button>
    </template>
    <template v-else>
      <div class="alert warn" style="margin:0 0 12px">{{final}}</div>
      <button class="btn" style="width:100%;justify-content:center" @click="salir()">Salir</button>
    </template>
  </div></div>`,
  setup() { return { sesion, textoRetomado: TEXTO_RETOMADO, textoBloqueo: FINALES.bloqueada }; },
};
