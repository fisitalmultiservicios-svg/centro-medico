// Bancos y cajas — cuentas bancarias, efectivo y tarjetas (datos de ejemplo en localStorage; backend pendiente)
import { api, money, fmt, fecha, hoy, toast, mock, monedas } from '../../api.js';
import { planCuentas } from '../contabilidad/catalogo.js';

export function dias(n) { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); }
// Tipo de cambio de una moneda respecto a la principal (monedas.get().tipo_cambio está expresado en colones)
export function tc(moneda) { return monedas.tc(moneda) / monedas.tc(monedas.principal().codigo); }   // venta BCCR (la misma que se muestra)
export function aPrincipal(monto, moneda) { return monto * tc(moneda); }

// Cuentas de ejemplo (persisten en localStorage la primera vez)
export function bancosMock() {
  const semilla = [
      { id: 1, nombre: 'Banco Nacional CRC', tipo: 'Banco', moneda: 'CRC', numero: '100-01-000-215487-3', saldo_inicial: 3200000, fecha_saldo: dias(120), saldo: 4865500, descripcion: 'Cuenta corriente principal en colones' },
      { id: 2, nombre: 'BAC Credomatic USD', tipo: 'Banco', moneda: 'USD', numero: '951 234 567', saldo_inicial: 8500, fecha_saldo: dias(120), saldo: 12480.5, descripcion: 'Cuenta en dólares para proveedores del exterior' },
      { id: 3, nombre: 'Caja general', tipo: 'Efectivo', moneda: 'CRC', numero: '', saldo_inicial: 250000, fecha_saldo: dias(120), saldo: 385000, descripcion: 'Efectivo en oficina' },
      { id: 4, nombre: 'Caja chica', tipo: 'Efectivo', moneda: 'CRC', numero: '', saldo_inicial: 100000, fecha_saldo: dias(120), saldo: 62500, descripcion: 'Gastos menores' },
      { id: 5, nombre: 'Tarjeta BCR Visa Empresarial', tipo: 'Tarjeta de crédito', moneda: 'CRC', numero: '**** **** **** 4512', saldo_inicial: 0, fecha_saldo: dias(120), saldo: 618400, descripcion: 'Tarjeta corporativa (el saldo representa la deuda)' },
  ];
  return mock.ejemplos('bancos', semilla, 'nombre');
}

// Movimientos de ejemplo por cuenta (monto positivo = entrada; en tarjetas = aumento de deuda)
export function movimientosMock() {
  const m = (banco_id, d, descripcion, monto) => ({ banco_id, fecha: dias(d), descripcion, monto, conciliado: false });
  const semilla = [
      m(1, 95, 'Depósito Ferretería El Progreso S.A. · FE-0001', 850000), m(1, 80, 'Pago de planilla', -1250000),
      m(1, 60, 'SINPE Comercial La Esquina · FE-0004', 1120000), m(1, 45, 'Pago Kölbi servicios', -48500),
      m(1, 30, 'Depósito Distribuidora Monge · FE-0007', 1450000), m(1, 20, 'Pago alquiler oficina Sabana', -650000),
      m(1, 12, 'Comisión bancaria', -4500), m(1, 8, 'Impuesto bancario', -1500),
      m(1, 5, 'Pago CCSS', -520000), m(1, 2, 'Depósito Soluciones TI del Este · FE-0012', 720000),
      m(2, 70, 'Depósito Exportaciones Caribe S.A.', 3200), m(2, 40, 'Pago Amazon Web Services', -219.5),
      m(2, 15, 'Depósito Tropical Fruits Export', 1500), m(2, 6, 'Pago licencia Microsoft 365', -500),
      m(3, 50, 'Ventas de contado', 215000), m(3, 25, 'Compra de papelería', -35000), m(3, 10, 'Pago mensajería', -45000),
      m(4, 30, 'Compra suministros de limpieza', -37500),
      m(5, 35, 'Combustible Delta', 118400), m(5, 14, 'Compra equipo de cómputo Monge', 500000),
  ].map((x, i) => ({ id: i + 1, ...x }));
  return mock.ejemplos('movimientos', semilla, 'descripcion');
}

const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'set', 'oct', 'nov', 'dic'];

// ---- cuenta principal por moneda y movimientos generados por los pagos (recibidos +, enviados −) ----
export function cuentasActivas() { return (bancosMock() || []).filter(b => b.nombre && b.tipo !== 'Tarjeta de crédito'); }
// Cuentas para cobrar o pagar (nombre, tipo, moneda, principal; sin saldos). Sirve también a roles sin acceso a Bancos.
export async function cuentasParaMovimientos() {
  try { return (await api('/api/bancos/cuentas')).filter(b => b.tipo !== 'Tarjeta de crédito'); } catch { return cuentasActivas(); }
}
// La cuenta marcada como principal en esa moneda; si no hay, el primer banco en esa moneda; si no, cualquier cuenta en esa moneda.
export function cuentaPrincipal(moneda, lista) {
  const l = lista || cuentasActivas(), m = moneda || monedas.principal().codigo;
  return l.find(b => b.principal && (b.moneda || 'CRC') === m) || l.find(b => b.tipo === 'Banco' && (b.moneda || 'CRC') === m) || l.find(b => (b.moneda || 'CRC') === m) || null;
}
// 4.5: la cuenta que propone el medio de pago (como cuentaPara de caja.js): efectivo (01) → cuenta de tipo Efectivo en esa moneda;
// tarjeta, SINPE, transferencia… → cuenta de tipo Banco (la principal si lo es). Sin una del tipo, la principal de la moneda, sin
// caer en la caja cuando el medio no es efectivo; en último caso, la principal.
export function cuentaParaMedio(medio, moneda, lista) {
  const l = lista || cuentasActivas(), m = moneda || monedas.principal().codigo, efectivo = String(medio || '01') === '01';
  const delTipo = l.filter(b => (b.tipo === 'Efectivo') === efectivo && (b.moneda || 'CRC') === m);
  return delTipo.find(b => b.principal) || delTipo.find(b => b.tipo === 'Banco') || delTipo[0] || cuentaPrincipal(m, efectivo ? l : l.filter(b => b.tipo !== 'Efectivo')) || cuentaPrincipal(m, l);
}
export function nombresCuentas(moneda) { return cuentasActivas().filter(b => !moneda || (b.moneda || 'CRC') === moneda).map(b => b.nombre); }   // por moneda (R153)
// ¿Se puede registrar dinero en `moneda` en esa cuenta? Misma moneda, o documento en otra moneda hacia una cuenta en colones
// (se convierte con el tipo de cambio del documento). Devuelve el aviso para el usuario o '' si está bien. Cuentas genéricas
// (que no están en Bancos) no se revisan.
export function problemaMoneda(nombre, moneda, tipoCambio, lista) {
  const b = (lista || cuentasActivas()).find(x => x.nombre === nombre);
  if (!b) return '';
  const mc = b.moneda || 'CRC', md = moneda || mc;
  if (md === mc) return '';
  if (mc === 'CRC') return +tipoCambio > 0 && +tipoCambio !== 1 ? '' : 'Falta el tipo de cambio de ' + md + ' para registrarlo en una cuenta en colones';
  return 'La cuenta «' + nombre + '» está en ' + mc + ' y el movimiento en ' + md + ': elija una cuenta en ' + md + ' o en colones';
}
// Texto de ayuda cuando el documento y la cuenta tienen distinta moneda (cuánto entra o sale de la cuenta)
export function avisoConversion(nombre, monto, moneda, tipoCambio, lista) {
  const b = (lista || cuentasActivas()).find(x => x.nombre === nombre);
  if (!b || (b.moneda || 'CRC') === (moneda || 'CRC') || problemaMoneda(nombre, moneda, tipoCambio, lista)) return '';
  return 'La cuenta está en colones: se registrarán ' + money(Math.round((+monto || 0) * (+tipoCambio) * 100) / 100, 'CRC') + ' (tipo de cambio ' + fmt(+tipoCambio, 2) + ').';
}
// Saldo de una cuenta = saldo inicial + todos sus movimientos (cobros, pagos, planillas, transferencias…). Se calcula siempre:
// así un cobro registrado por el servidor o por otro usuario se refleja sin que nadie tenga que escribir el saldo.
export function saldoDe(b, movs) {
  const t = (movs || []).reduce((s, m) => s + (m.banco_id === b.id ? (+m.monto || 0) : 0), 0);
  return Math.round(((+b.saldo_inicial || 0) + t) * 100) / 100;
}
// Movimiento de un pago a proveedor, planilla o liquidación (monto + entrada, − salida). Lo registra el servidor (idempotente
// por ref; con reemplazar sustituye el de esa ref): funciona para roles sin acceso a Bancos (RRHH) y sin pisar a otros usuarios.
export function refUnica(prefijo) { return prefijo + ':' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
// moneda/tipoCambio: los del documento; el servidor pasa el monto a la moneda de la cuenta (un pago en dólares que sale de una
// cuenta en colones se convierte con el tipo de cambio del pago).
export async function registrarMovimientoBanco(nombre, monto, fecha, descripcion, ref, reemplazar = false, moneda = null, tipoCambio = null) {
  if (!nombre || !(+monto)) return false;
  try {
    const r = await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: nombre, monto: Math.round(+monto * 100) / 100, fecha: fecha || hoy(), descripcion, ref, reemplazar, moneda, tipo_cambio: +tipoCambio || null } });
    await mock.refrescar(['movimientos']);
    if (!r.ok) toast('No se registró el movimiento en Bancos: la cuenta «' + nombre + '» no existe en Bancos y cajas o ya hay un movimiento con esa referencia', 'err');
    return !!r.ok;
  } catch (e) { toast('No se pudo registrar el movimiento bancario: ' + e.message, 'err'); return false; }
}
export async function revertirMovimientoBanco(refs) {
  const l = (Array.isArray(refs) ? refs : [refs]).filter(Boolean);
  if (!l.length) return false;
  // las refs van en el cuerpo: un borrado masivo de muchos pagos no cabe en la dirección
  try { await api('/api/bancos/movimientos/quitar', { method: 'POST', body: { refs: l } }); await mock.refrescar(['movimientos']); return true; }
  catch (e) { toast('No se pudo quitar el movimiento bancario: ' + e.message, 'err'); return false; }
}

export default {
  props: ['params'],
  data() {
    return {
      bancos: bancosMock(), movimientos: movimientosMock(), q: '', periodo: 6,
      modal: null, ver: null, monedasOpc: monedas.opciones(), principal: monedas.principal(),
      nuevo: { nombre: '', tipo: 'Banco', moneda: 'CRC', numero: '', saldo_inicial: null, fecha_saldo: hoy(), descripcion: '', principal: false, cuenta_contable: '' },
      cuentasContables: planCuentas().filter(c => c.hoja && c.codigo.startsWith('1.1.01')),
      tr: { origen: 1, destino: 2, monto: null, fecha: hoy(), observaciones: '' },
    };
  },
  computed: {
    columns() {
      return [
        { key: 'nombre', label: 'Nombre' }, { key: 'principal', label: 'Principal', fmt: (v, r) => v ? '★ en ' + (r.moneda || 'CRC') : '' }, { key: 'tipo', label: 'Tipo de cuenta', fmt: 'badge' },
        { key: 'numero', label: 'Número de cuenta', mono: true, fmt: v => v || '—' },
        { key: 'saldo', label: 'Saldo', num: true, fmt: (v, r) => money(saldoDe(r, this.movimientos), r.moneda) },
      ];
    },
    saldoBancos() { return this.bancos.filter(b => b.tipo !== 'Tarjeta de crédito').reduce((s, b) => s + aPrincipal(saldoDe(b, this.movimientos), b.moneda), 0); },
    deudaTarjetas() { return this.bancos.filter(b => b.tipo === 'Tarjeta de crédito').reduce((s, b) => s + aPrincipal(saldoDe(b, this.movimientos), b.moneda), 0); },
    tiposCambio() { return monedas.list().filter(m => m.codigo !== 'CRC').map(m => money(monedas.tc(m.codigo), 'CRC') + ' por ' + m.codigo).join(' · '); },
    meses() {
      const out = [], now = new Date();
      for (let i = this.periodo - 1; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        out.push({ k: MESES[d.getMonth()] + ' ' + String(d.getFullYear()).slice(2), ym: d.toISOString().slice(0, 7), ing: 0, gas: 0 });
      }
      for (const mv of this.movimientos) {
        const b = this.bancos.find(x => x.id === mv.banco_id); if (!b) continue;
        const m = out.find(x => x.ym === mv.fecha.slice(0, 7)); if (!m) continue;
        const v = aPrincipal(Math.abs(mv.monto), b.moneda);
        if (String(mv.ref || '').startsWith('tr:') || mv.transferencia) continue;      // transferencias entre cuentas propias no son ingreso ni gasto (R186)
        const entrada = b.tipo === 'Tarjeta de crédito' ? mv.monto < 0 : mv.monto > 0;
        if (entrada) m.ing += v; else m.gas += v;
      }
      const max = Math.max(1, ...out.map(x => Math.max(x.ing, x.gas)));
      return out.map(x => ({ ...x, hi: Math.round(x.ing / max * 150), hg: Math.round(x.gas / max * 150) }));
    },
    totIng() { return this.meses.reduce((s, m) => s + m.ing, 0); },
    totGas() { return this.meses.reduce((s, m) => s + m.gas, 0); },
    movsVer() { return this.ver ? this.movimientos.filter(m => m.banco_id === this.ver.id).sort((a, b) => b.fecha.localeCompare(a.fecha)) : []; },
  },
  methods: {
    money, fmt, fecha, saldoDe,
    guardar() { mock.set('bancos', this.bancos); mock.set('movimientos', this.movimientos); },
    agregar() {
      const n = this.nuevo;
      if (!n.nombre.trim() || n.saldo_inicial === null || n.saldo_inicial === '' || !n.fecha_saldo) return toast('Complete los campos obligatorios', 'err');
      if (this.bancos.some(b => b.nombre.trim().toLowerCase() === n.nombre.trim().toLowerCase())) return toast('Ya existe una cuenta con ese nombre', 'err');   // (R181)
      if (n.principal) for (const b of this.bancos) if ((b.moneda || 'CRC') === n.moneda) b.principal = false;
      this.bancos.push({ id: mock.nextId(this.bancos, 'bancos'), ...n, saldo_inicial: +n.saldo_inicial, saldo: +n.saldo_inicial });
      this.guardar(); this.modal = null; toast('Cuenta «' + n.nombre + '» creada', 'ok');
      this.nuevo = { nombre: '', tipo: 'Banco', moneda: 'CRC', numero: '', saldo_inicial: null, fecha_saldo: hoy(), descripcion: '', principal: false, cuenta_contable: '' };
    },
    transferir() {
      const t = this.tr, o = this.bancos.find(b => b.id == t.origen), d = this.bancos.find(b => b.id == t.destino);
      if (!o || !d || o.id === d.id) return toast('Seleccione cuentas distintas', 'err');
      if (!(+t.monto > 0)) return toast('Indique un monto mayor a cero', 'err');
      const monto = +t.monto;
      const montoDest = o.moneda === d.moneda ? monto : +(monto * tc(o.moneda) / tc(d.moneda)).toFixed(2);
      const id = mock.nextId(this.movimientos, 'movimientos'), desc = 'Transferencia ' + o.nombre + ' → ' + d.nombre + (t.observaciones ? ' · ' + t.observaciones : '');
      // En una tarjeta de crédito el saldo es deuda: pagarla desde el banco la BAJA (y un adelanto de efectivo la sube).
      // Antes siempre se restaba al origen y se sumaba al destino, así que pagar la tarjeta aumentaba la deuda.
      const tarjeta = b => b.tipo === 'Tarjeta de crédito';
      const sale = tarjeta(o) ? monto : -monto, entra = tarjeta(d) ? -montoDest : montoDest;
      this.movimientos.push({ transferencia: true, id, banco_id: o.id, fecha: t.fecha, descripcion: desc, monto: sale, conciliado: false }, { id: id + 1, banco_id: d.id, fecha: t.fecha, descripcion: desc, monto: entra, conciliado: false });
      this.guardar(); this.modal = null; toast('Transferencia de ' + money(monto, o.moneda) + ' registrada', 'ok');
      this.tr = { origen: 1, destino: 2, monto: null, fecha: hoy(), observaciones: '' };
    },
    hacerPrincipal(b) {
      for (const x of this.bancos) if ((x.moneda || 'CRC') === (b.moneda || 'CRC')) x.principal = x.id === b.id;
      this.guardar(); toast('«' + b.nombre + '» es ahora la cuenta principal en ' + (b.moneda || 'CRC') + ': los cobros entran y los pagos salen de ahí salvo que elija otra', 'ok');
    },
    eliminar(b) { if (this.movimientos.some(m => m.banco_id === b.id)) return toast('La cuenta «' + b.nombre + '» tiene movimientos y no se puede eliminar (se perdería el historial de cobros y pagos); déjela sin uso', 'err');   // (R181)
      if (!confirm('¿Eliminar la cuenta «' + b.nombre + '»? Se perderán sus movimientos de ejemplo.')) return;
      this.bancos = this.bancos.filter(x => x.id !== b.id); this.movimientos = this.movimientos.filter(m => m.banco_id !== b.id);
      this.guardar(); toast('Cuenta eliminada');
    },
    eliminarVarios(rows) { const conMov = rows.filter(b => this.movimientos.some(m => m.banco_id === b.id)); if (conMov.length) toast(conMov.length + ' cuenta(s) con movimientos no se eliminan', 'err'); rows = rows.filter(b => !conMov.includes(b)); if (!rows.length) return;
      const ids = rows.map(r => r.id);
      this.bancos = this.bancos.filter(x => !ids.includes(x.id)); this.movimientos = this.movimientos.filter(m => !ids.includes(m.banco_id));
      this.guardar(); toast(ids.length + ' cuentas eliminadas (con sus movimientos de ejemplo)', 'ok');
    },
  },
  template: `
  <div class="page">
    <PageHead title="Bancos y cajas" sub="Sus cuentas bancarias, cajas y tarjetas. Marque una cuenta principal por moneda: los cobros entran y los pagos salen de ella salvo que elija otra en el documento.">
      <button class="btn ghost" v-if="puede('gastos')" @click="modal='tr'">⇄ Transferir</button>
      <button class="btn" v-if="puede('gastos')" @click="modal='nuevo'">+ Agregar banco</button>
    </PageHead>

    <div class="dash" style="margin-bottom:18px">
      <div class="card w6" style="margin:0"><h2>Ingresos y gastos <small>consolidado en {{principal.codigo}}</small>
          <select class="inp" v-model.number="periodo" style="float:right;padding:4px 8px;font-size:12.5px"><option :value="6">Últimos 6 meses</option><option :value="12">Últimos 12 meses</option></select></h2>
        <div class="chart" style="height:190px"><div class="b" v-for="m in meses" :key="m.ym">
          <div style="display:flex;gap:3px;align-items:flex-end;justify-content:center;width:100%;height:150px"><i :style="{height:m.hi+'px'}" :title="'Ingresos '+money(m.ing, principal.codigo)"></i><i class="red" :style="{height:m.hg+'px'}" :title="'Gastos '+money(m.gas, principal.codigo)"></i></div>{{m.k}}</div></div>
        <div class="legend" style="margin-top:8px"><span><i style="background:var(--primary)"></i>Ingresos {{money(totIng, principal.codigo)}}</span><span><i style="background:var(--danger)"></i>Gastos {{money(totGas, principal.codigo)}}</span></div>
      </div>
      <div class="card w6" style="margin:0"><h2>Resumen <small>en {{principal.codigo}} · tipo de cambio {{tiposCambio}}</small></h2>
        <div class="totals" style="align-items:stretch;margin-top:0">
          <div><span>Saldo en bancos y efectivo</span><b>{{money(saldoBancos, principal.codigo)}}</b></div>
          <div><span>− Deuda en tarjetas</span><b style="color:var(--danger)">{{money(deudaTarjetas, principal.codigo)}}</b></div>
          <div class="total"><span>Saldo total</span><b>{{money(saldoBancos - deudaTarjetas, principal.codigo)}}</b></div>
        </div>
        <p class="small muted" style="margin:12px 0 0">{{bancos.length}} cuentas · las cuentas en otras monedas se convierten al tipo de cambio configurado en Configuración › Monedas.</p>
      </div>
    </div>

    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cuenta" v-model="q"><button class="btn ghost sm">⚲ Filtrar</button><button class="btn ghost sm" @click="bancos=bancosMock()">↻ Actualizar</button></div>
      <DataTable :rows="bancos" :columns="columns" :search="q" :selectable="puede('gastos')" :on-bulk-delete="eliminarVarios" empty-title="Aún no tienes cuentas" empty-text="Agrega tu primer banco o caja para controlar tus saldos.">
        <template #actions="{row}">
          <button class="btn icon" v-if="row.tipo !== 'Tarjeta de crédito'" :title="row.principal ? 'Cuenta principal en ' + (row.moneda||'CRC') : 'Hacer principal en ' + (row.moneda||'CRC')" @click.stop="hacerPrincipal(row)">{{row.principal ? '★' : '☆'}}</button>
          <a class="btn sm sec" :href="'#/bancos/conciliaciones/'+row.id" @click.stop>Conciliar</a>
          <button class="btn icon" title="Ver movimientos" @click.stop="ver=row">👁</button>
          <button class="btn icon" v-if="puede('gastos')" title="Eliminar" @click.stop="eliminar(row)">🗑</button>
        </template>
        <template #empty><button class="btn" v-if="puede('gastos')" @click="modal='nuevo'">+ Agregar banco</button></template>
      </DataTable>
    </div>

    <Modal v-if="modal==='nuevo'" title="Agregar banco" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="nuevo.nombre" placeholder="Ej. Banco de Costa Rica CRC"></Field>
        <Field label="Tipo de cuenta" req><select v-model="nuevo.tipo"><option>Banco</option><option>Efectivo</option><option>Tarjeta de crédito</option></select></Field>
        <Field label="Moneda"><select v-model="nuevo.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Número de cuenta"><input v-model="nuevo.numero" placeholder="IBAN o número de cuenta"></Field>
        <Field label="Saldo inicial" req><input type="number" step="0.01" v-model.number="nuevo.saldo_inicial"></Field>
        <Field label="Fecha de saldo inicial" req><input type="date" v-model="nuevo.fecha_saldo"></Field>
        <Field label="Cuenta contable" help="Para los asientos automáticos de cobros y pagos; si se deja vacía se usa la de Parametrización"><select v-model="nuevo.cuenta_contable"><option value="">— Según parametrización —</option><option v-for="c in cuentasContables" :key="c.codigo" :value="c.codigo + ' ' + c.nombre">{{c.codigo}} · {{c.nombre}}</option></select></Field>
        <Field label="Cuenta principal" help="Los cobros en esta moneda entran aquí y los pagos salen de aquí, salvo que elija otra"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="nuevo.principal"> Principal en {{nuevo.moneda}}</label></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea rows="2" v-model="nuevo.descripcion"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="agregar">Guardar</button></template>
    </Modal>

    <Modal v-if="modal==='tr'" title="Transferir entre cuentas" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Cuenta origen" req><select v-model="tr.origen"><option v-for="b in bancos" :key="b.id" :value="b.id">{{b.nombre}} · {{money(saldoDe(b, movimientos),b.moneda)}}</option></select></Field>
        <Field label="Cuenta destino" req><select v-model="tr.destino"><option v-for="b in bancos" :key="b.id" :value="b.id">{{b.nombre}} · {{money(saldoDe(b, movimientos),b.moneda)}}</option></select></Field>
        <Field label="Monto" req help="En la moneda de la cuenta origen; se convierte con el tipo de cambio configurado si las monedas difieren."><input type="number" step="0.01" v-model.number="tr.monto"></Field>
        <Field label="Fecha" req><input type="date" v-model="tr.fecha"></Field>
        <Field label="Observaciones" style="grid-column:1/-1"><textarea rows="2" v-model="tr.observaciones"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="transferir">Transferir</button></template>
    </Modal>

    <Modal v-if="ver" :title="ver.nombre" lg @close="ver=null">
      <div class="row" style="margin-bottom:12px"><span class="chip">{{ver.tipo}}</span><span class="chip" v-if="ver.numero">{{ver.numero}}</span><span class="chip on">Saldo {{money(saldoDe(ver, movimientos), ver.moneda)}}</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fecha</th><th>Descripción</th><th class="num">Monto</th><th>Estado</th></tr></thead>
        <tbody><tr v-for="m in movsVer" :key="m.id"><td>{{fecha(m.fecha)}}</td><td style="white-space:normal">{{m.descripcion}}</td><td class="num" :style="{color: m.monto<0?'var(--danger)':'var(--ok)'}">{{money(m.monto, ver.moneda)}}</td><td><Badge :value="m.conciliado?'Conciliado':'No conciliado'"></Badge></td></tr></tbody>
      </table></div>
      <Empty v-if="!movsVer.length" icon="🏦" title="Sin movimientos" text="Esta cuenta todavía no tiene transacciones."></Empty>
      <template #foot><a class="btn sec" :href="'#/bancos/conciliaciones/'+ver.id">Conciliar</a><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { bancosMock }; },
};
