// Conciliaciones bancarias — lista (datos de ejemplo en localStorage; backend pendiente)
import { money, fecha, hoy, toast, mock, sumarMeses } from '../../api.js';
import { bancosMock, movimientosMock, saldoDe, dias } from './cuentas.js';

function primerDia(n) { return sumarMeses(hoy(), -n, 1); }                 // hora local (R194)
function ultimoDia(n) { return sumarMeses(hoy(), -n + 1, 0); }

export function conciliacionesMock() {
  const semilla = [
      { id: 1, banco_id: 1, banco: 'Banco Nacional CRC', moneda: 'CRC', desde: primerDia(3), hasta: ultimoDia(3), saldo_bancario: 3200000, diferencia: 0, estado: 'Conciliada', fecha: dias(70) },
      { id: 2, banco_id: 2, banco: 'BAC Credomatic USD', moneda: 'USD', desde: primerDia(2), hasta: ultimoDia(2), saldo_bancario: 11700, diferencia: 0, estado: 'Conciliada', fecha: dias(38) },
      { id: 3, banco_id: 1, banco: 'Banco Nacional CRC', moneda: 'CRC', desde: primerDia(1), hasta: ultimoDia(1), saldo_bancario: 4118000, diferencia: -4500, estado: 'En proceso', fecha: dias(6) },
  ];
  return mock.ejemplos('conciliaciones', semilla, 'banco');
}

export default {
  props: ['params'],
  data() {
    return { movs: movimientosMock(), lista: conciliacionesMock(), bancos: bancosMock(), q: '', modal: false, f: { banco_id: 1, desde: primerDia(0), hasta: hoy() } };
  },
  computed: {
    rows() { return this.lista.slice().sort((a, b) => b.fecha.localeCompare(a.fecha)).map(c => ({ ...c, periodo: fecha(c.desde) + ' – ' + fecha(c.hasta) })); },
    columns() {
      return [
        { key: 'banco', label: 'Banco', link: r => this.abrir(r) },
        { key: 'periodo', label: 'Período' },
        { key: 'saldo_bancario', label: 'Saldo bancario', num: true, fmt: 'money' },
        { key: 'diferencia', label: 'Diferencia', num: true, fmt: (v, r) => money(v, r.moneda), class: 'dif' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
      ];
    },
  },
  methods: {
    saldoDe,
    money, fecha,
    abrir(c) { location.hash = '/bancos/conciliaciones/' + c.banco_id + '?desde=' + c.desde + '&hasta=' + c.hasta; },
    nueva() {
      if (!this.f.banco_id || !this.f.desde || !this.f.hasta) return toast('Seleccione el banco y el rango de fechas', 'err');
      if (this.f.desde > this.f.hasta) return toast('La fecha inicial debe ser anterior a la final', 'err');
      this.modal = false;
      location.hash = '/bancos/conciliaciones/' + this.f.banco_id + '?desde=' + this.f.desde + '&hasta=' + this.f.hasta;
    },
    eliminar(c) {
      if (!confirm('¿Eliminar la conciliación de ' + c.banco + ' (' + fecha(c.desde) + ' – ' + fecha(c.hasta) + ')?')) return;
      this.lista = this.lista.filter(x => x.id !== c.id); mock.set('conciliaciones', this.lista); this.quitarAjustes([c]); toast('Conciliación eliminada');
    },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = this.lista.filter(x => !ids.includes(x.id)); mock.set('conciliaciones', this.lista); this.quitarAjustes(rows); toast(ids.length + ' conciliaciones eliminadas', 'ok'); },
    // los ajustes de una conciliación eliminada (movimientos 'conc:<banco>:<desde>:<hasta>:…') también se quitan del banco
    quitarAjustes(concs) {
      const pre = concs.map(c => 'conc:' + c.banco_id + ':' + c.desde + ':' + c.hasta + ':');
      mock.actualizar('movimientos', l => (Array.isArray(l) ? l : []).filter(m => !pre.some(p => String(m.ref || '').startsWith(p))), []);
    },
    estadoVarios(rows, estado) {
      if (estado === 'Conciliada') { const conDif = rows.filter(r => Math.abs(+r.diferencia || 0) > 0.005); if (conDif.length) toast(conDif.length + ' conciliación(es) con diferencia no se marcan como conciliadas', 'err'); rows = rows.filter(r => Math.abs(+r.diferencia || 0) <= 0.005); if (!rows.length) return; } /* R199 */ for (const r of rows) { const x = this.lista.find(y => y.id === r.id); if (x) x.estado = estado; } mock.set('conciliaciones', this.lista); toast(rows.length + ' conciliaciones marcadas como ' + estado.toLowerCase(), 'ok'); },
    bulk() {
      return [
        { label: '✔ Marcar conciliadas', kind: 'sec', confirm: '¿Marcar {n} conciliaciones como conciliadas?', handler: rows => this.estadoVarios(rows, 'Conciliada') },
        { label: '↺ Reabrir', kind: 'sec', handler: rows => this.estadoVarios(rows, 'En proceso') },
      ];
    },
  },
  template: `
  <div class="page">
    <PageHead title="Conciliaciones bancarias" sub="Compare los movimientos registrados con el estado de cuenta de su banco." :crumbs="[{label:'Bancos',to:'/bancos'},{label:'Conciliaciones bancarias'}]" mock>
      <button class="btn" @click="modal=true">+ Nueva conciliación</button>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar banco o estado" v-model="q"><button class="btn ghost sm">⚲ Filtrar</button><button class="btn ghost sm" @click="lista=conciliacionesMock()">↻ Actualizar</button></div>
      <DataTable :rows="rows" :columns="columns" :search="q" selectable :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has realizado conciliaciones" empty-text="Concilia tus cuentas bancarias para asegurarte de que los saldos coincidan con tu banco.">
        <template #actions="{row}">
          <button class="btn sm sec" @click.stop="abrir(row)">{{row.estado==='Conciliada' ? 'Ver' : 'Continuar'}}</button>
          <button class="btn icon" title="Eliminar" @click.stop="eliminar(row)">🗑</button>
        </template>
        <template #empty><button class="btn" @click="modal=true">+ Nueva conciliación</button></template>
      </DataTable>
    </div>

    <Modal v-if="modal" title="Nueva conciliación" @close="modal=false">
      <div class="grid cols-2">
        <Field label="Banco" req style="grid-column:1/-1"><select v-model.number="f.banco_id"><option v-for="b in bancos.filter(x=>x.tipo!=='Efectivo')" :key="b.id" :value="b.id">{{b.nombre}} · {{money(saldoDe(b, movs),b.moneda)}}</option></select></Field>
        <Field label="Desde" req><input type="date" v-model="f.desde"></Field>
        <Field label="Hasta" req><input type="date" v-model="f.hasta"></Field>
      </div>
      <p class="small muted">Las cajas de efectivo no se concilian; sus saldos se ajustan con arqueos.</p>
      <template #foot><button class="btn ghost" @click="modal=false">Cancelar</button><button class="btn" @click="nueva">Continuar</button></template>
    </Modal>
  </div>`,
  setup() { return { conciliacionesMock }; },
};
