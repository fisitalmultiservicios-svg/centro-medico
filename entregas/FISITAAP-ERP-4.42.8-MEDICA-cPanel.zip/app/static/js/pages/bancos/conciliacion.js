// Conciliación bancaria — detalle para el banco params.id (datos de ejemplo en localStorage; backend pendiente)
import { money, fecha, hoy, toast, mock } from '../../api.js';
import { bancosMock, movimientosMock } from './cuentas.js';
import { conciliacionesMock } from './conciliaciones.js';

function primerDiaMes() { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10); }
// Ajustes bancarios (comisiones, impuestos, intereses) de una conciliación: se guardan como movimientos de la cuenta con esta
// referencia, así cambian el saldo y el mes siguiente no reaparece la diferencia.
const AJUSTES = [
  { k: 'gastos', nombre: 'Gastos bancarios', signo: -1 },
  { k: 'impuestos', nombre: 'Impuestos bancarios', signo: -1 },
  { k: 'entradas', nombre: 'Entradas bancarias', signo: 1 },
];
const prefijoAjuste = (bancoId, desde, hasta) => 'conc:' + bancoId + ':' + desde + ':' + hasta + ':';

// ---- lectura del estado de cuenta (CSV) ----
// Filas respetando comillas ("Pago a Juan, S.A."), con el separador de columnas que más se repite fuera de comillas.
export function leerCsv(texto) {
  const lineas = String(texto || '').replace(/^\uFEFF/, '').split(/\r?\n/).filter(l => l.trim());
  const cuenta = (l, sep) => { let n = 0, q = false; for (const ch of l) { if (ch === '"') q = !q; else if (!q && ch === sep) n++; } return n; };
  const muestra = lineas.slice(0, 5);
  const sep = [';', '\t', ','].map(s => [s, muestra.reduce((t, l) => t + cuenta(l, s), 0)]).sort((a, b) => b[1] - a[1])[0];
  const s = sep && sep[1] > 0 ? sep[0] : ',';
  return lineas.map(l => {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < l.length; i++) {
      const ch = l[i];
      if (ch === '"') { if (q && l[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
      else if (ch === s && !q) { out.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    out.push(cur.trim());
    return out;
  });
}
// Monto en formato tico (1.250.000,00) o inglés (1,250,000.00); paréntesis o signo menos = negativo. NaN si no se entiende.
export function leerMonto(texto) {
  let s = String(texto ?? '').trim().replace(/[₡$€\s]/g, '').replace(/^(?:CRC|USD|EUR)/i, '');
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  if (s.startsWith('-')) { neg = !neg; s = s.slice(1); } else if (s.endsWith('-')) { neg = !neg; s = s.slice(0, -1); }
  if (!/^[\d.,]+$/.test(s) || !/\d/.test(s)) return NaN;
  const coma = s.lastIndexOf(','), punto = s.lastIndexOf('.');
  const nComas = (s.match(/,/g) || []).length, nPuntos = (s.match(/\./g) || []).length;
  if (coma > -1 && punto > -1) s = coma > punto ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');   // el último es el decimal
  else if (coma > -1) s = nComas === 1 && s.length - coma - 1 !== 3 ? s.replace(',', '.') : s.replace(/,/g, '');
  else if (punto > -1 && (nPuntos > 1 || s.length - punto - 1 === 3)) s = s.replace(/\./g, '');               // 1.250 = mil doscientos cincuenta
  const v = Number(s);
  return Number.isFinite(v) ? Math.round((neg ? -v : v) * 100) / 100 : NaN;
}
// Fecha AAAA-MM-DD o DD/MM/AAAA (también con guiones); '' si no se entiende.
export function leerFecha(texto) {
  const s = String(texto || '').trim();
  let m = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (m) return m[1] + '-' + m[2].padStart(2, '0') + '-' + m[3].padStart(2, '0');
  m = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
  if (m) return m[3] + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0');
  return '';
}
const diasEntre = (a, b) => Math.abs((new Date(a + 'T00:00:00') - new Date(b + 'T00:00:00')) / 86400000);

export default {
  props: ['params'],
  data() {
    const bancos = bancosMock(), banco = bancos.find(b => b.id == this.params.id) || null;
    return {
      banco, movimientos: movimientosMock(),
      desde: this.params.desde || primerDiaMes(), hasta: this.params.hasta || hoy(),
      saldo_bancario: null, extra: { gastos: 0, impuestos: 0, entradas: 0 },
      editarRango: false, edDesde: '', edHasta: '', guardando: false,
    };
  },
  created() { this.cargarConc(); },
  // Cambiar el rango solo cambia la consulta de la dirección (la pantalla no se vuelve a montar): se recargan el período y lo
  // guardado de ESE período (antes quedaban los valores del rango anterior y al guardar se duplicaban o borraban ajustes).
  watch: {
    params(v) {
      this.desde = (v && v.desde) || primerDiaMes(); this.hasta = (v && v.hasta) || hoy();
      this.movimientos = movimientosMock(); this.cargarConc();
    },
  },
  computed: {
    mon() { return this.banco?.moneda || 'CRC'; },
    // en tarjetas de crédito el saldo es deuda: un cargo del banco la aumenta
    esTarjeta() { return this.banco?.tipo === 'Tarjeta de crédito'; },
    prefijo() { return this.banco ? prefijoAjuste(this.banco.id, this.desde, this.hasta) : '\u0000'; },
    // los ajustes de ESTA conciliación están en los campos de arriba: sus movimientos no se cuentan otra vez en el período
    movsBanco() { return this.movimientos.filter(m => m.banco_id === this.banco?.id && !String(m.ref || '').startsWith(this.prefijo)); },
    anteriores() { return this.movsBanco.filter(m => m.fecha < this.desde); },
    enRango() { return this.movsBanco.filter(m => m.fecha >= this.desde && m.fecha <= this.hasta).sort((a, b) => a.fecha.localeCompare(b.fecha)); },
    saldoAnterior() { return (this.banco?.saldo_inicial || 0) + this.anteriores.reduce((s, m) => s + m.monto, 0); },
    entradas() { return this.enRango.filter(m => m.monto > 0).reduce((s, m) => s + m.monto, 0); },
    salidas() { return this.enRango.filter(m => m.monto < 0).reduce((s, m) => s - m.monto, 0); },
    ajustes() { const s = this.esTarjeta ? -1 : 1; return AJUSTES.reduce((t, a) => t + s * a.signo * (+this.extra[a.k] || 0), 0); },
    saldoTotal() { return this.saldoAnterior + this.entradas - this.salidas + this.ajustes; },
    diferencia() { return this.saldo_bancario === null || this.saldo_bancario === '' ? null : +((+this.saldo_bancario) - this.saldoTotal).toFixed(2); },
    conciliados() { return this.enRango.filter(m => m.conciliado).length; },
  },
  methods: {
    money, fecha,
    // la conciliación guardada de esta cuenta y este período (también al abrir sin fechas: se busca la del rango por defecto)
    cargarConc() {
      const conc = this.banco ? conciliacionesMock().find(c => c.banco_id == this.banco.id && c.desde === this.desde && c.hasta === this.hasta) : null;
      // al reabrir, los ajustes guardados vuelven a sus campos (antes arrancaban en 0 y la conciliación pasaba a 'En proceso')
      this.saldo_bancario = conc ? conc.saldo_bancario : null;
      this.extra = { gastos: conc ? (+conc.gastos || 0) : 0, impuestos: conc ? (+conc.impuestos || 0) : 0, entradas: conc ? (+conc.entradas || 0) : 0 };
    },
    guardarMovs() { mock.set('movimientos', this.movimientos); },
    toggleTodos(e) { for (const m of this.enRango) m.conciliado = e.target.checked; this.guardarMovs(); },
    // Estado de cuenta: cada línea se empareja con un movimiento ya registrado de la cuenta (mismo monto, hasta 3 días de
    // diferencia, sin conciliar) y lo marca conciliado; si no hay, se agrega como movimiento importado (comisiones, intereses…).
    // Volver a importar el mismo archivo no duplica nada. Columnas: fecha, descripción, monto (o débito y crédito).
    importar(e) {
      const file = e.target.files[0]; if (!file) return;
      if (!mock.puedeGuardar()) { e.target.value = ''; return; }
      const r = new FileReader();
      r.onload = () => {
        const filas = leerCsv(r.result);
        const cab = (filas[0] || []).map(x => x.toLowerCase());
        const iDeb = cab.findIndex(x => /d[eé]bito|cargo|retiro/.test(x)), iCred = cab.findIndex(x => /cr[eé]dito|abono|dep[oó]sito/.test(x));
        const leidas = [], descartadas = [];
        filas.forEach((c, i) => {
          const f = leerFecha(c[0]);
          let monto = NaN;
          if (iDeb > 1 && iCred > 1) {
            const d = leerMonto(c[iDeb] || '0'), k = leerMonto(c[iCred] || '0'), deb = Number.isFinite(d) ? Math.abs(d) : 0, cred = Number.isFinite(k) ? k : 0;
            monto = this.esTarjeta ? deb - cred : cred - deb;          // en la tarjeta un cargo (débito) AUMENTA la deuda
          }
          else monto = leerMonto(c[2]);
          if (!f || !Number.isFinite(monto) || !monto) { if (i > 0 || f) descartadas.push(i + 1); return; }      // la primera fila puede ser el encabezado
          leidas.push({ fecha: f, descripcion: (c[1] || '').trim() || 'Movimiento importado', monto });
        });
        const b = this.banco, pre = this.prefijo;
        let emparejados = 0, nuevos = 0, repetidos = 0;
        const res = mock.actualizar('movimientos', l => {
          const lista = Array.isArray(l) ? l : [];
          // ya importados antes con la misma fecha, monto y descripción: no se repiten (se cuentan por clave)
          const clave = x => x.fecha + '|' + x.monto + '|' + x.descripcion;
          // ya traídas de un estado de cuenta antes (importadas o emparejadas): no se repiten (se cuentan por clave)
          const previos = {}, usados = new Set();
          for (const m of lista) if (m.banco_id === b.id && (m.importado || m.extracto)) { const k = m.extracto || clave(m); previos[k] = (previos[k] || 0) + 1; }
          for (const x of leidas) {
            if (previos[clave(x)] > 0) { previos[clave(x)]--; repetidos++; continue; }
            // candidatos: movimientos registrados sin conciliar, o ajustes de conciliación (una comisión ya anotada a mano)
            // también los ya marcados a mano como conciliados (sin extracto): antes se duplicaban; primero los no conciliados
            const cand = lista.filter(m => m.banco_id === b.id && !usados.has(m.id) && !m.importado && !m.extracto
                                         && (!m.ajuste || String(m.ref || '').startsWith(pre))       // ajustes: solo los de esta conciliación
                                         && Math.abs((+m.monto || 0) - x.monto) < 0.005 && diasEntre(m.fecha, x.fecha) <= 3)
              .sort((a, z) => (a.conciliado ? 1 : 0) - (z.conciliado ? 1 : 0) || diasEntre(a.fecha, x.fecha) - diasEntre(z.fecha, x.fecha))[0];
            if (cand) { cand.conciliado = true; cand.extracto = clave(x); usados.add(cand.id); emparejados++; continue; }
            lista.push({ id: mock.nextId(lista, 'movimientos'), banco_id: b.id, fecha: x.fecha, descripcion: x.descripcion, monto: x.monto, conciliado: true, importado: true });
            nuevos++;
          }
          return lista;
        }, []);
        this.movimientos = res; e.target.value = '';
        const partes = [];
        if (emparejados) partes.push(emparejados + ' emparejados con movimientos ya registrados');
        if (nuevos) partes.push(nuevos + ' nuevos');
        if (repetidos) partes.push(repetidos + ' ya importados antes (no se repiten)');
        if (descartadas.length) partes.push(descartadas.length + ' filas descartadas (línea' + (descartadas.length > 1 ? 's ' : ' ') + descartadas.slice(0, 8).join(', ') + (descartadas.length > 8 ? '…' : '') + ')');
        if (!leidas.length) return toast('No se encontraron filas válidas. Formato esperado: fecha (AAAA-MM-DD o DD/MM/AAAA), descripción, monto' + (descartadas.length ? ' · ' + partes.join(' · ') : ''), 'err');
        toast('Estado de cuenta: ' + partes.join(' · '), descartadas.length ? '' : 'ok');
      };
      r.readAsText(file);
    },
    abrirRango() { this.edDesde = this.desde; this.edHasta = this.hasta; this.editarRango = !this.editarRango; },
    ajustarRango() {
      if (!this.edDesde || !this.edHasta || this.edHasta < this.edDesde) return toast('Indique un rango válido', 'err');
      this.editarRango = false; location.hash = '/bancos/conciliaciones/' + this.banco.id + '?desde=' + this.edDesde + '&hasta=' + this.edHasta;
    },
    guardar() {
      if (this.diferencia === null) return toast('Indique el saldo según el estado de cuenta del banco', 'err');
      const lista = conciliacionesMock();
      const estado = this.diferencia === 0 ? 'Conciliada' : 'En proceso';
      const reg = { banco_id: this.banco.id, banco: this.banco.nombre, moneda: this.mon, desde: this.desde, hasta: this.hasta, saldo_bancario: +this.saldo_bancario, saldo_total: this.saldoTotal, diferencia: this.diferencia, estado, fecha: hoy(), ...this.extra };
      const i = lista.findIndex(c => c.banco_id === reg.banco_id && c.desde === reg.desde && c.hasta === reg.hasta);
      if (i >= 0) lista[i] = { ...lista[i], ...reg }; else lista.push({ id: mock.nextId(lista, 'conciliaciones'), ...reg });
      mock.set('conciliaciones', lista);
      // los ajustes pasan a ser movimientos de la cuenta (con la fecha de cierre): se crean, se actualizan o se quitan según
      // los montos de ahora, sobre la lista guardada más reciente
      const pre = this.prefijo, s = this.esTarjeta ? -1 : 1, b = this.banco, hasta = this.hasta;
      const deseados = AJUSTES.filter(a => +this.extra[a.k] > 0).map(a => ({ ref: pre + a.k, monto: Math.round(s * a.signo * (+this.extra[a.k]) * 100) / 100,
        descripcion: 'Ajuste de conciliación · ' + a.nombre + ' (' + fecha(this.desde) + ' – ' + fecha(hasta) + ')' }));
      mock.actualizar('movimientos', l => {
        const lista = (Array.isArray(l) ? l : []).filter(m => !String(m.ref || '').startsWith(pre) || deseados.some(d => d.ref === m.ref));
        for (const d of deseados) {
          const x = lista.find(m => m.ref === d.ref);
          if (x) Object.assign(x, { monto: d.monto, descripcion: d.descripcion, fecha: hasta, conciliado: true });
          else lista.push({ id: mock.nextId(lista, 'movimientos'), banco_id: b.id, fecha: hasta, descripcion: d.descripcion, monto: d.monto, conciliado: true, ref: d.ref, ajuste: true });
        }
        return lista;
      }, []);
      toast(estado === 'Conciliada' ? 'Conciliación guardada: los saldos coinciden' : 'Conciliación guardada en proceso (diferencia ' + money(this.diferencia, this.mon) + ')', estado === 'Conciliada' ? 'ok' : '');
      location.hash = '/bancos/conciliaciones';
    },
  },
  template: `
  <div class="page">
    <PageHead :title="'Conciliación · ' + (banco ? banco.nombre : 'Banco')" sub="Marque los movimientos que aparecen en su estado de cuenta y compare el saldo." :crumbs="[{label:'Bancos',to:'/bancos'},{label:'Conciliaciones bancarias',to:'/bancos/conciliaciones'},{label: banco ? banco.nombre : ''}]" mock>
      <label class="btn ghost" style="cursor:pointer">⤒ Importar movimientos<input type="file" accept=".csv,.txt" style="display:none" @change="importar"></label>
      <button class="btn" :disabled="!banco" @click="guardar">Guardar conciliación</button>
    </PageHead>

    <div class="alert err" v-if="!banco">No se encontró la cuenta bancaria solicitada. <a href="#/bancos">Volver a Bancos y cajas</a></div>
    <template v-else>
      <div class="row" style="margin-bottom:14px">
        <span class="chip on">🏦 {{banco.nombre}} · {{mon}}</span>
        <span class="chip" @click="abrirRango" title="Cambiar rango">📅 {{fecha(desde)}} – {{fecha(hasta)}}</span>
        <span class="chip">{{enRango.length}} transacciones · {{conciliados}} conciliadas</span>
        <template v-if="editarRango"><input class="inp" type="date" v-model="edDesde"><input class="inp" type="date" v-model="edHasta"><button class="btn sm" @click="ajustarRango">Aplicar</button></template>
      </div>

      <div class="grid cols-2">
        <div class="card" style="margin:0">
          <h2>Saldos del período</h2>
          <div class="totals" style="align-items:stretch;margin:0">
            <div><span>Saldo anterior</span><b>{{money(saldoAnterior, mon)}}</b></div>
            <div><span>+ Entradas</span><b style="color:var(--ok)">{{money(entradas, mon)}}</b></div>
            <div><span>− Salidas</span><b style="color:var(--danger)">{{money(salidas, mon)}}</b></div>
            <div v-if="extra.gastos||extra.impuestos||extra.entradas"><span>± Ajustes bancarios</span><b>{{money(ajustes, mon)}}</b></div>
            <div class="total"><span>Saldo total</span><b>{{money(saldoTotal, mon)}}</b></div>
          </div>
          <div class="grid cols-2" style="margin-top:14px;align-items:end">
            <Field label="Saldo bancario" req help="Saldo final según el estado de cuenta"><input type="number" step="0.01" v-model.number="saldo_bancario" placeholder="0,00"></Field>
            <div><div class="small muted">Diferencia</div><div style="font-size:20px;font-weight:700" :style="{color: diferencia===null?'var(--muted)':diferencia===0?'var(--ok)':'var(--danger)'}">{{diferencia===null ? '—' : money(diferencia, mon)}}</div></div>
          </div>
          <div class="alert err" v-if="diferencia!==null && diferencia!==0" style="margin:12px 0 0">La diferencia debe ser cero para cerrar la conciliación. Revise movimientos faltantes o registre gastos, impuestos o entradas bancarias.</div>
          <div class="alert ok" v-if="diferencia===0" style="margin:12px 0 0">Los saldos coinciden. Puede guardar la conciliación.</div>
        </div>
        <div class="card" style="margin:0">
          <h2>Información adicional <small>movimientos del banco no registrados</small></h2>
          <div class="grid">
            <Field label="Gastos bancarios" help="Comisiones y cargos por servicios"><input type="number" step="0.01" v-model.number="extra.gastos"></Field>
            <Field label="Impuestos bancarios" help="Impuestos retenidos por el banco"><input type="number" step="0.01" v-model.number="extra.impuestos"></Field>
            <Field label="Entradas bancarias" help="Intereses ganados u otros abonos"><input type="number" step="0.01" v-model.number="extra.entradas"></Field>
          </div>
          <p class="small muted" style="margin:12px 0 0">Al guardar, estos montos se registran como movimientos de la cuenta con fecha {{fecha(hasta)}} (cambian su saldo; si vuelve a guardar, se actualizan). Para importar su estado de cuenta use un CSV con columnas <span class="mono">fecha,descripcion,monto</span>.</p>
        </div>
      </div>

      <div class="card pad0" style="margin-top:18px">
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th style="width:32px"><input type="checkbox" :checked="enRango.length>0 && conciliados===enRango.length" @change="toggleTodos" title="Conciliar todo"></th><th>Fecha</th><th>Descripción</th><th class="num">Entrada</th><th class="num">Salida</th><th>Estado</th></tr></thead>
          <tbody>
            <tr v-for="m in enRango" :key="m.id">
              <td><input type="checkbox" v-model="m.conciliado" @change="guardarMovs"></td>
              <td>{{fecha(m.fecha)}}</td>
              <td style="white-space:normal">{{m.descripcion}} <span v-if="m.importado" class="badge info">Importado</span></td>
              <td class="num" style="color:var(--ok)">{{m.monto>0 ? money(m.monto, mon) : ''}}</td>
              <td class="num" style="color:var(--danger)">{{-m.monto > 0 ? money(-m.monto, mon) : ''}}</td>
              <td><Badge :value="m.conciliado ? 'Conciliado' : 'No conciliado'"></Badge></td>
            </tr>
          </tbody>
        </table></div>
        <Empty v-if="!enRango.length" icon="🏦" title="Sin transacciones en el período" text="Importe los movimientos del estado de cuenta o cambie el rango de fechas."></Empty>
      </div>
    </template>
  </div>`,
};
