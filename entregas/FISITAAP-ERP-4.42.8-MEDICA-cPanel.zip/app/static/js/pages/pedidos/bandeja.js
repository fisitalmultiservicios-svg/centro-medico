// FISITAAP › Pedidos (3.47; dentro del módulo FISITAAP desde 3.57): bandeja de los pedidos que entran del catálogo público. Nuevo → Confirmar (entra
// a la caja como cuenta en espera y al monitor de preparación) o Cancelar con motivo; el estado «en preparación / listo /
// entregado» lo pone la caja o el monitor y aquí se refleja. Se refresca sola y suena cuando entra un pedido nuevo.
import { api, toast, money, fechaHora, hoy, abrirArchivo } from '../../api.js';
import { sesion } from '../../app.js';

const ESTADOS = [['', 'Todos'], ['pendiente_pago', 'Esperando pago'], ['nuevo', 'Nuevos'], ['confirmado', 'Confirmados'], ['en_preparacion', 'En preparación'], ['listo', 'Listos'], ['entregado', 'Entregados'], ['cancelado', 'Cancelados']];

export default {
  props: ['params'],
  data() { return { lista: [], estado: 'nuevo', q: '', desde: '', hasta: '', cargando: false, cancelar: null, detalle: null, sonido: true, ultimo: null, ESTADOS, negocio: null }; },
  computed: {
    filtrados() { const q = this.q.trim().toLowerCase(); return this.lista.filter(p => (!this.estado || p.estado === this.estado) && (!q || String(p.telefono || '').includes(q) || String(p.nombre || '').toLowerCase().includes(q) || String(p.numero) === q)); },
    nuevos() { return this.lista.filter(p => p.estado === 'nuevo').length; },
  },
  methods: {
    money, fechaHora,
    async cargar(silencioso) {
      if (!silencioso) this.cargando = true;
      try {
        const q = this.desde || this.hasta ? '?desde=' + (this.desde || '2000-01-01') + '&hasta=' + (this.hasta || hoy()) : '';
        const l = await api('/api/pedidos' + q);
        const maxId = Math.max(0, ...l.filter(p => p.estado === 'nuevo').map(p => p.id));
        if (this.ultimo !== null && maxId > this.ultimo && this.sonido) this.beep();
        this.ultimo = maxId; this.lista = l;
      } catch (e) { if (!silencioso) toast(e.message, 'err'); }
      this.cargando = false;
    },
    async confirmar(p) {
      try { const r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); Object.assign(p, r); toast('Pedido #' + p.numero + ' confirmado: ya está en la caja y en el monitor de preparación', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async entregar(p) { try { const r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'entregado' } }); Object.assign(p, r); toast('Pedido #' + p.numero + ' entregado', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async confirmarCancelar() {
      const c = this.cancelar; if (!(c.motivo || '').trim()) return toast('Escriba el motivo', 'err');
      try { const r = await api('/api/pedidos/' + c.p.id + '/estado', { method: 'PUT', body: { estado: 'cancelado', motivo: c.motivo.trim() } }); Object.assign(c.p, r); this.cancelar = null; toast('Pedido #' + c.p.numero + ' cancelado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    wa(p) { const n = this.negocio ? this.negocio.nombre_publico : ''; return 'https://wa.me/506' + p.telefono + '?text=' + encodeURIComponent('Hola ' + p.nombre + ', su pedido #' + p.numero + ' en ' + n + (p.estado === 'listo' ? ' está listo' + (p.tipo === 'domicilio' ? ' y va en camino' : ' para recoger') : p.estado === 'cancelado' ? ' fue cancelado: ' + (p.motivo || '') : ' fue confirmado') + '. Total ' + money(p.total) + '.'); },
    claseEstado(e) { return e === 'listo' || e === 'entregado' ? 'ok' : e === 'cancelado' ? 'danger' : e === 'nuevo' ? 'warn' : 'info'; },
    icono(p) { return p.tipo === 'domicilio' ? '🛵' : p.tipo === 'coordinado' ? '📦' : '🥡'; },
    // SINPE Móvil con comprobante (3.58): el negocio revisa el comprobante y marca «pago verificado» (o lo rechaza y el cliente paga al recibir)
    verComprobante(p) { abrirArchivo('/api/pedidos/' + p.id + '/sinpe/comprobante').catch(e => toast(e.message, 'err')); },
    async sinpe(p, ok) {
      const motivo = ok ? null : (prompt('¿Por qué se rechaza el comprobante? (el cliente lo ve)', 'No aparece el SINPE en la cuenta') || '').trim();
      if (!ok && !motivo) return;
      try { const r = await api('/api/pedidos/' + p.id + '/sinpe', { method: 'PUT', body: { verificado: ok, motivo } }); Object.assign(p, r); toast(ok ? 'Pago por SINPE verificado' + (p.cuenta_espera_id ? ': la caja ya lo ve pagado' : '') : 'Comprobante rechazado: el pedido queda por pagar al recibir', ok ? 'ok' : 'err'); }
      catch (e) { toast(e.message, 'err'); }
    },
    beep() { try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 660; g.gain.value = 0.2; o.start(); o.stop(ac.currentTime + 0.35); } catch {} },
  },
  async created() { const m = /[?&]q=([^&]*)/.exec(location.hash); if (m) { this.q = decodeURIComponent(m[1]); this.estado = ''; } await this.cargar(); try { this.negocio = await api('/api/pedidos/negocio'); } catch {} this._t = setInterval(() => this.cargar(true), 20000); },
  beforeUnmount() { clearInterval(this._t); },
  template: `
  <div class="page">
    <PageHead title="Pedidos" sub="Los pedidos que entran por su página. Confirme para mandarlos a la caja y al monitor de preparación; se cobran en la caja." :crumbs="[{label:'FISITAAP'},{label:'Pedidos'}]">
      <label class="row small" style="gap:4px;cursor:pointer"><input type="checkbox" v-model="sonido"> Sonido</label>
      <a class="btn ghost" href="#/fisitaap/pagina">Mi página</a><button class="btn sec" @click="cargar()" :disabled="cargando">Actualizar</button>
    </PageHead>
    <div class="alert warn" v-if="negocio && !negocio.activo" style="margin-bottom:12px">Su página no está publicada: <a href="#/fisitaap/pagina">publíquelo</a> para recibir pedidos.</div>
    <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end">
      <span class="seg"><button v-for="e in ESTADOS" :key="e[0]" :class="{on: estado===e[0]}" @click="estado=e[0]">{{e[1]}}<span v-if="e[0]==='nuevo' && nuevos" class="badge warn" style="margin-left:4px">{{nuevos}}</span></button></span>
      <Field label="Desde"><input type="date" v-model="desde"></Field><Field label="Hasta"><input type="date" v-model="hasta"></Field><button class="btn sm ghost" @click="cargar()">Buscar</button><span class="small muted">Sin fechas: los últimos 3 días. Se actualiza sola cada 20 s.</span>
    </div></div>
    <Empty v-if="!filtrados.length" icon="🌐" title="Sin pedidos" :text="estado==='nuevo' ? 'Cuando un cliente pida desde el catálogo aparece aquí y suena.' : 'No hay pedidos con ese estado en el período.'"></Empty>
    <div v-for="p in filtrados" :key="p.id" class="card" style="margin-bottom:10px" :style="p.estado==='nuevo' ? 'border-color:var(--warn)' : ''">
      <div class="row" style="justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:flex-start">
        <div><b style="font-size:16px">{{icono(p)}} Pedido #{{p.numero}} · {{p.nombre}}</b> <span class="badge" :class="claseEstado(p.estado)">{{p.estado_nombre}}</span> <span class="badge ok" v-if="p.pago_estado==='aprobado'">{{p.pago_medio==='sinpe' ? '📲 SINPE verificado' : '💳 Pagado en línea'}} {{money(p.pago_monto)}}</span><span class="badge warn" v-else-if="p.pago_estado==='sinpe_pendiente'">📲 SINPE por verificar{{p.sinpe && p.sinpe.comprobante ? '' : ' · sin comprobante aún'}}</span><span class="badge danger" v-else-if="p.pago_medio==='sinpe' && p.pago_estado==='rechazado'" :title="p.pago_detalle">SINPE rechazado · paga al recibir</span><span class="badge danger" v-else-if="p.pago_estado==='reembolso_pendiente'" title="Tilopay no aceptó el reembolso automático: hágalo desde su panel de Tilopay">Reembolso pendiente</span><span class="badge" v-else-if="p.pago_estado==='reembolsado'">Reembolsado</span><span class="badge warn" v-else-if="p.estado==='pendiente_pago'">{{p.pago_estado_nombre || 'Pago pendiente'}}</span>
          <div class="small muted">{{p.tipo_nombre}} · {{fechaHora(p.creado)}}{{p.hora_programada ? ' · para las ' + p.hora_programada : ''}} · tel. {{p.telefono}}<span v-if="p.correo"> · {{p.correo}}</span><span v-if="p.direccion"> · {{p.direccion}}</span></div>
          <div class="small" v-if="p.nota" style="color:var(--primary)">✎ {{p.nota}}</div><div class="small" v-if="p.motivo" style="color:var(--danger)">Motivo: {{p.motivo}}</div>
          <div class="small" v-if="p.entrega" style="margin-top:2px">🛵 Entrega: <span class="badge" :class="p.entrega.estado==='entregada' ? 'ok' : ['cancelada','incidencia'].includes(p.entrega.estado) ? 'danger' : ['pendiente','liberada'].includes(p.entrega.estado) ? 'warn' : 'info'">{{p.entrega.estado_nombre}}</span>{{p.entrega.motorizado ? ' · ' + p.entrega.motorizado : ''}}{{p.zona ? ' · zona ' + p.zona : ''}}<a href="#/entregas" style="margin-left:6px">despachar</a></div>
          <div class="small" style="margin-top:4px"><span v-for="(l,i) in p.lineas" :key="i">{{l.cantidad}} × {{l.detalle}}<i v-if="l.nota"> ({{l.nota}})</i><span v-if="i < p.lineas.length-1"> · </span></span></div>
        </div>
        <div style="text-align:right"><b style="font-size:18px">{{money(p.total)}}</b><div class="small muted" v-if="p.envio">incluye envío {{money(p.envio)}}</div>
          <div class="acts" style="justify-content:flex-end;margin-top:6px;flex-wrap:wrap">
            <button class="btn sm" v-if="p.estado==='nuevo'" @click="confirmar(p)">Confirmar</button>
            <template v-if="p.pago_medio==='sinpe' && p.pago_estado!=='aprobado' && !['entregado','cancelado'].includes(p.estado)"><button class="btn sm ghost" v-if="p.sinpe && p.sinpe.comprobante" @click="verComprobante(p)" :title="p.sinpe.referencia ? 'Ref. ' + p.sinpe.referencia : ''">Ver comprobante</button><button class="btn sm sec" @click="sinpe(p, true)" title="Ya vi el SINPE en la cuenta del negocio">Pago verificado</button><button class="btn sm ghost" v-if="p.pago_estado==='sinpe_pendiente'" @click="sinpe(p, false)">Rechazar pago</button></template>
            <a class="btn sm ghost" :href="wa(p)" target="_blank" rel="noopener" v-if="p.estado!=='nuevo'">WhatsApp</a>
            <a class="btn sm sec" href="#/pos/caja" v-if="p.cuenta_espera_id && !['entregado','cancelado'].includes(p.estado)" title="Cobrar desde la caja (Pedidos)">Cobrar en la caja</a>
            <button class="btn sm sec" v-if="['confirmado','en_preparacion','listo'].includes(p.estado) && p.tipo!=='domicilio'" @click="entregar(p)">Entregado</button>
            <button class="btn sm ghost" v-if="!['entregado','cancelado'].includes(p.estado)" @click="cancelar={p, motivo: ''}">Cancelar</button>
          </div></div>
      </div>
    </div>
    <Modal v-if="cancelar" :title="'Cancelar el pedido #' + cancelar.p.numero" @close="cancelar=null">
      <Field label="Motivo" req><input v-model="cancelar.motivo" maxlength="200" placeholder="Sin existencias, el cliente no respondió…" autofocus @keyup.enter="confirmarCancelar"></Field>
      <p class="small muted" v-if="cancelar.p.pago_estado==='aprobado' && cancelar.p.pago_medio==='sinpe'">Este pedido se pagó por SINPE Móvil ({{money(cancelar.p.pago_monto)}}): devuélvalo al cliente desde su banco.</p>
      <p class="small muted" v-else-if="cancelar.p.pago_estado==='aprobado'">Este pedido se pagó con tarjeta en línea ({{money(cancelar.p.pago_monto)}}): al cancelarlo se pide el reembolso a Tilopay.</p>
      <p class="small muted" style="margin:8px 0 0">Si ya estaba en la caja, la cuenta se retira (si tiene cobros, anule la venta desde la caja). Avísele al cliente por WhatsApp.</p>
      <template #foot><button class="btn ghost" @click="cancelar=null">Volver</button><button class="btn danger" @click="confirmarCancelar">Cancelar el pedido</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
