// Inventario — Ítems (backend real: /api/productos, /api/inventario/existencias y /api/inventario/bodegas)
import { api, toast, money, fmt, mock, CAT, opts, fmtCant, monedas } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';
import { store, sesion } from '../../app.js';
import { normCodigo } from './_etiquetas.js';   // 4.24: etiquetas con código de barras (el código del ítem es el que lee la caja)
import { DialogoRegistrarCodigos, DialogoGenerarCodigos, DialogoEtiquetas } from './_etiquetas-dialogos.js';

// precios por lista guardados con el NOMBRE de la lista (versiones anteriores) → id; se escribe de vuelta una sola vez (R282)
export function migrarListas(extra) {
  const listas = mock.get('listas_precios', []) || [];
  let cambio = false;
  for (const x of Object.values(extra || {})) {
    for (const l of (x && x.listas) || []) {
      if (l.lista_id === undefined && l.lista !== undefined) { const def = listas.find(d => d.nombre === l.lista); l.lista_id = def ? def.id : null; delete l.lista; cambio = true; }
    }
  }
  if (cambio) mock.set('items_extra', extra);
  return extra || {};
}
const LISTAS_BASE = [{ id: 1, nombre: 'General', principal: true, tipo: 'Valor', descripcion: 'Lista de precios base', activa: true }];
// Campos de ProductoIn que se envían al backend al crear/editar
// 9c (J5): acciones en bloque. Un ítem creado en la página web (en el programa, su id está fuera de rango_items, como lo calcula
// item-form.js) se guarda allá en el momento; si la web no respondió para uno, los demás ítems de la web de esa selección no se intentan.
export const FALLA_ITEM_WEB = 'No se pudo guardar: este ítem se creó en la página web';
export function itemDeLaWeb(id, info) { const e = info === undefined ? sesion.empresaInfo : info; const r = e && e.es_local ? +(e.rango_items || 0) : 0; return !!(r && (r < 0 || Math.floor(+id / 10000000) !== r)); }
export function esFallaItemWeb(e) { return String((e && e.message) || '').startsWith(FALLA_ITEM_WEB); }
// El aviso final: lo hecho y, si algo no se guardó, cuántos y el primer motivo («1 ítem desactivado. 1 no se guardó: …»)
export function avisoBloque(hecho, err, motivo) {
  if (!err) return hecho;
  const m = String(motivo || '').trim();
  return hecho + '. ' + (err === 1 ? '1 no se guardó' : err + ' no se guardaron') + (m ? ': ' + m : '.');
}
const CAMPOS = ['codigo', 'nombre', 'cabys', 'precio', 'unidad_medida', 'es_servicio', 'codigo_tarifa', 'tarifa', 'tipo', 'descripcion', 'categoria', 'costo', 'inventariable', 'venta_negativo', 'partida_arancelaria', 'activo'];


export default {
  props: ['params'],
  components: { DialogoRegistrarCodigos, DialogoGenerarCodigos, DialogoEtiquetas },
  data() {
    return {
      q: '', menu: false, modal: false, ver: null, guardando: false, lista: 1, estado: 'todos', lote: null,   // acciones en bloque (3.25)
      repetidos: null, soloRepetidos: false,   // 4.24: códigos que ya estaban repetidos antes de la regla (GET /api/productos/codigos/repetidos)
      registrar: null,   // 4.24: productos del cuadro «Registrar código» (uno, o varios de uno en uno)
      etq: null, generar: null,   // 4.24: productos de los cuadros «Etiquetas» y «Generar códigos de barras»
      existencias: [], bodegas: [],
      // Sin backend aún: precios por lista de precios (mock 'items_extra'[id].listas) y catálogo de listas (mock 'listas_precios')
      extra: migrarListas(mock.get('items_extra', {})), listas: ((l) => (l.some(x => x.principal) ? l : [...LISTAS_BASE, ...l]))(mock.get('listas_precios', LISTAS_BASE) || []),
      f: this.nuevo(), imagenNueva: null, cabysQ: '', cabysRes: [], buscandoCabys: false, cabysModal: false, cabysInfo: null, CAT, opts,
    };
  },
  computed: {
    electronica() { return sesion.electronica; },   // 4.21: sin facturación electrónica el CABYS no es obligatorio
    store() { return store; },
    monedas() { return monedas; },
    pct() { return CAT.tarifaPct[this.f.codigo_tarifa] ?? 0; },
    existPorProducto() { const m = {}; for (const e of this.existencias) m[e.producto_id] = e; return m; },
    nombreBodega() { const m = {}; for (const b of this.bodegas) m[b.id] = b.nombre; return m; },
    idsRepetidos() { const s = new Set(); for (const g of (this.repetidos && this.repetidos.grupos) || []) for (const p of g.productos || []) s.add(p.id); return s; },   // 4.24
    avisoRepetidos() { const n = (this.repetidos && this.repetidos.codigos) || 0; return n ? (n === 1 ? 'Hay 1 código repetido' : 'Hay ' + n + ' códigos repetidos') + ': la caja toma el primero que encuentra' : ''; },
    rows() {
      if (this.soloRepetidos && this.avisoRepetidos) return this.filas.filter(r => this.idsRepetidos.has(r.id)).sort((a, b) => normCodigo(a.codigo).localeCompare(normCodigo(b.codigo)) || a.nombre.localeCompare(b.nombre, 'es'));   // juntos los que comparten código
      return this.filas;
    },
    filas() {
      return store.productos.map(p => {
        const ex = this.existPorProducto[p.id];
        const detalle = ex ? Object.entries(ex.bodegas || {}).filter(([, v]) => v.cantidad).map(([bid, v]) => `${this.nombreBodega[bid] || 'Bodega ' + bid}: ${fmtCant(v.cantidad)}`).join(' · ') : '';
        return { ...p, existencias: ex ? ex.cantidad : 0, detalle, estado: p.activo === false ? 'Inactivo' : 'Activo', precio_lista: this.precioLista(p), precio_moneda: this.esListaPrincipal() ? (p.moneda || monedas.principal().codigo) : this.monedaLista(), imagen: p.imagen_nombre ? `/api/productos/${p.id}/imagen` : '' };
      }).filter(r => this.estado === 'todos' || (this.estado === 'activos' ? r.estado === 'Activo' : r.estado === 'Inactivo'));
    },
    columns() {
      return [
        { key: 'nombre', label: 'Nombre', link: r => location.hash = '/inventario/items/' + r.id },
        { key: 'codigo', label: 'Código', mono: true, fmt: v => v || '—', busca: r => r.codigos_alternos || '' },   // 4.24: la búsqueda también encuentra por un código alterno
        { key: 'es_venta', label: 'Uso', fmt: v => v === false ? 'Insumo' : 'Se vende' },   // 3.18
        { key: 'precio_lista', label: 'Precio', num: true, fmt: (v, r) => money(v, r.precio_moneda) },   // en la moneda de la lista (R282) o del ítem (3.25)
        { key: 'existencias', label: 'Existencias', num: true, fmt: (v, r) => this.noInventariable(r) ? '—' : fmtCant(v) + (r.detalle && r.detalle.includes('·') ? ' (' + r.detalle + ')' : '') },
        { key: 'descripcion', label: 'Descripción', fmt: v => v || '—' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    fmtCant,
    money, fmt,
    nuevo() { return { tipo: 'Producto', nombre: '', bodega_id: null, unidad_medida: 'Unid', cabys: '', cantidad: 0, costo: 0, precio: 0, total: 0, codigo_tarifa: '08' }; },
    noInventariable(p) { return p.es_servicio || p.inventariable === false; },
    bodyDe(p) { const b = {}; for (const k of CAMPOS) b[k] = p[k]; return b; },
    async cargar() {
      try {
        [this.existencias, this.bodegas] = await Promise.all([api('/api/inventario/existencias'), api('/api/inventario/bodegas')]);
        if (!this.f.bodega_id) this.f.bodega_id = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null;
      } catch (e) { toast(e.message, 'err'); }
      this.cargarRepetidos();
    },
    async cargarRepetidos() { try { this.repetidos = await api('/api/productos/codigos/repetidos'); } catch { this.repetidos = null; } if (!this.avisoRepetidos) this.soloRepetidos = false; },   // 4.24
    // Los precios por lista se guardan por id de lista (antes por nombre: renombrar o borrar una lista los dejaba huérfanos) (R282)
    precioLista(p) {
      const def = this.listas.find(x => x.id === this.lista);
      if (!def || def.principal) return p.precio;
      const l = (this.extra[p.id]?.listas || []).find(x => x.lista_id === def.id);
      if (!l) return p.precio;
      return def.tipo === 'Porcentaje' ? p.precio * (1 - (+l.valor || 0) / 100) : +l.valor || p.precio;
    },
    monedaLista() { const def = this.listas.find(x => x.id === this.lista); return (def && !def.principal && def.moneda) || monedas.principal().codigo; },   // la lista General va en la moneda principal (3.25)
    esListaPrincipal() { const def = this.listas.find(x => x.id === this.lista); return !def || !!def.principal; },
    // ---- acciones en bloque sobre los seleccionados (3.25) ----
    abrirLote(rows, tipo) { this.lote = { rows, tipo, moneda: 'USD', modo: 'etiqueta', tc: +monedas.tc('USD') || 0, umbral: null, pct: 0, categoria: '', codigo_tarifa: '08', guardando: false }; },
    async confirmarLote() {
      const l = this.lote, body = { ids: l.rows.map(r => r.id) };
      if (l.tipo === 'moneda') {
        if (l.modo === 'etiqueta') body.moneda = l.moneda; else { body.convertir_a = l.moneda; body.tipo_cambio = +l.tc || 0; if (!(body.tipo_cambio > 0)) return toast('Indique el tipo de cambio', 'err'); }
        if (l.umbral !== null && l.umbral !== '' && +l.umbral > 0) body.solo_precio_menor_que = +l.umbral;
      } else if (l.tipo === 'precio') { if (!(+l.pct > -100)) return toast('Indique el porcentaje', 'err'); body.precio_factor = 1 + (+l.pct || 0) / 100; }
      else if (l.tipo === 'categoria') body.categoria = l.categoria || '';
      else if (l.tipo === 'tarifa') { body.codigo_tarifa = l.codigo_tarifa; body.tarifa = CAT.tarifaPct[l.codigo_tarifa] ?? 0; }
      l.guardando = true;
      try { const r = await api('/api/productos/lote/cambios', { method: 'POST', body }); toast(r.cambiados + ' ítem(s) actualizados' + (r.omitidos ? ' · ' + r.omitidos + ' sin cambio' : '') + (r.aviso ? ' · ' + r.aviso : ''), r.aviso ? 'err' : 'ok'); this.lote = null; await store.cargar(); this.cargar(); }
      catch (e) { toast(e.message, 'err'); l.guardando = false; }
    },
    categoriasExistentes() { return [...new Set(store.productos.map(p => (p.categoria || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es')); },
    recalcTotal() { this.f.total = +((+this.f.precio || 0) * (1 + this.pct / 100)).toFixed(2); },
    recalcBase() { this.f.precio = +((+this.f.total || 0) / (1 + this.pct / 100)).toFixed(5); },   // (R281)
    async buscarCabys() {
      if (!this.cabysQ.trim()) return;
      this.buscandoCabys = true;
      try { this.cabysRes = await api('/api/hacienda/cabys?q=' + encodeURIComponent(this.cabysQ)); if (!this.cabysRes.length) toast('Sin resultados en el catálogo CABYS'); } catch (e) { toast(e.message, 'err'); }
      this.buscandoCabys = false;
    },
    elegirCabys(c) { this.f.cabys = c.codigo; this.cabysInfo = { ok: true, texto: `${c.descripcion} · IVA ${c.impuesto} %` }; const t = Number(c.impuesto) === 0 ? ['10'] : Object.entries(CAT.tarifaPct).find(([k, v]) => v === Number(c.impuesto) && k !== '10' && k !== '11' && k !== '01'); if (t) { this.f.codigo_tarifa = t[0]; this.recalcTotal(); } else toast('El catálogo no indica la tarifa de IVA de este código: elija la tarifa a mano', 'err'); this.cabysModal = false; },
    // Permite escribir el código directamente: al completar 13 dígitos se valida contra el catálogo oficial
    async validarCabys() {
      const c = (this.f.cabys || '').replace(/\D/g, ''); this.f.cabys = c;
      if (c.length < 13) { this.cabysInfo = c.length ? { ok: null, texto: `${c.length}/13 dígitos` } : null; return; }
      try { const d = await api('/api/cabys/' + c); this.elegirCabys(d); }
      catch { this.cabysInfo = { ok: false, texto: 'Este código no existe en el catálogo oficial CABYS' }; }
    },
    imagen(ev) { const file = ev.target.files?.[0]; if (!file) return; if (file.size > 400000) { ev.target.value = ''; return toast('La imagen debe pesar menos de 400 KB', 'err'); } this.imagenNueva = file; },
    async crear() {
      const f = this.f;
      if (!f.nombre) return toast('El nombre es obligatorio', 'err');
      if (f.tipo === 'Combo' || f.tipo === 'Surtido') { this.modal = false; location.hash = '/inventario/items/nuevo?tipo=' + f.tipo + '&nombre=' + encodeURIComponent(f.nombre) + '&cabys=' + (f.cabys || ''); return; }
      if (!f.cabys && sesion.electronica) return toast('Indique el código CABYS', 'err');   /* 4.21: opcional sin facturación electrónica, igual que en la ficha del ítem (3.93) */
      this.guardando = true;
      try {
        const esServicio = f.tipo === 'Servicio';
        const body = { codigo: null, nombre: f.nombre, cabys: f.cabys, precio: +f.precio || 0, unidad_medida: f.unidad_medida, es_servicio: esServicio, codigo_tarifa: f.codigo_tarifa, tarifa: this.pct,
          tipo: f.tipo, costo: esServicio ? 0 : +f.costo || 0, inventariable: !esServicio, venta_negativo: false, activo: true,
          cantidad_inicial: esServicio ? null : (+f.cantidad || null), bodega_id: esServicio ? null : f.bodega_id };
        const p = await api('/api/productos', { method: 'POST', body });
        if (this.imagenNueva) {
          const fd = new FormData(); fd.append('archivo', this.imagenNueva, this.imagenNueva.name);
          try { await api(`/api/productos/${p.id}/imagen`, { method: 'POST', body: fd }); } catch (e) { toast('Ítem creado, pero la imagen no se pudo subir: ' + e.message, 'err'); }
        }
        store.poner('productos', p); await this.cargar();      // solo el ítem nuevo (R263)
        toast(f.tipo + ' creado', 'ok'); this.modal = false; this.f = this.nuevo(); this.imagenNueva = null; this.cabysInfo = null;
        this.f.bodega_id = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null;
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async activar(r) {
      const activo = r.estado !== 'Activo';
      try { const p = await api('/api/productos/' + r.id, { method: 'PUT', body: { ...this.bodyDe(r), activo } }); store.poner('productos', p && p.id ? p : { id: r.id, activo }); toast(activo ? 'Ítem activado' : 'Ítem desactivado', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminar(r) {
      if (!confirm('¿Eliminar "' + r.nombre + '"?' + (this.noInventariable(r) ? '' : ' Si tiene existencias o movimientos, se desactiva en lugar de borrarse (conserva el historial).'))) return;   // (R114)
      try {
        const res = await api('/api/productos/' + r.id, { method: 'DELETE' });
        if (!res?.desactivado) this.extra = mock.actualizar('items_extra', x => { delete x[r.id]; }, {});
        store.quitar('productos', r.id, !!res?.desactivado); if (res?.desactivado) store.poner('productos', { id: r.id, codigo: null, codigos_alternos: null });   // 4.24: al desactivarse por «Eliminar» su código queda libre
        await this.cargar();
        toast(res?.desactivado ? 'El ítem se desactivó porque ya fue facturado' : 'Ítem eliminado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // Acciones masivas sobre la selección
    async eliminarVarios(rows) {
      let ok = 0, desact = 0, err = 0, motivo = '', sinWeb = false;   // 9c (J5): el primer motivo va en el aviso; sin la web, los demás de la web no se intentan
      const borrados = [];
      for (const r of rows) {
        if (sinWeb && itemDeLaWeb(r.id)) { err++; continue; }
        try { const res = await api('/api/productos/' + r.id, { method: 'DELETE' }); if (res?.desactivado) desact++; else { ok++; borrados.push(r.id); } store.quitar('productos', r.id, !!res?.desactivado); if (res?.desactivado) store.poner('productos', { id: r.id, codigo: null, codigos_alternos: null }); }
        catch (e) { err++; if (!motivo) motivo = (e && e.message) || ''; if (itemDeLaWeb(r.id) && esFallaItemWeb(e)) sinWeb = true; }
      }
      this.extra = mock.actualizar('items_extra', x => { for (const id of borrados) delete x[id]; }, {});
      toast(avisoBloque((ok === 1 ? '1 ítem eliminado' : ok + ' ítems eliminados') + (desact ? ', ' + desact + (desact === 1 ? ' desactivado (ya facturado)' : ' desactivados (ya facturados)') : ''), err, motivo), err ? 'err' : 'ok');
      await this.cargar();
    },
    async activarVarios(rows, activo) {
      let ok = 0, err = 0, motivo = '', sinWeb = false;   // 9c (J5): igual que eliminarVarios
      for (const r of rows) {
        if (sinWeb && itemDeLaWeb(r.id)) { err++; continue; }
        try { const p = await api('/api/productos/' + r.id, { method: 'PUT', body: { ...this.bodyDe(r), activo } }); store.poner('productos', p && p.id ? p : { id: r.id, activo }); ok++; }
        catch (e) { err++; if (!motivo) motivo = (e && e.message) || ''; if (itemDeLaWeb(r.id) && esFallaItemWeb(e)) sinWeb = true; }
      }
      toast(avisoBloque(ok === 1 ? (activo ? '1 ítem activado' : '1 ítem desactivado') : ok + (activo ? ' ítems activados' : ' ítems desactivados'), err, motivo), err ? 'err' : 'ok');
    },
    // 4.24: lo que muestra la lista con sus filtros y su búsqueda (la tabla hace la búsqueda)
    visibles() { const t = this.$refs.tabla; return (t && t.filtered ? t.filtered : this.rows).filter(r => r.estado !== 'Inactivo'); },
    // «Registrar código»: leer con el lector el código que el producto ya trae. De la fila (uno), de los seleccionados o de los que no tienen código
    abrirRegistrar(rows) { if (!rows.length) return toast('No hay ítems para registrarles el código', 'err'); this.registrar = rows.slice(); },
    registrarSinCodigo() { const l = this.visibles().filter(r => !String(r.codigo || '').trim()); if (!l.length) return toast('Todos los ítems de la lista ya tienen código', 'ok'); this.abrirRegistrar(l); },
    cerrarRegistrar() { this.registrar = null; this.cargarRepetidos(); },
    // «Etiquetas»: el cuadro pide cuántas copias de cada producto, el formato, la medida y la impresora. De la selección van los elegidos; de «Más acciones», lo que muestra la lista
    abrirEtiquetas(rows) { if (!rows.length) return toast('No hay ítems en la lista', 'err'); if (rows.length > 3000) return toast('Son ' + rows.length + ' ítems: filtre la lista o seleccione hasta 3.000 para imprimir sus etiquetas', 'err'); this.etq = rows.slice(); },
    etiquetas() { this.abrirEtiquetas(this.visibles()); },
    // «Generar códigos de barras»: solo a los que no tienen o a todos (reemplaza; el anterior queda como código alterno)
    abrirGenerar(rows) { if (!rows.length) return toast('No hay ítems en la lista', 'err'); this.generar = rows.slice(); },
    cerrarCodigos() { this.etq = null; this.generar = null; this.cargarRepetidos(); },
    bulk() {
      return [
        { label: '✔ Activar', kind: 'sec', handler: rows => this.activarVarios(rows, true) },
        { label: '⏻ Desactivar', kind: 'sec', handler: rows => this.activarVarios(rows, false) },
        { label: '$ Moneda del precio', kind: 'sec', handler: rows => this.abrirLote(rows, 'moneda') },
        { label: '% Ajustar precios', kind: 'sec', handler: rows => this.abrirLote(rows, 'precio') },
        { label: '🏷 Categoría', kind: 'sec', handler: rows => this.abrirLote(rows, 'categoria') },
        { label: 'IVA', kind: 'sec', handler: rows => this.abrirLote(rows, 'tarifa') },
        { label: '🖨 Etiquetas', kind: 'sec', handler: rows => this.abrirEtiquetas(rows) },   // 4.24: código de barras
        { label: '▥ Generar códigos de barras', kind: 'sec', handler: rows => this.abrirGenerar(rows) },
        { label: 'Registrar códigos con el lector', kind: 'sec', handler: rows => this.abrirRegistrar(rows) },
      ];
    },
    exportar() { exportarFilas('items', ['Nombre', 'Código', 'CABYS', 'Precio', 'Moneda', 'Unidad', 'Tipo', 'Tarifa', 'Costo', 'Existencias', 'Detalle por bodega', 'Estado'], this.rows.map(r => [r.nombre, r.codigo || '', r.cabys, r.precio, r.moneda || monedas.principal().codigo, r.unidad_medida, r.tipo, r.codigo_tarifa, r.costo, this.noInventariable(r) ? '' : r.existencias, r.detalle, r.estado]), { titulo: 'Ítems', num: [3, 8, 9] }); },
    actualizar() { store.cargar(); this.cargar(); },
  },
  created() { if (store.fallos?.productos) store.cargar(); this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Ítems" sub="Todo lo que vende y lo que compra para producir: productos, servicios e insumos. Administre sus precios y existencias.">
      <div style="position:relative"><button class="btn ghost" @click="menu=!menu">Más acciones ▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:230px;padding:6px" @click="menu=false">
          <a class="item" v-if="puede('catalogos')" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/gestion">Importar listado</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar">Exportar listado</a>
          <a class="item" v-if="puede('catalogos')" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/gestion">Historial de importaciones</a>
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit;border-top:1px solid var(--line)" href="#/inventario/bodegas">⚙ Bodegas</a>
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/categorias">⚙ Categorías</a>
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/listas-precios">⚙ Listas de precios</a>
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/atributos">⚙ Atributos</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="actualizar">Actualizar</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer;border-top:1px solid var(--line)" @click="etiquetas" title="Etiquetas con el nombre y el código de barras de los ítems que muestra la lista (con sus filtros y su búsqueda): elija cuántas copias de cada uno, la medida y la impresora">Etiquetas con código de barras</a>
          <a class="item" v-if="puede('catalogos')" style="display:block;padding:8px 10px;cursor:pointer" @click="abrirGenerar(visibles())" title="Pone un código de barras propio a los ítems que muestra la lista: solo a los que no tienen, o a todos">Generar códigos de barras</a>
          <a class="item" v-if="puede('catalogos')" style="display:block;padding:8px 10px;cursor:pointer" @click="registrarSinCodigo" title="Muestra uno por uno los ítems de la lista que no tienen código, para leerles con el lector el código de barras que ya traen de fábrica">Registrar códigos con el lector</a>
        </div></div>
      <button class="btn" v-if="puede('catalogos')" @click="f=nuevo();f.bodega_id=(bodegas.find(b=>b.principal)||bodegas[0])?.id||null;imagenNueva=null;cabysInfo=null;modal=true">+ Nuevo producto</button>
    </PageHead>
    <div class="card pad0">
      <div class="alert warn" v-if="avisoRepetidos" style="margin:12px 12px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span>{{avisoRepetidos}}. Cambie el código de los que sobran: desde hoy un código no puede quedar en dos ítems.</span><button class="btn sm sec" @click="soloRepetidos=!soloRepetidos">{{soloRepetidos ? 'Ver todos los ítems' : 'Ver esos ítems'}}</button></div>
      <div class="toolbar" style="padding:12px 12px 0">
        <label class="row small muted" style="gap:6px">Lista de precios <select class="inp" v-model.number="lista"><option v-for="l in listas" :value="l.id">{{l.nombre}}{{l.moneda && l.moneda !== 'CRC' ? ' (' + l.moneda + ')' : ''}}</option></select></label>
        <input class="search" placeholder="Buscar por nombre o código" v-model="q">
        <span class="chip" :class="{on:estado==='activos'}" @click="estado=estado==='activos'?'todos':'activos'">Estado: Activos</span>
        <span class="chip" :class="{on:estado==='inactivos'}" @click="estado=estado==='inactivos'?'todos':'inactivos'">Estado: Inactivos</span>
        <button class="btn ghost sm" v-if="estado!=='todos'" @click="estado='todos'">Remover filtros</button>
      </div>
      <DataTable ref="tabla" :rows="rows" :columns="columns" :search="q" :selectable="puede('catalogos')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado ítems" empty-text="Crea productos o servicios para usarlos en tus facturas.">
        <template #actions="{row}">
          <button class="btn icon" @click.stop="ver=row" title="Ver">👁</button>
          <a class="btn icon" v-if="puede('catalogos')" :href="'#/inventario/items/'+row.id" title="Editar">✎</a>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="abrirRegistrar([row])" title="Registrar código: leer con el lector el código de barras que el producto ya trae">▥</button>
          <a class="btn icon" v-if="puede('catalogos')" :href="'#/inventario/items/nuevo?duplicar='+row.id" @click.stop title="Duplicar: nuevo ítem con los mismos precios, impuestos y opciones">⧉</a>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="activar(row)" :title="row.estado==='Activo'?'Desactivar':'Activar'">{{row.estado==='Activo'?'⏻':'✔'}}</button>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><button class="btn" v-if="puede('catalogos')" @click="modal=true">+ Nuevo producto</button></template>
      </DataTable>
    </div>

    <Modal v-if="modal" title="Nuevo ítem — formulario básico" lg @close="modal=false">
      <Field label="Tipo de ítem" req help="No se puede cambiar después de crear el ítem"><div class="seg"><button v-for="t in ['Producto','Servicio','Combo','Surtido']" :key="t" :class="{on:f.tipo===t}" @click="f.tipo=t">{{t}}</button></div></Field>
      <div class="grid" style="margin-top:14px">
        <Field label="Nombre" req><input v-model="f.nombre"></Field>
        <Field label="Bodega" req v-if="f.tipo!=='Servicio'" help="Donde se registra la cantidad inicial"><Buscador v-model="f.bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        <Field label="Unidad de medida" req><select v-model="f.unidad_medida"><option v-for="u in CAT.unidades" :key="u" :value="u">{{u}}{{CAT.unidadesNombre[u] ? ' · ' + CAT.unidadesNombre[u] : ''}}</option></select></Field>
        <Field label="Código de producto o servicio (CABYS)" :req="electronica && (f.tipo==='Producto'||f.tipo==='Servicio')"><div class="row" style="gap:6px"><input class="mono" v-model="f.cabys" maxlength="13" placeholder="Escriba los 13 dígitos" @input="validarCabys" style="flex:1"><button class="btn sec sm" @click="cabysModal=true">Buscar por descripción</button></div>
          <span class="help" v-if="cabysInfo" :style="{color: cabysInfo.ok===true?'var(--ok)':cabysInfo.ok===false?'var(--danger)':''}">{{cabysInfo.texto}}</span></Field>
        <template v-if="f.tipo==='Producto'">
          <Field label="Cantidad inicial" req><input type="number" min="0" v-model.number="f.cantidad"></Field>
          <Field label="Costo por unidad" req><input type="number" min="0" step="0.01" v-model.number="f.costo"></Field>
        </template>
        <template v-if="f.tipo!=='Surtido'">
          <Field label="Precio base" req><input type="number" min="0" step="0.01" v-model.number="f.precio" @input="recalcTotal"></Field>
          <Field label="Impuesto"><select v-model="f.codigo_tarifa" @change="recalcTotal"><option v-for="o in CAT.tarifaIvaLista" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
          <Field label="Precio total" req><input type="number" min="0" step="0.01" v-model.number="f.total" @input="recalcBase"></Field>
        </template>
        <Field label="Imagen" help="PNG, JPG o WEBP de hasta 400 KB" v-if="f.tipo==='Producto'||f.tipo==='Servicio'"><input type="file" accept="image/png,image/jpeg,image/webp" @change="imagen"><span class="small muted" v-if="imagenNueva">{{imagenNueva.name}}</span></Field>
      </div>
      <p class="small muted" v-if="f.tipo==='Combo'||f.tipo==='Surtido'" style="margin-top:12px">Los {{f.tipo.toLowerCase()}}s se completan en el formulario avanzado, donde se definen los productos que lo componen.</p>
      <template #foot>
        <a class="btn ghost" href="#/inventario/items/nuevo" @click="modal=false">Ir al formulario avanzado</a>
        <button class="btn" @click="crear" :disabled="guardando">{{guardando?'Guardando…':(f.tipo==='Combo'?'Completar combo':f.tipo==='Surtido'?'Completar surtido':'Guardar')}}</button>
      </template>
    </Modal>

    <DialogoRegistrarCodigos v-if="registrar" :productos="registrar" @close="cerrarRegistrar"></DialogoRegistrarCodigos>
    <DialogoEtiquetas v-if="etq" :productos="etq" @close="cerrarCodigos"></DialogoEtiquetas>
    <DialogoGenerarCodigos v-if="generar" :productos="generar" @close="cerrarCodigos" @hecho="cargarRepetidos"></DialogoGenerarCodigos>

    <Modal v-if="cabysModal" title="Buscar código CABYS" lg @close="cabysModal=false">
      <div class="toolbar"><input class="search" v-model="cabysQ" placeholder="Describa el producto o servicio" @keyup.enter="buscarCabys" style="flex:1"><button class="btn" @click="buscarCabys" :disabled="buscandoCabys">{{buscandoCabys?'Buscando…':'Buscar'}}</button></div>
      <table class="tbl" v-if="cabysRes.length"><thead><tr><th>Código</th><th>Descripción</th><th class="num">IVA</th><th></th></tr></thead>
        <tbody><tr v-for="c in cabysRes" :key="c.codigo"><td class="mono">{{c.codigo}}</td><td style="white-space:normal">{{c.descripcion}}</td><td class="num">{{c.impuesto}} %</td><td><button class="btn sm sec" @click="elegirCabys(c)">Elegir</button></td></tr></tbody></table>
      <p class="muted small" v-else>Escriba una descripción y presione Buscar. Los resultados provienen del catálogo oficial de Hacienda.</p>
    </Modal>

    <Modal v-if="lote" :title="(lote.tipo==='moneda' ? 'Moneda del precio' : lote.tipo==='precio' ? 'Ajustar precios' : lote.tipo==='categoria' ? 'Cambiar categoría' : 'Cambiar IVA') + ' · ' + lote.rows.length + ' ítem(s)'" @close="lote=null">
      <template v-if="lote.tipo==='moneda'">
        <div class="seg" style="margin-bottom:10px"><button :class="{on: lote.modo==='etiqueta'}" @click="lote.modo='etiqueta'">Solo cambiar la moneda</button><button :class="{on: lote.modo==='convertir'}" @click="lote.modo='convertir'">Convertir el precio al tipo de cambio</button></div>
        <p class="small muted" style="margin:0 0 8px" v-if="lote.modo==='etiqueta'">El número del precio no cambia: un ítem a 92,69 pasa a ser $92,69. Úselo cuando los precios ya estaban en esa moneda (por ejemplo, importados de otro sistema).</p>
        <p class="small muted" style="margin:0 0 8px" v-else>El precio se convierte con el tipo de cambio: un ítem a ₡50.000 pasa a $98,04 con tipo de cambio 510. Los que ya están en esa moneda no se tocan.</p>
        <div class="grid cols-2">
          <Field label="Moneda nueva"><select v-model="lote.moneda"><option v-for="o in monedas.opciones()" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
          <Field label="Tipo de cambio (colones por dólar)" v-if="lote.modo==='convertir'"><input type="number" min="0" step="0.01" v-model.number="lote.tc"></Field>
          <Field label="Solo los seleccionados con precio menor que" help="Vacío = todos los seleccionados. Sirve para separar los precios en dólares (bajos) de los que ya están en colones" style="grid-column:1/-1"><input type="number" min="0" step="1" v-model.number="lote.umbral" placeholder="Ej.: 1000"></Field>
        </div>
      </template>
      <template v-else-if="lote.tipo==='precio'"><Field label="Porcentaje" help="Positivo sube, negativo baja: 10 = +10 %, -5 = −5 %. Se aplica al precio base de cada ítem"><input type="number" step="0.1" v-model.number="lote.pct"></Field></template>
      <template v-else-if="lote.tipo==='categoria'"><Field label="Categoría" help="Vacío = sin categoría"><input v-model="lote.categoria" maxlength="60" list="lote-cats"><datalist id="lote-cats"><option v-for="x in categoriasExistentes()" :key="x" :value="x"></option></datalist></Field></template>
      <template v-else><Field label="IVA"><select v-model="lote.codigo_tarifa"><option v-for="o in CAT.tarifaIvaLista" :key="o.value" :value="o.value">{{o.label}}</option></select></Field></template>
      <template #foot><button class="btn ghost" @click="lote=null">Cancelar</button><button class="btn" @click="confirmarLote" :disabled="lote.guardando">{{lote.guardando ? 'Aplicando…' : 'Aplicar a ' + lote.rows.length + ' ítem(s)'}}</button></template>
    </Modal>
    <Modal v-if="ver" :title="ver.nombre" @close="ver=null">
      <div style="text-align:center;margin-bottom:12px" v-if="ver.imagen"><img :src="ver.imagen" style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px"></div>
      <div class="grid">
        <div><div class="small muted">Tipo</div><b>{{ver.tipo}}</b></div><div><div class="small muted">Código</div><b class="mono">{{ver.codigo||'—'}}</b></div>
        <div><div class="small muted">CABYS</div><b class="mono">{{ver.cabys}}</b></div><div><div class="small muted">Unidad</div><b>{{ver.unidad_medida}}</b></div>
        <div><div class="small muted">Precio base</div><b>{{money(ver.precio)}}</b></div><div><div class="small muted">Impuesto</div><b>{{CAT.tarifaIva[ver.codigo_tarifa]}}</b></div>
        <div><div class="small muted">Precio total</div><b>{{money(ver.precio*(1+ver.tarifa/100))}}</b></div><div><div class="small muted">Costo</div><b>{{money(ver.costo)}}</b></div>
        <div><div class="small muted">Existencias</div><b>{{noInventariable(ver)?'—':fmtCant(ver.existencias)}}</b><div class="small muted" v-if="ver.detalle">{{ver.detalle}}</div></div>
        <div><div class="small muted">Estado</div><Badge :value="ver.estado"></Badge></div>
        <div style="grid-column:1/-1" v-if="ver.descripcion"><div class="small muted">Descripción</div>{{ver.descripcion}}</div>
      </div>
      <template #foot><a class="btn sec" :href="'#/inventario/items/'+ver.id">Editar</a><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
};
