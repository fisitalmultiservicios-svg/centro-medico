// Inventario — Atributos: variantes y campos adicionales (registros 'variantes' y 'campos_adicionales' del servidor; los ejemplos solo en la demo)
import { mock, toast } from '../../api.js';

const VARIANTES = [
  { id: 1, nombre: 'Color', atributos: ['Rojo', 'Azul', 'Negro', 'Blanco'] },
  { id: 2, nombre: 'Talla', atributos: ['S', 'M', 'L', 'XL'] },
  { id: 3, nombre: 'Material', atributos: ['Algodón', 'Poliéster'] },
];
const CAMPOS = [
  { id: 1, nombre: 'Garantía (meses)', tipo: 'Número', valor_defecto: '12', descripcion: 'Meses de garantía del fabricante', requerido: false, imprimir: true },
  { id: 2, nombre: 'Marca', tipo: 'Texto', valor_defecto: '', descripcion: 'Marca comercial del producto', requerido: true, imprimir: true },
  { id: 3, nombre: 'Fecha de vencimiento', tipo: 'Fecha', valor_defecto: '', descripcion: 'Para productos perecederos', requerido: false, imprimir: false },
  { id: 4, nombre: 'Origen', tipo: 'Lista', valor_defecto: 'Nacional', opciones: ['Nacional', 'Importado'], descripcion: 'Procedencia del producto', requerido: false, imprimir: false },
];

export default {
  props: ['params'],
  data() { return { tab: this.params.tab || 'hub', variantes: mock.ejemplos('variantes', VARIANTES, 'nombre').map(v => ({ ...v, atributos: Array.isArray(v.atributos) ? v.atributos : String(v.atributos || v.valores || '').split(',').map(s => s.trim()).filter(Boolean) })), campos: mock.ejemplos('campos_adicionales', CAMPOS, 'nombre').map(c => ({ ...c, valor_defecto: c.valor_defecto ?? c.defecto ?? '', opciones: Array.isArray(c.opciones) ? c.opciones : String(c.opciones || '').split(',').map(s => s.trim()).filter(Boolean) })), q: '', fv: null, fc: null, nuevoAtributo: '' }; },
  computed: {
    colVariantes() { return [{ key: 'nombre', label: 'Nombre' }, { key: 'atributos', label: 'Atributos', fmt: v => (v || []).join(', ') || '—' }, { key: 'atributos', label: 'Cantidad', num: true, fmt: v => (v || []).length }]; },
    colCampos() {
      return [
        { key: 'nombre', label: 'Nombre' }, { key: 'tipo', label: 'Tipo de campo' },
        { key: 'valor_defecto', label: 'Valor por defecto', fmt: v => v || '—' }, { key: 'descripcion', label: 'Descripción', fmt: v => v || '—' },
        { key: 'requerido', label: 'Requerido', fmt: v => v ? 'Sí' : 'No' }, { key: 'imprimir', label: 'Imprimir en factura', fmt: v => v ? 'Sí' : 'No' },
      ];
    },
  },
  methods: {
    nuevaVariante() { this.fv = { id: null, nombre: '', atributos: [] }; this.nuevoAtributo = ''; },
    editarVariante(r) { this.fv = { ...r, atributos: [...(r.atributos || [])] }; this.nuevoAtributo = ''; },
    agregarAtributo() { const a = this.nuevoAtributo.trim(); if (!a) return; if (this.fv.atributos.includes(a)) return toast('El atributo ya existe'); this.fv.atributos.push(a); this.nuevoAtributo = ''; },
    guardarVariante() {
      if (!this.fv.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      if (!this.fv.atributos.length) return toast('Agregue al menos un atributo', 'err');
      if (this.fv.id) { const i = this.variantes.findIndex(v => v.id === this.fv.id); this.variantes[i] = { ...this.fv }; } else this.variantes.push({ ...this.fv, id: mock.nextId(this.variantes, 'variantes') });
      mock.set('variantes', this.variantes); toast('Variante guardada', 'ok'); this.fv = null;
    },
    eliminarVariante(r) { if (!confirm('¿Eliminar la variante "' + r.nombre + '"?')) return; this.variantes = this.variantes.filter(v => v.id !== r.id); mock.set('variantes', this.variantes); toast('Variante eliminada', 'ok'); },
    nuevoCampo() { this.fc = { id: null, nombre: '', tipo: 'Texto', valor_defecto: '', opciones: '', descripcion: '', requerido: false, imprimir: false }; },
    editarCampo(r) { this.fc = { ...r, valor_defecto: r.valor_defecto ?? r.defecto ?? '', opciones: (Array.isArray(r.opciones) ? r.opciones : String(r.opciones || '').split(',').map(s => s.trim()).filter(Boolean)).join(', ') }; },   // (R117)
    guardarCampo() {
      if (!this.fc.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      const c = { ...this.fc, opciones: this.fc.tipo === 'Lista' ? String(this.fc.opciones || '').split(',').map(s => s.trim()).filter(Boolean) : [] };
      if (c.tipo === 'Lista' && !c.opciones.length) return toast('Indique las opciones de la lista separadas por coma', 'err');
      if (c.id) { const i = this.campos.findIndex(x => x.id === c.id); this.campos[i] = c; } else this.campos.push({ ...c, id: mock.nextId(this.campos, 'campos_adicionales') });
      mock.set('campos_adicionales', this.campos); toast('Campo guardado', 'ok'); this.fc = null;
    },
    eliminarCampo(r) { if (!confirm('¿Eliminar el campo "' + r.nombre + '"?')) return; this.campos = this.campos.filter(c => c.id !== r.id); mock.set('campos_adicionales', this.campos); toast('Campo eliminado', 'ok'); },
    eliminarVariantes(rows) { const ids = rows.map(r => r.id); this.variantes = this.variantes.filter(v => !ids.includes(v.id)); mock.set('variantes', this.variantes); toast(ids.length + ' variantes eliminadas', 'ok'); },
    eliminarCampos(rows) { const ids = rows.map(r => r.id); this.campos = this.campos.filter(c => !ids.includes(c.id)); mock.set('campos_adicionales', this.campos); toast(ids.length + ' campos eliminados', 'ok'); },
  },
  template: `
  <div class="page">
    <PageHead title="Atributos" sub="Defina variantes (color, talla…) y campos adicionales para enriquecer la información de sus ítems.">
      <button class="btn" v-if="tab==='variantes'" @click="nuevaVariante">+ Nueva variante</button>
      <button class="btn" v-if="tab==='campos'" @click="nuevoCampo">+ Nuevo campo adicional</button>
    </PageHead>
    <div class="tiles" style="margin-bottom:18px">
      <div class="tile" :style="tab==='variantes'?'border-color:var(--primary)':''" @click="tab='variantes'"><h3>◧ Variantes</h3><p>Cree combinaciones de un mismo producto, por ejemplo Color: rojo, azul; Talla: S, M, L.</p><div class="links"><span class="muted">{{variantes.length}} variantes definidas</span></div></div>
      <div class="tile" :style="tab==='campos'?'border-color:var(--primary)':''" @click="tab='campos'"><h3>☰ Campos adicionales</h3><p>Agregue información personalizada a sus ítems (marca, garantía, vencimiento…) e imprímala en la factura.</p><div class="links"><span class="muted">{{campos.length}} campos definidos</span></div></div>
    </div>
    <div class="card pad0" v-if="tab!=='hub'">
      <div style="padding:12px 12px 0">
        <div class="tabs" style="margin-bottom:10px"><button :class="{on:tab==='variantes'}" @click="tab='variantes'">Variantes</button><button :class="{on:tab==='campos'}" @click="tab='campos'">Campos adicionales</button></div>
        <div class="toolbar"><input class="search" placeholder="Buscar" v-model="q"></div>
      </div>
      <DataTable v-if="tab==='variantes'" :rows="variantes" :columns="colVariantes" :search="q" selectable :on-bulk-delete="eliminarVariantes" empty-title="Sin variantes" empty-text="Cree una variante para generar combinaciones de productos.">
        <template #actions="{row}"><button class="btn icon" @click.stop="editarVariante(row)" title="Editar">✎</button><button class="btn icon" @click.stop="eliminarVariante(row)" title="Eliminar">🗑</button></template>
        <template #empty><button class="btn" @click="nuevaVariante">+ Nueva variante</button></template>
      </DataTable>
      <DataTable v-else :rows="campos" :columns="colCampos" :search="q" selectable :on-bulk-delete="eliminarCampos" empty-title="Sin campos adicionales" empty-text="Cree campos para registrar información personalizada de sus ítems.">
        <template #actions="{row}"><button class="btn icon" @click.stop="editarCampo(row)" title="Editar">✎</button><button class="btn icon" @click.stop="eliminarCampo(row)" title="Eliminar">🗑</button></template>
        <template #empty><button class="btn" @click="nuevoCampo">+ Nuevo campo adicional</button></template>
      </DataTable>
    </div>

    <Modal v-if="fv" :title="fv.id?'Editar variante':'Nueva variante'" @close="fv=null">
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Nombre" req><input v-model="fv.nombre" placeholder="Ej. Color"></Field>
        <Field label="Atributos" req help="Escriba un valor y presione Enter o Agregar">
          <div class="row" style="gap:6px"><input v-model="nuevoAtributo" placeholder="Ej. Rojo" @keyup.enter="agregarAtributo" style="flex:1"><button class="btn sec sm" @click="agregarAtributo">Agregar</button></div>
        </Field>
      </div>
      <div class="row" style="margin-top:10px;gap:6px"><span class="chip on" v-for="(a,i) in fv.atributos" :key="a" @click="fv.atributos.splice(i,1)" title="Quitar">{{a}} ✕</span><span class="muted small" v-if="!fv.atributos.length">Aún no hay atributos.</span></div>
      <template #foot><button class="btn ghost" @click="fv=null">Cancelar</button><button class="btn" @click="guardarVariante">Guardar</button></template>
    </Modal>

    <Modal v-if="fc" :title="fc.id?'Editar campo adicional':'Nuevo campo adicional'" @close="fc=null">
      <div class="grid">
        <Field label="Nombre" req><input v-model="fc.nombre"></Field>
        <Field label="Tipo de campo" req><select v-model="fc.tipo"><option>Texto</option><option>Número</option><option>Fecha</option><option>Lista</option></select></Field>
        <Field label="Opciones de la lista" req help="Separadas por coma" v-if="fc.tipo==='Lista'" style="grid-column:1/-1"><input v-model="fc.opciones" placeholder="Nacional, Importado"></Field>
        <Field label="Valor por defecto"><input :type="fc.tipo==='Número'?'number':fc.tipo==='Fecha'?'date':'text'" v-model="fc.valor_defecto"></Field>
        <Field label="Descripción"><input v-model="fc.descripcion"></Field>
      </div>
      <div class="row" style="margin-top:14px;gap:24px"><Toggle v-model="fc.requerido" label="Requerido"></Toggle><Toggle v-model="fc.imprimir" label="Imprimir en factura"></Toggle></div>
      <template #foot><button class="btn ghost" @click="fc=null">Cancelar</button><button class="btn" @click="guardarCampo">Guardar</button></template>
    </Modal>
  </div>`,
};
