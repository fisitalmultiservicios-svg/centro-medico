// Inventario — Ajustes de inventario: listado y detalle (backend real: /api/inventario/ajustes, incluye transferencias)
import { api, money, fmt, fecha, toast } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';

const TIPO = { ajuste: 'Ajuste', transferencia: 'Transferencia', compra: 'Compra' };   // 3.75: las compras entran como CO-####

export default {
  props: ['params'],
  data() { return { lista: [], q: '', filtro: 'todos', ver: null, cargando: false }; },
  computed: {
    rows() {
      return this.lista.filter(a => this.filtro === 'todos' || a.tipo === this.filtro)
        .map(a => ({ ...a, tipoLabel: TIPO[a.tipo] || 'Ajuste', bodegaLabel: a.tipo === 'transferencia' ? `${a.bodega || '—'} → ${a.bodega_destino || '—'}` : (a.bodega || '—') }));
    },
    columns() {
      return [
        { key: 'codigo', label: 'Número', mono: true, link: r => this.abrir(r) },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'tipoLabel', label: 'Tipo', fmt: 'badge' },
        { key: 'bodegaLabel', label: 'Bodega' },
        { key: 'total', label: 'Total ajustado', num: true, fmt: (v, r) => r.tipo === 'transferencia' ? '—' : money(v) },
        { key: 'observaciones', label: 'Observaciones', fmt: v => v || '—' },
      ];
    },
  },
  methods: {
    money, fmt, fecha,
    async cargar(aviso = false) {
      this.cargando = true;
      try { this.lista = await api('/api/inventario/ajustes'); if (aviso) toast('Listado actualizado', 'ok'); } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async abrir(r) {
      this.ver = { ...r, movimientos: null };
      try { this.ver = { ...this.ver, ...(await api('/api/inventario/ajustes/' + r.id)) }; } catch (e) { toast(e.message, 'err'); this.ver = null; }
    },
    // En una transferencia hay dos movimientos por producto (salida en origen, entrada en destino); se muestran todos con su bodega
    tipoLinea(m) { return m.tipo === 'transferencia' ? (m.cantidad < 0 ? 'Salida' : 'Entrada') : m.tipo === 'compra' ? 'Compra' : (m.cantidad < 0 ? 'Disminución' : 'Incremento'); },
    // 3.75: con PEPS/UEPS una salida dice de qué capas salió (cantidad × costo de cada una)
    capasTexto(m) { return (m.capas || []).map(k => fmt(k.cantidad, 2) + ' × ' + money(k.costo_unitario) + (k.capa_id === null ? ' (sin capa)' : k.fecha && k.fecha !== '1900-01-01' ? ' del ' + fecha(k.fecha) : ' (existencia anterior)')).join(' + '); },
    exportar() {
      if (!this.rows.length) return toast('No hay ajustes para exportar');
      exportarFilas('ajustes-inventario', ['Número', 'Fecha', 'Tipo', 'Bodega', 'Bodega destino', 'Total ajustado', 'Observaciones'], this.rows.map(a => [a.codigo, a.fecha, a.tipoLabel, a.bodega || '', a.bodega_destino || '', a.tipo === 'transferencia' ? '' : a.total, a.observaciones || '']), { titulo: 'Ajustes de inventario', num: [5] });
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Ajustes de inventario" sub="Incrementos y disminuciones por conteos físicos, daños o pérdidas, transferencias entre bodegas y entradas por compra (CO-####).">
      <button class="btn ghost" @click="cargar(true)" :disabled="cargando">↻ Actualizar</button>
      <button class="btn ghost" @click="exportar">⤓ Exportar</button>
      <a class="btn" v-if="puede('inventario')" href="#/inventario/ajustes/nuevo">+ Nuevo ajuste</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0">
        <input class="search" placeholder="Buscar por número, bodega u observación" v-model="q">
        <span class="chip" :class="{on:filtro==='ajuste'}" @click="filtro=filtro==='ajuste'?'todos':'ajuste'">Ajustes</span>
        <span class="chip" :class="{on:filtro==='transferencia'}" @click="filtro=filtro==='transferencia'?'todos':'transferencia'">Transferencias</span>
        <span class="chip" :class="{on:filtro==='compra'}" @click="filtro=filtro==='compra'?'todos':'compra'">Compras</span>
      </div>
      <DataTable :rows="rows" :columns="columns" :search="q" empty-title="Aún no has registrado ajustes" empty-text="Crea un ajuste para corregir las existencias de tus productos. Los ajustes registrados no se pueden eliminar: para revertir uno, registre el ajuste contrario.">
        <template #actions="{row}"><button class="btn icon" @click.stop="abrir(row)" title="Ver">👁</button></template>
        <template #empty><a class="btn" v-if="puede('inventario')" href="#/inventario/ajustes/nuevo">+ Nuevo ajuste</a></template>
      </DataTable>
    </div>
    <Modal v-if="ver" :title="(ver.tipo==='transferencia'?'Transferencia ':ver.tipo==='compra'?'Compra ':'Ajuste ') + ver.codigo" lg @close="ver=null">
      <div class="grid" style="margin-bottom:14px">
        <div><div class="small muted">Fecha</div><b>{{fecha(ver.fecha)}}</b></div>
        <div><div class="small muted">{{ver.tipo==='transferencia'?'Origen → Destino':'Bodega'}}</div><b>{{ver.tipo==='transferencia'?(ver.bodega||'—')+' → '+(ver.bodega_destino||'—'):(ver.bodega||'—')}}</b></div>
        <div><div class="small muted">Tipo</div><Badge :value="ver.tipo==='transferencia'?'Transferencia':ver.tipo==='compra'?'Compra':'Ajuste'"></Badge></div>
        <div v-if="ver.tipo!=='transferencia'"><div class="small muted">{{ver.tipo==='compra'?'Total de la entrada':'Total ajustado'}}</div><b>{{money(ver.total)}}</b></div>
        <div style="grid-column:1/-1" v-if="ver.observaciones"><div class="small muted">Observaciones</div>{{ver.observaciones}}</div>
      </div>
      <p class="muted small" v-if="!ver.movimientos">Cargando detalle…</p>
      <table class="tbl" v-else-if="ver.movimientos.length"><thead><tr><th>Producto</th><th>Bodega</th><th>Tipo</th><th class="num">Cantidad</th><th class="num">Costo unitario</th><th class="num">Existencia resultante</th><th class="num">Total</th></tr></thead>
        <tbody><tr v-for="m in ver.movimientos" :key="m.id"><td>{{m.producto||('Producto '+m.producto_id)}}<div class="small muted" v-if="m.capas && m.capas.length && ver.metodo && ver.metodo!=='promedio'">{{ver.metodo.toUpperCase()}}: {{capasTexto(m)}}</div></td><td>{{m.bodega||'—'}}</td><td>{{tipoLinea(m)}}</td><td class="num" :style="m.cantidad<0?'color:var(--danger)':''">{{m.cantidad>0?'+':''}}{{fmt(m.cantidad,0)}}</td><td class="num">{{money(m.costo_unitario)}}</td><td class="num">{{fmt(m.existencia_resultante,0)}}</td><td class="num">{{money(m.cantidad*m.costo_unitario)}}</td></tr></tbody></table>
      <p class="muted small" v-else>Sin movimientos asociados.</p>
      <template #foot><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
};
