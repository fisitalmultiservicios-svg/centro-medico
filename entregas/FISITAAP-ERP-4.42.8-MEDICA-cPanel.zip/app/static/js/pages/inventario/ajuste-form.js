// Inventario — Nuevo ajuste de inventario (backend real: POST /api/inventario/ajustes; bodegas y existencias de la API)
import { api, money, fmt, hoy, toast, fmtCant } from '../../api.js';
import { store } from '../../app.js';

export default {
  props: ['params'],
  data() {
    return {
      bodegas: [], existencias: {}, guardando: false,
      f: { bodega_id: null, fecha: hoy(), observaciones: '' },
      lineas: [this.linea()],
    };
  },
  computed: {
    store() { return store; },
    productos() { return store.productos.filter(p => !p.es_servicio && p.inventariable !== false && p.activo !== false); },
    total() { return this.lineas.reduce((s, l) => s + this.totalLinea(l), 0); },
    tipoAjuste() { const t = new Set(this.lineas.filter(l => l.producto_id).map(l => l.tipo)); return t.size > 1 ? 'Mixto' : [...t][0] === 'disminucion' ? 'Disminución' : 'Incremento'; },
  },
  watch: { 'f.bodega_id'() { this.cargarExistencias(); } },
  methods: {
    fmtCant,
    money, fmt,
    linea() { return { producto_id: null, actual: 0, tipo: 'incremento', cantidad: 0, costo: 0 }; },
    async cargarExistencias() {
      if (!this.f.bodega_id) return;
      try {
        const l = await api('/api/inventario/existencias?bodega_id=' + this.f.bodega_id);
        this.existencias = {}; for (const e of l) this.existencias[e.producto_id] = e.bodegas?.[this.f.bodega_id] || { cantidad: e.cantidad, costo_promedio: e.costo_promedio };
        for (const li of this.lineas) this.pick(li);
      } catch (e) { toast(e.message, 'err'); }
    },
    pick(l) {
      const p = this.productos.find(x => x.id == l.producto_id); if (!p) { l.actual = 0; l.costo = 0; return; }
      const ex = this.existencias[p.id]; l.actual = ex ? +ex.cantidad || 0 : 0; l.costo = ex && ex.costo_promedio ? +ex.costo_promedio : (+p.costo || 0);
    },
    finalLinea(l) { return l.tipo === 'incremento' ? l.actual + (+l.cantidad || 0) : l.actual - (+l.cantidad || 0); },
    totalLinea(l) { return (l.tipo === 'incremento' ? 1 : -1) * (+l.cantidad || 0) * (+l.costo || 0); },
    async guardar() {
      const validas = this.lineas.filter(l => l.producto_id && +l.cantidad > 0);
      if (!this.f.bodega_id || !this.f.fecha) return toast('Complete bodega y fecha', 'err');
      if (!validas.length) return toast('Agregue al menos un producto con cantidad mayor a cero', 'err');
      if (validas.some(l => this.finalLinea(l) < 0 && !this.productos.find(p => p.id == l.producto_id)?.venta_negativo)) return toast('La cantidad final no puede ser negativa', 'err');
      this.guardando = true;
      try {
        const r = await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: this.f.bodega_id, fecha: this.f.fecha, observaciones: this.f.observaciones || null,
          lineas: validas.map(l => ({ producto_id: l.producto_id, tipo: l.tipo, cantidad: +l.cantidad, costo_unitario: l.tipo === 'incremento' ? (+l.costo || 0) : null })) } });   // las disminuciones salen al costo promedio (R278)
        toast('Ajuste ' + r.codigo + ' registrado', 'ok');
        location.hash = '/inventario/ajustes';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    if (store.fallos?.productos) store.cargar();
    try { this.bodegas = await api('/api/inventario/bodegas'); this.f.bodega_id = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null; } catch (e) { toast(e.message, 'err'); }
  },
  template: `
  <div class="page">
    <PageHead title="Nuevo ajuste de inventario" sub="Modifique las existencias de sus productos indicando el tipo de ajuste y la cantidad." :crumbs="[{label:'Ajustes de inventario',to:'/inventario/ajustes'},{label:'Nuevo'}]"></PageHead>
    <div class="card">
      <div class="grid">
        <Field label="Bodega" req><Buscador v-model="f.bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        <Field label="Fecha" req><input type="date" v-model="f.fecha" :max="hoy"></Field>
        <Field label="Numeración" help="Se asigna automáticamente al guardar"><input class="mono" value="AJ-#### (automática)" disabled></Field>
        <Field label="Observaciones" style="grid-column:1/-1"><textarea rows="2" v-model="f.observaciones" placeholder="Motivo del ajuste (conteo físico, daño, pérdida…)"></textarea></Field>
      </div>
    </div>
    <div class="card"><h2>Productos <small>Tipo de ajuste: {{tipoAjuste}}</small></h2>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th style="min-width:220px">Producto</th><th class="num">Cantidad actual</th><th style="width:140px">Tipo de ajuste</th><th class="num" style="width:110px">Cantidad</th><th class="num" style="width:130px">Costo unitario</th><th class="num">Cantidad final</th><th class="num">Total ajustado</th><th></th></tr></thead>
        <tbody><tr v-for="(l,i) in lineas" :key="i">
          <td><Buscador v-model="l.producto_id" :opciones="productos" :etiqueta="p => (p.codigo ? p.codigo + ' · ' : '') + p.nombre" vacio="Seleccionar" agregar="item" @change="pick(l)"></Buscador></td>
          <td class="num">{{fmtCant(l.actual)}}</td>
          <td><select class="inp" v-model="l.tipo"><option value="incremento">Incremento</option><option value="disminucion">Disminución</option></select></td>
          <td><input class="inp" type="number" min="0" v-model.number="l.cantidad" style="width:100%;text-align:right"></td>
          <td><input class="inp" type="number" min="0" step="0.01" v-model.number="l.costo" style="width:100%;text-align:right" :disabled="l.tipo==='disminucion'" :title="l.tipo==='disminucion'?'Las disminuciones usan el costo promedio actual':''"></td>
          <td class="num" :style="finalLinea(l)<0?'color:var(--danger)':''">{{fmtCant(finalLinea(l))}}</td>
          <td class="num">{{money(totalLinea(l))}}</td>
          <td><button class="btn icon" @click="lineas.splice(i,1)" :disabled="lineas.length===1">✕</button></td>
        </tr></tbody>
      </table></div>
      <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="lineas.push(linea())">+ Agregar producto</button><span class="small muted" v-if="!productos.length">No hay productos inventariables activos.</span></div>
      <div class="totals"><div class="total"><span>Total</span><b>{{money(total)}}</b></div></div>
    </div>
    <div class="row end" style="margin-bottom:18px">
      <a class="btn ghost" href="#/inventario/ajustes">Cancelar</a>
      <button class="btn" @click="guardar" :disabled="guardando">{{guardando?'Guardando…':'Guardar'}}</button>
    </div>
  </div>`,
  setup() { return { hoy: hoy() }; },
};
