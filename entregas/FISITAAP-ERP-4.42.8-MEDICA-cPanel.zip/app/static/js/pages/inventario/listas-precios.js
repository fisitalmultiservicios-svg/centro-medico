// Inventario — Listas de precios (registro 'listas_precios' del servidor; los ejemplos solo en la demo)
import { mock, toast, monedas } from '../../api.js';

const EJEMPLO = [
  { id: 1, nombre: 'General', principal: true, tipo: 'Valor', descripcion: 'Lista de precios base', moneda: 'CRC', activa: true },
  { id: 2, nombre: 'Mayoristas', principal: false, tipo: 'Porcentaje', descripcion: 'Descuento del 15 % para compras al por mayor', moneda: 'CRC', activa: true },
  { id: 3, nombre: 'Precios en dólares', principal: false, tipo: 'Valor', descripcion: 'Precios fijos en USD para clientes del exterior', moneda: 'USD', activa: true },
];

export default {
  props: ['params'],
  data() {
    // La lista 'General' siempre existe; 'Mayoristas' y 'Precios en dólares' solo son ejemplos (demo).
    const lista = mock.ejemplos('listas_precios', EJEMPLO.slice(1), 'nombre');      // 'General' es real, nunca se limpia como ejemplo
    if (!lista.some(l => l.principal)) lista.unshift({ ...EJEMPLO[0] });     // se muestra siempre; se guarda cuando el usuario cambie algo
    return { lista, q: '', f: null, ver: null, monedasOpc: monedas.opciones() };
  },
  computed: {
    rows() { return this.lista.map(l => ({ ...l, principalTxt: l.principal ? 'Sí' : 'No', estado: l.activa === false ? 'Inactiva' : 'Activa' })); },
    columns() {
      return [
        { key: 'nombre', label: 'Nombre', link: r => this.ver = r },
        { key: 'principalTxt', label: 'Principal' },
        { key: 'tipo', label: 'Tipo' },
        { key: 'moneda', label: 'Moneda', fmt: v => v || 'CRC' },
        { key: 'descripcion', label: 'Descripción', fmt: v => v || '—' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    nuevo() { this.f = { id: null, nombre: '', tipo: 'Valor', descripcion: '', moneda: monedas.principal().codigo, principal: false, activa: true }; },
    editar(r) { this.f = { ...r }; },
    guardar() {
      if (!this.f.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      if (this.lista.some(l => l.nombre.toLowerCase() === this.f.nombre.trim().toLowerCase() && l.id !== this.f.id)) return toast('Ya existe una lista con ese nombre', 'err');
      const { principalTxt, estado, ...datos } = this.f;
      if (datos.id) { const i = this.lista.findIndex(l => l.id === datos.id); this.lista[i] = { ...this.lista[i], ...datos }; }
      else { datos.id = mock.nextId(this.lista, 'listas_precios'); this.lista.push(datos); }
      mock.set('listas_precios', this.lista); toast('Lista de precios guardada', 'ok'); this.f = null;
    },
    activar(r) { const l = this.lista.find(x => x.id === r.id); l.activa = l.activa === false; mock.set('listas_precios', this.lista); toast(l.activa ? 'Lista activada' : 'Lista desactivada', 'ok'); },
    eliminar(r) { if (r.principal) return toast('La lista principal no se puede eliminar', 'err'); if (!confirm('¿Eliminar la lista "' + r.nombre + '"? Los precios de los ítems en esa lista se quitarán y los contactos que la usaban pasarán a la lista General.')) return; this.lista = this.lista.filter(l => l.id !== r.id); mock.set('listas_precios', this.lista); this.limpiarReferencias([r.id]); toast('Lista eliminada', 'ok'); },
    // sin huérfanos: los precios por ítem y los contactos que apuntaban a la lista borrada (R282)
    limpiarReferencias(ids) {
      mock.actualizar('items_extra', x => { for (const v of Object.values(x || {})) if (v && v.listas) v.listas = v.listas.filter(l => !ids.includes(l.lista_id)); }, {});
      mock.actualizar('contactos_extra', x => { for (const v of Object.values(x || {})) if (v && ids.includes(v.lista_precios_id)) v.lista_precios_id = 1; }, {});
    },
    // Acciones masivas (la lista principal siempre se omite)
    eliminarVarios(rows) { const ids = rows.filter(r => !r.principal).map(r => r.id); const omit = rows.length - ids.length; this.lista = this.lista.filter(l => !ids.includes(l.id)); mock.set('listas_precios', this.lista); this.limpiarReferencias(ids); toast(ids.length + ' listas eliminadas' + (omit ? '; la principal se omitió' : ''), 'ok'); },
    activarVarios(rows, activa) { let n = 0; for (const r of rows) { const l = this.lista.find(x => x.id === r.id); if (l && !l.principal) { l.activa = activa; n++; } } mock.set('listas_precios', this.lista); toast(n + (activa ? ' listas activadas' : ' listas desactivadas'), 'ok'); },
    bulk() {
      return [
        { label: '✔ Activar', kind: 'sec', handler: rows => this.activarVarios(rows, true) },
        { label: '⏻ Desactivar', kind: 'sec', handler: rows => this.activarVarios(rows, false) },
      ];
    },
  },
  template: `
  <div class="page">
    <PageHead title="Listas de precios" sub="Defina precios diferenciados por tipo de cliente o canal de venta. Cada lista tiene su moneda; los precios por ítem se asignan en la ficha del ítem.">
      <button class="btn" @click="nuevo">+ Nueva lista de precios</button>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar lista" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" selectable :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Sin listas de precios">
        <template #actions="{row}">
          <button class="btn icon" @click.stop="ver=row" title="Ver">👁</button>
          <button class="btn icon" @click.stop="editar(row)" title="Editar">✎</button>
          <button class="btn icon" @click.stop="activar(row)" :disabled="row.principal" :title="row.estado==='Activa'?'Desactivar':'Activar'">{{row.estado==='Activa'?'⏻':'✔'}}</button>
          <button class="btn icon" @click.stop="eliminar(row)" :disabled="row.principal" title="Eliminar">🗑</button>
        </template>
      </DataTable>
    </div>
    <Modal v-if="f" :title="f.id?'Editar lista de precios':'Nueva lista de precios'" @close="f=null">
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Nombre" req><input v-model="f.nombre"></Field>
        <Field label="Tipo" req help="Valor: precio fijo por ítem. Porcentaje: descuento o recargo sobre el precio base."><select v-model="f.tipo" :disabled="f.principal"><option>Valor</option><option>Porcentaje</option></select></Field>
        <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Descripción"><textarea rows="2" v-model="f.descripcion"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="f=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="ver" :title="ver.nombre" @close="ver=null">
      <div class="grid">
        <div><div class="small muted">Principal</div><b>{{ver.principalTxt}}</b></div><div><div class="small muted">Tipo</div><b>{{ver.tipo}}</b></div>
        <div><div class="small muted">Moneda</div><b>{{ver.moneda||'CRC'}}</b></div><div><div class="small muted">Estado</div><Badge :value="ver.estado"></Badge></div>
        <div style="grid-column:1/-1"><div class="small muted">Descripción</div>{{ver.descripcion||'—'}}</div>
      </div>
      <template #foot><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
};
