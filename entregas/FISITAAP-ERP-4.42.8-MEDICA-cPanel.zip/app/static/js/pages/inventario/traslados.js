// Inventario — Traslados a otra empresa del grupo (3.69): factura al costo (+ %) a la otra cédula, descuenta aquí y entra allá.
import { api, money, fmt, fechaHora, toast, fmtCant } from '../../api.js';
import { store, sesion } from '../../app.js';

export default {
  data() {
    return {
      tab: 'nuevo', destinos: [], bodegas: [], existencias: {}, salidas: [], entradas: [], config: { porcentaje: 0 }, extraActivo: true, extraDisponible: true, cargado: false,
      f: { empresa_destino_id: null, bodega_origen_id: null, bodega_destino_id: null, porcentaje: 0, observaciones: '' },
      lineas: [this.linea()], guardando: false, resultado: null, guardandoPct: false, clave: null,
    };
  },
  computed: {
    sesion() { return sesion; },
    productos() { return (store.productos || []).filter(p => !p.es_servicio && p.inventariable !== false && p.es_venta !== false && p.activo !== false); },
    destino() { return this.destinos.find(d => d.id === this.f.empresa_destino_id) || null; },
    validas() { return this.lineas.filter(l => l.producto_id && +l.cantidad > 0); },
    subtotal() { return this.validas.reduce((s, l) => s + this.precio(l) * (+l.cantidad || 0), 0); },
    impuesto() { return this.validas.reduce((s, l) => { const p = this.prod(l); return s + this.precio(l) * (+l.cantidad || 0) * ((p && p.tarifa != null ? +p.tarifa : 13) / 100); }, 0); },
    total() { return this.subtotal + this.impuesto; },
    sinCosto() { return this.validas.filter(l => !(this.prod(l) && +this.prod(l).costo > 0)).map(l => this.prod(l).nombre); },
  },
  watch: { 'f.bodega_origen_id'() { this.cargarExistencias(); }, 'f.empresa_destino_id'(v) { const d = this.destino; this.f.bodega_destino_id = d ? ((d.bodegas.find(b => b.principal) || d.bodegas[0]) || {}).id || null : null; } },
  methods: {
    money, fmt, fmtCant,
    linea() { return { producto_id: null, cantidad: 1, actual: 0 }; },
    prod(l) { return this.productos.find(p => p.id == l.producto_id); },
    precio(l) { const p = this.prod(l); return p ? Math.round((+p.costo || 0) * (1 + (+this.f.porcentaje || 0) / 100) * 100) / 100 : 0; },
    fecha(v) { return v ? fechaHora(v) : ''; },
    async cargarExistencias() {
      if (!this.f.bodega_origen_id) return;
      try {
        const l = await api('/api/inventario/existencias?bodega_id=' + this.f.bodega_origen_id);
        this.existencias = {}; for (const e of l) this.existencias[e.producto_id] = e.bodegas?.[this.f.bodega_origen_id] || { cantidad: e.cantidad };
        for (const li of this.lineas) this.pick(li);
      } catch (e) { toast(e.message, 'err'); }
    },
    pick(l) { const ex = this.existencias[l.producto_id]; l.actual = ex ? +ex.cantidad || 0 : 0; },
    async cargar() {
      try {
        const [r, d, b] = await Promise.all([api('/api/traslados'), sesion.puede('inventario') && sesion.puede('facturar') ? api('/api/traslados/destinos').catch(() => []) : [], api('/api/inventario/bodegas').catch(() => [])]);   // 3.87: destinos solo para quien traslada (el Contador ve el historial sin un 403)
        this.salidas = r.salidas; this.entradas = r.entradas; this.config = r.config; this.extraActivo = r.extra_activo; this.f.porcentaje = r.config.porcentaje;
        this.extraDisponible = r.extra_disponible !== false;   // 3.87: el hotel no puede contratar el extra: solo recibe; abre en el historial
        if (!this.extraActivo && !this.extraDisponible) this.tab = 'historial';
        this.destinos = d; this.bodegas = b;
        if (!this.f.bodega_origen_id) this.f.bodega_origen_id = ((b.find(x => x.principal) || b[0]) || {}).id || null;
        if (!this.f.empresa_destino_id && d.length === 1) this.f.empresa_destino_id = d[0].id;
      } catch (e) { toast(e.message, 'err'); }
      this.cargado = true;
    },
    async guardarPct() {
      this.guardandoPct = true;
      try { this.config = await api('/api/traslados/config', { method: 'PUT', body: { porcentaje: +this.f.porcentaje || 0 } }); toast('Porcentaje guardado como predeterminado', 'ok'); } catch (e) { toast(e.message, 'err'); }
      this.guardandoPct = false;
    },
    async trasladar() {
      if (this.guardando) return;
      if (!this.f.empresa_destino_id) return toast('Elija la empresa que recibe', 'err');
      if (!this.validas.length) return toast('Agregue al menos un producto con cantidad', 'err');
      if (this.sinCosto.length) return toast('Sin costo registrado: ' + this.sinCosto.join(', ') + '. El traslado se factura al costo; póngalo en la ficha del ítem.', 'err');
      if (this.validas.some(l => +l.cantidad > l.actual && !(this.prod(l) || {}).venta_negativo)) return toast('Hay cantidades mayores a la existencia en la bodega de origen', 'err');
      if (!confirm('Se emitirá una factura de esta empresa a ' + this.destino.nombre + ' por ' + money(this.total) + ' (IVA incluido), se descontará la bodega de origen y la mercadería entrará a la bodega de destino. ¿Continuar?')) return;
      this.guardando = true;
      if (!this.clave) this.clave = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      try {
        const r = await api('/api/traslados', { method: 'POST', body: { empresa_destino_id: this.f.empresa_destino_id, bodega_origen_id: this.f.bodega_origen_id, bodega_destino_id: this.f.bodega_destino_id,
          porcentaje: +this.f.porcentaje || 0, observaciones: this.f.observaciones || null, clave_peticion: this.clave, lineas: this.validas.map(l => ({ producto_id: l.producto_id, cantidad: +l.cantidad })) } });
        this.resultado = r; this.clave = null; this.lineas = [this.linea()]; this.f.observaciones = '';
        toast(r.error ? 'Factura ' + r.consecutivo + ' emitida, pero ' + r.empresa_destino + ' no pudo registrarla: ' + r.error : 'Traslado listo: factura ' + r.consecutivo + ' y compra registrada en ' + r.empresa_destino, r.error ? 'err' : 'ok');
        store.cargar && store.cargar();
        await this.cargar(); this.cargarExistencias();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async reintentar(x) {
      try { const r = await api('/api/traslados/' + x.id + '/reintentar', { method: 'POST' }); toast('Registrado en ' + r.empresa_destino + ': compra ' + r.compra_id_destino, 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
  },
  async created() { if (store.fallos?.productos) store.cargar(); await this.cargar(); this.cargarExistencias(); },
  template: `
  <div class="page">
    <PageHead title="Traslados a otra empresa" :sub="extraActivo || extraDisponible ? 'Mueva mercadería a otra empresa suya con cédula distinta: una factura al costo, menos aquí y más allá, en un solo paso.' : 'La mercadería que otra empresa suya le trasladó, con su factura y su entrada a la bodega.'" :crumbs="[{label:'Inventario'},{label:'Traslados a otra empresa'}]"></PageHead>
    <div class="tabs" v-if="extraActivo || extraDisponible">
      <button :class="{on:tab==='nuevo'}" @click="tab='nuevo'">Nuevo traslado</button>
      <button :class="{on:tab==='historial'}" @click="tab='historial'">Historial</button>
    </div>
    <div class="card" v-if="cargado && !extraActivo && extraDisponible"><b>Grupo de empresas</b> es un extra del plan. <span class="muted">Pídalo en Configuración › Suscripción y planes; mientras tanto puede ver el historial.</span></div>
    <div class="card" v-else-if="cargado && !extraActivo"><b>En esta versión los traslados se reciben.</b> <span class="muted">Otra empresa suya que tenga el extra «Grupo de empresas» le traslada mercadería: aquí ve lo recibido, y la compra y la entrada a la bodega quedan registradas solas.</span></div>
    <div class="card" v-else-if="cargado && !destinos.length && tab==='nuevo'"><b>No hay otra empresa a la que trasladar.</b> <span class="muted">Su usuario debe tener acceso a la empresa que recibe con permisos de gastos e inventario (Configuración › Usuarios de esa empresa).</span></div>
    <template v-if="tab==='nuevo' && extraActivo && destinos.length">
      <div class="card">
        <div class="grid cols-4">
          <Field label="Empresa que recibe" req><select v-model="f.empresa_destino_id"><option :value="null">— Elegir —</option><option v-for="d in destinos" :key="d.id" :value="d.id">{{d.nombre_comercial || d.nombre}} · {{d.numero_id}}</option></select></Field>
          <Field label="Bodega de origen (aquí)" req><select v-model="f.bodega_origen_id"><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
          <Field label="Bodega de destino (allá)"><select v-model="f.bodega_destino_id" :disabled="!destino"><option v-for="b in (destino ? destino.bodegas : [])" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
          <Field label="Sobre el costo (%)" help="0 = al costo exacto. Lo define su contador"><div class="row" style="gap:6px"><input type="number" min="0" max="100" step="0.5" v-model.number="f.porcentaje"><button class="btn sm sec" v-if="sesion.puede('configurar') && +f.porcentaje !== +config.porcentaje" :disabled="guardandoPct" @click="guardarPct" title="Usarlo en los próximos traslados">Fijar</button></div></Field>
        </div>
        <Field label="Observaciones (van en la factura)"><input v-model="f.observaciones" maxlength="300" placeholder="Reposición semanal, pedido de la tienda…"></Field>
      </div>
      <div class="card pad0">
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Producto</th><th class="r">Existencia aquí</th><th class="r">Cantidad</th><th class="r">Costo</th><th class="r">Precio traslado</th><th class="r">Subtotal</th><th></th></tr></thead>
          <tbody><tr v-for="(l, i) in lineas" :key="i">
            <td><select class="inp" v-model="l.producto_id" @change="pick(l)"><option :value="null">— Producto —</option><option v-for="p in productos" :key="p.id" :value="p.id">{{p.codigo ? p.codigo + ' · ' : ''}}{{p.nombre}}</option></select></td>
            <td class="r">{{fmtCant(l.actual)}}</td>
            <td class="r"><input class="inp r" type="number" min="0" step="any" v-model.number="l.cantidad" style="width:110px"></td>
            <td class="r">{{prod(l) ? money(prod(l).costo) : ''}}</td>
            <td class="r">{{prod(l) ? money(precio(l)) : ''}}</td>
            <td class="r">{{prod(l) ? money(precio(l) * (+l.cantidad || 0)) : ''}}</td>
            <td><button class="btn icon" @click="lineas.splice(i,1)" v-if="lineas.length > 1">✕</button></td>
          </tr></tbody>
        </table></div>
        <div class="row" style="padding:10px 12px;justify-content:space-between;align-items:center">
          <button class="btn sec sm" @click="lineas.push(linea())">+ Producto</button>
          <div class="small">Subtotal {{money(subtotal)}} · IVA {{money(impuesto)}} · <b>Total {{money(total)}}</b></div>
        </div>
      </div>
      <p class="small muted">La factura sale a nombre de la empresa que recibe (se crea como cliente la primera vez). Allá queda registrada la compra con su IVA, entra a la bodega elegida y los productos que no existan se crean con la misma ficha. Cuando la factura llegue a su bandeja de Hacienda, ya estará vinculada a esa compra.</p>
      <div class="row" style="gap:8px"><button class="btn" :disabled="guardando" @click="trasladar">{{guardando ? 'Trasladando…' : 'Facturar y trasladar'}}</button></div>
      <div class="card" v-if="resultado" style="margin-top:12px"><b>Último traslado:</b> factura {{resultado.consecutivo}} ({{resultado.estado}}) a {{resultado.empresa_destino}} por {{money(resultado.total)}}.
        <span v-if="resultado.compra_id_destino"> Compra registrada allá con el número {{resultado.consecutivo}}<span v-if="resultado.productos_creados.length">; productos creados: {{resultado.productos_creados.join(', ')}}</span>.</span>
        <span v-else class="muted"> No se pudo registrar en destino: {{resultado.error}}.</span></div>
    </template>
    <template v-if="tab==='historial'">
      <div class="card pad0" v-if="extraActivo || extraDisponible || salidas.length"><div style="padding:12px 12px 0"><h2 style="margin:0">Enviados desde esta empresa</h2></div>
        <div class="table-wrap" v-if="salidas.length"><table class="tbl">
          <thead><tr><th>Fecha</th><th>A</th><th>Factura</th><th class="r">Líneas</th><th class="r">Total</th><th>En destino</th><th></th></tr></thead>
          <tbody><tr v-for="x in salidas" :key="x.id">
            <td class="small">{{fecha(x.fecha)}}</td><td>{{x.empresa_destino}}</td><td class="small">{{x.consecutivo}} <span class="muted">{{x.estado}}</span></td><td class="r">{{x.lineas}}</td><td class="r">{{money(x.total)}}</td>
            <td class="small"><span v-if="x.compra_id_destino">Compra registrada<span v-if="x.productos_creados && x.productos_creados.length"> · creó {{x.productos_creados.length}} producto(s)</span></span><span v-else class="muted">Pendiente: {{x.error}}</span></td>
            <td><button class="btn sm sec" v-if="!x.compra_id_destino" @click="reintentar(x)">Reintentar</button></td>
          </tr></tbody></table></div>
        <p class="muted" style="padding:12px" v-else>Aún no ha enviado traslados.</p>
      </div>
      <div class="card pad0"><div style="padding:12px 12px 0"><h2 style="margin:0">Recibidos en esta empresa</h2></div>
        <div class="table-wrap" v-if="entradas.length"><table class="tbl">
          <thead><tr><th>Fecha</th><th>De</th><th>Factura</th><th>Bodega</th><th class="r">Líneas</th><th class="r">Total</th></tr></thead>
          <tbody><tr v-for="x in entradas" :key="x.id">
            <td class="small">{{fecha(x.fecha)}}</td><td>{{x.empresa_origen}}</td><td class="small">{{x.consecutivo}}</td><td>{{x.bodega}}</td><td class="r">{{x.lineas}}</td><td class="r">{{money(x.total)}}</td>
          </tr></tbody></table></div>
        <p class="muted" style="padding:12px" v-else>Aún no ha recibido traslados.</p>
      </div>
    </template>
  </div>`,
};
