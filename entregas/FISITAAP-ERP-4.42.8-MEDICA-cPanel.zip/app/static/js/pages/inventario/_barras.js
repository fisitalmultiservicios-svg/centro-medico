// Código de barras Code 128 (B) en SVG, sin librerías (3.21): etiquetas de ítems para el lector de la caja.
const PATRONES = ['11011001100', '11001101100', '11001100110', '10010011000', '10010001100', '10001001100', '10011001000', '10011000100', '10001100100', '11001001000', '11001000100', '11000100100', '10110011100', '10011011100', '10011001110', '10111001100', '10011101100', '10011100110', '11001110010', '11001011100', '11001001110', '11011100100', '11001110100', '11101101110', '11101001100', '11100101100', '11100100110', '11101100100', '11100110100', '11100110010', '11011011000', '11011000110', '11000110110', '10100011000', '10001011000', '10001000110', '10110001000', '10001101000', '10001100010', '11010001000', '11000101000', '11000100010', '10110111000', '10110001110', '10001101110', '10111011000', '10111000110', '10001110110', '11101110110', '11010001110', '11000101110', '11011101000', '11011100010', '11011101110', '11101011000', '11101000110', '11100010110', '11101101000', '11101100010', '11100011010', '11101111010', '11001000010', '11110001010', '10100110000', '10100001100', '10010110000', '10010000110', '10000101100', '10000100110', '10110010000', '10110000100', '10011010000', '10011000010', '10000110100', '10000110010', '11000010010', '11001010000', '11110111010', '11000010100', '10001111010', '10100111100', '10010111100', '10010011110', '10111100100', '10011110100', '10011110010', '11110100100', '11110010100', '11110010010', '11011011110', '11011110110', '11110110110', '10101111000', '10100011110', '10001011110', '10111101000', '10111100010', '11110101000', '11110100010', '10111011110', '10111101110', '11101011110', '11110101110', '11010000100', '11010010000', '11010011100', '1100011101011'];
export function code128(texto) {
  const t = String(texto || '').replace(/[^\x20-\x7e]/g, '?'); if (!t) return '';
  const codigos = [104]; let suma = 104;
  for (let i = 0; i < t.length; i++) { const c = t.charCodeAt(i) - 32; codigos.push(c); suma += c * (i + 1); }
  codigos.push(suma % 103); codigos.push(106);
  return codigos.map(c => PATRONES[c]).join('');
}
export function svgBarras(texto, ancho = 2, alto = 50) {
  const bits = code128(texto); if (!bits) return '';
  let x = 0, out = '';
  for (const b of bits) { if (b === '1') out += `<rect x="${x}" y="0" width="${ancho}" height="${alto}" fill="#000"/>`; x += ancho; }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${x}" height="${alto + 14}" viewBox="0 0 ${x} ${alto + 14}"><rect width="100%" height="100%" fill="#fff"/>${out}<text x="${x / 2}" y="${alto + 11}" font-family="monospace" font-size="11" text-anchor="middle">${String(texto).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]))}</text></svg>`;
}

// 4.24 · EAN-13 (para la vista previa de la etiqueta): los 95 módulos de un código de 13 dígitos; '' si no lo es
const EAN_L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const EAN_G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const EAN_R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const EAN_PARIDAD = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];
export function ean13(codigo) {
  const c = String(codigo || ''); if (!/^[0-9]{13}$/.test(c)) return '';
  const par = EAN_PARIDAD[+c[0]]; let b = '101';
  for (let i = 1; i <= 6; i++) b += (par[i - 1] === 'L' ? EAN_L : EAN_G)[+c[i]];
  b += '01010';
  for (let i = 7; i <= 12; i++) b += EAN_R[+c[i]];
  return b + '101';
}
// Barras de un código para dibujarlas (vista previa de la etiqueta): EAN-13 si lo es (con su dígito verificador correcto); si no, Code 128.
// Devuelve { tipo, ancho (módulos, con la zona quieta), tramos: [{ x, w }] } para pintar un rectángulo por barra.
export function barrasDe(codigo, esEan) {
  const bits = esEan ? ean13(codigo) : code128(codigo); if (!bits) return { tipo: '', ancho: 0, tramos: [] };
  const quieta = esEan ? 11 : 10, tramos = [];
  for (let i = 0; i < bits.length; i++) { if (bits[i] !== '1') continue; let j = i; while (j < bits.length && bits[j] === '1') j++; tramos.push({ x: quieta + i, w: j - i }); i = j; }
  return { tipo: esEan ? 'ean13' : 'code128', ancho: bits.length + 2 * quieta, tramos };
}
