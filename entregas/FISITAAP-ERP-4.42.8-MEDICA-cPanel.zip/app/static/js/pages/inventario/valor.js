// Inventario — reporte Valor de inventario (backend real: /api/inventario/valor, /api/inventario/bodegas, /api/inventario/movimientos)
import { api, money, fmt, hoy, fecha, toast, fmtCant } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';

const TIPO_MOV = { inicial: 'Inventario inicial', ajuste: 'Ajuste', transferencia: 'Transferencia', venta: 'Venta', devolucion: 'Devolución', compra: 'Compra' };

export default {
  props: ['params'],
  data() { return { hasta: hoy(), bodega_id: '', q: '', bodegas: [], datos: { total: 0, items: [] }, cargando: false, movs: null, TIPO_MOV, metodo: 'promedio' }; },
  computed: {
    rows() { return this.datos.items.map(it => ({ ...it, id: it.producto_id, estado: it.activo === false ? 'Inactivo' : 'Activo' })); },
    total() { return this.datos.total || 0; },
    nombreBodega() { return this.bodega_id ? (this.bodegas.find(b => b.id == this.bodega_id)?.nombre || '') : 'todas las bodegas'; },
    // 3.75: con PEPS/UEPS el costo unitario es el de las capas que quedan; con promedio, el promedio ponderado
    etiquetaCosto() { return this.metodo === 'peps' ? 'Costo PEPS' : this.metodo === 'ueps' ? 'Costo UEPS' : 'Costo promedio'; },
    textoMetodo() { return this.metodo === 'peps' ? 'al costo de las capas que quedan (PEPS: salen primero las más antiguas)' : this.metodo === 'ueps' ? 'al costo de las capas que quedan (UEPS: salen primero las más recientes)' : 'según el costo promedio de cada ítem'; },
    columns() {
      return [
        { key: 'nombre', label: 'Ítem', link: r => location.hash = '/inventario/items/' + r.producto_id },
        { key: 'codigo', label: 'Referencia', mono: true, fmt: v => v || '—' },
        { key: 'cabys', label: 'CABYS', mono: true },
        { key: 'cantidad', label: 'Cantidad', num: true, fmt: 'num', dec: 0 },
        { key: 'unidad_medida', label: 'Unidad' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
        { key: 'costo_promedio', label: this.etiquetaCosto, num: true, fmt: 'money' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
      ];
    },
  },
  watch: { hasta() { this.cargar(); }, bodega_id() { this.cargar(); } },
  methods: {
    fmtCant,
    money, fmt, fecha,
    async cargar(aviso = false) {
      this.cargando = true;
      try {
        const qs = new URLSearchParams(); if (this.bodega_id) qs.set('bodega_id', this.bodega_id); if (this.hasta && this.hasta !== hoy()) qs.set('hasta', this.hasta);
        this.datos = await api('/api/inventario/valor' + (qs.toString() ? '?' + qs : ''));
        if (aviso) toast('Reporte actualizado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    descargar() {
      if (!this.rows.length) return toast('No hay datos para descargar');
      exportarFilas('valor-inventario-' + this.hasta, ['Ítem', 'Referencia', 'CABYS', 'Cantidad', 'Unidad', 'Estado', 'Costo promedio', 'Total'], this.rows.map(r => [r.nombre, r.codigo || '', r.cabys, r.cantidad, r.unidad_medida, r.estado, r.costo_promedio, r.total]).concat([['', '', '', '', '', '', 'Total', this.total]]), { titulo: 'Valor del inventario', periodo: 'Al ' + this.hasta, num: [3, 7] });
    },
    async verMovimientos(r) {
      this.movs = { nombre: r.nombre, lista: null };
      try { this.movs.lista = await api('/api/inventario/movimientos?producto_id=' + r.producto_id + (this.bodega_id ? '&bodega_id=' + this.bodega_id : '')); }
      catch (e) { toast(e.message, 'err'); this.movs = null; }
    },
  },
  async created() {
    try { this.bodegas = await api('/api/inventario/bodegas'); } catch (e) { toast(e.message, 'err'); }
    try { this.metodo = (await api('/api/inventario/config')).metodo || 'promedio'; } catch {}
    this.cargar();
  },
  template: `
  <div class="page">
    <PageHead title="Valor de inventario" :sub="'Conozca el valor de sus existencias a una fecha de corte, ' + textoMetodo + '.'">
      <button class="btn ghost" @click="cargar(true)" :disabled="cargando">↻ Actualizar</button>
      <button class="btn" @click="descargar">⤓ Descargar</button>
    </PageHead>
    <div class="dash" style="margin-bottom:18px">
      <div class="card w6" style="margin:0"><div class="grid cols-2">
        <Field label="Hasta" help="Fecha de corte del reporte"><input type="date" v-model="hasta" :max="hoy"></Field>
        <Field label="Bodega"><select v-model="bodega_id"><option value="">Todas</option><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
      </div></div>
      <div class="kpi w6"><div class="t">Total del inventario</div><div class="v">{{money(total)}}</div><div class="d">{{rows.length}} ítems · {{fmt(rows.reduce((s,r)=>s+r.cantidad,0),0)}} unidades · {{nombreBodega}} · al {{hasta.split('-').reverse().join('/')}}</div></div>
    </div>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar por ítem o referencia" v-model="q"><span class="small muted" v-if="cargando">Cargando…</span></div>
      <DataTable :rows="rows" :columns="columns" :search="q" empty-title="Sin ítems inventariables" empty-text="Cree productos con existencias para ver el valor de su inventario.">
        <template #actions="{row}"><button class="btn icon" @click.stop="verMovimientos(row)" title="Ver movimientos">≡</button></template>
      </DataTable>
    </div>
    <Modal v-if="movs" :title="'Movimientos · ' + movs.nombre" lg @close="movs=null">
      <p class="muted small" v-if="!movs.lista">Cargando…</p>
      <div class="table-wrap" v-else-if="movs.lista.length"><table class="tbl">
        <thead><tr><th>Fecha</th><th>Tipo</th><th>Bodega</th><th>Referencia</th><th class="num">Cantidad</th><th class="num">Costo unitario</th><th class="num">Existencia</th></tr></thead>
        <tbody><tr v-for="m in movs.lista" :key="m.id"><td>{{fecha(m.fecha)}}</td><td><Badge :value="TIPO_MOV[m.tipo]||m.tipo"></Badge></td><td>{{m.bodega||'—'}}</td><td class="mono">{{m.referencia||'—'}}</td><td class="num" :style="m.cantidad<0?'color:var(--danger)':''">{{m.cantidad>0?'+':''}}{{fmtCant(m.cantidad)}}</td><td class="num">{{money(m.costo_unitario)}}</td><td class="num">{{fmtCant(m.existencia_resultante)}}</td></tr></tbody>
      </table></div>
      <Empty v-else icon="≡" title="Sin movimientos" text="Este ítem aún no tiene movimientos de inventario registrados."></Empty>
      <template #foot><button class="btn" @click="movs=null">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy: hoy() }; },
};
