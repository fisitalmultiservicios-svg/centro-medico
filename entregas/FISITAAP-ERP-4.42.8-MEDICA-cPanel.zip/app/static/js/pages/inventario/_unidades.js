// Unidades de las recetas (3.10): gramos, kilos, mililitros, litros, onzas, libras o unidades → unidad del inventario del producto.
// Misma tabla que app/unidades.py (cambiar las dos juntas). Un ítem que se inventaría por unidad (botella, saco) declara su
// contenido en Inventario › ítem › Opciones avanzadas (750 ml, 25 000 g).
export const UNIDADES_RECETA = [['g', 'g · gramos'], ['kg', 'kg · kilos'], ['ml', 'ml · mililitros'], ['l', 'l · litros'], ['oz', 'oz · onzas'], ['lb', 'lb · libras'], ['unid', 'unidades']];
const MASA = { g: 1, kg: 1000, lb: 453.592, oz: 28.3495 };
const VOLUMEN = { ml: 1, l: 1000, gal: 3785.41, oz: 29.5735 };
const PRODUCTO = { G: ['masa', 1], Kg: ['masa', 1000], L: ['vol', 1000], mL: ['vol', 1], Gal: ['vol', 3785.41], Oz: ['masa', 28.3495] };

function contenido(extra) { const c = +((extra || {}).contenido || 0); if (!(c > 0)) return null; const u = String((extra || {}).contenido_unidad || 'ml').toLowerCase(); return [u === 'g' || u === 'kg' ? 'masa' : 'vol', c * (u === 'kg' || u === 'l' ? 1000 : 1)]; }

// Cantidad en la unidad del producto; null = no se puede convertir (el sistema usa 1:1 y avisa)
export function aUnidadProducto(cantidad, unidad, producto, extra) {
  const q = +cantidad || 0, u = String(unidad || '').trim().toLowerCase();
  if (!u || u === 'unid' || u === 'unidad' || u === 'u') return q;
  let fam = PRODUCTO[producto && producto.unidad_medida];
  if (!fam) { fam = contenido(extra); if (!fam) return null; }
  const [familia, factor] = fam;
  if (familia === 'masa' && MASA[u] !== undefined) return q * MASA[u] / factor;
  if (familia === 'vol' && VOLUMEN[u] !== undefined) return q * VOLUMEN[u] / factor;
  return null;
}
// Unidades que tienen sentido para un producto (según su unidad de Hacienda o su contenido declarado)
export function unidadesPara(producto, extra) {
  const fam = PRODUCTO[producto && producto.unidad_medida] || contenido(extra);
  if (!fam) return UNIDADES_RECETA.filter(x => x[0] === 'unid');
  return UNIDADES_RECETA.filter(x => x[0] === 'unid' || (fam[0] === 'masa' ? MASA[x[0]] !== undefined : VOLUMEN[x[0]] !== undefined));
}
export function textoContenido(producto, extra) { const c = contenido(extra); if (!c) return ''; return 'cada ' + (producto.unidad_medida || 'unidad') + ' = ' + (c[0] === 'masa' ? c[1] + ' g' : c[1] + ' ml'); }
