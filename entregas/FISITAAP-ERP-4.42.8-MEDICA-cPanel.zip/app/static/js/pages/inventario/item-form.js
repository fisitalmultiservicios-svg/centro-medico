// Inventario — Nuevo producto / editar ítem (formulario avanzado). Backend real: /api/productos (POST/PUT + imagen), /api/inventario/bodegas, existencias, ajustes y movimientos.
// 4.40: la existencia mínima no cambia el catálogo en línea; «Agotado por ahora» agota aunque haya existencias (agotado según existencias en la configuración de ventas en línea).
import { api, toast, money, fmt, hoy, fecha, mock, CAT, opts, fmtCant, monedas, otroImp, otroImpLinea } from '../../api.js';

// 3.41: «Otro impuesto» del ítem (Anexos 4.4, nota 8). tipo = clave del selector; codigo = el de Hacienda
const OTRO_TIPOS = [
  ['', 'Ninguno (solo IVA)'], ['02', 'Impuesto Selectivo de Consumo'], ['04', 'Impuesto específico de bebidas alcohólicas'],
  ['05', 'Bebidas envasadas sin alcohol'], ['05j', 'Jabón de tocador'], ['06', 'Productos de tabaco'], ['03', 'Combustibles'], ['12', 'Impuesto al cemento (5 %)'],
];
const OI_VACIO = () => ({ tipo: '', modo: 'porcentaje', tarifa: null, monto_unidad: null, cantidad_unidad: null, porcentaje: null, volumen_unidad: null, impuesto_unidad: null });
import { store, sesion } from '../../app.js';

const LISTAS_BASE = [{ id: 1, nombre: 'General', principal: true, tipo: 'Valor', descripcion: 'Lista de precios base', activa: true }];
const CUENTAS = { ventas: ['4101 Ventas', '4102 Ventas de servicios', '4103 Otros ingresos'], inventario: ['1201 Inventarios', '1202 Inventario en tránsito'], costo: ['5101 Costos del inventario', '5102 Costo de servicios'] };
const TIPO_MOV = { inicial: 'Inventario inicial', ajuste: 'Ajuste', transferencia: 'Transferencia', venta: 'Venta', devolucion: 'Devolución', compra: 'Compra' };

import { migrarListas } from './items.js';
import { codigoBarrasPropio, esCodigoPropio, marcaDe, normCodigo, alternosDe } from './_etiquetas.js';   // 4.24: el código es el código de barras; alternos = los que tuvo antes

export default {
  props: ['params'],
  data() {
    return {
      f: this.vacio(), guardando: false, cargando: !!this.params.id, monedasOpc: monedas.opciones(), duplicadoDe: '', iaOk: false, iaCargando: false,
      bodegas: [], existencias: [], movimientos: [], capas: null,   // capas: { metodo, capas: [...] } con PEPS/UEPS (3.75)
      // Sin backend aún (mock 'items_extra'[id]): listas de precios, componentes de combo, campos adicionales, cuentas contables, variantes y tipo de código
      extra: migrarListas(mock.get('items_extra', {})), listas: ((l) => (l.some(x => x.principal) ? l : [...LISTAS_BASE, ...l]))(mock.get('listas_precios', LISTAS_BASE) || []), categorias: mock.get('categorias', []), camposDef: (mock.get('campos_adicionales', []) || []).map(c => ({ ...c, valor_defecto: c.valor_defecto ?? c.defecto ?? '', opciones: Array.isArray(c.opciones) ? c.opciones : String(c.opciones || c.atributos || '').split(',').map(s => s.trim()).filter(Boolean) })),
      cabysModal: false, cabysQ: '', cabysRes: [], buscandoCabys: false, cabysInfo: null, campoSel: '', CAT, opts, CUENTAS, TIPO_MOV,
      codigoOriginal: '', alternos: [], alternosTocados: false, conservarAnterior: false, generarAlGuardar: false,   // 4.24: código de barras y códigos alternos
    };
  },
  computed: {
    codigoCambiado() { return this.editando && !!this.codigoOriginal.trim() && normCodigo(this.f.codigo) !== normCodigo(this.codigoOriginal); },   // 4.24
    gruposMod() { return (mock.get('pos_modificadores', []) || []).filter(g => g && g.nombre && g.activo !== false); },   /* 3.49 */
    impresorasComanda() { return (mock.get('pos_impresoras', []) || []).filter(i => i && i.nombre && i.activa !== false && (i.uso || 'comanda') === 'comanda'); },   // (3.10)
    store() { return store; },
    editando() { return !!this.params.id; },
    // 4.25 (tanda 9): en el programa conectado, un ítem que no es de esta computadora se cambia en la web, en el momento
    deLaWeb() { const r = sesion.empresaInfo?.es_local ? +(sesion.empresaInfo?.rango_items || 0) : 0; return !!(r && this.editando && (r < 0 || Math.floor(+this.params.id / 10000000) !== r)); },
    pct() { return CAT.tarifaPct[this.f.codigo_tarifa] ?? 0; },
    OTRO_TIPOS() { return OTRO_TIPOS; },
    // «otro impuesto» como lo guarda el servidor (null = ninguno)
    oiBody() {
      const o = this.f.oi || OI_VACIO(), t = o.tipo; if (!t) return null;
      const n = v => (v === '' || v === null || v === undefined ? null : +v);
      if (t === '02') return o.modo === 'monto' ? { codigo: '02', monto_unidad: n(o.monto_unidad) } : { codigo: '02', tarifa: n(o.tarifa) };
      if (t === '12') return { codigo: '12' };
      if (t === '04') return { codigo: '04', cantidad_unidad: n(o.cantidad_unidad), porcentaje: n(o.porcentaje), impuesto_unidad: n(o.impuesto_unidad) };
      if (t === '05') return { codigo: '05', cantidad_unidad: n(o.cantidad_unidad), volumen_unidad: n(o.volumen_unidad), impuesto_unidad: n(o.impuesto_unidad), jabon: false };
      if (t === '05j') return { codigo: '05', cantidad_unidad: n(o.volumen_unidad), volumen_unidad: n(o.volumen_unidad), impuesto_unidad: n(o.impuesto_unidad), jabon: true };
      return { codigo: t, cantidad_unidad: n(o.cantidad_unidad), impuesto_unidad: n(o.impuesto_unidad) };
    },
    oiUnidad() { return otroImpLinea(this.oiBody, 1, +this.f.precio || 0).monto; },
    esServicio() { return this.f.tipo === 'Servicio'; },
    esCombo() { return this.f.tipo === 'Combo' || this.f.tipo === 'Surtido'; },
    costoCombo() { return this.f.componentes.reduce((s, c) => { const p = store.productos.find(x => x.id == c.producto_id); return s + (+c.cantidad || 0) * (p ? +p.costo || 0 : 0); }, 0); },
    costo() { return this.esCombo ? this.costoCombo : +this.f.costo || 0; },
    // 3.34: margen = ganancia / precio; markup = ganancia / costo (precio sin IVA, llevado a la moneda principal como el costo)
    precioPrincipal() { const pri = monedas.principal().codigo, mon = this.f.moneda || pri; const p = +this.f.precio || 0; return mon === pri ? p : p * monedas.tc(mon) / monedas.tc(pri); },
    rentabilidad() {
      const c = +this.costo || 0, p = this.precioPrincipal, g = p - c;
      return { ganancia: g, margen: p > 0 && c > 0 ? g / p * 100 : null, markup: c > 0 ? g / c * 100 : null, convertido: (this.f.moneda || monedas.principal().codigo) !== monedas.principal().codigo };
    },
    cantidadTotal() { return this.editando ? this.existencias.reduce((s, b) => s + (+b.cantidad || 0), 0) : this.f.porBodega.reduce((s, b) => s + (+b.cantidad || 0), 0); },
    nombreBodega() { const m = {}; for (const b of this.bodegas) m[b.id] = b.nombre; return m; },
  },
  methods: {
    async redactarIA() {
      if (!(this.f.nombre || '').trim()) return toast('Escriba primero el nombre del ítem', 'err');
      this.iaCargando = true;
      try { const r = await api('/api/ia/producto', { method: 'POST', body: { nombre: this.f.nombre, categoria: this.f.categoria || '', descripcion: this.f.descripcion || '', notas: '' } }); this.f.descripcion_publica = r.descripcion_publica; toast('Descripción redactada: revísela', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.iaCargando = false;
    },
    fmtCant,
    money, fmt, fecha,
    vacio() {
      return { tipo: this.params.tipo || 'Producto', variantes: false, contenido: null, contenido_unidad: 'ml', impresora_id: '', modificadores: [], nombre: this.params.nombre || '', categoria: '', unidad_medida: 'Unid', codigo: '', tipo_codigo: 'Interno', descripcion: '',
        existencia_minima: null, existencia_maxima: null,   // 3.87: Inventario › Por reponer (vacío = sin aviso)
        costo: 0, precio: 0, moneda: monedas.principal().codigo, total: 0, codigo_tarifa: '08', partida: '', cabys: this.params.cabys || '', imagen: '', inventariable: true, es_venta: true, negativo: false, activo: true, visible_catalogo: false, descripcion_publica: '', destacado: false, agotado: false,
        oi: OI_VACIO(), porBodega: [{ bodega_id: null, cantidad: 0 }], precios: [], componentes: [], campos: [], cuentas: { ventas: CUENTAS.ventas[0], inventario: CUENTAS.inventario[0], costo: CUENTAS.costo[0] } };
    },
    async cargarBodegas() {
      try { this.bodegas = await api('/api/inventario/bodegas'); } catch (e) { toast(e.message, 'err'); }
      const principal = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null;
      for (const b of this.f.porBodega) if (!b.bodega_id) b.bodega_id = principal;
    },
    async cargarInventario() {
      try {
        const [ex, movs, capas] = await Promise.all([api('/api/inventario/existencias?producto_id=' + this.params.id), api('/api/inventario/movimientos?producto_id=' + this.params.id + '&limite=20'),
                                                    api('/api/inventario/capas?producto_id=' + this.params.id).catch(() => null)]);
        this.existencias = Object.entries(ex[0]?.bodegas || {}).map(([bid, v]) => ({ bodega_id: +bid, bodega: this.nombreBodega[bid] || 'Bodega ' + bid, cantidad: v.cantidad, costo_promedio: v.costo_promedio }));
        this.movimientos = movs;
        this.capas = capas && capas.metodo !== 'promedio' ? capas : null;   // con promedio las capas se llevan pero no se muestran (3.75)
      } catch (e) { toast(e.message, 'err'); }
    },
    // Duplicar (3.43): mismos precios, impuestos, categoría y opciones; sin código, imagen ni existencias, con «(copia)» en el nombre
    async cargarCopia(id) {
      try {
        let p = store.productos.find(x => x.id == id);
        if (!p) { const l = await api('/api/productos'); p = l.find(x => x.id == id); }
        if (!p) { toast('Ítem a duplicar no encontrado', 'err'); return; }
        const ex = this.extra[p.id] || {};
        this.f = { ...this.vacio(), tipo: (p.es_servicio && (!p.tipo || p.tipo === 'Producto')) ? 'Servicio' : (p.tipo || 'Producto'), nombre: p.nombre + ' (copia)', codigo: '', unidad_medida: p.unidad_medida, cabys: p.cabys, precio: p.precio, moneda: p.moneda || monedas.principal().codigo, codigo_tarifa: p.codigo_tarifa,
          descripcion: p.descripcion || '', categoria: p.categoria || '', partida: p.partida_arancelaria || '', costo: p.costo || 0, es_venta: p.es_venta !== false, inventariable: p.inventariable !== false, negativo: !!p.venta_negativo, activo: true, visible_catalogo: !!p.visible_catalogo, descripcion_publica: p.descripcion_publica || '', destacado: !!p.destacado, agotado: false,
          variantes: !!ex.variantes, contenido: ex.contenido || null, contenido_unidad: ex.contenido_unidad || 'ml', impresora_id: ex.impresora_id || '', modificadores: Array.isArray(ex.modificadores) ? ex.modificadores.slice() : [], tipo_codigo: ex.tipo_codigo || 'Interno', precios: JSON.parse(JSON.stringify(ex.listas || [])), componentes: JSON.parse(JSON.stringify(ex.componentes || [])), campos: JSON.parse(JSON.stringify(ex.campos || [])), cuentas: ex.cuentas || this.vacio().cuentas };
        this.f.oi = this.oiDesde(p.otro_impuesto);
        this.f.existencia_minima = p.existencia_minima ?? null; this.f.existencia_maxima = p.existencia_maxima ?? null;   // 3.87
        this.duplicadoDe = p.nombre;
        this.recalcTotal();
      } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async cargar() {
      try {
        let p = store.productos.find(x => x.id == this.params.id);
        if (!p) { const l = await api('/api/productos'); p = l.find(x => x.id == this.params.id); }
        if (!p) { toast('Ítem no encontrado', 'err'); location.hash = '/inventario/items'; return; }
        const ex = this.extra[p.id] || {};
        this.f = { ...this.vacio(), tipo: (p.es_servicio && (!p.tipo || p.tipo === 'Producto')) ? 'Servicio' : (p.tipo || 'Producto'), nombre: p.nombre, codigo: p.codigo || '', unidad_medida: p.unidad_medida, cabys: p.cabys, precio: p.precio, moneda: p.moneda || monedas.principal().codigo, codigo_tarifa: p.codigo_tarifa,
          descripcion: p.descripcion || '', categoria: p.categoria || '', partida: p.partida_arancelaria || '', costo: p.costo || 0, es_venta: p.es_venta !== false, inventariable: p.inventariable !== false, negativo: !!p.venta_negativo, activo: p.activo !== false, visible_catalogo: !!p.visible_catalogo, descripcion_publica: p.descripcion_publica || '', destacado: !!p.destacado, agotado: !!p.agotado,
          imagen: p.imagen_nombre ? `/api/productos/${p.id}/imagen?v=${Date.now()}` : '',
          variantes: !!ex.variantes, contenido: ex.contenido || null, contenido_unidad: ex.contenido_unidad || 'ml', impresora_id: ex.impresora_id || '', modificadores: Array.isArray(ex.modificadores) ? ex.modificadores.slice() : [], tipo_codigo: ex.tipo_codigo || 'Interno', precios: ex.listas || [], componentes: ex.componentes || [], campos: ex.campos || [], cuentas: ex.cuentas || this.vacio().cuentas };
        this.f.oi = this.oiDesde(p.otro_impuesto);
        this.f.existencia_minima = p.existencia_minima ?? null; this.f.existencia_maxima = p.existencia_maxima ?? null;   // 3.87
        this.codigoOriginal = p.codigo || ''; this.alternos = alternosDe(p); this.alternosTocados = false; this.conservarAnterior = false;   // 4.24
        this.recalcTotal();
        if (!this.esServicio && this.f.inventariable) await this.cargarInventario();
      } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    // precio final de una unidad: precio + otro impuesto + IVA sobre (precio + la parte del otro impuesto que va en la base) (3.41)
    totalCon(p) { const oi = otroImpLinea(this.oiBody, 1, p); return p + oi.monto + (p + oi.base) * this.pct / 100; },
    oiDesde(v) {
      const o = otroImp(v), x = OI_VACIO(); if (!o) return x;
      x.tipo = o.codigo === '05' && o.jabon ? '05j' : o.codigo;
      if (o.codigo === '02') { x.modo = o.monto_unidad !== undefined && o.monto_unidad !== null ? 'monto' : 'porcentaje'; x.tarifa = o.tarifa ?? null; x.monto_unidad = o.monto_unidad ?? null; }
      for (const k of ['cantidad_unidad', 'porcentaje', 'volumen_unidad', 'impuesto_unidad']) if (o[k] !== undefined) x[k] = o[k];
      return x;
    },
    recalcTotal() { this.f.total = +this.totalCon(+this.f.precio || 0).toFixed(2); },
    // el total es lineal en el precio: precio = (total − t(0)) / (t(1) − t(0))
    recalcBase() { const t0 = this.totalCon(0), a = this.totalCon(1) - t0; this.f.precio = a > 0 ? +Math.max(0, ((+this.f.total || 0) - t0) / a).toFixed(5) : 0; },   // 5 decimales (R281)   // 5 decimales (Hacienda los admite): el total digitado se respeta (R281)
    imagen(ev) { const file = ev.target.files?.[0] || ev.dataTransfer?.files?.[0]; if (!file) return; if (file.size > 400000) return toast('La imagen debe pesar menos de 400 KB', 'err'); const r = new FileReader(); r.onload = () => this.f.imagen = r.result; r.readAsDataURL(file); },
    async buscarCabys() {
      if (!this.cabysQ.trim()) return;
      this.buscandoCabys = true;
      try { this.cabysRes = await api('/api/hacienda/cabys?q=' + encodeURIComponent(this.cabysQ)); if (!this.cabysRes.length) toast('Sin resultados en el catálogo CABYS'); } catch (e) { toast(e.message, 'err'); }
      this.buscandoCabys = false;
    },
    elegirCabys(c) { this.f.cabys = c.codigo; this.cabysInfo = { ok: true, texto: `${c.descripcion} · IVA ${c.impuesto} %` }; const t = Number(c.impuesto) === 0 ? ['10'] : Object.entries(CAT.tarifaPct).find(([k, v]) => v === Number(c.impuesto) && k !== '10' && k !== '11' && k !== '01'); if (t) { this.f.codigo_tarifa = t[0]; this.recalcTotal(); } else toast('El catálogo no indica la tarifa de IVA de este código: elija la tarifa a mano', 'err'); this.cabysModal = false; },
    // Permite escribir el código directamente: al completar 13 dígitos se valida contra el catálogo oficial
    async validarCabys() {
      const c = (this.f.cabys || '').replace(/\D/g, ''); this.f.cabys = c;
      if (c.length < 13) { this.cabysInfo = c.length ? { ok: null, texto: `${c.length}/13 dígitos` } : null; return; }
      try { const d = await api('/api/cabys/' + c); this.elegirCabys(d); }
      catch { this.cabysInfo = { ok: false, texto: 'Este código no existe en el catálogo oficial CABYS' }; }
    },
    // 4.24: «Generar» pone el código de barras propio del producto (sale de su número, por eso no se repite). En un ítem nuevo se genera al guardar, cuando ya tiene número.
    generarCodigo() {
      if (!this.editando) { this.generarAlGuardar = !this.generarAlGuardar; if (this.generarAlGuardar) this.f.codigo = ''; return; }
      if (esCodigoPropio(this.f.codigo, this.params.id)) return toast('Este ítem ya tiene su código generado', 'ok');
      const propio = codigoBarrasPropio(this.params.id, marcaDe(store.empresa));   // lleva la marca de la empresa (3 dígitos que salen de su cédula y de su código de sucursal); sin ella no se supone un código
      if (!propio) return toast('No se pudo generar el código porque faltan los datos de la empresa: actualice la página e intente de nuevo', 'err');
      this.f.codigo = propio; this.conservarAnterior = !!this.codigoOriginal.trim();
      toast('Código generado. Guarde el ítem para aplicarlo' + (this.conservarAnterior ? '; el código anterior queda como código alterno' : ''), 'ok');
    },
    quitarAlterno(a) { this.alternos = this.alternos.filter(x => x !== a); this.alternosTocados = true; },
    agregarCampo() { const d = this.camposDef.find(c => c.nombre === this.campoSel); if (!d) return; if (this.f.campos.some(c => c.campo === d.nombre)) return toast('El campo ya fue agregado'); this.f.campos.push({ campo: d.nombre, tipo: d.tipo, valor: d.valor_defecto || '' }); this.campoSel = ''; },
    agregarBodega() { const usadas = this.f.porBodega.map(b => b.bodega_id); const libre = this.bodegas.find(b => !usadas.includes(b.id)); this.f.porBodega.push({ bodega_id: libre?.id || null, cantidad: 0 }); },
    async guardar(otro = false) {
      if (this.guardando) return;   // un segundo clic no crea otro producto (R41)
      const f = this.f;
      if (!f.nombre) return toast('El nombre es obligatorio', 'err');
      if (!f.cabys && f.es_venta !== false && sesion.electronica) return toast('El código CABYS es obligatorio en un ítem que se vende', 'err');   /* 3.93: opcional sin facturación electrónica */
      if (this.esCombo && !f.componentes.length) return toast('Agregue al menos un producto al ' + f.tipo.toLowerCase(), 'err');
      const cantMin = v => (v === '' || v === null || v === undefined || isNaN(+v) ? null : +v);   // 3.87: vacío = sin mínimo
      if (cantMin(f.existencia_minima) !== null && cantMin(f.existencia_maxima) !== null && cantMin(f.existencia_maxima) < cantMin(f.existencia_minima)) return toast('La existencia máxima no puede ser menor que la mínima', 'err');
      this.guardando = true;
      try {
        // Al crear: la primera bodega con cantidad va como existencia inicial del producto; el resto se registra como ajustes de incremento
        const inventariable = !this.esServicio && !this.esCombo && !!f.inventariable;   // combos y surtidos no controlan inventario (R116)
        const porBodega = {};
        if (inventariable && !this.editando) for (const b of f.porBodega) if (b.bodega_id && +b.cantidad > 0) porBodega[b.bodega_id] = (porBodega[b.bodega_id] || 0) + +b.cantidad;
        const entradas = Object.entries(porBodega);
        const [primera, ...resto] = entradas;
        const body = { codigo: f.codigo || null, nombre: f.nombre, cabys: f.cabys, precio: +f.precio || 0, moneda: f.moneda || monedas.principal().codigo, unidad_medida: f.unidad_medida, es_servicio: this.esServicio, codigo_tarifa: f.codigo_tarifa, tarifa: this.pct, otro_impuesto: this.oiBody,
          tipo: f.tipo, descripcion: f.descripcion || null, categoria: f.categoria || null, costo: +this.costo || 0, inventariable, venta_negativo: !!f.negativo,
          partida_arancelaria: f.partida || null, activo: f.activo !== false, es_venta: f.es_venta !== false,
          visible_catalogo: !!f.visible_catalogo && f.es_venta !== false, descripcion_publica: (f.descripcion_publica || '').trim() || null, destacado: !!f.destacado, agotado: !!f.agotado,   /* catálogo en línea (3.47) */
          cantidad_inicial: primera ? primera[1] : null, bodega_id: primera ? +primera[0] : null };
        body.existencia_minima = inventariable ? cantMin(f.existencia_minima) : null; body.existencia_maxima = inventariable ? cantMin(f.existencia_maxima) : null;   // 3.87
        if (this.editando) { if (this.alternosTocados) body.codigos_alternos = this.alternos; if (this.conservarAnterior && this.codigoCambiado) body.conservar_codigo_anterior = true; }   // 4.24
        const p = this.editando ? await api('/api/productos/' + this.params.id, { method: 'PUT', body }) : await api('/api/productos', { method: 'POST', body });
        if (!this.editando && this.generarAlGuardar) {   // 4.24: ítem nuevo con «Generar»: ya tiene número, ya se le puede poner su código
          try { const g = await api('/api/productos/codigos/generar', { method: 'POST', body: { ids: [p.id] } }); if (g.codigos && g.codigos[p.id]) p.codigo = g.codigos[p.id]; else if ((g.no_se_pudo || []).length) toast('Ítem guardado sin código: ' + g.no_se_pudo[0].motivo, 'err'); }
          catch (e) { toast('Ítem guardado, pero el código no se pudo generar: ' + e.message, 'err'); }
        }
        for (const [bid, cantidad] of resto) {
          try { await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: +bid, fecha: hoy(), observaciones: 'Inventario inicial', lineas: [{ producto_id: p.id, tipo: 'incremento', cantidad, costo_unitario: +this.costo || 0 }] } }); }
          catch (e) { toast('No se pudo registrar la existencia inicial en ' + (this.nombreBodega[bid] || 'la bodega ' + bid) + ': ' + e.message, 'err'); }
        }
        if (f.imagen && f.imagen.startsWith('data:')) {
          // dataURL → Blob sin fetch (connect-src 'self' lo bloqueaba y el producto quedaba creado sin imagen; otro clic lo duplicaba) (R41)
          try {
            const [meta, b64] = f.imagen.split(','); const mime = (meta.match(/data:([^;]+)/) || [])[1] || 'image/png';
            const bin = atob(b64); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
            const blob = new Blob([arr], { type: mime }); const fd = new FormData(); fd.append('archivo', blob, 'imagen.' + (mime.split('/')[1] || 'png'));
            await api(`/api/productos/${p.id}/imagen`, { method: 'POST', body: fd });
          } catch (e) { toast('Producto guardado, pero la imagen no se pudo subir: ' + e.message, 'err'); }
        } else if (this.editando && !f.imagen && !this.deLaWeb) { try { await api(`/api/productos/${p.id}/imagen`, { method: 'DELETE' }); } catch {} }   // 9c (J6): la imagen de un ítem de la web se cambia allá
        const dato = { modificadores: (f.modificadores || []).map(Number), variantes: f.variantes, tipo_codigo: f.tipo_codigo, listas: f.precios, componentes: f.componentes, campos: f.campos, cuentas: f.cuentas, contenido: +f.contenido > 0 ? +f.contenido : null, contenido_unidad: f.contenido_unidad || 'ml', impresora_id: f.impresora_id || '' };
        this.extra = mock.actualizar('items_extra', x => { x[p.id] = { ...(x[p.id] || {}), ...dato }; }, {});   // 4.30: conserva lo que esta ficha no edita (lo de otras pantallas)
        store.poner('productos', p);      // (R263)
        toast(f.tipo + (this.editando ? ' actualizado' : ' creado'), 'ok');
        if (otro) { this.f = this.vacio(); this.generarAlGuardar = false; await this.cargarBodegas(); this.recalcTotal(); window.scrollTo(0, 0); } else location.hash = '/inventario/items';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    api('/api/ia/config').then(c => { this.iaOk = !!(c && c.disponible && c.activo && c.productos); }).catch(() => { this.iaOk = false; });
    await this.cargarBodegas();
    if (this.editando) this.cargar();
    else if (this.params.duplicar) this.cargarCopia(+this.params.duplicar);
    else { if (this.esServicio) this.f.inventariable = false; this.recalcTotal(); }
  },
  template: `
  <div class="page">
    <PageHead :title="editando?'Editar ítem':'Nuevo producto'" sub="Complete la información general, de inventario, fiscal y contable del ítem." :crumbs="[{label:'Ítems',to:'/inventario/items'},{label:editando?f.nombre||'Editar':'Nuevo'}]">
      <a class="btn sec" v-if="editando" :href="'#/inventario/items/nuevo?duplicar=' + params.id" title="Crear otro ítem con los mismos precios, impuestos y opciones">Duplicar</a></PageHead>
    <p class="small muted" v-if="deLaWeb" style="margin:-6px 0 12px">Este ítem se creó en la página web: sus cambios se guardan allá en el momento (hace falta internet).</p>
    <div class="alert info" v-if="duplicadoDe" style="margin-bottom:12px">Copia de <b>{{duplicadoDe}}</b>: cambie el nombre y revise precio y código antes de guardar. Las existencias no se copian.</div>
    <div class="alert info" v-if="cargando">Cargando ítem…</div>
    <div style="display:grid;grid-template-columns:minmax(0,1fr) 280px;gap:18px;align-items:start" v-else>
      <div>
        <div class="card"><h2>Información general</h2>
          <div class="grid">
            <Field label="Tipo de ítem" req help="No editable después de crear"><select v-model="f.tipo" :disabled="editando"><option v-for="t in ['Producto','Servicio','Combo','Surtido']">{{t}}</option></select></Field>
            <div class="alert info" v-if="esCombo" style="grid-column:1/-1">Los combos y surtidos se facturan como un solo ítem y no controlan inventario por componentes todavía.</div>
            <Field label="Variantes" v-if="f.tipo==='Producto'"><label class="row" style="height:36px"><input type="checkbox" v-model="f.variantes"> Producto con variantes</label></Field>
            <Field label="Nombre" req><input v-model="f.nombre"></Field>
            <Field label="Bodega" req v-if="!esServicio && !editando" help="Donde se registra la cantidad inicial"><Buscador v-model="f.porBodega[0].bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
            <Field label="Categoría"><Buscador v-model="f.categoria" :opciones="categorias" valor="nombre" placeholder="Sin categoría (escriba para buscar)" agregar="categoria"></Buscador></Field>
            <Field label="Unidad de medida" req><select v-model="f.unidad_medida"><option v-for="u in CAT.unidades" :key="u" :value="u">{{u}}{{CAT.unidadesNombre[u] ? ' · ' + CAT.unidadesNombre[u] : ''}}</option></select></Field>
            <Field label="Código" help="Es el código de barras del ítem: léalo con el lector, escríbalo o genere uno. Máximo 20 caracteres (va en la factura) y no puede repetirse en otro ítem"><div class="row" style="gap:6px"><input class="mono" v-model="f.codigo" maxlength="20" :placeholder="generarAlGuardar ? 'Se genera al guardar' : 'Léalo con el lector o escríbalo'" :disabled="generarAlGuardar" style="flex:1" @keydown.enter.prevent><button type="button" class="btn sec sm" @click.prevent="generarCodigo" :title="editando ? 'Pone el código de barras propio de este ítem (sale de su número: no se repite)' : 'El código de barras se genera al guardar el ítem'">{{generarAlGuardar ? 'No generar' : 'Generar'}}</button></div></Field>
            <Field label="Tipo de código"><select v-model="f.tipo_codigo"><option>Interno</option><option>Código de barras (EAN)</option><option>SKU</option></select></Field>
            <div style="grid-column:1/-1" v-if="editando && (alternos.length || codigoCambiado)">
              <div class="row small" v-if="codigoCambiado" style="gap:6px;margin-bottom:6px"><input type="checkbox" id="item-conservar-codigo" v-model="conservarAnterior"><label for="item-conservar-codigo" style="cursor:pointer">Conservar el código anterior <b class="mono">{{codigoOriginal}}</b> como código alterno: la caja lo sigue reconociendo (útil si ya hay etiquetas pegadas)</label></div>
              <div class="small" v-if="alternos.length"><span class="muted">Códigos alternos (la caja también vende este ítem al leerlos): </span><span v-for="a in alternos" :key="a" class="chip mono" style="margin:0 6px 4px 0;cursor:default">{{a}}<button type="button" class="btn icon" style="padding:0 4px;min-width:0;height:auto" title="Quitar este código alterno (se aplica al guardar)" @click.prevent="quitarAlterno(a)">×</button></span></div>
            </div>
            <Field label="Descripción" style="grid-column:1/-1"><textarea rows="2" v-model="f.descripcion"></textarea></Field>
          </div>
        </div>
        <div class="card"><h2>Inventario y precio</h2>
          <div class="grid">
            <template v-if="f.tipo==='Producto'">
              <Field label="Cantidad inicial" req v-if="!editando"><input type="number" min="0" v-model.number="f.porBodega[0].cantidad" :disabled="!f.inventariable"></Field>
              <Field label="Existencias actuales" v-else help="Se modifican desde Ajustes de inventario"><input :value="f.inventariable ? fmtCant(cantidadTotal) : '—'" disabled></Field>
              <Field label="Costo por unidad" req help="Costo de referencia; el costo promedio real se calcula con los movimientos"><input type="number" min="0" step="0.01" v-model.number="f.costo"></Field>
              <Field label="Existencia mínima" help="Al llegar aquí el ítem sale en Inventario › Por reponer y en el Inicio. No cambia lo que se ve en el catálogo en línea. Vacío = sin aviso"><input type="number" min="0" step="any" v-model="f.existencia_minima" :disabled="!f.inventariable" placeholder="Sin mínimo"></Field>
              <Field label="Existencia máxima" help="Hasta dónde se sugiere reponer; vacío = el doble del mínimo"><input type="number" min="0" step="any" v-model="f.existencia_maxima" :disabled="!f.inventariable" placeholder="Opcional"></Field>
            </template>
            <Field label="Costo del combo" v-if="esCombo"><input :value="money(costoCombo)" disabled></Field>
            <template v-if="f.tipo!=='Surtido'">
              <Field label="Precio base" req><input type="number" min="0" step="0.01" v-model.number="f.precio" @input="recalcTotal"></Field>
              <Field label="Moneda del precio" help="Un ítem en dólares se convierte solo al facturar o cobrar en colones; el costo va siempre en la moneda principal"><select v-model="f.moneda"><option v-for="o in monedasOpc" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
              <Field label="IVA"><select v-model="f.codigo_tarifa" @change="recalcTotal"><option v-for="o in CAT.tarifaIvaLista" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
              <Field label="Precio total" req><input type="number" min="0" step="0.01" v-model.number="f.total" @input="recalcBase"></Field>
              <Field label="Margen" help="Ganancia sobre el precio de venta sin IVA"><input :value="rentabilidad.margen === null ? '—' : rentabilidad.margen.toFixed(2) + ' %'" disabled :style="rentabilidad.margen !== null && rentabilidad.margen < 0 ? 'color:var(--danger)' : ''"></Field>
              <Field label="Markup" help="Ganancia sobre el costo"><input :value="rentabilidad.markup === null ? '—' : rentabilidad.markup.toFixed(2) + ' %'" disabled :style="rentabilidad.markup !== null && rentabilidad.markup < 0 ? 'color:var(--danger)' : ''"></Field>
              <Field label="Ganancia por unidad" :help="rentabilidad.convertido ? 'Precio convertido a la moneda del costo con el tipo de cambio del día' : 'Precio sin IVA menos el costo'"><input :value="costo > 0 ? money(rentabilidad.ganancia) : '—'" disabled></Field>
            </template>
          </div>
        </div>
        <div class="card" v-if="f.tipo!=='Servicio' || f.oi.tipo"><h2>Otro impuesto <small>Selectivo de Consumo e impuestos específicos (solo si el ítem los lleva)</small></h2>
          <div class="grid cols-3">
            <Field label="Impuesto adicional" help="Además del IVA. Lo cobran sobre todo fabricantes e importadores"><select v-model="f.oi.tipo" @change="recalcTotal"><option v-for="t in OTRO_TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
            <template v-if="f.oi.tipo==='02'">
              <Field label="Se calcula por"><select v-model="f.oi.modo" @change="recalcTotal"><option value="porcentaje">Porcentaje del precio</option><option value="monto">Monto por unidad</option></select></Field>
              <Field v-if="f.oi.modo==='porcentaje'" label="Tarifa del Selectivo (%)" help="La que fija la ley para este producto"><input type="number" min="0" max="99.99" step="0.01" v-model.number="f.oi.tarifa" @input="recalcTotal"></Field>
              <Field v-else label="Monto por unidad" help="En la moneda del documento"><input type="number" min="0" step="0.00001" v-model.number="f.oi.monto_unidad" @input="recalcTotal"></Field>
            </template>
            <template v-if="f.oi.tipo==='04'">
              <Field label="Mililitros del envase"><input type="number" min="0" step="0.01" v-model.number="f.oi.cantidad_unidad" @input="recalcTotal" placeholder="750"></Field>
              <Field label="Alcohol por volumen (%)"><input type="number" min="0" max="99.99" step="0.01" v-model.number="f.oi.porcentaje" @input="recalcTotal" placeholder="40"></Field>
              <Field label="Impuesto por mililitro de alcohol absoluto" help="El monto vigente que publica Hacienda"><input type="number" min="0" step="0.00001" v-model.number="f.oi.impuesto_unidad" @input="recalcTotal"></Field>
            </template>
            <template v-if="f.oi.tipo==='05'">
              <Field label="Mililitros del envase"><input type="number" min="0" step="0.01" v-model.number="f.oi.cantidad_unidad" @input="recalcTotal" placeholder="355"></Field>
              <Field label="Volumen de referencia (ml)" help="El volumen sobre el que Hacienda fija el impuesto"><input type="number" min="0" step="0.01" v-model.number="f.oi.volumen_unidad" @input="recalcTotal"></Field>
              <Field label="Impuesto por volumen de referencia"><input type="number" min="0" step="0.00001" v-model.number="f.oi.impuesto_unidad" @input="recalcTotal"></Field>
            </template>
            <template v-if="f.oi.tipo==='05j'">
              <Field label="Gramos del jabón"><input type="number" min="0" step="0.01" v-model.number="f.oi.volumen_unidad" @input="recalcTotal" placeholder="100"></Field>
              <Field label="Impuesto por gramo"><input type="number" min="0" step="0.00001" v-model.number="f.oi.impuesto_unidad" @input="recalcTotal"></Field>
            </template>
            <template v-if="f.oi.tipo==='06'">
              <Field label="Unidades por paquete" placeholder="20"><input type="number" min="0" step="0.01" v-model.number="f.oi.cantidad_unidad" @input="recalcTotal" placeholder="20"></Field>
              <Field label="Impuesto por unidad"><input type="number" min="0" step="0.00001" v-model.number="f.oi.impuesto_unidad" @input="recalcTotal"></Field>
            </template>
            <template v-if="f.oi.tipo==='03'">
              <Field label="Litros por unidad vendida" help="1 si se vende por litro"><input type="number" min="0" step="0.01" v-model.number="f.oi.cantidad_unidad" @input="recalcTotal" placeholder="1"></Field>
              <Field label="Impuesto por litro"><input type="number" min="0" step="0.00001" v-model.number="f.oi.impuesto_unidad" @input="recalcTotal"></Field>
            </template>
          </div>
          <p class="small muted" style="margin:6px 0 0" v-if="f.oi.tipo">Por cada unidad: <b>{{money(oiUnidad, f.moneda)}}</b> de {{OTRO_TIPOS.find(t => t[0] === f.oi.tipo)[1].toLowerCase()}}{{['02','04','05','05j','12'].includes(f.oi.tipo) ? ', y el IVA se calcula sobre el precio más este impuesto' : ''}}. El «Precio total» ya lo incluye.</p>
        </div>
        <div class="card"><h2>Información fiscal</h2>
          <div class="grid cols-2">
            <Field label="Partida arancelaria" help="Solo mercancías exportadas: 12 dígitos (va en la factura de exportación)"><input class="mono" v-model="f.partida" maxlength="20" placeholder="12 dígitos, p. ej. 8471.30.00.00.00"></Field>
            <Field label="Código de producto o servicio (CABYS)" :req="sesion.electronica" :help="sesion.electronica ? null : 'Opcional: la facturación electrónica está apagada'"><div class="row" style="gap:6px"><input class="mono" v-model="f.cabys" maxlength="13" placeholder="Escriba los 13 dígitos" @input="validarCabys" style="flex:1"><button class="btn sec sm" @click="cabysModal=true">Buscar por descripción</button></div>
              <span class="help" v-if="cabysInfo" :style="{color: cabysInfo.ok===true?'var(--ok)':cabysInfo.ok===false?'var(--danger)':''}">{{cabysInfo.texto}}</span></Field>
          </div>
        </div>
        <div class="card"><h2>Opciones avanzadas</h2>
          <div class="grid cols-2" style="margin-bottom:10px">
            <Field label="Contenido por unidad (para recetas)" v-if="!esServicio && f.inventariable" help="Si se inventaría por unidad: cuánto trae cada una (botella de 750 ml, saco de 25 000 g). Con Kg, G, L o mL no hace falta"><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="f.contenido" style="flex:1" placeholder="750"><select v-model="f.contenido_unidad" style="width:90px"><option value="ml">ml</option><option value="g">g</option></select></div></Field>
            <Field label="Modificadores (tamaño, extras…)" help="Grupos de opciones que se preguntan al pedirlo en la caja y en el catálogo en línea; se crean en Punto de venta › Configuración › Modificadores" v-if="gruposMod.length"><select multiple v-model="f.modificadores" style="height:76px"><option v-for="g in gruposMod" :key="g.id" :value="g.id">{{g.nombre}}{{g.minimo ? " (obligatorio)" : ""}}</option></select></Field>
            <Field label="Impresora de comanda" help="Dónde sale este plato o bebida al enviar la comanda; vacío = según su categoría"><select v-model="f.impresora_id"><option value="">— Según la categoría —</option><option value="none">Sin comanda</option><option v-for="i in impresorasComanda" :key="i.id" :value="String(i.id)">{{i.nombre}}</option></select></Field>
          </div>
          <template v-if="!esServicio && f.inventariable">
            <h2 style="font-size:14px">Detalle de inventario por bodega</h2>
            <template v-if="!editando">
              <table class="tbl"><thead><tr><th>Bodega</th><th class="num" style="width:160px">Cantidad inicial</th><th></th></tr></thead>
                <tbody><tr v-for="(b,i) in f.porBodega" :key="i"><td><select class="inp" v-model="b.bodega_id"><option v-for="x in bodegas" :key="x.id" :value="x.id">{{x.nombre}}</option></select></td><td><input class="inp" type="number" min="0" v-model.number="b.cantidad" style="width:100%;text-align:right"></td><td><button class="btn icon" @click="f.porBodega.splice(i,1)" v-if="i>0">✕</button></td></tr></tbody></table>
              <div class="row" style="margin:8px 0 18px"><button class="btn sec sm" @click="agregarBodega" :disabled="f.porBodega.length>=bodegas.length">+ Agregar bodega</button><span class="small muted">Total: {{fmtCant(cantidadTotal)}}</span></div>
            </template>
            <template v-else>
              <table class="tbl" v-if="existencias.length"><thead><tr><th>Bodega</th><th class="num">Cantidad</th><th class="num">Costo promedio</th><th class="num">Valor</th></tr></thead>
                <tbody><tr v-for="b in existencias" :key="b.bodega_id"><td>{{b.bodega}}</td><td class="num">{{fmtCant(b.cantidad)}}</td><td class="num">{{money(b.costo_promedio)}}</td><td class="num">{{money(b.cantidad*b.costo_promedio)}}</td></tr></tbody></table>
              <p class="muted small" v-else>Este ítem no tiene existencias registradas en ninguna bodega.</p>
              <div class="row" style="margin:8px 0 18px"><a class="btn sec sm" href="#/inventario/ajustes/nuevo">Registrar ajuste de inventario</a><span class="small muted">Total: {{fmtCant(cantidadTotal)}} · Las existencias se modifican con ajustes o transferencias, no desde este formulario.</span></div>
            </template>
          </template>
          <h2 style="font-size:14px">Listas de precios <small>Precio de este ítem en cada lista: lo usan la caja, las facturas y el catálogo de revendedoras</small></h2>
          <table class="tbl" v-if="f.precios.length"><thead><tr><th>Lista</th><th class="num" style="width:160px">Valor</th><th></th></tr></thead>
            <tbody><tr v-for="(l,i) in f.precios" :key="i"><td><select class="inp" v-model.number="l.lista_id"><option v-for="x in listas.filter(x=>!x.principal)" :value="x.id">{{x.nombre}} ({{x.tipo}}{{x.moneda && x.moneda !== 'CRC' ? ', ' + x.moneda : ''}})</option></select></td><td><input class="inp" type="number" step="0.01" v-model.number="l.valor" style="width:100%;text-align:right"></td><td><button class="btn icon" @click="f.precios.splice(i,1)">✕</button></td></tr></tbody></table>
          <div class="row" style="margin:8px 0 18px"><button class="btn sec sm" @click="f.precios.push({lista_id:null,valor:0})">+ Agregar lista</button><span class="small muted" v-if="listas.length<2">Cree listas adicionales en Inventario › Listas de precios.</span></div>
          <template v-if="esCombo">
            <h2 style="font-size:14px">Productos del {{f.tipo.toLowerCase()}}</h2>
            <table class="tbl"><thead><tr><th>Producto</th><th class="num" style="width:140px">Cantidad</th><th class="num">Costo</th><th></th></tr></thead>
              <tbody><tr v-for="(c,i) in f.componentes" :key="i"><td><Buscador v-model="c.producto_id" :opciones="store.productos.filter(p=>p.id!=params.id)" :etiqueta="p => (p.codigo ? p.codigo + ' · ' : '') + p.nombre" agregar="ítem"></Buscador></td><td><input class="inp" type="number" min="0" step="0.01" v-model.number="c.cantidad" style="width:100%;text-align:right"></td><td class="num">{{money((+c.cantidad||0)*(store.productos.find(p=>p.id==c.producto_id)?.costo||0))}}</td><td><button class="btn icon" @click="f.componentes.splice(i,1)">✕</button></td></tr></tbody></table>
            <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="f.componentes.push({producto_id:null,cantidad:1})">+ Agregar producto</button><span class="small muted">Costo total: <b>{{money(costoCombo)}}</b></span></div>
          </template>
        </div>
        <div class="card" v-if="editando && !esServicio && f.inventariable"><h2>Movimientos recientes <small>Últimos 20 movimientos de inventario</small></h2>
          <div class="table-wrap" v-if="movimientos.length"><table class="tbl">
            <thead><tr><th>Fecha</th><th>Tipo</th><th>Bodega</th><th>Referencia</th><th class="num">Cantidad</th><th class="num">Costo unitario</th><th class="num">Existencia</th></tr></thead>
            <tbody><tr v-for="m in movimientos" :key="m.id"><td>{{fecha(m.fecha)}}</td><td><Badge :value="TIPO_MOV[m.tipo]||m.tipo"></Badge></td><td>{{m.bodega||'—'}}</td><td class="mono">{{m.referencia||'—'}}</td><td class="num" :style="m.cantidad<0?'color:var(--danger)':''">{{m.cantidad>0?'+':''}}{{fmtCant(m.cantidad)}}</td><td class="num">{{money(m.costo_unitario)}}</td><td class="num">{{fmtCant(m.existencia_resultante)}}</td></tr></tbody>
          </table></div>
          <p class="muted small" v-else>Aún no hay movimientos registrados para este ítem.</p>
        </div>
        <div class="card" v-if="editando && capas"><h2>Capas de costo <small>{{capas.metodo === 'ueps' ? 'UEPS: salen primero las más recientes' : 'PEPS: salen primero las más antiguas'}}</small></h2>
          <div class="table-wrap" v-if="capas.capas.length"><table class="tbl">
            <thead><tr><th>Entrada</th><th>Bodega</th><th>Referencia</th><th class="num">Entró</th><th class="num">Queda</th><th class="num">Costo unitario</th><th class="num">Valor</th></tr></thead>
            <tbody><tr v-for="k in capas.capas" :key="k.id"><td>{{k.base ? 'Existencia anterior' : fecha(k.fecha)}}</td><td>{{k.bodega||'—'}}</td><td class="mono">{{k.referencia||'—'}}</td><td class="num">{{fmtCant(k.cantidad_inicial)}}</td><td class="num">{{fmtCant(k.cantidad)}}</td><td class="num">{{money(k.costo_unitario)}}</td><td class="num">{{money(k.total)}}</td></tr></tbody>
            <tfoot><tr><td colspan="4"></td><td class="num"><b>{{fmtCant(capas.cantidad)}}</b></td><td></td><td class="num"><b>{{money(capas.valor)}}</b></td></tr></tfoot>
          </table></div>
          <p class="muted small" v-else>Sin capas con existencia: las entradas con costo (compras, ajustes de incremento) abren capas.</p>
        </div>
        <div class="card"><h2>Campos adicionales</h2>
          <div class="row"><select class="inp" v-model="campoSel"><option value="">— Seleccionar campo —</option><option v-for="c in camposDef" :value="c.nombre">{{c.nombre}} ({{c.tipo}})</option></select><button class="btn sec sm" @click="agregarCampo" :disabled="!campoSel">Agregar</button><span class="small muted" v-if="!camposDef.length">Defina campos en Inventario › Atributos › Campos adicionales.</span></div>
          <div class="grid" style="margin-top:12px" v-if="f.campos.length">
            <Field v-for="(c,i) in f.campos" :key="i" :label="c.campo"><div class="row" style="gap:6px"><input :type="c.tipo==='Número'?'number':c.tipo==='Fecha'?'date':'text'" v-model="c.valor" style="flex:1"><button class="btn icon" @click="f.campos.splice(i,1)">✕</button></div></Field>
          </div>
        </div>
        <div class="card"><h2>Configuración contable</h2>
          <div class="grid cols-3">
            <Field label="Cuenta contable (ventas)"><select v-model="f.cuentas.ventas"><option v-for="c in CUENTAS.ventas">{{c}}</option></select></Field>
            <template v-if="f.tipo==='Producto'">
              <Field label="Cuenta para inventario"><select v-model="f.cuentas.inventario"><option v-for="c in CUENTAS.inventario">{{c}}</option></select></Field>
              <Field label="Cuenta de costo de venta"><select v-model="f.cuentas.costo"><option v-for="c in CUENTAS.costo">{{c}}</option></select></Field>
            </template>
          </div>
        </div>
      </div>
      <div class="card" style="position:sticky;top:16px">
        <label class="drop" style="display:block;padding:0;overflow:hidden" @dragover.prevent @drop.prevent="imagen">
          <img v-if="f.imagen" :src="f.imagen" style="width:100%;max-height:180px;object-fit:contain;display:block">
          <div v-else style="padding:22px">📷<br>Arrastre una imagen o haga clic para seleccionarla</div>
          <input type="file" accept="image/png,image/jpeg,image/webp" style="display:none" @change="imagen">
        </label>
        <button class="btn ghost sm" style="margin-top:6px" v-if="f.imagen" @click="f.imagen=''">Quitar imagen</button>
        <div class="totals" style="align-items:stretch;margin-top:14px">
          <div><span>Costo</span><b>{{money(costo)}}</b></div>
          <div><span>Precio de venta</span><b>{{money(f.precio, f.moneda)}}</b></div>
          <div v-if="rentabilidad.margen !== null"><span>Margen</span><b>{{rentabilidad.margen.toFixed(2)}} %</b></div>
          <div v-if="rentabilidad.markup !== null"><span>Markup</span><b>{{rentabilidad.markup.toFixed(2)}} %</b></div>
          <div class="total"><span>Precio total</span><b>{{money(f.total, f.moneda)}}</b></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin:16px 0">
          <template v-if="!esServicio">
            <Toggle v-model="f.es_venta" label="Se vende (aparece en la caja y en las facturas)"></Toggle>
            <p class="small muted" style="margin:-4px 0 8px" v-if="!f.es_venta">Apagado: es un insumo o materia prima (arroz, pollo, botella de vino). No necesita CABYS ni precio; se compra, se inventaría y se consume por recetas.</p>
            <Toggle v-model="f.inventariable" label="Inventariable"></Toggle>
            <Toggle v-model="f.negativo" label="Venta en negativo"></Toggle>
          </template>
          <template v-if="f.es_venta !== false && sesion.tieneModulo('pedidos_online')">
            <Toggle v-model="f.visible_catalogo" label="Visible en el catálogo en línea (pedidos por internet)"></Toggle>
            <template v-if="f.visible_catalogo">
              <Field label="Descripción pública" help="Lo que lee el cliente en el catálogo; vacío = la descripción del ítem"><textarea rows="2" v-model="f.descripcion_publica" maxlength="300" placeholder="Con ensalada, plátano maduro y frijoles."></textarea>
                <button class="btn sm ghost" style="margin-top:4px" @click="redactarIA" :disabled="iaCargando" v-if="iaOk">{{iaCargando ? 'Redactando…' : '✨ Redactar con IA'}}</button></Field>
              <Toggle v-model="f.destacado" label="Destacado (sale de primero en el catálogo)"></Toggle>
              <Toggle v-model="f.agotado" label="Agotado por ahora (se ve, pero no se puede pedir aunque haya existencias)"></Toggle>
            </template>
          </template>
          <Toggle v-model="f.activo" label="Activo" v-if="editando"></Toggle>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn" @click="guardar(false)" :disabled="guardando">{{guardando?'Guardando…':'Guardar'}}</button>
          <button class="btn sec" @click="guardar(true)" :disabled="guardando" v-if="!editando">Guardar y crear otro</button>
          <a class="btn ghost" href="#/inventario/items">Cancelar</a>
        </div>
      </div>
    </div>

    <Modal v-if="cabysModal" title="Buscar código CABYS" lg @close="cabysModal=false">
      <div class="toolbar"><input class="search" v-model="cabysQ" placeholder="Describa el producto o servicio" @keyup.enter="buscarCabys" style="flex:1"><button class="btn" @click="buscarCabys" :disabled="buscandoCabys">{{buscandoCabys?'Buscando…':'Buscar'}}</button></div>
      <table class="tbl" v-if="cabysRes.length"><thead><tr><th>Código</th><th>Descripción</th><th class="num">IVA</th><th></th></tr></thead>
        <tbody><tr v-for="c in cabysRes" :key="c.codigo"><td class="mono">{{c.codigo}}</td><td style="white-space:normal">{{c.descripcion}}</td><td class="num">{{c.impuesto}} %</td><td><button class="btn sm sec" @click="elegirCabys(c)">Elegir</button></td></tr></tbody></table>
      <p class="muted small" v-else>Escriba una descripción y presione Buscar. Los resultados provienen del catálogo oficial de Hacienda.</p>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
