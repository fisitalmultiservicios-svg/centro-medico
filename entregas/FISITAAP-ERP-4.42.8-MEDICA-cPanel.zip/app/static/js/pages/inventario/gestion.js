// Inventario — Gestión de ítems: importación y actualización masiva (productos: backend real /api/productos; historial en mock)
import { api, toast, money, mock, CAT, fechaHora, monedas, cabecerasAuth, abrirArchivo } from '../../api.js';
import { store, sesion } from '../../app.js';

// Parte una línea CSV respetando comillas («"Cable UTP, cat 6"» es un solo campo; «""» es una comilla literal).
export function partirCsv(linea, sep) {
  const out = []; let campo = '', dentro = false;
  for (let i = 0; i < linea.length; i++) {
    const ch = linea[i];
    if (ch === '"') { if (dentro && linea[i + 1] === '"') { campo += '"'; i++; } else dentro = !dentro; }
    else if (ch === sep && !dentro) { out.push(campo); campo = ''; }
    else campo += ch;
  }
  out.push(campo);
  return out;
}

// Código de tarifa a partir de la columna «tarifa» del CSV (ver importar()). Devuelve { codigo_tarifa } o { problema }.
// Un valor con «%» es un porcentaje y nunca un código ('8 %' = 8 %, no '08'); sin «%», un dígito es un código sin su cero.
export function leerTarifa(valor) {
  const crudo = String(valor ?? '').trim(), conPct = crudo.includes('%'), t = crudo.replace('%', '').trim();
  if (!t) return { codigo_tarifa: '08', defecto: true };
  if (!conPct && /^\d{2}$/.test(t) && CAT.tarifaPct[t] !== undefined) return { codigo_tarifa: t };
  if (!conPct && /^\d$/.test(t) && CAT.tarifaPct['0' + t] !== undefined) return { codigo_tarifa: '0' + t };
  const pct = parseFloat(t.replace(',', '.'));
  if (isNaN(pct)) return { problema: `tarifa «${valor}» no válida: use el código de IVA (01 exento, 02 1 %, 03 2 %, 04 4 %, 07 8 %, 08 13 %, 09 0,5 %, 10 o 11 0 %)` };
  const cands = Object.entries(CAT.tarifaPct).filter(([, v]) => v === pct).map(([k]) => k);
  if (cands.length === 1) return { codigo_tarifa: cands[0] };
  return { problema: `tarifa «${valor}» ambigua: indique el código (${cands.join(', ')})` };
}

export default {
  props: ['params'],
  data() {
    return {
      tab: 'importar', importando: false, resultado: null, masivo: false, guardando: false, filas: [],
      // importación en el servidor (3.58): Excel (.xlsx) o CSV con vista previa (simulación) antes de guardar
      modo: 'crear', enServidor: true, archivo: null, previa: null, importandoSrv: false,
      historial: mock.get('importaciones', []), actualizaciones: mock.get('actualizaciones', []), extra: mock.get('items_extra', {}), CAT,
    };
  },
  computed: {
    store() { return store; },
    cambios() { return this.filas.filter(f => f.precio !== f._precio || f.nombre !== f._nombre || f.codigo_tarifa !== f._codigo_tarifa); },
  },
  methods: {
    money,
    plantilla() {
      const csv = 'nombre;codigo;cabys;precio;unidad;tipo;tarifa;moneda;categoria;costo;descripcion\nCemento gris 50 kg;CEM-50;3744001009900;9500;Unid;Producto;08;CRC;Construcción;7200;Saco de 50 kg\nConsultoría contable;SERV-01;8222100000000;45000;h;Servicio;08;CRC;Servicios;;\nDisco SSD 1 TB;SSD-1T;4755000000100;89.90;Unid;Producto;08;USD;Computo;62;';   // 3.87: CABYS que existen en el catálogo oficial
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })); a.download = 'plantilla-items.csv'; a.click(); URL.revokeObjectURL(a.href);
    },
    // ---- importación en el servidor (3.58): Excel o CSV, primero se simula y luego se guarda ----
    async plantillaExcel() { try { await abrirArchivo('/api/productos/plantilla.xlsx', 'plantilla-items.xlsx'); } catch (e) { toast(e.message, 'err'); } },
    async enviarServidor(file, simular) {
      const fd = new FormData(); fd.append('archivo', file, file.name); fd.append('modo', this.modo); fd.append('simular', simular ? '1' : '0');
      const r = await fetch('/api/productos/importar', { method: 'POST', headers: cabecerasAuth(), body: fd });
      const j = await r.json().catch(() => null);
      if (!r.ok) { const d = j && j.detail; throw new Error(typeof d === 'string' ? d : Array.isArray(d) ? d.map(x => x.msg).join('; ') : (d && d.mensaje) || ('Error ' + r.status)); }
      return j;
    },
    async simular(file) {
      this.importandoSrv = true; this.previa = null; this.resultado = null; this.archivo = file;
      try { this.previa = await this.enviarServidor(file, true); if (!this.previa.creados && !this.previa.actualizados) toast('Ninguna fila se puede importar: revise los errores', 'err'); }
      catch (e) { toast(e.message, 'err'); this.archivo = null; }
      this.importandoSrv = false;
    },
    async importarAhora() {
      if (!this.archivo) return; this.importandoSrv = true;
      try {
        const r = await this.enviarServidor(this.archivo, false);
        this.historial = mock.actualizar('importaciones', l => [{ fecha: fechaHora(), archivo: this.archivo.name, creados: r.creados + (r.actualizados ? ' (+' + r.actualizados + ' actualizados)' : ''), errores: r.errores.length }, ...(Array.isArray(l) ? l : [])], []);
        this.previa = null; this.archivo = null; this.resultado = { ok: r.creados, actualizados: r.actualizados, errores: r.errores, asignadas: r.avisos };
        toast(r.creados + ' ítems creados' + (r.actualizados ? ', ' + r.actualizados + ' actualizados' : '') + (r.errores.length ? ', ' + r.errores.length + ' con error' : ''), r.errores.length ? 'err' : 'ok');
        await store.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.importandoSrv = false;
    },
    async importar(ev) {
      const file = ev.target.files?.[0] || ev.dataTransfer?.files?.[0]; if (!file) return;
      if (ev.target) ev.target.value = '';
      if (this.enServidor || /\.xlsx?$/i.test(file.name)) return this.simular(file);   // Excel siempre en el servidor
      this.importando = true; this.resultado = null;
      const texto = await file.text(); const lineas = texto.split(/\r?\n/).filter(l => l.trim());
      const sep = (lineas[0] || '').includes(';') ? ';' : ',';
      const sinTilde = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      const cab = partirCsv(lineas[0], sep).map(s => sinTilde(s.toLowerCase().trim()));
      const idx = k => cab.indexOf(k);
      const conCabecera = idx('nombre') >= 0;
      const col = (c, k, def) => { const i = conCabecera ? idx(k) : def; return i >= 0 ? (c[i] || '').trim() : ''; };
      let ok = 0; const errores = [], asignadas = []; const nuevosExtra = {};
      for (const l of lineas.slice(conCabecera ? 1 : 0)) {
        const c = partirCsv(l, sep);
        const nombre = col(c, 'nombre', 0), codigo = col(c, 'codigo', 1), cabys = col(c, 'cabys', 2), precio = parseFloat(col(c, 'precio', 3).replace(',', '.')), unidad = col(c, 'unidad', 4) || 'Unid', tipo = col(c, 'tipo', 5) || 'Producto', tarifa = col(c, 'tarifa', 6) || '08';
        // columnas opcionales (3.25): moneda del precio, categoría, costo y descripción
        const moneda = (col(c, 'moneda', -1) || monedas.principal().codigo).toUpperCase(), categoria = col(c, 'categoria', -1), costoTxt = col(c, 'costo', -1), costo = costoTxt ? parseFloat(costoTxt.replace(',', '.')) : 0, descripcion = col(c, 'descripcion', -1);
        if (!nombre || (!cabys && sesion.electronica) || isNaN(precio)) { errores.push('Fila omitida (faltan nombre, CABYS o precio): ' + l.slice(0, 60)); continue; }   /* 3.93 */
        // 3.87: existencia mínima y máxima opcionales, igual que en el servidor (vacía = sin mínimo; el servidor valida que la máxima no sea menor)
        const minTxt = col(c, 'minimo', -1).replace(',', '.'), maxTxt = col(c, 'maximo', -1).replace(',', '.');
        const minimo = minTxt ? Number(minTxt) : null, maximo = maxTxt ? Number(maxTxt) : null;
        if ((minimo !== null && !(minimo >= 0)) || (maximo !== null && !(maximo >= 0))) { errores.push(nombre + ': minimo o maximo no son números válidos (0 o más)'); continue; }
        if (codigo.length > 20) { errores.push(nombre + ': el código «' + codigo + '» pasa de 20 caracteres (límite de Hacienda)'); continue; }
        // Tarifa: código de dos dígitos ('08'); un solo dígito es un código al que Excel le quitó el cero ('8' → '08'); un
        // porcentaje ('13', '13%', '0,5') solo si corresponde a UN código. Nada se asume como 13 %: la fila ambigua se rechaza.
        const { codigo_tarifa, problema, defecto } = leerTarifa(tarifa);
        if (problema) { errores.push(nombre + ': ' + problema); continue; }
        const esServ = /servicio/i.test(tipo);
        try {
          const p = await api('/api/productos', { method: 'POST', body: { codigo: codigo || null, nombre, cabys, precio, moneda, unidad_medida: unidad, es_servicio: esServ, tipo: esServ ? 'Servicio' : 'Producto', codigo_tarifa, tarifa: CAT.tarifaPct[codigo_tarifa], categoria: categoria || null, costo: isNaN(costo) ? 0 : costo, descripcion: descripcion || null, existencia_minima: esServ ? null : minimo, existencia_maxima: esServ ? null : maximo } });
          asignadas.push(`${nombre}: IVA ${CAT.tarifaPct[codigo_tarifa]} % (código ${codigo_tarifa})${defecto ? ' — sin tarifa en el archivo, se asignó 13 %' : ''} · ${esServ ? 'Servicio' : 'Producto'}`);
          nuevosExtra[p.id] = { tipo: /servicio/i.test(tipo) ? 'Servicio' : 'Producto', costo: isNaN(costo) ? 0 : costo, existencias: /servicio/i.test(tipo) ? {} : { Principal: 0 }, activo: true, descripcion: '', listas: [], inventariable: !/servicio/i.test(tipo) };
          ok++;
        } catch (e) { errores.push(nombre + ': ' + e.message); }
      }
      this.extra = mock.actualizar('items_extra', x => Object.assign(x, nuevosExtra), {});
      this.historial = mock.actualizar('importaciones', l => [{ fecha: fechaHora(), archivo: file.name, creados: ok, errores: errores.length }, ...(Array.isArray(l) ? l : [])], []);
      this.resultado = { ok, errores, asignadas };
      toast(ok + ' ítems importados' + (errores.length ? ', ' + errores.length + ' con error' : ''), errores.length ? 'err' : 'ok');
      await store.cargar(); this.importando = false;
    },
    abrirMasivo() { this.filas = store.productos.map(p => ({ ...p, codigo_tarifa: p.codigo_tarifa, _precio: p.precio, _nombre: p.nombre, _codigo_tarifa: p.codigo_tarifa })); this.masivo = true; },
    async guardarMasivo() {
      if (!this.cambios.length) return toast('No hay cambios por guardar');
      this.guardando = true; let ok = 0, fallos = 0;
      for (const f of this.cambios) {
        try {
          // Edición en el mismo producto (PUT parcial): conserva id, existencias, costo, movimientos y datos extra
          await api('/api/productos/' + f.id, { method: 'PUT', body: { nombre: f.nombre, cabys: f.cabys, precio: +f.precio || 0, codigo_tarifa: f.codigo_tarifa, tarifa: CAT.tarifaPct[f.codigo_tarifa] ?? f.tarifa } });
          ok++;
        } catch (e) { fallos++; toast(f.nombre + ': ' + e.message, 'err'); }
      }
      // 3.87: si no se guardó ninguno no se anota el historial ni sale «0 ítems actualizados» en verde (quedan los avisos de cada fila)
      if (ok) this.actualizaciones = mock.actualizar('actualizaciones', l => [{ fecha: fechaHora(), detalle: ok + ' ítems actualizados' }, ...(Array.isArray(l) ? l : [])], []);
      await store.cargar(); this.guardando = false;
      if (ok) { this.masivo = false; toast(ok + ' ítems actualizados' + (fallos ? ', ' + fallos + ' con error' : ''), fallos ? 'err' : 'ok'); }
    },
  },
  created() { if (store.fallos?.productos) store.cargar(); },   // solo si la carga de ítems falló al entrar (R35)
  template: `
  <div class="page">
    <PageHead title="Importar y actualizar ítems" sub="Importe nuevos ítems desde un archivo o actualice en bloque la información de los existentes."></PageHead>
    <div class="tiles" style="margin-bottom:18px">
      <div class="tile" :style="tab==='importar'?'border-color:var(--primary)':''" @click="tab='importar'"><h3>⤒ Importar desde Excel o CSV</h3><p>Cree o actualice varios ítems a la vez a partir de un archivo de Excel (.xlsx) o CSV con el formato de la plantilla.</p><div class="links"><a class="link" style="color:var(--primary);cursor:pointer" @click.stop="tab='importar'">Importar ítems</a><a class="link" style="color:var(--primary);cursor:pointer" @click.stop="tab='hist-imp'">Ver historial</a></div></div>
      <div class="tile" :style="tab==='masivo'?'border-color:var(--primary)':''" @click="tab='masivo'"><h3>✎ Actualización masiva</h3><p>Modifique nombres, precios e impuestos de todos sus ítems desde una sola tabla.</p><div class="links"><a class="link" style="color:var(--primary);cursor:pointer" @click.stop="abrirMasivo">Actualizar ítems</a><a class="link" style="color:var(--primary);cursor:pointer" @click.stop="tab='hist-act'">Ver historial</a></div></div>
    </div>

    <div class="card" v-if="tab==='importar'"><h2>Importar ítems <small>Columnas: nombre; codigo; cabys; precio; unidad; tipo (Producto/Servicio); tarifa (código IVA). Opcionales: moneda (CRC o USD); categoria; costo; descripcion; existencia; visible (si/no); minimo y maximo (existencia mínima y máxima, para Por reponer)</small></h2>
      <div class="row" style="gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
        <label class="row small" style="gap:6px;align-items:center;cursor:pointer"><input type="radio" value="crear" v-model="modo"> Solo crear ítems nuevos</label>
        <label class="row small" style="gap:6px;align-items:center;cursor:pointer"><input type="radio" value="actualizar" v-model="modo"> Crear y actualizar los que ya existen (por código o nombre)</label>
      </div>
      <label class="drop" style="display:block" @dragover.prevent @drop.prevent="importar">
        <div>{{importando || importandoSrv ? 'Leyendo el archivo…' : 'Arrastre aquí el archivo de Excel (.xlsx) o CSV, o haga clic para seleccionarlo'}}</div>
        <input type="file" accept=".xlsx,.csv,.txt" style="display:none" @change="importar" :disabled="importando || importandoSrv">
      </label>
      <div class="row" style="margin-top:10px;gap:8px;flex-wrap:wrap;align-items:center"><button class="btn ghost sm" @click="plantillaExcel">⤓ Plantilla Excel</button><button class="btn ghost sm" @click="plantilla">⤓ Plantilla CSV</button>
        <label class="row small muted" style="gap:6px;align-items:center;cursor:pointer;margin-left:auto"><input type="checkbox" v-model="enServidor"> Revisar antes de guardar (los CSV también)</label></div>
      <div v-if="previa" style="margin-top:14px">
        <div class="alert" :class="previa.creados || previa.actualizados ? 'info' : 'err'"><b>Vista previa de {{archivo ? archivo.name : 'archivo'}}</b>: {{previa.filas}} filas · se crearían <b>{{previa.creados}}</b> ítems{{previa.actualizados ? ' y se actualizarían ' + previa.actualizados : ''}}{{previa.omitidos ? ' · ' + previa.omitidos + ' con error (se omiten)' : ''}}. Todavía no se guardó nada.</div>
        <div class="alert warn" v-if="previa.avisos.length"><b>Avisos</b><ul style="margin:6px 0 0;padding-left:18px"><li v-for="(a,i) in previa.avisos" :key="i" class="small">{{a}}</li></ul></div>
        <div class="alert err" v-if="previa.errores.length"><b>{{previa.errores.length}} filas con error</b><ul style="margin:6px 0 0;padding-left:18px"><li v-for="(e,i) in previa.errores" :key="i" class="small">{{e}}</li></ul></div>
        <div class="row" style="gap:8px;margin-top:8px"><button class="btn" @click="importarAhora" :disabled="importandoSrv || !(previa.creados || previa.actualizados)">{{importandoSrv ? 'Importando…' : 'Importar ahora'}}</button><button class="btn ghost" @click="previa=null; archivo=null">Cancelar</button></div>
      </div>
      <div v-if="resultado" style="margin-top:14px">
        <div class="alert ok">{{resultado.ok}} ítems creados correctamente{{resultado.actualizados ? ' y ' + resultado.actualizados + ' actualizados' : ''}}.<ul v-if="resultado.asignadas.length" style="margin:6px 0 0;padding-left:18px"><li v-for="(a,i) in resultado.asignadas" :key="i" class="small">{{a}}</li></ul></div>
        <div class="alert err" v-if="resultado.errores.length"><b>{{resultado.errores.length}} filas con error</b><ul style="margin:6px 0 0;padding-left:18px"><li v-for="(e,i) in resultado.errores" :key="i" class="small">{{e}}</li></ul></div>
      </div>
    </div>
    <div class="card" v-if="tab==='masivo'"><h2>Actualización masiva</h2><p class="muted small">Abra la tabla editable para cambiar nombre, precio base e impuesto de los {{store.productos.length}} ítems registrados.</p><button class="btn" @click="abrirMasivo">Abrir tabla de actualización</button></div>
    <div class="card pad0" v-if="tab==='hist-imp'"><div style="padding:14px 18px 0"><h2>Historial de importaciones</h2></div>
      <Empty v-if="!historial.length" icon="🕘" title="Sin importaciones" text="Las importaciones de ítems aparecerán aquí."></Empty>
      <table class="tbl" v-else><thead><tr><th>Fecha</th><th>Archivo</th><th class="num">Creados</th><th class="num">Errores</th></tr></thead><tbody><tr v-for="(h,i) in historial" :key="i"><td>{{h.fecha}}</td><td>{{h.archivo}}</td><td class="num">{{h.creados}}</td><td class="num">{{h.errores}}</td></tr></tbody></table></div>
    <div class="card pad0" v-if="tab==='hist-act'"><div style="padding:14px 18px 0"><h2>Historial de actualizaciones masivas</h2></div>
      <Empty v-if="!actualizaciones.length" icon="🕘" title="Sin actualizaciones" text="Las actualizaciones masivas aparecerán aquí."></Empty>
      <table class="tbl" v-else><thead><tr><th>Fecha</th><th>Detalle</th></tr></thead><tbody><tr v-for="(h,i) in actualizaciones" :key="i"><td>{{h.fecha}}</td><td>{{h.detalle}}</td></tr></tbody></table></div>

    <Modal v-if="masivo" title="Actualización masiva de ítems" lg @close="masivo=false">
      <p class="small muted" style="margin-top:0">Edite los valores directamente en la tabla. Solo se guardan las filas modificadas ({{cambios.length}}).</p>
      <div class="table-wrap" style="max-height:60vh;overflow:auto"><table class="tbl">
        <thead><tr><th>Código</th><th>Nombre</th><th>CABYS</th><th class="num" style="width:140px">Precio base</th><th style="width:150px">Impuesto</th><th class="num">Precio total</th></tr></thead>
        <tbody><tr v-for="f in filas" :key="f.id" :style="f.precio!==f._precio||f.nombre!==f._nombre||f.codigo_tarifa!==f._codigo_tarifa?'background:var(--primary-soft)':''">
          <td class="mono">{{f.codigo||'—'}}</td>
          <td><input class="inp" v-model="f.nombre" style="width:100%;min-width:200px"></td>
          <td class="mono">{{f.cabys}}</td>
          <td><input class="inp" type="number" min="0" step="0.01" v-model.number="f.precio" style="width:100%;text-align:right"></td>
          <td><select class="inp" v-model="f.codigo_tarifa" style="width:100%"><option v-for="(l,k) in CAT.tarifaIva" :value="k">{{l}}</option></select></td>
          <td class="num">{{money((+f.precio||0)*(1+(CAT.tarifaPct[f.codigo_tarifa]||0)/100))}}</td>
        </tr></tbody>
      </table></div>
      <template #foot><button class="btn ghost" @click="masivo=false">Cancelar</button><button class="btn" @click="guardarMasivo" :disabled="guardando||!cambios.length">{{guardando?'Guardando…':'Guardar cambios ('+cambios.length+')'}}</button></template>
    </Modal>
  </div>`,
};
