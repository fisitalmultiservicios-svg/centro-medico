// Inventario — Bodegas y transferencias entre bodegas (backend real: /api/inventario/bodegas, existencias, transferencias y ajustes)
import { api, toast, hoy, fmt, fecha, fmtCant } from '../../api.js';
import { store } from '../../app.js';

export default {
  props: ['params'],
  data() {
    return { lista: [], existencias: [], transferencias: [], q: '', f: null, transf: null, ver: null, guardando: false };
  },
  computed: {
    store() { return store; },
    productos() { return store.productos.filter(p => !p.es_servicio && p.inventariable !== false); },
    existPorProducto() { const m = {}; for (const e of this.existencias) m[e.producto_id] = e; return m; },
    columns() {
      return [
        { key: 'nombre', label: 'Nombre', fmt: (v, r) => v + (r.principal ? ' (principal)' : '') },
        { key: 'direccion', label: 'Dirección', fmt: v => v || '—' },
        { key: 'observaciones', label: 'Observaciones', fmt: v => v || '—' },
        { key: 'id', label: 'Ítems con existencias', num: true, fmt: v => fmt(this.existencias.filter(e => +(e.bodegas?.[v]?.cantidad || 0) > 0).length, 0) },
      ];
    },
  },
  methods: {
    fmtCant,
    fmt, fecha,
    async cargar() {
      try {
        const [bodegas, existencias, ajustes] = await Promise.all([api('/api/inventario/bodegas'), api('/api/inventario/existencias'), api('/api/inventario/ajustes')]);
        this.lista = bodegas; this.existencias = existencias; this.transferencias = ajustes.filter(a => a.tipo === 'transferencia');
      } catch (e) { toast(e.message, 'err'); }
    },
    existencia(pid, bodegaId) { return +(this.existPorProducto[pid]?.bodegas?.[bodegaId]?.cantidad || 0); },
    nombreProducto(pid) { return this.productos.find(p => p.id == pid)?.nombre || 'Producto ' + pid; },
    nuevo() { this.f = { id: null, nombre: '', direccion: '', observaciones: '', principal: false, activa: true }; },
    editar(r) { this.f = { ...r }; },
    async guardar() {
      if (!this.f.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      if (this.lista.some(b => b.nombre.toLowerCase() === this.f.nombre.trim().toLowerCase() && b.id !== this.f.id)) return toast('Ya existe una bodega con ese nombre', 'err');
      this.guardando = true;
      const body = { nombre: this.f.nombre.trim(), direccion: this.f.direccion || null, observaciones: this.f.observaciones || null, principal: !!this.f.principal, activa: this.f.activa !== false };
      try {
        if (this.f.id) await api('/api/inventario/bodegas/' + this.f.id, { method: 'PUT', body }); else await api('/api/inventario/bodegas', { method: 'POST', body });
        await this.cargar(); toast('Bodega guardada', 'ok'); this.f = null;
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async eliminar(r) {
      if (r.principal) return toast('La bodega principal no se puede eliminar', 'err');
      if (!confirm('¿Eliminar la bodega "' + r.nombre + '"?')) return;
      try { await api('/api/inventario/bodegas/' + r.id, { method: 'DELETE' }); await this.cargar(); toast('Bodega eliminada', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    // Eliminación masiva: el backend rechaza la principal y las que tienen existencias
    async eliminarVarios(rows) {
      let ok = 0, err = 0;
      for (const r of rows) { try { await api('/api/inventario/bodegas/' + r.id, { method: 'DELETE' }); ok++; } catch { err++; } }
      await this.cargar();
      toast(ok + ' bodegas eliminadas' + (err ? '; ' + err + ' omitidas (principal o con existencias)' : ''), err ? undefined : 'ok');
    },
    nuevaTransf() {
      const origen = (this.lista.find(b => b.principal) || this.lista[0])?.id || null;
      this.transf = { origen_id: origen, destino_id: this.lista.find(b => b.id !== origen)?.id || null, fecha: hoy(), observaciones: '', lineas: [{ producto_id: null, cantidad: 1 }] };
    },
    async transferir() {
      const t = this.transf;
      if (!t.origen_id || !t.destino_id || !t.fecha) return toast('Indique bodega de origen, destino y fecha', 'err');
      if (t.origen_id === t.destino_id) return toast('La bodega de origen y destino deben ser distintas', 'err');
      const lineas = t.lineas.filter(l => l.producto_id && +l.cantidad > 0);
      if (!lineas.length) return toast('Agregue al menos un producto con cantidad', 'err');
      const origen = this.lista.find(b => b.id === t.origen_id)?.nombre || 'origen';
      for (const l of lineas) if (this.existencia(l.producto_id, t.origen_id) < +l.cantidad) return toast('Existencias insuficientes en ' + origen + ' para ' + this.nombreProducto(l.producto_id), 'err');
      this.guardando = true;
      try {
        const r = await api('/api/inventario/transferencias', { method: 'POST', body: { origen_id: t.origen_id, destino_id: t.destino_id, fecha: t.fecha, observaciones: t.observaciones || null, lineas: lineas.map(l => ({ producto_id: l.producto_id, cantidad: +l.cantidad })) } });
        await this.cargar();
        toast('Transferencia ' + r.codigo + ' registrada: ' + lineas.length + ' productos de ' + origen + ' a ' + (this.lista.find(b => b.id === t.destino_id)?.nombre || 'destino'), 'ok'); this.transf = null;
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async abrir(t) {
      this.ver = { ...t, movimientos: null };
      try { this.ver = { ...this.ver, ...(await api('/api/inventario/ajustes/' + t.id)) }; } catch (e) { toast(e.message, 'err'); this.ver = null; }
    },
  },
  created() { if (store.fallos?.productos) store.cargar(); this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Bodegas" sub="Administre los lugares físicos donde almacena sus productos y mueva existencias entre ellos.">
      <button class="btn ghost" @click="nuevaTransf" :disabled="lista.length<2">⇄ Transferencia entre bodegas</button>
      <button class="btn" v-if="puede('catalogos')" @click="nuevo">+ Nueva bodega</button>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar bodega" v-model="q"></div>
      <DataTable :rows="lista" :columns="columns" :search="q" :selectable="puede('catalogos')" :on-bulk-delete="eliminarVarios" empty-title="Sin bodegas">
        <template #actions="{row}">
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="editar(row)" title="Editar">✎</button>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="eliminar(row)" :disabled="row.principal" title="Eliminar">🗑</button>
        </template>
      </DataTable>
    </div>
    <div class="card"><h2>Últimas transferencias <small>Movimientos de existencias entre bodegas</small></h2>
      <table class="tbl" v-if="transferencias.length"><thead><tr><th>Número</th><th>Fecha</th><th>Origen</th><th>Destino</th><th>Observaciones</th><th></th></tr></thead>
        <tbody><tr v-for="t in transferencias.slice(0,8)" :key="t.id"><td class="mono"><a class="link" @click="abrir(t)">{{t.codigo}}</a></td><td>{{fecha(t.fecha)}}</td><td>{{t.bodega||'—'}}</td><td>{{t.bodega_destino||'—'}}</td><td>{{t.observaciones||'—'}}</td><td><div class="acts"><button class="btn icon" @click="abrir(t)" title="Ver">👁</button></div></td></tr></tbody></table>
      <p class="muted small" v-else>Aún no se han registrado transferencias.</p>
      <p class="small muted" v-if="transferencias.length>8" style="margin-top:8px">Vea el historial completo en <a href="#/inventario/ajustes">Ajustes de inventario</a>.</p>
    </div>
    <Modal v-if="f" :title="f.id?'Editar bodega':'Nueva bodega'" @close="f=null">
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Nombre" req><input v-model="f.nombre"></Field>
        <Field label="Dirección"><input v-model="f.direccion"></Field>
        <Field label="Observaciones"><textarea rows="2" v-model="f.observaciones"></textarea></Field>
        <Toggle v-model="f.principal" label="Bodega principal" v-if="!(f.id && lista.find(b=>b.id===f.id)?.principal)"></Toggle>
        <p class="small muted" v-else>Esta es la bodega principal: se usa por defecto en facturas y existencias iniciales.</p>
      </div>
      <template #foot><button class="btn ghost" @click="f=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">{{guardando?'Guardando…':'Guardar'}}</button></template>
    </Modal>
    <Modal v-if="transf" title="Transferencia entre bodegas" lg @close="transf=null">
      <div class="grid cols-3">
        <Field label="Bodega de origen" req><select v-model="transf.origen_id"><option v-for="b in lista" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
        <Field label="Bodega de destino" req><select v-model="transf.destino_id"><option v-for="b in lista" :key="b.id" :value="b.id" :disabled="b.id===transf.origen_id">{{b.nombre}}</option></select></Field>
        <Field label="Fecha" req><input type="date" v-model="transf.fecha" :max="hoy"></Field>
      </div>
      <div class="alert warn" v-if="lista.length<2" style="margin-top:12px">Cree al menos dos bodegas para poder transferir existencias.</div>
      <table class="tbl" style="margin-top:12px"><thead><tr><th>Producto</th><th class="num">Disponible en origen</th><th class="num" style="width:130px">Cantidad</th><th></th></tr></thead>
        <tbody><tr v-for="(l,i) in transf.lineas" :key="i">
          <td><select class="inp" v-model="l.producto_id" style="width:100%;min-width:220px"><option :value="null">— Seleccionar —</option><option v-for="p in productos" :value="p.id">{{p.codigo?p.codigo+' · ':''}}{{p.nombre}}</option></select></td>
          <td class="num" :style="l.producto_id && existencia(l.producto_id, transf.origen_id)<+l.cantidad?'color:var(--danger)':''">{{fmtCant(existencia(l.producto_id, transf.origen_id))}}</td>
          <td><input class="inp" type="number" min="0" v-model.number="l.cantidad" style="width:100%;text-align:right"></td>
          <td><button class="btn icon" @click="transf.lineas.splice(i,1)" :disabled="transf.lineas.length===1">✕</button></td>
        </tr></tbody></table>
      <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="transf.lineas.push({producto_id:null,cantidad:1})">+ Agregar producto</button></div>
      <Field label="Observaciones" style="margin-top:12px"><input v-model="transf.observaciones" placeholder="Motivo de la transferencia"></Field>
      <template #foot><button class="btn ghost" @click="transf=null">Cancelar</button><button class="btn" @click="transferir" :disabled="lista.length<2 || guardando">{{guardando?'Transfiriendo…':'Transferir'}}</button></template>
    </Modal>
    <Modal v-if="ver" :title="'Transferencia ' + ver.codigo" lg @close="ver=null">
      <div class="grid" style="margin-bottom:14px">
        <div><div class="small muted">Fecha</div><b>{{fecha(ver.fecha)}}</b></div>
        <div><div class="small muted">Origen → Destino</div><b>{{ver.bodega||'—'}} → {{ver.bodega_destino||'—'}}</b></div>
        <div style="grid-column:1/-1" v-if="ver.observaciones"><div class="small muted">Observaciones</div>{{ver.observaciones}}</div>
      </div>
      <p class="muted small" v-if="!ver.movimientos">Cargando detalle…</p>
      <table class="tbl" v-else-if="ver.movimientos.length"><thead><tr><th>Producto</th><th>Bodega</th><th class="num">Cantidad</th><th class="num">Existencia resultante</th></tr></thead>
        <tbody><tr v-for="m in ver.movimientos" :key="m.id"><td>{{m.producto||('Producto '+m.producto_id)}}</td><td>{{m.bodega||'—'}}</td><td class="num" :style="m.cantidad<0?'color:var(--danger)':''">{{m.cantidad>0?'+':''}}{{fmtCant(m.cantidad)}}</td><td class="num">{{fmtCant(m.existencia_resultante)}}</td></tr></tbody></table>
      <p class="muted small" v-else>Sin movimientos asociados.</p>
      <template #foot><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy: hoy() }; },
};
