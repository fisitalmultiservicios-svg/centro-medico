// Punto de venta › Recetas y fichas técnicas (3.4; reubicado y rehecho en 3.18 por pedido de Norman): la receta es la unidad de
// trabajo. Cada receta crea (o actualiza) su propio ítem: si «Se vende» está encendido, el ítem aparece en la caja y en las
// facturas con su precio y su CABYS (copa de vino, casado, cóctel); si está apagado, es una preparación (salsa de la casa, masa)
// que solo sirve como ingrediente de otras recetas. Los ingredientes son ítems de Inventario: insumos que no se venden (arroz,
// pollo, botella de vino) o preparaciones con receta. Al vender se rebajan los insumos, no el plato. Igual en comercio y en el
// restaurante del hotel. Registro `recetas` [{id = producto_id, producto_id, nombre, categoria, vender, precio, cabys,
// ingredientes: [{producto_id, cantidad, unidad}], rendimiento, notas}].
import { api, toast, money, fmt, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { UNIDADES_RECETA, aUnidadProducto, unidadesPara, textoContenido } from './_unidades.js';   // gramos, mililitros… (3.10)

const r4 = n => Math.round((+n || 0) * 10000) / 10000;
const TARIFAS = [['08', 13], ['04', 4], ['03', 2], ['02', 1], ['01', 0]];

export default {
  props: ['params'],
  data() { return { lista: mock.get('recetas', []) || [], costos: [], existencias: [], q: '', form: null, cargando: false, guardando: false, extra: mock.get('items_extra', {}) || {}, UNIDADES_RECETA, TARIFAS }; },
  computed: {
    puedeEscribir() { return sesion.puede('catalogos'); },
    electronica() { return sesion.electronica; },   // 4.21: sin facturación electrónica el CABYS no es obligatorio
    productos() { return (store.productos || []).filter(p => p.activo !== false); },
    categorias() { return (mock.get('categorias', []) || []).filter(c => c && c.nombre).map(c => c.nombre); },
    recetasPor() { const m = {}; for (const r of this.lista) m[r.producto_id] = r; return m; },
    // ingredientes: insumos inventariables y preparaciones con receta; nunca la receta misma
    ingredientes() { const yo = this.form ? this.form.producto_id : null; return this.productos.filter(p => p.id !== yo && !p.es_servicio && (p.inventariable !== false || this.recetasPor[p.id])); },
    exist() { const m = {}; for (const e of this.existencias) m[e.producto_id] = e; return m; },
    costoDe() { const m = {}; for (const c of this.costos) m[c.producto_id] = c; return m; },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.lista.map(r => { const p = this.productos.find(x => x.id === r.producto_id) || {}; const c = this.costoDe[r.producto_id] || {};
        return { ...r, nombre: r.nombre || p.nombre || ('Ítem ' + r.producto_id), categoria: r.categoria || p.categoria || '', vender: r.vender !== undefined ? r.vender : p.es_venta !== false, precio: +p.precio || +r.precio || 0, n: (r.ingredientes || []).length, costo: c.costo, margen: c.margen, margen_pct: c.margen_pct, costo_local: this.costoLocal(r) }; })
        .filter(r => !q || r.nombre.toLowerCase().includes(q) || (r.categoria || '').toLowerCase().includes(q)).sort((a, b) => (a.categoria || '').localeCompare(b.categoria || '') || a.nombre.localeCompare(b.nombre));
    },
    columns() { return [{ key: 'nombre', label: 'Receta', link: r => this.editar(r) }, { key: 'categoria', label: 'Categoría', fmt: v => v || '—' }, { key: 'vender', label: 'Uso', fmt: v => v ? 'Se vende' : 'Preparación' }, { key: 'n', label: 'Ingredientes', num: true }, { key: 'rendimiento', label: 'Porciones', num: true }, { key: 'precio', label: 'Precio de venta', num: true, fmt: v => v ? money(v) : '—' }, { key: 'costo_local', label: 'Costo por porción', num: true, fmt: v => money(v) }, { key: 'margen_pct', label: 'Margen %', num: true, fmt: (v, r) => r.vender && r.precio ? fmt(this.margenPct(r), 1) + ' %' : '—' }]; },
    costoForm() { return this.form ? this.costoLocal(this.form) : 0; },
    netoForm() { const f = this.form; if (!f || !f.vender) return 0; const t = (TARIFAS.find(x => x[0] === f.codigo_tarifa) || [null, 13])[1]; return (+f.precio || 0) / (1 + t / 100); },
  },
  methods: {
    money, fmt,
    costoIng(pid) { const e = this.exist[pid], p = this.productos.find(x => x.id === pid); if (e && e.costo_promedio) return +e.costo_promedio; if (p && +p.costo) return +p.costo; const r = this.recetasPor[pid]; return r ? this.costoLocal(r) : 0; },   // una preparación cuesta lo que cuesta su receta
    enInventario(i) { const p = this.productos.find(x => x.id === i.producto_id); if (!p) return 0; return aUnidadProducto(i.cantidad, i.unidad, p, this.extra[p.id]); },
    cantInv(i) { const q = this.enInventario(i); return q === null ? (+i.cantidad || 0) : q; },
    unidadesDe(i) { const p = this.productos.find(x => x.id === i.producto_id); return p ? unidadesPara(p, this.extra[p.id]) : UNIDADES_RECETA; },
    contenidoDe(i) { const p = this.productos.find(x => x.id === i.producto_id); return p ? textoContenido(p, this.extra[p.id]) : ''; },
    cambioIngrediente(i) { const us = this.unidadesDe(i); if (!us.some(u => u[0] === i.unidad)) i.unidad = us[0][0]; },
    costoLocal(r, nivel = 0) { if (nivel > 5) return 0; const rend = +r.rendimiento || 1; return r4((r.ingredientes || []).reduce((s, i) => s + this.cantInv(i) * (this.recetasPor[i.producto_id] && !this.exist[i.producto_id] ? this.costoLocal(this.recetasPor[i.producto_id], nivel + 1) : this.costoIng(i.producto_id)), 0) / rend); },
    margenPct(r) { const neto = (+r.precio || 0) / (1 + ((TARIFAS.find(x => x[0] === r.codigo_tarifa) || [null, 13])[1]) / 100); return neto ? (neto - this.costoLocal(r)) / neto * 100 : 0; },
    unidad(pid) { const p = this.productos.find(x => x.id === pid); return p ? p.unidad_medida || 'Unid' : ''; },
    async cargar() { this.cargando = true; try { [this.existencias, this.costos] = await Promise.all([api('/api/inventario/existencias'), api('/api/inventario/recetas/costos')]); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    nueva() { this.form = { producto_id: null, nombre: '', categoria: '', vender: true, precio: 0, cabys: '', codigo_tarifa: '08', ingredientes: [{ producto_id: null, cantidad: 1, unidad: 'g' }], rendimiento: 1, notas: '' }; },
    editar(r) {
      const p = this.productos.find(x => x.id === r.producto_id) || {};
      this.form = { ...JSON.parse(JSON.stringify(r)), nombre: r.nombre || p.nombre || '', categoria: r.categoria || p.categoria || '', vender: r.vender !== undefined ? r.vender : p.es_venta !== false, precio: +p.precio || +r.precio || 0, cabys: r.cabys || p.cabys || '', codigo_tarifa: r.codigo_tarifa || p.codigo_tarifa || '08' };
    },
    async guardar() {
      const f = this.form; if (this.guardando) return;
      if (!(f.nombre || '').trim() || f.nombre.trim().length < 3) return toast('Escriba el nombre de la receta (3 caracteres o más)', 'err');
      const ings = (f.ingredientes || []).filter(i => i.producto_id && +i.cantidad > 0).map(i => ({ producto_id: i.producto_id, cantidad: r4(i.cantidad), unidad: i.unidad || 'unid' }));
      if (!ings.length) return toast('Agregue al menos un ingrediente con cantidad', 'err');
      if (f.producto_id && ings.some(i => i.producto_id === f.producto_id)) return toast('Una receta no puede ser ingrediente de sí misma', 'err');
      if (ings.some(i => this.enInventario(i) === null)) toast('Hay ingredientes cuya unidad no se puede convertir a la del inventario: se descontarán 1 a 1', 'err');
      const cabys = String(f.cabys || '').replace(/\D/g, '');
      if (f.vender && cabys.length !== 13 && (sesion.electronica || cabys.length)) return toast(sesion.electronica ? 'Para vender la receta indique el código CABYS del plato o bebida (13 dígitos)' : 'El código CABYS es opcional, pero si lo escribe debe tener 13 dígitos', 'err');   /* 4.21: sin facturación electrónica un restaurante no podía poner sus platos a la venta */
      if (f.vender && !(+f.precio > 0)) return toast('Indique el precio de venta', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      try {
        const body = { nombre: f.nombre.trim(), cabys: f.vender ? cabys : cabys, precio: f.vender ? +f.precio : 0, unidad_medida: 'Unid', es_servicio: false, inventariable: false, tipo: 'Producto',
          categoria: (f.categoria || '').trim() || null, es_venta: !!f.vender, codigo_tarifa: f.codigo_tarifa || '08', tarifa: (TARIFAS.find(x => x[0] === f.codigo_tarifa) || [null, 13])[1], activo: true };
        const p = f.producto_id ? await api('/api/productos/' + f.producto_id, { method: 'PUT', body }) : await api('/api/productos', { method: 'POST', body });
        store.poner('productos', p);
        const reg = { id: p.id, producto_id: p.id, nombre: body.nombre, categoria: body.categoria || '', vender: !!f.vender, precio: body.precio, cabys: body.cabys, codigo_tarifa: body.codigo_tarifa, ingredientes: ings, rendimiento: Math.max(1, +f.rendimiento || 1), notas: (f.notas || '').trim() };
        const l = this.lista.filter(r => r.producto_id !== p.id); l.push(reg);
        mock.set('recetas', l); this.lista = l; this.form = null; toast(f.vender ? 'Receta guardada: el ítem «' + body.nombre + '» ya se puede vender' : 'Preparación guardada', 'ok'); this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async eliminar(r) {
      if (!confirm('¿Eliminar la receta «' + (r.nombre || '') + '»? Su ítem se desactiva y deja de venderse.')) return;
      try { if (r.producto_id) { const p = await api('/api/productos/' + r.producto_id, { method: 'PUT', body: { activo: false } }); store.poner('productos', p); } } catch (e) { return toast(e.message, 'err'); }
      const l = this.lista.filter(x => x.producto_id !== r.producto_id); mock.set('recetas', l); this.lista = l; this.form = null;
    },
    exportar(formato) {
      const cols = this.columns.map(c => ({ ...c, link: undefined })), rows = this.filas;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'recetas', cols, rows);
      return descargarReporte(formato, { titulo: 'Recetas y fichas técnicas', subtitulo: 'Ingredientes, porciones, precio, costo y margen', cols, rows, kpis: [{ t: 'Recetas', v: String(rows.length) }], archivo: 'recetas' });
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Recetas y fichas técnicas" sub="Qué lleva cada plato, bebida o cóctel. Cada receta crea su ítem de venta; al venderlo se rebajan los insumos del inventario y se calcula el costo por porción y el margen." :crumbs="[{label:'Punto de venta'},{label:'Configuración'},{label:'Recetas'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!filas.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!filas.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!filas.length">CSV</button>
      <button class="btn" @click="nueva" v-if="puedeEscribir">+ Receta</button>
    </PageHead>
    <div class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar receta o categoría" v-model="q"></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin recetas" empty-text="Cree la primera: nombre, categoría, precio y sus ingredientes por porción (por ejemplo 180 g de arroz, 150 g de pollo, 150 ml de la botella de vino)." @row-click="editar">
        <template #actions="{row}"><button class="btn sm ghost" @click.stop="editar(row)">{{puedeEscribir ? 'Editar' : 'Ver'}}</button></template>
      </DataTable>
      <p class="small muted" style="margin:8px 0 0">Los insumos (arroz, pollo, botella de vino) se crean en Inventario › Ítems con «Se vende» apagado: no salen en la caja ni en las facturas. Las cantidades se escriben en gramos, kilos, mililitros, litros, onzas, libras o unidades y se convierten a la unidad del inventario; un ítem que se inventaría por unidad (botella, saco) declara su contenido en el ítem › Opciones avanzadas. Una preparación (receta con «Se vende» apagado) sirve como ingrediente de otras recetas.</p>
    </div>
    <Modal v-if="form" :title="form.producto_id ? 'Receta' : 'Nueva receta'" lg @close="form=null">
      <div class="grid cols-3">
        <Field label="Nombre de la receta" req help="Es el nombre del ítem en la caja y en la factura"><input v-model="form.nombre" maxlength="200" placeholder="Copa de vino tinto" :disabled="!puedeEscribir"></Field>
        <Field label="Categoría" help="Agrupa el ítem en la caja (Entradas, Platos fuertes, Cócteles…)"><input v-model="form.categoria" list="rec-cats" maxlength="60" :disabled="!puedeEscribir"><datalist id="rec-cats"><option v-for="c in categorias" :key="c" :value="c"></option></datalist></Field>
        <Field label="Porciones que rinde la receta" req help="1 = las cantidades son por porción"><input type="number" min="1" step="1" v-model.number="form.rendimiento" :disabled="!puedeEscribir"></Field>
      </div>
      <div class="row" style="gap:16px;align-items:center;margin:6px 0 10px;flex-wrap:wrap"><Toggle v-model="form.vender" label="Se vende (aparece en la caja y en las facturas)"></Toggle><span class="small muted" v-if="!form.vender">Apagado: es una preparación (salsa, masa, mezcla) que solo se usa como ingrediente de otras recetas.</span></div>
      <div class="grid cols-3" v-if="form.vender">
        <Field label="Precio de venta (con IVA)" req><input type="number" min="0" step="1" v-model.number="form.precio" :disabled="!puedeEscribir"></Field>
        <Field label="Código CABYS" :req="electronica" :help="electronica ? '13 dígitos; el de comidas preparadas o bebidas según el caso' : 'Opcional: su empresa no emite comprobantes electrónicos'"><input v-model="form.cabys" maxlength="13" class="mono" placeholder="6311100000000" :disabled="!puedeEscribir"></Field>
        <Field label="IVA"><select v-model="form.codigo_tarifa" :disabled="!puedeEscribir"><option v-for="t in TARIFAS" :key="t[0]" :value="t[0]">{{t[1]}} %</option></select></Field>
      </div>
      <div class="row" style="justify-content:space-between;margin:12px 0 6px"><b>Ingredientes</b><button class="btn sm sec" @click="form.ingredientes.push({producto_id:null, cantidad:1, unidad:'g'})" :disabled="!puedeEscribir">+ Ingrediente</button></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Ingrediente (insumo o preparación)</th><th class="num">Cantidad</th><th>Unidad</th><th class="num">En inventario</th><th class="num">Costo</th><th class="num">Existencia</th><th></th></tr></thead>
        <tbody><tr v-for="(i, k) in form.ingredientes" :key="k"><td><Buscador v-model="i.producto_id" :opciones="ingredientes" :detalle="p => (recetasPor[p.id] && p.inventariable === false ? 'preparación' : p.unidad_medida)" vacio="Elegir" :disabled="!puedeEscribir" @change="cambioIngrediente(i)"></Buscador><div class="small muted" v-if="contenidoDe(i)">{{contenidoDe(i)}}</div></td>
          <td class="num"><input class="inp" type="number" min="0" step="0.001" v-model.number="i.cantidad" style="width:100px" :disabled="!puedeEscribir"></td>
          <td><select class="inp" v-model="i.unidad" :disabled="!puedeEscribir"><option v-for="u in unidadesDe(i)" :key="u[0]" :value="u[0]">{{u[1]}}</option></select></td>
          <td class="num small">{{i.producto_id ? (enInventario(i) === null ? '—' : fmt(cantInv(i), 3) + ' ' + unidad(i.producto_id)) : ''}}</td>
          <td class="num small">{{i.producto_id ? money(cantInv(i) * costoIng(i.producto_id)) : ''}}</td>
          <td class="num small muted">{{i.producto_id && exist[i.producto_id] ? fmt(exist[i.producto_id].cantidad, 3) : ''}}</td>
          <td><button class="btn icon" @click="form.ingredientes.splice(k,1)" :disabled="!puedeEscribir">✕</button></td></tr></tbody></table></div>
      <div class="totals" style="margin-top:10px"><div><span>Costo de la receta</span><b>{{money(costoForm * (+form.rendimiento || 1))}}</b></div><div class="total"><span>Costo por porción</span><b>{{money(costoForm)}}</b></div><div v-if="form.vender && form.precio"><span>Precio de venta (sin IVA {{money(netoForm)}})</span><b>{{money(form.precio)}}</b></div><div v-if="form.vender && form.precio"><span>Margen por porción</span><b>{{money(netoForm - costoForm)}} · {{fmt(margenPct(form), 1)}} %</b></div></div>
      <Field label="Notas de preparación" style="margin-top:10px"><textarea rows="2" v-model="form.notas" maxlength="400" :disabled="!puedeEscribir"></textarea></Field>
      <template #foot><button class="btn danger" v-if="form.producto_id && puedeEscribir" @click="eliminar(form)">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="form=null">Cerrar</button><button class="btn" @click="guardar" v-if="puedeEscribir" :disabled="guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button></template>
    </Modal>
  </div>`,
};
