// 4.24 · Etiquetas de productos con código de barras: lo que comparten Ítems, la ficha del ítem, la caja y la configuración de
// impresoras. Sin dependencias: solo datos y funciones puras. MEDIDAS, FORMATOS, MODELOS y los topes son los mismos de
// app/etiquetas_impresora.py (tests/test_424_etiquetas.py comprueba que no se separen).
export const MEDIDAS = [[30, 20], [40, 25], [40, 30], [50, 25], [50, 30], [58, 40], [60, 40], [76, 51], [100, 50], [100, 150]];   // ancho × alto, mm
export const ANCHO_MIN = 20, ANCHO_MAX = 110, ALTO_MIN = 15, ALTO_MAX = 160;   // medida «Personalizada»
export const COPIAS_MAX = 500, ETIQUETAS_MAX = 3000, ALTERNOS_MAX = 5, SEPARACION_MM = 2, CODIGO_MAX = 20;
export const FORMATOS = [['nombre_codigo', 'Nombre y código de barras'], ['nombre_codigo_precio', 'Nombre, código de barras y precio'], ['solo_codigo', 'Solo el código de barras']];
export const LENGUAJES = [['tspl', 'TSPL'], ['zpl', 'ZPL'], ['pdf', 'Controlador de Windows (PDF)']];
// Modelos predefinidos de impresora de etiquetas: el modelo pone el lenguaje y la densidad (null = la que tenga puesta la impresora)
export const MODELOS = [
  { id: '3nstar-ldt124', nombre: '3nStar LDT124', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 104, densidad: 8 },
  { id: '3nstar-ldt114', nombre: '3nStar LDT114', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 104, densidad: 8 },
  { id: 'tsc-te200', nombre: 'TSC TE200', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'tsc-ttp244pro', nombre: 'TSC TTP-244 Pro', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'tsc-da210', nombre: 'TSC DA210', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'xprinter-xp365b', nombre: 'Xprinter XP-365B', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'xprinter-xp420b', nombre: 'Xprinter XP-420B', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'gprinter-gp1324d', nombre: 'Gprinter GP-1324D', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'zebra-zd220', nombre: 'Zebra ZD220', lenguaje: 'zpl', dpi: 203, ancho_max_mm: 110, densidad: null },
  { id: 'zebra-zd230', nombre: 'Zebra ZD230', lenguaje: 'zpl', dpi: 203, ancho_max_mm: 110, densidad: null },
  { id: 'zebra-zd420', nombre: 'Zebra ZD420', lenguaje: 'zpl', dpi: 203, ancho_max_mm: 110, densidad: null },
  { id: 'zebra-gk420', nombre: 'Zebra GK420', lenguaje: 'zpl', dpi: 203, ancho_max_mm: 110, densidad: null },
  { id: 'otra-tspl', nombre: 'Otra con TSPL', lenguaje: 'tspl', dpi: 203, ancho_max_mm: 110, densidad: 8 },
  { id: 'otra-zpl', nombre: 'Otra con ZPL', lenguaje: 'zpl', dpi: 203, ancho_max_mm: 110, densidad: null },
  { id: 'otra-pdf', nombre: 'Otra, con controlador de Windows (PDF)', lenguaje: 'pdf', dpi: 203, ancho_max_mm: 110, densidad: null },
];
export function modeloDe(id) { return MODELOS.find(m => m.id === id) || null; }

// ---- códigos ----
export function normCodigo(c) { return String(c ?? '').trim().toLowerCase(); }   // como compara el servidor: sin espacios a los lados ni mayúsculas
export function digitoEan13(doce) { let s = 0; for (let i = 0; i < 12; i++) s += (+String(doce)[i]) * (i % 2 ? 3 : 1); return (10 - s % 10) % 10; }
export function esEan13(c) { c = String(c ?? ''); return /^[0-9]{13}$/.test(c) && digitoEan13(c) === +c[12]; }
// La marca de la empresa en sus códigos generados (la misma de etiquetas_impresora.marca_empresa): los 3 últimos dígitos de su cédula,
// con ceros a la izquierda si hay menos; «000» si no tiene cédula. Se le suma el código de sucursal de la empresa menos 1 (sin dato, 1) y
// se toman los 3 últimos dígitos: las sucursales de una misma cédula, que se llevan como empresas aparte, no reciben la misma marca
export function marcaEmpresa(numeroId, sucursal) {
  const s = Math.trunc(+sucursal);
  return String(((+String(numeroId ?? '').replace(/[^0-9]/g, '').slice(-3) || 0) + (Number.isFinite(s) && s >= 1 ? s : 1) - 1) % 1000).padStart(3, '0');
}
// La marca de la empresa activa, de la ficha que la aplicación ya tiene cargada (store.empresa); null mientras no la tenga: la pantalla
// nunca inventa la marca (sin ella no muestra un código supuesto)
export function marcaDe(empresa) { return empresa ? marcaEmpresa(empresa.numero_id, empresa.sucursal) : null; }
// Código de barras propio de un producto (el mismo de etiquetas_impresora.codigo_barras_propio): EAN-13 interno = «2» + marca de la
// empresa (3 dígitos) + id con ceros hasta 8 dígitos + verificador; un id que no cabe en 8 dígitos: «P» + marca + «-» + id. '' sin marca
export function codigoBarrasPropio(id, marca) {
  const n = Math.trunc(+id), m = String(marca ?? ''); if (!(n >= 0) || !/^[0-9]{3}$/.test(m)) return '';
  if (n > 99999999) return 'P' + m + '-' + n;
  const doce = '2' + m + String(n).padStart(8, '0');
  return doce + digitoEan13(doce);
}
// ¿Ese código es el generado de ese producto? (el mismo de etiquetas_impresora.es_codigo_propio): con CUALQUIER marca, para que los
// códigos ya generados sigan contando como propios si la empresa corrige su cédula
export function esCodigoPropio(codigo, id) {
  const c = normCodigo(codigo), n = Math.trunc(+id); if (!(n >= 0)) return false;
  if (n > 99999999) return /^p[0-9]{3}-/.test(c) && c.slice(5) === String(n);
  return esEan13(c) && c[0] === '2' && c.slice(4, 12) === String(n).padStart(8, '0');
}
export function alternosDe(p) { return String((p && p.codigos_alternos) || '').split(',').map(s => s.trim()).filter(Boolean); }
// La caja al leer un código: exacto por el código del producto, después por un código alterno (el de fábrica o una etiqueta vieja) y después por CABYS
export function productoPorCodigo(productos, q) {
  const c = normCodigo(q); if (!c) return null;
  const lista = productos || [];
  return lista.find(p => normCodigo(p.codigo) === c) || lista.find(p => alternosDe(p).some(a => a.toLowerCase() === c)) || lista.find(p => String(p.cabys || '') === String(q).trim()) || null;
}
// Los de `items` cuyo código ya tiene OTRO producto (repetidos de antes de la regla): la caja toma el primero que encuentra, así que
// su etiqueta puede vender el otro. Devuelve [{ id, nombre, codigo, otro }] (otro = el nombre de uno de los que comparten el código)
export function conCodigoRepetido(items, productos) {
  const por = new Map();
  for (const p of productos || []) { const c = normCodigo(p && p.codigo); if (c) por.set(c, (por.get(c) || []).concat(p)); }
  const out = [];
  for (const x of items || []) { const otro = (por.get(normCodigo(x.codigo)) || []).find(p => p.id !== x.id); if (otro) out.push({ id: x.id, nombre: x.nombre, codigo: String(x.codigo).trim(), otro: otro.nombre }); }
  return out;
}

// ---- medidas y copias ----
export function medidaTexto(m) { return m[0] + ' × ' + m[1] + ' mm'; }
export function medidaValida(ancho, alto) { const a = +ancho, h = +alto; return a >= ANCHO_MIN && a <= ANCHO_MAX && h >= ALTO_MIN && h <= ALTO_MAX; }
export function copiasDe(v) { const n = Math.floor(+v); return n >= 1 ? Math.min(n, COPIAS_MAX) : 0; }   // 0 = ese producto no se imprime
export function copiasPorExistencias(existencias) { return copiasDe(Math.ceil(+existencias || 0)); }
export function totalEtiquetas(items) { return (items || []).reduce((s, x) => s + copiasDe(x.copias), 0); }

// ---- barras muy finas para el lector ----
// Ancho de la barra más angosta (mm) que tendría ese código en una etiqueta de ese ancho. Es un cálculo APROXIMADO, solo para avisar en
// la pantalla (el exacto lo hacen el servidor y el servicio de impresión): módulos = 95 + 22 si es EAN-13 (o no tiene código: se le
// generará uno); si no, Code128 = 11 × (símbolos + 2) + 13 + 20, con símbolos = largo del código, o la mitad si son solo dígitos y de
// largo par; el módulo se redondea hacia abajo a puntos de una impresora de 203 por pulgada (0,1251 mm), con tope de 4 puntos
export const PUNTO_MM = 25.4 / 203, BARRA_FINA_MM = 0.25;
export function barraAngostaMm(codigo, anchoMm) {
  const c = String(codigo ?? '').trim(), simbolos = /^[0-9]+$/.test(c) && c.length % 2 === 0 ? c.length / 2 : c.length;
  const modulos = !c || esEan13(c) ? 95 + 22 : 11 * (simbolos + 2) + 13 + 20;
  return Math.max(0, Math.min(4, Math.floor((+anchoMm || 0) / modulos / PUNTO_MM))) * PUNTO_MM;
}
// Cuántos de `items` quedarían con barras por debajo de 0,25 mm en una etiqueta de ese ancho, y el aviso del cuadro ('' = ninguno)
export function conBarrasFinas(items, anchoMm) { return (items || []).filter(x => barraAngostaMm(x.codigo, anchoMm) < BARRA_FINA_MM).length; }
export function avisoBarrasFinas(n) { return n > 0 ? 'Con esta medida las barras de ' + (n === 1 ? '1 producto' : n + ' productos') + ' quedan muy finas y el lector puede no leerlas: use una etiqueta más ancha' : ''; }

// ---- impresoras de etiquetas (registro pos_impresoras, uso 'etiquetas') ----
export function esDeEtiquetas(i) { return !!i && i.uso === 'etiquetas'; }
export function directa(i) { return esDeEtiquetas(i) && (i.lenguaje === 'tspl' || i.lenguaje === 'zpl') && (i.conexion === 'usb' || i.conexion === 'red'); }   // va por el servicio de impresión local; las demás, en PDF
export function medidaImpresora(i) { const a = +(i && i.etq_ancho_mm), h = +(i && i.etq_alto_mm); return medidaValida(a, h) ? [a, h] : [50, 30]; }
// La que propone el cuadro de etiquetas: si hay una sola, esa; si hay varias, la última usada en este equipo ('' = elegir al imprimir, en PDF)
export function impresoraPropuesta(lista, recordada) {
  const l = (lista || []).filter(i => esDeEtiquetas(i) && i.activa !== false);
  if (l.length === 1) return String(l[0].id);
  return l.some(i => String(i.id) === String(recordada)) ? String(recordada) : '';
}
// El trabajo que recibe el servicio de impresión local: solo datos (nombre, código, precio, copias y medidas), nunca órdenes de la impresora
export function trabajoEtiquetas(imp, items, formato, medida) {
  const den = imp.densidad === '' || imp.densidad === null || imp.densidad === undefined ? null : +imp.densidad;
  return { conexion: imp.conexion, direccion: imp.direccion || '', lenguaje: imp.lenguaje, ancho_mm: +medida[0], alto_mm: +medida[1], separacion_mm: imp.separacion_mm === '' || imp.separacion_mm === null || imp.separacion_mm === undefined ? SEPARACION_MM : +imp.separacion_mm,
    densidad: den, dpi: +imp.dpi || 203, girar: !!imp.girar,   // girar: la impresión sale girada 180° (casilla de la impresora)
    etiquetas: (items || []).filter(x => copiasDe(x.copias) > 0 && String(x.codigo || '').trim()).map(x => ({ nombre: formato === 'solo_codigo' ? '' : String(x.nombre || ''), codigo: String(x.codigo).trim(), ...(formato === 'nombre_codigo_precio' && x.precio_texto ? { precio: x.precio_texto } : {}), copias: copiasDe(x.copias) })) };
}

// ---- «Registrar códigos con el lector»: un producto a la vez. El estado es puro; la pantalla lo dibuja y pasa `guardar(producto, cuerpo)` ----
export function nuevaTanda(productos) { return { lista: (productos || []).slice(), i: 0, registrados: [], saltados: [], choques: [], fin: !(productos || []).length }; }
export function productoDeTanda(t) { return t.fin ? null : t.lista[t.i] || null; }
function avanzar(t) { t.i++; if (t.i >= t.lista.length) t.fin = true; }
// Guarda el código leído como código del producto por la ruta de cambio de siempre. El anterior, si tenía, queda como código alterno.
// Devuelve { ok, igual, vacio, choque, mensaje, producto }; un 409 (ya lo tiene otro producto) no se guarda y se informa.
export async function registrarCodigo(p, codigo, guardar) {
  const c = String(codigo ?? '').trim();
  if (!c) return { ok: false, vacio: true, mensaje: 'Lea o escriba el código' };
  if (c.length > CODIGO_MAX) return { ok: false, mensaje: 'El código no puede pasar de ' + CODIGO_MAX + ' caracteres' };
  if (normCodigo(p.codigo) === normCodigo(c)) return { ok: true, igual: true, producto: p };
  try { const r = await guardar(p, { codigo: c, conservar_codigo_anterior: true }); return { ok: true, producto: r && r.id ? r : { ...p, codigo: c } }; }
  catch (e) { return { ok: false, choque: e && e.status === 409, mensaje: (e && e.message) || 'No se pudo guardar el código' }; }
}
export async function registrarEnTanda(t, codigo, guardar) {
  const p = productoDeTanda(t); if (!p) return { ok: false, mensaje: 'No quedan productos' };
  const r = await registrarCodigo(p, codigo, guardar);
  if (r.ok) { t.choques = t.choques.filter(x => x.id !== p.id); t.registrados.push({ id: p.id, nombre: p.nombre, codigo: String(codigo).trim() }); avanzar(t); }
  else if (r.choque) { t.choques = t.choques.filter(x => x.id !== p.id); t.choques.push({ id: p.id, nombre: p.nombre, codigo: String(codigo).trim(), mensaje: r.mensaje }); }
  return r;
}
export function saltarEnTanda(t) { const p = productoDeTanda(t); if (!p) return; if (!t.choques.some(x => x.id === p.id)) t.saltados.push({ id: p.id, nombre: p.nombre }); avanzar(t); }
export function terminarTanda(t) { t.fin = true; }
export function resumenTanda(t) {
  const n = t.registrados.length, s = t.saltados.length, ch = t.choques.length, sinVer = Math.max(0, t.lista.length - n - s - ch);   // sin ver: se terminó antes de llegar a ellos
  return { registrados: n, saltados: s, choques: t.choques.slice(), sin_ver: sinVer,
    texto: n + (n === 1 ? ' código registrado' : ' códigos registrados') + ' · ' + s + (s === 1 ? ' saltado' : ' saltados') + (ch ? ' · ' + ch + (ch === 1 ? ' chocó' : ' chocaron') + ' con otro producto' : '') + (sinVer ? ' · ' + sinVer + ' sin ver' : '') };
}
