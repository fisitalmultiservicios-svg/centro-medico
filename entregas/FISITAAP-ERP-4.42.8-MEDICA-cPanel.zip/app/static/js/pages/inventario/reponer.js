// Inventario › Por reponer (3.87): ítems en o bajo su existencia mínima (Producto.existencia_minima), con la cantidad sugerida
// (hasta la existencia máxima o, sin ella, el doble de la mínima), el costo y el proveedor habitual (la relación proveedor → ítem
// de la recepción de comprobantes, 3.75). Un botón por proveedor abre la orden de compra ya llena. Backend: GET /api/inventario/reponer.
import { api, money, fmtCant, toast } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { cargando: true, datos: { con_minimo: 0, items: [] }, bodegas: [], bodega_id: '', q: '' }; },
  computed: {
    puedeComprar() { return sesion.puede('gastos'); },
    filtrados() {
      const q = this.q.trim().toLowerCase();
      return q ? this.datos.items.filter(x => [x.nombre, x.codigo, x.categoria, (x.proveedor || {}).nombre].join(' ').toLowerCase().includes(q)) : this.datos.items;
    },
    // una tarjeta por proveedor habitual (y una para los que no tienen): cada una se vuelve una orden de compra
    grupos() {
      const m = new Map();
      for (const x of this.filtrados) {
        const p = x.proveedor, k = p ? (p.contacto_id ? 'c' + p.contacto_id : 'p' + (p.identificacion || p.nombre)) : '-';
        if (!m.has(k)) m.set(k, { clave: k, proveedor: p, items: [] });
        m.get(k).items.push(x);
      }
      return [...m.values()];
    },
    totalSugerido() { return this.filtrados.reduce((s, x) => s + (+x.sugerido || 0) * (+x.costo || 0), 0); },
  },
  watch: { bodega_id() { this.cargar(); } },
  methods: {
    money, fmtCant,
    async cargar() {
      this.cargando = true;
      try { this.datos = await api('/api/inventario/reponer' + (this.bodega_id ? '?bodega_id=' + encodeURIComponent(this.bodega_id) : '')); }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    subtotal(g) { return g.items.reduce((s, x) => s + (+x.sugerido || 0) * (+x.costo || 0), 0); },
    orden(g) {
      const qs = new URLSearchParams({ reponer: g.items.map(x => x.producto_id).join(',') });
      if (g.proveedor && g.proveedor.contacto_id) qs.set('proveedor', g.proveedor.contacto_id);
      if (this.bodega_id) qs.set('bodega_id', this.bodega_id);
      location.hash = '/gastos/ordenes/nueva?' + qs.toString();
    },
  },
  async created() {
    try { this.bodegas = await api('/api/inventario/bodegas'); } catch { /* sin bodegas: el total de la empresa */ }
    this.cargar();
  },
  template: `
  <div class="page" :data-listo="!cargando">
    <PageHead title="Por reponer" sub="Ítems que llegaron a su existencia mínima, con la cantidad sugerida y el proveedor habitual. La orden de compra sale ya llena." :crumbs="[{label:'Inventario'},{label:'Por reponer'}]">
      <button class="btn ghost" @click="cargar" :disabled="cargando">↻ Actualizar</button>
    </PageHead>
    <div class="card"><div class="grid cols-3" style="align-items:end">
      <Field label="Bodega" help="Todas = la existencia total de la empresa"><select v-model="bodega_id"><option value="">Todas las bodegas</option><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
      <Field label="Buscar"><input v-model="q" placeholder="Ítem, código, categoría o proveedor"></Field>
      <div><div class="small muted">Por reponer</div><div style="font-size:22px;font-weight:700">{{filtrados.length}} <span class="small muted" style="font-weight:400">de {{datos.con_minimo}} con mínimo</span></div><div class="small muted">Compra sugerida: {{money(totalSugerido)}} sin IVA</div></div>
    </div></div>
    <p class="muted small" v-if="cargando">Cargando…</p>
    <div class="card" v-else-if="!datos.con_minimo"><Empty icon="▦" title="Ningún ítem tiene existencia mínima" text="Indíquela en la ficha de cada ítem (Inventario › Ítems › editar › Existencia mínima). Cuando la existencia llegue a ese número, el ítem aparece aquí y en el Inicio."><a class="btn" href="#/inventario/items">Ir a Ítems</a></Empty></div>
    <div class="card" v-else-if="!filtrados.length"><Empty icon="✓" title="Nada por reponer" :text="q ? 'Ningún ítem por reponer coincide con la búsqueda.' : 'Todos los ítems con mínimo tienen existencias por encima de él.'"></Empty></div>
    <template v-else>
      <div class="card pad0" v-for="g in grupos" :key="g.clave">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding:12px 14px 0">
          <h2 style="margin:0">{{g.proveedor ? g.proveedor.nombre : 'Sin proveedor habitual'}} <small v-if="g.proveedor && g.proveedor.identificacion">{{g.proveedor.identificacion}}</small><small v-else-if="!g.proveedor">elija el proveedor en la orden</small></h2>
          <div class="row" style="gap:8px;align-items:center"><span class="small muted">{{money(subtotal(g))}}</span><button class="btn sm" v-if="puedeComprar" @click="orden(g)">Crear orden de compra ({{g.items.length}})</button></div>
        </div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Ítem</th><th>Código</th><th class="num">Existencia</th><th class="num">Mínimo</th><th class="num">Máximo</th><th class="num">Sugerido</th><th class="num">Costo</th><th class="num">Subtotal</th></tr></thead>
          <tbody><tr v-for="x in g.items" :key="x.producto_id">
            <td><a :href="'#/inventario/items/' + x.producto_id">{{x.nombre}}</a><div class="small muted" v-if="x.categoria">{{x.categoria}}</div></td>
            <td class="mono small">{{x.codigo || '—'}}</td>
            <td class="num" :style="x.existencia <= 0 ? 'color:var(--danger);font-weight:600' : ''">{{fmtCant(x.existencia)}} <span class="small muted">{{x.unidad_medida}}</span></td>
            <td class="num">{{fmtCant(x.minimo)}}</td>
            <td class="num">{{x.maximo === null || x.maximo === undefined ? '—' : fmtCant(x.maximo)}}</td>
            <td class="num"><b>{{fmtCant(x.sugerido)}}</b></td>
            <td class="num">{{money(x.costo)}}</td>
            <td class="num">{{money(x.costo * x.sugerido)}}</td>
          </tr></tbody>
        </table></div>
      </div>
      <p class="small muted">Cantidad sugerida: lo que falta para llegar a la existencia máxima; sin máxima, al doble de la mínima. Los ítems con receta se reponen por sus ingredientes. <span v-if="!puedeComprar">Las órdenes de compra las crea quien tiene acceso a Gastos.</span></p>
    </template>
  </div>`,
};
