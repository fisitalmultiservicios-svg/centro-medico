// 4.24 · Cuadros de Inventario › Ítems para el código de barras: «Registrar código» (leer con el lector el que el producto ya trae),
// «Generar códigos de barras» y «Etiquetas» (varios productos, cuántas copias de cada uno, formato, medida e impresora).
// La lógica que no depende de la pantalla está en _etiquetas.js (funciones puras, con pruebas).
import { api, toast, money, otroImpLinea, mock, abrirArchivo, fmtCant } from '../../api.js';
import { store, sesion } from '../../app.js';
import { nuevaTanda, productoDeTanda, registrarEnTanda, saltarEnTanda, terminarTanda, resumenTanda, normCodigo, CODIGO_MAX, codigoBarrasPropio, esCodigoPropio, marcaDe, esEan13, MEDIDAS, FORMATOS, COPIAS_MAX, ETIQUETAS_MAX,
  ANCHO_MIN, ANCHO_MAX, ALTO_MIN, ALTO_MAX, medidaValida, copiasDe, copiasPorExistencias, totalEtiquetas, esDeEtiquetas, directa, medidaImpresora, impresoraPropuesta, trabajoEtiquetas, conCodigoRepetido, conBarrasFinas, avisoBarrasFinas } from './_etiquetas.js';
import { barrasDe } from './_barras.js';
import { agenteEstado, sabeEtiquetas, imprimirEtiquetas } from '../pos/_agente.js';   // envío directo a la impresora de etiquetas por el servicio de impresión local
// 9c (J4): el aviso de una impresión que no salió, con la ayuda común de pos/_agente.js (se carga aquí al usarla: las pruebas viejas montan esta pantalla con un _agente.js reducido)
async function avisoImpresion(prefijo, e) { try { const A = await import('../pos/_agente.js'); if (A.avisoImpresion) return A.avisoImpresion(prefijo, e); } catch { /* como antes */ } return prefijo + ((e && e.message) || ''); }

// precio final de una unidad: con IVA y, si el ítem lo lleva, Selectivo o impuesto específico (lo mismo que cobra la caja)
export function precioFinal(p) { const base = +p.precio || 0, oi = otroImpLinea(p.otro_impuesto, 1, base); return Math.round((base + oi.monto + (base + oi.base) * (+p.tarifa || 0) / 100) * 100) / 100; }

// ---- «Registrar código»: uno (acción de la fila) o varios, un producto a la vez (acción en lote y «Más acciones») ----
export const DialogoRegistrarCodigos = {
  props: { productos: { type: Array, required: true } },
  emits: ['close', 'cambio'],
  data() { return { tanda: nuevaTanda(this.productos), codigo: '', error: '', guardando: false, CODIGO_MAX }; },
  computed: {
    uno() { return this.productos.length === 1; },
    actual() { return productoDeTanda(this.tanda); },
    resumen() { return resumenTanda(this.tanda); },
  },
  methods: {
    money, precioFinal,
    enfocar() { this.$nextTick(() => { const el = this.$refs.lector; if (el) el.focus(); }); },
    async guardar() {
      if (this.guardando) return;
      const p = this.actual, c = this.codigo.trim(); if (!p) return;
      if (!c) { this.error = 'Lea el código con el lector o escríbalo'; return this.enfocar(); }
      const anterior = String(p.codigo || '').trim();
      // ya tenía código: se pregunta antes de reemplazarlo (el anterior queda como código alterno)
      if (anterior && normCodigo(anterior) !== normCodigo(c) && !confirm('«' + p.nombre + '» ya tiene el código ' + anterior + '.\n\n¿Reemplazarlo por ' + c + '? El anterior queda como código alterno: la caja lo sigue reconociendo.')) return this.enfocar();
      this.guardando = true; this.error = '';
      const r = await registrarEnTanda(this.tanda, c, (prod, cuerpo) => api('/api/productos/' + prod.id, { method: 'PUT', body: cuerpo }));
      this.guardando = false;
      if (r.ok) {
        if (r.producto && r.producto.id && !r.igual) { store.poner('productos', r.producto); this.$emit('cambio', r.producto); }
        this.codigo = '';
        if (this.uno) { toast(r.igual ? 'Ese ya era el código de «' + p.nombre + '»' : 'Código ' + c + ' registrado en «' + p.nombre + '»', 'ok'); return this.$emit('close'); }
      } else { this.error = r.mensaje; if (this.$refs.lector) this.$refs.lector.select(); }
      this.enfocar();
    },
    saltar() { saltarEnTanda(this.tanda); this.codigo = ''; this.error = ''; this.enfocar(); },
    terminar() { terminarTanda(this.tanda); this.codigo = ''; this.error = ''; },
  },
  mounted() { this.enfocar(); },
  template: `
  <Modal :title="uno ? 'Registrar código' : 'Registrar códigos con el lector'" @close="$emit('close')">
    <template v-if="actual">
      <p class="small muted" style="margin:0 0 6px" v-if="!uno">Producto {{tanda.i + 1}} de {{tanda.lista.length}} · {{resumen.registrados}} registrados</p>
      <p style="margin:0 0 4px" v-if="uno">Lea el código de <b>{{actual.nombre}}</b> con el lector.</p>
      <template v-else><p style="margin:0 0 4px">Lea con el lector el código de:</p><div style="font-size:20px;font-weight:700;line-height:1.25">{{actual.nombre}}</div></template>
      <div class="small muted" style="margin:2px 0 12px">{{actual.categoria || 'Sin categoría'}} · {{money(precioFinal(actual), actual.moneda || 'CRC')}}</div>
      <div class="alert info" v-if="(actual.codigo || '').trim()" style="margin-bottom:10px">Ya tiene el código <b class="mono">{{actual.codigo}}</b>. Si registra otro, el anterior queda como código alterno: la caja lo sigue reconociendo.</div>
      <Field label="Código de barras" help="El lector lo escribe y lo guarda solo. También puede escribirlo y presionar Enter."><input ref="lector" class="mono" v-model="codigo" :maxlength="CODIGO_MAX" autocomplete="off" placeholder="Lea el código con el lector" :disabled="guardando" @keydown.enter.prevent="guardar"></Field>
      <div class="alert err" v-if="error" style="margin:10px 0 0">{{error}}</div>
    </template>
    <template v-else>
      <p style="margin:0 0 8px"><b>{{resumen.texto}}</b></p>
      <div v-if="resumen.choques.length"><p class="small" style="margin:0 0 4px">No se guardaron porque el código ya es de otro producto:</p>
        <ul class="small" style="margin:0;padding-left:18px"><li v-for="x in resumen.choques" :key="x.id"><b>{{x.nombre}}</b> · <span class="mono">{{x.codigo}}</span> — {{x.mensaje}}</li></ul></div>
      <p class="small muted" style="margin:8px 0 0" v-if="resumen.registrados">Ya puede imprimir sus etiquetas o venderlos en la caja leyendo el código.</p>
    </template>
    <template #foot>
      <template v-if="actual">
        <button class="btn ghost" v-if="uno" @click="$emit('close')">Cancelar</button>
        <template v-else><button class="btn ghost" @click="terminar">Terminar</button><button class="btn sec" @click="saltar" :disabled="guardando">Saltar</button></template>
        <button class="btn" @click="guardar" :disabled="guardando">{{guardando ? 'Guardando…' : 'Guardar código'}}</button>
      </template>
      <button class="btn" v-else @click="$emit('close')">Cerrar</button>
    </template>
  </Modal>`,
};

// ---- «Generar códigos de barras»: solo a los que no tienen, o a todos reemplazando (el anterior queda como código alterno) ----
export const DialogoGenerarCodigos = {
  props: { productos: { type: Array, required: true } },
  emits: ['close', 'hecho'],
  data() { return { modo: 'faltan', trabajando: false, resultado: null }; },
  computed: {
    sinCodigo() { return this.productos.filter(p => !String(p.codigo || '').trim()); },
    // con «A todos» cambian los que no tienen ya su código propio (el generado de ese producto, con cualquier marca de empresa)
    afectados() { return this.modo === 'faltan' ? this.sinCodigo.length : this.productos.filter(p => !esCodigoPropio(p.codigo, p.id)).length; },
    reemplazados() { return this.modo === 'todos' ? this.afectados - this.sinCodigo.length : 0; },
  },
  methods: {
    async generar() {
      const n = this.afectados; if (!n || this.trabajando) return;
      if (!confirm('Se va a generar el código de barras de ' + n + (n === 1 ? ' producto' : ' productos') + (this.reemplazados ? ': ' + this.reemplazados + ' ya ' + (this.reemplazados === 1 ? 'tiene código y se le' : 'tienen código y se les') + ' reemplaza (el anterior queda como código alterno)' : '') + '. ¿Continuar?')) return;
      this.trabajando = true;
      const res = { cambiados: 0, sin_cambio: 0, no_se_pudo: [], no_guardados: 0, avisos: [] }, ids = this.productos.map(p => p.id);
      try {
        for (let i = 0; i < ids.length; i += 2000) {   // por tandas: el servidor recibe hasta 5.000 por pedido
          const r = await api('/api/productos/codigos/generar', { method: 'POST', body: { ids: ids.slice(i, i + 2000), reemplazar: this.modo === 'todos' } });
          res.cambiados += r.cambiados; res.sin_cambio += r.sin_cambio;
          // 9b (U18): los ítems de la página web que no se pudieron cambiar (la web no respondió) van aparte, con su aviso, no como choques de código
          res.no_se_pudo.push(...(r.no_se_pudo || []).filter(x => !(x && x.web)));
          if (r.no_guardados) { res.no_guardados += r.no_guardados; if (r.aviso && !res.avisos.includes(r.aviso)) res.avisos.push(r.aviso); }
        }
        this.resultado = res; await store.cargar(); this.$emit('hecho', res);
      } catch (e) { toast(e.message, 'err'); if (res.cambiados) { await store.cargar(); this.$emit('hecho', res); } }
      this.trabajando = false;
    },
  },
  template: `
  <Modal title="Generar códigos de barras" @close="$emit('close')">
    <template v-if="!resultado">
      <p class="small muted" style="margin:0 0 12px">Cada producto recibe un código de barras propio, que sale de su número y por eso no se repite. Con él se imprimen las etiquetas y la caja lo vende al leerlo con el lector.</p>
      <label class="row" style="gap:8px;align-items:flex-start;cursor:pointer;margin-bottom:12px"><input type="radio" value="faltan" v-model="modo" style="margin-top:3px"><span><b>Solo a los que no tienen</b><br><span class="small muted">{{sinCodigo.length}} de {{productos.length}} {{productos.length === 1 ? 'producto no tiene' : 'productos no tienen'}} código. A los que ya tienen no se les cambia.</span></span></label>
      <label class="row" style="gap:8px;align-items:flex-start;cursor:pointer"><input type="radio" value="todos" v-model="modo" style="margin-top:3px"><span><b>A todos: reemplaza los que ya tienen</b><br><span class="small muted">El código anterior queda como código alterno: la caja lo sigue reconociendo. Las facturas nuevas llevarán el código nuevo.</span></span></label>
    </template>
    <template v-else>
      <p style="margin:0 0 8px"><b>{{resultado.cambiados}} {{resultado.cambiados === 1 ? 'código generado' : 'códigos generados'}}</b><span v-if="resultado.sin_cambio"> · {{resultado.sin_cambio}} sin cambio</span></p>
      <div class="alert err small" style="margin:0 0 10px" v-for="a in (resultado.avisos || [])" :key="a">{{a}}</div>
      <div v-if="resultado.no_se_pudo.length"><p class="small" style="margin:0 0 4px">A estos no se les pudo generar porque su código ya lo tiene otro producto (cámbielo en ese otro y vuelva a generar):</p>
        <ul class="small" style="margin:0;padding-left:18px"><li v-for="x in resultado.no_se_pudo" :key="x.id"><b>{{x.nombre}}</b> — {{x.motivo}}</li></ul></div>
    </template>
    <template #foot>
      <button class="btn ghost" @click="$emit('close')">{{resultado ? 'Cerrar' : 'Cancelar'}}</button>
      <button class="btn" v-if="!resultado" @click="generar" :disabled="trabajando || !afectados">{{trabajando ? 'Generando…' : afectados ? 'Generar ' + afectados + (afectados === 1 ? ' código' : ' códigos') : 'Nada por generar'}}</button>
    </template>
  </Modal>`,
};

// ---- «Etiquetas»: varios productos, cuántas copias de cada uno, formato, medida e impresora ----
const leer = k => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
const recordar = (k, v) => { try { localStorage.setItem(k, String(v)); } catch { /* sin almacenamiento: no se recuerda */ } };
export function impresorasEtiquetas() { return (mock.get('pos_impresoras', []) || []).filter(i => i && i.nombre && i.activa !== false && esDeEtiquetas(i)); }

export const DialogoEtiquetas = {
  props: { productos: { type: Array, required: true } },
  emits: ['close', 'cambio'],
  data() {
    const imps = impresorasEtiquetas(), impId = impresoraPropuesta(imps, leer('etiquetas:impresora')) || (leer('etiquetas:impresora') === 'carta' ? 'carta' : '');
    const imp = imps.find(i => String(i.id) === impId);
    // con una impresora de etiquetas elegida al abrir (la única, o la última usada) la medida es la suya: es el rollo que tiene puesto. La
    // medida recordada en este navegador solo vale cuando se abre en «Elegir al imprimir (PDF)» o en hoja carta. Después se puede cambiar a mano
    const m = /^(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)$/.exec(leer('etiquetas:medida')), medida = imp ? medidaImpresora(imp) : m && medidaValida(+m[1], +m[2]) ? [+m[1], +m[2]] : [50, 30];
    const fmtRec = leer('etiquetas:formato');
    return {
      items: this.productos.map(p => ({ id: p.id, nombre: p.nombre, codigo: String(p.codigo || '').trim(), existencias: p.es_servicio || p.inventariable === false ? null : +p.existencias || 0, precio_texto: money(precioFinal(p), p.moneda || 'CRC'), copias: 1 })),
      copiasTodos: 1, formato: FORMATOS.some(f => f[0] === fmtRec) ? fmtRec : 'nombre_codigo', imps, impId,
      impFija: '', impRecordada: leer('etiquetas:impresora'), tocada: false,   // 4.25: la impresora de etiquetas de esta computadora (programa de escritorio)
      medidaSel: MEDIDAS.some(x => x[0] === medida[0] && x[1] === medida[1]) ? medida[0] + 'x' + medida[1] : 'personalizada', ancho: medida[0], alto: medida[1],
      trabajando: false, MEDIDAS, FORMATOS, COPIAS_MAX, ANCHO_MIN, ANCHO_MAX, ALTO_MIN, ALTO_MAX,
    };
  },
  // 4.25 (tanda 8): en el programa de escritorio, las impresoras de etiquetas como están en esta computadora (con las propias) y, si
  // esta computadora tiene su impresora de etiquetas elegida, esa sin preguntar. En la web no se pide nada (todo como antes).
  async created() {
    if (!sesion.empresaInfo?.es_local) return;
    const antes = this.impId;
    try {
      const A = await import('../pos/_agente.js'); if (!A.cargarEquipo) return;
      await A.cargarEquipo(); const eq = A.equipo(); if (!eq) return;
      this.imps = A.impresorasAqui(mock.get('pos_impresoras', []) || [], 'etiquetas', eq);
      const fija = eq.etiquetas && this.imps.some(i => String(i.id) === String(eq.etiquetas)) ? String(eq.etiquetas) : '';
      this.impFija = fija;
      if (this.impId !== antes) return;                              // ya la cambió a mano mientras cargaba
      const nueva = fija || impresoraPropuesta(this.imps, this.impRecordada) || (this.impRecordada === 'carta' ? 'carta' : '');
      if (nueva !== this.impId) { this.impId = nueva; this.alCambiarImpresora(); }
    } catch { /* sin el programa: como antes */ }
  },
  computed: {
    medida() { if (this.medidaSel === 'personalizada') return [+this.ancho || 0, +this.alto || 0]; const [a, h] = this.medidaSel.split('x'); return [+a, +h]; },
    total() { return totalEtiquetas(this.items); },
    conCopias() { return this.items.filter(x => copiasDe(x.copias) > 0); },
    sinCodigo() { return this.conCopias.filter(x => !x.codigo); },
    puedeGenerar() { return sesion.puede('catalogos'); },
    avisoSinCodigo() {
      const n = this.sinCodigo.length; if (!n) return '';
      return this.puedeGenerar ? (n === 1 ? '1 producto no tiene código: se le genera uno al imprimir' : n + ' productos no tienen código: se les genera uno al imprimir')
        : (n === 1 ? '1 producto no tiene código y no se imprime' : n + ' productos no tienen código y no se imprimen') + ': pida a quien administra los ítems que les genere uno';
    },
    // un código que ya tiene otro ítem (repetido de antes de la regla): la etiqueta se imprime, pero se avisa que la caja puede vender el otro
    avisoRepetidos() {
      const r = conCodigoRepetido(this.conCopias, store.productos); if (!r.length) return '';
      return (r.length === 1 ? '«' + r[0].nombre + '» tiene el mismo código que otro ítem («' + r[0].otro + '»)' : r.length + ' productos tienen el mismo código que otro ítem (' + r.slice(0, 3).map(x => x.nombre).join(', ') + (r.length > 3 ? '…' : '') + ')')
        + ': la caja toma el primero que encuentra, así que la etiqueta puede vender el otro. Cambie el código antes de imprimir.';
    },
    // barras muy finas para el lector con la medida elegida (cálculo aproximado): se avisa, no se impide
    avisoFinas() { return medidaValida(this.medida[0], this.medida[1]) ? avisoBarrasFinas(conBarrasFinas(this.conCopias, this.medida[0])) : ''; },
    imp() { return this.imps.find(i => String(i.id) === String(this.impId)) || null; },
    ayudaImpresora() {
      const fija = this.impFija ? this.imps.find(i => String(i.id) === this.impFija) : null;   // 4.25: la de etiquetas de esta computadora
      if (fija && String(this.impId) === this.impFija) return 'Es la impresora de etiquetas de esta computadora: ' + (directa(fija) ? 'sale directo en «' + fija.nombre + '»' : 'se abre un PDF del tamaño de la etiqueta para «' + fija.nombre + '»') + '. Puede elegir otra solo para esta vez';
      if (fija) return 'Solo para esta vez: la impresora de etiquetas de esta computadora sigue siendo «' + fija.nombre + '»';
      if (this.impId === 'carta') return 'Se abre un PDF en hoja carta con las etiquetas en cuadrícula, para recortar';
      if (!this.imp) return 'Se abre un PDF con una etiqueta por página, del tamaño de la etiqueta: al imprimirlo elija la impresora' + (this.imps.length ? '' : '. Puede dejar configurada la impresora de etiquetas en Punto de venta › Configuración › Impresoras');
      return directa(this.imp) ? 'Sale directo en «' + this.imp.nombre + '» con el programa de escritorio; sin él, se abre el PDF para imprimir a mano' : 'Se abre un PDF del tamaño de la etiqueta: al imprimirlo elija «' + this.imp.nombre + '»';
    },
    // vista previa: la primera etiqueta que se va a imprimir, con el mismo contenido (a un producto sin código se le muestra el que se le
    // generará; si la pantalla no tiene la marca de la empresa no lo supone: pone un código de muestra y lo dice)
    previa() {
      const x = this.conCopias[0] || this.items[0]; if (!x) return null;
      const propio = x.codigo ? '' : codigoBarrasPropio(x.id, marcaDe(store.empresa)), muestra = !x.codigo && !propio;
      const codigo = x.codigo || propio || codigoBarrasPropio(0, '000'), [a, h] = medidaValida(this.medida[0], this.medida[1]) ? this.medida : [50, 30];
      const ancho = Math.min(230, Math.max(110, a * 2.6)), alto = ancho * h / a;
      return { nombre: this.formato === 'solo_codigo' ? '' : x.nombre, codigo, muestra, precio: this.formato === 'nombre_codigo_precio' ? x.precio_texto : '', barras: barrasDe(codigo, esEan13(codigo)), ancho, alto, letra: Math.max(8, Math.min(13, alto * 0.11)) };
    },
  },
  methods: {
    fmtCant, copiasDe,
    aplicarTodos() { const n = copiasDe(this.copiasTodos); for (const x of this.items) x.copias = n; },
    segunExistencias() { for (const x of this.items) x.copias = x.existencias === null ? 1 : copiasPorExistencias(x.existencias); if (!this.total) toast('Ninguno de estos productos tiene existencias', 'err'); },
    quitar(i) { this.items.splice(i, 1); },
    alCambiarImpresora() { if (this.imp) { const [a, h] = medidaImpresora(this.imp); this.ancho = a; this.alto = h; this.medidaSel = MEDIDAS.some(x => x[0] === a && x[1] === h) ? a + 'x' + h : 'personalizada'; } },
    // a los que no tienen código se les genera primero (con permiso); devuelve false si no queda nada por imprimir
    async prepararCodigos() {
      const faltan = this.sinCodigo; if (!faltan.length) return true;
      if (this.puedeGenerar) {
        const g = await api('/api/productos/codigos/generar', { method: 'POST', body: { ids: faltan.map(x => x.id) } });
        let n = 0;
        for (const x of faltan) { const c = g.codigos && g.codigos[x.id]; if (c) { x.codigo = c; n++; store.poner('productos', { id: x.id, codigo: c }); } }
        if (n) { toast(n === 1 ? 'Se generó el código de 1 producto' : 'Se generó el código de ' + n + ' productos', 'ok'); this.$emit('cambio'); }
        if ((g.no_se_pudo || []).length) toast(g.no_se_pudo.length + ' sin código: ' + g.no_se_pudo[0].motivo, 'err');
      } else toast(this.avisoSinCodigo, 'err');
      return this.conCopias.some(x => x.codigo);
    },
    async imprimir(descargar) {
      if (this.trabajando) return;
      if (!this.total) return toast('Indique cuántas copias quiere de al menos un producto', 'err');
      if (this.total > ETIQUETAS_MAX) return toast('Un pedido lleva hasta 3.000 etiquetas: imprímalas en varias tandas', 'err');
      if (!medidaValida(this.medida[0], this.medida[1])) return toast('La medida va de ' + ANCHO_MIN + ' a ' + ANCHO_MAX + ' mm de ancho y de ' + ALTO_MIN + ' a ' + ALTO_MAX + ' mm de alto', 'err');
      this.trabajando = true;
      try {
        if (!(await this.prepararCodigos())) { this.trabajando = false; return; }
        const lista = this.conCopias.filter(x => x.codigo), n = totalEtiquetas(lista), imp = this.imp;
        recordar('etiquetas:formato', this.formato); recordar('etiquetas:medida', this.medida[0] + 'x' + this.medida[1]); recordar('etiquetas:impresora', this.impId);
        if (this.impFija) recordar('etiquetas:impresora', this.impRecordada);   // 4.25: con la de esta computadora elegida, otra vale solo por esta vez
        if (!descargar && directa(imp)) {
          const est = await agenteEstado(true);
          if (sabeEtiquetas(est)) {
            try { await imprimirEtiquetas(imp, trabajoEtiquetas(imp, lista, this.formato, this.medida)); toast((n === 1 ? '1 etiqueta enviada' : n + ' etiquetas enviadas') + ' a «' + imp.nombre + '»', 'ok'); this.trabajando = false; return; }
            catch (e) {
              // el servicio respondió con un motivo (no cabe, muy baja, la impresora no está…): se muestra completo, con la impresora que
              // falló (el motivo de una impresora apagada o mal escrita es técnico: «timed out»), y NO se abre el PDF (daría el mismo
              // rechazo); la vuelta al PDF es solo para cuando el servicio no responde o no sabe de etiquetas
              if (e.rechazo) { toast(await avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e), 'err'); this.trabajando = false; return; }
              toast(await avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre el PDF para imprimir a mano.', 'err');
            }
          } else toast('El envío directo necesita el programa de escritorio actualizado: se abre el PDF para imprimir a mano', 'err');
        }
        // dpi: la resolución de la impresora de etiquetas elegida (las barras del PDF miden puntos enteros de ella); con «Elegir al imprimir» o en hoja carta no se manda
        // 'etiquetas.pdf' al final: si el navegador bloquea la ventana del PDF, el archivo ya preparado queda en las descargas (no hay que pedirlo otra vez)
        const abierto = await abrirArchivo('/api/productos/etiquetas', descargar ? 'etiquetas.pdf' : null, { items: lista.map(x => ({ id: x.id, copias: copiasDe(x.copias) })), formato: this.formato, ancho_mm: this.medida[0], alto_mm: this.medida[1], hoja: this.impId === 'carta' ? 'carta' : null, ...(imp && +imp.dpi ? { dpi: +imp.dpi } : {}) }, 'etiquetas.pdf');
        if (abierto === 'descargado') toast('El navegador no dejó abrir la ventana: el PDF quedó en sus descargas');
      } catch (e) { toast(e.message, 'err'); }
      this.trabajando = false;
    },
  },
  template: `
  <Modal title="Etiquetas con código de barras" lg @close="$emit('close')">
    <div style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start">
      <div style="flex:1 1 380px;min-width:0">
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px">
          <span class="small">Copias para todos</span><input class="inp" type="number" min="0" :max="COPIAS_MAX" v-model.number="copiasTodos" style="width:80px"><button class="btn sm sec" @click="aplicarTodos">Aplicar</button>
          <button class="btn sm sec" @click="segunExistencias" title="Una etiqueta por cada unidad en existencia (los que no tienen existencias quedan en 0 y no se imprimen)">Según existencias</button>
        </div>
        <div class="table-wrap" style="max-height:320px;overflow:auto">
          <table class="tbl"><thead><tr><th>Producto</th><th class="num">Existencias</th><th class="num">Copias</th><th></th></tr></thead>
            <tbody><tr v-for="(x, i) in items" :key="x.id" :style="copiasDe(x.copias) === 0 ? 'opacity:.55' : ''"><td class="parte fina">{{x.nombre}}<div class="mono small muted">{{x.codigo || 'Sin código'}}</div></td><td class="num">{{x.existencias === null ? '—' : fmtCant(x.existencias)}}</td>
              <td class="num"><input class="inp" type="number" min="0" :max="COPIAS_MAX" step="1" v-model.number="x.copias" @change="x.copias = copiasDe(x.copias)" style="width:60px;padding:8px 6px;text-align:right" :aria-label="'Copias de ' + x.nombre"></td>
              <td style="padding-left:0"><button class="btn icon" title="Quitar de la lista" @click="quitar(i)">×</button></td></tr></tbody></table>
        </div>
        <p style="margin:10px 0 0"><b>Total: {{total}} {{total === 1 ? 'etiqueta' : 'etiquetas'}}</b> <span class="small muted">de {{conCopias.length}} {{conCopias.length === 1 ? 'producto' : 'productos'}} · hasta 500 por producto y 3.000 por pedido</span></p>
        <div class="alert warn" v-if="avisoSinCodigo" style="margin:10px 0 0">{{avisoSinCodigo}}</div>
        <div class="alert warn" v-if="avisoRepetidos" style="margin:10px 0 0">{{avisoRepetidos}}</div>
        <div class="alert warn" v-if="avisoFinas" style="margin:10px 0 0">{{avisoFinas}}</div>
      </div>
      <div style="flex:0 1 250px;min-width:220px;display:flex;flex-direction:column;gap:10px">
        <Field label="Formato"><select v-model="formato"><option v-for="f in FORMATOS" :key="f[0]" :value="f[0]">{{f[1]}}</option></select></Field>
        <Field label="Medida de la etiqueta"><select v-model="medidaSel"><option v-for="m in MEDIDAS" :key="m[0] + 'x' + m[1]" :value="m[0] + 'x' + m[1]">{{m[0]}} × {{m[1]}} mm</option><option value="personalizada">Personalizada</option></select></Field>
        <div class="grid cols-2" v-if="medidaSel==='personalizada'"><Field label="Ancho (mm)"><input type="number" :min="ANCHO_MIN" :max="ANCHO_MAX" v-model.number="ancho"></Field><Field label="Alto (mm)"><input type="number" :min="ALTO_MIN" :max="ALTO_MAX" v-model.number="alto"></Field></div>
        <Field label="Impresora" :help="ayudaImpresora"><select v-model="impId" @change="alCambiarImpresora"><option value="">Elegir al imprimir (PDF)</option><option v-for="i in imps" :key="i.id" :value="String(i.id)">{{i.nombre}}</option><option value="carta">Impresora común, en hoja carta (PDF)</option></select></Field>
        <div v-if="previa"><div class="small muted" style="margin-bottom:4px">Vista previa</div>
          <div :style="{ width: previa.ancho + 'px', height: previa.alto + 'px', border: '1px solid var(--line)', borderRadius: '4px', background: '#fff', color: '#000', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '4px', boxSizing: 'border-box', overflow: 'hidden', textAlign: 'center' }">
            <div v-if="previa.nombre" :style="{ fontSize: previa.letra + 'px', fontWeight: 700, lineHeight: 1.15, maxHeight: (previa.letra * 2.3) + 'px', overflow: 'hidden', width: '100%' }">{{previa.nombre}}</div>
            <svg v-if="previa.barras.ancho" :viewBox="'0 0 ' + previa.barras.ancho + ' 10'" preserveAspectRatio="none" style="width:100%;flex:1 1 auto;min-height:14px;margin:2px 0"><rect v-for="t in previa.barras.tramos" :key="t.x" :x="t.x" y="0" :width="t.w" height="10" fill="#000"></rect></svg>
            <div class="mono" :style="{ fontSize: Math.max(8, previa.letra * 0.85) + 'px', lineHeight: 1.1 }">{{previa.codigo}}</div>
            <div v-if="previa.precio" :style="{ fontSize: (previa.letra * 1.2) + 'px', fontWeight: 700, lineHeight: 1.15 }">{{previa.precio}}</div>
          </div>
          <div class="small muted" v-if="previa.muestra" style="margin-top:4px">Código de muestra: el código se genera al imprimir</div></div>
      </div>
    </div>
    <template #foot>
      <button class="btn ghost" @click="$emit('close')">Cerrar</button>
      <button class="btn sec" @click="imprimir(true)" :disabled="trabajando || !items.length">Descargar PDF</button>
      <button class="btn" @click="imprimir(false)" :disabled="trabajando || !items.length">{{trabajando ? 'Preparando…' : 'Imprimir'}}</button>
    </template>
  </Modal>`,
};
