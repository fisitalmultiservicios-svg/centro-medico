// Inventario — Categorías de ítems (registro 'categorias' del servidor; los ejemplos solo en la demo)
import { mock, toast, api } from '../../api.js';

const EJEMPLO = [
  { id: 1, nombre: 'Abarrotes', descripcion: 'Alimentos empacados y productos de consumo básico', imagen: '' },
  { id: 2, nombre: 'Bebidas', descripcion: 'Refrescos, jugos, agua embotellada y bebidas calientes', imagen: '' },
  { id: 3, nombre: 'Ferretería', descripcion: 'Herramientas, tornillería y materiales de construcción', imagen: '' },
  { id: 4, nombre: 'Electrónica', descripcion: 'Equipos, accesorios y repuestos electrónicos', imagen: '' },
  { id: 5, nombre: 'Hogar', descripcion: 'Artículos para el hogar, limpieza y decoración', imagen: '' },
  { id: 6, nombre: 'Papelería', descripcion: 'Útiles de oficina y material escolar', imagen: '' },
  { id: 7, nombre: 'Ropa y calzado', descripcion: 'Prendas de vestir y calzado para toda la familia', imagen: '' },
  { id: 8, nombre: 'Servicios', descripcion: 'Servicios profesionales, mantenimiento y consultoría', imagen: '' },
];

import { store } from '../../app.js';

export default {
  props: ['params'],
  data() { return { lista: mock.ejemplos('categorias', EJEMPLO, 'nombre'), q: '', f: null, extra: mock.get('items_extra', {}) }; },
  computed: {
    // raíces primero y sus subcategorías debajo (el punto de venta las muestra como botón y subbotón)
    rows() {
      const n = Object.fromEntries(this.lista.map(c => [c.id, c.nombre]));
      const fila = c => ({ ...c, padre: c.padre_id ? (n[c.padre_id] || '—') : '', items: (store.productos || []).filter(p => (p.categoria || '') === c.nombre).length });   // productos reales (R119)
      const out = [];
      for (const r of this.lista.filter(c => !c.padre_id || !n[c.padre_id])) { out.push(fila(r)); for (const h of this.lista.filter(c => c.padre_id === r.id)) out.push(fila(h)); }
      return out;
    },
    raices() { return this.lista.filter(c => !c.padre_id && (!this.f || c.id !== this.f.id)); },
    columns() {
      return [
        { key: 'nombre', label: 'Nombre', fmt: (v, r) => (r.padre_id ? '   ↳ ' : '') + (r.icono ? r.icono + ' ' : '') + (r.imagen ? '🖼 ' : '') + v },
        { key: 'padre', label: 'Dentro de', fmt: v => v || '—' },
        { key: 'descripcion', label: 'Descripción', fmt: v => v || '—' },
        { key: 'items', label: 'Ítems', num: true },
      ];
    },
  },
  methods: {
    // al renombrar o eliminar una categoría, los productos del servidor se actualizan (R119)
    async renombrarEnProductos(antes, despues) { const ps = (store.productos || []).filter(p => (p.categoria || '') === antes); for (const p of ps) { try { await api('/api/productos/' + p.id, { method: 'PUT', body: { categoria: despues || null } }); } catch {} } if (ps.length) store.cargar(); },
    nuevo(padreId) { this.f = { id: null, nombre: '', descripcion: '', imagen: '', icono: '', padre_id: Number.isInteger(padreId) ? padreId : null }; },
    editar(r) { const { items, padre, ...c } = r; this.f = { ...c, padre_id: c.padre_id || null, icono: c.icono || '' }; },
    imagen(ev) { const file = ev.target.files?.[0] || ev.dataTransfer?.files?.[0]; if (!file) return; if (!file.type.startsWith('image/')) return toast('Seleccione un archivo de imagen', 'err'); if (file.size > 100000) return toast('La imagen debe pesar menos de 100 KB', 'err'); if (false) return toast('La imagen debe pesar menos de 300 KB', 'err'); const r = new FileReader(); r.onload = () => this.f.imagen = r.result; r.readAsDataURL(file); },
    guardar() {
      if (!this.f.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      if (this.lista.some(c => c.nombre.toLowerCase() === this.f.nombre.trim().toLowerCase() && c.id !== this.f.id)) return toast('Ya existe una categoría con ese nombre', 'err');
      if (this.f.imagen && this.f.imagen.length > 140000) return toast('La imagen es demasiado grande para guardarla aquí (máximo 100 KB)', 'err');   // (R118)
      if (this.f.padre_id) {
        const padre = this.lista.find(c => c.id === this.f.padre_id);
        if (!padre || padre.padre_id) return toast('Solo hay dos niveles: una subcategoría no puede estar dentro de otra subcategoría', 'err');
        if (this.f.id && this.lista.some(c => c.padre_id === this.f.id)) return toast('Esta categoría tiene subcategorías: no puede convertirse en subcategoría', 'err');
      }
      this.f.icono = (this.f.icono || '').trim().slice(0, 4);
      if (this.f.id) { const i = this.lista.findIndex(c => c.id === this.f.id); const antes = this.lista[i]?.nombre; this.lista[i] = { ...this.f }; if (antes && antes !== this.f.nombre.trim()) this.renombrarEnProductos(antes, this.f.nombre.trim()); }
      else this.lista.push({ ...this.f, id: mock.nextId(this.lista, 'categorias') });
      mock.set('categorias', this.lista); toast('Categoría guardada', 'ok'); this.f = null;
    },
    eliminar(r) { if (this.lista.some(c => c.padre_id === r.id)) return toast('Elimine o mueva primero sus subcategorías', 'err'); if (!confirm('¿Eliminar la categoría "' + r.nombre + '"?' + (r.items ? ' Los ' + r.items + ' ítems asociados quedarán sin categoría.' : ''))) return; this.renombrarEnProductos(r.nombre, ''); this.lista = this.lista.filter(c => c.id !== r.id); mock.set('categorias', this.lista); toast('Categoría eliminada', 'ok'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = this.lista.filter(c => !ids.includes(c.id)); mock.set('categorias', this.lista); toast(ids.length + ' categorías eliminadas', 'ok'); },
  },
  template: `
  <div class="page">
    <PageHead title="Categorías" sub="Agrupe sus ítems en categorías y subcategorías: en el punto de venta son los botones y subbotones para encontrar los productos.">
      <button class="btn" v-if="puede('catalogos')" @click="nuevo(null)">+ Nueva categoría</button>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar categoría" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('catalogos')" :on-bulk-delete="eliminarVarios" empty-title="Sin categorías" empty-text="Cree categorías para clasificar sus productos y servicios.">
        <template #actions="{row}">
          <button class="btn sm ghost" v-if="!row.padre_id" @click.stop="nuevo(row.id)" title="Agregar una subcategoría dentro de esta">+ Sub</button>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="editar(row)" title="Editar">✎</button>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><button class="btn" v-if="puede('catalogos')" @click="nuevo(null)">+ Nueva categoría</button></template>
      </DataTable>
    </div>
    <Modal v-if="f" :title="f.id?'Editar categoría':'Nueva categoría'" @close="f=null">
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Nombre" req><input v-model="f.nombre"></Field>
        <Field label="Dentro de" help="Vacío = categoría principal (botón); con padre = subcategoría (subbotón)"><select v-model="f.padre_id"><option :value="null">— Categoría principal —</option><option v-for="c in raices" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
        <Field label="Icono" help="Un emoji para el botón del punto de venta (opcional): 🍔 🥤 🧴 👕"><input v-model="f.icono" maxlength="4" placeholder="🍔"></Field>
        <Field label="Descripción"><textarea rows="2" v-model="f.descripcion"></textarea></Field>
        <Field label="Imagen">
          <label class="drop" style="display:block;padding:0;overflow:hidden" @dragover.prevent @drop.prevent="imagen">
            <img v-if="f.imagen" :src="f.imagen" style="width:100%;max-height:160px;object-fit:contain;display:block">
            <div v-else style="padding:20px">🖼<br>Arrastre una imagen aquí o haga clic para seleccionarla</div>
            <input type="file" accept="image/*" style="display:none" @change="imagen">
          </label>
          <button class="btn ghost sm" style="margin-top:6px;align-self:flex-start" v-if="f.imagen" @click.prevent="f.imagen=''">Quitar imagen</button>
        </Field>
      </div>
      <template #foot><button class="btn ghost" @click="f=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};
