// Exoneraciones de IVA del cliente (v1.28): se cargan desde el PDF o el número de autorización y se validan contra Hacienda
// (beneficiario, vigencia, tarifa y CABYS autorizados); los tipos sin consulta pública (diplomáticos, ley especial, zona franca,
// otros) se registran a mano con su PDF de respaldo. Al facturar a este cliente la exoneración se aplica sola.
import { api, toast, fecha, abrirArchivo } from '../../api.js';
import ExoneracionRapida from './exoneracion-rapida.js';

export const TIPOS_EXO = {
  '01': 'Compras autorizadas por la DGT (solo notas)', '02': 'Ventas exentas a diplomáticos', '03': 'Autorizado por ley especial',
  '04': 'Exención DGH, autorización local genérica', '05': 'Transitorio V (solo notas)', '06': 'Servicios turísticos ICT (solo notas)',
  '07': 'Transitorio XVII (solo notas)', '08': 'Zona franca', '09': 'Servicios complementarios a la exportación', '10': 'Corporaciones municipales',
  '11': 'Exención DGH, autorización concreta (solo notas)', '99': 'Otros',
};
export const INSTITUCIONES_EXO = {
  '01': 'Ministerio de Hacienda', '02': 'Ministerio de Relaciones Exteriores y Culto', '03': 'Ministerio de Agricultura y Ganadería',
  '04': 'Ministerio de Economía, Industria y Comercio', '05': 'Cruz Roja Costarricense', '06': 'Cuerpo de Bomberos', '07': 'Obras del Espíritu Santo',
  '08': 'Fecrunapa', '09': 'EARTH', '10': 'INCAE', '11': 'Junta de Protección Social', '12': 'Aresep', '99': 'Otra institución',
};
const ESTADOS = { vigente: 'Vigente', por_vencer: 'Por vencer', vencida: 'Vencida', inactiva: 'Desactivada' };

export default {
  name: 'ExoneracionesCliente',
  components: { ExoneracionRapida },
  props: { clienteId: { type: [Number, String], required: true }, numeroId: { type: String, default: '' } },
  data() {
    return { lista: [], cargando: true, modo: null, archivo: null, leyendo: false, consultando: false, guardando: false, numeros: [],
      numero: '', consulta: null, m: this.vacioManual(), TIPOS_EXO, INSTITUCIONES_EXO, ESTADOS };
  },
  computed: {
    tiposManual() { return Object.entries(TIPOS_EXO).filter(([k]) => !['04', '11'].includes(k)); },
    coincide() { const n = x => String(x || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase().replace(/^0+/, ''); return !!this.consulta && n(this.consulta.identificacion) === n(this.numeroId); },
  },
  methods: {
    fecha,
    fd(x) { return fecha(String(x || '').slice(0, 10)); },   // fecha del documento (sin hora): tal cual, sin pasarla por la zona horaria
    vacioManual() { return { tipo: '03', tipo_otro: '', numero: '', articulo: null, inciso: null, institucion: '01', institucion_otro: '', fecha_emision: '', fecha_vencimiento: '', tarifa: 13, cabys: '', notas: '' }; },
    async cargar() {
      this.cargando = true;
      try { this.lista = await api(`/api/clientes/${this.clienteId}/exoneraciones`); } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    abrir(modo) { this.modo = modo; this.archivo = null; this.numeros = []; this.numero = ''; this.consulta = null; this.m = this.vacioManual(); },
    async elegirPdf(ev) {
      const f = ev.target.files && ev.target.files[0]; this.archivo = f || null; this.numeros = [];
      if (f && f.size > 5 * 1024 * 1024) { this.archivo = null; ev.target.value = ''; return toast('El PDF supera 5 MB', 'err'); }
      if (!f || this.modo !== 'hacienda') return;
      this.leyendo = true;
      try {
        const fd = new FormData(); fd.append('archivo', f);
        const r = await api('/api/exoneraciones/leer-pdf', { method: 'POST', body: fd });
        this.numeros = r.numeros || [];
        if (this.numeros.length) { this.numero = this.numeros[0]; await this.consultar(); }
        else toast('No se encontró el número de autorización en el PDF (puede ser una imagen escaneada): escríbalo abajo', 'err');
      } catch (e) { toast(e.message, 'err'); }
      this.leyendo = false;
    },
    async consultar() {
      const n = String(this.numero || '').trim().toUpperCase();
      if (!n) return toast('Escriba el número de autorización (p. ej. AL-00020402-24)', 'err');
      const turno = (this._turno = (this._turno || 0) + 1);   // consultas solapadas: solo vale la última
      this.consultando = true; this.consulta = null;
      try { const r = await api('/api/exoneraciones/consultar', { method: 'POST', body: { numero: n } }); if (turno === this._turno) this.consulta = r; }
      catch (e) { if (turno === this._turno) toast(e.message, 'err'); }
      if (turno === this._turno) this.consultando = false;
    },
    async subirPdf(id) {
      if (!this.archivo) return;
      const fd = new FormData(); fd.append('archivo', this.archivo);
      try { await api(`/api/exoneraciones/${id}/pdf`, { method: 'POST', body: fd }); } catch (e) { toast('La exoneración quedó registrada, pero el PDF no se pudo guardar: ' + e.message, 'err'); }
    },
    async registrarHacienda() {
      if (!this.consulta) return;
      this.guardando = true;
      try {
        const x = await api(`/api/clientes/${this.clienteId}/exoneraciones`, { method: 'POST', body: { origen: 'hacienda', numero: this.consulta.numero } });
        await this.subirPdf(x.id);
        toast('Exoneración ' + x.numero + ' registrada y verificada con Hacienda', 'ok'); this.modo = null; await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async registrarManual() {
      const m = this.m;
      if (!m.numero.trim() || !m.fecha_emision || !(+m.tarifa > 0)) return toast('Complete número, fecha de emisión y tarifa exonerada', 'err');
      this.guardando = true;
      try {
        const body = { origen: 'manual', numero: m.numero.trim(), tipo: m.tipo, tipo_otro: m.tipo === '99' ? m.tipo_otro : null, articulo: m.articulo || null, inciso: m.inciso || null,
          institucion: m.institucion, institucion_otro: m.institucion === '99' ? m.institucion_otro : null, fecha_emision: m.fecha_emision, fecha_vencimiento: m.fecha_vencimiento || null,
          tarifa: +m.tarifa, cabys: (m.cabys.match(/\d{13}/g) || []), notas: m.notas || null };
        const x = await api(`/api/clientes/${this.clienteId}/exoneraciones`, { method: 'POST', body });
        await this.subirPdf(x.id);
        toast('Exoneración ' + x.numero + ' registrada', 'ok'); this.modo = null; await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async verificar(x) {
      try { await api(`/api/exoneraciones/${x.id}/verificar`, { method: 'POST' }); toast('Verificada con Hacienda', 'ok'); } catch (e) { toast(e.message, 'err'); }
      await this.cargar();
    },
    async activar(x) {
      try { await api(`/api/exoneraciones/${x.id}`, { method: 'PUT', body: { numero: x.numero, activa: !x.activa } }); } catch (e) { toast(e.message, 'err'); }
      await this.cargar();
    },
    async borrar(x) {
      if (!confirm('¿Eliminar la exoneración ' + x.numero + '? Si ya se usó en comprobantes solo se desactiva.')) return;
      try { const r = await api(`/api/exoneraciones/${x.id}`, { method: 'DELETE' }); toast(r.desactivada ? 'Se usó en comprobantes: quedó desactivada' : 'Exoneración eliminada', 'ok'); } catch (e) { toast(e.message, 'err'); }
      await this.cargar();
    },
    async verPdf(x) { try { await abrirArchivo(`/api/exoneraciones/${x.id}/pdf`); } catch (e) { toast(e.message, 'err'); } },
    pct(v) { return (+v || 0).toLocaleString('es-CR', { maximumFractionDigits: 2 }) + ' %'; },
  },
  watch: { clienteId() { this.cargar(); } },
  created() { this.cargar(); },
  template: `
  <div class="card">
    <h2>Exoneraciones de IVA <small>Se aplican solas al facturar a este cliente, solo en los CABYS autorizados</small></h2>
    <p class="muted small" v-if="cargando">Cargando…</p>
    <template v-else>
      <div class="table-wrap" v-if="lista.length"><table class="tbl">
        <thead><tr><th>Documento</th><th>Tipo</th><th class="num">Tarifa</th><th>Vence</th><th>CABYS</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="x in lista" :key="x.id">
          <td><b class="mono">{{x.numero}}</b><div class="small muted">{{x.institucion_nombre}} · {{x.origen==='hacienda' ? 'verificada con Hacienda' + (x.verificada_en ? ' el ' + fecha(x.verificada_en) : '') : 'registrada a mano'}}</div></td>
          <td class="small">{{x.tipo}} · {{TIPOS_EXO[x.tipo] || x.tipo_nombre}}</td>
          <td class="num">{{pct(x.tarifa)}}</td>
          <td>{{x.fecha_vencimiento ? fecha(x.fecha_vencimiento) : 'Sin vencimiento'}}</td>
          <td class="small">{{x.posee_cabys ? x.cabys.length + ' autorizados' : 'Todos'}}</td>
          <td><Badge :value="ESTADOS[x.estado] || x.estado"></Badge></td>
          <td style="white-space:nowrap">
            <button class="btn icon" v-if="x.tiene_pdf" title="Ver PDF" @click="verPdf(x)">📄</button>
            <button class="btn icon" v-if="x.origen==='hacienda' && (puede('catalogos') || puede('facturar'))" title="Volver a verificar con Hacienda" @click="verificar(x)">↻</button>
            <button class="btn icon" v-if="puede('catalogos')" :title="x.activa ? 'Desactivar' : 'Activar'" @click="activar(x)">{{x.activa ? '⏸' : '▶'}}</button>
            <button class="btn icon" v-if="puede('catalogos')" title="Eliminar" @click="borrar(x)">✕</button>
          </td>
        </tr></tbody>
      </table></div>
      <p class="muted small" v-else>Este cliente no tiene exoneraciones registradas.</p>
      <div class="row" style="margin-top:8px;gap:8px" v-if="puede('catalogos') || puede('facturar') || puede('pos')">
        <button class="btn sec sm" @click="abrir('hacienda')">+ Autorización de Hacienda (PDF o número)</button>
        <button class="btn ghost sm" v-if="puede('catalogos')" @click="abrir('manual')">+ Otro tipo (registro manual)</button>
      </div>
    </template>

    <ExoneracionRapida v-if="modo==='hacienda'" :cliente-id="clienteId" :numero-id="numeroId" @close="modo=null" @registrada="modo=null; cargar()"></ExoneracionRapida>

    <Modal v-if="modo==='manual'" title="Registrar exoneración (sin consulta en Hacienda)" @close="modo=null">
      <p class="small muted" style="margin-top:0">Para diplomáticos, leyes especiales, zona franca y otros documentos que Hacienda no publica. Las autorizaciones de Hacienda (tipos 04 y 11) se registran con su número.</p>
      <div class="grid cols-2">
        <Field label="Tipo de documento" req><select v-model="m.tipo"><option v-for="[k, v] in tiposManual" :key="k" :value="k">{{k}} · {{v}}</option></select></Field>
        <Field label="Descripción del tipo" req v-if="m.tipo==='99'" help="5 a 100 caracteres"><input v-model="m.tipo_otro" maxlength="100"></Field>
        <Field label="Número de documento" req :help="['02','03','08'].includes(m.tipo) ? 'El número de la ley' : ''"><input v-model="m.numero" maxlength="40"></Field>
        <Field label="Artículo" :req="['02','03','06','07','08'].includes(m.tipo)"><input type="number" min="0" max="999999" v-model.number="m.articulo"></Field>
        <Field label="Inciso"><input type="number" min="0" max="999999" v-model.number="m.inciso"></Field>
        <Field label="Institución que la emitió" req><select v-model="m.institucion"><option v-for="(v, k) in INSTITUCIONES_EXO" :key="k" :value="k">{{k}} · {{v}}</option></select></Field>
        <Field label="Nombre de la institución" req v-if="m.institucion==='99'"><input v-model="m.institucion_otro" maxlength="160"></Field>
        <Field label="Fecha de emisión" req><input type="date" v-model="m.fecha_emision"></Field>
        <Field label="Fecha de vencimiento"><input type="date" v-model="m.fecha_vencimiento"></Field>
        <Field label="Tarifa exonerada (puntos de IVA)" req help="13 = no se cobra nada del 13 %"><input type="number" step="0.01" min="0.01" max="13" v-model.number="m.tarifa"></Field>
        <Field label="PDF del documento"><input type="file" accept="application/pdf,.pdf" @change="elegirPdf"></Field>
        <Field label="CABYS autorizados" style="grid-column:1/-1" help="Vacío = aplica a todos los ítems gravados. Varios códigos separados por coma o espacio"><textarea rows="2" v-model="m.cabys" class="mono"></textarea></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="m.notas" maxlength="500"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modo=null">Cancelar</button><button class="btn" :disabled="guardando" @click="registrarManual">{{guardando ? 'Guardando…' : 'Registrar'}}</button></template>
    </Modal>
  </div>`,
};
