// Contactos — formulario avanzado (backend real /api/clientes: POST al crear, PUT al editar; todos los campos del modelo)
import { api, toast, mock, CAT, opts, money, monedas, hoy } from '../../api.js';
import { store, sesion, rutaPermitida } from '../../app.js';
import { telefonoWa, enlaceWhatsApp, textoEstadoCuenta } from '../reportes/_revendedoras.js';   // 4.9: la cuenta del cliente y su envío
import { cantones, distritos } from '../../ubicaciones.js';
import ExoneracionesCliente from './exoneraciones.js';

const CUENTAS_COBRAR = ['1105 Cuentas por cobrar clientes', '1106 Documentos por cobrar', '1107 Anticipos a proveedores'];
const CUENTAS_PAGAR = ['2105 Cuentas por pagar proveedores', '2106 Documentos por pagar', '2107 Anticipos de clientes'];

export default {
  props: ['params'],
  components: { ExoneracionesCliente },
  data() {
    return {
      f: this.vacio(), cedulaGuardada: '', tipoGuardado: '', personas: [], dirs: [], persona: null, guardando: false, buscando: false, cargando: !!this.params.id,
      cred: null,   // 4.9: límite, saldo, en pedidos y disponible (GET /api/revendedoras/{id}/credito)
      sec: { general: true, contacto: true, comercial: false, contab: false },
      // Sin backend aún (se conservan en mock 'contactos_extra' por id): personas asociadas, lista de precios y cuentas contables
      extra: mock.get('contactos_extra', {}),
      CAT, opts, CUENTAS_COBRAR, CUENTAS_PAGAR,
    };
  },
  computed: {
    listasPrecios() { const l = mock.get('listas_precios', []) || []; return l.some(x => x.principal) ? l : [{ id: 1, nombre: 'General', principal: true }, ...l]; },
    editando() { return !!this.params.id; },
    // 3.87: lo que el servidor acepta: catálogos todo; quien lleva gastos (Contador), sus proveedores; la caja, crear clientes. Sin eso la ficha es de consulta
    puedeGuardar() { return sesion.puede('catalogos') || (sesion.puede('gastos') && this.f.tipo === 'Proveedor' && (!this.editando || this.tipoGuardado === 'Proveedor')) || (!this.editando && sesion.puede('pos') && this.f.tipo === 'Cliente'); },
    tiposContacto() { return sesion.puede('catalogos') ? ['Cliente', 'Proveedor', 'Ambos'] : (this.editando ? [this.tipoGuardado || this.f.tipo] : [...(sesion.puede('pos') ? ['Cliente'] : []), ...(sesion.puede('gastos') ? ['Proveedor'] : [])]); },
    titulo() { return this.editando ? 'Editar ' + this.f.tipo.toLowerCase() : 'Nuevo contacto'; },
    // 4.9: tarjeta «Cuenta del cliente» (solo editando un cliente y con los permisos del estado de cuenta)
    verCuenta() { return this.editando && this.f.tipo !== 'Proveedor' && !!this.cred; },
    monedaP() { return (monedas.principal() || { codigo: 'CRC' }).codigo; },
    waCuenta() { const e = store.empresa || {}; return this.cred ? enlaceWhatsApp(telefonoWa(this.f), textoEstadoCuenta({ empresa: e.nombre_comercial || e.nombre || '', nombre: this.f.nombre_comercial || this.f.nombre, credito: this.cred, moneda: this.monedaP, al: hoy() })) : ''; },
    telCuenta() { return telefonoWa(this.f); },
  },
  methods: {
    vacio() {
      const t = (this.params.tipo || ((sesion.puede('catalogos') || sesion.puede('pos')) ? 'cliente' : 'proveedor')).toLowerCase();   // 3.87: el Contador arranca en «Proveedor»
      return { tipo: t === 'proveedor' ? 'Proveedor' : t === 'ambos' ? 'Ambos' : 'Cliente', numero_id: this.params.numero || '', tipo_id: '01', nombre: this.params.nombre ? decodeURIComponent(this.params.nombre) : '', nombre_comercial: '', actividad: '',
        provincia: null, canton: null, distrito: null, /* sin ubicación hasta que el usuario la elija (antes San José, Carmen) (R248) */ barrio: '', direccion: '', correo: '', correo_facturas: '', correo_cc: '', telefono: '', celular: '', termino_pago_dias: 0, limite_credito: 0, vendedor: '',
        enviar_estado_cuenta: false, comentarios: '', activo: true,
        lista_precios_id: 1, cuenta_cobrar: CUENTAS_COBRAR[0], cuenta_pagar: CUENTAS_PAGAR[0] };
    },
    async cargar() {
      let base = null;
      try { base = await api('/api/clientes/' + this.params.id); if (base) store.poner('clientes', base); } catch {}   // 4.6: la ficha fresca (la caja pudo agregarle direcciones desde otro equipo)
      if (!base) base = store.clientes.find(c => c.id == this.params.id);
      if (!base) { try { const l = await api('/api/clientes'); base = l.find(c => c.id == this.params.id); } catch (e) { toast(e.message, 'err'); } }
      if (!base) { toast('Contacto no encontrado', 'err'); location.hash = '/contactos'; return; }
      const ex = this.extra[this.params.id] || {};
      this.f = { ...this.vacio(), ...ex, ...base,
        tipo: base.tipo || 'Cliente', nombre_comercial: base.nombre_comercial || '', telefono: base.telefono || '', celular: base.celular || '', correo: base.correo || '', actividad: base.actividad || '',
        provincia: base.provincia ?? null, canton: base.canton ?? null, distrito: base.distrito ?? null, barrio: base.barrio || '', direccion: base.direccion || '',
        termino_pago_dias: base.termino_pago_dias ?? 0, limite_credito: base.limite_credito ?? 0, vendedor: base.vendedor || '', comentarios: base.comentarios || '',
        enviar_estado_cuenta: !!base.enviar_estado_cuenta, activo: base.activo !== false };
      this.tipoGuardado = base.tipo || 'Cliente';   // 3.87: el tipo guardado decide si el Contador puede corregirlo
      this.cedulaGuardada = String(base.numero_id || '');   // la exoneración se compara con la cédula guardada (la que valida el servidor)
      this.personas = ex.personas || [];
      this.dirs = this.parseDirs(base.direcciones);   // 4.6: otras direcciones (casa, trabajo…)
      if (this.f.lista_precios_id === undefined || this.f.lista_precios_id === null) { const l = this.listasPrecios.find(x => x.nombre === ex.lista_precios); this.f.lista_precios_id = l ? l.id : 1; }   // contactos guardados con el nombre de la lista (R282)
      this.cargando = false;
      if (this.f.tipo !== 'Proveedor') this.cargarCredito();   // 4.9: sin esperar: la ficha ya se puede usar
    },
    // 4.9: la cuenta del cliente (límite, saldo, vencido, en pedidos y disponible); sin permiso o sin respuesta, la tarjeta no se muestra
    async cargarCredito() {
      if (!rutaPermitida('/contactos/estado-cuenta')) { this.cred = null; return; }
      try { this.cred = await api('/api/revendedoras/' + this.params.id + '/credito'); } catch { this.cred = null; }
    },
    async buscarHacienda() {
      const n = String(this.f.numero_id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      if (!n) return toast('Ingrese el número de identificación', 'err');
      this.buscando = true;
      try {
        const d = await api('/api/hacienda/contribuyente/' + n);
        this.f.nombre = d.nombre || this.f.nombre;
        if (d.tipo_identificacion && CAT.tipoId[d.tipo_identificacion]) this.f.tipo_id = d.tipo_identificacion;
        if (d.actividades?.length) this.f.actividad = d.actividades[0].codigo;
        toast('Datos obtenidos de Hacienda', 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.buscando = false;
    },
    parseDirs(v) { try { const l = typeof v === 'string' ? JSON.parse(v || '[]') : (v || []); return Array.isArray(l) ? l.filter(d => d && typeof d === 'object').map(d => ({ nombre: d.nombre || '', detalle: d.detalle || '', enlace: d.enlace || '' })) : []; } catch { return []; } },   // 4.6
    nuevaPersona() { this.persona = { nombre: '', correo: '', telefono: '', notificar: true }; },
    agregarPersona() { if (!this.persona.nombre) return toast('Indique el nombre de la persona', 'err'); this.personas.push({ ...this.persona }); this.persona = null; },
    cantones, distritos,
    // Teléfonos: 8 dígitos; se quitan guiones, espacios y el 506 inicial
    num(v) { let d = String(v ?? '').replace(/\D/g, ''); if (d.length === 11 && d.startsWith('506')) d = d.slice(3); return d ? +d : null; },
    async guardar(otro = false) {
      const f = this.f;
      if ((f.tipo_id && !f.numero_id) || !f.nombre) return toast(f.tipo_id ? 'Complete los campos obligatorios: identificación y nombre' : 'Indique el nombre', 'err');
      for (const [campo, etiqueta] of [['telefono', 'teléfono'], ['celular', 'celular']]) { const n = this.num(f[campo]); if (n !== null && String(n).length !== 8 && String(n).length !== 3) return toast('El ' + etiqueta + ' debe tener 8 dígitos (o ser un número especial de 3, como 911), sin guiones ni el 506', 'err'); }   // antes de 'Guardando…' (R108)
      if (this.dirs.some(d => ((d.nombre || '').trim() || (d.enlace || '').trim()) && !(d.detalle || '').trim())) return toast('Cada dirección adicional necesita las señas (o quítela de la lista)', 'err');   // 4.6
      this.guardando = true;
      const body = { nombre: f.nombre, tipo_id: f.tipo_id || '', numero_id: f.tipo_id ? String(f.numero_id).replace(/[^A-Za-z0-9]/g, '').toUpperCase() : '', correo: f.correo || null, correo_facturas: (f.correo_facturas || '').trim() || null, correo_cc: (f.correo_cc || '').trim() || null, telefono: this.num(f.telefono), actividad: f.actividad || null,
        tipo: f.tipo, nombre_comercial: f.nombre_comercial || null, provincia: f.provincia || null, canton: f.canton || null, distrito: f.distrito || null, barrio: f.barrio || null, direccion: f.direccion || null,
        celular: this.num(f.celular), termino_pago_dias: f.termino_pago_dias ?? null, limite_credito: +f.limite_credito || 0, vendedor: f.vendedor || null,
        enviar_estado_cuenta: !!f.enviar_estado_cuenta, comentarios: f.comentarios || null, activo: f.activo !== false,
        direcciones: JSON.stringify(this.dirs.filter(d => (d.detalle || '').trim()).map(d => ({ nombre: (d.nombre || '').trim(), detalle: d.detalle.trim(), enlace: (d.enlace || '').trim() }))) };   // 4.6: casa, trabajo… (la caja las ofrece al pedir Express)
      try {
        const c = this.editando ? await api('/api/clientes/' + this.params.id, { method: 'PUT', body }) : await api('/api/clientes', { method: 'POST', body });
        const dato = { personas: this.personas, lista_precios_id: f.lista_precios_id, cuenta_cobrar: f.cuenta_cobrar, cuenta_pagar: f.cuenta_pagar };   // por id (R282)
        this.extra = mock.actualizar('contactos_extra', x => { x[c.id] = dato; }, {});
        store.poner('clientes', c);      // (R263)
        toast(f.tipo + (this.editando ? ' actualizado' : ' creado'), 'ok');
        if (otro) { this.f = this.vacio(); this.personas = []; this.dirs = []; location.hash = '/contactos/nuevo?tipo=' + f.tipo.toLowerCase(); }
        else location.hash = '/contactos';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { if (this.editando) this.cargar(); },
  template: `
  <div class="page">
    <PageHead :title="titulo" sub="Complete la información general, de contacto, comercial y contable." :crumbs="[{label:'Contactos',to:'/contactos'},{label:editando?f.nombre||'Editar':'Nuevo'}]">
      <div class="seg"><button v-for="t in tiposContacto" :key="t" :class="{on:f.tipo===t}" @click="f.tipo=t">{{t}}</button></div>
    </PageHead>
    <div class="alert info" v-if="cargando">Cargando contacto…</div>
    <div style="display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:18px;align-items:start" v-else>
      <div>
        <div class="card">
          <h2 style="cursor:pointer" @click="sec.general=!sec.general">{{sec.general?'▾':'▸'}} Datos generales</h2>
          <div class="grid" v-show="sec.general">
            <Field label="Número de identificación" :req="!!f.tipo_id" :help="f.tipo_id ? 'Sin guiones. Las cédulas jurídicas nuevas pueden llevar letras' : 'Sin identificación: solo se le emiten tiquetes electrónicos'"><div class="row" style="gap:6px"><input v-model="f.numero_id" :placeholder="f.tipo_id ? 'Sin guiones' : 'Sin identificación'" :disabled="!f.tipo_id" style="flex:1;text-transform:uppercase"><button class="btn sec sm" @click="buscarHacienda" :disabled="buscando || !f.tipo_id">{{buscando?'Buscando…':'Buscar en Hacienda'}}</button></div></Field>
            <Field label="Tipo de identificación" req><select v-model="f.tipo_id" @change="f.tipo_id || (f.numero_id = '')"><option v-for="o in opts(CAT.tipoId)" :value="o.value">{{o.label}}</option><option value="">Sin identificación (solo tiquetes)</option></select></Field>
            <Field label="Razón social o nombre" req><input v-model="f.nombre"></Field>
            <Field label="Nombre comercial"><input v-model="f.nombre_comercial"></Field>
            <Field label="Provincia"><select v-model.number="f.provincia" @change="f.canton = cantones(f.provincia)[0]?.value || 1; f.distrito = 1"><option v-for="o in opts(CAT.provincias)" :value="Number(o.value)">{{o.label}}</option></select></Field>
            <Field label="Cantón"><select v-model.number="f.canton" @change="f.distrito = distritos(f.provincia, f.canton)[0]?.value || 1"><option v-for="o in cantones(f.provincia)" :key="o.value" :value="o.value">{{o.value}} · {{o.label}}</option></select></Field>
            <Field label="Distrito"><select v-model.number="f.distrito"><option v-for="o in distritos(f.provincia, f.canton)" :key="o.value" :value="o.value">{{o.value}} · {{o.label}}</option></select></Field>
            <Field label="Barrio"><input v-model="f.barrio"></Field>
            <Field label="Dirección" style="grid-column:1/-1"><input v-model="f.direccion" placeholder="Otras señas (mínimo 5 caracteres para incluirla en el XML)"></Field>
            <div style="grid-column:1/-1"><!-- 4.6: varias direcciones por cliente (al estilo FISITAAP) -->
              <h2 style="margin:6px 0 4px;font-size:13px">Otras direcciones <small>para entregas: casa, trabajo, donde la hermana… la caja las ofrece al pedir Express y guarda la nueva aquí</small></h2>
              <table class="tbl" v-if="dirs.length"><thead><tr><th style="width:150px">Nombre</th><th>Señas</th><th style="width:220px">Enlace del mapa (opcional)</th><th></th></tr></thead>
                <tbody><tr v-for="(d,i) in dirs" :key="i"><td><input class="inp" v-model="d.nombre" maxlength="40" placeholder="Casa" style="width:100%"></td><td><input class="inp" v-model="d.detalle" maxlength="250" placeholder="200 m sur de la iglesia, portón negro" style="width:100%"></td><td><input class="inp" v-model="d.enlace" maxlength="300" placeholder="https://maps.app.goo.gl/…" style="width:100%"></td><td><button class="btn icon" title="Quitar" @click="dirs.splice(i,1)">✕</button></td></tr></tbody></table>
              <div class="row" style="margin-top:6px"><button class="btn sec sm" @click="dirs.push({nombre:'', detalle:'', enlace:''})">+ Agregar dirección</button></div>
            </div>
          </div>
        </div>
        <div class="card">
          <h2 style="cursor:pointer" @click="sec.contacto=!sec.contacto">{{sec.contacto?'▾':'▸'}} Información de contacto</h2>
          <div v-show="sec.contacto">
            <div class="grid cols-3">
              <Field label="Correo"><input type="email" v-model="f.correo" placeholder="correo@empresa.cr"></Field>
              <Field label="Enviar facturas a" help="Vacío = al correo principal"><ListaCorreos v-model="f.correo_facturas" placeholder="facturas@empresa.cr" agregar="+ Agregar destinatario"></ListaCorreos></Field>
              <Field label="Copia (CC) de las facturas" help="Agregue todos los que necesite"><ListaCorreos v-model="f.correo_cc" placeholder="contabilidad@empresa.cr" agregar="+ Agregar copia"></ListaCorreos></Field>
              <Field label="Teléfono" help="8 dígitos, sin guiones ni 506"><div class="row" style="gap:6px"><span class="muted">+506</span><input v-model="f.telefono" style="flex:1" maxlength="8" inputmode="numeric" placeholder="22221111"></div></Field>
              <Field label="Celular" help="8 dígitos"><div class="row" style="gap:6px"><span class="muted">+506</span><input v-model="f.celular" style="flex:1" maxlength="8" inputmode="numeric" placeholder="88881111"></div></Field>
            </div>
            <h2 style="margin-top:18px;font-size:14px">Personas asociadas <small>Reciben notificaciones de vencimiento de facturas (se guardan localmente)</small></h2>
            <table class="tbl" v-if="personas.length"><thead><tr><th>Nombre</th><th>Correo</th><th>Teléfono</th><th>Notificar vencimientos</th><th></th></tr></thead>
              <tbody><tr v-for="(p,i) in personas" :key="i"><td>{{p.nombre}}</td><td>{{p.correo}}</td><td>{{p.telefono}}</td><td><Badge :value="p.notificar?'Recibe copia':'Sin copia'"></Badge></td><td><button class="btn icon" @click="personas.splice(i,1)">✕</button></td></tr></tbody></table>
            <p class="muted small" v-else>Aún no hay personas asociadas.</p>
            <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="nuevaPersona">+ Asociar persona</button></div>
          </div>
        </div>
        <div class="card">
          <h2 style="cursor:pointer" @click="sec.comercial=!sec.comercial">{{sec.comercial?'▾':'▸'}} Información comercial</h2>
          <div class="grid" v-show="sec.comercial">
            <Field label="Término de pago"><select v-model.number="f.termino_pago_dias"><option v-for="t in CAT.terminosPago" :value="t.dias">{{t.nombre}}</option></select></Field>
            <Field label="Lista de precios" help="El precio de esa lista se aplica al elegir sus ítems en facturas, cotizaciones y la caja"><select v-model.number="f.lista_precios_id"><option v-for="l in listasPrecios" :value="l.id">{{l.nombre}}</option></select></Field>
            <Field label="Vendedor" help="Vendedor asignado"><Buscador v-model="f.vendedor" catalogo="vendedores" valor="nombre" placeholder="Sin vendedor" agregar="vendedor"></Buscador></Field>
            <Field label="Límite de crédito"><input type="number" step="0.01" min="0" v-model.number="f.limite_credito"></Field>
            <Field label="Actividad económica"><input v-model="f.actividad" placeholder="Código de actividad (Hacienda)"></Field>
          </div>
        </div>
        <div class="card">
          <h2 style="cursor:pointer" @click="sec.contab=!sec.contab">{{sec.contab?'▾':'▸'}} Configuración para contabilidad <small>El precio de esa lista se aplica al elegir sus ítems en facturas, cotizaciones y la caja</small></h2>
          <div class="grid cols-2" v-show="sec.contab">
            <Field label="Cuenta por cobrar" help="Cuenta contable donde se registran las ventas a crédito"><select v-model="f.cuenta_cobrar"><option v-for="c in CUENTAS_COBRAR">{{c}}</option></select></Field>
            <Field label="Cuenta por pagar" help="Cuenta contable donde se registran las compras a crédito"><select v-model="f.cuenta_pagar"><option v-for="c in CUENTAS_PAGAR">{{c}}</option></select></Field>
          </div>
        </div>
        <ExoneracionesCliente v-if="editando && f.tipo !== 'Proveedor' && f.id && (puede('catalogos') || puede('facturar') || puede('pos'))" :cliente-id="f.id" :numero-id="cedulaGuardada"></ExoneracionesCliente>
        <div class="card" v-else-if="!editando && f.tipo !== 'Proveedor'"><h2>Exoneraciones de IVA</h2><p class="muted small" style="margin:0">Guarde el contacto para registrar sus documentos de exoneración (se cargan desde el PDF o el número de autorización y se validan con Hacienda).</p></div>
        <div class="card"><h2>Comentarios <small>No son visibles para el contacto</small></h2><textarea class="inp" rows="3" v-model="f.comentarios" style="width:100%" placeholder="Notas internas sobre este contacto"></textarea></div>
      </div>
      <div style="position:sticky;top:16px">
      <div class="card">
        <Toggle v-model="f.enviar_estado_cuenta" label="Enviar estado de cuenta"></Toggle>
        <p class="small muted" style="margin:8px 0 12px">Envía mensualmente por correo el resumen de facturas pendientes.</p>
        <template v-if="editando">
          <Toggle v-model="f.activo" label="Contacto activo"></Toggle>
          <p class="small muted" style="margin:8px 0 16px">Los contactos inactivos no se eliminan: conservan su historial de documentos.</p>
        </template>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn" v-if="puedeGuardar" @click="guardar(false)" :disabled="guardando">{{guardando?'Guardando…':(editando?'Guardar cambios':'Crear contacto')}}</button>
          <button class="btn sec" @click="guardar(true)" :disabled="guardando" v-if="!editando && puedeGuardar">Guardar y crear otro</button>
          <p class="small muted" v-if="!puedeGuardar" style="margin:0">Su rol puede consultar este contacto, pero no cambiarlo.</p>
          <a class="btn ghost" href="#/contactos">Cancelar</a>
        </div>
      </div>
      <div class="card" v-if="verCuenta"><!-- 4.9: cuenta del cliente -->
        <h2 style="margin-top:0">Cuenta del cliente <small v-if="cred.revendedora">revendedora</small></h2>
        <div class="totals" style="align-items:stretch;margin-top:0">
          <div style="min-width:0"><span>Límite de crédito</span><b>{{(+cred.limite || 0) > 0 ? money(cred.limite, monedaP) : 'Sin crédito'}}</b></div>
          <div style="min-width:0"><span>Saldo pendiente</span><b>{{money(cred.saldo || 0, monedaP)}}</b></div>
          <div style="min-width:0" v-if="(+cred.vencido || 0) > 0"><span>Vencido</span><b>{{money(cred.vencido, monedaP)}}</b></div>
          <div style="min-width:0"><span>En pedidos</span><b>{{money(cred.en_pedidos || 0, monedaP)}}</b></div>
          <div style="min-width:0" class="total" v-if="(+cred.limite || 0) > 0"><span>Disponible</span><b>{{money(cred.disponible || 0, monedaP)}}</b></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:12px">
          <a class="btn sec" :href="'#/contactos/estado-cuenta/' + params.id">Estado de cuenta</a>
          <a class="btn ghost" :href="waCuenta" target="_blank" rel="noopener" :title="telCuenta ? 'Enviarle el resumen de su cuenta por WhatsApp' : 'Sin teléfono registrado: WhatsApp le pedirá elegir el contacto'">Enviar por WhatsApp</a>
        </div>
      </div>
      </div>
    </div>

    <Modal v-if="persona" title="Asociar persona" @close="persona=null">
      <div class="grid">
        <Field label="Nombre" req><input v-model="persona.nombre"></Field>
        <Field label="Correo"><input type="email" v-model="persona.correo"></Field>
        <Field label="Teléfono"><input v-model="persona.telefono"></Field>
      </div>
      <div style="margin-top:12px"><Toggle v-model="persona.notificar" label="Recibe copia de las facturas por correo"></Toggle></div>
      <template #foot><button class="btn ghost" @click="persona=null">Cancelar</button><button class="btn" @click="agregarPersona">Asociar</button></template>
    </Modal>
  </div>`,
  setup() { return { mock, money }; },
};
