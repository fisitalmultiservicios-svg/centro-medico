// Contactos — listado (backend real /api/clientes: clientes y proveedores son el mismo modelo, diferenciados por `tipo`)
import { api, toast, mock, CAT, opts, fechaHora } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';
import { store, sesion } from '../../app.js';

// Identificación alfanumérica en mayúsculas (cédulas jurídicas v4.4 y pasaportes conservan sus letras) y teléfono de 8 dígitos
// sin el 506 (antes se borraban las letras y «+506 8888-8888» se rechazaba) (R85)
export function normId(v) { return String(v || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); }
export function normTel(v) { let d = String(v || '').replace(/\D/g, ''); if (d.length === 11 && d.startsWith('506')) d = d.slice(3); return d ? Number(d) || null : null; }

export default {
  props: ['params'],
  data() {
    return {
      tab: ({ Proveedor: 'proveedores', Cliente: 'clientes', Ambos: 'ambos' })[this.params.tipo] || 'todos',   // 4.1: submenú Contactos
      q: this.params.q || '', menu: false, modal: false, historial: false, guardando: false, buscando: false,   // 4.6: estaban dentro del comentario anterior (búsqueda y menú muertos)
      // Sin backend aún: personas asociadas (mock 'contactos_extra') e historial de operaciones masivas (mock 'contactos_historial')
      extra: mock.get('contactos_extra', {}),
      log: mock.get('contactos_historial', []),
      f: this.nuevo(), CAT, opts,
    };
  },
  computed: {
    store() { return store; },
    // 3.87: los tipos que el rol puede crear (como el servidor): quien lleva gastos (Contador), solo proveedores; la caja, solo clientes
    tiposContacto() { return sesion.puede('catalogos') ? ['Cliente', 'Proveedor', 'Ambos'] : [...(sesion.puede('pos') ? ['Cliente'] : []), ...(sesion.puede('gastos') ? ['Proveedor'] : [])]; },
    rows() {
      const todos = store.clientes.map(c => ({ ...c, estado: c.activo === false ? 'Inactivo' : 'Activo' }));
      if (this.tab === 'clientes') return todos.filter(c => c.tipo === 'Cliente' || c.tipo === 'Ambos');
      if (this.tab === 'proveedores') return todos.filter(c => c.tipo === 'Proveedor' || c.tipo === 'Ambos');
      if (this.tab === 'ambos') return todos.filter(c => c.tipo === 'Ambos');
      return todos;
    },
    columns() {
      return [
        { key: 'nombre', label: '', width: '44px', fmt: v => (v || '?').trim().charAt(0).toUpperCase(), class: 'avatar-col' },
        { key: 'nombre', label: 'Nombre', link: r => location.hash = '/contactos/' + r.id },
        { key: 'numero_id', label: 'Identificación', mono: true, fmt: (v, r) => this.formatoId(r.tipo_id, v) },
        { key: 'telefono', label: 'Teléfono', fmt: v => v ? '+506 ' + String(v).replace(/(\d{4})(\d{4})/, '$1 $2') : '—' },
        { key: 'tipo', label: 'Tipo', fmt: 'badge' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    nuevo() { return { tipo: (sesion.puede('catalogos') || sesion.puede('pos')) ? 'Cliente' : 'Proveedor', numero_id: '', tipo_id: '01', nombre: '', provincia: null, canton: null, distrito: null, barrio: '', direccion: '', correo: '', telefono: '', actividad: '' }; },
    formatoId(tipo, num) {
      if (!num) return 'Sin identificación';
      const n = String(num || '').replace(/\D/g, '');
      if (tipo === '01' && n.length === 9) return n[0] + '-' + n.slice(1, 5) + '-' + n.slice(5);
      if (tipo === '02' && n.length === 10) return n[0] + '-' + n.slice(1, 4) + '-' + n.slice(4);
      return num || '';
    },
    // sobre lo guardado más reciente (no sobre la copia leída al abrir la pantalla)
    registrar(accion, detalle) { this.log = mock.actualizar('contactos_historial', l => [{ fecha: fechaHora(), accion, detalle }, ...(Array.isArray(l) ? l : [])].slice(0, 50), []); },
    exportar() {
      // en CSV, mismas columnas y orden que la importación (nombre; tipo_id; numero_id; correo; telefono; actividad; tipo): se puede reimportar (R85)
      exportarFilas('contactos', ['nombre', 'tipo_id', 'numero_id', 'correo', 'telefono', 'actividad', 'tipo', 'estado'], this.rows.map(r => [r.nombre, r.tipo_id, r.numero_id, r.correo || '', r.telefono || '', r.actividad || '', r.tipo, r.estado]),
        { titulo: 'Contactos', etiquetas: ['Nombre', 'Tipo de identificación', 'Identificación', 'Correo', 'Teléfono', 'Actividad', 'Tipo', 'Estado'] });
      this.registrar('Exportar', this.rows.length + ' contactos');
    },
    exportarPersonas() {
      const filas = [];
      for (const r of this.rows) for (const p of (this.extra[r.id]?.personas || [])) filas.push([r.nombre, p.nombre, p.correo, p.telefono, p.notificar ? 'Sí' : 'No']);
      if (!filas.length) return toast('No hay personas asociadas registradas');
      exportarFilas('personas-asociadas', ['Contacto', 'Nombre', 'Correo', 'Teléfono', 'Notificar vencimientos'], filas, { titulo: 'Personas asociadas' });
      this.registrar('Exportar personas asociadas', filas.length + ' personas');
    },
    async importar(ev) {
      const file = ev.target.files[0]; if (!file) return;
      const texto = await file.text(); const lineas = texto.split(/\r?\n/).filter(l => l.trim());
      const sep = (lineas[0] || '').includes(';') ? ';' : ',';
      let ok = 0, err = 0;
      for (const l of lineas) {
        const [nombre, tipo_id, numero_id, correo, telefono, actividad, tipo] = l.split(sep).map(s => s.replace(/^"|"$/g, '').trim());
        if (!nombre || /^nombre$/i.test(nombre) || !numero_id) continue;
        const tipoIdOk = CAT.tipoId[tipo_id] ? tipo_id : (Object.entries(CAT.tipoId).find(([, v]) => v.toLowerCase() === String(tipo_id || '').toLowerCase()) || ['01'])[0];
        const t = ['Cliente', 'Proveedor', 'Ambos'].includes(tipo) ? tipo : 'Cliente';
        try { store.poner('clientes', await api('/api/clientes', { method: 'POST', body: { nombre, tipo_id: tipoIdOk, numero_id: normId(numero_id), correo: correo || null, telefono: normTel(telefono), actividad: actividad || null, tipo: t } })); ok++; } catch { err++; }
      }
      ev.target.value = '';
      this.registrar('Importar contactos', ok + ' creados, ' + err + ' con error');
      toast(ok + ' contactos importados' + (err ? ', ' + err + ' con error' : ''), err ? 'err' : 'ok');
    },
    async buscarHacienda() {
      const n = normId(this.f.numero_id);
      if (!n) return toast('Ingrese el número de identificación', 'err');
      this.buscando = true;
      try {
        const d = await api('/api/hacienda/contribuyente/' + n);
        this.f.nombre = d.nombre || this.f.nombre;
        if (d.tipo_identificacion && CAT.tipoId[d.tipo_identificacion]) this.f.tipo_id = d.tipo_identificacion;
        if (d.actividades?.length) this.f.actividad = d.actividades[0].codigo;
        toast('Datos obtenidos de Hacienda' + (d.situacion ? ' · ' + d.situacion : ''), 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.buscando = false;
    },
    async crear() {
      const f = this.f;
      if ((f.tipo_id && !f.numero_id) || !f.nombre) return toast('Complete los campos obligatorios', 'err');
      this.guardando = true;
      const body = { nombre: f.nombre, tipo_id: f.tipo_id || '', numero_id: f.tipo_id ? normId(f.numero_id) : '', correo: f.correo || null, telefono: normTel(f.telefono), actividad: f.actividad || null,
        tipo: f.tipo, provincia: f.provincia || null, canton: f.canton || null, distrito: f.distrito || null, barrio: f.barrio || null, direccion: f.direccion || null, activo: true };
      try {
        store.poner('clientes', await api('/api/clientes', { method: 'POST', body }));      // (R263)
        toast(f.tipo + ' creado', 'ok'); this.modal = false; this.f = this.nuevo();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    avanzado() { this.modal = false; location.hash = '/contactos/nuevo?tipo=' + this.f.tipo.toLowerCase() + (this.f.numero_id ? '&numero=' + encodeURIComponent(this.f.numero_id) : ''); },
    async eliminar(r) {
      if (!confirm('¿Eliminar el contacto "' + r.nombre + '"?')) return;
      try {
        const res = await api('/api/clientes/' + r.id, { method: 'DELETE' });
        if (!res?.desactivado) this.extra = mock.actualizar('contactos_extra', x => { delete x[r.id]; }, {});
        store.quitar('clientes', r.id, !!res?.desactivado);
        toast(res?.desactivado ? 'El contacto tiene documentos emitidos: se desactivó en lugar de eliminarse' : 'Contacto eliminado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    async eliminarVarios(rows) {
      let ok = 0, desact = 0, err = 0; const borrados = [];
      for (const r of rows) {
        try { const res = await api('/api/clientes/' + r.id, { method: 'DELETE' }); if (res?.desactivado) desact++; else { ok++; borrados.push(r.id); } store.quitar('clientes', r.id, !!res?.desactivado); } catch { err++; }
      }
      this.extra = mock.actualizar('contactos_extra', x => { for (const id of borrados) delete x[id]; }, {});
      const msg = ok + ' eliminados' + (desact ? ', ' + desact + ' desactivados (tienen documentos)' : '') + (err ? ', ' + err + ' con error' : '');
      this.registrar('Eliminar contactos', msg);
      toast(msg, err ? 'err' : 'ok');
    },
  },
  // La carga corrió al entrar; solo se repite si falló (store.fallos). Antes una empresa sin contactos la pedía en cada montaje.
  created() { if (store.fallos?.clientes) store.cargar(); },
  watch: { 'params.q'(v) { this.q = v || ''; }, 'params.tipo'(v) { this.tab = ({ Proveedor: 'proveedores', Cliente: 'clientes', Ambos: 'ambos' })[v] || 'todos'; } },     // la búsqueda de la barra superior también funciona estando ya en Contactos (R265)
  template: `
  <div class="page">
    <PageHead title="Contactos" sub="Administre sus clientes y proveedores, sus datos de contacto y condiciones comerciales.">
      <button class="btn icon" title="Ayuda">?</button>
      <div style="position:relative"><button class="btn ghost" @click="menu=!menu">Más acciones ▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:250px;padding:6px" @click="menu=false">
          <a class="item" v-if="puede('catalogos')" style="display:block;padding:8px 10px;cursor:pointer" @click="$refs.archivo.click()">Importar contactos</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar">Exportar</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportarPersonas">Exportar personas asociadas</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="historial=true">Historial de operaciones masivas</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="store.cargar()">Actualizar</a>
        </div></div>
      <button class="btn" v-if="puede('catalogos') || puede('gastos') || puede('pos')" @click="f=nuevo();modal=true">+ Nuevo contacto</button>
      <input type="file" ref="archivo" accept=".csv,.txt" style="display:none" @change="importar">
    </PageHead>
    <div class="card pad0">
      <div style="padding:12px 12px 0">
        <div class="tabs" style="margin-bottom:10px"><button :class="{on:tab==='todos'}" @click="tab='todos'">Todos</button><button :class="{on:tab==='clientes'}" @click="tab='clientes'">Clientes</button><button :class="{on:tab==='proveedores'}" @click="tab='proveedores'">Proveedores</button><button :class="{on:tab==='ambos'}" @click="tab='ambos'">Clientes y proveedores</button></div>
        <div class="toolbar"><input class="search" placeholder="Buscar por nombre, identificación o correo" v-model="q"></div>
      </div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('catalogos')" :on-bulk-delete="eliminarVarios" empty-title="Aún no tienes contactos" empty-text="Crea tu primer cliente o proveedor para usarlo en facturas y compras.">
        <template #actions="{row}">
          <a class="btn icon" v-if="puede('catalogos') || (puede('gastos') && row.tipo === 'Proveedor')" :href="'#/contactos/'+row.id" title="Editar">✎</a>
          <button class="btn icon" v-if="puede('catalogos')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><button class="btn" v-if="puede('catalogos') || puede('gastos') || puede('pos')" @click="modal=true">+ Nuevo contacto</button></template>
      </DataTable>
    </div>

    <Modal v-if="modal" title="Nuevo contacto" lg @close="modal=false">
      <div class="row" style="margin-bottom:14px"><div class="seg"><button v-for="t in tiposContacto" :key="t" :class="{on:f.tipo===t}" @click="f.tipo=t">{{t}}</button></div></div>
      <div class="grid">
        <Field label="Número de identificación" :req="!!f.tipo_id"><div class="row" style="gap:6px"><input v-model="f.numero_id" :placeholder="f.tipo_id ? 'Sin guiones' : 'Sin identificación'" :disabled="!f.tipo_id" style="flex:1"><button class="btn sec sm" @click="buscarHacienda" :disabled="buscando || !f.tipo_id">{{buscando?'Buscando…':'Buscar en Hacienda'}}</button></div></Field>
        <Field label="Tipo de identificación" req><select v-model="f.tipo_id" @change="f.tipo_id || (f.numero_id = '')"><option v-for="o in opts(CAT.tipoId)" :value="o.value">{{o.label}}</option><option value="">Sin identificación (solo tiquetes)</option></select></Field>
        <Field label="Razón social o nombre" req><input v-model="f.nombre"></Field>
        <Field label="Actividad económica"><input v-model="f.actividad" placeholder="Código de actividad"></Field>
        <Field label="Provincia"><select v-model.number="f.provincia"><option v-for="o in opts(CAT.provincias)" :value="Number(o.value)">{{o.label}}</option></select></Field>
        <Field label="Cantón"><input type="number" min="1" max="99" v-model.number="f.canton"></Field>
        <Field label="Distrito"><input type="number" min="1" max="99" v-model.number="f.distrito"></Field>
        <Field label="Barrio"><input v-model="f.barrio"></Field>
        <Field label="Dirección"><input v-model="f.direccion" placeholder="Otras señas"></Field>
        <Field label="Correo"><input type="email" v-model="f.correo"></Field>
        <Field label="Teléfono"><div class="row" style="gap:6px"><span class="muted">+506</span><input v-model="f.telefono" placeholder="8888 8888" style="flex:1"></div></Field>
      </div>
      <template #foot>
        <button class="btn ghost" @click="avanzado">Ir a formulario avanzado</button>
        <button class="btn" @click="crear" :disabled="guardando">{{guardando?'Guardando…':'Crear contacto'}}</button>
      </template>
    </Modal>

    <Modal v-if="historial" title="Historial de operaciones masivas" @close="historial=false">
      <Empty v-if="!log.length" icon="🕘" title="Sin operaciones" text="Las importaciones y exportaciones aparecerán aquí."></Empty>
      <table class="tbl" v-else><thead><tr><th>Fecha</th><th>Operación</th><th>Detalle</th></tr></thead><tbody><tr v-for="(l,i) in log" :key="i"><td>{{l.fecha}}</td><td>{{l.accion}}</td><td>{{l.detalle}}</td></tr></tbody></table>
      <template #foot><button class="btn" @click="historial=false">Cerrar</button></template>
    </Modal>
  </div>`,
};
