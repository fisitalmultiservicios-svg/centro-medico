// Registro rápido de una exoneración autorizada por Hacienda (v1.29): desde la ficha del cliente, la factura o la caja. Se carga el PDF
// (el sistema lee el número) o se escribe el número; se consulta en Hacienda y solo se registra si el beneficiario es el cliente y
// está vigente. El PDF queda como respaldo en la ficha del cliente. Emite 'registrada' con la exoneración creada.
import { api, toast, fecha } from '../../api.js';

// Puntos de IVA que la exoneración `x` quita a la línea `l` (mismas reglas que el servidor: gravada, no exenta, CABYS autorizado si el
// documento trae lista, nunca más que la tarifa; una línea marcada exonerar=false no la toma).
export function tarifaExoLinea(x, l) {
  if (!x || !l || l.exonerar === false || l.codigo_tarifa === '10' || !((+l.tarifa || 0) > 0)) return 0;
  if (x.posee_cabys && !(x.cabys || []).includes(String(l.cabys || ''))) return 0;
  return Math.min(+x.tarifa || 0, +l.tarifa || 0);
}
// Datos de la exoneración que se guardan con una cotización (para su lista y su PDF aunque después cambie la ficha del cliente).
export function fotoExoneracion(x) {
  return x ? { id: x.id, numero: x.numero, tipo: x.tipo, tipo_nombre: x.tipo_nombre, institucion: x.institucion, institucion_otro: x.institucion_otro || '',
    institucion_nombre: x.institucion_nombre, fecha: x.fecha_emision, tarifa: +x.tarifa, articulo: x.articulo || null, inciso: x.inciso || null,
    posee_cabys: !!x.posee_cabys, cabys: x.cabys || [] } : null;
}

export default {
  name: 'ExoneracionRapida',
  props: { clienteId: { type: [Number, String], required: true }, numeroId: { type: String, default: '' }, titulo: { type: String, default: 'Exoneración autorizada por Hacienda' } },
  emits: ['close', 'registrada'],
  data() { return { archivo: null, leyendo: false, consultando: false, guardando: false, numeros: [], numero: '', consulta: null }; },
  computed: {
    coincide() { const n = x => String(x || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase().replace(/^0+/, ''); return !!this.consulta && n(this.consulta.identificacion) === n(this.numeroId); },
  },
  methods: {
    fecha,
    fd(x) { return fecha(String(x || '').slice(0, 10)); },   // fecha del documento (sin hora): tal cual, sin zona horaria
    pct(v) { return (+v || 0).toLocaleString('es-CR', { maximumFractionDigits: 2 }) + ' %'; },
    async elegirPdf(ev) {
      const f = ev.target.files && ev.target.files[0]; this.archivo = f || null; this.numeros = [];
      if (!f) return;
      if (f.size > 5 * 1024 * 1024) { this.archivo = null; ev.target.value = ''; return toast('El PDF supera 5 MB', 'err'); }
      this.leyendo = true;
      try {
        const fd = new FormData(); fd.append('archivo', f);
        const r = await api('/api/exoneraciones/leer-pdf', { method: 'POST', body: fd });
        this.numeros = r.numeros || [];
        if (this.numeros.length) { this.numero = this.numeros[0]; await this.consultar(); }
        else toast('No se encontró el número de autorización en el PDF (puede ser una imagen escaneada): escríbalo abajo', 'err');
      } catch (e) { toast(e.message, 'err'); }
      this.leyendo = false;
    },
    async consultar() {
      const n = String(this.numero || '').trim().toUpperCase();
      if (!n) return toast('Escriba el número de autorización (p. ej. AL-00020402-24)', 'err');
      const turno = (this._turno = (this._turno || 0) + 1);   // consultas solapadas: solo vale la última
      this.consultando = true; this.consulta = null;
      try { const r = await api('/api/exoneraciones/consultar', { method: 'POST', body: { numero: n } }); if (turno === this._turno) this.consulta = r; }
      catch (e) { if (turno === this._turno) toast(e.message, 'err'); }
      if (turno === this._turno) this.consultando = false;
    },
    async registrar() {
      if (!this.consulta || !this.coincide || this.consulta.vencida || this.guardando) return;
      this.guardando = true;
      try {
        const x = await api(`/api/clientes/${this.clienteId}/exoneraciones`, { method: 'POST', body: { origen: 'hacienda', numero: this.consulta.numero } });
        if (this.archivo) {
          const fd = new FormData(); fd.append('archivo', this.archivo);
          try { await api(`/api/exoneraciones/${x.id}/pdf`, { method: 'POST', body: fd }); x.tiene_pdf = true; }
          catch (e) { toast('La exoneración quedó registrada, pero el PDF no se pudo guardar: ' + e.message, 'err'); }
        }
        toast('Exoneración ' + x.numero + ' registrada y verificada con Hacienda', 'ok');
        this.$emit('registrada', x);
      } catch (e) {
        if (e.status === 409) { toast(e.message + ': se usa la que ya está en la ficha', 'ok'); this.$emit('registrada', null); }
        else toast(e.message, 'err');
      }
      this.guardando = false;
    },
  },
  template: `
  <Modal :title="titulo" @close="$emit('close')">
    <p class="small muted" style="margin-top:0">Cargue el PDF de la autorización (EXONET): el sistema lee el número y lo consulta en Hacienda. También puede escribir el número. Queda registrada en la ficha del cliente.</p>
    <div class="grid cols-2">
      <Field label="PDF de la autorización" help="Se guarda como respaldo en la ficha del cliente"><input type="file" accept="application/pdf,.pdf" @change="elegirPdf"></Field>
      <Field label="Número de autorización" req :help="leyendo ? 'Leyendo el PDF…' : (numeros.length > 1 ? 'El PDF trae varios números: elija' : '')">
        <div class="row" style="gap:6px"><input v-model="numero" class="mono" placeholder="AL-00020402-24" style="flex:1;text-transform:uppercase" @keyup.enter="consultar">
        <select v-if="numeros.length > 1" v-model="numero" @change="consultar"><option v-for="n in numeros" :key="n" :value="n">{{n}}</option></select>
        <button class="btn sec sm" @click="consultar" :disabled="consultando">{{consultando ? 'Consultando…' : 'Consultar en Hacienda'}}</button></div>
      </Field>
    </div>
    <div v-if="consulta" class="alert" :class="coincide && !consulta.vencida ? 'ok' : 'err'" style="margin-top:12px">
      <div><b class="mono">{{consulta.numero}}</b> · {{consulta.tipo}} {{consulta.descripcion_tipo || consulta.tipo_nombre}}</div>
      <div class="small">Beneficiario: <b class="mono">{{consulta.identificacion}}</b> <span v-if="coincide">✓ coincide con el cliente</span><span v-else>✗ no es la identificación del cliente ({{numeroId}}): no se puede registrar</span></div>
      <div class="small">{{consulta.nombre_institucion}} · emitida {{fd(consulta.fecha_emision)}} · {{consulta.fecha_vencimiento ? 'vence ' + fecha(consulta.fecha_vencimiento) : 'sin vencimiento'}}<b v-if="consulta.vencida"> · VENCIDA</b></div>
      <div class="small">Tarifa exonerada: <b>{{pct(consulta.tarifa)}}</b> · {{consulta.posee_cabys ? consulta.cabys.length + ' CABYS autorizados' : 'aplica a todos los CABYS'}}</div>
      <div class="small mono muted" v-if="consulta.posee_cabys" style="margin-top:4px;max-height:80px;overflow:auto">{{consulta.cabys.join(', ')}}</div>
    </div>
    <template #foot><button class="btn ghost" @click="$emit('close')">Cancelar</button><button class="btn" :disabled="!consulta || !coincide || consulta.vencida || guardando" @click="registrar">{{guardando ? 'Guardando…' : 'Registrar y usar'}}</button></template>
  </Modal>`,
};
