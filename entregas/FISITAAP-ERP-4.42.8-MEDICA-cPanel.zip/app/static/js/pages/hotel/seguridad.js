// Hotel › Seguridad (3.3): la vista de recepción sin montos para el puesto de seguridad. Quién llega y quién sale hoy, quién está en
// casa (con vehículo y acompañantes), bitácora de turno, visitantes y vehículos, incidentes y objetos perdidos. Todo sin dinero.
// Una sola pantalla con pestañas según la ruta: /hotel/seguridad (puesto), /bitacora, /visitantes, /incidentes, /objetos.
import { toast, fecha, fechaHora, hoy, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { hotelActivo, reservas, esEstadia, listasDelDia, huesped, nombreHab, nombreCat, usuarioActual, habitaciones, reportesAbiertos, crearReporte, MODULOS_REPORTE } from './_datos.js';

const TABS = [['puesto', 'Puesto de seguridad'], ['bitacora', 'Bitácora de turno'], ['visitantes', 'Visitantes y vehículos'], ['incidentes', 'Incidentes'], ['objetos', 'Objetos perdidos']];
const TIPOS_INCIDENTE = ['Ruido o molestia', 'Persona sospechosa', 'Robo o pérdida', 'Daño a la propiedad', 'Accidente o emergencia médica', 'Intoxicación o alcohol', 'Vehículo mal estacionado', 'Puerta o acceso forzado', 'Otro'];
const siguiente = (lista, pref) => pref + String((lista || []).reduce((m, x) => Math.max(m, parseInt(String(x.numero || '').replace(/\D/g, ''), 10) || 0), 0) + 1).padStart(4, '0');

export default {
  props: ['params'],
  data() {
    const h = location.hash.split('?')[0], tab = h.endsWith('/bitacora') ? 'bitacora' : h.endsWith('/visitantes') ? 'visitantes' : h.endsWith('/incidentes') ? 'incidentes' : h.endsWith('/objetos') ? 'objetos' : 'puesto';
    return { tab, TABS, TIPOS_INCIDENTE, activo: hotelActivo(), lista: reservas(), bitacora: mock.get('hotel_seg_bitacora', []) || [], visitantes: mock.get('hotel_seg_visitantes', []) || [], incidentes: mock.get('hotel_seg_incidentes', []) || [], objetos: mock.get('hotel_seg_objetos', []) || [],
      nota: '', visita: null, incidente: null, objeto: null, ver: null, q: '', filtroV: 'dentro', filtroI: 'abiertos', filtroO: 'pendientes', reloj: Date.now() };
  },
  computed: {
    puedeEscribir() { return sesion.puede('seguridad') || sesion.puede('escribir'); },
    hoyS() { void this.reloj; return hoy(); },
    dia() { return listasDelDia(this.hoyS, this.lista.filter(esEstadia)); },
    enCasa() { return this.dia.enCasa.map(r => ({ ...r, h: r.huesped_id ? huesped(r.huesped_id) : null })); },
    habs() { return habitaciones(); },
    hoyBitacora() { return this.bitacora.filter(b => String(b.hora || '').slice(0, 10) === this.hoyS).sort((a, b) => String(b.hora).localeCompare(String(a.hora))); },
    visitantesVer() { const q = this.q.trim().toLowerCase(); return this.visitantes.filter(v => this.filtroV === 'todos' || (this.filtroV === 'dentro' && !v.salida) || (this.filtroV === 'hoy' && String(v.entrada || '').slice(0, 10) === this.hoyS)).filter(v => !q || [v.nombre, v.documento, v.placa, v.visita_a, v.motivo].some(x => String(x || '').toLowerCase().includes(q))).sort((a, b) => String(b.entrada).localeCompare(String(a.entrada))); },
    incidentesVer() { return this.incidentes.filter(i => this.filtroI === 'todos' || (this.filtroI === 'abiertos' && i.estado !== 'cerrado') || (this.filtroI === 'graves' && i.gravedad === 'grave' && i.estado !== 'cerrado')).sort((a, b) => (a.estado === 'cerrado') - (b.estado === 'cerrado') || String(b.hora).localeCompare(String(a.hora))); },
    objetosVer() { return this.objetos.filter(o => this.filtroO === 'todos' || (this.filtroO === 'pendientes' && o.estado === 'guardado') || (this.filtroO === 'entregados' && o.estado !== 'guardado')).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha))); },
    vehiculos() { return this.enCasa.filter(r => (r.vehiculo || '').trim()).map(r => ({ placa: r.vehiculo, hab: nombreHab(r.habitacion_id), quien: r.huesped_nombre })); },
    abiertosMant() { return reportesAbiertos().length; },
    resumen() { return { llegadas: this.dia.llegadas.length, salidas: this.dia.salidas.length, enCasa: this.enCasa.length, personas: this.enCasa.reduce((s, r) => s + (+r.adultos || 0) + (+r.ninos || 0), 0), visitantes: this.visitantes.filter(v => !v.salida).length, incidentes: this.incidentes.filter(i => i.estado !== 'cerrado').length, objetos: this.objetos.filter(o => o.estado === 'guardado').length }; },
  },
  methods: {
    fecha, fechaHora, nombreHab, nombreCat,
    ir(t) { this.tab = t; location.hash = '/hotel/seguridad' + (t === 'puesto' ? '' : '/' + t); },
    refrescar() { this.lista = reservas(); this.bitacora = mock.get('hotel_seg_bitacora', []) || []; this.visitantes = mock.get('hotel_seg_visitantes', []) || []; this.incidentes = mock.get('hotel_seg_incidentes', []) || []; this.objetos = mock.get('hotel_seg_objetos', []) || []; this.reloj = Date.now(); },
    guardar(clave, fn) { if (!mock.puedeGuardar()) return false; mock.actualizar(clave, l => fn(Array.isArray(l) ? l : []), []); this.refrescar(); return true; },
    // bitácora
    anotar(tipo) { const n = (this.nota || '').trim(); if (!n) return toast('Escriba la anotación', 'err'); if (this.guardar('hotel_seg_bitacora', l => [...l, { id: mock.nextId(l, 'hotel_seg_bitacora'), hora: new Date().toISOString(), usuario: usuarioActual(), tipo: tipo || 'nota', texto: n }])) { this.nota = ''; toast('Anotado en la bitácora', 'ok'); } },
    // visitantes y vehículos
    nuevaVisita() { this.visita = { nombre: '', documento: '', placa: '', visita_a: '', habitacion_id: null, motivo: '', personas: 1 }; },
    registrarEntrada() { const v = this.visita; if (!(v.nombre || '').trim()) return toast('Indique el nombre del visitante', 'err'); if (this.guardar('hotel_seg_visitantes', l => [...l, { ...v, id: mock.nextId(l, 'hotel_seg_visitantes'), nombre: v.nombre.trim(), entrada: new Date().toISOString(), salida: null, usuario: usuarioActual() }])) { this.visita = null; toast('Entrada registrada', 'ok'); } },
    registrarSalida(v) { this.guardar('hotel_seg_visitantes', l => l.map(x => (x.id === v.id ? { ...x, salida: new Date().toISOString(), salida_usuario: usuarioActual() } : x))); toast('Salida de ' + v.nombre + ' registrada', 'ok'); },
    // incidentes
    nuevoIncidente() { this.incidente = { tipo: TIPOS_INCIDENTE[0], gravedad: 'leve', lugar: '', habitacion_id: null, involucrados: '', descripcion: '', acciones: '', avisar_mantenimiento: false }; },
    guardarIncidente() {
      const i = this.incidente; if (!(i.descripcion || '').trim()) return toast('Describa lo ocurrido', 'err');
      let numero = '';
      const ok = this.guardar('hotel_seg_incidentes', l => { numero = siguiente(l, 'SG-'); return [...l, { ...i, id: mock.nextId(l, 'hotel_seg_incidentes'), numero, hora: new Date().toISOString(), estado: 'abierto', usuario: usuarioActual(), historial: [{ hora: new Date().toISOString(), usuario: usuarioActual(), texto: 'Registrado' }] }]; });
      if (!ok) return;
      if (i.avisar_mantenimiento) { crearReporte({ habitacion_id: i.habitacion_id || null, lugar: i.habitacion_id ? '' : (i.lugar || 'Seguridad'), modulo: 'mantenimiento', tipo: 'Incidente de seguridad ' + numero, descripcion: (i.descripcion || '').trim(), prioridad: i.gravedad === 'grave' ? 'urgente' : 'normal', reportado_por: usuarioActual() }); }
      this.incidente = null; toast('Incidente ' + numero + ' registrado' + (i.avisar_mantenimiento ? ' y avisado a Mantenimiento' : ''), 'ok');
    },
    cerrarIncidente(i) { const n = window.prompt('Cómo se resolvió:', i.acciones || ''); if (n === null) return; this.guardar('hotel_seg_incidentes', l => l.map(x => (x.id === i.id ? { ...x, estado: 'cerrado', cerrado_en: new Date().toISOString(), acciones: n.trim() || x.acciones, historial: [...(x.historial || []), { hora: new Date().toISOString(), usuario: usuarioActual(), texto: 'Cerrado' + (n.trim() ? ': ' + n.trim() : '') }] } : x))); toast(i.numero + ' cerrado', 'ok'); },
    // objetos perdidos
    nuevoObjeto() { this.objeto = { descripcion: '', lugar: '', habitacion_id: null, fecha: this.hoyS, encontrado_por: usuarioActual(), guardado_en: 'Recepción', huesped_nombre: '' }; },
    guardarObjeto() { const o = this.objeto; if (!(o.descripcion || '').trim()) return toast('Describa el objeto', 'err'); let numero = ''; if (this.guardar('hotel_seg_objetos', l => { numero = siguiente(l, 'OP-'); return [...l, { ...o, id: mock.nextId(l, 'hotel_seg_objetos'), numero, estado: 'guardado', usuario: usuarioActual(), registrado: new Date().toISOString() }]; })) { this.objeto = null; toast('Objeto ' + numero + ' registrado', 'ok'); } },
    entregarObjeto(o) { const n = window.prompt('Entregado a (nombre y documento):', o.huesped_nombre || ''); if (n === null || !n.trim()) return; this.guardar('hotel_seg_objetos', l => l.map(x => (x.id === o.id ? { ...x, estado: 'entregado', entregado_a: n.trim(), entregado_en: new Date().toISOString(), entregado_por: usuarioActual() } : x))); toast(o.numero + ' entregado', 'ok'); },
    descartarObjeto(o) { if (!confirm('¿Marcar «' + o.descripcion + '» como descartado o donado?')) return; this.guardar('hotel_seg_objetos', l => l.map(x => (x.id === o.id ? { ...x, estado: 'descartado', entregado_en: new Date().toISOString(), entregado_por: usuarioActual() } : x))); },
    exportar(formato) {
      let cols, rows, titulo;
      if (this.tab === 'bitacora') { titulo = 'Bitácora de seguridad'; cols = [{ key: 'hora', label: 'Hora', fmt: v => fechaHora(v) }, { key: 'usuario', label: 'Oficial' }, { key: 'tipo', label: 'Tipo' }, { key: 'texto', label: 'Anotación' }]; rows = this.bitacora.slice().sort((a, b) => String(b.hora).localeCompare(String(a.hora))).slice(0, 500); }
      else if (this.tab === 'visitantes') { titulo = 'Visitantes y vehículos'; cols = [{ key: 'entrada', label: 'Entrada', fmt: v => fechaHora(v) }, { key: 'salida', label: 'Salida', fmt: v => (v ? fechaHora(v) : 'Dentro') }, { key: 'nombre', label: 'Visitante' }, { key: 'documento', label: 'Documento' }, { key: 'placa', label: 'Placa' }, { key: 'visita_a', label: 'Visita a' }, { key: 'motivo', label: 'Motivo' }]; rows = this.visitantesVer; }
      else if (this.tab === 'incidentes') { titulo = 'Incidentes de seguridad'; cols = [{ key: 'numero', label: 'Nº' }, { key: 'hora', label: 'Hora', fmt: v => fechaHora(v) }, { key: 'tipo', label: 'Tipo' }, { key: 'gravedad', label: 'Gravedad' }, { key: 'lugar_txt', label: 'Lugar' }, { key: 'descripcion', label: 'Descripción' }, { key: 'acciones', label: 'Acciones' }, { key: 'estado', label: 'Estado' }]; rows = this.incidentesVer.map(i => ({ ...i, lugar_txt: i.habitacion_id ? 'Hab. ' + nombreHab(i.habitacion_id) : i.lugar })); }
      else { titulo = 'Objetos perdidos'; cols = [{ key: 'numero', label: 'Nº' }, { key: 'fecha', label: 'Encontrado', fmt: 'date' }, { key: 'descripcion', label: 'Objeto' }, { key: 'lugar_txt', label: 'Lugar' }, { key: 'guardado_en', label: 'Guardado en' }, { key: 'estado', label: 'Estado' }, { key: 'entregado_a', label: 'Entregado a' }]; rows = this.objetosVer.map(o => ({ ...o, lugar_txt: o.habitacion_id ? 'Hab. ' + nombreHab(o.habitacion_id) : o.lugar })); }
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'seguridad_' + this.tab, cols, rows);
      return descargarReporte(formato, { titulo, subtitulo: 'Hotel · módulo de Seguridad', periodo: 'Al ' + fecha(this.hoyS), cols, rows, kpis: [{ t: 'Registros', v: String(rows.length) }], archivo: 'seguridad_' + this.tab });
    },
  },
  created() { this._reloj = setInterval(() => { this.reloj = Date.now(); }, 60000); },
  beforeUnmount() { clearInterval(this._reloj); },
  template: `
  <div class="page">
    <PageHead title="Seguridad" :sub="activo ? resumen.enCasa + ' habitaciones en casa · ' + resumen.personas + ' personas · ' + resumen.visitantes + ' visitante(s) dentro · ' + resumen.incidentes + ' incidente(s) abierto(s)' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Seguridad'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" v-if="tab!=='puesto'">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" v-if="tab!=='puesto'">Excel</button><button class="btn ghost sm" @click="exportar('csv')" v-if="tab!=='puesto'">CSV</button>
      <button class="btn ghost sm" @click="refrescar">Actualizar</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛡" title="El hotel no está configurado"></Empty></div>
    <template v-else>
    <div class="tabs"><button v-for="t in TABS" :key="t[0]" :class="{on: tab===t[0]}" @click="ir(t[0])">{{t[1]}}</button></div>

    <div v-if="tab==='puesto'">
      <div class="kpis">
        <div class="kpi"><div class="t">Llegadas de hoy</div><div class="v">{{resumen.llegadas}}</div></div><div class="kpi"><div class="t">Salidas de hoy</div><div class="v">{{resumen.salidas}}</div></div>
        <div class="kpi"><div class="t">En casa</div><div class="v">{{resumen.enCasa}}</div><div class="d">{{resumen.personas}} personas</div></div><div class="kpi"><div class="t">Visitantes dentro</div><div class="v">{{resumen.visitantes}}</div></div>
        <div class="kpi"><div class="t">Incidentes abiertos</div><div class="v">{{resumen.incidentes}}</div></div><div class="kpi"><div class="t">Objetos guardados</div><div class="v">{{resumen.objetos}}</div></div>
      </div>
      <div class="cols">
        <div class="card col"><h2>Llegan hoy <small>{{dia.llegadas.length}}</small></h2><div class="lista">
          <div v-for="r in dia.llegadas" :key="r.id" class="hues"><div class="n">{{r.huesped_nombre}}</div><div class="m">{{r.habitacion_id ? 'Hab. ' + nombreHab(r.habitacion_id) : 'Por asignar'}} · {{(+r.adultos||0)+(+r.ninos||0)}} pers.<span v-if="r.vehiculo"> · placa {{r.vehiculo}}</span><span v-if="r.acompanantes"> · {{r.acompanantes}}</span></div></div>
          <Empty v-if="!dia.llegadas.length" icon="🛎" title="Sin llegadas pendientes"></Empty></div></div>
        <div class="card col"><h2>Salen hoy <small>{{dia.salidas.length}}</small></h2><div class="lista">
          <div v-for="r in dia.salidas" :key="r.id" class="hues"><div class="n">Hab. {{nombreHab(r.habitacion_id)}} · {{r.huesped_nombre}}</div><div class="m">{{(+r.adultos||0)+(+r.ninos||0)}} pers.<span v-if="r.vehiculo"> · placa {{r.vehiculo}}</span></div></div>
          <Empty v-if="!dia.salidas.length" icon="🧳" title="Sin salidas hoy"></Empty></div></div>
        <div class="card col"><h2>En casa <small>{{enCasa.length}}</small></h2><div class="lista">
          <div v-for="r in enCasa" :key="r.id" class="hues"><div class="n">Hab. {{nombreHab(r.habitacion_id)}} · {{r.huesped_nombre}}</div><div class="m">{{(+r.adultos||0)+(+r.ninos||0)}} pers. · sale el {{fecha(r.salida)}}<span v-if="r.vehiculo"> · placa {{r.vehiculo}}</span><span v-if="r.acompanantes"> · {{r.acompanantes}}</span><span v-if="r.h && r.h.nacionalidad"> · {{r.h.nacionalidad}}</span></div><div class="small muted" v-if="r.notas || (r.h && r.h.notas)">{{[r.notas, r.h && r.h.notas].filter(Boolean).join(' · ')}}</div></div>
          <Empty v-if="!enCasa.length" icon="🏨" title="Nadie en casa"></Empty></div></div>
      </div>
      <div class="dos" style="margin-top:16px">
        <div class="card" style="margin:0"><h2>Vehículos de huéspedes <small>{{vehiculos.length}}</small></h2>
          <Empty v-if="!vehiculos.length" icon="🚗" title="Sin placas registradas" text="La placa se anota en la reserva o en el check-in."></Empty>
          <table class="tbl" v-else><thead><tr><th>Placa</th><th>Hab.</th><th>Huésped</th></tr></thead><tbody><tr v-for="v in vehiculos" :key="v.placa + v.hab"><td class="mono"><b>{{v.placa}}</b></td><td>{{v.hab}}</td><td>{{v.quien}}</td></tr></tbody></table>
        </div>
        <div class="card" style="margin:0"><h2>Anotar en la bitácora</h2>
          <textarea rows="3" class="inp" style="width:100%" v-model="nota" placeholder="Ronda, novedad, relevo de turno…" :disabled="!puedeEscribir"></textarea>
          <div class="row" style="gap:6px;margin-top:8px;flex-wrap:wrap"><button class="btn sm" @click="anotar('ronda')" :disabled="!puedeEscribir">Ronda</button><button class="btn sm sec" @click="anotar('relevo')" :disabled="!puedeEscribir">Relevo de turno</button><button class="btn sm sec" @click="anotar('nota')" :disabled="!puedeEscribir">Nota</button><span style="flex:1"></span><button class="btn sm ghost" @click="nuevoIncidente()" :disabled="!puedeEscribir">+ Incidente</button><button class="btn sm ghost" @click="nuevaVisita()" :disabled="!puedeEscribir">+ Visitante</button></div>
          <div class="small" style="margin-top:10px" v-for="b in hoyBitacora.slice(0,6)" :key="b.id"><span class="muted">{{fechaHora(b.hora).slice(-5)}} · {{b.usuario}}</span> · <span class="badge">{{b.tipo}}</span> {{b.texto}}</div>
        </div>
      </div>
    </div>

    <div v-if="tab==='bitacora'" class="card">
      <div class="row" style="gap:6px;margin-bottom:10px"><input class="inp" style="flex:1" v-model="nota" placeholder="Anotación de turno" :disabled="!puedeEscribir" @keyup.enter="anotar('nota')"><button class="btn" @click="anotar('nota')" :disabled="!puedeEscribir">Anotar</button></div>
      <Empty v-if="!bitacora.length" icon="📓" title="Bitácora vacía" text="Cada ronda, relevo o novedad queda con hora y oficial."></Empty>
      <table class="tbl" v-else><thead><tr><th>Hora</th><th>Oficial</th><th>Tipo</th><th>Anotación</th></tr></thead><tbody><tr v-for="b in bitacora.slice().sort((a,b)=>String(b.hora).localeCompare(String(a.hora))).slice(0,300)" :key="b.id"><td class="small" style="white-space:nowrap">{{fechaHora(b.hora)}}</td><td class="small">{{b.usuario}}</td><td><span class="badge">{{b.tipo}}</span></td><td style="white-space:normal">{{b.texto}}</td></tr></tbody></table>
    </div>

    <div v-if="tab==='visitantes'" class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar por nombre, documento o placa" v-model="q"><div class="seg"><button :class="{on: filtroV==='dentro'}" @click="filtroV='dentro'">Dentro</button><button :class="{on: filtroV==='hoy'}" @click="filtroV='hoy'">Hoy</button><button :class="{on: filtroV==='todos'}" @click="filtroV='todos'">Todos</button></div><button class="btn" @click="nuevaVisita()" :disabled="!puedeEscribir">+ Registrar entrada</button></div>
      <Empty v-if="!visitantesVer.length" icon="🧍" title="Sin visitantes" text="Registre a quien entra sin reserva: proveedores, visitas de huéspedes, técnicos."></Empty>
      <table class="tbl" v-else><thead><tr><th>Entrada</th><th>Visitante</th><th>Documento</th><th>Placa</th><th>Visita a</th><th>Motivo</th><th>Salida</th><th></th></tr></thead>
        <tbody><tr v-for="v in visitantesVer" :key="v.id"><td class="small" style="white-space:nowrap">{{fechaHora(v.entrada)}}</td><td><b>{{v.nombre}}</b><span class="small muted" v-if="v.personas > 1"> · {{v.personas}} pers.</span></td><td class="mono">{{v.documento}}</td><td class="mono">{{v.placa}}</td><td>{{v.visita_a}}{{v.habitacion_id ? ' · hab. ' + nombreHab(v.habitacion_id) : ''}}</td><td class="small">{{v.motivo}}</td><td class="small">{{v.salida ? fechaHora(v.salida) : 'Dentro'}}</td><td><button class="btn sm" v-if="!v.salida" @click="registrarSalida(v)" :disabled="!puedeEscribir">Salió</button></td></tr></tbody></table>
    </div>

    <div v-if="tab==='incidentes'" class="card">
      <div class="toolbar"><div class="seg"><button :class="{on: filtroI==='abiertos'}" @click="filtroI='abiertos'">Abiertos</button><button :class="{on: filtroI==='graves'}" @click="filtroI='graves'">Graves</button><button :class="{on: filtroI==='todos'}" @click="filtroI='todos'">Todos</button></div><span style="flex:1"></span><button class="btn" @click="nuevoIncidente()" :disabled="!puedeEscribir">+ Incidente</button></div>
      <Empty v-if="!incidentesVer.length" icon="🚨" title="Sin incidentes" text="Ruidos, personas sospechosas, daños, accidentes: quedan con hora, lugar, involucrados y acciones tomadas."></Empty>
      <table class="tbl" v-else><thead><tr><th>Nº</th><th>Hora</th><th>Tipo</th><th>Gravedad</th><th>Lugar</th><th>Descripción</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="i in incidentesVer" :key="i.id" :style="i.estado==='cerrado' ? 'opacity:.65' : ''"><td class="mono">{{i.numero}}</td><td class="small" style="white-space:nowrap">{{fechaHora(i.hora)}}</td><td>{{i.tipo}}</td><td><span class="badge" :class="i.gravedad==='grave' ? 'danger' : i.gravedad==='moderado' ? 'warn' : ''">{{i.gravedad}}</span></td><td>{{i.habitacion_id ? 'Hab. ' + nombreHab(i.habitacion_id) : i.lugar}}</td><td class="small" style="white-space:normal;max-width:360px">{{i.descripcion}}<span v-if="i.involucrados"> · <b>{{i.involucrados}}</b></span><div class="muted" v-if="i.acciones">Acciones: {{i.acciones}}</div></td><td><Badge :value="i.estado==='cerrado' ? 'Cerrado' : 'Abierto'"></Badge></td><td><button class="btn sm ghost" v-if="i.estado!=='cerrado'" @click="cerrarIncidente(i)" :disabled="!puedeEscribir">Cerrar</button></td></tr></tbody></table>
    </div>

    <div v-if="tab==='objetos'" class="card">
      <div class="toolbar"><div class="seg"><button :class="{on: filtroO==='pendientes'}" @click="filtroO='pendientes'">Guardados</button><button :class="{on: filtroO==='entregados'}" @click="filtroO='entregados'">Entregados</button><button :class="{on: filtroO==='todos'}" @click="filtroO='todos'">Todos</button></div><span style="flex:1"></span><button class="btn" @click="nuevoObjeto()" :disabled="!puedeEscribir">+ Objeto encontrado</button></div>
      <Empty v-if="!objetosVer.length" icon="🧳" title="Sin objetos" text="Lo que se encuentra en habitaciones o zonas comunes queda registrado con dónde se guarda y a quién se entrega."></Empty>
      <table class="tbl" v-else><thead><tr><th>Nº</th><th>Encontrado</th><th>Objeto</th><th>Lugar</th><th>Posible dueño</th><th>Guardado en</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="o in objetosVer" :key="o.id"><td class="mono">{{o.numero}}</td><td>{{fecha(o.fecha)}}</td><td><b>{{o.descripcion}}</b><div class="small muted">por {{o.encontrado_por}}</div></td><td>{{o.habitacion_id ? 'Hab. ' + nombreHab(o.habitacion_id) : o.lugar}}</td><td>{{o.huesped_nombre}}</td><td>{{o.guardado_en}}</td><td><Badge :value="o.estado==='guardado' ? 'Guardado' : o.estado==='entregado' ? 'Entregado' : 'Descartado'"></Badge><div class="small muted" v-if="o.entregado_a">{{o.entregado_a}} · {{fechaHora(o.entregado_en)}}</div></td><td style="white-space:nowrap"><button class="btn sm" v-if="o.estado==='guardado'" @click="entregarObjeto(o)" :disabled="!puedeEscribir">Entregar</button> <button class="btn sm ghost" v-if="o.estado==='guardado'" @click="descartarObjeto(o)" :disabled="!puedeEscribir">Descartar</button></td></tr></tbody></table>
    </div>
    </template>

    <Modal v-if="visita" title="Registrar entrada de visitante" @close="visita=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="visita.nombre" maxlength="80"></Field><Field label="Documento"><input v-model="visita.documento" maxlength="30"></Field>
        <Field label="Placa del vehículo"><input v-model="visita.placa" maxlength="12"></Field><Field label="Personas"><input type="number" min="1" v-model.number="visita.personas"></Field>
        <Field label="Visita a (huésped, área o persona)"><input v-model="visita.visita_a" maxlength="80"></Field><Field label="Habitación"><select v-model="visita.habitacion_id"><option :value="null">— Ninguna —</option><option v-for="h in habs" :key="h.id" :value="h.id">{{h.numero}}</option></select></Field>
        <Field label="Motivo" style="grid-column:1/-1"><input v-model="visita.motivo" maxlength="120" placeholder="Entrega, visita, servicio técnico…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="visita=null">Cancelar</button><button class="btn" @click="registrarEntrada">Registrar entrada</button></template>
    </Modal>
    <Modal v-if="incidente" title="Registrar incidente" @close="incidente=null">
      <div class="grid cols-2">
        <Field label="Tipo" req><select v-model="incidente.tipo"><option v-for="t in TIPOS_INCIDENTE" :key="t">{{t}}</option></select></Field>
        <Field label="Gravedad"><select v-model="incidente.gravedad"><option value="leve">Leve</option><option value="moderado">Moderado</option><option value="grave">Grave</option></select></Field>
        <Field label="Habitación"><select v-model="incidente.habitacion_id"><option :value="null">— Zona común —</option><option v-for="h in habs" :key="h.id" :value="h.id">{{h.numero}}</option></select></Field>
        <Field label="Lugar" v-if="!incidente.habitacion_id"><input v-model="incidente.lugar" maxlength="80" placeholder="Parqueo, piscina, lobby…"></Field>
        <Field label="Involucrados" style="grid-column:1/-1"><input v-model="incidente.involucrados" maxlength="160" placeholder="Huésped de la 204, visitante sin registro…"></Field>
        <Field label="Qué ocurrió" req style="grid-column:1/-1"><textarea rows="3" v-model="incidente.descripcion" maxlength="800"></textarea></Field>
        <Field label="Acciones tomadas" style="grid-column:1/-1"><input v-model="incidente.acciones" maxlength="300" placeholder="Se habló con el huésped, se llamó al 911…"></Field>
      </div>
      <label class="row" style="gap:8px;margin-top:10px;cursor:pointer"><input type="checkbox" v-model="incidente.avisar_mantenimiento"> Avisar a Mantenimiento (daño a reparar)</label>
      <template #foot><button class="btn ghost" @click="incidente=null">Cancelar</button><button class="btn" @click="guardarIncidente">Registrar</button></template>
    </Modal>
    <Modal v-if="objeto" title="Objeto encontrado" @close="objeto=null">
      <div class="grid cols-2">
        <Field label="Objeto" req style="grid-column:1/-1"><input v-model="objeto.descripcion" maxlength="160" placeholder="Reloj plateado, cargador, pasaporte…"></Field>
        <Field label="Habitación"><select v-model="objeto.habitacion_id"><option :value="null">— Zona común —</option><option v-for="h in habs" :key="h.id" :value="h.id">{{h.numero}}</option></select></Field>
        <Field label="Lugar" v-if="!objeto.habitacion_id"><input v-model="objeto.lugar" maxlength="80"></Field>
        <Field label="Fecha"><input type="date" v-model="objeto.fecha"></Field><Field label="Guardado en"><input v-model="objeto.guardado_en" maxlength="60"></Field>
        <Field label="Posible dueño"><input v-model="objeto.huesped_nombre" maxlength="80"></Field><Field label="Encontrado por"><input v-model="objeto.encontrado_por" maxlength="60"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="objeto=null">Cancelar</button><button class="btn" @click="guardarObjeto">Registrar</button></template>
    </Modal>
  </div>`,
  setup() { return { MODULOS_REPORTE }; },
};
