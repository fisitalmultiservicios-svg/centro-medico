// Hotel › Reservaciones › Histórico (H21): búsqueda de reservas de cualquier fecha y estado con criterios que se combinan, y la
// historia de una habitación (estadías y bloqueos) en un rango de fechas. Es solo de consulta: no guarda nada. Los criterios
// aplicados quedan en la dirección de la página, así el botón Atrás del navegador vuelve con la misma búsqueda.
// Tolera reservas sin los campos que llegan después (agente_id, origen_negocio, reservante_nombre) y sin total (roles sin montos).
import { toast, money, fecha, sumarDias, mock } from '../../api.js';
import { exportarTabla } from '../reportes/_montos.js';
import { config, hotelActivo, reservas, esEstadia, huespedes, folios, totalCargo, agencias, categorias, todasHabitaciones, noches, ESTADOS, ORIGENES, segmentos, convertirMonto, r2, hoyHotel, abrirHoja, encabezadoHoja, vuelosTexto } from './_datos.js';

// criterios de la dirección: l = entrada, s = salida, c = creación (d = desde, h = hasta); hd y hh son el rango de «Por habitación»
const CLAVES = ['ld', 'lh', 'sd', 'sh', 'cd', 'ch', 'num', 'q', 'agencia', 'seg', 'origen', 'negocio', 'agente', 'cat', 'hab', 'estados', 'nac', 'grupo', 'esp', 'hd', 'hh'];
const SIN_NAC = 'Sin indicar';
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hayCriterio = c => CLAVES.some(k => k !== 'hd' && k !== 'hh' && c[k]);
// Los criterios tal como vienen en la dirección. Sin ninguno (entrada desde el menú) se proponen los últimos 12 meses por fecha de
// entrada, para no recorrer años de reservas sin que se pida; «todo=1» dice que la búsqueda sin fechas fue a propósito.
export function criterios(p) {
  const c = {}, hoyS = hoyHotel();
  for (const k of CLAVES) c[k] = p && p[k] !== undefined && p[k] !== null && p[k] !== false ? String(p[k]).trim() : '';
  if (!(p && p.todo) && !hayCriterio(c)) c.ld = sumarDias(hoyS, -365);
  if (!c.hd) c.hd = sumarDias(hoyS, -365);
  if (!c.hh) c.hh = hoyS;
  return c;
}

export default {
  props: ['params'],
  data() { const c = criterios(this.params); return { cfg: config(), activo: hotelActivo(), tab: this.params.tab === 'habitacion' ? 'habitacion' : 'reservas', f: { ...c }, ap: c, ESTADOS, ORIGENES, segs: segmentos() }; },
  computed: {
    todas() { return reservas(); },
    lista() { return this.todas.filter(esEstadia); },
    huPorId() { return new Map(huespedes().map(x => [x.id, x])); },
    agenciasLista() { return agencias(); },
    agPorId() { return new Map(this.agenciasLista.map(x => [x.id, x])); },
    cats() { return categorias(); },
    catPorId() { return new Map(this.cats.map(x => [x.id, x])); },
    habs() { return todasHabitaciones(); },
    habPorId() { return new Map(this.habs.map(x => [x.id, x])); },
    agentes() { const l = mock.get('vendedores', []); return Array.isArray(l) ? l : []; },
    nacionalidades() { const s = new Set(); for (const r of this.lista) s.add((this.huPorId.get(r.huesped_id) || {}).nacionalidad || SIN_NAC); return [...s].sort((a, b) => a.localeCompare(b, 'es')); },
    negocios() { const s = new Set(); for (const r of this.lista) if (r.origen_negocio) s.add(String(r.origen_negocio)); return [...s].sort((a, b) => a.localeCompare(b, 'es')); },
    pendiente() { return CLAVES.some(k => String(this.f[k] ?? '').trim() !== this.ap[k]); },
    // Resultado: solo se recalcula al pulsar «Aplicar» (this.ap), no con cada letra
    filas() {
      const a = this.ap, cfg = this.cfg, q = a.q.toLowerCase(), num = a.num.toLowerCase(), grupo = a.grupo.toLowerCase(), est = a.estados ? a.estados.split(',') : [], out = [];
      for (const r of this.lista) {
        if (a.ld && !(r.llegada >= a.ld)) continue;
        if (a.lh && !(r.llegada <= a.lh)) continue;
        if (a.sd && !(r.salida >= a.sd)) continue;
        if (a.sh && !(r.salida <= a.sh)) continue;
        const creada = String(r.creado || '').slice(0, 10);
        if (a.cd && !(creada >= a.cd)) continue;
        if (a.ch && !(creada && creada <= a.ch)) continue;
        if (num && !String(r.numero || '').toLowerCase().includes(num)) continue;
        if (est.length && !est.includes(r.estado)) continue;
        if (a.agencia && String(r.agencia_id || '') !== a.agencia) continue;
        if (a.seg && (r.segmento || '') !== a.seg) continue;
        if (a.origen && (r.origen || '') !== a.origen) continue;
        if (a.negocio && String(r.origen_negocio || '') !== a.negocio) continue;
        if (a.agente && String(r.agente_id || '') !== a.agente) continue;
        if (a.cat && String(r.categoria_id || '') !== a.cat) continue;
        if (a.hab && String(r.habitacion_id || '') !== a.hab) continue;
        if (grupo && !String(r.grupo || '').toLowerCase().includes(grupo)) continue;
        if (a.esp && !String(r.especiales || '').trim()) continue;
        const h = this.huPorId.get(r.huesped_id) || {}, nacionalidad = h.nacionalidad || SIN_NAC;
        if (a.nac && nacionalidad !== a.nac) continue;
        if (q && ![r.huesped_nombre, r.reservante_nombre, h.documento, r.referencia].some(x => String(x || '').toLowerCase().includes(q))) continue;
        out.push({ ...r, nacionalidad, cat: (this.catPorId.get(r.categoria_id) || {}).nombre || '—', hab: r.habitacion_id ? String((this.habPorId.get(r.habitacion_id) || {}).numero || '—') : '—', noches_n: noches(r.llegada, r.salida), personas: (+r.adultos || 0) + (+r.ninos || 0),
          agencia: (this.agPorId.get(r.agencia_id) || {}).nombre || '', segmento: r.segmento || '', estado_txt: ESTADOS[r.estado] || r.estado || '', total: convertirMonto(+r.total || 0, r.moneda || cfg.moneda, cfg.moneda, cfg) });
      }
      return out.sort((x, y) => String(y.llegada).localeCompare(String(x.llegada)) || String(x.numero).localeCompare(String(y.numero)));
    },
    columnas() {
      const m = this.cfg.moneda;
      return [{ key: 'numero', label: 'Reserva', mono: true, link: r => this.abrir(r) }, { key: 'huesped_nombre', label: 'Huésped', fmt: (v, r) => (r.vip ? '★ ' : '') + (v || '—') }, { key: 'nacionalidad', label: 'Nacionalidad' }, { key: 'cat', label: 'Categoría' }, { key: 'hab', label: 'Hab.' },
        { key: 'llegada', label: 'Entrada', fmt: 'date' }, { key: 'salida', label: 'Salida', fmt: 'date' }, { key: 'noches_n', label: 'Noches', num: true }, { key: 'personas', label: 'Pers.', num: true }, { key: 'agencia', label: 'Agencia' }, { key: 'segmento', label: 'Mercado' },
        { key: 'estado_txt', label: 'Estado', fmt: 'badge' }, { key: 'total', label: 'Total', num: true, fmt: v => money(v || 0, m) }];
    },
    // noches y valor sin las canceladas ni las no presentadas (no se hospedaron)
    resumen() {
      const vivas = this.filas.filter(r => !['cancelada', 'no_show'].includes(r.estado));
      return { n: this.filas.length, canceladas: this.filas.length - vivas.length, noches: vivas.reduce((s, r) => s + r.noches_n, 0), valor: r2(vivas.reduce((s, r) => s + (+r.total || 0), 0)) };
    },
    textoCriterios() {
      const a = this.ap, rango = (t, d, h) => (d || h ? t + (d ? ' desde ' + fecha(d) : '') + (h ? ' hasta ' + fecha(h) : '') : '');
      return [rango('Entrada', a.ld, a.lh), rango('Salida', a.sd, a.sh), rango('Creación', a.cd, a.ch), a.num && 'Reserva ' + a.num, a.q && 'Huésped o reservante: ' + a.q, a.agencia && 'Agencia: ' + ((this.agPorId.get(+a.agencia) || {}).nombre || a.agencia),
        a.seg && 'Mercado: ' + a.seg, a.origen && 'Origen: ' + (ORIGENES.find(o => o[0] === a.origen) || [0, a.origen])[1], a.negocio && 'Origen del negocio: ' + a.negocio, a.agente && 'Agente: ' + ((this.agentes.find(x => String(x.id) === a.agente) || {}).nombre || a.agente),
        a.cat && 'Categoría: ' + ((this.catPorId.get(+a.cat) || {}).nombre || a.cat), a.hab && 'Habitación ' + ((this.habPorId.get(+a.hab) || {}).numero || a.hab), a.estados && 'Estado: ' + a.estados.split(',').map(k => ESTADOS[k] || k).join(', '),
        a.nac && 'Nacionalidad: ' + a.nac, a.grupo && 'Grupo: ' + a.grupo, a.esp && 'Con pedidos especiales'].filter(Boolean).join(' · ');
    },
    // «Por habitación»: estadías y bloqueos de la habitación que tocan el rango; el hospedaje sale de los cargos del folio de esas noches
    porHab() {
      const a = this.ap, hab = this.habPorId.get(+a.hab) || null, vacio = { hab, filas: [], dias: 0, ocupadas: 0, bloqueadas: 0, pct: 0, ingreso: 0 };
      if (!hab || !a.hd || !a.hh || a.hh < a.hd) return vacio;
      const cfg = this.cfg, fin = sumarDias(a.hh, 1), cobrado = new Map();   // el rango incluye la noche del último día
      for (const x of folios()) { if (x.tipo !== 'cargo' || x.origen !== 'hospedaje' || !(x.fecha >= a.hd && x.fecha <= a.hh)) continue; const k = x.reserva_origen_id || x.reserva_id; cobrado.set(k, (cobrado.get(k) || 0) + convertirMonto(totalCargo(x), x.moneda || cfg.moneda, cfg.moneda, cfg)); }
      const filas = this.todas.filter(r => r.habitacion_id === hab.id && r.tipo !== 'folio' && !['cancelada', 'no_show'].includes(r.estado) && r.llegada < fin && r.salida > a.hd).map(r => {
        const bloqueo = r.tipo === 'bloqueo', desde = r.llegada > a.hd ? r.llegada : a.hd, hasta = r.salida < fin ? r.salida : fin;
        return { id: r.id, bloqueo, tipo: bloqueo ? 'Bloqueo' : 'Estadía', numero: bloqueo ? '' : (r.numero || ''), huesped: bloqueo ? (r.motivo || 'Bloqueo') : (r.huesped_nombre || '—'), llegada: r.llegada, salida: r.salida, noches_n: noches(r.llegada, r.salida), en_rango: noches(desde, hasta),
          estado_txt: bloqueo ? 'Bloqueo' : (ESTADOS[r.estado] || r.estado || ''), hospedaje: bloqueo ? 0 : r2(cobrado.get(r.id) || 0) };
      }).sort((x, y) => String(y.llegada).localeCompare(String(x.llegada)));
      const dias = noches(a.hd, fin), ocupadas = filas.filter(x => !x.bloqueo).reduce((s, x) => s + x.en_rango, 0);
      return { hab, filas, dias, ocupadas, bloqueadas: filas.filter(x => x.bloqueo).reduce((s, x) => s + x.en_rango, 0), pct: dias ? Math.round(ocupadas / dias * 100) : 0, ingreso: r2(filas.reduce((s, x) => s + x.hospedaje, 0)) };
    },
    columnasHab() {
      const m = this.cfg.moneda;
      return [{ key: 'tipo', label: 'Tipo' }, { key: 'numero', label: 'Reserva', mono: true }, { key: 'huesped', label: 'Huésped o motivo' }, { key: 'llegada', label: 'Entrada', fmt: 'date' }, { key: 'salida', label: 'Salida', fmt: 'date' }, { key: 'noches_n', label: 'Noches', num: true },
        { key: 'en_rango', label: 'Noches en el período', num: true }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' }, { key: 'hospedaje', label: 'Hospedaje en el período', num: true, fmt: v => money(v || 0, m) }];
    },
  },
  watch: {
    // Atrás o Adelante del navegador (o el menú) cambian la dirección sin volver a montar la pantalla: se toman sus criterios
    params(p) { const c = criterios(p), t = p && p.tab === 'habitacion' ? 'habitacion' : 'reservas'; if (t !== this.tab || JSON.stringify(c) !== JSON.stringify(this.ap)) { this.tab = t; this.ap = c; this.f = { ...c }; } },
  },
  methods: {
    money, fecha,
    catDe(h) { return (this.catPorId.get(h.categoria_id) || {}).nombre || ''; },
    tieneEstado(k) { return String(this.f.estados || '').split(',').includes(k); },
    alternarEstado(k) { const l = String(this.f.estados || '').split(',').filter(Boolean); this.f.estados = (l.includes(k) ? l.filter(x => x !== k) : [...l, k]).join(','); },
    // Aplica lo escrito y lo deja en la dirección (una entrada nueva del historial: Atrás vuelve a la búsqueda anterior)
    aplicar() {
      const c = criterios({ ...this.f, todo: '1' }), base = criterios({ todo: '1' });
      this.ap = c; this.f = { ...c };
      const q = new URLSearchParams();
      if (this.tab === 'habitacion') q.set('tab', 'habitacion');
      for (const k of CLAVES) if (c[k] && !((k === 'hd' || k === 'hh') && this.tab !== 'habitacion' && c[k] === base[k])) q.set(k, c[k]);   // el rango de «Por habitación» solo va si se usa
      if (!hayCriterio(c)) q.set('todo', '1');
      const destino = '/hotel/historico?' + q.toString();
      if (location.hash.slice(1) !== destino) location.hash = destino;
    },
    limpiar() { for (const k of CLAVES) if (k !== 'hd' && k !== 'hh') this.f[k] = ''; this.aplicar(); },
    cambiarTab(t) { if (t === this.tab) return; this.tab = t; this.aplicar(); },
    abrir(r) { if (r && r.id && !r.bloqueo) location.hash = '/hotel/reservaciones/' + r.id; },
    exportar() {
      const a = this.ap, periodo = a.ld || a.lh ? 'Entrada' + (a.ld ? ' desde ' + fecha(a.ld) : '') + (a.lh ? ' hasta ' + fecha(a.lh) : '') : '';
      return exportarTabla('hotel_historico', this.columnas, this.filas, { titulo: 'Histórico de reservas', periodo });
    },
    exportarHab() {
      const p = this.porHab; if (!p.hab) return toast('Elija la habitación', 'err');
      return exportarTabla('hotel_historico_habitacion', this.columnasHab, p.filas, { titulo: 'Histórico de la habitación ' + p.hab.numero, periodo: fecha(this.ap.hd) + ' al ' + fecha(this.ap.hh) });
    },
    // Rooming list de lo filtrado (hoja imprimible, como la de Grupos)
    roomingList() {
      const todas = this.filas, tope = 500, l = todas.slice(0, tope), m = this.cfg.moneda;
      if (!l.length) return toast('No hay reservas para la rooming list');
      const filas = l.map(r => '<tr><td>' + esc(r.numero) + '</td><td>' + esc(r.hab) + '</td><td>' + esc(r.cat) + '</td><td>' + esc(r.huesped_nombre) + '</td><td class="n">' + r.personas + '</td><td>' + esc(fecha(r.llegada)) + '</td><td>' + esc(fecha(r.salida)) + '</td><td>' + esc(vuelosTexto(r)) + '</td><td>' + esc(r.estado_txt) + '</td><td class="n">' + esc(money(r.total || 0, m)) + '</td></tr>').join('');
      abrirHoja('Rooming list · histórico', encabezadoHoja('Rooming list · ' + l.length + ' reserva(s)') + '<div class="muted">' + esc(this.textoCriterios || 'Todas las reservas') + '</div><table style="margin-top:10px"><thead><tr><th>Reserva</th><th>Hab.</th><th>Categoría</th><th>Huésped</th><th class="n">Pers.</th><th>Entrada</th><th>Salida</th><th>Vuelo</th><th>Estado</th><th class="n">Total</th></tr></thead><tbody>' + filas
        + '</tbody><tbody class="tot"><tr><td colspan="9">Total · ' + l.reduce((s, r) => s + r.personas, 0) + ' persona(s)</td><td class="n">' + esc(money(r2(l.reduce((s, r) => s + (+r.total || 0), 0)), m)) + '</td></tr></tbody></table>'
        + (todas.length > tope ? '<p class="muted">Se muestran las primeras ' + tope + ' de ' + todas.length + ' reservas: acote los criterios para verlas todas.</p>' : ''));
    },
  },
  template: `
  <div class="page">
    <PageHead title="Histórico de reservas" sub="Busque reservas de cualquier fecha y estado combinando criterios, o vea la historia de una habitación. Es solo de consulta: aquí no se cambia nada." :crumbs="[{label:'Hotel'},{label:'Reservaciones',to:'/hotel/reservaciones'},{label:'Histórico'}]"></PageHead>
    <div class="card" v-if="!activo"><Empty icon="🗂" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="tabs"><button :class="{on: tab==='reservas'}" @click="cambiarTab('reservas')">Reservas</button><button :class="{on: tab==='habitacion'}" @click="cambiarTab('habitacion')">Por habitación</button></div>
    <template v-if="tab==='reservas'">
    <div class="card"><h2>Criterios <small>todos son opcionales y se combinan entre sí</small></h2>
      <div class="grid">
        <Field label="Entrada: desde y hasta"><div class="row" style="gap:6px;flex-wrap:nowrap"><input type="date" v-model="f.ld" style="flex:1;min-width:0"><input type="date" v-model="f.lh" style="flex:1;min-width:0"></div></Field>
        <Field label="Salida: desde y hasta"><div class="row" style="gap:6px;flex-wrap:nowrap"><input type="date" v-model="f.sd" style="flex:1;min-width:0"><input type="date" v-model="f.sh" style="flex:1;min-width:0"></div></Field>
        <Field label="Creación: desde y hasta"><div class="row" style="gap:6px;flex-wrap:nowrap"><input type="date" v-model="f.cd" style="flex:1;min-width:0"><input type="date" v-model="f.ch" style="flex:1;min-width:0"></div></Field>
        <Field label="Número de reserva"><input v-model="f.num" maxlength="20" placeholder="R-0123" @keyup.enter="aplicar"></Field>
        <Field label="Huésped o reservante" help="Nombre, documento o referencia del canal"><input v-model="f.q" maxlength="60" @keyup.enter="aplicar"></Field>
        <Field label="Agencia o empresa" v-if="agenciasLista.length"><Buscador v-model="f.agencia" :opciones="agenciasLista" placeholder="Todas"></Buscador></Field>
        <Field label="Mercado (segmento)"><select v-model="f.seg"><option value="">Todos</option><option v-for="s in segs" :key="s" :value="s">{{s}}</option></select></Field>
        <Field label="Origen"><select v-model="f.origen"><option value="">Todos</option><option v-for="o in ORIGENES" :key="o[0]" :value="o[0]">{{o[1]}}</option></select></Field>
        <Field label="Origen del negocio" v-if="negocios.length || f.negocio"><select v-model="f.negocio"><option value="">Todos</option><option v-for="x in negocios" :key="x" :value="x">{{x}}</option></select></Field>
        <Field label="Agente de ventas" v-if="agentes.length"><select v-model="f.agente"><option value="">Todos</option><option v-for="x in agentes" :key="x.id" :value="String(x.id)">{{x.nombre}}</option></select></Field>
        <Field label="Categoría"><select v-model="f.cat"><option value="">Todas</option><option v-for="c in cats" :key="c.id" :value="String(c.id)">{{c.nombre}}</option></select></Field>
        <Field label="Habitación"><Buscador v-model="f.hab" :opciones="habs" etiqueta="numero" :detalle="catDe" placeholder="Todas"></Buscador></Field>
        <Field label="Nacionalidad"><select v-model="f.nac"><option value="">Todas</option><option v-for="x in nacionalidades" :key="x" :value="x">{{x}}</option></select></Field>
        <Field label="Grupo"><input v-model="f.grupo" maxlength="60" @keyup.enter="aplicar"></Field>
      </div>
      <div class="row" style="gap:14px;flex-wrap:wrap;align-items:center;margin-top:12px"><span class="small muted">Estado (ninguno marcado = todos):</span><label v-for="(t, k) in ESTADOS" :key="k" class="row small" style="gap:4px;cursor:pointer"><input type="checkbox" :checked="tieneEstado(k)" @change="alternarEstado(k)"> {{t}}</label>
        <Toggle :model-value="!!f.esp" @update:model-value="f.esp = $event ? '1' : ''" label="Solo con pedidos especiales"></Toggle></div>
      <div class="row" style="gap:6px;margin-top:12px;align-items:center"><button class="btn" @click="aplicar">Aplicar</button><button class="btn ghost" @click="limpiar">Quitar criterios</button><span class="small muted" v-if="pendiente">Hay cambios sin aplicar.</span></div>
    </div>
    <div class="card"><h2>Resultado <small>{{filas.length}} reserva(s){{textoCriterios ? ' · ' + textoCriterios : ' · sin criterios: todas las reservas'}}</small></h2>
      <DataTable :rows="filas" :columns="columnas" :page-size="50" empty-title="Sin reservas" empty-text="Ninguna reserva cumple los criterios aplicados." @row-click="abrir"></DataTable>
      <div class="totals" v-if="filas.length"><div><span>Reservas</span><b>{{resumen.n}}</b></div><div v-if="resumen.canceladas"><span>De ellas, canceladas o no presentadas</span><b>{{resumen.canceladas}}</b></div><div><span>Noches{{resumen.canceladas ? ' (sin las canceladas)' : ''}}</span><b>{{resumen.noches}}</b></div><div class="total"><span>Valor{{resumen.canceladas ? ' (sin las canceladas)' : ''}}</span><b>{{money(resumen.valor, cfg.moneda)}}</b></div></div>
      <div class="row" style="gap:6px;margin-top:12px" v-if="filas.length"><button class="btn sec" @click="exportar" title="PDF, Excel o CSV">Exportar</button><button class="btn ghost" @click="roomingList">Rooming list</button></div>
    </div>
    </template>
    <template v-else>
    <div class="card"><h2>Habitación y período</h2>
      <div class="grid">
        <Field label="Habitación" req><Buscador v-model="f.hab" :opciones="habs" etiqueta="numero" :detalle="catDe" placeholder="Elija la habitación"></Buscador></Field>
        <Field label="Desde"><input type="date" v-model="f.hd"></Field>
        <Field label="Hasta"><input type="date" v-model="f.hh" :min="f.hd"></Field>
      </div>
      <div class="row" style="gap:6px;margin-top:12px;align-items:center"><button class="btn" @click="aplicar">Ver la historia</button><span class="small muted" v-if="pendiente">Hay cambios sin aplicar.</span></div>
    </div>
    <div class="card">
      <Empty v-if="!porHab.hab" icon="🛏" title="Elija una habitación" text="Verá cada estadía y cada bloqueo del período, con las noches ocupadas y el hospedaje cobrado."></Empty>
      <template v-else>
      <h2>Habitación {{porHab.hab.numero}} <small>{{catDe(porHab.hab)}} · {{fecha(ap.hd)}} al {{fecha(ap.hh)}}</small></h2>
      <DataTable :rows="porHab.filas" :columns="columnasHab" :page-size="50" empty-title="Sin estadías ni bloqueos" empty-text="La habitación no tuvo estadías ni bloqueos en ese período." @row-click="abrir"></DataTable>
      <div class="totals"><div><span>Noches ocupadas de {{porHab.dias}}</span><b>{{porHab.ocupadas}}</b></div><div><span>Ocupación</span><b>{{porHab.pct}} %</b></div><div><span>Días bloqueados</span><b>{{porHab.bloqueadas}}</b></div><div class="total"><span>Hospedaje cobrado en el período</span><b>{{money(porHab.ingreso, cfg.moneda)}}</b></div></div>
      <p class="small muted" style="margin:8px 0 0">Una estadía que cambió de habitación aparece en la habitación donde terminó. No se cuentan las reservas canceladas ni las no presentadas.</p>
      <div class="row" style="gap:6px;margin-top:12px" v-if="porHab.filas.length"><button class="btn sec" @click="exportarHab" title="PDF, Excel o CSV">Exportar</button></div>
      </template>
    </div>
    </template>
    </template>
  </div>`,
};
