// Hotel (2.2): registros por empresa y reglas compartidas por Recepción, Reservaciones, Calendario, Huéspedes y Reportes.
//  - hotel_config (valor): datos del hotel, horarios, moneda, IVA, CABYS, adelanto, temporadas, tarifas por categoría × temporada, planes.
//  - hotel_categorias, hotel_habitaciones, hotel_reservas (reservas y bloqueos), hotel_huespedes, hotel_folios (cargos y pagos por reserva): colecciones.
// Las fechas son 'AAAA-MM-DD' en hora de Costa Rica. Una estadía del 17 al 19 ocupa las noches del 17 y del 18: el día de salida
// queda libre para otra llegada (misma regla que el servidor, app/hotel.py).
import { api, mock, hoy, sumarDias, money, fmt, siguienteNumero, monedas, toast, cabecerasAuth, otroImpLinea } from '../../api.js';
import { sesion, store } from '../../app.js';

export const ESTADOS = { pendiente: 'Pendiente', confirmada: 'Confirmada', en_casa: 'En casa', salio: 'Salió', cancelada: 'Cancelada', no_show: 'No llegó' };
export const CLASE_ESTADO = { pendiente: 'pend', confirmada: 'conf', en_casa: 'casa', salio: 'pasada', cancelada: 'canc', no_show: 'canc' };
export const ORIGENES = [['directa', 'Directa (teléfono, WhatsApp, mostrador)'], ['web', 'Página web del hotel'], ['booking', 'Booking.com'], ['airbnb', 'Airbnb'], ['expedia', 'Expedia'], ['agencia', 'Agencia u operador'], ['empresa', 'Empresa (corporativo)'], ['otro', 'Otro']];
export const MEDIOS = [['01', 'Efectivo', '💵'], ['02', 'Tarjeta', '💳'], ['06', 'SINPE Móvil', '📱'], ['04', 'Transferencia / depósito', '🏦'], ['07', 'Plataforma (Booking, Airbnb, pasarela)', '🌐'], ['99', 'Otro', '…']];
export const ESTADOS_HAB = [['limpia', 'Limpia'], ['sucia', 'Sucia'], ['limpiando', 'En limpieza'], ['inspeccion', 'Lista para inspección'], ['mantenimiento', 'Mantenimiento']];   // inspección (3.21): la camarera terminó; la supervisora la deja limpia
// Países (en español) para nacionalidad y país del huésped: lista con sugerencias al escribir (2.6). Se puede escribir uno que no esté.
export const PAISES = ['Costa Rica', 'Estados Unidos', 'Canadá', 'México', 'Guatemala', 'Honduras', 'El Salvador', 'Nicaragua', 'Panamá', 'Colombia', 'Venezuela', 'Ecuador', 'Perú', 'Bolivia', 'Chile', 'Argentina', 'Uruguay', 'Paraguay', 'Brasil', 'Cuba', 'República Dominicana', 'Puerto Rico', 'Jamaica', 'Haití', 'Bahamas', 'Barbados', 'Trinidad y Tobago', 'Belice', 'Guyana', 'Surinam', 'España', 'Portugal', 'Francia', 'Alemania', 'Italia', 'Reino Unido', 'Irlanda', 'Países Bajos', 'Bélgica', 'Luxemburgo', 'Suiza', 'Austria', 'Dinamarca', 'Suecia', 'Noruega', 'Finlandia', 'Islandia', 'Polonia', 'República Checa', 'Eslovaquia', 'Hungría', 'Rumania', 'Bulgaria', 'Grecia', 'Croacia', 'Eslovenia', 'Serbia', 'Bosnia y Herzegovina', 'Montenegro', 'Macedonia del Norte', 'Albania', 'Ucrania', 'Rusia', 'Bielorrusia', 'Lituania', 'Letonia', 'Estonia', 'Moldavia', 'Malta', 'Chipre', 'Turquía', 'Georgia', 'Armenia', 'Azerbaiyán', 'China', 'Japón', 'Corea del Sur', 'Corea del Norte', 'Taiwán', 'Hong Kong', 'India', 'Pakistán', 'Bangladés', 'Sri Lanka', 'Nepal', 'Bután', 'Maldivas', 'Tailandia', 'Vietnam', 'Filipinas', 'Indonesia', 'Malasia', 'Singapur', 'Camboya', 'Laos', 'Myanmar', 'Mongolia', 'Kazajistán', 'Uzbekistán', 'Kirguistán', 'Tayikistán', 'Turkmenistán', 'Afganistán', 'Irán', 'Irak', 'Israel', 'Palestina', 'Jordania', 'Líbano', 'Siria', 'Arabia Saudita', 'Emiratos Árabes Unidos', 'Catar', 'Kuwait', 'Baréin', 'Omán', 'Yemen', 'Australia', 'Nueva Zelanda', 'Fiyi', 'Papúa Nueva Guinea', 'Samoa', 'Tonga', 'Marruecos', 'Argelia', 'Túnez', 'Libia', 'Egipto', 'Sudán', 'Etiopía', 'Eritrea', 'Yibuti', 'Somalia', 'Kenia', 'Uganda', 'Tanzania', 'Ruanda', 'Burundi', 'República Democrática del Congo', 'República del Congo', 'Gabón', 'Camerún', 'Nigeria', 'Ghana', 'Costa de Marfil', 'Senegal', 'Malí', 'Burkina Faso', 'Níger', 'Chad', 'Mauritania', 'Guinea', 'Sierra Leona', 'Liberia', 'Togo', 'Benín', 'Angola', 'Zambia', 'Zimbabue', 'Mozambique', 'Malaui', 'Madagascar', 'Mauricio', 'Seychelles', 'Namibia', 'Botsuana', 'Sudáfrica', 'Lesoto', 'Esuatini', 'Cabo Verde', 'Guinea Ecuatorial', 'Santo Tomé y Príncipe'];
// Gentilicio (femenino, como en el ICT) para mostrar junto al país; si no está, se usa el país
export const GENTILICIOS = { 'Costa Rica': 'costarricense', 'Estados Unidos': 'estadounidense', 'Canadá': 'canadiense', 'México': 'mexicana', 'Guatemala': 'guatemalteca', 'Honduras': 'hondureña', 'El Salvador': 'salvadoreña', 'Nicaragua': 'nicaragüense', 'Panamá': 'panameña', 'Colombia': 'colombiana', 'Venezuela': 'venezolana', 'Ecuador': 'ecuatoriana', 'Perú': 'peruana', 'Bolivia': 'boliviana', 'Chile': 'chilena', 'Argentina': 'argentina', 'Uruguay': 'uruguaya', 'Paraguay': 'paraguaya', 'Brasil': 'brasileña', 'Cuba': 'cubana', 'República Dominicana': 'dominicana', 'España': 'española', 'Portugal': 'portuguesa', 'Francia': 'francesa', 'Alemania': 'alemana', 'Italia': 'italiana', 'Reino Unido': 'británica', 'Irlanda': 'irlandesa', 'Países Bajos': 'neerlandesa', 'Bélgica': 'belga', 'Suiza': 'suiza', 'Austria': 'austriaca', 'Dinamarca': 'danesa', 'Suecia': 'sueca', 'Noruega': 'noruega', 'Finlandia': 'finlandesa', 'Polonia': 'polaca', 'Rusia': 'rusa', 'Ucrania': 'ucraniana', 'Grecia': 'griega', 'Turquía': 'turca', 'China': 'china', 'Japón': 'japonesa', 'Corea del Sur': 'coreana', 'India': 'india', 'Israel': 'israelí', 'Australia': 'australiana', 'Nueva Zelanda': 'neozelandesa', 'Sudáfrica': 'sudafricana', 'Egipto': 'egipcia', 'Marruecos': 'marroquí', 'Filipinas': 'filipina', 'Tailandia': 'tailandesa', 'Vietnam': 'vietnamita', 'Indonesia': 'indonesia', 'Taiwán': 'taiwanesa', 'Jamaica': 'jamaiquina', 'Haití': 'haitiana', 'Puerto Rico': 'puertorriqueña', 'Belice': 'beliceña', 'Arabia Saudita': 'saudita', 'Emiratos Árabes Unidos': 'emiratí' };
export function opcionesPais(q) { const s = String(q || '').toLowerCase(); return PAISES.filter(p => !s || p.toLowerCase().includes(s) || (GENTILICIOS[p] || '').includes(s)); }
export const TIPOS_DOC = [['cedula', 'Cédula'], ['pasaporte', 'Pasaporte'], ['dimex', 'DIMEX'], ['otro', 'Otro']];
export const OCASIONES = [['', 'Ninguna'], ['cumpleanos', 'Cumpleaños'], ['aniversario', 'Aniversario'], ['luna_miel', 'Luna de miel'], ['trabajo', 'Viaje de trabajo'], ['otra', 'Otra']];
export const CABYS_HOSPEDAJE = '6311100000000';
// ---- segmentos de mercado y conceptos de producción (3.0) ----
export const SEGMENTOS_BASE = ['Ocio', 'Corporativo', 'Grupo', 'Agencia u OTA', 'Evento', 'Residente'];
export function segmentos(cfg) { const c = cfg || config(); return Array.isArray(c.segmentos) && c.segmentos.length ? c.segmentos : SEGMENTOS_BASE; }
export const CONCEPTOS = [['hospedaje', 'Hospedaje'], ['pos', 'Restaurante y bar'], ['servicios', 'Servicios (spa, tours, traslados)'], ['eventos', 'Eventos y banquetes'], ['auto', 'Cargos automáticos'], ['minibar', 'Minibar'], ['manual', 'Otros cargos'], ['servicio', 'Impuesto de servicio']];
export function conceptoDe(f) { if (f.es_otro_cargo) return 'servicio'; return ['hospedaje', 'pos', 'auto', 'servicios', 'eventos', 'minibar'].includes(f.origen) ? f.origen : 'manual'; }
export function nombreConcepto(k) { return (CONCEPTOS.find(x => x[0] === k) || [k, k])[1]; }
export const TIPOS_CARGO_AUTO = [['noche', 'Por noche'], ['persona_noche', 'Por persona y noche'], ['estadia', 'Una vez por estadía']];
export function nombreTipoAuto(k) { return (TIPOS_CARGO_AUTO.find(x => x[0] === k) || [k, k])[1]; }     // Servicios de alojamiento para visitantes, estancias cortas, con servicio de limpieza (13 %)

export function nombreOrigen(o) { return (ORIGENES.find(x => x[0] === o) || [o, o || '—'])[1]; }
export function nombrePlan(id, cfg) { const c = cfg || config(); return ((c.planes || []).find(p => p.id === id) || {}).nombre || '—'; }   // plan de alimentación de la reserva (H9)
export function origenCorto(o) { return { directa: 'Directa', web: 'Web', booking: 'Booking', airbnb: 'Airbnb', expedia: 'Expedia', agencia: 'Agencia', empresa: 'Empresa', otro: 'Otro' }[o] || (o || '—'); }
export function nombreMedio(m) { return (MEDIOS.find(x => x[0] === m) || [m, m])[1]; }
// H8: vuelos y traslado de la reserva (datos informativos, sin dinero). vueloTexto: «AV 641 14:30»; vuelosTexto: «Llega AV 641 14:30 · Sale AV 642 09:10»
export const TRASLADOS = [['', 'No necesita'], ['hotel', 'Lo da el hotel'], ['servicio', 'Servicio contratado'], ['propio', 'Por su cuenta']];
export function nombreTraslado(t) { return (TRASLADOS.find(x => x[0] === (t || '')) || [t, t || ''])[1]; }
export function vueloTexto(numero, hora) { return [String(numero || '').trim(), String(hora || '').trim()].filter(Boolean).join(' '); }
export function vuelosTexto(r) { const a = vueloTexto(r.vuelo_llegada, r.hora_vuelo_llegada), b = vueloTexto(r.vuelo_salida, r.hora_vuelo_salida); return [a && 'Llega ' + a, b && 'Sale ' + b].filter(Boolean).join(' · '); }
// 3.60: reportes que entran al paquete PDF del cierre del día (Habitaciones y tarifas elige cuáles; sin lista = todos)
// Cada clave necesita además su línea en cierre.js › secciones(); el servidor imprime como máximo 11 secciones del paquete (main.py, hotel_cierre_paquete)
export const PAQUETE_CIERRE = [['informe_diario', 'Informe diario'], ['mano_corriente', 'Mano corriente'], ['llegadas', 'Llegadas de hoy y de mañana'], ['salidas', 'Salidas de hoy y de mañana'], ['transporte', 'Transporte de hoy y de mañana'], ['en_casa', 'Huéspedes en casa con saldo'], ['caja_recepcion', 'Caja de recepción por medio de pago'], ['habitaciones', 'Habitaciones por estado'], ['no_show', 'No presentados del día'], ['pendientes', 'Pendientes al cerrar'], ['caja_pos', 'Cierre de caja del restaurante']];
export function paqueteCierre(cfg) { const sel = cfg && Array.isArray(cfg.paquete_cierre) ? cfg.paquete_cierre : null; return PAQUETE_CIERRE.map(p => p[0]).filter(k => !sel || sel.includes(k)); }
export function nombreEstadoHab(e) { return (ESTADOS_HAB.find(x => x[0] === e) || [e, 'Limpia'])[1]; }
export function nombreOcasion(o) { return (OCASIONES.find(x => x[0] === o) || ['', ''])[1]; }
export const r2 = n => Math.round((+n || 0) * 100) / 100;
export const r5 = n => Math.round((+n || 0) * 100000) / 100000;   // precio unitario sin IVA con 5 decimales (como lo admite Hacienda): $120 con IVA incluido factura $120,00 y no $119,99 (3.0)

const MENSAJE_BASE = 'Hola {huesped}, le confirmamos su reserva {numero} en {hotel}.\n\nLlegada: {llegada} (desde las {hora_entrada})\nSalida: {salida} (hasta las {hora_salida})\nHabitación: {categoria}\nNoches: {noches} · Personas: {personas}\nTotal: {total}\nAdelanto: {adelanto}\n\n{politicas}\n\n¡Le esperamos!';
export const CONFIG_BASE = {
  activo: false, nombre: '', telefono: '', hora_entrada: '15:00', hora_salida: '12:00', moneda: 'USD', codigo_tarifa: '08', tarifa_iva: 13,
  // multimoneda (2.9): tipo de cambio automático (venta BCCR del día) o manual, y márgenes de protección al recibir la otra moneda
  tc_modo: 'auto', tc_manual: 0, margen_venta: 2, margen_compra: 2,
  precios_incluyen_iva: true, cabys_hospedaje: CABYS_HOSPEDAJE, adelanto_pct: 50, adelanto_plazo_dias: 0, tope_cuenta: 0, correo_cierre: '', bloquear_cerrados: false, finde_dias: [5, 6], finde_pct: 0, ocupacion_reglas: [], larga_reglas: [], minibar_categoria: '', cotizacion_vigencia_dias: 7, prefijo: 'R-', bodega_id: null, persona_extra: 0,   // adelanto_plazo_dias: liberar la reserva pendiente pasados N días (3.21); tope_cuenta: aviso en la caja al cargar a una cuenta que lo supera
  // 3.0: segmentos de mercado, cargos automáticos (desayuno, parqueo, impuesto turístico…), estancia mínima general
  segmentos: SEGMENTOS_BASE.slice(), cargos_auto: [], min_noches: 1,
  politicas: 'Cancelación sin costo hasta 48 horas antes de la llegada. El adelanto no se reembolsa en caso de no presentarse.',
  wifi: '', mensaje_confirmacion: MENSAJE_BASE,
  // mensajes de WhatsApp (3.21): antes de llegar (datos útiles) y al salir (agradecimiento, factura y encuesta)
  mensaje_prellegada: 'Hola {huesped}, ya casi le recibimos en {hotel}. Su reserva {numero} es del {llegada} al {salida}; la entrada es desde las {hora_entrada}.\n\n{wifi}\n\n¿Necesita traslado o alguna indicación para llegar? Escríbanos por aquí.',
  mensaje_salida: 'Hola {huesped}, gracias por hospedarse en {hotel}. Aquí tiene su comprobante: {enlace}\n\n¿Cómo le fue? Nos ayudaría mucho su opinión. ¡Buen viaje!',
  temporadas: [], tarifas: {}, planes: [{ id: 1, nombre: 'Solo habitación', pct: 0 }, { id: 2, nombre: 'Con desayuno', pct: 0 }],
  // tareas automáticas diarias (2.3): el servidor las corre una vez al día (o con «Ejecutar ahora»)
  no_show_auto: true, no_show_dias: 1, salida_tardia_auto: true, recordatorio_adelanto: true, recordatorio_adelanto_dias: 7, recordatorio_llegada: true, recordatorio_llegada_dias: 1, ical_auto: true,
  mensaje_recordatorio_adelanto: 'Hola {huesped}, su reserva {numero} en {hotel} del {llegada} al {salida} está pendiente del adelanto de {adelanto}. Al recibirlo queda confirmada.\n\n{politicas}',
  mensaje_recordatorio_llegada: 'Hola {huesped}, le esperamos en {hotel} el {llegada} (entrada desde las {hora_entrada}). Reserva {numero}, {categoria}, {noches} noche(s).\n\n{wifi}\n\n¡Buen viaje!',
};

// ---- registros ----
export function config() { const c = mock.get('hotel_config', null); return { ...CONFIG_BASE, ...(c && typeof c === 'object' ? c : {}), temporadas: (c && Array.isArray(c.temporadas)) ? c.temporadas : [], tarifas: (c && c.tarifas && typeof c.tarifas === 'object') ? c.tarifas : {}, planes: (c && Array.isArray(c.planes) && c.planes.length) ? c.planes : CONFIG_BASE.planes }; }
export function guardarConfig(c) { return mock.set('hotel_config', { ...c }); }
// 3.62: fecha del hotel (auditoría nocturna). Con cfg.fecha_hotel, la fecha de trabajo de Recepción, Reservaciones, Cierre y
// reportes es la del registro hotel_fecha y solo avanza al cerrar el día (lo de la madrugada sigue perteneciendo al día abierto).
export function fechaHotelActiva() { const c = mock.get('hotel_config', null); return !!(c && c.fecha_hotel); }
export function fechaHotelReg() { const r = mock.get('hotel_fecha', null); return r && typeof r === 'object' && /^\d{4}-\d{2}-\d{2}$/.test(String(r.fecha || '')) ? r : null; }
export function hoyHotel() { if (!fechaHotelActiva()) return hoy(); const r = fechaHotelReg(); return r ? r.fecha : hoy(); }
export function fijarFechaHotel(fecha, motivo) { return mock.set('hotel_fecha', { fecha, cambiada_en: new Date().toISOString(), usuario: usuarioActual(), motivo: motivo || '' }); }
export function hotelActivo() { if (sesion.tipo !== 'hospitalidad') return false; const c = mock.get('hotel_config', null); return !!(c && c.activo); }   // solo en el tipo Hospitalidad (2.5)
export function categorias() { return (mock.get('hotel_categorias', []) || []).slice().sort((a, b) => (+a.orden || 0) - (+b.orden || 0) || String(a.nombre).localeCompare(String(b.nombre))); }
export function habitaciones() { return (mock.get('hotel_habitaciones', []) || []).filter(h => h.activa !== false).slice().sort(ordenHab); }
export function todasHabitaciones() { return (mock.get('hotel_habitaciones', []) || []).slice().sort(ordenHab); }
export function reservas() { return mock.get('hotel_reservas', []) || []; }
export function esEstadia(r) { return r.tipo !== 'bloqueo' && r.tipo !== 'folio'; }   // reservas de verdad: ni bloqueos ni cuentas externas (3.0)
export function huespedes() { return mock.get('hotel_huespedes', []) || []; }
export function folios() { return mock.get('hotel_folios', []) || []; }
export function ordenHab(a, b) { const na = parseInt(a.numero, 10), nb = parseInt(b.numero, 10); if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb; return String(a.numero).localeCompare(String(b.numero), 'es', { numeric: true }); }
export function categoria(id) { return categorias().find(c => c.id === id) || null; }
export function habitacion(id) { return todasHabitaciones().find(h => h.id === id) || null; }
export function huesped(id) { return huespedes().find(h => h.id === id) || null; }
export function reserva(id) { return reservas().find(r => r.id === id) || null; }
export function usuarioActual() { return (sesion.usuario && (sesion.usuario.correo || sesion.usuario.nombre)) || ''; }
export function pisoDe(h) { return String(h.piso || (String(h.numero || '').length >= 3 ? String(h.numero)[0] : '') || '—'); }

// ---- fechas ----
export function noches(llegada, salida) { if (!llegada || !salida) return 0; const a = new Date(llegada + 'T00:00:00'), b = new Date(salida + 'T00:00:00'); return Math.max(0, Math.round((b - a) / 86400000)); }
export function fechasEntre(desde, n) { const out = []; for (let i = 0; i < n; i++) out.push(sumarDias(desde, i)); return out; }
export function domingoAnterior(iso) { const d = new Date((iso || hoy()) + 'T00:00:00'); return sumarDias(iso || hoy(), -d.getDay()); }
export const DIAS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
export const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'set', 'oct', 'nov', 'dic'];
export function etiquetaDia(iso) { const d = new Date(iso + 'T00:00:00'); return { dia: DIAS[d.getDay()], num: d.getDate(), mes: MESES[d.getMonth()], fin: d.getDay() === 0 || d.getDay() === 6 }; }
export function fechaCorta(iso) { if (!iso) return ''; const d = new Date(String(iso).slice(0, 10) + 'T00:00:00'); return d.getDate() + ' ' + MESES[d.getMonth()]; }
export function edad(nacimiento, en) { if (!nacimiento) return null; const n = new Date(nacimiento + 'T00:00:00'), h = new Date((en || hoy()) + 'T00:00:00'); let e = h.getFullYear() - n.getFullYear(); if (h.getMonth() < n.getMonth() || (h.getMonth() === n.getMonth() && h.getDate() < n.getDate())) e--; return e; }
// próximo cumpleaños a partir de `desde` (AAAA-MM-DD) y los días que faltan
export function proximoCumple(nacimiento, desde) { if (!nacimiento || nacimiento.length < 10) return null; const d = desde || hoy(); let c = d.slice(0, 4) + nacimiento.slice(4, 10); if (c < d) c = (+d.slice(0, 4) + 1) + nacimiento.slice(4, 10); return { fecha: c, dias: noches(d, c) }; }

// ---- temporadas y precios ----
export function temporadaDe(fecha, cfg) {
  const c = cfg || config();
  for (const t of c.temporadas || []) for (const r of t.rangos || []) if (r.desde && r.hasta && fecha >= r.desde && fecha <= r.hasta) return t;
  return null;
}
export function diaSemana(iso) { return new Date(String(iso).slice(0, 10) + 'T12:00:00').getDay(); }   // 0 = domingo … 6 = sábado
// Reglas de precio (3.22): recargo por día de la semana (viernes y sábado) y por ocupación del día (p. ej. +15 % con 80 % o más)
export function recargosNoche(fecha, cfg) {
  const c = cfg || config(), notas = []; let pct = 0;
  const dias = Array.isArray(c.finde_dias) ? c.finde_dias.map(Number) : [];
  if (+c.finde_pct && dias.includes(diaSemana(fecha))) { pct += +c.finde_pct; notas.push('fin de semana ' + (+c.finde_pct > 0 ? '+' : '') + +c.finde_pct + ' %'); }
  const reglas = (c.ocupacion_reglas || []).filter(x => +x.pct_desde > 0 && +x.recargo).sort((a, b) => +b.pct_desde - +a.pct_desde);
  if (reglas.length) { const o = ocupacionDia(fecha, reservas(), habitaciones()); const r = reglas.find(x => o.pct >= +x.pct_desde); if (r) { pct += +r.recargo; notas.push('ocupación ' + o.pct + ' % ' + (+r.recargo > 0 ? '+' : '') + +r.recargo + ' %'); } }
  return { pct, notas };
}
export function precioNoche(catId, fecha, cfg) {
  const c = cfg || config(), t = (c.tarifas || {})[String(catId)] || {}, temp = temporadaDe(fecha, c);
  const v = temp && t[String(temp.id)] !== undefined && t[String(temp.id)] !== null && t[String(temp.id)] !== '' ? +t[String(temp.id)] : +t.base;
  const base = isFinite(v) ? v : 0, rec = base ? recargosNoche(fecha, c) : { pct: 0, notas: [] };
  return { precio: rec.pct ? r2(base * (1 + rec.pct / 100)) : base, temporada: temp, base, recargos: rec.notas };
}
// Estancia mínima que aplica a una estadía (3.0): la general del hotel o la mayor de las temporadas que toca
export function estanciaMinima(llegada, salida, cfg) {
  const c = cfg || config(); let mn = Math.max(1, +c.min_noches || 1), temp = null;
  for (const f of fechasEntre(llegada, Math.max(1, noches(llegada, salida)))) { const tp = temporadaDe(f, c); if (tp && +tp.min_noches > mn) { mn = +tp.min_noches; temp = tp; } }
  return { noches: mn, temporada: temp };
}
// ---- capacidad: cada habitación define sus camas, personas y sofá cama (2.4); la categoría solo agrupa y da el precio ----
export function capacidadHab(h) { return h && +h.personas > 0 ? +h.personas : null; }
export function capacidadCat(catId) { const ps = habitaciones().filter(h => h.categoria_id === catId).map(capacidadHab).filter(Boolean); if (ps.length) return Math.max(...ps); const c = categoria(catId); return c && +c.personas > 0 ? +c.personas : 2; }
export function rangoPersonasCat(catId) { const ps = habitaciones().filter(h => h.categoria_id === catId).map(capacidadHab).filter(Boolean); if (!ps.length) { const c = categoria(catId); return c && +c.personas > 0 ? c.personas + ' pers. (defina cada habitación)' : ''; } const a = Math.min(...ps), b = Math.max(...ps); return a === b ? a + ' pers.' : a + ' a ' + b + ' pers.'; }
export function camasTexto(h) { if (!h) return ''; return [h.camas, h.sofa_cama ? 'sofá cama' : ''].filter(Boolean).join(' + '); }
export function descripcionHab(h) { if (!h) return ''; return [capacidadHab(h) ? capacidadHab(h) + ' pers.' : '', camasTexto(h), h.vista].filter(Boolean).join(' · '); }
// ---- agencias y empresas con contrato (3.1) ----
// hotel_agencias: {id, nombre, tipo: 'agencia'|'empresa', cliente_id (contacto al que se factura), modalidad: 'neta' (la agencia paga el hospedaje
// a crédito y el huésped solo los extras) | 'comision' (el huésped paga todo y el hotel le debe la comisión), descuento_pct, comision_pct,
// tarifas {catId: {base, tempId…}} (tarifa negociada; vacío = pública menos descuento), vigencia_desde/hasta, credito, dias_credito, activo}
export const MODALIDADES_AGENCIA = [['neta', 'Tarifa neta: la agencia paga el hospedaje a crédito'], ['comision', 'Comisión: el huésped paga todo y la agencia cobra su comisión']];
export function agencias() { return mock.get('hotel_agencias', []) || []; }
export function agenciaDe(id) { return id ? agencias().find(a => a.id === id) || null : null; }
export function agenciaVigente(a, fecha) { if (!a || a.activo === false) return false; const f = fecha || hoy(); if (a.vigencia_desde && f < a.vigencia_desde) return false; if (a.vigencia_hasta && f > a.vigencia_hasta) return false; return true; }
// Precio por noche con contrato: tarifa negociada de la categoría (por temporada o base) o la pública con el descuento del contrato
export function precioNocheContrato(catId, fecha, a, cfg) {
  const pub = precioNoche(catId, fecha, cfg); if (!a) return pub;
  const tc = (a.tarifas || {})[String(catId)] || {}, temp = pub.temporada, v = temp && tc[String(temp.id)] !== undefined && tc[String(temp.id)] !== '' && tc[String(temp.id)] !== null ? +tc[String(temp.id)] : (tc.base !== undefined && tc.base !== '' && tc.base !== null ? +tc.base : null);
  if (v !== null && isFinite(v) && v > 0) return { precio: v, temporada: temp, contrato: true };
  return { precio: r2(pub.precio * (1 - (+a.descuento_pct || 0) / 100)), temporada: temp, contrato: !!(+a.descuento_pct) };
}
// Cargos que van a la cuenta de la agencia y no a la factura del huésped (modalidad neta): hospedaje y cargos automáticos
export function esCargoAgencia(f, r) { const a = r && r.agencia_id ? agenciaDe(r.agencia_id) : null; return !!(a && a.modalidad === 'neta' && f.tipo === 'cargo' && ['hospedaje', 'auto', 'no_show'].includes(f.origen)); }
export function cargarAgencias() { return agencias(); }
// Cotización de una estadía: precio por noche según temporada, plan (% sobre la tarifa) y personas extra; IVA según la configuración.
export function cotizar({ categoria_id, llegada, salida, plan_id, personas, precio_manual, capacidad, agencia }, cfg) {
  const c = cfg || config(), n = noches(llegada, salida), plan = (c.planes || []).find(p => p.id === plan_id) || null;
  const cap = +capacidad > 0 ? +capacidad : (categoria_id ? capacidadCat(categoria_id) : 0);
  const extra = cap && +personas > cap ? (+personas - cap) * (+c.persona_extra || 0) : 0;
  const detalle = [];
  let subtotal = 0;
  for (let i = 0; i < n; i++) {
    const f = sumarDias(llegada, i);
    const base = precio_manual !== null && precio_manual !== undefined && precio_manual !== '' ? +precio_manual : (() => { const p = agencia ? precioNocheContrato(categoria_id, f, agencia, c) : precioNoche(categoria_id, f, c); return r2(p.precio * (1 + (plan ? +plan.pct || 0 : 0) / 100) + extra); })();
    const temp = temporadaDe(f, c);
    detalle.push({ fecha: f, precio: r2(base), temporada: temp ? temp.nombre : '' });
    subtotal += base;
  }
  // larga estadía (3.22): descuento por noches (p. ej. 7 noches o más −10 %); no aplica con precio negociado
  const larga = precio_manual === null || precio_manual === undefined || precio_manual === '' ? ((c.larga_reglas || []).filter(x => +x.noches > 0 && +x.descuento > 0 && n >= +x.noches).sort((a, b) => +b.noches - +a.noches)[0] || null) : null;
  if (larga) { for (const d of detalle) d.precio = r2(d.precio * (1 - +larga.descuento / 100)); subtotal = detalle.reduce((s, d) => s + d.precio, 0); }
  const t = +c.tarifa_iva || 0;
  const total = r2(subtotal), neto = c.precios_incluyen_iva ? r2(total / (1 + t / 100)) : total, iva = c.precios_incluyen_iva ? r2(total - neto) : r2(total * t / 100);
  return { noches: n, detalle, neto, iva, total: c.precios_incluyen_iva ? total : r2(total + iva), promedio: n ? r2(total / n) : 0, moneda: c.moneda || 'USD', extra_personas: extra, plan, larga: larga ? { noches: +larga.noches, descuento: +larga.descuento } : null };
}

// ---- ocupación y disponibilidad ----
export function ocupa(r) { return r.tipo === 'bloqueo' || ['pendiente', 'confirmada', 'en_casa'].includes(r.estado); }
export function cruza(a, b) { return !!a.habitacion_id && a.habitacion_id === b.habitacion_id && a.llegada < b.salida && b.llegada < a.salida; }
// Habitaciones libres (activas) para esas fechas; con categoría, solo las de esa categoría. `excluir`: id de la reserva que se edita.
export function disponibles(categoria_id, llegada, salida, excluir, lista) {
  const rs = (lista || reservas()).filter(r => r.id !== excluir && ocupa(r));
  return habitaciones().filter(h => (!categoria_id || h.categoria_id === categoria_id) && !rs.some(r => cruza(r, { habitacion_id: h.id, llegada, salida })));
}
// Reserva o bloqueo que ocupa la habitación en esa noche
export function ocupanteEn(habId, fecha, lista) { return (lista || reservas()).find(r => r.habitacion_id === habId && (ocupa(r) || r.estado === 'salio') && r.llegada <= fecha && fecha < r.salida) || null; }
// Ocupación de un día: habitaciones ocupadas (sin bloqueos) sobre las activas
export function ocupacionDia(fecha, lista, habs) {
  const rs = lista || reservas(), hs = habs || habitaciones();
  const ocupadas = new Set(rs.filter(r => r.tipo !== 'bloqueo' && (ocupa(r) || r.estado === 'salio') && r.llegada <= fecha && fecha < r.salida && r.habitacion_id).map(r => r.habitacion_id));
  const bloqueadas = new Set(rs.filter(r => r.tipo === 'bloqueo' && r.llegada <= fecha && fecha < r.salida && r.habitacion_id).map(r => r.habitacion_id));
  const n = hs.length, oc = hs.filter(h => ocupadas.has(h.id)).length, bl = hs.filter(h => bloqueadas.has(h.id) && !ocupadas.has(h.id)).length;
  return { total: n, ocupadas: oc, bloqueadas: bl, libres: n - oc - bl, pct: n ? Math.round(oc / n * 100) : 0 };
}
// Disponibilidad de una noche por tipo de habitación (H3). Es la única cuenta de «libres por categoría»: la usan el pronóstico por
// tipo y, después, el calendario, las alertas y la ficha de reserva. Regla común (la misma que debe seguir el servidor):
//  - solo cuentan las habitaciones activas;
//  - una reserva CON habitación cuenta en la categoría de esa habitación (un cambio a categoría superior cuenta donde duerme el huésped);
//  - una reserva SIN habitación («asignar al llegar») cuenta en r.categoria_id, como sin_asignar;
//  - los bloqueos cuentan aparte; el estado «mantenimiento» de la habitación solo el día de hoy (es un estado actual, sin fechas).
// opts: { modo: 'proyectado' (pendientes, confirmadas, en casa y las que ya salieron) | 'real' (solo en casa o salió, y solo hasta hoy),
//         habs, cfg, excluir (id de la reserva que se está editando) }.
// Devuelve { porCat: { catId: { total, ocupadas, bloqueadas, sin_asignar, retenido, libres, pct, tarifa_prom, n_tarifa } }, total, ocupadas,
// bloqueadas, sin_asignar, libres, pct }. libres puede ser negativo (sobreventa). retenido queda en 0 (lo llenan los cupos de agencias).
// porCat[0] junta lo que no tiene categoría. tarifa_prom: promedio de tarifa_noche en la moneda del hotel; null si ninguna trae tarifa.
export function disponibilidadPorTipo(fecha, lista, opts = {}) {
  const c = opts.cfg || config(), real = opts.modo === 'real';
  const hs = (opts.habs || habitaciones()).filter(h => h.activa !== false);
  const cuenta = real ? (fecha <= hoyHotel() ? r => ['en_casa', 'salio'].includes(r.estado) : () => false) : r => ocupa(r) || r.estado === 'salio';
  const porCat = {}, ent = k => porCat[k || 0] || (porCat[k || 0] = { total: 0, ocupadas: 0, bloqueadas: 0, sin_asignar: 0, retenido: 0, libres: 0, pct: 0, tarifa_prom: null, n_tarifa: 0, suma: 0 });
  const catDe = new Map();
  for (const h of hs) { catDe.set(h.id, h.categoria_id || 0); ent(h.categoria_id).total++; }
  const ocupadas = new Set(), bloqueadas = new Set();
  for (const r of lista || reservas()) {
    if (r.tipo === 'folio' || !(r.llegada <= fecha && fecha < r.salida) || (opts.excluir && r.id === opts.excluir)) continue;
    if (r.tipo === 'bloqueo') { if (catDe.has(r.habitacion_id)) bloqueadas.add(r.habitacion_id); continue; }
    if (!cuenta(r)) continue;
    let e;
    if (r.habitacion_id) {
      if (!catDe.has(r.habitacion_id) || ocupadas.has(r.habitacion_id)) continue;   // habitación inactiva, o ya contada esa noche
      ocupadas.add(r.habitacion_id); e = ent(catDe.get(r.habitacion_id)); e.ocupadas++;
    } else { e = ent(r.categoria_id); e.sin_asignar++; }   // sin habitación: resta en la categoría que pidió
    if (+r.tarifa_noche > 0) { e.suma += convertirMonto(+r.tarifa_noche, r.moneda || c.moneda, c.moneda, c); e.n_tarifa++; }
  }
  if (fecha === hoyHotel()) for (const h of hs) if (h.estado === 'mantenimiento') bloqueadas.add(h.id);
  for (const id of bloqueadas) if (!ocupadas.has(id)) ent(catDe.get(id)).bloqueadas++;
  const t = { porCat, total: 0, ocupadas: 0, bloqueadas: 0, sin_asignar: 0, libres: 0, pct: 0 };
  for (const e of Object.values(porCat)) {
    e.libres = e.total - e.ocupadas - e.bloqueadas - e.sin_asignar;
    e.pct = e.total ? Math.round((e.ocupadas + e.sin_asignar) / e.total * 100) : 0;
    e.tarifa_prom = e.n_tarifa ? r2(e.suma / e.n_tarifa) : null; delete e.suma;
    t.total += e.total; t.ocupadas += e.ocupadas; t.bloqueadas += e.bloqueadas; t.sin_asignar += e.sin_asignar; t.libres += e.libres;
  }
  t.pct = t.total ? Math.round((t.ocupadas + t.sin_asignar) / t.total * 100) : 0;
  return t;
}

// ---- huéspedes ----
export function nombreHuesped(h) { if (!h) return '—'; return [h.nombre, h.apellidos].filter(Boolean).join(' ').trim() || h.documento || '—'; }
// Estadías de un huésped (llegó o ya salió), la más reciente primero
export function estadiasDe(huespedId, lista) { return (lista || reservas()).filter(r => r.tipo !== 'bloqueo' && r.huesped_id === huespedId && ['en_casa', 'salio'].includes(r.estado)).sort((a, b) => String(b.llegada).localeCompare(String(a.llegada))); }
// Número de visita de una reserva: cuántas estadías (incluida esta, si ya llegó) tiene el huésped hasta esa llegada
export function numeroVisita(r, lista) {
  if (!r || !r.huesped_id) return 1;
  const previas = (lista || reservas()).filter(x => x.tipo !== 'bloqueo' && x.huesped_id === r.huesped_id && x.id !== r.id && ['en_casa', 'salio'].includes(x.estado) && x.llegada <= r.llegada).length;
  return previas + 1;
}
export function insignia(n) { return n >= 5 ? '×5+' : n >= 2 ? '×' + n : ''; }
export function textoVisita(n) { return n >= 5 ? 'Quinta visita o más' : n === 4 ? 'Cuarta visita' : n === 3 ? 'Tercera visita' : n === 2 ? 'Segunda visita' : 'Primera visita'; }
export function huespedNuevo() { return { id: null, nombre: '', apellidos: '', tipo_doc: 'cedula', documento: '', nacionalidad: 'Costa Rica', nacimiento: '', telefono: '', correo: '', pais: 'Costa Rica', ciudad: '', vip: false, preferencias: '', notas: '', no_marketing: false, cliente_id: null, creado: new Date().toISOString() }; }
export function guardarHuesped(h) {
  let guardado = null;
  mock.actualizar('hotel_huespedes', l => { const lista = Array.isArray(l) ? l : []; const reg = { ...h, id: h.id || mock.nextId(lista, 'hotel_huespedes'), actualizado: new Date().toISOString() }; const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); guardado = reg; return lista; }, []);
  return guardado;
}
export function buscarHuespedes(q, lista) { const s = String(q || '').trim().toLowerCase(); if (!s) return []; return (lista || huespedes()).filter(h => nombreHuesped(h).toLowerCase().includes(s) || String(h.documento || '').toLowerCase().includes(s) || String(h.telefono || '').includes(s) || String(h.correo || '').toLowerCase().includes(s)).slice(0, 8); }
// Total gastado por el huésped (cargos de sus estadías, en la moneda del hotel)
export function gastoHuesped(huespedId) { const ids = new Set(estadiasDe(huespedId).map(r => r.id)); return r2(folios().filter(f => f.tipo === 'cargo' && ids.has(f.reserva_id)).reduce((s, f) => s + totalCargo(f), 0)); }

// ---- reservas ----
export function nuevoNumero(cfg) { const c = cfg || config(); const n = siguienteNumero(reservas(), 'numero', c.prefijo || 'R-', 1); return (c.prefijo || 'R-') + String(n).padStart(4, '0'); }
export function reservaNueva(cfg) {
  const c = cfg || config();
  return { id: null, tipo: 'reserva', numero: '', estado: 'pendiente', huesped_id: null, huesped_nombre: '', adultos: 2, ninos: 0, llegada: hoyHotel(), salida: sumarDias(hoyHotel(), 1), categoria_id: null, habitacion_id: null, plan_id: (c.planes[0] || {}).id || 1,
    precio_manual: null, tarifa_noche: 0, noches: 1, neto: 0, iva: 0, total: 0, moneda: c.moneda || 'USD', origen: 'directa', segmento: '', agencia_id: null, referencia: '', ocasion: '', especiales: '', notas: '', vehiculo: '', acompanantes: '', cliente_id: null, grupo: '',
    vuelo_llegada: '', hora_vuelo_llegada: '', vuelo_salida: '', hora_vuelo_salida: '', traslado: '', traslado_nota: '',   // H8: vuelos y traslado
    adelanto_requerido: 0, creado: new Date().toISOString(), usuario: usuarioActual(), checkin: null, checkout: null, documento_id: null, consecutivo: null, historial: [] };
}
// Guarda (alta o cambio) y devuelve {reg, promesa}. La promesa resuelve true cuando el servidor la aceptó; si la rechazó (por
// ejemplo, otra recepción tomó la misma habitación esas noches: 409), el aviso ya se mostró y aquí se deshace el cambio local.
export function guardarReserva(r) {
  const lista = reservas(), anterior = r.id ? lista.find(x => x.id === r.id) || null : null;
  const reg = { ...r, id: r.id || mock.nextId(lista, 'hotel_reservas'), actualizado: new Date().toISOString() };
  const nueva = anterior ? lista.map(x => (x.id === reg.id ? reg : x)) : [...lista, reg];
  const promesa = mock.set('hotel_reservas', nueva).then(ok => {
    if (!ok) { const l = reservas(); mock.set('hotel_reservas', anterior ? l.map(x => (x.id === reg.id ? anterior : x)) : l.filter(x => x.id !== reg.id)); }
    return ok;
  });
  return { reg, promesa };
}
export function cambiarReserva(id, fn) { const actual = reserva(id); if (!actual) return { reg: null, promesa: Promise.resolve(false) }; const n = { ...actual }; const r = fn(n); return guardarReserva(r || n); }
export function anotar(r, texto) { return { ...r, historial: [...(r.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto }].slice(-60) }; }
export function etiquetaReserva(r) { const h = r.habitacion_id ? habitacion(r.habitacion_id) : null; return (r.numero || '') + ' · ' + (r.huesped_nombre || 'Sin huésped') + (h ? ' · Hab. ' + h.numero : ''); }
export function nombreHab(id) { const h = id ? habitacion(id) : null; return h ? h.numero : '—'; }
export function nombreCat(id) { const c = id ? categoria(id) : null; return c ? c.nombre : '—'; }
// Clase de color de una barra o ficha según el estado y el día de hoy
export function claseEstado(r, hoyS) {
  const h = hoyS || hoyHotel();
  if (r.tipo === 'bloqueo') return 'bloq';
  if (r.estado === 'en_casa') return r.salida <= h ? 'sale' : 'casa';
  if (r.estado === 'confirmada' || r.estado === 'pendiente') return r.llegada === h ? 'llega' : (r.estado === 'pendiente' ? 'pend' : 'conf');
  return CLASE_ESTADO[r.estado] || 'pasada';
}
// H15: marcas que una barra del calendario lleva además del color de su estado. dep: la cuenta de la reserva ya tiene un pago o un
// adelanto (pagosMap = pagosPorReserva(), que se arma una sola vez por pantalla); pre: habitación preasignada desde el calendario,
// mientras la reserva no haga el check-in. hoyS queda para la marca «check-in en proceso», que se pospuso.
export function marcasReserva(r, pagosMap, hoyS) {
  const estadia = !!r && esEstadia(r);
  return { dep: estadia && (+((pagosMap || {})[r.id]) || 0) > 0.005, pre: estadia && !!r.preasignada && !!r.habitacion_id && ['pendiente', 'confirmada'].includes(r.estado) };
}
// Lo pagado en cada cuenta, {reserva_id: monto}. Quien no recibe montos (hotel_folios llega vacío) ve todo «sin depósito».
export function pagosPorReserva() { const m = {}; for (const f of folios()) if (f.tipo === 'pago') m[f.reserva_id] = r2((m[f.reserva_id] || 0) + (+f.monto || 0)); return m; }
// Reservas vigentes sin habitación («asignar al llegar») con alguna noche entre `desde` y `hasta`, los dos días incluidos (sin fechas, todas)
export function reservasSinHabitacion(desde, hasta, lista) {
  return (lista || reservas()).filter(r => esEstadia(r) && ocupa(r) && !r.habitacion_id && (!hasta || r.llegada <= hasta) && (!desde || r.salida > desde))
    .sort((a, b) => String(a.llegada).localeCompare(String(b.llegada)) || String(a.numero).localeCompare(String(b.numero)));
}

// ---- bloqueos de habitaciones en lote (H6) ----
// Un bloqueo es un registro de hotel_reservas con tipo 'bloqueo'. Los que se crean juntos comparten `lote` (un uuid; sin lote = bloqueo
// suelto) y llevan motivo_tipo además del texto. Siguen sin origen 'ical': así el Técnico de mantenimiento los crea y los quita.
export const MOTIVOS_BLOQUEO = [['mantenimiento', 'Mantenimiento'], ['remodelacion', 'Remodelación'], ['uso_interno', 'Uso interno'], ['otro', 'Otro']];
export function nombreMotivoBloqueo(t) { return (MOTIVOS_BLOQUEO.find(x => x[0] === t) || ['', ''])[1]; }
export function bloqueosDeLote(lote, lista) { return lote ? (lista || reservas()).filter(r => r.tipo === 'bloqueo' && r.lote === lote) : []; }
// Crea un bloqueo por habitación en UN solo guardado (un POST /cambios): el servidor revisa todas las altas juntas y, si una habitación
// ya se ocupó esas noches, rechaza el lote completo. Devuelve {regs, promesa}; si la promesa da false se quitan todas las altas locales.
export function crearBloqueos(habIds, desde, hasta, motivo, motivo_tipo) {
  const ids = [...new Set((habIds || []).filter(Boolean))];
  if (!ids.length || !desde || !hasta || hasta <= desde) return { regs: [], promesa: Promise.resolve(false) };
  const acumulada = reservas(), regs = [], ahora = new Date().toISOString();
  const lote = globalThis.crypto && crypto.randomUUID ? crypto.randomUUID() : 'lote-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  const texto = String(motivo || '').trim() || nombreMotivoBloqueo(motivo_tipo) || 'Bloqueo';
  for (const habitacion_id of ids) {
    const reg = { id: mock.nextId(acumulada, 'hotel_reservas'), tipo: 'bloqueo', estado: 'bloqueo', habitacion_id, llegada: desde, salida: hasta, motivo: texto, motivo_tipo: motivo_tipo || '', lote, numero: 'BLQ', huesped_nombre: '', creado: ahora, usuario: usuarioActual(), actualizado: ahora };
    regs.push(reg); acumulada.push(reg);   // el id siguiente sale de la lista acumulada: ids en secuencia
  }
  const promesa = mock.set('hotel_reservas', acumulada).then(ok => {
    if (!ok) { const altas = new Set(regs.map(x => x.id)); mock.set('hotel_reservas', reservas().filter(x => !altas.has(x.id))); }
    return ok;
  });
  return { regs, promesa };
}
// Quita los bloqueos con esos ids (nunca una reserva) en un solo guardado. Devuelve la promesa; si da false, vuelven a la copia local.
export function quitarBloqueos(ids) {
  const pedidos = new Set(ids || []), quitados = reservas().filter(x => x.tipo === 'bloqueo' && pedidos.has(x.id));
  if (!quitados.length) return Promise.resolve(false);
  const fuera = new Set(quitados.map(x => x.id));
  return mock.set('hotel_reservas', reservas().filter(x => !fuera.has(x.id))).then(ok => {
    if (!ok) { const l = reservas(), estan = new Set(l.map(x => x.id)), faltan = quitados.filter(x => !estan.has(x.id)); if (faltan.length) mock.set('hotel_reservas', [...l, ...faltan]); }
    return ok;
  });
}

// ---- cuenta del huésped (folio) ----
export function folioDe(reservaId) { return folios().filter(f => f.reserva_id === reservaId).sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)) || (a.id - b.id)); }
// 3.41: un cargo puede llevar Selectivo de Consumo o impuesto específico (licores del minibar, por ejemplo): se suma como en la factura
function oiCargo(f, base) { return otroImpLinea(f.otro_impuesto, f.cantidad, base, f.moneda && f.moneda !== 'CRC' ? (+monedas.tc(f.moneda) || 1) : 1); }
export function totalCargo(f) { const base = (+f.cantidad || 0) * (+f.precio || 0), oi = oiCargo(f, base); return r2(base + oi.monto + (base + oi.base) * (+f.tarifa || 0) / 100); }
// Las dos partes de totalCargo, sin redondear: lo que no es IVA (con el otro impuesto de la línea) y el IVA, que también grava ese otro impuesto
export function netoIvaCargo(f) { const base = (+f.cantidad || 0) * (+f.precio || 0), oi = oiCargo(f, base); return { neto: base + oi.monto, iva: (base + oi.base) * (+f.tarifa || 0) / 100 }; }
export function totalesFolio(items) {
  let neto = 0, iva = 0, otros = 0, pagos = 0;
  for (const f of items) { if (f.tipo === 'pago') { pagos += +f.monto || 0; continue; } const base = (+f.cantidad || 0) * (+f.precio || 0), oi = oiCargo(f, base); neto += base; otros += oi.monto; iva += (base + oi.base) * (+f.tarifa || 0) / 100; }
  const cargos = r2(neto + iva + otros);
  return { neto: r2(neto), iva: r2(iva), otros: r2(otros), cargos, pagos: r2(pagos), saldo: r2(cargos - pagos) };
}
export function agregarFolio(item) {
  let guardado = null;
  mock.actualizar('hotel_folios', l => { const lista = Array.isArray(l) ? l : []; guardado = { ...item, id: mock.nextId(lista, 'hotel_folios'), creado: new Date().toISOString(), usuario: usuarioActual() }; return [...lista, guardado]; }, []);
  return guardado;
}
export function quitarFolio(id) { mock.actualizar('hotel_folios', l => (l || []).filter(x => x.id !== id), []); }
export function cambiarFolio(id, cambios) { mock.actualizar('hotel_folios', l => (l || []).map(x => (x.id === id ? { ...x, ...cambios } : x)), []); }
// Cargo de hospedaje de una noche (precio sin IVA según la configuración)
export function cargoHospedaje(r, fecha, cfg) {
  const c = cfg || config(), t = +c.tarifa_iva || 0, bruto = +r.tarifa_noche || 0;
  const precio = c.precios_incluyen_iva ? r5(bruto / (1 + t / 100)) : bruto;
  // (3.22) si el hospedaje va a otra cuenta (la empresa paga la habitación y el huésped los extras), la noche se carga ahí
  return { reserva_id: r.cuenta_hospedaje_id || r.id, reserva_origen_id: r.cuenta_hospedaje_id ? r.id : undefined, tipo: 'cargo', origen: 'hospedaje', fecha, detalle: 'Hospedaje hab. ' + nombreHab(r.habitacion_id) + ' · noche del ' + fechaCorta(fecha) + (r.cuenta_hospedaje_id ? ' · ' + (r.huesped_nombre || '') : ''), cantidad: 1, precio, tarifa: t, codigo_tarifa: c.codigo_tarifa || '08', cabys: c.cabys_hospedaje || CABYS_HOSPEDAJE, moneda: r.moneda, producto_id: null };
}
// Deja un cargo de hospedaje por cada noche de la estadía (al llegar, al extender o acortar, al cambiar de habitación)
export function sincronizarHospedaje(r, cfg) {
  const c = cfg || config(), todos = folios().filter(f => f.tipo === 'cargo' && f.origen === 'hospedaje' && (f.reserva_id === r.id || (r.cuenta_hospedaje_id && f.reserva_id === r.cuenta_hospedaje_id && f.reserva_origen_id === r.id))).sort((a, b) => String(a.fecha).localeCompare(String(b.fecha))), actuales = todos.filter(f => !f.documento_id), fechas = new Set(fechasEntre(r.llegada, noches(r.llegada, r.salida)));
  for (const f of actuales) if (!fechas.has(f.fecha)) quitarFolio(f.id);
  for (const fch of fechas) { const ya = todos.find(f => f.fecha === fch); if (!ya) agregarFolio(cargoHospedaje(r, fch, c)); else if (!ya.documento_id && ya.detalle.indexOf('hab. ' + nombreHab(r.habitacion_id)) < 0) cambiarFolio(ya.id, { detalle: cargoHospedaje(r, fch, c).detalle }); }
  sincronizarCargosAuto(r, c);
}
// ---- cargos automáticos (3.0): desayuno, parqueo, impuesto turístico… por noche, por persona y noche o una vez por estadía, según el plan ----
export function cargosAutoDe(r, cfg) { const c = cfg || config(); return (c.cargos_auto || []).filter(a => a.activo !== false && +a.precio > 0 && (!a.plan_id || a.plan_id === r.plan_id)); }
function cargoAuto(r, a, fecha, c) {
  const t = a.codigo_tarifa ? (CAT_TARIFA[a.codigo_tarifa] ?? (+c.tarifa_iva || 0)) : (+c.tarifa_iva || 0), personas = (+r.adultos || 0) + (+r.ninos || 0);
  const cant = a.tipo === 'persona_noche' ? Math.max(1, personas) : 1, bruto = +a.precio || 0, precio = c.precios_incluyen_iva ? r5(bruto / (1 + t / 100)) : bruto;
  return { reserva_id: r.id, tipo: 'cargo', origen: 'auto', auto_id: a.id, fecha, detalle: a.nombre + (a.tipo === 'estadia' ? '' : ' · ' + fechaCorta(fecha)) + (a.tipo === 'persona_noche' ? ' · ' + cant + ' pers.' : ''), cantidad: cant, precio, tarifa: t, codigo_tarifa: a.codigo_tarifa || c.codigo_tarifa || '08', cabys: /^\d{13}$/.test(String(a.cabys || '')) ? a.cabys : (c.cabys_hospedaje || CABYS_HOSPEDAJE), moneda: r.moneda, producto_id: null };
}
const CAT_TARIFA = { '01': 0, '02': 1, '03': 2, '04': 4, '05': 0, '06': 4, '07': 8, '08': 13, '09': 0.5, '10': 1, '11': 0 };
export function sincronizarCargosAuto(r, cfg) {
  const c = cfg || config(), actuales = folioDe(r.id).filter(f => f.tipo === 'cargo' && f.origen === 'auto' && !f.documento_id), reglas = cargosAutoDe(r, c);
  const fechas = fechasEntre(r.llegada, noches(r.llegada, r.salida)), deseados = [];
  for (const a of reglas) { if (a.tipo === 'estadia') deseados.push({ a, fecha: r.llegada }); else for (const f of fechas) deseados.push({ a, fecha: f }); }
  for (const f of actuales) if (!deseados.some(d => d.a.id === f.auto_id && d.fecha === f.fecha)) quitarFolio(f.id);
  for (const d of deseados) if (!actuales.some(f => f.auto_id === d.a.id && f.fecha === d.fecha)) agregarFolio(cargoAuto(r, d.a, d.fecha, c));
}
// Traslado de un cargo a la cuenta de otra reserva (3.0): el cargo cambia de cuenta y deja rastro de dónde venía
export function trasladarCargo(f, origen, destino) {
  cambiarFolio(f.id, { reserva_id: destino.id, traslado_de: origen.id, detalle: String(f.detalle || '') + ' (de ' + (origen.numero || '') + (origen.habitacion_id ? ' hab. ' + nombreHab(origen.habitacion_id) : '') + ')' });
}
// Pago o adelanto en la cuenta del huésped: queda en el folio y, si se indicó cuenta, entra a Bancos (ref hotel:pago:<id>).
// Al hacer el check-out, estos pagos se aplican a la factura con un recibo sin cuenta (el dinero ya entró al banco).
export async function registrarPago(r, p) {
  // pago en la otra moneda (2.9): p.moneda_pago y p.monto_pago; en la cuenta queda el monto convertido con el margen del hotel
  const mp = p.moneda_pago && p.moneda_pago !== r.moneda ? p.moneda_pago : r.moneda, tc = mp !== r.moneda ? (+p.tipo_cambio || tcPago(mp, r.moneda)) : null;
  const montoPago = mp !== r.moneda ? r2(p.monto_pago) : r2(p.monto), monto = tc ? (r.moneda === 'USD' ? r2(montoPago / tc) : r2(montoPago * tc)) : r2(p.monto);
  const detalle = (p.detalle || ('Pago ' + nombreMedio(p.medio))) + (tc ? ' · ' + money(montoPago, mp) + ' al tipo de cambio ' + fmt(tc, 2) : '');
  const item = agregarFolio({ reserva_id: r.id, tipo: 'pago', fecha: p.fecha || hoyHotel(), detalle, medio: p.medio || '01', cuenta: p.cuenta || '', monto, moneda: r.moneda, moneda_pago: mp, monto_pago: montoPago, tipo_cambio: tc, referencia: p.referencia || '' });
  if (p.cuenta) {
    // a Bancos va lo que realmente entró, en la moneda en que se pagó; si la cuenta bancaria está en otra moneda, el servidor convierte con este tipo de cambio
    try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: p.cuenta, monto: montoPago, fecha: item.fecha, descripcion: (p.detalle || 'Pago') + ' · ' + (r.numero || '') + (r.huesped_nombre ? ' · ' + r.huesped_nombre : ''), ref: 'hotel:pago:' + item.id, moneda: mp, tipo_cambio: tc || monedas.tc(mp) } }); item.en_banco = true; cambiarFolio(item.id, { en_banco: true }); }
    catch (e) { toast('El pago quedó en la cuenta del huésped, pero no entró a Bancos: ' + e.message, 'err'); }
  }
  return item;
}
export async function anularPago(item) {
  quitarFolio(item.id);
  if (item.deposito_id) cambiarDeposito(item.deposito_id, x => ({ ...x, aplicaciones: (x.aplicaciones || []).filter(a => a.folio_id !== item.id), historial: [...(x.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto: 'Aplicación anulada: ' + money(item.monto_deposito || item.monto, x.moneda) + ' vuelve a estar disponible' }] }));
  if (item.en_banco) { try { await api('/api/bancos/movimientos?ref=' + encodeURIComponent('hotel:pago:' + item.id), { method: 'DELETE' }); } catch (e) { toast('No se pudo quitar el movimiento de Bancos: ' + e.message, 'err'); } }
}
// ---- multimoneda (2.9): colones y dólares en todo el hotel ----
// La cuenta del huésped está en la moneda del hotel (por defecto dólares). Un pago en la otra moneda se convierte con el tipo de cambio
// base (venta BCCR del día o el manual) más un margen de protección: si la cuenta es en dólares y pagan en colones, el hotel «vende»
// dólares más caro (tc × (1 + margen_venta)); si la cuenta es en colones y pagan en dólares, los «compra» más barato (tc × (1 − margen_compra)).
export const MONEDAS_HOTEL = [['USD', 'Dólares'], ['CRC', 'Colones']];
export function otraMoneda(m) { return m === 'CRC' ? 'USD' : 'CRC'; }
// (3.20) un solo tipo de cambio en toda la empresa: el de Configuración › Monedas (venta BCCR del día o el manual de la empresa);
// el hotel ya no lleva el suyo aparte (antes la cuenta del huésped y Bancos convertían con valores distintos). Los márgenes se aplican encima.
export function tcBaseHotel(cfg) { const c = cfg || config(); return +monedas.tc('USD') || +c.tc_manual || 0; }
export function tcVentaHotel(cfg) { const c = cfg || config(); return r2(tcBaseHotel(c) * (1 + (+c.margen_venta || 0) / 100)); }
export function tcCompraHotel(cfg) { const c = cfg || config(); return r2(tcBaseHotel(c) * (1 - (+c.margen_compra || 0) / 100)); }
// Tipo de cambio (colones por dólar) que aplica a un pago hecho en `de` sobre una cuenta en `a`; null si es la misma moneda
export function tcPago(de, a, cfg) { if (!de || !a || de === a) return null; return a === 'USD' ? tcVentaHotel(cfg) : tcCompraHotel(cfg); }
// Monto pagado en `de` expresado en la moneda `a` de la cuenta
export function convertirPago(monto, de, a, cfg) { const tc = tcPago(de, a, cfg); if (!tc) return r2(monto); return a === 'USD' ? r2((+monto || 0) / tc) : r2((+monto || 0) * tc); }
// Equivalente informativo en la otra moneda al tipo de cambio base (sin margen): «≈ ₡62.000»
export function equivalente(monto, moneda, cfg) { const tc = tcBaseHotel(cfg); if (!tc || !(+monto)) return ''; const o = otraMoneda(moneda || 'USD'); return '≈ ' + money(o === 'USD' ? r2(monto / tc) : r2(monto * tc), o); }
// Texto del cambio aplicado a un pago: «₡62.000 al tipo de cambio 516,00 = $120,16»
export function textoCambio(montoPago, de, a, cfg) { const tc = tcPago(de, a, cfg); if (!tc) return ''; return money(montoPago, de) + ' al tipo de cambio ' + fmt(tc, 2) + ' = ' + money(convertirPago(montoPago, de, a, cfg), a); }
// Tipo de cambio para pasar colones a la moneda de la cuenta (y viceversa): cargos del restaurante, sin margen
export function aMonedaFolio(montoCRC, moneda) { if (!moneda || moneda === 'CRC') return r2(montoCRC); const tc = tcBaseHotel() || monedas.tc(moneda) || 1; return r2(montoCRC / tc); }
export function convertirMonto(monto, de, a, cfg) { if (!de || !a || de === a) return r2(monto); const tc = tcBaseHotel(cfg) || 1; return a === 'USD' ? r2((+monto || 0) / tc) : r2((+monto || 0) * tc); }   // al tipo de cambio base del hotel (sin margen): cargos y reportes
export function textoMonto(v, moneda) { return money(v || 0, moneda || config().moneda || 'USD'); }

// ---- depósitos en garantía (3.0): dinero recibido antes de la estadía que se aplica a una o varias reservas, se devuelve o se traspasa ----
export const ESTADOS_DEPOSITO = { disponible: 'Disponible', parcial: 'Parcialmente usado', aplicado: 'Aplicado', devuelto: 'Devuelto' };
export function depositos() { return mock.get('hotel_depositos', []) || []; }
export function depositoDisponible(d) { return r2((+d.monto || 0) - (d.aplicaciones || []).reduce((s, a) => s + (+a.monto || 0), 0) - (d.devoluciones || []).reduce((s, a) => s + (+a.monto || 0), 0)); }
export function estadoDeposito(d) { const disp = depositoDisponible(d), ap = (d.aplicaciones || []).length, dv = (d.devoluciones || []).length; if (disp > 0.005) return ap || dv ? 'parcial' : 'disponible'; return dv && !ap ? 'devuelto' : 'aplicado'; }
// Depósitos con saldo que podrían aplicarse a una reserva: del mismo huésped, del mismo contacto o del mismo grupo
export function depositosPara(r) { return depositos().filter(d => depositoDisponible(d) > 0.005 && ((r.huesped_id && d.huesped_id === r.huesped_id) || (r.cliente_id && d.cliente_id && d.cliente_id === r.cliente_id) || (r.grupo && d.grupo && d.grupo === r.grupo))); }
export function cambiarDeposito(id, fn) { let out = null; mock.actualizar('hotel_depositos', l => (l || []).map(x => { if (x.id !== id) return x; const n = { ...x }; out = fn(n) || n; return out; }), []); return out; }
export async function crearDeposito(d) {
  const lista = depositos(), n = siguienteNumero(lista, 'numero', 'DG-', 1), ahora = new Date().toISOString();
  const reg = { ...d, id: mock.nextId(lista, 'hotel_depositos'), numero: 'DG-' + String(n).padStart(4, '0'), monto: r2(d.monto), fecha: d.fecha || hoyHotel(), aplicaciones: [], devoluciones: [], creado: ahora, usuario: usuarioActual(), historial: [{ fecha: ahora, usuario: usuarioActual(), texto: 'Depósito recibido: ' + money(d.monto, d.moneda) + ' ' + nombreMedio(d.medio) + (d.referencia ? ' · ' + d.referencia : '') }] };
  mock.set('hotel_depositos', [...lista, reg]);
  if (d.cuenta) {
    try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: d.cuenta, monto: reg.monto, fecha: reg.fecha, descripcion: 'Depósito en garantía ' + reg.numero + ' · ' + (reg.nombre || ''), ref: 'hotel:deposito:' + reg.id, moneda: reg.moneda, tipo_cambio: monedas.tc(reg.moneda) } }); cambiarDeposito(reg.id, x => ({ ...x, en_banco: true })); }
    catch (e) { toast('El depósito quedó registrado, pero no entró a Bancos: ' + e.message, 'err'); }
  }
  return reg;
}
// Aplica parte del depósito a la cuenta de una reserva: queda como pago de la cuenta (el dinero ya entró con el depósito) y se descuenta del depósito
export function aplicarDeposito(d, r, monto) {
  const m = r2(Math.min(+monto || 0, depositoDisponible(d))); if (m <= 0) return null;
  const montoCuenta = d.moneda === r.moneda ? m : convertirPago(m, d.moneda, r.moneda);
  const item = agregarFolio({ reserva_id: r.id, tipo: 'pago', fecha: hoyHotel(), detalle: 'Depósito en garantía ' + d.numero + (d.moneda !== r.moneda ? ' · ' + money(m, d.moneda) + ' al tipo de cambio ' + fmt(tcPago(d.moneda, r.moneda), 2) : ''), medio: d.medio || '04', cuenta: d.cuenta || '', monto: montoCuenta, moneda: r.moneda, deposito_id: d.id, monto_deposito: m, en_banco: false });
  cambiarDeposito(d.id, x => ({ ...x, aplicaciones: [...(x.aplicaciones || []), { reserva_id: r.id, numero: r.numero, monto: m, fecha: hoyHotel(), folio_id: item.id }], historial: [...(x.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto: 'Aplicado ' + money(m, d.moneda) + ' a la reserva ' + r.numero }] }));
  return item;
}
export async function devolverDeposito(d, dv) {
  const m = r2(Math.min(+dv.monto || 0, depositoDisponible(d))); if (m <= 0) return false;
  const n = (d.devoluciones || []).length + 1, fecha = dv.fecha || hoyHotel();
  cambiarDeposito(d.id, x => ({ ...x, devoluciones: [...(x.devoluciones || []), { monto: m, fecha, medio: dv.medio || '04', cuenta: dv.cuenta || '', referencia: dv.referencia || '', motivo: dv.motivo || '' }], historial: [...(x.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto: 'Devuelto ' + money(m, d.moneda) + ' ' + nombreMedio(dv.medio || '04') + (dv.motivo ? ' · ' + dv.motivo : '') }] }));
  if (dv.cuenta) {
    try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: dv.cuenta, monto: -m, fecha, descripcion: 'Devolución del depósito en garantía ' + d.numero + ' · ' + (d.nombre || ''), ref: 'hotel:devolucion:' + d.id + ':' + n, moneda: d.moneda, tipo_cambio: monedas.tc(d.moneda) } }); }
    catch (e) { toast('La devolución quedó registrada, pero no salió de Bancos: ' + e.message, 'err'); }
  }
  return true;
}
// Traspaso: parte de un depósito pasa a otro huésped o contacto como un depósito nuevo (el dinero no se mueve en Bancos)
export function traspasarDeposito(d, datos, monto) {
  const m = r2(Math.min(+monto || 0, depositoDisponible(d))); if (m <= 0) return null;
  const lista = depositos(), n = siguienteNumero(lista, 'numero', 'DG-', 1), ahora = new Date().toISOString();
  const nuevo = { ...d, ...datos, id: mock.nextId(lista, 'hotel_depositos'), numero: 'DG-' + String(n).padStart(4, '0'), monto: m, fecha: hoyHotel(), aplicaciones: [], devoluciones: [], origen_deposito: d.numero, en_banco: false, creado: ahora, usuario: usuarioActual(), historial: [{ fecha: ahora, usuario: usuarioActual(), texto: 'Traspasado desde ' + d.numero + ': ' + money(m, d.moneda) }] };
  mock.set('hotel_depositos', [...lista.map(x => (x.id === d.id ? { ...x, devoluciones: [...(x.devoluciones || []), { monto: m, fecha: hoyHotel(), medio: 'traspaso', cuenta: '', referencia: nuevo.numero, motivo: 'Traspaso a ' + (datos.nombre || '') }], historial: [...(x.historial || []), { fecha: ahora, usuario: usuarioActual(), texto: 'Traspasado ' + money(m, d.moneda) + ' a ' + nuevo.numero + ' (' + (datos.nombre || '') + ')' }] } : x)), nuevo]);
  return nuevo;
}

// ---- servicios (3.5): spa, tours, traslados y alquileres; catálogo en hotel_servicios y agenda en hotel_servicios_agenda ----
export const TIPOS_SERVICIO = [['spa', 'Spa y masajes'], ['tour', 'Tours y excursiones'], ['traslado', 'Traslados'], ['alquiler', 'Alquileres (bicicletas, kayaks, equipo)'], ['otro', 'Otros servicios']];
export function nombreTipoServicio(t) { return (TIPOS_SERVICIO.find(x => x[0] === t) || [t, t || '—'])[1]; }
export const ESTADOS_SERVICIO = { reservado: 'Reservado', realizado: 'Realizado', cancelado: 'Cancelado', no_show: 'No llegó' };
export function serviciosCatalogo() { return mock.get('hotel_servicios', []) || []; }
export function serviciosAgenda() { return mock.get('hotel_servicios_agenda', []) || []; }
// Cargo a la cuenta por un servicio de la agenda: precio en la moneda de la cuenta, sin IVA a 5 decimales; IVA y CABYS del ítem de venta ligado o los del hotel
export function cargoServicio(a, s, r, cfg) {
  const c = cfg || config(), prod = s && s.producto_id ? (store.productos || []).find(p => p.id === s.producto_id) : null;
  const tarifa = prod ? +prod.tarifa || 0 : +c.tarifa_iva || 0;
  const bruto = convertirMonto(+a.precio || 0, a.moneda || c.moneda, r.moneda, c);
  const precio = c.precios_incluyen_iva ? r5(bruto / (1 + tarifa / 100)) : r5(bruto);
  return { reserva_id: r.id, tipo: 'cargo', origen: 'servicios', servicio_id: a.id, fecha: hoyHotel(), detalle: a.servicio_nombre + ' · ' + fechaCorta(a.fecha) + (a.hora ? ' ' + a.hora : '') + (+a.personas > 1 ? ' · ' + a.personas + ' personas' : ''),
    cantidad: +a.personas || 1, precio, tarifa, codigo_tarifa: prod ? prod.codigo_tarifa : (c.codigo_tarifa || '08'), cabys: prod ? prod.cabys : (c.cabys_hospedaje || CABYS_HOSPEDAJE), moneda: r.moneda, producto_id: prod ? prod.id : null };
}

// ---- eventos y banquetes (3.6): salones en hotel_salones y eventos en hotel_eventos; la cuenta del evento es una cuenta externa ----
export const TIPOS_EVENTO = [['boda', 'Boda'], ['corporativo', 'Corporativo o reunión'], ['seminario', 'Seminario o capacitación'], ['fiesta', 'Fiesta o celebración'], ['graduacion', 'Graduación'], ['otro', 'Otro']];
export const MONTAJES = [['banquete', 'Banquete (mesas redondas)'], ['auditorio', 'Auditorio'], ['escuela', 'Escuela'], ['u', 'Herradura (U)'], ['coctel', 'Cóctel (de pie)'], ['imperial', 'Imperial (mesa larga)']];
export const ESTADOS_EVENTO = { cotizado: 'Cotizado', confirmado: 'Confirmado', realizado: 'Realizado', cancelado: 'Cancelado' };
export const CONCEPTOS_EVENTO = [['Alquiler del salón', 'evento'], ['Menú por persona', 'persona'], ['Coffee break', 'persona'], ['Bebidas', 'persona'], ['Equipo audiovisual', 'evento'], ['Decoración', 'evento'], ['Personal de servicio', 'evento']];
export function salones() { return mock.get('hotel_salones', []) || []; }
export function eventos() { return mock.get('hotel_eventos', []) || []; }
export function totalEvento(e) { return r2((e.lineas || []).reduce((s, l) => s + (l.por === 'persona' ? (+e.personas || 0) : (+l.cantidad || 0)) * (+l.precio || 0), 0)); }
// Cargo a la cuenta del evento por cada concepto: precio en la moneda de la cuenta, sin IVA a 5 decimales; IVA y CABYS del ítem ligado o los del hotel
export function cargoEvento(l, e, r, cfg, productos) {
  const c = cfg || config(), prod = l.producto_id ? (productos || store.productos || []).find(p => p.id === l.producto_id) : null;
  const tarifa = prod ? +prod.tarifa || 0 : +c.tarifa_iva || 0;
  const bruto = convertirMonto(+l.precio || 0, e.moneda || c.moneda, r.moneda, c);
  const precio = c.precios_incluyen_iva ? r5(bruto / (1 + tarifa / 100)) : r5(bruto);
  return { reserva_id: r.id, tipo: 'cargo', origen: 'eventos', evento_id: e.id, fecha: hoyHotel(), detalle: l.concepto + ' · ' + e.numero + ' ' + e.nombre + (l.por === 'persona' ? ' · ' + e.personas + ' personas' : ''),
    cantidad: l.por === 'persona' ? (+e.personas || 1) : (+l.cantidad || 1), precio, tarifa, codigo_tarifa: prod ? prod.codigo_tarifa : (c.codigo_tarifa || '08'), cabys: prod ? prod.cabys : (c.cabys_hospedaje || CABYS_HOSPEDAJE), moneda: r.moneda, producto_id: prod ? prod.id : null };
}

// ---- cuentas externas (3.0): folios sin habitación (eventos, clientes externos, consumo de empleados). Viven en hotel_reservas con tipo 'folio' ----
export function cuentasExternas() { return reservas().filter(r => r.tipo === 'folio'); }
export function nuevaCuentaExterna(cfg) {
  const c = cfg || config(), n = siguienteNumero(cuentasExternas(), 'numero', 'CE-', 1);
  return { id: null, tipo: 'folio', estado: 'abierto', numero: 'CE-' + String(n).padStart(4, '0'), huesped_id: null, huesped_nombre: '', cliente_id: null, grupo: '', llegada: hoyHotel(), salida: hoyHotel(), categoria_id: null, habitacion_id: null, adultos: 0, ninos: 0, total: 0, moneda: c.moneda || 'USD', origen: 'directa', segmento: '', notas: '', creado: new Date().toISOString(), usuario: usuarioActual(), documento_id: null, consecutivo: null, historial: [] };
}

// ---- reportes de problemas (2.4): cualquier usuario reporta; el tipo decide a qué módulo va (ama de llaves o mantenimiento) ----
export const MODULOS_REPORTE = [['limpieza', 'Ama de llaves'], ['mantenimiento', 'Mantenimiento']];
export function nombreModulo(m) { return (MODULOS_REPORTE.find(x => x[0] === m) || [m, m])[1]; }
export const TIPOS_BASE = {
  limpieza: ['Toallas o ropa de cama faltante', 'Habitación sin limpiar', 'Baño sucio', 'Amenidades faltantes (jabón, papel, café)', 'Basura sin recoger', 'Olor o humedad', 'Insectos', 'Cuna o cama extra solicitada'],
  mantenimiento: ['Aire acondicionado no enfría', 'Fuga de agua o goteo', 'Luz o foco quemado', 'Televisor o control remoto', 'Cerradura o llave', 'Wifi sin señal', 'Sin agua caliente', 'Puerta, ventana o mueble dañado', 'Pintura o pared', 'Minibar o refrigeradora', 'Caja fuerte'],
};
export const ESTADOS_REPORTE = { abierto: 'Abierto', en_proceso: 'En proceso', resuelto: 'Resuelto' };
// Tipos de problema por módulo; la primera vez se cargan los básicos y cada módulo agrega los suyos
export function tiposProblema(modulo) {
  let l = mock.get('hotel_tipos_problema', null);
  if (!Array.isArray(l) || !l.length) {
    l = []; let id = 1;
    for (const [m, ts] of Object.entries(TIPOS_BASE)) for (const t of ts) l.push({ id: id++, modulo: m, nombre: t, activo: true });
    if (mock.cargado) mock.set('hotel_tipos_problema', l);
  }
  return modulo ? l.filter(t => t.modulo === modulo && t.activo !== false) : l;
}
export function reportes() { return mock.get('hotel_reportes', []) || []; }
export function reportesAbiertos(modulo) { return reportes().filter(r => r.estado !== 'resuelto' && (!modulo || r.modulo === modulo)); }
export function abiertosPorHab() { const m = {}; for (const r of reportesAbiertos()) if (r.habitacion_id) m[r.habitacion_id] = (m[r.habitacion_id] || 0) + 1; return m; }
export function crearReporte(r) {
  const lista = reportes(), n = siguienteNumero(lista, 'numero', 'RP-', 1);
  const reg = { estado: 'abierto', prioridad: 'normal', ...r, id: mock.nextId(lista, 'hotel_reportes'), numero: 'RP-' + String(n).padStart(4, '0'), creado: new Date().toISOString(), usuario: usuarioActual(), historial: [{ fecha: new Date().toISOString(), usuario: usuarioActual(), texto: 'Reportado' }] };
  mock.set('hotel_reportes', [...lista, reg]);
  return reg;
}
export function cambiarReporte(id, fn) { let out = null; mock.actualizar('hotel_reportes', l => (l || []).map(x => { if (x.id !== id) return x; const n = { ...x }; const r = fn(n); out = r || n; return out; }), []); return out; }
export function anotarReporte(r, texto) { return { ...r, historial: [...(r.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto }].slice(-40) }; }

// ---- listas del día (Recepción) ----
export function listasDelDia(dia, lista) {
  const h = dia || hoyHotel(), rs = (lista || reservas()).filter(esEstadia);
  const llegadas = rs.filter(r => ['pendiente', 'confirmada'].includes(r.estado) && r.llegada <= h).sort((a, b) => String(a.llegada).localeCompare(String(b.llegada)) || String(a.huesped_nombre).localeCompare(String(b.huesped_nombre)));
  const salidas = rs.filter(r => r.estado === 'en_casa' && r.salida <= h).sort((a, b) => String(a.salida).localeCompare(String(b.salida)) || nombreHab(a.habitacion_id).localeCompare(nombreHab(b.habitacion_id), 'es', { numeric: true }));
  const enCasa = rs.filter(r => r.estado === 'en_casa').sort((a, b) => nombreHab(a.habitacion_id).localeCompare(nombreHab(b.habitacion_id), 'es', { numeric: true }));
  const proximas = rs.filter(r => ['pendiente', 'confirmada'].includes(r.estado) && r.llegada > h).sort((a, b) => String(a.llegada).localeCompare(String(b.llegada)));
  return { llegadas, salidas, enCasa, proximas };
}
// ---- tablero del hotel (H7): alertas, tareas e indicadores del día, calculados aquí con los registros que el rol ya recibe ----
export const HORAS_TAREA_ATRASADA = 24;       // una incidencia abierta o en proceso pasa a «atrasada» a las 24 horas (o si es urgente)
export const DIAS_ALERTA_SOBREVENTA = 14;     // la alerta de sobreventa mira desde hoy esta cantidad de días
// Sello de tiempo → Date (uno sin zona es UTC, como en api.js) y su día en hora de Costa Rica
function sello(x) { let v = String(x || ''); if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(v)) v = v.replace(' ', 'T') + 'Z'; return new Date(v); }
function diaCR(iso) { const d = sello(iso); if (isNaN(d)) return String(iso || '').slice(0, 10); try { return d.toLocaleDateString('en-CA', { timeZone: 'America/Costa_Rica' }); } catch { return d.toISOString().slice(0, 10); } }
// Habitaciones activas en mantenimiento que no tienen ya un bloqueo de fechas ese día (las bloqueadas se cuentan aparte, en ocupacionDia)
export function habitacionesFuera(fecha, lista, habs) {
  const f = fecha || hoyHotel(), bloqueadas = new Set((lista || reservas()).filter(r => r.tipo === 'bloqueo' && r.habitacion_id && r.llegada <= f && f < r.salida).map(r => r.habitacion_id));
  return (habs || habitaciones()).filter(x => x.activa !== false && x.estado === 'mantenimiento' && !bloqueadas.has(x.id)).length;
}
// Alertas del día de trabajo: [{ clave, nivel: 'danger' | 'warn', texto, enlace }]. Las de saldo salen de hotel_folios: quien no recibe
// montos no las ve (sin datos no hay alerta, nunca una cifra falsa). La sobreventa usa disponibilidadPorTipo, la misma cuenta del pronóstico.
export function alertasHotel(fecha, lista, cfg) {
  const h = fecha || hoyHotel(), c = cfg || config(), todas = lista || reservas(), rs = todas.filter(esEstadia), out = [];
  const cuantas = (n, una, varias) => n + ' ' + (n === 1 ? una : varias);
  const poner = (clave, nivel, texto, enlace) => out.push({ clave, nivel, texto, enlace });
  const porLlegar = rs.filter(r => ['pendiente', 'confirmada'].includes(r.estado)), enCasa = rs.filter(r => r.estado === 'en_casa');
  if (fechaHotelActiva() && hoyHotel() < hoy()) poner('cierre', 'danger', 'El día ' + fechaCorta(hoyHotel()) + ' sigue abierto: falta el cierre del día', '#/hotel/cierre');
  const habs = habitaciones(); let diasSobre = 0, primero = null;
  for (const f of fechasEntre(h, DIAS_ALERTA_SOBREVENTA)) {
    const d = disponibilidadPorTipo(f, todas, { habs, cfg: c }), cats = Object.keys(d.porCat).filter(k => d.porCat[k].libres < 0);
    if (cats.length) { diasSobre++; if (!primero) primero = { f, cats }; }
  }
  if (diasSobre) poner('sobreventa', 'danger', 'Sobreventa: ' + cuantas(diasSobre, 'día', 'días') + ' de los próximos ' + DIAS_ALERTA_SOBREVENTA + ' con más reservas que habitaciones (' + primero.cats.map(k => (+k ? nombreCat(+k) : 'sin categoría')).join(', ') + ', desde el ' + fechaCorta(primero.f) + ')', '#/hotel/reportes?rep=pronostico_tipo&desde=' + h + '&hasta=' + sumarDias(h, DIAS_ALERTA_SOBREVENTA - 1));
  const atrasadas = porLlegar.filter(r => r.llegada < h).length;
  if (atrasadas) poner('atrasadas', 'warn', cuantas(atrasadas, 'llegada de días anteriores sigue', 'llegadas de días anteriores siguen') + ' sin check-in', '#/hotel/recepcion');
  const manana = sumarDias(h, 1), sinHab = porLlegar.filter(r => !r.habitacion_id && (r.llegada === h || r.llegada === manana)).length;
  if (sinHab) poner('sin_habitacion', 'warn', cuantas(sinHab, 'llegada de hoy o de mañana no tiene', 'llegadas de hoy o de mañana no tienen') + ' habitación asignada', '#/hotel/calendario');
  const plazo = +c.adelanto_plazo_dias || 0;
  const vencidas = plazo > 0 ? rs.filter(r => r.estado === 'pendiente' && String(r.creado || '').length >= 10 && noches(diaCR(r.creado), h) >= plazo).length : 0;
  if (vencidas) poner('adelanto', 'warn', cuantas(vencidas, 'reserva pendiente tiene', 'reservas pendientes tienen') + ' vencido el plazo de ' + cuantas(plazo, 'día', 'días') + ' para el adelanto', '#/hotel/reservaciones?estado=pendiente');
  if (enCasa.length) {
    // los cargos y pagos se agrupan UNA vez por cuenta; lo que paga la agencia (tarifa neta) no es saldo del huésped
    const porCuenta = new Map(); for (const f of folios()) { if (!porCuenta.has(f.reserva_id)) porCuenta.set(f.reserva_id, []); porCuenta.get(f.reserva_id).push(f); }
    const saldos = new Map(enCasa.map(r => { const items = porCuenta.get(r.id) || []; return [r.id, totalesFolio(r.agencia_id ? items.filter(f => !esCargoAgencia(f, r)) : items).saldo]; }));
    const conSaldo = enCasa.filter(r => r.salida <= h && saldos.get(r.id) > 0.005).length;
    if (conSaldo) poner('salidas_saldo', 'warn', cuantas(conSaldo, 'salida de hoy tiene', 'salidas de hoy tienen') + ' saldo por cobrar', '#/hotel/recepcion');
    const tope = +c.tope_cuenta || 0, sobre = tope > 0 ? enCasa.filter(r => saldos.get(r.id) > tope).length : 0;
    if (sobre) poner('tope', 'warn', cuantas(sobre, 'cuenta en casa supera', 'cuentas en casa superan') + ' el tope de ' + money(tope, c.moneda || 'USD'), '#/hotel/recepcion');
  }
  const habPorId = new Map(habs.map(x => [x.id, x]));
  const sucias = [...new Set(porLlegar.filter(r => r.llegada === h && r.habitacion_id && (habPorId.get(r.habitacion_id) || {}).estado === 'sucia').map(r => String(habPorId.get(r.habitacion_id).numero)))];
  if (sucias.length) poner('sucias', 'warn', (sucias.length === 1 ? 'La habitación ' + sucias[0] + ' tiene llegada hoy y sigue sucia' : 'Las habitaciones ' + sucias.join(', ') + ' tienen llegada hoy y siguen sucias'), sesion.puede('limpieza') ? '#/hotel/ama-de-llaves/tablero' : '#/hotel/recepcion');
  return out;
}
// Tareas de ama de llaves y mantenimiento, de hotel_reportes: abierto = pendiente; en_proceso = en proceso; atrasada = una de esas dos
// con más de HORAS_TAREA_ATRASADA horas o urgente (se cuenta además de su estado); completada = resuelta desde la fecha de trabajo.
// Los planes de hotel_preventivo con la próxima fecha vencida cuentan como atrasados de mantenimiento.
export function tareasHotel(fecha) {
  const h = fecha || hoyHotel(), ahora = Date.now(), cero = () => ({ pendientes: 0, en_proceso: 0, atrasadas: 0, completadas: 0 });
  const t = { ...cero(), preventivo: 0, porModulo: { limpieza: cero(), mantenimiento: cero() } };
  for (const r of reportes()) {
    const m = t.porModulo[r.modulo] || (t.porModulo[r.modulo] = cero()), suma = k => { t[k]++; m[k]++; };
    if (r.estado === 'resuelto') { if (r.resuelto_en && diaCR(r.resuelto_en) >= h) suma('completadas'); continue; }
    suma(r.estado === 'en_proceso' ? 'en_proceso' : 'pendientes');
    if (r.prioridad === 'urgente' || (ahora - sello(r.creado).getTime()) / 3600000 > HORAS_TAREA_ATRASADA) suma('atrasadas');
  }
  for (const p of mock.get('hotel_preventivo', []) || []) if (p && p.activo !== false && p.proxima && p.proxima < h) { t.preventivo++; t.atrasadas++; t.porModulo.mantenimiento.atrasadas++; }
  return t;
}
// Indicadores del día `fecha` (la fecha de trabajo), en la moneda del hotel y con IVA, como los reportes. ADR y RevPAR: solo hospedaje;
// RevPOR: todos los cargos del día (cualquier concepto) entre las habitaciones ocupadas. ingresos8: los cargos de los últimos 8 días.
export function tableroHotel(fecha) {
  const f = fecha || hoyHotel(), cfg = config(), mon = cfg.moneda || 'USD', todas = reservas(), habs = habitaciones(), o = ocupacionDia(f, todas, habs);
  const desde = sumarDias(f, -7), porDia = {}; let hospedaje = 0, cargos = 0;
  for (const x of folios()) {
    if (x.tipo !== 'cargo' || !(x.fecha >= desde && x.fecha <= f)) continue;
    const v = convertirMonto(totalCargo(x), x.moneda || mon, mon, cfg);
    porDia[x.fecha] = (porDia[x.fecha] || 0) + v;
    if (x.fecha === f) { cargos += v; if (x.origen === 'hospedaje') hospedaje += v; }
  }
  const ingresos8 = fechasEntre(desde, 8).map(d => ({ fecha: d, total: r2(porDia[d] || 0) }));
  return { fecha: f, moneda: mon, adr: o.ocupadas ? r2(hospedaje / o.ocupadas) : 0, revpar: o.total ? r2(hospedaje / o.total) : 0, revpor: o.ocupadas ? r2(cargos / o.ocupadas) : 0,
    hospedaje: r2(hospedaje), ingreso: r2(cargos), ocupadas: o.ocupadas, total: o.total, pct: o.pct, bloqueadas: o.bloqueadas, fuera: habitacionesFuera(f, todas, habs),
    ingresos8, maxIngreso: Math.max(1, ...ingresos8.map(x => x.total)), alertas: alertasHotel(f, todas, cfg), tareas: tareasHotel(f) };
}

// ---- mensajes (confirmación por correo o WhatsApp) ----
export function textoConfirmacion(r, cfg) {
  const c = cfg || config(), cat = categoria(r.categoria_id), emp = store.empresa || {};
  const rep = { huesped: r.huesped_nombre || '', numero: r.numero || '', hotel: c.nombre || emp.nombre_comercial || emp.nombre || '', llegada: fechaLarga(r.llegada), salida: fechaLarga(r.salida), hora_entrada: c.hora_entrada || '', hora_salida: c.hora_salida || '',
    categoria: cat ? cat.nombre : '', habitacion: nombreHab(r.habitacion_id), noches: String(noches(r.llegada, r.salida)), personas: String((+r.adultos || 0) + (+r.ninos || 0)), total: money(r.total || 0, r.moneda), adelanto: money(r.adelanto_requerido || 0, r.moneda), politicas: c.politicas || '', wifi: c.wifi || '' };
  return String(c.mensaje_confirmacion || MENSAJE_BASE).replace(/\{(\w+)\}/g, (m, k) => (rep[k] !== undefined ? rep[k] : m));
}
export function fechaLarga(iso) { if (!iso) return ''; const d = new Date(iso + 'T00:00:00'); return ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'][d.getDay()] + ' ' + d.getDate() + ' de ' + ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'][d.getMonth()] + ' de ' + d.getFullYear(); }
// Texto de WhatsApp de pre-llegada o de salida (3.21): misma plantilla que la confirmación más {enlace} del comprobante
export function textoMensaje(plantilla, r, cfg, extra) {
  const c = cfg || config();
  const base = textoConfirmacion(r, { ...c, mensaje_confirmacion: plantilla || '' });
  return base.replace(/\{enlace\}/g, (extra && extra.enlace) || '');
}
export function enlaceWhatsApp(telefono, texto) { const t = String(telefono || '').replace(/\D/g, ''); const n = t.length === 8 ? '506' + t : t; return 'https://wa.me/' + n + '?text=' + encodeURIComponent(texto); }

// ---- impresión (hoja imprimible desde el navegador) ----
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
export function abrirHoja(titulo, cuerpo) {
  const html = '<!doctype html><html><head><meta charset="utf-8"><title>' + esc(titulo) + '</title><style>body{font-family:system-ui,Arial,sans-serif;font-size:13px;color:#1d2433;max-width:760px;margin:18px auto;padding:0 16px}h1{font-size:20px;margin:0 0 2px}h2{font-size:14px;margin:18px 0 6px;border-bottom:1px solid #cfd6e0;padding-bottom:3px}table{width:100%;border-collapse:collapse}td,th{padding:5px 6px;border-bottom:1px solid #e3e7ee;text-align:left;vertical-align:top}th{font-size:11px;text-transform:uppercase;color:#6b7280}td.n,th.n{text-align:right;white-space:nowrap}.muted{color:#6b7280}.firma{margin-top:40px;display:flex;gap:40px}.firma div{flex:1;border-top:1px solid #1d2433;padding-top:4px;font-size:12px}.tot td{font-weight:700;border-top:2px solid #cfd6e0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:4px 18px}@media print{body{margin:0}}</style></head><body>' + cuerpo + '</body></html>';
  const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
}
export function encabezadoHoja(subtitulo) { const e = store.empresa || {}, c = config(); return '<h1>' + esc(c.nombre || e.nombre_comercial || e.nombre || '') + '</h1><div class="muted">' + esc([e.nombre !== c.nombre ? e.nombre : '', e.numero_id ? 'Cédula ' + e.numero_id : '', e.telefono ? 'Tel. ' + e.telefono : '', e.correo].filter(Boolean).join(' · ')) + '</div><div style="margin:8px 0 0;font-size:15px;font-weight:600">' + esc(subtitulo) + '</div>'; }
export function tarjetaRegistroHTML(r, h, firma) {
  const c = config(), cat = categoria(r.categoria_id), kv = (k, v) => '<div><span class="muted">' + esc(k) + ':</span> ' + esc(v || '—') + '</div>';
  const datos = kv('Nombre', nombreHuesped(h)) + kv('Documento', h ? ((TIPOS_DOC.find(t => t[0] === h.tipo_doc) || ['', ''])[1] + ' ' + (h.documento || '')) : '') + kv('Nacionalidad', h && h.nacionalidad) + kv('Fecha de nacimiento', h && h.nacimiento ? h.nacimiento.split('-').reverse().join('/') : '') + kv('Teléfono', h && h.telefono) + kv('Correo', h && h.correo) + kv('Dirección', h ? [h.ciudad, h.pais].filter(Boolean).join(', ') : '') + kv('Vehículo', r.vehiculo);
  const est = kv('Reserva', r.numero) + kv('Habitación', nombreHab(r.habitacion_id) + (cat ? ' · ' + cat.nombre : '')) + kv('Llegada', fechaLarga(r.llegada) + ' · desde las ' + (c.hora_entrada || '')) + kv('Salida', fechaLarga(r.salida) + ' · hasta las ' + (c.hora_salida || '')) + kv('Noches', String(noches(r.llegada, r.salida))) + kv('Personas', (r.adultos || 0) + ' adulto(s)' + (r.ninos ? ', ' + r.ninos + ' niño(s)' : '')) + kv('Acompañantes', r.acompanantes) + kv('Tarifa por noche', money(r.tarifa_noche || 0, r.moneda) + (c.precios_incluyen_iva ? ' (IVA incluido)' : ' + IVA')) + kv('Total estimado', money(r.total || 0, r.moneda)) + kv('Origen', nombreOrigen(r.origen))
    + (vueloTexto(r.vuelo_llegada, r.hora_vuelo_llegada) ? kv('Vuelo de llegada', vueloTexto(r.vuelo_llegada, r.hora_vuelo_llegada)) : '') + (vueloTexto(r.vuelo_salida, r.hora_vuelo_salida) ? kv('Vuelo de salida', vueloTexto(r.vuelo_salida, r.hora_vuelo_salida)) : '') + (r.traslado ? kv('Traslado', nombreTraslado(r.traslado) + (r.traslado_nota ? ' · ' + r.traslado_nota : '')) : '');   // H8
  return encabezadoHoja('Tarjeta de registro · ' + r.numero) + '<h2>Huésped</h2><div class="grid">' + datos + '</div><h2>Estadía</h2><div class="grid">' + est + '</div>' + (r.especiales ? '<h2>Pedidos especiales</h2><div>' + esc(r.especiales) + '</div>' : '') + '<h2>Políticas</h2><div style="white-space:pre-wrap">' + esc(c.politicas || '') + '</div>' + (firma ? '<h2>Firma del huésped</h2><img src="' + firma + '" style="height:80px;max-width:320px;display:block">' : '') + '<p class="muted" style="margin-top:14px">Declaro que los datos anteriores son correctos y acepto las políticas del hotel. Autorizo el cargo de los consumos a mi cuenta y su cobro al momento de la salida.</p><div class="firma"><div>Firma del huésped</div><div>Recepción · ' + esc(new Date().toLocaleString('es-CR')) + '</div></div>';
}
export function estadoCuentaHTML(r, h, items) {
  const t = totalesFolio(items), cargos = items.filter(f => f.tipo === 'cargo'), pagos = items.filter(f => f.tipo === 'pago');
  const filas = cargos.map(f => '<tr><td>' + esc(fechaCorta(f.fecha)) + '</td><td>' + esc(f.detalle) + '</td><td class="n">' + esc(fmt(f.cantidad, 0)) + '</td><td class="n">' + esc(money(f.precio, r.moneda)) + '</td><td class="n">' + esc(money(totalCargo(f), r.moneda)) + '</td></tr>').join('');
  const fp = pagos.map(f => '<tr><td>' + esc(fechaCorta(f.fecha)) + '</td><td>' + esc(f.detalle || nombreMedio(f.medio)) + '</td><td class="n" colspan="3">' + esc(money(f.monto, r.moneda)) + '</td></tr>').join('');
  return encabezadoHoja('Estado de cuenta · ' + r.numero + ' · ' + nombreHuesped(h) + ' · Hab. ' + nombreHab(r.habitacion_id)) + '<div class="muted">' + esc(fechaLarga(r.llegada) + ' al ' + fechaLarga(r.salida) + ' · ' + noches(r.llegada, r.salida) + ' noche(s)') + '</div><h2>Cargos</h2><table><thead><tr><th>Fecha</th><th>Detalle</th><th class="n">Cant.</th><th class="n">Precio</th><th class="n">Total</th></tr></thead><tbody>' + filas + '</tbody><tbody class="tot"><tr><td colspan="4">Total de cargos (IVA ' + esc(money(t.iva, r.moneda)) + ' incluido)</td><td class="n">' + esc(money(t.cargos, r.moneda)) + '</td></tr></tbody></table>' + (pagos.length ? '<h2>Pagos y adelantos</h2><table><tbody>' + fp + '</tbody><tbody class="tot"><tr><td colspan="2">Total pagado</td><td class="n" colspan="3">' + esc(money(t.pagos, r.moneda)) + '</td></tr></tbody></table>' : '') + '<h2>Saldo por pagar: ' + esc(money(t.saldo, r.moneda)) + '</h2><p class="muted">Este documento no es un comprobante electrónico: la factura o el tiquete se emite al momento de la salida.</p>';
}

// ---- lista de espera y cotizaciones (3.22) ----
export function esperas() { return mock.get('hotel_espera', []) || []; }
export function cotizaciones() { return mock.get('hotel_cotizaciones', []) || []; }
// firma y foto del documento del huésped (3.22): archivos del servidor, se leen con el token y se devuelven como data URL (o null)
export async function archivoHuesped(hid, tipo) {
  try {
    const r = await fetch('/api/hotel/huespedes/' + hid + '/archivo/' + tipo, { headers: cabecerasAuth() });
    if (!r.ok) return null;
    const b = await r.blob();
    return await new Promise(res => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => res(null); fr.readAsDataURL(b); });
  } catch { return null; }
}
