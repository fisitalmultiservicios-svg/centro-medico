// Bloqueo de habitaciones en lote (H6): un solo cuadro para «Bloquear habitaciones» (Reservaciones) y «Bloquear fechas» (Mantenimiento ›
// Fuera de servicio). Se eligen las fechas, el motivo y las habitaciones libres esas noches (por piso y categoría); al guardar se crea
// un bloqueo por habitación en un solo guardado: o se crean todos o ninguno. QuitarBloqueo es el cuadro para quitar uno solo o su lote.
import { toast, fecha, sumarDias, mock } from '../../api.js';
import { hoyHotel, reservas, disponibles, disponibilidadPorTipo, fechasEntre, noches, pisoDe, nombreCat, nombreHab, ordenHab, usuarioActual, MOTIVOS_BLOQUEO, nombreMotivoBloqueo, crearBloqueos, quitarBloqueos, bloqueosDeLote } from './_datos.js';

export default {
  // lista: reservas y bloqueos que la pantalla ya tiene; habs: habitaciones entre las que se puede elegir (sin ella, todas las activas);
  // habInicial: habitación que llega marcada (el botón «Bloquear fechas» de una habitación en mantenimiento)
  props: { lista: Array, habs: Array, habInicial: { type: Number, default: null } },
  emits: ['listo', 'cerrar'],
  data() { const h = hoyHotel(); return { desde: h, hasta: sumarDias(h, 1), motivo_tipo: 'mantenimiento', motivo: '', sel: this.habInicial ? [this.habInicial] : [], marcar: false, guardando: false, MOTIVOS_BLOQUEO }; },
  computed: {
    fechasOk() { return !!this.desde && !!this.hasta && this.hasta > this.desde; },
    // habitaciones activas libres TODAS las noches del bloqueo
    libres() {
      if (!this.fechasOk) return [];
      const permitidas = this.habs ? new Set(this.habs.map(h => h.id)) : null;
      return disponibles(null, this.desde, this.hasta, null, this.lista || reservas()).filter(h => !permitidas || permitidas.has(h.id)).sort(ordenHab);
    },
    idsLibres() { return this.libres.map(h => h.id); },
    // por piso y, dentro de cada piso, por categoría
    pisos() {
      const m = new Map();
      for (const h of this.libres) { const p = pisoDe(h); if (!m.has(p)) m.set(p, new Map()); const c = m.get(p), k = h.categoria_id || 0; if (!c.has(k)) c.set(k, { id: k, nombre: nombreCat(h.categoria_id), habs: [] }); c.get(k).habs.push(h); }
      return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0], 'es', { numeric: true })).map(([piso, c]) => ({ piso, cats: [...c.values()], ids: [...c.values()].flatMap(x => x.habs.map(h => h.id)) }));
    },
    // «todas las libres de esta categoría», de cualquier piso
    cats() { const m = new Map(); for (const h of this.libres) { const k = h.categoria_id || 0; if (!m.has(k)) m.set(k, { id: k, nombre: nombreCat(h.categoria_id), ids: [] }); m.get(k).ids.push(h.id); } return [...m.values()]; },
    // lo marcado que sigue libre con las fechas actuales (al cambiar las fechas, una habitación marcada puede dejar de estarlo)
    elegidas() { const ok = new Set(this.idsLibres); return this.sel.filter(id => ok.has(id)); },
    cubreHoy() { const h = hoyHotel(); return this.fechasOk && this.desde <= h && h < this.hasta; },
    // categorías que el bloqueo dejaría con menos habitaciones que reservas: las reservas «asignar al llegar» no ocupan una habitación,
    // pero sí un cupo de su categoría. Una habitación que hoy ya está en mantenimiento no resta otra vez esa noche.
    sobreventa() {
      if (!this.fechasOk || !this.elegidas.length) return [];
      const lista = this.lista || reservas(), hoyS = hoyHotel(), elegidas = new Set(this.elegidas), porCat = new Map();
      for (const f of fechasEntre(this.desde, Math.min(noches(this.desde, this.hasta), 366))) {
        const n = {}; for (const h of this.libres) if (elegidas.has(h.id) && !(f === hoyS && h.estado === 'mantenimiento')) { const k = h.categoria_id || 0; n[k] = (n[k] || 0) + 1; }
        const d = disponibilidadPorTipo(f, lista).porCat;
        for (const k of Object.keys(n)) { const e = d[k]; if (!e || !e.sin_asignar || e.libres - n[k] >= 0) continue; const faltan = Math.min(n[k] - e.libres, e.sin_asignar), s = porCat.get(k); if (s) { s.noches++; s.faltan = Math.max(s.faltan, faltan); } else porCat.set(k, { cat: nombreCat(+k), fecha: f, noches: 1, faltan }); }
      }
      return [...porCat.values()];
    },
  },
  methods: {
    fecha,
    todasDe(ids) { return ids.length > 0 && ids.every(id => this.sel.includes(id)); },
    marcarGrupo(ids, v) { const s = new Set(this.sel); for (const id of ids) { if (v) s.add(id); else s.delete(id); } this.sel = [...s]; },
    async guardar() {
      if (!this.fechasOk) return toast('Revise las fechas: la fecha final debe ser posterior a la inicial', 'err');
      const ids = this.elegidas; if (!ids.length) return toast('Marque al menos una habitación', 'err');
      if (!mock.puedeGuardar()) return;
      if (this.sobreventa.length && !confirm('Con este bloqueo quedarían reservas sin habitación disponible en: ' + this.sobreventa.map(s => s.cat).join(', ') + '. ¿Bloquear de todos modos?')) return;
      this.guardando = true;
      const { regs, promesa } = crearBloqueos(ids, this.desde, this.hasta, this.motivo, this.motivo_tipo);
      const ok = await promesa;
      this.guardando = false;
      if (!ok) return;   // el servidor ya avisó (por ejemplo, una habitación se ocupó mientras tanto): no quedó bloqueada ninguna
      // «además en mantenimiento»: solo si el bloqueo cubre hoy; es el estado de la habitación, que después se libera a mano
      const marcadas = this.marcar && this.cubreHoy ? ids.slice() : [];
      if (marcadas.length) { const m = new Set(marcadas), ahora = new Date().toISOString(); mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (m.has(x.id) && x.estado !== 'mantenimiento' ? { ...x, estado: 'mantenimiento', estado_hora: ahora, estado_usuario: usuarioActual() } : x)), []); }
      toast((ids.length === 1 ? 'Habitación ' + nombreHab(ids[0]) + ' bloqueada' : ids.length + ' habitaciones bloqueadas') + ' del ' + fecha(this.desde) + ' al ' + fecha(this.hasta) + (marcadas.length ? ' · en mantenimiento desde ahora' : ''), 'ok');
      this.$emit('listo', { regs, marcadas });
    },
  },
  template: `
  <Modal title="Bloquear habitaciones" lg @close="$emit('cerrar')">
    <p class="small muted" style="margin:0 0 10px">Para mantenimiento, remodelación o uso interno: las habitaciones marcadas no se podrán reservar esas noches. Se guardan todas juntas: si alguna ya no está libre, no se bloquea ninguna.</p>
    <div class="grid cols-2">
      <Field label="Desde" req><input type="date" v-model="desde"></Field><Field label="Hasta (día en que vuelven a estar disponibles)" req><input type="date" v-model="hasta"></Field>
      <Field label="Motivo"><select v-model="motivo_tipo"><option v-for="m in MOTIVOS_BLOQUEO" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
      <Field label="Detalle" help="Opcional; se ve en el calendario. Por ejemplo: Remodelación piso 2, pintura, uso del dueño."><input v-model="motivo" maxlength="60"></Field>
    </div>
    <div class="alert warn" v-if="!fechasOk" style="margin:10px 0 0">Revise las fechas: la fecha final debe ser posterior a la inicial.</div>
    <template v-else>
      <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0 6px"><b>Habitaciones libres en esas fechas</b><span class="small muted">{{elegidas.length}} de {{libres.length}} marcadas</span><span style="flex:1"></span>
        <button type="button" class="btn sm ghost" @click="marcarGrupo(idsLibres, true)" :disabled="!libres.length">Todas</button><button type="button" class="btn sm ghost" @click="marcarGrupo(idsLibres, false)" :disabled="!sel.length">Ninguna</button></div>
      <div class="row" style="gap:6px 16px;flex-wrap:wrap;margin-bottom:8px" v-if="cats.length > 1"><label v-for="c in cats" :key="c.id" class="row small" style="gap:5px;cursor:pointer"><input type="checkbox" :checked="todasDe(c.ids)" @change="marcarGrupo(c.ids, $event.target.checked)"> Todas las libres de {{c.nombre}} ({{c.ids.length}})</label></div>
      <p class="small muted" v-if="!libres.length" style="margin:0">No hay habitaciones libres todas esas noches.</p>
      <div v-for="p in pisos" :key="p.piso" style="border-top:1px solid var(--line);padding:8px 0">
        <label class="row small" style="gap:6px;cursor:pointer;font-weight:600"><input type="checkbox" :checked="todasDe(p.ids)" @change="marcarGrupo(p.ids, $event.target.checked)"> Piso {{p.piso}} <span class="muted" style="font-weight:400">· {{p.ids.length}} libre(s)</span></label>
        <div v-for="c in p.cats" :key="c.id" class="row" style="gap:6px 16px;flex-wrap:wrap;align-items:center;margin:6px 0 0 22px"><span class="small muted" style="min-width:120px">{{c.nombre}}</span>
          <label v-for="h in c.habs" :key="h.id" class="row" style="gap:5px;cursor:pointer"><input type="checkbox" :value="h.id" v-model="sel"> <b>{{h.numero}}</b><span class="small muted" v-if="h.estado === 'mantenimiento'">en mantenimiento</span></label></div>
      </div>
      <div class="alert warn" v-if="sobreventa.length" style="margin:10px 0 0">Con este bloqueo quedarían reservas sin habitación disponible: <span v-for="(s, i) in sobreventa" :key="s.cat">{{i ? '; ' : ''}}<b>{{s.cat}}</b>, {{s.faltan}} de más el {{fecha(s.fecha)}}{{s.noches > 1 ? ' y ' + (s.noches - 1) + ' noche(s) más' : ''}}</span>. Son reservas que todavía no tienen habitación asignada. Puede bloquear de todos modos y reubicarlas después.</div>
    </template>
    <div style="margin-top:12px" v-if="cubreHoy"><Toggle v-model="marcar" label="Además marcarlas en mantenimiento"></Toggle>
      <div class="small muted" style="margin-top:4px">El bloqueo empieza hoy: las habitaciones pasan ya al estado «Mantenimiento». Cuando termine el trabajo hay que liberarlas en Mantenimiento › Habitaciones fuera de servicio.</div></div>
    <template #foot><button class="btn ghost" @click="$emit('cerrar')">Cancelar</button><button class="btn" :disabled="guardando || !fechasOk || !elegidas.length" @click="guardar">{{elegidas.length > 1 ? 'Bloquear ' + elegidas.length + ' habitaciones' : 'Bloquear'}}</button></template>
  </Modal>`,
};

// Cuadro de un bloqueo ya creado: lo muestra y lo quita. Si se creó en un lote, ofrece quitar solo esa habitación o todas las del lote.
export const QuitarBloqueo = {
  props: { bloqueo: Object, lista: Array, puede: { type: Boolean, default: true } },
  emits: ['listo', 'cerrar'],
  data() { return { guardando: false }; },
  computed: {
    lote() { return bloqueosDeLote(this.bloqueo.lote, this.lista || reservas()); },
    numerosLote() { return this.lote.map(x => nombreHab(x.habitacion_id)).sort((a, b) => a.localeCompare(b, 'es', { numeric: true })).join(', '); },
    tipoTxt() { return nombreMotivoBloqueo(this.bloqueo.motivo_tipo); },
  },
  methods: {
    nombreHab, fecha,
    async quitar(todoElLote) {
      const ids = todoElLote ? this.lote.map(x => x.id) : [this.bloqueo.id];
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const ok = await quitarBloqueos(ids);
      this.guardando = false;
      if (ok) { toast(ids.length > 1 ? 'Se quitaron los ' + ids.length + ' bloqueos del lote' : 'Bloqueo quitado', 'ok'); this.$emit('listo', ids); }
    },
  },
  template: `
  <Modal :title="'Bloqueo · habitación ' + nombreHab(bloqueo.habitacion_id)" @close="$emit('cerrar')">
    <p style="margin:0 0 6px"><b>{{bloqueo.motivo || 'Bloqueo'}}</b><span class="muted" v-if="tipoTxt && tipoTxt !== bloqueo.motivo"> · {{tipoTxt}}</span></p>
    <p class="small muted" style="margin:0">Del {{fecha(bloqueo.llegada)}} al {{fecha(bloqueo.salida)}} (el día en que vuelve a estar disponible){{bloqueo.usuario ? ' · lo creó ' + bloqueo.usuario : ''}}.</p>
    <p class="small" v-if="lote.length > 1" style="margin:10px 0 0">Se bloqueó junto con otras: es un lote de <b>{{lote.length}} habitaciones</b> ({{numerosLote}}). ¿Quitar solo esta habitación o las {{lote.length}} del lote?</p>
    <template #foot><button class="btn ghost" @click="$emit('cerrar')">{{puede ? 'Cancelar' : 'Cerrar'}}</button>
      <template v-if="puede"><button class="btn danger" v-if="lote.length > 1" :disabled="guardando" @click="quitar(true)">Quitar las {{lote.length}} del lote</button><button class="btn" :class="lote.length > 1 ? 'sec' : 'danger'" :disabled="guardando" @click="quitar(false)">{{lote.length > 1 ? 'Quitar solo esta' : 'Quitar el bloqueo'}}</button></template></template>
  </Modal>`,
};
