// Hotel › Reservaciones › Grupos y rooming list (3.0): varias habitaciones bajo un mismo responsable. Se crean todas de una vez
// (lista de habitaciones con sus personas y nombres), se cambian en bloque (fechas, precio por noche, estado) y se imprimen las
// tarjetas de registro y la rooming list. La cuenta maestra y el check-out del grupo ya existen en Recepción.
import { toast, money, fecha, sumarDias, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { config, hotelActivo, reservas, esEstadia, categorias, habitaciones, disponibles, cotizar, nuevoNumero, reservaNueva, guardarReserva, cambiarReserva, anotar, noches, nombreHab, nombreCat, ORIGENES, segmentos, folioDe, totalesFolio, ESTADOS, abrirHoja, encabezadoHoja, tarjetaRegistroHTML, huesped, nombreHuesped, buscarHuespedes, huespedNuevo, guardarHuesped, sincronizarHospedaje, capacidadHab, capacidadCat, r2, agencias, agenciaDe, hoyHotel, vuelosTexto } from './_datos.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export default {
  props: ['params'],
  data() { return { cfg: config(), lista: reservas(), q: '', form: null, cambio: null, ORIGENES, segs: segmentos(), activo: hotelActivo(), guardando: false, verGrupo: this.params.grupo || null }; },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    cats() { return categorias(); },
    clientes() { return (store.clientes || []).filter(c => c.activo !== false); },
    grupos() {
      const m = {}, q = this.q.trim().toLowerCase();
      for (const r of this.lista.filter(r => esEstadia(r) && (r.grupo || '').trim())) { const k = r.grupo.trim(); (m[k] = m[k] || []).push(r); }
      return Object.entries(m).map(([nombre, rs]) => { const vig = rs.filter(r => ['pendiente', 'confirmada', 'en_casa'].includes(r.estado)); const t = rs.map(r => totalesFolio(folioDe(r.id))); return { nombre, rs: rs.slice().sort((a, b) => nombreHab(a.habitacion_id).localeCompare(nombreHab(b.habitacion_id), 'es', { numeric: true })), n: rs.length, vigentes: vig.length, llegada: rs.map(r => r.llegada).sort()[0], salida: rs.map(r => r.salida).sort().slice(-1)[0], personas: rs.reduce((s, r) => s + (+r.adultos || 0) + (+r.ninos || 0), 0), total: r2(rs.reduce((s, r) => s + (+r.total || 0), 0)), pagado: r2(t.reduce((s, x) => s + x.pagos, 0)), saldo: r2(rs.reduce((s, r, i) => s + (r.estado === 'en_casa' ? t[i].saldo : Math.max(0, (+r.total || 0) - t[i].pagos)), 0)), moneda: rs[0].moneda, estados: [...new Set(rs.map(r => ESTADOS[r.estado] || r.estado))].join(', '), responsable: rs.find(r => r.grupo_lider) || rs[0] }; })
        .filter(g => !q || g.nombre.toLowerCase().includes(q) || g.rs.some(r => String(r.huesped_nombre || '').toLowerCase().includes(q)))
        .sort((a, b) => (b.vigentes - a.vigentes) || String(b.llegada).localeCompare(String(a.llegada)));
    },
    grupoSel() { return this.verGrupo ? this.grupos.find(g => g.nombre === this.verGrupo) || null : null; },
    agenciasLista() { return agencias().filter(a => a.activo !== false); },
    cotForm() { if (!this.form) return null; const ag = this.form.agencia_id ? agenciaDe(this.form.agencia_id) : null; return this.form.filas.map(l => cotizar({ categoria_id: l.categoria_id, llegada: this.form.llegada, salida: this.form.salida, plan_id: this.form.plan_id, personas: (+l.adultos || 0) + (+l.ninos || 0), precio_manual: this.form.precio_manual, capacidad: l.habitacion_id ? capacidadHab(habitaciones().find(h => h.id === l.habitacion_id)) : capacidadCat(l.categoria_id), agencia: ag }, this.cfg)); },
    totalForm() { return r2((this.cotForm || []).reduce((s, c) => s + c.total, 0)); },
  },
  methods: {
    money, fecha, nombreHab, nombreCat, noches,
    refrescar() { this.lista = reservas(); },
    nuevo() { this.form = { nombre: '', responsable: '', cliente_id: null, agencia_id: null, llegada: hoyHotel(), salida: sumarDias(hoyHotel(), 2), origen: 'agencia', segmento: 'Grupo', plan_id: (this.cfg.planes[0] || {}).id || 1, precio_manual: null, notas: '', vuelo_llegada: '', hora_vuelo_llegada: '', vuelo_salida: '', hora_vuelo_salida: '', filas: [this.filaNueva(), this.filaNueva()] }; },
    filaNueva() { const c = this.cats[0]; return { categoria_id: c ? c.id : null, habitacion_id: null, adultos: 2, ninos: 0, nombre: '' }; },
    habsPara(l) { if (!this.form) return []; const usadas = new Set(this.form.filas.filter(x => x !== l && x.habitacion_id).map(x => x.habitacion_id)); return disponibles(l.categoria_id, this.form.llegada, this.form.salida).filter(h => !usadas.has(h.id)); },
    asignarTodas() { for (const l of this.form.filas) if (!l.habitacion_id) { const h = this.habsPara(l)[0]; if (h) l.habitacion_id = h.id; } },
    async crear() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Indique el nombre del grupo', 'err'); if (!f.llegada || !f.salida || f.salida <= f.llegada) return toast('Revise las fechas', 'err');
      const filas = f.filas.filter(l => l.categoria_id); if (!filas.length) return toast('Agregue al menos una habitación', 'err');
      const usadas = filas.filter(l => l.habitacion_id).map(l => l.habitacion_id); if (new Set(usadas).size !== usadas.length) return toast('Hay una habitación repetida', 'err');
      for (const l of filas) if (l.habitacion_id && !this.habsPara(l).some(h => h.id === l.habitacion_id)) return toast('La habitación ' + nombreHab(l.habitacion_id) + ' no está libre esas noches', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true; const creadas = [];
      try {
        for (let i = 0; i < filas.length; i++) {
          const l = filas[i], cot = this.cotForm[f.filas.indexOf(l)] || cotizar({ categoria_id: l.categoria_id, llegada: f.llegada, salida: f.salida, plan_id: f.plan_id, personas: (+l.adultos || 0) + (+l.ninos || 0), precio_manual: f.precio_manual, agencia: f.agencia_id ? agenciaDe(f.agencia_id) : null }, this.cfg);
          const nombre = (l.nombre || '').trim() || (f.responsable || f.nombre).trim() + (filas.length > 1 ? ' (' + (i + 1) + ')' : '');
          let hid = null; const existentes = buscarHuespedes(nombre); if (existentes.length === 1 && nombreHuesped(existentes[0]).toLowerCase() === nombre.toLowerCase()) hid = existentes[0].id; else { const partes = nombre.split(' '); const h = guardarHuesped({ ...huespedNuevo(), nombre: partes[0], apellidos: partes.slice(1).join(' ') }); hid = h ? h.id : null; }
          const r = { ...reservaNueva(this.cfg), numero: nuevoNumero(this.cfg), estado: 'confirmada', huesped_id: hid, huesped_nombre: nombre, adultos: +l.adultos || 1, ninos: +l.ninos || 0, llegada: f.llegada, salida: f.salida, categoria_id: l.categoria_id, habitacion_id: l.habitacion_id || null, plan_id: f.plan_id, precio_manual: f.precio_manual, tarifa_noche: cot.promedio, noches: cot.noches, neto: cot.neto, iva: cot.iva, total: cot.total, moneda: cot.moneda, origen: f.origen, segmento: f.segmento, cliente_id: f.cliente_id || null, agencia_id: f.agencia_id || null, grupo: f.nombre.trim(), grupo_lider: i === 0, notas: f.notas || '', vuelo_llegada: (f.vuelo_llegada || '').trim(), hora_vuelo_llegada: f.hora_vuelo_llegada || '', vuelo_salida: (f.vuelo_salida || '').trim(), hora_vuelo_salida: f.hora_vuelo_salida || '' };   // H8: los vuelos del grupo van en cada reserva
          const { reg, promesa } = guardarReserva(anotar(r, 'Reserva creada con el grupo ' + f.nombre.trim()));
          if (!(await promesa)) break; creadas.push(reg);
        }
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false; this.refrescar();
      if (creadas.length) { toast(creadas.length + ' reserva(s) creada(s) para el grupo ' + f.nombre.trim(), 'ok'); this.verGrupo = f.nombre.trim(); this.form = null; }
    },
    abrirCambio(g) { this.cambio = { grupo: g.nombre, llegada: g.llegada, salida: g.salida, precio_manual: null, aplicarPrecio: false, estado: '' }; },
    async confirmarCambio() {
      const c = this.cambio, g = this.grupos.find(x => x.nombre === c.grupo); if (!g) return;
      if (!c.llegada || !c.salida || c.salida <= c.llegada) return toast('Revise las fechas', 'err');
      if (!mock.puedeGuardar()) return;
      let n = 0;
      for (const r of g.rs.filter(r => ['pendiente', 'confirmada', 'en_casa'].includes(r.estado))) {
        const cambios = {}, textos = [];
        if (c.llegada !== r.llegada || c.salida !== r.salida) { if (r.estado === 'en_casa') { cambios.salida = c.salida; } else { cambios.llegada = c.llegada; cambios.salida = c.salida; } textos.push('fechas ' + fecha(cambios.llegada || r.llegada) + ' al ' + fecha(cambios.salida || r.salida)); }
        if (c.aplicarPrecio && +c.precio_manual > 0) { cambios.precio_manual = +c.precio_manual; textos.push('precio por noche ' + money(+c.precio_manual, r.moneda)); }
        if (c.estado && c.estado !== r.estado && r.estado !== 'en_casa') { cambios.estado = c.estado; textos.push(ESTADOS[c.estado]); }
        if (!textos.length) continue;
        const nr = { ...r, ...cambios }; const cot = cotizar({ categoria_id: nr.categoria_id, llegada: nr.llegada, salida: nr.salida, plan_id: nr.plan_id, personas: (+nr.adultos || 0) + (+nr.ninos || 0), precio_manual: nr.precio_manual }, this.cfg);
        if (nr.habitacion_id && !disponibles(null, nr.llegada, nr.salida, r.id).some(h => h.id === nr.habitacion_id)) { toast('Hab. ' + nombreHab(nr.habitacion_id) + ' (' + r.numero + ') no está libre en las fechas nuevas; esa reserva no se cambió', 'err'); continue; }
        const { reg, promesa } = cambiarReserva(r.id, x => anotar({ ...x, ...cambios, tarifa_noche: cot.promedio, noches: cot.noches, neto: cot.neto, iva: cot.iva, total: cot.total }, 'Cambio del grupo: ' + textos.join(', ')));
        if (await promesa) { n++; if (reg.estado === 'en_casa') sincronizarHospedaje(reg, this.cfg); }
      }
      this.cambio = null; this.refrescar(); toast(n + ' reserva(s) del grupo actualizada(s)', 'ok');
    },
    tarjetas(g) { abrirHoja('Tarjetas de registro · ' + g.nombre, g.rs.map(r => tarjetaRegistroHTML(r, r.huesped_id ? huesped(r.huesped_id) : null)).join('<div style="page-break-after:always"></div>')); },
    roomingList(g) {
      const filas = g.rs.map(r => '<tr><td>' + esc(r.numero) + '</td><td>' + esc(nombreHab(r.habitacion_id)) + '</td><td>' + esc(nombreCat(r.categoria_id)) + '</td><td>' + esc(r.huesped_nombre) + '</td><td class="n">' + ((+r.adultos || 0) + (+r.ninos || 0)) + '</td><td>' + esc(fecha(r.llegada)) + '</td><td>' + esc(fecha(r.salida)) + '</td><td>' + esc(vuelosTexto(r)) + '</td><td>' + esc(ESTADOS[r.estado] || r.estado) + '</td><td class="n">' + esc(money(r.total || 0, r.moneda)) + '</td></tr>').join('');
      abrirHoja('Rooming list · ' + g.nombre, encabezadoHoja('Rooming list · ' + g.nombre) + '<div class="muted">' + esc(fecha(g.llegada) + ' al ' + fecha(g.salida) + ' · ' + g.n + ' habitación(es) · ' + g.personas + ' persona(s)') + '</div><table style="margin-top:10px"><thead><tr><th>Reserva</th><th>Hab.</th><th>Categoría</th><th>Huésped</th><th class="n">Pers.</th><th>Llegada</th><th>Salida</th><th>Vuelo</th><th>Estado</th><th class="n">Total</th></tr></thead><tbody>' + filas + '</tbody><tbody class="tot"><tr><td colspan="9">Total del grupo</td><td class="n">' + esc(money(g.total, g.moneda)) + '</td></tr></tbody></table>');
    },
  },
  template: `
  <div class="page">
    <PageHead title="Grupos y rooming list" sub="Varias habitaciones bajo un mismo responsable: se crean de una vez, se cambian en bloque y se facturan con la cuenta maestra en Recepción." :crumbs="[{label:'Hotel'},{label:'Reservaciones',to:'/hotel/reservaciones'},{label:'Grupos'}]">
      <button class="btn" @click="nuevo" v-if="puedeEscribir && cats.length">+ Grupo</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="👥" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="card"><div class="toolbar"><input class="search" placeholder="Buscar grupo o huésped" v-model="q"></div>
      <Empty v-if="!grupos.length" icon="👥" title="Sin grupos" text="Cree uno con «+ Grupo» o escriba el mismo nombre de grupo en varias reservas."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Grupo</th><th>Responsable</th><th class="num">Hab.</th><th class="num">Pers.</th><th>Llegada</th><th>Salida</th><th>Estados</th><th class="num">Total</th><th class="num">Pagado</th><th class="num">Saldo</th><th></th></tr></thead>
        <tbody><tr v-for="g in grupos" :key="g.nombre" :class="{sel: verGrupo===g.nombre}" style="cursor:pointer" @click="verGrupo = verGrupo===g.nombre ? null : g.nombre"><td><b>{{g.nombre}}</b></td><td>{{g.responsable.huesped_nombre}}</td><td class="num">{{g.n}}</td><td class="num">{{g.personas}}</td><td>{{fecha(g.llegada)}}</td><td>{{fecha(g.salida)}}</td><td class="small">{{g.estados}}</td><td class="num">{{money(g.total, g.moneda)}}</td><td class="num">{{money(g.pagado, g.moneda)}}</td><td class="num" :style="g.saldo > 0 ? 'color:var(--danger)' : ''">{{money(g.saldo, g.moneda)}}</td>
          <td style="white-space:nowrap"><button class="btn sm ghost" @click.stop="roomingList(g)">Rooming list</button><button class="btn sm ghost" @click.stop="tarjetas(g)">Tarjetas</button><button class="btn sm ghost" v-if="puedeEscribir && g.vigentes" @click.stop="abrirCambio(g)">Cambiar en bloque</button></td></tr></tbody></table></div>
    </div>
    <div class="card" v-if="grupoSel"><h2>{{grupoSel.nombre}} <small>{{grupoSel.n}} habitación(es) · {{fecha(grupoSel.llegada)}} al {{fecha(grupoSel.salida)}}</small></h2>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Reserva</th><th>Hab.</th><th>Categoría</th><th>Huésped</th><th class="num">Pers.</th><th>Llegada</th><th>Salida</th><th>Estado</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="r in grupoSel.rs" :key="r.id"><td class="mono">{{r.numero}}<span class="badge" v-if="r.grupo_lider" style="margin-left:4px">responsable</span></td><td>{{nombreHab(r.habitacion_id)}}</td><td>{{nombreCat(r.categoria_id)}}</td><td>{{r.huesped_nombre}}</td><td class="num">{{(+r.adultos||0)+(+r.ninos||0)}}</td><td>{{fecha(r.llegada)}}</td><td>{{fecha(r.salida)}}</td><td><Badge :value="ESTADOS[r.estado]"></Badge></td><td class="num">{{money(r.total, r.moneda)}}</td><td style="white-space:nowrap"><a class="btn sm ghost" :href="'#/hotel/reservaciones/' + r.id">Reserva</a><a class="btn sm ghost" :href="'#/hotel/recepcion?reserva=' + r.id">Cuenta</a></td></tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0">El check-out del grupo con una sola factura (cuenta maestra) se hace en Recepción desde cualquier habitación del grupo que esté en casa.</p>
    </div>
    </template>

    <Modal v-if="form" title="Nuevo grupo (rooming list)" lg @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre del grupo" req><input v-model="form.nombre" maxlength="60" placeholder="Colegio Verde · excursión"></Field>
        <Field label="Responsable" help="Nombre del encargado; se usa si una habitación no tiene nombre"><input v-model="form.responsable" maxlength="80"></Field>
        <Field label="Llegada" req><input type="date" v-model="form.llegada"></Field><Field label="Salida" req><input type="date" v-model="form.salida" :min="form.llegada"></Field>
        <Field label="Origen"><select v-model="form.origen"><option v-for="o in ORIGENES" :key="o[0]" :value="o[0]">{{o[1]}}</option></select></Field>
        <Field label="Segmento"><select v-model="form.segmento"><option value="">— Sin segmento —</option><option v-for="s in segs" :key="s" :value="s">{{s}}</option></select></Field>
        <Field label="Plan"><select v-model="form.plan_id"><option v-for="p in cfg.planes" :key="p.id" :value="p.id">{{p.nombre}}</option></select></Field>
        <Field label="Precio por noche acordado" help="Vacío = según tarifas y temporada"><input type="number" min="0" step="0.01" v-model.number="form.precio_manual"></Field>
        <Field label="Contacto para facturar (opcional)"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Ninguno" agregar="cliente"></Buscador></Field>
        <Field label="Agencia o empresa con contrato" v-if="agenciasLista.length"><Buscador v-model="form.agencia_id" :opciones="agenciasLista" :detalle="a => a.tipo === 'empresa' ? 'empresa' : 'agencia'" placeholder="Sin contrato" agregar="agencia"></Buscador></Field>
        <Field label="Notas"><input v-model="form.notas" maxlength="160"></Field>
        <Field label="Vuelo de llegada del grupo" help="Número y hora; se copia a cada reserva"><div class="row" style="gap:6px;flex-wrap:nowrap"><input v-model="form.vuelo_llegada" maxlength="12" placeholder="AV 641" style="flex:1;min-width:0"><input type="time" v-model="form.hora_vuelo_llegada" style="width:130px"></div></Field>
        <Field label="Vuelo de salida del grupo"><div class="row" style="gap:6px;flex-wrap:nowrap"><input v-model="form.vuelo_salida" maxlength="12" placeholder="AV 642" style="flex:1;min-width:0"><input type="time" v-model="form.hora_vuelo_salida" style="width:130px"></div></Field>
      </div>
      <div class="row" style="justify-content:space-between;margin:12px 0 6px"><b>Habitaciones</b><div class="row" style="gap:6px"><button class="btn sm ghost" @click="asignarTodas">Asignar libres automáticamente</button><button class="btn sm sec" @click="form.filas.push(filaNueva())">+ Habitación</button></div></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Categoría</th><th>Habitación</th><th class="num">Adultos</th><th class="num">Niños</th><th>Nombre del huésped</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="(l, i) in form.filas" :key="i"><td><select class="inp" v-model="l.categoria_id" @change="l.habitacion_id=null"><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select></td><td><select class="inp" v-model="l.habitacion_id"><option :value="null">Asignar al llegar</option><option v-for="h in habsPara(l)" :key="h.id" :value="h.id">{{h.numero}}</option></select></td><td class="num"><input class="inp" type="number" min="1" v-model.number="l.adultos" style="width:64px"></td><td class="num"><input class="inp" type="number" min="0" v-model.number="l.ninos" style="width:64px"></td><td><input class="inp" v-model="l.nombre" maxlength="80" style="width:100%" placeholder="Vacío = responsable"></td><td class="num">{{cotForm && cotForm[i] ? money(cotForm[i].total, cfg.moneda) : ''}}</td><td><button class="btn icon" @click="form.filas.splice(i,1)" v-if="form.filas.length>1">✕</button></td></tr></tbody>
        <tbody><tr class="tot"><td colspan="5">Total del grupo · {{noches(form.llegada, form.salida)}} noche(s)</td><td class="num">{{money(totalForm, cfg.moneda)}}</td><td></td></tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0">Se crea una reserva confirmada por habitación con el mismo nombre de grupo. Las habitaciones sin nombre quedan a nombre del responsable.</p>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="crear" :disabled="guardando">{{guardando ? 'Creando…' : 'Crear ' + form.filas.filter(l=>l.categoria_id).length + ' reserva(s)'}}</button></template>
    </Modal>
    <Modal v-if="cambio" :title="'Cambiar en bloque · ' + cambio.grupo" @close="cambio=null">
      <div class="grid cols-2">
        <Field label="Llegada" help="No cambia para las que ya están en casa"><input type="date" v-model="cambio.llegada"></Field><Field label="Salida"><input type="date" v-model="cambio.salida" :min="cambio.llegada"></Field>
        <Field label="Estado" help="Solo para las que no han llegado"><select v-model="cambio.estado"><option value="">— Sin cambio —</option><option value="confirmada">Confirmada</option><option value="pendiente">Pendiente de adelanto</option><option value="cancelada">Cancelada</option></select></Field>
        <Field label="Precio por noche acordado"><div class="row" style="gap:6px"><input type="checkbox" v-model="cambio.aplicarPrecio"><input type="number" min="0" step="0.01" v-model.number="cambio.precio_manual" :disabled="!cambio.aplicarPrecio" style="flex:1"></div></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Se aplica a todas las reservas vigentes del grupo; si una habitación no está libre en las fechas nuevas, esa reserva no se cambia y se avisa.</p>
      <template #foot><button class="btn ghost" @click="cambio=null">Cancelar</button><button class="btn" @click="confirmarCambio">Aplicar al grupo</button></template>
    </Modal>
  </div>`,
  setup() { return { ESTADOS }; },
};
