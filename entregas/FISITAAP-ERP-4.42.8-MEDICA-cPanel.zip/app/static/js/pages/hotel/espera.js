// Hotel › Lista de espera (3.22): cuando no hay habitación para las fechas que pide alguien, se anota con su categoría,
// fechas y teléfono. La lista revisa sola si ya hay disponibilidad (por cancelaciones o salidas anticipadas), avisa por
// WhatsApp con un toque y crea la reserva con los datos ya puestos. Registro `hotel_espera`.
import { toast, fecha, hoy, sumarDias, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { config, hotelActivo, categorias, nombreCat, disponibles, esperas, noches, enlaceWhatsApp, usuarioActual, hoyHotel } from './_datos.js';

const ESTADOS_ESPERA = { espera: 'En espera', avisado: 'Avisado', reservado: 'Reservó', descartado: 'Descartado' };

export default {
  props: ['params'],
  data() {
    const p = this.params || {};
    const nuevo = p.nuevo ? { id: null, nombre: p.nombre || '', telefono: '', correo: '', categoria_id: p.categoria ? +p.categoria : null, llegada: p.llegada || hoyHotel(), salida: p.salida || sumarDias(p.llegada || hoyHotel(), 1), personas: 2, notas: '', estado: 'espera' } : null;
    return { cfg: config(), lista: esperas(), form: nuevo, filtro: 'espera', activo: hotelActivo(), cats: categorias(), ESTADOS_ESPERA };
  },
  computed: {
    puedeEscribir() { return ['escribir', 'pos', 'cobros', 'facturar'].some(p => sesion.puede(p)); },
    filas() {
      const h = hoyHotel();
      return this.lista.map(x => { const vieja = x.salida < h, disp = !vieja && x.categoria_id ? disponibles(x.categoria_id, x.llegada, x.salida, null).length : 0; return { ...x, disp, vieja, noches: noches(x.llegada, x.salida) }; })
        .filter(x => this.filtro === 'todas' || (this.filtro === 'espera' ? ['espera', 'avisado'].includes(x.estado) && !x.vieja : x.estado === this.filtro))
        .sort((a, b) => (b.disp > 0) - (a.disp > 0) || String(a.llegada).localeCompare(String(b.llegada)));
    },
    conDisponibilidad() { return this.lista.filter(x => ['espera', 'avisado'].includes(x.estado) && x.salida >= hoyHotel() && x.categoria_id && disponibles(x.categoria_id, x.llegada, x.salida, null).length > 0).length; },
  },
  methods: {
    fecha, nombreCat,
    nuevo() { this.form = { id: null, nombre: '', telefono: '', correo: '', categoria_id: this.cats.length === 1 ? this.cats[0].id : null, llegada: hoyHotel(), salida: sumarDias(hoyHotel(), 1), personas: 2, notas: '', estado: 'espera' }; },
    editar(x) { this.form = { ...x }; },
    guardar() {
      const f = this.form;
      if (!(f.nombre || '').trim()) return toast('Escriba el nombre', 'err');
      if (!f.categoria_id) return toast('Elija la categoría que pide', 'err');
      if (!f.llegada || !f.salida || f.salida <= f.llegada) return toast('Revise las fechas: la salida va después de la llegada', 'err');
      if (!mock.puedeGuardar()) return;
      this.lista = mock.actualizar('hotel_espera', l => { const lista = Array.isArray(l) ? l : []; const reg = { ...f, nombre: f.nombre.trim(), personas: +f.personas || 1 }; if (reg.id) return lista.map(x => (x.id === reg.id ? reg : x)); return [...lista, { ...reg, id: mock.nextId(lista, 'hotel_espera'), creado: new Date().toISOString(), usuario: usuarioActual() }]; }, []);
      this.form = null; toast('Anotado en la lista de espera', 'ok');
    },
    marcar(x, estado) {
      if (!mock.puedeGuardar()) return;
      this.lista = mock.actualizar('hotel_espera', l => (l || []).map(y => (y.id === x.id ? { ...y, estado, [estado + '_en']: new Date().toISOString() } : y)), []);
    },
    textoAviso(x) { return 'Hola ' + x.nombre + ', le escribe ' + (this.cfg.nombre || 'el hotel') + '. Se liberó una habitación ' + nombreCat(x.categoria_id) + ' del ' + fecha(x.llegada) + ' al ' + fecha(x.salida) + '. ¿Desea que la reservemos a su nombre?'; },
    avisar(x) { if (x.estado === 'espera') this.marcar(x, 'avisado'); window.open(enlaceWhatsApp(x.telefono, this.textoAviso(x)), '_blank', 'noopener'); },
    reservar(x) { this.marcar(x, 'reservado'); location.hash = '#/hotel/reservaciones/nueva?espera=' + x.id + '&categoria=' + (x.categoria_id || '') + '&llegada=' + x.llegada + '&salida=' + x.salida + '&adultos=' + (+x.personas || 1) + '&nombre=' + encodeURIComponent(x.nombre || ''); },
    quitar(x) { if (!confirm('¿Quitar a «' + x.nombre + '» de la lista de espera?')) return; if (!mock.puedeGuardar()) return; this.lista = mock.actualizar('hotel_espera', l => (l || []).filter(y => y.id !== x.id), []); },
  },
  template: `
  <div class="page">
    <PageHead title="Lista de espera" :sub="activo ? (conDisponibilidad ? conDisponibilidad + ' con habitación disponible ahora · ' : '') + lista.filter(x => ['espera','avisado'].includes(x.estado)).length + ' en espera' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Reservaciones'},{label:'Lista de espera'}]">
      <button class="btn" @click="nuevo" v-if="puedeEscribir && activo">+ Anotar</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛏" title="El hotel no está configurado"></Empty></div>
    <template v-else>
      <div class="alert ok" v-if="conDisponibilidad">Hay {{conDisponibilidad}} persona(s) en espera para fechas que ya tienen habitación libre: avísele por WhatsApp y cree la reserva.</div>
      <div class="seg" style="margin-bottom:10px"><button :class="{on: filtro==='espera'}" @click="filtro='espera'">En espera</button><button :class="{on: filtro==='reservado'}" @click="filtro='reservado'">Reservaron</button><button :class="{on: filtro==='descartado'}" @click="filtro='descartado'">Descartados</button><button :class="{on: filtro==='todas'}" @click="filtro='todas'">Todas</button></div>
      <Empty v-if="!filas.length" icon="⏳" title="Nadie en espera" text="Cuando no haya habitación para unas fechas, anote aquí a la persona: la lista avisa cuando se libere una."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Persona</th><th>Pide</th><th>Fechas</th><th>Disponibilidad</th><th>Estado</th><th></th></tr></thead><tbody>
        <tr v-for="x in filas" :key="x.id">
          <td><b>{{x.nombre}}</b><div class="small muted">{{x.telefono || '—'}}{{x.correo ? ' · ' + x.correo : ''}}</div></td>
          <td>{{nombreCat(x.categoria_id)}}<div class="small muted">{{x.personas}} persona(s){{x.notas ? ' · ' + x.notas : ''}}</div></td>
          <td>{{fecha(x.llegada)}} al {{fecha(x.salida)}}<div class="small muted">{{x.noches}} noche(s)</div></td>
          <td><span class="badge ok" v-if="x.disp > 0">{{x.disp}} libre(s) ahora</span><span class="badge" v-else-if="x.vieja">Fechas pasadas</span><span class="badge warn" v-else>Sin habitación</span></td>
          <td><span class="badge" :class="x.estado==='reservado' ? 'ok' : x.estado==='avisado' ? 'info' : ''">{{ESTADOS_ESPERA[x.estado] || x.estado}}</span></td>
          <td class="num" style="white-space:nowrap">
            <button class="btn sm sec" v-if="puedeEscribir && x.telefono && ['espera','avisado'].includes(x.estado)" @click="avisar(x)" title="Abre WhatsApp con el aviso">WhatsApp</button>
            <button class="btn sm" v-if="puedeEscribir && ['espera','avisado'].includes(x.estado)" @click="reservar(x)">Crear la reserva</button>
            <button class="btn sm ghost" v-if="puedeEscribir && ['espera','avisado'].includes(x.estado)" @click="marcar(x,'descartado')">Descartar</button>
            <button class="btn sm ghost" v-if="puedeEscribir" @click="editar(x)">Editar</button>
            <button class="btn icon" v-if="puedeEscribir" @click="quitar(x)" title="Quitar">✕</button>
          </td>
        </tr></tbody></table></div>
    </template>
    <Modal v-if="form" :title="form.id ? 'Lista de espera' : 'Anotar en la lista de espera'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre" req style="grid-column:1/-1"><input v-model="form.nombre" maxlength="80"></Field>
        <Field label="Teléfono (WhatsApp)"><input v-model="form.telefono" maxlength="20" placeholder="8888-8888"></Field>
        <Field label="Correo"><input type="email" v-model="form.correo" maxlength="120"></Field>
        <Field label="Categoría que pide" req><select v-model="form.categoria_id"><option :value="null">— Elegir —</option><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
        <Field label="Personas"><input type="number" min="1" max="30" v-model.number="form.personas"></Field>
        <Field label="Llegada" req><input type="date" v-model="form.llegada"></Field>
        <Field label="Salida" req><input type="date" v-model="form.salida" :min="form.llegada"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="160" placeholder="Flexible con las fechas, viene con niños…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};
