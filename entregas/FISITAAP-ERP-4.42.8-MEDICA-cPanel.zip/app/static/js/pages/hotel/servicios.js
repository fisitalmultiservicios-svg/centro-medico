// Hotel › Servicios (3.5): spa, tours, traslados y alquileres. Catálogo con precio, duración, horario, proveedor y comisión
// del hotel; agenda con hora, personas y la cuenta a la que se carga (huésped en casa, reserva confirmada, cuenta externa o
// cliente de paso); el cargo va a la cuenta al marcar el servicio como realizado (o al reservarlo, si se pide) y se factura con
// la cuenta. Liquidación a proveedores externos: lo cobrado, la comisión del hotel y lo que se le paga a cada uno por período.
// Registros: hotel_servicios (catálogo) y hotel_servicios_agenda (servicios reservados).
import { toast, money, fmt, fecha, fechaHora, hoy, sumarDias, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { config, hotelActivo, reservas, reserva, esEstadia, cuentasExternas, nuevaCuentaExterna, guardarReserva, nombreHab, usuarioActual, agregarFolio, quitarFolio, folios, convertirMonto, MONEDAS_HOTEL, TIPOS_SERVICIO, nombreTipoServicio, ESTADOS_SERVICIO, serviciosCatalogo, serviciosAgenda, cargoServicio, abrirHoja, encabezadoHoja, fechaLarga, r2, hoyHotel } from './_datos.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const CLASE = { reservado: 'info', realizado: 'ok', cancelado: '', no_show: 'danger' };
const EJEMPLOS = [
  { nombre: 'Masaje relajante 60 min', tipo: 'spa', precio: 70, duracion: 60, capacidad: 2, horario: '9:00 a 18:00' },
  { nombre: 'Tour al volcán (día completo)', tipo: 'tour', precio: 95, duracion: 480, capacidad: 12, horario: 'Salida 7:30' },
  { nombre: 'Traslado al aeropuerto', tipo: 'traslado', precio: 45, duracion: 90, capacidad: 4, horario: 'Reservar con 24 h' },
  { nombre: 'Alquiler de bicicleta (día)', tipo: 'alquiler', precio: 15, duracion: 480, capacidad: 6, horario: '8:00 a 17:00' },
];

export default {
  props: ['params'],
  data() {
    const h = hoyHotel();
    return { cfg: config(), tab: ['agenda', 'catalogo', 'proveedores'].includes(this.params.tab) ? this.params.tab : 'agenda', dia: this.params.fecha || h, catalogo: serviciosCatalogo(), agenda: serviciosAgenda(),
      q: '', form: null, serv: null, desde: h.slice(0, 8) + '01', hasta: h, conLiquidados: false, activo: hotelActivo(), TIPOS_SERVICIO, MONEDAS_HOTEL, ESTADOS_SERVICIO, guardando: false };
  },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    puedeCatalogo() { return sesion.puede('catalogos') || sesion.puede('configurar'); },
    proveedores() { return (store.clientes || []).filter(c => c.activo !== false && (c.tipo === 'Proveedor' || c.tipo === 'Ambos')).sort((a, b) => a.nombre.localeCompare(b.nombre)); },
    productos() { return (store.productos || []).filter(p => p.activo !== false && p.es_venta !== false); },   // sin insumos (3.18)
    catalogoOrdenado() { const q = this.q.trim().toLowerCase(); return this.catalogo.filter(s => !q || [s.nombre, nombreTipoServicio(s.tipo), s.proveedor_nombre].some(x => String(x || '').toLowerCase().includes(q))).slice().sort((a, b) => (a.activo === false) - (b.activo === false) || a.tipo.localeCompare(b.tipo) || a.nombre.localeCompare(b.nombre)); },
    catalogoActivo() { return this.catalogo.filter(s => s.activo !== false).slice().sort((a, b) => a.tipo.localeCompare(b.tipo) || a.nombre.localeCompare(b.nombre)); },
    // cuentas a las que se puede cargar: huéspedes en casa primero, luego reservas confirmadas o pendientes y cuentas externas abiertas
    cuentas() {
      const orden = { en_casa: 0, confirmada: 1, pendiente: 2 };
      const est = reservas().filter(r => esEstadia(r) && orden[r.estado] !== undefined).sort((a, b) => orden[a.estado] - orden[b.estado] || String(a.llegada).localeCompare(b.llegada))
        .map(r => ({ id: r.id, etiqueta: (r.estado === 'en_casa' ? 'Hab. ' + nombreHab(r.habitacion_id) : r.numero + ' (llega ' + fecha(r.llegada) + ')') + ' · ' + (r.huesped_nombre || 'Sin nombre') }));
      const ext = cuentasExternas().filter(r => r.estado === 'abierto').map(r => ({ id: r.id, etiqueta: r.numero + ' · ' + (r.huesped_nombre || 'Cuenta externa') }));
      return [...est, ...ext];
    },
    delDia() { return this.agenda.filter(a => a.fecha === this.dia).map(a => this.enriquecer(a)).sort((a, b) => String(a.hora || '').localeCompare(String(b.hora || '')) || a.id - b.id); },
    proximos() { const d1 = sumarDias(this.dia, 1), d7 = sumarDias(this.dia, 7); return this.agenda.filter(a => a.fecha >= d1 && a.fecha <= d7 && a.estado === 'reservado').map(a => this.enriquecer(a)).sort((a, b) => a.fecha.localeCompare(b.fecha) || String(a.hora || '').localeCompare(String(b.hora || ''))); },
    kpis() {
      const l = this.delDia, m = this.cfg.moneda;
      return { reservados: l.filter(a => a.estado === 'reservado').length, realizados: l.filter(a => a.estado === 'realizado').length, personas: l.filter(a => a.estado !== 'cancelado').reduce((s, a) => s + (+a.personas || 0), 0),
        ingresos: r2(l.filter(a => a.estado === 'realizado').reduce((s, a) => s + convertirMonto(a.total, a.moneda, m, this.cfg), 0)), proximos: this.proximos.length };
    },
    // liquidación: servicios realizados por proveedores externos en el período (por fecha del servicio)
    liquidacion() {
      const m = {}, mon = this.cfg.moneda;
      for (const a of this.agenda.filter(a => a.estado === 'realizado' && a.proveedor_id && a.fecha >= this.desde && a.fecha <= this.hasta && (this.conLiquidados || !a.liquidado))) {
        const o = m[a.proveedor_id] || (m[a.proveedor_id] = { proveedor_id: a.proveedor_id, proveedor: a.proveedor_nombre || 'Proveedor', n: 0, personas: 0, cobrado: 0, comision: 0, a_pagar: 0, items: [] });
        const cobrado = convertirMonto(a.total, a.moneda, mon, this.cfg), comision = r2(cobrado * (+a.comision_pct || 0) / 100);
        o.n++; o.personas += +a.personas || 0; o.cobrado = r2(o.cobrado + cobrado); o.comision = r2(o.comision + comision); o.a_pagar = r2(o.a_pagar + cobrado - comision);
        o.items.push({ ...this.enriquecer(a), cobrado, comision, a_pagar: r2(cobrado - comision) });
      }
      return Object.values(m).sort((a, b) => b.a_pagar - a.a_pagar);
    },
    totalLiq() { return { n: this.liquidacion.reduce((s, p) => s + p.n, 0), cobrado: r2(this.liquidacion.reduce((s, p) => s + p.cobrado, 0)), comision: r2(this.liquidacion.reduce((s, p) => s + p.comision, 0)), a_pagar: r2(this.liquidacion.reduce((s, p) => s + p.a_pagar, 0)) }; },
    totalForm() { return this.form ? r2((+this.form.precio || 0) * (+this.form.personas || 1)) : 0; },
    servForm() { return this.form ? this.catalogo.find(s => s.id === this.form.servicio_id) || null : null; },
  },
  methods: {
    money, fmt, fecha, fechaHora, nombreTipoServicio, nombreHab,
    M(v, mon) { return money(v || 0, mon || this.cfg.moneda); },
    clase(e) { return 'badge ' + (CLASE[e] || ''); },
    refrescar() { this.catalogo = serviciosCatalogo(); this.agenda = serviciosAgenda(); },
    cambiarDia(n) { this.dia = sumarDias(this.dia, n); },
    para(a) { const r = reserva(a.reserva_id); if (!r) return a.cliente_nombre || '—'; return (r.tipo === 'folio' ? r.numero : 'Hab. ' + nombreHab(r.habitacion_id)) + ' · ' + (r.huesped_nombre || ''); },
    enriquecer(a) { const f = a.cargo_id ? folios().find(x => x.id === a.cargo_id) : null; return { ...a, tipo_txt: nombreTipoServicio(a.tipo), estado_txt: ESTADOS_SERVICIO[a.estado] || a.estado, para_txt: this.para(a), facturado: !!(f && f.documento_id), cargado: !!f }; },
    // ---- catálogo ----
    nuevoServicio() { this.serv = { id: null, nombre: '', tipo: 'tour', precio: null, moneda: this.cfg.moneda || 'USD', duracion: 60, capacidad: null, horario: '', producto_id: null, proveedor_id: null, comision_pct: 0, activo: true, notas: '' }; },
    editarServicio(s) { this.serv = { ...s }; },
    cargarEjemplos() {
      if (!mock.puedeGuardar()) return;
      mock.actualizar('hotel_servicios', l => { const lista = Array.isArray(l) ? l : []; for (const e of EJEMPLOS) lista.push({ ...e, id: mock.nextId(lista, 'hotel_servicios'), moneda: this.cfg.moneda || 'USD', producto_id: null, proveedor_id: null, comision_pct: 0, activo: true, notas: '' }); return lista; }, []);
      this.refrescar(); toast('Servicios de ejemplo cargados: ajuste precios y proveedores', 'ok');
    },
    guardarServicio() {
      const s = this.serv; if (!(s.nombre || '').trim()) return toast('Indique el nombre del servicio', 'err'); if (!(+s.precio > 0)) return toast('Indique el precio', 'err');
      if (s.proveedor_id && !(+s.comision_pct >= 0 && +s.comision_pct <= 100)) return toast('La comisión del hotel va de 0 a 100 %', 'err');
      if (!mock.puedeGuardar()) return;
      const p = this.proveedores.find(x => x.id === s.proveedor_id);
      const reg = { ...s, nombre: s.nombre.trim(), precio: r2(s.precio), duracion: Math.max(0, +s.duracion || 0), capacidad: +s.capacidad > 0 ? +s.capacidad : null, horario: (s.horario || '').trim(), comision_pct: p ? r2(s.comision_pct) : 0, proveedor_id: p ? p.id : null, proveedor_nombre: p ? p.nombre : '', notas: (s.notas || '').trim() };
      mock.actualizar('hotel_servicios', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'hotel_servicios'); lista.push(reg); } return lista; }, []);
      this.serv = null; this.refrescar(); toast('Servicio «' + reg.nombre + '» guardado', 'ok');
    },
    eliminarServicio(s) {
      if (this.agenda.some(a => a.servicio_id === s.id && a.estado === 'reservado')) return toast('Tiene reservas pendientes: desactívelo en lugar de eliminarlo', 'err');
      if (!confirm('¿Eliminar «' + s.nombre + '» del catálogo? Los servicios ya realizados conservan su historial.')) return;
      mock.actualizar('hotel_servicios', l => (l || []).filter(x => x.id !== s.id), []); this.serv = null; this.refrescar();
    },
    // ---- agenda ----
    nuevaReserva(s) {
      const srv = s || this.catalogoActivo[0]; if (!srv) { this.tab = 'catalogo'; return toast('Cree primero el catálogo de servicios', 'err'); }
      const c = this.cuentas[0];
      this.form = { id: null, servicio_id: srv.id, fecha: this.dia, hora: '09:00', personas: 1, modo: c ? 'cuenta' : 'paso', reserva_id: c ? c.id : null, cliente_nombre: '', telefono: '', precio: +srv.precio || 0, moneda: srv.moneda || this.cfg.moneda, notas: '', cargar_ahora: false };
    },
    editarReserva(a) { if (a.estado !== 'reservado') return; this.form = { ...a, modo: 'cuenta', cargar_ahora: false }; },
    cambiarServicioForm() { const s = this.catalogo.find(x => x.id === this.form.servicio_id); if (s) { this.form.precio = +s.precio || 0; this.form.moneda = s.moneda || this.cfg.moneda; } },
    guardarReservaServicio() {
      const f = this.form, s = this.catalogo.find(x => x.id === f.servicio_id); if (!s) return toast('Elija el servicio', 'err');
      if (!f.fecha) return toast('Indique la fecha', 'err'); if (!(+f.personas > 0)) return toast('Indique las personas o unidades', 'err'); if (!(+f.precio >= 0)) return toast('Revise el precio', 'err');
      if (s.capacidad && +f.personas > +s.capacidad) return toast('Este servicio admite hasta ' + s.capacidad + ' por turno', 'err');
      if (f.modo === 'cuenta' && !f.reserva_id) return toast('Elija la cuenta del huésped', 'err');
      if (f.modo === 'paso' && !(f.cliente_nombre || '').trim()) return toast('Indique el nombre del cliente', 'err');
      if (!mock.puedeGuardar()) return;
      let reservaId = f.reserva_id;
      if (!f.id && f.modo === 'paso') {   // cliente de paso: se le abre una cuenta externa para cobrarle y facturarle desde Recepción
        const ce = nuevaCuentaExterna(this.cfg); ce.huesped_nombre = f.cliente_nombre.trim(); ce.notas = 'Cliente de paso · ' + s.nombre; ce.telefono = (f.telefono || '').trim();
        reservaId = guardarReserva(ce).reg.id;
      }
      const reg = { id: f.id || null, servicio_id: s.id, servicio_nombre: s.nombre, tipo: s.tipo, fecha: f.fecha, hora: f.hora || '', personas: +f.personas, reserva_id: reservaId, cliente_nombre: f.modo === 'paso' ? f.cliente_nombre.trim() : '', precio: r2(f.precio), moneda: f.moneda || this.cfg.moneda, total: r2((+f.precio || 0) * +f.personas),
        proveedor_id: s.proveedor_id || null, proveedor_nombre: s.proveedor_nombre || '', comision_pct: +s.comision_pct || 0, duracion: s.duracion, notas: (f.notas || '').trim(), estado: f.estado || 'reservado', cargo_id: f.cargo_id || null, liquidado: f.liquidado || null, creado: f.creado || new Date().toISOString(), usuario: f.usuario || usuarioActual(), historial: f.historial || [] };
      let guardado = null;
      mock.actualizar('hotel_servicios_agenda', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); guardado = reg; if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { guardado = { ...reg, id: mock.nextId(lista, 'hotel_servicios_agenda') }; lista.push(guardado); } return lista; }, []);
      if (f.cargar_ahora && !guardado.cargo_id) this.cargar(guardado);
      this.form = null; this.dia = reg.fecha; this.refrescar(); toast(s.nombre + ' reservado para el ' + fecha(reg.fecha) + (reg.hora ? ' a las ' + reg.hora : ''), 'ok');
    },
    cambiar(id, fn) { mock.actualizar('hotel_servicios_agenda', l => (l || []).map(x => (x.id === id ? fn({ ...x }) : x)), []); this.refrescar(); },
    anotar(a, texto) { return { ...a, historial: [...(a.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto }].slice(-40) }; },
    cargar(a) {
      const r = reserva(a.reserva_id); if (!r) { toast('La cuenta ya no existe: no se pudo cargar', 'err'); return null; }
      if (r.tipo !== 'folio' && !['en_casa', 'confirmada', 'pendiente'].includes(r.estado)) { toast('La reserva ' + r.numero + ' ya salió o se canceló: registre el cargo en otra cuenta', 'err'); return null; }
      const s = this.catalogo.find(x => x.id === a.servicio_id) || {};
      const f = agregarFolio(cargoServicio(a, s, r, this.cfg));
      this.cambiar(a.id, x => this.anotar({ ...x, cargo_id: f.id }, 'Cargado a la cuenta ' + (r.numero || '') + ': ' + money(f.cantidad * f.precio * (1 + (+f.tarifa || 0) / 100), r.moneda)));
      return f;
    },
    realizado(a) { if (!mock.puedeGuardar()) return; let f = null; if (!a.cargo_id) { f = this.cargar(a); if (!f) return; } this.cambiar(a.id, x => this.anotar({ ...x, estado: 'realizado', realizado: new Date().toISOString() }, 'Servicio realizado')); toast(a.servicio_nombre + ' realizado' + (f ? ' y cargado a la cuenta' : ''), 'ok'); },
    quitarCargo(a) { const f = a.cargo_id ? folios().find(x => x.id === a.cargo_id) : null; if (!f) return true; if (f.documento_id) { toast('El cargo ya se facturó (' + (f.consecutivo || '') + '): anúlelo con una nota de crédito desde la cuenta', 'err'); return false; } quitarFolio(f.id); return true; },
    cancelar(a) {
      if (!confirm('¿Cancelar ' + a.servicio_nombre + ' del ' + fecha(a.fecha) + '?' + (a.cargo_id ? ' Se quita el cargo de la cuenta.' : ''))) return;
      if (!mock.puedeGuardar()) return; if (!this.quitarCargo(a)) return;
      this.cambiar(a.id, x => this.anotar({ ...x, estado: 'cancelado', cargo_id: null }, 'Cancelado')); toast('Servicio cancelado', 'ok');
    },
    noLlego(a) {
      if (!mock.puedeGuardar()) return;
      let conservar = false;
      if (a.cargo_id) conservar = confirm('El servicio ya está cargado a la cuenta. ¿Conservar el cargo como penalidad por no presentarse? (Cancelar = quitarlo)');
      if (a.cargo_id && !conservar && !this.quitarCargo(a)) return;
      this.cambiar(a.id, x => this.anotar({ ...x, estado: 'no_show', cargo_id: conservar ? x.cargo_id : null }, 'No se presentó' + (conservar ? ' · se conserva el cargo' : ''))); toast('Marcado como no llegó', 'ok');
    },
    reabrir(a) { if (!mock.puedeGuardar()) return; this.cambiar(a.id, x => this.anotar({ ...x, estado: 'reservado' }, 'Reabierto')); },
    voucher(a) {
      const s = this.catalogo.find(x => x.id === a.servicio_id) || {}, r = reserva(a.reserva_id);
      const filas = [['Servicio', a.servicio_nombre], ['Fecha', fechaLarga(a.fecha) + (a.hora ? ' · ' + a.hora : '')], ['Duración', s.duracion ? s.duracion + ' min' : ''], ['Personas', a.personas], ['A nombre de', r ? (r.huesped_nombre || '') + (r.tipo !== 'folio' ? ' · hab. ' + nombreHab(r.habitacion_id) : '') : a.cliente_nombre], ['Proveedor', a.proveedor_nombre || 'El hotel'], ['Punto de encuentro / horario', s.horario || ''], ['Precio', money(a.total, a.moneda)], ['Notas', a.notas || '']].filter(x => x[1] !== '' && x[1] !== null && x[1] !== undefined);
      abrirHoja('Voucher de servicio', encabezadoHoja('Voucher de servicio · ' + a.servicio_nombre) + '<table>' + filas.map(x => '<tr><th style="width:200px">' + esc(x[0]) + '</th><td>' + esc(x[1]) + '</td></tr>').join('') + '</table><p class="muted" style="margin-top:14px">Presente este voucher al proveedor o en recepción. Emitido el ' + esc(new Date().toLocaleString('es-CR')) + ' por ' + esc(usuarioActual()) + '.</p>');
    },
    // ---- liquidación ----
    liquidar(p) {
      if (!confirm('¿Marcar como liquidados los ' + p.n + ' servicios de ' + p.proveedor + ' del período (' + this.M(p.a_pagar) + ' a pagar)? Registre el pago al proveedor en Gastos › Pagos a proveedores.')) return;
      if (!mock.puedeGuardar()) return;
      const ids = new Set(p.items.map(a => a.id)), f = hoyHotel();
      mock.actualizar('hotel_servicios_agenda', l => (l || []).map(x => (ids.has(x.id) ? { ...x, liquidado: f, liquidado_por: usuarioActual() } : x)), []); this.refrescar(); toast('Liquidación de ' + p.proveedor + ' registrada', 'ok');
    },
    exportar(que, formato) {
      const hotel = this.cfg.nombre || 'Hotel', M = v => this.M(v);
      if (que === 'agenda') {
        const cols = [{ key: 'hora', label: 'Hora' }, { key: 'servicio_nombre', label: 'Servicio' }, { key: 'tipo_txt', label: 'Tipo' }, { key: 'para_txt', label: 'Para' }, { key: 'personas', label: 'Personas', num: true }, { key: 'total', label: 'Total', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'proveedor_nombre', label: 'Proveedor' }, { key: 'estado_txt', label: 'Estado' }, { key: 'notas', label: 'Notas' }];
        if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'servicios_' + this.dia, cols, this.delDia);
        return descargarReporte(formato, { titulo: 'Agenda de servicios · ' + hotel, subtitulo: fechaLarga(this.dia), cols, rows: this.delDia, kpis: [{ t: 'Reservados', v: String(this.kpis.reservados) }, { t: 'Realizados', v: String(this.kpis.realizados) }, { t: 'Personas', v: String(this.kpis.personas) }], archivo: 'servicios_' + this.dia });
      }
      const rows = this.liquidacion.flatMap(p => p.items.map(a => ({ proveedor: p.proveedor, fecha: a.fecha, servicio: a.servicio_nombre, para: a.para_txt, personas: a.personas, cobrado: a.cobrado, pct: a.comision_pct, comision: a.comision, a_pagar: a.a_pagar })));
      const cols = [{ key: 'proveedor', label: 'Proveedor' }, { key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'servicio', label: 'Servicio' }, { key: 'para', label: 'Para' }, { key: 'personas', label: 'Personas', num: true }, { key: 'cobrado', label: 'Cobrado', num: true, fmt: M }, { key: 'pct', label: '% hotel', num: true }, { key: 'comision', label: 'Comisión', num: true, fmt: M }, { key: 'a_pagar', label: 'A pagar', num: true, fmt: M }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'liquidacion_servicios', cols, rows);
      return descargarReporte(formato, { titulo: 'Liquidación a proveedores de servicios · ' + hotel, subtitulo: 'Del ' + fecha(this.desde) + ' al ' + fecha(this.hasta) + (this.conLiquidados ? '' : ' · pendientes de liquidar'), cols, rows, kpis: [{ t: 'Servicios', v: String(this.totalLiq.n) }, { t: 'Cobrado', v: M(this.totalLiq.cobrado) }, { t: 'Comisión del hotel', v: M(this.totalLiq.comision) }, { t: 'A pagar', v: M(this.totalLiq.a_pagar) }], totales: this.liquidacion.map(p => ({ t: p.proveedor, v: M(p.a_pagar) })), archivo: 'liquidacion_servicios' });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Servicios" :sub="activo ? 'Spa, tours, traslados y alquileres: agenda del día, cargo a la cuenta del huésped y liquidación a proveedores.' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Servicios'}]">
      <button class="btn ghost sm" v-if="tab==='agenda' && delDia.length" @click="exportar('agenda','pdf')">PDF del día</button>
      <button class="btn ghost sm" v-if="tab==='proveedores' && liquidacion.length" @click="exportar('liq','pdf')">PDF</button><button class="btn ghost sm" v-if="tab==='proveedores' && liquidacion.length" @click="exportar('liq','xlsx')">Excel</button><button class="btn ghost sm" v-if="tab==='proveedores' && liquidacion.length" @click="exportar('liq','csv')">CSV</button>
      <button class="btn" v-if="tab!=='catalogo' && puedeEscribir && activo" @click="nuevaReserva()">+ Reservar servicio</button>
      <button class="btn" v-if="tab==='catalogo' && puedeCatalogo && activo" @click="nuevoServicio">+ Servicio</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🧖" title="El hotel no está configurado" text="Active el hotel en Hotel › Habitaciones y tarifas y luego cree el catálogo de servicios."></Empty></div>
    <template v-else>
    <div class="tabs"><button :class="{on: tab==='agenda'}" @click="tab='agenda'">Agenda</button><button :class="{on: tab==='catalogo'}" @click="tab='catalogo'">Catálogo de servicios</button><button :class="{on: tab==='proveedores'}" @click="tab='proveedores'">Liquidación a proveedores</button></div>

    <template v-if="tab==='agenda'">
      <div class="kpis">
        <div class="kpi"><div class="t">Reservados</div><div class="v">{{kpis.reservados}}</div><div class="d">{{fecha(dia)}}</div></div>
        <div class="kpi"><div class="t">Realizados</div><div class="v">{{kpis.realizados}}</div><div class="d">{{kpis.personas}} personas en el día</div></div>
        <div class="kpi"><div class="t">Ingresos del día</div><div class="v">{{M(kpis.ingresos)}}</div><div class="d">servicios realizados</div></div>
        <div class="kpi"><div class="t">Próximos 7 días</div><div class="v">{{kpis.proximos}}</div><div class="d">servicios reservados</div></div>
      </div>
      <div class="card">
        <div class="toolbar"><button class="btn sm sec" @click="cambiarDia(-1)">◀</button><input type="date" class="inp" v-model="dia" style="width:160px"><button class="btn sm sec" @click="cambiarDia(1)">▶</button><button class="btn sm ghost" @click="dia=hoyHotel()">Hoy</button><span style="flex:1"></span><span class="small muted" v-if="!catalogoActivo.length">Sin catálogo: cree los servicios en la pestaña Catálogo.</span></div>
        <Empty v-if="!delDia.length" icon="🧖" title="Sin servicios este día" text="Reserve un masaje, un tour, un traslado o un alquiler para un huésped o un cliente de paso; al realizarlo, el cargo va a su cuenta."><button class="btn" v-if="puedeEscribir" @click="nuevaReserva()">+ Reservar servicio</button></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Hora</th><th>Servicio</th><th>Para</th><th class="num">Personas</th><th class="num">Total</th><th>Proveedor</th><th>Estado</th><th></th></tr></thead>
          <tbody><tr v-for="a in delDia" :key="a.id" :style="a.estado==='cancelado' ? 'opacity:.55' : ''">
            <td class="mono">{{a.hora || '—'}}</td>
            <td><b>{{a.servicio_nombre}}</b><div class="small muted">{{a.tipo_txt}}<span v-if="a.duracion"> · {{a.duracion}} min</span><span v-if="a.notas"> · {{a.notas}}</span></div></td>
            <td>{{a.para_txt}}</td><td class="num">{{a.personas}}</td><td class="num">{{money(a.total, a.moneda)}}<div class="small muted" v-if="a.cargado">{{a.facturado ? 'facturado' : 'en la cuenta'}}</div></td>
            <td class="small">{{a.proveedor_nombre || 'Hotel'}}</td><td><span :class="clase(a.estado)">{{a.estado_txt}}</span></td>
            <td style="white-space:nowrap"><div class="acts" v-if="puedeEscribir">
              <button class="btn sm" v-if="a.estado==='reservado'" @click="realizado(a)" title="Marcar como realizado y cargar a la cuenta">Realizado</button>
              <button class="btn sm ghost" @click="voucher(a)" title="Imprimir voucher">Voucher</button>
              <button class="btn sm ghost" v-if="a.estado==='reservado'" @click="editarReserva(a)">Editar</button>
              <button class="btn sm ghost" v-if="a.estado==='reservado'" @click="noLlego(a)">No llegó</button>
              <button class="btn sm ghost" v-if="a.estado==='reservado'" @click="cancelar(a)">Cancelar</button>
              <button class="btn sm ghost" v-if="a.estado==='cancelado' || a.estado==='no_show'" @click="reabrir(a)">Reabrir</button>
            </div></td>
          </tr></tbody></table></div>
      </div>
      <div class="card" v-if="proximos.length">
        <h3 style="margin:0 0 8px">Próximos 7 días</h3>
        <table class="tbl"><thead><tr><th>Fecha</th><th>Hora</th><th>Servicio</th><th>Para</th><th class="num">Personas</th><th>Proveedor</th><th></th></tr></thead>
          <tbody><tr v-for="a in proximos" :key="a.id"><td>{{fecha(a.fecha)}}</td><td class="mono">{{a.hora || '—'}}</td><td>{{a.servicio_nombre}}</td><td>{{a.para_txt}}</td><td class="num">{{a.personas}}</td><td class="small">{{a.proveedor_nombre || 'Hotel'}}</td><td><a class="link" style="cursor:pointer" @click="dia=a.fecha">Ver día</a></td></tr></tbody></table>
      </div>
    </template>

    <div v-if="tab==='catalogo'" class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar servicio, tipo o proveedor" v-model="q"></div>
      <Empty v-if="!catalogo.length" icon="🧖" title="Sin servicios en el catálogo" text="Agregue los servicios que vende el hotel: masajes, tours, traslados, alquileres… con precio, duración y, si lo presta un proveedor externo, la comisión que se queda el hotel."><div class="row" style="gap:8px"><button class="btn" v-if="puedeCatalogo" @click="nuevoServicio">+ Servicio</button><button class="btn sec" v-if="puedeCatalogo" @click="cargarEjemplos">Cargar ejemplos</button></div></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Servicio</th><th>Tipo</th><th class="num">Precio</th><th class="num">Duración</th><th>Horario</th><th>Proveedor</th><th class="num">Comisión hotel</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="s in catalogoOrdenado" :key="s.id" :style="s.activo===false ? 'opacity:.55' : ''">
          <td><b>{{s.nombre}}</b><div class="small muted" v-if="s.notas">{{s.notas}}</div></td><td>{{nombreTipoServicio(s.tipo)}}</td><td class="num">{{money(s.precio, s.moneda)}}<div class="small muted">por persona o unidad</div></td><td class="num">{{s.duracion ? s.duracion + ' min' : '—'}}</td><td class="small">{{s.horario || '—'}}<span v-if="s.capacidad"> · hasta {{s.capacidad}}</span></td>
          <td>{{s.proveedor_nombre || 'El hotel'}}</td><td class="num">{{s.proveedor_id ? fmt(s.comision_pct, 1) + ' %' : '—'}}</td><td><span :class="s.activo===false ? 'badge' : 'badge ok'">{{s.activo===false ? 'Inactivo' : 'Activo'}}</span></td>
          <td style="white-space:nowrap"><div class="acts"><button class="btn sm" v-if="puedeEscribir && s.activo!==false" @click="nuevaReserva(s)">Reservar</button><button class="btn sm ghost" v-if="puedeCatalogo" @click="editarServicio(s)">Editar</button></div></td>
        </tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0">El precio se cobra por persona (o por unidad en los alquileres) en la moneda indicada; si la cuenta del huésped está en otra moneda se convierte al tipo de cambio del hotel. El IVA y el código CABYS salen del ítem de venta ligado o, si no hay, de los del hotel.</p>
    </div>

    <div v-if="tab==='proveedores'" class="card">
      <div class="toolbar"><label class="small">Del <input type="date" class="inp" v-model="desde"></label><label class="small">al <input type="date" class="inp" v-model="hasta"></label><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="conLiquidados"> Incluir ya liquidados</label></div>
      <Empty v-if="!liquidacion.length" icon="🤝" title="Nada que liquidar" text="Aquí aparecen los servicios realizados por proveedores externos (tours, traslados, spa de terceros) con lo cobrado, la comisión del hotel y lo que se le paga a cada uno."></Empty>
      <template v-else>
        <div class="kpis"><div class="kpi"><div class="t">Servicios</div><div class="v">{{totalLiq.n}}</div></div><div class="kpi"><div class="t">Cobrado a clientes</div><div class="v">{{M(totalLiq.cobrado)}}</div></div><div class="kpi"><div class="t">Comisión del hotel</div><div class="v">{{M(totalLiq.comision)}}</div></div><div class="kpi"><div class="t">A pagar a proveedores</div><div class="v">{{M(totalLiq.a_pagar)}}</div></div></div>
        <div v-for="p in liquidacion" :key="p.proveedor_id" style="margin-top:14px">
          <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><h3 style="margin:0">{{p.proveedor}} <span class="small muted">· {{p.n}} servicio(s) · {{p.personas}} personas</span></h3><div class="row" style="gap:10px;align-items:center"><span>Cobrado <b>{{M(p.cobrado)}}</b> · Comisión <b>{{M(p.comision)}}</b> · A pagar <b>{{M(p.a_pagar)}}</b></span><button class="btn sm" v-if="puedeEscribir && !conLiquidados" @click="liquidar(p)">Marcar liquidado</button></div></div>
          <table class="tbl" style="margin-top:6px"><thead><tr><th>Fecha</th><th>Servicio</th><th>Para</th><th class="num">Personas</th><th class="num">Cobrado</th><th class="num">% hotel</th><th class="num">Comisión</th><th class="num">A pagar</th><th>Liquidado</th></tr></thead>
            <tbody><tr v-for="a in p.items" :key="a.id"><td>{{fecha(a.fecha)}}</td><td>{{a.servicio_nombre}}</td><td>{{a.para_txt}}</td><td class="num">{{a.personas}}</td><td class="num">{{M(a.cobrado)}}</td><td class="num">{{fmt(a.comision_pct,1)}} %</td><td class="num">{{M(a.comision)}}</td><td class="num">{{M(a.a_pagar)}}</td><td class="small">{{a.liquidado ? fecha(a.liquidado) : '—'}}</td></tr></tbody></table>
        </div>
        <p class="small muted" style="margin:10px 0 0">La liquidación no mueve dinero: registre el pago al proveedor en Gastos › Pagos a proveedores con este detalle.</p>
      </template>
    </div>
    </template>

    <Modal v-if="serv" :title="serv.id ? 'Servicio' : 'Nuevo servicio'" @close="serv=null">
      <div class="grid cols-2">
        <Field label="Nombre" req style="grid-column:1/-1"><input v-model="serv.nombre" maxlength="80" placeholder="Masaje relajante 60 min, Tour al volcán, Traslado al aeropuerto…"></Field>
        <Field label="Tipo" req><select v-model="serv.tipo"><option v-for="t in TIPOS_SERVICIO" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Precio por persona o unidad" req help="Con IVA incluido, como las tarifas del hotel"><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="serv.precio" style="flex:1"><select v-model="serv.moneda" style="width:110px"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></div></Field>
        <Field label="Duración (minutos)"><input type="number" min="0" step="5" v-model.number="serv.duracion"></Field>
        <Field label="Capacidad por turno" help="Vacío = sin límite"><input type="number" min="1" step="1" v-model.number="serv.capacidad"></Field>
        <Field label="Horario o punto de encuentro" style="grid-column:1/-1"><input v-model="serv.horario" maxlength="120" placeholder="9:00 a 18:00 · Salida 7:30 desde recepción · Reservar con 24 h"></Field>
        <Field label="Ítem de venta (para IVA y CABYS)" help="Vacío = IVA y CABYS del hotel"><Buscador v-model="serv.producto_id" :opciones="productos" vacio="Los del hotel" agregar="item"></Buscador></Field>
        <Field label="Proveedor externo" help="Vacío = lo presta el hotel"><Buscador v-model="serv.proveedor_id" :opciones="proveedores" detalle="numero_id" vacio="El hotel" agregar="proveedor"></Buscador></Field>
        <Field label="Comisión del hotel (%)" v-if="serv.proveedor_id" help="Lo que se queda el hotel; el resto se le paga al proveedor"><input type="number" min="0" max="100" step="0.5" v-model.number="serv.comision_pct"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="serv.notas" maxlength="200" placeholder="Incluye almuerzo, llevar bloqueador…"></Field>
        <label class="row" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="serv.activo"> Activo (se puede reservar)</label>
      </div>
      <p class="small muted" style="margin:8px 0 0" v-if="!proveedores.length">Para servicios de terceros cree primero el proveedor en Contactos (tipo Proveedor).</p>
      <template #foot><button class="btn danger" v-if="serv.id && puedeCatalogo" @click="eliminarServicio(serv)">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="serv=null">Cancelar</button><button class="btn" @click="guardarServicio">Guardar</button></template>
    </Modal>

    <Modal v-if="form" :title="form.id ? 'Servicio reservado' : 'Reservar servicio'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Servicio" req style="grid-column:1/-1"><select v-model="form.servicio_id" @change="cambiarServicioForm"><option v-for="s in catalogoActivo" :key="s.id" :value="s.id">{{s.nombre}} · {{money(s.precio, s.moneda)}}{{s.proveedor_nombre ? ' · ' + s.proveedor_nombre : ''}}</option></select></Field>
        <Field label="Fecha" req><input type="date" v-model="form.fecha"></Field><Field label="Hora"><input type="time" v-model="form.hora"></Field>
        <Field label="Personas o unidades" req><input type="number" min="1" step="1" v-model.number="form.personas"></Field>
        <Field label="Precio por persona" req><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="form.precio" style="flex:1"><span class="small muted">{{form.moneda}}</span></div></Field>
        <template v-if="!form.id">
          <Field label="¿A quién se cobra?" style="grid-column:1/-1"><div class="seg"><button :class="{on: form.modo==='cuenta'}" @click="form.modo='cuenta'">Huésped o cuenta abierta</button><button :class="{on: form.modo==='paso'}" @click="form.modo='paso'">Cliente de paso</button></div></Field>
          <Field label="Cuenta" req v-if="form.modo==='cuenta'" style="grid-column:1/-1"><select v-model="form.reserva_id"><option :value="null">— Elegir —</option><option v-for="c in cuentas" :key="c.id" :value="c.id">{{c.etiqueta}}</option></select></Field>
          <template v-else><Field label="Nombre del cliente" req><input v-model="form.cliente_nombre" maxlength="80"></Field><Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field><p class="small muted" style="grid-column:1/-1;margin:0">Se le abre una cuenta externa (CE-) para cobrarle y emitir su tiquete desde Recepción › Cuentas externas.</p></template>
        </template>
        <Field label="Para" v-else style="grid-column:1/-1"><input :value="para(form)" disabled></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="200" placeholder="Alergias, recogida en el lobby, idioma del guía…"></Field>
        <label class="row" style="gap:6px;cursor:pointer;grid-column:1/-1" v-if="!form.cargo_id"><input type="checkbox" v-model="form.cargar_ahora"> Cargar a la cuenta ahora (si no, se carga al marcarlo como realizado)</label>
      </div>
      <div class="totals" style="margin-top:10px"><div class="total"><span>Total</span><b>{{money(totalForm, form.moneda)}}</b></div><div v-if="servForm && servForm.proveedor_id"><span>Proveedor {{servForm.proveedor_nombre}} · comisión del hotel {{fmt(servForm.comision_pct,1)}} %</span><b>{{money(r2(totalForm * (1 - (+servForm.comision_pct||0)/100)), form.moneda)}} a pagar</b></div></div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardarReservaServicio">{{form.id ? 'Guardar' : 'Reservar'}}</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy, hoyHotel, r2 }; },   // 3.87: el botón «Hoy» llama hoyHotel en la plantilla
};
