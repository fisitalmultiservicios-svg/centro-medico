// Hotel › Reservaciones › Agencias y empresas (3.1): contratos con agencias, operadores y empresas. Cada contrato define la
// modalidad (tarifa neta a crédito o comisión sobre la tarifa pública), tarifas negociadas por categoría y temporada o un descuento,
// vigencia, crédito y el contacto al que se factura. Desde aquí se facturan a la agencia las estadías a crédito (varias reservas,
// incluidos los no presentados, en una sola factura) y se ve el estado de cuenta y las comisiones.
import { api, toast, money, fecha, fechaHora, hoy, mock, monedas } from '../../api.js';
import { sesion, store } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { config, hotelActivo, agencias, agenciaVigente, MODALIDADES_AGENCIA, categorias, reservas, folios, totalCargo, cambiarFolio, cambiarReserva, anotar, nombreHab, noches, CABYS_HOSPEDAJE, r2, hoyHotel } from './_datos.js';

const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());

export default {
  props: ['params'],
  data() { return { cfg: config(), lista: agencias(), q: '', form: null, ver: null, facturar: null, procesando: false, MODALIDADES_AGENCIA, activo: hotelActivo(), tab: 'contratos', docs: [] }; },
  async created() { try { this.docs = (await api('/api/comprobantes')).filter(d => d.tipo_documento === '01' && d.estado !== 'rechazado'); } catch { this.docs = []; } },   // facturas a crédito de las agencias (3.22)
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    puedeFacturar() { return sesion.puede('facturar') || sesion.puede('pos'); },
    clientes() { return (store.clientes || []).filter(c => c.activo !== false); },
    cats() { return categorias(); },
    cxcVer() { return this.cxcDe(this.ver); },
    filas() {
      const q = this.q.trim().toLowerCase(), fs = folios().filter(f => f.a_agencia), rs = reservas();
      return this.lista.map(a => { const mios = fs.filter(f => f.agencia_id === a.id); const pend = r2(mios.filter(f => !f.documento_id).reduce((s, f) => s + totalCargo(f), 0)), fact = r2(mios.filter(f => f.documento_id).reduce((s, f) => s + totalCargo(f), 0)); const cli = this.clientes.find(c => c.id === a.cliente_id); const cxc = this.cxcDe(a), expuesto = r2(pend + cxc.total); return { ...a, contacto: cli ? cli.nombre : '', por_cobrar: cxc.total, vencido: r2(cxc.d30 + cxc.d60 + cxc.mas60), expuesto, sobre_tope: +a.credito_tope > 0 && expuesto > +a.credito_tope, modalidad_txt: a.modalidad === 'neta' ? 'Tarifa neta' : 'Comisión ' + (a.comision_pct || 0) + ' %', vigente: agenciaVigente(a) ? 'Vigente' : (a.activo === false ? 'Inactivo' : 'Fuera de vigencia'), reservas_n: rs.filter(r => r.agencia_id === a.id && r.tipo !== 'bloqueo').length, pendiente: pend, facturado: fact }; })
        .filter(a => !q || [a.nombre, a.contacto, a.notas].some(x => String(x || '').toLowerCase().includes(q)))
        .sort((a, b) => a.nombre.localeCompare(b.nombre));
    },
    columns() { return [{ key: 'nombre', label: 'Agencia o empresa', link: a => this.abrir(a) }, { key: 'tipo', label: 'Tipo', fmt: v => (v === 'empresa' ? 'Empresa' : 'Agencia') }, { key: 'contacto', label: 'Se factura a' }, { key: 'modalidad_txt', label: 'Modalidad' }, { key: 'descuento_pct', label: 'Desc. %', num: true }, { key: 'reservas_n', label: 'Reservas', num: true }, { key: 'pendiente', label: 'Por facturar', num: true, fmt: v => money(v, this.cfg.moneda) }, { key: 'por_cobrar', label: 'Por cobrar', num: true, fmt: (v, r) => money(v, this.cfg.moneda) + (r.vencido > 0.005 ? ' · vencido ' + money(r.vencido, this.cfg.moneda) : '') }, { key: 'facturado', label: 'Facturado', num: true, fmt: v => money(v, this.cfg.moneda) }, { key: 'vigente', label: 'Estado', fmt: 'badge' }]; },
    // estado de cuenta de la agencia abierta: cargos a crédito agrupados por reserva
    cuenta() {
      if (!this.ver) return [];
      const rs = {}; for (const r of reservas()) rs[r.id] = r;
      const m = {};
      for (const f of folios().filter(f => f.a_agencia && f.agencia_id === this.ver.id)) { const r = rs[f.reserva_id] || { id: f.reserva_id }; const o = m[r.id] || (m[r.id] = { reserva: r, cargos: [], pendiente: 0, facturado: 0, consecutivos: new Set() }); o.cargos.push(f); if (f.documento_id) { o.facturado = r2(o.facturado + totalCargo(f)); if (f.consecutivo) o.consecutivos.add(f.consecutivo); } else o.pendiente = r2(o.pendiente + totalCargo(f)); }
      return Object.values(m).map(o => ({ ...o, consecutivos: [...o.consecutivos].join(', ') })).sort((a, b) => String(b.reserva.llegada || '').localeCompare(String(a.reserva.llegada || '')));
    },
    pendientesVer() { return this.cuenta.filter(o => o.pendiente > 0.005); },
    comisionesVer() {
      if (!this.ver || this.ver.modalidad !== 'comision') return [];
      return reservas().filter(r => r.agencia_id === this.ver.id && r.estado === 'salio').map(r => { const base = r2(folios().filter(f => f.reserva_id === r.id && f.tipo === 'cargo' && ['hospedaje', 'auto'].includes(f.origen)).reduce((s, f) => s + totalCargo(f), 0)); return { r, base, comision: r2(base * (+this.ver.comision_pct || 0) / 100) }; }).sort((a, b) => String(b.r.salida).localeCompare(String(a.r.salida)));
    },
    totalFacturar() { return !this.facturar ? 0 : r2(this.pendientesVer.filter(o => this.facturar.ids.includes(o.reserva.id)).reduce((s, o) => s + o.pendiente, 0)); },
  },
  methods: {
    // cuentas por cobrar de cada contrato (3.22): facturas a su contacto con saldo, por antigüedad desde el vencimiento
    cxcDe(a) {
      const h = hoy(), out = { docs: [], total: 0, vigente: 0, d30: 0, d60: 0, mas60: 0 };
      if (!a || !a.cliente_id) return out;
      for (const d of this.docs.filter(x => x.cliente_id === a.cliente_id)) {
        const saldo = r2((+d.total || 0) - (+d.pagado || 0) - (+d.acreditado || 0)); if (saldo <= 0.005) continue;
        const vence = String(d.fecha_vencimiento || d.fecha_emision || '').slice(0, 10), dias = vence ? noches(vence, h) * (vence < h ? 1 : -1) : 0;
        const saldoHotel = (d.moneda || 'CRC') === this.cfg.moneda ? saldo : (d.moneda === 'USD' ? r2(saldo * (+d.tipo_cambio || 1)) : r2(saldo / (+d.tipo_cambio || 1)));
        out.docs.push({ id: d.id, consecutivo: d.consecutivo, fecha: String(d.fecha_emision || '').slice(0, 10), vence, dias: vence && vence < h ? dias : 0, saldo, moneda: d.moneda || 'CRC', saldoHotel });
        out.total = r2(out.total + saldoHotel);
        if (!vence || vence >= h) out.vigente = r2(out.vigente + saldoHotel); else if (dias <= 30) out.d30 = r2(out.d30 + saldoHotel); else if (dias <= 60) out.d60 = r2(out.d60 + saldoHotel); else out.mas60 = r2(out.mas60 + saldoHotel);
      }
      out.docs.sort((x, y) => String(x.vence).localeCompare(String(y.vence)));
      return out;
    },

    money, fecha, fechaHora, nombreHab, noches,
    refrescar() { this.lista = agencias(); if (this.ver) this.ver = this.lista.find(x => x.id === this.ver.id) || null; },
    abrir(a) { this.ver = this.lista.find(x => x.id === a.id) || a; },
    nuevo() { this.form = { id: null, nombre: '', tipo: 'agencia', cliente_id: null, modalidad: 'neta', descuento_pct: 0, comision_pct: 10, tarifas: {}, vigencia_desde: '', vigencia_hasta: '', credito: true, dias_credito: 30, contacto: '', correo: '', telefono: '', notas: '', activo: true }; },
    editar(a) { this.form = JSON.parse(JSON.stringify({ tarifas: {}, ...a })); },
    tarifa(catId, k) { const t = this.form.tarifas[String(catId)]; return t ? t[String(k)] : ''; },
    ponerTarifa(catId, k, v) { if (!this.form.tarifas[String(catId)]) this.form.tarifas[String(catId)] = {}; this.form.tarifas[String(catId)][String(k)] = v === '' || v === null ? '' : +v; },
    guardar() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Indique el nombre', 'err');
      if (f.modalidad === 'neta' && !f.cliente_id) return toast('Con tarifa neta hace falta el contacto al que se factura (créelo en Contactos con su cédula)', 'err');
      if (!mock.puedeGuardar()) return;
      for (const k of Object.keys(f.tarifas)) for (const kk of Object.keys(f.tarifas[k])) { const v = f.tarifas[k][kk]; if (v === '' || v === null || isNaN(+v)) delete f.tarifas[k][kk]; else f.tarifas[k][kk] = +v; }
      const reg = { ...f, nombre: f.nombre.trim(), descuento_pct: +f.descuento_pct || 0, comision_pct: +f.comision_pct || 0, dias_credito: +f.dias_credito || 30 };
      this.lista = mock.actualizar('hotel_agencias', l => { const lista = Array.isArray(l) ? l : []; const r = { ...reg, id: reg.id || mock.nextId(lista, 'hotel_agencias'), actualizado: new Date().toISOString() }; const i = lista.findIndex(x => x.id === r.id); if (i >= 0) lista.splice(i, 1, r); else lista.push(r); return lista; }, []);
      this.form = null; toast('Contrato guardado', 'ok');
    },
    abrirFacturar() { const b = this.clientes.find(c => c.id === this.ver.cliente_id); if (!b) return toast('El contrato no tiene contacto para facturar', 'err'); this.facturar = { ids: this.pendientesVer.map(o => o.reserva.id), enviar: true, idem: uuid() }; },
    alternarRes(id) { const i = this.facturar.ids.indexOf(id); if (i >= 0) this.facturar.ids.splice(i, 1); else this.facturar.ids.push(id); },
    async confirmarFacturar() {
      const a = this.ver, fx = this.facturar; const grupos = this.pendientesVer.filter(o => fx.ids.includes(o.reserva.id)); if (!grupos.length) return toast('Marque al menos una reserva', 'err');
      if (!mock.puedeGuardar()) return;
      this.procesando = true;
      const lineas = [], cargos = [];
      for (const o of grupos) for (const f of o.cargos.filter(f => !f.documento_id)) { cargos.push(f); lineas.push({ producto_id: null, detalle: ('Hab. ' + nombreHab(o.reserva.habitacion_id) + ' · ' + (o.reserva.huesped_nombre || '') + ' · ' + (f.detalle || '')).slice(0, 200), cabys: f.cabys || this.cfg.cabys_hospedaje || CABYS_HOSPEDAJE, cantidad: +f.cantidad || 1, precio_unitario: Math.round((+f.precio || 0) * 100000) / 100000, descuento: 0, codigo_tarifa: f.codigo_tarifa || '08', tarifa: +f.tarifa || 0, es_servicio: true, unidad_medida: 'Os' }); }
      const moneda = grupos[0].reserva.moneda || this.cfg.moneda;
      try {
        const doc = await api('/api/comprobantes', { method: 'POST', body: { tipo_documento: '01', cliente_id: a.cliente_id, condicion_venta: a.credito ? '02' : '01', plazo_credito: a.credito ? (+a.dias_credito || 30) : null, medio_pago: '04', moneda, tipo_cambio: monedas.tc(moneda), lineas, observaciones: ('Hospedaje a crédito · ' + a.nombre + ' · reservas ' + grupos.map(o => o.reserva.numero).join(', ')).slice(0, 500), idempotencia: fx.idem, vendedor: sesion.usuario?.nombre || null } });
        for (const f of cargos) cambiarFolio(f.id, { documento_id: doc.id, consecutivo: doc.consecutivo, facturado_fecha: hoyHotel(), doc_tipo: '01' });
        for (const o of grupos) cambiarReserva(o.reserva.id, x => anotar(x, 'Hospedaje facturado a ' + a.nombre + ' · ' + doc.consecutivo));
        if (fx.enviar && doc.estado === 'firmado') { try { await api('/api/comprobantes/' + doc.id + '/enviar', { method: 'POST' }); } catch (e) { toast('Queda en cola para Hacienda (' + e.message + ')', 'err'); } }
        this.facturar = null; this.refrescar(); toast('Factura ' + doc.consecutivo.slice(-10) + ' emitida a ' + a.nombre + ' · ' + money(doc.total, moneda) + (a.credito ? ' · a crédito ' + (a.dias_credito || 30) + ' días' : ''), 'ok');
        window.open('/api/comprobantes/' + doc.id + '/pdf', '_blank');
      } catch (e) { toast('No se emitió la factura: ' + e.message, 'err'); }
      this.procesando = false;
    },
    exportar(formato) {
      const cols = this.columns.map(c => ({ ...c, fmt: c.fmt === 'badge' ? undefined : c.fmt })), rows = this.filas;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'hotel_agencias', cols, rows);
      return descargarReporte(formato, { titulo: 'Agencias y empresas · ' + (this.cfg.nombre || 'Hotel'), subtitulo: 'Contratos, saldo por facturar y facturado', periodo: 'Al ' + fecha(hoy()), cols, rows, kpis: [{ t: 'Contratos', v: String(rows.length) }, { t: 'Por facturar', v: money(r2(rows.reduce((s, x) => s + x.pendiente, 0)), this.cfg.moneda) }], archivo: 'hotel_agencias' });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Agencias y empresas" sub="Contratos con agencias, operadores y empresas: tarifa neta a crédito o comisión, tarifas negociadas, vigencia y facturación de las estadías a crédito." :crumbs="[{label:'Hotel'},{label:'Reservaciones',to:'/hotel/reservaciones'},{label:'Agencias y empresas'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!filas.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!filas.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!filas.length">CSV</button>
      <button class="btn" @click="nuevo" v-if="puedeEscribir">+ Contrato</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🤝" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="card"><div class="toolbar"><input class="search" placeholder="Buscar agencia, empresa o contacto" v-model="q"></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin contratos" empty-text="Cree el primero con «+ Contrato». Luego elija la agencia en cada reserva o en el grupo." @row-click="abrir"></DataTable>
    </div>
    <div class="card" v-if="ver"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><h2 style="margin:0">{{ver.nombre}} <small>{{ver.modalidad === 'neta' ? 'tarifa neta a crédito' : 'comisión ' + (ver.comision_pct || 0) + ' %'}}{{ver.descuento_pct ? ' · descuento ' + ver.descuento_pct + ' %' : ''}}{{ver.vigencia_hasta ? ' · vence ' + fecha(ver.vigencia_hasta) : ''}}</small></h2>
        <div class="row" style="gap:6px"><button class="btn sm ghost" @click="editar(ver)" v-if="puedeEscribir">Editar contrato</button><button class="btn sm" @click="abrirFacturar" v-if="puedeFacturar && ver.modalidad === 'neta' && pendientesVer.length">Facturar a la agencia ({{pendientesVer.length}})</button></div></div>
      <div class="alert danger" v-if="+ver.credito_tope > 0 && (filas.find(x => x.id === ver.id) || {}).sobre_tope" style="margin:0 0 10px">Crédito excedido: por facturar más facturas con saldo suman {{money((filas.find(x => x.id === ver.id) || {}).expuesto, cfg.moneda)}} y el tope es {{money(ver.credito_tope, cfg.moneda)}}.</div>
      <div class="card" style="padding:10px;margin:0 0 12px" v-if="ver.cliente_id">
        <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><b>Cuentas por cobrar <small class="muted">facturas a {{(clientes.find(c => c.id === ver.cliente_id) || {}).nombre}} con saldo</small></b><span class="small">Vigente <b>{{money(cxcVer.vigente, cfg.moneda)}}</b> · 1-30 días <b :style="cxcVer.d30 ? 'color:var(--warn)' : ''">{{money(cxcVer.d30, cfg.moneda)}}</b> · 31-60 <b :style="cxcVer.d60 ? 'color:var(--danger)' : ''">{{money(cxcVer.d60, cfg.moneda)}}</b> · más de 60 <b :style="cxcVer.mas60 ? 'color:var(--danger)' : ''">{{money(cxcVer.mas60, cfg.moneda)}}</b> · total <b>{{money(cxcVer.total, cfg.moneda)}}</b></span></div>
        <div class="table-wrap" v-if="cxcVer.docs.length" style="margin-top:6px"><table class="tbl"><thead><tr><th>Factura</th><th>Emitida</th><th>Vence</th><th class="num">Días vencida</th><th class="num">Saldo</th></tr></thead><tbody><tr v-for="x in cxcVer.docs" :key="x.id"><td><a class="link" :href="'#/ventas/facturas/' + x.id">{{x.consecutivo.slice(-10)}}</a></td><td>{{fecha(x.fecha)}}</td><td>{{x.vence ? fecha(x.vence) : '—'}}</td><td class="num" :style="x.dias > 0 ? 'color:var(--danger);font-weight:600' : ''">{{x.dias > 0 ? x.dias : '—'}}</td><td class="num">{{money(x.saldo, x.moneda)}}</td></tr></tbody></table></div>
        <p class="small muted" v-else style="margin:6px 0 0">Sin facturas pendientes de cobro.</p>
      </div>
      <template v-if="ver.modalidad === 'neta'">
        <Empty v-if="!cuenta.length" icon="🧾" title="Sin estadías a crédito todavía" text="Cuando una reserva con este contrato haga check-out, su hospedaje aparece aquí para facturarlo."></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Reserva</th><th>Huésped</th><th>Hab.</th><th>Llegada</th><th>Salida</th><th class="num">Por facturar</th><th class="num">Facturado</th><th>Facturas</th></tr></thead>
          <tbody><tr v-for="o in cuenta" :key="o.reserva.id"><td><a class="link" :href="'#/hotel/recepcion?reserva=' + o.reserva.id">{{o.reserva.numero}}</a></td><td>{{o.reserva.huesped_nombre}}</td><td>{{nombreHab(o.reserva.habitacion_id)}}</td><td>{{fecha(o.reserva.llegada)}}</td><td>{{fecha(o.reserva.salida_real || o.reserva.salida)}}</td><td class="num" :style="o.pendiente > 0 ? 'color:var(--danger)' : ''">{{money(o.pendiente, o.reserva.moneda || cfg.moneda)}}</td><td class="num">{{money(o.facturado, o.reserva.moneda || cfg.moneda)}}</td><td class="small">{{o.consecutivos}}</td></tr></tbody></table></div>
      </template>
      <template v-else>
        <Empty v-if="!comisionesVer.length" icon="💼" title="Sin estadías con comisión todavía"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Reserva</th><th>Huésped</th><th>Salida</th><th class="num">Hospedaje</th><th class="num">Comisión {{ver.comision_pct || 0}} %</th></tr></thead>
          <tbody><tr v-for="x in comisionesVer" :key="x.r.id"><td>{{x.r.numero}}</td><td>{{x.r.huesped_nombre}}</td><td>{{fecha(x.r.salida_real || x.r.salida)}}</td><td class="num">{{money(x.base, x.r.moneda)}}</td><td class="num">{{money(x.comision, x.r.moneda)}}</td></tr></tbody>
          <tbody><tr class="tot"><td colspan="4">Total de comisiones</td><td class="num">{{money(comisionesVer.reduce((s,x)=>s+x.comision,0), cfg.moneda)}}</td></tr></tbody></table></div>
        <p class="small muted" style="margin:8px 0 0">Las comisiones se pagan a la agencia por fuera (Gastos); este cuadro y el reporte «Comisiones a agencias» dicen cuánto.</p>
      </template>
    </div>
    </template>

    <Modal v-if="form" :title="form.id ? 'Contrato · ' + form.nombre : 'Nuevo contrato'" lg @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="80" placeholder="Viajes del Pacífico"></Field>
        <Field label="Tipo"><select v-model="form.tipo"><option value="agencia">Agencia u operador</option><option value="empresa">Empresa (corporativo)</option></select></Field>
        <Field label="Modalidad" req style="grid-column:1/-1"><select v-model="form.modalidad"><option v-for="m in MODALIDADES_AGENCIA" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
        <Field label="Contacto al que se factura" :req="form.modalidad==='neta'" help="De Contactos, con su cédula"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Elegir" agregar="cliente"></Buscador></Field>
        <Field label="Comisión (%)" v-if="form.modalidad==='comision'" help="Sobre el hospedaje de cada estadía"><input type="number" min="0" max="50" step="0.5" v-model.number="form.comision_pct"></Field>
        <Field label="Descuento sobre la tarifa pública (%)" help="Se usa cuando la categoría no tiene tarifa negociada abajo"><input type="number" min="0" max="80" step="0.5" v-model.number="form.descuento_pct"></Field>
        <Field label="Vigencia desde"><input type="date" v-model="form.vigencia_desde"></Field><Field label="Vigencia hasta" help="Vacío = sin vencimiento"><input type="date" v-model="form.vigencia_hasta"></Field>
        <template v-if="form.modalidad==='neta'"><Field label="Crédito"><div class="row" style="gap:8px"><input type="checkbox" v-model="form.credito"><input type="number" min="1" max="120" v-model.number="form.dias_credito" :disabled="!form.credito" style="width:90px"><span class="small muted">días de plazo en la factura</span></div></Field></template>
        <Field label="Contacto (persona)"><input v-model="form.contacto" maxlength="80"></Field>
        <Field label="Correo"><input v-model="form.correo" maxlength="80"></Field><Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field>
        <Field label="Tope de crédito" :help="'En ' + cfg.moneda + ': por facturar más facturas con saldo; al pasarlo se avisa en la lista y en la reserva. 0 = sin tope'"><input type="number" min="0" step="1" v-model.number="form.credito_tope"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="200"></Field>
      </div>
      <h3 class="small muted" style="margin:12px 0 4px">Tarifas negociadas por noche en {{cfg.moneda}} (vacío = tarifa pública menos el descuento)</h3>
      <div class="table-wrap"><table class="tbl tarifas"><thead><tr><th>Categoría</th><th class="num">Base</th><th class="num" v-for="t in cfg.temporadas" :key="t.id">{{t.nombre}}</th></tr></thead>
        <tbody><tr v-for="c in cats" :key="c.id"><td><b>{{c.nombre}}</b></td><td class="num"><input type="number" min="0" step="0.01" :value="tarifa(c.id,'base')" @input="ponerTarifa(c.id,'base',$event.target.value)"></td><td class="num" v-for="t in cfg.temporadas" :key="t.id"><input type="number" min="0" step="0.01" :value="tarifa(c.id,t.id)" @input="ponerTarifa(c.id,t.id,$event.target.value)"></td></tr></tbody></table></div>
      <div style="margin-top:10px"><Toggle v-model="form.activo" label="Contrato activo"></Toggle></div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar contrato</button></template>
    </Modal>
    <Modal v-if="facturar && ver" :title="'Facturar a ' + ver.nombre" lg @close="procesando || (facturar=null)">
      <p class="small muted" style="margin:0 0 8px">Una sola factura electrónica a {{(clientes.find(c=>c.id===ver.cliente_id) || {}).nombre}} con el hospedaje a crédito de las reservas marcadas{{ver.credito ? ', a crédito a ' + (ver.dias_credito || 30) + ' días' : ''}}. Cada línea indica la habitación y el huésped.</p>
      <div class="card" style="padding:8px;max-height:260px;overflow:auto"><label v-for="o in pendientesVer" :key="o.reserva.id" class="row small" style="gap:6px;cursor:pointer;padding:3px 0"><input type="checkbox" :checked="facturar.ids.includes(o.reserva.id)" @change="alternarRes(o.reserva.id)"> {{o.reserva.numero}} · {{o.reserva.huesped_nombre}} · hab. {{nombreHab(o.reserva.habitacion_id)}} · {{fecha(o.reserva.llegada)}} al {{fecha(o.reserva.salida_real || o.reserva.salida)}}<span class="badge warn" v-if="o.reserva.estado==='no_show'" style="margin-left:4px">no presentado</span><b style="margin-left:auto">{{money(o.pendiente, o.reserva.moneda || cfg.moneda)}}</b></label></div>
      <div class="totals" style="margin-top:8px"><div class="total"><span>Total a facturar</span><b>{{money(totalFacturar, cfg.moneda)}}</b></div></div>
      <label class="row" style="gap:6px;margin-top:8px;cursor:pointer"><input type="checkbox" v-model="facturar.enviar"> Enviar a Hacienda ahora</label>
      <template #foot><button class="btn ghost" @click="facturar=null" :disabled="procesando">Cancelar</button><button class="btn" @click="confirmarFacturar" :disabled="procesando || !facturar.ids.length">{{procesando ? 'Emitiendo…' : 'Emitir factura'}}</button></template>
    </Modal>
  </div>`,
};
