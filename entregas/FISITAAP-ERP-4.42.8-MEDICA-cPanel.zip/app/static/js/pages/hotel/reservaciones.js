// Hotel › Reservaciones: calendario pequeño de la semana (domingo a domingo, con desplazamiento para las siguientes) y lista de
// reservas con búsqueda, filtros por estado y fechas, confirmación, cancelación y bloqueos de habitaciones.
import { api, toast, money, fecha, hoy, sumarDias, mock, monedas } from '../../api.js';
import { sesion } from '../../app.js';
import Tape, { Leyenda } from './_tape.js';
import BloqueoModal, { QuitarBloqueo } from './_bloqueo.js';   // H6: bloqueo de varias habitaciones en un solo guardado
import { config, hotelActivo, habitaciones, reservas, esEstadia, agregarFolio, cambiarFolio, agenciaDe, CABYS_HOSPEDAJE, r2, ESTADOS, nombreOrigen, origenCorto, nombreHab, nombreCat, noches, domingoAnterior, fechasEntre, totalesFolio, folioDe, cambiarReserva, anotar, insignia, numeroVisita, ocupacionDia, claseEstado, hoyHotel } from './_datos.js';

export default {
  props: ['params'],
  components: { Tape, Leyenda, BloqueoModal, QuitarBloqueo },
  data() { return { cfg: config(), lista: reservas(), q: this.params.q || '', estado: this.params.estado || 'vigentes', inicio: domingoAnterior(hoyHotel()), bloqueo: null, quitar: null, cancelar: null, activo: hotelActivo(), agrupar: 'piso' }; },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    dias() { return fechasEntre(this.inicio, 28); },
    habs() { return habitaciones(); },
    hoyS() { return hoyHotel(); },
    filas() {
      const q = this.q.trim().toLowerCase(), h = this.hoyS;
      return this.lista.filter(esEstadia).filter(r => {
        if (this.estado === 'vigentes') return ['pendiente', 'confirmada', 'en_casa'].includes(r.estado) && r.salida >= h;
        if (this.estado === 'hoy') return (r.llegada === h || r.salida === h) && r.estado !== 'cancelada';
        if (this.estado === 'pasadas') return r.estado === 'salio' || r.salida < h;
        if (this.estado === 'todas') return true;
        return r.estado === this.estado;
      }).filter(r => !q || [r.numero, r.huesped_nombre, nombreHab(r.habitacion_id), r.referencia, r.grupo].some(x => String(x || '').toLowerCase().includes(q)))
        .map(r => { const t = totalesFolio(folioDe(r.id)); const v = numeroVisita(r, this.lista); const cre = String(r.creado || '').slice(0, 10); return { ...r, dias_pend: r.estado === 'pendiente' && cre.length === 10 ? noches(cre, h) : null, hab: nombreHab(r.habitacion_id) + (r.habitacion_id ? '' : ' (' + nombreCat(r.categoria_id) + ')'), noches_n: noches(r.llegada, r.salida), pagado: t.pagos, saldo: Math.max(0, (+r.total || 0) - t.pagos), visita: insignia(v), estado_txt: ESTADOS[r.estado] || r.estado, origen_txt: origenCorto(r.origen) }; })
        .sort((a, b) => String(a.llegada).localeCompare(String(b.llegada)) || String(a.numero).localeCompare(String(b.numero)));
    },
    columns() {
      return [{ key: 'numero', label: 'Reserva', mono: true, link: r => this.abrir(r) }, { key: 'huesped_nombre', label: 'Huésped', fmt: (v, r) => (r.vip ? '★ ' : '') + (v || '—') + (r.visita ? ' ' + r.visita : '') }, { key: 'hab', label: 'Habitación' },
        { key: 'llegada', label: 'Llegada', fmt: 'date' }, { key: 'salida', label: 'Salida', fmt: 'date' }, { key: 'noches_n', label: 'Noches', num: true }, { key: 'total', label: 'Total', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'saldo', label: 'Saldo', num: true, fmt: (v, r) => money(v, r.moneda) },
        { key: 'origen_txt', label: 'Origen' }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' },
        ...(this.estado === 'pendiente' ? [{ key: 'dias_pend', label: 'Días sin adelanto', num: true, fmt: v => (v === null ? '—' : v + (this.cfg.adelanto_plazo_dias ? ' de ' + this.cfg.adelanto_plazo_dias : '')) }] : [])];
    },
    resumen() { const h = this.hoyS, o = ocupacionDia(h, this.lista, this.habs); const llegan = this.lista.filter(r => esEstadia(r) && r.llegada === h && ['pendiente', 'confirmada'].includes(r.estado)).length, salen = this.lista.filter(r => r.tipo !== 'bloqueo' && r.salida === h && r.estado === 'en_casa').length, pend = this.lista.filter(r => r.tipo !== 'bloqueo' && r.estado === 'pendiente' && r.salida >= h).length; return { ...o, llegan, salen, pend }; },
  },
  methods: {
    money, fecha, claseEstado,
    abrir(r) { location.hash = '/hotel/reservaciones/' + r.id; },
    nuevaEn(x) { location.hash = '/hotel/reservaciones/nueva?habitacion=' + x.habitacion.id + '&fecha=' + x.fecha; },
    mover(n) { this.inicio = sumarDias(this.inicio, n); },
    irHoy() { this.inicio = domingoAnterior(hoyHotel()); },
    async confirmar(r) { const { promesa } = cambiarReserva(r.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada')); if (await promesa) { this.lista = reservas(); toast('Reserva ' + r.numero + ' confirmada', 'ok'); } },
    abrirCancelar(r) { const t = totalesFolio(folioDe(r.id)); const pen = this.penalidadSugerida(r); this.cancelar = { r, motivo: '', noShow: r.llegada < this.hoyS, cobrar: pen > 0, penalidad: pen, pagado: t.pagos, agencia: r.agencia_id ? agenciaDe(r.agencia_id) : null }; },
    // penalidad por no presentación (3.1): la primera noche (lo habitual en la política) o el adelanto si fue menor
    penalidadSugerida(r) { return r2(+r.tarifa_noche || 0); },
    async confirmarCancelar() {
      const { r, motivo, noShow, cobrar, penalidad, agencia } = this.cancelar; const estado = noShow ? 'no_show' : 'cancelada';
      if (!mock.puedeGuardar()) return;
      let nota = (noShow ? 'No llegó' : 'Cancelada') + (motivo ? ': ' + motivo : '');
      let cargo = null;
      if (noShow && cobrar && +penalidad > 0) {
        const c = this.cfg, t = +c.tarifa_iva || 0, precio = c.precios_incluyen_iva ? Math.round(+penalidad / (1 + t / 100) * 100000) / 100000 : +penalidad;
        cargo = agregarFolio({ reserva_id: r.id, tipo: 'cargo', origen: 'no_show', fecha: this.hoyS, detalle: 'Penalidad por no presentación · reserva ' + r.numero + ' · ' + fecha(r.llegada), cantidad: 1, precio, tarifa: t, codigo_tarifa: c.codigo_tarifa || '08', cabys: c.cabys_hospedaje || CABYS_HOSPEDAJE, moneda: r.moneda, producto_id: null });
        nota += ' · penalidad ' + money(+penalidad, r.moneda);
        const neta = agencia && agencia.modalidad === 'neta';
        if (neta) { cambiarFolio(cargo.id, { a_agencia: true, agencia_id: agencia.id }); nota += ' a cargo de ' + agencia.nombre; }
        else {
          // con adelanto: se emite el tiquete de la penalidad y se aplica el adelanto; sin adelanto queda como saldo en la cuenta
          const t0 = totalesFolio(folioDe(r.id)), pagos = folioDe(r.id).filter(f => f.tipo === 'pago' && !f.aplicado_en);
          if (t0.pagos > 0.005) {
            try {
              const doc = await api('/api/comprobantes', { method: 'POST', body: { tipo_documento: '04', cliente_id: null, condicion_venta: '01', medio_pago: pagos[0] ? pagos[0].medio : '01', moneda: r.moneda, tipo_cambio: monedas.tc(r.moneda), lineas: [{ producto_id: null, detalle: cargo.detalle.slice(0, 200), cabys: cargo.cabys, cantidad: 1, precio_unitario: precio, descuento: 0, codigo_tarifa: cargo.codigo_tarifa, tarifa: t, es_servicio: true, unidad_medida: 'Os' }], observaciones: ('No presentación · ' + r.numero + (r.huesped_nombre ? ' · ' + r.huesped_nombre : '')).slice(0, 500), idempotencia: 'noshow-' + r.id + '-' + Date.now(), vendedor: sesion.usuario?.nombre || null } });
              const total = r2(doc.total || +penalidad), aplicar = r2(Math.min(t0.pagos, total));
              try { await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: null, detalles: 'Adelanto retenido por no presentación · ' + r.numero + ' (ya registrado en Bancos)', fecha: this.hoyS, cuenta: '', condicion_venta: '01', medio_pago: pagos[0] ? pagos[0].medio : '01', moneda: r.moneda, tipo_cambio: monedas.tc(r.moneda), monto: aplicar, notas: 'Hotel', facturas: [{ id: doc.id, monto: aplicar }] } }); for (const p of pagos) cambiarFolio(p.id, { aplicado_en: doc.id }); } catch (e) { toast('El adelanto no se aplicó al tiquete: ' + e.message, 'err'); }
              cambiarFolio(cargo.id, { documento_id: doc.id, consecutivo: doc.consecutivo }); nota += ' · tiquete ' + doc.consecutivo;
              try { await api('/api/comprobantes/' + doc.id + '/enviar', { method: 'POST' }); } catch {}
            } catch (e) { toast('La penalidad quedó en la cuenta, pero no se emitió el tiquete: ' + e.message, 'err'); }
          }
        }
      }
      const { promesa } = cambiarReserva(r.id, x => anotar({ ...x, estado, motivo_cancelacion: motivo, penalidad: noShow && cobrar ? +penalidad : 0 }, nota));
      if (await promesa) { this.lista = reservas(); toast('Reserva ' + r.numero + (noShow ? ' marcada como no presentada' : ' cancelada') + (cargo ? ' · penalidad registrada' : ''), 'ok'); }
      this.cancelar = null;
    },
    // H6: el cuadro compartido (_bloqueo.js) elige fechas, motivo y habitaciones, y las guarda todas juntas
    abrirBloqueo() { this.bloqueo = {}; },
    bloqueoListo() { this.lista = reservas(); this.bloqueo = null; this.quitar = null; },
    // un bloqueo del calendario se quita solo o, si se creó en un lote, con las demás habitaciones del lote
    abrirDesdeCalendario(r) { if (r.tipo === 'bloqueo') { this.quitar = r; return; } this.abrir(r); },
  },
  template: `
  <div class="page">
    <PageHead title="Reservaciones" :sub="activo ? 'Hoy: ' + resumen.ocupadas + ' de ' + resumen.total + ' habitaciones ocupadas (' + resumen.pct + ' %) · ' + resumen.llegan + ' llegadas · ' + resumen.salen + ' salidas' + (resumen.pend ? ' · ' + resumen.pend + ' pendientes de adelanto' : '') : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Reservaciones'}]">
      <a class="btn ghost" href="#/hotel/calendario">Calendario completo</a>
      <button class="btn sec" @click="abrirBloqueo" :disabled="!puedeEscribir || !habs.length">Bloquear habitaciones</button>
      <a class="btn" href="#/hotel/reservaciones/nueva" v-if="puedeEscribir && habs.length">+ Nueva reserva</a>
    </PageHead>
    <div class="card" v-if="!activo || !habs.length"><Empty icon="🛏" title="El hotel todavía no está configurado" text="Cree las categorías, las habitaciones y los precios en Habitaciones y tarifas; luego marque el hotel como activo."><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Configurar el hotel</a></Empty></div>
    <template v-else>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:8px">
      <h2 style="margin:0">Semana <small>de domingo a domingo · deslice para ver las siguientes · toque una celda libre para reservar</small></h2>
      <div class="row" style="gap:6px"><button class="btn sm ghost" @click="mover(-7)">◀ Semana</button><button class="btn sm sec" @click="irHoy">Hoy</button><button class="btn sm ghost" @click="mover(7)">Semana ▶</button><select class="inp" v-model="agrupar" style="padding:4px 8px"><option value="piso">Por piso</option><option value="categoria">Por categoría</option><option value="ninguno">Sin agrupar</option></select></div></div>
      <Leyenda></Leyenda>
      <Tape :dias="dias" :habitaciones="habs" :reservas="lista" :agrupar="agrupar" compacto :solo-lectura="!puedeEscribir" @abrir="abrirDesdeCalendario" @nueva="nuevaEn"></Tape>
    </div>
    <div class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar por número, huésped, habitación o referencia" v-model="q">
        <div class="seg"><button :class="{on: estado==='vigentes'}" @click="estado='vigentes'">Vigentes</button><button :class="{on: estado==='hoy'}" @click="estado='hoy'">Hoy</button><button :class="{on: estado==='pendiente'}" @click="estado='pendiente'">Sin adelanto</button><button :class="{on: estado==='en_casa'}" @click="estado='en_casa'">En casa</button><button :class="{on: estado==='pasadas'}" @click="estado='pasadas'">Pasadas</button><button :class="{on: estado==='cancelada'}" @click="estado='cancelada'">Canceladas</button><button :class="{on: estado==='todas'}" @click="estado='todas'">Todas</button></div></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin reservas" empty-text="Cree la primera con «Nueva reserva» o toque una celda libre del calendario." @row-click="abrir">
        <template #actions="{row}">
          <button class="btn sm ghost" v-if="row.estado==='pendiente' && puedeEscribir" @click.stop="confirmar(row)" title="Marcar como confirmada">Confirmar</button>
          <a class="btn sm ghost" v-if="['pendiente','confirmada'].includes(row.estado) && row.llegada <= hoyS" :href="'#/hotel/recepcion?reserva=' + row.id" @click.stop title="Hacer el check-in en Recepción">Check-in</a>
          <button class="btn icon" v-if="['pendiente','confirmada'].includes(row.estado) && puedeEscribir" @click.stop="abrirCancelar(row)" title="Cancelar">✕</button>
        </template>
      </DataTable>
    </div>
    </template>

    <BloqueoModal v-if="bloqueo" :lista="lista" :habs="habs" @listo="bloqueoListo" @cerrar="bloqueo=null"></BloqueoModal>
    <QuitarBloqueo v-if="quitar" :bloqueo="quitar" :lista="lista" :puede="puedeEscribir" @listo="bloqueoListo" @cerrar="quitar=null"></QuitarBloqueo>
    <Modal v-if="cancelar" :title="(cancelar.noShow ? 'No se presentó · ' : 'Cancelar · ') + cancelar.r.numero" @close="cancelar=null">
      <p v-if="cancelar.noShow" class="small muted">La fecha de llegada ya pasó y el huésped no llegó. Se marca como <b>no presentado</b> y la habitación queda libre.</p>
      <div v-if="cancelar.noShow" class="card" style="padding:10px;margin:0 0 10px">
        <label class="row" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="cancelar.cobrar"> Cobrar penalidad por no presentación</label>
        <div class="grid cols-2" style="margin-top:8px" v-if="cancelar.cobrar"><Field label="Monto de la penalidad" :help="'Sugerido: la primera noche. Adelanto recibido: ' + money(cancelar.pagado, cancelar.r.moneda)"><input type="number" min="0" step="0.01" v-model.number="cancelar.penalidad"></Field></div>
        <p class="small muted" style="margin:6px 0 0" v-if="cancelar.cobrar">{{cancelar.agencia && cancelar.agencia.modalidad === 'neta' ? 'Contrato de tarifa neta: la penalidad se factura a ' + cancelar.agencia.nombre + ' desde Agencias y empresas.' : (cancelar.pagado > 0 ? 'Se emite el tiquete de la penalidad y se retiene el adelanto; si el adelanto es menor, el resto queda como saldo en la cuenta.' : 'Sin adelanto: la penalidad queda como saldo en la cuenta de la reserva.')}}</p>
      </div>
      <p v-else class="small muted">La reserva pasa a cancelada y la habitación queda libre para esas fechas.</p>
      <Field label="Motivo"><input v-model="cancelar.motivo" maxlength="120"></Field>
      <template #foot><button class="btn ghost" @click="cancelar=null">Volver</button><button class="btn danger" @click="confirmarCancelar">{{cancelar.noShow ? 'Marcar no presentado' : 'Cancelar reserva'}}</button></template>
    </Modal>
  </div>`,
  setup() { return { nombreCat }; },
};
