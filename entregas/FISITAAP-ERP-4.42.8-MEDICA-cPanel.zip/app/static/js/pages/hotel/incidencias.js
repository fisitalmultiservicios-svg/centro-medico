// Ama de llaves › Reportes de limpieza y Mantenimiento › Incidencias (2.4): la misma pantalla con el módulo según la ruta.
// Reportes abiertos, en proceso y resueltos; tomar, resolver con nota, pasar al otro módulo, dejar o sacar la habitación de
// mantenimiento, prioridad; exportación a PDF, Word y CSV.
import { toast, fecha, fechaHora, hoy, mock } from '../../api.js';
import { sesion } from '../../app.js';
import ReporteProblema from './_reporte.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { hotelActivo, reportes, cambiarReporte, anotarReporte, nombreHab, nombreModulo, MODULOS_REPORTE, ESTADOS_REPORTE, usuarioActual, todasHabitaciones } from './_datos.js';

export default {
  props: ['params'],
  data() { const modulo = location.hash.includes('/mantenimiento') ? 'mantenimiento' : 'limpieza'; return { modulo, lista: reportes(), filtro: 'pendientes', q: '', nuevo: false, ver: null, nota: '', activo: hotelActivo(), ESTADOS_REPORTE }; },
  computed: {
    puedeEscribir() { return sesion.puede(this.modulo) || sesion.puede('escribir') || sesion.puede('pos'); },
    preventivoVencido() { const h = hoy(); return (mock.get('hotel_preventivo', []) || []).filter(p => p && p.activo !== false && p.proxima && p.proxima <= h).sort((a, b) => String(a.proxima).localeCompare(String(b.proxima))); },   // planes vencidos (3.21)
    titulo() { return this.modulo === 'mantenimiento' ? 'Incidencias de mantenimiento' : 'Reportes de limpieza'; },
    otro() { return this.modulo === 'mantenimiento' ? 'limpieza' : 'mantenimiento'; },
    rows() {
      const q = this.q.trim().toLowerCase();
      return this.lista.filter(r => r.modulo === this.modulo).filter(r => this.filtro === 'todos' || (this.filtro === 'pendientes' && r.estado !== 'resuelto') || (this.filtro === 'urgentes' && r.prioridad === 'urgente' && r.estado !== 'resuelto') || (this.filtro === 'resueltos' && r.estado === 'resuelto'))
        .filter(r => !q || [r.numero, r.tipo, r.descripcion, r.lugar, nombreHab(r.habitacion_id), r.usuario, r.asignado].some(x => String(x || '').toLowerCase().includes(q)))
        .map(r => ({ ...r, lugar_txt: r.habitacion_id ? 'Hab. ' + nombreHab(r.habitacion_id) : (r.lugar || '—'), estado_txt: ESTADOS_REPORTE[r.estado] || r.estado, prioridad_txt: r.prioridad === 'urgente' ? 'Urgente' : 'Normal', edad: this.edad(r) }))
        .sort((a, b) => (a.estado === 'resuelto') - (b.estado === 'resuelto') || (b.prioridad === 'urgente') - (a.prioridad === 'urgente') || String(a.creado).localeCompare(String(b.creado)));
    },
    columns() { return [{ key: 'numero', label: 'Nº', mono: true, link: r => this.abrir(r) }, { key: 'creado', label: 'Reportado', fmt: v => fechaHora(v) }, { key: 'lugar_txt', label: 'Lugar' }, { key: 'tipo', label: 'Problema' }, { key: 'descripcion', label: 'Detalle', fmt: v => (v || '').slice(0, 60) }, { key: 'prioridad_txt', label: 'Prioridad', fmt: 'badge' }, { key: 'asignado', label: 'Atiende', fmt: v => v || '—' }, { key: 'edad', label: 'Tiempo' }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' }]; },
    resumen() { const mios = this.lista.filter(r => r.modulo === this.modulo); return { abiertos: mios.filter(r => r.estado === 'abierto').length, proceso: mios.filter(r => r.estado === 'en_proceso').length, urgentes: mios.filter(r => r.prioridad === 'urgente' && r.estado !== 'resuelto').length, hoy: mios.filter(r => r.estado === 'resuelto' && r.resuelto_en && fecha(r.resuelto_en) === fecha(hoy())).length }; },   // resuelto_en es UTC: se compara en fecha de Costa Rica
  },
  methods: {
    fecha, fechaHora, nombreHab, nombreModulo,
    edad(r) { const ms = Date.now() - new Date(r.creado).getTime(); const h = Math.floor(ms / 3600000); if (r.estado === 'resuelto') return '—'; return h < 1 ? Math.max(1, Math.round(ms / 60000)) + ' min' : h < 48 ? h + ' h' : Math.round(h / 24) + ' d'; },
    refrescar() { this.lista = reportes(); if (this.ver) this.ver = this.lista.find(x => x.id === this.ver.id) || null; },
    abrir(r) { this.ver = this.lista.find(x => x.id === r.id) || r; this.nota = ''; },
    tomar(r) { cambiarReporte(r.id, x => anotarReporte({ ...x, estado: 'en_proceso', asignado: usuarioActual() }, 'En proceso · ' + usuarioActual())); this.refrescar(); toast(r.numero + ' en proceso', 'ok'); },
    resolver(r) {
      const n = (this.nota || '').trim();
      cambiarReporte(r.id, x => anotarReporte({ ...x, estado: 'resuelto', resuelto_en: new Date().toISOString(), resuelto_por: usuarioActual(), nota_cierre: n }, 'Resuelto' + (n ? ': ' + n : '')));
      if (r.habitacion_id && this.modulo === 'mantenimiento') { const h = todasHabitaciones().find(x => x.id === r.habitacion_id); if (h && h.estado === 'mantenimiento' && confirm('¿Sacar la habitación ' + h.numero + ' de mantenimiento? Queda como sucia para que Ama de llaves la revise.')) this.marcarHab(h.id, 'sucia'); }
      this.refrescar(); this.nota = ''; toast(r.numero + ' resuelto', 'ok');
    },
    reabrir(r) { cambiarReporte(r.id, x => anotarReporte({ ...x, estado: 'abierto', resuelto_en: null }, 'Reabierto')); this.refrescar(); },
    pasar(r) { cambiarReporte(r.id, x => anotarReporte({ ...x, modulo: this.otro, estado: 'abierto', asignado: '' }, 'Pasado a ' + nombreModulo(this.otro))); this.refrescar(); this.ver = null; toast(r.numero + ' pasado a ' + nombreModulo(this.otro), 'ok'); },
    urgencia(r) { cambiarReporte(r.id, x => anotarReporte({ ...x, prioridad: x.prioridad === 'urgente' ? 'normal' : 'urgente' }, x.prioridad === 'urgente' ? 'Prioridad normal' : 'Marcado urgente')); this.refrescar(); },
    marcarHab(id, estado) { mock.actualizar('hotel_habitaciones', l => (l || []).map(h => (h.id === id ? { ...h, estado, estado_hora: new Date().toISOString(), estado_usuario: usuarioActual() } : h)), []); },
    habEstado(r) { const h = r.habitacion_id ? todasHabitaciones().find(x => x.id === r.habitacion_id) : null; return h ? h.estado || 'limpia' : ''; },
    bloquear(r) { if (!r.habitacion_id) return; const h = todasHabitaciones().find(x => x.id === r.habitacion_id); if (!h) return; if (h.estado === 'mantenimiento') { this.marcarHab(h.id, 'sucia'); cambiarReporte(r.id, x => anotarReporte(x, 'Habitación ' + h.numero + ' sale de mantenimiento')); } else { this.marcarHab(h.id, 'mantenimiento'); cambiarReporte(r.id, x => anotarReporte(x, 'Habitación ' + h.numero + ' en mantenimiento')); } this.refrescar(); },
    eliminar(r) { if (!confirm('¿Eliminar el reporte ' + r.numero + '? Se pierde su historial.')) return; mock.set('hotel_reportes', reportes().filter(x => x.id !== r.id)); this.refrescar(); this.ver = null; },
    exportar(formato) {
      const cols = [{ key: 'numero', label: 'Nº' }, { key: 'creado', label: 'Reportado', fmt: v => fechaHora(v) }, { key: 'lugar_txt', label: 'Lugar' }, { key: 'tipo', label: 'Problema' }, { key: 'descripcion', label: 'Detalle' }, { key: 'prioridad_txt', label: 'Prioridad' }, { key: 'usuario', label: 'Reportó' }, { key: 'asignado', label: 'Atiende' }, { key: 'estado_txt', label: 'Estado' }, { key: 'resuelto_en', label: 'Resuelto', fmt: v => (v ? fechaHora(v) : '') }, { key: 'nota_cierre', label: 'Nota de cierre' }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, this.modulo + '_reportes', cols, this.rows);
      return descargarReporte(formato, { titulo: this.titulo, subtitulo: this.rows.length + ' reporte(s) · ' + this.filtro, periodo: 'Al ' + fecha(hoy()), cols, rows: this.rows, kpis: [{ t: 'Abiertos', v: String(this.resumen.abiertos) }, { t: 'En proceso', v: String(this.resumen.proceso) }, { t: 'Urgentes', v: String(this.resumen.urgentes) }, { t: 'Resueltos hoy', v: String(this.resumen.hoy) }], archivo: this.modulo + '_reportes' });
    },
  },
  components: { ReporteProblema },
  template: `
  <div class="page">
    <PageHead :title="titulo" :sub="activo ? resumen.abiertos + ' abierto(s) · ' + resumen.proceso + ' en proceso · ' + resumen.urgentes + ' urgente(s) · ' + resumen.hoy + ' resuelto(s) hoy' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label: nombreModulo(modulo)},{label: titulo}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!rows.length">PDF</button><button class="btn ghost sm" @click="exportar('docx')" :disabled="!rows.length">Word</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!rows.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!rows.length">CSV</button>
      <a class="btn sec" :href="'#/hotel/' + (modulo==='mantenimiento' ? 'mantenimiento' : 'ama-de-llaves') + '/tipos'">Tipos de problema</a>
      <button class="btn" @click="nuevo=true">+ Reportar problema</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛠" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <div class="alert warn" v-if="activo && modulo==='mantenimiento' && preventivoVencido.length" style="margin-bottom:12px">Mantenimiento preventivo vencido: {{preventivoVencido.map(p => p.nombre + ' (' + fecha(p.proxima) + ')').join(' · ')}}. <a href="#/hotel/mantenimiento/preventivo" class="link">Ir al preventivo</a></div>
    <div class="card" v-if="activo">
      <div class="toolbar"><input class="search" v-model="q" placeholder="Buscar por número, habitación, problema o persona">
        <div class="seg"><button :class="{on: filtro==='pendientes'}" @click="filtro='pendientes'">Pendientes</button><button :class="{on: filtro==='urgentes'}" @click="filtro='urgentes'">Urgentes</button><button :class="{on: filtro==='resueltos'}" @click="filtro='resueltos'">Resueltos</button><button :class="{on: filtro==='todos'}" @click="filtro='todos'">Todos</button></div></div>
      <DataTable :rows="rows" :columns="columns" :page-size="20" empty-title="Sin reportes" empty-text="Cualquier usuario puede reportar un problema desde el menú Hotel o desde Recepción; aquí se atienden." @row-click="abrir">
        <template #actions="{row}">
          <button class="btn sm" v-if="row.estado==='abierto' && puedeEscribir" @click.stop="tomar(row)">Tomar</button>
          <button class="btn sm sec" v-if="row.estado!=='resuelto' && puedeEscribir" @click.stop="abrir(row)">Resolver…</button>
        </template>
      </DataTable>
    </div>
    <Drawer v-if="ver" :title="ver.numero + ' · ' + ver.tipo" @close="ver=null">
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px"><Badge :value="ESTADOS_REPORTE[ver.estado]"></Badge><span class="badge" :class="ver.prioridad==='urgente' ? 'danger' : ''">{{ver.prioridad==='urgente' ? 'Urgente' : 'Normal'}}</span><span class="badge" v-if="ver.habitacion_id && habEstado(ver)==='mantenimiento'">Habitación en mantenimiento</span></div>
      <div class="grid" style="grid-template-columns:1fr 1fr;gap:6px 14px;font-size:13px">
        <div><div class="small muted">Lugar</div>{{ver.habitacion_id ? 'Habitación ' + nombreHab(ver.habitacion_id) : (ver.lugar || '—')}}</div>
        <div><div class="small muted">Reportado</div>{{fechaHora(ver.creado)}}<br><span class="muted">{{ver.usuario}}</span></div>
        <div style="grid-column:1/-1"><div class="small muted">Detalle</div><span style="white-space:pre-wrap">{{ver.descripcion || '—'}}</span></div>
        <div v-if="ver.asignado"><div class="small muted">Atiende</div>{{ver.asignado}}</div>
        <div v-if="ver.resuelto_en"><div class="small muted">Resuelto</div>{{fechaHora(ver.resuelto_en)}} · {{ver.resuelto_por}}<br>{{ver.nota_cierre}}</div>
      </div>
      <div v-if="ver.estado!=='resuelto' && puedeEscribir" style="margin-top:14px">
        <Field label="Nota de cierre" help="Qué se hizo"><textarea rows="2" v-model="nota" maxlength="300"></textarea></Field>
        <div class="row" style="gap:6px;margin-top:8px;flex-wrap:wrap"><button class="btn sm" v-if="ver.estado==='abierto'" @click="tomar(ver)">Tomar</button><button class="btn sm" @click="resolver(ver)">Marcar resuelto</button><button class="btn sm ghost" @click="urgencia(ver)">{{ver.prioridad==='urgente' ? 'Quitar urgencia' : 'Marcar urgente'}}</button><button class="btn sm ghost" @click="pasar(ver)">Pasar a {{nombreModulo(otro)}}</button><button class="btn sm ghost" v-if="ver.habitacion_id" @click="bloquear(ver)">{{habEstado(ver)==='mantenimiento' ? 'Sacar de mantenimiento' : 'Habitación en mantenimiento'}}</button></div>
      </div>
      <div v-else-if="puedeEscribir" class="row" style="gap:6px;margin-top:14px"><button class="btn sm ghost" @click="reabrir(ver)">Reabrir</button></div>
      <h2 style="font-size:14px;margin:16px 0 6px">Historial</h2>
      <div v-for="(x,i) in (ver.historial || []).slice().reverse()" :key="i" class="small" style="padding:4px 0;border-bottom:1px solid var(--line)"><span class="muted">{{fechaHora(x.fecha)}} · {{x.usuario}}</span><br>{{x.texto}}</div>
      <template #foot><button class="btn danger" @click="eliminar(ver)" v-if="puede('configurar')">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="ver=null">Cerrar</button></template>
    </Drawer>
    <ReporteProblema v-if="nuevo" :modulo="modulo" @close="nuevo=false" @creado="refrescar"></ReporteProblema>
  </div>`,
  setup() { return { MODULOS_REPORTE }; },
};
