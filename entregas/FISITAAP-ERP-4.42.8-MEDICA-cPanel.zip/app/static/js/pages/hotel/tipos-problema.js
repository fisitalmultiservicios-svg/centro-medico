// Ama de llaves › Tipos de problema y Mantenimiento › Tipos de problema (2.4): la lista básica viene cargada y cada módulo agrega,
// renombra o desactiva los suyos. Son las opciones del cuadro «Reportar problema».
import { toast, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { tiposProblema, nombreModulo, reportes } from './_datos.js';

export default {
  props: ['params'],
  data() { const modulo = location.hash.includes('/mantenimiento') ? 'mantenimiento' : 'limpieza'; return { modulo, lista: tiposProblema(), nuevo: '' }; },
  computed: {
    puedeEscribir() { return sesion.puede(this.modulo) || sesion.puede('escribir'); },
    mios() { return this.lista.filter(t => t.modulo === this.modulo); },
    usos() { const m = {}; for (const r of reportes()) if (r.modulo === this.modulo) m[r.tipo] = (m[r.tipo] || 0) + 1; return m; },
  },
  methods: {
    nombreModulo,
    guardar(l) { if (!mock.puedeGuardar()) return; mock.set('hotel_tipos_problema', l); this.lista = l; },
    agregar() { const n = (this.nuevo || '').trim(); if (!n) return; if (this.mios.some(t => t.nombre.toLowerCase() === n.toLowerCase())) return toast('Ese tipo ya existe', 'err'); this.guardar([...this.lista, { id: mock.nextId(this.lista, 'hotel_tipos_problema'), modulo: this.modulo, nombre: n, activo: true }]); this.nuevo = ''; toast('Tipo agregado', 'ok'); },
    renombrar(t) { const n = window.prompt('Nuevo nombre:', t.nombre); if (n === null || !n.trim()) return; this.guardar(this.lista.map(x => (x.id === t.id ? { ...x, nombre: n.trim() } : x))); },
    alternar(t) { this.guardar(this.lista.map(x => (x.id === t.id ? { ...x, activo: x.activo === false } : x))); },
    eliminar(t) { if (this.usos[t.nombre]) return toast('Tiene reportes: desactívelo en vez de eliminarlo', 'err'); if (!confirm('¿Eliminar «' + t.nombre + '»?')) return; this.guardar(this.lista.filter(x => x.id !== t.id)); },
  },
  template: `
  <div class="page" style="max-width:860px">
    <PageHead :title="'Tipos de problema · ' + nombreModulo(modulo)" sub="Las opciones que ve quien reporta un problema. Los básicos vienen cargados; agregue los de su hotel o desactive los que no use." :crumbs="[{label:'Hotel'},{label: nombreModulo(modulo)},{label:'Tipos de problema'}]">
      <a class="btn ghost" :href="'#/hotel/' + (modulo==='mantenimiento' ? 'mantenimiento' : 'ama-de-llaves') + '/incidencias'">Ver reportes</a>
    </PageHead>
    <div class="card">
      <div class="row" style="gap:8px;margin-bottom:12px" v-if="puedeEscribir"><input class="inp" style="flex:1" v-model="nuevo" maxlength="80" placeholder="Nuevo tipo de problema…" @keyup.enter="agregar"><button class="btn" @click="agregar">+ Agregar</button></div>
      <table class="tbl"><thead><tr><th>Tipo</th><th class="num">Reportes</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="t in mios" :key="t.id" :style="t.activo===false ? 'opacity:.55' : ''"><td>{{t.nombre}}</td><td class="num">{{usos[t.nombre] || 0}}</td><td><Badge :value="t.activo===false ? 'Desactivado' : 'Activo'"></Badge></td><td><div class="acts" v-if="puedeEscribir"><button class="btn sm ghost" @click="renombrar(t)">Renombrar</button><button class="btn sm ghost" @click="alternar(t)">{{t.activo===false ? 'Activar' : 'Desactivar'}}</button><button class="btn icon" @click="eliminar(t)" title="Eliminar">🗑</button></div></td></tr></tbody></table>
    </div>
  </div>`,
};
