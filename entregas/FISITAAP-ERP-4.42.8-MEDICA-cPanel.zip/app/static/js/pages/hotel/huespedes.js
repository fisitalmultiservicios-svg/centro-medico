// Hotel › Huéspedes: tarjeta del huésped que se arma sola con cada estadía (datos, documento, cumpleaños, preferencias, VIP,
// número de visitas, historial y gasto), búsqueda y exportación.
import { toast, money, fecha, hoy, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { PAISES, GENTILICIOS, config, huespedes, huespedNuevo, guardarHuesped, nombreHuesped, estadiasDe, gastoHuesped, insignia, textoVisita, edad, proximoCumple, TIPOS_DOC, nombreHab, nombreOrigen, noches, ESTADOS, reservas, enlaceWhatsApp, hotelActivo , archivoHuesped } from './_datos.js';

export default {
  props: ['params'],
  data() { return { PAISES, GENTILICIOS, cfg: config(), lista: huespedes(), q: this.params.q || '', filtro: 'todos', ver: null, archivos: {}, form: null, TIPOS_DOC, activo: hotelActivo() }; },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    enCasa() { return new Set(reservas().filter(r => r.estado === 'en_casa').map(r => r.huesped_id)); },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.lista.map(h => { const est = estadiasDe(h.id); const c = proximoCumple(h.nacimiento); return { ...h, nombre_completo: nombreHuesped(h), visitas: est.length, insignia: insignia(est.length), ultima: est[0] ? est[0].llegada : '', gasto: gastoHuesped(h.id), en_casa: this.enCasa.has(h.id), cumple: c ? c.dias : null, edad_n: edad(h.nacimiento) }; })
        .filter(h => this.filtro === 'todos' || (this.filtro === 'vip' && h.vip) || (this.filtro === 'casa' && h.en_casa) || (this.filtro === 'repiten' && h.visitas >= 2) || (this.filtro === 'cumple' && h.cumple !== null && h.cumple <= 30))
        .filter(h => !q || [h.nombre_completo, h.documento, h.telefono, h.correo, h.nacionalidad, h.pais].some(x => String(x || '').toLowerCase().includes(q)))
        .sort((a, b) => (b.visitas - a.visitas) || a.nombre_completo.localeCompare(b.nombre_completo));
    },
    columns() { return [{ key: 'nombre_completo', label: 'Huésped', fmt: (v, r) => (r.vip ? '★ ' : '') + v + (r.insignia ? ' ' + r.insignia : ''), link: r => this.abrir(r) }, { key: 'documento', label: 'Documento', mono: true }, { key: 'nacionalidad', label: 'Nacionalidad' }, { key: 'telefono', label: 'Teléfono' }, { key: 'visitas', label: 'Visitas', num: true }, { key: 'ultima', label: 'Última estadía', fmt: 'date' }, { key: 'gasto', label: 'Gasto total', num: true, fmt: v => money(v, this.cfg.moneda) }, { key: 'en_casa', label: 'Estado', fmt: v => (v ? 'En casa' : '') }]; },
    estadiasVer() { return this.ver ? estadiasDe(this.ver.id).map(r => ({ ...r, hab: nombreHab(r.habitacion_id), noches_n: noches(r.llegada, r.salida), estado_txt: ESTADOS[r.estado], origen_txt: nombreOrigen(r.origen) })) : []; },
    reservasFuturas() { return this.ver ? reservas().filter(r => r.huesped_id === this.ver.id && ['pendiente', 'confirmada'].includes(r.estado)) : []; },
  },
  methods: {
    money, fecha, nombreHuesped, textoVisita, insignia, edad, enlaceWhatsApp,
    abrir(h) { this.ver = this.lista.find(x => x.id === h.id) || h; this.archivos = {}; const id = this.ver.id; for (const t of ['documento', 'firma']) archivoHuesped(id, t).then(d => { if (d && this.ver && this.ver.id === id) this.archivos = { ...this.archivos, [t]: d }; }); },
    nuevo() { this.form = huespedNuevo(); },
    editar(h) { this.form = { ...huespedNuevo(), ...h }; },
    guardar() {
      if (!(this.form.nombre || '').trim()) return toast('Indique el nombre', 'err');
      if (!mock.puedeGuardar()) return;
      const h = guardarHuesped({ ...this.form, nombre: this.form.nombre.trim() });
      // el nombre y la marca VIP viajan copiados en las reservas vigentes
      const cambiadas = reservas().map(r => (r.huesped_id === h.id && ['pendiente', 'confirmada', 'en_casa'].includes(r.estado) ? { ...r, huesped_nombre: nombreHuesped(h), vip: !!h.vip } : r));
      if (JSON.stringify(cambiadas) !== JSON.stringify(reservas())) mock.set('hotel_reservas', cambiadas);
      this.lista = huespedes(); this.form = null; if (this.ver && this.ver.id === h.id) this.ver = h; toast('Huésped guardado', 'ok');
    },
    eliminar(h) { if (estadiasDe(h.id).length || reservas().some(r => r.huesped_id === h.id)) return toast('Tiene reservas o estadías: no se puede eliminar', 'err'); if (!confirm('¿Eliminar a ' + nombreHuesped(h) + '?')) return; mock.set('hotel_huespedes', huespedes().filter(x => x.id !== h.id)); this.lista = huespedes(); this.ver = null; this.form = null; },
    exportar(formato) {
      const cols = [{ key: 'nombre_completo', label: 'Huésped' }, { key: 'documento', label: 'Documento' }, { key: 'nacionalidad', label: 'Nacionalidad' }, { key: 'telefono', label: 'Teléfono' }, { key: 'correo', label: 'Correo' }, { key: 'visitas', label: 'Visitas', num: true }, { key: 'ultima', label: 'Última estadía', fmt: 'date' }, { key: 'gasto', label: 'Gasto', num: true, fmt: v => money(v, this.cfg.moneda) }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'huespedes', cols, this.filas);
      return descargarReporte(formato, { titulo: 'Huéspedes del hotel', subtitulo: this.filas.length + ' huésped(es)', periodo: 'Al ' + fecha(hoy()), cols, rows: this.filas, archivo: 'huespedes' });
    },
  },
  created() { if (this.params.id) { const h = this.lista.find(x => x.id === +this.params.id); if (h) this.ver = h; } },
  template: `
  <div class="page">
    <PageHead title="Huéspedes" sub="La tarjeta de cada huésped se arma sola con sus estadías: visitas, preferencias, cumpleaños, VIP y gasto." :crumbs="[{label:'Hotel'},{label:'Huéspedes'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!filas.length">PDF</button><button class="btn ghost sm" @click="exportar('docx')" :disabled="!filas.length">Word</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!filas.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!filas.length">CSV</button>
      <button class="btn" @click="nuevo" v-if="puedeEscribir">+ Nuevo huésped</button>
    </PageHead>
    <div class="card">
      <div class="toolbar"><input class="search" v-model="q" placeholder="Buscar por nombre, documento, teléfono, correo o país">
        <div class="seg"><button :class="{on: filtro==='todos'}" @click="filtro='todos'">Todos</button><button :class="{on: filtro==='casa'}" @click="filtro='casa'">En casa</button><button :class="{on: filtro==='vip'}" @click="filtro='vip'">VIP</button><button :class="{on: filtro==='repiten'}" @click="filtro='repiten'">Repiten (×2 o más)</button><button :class="{on: filtro==='cumple'}" @click="filtro='cumple'">Cumplen en 30 días</button></div></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin huéspedes" empty-text="Se crean solos al registrar reservas; también puede crearlos aquí." @row-click="abrir"></DataTable>
    </div>

    <Drawer v-if="ver" :title="nombreHuesped(ver)" @close="ver=null">
      <div class="row" style="gap:6px;margin-bottom:10px;flex-wrap:wrap"><span class="visita" v-if="estadiasDe(ver.id).length>=2" :title="textoVisita(estadiasDe(ver.id).length)">{{insignia(estadiasDe(ver.id).length)}}</span><span class="badge warn" v-if="ver.vip">VIP</span><span class="badge info" v-if="enCasa.has(ver.id)">En casa</span><span class="badge" v-if="ver.no_marketing">Sin promociones</span></div>
      <div class="grid" style="grid-template-columns:1fr 1fr;gap:6px 14px;font-size:13px">
        <div><div class="small muted">Documento</div>{{(TIPOS_DOC.find(t=>t[0]===ver.tipo_doc)||['',''])[1]}} {{ver.documento || '—'}}</div>
        <div><div class="small muted">Nacionalidad</div>{{ver.nacionalidad || '—'}}</div>
        <div><div class="small muted">Teléfono</div>{{ver.telefono || '—'}} <a v-if="ver.telefono" class="link small" :href="enlaceWhatsApp(ver.telefono, 'Hola ' + ver.nombre + ', le saluda ' + (cfg.nombre || 'el hotel') + '.')" target="_blank" rel="noopener">WhatsApp</a></div>
        <div><div class="small muted">Correo</div>{{ver.correo || '—'}}</div>
        <div><div class="small muted">Cumpleaños</div>{{ver.nacimiento ? fecha(ver.nacimiento) + ' (' + edad(ver.nacimiento) + ' años)' : '—'}}</div>
        <div><div class="small muted">Vive en</div>{{[ver.ciudad, ver.pais].filter(Boolean).join(', ') || '—'}}</div>
        <div style="grid-column:1/-1"><div class="small muted">Preferencias</div>{{ver.preferencias || '—'}}</div>
        <div style="grid-column:1/-1"><div class="small muted">Notas internas</div>{{ver.notas || '—'}}</div>
        <div><div class="small muted">Estadías</div><b>{{estadiasDe(ver.id).length}}</b></div>
        <div><div class="small muted">Gasto total</div><b>{{money(gastoHuesped(ver.id), cfg.moneda)}}</b></div>
        <div v-if="archivos.documento" style="grid-column:1/-1"><div class="small muted">Documento (foto tomada al check-in)</div><img :src="archivos.documento" alt="Documento" style="max-width:100%;max-height:220px;border-radius:6px;display:block"></div>
        <div v-if="archivos.firma"><div class="small muted">Firma</div><img :src="archivos.firma" alt="Firma" style="height:60px;display:block"></div>
      </div>
      <h2 style="font-size:14px;margin:16px 0 6px">Historial de estadías</h2>
      <table class="tbl" v-if="estadiasVer.length"><thead><tr><th>Reserva</th><th>Fechas</th><th>Hab.</th><th class="num">Total</th></tr></thead><tbody><tr v-for="r in estadiasVer" :key="r.id"><td><a :href="'#/hotel/reservaciones/' + r.id" class="link">{{r.numero}}</a><div class="small muted">{{r.estado_txt}} · {{r.origen_txt}}</div></td><td>{{fecha(r.llegada)}} – {{fecha(r.salida)}}<div class="small muted">{{r.noches_n}} noche(s)</div></td><td>{{r.hab}}</td><td class="num">{{money(r.total, r.moneda)}}</td></tr></tbody></table>
      <p class="small muted" v-else>Todavía no se ha hospedado.</p>
      <p class="small" style="margin:8px 0 0"><a class="link" :href="'#/hotel/historico?q=' + encodeURIComponent(ver.documento || nombreHuesped(ver))">Ver en el histórico</a> <span class="muted">· todas sus reservas, también las canceladas y las no presentadas</span></p>
      <div v-if="reservasFuturas.length" class="small" style="margin-top:8px"><b>Próximas reservas:</b> <span v-for="(r,i) in reservasFuturas" :key="r.id"><a :href="'#/hotel/reservaciones/' + r.id" class="link">{{r.numero}}</a> ({{fecha(r.llegada)}})<span v-if="i<reservasFuturas.length-1">, </span></span></div>
      <template #foot><button class="btn danger" @click="eliminar(ver)" v-if="puedeEscribir">Eliminar</button><span style="flex:1"></span><a class="btn sec" :href="'#/hotel/reservaciones/nueva?huesped=' + ver.id" v-if="puedeEscribir">Nueva reserva</a><button class="btn" @click="editar(ver)" v-if="puedeEscribir">Editar</button></template>
    </Drawer>

    <Modal v-if="form" :title="form.id ? 'Editar huésped' : 'Nuevo huésped'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="60"></Field><Field label="Apellidos"><input v-model="form.apellidos" maxlength="60"></Field>
        <Field label="Documento"><div class="row" style="gap:6px;flex-wrap:nowrap"><select v-model="form.tipo_doc" style="width:120px"><option v-for="t in TIPOS_DOC" :key="t[0]" :value="t[0]">{{t[1]}}</option></select><input v-model="form.documento" maxlength="30" style="flex:1;min-width:0"></div></Field>
        <Field label="Nacionalidad" help="Escriba para ver coincidencias (país o gentilicio)"><input v-model="form.nacionalidad" maxlength="40" list="hotel-paises" autocomplete="off" placeholder="Costa Rica, estadounidense, alemana…"></Field>
        <Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field><Field label="Correo"><input type="email" v-model="form.correo" maxlength="80"></Field>
        <Field label="Fecha de nacimiento"><input type="date" v-model="form.nacimiento"></Field>
        <Field label="Ciudad y país"><div class="row" style="gap:6px;flex-wrap:nowrap"><input v-model="form.ciudad" placeholder="Ciudad" style="flex:1;min-width:0"><input v-model="form.pais" placeholder="País" style="flex:1;min-width:0" list="hotel-paises" autocomplete="off"></div></Field>
        <datalist id="hotel-paises"><option v-for="p in PAISES" :key="p" :value="p">{{GENTILICIOS[p] || ''}}</option></datalist>
        <Field label="Preferencias" style="grid-column:1/-1"><input v-model="form.preferencias" maxlength="200" placeholder="Almohada firme, piso alto, dieta vegetariana, cuna…"></Field>
        <Field label="Notas internas" style="grid-column:1/-1"><textarea rows="2" v-model="form.notas"></textarea></Field>
      </div>
      <div class="row" style="margin-top:10px;gap:16px"><Toggle v-model="form.vip" label="VIP"></Toggle><Toggle v-model="form.no_marketing" label="No enviar promociones"></Toggle></div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { estadiasDe, gastoHuesped }; },
};
