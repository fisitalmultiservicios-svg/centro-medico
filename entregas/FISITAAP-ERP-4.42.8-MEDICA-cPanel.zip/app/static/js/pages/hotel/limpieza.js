// Hotel › Limpieza: vista para la camarera desde el celular. Tarjetas grandes por habitación en orden de prioridad (salidas de
// hoy primero, luego sucias, ocupadas y libres), un toque para pasar a «en limpieza» o «limpia», y reporte de faltante o daño
// (deja la habitación en mantenimiento con la nota). Un rol personalizado con solo «Guardar registros» puede usar esta pantalla.
import { api, toast, money, fechaHora, hoy, mock } from '../../api.js';
import { sesion } from '../../app.js';
import ReporteProblema from './_reporte.js';
import { hotelActivo, todasHabitaciones, reservas, nombreCat, nombreEstadoHab, pisoDe, ordenHab, usuarioActual, ESTADOS_HAB, abiertosPorHab } from './_datos.js';

export default {
  props: ['params'],
  data() { return { habs: todasHabitaciones(), lista: reservas(), filtro: 'pendientes', piso: '', reporte: null, activo: hotelActivo(), reloj: Date.now(), ESTADOS_HAB, asignar: null, repartir: null, minibar: null, minibarCfg: null }; },   // asignación y minibar (3.22)
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos') || sesion.puede('limpieza'); },
    hoyS() { void this.reloj; return hoy(); },
    ocupantes() { const m = {}; for (const r of this.lista) if (r.estado === 'en_casa' && r.habitacion_id) m[r.habitacion_id] = r; return m; },
    llegadas() { const s = new Set(); for (const r of this.lista) if (['pendiente', 'confirmada'].includes(r.estado) && r.llegada === this.hoyS && r.habitacion_id) s.add(r.habitacion_id); return s; },
    pisos() { return [...new Set(this.habs.filter(h => h.activa !== false).map(pisoDe))].sort((a, b) => a.localeCompare(b, 'es', { numeric: true })); },
    tarjetas() {
      return this.habs.filter(h => h.activa !== false && (!this.piso || pisoDe(h) === this.piso)).map(h => {
        const r = this.ocupantes[h.id], estado = h.estado || 'limpia', saleHoy = !!r && r.salida <= this.hoyS;
        const prioridad = saleHoy ? 0 : estado === 'sucia' ? (this.llegadas.has(h.id) ? 1 : 2) : estado === 'limpiando' ? 3 : estado === 'inspeccion' ? 3.5 : r ? 4 : estado === 'mantenimiento' ? 6 : 5;
        const texto = saleHoy ? 'Sale hoy' + (estado === 'sucia' ? ' · por limpiar' : '') : this.llegadas.has(h.id) ? 'Llega hoy' : r ? 'Ocupada' : estado === 'limpia' ? 'Libre y limpia' : '';
        return { ...h, estado, r, saleHoy, prioridad, texto, pendiente: saleHoy || estado === 'sucia' || estado === 'limpiando' || estado === 'inspeccion' || (this.llegadas.has(h.id) && estado !== 'limpia') };
      }).filter(t => this.filtro === 'todas' || (this.filtro === 'mias' && this.esMia(t)) || (this.filtro === 'pendientes' && t.pendiente) || (this.filtro === 'ocupadas' && t.r) || (this.filtro === 'libres' && !t.r && t.estado === 'limpia'))
        .sort((a, b) => a.prioridad - b.prioridad || ordenHab(a, b));
    },
    abiertos() { void this.reloj; return abiertosPorHab(); },
    resumen() { const t = this.habs.filter(h => h.activa !== false); return { sucias: t.filter(h => h.estado === 'sucia').length, limpiando: t.filter(h => h.estado === 'limpiando').length, inspeccion: t.filter(h => h.estado === 'inspeccion').length, salen: Object.values(this.ocupantes).filter(r => r.salida <= this.hoyS).length, mant: t.filter(h => h.estado === 'mantenimiento').length }; },
    // la supervisora (quien escribe o configura) deja la habitación limpia tras la inspección; la camarera la marca «lista para inspección» (3.21)
    supervisa() { return sesion.puede('escribir') || sesion.puede('configurar') || sesion.puede('pos'); },
  },
  methods: {
    nombreCat, nombreEstadoHab, fechaHora, pisoDe, money,
    marcar(h, estado) {
      if (!this.puedeEscribir) return toast('Su rol no puede cambiar el estado de las habitaciones', 'err');
      if (!mock.puedeGuardar()) return;
      mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (x.id === h.id ? { ...x, estado, estado_hora: new Date().toISOString(), estado_usuario: usuarioActual() } : x)), []);
      this.habs = todasHabitaciones(); toast('Habitación ' + h.numero + ': ' + nombreEstadoHab(estado).toLowerCase(), 'ok');
    },
    siguiente(t) { if (t.estado === 'sucia') return this.marcar(t, 'limpiando'); if (t.estado === 'limpiando') return this.marcar(t, this.supervisa ? 'limpia' : 'inspeccion'); if (t.estado === 'inspeccion') return this.supervisa ? this.marcar(t, 'limpia') : null; if (t.estado === 'limpia' && !t.saleHoy) return this.marcar(t, 'sucia'); if (t.saleHoy && t.estado === 'limpia') return this.marcar(t, 'sucia'); },
    abrirReporte(t) { this.reporte = t; },
    // ---- asignación por camarera (3.22): la supervisora reparte; cada camarera filtra «Mías» ----
    esMia(t) { const u = sesion.usuario || {}, c = String(t.camarera || '').trim().toLowerCase(); return !!c && [u.correo, u.nombre].filter(Boolean).some(x => String(x).trim().toLowerCase() === c); },
    nombresCamareras() { return [...new Set(this.habs.map(h => (h.camarera || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es')); },
    guardarAsignacion() {
      const a = this.asignar; if (!a) return; if (!mock.puedeGuardar()) return;
      mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (x.id === a.hab.id ? { ...x, camarera: (a.nombre || '').trim() } : x)), []);
      this.habs = todasHabitaciones(); this.asignar = null; toast(a.nombre ? 'Habitación ' + a.hab.numero + ' asignada a ' + a.nombre.trim() : 'Asignación quitada', 'ok');
    },
    abrirRepartir() { this.repartir = { nombres: this.nombresCamareras().join('\n'), solo_pendientes: true }; },
    confirmarRepartir() {
      const r = this.repartir, nombres = String(r.nombres || '').split('\n').map(x => x.trim()).filter(Boolean);
      if (!nombres.length) return toast('Escriba al menos un nombre (uno por línea)', 'err');
      if (!mock.puedeGuardar()) return;
      const habs = this.habs.filter(h => h.activa !== false && (!this.piso || pisoDe(h) === this.piso)).map(h => { const t = this.tarjetas.find(x => x.id === h.id); return { h, pendiente: !!(t && t.pendiente), prioridad: t ? t.prioridad : 9 }; }).filter(x => !r.solo_pendientes || x.pendiente).sort((a, b) => a.prioridad - b.prioridad || ordenHab(a.h, b.h));
      const asig = {}; habs.forEach((x, i) => { asig[x.h.id] = nombres[i % nombres.length]; });
      mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (asig[x.id] ? { ...x, camarera: asig[x.id] } : x)), []);
      this.habs = todasHabitaciones(); this.repartir = null; toast(habs.length + ' habitación(es) repartidas entre ' + nombres.length + ' camarera(s)', 'ok');
    },
    // ---- minibar desde el celular (3.22): los ítems de la categoría del minibar se cargan a la cuenta del huésped ----
    async cargarMinibar() { try { this.minibarCfg = await api('/api/hotel/minibar'); } catch { this.minibarCfg = null; } },
    abrirMinibar(t) { if (!this.minibarCfg || !this.minibarCfg.items.length) return toast('Configure la categoría del minibar en Habitaciones y tarifas', 'err'); this.minibar = { t, cant: {}, nota: '' }; },
    minibarMas(p, d) { const c = { ...this.minibar.cant }; c[p.id] = Math.max(0, (+c[p.id] || 0) + d); if (!c[p.id]) delete c[p.id]; this.minibar.cant = c; },
    minibarTotal() { const m = this.minibar; if (!m) return 0; return Math.round(this.minibarCfg.items.reduce((s, p) => s + (+m.cant[p.id] || 0) * (+p.precio_con_iva || 0), 0) * 100) / 100; },
    async confirmarMinibar() {
      const m = this.minibar, items = Object.entries(m.cant).filter(([, q]) => +q > 0).map(([id, q]) => ({ producto_id: +id, cantidad: +q }));
      if (!items.length) return toast('Marque al menos un producto', 'err');
      try { const r = await api('/api/hotel/minibar', { method: 'POST', body: { reserva_id: m.t.r.id, items, nota: m.nota || '' } }); this.minibar = null; toast('Minibar cargado a la habitación ' + m.t.numero + ': ' + money(r.total, r.moneda), 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    refrescar() { this.habs = todasHabitaciones(); this.lista = reservas(); this.reloj = Date.now(); },
  },
  components: { ReporteProblema },
  created() { this._reloj = setInterval(() => { this.reloj = Date.now(); }, 60000); if (this.puedeEscribir) this.cargarMinibar(); },   // 3.87: quien no puede cargar el minibar (Solo lectura) no lo pide (403)
  beforeUnmount() { clearInterval(this._reloj); },
  template: `
  <div class="page limpieza">
    <PageHead title="Tablero de habitaciones" :sub="activo ? resumen.salen + ' salidas hoy · ' + resumen.sucias + ' por limpiar · ' + resumen.limpiando + ' en limpieza' + (resumen.mant ? ' · ' + resumen.mant + ' en mantenimiento' : '') : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Ama de llaves'},{label:'Tablero de habitaciones'}]">
      <a class="btn ghost sm" href="#/hotel/ama-de-llaves/incidencias">Reportes de limpieza</a><button class="btn ghost sm" v-if="supervisa" @click="abrirRepartir">Repartir el trabajo</button><button class="btn ghost sm" @click="refrescar">Actualizar</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🧹" title="El hotel no está configurado"></Empty></div>
    <template v-else>
    <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:12px">
      <div class="seg"><button :class="{on: filtro==='mias'}" @click="filtro='mias'">Mías</button><button :class="{on: filtro==='pendientes'}" @click="filtro='pendientes'">Pendientes</button><button :class="{on: filtro==='ocupadas'}" @click="filtro='ocupadas'">Ocupadas</button><button :class="{on: filtro==='libres'}" @click="filtro='libres'">Libres</button><button :class="{on: filtro==='todas'}" @click="filtro='todas'">Todas</button></div>
      <select class="inp" v-model="piso" style="padding:6px 8px"><option value="">Todos los pisos</option><option v-for="p in pisos" :key="p" :value="p">Piso {{p}}</option></select>
    </div>
    <Empty v-if="!tarjetas.length" icon="✅" title="Nada pendiente" text="No hay habitaciones por limpiar en este filtro."></Empty>
    <div class="lim-lista">
      <div v-for="t in tarjetas" :key="t.id" class="lim-card" :class="t.estado">
        <div class="lim-top"><b>{{t.numero}}</b><span class="small muted">Piso {{pisoDe(t)}} · {{nombreCat(t.categoria_id)}}</span><span class="badge" :class="t.saleHoy ? 'warn' : t.estado==='sucia' ? 'danger' : t.estado==='limpiando' ? 'warn' : t.estado==='limpia' ? 'ok' : ''">{{nombreEstadoHab(t.estado)}}</span><span class="badge danger" v-if="abiertos[t.id]" title="Reportes abiertos">⚠ {{abiertos[t.id]}}</span><span class="badge" :class="esMia(t) ? 'ok' : 'info'" v-if="t.camarera" :title="supervisa ? 'Cambiar la asignación' : ''" :style="supervisa ? 'cursor:pointer' : ''" @click="supervisa && (asignar={hab: t, nombre: t.camarera})">👤 {{t.camarera}}</span><a class="link small" v-else-if="supervisa" style="cursor:pointer" @click="asignar={hab: t, nombre: ''}">Asignar</a></div>
        <div class="small" style="margin:4px 0 8px"><b v-if="t.texto">{{t.texto}}</b><span v-if="t.r"> · {{t.r.huesped_nombre}}{{t.r.vip ? ' ★' : ''}} · sale el {{t.r.salida.split('-').reverse().join('/')}}</span><span v-if="t.r && t.r.especiales"> · {{t.r.especiales}}</span><div class="muted" v-if="t.notas" style="white-space:pre-wrap">{{t.notas.split('\\n').slice(-2).join(' · ')}}</div><div class="muted" v-if="t.estado_hora">{{nombreEstadoHab(t.estado)}} · {{fechaHora(t.estado_hora)}}{{t.estado_usuario ? ' · ' + t.estado_usuario : ''}}</div></div>
        <div class="lim-btns">
          <button class="btn" v-if="t.estado==='sucia'" @click="marcar(t,'limpiando')" :disabled="!puedeEscribir">Empezar limpieza</button>
          <button class="btn" v-if="t.estado==='limpiando' && !supervisa" @click="marcar(t,'inspeccion')" :disabled="!puedeEscribir">✓ Lista para inspección</button>
          <button class="btn" v-if="t.estado==='limpiando' && supervisa" @click="marcar(t,'limpia')" :disabled="!puedeEscribir">✓ Lista (limpia)</button>
          <button class="btn" v-if="t.estado==='inspeccion'" @click="marcar(t,'limpia')" :disabled="!puedeEscribir || !supervisa" :title="supervisa ? 'Inspeccionada: queda limpia' : 'La supervisora la revisa y la deja limpia'">✓ Inspeccionada (limpia)</button>
          <button class="btn sec" v-if="t.estado==='inspeccion'" @click="marcar(t,'limpiando')" :disabled="!puedeEscribir">Volver a limpiar</button>
          <button class="btn sec" v-if="t.estado==='limpia' || t.estado==='mantenimiento'" @click="marcar(t,'sucia')" :disabled="!puedeEscribir">Marcar sucia</button>
          <button class="btn sec" v-if="t.estado==='sucia'" @click="marcar(t,'limpia')" :disabled="!puedeEscribir">Ya está limpia</button>
          <button class="btn sec" v-if="t.estado==='mantenimiento'" @click="marcar(t,'limpia')" :disabled="!puedeEscribir">Fin del mantenimiento</button>
          <button class="btn ghost" v-if="t.r && minibarCfg && minibarCfg.items.length" @click="abrirMinibar(t)" :disabled="!puedeEscribir">Minibar</button>
          <button class="btn ghost" @click="abrirReporte(t)" :disabled="!puedeEscribir">Reportar problema</button>
        </div>
      </div>
    </div>
    </template>
    <ReporteProblema v-if="reporte" :habitacion-id="reporte.id" @close="reporte=null" @creado="refrescar"></ReporteProblema>
    <Modal v-if="asignar" :title="'Habitación ' + asignar.hab.numero" @close="asignar=null">
      <Field label="Camarera" help="El nombre o el correo con que entra al sistema; así ve sus habitaciones con el filtro «Mías»"><input v-model="asignar.nombre" maxlength="80" list="lim-camareras"><datalist id="lim-camareras"><option v-for="n in nombresCamareras()" :key="n" :value="n"></option></datalist></Field>
      <template #foot><button class="btn ghost" @click="asignar=null">Cancelar</button><button class="btn" @click="guardarAsignacion">Guardar</button></template>
    </Modal>
    <Modal v-if="repartir" title="Repartir el trabajo del día" @close="repartir=null">
      <Field label="Camareras (una por línea)" help="Nombre o correo con que entran al sistema. Las habitaciones se reparten en orden de prioridad: primero las salidas de hoy y las sucias con llegada."><textarea v-model="repartir.nombres" rows="4"></textarea></Field>
      <label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="repartir.solo_pendientes"> Solo las pendientes{{piso ? ' del piso ' + piso : ''}}</label>
      <template #foot><button class="btn ghost" @click="repartir=null">Cancelar</button><button class="btn" @click="confirmarRepartir">Repartir</button></template>
    </Modal>
    <Modal v-if="minibar" :title="'Minibar · habitación ' + minibar.t.numero" @close="minibar=null">
      <p class="small muted" style="margin:0 0 8px">{{minibar.t.r.huesped_nombre}} · se carga a su cuenta con el precio de venta.</p>
      <div v-for="p in minibarCfg.items" :key="p.id" class="row" style="justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border, #e3e7ee)"><div><b>{{p.nombre}}</b><div class="small muted">{{money(p.precio_con_iva)}}</div></div><div class="row" style="gap:6px;align-items:center"><button class="btn sm sec" @click="minibarMas(p, -1)">−</button><b style="min-width:22px;text-align:center">{{minibar.cant[p.id] || 0}}</b><button class="btn sm" @click="minibarMas(p, 1)">+</button></div></div>
      <Field label="Nota" style="margin-top:8px"><input v-model="minibar.nota" maxlength="80" placeholder="Opcional"></Field>
      <template #foot><span class="small" style="margin-right:auto">Total <b>{{money(minibarTotal())}}</b></span><button class="btn ghost" @click="minibar=null">Cancelar</button><button class="btn" @click="confirmarMinibar">Cargar a la cuenta</button></template>
    </Modal>
  </div>`,
};
