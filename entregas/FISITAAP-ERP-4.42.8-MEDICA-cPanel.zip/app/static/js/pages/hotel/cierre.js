// Hotel › Recepción › Cierre del día (3.0): la auditoría nocturna de un hotel pequeño. Lista de revisión con lo que falta antes de
// cerrar (llegadas sin registrar, salidas pendientes, huéspedes sin cargo de la noche, cuentas a favor, pagos sin cuenta, habitaciones
// sucias, reportes urgentes), corre las tareas automáticas y deja el cierre registrado con el resumen del día (hotel_cierres).
import { api, toast, money, fecha, fechaHora, hoy, sumarDias, mock, cabecerasAuth } from '../../api.js';
import { sesion } from '../../app.js';
import { config, hotelActivo, reservas, esEstadia, habitaciones, folios, folioDe, totalesFolio, totalCargo, listasDelDia, ocupacionDia, nombreHab, nombreCat, nombreOrigen, nombreEstadoHab, reportesAbiertos, usuarioActual, conceptoDe, nombreConcepto, nombreMedio, r2, paqueteCierre, hoyHotel, fechaHotelActiva, fijarFechaHotel } from './_datos.js';
import { definirReportesHotel } from './reportes.js';   /* 3.60: paquete de reportes del cierre */
import { celdaTexto } from '../reportes/_montos.js';
import { cajas as cajasPos, resumenCaja, nombreMedio as nombreMedioPos, corteDeLaCaja } from '../pos/_datos.js';   // 4.41: cierre ciego

export default {
  props: ['params'],
  data() { return { cfg: config(), dia: this.params.dia || hoyHotel(), lista: reservas(), corriendo: false, cerrando: false, cierres: mock.get('hotel_cierres', []) || [], diario: mock.get('hotel_diario', null), activo: hotelActivo(), notas: '', paquetes: [], generando: false, confirmar: null, reabrir: null }; },
  created() { this.cargarPaquetes(); },
  computed: {
    puedeEscribir() { return sesion.puede('escribir'); },   // 3.87: como el servidor (antes también la caja, que no guarda el cierre)
    esHoy() { return this.dia === hoyHotel(); },
    estadias() { return this.lista.filter(esEstadia); },
    habs() { return habitaciones(); },
    cerrado() { return this.cierres.find(c => c.fecha === this.dia) || null; },
    // lista de revisión: cada punto con las reservas o habitaciones que lo incumplen
    revision() {
      const d = this.dia, fs = folios(), est = this.estadias;
      const llegadas = est.filter(r => ['pendiente', 'confirmada'].includes(r.estado) && r.llegada <= d);
      const salidas = est.filter(r => r.estado === 'en_casa' && r.salida <= d);
      const enCasa = est.filter(r => r.estado === 'en_casa' && r.llegada <= d && d < r.salida);
      const sinNoche = enCasa.filter(r => !fs.some(f => f.reserva_id === r.id && f.tipo === 'cargo' && f.origen === 'hospedaje' && f.fecha === d));
      const aFavor = est.filter(r => r.estado === 'en_casa').filter(r => totalesFolio(folioDe(r.id)).saldo < -0.005);
      const sinCuenta = fs.filter(f => f.tipo === 'pago' && f.fecha === d && !f.cuenta && !f.deposito_id && !f.pago_numero);
      const sucias = this.habs.filter(h => h.estado === 'sucia');
      const urgentes = reportesAbiertos().filter(r => r.prioridad === 'urgente');
      const pendMan = est.filter(r => r.estado === 'pendiente' && r.llegada === sumarDias(d, 1));
      const puntos = [
        { k: 'llegadas', t: 'Llegadas sin registrar', n: llegadas.length, d: llegadas.map(r => r.numero + ' · ' + r.huesped_nombre + (r.llegada < d ? ' (desde ' + fecha(r.llegada) + ')' : '')), a: '#/hotel/recepcion', ayuda: 'Haga el check-in o márquelas como no presentadas en Reservaciones.' },
        { k: 'salidas', t: 'Salidas pendientes', n: salidas.length, d: salidas.map(r => 'Hab. ' + nombreHab(r.habitacion_id) + ' · ' + r.huesped_nombre), a: '#/hotel/recepcion', ayuda: 'Haga el check-out o extienda la estadía.' },
        { k: 'noche', t: 'Huéspedes en casa sin el cargo de la noche', n: sinNoche.length, d: sinNoche.map(r => 'Hab. ' + nombreHab(r.habitacion_id) + ' · ' + r.huesped_nombre), a: '#/hotel/recepcion', ayuda: 'Abra la cuenta y use «Extender o acortar» para regenerar las noches.' },
        { k: 'favor', t: 'Cuentas con saldo a favor del huésped', n: aFavor.length, d: aFavor.map(r => r.numero + ' · ' + r.huesped_nombre + ' · ' + money(-totalesFolio(folioDe(r.id)).saldo, r.moneda)), a: '#/hotel/recepcion', ayuda: 'Revise pagos duplicados o cargos que faltan.' },
        { k: 'pagos', t: 'Pagos de hoy sin cuenta de Bancos', n: sinCuenta.length, d: sinCuenta.map(f => (f.detalle || '') + ' · ' + money(f.monto, f.moneda)), a: '#/hotel/reportes?rep=caja_recepcion', ayuda: 'No afecta el cierre, pero ese dinero no está en Bancos.' },
        { k: 'sucias', t: 'Habitaciones sucias', n: sucias.length, d: sucias.map(h => h.numero), a: '#/hotel/ama-de-llaves/tablero', ayuda: 'Ama de llaves las marca limpias desde el tablero.' },
        { k: 'urgentes', t: 'Reportes urgentes abiertos', n: urgentes.length, d: urgentes.map(r => r.numero + ' · ' + (r.tipo || '') + (r.habitacion_id ? ' · hab. ' + nombreHab(r.habitacion_id) : '')), a: '#/hotel/mantenimiento/incidencias', ayuda: '' },
        { k: 'manana', t: 'Llegadas de mañana pendientes de adelanto', n: pendMan.length, d: pendMan.map(r => r.numero + ' · ' + r.huesped_nombre), a: '#/hotel/reservaciones?estado=pendiente', ayuda: 'Confírmelas o cóbreles el adelanto.' },
      ];
      return puntos;
    },
    bloqueantes() { return this.revision.filter(p => ['llegadas', 'salidas', 'noche'].includes(p.k) && p.n > 0); },
    resumen() {
      const d = this.dia, fs = folios().filter(f => f.fecha === d), o = ocupacionDia(d, this.estadias, this.habs), l = listasDelDia(d, this.estadias);
      const porC = {}; for (const f of fs.filter(x => x.tipo === 'cargo')) { const k = conceptoDe(f); porC[k] = r2((porC[k] || 0) + totalCargo(f)); }
      const porM = {}; for (const f of fs.filter(x => x.tipo === 'pago')) { const k = nombreMedio(f.medio); porM[k] = r2((porM[k] || 0) + (+f.monto || 0)); }
      const ing = porC.hospedaje || 0;
      return { ocupadas: o.ocupadas, total: o.total, pct: o.pct, cargos: r2(Object.values(porC).reduce((s, v) => s + v, 0)), porC, pagos: r2(Object.values(porM).reduce((s, v) => s + v, 0)), porM, adr: o.ocupadas ? r2(ing / o.ocupadas) : 0, revpar: o.total ? r2(ing / o.total) : 0,
        llegadas: this.estadias.filter(r => r.llegada === d && ['en_casa', 'salio'].includes(r.estado)).length, salidas: this.estadias.filter(r => (r.salida_real || r.salida) === d && r.estado === 'salio').length, en_casa: l.enCasa.length, no_show: this.estadias.filter(r => r.llegada === d && r.estado === 'no_show').length, creadas: this.estadias.filter(r => String(r.creado || '').slice(0, 10) === d).length };
    },
  },
  methods: {
    money, fecha, fechaHora, nombreConcepto, hoyHotel, fechaHotelActiva, sumarDias,
    // ---- paquete de reportes del cierre (3.60): un PDF con los reportes elegidos en Habitaciones y tarifas, guardado junto al cierre
    async cargarPaquetes() { try { this.paquetes = (await api('/api/hotel/cierre-paquete')).fechas || []; } catch { this.paquetes = []; } },
    tienePaquete(f) { return this.paquetes.includes(f); },
    secciones() {
      const d = this.dia, claves = paqueteCierre(this.cfg), out = [], M = v => money(v || 0, this.cfg.moneda);
      const tabla = (titulo, cols, filas, totales) => out.push({ titulo, columnas: cols.map(c => ({ key: c.key, label: c.label, num: !!c.num })), filas: filas.slice(0, 2000).map(r => Object.fromEntries(cols.map(c => [c.key, celdaTexto(r, c)]))), totales: (totales || []).map(t => ({ t: String(t.t), v: String(t.v) })) });
      const rep = (defs, k, titulo) => { const r = defs[k]; if (!r) return; const f = r.filas(); tabla(titulo + ' · ' + f.length + ' fila(s)', r.cols, f, typeof r.totales === 'function' ? r.totales(f) : []); };
      const dosDias = definirReportesHotel(this.cfg, this.lista, d, sumarDias(d, 1)), unDia = definirReportesHotel(this.cfg, this.lista, d, d);
      if (claves.includes('informe_diario')) rep(unDia, 'informe_diario', 'Informe diario');
      if (claves.includes('mano_corriente')) rep(unDia, 'mano_corriente', 'Mano corriente');
      if (claves.includes('llegadas')) rep(dosDias, 'llegadas', 'Llegadas de hoy y de mañana');
      if (claves.includes('salidas')) rep(dosDias, 'salidas', 'Salidas de hoy y de mañana');
      if (claves.includes('transporte')) rep(dosDias, 'transporte', 'Transporte de hoy y de mañana');
      if (claves.includes('en_casa')) rep(unDia, 'en_casa', 'Huéspedes en casa con saldo');
      if (claves.includes('caja_recepcion')) rep(unDia, 'caja_recepcion', 'Caja de recepción');
      if (claves.includes('habitaciones')) {
        const enCasa = this.estadias.filter(r => r.estado === 'en_casa');
        const filas = this.habs.map(h => { const r = enCasa.find(x => x.habitacion_id === h.id); return { numero: h.numero, cat: nombreCat(h.categoria_id), estado: nombreEstadoHab(h.estado), ocupada: r ? 'Ocupada' : 'Libre', huesped: r ? r.huesped_nombre : '', salida: r ? fecha(r.salida) : '' }; });
        tabla('Habitaciones por estado · ' + filas.length, [{ key: 'numero', label: 'Hab.' }, { key: 'cat', label: 'Categoría' }, { key: 'estado', label: 'Limpieza' }, { key: 'ocupada', label: 'Ocupación' }, { key: 'huesped', label: 'Huésped' }, { key: 'salida', label: 'Sale' }], filas);
      }
      if (claves.includes('no_show')) {
        const filas = this.estadias.filter(r => r.estado === 'no_show' && r.llegada === d).map(r => ({ numero: r.numero, huesped: r.huesped_nombre, hab: nombreHab(r.habitacion_id), origen: nombreOrigen(r.origen), llegada: fecha(r.llegada), salida: fecha(r.salida) }));
        tabla('No presentados del día · ' + filas.length, [{ key: 'numero', label: 'Reserva' }, { key: 'huesped', label: 'Huésped' }, { key: 'hab', label: 'Hab.' }, { key: 'origen', label: 'Origen' }, { key: 'llegada', label: 'Llegada' }, { key: 'salida', label: 'Salida' }], filas.length ? filas : [{ numero: '—', huesped: 'Ninguno', hab: '', origen: '', llegada: '', salida: '' }]);
      }
      if (claves.includes('pendientes')) {
        const filas = this.revision.filter(p => p.n > 0).map(p => ({ punto: p.t, n: p.n, detalle: p.d.slice(0, 12).join(' · ') + (p.d.length > 12 ? ' …' : '') }));
        tabla('Pendientes al cerrar · ' + filas.length, [{ key: 'punto', label: 'Punto' }, { key: 'n', label: 'Cantidad', num: true }, { key: 'detalle', label: 'Detalle' }], filas.length ? filas : [{ punto: 'Todo en orden', n: '', detalle: '' }]);
      }
      if (claves.includes('caja_pos') && sesion.puede('pos')) {
        try {
          const cs = cajasPos().filter(c => String(c.fecha || c.abierta_en || '').slice(0, 10) === d || String(c.cerrada_en || '').slice(0, 10) === d);
          /* 4.41: el paquete es un archivo que bajan otros usuarios: de una caja con cierre a ciegas (sin «el cajero ve el corte») no lleva el corte
             (lo vendido por medio de pago, el efectivo esperado, lo contado ni la diferencia), sin importar quién lo genere */
          const filas = cs.map(c => { const r = resumenCaja(c), k = corteDeLaCaja(c); return { caja: c.caja, usuario: c.usuario || '', estado: c.estado, ventas: r.ventas, total: money(r.total), medios: k ? Object.entries(r.porMedio).map(([m, v]) => nombreMedioPos(m) + ' ' + money(v)).join(', ') : '—', esperado: k ? money(r.efectivo_esperado) : '—', contado: !k ? '—' : c.conteo === null || c.conteo === undefined ? '' : money(c.conteo), diferencia: !k ? '—' : c.diferencia === null || c.diferencia === undefined ? '' : money(c.diferencia) }; });
          if (filas.length) {
            tabla('Cierre de caja del restaurante · ' + filas.length + ' sesión(es)', [{ key: 'caja', label: 'Caja' }, { key: 'usuario', label: 'Cajero' }, { key: 'estado', label: 'Estado' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Total', num: true }, { key: 'medios', label: 'Por medio de pago' }, { key: 'esperado', label: 'Efectivo esperado', num: true }, { key: 'contado', label: 'Contado', num: true }, { key: 'diferencia', label: 'Diferencia', num: true }], filas);
            if (cs.some(c => !corteDeLaCaja(c))) out[out.length - 1].nota = 'Las cajas con cierre a ciegas en las que el cajero no ve el corte salen sin su corte: la administración lo revisa en Punto de venta › Cierres de caja.';
          }
        } catch (e) { console.warn('Cierre de caja en el paquete', e); }
      }
      return out;
    },
    async generarPaquete(reg) {
      this.generando = true;
      try {
        const M = v => money(v || 0, this.cfg.moneda), r = reg.resumen || {};
        const kpis = [{ t: 'Ocupación', v: (r.ocupadas || 0) + ' de ' + (r.total || 0) + ' · ' + (r.pct || 0) + ' %' }, { t: 'Llegadas · salidas · en casa', v: (r.llegadas || 0) + ' · ' + (r.salidas || 0) + ' · ' + (r.en_casa || 0) }, { t: 'Cargos del día', v: M(r.cargos) }, { t: 'Pagos del día', v: M(r.pagos) }, { t: 'ADR · RevPAR', v: M(r.adr) + ' · ' + M(r.revpar) }];
        const res = await api('/api/hotel/cierre-paquete', { method: 'POST', body: { fecha: reg.fecha, resumen: reg.resumen, pendientes: reg.pendientes, notas: reg.notas, usuario: reg.usuario, kpis, secciones: this.secciones() } });
        await this.cargarPaquetes();
        toast('Paquete del cierre listo: PDF guardado' + (res.correo ? ' y enviado a ' + res.correo : ''), 'ok');
        if (res.correo_error) toast('El PDF quedó guardado, pero el correo no salió: ' + res.correo_error, 'err');
      } catch (e) { toast('El día quedó cerrado, pero no se pudo generar el paquete: ' + e.message, 'err'); }
      this.generando = false;
    },
    async descargarPaquete(f) {
      try {
        const r = await fetch('/api/hotel/cierre-paquete/' + f, { headers: cabecerasAuth() });
        if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || 'No se pudo descargar el paquete'); }
        const blob = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'cierre_' + f + '.pdf'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      } catch (e) { toast(e.message, 'err'); }
    },
    refrescar() { this.lista = reservas(); this.cierres = mock.get('hotel_cierres', []) || []; this.diario = mock.get('hotel_diario', null); },
    async tareas() {
      this.corriendo = true;
      try { const r = await api('/api/hotel/diario', { method: 'POST' }); await mock.refrescar(['hotel_reservas', 'hotel_folios', 'hotel_diario', 'hotel_habitaciones']); this.refrescar(); const s = r.resumen || {}; toast('Tareas automáticas: ' + (s.no_show || 0) + ' no presentado(s), ' + (s.salida_tardia || 0) + ' salida(s) tardía(s), ' + (s.recordatorios || 0) + ' recordatorio(s)', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.corriendo = false;
    },
    // 3.61: el cierre pide confirmación siempre, en una ventana que explica qué va a pasar y qué pendientes quedan
    cerrar() { if (!mock.puedeGuardar()) return; this.confirmar = { bloqueantes: this.bloqueantes.map(p => p.t.toLowerCase()), pendientes: this.revision.filter(p => p.n > 0).length, yaCerrado: !!this.cerrado }; },
    abrirReabrir() { this.reabrir = { motivo: '' }; },
    async confirmarReabrir() {
      const motivo = (this.reabrir.motivo || '').trim();
      if (motivo.length < 5) return toast('Indique el motivo de la reapertura (al menos 5 letras)', 'err');
      if (!mock.puedeGuardar()) return;
      try { await api('/api/hotel/cierre-paquete/' + this.dia + '?motivo=' + encodeURIComponent(motivo), { method: 'DELETE' }); } catch (e) { return toast('No se pudo reabrir el día: ' + e.message, 'err'); }
      mock.set('hotel_cierres', this.cierres.filter(c => c.fecha !== this.dia));
      if (fechaHotelActiva() && sumarDias(this.dia, 1) === hoyHotel()) fijarFechaHotel(this.dia, 'Reapertura del ' + this.dia);   // 3.62: la fecha del hotel vuelve al día reabierto
      this.reabrir = null; this.refrescar(); await this.cargarPaquetes();
      toast('Día ' + fecha(this.dia) + ' reabierto: haga los ajustes y vuelva a cerrarlo', 'ok');
    },
    confirmarCierre() {
      this.confirmar = null;
      this.cerrando = true;
      const reg = { id: mock.nextId(this.cierres, 'hotel_cierres'), fecha: this.dia, hora: new Date().toISOString(), usuario: usuarioActual(), resumen: this.resumen, pendientes: this.revision.filter(p => p.n > 0).map(p => ({ k: p.k, t: p.t, n: p.n })), notas: (this.notas || '').trim() };
      mock.set('hotel_cierres', [...this.cierres.filter(c => c.fecha !== this.dia), reg]);
      this.cerrando = false; this.notas = ''; this.refrescar(); toast('Día ' + fecha(this.dia) + ' cerrado: ' + money(reg.resumen.cargos, this.cfg.moneda) + ' en cargos, ' + money(reg.resumen.pagos, this.cfg.moneda) + ' en pagos, ocupación ' + reg.resumen.pct + ' %', 'ok');
      if (fechaHotelActiva() && reg.fecha === hoyHotel()) { fijarFechaHotel(sumarDias(reg.fecha, 1), 'Cierre del ' + reg.fecha); toast('La fecha del hotel pasa al ' + fecha(sumarDias(reg.fecha, 1)), 'ok'); }   // 3.62
      this.generarPaquete(reg);   // 3.60: PDF con los reportes del cierre, guardado y enviado a la gerencia si hay correo
    },
    mover(n) { this.dia = sumarDias(this.dia, n); },
  },
  template: `
  <div class="page">
    <PageHead title="Cierre del día" :sub="'Lista de revisión, tareas automáticas y cierre con el resumen del día y el paquete de reportes en PDF. ' + (fechaHotelActiva() ? 'Fecha del hotel: ' + fecha(hoyHotel()) + ' · calendario: ' + fecha(hoy()) + '.' : 'Hoy es ' + fecha(hoy()) + '.')" :crumbs="[{label:'Hotel'},{label:'Recepción',to:'/hotel/recepcion'},{label:'Cierre del día'}]">
      <button class="btn sm ghost" @click="mover(-1)">◀ Día anterior</button><input type="date" class="inp" v-model="dia" :max="hoyHotel()"><button class="btn sm ghost" @click="mover(1)" :disabled="esHoy">Día siguiente ▶</button>
      <a class="btn ghost" :href="'#/hotel/reportes?rep=informe_diario&desde=' + dia + '&hasta=' + dia">Informe diario</a>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🌙" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="alert warn" v-if="fechaHotelActiva() && sumarDias(hoyHotel(), 1) < hoy()" style="margin-bottom:12px">El hotel va atrasado: la fecha del hotel es el {{fecha(hoyHotel())}} y el calendario marca el {{fecha(hoy())}}. Cierre día por día hasta ponerse al día.</div>
    <div class="alert ok" v-if="cerrado" style="margin-bottom:12px">Día cerrado el {{fechaHora(cerrado.hora)}} por {{cerrado.usuario}}: {{money(cerrado.resumen.cargos, cfg.moneda)}} en cargos · {{money(cerrado.resumen.pagos, cfg.moneda)}} en pagos · ocupación {{cerrado.resumen.pct}} % <button class="btn sm sec" v-if="tienePaquete(dia)" @click="descargarPaquete(dia)">⤓ Paquete PDF</button><button class="btn sm ghost" v-else-if="puedeEscribir" @click="generarPaquete(cerrado)" :disabled="generando">{{generando ? 'Generando…' : 'Generar el paquete PDF'}}</button><button class="btn sm ghost" v-if="puede('configurar')" @click="abrirReabrir" title="Borra el cierre y su PDF para corregir y volver a cerrar">Reabrir el día</button><span v-if="cerrado.notas"> · {{cerrado.notas}}</span></div>
    <div class="dos">
      <div class="card" style="margin:0"><h2>Lista de revisión <small>{{revision.filter(p=>p.n>0).length ? revision.filter(p=>p.n>0).length + ' punto(s) con pendientes' : 'todo en orden'}}</small></h2>
        <div v-for="p in revision" :key="p.k" style="padding:8px 0;border-top:1px solid var(--line)">
          <div class="row" style="gap:8px;align-items:center"><span class="badge" :class="p.n ? (['llegadas','salidas','noche'].includes(p.k) ? 'danger' : 'warn') : 'ok'">{{p.n ? p.n : '✓'}}</span><b style="flex:1">{{p.t}}</b><a class="btn sm ghost" :href="p.a" v-if="p.n">Ir</a></div>
          <div class="small muted" v-if="p.n" style="margin:4px 0 0 34px">{{p.d.slice(0, 8).join(' · ')}}{{p.d.length > 8 ? ' · y ' + (p.d.length - 8) + ' más' : ''}}<span v-if="p.ayuda"><br>{{p.ayuda}}</span></div>
        </div>
      </div>
      <div class="card" style="margin:0"><h2>Resumen del {{fecha(dia)}}</h2>
        <div class="totals" style="align-items:stretch">
          <div><span>Ocupación</span><b>{{resumen.ocupadas}} de {{resumen.total}} · {{resumen.pct}} %</b></div>
          <div><span>Llegadas · salidas · en casa</span><b>{{resumen.llegadas}} · {{resumen.salidas}} · {{resumen.en_casa}}</b></div>
          <div><span>No presentados · reservas creadas</span><b>{{resumen.no_show}} · {{resumen.creadas}}</b></div>
          <div v-for="(v, k) in resumen.porC" :key="k"><span>{{nombreConcepto(k)}}</span><b>{{money(v, cfg.moneda)}}</b></div>
          <div class="total"><span>Cargos del día</span><b>{{money(resumen.cargos, cfg.moneda)}}</b></div>
          <div v-for="(v, k) in resumen.porM" :key="'m'+k"><span>Pagos · {{k}}</span><b>{{money(v, cfg.moneda)}}</b></div>
          <div class="total"><span>Pagos del día</span><b>{{money(resumen.pagos, cfg.moneda)}}</b></div>
          <div><span>Tarifa promedio (ADR) · RevPAR</span><b>{{money(resumen.adr, cfg.moneda)}} · {{money(resumen.revpar, cfg.moneda)}}</b></div>
        </div>
        <p class="small muted" style="margin:8px 0 0" v-if="diario && diario.fecha">Tareas automáticas: última pasada el {{fecha(diario.fecha)}} {{diario.hora ? fechaHora(diario.hora).slice(-5) : ''}}.</p>
        <Field label="Nota del cierre" style="margin-top:10px"><input v-model="notas" maxlength="200" placeholder="Novedades del turno, efectivo entregado…"></Field>
        <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap" v-if="puedeEscribir">
          <button class="btn sec" @click="tareas" :disabled="corriendo">{{corriendo ? 'Ejecutando…' : 'Ejecutar tareas automáticas'}}</button>
          <span style="flex:1"></span>
          <button class="btn" @click="cerrar" :disabled="cerrando || generando">{{cerrado ? 'Volver a cerrar y generar el paquete' : 'Cerrar el día y generar el paquete'}}</button>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:16px" v-if="cierres.length"><h2>Cierres anteriores</h2>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Día</th><th>Cerrado</th><th>Usuario</th><th class="num">Ocupación</th><th class="num">Cargos</th><th class="num">Pagos</th><th class="num">ADR</th><th>Pendientes al cerrar</th><th>Nota</th><th>Paquete</th></tr></thead>
        <tbody><tr v-for="c in cierres.slice().sort((a,b)=>String(b.fecha).localeCompare(String(a.fecha))).slice(0, 60)" :key="c.id"><td>{{fecha(c.fecha)}}</td><td>{{fechaHora(c.hora)}}</td><td>{{c.usuario}}</td><td class="num">{{c.resumen.pct}} %</td><td class="num">{{money(c.resumen.cargos, cfg.moneda)}}</td><td class="num">{{money(c.resumen.pagos, cfg.moneda)}}</td><td class="num">{{money(c.resumen.adr, cfg.moneda)}}</td><td class="small">{{(c.pendientes||[]).map(p=>p.n + ' ' + p.t.toLowerCase()).join(' · ') || '—'}}</td><td class="small">{{c.notas}}</td><td><button class="btn sm sec" v-if="tienePaquete(c.fecha)" @click="descargarPaquete(c.fecha)">⤓ PDF</button></td></tr></tbody></table></div>
    </div>
    </template>
    <Modal v-if="confirmar" title="Cerrar el día" @close="confirmar=null">
      <div class="alert warn"><b>Va a cerrar el {{fecha(dia)}}.</b> El cierre marca el fin del día de trabajo de recepción: antes de cerrar deje registradas todas las llegadas y salidas de hoy y los cargos de la noche.</div>
      <ul class="small" style="margin:10px 0 0 18px;padding:0">
        <li>Se registra el cierre con las cifras actuales: ocupación {{resumen.pct}} %, {{money(resumen.cargos, cfg.moneda)}} en cargos y {{money(resumen.pagos, cfg.moneda)}} en pagos.</li>
        <li>Se genera el paquete PDF con los reportes del cierre{{(cfg.correo_cierre || '').includes('@') ? ' y se envía a ' + cfg.correo_cierre : ''}}.</li>
        <li v-if="cfg.bloquear_cerrados">Nadie más podrá registrar cargos con esta fecha.</li>
        <li v-if="fechaHotelActiva() && dia === hoyHotel()"><b>La fecha del hotel pasa al {{fecha(sumarDias(dia, 1))}}:</b> las llegadas, cargos y pagos que se registren después contarán para ese día.</li>
        <li v-if="confirmar.yaCerrado">El día ya estaba cerrado: se reemplazan el cierre y el PDF.</li>
      </ul>
      <div class="alert" style="margin-top:10px" v-if="confirmar.bloqueantes.length"><b>Quedan pendientes que normalmente se resuelven antes:</b> {{confirmar.bloqueantes.join(', ')}}.</div>
      <p class="small muted" style="margin:8px 0 0">Si se equivoca, el Administrador puede reabrir el día desde esta pantalla.</p>
      <template #foot><button class="btn ghost" @click="confirmar=null">Cancelar</button><button class="btn" @click="confirmarCierre">{{confirmar.bloqueantes.length ? 'Cerrar de todos modos' : 'Cerrar el día'}}</button></template>
    </Modal>
    <Modal v-if="reabrir" title="Reabrir el día" @close="reabrir=null">
      <div class="alert warn">Se borra el cierre del {{fecha(dia)}} y su paquete PDF, y se vuelve a permitir registrar cargos con esa fecha. El correo que ya salió a la gerencia no se puede retirar. Queda en el historial de operaciones con su nombre y el motivo.</div>
      <Field label="Motivo" req style="margin-top:10px"><input v-model="reabrir.motivo" maxlength="200" placeholder="Faltaba registrar la salida de la 204…"></Field>
      <template #foot><button class="btn ghost" @click="reabrir=null">Cancelar</button><button class="btn" @click="confirmarReabrir">Reabrir el día</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy }; },
};
