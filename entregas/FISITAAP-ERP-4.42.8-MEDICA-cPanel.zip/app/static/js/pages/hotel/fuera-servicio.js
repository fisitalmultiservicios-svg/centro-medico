// Mantenimiento › Habitaciones fuera de servicio (2.4): las que están en mantenimiento (con su último reporte y notas) y los
// bloqueos de fechas por mantenimiento en el calendario; desde aquí se liberan, se bloquean fechas (una o varias habitaciones a la
// vez, H6) o se quita un bloqueo o todo su lote.
import { toast, fecha, fechaHora, mock } from '../../api.js';
import { sesion } from '../../app.js';
import BloqueoModal from './_bloqueo.js';
import { exportarTabla } from '../reportes/_montos.js';
import { hotelActivo, todasHabitaciones, reservas, nombreCat, nombreHab, usuarioActual, reportesAbiertos, ordenHab, hoyHotel, noches, nombreMotivoBloqueo, quitarBloqueos } from './_datos.js';

export default {
  props: ['params'],
  components: { BloqueoModal },
  data() { return { habs: todasHabitaciones(), lista: reservas(), activo: hotelActivo(), bloqueo: null, abiertos: [] }; },
  computed: {
    puedeEscribir() { return sesion.puede('mantenimiento') || sesion.puede('escribir'); },
    fuera() { const ab = reportesAbiertos('mantenimiento'); return this.habs.filter(h => h.activa !== false && h.estado === 'mantenimiento').sort(ordenHab).map(h => ({ ...h, reportes: ab.filter(r => r.habitacion_id === h.id) })); },
    numeros() { return new Map(this.habs.map(h => [h.id, String(h.numero)])); },
    bloqueos() { const h = hoyHotel(), n = id => this.numeros.get(id) || '—'; return this.lista.filter(r => r.tipo === 'bloqueo' && r.origen !== 'ical' && r.salida >= h).sort((a, b) => String(a.llegada).localeCompare(String(b.llegada)) || n(a.habitacion_id).localeCompare(n(b.habitacion_id), 'es', { numeric: true })); },
    // H6: los bloqueos creados juntos (el mismo lote) salen en una sola fila; un bloqueo suelto es un lote de una habitación
    lotes() {
      const m = new Map();
      for (const r of this.bloqueos) { const k = r.lote ? 'l:' + r.lote : 'b:' + r.id; if (!m.has(k)) m.set(k, { clave: k, lote: r.lote || '', llegada: r.llegada, salida: r.salida, motivo: r.motivo || '', tipo_txt: nombreMotivoBloqueo(r.motivo_tipo), bloqueos: [] }); m.get(k).bloqueos.push(r); }
      return [...m.values()].map(g => ({ ...g, n: g.bloqueos.length, habs_txt: g.bloqueos.map(b => this.numeros.get(b.habitacion_id) || '—').join(', ') }));
    },
  },
  methods: {
    fecha, fechaHora, nombreCat, nombreHab,
    refrescar() { this.habs = todasHabitaciones(); this.lista = reservas(); },
    liberar(h) { if (!confirm('¿Sacar la habitación ' + h.numero + ' de mantenimiento? Queda como sucia para que Ama de llaves la revise.')) return; mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (x.id === h.id ? { ...x, estado: 'sucia', estado_hora: new Date().toISOString(), estado_usuario: usuarioActual() } : x)), []); this.refrescar(); toast('Habitación ' + h.numero + ' liberada', 'ok'); },
    // el cuadro compartido (_bloqueo.js) propone la fecha del hotel, guarda todo el lote junto y, si se pidió, deja las habitaciones en mantenimiento
    abrirBloqueo(h) { this.bloqueo = { hab: h ? h.id : null }; },
    bloqueoListo() { this.refrescar(); this.bloqueo = null; },
    alternar(g) { const i = this.abiertos.indexOf(g.clave); if (i >= 0) this.abiertos.splice(i, 1); else this.abiertos.push(g.clave); },
    async quitarBloqueo(r) { if (!confirm('¿Quitar el bloqueo de la habitación ' + nombreHab(r.habitacion_id) + ' del ' + fecha(r.llegada) + ' al ' + fecha(r.salida) + '?')) return; const ok = await quitarBloqueos([r.id]); this.refrescar(); if (ok) toast('Bloqueo quitado', 'ok'); },
    async quitarLote(g) {
      if (g.n < 2) return this.quitarBloqueo(g.bloqueos[0]);
      if (!confirm('¿Quitar el bloqueo de las ' + g.n + ' habitaciones del lote (' + g.habs_txt + ') del ' + fecha(g.llegada) + ' al ' + fecha(g.salida) + '?')) return;
      const ok = await quitarBloqueos(g.bloqueos.map(b => b.id)); this.refrescar(); if (ok) toast('Se quitaron los ' + g.n + ' bloqueos del lote', 'ok');
    },
    exportar() {
      const cols = [{ key: 'hab', label: 'Habitación' }, { key: 'cat', label: 'Categoría' }, { key: 'llegada', label: 'Desde', fmt: 'date' }, { key: 'salida', label: 'Hasta', fmt: 'date' }, { key: 'noches_n', label: 'Noches', num: true }, { key: 'tipo_txt', label: 'Motivo' }, { key: 'motivo', label: 'Detalle' }, { key: 'lote_txt', label: 'Lote' }, { key: 'usuario', label: 'Bloqueó' }];
      const catDe = new Map(this.habs.map(h => [h.id, h.categoria_id])), filas = [];
      for (const g of this.lotes) for (const r of g.bloqueos) filas.push({ hab: this.numeros.get(r.habitacion_id) || '—', cat: nombreCat(catDe.get(r.habitacion_id)), llegada: r.llegada, salida: r.salida, noches_n: noches(r.llegada, r.salida), tipo_txt: nombreMotivoBloqueo(r.motivo_tipo), motivo: r.motivo || '', lote_txt: g.n > 1 ? g.n + ' habitaciones' : '', usuario: r.usuario || '' });
      exportarTabla('hotel_bloqueos', cols, filas, { titulo: 'Bloqueos de habitaciones', periodo: 'Vigentes al ' + fecha(hoyHotel()) });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Habitaciones fuera de servicio" :sub="activo ? fuera.length + ' en mantenimiento · ' + bloqueos.length + ' bloqueo(s) de fechas' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Mantenimiento'},{label:'Fuera de servicio'}]">
      <a class="btn ghost" href="#/hotel/mantenimiento/incidencias">Incidencias</a><button class="btn" @click="abrirBloqueo(null)" :disabled="!puedeEscribir">Bloquear fechas</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛠" title="El hotel no está configurado"></Empty></div>
    <template v-else>
    <div class="card"><h2>En mantenimiento ahora <small>no se asignan hasta liberarlas</small></h2>
      <Empty v-if="!fuera.length" icon="✅" title="Ninguna habitación en mantenimiento"></Empty>
      <table class="tbl" v-else><thead><tr><th>Hab.</th><th>Categoría</th><th>Desde</th><th>Reportes abiertos</th><th>Notas</th><th></th></tr></thead>
        <tbody><tr v-for="h in fuera" :key="h.id"><td><b>{{h.numero}}</b></td><td>{{nombreCat(h.categoria_id)}}</td><td class="small">{{h.estado_hora ? fechaHora(h.estado_hora) : '—'}}<div class="muted">{{h.estado_usuario}}</div></td><td class="small" style="white-space:normal"><div v-for="r in h.reportes" :key="r.id"><a :href="'#/hotel/mantenimiento/incidencias?q=' + r.numero" class="link">{{r.numero}}</a> {{r.tipo}}</div><span class="muted" v-if="!h.reportes.length">—</span></td><td class="small muted" style="white-space:pre-wrap;max-width:320px">{{(h.notas || '').split('\\n').slice(-2).join('\\n')}}</td><td><div class="acts"><button class="btn sm sec" @click="abrirBloqueo(h)" :disabled="!puedeEscribir">Bloquear fechas</button><button class="btn sm" @click="liberar(h)" :disabled="!puedeEscribir">Liberar</button></div></td></tr></tbody></table>
    </div>
    <div class="card"><div class="row" style="justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:8px"><h2 style="margin:0">Bloqueos de fechas <small>en el calendario de habitaciones</small></h2><button class="btn sm ghost" v-if="bloqueos.length" @click="exportar">Exportar</button></div>
      <Empty v-if="!bloqueos.length" icon="📅" title="Sin bloqueos" text="Bloquee fechas cuando una reparación o pintura tome varios días: así nadie reserva esas habitaciones."></Empty>
      <table class="tbl" v-else><thead><tr><th>Habitaciones</th><th>Desde</th><th>Hasta</th><th>Motivo</th><th></th></tr></thead>
        <tbody v-for="g in lotes" :key="g.clave">
          <tr><td style="white-space:normal"><b>{{g.n > 1 ? g.n + ' habitaciones' : g.habs_txt}}</b><div class="small muted" v-if="g.n > 1">{{g.habs_txt}}</div></td><td>{{fecha(g.llegada)}}</td><td>{{fecha(g.salida)}}</td><td style="white-space:normal">{{g.motivo}}<span class="muted" v-if="g.tipo_txt && g.tipo_txt !== g.motivo"> · {{g.tipo_txt}}</span></td>
            <td><div class="acts"><button class="btn sm ghost" v-if="g.n > 1" @click="alternar(g)">{{abiertos.includes(g.clave) ? 'Ocultar' : 'Una por una'}}</button><button class="btn sm ghost" @click="quitarLote(g)" :disabled="!puedeEscribir">{{g.n > 1 ? 'Quitar el lote' : 'Quitar'}}</button></div></td></tr>
          <template v-if="g.n > 1 && abiertos.includes(g.clave)"><tr v-for="r in g.bloqueos" :key="r.id"><td style="padding-left:28px">Hab. <b>{{nombreHab(r.habitacion_id)}}</b></td><td>{{fecha(r.llegada)}}</td><td>{{fecha(r.salida)}}</td><td></td><td><div class="acts"><button class="btn sm ghost" @click="quitarBloqueo(r)" :disabled="!puedeEscribir">Quitar</button></div></td></tr></template>
        </tbody></table>
    </div>
    </template>
    <BloqueoModal v-if="bloqueo" :lista="lista" :habs="habs" :hab-inicial="bloqueo.hab" @listo="bloqueoListo" @cerrar="bloqueo=null"></BloqueoModal>
  </div>`,
};
