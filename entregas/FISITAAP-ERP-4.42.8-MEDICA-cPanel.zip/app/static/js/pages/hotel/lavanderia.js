// Hotel › Ama de llaves › Lavandería y blancos (3.3): inventario de blancos (sábanas, toallas, fundas…) con existencias en
// bodega, en habitaciones y en lavandería; envíos y recepciones de lavandería; bajas por daño; y la lavandería de huéspedes
// (prendas recibidas y entregadas, con el cargo a la cuenta cuando hay precio). Todo vive en hotel_lavanderia.
import { toast, money, fecha, fechaHora, hoy, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { config, hotelActivo, reservas, nombreHab, usuarioActual, agregarFolio, aMonedaFolio, r2 } from './_datos.js';

const BLANCOS_BASE = ['Sábana', 'Funda de almohada', 'Toalla de baño', 'Toalla de mano', 'Toalla de piso', 'Cobija', 'Edredón', 'Protector de colchón', 'Mantel', 'Servilleta'];
const base = () => ({ blancos: [], movimientos: [], prendas: [] });

export default {
  props: ['params'],
  data() { const d = { ...base(), ...(mock.get('hotel_lavanderia', null) || {}) }; return { d, tab: 'blancos', cfg: config(), nuevoB: '', mov: null, prenda: null, activo: hotelActivo(), q: '' }; },
  computed: {
    puedeEscribir() { return sesion.puede('limpieza') || sesion.puede('escribir'); },
    blancos() { return (this.d.blancos || []).map(b => ({ ...b, total: (+b.bodega || 0) + (+b.habitaciones || 0) + (+b.lavanderia || 0), bajo: +b.minimo > 0 && (+b.bodega || 0) < +b.minimo })); },
    movimientos() { return (this.d.movimientos || []).slice().sort((a, b) => String(b.hora).localeCompare(String(a.hora))).slice(0, 200); },
    prendas() { const q = this.q.trim().toLowerCase(); return (this.d.prendas || []).filter(p => !q || [p.huesped, nombreHab(p.habitacion_id), p.detalle].some(x => String(x || '').toLowerCase().includes(q))).sort((a, b) => (a.estado === 'entregado') - (b.estado === 'entregado') || String(b.recibido).localeCompare(String(a.recibido))); },
    enCasa() { return reservas().filter(r => r.estado === 'en_casa'); },
    productos() { return (store.productos || []).filter(p => p.activo !== false && /lavand|planch|ropa|prenda/i.test(p.nombre || '')); },
    resumen() { return { tipos: this.blancos.length, bajo: this.blancos.filter(b => b.bajo).length, enLav: this.blancos.reduce((s, b) => s + (+b.lavanderia || 0), 0), prendas: (this.d.prendas || []).filter(p => p.estado !== 'entregado').length }; },
  },
  methods: {
    money, fecha, fechaHora, nombreHab,
    guardar() { if (!mock.puedeGuardar()) return false; mock.set('hotel_lavanderia', { ...this.d }); return true; },
    cargarBase() { if (this.d.blancos.length) return; this.d.blancos = BLANCOS_BASE.map((n, i) => ({ id: i + 1, nombre: n, bodega: 0, habitaciones: 0, lavanderia: 0, minimo: 0, por_habitacion: 0 })); this.guardar(); },
    agregarBlanco() { const n = (this.nuevoB || '').trim(); if (!n) return; if (this.d.blancos.some(b => b.nombre.toLowerCase() === n.toLowerCase())) return toast('Ya existe', 'err'); this.d.blancos.push({ id: this.d.blancos.reduce((m, b) => Math.max(m, b.id), 0) + 1, nombre: n, bodega: 0, habitaciones: 0, lavanderia: 0, minimo: 0, por_habitacion: 0 }); this.nuevoB = ''; this.guardar(); },
    quitarBlanco(b) { if (!confirm('¿Quitar «' + b.nombre + '» del inventario de blancos?')) return; this.d.blancos = this.d.blancos.filter(x => x.id !== b.id); this.guardar(); },
    guardarBlancos() { for (const b of this.d.blancos) { b.bodega = Math.max(0, +b.bodega || 0); b.habitaciones = Math.max(0, +b.habitaciones || 0); b.lavanderia = Math.max(0, +b.lavanderia || 0); b.minimo = Math.max(0, +b.minimo || 0); } if (this.guardar()) toast('Inventario de blancos guardado', 'ok'); },
    abrirMov(tipo) { this.mov = { tipo, blanco_id: this.d.blancos[0] ? this.d.blancos[0].id : null, cantidad: 1, nota: '' }; },
    confirmarMov() {
      const m = this.mov, b = this.d.blancos.find(x => x.id === m.blanco_id); if (!b) return toast('Elija el blanco', 'err'); const n = Math.max(0, Math.floor(+m.cantidad || 0)); if (!n) return toast('Indique la cantidad', 'err');
      // tipos: a_habitaciones (bodega→habitaciones), a_lavanderia (habitaciones→lavandería), de_lavanderia (lavandería→bodega), baja (lo que esté en lavandería o bodega), compra (→bodega)
      if (m.tipo === 'a_habitaciones') { if (b.bodega < n) return toast('No hay tanto en bodega', 'err'); b.bodega -= n; b.habitaciones += n; }
      else if (m.tipo === 'a_lavanderia') { if (b.habitaciones < n) return toast('No hay tanto en habitaciones', 'err'); b.habitaciones -= n; b.lavanderia += n; }
      else if (m.tipo === 'de_lavanderia') { if (b.lavanderia < n) return toast('No hay tanto en lavandería', 'err'); b.lavanderia -= n; b.bodega += n; }
      else if (m.tipo === 'baja') { if (b.lavanderia >= n) b.lavanderia -= n; else if (b.bodega >= n) b.bodega -= n; else return toast('No hay tanto para dar de baja', 'err'); }
      else if (m.tipo === 'compra') { b.bodega += n; }
      this.d.movimientos.push({ id: (this.d.movimientos.reduce((x, y) => Math.max(x, y.id), 0) + 1), hora: new Date().toISOString(), usuario: usuarioActual(), tipo: m.tipo, blanco: b.nombre, cantidad: n, nota: (m.nota || '').trim() });
      if (this.guardar()) { this.mov = null; toast('Movimiento registrado', 'ok'); }
    },
    nombreMov(t) { return { a_habitaciones: 'A habitaciones', a_lavanderia: 'A lavandería', de_lavanderia: 'Regresa de lavandería', baja: 'Baja por daño o pérdida', compra: 'Compra o entrada' }[t] || t; },
    // lavandería de huéspedes
    nuevaPrenda() { const r = this.enCasa[0]; this.prenda = { reserva_id: r ? r.id : null, detalle: '', piezas: 1, producto_id: null, precio: null, entrega: hoy(), nota: '' }; },
    elegirProducto() { const p = this.productos.find(x => x.id === this.prenda.producto_id); if (p) { this.prenda.precio = +p.precio || 0; if (!this.prenda.detalle) this.prenda.detalle = p.nombre; } },
    guardarPrenda() {
      const p = this.prenda, r = reservas().find(x => x.id === p.reserva_id); if (!r) return toast('Elija la habitación', 'err'); if (!(p.detalle || '').trim()) return toast('Indique las prendas', 'err');
      let cargo = null;
      if (+p.precio > 0) { const prod = this.productos.find(x => x.id === p.producto_id); const precioCRC = +p.precio, precio = prod ? (r.moneda === 'CRC' ? precioCRC : aMonedaFolio(precioCRC, r.moneda)) : +p.precio; cargo = agregarFolio({ reserva_id: r.id, tipo: 'cargo', origen: 'manual', fecha: hoy(), detalle: 'Lavandería · ' + p.detalle.trim() + ' (' + (+p.piezas || 1) + ' pieza(s))', cantidad: +p.piezas || 1, precio: r2(precio / (prod && prod.tarifa ? 1 + (+prod.tarifa || 0) / 100 : 1)), tarifa: prod ? +prod.tarifa || 0 : +this.cfg.tarifa_iva || 13, codigo_tarifa: prod ? prod.codigo_tarifa : (this.cfg.codigo_tarifa || '08'), cabys: prod ? prod.cabys : (this.cfg.cabys_hospedaje || ''), producto_id: prod ? prod.id : null, moneda: r.moneda }); }
      this.d.prendas.push({ id: (this.d.prendas.reduce((x, y) => Math.max(x, y.id), 0) + 1), reserva_id: r.id, habitacion_id: r.habitacion_id, huesped: r.huesped_nombre, detalle: p.detalle.trim(), piezas: +p.piezas || 1, precio: +p.precio || 0, entrega: p.entrega, nota: (p.nota || '').trim(), recibido: new Date().toISOString(), estado: 'recibido', usuario: usuarioActual(), folio_id: cargo ? cargo.id : null });
      if (this.guardar()) { this.prenda = null; toast('Prendas recibidas' + (cargo ? ' y cargadas a la cuenta' : ''), 'ok'); }
    },
    entregarPrenda(p) { p.estado = 'entregado'; p.entregado = new Date().toISOString(); p.entregado_por = usuarioActual(); this.guardar(); toast('Entregado a hab. ' + nombreHab(p.habitacion_id), 'ok'); },
    exportar(formato) {
      const cols = [{ key: 'nombre', label: 'Blanco' }, { key: 'bodega', label: 'Bodega', num: true }, { key: 'habitaciones', label: 'En habitaciones', num: true }, { key: 'lavanderia', label: 'En lavandería', num: true }, { key: 'total', label: 'Total', num: true }, { key: 'minimo', label: 'Mínimo en bodega', num: true }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'hotel_blancos', cols, this.blancos);
      return descargarReporte(formato, { titulo: 'Inventario de blancos · ' + (this.cfg.nombre || 'Hotel'), subtitulo: 'Bodega, habitaciones y lavandería', periodo: 'Al ' + fecha(hoy()), cols, rows: this.blancos, kpis: [{ t: 'Tipos', v: String(this.blancos.length) }, { t: 'Bajo mínimo', v: String(this.resumen.bajo) }], archivo: 'hotel_blancos' });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Lavandería y blancos" :sub="activo ? resumen.tipos + ' tipos de blancos · ' + resumen.enLav + ' piezas en lavandería · ' + resumen.bajo + ' bajo mínimo · ' + resumen.prendas + ' pedido(s) de huéspedes pendientes' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Ama de llaves'},{label:'Lavandería y blancos'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" v-if="blancos.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" v-if="blancos.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" v-if="blancos.length">CSV</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🧺" title="El hotel no está configurado"></Empty></div>
    <template v-else>
    <div class="tabs"><button :class="{on: tab==='blancos'}" @click="tab='blancos'">Inventario de blancos</button><button :class="{on: tab==='movimientos'}" @click="tab='movimientos'">Movimientos</button><button :class="{on: tab==='huespedes'}" @click="tab='huespedes'">Lavandería de huéspedes</button></div>
    <div v-if="tab==='blancos'" class="card">
      <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px"><div class="row" style="gap:6px"><button class="btn sm sec" @click="abrirMov('a_habitaciones')" :disabled="!puedeEscribir || !blancos.length">Bodega → habitaciones</button><button class="btn sm sec" @click="abrirMov('a_lavanderia')" :disabled="!puedeEscribir || !blancos.length">Habitaciones → lavandería</button><button class="btn sm sec" @click="abrirMov('de_lavanderia')" :disabled="!puedeEscribir || !blancos.length">Lavandería → bodega</button><button class="btn sm ghost" @click="abrirMov('compra')" :disabled="!puedeEscribir || !blancos.length">Entrada por compra</button><button class="btn sm ghost" @click="abrirMov('baja')" :disabled="!puedeEscribir || !blancos.length">Baja</button></div><button class="btn sm" @click="guardarBlancos" :disabled="!puedeEscribir">Guardar cantidades</button></div>
      <Empty v-if="!blancos.length" icon="🧺" title="Sin inventario de blancos" text="Cargue la lista básica (sábanas, fundas, toallas…) y anote cuántas piezas hay en bodega, en habitaciones y en lavandería."><button class="btn" @click="cargarBase" :disabled="!puedeEscribir">Cargar lista básica</button></Empty>
      <table class="tbl" v-else><thead><tr><th>Blanco</th><th class="num">Bodega</th><th class="num">En habitaciones</th><th class="num">En lavandería</th><th class="num">Total</th><th class="num">Mínimo en bodega</th><th class="num">Por habitación</th><th></th></tr></thead>
        <tbody><tr v-for="b in d.blancos" :key="b.id" :style="(+b.minimo > 0 && (+b.bodega||0) < +b.minimo) ? 'background:#fff7ed' : ''"><td><b>{{b.nombre}}</b></td><td class="num"><input class="inp" type="number" min="0" v-model.number="b.bodega" style="width:84px;text-align:right" :disabled="!puedeEscribir"></td><td class="num"><input class="inp" type="number" min="0" v-model.number="b.habitaciones" style="width:84px;text-align:right" :disabled="!puedeEscribir"></td><td class="num"><input class="inp" type="number" min="0" v-model.number="b.lavanderia" style="width:84px;text-align:right" :disabled="!puedeEscribir"></td><td class="num"><b>{{(+b.bodega||0)+(+b.habitaciones||0)+(+b.lavanderia||0)}}</b></td><td class="num"><input class="inp" type="number" min="0" v-model.number="b.minimo" style="width:84px;text-align:right" :disabled="!puedeEscribir"></td><td class="num"><input class="inp" type="number" min="0" v-model.number="b.por_habitacion" style="width:70px;text-align:right" :disabled="!puedeEscribir" title="Dotación por habitación"></td><td><button class="btn icon" @click="quitarBlanco(b)" :disabled="!puedeEscribir">✕</button></td></tr></tbody></table>
      <div class="row" style="gap:6px;margin-top:10px" v-if="blancos.length"><input class="inp" v-model="nuevoB" maxlength="40" placeholder="Otro blanco (bata, cortina de baño…)" style="flex:1;max-width:360px" @keyup.enter="agregarBlanco" :disabled="!puedeEscribir"><button class="btn sm sec" @click="agregarBlanco" :disabled="!puedeEscribir">+ Agregar</button></div>
    </div>
    <div v-if="tab==='movimientos'" class="card">
      <Empty v-if="!movimientos.length" icon="🔄" title="Sin movimientos" text="Los envíos a lavandería, las entradas y las bajas quedan aquí con hora y usuario."></Empty>
      <table class="tbl" v-else><thead><tr><th>Hora</th><th>Usuario</th><th>Movimiento</th><th>Blanco</th><th class="num">Piezas</th><th>Nota</th></tr></thead><tbody><tr v-for="m in movimientos" :key="m.id"><td class="small" style="white-space:nowrap">{{fechaHora(m.hora)}}</td><td class="small">{{m.usuario}}</td><td>{{nombreMov(m.tipo)}}</td><td>{{m.blanco}}</td><td class="num">{{m.cantidad}}</td><td class="small">{{m.nota}}</td></tr></tbody></table>
    </div>
    <div v-if="tab==='huespedes'" class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar por huésped o habitación" v-model="q"><span style="flex:1"></span><button class="btn" @click="nuevaPrenda" :disabled="!puedeEscribir || !enCasa.length">+ Recibir prendas</button></div>
      <Empty v-if="!prendas.length" icon="👕" title="Sin pedidos de lavandería" text="Reciba las prendas del huésped con la fecha de entrega; si tiene precio, el cargo va a su cuenta."></Empty>
      <table class="tbl" v-else><thead><tr><th>Recibido</th><th>Hab.</th><th>Huésped</th><th>Prendas</th><th class="num">Piezas</th><th class="num">Cargo</th><th>Entrega</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="p in prendas" :key="p.id" :style="p.estado==='entregado' ? 'opacity:.65' : ''"><td class="small">{{fechaHora(p.recibido)}}</td><td><b>{{nombreHab(p.habitacion_id)}}</b></td><td>{{p.huesped}}</td><td>{{p.detalle}}<div class="small muted" v-if="p.nota">{{p.nota}}</div></td><td class="num">{{p.piezas}}</td><td class="num">{{p.precio ? money(p.precio) : '—'}}</td><td>{{fecha(p.entrega)}}</td><td><Badge :value="p.estado==='entregado' ? 'Entregado' : 'En proceso'"></Badge></td><td><button class="btn sm" v-if="p.estado!=='entregado'" @click="entregarPrenda(p)" :disabled="!puedeEscribir">Entregado</button></td></tr></tbody></table>
    </div>
    </template>
    <Modal v-if="mov" :title="nombreMov(mov.tipo)" @close="mov=null">
      <div class="grid cols-2"><Field label="Blanco" req><select v-model="mov.blanco_id"><option v-for="b in d.blancos" :key="b.id" :value="b.id">{{b.nombre}} (bodega {{b.bodega}} · hab. {{b.habitaciones}} · lav. {{b.lavanderia}})</option></select></Field><Field label="Piezas" req><input type="number" min="1" v-model.number="mov.cantidad"></Field><Field label="Nota" style="grid-column:1/-1"><input v-model="mov.nota" maxlength="120" placeholder="Lavandería externa, piso 2, manchadas…"></Field></div>
      <template #foot><button class="btn ghost" @click="mov=null">Cancelar</button><button class="btn" @click="confirmarMov">Registrar</button></template>
    </Modal>
    <Modal v-if="prenda" title="Recibir prendas de un huésped" @close="prenda=null">
      <div class="grid cols-2">
        <Field label="Habitación" req style="grid-column:1/-1"><select v-model="prenda.reserva_id"><option v-for="r in enCasa" :key="r.id" :value="r.id">{{nombreHab(r.habitacion_id)}} · {{r.huesped_nombre}}</option></select></Field>
        <Field label="Servicio (ítem de venta)" help="Ítems con «lavandería» o «planchado» en el nombre; vacío = sin cargo o precio manual"><Buscador v-model="prenda.producto_id" :opciones="productos" :detalle="p => money(p.precio)" agregar="ítem" @change="elegirProducto"></Buscador></Field>
        <Field label="Precio por pieza (₡)" help="Vacío = sin cargo"><input type="number" min="0" step="1" v-model.number="prenda.precio"></Field>
        <Field label="Prendas" req style="grid-column:1/-1"><input v-model="prenda.detalle" maxlength="160" placeholder="2 camisas, 1 pantalón…"></Field>
        <Field label="Piezas"><input type="number" min="1" v-model.number="prenda.piezas"></Field><Field label="Entrega"><input type="date" v-model="prenda.entrega"></Field>
        <Field label="Nota" style="grid-column:1/-1"><input v-model="prenda.nota" maxlength="120" placeholder="Sin suavizante, urgente…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="prenda=null">Cancelar</button><button class="btn" @click="guardarPrenda">Recibir</button></template>
    </Modal>
  </div>`,
};
