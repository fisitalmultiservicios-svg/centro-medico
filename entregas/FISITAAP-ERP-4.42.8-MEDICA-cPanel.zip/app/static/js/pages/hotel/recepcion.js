// Hotel › Recepción (front desk): tablero del día con llegadas, salidas y huéspedes en casa (tres widgets de igual altura con su
// propio desplazamiento), check-in con asignación de habitación, cuenta del huésped (cargos por noche, consumos del restaurante,
// cargos manuales, pagos), cambio de habitación, extensión de la estadía, check-out con factura o tiquete electrónico y cobro del
// saldo, huésped sin reserva (walk-in) y tablero de limpieza por piso.
import { api, toast, money, fmt, fecha, fechaHora, hoy, sumarDias, mock, monedas, CAT, precioCliente, otroImpLinea } from '../../api.js';
import { sesion, store } from '../../app.js';
import { cuentasParaMovimientos, cuentaPrincipal, cuentaParaMedio } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta
import ReporteProblema from './_reporte.js';
import { config, hotelActivo, habitaciones, todasHabitaciones, reservas, reserva, huesped, categoria, listasDelDia, ocupacionDia, folioDe, folios, totalesFolio, totalCargo, agregarFolio, quitarFolio, registrarPago, anularPago, sincronizarHospedaje, cambiarReserva, anotar, disponibles, noches, nombreHab, nombreCat, nombreHuesped, nombreMedio, MEDIOS, ESTADOS, ESTADOS_HAB, nombreEstadoHab, numeroVisita, insignia, textoVisita, pisoDe, ordenHab, usuarioActual, abrirHoja, tarjetaRegistroHTML, estadoCuentaHTML, enlaceWhatsApp, textoConfirmacion, textoMensaje, cotizar, crearDeposito, nuevaCuentaExterna, guardarReserva, capacidadHab, archivoHuesped, r2, fechaCorta, claseEstado, nombreOrigen, origenCorto, CABYS_HOSPEDAJE, abiertosPorHab, descripcionHab, MONEDAS_HOTEL, tcPago, convertirPago, equivalente, textoCambio, trasladarCargo, depositosPara, aplicarDeposito, depositoDisponible, cambiarFolio, agenciaDe, esCargoAgencia, hoyHotel, fechaHotelActiva, alertasHotel, habitacionesFuera } from './_datos.js';

const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());

export default {
  props: ['params'],
  data() {
    return { cfg: config(), lista: reservas(), habs: todasHabitaciones(), selId: this.params.reserva ? +this.params.reserva : null, activo: hotelActivo(), cuentas: [], reloj: Date.now(),
      checkin: null, cargo: null, pago: null, checkout: null, cambio: null, extender: null, habMenu: null, procesando: false, reporte: null, MEDIOS, ESTADOS_HAB, MONEDAS_HOTEL, exos: [], tarifas: CAT.tarifaIvaLista, pisoFiltro: '', traslado: null, deposito: null,
      vistaMovil: 'llegadas', enlaceDoc: '', separar: null, ocultarAlertas: false };   // pestañas del tablero en el celular y enlace público del comprobante del check-out (3.21); hospedaje a otra cuenta (3.22)
  },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    puedeFacturar() { return sesion.puede('facturar') || sesion.puede('pos'); },
    hoyS() { void this.reloj; return hoyHotel(); },   // 3.62: fecha del hotel si está activa
    hoyCal() { void this.reloj; return hoy(); },
    dia() { return listasDelDia(this.hoyS, this.lista); },
    ocup() { return ocupacionDia(this.hoyS, this.lista, this.habs.filter(h => h.activa !== false)); },
    abiertos() { void this.reloj; return abiertosPorHab(); },
    // H7: alertas del día (el recepcionista no ve Inicio) y habitaciones en mantenimiento sin bloqueo de fechas; se calculan al cambiar
    // la lista o cada minuto, no en cada repintado
    alertas() { void this.reloj; return alertasHotel(this.hoyS, this.lista, this.cfg); },
    fueraServicio() { void this.reloj; return habitacionesFuera(this.hoyS, this.lista, this.habs); },
    porLimpiar() { return this.habs.filter(h => h.activa !== false && h.estado === 'sucia').length; },
    sel() { return this.selId ? this.lista.find(r => r.id === this.selId) || null : null; },
    selH() { return this.sel && this.sel.huesped_id ? huesped(this.sel.huesped_id) : null; },
    folio() { return this.sel ? folioDe(this.sel.id) : []; },
    tot() { return totalesFolio(this.folio); },
    cargos() { return this.folio.filter(f => f.tipo === 'cargo'); },
    pagos() { return this.folio.filter(f => f.tipo === 'pago'); },
    visitaSel() { return this.sel ? numeroVisita(this.sel, this.lista) : 1; },
    esLlegada() { return !!this.sel && ['pendiente', 'confirmada'].includes(this.sel.estado); },
    enCasa() { return !!this.sel && this.sel.estado === 'en_casa'; },
    esExterna() { return !!this.sel && this.sel.tipo === 'folio'; },           // cuenta externa sin habitación (3.0)
    activa() { return !!this.sel && (['en_casa', 'confirmada', 'pendiente'].includes(this.sel.estado) || (this.esExterna && this.sel.estado === 'abierto')); },
    cargosPendientes() { return this.cargos.filter(f => !f.documento_id); },  // sin facturar (facturar parte de la cuenta, 3.0)
    destinosTraslado() { return this.lista.filter(r => r.id !== (this.sel && this.sel.id) && ((r.estado === 'en_casa' && r.tipo !== 'bloqueo') || (r.tipo === 'folio' && r.estado === 'abierto'))); },
    depositosDisp() { return this.sel ? depositosPara(this.sel) : []; },
    // habitaciones para el check-in: libres en las noches de la estadía, primero las de la categoría y limpias
    habsCheckin() {
      if (!this.sel) return [];
      const libres = disponibles(null, this.sel.llegada, this.sel.salida, this.sel.id, this.lista);
      const peso = h => (h.categoria_id === this.sel.categoria_id ? 0 : 10) + (h.estado === 'limpia' || !h.estado ? 0 : h.estado === 'limpiando' ? 1 : h.estado === 'sucia' ? 2 : 5);
      return libres.slice().sort((a, b) => peso(a) - peso(b) || ordenHab(a, b)).map(h => ({ ...h, peso: peso(h) }));
    },
    habsCambio() { if (!this.sel) return []; return disponibles(null, this.hoyS, this.sel.salida, this.sel.id, this.lista).filter(h => h.id !== this.sel.habitacion_id).sort(ordenHab); },
    productos() { return (store.productos || []).filter(p => p.activo !== false && p.es_venta !== false); },   // sin insumos (3.18)
    clientes() { return (store.clientes || []).filter(c => c.activo !== false && c.tipo !== 'Proveedor'); },
    pisos() { const m = new Map(); for (const h of this.habs.filter(x => x.activa !== false).sort(ordenHab)) { const p = pisoDe(h); if (!m.has(p)) m.set(p, []); m.get(p).push(h); } return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0], 'es', { numeric: true })).map(([nombre, habs]) => ({ nombre, habs })); },
    ocupantes() { const m = {}; for (const r of this.lista) if (r.estado === 'en_casa' && r.habitacion_id) m[r.habitacion_id] = r; return m; },
    saleHoy() { const s = new Set(); for (const r of this.lista) if (r.estado === 'en_casa' && r.salida <= this.hoyS && r.habitacion_id) s.add(r.habitacion_id); return s; },
    llegaHoy() { const s = new Set(); for (const r of this.lista) if (['pendiente', 'confirmada'].includes(r.estado) && r.llegada === this.hoyS && r.habitacion_id) s.add(r.habitacion_id); return s; },
    // check-out individual o de grupo (cuenta maestra, 2.3): las reservas que se cierran juntas y la suma de sus cuentas
    grupoSel() { return this.sel && this.sel.grupo ? this.lista.filter(r => r.estado === 'en_casa' && r.grupo === this.sel.grupo && r.tipo !== 'bloqueo') : []; },
    coReservas() { return this.checkout && this.checkout.ids ? this.checkout.ids.map(id => this.lista.find(r => r.id === id)).filter(Boolean) : (this.sel ? [this.sel] : []); },
    coFolio() { const ids = new Set(this.coReservas.map(r => r.id)); return folios().filter(f => ids.has(f.reserva_id)); },
    // solo lo que no se ha facturado y los pagos que no se han aplicado a una factura anterior (facturación parcial, 3.0)
    // con contrato de tarifa neta (3.1) el hospedaje y los cargos automáticos no van a la factura del huésped: quedan a crédito de la agencia
    agenciaSel() { return this.sel && this.sel.agencia_id ? agenciaDe(this.sel.agencia_id) : null; },
    agenciaNeta() { return !!(this.agenciaSel && this.agenciaSel.modalidad === 'neta'); },
    coCargosAgencia() { return this.coFolio.filter(f => f.tipo === 'cargo' && !f.documento_id && esCargoAgencia(f, this.coReservas.find(r => r.id === f.reserva_id) || this.sel)); },
    coCargos() { const l = this.coFolio.filter(f => f.tipo === 'cargo' && !f.documento_id && !esCargoAgencia(f, this.coReservas.find(r => r.id === f.reserva_id) || this.sel)); return this.checkout && this.checkout.parcial ? l.filter(f => this.checkout.seleccion.includes(f.id)) : l; },
    coPagos() { return this.checkout && this.checkout.parcial ? [] : this.coFolio.filter(f => f.tipo === 'pago' && !f.aplicado_en); },
    coTot() { return totalesFolio([...this.coCargos, ...this.coPagos]); },
    coCargosTodos() { return this.coFolio.filter(f => f.tipo === 'cargo' && !f.documento_id); },
    esGrupo() { return this.coReservas.length > 1; },
    checkoutTot() {
      if (!this.checkout) return null;
      const co = this.checkout, saldo = this.coTot.saldo;
      const partes = saldo > 0 ? [{ medio: co.medio, moneda_pago: co.moneda_pago || this.sel.moneda, monto_pago: +co.monto_pago || 0, cuenta: co.cuenta, referencia: co.referencia }, ...(co.extra || []).filter(x => +x.monto_pago > 0)] : [];
      const cobro = r2(partes.reduce((s, p) => s + convertirPago(p.monto_pago, p.moneda_pago, this.sel.moneda), 0));
      const sobra = r2(Math.max(0, cobro - saldo)), efectivo = partes.some(p => p.medio === '01');
      return { saldo, cobro, falta: r2(Math.max(0, saldo - cobro)), previos: this.coTot.pagos, otraMoneda: partes.some(p => p.moneda_pago !== this.sel.moneda), varios: partes.length > 1, partes, cambio: efectivo ? sobra : 0, excede: !efectivo && sobra > 0.005 };
    },
    exoSel() { return this.checkout && this.checkout.exo_id ? this.exos.find(x => x.id === this.checkout.exo_id) || null : null; },
  },
  watch: {
    'checkout.cliente_id'(v) { this.cargarExos(v); },
    // 4.5: el medio decide la cuenta de Bancos propuesta: efectivo → cuenta de Efectivo; tarjeta, SINPE o transferencia → Banco (antes la tarjeta caía en la caja)
    'pago.medio'(m) { if (this.pago) { const b = cuentaParaMedio(m, this.pago.moneda_pago || (this.sel || {}).moneda, this.cuentas); if (b) this.pago.cuenta = b.nombre; } },
    'checkout.medio'(m) { if (this.checkout) { const b = cuentaParaMedio(m, this.checkout.moneda_pago || (this.sel || {}).moneda, this.cuentas); if (b) this.checkout.cuenta = b.nombre; } },
  },
  methods: {
    fechaHotelActiva,
    agregarMedioCheckout() { const co = this.checkout, t = this.checkoutTot; co.extra.push({ medio: '01', moneda_pago: this.sel.moneda, monto_pago: t ? t.falta : 0, cuenta: (cuentaParaMedio('01', this.sel.moneda, this.cuentas) || {}).nombre || '', referencia: '' }); },
    // 4.5: en el cobro mixto el medio (y la moneda) de cada fila también deciden la cuenta de Bancos propuesta
    cuentaMedioExtra(x, medio, moneda) { const b = cuentaParaMedio(medio || x.medio, moneda || x.moneda_pago || this.sel.moneda, this.cuentas); if (b) x.cuenta = b.nombre; },
    equivalente,
    money, fmt, fecha, fechaHora, nombreHab, nombreCat, nombreHuesped, nombreMedio, nombreEstadoHab, descripcionHab, insignia, textoVisita, totalCargo, pisoDe, claseEstado, nombreOrigen, origenCorto, noches, depositoDisponible, esCargoAgencia,
    refrescar() { this.lista = reservas(); this.habs = todasHabitaciones(); },
    elegir(r) { this.selId = r ? r.id : null; this.checkin = null; this.cargarEnlace(); },
    saldoDe(r) { const t = totalesFolio(folioDe(r.id)); return r.estado === 'en_casa' ? t.saldo : Math.max(0, (+r.total || 0) - t.pagos); },
    pagadoDe(r) { return totalesFolio(folioDe(r.id)).pagos; },
    atrasada(r) { return r.llegada < this.hoyS; },
    waLink(r) { const h = r.huesped_id ? huesped(r.huesped_id) : null; return h && h.telefono ? enlaceWhatsApp(h.telefono, 'Hola ' + (h.nombre || '') + ', le saluda ' + (this.cfg.nombre || 'el hotel') + '. ' + (this.cfg.wifi ? '\n' + this.cfg.wifi : '')) : ''; },
    // WhatsApp de salida con el enlace público del comprobante (3.21): el enlace se pide al servidor al abrir la cuenta de quien ya salió
    waSalida(r) { const h = r.huesped_id ? huesped(r.huesped_id) : null; return h && h.telefono ? enlaceWhatsApp(h.telefono, textoMensaje(this.cfg.mensaje_salida, r, this.cfg, { enlace: this.enlaceDoc || '' })) : ''; },
    async cargarEnlace() { this.enlaceDoc = ''; const r = this.sel; if (!r || !r.documento_id || !['salio', 'cerrado'].includes(r.estado)) return; try { const x = await api('/api/comprobantes/' + r.documento_id + '/enlace'); this.enlaceDoc = x.url || ''; } catch { this.enlaceDoc = ''; } },
    // ---- check-in ----
    abrirCheckin(r) {
      this.selId = r.id; const h = r.huesped_id ? huesped(r.huesped_id) : null;
      const prefer = this.habsCheckin.find(x => x.id === r.habitacion_id) || this.habsCheckin.find(x => x.peso === 0) || null;
      this.checkin = { habitacion_id: prefer ? prefer.id : null, documento: (h && h.documento) || '', telefono: (h && h.telefono) || '', vehiculo: r.vehiculo || '', acompanantes: r.acompanantes || '', llaves: 1, garantia: '', notas: '', imprimir: false, upgrade: 'cortesia', firma: null, foto: null };
    },
    async registrarLlegada() {
      const c = this.checkin, r = this.sel; if (!c || !r) return;
      if (!c.habitacion_id) return toast('Asigne la habitación', 'err');
      const hab = this.habs.find(h => h.id === c.habitacion_id);
      if (!this.habsCheckin.some(h => h.id === c.habitacion_id)) return toast('La habitación ' + (hab ? hab.numero : '') + ' no está libre para estas noches', 'err');
      if (hab && hab.estado && hab.estado !== 'limpia' && !confirm('La habitación ' + hab.numero + ' está marcada como «' + nombreEstadoHab(hab.estado) + '». ¿Registrar la llegada de todos modos?')) return;
      if (!mock.puedeGuardar()) return;
      this.procesando = true;
      try {
        if (r.huesped_id && (c.documento || c.telefono)) mock.actualizar('hotel_huespedes', l => (l || []).map(x => (x.id === r.huesped_id ? { ...x, documento: c.documento || x.documento, telefono: c.telefono || x.telefono } : x)), []);
        let llegada = r.llegada; if (llegada > this.hoyS) llegada = this.hoyS;      // llegó antes de la fecha prevista
        // habitación de otra categoría (3.22): de cortesía (se mantiene el precio) o cobrando la tarifa de la categoría nueva
        let extra = {}, notaCat = '';
        if (hab && r.categoria_id && hab.categoria_id !== r.categoria_id) {
          if (c.upgrade === 'cobrar') { const cot = cotizar({ categoria_id: hab.categoria_id, llegada, salida: r.salida, plan_id: r.plan_id, personas: (+r.adultos || 0) + (+r.ninos || 0), precio_manual: null, capacidad: capacidadHab(hab) }, this.cfg); extra = { categoria_id: hab.categoria_id, tarifa_noche: cot.promedio, neto: cot.neto, iva: cot.iva, total: cot.total, precio_manual: null }; notaCat = ' · categoría ' + nombreCat(hab.categoria_id) + ' cobrada a ' + money(cot.promedio, r.moneda) + ' por noche'; }
          else notaCat = ' · categoría ' + nombreCat(hab.categoria_id) + ' de cortesía (se mantiene el precio de ' + nombreCat(r.categoria_id) + ')';
        }
        if (c.firma) extra.firmado = true;   // firma digital en la tarjeta de registro (3.22)
        const { reg, promesa } = cambiarReserva(r.id, x => anotar({ ...x, ...extra, estado: 'en_casa', habitacion_id: c.habitacion_id, llegada, checkin: new Date().toISOString(), vehiculo: c.vehiculo, acompanantes: c.acompanantes, llaves: +c.llaves || 1, garantia: c.garantia, notas: [x.notas, c.notas].filter(Boolean).join('\n'), preasignada: undefined }, 'Check-in en la habitación ' + (hab ? hab.numero : '') + notaCat));
        if (!(await promesa)) { this.procesando = false; return; }
        sincronizarHospedaje(reg, this.cfg);
        this.refrescar(); this.checkin = null; this.selId = reg.id;
        toast('Bienvenido ' + reg.huesped_nombre + ' · habitación ' + (hab ? hab.numero : ''), 'ok');
        this.subirArchivos(reg, c); if (c.imprimir) this.tarjeta(reg, c.firma);
      } catch (e) { toast(e.message, 'err'); }
      this.procesando = false;
    },
    // tarjeta de registro: con la firma digital si el huésped firmó en pantalla (3.22); al reimprimir se trae la firma guardada
    tarjeta(r, firma) {
      const x = r || this.sel, h = x.huesped_id ? huesped(x.huesped_id) : null;
      if (firma || !x.firmado || !x.huesped_id) return abrirHoja('Tarjeta de registro ' + x.numero, tarjetaRegistroHTML(x, h, firma || null));
      archivoHuesped(x.huesped_id, 'firma').then(f => abrirHoja('Tarjeta de registro ' + x.numero, tarjetaRegistroHTML(x, h, f)));
    },
    // firma con el dedo o el mouse y foto del documento (3.22): se suben al servidor al confirmar el check-in
    firmaCtx() { const c = this.$refs.firma; if (!c) return null; const k = c.getContext('2d'); k.lineWidth = 2.2; k.lineCap = 'round'; k.lineJoin = 'round'; k.strokeStyle = '#1d2433'; return k; },
    firmaPos(e) { const c = this.$refs.firma, b = c.getBoundingClientRect(); return [(e.clientX - b.left) * c.width / b.width, (e.clientY - b.top) * c.height / b.height]; },
    firmaInicio(e) { const k = this.firmaCtx(); if (!k) return; e.preventDefault(); this._firmando = true; const [x, y] = this.firmaPos(e); k.beginPath(); k.moveTo(x, y); },
    firmaTrazo(e) { if (!this._firmando) return; e.preventDefault(); const k = this.firmaCtx(); const [x, y] = this.firmaPos(e); k.lineTo(x, y); k.stroke(); this._firmaTrazos = (this._firmaTrazos || 0) + 1; },
    firmaFin() { if (!this._firmando) return; this._firmando = false; if ((this._firmaTrazos || 0) > 2 && this.checkin && this.$refs.firma) this.checkin.firma = this.$refs.firma.toDataURL('image/png'); },
    firmaLimpiar() { const c = this.$refs.firma; if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height); this._firmaTrazos = 0; if (this.checkin) this.checkin.firma = null; },
    fotoDoc(e) {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      const img = new Image(), u = URL.createObjectURL(f);
      img.onload = () => { const k = Math.min(1, 1200 / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); if (this.checkin) this.checkin.foto = c.toDataURL('image/jpeg', 0.82); URL.revokeObjectURL(u); };
      img.onerror = () => { URL.revokeObjectURL(u); toast('No se pudo leer la imagen', 'err'); };
      img.src = u;
    },
    async subirArchivos(r, c) {
      if (!r || !r.huesped_id) return;
      for (const [tipo, datos] of [['firma', c.firma], ['documento', c.foto]]) {
        if (!datos) continue;
        try { await api('/api/hotel/huespedes/' + r.huesped_id + '/archivo', { method: 'POST', body: { tipo, datos } }); } catch (e) { toast('No se guardó ' + (tipo === 'firma' ? 'la firma' : 'la foto del documento') + ': ' + e.message, 'err'); }
      }
    },
    estadoCuenta() { const r = this.sel; abrirHoja('Estado de cuenta ' + r.numero, estadoCuentaHTML(r, this.selH, this.folio)); },
    // ---- cargos ----
    // el precio del cargo manual se escribe como lo cobra el hotel (3.21): con IVA incluido (lo habitual) o sin IVA; se guarda sin IVA a 5 decimales
    abrirCargo() { this.cargo = { producto_id: null, detalle: '', cantidad: 1, precio: null, con_iva: this.cfg.precios_incluyen_iva !== false, codigo_tarifa: this.cfg.codigo_tarifa || '08', tarifa: +this.cfg.tarifa_iva || 13, cabys: '', fecha: this.hoyS, nota: '', otro_impuesto: null }; },
    elegirProducto() { const p = this.productos.find(x => x.id === this.cargo.producto_id); if (!p) return; this.cargo.detalle = p.nombre; this.cargo.cabys = p.cabys; this.cargo.codigo_tarifa = p.codigo_tarifa; this.cargo.tarifa = +p.tarifa || 0; this.cargo.otro_impuesto = p.otro_impuesto || null; const neto = r2(precioCliente(p, null, this.sel.moneda)); /* según la moneda del ítem (3.25) */ this.cargo.precio = this.cargo.con_iva ? r2(this.conImpCargo(neto)) : neto; },
    // precio de una unidad con IVA y, si el ítem lo lleva, Selectivo o impuesto específico (3.41)
    conImpCargo(p) { const c = this.cargo, oi = otroImpLinea(c.otro_impuesto, 1, p, this.sel && this.sel.moneda !== 'CRC' ? (+monedas.tc(this.sel.moneda) || 1) : 1); return p + oi.monto + (p + oi.base) * (+c.tarifa || 0) / 100; },
    // precio escrito con impuestos → sin impuestos: el total es lineal en el precio
    precioNetoCargo() { const c = this.cargo; const p = +c.precio || 0; if (!c.con_iva) return p; const t0 = this.conImpCargo(0), a = this.conImpCargo(1) - t0; return a > 0 ? Math.round(Math.max(0, (p - t0) / a) * 100000) / 100000 : p; },
    tarifaCargo() { this.cargo.tarifa = CAT.tarifaPct[this.cargo.codigo_tarifa] ?? 0; },
    guardarCargo() {
      const c = this.cargo; if (!(c.detalle || '').trim()) return toast('Indique el detalle', 'err'); if (!(+c.cantidad > 0)) return toast('Indique la cantidad', 'err'); if (c.precio === null || c.precio === '' || isNaN(+c.precio)) return toast('Indique el precio', 'err');
      if (!c.producto_id && !/^\d{13}$/.test(String(c.cabys || ''))) c.cabys = this.cfg.cabys_hospedaje || CABYS_HOSPEDAJE;
      if (this.diaCerrado(c.fecha)) return toast('El ' + fecha(c.fecha) + ' ya está cerrado: registre el cargo con fecha de hoy o pida a quien configura que reabra el día', 'err');
      if (!mock.puedeGuardar()) return;
      agregarFolio({ reserva_id: this.sel.id, tipo: 'cargo', origen: 'manual', fecha: c.fecha || this.hoyS, detalle: c.detalle.trim() + (c.nota ? ' · ' + c.nota : ''), cantidad: +c.cantidad, precio: this.precioNetoCargo(), tarifa: +c.tarifa || 0, codigo_tarifa: c.codigo_tarifa, cabys: c.cabys, producto_id: c.producto_id || null, otro_impuesto: c.otro_impuesto || null, moneda: this.sel.moneda });
      this.cargo = null; toast('Cargo agregado a la cuenta', 'ok');
    },
    // días cerrados (3.22): con el bloqueo activo, solo quien configura registra cargos con fecha de un día ya cerrado
    diaCerrado(f) { if (!this.cfg.bloquear_cerrados || sesion.puede('configurar')) return false; const cierres = mock.get('hotel_cierres', []) || []; return cierres.some(c => c.fecha === f); },
    // hospedaje a otra cuenta (3.22): la empresa paga la habitación (y los cargos automáticos) y el huésped solo los extras
    abrirSeparar() { this.separar = { cliente_id: this.sel.cliente_id || null, nombre: '' }; },
    async confirmarSeparar() {
      const r = this.sel, sp = this.separar; const cli = sp.cliente_id ? this.clientes.find(c => c.id === sp.cliente_id) : null;
      if (!cli && !(sp.nombre || '').trim()) return toast('Elija el contacto o escriba el nombre de la cuenta', 'err');
      if (!mock.puedeGuardar()) return;
      const base = nuevaCuentaExterna(this.cfg);
      const { reg: ce, promesa } = guardarReserva(anotar({ ...base, huesped_nombre: cli ? cli.nombre : sp.nombre.trim(), cliente_id: cli ? cli.id : null, huesped_id: null, segmento: 'Corporativo', moneda: r.moneda, notas: 'Hospedaje de ' + r.numero + ' · ' + (r.huesped_nombre || '') + ' · hab. ' + nombreHab(r.habitacion_id) }, 'Cuenta abierta para el hospedaje de ' + r.numero));
      if (!(await promesa)) return;
      const cargos = folioDe(r.id).filter(f => f.tipo === 'cargo' && ['hospedaje', 'auto'].includes(f.origen) && !f.documento_id);
      for (const f of cargos) cambiarFolio(f.id, { reserva_id: ce.id, reserva_origen_id: r.id, traslado_de: r.id, detalle: String(f.detalle || '') + ' · ' + (r.huesped_nombre || '') });
      await cambiarReserva(r.id, x => anotar({ ...x, cuenta_hospedaje_id: ce.id }, 'Hospedaje y cargos automáticos pasan a la cuenta ' + ce.numero + ' (' + ce.huesped_nombre + '); el huésped paga solo sus extras')).promesa;
      this.refrescar(); this.separar = null; toast('Hospedaje en la cuenta ' + ce.numero + '. Se cierra y factura desde Cuentas externas.', 'ok');
    },
    // traslado de un cargo a otra cuenta en casa o a una cuenta externa (3.0)
    abrirTraslado(f) { this.traslado = { f, destino_id: null }; },
    confirmarTraslado() { const t = this.traslado, dest = this.lista.find(r => r.id === t.destino_id); if (!dest) return toast('Elija la cuenta de destino', 'err'); if (!mock.puedeGuardar()) return; trasladarCargo(t.f, this.sel, dest); cambiarReserva(this.sel.id, x => anotar(x, 'Cargo «' + t.f.detalle + '» trasladado a ' + dest.numero)); cambiarReserva(dest.id, x => anotar(x, 'Cargo «' + t.f.detalle + '» recibido de ' + this.sel.numero)); this.traslado = null; toast('Cargo trasladado a ' + dest.numero, 'ok'); },
    // deshacer un check-in hecho por error (3.0): la reserva vuelve a confirmada, se quitan las noches y los cargos automáticos; los pagos y consumos quedan
    async deshacerCheckin() {
      const r = this.sel; if (!r) return;
      if (!confirm('¿Deshacer el check-in de ' + r.huesped_nombre + '? La reserva vuelve a confirmada, se quitan las noches cargadas y los cargos automáticos; los pagos y los consumos se conservan.')) return;
      if (!mock.puedeGuardar()) return;
      for (const f of folioDe(r.id).filter(f => f.tipo === 'cargo' && ['hospedaje', 'auto'].includes(f.origen) && !f.documento_id)) quitarFolio(f.id);
      const { promesa } = cambiarReserva(r.id, x => anotar({ ...x, estado: 'confirmada', checkin: null }, 'Check-in deshecho'));
      if (await promesa) { if (r.habitacion_id) this.marcarHab(r.habitacion_id, 'sucia'); this.refrescar(); toast('Check-in deshecho: la reserva vuelve a confirmada', 'ok'); }
    },
    // aplicar un depósito en garantía disponible a la cuenta (3.0)
    abrirDeposito() { const d = this.depositosDisp[0]; this.deposito = { id: d ? d.id : null, monto: d ? Math.min(depositoDisponible(d), Math.max(0, this.saldoDe(this.sel)) || depositoDisponible(d)) : 0 }; },
    cambiarDep() { const d = this.depositosDisp.find(x => x.id === this.deposito.id); this.deposito.monto = d ? Math.min(depositoDisponible(d), Math.max(0, this.saldoDe(this.sel)) || depositoDisponible(d)) : 0; },
    confirmarDeposito() {
      const d = this.depositosDisp.find(x => x.id === this.deposito.id); if (!d) return toast('Elija el depósito', 'err'); const m = +this.deposito.monto || 0; if (!(m > 0) || m > depositoDisponible(d) + 0.005) return toast('El monto debe ser mayor que cero y no superar lo disponible', 'err');
      if (!mock.puedeGuardar()) return;
      const item = aplicarDeposito(d, this.sel, m); if (!item) return;
      if (this.sel.estado === 'pendiente') cambiarReserva(this.sel.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada con depósito en garantía ' + d.numero)); else cambiarReserva(this.sel.id, x => anotar(x, 'Depósito en garantía ' + d.numero + ' aplicado: ' + money(item.monto, this.sel.moneda)));
      this.refrescar(); this.deposito = null; toast('Depósito ' + d.numero + ' aplicado a la cuenta', 'ok');
    },
    quitarCargo(f) { if (f.origen === 'hospedaje' && !confirm('Es un cargo de hospedaje: se vuelve a generar si cambia las fechas. ¿Quitarlo?')) return; if (f.origen !== 'hospedaje' && !confirm('¿Quitar «' + f.detalle + '»?')) return; quitarFolio(f.id); },
    // ---- pagos ----
    abrirPago() { const b = cuentaParaMedio('01', this.sel.moneda, this.cuentas) || cuentaParaMedio('01', 'CRC', this.cuentas), s = Math.max(0, this.saldoDe(this.sel));   /* 4.5: efectivo → caja */ this.pago = { moneda_pago: this.sel.moneda, monto_pago: s, medio: '01', cuenta: b ? b.nombre : '', referencia: '' }; },
    // el pago puede venir en la otra moneda (2.9): se convierte con el margen del hotel y la cuenta de Bancos pasa a la de esa moneda
    pagoConv(obj, montoRef) { const m = obj.moneda_pago || this.sel.moneda; return { monto: convertirPago(obj.monto_pago, m, this.sel.moneda), texto: textoCambio(obj.monto_pago, m, this.sel.moneda), tc: tcPago(m, this.sel.moneda) }; },
    cambiarMonedaPago(obj, m, saldo) { obj.moneda_pago = m; const tc = tcPago(m, this.sel.moneda); obj.monto_pago = !tc ? r2(saldo) : (this.sel.moneda === 'USD' ? r2(saldo * tc) : r2(saldo / tc)); const b = cuentaParaMedio(obj.medio, m, this.cuentas); if (b) obj.cuenta = b.nombre; },   // 4.5: según el medio
    async guardarPago() {
      const p = this.pago; if (!(+p.monto_pago > 0)) return toast('Indique el monto', 'err'); if (!mock.puedeGuardar()) return;
      const monto = this.pagoConv(p).monto;
      this.procesando = true;
      await registrarPago(this.sel, { ...p, monto, fecha: this.hoyS, detalle: (this.enCasa ? 'Pago ' : 'Adelanto ') + nombreMedio(p.medio) + (p.referencia ? ' · ' + p.referencia : '') });
      if (this.sel.estado === 'pendiente') { const { promesa } = cambiarReserva(this.sel.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada con adelanto de ' + money(monto, this.sel.moneda))); await promesa; } else cambiarReserva(this.sel.id, x => anotar(x, 'Pago de ' + money(monto, this.sel.moneda) + ' ' + nombreMedio(p.medio)));
      this.refrescar(); this.pago = null; this.procesando = false; toast('Pago registrado', 'ok');
    },
    async anular(p) { if (!confirm('¿Anular el pago de ' + money(p.monto, this.sel.moneda) + '?')) return; await anularPago(p); cambiarReserva(this.sel.id, x => anotar(x, 'Pago anulado: ' + money(p.monto, this.sel.moneda))); this.refrescar(); },
    // ---- cambio de habitación y estadía ----
    abrirCambio() { this.cambio = { habitacion_id: null, motivo: '' }; },
    async confirmarCambio() {
      const c = this.cambio; if (!c.habitacion_id) return toast('Elija la habitación nueva', 'err');
      const vieja = this.sel.habitacion_id, nueva = this.habs.find(h => h.id === c.habitacion_id);
      const { reg, promesa } = cambiarReserva(this.sel.id, x => anotar({ ...x, habitacion_id: c.habitacion_id }, 'Cambio de la habitación ' + nombreHab(vieja) + ' a la ' + (nueva ? nueva.numero : '') + (c.motivo ? ': ' + c.motivo : '')));
      if (!(await promesa)) return;
      this.marcarHab(vieja, 'sucia'); sincronizarHospedaje(reg, this.cfg); this.refrescar(); this.cambio = null; toast('Huésped movido a la habitación ' + (nueva ? nueva.numero : ''), 'ok');
    },
    abrirExtender() { this.extender = { salida: this.sel.salida }; },
    async confirmarExtender() {
      const s = this.extender.salida; if (!s || s <= this.sel.llegada) return toast('La salida debe ser posterior a la llegada', 'err');
      if (s < this.hoyS) return toast('La salida no puede ser anterior a hoy', 'err');
      if (this.sel.habitacion_id && !disponibles(null, this.sel.llegada, s, this.sel.id, this.lista).some(h => h.id === this.sel.habitacion_id)) return toast('La habitación ' + nombreHab(this.sel.habitacion_id) + ' ya está reservada en esas noches: cambie de habitación o acorte la fecha', 'err');
      const n = noches(this.sel.llegada, s);
      const { reg, promesa } = cambiarReserva(this.sel.id, x => anotar({ ...x, salida: s, noches: n, total: r2((+x.tarifa_noche || 0) * n) }, 'Salida cambiada al ' + fecha(s) + ' (' + n + ' noches)'));
      if (!(await promesa)) return;
      if (reg.estado === 'en_casa') sincronizarHospedaje(reg, this.cfg);
      this.refrescar(); this.extender = null; toast('Estadía actualizada: salida el ' + fecha(s), 'ok');
    },
    // ---- check-out ----
    // salida anticipada (3.19): al hacer el check-in se cargan todas las noches; si el huésped sale antes, se ofrece quitar las
    // noches (y sus cargos automáticos) que no durmió y la salida pasa a hoy. Si el hotel las cobra por política, se dejan.
    salidaAnticipada(r) {
      if (!r || r.estado !== 'en_casa' || r.tipo === 'folio' || !(r.salida > this.hoyS)) return;
      const futuras = folioDe(r.id).filter(f => f.tipo === 'cargo' && ['hospedaje', 'auto'].includes(f.origen) && !f.documento_id && f.fecha >= this.hoyS);
      if (!futuras.length) return;
      const nNoches = new Set(futuras.filter(f => f.origen === 'hospedaje').map(f => f.fecha)).size || futuras.length;
      if (!confirm(r.huesped_nombre + ' sale antes de lo previsto (tenía salida el ' + fecha(r.salida) + ').\n\n¿Quitar de la cuenta las ' + nNoches + ' noche(s) que no durmió? La salida pasa a hoy.\n\nAceptar: se quitan antes de facturar.\nCancelar: se cobran igual (política de salida anticipada).')) return;
      for (const f of futuras) quitarFolio(f.id);
      const n = noches(r.llegada, this.hoyS);
      cambiarReserva(r.id, x => anotar({ ...x, salida: this.hoyS, noches: n, total: r2((+x.tarifa_noche || 0) * n) }, 'Salida anticipada: se quitaron ' + nNoches + ' noche(s) no dormida(s); salida el ' + fecha(this.hoyS)));
      this.refrescar();
    },
    abrirCheckout(grupo) {
      if (!grupo) this.salidaAnticipada(this.sel);
      const r = this.sel, h = this.selH, b = cuentaParaMedio('02', r.moneda, this.cuentas) || cuentaParaMedio('02', 'CRC', this.cuentas);   // 4.5: el check-out abre con tarjeta: cuenta de Banco, no la caja
      const cli = r.cliente_id ? this.clientes.find(c => c.id === r.cliente_id) : (h && h.cliente_id ? this.clientes.find(c => c.id === h.cliente_id) : null);
      const ids = grupo ? this.grupoSel.map(x => x.id) : [r.id];
      this.checkout = { ids, tipo_documento: cli ? '01' : '04', cliente_id: cli ? cli.id : null, monto: 0, moneda_pago: r.moneda, monto_pago: 0, medio: '02', cuenta: b ? b.nombre : '', referencia: '', enviar: true, nuevoCliente: null, exo_id: undefined, idem: uuid(), parcial: false, seleccion: [],
        extra: [], devolver: 'efectivo', dev_medio: '01', dev_cuenta: (cuentaPrincipal(r.moneda, this.cuentas.filter(x => x.tipo === 'Efectivo')) || b || {}).nombre || '' };   // varios medios y devolución del saldo a favor (3.22)
      this.checkout.monto = Math.max(0, this.coTot.saldo); this.checkout.monto_pago = this.checkout.monto;
      if (cli) this.cargarExos(cli.id);
    },
    async cargarExos(cid) { this.exos = []; if (!cid) return; try { this.exos = (await api('/api/clientes/' + cid + '/exoneraciones')).filter(x => x.activa && x.estado !== 'vencida' && !x.solo_notas); if (this.checkout && this.checkout.exo_id === undefined) this.checkout.exo_id = this.exos.length ? this.exos[0].id : null; } catch { this.exos = []; } },
    abrirNuevoCliente() { const h = this.selH || {}; this.checkout.nuevoCliente = { tipo_id: h.tipo_doc === 'dimex' ? '03' : h.tipo_doc === 'pasaporte' ? '05' : '01', numero_id: String(h.documento || '').replace(/[^A-Za-z0-9]/g, ''), nombre: nombreHuesped(h), correo: h.correo || '', telefono: String(h.telefono || '').replace(/\D/g, '').slice(-8) }; },
    async guardarCliente() {
      const f = this.checkout.nuevoCliente; if (!f.numero_id || !f.nombre) return toast('Identificación y nombre son obligatorios', 'err');
      try { const c = await api('/api/clientes', { method: 'POST', body: { nombre: f.nombre.trim(), tipo_id: f.tipo_id, numero_id: String(f.numero_id).toUpperCase(), correo: (f.correo || '').trim() || null, telefono: /^\d{8}$/.test(f.telefono || '') ? +f.telefono : null, tipo: 'Cliente', activo: true } }); store.poner('clientes', c); this.checkout.cliente_id = c.id; this.checkout.tipo_documento = '01'; this.checkout.nuevoCliente = null; if (this.sel.huesped_id) mock.actualizar('hotel_huespedes', l => (l || []).map(x => (x.id === this.sel.huesped_id ? { ...x, cliente_id: c.id } : x)), []); toast('Contacto ' + c.nombre + ' creado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    otrosCargosFactura() { return this.coCargos.filter(f => f.es_otro_cargo).map(f => ({ tipo: '06', detalle: String(f.detalle || 'Impuesto de servicio').slice(0, 160), monto: r2(totalCargo(f)) })); },
    lineasFactura() {
      const habDe = {}; for (const r of this.coReservas) habDe[r.id] = nombreHab(r.habitacion_id);
      return this.coCargos.filter(f => !f.es_otro_cargo).map(f => ({ producto_id: f.producto_id || null, detalle: String((this.esGrupo && !/hab\. /i.test(String(f.detalle || '')) ? 'Hab. ' + habDe[f.reserva_id] + ' · ' : '') + (f.detalle || '')).slice(0, 200), cabys: f.cabys || this.cfg.cabys_hospedaje || CABYS_HOSPEDAJE, cantidad: +f.cantidad || 1, precio_unitario: Math.round((+f.precio || 0) * 100000) / 100000, descuento: 0, codigo_tarifa: f.codigo_tarifa || '08', tarifa: +f.tarifa || 0, otro_impuesto: f.otro_impuesto || {}, es_servicio: !f.producto_id, unidad_medida: f.producto_id ? undefined : 'Os' }));   /* 3.41: el otro impuesto que se cargó a la cuenta */
    },
    // facturar solo parte de la cuenta (3.0): marcar cargos; la reserva sigue en casa y el resto se factura al salir
    alternarParcial() { const co = this.checkout; co.parcial = !co.parcial; co.seleccion = co.parcial ? [] : []; this.$nextTick(() => { co.monto = Math.max(0, this.coTot.saldo); co.monto_pago = co.moneda_pago === this.sel.moneda ? co.monto : r2(convertirPago(co.monto, this.sel.moneda, co.moneda_pago)); }); },
    marcarCargo(id) { const co = this.checkout, i = co.seleccion.indexOf(id); if (i >= 0) co.seleccion.splice(i, 1); else co.seleccion.push(id); this.$nextTick(() => { co.monto = Math.max(0, this.coTot.saldo); co.monto_pago = co.moneda_pago === this.sel.moneda ? co.monto : r2(this.sel.moneda === 'USD' ? co.monto * (tcPago(co.moneda_pago, this.sel.moneda) || 1) : co.monto / (tcPago(co.moneda_pago, this.sel.moneda) || 1)); }); },
    async confirmarCheckout() {
      const r = this.sel, co = this.checkout, ct = this.checkoutTot, grupo = this.coReservas; if (!r || !co) return;
      // solo hospedaje a crédito de la agencia y nada que cobrar al huésped: se cierra sin comprobante y la agencia se factura desde Agencias (3.1)
      if (!this.coCargos.length && this.coCargosAgencia.length && !co.parcial) {
        if (!mock.puedeGuardar()) return;
        this.procesando = true;
        for (const f of this.coCargosAgencia) cambiarFolio(f.id, { a_agencia: true, agencia_id: (this.coReservas.find(x => x.id === f.reserva_id) || r).agencia_id });
        for (const x of grupo) { const { reg, promesa } = cambiarReserva(x.id, y => anotar({ ...y, estado: 'salio', checkout: new Date().toISOString(), salida_real: this.hoyS, salida: y.salida > this.hoyS ? this.hoyS : y.salida }, 'Check-out · hospedaje a crédito de ' + (this.agenciaSel ? this.agenciaSel.nombre : 'la agencia'))); await promesa; if (reg && reg.habitacion_id) this.marcarHab(reg.habitacion_id, 'sucia'); }
        this.refrescar(); this.checkout = null; this.procesando = false; return toast('Salida registrada. El hospedaje queda por facturar a ' + (this.agenciaSel ? this.agenciaSel.nombre : 'la agencia') + ' en Reservaciones › Agencias y empresas', 'ok');
      }
      if (!this.coCargos.length) return toast(co.parcial ? 'Marque al menos un cargo para facturar' : 'La cuenta no tiene cargos: agregue al menos el hospedaje', 'err');
      if (co.parcial && ct.falta > 0.005) return toast('La factura parcial se cobra completa ahora: falta ' + money(ct.falta, r.moneda), 'err');
      if (co.tipo_documento === '01' && !co.cliente_id) return toast('La factura electrónica requiere un contacto; elija uno o emita tiquete', 'err');
      if (ct.saldo > 0 && ct.falta > 0.005) return toast('Falta cobrar ' + money(ct.falta, r.moneda) + ' para cerrar la cuenta', 'err');
      if (ct.excede) return toast('Lo cobrado supera el saldo: ajuste los montos (solo el efectivo da cambio)', 'err');
      if (!mock.puedeGuardar()) return;
      this.procesando = true;
      let previosBase = ct.previos, cobroHoy = ct.cobro;
      // cobro en la otra moneda (2.9) o con varios medios (3.22): cada parte se registra primero como pago de la cuenta (con su tipo de
      // cambio y a Bancos en la moneda pagada) y la factura los recibe como adelantos ya cobrados; el efectivo que sobra es el cambio
      if ((ct.otraMoneda || ct.varios) && cobroHoy > 0) {
        let resta = r2(Math.min(cobroHoy, ct.saldo));
        for (const p of ct.partes) {
          const enCuenta = r2(Math.min(resta, convertirPago(p.monto_pago, p.moneda_pago, r.moneda))); if (enCuenta <= 0) continue;
          const pagoEnMoneda = p.moneda_pago === r.moneda ? enCuenta : r2(r.moneda === 'USD' ? enCuenta * (tcPago(p.moneda_pago, r.moneda) || 1) : enCuenta / (tcPago(p.moneda_pago, r.moneda) || 1));
          await registrarPago(r, { moneda_pago: p.moneda_pago, monto_pago: pagoEnMoneda, monto: enCuenta, medio: p.medio, cuenta: p.cuenta || '', fecha: this.hoyS, referencia: p.referencia || '', detalle: 'Pago al salir ' + nombreMedio(p.medio) + (p.referencia ? ' · ' + p.referencia : '') + (ct.cambio && p.medio === '01' ? ' · cambio ' + money(ct.cambio, r.moneda) : '') });
          resta = r2(resta - enCuenta);
        }
        previosBase = r2(previosBase + Math.min(cobroHoy, ct.saldo)); cobroHoy = 0;
      }
      let doc = null;
      try {
        const obs = this.esExterna ? 'Cuenta ' + r.numero + (r.huesped_nombre ? ' · ' + r.huesped_nombre : '') + (r.notas ? ' · ' + r.notas : '') : this.esGrupo ? 'Hospedaje grupo ' + (r.grupo || '') + ' · reservas ' + grupo.map(x => x.numero + ' hab. ' + nombreHab(x.habitacion_id)).join(', ') : 'Hospedaje reserva ' + r.numero + ' · habitación ' + nombreHab(r.habitacion_id) + ' · ' + fecha(r.llegada) + ' al ' + fecha(r.salida) + (r.huesped_nombre && co.tipo_documento === '04' ? ' · ' + r.huesped_nombre : '') + (co.parcial ? ' · factura parcial' : '');
        const cuerpo = { tipo_documento: co.tipo_documento, cliente_id: co.cliente_id || null, condicion_venta: '01', medio_pago: ct.saldo > 0 ? co.medio : (this.coPagos[0] ? this.coPagos[0].medio : '01'), moneda: r.moneda, tipo_cambio: monedas.tc(r.moneda), bodega_id: this.cfg.bodega_id || null,
          lineas: this.lineasFactura(), observaciones: obs.slice(0, 500),
          idempotencia: co.idem, exoneracion_id: co.tipo_documento === '01' && this.exoSel ? this.exoSel.id : null, vendedor: sesion.usuario?.nombre || null, otros_cargos: this.otrosCargosFactura() };
        if (!cuerpo.lineas.length) { this.procesando = false; return toast('La cuenta solo tiene cargos de servicio: agregue al menos una línea', 'err'); }
        doc = await api('/api/comprobantes', { method: 'POST', body: cuerpo });
      } catch (e) { this.procesando = false; return toast('No se emitió el comprobante: ' + e.message, 'err'); }
      const avisos = [];
      try {
        if (co.enviar && doc.estado === 'firmado') { try { await api('/api/comprobantes/' + doc.id + '/enviar', { method: 'POST' }); } catch (e) { avisos.push('Queda en cola para Hacienda (' + e.message + ')'); } }
        const total = r2(doc.total || this.coTot.cargos), tc = monedas.tc(r.moneda), etiqueta = this.esGrupo ? 'del grupo ' + (r.grupo || '') : 'de la reserva ' + r.numero;
        // adelantos y pagos anteriores (ya entraron a Bancos): se aplican a la factura con un recibo sin cuenta
        const previos = r2(Math.min(previosBase, total));
        if (previos > 0) { try { await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: co.cliente_id || null, detalles: 'Adelantos y pagos ' + etiqueta + ' (ya registrados en Bancos)', fecha: this.hoyS, cuenta: '', condicion_venta: '01', medio_pago: this.coPagos[0] ? this.coPagos[0].medio : '01', moneda: r.moneda, tipo_cambio: tc, monto: previos, notas: 'Hotel', facturas: [{ id: doc.id, monto: previos }] } }); for (const p of this.coPagos) cambiarFolio(p.id, { aplicado_en: doc.id }); } catch (e) { avisos.push('Los adelantos no se aplicaron a la factura: ' + e.message); } }
        // saldo a favor del huésped (3.22): se devuelve (sale de Bancos) o queda como depósito en garantía para otra estadía
        const aFavor = r2(Math.max(0, previosBase - total));
        if (aFavor > 0.005 && !co.parcial && co.devolver !== 'nada') {
          if (co.devolver === 'deposito') {
            const dep = await crearDeposito({ nombre: r.huesped_nombre || r.numero, huesped_id: r.huesped_id || null, cliente_id: co.cliente_id || r.cliente_id || null, grupo: r.grupo || '', monto: aFavor, moneda: r.moneda, medio: '99', cuenta: '', referencia: 'Saldo a favor ' + r.numero, notas: 'Saldo a favor al salir de la reserva ' + r.numero });
            agregarFolio({ reserva_id: r.id, tipo: 'pago', fecha: this.hoyS, detalle: 'Saldo a favor pasa al depósito en garantía ' + dep.numero, medio: '99', cuenta: '', monto: -aFavor, moneda: r.moneda, en_banco: false, aplicado_en: doc.id, deposito_origen: dep.id });
            avisos.push('Saldo a favor de ' + money(aFavor, r.moneda) + ' guardado como depósito ' + dep.numero);
          } else {
            const item = agregarFolio({ reserva_id: r.id, tipo: 'pago', fecha: this.hoyS, detalle: 'Devolución al huésped ' + nombreMedio(co.dev_medio), medio: co.dev_medio, cuenta: co.dev_cuenta || '', monto: -aFavor, moneda: r.moneda, en_banco: false, aplicado_en: doc.id });
            if (co.dev_cuenta) { try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: co.dev_cuenta, monto: -aFavor, fecha: this.hoyS, descripcion: 'Devolución al huésped · ' + r.numero + ' · ' + (r.huesped_nombre || ''), ref: 'hotel:devolucion:' + item.id, moneda: r.moneda, tipo_cambio: monedas.tc(r.moneda) } }); cambiarFolio(item.id, { en_banco: true }); } catch (e) { avisos.push('La devolución quedó en la cuenta, pero no salió de Bancos: ' + e.message); } }
            avisos.push('Devueltos ' + money(aFavor, r.moneda) + ' al huésped ' + nombreMedio(co.dev_medio));
          }
        }
        for (const f of this.coCargos) cambiarFolio(f.id, { documento_id: doc.id, consecutivo: doc.consecutivo, facturado_fecha: this.hoyS, doc_tipo: doc.tipo_documento || co.tipo_documento });   // lo facturado queda marcado (3.0), con su fecha y tipo para el reporte Facturación del día
        if (!co.parcial) for (const f of this.coCargosAgencia) cambiarFolio(f.id, { a_agencia: true, agencia_id: (this.coReservas.find(x => x.id === f.reserva_id) || r).agencia_id });   // a crédito de la agencia (3.1)
        // cobro del saldo de hoy: recibo de caja con cuenta (entra a Bancos)
        const cobro = r2(Math.min(cobroHoy, total - previos));
        if (cobro > 0) {
          try { const p = await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: co.cliente_id || null, detalles: 'Check-out ' + etiqueta + ' · ' + doc.consecutivo, fecha: this.hoyS, cuenta: co.cuenta || '', condicion_venta: '01', medio_pago: co.medio, moneda: r.moneda, tipo_cambio: tc, monto: cobro, notas: co.referencia || 'Hotel', facturas: [{ id: doc.id, monto: cobro }] } }); agregarFolio({ reserva_id: r.id, tipo: 'pago', fecha: this.hoyS, detalle: (co.parcial ? 'Pago de factura parcial ' : 'Pago al salir ') + nombreMedio(co.medio) + ' · recibo #' + p.numero + (this.esGrupo ? ' (cuenta del grupo)' : ''), medio: co.medio, cuenta: co.cuenta || '', monto: cobro, moneda: r.moneda, pago_numero: p.numero, en_banco: false, aplicado_en: doc.id }); }
          catch (e) { avisos.push('El cobro del saldo no quedó registrado en Pagos recibidos: ' + e.message + '. Regístrelo a mano.'); }
        }
        if (co.parcial) {   // factura parcial: la cuenta sigue abierta con lo que falta
          const { promesa } = cambiarReserva(r.id, y => anotar(y, 'Factura parcial ' + doc.consecutivo + ' · ' + money(total, r.moneda) + ' (' + this.coCargos.length + ' cargo(s))')); await promesa;
          this.refrescar(); this.checkout = null; toast('Factura parcial ' + doc.consecutivo.slice(-10) + ' emitida · ' + money(total, r.moneda) + '. La cuenta sigue abierta con el resto.', 'ok');
          for (const a of avisos) toast(a, 'err'); window.open('/api/comprobantes/' + doc.id + '/pdf', '_blank'); this.procesando = false; return;
        }
        for (const x of grupo) {
          const cerrada = x.tipo === 'folio';
          const { reg, promesa } = cambiarReserva(x.id, y => anotar({ ...y, estado: cerrada ? 'cerrado' : 'salio', checkout: new Date().toISOString(), salida_real: this.hoyS, documento_id: doc.id, consecutivo: doc.consecutivo, salida: y.salida > this.hoyS ? this.hoyS : y.salida }, (cerrada ? 'Cuenta cerrada · ' : 'Check-out · ') + (doc.tipo_documento === '04' ? 'tiquete ' : 'factura ') + doc.consecutivo + (this.esGrupo ? ' (cuenta maestra del grupo ' + (r.grupo || '') + ')' : ' · ' + money(total, r.moneda))));
          await promesa;
          if (reg && reg.habitacion_id && !cerrada) this.marcarHab(reg.habitacion_id, 'sucia');
        }
        this.refrescar(); this.checkout = null;
        toast((doc.tipo_documento === '04' ? 'Tiquete ' : 'Factura ') + doc.consecutivo.slice(-10) + ' emitido · ' + money(total, r.moneda) + (this.esExterna ? '' : ' · ¡buen viaje!'), 'ok');
        for (const a of avisos) toast(a, 'err');
        window.open('/api/comprobantes/' + doc.id + '/pdf', '_blank');
      } catch (e) { toast('El comprobante ' + doc.consecutivo + ' se emitió, pero hubo un problema después: ' + e.message, 'err'); }
      this.procesando = false;
    },
    // ---- limpieza ----
    marcarHab(id, estado) { mock.actualizar('hotel_habitaciones', l => (l || []).map(h => (h.id === id ? { ...h, estado, estado_hora: new Date().toISOString(), estado_usuario: usuarioActual() } : h)), []); this.habs = todasHabitaciones(); this.habMenu = null; },
    claseHab(h) { const r = this.ocupantes[h.id]; if (h.estado === 'mantenimiento') return 'mant'; if (h.estado === 'sucia') return 'sucia'; if (h.estado === 'limpiando') return 'limp'; if (h.estado === 'inspeccion') return 'insp'; return r ? 'ocup' : 'limpia'; },
    textoHab(h) { const r = this.ocupantes[h.id]; if (r) return (this.saleHoy.has(h.id) ? 'Sale hoy · ' : '') + (r.huesped_nombre || '').split(' ')[0]; if (this.llegaHoy.has(h.id)) return 'Llega hoy · ' + nombreEstadoHab(h.estado || 'limpia').toLowerCase(); return nombreEstadoHab(h.estado || 'limpia'); },
    irReserva(r) { location.hash = '/hotel/reservaciones/' + r.id; },
  },
  async created() { try { this.cuentas = await cuentasParaMovimientos(); } catch {} this._reloj = setInterval(() => { this.reloj = Date.now(); }, 60000); if (this.sel && this.esLlegada) this.abrirCheckin(this.sel); if (this.sel) this.cargarEnlace(); },
  beforeUnmount() { clearInterval(this._reloj); },
  template: `
  <div class="page">
    <PageHead title="Recepción" :sub="activo ? fechaLarga(hoyS) + (fechaHotelActiva() && hoyS !== hoyCal ? ' (fecha del hotel; el calendario marca ' + fechaLarga(hoyCal) + ')' : '') + ' · entrada desde las ' + cfg.hora_entrada + ' · salida hasta las ' + cfg.hora_salida : 'Configure primero el hotel.'" :crumbs="[{label:'Recepción'}]"><Atajo to="/hotel/configuracion" label="Configurar el hotel"></Atajo>
      <button class="btn ghost" @click="reporte = {}" title="Avisar a Ama de llaves o a Mantenimiento">⚠ Reportar problema</button>
      <a class="btn ghost" href="#/hotel/calendario">Calendario</a>
      <a class="btn sec" href="#/hotel/reservaciones/nueva?walkin=1" v-if="puedeEscribir">Huésped sin reserva</a>
      <a class="btn" href="#/hotel/reservaciones/nueva" v-if="puedeEscribir">+ Nueva reserva</a>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛎" title="El hotel todavía no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Configurar el hotel</a></Empty></div>
    <template v-else>
    <div class="kpis k7">
      <div class="kpi"><div class="t">Llegadas pendientes</div><div class="v">{{dia.llegadas.length}}</div><div class="d">{{dia.llegadas.filter(atrasada).length ? dia.llegadas.filter(atrasada).length + ' de días anteriores' : 'de hoy'}}</div></div>
      <div class="kpi"><div class="t">Salidas de hoy</div><div class="v">{{dia.salidas.length}}</div><div class="d">hasta las {{cfg.hora_salida}}</div></div>
      <div class="kpi"><div class="t">En casa</div><div class="v">{{dia.enCasa.length}}</div><div class="d">{{dia.enCasa.reduce((s,r)=>s+(+r.adultos||0)+(+r.ninos||0),0)}} personas</div></div>
      <div class="kpi"><div class="t">Ocupación</div><div class="v">{{ocup.pct}} %</div><div class="d">{{ocup.ocupadas}} de {{ocup.total}} · {{ocup.libres}} libres</div></div>
      <div class="kpi"><div class="t">Por limpiar</div><div class="v">{{porLimpiar}}</div><div class="d">{{habs.filter(h=>h.estado==='limpiando').length}} en limpieza</div></div>
      <div class="kpi" title="Habitaciones que hoy no se pueden vender: con un bloqueo de fechas o en mantenimiento"><div class="t">Bloqueadas o fuera de servicio</div><div class="v">{{ocup.bloqueadas + fueraServicio}}</div><div class="d">{{ocup.bloqueadas}} con bloqueo · {{fueraServicio}} en mantenimiento</div></div>
      <div class="kpi clic" @click="ocultarAlertas = !ocultarAlertas" title="Muestra u oculta la franja de alertas"><div class="t">Alertas</div><div class="v" :style="alertas.some(a => a.nivel === 'danger') ? 'color:var(--danger)' : (alertas.length ? 'color:var(--warn)' : '')">{{alertas.length}}</div><div class="d">{{!alertas.length ? 'todo en orden' : (ocultarAlertas ? 'toque para verlas' : 'toque para ocultarlas')}}</div></div>
    </div>
    <div class="card" v-if="alertas.length && !ocultarAlertas" style="margin-bottom:14px;padding:12px 16px"><h2 style="margin:0 0 6px">Alertas <small>{{alertas.length}} por atender</small><button class="btn sm ghost" style="float:right" @click="ocultarAlertas = true" title="Se vuelve a abrir con el indicador Alertas">Cerrar</button></h2>
      <div v-for="a in alertas" :key="a.clave" class="alert" :class="a.nivel" style="margin:6px 0;display:flex;justify-content:space-between;gap:10px;align-items:center"><span>{{a.texto}}</span><a v-if="a.enlace && a.enlace !== '#/hotel/recepcion'" class="btn sm sec" :href="a.enlace">Ver</a></div>
    </div>
    <div class="seg solo-movil" style="margin-bottom:10px"><button :class="{on: vistaMovil==='llegadas'}" @click="vistaMovil='llegadas'">Llegadas {{dia.llegadas.length}}</button><button :class="{on: vistaMovil==='salidas'}" @click="vistaMovil='salidas'">Salidas {{dia.salidas.length}}</button><button :class="{on: vistaMovil==='casa'}" @click="vistaMovil='casa'">En casa {{dia.enCasa.length}}</button></div>
    <div class="cols" :class="'mv-' + vistaMovil">
      <div class="card col"><h2>Llegadas <small>{{dia.llegadas.length}}</small></h2>
        <div class="lista">
          <div v-for="r in dia.llegadas" :key="r.id" class="hues" :class="{sel: selId===r.id, atrasada: atrasada(r)}" @click="elegir(r)">
            <div class="n">{{r.vip ? '★ ' : ''}}{{r.huesped_nombre}} <span class="visita" v-if="numeroVisita(r, lista)>1" :title="textoVisita(numeroVisita(r, lista))">{{insignia(numeroVisita(r, lista))}}</span><span class="badge warn" v-if="r.estado==='pendiente'" style="margin-left:6px">sin adelanto</span><span class="badge danger" v-if="atrasada(r)" style="margin-left:6px">desde {{fecha(r.llegada)}}</span></div>
            <div class="m">{{r.habitacion_id ? 'Hab. ' + nombreHab(r.habitacion_id) : 'Por asignar'}} · {{nombreCat(r.categoria_id)}} · {{noches(r.llegada, r.salida)}} noche(s) · {{(+r.adultos||0)+(+r.ninos||0)}} pers. · {{origenCorto(r.origen)}}<span v-if="r.especiales"> · <b>{{r.especiales}}</b></span></div>
            <div class="fila"><span class="small">Por pagar {{money(saldoDe(r), r.moneda)}}</span><span class="small muted" v-if="r.vuelo_llegada || r.hora_vuelo_llegada" title="Vuelo de llegada" style="margin-left:8px">✈ {{[r.vuelo_llegada, r.hora_vuelo_llegada].filter(Boolean).join(' ')}}</span><span style="flex:1"></span><button class="btn sm" @click.stop="abrirCheckin(r)" v-if="puedeEscribir">Check-in</button><button class="btn icon" @click.stop="irReserva(r)" title="Abrir la reserva">↗</button></div>
          </div>
          <Empty v-if="!dia.llegadas.length" icon="🛎" title="Sin llegadas pendientes" text="Las reservas de hoy ya hicieron check-in."></Empty>
        </div>
      </div>
      <div class="card col"><h2>Salidas <small>{{dia.salidas.length}}</small></h2>
        <div class="lista">
          <div v-for="r in dia.salidas" :key="r.id" class="hues" :class="{sel: selId===r.id, atrasada: r.salida < hoyS}" @click="elegir(r)">
            <div class="n">Hab. {{nombreHab(r.habitacion_id)}} · {{r.vip ? '★ ' : ''}}{{r.huesped_nombre}}<span class="badge danger" v-if="r.salida < hoyS" style="margin-left:6px">debía salir el {{fecha(r.salida)}}</span></div>
            <div class="m">{{noches(r.llegada, r.salida)}} noche(s) · llegó el {{fecha(r.llegada)}}</div>
            <div class="fila"><span class="small" :style="saldoDe(r) > 0 ? 'color:var(--danger);font-weight:600' : ''">Saldo {{money(saldoDe(r), r.moneda)}}</span><span class="badge" v-if="r.grupo" :title="'Grupo ' + r.grupo">grupo</span><span style="flex:1"></span><button class="btn sm" @click.stop="selId=r.id; abrirCheckout(false)" v-if="puedeFacturar">Check-out</button></div>
          </div>
          <Empty v-if="!dia.salidas.length" icon="🧳" title="Sin salidas hoy"></Empty>
        </div>
      </div>
      <div class="card col"><h2>En casa <small>{{dia.enCasa.length}}</small></h2>
        <div class="lista">
          <div v-for="r in dia.enCasa" :key="r.id" class="hues" :class="{sel: selId===r.id}" @click="elegir(r)">
            <div class="n">Hab. {{nombreHab(r.habitacion_id)}} · {{r.vip ? '★ ' : ''}}{{r.huesped_nombre}} <span class="visita" v-if="numeroVisita(r, lista)>1">{{insignia(numeroVisita(r, lista))}}</span></div>
            <div class="m">Sale el {{fecha(r.salida)}}{{r.salida === hoyS ? ' (hoy)' : ''}} · {{(+r.adultos||0)+(+r.ninos||0)}} pers.<span v-if="r.especiales"> · {{r.especiales}}</span></div>
            <div class="fila"><span class="small">Saldo {{money(saldoDe(r), r.moneda)}}</span><span style="flex:1"></span><a class="btn icon" :href="waLink(r)" target="_blank" rel="noopener" v-if="waLink(r)" title="WhatsApp" @click.stop>💬</a></div>
          </div>
          <Empty v-if="!dia.enCasa.length" icon="🏨" title="Nadie en casa"></Empty>
        </div>
      </div>
    </div>

    <div class="dos">
      <div class="card" style="margin:0"><h2>Cuenta del huésped <small v-if="sel">{{sel.numero}} · {{ESTADOS[sel.estado]}}</small></h2>
        <Empty v-if="!sel" icon="🧾" title="Elija una llegada, salida o huésped en casa" text="Aquí verá su cuenta: noches, consumos del restaurante, cargos y pagos."></Empty>
        <template v-else>
          <div class="row" style="justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:10px">
            <div><b style="font-size:15px">{{sel.vip ? '★ ' : ''}}{{sel.huesped_nombre}}</b> <span class="visita" v-if="visitaSel>1" :title="textoVisita(visitaSel)">{{insignia(visitaSel)}}</span>
              <div class="small muted">{{sel.habitacion_id ? 'Hab. ' + nombreHab(sel.habitacion_id) + ' · ' : ''}}{{nombreCat(sel.categoria_id)}} · {{fecha(sel.llegada)}} al {{fecha(sel.salida)}} · {{noches(sel.llegada, sel.salida)}} noche(s) · {{(+sel.adultos||0)+(+sel.ninos||0)}} pers.<span v-if="selH && selH.telefono"> · {{selH.telefono}}</span><span v-if="selH && selH.documento"> · {{selH.documento}}</span></div>
              <div class="small" v-if="sel.especiales || (selH && selH.preferencias)"><b>Pedidos:</b> {{[sel.especiales, selH && selH.preferencias].filter(Boolean).join(' · ')}}</div></div>
            <div class="row" style="gap:4px;flex-wrap:wrap;justify-content:flex-end">
              <button class="btn sm sec" @click="abrirCargo" v-if="puedeEscribir && activa">+ Cargo</button>
              <button class="btn sm sec" @click="abrirPago" v-if="puedeEscribir && activa">+ Pago</button>
              <button class="btn sm sec" @click="abrirDeposito" v-if="puedeEscribir && activa && depositosDisp.length" :title="depositosDisp.length + ' depósito(s) en garantía disponible(s)'">Depósito</button>
              <button class="btn sm ghost" @click="estadoCuenta">Estado de cuenta</button><button class="btn sm ghost" @click="tarjeta()">Tarjeta</button>
              <button class="btn sm ghost" @click="irReserva(sel)">Reserva</button>
            </div>
          </div>
          <div class="folio"><table><thead><tr><th>Fecha</th><th>Detalle</th><th class="n">Cant.</th><th class="n">Precio</th><th class="n">Total</th><th></th></tr></thead>
            <tbody>
              <tr class="sec" v-if="cargos.length"><td colspan="6">Cargos</td></tr>
              <tr v-for="f in cargos" :key="f.id" :style="f.documento_id ? 'opacity:.6' : ''"><td>{{fechaCorta(f.fecha)}}</td><td>{{f.detalle}}<span class="small muted" v-if="f.origen==='pos'"> · restaurante</span><span class="small muted" v-if="f.origen==='auto'"> · automático</span><span class="small muted" v-if="f.origen==='servicios'"> · servicio</span><span class="small muted" v-if="f.origen==='eventos'"> · evento</span><span class="badge info" v-if="esCargoAgencia(f, sel) && !f.documento_id" style="margin-left:6px" :title="'Se factura a ' + (agenciaSel ? agenciaSel.nombre : 'la agencia')">agencia</span><span class="badge ok" v-if="f.documento_id" style="margin-left:6px" :title="'Facturado en ' + (f.consecutivo || '')">facturado</span></td><td class="n">{{fmt(f.cantidad, 0)}}</td><td class="n">{{money(f.precio, sel.moneda)}}<span class="small muted" v-if="f.tarifa"> +{{f.tarifa}} %</span></td><td class="n">{{money(totalCargo(f), sel.moneda)}}</td><td style="white-space:nowrap"><button class="btn icon" v-if="puedeEscribir && activa && !f.documento_id && destinosTraslado.length" @click="abrirTraslado(f)" title="Trasladar a otra cuenta">⇄</button><button class="btn icon" v-if="puedeEscribir && activa && !f.documento_id" @click="quitarCargo(f)" title="Quitar">✕</button></td></tr>
              <tr v-if="!cargos.length"><td colspan="6" class="muted">Sin cargos todavía{{esLlegada ? ': las noches se cargan al hacer el check-in' : ''}}.</td></tr>
              <tr class="sec" v-if="pagos.length"><td colspan="6">Pagos y adelantos</td></tr>
              <tr v-for="f in pagos" :key="f.id"><td>{{fechaCorta(f.fecha)}}</td><td>{{f.detalle}}<span class="small muted" v-if="f.cuenta"> · {{f.cuenta}}</span><span class="badge ok" v-if="f.aplicado_en" style="margin-left:6px">aplicado</span></td><td class="n" colspan="2"></td><td class="n">−{{money(f.monto, sel.moneda)}}</td><td><button class="btn icon" v-if="puedeEscribir && activa && !f.pago_numero && !f.aplicado_en" @click="anular(f)" title="Anular">✕</button></td></tr>
            </tbody>
            <tbody><tr class="tot"><td colspan="4">Cargos {{money(tot.cargos, sel.moneda)}} (IVA {{money(tot.iva, sel.moneda)}}) − pagos {{money(tot.pagos, sel.moneda)}}</td><td class="n" :style="tot.saldo > 0 ? 'color:var(--danger)' : 'color:var(--ok)'">{{enCasa || sel.estado==='salio' ? 'Saldo ' + money(tot.saldo, sel.moneda) : 'Por pagar ' + money(saldoDe(sel), sel.moneda)}}<div class="small muted" style="font-weight:400">{{equivalente(enCasa || sel.estado==='salio' ? tot.saldo : saldoDe(sel), sel.moneda)}}</div></td><td></td></tr></tbody>
          </table></div>
          <div class="row" style="margin-top:10px;gap:6px;flex-wrap:wrap" v-if="(enCasa || (esExterna && activa)) && puedeEscribir">
            <template v-if="enCasa"><button class="btn sm ghost" @click="abrirCambio">Cambiar de habitación</button><button class="btn sm ghost" @click="abrirExtender">Extender o acortar</button><button class="btn sm ghost" @click="deshacerCheckin" title="La reserva vuelve a confirmada">Deshacer check-in</button><button class="btn sm ghost" v-if="!sel.cuenta_hospedaje_id && !agenciaNeta" @click="abrirSeparar" title="La empresa paga la habitación y el huésped solo sus consumos">Hospedaje a otra cuenta</button><span class="badge info" v-else-if="sel.cuenta_hospedaje_id">hospedaje en otra cuenta</span></template>
            <span style="flex:1"></span>
            <button class="btn sec" @click="abrirCheckout(true)" v-if="puedeFacturar && grupoSel.length > 1" :title="'Una sola factura para las ' + grupoSel.length + ' habitaciones del grupo ' + sel.grupo">Cuenta del grupo ({{grupoSel.length}} hab.)</button>
            <button class="btn" @click="abrirCheckout(false)" v-if="puedeFacturar">{{esExterna ? 'Cerrar la cuenta y facturar' : 'Check-out y facturar'}}</button>
          </div>
          <p class="small muted" style="margin:8px 0 0" v-if="sel.estado==='salio' || sel.estado==='cerrado'">{{sel.estado==='cerrado' ? 'Cuenta cerrada el ' : 'Salió el '}}{{fechaHora(sel.checkout)}}<span v-if="sel.consecutivo"> · comprobante <a :href="'#/ventas/facturas/' + sel.documento_id" class="link">{{sel.consecutivo}}</a></span>.</p>
          <div class="row" style="gap:6px;margin-top:8px;flex-wrap:wrap" v-if="sel.estado==='salio' && waSalida(sel)"><a class="btn sm sec" :href="waSalida(sel)" target="_blank" rel="noopener" :title="enlaceDoc ? 'Agradecimiento, comprobante y encuesta' : 'Agradecimiento y encuesta (el comprobante no tiene enlace público: configure la dirección pública del sistema)'">WhatsApp de salida{{enlaceDoc ? ' con el comprobante' : ''}}</a></div>
        </template>
      </div>
      <div class="card" style="margin:0">
        <template v-if="sel && esLlegada && checkin"><h2>Check-in <small>{{sel.numero}}</small></h2>
          <div class="pasos"><div class="on">1 Habitación</div><div class="on">2 Datos</div><div>3 Llaves</div><div>4 Listo</div></div>
          <div class="alert warn" style="margin:0 0 8px" v-if="!habsCheckin.some(h => h.categoria_id === sel.categoria_id && (h.estado === 'limpia' || !h.estado))">No hay habitación limpia de {{nombreCat(sel.categoria_id)}}: puede esperar la limpieza o asignar otra categoría (abajo se elige si se cobra la diferencia).</div>
          <Field label="Habitación" req :help="habsCheckin.length ? 'Primero las de la categoría reservada y limpias' : 'No hay habitaciones libres para estas noches'"><select v-model="checkin.habitacion_id"><option :value="null">— Asignar —</option><option v-for="h in habsCheckin" :key="h.id" :value="h.id">{{h.numero}} · {{nombreCat(h.categoria_id)}}{{descripcionHab(h) ? ' · ' + descripcionHab(h) : ''}} · {{nombreEstadoHab(h.estado || 'limpia')}}{{h.categoria_id !== sel.categoria_id ? ' (otra categoría)' : ''}}</option></select></Field>
          <Field label="Es otra categoría" v-if="checkin.habitacion_id && (habs.find(h => h.id === checkin.habitacion_id) || {}).categoria_id !== sel.categoria_id" :help="'Reservó ' + nombreCat(sel.categoria_id) + ' y se le asigna ' + nombreCat((habs.find(h => h.id === checkin.habitacion_id) || {}).categoria_id)"><select v-model="checkin.upgrade"><option value="cortesia">De cortesía: se mantiene el precio reservado</option><option value="cobrar">Cobrar la tarifa de la categoría nueva</option></select></Field>
          <div class="grid cols-2" style="margin-top:8px">
            <Field label="Documento"><input v-model="checkin.documento" maxlength="30"></Field><Field label="Teléfono"><input v-model="checkin.telefono" maxlength="20"></Field>
            <Field label="Vehículo (placa)"><input v-model="checkin.vehiculo" maxlength="20"></Field><Field label="Llaves entregadas"><input type="number" min="0" max="10" v-model.number="checkin.llaves"></Field>
            <Field label="Acompañantes" style="grid-column:1/-1"><input v-model="checkin.acompanantes" maxlength="200"></Field>
            <Field label="Garantía" help="Tarjeta, depósito, voucher…" style="grid-column:1/-1"><input v-model="checkin.garantia" maxlength="80"></Field>
            <Field label="Observaciones" style="grid-column:1/-1"><input v-model="checkin.notas" maxlength="200"></Field>
          </div>
          <label class="row" style="gap:6px;margin-top:8px;cursor:pointer"><input type="checkbox" v-model="checkin.imprimir"> Imprimir la tarjeta de registro{{checkin.firma ? ' (con la firma)' : ' para la firma'}}</label>
          <div class="grid cols-2" style="margin-top:8px">
            <div><div class="small muted" style="margin-bottom:4px">Firma del huésped <span class="muted">(con el dedo o el mouse)</span></div><canvas ref="firma" width="360" height="130" style="width:100%;max-width:360px;border:1px dashed var(--border, #c9d0dc);border-radius:8px;background:#fff;touch-action:none;display:block" @pointerdown="firmaInicio" @pointermove="firmaTrazo" @pointerup="firmaFin" @pointerleave="firmaFin" @pointercancel="firmaFin"></canvas><a class="link small" style="cursor:pointer" @click="firmaLimpiar">Borrar firma</a><span class="small muted" v-if="checkin.firma"> · firmada</span></div>
            <div><div class="small muted" style="margin-bottom:4px">Foto del documento <span class="muted">(cédula o pasaporte)</span></div><input type="file" accept="image/*" capture="environment" @change="fotoDoc"><img v-if="checkin.foto" :src="checkin.foto" alt="Documento" style="max-width:100%;max-height:120px;margin-top:6px;border-radius:6px;display:block"></div>
          </div>
          <div class="alert warn" style="margin:8px 0 0" v-if="sel.estado==='pendiente'">Reserva sin adelanto registrado: puede cobrarlo al llegar con «+ Pago».</div>
          <div class="row" style="margin-top:10px;gap:6px"><button class="btn ghost" @click="checkin=null">Cancelar</button><button class="btn" style="flex:1;justify-content:center" @click="registrarLlegada" :disabled="procesando || !checkin.habitacion_id">Registrar llegada</button></div>
        </template>
        <template v-else-if="sel && esLlegada"><h2>Llegada <small>{{sel.numero}}</small></h2>
          <p class="small muted">{{sel.huesped_nombre}} llega {{sel.llegada === hoyS ? 'hoy' : 'el ' + fecha(sel.llegada)}} · {{nombreCat(sel.categoria_id)}}{{sel.habitacion_id ? ' · hab. ' + nombreHab(sel.habitacion_id) : ''}}.</p>
          <button class="btn" style="width:100%;justify-content:center" @click="abrirCheckin(sel)" v-if="puedeEscribir">Hacer check-in</button>
          <a class="btn ghost" style="width:100%;justify-content:center;margin-top:6px" :href="'#/hotel/reservaciones/' + sel.id">Ver o editar la reserva</a>
        </template>
        <template v-else-if="sel && enCasa"><h2>Estadía <small>hab. {{nombreHab(sel.habitacion_id)}}</small></h2>
          <div class="grid" style="grid-template-columns:1fr 1fr;gap:6px 12px;font-size:13px">
            <div><div class="small muted">Llegó</div>{{fechaHora(sel.checkin)}}</div><div><div class="small muted">Sale</div>{{fecha(sel.salida)}} · {{cfg.hora_salida}}</div>
            <div><div class="small muted">Personas</div>{{(+sel.adultos||0)}} adulto(s){{sel.ninos ? ', ' + sel.ninos + ' niño(s)' : ''}}</div><div><div class="small muted">Llaves</div>{{sel.llaves || 1}}</div>
            <div v-if="sel.vehiculo"><div class="small muted">Vehículo</div>{{sel.vehiculo}}</div><div v-if="sel.garantia"><div class="small muted">Garantía</div>{{sel.garantia}}</div>
            <div v-if="sel.acompanantes" style="grid-column:1/-1"><div class="small muted">Acompañantes</div>{{sel.acompanantes}}</div>
            <div v-if="sel.notas" style="grid-column:1/-1"><div class="small muted">Notas</div><span style="white-space:pre-wrap">{{sel.notas}}</span></div>
          </div>
          <div class="row" style="gap:6px;margin-top:12px;flex-wrap:wrap"><a class="btn sm sec" :href="waLink(sel)" target="_blank" rel="noopener" v-if="waLink(sel)">WhatsApp de bienvenida</a><a class="btn sm ghost" :href="'#/hotel/huespedes/' + sel.huesped_id" v-if="sel.huesped_id">Tarjeta del huésped</a></div>
        </template>
        <template v-else-if="sel && esExterna"><h2>Cuenta externa <small>{{sel.numero}}</small></h2>
          <p class="small muted" style="margin:0 0 8px">{{sel.huesped_nombre}}<span v-if="sel.grupo"> · {{sel.grupo}}</span><span v-if="sel.notas"> · {{sel.notas}}</span></p>
          <p class="small muted">Cuenta sin habitación: eventos, clientes externos o consumos internos. Agregue cargos y pagos; al cerrarla se emite el comprobante.</p>
          <a class="btn ghost" style="width:100%;justify-content:center" href="#/hotel/folios">Todas las cuentas externas</a>
        </template>
        <template v-else-if="sel"><h2>{{ESTADOS[sel.estado]}} <small>{{sel.numero}}</small></h2><p class="small muted">Esta reserva ya no está activa.</p><a class="btn ghost" :href="'#/hotel/reservaciones/' + sel.id">Ver la reserva</a></template>
        <template v-else><h2>Acciones rápidas</h2>
          <a class="btn sec" style="width:100%;justify-content:center;margin-bottom:6px" href="#/hotel/reservaciones/nueva?walkin=1" v-if="puedeEscribir">Huésped sin reserva (walk-in)</a>
          <a class="btn ghost" style="width:100%;justify-content:center;margin-bottom:6px" href="#/hotel/reservaciones">Ver reservaciones</a>
          <a class="btn ghost" style="width:100%;justify-content:center;margin-bottom:6px" href="#/hotel/reportes">Reportes del día</a>
          <p class="small muted" style="margin:8px 0 0">Toque un huésped en las listas para ver su cuenta, hacer el check-in o el check-out.</p>
        </template>
      </div>
    </div>

    <div class="card" style="margin-top:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Limpieza por piso <small>toque una habitación para cambiar su estado</small></h2>
      <div class="leyenda" style="margin:0"><span><i style="background:#f0fdf4;border:1px solid #86efac"></i>Limpia</span><span><i style="background:#eff6ff;border:1px solid #93c5fd"></i>Ocupada</span><span><i style="background:#fef2f2;border:1px solid #fca5a5"></i>Sucia</span><span><i style="background:#f5f3ff;border:1px solid #c4b5fd"></i>Por inspeccionar</span><span><i style="background:#fffbeb;border:1px solid #fcd34d"></i>En limpieza</span><span><i style="background:#f3f4f6;border:1px solid #d1d5db"></i>Mantenimiento</span></div></div>
      <div class="hk" v-for="p in pisos" :key="p.nombre" style="margin-bottom:8px">
        <div class="piso-t">Piso {{p.nombre}}</div>
        <div v-for="h in p.habs" :key="h.id" class="h" :class="claseHab(h)" @click="habMenu = habMenu === h.id ? null : h.id" style="cursor:pointer;position:relative"><b>{{h.numero}}<span v-if="abiertos[h.id]" class="badge danger" style="margin-left:4px;padding:0 5px" title="Reportes abiertos">⚠{{abiertos[h.id]}}</span></b><span>{{textoHab(h)}}</span>
          <div class="hmenu" v-if="habMenu===h.id" @click.stop><button v-for="e in ESTADOS_HAB" :key="e[0]" class="btn sm" :class="h.estado===e[0] ? '' : 'ghost'" @click="marcarHab(h.id, e[0])" :disabled="!puedeEscribir">{{e[1]}}</button><button class="btn sm ghost" @click="reporte = { habitacion_id: h.id }; habMenu = null">⚠ Reportar problema</button><div class="small muted" v-if="h.estado_hora">{{nombreEstadoHab(h.estado)}} · {{fechaHora(h.estado_hora)}}<br>{{h.estado_usuario}}</div></div>
        </div>
      </div>
    </div>
    </template>

    <ReporteProblema v-if="reporte" :habitacion-id="reporte.habitacion_id || null" @close="reporte=null" @creado="refrescar"></ReporteProblema>
    <Modal v-if="separar && sel" title="Hospedaje a otra cuenta" @close="separar=null">
      <p class="small muted" style="margin:0 0 8px">Las noches y los cargos automáticos de {{sel.huesped_nombre}} pasan a una cuenta externa a nombre de la empresa o persona que paga el hospedaje; las noches que falten se cargan ahí. El huésped paga al salir solo sus consumos y extras.</p>
      <div class="grid cols-2"><Field label="Contacto que paga (facturar a)" style="grid-column:1/-1"><Buscador v-model="separar.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Sin contacto (solo nombre)" agregar="cliente"></Buscador></Field><Field label="Nombre de la cuenta" v-if="!separar.cliente_id" style="grid-column:1/-1"><input v-model="separar.nombre" maxlength="80" placeholder="Empresa o persona que paga"></Field></div>
      <template #foot><button class="btn ghost" @click="separar=null">Cancelar</button><button class="btn" @click="confirmarSeparar">Separar el hospedaje</button></template>
    </Modal>
    <Modal v-if="cargo" title="Cargo a la cuenta" @close="cargo=null">
      <div class="grid cols-2">
        <Field label="Ítem de venta" help="Lavandería, tour, minibar… (Inventario › Ítems)" style="grid-column:1/-1"><Buscador v-model="cargo.producto_id" :opciones="productos" :detalle="p => money(p.precio, p.moneda || 'CRC')" vacio="Cargo manual" agregar="item" @change="elegirProducto"></Buscador></Field>
        <Field label="Detalle" req style="grid-column:1/-1"><input v-model="cargo.detalle" maxlength="120"></Field>
        <Field label="Cantidad" req><input type="number" min="0.001" step="1" v-model.number="cargo.cantidad"></Field>
        <Field :label="cargo.con_iva ? 'Precio unitario con IVA' : 'Precio unitario sin IVA'" req :help="'En ' + (sel ? sel.moneda : '') + (cargo.con_iva && +cargo.precio ? ' · sin IVA ' + money(precioNetoCargo(), sel.moneda) : '')"><input type="number" min="0" step="0.01" v-model.number="cargo.precio"></Field>
        <Field label=" " style="align-self:end"><Toggle v-model="cargo.con_iva" label="El precio ya incluye el IVA"></Toggle></Field>
        <Field label="IVA"><select v-model="cargo.codigo_tarifa" @change="tarifaCargo"><option v-for="t in tarifas" :key="t.value" :value="t.value">{{t.label}}</option></select></Field>
        <Field label="Fecha"><input type="date" v-model="cargo.fecha"></Field>
        <Field label="CABYS" help="Vacío = el del hospedaje" v-if="!cargo.producto_id"><input class="mono" v-model="cargo.cabys" maxlength="13"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="cargo=null">Cancelar</button><button class="btn" @click="guardarCargo">Agregar</button></template>
    </Modal>
    <Modal v-if="pago" :title="(enCasa ? 'Pago' : 'Adelanto') + ' · ' + (sel ? sel.numero : '')" @close="pago=null">
      <div class="grid cols-2">
        <Field label="Moneda en que paga" :help="'La cuenta del huésped está en ' + sel.moneda"><select :value="pago.moneda_pago" @change="cambiarMonedaPago(pago, $event.target.value, saldoDe(sel))"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field>
        <Field :label="'Monto en ' + pago.moneda_pago" req :help="pagoConv(pago).texto || equivalente(pago.monto_pago, sel.moneda)"><input type="number" min="0" step="0.01" v-model.number="pago.monto_pago"></Field>
        <Field label="Medio"><select v-model="pago.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field>
        <Field label="Cuenta de Bancos donde entra"><Buscador v-model="pago.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
        <Field label="Referencia"><input v-model="pago.referencia" maxlength="40" placeholder="SINPE, voucher…"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Queda en la cuenta del huésped y, con cuenta, en Bancos. Al salir, se aplica al comprobante.</p>
      <template #foot><button class="btn ghost" @click="pago=null">Cancelar</button><button class="btn" @click="guardarPago" :disabled="procesando">Registrar</button></template>
    </Modal>
    <Modal v-if="traslado" :title="'Trasladar cargo · ' + traslado.f.detalle" @close="traslado=null">
      <Field label="Cuenta de destino" req help="Huéspedes en casa y cuentas externas abiertas"><select v-model="traslado.destino_id"><option :value="null">— Elegir —</option><option v-for="r in destinosTraslado" :key="r.id" :value="r.id">{{r.numero}} · {{r.huesped_nombre}}{{r.habitacion_id ? ' · hab. ' + nombreHab(r.habitacion_id) : ''}}</option></select></Field>
      <p class="small muted" style="margin:8px 0 0">El cargo de {{money(totalCargo(traslado.f), sel.moneda)}} sale de esta cuenta y entra en la de destino con la nota de dónde venía.</p>
      <template #foot><button class="btn ghost" @click="traslado=null">Cancelar</button><button class="btn" @click="confirmarTraslado">Trasladar</button></template>
    </Modal>
    <Modal v-if="deposito" :title="'Aplicar depósito en garantía · ' + (sel ? sel.numero : '')" @close="deposito=null">
      <div class="grid cols-2">
        <Field label="Depósito" req><select v-model="deposito.id" @change="cambiarDep"><option v-for="d in depositosDisp" :key="d.id" :value="d.id">{{d.numero}} · {{d.nombre}} · disponible {{money(depositoDisponible(d), d.moneda)}}</option></select></Field>
        <Field label="Monto a aplicar" req help="Lo que no se aplique sigue disponible"><input type="number" min="0" step="0.01" v-model.number="deposito.monto"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">El dinero ya entró con el depósito: queda como pago de esta cuenta y se descuenta del depósito.</p>
      <template #foot><button class="btn ghost" @click="deposito=null">Cancelar</button><button class="btn" @click="confirmarDeposito">Aplicar</button></template>
    </Modal>
    <Modal v-if="cambio" :title="'Cambiar de habitación · ' + (sel ? sel.numero : '')" @close="cambio=null">
      <Field label="Habitación nueva" req help="Libres desde hoy hasta la salida"><select v-model="cambio.habitacion_id"><option :value="null">— Elegir —</option><option v-for="h in habsCambio" :key="h.id" :value="h.id">{{h.numero}} · {{nombreCat(h.categoria_id)}} · {{nombreEstadoHab(h.estado || 'limpia')}}</option></select></Field>
      <Field label="Motivo" style="margin-top:8px"><input v-model="cambio.motivo" maxlength="80" placeholder="Aire acondicionado, ruido, mejora…"></Field>
      <p class="small muted" style="margin:8px 0 0">La habitación actual queda como sucia; la tarifa por noche no cambia (ajústela con un cargo si aplica).</p>
      <template #foot><button class="btn ghost" @click="cambio=null">Cancelar</button><button class="btn" @click="confirmarCambio">Cambiar</button></template>
    </Modal>
    <Modal v-if="extender" :title="'Fecha de salida · ' + (sel ? sel.numero : '')" @close="extender=null">
      <Field label="Nueva fecha de salida" req><input type="date" v-model="extender.salida" :min="hoyS"></Field>
      <p class="small muted" style="margin:8px 0 0">Se agregan o quitan las noches en la cuenta con la misma tarifa por noche ({{sel ? money(sel.tarifa_noche, sel.moneda) : ''}}).</p>
      <template #foot><button class="btn ghost" @click="extender=null">Cancelar</button><button class="btn" @click="confirmarExtender">Guardar</button></template>
    </Modal>
    <Modal v-if="checkout && sel" :title="procesando ? 'Emitiendo…' : esExterna ? 'Cerrar la cuenta ' + sel.numero : (esGrupo ? 'Check-out del grupo ' + (sel.grupo || '') + ' · ' + coReservas.length + ' habitaciones' : 'Check-out · ' + sel.numero + ' · hab. ' + nombreHab(sel.habitacion_id))" lg @close="procesando || (checkout=null)">
      <div v-if="!esGrupo && coCargosTodos.length > 1" style="margin:0 0 10px"><label class="row" style="gap:6px;cursor:pointer"><input type="checkbox" :checked="checkout.parcial" @change="alternarParcial"> Facturar solo parte de la cuenta (la reserva sigue abierta con el resto)</label>
        <div v-if="checkout.parcial" class="card" style="padding:8px;margin:6px 0 0;max-height:180px;overflow:auto"><label v-for="f in coCargosTodos" :key="f.id" class="row small" style="gap:6px;cursor:pointer;padding:2px 0"><input type="checkbox" :checked="checkout.seleccion.includes(f.id)" @change="marcarCargo(f.id)"> {{fechaCorta(f.fecha)}} · {{f.detalle}} <b style="margin-left:auto">{{money(totalCargo(f), sel.moneda)}}</b></label></div></div>
      <div class="alert info" v-if="coCargosAgencia.length" style="margin:0 0 12px">Contrato de tarifa neta con <b>{{agenciaSel ? agenciaSel.nombre : 'la agencia'}}</b>: {{coCargosAgencia.length}} cargo(s) de hospedaje por {{money(coCargosAgencia.reduce((s,f)=>s+totalCargo(f),0), sel.moneda)}} no se cobran al huésped; se facturan a la agencia desde Reservaciones › Agencias y empresas.</div>
      <div class="alert info" v-if="esGrupo" style="margin:0 0 12px">Cuenta maestra: un solo comprobante con las cuentas de <span v-for="(x,i) in coReservas" :key="x.id"><b>hab. {{nombreHab(x.habitacion_id)}}</b> ({{x.huesped_nombre}}){{i < coReservas.length - 1 ? ', ' : ''}}</span>. Cada línea indica su habitación; todas las reservas quedan como salidas.</div>
      <div class="grid cols-2" style="align-items:start">
        <div>
          <div class="totals" style="align-items:stretch;margin:0 0 10px"><div><span>Cargos ({{coCargos.length}})</span><b>{{money(coTot.cargos, sel.moneda)}}</b></div><div><span>Pagos y adelantos</span><b>−{{money(coTot.pagos, sel.moneda)}}</b></div><div class="total"><span>Saldo por cobrar</span><b>{{money(Math.max(0, coTot.saldo), sel.moneda)}}</b></div><div v-if="coTot.saldo > 0.005"><span class="muted">Equivale a</span><b class="muted">{{equivalente(coTot.saldo, sel.moneda)}}</b></div><div v-if="coTot.saldo < -0.005"><span style="color:var(--danger)">A favor del huésped (devolver)</span><b>{{money(-coTot.saldo, sel.moneda)}}</b></div></div>
          <template v-if="coTot.saldo > 0.005">
            <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px"><button v-for="m in MEDIOS.slice(0,4)" :key="m[0]" class="btn sm" :class="checkout.medio===m[0] ? '' : 'sec'" @click="checkout.medio=m[0]">{{m[2]}} {{m[1]}}</button></div>
            <div class="grid cols-2"><Field label="Moneda en que paga"><select :value="checkout.moneda_pago" @change="cambiarMonedaPago(checkout, $event.target.value, Math.max(0, coTot.saldo))"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field><Field :label="'Monto cobrado ahora en ' + checkout.moneda_pago" req :help="pagoConv(checkout).texto"><input type="number" min="0" step="0.01" v-model.number="checkout.monto_pago"></Field><Field label="Cuenta de Bancos"><select v-model="checkout.cuenta"><option value="">— Sin cuenta —</option><option v-for="b in cuentas" :key="b.nombre" :value="b.nombre">{{b.nombre}} ({{b.moneda || 'CRC'}})</option></select></Field><Field label="Referencia" style="grid-column:1/-1"><input v-model="checkout.referencia" maxlength="40"></Field></div>
            <div v-for="(x, i) in checkout.extra" :key="i" class="card" style="padding:8px;margin:6px 0"><div class="row" style="justify-content:space-between;margin-bottom:4px"><b class="small">Otro medio</b><button class="btn icon" @click="checkout.extra.splice(i, 1)">✕</button></div>
              <div class="grid cols-2"><Field label="Medio"><select v-model="x.medio" @change="cuentaMedioExtra(x, $event.target.value, x.moneda_pago)"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field><Field label="Moneda"><select v-model="x.moneda_pago" @change="cuentaMedioExtra(x, x.medio, $event.target.value)"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field><Field :label="'Monto en ' + x.moneda_pago" req><input type="number" min="0" step="0.01" v-model.number="x.monto_pago"></Field><Field label="Cuenta de Bancos"><Buscador v-model="x.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="Sin cuenta" agregar="cuenta"></Buscador></Field></div></div>
            <div class="row" style="gap:8px;align-items:center;margin-top:6px;flex-wrap:wrap"><button class="btn sm ghost" @click="agregarMedioCheckout">+ Otro medio (mixto)</button><span class="small" v-if="checkoutTot.cambio > 0.005">Cambio en efectivo: <b>{{money(checkoutTot.cambio, sel.moneda)}}</b> <span class="muted">({{equivalente(checkoutTot.cambio, sel.moneda)}})</span></span><span class="small" style="color:var(--danger)" v-else-if="checkoutTot.excede">Lo cobrado supera el saldo</span></div>
          </template>
          <template v-else-if="coTot.saldo < -0.005">
            <div class="row" style="gap:12px;flex-wrap:wrap;margin-bottom:6px"><label class="row small" style="gap:6px;cursor:pointer"><input type="radio" value="efectivo" v-model="checkout.devolver"> Devolver ahora</label><label class="row small" style="gap:6px;cursor:pointer"><input type="radio" value="deposito" v-model="checkout.devolver"> Dejar como depósito en garantía para otra estadía</label><label class="row small" style="gap:6px;cursor:pointer"><input type="radio" value="nada" v-model="checkout.devolver"> Resolver después</label></div>
            <div class="grid cols-2" v-if="checkout.devolver==='efectivo'"><Field label="Cómo se devuelve"><select v-model="checkout.dev_medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field><Field label="Sale de la cuenta"><Buscador v-model="checkout.dev_cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field></div>
          </template>
          <p class="small muted" v-else style="margin:0">La cuenta está cubierta con los adelantos: solo se emite el comprobante.</p>
        </div>
        <div>
          <div class="row" style="gap:14px;flex-wrap:wrap;margin-bottom:8px"><label class="row" style="cursor:pointer;gap:6px"><input type="radio" value="04" v-model="checkout.tipo_documento"> Tiquete electrónico</label><label class="row" style="cursor:pointer;gap:6px"><input type="radio" value="01" v-model="checkout.tipo_documento"> Factura electrónica</label></div>
          <template v-if="checkout.tipo_documento==='01'">
            <Field label="Contacto (receptor)" req><Buscador v-model="checkout.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Elegir" agregar="cliente"></Buscador></Field>
            <a class="link small" style="cursor:pointer;display:inline-block;margin-top:4px" @click="abrirNuevoCliente" v-if="!checkout.nuevoCliente">+ Crear el contacto con los datos del huésped</a>
            <div v-if="checkout.nuevoCliente" class="card" style="padding:10px;margin:6px 0 0">
              <div class="grid cols-2"><Field label="Tipo"><select v-model="checkout.nuevoCliente.tipo_id"><option value="01">Cédula física</option><option value="02">Cédula jurídica</option><option value="03">DIMEX</option><option value="05">Extranjero</option></select></Field><Field label="Identificación" req><input v-model="checkout.nuevoCliente.numero_id"></Field><Field label="Nombre" req style="grid-column:1/-1"><input v-model="checkout.nuevoCliente.nombre"></Field><Field label="Correo"><input v-model="checkout.nuevoCliente.correo"></Field><Field label="Teléfono"><input v-model="checkout.nuevoCliente.telefono" maxlength="8"></Field></div>
              <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm" @click="guardarCliente">Crear contacto</button><button class="btn sm ghost" @click="checkout.nuevoCliente=null">Cancelar</button></div>
            </div>
            <div v-if="exos.length" class="small" style="margin-top:8px">Exoneración: <select class="inp" v-model="checkout.exo_id" style="padding:2px 6px"><option :value="null">— No aplicar —</option><option v-for="x in exos" :key="x.id" :value="x.id">{{x.numero}} · {{x.tarifa}} %</option></select></div>
          </template>
          <p class="small muted" v-else style="margin:0">El tiquete no lleva receptor; el nombre del huésped va en las observaciones. Para factura con cédula, elija Factura electrónica.</p>
          <label class="row" style="gap:6px;margin-top:10px;cursor:pointer"><input type="checkbox" v-model="checkout.enviar"> Enviar a Hacienda ahora</label>
          <p class="small muted" style="margin:8px 0 0" v-if="checkout.parcial">Factura parcial: se emite con los {{coCargos.length}} cargo(s) marcados, se cobra completa ahora y la cuenta sigue abierta con el resto; los adelantos se aplican al final.</p>
          <p class="small muted" style="margin:8px 0 0" v-else-if="esExterna">Al confirmar: se emite el comprobante en {{sel.moneda}} con las {{coCargos.length}} línea(s), se aplican los pagos previos, se registra el cobro de hoy y la cuenta queda cerrada.</p>
          <p class="small muted" style="margin:8px 0 0" v-else>Al confirmar: se emite el comprobante en {{sel.moneda}} con las {{coCargos.length}} línea(s) de la cuenta, se aplican los adelantos, se registra el cobro de hoy en Pagos recibidos y Bancos, la habitación pasa a sucia y se abre el PDF.</p>
        </div>
      </div>
      <template #foot><button class="btn ghost" @click="checkout=null" :disabled="procesando">Cancelar</button><button class="btn" @click="confirmarCheckout" :disabled="procesando">{{procesando ? 'Emitiendo…' : 'Confirmar salida y emitir'}}</button></template>
    </Modal>
  </div>`,
  components: { ReporteProblema },
  setup() { return { fechaLarga: f => { const d = new Date(f + 'T00:00:00'); return ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'][d.getDay()] + ' ' + d.getDate() + ' de ' + ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'][d.getMonth()]; }, numeroVisita, fechaCorta, sumarDias, reserva, categoria, ESTADOS }; },
};
