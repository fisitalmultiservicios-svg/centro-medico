// Hotel › Nueva reserva / detalle de la reserva: huésped (existente o nuevo), fechas, categoría y habitación disponible, precio
// por noche según temporada y plan, origen, pedidos especiales, adelanto, confirmación por correo o WhatsApp, tarjeta de registro,
// historial y cuenta del huésped (resumen). El check-in, los cargos y el check-out se hacen en Recepción.
import { api, toast, money, fmt, fecha, hoy, sumarDias, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { cuentasParaMovimientos, cuentaPrincipal, cuentaParaMedio } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta
import { PAISES, GENTILICIOS, config, categorias, habitaciones, reserva, reservaNueva, guardarReserva, cambiarReserva, anotar, huesped, huespedNuevo, guardarHuesped, buscarHuespedes, nombreHuesped, cotizar, disponibles, noches, nuevoNumero, ESTADOS, ORIGENES, OCASIONES, TIPOS_DOC, MEDIOS, nombreMedio, nombreHab, nombreCat, folioDe, totalesFolio, registrarPago, anularPago, textoConfirmacion, textoMensaje, enlaceWhatsApp, abrirHoja, tarjetaRegistroHTML, numeroVisita, insignia, textoVisita, estadiasDe, r2, hotelActivo, claseEstado, sincronizarHospedaje, capacidadHab, capacidadCat, rangoPersonasCat, descripcionHab, MONEDAS_HOTEL, tcPago, convertirPago, equivalente, textoCambio, segmentos, estanciaMinima, depositosPara, aplicarDeposito, depositoDisponible, agencias, agenciaDe, agenciaVigente, MODALIDADES_AGENCIA, hoyHotel, TRASLADOS } from './_datos.js';

export default {
  props: ['params'],
  data() {
    const cfg = config(), id = this.params.id ? +this.params.id : null, existente = id ? reserva(id) : null;
    let f = existente ? JSON.parse(JSON.stringify(existente)) : reservaNueva(cfg);
    if (!existente) {
      if (this.params.fecha) { f.llegada = this.params.fecha; f.salida = sumarDias(this.params.fecha, 1); }
      if (this.params.habitacion) { const h = habitaciones().find(x => x.id === +this.params.habitacion); if (h) { f.habitacion_id = h.id; f.categoria_id = h.categoria_id; } }
      if (this.params.walkin) { f.llegada = hoyHotel(); f.salida = sumarDias(hoyHotel(), 1); f.origen = 'directa'; }
      // desde la lista de espera o una cotización (3.22): los datos ya vienen puestos
      if (this.params.categoria) f.categoria_id = +this.params.categoria || null;
      if (this.params.llegada) f.llegada = this.params.llegada;
      if (this.params.salida) f.salida = this.params.salida;
      if (this.params.adultos) f.adultos = +this.params.adultos || 1;
      if (this.params.nombre) f.huesped_nombre = decodeURIComponent(this.params.nombre);
      if (this.params.espera) f.notas = 'Desde la lista de espera';
      if (this.params.cot) { const q = (mock.get('hotel_cotizaciones', []) || []).find(x => x.id === +this.params.cot); if (q) { Object.assign(f, { huesped_nombre: q.nombre, categoria_id: q.categoria_id, llegada: q.llegada, salida: q.salida, adultos: +q.adultos || 1, ninos: +q.ninos || 0, plan_id: q.plan_id || f.plan_id, precio_manual: q.precio_manual === null || q.precio_manual === undefined || q.precio_manual === '' ? f.precio_manual : q.precio_manual, cotizacion_id: q.id, notas: ['Cotización ' + q.numero + ' · ' + money(q.total, q.moneda), q.notas].filter(Boolean).join('\n') }); } }
      if (!f.categoria_id && categorias().length === 1) f.categoria_id = categorias()[0].id;
    }
    for (const k of ['vuelo_llegada', 'hora_vuelo_llegada', 'vuelo_salida', 'hora_vuelo_salida', 'traslado', 'traslado_nota']) if (f[k] === undefined || f[k] === null) f[k] = '';   // H8: las reservas anteriores no traen estos campos
    const hid = existente && existente.huesped_id ? existente.huesped_id : (this.params.huesped ? +this.params.huesped : null);
    const h = hid && huesped(hid) ? { ...huespedNuevo(), ...huesped(hid) } : huespedNuevo();
    return { cfg, id, f, noEncontrada: !!(id && !existente), h, modoH: hid && huesped(hid) ? 'elegido' : 'buscar', qH: '', cats: categorias(), guardando: false, verNoches: false, segs: segmentos(cfg), depositoSel: null, depositoMonto: 0,
      adelanto: null, cuentas: [], correo: null, PAISES, GENTILICIOS, MONEDAS_HOTEL, ORIGENES, OCASIONES, TIPOS_DOC, MEDIOS, ESTADOS, TRASLADOS, walkin: !!this.params.walkin, activo: hotelActivo(), precioManual: existente ? existente.precio_manual !== null && existente.precio_manual !== undefined : false };
  },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    esNueva() { return !this.id; },
    editable() { return this.esNueva || ['pendiente', 'confirmada', 'en_casa'].includes(this.f.estado); },
    cat() { return this.cats.find(c => c.id === this.f.categoria_id) || null; },
    personas() { return (+this.f.adultos || 0) + (+this.f.ninos || 0); },
    // capacidad de la habitación elegida (cada habitación define sus personas y camas); sin habitación, la mayor de la categoría
    capacidad() { if (this.habActual) return capacidadHab(this.habActual) || capacidadCat(this.f.categoria_id); return this.f.categoria_id ? capacidadCat(this.f.categoria_id) : 0; },
    agenciasLista() { return agencias().filter(a => a.activo !== false); },
    agenciaSel() { return this.f.agencia_id ? agenciaDe(this.f.agencia_id) : null; },
    cot() { return cotizar({ categoria_id: this.f.categoria_id, llegada: this.f.llegada, salida: this.f.salida, plan_id: this.f.plan_id, personas: this.personas, precio_manual: this.precioManual ? this.f.precio_manual : null, capacidad: this.capacidad, agencia: this.agenciaSel }, this.cfg); },
    habsDisp() { return this.f.llegada && this.f.salida && this.f.salida > this.f.llegada ? disponibles(this.f.categoria_id, this.f.llegada, this.f.salida, this.id) : []; },
    // libres por categoría para estas fechas (3.22): se ve en la lista de categorías antes de elegir
    dispCat() { const m = {}; if (!(this.f.llegada && this.f.salida && this.f.salida > this.f.llegada)) return m; const habs = habitaciones().filter(h => h.activa !== false); for (const c of this.cats) m[c.id] = { libres: disponibles(c.id, this.f.llegada, this.f.salida, this.id).length, total: habs.filter(h => h.categoria_id === c.id).length }; return m; },
    sinHabitacion() { return !this.id && !!this.f.categoria_id && !!this.f.llegada && this.f.salida > this.f.llegada && !this.habsDisp.length && !this.f.habitacion_id; },
    habActual() { return this.f.habitacion_id ? habitaciones().find(h => h.id === this.f.habitacion_id) || null : null; },
    habNoDisponible() { return !!this.f.habitacion_id && !this.habsDisp.some(h => h.id === this.f.habitacion_id); },
    sugerencias() { return this.modoH === 'buscar' ? buscarHuespedes(this.qH) : []; },
    adelantoReq() { return this.sinAdelanto ? 0 : r2(this.cot.total * (+this.cfg.adelanto_pct || 0) / 100); },
    folio() { return this.id ? folioDe(this.id) : []; },
    totFolio() { return totalesFolio(this.folio); },
    pagos() { return this.folio.filter(x => x.tipo === 'pago'); },
    visita() { return this.id ? numeroVisita(this.f) : (this.h.id ? estadiasDe(this.h.id).length + 1 : 1); },
    estadias() { return this.h.id ? estadiasDe(this.h.id).filter(r => r.id !== this.id) : []; },
    sinTarifa() { return !!this.cat && this.cot.noches > 0 && !this.precioManual && this.cot.detalle.every(d => !d.precio); },
    waLink() { return this.h.telefono ? enlaceWhatsApp(this.h.telefono, textoConfirmacion(this.vistaPrevia(), this.cfg)) : ''; },
    waPre() { return this.h.telefono && this.cfg.mensaje_prellegada ? enlaceWhatsApp(this.h.telefono, textoMensaje(this.cfg.mensaje_prellegada, this.vistaPrevia(), this.cfg)) : ''; },   // pre-llegada (3.21)
    // contrato con tarifa neta (crédito): el hospedaje lo paga la agencia o la empresa, así que la reserva no pide adelanto (3.21)
    sinAdelanto() { return !!(this.agenciaSel && this.agenciaSel.modalidad === 'neta' && agenciaVigente(this.agenciaSel, this.f.llegada)); },
    tiene() { return { correo: !!(this.h.correo || '').includes('@'), smtp: !!(store.empresa && store.empresa.smtp_host) }; },
    historial() { return (this.f.historial || []).slice().reverse(); },
    estanciaMin() { return estanciaMinima(this.f.llegada, this.f.salida, this.cfg); },
    depositosDisp() { return this.id ? depositosPara({ ...this.f, huesped_id: this.h.id || this.f.huesped_id }) : []; },
  },
  watch: {
    'f.llegada'(v) { if (v && this.f.salida <= v) this.f.salida = sumarDias(v, 1); },
    'adelanto.medio'(m) { if (this.adelanto) { const b = cuentaParaMedio(m, this.adelanto.moneda_pago || this.cot.moneda, this.cuentas); if (b) this.adelanto.cuenta = b.nombre; } },   // 4.5: el medio decide la cuenta (efectivo → Efectivo; tarjeta, SINPE o transferencia → Banco)
    habsDisp() { if (this.f.habitacion_id && this.habNoDisponible && this.esNueva) this.f.habitacion_id = null; },
  },
  methods: {
    equivalente,
    money, fmt, fecha, nombreMedio, nombreHab, nombreCat, nombreHuesped, textoVisita, insignia, claseEstado, rangoPersonasCat, descripcionHab, depositoDisponible,
    agenciaVigente,
    vistaPrevia() { const c = this.cot; return { ...this.f, huesped_nombre: nombreHuesped(this.h), noches: c.noches, total: c.total, adelanto_requerido: this.f.adelanto_requerido || this.adelantoReq, moneda: c.moneda, numero: this.f.numero || nuevoNumero(this.cfg) }; },
    elegirH(x) { this.h = { ...huespedNuevo(), ...x }; this.modoH = 'elegido'; this.qH = ''; },
    nuevoH() { const n = huespedNuevo(); if (/\d/.test(this.qH)) n.documento = this.qH.trim(); else n.nombre = this.qH.trim(); this.h = n; this.modoH = 'nuevo'; this.qH = ''; },
    quitarH() { this.h = huespedNuevo(); this.modoH = 'buscar'; },
    usarManual(v) { this.precioManual = v; if (v && (this.f.precio_manual === null || this.f.precio_manual === undefined)) this.f.precio_manual = this.cot.promedio; if (!v) this.f.precio_manual = null; },
    validar() {
      if (!(this.h.nombre || '').trim()) return 'Indique el nombre del huésped';
      if (!this.f.llegada || !this.f.salida || this.f.salida <= this.f.llegada) return 'La salida debe ser posterior a la llegada';
      if (!this.f.categoria_id) return 'Elija la categoría de habitación';
      if (this.personas < 1) return 'Indique al menos una persona';
      if (this.f.habitacion_id && this.habNoDisponible) return 'La habitación ' + nombreHab(this.f.habitacion_id) + ' no está disponible esas noches: elija otra';
      if (this.sinTarifa) return 'La categoría no tiene precio: defínalo en Habitaciones y tarifas o escriba un precio por noche';
      { const em = estanciaMinima(this.f.llegada, this.f.salida, this.cfg); if (this.cot.noches < em.noches && this.esNueva) return 'Estancia mínima de ' + em.noches + ' noches' + (em.temporada ? ' en la temporada ' + em.temporada.nombre : '') + ' (hoy: ' + this.cot.noches + ')'; }
      if (this.adelanto && !(+this.adelanto.monto_pago > 0)) return 'Indique el monto del adelanto';
      return '';
    },
    async guardar(destino) {
      const e = this.validar(); if (e) return toast(e, 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      try {
        const hu = guardarHuesped({ ...this.h, nombre: this.h.nombre.trim(), apellidos: (this.h.apellidos || '').trim() });
        const c = this.cot, nueva = this.esNueva;
        let f = { ...this.f, huesped_id: hu.id, huesped_nombre: nombreHuesped(hu), vip: !!hu.vip, noches: c.noches, tarifa_noche: c.promedio, neto: c.neto, iva: c.iva, total: c.total, moneda: c.moneda, precio_manual: this.precioManual ? +this.f.precio_manual : null, adultos: +this.f.adultos || 0, ninos: +this.f.ninos || 0 };
        if (nueva) { f.numero = nuevoNumero(this.cfg); f.adelanto_requerido = this.adelantoReq; f.estado = this.walkin || this.sinAdelanto ? 'confirmada' : (+this.cfg.adelanto_pct > 0 && !this.adelanto ? 'pendiente' : 'confirmada'); f = anotar(f, 'Reserva creada' + (this.walkin ? ' (huésped sin reserva previa)' : this.sinAdelanto ? ' (confirmada: contrato a crédito de ' + this.agenciaSel.nombre + ')' : '')); }
        else { const antes = reserva(this.id) || {}; const cambios = []; if (antes.llegada !== f.llegada || antes.salida !== f.salida) cambios.push('fechas ' + fecha(f.llegada) + ' al ' + fecha(f.salida)); if (antes.habitacion_id !== f.habitacion_id) cambios.push('habitación ' + nombreHab(f.habitacion_id)); if (Math.abs((+antes.total || 0) - f.total) > 0.005) cambios.push('total ' + money(f.total, f.moneda)); if (cambios.length) f = anotar(f, 'Cambio: ' + cambios.join(', ')); if (f.estado === 'pendiente' && this.adelanto) { f.estado = 'confirmada'; f = anotar(f, 'Confirmada con adelanto'); } }
        const { reg, promesa } = guardarReserva(f);
        const ok = await promesa;
        if (!ok) { this.guardando = false; return; }
        if (this.adelanto) { await registrarPago(reg, { ...this.adelanto, monto: this.adelantoFolio(), detalle: 'Adelanto ' + nombreMedio(this.adelanto.medio) + (this.adelanto.referencia ? ' · ' + this.adelanto.referencia : '') }); }
        if (reg.estado === 'en_casa') sincronizarHospedaje(reg, this.cfg);
        toast('Reserva ' + reg.numero + (nueva ? ' creada' : ' guardada') + (reg.estado === 'pendiente' ? ' · pendiente de adelanto' : ''), 'ok');
        if (destino === 'recepcion' || this.walkin) location.hash = '/hotel/recepcion?reserva=' + reg.id;
        else if (nueva) location.hash = '/hotel/reservaciones/' + reg.id;
        else { this.f = JSON.parse(JSON.stringify(reg)); this.adelanto = null; }
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    // depósito en garantía (3.0): aplicar parte de un depósito disponible del huésped, contacto o grupo a esta reserva
    aplicarDep() {
      const d = this.depositosDisp.find(x => x.id === this.depositoSel); if (!d) return toast('Elija el depósito', 'err');
      const m = +this.depositoMonto || 0; if (!(m > 0) || m > depositoDisponible(d) + 0.005) return toast('El monto debe ser mayor que cero y no superar lo disponible', 'err');
      if (!mock.puedeGuardar()) return;
      const item = aplicarDeposito(d, this.f, m); if (!item) return;
      if (this.f.estado === 'pendiente') { const { reg } = cambiarReserva(this.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada con depósito en garantía ' + d.numero)); if (reg) this.f = JSON.parse(JSON.stringify(reg)); }
      else { const { reg } = cambiarReserva(this.id, x => anotar(x, 'Depósito en garantía ' + d.numero + ' aplicado: ' + money(item.monto, this.f.moneda))); if (reg) this.f = JSON.parse(JSON.stringify(reg)); }
      this.depositoSel = null; this.depositoMonto = 0; toast('Depósito aplicado a la cuenta', 'ok');
    },
    abrirAdelanto() { const b = cuentaParaMedio('06', this.cfg.moneda, this.cuentas) || cuentaParaMedio('06', 'CRC', this.cuentas), m = Math.max(0, r2((this.f.adelanto_requerido || this.adelantoReq) - this.totFolio.pagos)) || this.adelantoReq; this.adelanto = { moneda_pago: this.cot.moneda, monto_pago: m, medio: '06', cuenta: b ? b.nombre : '', fecha: hoyHotel(), referencia: '' }; },
    // el adelanto puede venir en la otra moneda (2.9): se convierte con el margen del hotel
    adelantoFolio() { const a = this.adelanto; return a ? convertirPago(a.monto_pago, a.moneda_pago || this.cot.moneda, this.cot.moneda) : 0; },
    adelantoTexto() { const a = this.adelanto; return a ? (textoCambio(a.monto_pago, a.moneda_pago || this.cot.moneda, this.cot.moneda) || equivalente(a.monto_pago, this.cot.moneda)) : ''; },
    cambiarMonedaAdelanto(m) { const a = this.adelanto, tc = tcPago(m, this.cot.moneda), base = this.adelantoFolio(); a.moneda_pago = m; a.monto_pago = !tc ? r2(base) : (this.cot.moneda === 'USD' ? r2(base * tc) : r2(base / tc)); const b = cuentaParaMedio(a.medio, m, this.cuentas); if (b) a.cuenta = b.nombre; },   // 4.5: según el medio
    async registrarAdelantoAhora() {
      if (!(+this.adelanto.monto_pago > 0)) return toast('Indique el monto', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const monto = this.adelantoFolio();
      await registrarPago(this.f, { ...this.adelanto, monto, detalle: 'Adelanto ' + nombreMedio(this.adelanto.medio) + (this.adelanto.referencia ? ' · ' + this.adelanto.referencia : '') });
      if (this.f.estado === 'pendiente') { const { reg, promesa } = cambiarReserva(this.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada con adelanto de ' + money(monto, this.f.moneda))); if (await promesa) this.f = JSON.parse(JSON.stringify(reg)); }
      else { const { reg } = cambiarReserva(this.id, x => anotar(x, 'Pago de ' + money(monto, this.f.moneda))); if (reg) this.f = JSON.parse(JSON.stringify(reg)); }
      this.adelanto = null; this.guardando = false; toast('Pago registrado en la cuenta del huésped', 'ok');
    },
    async anular(p) { if (!confirm('¿Anular el pago de ' + money(p.monto, this.f.moneda) + '? Si entró a Bancos, se quita el movimiento.')) return; await anularPago(p); const { reg } = cambiarReserva(this.id, x => anotar(x, 'Pago anulado: ' + money(p.monto, this.f.moneda))); if (reg) this.f = JSON.parse(JSON.stringify(reg)); toast('Pago anulado', 'ok'); },
    async confirmar() { const { reg, promesa } = cambiarReserva(this.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada sin adelanto')); if (await promesa) { this.f = JSON.parse(JSON.stringify(reg)); toast('Reserva confirmada', 'ok'); } },
    async cancelar(noShow) {
      const motivo = window.prompt(noShow ? 'El huésped no se presentó. Motivo o nota (opcional):' : 'Motivo de la cancelación (opcional):', ''); if (motivo === null) return;
      const estado = noShow ? 'no_show' : 'cancelada';
      const { reg, promesa } = cambiarReserva(this.id, x => anotar({ ...x, estado, motivo_cancelacion: motivo }, (noShow ? 'No llegó' : 'Cancelada') + (motivo ? ': ' + motivo : '')));
      if (await promesa) { this.f = JSON.parse(JSON.stringify(reg)); toast(noShow ? 'Marcada como no presentada' : 'Reserva cancelada', 'ok'); }
    },
    abrirCorreo() { this.correo = { para: this.h.correo || '', asunto: 'Confirmación de reserva ' + (this.f.numero || '') + ' · ' + (this.cfg.nombre || (store.empresa || {}).nombre_comercial || ''), texto: textoConfirmacion(this.vistaPrevia(), this.cfg) }; },
    async enviarCorreo() {
      if (!(this.correo.para || '').includes('@')) return toast('Indique el correo del huésped', 'err');
      this.guardando = true;
      try { await api('/api/hotel/correo', { method: 'POST', body: this.correo }); toast('Confirmación enviada a ' + this.correo.para, 'ok'); if (this.id) { const { reg } = cambiarReserva(this.id, x => anotar(x, 'Confirmación enviada por correo a ' + this.correo.para)); if (reg) this.f = JSON.parse(JSON.stringify(reg)); } this.correo = null; }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    whatsapp() { window.open(this.waLink, '_blank'); if (this.id) { const { reg } = cambiarReserva(this.id, x => anotar(x, 'Confirmación enviada por WhatsApp')); if (reg) this.f = JSON.parse(JSON.stringify(reg)); } },
    tarjeta() { abrirHoja('Tarjeta de registro ' + (this.f.numero || ''), tarjetaRegistroHTML(this.vistaPrevia(), this.h)); },
    copiar() { navigator.clipboard?.writeText(textoConfirmacion(this.vistaPrevia(), this.cfg)).then(() => toast('Texto copiado', 'ok')); },
  },
  async created() { try { this.cuentas = await cuentasParaMovimientos(); } catch {} },
  template: `
  <div class="page">
    <div class="card" v-if="noEncontrada"><Empty icon="⚠" title="Reserva no encontrada" text="No existe o fue eliminada."><a class="btn" href="#/hotel/reservaciones">Ir a Reservaciones</a></Empty></div>
    <div class="card" v-else-if="!activo"><Empty icon="🛏" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <PageHead :title="esNueva ? (walkin ? 'Huésped sin reserva (walk-in)' : 'Nueva reserva') : 'Reserva ' + f.numero" :sub="esNueva ? 'Huésped, fechas, habitación y precio. El adelanto confirma la reserva.' : ESTADOS[f.estado] + ' · creada ' + fecha(f.creado) + (f.usuario ? ' por ' + f.usuario : '')" :crumbs="[{label:'Hotel'},{label:'Reservaciones',to:'/hotel/reservaciones'},{label: esNueva ? 'Nueva' : f.numero}]">
      <span v-if="!esNueva" class="hbadge" :class="claseEstado(f)">{{ESTADOS[f.estado]}}</span>
      <template v-if="!esNueva">
        <button class="btn sec" @click="abrirCorreo" :disabled="!tiene.smtp" :title="tiene.smtp ? '' : 'Configure el correo saliente de la empresa'">✉ Correo</button>
        <a class="btn sec" :href="waLink" target="_blank" rel="noopener" v-if="waLink" @click="whatsapp">WhatsApp</a>
        <a class="btn sec" :href="waPre" target="_blank" rel="noopener" v-if="waPre && ['confirmada','pendiente'].includes(f.estado)" title="Datos útiles antes de la llegada (wifi, horarios, cómo llegar)">Pre-llegada</a>
        <button class="btn sec" @click="tarjeta">Tarjeta de registro</button>
        <a class="btn" :href="'#/hotel/recepcion?reserva=' + id" v-if="['pendiente','confirmada'].includes(f.estado) && f.llegada <= hoyHotel()">Check-in</a>
        <a class="btn" :href="'#/hotel/recepcion?reserva=' + id" v-else-if="f.estado==='en_casa'">Cuenta y check-out</a>
      </template>
    </PageHead>
    <div class="alert warn" v-if="!esNueva && f.estado==='pendiente'">Pendiente de adelanto{{f.adelanto_requerido ? ' de ' + money(f.adelanto_requerido, f.moneda) : ''}}. Registre el adelanto o confírmela sin adelanto.
      <button class="btn sm" style="margin-left:8px" @click="abrirAdelanto" v-if="puedeEscribir">Registrar adelanto</button><button class="btn sm ghost" style="margin-left:6px" @click="confirmar" v-if="puedeEscribir">Confirmar sin adelanto</button></div>
    <div class="alert info" v-if="!esNueva && ['salio','cancelada','no_show'].includes(f.estado)">Esta reserva ya {{f.estado==='salio' ? 'terminó (el huésped salió' + (f.consecutivo ? ' · comprobante ' + f.consecutivo : '') + ')' : f.estado==='cancelada' ? 'fue cancelada' : 'quedó como no presentada'}}{{f.motivo_cancelacion ? ': ' + f.motivo_cancelacion : ''}}. No se puede editar.</div>
    <div class="grid cols-2" style="align-items:start">
      <div>
        <div class="card"><h2>Huésped <span v-if="visita>1" class="visita" :title="textoVisita(visita)">{{insignia(visita)}}</span><span v-if="h.vip" class="badge warn" style="margin-left:6px">VIP</span></h2>
          <div v-if="modoH==='buscar'" style="position:relative">
            <input class="inp" style="width:100%" v-model="qH" placeholder="Buscar por nombre, documento, teléfono o correo… o escriba el nombre de un huésped nuevo" @keyup.enter="sugerencias.length ? elegirH(sugerencias[0]) : nuevoH()" autofocus>
            <div class="pos-sug" v-if="qH.trim()" style="top:42px"><div v-for="x in sugerencias" :key="x.id" class="it" @mousedown.prevent="elegirH(x)"><b>{{nombreHuesped(x)}}</b> <span class="muted small">{{x.documento}} · {{x.telefono}}</span><span class="visita" v-if="estadiasDe(x.id).length">×{{estadiasDe(x.id).length + 1}}</span></div><div class="it nuevo" @mousedown.prevent="nuevoH">+ Huésped nuevo «{{qH}}»</div></div>
            <p class="small muted" style="margin:8px 0 0">Si ya se hospedó antes, aparece aquí con su número de visita; sus datos y preferencias se cargan solos.</p>
          </div>
          <template v-else>
            <div class="row" style="justify-content:space-between;margin-bottom:8px" v-if="modoH==='elegido'"><span class="small muted">Huésped registrado{{estadias.length ? ' · ' + estadias.length + ' estadía(s) anterior(es)' : ''}}</span><button class="btn sm ghost" @click="quitarH" v-if="editable">Cambiar de huésped</button></div>
            <div class="grid cols-2">
              <Field label="Nombre" req><input v-model="h.nombre" maxlength="60" :disabled="!editable"></Field>
              <Field label="Apellidos"><input v-model="h.apellidos" maxlength="60" :disabled="!editable"></Field>
              <Field label="Documento"><div class="row" style="gap:6px;flex-wrap:nowrap"><select v-model="h.tipo_doc" style="width:120px" :disabled="!editable"><option v-for="t in TIPOS_DOC" :key="t[0]" :value="t[0]">{{t[1]}}</option></select><input v-model="h.documento" maxlength="30" style="flex:1;min-width:0" :disabled="!editable"></div></Field>
              <Field label="Nacionalidad"><input v-model="h.nacionalidad" maxlength="40" :disabled="!editable" list="hotel-paises" autocomplete="off" placeholder="Escriba para ver coincidencias"></Field>
              <Field label="Teléfono (WhatsApp)" help="8 dígitos en Costa Rica; con código de país si es extranjero"><input v-model="h.telefono" maxlength="20" :disabled="!editable"></Field>
              <Field label="Correo"><input type="email" v-model="h.correo" maxlength="80" :disabled="!editable"></Field>
              <Field label="Fecha de nacimiento" help="Para el reporte de cumpleaños"><input type="date" v-model="h.nacimiento" :disabled="!editable"></Field>
              <Field label="Ciudad y país"><div class="row" style="gap:6px;flex-wrap:nowrap"><input v-model="h.ciudad" maxlength="40" placeholder="Ciudad" style="flex:1;min-width:0" :disabled="!editable"><input v-model="h.pais" maxlength="40" placeholder="País" style="flex:1;min-width:0" :disabled="!editable" list="hotel-paises" autocomplete="off"></div></Field>
              <datalist id="hotel-paises"><option v-for="p in PAISES" :key="p" :value="p">{{GENTILICIOS[p] || ''}}</option></datalist>
              <Field label="Preferencias" help="Almohada, piso, dieta, cuna…" style="grid-column:1/-1"><input v-model="h.preferencias" maxlength="200" :disabled="!editable"></Field>
            </div>
            <div class="row" style="margin-top:10px;gap:16px"><Toggle v-model="h.vip" label="Huésped VIP (avisa a recepción, restaurante y limpieza)"></Toggle><Toggle v-model="h.no_marketing" label="No enviar promociones"></Toggle></div>
          </template>
        </div>
        <div class="card"><h2>Estadía</h2>
          <div class="grid cols-2">
            <Field label="Llegada" req><input type="date" v-model="f.llegada" :disabled="!editable || f.estado==='en_casa'"></Field>
            <Field label="Salida" req :help="cot.noches + ' noche(s)'"><input type="date" v-model="f.salida" :min="f.llegada" :disabled="!editable"></Field>
            <Field label="Adultos" req><input type="number" min="1" max="30" v-model.number="f.adultos" :disabled="!editable"></Field>
            <Field label="Niños"><input type="number" min="0" max="30" v-model.number="f.ninos" :disabled="!editable"></Field>
            <Field label="Categoría" req :help="cat ? [rangoPersonasCat(cat.id), cat.descripcion].filter(Boolean).join(' · ') : ''"><select v-model="f.categoria_id" :disabled="!editable || f.estado==='en_casa'"><option :value="null">— Elegir —</option><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}{{dispCat[c.id] ? ' · ' + dispCat[c.id].libres + ' de ' + dispCat[c.id].total + ' libres' : ''}}</option></select></Field>
            <Field label="Habitación" :help="f.habitacion_id ? '' : 'Puede asignarse al llegar'"><select v-model="f.habitacion_id" :disabled="!editable"><option :value="null">— Asignar al llegar —</option><option v-if="habActual && habNoDisponible" :value="habActual.id">{{habActual.numero}} (no disponible)</option><option v-for="x in habsDisp" :key="x.id" :value="x.id">{{x.numero}}<span v-if="!f.categoria_id"> · {{nombreCat(x.categoria_id)}}</span>{{descripcionHab(x) ? ' · ' + descripcionHab(x) : ''}}{{x.estado && x.estado !== 'limpia' ? ' · ' + x.estado : ''}}</option></select></Field>
            <div class="alert warn" style="grid-column:1/-1;margin:0" v-if="sinHabitacion">No queda habitación {{cat ? cat.nombre : ''}} libre para esas fechas. <a class="link" :href="'#/hotel/espera?nuevo=1&categoria=' + f.categoria_id + '&llegada=' + f.llegada + '&salida=' + f.salida + '&nombre=' + encodeURIComponent(f.huesped_nombre || '')">Anotar en la lista de espera</a></div>
            <Field label="Plan"><select v-model="f.plan_id" :disabled="!editable"><option v-for="p in cfg.planes" :key="p.id" :value="p.id">{{p.nombre}}{{p.pct ? ' (' + (p.pct > 0 ? '+' : '') + p.pct + ' %)' : ''}}</option></select></Field>
            <Field label="Origen" req><select v-model="f.origen" :disabled="!editable"><option v-for="o in ORIGENES" :key="o[0]" :value="o[0]">{{o[1]}}</option></select></Field>
            <Field label="Segmento" help="Para los reportes por segmento de mercado"><select v-model="f.segmento" :disabled="!editable"><option value="">— Sin segmento —</option><option v-for="s in segs" :key="s" :value="s">{{s}}</option></select></Field>
            <Field label="Agencia o empresa con contrato" v-if="agenciasLista.length || f.agencia_id" :help="agenciaSel ? (agenciaSel.modalidad === 'neta' ? 'Tarifa neta: el hospedaje se factura a la agencia; el huésped paga solo los extras' : 'Comisión ' + (agenciaSel.comision_pct || 0) + ' %: el huésped paga todo') + (agenciaVigente(agenciaSel, f.llegada) ? '' : ' · contrato fuera de vigencia') : 'Aplica su tarifa de contrato o su descuento'" style="grid-column:1/-1"><Buscador v-model="f.agencia_id" :opciones="agenciasLista" :detalle="a => a.tipo === 'empresa' ? 'empresa' : 'agencia'" placeholder="Sin contrato" :disabled="!editable" agregar="agencia"></Buscador></Field>
            <Field label="Referencia del canal o agencia" help="Número de Booking, Airbnb, voucher…" v-if="f.origen!=='directa'"><input v-model="f.referencia" maxlength="60" :disabled="!editable"></Field>
            <Field label="Grupo o empresa" help="Varias reservas bajo un mismo responsable"><input v-model="f.grupo" maxlength="60" :disabled="!editable"></Field>
            <Field label="Ocasión"><select v-model="f.ocasion" :disabled="!editable"><option v-for="o in OCASIONES" :key="o[0]" :value="o[0]">{{o[1]}}</option></select></Field>
            <Field label="Vehículo (placa)"><input v-model="f.vehiculo" maxlength="20" :disabled="!editable"></Field>
            <Field label="Vuelo de llegada" help="Aerolínea y número; sale en el reporte de transporte"><input v-model="f.vuelo_llegada" maxlength="12" placeholder="AV 641" :disabled="!editable"></Field>
            <Field label="Hora del vuelo de llegada"><input type="time" v-model="f.hora_vuelo_llegada" :disabled="!editable"></Field>
            <Field label="Vuelo de salida"><input v-model="f.vuelo_salida" maxlength="12" placeholder="AV 642" :disabled="!editable"></Field>
            <Field label="Hora del vuelo de salida"><input type="time" v-model="f.hora_vuelo_salida" :disabled="!editable"></Field>
            <Field label="Traslado"><select v-model="f.traslado" :disabled="!editable"><option v-for="t in TRASLADOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
            <Field label="Nota del traslado" help="Punto de encuentro, maletas, quién lo paga…"><input v-model="f.traslado_nota" maxlength="120" :disabled="!editable"></Field>
            <Field label="Pedidos especiales" help="Cuna, dieta, piso alto, llegada tarde… salen en el reporte del día" style="grid-column:1/-1"><input v-model="f.especiales" maxlength="200" :disabled="!editable"></Field>
            <Field label="Acompañantes" help="Nombres de las demás personas" style="grid-column:1/-1"><input v-model="f.acompanantes" maxlength="200" :disabled="!editable"></Field>
            <Field label="Notas internas" style="grid-column:1/-1"><textarea rows="2" v-model="f.notas" :disabled="!editable"></textarea></Field>
          </div>
          <div class="alert warn" style="margin:10px 0 0" v-if="capacidad && personas > capacidad">{{personas}} personas en una habitación para {{capacidad}}: se cobra persona adicional{{cfg.persona_extra ? ' (' + money(cfg.persona_extra, cfg.moneda) + ' por noche cada una)' : ' (defina el monto en Habitaciones y tarifas)'}}.</div>
          <div class="alert err" style="margin:10px 0 0" v-if="habNoDisponible">La habitación {{habActual ? habActual.numero : ''}} ya está ocupada en esas noches.</div>
        </div>
      </div>
      <div>
        <div class="card"><h2>Precio <small>{{cfg.precios_incluyen_iva ? 'IVA incluido' : 'más IVA'}} · {{cot.moneda}}</small></h2>
          <div class="row" style="gap:14px;margin-bottom:8px"><label class="row" style="gap:6px;cursor:pointer"><input type="radio" :checked="!precioManual" @change="usarManual(false)" :disabled="!editable"> Según tarifas y temporada</label><label class="row" style="gap:6px;cursor:pointer"><input type="radio" :checked="precioManual" @change="usarManual(true)" :disabled="!editable"> Precio por noche acordado</label></div>
          <Field label="Precio por noche acordado" v-if="precioManual"><input type="number" min="0" step="0.01" v-model.number="f.precio_manual" :disabled="!editable"></Field>
          <div class="alert warn" v-if="sinTarifa" style="margin:8px 0">La categoría no tiene precio definido para estas fechas.</div>
          <div class="totals" style="align-items:stretch">
            <div><span>{{cot.noches}} noche(s) · promedio {{money(cot.promedio, cot.moneda)}}</span><b>{{money(cot.total, cot.moneda)}}</b></div>
            <div v-if="cot.extra_personas"><span>Incluye persona adicional por noche</span><b>{{money(cot.extra_personas, cot.moneda)}}</b></div>
            <div><span>Sin IVA</span><b>{{money(cot.neto, cot.moneda)}}</b></div><div><span>IVA {{cfg.tarifa_iva}} %</span><b>{{money(cot.iva, cot.moneda)}}</b></div>
            <div class="total"><span>Total de la estadía</span><b>{{money(cot.total, cot.moneda)}}</b></div><div><span class="muted">Equivale a</span><b class="muted">{{equivalente(cot.total, cot.moneda)}}</b></div>
            <div v-if="cfg.adelanto_pct > 0"><span>Adelanto ({{cfg.adelanto_pct}} %)</span><b>{{money(esNueva ? adelantoReq : (f.adelanto_requerido || adelantoReq), cot.moneda)}}</b></div>
          </div>
          <a class="link small" style="cursor:pointer" @click="verNoches=!verNoches">{{verNoches ? 'Ocultar' : 'Ver'}} el detalle por noche</a>
          <table class="tbl" v-if="verNoches" style="margin-top:6px"><thead><tr><th>Noche</th><th>Temporada</th><th class="num">Precio</th></tr></thead><tbody><tr v-for="d in cot.detalle" :key="d.fecha"><td>{{fecha(d.fecha)}}</td><td>{{d.temporada || 'Tarifa base'}}</td><td class="num">{{money(d.precio, cot.moneda)}}</td></tr></tbody></table>
        </div>
        <div class="alert info" v-if="sinAdelanto" style="margin-bottom:12px">Contrato a crédito con {{agenciaSel.nombre}}: el hospedaje se factura a la agencia o empresa, la reserva queda confirmada sin adelanto.</div>
        <div class="card" v-if="esNueva && cfg.adelanto_pct > 0 && !walkin && !sinAdelanto"><h2>Adelanto <small>confirma la reserva</small></h2>
          <div v-if="!adelanto"><p class="small muted" style="margin:0 0 8px">Sin adelanto la reserva queda <b>pendiente</b>; puede registrarlo ahora o después desde la reserva.</p><button class="btn sec sm" @click="abrirAdelanto">Registrar el adelanto ahora</button></div>
          <div v-else>
            <div class="grid cols-2">
              <Field label="Moneda en que paga" :help="'La reserva está en ' + cot.moneda"><select :value="adelanto.moneda_pago" @change="cambiarMonedaAdelanto($event.target.value)"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field>
              <Field :label="'Monto en ' + adelanto.moneda_pago" req :help="adelantoTexto()"><input type="number" min="0" step="0.01" v-model.number="adelanto.monto_pago"></Field>
              <Field label="Medio"><select v-model="adelanto.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field>
              <Field label="Cuenta de Bancos donde entra"><Buscador v-model="adelanto.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
              <Field label="Referencia" help="Número de SINPE, voucher…"><input v-model="adelanto.referencia" maxlength="40"></Field>
            </div>
            <button class="btn ghost sm" style="margin-top:8px" @click="adelanto=null">Sin adelanto por ahora</button>
          </div>
        </div>
        <div class="card" v-if="!esNueva"><h2>Cuenta del huésped <small>resumen</small></h2>
          <div class="totals" style="align-items:stretch"><div><span>Cargos</span><b>{{money(totFolio.cargos, f.moneda)}}</b></div><div><span>Pagos y adelantos</span><b>{{money(totFolio.pagos, f.moneda)}}</b></div><div class="total"><span>{{f.estado==='en_casa' || f.estado==='salio' ? 'Saldo' : 'Por pagar de la estadía'}}</span><b>{{money(f.estado==='en_casa' || f.estado==='salio' ? totFolio.saldo : Math.max(0, f.total - totFolio.pagos), f.moneda)}}</b></div></div>
          <table class="tbl" v-if="pagos.length" style="margin-top:8px"><tbody><tr v-for="p in pagos" :key="p.id"><td>{{fecha(p.fecha)}}</td><td>{{p.detalle}}<span class="small muted" v-if="p.cuenta"> · {{p.cuenta}}</span></td><td class="num">{{money(p.monto, f.moneda)}}</td><td><button class="btn icon" title="Anular pago" v-if="editable && puedeEscribir" @click="anular(p)">✕</button></td></tr></tbody></table>
          <div class="row" style="margin-top:8px;gap:6px;flex-wrap:wrap" v-if="editable && puedeEscribir"><button class="btn sm sec" @click="abrirAdelanto" v-if="!adelanto">+ Adelanto o pago</button>
            <template v-if="depositosDisp.length"><select class="inp" v-model="depositoSel" style="padding:4px 8px" @change="depositoMonto = Math.min(depositoDisponible(depositosDisp.find(x=>x.id===depositoSel) || {monto:0}), Math.max(0, (f.adelanto_requerido || adelantoReq) - totFolio.pagos) || depositoDisponible(depositosDisp.find(x=>x.id===depositoSel) || {monto:0}))"><option :value="null">Aplicar depósito en garantía…</option><option v-for="d in depositosDisp" :key="d.id" :value="d.id">{{d.numero}} · {{d.nombre}} · disponible {{money(depositoDisponible(d), d.moneda)}}</option></select><input type="number" class="inp" min="0" step="0.01" v-model.number="depositoMonto" style="width:120px;padding:4px 8px" v-if="depositoSel"><button class="btn sm" @click="aplicarDep" v-if="depositoSel">Aplicar</button></template></div>
          <div v-if="adelanto && !esNueva" style="margin-top:8px">
            <div class="grid cols-2">
              <Field label="Moneda en que paga" :help="'La reserva está en ' + cot.moneda"><select :value="adelanto.moneda_pago" @change="cambiarMonedaAdelanto($event.target.value)"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field>
              <Field :label="'Monto en ' + adelanto.moneda_pago" req :help="adelantoTexto()"><input type="number" min="0" step="0.01" v-model.number="adelanto.monto_pago"></Field>
              <Field label="Medio"><select v-model="adelanto.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field>
              <Field label="Cuenta de Bancos"><Buscador v-model="adelanto.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
              <Field label="Referencia"><input v-model="adelanto.referencia" maxlength="40"></Field>
            </div>
            <div class="row" style="margin-top:8px;gap:6px"><button class="btn sm" @click="registrarAdelantoAhora" :disabled="guardando">Registrar pago</button><button class="btn sm ghost" @click="adelanto=null">Cancelar</button></div>
          </div>
          <p class="small muted" style="margin:8px 0 0">Los cargos por noche, los consumos y el check-out con factura se manejan en <a :href="'#/hotel/recepcion?reserva=' + id">Recepción</a>.</p>
        </div>
        <div class="card" v-if="!esNueva && historial.length"><h2>Historial</h2><div v-for="(x,i) in historial" :key="i" class="small" style="padding:4px 0;border-bottom:1px solid var(--line)"><span class="muted">{{fechaHora(x.fecha)}} · {{x.usuario}}</span><br>{{x.texto}}</div></div>
      </div>
    </div>
    <div class="row end" style="margin-bottom:18px" v-if="editable && puedeEscribir">
      <button class="btn danger" v-if="!esNueva && ['pendiente','confirmada'].includes(f.estado)" @click="cancelar(f.llegada < hoyHotel())">{{f.llegada < hoyHotel() ? 'No se presentó' : 'Cancelar reserva'}}</button>
      <span style="flex:1"></span>
      <a class="btn ghost" href="#/hotel/reservaciones">Volver</a>
      <button class="btn sec" v-if="esNueva && f.llegada === hoyHotel()" @click="guardar('recepcion')" :disabled="guardando">Guardar y hacer check-in</button>
      <button class="btn" @click="guardar()" :disabled="guardando">{{guardando ? 'Guardando…' : (esNueva ? 'Guardar reserva' : 'Guardar cambios')}}</button>
    </div>
    <Modal v-if="correo" title="Enviar confirmación por correo" @close="correo=null">
      <div class="grid" style="grid-template-columns:1fr"><Field label="Para" req><input type="email" v-model="correo.para"></Field><Field label="Asunto" req><input v-model="correo.asunto" maxlength="120"></Field><Field label="Mensaje" help="Se puede editar antes de enviar; el texto base se cambia en Habitaciones y tarifas › Políticas y mensajes"><textarea rows="12" v-model="correo.texto"></textarea></Field></div>
      <template #foot><button class="btn ghost" @click="copiar">Copiar texto</button><button class="btn ghost" @click="correo=null">Cancelar</button><button class="btn" @click="enviarCorreo" :disabled="guardando">{{guardando ? 'Enviando…' : 'Enviar'}}</button></template>
    </Modal>
    </template>
  </div>`,
  setup() { return { hoy, hoyHotel, estadiasDe }; },   // 3.87: la plantilla llama hoyHotel (Check-in, Cancelar o No se presentó, Guardar y hacer check-in); sin exponerla la ficha quedaba en blanco
};
