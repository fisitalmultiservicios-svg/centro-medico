// Hotel › Mantenimiento › Preventivo programado (3.3): tareas que se repiten cada tantos días por habitación, por área o por
// equipo (aire acondicionado, calentador, piscina, extintores…). Cada plan tiene su frecuencia y su próxima fecha; al ejecutarlo
// queda el historial y se calcula la siguiente. Lo vencido aparece primero. Vive en hotel_preventivo.
import { toast, fecha, fechaHora, hoy, sumarDias, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { hotelActivo, habitaciones, nombreHab, nombreCat, usuarioActual, crearReporte } from './_datos.js';

const PLANES_BASE = [
  { nombre: 'Limpieza de filtros de aire acondicionado', alcance: 'habitacion', cada: 90, equipo: 'Aire acondicionado' },
  { nombre: 'Revisión de calentador de agua', alcance: 'habitacion', cada: 180, equipo: 'Calentador' },
  { nombre: 'Prueba de cerraduras y llaves', alcance: 'habitacion', cada: 180, equipo: 'Cerradura' },
  { nombre: 'Revisión de extintores', alcance: 'area', area: 'Todo el hotel', cada: 30, equipo: 'Extintores' },
  { nombre: 'Limpieza y químicos de la piscina', alcance: 'area', area: 'Piscina', cada: 7, equipo: 'Piscina' },
  { nombre: 'Mantenimiento de planta eléctrica', alcance: 'area', area: 'Cuarto de máquinas', cada: 30, equipo: 'Planta eléctrica' },
  { nombre: 'Fumigación', alcance: 'area', area: 'Todo el hotel', cada: 90, equipo: '' },
];

export default {
  props: ['params'],
  data() { return { lista: mock.get('hotel_preventivo', []) || [], filtro: 'pendientes', form: null, ejec: null, activo: hotelActivo(), hoyS: hoy() }; },
  computed: {
    puedeEscribir() { return sesion.puede('mantenimiento') || sesion.puede('escribir'); },
    habs() { return habitaciones(); },
    planes() {
      return this.lista.map(p => { const prox = p.proxima || this.hoyS, dias = Math.round((new Date(prox + 'T00:00:00') - new Date(this.hoyS + 'T00:00:00')) / 86400000); return { ...p, dias, vencido: dias < 0, pronto: dias >= 0 && dias <= 7, donde: p.alcance === 'habitacion' ? (p.habitacion_id ? 'Hab. ' + nombreHab(p.habitacion_id) : 'Todas las habitaciones') : (p.area || 'Área'), ultima: (p.historial || []).slice(-1)[0] || null }; })
        .filter(p => p.activo !== false || this.filtro === 'todos').filter(p => this.filtro === 'todos' || (this.filtro === 'pendientes' && (p.vencido || p.pronto)) || (this.filtro === 'vencidos' && p.vencido))
        .sort((a, b) => a.dias - b.dias);
    },
    resumen() { const l = this.lista.filter(p => p.activo !== false).map(p => Math.round((new Date((p.proxima || this.hoyS) + 'T00:00:00') - new Date(this.hoyS + 'T00:00:00')) / 86400000)); return { total: l.length, vencidos: l.filter(d => d < 0).length, semana: l.filter(d => d >= 0 && d <= 7).length }; },
  },
  methods: {
    fecha, fechaHora, nombreHab, nombreCat,
    guardar(l) { if (!mock.puedeGuardar()) return false; mock.set('hotel_preventivo', l); this.lista = l; return true; },
    cargarBase() { if (this.lista.length) return; const l = PLANES_BASE.map((p, i) => ({ id: i + 1, ...p, habitacion_id: null, proxima: sumarDias(this.hoyS, Math.min(p.cada, 7 + i * 3)), responsable: '', notas: '', activo: true, historial: [], creado: new Date().toISOString() })); this.guardar(l); toast('Planes básicos cargados: ajuste frecuencias y fechas', 'ok'); },
    nuevo() { this.form = { id: null, nombre: '', alcance: 'habitacion', habitacion_id: null, area: '', equipo: '', cada: 90, proxima: sumarDias(this.hoyS, 30), responsable: '', notas: '', activo: true }; },
    editar(p) { this.form = { ...p }; },
    guardarPlan() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Indique el nombre de la tarea', 'err'); if (!(+f.cada > 0)) return toast('Indique cada cuántos días', 'err'); if (!f.proxima) return toast('Indique la próxima fecha', 'err');
      const reg = { ...f, nombre: f.nombre.trim(), cada: Math.round(+f.cada), historial: f.historial || [] };
      const l = this.lista.slice(); if (reg.id) { const i = l.findIndex(x => x.id === reg.id); l.splice(i, 1, reg); } else { reg.id = l.reduce((m, x) => Math.max(m, x.id), 0) + 1; reg.creado = new Date().toISOString(); l.push(reg); }
      if (this.guardar(l)) { this.form = null; toast('Plan guardado', 'ok'); }
    },
    eliminar(p) { if (!confirm('¿Eliminar el plan «' + p.nombre + '» y su historial?')) return; this.guardar(this.lista.filter(x => x.id !== p.id)); },
    abrirEjecutar(p) { this.ejec = { id: p.id, fecha: this.hoyS, nota: '', hallazgo: false }; },
    confirmarEjecutar() {
      const e = this.ejec, p = this.lista.find(x => x.id === e.id); if (!p) return;
      const l = this.lista.map(x => (x.id !== p.id ? x : { ...x, proxima: sumarDias(e.fecha || this.hoyS, +x.cada || 30), ultima: e.fecha || this.hoyS, historial: [...(x.historial || []), { fecha: e.fecha || this.hoyS, usuario: usuarioActual(), nota: (e.nota || '').trim(), hallazgo: !!e.hallazgo }].slice(-60) }));
      if (!this.guardar(l)) return;
      if (e.hallazgo) crearReporte({ habitacion_id: p.habitacion_id || null, lugar: p.habitacion_id ? '' : (p.area || p.nombre), modulo: 'mantenimiento', tipo: 'Hallazgo en preventivo: ' + p.nombre, descripcion: (e.nota || '').trim(), prioridad: 'normal', reportado_por: usuarioActual() });
      this.ejec = null; toast('Hecho: próxima vez el ' + fecha(sumarDias(e.fecha || this.hoyS, +p.cada || 30)) + (e.hallazgo ? ' · incidencia creada' : ''), 'ok');
    },
    exportar(formato) {
      const cols = [{ key: 'nombre', label: 'Tarea' }, { key: 'donde', label: 'Dónde' }, { key: 'equipo', label: 'Equipo' }, { key: 'cada', label: 'Cada (días)', num: true }, { key: 'ultima', label: 'Última vez', fmt: v => (v ? fecha(v.fecha) : '—') }, { key: 'proxima', label: 'Próxima', fmt: 'date' }, { key: 'dias', label: 'Días', num: true }, { key: 'responsable', label: 'Responsable' }];
      const rows = this.planes;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'hotel_preventivo', cols.map(c => ({ ...c, fmt: c.key === 'ultima' ? undefined : c.fmt })), rows.map(r => ({ ...r, ultima: r.ultima ? r.ultima.fecha : '' })));
      return descargarReporte(formato, { titulo: 'Mantenimiento preventivo', subtitulo: 'Planes programados y su próxima fecha', periodo: 'Al ' + fecha(this.hoyS), cols, rows, kpis: [{ t: 'Planes', v: String(this.resumen.total) }, { t: 'Vencidos', v: String(this.resumen.vencidos) }, { t: 'Esta semana', v: String(this.resumen.semana) }], archivo: 'hotel_preventivo' });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Mantenimiento preventivo" :sub="activo ? resumen.total + ' planes · ' + resumen.vencidos + ' vencido(s) · ' + resumen.semana + ' en los próximos 7 días' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Mantenimiento'},{label:'Preventivo'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" v-if="lista.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" v-if="lista.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" v-if="lista.length">CSV</button>
      <button class="btn" @click="nuevo" :disabled="!puedeEscribir">+ Plan</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🗓" title="El hotel no está configurado"></Empty></div>
    <div class="card" v-else>
      <div class="toolbar"><div class="seg"><button :class="{on: filtro==='pendientes'}" @click="filtro='pendientes'">Vencidos y próximos</button><button :class="{on: filtro==='vencidos'}" @click="filtro='vencidos'">Solo vencidos</button><button :class="{on: filtro==='todos'}" @click="filtro='todos'">Todos los planes</button></div></div>
      <Empty v-if="!lista.length" icon="🗓" title="Sin planes de mantenimiento" text="Cargue los básicos (filtros de aire, calentadores, extintores, piscina, fumigación…) y ajuste cada cuántos días se hacen."><button class="btn" @click="cargarBase" :disabled="!puedeEscribir">Cargar planes básicos</button></Empty>
      <Empty v-else-if="!planes.length" icon="✅" title="Nada vencido ni próximo" text="Cambie el filtro para ver todos los planes."></Empty>
      <table class="tbl" v-else><thead><tr><th>Tarea</th><th>Dónde</th><th>Equipo</th><th class="num">Cada</th><th>Última vez</th><th>Próxima</th><th>Responsable</th><th></th></tr></thead>
        <tbody><tr v-for="p in planes" :key="p.id" :style="p.activo===false ? 'opacity:.55' : p.vencido ? 'background:#fef2f2' : p.pronto ? 'background:#fffbeb' : ''">
          <td><b>{{p.nombre}}</b><div class="small muted" v-if="p.notas">{{p.notas}}</div></td><td>{{p.donde}}</td><td>{{p.equipo}}</td><td class="num">{{p.cada}} días</td><td class="small">{{p.ultima ? fecha(p.ultima.fecha) + ' · ' + p.ultima.usuario : '—'}}</td><td><b>{{fecha(p.proxima)}}</b><span class="badge" :class="p.vencido ? 'danger' : p.pronto ? 'warn' : ''" style="margin-left:6px">{{p.vencido ? 'vencido ' + (-p.dias) + ' d' : p.dias === 0 ? 'hoy' : 'en ' + p.dias + ' d'}}</span></td><td>{{p.responsable}}</td>
          <td style="white-space:nowrap"><button class="btn sm" @click="abrirEjecutar(p)" :disabled="!puedeEscribir || p.activo===false">Hecho</button> <button class="btn sm ghost" @click="editar(p)" :disabled="!puedeEscribir">Editar</button></td></tr></tbody></table>
    </div>
    <Modal v-if="form" :title="form.id ? 'Plan · ' + form.nombre : 'Nuevo plan preventivo'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Tarea" req style="grid-column:1/-1"><input v-model="form.nombre" maxlength="100" placeholder="Limpieza de filtros de aire acondicionado"></Field>
        <Field label="Alcance"><select v-model="form.alcance"><option value="habitacion">Habitación (una o todas)</option><option value="area">Área o equipo común</option></select></Field>
        <Field label="Habitación" v-if="form.alcance==='habitacion'"><select v-model="form.habitacion_id"><option :value="null">Todas las habitaciones</option><option v-for="h in habs" :key="h.id" :value="h.id">{{h.numero}}</option></select></Field>
        <Field label="Área" v-else><input v-model="form.area" maxlength="60" placeholder="Piscina, lobby, cuarto de máquinas…"></Field>
        <Field label="Equipo"><input v-model="form.equipo" maxlength="60"></Field>
        <Field label="Cada cuántos días" req><input type="number" min="1" max="730" v-model.number="form.cada"></Field>
        <Field label="Próxima fecha" req><input type="date" v-model="form.proxima"></Field>
        <Field label="Responsable"><input v-model="form.responsable" maxlength="60"></Field>
        <Field label="Notas o procedimiento" style="grid-column:1/-1"><textarea rows="2" v-model="form.notas" maxlength="400"></textarea></Field>
      </div>
      <div style="margin-top:10px"><Toggle v-model="form.activo" label="Plan activo"></Toggle></div>
      <template #foot><button class="btn danger" v-if="form.id" @click="eliminar(form); form=null">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardarPlan">Guardar</button></template>
    </Modal>
    <Modal v-if="ejec" title="Registrar la ejecución" @close="ejec=null">
      <div class="grid cols-2"><Field label="Fecha en que se hizo"><input type="date" v-model="ejec.fecha" :max="hoyS"></Field><Field label="Nota" style="grid-column:1/-1"><input v-model="ejec.nota" maxlength="300" placeholder="Qué se hizo, repuestos, observaciones…"></Field></div>
      <label class="row" style="gap:8px;margin-top:10px;cursor:pointer"><input type="checkbox" v-model="ejec.hallazgo"> Se encontró un daño: crear una incidencia de mantenimiento con la nota</label>
      <template #foot><button class="btn ghost" @click="ejec=null">Cancelar</button><button class="btn" @click="confirmarEjecutar">Marcar como hecho</button></template>
    </Modal>
  </div>`,
};
