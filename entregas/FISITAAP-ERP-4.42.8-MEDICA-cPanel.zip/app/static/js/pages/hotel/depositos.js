// Hotel › Reservaciones › Depósitos en garantía (3.0): dinero recibido por adelantado (de un huésped, una empresa o un grupo) que
// luego se aplica a una o varias reservas (fragmentar), se devuelve o se traspasa a otra persona. Cada depósito lleva su número
// DG-0001, su saldo disponible y su historial; entra a Bancos al recibirlo y sale al devolverlo.
import { toast, money, fecha, fechaHora, hoy, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { cuentasParaMovimientos, cuentaPrincipal, cuentaParaMedio } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { config, hotelActivo, depositos, depositoDisponible, estadoDeposito, ESTADOS_DEPOSITO, crearDeposito, aplicarDeposito, devolverDeposito, traspasarDeposito, MEDIOS, nombreMedio, MONEDAS_HOTEL, buscarHuespedes, nombreHuesped, reservas, esEstadia, nombreHab, cambiarReserva, anotar, r2 } from './_datos.js';

export default {
  props: ['params'],
  data() { return { cfg: config(), lista: depositos(), q: '', filtro: 'disponibles', form: null, ver: null, devolver: null, traspaso: null, aplicar: null, cuentas: [], qH: '', MEDIOS, MONEDAS_HOTEL, activo: hotelActivo(), guardando: false }; },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    clientes() { return (store.clientes || []).filter(c => c.activo !== false); },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.lista.map(d => ({ ...d, disponible: depositoDisponible(d), estado: estadoDeposito(d), estado_txt: ESTADOS_DEPOSITO[estadoDeposito(d)], usado: r2((d.aplicaciones || []).reduce((s, a) => s + (+a.monto || 0), 0)), medio_txt: nombreMedio(d.medio) }))
        .filter(d => this.filtro === 'todos' || (this.filtro === 'disponibles' && d.disponible > 0.005) || (this.filtro === 'aplicados' && d.estado === 'aplicado') || (this.filtro === 'devueltos' && d.estado === 'devuelto'))
        .filter(d => !q || [d.numero, d.nombre, d.grupo, d.referencia, d.notas].some(x => String(x || '').toLowerCase().includes(q)))
        .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || b.id - a.id);
    },
    columns() { return [{ key: 'numero', label: 'Depósito', mono: true, link: d => this.abrir(d) }, { key: 'fecha', label: 'Recibido', fmt: 'date' }, { key: 'nombre', label: 'De quién' }, { key: 'grupo', label: 'Grupo' }, { key: 'medio_txt', label: 'Medio' }, { key: 'monto', label: 'Monto', num: true, fmt: (v, d) => money(v, d.moneda) }, { key: 'usado', label: 'Aplicado', num: true, fmt: (v, d) => money(v, d.moneda) }, { key: 'disponible', label: 'Disponible', num: true, fmt: (v, d) => money(v, d.moneda) }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' }]; },
    totales() { const disp = this.filas.reduce((s, d) => s + (d.moneda === this.cfg.moneda ? d.disponible : 0), 0); return { n: this.filas.length, disponible: r2(disp) }; },
    sugerencias() { return this.form && this.form.modoH === 'buscar' ? buscarHuespedes(this.qH) : []; },
    reservasAplicar() {
      const d = this.aplicar && this.lista.find(x => x.id === this.aplicar.id); if (!d) return [];
      const vig = reservas().filter(r => esEstadia(r) && ['pendiente', 'confirmada', 'en_casa'].includes(r.estado));
      const propias = vig.filter(r => (d.huesped_id && r.huesped_id === d.huesped_id) || (d.cliente_id && r.cliente_id === d.cliente_id) || (d.grupo && r.grupo === d.grupo));
      return (propias.length ? propias : vig).map(r => ({ ...r, etiqueta: r.numero + ' · ' + r.huesped_nombre + (r.habitacion_id ? ' · hab. ' + nombreHab(r.habitacion_id) : '') + ' · ' + fecha(r.llegada), propia: propias.includes(r) }));
    },
  },
  methods: {
    money, fecha, fechaHora, nombreMedio, depositoDisponible,
    refrescar() { this.lista = depositos(); if (this.ver) this.ver = this.lista.find(x => x.id === this.ver.id) || null; },
    abrir(d) { this.ver = this.lista.find(x => x.id === d.id) || d; },
    nuevo() { const b = cuentaParaMedio('04', this.cfg.moneda, this.cuentas) || cuentaParaMedio('04', 'CRC', this.cuentas); this.form = { nombre: '', huesped_id: null, cliente_id: null, grupo: '', monto: null, moneda: this.cfg.moneda || 'USD', medio: '04', cuenta: b ? b.nombre : '', referencia: '', fecha: hoy(), notas: '', modoH: 'buscar' }; this.qH = ''; },
    elegirH(h) { this.form.huesped_id = h.id; this.form.nombre = this.form.nombre || nombreHuesped(h); this.form.modoH = 'elegido'; this.form.huesped_nombre = nombreHuesped(h); this.qH = ''; },
    elegirCliente() { const c = this.clientes.find(x => x.id === this.form.cliente_id); if (c && !this.form.nombre) this.form.nombre = c.nombre; },
    cambiarMoneda() { const b = cuentaParaMedio(this.form.medio, this.form.moneda, this.cuentas); if (b) this.form.cuenta = b.nombre; },   // 4.5: según el medio
    async guardar() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Indique de quién es el depósito', 'err'); if (!(+f.monto > 0)) return toast('Indique el monto', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const { modoH, huesped_nombre, ...datos } = f;
      const d = await crearDeposito({ ...datos, nombre: f.nombre.trim(), grupo: (f.grupo || '').trim(), notas: (f.notas || '').trim() });
      this.guardando = false; this.form = null; this.refrescar(); toast('Depósito ' + d.numero + ' registrado' + (d.cuenta ? ' y en Bancos' : ''), 'ok');
    },
    abrirAplicar(d) { const l = this.reservasAplicarDe(d); this.aplicar = { id: d.id, reserva_id: l[0] ? l[0].id : null, monto: depositoDisponible(d) }; },
    reservasAplicarDe(d) { const vig = reservas().filter(r => esEstadia(r) && ['pendiente', 'confirmada', 'en_casa'].includes(r.estado)); const propias = vig.filter(r => (d.huesped_id && r.huesped_id === d.huesped_id) || (d.cliente_id && r.cliente_id === d.cliente_id) || (d.grupo && r.grupo === d.grupo)); return propias.length ? propias : vig; },
    confirmarAplicar() {
      const d = this.lista.find(x => x.id === this.aplicar.id), r = reservas().find(x => x.id === this.aplicar.reserva_id); if (!d || !r) return toast('Elija la reserva', 'err');
      const m = +this.aplicar.monto || 0; if (!(m > 0) || m > depositoDisponible(d) + 0.005) return toast('El monto debe ser mayor que cero y no superar lo disponible', 'err');
      if (!mock.puedeGuardar()) return;
      const item = aplicarDeposito(d, r, m); if (!item) return;
      if (r.estado === 'pendiente') cambiarReserva(r.id, x => anotar({ ...x, estado: 'confirmada' }, 'Confirmada con depósito en garantía ' + d.numero)); else cambiarReserva(r.id, x => anotar(x, 'Depósito en garantía ' + d.numero + ' aplicado: ' + money(item.monto, r.moneda)));
      this.aplicar = null; this.refrescar(); toast(money(m, d.moneda) + ' del depósito ' + d.numero + ' aplicado a ' + r.numero, 'ok');
    },
    abrirDevolver(d) { const b = cuentaParaMedio(d.medio || '04', d.moneda, this.cuentas); this.devolver = { id: d.id, monto: depositoDisponible(d), medio: d.medio || '04', cuenta: d.cuenta || (b ? b.nombre : ''), referencia: '', motivo: '', fecha: hoy() }; },
    async confirmarDevolver() {
      const d = this.lista.find(x => x.id === this.devolver.id); if (!d) return; const m = +this.devolver.monto || 0; if (!(m > 0) || m > depositoDisponible(d) + 0.005) return toast('Revise el monto', 'err');
      if (!mock.puedeGuardar()) return;
      await devolverDeposito(d, this.devolver); this.devolver = null; this.refrescar(); toast('Devolución de ' + money(m, d.moneda) + ' registrada', 'ok');
    },
    abrirTraspaso(d) { this.traspaso = { id: d.id, monto: depositoDisponible(d), nombre: '', huesped_id: null, cliente_id: null, grupo: '', modoH: 'buscar' }; this.qH = ''; },
    elegirHT(h) { this.traspaso.huesped_id = h.id; this.traspaso.nombre = this.traspaso.nombre || nombreHuesped(h); this.traspaso.modoH = 'elegido'; this.qH = ''; },
    confirmarTraspaso() {
      const d = this.lista.find(x => x.id === this.traspaso.id); if (!d) return; const t = this.traspaso; if (!(t.nombre || '').trim()) return toast('Indique a quién se traspasa', 'err'); const m = +t.monto || 0; if (!(m > 0) || m > depositoDisponible(d) + 0.005) return toast('Revise el monto', 'err');
      if (!mock.puedeGuardar()) return;
      const n = traspasarDeposito(d, { nombre: t.nombre.trim(), huesped_id: t.huesped_id, cliente_id: t.cliente_id, grupo: (t.grupo || '').trim(), notas: 'Traspaso de ' + d.numero }, m);
      this.traspaso = null; this.refrescar(); toast('Traspasado a ' + n.numero + ' (' + n.nombre + ')', 'ok');
    },
    exportar(formato) {
      const cols = this.columns.filter(c => c.key !== 'estado_txt').concat([{ key: 'estado_txt', label: 'Estado' }]), rows = this.filas;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'hotel_depositos', cols, rows);
      return descargarReporte(formato, { titulo: 'Depósitos en garantía · ' + (this.cfg.nombre || 'Hotel'), subtitulo: 'Recibidos, aplicados y devueltos', periodo: 'Al ' + fecha(hoy()), cols, rows, kpis: [{ t: 'Depósitos', v: String(rows.length) }, { t: 'Disponible', v: money(this.totales.disponible, this.cfg.moneda) }], archivo: 'hotel_depositos' });
    },
  },
  watch: { 'form.medio'(m) { if (this.form) { const b = cuentaParaMedio(m, this.form.moneda, this.cuentas); if (b) this.form.cuenta = b.nombre; } } },   // 4.5: el medio decide la cuenta (efectivo → Efectivo; tarjeta, SINPE o transferencia → Banco)
  async created() { try { this.cuentas = await cuentasParaMovimientos(); } catch {} },
  template: `
  <div class="page">
    <PageHead title="Depósitos en garantía" sub="Dinero recibido por adelantado que se aplica a una o varias reservas, se devuelve o se traspasa. Entra a Bancos al recibirlo." :crumbs="[{label:'Hotel'},{label:'Reservaciones',to:'/hotel/reservaciones'},{label:'Depósitos en garantía'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!filas.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!filas.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!filas.length">CSV</button>
      <button class="btn" @click="nuevo" v-if="puedeEscribir">+ Depósito</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="💰" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="kpis"><div class="kpi"><div class="t">Depósitos en la vista</div><div class="v">{{totales.n}}</div></div><div class="kpi"><div class="t">Disponible por aplicar ({{cfg.moneda}})</div><div class="v">{{money(totales.disponible, cfg.moneda)}}</div><div class="d">solo los depósitos en la moneda del hotel</div></div></div>
    <div class="card">
      <div class="toolbar"><input class="search" placeholder="Buscar por número, nombre, grupo o referencia" v-model="q">
        <div class="seg"><button :class="{on: filtro==='disponibles'}" @click="filtro='disponibles'">Con saldo</button><button :class="{on: filtro==='aplicados'}" @click="filtro='aplicados'">Aplicados</button><button :class="{on: filtro==='devueltos'}" @click="filtro='devueltos'">Devueltos</button><button :class="{on: filtro==='todos'}" @click="filtro='todos'">Todos</button></div></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin depósitos" empty-text="Registre el primero con «+ Depósito». También puede aplicarlos desde la reserva o desde Recepción." @row-click="abrir">
        <template #actions="{row}">
          <button class="btn sm ghost" v-if="row.disponible > 0.005 && puedeEscribir" @click.stop="abrirAplicar(row)">Aplicar</button>
          <button class="btn sm ghost" v-if="row.disponible > 0.005 && puedeEscribir" @click.stop="abrirDevolver(row)">Devolver</button>
          <button class="btn sm ghost" v-if="row.disponible > 0.005 && puedeEscribir" @click.stop="abrirTraspaso(row)">Traspasar</button>
        </template>
      </DataTable>
    </div>
    </template>

    <Modal v-if="form" title="Nuevo depósito en garantía" @close="form=null">
      <div class="grid cols-2">
        <Field label="De quién" req help="Nombre de la persona, empresa o agencia" style="grid-column:1/-1"><input v-model="form.nombre" maxlength="80"></Field>
        <Field label="Huésped (opcional)" help="Para que aparezca en sus reservas"><template v-if="form.modoH==='buscar'"><input v-model="qH" placeholder="Buscar por nombre o documento"><div v-if="sugerencias.length" class="card" style="padding:4px;margin-top:4px"><div v-for="h in sugerencias" :key="h.id" class="row" style="padding:5px 8px;cursor:pointer" @click="elegirH(h)">{{nombreHuesped(h)}}<span class="muted small" style="margin-left:6px">{{h.documento}}</span></div></div></template><div v-else class="row" style="gap:6px"><span class="badge info">{{form.huesped_nombre}}</span><button class="btn icon" @click="form.huesped_id=null; form.modoH='buscar'">✕</button></div></Field>
        <Field label="Contacto (opcional)" help="Empresa o agencia de Contactos"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Ninguno" agregar="cliente" @change="elegirCliente"></Buscador></Field>
        <Field label="Grupo (opcional)" help="Mismo nombre que en las reservas del grupo"><input v-model="form.grupo" maxlength="60"></Field>
        <Field label="Fecha"><input type="date" v-model="form.fecha"></Field>
        <Field label="Moneda"><select v-model="form.moneda" @change="cambiarMoneda"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field>
        <Field label="Monto" req><input type="number" min="0" step="0.01" v-model.number="form.monto"></Field>
        <Field label="Medio"><select v-model="form.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field>
        <Field label="Cuenta de Bancos donde entra"><Buscador v-model="form.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
        <Field label="Referencia"><input v-model="form.referencia" maxlength="40" placeholder="SINPE, transferencia, voucher…"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="160"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Registrar depósito</button></template>
    </Modal>
    <Modal v-if="ver" :title="'Depósito ' + ver.numero + ' · ' + ver.nombre" @close="ver=null">
      <div class="totals" style="align-items:stretch;margin:0 0 10px"><div><span>Recibido el {{fecha(ver.fecha)}} · {{nombreMedio(ver.medio)}}{{ver.cuenta ? ' · ' + ver.cuenta : ''}}</span><b>{{money(ver.monto, ver.moneda)}}</b></div><div><span>Aplicado a reservas</span><b>−{{money((ver.aplicaciones||[]).reduce((s,a)=>s+(+a.monto||0),0), ver.moneda)}}</b></div><div><span>Devuelto o traspasado</span><b>−{{money((ver.devoluciones||[]).reduce((s,a)=>s+(+a.monto||0),0), ver.moneda)}}</b></div><div class="total"><span>Disponible</span><b>{{money(depositoDisponible(ver), ver.moneda)}}</b></div></div>
      <p class="small muted" v-if="ver.grupo || ver.referencia || ver.notas" style="margin:0 0 8px">{{[ver.grupo ? 'Grupo ' + ver.grupo : '', ver.referencia ? 'Ref. ' + ver.referencia : '', ver.notas].filter(Boolean).join(' · ')}}</p>
      <table class="tbl" v-if="(ver.aplicaciones||[]).length"><thead><tr><th>Aplicado a</th><th>Fecha</th><th class="num">Monto</th></tr></thead><tbody><tr v-for="(a,i) in ver.aplicaciones" :key="i"><td><a class="link" :href="'#/hotel/recepcion?reserva=' + a.reserva_id">{{a.numero}}</a></td><td>{{fecha(a.fecha)}}</td><td class="num">{{money(a.monto, ver.moneda)}}</td></tr></tbody></table>
      <h3 class="small muted" style="margin:10px 0 4px">Historial</h3>
      <div v-for="(h,i) in (ver.historial||[]).slice().reverse()" :key="i" class="small" style="padding:3px 0;border-top:1px solid var(--line)"><span class="muted">{{fechaHora(h.fecha)}} · {{h.usuario}}</span> · {{h.texto}}</div>
      <template #foot><button class="btn ghost" @click="ver=null">Cerrar</button><button class="btn sec" v-if="depositoDisponible(ver) > 0.005 && puedeEscribir" @click="abrirAplicar(ver); ver=null">Aplicar a una reserva</button></template>
    </Modal>
    <Modal v-if="aplicar" title="Aplicar depósito a una reserva" @close="aplicar=null">
      <div class="grid cols-2">
        <Field label="Reserva" req help="Primero las del mismo huésped, contacto o grupo" style="grid-column:1/-1"><select v-model="aplicar.reserva_id"><option :value="null">— Elegir —</option><option v-for="r in reservasAplicar" :key="r.id" :value="r.id">{{r.etiqueta}}{{r.propia ? '' : ' (otro huésped)'}}</option></select></Field>
        <Field label="Monto a aplicar" req><input type="number" min="0" step="0.01" v-model.number="aplicar.monto"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Queda como pago en la cuenta de la reserva. Lo que no se aplique sigue disponible para otra reserva (fragmentar), devolver o traspasar.</p>
      <template #foot><button class="btn ghost" @click="aplicar=null">Cancelar</button><button class="btn" @click="confirmarAplicar">Aplicar</button></template>
    </Modal>
    <Modal v-if="devolver" title="Devolver depósito" @close="devolver=null">
      <div class="grid cols-2">
        <Field label="Monto a devolver" req><input type="number" min="0" step="0.01" v-model.number="devolver.monto"></Field>
        <Field label="Fecha"><input type="date" v-model="devolver.fecha"></Field>
        <Field label="Medio"><select v-model="devolver.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field>
        <Field label="Cuenta de Bancos de donde sale"><Buscador v-model="devolver.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
        <Field label="Referencia"><input v-model="devolver.referencia" maxlength="40"></Field>
        <Field label="Motivo"><input v-model="devolver.motivo" maxlength="80" placeholder="Cancelación, sobrante…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="devolver=null">Cancelar</button><button class="btn danger" @click="confirmarDevolver">Registrar devolución</button></template>
    </Modal>
    <Modal v-if="traspaso" title="Traspasar depósito a otra persona" @close="traspaso=null">
      <div class="grid cols-2">
        <Field label="A quién" req style="grid-column:1/-1"><input v-model="traspaso.nombre" maxlength="80"></Field>
        <Field label="Huésped (opcional)"><template v-if="traspaso.modoH==='buscar'"><input v-model="qH" placeholder="Buscar huésped"><div v-if="buscarH(qH).length" class="card" style="padding:4px;margin-top:4px"><div v-for="h in buscarH(qH)" :key="h.id" class="row" style="padding:5px 8px;cursor:pointer" @click="elegirHT(h)">{{nombreHuesped(h)}}</div></div></template><span v-else class="badge info">elegido</span></Field>
        <Field label="Grupo (opcional)"><input v-model="traspaso.grupo" maxlength="60"></Field>
        <Field label="Monto a traspasar" req><input type="number" min="0" step="0.01" v-model.number="traspaso.monto"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Se crea un depósito nuevo a nombre de la otra persona con ese monto; el dinero no se mueve en Bancos.</p>
      <template #foot><button class="btn ghost" @click="traspaso=null">Cancelar</button><button class="btn" @click="confirmarTraspaso">Traspasar</button></template>
    </Modal>
  </div>`,
  setup() { return { nombreHuesped, buscarH: q => buscarHuespedes(q) }; },
};
