// Hotel › Calendario de habitaciones: pantalla a todo lo ancho con 1, 7, 15, 30 o 60 días, agrupado por piso o categoría (con las
// libres y la tarifa promedio de cada tipo), filtro por categoría, encabezado y columna de habitación fijos, ocupación por día y,
// debajo, las reservas del período que todavía no tienen habitación, para preasignarlas.
import { hoy, sumarDias, fecha, mock, toast, money } from '../../api.js';
import { sesion } from '../../app.js';
import Tape, { Leyenda } from './_tape.js';
import { QuitarBloqueo } from './_bloqueo.js';
import { exportarTabla } from '../reportes/_montos.js';
import { habitaciones, reservas, categorias, nombreHab, nombreCat, nombreEstadoHab, domingoAnterior, fechasEntre, hotelActivo, ocupacionDia, hoyHotel, reservasSinHabitacion, pagosPorReserva, disponibles, cambiarReserva, anotar, ordenHab } from './_datos.js';

const VISTAS = [1, 7, 15, 30, 60];

export default {
  props: ['params'],
  components: { Tape, Leyenda, QuitarBloqueo },
  data() {
    // H4: la vista guardada de 14 días pasa a 15; con un solo día el calendario abre en la fecha del hotel y no en el domingo anterior
    const guardado = +(localStorage.getItem('hotel:cal:dias') || 30), dias_n = guardado === 14 ? 15 : (VISTAS.includes(guardado) ? guardado : 30);
    return { lista: reservas(), dias_n, inicio: this.params.desde || (dias_n === 1 ? hoyHotel() : domingoAnterior(hoyHotel())), agrupar: localStorage.getItem('hotel:cal:agrupar') || 'piso', cat: null, activo: hotelActivo(), zoom: localStorage.getItem('hotel:cal:zoom') === '1',
      pre: null, guardando: false, quitar: null };   // H15: reserva que se está preasignando; H6: bloqueo que se está quitando
  },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    cats() { return categorias(); },
    habs() { return habitaciones().filter(h => !this.cat || h.categoria_id === this.cat); },
    dias() { return fechasEntre(this.inicio, this.dias_n); },
    ocupacionPeriodo() { const hs = this.habs; let oc = 0, tot = 0; for (const d of this.dias) { const o = ocupacionDia(d, this.lista, hs); oc += o.ocupadas; tot += o.total; } return tot ? Math.round(oc / tot * 100) : 0; },
    fin() { return sumarDias(this.inicio, this.dias_n - 1); },
    // con el filtro de categoría, las reservas sin habitación de otras categorías no cuentan en el pie ni en la tarjeta de abajo
    listaVista() { return this.cat ? this.lista.filter(r => r.habitacion_id || r.categoria_id === this.cat) : this.lista; },
    // H15: reservas vigentes del período que no tienen habitación, con lo que ya pagaron
    pagos() { void this.lista; return pagosPorReserva(); },
    sinHab() { return reservasSinHabitacion(this.inicio, this.fin, this.listaVista).map(r => ({ ...r, cat: nombreCat(r.categoria_id), deposito: this.pagos[r.id] || 0 })); },
    colsSinHab() {
      return [{ key: 'numero', label: 'Reserva', mono: true, link: r => this.abrir(r) }, { key: 'huesped_nombre', label: 'Huésped', fmt: v => v || '—' }, { key: 'cat', label: 'Categoría' },
        { key: 'llegada', label: 'Llegada', fmt: 'date' }, { key: 'salida', label: 'Salida', fmt: 'date' }, { key: 'deposito', label: 'Depósito', num: true, fmt: (v, r) => money(v || 0, r.moneda) }];
    },
    // habitaciones libres en las noches de la reserva que se preasigna: primero las de su categoría
    habsPre() {
      const r = this.pre && this.pre.r; if (!r) return { propias: [], otras: [] };
      const libres = disponibles(null, r.llegada, r.salida, r.id, this.lista).slice().sort(ordenHab);
      return { propias: libres.filter(h => h.categoria_id === r.categoria_id), otras: libres.filter(h => h.categoria_id !== r.categoria_id) };
    },
  },
  watch: {
    // al pasar a un solo día desde un período que incluye hoy, se muestra hoy
    dias_n(v, antes) { localStorage.setItem('hotel:cal:dias', String(v)); if (v === 1) { const h = hoyHotel(); if (this.inicio <= h && h <= sumarDias(this.inicio, antes - 1)) this.inicio = h; } },
    agrupar(v) { localStorage.setItem('hotel:cal:agrupar', v); }, zoom(v) { localStorage.setItem('hotel:cal:zoom', v ? '1' : '0'); },
  },
  methods: {
    fecha, nombreCat, nombreEstadoHab,
    mover(n) { this.inicio = sumarDias(this.inicio, n); },
    abrir(r) { if (r.tipo === 'bloqueo') { this.quitar = r; return; } location.hash = '/hotel/reservaciones/' + r.id; },   // H6: el bloqueo se quita solo o con todo su lote
    bloqueoQuitado() { this.lista = reservas(); this.quitar = null; },
    nuevaEn(x) { location.hash = '/hotel/reservaciones/nueva?habitacion=' + x.habitacion.id + '&fecha=' + x.fecha; },
    exportarSinHab() { exportarTabla('hotel_sin_habitacion', this.colsSinHab, this.sinHab, { titulo: 'Reservas sin habitación', periodo: fecha(this.inicio) + ' al ' + fecha(this.fin) }); },
    abrirPreasignar(r) { this.pre = { r, habitacion_id: null }; },
    // H15: la habitación queda apartada para la reserva; si otra recepción la tomó esas noches, el servidor responde 409 y no cambia nada
    async guardarPreasignar() {
      const p = this.pre; if (!p || !p.habitacion_id) return toast('Elija la habitación', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const { promesa } = cambiarReserva(p.r.id, x => anotar({ ...x, habitacion_id: p.habitacion_id, preasignada: true }, 'Preasignada a la hab. ' + nombreHab(p.habitacion_id)));
      const ok = await promesa;
      this.guardando = false; this.lista = reservas();
      if (ok) { toast('Reserva ' + p.r.numero + ' preasignada a la habitación ' + nombreHab(p.habitacion_id), 'ok'); this.pre = null; }
    },
  },
  template: `
  <div class="page ancha">
    <PageHead title="Calendario de habitaciones" :sub="activo ? 'Del ' + fecha(inicio) + ' al ' + fecha(fin) + ' · ocupación del período ' + ocupacionPeriodo + ' % · toque una celda libre para reservar o una barra para abrir la reserva' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Calendario'}]">
      <div class="seg"><button v-for="n in [1,7,15,30,60]" :key="n" :class="{on: dias_n===n}" @click="dias_n=n">{{n === 1 ? '1 día' : n + ' días'}}</button></div>
      <div class="row" style="gap:2px;flex-wrap:wrap"><button class="btn sm ghost" @click="mover(-30)" title="Retroceder 30 días">◀ 30</button><button class="btn sm ghost" @click="mover(-15)" title="Retroceder 15 días">◀ 15</button><button class="btn sm ghost" @click="mover(-7)" title="Retroceder 7 días">◀ 7</button><button class="btn sm ghost" @click="mover(-1)" title="Retroceder 1 día">◀ 1</button>
        <button class="btn sm sec" @click="inicio = dias_n === 1 ? hoyHotel() : domingoAnterior(hoyHotel())">Hoy</button>
        <button class="btn sm ghost" @click="mover(1)" title="Avanzar 1 día">1 ▶</button><button class="btn sm ghost" @click="mover(7)" title="Avanzar 7 días">7 ▶</button><button class="btn sm ghost" @click="mover(15)" title="Avanzar 15 días">15 ▶</button><button class="btn sm ghost" @click="mover(30)" title="Avanzar 30 días">30 ▶</button></div>
      <input type="date" class="inp" v-model="inicio" style="padding:5px 8px">
      <select class="inp" v-model="agrupar" style="padding:5px 8px"><option value="piso">Por piso</option><option value="categoria">Por categoría</option><option value="ninguno">Sin agrupar</option></select>
      <select class="inp" v-model="cat" style="padding:5px 8px"><option :value="null">Todas las categorías</option><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select>
      <label class="row small" style="gap:6px;cursor:pointer" title="Celdas más angostas para ver más días sin desplazarse; el precio del día sale al pasar el mouse por una celda libre"><input type="checkbox" v-model="zoom"> Compacto</label>
      <a class="btn" href="#/hotel/reservaciones/nueva" v-if="puedeEscribir">+ Nueva reserva</a>
    </PageHead>
    <div class="card" v-if="!activo || !habs.length"><Empty icon="📅" title="Sin habitaciones que mostrar" text="Configure el hotel o cambie el filtro de categoría."><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <template v-else>
    <div class="card" style="padding:12px 14px">
      <Leyenda></Leyenda>
      <Tape :dias="dias" :habitaciones="habs" :reservas="listaVista" :agrupar="agrupar" :zoom="zoom" :resumen-tipo="agrupar==='categoria'" :solo-lectura="!puedeEscribir" @abrir="abrir" @nueva="nuevaEn"></Tape>
    </div>
    <div class="card" v-if="sinHab.length">
      <div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:8px">
        <h2 style="margin:0">Reservas sin habitación <small>{{sinHab.length}} en el período · ya restan disponibilidad en su categoría</small></h2>
        <button class="btn sm ghost" @click="exportarSinHab">Exportar</button></div>
      <DataTable :rows="sinHab" :columns="colsSinHab" :page-size="10" empty-title="Sin reservas por asignar" @row-click="abrir">
        <template #actions="{row}"><button class="btn sm" v-if="puedeEscribir" @click.stop="abrirPreasignar(row)" title="Apartar una habitación libre para esta reserva">Preasignar</button></template>
      </DataTable>
    </div>
    </template>
    <Modal v-if="pre" :title="'Preasignar habitación · ' + pre.r.numero" @close="pre=null">
      <p class="small muted" style="margin:0 0 10px">{{pre.r.huesped_nombre || 'Sin nombre'}} · {{nombreCat(pre.r.categoria_id)}} · del {{fecha(pre.r.llegada)}} al {{fecha(pre.r.salida)}}. La habitación queda apartada para esta reserva (borde punteado en el calendario) hasta el check-in; el precio de la reserva no cambia.</p>
      <Field label="Habitación" req help="Solo las libres en esas noches"><select v-model="pre.habitacion_id"><option :value="null">— Elegir —</option>
        <optgroup :label="'De su categoría: ' + nombreCat(pre.r.categoria_id)" v-if="habsPre.propias.length"><option v-for="h in habsPre.propias" :key="h.id" :value="h.id">{{h.numero}}{{h.estado && h.estado !== 'limpia' ? ' · ' + nombreEstadoHab(h.estado) : ''}}</option></optgroup>
        <optgroup label="De otra categoría" v-if="habsPre.otras.length"><option v-for="h in habsPre.otras" :key="h.id" :value="h.id">{{h.numero}} · {{nombreCat(h.categoria_id)}}{{h.estado && h.estado !== 'limpia' ? ' · ' + nombreEstadoHab(h.estado) : ''}}</option></optgroup></select></Field>
      <p class="small muted" v-if="!habsPre.propias.length && !habsPre.otras.length" style="margin:8px 0 0">No hay habitaciones libres para esas noches.</p>
      <template #foot><button class="btn ghost" @click="pre=null">Cancelar</button><button class="btn" :disabled="!pre.habitacion_id || guardando" @click="guardarPreasignar">Preasignar</button></template>
    </Modal>
    <QuitarBloqueo v-if="quitar" :bloqueo="quitar" :lista="lista" :puede="puedeEscribir" @listo="bloqueoQuitado" @cerrar="quitar=null"></QuitarBloqueo>
  </div>`,
  setup() { return { hoy, hoyHotel, domingoAnterior }; },
};
