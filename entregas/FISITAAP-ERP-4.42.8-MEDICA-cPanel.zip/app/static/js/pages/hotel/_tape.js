// Calendario de habitaciones (tape chart): una fila por habitación, una columna por noche; cada reserva o bloqueo es una barra
// que ocupa sus noches. Lo usan Reservaciones (semana de domingo a domingo con desplazamiento) y la pantalla Calendario (completo).
import { hoy } from '../../api.js';
import { etiquetaDia, claseEstado, pisoDe, nombreCat, categorias, insignia, numeroVisita, origenCorto, precioNoche, config, hoyHotel, disponibilidadPorTipo, marcasReserva, pagosPorReserva, noches, nombrePlan } from './_datos.js';
import { money } from '../../api.js';

// Leyenda del calendario (H15): pinta con las mismas clases de las barras (ui.css), para que no vuelva a quedar con otros colores
export const Leyenda = {
  template: `<div class="leyenda"><span><i class="res llega"></i>Llega hoy</span><span><i class="res casa"></i>En casa</span><span><i class="res sale"></i>Sale hoy</span><span><i class="res conf"></i>Confirmada</span><span><i class="res pend"></i>Pendiente de adelanto</span><span><i class="res pasada"></i>Salió</span><span><i class="res bloq"></i>Bloqueo</span><span><i class="res conf dep"></i>$ Con depósito o adelanto</span><span><i class="res conf pre"></i>Habitación preasignada</span><span>«mant.» junto al número: fuera de servicio</span></div>`,
};

export default {
  props: { dias: Array, habitaciones: Array, reservas: Array, agrupar: { type: String, default: 'piso' }, compacto: Boolean, soloLectura: Boolean, zoom: Boolean, resumenTipo: Boolean },
  emits: ['abrir', 'nueva'],
  computed: {
    hoyS() { return hoyHotel(); },
    cfg() { return config(); },
    moneda() { return this.cfg.moneda || 'USD'; },
    cabeceras() { return (this.dias || []).map(d => ({ iso: d, ...etiquetaDia(d), hoy: d === this.hoyS })); },
    grupos() {
      const habs = this.habitaciones || [];
      if (this.agrupar === 'ninguno') return [{ nombre: '', habs }];
      const porCat = this.agrupar === 'categoria', m = new Map(), catDe = new Map();
      for (const h of habs) { const k = porCat ? nombreCat(h.categoria_id) : 'Piso ' + pisoDe(h); if (!m.has(k)) m.set(k, []); m.get(k).push(h); if (porCat && !catDe.has(k)) catDe.set(k, h.categoria_id || null); }
      const orden = porCat ? categorias().map(c => c.nombre) : [...m.keys()].sort((a, b) => a.localeCompare(b, 'es', { numeric: true }));
      return [...orden.filter(k => m.has(k)), ...[...m.keys()].filter(k => !orden.includes(k))].map(k => ({ nombre: k, habs: m.get(k), catId: catDe.get(k) || null }));   // catId: la fila de resumen del tipo (H4)
    },
    // por habitación: lista de celdas {iso, reserva|null, inicio:bool, span}
    filas() {
      const dias = this.dias || [], n = dias.length, out = {};
      if (!n) return out;
      const primero = dias[0], ultimo = dias[n - 1];
      for (const h of this.habitaciones || []) {
        const rs = (this.reservas || []).filter(r => r.habitacion_id === h.id && (r.tipo === 'bloqueo' || !['cancelada', 'no_show'].includes(r.estado)) && r.llegada <= ultimo && r.salida > primero);
        const celdas = dias.map(d => ({ iso: d, r: null, inicio: false, span: 0 }));
        for (const r of rs) {
          const i0 = Math.max(0, dias.indexOf(r.llegada) >= 0 ? dias.indexOf(r.llegada) : 0), iFin = dias.indexOf(r.salida) >= 0 ? dias.indexOf(r.salida) : n;
          const span = Math.max(1, iFin - i0);
          if (celdas[i0].r) continue;              // dos ocupantes en la misma noche (no debería pasar): se dibuja el primero
          celdas[i0].r = r; celdas[i0].inicio = true; celdas[i0].span = span;
          for (let i = i0 + 1; i < i0 + span && i < n; i++) if (!celdas[i].r) celdas[i].r = r;
        }
        out[h.id] = celdas;
      }
      return out;
    },
    // H4: disponibilidad de cada día con la cuenta única del hotel (la del pronóstico): las reservas sin habitación restan libres y, hoy,
    // también las habitaciones en mantenimiento. La usan el pie «Ocupación» y la fila de resumen de cada categoría.
    porDia() { const cfg = this.cfg; return (this.dias || []).map(d => disponibilidadPorTipo(d, this.reservas, { habs: this.habitaciones, cfg })); },
    // H15: lo pagado por reserva, una sola vez (se vuelve a armar cuando cambia la lista de reservas)
    pagos() { void this.reservas; return pagosPorReserva(); },
  },
  methods: {
    // precio por noche de la categoría de la habitación ese día, con su temporada (3.21): sale al pasar el mouse por una celda libre
    precioDia(h, iso) { const c = config(), p = precioNoche(h.categoria_id, iso, c); return (p.precio ? money(p.precio, c.moneda || 'USD') : 'sin tarifa') + (p.temporada ? ' · ' + p.temporada.nombre : ''); },
    claseEstado,
    // H15: marcas de la barra además del color del estado: dep (con depósito o adelanto) y pre (habitación preasignada)
    marcas(r) { const m = marcasReserva(r, this.pagos, this.hoyS); return { dep: m.dep, pre: m.pre }; },
    texto(r) {
      if (r.tipo === 'bloqueo') return '⛔ ' + (r.motivo || 'Bloqueo');
      const v = numeroVisita(r, this.reservas), b = insignia(v);
      let t = (this.marcas(r).dep ? '$ ' : '') + (r.vip ? '★ ' : '') + (r.huesped_nombre || 'Sin nombre') + (b ? ' ' + b : '');
      // H4: en la vista de un día la celda es ancha y caben las noches y el plan
      if ((this.dias || []).length === 1) { const n = noches(r.llegada, r.salida), plan = r.plan_id ? nombrePlan(r.plan_id, this.cfg) : '—'; t += ' · ' + n + (n === 1 ? ' noche' : ' noches') + (plan !== '—' ? ' · ' + plan : ''); }
      return t;
    },
    titulo(r) { if (r.tipo === 'bloqueo') return 'Bloqueo: ' + (r.motivo || '') + ' · ' + r.llegada + ' al ' + r.salida; const m = this.marcas(r); return (r.numero || '') + ' · ' + (r.huesped_nombre || '') + ' · ' + r.llegada + ' al ' + r.salida + ' · ' + (r.estado || '') + (m.dep ? ' · con depósito o adelanto' : '') + (m.pre ? ' · habitación preasignada' : ''); },
    clic(h, c) { if (this.soloLectura) return; if (c.r) this.$emit('abrir', c.r); else if (c.iso >= this.hoyS) this.$emit('nueva', { habitacion: h, fecha: c.iso }); },
    // H4: fila de resumen de la categoría: libres de ese tipo cada día y tarifa promedio vendida de la noche («—» si no hay ventas)
    tipo(g, i) { const d = this.porDia[i]; return (d && d.porCat[g.catId]) || null; },
    libresTipo(g, i) { const t = this.tipo(g, i); return t ? t.libres : 0; },
    tarifaTipo(g, i) { const t = this.tipo(g, i); return t && t.tarifa_prom !== null ? money(t.tarifa_prom, this.moneda) : '—'; },
    tituloTipo(g, i) { const t = this.tipo(g, i); if (!t) return ''; return g.nombre + ': ' + t.libres + ' libre(s) de ' + t.total + ' · ' + t.ocupadas + ' ocupada(s)' + (t.sin_asignar ? ' · ' + t.sin_asignar + ' sin habitación asignada' : '') + (t.bloqueadas ? ' · ' + t.bloqueadas + ' bloqueada(s) o fuera de servicio' : '') + (t.tarifa_prom !== null ? ' · tarifa promedio vendida ' + money(t.tarifa_prom, this.moneda) : ' · sin ventas esa noche'); },
    tituloPie(o) { return o.ocupadas + ' ocupada(s)' + (o.sin_asignar ? ' · ' + o.sin_asignar + ' sin habitación asignada' : '') + (o.bloqueadas ? ' · ' + o.bloqueadas + ' bloqueada(s) o fuera de servicio' : '') + ' · ' + o.total + ' habitaciones'; },
  },
  template: `
  <div class="tape" :class="[compacto ? 'semana' : 'completo', zoom ? 'zoom' : '', (dias || []).length === 1 ? 'un-dia' : '']">
    <table>
      <thead><tr><th class="hab">Habitación</th><th v-for="c in cabeceras" :key="c.iso" :class="{fin: c.fin, hoy: c.hoy}"><span class="d">{{c.dia}}</span><br><b>{{c.num}}</b> <span class="m">{{c.mes}}</span></th></tr></thead>
      <tbody v-for="g in grupos" :key="g.nombre">
        <tr class="tipo" v-if="g.nombre && resumenTipo && g.catId"><td class="hab">{{g.nombre}}<small>libres · tarifa promedio vendida</small></td><td v-for="(c, i) in cabeceras" :key="c.iso" :class="{hoy: c.hoy, sin: libresTipo(g, i) <= 0}" :title="tituloTipo(g, i)"><b>{{libresTipo(g, i)}}</b><span class="tar"><br>{{tarifaTipo(g, i)}}</span></td></tr>
        <tr class="piso" v-else-if="g.nombre"><td :colspan="cabeceras.length + 1">{{g.nombre}}</td></tr>
        <tr v-for="h in g.habs" :key="h.id">
          <td class="hab">{{h.numero}}<small>{{nombreCat(h.categoria_id)}}<span v-if="h.estado && h.estado !== 'limpia'" class="est" :class="h.estado"> · {{h.estado === 'sucia' ? 'sucia' : h.estado === 'limpiando' ? 'limpiando' : 'mant.'}}</span></small></td>
          <td v-for="c in (filas[h.id] || [])" :key="c.iso" :class="{fin: etiqueta(c.iso).fin, hoy: c.iso === hoyS, libre: !c.r && c.iso >= hoyS && !soloLectura}" @click="clic(h, c)" :title="!c.r ? precioDia(h, c.iso) + (c.iso >= hoyS && !soloLectura ? ' · toque para reservar en ' + h.numero : '') : ''">
            <div v-if="c.inicio" class="res" :class="[claseEstado(c.r, hoyS), marcas(c.r)]" :style="{width: 'calc(' + (c.span * 100) + '% - 4px)'}" :title="titulo(c.r)" @click.stop="$emit('abrir', c.r)">{{texto(c.r)}}<span class="or" v-if="c.r.origen && c.r.origen !== 'directa' && c.r.tipo !== 'bloqueo'">{{origenCorto(c.r.origen)}}</span></div>
          </td>
        </tr>
      </tbody>
      <tfoot v-if="!compacto"><tr><td class="hab">Ocupación</td><td v-for="(o, i) in porDia" :key="i" :class="{hoy: dias[i] === hoyS, sin: o.libres < 0}" class="oc" :title="tituloPie(o)"><b>{{o.pct}} %</b><br><span>{{o.libres}} libres</span></td></tr></tfoot>
    </table>
  </div>`,
  setup() { return { nombreCat, etiqueta: etiquetaDia, origenCorto }; },
};
