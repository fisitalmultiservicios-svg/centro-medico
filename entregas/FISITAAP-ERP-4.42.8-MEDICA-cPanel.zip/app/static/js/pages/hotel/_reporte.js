// Botón y cuadro «Reportar problema» (2.4): cualquier usuario reporta algo de una habitación o de una zona del hotel; el tipo de
// problema decide si va a Ama de llaves o a Mantenimiento. Se usa desde el menú, Recepción, Ama de llaves y Mantenimiento.
import { toast, mock } from '../../api.js';
import { habitaciones, nombreCat, tiposProblema, crearReporte, MODULOS_REPORTE, nombreModulo, usuarioActual } from './_datos.js';

export default {
  props: { habitacionId: { type: Number, default: null }, modulo: { type: String, default: '' } },
  emits: ['close', 'creado'],
  data() { return { f: { habitacion_id: this.habitacionId, lugar: '', modulo: this.modulo || 'limpieza', tipo: '', otro: '', descripcion: '', prioridad: 'normal', bloquear: false }, guardando: false, MODULOS_REPORTE }; },
  computed: {
    habs() { return habitaciones(); },
    tipos() { return tiposProblema(this.f.modulo); },
    hab() { return this.habs.find(h => h.id === this.f.habitacion_id) || null; },
  },
  watch: { 'f.modulo'() { this.f.tipo = ''; } },
  methods: {
    nombreCat, nombreModulo,
    guardar() {
      const f = this.f;
      const tipo = f.tipo === '__otro' ? (f.otro || '').trim() : f.tipo;
      if (!tipo) return toast('Elija el tipo de problema', 'err');
      if (!f.habitacion_id && !(f.lugar || '').trim()) return toast('Indique la habitación o el lugar (piscina, lobby, pasillo…)', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const r = crearReporte({ habitacion_id: f.habitacion_id || null, lugar: f.habitacion_id ? '' : f.lugar.trim(), modulo: f.modulo, tipo, descripcion: (f.descripcion || '').trim(), prioridad: f.prioridad, reportado_por: usuarioActual() });
      if (f.bloquear && f.habitacion_id) mock.actualizar('hotel_habitaciones', l => (l || []).map(h => (h.id === f.habitacion_id ? { ...h, estado: 'mantenimiento', estado_hora: new Date().toISOString(), estado_usuario: usuarioActual() } : h)), []);
      toast('Reporte ' + r.numero + ' enviado a ' + nombreModulo(f.modulo) + (f.bloquear && f.habitacion_id ? ' · la habitación queda en mantenimiento' : ''), 'ok');
      this.guardando = false;
      this.$emit('creado', r); this.$emit('close');
    },
  },
  template: `
  <Modal title="Reportar un problema" @close="$emit('close')">
    <div class="grid cols-2">
      <Field label="Habitación" help="Vacío si es una zona común"><select v-model="f.habitacion_id"><option :value="null">— Zona común / otro lugar —</option><option v-for="h in habs" :key="h.id" :value="h.id">{{h.numero}} · {{nombreCat(h.categoria_id)}}</option></select></Field>
      <Field label="Lugar" v-if="!f.habitacion_id" req><input v-model="f.lugar" maxlength="60" placeholder="Piscina, lobby, pasillo piso 2, restaurante…"></Field>
      <Field label="A quién va" req style="grid-column:1/-1"><div class="seg"><button v-for="m in MODULOS_REPORTE" :key="m[0]" :class="{on: f.modulo===m[0]}" @click="f.modulo=m[0]">{{m[1]}}</button></div></Field>
      <Field label="Tipo de problema" req style="grid-column:1/-1"><select v-model="f.tipo"><option value="">— Elegir —</option><option v-for="t in tipos" :key="t.id" :value="t.nombre">{{t.nombre}}</option><option value="__otro">Otro…</option></select></Field>
      <Field label="¿Cuál?" req v-if="f.tipo==='__otro'" style="grid-column:1/-1"><input v-model="f.otro" maxlength="80"></Field>
      <Field label="Detalle" style="grid-column:1/-1"><textarea rows="3" v-model="f.descripcion" maxlength="500" placeholder="Qué pasa, dónde exactamente, desde cuándo…"></textarea></Field>
      <Field label="Prioridad"><select v-model="f.prioridad"><option value="normal">Normal</option><option value="urgente">Urgente (el huésped lo necesita ya)</option></select></Field>
    </div>
    <label class="row" style="gap:8px;margin-top:10px;cursor:pointer" v-if="f.habitacion_id && f.modulo==='mantenimiento'"><input type="checkbox" v-model="f.bloquear"> Dejar la habitación en mantenimiento (no se asigna hasta resolverlo)</label>
    <p class="small muted" style="margin:8px 0 0">El reporte queda en {{nombreModulo(f.modulo)}} con su nombre y la hora; allí lo toman, lo resuelven o lo pasan al otro módulo.</p>
    <template #foot><button class="btn ghost" @click="$emit('close')">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Enviar reporte</button></template>
  </Modal>`,
};
