// Hotel › Eventos y banquetes (3.6): salones con capacidad y montajes; eventos que nacen como cotización (salón, menú por persona,
// coffee break, equipo, decoración…), se confirman abriendo una cuenta externa (CE-) con su anticipo como depósito en garantía,
// se cargan a la cuenta al realizarse y se cierran y facturan desde Recepción como cualquier cuenta. Orden de servicio (BEO)
// imprimible para cocina, montaje y operación, y calendario de salones.
// Registros: hotel_salones (catálogo) y hotel_eventos.
import { toast, money, fmt, fecha, fechaHora, hoy, sumarDias, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { cuentasParaMovimientos, cuentaPrincipal, cuentaParaMedio } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta
import { config, hotelActivo, reserva, nuevaCuentaExterna, guardarReserva, cambiarReserva, anotar, usuarioActual, agregarFolio, quitarFolio, folios, folioDe, totalesFolio, convertirMonto, MONEDAS_HOTEL, MEDIOS, nombreMedio, crearDeposito, aplicarDeposito, salones, eventos, TIPOS_EVENTO, MONTAJES, ESTADOS_EVENTO, CONCEPTOS_EVENTO, cargoEvento, totalEvento, abrirHoja, encabezadoHoja, fechaLarga, fechasEntre, etiquetaDia, r2 } from './_datos.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const CLASE = { cotizado: 'info', confirmado: 'primary', realizado: 'ok', cancelado: '' };
const SALONES_EJEMPLO = [{ nombre: 'Salón principal', capacidad: 150, montajes: ['banquete', 'auditorio', 'coctel', 'escuela'], precio: 600 }, { nombre: 'Sala de juntas', capacidad: 20, montajes: ['u', 'escuela'], precio: 150 }, { nombre: 'Terraza', capacidad: 80, montajes: ['banquete', 'coctel'], precio: 400 }];
const lineaNueva = (concepto, por) => ({ concepto: concepto || '', por: por || 'evento', cantidad: 1, precio: null, producto_id: null });

export default {
  props: ['params'],
  data() {
    const h = hoy();
    return { cfg: config(), tab: ['eventos', 'calendario', 'salones'].includes(this.params.tab) ? this.params.tab : 'eventos', salones: salones(), lista: eventos(), q: '', filtro: 'vigentes', form: null, salon: null, anticipo: null, ver: null,
      mes: h.slice(0, 7), cuentas: [], activo: hotelActivo(), TIPOS_EVENTO, MONTAJES, ESTADOS_EVENTO, CONCEPTOS_EVENTO, MONEDAS_HOTEL, MEDIOS, guardando: false };
  },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    puedeCatalogo() { return sesion.puede('catalogos') || sesion.puede('configurar'); },
    clientes() { return (store.clientes || []).filter(c => c.activo !== false && c.tipo !== 'Proveedor').sort((a, b) => a.nombre.localeCompare(b.nombre)); },
    productos() { return (store.productos || []).filter(p => p.activo !== false && p.es_venta !== false); },   // sin insumos (3.18)
    salonesActivos() { return this.salones.filter(s => s.activo !== false); },
    filas() {
      const q = this.q.trim().toLowerCase(), h = hoy();
      return this.lista.map(e => this.enriquecer(e))
        .filter(e => this.filtro === 'todos' || (this.filtro === 'vigentes' && e.estado !== 'cancelado' && e.fecha >= sumarDias(h, -1)) || (this.filtro === 'cotizados' && e.estado === 'cotizado') || (this.filtro === 'confirmados' && e.estado === 'confirmado') || (this.filtro === 'realizados' && e.estado === 'realizado') || (this.filtro === 'cancelados' && e.estado === 'cancelado'))
        .filter(e => !q || [e.numero, e.nombre, e.cliente_nombre, e.salon_nombre, e.tipo_txt].some(x => String(x || '').toLowerCase().includes(q)))
        .sort((a, b) => a.fecha.localeCompare(b.fecha) || String(a.hora_inicio || '').localeCompare(String(b.hora_inicio || '')));
    },
    kpis() {
      const h = hoy(), m = h.slice(0, 7), mon = this.cfg.moneda;
      const mesL = this.lista.filter(e => e.fecha.slice(0, 7) === m && e.estado !== 'cancelado');
      return { cotizados: this.lista.filter(e => e.estado === 'cotizado' && e.fecha >= h).length, confirmados: this.lista.filter(e => e.estado === 'confirmado' && e.fecha >= h).length, mes: mesL.length, mes_total: r2(mesL.reduce((s, e) => s + convertirMonto(totalEvento(e), e.moneda, mon, this.cfg), 0)), personas: mesL.reduce((s, e) => s + (+e.personas || 0), 0) };
    },
    // calendario del mes: una fila por día, una columna por salón
    diasMes() { const d = this.mes + '-01', n = new Date(+this.mes.slice(0, 4), +this.mes.slice(5, 7), 0).getDate(); return fechasEntre(d, n).map(f => ({ f, et: etiquetaDia(f) })); },
    porDiaSalon() { const m = {}; for (const e of this.lista.filter(e => e.estado !== 'cancelado' && e.fecha.slice(0, 7) === this.mes)) { const k = e.fecha + '|' + (e.salon_id || 0); (m[k] = m[k] || []).push(e); } return m; },
    totalForm() { return this.form ? totalEvento(this.form) : 0; },
    conflicto() {
      const f = this.form; if (!f || !f.salon_id || !f.fecha) return null;
      const otro = this.lista.find(e => e.id !== f.id && e.salon_id === f.salon_id && e.fecha === f.fecha && ['confirmado', 'realizado'].includes(e.estado) && this.cruzaHoras(e, f));
      return otro ? otro.numero + ' · ' + otro.nombre + ' (' + (otro.hora_inicio || 'todo el día') + (otro.hora_fin ? '–' + otro.hora_fin : '') + ')' : null;
    },
    salonForm() { return this.form ? this.salones.find(s => s.id === this.form.salon_id) || null : null; },
  },
  methods: {
    money, fmt, fecha, fechaHora, nombreMedio, totalEvento,
    M(v, mon) { return money(v || 0, mon || this.cfg.moneda); },
    clase(e) { return 'badge ' + (CLASE[e] || ''); },
    nombreTipo(t) { return (TIPOS_EVENTO.find(x => x[0] === t) || [t, t])[1]; },
    nombreMontaje(m) { return (MONTAJES.find(x => x[0] === m) || [m, m || '—'])[1]; },
    refrescar() { this.salones = salones(); this.lista = eventos(); if (this.ver) this.ver = this.lista.find(x => x.id === this.ver.id) ? this.enriquecer(this.lista.find(x => x.id === this.ver.id)) : null; },
    enriquecer(e) { const r = e.cuenta_id ? reserva(e.cuenta_id) : null, t = r ? totalesFolio(folioDe(r.id)) : null; return { ...e, tipo_txt: this.nombreTipo(e.tipo), estado_txt: ESTADOS_EVENTO[e.estado] || e.estado, salon_nombre: (this.salones.find(s => s.id === e.salon_id) || {}).nombre || e.salon_nombre || '—', total: totalEvento(e), cuenta: r, saldo: t ? t.saldo : null, pagado: t ? t.pagos : 0, facturada: !!(r && r.estado === 'cerrado') }; },
    cruzaHoras(a, b) { if (!a.hora_inicio || !a.hora_fin || !b.hora_inicio || !b.hora_fin) return true; return a.hora_inicio < b.hora_fin && b.hora_inicio < a.hora_fin; },
    cambiarMes(n) { const d = new Date(+this.mes.slice(0, 4), +this.mes.slice(5, 7) - 1 + n, 1); this.mes = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); },
    eventosEn(f, salonId) { return this.porDiaSalon[f + '|' + (salonId || 0)] || []; },
    // ---- salones ----
    nuevoSalon() { this.salon = { id: null, nombre: '', capacidad: null, montajes: ['banquete'], precio: null, precio_hora: null, moneda: this.cfg.moneda || 'USD', activo: true, notas: '' }; },
    editarSalon(s) { this.salon = { ...s, montajes: [...(s.montajes || [])] }; },
    cargarSalones() { if (!mock.puedeGuardar()) return; mock.actualizar('hotel_salones', l => { const lista = Array.isArray(l) ? l : []; for (const e of SALONES_EJEMPLO) lista.push({ ...e, id: mock.nextId(lista, 'hotel_salones'), precio_hora: null, moneda: this.cfg.moneda || 'USD', activo: true, notas: '' }); return lista; }, []); this.refrescar(); toast('Salones de ejemplo cargados: ajuste capacidad y precios', 'ok'); },
    guardarSalon() {
      const s = this.salon; if (!(s.nombre || '').trim()) return toast('Indique el nombre del salón', 'err'); if (!(+s.capacidad > 0)) return toast('Indique la capacidad', 'err');
      if (!mock.puedeGuardar()) return;
      const reg = { ...s, nombre: s.nombre.trim(), capacidad: Math.floor(+s.capacidad), precio: r2(s.precio), precio_hora: +s.precio_hora > 0 ? r2(s.precio_hora) : null, notas: (s.notas || '').trim() };
      mock.actualizar('hotel_salones', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'hotel_salones'); lista.push(reg); } return lista; }, []);
      this.salon = null; this.refrescar(); toast('Salón «' + reg.nombre + '» guardado', 'ok');
    },
    eliminarSalon(s) { if (this.lista.some(e => e.salon_id === s.id && ['cotizado', 'confirmado'].includes(e.estado))) return toast('Tiene eventos pendientes: desactívelo en lugar de eliminarlo', 'err'); if (!confirm('¿Eliminar el salón «' + s.nombre + '»?')) return; mock.actualizar('hotel_salones', l => (l || []).filter(x => x.id !== s.id), []); this.salon = null; this.refrescar(); },
    // ---- eventos ----
    nuevoEvento() {
      const s = this.salonesActivos[0];
      this.form = { id: null, nombre: '', tipo: 'corporativo', cliente_id: null, cliente_nombre: '', contacto: '', telefono: '', correo: '', salon_id: s ? s.id : null, fecha: sumarDias(hoy(), 7), hora_inicio: '09:00', hora_fin: '17:00', personas: 20, montaje: s && s.montajes && s.montajes[0] ? s.montajes[0] : 'banquete', moneda: s ? s.moneda : (this.cfg.moneda || 'USD'),
        lineas: [{ ...lineaNueva('Alquiler del salón', 'evento'), precio: s ? +s.precio || 0 : null }, { ...lineaNueva('Menú por persona', 'persona'), precio: null }], anticipo_pct: 50, vigencia: sumarDias(hoy(), 15), requerimientos: '', notas: '', estado: 'cotizado' };
    },
    editarEvento(e) { if (!['cotizado', 'confirmado'].includes(e.estado)) return; this.form = { ...e, lineas: (e.lineas || []).map(l => ({ ...l })) }; },
    elegirCliente() { const c = this.clientes.find(x => x.id === this.form.cliente_id); if (c) { this.form.cliente_nombre = c.nombre; if (!this.form.telefono && c.telefono) this.form.telefono = String(c.telefono); if (!this.form.correo && c.correo) this.form.correo = c.correo; } },
    cambiarSalon() { const s = this.salones.find(x => x.id === this.form.salon_id); if (!s) return; const l = this.form.lineas.find(x => /salón|salon/i.test(x.concepto)); if (l && !(+l.precio > 0)) l.precio = +s.precio || 0; if (s.montajes && s.montajes.length && !s.montajes.includes(this.form.montaje)) this.form.montaje = s.montajes[0]; this.form.moneda = s.moneda || this.form.moneda; },
    agregarLinea(c) { this.form.lineas.push(lineaNueva(c ? c[0] : '', c ? c[1] : 'evento')); },
    cantidadLinea(l) { return l.por === 'persona' ? (+this.form.personas || 0) : (+l.cantidad || 0); },
    guardarEvento() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Indique el nombre del evento', 'err'); if (!(f.cliente_nombre || '').trim()) return toast('Indique el cliente', 'err');
      if (!f.fecha) return toast('Indique la fecha', 'err'); if (!(+f.personas > 0)) return toast('Indique las personas', 'err');
      const s = this.salones.find(x => x.id === f.salon_id); if (s && +f.personas > +s.capacidad) return toast('El salón «' + s.nombre + '» admite hasta ' + s.capacidad + ' personas', 'err');
      if (f.hora_inicio && f.hora_fin && f.hora_fin <= f.hora_inicio) return toast('La hora de fin debe ser posterior a la de inicio', 'err');
      if (this.conflicto && f.estado !== 'cotizado') return toast('El salón ya está ocupado: ' + this.conflicto, 'err');
      const lineas = (f.lineas || []).filter(l => (l.concepto || '').trim() && +l.precio >= 0).map(l => ({ concepto: l.concepto.trim(), por: l.por === 'persona' ? 'persona' : 'evento', cantidad: l.por === 'persona' ? +f.personas : Math.max(1, +l.cantidad || 1), precio: r2(l.precio), producto_id: l.producto_id || null }));
      if (!lineas.length) return toast('Agregue al menos un concepto con precio', 'err');
      if (!mock.puedeGuardar()) return;
      const reg = { ...f, nombre: f.nombre.trim(), cliente_nombre: f.cliente_nombre.trim(), contacto: (f.contacto || '').trim(), telefono: (f.telefono || '').trim(), correo: (f.correo || '').trim(), personas: +f.personas, lineas, anticipo_pct: Math.min(100, Math.max(0, +f.anticipo_pct || 0)), requerimientos: (f.requerimientos || '').trim(), notas: (f.notas || '').trim(), salon_nombre: s ? s.nombre : '' };
      let guardado = null;
      mock.actualizar('hotel_eventos', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); guardado = { ...lista[i], ...reg }; if (i >= 0) lista.splice(i, 1, guardado); else lista.push(guardado); } else { const n = lista.reduce((m, e) => Math.max(m, +String(e.numero || '').replace(/\D/g, '') || 0), 0) + 1; guardado = { ...reg, id: mock.nextId(lista, 'hotel_eventos'), numero: 'EV-' + String(n).padStart(4, '0'), cuenta_id: null, deposito_id: null, cargado: false, creado: new Date().toISOString(), usuario: usuarioActual(), historial: [{ fecha: new Date().toISOString(), usuario: usuarioActual(), texto: 'Cotización creada' }] }; lista.push(guardado); } return lista; }, []);
      this.form = null; this.refrescar(); toast('Evento ' + guardado.numero + ' guardado' + (this.conflicto ? ' · ojo: el salón tiene otro evento confirmado ese día' : ''), 'ok');
    },
    cambiar(id, fn) { mock.actualizar('hotel_eventos', l => (l || []).map(x => (x.id === id ? fn({ ...x }) : x)), []); this.refrescar(); },
    anotar(e, texto) { return { ...e, historial: [...(e.historial || []), { fecha: new Date().toISOString(), usuario: usuarioActual(), texto }].slice(-60) }; },
    // Confirmar: abre la cuenta externa del evento (CE-) y pregunta por el anticipo
    confirmar(e) {
      const otro = this.lista.find(x => x.id !== e.id && x.salon_id === e.salon_id && x.fecha === e.fecha && ['confirmado', 'realizado'].includes(x.estado) && this.cruzaHoras(x, e));
      if (otro) return toast('El salón ya está confirmado para ' + otro.numero + ' · ' + otro.nombre, 'err');
      if (!mock.puedeGuardar()) return;
      let cuentaId = e.cuenta_id;
      if (!cuentaId) { const ce = nuevaCuentaExterna(this.cfg); ce.huesped_nombre = 'Evento ' + e.numero + ' · ' + e.nombre; ce.cliente_id = e.cliente_id || null; ce.segmento = 'Evento'; ce.grupo = e.numero; ce.llegada = e.fecha; ce.salida = e.fecha; ce.moneda = e.moneda || this.cfg.moneda; ce.notas = e.cliente_nombre + (e.salon_nombre ? ' · ' + e.salon_nombre : ''); cuentaId = guardarReserva(anotar(ce, 'Cuenta del evento ' + e.numero)).reg.id; }
      this.cambiar(e.id, x => this.anotar({ ...x, estado: 'confirmado', cuenta_id: cuentaId, confirmado: new Date().toISOString() }, 'Confirmado · cuenta ' + (reserva(cuentaId) || {}).numero));
      toast('Evento ' + e.numero + ' confirmado', 'ok');
      const total = totalEvento(e), pct = +e.anticipo_pct || 0;
      if (pct > 0) this.abrirAnticipo({ ...e, cuenta_id: cuentaId }, r2(total * pct / 100));
    },
    abrirAnticipo(e, monto) { const b = cuentaParaMedio('04', e.moneda || this.cfg.moneda, this.cuentas) || cuentaParaMedio('04', 'CRC', this.cuentas);   /* 4.5: según el medio */ this.anticipo = { evento_id: e.id, numero: e.numero, monto: monto || r2(totalEvento(e) * (+e.anticipo_pct || 0) / 100), moneda: e.moneda || this.cfg.moneda, medio: '04', cuenta: b ? b.nombre : '', referencia: '', fecha: hoy() }; },
    cambiarMonedaAnticipo() { const b = cuentaParaMedio(this.anticipo.medio, this.anticipo.moneda, this.cuentas); if (b) this.anticipo.cuenta = b.nombre; },   // 4.5: según el medio
    async confirmarAnticipo() {
      const a = this.anticipo, e = this.lista.find(x => x.id === a.evento_id); if (!e || !e.cuenta_id) return toast('El evento no tiene cuenta', 'err'); if (!(+a.monto > 0)) return toast('Indique el monto', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const d = await crearDeposito({ nombre: e.cliente_nombre, cliente_id: e.cliente_id || null, huesped_id: null, grupo: e.numero, monto: r2(a.monto), moneda: a.moneda, medio: a.medio, cuenta: a.cuenta, referencia: (a.referencia || '').trim(), fecha: a.fecha, notas: 'Anticipo del evento ' + e.numero + ' · ' + e.nombre });
      const r = reserva(e.cuenta_id); const item = r ? aplicarDeposito(d, r, d.monto) : null;
      if (r) cambiarReserva(r.id, x => anotar(x, 'Anticipo del evento: depósito ' + d.numero + ' aplicado'));
      this.cambiar(e.id, x => this.anotar({ ...x, deposito_id: d.id }, 'Anticipo recibido: ' + money(d.monto, d.moneda) + ' (' + d.numero + ')' + (item ? ' aplicado a la cuenta' : '')));
      this.guardando = false; this.anticipo = null; toast('Anticipo ' + d.numero + ' registrado' + (d.cuenta ? ' y en Bancos' : '') + ' y aplicado a la cuenta', 'ok');
    },
    cargar(e) {
      const r = reserva(e.cuenta_id); if (!r || r.estado !== 'abierto') { toast('La cuenta del evento no está abierta', 'err'); return false; }
      for (const l of e.lineas || []) agregarFolio(cargoEvento(l, e, r, this.cfg, this.productos));
      this.cambiar(e.id, x => this.anotar({ ...x, cargado: true }, 'Cargado a la cuenta ' + r.numero + ': ' + money(totalEvento(e), e.moneda)));
      return true;
    },
    cargarCuenta(e) { if (!mock.puedeGuardar()) return; if (e.cargado) return toast('Ya está cargado a la cuenta', 'err'); if (this.cargar(e)) toast('Evento cargado a la cuenta ' + (e.cuenta ? e.cuenta.numero : ''), 'ok'); },
    realizado(e) { if (!mock.puedeGuardar()) return; if (!e.cargado && !this.cargar(e)) return; this.cambiar(e.id, x => this.anotar({ ...x, estado: 'realizado', realizado: new Date().toISOString() }, 'Evento realizado')); toast('Evento ' + e.numero + ' realizado: cierre y facture la cuenta desde Recepción', 'ok'); },
    cancelar(e) {
      if (!confirm('¿Cancelar el evento ' + e.numero + ' · ' + e.nombre + '?' + (e.cargado ? ' Se quitan de la cuenta los cargos no facturados.' : '') + (e.deposito_id ? ' El anticipo queda en la cuenta: devuélvalo o trasládelo desde Depósitos en garantía.' : ''))) return;
      if (!mock.puedeGuardar()) return;
      if (e.cuenta_id) { let fact = 0; for (const f of folios().filter(f => f.reserva_id === e.cuenta_id && f.tipo === 'cargo' && f.origen === 'eventos')) { if (f.documento_id) fact++; else quitarFolio(f.id); } if (fact) toast(fact + ' cargo(s) ya facturados quedan en la cuenta: anúlelos con nota de crédito', 'err'); }
      this.cambiar(e.id, x => this.anotar({ ...x, estado: 'cancelado', cargado: false }, 'Cancelado')); toast('Evento cancelado', 'ok');
    },
    reabrir(e) { if (!mock.puedeGuardar()) return; this.cambiar(e.id, x => this.anotar({ ...x, estado: x.cuenta_id ? 'confirmado' : 'cotizado' }, 'Reabierto')); },
    // ---- hojas ----
    cotizacion(e) {
      const filas = (e.lineas || []).map(l => '<tr><td>' + esc(l.concepto) + (l.por === 'persona' ? ' <span class="muted">(por persona)</span>' : '') + '</td><td class="n">' + esc(fmt(l.cantidad, 0)) + '</td><td class="n">' + esc(money(l.precio, e.moneda)) + '</td><td class="n">' + esc(money(r2(l.cantidad * l.precio), e.moneda)) + '</td></tr>').join('');
      const total = totalEvento(e), ant = r2(total * (+e.anticipo_pct || 0) / 100);
      abrirHoja('Cotización ' + e.numero, encabezadoHoja('Cotización de evento · ' + e.numero) + '<table style="margin-top:10px"><tr><th style="width:180px">Evento</th><td>' + esc(e.nombre) + ' · ' + esc(this.nombreTipo(e.tipo)) + '</td></tr><tr><th>Cliente</th><td>' + esc(e.cliente_nombre) + (e.contacto ? ' · ' + esc(e.contacto) : '') + (e.telefono ? ' · ' + esc(e.telefono) : '') + (e.correo ? ' · ' + esc(e.correo) : '') + '</td></tr><tr><th>Fecha y horario</th><td>' + esc(fechaLarga(e.fecha)) + (e.hora_inicio ? ' · ' + esc(e.hora_inicio) + (e.hora_fin ? ' a ' + esc(e.hora_fin) : '') : '') + '</td></tr><tr><th>Salón y montaje</th><td>' + esc((this.salones.find(s => s.id === e.salon_id) || {}).nombre || e.salon_nombre || '') + ' · ' + esc(this.nombreMontaje(e.montaje)) + ' · ' + esc(e.personas) + ' personas</td></tr></table>'
        + '<h2>Detalle</h2><table><thead><tr><th>Concepto</th><th class="n">Cantidad</th><th class="n">Precio</th><th class="n">Total</th></tr></thead><tbody>' + filas + '</tbody></table>'
        + '<table style="margin-top:8px"><tr><th style="width:180px">Total' + (this.cfg.precios_incluyen_iva ? ' (IVA incluido)' : ' (más IVA)') + '</th><td style="text-align:right;font-size:16px;font-weight:700">' + esc(money(total, e.moneda)) + '</td></tr>' + (ant ? '<tr><th>Anticipo para confirmar (' + esc(e.anticipo_pct) + ' %)</th><td style="text-align:right">' + esc(money(ant, e.moneda)) + '</td></tr>' : '') + (e.vigencia ? '<tr><th>Válida hasta</th><td style="text-align:right">' + esc(fecha(e.vigencia)) + '</td></tr>' : '') + '</table>'
        + (e.notas ? '<h2>Condiciones y notas</h2><p>' + esc(e.notas) + '</p>' : '') + '<p class="muted" style="margin-top:14px">Cotización emitida el ' + esc(new Date().toLocaleDateString('es-CR')) + ' por ' + esc(usuarioActual()) + '. No es un comprobante electrónico; la factura se emite al cerrar la cuenta del evento.</p>');
    },
    ordenServicio(e) {
      const filas = (e.lineas || []).map(l => '<tr><td>' + esc(l.concepto) + '</td><td class="n">' + esc(fmt(l.cantidad, 0)) + (l.por === 'persona' ? ' pers.' : '') + '</td></tr>').join('');
      abrirHoja('Orden de servicio ' + e.numero, encabezadoHoja('Orden de servicio (BEO) · ' + e.numero + ' · ' + e.nombre) + '<table style="margin-top:10px"><tr><th style="width:180px">Fecha y horario</th><td><b>' + esc(fechaLarga(e.fecha)) + '</b>' + (e.hora_inicio ? ' · ' + esc(e.hora_inicio) + (e.hora_fin ? ' a ' + esc(e.hora_fin) : '') : '') + '</td></tr><tr><th>Salón</th><td>' + esc((this.salones.find(s => s.id === e.salon_id) || {}).nombre || e.salon_nombre || '') + '</td></tr><tr><th>Montaje</th><td>' + esc(this.nombreMontaje(e.montaje)) + ' para ' + esc(e.personas) + ' personas</td></tr><tr><th>Cliente</th><td>' + esc(e.cliente_nombre) + (e.contacto ? ' · ' + esc(e.contacto) : '') + (e.telefono ? ' · tel. ' + esc(e.telefono) : '') + '</td></tr><tr><th>Tipo</th><td>' + esc(this.nombreTipo(e.tipo)) + '</td></tr><tr><th>Estado</th><td>' + esc(ESTADOS_EVENTO[e.estado] || e.estado) + '</td></tr></table>'
        + '<h2>Servicios contratados</h2><table><thead><tr><th>Concepto</th><th class="n">Cantidad</th></tr></thead><tbody>' + filas + '</tbody></table>'
        + '<h2>Requerimientos (cocina, montaje, equipo, decoración, minuta)</h2><p style="white-space:pre-wrap">' + (e.requerimientos ? esc(e.requerimientos) : '<span class="muted">Sin requerimientos anotados.</span>') + '</p>'
        + '<table style="margin-top:18px"><tr><td style="width:33%;border:0;padding-top:28px;border-top:1px solid #999">Cocina</td><td style="width:33%;border:0;padding-top:28px;border-top:1px solid #999">Montaje y salón</td><td style="border:0;padding-top:28px;border-top:1px solid #999">Coordinador del evento</td></tr></table><p class="muted">Impresa el ' + esc(new Date().toLocaleString('es-CR')) + ' por ' + esc(usuarioActual()) + '. Sin precios: documento interno de operación.</p>');
    },
    exportar(formato) {
      const cols = [{ key: 'numero', label: 'Evento' }, { key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'nombre', label: 'Nombre' }, { key: 'tipo_txt', label: 'Tipo' }, { key: 'cliente_nombre', label: 'Cliente' }, { key: 'salon_nombre', label: 'Salón' }, { key: 'personas', label: 'Personas', num: true }, { key: 'total', label: 'Total', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'estado_txt', label: 'Estado' }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'eventos', cols, this.filas);
      return descargarReporte(formato, { titulo: 'Eventos y banquetes · ' + (this.cfg.nombre || 'Hotel'), subtitulo: { vigentes: 'Cotizados y confirmados próximos', todos: 'Todos', cotizados: 'Cotizados', confirmados: 'Confirmados', realizados: 'Realizados', cancelados: 'Cancelados' }[this.filtro], cols, rows: this.filas, kpis: [{ t: 'Eventos', v: String(this.filas.length) }, { t: 'Personas', v: String(this.filas.reduce((s, e) => s + (+e.personas || 0), 0)) }], archivo: 'eventos' });
    },
  },
  watch: { 'anticipo.medio'(m) { if (this.anticipo) { const b = cuentaParaMedio(m, this.anticipo.moneda, this.cuentas); if (b) this.anticipo.cuenta = b.nombre; } } },   // 4.5: el medio decide la cuenta (efectivo → Efectivo; tarjeta, SINPE o transferencia → Banco)
  async created() { try { this.cuentas = await cuentasParaMovimientos(); } catch {} },
  template: `
  <div class="page">
    <PageHead title="Eventos y banquetes" :sub="activo ? 'Cotice, confirme con anticipo, imprima la orden de servicio y facture el evento desde su cuenta.' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Eventos y banquetes'}]">
      <button class="btn ghost sm" v-if="tab==='eventos' && filas.length" @click="exportar('pdf')">PDF</button><button class="btn ghost sm" v-if="tab==='eventos' && filas.length" @click="exportar('xlsx')">Excel</button><button class="btn ghost sm" v-if="tab==='eventos' && filas.length" @click="exportar('csv')">CSV</button>
      <button class="btn" v-if="tab!=='salones' && puedeEscribir && activo" @click="nuevoEvento">+ Nuevo evento</button>
      <button class="btn" v-if="tab==='salones' && puedeCatalogo && activo" @click="nuevoSalon">+ Salón</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🎉" title="El hotel no está configurado" text="Active el hotel en Hotel › Habitaciones y tarifas y luego cree los salones."></Empty></div>
    <template v-else>
    <div class="tabs"><button :class="{on: tab==='eventos'}" @click="tab='eventos'">Eventos y cotizaciones</button><button :class="{on: tab==='calendario'}" @click="tab='calendario'">Calendario de salones</button><button :class="{on: tab==='salones'}" @click="tab='salones'">Salones</button></div>

    <template v-if="tab==='eventos'">
      <div class="kpis">
        <div class="kpi"><div class="t">Cotizaciones abiertas</div><div class="v">{{kpis.cotizados}}</div><div class="d">por confirmar</div></div>
        <div class="kpi"><div class="t">Confirmados</div><div class="v">{{kpis.confirmados}}</div><div class="d">próximos</div></div>
        <div class="kpi"><div class="t">Eventos del mes</div><div class="v">{{kpis.mes}}</div><div class="d">{{kpis.personas}} personas</div></div>
        <div class="kpi"><div class="t">Valor del mes</div><div class="v">{{M(kpis.mes_total)}}</div><div class="d">cotizado, confirmado o realizado</div></div>
      </div>
      <div class="card">
        <div class="toolbar"><input class="search" placeholder="Buscar evento, cliente o salón" v-model="q"><div class="seg"><button v-for="f in [['vigentes','Próximos'],['cotizados','Cotizados'],['confirmados','Confirmados'],['realizados','Realizados'],['cancelados','Cancelados'],['todos','Todos']]" :key="f[0]" :class="{on: filtro===f[0]}" @click="filtro=f[0]">{{f[1]}}</button></div></div>
        <Empty v-if="!filas.length" icon="🎉" title="Sin eventos" text="Cree la cotización de una boda, un seminario o una fiesta: salón, menú por persona, equipo… Al confirmarla se abre la cuenta del evento con su anticipo."><button class="btn" v-if="puedeEscribir" @click="nuevoEvento">+ Nuevo evento</button></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Evento</th><th>Fecha</th><th>Nombre</th><th>Cliente</th><th>Salón</th><th class="num">Personas</th><th class="num">Total</th><th>Cuenta</th><th>Estado</th><th></th></tr></thead>
          <tbody><tr v-for="e in filas" :key="e.id" :style="e.estado==='cancelado' ? 'opacity:.55' : ''">
            <td class="mono"><a class="link" style="cursor:pointer" @click="ver=e">{{e.numero}}</a></td><td style="white-space:nowrap">{{fecha(e.fecha)}}<div class="small muted" v-if="e.hora_inicio">{{e.hora_inicio}}<span v-if="e.hora_fin">–{{e.hora_fin}}</span></div></td>
            <td><b>{{e.nombre}}</b><div class="small muted">{{e.tipo_txt}} · {{nombreMontaje(e.montaje)}}</div></td><td>{{e.cliente_nombre}}</td><td>{{e.salon_nombre}}</td><td class="num">{{e.personas}}</td><td class="num">{{money(e.total, e.moneda)}}</td>
            <td class="small"><template v-if="e.cuenta"><a class="link" :href="'#/hotel/recepcion?reserva=' + e.cuenta.id">{{e.cuenta.numero}}</a><div class="muted">{{e.facturada ? 'facturada' : (e.cargado ? 'cargada · saldo ' + money(e.saldo, e.cuenta.moneda) : (e.pagado ? 'anticipo ' + money(e.pagado, e.cuenta.moneda) : 'abierta'))}}</div></template><span v-else class="muted">—</span></td>
            <td><span :class="clase(e.estado)">{{e.estado_txt}}</span></td>
            <td style="white-space:nowrap"><div class="acts" v-if="puedeEscribir">
              <button class="btn sm" v-if="e.estado==='cotizado'" @click="confirmar(e)" title="Abrir la cuenta del evento y registrar el anticipo">Confirmar</button>
              <button class="btn sm" v-if="e.estado==='confirmado'" @click="realizado(e)" title="Marcar como realizado y cargar a la cuenta">Realizado</button>
              <button class="btn sm ghost" v-if="e.estado==='cotizado'" @click="cotizacion(e)">Cotización</button>
              <button class="btn sm ghost" v-if="e.estado!=='cancelado'" @click="ordenServicio(e)" title="Orden de servicio para cocina, montaje y operación">Orden de servicio</button>
              <button class="btn sm ghost" v-if="e.estado==='confirmado' && !e.deposito_id" @click="abrirAnticipo(e)">Anticipo</button>
              <button class="btn sm ghost" v-if="e.estado==='confirmado' && !e.cargado" @click="cargarCuenta(e)" title="Pasar los conceptos a la cuenta antes del evento">Cargar a la cuenta</button>
              <button class="btn sm ghost" v-if="e.estado==='cotizado' || e.estado==='confirmado'" @click="editarEvento(e)">Editar</button>
              <button class="btn sm ghost" v-if="e.estado==='cotizado' || e.estado==='confirmado'" @click="cancelar(e)">Cancelar</button>
              <button class="btn sm ghost" v-if="e.estado==='cancelado'" @click="reabrir(e)">Reabrir</button>
            </div></td>
          </tr></tbody></table></div>
      </div>
    </template>

    <div v-if="tab==='calendario'" class="card">
      <div class="toolbar"><button class="btn sm sec" @click="cambiarMes(-1)">◀</button><input type="month" class="inp" v-model="mes" style="width:170px"><button class="btn sm sec" @click="cambiarMes(1)">▶</button><span class="small muted">Confirmados y realizados en negrita; cotizaciones en gris.</span></div>
      <Empty v-if="!salonesActivos.length" icon="🏛" title="Sin salones" text="Cree los salones en la pestaña Salones para ver su calendario."></Empty>
      <div class="table-wrap" v-else><table class="tbl" style="min-width:600px"><thead><tr><th style="width:90px">Día</th><th v-for="s in salonesActivos" :key="s.id">{{s.nombre}} <span class="small muted">· {{s.capacidad}} pers.</span></th></tr></thead>
        <tbody><tr v-for="d in diasMes" :key="d.f" :style="d.et.fin ? 'background:var(--bg-soft, #f8fafc)' : ''"><td class="small" style="white-space:nowrap"><b>{{d.et.num}}</b> {{d.et.dia}}</td>
          <td v-for="s in salonesActivos" :key="s.id" class="small"><div v-for="e in eventosEn(d.f, s.id)" :key="e.id" :style="['confirmado','realizado'].includes(e.estado) ? 'font-weight:600' : 'color:var(--muted)'"><a class="link" style="cursor:pointer;color:inherit" @click="ver=enriquecer(e)">{{e.hora_inicio ? e.hora_inicio + ' ' : ''}}{{e.nombre}}</a> <span class="muted">· {{e.personas}} p.</span></div></td>
        </tr></tbody></table></div>
    </div>

    <div v-if="tab==='salones'" class="card">
      <Empty v-if="!salones.length" icon="🏛" title="Sin salones" text="Agregue los salones con su capacidad, los montajes posibles y el precio por evento."><div class="row" style="gap:8px"><button class="btn" v-if="puedeCatalogo" @click="nuevoSalon">+ Salón</button><button class="btn sec" v-if="puedeCatalogo" @click="cargarSalones">Cargar ejemplos</button></div></Empty>
      <table class="tbl" v-else><thead><tr><th>Salón</th><th class="num">Capacidad</th><th>Montajes</th><th class="num">Precio por evento</th><th class="num">Por hora</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="s in salones" :key="s.id" :style="s.activo===false ? 'opacity:.55' : ''"><td><b>{{s.nombre}}</b><div class="small muted" v-if="s.notas">{{s.notas}}</div></td><td class="num">{{s.capacidad}}</td><td class="small">{{(s.montajes||[]).map(nombreMontaje).join(', ') || '—'}}</td><td class="num">{{money(s.precio, s.moneda)}}</td><td class="num">{{s.precio_hora ? money(s.precio_hora, s.moneda) : '—'}}</td><td><span :class="s.activo===false ? 'badge' : 'badge ok'">{{s.activo===false ? 'Inactivo' : 'Activo'}}</span></td><td><button class="btn sm ghost" v-if="puedeCatalogo" @click="editarSalon(s)">Editar</button></td></tr></tbody></table>
    </div>
    </template>

    <Modal v-if="salon" :title="salon.id ? 'Salón' : 'Nuevo salón'" @close="salon=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="salon.nombre" maxlength="60"></Field><Field label="Capacidad (personas)" req><input type="number" min="1" step="1" v-model.number="salon.capacidad"></Field>
        <Field label="Precio por evento" req><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="salon.precio" style="flex:1"><select v-model="salon.moneda" style="width:110px"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></div></Field>
        <Field label="Precio por hora" help="Opcional, para reuniones cortas"><input type="number" min="0" step="0.01" v-model.number="salon.precio_hora"></Field>
        <Field label="Montajes posibles" style="grid-column:1/-1"><div class="row" style="gap:12px;flex-wrap:wrap"><label v-for="m in MONTAJES" :key="m[0]" class="row" style="gap:4px;cursor:pointer"><input type="checkbox" :value="m[0]" v-model="salon.montajes"> {{m[1]}}</label></div></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="salon.notas" maxlength="200" placeholder="Equipo incluido, acceso, restricciones…"></Field>
        <label class="row" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="salon.activo"> Activo</label>
      </div>
      <template #foot><button class="btn danger" v-if="salon.id" @click="eliminarSalon(salon)">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="salon=null">Cancelar</button><button class="btn" @click="guardarSalon">Guardar</button></template>
    </Modal>

    <Modal v-if="form" :title="form.id ? form.numero + ' · ' + form.nombre : 'Nuevo evento (cotización)'" lg @close="form=null">
      <div class="grid cols-3">
        <Field label="Nombre del evento" req style="grid-column:1/3"><input v-model="form.nombre" maxlength="100" placeholder="Boda Pérez-Mora, Seminario de ventas, Fiesta de fin de año…"></Field>
        <Field label="Tipo" req><select v-model="form.tipo"><option v-for="t in TIPOS_EVENTO" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Cliente (de Contactos)" help="Para la factura; vacío = solo el nombre"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Elegir" agregar="cliente" @change="elegirCliente"></Buscador></Field>
        <Field label="Nombre del cliente" req><input v-model="form.cliente_nombre" maxlength="100"></Field>
        <Field label="Persona de contacto"><input v-model="form.contacto" maxlength="80"></Field>
        <Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field><Field label="Correo"><input type="email" v-model="form.correo" maxlength="100"></Field>
        <Field label="Personas" req><input type="number" min="1" step="1" v-model.number="form.personas"></Field>
        <Field label="Fecha" req><input type="date" v-model="form.fecha"></Field><Field label="Hora de inicio"><input type="time" v-model="form.hora_inicio"></Field><Field label="Hora de fin"><input type="time" v-model="form.hora_fin"></Field>
        <Field label="Salón"><select v-model="form.salon_id" @change="cambiarSalon"><option :value="null">— Sin salón —</option><option v-for="s in salonesActivos" :key="s.id" :value="s.id">{{s.nombre}} · hasta {{s.capacidad}} · {{money(s.precio, s.moneda)}}</option></select></Field>
        <Field label="Montaje"><select v-model="form.montaje"><option v-for="m in (salonForm && salonForm.montajes && salonForm.montajes.length ? MONTAJES.filter(x => salonForm.montajes.includes(x[0])) : MONTAJES)" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
        <Field label="Moneda"><select v-model="form.moneda"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
      </div>
      <p class="small" style="margin:6px 0 0;color:var(--danger)" v-if="conflicto">⚠ El salón ya tiene un evento confirmado ese día: {{conflicto}}</p>
      <p class="small" style="margin:6px 0 0;color:var(--danger)" v-if="salonForm && +form.personas > +salonForm.capacidad">⚠ El salón admite hasta {{salonForm.capacidad}} personas.</p>
      <div class="row" style="justify-content:space-between;margin:12px 0 6px;flex-wrap:wrap;gap:6px"><b>Conceptos</b><div class="row" style="gap:4px;flex-wrap:wrap"><button v-for="c in CONCEPTOS_EVENTO" :key="c[0]" class="btn sm ghost" @click="agregarLinea(c)">+ {{c[0]}}</button><button class="btn sm sec" @click="agregarLinea(null)">+ Otro</button></div></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Concepto</th><th>Se cobra</th><th class="num">Cantidad</th><th class="num">Precio</th><th class="num">Total</th><th>Ítem de venta (IVA/CABYS)</th><th></th></tr></thead>
        <tbody><tr v-for="(l, k) in form.lineas" :key="k"><td><input class="inp" v-model="l.concepto" maxlength="80" style="width:100%"></td><td><select class="inp" v-model="l.por"><option value="evento">Por evento</option><option value="persona">Por persona</option></select></td><td class="num"><input class="inp" type="number" min="1" step="1" v-model.number="l.cantidad" style="width:80px;text-align:right" :disabled="l.por==='persona'" :placeholder="l.por==='persona' ? String(form.personas) : ''"><div class="small muted" v-if="l.por==='persona'">{{form.personas}} pers.</div></td><td class="num"><input class="inp" type="number" min="0" step="0.01" v-model.number="l.precio" style="width:110px;text-align:right"></td><td class="num">{{money(cantidadLinea(l) * (+l.precio || 0), form.moneda)}}</td><td><select class="inp" v-model="l.producto_id" style="max-width:200px"><option :value="null">— Los del hotel —</option><option v-for="p in productos" :key="p.id" :value="p.id">{{p.nombre}}</option></select></td><td><button class="btn icon" @click="form.lineas.splice(k,1)">✕</button></td></tr></tbody></table></div>
      <div class="grid cols-3" style="margin-top:10px">
        <Field label="Anticipo para confirmar (%)"><input type="number" min="0" max="100" step="5" v-model.number="form.anticipo_pct"></Field>
        <Field label="Cotización válida hasta"><input type="date" v-model="form.vigencia"></Field>
        <div class="totals" style="align-self:end"><div class="total"><span>Total{{cfg.precios_incluyen_iva ? ' (IVA incl.)' : ' + IVA'}}</span><b>{{money(totalForm, form.moneda)}}</b></div><div v-if="+form.anticipo_pct > 0"><span>Anticipo {{form.anticipo_pct}} %</span><b>{{money(r2(totalForm * form.anticipo_pct / 100), form.moneda)}}</b></div></div>
      </div>
      <Field label="Requerimientos para la orden de servicio" help="Menú, alergias, equipo, decoración, minuta del día: lo que cocina, montaje y operación deben saber" style="margin-top:6px"><textarea rows="3" v-model="form.requerimientos" maxlength="2000"></textarea></Field>
      <Field label="Condiciones y notas para el cliente"><textarea rows="2" v-model="form.notas" maxlength="600" placeholder="Incluye mantelería y servicio; bebidas aparte; cancelación con 7 días…"></textarea></Field>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardarEvento">{{form.id ? 'Guardar' : 'Guardar cotización'}}</button></template>
    </Modal>

    <Modal v-if="anticipo" :title="'Anticipo del evento ' + anticipo.numero" @close="anticipo=null">
      <div class="grid cols-2">
        <Field label="Monto" req><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="anticipo.monto" style="flex:1"><select v-model="anticipo.moneda" @change="cambiarMonedaAnticipo" style="width:110px"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></div></Field>
        <Field label="Medio" req><select v-model="anticipo.medio"><option v-for="m in MEDIOS" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
        <Field label="Cuenta donde entra" help="Vacío = no se registra en Bancos"><Buscador v-model="anticipo.cuenta" :opciones="cuentas" valor="nombre" :detalle="b => b.moneda || 'CRC'" placeholder="No registrar en Bancos" agregar="cuenta"></Buscador></Field>
        <Field label="Referencia"><input v-model="anticipo.referencia" maxlength="60" placeholder="Número de transferencia, voucher…"></Field>
        <Field label="Fecha"><input type="date" v-model="anticipo.fecha"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">El anticipo queda como depósito en garantía (DG-) aplicado a la cuenta del evento: si el evento se cancela, se devuelve o se traslada desde Reservaciones › Depósitos en garantía.</p>
      <template #foot><button class="btn ghost" @click="anticipo=null">Después</button><button class="btn" @click="confirmarAnticipo" :disabled="guardando">{{guardando ? 'Guardando…' : 'Registrar anticipo'}}</button></template>
    </Modal>

    <Modal v-if="ver" :title="ver.numero + ' · ' + ver.nombre" @close="ver=null">
      <div class="grid cols-2 small">
        <div><b>Cliente:</b> {{ver.cliente_nombre}}<span v-if="ver.contacto"> · {{ver.contacto}}</span><span v-if="ver.telefono"> · {{ver.telefono}}</span></div><div><b>Tipo:</b> {{ver.tipo_txt}} · <b>Estado:</b> {{ver.estado_txt}}</div>
        <div><b>Fecha:</b> {{fecha(ver.fecha)}}<span v-if="ver.hora_inicio"> · {{ver.hora_inicio}}<span v-if="ver.hora_fin">–{{ver.hora_fin}}</span></span></div><div><b>Salón:</b> {{ver.salon_nombre}} · {{nombreMontaje(ver.montaje)}} · {{ver.personas}} personas</div>
        <div><b>Total:</b> {{money(ver.total, ver.moneda)}}<span v-if="ver.anticipo_pct"> · anticipo {{ver.anticipo_pct}} %</span></div><div v-if="ver.cuenta"><b>Cuenta:</b> <a class="link" :href="'#/hotel/recepcion?reserva=' + ver.cuenta.id">{{ver.cuenta.numero}}</a> · pagado {{money(ver.pagado, ver.cuenta.moneda)}}<span v-if="ver.cargado"> · saldo {{money(ver.saldo, ver.cuenta.moneda)}}</span></div>
      </div>
      <table class="tbl" style="margin-top:10px"><thead><tr><th>Concepto</th><th class="num">Cantidad</th><th class="num">Precio</th><th class="num">Total</th></tr></thead><tbody><tr v-for="(l,k) in ver.lineas" :key="k"><td>{{l.concepto}}<span class="small muted" v-if="l.por==='persona'"> · por persona</span></td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio, ver.moneda)}}</td><td class="num">{{money(r2(l.cantidad * l.precio), ver.moneda)}}</td></tr></tbody></table>
      <p class="small" style="white-space:pre-wrap;margin:10px 0 0" v-if="ver.requerimientos"><b>Requerimientos:</b> {{ver.requerimientos}}</p>
      <p class="small muted" style="margin:6px 0 0" v-if="ver.notas">{{ver.notas}}</p>
      <div class="small muted" style="margin-top:10px" v-if="(ver.historial||[]).length"><div v-for="(h,i) in ver.historial.slice().reverse().slice(0,8)" :key="i">{{fechaHora(h.fecha)}} · {{h.usuario}} · {{h.texto}}</div></div>
      <template #foot><button class="btn ghost" @click="cotizacion(ver)">Cotización</button><button class="btn ghost" @click="ordenServicio(ver)">Orden de servicio</button><span style="flex:1"></span><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { r2 }; },
};
