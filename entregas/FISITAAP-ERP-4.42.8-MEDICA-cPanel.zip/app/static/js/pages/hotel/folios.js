// Hotel › Recepción › Cuentas externas (3.0): folios sin habitación para eventos, clientes externos, consumo de empleados o
// cuentas de agencia. Se abren aquí y se manejan en Recepción como cualquier cuenta (cargos, pagos, cerrar y facturar).
import { toast, money, fecha, fechaHora, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { config, hotelActivo, cuentasExternas, nuevaCuentaExterna, guardarReserva, anotar, folioDe, totalesFolio, segmentos, MONEDAS_HOTEL, buscarHuespedes, nombreHuesped } from './_datos.js';

export default {
  props: ['params'],
  data() { return { cfg: config(), lista: cuentasExternas(), q: '', filtro: 'abiertas', form: null, qH: '', segs: segmentos(), MONEDAS_HOTEL, activo: hotelActivo(), guardando: false }; },
  computed: {
    puedeEscribir() { return sesion.puede('escribir') || sesion.puede('pos'); },
    clientes() { return (store.clientes || []).filter(c => c.activo !== false); },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.lista.map(r => { const t = totalesFolio(folioDe(r.id)); return { ...r, cargos: t.cargos, pagos: t.pagos, saldo: t.saldo, estado_txt: r.estado === 'abierto' ? 'Abierta' : 'Cerrada', cliente: r.cliente_id ? (this.clientes.find(c => c.id === r.cliente_id) || {}).nombre || '' : '' }; })
        .filter(r => this.filtro === 'todas' || (this.filtro === 'abiertas' && r.estado === 'abierto') || (this.filtro === 'cerradas' && r.estado === 'cerrado'))
        .filter(r => !q || [r.numero, r.huesped_nombre, r.grupo, r.notas, r.cliente, r.consecutivo].some(x => String(x || '').toLowerCase().includes(q)))
        .sort((a, b) => String(b.creado).localeCompare(String(a.creado)));
    },
    columns() { return [{ key: 'numero', label: 'Cuenta', mono: true, link: r => this.abrir(r) }, { key: 'huesped_nombre', label: 'Nombre' }, { key: 'cliente', label: 'Contacto' }, { key: 'grupo', label: 'Grupo o evento' }, { key: 'creado', label: 'Abierta', fmt: 'date' }, { key: 'cargos', label: 'Cargos', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'pagos', label: 'Pagos', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'saldo', label: 'Saldo', num: true, fmt: (v, r) => money(v, r.moneda) }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' }]; },
    sugerencias() { return this.form && this.form.modoH === 'buscar' ? buscarHuespedes(this.qH) : []; },
  },
  methods: {
    money, fecha, fechaHora, nombreHuesped,
    refrescar() { this.lista = cuentasExternas(); },
    abrir(r) { location.hash = '/hotel/recepcion?reserva=' + r.id; },
    nuevo() { this.form = { ...nuevaCuentaExterna(this.cfg), modoH: 'buscar' }; this.qH = ''; },
    elegirH(h) { this.form.huesped_id = h.id; this.form.huesped_nombre = this.form.huesped_nombre || nombreHuesped(h); this.form.modoH = 'elegido'; this.qH = ''; },
    elegirCliente() { const c = this.clientes.find(x => x.id === this.form.cliente_id); if (c && !this.form.huesped_nombre) this.form.huesped_nombre = c.nombre; },
    async guardar() {
      const f = this.form; if (!(f.huesped_nombre || '').trim()) return toast('Indique el nombre de la cuenta', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true;
      const { modoH, ...datos } = f;
      const { reg, promesa } = guardarReserva(anotar({ ...datos, huesped_nombre: f.huesped_nombre.trim(), grupo: (f.grupo || '').trim(), notas: (f.notas || '').trim() }, 'Cuenta externa abierta'));
      const ok = await promesa; this.guardando = false;
      if (ok) { this.form = null; this.refrescar(); toast('Cuenta ' + reg.numero + ' abierta', 'ok'); this.abrir(reg); }
    },
  },
  template: `
  <div class="page">
    <PageHead title="Cuentas externas" sub="Cuentas sin habitación: eventos, salones, clientes externos, consumo de empleados o cuentas de agencia. Se manejan en Recepción como cualquier cuenta." :crumbs="[{label:'Hotel'},{label:'Recepción',to:'/hotel/recepcion'},{label:'Cuentas externas'}]">
      <button class="btn" @click="nuevo" v-if="puedeEscribir">+ Cuenta externa</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🧾" title="El hotel no está configurado"><a class="btn" href="#/hotel/configuracion" v-if="puede('configurar')">Habitaciones y tarifas</a></Empty></div>
    <div class="card" v-else>
      <div class="toolbar"><input class="search" placeholder="Buscar por número, nombre, contacto o evento" v-model="q">
        <div class="seg"><button :class="{on: filtro==='abiertas'}" @click="filtro='abiertas'">Abiertas</button><button :class="{on: filtro==='cerradas'}" @click="filtro='cerradas'">Cerradas</button><button :class="{on: filtro==='todas'}" @click="filtro='todas'">Todas</button></div></div>
      <DataTable :rows="filas" :columns="columns" :page-size="20" empty-title="Sin cuentas externas" empty-text="Abra una con «+ Cuenta externa»: por ejemplo un evento en el salón o la cuenta de un cliente que no se hospeda." @row-click="abrir">
        <template #actions="{row}"><a class="btn sm ghost" :href="'#/hotel/recepcion?reserva=' + row.id" @click.stop>{{row.estado==='abierto' ? 'Abrir' : 'Ver'}}</a></template>
      </DataTable>
    </div>
    <Modal v-if="form" title="Nueva cuenta externa" @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre de la cuenta" req help="Evento, persona o empresa" style="grid-column:1/-1"><input v-model="form.huesped_nombre" maxlength="80" placeholder="Boda Rodríguez · salón principal"></Field>
        <Field label="Huésped (opcional)"><template v-if="form.modoH==='buscar'"><input v-model="qH" placeholder="Buscar huésped"><div v-if="sugerencias.length" class="card" style="padding:4px;margin-top:4px"><div v-for="h in sugerencias" :key="h.id" class="row" style="padding:5px 8px;cursor:pointer" @click="elegirH(h)">{{nombreHuesped(h)}}</div></div></template><div v-else class="row" style="gap:6px"><span class="badge info">huésped elegido</span><button class="btn icon" @click="form.huesped_id=null; form.modoH='buscar'">✕</button></div></Field>
        <Field label="Contacto para facturar (opcional)"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Ninguno" agregar="cliente" @change="elegirCliente"></Buscador></Field>
        <Field label="Grupo o evento"><input v-model="form.grupo" maxlength="60"></Field>
        <Field label="Segmento"><select v-model="form.segmento"><option value="">— Sin segmento —</option><option v-for="s in segs" :key="s" :value="s">{{s}}</option></select></Field>
        <Field label="Moneda de la cuenta"><select v-model="form.moneda"><option v-for="m in MONEDAS_HOTEL" :key="m[0]" :value="m[0]">{{m[1]}} ({{m[0]}})</option></select></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="160"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Abrir cuenta</button></template>
    </Modal>
  </div>`,
};
