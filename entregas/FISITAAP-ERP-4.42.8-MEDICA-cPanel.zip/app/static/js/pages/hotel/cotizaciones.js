// Hotel › Cotizaciones (3.22): precio de una estadía para alguien que todavía no reserva. Se calcula con las mismas
// tarifas, temporadas, planes y reglas de precio de las reservas; queda numerada (COT-0001) con fecha de vencimiento,
// se manda por WhatsApp y, cuando la persona acepta, se convierte en reserva con los datos ya puestos.
// Registro `hotel_cotizaciones`.
import { toast, money, fecha, hoy, sumarDias, mock, siguienteNumero } from '../../api.js';
import { sesion } from '../../app.js';
import { config, hotelActivo, categorias, nombreCat, cotizar, cotizaciones, reservas, noches, enlaceWhatsApp, usuarioActual, capacidadCat, disponibles } from './_datos.js';

export default {
  props: ['params'],
  data() { return { cfg: config(), lista: cotizaciones(), form: null, filtro: 'vigentes', activo: hotelActivo(), cats: categorias() }; },
  computed: {
    puedeEscribir() { return ['escribir', 'pos', 'cobros', 'facturar'].some(p => sesion.puede(p)); },
    reservadas() { const m = {}; for (const r of reservas()) if (r.cotizacion_id) m[r.cotizacion_id] = r; return m; },
    filas() {
      const h = hoy();
      return this.lista.map(q => { const r = this.reservadas[q.id]; const estado = r ? 'reservada' : q.estado === 'descartada' ? 'descartada' : (q.vence && q.vence < h ? 'vencida' : 'vigente'); return { ...q, estado, reserva: r, noches: noches(q.llegada, q.salida) }; })
        .filter(q => this.filtro === 'todas' || (this.filtro === 'vigentes' ? q.estado === 'vigente' : q.estado === this.filtro))
        .sort((a, b) => b.id - a.id);
    },
    cot() { const f = this.form; if (!f || !f.categoria_id || !f.llegada || !f.salida || f.salida <= f.llegada) return null; return cotizar({ categoria_id: f.categoria_id, llegada: f.llegada, salida: f.salida, plan_id: f.plan_id, personas: (+f.adultos || 0) + (+f.ninos || 0), precio_manual: f.precio_manual === '' || f.precio_manual === null ? null : f.precio_manual, capacidad: capacidadCat(f.categoria_id) }, this.cfg); },
    dispForm() { const f = this.form; return f && f.categoria_id && f.llegada && f.salida > f.llegada ? disponibles(f.categoria_id, f.llegada, f.salida, null).length : null; },
  },
  methods: {
    fecha, money, nombreCat,
    nuevo() { const h = hoy(); this.form = { id: null, nombre: '', telefono: '', correo: '', categoria_id: this.cats.length === 1 ? this.cats[0].id : null, llegada: h, salida: sumarDias(h, 1), adultos: 2, ninos: 0, plan_id: (this.cfg.planes[0] || {}).id || 1, precio_manual: null, notas: '', vence: sumarDias(h, +this.cfg.cotizacion_vigencia_dias || 7) }; },
    editar(q) { this.form = { ...q }; },
    guardar() {
      const f = this.form, c = this.cot;
      if (!(f.nombre || '').trim()) return toast('Escriba el nombre de la persona', 'err');
      if (!c) return toast('Elija la categoría y las fechas', 'err');
      if (!mock.puedeGuardar()) return;
      this.lista = mock.actualizar('hotel_cotizaciones', l => {
        const lista = Array.isArray(l) ? l : [];
        const reg = { ...f, nombre: f.nombre.trim(), total: c.total, neto: c.neto, iva: c.iva, promedio: c.promedio, moneda: c.moneda, detalle: c.detalle, larga: c.larga ? { noches: c.larga.noches, descuento: c.larga.descuento } : null };
        if (reg.id) return lista.map(x => (x.id === reg.id ? { ...reg, actualizado: new Date().toISOString() } : x));
        return [...lista, { ...reg, id: mock.nextId(lista, 'hotel_cotizaciones'), numero: 'COT-' + String(siguienteNumero(lista, 'numero', 'COT-', 1)).padStart(4, '0'), fecha: hoy(), estado: 'enviada', creado: new Date().toISOString(), usuario: usuarioActual() }];
      }, []);
      this.form = null; toast('Cotización guardada', 'ok');
    },
    texto(q) {
      const plan = (this.cfg.planes || []).find(p => p.id === q.plan_id);
      return 'Hola ' + q.nombre + ', le escribe ' + (this.cfg.nombre || 'el hotel') + '. Cotización ' + q.numero + ':\n' + nombreCat(q.categoria_id) + ' del ' + fecha(q.llegada) + ' al ' + fecha(q.salida) + ' (' + noches(q.llegada, q.salida) + ' noche(s), ' + ((+q.adultos || 0) + (+q.ninos || 0)) + ' persona(s))' + (plan ? ' · ' + plan.nombre : '') + '\nTotal: ' + money(q.total, q.moneda) + (this.cfg.precios_incluyen_iva ? ' con IVA' : ' más IVA') + ' (' + money(q.promedio, q.moneda) + ' por noche)' + (q.larga ? ' · incluye ' + q.larga.descuento + ' % de descuento por larga estadía' : '') + '\nVálida hasta el ' + fecha(q.vence) + '. ¿La reservamos a su nombre?';
    },
    whatsapp(q) { window.open(enlaceWhatsApp(q.telefono, this.texto(q)), '_blank', 'noopener'); },
    copiar(q) { navigator.clipboard?.writeText(this.texto(q)).then(() => toast('Texto copiado', 'ok')); },
    reservar(q) { location.hash = '#/hotel/reservaciones/nueva?cot=' + q.id; },
    marcar(q, estado) { if (!mock.puedeGuardar()) return; this.lista = mock.actualizar('hotel_cotizaciones', l => (l || []).map(x => (x.id === q.id ? { ...x, estado } : x)), []); },
    quitar(q) { if (!confirm('¿Eliminar la cotización ' + q.numero + '?')) return; if (!mock.puedeGuardar()) return; this.lista = mock.actualizar('hotel_cotizaciones', l => (l || []).filter(x => x.id !== q.id), []); },
  },
  template: `
  <div class="page">
    <PageHead title="Cotizaciones" :sub="activo ? filas.length + ' cotización(es) en este filtro' : 'Configure primero el hotel.'" :crumbs="[{label:'Hotel'},{label:'Reservaciones'},{label:'Cotizaciones'}]">
      <button class="btn" @click="nuevo" v-if="puedeEscribir && activo">+ Nueva cotización</button>
    </PageHead>
    <div class="card" v-if="!activo"><Empty icon="🛏" title="El hotel no está configurado"></Empty></div>
    <template v-else>
      <div class="seg" style="margin-bottom:10px"><button :class="{on: filtro==='vigentes'}" @click="filtro='vigentes'">Vigentes</button><button :class="{on: filtro==='reservada'}" @click="filtro='reservada'">Reservadas</button><button :class="{on: filtro==='vencida'}" @click="filtro='vencida'">Vencidas</button><button :class="{on: filtro==='todas'}" @click="filtro='todas'">Todas</button></div>
      <Empty v-if="!filas.length" icon="🧾" title="Sin cotizaciones" text="Cotice una estadía con las tarifas del hotel y mándela por WhatsApp; cuando acepten, se convierte en reserva."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Cotización</th><th>Persona</th><th>Estadía</th><th class="num">Total</th><th>Válida hasta</th><th>Estado</th><th></th></tr></thead><tbody>
        <tr v-for="q in filas" :key="q.id">
          <td><b>{{q.numero}}</b><div class="small muted">{{fecha(q.fecha)}}</div></td>
          <td>{{q.nombre}}<div class="small muted">{{q.telefono || '—'}}</div></td>
          <td>{{nombreCat(q.categoria_id)}} · {{fecha(q.llegada)}} al {{fecha(q.salida)}}<div class="small muted">{{q.noches}} noche(s) · {{(+q.adultos||0) + (+q.ninos||0)}} persona(s){{q.larga ? ' · ' + q.larga.descuento + ' % larga estadía' : ''}}</div></td>
          <td class="num"><b>{{money(q.total, q.moneda)}}</b><div class="small muted">{{money(q.promedio, q.moneda)}} por noche</div></td>
          <td>{{q.vence ? fecha(q.vence) : '—'}}</td>
          <td><span class="badge" :class="q.estado==='reservada' ? 'ok' : q.estado==='vigente' ? 'info' : q.estado==='vencida' ? 'warn' : ''">{{q.estado==='reservada' ? 'Reservada ' + q.reserva.numero : q.estado==='vigente' ? 'Vigente' : q.estado==='vencida' ? 'Vencida' : 'Descartada'}}</span></td>
          <td class="num" style="white-space:nowrap">
            <button class="btn sm sec" v-if="q.telefono" @click="whatsapp(q)">WhatsApp</button><button class="btn sm ghost" @click="copiar(q)" title="Copiar el texto para correo">Copiar</button>
            <button class="btn sm" v-if="puedeEscribir && q.estado!=='reservada'" @click="reservar(q)">Convertir en reserva</button>
            <button class="btn sm ghost" v-if="puedeEscribir && q.estado==='vigente'" @click="editar(q)">Editar</button>
            <button class="btn sm ghost" v-if="puedeEscribir && q.estado==='vigente'" @click="marcar(q,'descartada')">Descartar</button>
            <button class="btn icon" v-if="puedeEscribir" @click="quitar(q)" title="Eliminar">✕</button>
          </td>
        </tr></tbody></table></div>
    </template>
    <Modal v-if="form" :title="form.id ? 'Cotización ' + (form.numero || '') : 'Nueva cotización'" lg @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="80"></Field>
        <Field label="Teléfono (WhatsApp)"><input v-model="form.telefono" maxlength="20" placeholder="8888-8888"></Field>
        <Field label="Correo"><input type="email" v-model="form.correo" maxlength="120"></Field>
        <Field label="Válida hasta"><input type="date" v-model="form.vence"></Field>
        <Field label="Categoría" req :help="dispForm === null ? '' : dispForm + ' habitación(es) libre(s) en esas fechas'"><select v-model="form.categoria_id"><option :value="null">— Elegir —</option><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
        <Field label="Plan"><select v-model="form.plan_id"><option v-for="p in cfg.planes" :key="p.id" :value="p.id">{{p.nombre}}{{p.pct ? ' (' + (p.pct > 0 ? '+' : '') + p.pct + ' %)' : ''}}</option></select></Field>
        <Field label="Llegada" req><input type="date" v-model="form.llegada"></Field>
        <Field label="Salida" req><input type="date" v-model="form.salida" :min="form.llegada"></Field>
        <Field label="Adultos"><input type="number" min="1" max="30" v-model.number="form.adultos"></Field>
        <Field label="Niños"><input type="number" min="0" max="30" v-model.number="form.ninos"></Field>
        <Field label="Precio por noche negociado" :help="'Vacío = tarifa del hotel con temporadas y reglas de precio, en ' + cfg.moneda"><input type="number" min="0" step="0.01" v-model.number="form.precio_manual"></Field>
        <Field label="Notas"><input v-model="form.notas" maxlength="160"></Field>
      </div>
      <div class="card" v-if="cot" style="padding:10px;margin-top:8px">
        <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><b>{{cot.noches}} noche(s) · {{money(cot.promedio, cot.moneda)}} por noche</b><b style="font-size:18px">{{money(cot.total, cot.moneda)}} <small class="muted">{{cfg.precios_incluyen_iva ? 'con IVA' : 'más IVA'}}</small></b></div>
        <div class="small muted" style="margin-top:4px">{{cot.detalle.map(d => fecha(d.fecha) + ' ' + money(d.precio, cot.moneda) + (d.temporada ? ' (' + d.temporada + ')' : '')).join(' · ')}}</div>
        <div class="small" v-if="cot.larga" style="margin-top:4px">Incluye {{cot.larga.descuento}} % de descuento por larga estadía ({{cot.larga.noches}} noches o más).</div>
        <div class="small" v-if="cot.extra_personas" style="margin-top:4px">Incluye {{money(cot.extra_personas, cot.moneda)}} por noche de persona(s) extra.</div>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar cotización</button></template>
    </Modal>
  </div>`,
};
