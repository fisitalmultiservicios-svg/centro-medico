// Hotel › Habitaciones y tarifas: datos del hotel, categorías de habitación, habitaciones por rango de números, temporadas con
// rangos de fechas, tabla de precios por categoría × temporada, planes y políticas. Todo lo configura el propio hotel.
import { api, toast, money, fmt, hoy, monedas, mock, CAT } from '../../api.js';
import { sesion } from '../../app.js';
import { config, guardarConfig, categorias, todasHabitaciones, ordenHab, CABYS_HOSPEDAJE, ESTADOS_HAB, nombreEstadoHab, reservas, ocupa, usuarioActual, rangoPersonasCat, descripcionHab, tcBaseHotel, tcVentaHotel, tcCompraHotel, SEGMENTOS_BASE, TIPOS_CARGO_AUTO, PAQUETE_CIERRE, paqueteCierre, fechaHotelReg, fijarFechaHotel } from './_datos.js';

export default {
  props: ['params'],
  data() {
    const DIAS_SEMANA = [[1, 'Lun'], [2, 'Mar'], [3, 'Mié'], [4, 'Jue'], [5, 'Vie'], [6, 'Sáb'], [0, 'Dom']];
    return { DIAS_SEMANA,  cfg: config(), cats: categorias(), habs: todasHabitaciones(), tab: this.params.tab || 'hotel', guardando: false, bodegas: [], monedasOpc: monedas.opciones(), tarifas: CAT.tarifaIvaLista,
      catForm: null, rango: { categoria_id: null, desde: '', hasta: '', piso: '', prefijo: '', personas: 2, camas: '1 cama matrimonial', sofa_cama: false }, habForm: null, cabysBusca: '', cabysRes: [], ESTADOS_HAB, editarMensaje: false,
      enlaces: [], diario: mock.get('hotel_diario', null), corriendo: false, importando: false, TIPOS_CARGO_AUTO,
      segTexto: (Array.isArray(config().segmentos) && config().segmentos.length ? config().segmentos : SEGMENTOS_BASE).join(', ') };
  },
  computed: {
    esLocal() { return !!sesion.empresaInfo?.es_local; },   // 4.14
    catsItems() { return [...new Set((mock.get('categorias', []) || []).map(c => c && c.nombre).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es')); },   // categorías de ítems (minibar, 3.22)
    tcEmpresa() { return +monedas.tc('USD') || 0; },   // un solo tipo de cambio (3.20)
    puede() { return sesion.puede('configurar'); },
    habsOrdenadas() { return this.habs.slice().sort(ordenHab); },
    porCategoria() { const m = {}; for (const h of this.habs) if (h.activa !== false) m[h.categoria_id] = (m[h.categoria_id] || 0) + 1; return m; },
    numerosPorCategoria() { const m = {}; for (const h of this.habsOrdenadas) if (h.activa !== false) (m[h.categoria_id] = m[h.categoria_id] || []).push(h.numero); return m; },
    listo() { return this.cats.length > 0 && this.habs.some(h => h.activa !== false) && Object.keys(this.cfg.tarifas || {}).length > 0; },
    ocupadasHoy() { const h = hoy(); return new Set(reservas().filter(r => ocupa(r) && r.llegada <= h && h < r.salida).map(r => r.habitacion_id)); },
  },
  methods: {
    paqueteOpciones() { return PAQUETE_CIERRE; },   /* 3.60 */
    enPaquete(k) { return paqueteCierre(this.cfg).includes(k); },
    alternarPaquete(k) { const cur = paqueteCierre(this.cfg); this.cfg.paquete_cierre = cur.includes(k) ? cur.filter(x => x !== k) : [...cur, k]; },
    tcBaseHotel, tcVentaHotel, tcCompraHotel,
    money, fmt, nombreEstadoHab, rangoPersonasCat, descripcionHab,
    tarifa(catId, tempId) { const t = this.cfg.tarifas[String(catId)]; return t ? t[String(tempId)] : undefined; },
    ponerTarifa(catId, tempId, v) { if (!this.cfg.tarifas[String(catId)]) this.cfg.tarifas[String(catId)] = {}; this.cfg.tarifas[String(catId)][String(tempId)] = v === '' || v === null ? '' : +v; },
    // ---- categorías ----
    nuevaCat() { this.catForm = { id: null, nombre: '', personas: 2, camas: '1 cama matrimonial', descripcion: '', orden: this.cats.length + 1 }; },
    editarCat(c) { this.catForm = { ...c }; },
    guardarCat() {
      const f = this.catForm; if (!(f.nombre || '').trim()) return toast('Indique el nombre de la categoría', 'err');
      if (this.cats.some(c => c.id !== f.id && c.nombre.trim().toLowerCase() === f.nombre.trim().toLowerCase())) return toast('Ya existe una categoría con ese nombre', 'err');
      this.cats = mock.actualizar('hotel_categorias', l => { const lista = Array.isArray(l) ? l : []; const reg = { ...f, nombre: f.nombre.trim(), personas: Math.max(1, +f.personas || 1), id: f.id || mock.nextId(lista, 'hotel_categorias') }; const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); return lista; }, []);
      if (!this.rango.categoria_id) this.rango.categoria_id = this.cats[this.cats.length - 1].id;
      this.catForm = null; toast('Categoría guardada', 'ok');
    },
    eliminarCat(c) {
      if (this.habs.some(h => h.categoria_id === c.id)) return toast('Primero mueva o elimine las habitaciones de «' + c.nombre + '»', 'err');
      if (!confirm('¿Eliminar la categoría «' + c.nombre + '»?')) return;
      this.cats = mock.actualizar('hotel_categorias', l => (l || []).filter(x => x.id !== c.id), []); delete this.cfg.tarifas[String(c.id)];
    },
    // ---- habitaciones por rango ----
    crearRango() {
      const r = this.rango; if (!r.categoria_id) return toast('Elija la categoría', 'err');
      const a = parseInt(r.desde, 10), b = parseInt(r.hasta || r.desde, 10);
      if (isNaN(a) || isNaN(b) || b < a || b - a > 500) return toast('Indique el rango de números (por ejemplo 101 a 112)', 'err');
      const existentes = new Set(this.habs.map(h => String(h.numero)));
      const nuevos = []; for (let n = a; n <= b; n++) { const num = (r.prefijo || '') + n; if (!existentes.has(num)) nuevos.push(num); }
      if (!nuevos.length) return toast('Esos números ya existen', 'err');
      this.habs = mock.actualizar('hotel_habitaciones', l => { const lista = Array.isArray(l) ? l : []; let id = mock.nextId(lista, 'hotel_habitaciones'); for (const num of nuevos) lista.push({ id: id++, numero: num, categoria_id: r.categoria_id, piso: (r.piso || '').trim() || (num.length >= 3 ? num[0] : ''), personas: Math.max(1, +r.personas || 2), camas: (r.camas || '').trim(), sofa_cama: !!r.sofa_cama, vista: '', estado: 'limpia', notas: '', activa: true }); return lista; }, []);
      toast(nuevos.length + ' habitación(es) creada(s): ' + nuevos.slice(0, 6).join(', ') + (nuevos.length > 6 ? '…' : ''), 'ok'); this.rango.desde = ''; this.rango.hasta = '';
    },
    editarHab(h) { this.habForm = { ...h }; },
    guardarHab() {
      const f = this.habForm; if (!String(f.numero || '').trim()) return toast('Indique el número', 'err');
      if (this.habs.some(h => h.id !== f.id && String(h.numero) === String(f.numero).trim())) return toast('Ya existe la habitación ' + f.numero, 'err');
      this.habs = mock.actualizar('hotel_habitaciones', l => (l || []).map(x => (x.id === f.id ? { ...x, ...f, numero: String(f.numero).trim(), estado_hora: x.estado !== f.estado ? new Date().toISOString() : x.estado_hora, estado_usuario: x.estado !== f.estado ? usuarioActual() : x.estado_usuario } : x)), []);
      this.habForm = null; toast('Habitación guardada', 'ok');
    },
    eliminarHab(h) {
      if (reservas().some(r => r.habitacion_id === h.id && ocupa(r))) return toast('La habitación ' + h.numero + ' tiene reservas vigentes: desactívela en vez de eliminarla', 'err');
      if (!confirm('¿Eliminar la habitación ' + h.numero + '?')) return;
      this.habs = mock.actualizar('hotel_habitaciones', l => (l || []).filter(x => x.id !== h.id), []); this.habForm = null;
    },
    // ---- temporadas ----
    nuevaTemporada() { const id = Math.max(0, ...this.cfg.temporadas.map(t => +t.id || 0)) + 1; this.cfg.temporadas.push({ id, nombre: 'Temporada ' + id, rangos: [{ desde: '', hasta: '' }] }); },
    quitarTemporada(t) { if (!confirm('¿Quitar la temporada «' + t.nombre + '» y sus precios?')) return; this.cfg.temporadas = this.cfg.temporadas.filter(x => x.id !== t.id); for (const k of Object.keys(this.cfg.tarifas)) delete this.cfg.tarifas[k][String(t.id)]; },
    nuevoPlan() { const id = Math.max(0, ...this.cfg.planes.map(p => +p.id || 0)) + 1; this.cfg.planes.push({ id, nombre: 'Plan ' + id, pct: 0 }); },
    // ---- CABYS ----
    async buscarCabys() { const q = this.cabysBusca.trim(); if (q.length < 3) return; try { this.cabysRes = (await api('/api/hacienda/cabys?q=' + encodeURIComponent(q))).slice(0, 12); } catch (e) { toast(e.message, 'err'); } },
    elegirCabys(c) { this.cfg.cabys_hospedaje = c.codigo; this.cabysRes = []; this.cabysBusca = ''; if (c.impuesto !== undefined && c.impuesto !== null) { const pct = +c.impuesto <= 1 ? Math.round(+c.impuesto * 100) : +c.impuesto; this.cfg.tarifa_iva = pct; const cod = Object.entries(CAT.tarifaPct).find(([, v]) => v === pct); if (cod) this.cfg.codigo_tarifa = cod[0]; } },
    tarifaCambio() { this.cfg.tarifa_iva = CAT.tarifaPct[this.cfg.codigo_tarifa] ?? 13; },
    // ---- guardar ----
    async guardar() {
      const c = this.cfg;
      if (!(c.nombre || '').trim()) return toast('Indique el nombre del hotel', 'err');
      for (const t of c.temporadas) { if (!(t.nombre || '').trim()) return toast('Cada temporada necesita un nombre', 'err'); t.rangos = (t.rangos || []).filter(r => r.desde || r.hasta); for (const r of t.rangos) if (!r.desde || !r.hasta || r.hasta < r.desde) return toast('Temporada «' + t.nombre + '»: revise las fechas (desde y hasta)', 'err'); }
      for (const p of c.planes) { if (!(p.nombre || '').trim()) return toast('Cada plan necesita un nombre', 'err'); p.pct = +p.pct || 0; }
      c.adelanto_pct = Math.min(100, Math.max(0, +c.adelanto_pct || 0)); c.persona_extra = +c.persona_extra || 0; c.tarifa_iva = +c.tarifa_iva || 0;
      c.no_show_dias = Math.min(7, Math.max(1, +c.no_show_dias || 1)); c.recordatorio_adelanto_dias = Math.min(60, Math.max(1, +c.recordatorio_adelanto_dias || 7)); c.recordatorio_llegada_dias = Math.min(30, Math.max(1, +c.recordatorio_llegada_dias || 1));
      if (!/^\d{13}$/.test(String(c.cabys_hospedaje || ''))) c.cabys_hospedaje = CABYS_HOSPEDAJE;
      c.prefijo = (c.prefijo || 'R-').trim().slice(0, 6);
      c.segmentos = String(this.segTexto || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 20); if (!c.segmentos.length) c.segmentos = SEGMENTOS_BASE.slice();
      c.finde_pct = +c.finde_pct || 0; c.finde_dias = (c.finde_dias || []).map(Number).filter(d => d >= 0 && d <= 6);
      c.ocupacion_reglas = (c.ocupacion_reglas || []).filter(x => +x.pct_desde > 0 && +x.recargo).map(x => ({ pct_desde: +x.pct_desde, recargo: +x.recargo }));
      c.larga_reglas = (c.larga_reglas || []).filter(x => +x.noches > 1 && +x.descuento > 0).map(x => ({ noches: +x.noches, descuento: +x.descuento }));
      c.min_noches = Math.max(1, Math.min(30, +c.min_noches || 1)); for (const tp of c.temporadas) tp.min_noches = +tp.min_noches > 1 ? Math.min(30, +tp.min_noches) : 0;
      c.cargos_auto = (c.cargos_auto || []).filter(a => (a.nombre || '').trim()).map(a => ({ ...a, nombre: a.nombre.trim(), precio: +a.precio || 0, plan_id: a.plan_id || null }));
      for (const k of Object.keys(c.tarifas)) for (const kk of Object.keys(c.tarifas[k])) { const v = c.tarifas[k][kk]; if (v === '' || v === null || isNaN(+v)) delete c.tarifas[k][kk]; else c.tarifas[k][kk] = +v; }
      this.guardando = true;
      if (c.fecha_hotel && !fechaHotelReg()) fijarFechaHotel(hoy(), 'Activación de la fecha del hotel');   // 3.62
      const ok = await guardarConfig(c);
      this.guardando = false;
      if (ok) toast(c.activo ? 'Configuración del hotel guardada' : 'Guardado. Marque «Hotel activo» para que el módulo aparezca en el menú de todos los usuarios', 'ok');
    },
    activarYGuardar() { this.cfg.activo = true; this.guardar(); },
    // cargos automáticos y ajuste masivo de precios (3.0)
    nuevoCargoAuto() { const l = this.cfg.cargos_auto || (this.cfg.cargos_auto = []); l.push({ id: (l.reduce((m, a) => Math.max(m, +a.id || 0), 0) + 1), nombre: '', tipo: 'noche', precio: 0, plan_id: null, codigo_tarifa: '', cabys: '', activo: true }); },
    ajustarTarifas() {
      const s = prompt('Porcentaje de ajuste para TODOS los precios por noche (por ejemplo 5 o -10):'); if (s === null) return; const pct = +String(s).replace(',', '.'); if (!isFinite(pct) || !pct) return toast('Indique un porcentaje distinto de cero', 'err');
      let n = 0; for (const k of Object.keys(this.cfg.tarifas)) for (const kk of Object.keys(this.cfg.tarifas[k])) { const v = +this.cfg.tarifas[k][kk]; if (isFinite(v) && v > 0) { this.cfg.tarifas[k][kk] = Math.round(v * (1 + pct / 100) * 100) / 100; n++; } }
      toast(n + ' precio(s) ajustado(s) un ' + pct + ' %. Revise y guarde.', 'ok');
    },
    // ---- tareas automáticas e iCal (2.3) ----
    async cargarEnlaces() { try { this.enlaces = await api('/api/hotel/ical/enlaces'); } catch (e) { toast(e.message, 'err'); } },
    copiar(t) { navigator.clipboard?.writeText(t).then(() => toast('Enlace copiado', 'ok')); },
    agregarIcal() { if (!this.habForm.ical_urls) this.habForm.ical_urls = []; this.habForm.ical_urls.push({ nombre: 'Booking', url: '' }); },
    async ejecutarDiario() {
      if (!confirm('Se corren ahora las tareas automáticas: leer calendarios iCal, enviar recordatorios, marcar no presentados y cargar salidas tardías según lo configurado. ¿Continuar?')) return;
      this.corriendo = true;
      try { const r = await api('/api/hotel/diario', { method: 'POST' }); await mock.refrescar(['hotel_reservas', 'hotel_folios', 'hotel_diario']); this.diario = mock.get('hotel_diario', null); const s = r.resumen || {}; toast('Tareas ejecutadas: ' + Object.entries(s).filter(x => x[1]).map(x => x[0].replace(/_/g, ' ') + ' ' + x[1]).join(', ') + (r.avisos && r.avisos.length ? ' · ' + r.avisos.length + ' aviso(s)' : '') || 'sin novedades', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.corriendo = false;
    },
    async importarIcal() {
      this.importando = true;
      try { const r = await api('/api/hotel/ical/importar', { method: 'POST' }); await mock.refrescar(['hotel_reservas']); toast(r.fuentes ? r.fuentes + ' calendario(s) leído(s): ' + r.creados + ' nuevos, ' + r.actualizados + ' cambiados, ' + r.quitados + ' quitados' : 'Ninguna habitación tiene calendarios iCal configurados', r.avisos && r.avisos.length ? 'err' : 'ok'); for (const a of (r.avisos || []).slice(0, 5)) toast(a, 'err'); }
      catch (e) { toast(e.message, 'err'); }
      this.importando = false;
    },
  },
  watch: { tab(v) { if (v === 'automatico' && !this.enlaces.length) this.cargarEnlaces(); } },
  async created() { if (this.tab === 'automatico') this.cargarEnlaces(); try { this.bodegas = await api('/api/inventario/bodegas'); if (!this.cfg.bodega_id) this.cfg.bodega_id = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null; } catch {} if (this.cats.length && !this.rango.categoria_id) this.rango.categoria_id = this.cats[0].id; },
  template: `
  <div class="page">
    <PageHead title="Habitaciones y tarifas" sub="Configure su hotel: categorías, habitaciones por rango de números, temporadas, precios por categoría y temporada, planes y políticas." :crumbs="[{label:'Hotel'},{label:'Habitaciones y tarifas'}]">
      <a class="btn ghost" href="#/hotel/reservaciones" v-if="cfg.activo">Ir a Reservaciones</a>
      <button class="btn" :disabled="guardando || !puede" @click="guardar">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </PageHead>
    <div class="alert warn" v-if="!puede">Su rol puede ver esta configuración, pero solo un Administrador de la empresa la cambia.</div>
    <div class="alert info" v-else-if="!cfg.activo">Pasos: 1) datos del hotel, 2) categorías, 3) habitaciones por rango, 4) temporadas y precios. Al terminar, marque <b>Hotel activo</b> y guarde: Recepción, Reservaciones y Calendario aparecen en el menú.</div>
    <div class="tabs"><button :class="{on: tab==='hotel'}" @click="tab='hotel'">Datos del hotel</button><button :class="{on: tab==='categorias'}" @click="tab='categorias'">Categorías ({{cats.length}})</button><button :class="{on: tab==='habitaciones'}" @click="tab='habitaciones'">Habitaciones ({{habs.filter(h=>h.activa!==false).length}})</button><button :class="{on: tab==='tarifas'}" @click="tab='tarifas'">Temporadas y precios</button><button :class="{on: tab==='politicas'}" @click="tab='politicas'">Políticas y mensajes</button><button :class="{on: tab==='automatico'}" @click="tab='automatico'">Automático e iCal</button></div>

    <div v-if="tab==='automatico'">
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Tareas automáticas <small>una vez al día, de madrugada</small></h2>
        <div class="alert info" style="margin-bottom:10px" v-if="esLocal"><b>Requiere internet.</b> Esta tarea automática corre solo en la nube: en este programa no se ejecuta. Configúrelo en la página web.</div>
          <div style="display:flex;flex-direction:column;gap:10px">
            <div><Toggle v-model="cfg.no_show_auto" label="Marcar como no presentada la reserva que no llegó"></Toggle><div class="row" style="gap:6px;margin:4px 0 0 44px" v-if="cfg.no_show_auto"><span class="small muted">después de</span><input type="number" class="inp" min="1" max="7" v-model.number="cfg.no_show_dias" style="width:70px;padding:4px 6px"><span class="small muted">día(s) de la llegada prevista (la habitación queda libre)</span></div></div>
            <div><Toggle v-model="cfg.salida_tardia_auto" label="Cargar las noches de más cuando el huésped no salió en la fecha prevista"></Toggle><div class="small muted" style="margin:2px 0 0 44px">Se agrega el hospedaje de cada noche extra a su cuenta y la salida se corre a hoy.</div></div>
            <div><Toggle v-model="cfg.recordatorio_adelanto" label="Recordar por correo el adelanto pendiente"></Toggle><div class="row" style="gap:6px;margin:4px 0 0 44px" v-if="cfg.recordatorio_adelanto"><span class="small muted">cuando falten</span><input type="number" class="inp" min="1" max="60" v-model.number="cfg.recordatorio_adelanto_dias" style="width:70px;padding:4px 6px"><span class="small muted">días o menos para la llegada (una sola vez por reserva)</span></div></div>
            <div><Toggle v-model="cfg.recordatorio_llegada" label="Enviar por correo el recordatorio de llegada"></Toggle><div class="row" style="gap:6px;margin:4px 0 0 44px" v-if="cfg.recordatorio_llegada"><input type="number" class="inp" min="1" max="30" v-model.number="cfg.recordatorio_llegada_dias" style="width:70px;padding:4px 6px"><span class="small muted">día(s) antes de la llegada (reservas confirmadas con correo)</span></div></div>
            <div><Toggle v-model="cfg.ical_auto" label="Leer cada día los calendarios iCal de Booking y Airbnb"></Toggle></div>
          </div>
          <p class="small muted" style="margin:12px 0 0">Los correos salen con el correo saliente de la empresa (Configuración › Empresa). Lo hecho queda en el historial de cada reserva y en la auditoría.</p>
          <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn sec" @click="ejecutarDiario" :disabled="corriendo || !puede">{{corriendo ? 'Ejecutando…' : 'Ejecutar ahora'}}</button><span class="small muted" v-if="diario && diario.fecha">Última pasada: {{diario.fecha.split('-').reverse().join('/')}}{{diario.hora ? ' ' + diario.hora.slice(11, 16) : ''}}<span v-if="diario.resumen"> · {{Object.entries(diario.resumen).filter(x => x[1]).map(x => x[0].replace(/_/g, ' ') + ' ' + x[1]).join(', ') || 'sin novedades'}}</span></span></div>
          <div class="alert warn" style="margin:10px 0 0" v-if="diario && diario.avisos && diario.avisos.length"><b>Avisos de la última pasada:</b><div v-for="(a, i) in diario.avisos" :key="i" class="small">{{a}}</div></div>
        </div>
        <div class="card"><h2>Mensajes de los recordatorios</h2>
          <Field label="Adelanto pendiente" help="Campos: {huesped} {numero} {hotel} {llegada} {salida} {total} {adelanto} {politicas}"><textarea rows="5" v-model="cfg.mensaje_recordatorio_adelanto" :disabled="!puede"></textarea></Field>
          <Field label="Recordatorio de llegada" style="margin-top:10px" help="Campos: {huesped} {numero} {hotel} {llegada} {hora_entrada} {categoria} {noches} {wifi}"><textarea rows="5" v-model="cfg.mensaje_recordatorio_llegada" :disabled="!puede"></textarea></Field>
        </div>
      </div>
      <div class="alert info" style="margin-bottom:10px" v-if="esLocal"><b>Requiere internet.</b> La lectura de los calendarios iCal corre solo en la nube: en este programa no se ejecuta. Configúrelo en la página web.</div><div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:8px"><h2 style="margin:0">Calendarios iCal con Booking y Airbnb <small>bloquean las fechas en los dos sentidos</small></h2><button class="btn sm sec" @click="importarIcal" :disabled="importando">{{importando ? 'Leyendo…' : 'Leer calendarios ahora'}}</button></div>
        <p class="small muted" style="margin:0 0 10px"><b>Exportar:</b> copie el enlace de cada habitación y péguelo en Booking (Extranet › Calendario › Sincronizar calendarios) o Airbnb (Disponibilidad › Importar calendario): las noches reservadas aquí se cierran allá. <b>Importar:</b> abra cada habitación en la pestaña Habitaciones y pegue el enlace iCal que le dan Booking o Airbnb; sus reservas llegan aquí como bloqueos de esa habitación (cada día y con el botón). Si una fecha importada choca con una reserva propia, se avisa y no se bloquea.</p>
        <div class="table-wrap" v-if="enlaces.length"><table class="tbl"><thead><tr><th>Habitación</th><th>Enlace para exportar (pegar en Booking / Airbnb)</th><th>Calendarios que importa</th><th></th></tr></thead>
          <tbody><tr v-for="x in enlaces" :key="x.id"><td><b>{{x.numero}}</b></td><td class="mono small" style="white-space:normal;word-break:break-all">{{x.url}}</td><td class="small">{{((habs.find(h => h.id === x.id) || {}).ical_urls || []).filter(u => u.url).map(u => u.nombre).join(', ') || '—'}}</td><td><div class="acts"><button class="btn sm ghost" @click="copiar(x.url)">Copiar</button><button class="btn sm ghost" @click="editarHab(habs.find(h => h.id === x.id))">Importar…</button></div></td></tr></tbody></table></div>
        <p class="small muted" v-else>Cree las habitaciones para ver sus enlaces.</p>
      </div>
    </div>

    <div v-if="tab==='hotel'" class="grid cols-2" style="align-items:start">
      <div class="card"><h2>Hotel</h2>
        <div class="grid">
          <Field label="Nombre del hotel" req help="Como lo ve el huésped en confirmaciones y tarjetas"><input v-model="cfg.nombre" maxlength="80" placeholder="Hotel Playa Serena"></Field>
          <Field label="Teléfono o WhatsApp de recepción" help="8 dígitos"><input v-model="cfg.telefono" maxlength="12"></Field>
          <Field label="Hora de entrada (check-in)"><input type="time" v-model="cfg.hora_entrada"></Field>
          <Field label="Hora de salida (check-out)"><input type="time" v-model="cfg.hora_salida"></Field>
          <Field label="Moneda de las tarifas y de la cuenta del huésped" req help="La factura se emite en esta moneda; los consumos del restaurante en colones se convierten con el tipo de cambio del día"><select v-model="cfg.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
          <Field label="Tipo de cambio" help="El mismo de toda la empresa (Configuración › Monedas): la venta del BCCR del día o el manual que ahí se indique. Los márgenes de abajo se aplican encima."><input :value="tcEmpresa ? '₡' + fmt(tcEmpresa, 2) + ' por dólar' : 'Sin tipo de cambio: actualícelo en Configuración › Monedas'" disabled></Field>
          <Field label=" "><a class="btn sm sec" href="#/configuracion?tab=monedas">Configuración › Monedas</a></Field>
          <Field label="Margen al recibir colones en una cuenta en dólares (%)" help="Protección cambiaria: el dólar se cobra más caro"><input type="number" min="0" max="20" step="0.5" v-model.number="cfg.margen_venta"></Field>
          <Field label="Margen al recibir dólares en una cuenta en colones (%)" help="El dólar se recibe más barato"><input type="number" min="0" max="20" step="0.5" v-model.number="cfg.margen_compra"></Field>
          <div class="alert info" style="grid-column:1/-1;margin:0">Hoy: tipo de cambio base <b>{{fmt(tcBaseHotel(cfg), 2)}}</b> · si pagan en colones una cuenta en dólares, cada dólar se cobra a <b>₡{{fmt(tcVentaHotel(cfg), 2)}}</b> · si pagan en dólares una cuenta en colones, cada dólar se recibe a <b>₡{{fmt(tcCompraHotel(cfg), 2)}}</b>. Los consumos del restaurante se pasan a la cuenta al tipo de cambio base.</div>
          <Field label="Prefijo de las reservas" help="Por ejemplo R-0001"><input v-model="cfg.prefijo" maxlength="6"></Field>
          <Field label="Estancia mínima general (noches)" help="Cada temporada puede exigir más"><input type="number" min="1" max="30" v-model.number="cfg.min_noches"></Field>
          <Field label="Segmentos de mercado" help="Separados por coma; se eligen en cada reserva y salen en los reportes" style="grid-column:1/-1"><input v-model="segTexto" maxlength="300"></Field>
          <Field label="Adelanto requerido (%)" help="Porcentaje del total para confirmar la reserva; 0 = no se pide"><input type="number" min="0" max="100" v-model.number="cfg.adelanto_pct"></Field>
          <Field label="Liberar la reserva si el adelanto no llega (días)" help="Las reservas pendientes de adelanto se cancelan solas pasados estos días desde que se crearon y la habitación queda libre; 0 = nunca (solo el recordatorio)"><input type="number" min="0" max="60" v-model.number="cfg.adelanto_plazo_dias"></Field>
          <Field label="Correo del cierre del día" help="Al cerrar el día se envía el resumen (ocupación, cargos, pagos, ADR, pendientes) a esta dirección; vacío = no se envía"><input type="email" v-model="cfg.correo_cierre" maxlength="120"></Field>
          <Field label="Paquete de reportes del cierre del día" help="Al cerrar el día se genera un PDF con estos reportes: queda guardado junto al cierre, se descarga cuando quiera y va adjunto al correo del cierre. Sin ninguno marcado, el PDF lleva solo el resumen" style="grid-column:1/-1"><div class="row" style="gap:4px 16px;flex-wrap:wrap"><label v-for="p in paqueteOpciones()" :key="p[0]" class="row" style="gap:5px;cursor:pointer;align-items:center"><input type="checkbox" :checked="enPaquete(p[0])" @change="alternarPaquete(p[0])" :disabled="!puede"> {{p[1]}}</label></div></Field>
          <Field label="Fecha del hotel (auditoría nocturna)" style="grid-column:1/-1"><Toggle v-model="cfg.fecha_hotel" label="La fecha de trabajo del hotel avanza solo al cerrar el día"></Toggle><div class="small muted">Con esto, lo que pase después de medianoche y antes del cierre (llegadas tardías, consumos del bar, pagos) sigue perteneciendo al día que todavía no se ha cerrado. Recepción, Reservaciones, Cierre del día, las tareas automáticas y los reportes trabajan con esa fecha. Al activarla se pone en la fecha de hoy; al reabrir un día, vuelve a ese día.</div></Field>
          <Field label="Bloquear cargos en días cerrados"><Toggle v-model="cfg.bloquear_cerrados" label="Solo quien configura puede registrar cargos con fecha de un día ya cerrado"></Toggle></Field>
          <Field label="Tope de la cuenta del huésped" :help="'Al cargar un consumo desde la caja se avisa cuando la cuenta supera este monto en ' + (cfg.moneda || 'USD') + '; 0 = sin aviso'"><input type="number" min="0" step="1" v-model.number="cfg.tope_cuenta"></Field>
          <Field label="Persona adicional por noche" :help="'Cargo por cada persona sobre la capacidad de la categoría, en ' + cfg.moneda"><input type="number" min="0" step="0.01" v-model.number="cfg.persona_extra"></Field>
          <Field label="Categoría de ítems del minibar" help="Con ella, la camarera carga el consumo del minibar a la cuenta desde su celular (Tablero de habitaciones)"><select v-model="cfg.minibar_categoria" :disabled="!puede"><option value="">— Sin minibar desde el celular —</option><option v-for="c in catsItems" :key="c" :value="c">{{c}}</option></select></Field>
          <Field label="Bodega para los consumos" help="De donde se descuentan los cargos del restaurante o minibar al facturar"><Buscador v-model="cfg.bodega_id" :opciones="bodegas" placeholder="La principal" agregar="bodega"></Buscador></Field>
        </div>
        <div style="margin-top:14px;display:flex;flex-direction:column;gap:8px">
          <Toggle v-model="cfg.activo" label="Hotel activo: Recepción, Reservaciones, Calendario, Huéspedes y Reportes visibles para todos los usuarios"></Toggle>
        </div>
      </div>
      <div class="card"><h2>Impuestos del hospedaje <small>cómo se factura la noche</small></h2>
        <div class="grid">
          <Field label="IVA del hospedaje" req><select v-model="cfg.codigo_tarifa" @change="tarifaCambio"><option v-for="t in tarifas" :key="t.value" :value="t.value">{{t.label}}</option></select></Field>
          <Field label="CABYS del hospedaje" req help="6311100000000 = alojamiento en habitaciones con limpieza (hoteles)"><input class="mono" v-model="cfg.cabys_hospedaje" maxlength="13"></Field>
        </div>
        <div class="row" style="margin-top:8px;gap:6px"><input class="inp" style="flex:1" v-model="cabysBusca" placeholder="Buscar otro CABYS (alojamiento, cabinas, campamento…)" @keyup.enter="buscarCabys"><button class="btn sm sec" @click="buscarCabys">Buscar</button></div>
        <div v-if="cabysRes.length" class="card" style="padding:6px;margin:6px 0 0;max-height:200px;overflow:auto"><div v-for="c in cabysRes" :key="c.codigo" class="row" style="padding:5px 8px;cursor:pointer;gap:8px" @click="elegirCabys(c)"><span class="mono">{{c.codigo}}</span><span class="small">{{c.descripcion}}</span><span class="badge" style="margin-left:auto">{{c.impuesto}}</span></div></div>
        <div style="margin-top:14px"><Toggle v-model="cfg.precios_incluyen_iva" label="Los precios por noche incluyen el IVA (lo habitual en hotelería)"></Toggle></div>
        <p class="small muted" style="margin:10px 0 0">Los extras cobrables (lavandería, tours, minibar, traslados, late check-out) se crean como ítems de venta en Inventario › Ítems y se cargan a la cuenta del huésped desde Recepción o desde la caja del restaurante («Cargo a habitación»).</p>
      </div>
    </div>

    <div v-if="tab==='categorias'">
      <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Categorías de habitación</h2><button class="btn sm" @click="nuevaCat" :disabled="!puede">+ Nueva categoría</button></div>
        <Empty v-if="!cats.length" icon="🛏" title="Sin categorías" text="Cree las categorías de su hotel (Estándar, Superior, Deluxe, Familiar, Dormitorio…). Las camas, las personas y el sofá cama se definen en cada habitación."></Empty>
        <div class="cfg" v-else>
          <div class="cat" v-for="c in cats" :key="c.id"><div class="row" style="justify-content:space-between"><b>{{c.nombre}}</b><span class="badge">{{porCategoria[c.id] || 0}} hab.</span></div>
            <div class="r">{{rangoPersonasCat(c.id) || 'sin habitaciones todavía'}} · camas según cada habitación</div><div class="small muted" v-if="c.descripcion">{{c.descripcion}}</div>
            <div class="nums"><span v-for="n in (numerosPorCategoria[c.id] || [])" :key="n">{{n}}</span></div>
            <div class="row" style="gap:4px;margin-top:8px"><button class="btn sm ghost" @click="editarCat(c)" :disabled="!puede">Editar</button><button class="btn icon" @click="eliminarCat(c)" :disabled="!puede" title="Eliminar">🗑</button></div>
          </div>
        </div>
      </div>
    </div>

    <div v-if="tab==='habitaciones'" class="grid cols-2" style="align-items:start">
      <div class="card"><h2>Crear habitaciones por rango</h2>
        <p class="small muted">Indique la categoría y el rango de números: se crean todas de una vez (por ejemplo 401 a 404). Luego puede editar una a una.</p>
        <div class="grid">
          <Field label="Categoría" req><select v-model="rango.categoria_id"><option :value="null">— Elegir —</option><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
          <Field label="Piso o zona" help="Vacío = el primer dígito del número"><input v-model="rango.piso" maxlength="20" placeholder="1, 2, Villas…"></Field>
          <Field label="Del número" req><input v-model="rango.desde" inputmode="numeric" placeholder="401"></Field>
          <Field label="Al número" help="Vacío = una sola"><input v-model="rango.hasta" inputmode="numeric" placeholder="404"></Field>
          <Field label="Prefijo" help="Opcional: V para V1, V2…"><input v-model="rango.prefijo" maxlength="4"></Field>
          <Field label="Personas" help="Se puede cambiar en cada habitación"><input type="number" min="1" max="30" v-model.number="rango.personas"></Field>
          <Field label="Camas"><input v-model="rango.camas" maxlength="60"></Field>
        </div>
        <div style="margin-top:10px"><Toggle v-model="rango.sofa_cama" label="Tienen sofá cama"></Toggle></div>
        <div class="row" style="margin-top:10px"><button class="btn" @click="crearRango" :disabled="!puede || !cats.length">Crear habitaciones</button></div>
        <p class="small muted" style="margin:8px 0 0" v-if="!cats.length">Primero cree las categorías.</p>
      </div>
      <div class="card"><h2>Habitaciones <small>{{habs.filter(h=>h.activa!==false).length}} activas</small></h2>
        <Empty v-if="!habs.length" icon="🚪" title="Sin habitaciones" text="Créelas por rango a la izquierda."></Empty>
        <div class="hk" v-else style="grid-template-columns:repeat(auto-fill,minmax(88px,1fr))">
          <div v-for="h in habsOrdenadas" :key="h.id" class="h" :class="[h.estado || 'limpia', {inactiva: h.activa===false}]" @click="editarHab(h)" style="cursor:pointer" :title="'Editar ' + h.numero"><b>{{h.numero}}</b><span>{{(cats.find(c=>c.id===h.categoria_id)||{}).nombre || '—'}}</span><span class="small muted">{{descripcionHab(h) || '—'}}</span><span class="small muted" v-if="h.activa===false">inactiva</span></div>
        </div>
      </div>
    </div>

    <div v-if="tab==='tarifas'">
      <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Temporadas <small>rangos de fechas; fuera de ellas rige la tarifa base</small></h2><button class="btn sm sec" @click="nuevaTemporada" :disabled="!puede">+ Temporada</button></div>
        <p class="small muted" v-if="!cfg.temporadas.length">Sin temporadas: se cobra la tarifa base todo el año. Agregue por ejemplo «Alta» (15 dic – 15 abr) o «Semana Santa».</p>
        <div class="temp" v-if="cfg.temporadas.length" style="grid-template-columns:repeat(auto-fill,minmax(260px,1fr))">
          <div v-for="t in cfg.temporadas" :key="t.id"><div class="row" style="gap:6px"><input class="inp" v-model="t.nombre" maxlength="30" style="flex:1;font-weight:600"><button class="btn icon" @click="quitarTemporada(t)" :disabled="!puede">🗑</button></div>
            <div v-for="(r, i) in t.rangos" :key="i" class="row" style="gap:4px;margin-top:6px;flex-wrap:nowrap"><input type="date" class="inp" v-model="r.desde" style="flex:1;min-width:0"><span class="muted small">a</span><input type="date" class="inp" v-model="r.hasta" style="flex:1;min-width:0"><button class="btn icon" @click="t.rangos.splice(i,1)" v-if="t.rangos.length>1">✕</button></div>
            <a class="link small" style="cursor:pointer;display:inline-block;margin-top:6px" @click="t.rangos.push({desde:'',hasta:''})">+ Otro rango de fechas</a>
            <div class="row small" style="gap:6px;margin-top:6px;align-items:center"><span class="muted">Estancia mínima</span><input type="number" class="inp" min="0" max="30" v-model.number="t.min_noches" style="width:70px;padding:3px 6px" :disabled="!puede" placeholder="0"><span class="muted">noches (0 = la general)</span></div></div>
        </div>
      </div>
      <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:6px"><h2 style="margin:0">Precio por noche <small>por categoría y temporada, en {{cfg.moneda}}{{cfg.precios_incluyen_iva ? ' (IVA incluido)' : ' (sin IVA)'}}</small></h2><button class="btn sm sec" @click="ajustarTarifas" :disabled="!puede" title="Sube o baja todos los precios un porcentaje">Ajustar todos ±%</button></div>
        <Empty v-if="!cats.length" icon="💲" title="Sin categorías" text="Cree las categorías para definir sus precios."></Empty>
        <div class="table-wrap" v-else><table class="tbl tarifas"><thead><tr><th>Categoría</th><th class="num">Tarifa base</th><th class="num" v-for="t in cfg.temporadas" :key="t.id">{{t.nombre}}</th></tr></thead>
          <tbody><tr v-for="c in cats" :key="c.id"><td><b>{{c.nombre}}</b><div class="small muted">{{rangoPersonasCat(c.id) || '—'}} · {{porCategoria[c.id] || 0}} hab.</div></td>
            <td class="num"><input type="number" min="0" step="0.01" :value="tarifa(c.id,'base')" @input="ponerTarifa(c.id,'base',$event.target.value)" :disabled="!puede"></td>
            <td class="num" v-for="t in cfg.temporadas" :key="t.id"><input type="number" min="0" step="0.01" :value="tarifa(c.id,t.id)" @input="ponerTarifa(c.id,t.id,$event.target.value)" :disabled="!puede" :placeholder="tarifa(c.id,'base') !== undefined && tarifa(c.id,'base') !== '' ? String(tarifa(c.id,'base')) : ''"></td></tr></tbody></table></div>
        <p class="small muted" style="margin:8px 0 0">Una celda de temporada vacía usa la tarifa base. El precio de cada noche se calcula según la temporada en que cae; la reserva muestra el detalle noche por noche.</p>
      </div>
      <div class="card"><h2 style="margin:0 0 4px">Reglas de precio <small>se aplican sobre la tarifa de la noche; no tocan los contratos de agencias ni los precios negociados</small></h2>
        <div class="grid cols-2" style="margin-top:8px">
          <Field label="Recargo de fin de semana (%)" help="0 = sin recargo; negativo = descuento"><input type="number" step="1" min="-90" max="300" v-model.number="cfg.finde_pct" :disabled="!puede"></Field>
          <Field label="Días del fin de semana"><div class="row" style="gap:10px;flex-wrap:wrap;padding-top:6px"><label class="row small" style="gap:4px;cursor:pointer" v-for="d in DIAS_SEMANA" :key="d[0]"><input type="checkbox" :value="d[0]" v-model="cfg.finde_dias" :disabled="!puede"> {{d[1]}}</label></div></Field>
        </div>
        <div class="grid cols-2" style="margin-top:6px">
          <div><div class="row" style="justify-content:space-between"><b class="small">Por ocupación del día</b><button class="btn sm ghost" @click="cfg.ocupacion_reglas.push({pct_desde: 80, recargo: 10})" :disabled="!puede">+ Regla</button></div>
            <p class="small muted" v-if="!cfg.ocupacion_reglas.length" style="margin:4px 0">Ej.: con 80 % o más de ocupación, +15 %.</p>
            <div class="row" v-for="(x, i) in cfg.ocupacion_reglas" :key="i" style="gap:6px;align-items:center;margin-top:4px;flex-wrap:nowrap"><span class="small">Desde</span><input type="number" class="inp" min="1" max="100" v-model.number="x.pct_desde" style="width:70px" :disabled="!puede"><span class="small">% de ocupación:</span><input type="number" class="inp" step="1" min="-90" max="300" v-model.number="x.recargo" style="width:70px" :disabled="!puede"><span class="small">%</span><button class="btn icon" @click="cfg.ocupacion_reglas.splice(i, 1)" :disabled="!puede">✕</button></div></div>
          <div><div class="row" style="justify-content:space-between"><b class="small">Por larga estadía</b><button class="btn sm ghost" @click="cfg.larga_reglas.push({noches: 7, descuento: 10})" :disabled="!puede">+ Regla</button></div>
            <p class="small muted" v-if="!cfg.larga_reglas.length" style="margin:4px 0">Ej.: 7 noches o más, −10 %; 28 o más, −25 %.</p>
            <div class="row" v-for="(x, i) in cfg.larga_reglas" :key="i" style="gap:6px;align-items:center;margin-top:4px;flex-wrap:nowrap"><input type="number" class="inp" min="2" max="365" v-model.number="x.noches" style="width:70px" :disabled="!puede"><span class="small">noches o más: −</span><input type="number" class="inp" min="1" max="90" v-model.number="x.descuento" style="width:70px" :disabled="!puede"><span class="small">%</span><button class="btn icon" @click="cfg.larga_reglas.splice(i, 1)" :disabled="!puede">✕</button></div></div>
        </div>
        <p class="small muted" style="margin:8px 0 0">La cotización y la reserva muestran qué regla aplicó en cada noche. Con varias reglas de ocupación manda la de mayor porcentaje alcanzado; con varias de larga estadía, la de más noches.</p>
      </div>
      <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Planes <small>recargo o descuento sobre la tarifa</small></h2><button class="btn sm sec" @click="nuevoPlan" :disabled="!puede">+ Plan</button></div>
        <table class="tbl"><thead><tr><th>Plan</th><th class="num">% sobre la tarifa</th><th></th></tr></thead><tbody><tr v-for="(p, i) in cfg.planes" :key="p.id"><td><input class="inp" v-model="p.nombre" maxlength="40" style="width:100%" :disabled="!puede"></td><td class="num"><input class="inp" type="number" step="0.5" v-model.number="p.pct" style="width:110px;text-align:right" :disabled="!puede"></td><td><button class="btn icon" @click="cfg.planes.splice(i,1)" v-if="cfg.planes.length>1" :disabled="!puede">✕</button></td></tr></tbody></table>
        <p class="small muted" style="margin:8px 0 0">Ejemplos: «Con desayuno» +10 %, «Corporativo» −15 %, «Agencia» −20 %.</p>
      </div>
      <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Cargos automáticos <small>se cargan solos a la cuenta al hacer el check-in</small></h2><button class="btn sm sec" @click="nuevoCargoAuto" :disabled="!puede">+ Cargo automático</button></div>
        <p class="small muted" v-if="!(cfg.cargos_auto || []).length" style="margin:0">Ejemplos: desayuno por persona y noche, parqueo por noche, impuesto turístico por estadía. Se pueden limitar a un plan.</p>
        <table class="tbl" v-else><thead><tr><th>Nombre</th><th>Cómo se cobra</th><th class="num">Precio ({{cfg.moneda}}{{cfg.precios_incluyen_iva ? ', IVA incl.' : ''}})</th><th>Solo con el plan</th><th>IVA</th><th>Activo</th><th></th></tr></thead>
          <tbody><tr v-for="(a, i) in cfg.cargos_auto" :key="a.id"><td><input class="inp" v-model="a.nombre" maxlength="60" style="width:100%" placeholder="Desayuno" :disabled="!puede"></td><td><select class="inp" v-model="a.tipo" :disabled="!puede"><option v-for="x in TIPOS_CARGO_AUTO" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></td><td class="num"><input class="inp" type="number" min="0" step="0.01" v-model.number="a.precio" style="width:110px;text-align:right" :disabled="!puede"></td><td><select class="inp" v-model="a.plan_id" :disabled="!puede"><option :value="null">Todos los planes</option><option v-for="p in cfg.planes" :key="p.id" :value="p.id">{{p.nombre}}</option></select></td><td><select class="inp" v-model="a.codigo_tarifa" :disabled="!puede"><option value="">El del hospedaje</option><option v-for="t in tarifas" :key="t.value" :value="t.value">{{t.label}}</option></select></td><td><input type="checkbox" v-model="a.activo" :disabled="!puede"></td><td><button class="btn icon" @click="cfg.cargos_auto.splice(i,1)" :disabled="!puede">✕</button></td></tr></tbody></table>
        <p class="small muted" style="margin:8px 0 0">Los cargos automáticos se agregan a la cuenta junto con las noches (al hacer el check-in, al extender o acortar) y se facturan al salir. Para un ítem con CABYS propio, créelo en Inventario › Ítems y cárguelo a mano.</p>
      </div>
    </div>

    <div v-if="tab==='politicas'" class="grid cols-2" style="align-items:start">
      <div class="card"><h2>Políticas</h2>
        <Field label="Políticas de reserva, cancelación y no presentación" help="Se imprimen en la tarjeta de registro y van en la confirmación"><textarea rows="6" v-model="cfg.politicas" :disabled="!puede"></textarea></Field>
        <Field label="Wifi y datos útiles para el huésped" help="Red y clave del wifi, horarios del desayuno…" style="margin-top:10px"><textarea rows="3" v-model="cfg.wifi" :disabled="!puede"></textarea></Field>
        <Field label="WhatsApp antes de la llegada" help="Botón «Pre-llegada» en la reserva. Campos: {huesped} {numero} {hotel} {llegada} {salida} {hora_entrada} {categoria} {noches} {wifi}" style="margin-top:10px"><textarea rows="4" v-model="cfg.mensaje_prellegada" :disabled="!puede"></textarea></Field>
        <Field label="WhatsApp al salir" help="Botón «WhatsApp de salida» en Recepción tras el check-out; {enlace} es el comprobante para consultar o descargar" style="margin-top:10px"><textarea rows="4" v-model="cfg.mensaje_salida" :disabled="!puede"></textarea></Field>
      </div>
      <div class="card"><h2>Mensaje de confirmación <small>correo y WhatsApp</small></h2>
        <Field label="Texto" help="Campos que se reemplazan: {huesped} {numero} {hotel} {llegada} {salida} {hora_entrada} {hora_salida} {categoria} {habitacion} {noches} {personas} {total} {adelanto} {politicas} {wifi}"><textarea rows="12" v-model="cfg.mensaje_confirmacion" :disabled="!puede"></textarea></Field>
      </div>
    </div>

    <Modal v-if="catForm" :title="catForm.id ? 'Editar categoría' : 'Nueva categoría'" @close="catForm=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="catForm.nombre" maxlength="40" placeholder="Superior, Deluxe, Familiar…"></Field>
        <Field label="Orden en listas"><input type="number" min="1" v-model.number="catForm.orden"></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea rows="2" v-model="catForm.descripcion" placeholder="Vista al jardín, balcón, aire acondicionado…"></textarea></Field>
      </div>
      <p class="small muted" style="margin:10px 0 0">La categoría agrupa habitaciones con el mismo precio. Las camas, la cantidad de personas y el sofá cama se definen en cada habitación, porque dentro de una misma categoría pueden variar.</p>
      <template #foot><button class="btn ghost" @click="catForm=null">Cancelar</button><button class="btn" @click="guardarCat">Guardar</button></template>
    </Modal>
    <Modal v-if="habForm" :title="'Habitación ' + habForm.numero" @close="habForm=null">
      <div class="grid cols-2">
        <Field label="Número" req><input v-model="habForm.numero" maxlength="10"></Field>
        <Field label="Categoría" req><select v-model="habForm.categoria_id"><option v-for="c in cats" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
        <Field label="Piso o zona"><input v-model="habForm.piso" maxlength="20"></Field>
        <Field label="Personas (capacidad)" req><input type="number" min="1" max="30" v-model.number="habForm.personas"></Field>
        <Field label="Camas"><input v-model="habForm.camas" maxlength="60" placeholder="1 king, 2 individuales, 3 literas…"></Field>
        <Field label="Vista o extras"><input v-model="habForm.vista" maxlength="80" placeholder="Vista al mar, balcón, jacuzzi…"></Field>
        <Field label="Estado de limpieza"><select v-model="habForm.estado"><option v-for="e in ESTADOS_HAB" :key="e[0]" :value="e[0]">{{e[1]}}</option></select></Field>
        <Field label="Notas" style="grid-column:1/-1"><textarea rows="2" v-model="habForm.notas" placeholder="Cuna disponible, vista al mar, aire ruidoso…"></textarea></Field>
      </div>
      <div style="margin-top:10px;display:flex;flex-direction:column;gap:8px"><Toggle v-model="habForm.sofa_cama" label="Tiene sofá cama"></Toggle><Toggle v-model="habForm.activa" label="Activa (se puede reservar)"></Toggle></div>
      <div style="margin-top:14px"><div class="row" style="justify-content:space-between"><b class="small">Calendarios iCal que importa esta habitación</b><button class="btn sm ghost" @click="agregarIcal">+ Agregar</button></div>
        <div v-for="(u, i) in (habForm.ical_urls || [])" :key="i" class="row" style="gap:6px;margin-top:6px;flex-wrap:nowrap"><input class="inp" v-model="u.nombre" maxlength="30" placeholder="Booking" style="width:110px"><input class="inp" v-model="u.url" placeholder="https://…/export.ics" style="flex:1;min-width:0"><button class="btn icon" @click="habForm.ical_urls.splice(i,1)">✕</button></div>
        <p class="small muted" style="margin:6px 0 0">Pegue el enlace de exportación que da Booking o Airbnb para esta habitación. Sus reservas llegan como bloqueos cada día (o con «Leer calendarios ahora» en Automático e iCal).</p></div>
      <template #foot><button class="btn danger" @click="eliminarHab(habForm)">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="habForm=null">Cancelar</button><button class="btn" @click="guardarHab">Guardar</button></template>
    </Modal>
  </div>`,
};
