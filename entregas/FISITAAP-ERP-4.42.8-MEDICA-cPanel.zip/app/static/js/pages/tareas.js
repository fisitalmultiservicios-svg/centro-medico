// Mis tareas — lista y tablero kanban. Registro 'tareas' guardado en el servidor por empresa (mock.get/set); semilla solo en modo demo.
import { api, mock, toast, fecha, hoy, sumarDias } from '../api.js';
import { sesion } from '../app.js';

const ESTADOS = ['Próximas', 'En progreso', 'Hecho', 'Archivados'];
const PRIORIDADES = ['Alta', 'Media', 'Baja'];
const RESPONSABLES = ['María Fernández', 'Carlos Jiménez', 'Ana Rodríguez'];   // solo para la semilla de ejemplo; los reales salen de los usuarios de la empresa (R269)
const en = (n) => sumarDias(hoy(), n);   // hora de Costa Rica (R258)

const SEMILLA = [
  { id: 1, titulo: 'Presentar declaración D-104 de IVA', descripcion: 'Declaración mensual ante Hacienda (vence el 15).', fecha: en(5), responsable: 'María Fernández', prioridad: 'Alta', estado: 'Próximas' },
  { id: 2, titulo: 'Llamar a Distribuidora La Paz por factura vencida', descripcion: 'Factura FE-5720, 45 días de atraso.', fecha: en(1), responsable: 'Carlos Jiménez', prioridad: 'Alta', estado: 'En progreso' },
  { id: 3, titulo: 'Conciliar cuenta Banco Nacional CRC', descripcion: 'Movimientos de setiembre.', fecha: en(3), responsable: 'Norman Pérez', prioridad: 'Media', estado: 'En progreso' },
  { id: 4, titulo: 'Actualizar lista de precios 2026', descripcion: 'Aplicar aumento del 4 % en servicios.', fecha: en(12), responsable: 'Ana Rodríguez', prioridad: 'Baja', estado: 'Próximas' },
  { id: 5, titulo: 'Renovar póliza de riesgos del trabajo (INS)', descripcion: '', fecha: en(-2), responsable: 'Norman Pérez', prioridad: 'Media', estado: 'Hecho' },
  { id: 6, titulo: 'Enviar estados de cuenta a clientes de crédito', descripcion: 'Cierre de mes.', fecha: en(-20), responsable: 'María Fernández', prioridad: 'Baja', estado: 'Archivados' },
];
const SUGERIDAS = [
  { titulo: 'Enviar facturas pendientes a Hacienda', descripcion: 'Hay comprobantes firmados sin enviar.', prioridad: 'Alta' },
  { titulo: 'Cargar certificado de producción', descripcion: 'Suba la llave criptográfica .p12 del ambiente de producción.', prioridad: 'Media' },
  { titulo: 'Revisar cuentas por cobrar vencidas', descripcion: 'Facturas con más de 30 días sin pago.', prioridad: 'Alta' },
];
const vacia = () => ({ id: null, titulo: '', descripcion: '', fecha: hoy(), responsable: sesion.usuario?.nombre || '', prioridad: 'Media', estado: 'Próximas' });

export default {
  props: ['params'],
  data() {
    const tareas = mock.ejemplos('tareas', SEMILLA, 'titulo');   // se guarda solo al crear, editar o eliminar (R70)
    return { tareas, vista: 'lista', q: '', filtro: false, fPrioridad: '', fResponsable: '', soloMias: !!(sesion.usuario && sesion.usuario.nombre) && !(() => { try { return localStorage.getItem('tareas:todas') === '1'; } catch { return false; } })(), modal: false, form: vacia(), cerrados: {}, ESTADOS, PRIORIDADES, responsables: [sesion.usuario?.nombre || ''].filter(Boolean) };
  },
  computed: {
    filtradas() {
      const q = this.q.trim().toLowerCase();
      const yo = String(sesion.usuario?.nombre || '').trim().toLowerCase(), correo = String(sesion.usuario?.correo || '').trim().toLowerCase();
      return this.tareas.filter(t => (!q || (t.titulo + ' ' + t.descripcion + ' ' + t.responsable).toLowerCase().includes(q)) && (!this.fPrioridad || t.prioridad === this.fPrioridad) && (!this.fResponsable || t.responsable === this.fResponsable)
        && (!this.soloMias || !t.responsable || [yo, correo].includes(String(t.responsable).trim().toLowerCase())));
    },
    grupos() { return ESTADOS.map(e => ({ estado: e, items: this.filtradas.filter(t => t.estado === e).sort((a, b) => a.fecha.localeCompare(b.fecha)) })); },
  },
  // responsables: los usuarios de la empresa (si el rol puede verlos) más los que ya aparecen en tareas (R269)
  async created() { try { const us = await api('/api/auth/usuarios'); const n = (Array.isArray(us) ? us : us.usuarios || []).map(u => u.nombre || u.correo).filter(Boolean); this.responsables = [...new Set([...n, ...this.responsables])]; } catch {} this.responsables = [...new Set([...this.responsables, ...this.tareas.map(t => t.responsable).filter(Boolean)])]; },
  watch: { soloMias(v) { try { localStorage.setItem('tareas:todas', v ? '0' : '1'); } catch {} } },
  methods: {
    fecha,
    // 3.87: el registro «tareas» lo guarda quien tiene «escribir» (Solo lectura y los roles de solo cobros no). Los avisos salen cuando el
    // servidor confirma; si lo rechaza, la lista vuelve a lo guardado (antes decía «guardada» y la fila rechazada seguía en pantalla)
    guardarTodo() { return mock.set('tareas', this.tareas).then(ok => { if (!ok) this.tareas = mock.ejemplos('tareas', SEMILLA, 'titulo'); return ok; }); },
    nueva() { this.form = vacia(); this.modal = true; },
    editar(t) { this.form = { ...t }; this.modal = true; },
    guardar() {
      if (!this.form.titulo.trim()) return toast('El título es obligatorio', 'err');
      if (this.form.id) { const i = this.tareas.findIndex(t => t.id === this.form.id); this.tareas.splice(i, 1, { ...this.form }); }
      else this.tareas.push({ ...this.form, id: mock.nextId(this.tareas, 'tareas') });
      this.modal = false; this.guardarTodo().then(ok => ok && toast('Tarea guardada', 'ok'));
    },
    eliminar(t) { if (!confirm('¿Eliminar la tarea "' + t.titulo + '"?')) return; this.tareas.splice(this.tareas.indexOf(t), 1); this.guardarTodo().then(ok => ok && toast('Tarea eliminada')); },
    mover(t, dir) { const i = ESTADOS.indexOf(t.estado) + dir; if (i < 0 || i >= ESTADOS.length) return; t.estado = ESTADOS[i]; this.guardarTodo(); },
    cambiarEstado(t, e) { t.estado = e; this.guardarTodo(); },
    sugerir() {
      let n = 0;
      for (const s of SUGERIDAS) { if (this.tareas.some(t => t.titulo === s.titulo)) continue; this.tareas.push({ ...s, id: mock.nextId(this.tareas, 'tareas'), fecha: en(7), responsable: sesion.usuario?.nombre || '', estado: 'Próximas' }); n++; }
      if (!n) return toast('Las tareas sugeridas ya están en su lista');
      this.guardarTodo().then(ok => ok && toast(n + ' tarea(s) sugerida(s) agregada(s)', 'ok'));
    },
    vencida(t) { return t.fecha < hoy() && t.estado !== 'Hecho' && t.estado !== 'Archivados'; },
    badgePrio(p) { return { Alta: 'danger', Media: 'warn', Baja: 'info' }[p] || ''; },
    toggleGrupo(e) { this.cerrados[e] = !this.cerrados[e]; },
  },
  template: `
  <div class="page">
    <PageHead title="Mis tareas" sub="Organice los pendientes de su equipo y no deje pasar ninguna fecha. Las tareas son de la empresa: cada persona ve las suyas o todas.">
      <button class="btn ghost" v-if="puede('escribir')" @click="sugerir">✦ Tareas sugeridas</button>
      <button class="btn" v-if="puede('escribir')" @click="nueva">+ Nueva tarea</button>
    </PageHead>

    <div class="toolbar">
      <div class="seg"><button :class="{on: vista==='lista'}" @click="vista='lista'">Lista</button><button :class="{on: vista==='tablero'}" @click="vista='tablero'">Tablero</button></div>
      <div class="seg"><button :class="{on: soloMias}" @click="soloMias=true">Mis tareas</button><button :class="{on: !soloMias}" @click="soloMias=false">Todas</button></div>
      <input class="search" placeholder="Buscar tarea o responsable" v-model="q">
      <button class="btn ghost sm" @click="filtro=!filtro">⚲ Filtrar</button>
      <template v-if="filtro">
        <select class="inp" v-model="fPrioridad"><option value="">Toda prioridad</option><option v-for="p in PRIORIDADES" :key="p">{{p}}</option></select>
        <select class="inp" v-model="fResponsable"><option value="">Todo responsable</option><option v-for="r in responsables" :key="r">{{r}}</option></select>
        <button class="btn icon" @click="fPrioridad='';fResponsable=''" title="Limpiar filtros">✕</button>
      </template>
      <span class="muted small" style="margin-left:auto">Las tareas archivadas se conservan hasta que las elimine.</span>
    </div>

    <!-- Vista lista: grupos colapsables por estado -->
    <template v-if="vista==='lista'">
      <div class="card pad0" v-for="g in grupos" :key="g.estado">
        <div class="row" style="padding:12px 16px;cursor:pointer;user-select:none" @click="toggleGrupo(g.estado)">
          <span class="muted">{{cerrados[g.estado] ? '▸' : '▾'}}</span><h2 style="margin:0">{{g.estado}}</h2><span class="badge primary">{{g.items.length}}</span>
        </div>
        <div class="table-wrap" v-show="!cerrados[g.estado]">
          <table class="tbl" v-if="g.items.length">
            <thead><tr><th>Título</th><th>Fecha de entrega</th><th>Responsable</th><th>Prioridad</th><th>Estado</th><th></th></tr></thead>
            <tbody>
              <tr v-for="t in g.items" :key="t.id">
                <td><a class="link" @click="editar(t)">{{t.titulo}}</a><div class="small muted" v-if="t.descripcion">{{t.descripcion}}</div></td>
                <td :class="{muted: !vencida(t)}" :style="vencida(t)?'color:var(--danger);font-weight:600':''">{{fecha(t.fecha)}}<span v-if="vencida(t)" class="small"> · vencida</span></td>
                <td>{{t.responsable}}</td>
                <td><span class="badge" :class="badgePrio(t.prioridad)">{{t.prioridad}}</span></td>
                <td><select class="inp" :value="t.estado" :disabled="!puede('escribir')" @change="cambiarEstado(t, $event.target.value)"><option v-for="e in ESTADOS" :key="e">{{e}}</option></select></td>
                <td><div class="acts" v-if="puede('escribir')"><button class="btn icon" @click="editar(t)" title="Editar">✎</button><button class="btn icon" @click="eliminar(t)" title="Eliminar">🗑</button></div></td>
              </tr>
            </tbody>
          </table>
          <p class="muted small" v-else style="padding:0 16px 14px">Sin tareas en este grupo.</p>
        </div>
      </div>
    </template>

    <!-- Vista tablero (kanban) -->
    <div v-else class="grid" style="grid-template-columns:repeat(4,1fr);align-items:start">
      <div class="card pad0" v-for="(g,gi) in grupos" :key="g.estado">
        <div class="row" style="padding:12px 14px;border-bottom:1px solid var(--line)"><h2 style="margin:0">{{g.estado}}</h2><span class="badge primary">{{g.items.length}}</span></div>
        <div style="padding:10px;display:flex;flex-direction:column;gap:8px;min-height:80px">
          <div class="card" v-for="t in g.items" :key="t.id" style="margin:0;padding:12px 14px">
            <div class="row" style="justify-content:space-between;align-items:flex-start"><b style="font-size:13.5px;cursor:pointer" @click="editar(t)">{{t.titulo}}</b><span class="badge" :class="badgePrio(t.prioridad)">{{t.prioridad}}</span></div>
            <div class="small muted" style="margin-top:4px">{{t.responsable}} · <span :style="vencida(t)?'color:var(--danger)':''">{{fecha(t.fecha)}}</span></div>
            <div class="row" style="justify-content:space-between;margin-top:8px">
              <button class="btn icon" :disabled="gi===0 || !puede('escribir')" @click="mover(t,-1)" title="Mover a la columna anterior">←</button>
              <button class="btn icon" v-if="puede('escribir')" @click="eliminar(t)" title="Eliminar">🗑</button>
              <button class="btn icon" :disabled="gi===ESTADOS.length-1 || !puede('escribir')" @click="mover(t,1)" title="Mover a la siguiente columna">→</button>
            </div>
          </div>
          <p class="muted small" v-if="!g.items.length" style="text-align:center;margin:20px 0">Sin tareas</p>
        </div>
      </div>
    </div>

    <Modal v-if="modal" :title="!puede('escribir') ? 'Tarea' : form.id ? 'Editar tarea' : 'Nueva tarea'" @close="modal=false">
      <div class="grid cols-2">
        <Field label="Título" req style="grid-column:1/-1"><input v-model="form.titulo" placeholder="Ej.: Presentar declaración de IVA"></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea v-model="form.descripcion" rows="3"></textarea></Field>
        <Field label="Fecha de entrega"><input type="date" v-model="form.fecha"></Field>
        <Field label="Responsable"><select v-model="form.responsable"><option v-for="r in responsables" :key="r">{{r}}</option></select></Field>
        <Field label="Prioridad"><select v-model="form.prioridad"><option v-for="p in PRIORIDADES" :key="p">{{p}}</option></select></Field>
        <Field label="Estado"><select v-model="form.estado"><option v-for="e in ESTADOS" :key="e">{{e}}</option></select></Field>
      </div>
      <template #foot><button class="btn sec" @click="modal=false">{{puede('escribir') ? 'Cancelar' : 'Cerrar'}}</button><button class="btn" v-if="puede('escribir')" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};
