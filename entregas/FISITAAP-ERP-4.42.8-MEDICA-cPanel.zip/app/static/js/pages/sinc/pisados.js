// 4.32 (B7): «Cambios que no quedaron». Lista, solo para leer, de lo que alguien escribió y no quedó porque otro cambio llegó antes
// (GET /api/sinc/datos/pisados) y, en el programa, de los datos que no subieron solos (GET /api/sinc/datos/choques).
// Quien quiera su valor lo vuelve a escribir: aquí no hay «Restaurar». «Marcar como vistos» solo apaga el aviso de la franja.
// Todo se pinta con {{ }}: nada de lo que viene del servidor se interpreta como HTML. Un 404 (interruptor apagado) se ignora en silencio.
import { api, toast, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';

export const TEXTO_SOLO_LEER = 'Esta lista es solo para leer: si quiere su valor, vuelva a escribirlo.';
export const TEXTO_VACIO = 'No hay cambios pendientes de revisar.';
export const TEXTO_CHOQUES = 'Datos que no subieron solos';
// El valor que no quedó, para leerlo y volver a escribirlo: una lista de un valor, ese valor; un objeto, sus pares «llave: valor»
const simple = x => (x === null || x === undefined || x === '' || typeof x === 'object') ? '' : (x === true ? 'Sí' : x === false ? 'No' : String(x));
export function valorPerdido(v) {
  if (Array.isArray(v)) return v.length === 1 && v[0] && typeof v[0] === 'object' ? valorPerdido(v[0]) : v.map(simple).filter(Boolean).join(', ');
  if (v && typeof v === 'object') return Object.keys(v).filter(k => simple(v[k])).map(k => k + ': ' + simple(v[k])).join(' · ');
  return simple(v);
}

export default {
  props: ['params'],
  data() { return { pisados: [], sinVer: 0, choques: [], cargando: true, marcando: false }; },
  computed: {
    puede() { return !!(sesion.esAdmin || sesion.puede('configurar')); },
    enPrograma() { return !!(sesion.empresaInfo && sesion.empresaInfo.es_local); },
    textoSoloLeer() { return TEXTO_SOLO_LEER; },
    textoVacio() { return TEXTO_VACIO; },
    textoChoques() { return TEXTO_CHOQUES; },
  },
  methods: {
    valorPerdido,
    cuando(v) { try { return v ? fechaHora(v) : ''; } catch { return String(v || ''); } },
    async cargar() {
      const eid = sesion.empresa_id;
      this.cargando = true;
      let p = null, c = null;
      try { p = await api('/api/sinc/datos/pisados?limite=200'); } catch { p = null; }   // 404 o sin red: lista vacía, sin aviso de error
      if (this.enPrograma) { try { c = await api('/api/sinc/datos/choques'); } catch { c = null; } }
      if (sesion.empresa_id !== eid) return;
      this.pisados = p && Array.isArray(p.pisados) ? p.pisados : [];
      this.sinVer = p ? (+p.sin_ver || 0) : 0;
      this.choques = c && Array.isArray(c.choques) ? c.choques : [];
      this.cargando = false;
    },
    async marcarVistos() {
      if (this.marcando || !this.sinVer) return;
      this.marcando = true;
      try { await api('/api/sinc/datos/pisados/vistos', { method: 'POST', body: {} }); await this.cargar(); }
      catch (e) { if (!e || e.status !== 404) toast('No se pudo marcar. Intente de nuevo en un momento.', 'err'); }
      finally { this.marcando = false; }
    },
  },
  mounted() { this.cargar(); },
  template: `
  <div class="page">
    <div class="card">
      <h2>Cambios que no quedaron</h2>
      <p class="small muted" style="margin:0 0 10px">{{textoSoloLeer}}</p>
      <p class="small" v-if="!puede">Esta lista es solo para el administrador de la empresa.</p>
      <template v-else>
        <p class="muted" v-if="cargando">Cargando…</p>
        <template v-else>
          <p class="muted" v-if="!pisados.length">{{textoVacio}}</p>
          <template v-else>
            <div style="margin:0 0 10px"><button class="btn sec" @click="marcarVistos" :disabled="marcando || !sinVer">{{marcando ? 'Marcando…' : 'Marcar como vistos'}}</button></div>
            <table class="tbl"><thead><tr><th>Fecha</th><th>Qué era</th><th>Lo que pasó</th><th>Lo que no quedó</th><th>Quedó de</th></tr></thead>
              <tbody><tr v-for="p in pisados" :key="p.id">
                <td class="small">{{cuando(p.cuando)}}</td>
                <td><b>{{p.tipo_nombre}}</b><span v-if="p.nombre"> · {{p.nombre}}</span></td>
                <td>{{p.texto}}<span class="small muted" v-if="!p.visto"> · nuevo</span></td>
                <td class="small">{{valorPerdido(p.perdio) || '—'}}</td>
                <td class="small">{{p.quedo_de || '—'}}</td>
              </tr></tbody></table>
          </template>
        </template>
      </template>
    </div>
    <div class="card" v-if="puede && enPrograma && !cargando && choques.length">
      <h2>{{textoChoques}}</h2>
      <table class="tbl"><thead><tr><th>Fecha</th><th>Qué era</th><th>Lo que pasó</th></tr></thead>
        <tbody><tr v-for="(c, i) in choques" :key="i">
          <td class="small">{{cuando(c.cuando)}}</td>
          <td><b>{{c.tipo_nombre}}</b><span v-if="c.nombre"> · {{c.nombre}}</span></td>
          <td>{{c.texto}}</td>
        </tr></tbody></table>
    </div>
  </div>`,
};
