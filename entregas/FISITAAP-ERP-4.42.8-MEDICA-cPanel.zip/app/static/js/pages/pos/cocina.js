// Punto de venta › Monitor de preparación (3.46, al estilo FISITAAP) y pantalla de cocina por rondas (3.24, KDS).
// Vista «Columnas»: Por preparar → En preparación → Listo, con botones grandes Preparar / Preparado / Entregado (o Despachar en
// pedidos a domicilio). Entran las comandas de mesa, las ventas para llevar o a domicilio y los pedidos en línea, con su origen.
// Vista «Por rondas»: la pantalla anterior, agrupada por ronda y estación, con el tiempo que lleva cada comanda y en rojo cuando
// pasa del límite. Cada plato se puede marcar por separado. Se refresca sola cada 15 segundos y suena cuando llega una comanda
// nueva. «Imprimir» saca la comanda una sola vez (queda marcada como impresa; se puede reimprimir a propósito).
import { mock, toast, fmtCant } from '../../api.js';
import { store, sesion } from '../../app.js';
import { enEspera, impresorasComanda, impresoraDe, categorias, terminales, terminalActual } from './_datos.js';
import { porAgente, imprimirAgente, docComanda, cargarEquipo, impresoraAqui } from './_agente.js';
import { textoNumeroComanda } from './_agente.js';   // 4.29: «COMANDA N.º 153» al reimprimir (el mismo número, no se pide otro)

const mismaLinea = (a, b) => a.detalle === b.detalle && String(a.enviado || '') === String(b.enviado || '') && String(a.nota || '') === String(b.nota || '') && +a.cantidad === +b.cantidad;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const COLUMNAS = [['pendiente', 'Por preparar'], ['preparando', 'En preparación'], ['listo', 'Listo']];
// 4.29: el número consecutivo de la comanda (el que la caja guardó en cada línea al enviarla); null = la comanda no tiene número
export function numeroDeRonda(lineas) { for (const l of lineas || []) { const n = Number(l && l.comanda); if (Number.isInteger(n) && n >= 1) return n; } return null; }
// 4.31: el aviso cuando el navegador no abrió la ventana de impresión (esos platos no quedan marcados como impresos). `nombres` = las
// impresoras cuya comanda iba a esa ventana; `platos` = los platos sin impresora de comanda que iban a ella (en la hoja salen como «Cocina»,
// pero el aviso los nombra a ellos: la impresora «Cocina» de verdad pudo imprimir bien en el mismo toque).
export function textoVentanaBloqueada(nombres, platos) {
  const lista = (xs, d) => [...new Set((Array.isArray(xs) ? xs : []).map(x => '«' + String(x || d) + '»'))];
  const y = xs => (xs.length > 1 ? xs.slice(0, -1).join(', ') + ' y ' + xs[xs.length - 1] : xs[0] || '');
  const n = lista(nombres, 'Cocina'), p = lista(platos, 'plato');
  const fin = ': el navegador no abrió la ventana de impresión (revise si bloquea las ventanas emergentes de esta página). Toque «Imprimir» otra vez cuando lo haya revisado.';
  if (p.length && n.length) return 'No se imprimieron ' + (n.length > 1 ? 'las comandas de ' : 'la comanda de ') + y(n) + ' ni ' + (p.length > 1 ? 'los platos ' : 'el plato ') + y(p) + fin;
  if (p.length) return (p.length > 1 ? 'Los platos ' + y(p) + ' no se imprimieron' : 'El plato ' + p[0] + ' no se imprimió') + fin;
  const quien = n.length > 1 ? 'Las comandas de ' + y(n) + ' no se imprimieron' : 'La comanda de ' + (n[0] || '«Cocina»') + ' no se imprimió';
  return quien + fin;
}

export default {
  props: ['params'],
  data() {
    let estacion = '', vista = 'columnas';
    try { estacion = localStorage.getItem('pos:kds:estacion') || ''; vista = localStorage.getItem('pos:kds:vista') || 'columnas'; } catch {}
    return { estacion, vista: vista === 'rondas' ? 'rondas' : 'columnas', reloj: Date.now(), mostrarListos: false, mostrarEntregadas: false, sonido: true, vistos: null, limite: +((terminalActual() || {}).alerta_comanda) || 20, COLUMNAS, estEstado: null, textoListaCocina: '' };
  },
  computed: {
    estaciones() { return impresorasComanda(); },
    // una tarjeta por cuenta y ronda, con sus platos (filtrados por estación), minutos y estado
    tickets() {
      void this.reloj;
      const cats = categorias(), extras = mock.get('items_extra', {}) || {}, term = terminalActual() || terminales()[0] || null, prods = store.productos || [], ahora = Date.now(), out = [];
      for (const v of enEspera()) {
        const tv = (v.canal === 'online' && terminales().find(x => String(x.id) === String(v.terminal_id))) || term;   /* 4.31: un pedido en línea va a las impresoras de la caja de su cuenta, como la estación de comandas */
        const ls = (v.lineas || []).filter(l => l.enviado && +l.cantidad > 0).map(l => { const p = prods.find(x => x.id === l.producto_id); const imp = p ? impresoraDe(p, cats, tv, extras) : null; return { ...l, estacion: imp ? imp.id : null, estacion_nombre: imp ? imp.nombre : '', imp }; })
          .filter(l => !this.estacion || String(l.estacion) === String(this.estacion));
        if (!ls.length) continue;
        const rondas = {}; for (const l of ls) (rondas[+l.ronda || 0] = rondas[+l.ronda || 0] || []).push(l);
        for (const [r, lineas] of Object.entries(rondas)) {
          // 3.87: una cuenta ya entregada (el motorizado con el PIN, Ventas en línea › Pedidos o la caja) sale de la cocina aunque sus platos no
          // se marcaran aquí, pero solo con las comandas enviadas antes de la entrega: una ronda nueva de esa cuenta sí se prepara
          const pend = lineas.filter(l => !l.listo), entregadas = this.cerradaAfuera(v, lineas) || lineas.every(l => l.entregado);
          const desde = lineas.map(l => l.enviado).sort()[0], min = Math.max(0, Math.round((ahora - new Date(desde).getTime()) / 60000));
          const columna = entregadas ? 'entregada' : !pend.length ? 'listo' : lineas.some(l => l.preparando || l.listo) ? 'preparando' : 'pendiente';
          out.push({ key: v.id + ':' + r, cuenta: v, ronda: +r, lineas, comanda: numeroDeRonda(lineas), pendientes: pend.length, desde, minutos: min, listoTodo: !pend.length, entregada: entregadas, columna, tarde: !entregadas && pend.length && min >= this.limite, aviso: !entregadas && pend.length && min >= this.limite / 2, impresa: lineas.every(l => l.impreso), origen: this.origen(v) });
        }
      }
      return out.sort((a, b) => (a.listoTodo - b.listoTodo) || String(a.desde).localeCompare(String(b.desde)));
    },
    ticketsRondas() { return this.tickets.filter(t => !t.entregada && (this.mostrarListos || !t.listoTodo)); },
    porColumna() { const m = { pendiente: [], preparando: [], listo: [], entregada: [] }; for (const t of this.tickets) (m[t.columna] || m.pendiente).push(t); return m; },
    pendientes() { return this.tickets.filter(t => !t.listoTodo && !t.entregada).length; },
  },
  methods: {
    fmtCant,
    origen(v) { return v.canal === 'online' ? { icono: '🌐', nombre: 'En línea' } : v.pedido === 'domicilio' ? { icono: '🛵', nombre: 'A domicilio' } : v.pedido ? { icono: '🥡', nombre: 'Para llevar' } : v.mesa_id ? { icono: '🍽', nombre: 'Mesa' } : { icono: '🧾', nombre: 'Cuenta' }; },
    titulo(t) { return t.origen.icono + ' ' + t.cuenta.nombre; },
    // 3.87: ¿la ronda se entregó fuera de la cocina? La cuenta quedó «entregado» y todos sus platos se enviaron antes de esa hora. Se
    // comparan instantes (el servidor escribe la hora de Costa Rica con su desfase y la caja en UTC). Sin hora no se supone nada: se muestra.
    cerradaAfuera(v, lineas) { if (v.estado !== 'entregado') return false; const h = Date.parse(v.hora_entregado || ''); return !isNaN(h) && lineas.every(l => Date.parse(l.enviado) <= h); },
    hora(iso) { return iso ? new Date(iso).toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) : ''; },
    cambiarEstacion(v) { this.estacion = v; try { localStorage.setItem('pos:kds:estacion', v || ''); } catch {} },
    cambiarVista(v) { this.vista = v; try { localStorage.setItem('pos:kds:vista', v); } catch {} },
    async aplicar(cuentaId, fn) {
      if (!mock.puedeGuardar()) return;
      try { await mock.refrescar(['pos_espera'], { sinCorte: true }); } catch {}   // 4.6: la cuenta fresca (la caja pudo enviar otra ronda): no se pisa con la copia de hace 15 s
      const F = await import('./_fusion.js').catch(() => null);   /* 4.31: la cocina solo manda sus marcas; si el módulo no carga, como antes */
      mock.actualizar('pos_espera', lista => (lista || []).map(v => (v.id !== cuentaId ? v : F ? F.conFusionDe(F.ponerLids(v), fn(v), 'cocina') : fn(v))), []);
      this.reloj = Date.now();
    },
    // ---- columnas (3.46): toda la comanda avanza de estado ----
    enRonda(x, t) { return x.enviado && +x.ronda === t.ronda && t.lineas.some(l => mismaLinea(x, l)); },
    preparar(t) { const ahora = new Date().toISOString(); this.aplicar(t.cuenta.id, v => this.conEstado({ ...v, lineas: (v.lineas || []).map(x => (this.enRonda(x, t) && !x.preparando ? { ...x, preparando: ahora } : x)) })); },
    preparado(t) { const ahora = new Date().toISOString(); this.aplicar(t.cuenta.id, v => this.conEstado({ ...v, lineas: (v.lineas || []).map(x => (this.enRonda(x, t) && !x.listo ? { ...x, preparando: x.preparando || ahora, listo: ahora } : x)) })); toast('Comanda ' + (t.comanda ? 'N.º ' + t.comanda : t.ronda) + ' de ' + t.cuenta.nombre + ' lista', 'ok'); },
    entregar(t) {
      const ahora = new Date().toISOString();
      this.aplicar(t.cuenta.id, v => { const lineas = (v.lineas || []).map(x => (this.enRonda(x, t) ? { ...x, preparando: x.preparando || ahora, listo: x.listo || ahora, entregado: ahora } : x)); const todo = lineas.filter(l => l.enviado).every(l => l.entregado); return v.pedido && todo && v.estado !== 'entregado' ? { ...v, lineas, estado: v.pedido === 'domicilio' ? 'listo' : 'entregado', hora_entregado: ahora } : { ...v, lineas }; });
      toast((t.cuenta.pedido === 'domicilio' ? 'Despachada: ' : 'Entregada: ') + t.cuenta.nombre, 'ok');
    },
    devolver(t) {
      if (t.columna === 'entregada') {   // 3.87: «↩ Regresar a Listo» deja los platos listos (antes volvían a «Por preparar») y la cuenta deja de estar entregada
        const ahora = new Date().toISOString();
        return this.aplicar(t.cuenta.id, v => {
          // 3.87: la cuenta vuelve a «listo» solo si la entregó la cocina (todos sus platos marcados): si la cerró el motorizado o la caja,
          // sus otras rondas siguen fuera del monitor
          const env = (v.lineas || []).filter(l => l.enviado), porCocina = env.length > 0 && env.every(l => l.entregado);
          return { ...v, estado: v.pedido && v.estado === 'entregado' && porCocina ? 'listo' : v.estado, lineas: (v.lineas || []).map(x => (this.enRonda(x, t) ? { ...x, preparando: x.preparando || ahora, listo: x.listo || ahora, entregado: null } : x)) };
        });
      }
      this.aplicar(t.cuenta.id, v => this.conEstado({ ...v, lineas: (v.lineas || []).map(x => (this.enRonda(x, t) ? { ...x, preparando: t.columna === 'listo' ? x.preparando : null, listo: null, entregado: null } : x)) }));
    },
    // ---- por plato: pendiente → en preparación → listo (y deshacer) ----
    avanzarLinea(t, l) {
      const ahora = new Date().toISOString();
      this.aplicar(t.cuenta.id, v => { let hecho = false; const lineas = (v.lineas || []).map(x => { if (hecho || !mismaLinea(x, l) || x.listo) return x; hecho = true; return x.preparando ? { ...x, listo: ahora } : { ...x, preparando: ahora }; }); return this.conEstado({ ...v, lineas }); });
    },
    marcar(t, l) {
      const ahora = new Date().toISOString();
      this.aplicar(t.cuenta.id, v => { let hecho = false; const lineas = (v.lineas || []).map(x => (!hecho && !x.listo && mismaLinea(x, l) ? (hecho = true, { ...x, preparando: x.preparando || ahora, listo: ahora }) : x)); return this.conEstado({ ...v, lineas }); });
    },
    marcarTodo(t) { this.preparado(t); },
    deshacer(t, l) { this.aplicar(t.cuenta.id, v => { let hecho = false; const lineas = (v.lineas || []).map(x => (!hecho && x.listo && mismaLinea(x, l) ? (hecho = true, { ...x, listo: null, entregado: null }) : x)); return this.conEstado({ ...v, lineas }); }); },
    // un pedido para llevar o a domicilio pasa solo a «Listo» cuando toda su comanda está lista (y regresa a «En cocina» si se deshace)
    conEstado(v) { if (!v.pedido || v.estado === 'entregado') return v; const env = (v.lineas || []).filter(l => l.enviado); const todo = env.length && env.every(l => l.listo); if (todo && v.estado !== 'listo') return { ...v, estado: 'listo', hora_listo: new Date().toISOString() }; if (!todo && v.estado === 'listo') return { ...v, estado: 'en_cocina' }; return v; },
    // ---- imprimir la comanda desde el monitor (una sola vez; reimprimir a propósito) ----
    async imprimir(t) {
      const enLinea = this._est ? await this._est.imprimirCocinaEnLinea(t, ls => this.aplicar(t.cuenta.id, x => ({ ...x, lineas: (x.lineas || []).map(l => (this.enRonda(l, t) && (!ls || ls.some(y => mismaLinea(l, y))) ? { ...l, impreso: true } : l)) }))) : false;   /* 4.31: pedido en línea con copia de la comanda: solo los platos de esta tarjeta, reclamados antes de imprimir; la marca, solo en los que salieron */
      if (enLinea === true) return;
      if (enLinea && Array.isArray(enLinea.resto)) t = { ...t, lineas: enLinea.resto, impresa: false };   /* 4.31: los platos de la tarjeta que no son de la copia de la comanda, como siempre */
      if (t.impresa && !confirm('Esta comanda ya se imprimió. ¿Imprimirla otra vez?')) return;
      const faltan = t.impresa ? t.lineas : t.lineas.filter(l => !l.impreso);   // 4.29: impresa en parte (una impresora no respondió al aceptar): solo lo que falta
      const grupos = {}; for (const l of faltan) { const imp =l.imp || { id: 'v:Cocina', nombre: 'Cocina', virtual: true }; (grupos[imp.id] = grupos[imp.id] || { imp, ls: [] }).ls.push(l); }
      const v = t.cuenta, navegador = [], vent = enLinea && enLinea.ventana ? enLinea.ventana : null;   /* 4.31: la ventana abierta en el toque (pedido en línea): la comanda del navegador se escribe ahí */
      if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});   // 4.25: la impresión de esta computadora (solo en el programa)
      for (const g of Object.values(grupos)) {
        g.imp = impresoraAqui(g.imp);   // 4.25: la de la categoría, como está conectada en esta computadora
        if (!porAgente(g.imp)) { navegador.push(g); continue; }
        try { await imprimirAgente(g.imp, docComanda({ impresora: g.imp.nombre, cuenta: v.nombre, ronda: t.ronda, salonero: v.salonero || '', caja: '', lineas: g.ls, nota: v.nota || '', numero: t.comanda })); }
        catch (e) { toast('Comanda de «' + g.imp.nombre + '» no se imprimió por el agente: ' + e.message, 'err'); navegador.push(g); }
      }
      if (navegador.length) {
        const secciones = navegador.map(({ imp, ls }) => '<div class="pg">' + (t.comanda ? '<h1 style="margin:0 0 4px;text-align:center;font-size:30px">' + esc(textoNumeroComanda(t.comanda)) + '</h1>' : '') + '<h2>' + esc(String(imp.nombre).toUpperCase()) + '</h2><h3>' + esc(t.origen.icono + ' ' + v.nombre) + ' · ronda ' + t.ronda + '</h3><p>' + esc(this.hora(t.desde)) + (v.salonero ? ' · ' + esc(v.salonero) : '') + '</p><table>' + ls.map(l => '<tr><td class="q">' + esc(fmtCant(l.cantidad)) + '</td><td>' + esc(l.detalle) + (l.nota ? '<div class="o">' + esc(l.nota) + '</div>' : '') + '</td></tr>').join('') + '</table>' + (v.nota ? '<p class="o">' + esc(v.nota) + '</p>' : '') + '</div>').join('');
        const html = '<!doctype html><html><head><meta charset="utf-8"><title>Comanda</title><style>body{font-family:Arial,sans-serif;font-size:15px;width:72mm;margin:4mm auto;color:#111}h2{margin:2px 0;text-align:center;font-size:20px}h3{margin:2px 0;text-align:center;font-size:16px}p{margin:4px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:5px 0;border-bottom:1px dotted #bbb;vertical-align:top}td.q{width:34px;font-weight:700;font-size:18px}.o{font-weight:700;font-style:italic}.pg{page-break-after:always;padding-bottom:12px}@media print{body{margin:0}}</style></head><body>' + secciones + '</body></html>';
        let abierta = false;
        if (vent && !vent.closed) { try { vent.document.open(); vent.document.write(html); vent.document.close(); abierta = true; } catch { /* sigue con una ventana nueva */ } }
        if (!abierta) { const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); abierta = !!window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000); }
        if (!abierta) {   /* 4.31: el navegador no abrió la ventana: esos platos no salieron y no se marcan (el servidor los daría por impresos); solo lo que salió por la impresora directa */
          toast(textoVentanaBloqueada(navegador.filter(g => g.ls.some(l => l.imp)).map(g => g.imp.nombre), navegador.filter(g => !g.ls.some(l => l.imp)).flatMap(g => g.ls.map(l => l.detalle))), 'err');   /* 4.31: los platos sin impresora de comanda, por su nombre (no «Cocina») */
          const salieron = faltan.filter(l => !navegador.some(g => g.ls.includes(l)));
          if (salieron.length) this.aplicar(v.id, x => ({ ...x, lineas: (x.lineas || []).map(l => (this.enRonda(l, t) && salieron.some(y => mismaLinea(l, y)) ? { ...l, impreso: true } : l)) }));
          return;
        }
      } else if (vent) { try { vent.close(); } catch { /* ya cerrada */ } }   /* 4.31: todo salió por las impresoras directas: la ventana del toque sobra */
      this.aplicar(v.id, x => ({ ...x, lineas: (x.lineas || []).map(l => (this.enRonda(l, t) ? { ...l, impreso: true } : l)) }));
    },
    async refrescar() { try { await mock.refrescar(['pos_espera']); } catch {} this.reloj = Date.now(); if (this._est) this._est.revisarEstacion('cocina'); },
    /* 4.31: la banda de la estación de comandas (vacía mientras el módulo no carga o sin pedidos en línea) */
    textoEstacion() { return this.estEstado && this._est ? this._est.textoEstacion() : ''; },
    imprimirListaCocina(id) { return this._est ? this._est.imprimirListaCocina(id) : null; },
    beep() { try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 880; g.gain.value = 0.15; o.start(); o.stop(ac.currentTime + 0.25); } catch {} },
  },
  watch: {
    tickets(ts) { const claves = new Set(ts.filter(t => !t.listoTodo && !t.entregada).map(t => t.key)); if (this.vistos && this.sonido && [...claves].some(k => !this.vistos.has(k))) this.beep(); this.vistos = claves; },
  },
  created() { this.vistos = new Set(this.tickets.filter(t => !t.listoTodo && !t.entregada).map(t => t.key)); this._t1 = setInterval(() => this.refrescar(), 15000); this._t2 = setInterval(() => { this.reloj = Date.now(); }, 30000);
    import('./_estacion.js').then(E => { if (this._fuera) return; this._est = E; this.textoListaCocina = E.TEXTO_LISTA_COCINA; this.estEstado = E.estadoEstacion; E.iniciarEstacion('cocina'); }).catch(() => {});   /* 4.31: estación de comandas; si no carga, Cocina sigue como antes */
  },
  beforeUnmount() { this._fuera = true; clearInterval(this._t1); clearInterval(this._t2); if (this._est) this._est.pararEstacion('cocina'); },
  template: `
  <div class="page kds">
    <div class="kds-top">
      <b style="font-size:18px">{{vista==='columnas' ? 'Monitor de preparación' : 'Pantalla de cocina'}}</b><span class="small muted">{{pendientes}} comanda(s) pendiente(s) · se actualiza sola</span>
      <span class="seg"><button :class="{on: vista==='columnas'}" @click="cambiarVista('columnas')">Columnas</button><button :class="{on: vista==='rondas'}" @click="cambiarVista('rondas')">Por rondas</button></span>
      <span style="flex:1"></span>
      <select class="inp" :value="estacion" @change="cambiarEstacion($event.target.value)" v-if="estaciones.length"><option value="">Todas las estaciones</option><option v-for="e in estaciones" :key="e.id" :value="e.id">{{e.nombre}}</option></select>
      <label class="row small" style="gap:4px;cursor:pointer" v-if="vista==='rondas'"><input type="checkbox" v-model="mostrarListos"> Ver listas</label>
      <label class="row small" style="gap:4px;cursor:pointer" v-else><input type="checkbox" v-model="mostrarEntregadas"> Ver entregadas</label>
      <label class="row small" style="gap:4px;cursor:pointer"><input type="checkbox" v-model="sonido"> Sonido</label>
      <button class="btn sm ghost" @click="refrescar">Actualizar</button>
    </div>
    <div class="alert small" style="margin:0 0 10px" v-if="textoEstacion()">{{textoEstacion()}}</div>
    <div class="alert err small row" style="margin:0 0 10px;gap:8px;flex-wrap:wrap;align-items:center" v-if="estEstado && estEstado.lista && estEstado.lista.length"><b>{{textoListaCocina}}</b><span v-for="x in estEstado.lista" :key="x.pedido_id" class="row" style="gap:4px;align-items:center">{{x.texto}} <button class="btn sm" @click="imprimirListaCocina(x.pedido_id)">Imprimir</button></span></div>

    <!-- columnas (3.46) -->
    <template v-if="vista==='columnas'">
      <Empty v-if="!tickets.length" icon="🍳" title="Sin comandas" text="Cuando la caja envíe una comanda (F8) o entre un pedido, aparece aquí en «Por preparar». Cada estación filtra los platos de su impresora de comanda."></Empty>
      <div class="kds-cols" v-else>
        <div v-for="c in COLUMNAS" :key="c[0]" class="kds-col" :class="c[0]">
          <div class="kds-col-t">{{c[1]}} <span class="badge">{{porColumna[c[0]].length}}</span></div>
          <div v-for="t in porColumna[c[0]]" :key="t.key" class="kds-card" :class="{tarde: t.tarde, aviso: t.aviso && !t.tarde, lista: t.listoTodo}">
            <div class="kds-head"><div><span v-if="t.comanda" class="kds-num" style="display:block;font-size:22px;font-weight:800;line-height:1.1" title="Número de comanda">N.º {{t.comanda}}</span><b>{{titulo(t)}}</b><div class="small">{{t.origen.nombre}} · comanda {{t.ronda}} · {{hora(t.desde)}}{{t.cuenta.salonero ? ' · ' + t.cuenta.salonero : ''}}{{t.cuenta.hora_entrega ? ' · entregar ' + t.cuenta.hora_entrega : ''}}</div></div><div class="kds-min">{{t.minutos}} min</div></div>
            <div v-if="t.cuenta.nota" class="small" style="margin:0 0 6px;color:var(--primary)">✎ {{t.cuenta.nota}}</div>
            <div v-for="(l, i) in t.lineas" :key="i" class="kds-line" :class="{ok: l.listo, prep: l.preparando && !l.listo}" @click="l.listo ? deshacer(t, l) : avanzarLinea(t, l)" :title="l.listo ? 'Lista a las ' + hora(l.listo) + ' (toque para deshacer)' : l.preparando ? 'En preparación (toque para marcar lista)' : 'Toque para pasar a preparación'">
              <span class="q">{{fmtCant(l.cantidad)}}</span><span class="d">{{l.detalle}}<div class="small" v-if="l.nota">✎ {{l.nota}}</div><div class="small muted" v-if="!estacion && l.estacion_nombre">{{l.estacion_nombre}}</div></span><span class="k">{{l.listo ? '✓' : l.preparando ? '🔥' : ''}}</span>
            </div>
            <div class="row" style="gap:6px;margin-top:8px">
              <button class="btn kds-btn" v-if="t.columna==='pendiente'" @click="preparar(t)">Preparar</button>
              <button class="btn kds-btn" v-else-if="t.columna==='preparando'" @click="preparado(t)">Preparado</button>
              <button class="btn kds-btn ok" v-else @click="entregar(t)">{{t.cuenta.pedido==='domicilio' ? 'Despachar' : 'Entregado'}}</button>
              <button class="btn sm ghost" v-if="t.columna!=='pendiente'" @click="devolver(t)" title="Regresar la comanda a la columna anterior">↩</button>
              <button class="btn sm ghost" @click="imprimir(t)" :title="t.impresa ? 'Ya se imprimió; toque para reimprimir' : 'Imprimir la comanda'">{{t.impresa ? '🖨 Impresa' : '🖨'}}</button>
            </div>
          </div>
          <div class="small muted" v-if="!porColumna[c[0]].length" style="padding:14px;text-align:center">—</div>
        </div>
      </div>
      <details v-if="mostrarEntregadas && porColumna.entregada.length" style="margin-top:12px" open><summary class="small muted">Entregadas ({{porColumna.entregada.length}})</summary>
        <div class="kds-grid" style="margin-top:8px"><div v-for="t in porColumna.entregada" :key="t.key" class="kds-card lista"><div class="kds-head"><div><b>{{titulo(t)}}</b><div class="small">{{t.comanda ? 'N.º ' + t.comanda + ' · ' : ''}}comanda {{t.ronda}} · {{hora(t.desde)}}</div></div><div class="kds-min">✓</div></div><div v-for="(l, i) in t.lineas" :key="i" class="kds-line ok"><span class="q">{{fmtCant(l.cantidad)}}</span><span class="d">{{l.detalle}}</span><span class="k">✓</span></div><button class="btn sm ghost" style="margin-top:6px" v-if="t.lineas.every(l => l.entregado)" @click="devolver(t)">↩ Regresar a Listo</button></div></div>
      </details>
    </template>

    <!-- por rondas (3.24) -->
    <template v-else>
      <Empty v-if="!ticketsRondas.length" icon="🍳" title="Sin comandas pendientes" text="Cuando la caja envíe una comanda (F8), aparece aquí con su tiempo. Cada estación filtra los platos de su impresora de comanda."></Empty>
      <div class="kds-grid" v-else>
        <div v-for="t in ticketsRondas" :key="t.key" class="kds-card" :class="{tarde: t.tarde, aviso: t.aviso && !t.tarde, lista: t.listoTodo}">
          <div class="kds-head"><div><span v-if="t.comanda" class="kds-num" style="display:block;font-size:22px;font-weight:800;line-height:1.1" title="Número de comanda">N.º {{t.comanda}}</span><b>{{titulo(t)}}</b><div class="small">Comanda {{t.ronda}} · {{hora(t.desde)}}{{t.cuenta.salonero ? ' · ' + t.cuenta.salonero : ''}}{{t.cuenta.hora_entrega ? ' · entregar ' + t.cuenta.hora_entrega : ''}}</div></div><div class="kds-min">{{t.listoTodo ? '✓' : t.minutos + ' min'}}</div></div>
          <div v-if="t.cuenta.nota" class="small" style="margin:0 0 6px;color:var(--primary)">✎ {{t.cuenta.nota}}</div>
          <div v-for="(l, i) in t.lineas" :key="i" class="kds-line" :class="{ok: l.listo, prep: l.preparando && !l.listo}" @click="l.listo ? deshacer(t, l) : marcar(t, l)" :title="l.listo ? 'Lista a las ' + hora(l.listo) + ' (toque para deshacer)' : 'Toque para marcar lista'">
            <span class="q">{{fmtCant(l.cantidad)}}</span><span class="d">{{l.detalle}}<div class="small" v-if="l.nota">✎ {{l.nota}}</div><div class="small muted" v-if="!estacion && l.estacion_nombre">{{l.estacion_nombre}}</div></span><span class="k">{{l.listo ? '✓' : l.preparando ? '🔥' : ''}}</span>
          </div>
          <div class="row" style="gap:6px;margin-top:8px"><button class="btn" style="flex:1" v-if="!t.listoTodo" @click="marcarTodo(t)">Todo listo</button><button class="btn sm ghost" @click="imprimir(t)" :title="t.impresa ? 'Ya se imprimió; toque para reimprimir' : 'Imprimir la comanda'">{{t.impresa ? '🖨 Impresa' : '🖨'}}</button></div>
        </div>
      </div>
    </template>
  </div>`,
};
