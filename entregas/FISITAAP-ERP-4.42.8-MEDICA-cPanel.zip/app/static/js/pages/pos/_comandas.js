// 4.29 (encargo B): imprimir la comanda de una cuenta, con el mismo agrupado, documento y caminos que «Imprimir» de Punto de venta ›
// Cocina (pos/cocina.js imprimir): una comanda por impresora, impresión directa (agente o el programa de escritorio, con la impresora como
// está conectada en esta computadora) o la ventana de impresión del navegador, y «COMANDA N.º …» arriba si la comanda tiene número.
// Lo usa Ventas en línea › Pedidos al aceptar un pedido (fis/pages/pedidos.js). OJO: este módulo NO importa app.js ni _datos.js (los dos
// arrancan el ERP); la aplicación de Ventas en línea no tiene cargados los registros del punto de venta, así que todo dato llega por
// parámetro. Las funciones de abajo que no imprimen son puras (se prueban en Node).
import { toast, fmtCant } from '../../api.js';
import { porAgente, imprimirAgente, docComanda, cargarEquipo, impresoraAqui, textoNumeroComanda, avisoImpresion } from './_agente.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
export const COCINA_VIRTUAL = { id: 'v:Cocina', nombre: 'Cocina', virtual: true };
// El número consecutivo de la comanda (el que quedó en cada línea, campo «comanda»); null = sin número
export function numeroDeRonda(lineas) { for (const l of lineas || []) { const n = Number(l && l.comanda); if (Number.isInteger(n) && n >= 1) return n; } return null; }
export function horaCorta(iso) { return iso ? new Date(iso).toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) : ''; }
// Una comanda por impresora: las líneas llevan su impresora en `imp` (sin impresora, la «Cocina» del navegador, como en el monitor)
export function gruposComanda(lineas) {
  const grupos = {}; for (const l of lineas || []) { const imp = l.imp || COCINA_VIRTUAL; (grupos[imp.id] = grupos[imp.id] || { imp, ls: [] }).ls.push(l); }
  return grupos;
}
// La página de la ventana de impresión del navegador (una hoja por impresora)
export function htmlComandas(grupos, { cuenta, ronda, numero, icono, desde }) {
  const v = cuenta || {};
  const secciones = grupos.map(({ imp, ls }) => '<div class="pg">' + (numero ? '<h1 style="margin:0 0 4px;text-align:center;font-size:30px">' + esc(textoNumeroComanda(numero)) + '</h1>' : '') + '<h2>' + esc(String(imp.nombre).toUpperCase()) + '</h2><h3>' + esc((icono || '') + ' ' + v.nombre) + ' · ronda ' + ronda + '</h3><p>' + esc(horaCorta(desde)) + (v.salonero ? ' · ' + esc(v.salonero) : '') + '</p><table>' + ls.map(l => '<tr><td class="q">' + esc(fmtCant(l.cantidad)) + '</td><td>' + esc(l.detalle) + (l.nota ? '<div class="o">' + esc(l.nota) + '</div>' : '') + '</td></tr>').join('') + '</table>' + (v.nota ? '<p class="o">' + esc(v.nota) + '</p>' : '') + '</div>').join('');
  return '<!doctype html><html><head><meta charset="utf-8"><title>Comanda</title><style>body{font-family:Arial,sans-serif;font-size:15px;width:72mm;margin:4mm auto;color:#111}h2{margin:2px 0;text-align:center;font-size:20px}h3{margin:2px 0;text-align:center;font-size:16px}p{margin:4px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:5px 0;border-bottom:1px dotted #bbb;vertical-align:top}td.q{width:34px;font-weight:700;font-size:18px}.o{font-weight:700;font-style:italic}.pg{page-break-after:always;padding-bottom:12px}@media print{body{margin:0}}</style></head><body>' + secciones + '</body></html>';
}
// Imprime la comanda de una ronda de la cuenta. Devuelve { impresas: [líneas que salieron], fallas: [motivos] } y nunca lanza.
// respaldoNavegador (como en el monitor): si el agente falla, avisa y esa impresora sale por la ventana del navegador. Sin respaldo (al
// aceptar un pedido): esa impresora queda como falla, con su motivo, y sus líneas sin marcar; la ventana del navegador que no se abrió
// (bloqueada) también es falla.
// 4.29: `ventana` = la abierta en el toque (al aceptar un pedido en la web): la página se escribe ahí; si no hace falta, se cierra.
export async function imprimirComandas({ cuenta, ronda, lineas, numero, icono, desde, local, respaldoNavegador = true, ventana = null }) {
  const v = cuenta || {}, navegador = [], impresas = [], fallas = [];
  let enVentana = false;
  try {
    if (local) await cargarEquipo().catch(() => {});   // 4.25: la impresión de esta computadora (solo en el programa)
    for (const g of Object.values(gruposComanda(lineas))) {
      g.imp = impresoraAqui(g.imp);   // 4.25: la de la categoría, como está conectada en esta computadora
      if (!porAgente(g.imp)) { navegador.push(g); continue; }
      try { await imprimirAgente(g.imp, docComanda({ impresora: g.imp.nombre, cuenta: v.nombre, ronda, salonero: v.salonero || '', caja: '', lineas: g.ls, nota: v.nota || '', numero })); impresas.push(...g.ls); }
      catch (e) {
        if (respaldoNavegador) { toast('Comanda de «' + g.imp.nombre + '» no se imprimió por el agente: ' + e.message, 'err'); navegador.push(g); }
        else fallas.push(avisoImpresion('la impresora «' + g.imp.nombre + '» no respondió: ', e));
      }
    }
    if (navegador.length) {
      const html = htmlComandas(navegador, { cuenta: v, ronda, numero, icono, desde });
      if (ventana && !ventana.closed) { try { ventana.document.open(); ventana.document.write(html); ventana.document.close(); enVentana = true; } catch { /* sigue con la ventana de siempre */ } }
      if (enVentana) for (const g of navegador) impresas.push(...g.ls);
      else {
        const u = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
        const w = window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
        if (w) for (const g of navegador) impresas.push(...g.ls);   /* 4.31: la ventana bloqueada no cuenta como impresa (tampoco con respaldo): esos platos no se marcan */
        else fallas.push('el navegador no abrió la ventana de impresión (revise si bloquea las ventanas emergentes de esta página)');
      }
    }
  } catch (e) { fallas.push(String((e && e.message) || e || 'error al imprimir')); }
  if (ventana && !enVentana) { try { ventana.close(); } catch { /* ya cerrada */ } }
  return { impresas, fallas: fallas.map(m => String(m).trim().replace(/[.\s]+$/, '')) };
}

// ---- comanda al aceptar un pedido en línea (W-1, W-3): los datos llegan de la API, no del registro cargado ----
// Las impresoras de comanda activas (registro pos_impresoras)
export function impresorasDeComanda(lista) { return (Array.isArray(lista) ? lista : []).filter(i => i && i.nombre && i.activa !== false && (i.uso || 'comanda') === 'comanda'); }
// La caja con ese id, leída como la lee el servidor al crear la cuenta (pedidos.terminales_pos): las guardadas; la configuración vieja de
// una sola caja cuenta como la caja 1; sin nada, la «Caja 1» por defecto. Sin id o con uno que no está, la primera.
export function cajaDe(cfg, id) {
  const lista = cfg && Array.isArray(cfg.terminales) ? cfg.terminales.filter(t => t && typeof t === 'object') : [];
  const ts = lista.length ? lista : cfg && typeof cfg === 'object' && !Array.isArray(cfg) && Object.keys(cfg).length && !Array.isArray(cfg.terminales) ? [{ ...cfg, id: 1 }] : [{ id: 1, nombre: 'Caja 1' }];
  return ts.find(t => id !== null && id !== undefined && id !== '' && String(t.id) === String(id)) || ts[0];
}
// La impresora de comanda de un producto con la lista dada: la misma regla que la caja (pos/_datos.js impresoraDe, que lee el registro
// cargado): la del ítem; si no, la de su categoría o de una superior en esa caja; si no, la primera de comanda. null = sin comanda.
export function impresoraDeLista(lista, p, cats, terminal, extras) {
  const porId = Object.fromEntries(lista.map(i => [String(i.id), i]));
  const virtual = n => ({ id: 'v:' + n, nombre: n, virtual: true });
  const resolver = v => { if (v === 'none') return null; if (v === '' || v === undefined || v === null) return undefined; if (porId[String(v)]) return porId[String(v)]; if (typeof v === 'string') { const i = lista.find(x => x.nombre.toLowerCase() === v.toLowerCase()); return i || virtual(v === 'cocina' ? 'Cocina' : v === 'bar' ? 'Bar' : v); } return undefined; };
  const ex = p && extras ? (extras[p.id] || {}) : {};
  let r = resolver(ex.impresora_id); if (r !== undefined) return r;
  const d = (terminal && terminal.destinos) || {}, lista2 = cats || [];
  let c = p ? lista2.find(x => x.nombre === (p.categoria || '')) : null, n = 0;
  while (c && n++ < 10) { r = resolver(d[c.id]); if (r !== undefined) return r; c = c.padre_id ? lista2.find(x => x.id === c.padre_id) : null; }
  return lista[0] || virtual('Cocina');
}
// ¿El botón de un pedido nuevo imprime la comanda? (W-3) Negocio con menú, al menos una impresora de comanda activa y la caja de los
// pedidos sin «imprimir la comanda» apagado (sin configuración guardada vale la «Caja 1» por defecto, que sí imprime).
export function imprimeAlAceptar(menu, cfg, impresoras, terminalId) {
  if (!menu || !impresorasDeComanda(impresoras).length) return false;
  return cajaDe(cfg, terminalId).imprimir_comanda !== false;
}
// 4.29: ¿alguna impresora de comanda sale por la ventana del navegador? Entonces, en la web, la ventana se abre en el toque de «Aceptar»
// (después de esperar al servidor el navegador puede bloquearla, sobre todo Safari). El programa de escritorio sigue como estaba.
export function usaVentana(impresoras, local) { return !local && impresorasDeComanda(impresoras).some(i => !porAgente(impresoraAqui(i))); }
// Las líneas de la comanda de la cuenta de un pedido: las enviadas a cocina con cantidad, cada una con su impresora (`imp`) y su
// posición en la cuenta (`pos`, para marcarla impresa); las de un plato «sin comanda» no van. [] = no hay nada que imprimir.
export function lineasComandaPedido(cuenta, { impresoras, categorias, extras, productos, terminal } = {}) {
  const lista = impresorasDeComanda(impresoras), cats = (Array.isArray(categorias) ? categorias : []).filter(c => c && c.nombre), prods = Array.isArray(productos) ? productos : [];
  const ex = extras && typeof extras === 'object' ? extras : {}, out = [];
  if (!lista.length) return out;
  (cuenta && Array.isArray(cuenta.lineas) ? cuenta.lineas : []).forEach((l, pos) => {
    if (!l || !l.enviado || !(+l.cantidad > 0)) return;
    const imp = impresoraDeLista(lista, prods.find(x => x && x.id === l.producto_id), cats, terminal, ex);
    if (imp) out.push({ ...l, imp, pos });
  });
  return out;
}
// El aviso cuando la comanda no salió (W-4). 4.31: con { saleSola: true } (la comanda era de una impresora USB o de red y la imprime sola
// la estación de comandas de la caja o de la cocina) el texto lo dice; sin la opción, el texto de siempre.
export function avisoComandaNoImpresa(motivos, opciones) {
  const m = (Array.isArray(motivos) ? motivos : [motivos]).map(x => String(x || '').trim().replace(/[.\s]+$/, '')).filter(Boolean).join('; ') || 'no se pudo imprimir';
  if (opciones && opciones.saleSola) return 'Pedido aceptado. La comanda no se imprimió en este equipo (' + m + '): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.';
  return 'Pedido aceptado. La comanda no se imprimió: ' + m + '. Imprímala desde Punto de venta › Cocina.';
}

// ---- 4.31: estación de comandas (la comanda de un pedido en línea siempre sale; diseño exe430/diseno_estacion.md) ----
// El servidor guarda una copia fija de la comanda de cada pedido en línea (GET /api/pos/comanda/pendientes) y cada plato se reclama antes
// de imprimirlo (POST /api/pos/comanda/reclamar, /impresa, /soltar): un plato lo imprime una sola computadora. Este módulo sigue sin
// importar app.js ni _datos.js: las llamadas reciben `pedir` (api() de api.js) como primer parámetro, como pedirNumeroComanda.
// Los textos que ve el usuario al aceptar un pedido (pantalla de Pedidos, 5.4 del diseño)
export const MOTIVO_LECTURA_TARDE = 'no se pudo leer a tiempo la configuración de impresión';
export const MOTIVO_SIN_RESERVA = 'no hubo conexión con el servidor para reservar la impresión';
export const MOTIVO_SIN_AGENTE = 'este equipo no tiene el programa de escritorio ni el agente de impresión abiertos';
export function textoAceptadoOcupada(nombre) { return 'Pedido aceptado. La comanda la está imprimiendo «' + String(nombre || 'otra computadora') + '».'; }
export function textoAceptadoMasTarde(hora) { return 'Pedido aceptado para las ' + String(hora || '') + '. La comanda saldrá sola en la computadora de la caja o de la cocina 45 minutos antes.'; }
// El identificador de esta pestaña (32 caracteres de 0-9a-f); el servidor acepta de 8 a 64 de [A-Za-z0-9_-]
export function nuevoEquipo() {
  try { if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') return globalThis.crypto.randomUUID().replace(/-/g, ''); } catch { /* sigue con los bytes al azar */ }
  const b = new Uint8Array(16);
  try { globalThis.crypto.getRandomValues(b); } catch { for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256); }
  return [...b].map(x => x.toString(16).padStart(2, '0')).join('');
}
// La cantidad como texto en la huella: hasta 3 decimales, sin ceros de más (2 → «2», 1.50 → «1.5»)
export function cantidadHuella(c) { const n = Math.round((+c || 0) * 1000) / 1000; return String(Object.is(n, -0) ? 0 : n); }
// La huella de una línea: «detalle|enviado|nota|cantidad» (la misma comparación que cocina.js mismaLinea)
export function huellaLinea(l) { const x = l || {}; return [String(x.detalle ?? ''), String(x.enviado || ''), String(x.nota || ''), String(+(x.cantidad ?? 0))].join('|'); }   /* 4.31: exactamente la del servidor (comandas.huella, contrato 5.1) */
// ¿La línea de la cuenta (pos_espera) es ese plato de la copia? Se compara campo por campo (detalle, nota, cantidad y la hora de envío,
// que en la copia es `creado`), sin depender de cómo escribe el servidor la huella.
export function esLineaDeCopia(l, c, copia) { return !!(l && c) && String(l.detalle ?? '') === String(c.detalle ?? '') && String(l.nota || '') === String(c.nota || '') && cantidadHuella(l.cantidad) === cantidadHuella(c.cantidad) && String(l.enviado || '') === String((copia && copia.creado) || ''); }
// Las posiciones de la copia que corresponden a esas líneas de la cuenta (cada plato de la copia, una sola vez)
export function posicionesDeCopia(lineas, copia) {
  const usadas = new Set(), out = [];
  for (const l of Array.isArray(lineas) ? lineas : []) {
    const c = ((copia && Array.isArray(copia.lineas)) ? copia.lineas : []).find(x => x && !usadas.has(x.pos) && esLineaDeCopia(l, x, copia));
    if (c) { usadas.add(c.pos); out.push(c.pos); }
  }
  return out;
}
// Los platos que alguien está imprimiendo en esta pestaña ahora mismo («pedido|pos»): los comparten la estación, Cocina y Pedidos
export const EN_CURSO = new Set();
export function claveEnCurso(pedidoId, pos) { return String(pedidoId) + '|' + String(pos); }
// Una promesa con tope: pasado `ms`, devuelve `valor` (la promesa sigue sola; su resultado ya no se usa)
export function conTope(promesa, ms, valor) {
  let t = null;
  return Promise.race([Promise.resolve(promesa), new Promise(r => { t = setTimeout(() => r(valor), ms); })]).finally(() => { if (t !== null) clearTimeout(t); });
}
const corto = (s, n) => String(s ?? '').slice(0, n);
// Ninguna de las cuatro llamadas lanza: { resultado, … } del servidor, { resultado: 'sin_red', motivo } sin conexión, o
// { resultado: 'error', status, motivo } si el servidor respondió con un error (400, 401, 403…). 404 = servidor anterior a la 4.31: 'sin_ruta'.
async function llamarComanda(pedir, url, opt) {
  try {
    if (typeof pedir !== 'function') return { resultado: 'sin_red', motivo: 'sin conexión con el servidor' };
    const r = await pedir(url, opt);
    return r && typeof r === 'object' && !Array.isArray(r) ? r : { resultado: 'sin_ruta' };
  } catch (e) {
    const motivo = String((e && e.message) || e || 'sin conexión con el servidor').trim();
    if (e && e.status === 404) return { resultado: 'sin_ruta', motivo };
    return e && e.status ? { resultado: 'error', status: e.status, motivo } : { resultado: 'sin_red', motivo };
  }
}
const posiciones = l => (Array.isArray(l) ? l : []).map(Number).filter(n => Number.isInteger(n) && n >= 0).slice(0, 200);
export function reclamarComanda(pedir, { pedido_id, lineas, grupo, grupo_nombre, equipo, nombre, momento } = {}) {
  return llamarComanda(pedir, '/api/pos/comanda/reclamar', { method: 'POST', body: { pedido_id: +pedido_id, lineas: posiciones(lineas), grupo: corto(grupo, 64), grupo_nombre: corto(grupo_nombre, 60), equipo: corto(equipo, 64), nombre: corto(nombre, 60), momento } });
}
export function marcarComandaImpresa(pedir, { pedido_id, equipo, lineas, sin_comanda } = {}) {
  return llamarComanda(pedir, '/api/pos/comanda/impresa', { method: 'POST', body: { pedido_id: +pedido_id, equipo: corto(equipo, 64), lineas: posiciones(lineas), sin_comanda: posiciones(sin_comanda) } });
}
export function soltarComanda(pedir, { pedido_id, equipo, lineas, motivo } = {}) {
  return llamarComanda(pedir, '/api/pos/comanda/soltar', { method: 'POST', body: { pedido_id: +pedido_id, equipo: corto(equipo, 64), lineas: posiciones(lineas), motivo: corto(motivo, 300) } });
}
// 4.31: ¿la marca «impresa» no llegó y hay que volver a mandarla? Sin conexión, el servidor caído u ocupado (5xx, 429, 408) o la sesión
// vencida (401). Un 400 o un 403 no se arreglan solos: no se reintentan.
export function marcaPorReintentar(r) { const st = r && +r.status; return !r || r.resultado === 'sin_red' || (r.resultado === 'error' && (!st || st >= 500 || st === 401 || st === 408 || st === 429)); }
// Las copias pendientes (o la de un pedido): { resultado: 'ok', ahora, copias: [...] }; sin la lista en la respuesta = 'sin_ruta'
export async function pendientesComanda(pedir, { pedido_id } = {}) {
  const id = +pedido_id, r = await llamarComanda(pedir, '/api/pos/comanda/pendientes' + (Number.isInteger(id) && id > 0 ? '?pedido_id=' + id : ''));
  if (r.resultado) return r;
  return Array.isArray(r.copias) ? { resultado: 'ok', ahora: r.ahora || '', copias: r.copias.filter(c => c && typeof c === 'object') } : { resultado: 'sin_ruta' };
}
// ¿El plato de la copia se puede intentar ahora? Libre, soltado o con el reclamo vencido (con la hora del servidor, `ahora`). Para la
// estación (paraEstacion) un plato soltado 3 veces ya no: lo imprime Cocina a mano. Cocina a mano (incluirReclamadas) también intenta los
// reclamados vigentes: el servidor responde «ocupada» y se pregunta.
export function platoLibre(l, ahora, paraEstacion, incluirReclamadas) {
  const e = (l && l.estado) || 'libre';
  if (e === 'impresa') return false;
  if (e === 'reclamada') { if (incluirReclamadas) return true; const v = Date.parse(l.vence || ''), a = Date.parse(ahora || ''); return !isNaN(v) && !isNaN(a) && v < a; }
  if (e === 'soltada' && paraEstacion && +l.intentos >= 3) return false;
  return true;
}
// La nota de la comanda: la del pedido y, si es para más tarde, «PARA LAS 19:00» (si el servidor no la puso ya)
export function notaDeCopia(copia) {
  const n = String((copia && copia.nota) || '').trim(), h = String((copia && copia.hora_entrega) || '').trim();
  return h && !n.toUpperCase().includes('PARA LAS') ? (n ? n + ' · ' : '') + 'PARA LAS ' + h : n;
}
// Los grupos por impresora de los platos libres de la copia, con la caja de la copia (cajaDe) y las reglas de hoy (impresoraDeLista): caja
// con «imprimir la comanda» apagado → todo «sin comanda»; plato o categoría «none» → «sin comanda»; sin impresoras de comanda → todo «sin
// comanda». Pura. { caja, grupos: [{ id, imp, directo, pos: [n], lineas: [{…plato de la copia, imp}] }], sin_comanda: [n] }. `directo` =
// la impresora como vale en esta computadora (impresoraAqui) es USB o de red.
// 4.31: con `soloRestaurante` (negocio que no es restaurante: la estación, como el aceptar, que solo imprime con menú) una caja que no está
// en modo restaurante no imprime comandas: todo «sin comanda».
export function gruposDeCopia(copia, { impresoras, categorias, extras, productos, cfg, ahora, paraEstacion, incluirReclamadas, soloRestaurante } = {}) {
  const caja = cajaDe(cfg, copia ? copia.terminal_id : null), out = { caja, grupos: [], sin_comanda: [] };
  const platos = (copia && Array.isArray(copia.lineas) ? copia.lineas : []).filter(l => l && Number.isInteger(+l.pos) && +l.cantidad > 0);
  const yaSin = new Set(posiciones(copia && copia.sin_comanda));
  const lista = impresorasDeComanda(impresoras), cats = (Array.isArray(categorias) ? categorias : []).filter(c => c && c.nombre), prods = Array.isArray(productos) ? productos : [];
  const ex = extras && typeof extras === 'object' ? extras : {}, porId = {};
  const noImprime = caja.imprimir_comanda === false || !lista.length || (!!soloRestaurante && caja.modo !== 'restaurante');
  for (const l of platos) {
    const pos = +l.pos; if (yaSin.has(pos) || !platoLibre(l, ahora, paraEstacion, incluirReclamadas)) continue;
    const imp = noImprime ? null : impresoraDeLista(lista, prods.find(x => x && x.id === l.producto_id), cats, caja, ex);
    if (!imp) { out.sin_comanda.push(pos); continue; }
    const g = porId[imp.id] || (porId[imp.id] = { id: String(imp.id), imp, directo: porAgente(impresoraAqui(imp)), pos: [], lineas: [] });
    g.pos.push(pos); g.lineas.push({ ...l, imp });
  }
  out.grupos = Object.values(porId);
  return out;
}
// Imprime UN grupo de la copia (impresora directa o la ventana dada) con el documento de siempre. { impresas: [pos], fallas: [motivos] }; nunca lanza.
export async function imprimirGrupoCopia(copia, grupos, { ventana = null, respaldoNavegador = false, local = false } = {}) {
  const lineas = (Array.isArray(grupos) ? grupos : [grupos]).flatMap(g => (g && Array.isArray(g.lineas) ? g.lineas : []));
  const r = await imprimirComandas({ cuenta: { nombre: (copia && copia.nombre) || ('Pedido #' + ((copia && (copia.pedido_numero || copia.pedido_id)) || '')), nota: notaDeCopia(copia) }, ronda: 1, lineas, numero: copia && Number.isInteger(+copia.numero) && +copia.numero >= 1 ? +copia.numero : null, icono: '🌐', desde: copia ? copia.creado : null, local, respaldoNavegador, ventana });
  return { impresas: r.impresas.map(l => +l.pos).filter(n => Number.isInteger(n)), fallas: r.fallas };
}
