// Punto de venta › Cierres de caja: sesiones abiertas y cerradas por caja y cajero, arqueo (efectivo esperado vs contado),
// diferencias, retiros y reporte Z (PDF/Word) con las ventas por medio de pago.
import { money, fmt, fecha, fechaHora, hoy, toast, mock } from '../../api.js';
import { cajas, resumenCaja, nombreMedio, MEDIOS, ventasDe, porCajero, corteCaja, veResultadoCaja, cierreCiego, opcionesCierre, colillaDeLaCaja, terminalDeCaja } from './_datos.js';
import { descargarReporte, imprimirReporte, impresorasReporte, cargarImpresorasReporte } from '../reportes/_montos.js';
import { sesion } from '../../app.js';
import { api, red } from '../../api.js';                 // 3.87: cierre (Z) por correo al dueño
import { config as configPos, impresoras } from './_datos.js';
import { porAgente, imprimirAgente, docColilla, cargarEquipo, impresoraTiqueteAqui, avisoImpresion } from './_agente.js';   // 4.2: colilla del cierre; 4.25: la impresión de esta computadora
import { cuentasActivas } from '../bancos/cuentas.js';
import { store } from '../../app.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const DENOM = [20000, 10000, 5000, 2000, 1000, 500, 100, 50, 25, 10, 5];   // 4.2: billetes y monedas de colones para contar la gaveta

// 3.87: el contenido del Z (lo usan la descarga en PDF/Word y el correo al dueño)
export function datosCierre(c) {
  const r = resumenCaja(c), M = v => money(v || 0);
  const medios = Object.entries(r.porMedio).map(([k, v]) => ({ medio: nombreMedio(k), monto: M(v) }));
  const ventas = ventasDe(c).map(v => ({ hora: fechaHora(v.hora), consecutivo: v.consecutivo, cliente: (v.cliente || 'Consumidor final') + (v.anulada ? ' (anulada)' : ''), medios: (v.medios || []).map(m => nombreMedio(m.medio) + ' ' + money(m.monto)).concat(+v.fiado > 0 ? [nombreMedio('fiado') + ' ' + money(v.fiado)] : []).join(', '), total: M(v.total) }));   // 3.87: la venta fiada muestra lo fiado en «Pago»
  const retiros = (c.retiros || []).filter(x => x.tipo !== 'proveedor').map(x => ({ hora: fechaHora(x.hora), motivo: x.motivo + (x.cuenta_destino ? ' → ' + x.cuenta_destino : ''), monto: M(x.monto) }));
  const entradas = (c.entradas || []).map(x => ({ hora: fechaHora(x.hora), motivo: x.motivo + (x.cuenta_origen ? ' ← ' + x.cuenta_origen : ''), monto: M(x.monto) }));   // 4.2
  const pagosProv = (c.retiros || []).filter(x => x.tipo === 'proveedor').map(x => ({ hora: fechaHora(x.hora), proveedor: x.proveedor || '', documento: x.documento || '', registro: x.pago || (x.por_registrar ? 'Por registrar en Gastos' : ''), monto: M(x.monto) }));
  const arqueo = [{ d: 'Efectivo inicial', v: M(c.monto_inicial) }, { d: 'Ventas y abonos en efectivo', v: M(r.porMedio['01'] || 0) }, ...(r.propinas_efectivo ? [{ d: 'Propinas en efectivo (en la gaveta)', v: M(r.propinas_efectivo) }] : []), ...(r.dolares ? [{ d: 'Vuelto en colones de los pagos en dólares', v: '−' + M(r.vuelto_usd) }] : []), ...(r.entradas ? [{ d: 'Entradas de efectivo', v: M(r.entradas) }] : []), { d: 'Retiros y depósitos', v: '−' + M(r.salidas) }, ...(r.pagos_proveedor ? [{ d: 'Pagos a proveedores', v: '−' + M(r.pagos_proveedor) }] : []), { d: 'Efectivo esperado', v: M(r.efectivo_esperado) }, { d: 'Efectivo contado', v: c.conteo === null || c.conteo === undefined ? '—' : M(c.conteo) }, { d: 'Diferencia', v: c.diferencia === null || c.diferencia === undefined ? '—' : M(c.diferencia) },
    ...(r.dolares ? [{ d: 'Dólares esperados en la gaveta', v: money(r.dolares, 'USD') }, { d: 'Dólares contados', v: c.conteo_usd === null || c.conteo_usd === undefined ? '—' : money(c.conteo_usd, 'USD') }, { d: 'Diferencia en dólares', v: c.diferencia_usd === null || c.diferencia_usd === undefined ? '—' : money(c.diferencia_usd, 'USD') }] : [])];
  const secciones = [{ titulo: 'Arqueo de efectivo', columnas: [{ key: 'd', label: 'Concepto' }, { key: 'v', label: 'Monto', num: true }], filas: arqueo },
    { titulo: 'Ventas por medio de pago', columnas: [{ key: 'medio', label: 'Medio' }, { key: 'monto', label: 'Monto', num: true }], filas: medios, totales: [{ t: 'Total vendido', v: M(r.total) }] },
    { titulo: 'Ventas (' + r.ventas + ')', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'consecutivo', label: 'Comprobante' }, { key: 'cliente', label: 'Cliente' }, { key: 'medios', label: 'Pago' }, { key: 'total', label: 'Total', num: true }], filas: ventas }];
  if (c.estado === 'Cerrada') {   // 4.2: el corte: lo que registró el sistema contra lo que declaró el cajero, por medio de pago
    const k = corteCaja(c, r), D = (f, v) => (v === null || v === undefined ? '—' : money(v, f.usd ? 'USD' : 'CRC'));
    secciones.splice(1, 0, { titulo: 'Corte por medio de pago', columnas: [{ key: 'medio', label: 'Medio' }, { key: 'sistema', label: 'Sistema', num: true }, { key: 'declarado', label: 'Declarado', num: true }, { key: 'diferencia', label: 'Diferencia', num: true }, { key: 'estado', label: 'Resultado' }],
      filas: k.filas.map(f => ({ medio: f.nombre, sistema: D(f, f.sistema), declarado: D(f, f.declarado), diferencia: D(f, f.diferencia), estado: f.diferencia === null ? 'No declarado' : f.diferencia < -0.005 ? 'Faltante' : f.diferencia > 0.005 ? 'Sobrante' : 'Cuadra' })),
      totales: [{ t: 'Faltante', v: M(-k.faltante) }, { t: 'Sobrante', v: M(k.sobrante) }] });
  }
  if (retiros.length) secciones.push({ titulo: 'Retiros y depósitos', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'motivo', label: 'Motivo' }, { key: 'monto', label: 'Monto', num: true }], filas: retiros, totales: [{ t: 'Total retirado', v: M(r.salidas) }] });
  if (entradas.length) secciones.push({ titulo: 'Entradas de efectivo', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'motivo', label: 'Motivo' }, { key: 'monto', label: 'Monto', num: true }], filas: entradas, totales: [{ t: 'Total de entradas', v: M(r.entradas) }] });
  if (pagosProv.length) secciones.push({ titulo: 'Pagos a proveedores desde la caja', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'proveedor', label: 'Proveedor' }, { key: 'documento', label: 'Documento' }, { key: 'registro', label: 'Registro' }, { key: 'monto', label: 'Monto', num: true }], filas: pagosProv, totales: [{ t: 'Total pagado', v: M(r.pagos_proveedor) }] });
  if (r.propinas) secciones.push({ titulo: 'Propinas (aparte del comprobante)', columnas: [{ key: 'd', label: 'Concepto' }, { key: 'v', label: 'Monto', num: true }], filas: [{ d: 'En efectivo (en la gaveta)', v: M(r.propinas_efectivo) }, { d: 'Con tarjeta, SINPE o transferencia (en Bancos)', v: M(r.propinas - r.propinas_efectivo) }], totales: [{ t: 'Total de propinas', v: M(r.propinas) }] });
  if (r.porSalonero.some(s => s.salonero !== '—')) secciones.push({ titulo: 'Ventas por salonero', columnas: [{ key: 'salonero', label: 'Salonero' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true }, { key: 'propinas', label: 'Propinas', num: true }], filas: r.porSalonero.map(s => ({ ...s, total: M(s.total), propinas: M(s.propinas) })) });
  const cajeros = porCajero(c);   // turnos y ventas por cajero (3.23)
  if (cajeros.length > 1 || (c.turnos || []).length) secciones.push({ titulo: 'Ventas por cajero', columnas: [{ key: 'usuario', label: 'Cajero' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true }], filas: cajeros.map(x => ({ ...x, total: M(x.total) })) });
  if ((c.turnos || []).length) secciones.push({ titulo: 'Turnos (arqueos parciales)', columnas: [{ key: 'usuario', label: 'Cajero' }, { key: 'periodo', label: 'Turno' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'esperado', label: 'Esperado', num: true }, { key: 'conteo', label: 'Contado', num: true }, { key: 'diferencia', label: 'Diferencia', num: true }], filas: (c.turnos || []).map(t => ({ usuario: t.usuario, periodo: fechaHora(t.inicio) + ' – ' + fechaHora(t.fin), ventas: String(t.ventas || 0), esperado: M(t.esperado), conteo: M(t.conteo), diferencia: M(t.diferencia) })) });
  if (r.abonos) secciones.push({ titulo: 'Abonos a cuentas por cobrar', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'consecutivo', label: 'Abono' }, { key: 'cliente', label: 'Cliente' }, { key: 'total', label: 'Monto', num: true }], filas: ventasDe(c).filter(v => v.abono).map(v => ({ hora: fechaHora(v.hora), consecutivo: v.consecutivo, cliente: v.cliente || '', total: M(v.total) })), totales: [{ t: 'Total abonado', v: M(r.abonos) }] });
  if ((c.autorizaciones || []).length) secciones.push({ titulo: 'Autorizaciones de supervisor', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'usuario', label: 'Cajero' }, { key: 'accion', label: 'Acción' }, { key: 'mesa', label: 'Cuenta' }], filas: c.autorizaciones.map(a => ({ hora: fechaHora(a.hora), usuario: a.usuario || '', accion: a.accion, mesa: a.mesa || '' })) });
  const anuladas = ventasDe(c).filter(v => v.anulada);   // 3.87: anulaciones y devoluciones de la sesión (no suman en lo vendido)
  if (anuladas.length) secciones.push({ titulo: 'Anulaciones (' + anuladas.length + ')', columnas: [{ key: 'hora', label: 'Hora' }, { key: 'consecutivo', label: 'Comprobante' }, { key: 'nc', label: 'Nota de crédito' }, { key: 'motivo', label: 'Motivo' }, { key: 'total', label: 'Monto', num: true }], filas: anuladas.map(v => ({ hora: fechaHora(v.anulada_hora || v.hora), consecutivo: v.consecutivo, nc: v.nc_consecutivo || '—', motivo: (v.motivo_anulacion || '') + (v.anulada_por ? ' · ' + v.anulada_por : ''), total: M(v.total) })), totales: [{ t: 'Total anulado', v: M(anuladas.reduce((s, v) => s + (+v.total || 0), 0)) }] });
  return { titulo: ('Cierre de caja · ' + c.caja + ' · ' + fecha(c.fecha)).slice(0, 120), subtitulo: ('Cajero ' + (c.usuario || '—') + ' · abierta ' + fechaHora(c.abierta_en) + (c.cerrada_en ? ' · cerrada ' + fechaHora(c.cerrada_en) : ' · ABIERTA') + (c.notas ? ' · ' + c.notas : '')).slice(0, 300),
    periodo: fecha(c.fecha), kpis: [{ t: 'Ventas', v: String(r.ventas) }, { t: 'Total vendido', v: M(r.total) }, { t: 'Efectivo esperado', v: M(r.efectivo_esperado) }, { t: 'Diferencia', v: c.diferencia === null || c.diferencia === undefined ? '—' : M(c.diferencia) }],
    cols: [], rows: [], secciones, nota: 'Reporte de cierre (Z) del punto de venta. Los comprobantes electrónicos se consultan en Ingresos › Facturas de venta.', archivo: 'cierre_caja_' + c.id };
}
export function documentoCierre(c, formato) { return descargarReporte(formato, datosCierre(c)); }
// 3.87: el mismo Z como lo recibe el servidor para el PDF del correo (textos ya formateados)
export function cuerpoCorreoCierre(d) {
  return { titulo: d.titulo, subtitulo: d.subtitulo || null, periodo: d.periodo || null, nota: d.nota || null, kpis: (d.kpis || []).map(k => ({ t: String(k.t), v: String(k.v) })),
    secciones: (d.secciones || []).map(s => ({ titulo: String(s.titulo).slice(0, 120), columnas: s.columnas.map(c => ({ key: c.key, label: c.label, num: !!c.num })), filas: s.filas.slice(0, 5000).map(r => Object.fromEntries(s.columnas.map(c => [c.key, String(r[c.key] ?? '')]))), totales: (s.totales || []).map(k => ({ t: String(k.t), v: String(k.v) })), nota: s.nota || null })) };
}

export default {
  props: ['params'],
  data() { return { listo: false, lista: cajas(), cerrar: null, ver: null, resultado: null, MEDIOS, DENOM, enviando: null, red, impsListas: false }; },
  async created() {
    if (await mock.completar('pos_ventas')) { this.listo = true; this.lista = cajas(); } this.reintentarCorreos();
    const id = this.params && this.params.cerrar, c = id ? this.lista.find(x => String(x.id) === String(id) && x.estado === 'Abierta') : null;   // 4.2: «Cerrar caja» desde la caja
    if (c) this.abrirCierre(c);
  },   // las sesiones viejas muestran sus ventas (3.73); 3.87: correos del cierre que quedaron sin conexión
  mounted() { cargarImpresorasReporte().then(() => { this.impsListas = true; }); },   // 9c (J1): en el programa, las impresoras como valen en esta computadora
  watch: { 'red.enLinea'(v) { if (v) this.reintentarCorreos(); } },
  computed: {
    rows() { return this.lista.slice().sort((a, b) => b.id - a.id).map(c => { const r = resumenCaja(c); return { ...c, ventas_n: r.ventas, total: r.total, esperado: r.efectivo_esperado, dif: c.diferencia }; }); },
    columnasTodas() { return [{ key: 'caja', label: 'Caja', link: r => this.ver = r }, { key: 'usuario', label: 'Cajero' }, { key: 'abierta_en', label: 'Apertura', fmt: v => fechaHora(v) }, { key: 'cerrada_en', label: 'Cierre', fmt: v => v ? fechaHora(v) : '—' }, { key: 'ventas_n', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true, fmt: 'money' }, { key: 'esperado', label: 'Efectivo esperado', num: true, fmt: 'money' }, { key: 'dif', label: 'Diferencia', num: true, fmt: v => v === null || v === undefined ? '—' : money(v) }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    resumenCerrar() { return this.cerrar ? resumenCaja(this.cerrar.c) : null; },
    verRes() { return veResultadoCaja(); },   // 4.2: lo esperado, el faltante y el sobrante: solo quien ve todo o configura
    columns() { return this.verRes ? this.columnasTodas : this.columnasTodas.filter(c => !['total', 'esperado', 'dif'].includes(c.key)); },
    hayDolares() { return !!(this.cerrar && this.resumenCerrar && this.resumenCerrar.dolares); },
    puedeCorregir() { return sesion.puede('cobros') || sesion.puede('configurar'); },   // 3.87: reabrir o borrar un cierre hecho (el servidor también lo exige)
    difCerrar() { return this.cerrar && this.cerrar.conteo !== null && this.cerrar.conteo !== '' ? r2(+this.cerrar.conteo - this.resumenCerrar.efectivo_esperado) : null; },
  },
  methods: {
    porCajero,
    money, fmt, fecha, fechaHora, nombreMedio, resumenCaja, ventasDe,
    abrirCierre(c) { this.ver = null; this.cerrar = { c, conteo: null, conteo_usd: null, notas: '', medios: { '02': null, '06': null, '04': null }, billetes: null, ciego: cierreCiego(c), porBanco: false, bancos: (l => (l.length ? l : [{ nombre: '', monto: null }, { nombre: '', monto: null }]))(cuentasActivas().filter(b => b.tipo === 'Banco').map(b => ({ nombre: b.nombre, monto: null }))) }; },   // el cajero no ve Bancos: filas con nombre libre
    // 4.2: el cierre del datáfono por banco (cuando hay más de un datáfono): la suma es lo declarado en Tarjeta
    sumarBancos() { const k = this.cerrar; if (!k || !k.porBanco) return; const con = k.bancos.filter(b => b.monto !== null && b.monto !== '' && b.monto !== undefined); k.medios['02'] = con.length ? r2(con.reduce((s, b) => s + (+b.monto || 0), 0)) : null; },
    terminalDe(c) { return terminalDeCaja(c); },   // 4.41: la misma regla que las opciones del cierre (el nombre solo en sesiones viejas sin id)
    // 4.2: colilla del cierre (A = cajero, B = sistema, faltante/excedente, resumen): impresora térmica del agente si la caja la tiene; si no, el navegador.
    // 4.41: con ciego completo (opción de la caja) la colilla que imprime el cajero lleva solo lo que declaró; quien ve resultados la imprime completa.
    // deLaCaja (la que sale sola al cerrar): la colilla propia de la caja, sin importar quién cierra. La completa que la caja no da a su cajero
    // no va a la impresora de la caja (saldría delante del cajero): va a la de tiquetes elegida en esta computadora o al navegador.
    async imprimirColilla(c, { deLaCaja = false } = {}) {
      const r = resumenCaja(c), k = corteCaja(c, r), propia = colillaDeLaCaja(c), completa = deLaCaja ? propia : opcionesCierre(c).colilla, t = this.terminalDe(c), deCaja = t && t.impresora_comprobante_id ? impresoras().find(i => String(i.id) === String(t.impresora_comprobante_id) && i.activa !== false && i.uso !== 'etiquetas') : null;   // 4.24: la de etiquetas no recibe la colilla
      if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});
      const imp = impresoraTiqueteAqui(completa && !propia ? null : deCaja, impresoras());   // 4.25: en el programa, la de tiquetes de esta computadora (o la de la caja como está conectada aquí)
      if (porAgente(imp)) { try { await imprimirAgente(imp, docColilla({ empresa: store.empresa, caja: c, corte: k, resumen: { ...r, nombreMedio }, cajero: c.cerrada_por || c.usuario, M: money, completa })); return; } catch (e) { toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre la colilla en el navegador.', 'err'); } }
      const e = store.empresa || {}, esc = x => String(x ?? '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch])), D = (f, v) => (v === null || v === undefined ? '—' : money(v, f.usd ? 'USD' : 'CRC'));
      const cab = '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Cierre de caja</title><style>body{font-family:monospace;font-size:12px;width:300px;margin:12px auto}h2,h3{text-align:center;margin:4px 0}table{width:100%;border-collapse:collapse}td,th{padding:2px 0;vertical-align:top;font-size:11px}th{text-align:left;border-bottom:1px solid #000}.n{text-align:right}.b{font-weight:700}.c{text-align:center}.firma{margin-top:28px;text-align:center}</style></head><body>'
        + '<h2>' + esc(e.nombre_comercial || e.nombre || '') + '</h2><h3>CIERRE DE CAJA · ' + esc(c.caja) + '</h3><div class="c">' + esc(fechaHora(c.cerrada_en)) + '<br>Cajero: ' + esc(c.cerrada_por || c.usuario || '') + '</div><hr>';
      const pie = (c.notas_cierre ? '<hr><div>Notas: ' + esc(c.notas_cierre) + '</div>' : '') + '<div class="firma">______________________<br>Entrega (cajero)</div><div class="firma">______________________<br>Recibe (administración)</div></body></html>';
      let html;
      if (!completa) {
        const dec = k.filas.filter(f => f.declarado !== null && f.declarado !== undefined).map(f => '<tr><td>' + esc(f.nombre) + '</td><td class="n b">' + esc(D(f, f.declarado)) + '</td></tr>').join('');
        html = cab + '<h3>Lo declarado por el cajero</h3><table>' + dec + '</table>' + pie.replace('<div class="firma">', '<hr><div class="c">El corte lo revisa la administración</div><div class="firma">');
      } else {
        const filas = k.filas.map(f => '<tr><td>' + esc(f.nombre) + '</td><td class="n">' + esc(D(f, f.declarado)) + '</td><td class="n">' + esc(D(f, f.sistema)) + '</td><td class="n b">' + esc(D(f, f.diferencia)) + '</td></tr>').join('');
        const res = [['Fondo inicial', money(c.monto_inicial)], ['Ventas (' + r.ventas + ')', money(r.total)], ...Object.entries(r.porMedio).map(([m, v]) => ['&nbsp;&nbsp;' + esc(nombreMedio(m)), money(v)]), ...(r.abonos ? [['Abonos a cuentas por cobrar', money(r.abonos)]] : []), ...(r.entradas ? [['Entradas de efectivo', money(r.entradas)]] : []),
          ...(r.salidas ? [['Retiros y depósitos', '−' + money(r.salidas)]] : []), ...(r.pagos_proveedor ? [['Pagos a proveedores', '−' + money(r.pagos_proveedor)]] : []), ...(r.propinas ? [['Propinas', money(r.propinas)]] : [])].map(([a, b]) => '<tr><td colspan="3">' + a + '</td><td class="n">' + esc(b) + '</td></tr>').join('');
        html = cab + '<table><tr><th>Medio</th><th class="n">A cajero</th><th class="n">B sistema</th><th class="n">Dif.</th></tr>' + filas + '</table><hr>'
          + '<table><tr class="b"><td colspan="3">FALTANTE</td><td class="n">' + esc(money(-k.faltante)) + '</td></tr><tr class="b"><td colspan="3">EXCEDENTE</td><td class="n">' + esc(money(k.sobrante)) + '</td></tr></table><hr><h3>Resumen del turno</h3><table>' + res + '</table>' + pie;
      }
      const w = window.open('', '_blank'); if (!w) return toast('Permita las ventanas emergentes para imprimir la colilla del cierre', 'err');
      w.document.write(html); w.document.close(); setTimeout(() => { try { w.print(); } catch {} }, 300);
    },
    corte(c) { return corteCaja(c, resumenCaja(c)); },
    opc(c) { return opcionesCierre(c); },   // 4.41: lo que este usuario ve del cierre según las opciones de la caja
    // 4.41: lo que declaró el cajero (sin lo del sistema): los medios que anotó y, del datáfono por banco, cada banco
    declaradoDe(c) { return this.corte(c).filas.filter(f => f.declarado !== null && f.declarado !== undefined); },
    resultadoDe(f) { return f.diferencia === null ? ['No declarado', ''] : f.diferencia < -0.005 ? ['Faltante', 'danger'] : f.diferencia > 0.005 ? ['Sobrante', 'warn'] : ['Cuadra', 'ok']; },
    alternarBilletes() { const k = this.cerrar; if (k.billetes) { k.billetes = null; return; } k.billetes = Object.fromEntries(DENOM.map(d => [d, null])); this.sumarBilletes(); },
    sumarBilletes() { const k = this.cerrar; if (!k || !k.billetes) return; k.conteo = r2(DENOM.reduce((s, d) => s + d * (+k.billetes[d] || 0), 0)); },
    difUsd() { const c = this.cerrar; if (!c || !this.resumenCerrar.dolares || c.conteo_usd === null || c.conteo_usd === '' || c.conteo_usd === undefined) return null; return r2(+c.conteo_usd - this.resumenCerrar.dolares); },
    confirmarCierre() {
      if (!mock.puedeGuardar()) return;
      const k = this.cerrar, { c, conteo, notas } = k;
      if (conteo === null || conteo === '') return toast('Indique el efectivo contado en la gaveta', 'err');
      // 4.2: lo declarado por medio (efectivo contado, cierre del datáfono, SINPE y transferencias); en blanco = no declarado
      const declarado = { '01': r2(conteo) };
      for (const m of ['02', '06', '04']) { const v = k.medios[m]; if (v !== null && v !== '' && v !== undefined) declarado[m] = r2(v); }
      const declaradoBancos = k.porBanco ? k.bancos.filter(b => b.monto !== null && b.monto !== '' && b.monto !== undefined).map((b, i) => ({ nombre: String(b.nombre || '').trim() || 'Datáfono ' + (i + 1), monto: r2(b.monto) })) : null;
      const dif = this.difCerrar;
      if (!k.ciego && Math.abs(dif) > 0.005 && !confirm('Hay una diferencia de ' + money(dif) + ' entre lo esperado y lo contado. ¿Cerrar de todos modos?')) return;
      const difUsd = this.difUsd();
      this.lista = mock.actualizar('pos_cajas', l => (l || []).map(x => (x.id === c.id ? { ...x, estado: 'Cerrada', cerrada_en: new Date().toISOString(), cerrada_por: sesion.usuario?.correo || '', conteo: r2(conteo), diferencia: dif, declarado, declarado_bancos: declaradoBancos, cierre_ciego: !!k.ciego,
        conteo_usd: k.conteo_usd === null || k.conteo_usd === '' || k.conteo_usd === undefined ? null : r2(k.conteo_usd), diferencia_usd: difUsd, notas_cierre: (notas || '').trim() } : x)), []);
      const cerrada = this.lista.find(x => x.id === c.id);
      this.cerrar = null; this.ver = null;
      // 4.41: el modal de Resultado muestra el corte completo solo si la caja lo permite (o quien cierra ve resultados); si no, solo lo que declaró
      this.resultado = cerrada || null;
      const o = cerrada ? opcionesCierre(cerrada) : null, kk = cerrada && o.corte ? this.corte(cerrada) : null;
      if (cerrada && !o.corte) toast('Caja cerrada. El corte lo revisa la administración.', 'ok');
      else toast('Caja cerrada' + (kk && (kk.faltante || kk.sobrante) ? ': faltante ' + money(-kk.faltante) + ' · excedente ' + money(kk.sobrante) : ' sin diferencias'), kk && kk.faltante ? 'err' : 'ok');
      if (cerrada && o.auto) this.imprimirColilla(cerrada, { deLaCaja: true });   // la colilla se deja con el dinero (4.41: si la caja la imprime sola; la de la caja, cierre quien cierre)
      if (cerrada) this.enviarCorreo(cerrada, true);   // 3.87: el Z al dueño; si falla, la caja queda cerrada igual
    },
    // 3.87: reporte de cierre (Z) en PDF a «Enviar el cierre a» de la caja (Configuración de la caja). Sin conexión queda pendiente y
    // sale al volver la red (al abrir esta pantalla o al reconectar).
    correoDe(c) { const l = configPos().terminales; const t = (c && c.terminal_id ? l.find(x => x.id === c.terminal_id) : null) || l.find(x => c && x.nombre === c.caja); return String((t && t.correo_cierre) || '').trim(); },
    async enviarCorreo(c, auto = false) {
      if (!c || c.estado !== 'Cerrada' || this.enviando === c.id) return;
      if (!this.correoDe(c)) { if (!auto) toast('Indique «Enviar el cierre a» en Punto de venta › Configuración de la caja', 'err'); return; }
      const marcar = cambios => { this.lista = mock.actualizar('pos_cajas', l => (l || []).map(x => (x.id === c.id ? { ...x, ...cambios } : x)), []); if (this.ver && this.ver.id === c.id) this.ver = this.lista.find(x => x.id === c.id) || null; };
      this.enviando = c.id;
      try {
        await mock.guardarTodo();                                  // el servidor ya ve la caja cerrada
        const r = await api('/api/pos/cierres/correo', { method: 'POST', body: { caja_id: c.id, ...cuerpoCorreoCierre(datosCierre(c)) } });
        marcar({ correo_z: { enviado: new Date().toISOString(), para: r.para }, correo_z_pendiente: false });
        toast('Cierre enviado por correo a ' + r.para.join(', '), 'ok');
      } catch (e) {
        if (e.sinConexion) { marcar({ correo_z_pendiente: true }); toast('Sin conexión: el cierre se enviará por correo cuando vuelva la red', 'err'); }
        else { if (c.correo_z_pendiente) marcar({ correo_z_pendiente: false }); toast('La caja quedó cerrada, pero el correo del cierre no salió. ' + e.message, 'err'); }
      }
      this.enviando = null;
    },
    reintentarCorreos() { if (!red.enLinea) return; for (const c of this.lista.filter(x => x.correo_z_pendiente && x.estado === 'Cerrada')) this.enviarCorreo(c, true); },
    reabrir(c) { if (!confirm('¿Reabrir la caja «' + c.caja + '»? Las nuevas ventas se sumarán a esta sesión.')) return; this.lista = mock.actualizar('pos_cajas', l => (l || []).map(x => (x.id === c.id ? { ...x, estado: 'Abierta', cerrada_en: null, conteo: null, diferencia: null,
      reaperturas: [...(x.reaperturas || []), { hora: new Date().toISOString(), usuario: sesion.usuario?.correo || '', cerrada_en: x.cerrada_en, conteo: x.conteo, diferencia: x.diferencia }] } : x)), []); this.ver = null; },   // 3.87: el conteo y el faltante originales no se pierden
    eliminar(c) { if (ventasDe(c).length) return toast('Una sesión con ventas no se elimina: ciérrela', 'err'); if (!confirm('¿Eliminar la sesión de caja sin ventas?')) return; this.lista = mock.actualizar('pos_cajas', l => (l || []).filter(x => x.id !== c.id), []); this.ver = null; },
    async documento(c, formato) { try { await documentoCierre(c, formato); } catch (e) { toast(e.message, 'err'); } },
    impresorasLista() { return this.impsListas ? impresorasReporte() : []; },   // 9c (J1): después de cargar lo de esta computadora
    async imprimirZ(c, imp) { try { const d = await imprimirReporte(datosCierre(c), imp || null, store.empresa); if (d === 'agente') toast('Cierre enviado a «' + imp.nombre + '»', 'ok'); } catch (e) { toast(avisoImpresion('No se imprimió: ', e), 'err'); } },   // 4.3; 9c (J4): sin repetir la impresora
  },
  template: `
  <div class="page" :data-listo="listo">
    <PageHead title="Cierres de caja" sub="Apertura y cierre por caja y cajero: se cuenta el efectivo, se declaran el datáfono, SINPE y transferencias, y el sistema hace el corte con el faltante o sobrante por medio de pago." :crumbs="[{label:'Punto de venta'},{label:'Cierres de caja'}]"><Atajo to="/pos/configuracion" label="Configurar la caja"></Atajo>
      <a class="btn" href="#/pos/caja">Ir a la caja</a>
    </PageHead>
    <div class="card pad0"><DataTable :rows="rows" :columns="columns" empty-title="Sin sesiones de caja" empty-text="La caja se abre desde Punto de venta › Caja al empezar el día." @row-click="ver=$event">
      <template #actions="{row}"><button class="btn sm" v-if="row.estado==='Abierta'" @click.stop="abrirCierre(row)">Cerrar caja</button><template v-if="verRes"><button class="btn sm sec" v-if="row.estado==='Cerrada'" @click.stop="resultado=row">Resultado</button><button class="btn sm sec" v-if="row.estado==='Cerrada' && correoDe(row)" @click.stop="enviarCorreo(row)" :disabled="enviando===row.id" :title="'Enviar el cierre a ' + correoDe(row)">✉ Correo</button><button class="btn sm sec" @click.stop="documento(row,'pdf')">⤓ PDF</button><button class="btn sm sec" @click.stop="documento(row,'docx')">⤓ Word</button></template><button class="btn icon" v-if="!row.ventas_n && (row.estado==='Abierta' || puedeCorregir)" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
      <template #empty><a class="btn" href="#/pos/caja">Ir a la caja</a></template>
    </DataTable></div>
    <Modal v-if="ver" :title="(String(ver.caja || '').toLowerCase().startsWith('caja') ? '' : 'Caja ') + ver.caja + ' · ' + fecha(ver.fecha)" lg @close="ver=null">
      <div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:10px"><span class="chip">{{ver.usuario}}</span><span class="chip">Abierta {{fechaHora(ver.abierta_en)}}</span><span class="chip" v-if="ver.cerrada_en">Cerrada {{fechaHora(ver.cerrada_en)}}</span><span class="chip on">{{ver.estado}}</span><span class="chip" v-if="ver.correo_z && ver.correo_z.enviado">✉ Enviado a {{(ver.correo_z.para || []).join(', ')}} · {{fechaHora(ver.correo_z.enviado)}}</span><span class="chip" v-else-if="ver.correo_z_pendiente">✉ Correo pendiente (sin conexión)</span></div>
      <template v-if="verRes">
        <div class="grid cols-2" style="align-items:start">
          <div><h3 style="margin:0 0 6px">Arqueo del efectivo</h3><div class="totals" style="align-items:stretch;margin:0"><div><span>Efectivo inicial</span><b>{{money(ver.monto_inicial)}}</b></div><div><span>Ventas y abonos en efectivo</span><b>{{money(resumenCaja(ver).porMedio['01'] || 0)}}</b></div><div v-if="resumenCaja(ver).propinas_efectivo"><span>Propinas en efectivo</span><b>{{money(resumenCaja(ver).propinas_efectivo)}}</b></div><div v-if="resumenCaja(ver).entradas"><span>Entradas de efectivo</span><b>{{money(resumenCaja(ver).entradas)}}</b></div><div v-if="resumenCaja(ver).dolares"><span>Vuelto en colones de pagos en dólares</span><b>−{{money(resumenCaja(ver).vuelto_usd)}}</b></div><div v-if="resumenCaja(ver).salidas"><span>Retiros y depósitos</span><b>−{{money(resumenCaja(ver).salidas)}}</b></div><div v-if="resumenCaja(ver).pagos_proveedor"><span>Pagos a proveedores</span><b>−{{money(resumenCaja(ver).pagos_proveedor)}}</b></div><div class="total"><span>Efectivo esperado</span><b>{{money(resumenCaja(ver).efectivo_esperado)}}</b></div><div v-if="resumenCaja(ver).dolares"><span>Dólares en la gaveta</span><b>{{money(resumenCaja(ver).dolares, 'USD')}}<span v-if="ver.conteo_usd !== null && ver.conteo_usd !== undefined"> · contados {{money(ver.conteo_usd, 'USD')}}</span></b></div><div v-if="ver.conteo !== null && ver.conteo !== undefined"><span>Contado</span><b>{{money(ver.conteo)}}</b></div><div v-if="ver.diferencia !== null && ver.diferencia !== undefined"><span>Diferencia</span><b :style="Math.abs(ver.diferencia) > 0.005 ? 'color:var(--danger)' : ''">{{money(ver.diferencia)}}</b></div></div></div>
          <div><h3 style="margin:0 0 6px">Por medio de pago</h3><table class="tbl"><tbody><tr v-for="(v,k) in resumenCaja(ver).porMedio" :key="k"><td>{{nombreMedio(k)}}</td><td class="num">{{money(v)}}</td></tr><tr><th>Total vendido ({{resumenCaja(ver).ventas}} ventas)</th><th class="num">{{money(resumenCaja(ver).total)}}</th></tr></tbody></table></div>
        </div>
        <template v-if="ver.estado==='Cerrada'"><h3 style="margin:14px 0 6px">Corte por medio de pago</h3><table class="tbl"><thead><tr><th>Medio</th><th class="num">Sistema</th><th class="num">Declarado</th><th class="num">Diferencia</th><th></th></tr></thead><tbody><tr v-for="f in corte(ver).filas" :key="f.medio"><td>{{f.nombre}}</td><td class="num">{{money(f.sistema, f.usd ? 'USD' : 'CRC')}}</td><td class="num">{{f.declarado === null ? '—' : money(f.declarado, f.usd ? 'USD' : 'CRC')}}</td><td class="num">{{f.diferencia === null ? '—' : money(f.diferencia, f.usd ? 'USD' : 'CRC')}}</td><td><span class="badge" :class="resultadoDe(f)[1]">{{resultadoDe(f)[0]}}</span></td></tr></tbody></table></template>
      </template>
      <div class="alert" v-else-if="ver.estado==='Cerrada'">Cierre registrado: el faltante o excedente lo revisa la administración. <button class="btn sm sec" @click="resultado=ver">{{opc(ver).corte ? 'Ver el corte' : 'Ver lo declarado'}}</button></div>
      <h3 style="margin:14px 0 6px">Ventas</h3>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Hora</th><th>Comprobante</th><th>Cliente</th><th>Pago</th><th class="num">Total</th></tr></thead><tbody><tr v-for="(v,i) in ventasDe(ver)" :key="i"><td class="small">{{fechaHora(v.hora)}}</td><td class="mono"><a :href="'#/ventas/facturas/' + v.doc_id">{{v.consecutivo}}</a></td><td>{{v.cliente || 'Consumidor final'}}<div class="small muted" v-if="v.mesa">{{v.mesa}}</div></td><td class="small">{{(v.medios||[]).map(m => nombreMedio(m.medio) + ' ' + money(m.monto)).concat(+v.fiado > 0 ? [nombreMedio('fiado') + ' ' + money(v.fiado)] : []).join(', ')}}</td><td class="num">{{money(v.total)}}</td></tr></tbody></table></div>
      <p class="muted small" v-if="!ventasDe(ver).length">Sin ventas en esta sesión.</p>
      <template v-if="resumenCaja(ver).propinas || resumenCaja(ver).porSalonero.some(s => s.salonero !== '—')"><h3 style="margin:14px 0 6px">Saloneros y propinas</h3><table class="tbl"><thead><tr><th>Salonero</th><th class="num">Ventas</th><th class="num">Vendido</th><th class="num">Propinas</th></tr></thead><tbody><tr v-for="s in resumenCaja(ver).porSalonero" :key="s.salonero"><td>{{s.salonero}}</td><td class="num">{{s.ventas}}</td><td class="num">{{money(s.total)}}</td><td class="num">{{money(s.propinas)}}</td></tr></tbody></table><p class="small muted" style="margin:6px 0 0">Propinas: {{money(resumenCaja(ver).propinas_efectivo)}} en efectivo (en la gaveta) · {{money(resumenCaja(ver).propinas - resumenCaja(ver).propinas_efectivo)}} con tarjeta, SINPE o transferencia (en Bancos). No van en el comprobante.</p></template>
      <template v-if="porCajero(ver).length > 1 || (ver.turnos||[]).length"><h3 style="margin:14px 0 6px">Cajeros y turnos</h3><table class="tbl"><thead><tr><th>Cajero</th><th class="num">Ventas</th><th class="num">Vendido</th></tr></thead><tbody><tr v-for="x in porCajero(ver)" :key="x.usuario"><td>{{x.usuario}}</td><td class="num">{{x.ventas}}</td><td class="num">{{money(x.total)}}</td></tr></tbody></table>
        <table class="tbl" v-if="(ver.turnos||[]).length" style="margin-top:6px"><thead><tr><th>Turno entregado por</th><th>Período</th><th class="num" v-if="verRes">Esperado</th><th class="num">Contado</th><th class="num" v-if="verRes">Diferencia</th></tr></thead><tbody><tr v-for="(t,i) in ver.turnos" :key="i"><td>{{t.usuario}}<div class="small muted" v-if="t.nota">{{t.nota}}</div></td><td class="small">{{fechaHora(t.inicio)}} – {{fechaHora(t.fin)}}</td><td class="num" v-if="verRes">{{money(t.esperado)}}</td><td class="num">{{money(t.conteo)}}</td><td class="num" v-if="verRes" :style="Math.abs(t.diferencia) > 0.005 ? 'color:var(--danger);font-weight:600' : 'color:var(--ok)'">{{money(t.diferencia)}}</td></tr></tbody></table></template>
      <template v-if="resumenCaja(ver).abonos"><h3 style="margin:14px 0 6px">Abonos a cuentas por cobrar <small>{{money(resumenCaja(ver).abonos)}} recibidos; entran a la caja sin contar como venta</small></h3></template>
      <template v-if="(ver.autorizaciones||[]).length"><h3 style="margin:14px 0 6px">Autorizaciones de supervisor</h3><table class="tbl"><tbody><tr v-for="(a,i) in ver.autorizaciones" :key="i"><td class="small">{{fechaHora(a.hora)}}</td><td class="small">{{a.usuario}}</td><td>{{a.accion}}</td><td class="small muted">{{a.mesa}}</td></tr></tbody></table></template>
      <template v-if="(ver.entradas||[]).length"><h3 style="margin:14px 0 6px">Entradas de efectivo</h3><table class="tbl"><tbody><tr v-for="(x,i) in ver.entradas" :key="i"><td class="small">{{fechaHora(x.hora)}}</td><td>{{x.motivo}}<span class="small muted" v-if="x.cuenta_origen"> · desde {{x.cuenta_origen}}</span></td><td class="num">{{money(x.monto)}}</td></tr></tbody></table></template>
      <template v-if="(ver.retiros||[]).length"><h3 style="margin:14px 0 6px">Salidas de efectivo</h3><table class="tbl"><tbody><tr v-for="(x,i) in ver.retiros" :key="i"><td class="small">{{fechaHora(x.hora)}}</td><td>{{x.motivo}}<span class="small muted" v-if="x.tipo==='proveedor'"> · {{x.pago ? 'registrado ' + x.pago : 'por registrar en Gastos'}}</span></td><td class="num">{{money(x.monto)}}</td></tr></tbody></table></template>
      <template #foot><button class="btn" v-if="ver.estado==='Abierta'" @click="abrirCierre(ver)">Cerrar caja</button><button class="btn ghost" v-else-if="puedeCorregir" @click="reabrir(ver)">Reabrir</button><template v-if="verRes"><button class="btn sec" v-if="ver.estado==='Cerrada'" @click="resultado=ver">Resultado</button><button class="btn sec" v-if="ver.estado==='Cerrada' && correoDe(ver)" @click="enviarCorreo(ver)" :disabled="enviando===ver.id">✉ Enviar por correo</button><button class="btn sec" @click="imprimirZ(ver)" title="Imprimir el cierre: el navegador deja elegir la impresora">⎙ Imprimir</button><button class="btn sec" v-for="i in impresorasLista()" :key="i.id" @click="imprimirZ(ver, i)">⎙ {{i.nombre}}</button><button class="btn sec" @click="documento(ver,'pdf')">⤓ PDF</button><button class="btn sec" @click="documento(ver,'docx')">⤓ Word</button></template><button class="btn ghost" @click="ver=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="cerrar" :title="'Cierre de caja · ' + cerrar.c.caja" @close="cerrar=null">
      <p class="small muted" style="margin:0 0 10px" v-if="cerrar.ciego">Cuente todo lo que hay en la gaveta y anote lo que dicen el cierre del datáfono, el SINPE Móvil y las transferencias. Al confirmar, el sistema hace el corte.</p>
      <div class="totals" style="align-items:stretch;margin:0 0 12px" v-else><div><span>Efectivo inicial</span><b>{{money(cerrar.c.monto_inicial)}}</b></div><div><span>Ventas y abonos en efectivo</span><b>{{money(resumenCerrar.porMedio['01'] || 0)}}</b></div><div v-if="resumenCerrar.propinas_efectivo"><span>Propinas en efectivo</span><b>{{money(resumenCerrar.propinas_efectivo)}}</b></div><div v-if="resumenCerrar.entradas"><span>Entradas de efectivo</span><b>{{money(resumenCerrar.entradas)}}</b></div><div v-if="resumenCerrar.dolares"><span>Vuelto en colones de pagos en dólares</span><b>−{{money(resumenCerrar.vuelto_usd)}}</b></div><div v-if="resumenCerrar.salidas"><span>Retiros y depósitos</span><b>−{{money(resumenCerrar.salidas)}}</b></div><div v-if="resumenCerrar.pagos_proveedor"><span>Pagos a proveedores</span><b>−{{money(resumenCerrar.pagos_proveedor)}}</b></div><div class="total"><span>Efectivo esperado en la gaveta</span><b>{{money(resumenCerrar.efectivo_esperado)}}</b></div></div>
      <div class="grid cols-2">
        <Field label="Efectivo contado en la gaveta" req style="grid-column:1/-1"><input type="number" min="0" step="1" v-model.number="cerrar.conteo" class="mono" style="font-size:22px;text-align:right" :disabled="!!cerrar.billetes"></Field>
        <div style="grid-column:1/-1"><button class="btn sm ghost" type="button" @click="alternarBilletes">{{cerrar.billetes ? 'Escribir solo el total' : 'Contar por billetes y monedas'}}</button>
          <div v-if="cerrar.billetes" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:6px;margin-top:6px"><label v-for="d in DENOM" :key="d" class="small" style="display:flex;flex-direction:column;gap:2px">₡{{fmt(d, 0)}} <input type="number" min="0" step="1" v-model.number="cerrar.billetes[d]" @input="sumarBilletes" class="inp mono" style="text-align:right" placeholder="cantidad"></label></div></div>
        <Field label="Tarjeta: total del cierre del datáfono"><input type="number" min="0" step="1" v-model.number="cerrar.medios['02']" class="mono" style="text-align:right" :disabled="cerrar.porBanco"></Field>
        <div style="grid-column:1/-1"><label class="small" style="display:flex;gap:6px;align-items:center;cursor:pointer"><input type="checkbox" v-model="cerrar.porBanco" @change="sumarBancos"> Cierre del datáfono por banco (varios datáfonos: uno por fila; la suma es el total de tarjeta)</label>
          <div v-if="cerrar.porBanco" style="margin-top:6px;display:flex;flex-direction:column;gap:6px"><div v-for="(b, i) in cerrar.bancos" :key="i" class="row" style="gap:6px"><input class="inp" v-model="b.nombre" :placeholder="'Banco o datáfono ' + (i + 1)" style="flex:1"><input type="number" min="0" step="1" v-model.number="b.monto" @input="sumarBancos" class="inp mono" style="width:140px;text-align:right" placeholder="cierre"></div>
            <div><button class="btn sm ghost" type="button" @click="cerrar.bancos.push({ nombre: '', monto: null })">+ Otro datáfono</button></div></div></div>
        <Field label="SINPE Móvil recibido"><input type="number" min="0" step="1" v-model.number="cerrar.medios['06']" class="mono" style="text-align:right"></Field>
        <Field label="Transferencias recibidas"><input type="number" min="0" step="1" v-model.number="cerrar.medios['04']" class="mono" style="text-align:right"></Field>
        <Field label="Dólares contados" v-if="hayDolares" :help="cerrar.ciego ? 'Billetes en dólares que hay en la gaveta' : 'Esperados ' + money(resumenCerrar.dolares, 'USD') + ' (pagos en dólares; el vuelto ya se descontó del efectivo en colones)'"><input type="number" min="0" step="1" v-model.number="cerrar.conteo_usd" class="mono" style="text-align:right"></Field>
        <Field label="Diferencia en efectivo" v-if="!cerrar.ciego"><input :value="difCerrar === null ? '—' : money(difCerrar)" disabled :style="difCerrar && Math.abs(difCerrar) > 0.005 ? 'color:var(--danger);font-weight:600' : ''"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="cerrar.notas" placeholder="Observaciones del cierre"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Deje en blanco los medios que no recibió en esta caja.</p>
      <p class="small muted" style="margin:6px 0 0" v-if="!cerrar.ciego">Tarjeta, SINPE y transferencias: {{money(resumenCerrar.bancos)}} ya entraron en las cuentas de Bancos al cobrar.</p>
      <p class="small muted" style="margin:6px 0 0" v-if="correoDe(cerrar.c)">✉ Al cerrar, el reporte de cierre se envía en PDF a {{correoDe(cerrar.c)}}.</p>
      <template #foot><button class="btn ghost" @click="cerrar=null">Cancelar</button><button class="btn" @click="confirmarCierre">Hacer el corte y cerrar</button></template>
    </Modal>
    <Modal v-if="resultado" :title="(opc(resultado).corte ? 'Resultado del cierre · ' : 'Cierre registrado · ') + resultado.caja" lg @close="resultado=null">
      <template v-if="!opc(resultado).corte">
        <div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:12px"><span class="chip">{{resultado.cerrada_por || resultado.usuario}}</span><span class="chip" v-if="resultado.cerrada_en">Cerrada {{fechaHora(resultado.cerrada_en)}}</span></div>
        <h3 style="margin:0 0 6px">Lo declarado al cerrar</h3>
        <table class="tbl"><thead><tr><th>Medio</th><th class="num">Declarado</th></tr></thead><tbody><tr v-for="f in declaradoDe(resultado)" :key="f.medio"><td>{{f.nombre}}<div class="small muted" v-if="f.medio==='02' && (resultado.declarado_bancos||[]).length">{{resultado.declarado_bancos.map(b => b.nombre + ' ' + money(b.monto)).join(' · ')}}</div></td><td class="num">{{money(f.declarado, f.usd ? 'USD' : 'CRC')}}</td></tr></tbody></table>
        <p class="small muted" style="margin:10px 0 0" v-if="resultado.notas_cierre">Notas del cierre: {{resultado.notas_cierre}}</p>
        <p class="small muted" style="margin:10px 0 0">La caja quedó cerrada. El corte (lo que registró el sistema y el faltante o excedente) lo revisa la administración en Cierres de caja.</p>
      </template>
      <template v-else>
        <div class="dash" style="margin-bottom:12px"><div class="kpi w3"><div class="t">Faltante</div><div class="v" :style="corte(resultado).faltante ? 'color:var(--danger)' : ''">{{money(-corte(resultado).faltante)}}</div></div><div class="kpi w3"><div class="t">Excedente</div><div class="v">{{money(corte(resultado).sobrante)}}</div></div><div class="kpi w3"><div class="t">Ventas</div><div class="v">{{resumenCaja(resultado).ventas}}</div><div class="d">{{money(resumenCaja(resultado).total)}} vendido</div></div><div class="kpi w3"><div class="t">Cajero</div><div class="v" style="font-size:16px">{{resultado.cerrada_por || resultado.usuario}}</div><div class="d">{{fechaHora(resultado.cerrada_en)}}</div></div></div>
        <h3 style="margin:0 0 6px">Corte por medio de pago <small class="muted">A = lo que declaró el cajero · B = lo que registró el sistema</small></h3>
        <table class="tbl"><thead><tr><th>Medio</th><th class="num">A · Cajero</th><th class="num">B · Sistema</th><th class="num">Diferencia</th><th></th></tr></thead><tbody><tr v-for="f in corte(resultado).filas" :key="f.medio"><td>{{f.nombre}}<div class="small muted" v-if="f.medio==='02' && (resultado.declarado_bancos||[]).length">{{resultado.declarado_bancos.map(b => b.nombre + ' ' + money(b.monto)).join(' · ')}}</div></td><td class="num">{{f.declarado === null ? '—' : money(f.declarado, f.usd ? 'USD' : 'CRC')}}</td><td class="num">{{money(f.sistema, f.usd ? 'USD' : 'CRC')}}</td><td class="num">{{f.diferencia === null ? '—' : money(f.diferencia, f.usd ? 'USD' : 'CRC')}}</td><td><span class="badge" :class="resultadoDe(f)[1]">{{resultadoDe(f)[0]}}</span></td></tr></tbody></table>
        <div class="grid cols-2" style="align-items:start;margin-top:12px">
          <div><h3 style="margin:0 0 6px">Por tipo de pago</h3><table class="tbl"><tbody><tr v-for="(v,k) in resumenCaja(resultado).porMedio" :key="k"><td>{{nombreMedio(k)}}</td><td class="num">{{money(v)}}</td></tr><tr><th>Total vendido</th><th class="num">{{money(resumenCaja(resultado).total)}}</th></tr></tbody></table></div>
          <div><h3 style="margin:0 0 6px">Movimientos de la caja</h3><div class="totals" style="align-items:stretch;margin:0"><div><span>Fondo inicial</span><b>{{money(resultado.monto_inicial)}}</b></div><div v-if="resumenCaja(resultado).abonos"><span>Abonos a cuentas por cobrar</span><b>{{money(resumenCaja(resultado).abonos)}}</b></div><div v-if="resumenCaja(resultado).entradas"><span>Entradas de efectivo</span><b>{{money(resumenCaja(resultado).entradas)}}</b></div><div v-if="resumenCaja(resultado).salidas"><span>Retiros y depósitos</span><b>−{{money(resumenCaja(resultado).salidas)}}</b></div><div v-if="resumenCaja(resultado).pagos_proveedor"><span>Pagos a proveedores</span><b>−{{money(resumenCaja(resultado).pagos_proveedor)}}</b></div><div v-if="resumenCaja(resultado).propinas"><span>Propinas</span><b>{{money(resumenCaja(resultado).propinas)}}</b></div></div></div>
        </div>
        <p class="small muted" style="margin:10px 0 0" v-if="resultado.notas_cierre">Notas del cierre: {{resultado.notas_cierre}}</p>
        <p class="small muted" style="margin:10px 0 0">La colilla impresa se deja con el dinero; la administración revisa el faltante o excedente desde Cierres de caja.</p>
      </template>
      <template #foot><button class="btn sec" @click="imprimirColilla(resultado)">⎙ Colilla</button><template v-if="verRes"><button class="btn sec" @click="documento(resultado,'pdf')">⤓ PDF</button><button class="btn sec" @click="documento(resultado,'docx')">⤓ Word</button></template><button class="btn" @click="resultado=null">Listo</button></template>
    </Modal>
  </div>`,
};
