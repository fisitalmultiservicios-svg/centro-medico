// Punto de venta › Caja: pantalla de venta rápida de la caja elegida en este equipo. Productos por nombre, código o código de barras
// (lector = teclado + Enter) o por botones de categoría y subcategoría (solo las categorías de esta caja); carrito; cliente
// registrado (o alta rápida); ventas en espera (cuentas abiertas); en modo restaurante, plano de mesas: tocar la mesa abre su
// cuenta, se le siguen agregando platos, se guarda, se imprime la precuenta y al final se cobra. Cobro en efectivo con vuelto,
// tarjeta, SINPE, transferencia o mixto; emite tiquete (o factura) electrónico, registra el cobro en Bancos, lo anota en la
// sesión de caja y abre el tiquete térmico.
import { api, toast, money, fmt, fmtCant, hoy, CAT, opts, mock, fecha, abrirArchivo, monedas, otroImpDe, otroImpLinea, red } from '../../api.js';
import ExoneracionRapida from '../contactos/exoneracion-rapida.js';
import { store, sesion } from '../../app.js';
import { MEDIOS, nombreMedio, terminales, terminalActual, fijarTerminal, cajaAbierta, cajaPorId, abrirCaja, registrarVentaEnCaja, registrarRetiro, registrarEntrada, veResultadoCaja, registrarAutorizacion, resumenCaja, enEspera, cuentaDeMesa, cuentasDeMesa, estadoDeMesa, esDeco, servicioDeMesa, sectorDe, precioPara, precioConIva, categorias, raices, hijas, nombresBajo, modificadores, hashClave, impresoraDe, impresoras, ventasDe, promos, promoVigente, registrarTurno, porCajero, ESTADOS_PEDIDO, nombreEstadoPedido, siguienteEstadoPedido, cobroSoloCajero, cajeroDeCaja, tomarTurno, usuarioActual, vistaInicial, vistaTrasCobro, opcionesCierre } from './_datos.js';
import { porAgente, imprimirAgente, abrirGaveta, docComanda, docTiquete, cargarEquipo, impresoraAqui, impresoraTiqueteAqui, avisoImpresion } from './_agente.js';   // agente de impresión local (3.11); 4.25: la impresión de esta computadora
import { modoNumerarComanda, pedirNumeroComanda } from './_datos.js';   // 4.29: número consecutivo de la comanda
import { textoNumeroComanda } from './_agente.js';
import { nuevoLid, ponerLids, diferencia, conFusion, conFusionDe, fusionarCuenta, condicionDe, tomarBaseDe, baseDeCuenta, lidsDeBase, lidsPantalla, aplicarEnLugar, contarCambio, conLidNuevo, restoDe, cierreDeCobro, EQUIPO } from './_fusion.js';   /* 4.31: la misma mesa abierta en dos equipos */
import PosGrid from './_grid.js';   // 4.6: cuadrícula de productos aparte (no se redibuja al tocar botones)
import { productoPorCodigo } from '../inventario/_etiquetas.js';   // 4.24: el lector encuentra por código y por código alterno
import { cuentaPrincipal, cuentasParaMovimientos } from '../bancos/cuentas.js';
import { hotelActivo, reservas as reservasHotel, nombreHab, agregarFolio, aMonedaFolio, config as configHotel, folioDe as folioHotel, totalesFolio as totalesHotel } from '../hotel/_datos.js';   // cargo a habitación (2.2)

const r2 = n => Math.round((+n || 0) * 100) / 100;
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// 4.29 (K-2, K-3): los dos botones del cobro. El principal (F9, Enter y el botón) hace lo de siempre en esta caja: abre o imprime el
// comprobante si la caja tiene «imprimir_auto» (la misma prueba de siempre); el otro (F10) cobra igual, con la impresión al revés SOLO
// para esa venta (no cambia la configuración). Devuelve si esta venta imprime y los textos de los dos botones.
export function formaCobro(cfg, otra) {
  const siempre = !!(cfg && cfg.imprimir_auto);
  return { imprime: otra === true ? !siempre : siempre, principal: siempre ? 'Cobrar e imprimir (F9)' : 'Cobrar sin imprimir (F9)', otra: siempre ? 'Cobrar sin imprimir (F10)' : 'Cobrar e imprimir (F10)' };
}

export default {
  props: ['params'],
  components: { ExoneracionRapida, PosGrid },
  data() {
    const lista = terminales(), cfg = terminalActual();
    return {
      terminalesLista: lista, cfg, elegir: !cfg, vista: vistaInicial(cfg), mesaActual: null,
      q: '', catId: null, subId: null, lineas: [], clienteId: (cfg && cfg.cliente_defecto_id) || null, qCliente: '', mostrarClientes: false, nuevoCliente: null, buscandoHac: false,
      existencias: {}, existenciasOk: false, bodegas: [], cuentas: [], caja: cfg ? cajaAbierta(cfg) : null, apertura: null, retiro: null, entrada: null, carritoPlegado: true, guia: null,
      pago: null, cobrando: false, modalVentas: false, porciones: {}, promosLista: promos(), pedido: null, fiado: null, turno: null, ultima: null, espera: enEspera(), modalEspera: false, nombreEspera: '', esperaId: null, rapida: true, servicio: !!(cfg && +cfg.servicio_pct > 0), mover: null,
      idem: uuid(), CAT, opts, MEDIOS, nota: '', reloj: Date.now(), habCargo: null,
      salonero: '', lineaNota: null, dividir: null,   // restaurante avanzado (3.7)
      // mesas al estilo FISITAAP (3.46): zoom y sector del plano, varias cuentas por mesa, mesas unidas, servicio por sector, cobro por partes
      zoom: 1, sectorFiltro: null, elegirCuenta: null, unir: null, parteNueva: false, servicioPctCuenta: null, cobroParcial: null,
      partesOtro: null,   // 4.31 (cuarta vuelta): la parte que otro equipo acaba de cobrar de la cuenta abierta (partesDe)
      revisando: false,   // 4.31 (sexta vuelta): al cerrar el cobro de una parte se pregunta al servidor (la ventana dice «Revisando…»)
      online: { nuevos: 0, ultimo: null, sinVer: 0 },   // pedidos en línea nuevos (FISITAAP, 3.47): aviso y sonido en la caja
      panelWeb: null,   /* 4.32: la ventana «Pedidos web» de la caja: { cargando, lista, error, aceptando }; 4.39: ver (id del pedido abierto con «Ver pedido»), cancelar ({ motivo, enviando }), imprime (false = se sabe que no sale comanda), listo (false = en la página web todavía se lee lo de imprimir: «Imprimir comanda» espera) */
      // comercio avanzado (3.49): modificadores al agregar, cupón, puntos y tarjetas de regalo
      sincronizando: false, sync: 0, modSel: null, cupon: null, puntos: null, regalo: null, tarjetaPago: null, prepago: null,
      autorizado: null,   // 4.5: token de la última clave de supervisor aceptada por el servidor en esta venta (viaja como pos_autorizacion)
      cola: [], verCola: false, reintentando: false, red,   // venta sin internet (3.55): ventas de contado que esperan conexión
      // exoneración del cliente: exoId undefined = la elige el sistema (la primera vigente), null = el cajero la quitó
      exos: [], exoId: undefined, exoAuto: false, exosCargando: false, exoNueva: false,
    };
  },
  computed: {
    // billetes «redondos» por encima del total, sin repetir (con ₡579.690: 580.000, 585.000, 590.000, 600.000, 1.000.000)
    totalCobro() { return r2(this.totales.total + (this.pago && this.cfg.propina !== false ? Math.max(0, +this.pago.propina || 0) : 0)); },   // total + propina voluntaria (3.7)
    // 4.9: lo que de verdad se cobra en la caja: el total con propina menos lo ya pagado en línea (prepago: tarjeta de regalo, tarjeta o SINPE);
    // antes «Exacto», los billetes rápidos, el cobro en dólares y la propina pedían también lo ya pagado
    porCobrar() { return r2(Math.max(0, this.totalCobro - (this.prepago ? +this.prepago.monto || 0 : 0))); },
    montosRapidos() {
      const total = this.porCobrar, out = [];   // 4.9: por encima de lo que falta cobrar (sin el prepago)
      for (const v of [1000, 5000, 10000, 20000, 50000, 100000, 500000, 1000000]) {
        const m = Math.ceil(total / v) * v;
        if (m > total && !out.includes(m)) out.push(m);
        if (out.length === 5) break;
      }
      return out;
    },
    ventasCaja() { return this.caja ? ventasDe(this.caja).slice().sort((a, b) => String(b.hora).localeCompare(String(a.hora))) : []; },   // ventas de la sesión (3.22)
    // promociones vigentes ahora (día y hora) y combos para la rejilla (3.23)
    promosActivas() { void this.reloj; const ahora = new Date(); return this.promosLista.filter(p => promoVigente(p, ahora)); },
    combosActivos() { return this.promosActivas.filter(p => p.tipo === 'combo' && p.combo && (p.combo.items || []).length); },
    combosGrid() { return this.combosActivos.map(c => ({ ...c, titulo: 'Combo: ' + (c.combo.items || []).map(i => (i.cantidad || 1) + ' × ' + ((this.productos.find(x => x.id === +i.producto_id) || {}).nombre || '')).join(', ') })); },   // 4.6: para la cuadrícula aparte
    textoVacio() { return 'Sin productos' + (this.q ? ' para «' + this.q + '»' : '') + '.' + (this.permitidas ? ' Esta caja solo carga sus categorías.' : ''); },
    etiquetaPedido() { const c = this.cuentaActual; if (c && c.pedido) return (c.pedido === 'domicilio' ? '🛵 ' : '🥡 ') + c.nombre + (c.direccion ? ' · ' + String(c.direccion).slice(0, 28) : ''); return '🥡 Para llevar / 🛵 Express'; },   // 4.6
    duenoCaja() { return this.caja && cobroSoloCajero(this.cfg) ? cajeroDeCaja(this.caja) : ''; },   // 4.6: quién cobra en esta caja ('' = cualquiera, o turno entregado)
    botonesCobro() { return formaCobro(this.cfg, false); },   /* 4.29 (K-1 a K-3): textos de los botones de la ventana de cobro */
    tituloCobrar() { const d = this.duenoCaja; return d && d !== usuarioActual() ? 'Solo cobra ' + d + ' (abrió la caja o recibió el turno). Pida el cambio de turno.' : 'Cobrar (F9)'; },
    pedidosActivos() { return this.esperaCaja.filter(v => v.pedido && v.estado !== 'entregado'); },
    // 4.32 (pedido del 14 nov): «🌐 Pedidos web» en Mesas y en Venta rápida, siempre a la vista con los pedidos en línea. El número cuenta
    // los pedidos por aceptar más los que entraron a esta caja y todavía no se vieron en la ventana; mientras haya alguno se pone rojo.
    conPedidosWeb() { return !!(sesion.tieneModulo && sesion.tieneModulo('pedidos_online')); },
    avisoWeb() { return (+this.online.nuevos || 0) + (+this.online.sinVer || 0); },
    enProgWeb() { const i = sesion.empresaInfo; return !!(i && i.es_local && i.pedidos_programa); },   /* 4.32: el programa que atiende los pedidos en línea */
    verWeb() { const pw = this.panelWeb; return pw && pw.ver ? (pw.lista || []).find(p => p && +p.id === +pw.ver) || null : null; },   /* 4.39: el pedido abierto con «Ver pedido» (el de la lista al día) */
    textoImprimirWeb() { return this.panelWeb && this.panelWeb.listo === false ? 'Preparando…' : this.panelWeb && this.panelWeb.imprime === false ? 'Aceptar pedido' : 'Imprimir comanda'; },   /* 4.39: «Aceptar pedido» solo si se sabe que no sale comanda (sin menú, sin impresoras de comanda o la caja de los pedidos no la imprime), como en Ventas en línea; 4.39 (revisión): «Preparando…» mientras la página web lee lo de imprimir */
    // los activos (nuevo, confirmado, en preparación, listo): primero los nuevos y luego del más reciente al más viejo
    filasWeb() {
      const l = this.panelWeb ? this.panelWeb.lista || [] : [];
      return l.filter(p => p && ['nuevo', 'confirmado', 'en_preparacion', 'listo'].includes(p.estado)).sort((a, b) => (a.estado === 'nuevo' ? 0 : 1) - (b.estado === 'nuevo' ? 0 : 1) || String(b.creado || '').localeCompare(String(a.creado || '')));
    },
    turnoActual() { const c = this.caja; if (!c) return null; const desde = c.turno_desde || c.abierta_en, vs = ventasDe(c).filter(v => !v.anulada && !v.abono && String(v.hora) >= String(desde)); return { desde, ventas: vs.length, total: r2(vs.reduce((s, v) => s + (+v.total || 0), 0)), turnos: (c.turnos || []).length }; },
    productos() { return (store.productos || []).filter(p => p.activo !== false && p.es_venta !== false); },   // sin insumos (3.18)
    cats() { void this.sync; return categorias(); },   // 4.6: se recalcula tras cada sincronización
    permitidas() { const ids = (this.cfg && this.cfg.categorias) || []; return ids.length ? new Set(ids) : null; },   // categorías principales de esta caja (null = todas)
    raices() { return raices(this.cats).filter(c => !this.permitidas || this.permitidas.has(c.id)); },
    subcats() { return this.catId ? hijas(this.cats, this.catId) : []; },
    catActual() { return this.cats.find(c => c.id === (this.subId || this.catId)); },
    filtrados() {
      const q = this.q.trim().toLowerCase();
      let l = this.productos;
      if (this.subId || this.catId) { const nombres = nombresBajo(this.cats, this.subId || this.catId); l = l.filter(p => nombres.has(p.categoria || '')); }
      else if (this.permitidas) { const nombres = new Set(); for (const id of this.permitidas) for (const n of nombresBajo(this.cats, id)) nombres.add(n); l = l.filter(p => nombres.has(p.categoria || '')); }
      if (q) l = l.filter(p => (p.nombre || '').toLowerCase().includes(q) || String(p.codigo || '').toLowerCase().includes(q) || String(p.cabys || '').includes(q));
      return l.slice(0, 200);
    },
    cliente() { return (store.clientes || []).find(c => c.id === this.clienteId) || null; },
    clienteReal() { return this.cliente && this.clienteId !== ((this.cfg && this.cfg.cliente_defecto_id) || null) ? this.cliente : null; },   // 4.6: el «cliente por defecto» de la caja no cuenta como cliente del pedido (sus direcciones no se mezclan)
    exoSel() { return this.exos.find(x => x.id === this.exoId) || null; },
    // la elegida por el sistema que no cubre ninguna línea no se envía (el servidor no emite con una exoneración que no aplica)
    exoAplica() { return !!this.exoSel && this.lineas.some(l => this.tarifaExo(l) > 0); },
    clientesFiltrados() { return this.filtrarClientes(this.qCliente); },
    clientesPedido() { return this.filtrarClientes(this.pedido ? this.pedido.q : ''); },   // 4.6: buscador del pedido para llevar / Express
    // mismas reglas que el servidor (app/fe/calculo.py): se acumula sin redondear y se redondea al final
    totales() {
      let sub = 0, desc = 0, iva = 0, exo = 0, otros = 0;
      for (const l of this.lineas) {
        const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); const d = this.descuentoDe(l); sub += m; desc += d;
        const oi = this.oiLinea(l, m - d); otros += oi.monto;                                   /* Selectivo y específicos (3.41) */
        iva += (m - d + oi.base) * this.tarifaNeta(l) / 100; exo += (m - d + oi.base) * this.tarifaExo(l) / 100;
      }
      const neto = sub - desc, servicio = this.servicio && this.cfg && this.servicioPct > 0 ? neto * this.servicioPct / 100 : 0;
      return { sub: r2(sub), desc: r2(desc), neto: r2(neto), iva: r2(iva), exo: r2(exo), otros: r2(otros), servicio: r2(servicio), total: r2(neto + iva + otros + servicio), items: this.lineas.reduce((s, l) => s + (+l.cantidad || 0), 0) };
    },
    resumenCaja() { return this.caja ? resumenCaja(this.caja) : null; },
    verMontosCaja() { return !this.cfg || this.cfg.cierre_ciego === false || veResultadoCaja(); },   // 4.2: con cierre a ciegas el cajero no ve los montos de la caja
    pagoTot() {
      if (!this.pago) return null;
      const total = this.totalCobro;
      if (this.enDolares) {   // cobro en dólares (3.20): lo recibido en dólares al tipo de cambio de la empresa; el vuelto sale en colones
        const tc = +this.pago.tc || 0, usd = this.pago.recibido_usd === null || this.pago.recibido_usd === '' ? this.totalUsd : r2(this.pago.recibido_usd);
        const resto = this.porCobrar;   // 4.9: sin lo ya pagado en línea (antes se pedía en dólares también el prepago)
        const pagado = r2(usd * tc), falta = r2(Math.max(0, resto - pagado));
        return { pagado, falta, vuelto: r2(Math.max(0, pagado - resto)), usd, ok: tc > 0 && falta <= 0.005 };
      }
      const pagado = r2(this.pago.medios.reduce((s, m) => s + (+m.monto || 0), 0) + (this.prepago ? +this.prepago.monto || 0 : 0));   // prepago: parte ya pagada con tarjeta de regalo en línea (3.49)
      const efectivo = this.pago.medios.filter(m => m.medio === '01').reduce((s, m) => s + (+m.monto || 0), 0);
      const falta = r2(Math.max(0, total - pagado)), vuelto = r2(Math.max(0, pagado - total));
      return { pagado, falta, vuelto: Math.min(vuelto, efectivo), ok: falta <= 0.005 && (vuelto <= efectivo + 0.005) };
    },
    cuentaUsd() { return (this.cfg && this.cfg.cuentas && this.cfg.cuentas.USD) || ''; },   // caja en dólares (3.20)
    enDolares() { return !!(this.pago && this.pago.moneda === 'USD' && this.pago.medios.length === 1 && this.pago.medios[0].medio === '01'); },
    totalUsd() { const tc = this.pago ? +this.pago.tc || 0 : 0; return tc ? r2(this.porCobrar / tc) : 0; },   // 4.9: sin el prepago
    enPruebas() { return !!(store.empresa && store.empresa.ambiente && store.empresa.ambiente !== 'produccion'); },   // aviso: en pruebas no se rebajan existencias (3.20)
    esRestaurante() { return !!(this.cfg && this.cfg.modo === 'restaurante'); },
    numerarComanda() { return modoNumerarComanda(this.cfg); },   /* 4.29: '' (no numera), 'dia' o 'continuo' */
    esVentaRapida() { return this.vista === 'venta' && !this.mesaActual && this.rapida; },   // 4.27: venta sin mesa abierta con «Venta rápida»; sigue siéndolo aunque la comanda la guarde como «Cuenta N»
    enMesas() { return this.vista === 'mesas' || (this.vista === 'venta' && !this.esVentaRapida); },   // 4.27: «Mesas» marcado en el plano y también con una mesa abierta, una cuenta en espera o un pedido para llevar cargado
    ventaLibreSinMesas() { return this.esRestaurante && this.vista === 'venta' && !this.mesaActual && !this.esperaId && !this.cobroParcial && !this.mesas.length; },   /* 4.39: restaurante sin mesas, en la venta y sin cuenta cargada (ver «watch») */
    /* 4.39 (prueba de punta a punta): una cuenta guardada sin mesa abierta en la venta para cobrarla («Guardar y nueva venta», «Para llevar en espera», un pedido
       para llevar de la caja o un pedido en línea). Al cobrarla, sus platos sin enviar salen a cocina como en la venta rápida (antes se cobraban y nunca
       llegaban a cocina). Los pedidos en línea llegan con sus platos ya enviados y el envío a domicilio no va a cocina (destinoDe). Revisión de los arreglos:
       también la que ya no está en la lista (otro equipo la cobró, la borró o la cambió con la ventana de cobro abierta): así el cobro la ve cerrada */
    cuentaRapidaGuardada() { const c = this.cuentaActual; return !!(this.esRestaurante && this.vista === 'venta' && !this.mesaActual && this.esperaId && !this.cobroParcial && !(c && (c.mesa_id || (Array.isArray(c.mesas_ids) && c.mesas_ids.length)))); },
    mesas() { return ((this.cfg && this.cfg.mesas) || []).filter(m => !esDeco(m)); },
    // porcentaje de servicio de la cuenta abierta (3.46): el del sector de la mesa si lo fija, si no el de la caja
    servicioPct() { return this.servicioPctCuenta !== null && this.servicioPctCuenta !== undefined ? +this.servicioPctCuenta || 0 : +((this.cfg || {}).servicio_pct) || 0; },
    sectores() { return (this.cfg && this.cfg.sectores) || []; },
    estiloPlano() { return { aspectRatio: (this.cfg && this.cfg.plano_aspecto) || '5/3', width: Math.round(this.zoom * 100) + '%' }; },
    // estado de cada mesa u objeto del plano (3.46): cuentas abiertas (puede haber varias), total, minutos, color por estado; las mesas
    // unidas muestran la misma cuenta; los objetos decorativos solo se dibujan. El filtro por sector oculta las mesas de otros sectores.
    estadoMesas() {
      void this.reloj; const ahora = Date.now(), termId = this.cfg.id;
      return ((this.cfg && this.cfg.mesas) || []).filter(m => !this.sectorFiltro || esDeco(m) || m.sector_id === this.sectorFiltro).map(m => {
        if (esDeco(m)) return { ...m, deco: true, estado: 'deco', cuenta: null, cuentas: [] };
        const st = estadoDeMesa(this.espera.filter(v => (v.mesa_id === m.id || (Array.isArray(v.mesas_ids) && v.mesas_ids.includes(m.id))) && (v.terminal_id || termId) === termId), ahora);
        return { ...m, ...st, unida: st.cuentas.some(v => Array.isArray(v.mesas_ids) && v.mesas_ids.length > 1), tarde: st.com !== null && st.com >= (+this.cfg.alerta_comanda || 20), sector: sectorDe(this.cfg, m) };
      });
    },
    mesasLibres() { return this.estadoMesas.filter(m => !m.deco && !m.cuentas.length); },
    cuentaActual() { return this.esperaId ? this.espera.find(v => v.id === this.esperaId) || null : null; },
    // 4.9: la cuenta en espera que se está cobrando: la abierta o, en el cobro por partes (esperaId queda en null), la cuenta de donde sale la parte
    cuentaCobro() { if (this.esperaId) return this.cuentaActual; const cp = this.cobroParcial; return cp ? this.espera.find(v => v.id === cp.cuentaId) || null : null; },
    esCredito() { const c = this.cuentaCobro; return !!(c && c.credito); },   // 4.9: pedido en línea hecho A CRÉDITO (revendedora): se cierra como fiado
    mesasUnidas() { const c = this.cuentaActual; return c && Array.isArray(c.mesas_ids) && c.mesas_ids.length > 1 ? c.mesas_ids.map(id => (this.mesas.find(m => m.id === id) || {}).nombre).filter(Boolean) : []; },
    partesCuenta() { return this.partesDe(this.cuentaActual); },   /* 4.31 (cuarta vuelta): con la parte que otro equipo acaba de cobrar */
    esperaCaja() { return this.cfg ? this.espera.filter(v => (v.terminal_id || this.cfg.id) === this.cfg.id) : []; },   // cada caja ve solo sus cuentas
    esperaSinMesa() { return this.esperaCaja.filter(v => !v.mesa_id); },
    esperaRapida() { return this.esperaSinMesa.filter(v => v.id !== this.esperaId); },   /* 4.36: las guardadas sin mesa de esta caja, sin la que está abierta en la venta rápida */
    // hotel: huéspedes en casa a los que se les puede cargar la cuenta (2.2)
    hotelOn() { return hotelActivo(); },
    enCasaHotel() { const q = this.habCargo ? this.habCargo.q.trim().toLowerCase() : ''; return reservasHotel().filter(r => r.estado === 'en_casa').map(r => ({ ...r, hab: nombreHab(r.habitacion_id) })).filter(r => !q || r.hab.toLowerCase().includes(q) || String(r.huesped_nombre || '').toLowerCase().includes(q)).sort((a, b) => a.hab.localeCompare(b.hab, 'es', { numeric: true })); },
    // avisos al cargar a la habitación (3.21): el huésped sale hoy o la cuenta supera el tope del hotel
    avisoHab() {
      const r = this.habCargo && this.habCargo.reserva_id ? reservasHotel().find(x => x.id === this.habCargo.reserva_id) : null; if (!r) return '';
      const cfgH = configHotel(), t = totalesHotel(folioHotel(r.id)), nuevo = aMonedaFolio(this.totales.total, r.moneda), avisos = [];
      if (r.salida <= hoy()) avisos.push('El huésped sale hoy: conviene cobrar el consumo en la caja o avisar a recepción antes del check-out');
      if (+cfgH.tope_cuenta > 0 && t.saldo + nuevo > +cfgH.tope_cuenta) avisos.push('La cuenta quedaría en ' + money(t.saldo + nuevo, r.moneda) + ', por encima del tope de ' + money(cfgH.tope_cuenta, r.moneda));
      return avisos.join('. ');
    },
    // primera venta guiada (P13): la caja no tiene cuenta de efectivo ni mesas ni bodega → asistente de tres pasos
    sinConfigurar() { return !!this.cfg && !(this.cfg.cuentas && Object.values(this.cfg.cuentas).some(Boolean)) && !(this.cfg.mesas || []).length && !this.cfg.bodega_id && !(mock.get('pos_cajas', []) || []).length && sesion.puede('configurar'); },
  },
  watch: {
    lineas: { deep: true, handler() { this.difundir(); } }, totales() { this.difundir(); },   // pantalla del cliente (3.21)
    promosActivas() { if (!this.cobroParcial) this.aplicarPromos(); },   /* al entrar o salir del horario de una promoción (3.23). 4.31 (séptima vuelta): no en el cobro de una parte: el reloj lo dispara cada 30 s y la parte perdía el 2x1 con que se partió */
    catId() { this.subId = null; },
    /* 4.39: en una caja de restaurante sin mesas, toda venta sin cuenta cargada es venta rápida: después de cobrar (o cargar a la habitación) una cuenta
       recuperada o un pedido, la venta siguiente vuelve a mandar la comanda al cobrar y tiene «Guardar y nueva venta» y «Para llevar en espera» */
    ventaLibreSinMesas(v) { if (v) this.rapida = true; },
    lineas: { deep: true, handler() { if (!this.cobrando) this.idem = uuid(); } },
    clienteId(v, antes) { if (v !== antes) { this.exoId = undefined; this.cargarExos(); } for (const l of this.lineas) if (l.producto_id && !l.precio_manual) { const p = this.productos.find(x => x.id === l.producto_id); if (p) l.precio_unitario = precioPara(p, this.clienteId); } },
  },
  methods: {
    money, fmt, fmtCant, nombreMedio, fecha, opcionesCierre,   // 4.41: el texto del turno según «el cajero ve el corte»
    // ---- caja (terminal) de este equipo ----
    usarTerminal(id) {
      const t = this.terminalesLista.find(x => x.id === id); if (!t || (this.cfg && t.id === this.cfg.id)) return;
      if ((this.lineas.length || this.esperaId) && !confirm('Hay una cuenta cargada en «' + this.cfg.nombre + '». Al cambiar de caja se descarta lo que no esté guardado. ¿Continuar?')) return;
      if (this.esperaId && !this.lineas.length) this.descartarVacia();
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.subId = null; this.pago = null; this.idem = uuid(); this.rapida = true;
      fijarTerminal(id); this.cfg = t; this.elegir = false; this.caja = cajaAbierta(t); this.servicio = +t.servicio_pct > 0; this.clienteId = t.cliente_defecto_id || null; this.vista = vistaInicial(t); this.mesaActual = null; this.catId = null; this.cargarExistencias(); if (t.pedir_apertura && !this.caja) this.abrirApertura(); },
    precioMostrar(p) { return precioConIva(p, precioPara(p, this.clienteId)); },
    stock(p) { const po = this.porciones[p.id]; if (po !== undefined && po !== null) return +po; return p.es_servicio || p.inventariable === false || !this.existenciasOk ? null : +(this.existencias[p.id] ?? 0); },   // sin existencias cargadas = desconocido (no «agotado»)
    descuentoDe(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); const d = l.descuento_pct ? m * (+l.descuento_pct) / 100 : (+l.descuento || 0); return Math.max(0, Math.min(m, d)); },
    imagen(p) { return this.cfg.mostrar_imagenes && p.imagen_nombre ? '/api/productos/' + p.id + '/imagen' : ''; },
    buscarEnter() {
      const q = this.q.trim(); if (!q) return;
      const exacto = productoPorCodigo(this.productos, q);   // 4.24: exacto por código, después por código alterno (el de fábrica o una etiqueta vieja) y después por CABYS
      if (exacto) { this.agregar(exacto); this.q = ''; return; }
      if (this.filtrados.length === 1) { this.agregar(this.filtrados[0]); this.q = ''; return; }
      if (!this.filtrados.length) toast('No se encontró «' + q + '»', 'err');
    },
    agregar(p, cantidad = 1, opciones = null) {
      const st = this.stock(p);
      // modificadores (3.49): si el ítem tiene grupos, primero se eligen las opciones
      if (opciones === null) { const gs = this.gruposDe(p); if (gs.length) { this.modSel = { p, cantidad, grupos: gs, sel: Object.fromEntries(gs.map(g => [g.id, []])) }; return; } }
      const extra = (opciones || []).reduce((s, o) => s + (+o.precio || 0), 0), notaOp = (opciones || []).map(o => o.nombre).join(', ');
      const guardadas = lidsDeBase(this._base, this.esperaId);   /* 4.31: tampoco una línea ya guardada (otro equipo pudo sumarle a la vez): va en una línea nueva */
      const ya = !opciones && this.lineas.find(l => l.producto_id === p.id && !l.precio_manual && !l.nota && !l.enviado && !guardadas.has(l.lid));   // lo ya enviado a cocina o con observación no se junta (3.7)
      const pedida = this.lineas.filter(l => l.producto_id === p.id).reduce((s, l) => s + (+l.cantidad || 0), 0) + cantidad;
      if (st !== null && pedida > st + 1e-9 && !p.venta_negativo) return toast('Sin existencias suficientes de «' + p.nombre + '» (hay ' + fmtCant(st) + ')', 'err');
      if (ya) ya.cantidad = r2(+ya.cantidad + cantidad);
      else this.lineas.push({ producto_id: p.id, detalle: p.nombre, cabys: p.cabys, cantidad, precio_unitario: r2(precioPara(p, this.clienteId) + extra), descuento: 0, descuento_pct: 0, codigo_tarifa: p.codigo_tarifa, tarifa: +p.tarifa || 0, es_servicio: p.es_servicio, unidad_medida: p.unidad_medida, precio_manual: !!extra, nota: notaOp, opciones: opciones || [], enviado: null, ronda: 0 });
      this.aplicarPromos();
      this.$nextTick(() => { const el = this.$refs.carrito; if (el) el.scrollTop = el.scrollHeight; });
    },
    gruposDe(p) {   // 3.74: además de los grupos del ítem, los que FISITAAP asignó al producto o a su categoría (extras y opcionales)
      const todos = (mock.get('pos_modificadores', []) || []).filter(g => g && g.activo !== false); const ex = (mock.get('items_extra', {}) || {})[p.id] || {};
      const ids = (ex.modificadores || []).map(Number);
      for (const g of todos) if (!ids.includes(+g.id) && ((g.productos || []).map(Number).includes(+p.id) || (p.categoria && (g.categorias || []).includes(p.categoria)))) ids.push(+g.id);
      return ids.map(id => todos.find(g => +g.id === +id)).filter(Boolean);
    },
    toggleOpcion(g, o) { const l = this.modSel.sel[g.id]; const i = l.indexOf(o.id); if (i >= 0) l.splice(i, 1); else { if (+g.maximo === 1) l.splice(0, l.length); if (+g.maximo && l.length >= +g.maximo) return toast('«' + g.nombre + '» admite máximo ' + g.maximo, 'err'); l.push(o.id); } },
    confirmarMod() {
      const m = this.modSel, elegidas = [];
      for (const g of m.grupos) { const ids = m.sel[g.id] || []; if (ids.length < (+g.minimo || 0)) return toast('Elija ' + g.minimo + ' opción(es) de «' + g.nombre + '»', 'err'); for (const id of ids) { const o = g.opciones.find(x => x.id === id); if (o) elegidas.push({ id: o.id, grupo: g.nombre, nombre: o.nombre, precio: +o.precio || 0 }); } }
      this.modSel = null; this.agregar(m.p, m.cantidad, elegidas);
    },
    // ---- cupón (3.49): se valida en el servidor y se reparte como descuento en cada línea; el uso se registra al cobrar ----
    async aplicarCupon(codigo) {
      const cod = (codigo || '').trim(); if (!cod) return;
      const base = r2(this.totales.sub - this.totales.desc + this.totales.iva + this.totales.otros);
      try {
        const r = await api('/api/cupones/validar', { method: 'POST', body: { codigo: cod, subtotal: base, cliente_id: this.clienteId || null, telefono: this.cliente ? String(this.cliente.celular || this.cliente.telefono || '') : null } });
        if (this.cupon) this.quitarCupon();
        const pct = Math.min(100, r.descuento / Math.max(base, 0.01) * 100);
        for (const l of this.lineas) { l.descuento_pct = r2(pct * 100) / 100; l.descuento_manual = true; l.promo = 'Cupón ' + r.cupon.codigo; l.descuento = r2(this.descuentoDe({ ...l })); }
        this.cupon = { codigo: r.cupon.codigo, descuento: r.descuento, base }; toast('Cupón ' + r.cupon.codigo + ': −' + money(r.descuento), 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    quitarCupon() { for (const l of this.lineas) if (l.promo && l.promo.startsWith('Cupón ')) { l.descuento_pct = 0; l.descuento = 0; l.descuento_manual = false; l.promo = ''; } this.cupon = null; this.aplicarPromos(); },
    pedirCupon() { if (this.cupon) return this.quitarCupon(); const c = window.prompt('Código del cupón'); if (c) this.aplicarCupon(c); },
    // ---- puntos (3.49): saldo del cliente y canje como descuento ----
    quienPuntos() { return this.cliente ? { cliente_id: this.cliente.id, telefono: String(this.cliente.celular || this.cliente.telefono || '') || null } : null; },
    async abrirPuntos() {
      const q = this.quienPuntos(); if (!q) return toast('Elija el cliente para ver sus puntos', 'err');
      try { const r = await api('/api/fidelizacion/saldo?' + (q.telefono ? 'telefono=' + q.telefono : 'cliente_id=' + q.cliente_id)); this.puntos = { ...r, usar: Math.min(r.saldo, Math.floor(this.totales.total * (+r.config.maximo_pct || 100) / 100 / (+r.config.valor_punto || 1))) }; }
      catch (e) { toast(e.message, 'err'); }
    },
    aplicarPuntos() {
      const p = this.puntos, usar = Math.floor(+p.usar || 0); if (usar < (+p.config.minimo_canje || 0)) return toast('El canje mínimo es ' + p.config.minimo_canje + ' puntos', 'err'); if (usar > p.saldo) return toast('No tiene tantos puntos', 'err');
      const base = r2(this.totales.sub - this.totales.desc + this.totales.iva + this.totales.otros), desc = Math.min(r2(usar * +p.config.valor_punto), r2(base * (+p.config.maximo_pct || 100) / 100));
      const pct = Math.min(100, desc / Math.max(base, 0.01) * 100);
      for (const l of this.lineas) if (!(l.promo || '').startsWith('Cupón')) { l.descuento_pct = r2(pct * 100) / 100; l.descuento_manual = true; l.promo = 'Puntos'; l.descuento = r2(this.descuentoDe({ ...l })); }
      this.puntos = { ...p, aplicados: usar, descuento: desc, canje: true }; toast(usar + ' puntos: −' + money(desc), 'ok');
    },
    // ---- tarjeta de regalo (3.49): medio de pago y venta ----
    async usarTarjeta() {
      const cod = window.prompt('Código de la tarjeta de regalo'); if (!cod) return;
      try { const t = await api('/api/tarjetas/' + encodeURIComponent(cod.trim().toUpperCase())); if (!t.activa || t.saldo <= 0) return toast('La tarjeta no tiene saldo o está anulada', 'err'); const falta = this.pagoTot ? this.pagoTot.falta : this.totalCobro; const monto = r2(Math.min(t.saldo, falta > 0 ? falta : this.totalCobro)); this.pago.medios = this.pago.medios.filter(m => m.medio !== 'regalo' && +m.monto > 0); this.pago.medios.push({ medio: 'regalo', monto, codigo: t.codigo }); toast('Tarjeta ' + t.codigo + ': saldo ' + money(t.saldo) + ', se aplican ' + money(monto), 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async abrirRegalo() { if (this.cfg.pedir_apertura && !this.caja) { toast('Abra la caja antes de vender', 'err'); return this.abrirApertura(); } if (!(await this.cobroPermitido('vender tarjetas de regalo'))) return; this.regalo = { monto: 10000, beneficiario: '', comprador: this.cliente ? this.cliente.nombre : '', medio: '01', meses: 12 }; },
    async venderRegalo() {
      const g = this.regalo; if (!(+g.monto > 0)) return toast('Indique el monto', 'err'); if (!mock.puedeGuardar()) return;
      try {
        // 4.5: sin cuenta de Bancos para el medio no se vende (antes la tarjeta nacía y el dinero no quedaba en ningún lado, sin aviso); el
        // servidor registra el cobro junto con la tarjeta (ref pos:regalo:<código>): si el dinero no entra, la tarjeta no existe
        const cuenta = this.cuentaPara(g.medio);
        if (!cuenta) { toast('Sin cuenta para ' + nombreMedio(g.medio) + ' en la configuración de la caja: configúrela antes de vender tarjetas de regalo', 'err'); return; }
        const t = await api('/api/tarjetas', { method: 'POST', body: { monto: +g.monto, beneficiario: g.beneficiario, comprador: g.comprador, meses_vigencia: +g.meses || 0, medio: g.medio, cuenta } });
        if (this.caja) registrarVentaEnCaja(this.caja.id, { abono: true, tipo: 'regalo', doc_id: null, consecutivo: 'TARJETA ' + t.codigo, total: +g.monto, medios: [{ medio: g.medio, monto: +g.monto }], cliente: g.comprador || null, hora: new Date().toISOString(), usuario: sesion.usuario?.correo });
        if (this.caja) this.caja = cajaPorId(this.caja.id);
        this.regalo = null; toast('Tarjeta ' + t.codigo + ' vendida por ' + money(t.saldo) + '. Imprímala desde Promociones › Tarjetas de regalo', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    async cambiarCantidad(l, delta) { const n = r2((+l.cantidad || 0) + delta); if (n <= 0) return this.quitar(l); if (delta < 0 && l.enviado && this.cfg.clave_anular && !(await this.autorizar('Bajar ' + l.detalle + ' ya enviado a cocina'))) return; l.cantidad = n; this.aplicarPromos(l); },   /* 4.31 (cuarta vuelta): con la cantidad nueva, también el resto de una línea partida */
    /* 4.39 (decimotercera vuelta): también con 0 en la casilla de la cantidad (antes la pantalla escondía el plato pero la cuenta guardada lo conservaba y se */
    /* cobraba después); si no se da la clave, la línea vuelve a la cantidad guardada */
    /* 4.39 (decimocuarta vuelta): la cantidad guardada (y el 2x1 de la base en una línea partida o marcada) vuelve ANTES de pedir la clave: mientras se esperaba, */
    /* la sincronización o el reloj de las promociones veían el plato en 0 (se lo llevaban, o le dejaban el descuento de otra cantidad) */
    async quitar(l) { if (l.enviado && this.cfg.clave_anular) { if (!(+l.cantidad > 0)) { const b = ((this._base && this._base.id === this.esperaId && this._base.lineas) || []).find(x => x.lid === l.lid); l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1; if (b && ((typeof l.de === 'string' && l.de !== '') || l.promo_fija || l.promo_fija_de)) for (const k of ['descuento_pct', 'descuento', 'promo', 'promo_fija', 'promo_fija_de']) { if (b[k] === undefined) delete l[k]; else l[k] = JSON.parse(JSON.stringify(b[k])); } this.aplicarPromos(); } if (!(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) return; } this.lineas = this.lineas.filter(x => x !== l); this.aplicarPromos(); this.cuentaVacia(); },   /* 4.31 (quinta vuelta): la que queda sola no conserva el 2x1 */
    // al retirar el último producto de una cuenta de mesa la cuenta se cancela y la mesa se libera (3.46); un descuento del 100 % no la cancela
    cuentaVacia() {
      if (this.lineas.length || !this.esRestaurante || !this.esperaId) return;
      const c = this.cuentaActual, id = this.esperaId, cobros = c ? (c.cobros || []).length : 0;
      if (c && c.pedido && !cobros) { this.persistirCuenta(); return toast('El pedido de ' + c.nombre + ' quedó sin platos: agregue los platos o descártelo con «Vaciar»', 'ok'); }   // 4.6: conserva cliente, teléfono y dirección
      this.bajaCuenta(id, (this.baseDe(id, c) || { lineas: [] }).lineas, this.nombreEspera || (c ? c.nombre : '')); this.esperaId = null;   /* 4.31: se cierra solo si en el servidor no queda nada más */
      toast(cobros ? 'La cuenta ya no tiene productos pendientes: se cerró y la mesa quedó libre' : 'Cuenta cancelada: la mesa quedó libre', 'ok');
      this.volverAMesas(true);
    },
    // ---- restaurante avanzado (3.7): clave de supervisor, observaciones por plato, comandas, dividir y pasar platos ----
    horaCorta(iso) { return iso ? new Date(iso).toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) : ''; },
    async autorizar(accion) {
      if (!this.cfg.clave_supervisor) return true;   // sin clave configurada no se pide
      const v = window.prompt('Clave de supervisor para: ' + accion); if (v === null) return false;
      // 4.5: la clave la comprueba el servidor y devuelve un token que viaja con la venta (pos_autorizacion); sin red, la comparación local de siempre
      try { const r = await api('/api/pos/autorizar', { method: 'POST', body: { terminal_id: this.cfg.id, clave: v, accion: String(accion || '').slice(0, 120) } }); this.autorizado = r.token || null; }
      catch (e) { if (!e.sinConexion) { toast(e.message || 'Clave de supervisor incorrecta', 'err'); return false; } if ((await hashClave(v)) !== this.cfg.clave_supervisor) { toast('Clave de supervisor incorrecta', 'err'); return false; } }
      if (this.caja) registrarAutorizacion(this.caja.id, { hora: new Date().toISOString(), accion, usuario: sesion.usuario?.correo, mesa: this.nombreEspera || null });
      return true;
    },
    abrirNota(l) { this.lineaNota = { l, texto: l.nota || '' }; },
    ponerMod(m) { const partes = this.lineaNota.texto.split(',').map(x => x.trim()).filter(Boolean); this.lineaNota.texto = (partes.includes(m) ? partes.filter(x => x !== m) : [...partes, m]).join(', '); },
    guardarNota() { this.lineaNota.l.nota = this.lineaNota.texto.trim().slice(0, 120); this.lineaNota = null; },
    raizDe(p) { let c = this.cats.find(x => x.nombre === (p.categoria || '')), n = 0; while (c && c.padre_id && n++ < 10) c = this.cats.find(x => x.id === c.padre_id); return c ? c.id : null; },
    destinoDe(l) { if (l && !l.producto_id && l.es_servicio) return null; const p = this.productos.find(x => x.id === l.producto_id); return impresoraDe(p, this.cats, this.cfg, mock.get('items_extra', {}) || {}); },   /* impresora de comanda (3.10) o null = sin comanda. 4.39 (revisión de los arreglos): un cargo sin producto (el «Envío a domicilio» de un pedido) no es un plato: no va a cocina */
    enviarComanda() {
      const nuevas = this.lineas.filter(l => !l.enviado && +l.cantidad > 0); if (!nuevas.length) return toast('No hay platos nuevos por enviar', 'err');
      const ronda = Math.max(0, ...this.lineas.map(l => +l.ronda || 0)) + 1, ahora = new Date().toISOString(), grupos = {};
      for (const l of nuevas) { const imp = this.destinoDe(l); l.enviado = ahora; l.ronda = ronda; if (imp) { const g = grupos[imp.id] || (grupos[imp.id] = { imp, ls: [] }); g.ls.push(l); } }
      const modo = this.numerarComanda;   /* 4.29: la caja que numera sigue en comandaNumerada; la que no, exactamente como antes */
      if (modo) return this.comandaNumerada(modo, nuevas, grupos, ronda, ahora);
      if (this.esRestaurante && !this.cobrando && this.platosDudosos(nuevas).length) return this.comandaRevisada(nuevas, grupos, ronda, ahora);   /* 4.31: platos que ya estaban guardados sin enviar: se imprime lo que sigue en la cuenta (al cobrar la venta rápida no: sale lo que se cobra) */
      if (this.cfg.imprimir_comanda !== false && Object.keys(grupos).length) this.imprimirComanda(grupos, ronda);
      if (this.esRestaurante) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos
      toast('Comanda ' + ronda + ' enviada' + (Object.keys(grupos).length ? ' a ' + Object.values(grupos).map(g => g.imp.nombre).join(', ') : ''), 'ok');
    },
    // 4.29: comanda con número consecutivo (N-5, N-6). Lo de siempre pasa YA, sin esperar: las líneas quedaron marcadas como enviadas
    // (enviarComanda) y aquí la cuenta se guarda en el acto, así quien llamó (el pedido para llevar, F8, el botón) sigue igual que antes
    // y un segundo toque no encuentra platos nuevos. Después se pide el número (3 s como mucho) y recién entonces se imprime, con los
    // datos tomados AHORA: si mientras tanto se cobró o se cambió de mesa, la comanda sale con la cuenta correcta. Devuelve una promesa.
    comandaNumerada(modo, nuevas, grupos, ronda, ahora) {
      let dudosas = this.esRestaurante && !this.cobrando ? this.platosDudosos(nuevas) : [];   /* 4.31: antes de guardar (después la base ya los tiene como enviados); al cobrar la venta rápida sale lo que se cobra */
      const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();
      /* 4.39 (tercera vuelta): al guardar se supo que la cuenta se cobró o se cerró en otro equipo (quedó otra cuenta): lo que ya estaba guardado en ella */
      /* no sale en la comanda ni pasa a la cuenta nueva (antes, si el servidor no contestaba a tiempo, salía y se rehacía: se cobraba dos veces) */
      const idas = dudosas.length && this.esperaId !== id0 ? dudosas.filter(l => !this.lineas.some(x => x.lid === l.lid)) : [];
      if (idas.length) { nuevas = nuevas.filter(l => !idas.includes(l)); dudosas = dudosas.filter(l => !idas.includes(l)); for (const [k, g] of Object.entries(grupos)) { g.ls = g.ls.filter(l => !idas.includes(l)); if (!g.ls.length) delete grupos[k]; } if (!nuevas.length) return Promise.resolve(null); }
      const envio = { cuentaId: this.esperaId, nuevas, grupos, ronda, ahora, imprimir: this.cfg.imprimir_comanda !== false && Object.keys(grupos).length > 0,
        datos: { cuenta: this.nombreEspera, salonero: this.salonero, caja: this.cfg.nombre, nota: this.nota } };
      // en la web, la ventana de las impresoras «del navegador» se abre YA, en el toque (después de esperar al servidor el navegador
      // puede bloquearla, sobre todo Safari en iPhone); la comanda se escribe en ella cuando llega el número (o sin número)
      if (envio.imprimir && !sesion.empresaInfo?.es_local && Object.values(grupos).some(g => !porAgente(g.imp))) { try { envio.datos.ventana = window.open('', '_blank') || null; } catch { envio.datos.ventana = null; } }
      const enCamino = this._enCamino || (this._enCamino = new Set()); enCamino.add(envio);   /* 4.29: si el servidor le cambia el id a la cuenta mientras tanto, el envío lo sigue (seguirIds) */
      const numero = pedirNumeroComanda(modo, api, 3000), revisada = dudosas.length ? Promise.resolve().then(() => this.revisarComanda(envio, dudosas)).catch(() => { try { this.comoPedidoNuevo(envio.cuentaId, dudosas.filter(l => envio.nuevas.includes(l))); } catch { /* la comanda sale igual */ } }) : null;   /* 4.31: a la vez que el número, qué sigue en la cuenta; si la revisión falla, sale todo (como «no se puede saber») */
      return (revisada ? Promise.all([numero, revisada]).then(([n]) => n) : numero).then(n => { enCamino.delete(envio); return this.ponerNumeroComanda(envio, n); });
    },
    // 4.29: dos equipos crearon a la vez una cuenta nueva con el mismo id y el servidor le dio otro a la de este equipo (api.js lo avisa al
    // guardar): la caja sigue con SU cuenta. Antes se quedaba con el id viejo y, al guardar otra vez, no la encontraba y la duplicaba (o
    // encontraba la del otro equipo con ese id y la pisaba).
    seguirIds(key, cambios) {
      if (key !== 'pos_espera' || !cambios) return;
      const nuevo = id => (id !== null && id !== undefined && cambios[String(id)] !== undefined ? cambios[String(id)] : id);
      /* 4.31: si una cuenta que ya existía y que esta pantalla guardó (abierta o no: también después de tocar «Mesas») vuelve con otro id, se */
      /* cobró o se cerró en otro equipo: lo agregado quedó en una cuenta nueva. Se avisa una vez y la pantalla, el plano y la precuenta */
      /* muestran ya solo lo que quedó en ella */
      const enviadas = this._enviadas || new Map(), abierta = this._base && this._base.existia && this.esperaId !== null && this.esperaId !== undefined && this._base.id === this.esperaId ? this.esperaId : null;
      for (const viejo of new Set([...(abierta !== null ? [abierta] : []), ...enviadas.keys()])) {
        const idN = nuevo(viejo); if (idN === viejo) continue;
        const m = (viejo === abierta ? this.nombreEspera || enviadas.get(viejo) : enviadas.get(viejo)) || 'la cuenta'; enviadas.delete(viejo);   /* 4.39 (quinta vuelta): la venta rápida guardada no tiene nombre en pantalla */
        /* 4.31 (sexta vuelta): si lo que llevó a la cuenta nueva fue solo la parte de un cobro que volvió (devolverParte), no se agregó nada: */
        /* el aviso es el de la parte («La parte que tenía abierta volvió…») */
        const vuelta = this._vuelta && this._vuelta.id === viejo && Date.now() < this._vuelta.hasta; if (vuelta) this._vuelta = null;
        if (!vuelta) toast('La cuenta de ' + m + ' se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en ' + m + ' como cuenta nueva.', 'err');
        this._alDiaNueva = Promise.resolve().then(() => this.alDiaCuentaNueva(idN)).catch(() => {});
      }
      if (this._base) this._base.id = nuevo(this._base.id);
      if (this._bajas && this._bajas.size) this._bajas = new Map([...this._bajas].map(([id, n]) => [nuevo(id), n]));
      this.esperaId = nuevo(this.esperaId);
      if (this.cobroParcial) this.cobroParcial.cuentaId = nuevo(this.cobroParcial.cuentaId);
      for (const e of this._enCamino || []) e.cuentaId = nuevo(e.cuentaId);
      this.espera = enEspera();
    },
    // 4.29: el mismo número para todas las impresoras del envío y en cada línea («comanda»). Las líneas se marcan en pantalla (si la
    // cuenta sigue abierta aquí) y en la cuenta guardada (si todavía existe: una cuenta ya cobrada no se resucita). Sin número
    // (el servidor no contestó a tiempo o dio error) la comanda sale igual que antes, con un aviso corto.
    ponerNumeroComanda(e, n) {
      if (e.revisada && !e.nuevas.length) return n;   /* 4.31: nada de esta comanda seguía en la cuenta (ya salió el aviso) */
      const destinos = Object.keys(e.grupos).length ? ' a ' + Object.values(e.grupos).map(g => g.imp.nombre).join(', ') : '';
      if (n) {
        const deEste = l => !!l && l.enviado === e.ahora && +l.ronda === e.ronda;
        for (const l of e.nuevas) l.comanda = n;
        if (e.cuentaId && this.esperaId === e.cuentaId) for (const l of this.lineas) if (deEste(l)) l.comanda = n;
        const guardada = e.cuentaId ? (mock.get('pos_espera', []) || []).find(x => x.id === e.cuentaId) : null;
        if (guardada && (guardada.lineas || []).some(l => deEste(l) && l.comanda !== n)) this.actualizarCuenta(e.cuentaId, x => ({ ...x, lineas: (x.lineas || []).map(l => (deEste(l) ? { ...l, comanda: n } : l)) }));   /* 4.31: solo el número de esas líneas */
      }
      if (e.imprimir) this.imprimirComanda(e.grupos, e.ronda, { ...e.datos, numero: n });
      if (n) toast('Comanda N.º ' + n + ' enviada' + destinos, 'ok');
      else toast('Comanda ' + e.ronda + ' enviada' + destinos + ' sin número: el servidor no respondió a tiempo', 'err');
      return n;
    },
    async imprimirComanda(grupos, ronda, datos) {
      // impresoras USB o de red: por el agente local; las del navegador (o si el agente falla) salen en la ventana de impresión
      // 4.29: los datos de la cuenta se toman al empezar (la comanda numerada los trae tomados al enviarla); `numero` = consecutivo o nada
      const d = datos || { cuenta: this.nombreEspera, salonero: this.salonero, caja: this.cfg.nombre, nota: this.nota }, numero = d.numero || null;
      const navegador = {};
      if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});
      for (const [k, g] of Object.entries(grupos)) {
        g.imp = impresoraAqui(g.imp);   // 4.25: la de la categoría, como está conectada en esta computadora
        if (!porAgente(g.imp)) { navegador[k] = g; continue; }
        try { await imprimirAgente(g.imp, docComanda({ impresora: g.imp.nombre, cuenta: d.cuenta, ronda, salonero: d.salonero, caja: d.caja, lineas: g.ls, nota: d.nota, numero })); }
        catch (e) { toast('Comanda de «' + g.imp.nombre + '» no se imprimió por el agente: ' + e.message, 'err'); navegador[k] = g; }
      }
      const w = d.ventana || null;   // 4.29: la ventana abierta en el toque (comanda numerada en la web)
      if (!Object.keys(navegador).length) { if (w) { try { w.close(); } catch { /* ya cerrada */ } } return; }
      grupos = navegador;
      const hora = new Date().toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' });
      const secciones = Object.values(grupos).map(({ imp, ls }) => '<div class="pg">' + (numero ? '<h1 style="margin:0 0 4px;text-align:center;font-size:30px">' + esc(textoNumeroComanda(numero)) + '</h1>' : '') + '<h2>' + esc(String(imp.nombre).toUpperCase()) + '</h2><h3>' + esc(d.cuenta || 'Para llevar') + ' · ronda ' + ronda + '</h3><p>' + esc(hora) + (d.salonero ? ' · ' + esc(d.salonero) : '') + ' · ' + esc(d.caja) + '</p><table>' + ls.map(l => '<tr><td class="q">' + esc(fmtCant(l.cantidad)) + '</td><td>' + esc(l.detalle) + (l.nota ? '<div class="o">' + esc(l.nota) + '</div>' : '') + '</td></tr>').join('') + '</table>' + (d.nota ? '<p class="o">' + esc(d.nota) + '</p>' : '') + '</div>').join('');
      const html = '<!doctype html><html><head><meta charset="utf-8"><title>Comanda</title><style>body{font-family:Arial,sans-serif;font-size:15px;width:72mm;margin:4mm auto;color:#111}h2{margin:2px 0;text-align:center;font-size:20px}h3{margin:2px 0;text-align:center;font-size:16px}p{margin:4px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:5px 0;border-bottom:1px dotted #bbb;vertical-align:top}td.q{width:34px;font-weight:700;font-size:18px}.o{font-weight:700;font-style:italic}.pg{page-break-after:always;padding-bottom:12px}@media print{body{margin:0}}</style></head><body>' + secciones + '</body></html>';
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      let escrita = false;
      if (w && !w.closed) { try { w.document.open(); w.document.write(html); w.document.close(); escrita = true; } catch { /* sigue con la ventana de siempre */ } }
      if (!escrita) window.open(u, '_blank');
      setTimeout(() => URL.revokeObjectURL(u), 60000);
    },
    totalDe(lineas, servicio, pct) { let neto = 0, iva = 0, otros = 0; for (const l of lineas) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - this.descuentoDe(l); const oi = this.oiLinea(l, m); neto += m; otros += oi.monto; iva += (m + oi.base) * this.tarifaNeta(l) / 100; } const p = pct === undefined || pct === null ? this.servicioPct : +pct || 0; const sv = servicio && p > 0 ? neto * p / 100 : 0; return r2(neto + iva + otros + sv); },
    oiLinea(l, subtotal) { return otroImpLinea(otroImpDe(l, this.productos), l.cantidad, subtotal); },   /* 3.41 */
    cuentaDeMesaId(id) { return cuentaDeMesa(id, this.cfg.id); },
    nuevaCuentaEspera(nombre, lineas, mesaId, extra) {
      let id = null;   /* 4.31 (sexta vuelta): también sin líneas (el pedido para llevar o Express se abre antes de cargar los platos); «Dividir» sin platos ya no llega aquí */
      for (const x of lineas || []) { x.lid = nuevoLid(); delete x.de; }   /* 4.31: las líneas que pasan a otra cuenta son líneas nuevas de ella */
      this.espera = mock.actualizar('pos_espera', l => { const lista = Array.isArray(l) ? l : []; id = mock.nextId(lista, 'pos_espera'); lista.push({ id, nombre, cliente_id: null, lineas, nota: '', servicio: this.servicio, servicio_pct: this.servicioPctCuenta, creado: new Date().toISOString(), actualizado: new Date().toISOString(), usuario: sesion.usuario?.correo, total: this.totalDe(lineas, this.servicio), mesa_id: mesaId || null, terminal_id: this.cfg.id, salonero: this.salonero, mesa_origen: this.nombreEspera || null, ...(extra || {}) }); return lista; }, []);
      return id;
    },
    // 4.9: lo que pasa de un pedido en línea a crédito a otra cuenta (partes, «aparte»): cliente, crédito y enlace con el pedido; sin prepago ni teléfono (los puntos no se repiten)
    datosCredito(c) { return c && c.credito ? { cliente_id: c.cliente_id || null, credito: true, canal: c.canal || null, pedido_id: c.pedido_id || null, pedido_numero: c.pedido_numero || null } : null; },
    async abrirDividir() { if (!this.lineas.length) return; await this.alDiaParaCobrar(); if (!this.lineas.length || this.dividir || this.pago || this.habCargo || this.cobroParcial) return; this.dividir = { modo: 'articulos', partes: 2, destino: 'nueva', sel: {} }; },   /* 4.31: se elige sobre la cuenta como está ahora (la selección va por posición) */
    toggleSel(i, on) { this.dividir.sel[i] = on ? +this.lineas[i].cantidad || 0 : 0; },
    // Partes iguales (3.46, al estilo FISITAAP): la cuenta se queda en la mesa y se cobra por partes; cada parte emite su tiquete y queda
    // anotada en la cuenta (cobros). La mesa sigue ocupada hasta cobrar la última parte.
    async cobrarParte(n) {
      if (this.cfg.pedir_apertura && !this.caja) { toast('Abra la caja antes de cobrar', 'err'); return this.abrirApertura(); }
      const id0 = this.esperaId, div0 = this.dividir;   /* 4.31: un segundo toque mientras se espera a la red no vuelve a partir la parte que ya se está cobrando */
      /* 4.39 (sexta vuelta): div0, «Dividir» como estaba al tocar (abierto si se llega desde ahí): si se cancela o se abre mientras se espera, no se parte */
      if (!(await this.cobroPermitido('cobrar'))) return;   // 4.6: antes de partir la cuenta (si no, la parte quedaba huérfana)
      this._seguirCobro = null; await this.alDiaParaCobrar();   /* 4.31: la cuenta como está ahora en el servidor (1,5 s como mucho) */
      /* 4.39 (quinta vuelta): si otro equipo acaba de mandar a cocina platos de esta cuenta (la marca, o la cuenta del servidor), se espera a que salga su comanda */
      /* antes de partirla (al partir, sus platos cambian de identificador y la revisión del otro equipo ya no los encontraba) y se junta otra vez */
      if (this.esRestaurante && id0 !== null && id0 !== undefined) {
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)), ma = this._marcaAjena; let hasta = ma && ma.id === id0 ? ma.t + 4000 : 0, junta = false;
        if (sin1.size) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ } const c1 = enEspera().find(v => v.id === id0), vistos = c1 ? (c1.lineas || []).filter(l => l && l.lid && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : [], ls = vistos.filter(l => !(Date.now() - Date.parse(l.enviado) > 10000)); if (vistos.length) junta = true; if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === id0 && m1.env >= te)) this._marcaAjena = { id: id0, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; hasta = Math.max(hasta, this._marcaAjena.t + 4000); } }   /* 4.39 (sexta vuelta): la marca, con la hora de esa comanda. Séptima vuelta: y se junta aunque esa comanda sea vieja (la pantalla está atrasada: lo que quedaba se guardaba «sin enviar» y volvía a salir a cocina) */
        /* 4.39 (séptima vuelta): si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó), se espera también esa y se junta otra vez */
        for (let k = 0; k < 2 && (Date.now() < hasta || junta); k++) { junta = false; for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0; i++) await new Promise(r => setTimeout(r, 200)); if (!(this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0)) break; this._alDia = 0; await this.alDiaParaCobrar(); const m2 = this._marcaAjena; if (m2 && m2.id === id0) hasta = Math.max(hasta, m2.t + 4000); }   /* 4.39 (sexta vuelta): con el aviso si la cuenta cambió */
      }
      if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago || this.dividir !== div0) return;   /* 4.39 (cuarta vuelta): ni con la ventana de la habitación o la de cobro abiertas mientras tanto. Sexta vuelta: ni si «Dividir» cambió */
      if (this.cerradaAfuera()) return;   /* 4.31 (cuarta vuelta): otro equipo ya la cobró o la cerró: no se parte ni se cobra */
      if (!this.lineas.length) return toast('No hay nada que cobrar en esta parte', 'err');
      const c = this.cuentaActual, pc = this.partesDe(c), partes = pc ? { ...pc } : { total: n, cobradas: 0 };   /* 4.31 (cuarta vuelta): con la parte que otro equipo acaba de cobrar */
      const faltan = partes.total - partes.cobradas; if (faltan <= 0) return toast('Esta cuenta ya se cobró por completo', 'err');
      const ultima = faltan === 1;
      const parte = ultima ? this.lineas.map(l => ({ ...l })) : this.lineas.map(l => ({ ...l, cantidad: Math.round((+l.cantidad / faltan) * 1000) / 1000 })).filter(l => l.cantidad > 0);
      /* 4.39 (decimotercera vuelta): lo que queda de cada línea sale de su propia parte: con una línea en 0 la parte filtrada se corría de posición y se cobraba de más */
      const resto = ultima ? [] : this.lineas.map(l => restoDe(l, Math.round(((+l.cantidad || 0) - Math.round(((+l.cantidad || 0) / faltan) * 1000) / 1000) * 1000) / 1000)).filter(l => l.cantidad > 0);   /* 4.31: lo que queda es otra línea (con `de`: si otro equipo ya partió la misma, no se suma dos veces); la vieja se cobra */
      if (!parte.length) return toast('No hay nada que cobrar en esta parte', 'err');
      const existia0 = this.yaGuardada(id0);   /* 4.31 (cuarta vuelta): el cobro se pide para la cuenta de la que salen los platos (id0), no para la que quede al volver a guardarla */
      this.lineas = resto; const id = this.persistirCuenta(true);
      this.actualizarCuenta(id, x => ({ ...x, partes }));
      const conResto = new Set(resto.map(l => l.de)), restos = resto.map(l => l.lid), enteras = parte.map(l => l.lid).filter(x => typeof x === 'string' && x && !conResto.has(x));   /* 4.31 (quinta vuelta): lo que quedó en la cuenta y lo que se cobra entero */
      /* 4.31 (séptima vuelta): lo que quedó en la cuenta del mismo plato con 2x1 (su par): si al cancelar el servidor dice que ya se cobró, lo que vuelve conserva el 2x1 */
      const grupo = l => String(l.producto_id) + '|' + String(l.enviado || ''), conPromo = new Set(parte.filter(l => +l.descuento_pct > 0 && l.promo && !l.descuento_manual && !l.combo).map(grupo)), pares = {};
      for (const l of resto) if (conPromo.has(grupo(l)) && typeof l.lid === 'string' && l.lid) pares[l.lid] = grupo(l);
      this.lineas = parte; this.esperaId = null; this.cobroParcial = { cuentaId: id, parte: partes.cobradas + 1, de: partes.total }; this._cobrosParte = { de: this.cobroParcial, n: this.cobrosDe(c), cuenta: id0, existia: existia0, restos, enteras, pares };   /* 4.31: los cobros que tenía la cuenta (si otro equipo cobra una parte mientras tanto, esta no se emite) */
      this.dividir = null; this.idem = uuid(); this.abrirPago();
    },
    async confirmarDividir() {
      const d = this.dividir; if (!this.lineas.length) { this.dividir = null; return; }   /* 4.31 (quinta vuelta): sin platos no se divide (nunca una cuenta vacía) */
      if (!mock.puedeGuardar()) return;
      if (!(d.modo === 'partes' && this.mesaActual) && this.esRestaurante && this.esperaId !== null && this.esperaId !== undefined) {   /* 4.39 (quinta vuelta): como en cobrarParte; la selección va por posición, así que no se junta aquí: se vuelve a dividir */
        /* 4.39 (sexta vuelta): también al separar, pasar a una mesa o partir sin mesa (las partes de una mesa van por cobrarParte). La marca lleva la hora de esa */
        /* comanda y la próxima vez que se abra «Dividir» se junta (antes repetía el aviso) */
        /* 4.39 (séptima vuelta): el aviso sale también con una comanda vieja que la pantalla todavía no tiene (con «Dividir» abierto no se junta: lo partido se */
        /* guardaba «sin enviar» y volvía a salir a cocina); la marca, solo con una reciente. Al separar, pasar a una mesa o partir, la lista se trae aunque todo */
        /* esté enviado (abajo: si otro equipo cobró la cuenta, sus platos no se pasan a otra). Después de esperar la marca se mira otra vez la cuenta: si otro */
        /* equipo la cambió mientras tanto, no se parte y se vuelve a dividir (la selección va por posición) */
        const id1 = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)), b1 = this._base, ex1 = !!(b1 && b1.id === id1 && b1.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', id1));
        /* 4.39 (undécima vuelta): las consultas de «Dividir» (estas dos y la de la caja de comercio) esperan la lista hasta 3 s, como el cobro: con la red lenta */
        /* se partía con la copia vieja (lo que otro equipo acababa de mandar a cocina volvía a salir, y lo que ya había cobrado o quitado pasaba a la otra */
        /* cuenta). Si mientras tanto «Dividir» se canceló o se volvió a tocar, no se avisa (el aviso salía falso, o dos veces) */
        if (sin1.size || (ex1 && (d.modo === 'partes' || d.destino !== 'cobrar'))) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ } if (this.dividir !== d || this.esperaId !== id1) return; const c1 = enEspera().find(v => v.id === id1), vistos = c1 ? (c1.lineas || []).filter(l => l && l.lid && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : [], ls = vistos.filter(l => !(Date.now() - Date.parse(l.enviado) > 10000)); if (vistos.length) { if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === id1 && m1.env >= te)) this._marcaAjena = { id: id1, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; } this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('Otro equipo mandó a cocina platos de esta cuenta. Vuelva a abrir «Dividir» para verla al día.', 'err'); } }
        const espero = !!(this._marcaAjena && this._marcaAjena.id === id1 && Date.now() < this._marcaAjena.t + 4000);
        const ma = this._marcaAjena; for (let i = 0; i < 20 && ma && ma.id === id1 && Date.now() < ma.t + 4000 && this.dividir === d && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200));
        if (this.dividir !== d || this.esperaId !== id1) return;
        if (espero) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ }
          if (this.dividir !== d || this.esperaId !== id1) return;
          /* 4.39 (octava vuelta): la firma lleva también la marca de envío: una segunda «Comanda» del otro equipo durante la espera hace volver a dividir */
          /* 4.39 (novena vuelta): como abajo, cada plato que esta pantalla conoce (su base) tiene que seguir igual en el servidor (cantidad, envío, precio, */
          /* descuento y nota) y también el servicio; un plato que otro equipo solo agregó no detiene la división (queda en la cuenta de origen) */
          const firma = l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0) + ':' + String((l && l.enviado) || '') + ':' + (+(l && l.precio_unitario) || 0) + ':' + (+(l && l.descuento_pct) || 0) + ':' + (+(l && l.descuento) || 0) + ':' + String((l && l.nota) || ''), c2 = enEspera().find(v => v.id === id1);
          if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }
          const s2 = c2 ? new Set((ponerLids(JSON.parse(JSON.stringify(c2))).lineas || []).map(firma)) : null;
          if (!c2 || (this._base && this._base.id === id1 && ((this._base.lineas || []).some(l => !s2.has(firma(l))) || !!c2.servicio !== !!(this._base.cuenta || {}).servicio))) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo mientras se esperaba. Vuelva a dividir.', 'err'); }
        }
      }
      /* 4.39 (séptima vuelta): como en «Cobrar estos platos» (más abajo): si la cuenta ya estaba guardada y no está en la lista, otro equipo la cobró o la cerró. */
      /* Separar, pasar a una mesa o partir no se hacen: antes sus platos quedaban en una cuenta nueva, por cobrar otra vez */
      /* 4.39 (octava vuelta): también si otro equipo cobró una parte, quitó o cambió un plato mientras «Dividir» estaba abierto (lo partido se llevaba lo ya */
      /* cobrado a otra cuenta, por cobrar otra vez): la cuenta del servidor se compara con la que esta pantalla conoce (su base) y, si cambió, se vuelve a */
      /* abrir «Dividir». En la caja de comercio la lista se trae aquí (en el restaurante ya se trajo arriba, salvo en las partes de una mesa, que la traen */
      /* después, en cobrarParte) */
      { const idx = this.esperaId, bx = this._base;
        /* 4.39 (decimotercera vuelta): las partes de una mesa no se comparan aquí: cobrarParte trae y junta la cuenta y calcula con ella (si la sincronización */
        /* de siempre ya había traído el cambio, aquí pedía volver a abrir «Dividir») */
        if ((d.modo === 'partes' || d.destino !== 'cobrar') && !(d.modo === 'partes' && this.esRestaurante && this.mesaActual) && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx)))) {
          if (!this.esRestaurante) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ } if (this.dividir !== d || this.esperaId !== idx) return; }
          const cx = enEspera().find(v => v.id === idx); if (!cx) { this.dividir = null; this.sincronizar(); return; }
          /* 4.39 (novena vuelta): cada plato que esta pantalla conoce (su base) tiene que seguir igual en el servidor: cantidad, envío, precio, descuento y nota, */
          /* y también el servicio de la cuenta (antes un descuento o un precio cambiado en otro equipo se perdía al dividir). Un plato que otro equipo solo */
          /* agregó no detiene la división: queda en la cuenta de origen y, si lo mandó a cocina, su comanda la encuentra */
          const fm = l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0) + ':' + String((l && l.enviado) || '') + ':' + (+(l && l.precio_unitario) || 0) + ':' + (+(l && l.descuento_pct) || 0) + ':' + (+(l && l.descuento) || 0) + ':' + String((l && l.nota) || ''), sv = new Set((ponerLids(JSON.parse(JSON.stringify(cx))).lineas || []).map(fm));
          if (this._base && this._base.id === idx && ((this._base.lineas || []).some(l => !sv.has(fm(l))) || !!cx.servicio !== !!(this._base.cuenta || {}).servicio)) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día.', 'err'); }
        } }
      if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura && !this.caja) { toast('Abra la caja antes de cobrar', 'err'); return this.abrirApertura(); } if (!(await this.cobroPermitido('cobrar'))) return; if (this.dividir !== d) return; }   /* 4.6; 4.31: un segundo toque mientras se esperaba no parte otra vez */
      // 4.9: lo ya pagado del pedido en línea (prepago: tarjeta de regalo, tarjeta o SINPE) se queda en la cuenta original y cobrar() lo recorta
      // al total de esa cuenta: si al dividir quedaba por menos, el sobrante no se aplicaba nunca (se fiaba o se cobraba otra vez, y lo pagado
      // en línea no entraba a Bancos). Regla simple: la cuenta que conserva el prepago no puede quedar por menos que él; si no, no se divide
      const c0 = this.cuentaActual, pre0 = c0 && c0.prepago ? +c0.prepago.monto || 0 : 0, yaPago = 'Este pedido ya pagó ' + money(pre0) + ' en línea o con tarjeta de regalo';
      if (d.modo === 'partes') {
        const n = Math.max(2, Math.min(12, Math.floor(+d.partes || 2)));
        /* 4.39 (novena vuelta): las partes de una mesa se calculan con la cuenta traída en el acto (alDiaParaCobrar en cobrarParte), aunque «Dividir» se haya */
        /* abierto hace menos de 3 s: antes se podía cobrar la parte de un plato que otro equipo acababa de quitar o bajar */
        if (this.esRestaurante && this.mesaActual) { if (pre0 > 0) return toast(yaPago + ': el cobro en partes iguales no lo descuenta; cobre la cuenta completa o pase platos a una cuenta aparte', 'err'); this._alDia = 0; return this.cobrarParte(n); }   // 4.9: cada parte se cobraba sin el prepago y la cuenta terminaba vacía
        const base = this.nombreEspera || 'Cuenta', parte = this.lineas.map(l => ({ ...l, cantidad: Math.round((+l.cantidad / n) * 1000) / 1000 }));
        const quedan = this.lineas.map((l, i) => ({ ...l, cantidad: Math.round((+l.cantidad - parte[i].cantidad * (n - 1)) * 1000) / 1000, ...(parte[i].cantidad > 0 ? { lid: 'l' + uuid(), de: l.lid } : {}) })).filter(l => l.cantidad > 0);   /* 4.31: la parte que queda es una línea nueva (con `de`: la línea de la que sale) */
        if (pre0 > 0) { const totQ = this.totalDe(quedan, this.servicio); if (totQ + 0.005 < pre0) return toast(yaPago + ': la parte 1, que lo conserva, no puede quedar por menos (' + money(totQ) + '); divídalo en menos partes', 'err'); }   // 4.9
        /* 4.39 (decimocuarta vuelta): a las cuentas nuevas no pasan líneas cuya parte redondea a 0 (al cobrarlas salía «cambió en otro equipo») */
        for (let k = 2; k <= n; k++) this.nuevaCuentaEspera(base + ' · parte ' + k + ' de ' + n, parte.filter(x => x.cantidad > 0).map(x => ({ ...x })), null, this.datosCredito(this.cuentaActual));   // 4.9: la parte de un pedido a crédito sigue siendo de la revendedora
        this.lineas = quedan;
        if (this.esperaId || (this.esRestaurante && this.mesaActual)) this.persistirCuenta();   // 4.9: también en comercio: la cuenta guardada queda recortada (antes solo en memoria: «en pedidos» y el cobro contaban las partes dos veces)
        this.dividir = null; return toast('Cuenta dividida en ' + n + ' partes: esta es la parte 1; las demás están en «Para llevar en espera»', 'ok');
      }
      const mov = [], resto = [];
      this.lineas.forEach((l, i) => { const q = Math.min(+l.cantidad || 0, Math.max(0, +d.sel[i] || 0)); if (q > 0) mov.push({ ...l, cantidad: q }); if (+l.cantidad - q > 0.0005) resto.push({ ...l, cantidad: r2(+l.cantidad - q), ...(q > 0 ? { lid: 'l' + uuid(), de: l.lid } : {}) }); });   /* 4.31: lo que queda de una línea partida es otra línea (con `de`: si otro equipo ya partió o cobró la misma, no se suma dos veces) */
      if (!mov.length) return toast('Marque qué platos pasar y cuántos', 'err');
      // 4.9: la cuenta original se queda con el resto y con el prepago (salvo si todo se cobra ahora o pasa a una cuenta aparte, que se lo lleva):
      // «cobrar ahora solo esos», «aparte» parcial y pasar a una mesa no la dejan por menos que el prepago (con todo a una mesa se perdía entero)
      if (pre0 > 0 && (resto.length || (d.destino !== 'cobrar' && d.destino !== 'nueva'))) { const totR = this.totalDe(resto, this.servicio); if (totR + 0.005 < pre0) return toast(yaPago + (resto.length ? ': esta cuenta, que lo conserva, no puede quedar por menos (' + money(totR) + '); deje más artículos en ella' : ': no se puede pasar todo a una mesa; páselo a una cuenta aparte o cóbrelo aquí'), 'err'); }
      /* 4.39 (undécima vuelta): un pedido en línea tampoco se pasa entero a una mesa: la cuenta de la mesa no lleva el enlace con el pedido (no quedaba ligado */
      /* a su comprobante, el cliente no recibía sus puntos y el pedido a crédito se cobraba de contado) */
      if (!resto.length && d.destino !== 'cobrar' && d.destino !== 'nueva' && c0 && c0.canal === 'online') return toast('Este pedido en línea no se puede pasar entero a una mesa: páselo a una cuenta aparte o cóbrelo aquí', 'err');
      // cobrar ahora solo esos platos (3.46): el resto sigue en la mesa; el cobro queda anotado en la cuenta
      if (d.destino === 'cobrar') {
        if (!resto.length) { this.dividir = null; return this.abrirPago(); }
        /* 4.31 (cuarta vuelta): lo mismo que yaGuardada, cerradaAfuera y cobrosDe, escrito aquí para que este método no dependa de los de más */
        /* abajo. Si la cuenta ya estaba guardada y no está en la lista, otro equipo la cobró o la cerró: no se parte ni se cobra. El cobro se pide */
        /* para la cuenta de la que salen los platos (id0), no para la que quede al guardarla */
        const id0 = this.esperaId, b0 = this._base, o0 = this.partesOtro, n0 = c0 && Array.isArray(c0.cobros) ? c0.cobros.length : 0;
        const existia0 = id0 !== null && id0 !== undefined && (!!(b0 && b0.id === id0 && b0.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', id0)));
        if (existia0 && !enEspera().some(v => v.id === id0)) { this.dividir = null; this.sincronizar(); return; }
        /* 4.31 (quinta vuelta): la línea que formaba el par del 2x1 con una que se cobra ahora (mismo producto y misma comanda) conserva la */
        /* promoción (`promo_fija`, se quita al cambiarle la cantidad); y se anota lo que quedó en la cuenta y lo que se cobra entero */
        const grupo = l => String(l.producto_id) + '|' + String(l.enviado || ''), conPromo = new Set(mov.filter(l => +l.descuento_pct > 0 && l.promo && !l.descuento_manual && !l.combo).map(grupo));
        for (const l of resto) if (conPromo.has(grupo(l)) && +l.descuento_pct > 0 && l.promo && !l.descuento_manual && !l.combo) l.promo_fija = +l.cantidad || true;   /* 4.31 (sexta vuelta): la cantidad que tenía al marcarse (aplicarPromos) */
        const conResto = new Set(resto.map(l => l.de).filter(Boolean)), restos = resto.filter(l => l.de).map(l => l.lid), enteras = mov.map(l => l.lid).filter(x => typeof x === 'string' && x && !conResto.has(x)), pares = {};
        for (const l of resto) if (conPromo.has(grupo(l)) && typeof l.lid === 'string' && l.lid) pares[l.lid] = grupo(l);   /* 4.31 (séptima vuelta): el par del 2x1 de lo que se cobra (devolverParte) */
        this.lineas = resto; const id = this.persistirCuenta(true);
        this.lineas = mov; this.esperaId = null; this.cobroParcial = { cuentaId: id, parte: null, de: null }; this._cobrosParte = { de: this.cobroParcial, n: c0 && o0 && o0.id === c0.id ? Math.max(n0, +o0.cobros || 0) : n0, cuenta: id0, existia: existia0, restos, enteras, pares }; this.dividir = null; this.idem = uuid(); return this.abrirPago();   /* 4.31: con los cobros que tenía la cuenta */
      }
      let destinoTxt = '';
      if (d.destino === 'nueva') {
        // 4.9: si se pasa todo, la cuenta original se borra (más abajo): lo ya pagado en línea (prepago) y el enlace con el pedido se van con las
        // líneas. Antes el prepago se perdía: el pedido a crédito con tarjeta de regalo se fiaba por el total y el pagado en línea se cobraba otra vez.
        // 4.9 (revisión, ronda 3): el enlace con el pedido (y su teléfono para los puntos, que así se acreditan una sola vez) se va con las líneas
        // en CUALQUIER pedido en línea, el prepago solo si lo tiene (antes uno de contado sin prepago salía sin pedido_id y quedaba «confirmado»)
        const ex = this.datosCredito(c0), todo = !resto.length && c0 && (c0.canal === 'online' || (c0.prepago && +c0.prepago.monto > 0));
        /* 4.39 (décima vuelta): si el servidor tiene un plato que esta pantalla no conoce (lo agregó otro equipo), no se pasa todo: la cuenta del pedido seguía */
        /* con ese plato, con lo ya pagado en línea y con el enlace del pedido, y la cuenta aparte también (se descontaba dos veces) */
        { const ib = this.esperaId, bb = this._base; if (todo && ib !== null && ib !== undefined && bb && bb.id === ib) { const cs = enEspera().find(v => v.id === ib), bl = new Set((bb.lineas || []).map(l => l.lid)); if (cs && (ponerLids(JSON.parse(JSON.stringify(cs))).lineas || []).some(l => !bl.has(l.lid))) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día.', 'err'); } } }
        this.nuevaCuentaEspera((this.nombreEspera || 'Cuenta') + ' · aparte', mov, null, todo ? { ...(ex || {}), cliente_id: c0.cliente_id || null, canal: c0.canal || null, pedido_id: c0.pedido_id || null, pedido_numero: c0.pedido_numero || null, telefono: c0.telefono || null, prepago: c0.prepago ? { ...c0.prepago } : null } : ex);
        destinoTxt = 'una cuenta aparte (en «Para llevar en espera»)';
      }
      /* 4.39 (decimotercera vuelta): una mesa unida a esta misma cuenta no es otra cuenta: antes avisaba en falso que los pasó y, al pasar todos, la cuenta se borraba sin cobrar */
      else { const m = this.mesas.find(x => x.id === d.destino); if (!m) return toast('Elija la mesa', 'err'); const cu = cuentaDeMesa(m.id, this.cfg.id); if (cu && cu.id === this.esperaId) return toast(m.nombre + ' ya está unida a esta cuenta', 'err'); if (cu) { const pasan = mov.map(({ de, ...x }) => ({ ...x, lid: 'l' + uuid() })); this.actualizarCuenta(cu.id, x => ({ ...x, lineas: [...(x.lineas || []), ...pasan], actualizado: new Date().toISOString(), total: this.totalDe([...(x.lineas || []), ...pasan], x.servicio, x.servicio_pct) })); } else this.nuevaCuentaEspera(m.nombre, mov, m.id, { servicio_pct: servicioDeMesa(this.cfg, m) }); destinoTxt = m.nombre; }
      this.lineas = resto; this.dividir = null;
      /* 4.39 (undécima vuelta): si lo ya pagado en línea se fue con todo a la cuenta aparte, la baja de esta va como la de un cobro: si otro equipo le agregó un */
      /* plato en esos segundos, la cuenta que queda con él no conserva lo ya pagado (antes se descontaba dos veces) */
      if (!this.lineas.length) { if (this.esperaId) { const id = this.esperaId; if (mock.condicionBaja) this.bajaCuenta(id, (this.baseDe(id, c0) || { lineas: [] }).lineas, this.nombreEspera, d.destino === 'nueva' && pre0 > 0); else this.espera = mock.actualizar('pos_espera', l => (l || []).filter(x => x.id !== id), []); } this.esperaId = null;   /* 4.31: se cierra solo si en el servidor no queda nada más (todo lo que tenía se pasó) */ toast('Todo se pasó a ' + destinoTxt + ': la cuenta quedó vacía', 'ok'); if (this.esRestaurante) this.volverAMesas(true); return; }
      if (this.esperaId || (this.esRestaurante && this.mesaActual)) this.persistirCuenta();   // 4.9: también en comercio (si no, las líneas pasadas «aparte» seguían en la cuenta guardada y contaban dos veces)
      toast('Platos pasados a ' + destinoTxt, 'ok');
    },
    // ---- mesas unidas y varias cuentas por mesa (3.46) ----
    abrirUnir() { if (!this.mesaActual) return; this.unir = { sel: {} }; },
    confirmarUnir() {
      const ids = Object.entries(this.unir.sel).filter(([, on]) => on).map(([id]) => +id); if (!ids.length) return toast('Marque las mesas que se unen', 'err');
      if (!mock.puedeGuardar()) return;
      const id = this.persistirCuenta(true), c = this.espera.find(v => v.id === id) || {}, todas = [...new Set([this.mesaActual.id, ...(c.mesas_ids || []), ...ids])];
      const nombre = todas.map(x => (this.mesas.find(m => m.id === x) || {}).nombre).filter(Boolean).join(' + ');
      this.actualizarCuenta(id, x => ({ ...x, mesas_ids: todas, nombre }));
      this.nombreEspera = nombre; this.unir = null; toast('Mesas unidas: ' + nombre, 'ok');
    },
    separarMesas() {
      const id = this.esperaId; if (!id) return;
      this.actualizarCuenta(id, x => ({ ...x, mesas_ids: [], nombre: this.mesaActual ? this.mesaActual.nombre : x.nombre }));
      this.nombreEspera = this.mesaActual ? this.mesaActual.nombre : this.nombreEspera; toast('Las mesas se separaron: la cuenta queda en ' + this.nombreEspera, 'ok');
    },
    nuevaCuentaEnMesa(m) {
      if (this.lineas.length && !this.esperaId && !confirm('Hay productos sin guardar en el carrito. ¿Descartarlos?')) return;
      const n = cuentasDeMesa(m.id, this.cfg.id).length + 1;
      this.lineas = []; this.esperaId = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.nota = ''; this.salonero = ''; this.servicioPctCuenta = servicioDeMesa(this.cfg, m); this.servicio = this.servicioPct > 0;
      this.parteNueva = true; this.mesaActual = m; this.nombreEspera = m.nombre + ' · cuenta ' + n; this.elegirCuenta = null; this.vista = 'venta'; this.idem = uuid();
      this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus());
    },
    abrirCuentaDeMesa(m, c) { this.cargarCuenta(c); this.mesaActual = m; this.elegirCuenta = null; this.vista = 'venta'; this.idem = uuid(); this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus()); },
    nombreCuentaCorto(c) { return c.nombre + (c.salonero ? ' · ' + c.salonero : '') + (c.cliente_id ? ' · ' + (((store.clientes || []).find(x => x.id === c.cliente_id) || {}).nombre || '') : ''); },
    cambiarZoom(d) { this.zoom = Math.max(1, Math.min(3, Math.round((this.zoom + d) * 100) / 100)); try { localStorage.setItem('pos:zoom:' + this.cfg.id, String(this.zoom)); } catch {} },
    estiloMesa(m) { return { left: m.x + '%', top: m.y + '%', width: m.w + '%', height: m.h + '%', transform: m.rot ? 'rotate(' + m.rot + 'deg)' : '' }; },
    textoEstado(m) { return m.estado === 'precuenta' ? 'precuenta' : m.estado === 'comanda' ? (m.listo ? '✓ listo' : '🍳 ' + this.tiempoTexto(m.com)) : m.pend ? 'sin enviar' : 'ocupada'; },
    lineaTotal(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - this.descuentoDe(l); const oi = this.oiLinea(l, m); return r2(m + oi.monto + (m + oi.base) * this.tarifaNeta(l) / 100); },
    // ---- exoneración (mismas reglas que el servidor: gravadas, CABYS autorizado, nunca más que la tarifa de la línea) ----
    tarifaExo(l) { const x = this.exoSel; if (!x || l.codigo_tarifa === '10' || !((+l.tarifa || 0) > 0)) return 0; if (x.posee_cabys && !(x.cabys || []).includes(String(l.cabys || ''))) return 0; return Math.min(+x.tarifa || 0, +l.tarifa || 0); },
    tarifaNeta(l) { return Math.max(0, (+l.tarifa || 0) - this.tarifaExo(l)); },
    async cargarExos() {
      const cid = this.clienteId; this.exos = [];
      if (!cid) return;
      this.exosCargando = true;
      try {
        const l = (await api('/api/clientes/' + cid + '/exoneraciones')).filter(x => x.activa && x.estado !== 'vencida' && !x.solo_notas);
        if (this.clienteId !== cid) return;
        this.exos = l;
        if (this.exoId === undefined) { this.exoId = l.length ? l[0].id : undefined; this.exoAuto = !!l.length; }
        else if (this.exoId && !l.some(x => x.id === this.exoId)) this.exoId = null;
      } catch { this.exos = []; }
      if (this.clienteId === cid) this.exosCargando = false;
    },
    async exoRegistrada(x) { this.exoNueva = false; await this.cargarExos(); if (x && this.exos.some(e => e.id === x.id)) { this.exoId = x.id; this.exoAuto = false; } },
    async verPdfExo(x) { try { await abrirArchivo('/api/exoneraciones/' + x.id + '/pdf'); } catch (e) { toast(e.message, 'err'); } },
    fecha,
    async pedirDescuento(l) { if (this.cfg.clave_descuento && !(await this.autorizar('Descuento en ' + l.detalle))) return; const v = window.prompt('Descuento en % para ' + l.detalle + ' (máximo ' + Math.min(100, +this.cfg.descuento_max_pct || 100) + ' %)', l.descuento_pct || '10'); if (v === null) return; this.descuentoPct(l, Math.max(0, +String(v).replace(',', '.') || 0)); },
    descuentoPct(l, pct) { const max = Math.min(100, +this.cfg.descuento_max_pct || 100); if (pct > max) { toast('El descuento máximo permitido es ' + max + ' %', 'err'); pct = max; } l.descuento_pct = pct; l.descuento_manual = true; l.promo = ''; l.descuento = r2(this.descuentoDe({ ...l, descuento_pct: pct, descuento: 0 })); },   /* 4.31 (cuarta vuelta): en 0 % no queda el monto de antes */
    async vaciar() { if (this.lineas.length && !confirm('¿Vaciar el carrito?')) return; if (this.cfg.clave_anular && this.lineas.some(l => l.enviado) && !(await this.autorizar('Vaciar la cuenta ' + (this.nombreEspera || '') + ' con platos ya enviados'))) return; if (!this.lineas.length) this.descartarVacia(); this.lineas = []; this.esperaId = null; this.nota = ''; this.idem = uuid(); if (this.esRestaurante) this.volverAMesas(true); else { this.nombreEspera = ''; this.clienteId = this.cfg.cliente_defecto_id || null; this.servicioPctCuenta = null; } },   // 4.6: también sin mesa
    // ---- cliente ----
    elegirCliente(c) { this.clienteId = c ? c.id : null; this.qCliente = ''; this.mostrarClientes = false; },
    // 4.6: por nombre, nombre comercial, cédula o teléfono (celular o fijo, 4 dígitos o más): en el restaurante el cliente se engancha por su número
    filtrarClientes(txt) { const q = String(txt || '').trim().toLowerCase(); if (!q) return []; const d = q.replace(/\D/g, ''); return (store.clientes || []).filter(c => c.activo !== false && c.tipo !== 'Proveedor' && ((c.nombre || '').toLowerCase().includes(q) || String(c.numero_id || '').includes(q) || (c.nombre_comercial || '').toLowerCase().includes(q) || (d.length >= 4 && (String(c.celular || '').includes(d) || String(c.telefono || '').includes(d))))).slice(0, 8); },
    abrirNuevoCliente() {
      const q = this.qCliente.trim(), d = q.replace(/\D/g, ''), numerico = /^[\d\s-]+$/.test(q), esTelefono = numerico && d.length === 8, esCedula = numerico && !esTelefono && d.length >= 9;
      // 4.6: en la caja el cliente nace sin cédula si no se escribió una (solo tiquetes; se completa después en Contactos); 8 dígitos = su teléfono
      this.nuevoCliente = { tipo_id: esCedula ? '01' : '', numero_id: esCedula ? d.slice(0, 12) : '', nombre: numerico ? '' : q, correo: '', telefono: esTelefono ? d : '' }; this.mostrarClientes = false;
    },
    async buscarHacienda() {
      const n = String(this.nuevoCliente.numero_id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); if (!n) return toast('Escriba la identificación', 'err');
      this.buscandoHac = true;
      try { const d = await api('/api/hacienda/contribuyente/' + n); this.nuevoCliente.nombre = d.nombre || this.nuevoCliente.nombre; if (d.tipo_identificacion && CAT.tipoId[d.tipo_identificacion]) this.nuevoCliente.tipo_id = d.tipo_identificacion; toast('Datos obtenidos de Hacienda', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.buscandoHac = false;
    },
    async guardarCliente() {
      const f = this.nuevoCliente;
      if ((f.tipo_id && !f.numero_id) || !f.nombre) return toast(f.tipo_id ? 'Identificación y nombre son obligatorios' : 'Indique el nombre', 'err');
      const tel = String(f.telefono || '').replace(/\D/g, '');
      if (tel && tel.length !== 8 && tel.length !== 3) return toast('El teléfono debe tener 8 dígitos (o ser un número especial de 3, como 911)', 'err');
      try {
        const c = await api('/api/clientes', { method: 'POST', body: { nombre: f.nombre.trim(), tipo_id: f.tipo_id || '', numero_id: f.tipo_id ? String(f.numero_id).replace(/[^A-Za-z0-9]/g, '').toUpperCase() : '', correo: (f.correo || '').trim() || null, telefono: tel ? +tel : null, tipo: 'Cliente', activo: true } });
        store.poner('clientes', c); this.clienteId = c.id; this.nuevoCliente = null; toast('Cliente ' + c.nombre + ' creado', 'ok');
        if (this.pedido) { this.pedido.nombre = c.nombre; this.pedido.telefono = String(c.celular || c.telefono || ''); this.pedido.q = ''; }   // 4.6: creado desde el pedido para llevar / Express
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.6 (FISITAAP): con «solo cobra quien abrió la caja o recibió el turno», los saloneros toman pedidos y envían comandas desde el
    // celular y el cobro queda en la caja. Si el turno fue entregado (nadie lo ha tomado), el primero que cobra lo toma.
    async cobroPermitido(accion) {
      if (!this.caja || !cobroSoloCajero(this.cfg)) return true;
      const yo = usuarioActual(); let dueno = cajeroDeCaja(this.caja);
      if (dueno && dueno === yo) return true;
      if (!dueno) {
        if (!mock.puedeGuardar()) return false;
        try { await mock.refrescar(['pos_cajas'], { sinCorte: true }); } catch {}                                     // lo último del servidor: otro equipo pudo tomar el turno hace un instante
        const fresca = cajaPorId(this.caja.id); dueno = cajeroDeCaja(fresca);
        if (fresca && fresca.estado === 'Abierta' && !dueno) { tomarTurno(this.caja.id); try { await mock.guardarTodo(); await mock.refrescar(['pos_cajas'], { sinCorte: true }); } catch {} dueno = cajeroDeCaja(cajaPorId(this.caja.id)); }
        this.caja = cajaPorId(this.caja.id) || this.caja;
        if (dueno === yo) { toast('Usted tomó el turno de la caja «' + this.caja.caja + '»', 'ok'); return true; }
      }
      toast('Solo ' + (dueno || 'quien tenga el turno') + ' (abrió la caja o recibió el turno) puede ' + (accion || 'cobrar') + ' en «' + this.caja.caja + '». Pida el cambio de turno con el botón Turno.', 'err');
      return false;
    },
    // 4.6: lo que guardaron otros equipos (comandas de los saloneros, extras y opcionales nuevos, ventas de la misma caja) sin recargar
    async sincronizar() {
      if (this.sincronizando || !mock.cargado) return; this.sincronizando = true;   // sin depender de red.enLinea: la petición barata de versiones restablece la conexión
      let fresco = false;   /* 4.31: si se pudo traer lo del servidor (para el aviso de las cuentas que no se cerraron) */
      try { fresco = await mock.refrescar(['pos_espera', 'pos_cajas', 'pos_ventas', 'pos_modificadores', 'items_extra', 'pos_promos', 'categorias']); } catch {}
      this.sincronizando = false;
      if (mock.pendientes) return;                                        // hay cambios locales en camino: en la próxima pasada
      const esp = enEspera(); if (JSON.stringify(esp) !== JSON.stringify(this.espera)) this.espera = esp;
      if (this.esperaId && !this.pago && !this.cobrando && !this.cobroParcial && !esp.some(v => v.id === this.esperaId)) {   // la cuenta abierta en pantalla fue cobrada o borrada en otro equipo
        const g = lidsDeBase(this._base, this.esperaId), nuevas = this.lineas.filter(l => !l.enviado && !g.has(l.lid));   /* 4.39 (revisión de los arreglos): lo guardado sin enviar ya estaba en la cuenta que el otro equipo cobró: no queda para cobrarlo otra vez */
        toast('La cuenta «' + (this.nombreEspera || '') + '» fue cobrada o cerrada en otro equipo' + (nuevas.length ? '; lo que no se había enviado sigue en pantalla como cuenta nueva' : ''), 'err');
        /* 4.39 (decimotercera vuelta): «Dividir» se cierra, como en cerradaAfuera: si no, quedaba encima y su selección (por posición) se llevaba otro plato */
        this.dividir = null;
        if (nuevas.length) { this.lineas = nuevas; this.esperaId = null; if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true; }   /* 4.39: sin mesa, lo que queda es una venta rápida (su comanda sale al cobrarla) */
        else if (this.esRestaurante) this.volverAMesas(true); else { this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.idem = uuid(); }
      }
      /* 4.31: cuentas que esta pantalla cerró y que el servidor conservó porque otro equipo les agregó platos en esos segundos */
      if (Array.isArray(fresco) && this._bajas && this._bajas.size) for (const [id, n] of [...this._bajas]) { this._bajas.delete(id); const v = esp.find(x => x.id === id), k = v ? (v.lineas || []).length : 0; if (v) toast('Mientras se cobraba o se cerraba ' + (n || v.nombre || 'la cuenta') + ', otro equipo le agregó ' + (k === 1 ? '1 plato. Quedó en la mesa sin cobrar.' : k + ' platos. Quedaron en la mesa sin cobrar.'), 'err'); }
      /* 4.31: la cuenta abierta en pantalla se pone al día con lo que guardaron otros equipos */
      if (this.esperaId && esp.some(v => v.id === this.esperaId)) this.avisarCambio(this.fusionarAbierta('sinc'));
      if (this.caja) {
        const c = cajaPorId(this.caja.id), act = c && c.estado === 'Abierta' ? c : cajaAbierta(this.cfg);
        if (!act) {   // la cerraron en otro equipo: nada de lo que dependía de la sesión sigue abierto
          const nombre = this.caja.caja; this.caja = null; if (this.pago && !this.cobrando) this.cerrarPago(); this.turno = null; this.retiro = null; this.entrada = null; this.regalo = null; this.fiado = null;
          toast('La caja «' + nombre + '» fue cerrada en otro equipo', 'err'); if (this.cfg.pedir_apertura) this.abrirApertura();
        } else if (JSON.stringify(act) !== JSON.stringify(this.caja)) this.caja = act;
      }
      else if (this.cfg) { const c = cajaAbierta(this.cfg); if (c) { this.caja = c; this.apertura = null; } }
      const pr = promos(); if (JSON.stringify(pr) !== JSON.stringify(this.promosLista)) this.promosLista = pr;
      const ids = new Set((store.clientes || []).map(c => c.id));   // clientes creados en otro equipo (p. ej. desde el celular del salonero)
      if (esp.some(v => v.cliente_id && !ids.has(v.cliente_id))) { try { const l = await api('/api/clientes'); if (Array.isArray(l)) store.clientes.splice(0, store.clientes.length, ...l); } catch {} }
      this.sync++;                                                        // invalida lo que se calcula desde los registros (categorías, precios de las fichas)
      if (this._est) this._est.revisarEstacion('caja');   /* 4.31: estación de comandas (sin esperar; no lanza) */
    },
    // ---- sesión de caja ----
    abrirApertura() { this.apertura = { caja: this.cfg.nombre, monto: 0, notas: '' }; },
    abrirGuia() { this.guia = { paso: 1, nombre: this.cfg.nombre || 'Caja 1', cuenta: (cuentaPrincipal('CRC', this.cuentas.filter(b => b.tipo === 'Efectivo')) || {}).nombre || '', modo: this.cfg.modo || 'mostrador', mesas: 8, servicio: true }; },
    async terminarGuia() {
      const g = this.guia; if (!g) return;
      const { config: cfgPos, guardarConfig, mesasEnCuadricula } = await import('./_datos.js');
      const c = cfgPos(); const t = c.terminales.find(x => x.id === this.cfg.id) || c.terminales[0];
      t.nombre = g.nombre.trim() || t.nombre; t.cuentas = { ...(t.cuentas || {}), '01': g.cuenta }; t.modo = g.modo;
      if (g.modo === 'restaurante') { if (!(t.mesas || []).length) t.mesas = mesasEnCuadricula(Math.max(1, +g.mesas || 8)); t.servicio_pct = g.servicio ? 10 : 0; }
      await guardarConfig(c); this.cfg = { ...this.cfg, ...t }; this.guia = null; toast('Caja lista. Abra la caja con el efectivo inicial y haga su primera venta', 'ok'); this.abrirApertura();
    },
    confirmarApertura() { if (!mock.puedeGuardar()) return; const c = abrirCaja(this.cfg, this.apertura.monto, this.apertura.notas); this.caja = c; this.apertura = null; toast('Caja «' + c.caja + '» abierta con ' + money(c.monto_inicial), 'ok'); },
    // 4.2: salidas de efectivo: retiro o depósito (3.20: con cuenta de destino, sale de la caja de efectivo y entra al banco en Bancos)
    // o pago a un proveedor (con permiso de compras, también queda el comprobante de egreso en Gastos › Pagos a proveedores)
    async nuevaEntrada() { if (!(await this.cobroPermitido('registrar entradas de efectivo'))) return; this.entrada = { monto: null, motivo: '', cuenta_origen: '' }; },   // 4.6
    async nuevaSalida() { if (!(await this.cobroPermitido('registrar salidas de efectivo'))) return; this.retiro = { tipo: 'retiro', monto: null, motivo: '', cuenta_destino: '', proveedor: '', proveedor_id: '', documento: '', compra_id: '', registrar: sesion.puede('gastos') }; },
    proveedoresCaja() { return (store.clientes || []).filter(c => c.activo !== false && (c.tipo === 'Proveedor' || c.tipo === 'Ambos')); },
    elegirProveedor() { const r = this.retiro; const p = this.proveedoresCaja().find(x => x.nombre === String(r.proveedor || '').trim()); r.proveedor_id = p ? p.id : ''; r.compra_id = ''; },
    comprasPendientes() { const r = this.retiro; if (!r || !r.proveedor_id || !sesion.puede('gastos')) return []; return (mock.get('compras', []) || []).filter(c => String(c.proveedor_id) === String(r.proveedor_id) && (c.moneda || 'CRC') === 'CRC' && (+c.total || 0) - (+c.pagado || 0) > 0.005); },
    async registrarPagoProveedor(reg, compraId) {
      const { registrarMovimientoBanco, refUnica } = await import('../bancos/cuentas.js');
      const { planCuentas } = await import('../contabilidad/catalogo.js');
      if (!reg.cuenta_origen) throw new Error('la caja no tiene cuenta de efectivo en su configuración');
      await mock.refrescar(['pagos_gastos', 'compras'], { sinCorte: true });
      const lista = mock.get('pagos_gastos', []) || [], n = lista.reduce((m, x) => Math.max(m, +String(x.numero || '').replace(/\D/g, '') || 0), 0) + 1;
      const compra = compraId ? (mock.get('compras', []) || []).find(c => String(c.id) === String(compraId)) : null;
      const aplicar = compra ? Math.min(reg.monto, r2((+compra.total || 0) - (+compra.pagado || 0))) : 0, resto = r2(reg.monto - aplicar);
      const gastos = planCuentas().filter(c => c.hoja && ['5', '6'].includes(c.raiz)).map(c => c.codigo + ' ' + c.nombre);
      const cuentaGasto = gastos.find(c => /otros gastos generales/i.test(c)) || gastos.find(c => /gastos generales/i.test(c)) || gastos[0] || '';
      const pago = { id: mock.nextId(lista, 'pagos_gastos'), numero: 'CE-' + String(n).padStart(4, '0'), contacto_id: reg.proveedor_id || null, contacto: reg.proveedor, fecha: hoy(), cuenta: reg.cuenta_origen, medio: '01', moneda: 'CRC', tipo_cambio: 1,
        monto: reg.monto, ref_mov: refUnica('pago_gasto'), estado: 'No conciliado', nota: 'Desde la caja ' + this.cfg.nombre + (reg.documento ? ' · ' + reg.documento : ''),
        facturas: aplicar > 0 ? [{ compra_id: compra.id, monto: aplicar }] : [], cuentas: resto > 0 ? [{ concepto: cuentaGasto, cuenta: cuentaGasto, valor: resto, impuesto: 0, cantidad: 1, obs: reg.documento || '' }] : [], retenciones: [] };
      const ok = await registrarMovimientoBanco(pago.cuenta, -pago.monto, pago.fecha, 'Pago a proveedor ' + pago.numero + ' · ' + pago.contacto + ' (caja ' + this.cfg.nombre + ')', pago.ref_mov, false, 'CRC', 1);
      if (!ok) throw new Error('no se pudo registrar la salida en Bancos');
      mock.actualizar('pagos_gastos', l => [...(l || []), pago], []);
      if (aplicar > 0) mock.actualizar('compras', todas => { const c = (todas || []).find(x => x.id === compra.id); if (c) c.pagado = r2((+c.pagado || 0) + aplicar); return todas; }, []);
      return pago.numero;
    },
    async confirmarRetiro() {
      const r = this.retiro; if (!(+r.monto > 0)) return toast('Indique el monto', 'err');
      if (r.tipo === 'proveedor') {
        const nombre = String(r.proveedor || '').trim(); if (!nombre) return toast('Indique el proveedor', 'err');
        if (!mock.puedeGuardar()) return;
        const reg = { tipo: 'proveedor', monto: r2(r.monto), motivo: 'Pago a proveedor ' + nombre + (r.documento ? ' · ' + r.documento.trim() : ''), proveedor: nombre, proveedor_id: r.proveedor_id || null, documento: (r.documento || '').trim(),
          hora: new Date().toISOString(), usuario: sesion.usuario?.correo, cuenta_origen: this.cuentaPara('01'), cuenta_destino: '' };
        if (r.registrar && sesion.puede('gastos')) {
          try { reg.pago = await this.registrarPagoProveedor(reg, r.compra_id); } catch (e) { return toast('No se registró el pago: ' + e.message, 'err'); }
        } else reg.por_registrar = true;
        registrarRetiro(this.caja.id, reg); this.caja = cajaPorId(this.caja.id); this.retiro = null;
        return toast('Pago a ' + nombre + ' por ' + money(reg.monto) + (reg.pago ? ' registrado (' + reg.pago + ')' : ' anotado en la caja: la administración lo registra en Gastos'), 'ok');
      }
      if (!String(r.motivo || '').trim()) return toast('Indique el motivo', 'err');
      if (!mock.puedeGuardar()) return;
      const n = (this.caja.retiros || []).length, reg = { tipo: 'retiro', monto: r2(r.monto), motivo: r.motivo.trim(), hora: new Date().toISOString(), usuario: sesion.usuario?.correo, cuenta_origen: this.cuentaPara('01'), cuenta_destino: r.cuenta_destino || '' };
      registrarRetiro(this.caja.id, reg); this.caja = cajaPorId(this.caja.id); this.retiro = null;
      if (reg.cuenta_destino) {
        const ref = 'pos:retiro:' + this.caja.id + ':' + n, detalle = 'Retiro de la caja ' + this.cfg.nombre + ' · ' + reg.motivo;
        try {
          if (reg.cuenta_origen) await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: reg.cuenta_origen, monto: -reg.monto, fecha: hoy(), descripcion: detalle, ref: ref + ':salida', moneda: 'CRC', tipo_cambio: 1 } });
          await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: reg.cuenta_destino, monto: reg.monto, fecha: hoy(), descripcion: detalle, ref: ref + ':entrada', moneda: 'CRC', tipo_cambio: 1 } });
          toast('Retiro registrado y depositado en ' + reg.cuenta_destino, 'ok');
        } catch (e) { toast('El retiro quedó en la caja, pero no se movió en Bancos: ' + e.message, 'err'); }
      } else toast('Retiro registrado', 'ok');
    },
    // 4.2: entrada de efectivo a la gaveta; si viene de una cuenta (sencillo cambiado en el banco), en Bancos sale de ella y entra a la caja
    async confirmarEntrada() {
      const r = this.entrada; if (!(+r.monto > 0)) return toast('Indique el monto', 'err'); if (!String(r.motivo || '').trim()) return toast('Indique el motivo', 'err');
      if (!mock.puedeGuardar()) return;
      const n = (this.caja.entradas || []).length, reg = { monto: r2(r.monto), motivo: r.motivo.trim(), hora: new Date().toISOString(), usuario: sesion.usuario?.correo, cuenta_destino: this.cuentaPara('01'), cuenta_origen: r.cuenta_origen || '' };
      registrarEntrada(this.caja.id, reg); this.caja = cajaPorId(this.caja.id); this.entrada = null;
      if (reg.cuenta_origen && reg.cuenta_destino) {
        const ref = 'pos:entrada:' + this.caja.id + ':' + n, detalle = 'Entrada a la caja ' + this.cfg.nombre + ' · ' + reg.motivo;
        try {
          await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: reg.cuenta_origen, monto: -reg.monto, fecha: hoy(), descripcion: detalle, ref: ref + ':salida', moneda: 'CRC', tipo_cambio: 1 } });
          await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: reg.cuenta_destino, monto: reg.monto, fecha: hoy(), descripcion: detalle, ref: ref + ':entrada', moneda: 'CRC', tipo_cambio: 1 } });
          toast('Entrada de ' + money(reg.monto) + ' registrada desde ' + reg.cuenta_origen, 'ok');
        } catch (e) { toast('La entrada quedó en la caja, pero no se movió en Bancos: ' + e.message, 'err'); }
      } else toast('Entrada de ' + money(reg.monto) + ' registrada', 'ok');
    },
    cuentasBanco() { return (this.cuentas || []).filter(b => b.tipo === 'Banco' && (b.moneda || 'CRC') === 'CRC'); },
    // ---- mesas (restaurante) ----
    tiempoTexto(min) { const m = Math.max(0, Math.round(+min || 0)); return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h' + (m % 60 ? ' ' + (m % 60) + ' min' : ''); },   // «1 h 10 min» en vez de «70 min» (3.21)
    abrirMesa(m) {
      if (m.deco || esDeco(m)) return;
      if (this.esperaId && !this.lineas.length) this.descartarVacia();
      if (this.lineas.length && !this.esperaId && !confirm('Hay productos sin guardar en el carrito. ¿Descartarlos y abrir ' + m.nombre + '?')) return;
      const cs = cuentasDeMesa(m.id, this.cfg.id);
      if (cs.length > 1) { this.elegirCuenta = { mesa: m, cuentas: cs }; return; }   // varias cuentas en la misma mesa o barra (3.46): se elige cuál
      const c = cs[0] || null;
      if (c) this.cargarCuenta(c); else { this.lineas = []; this.esperaId = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.nota = ''; this.servicioPctCuenta = servicioDeMesa(this.cfg, m); this.servicio = this.servicioPct > 0; this.salonero = ''; this.parteNueva = false; }
      this.mesaActual = m; this.nombreEspera = c ? c.nombre : m.nombre; this.vista = 'venta'; this.idem = uuid();
      this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus());
    },
    /* 4.31 (séptima vuelta): la parte que el servidor dejó sola (`<lid>+v`, sin la marca del 2x1) la calcula la caja como cualquier línea */
    cargarCuenta(v) { ponerLids(v); this.tomarBase(v); this.lineas = (v.lineas || []).map(x => ({ ...x })); this.clienteId = v.cliente_id || null; this.nota = v.nota || ''; this.servicioPctCuenta = v.servicio_pct !== undefined ? v.servicio_pct : null; this.servicio = v.servicio !== undefined ? !!v.servicio : this.servicio; this.esperaId = v.id; this.nombreEspera = v.nombre; this.salonero = v.salonero || ''; if (this.lineas.some(l => typeof l.lid === 'string' && l.lid.endsWith('+v'))) this.aplicarPromos(); this.parteNueva = false; this.rapida = false; },
    // Guarda la cuenta de la mesa (o la venta en espera) y vuelve al plano
    // 4.6: una cuenta de pedido (para llevar / Express) que se deja sin platos ni cobros no se queda guardada: se avisa y se descarta
    descartarVacia() {
      const c = this.cuentaActual; if (!c || this.lineas.length || (c.lineas || []).length || (c.cobros || []).length) return false;
      this.bajaCuenta(c.id, [], c.nombre); this.esperaId = null;   /* 4.31: se borra solo si en el servidor tampoco tiene platos */
      toast((c.pedido ? 'Pedido de ' : 'Cuenta ') + c.nombre + ' descartado: no tenía platos', 'ok'); return true;
    },
    guardarCuenta() {
      const rapida = this.esRestaurante && this.esVentaRapida;   /* 4.37 (Itzen): en la venta rápida se guarda y sigue otra venta rápida, sin pasar a Mesas */
      if (!this.lineas.length && rapida && !this.esperaId) { if (this.esperaRapida.length) this.modalEspera = true; else toast('No hay cuentas guardadas en esta caja'); return; }   /* 4.37: F4 sin platos en la venta rápida abre las cuentas guardadas */
      if (!this.lineas.length) { this.descartarVacia(); if (this.esperaId) this.bajaCuenta(this.esperaId, (this.baseDe(this.esperaId, this.cuentaActual) || { lineas: [] }).lineas, this.nombreEspera); return rapida ? this.nuevaVentaRapida() : this.volverAMesas(true); }   /* 4.31: con la condición de lo que la pantalla sabía que había */
      this.ponerEnEspera(); if (rapida) this.nuevaVentaRapida(); else if (this.esRestaurante) this.volverAMesas(true);
    },
    volverAMesas(sinPreguntar) {
      // 4.6 (Itzen): la cuenta que ya tiene comanda (o que ya se guardó) queda guardada al volver al plano, sin preguntar; los platos
      // agregados después y todavía sin enviar también se guardan (la mesa queda «sin enviar»). Solo una cuenta nueva que nunca se
      // envió ni se guardó pregunta antes de descartarse.
      if (!sinPreguntar && this.lineas.length && this.esRestaurante && this.esperaId && !this.cobroParcial && mock.puedeGuardar(false)) {
        const nombre = this.nombreEspera || (this.mesaActual ? this.mesaActual.nombre : 'La cuenta');
        this.persistirCuenta(); const pend = this.lineas.filter(l => !l.enviado).length;   /* 4.39 (tercera vuelta): después de guardar (si otro equipo cobró la cuenta, queda solo lo nuevo) */
        if (pend) toast(pend === 1 ? nombre + ' quedó guardada con 1 plato sin enviar a cocina: use «Comanda» para enviarlo' : nombre + ' quedó guardada con ' + pend + ' platos sin enviar a cocina: use «Comanda» para enviarlos', 'ok');   /* 4.31: singular y plural */
      } else if (!sinPreguntar && this.lineas.length && !confirm('¿Salir de ' + (this.mesaActual ? this.mesaActual.nombre : 'esta venta') + ' sin guardar? Los platos todavía no se enviaron a cocina. Use «Comanda» o «Guardar cuenta» para conservarlos.')) return;
      if (this.esperaId && !this.lineas.length) this.descartarVacia();
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.mesaActual = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.vista = 'mesas'; this.idem = uuid();
      if (sinPreguntar && Array.isArray(this.mesas) && !this.mesas.length) { this.vista = 'venta'; this.rapida = true; }   /* 4.39: sin mesas, las salidas solas (guardar, vaciar, cuenta cerrada) quedan en la venta rápida; al tocar «🍽 Mesas» se abre el plano con «Sin mesas», «⚡ Venta rápida» y los botones de la caja */
      this.parteNueva = false; this.servicioPctCuenta = null; this.cobroParcial = null;
    },
    ventaSinMesa() { if (this.esperaId && !this.lineas.length) this.descartarVacia(); this.mesaActual = null; this.esperaId = null; this.nombreEspera = ''; this.servicioPctCuenta = null; this.parteNueva = false; this.rapida = true; this.vista = 'venta'; this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus()); },
    /* 4.37 (Itzen): «Guardar y nueva venta»: guardada la cuenta, otra venta rápida limpia (como volverAMesas, pero sin salir de la venta rápida).
       4.38: también sin el cupón, los puntos ni la autorización de la venta guardada, como después de cobrar */
    nuevaVentaRapida() { this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.mesaActual = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.idem = uuid(); this.parteNueva = false; this.servicioPctCuenta = null; this.cobroParcial = null; this.cupon = null; this.puntos = null; this.autorizado = null; this.rapida = true; this.vista = 'venta'; this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus()); },
    // 4.27: «Venta rápida» (caja de restaurante): lo mismo que la venta sin mesa; si hay una mesa o una cuenta cargada, primero se
    // sale de ella como con «Mesas» (se guarda o se pregunta) y si la persona no confirma se queda donde estaba
    ventaRapida() {
      if (this.esVentaRapida) return;   // ya está en ella (con la comanda enviada sigue guardada como «Cuenta N»: no se suelta)
      if (this.vista === 'venta' && !this.esVentaRapida) { this.volverAMesas(false); if (this.vista !== 'mesas') return; }
      this.ventaSinMesa();
    },
    moverA(m) {
      const id = this.esperaId; if (!id) return;
      const pct = servicioDeMesa(this.cfg, m);
      this.actualizarCuenta(id, x => ({ ...x, mesa_id: m.id, mesas_ids: [], nombre: m.nombre, servicio_pct: pct }));
      this.mesaActual = m; this.nombreEspera = m.nombre; this.servicioPctCuenta = pct; this.mover = null; toast('Cuenta movida a ' + m.nombre, 'ok');
    },
    // Precuenta para la mesa: hoja imprimible (no es comprobante electrónico; el tiquete sale al cobrar). La mesa queda «precuenta pedida» (3.46)
    precuenta() {
      let esperar = false;
      if (this.esRestaurante && this.mesaActual && mock.puedeGuardar()) { const id = this.persistirCuenta(true); this.actualizarCuenta(id, x => ({ ...x, precuenta_pedida: new Date().toISOString() })); esperar = !!(this._base && this._base.existia && mock.pendientes); }
      if (!esperar) return this.imprimirPrecuenta(null);
      /* 4.31: una cuenta que ya existía: la hoja se escribe cuando el servidor guardó la cuenta (3 s como mucho). Si otro equipo la cobró */
      /* mientras tanto, sale solo lo que quedó en la cuenta nueva, no lo ya cobrado. La ventana se abre ya, en el toque */
      let w = null; try { w = window.open('', '_blank') || null; } catch { w = null; }
      const listo = Promise.race([Promise.resolve().then(() => mock.guardarTodo()).catch(() => {}).then(() => this._alDiaNueva), new Promise(r => setTimeout(r, 3000))]);
      /* 4.31 (cuarta vuelta): si mientras tanto se volvió al plano o se abrió otra mesa, la hoja no sale con otra cuenta: se cierra la ventana */
      const mesa0 = this.mesaActual, vista0 = this.vista;
      const hoja = () => { if (this.mesaActual === mesa0 && this.vista === vista0) return this.imprimirPrecuenta(w); if (w) { try { w.close(); } catch { /* ya cerrada */ } } toast('La mesa en pantalla cambió antes de que saliera la precuenta. Toque «Precuenta» otra vez.', 'err'); };
      return listo.then(hoja, hoja);
    },
    imprimirPrecuenta(w) {
      const e = store.empresa || {}, t = this.totales;
      const filas = this.lineas.map(l => '<tr><td>' + esc(l.cantidad) + ' × ' + esc(l.detalle) + '</td><td class="n">' + esc(money(this.lineaTotal(l))) + '</td></tr>').join('');
      const html = '<!doctype html><html><head><meta charset="utf-8"><title>Precuenta</title><style>body{font-family:Arial,sans-serif;font-size:13px;width:72mm;margin:4mm auto;color:#111}h2,h3{margin:2px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:3px 0;border-bottom:1px dotted #bbb}td.n{text-align:right;white-space:nowrap}.tot td{border:0;font-weight:bold}.tot .g{font-size:16px}p{margin:4px 0;text-align:center}@media print{body{margin:0}}</style></head><body>'
        + '<h2>' + esc(e.nombre_comercial || e.nombre || '') + '</h2><h3>PRECUENTA · ' + esc(this.nombreEspera || 'Para llevar') + '</h3><p>' + esc(new Date().toLocaleString('es-CR')) + (this.cliente ? ' · ' + esc(this.cliente.nombre) : '') + (this.salonero ? ' · le atendió ' + esc(this.salonero) : '') + '</p>'
        + '<table>' + filas + '</table><table class="tot"><tr><td>Subtotal</td><td class="n">' + esc(money(t.sub)) + '</td></tr>' + (t.desc ? '<tr><td>Descuento</td><td class="n">−' + esc(money(t.desc)) + '</td></tr>' : '') + '<tr><td>IVA</td><td class="n">' + esc(money(t.iva)) + '</td></tr>' + (t.servicio ? '<tr><td>' + esc(this.cfg.servicio_detalle) + '</td><td class="n">' + esc(money(t.servicio)) + '</td></tr>' : '') + '<tr><td class="g">TOTAL</td><td class="n g">' + esc(money(t.total)) + '</td></tr></table>'
        + (this.cfg.propina !== false ? '<table class="tot"><tr><td>Propina voluntaria</td><td class="n">________</td></tr></table>' : '') + '<p>Este documento no es un comprobante electrónico. Solicite su tiquete al pagar.</p><p>¡Gracias por su visita!</p></body></html>';
      if (w && !w.closed) { try { w.document.open(); w.document.write(html); w.document.close(); return; } catch { /* sigue con la ventana de siempre */ } }
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
    },
    // ---- espera ----
    // Guarda (o actualiza) la cuenta en espera sin salir de ella: la comanda y el dividir la dejan guardada (3.7)
    persistirCuenta(devolverId) {
      const nombre = (this.nombreEspera || '').trim() || (((this.esperaId !== null && this.esperaId !== undefined && (this.espera || []).find(v => v && v.id === this.esperaId)) || {}).nombre || '').trim() || ('Cuenta ' + (Math.max(this.espera.length, ...this.espera.map(v => +((/^Cuenta (\d+)$/.exec(v.nombre || '') || [])[1] || 0))) + 1));   /* 4.38: sin repetir el número de una «Cuenta N» que sigue abierta. 4.39 (tercera vuelta): la que ya está guardada conserva su nombre (cambiaba en cada guardado) */
      const mesaId = this.mesaActual ? this.mesaActual.id : null, termId = this.cfg.id; let regId = this.esperaId, guardada = null, existia = false, cambio = null;
      this.espera = mock.actualizar('pos_espera', l => {
        const lista = Array.isArray(l) ? l : [];
        // una cuenta nueva en una mesa que ya tiene cuenta abierta en otro equipo se junta con ella, salvo que sea «otra cuenta en esta mesa» (3.46)
        const otra = mesaId && !this.esperaId && !this.parteNueva ? lista.find(x => x.mesa_id === mesaId && !x.parte && (x.terminal_id || termId) === termId) : null;
        if (otra) { this.esperaId = otra.id; ponerLids(otra); this.tomarBase(otra); this.lineas = [...(otra.lineas || []).map(x => ({ ...x })), ...this.lineas]; toast(nombre + ' ya tenía una cuenta abierta en otro equipo: se juntaron los pedidos', 'err'); }   /* 4.31: lo que la pantalla agregó va como líneas nuevas de esa cuenta */
        let prev = lista.find(x => x.id === this.esperaId);
        if (this.esperaId && !prev) {   // 4.6: la cuenta fue cobrada o borrada en otro equipo (la sincronización ya la quitó): no resucita; lo recién agregado queda como cuenta nueva
          const corte = Date.now() - 20000, g = lidsDeBase(this._base, this.esperaId);   /* 4.39 (revisión de los arreglos): lo que ya estaba guardado en ESA cuenta lo cobró o lo cerró el otro equipo */
          this.lineas = this.lineas.filter(l => !g.has(l.lid) && (!l.enviado || new Date(l.enviado).getTime() >= corte));
          toast('La cuenta «' + nombre + '» fue cobrada o cerrada en otro equipo' + (this.lineas.length ? '; lo que acaba de agregar queda como cuenta nueva' : ''), 'err');
          this.esperaId = null; this.parteNueva = false; prev = null;
          if (!this.lineas.length) { regId = null; return lista; }
        }
        /* 4.31: cada línea con su identificador (lid): las de una cuenta nueva, uno fijo; en una cuenta guardada, las nuevas uno al azar */
        const id = this.esperaId || mock.nextId(lista, 'pos_espera');
        if (prev) { ponerLids(prev); lidsPantalla(this.lineas, prev); } else ponerLids({ id, lineas: this.lineas });
        if (prev) {   // 4.6: las marcas que la cocina puso mientras tanto (preparando, listo, entregado, impreso) se conservan
          const clave = l => [l.producto_id, l.detalle, l.enviado || '', l.ronda || 0, l.nota || ''].join('|'), marcas = new Map((prev.lineas || []).filter(l => l.enviado).map(l => [clave(l), l]));
          for (const l of this.lineas) { if (!l.enviado) continue; const m = marcas.get(clave(l)); if (!m) continue; for (const k of ['preparando', 'listo', 'entregado', 'impreso']) if (m[k] && !l[k]) l[k] = m[k]; if (m.comanda && !l.comanda) l.comanda = m.comanda; }   // 4.29: y el número de la comanda
        }
        this.ponerImportes();
        /* 4.31: lo que ESTA pantalla cambió desde lo último que sabe guardado (su base) viaja como `_fusion`: el servidor lo aplica sobre la */
        /* cuenta como esté en ese momento. Aquí se aplica ya sobre la copia local, así se ve en el acto lo que otro equipo ya guardó. */
        let f = null;
        if (prev) {
          const base = this.baseDe(id, prev), valores = { nombre, cliente_id: this.clienteId, nota: this.nota, servicio: this.servicio, servicio_pct: this.servicioPctCuenta, mesa_id: mesaId, salonero: this.salonero };
          const norm = v => JSON.stringify(v === undefined || v === '' ? null : v), cuentaCambios = Object.keys(valores).filter(k => norm(valores[k]) !== norm(base.cuenta[k]));
          f = conFusion(prev, diferencia(base.lineas, this.lineas), cuentaCambios, 'caja');
          const res = fusionarCuenta(prev, { ...prev, ...valores, lineas: this.lineas.map(x => ({ ...x })), _fusion: f });
          cambio = contarCambio(this.lineas, res.lineas);
          const sinEnviar0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));
          if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) { this.lineas = aplicarEnLugar(this.lineas, res.lineas); this.ponerImportes(); }
          { const ls = this.lineas.filter(l => l.enviado && sinEnviar0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)); if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === id && m1.env >= te)) this._marcaAjena = { id: id, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; } }   /* 4.39 (cuarta vuelta): como en fusionarAbierta */
        }
        const parte = prev ? prev.parte : (this.parteNueva ? Math.max(1, ...lista.filter(x => x.mesa_id === mesaId && (x.terminal_id || termId) === termId).map(x => +x.parte || 1)) + 1 : undefined);
        const reg = { id, nombre, cliente_id: this.clienteId, lineas: this.lineas.map(x => ({ ...x })), nota: this.nota, servicio: this.servicio, servicio_pct: this.servicioPctCuenta, creado: prev ? prev.creado : new Date().toISOString(), actualizado: new Date().toISOString(), usuario: sesion.usuario?.correo, total: this.totales.total, mesa_id: mesaId, terminal_id: termId, salonero: this.salonero,
          mesas_ids: prev ? prev.mesas_ids || [] : [], precuenta_pedida: prev ? prev.precuenta_pedida || null : null, cobros: prev ? prev.cobros || [] : [], partes: prev ? prev.partes || null : null, ...(parte ? { parte } : {}), ...(prev && prev.pedido ? { pedido: prev.pedido, telefono: prev.telefono, direccion: prev.direccion, hora_entrega: prev.hora_entrega, estado: prev.estado, hora_entregado: prev.hora_entregado } : {}), ...(prev && prev.canal ? { canal: prev.canal, pedido_id: prev.pedido_id, pedido_numero: prev.pedido_numero, prepago: prev.prepago || null, cupon: prev.cupon || null, puntos_canjeados: prev.puntos_canjeados || 0, credito: !!prev.credito } : {}) };   // 3.87: hora_entregado: el monitor separa las rondas de antes y de después de la entrega; 3.87: el pedido en línea conserva lo pagado y su enlace con el pedido (antes se cobraba otra vez al agregarle un plato)
        if (f) reg._fusion = f;   /* 4.31: una cuenta nueva (alta) va sin él */
        guardada = reg; existia = !!prev && (this._base && this._base.id === reg.id ? this._base.existia || !!(mock.confirmado && mock.confirmado('pos_espera', reg.id)) : true);   /* 4.31: el alta de esta pantalla, ya confirmada por el servidor, también «existía» */
        regId = reg.id; const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); return lista;
      }, []);
      if (guardada) this._base = tomarBaseDe(guardada, existia);
      if (guardada && existia) { const env = this._enviadas || (this._enviadas = new Map()); env.delete(guardada.id); env.set(guardada.id, guardada.nombre); if (env.size > 30) env.delete(env.keys().next().value); }   /* 4.31: si otro equipo la cobra mientras tanto, seguirIds avisa aunque ya no esté abierta */
      if (cambio) this.avisarCambio(cambio);
      if (this._vuelta && this._vuelta.id === regId) this._vuelta = null;   /* 4.31 (sexta vuelta): esta pantalla guardó algo más en esa cuenta: el aviso de cuenta nueva sí corresponde */
      this.esperaId = regId; this.parteNueva = false; return devolverId ? regId : nombre;
    },
    /* 4.31: lo que cada línea suma al total (los mismos términos de totalDe, sin redondear): el servidor rehace el total al unir dos guardados */
    ponerImportes() {
      try {
        const pct = this.servicio && this.servicioPct > 0 ? +this.servicioPct : 0;
        for (const l of this.lineas) {
          const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - this.descuentoDe(l), oi = this.oiLinea(l, m);
          l.importe = Math.round((m + oi.monto + (m + oi.base) * this.tarifaNeta(l) / 100 + (pct ? m * pct / 100 : 0)) * 100000) / 100000;
          l.importe_de = [l.cantidad, l.precio_unitario, l.descuento_pct, l.descuento];
        }
      } catch { /* sin importe el servidor deja el total que manda la pantalla */ }
    },
    /* 4.31: la base de la pantalla (lo último que sabe guardado de ESA cuenta, con su id); no es reactiva */
    tomarBase(v, existia = true) { this._base = v ? tomarBaseDe(v, existia) : null; },
    baseDe(id, prev) { return baseDeCuenta(this._base, id, prev); },
    /* 4.31: cambia UNA cuenta guardada (fn) diciendo qué cambió (_fusion): el servidor conserva lo que otro equipo cambió en lo demás */
    actualizarCuenta(id, fn, extra) { this.espera = mock.actualizar('pos_espera', l => (l || []).map(x => (x.id !== id ? x : conFusionDe(ponerLids(x), fn(x), 'caja', extra))), []); return this.espera; },   /* 4.31 (quinta vuelta): `extra` = {vuelve, enteras} (conFusion) */
    /* 4.31: baja de una cuenta con la condición de lo que esta pantalla cobró, quitó o pasó (lineas): el servidor la borra solo si no queda */
    /* nada más; si otro equipo le agregó algo en esos segundos, la cuenta sigue con eso y la próxima sincronización lo avisa. `cobro`: la */
    /* baja viene de un cobro (la cuenta que quede no se lleva lo ya pagado del pedido en línea) */
    bajaCuenta(id, lineas, nombre, cobro) {
      if (mock.condicionBaja) mock.condicionBaja('pos_espera', id, condicionDe(id, lineas, cobro === true));
      const lista = (mock.get('pos_espera', []) || []).filter(x => x.id !== id), guardado = mock.set('pos_espera', lista);
      this.espera = lista;
      (this._bajas || (this._bajas = new Map())).set(id, nombre || '');
      if (this._enviadas) this._enviadas.delete(id);   /* 4.31: la cerró esta pantalla: un id nuevo después no es «cobrada en otro equipo» */
      Promise.resolve(guardado).then(ok => { if (ok === true) return this.sincronizar(); }).catch(() => {});
      return lista;
    },
    /* 4.31 (sexta vuelta): lo que cierra la baja del cobro de la cuenta `id`: lo cobrado (lineas) y lo que esta pantalla quitó (✕) o bajó («−» */
    /* o la casilla) de lo que sabía guardado: su base de ESA cuenta y lo quitado en un guardado suyo todavía sin confirmar (y lo que ese */
    /* guardado bajó, con la cantidad que tiene el servidor según lo confirmado). Si no, el servidor dejaba en la mesa el plato devuelto, «sin */
    /* cobrar», como si otro equipo lo hubiera agregado */
    cierreCobro(id, lineas) {
      const base = this._base && id !== null && id !== undefined && this._base.id === id ? this._base.lineas : [], c = (mock.get('pos_espera', []) || []).find(x => x && x.id === id), f = c && c._fusion;
      const q = f && f.equipo === EQUIPO && f.origen === 'caja' ? { ...(f.quitadas || {}) } : null, conf = q && f.campos && mock.confirmadoDe ? mock.confirmadoDe('pos_espera', id) : null;
      if (conf) for (const l of conf.lineas || []) if (l && Array.isArray(f.campos[l.lid]) && f.campos[l.lid].includes('cantidad')) q[l.lid] = Math.max(+q[l.lid] || 0, +l.cantidad || 0);
      return cierreDeCobro(base, lineas, q);
    },
    /* 4.31: la cuenta abierta en pantalla se pone al día con lo guardado (lo que la pantalla tiene sin guardar se conserva). No guarda nada, */
    /* salvo corregir el total del plano. Devuelve cuántos platos llegaron y cuántos salieron. */
    fusionarAbierta(motivo) {
      const nada = { agregadas: 0, quitadas: 0 }, cobro = motivo === 'cobro';
      /* 4.39 (decimocuarta vuelta): tampoco mientras se escribe una cantidad (casilla con el cursor y un plato en 0 o vacío): la línea salía de la pantalla con un */
      /* aviso falso y el plato se borraba de la cuenta guardada sin la clave; la próxima sincronización, o el cobro, juntan */
      if (!this.esperaId || this.pago || this.cobrando || (this.cobroParcial && !cobro) || (this.dividir && !cobro) || this.unir || this.mover || this.lineaNota || this.modSel || this.pedido || this.habCargo || (!cobro && typeof document !== 'undefined' && document.activeElement && document.activeElement.type === 'number' && this.lineas.some(l => !(+l.cantidad > 0)))) return nada;
      const g0 = enEspera().find(v => v.id === this.esperaId), base = this._base && this._base.id === this.esperaId ? this._base : null;
      if (!g0 || !base) return nada;
      const g = ponerLids(JSON.parse(JSON.stringify(g0)));
      lidsPantalla(this.lineas, g);
      const dif = diferencia(base.lineas, this.lineas);
      const res = fusionarCuenta(g, { ...g, lineas: this.lineas.map(x => ({ ...x })), _fusion: { v: 1, origen: 'caja', nuevas: dif.nuevas, quitadas: dif.quitadas, campos: dif.campos, cuenta: [] } });
      const cambio = contarCambio(this.lineas, res.lineas);
      const sinEnviar0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));
      if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) this.lineas = aplicarEnLugar(this.lineas, res.lineas);
      /* 4.39 (sexta vuelta): la marca lleva la hora de esa comanda (env). Se espera hasta 4 s después de verla y nunca más de 8 s después de la comanda (la revisión del */
      /* otro equipo dura 3 s como mucho; lo demás es margen para relojes desfasados). La misma comanda, vista otra vez al juntar, no renueva la marca */
      { const ls = this.lineas.filter(l => l.enviado && sinEnviar0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)); if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === this.esperaId && m1.env >= te)) this._marcaAjena = { id: this.esperaId, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; } }   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro). Quinta vuelta: solo los que van a cocina, con una comanda de hace menos de 10 s */
      const antes = base.cuenta || {}, nombreBase = antes.nombre;
      this.tomarBase(g);
      if (g.nombre && this.nombreEspera === nombreBase) this.nombreEspera = g.nombre;   /* otro equipo unió o movió la mesa */
      /* lo que otro equipo cambió en la cuenta (mesa, cliente, nota, servicio, salonero) pasa a la pantalla si aquí no se cambió: si no, el */
      /* siguiente guardado lo mandaba como cambio de esta pantalla y deshacía lo del otro equipo (la cuenta volvía a la mesa vieja) */
      const norm = v => JSON.stringify(v === undefined || v === '' ? null : v), deOtro = (v, k) => norm(v) === norm(antes[k]) && norm(g[k]) !== norm(antes[k]);
      if (deOtro(this.mesaActual ? this.mesaActual.id : null, 'mesa_id')) this.mesaActual = g.mesa_id ? ((this.mesas || []).find(m => m.id === g.mesa_id) || { id: g.mesa_id, nombre: g.nombre || '' }) : null;
      let cambioCliente = false;   /* 4.31: el cliente que llega del otro equipo cambia los precios en pantalla (el observador de clienteId) */
      if (deOtro(this.clienteId, 'cliente_id')) { cambioCliente = norm(this.clienteId || null) !== norm(g.cliente_id || null); this.clienteId = g.cliente_id || null; }
      if (deOtro(this.nota, 'nota')) this.nota = g.nota || '';
      if (deOtro(this.servicio, 'servicio')) this.servicio = !!g.servicio;
      if (deOtro(this.servicioPctCuenta, 'servicio_pct')) this.servicioPctCuenta = g.servicio_pct !== undefined ? g.servicio_pct : null;
      if (deOtro(this.salonero, 'salonero')) this.salonero = g.salonero || '';
      /* 4.31: las promociones se vuelven a calcular solo si llegaron o salieron platos: si no, la parte que se cobra (cobro por partes, */
      /* «cobrar ahora solo esos», «· parte k de n») conserva el 2x1 con que se armó, como en la 4.29 */
      if (cambio.agregadas || cambio.quitadas) this.aplicarPromos();
      /* el total del plano se corrige solo si esta pantalla calcula como la cuenta guardada (mismo servicio y cliente, sin exoneración): dos */
      /* pantallas que calculan distinto ya no se pisan el total en cada sincronización; tampoco en la pasada en que llega el cliente del */
      /* otro equipo (los precios en pantalla se ponen al día después, con el observador del cliente) */
      const pend = diferencia(this._base.lineas, this.lineas), mismos = norm(this.servicio) === norm(g.servicio) && norm(this.servicioPctCuenta) === norm(g.servicio_pct) && norm(this.clienteId || null) === norm(g.cliente_id || null) && !this.exoAplica;
      if (mismos && !cambioCliente && !pend.nuevas.length && !Object.keys(pend.quitadas).length && !Object.keys(pend.campos).length && Math.abs(this.totales.total - (+g.total || 0)) > 0.01) { const total = this.totales.total; this.actualizarCuenta(g.id, x => ({ ...x, total })); }
      return cambio;
    },
    /* 4.31: antes de cobrar, dividir o cobrar por partes, la cuenta como está ahora en el servidor (1,5 s como mucho: con la red lenta se */
    /* sigue con la copia local y el servidor cuida lo que falte al cerrar la cuenta). Devuelve si la cuenta cambió. */
    async alDiaParaCobrar(sinAviso) {
      if (!this.esperaId || this.cobroParcial || !mock.puedeGuardar(false)) return false;
      if (this._alDia && Date.now() - this._alDia < 3000) return false;
      const antes = this.totales.total;
      await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]);
      this._alDia = Date.now(); this.espera = enEspera();
      const c = this.fusionarAbierta('cobro');
      if (!c.agregadas && !c.quitadas && Math.abs(this.totales.total - antes) <= 0.005) return false;
      if (sinAviso !== true) toast('La cuenta de ' + (this.nombreEspera || 'la cuenta') + ' cambió en otro equipo. Revise el total antes de cobrar.', 'err');   /* 4.31: tras «se está cobrando en otro equipo» no se repite */
      return true;
    },
    /* 4.31: lo que otro equipo cambió en la cuenta abierta (c = {agregadas, quitadas}), con «1 plato» o «2 platos» */
    avisarCambio(c, quien) {
      const m = quien || this.nombreEspera || 'la cuenta', a = c ? +c.agregadas || 0 : 0, q = c ? +c.quitadas || 0 : 0;
      if (a) toast(a === 1 ? 'Se sumó 1 plato que agregó otro equipo a la cuenta de ' + m + '.' : 'Se sumaron ' + a + ' platos que agregó otro equipo a la cuenta de ' + m + '.', 'ok');
      if (q) toast(q === 1 ? 'En otro equipo se quitó o cobró 1 plato de ' + m + '. La cuenta quedó como está ahora.' : 'En otro equipo se quitaron o cobraron ' + q + ' platos de ' + m + '. La cuenta quedó como está ahora.', 'err');
    },
    /* 4.31: la cuenta abierta quedó como cuenta nueva (la de antes se cobró o se cerró en otro equipo): se trae ya lo que quedó en ella, así */
    /* la pantalla, el plano y la precuenta no siguen mostrando lo que el otro equipo ya cobró */
    async alDiaCuentaNueva(id) {
      try { if (mock.refrescar) await mock.refrescar(['pos_espera'], { sinCorte: true }); } catch { /* sigue con la copia */ }
      this.espera = enEspera();
      /* 4.39 (cuarta vuelta): la cuenta rehecha que se llama «Cuenta N» y que ya usa otra cuenta abierta (otro equipo la creó mientras tanto) pasa al número siguiente */
      const cn = (this.espera || []).find(v => v && v.id === id), mismo = cn && /^Cuenta \d+$/.test(cn.nombre || '') && (this.esperaId !== id || !(this.nombreEspera || '').trim() || this.nombreEspera === cn.nombre) && this.espera.some(v => v && v.id !== id && v.nombre === cn.nombre);
      if (mismo) { const nombre = 'Cuenta ' + (Math.max(this.espera.length, ...this.espera.map(v => +((/^Cuenta (\d+)$/.exec((v && v.nombre) || '') || [])[1] || 0))) + 1); if (this.esperaId === id && this.nombreEspera === cn.nombre) this.nombreEspera = nombre; this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); toast('Ya había otra «' + cn.nombre + '» abierta: lo que agregó quedó en «' + nombre + '».', 'ok'); }   /* 4.39 (sexta vuelta): el aviso de seguirIds la nombró con el nombre de antes */
      if (this.esperaId === id) this.fusionarAbierta('sinc');
    },
    /* 4.31: los platos de esta comanda que ya estaban guardados sin enviar: otro equipo pudo quitarlos o cobrarlos mientras tanto */
    platosDudosos(nuevas) { const g = this.esperaId !== null && this.esperaId !== undefined ? lidsDeBase(this._base, this.esperaId) : null; return g && g.size ? (nuevas || []).filter(l => g.has(l.lid)) : []; },
    /* 4.31: comanda sin número con platos que ya estaban guardados sin enviar: la cuenta se guarda en el acto, como siempre (así «Mesas» */
    /* justo después no la pierde), y se imprime cuando se sabe qué sigue en la cuenta (revisarComanda) */
    comandaRevisada(nuevas, grupos, ronda, ahora) {
      let dudosas = this.platosDudosos(nuevas);
      const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();
      /* 4.39 (tercera vuelta): como en comandaNumerada, lo de la cuenta que se cobró o se cerró en otro equipo no sale ni pasa a la cuenta nueva */
      const idas = dudosas.length && this.esperaId !== id0 ? dudosas.filter(l => !this.lineas.some(x => x.lid === l.lid)) : [];
      if (idas.length) { nuevas = nuevas.filter(l => !idas.includes(l)); dudosas = dudosas.filter(l => !idas.includes(l)); for (const [k, g] of Object.entries(grupos)) { g.ls = g.ls.filter(l => !idas.includes(l)); if (!g.ls.length) delete grupos[k]; } if (!nuevas.length) return Promise.resolve(); }
      const e = { cuentaId: this.esperaId, nuevas, grupos, ronda, ahora, imprimir: this.cfg.imprimir_comanda !== false && Object.keys(grupos).length > 0,
        datos: { cuenta: this.nombreEspera, salonero: this.salonero, caja: this.cfg.nombre, nota: this.nota } };
      if (e.imprimir && !sesion.empresaInfo?.es_local && Object.values(grupos).some(g => !porAgente(g.imp))) { try { e.datos.ventana = window.open('', '_blank') || null; } catch { e.datos.ventana = null; } }   /* la ventana del navegador, en el toque */
      const enCamino = this._enCamino || (this._enCamino = new Set()); enCamino.add(e);   /* si el servidor le cambia el id a la cuenta, el envío lo sigue */
      const revisada = Promise.resolve().then(() => this.revisarComanda(e, dudosas)).catch(() => { try { this.comoPedidoNuevo(e.cuentaId, dudosas.filter(l => e.nuevas.includes(l))); } catch { /* la comanda sale igual */ } });   /* 4.31: si la revisión falla, sale todo (como «no se puede saber») */
      return revisada.then(() => {
        enCamino.delete(e);
        if (!e.nuevas.length) return;
        if (e.imprimir) this.imprimirComanda(e.grupos, e.ronda, e.datos);
        toast('Comanda ' + e.ronda + ' enviada' + (Object.keys(e.grupos).length ? ' a ' + Object.values(e.grupos).map(g => g.imp.nombre).join(', ') : ''), 'ok');
      });
    },
    /* 4.31: antes de imprimir, la cuenta como quedó en el servidor (3 s como mucho, lo mismo que el número de comanda): no sale lo que otro */
    /* equipo ya quitó o cobró, y se avisa en el momento. Si no se puede saber, sale todo y esos platos quedan en la cuenta como pedido nuevo */
    /* (comoPedidoNuevo): nunca un plato impreso que no se cobra. Cambia el envío `e` (sus platos y sus impresoras). */
    async revisarComanda(e, dudosas) {
      let sabe = false, c = null;
      try {
        /* 4.31 (tercera vuelta): lo de esta cuenta se sabe si la lista de cuentas se acaba de bajar del servidor, aunque justo después se */
        /* guarde otra cuenta o esta misma («Mesas» enseguida de «Comanda»); si algo quedó a medio subir se intenta otra vez, en los mismos 3 s */
        const tope = new Promise(res => setTimeout(() => res(false), 3000));
        for (let vuelta = 0; vuelta < 3 && !sabe; vuelta++) {
          const r = await Promise.race([Promise.resolve(mock.guardarTodo()).then(ok => (ok === true && mock.refrescar ? mock.refrescar(['pos_espera'], { sinCorte: true }) : false)), tope]);
          if (!Array.isArray(r)) break;
          sabe = r.includes('pos_espera') || !!(mock.alDia && mock.alDia('pos_espera'));
          if (sabe) c = (mock.get('pos_espera', []) || []).find(x => x.id === e.cuentaId) || null;   /* la cuenta como la tiene el servidor */
        }
      } catch { sabe = false; }
      if (!sabe) { this.comoPedidoNuevo(e.cuentaId, dudosas); return; }
      const siguen = new Set(c ? (c.lineas || []).map(l => l.lid) : []);
      /* 4.31 (tercera vuelta): otro equipo movió la cuenta de mesa: la comanda sale con la mesa de ahora y la pantalla se pone al día */
      const movida = !!(c && c.nombre && e.datos && e.datos.cuenta !== c.nombre); if (movida) e.datos.cuenta = c.nombre;
      /* 4.39 (tercera vuelta): tampoco lo que en el servidor ya figura enviado por otro equipo (otra marca de envío): allá salió su comanda */
      const ajenas = new Set(c ? (c.lineas || []).filter(l => l && l.enviado && l.enviado !== e.ahora).map(l => l.lid) : []);
      const fuera = dudosas.filter(l => !siguen.has(l.lid) || ajenas.has(l.lid)), yaSalio = fuera.every(l => siguen.has(l.lid));
      /* 4.39 (cuarta vuelta): de los platos que siguen, la comanda lleva la cantidad y la nota de la cuenta en el servidor (otro equipo pudo cambiarlas): */
      /* la cocina hace lo que se cobra. Son copias para imprimir; la pantalla se pone al día al sincronizar */
      const srv = new Map(c ? (c.lineas || []).filter(l => l && l.lid).map(l => [l.lid, l]) : []);
      for (const g of Object.values(e.grupos)) g.ls = g.ls.map(l => { const s = dudosas.includes(l) && !fuera.includes(l) ? srv.get(l.lid) : null; return s ? { ...l, cantidad: s.cantidad, nota: s.nota } : l; });
      if (!fuera.length) { if (movida && this.esperaId === e.cuentaId) { this.espera = enEspera(); this.avisarCambio(this.fusionarAbierta('comanda'), c.nombre); } return; }
      e.nuevas = e.nuevas.filter(l => !fuera.includes(l)); e.revisada = true;
      for (const [k, g] of Object.entries(e.grupos)) { g.ls = g.ls.filter(l => !fuera.includes(l)); if (!g.ls.length) delete e.grupos[k]; }
      if (!Object.keys(e.grupos).length) { e.imprimir = false; const w = e.datos && e.datos.ventana; if (w) { try { w.close(); } catch { /* ya cerrada */ } } }
      const m = (e.datos && e.datos.cuenta) || 'la cuenta', nombres = fuera.map(l => l.detalle).join(', ');
      if (yaSalio) toast(fuera.length === 1 ? 'No salió otra vez en la comanda: ' + nombres + '. Ya se había mandado a cocina desde otro equipo.' : 'No salieron otra vez en la comanda: ' + nombres + '. Ya se habían mandado a cocina desde otro equipo.', 'ok');
      else toast(fuera.length === 1 ? 'No salió en la comanda: ' + nombres + '. En otro equipo ya se había quitado o cobrado de ' + m + '.' : 'No salieron en la comanda: ' + nombres + '. En otro equipo ya se habían quitado o cobrado de ' + m + '.', 'err');
      if (this.esperaId === e.cuentaId) { this.espera = enEspera(); const cc = this.fusionarAbierta('comanda'); this.avisarCambio({ agregadas: cc.agregadas, quitadas: Math.max(0, cc.quitadas - fuera.filter(l => !siguen.has(l.lid)).length) }, m); }
    },
    /* 4.31: no se pudo saber si otro equipo quitó esos platos: salen en la comanda y quedan en la cuenta con otro lid (como pedido nuevo), */
    /* así el servidor los conserva aunque la línea de antes ya no esté; si estaba, la reemplaza (el mismo plato una sola vez) */
    comoPedidoNuevo(id, lineas) {
      const nuevos = new Map((lineas || []).filter(l => l && typeof l.lid === 'string' && l.lid).map(l => [l.lid, conLidNuevo(l)]));
      if (!nuevos.size || id === null || id === undefined) return;
      if (this.esperaId === id) for (const l of this.lineas) if (nuevos.has(l.lid)) l.lid = nuevos.get(l.lid).lid;
      this.actualizarCuenta(id, x => {
        const ls = [], vistos = new Set();
        for (const l of x.lineas || []) { const n = nuevos.get(l.lid); if (!n) { ls.push(l); continue; } vistos.add(l.lid); const { de, ...y } = l; ls.push({ ...y, lid: n.lid }); }
        for (const [viejo, n] of nuevos) if (!vistos.has(viejo)) ls.push(JSON.parse(JSON.stringify(n)));
        return { ...x, lineas: ls };
      });
    },
    /* 4.31 (la misma mesa, tercera vuelta): pide al servidor el cobro de la cuenta (la de la pantalla o la de la parte que se cobra) con */
    /* sus platos. Devuelve el cobro pedido ({id, clave}), el choque ({ocupada, resultado, comunes}: otra pestaña la está cobrando o ya */
    /* cobró esos platos), {sinRed} sin conexión o null con un servidor sin esta ruta: en esos dos se cobra como siempre. Lo pendiente de guardar sube antes */
    /* (2 s como mucho), así el servidor ya tiene el id definitivo de la cuenta. */
    async reclamarCobro(lineas) {
      if (red.enLinea === false) return { sinRed: true };   /* 4.31 (sexta vuelta): sin conexión no se sabe nada (el cobro sigue como siempre; la parte que se cierra no vuelve todavía) */
      const c0 = this.cuentaDelCobro();   /* 4.31 (cuarta vuelta): ANTES de subir lo pendiente: si ese guardado hace que el servidor rehaga la cuenta (otro equipo ya la cerró), el cobro se pide igual para la de antes */
      if (mock.pendientes) { try { await Promise.race([Promise.resolve(mock.guardarTodo()).catch(() => {}), new Promise(r => setTimeout(r, 2000))]); } catch { /* sigue */ } }
      const cp = this.cobroParcial, ahora = cp ? cp.cuentaId : this.esperaId, id = c0.existia ? c0.id : (ahora ?? c0.id);   /* una cuenta que todavía no estaba en el servidor: la del id que le dio */
      if (typeof id !== 'number' || !(id > 0)) return null;
      const clave = nuevoLid(), lids = [...new Set((lineas || []).map(l => l && l.lid).filter(x => typeof x === 'string' && x))].slice(0, 300);
      const k = this._cobrosParte, deParte = !!(cp && k && k.de === cp), cobros = deParte ? k.n : undefined;   /* los cobros que tenía la cuenta al armar esta parte */
      /* 4.31 (sexta vuelta): lo que esta parte dejó en la cuenta (sus restos): si la cuenta tiene el resto de uno de sus platos que dejó otro */
      /* equipo, los dos partieron lo mismo a la vez y esa porción ya está en la parte del otro («partida») */
      const restos = deParte && Array.isArray(k.restos) ? k.restos.filter(x => typeof x === 'string' && x).slice(0, 300) : null;
      /* 4.31 (séptima vuelta): el par del 2x1 de esta parte (lo que quedó en la cuenta del mismo plato): el servidor dice cuáles ya se cobraron */
      /* (`cobrados`) y solo con eso lo que vuelve conserva el 2x1 (devolverParte) */
      const pares = deParte && k.pares && typeof k.pares === 'object' ? Object.keys(k.pares).slice(0, 300) : [];
      const cuerpo = { cuenta_id: id, equipo: EQUIPO, clave, lids, ...(Number.isInteger(cobros) ? { cobros } : {}), ...(restos ? { restos } : {}), ...(pares.length ? { pares } : {}) };
      let r = null;
      try { r = await api('/api/pos/cobro/reclamar', { method: 'POST', body: cuerpo, limite: 8000 }); }
      catch (e) { return e && e.status === 404 ? null : e && e.sinConexion ? { sinRed: true } : { id, clave, lids, incierto: true }; }   /* sin respuesta clara: se cobra y al final se suelta igual */
      const res = r && r.resultado, cobrados = pares.length && r && Array.isArray(r.pares_cobrados) ? { cobrados: r.pares_cobrados.filter(x => typeof x === 'string') } : {};
      if (res === 'ocupada' || res === 'cobrada' || res === 'cambiada' || res === 'partida') return { ocupada: true, resultado: res, comunes: Array.isArray(r.comunes) ? r.comunes : [], id, vence: r.vence || '', ...cobrados };
      return { id, clave, lids, incierto: res !== 'ganada', ...cobrados };
    },
    /* 4.31: termina el cobro pedido (rc): si se emitió (cobrado), sus platos quedan anotados como cobrados en el servidor. `sigue`: ya se */
    /* emitió y el cobro todavía termina (pagos, Bancos). Al soltar después de cobrar, primero sube lo pendiente (5 s como mucho): así el */
    /* otro equipo, al pedir el cobro, ya encuentra la cuenta como quedó. No se espera ni lanza. */
    soltarCobro(rc, cobrado, lineas, sigue) {
      if (!rc || !rc.clave) return;
      const lids = cobrado ? [...new Set((lineas || []).map(l => l && l.lid).filter(x => typeof x === 'string' && x))].slice(0, 300) : [];
      const enviar = () => api('/api/pos/cobro/soltar', { method: 'POST', body: { cuenta_id: rc.id, clave: rc.clave, cobrado: !!cobrado, lids, ...(sigue ? { sigue: true } : {}) } }).catch(() => {});
      if (!cobrado || sigue || !mock.pendientes) return enviar();
      return Promise.race([Promise.resolve().then(() => mock.guardarTodo()).catch(() => {}), new Promise(r => setTimeout(r, 5000))]).then(enviar, enviar);
    },
    /* 4.31: otro equipo está cobrando esta cuenta (o ya cobró estos platos): aquí no se emite nada y la caja se pone al día. Lo de la parte */
    /* que el otro cobra no vuelve a la cuenta; lo demás vuelve como al cancelar el cobro. */
    async cobroOcupado(r) {
      this.cobrando = false;
      const res = r && r.resultado, cp = this.cobroParcial, comunes = new Set(res === 'cobrada' || res === 'partida' ? (r.comunes || []) : []);
      /* 4.39 (séptima vuelta): «cerrada», la cuenta ya no está después de esperar la comanda de otro equipo (borrada, pasada a otra mesa o cobrada): sin este */
      /* aviso, que decía «ya se cobró»; sincronizar, más abajo, da el de siempre («fue cobrada o cerrada en otro equipo») */
      if (res !== 'cerrada') toast(res === 'ocupada' ? 'Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar.' : res === 'partida' ? 'Otro equipo partió esta misma cuenta a la vez. Aquí no se cobró nada; revise la cuenta y cobre lo que queda.' : 'Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar.', 'err');
      /* 4.31 (cuarta vuelta): con «ocupada» el otro equipo todavía no emitió: nada de la parte se da por cobrado (si no llegaba a emitir, esos */
      /* platos se perdían). El cobro queda abierto aquí: al tocar otra vez, el servidor dice si ya se cobraron (y entonces se descartan) o si */
      /* se pueden cobrar. 4.31 (sexta vuelta): también sin platos en común (no se sabe si el otro la cobra). Solo con «cobrada» se descartan */
      /* platos, y la parte que el otro cobró ya cuenta como cobrada (el botón dice la que sigue); con «partida», los que otro equipo partió a */
      /* la vez (ya están en su parte); con «cambiada» la parte vuelve a la cuenta */
      if (cp && res === 'ocupada') { this._ocupada = cp; return; }
      this._ocupada = null;
      if (cp && res === 'cobrada' && cp.parte && comunes.size) { const k = this._cobrosParte; this.partesOtro = { id: cp.cuentaId, cobradas: cp.parte, cobros: (k && k.de === cp ? +k.n || 0 : 0) + 1 }; }
      if (cp) this.devolverParte(cp, this.lineas.filter(l => !comunes.has(l.lid)).map(x => ({ ...x })), { cobrados: [...(Array.isArray(r.cobrados) ? r.cobrados : []), ...comunes] });   /* 4.31 (quinta vuelta): lo que no cobró el otro vuelve siempre; (séptima) con lo que el servidor confirmó cobrado */
      else this.pago = null;
      this._alDia = 0;
      try { await this.alDiaParaCobrar(true); } catch { /* sigue con la copia */ }
      if (this.esperaId && !enEspera().some(v => v.id === this.esperaId)) this.sincronizar();   /* ya se cobró y se cerró: vuelve al plano con el aviso de siempre */
      else { if (res === 'cerrada' && this.esperaId) toast('Aquí no se cobró ni se cargó nada: la cuenta cambió en otro equipo. Revísela antes de cobrar.', 'err'); this.seguirCobroAjeno(this.esperaId); }   /* 4.31 (cuarta vuelta): y se pone al día cuando el otro equipo termine. 4.39 (séptima vuelta): con «cerrada», el aviso si la cuenta sigue en la lista */
    },
    /* 4.39: la comanda automática de la venta rápida (emitirCobro) guarda la cuenta y la junta con lo que otro equipo hizo con la ventana */
    /* de cobro abierta. Si la cuenta quedó con otro id (otro equipo la cobró o la cerró y aquí se rehízo con lo nuevo) o con otros platos o */
    /* cantidades o con otro total que lo que se iba a cobrar (id0, lineas0, total0: lo de antes de la comanda), no se emite: el total, los medios y el cobro que */
    /* se pide al servidor serían de otra cuenta (un plato cobrado a medias o la cuenta cobrada dos veces). Con otro id, como «ya se cobró en */
    /* otro equipo»: se cierra la ventana y la pantalla queda con lo que quedó; con otros platos, la ventana sigue abierta con el total */
    /* nuevo. Devuelve null si nada cambió (y siempre en una venta rápida nueva, sin cuenta al empezar): el cobro sigue como siempre. */
    /* 4.39 (revisión): `alta0`, la cuenta todavía no estaba en el servidor (su alta no se había confirmado): si el servidor le dio otro id */
    /* es porque chocó con la de otra caja, no porque la cobraran; se sigue con el id nuevo y solo cuentan los platos y el total */
    cobroCambiado(id0, lineas0, total0, alta0, cargo) {
      if (id0 === null || id0 === undefined) return null;
      const firma = ls => (ls || []).map(l => JSON.stringify([l ? l.lid : null, +(l && l.cantidad) || 0])).sort().join();
      const otraCuenta = this.esperaId !== id0 && alta0 !== true;
      if (!otraCuenta && firma(this.lineas) === firma(lineas0) && Math.abs((+this.totales.total || 0) - (+total0 || 0)) <= 0.005) return null;   /* el total: otro equipo pudo cambiar un precio o un descuento */
      if (otraCuenta) return this.cobroOcupado({ resultado: 'cobrada', comunes: [] });
      this.cobrando = false;
      toast(cargo ? 'La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar.' : 'La cuenta cambió en otro equipo y aquí no se cobró nada. Revise el total antes de cobrar.', 'err');   /* 4.39 (tercera vuelta): «cargo», desde la ventana de la habitación */
      if (this.pago && !this.lineas.length) this.pago = null; else if (this.pago) this.propinaCambio();   /* un solo medio de pago queda por el total nuevo, como al cambiar la propina */
      return Promise.resolve(true);
    },
    /* 4.39 (revisión): la venta rápida que ya mandó comanda y que otro equipo cobró o cerró con la ventana de cobro abierta, cuando esta */
    /* caja ya lo sabe (la cuenta no está en la lista). No sale comanda ni se emite; como al sincronizar sin cobro abierto, en pantalla */
    /* queda como venta nueva solo lo que no se había enviado, y se cobra después una sola vez */
    cobroDeCuentaCerrada() {
      const m = (this.nombreEspera || '').trim();
      this.cobrando = false; this.pago = null; this.espera = enEspera();
      /* 4.39 (revisión de los arreglos): solo lo que esta pantalla agregó sin guardar; lo guardado sin enviar ya estaba en la cuenta que el otro equipo cobró */
      const g = lidsDeBase(this._base, this.esperaId); this.lineas = this.lineas.filter(l => !l.enviado && !g.has(l.lid)); this.esperaId = null;
      if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true;   /* lo que queda es una venta rápida: su comanda sale al cobrarla (también en cajas con mesas) */
      toast((m ? 'La cuenta «' + m + '»' : 'Esta cuenta') + ' fue cobrada o cerrada en otro equipo y aquí no se cobró nada.' + (this.lineas.length ? ' Lo que no se había enviado sigue en pantalla como venta nueva: revise el total antes de cobrar.' : ''), 'err');
      return Promise.resolve(true);
    },
    /* 4.31 (quinta vuelta): se cierra sin cobrar el cobro de una parte. Antes de devolverla a la cuenta se pregunta al servidor: lo que otro */
    /* equipo ya cobró de esa parte no vuelve (se cobraría dos veces) y lo demás vuelve SIEMPRE (devolverParte). 4.31 (sexta vuelta): mientras */
    /* se pregunta, la ventana dice «Revisando…». Sin una respuesta clara (sin conexión, el servidor tarda o falla, u otro equipo está */
    /* cobrando la cuenta) la parte no vuelve: el cobro sigue abierto con el aviso (y cuánto falta) y se pregunta otra vez al tocar Cancelar. */
    /* Vuelve con «ganada», sin lo que otro cobró («cobrada») o partió a la vez («partida»), o con «cambiada»; sin la ruta en el servidor o */
    /* sin cuenta guardada, como siempre */
    async cerrarParte(cp) {
      if (this.cobrando) return;
      this.cobrando = true; this.revisando = true; let rc = null;
      try { rc = await this.reclamarCobro(this.lineas); } catch { rc = { sinRed: true }; } finally { this.cobrando = false; this.revisando = false; }
      if (rc && rc.clave) this.soltarCobro(rc, false);
      if (this.cobroParcial !== cp) return;
      /* 4.31 (séptima vuelta): sin conexión, el primer Cancelar deja el aviso y el segundo seguido devuelve la parte a la cuenta, como en la 4.30 (el */
      /* guardado pendiente lleva `vuelve` y, al volver la red, el servidor aplica la regla): si no, la caja quedaba trabada todo el corte y, al */
      /* recargar, la parte se perdía. «incierto» (el servidor falla o tarda) y «ocupada» siguen esperando una respuesta clara */
      if (rc && rc.sinRed && this._sinRed === cp) return this.devolverParte(cp, this.lineas.map(x => ({ ...x })), { sinRed: true });
      if (rc && (rc.sinRed || rc.incierto || rc.resultado === 'ocupada')) { this._ocupada = cp; this._sinRed = rc.sinRed ? cp : null; return toast(this.textoOcupada(rc), 'err'); }
      this._ocupada = null; this._sinRed = null;
      if (rc && rc.ocupada) return this.cobroOcupado(rc);   /* cobrada, cambiada o partida */
      return this.devolverParte(cp, this.lineas.map(x => ({ ...x })), { cobrados: rc && rc.cobrados });
    },
    /* 4.31 (quinta vuelta): «se está cobrando en otro equipo», con cuánto falta para que el reclamo del otro venza (si se sabe). 4.31 (sexta */
    /* vuelta): la parte sigue abierta hasta que el servidor conteste claro; sin respuesta, se dice eso */
    textoOcupada(rc) {
      if (!rc || rc.resultado !== 'ocupada') return 'No se pudo confirmar con el servidor si otro equipo cobró esta parte. Sigue abierta aquí: toque Cancelar otra vez en unos segundos para devolverla a la cuenta.';
      const t = Date.parse(rc.vence || ''), s = Number.isFinite(t) ? Math.ceil((t - Date.now()) / 1000) : NaN;
      const cuando = s > 0 ? 'Se libera en ' + (s === 1 ? '1 segundo' : s + ' segundos') + ' como mucho. ' : 'Espere unos segundos. ';
      return 'Esta cuenta se está cobrando en otro equipo. ' + cuando + 'Esta parte sigue abierta aquí: cuando se libere, toque Cancelar otra vez para devolverla a la cuenta (lo que el otro equipo cobre no vuelve).';
    },
    /* 4.31 (quinta vuelta): la parte de un cobro que no se emitió vuelve a la cuenta y NUNCA desaparece. Se suma a su plato (½ + ½ = 1) y el */
    /* servidor sabe cuánto vuelve (`vuelve`): si ese plato ya no está (otro equipo lo cobró o lo partió), esa cantidad queda sola en la cuenta. */
    /* Si la cuenta ya no está, la parte vuelve a la mesa (a la cuenta que tenga o en una nueva) con el aviso. 4.31 (sexta vuelta): sin la */
    /* variante «aparte». 4.31 (séptima vuelta), una sola regla en todas las ramas: la línea que vuelve conserva el 2x1 (`promo_fija` = su */
    /* cantidad) SOLO si el servidor confirmó que su par se cobró (`op.cobrados`: lo que el otro equipo cobró de esta parte, «cobrada» o */
    /* «partida», o lo que quedó en la cuenta del mismo plato y ya está cobrado); si no, se calcula como cualquier línea y la cuenta se guarda */
    /* así. Cada línea se suma primero a lo que quedó de ella misma (`de`) y nunca a una que el servidor ya dio por cobrada. `op.sinRed`: */
    /* sin conexión (segundo Cancelar): vuelve con su aviso y el servidor aplica la regla al volver la red */
    devolverParte(cp, parte, op) {
      const k = this._cobrosParte && this._cobrosParte.de === cp ? this._cobrosParte : null, o = op || {};
      const mesa = this.mesaActual, nombre = this.nombreEspera || (mesa ? mesa.nombre : 'la cuenta');
      const grupo = l => String(l.producto_id) + '|' + String(l.enviado || ''), cobrados = new Set(Array.isArray(o.cobrados) ? o.cobrados : []);
      const gruposDe = new Map([...Object.entries(k && k.pares && typeof k.pares === 'object' ? k.pares : {}), ...this.lineas.filter(l => l && typeof l.lid === 'string' && l.lid).map(l => [l.lid, grupo(l)])]);
      const pagados = new Set([...cobrados].filter(lid => gruposDe.has(lid)).map(lid => gruposDe.get(lid)));   /* los platos cuyo par ya se cobró */
      this.pago = null; this.cobroParcial = null; this._ocupada = null; this._sinRed = null;
      const lineas = (parte || []).filter(l => l && +l.cantidad > 0), c0 = enEspera().find(x => x.id === cp.cuentaId);
      const aviso = () => (o.sinRed ? toast('Sin conexión: la parte volvió a la cuenta; revise el total al volver la red.', 'err') : toast('La parte que tenía abierta volvió a ' + nombre + ': ' + [...new Set(lineas.map(l => l.detalle))].join(', ') + '.', 'ok'));
      const suelta = l => { const n = conLidNuevo(l); if (+l.descuento_pct > 0 && l.promo && !l.descuento_manual && !l.combo && pagados.has(grupo(l))) n.promo_fija = +l.cantidad; return n; };
      let destino = c0 ? cp.cuentaId : null;
      if (lineas.length && c0) {
        // las fracciones vuelven a juntarse con su plato para no dejar la cuenta partida en líneas repetidas; la que vuelve sola es una línea nueva
        const misma = (a, b) => a.producto_id === b.producto_id && a.detalle === b.detalle && +a.precio_unitario === +b.precio_unitario && String(a.nota || '') === String(b.nota || '') && String(a.enviado || '') === String(b.enviado || '') && (+a.descuento_pct || 0) === (+b.descuento_pct || 0) && String(a.promo || '') === String(b.promo || '');
        const grupos = new Set(lineas.map(grupo)), vuelve = {}, sueltas = new Set();
        this.actualizarCuenta(cp.cuentaId, x => {
          const out = (x.lineas || []).map(y => ({ ...y }));
          for (const l of lineas) {
            const libre = y => !cobrados.has(y.lid) && misma(y, l);
            let i = out.findIndex(y => y.de === l.lid && libre(y)); if (i < 0) i = out.findIndex(libre);   /* 4.31 (séptima vuelta): primero lo que quedó de ella misma */
            if (i < 0) { const n = suelta(l); sueltas.add(n.lid); out.push(n); continue; }
            out[i].cantidad = Math.round((+out[i].cantidad + +l.cantidad) * 1000) / 1000; vuelve[out[i].lid] = Math.round(((vuelve[out[i].lid] || 0) + +l.cantidad) * 1000) / 1000;
            if (sueltas.has(out[i].lid) && out[i].promo_fija) out[i].promo_fija = out[i].cantidad;
          }
          for (const y of out) if (y.promo_fija && grupos.has(grupo(y)) && !sueltas.has(y.lid)) delete y.promo_fija;   /* el par del 2x1 vuelve a estar completo */
          return { ...x, lineas: out, total: this.totalDe(out, x.servicio, x.servicio_pct), partes: x.partes && +x.partes.cobradas === 0 ? null : x.partes };
        }, { vuelve });
        this._vuelta = { id: cp.cuentaId, hasta: Date.now() + 20000 };   /* si el servidor la rehace con otro id, no es «usted agregaba platos» (seguirIds): sale el aviso de la parte */
        /* lo que esta pantalla dejó en la cuenta ya no está (otro equipo lo cobró o lo partió): la parte queda sola y se avisa; si la copia */
        /* estaba atrasada, se avisa cuando el servidor diga que la dejó sola */
        const hay = new Set((c0.lineas || []).map(l => l.lid));
        if (o.sinRed || (k && (k.restos || []).some(lid => !hay.has(lid)))) aviso(); else if (Object.keys(vuelve).length) this.avisarVuelta(Object.keys(vuelve).map(lid => lid + '+v'), aviso);
      } else if (lineas.length) {
        const nuevas = lineas.map(suelta), cu = mesa ? cuentasDeMesa(mesa.id, this.cfg.id)[0] || null : null;
        if (cu) { this.actualizarCuenta(cu.id, x => { const ls = [...(x.lineas || []), ...nuevas]; return { ...x, lineas: ls, actualizado: new Date().toISOString(), total: this.totalDe(ls, x.servicio, x.servicio_pct) }; }); destino = cu.id; }
        else destino = this.nuevaCuentaEspera(nombre, nuevas, mesa ? mesa.id : null, mesa ? { servicio_pct: servicioDeMesa(this.cfg, mesa) } : null);
        aviso();
      }
      this.idem = uuid();
      const c = destino !== null ? enEspera().find(x => x.id === destino) : null;
      if (!c) { this.lineas = []; if (this.esRestaurante) this.volverAMesas(true); return; }
      this.cargarCuenta(c);
      /* 4.31 (séptima vuelta): lo que volvió sin la marca del 2x1 se calcula como cualquier línea (lo que quedó de una línea partida, `de`, y lo */
      /* marcado no cambian) y la cuenta se guarda así: si no, una Cerveza sola quedaba al 50 % para cualquier equipo que la abriera */
      const antes = JSON.stringify(this.lineas); this.aplicarPromos();
      if (JSON.stringify(this.lineas) === antes) return;
      const ls = this.lineas.map(x => ({ ...x }));
      this.actualizarCuenta(c.id, x => ({ ...x, lineas: ls, total: this.totalDe(ls, x.servicio, x.servicio_pct) }));
      const c2 = enEspera().find(x => x.id === c.id); if (c2) this.cargarCuenta(c2);
    },
    /* 4.31 (quinta vuelta): la parte volvió a una cuenta que esta pantalla tenía atrasada: si el servidor la dejó sola (`<lid>+v`: el plato al */
    /* que se sumó ya no estaba), se avisa cuando se sabe. No se espera ni lanza */
    avisarVuelta(lids, aviso) {
      const buscar = new Set(lids);
      return Promise.race([Promise.resolve().then(() => mock.guardarTodo()).catch(() => {}), new Promise(r => setTimeout(r, 5000))])
        .then(() => (mock.refrescar ? mock.refrescar(['pos_espera'], { sinCorte: true }) : null)).catch(() => {})
        .then(() => {
          const v = enEspera().find(x => (x.lineas || []).some(l => buscar.has(l.lid))); if (!v) return;
          aviso(); if (this.esperaId === v.id) { this.espera = enEspera(); this.fusionarAbierta('sinc'); }
        }).catch(() => {});
    },
    /* 4.31 (cuarta vuelta): después de un cobro que tenía otro equipo, la cuenta en pantalla se pone al día sola mientras el otro termina (cada */
    /* segundo, 12 s como mucho): si ya se cerró, sale el aviso de siempre y vuelve al plano; si quedó algo, se ve lo que quedó. Deja de mirar */
    /* en cuanto se toca otra cosa (cobrar, dividir, otra mesa) */
    seguirCobroAjeno(id) {
      if (id === null || id === undefined) return;
      const t = this._seguirCobro = { id };
      const vuelta = async n => {
        if (this._seguirCobro !== t || this._fuera || this.esperaId !== id || this.pago || this.cobrando || this.cobroParcial || this.dividir || this.habCargo) return;
        this._alDia = 0;
        try { await this.alDiaParaCobrar(true); } catch { /* sigue con la copia */ }
        if (this._seguirCobro !== t || this.esperaId !== id) return;
        if (!enEspera().some(v => v.id === id)) { this._seguirCobro = null; this.sincronizar(); return; }
        if (n < 12) setTimeout(() => vuelta(n + 1), 1000); else this._seguirCobro = null;
      };
      setTimeout(() => vuelta(1), 1000);
    },
    /* 4.31 (cuarta vuelta): la cuenta de la que salen los platos que se cobran, como la conoce el servidor: la de la parte (tomada ANTES de */
    /* volver a guardarla) o la de la pantalla. `existia`: ya estaba guardada en el servidor; si otro equipo la cobró o la cerró mientras tanto, */
    /* el cobro se pide para ESA cuenta (tiene anotados los platos cobrados), no para la que el servidor rehace con lo agregado */
    cuentaDelCobro() {
      const cp = this.cobroParcial, k = this._cobrosParte;
      if (cp) return k && k.de === cp && k.cuenta !== null && k.cuenta !== undefined ? { id: k.cuenta, existia: !!k.existia } : { id: cp.cuentaId, existia: false };
      return { id: this.esperaId, existia: this.yaGuardada(this.esperaId) };
    },
    yaGuardada(id) { return id !== null && id !== undefined && (!!(this._base && this._base.id === id && this._base.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', id))); },
    /* 4.31 (cuarta vuelta): la cuenta abierta ya estaba guardada y no está en la lista: otro equipo la cobró o la cerró. No se parte ni se */
    /* cobra: la sincronización avisa y vuelve al plano (o deja en pantalla lo que no se había enviado) */
    cerradaAfuera() {
      const id = this.esperaId;
      if (id === null || id === undefined || !this.yaGuardada(id) || enEspera().some(v => v.id === id)) return false;
      this.dividir = null; this.sincronizar(); return true;   /* 4.31 (quinta vuelta): también se cierra «Dividir» (si no, quedaba encima del plano) */
    },
    /* 4.31 (cuarta vuelta): las partes y los cobros de la cuenta como se saben aquí: si otro equipo acaba de cobrar la misma parte y su cobro */
    /* todavía no llegó a la cuenta, ya cuenta como cobrada (el botón dice la parte que sigue y se cobra lo que queda) */
    partesDe(c) {
      const p = c && c.partes && +c.partes.total > 1 ? c.partes : null, o = this.partesOtro;
      return p && o && o.id === c.id && (+o.cobradas || 0) > (+p.cobradas || 0) ? { ...p, cobradas: +o.cobradas } : p;
    },
    cobrosDe(c) { const n = c && Array.isArray(c.cobros) ? c.cobros.length : 0, o = this.partesOtro; return c && o && o.id === c.id ? Math.max(n, +o.cobros || 0) : n; },
    /* 4.31: cargar a la habitación una cuenta guardada: primero se pide su cobro (como al cobrar); con el cobro pedido se carga */
    async reclamarHab() {
      if (this._habEnCurso) return; this._habEnCurso = true;
      const hc = this.habCargo;
      try {
        const esperoHab = !!(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000);   /* 4.39 (séptima vuelta): si aquí se espera la comanda de otro equipo, después se junta lo que guardó (abajo) */
        { const ma = this._marcaAjena, id1 = this.esperaId; if (ma && ma.id === id1) { for (let i = 0; i < 20 && Date.now() < ma.t + 4000 && this.habCargo === hc && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200)); if (this.habCargo !== hc || this.esperaId !== id1) return; } }   /* 4.39 (cuarta vuelta): como al cobrar (emitirCobro) */
        lidsPantalla(this.lineas, this.cuentaActual);
        let rc = null; try { rc = await this.reclamarCobro(this.lineas); } catch { rc = null; }
        if (rc && rc.ocupada) { this.habCargo = null; return this.cobroOcupado(rc); }
        if (this.habCargo !== hc || !this.esperaId) { if (rc && rc.clave) this.soltarCobro(rc, false); return; }   /* se cerró la ventana mientras tanto */
        this._rcHab = rc || {};
        /* 4.39 (revisión de los arreglos): con platos sin enviar que salen a cocina (como al cobrar), antes de imprimir se trae y se junta lo que otro equipo */
        /* guardó (con la ventana abierta no entra a la pantalla). Si la cuenta ya no está o cambió, no sale comanda ni se carga nada (el finally suelta el cobro) */
        const rapHab = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l));   /* 4.39 (séptima vuelta): la revisión de aquí abajo; lo demás va por la de la mesa */
        if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) {
          const id0 = this.esperaId, lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total, sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));
          /* 4.39 (tercera vuelta): después de cada espera se sigue solo si la pantalla sigue en esa cuenta. Si un plato que aquí estaba sin enviar llegó */
          /* enviado (otro equipo tocó «Comanda»), allá se está revisando su comanda (3 s como mucho): se espera a que termine y se junta otra vez */
          for (let vuelta = 0; ; vuelta++) {
            try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }
            if (this.habCargo !== hc || this.esperaId !== id0) return;
            if (!enEspera().some(v => v.id === id0)) { this.habCargo = null; return this.cobroDeCuentaCerrada(); }
            try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }
            if (this.habCargo !== hc || this.esperaId !== id0) return;
            if (vuelta > 1 || (vuelta ? !(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000) : !this.lineas.some(l => l.enviado && sin0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)))) break;   /* 4.39 (séptima vuelta): otra vuelta solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó) */
            { const ma = this._marcaAjena, fin = ma && ma.id === this.esperaId ? ma.t + 4000 : Date.now() + 4000; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200)); }   /* 4.39 (cuarta vuelta): en tramos: al cerrar la ventana se deja de esperar. Sexta vuelta: solo lo que falta (la marca que dejó persistirCuenta al juntar) */
          }
          if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */
        }
        /* 4.39 (quinta vuelta): en una mesa (sin la revisión de arriba), como al cobrarla: si otro equipo acaba de mandar a cocina un plato que aquí está sin enviar, se espera su comanda */
        /* 4.39 (séptima vuelta): también la venta rápida o la cuenta guardada sin platos por enviar, si arriba se esperó la comanda de otro equipo (esperoHab): */
        /* después de esperar se junta lo que ese equipo guardó. Y si al juntar llegó una comanda más nueva suya (la marca se renovó), se espera y se junta otra vez */
        if (this.esRestaurante && !this.cobroParcial && !rapHab) {
          const idM = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
          if (idM !== null && idM !== undefined && (sin1.size || esperoHab)) {
            let junta = esperoHab;
            if (sin1.size) {
              try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ }
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              const c1 = enEspera().find(v => v.id === idM), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)) : [];
              /* 4.39 (sexta vuelta): solo lo que falta (la marca, con la hora de esa comanda: al volver a tocar «Cargar» no se espera otra vez) y después se junta lo */
              /* que otro equipo guardó: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se carga nada (el finally suelta el cobro) */
              if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === idM && m1.env >= te)) this._marcaAjena = { id: idM, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; junta = true; }
            }
            const lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total;
            for (let k = 0; junta && k < 2; k++) {
              { const m2 = this._marcaAjena, fin = m2 && m2.id === idM ? m2.t + 4000 : 0; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200)); }
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }
              try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }
              if (this.habCargo !== hc) return;
              if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */
              junta = !!(this._marcaAjena && this._marcaAjena.id === idM && Date.now() < this._marcaAjena.t + 4000);
            }
          }
        }
        this._habSigue = true; this.cargarAHabitacion();   /* 4.39 (tercera vuelta): solo esta llamada pasa la puerta de cargarAHabitacion mientras se revisa */
      } finally {
        const sobra = this._rcHab; this._rcHab = null; this._habEnCurso = false; this._habSigue = false;
        if (sobra && sobra.clave) this.soltarCobro(sobra, false);   /* no se cargó (faltaba algo): el cobro queda libre */
      }
    },
    ponerEnEspera() {
      if (!this.lineas.length) return toast('No hay nada en el carrito', 'err');
      const nombre = this.persistirCuenta();
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.idem = uuid(); this.modalEspera = false; this.mesaActual = null; toast('«' + nombre + '» guardada', 'ok');
    },
    // 4.32: la ventana «Pedidos web». En el programa que atiende los pedidos en línea el pedido nuevo se acepta aquí mismo (como en
    // Ventas en línea › Pedidos del programa: la cuenta entra a esta caja y la comanda la saca la estación de esta caja). En la página
    // web el botón llevaba a Ventas en línea › Pedidos (4.39: ya no; se acepta aquí también, ver abajo). Los aceptados que ya
    // están en esta caja se abren para cobrar. Mientras la ventana está abierta se recarga con cada consulta del resumen.
    abrirPanelWeb() { this.online.sinVer = 0; const prog = this.enProgWeb; this.panelWeb = { cargando: true, lista: [], error: '', aceptando: {}, ver: null, cancelar: null, imprime: prog ? this.imprimeProgWeb() : null, listo: prog }; this.cargarPanelWeb(); if (!prog) this.prepararWeb(this.panelWeb); },   /* 4.39: en la página web, lo de imprimir se lee antes del toque (sin esperar; no lanza) y «Imprimir comanda» espera a que termine (listo); 4.39 (revisión): en el programa se sabe aquí mismo si sale comanda (imprimeProgWeb, sin red) */
    async cargarPanelWeb() {
      const pw = this.panelWeb; if (!pw) return;
      try { const l = await api('/api/pedidos'); if (this.panelWeb !== pw) return; pw.lista = Array.isArray(l) ? l : []; pw.error = ''; }
      catch (e) { if (this.panelWeb === pw) pw.error = 'No se pudieron leer los pedidos en línea: ' + (e && e.message ? e.message : 'sin conexión') + '. Se intenta otra vez en unos segundos.'; }
      finally { if (this.panelWeb === pw) pw.cargando = false; }
    },
    cuentaDePedidoWeb(p) { return (p && this.esperaCaja.find(v => v && +v.pedido_id === +p.id)) || null; },
    async aceptarWeb(p) {
      const pw = this.panelWeb; if (!pw || !this.enProgWeb || pw.aceptando[p.id]) return;
      pw.aceptando = { ...pw.aceptando, [p.id]: true };
      try {
        let r;
        try { r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); }
        catch (e) { toast(e.message, 'err'); return; }
        /* 4.39 (decimotercera vuelta): el pedido queda como ya avisado en cuanto se acepta, antes de recargar la ventana: si la consulta de pedidos llegaba */
        /* mientras tanto, su cuenta ya estaba en la caja y volvía a sonar «Entró a la caja…» */
        (this._entAvisados || (this._entAvisados = new Set())).add(+p.id);
        /* 4.39 (duodécima vuelta): si se sabe que no sale comanda («Aceptar pedido»), el aviso no dice que sale sola */
        toast(pw.imprime === false ? 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja.' : r && r.mensaje ? r.mensaje : 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.', 'ok');
        this.sincronizar();   /* 4.32: trae la cuenta del pedido a esta caja y la estación revisa su comanda (sin esperar; no lanza) */
        await this.cargarPanelWeb();
        return true;
      } finally { if (this.panelWeb === pw) { const a = { ...pw.aceptando }; delete a[p.id]; pw.aceptando = a; } }
    },
    abrirCuentaWeb(v) { this.panelWeb = null; this.recuperar(v); },
    horaWeb(p) { const t = String((p && p.creado) || ''); return t.length >= 16 ? t.slice(11, 16) : ''; },
    lineasWeb(p) { return ((p && p.lineas) || []).map(l => (+l.cantidad || 1) + ' × ' + (l.detalle || l.nombre || '')).join(', '); },
    // 4.39 (soporte de un restaurante, 16 nov 2026): todo el pedido en línea sin salir de la caja, en la página web y en el programa.
    // «Ver pedido» abre el resumen dentro de esta misma ventana, con «← Atrás» que vuelve a la lista (Escape también: primero cierra la
    // cancelación, después el resumen y al final la ventana). «Imprimir comanda» acepta el pedido y saca su comanda una sola vez: en la
    // página web con la lógica de Ventas en línea › Pedidos (./_aceptar_pedido.js, copia exacta de fis/pages/pedidos.js: ventana del
    // navegador abierta en el toque, reclamo por grupo, marca, soltar si falla, los mismos avisos); en el programa que atiende los pedidos,
    // como la 4.32 (aceptarWeb: la comanda la saca la estación de esta caja). Después la caja trae la cuenta del pedido («Para llevar en
    // espera») y la ventana lo muestra aceptado, con «Abrir para cobrar» cuando su cuenta llega. Cancelar pide la justificación (8+
    // caracteres, el cliente la ve), como Ventas en línea › Pedidos.
    verPedidoWeb(p) { const pw = this.panelWeb; if (!pw || !p) return; pw.cancelar = null; pw.ver = p.id; },
    atrasWeb() { const pw = this.panelWeb; if (!pw) return; if (pw.cancelar) pw.cancelar = null; else if (pw.ver) pw.ver = null; else this.panelWeb = null; },
    opcionesWeb(l) { return ((l && l.opciones) || []).map(o => (o && o.nombre) || '').filter(Boolean).join(', '); },
    /* 4.39: el nuevo que no atiende otra computadora; en la página web también el aceptado que quedó sin cuenta (como en Ventas en línea, «Aceptar» lo retoma) */
    puedeImprimirWeb(p) { return !!p && !(+p.atiende > 0) && (p.estado === 'nuevo' || (!this.enProgWeb && p.estado === 'confirmado' && !p.cuenta_espera_id && !p.documento_id && !this.cuentaDePedidoWeb(p))); },
    cargarAceptador() {
      if (!this._acepP) this._acepP = import('./_aceptar_pedido.js').then(M => { this._acep = M.crearAceptador({ api, toast, sesion: M.sesionDeCaja(sesion), recargar: () => this.trasAceptarWeb() }); return this._acep; }).catch(() => { this._acepP = null; return null; });
      return this._acepP;
    },
    async prepararWeb(pw) {
      const leer = (async () => {
        const a = await this.cargarAceptador(); if (!a || this.panelWeb !== pw) return;
        await a.preparar();
        if (this.panelWeb === pw) pw.imprime = !a.menu ? false : a.impresion ? a.conComanda : null;
      })().catch(() => { /* sin esto el botón dice «Imprimir comanda» y lo de imprimir se lee al tocarlo */ });
      /* 4.39 (revisión): «Imprimir comanda» espera a que esto termine (tocado antes, la ventana del navegador se abría después de esperar y el
         navegador podía bloquearla, o el pedido se aceptaba sin comanda); 6 s como mucho: después se puede tocar y lo que falte se lee al
         tocarlo, como en Ventas en línea › Pedidos */
      let tope = null;
      try { await Promise.race([leer, new Promise(r => { tope = setTimeout(r, 6000); })]); }
      finally { clearTimeout(tope); if (this.panelWeb === pw) pw.listo = true; }
    },
    /* 4.39 (revisión): en el programa, ¿sale la comanda del pedido que se acepta aquí? La saca la estación de comandas de esta computadora,
       con sus reglas (_comandas.js gruposDeCopia): alguna impresora de comanda activa y una caja que imprime comandas (en un negocio que no
       es restaurante, una caja en modo restaurante). Con lo guardado en esta computadora, sin red. false = se sabe que no sale (el botón
       dice «Aceptar pedido», como en Ventas en línea del programa); null = no se pudo saber. Nunca lanza */
    imprimeProgWeb() {
      try {
        if (!impresoras().some(i => i.activa !== false && (i.uso || 'comanda') === 'comanda')) return false;
        const ts = terminales(); if (!ts.length) return null;
        return ts.some(t => t && t.imprimir_comanda !== false && (sesion.tipo === 'restaurante' || t.modo === 'restaurante'));
      } catch { return null; }
    },
    async trasAceptarWeb() { if (!this._fuera) this.sincronizar(); await this.cargarPanelWeb(); },   /* 4.39: trae la cuenta del pedido a esta caja (sin esperar; no lanza) y lee otra vez la ventana */
    async imprimirComandaWeb(p) {
      const pw = this.panelWeb; if (!pw || !p || pw.aceptando[p.id] || pw.listo === false) return;   /* 4.39 (revisión): el botón dice «Preparando…» y no se puede tocar */
      const eraNuevo = p.estado === 'nuevo', o0 = this.online;   /* si mientras tanto llegó la consulta de pedidos (revisarOnline cambia `online`), esa ya lo cuenta */
      /* 4.39 (prueba de punta a punta): aceptado, el botón «Pedidos web» deja de contarlo ya (seguía rojo hasta la próxima consulta, 30 s) y, si se aceptó desde «Ver pedido», */
      /* la ventana vuelve a la lista también en el programa, como en la página web */
      /* 4.39 (undécima vuelta): en el programa, el pedido aceptado aquí queda como ya avisado: cuando su cuenta entra a la caja no vuelve a sonar ni a contarse */
      /* 4.39 (duodécima vuelta): si la consulta de pedidos llegó mientras se aceptaba, contaba todavía este pedido: se vuelve a leer (no se espera) */
      if (this.enProgWeb) { const ok = await this.aceptarWeb(p); if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id); if (ok && eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); } if (ok && this.panelWeb === pw && +pw.ver === +p.id) pw.ver = null; return; }
      pw.aceptando = { ...pw.aceptando, [p.id]: true };
      try {
        const a = this._acep || await this.cargarAceptador();   /* ya cargado (al abrir la ventana): sin esperar, la ventana del navegador se abre en el toque */
        if (!a) return toast('No se pudo preparar la impresión de la comanda. Revise la conexión e intente otra vez.', 'err');
        const ok = await a.aceptarComo(p, null);
        if (ok && eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); }
        if (ok && this.panelWeb === pw && +pw.ver === +p.id) pw.ver = null;
      } finally { if (this.panelWeb === pw) { const x = { ...pw.aceptando }; delete x[p.id]; pw.aceptando = x; } }
    },
    abrirCancelarWeb() { const pw = this.panelWeb; if (pw && pw.ver) pw.cancelar = { motivo: '', enviando: false }; },
    async cancelarWeb(p) {
      const pw = this.panelWeb, c = pw && pw.cancelar; if (!c || !p || c.enviando) return;
      const motivo = String(c.motivo || '').trim();
      if (motivo.length < 8) return toast('Escriba la justificación (al menos 8 caracteres): el cliente la ve.', 'err');
      c.enviando = true;
      const cuentaAntes = p.cuenta_espera_id || null, eraNuevo = p.estado === 'nuevo', o0 = this.online;
      try {
        const r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'cancelado', motivo } });
        if (r && typeof r === 'object') Object.assign(p, r);
        toast(this.enProgWeb && r && r.mensaje ? r.mensaje : 'Pedido #' + p.numero + ' cancelado. El cliente ve el motivo.', 'ok');
        if (this.panelWeb === pw) { pw.cancelar = null; pw.ver = null; }
        this.soltarCuentaCanceladaWeb(p, cuentaAntes);
        /* 4.39 (duodécima vuelta): si la consulta de pedidos llegó mientras se cancelaba, se vuelve a leer */
        if (eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); }   /* 4.39 (prueba de punta a punta): el botón «Pedidos web» deja de contarlo ya */
        if (!this._fuera) this.sincronizar();
        await this.cargarPanelWeb();
      } catch (e) { toast(e && e.message ? e.message : 'No se pudo cancelar el pedido.', 'err'); }
      finally { c.enviando = false; }
    },
    /* 4.39 (revisión): el servidor quita de la caja las cuentas del pedido cancelado. Si la que está en pantalla es una de ellas (se abrió
       con «Abrir para cobrar») y no hay un cobro en curso, se cierra aquí mismo, como una cuenta cerrada: sin el aviso de «cobrada o cerrada
       en otro equipo» (fue esta caja) y sin esperar a la próxima vuelta (no queda para cobrar un pedido que el cliente ya ve cancelado). Lo
       que no se había enviado a cocina sigue en pantalla como cuenta nueva, como cuando la cierra otro equipo. No toca el cobro */
    soltarCuentaCanceladaWeb(p, cuentaAntes) {
      const id = this.esperaId, es = x => x !== null && x !== undefined && x !== '' && String(x) === String(id);
      if (!id || !p || this.pago || this.cobrando || this.cobroParcial) return false;
      if (!(es(cuentaAntes) || es(p.cuenta_espera_id) || (this.esperaCaja || []).some(v => v && es(v.id) && +v.pedido_id === +p.id))) return false;
      const g = lidsDeBase(this._base, id), resto = (this.lineas || []).filter(l => l && !l.enviado && !g.has(l.lid));   /* 4.39 (tercera vuelta): lo guardado en la cuenta del pedido (el envío a domicilio) se va con el pedido */
      if (resto.length) { this.lineas = resto; this.esperaId = null; this.nombreEspera = ''; if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true; toast('Lo que no se había enviado a cocina sigue en pantalla como una cuenta nueva.', 'ok'); }
      else if (this.esRestaurante) this.volverAMesas(true);
      else { this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.idem = uuid(); }
      return true;
    },
    recuperar(v) {
      if (this.lineas.length && !confirm('El carrito actual se reemplaza por «' + v.nombre + '». ¿Continuar?')) return;
      if (v.terminal_id && this.cfg && v.terminal_id !== this.cfg.id) return toast('Esa cuenta pertenece a otra caja', 'err');
      if (this.esperaId && this.esperaId !== v.id && !this.lineas.length) this.descartarVacia();
      this.cargarCuenta(v); this.mesaActual = v.mesa_id ? this.mesas.find(m => m.id === v.mesa_id) || null : null; this.modalEspera = false; this.vista = 'venta'; this.idem = uuid();
    },
    async borrarEspera(v) { if (!confirm('¿Eliminar «' + v.nombre + '» de las cuentas en espera?')) return; if (this.cfg.clave_anular && (v.lineas || []).some(l => l.enviado) && !(await this.autorizar('Eliminar la cuenta ' + v.nombre + ' con platos ya enviados'))) return; this.bajaCuenta(v.id, v.lineas || [], v.nombre); if (this.esperaId === v.id) this.esperaId = null; },   /* 4.31: con la condición de los platos que se veían */
    // ---- cobro ----
    async abrirPago() {
      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (tercera vuelta): no se abre debajo de la ventana de la habitación (quinta vuelta: la parte vuelve a la cuenta) */
      if (!this.lineas.length) return toast('Agregue productos al carrito', 'err');
      if (this.cfg.pedir_apertura && !this.caja) { toast('Abra la caja antes de cobrar', 'err'); return this.abrirApertura(); }
      if (!(await this.cobroPermitido('cobrar'))) { if (this.cobroParcial) this.cerrarPago(); return; }   // 4.6
      if (this.esperaId && !this.cobroParcial) { await this.alDiaParaCobrar(); if (this.pago) return; if (!this.lineas.length) return toast('Agregue productos al carrito', 'err'); }   /* 4.31: se cobra la cuenta como está ahora (1,5 s como mucho) */
      // 4.9: pedido en línea a crédito con cliente: el cobro abre con «📒 Fiado» por el resto (antes salía efectivo y el cajero tenía que acordarse);
      // la ficha del cliente se trae fresca para revisar el límite al día (si no estaba cargada, se espera)
      const cc = this.cuentaCobro, fiar = !!(cc && cc.credito && this.clienteId);
      if (fiar) { const fresca = api('/api/clientes/' + this.clienteId).then(c => { if (c) store.poner('clientes', c); }).catch(() => {}); if (!this.cliente) await fresca; }
      const td = this.cfg.tipo_documento === '01' && !(this.clienteId && this.cliente && this.cliente.numero_id) ? '04' : this.cfg.tipo_documento;   /* sin identificación: tiquete (3.33) */
      if (this.habCargo || this.dividir) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió la ventana de la habitación. Sexta vuelta: o «Dividir» */
      const c0 = this.cuentaActual; this.prepago = c0 && c0.prepago && +c0.prepago.monto > 0 ? { ...c0.prepago } : null;   // pedido en línea ya pagado (parcial o total) con tarjeta de regalo (3.49)
      this.pago = { tipo_documento: td, medios: [{ medio: fiar ? 'fiado' : '01', monto: r2(Math.max(0, this.totales.total - (this.prepago ? +this.prepago.monto : 0))) }], recibido: null, propina: 0, moneda: 'CRC', recibido_usd: null, tc: +monedas.tc('USD') || 0, debe: null };   // 4.9: debe = saldo pendiente del cliente (solo para el aviso del pedido a crédito)
      if (fiar) { const pg = this.pago; this.saldoFiado(this.clienteId).then(ds => { if (this.pago === pg) pg.debe = r2(ds.reduce((s, d) => s + (+d.saldo || 0), 0)); }).catch(() => {}); }
      this.$nextTick(() => { const el = this.$refs.recibido; if (el) { el.focus(); el.select(); } });
    },
    textoVentas(n) { return (+n || 0) + ((+n || 0) === 1 ? ' venta' : ' ventas'); },   /* 4.29 (K-9): «1 venta», «0 ventas», «3 ventas» */
    // cerrar el cobro sin cobrar: si era una parte de la cuenta de la mesa, los platos vuelven a la cuenta (3.46)
    cerrarPago() {
      if (this.cobrando) return;
      if (this.cobroParcial) return this.cerrarParte(this.cobroParcial);   /* 4.31 (quinta vuelta): la parte vuelve a la cuenta después de preguntar al servidor qué se cobró (devolverParte) */
      this.pago = null;
    },
    fijarMedio(codigo) { this.pago.medios = [{ medio: codigo, monto: r2(Math.max(0, this.totalCobro - (this.prepago ? +this.prepago.monto || 0 : 0))) }];   /* 4.9: menos lo ya pagado en línea (antes «📒 Fiado» o Tarjeta cobraban otra vez el prepago) */ if (codigo !== '01') { this.pago.recibido = null; this.pago.moneda = 'CRC'; } },
    monedaCobro(m) { this.pago.moneda = m; this.pago.recibido = null; this.pago.recibido_usd = null; this.pago.medios = [{ medio: '01', monto: this.porCobrar }]; if (m === 'USD' && !(+this.pago.tc > 0)) toast('No hay tipo de cambio: actualícelo en Configuración › Monedas', 'err'); },   // 4.9: porCobrar (sin el prepago)
    propinaCambio() { if (this.pago.medios.length === 1) { if (this.pago.medios[0].medio === '01' && this.pago.recibido !== null && this.pago.recibido !== '') this.recibidoCambio(); else this.pago.medios[0].monto = this.porCobrar; } },   // 4.9: porCobrar: con prepago, la propina ya no deja el fiado o la tarjeta por encima de lo que falta
    propinaPct(p) { this.pago.propina = Math.round(this.totales.total * p / 100); this.propinaCambio(); },
    agregarMedio() { const falta = this.pagoTot ? this.pagoTot.falta : 0; this.pago.medios.push({ medio: '02', monto: falta }); },
    // pantalla del cliente (3.21): la caja difunde su carrito a la pestaña «Pantalla del cliente» abierta en el segundo monitor
    difundir(extra) { try { if (!this._canal) this._canal = new BroadcastChannel('gf-pos-' + (sesion.empresa_id || 0)); this._canal.postMessage({ caja: this.cfg ? this.cfg.nombre : '', lineas: this.lineas.map(l => ({ detalle: l.detalle, cantidad: +l.cantidad, total: this.totalLinea ? this.totalLinea(l) : r2((+l.cantidad || 0) * (+l.precio_unitario || 0) * (1 + (+l.tarifa || 0) / 100)) })), totales: this.totales, cliente: this.cliente ? this.cliente.nombre : '', ...(extra || {}) }); } catch {} },
    recibidoCambio() { const m = this.pago.medios.find(x => x.medio === '01'); if (m && this.pago.recibido !== null && this.pago.recibido !== '') m.monto = r2(+this.pago.recibido || 0); },
    montoRapido(v) { this.pago.recibido = v === 'exacto' ? this.porCobrar : v; this.recibidoCambio(); },   // 4.9: «Exacto» = lo que falta cobrar (antes, con prepago, mostraba un vuelto que no era)
    cuentaPara(medio) { const c = (this.cfg.cuentas || {})[medio]; if (c) return c; const tipo = medio === '01' ? 'Efectivo' : 'Banco'; const b = this.cuentas.find(x => x.tipo === tipo && (x.moneda || 'CRC') === 'CRC') || cuentaPrincipal('CRC', medio === '01' ? this.cuentas : this.cuentas.filter(x => x.tipo !== 'Efectivo')); return b ? b.nombre : ''; },   // 3.87: tarjeta, SINPE y transferencia no caen en la caja de efectivo (sin cuenta bancaria: «sin cuenta» y el aviso)
    // 3.87: la caja de una sucursal emite con esa sucursal aunque la sesión esté en «Todas» (antes salía con 001 y rebajaba la bodega de la sucursal de la caja)
    cabSucursal() { const sid = !sesion.sucursal_id && this.cfg && this.cfg.sucursal_id; return sid && (sesion.sucursales || []).some(x => x.id === sid) ? { 'X-Sucursal': String(sid) } : {}; },
    // 4.29 (K-2, K-3, K-6): F9, Enter y el botón principal cobran como siempre (cobrar); F10 y el segundo botón, con la impresión al revés
    // solo para esta venta (cobrarOtro). Las dos formas pasan por la misma puerta: mientras un cobro está en curso (también en lo que se
    // espera ANTES de marcar «cobrando», como revisar el turno de la caja) otro F9, F10, Enter o clic no hace nada. La elección viaja como
    // argumento de esta venta: no queda guardada para la siguiente.
    async cobrar() { return this.cobrarVenta(false); },
    cobrarOtro() { return this.cobrarVenta(true); },
    async cobrarVenta(otra) {
      if (this.cobrando || this._cobroEnCurso) return;
      this._cobroEnCurso = true;
      try { return await this.emitirCobro(otra === true); } finally { this._cobroEnCurso = false; }
    },
    async emitirCobro(otra) {
      if (this.cobrando) return;
      if (this._habEnCurso) return toast('Se está revisando el cargo a la habitación: espere un momento', 'err');   /* 4.39 (revisión de los arreglos): mientras «Cargar a la habitación» pide su cobro, F9 no cobra lo mismo en la caja. Cuarta vuelta: con aviso */
      const pt = this.pagoTot; if (!pt || !pt.ok) return toast(pt && pt.falta > 0 ? 'Falta cubrir ' + money(pt.falta) : 'Revise los montos del cobro', 'err');
      if (this.pago.tipo_documento === '01' && !this.clienteId) return toast('La factura electrónica requiere cliente; elija uno o emita tiquete', 'err');
      if (!mock.puedeGuardar()) return;
      const pagoAbierto = this.pago;
      if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }   // 4.6: por si la caja cambió de turno con el cobro abierto (la parte vuelve a la cuenta)
      if (this.pago !== pagoAbierto || this.cobrando) return;   /* 4.39 (quinta vuelta): se cerró el cobro mientras se esperaba (antes quedaba «cobrando» y la caja trabada hasta recargar). Sexta vuelta: o se está cerrando (la parte vuelve a la cuenta) o es otro cobro */
      if (this.cfg.pedir_apertura && !this.caja) { this.cerrarPago(); toast('Abra la caja antes de cobrar', 'err'); return this.abrirApertura(); }   // 4.6: la caja pudo cerrarse en otro equipo con el cobro abierto
      // 4.9: pedido en línea hecho A CRÉDITO: se pregunta antes de cobrarlo de contado (sin fiado) o a nombre de otro cliente (no quedaría en el estado de cuenta de la revendedora)
      const cc = this.cuentaCobro;
      if (cc && cc.credito) {
        const rev = ((store.clientes || []).find(c => c.id === cc.cliente_id) || {}).nombre || 'la revendedora', num = cc.pedido_numero ? ' #' + cc.pedido_numero : '';
        if (cc.cliente_id && +this.clienteId !== +cc.cliente_id && !confirm('El pedido' + num + ' es a crédito de ' + rev + ', pero el cobro ' + (this.clienteId ? 'está a nombre de otro cliente' : 'no tiene cliente') + ': no quedará en el estado de cuenta de ' + rev + '.\n\n¿Continuar de todos modos?')) return;
        const contado = this.pago.medios.filter(m => +m.monto > 0 && m.medio !== 'fiado');
        if (contado.length && !this.pago.medios.some(m => m.medio === 'fiado' && +m.monto > 0) && !confirm('El pedido' + num + ' de ' + rev + ' se hizo A CRÉDITO: lo normal es cerrarlo como «📒 Fiado» para que quede en su estado de cuenta.\n\n¿Cobrarlo de contado (' + contado.map(m => nombreMedio(m.medio)).join(' + ') + ') de todos modos?')) return;
      }
      this.cobrando = true;
      const imprime = formaCobro(this.cfg, otra).imprime;   /* 4.29 (K-3, K-4): solo decide si el comprobante de ESTA venta se abre o imprime solo */
      // todo lo del modal se toma ANTES de esperar al servidor (si el cajero cierra el modal a medias, el cobro termina igual)
      const tipoDoc = this.pago.tipo_documento, recibido0 = this.enDolares ? null : (this.pago.recibido !== null && this.pago.recibido !== '' ? r2(this.pago.recibido) : null);
      // pago en dólares (3.20): entran dólares a la caja en dólares y el vuelto sale de la gaveta en colones; el comprobante y su cobro siguen en colones
      const usd = this.enDolares ? { monto_usd: this.pagoTot.usd, tc: +this.pago.tc, cuenta_usd: this.cuentaUsd, cuenta_crc: this.cuentaPara('01') } : null;
      const clienteId = this.clienteId, cliente = this.cliente, esperaId = this.esperaId, nombreEspera = this.nombreEspera, cajaId = this.caja ? this.caja.id : null, mesa = this.mesaActual, rapida = this.esVentaRapida || (this.esRestaurante && !this.mesaActual && !(cc && (cc.mesa_id || (Array.isArray(cc.mesas_ids) && cc.mesas_ids.length))));   /* 4.39 (prueba de punta a punta): lo que no es de una mesa (venta rápida, cuenta guardada sin mesa, pedido para llevar o en línea) sigue «Al entrar a esta caja»; lo de una mesa vuelve al plano como antes */
      lidsPantalla(this.lineas, esperaId ? (this.espera || []).find(x => x.id === esperaId) : null); const lineasCobradas = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad }));   /* 4.31: lo que este cobro cierra de la cuenta */
      const lineasBaja = esperaId ? this.cierreCobro(esperaId, lineasCobradas) : lineasCobradas;   /* 4.31 (sexta vuelta): y lo que esta pantalla quitó o bajó sin guardar (no queda en la mesa) */
      const reclamar = !!this.cuentaDelCobro().id;   /* 4.31: una cuenta guardada (no la venta rápida ni la de mostrador sin guardar); la parte, con la cuenta de la que salió */
      const salonero = this.salonero || null, propina = this.cfg.propina !== false ? r2(Math.max(0, +this.pago.propina || 0)) : 0;   // propina voluntaria (3.7): no va en el comprobante
      // 4.9: lo ya pagado en línea (prepago del pedido: tarjeta de regalo, tarjeta o SINPE), tomado antes de esperar al servidor: no entra a la
      // gaveta (antes el efectivo se registraba por el total y el cierre esperaba de más) y se aplica al comprobante sin cuenta (más abajo)
      const prepagoV = this.prepago && +this.prepago.monto > 0 ? { ...this.prepago } : null, pre = prepagoV ? r2(Math.min(+prepagoV.monto, this.totales.total)) : 0;
      // 4.9: cobro que deja parte del pedido en la caja (cobro por partes con platos pendientes, o partes / cuentas «aparte» con el mismo
      // pedido_id): el servidor lo enlaza sin darlo por entregado ni sacarlo de «en pedidos» hasta el cobro que lo cierra
      const pedidoParcial = !!(cc && cc.pedido_id && ((this.cobroParcial && (cc.lineas || []).length) || this.espera.some(x => x && x.id !== cc.id && x.pedido_id && +x.pedido_id === +cc.pedido_id)));
      let total = this.totales.total, medios = this.pago.medios.filter(m => +m.monto > 0).map(m => ({ medio: m.medio, monto: r2(m.monto) }));
      // el efectivo se registra por lo que cubre, no por lo recibido (el vuelto sale de la caja); un efectivo que queda en cero se descarta
      const efectivoIdx = medios.findIndex(m => m.medio === '01'); if (efectivoIdx >= 0) { const otros = medios.filter((m, i) => i !== efectivoIdx).reduce((s, m) => s + m.monto, 0); medios[efectivoIdx].monto = r2(Math.max(0, total - pre + propina - otros)); }   // 4.9: menos el prepago
      medios = medios.filter(m => m.monto > 0);
      const regalos = medios.filter(m => m.medio === 'regalo');   // tarjetas de regalo (3.49): ya pagadas al comprarlas; no entran a Bancos y se descuentan de la tarjeta al cobrar
      const principal = medios.filter(m => m.medio !== 'fiado' && m.medio !== 'regalo').slice().sort((a, b) => b.monto - a.monto)[0] || { medio: this.prepago && this.prepago.online && !this.prepago.regalo && !regalos.length ? (this.prepago.medio || '02') : regalos.length || this.prepago ? '99' : '01' };   // pagado en línea con tarjeta (3.50): medio tarjeta; 4.9: o SINPE (el medio del prepago, antes '02' fijo)
      // fiado (3.23): la parte fiada deja el comprobante a crédito al cliente, dentro de su límite; no entra a Bancos
      const fiado = medios.find(m => m.medio === 'fiado'); let plazoFiado = 30;
      if (fiado) {
        if (!clienteId || !cliente) { this.cobrando = false; return toast('El fiado requiere elegir el cliente', 'err'); }
        plazoFiado = +cliente.termino_pago_dias || 30;
        const lim = +cliente.limite_credito || 0;
        if (lim <= 0) { this.cobrando = false; return toast(cliente.nombre + ' no tiene límite de crédito: defínalo en Contactos', 'err'); }
        try { const debe = r2((await this.saldoFiado(clienteId)).reduce((s, d) => s + d.saldo, 0)); if (debe + fiado.monto > lim + 0.005) { this.cobrando = false; return toast('Supera el límite de crédito de ' + cliente.nombre + ': debe ' + money(debe) + ' y el límite es ' + money(lim) + (cc && cc.credito ? '. Pida a un administrador que suba el límite en Contactos o cobre el pedido completo de contado' : ''), 'err'); } }
        catch (e) { this.cobrando = false; return toast('No se pudo revisar el crédito del cliente: ' + e.message, 'err'); }
      }
      // 4.5: un descuento por encima del máximo de la caja (promoción, cupón o puntos, que la pantalla no limita) lo autoriza un supervisor:
      // el servidor se lo exige a quien solo opera la caja (auth.solo_pos)
      const maxDesc = Math.min(100, +this.cfg.descuento_max_pct || 100), soloCaja = !sesion.esAdmin && (sesion.permisos || []).every(p => p === 'ver' || p === 'pos');
      const pasada = soloCaja && maxDesc < 100 && !this.autorizado ? this.lineas.find(l => this.descuentoDe(l) > (+l.cantidad || 0) * (+l.precio_unitario || 0) * maxDesc / 100 + 0.005) : null;
      if (pasada && !(await this.autorizar('Descuento mayor al ' + maxDesc + ' % en ' + pasada.detalle))) { this.cobrando = false; return; }
      // 4.29: en la venta rápida de una caja de restaurante los platos sin enviar salen a cocina al cobrar, con la comanda de siempre y una sola
      // vez (quedan marcados como enviados aunque el cobro falle). Va DESPUÉS de las revisiones que pueden rechazar el cobro (fiado, crédito,
      // clave de supervisor): un cobro rechazado no manda comanda, no gasta número ni deja cuenta guardada. Solo si algún plato va a una
      // impresora o estación (sin nada para cocina el cobro sigue tan rápido como antes). Se espera a que la cuenta quede guardada (3 s como
      // mucho): así el cobro la cierra con su id definitivo. Mesas, para llevar, domicilio y las cajas de mostrador siguen igual.
      /* 4.39 (prueba de punta a punta): también la cuenta guardada sin mesa que no es pedido (cuentaRapidaGuardada): antes sus platos se cobraban y nunca llegaban a cocina */
      /* 4.39 (cuarta vuelta): si hace menos de 4 s esta pantalla juntó platos de esta cuenta que otro equipo acaba de mandar a cocina («Comanda»), allá se */
      /* está revisando esa comanda (3 s como mucho) y sale si la cuenta sigue abierta: se espera lo que falta antes de cobrar. Si no, este cobro podía */
      /* cerrar la cuenta primero y la comanda no salía de ningún equipo (también en una mesa) */
      const esperoMarca = esperaId !== null && esperaId !== undefined && !!(this._marcaAjena && this._marcaAjena.id === esperaId && Date.now() < this._marcaAjena.t + 4000);   /* 4.39 (séptima vuelta): si aquí se espera la comanda de otro equipo, después se junta lo que guardó (abajo) */
      { const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }
      let rc = null, rcPedido = false;   /* 4.39 (revisión de los arreglos): el cobro pedido al servidor (rc) y si ya se pidió antes de la comanda */
      if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) {
        /* 4.39: esta caja ya sabe que otro equipo cobró o cerró la cuenta (no está en la lista): ni comanda ni cobro. Guardarla la rehacía */
        /* con lo enviado hace menos de 20 s (regla de la 4.6) y, al tocar otra vez, ese plato se cobraba dos veces */
        /* (si la cuenta ya cambió de id mientras se esperaba el crédito o la clave, no se sabe por qué: lo decide cobroCambiado, sin cobrar) */
        const mismoId = esperaId !== null && esperaId !== undefined && this.esperaId === esperaId;
        if (mismoId && !enEspera().some(v => v.id === esperaId)) return this.cobroDeCuentaCerrada();
        const alta0 = mismoId && !this.yaGuardada(esperaId);   /* 4.39: el servidor todavía no tenía la cuenta: si al subirla le da otro id, es la misma (nadie más pudo cobrarla) */
        /* 4.39 (revisión de los arreglos): una cuenta que ya estaba en el servidor (otro equipo pudo abrirla desde «Para llevar en espera») pide */
        /* su cobro ANTES de mandar la comanda: si dos equipos la cobran a la vez, la comanda sale solo del que ganó el cobro (antes salía de los dos) */
        if (reclamar && mismoId && !alta0) {
          const sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));   /* 4.39 (tercera vuelta): lo que aquí está sin enviar (ver abajo) */
          rcPedido = true; try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc);
          /* 4.39 (revisión de los arreglos): antes de imprimir se trae y se junta lo que otro equipo guardó (con la ventana de cobro abierta no entra a la */
          /* pantalla): si la cuenta ya no está o cambió (un plato quitado o agregado), no sale comanda ni se cobra, y el cobro pedido queda libre */
          /* 4.39 (tercera vuelta): si un plato que aquí estaba sin enviar llegó enviado (otro equipo tocó «Comanda»), allá se está revisando su comanda (3 s */
          /* como mucho) y sale si la cuenta sigue abierta: se espera a que termine y se junta otra vez. Antes, si este cobro cerraba primero, no salía de ninguno */
          for (let vuelta = 0; ; vuelta++) {
            try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }
            if (!enEspera().some(v => v.id === esperaId)) { if (rc && rc.clave) this.soltarCobro(rc, false); return this.cobroDeCuentaCerrada(); }
            try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }
            if (vuelta > 1 || (vuelta ? !(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000) : !this.lineas.some(l => l.enviado && sin0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)))) break;   /* 4.39 (séptima vuelta): otra vuelta solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó) */
            { const ma = this._marcaAjena, falta = ma && ma.id === this.esperaId ? ma.t + 4000 - Date.now() : 4000; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }   /* 4.39 (sexta vuelta): solo lo que falta (la marca que dejó persistirCuenta al juntar) */
          }
          const cambio0 = this.cobroCambiado(esperaId, lineasCobradas, total, alta0); if (cambio0) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio0; }
        }
        try { if (this.lineas.some(l => !l.enviado && +l.cantidad > 0)) this.enviarComanda(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* la comanda no detiene el cobro */ }   /* 4.39 (tercera vuelta): si al juntar ya no queda nada sin enviar, sin el aviso «No hay platos nuevos» */
        const cambio = this.cobroCambiado(esperaId, lineasCobradas, total, alta0); if (cambio) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio; }   /* 4.39: al guardarla, la cuenta cambió en otro equipo: no se emite (y el cobro pedido queda libre) */
      }
      /* 4.31 (la misma mesa): el cobro de una cuenta guardada se pide al servidor antes de emitir. Si otro equipo la está cobrando, o ya */
      /* cobró estos platos, este no emite y la caja se pone al día. Sin conexión, sin la ruta en el servidor o sin cuenta: como siempre */
      if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc); }
      /* 4.39 (quinta vuelta): en una mesa con platos sin enviar, con el cobro ya pedido, se mira la cuenta en el servidor: si otro equipo acaba de mandar */
      /* alguno a cocina («Comanda», con la ventana de cobro ya abierta aquí), se espera a que su comanda salga antes de cerrar la cuenta */
      if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial && esperaId !== null && esperaId !== undefined && this.esperaId === esperaId) {
        /* 4.39 (séptima vuelta): también si arriba se esperó la comanda de otro equipo (esperoMarca): después de esperar se junta lo que ese equipo guardó */
        /* (también la cuenta guardada sin platos por enviar). Y si al juntar llegó una comanda más nueva suya (la marca se renovó), se espera y se junta otra vez */
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)); let junta = esperoMarca;
        if (sin1.size) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ }
          const c1 = enEspera().find(v => v.id === esperaId), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)) : [];
          /* 4.39 (sexta vuelta): se espera solo lo que falta (la marca, con la hora de esa comanda) y después se junta lo que otro equipo guardó, como en la */
          /* venta rápida: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se cobra nada y el cobro pedido queda libre */
          if (ls.length) { const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === esperaId && m1.env >= te)) this._marcaAjena = { id: esperaId, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te }; junta = true; }
        }
        for (let k = 0; junta && k < 2; k++) {
          { const m2 = this._marcaAjena, falta = m2 && m2.id === esperaId ? m2.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }
          try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }
          if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }
          try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }
          const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }
          junta = !!(this._marcaAjena && this._marcaAjena.id === esperaId && Date.now() < this._marcaAjena.t + 4000);
        }
      }
      let doc = null, body = null;
      try {
        body = { exoneracion_id: this.exoAplica ? this.exoSel.id : null, tipo_documento: tipoDoc, cliente_id: clienteId || null, condicion_venta: fiado ? '02' : '01', plazo_credito: fiado ? plazoFiado : null, medio_pago: principal.medio, moneda: 'CRC', tipo_cambio: 1, bodega_id: this.cfg.bodega_id || null, vendedor: this.cfg.vendedor || sesion.usuario?.nombre || null,
          lineas: this.lineas.map(l => ({ producto_id: l.producto_id, detalle: (l.detalle + (l.nota ? ' (' + l.nota + ')' : '')).slice(0, 200), cabys: l.cabys, cantidad: +l.cantidad, precio_unitario: +l.precio_unitario, descuento: r2(this.descuentoDe(l)), codigo_tarifa: l.codigo_tarifa, tarifa: l.tarifa, es_servicio: l.es_servicio, unidad_medida: l.unidad_medida })),
          observaciones: [cc && cc.pedido_numero ? 'Pedido en línea #' + cc.pedido_numero : '', this.nota, 'Punto de venta ' + this.cfg.nombre + (nombreEspera ? ' · ' + nombreEspera : '')].filter(Boolean).join('. ').slice(0, 500), idempotencia: this.idem,   // 4.9: el número del pedido va primero (un recorte no lo borra)
          pedido_id: cc && cc.pedido_id ? +cc.pedido_id : null,   // 4.9: enlaza el pedido en línea con su comprobante (también en el cobro por partes: el servidor se queda con el primero)
          pedido_parcial: pedidoParcial,   // 4.9: queda parte del pedido en la caja: no se da por entregado ni deja de contar en el crédito
          // 4.9: el medio 99 «Otros» exige su descripción (Hacienda, 3 a 100 caracteres): sin ella no se emitía el fiado de un pedido a crédito
          // pagado en parte con tarjeta de regalo, ni la venta pagada toda con tarjeta de regalo
          medio_pago_otros: principal.medio === '99' ? (regalos.length || (prepagoV && prepagoV.regalo) ? 'Tarjeta de regalo' : 'Otro medio (punto de venta)') : null,
          pos_terminal_id: this.cfg.id, pos_autorizacion: this.autorizado || null,   // 4.5: la caja y la autorización de supervisor que revisa el servidor
          otros_cargos: this.totales.servicio > 0 ? [{ tipo: '06', detalle: this.cfg.servicio_detalle || 'Impuesto de servicio 10 %', porcentaje: this.servicioPct }] : [] };
        doc = await api('/api/comprobantes', { method: 'POST', headers: this.cabSucursal(), body });
      } catch (e) {
        /* 4.31: no se emitió: el cobro de la cuenta queda libre. 4.31 (quinta vuelta): sin conexión no se sabe si el servidor emitió (la */
        /* respuesta pudo perderse): no se suelta (vence solo) y, si la venta queda en la cola, al emitirse ahí se anotan sus platos como cobrados */
        if (rc && rc.clave && !e.sinConexion) this.soltarCobro(rc, false);
        // sin conexión (3.55): la venta de contado se guarda en este navegador y se emite sola al volver la red
        if (e.sinConexion && body) {
          this._reclamoSinRed = rc && rc.clave ? { id: rc.id, clave: rc.clave, lids: lineasCobradas.map(l => l.lid).filter(x => typeof x === 'string' && x).slice(0, 300) } : null;   /* 4.31 (quinta vuelta): el cobro pedido viaja con la venta (ventaSinConexion) */
          return this.ventaSinConexion({ body, tipoDoc, total, medios, propina, principal, usd, recibido0, pt, clienteId, cliente, esperaId: this.esperaId || esperaId, nombreEspera, cajaId, salonero, imprime, fiado, regalos, rapida });
        }
        // la clave de idempotencia se conserva: si la red se cortó después de emitir, el reintento devuelve el mismo tiquete (R93)
        this.cobrando = false; return toast('No se emitió: ' + e.message, 'err');
      }
      if (rc && rc.clave) this.soltarCobro(rc, true, lineasCobradas, true);   /* 4.31: ya se emitió: esos platos quedan como cobrados y el cobro sigue pedido hasta terminar */
      const avisos = [];
      try {
        // el total que manda es el del servidor (calcula a 5 decimales): la diferencia de centavos va al medio mayor
        const totalSrv = r2(doc.total || total);
        if (Math.abs(totalSrv - total) > 0.001 && medios.length) { const mayor = medios.slice().sort((a, b) => b.monto - a.monto)[0]; mayor.monto = r2(mayor.monto + totalSrv - total); medios = medios.filter(m => m.monto > 0); }
        total = totalSrv;
        const vuelto = usd ? r2(Math.max(0, usd.monto_usd * usd.tc - (total - pre) - propina)) : (recibido0 !== null && medios.length === 1 && medios[0].medio === '01' ? r2(Math.max(0, recibido0 - (total - pre) - propina)) : pt.vuelto);   // 4.9: sobre lo que faltaba (sin el prepago)
        if (usd) usd.vuelto_crc = vuelto;
        // la propina se descuenta del medio principal: el cobro de la factura se registra sin ella
        const regalosOk = [];   // 4.9: lo que de verdad se descontó de cada tarjeta (para aplicarlo a un fiado)
        for (const g of regalos) { try { const rg = await api('/api/tarjetas/' + encodeURIComponent(g.codigo) + '/canjear', { method: 'POST', body: { monto: g.monto, referencia: 'doc:' + doc.consecutivo } }); regalosOk.push({ codigo: g.codigo, monto: r2(rg && rg.aplicado !== undefined && rg.aplicado !== null ? +rg.aplicado || 0 : g.monto) }); } catch (e) { avisos.push('La tarjeta ' + g.codigo + ' no se descontó: ' + e.message); } }
        if (this.cupon) { try { await api('/api/cupones/usar', { method: 'POST', body: { codigo: this.cupon.codigo, subtotal: this.cupon.base, referencia: 'doc:' + doc.consecutivo, cliente_id: clienteId || null, telefono: cliente ? String(cliente.celular || cliente.telefono || '') || null : null } }); } catch (e) { avisos.push('El cupón no quedó registrado: ' + e.message); } }
        const qp = this.quienPuntos(), cuentaOnline = cc && cc.canal === 'online' ? cc : null;   // 4.9: la cuenta que se cobra, también por partes (antes se perdía con esperaId en null)
        // 4.9: «pedido:N» acredita una sola vez (idempotente): en un cobro por partes se acredita con el último cobro de la cuenta y por lo de todos sus cobros
        const cpP = this.cobroParcial, previosPedido = cuentaOnline && cuentaOnline.telefono ? (!cpP || (cpP.de && cpP.parte >= cpP.de) ? r2((cuentaOnline.cobros || []).reduce((s, x) => s + (+x.monto || 0), 0)) : null) : 0;
        if (this.puntos && this.puntos.canje && qp) { try { await api('/api/fidelizacion/canjear', { method: 'POST', body: { ...qp, puntos: this.puntos.aplicados, monto: this.puntos.descuento * 100, referencia: 'doc:' + doc.consecutivo, nombre: cliente ? cliente.nombre : '' } }); } catch (e) { avisos.push('El canje de puntos no quedó registrado: ' + e.message); } }
        if ((qp || (cuentaOnline && cuentaOnline.telefono)) && previosPedido !== null) { try { await api('/api/fidelizacion/acreditar', { method: 'POST', body: cuentaOnline && cuentaOnline.telefono ? { telefono: cuentaOnline.telefono, monto: r2(total - this.totales.servicio + previosPedido), referencia: 'pedido:' + cuentaOnline.pedido_id, nombre: cuentaOnline.nombre } : { ...qp, monto: r2(total - this.totales.servicio), referencia: 'doc:' + doc.consecutivo, nombre: cliente ? cliente.nombre : '' } }); } catch {} }
        let mediosFactura = medios.filter(m => m.medio !== 'fiado' && m.medio !== 'regalo').map(m => ({ ...m })); let resta = propina;
        for (const m of mediosFactura.slice().sort((a, b) => b.monto - a.monto)) { if (resta <= 0) break; const q = Math.min(m.monto, resta); m.monto = r2(m.monto - q); resta = r2(resta - q); }
        mediosFactura = mediosFactura.filter(m => m.monto > 0);
        const propinaMedio = principal.medio;
        if (this.cfg.enviar_hacienda !== false && doc.estado === 'firmado') { try { await api('/api/comprobantes/' + doc.id + '/enviar', { method: 'POST' }); } catch (e) { avisos.push('Queda en cola para Hacienda (' + e.message + ')'); } }
        const pagosOk = []; let aplicado = 0;
        for (const m of mediosFactura) {
          const cuenta = this.cuentaPara(m.medio);
          if (!cuenta) { avisos.push('Sin cuenta para ' + nombreMedio(m.medio) + ': registre el cobro en Pagos recibidos'); continue; }
          try { const p = await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: clienteId || null, detalles: 'POS ' + doc.consecutivo, fecha: hoy(), cuenta, condicion_venta: '01', medio_pago: m.medio, moneda: 'CRC', tipo_cambio: 1, monto: m.monto, notas: this.cfg.nombre, facturas: [{ id: doc.id, monto: m.monto }] } }); pagosOk.push(p.numero); aplicado = r2(aplicado + m.monto); }
          catch (e) { avisos.push('Cobro ' + nombreMedio(m.medio) + ' no registrado: ' + e.message); }
        }
        // 4.9: lo ya pagado fuera de la gaveta se aplica al comprobante: el prepago del pedido en línea siempre, y la tarjeta de regalo usada en la
        // caja cuando hay fiado. Antes un pedido a crédito con tarjeta de regalo quedaba fiado por el total y la revendedora debía también lo ya
        // pagado; y un pedido con prepago quedaba de contado con saldo. Lo fiado sigue como saldo del cliente (por eso el tope «cabe»); idempotente
        // por si se reintenta, con una clave por parte. 4.9 (revisión, ronda 2): el prepago se parte en dos:
        //  - lo pagado EN LÍNEA (Tilopay o SINPE verificado) entra a Bancos con su medio, en la cuenta de ese medio en la caja: nadie más lo
        //    registra (verificar el SINPE o la confirmación de Tilopay solo marcan el pedido). Antes iba sin cuenta y como «Tarjeta»: el depósito
        //    del banco quedaba sin asiento. Sin cuenta configurada se aplica igual al comprobante y se avisa que falta registrarlo en Bancos;
        //  - la tarjeta de regalo va SIN cuenta (medio 99 con su descripción): ese dinero entró a Bancos al vender la tarjeta.
        // Si el prepago quedó recortado al total de esta cuenta, primero va lo pagado en línea (es lo que todavía no está en Bancos).
        const yaPagado = [];
        if (pre > 0) {
          const preOnline = r2(Math.min(pre, Math.max(0, +prepagoV.online || 0))), preRegalo = r2(pre - preOnline), medOn = prepagoV.medio || '02';   // sin «online» (cuentas de la 3.49): todo es tarjeta de regalo
          if (preOnline > 0) yaPagado.push({ medio: medOn, cuenta: this.cuentaPara(medOn), enLinea: true, monto: preOnline, idem: 'prepago:online:' + doc.id, detalles: 'Pago en línea ' + nombreMedio(medOn) + (prepagoV.referencia ? ' ' + prepagoV.referencia : '') + ' (pedido en línea)' });
          if (preRegalo > 0) yaPagado.push({ medio: '99', cuenta: '', monto: preRegalo, idem: 'prepago:' + doc.id, detalles: 'Tarjeta de regalo ' + (prepagoV.tarjeta || '') + ' (pedido en línea)' });
        }
        if (fiado) for (const g of regalosOk) yaPagado.push({ medio: '99', cuenta: '', monto: g.monto, idem: 'regalo:' + doc.id + ':' + g.codigo, detalles: 'Tarjeta de regalo ' + g.codigo });
        let cabe = r2(total - (fiado ? +fiado.monto || 0 : 0) - aplicado);
        let enLineaOk = null;   // 4.9: lo pagado en línea que sí entró a Bancos (con cuenta): queda en la venta para que anularVenta lo saque
        for (const y of yaPagado) {
          const monto = r2(Math.min(y.monto, cabe)); if (monto <= 0.005) continue;
          try {
            await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: clienteId || null, detalles: (y.detalles + ' · POS ' + doc.consecutivo).slice(0, 200), fecha: hoy(), cuenta: y.cuenta, condicion_venta: '01', medio_pago: y.medio, medio_pago_otros: y.medio === '99' ? 'Tarjeta de regalo' : null, moneda: 'CRC', tipo_cambio: 1, monto, notas: this.cfg.nombre, facturas: [{ id: doc.id, monto }], idempotencia: y.idem } }); cabe = r2(cabe - monto);
            if (y.enLinea && y.cuenta) enLineaOk = { medio: y.medio, cuenta: y.cuenta, monto };
            if (y.enLinea && !y.cuenta) avisos.push('Sin cuenta de Bancos para ' + nombreMedio(y.medio) + ' en la caja: el pago en línea (' + money(monto) + ') se aplicó al comprobante; registre el pago en línea en Bancos');
          } catch (e) { avisos.push(y.detalles + ' (' + money(monto) + ') no se aplicó al comprobante' + (fiado ? ': queda como deuda del cliente' : '') + '; regístrelo en Pagos recibidos ' + (y.enLinea ? 'con la cuenta de Bancos donde entró el pago en línea' : 'sin cuenta') + ' (' + e.message + ')'); }
        }
        if (usd) {   // el cambio de dólares en Bancos: + dólares en la caja en dólares, − su equivalente en colones de la gaveta (mismas referencias que usa la nube al recibir una venta local)
          const ref = 'pos:cambio:' + doc.consecutivo, detalle = 'Dólares recibidos · ' + doc.consecutivo.slice(-10);
          if (usd.cuenta_usd) { try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: usd.cuenta_usd, monto: usd.monto_usd, fecha: hoy(), descripcion: detalle, ref: ref + ':usd', moneda: 'USD', tipo_cambio: usd.tc } }); } catch (e) { avisos.push('Los dólares no entraron a la caja en dólares: ' + e.message); } }
          if (usd.cuenta_crc) { try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: usd.cuenta_crc, monto: -r2(usd.monto_usd * usd.tc), fecha: hoy(), descripcion: detalle + ' · equivalente en colones (vuelto)', ref: ref + ':crc', moneda: 'CRC', tipo_cambio: 1 } }); } catch (e) { avisos.push('El equivalente en colones no salió de la gaveta en Bancos: ' + e.message); } }
        }
        if (propina > 0 && propinaMedio !== '01') {   // propina con tarjeta, SINPE o transferencia: entra a Bancos aparte
          const cuenta = this.cuentaPara(propinaMedio);
          if (cuenta) { try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta, monto: propina, fecha: hoy(), descripcion: 'Propina · ' + doc.consecutivo.slice(-10) + (salonero ? ' · ' + salonero : ''), ref: 'pos:propina:' + doc.id, moneda: 'CRC', tipo_cambio: 1 } }); } catch (e) { avisos.push('La propina no entró a Bancos: ' + e.message); } }
        }
        if (cajaId) {
          try { await mock.refrescar(['pos_cajas', 'pos_ventas'], { sinCorte: true }); } catch {}   // 4.8: sigue aunque el cajero cambie de pantalla
          const c = cajaPorId(cajaId);
          if (c && c.estado === 'Abierta') registrarVentaEnCaja(cajaId, { doc_id: doc.id, consecutivo: doc.consecutivo, tipo: doc.tipo_documento, total, medios: mediosFactura, propina, propina_medio: propinaMedio, salonero, servicio: this.totales.servicio, rondas: Math.max(0, ...this.lineas.map(l => +l.ronda || 0)), items: this.totales.items, cliente: cliente ? cliente.nombre : null, mesa: mesa ? mesa.nombre : (nombreEspera || null), lineas: this.lineas.map(l => ({ producto_id: l.producto_id, detalle: l.detalle, cantidad: +l.cantidad, precio: +l.precio_unitario, descuento: r2(this.descuentoDe(l)), tarifa: +l.tarifa || 0, categoria: (this.productos.find(x => x.id === l.producto_id) || {}).categoria || '', promo: l.promo || l.combo || '' })), fiado: fiado ? r2(fiado.monto) : 0, hora: new Date().toISOString(), usuario: sesion.usuario?.correo, vuelto, pagos: pagosOk, usd, prepago_online: enLineaOk });   // 4.9: prepago_online (no va en medios: no es de la gaveta ni del cierre)
          else avisos.push('La caja ' + (c ? c.caja : '') + ' ya estaba cerrada: la venta se emitió y cobró, pero no quedó en esa sesión (abra una caja nueva)');
          this.caja = cajaAbierta(this.cfg) || (c && c.estado === 'Abierta' ? c : null);
        }
        const idFin = this.esperaId || esperaId;   /* 4.29: el id de AHORA (seguirIds lo corrige si el servidor se lo cambió durante el cobro) */
        if (this._est) this._est.avisarSiPendiente(idFin);   /* 4.31: la comanda del pedido en línea todavía sin imprimir (sin esperar; no lanza) */
        if (idFin) { this.bajaCuenta(idFin, lineasBaja, nombreEspera, true); }   /* 4.31: con la condición de lo cobrado (y de lo que esta pantalla quitó): lo que otro equipo agregó mientras tanto queda en la mesa (sin lo ya pagado en línea) */
        // cobro por partes (3.46): el tiquete queda anotado en la cuenta de la mesa; cuando ya no quedan platos, la cuenta se cierra y la mesa se libera
        const cp = this.cobroParcial; let avisoParte = '';
        if (cp) {
          /* 4.31 (quinta vuelta): en el mismo guardado sale el resto que otro equipo dejó de las líneas que esta parte cobró enteras (`de`) */
          const kp = this._cobrosParte, enteras = new Set(kp && kp.de === cp && Array.isArray(kp.enteras) ? kp.enteras : []);
          this.actualizarCuenta(cp.cuentaId, x => ({ ...x, lineas: (x.lineas || []).filter(l => !(typeof l.de === 'string' && enteras.has(l.de))), cobros: [...(x.cobros || []), { hora: new Date().toISOString(), consecutivo: doc.consecutivo, doc_id: doc.id, monto: total, medios: mediosFactura, parte: cp.parte, usuario: sesion.usuario?.correo }], partes: x.partes ? { ...x.partes, cobradas: (+x.partes.cobradas || 0) + 1 } : x.partes }), enteras.size ? { enteras: [...enteras] } : undefined);
          const c = this.espera.find(x => x.id === cp.cuentaId);
          if (c && !(c.lineas || []).length) { await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]).catch(() => {}); this.bajaCuenta(cp.cuentaId, lineasCobradas, c.nombre, true); avisoParte = ' · cuenta completa: la mesa quedó libre'; }   /* 4.31: primero queda anotado este cobro (si otro equipo agregó un plato, la cuenta sigue con él y con sus cobros); se cierra solo si en el servidor tampoco le quedan platos; con lo cobrado en esta parte, por si el guardado que los quitaba no llegó */
          else if (c) avisoParte = cp.de ? ' · parte ' + cp.parte + ' de ' + cp.de + '; quedan ' + money(c.total) + ' en ' + c.nombre : ' · quedan ' + money(c.total) + ' en ' + c.nombre;
          this.cobroParcial = null;
        }
        this.ultima = { doc, total, vuelto, recibido: usd ? r2(usd.monto_usd * usd.tc) : recibido0, medios, propina, cliente: cliente ? cliente.nombre : 'Consumidor final', usd };
        this.difundir({ lineas: [], gracias: { total, vuelto } });   // pantalla del cliente (3.21)
        this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.pago = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.mesaActual = null; this.servicioPctCuenta = null; this.parteNueva = false;
        this.cupon = null; this.puntos = null; this.prepago = null; this.autorizado = null;   // 4.5: la autorización de supervisor vale para una venta
        if (this.esRestaurante) this.vista = vistaTrasCobro(this.cfg, rapida);   // 4.27: la venta rápida sigue según «Al entrar a esta caja»
        if (this.esRestaurante && this.vista === 'venta') this.rapida = true;   /* 4.39: después de cobrar una cuenta guardada o un pedido, la venta que queda es venta rápida */
        toast((doc.tipo_documento === '04' ? 'Tiquete ' : 'Factura ') + doc.consecutivo.slice(-10) + ' emitido · ' + money(total) + (propina ? ' · propina ' + money(propina) : '') + (vuelto ? ' · vuelto ' + money(vuelto) : '') + avisoParte, 'ok');
        for (const a of avisos) toast(a, 'err');
        if (imprime) this.imprimir(this.ultima);   // 4.29 (K-3): lo de la caja, o al revés si se cobró con F10
        if (this.cfg.abrir_gaveta && medios.some(m => m.medio === '01')) { const imp = this.impresoraTiquete(); if (porAgente(imp)) abrirGaveta(imp).catch(e => toast('La gaveta no abrió: ' + e.message, 'err')); }
      } catch (e) { toast('El comprobante ' + doc.consecutivo.slice(-10) + ' se emitió, pero hubo un problema después: ' + e.message, 'err'); this.lineas = []; this.pago = null; this.cobroParcial = null; }
      finally { this.cobrando = false; this.idem = uuid(); if (rc && rc.clave) this.soltarCobro(rc, true, lineasCobradas); }   /* 4.31: terminado, bien o mal: se suelta (cuando la cuenta ya quedó guardada) */
      this.cargarExistencias();
      this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus());
    },
    // ---- cargo a habitación (hotel): el consumo queda en la cuenta del huésped y se factura al hacer el check-out ----
    async abrirCargoHab() {
      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return toast('Termine o cierre el cobro antes de cargar a la habitación', 'err');   /* 4.39 (tercera vuelta; quinta: ni con «Dividir» abierto) */
      if (!this.lineas.length) return toast('Agregue productos al carrito', 'err');
      if (this.cfg.pedir_apertura && !this.caja) { toast('Abra la caja antes de cargar', 'err'); return this.abrirApertura(); }
      if (!(await this.cobroPermitido('cargar a la habitación'))) return;   // 4.6
      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return;   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió el cobro (F9 o «Cobrar parte») o «Dividir» */
      this.habCargo = { reserva_id: null, q: '', firma: true, autoriza: '' };
    },
    cargarAHabitacion() {
      if (this._habEnCurso && !this._habSigue) return toast('Se está revisando la cuenta para cargarla: espere un momento', 'ok');   /* 4.39 (tercera vuelta): mientras se pide y se revisa el cobro, otro toque no hace nada (se saltaba la revisión) */
      if (this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('Hay un cobro en curso en esta caja: espere a que termine', 'err');   /* 4.39 (tercera vuelta): ni se carga lo que se está cobrando (cuarta vuelta: ni una parte) */
      const r = reservasHotel().find(x => x.id === this.habCargo.reserva_id); if (!r) return toast('Elija la habitación del huésped', 'err');
      if (!this.lineas.some(l => +l.cantidad > 0)) { this.habCargo = null; return toast('No quedan platos para cargar a la habitación', 'err'); }   /* 4.39 (revisión de los arreglos): la cuenta se cerró en otro equipo con la ventana abierta */
      if (!mock.puedeGuardar()) return;
      /* 4.39 (revisión de los arreglos): como al cobrar, los platos sin enviar de la venta rápida o de la cuenta guardada sin mesa salen a cocina, una */
      /* vez y con el cobro ya pedido al servidor (la venta rápida nueva queda guardada por la comanda y se carga como una cuenta guardada). Sale lo que */
      /* se carga: sin la revisión de «platos que ya estaban guardados» (cobrando, como en emitirCobro) */
      const conComanda = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l));
      const comandaHab = () => { const c0 = this.cobrando; this.cobrando = true; try { this.enviarComanda(); } catch { /* la comanda no detiene el cargo */ } finally { this.cobrando = c0; } };
      if (conComanda && !this.esperaId && !this._rcHab) { comandaHab(); if (this.esperaId) return this.reclamarHab(); }   /* sin cuenta guardada (no se pudo guardar): se carga igual, ya con la comanda */
      else {
        if (this.esperaId && !this._rcHab) return this.reclamarHab();   /* 4.31: una cuenta guardada se carga con su cobro pedido al servidor (como al cobrar) */
        if (conComanda) {   /* 4.39 (revisión de los arreglos): si al guardar con la comanda entró un cambio de otro equipo, no se carga (el cobro pedido lo suelta reclamarHab) */
          const fir = () => this.lineas.map(l => String(l.lid || '') + ':' + (+l.cantidad || 0)).sort().join('|'), f0 = fir(), t0 = +this.totales.total || 0;
          comandaHab();
          if (fir() !== f0 || Math.abs((+this.totales.total || 0) - t0) > 0.005) return toast('La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar.', 'err');
        }
      }
      const rcHab = this._rcHab; this._rcHab = null;
      const t = this.totales, cfgH = configHotel(), fechaHoy = hoy(), items = [];
      for (const l of this.lineas) {
        const cant = +l.cantidad || 0; if (!cant) continue;
        const netoCRC = r2(cant * (+l.precio_unitario || 0) - this.descuentoDe(l)), precio = aMonedaFolio(netoCRC / cant, r.moneda);   // precio unitario sin IVA en la moneda de la cuenta
        items.push(agregarFolio({ reserva_id: r.id, tipo: 'cargo', origen: 'pos', fecha: fechaHoy, detalle: l.detalle + (this.nombreEspera ? ' (' + this.nombreEspera + ')' : '') + (this.habCargo.autoriza ? ' · autoriza ' + this.habCargo.autoriza.trim() : ''), cantidad: cant, precio, tarifa: this.tarifaNeta(l), codigo_tarifa: l.codigo_tarifa, cabys: l.cabys, producto_id: l.producto_id || null, otro_impuesto: otroImpDe(l, this.productos) || null, moneda: r.moneda, caja: this.cfg.nombre, monto_crc: (() => { const oi = otroImpLinea(otroImpDe(l, this.productos), cant, netoCRC); return r2(netoCRC + oi.monto + (netoCRC + oi.base) * this.tarifaNeta(l) / 100); })(), autoriza: (this.habCargo.autoriza || '').trim() }));
      }
      if (t.servicio > 0) items.push(agregarFolio({ reserva_id: r.id, tipo: 'cargo', origen: 'pos', es_otro_cargo: true, fecha: fechaHoy, detalle: (this.cfg.servicio_detalle || 'Impuesto de servicio 10 %') + ' · ' + this.cfg.nombre, cantidad: 1, precio: aMonedaFolio(t.servicio, r.moneda), tarifa: 0, codigo_tarifa: '01', cabys: cfgH.cabys_hospedaje, producto_id: null, moneda: r.moneda, caja: this.cfg.nombre, monto_crc: t.servicio }));
      if (this.esperaId) lidsPantalla(this.lineas, this.cuentaActual);   /* 4.31: los platos de la pantalla sin lid reciben el suyo antes de armar la condición (como al cobrar) */
      const total = t.total, cliente = r.huesped_nombre, mesa = this.mesaActual, esperaId = this.esperaId, nombreEspera = this.nombreEspera, rapida = this.esVentaRapida || (this.esRestaurante && !this.mesaActual && !(this.cuentaActual && (this.cuentaActual.mesa_id || (Array.isArray(this.cuentaActual.mesas_ids) && this.cuentaActual.mesas_ids.length)))), lineas =this.lineas.map(x => ({ ...x }));   /* 4.39: como al cobrar */
      if (this.caja) registrarVentaEnCaja(this.caja.id, { doc_id: null, consecutivo: 'HAB ' + nombreHab(r.habitacion_id), tipo: 'hab', total, medios: [{ medio: 'hab', monto: total }], salonero: this.salonero || null, servicio: t.servicio, rondas: Math.max(0, ...this.lineas.map(l => +l.ronda || 0)), items: t.items, cliente, mesa: mesa ? mesa.nombre : (nombreEspera || null), hora: new Date().toISOString(), usuario: sesion.usuario?.correo, vuelto: 0, pagos: [], reserva_id: r.id });
      if (this._est) this._est.avisarSiPendiente(esperaId);   /* 4.31: la comanda del pedido en línea todavía sin imprimir (sin esperar; no lanza) */
      if (esperaId) this.bajaCuenta(esperaId, lineas, nombreEspera, true);   /* 4.31: con la condición de lo cargado */
      if (rcHab && rcHab.clave) this.soltarCobro(rcHab, true, lineas);   /* 4.31: cargado: esos platos quedan como cobrados */
      if (this.habCargo.firma) this.comandaHab(r, lineas, t);
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.habCargo = null; this.mesaActual = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.idem = uuid();
      if (this.esRestaurante) this.vista = vistaTrasCobro(this.cfg, rapida);   // 4.27
      if (this.esRestaurante && this.vista === 'venta') this.rapida = true;   /* 4.39: como al cobrar */
      toast(money(total) + ' cargados a la habitación ' + nombreHab(r.habitacion_id) + ' · ' + cliente, 'ok');
      this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus());
    },
    comandaHab(r, lineas, t) {
      const e = store.empresa || {};
      const filas = lineas.map(l => '<tr><td>' + esc(l.cantidad) + ' × ' + esc(l.detalle) + '</td><td class="n">' + esc(money(this.lineaTotal(l))) + '</td></tr>').join('');
      const html = '<!doctype html><html><head><meta charset="utf-8"><title>Cargo a habitación</title><style>body{font-family:Arial,sans-serif;font-size:13px;width:72mm;margin:4mm auto;color:#111}h2,h3{margin:2px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:3px 0;border-bottom:1px dotted #bbb}td.n{text-align:right;white-space:nowrap}.tot td{border:0;font-weight:bold}.tot .g{font-size:16px}p{margin:4px 0;text-align:center}.firma{margin-top:34px;border-top:1px solid #111;padding-top:3px;text-align:center;font-size:12px}@media print{body{margin:0}}</style></head><body>'
        + '<h2>' + esc(e.nombre_comercial || e.nombre || '') + '</h2><h3>CARGO A HABITACIÓN ' + esc(nombreHab(r.habitacion_id)) + '</h3><p>' + esc(r.huesped_nombre || '') + ' · ' + esc(r.numero || '') + '</p><p>' + esc(new Date().toLocaleString('es-CR')) + ' · ' + esc(this.cfg.nombre) + (this.nombreEspera ? ' · ' + esc(this.nombreEspera) : '') + '</p>'
        + '<table>' + filas + '</table><table class="tot"><tr><td>Subtotal</td><td class="n">' + esc(money(t.sub)) + '</td></tr>' + (t.desc ? '<tr><td>Descuento</td><td class="n">−' + esc(money(t.desc)) + '</td></tr>' : '') + '<tr><td>IVA</td><td class="n">' + esc(money(t.iva)) + '</td></tr>' + (t.servicio ? '<tr><td>' + esc(this.cfg.servicio_detalle) + '</td><td class="n">' + esc(money(t.servicio)) + '</td></tr>' : '') + '<tr><td class="g">TOTAL</td><td class="n g">' + esc(money(t.total)) + '</td></tr></table>'
        + '<div class="firma">Firma del huésped</div><p>Se carga a su cuenta y se factura al salir. No es un comprobante electrónico.</p></body></html>';
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
    },
    impresoraCaja() { const id = this.cfg.impresora_comprobante_id; return id ? impresoras().find(i => String(i.id) === String(id) && i.activa !== false && i.uso !== 'etiquetas') || null : null; },   // 4.24: la que pasó a ser de etiquetas no recibe tiquetes
    impresoraTiquete() { return impresoraTiqueteAqui(this.impresoraCaja(), impresoras()); },   // 4.25: en el programa, la de tiquetes de esta computadora manda sobre la de la caja (y cada una, como está conectada aquí)
    // Tiquete por el agente local (impresora USB o de red de la caja); si falla, se abre el tiquete del navegador como siempre
    async imprimirTermico(u, imp, copia) {
      try {
        const doc = await api('/api/comprobantes/' + u.doc.id);
        await imprimirAgente(imp, docTiquete({ empresa: store.empresa, doc, cfg: this.cfg, recibido: u.recibido, vuelto: u.vuelto, medios: u.medios, cajero: this.cfg.vendedor || sesion.usuario?.nombre || '', nombreMedio, copia }));
      } catch (e) { toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre el tiquete del navegador.', 'err'); this.imprimir(u, 'tiquete', true, copia); }
    },
    // 4.33: «Reimprimir» en «Ventas de esta caja»: el tiquete de 80 mm de una venta anterior, con COPIA arriba. Nunca abre la gaveta ni emite nada.
    verTiquete(v) {   /* 4.33: «Ver» en «Ventas de esta caja»: el mismo tiquete con COPIA, en el navegador y sin mandarlo a la impresora */
      if (!v || !v.doc_id || v.anulada || v.tipo === 'hab' || v.abono) return;
      return this.imprimir({ doc: { id: v.doc_id }, recibido: v.recibido, vuelto: v.vuelto, medios: v.medios }, 'tiquete', true, true);
    },
    reimprimirVenta(v) {
      if (!v || !v.doc_id || v.anulada || v.tipo === 'hab' || v.abono) return;
      return this.imprimir({ doc: { id: v.doc_id }, recibido: v.recibido, vuelto: v.vuelto, medios: v.medios }, 'tiquete', false, true);
    },
    imprimir(u, formato, sinAgente, copia) {
      if (u && u.doc && u.doc.provisional) return this.imprimirProvisional(u.pendiente || this.cola.find(v => v.id === u.doc.pendiente_id), sinAgente);
      const f = formato || this.cfg.formato || 'tiquete';
      const imp = this.impresoraTiquete();
      if (f === 'tiquete' && !sinAgente && porAgente(imp)) return this.imprimirTermico(u, imp, copia);
      const url = f === 'carta' ? '/api/comprobantes/' + u.doc.id + '/pdf' : '/api/comprobantes/' + u.doc.id + '/tiquete?ancho=' + (this.cfg.ancho_ticket || 80) + (u.recibido !== null && u.recibido !== undefined ? '&recibido=' + u.recibido + '&vuelto=' + (u.vuelto || 0) : '') + '&cajero=' + encodeURIComponent(this.cfg.nombre || '') + (copia ? '&copia=true' : '');
      window.open(url, '_blank');
    },
    // ---- venta sin internet (3.55): cola de ventas de contado que esperan conexión ----
    claveCola() { return 'facturacr:ventas_pendientes:' + (store.empresa ? store.empresa.id : 0); },
    // Cierre de la etapa 0: sin conexión, lo anotado en la sesión de caja y el retiro de la cuenta en espera viven solo en memoria hasta poder subirlos.
    // Si la página se recarga antes, la venta seguía en la cola pero desaparecía de la caja (cierre incompleto) y la cuenta volvía a aparecer para cobrarse
    // otra vez. La cola guarda lo necesario y aquí se repone, una sola vez por venta.
    reponerPendientes() {
      if (!mock.cargado || !this.cola.length) return;
      const ventas = mock.get('pos_ventas', []) || [];
      for (const v of this.cola) {
        if (v.caja_id && !ventas.some(x => x.pendiente_id === v.id || (v.doc && x.doc_id === v.doc.id))) {
          const cj = cajaPorId(v.caja_id);
          if (cj && cj.estado === 'Abierta') registrarVentaEnCaja(v.caja_id, { doc_id: null, consecutivo: 'PENDIENTE ' + String(v.id).slice(0, 6).toUpperCase(), tipo: v.tipo_documento, total: v.total, medios: v.medios, propina: v.propina, propina_medio: v.propina_medio, salonero: v.salonero || null, servicio: v.servicio, cliente: v.cliente_nombre, hora: v.creado, pendiente_id: v.id });
        }
        if (v.espera_id && (this.espera || []).some(x => x.id === v.espera_id)) { if (Array.isArray(v.espera_quitadas)) this.bajaCuenta(v.espera_id, v.espera_quitadas, v.espera, true); else this.espera = mock.actualizar('pos_espera', l => (l || []).filter(x => x.id !== v.espera_id), []); }   /* 4.31: con la condición de lo cobrado (la venta encolada con la versión anterior, como antes) */
      }
    },
    cargarCola() { try { this.cola = JSON.parse(localStorage.getItem(this.claveCola()) || '[]'); } catch { this.cola = []; } },
    guardarCola() { this.guardarColaEn(this.claveCola()); },
    guardarColaEn(clave) { try { localStorage.setItem(clave, JSON.stringify(this.cola)); } catch { toast('No se pudo guardar la venta pendiente en este navegador', 'err'); } },   // 4.8: con la clave de la empresa con que empezó el reintento
    ventaSinConexion(c) {
      // 4.13 (confirmado por el contador): el comprobante provisional no es para cortes de internet y la caja web no puede firmar sin conexión
      // (la llave no baja al navegador). Con facturación electrónica no se emite: el carrito queda y la misma clave de idempotencia evita duplicar al reintentar.
      const reclamo = this._reclamoSinRed || null; this._reclamoSinRed = null;   /* 4.31 (quinta vuelta): el cobro pedido de la cuenta (emitirCobro); si la venta no queda en la cola, vence solo */
      if (sesion.electronica) { this.cobrando = false; return toast('Sin conexión con el servidor: el comprobante no se emitió y la venta no quedó registrada. Intente de nuevo cuando regrese la conexión. Para vender sin internet use el programa FISITAAP Local.', 'err'); }
      const motivo = c.fiado ? 'ventas fiadas' : c.regalos.length ? 'tarjetas de regalo' : this.cupon ? 'cupones' : (this.puntos && this.puntos.canje) ? 'canje de puntos' : this.cobroParcial ? 'cobros por partes' : this.prepago ? 'pedidos ya pagados en línea' : '';
      if (motivo) { this.cobrando = false; return toast('Sin conexión con el servidor: las ' + motivo + ' necesitan conexión. Cobre de contado sin eso o espere a que vuelva la red.', 'err'); }
      const vuelto = c.usd ? r2(Math.max(0, c.usd.monto_usd * c.usd.tc - c.total - c.propina)) : (c.recibido0 !== null && c.medios.length === 1 && c.medios[0].medio === '01' ? r2(Math.max(0, c.recibido0 - c.total - c.propina)) : c.pt.vuelto);
      const mediosFactura = c.medios.filter(m => m.medio !== 'fiado' && m.medio !== 'regalo').map(m => ({ ...m }));
      const v = { id: this.idem, creado: new Date().toISOString(), body: c.body, tipo_documento: c.tipoDoc, total: c.total, medios: mediosFactura, propina: c.propina, propina_medio: c.principal.medio, usd: c.usd, recibido: c.usd ? r2(c.usd.monto_usd * c.usd.tc) : c.recibido0, vuelto,
        cliente_id: c.clienteId || null, cliente_nombre: c.cliente ? c.cliente.nombre : 'Consumidor final', espera: c.nombreEspera || '', caja_id: c.cajaId || null, salonero: c.salonero || null, servicio: this.totales.servicio, iva: this.totales.iva,
        lineas: this.lineas.map(l => ({ cantidad: +l.cantidad, detalle: l.detalle + (l.nota ? ' (' + l.nota + ')' : ''), precio_unitario: +l.precio_unitario, descuento: r2(this.descuentoDe(l)), tarifa: +l.tarifa || 0 })), error: '', intentos: 0, sucursal: this.cabSucursal()['X-Sucursal'] || null };
      v.espera_id = c.esperaId || null;   // para reponer el retiro de la cuenta si la página se recarga sin conexión
      if (v.espera_id) v.espera_quitadas = this.cierreCobro(v.espera_id, this.lineas.filter(l => l && l.lid).map(l => ({ lid: l.lid, cantidad: +l.cantidad })));   /* 4.31: la condición de la baja, por si se repone (4.31, sexta vuelta: con lo que esta pantalla quitó o bajó sin guardar) */
      if (reclamo && reclamo.clave) v.reclamo = reclamo;   /* 4.31 (quinta vuelta): al emitirse desde la cola, sus platos quedan anotados como cobrados */
      const rapida = !!c.rapida;   // 4.27: tomada en cobrar() antes de limpiar la venta
      this.cargarCola(); this.cola.push(v); this.guardarCola();   // 4.8: releída: otra pestaña pudo encolar o emitir mientras tanto
      if (c.cajaId) { const cj = cajaPorId(c.cajaId); if (cj && cj.estado === 'Abierta') registrarVentaEnCaja(c.cajaId, { doc_id: null, consecutivo: 'PENDIENTE ' + v.id.slice(0, 6).toUpperCase(), tipo: c.tipoDoc, total: c.total, medios: mediosFactura, propina: c.propina, propina_medio: c.principal.medio, salonero: c.salonero || null, servicio: this.totales.servicio, cliente: v.cliente_nombre, hora: v.creado, pendiente_id: v.id }); }
      if (c.esperaId) this.bajaCuenta(c.esperaId, v.espera_quitadas || [], c.nombreEspera, true);   /* 4.31: con la condición de lo cobrado */
      this.ultima = { doc: { provisional: true, pendiente_id: v.id, consecutivo: 'PENDIENTE', tipo_documento: c.tipoDoc, id: null }, pendiente: v, total: c.total, vuelto, recibido: v.recibido, medios: c.medios, propina: c.propina, cliente: v.cliente_nombre, usd: c.usd };
      this.difundir({ lineas: [], gracias: { total: c.total, vuelto } });
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.pago = null; this.clienteId = this.cfg.cliente_defecto_id || null; this.mesaActual = null; this.servicioPctCuenta = null; this.parteNueva = false;
      this.cupon = null; this.puntos = null; this.prepago = null; this.autorizado = null; this.cobrando = false; this.idem = uuid();   // 4.5: el token ya viaja en el body encolado
      if (this.esRestaurante) this.vista = vistaTrasCobro(this.cfg, rapida);   // 4.27
      if (this.esRestaurante && this.vista === 'venta') this.rapida = true;   /* 4.39: como al cobrar */
      toast('Sin conexión: venta de ' + money(c.total) + ' guardada. Se emite sola al volver la red (' + this.cola.length + ' en espera).', 'err');
      if (c.imprime !== undefined ? c.imprime : this.cfg.imprimir_auto) this.imprimirProvisional(v);   // 4.29 (K-3): la elección del cobro
      if (this.cfg.abrir_gaveta && c.medios.some(m => m.medio === '01')) { const imp = this.impresoraTiquete(); if (porAgente(imp)) abrirGaveta(imp).catch(() => {}); }
      this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus());
    },
    docProvisional(v) {
      const lineas = v.lineas.map(l => ({ ...l, impuesto: r2((l.cantidad * l.precio_unitario - l.descuento) * l.tarifa / 100) }));
      return { tipo_documento: v.tipo_documento, consecutivo: 'PROVISIONAL ' + v.id.slice(0, 6).toUpperCase(), fecha_emision: v.creado, receptor_nombre: v.cliente_nombre, condicion_venta: '01', lineas, impuesto: v.iva, total: v.total, moneda: 'CRC',
        otros_cargos: v.servicio > 0 ? [{ detalle: this.cfg.servicio_detalle || 'Impuesto de servicio 10 %', monto: v.servicio }] : [], clave: null };
    },
    async imprimirProvisional(v, sinAgente) {
      if (!v) return;
      const doc = this.docProvisional(v), imp = this.impresoraTiquete(), aviso = 'COMPROBANTE PROVISIONAL · el tiquete electrónico se emite al volver la conexión';
      if (!sinAgente && porAgente(imp) && (this.cfg.formato || 'tiquete') === 'tiquete') {
        try { const d = docTiquete({ empresa: store.empresa, doc, cfg: this.cfg, recibido: v.recibido, vuelto: v.vuelto, medios: v.medios, cajero: this.cfg.vendedor || sesion.usuario?.nombre || '', nombreMedio }); d.bloques.splice(1, 0, { t: 'texto', x: aviso, al: 'C', b: true }); d.bloques.push({ t: 'texto', x: aviso, al: 'C' }); await imprimirAgente(imp, d); return; }
        catch (e) { toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre el comprobante en el navegador.', 'err'); }
      }
      const e = store.empresa || {}, esc = t => String(t ?? '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));
      const filas = doc.lineas.map(l => '<tr><td>' + esc(fmt(l.cantidad, 0)) + ' × ' + esc(l.detalle) + '</td><td style="text-align:right">' + esc(money(l.cantidad * l.precio_unitario - l.descuento + l.impuesto)) + '</td></tr>').join('');
      const html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Comprobante provisional</title><style>body{font-family:monospace;font-size:12px;width:280px;margin:12px auto}h2,h3{text-align:center;margin:4px 0}table{width:100%;border-collapse:collapse}td{padding:2px 0;vertical-align:top}.b{font-weight:700}.c{text-align:center}.aviso{border:1px dashed #000;padding:6px;text-align:center;font-weight:700;margin:8px 0}</style></head><body>'
        + '<h2>' + esc(e.nombre_comercial || e.nombre || '') + '</h2>' + (e.numero_id ? '<div class="c">Cédula: ' + esc(e.numero_id) + '</div>' : '') + '<div class="aviso">' + aviso + '</div>'
        + '<div class="c">' + esc(doc.consecutivo) + '<br>' + esc(fecha(doc.fecha_emision)) + ' ' + esc(String(doc.fecha_emision).slice(11, 16)) + '</div><div>Cliente: ' + esc(doc.receptor_nombre) + '</div><hr><table>' + filas + '</table><hr>'
        + '<table><tr><td>IVA</td><td style="text-align:right">' + esc(money(doc.impuesto)) + '</td></tr>' + doc.otros_cargos.map(o => '<tr><td>' + esc(o.detalle) + '</td><td style="text-align:right">' + esc(money(o.monto)) + '</td></tr>').join('')
        + '<tr class="b"><td>TOTAL</td><td style="text-align:right">' + esc(money(doc.total)) + '</td></tr>' + (v.recibido !== null && v.recibido !== undefined ? '<tr><td>Recibido</td><td style="text-align:right">' + esc(money(v.recibido)) + '</td></tr><tr><td>Cambio</td><td style="text-align:right">' + esc(money(v.vuelto || 0)) + '</td></tr>' : '')
        + v.medios.map(m => '<tr><td>' + esc(nombreMedio(m.medio)) + '</td><td style="text-align:right">' + esc(money(m.monto)) + '</td></tr>').join('') + '</table><hr><div class="c">' + aviso + '</div></body></html>';
      const w = window.open('', '_blank'); if (!w) return toast('Permita las ventanas emergentes para imprimir el comprobante provisional', 'err');
      w.document.write(html); w.document.close(); setTimeout(() => { try { w.print(); } catch {} }, 300);
    },
    async reintentarPendientes(manual) {
      if (this.reintentando || !this.cola.length) return;
      // 4.8: un solo reintento por empresa en este navegador (otra pestaña o una pantalla vieja de la caja emitían y cobraban dos veces)
      if (navigator.locks && !this._conCandado) {
        return navigator.locks.request('facturacr:cola:' + (store.empresa ? store.empresa.id : 0), { ifAvailable: true }, async l => {
          if (!l) return; this._conCandado = true; try { await this.reintentarPendientes(manual); } finally { this._conCandado = false; }
        });
      }
      const eid = store.empresa ? store.empresa.id : 0, gen = mock.generacion, clave = this.claveCola();
      const vigente = () => !this._fuera && (store.empresa ? store.empresa.id : 0) === eid && mock.generacion === gen;   // 4.8: cambió de empresa o salió de la caja: se detiene
      const cabEmpresa = { 'X-Empresa': String(eid) };
      const anotar = (id, cambios) => this.anotarEnCola(clave, id, cambios);   // 4.8: sobre lo que hay en el navegador en ese momento
      this.reintentando = true; let emitidas = 0;
      try {
        this.cargarCola();
        for (const v0 of this.cola.slice()) {
          if (!vigente()) break;
          this.cargarCola(); const v = this.cola.find(x => x.id === v0.id); if (!v) continue;     // otra pestaña ya la emitió o la descartó
          let doc;
          try { doc = await api('/api/comprobantes', { method: 'POST', body: v.body, headers: { ...cabEmpresa, ...(v.sucursal ? { 'X-Sucursal': String(v.sucursal) } : {}) } }); }   // misma clave de idempotencia: si ya se emitió, devuelve el mismo
          catch (e) {
            if (e.sinConexion || !vigente()) break;
            // 4.5: la autorización de supervisor no viajó (la clave se comparó sin red), venció (15 min) o es de otro usuario: con «Reintentar ahora»
            // se vuelve a pedir la clave solo para esta venta y el token queda en la cola; en los reintentos automáticos no se molesta al cajero
            let err = e, otraVez = null;
            if (manual && e.status === 403 && /supervisor/i.test(e.message || '')) {
              const previo = this.autorizado; this.autorizado = null;
              if (await this.autorizar('Venta pendiente de ' + money(v.total)) && this.autorizado) {
                v.body = { ...v.body, pos_autorizacion: this.autorizado }; anotar(v.id, { body: v.body });
                try { otraVez = await api('/api/comprobantes', { method: 'POST', body: v.body, headers: { ...cabEmpresa, ...(v.sucursal ? { 'X-Sucursal': String(v.sucursal) } : {}) } }); }
                catch (e2) { if (e2.sinConexion) { this.autorizado = previo; break; } err = e2; }
              }
              this.autorizado = previo;
            }
            if (!otraVez) { v.error = err.message; v.intentos = (v.intentos || 0) + 1; anotar(v.id, { error: v.error, intentos: v.intentos }); continue; }   // rechazo del servidor: queda para revisarla
            doc = otraVez;
          }
          v.doc = { id: doc.id, consecutivo: doc.consecutivo }; v.error = ''; anotar(v.id, { doc: v.doc, error: '' });   // 4.8: siempre (con la clave de la empresa con que empezó): ya emitida, no se puede descartar
          if (v.reclamo && v.reclamo.clave) api('/api/pos/cobro/soltar', { method: 'POST', headers: cabEmpresa, body: { cuenta_id: v.reclamo.id, clave: v.reclamo.clave, cobrado: true, lids: Array.isArray(v.reclamo.lids) ? v.reclamo.lids : [] } }).catch(() => {});   /* 4.31 (quinta vuelta): sus platos quedan anotados como cobrados (otro equipo ya no los cobra); un servidor sin la ruta, igual */
          if (!vigente()) break;                                              // queda en la cola con su comprobante: el próximo reintento recibe el mismo y termina el cobro
          const avisos = [];
          let pendiente = '';   // 4.8: '' terminó · 'red' sin conexión a mitad (queda en la cola) · otro texto: el servidor rechazó un cobro (queda con el motivo)
          try {
            if (this.cfg.enviar_hacienda !== false && doc.estado === 'firmado') { try { await api('/api/comprobantes/' + doc.id + '/enviar', { method: 'POST', headers: cabEmpresa }); } catch (e) { avisos.push('Queda en cola para Hacienda (' + e.message + ')'); } }
            let mediosFactura = v.medios.map(m => ({ ...m })), resta = v.propina || 0;
            for (const m of mediosFactura.slice().sort((a, b) => b.monto - a.monto)) { if (resta <= 0) break; const q = Math.min(m.monto, resta); m.monto = r2(m.monto - q); resta = r2(resta - q); }
            mediosFactura = mediosFactura.filter(m => m.monto > 0);
            // 4.8: como en el cobro normal, los medios se ajustan al total que calculó el servidor (una diferencia de un céntimo hacía rechazar el cobro)
            const totalSrv = r2(doc.total || v.total), dif = r2(totalSrv - mediosFactura.reduce((s, m) => s + (+m.monto || 0), 0));
            if (Math.abs(dif) > 0.001 && Math.abs(dif) < 1 && mediosFactura.length) { const mayor = mediosFactura.slice().sort((a, b) => b.monto - a.monto)[0]; mayor.monto = r2(mayor.monto + dif); mediosFactura = mediosFactura.filter(m => m.monto > 0); }
            v.cobrados = v.cobrados || {};                                    // 4.8: avance por cobro (un reintento no repite lo ya cobrado)
            for (const [i, m] of mediosFactura.entries()) {
              if (!vigente()) { pendiente = 'red'; break; }
              const k = i + ':' + m.medio;                                     // por posición: dos tarjetas son dos cobros del mismo medio
              if (v.cobrados[k]) continue;
              const cuenta = this.cuentaPara(m.medio);
              if (!cuenta) { avisos.push('Sin cuenta para ' + nombreMedio(m.medio) + ': registre el cobro en Pagos recibidos'); continue; }
              try {
                // 4.8: «facturas» (antes «documentos», que el servidor no conoce: el cobro no se aplicaba a la factura) y una clave de
                // idempotencia por cobro: si se perdió la respuesta de uno que sí se guardó, el servidor devuelve el mismo en vez de cobrar dos veces
                const pg = await api('/api/pagos', { method: 'POST', headers: cabEmpresa, body: { tipo: 'caja', cliente_id: v.cliente_id || null, detalles: 'POS ' + doc.consecutivo, fecha: hoy(), cuenta, condicion_venta: '01', medio_pago: m.medio, moneda: 'CRC', tipo_cambio: 1, monto: m.monto, facturas: [{ id: doc.id, monto: m.monto }], idempotencia: 'cola:' + v.id + ':' + doc.id + ':' + k } });
                v.cobrados[k] = (pg && pg.numero) || true; anotar(v.id, { cobrados: { ...v.cobrados } });
              } catch (e) {
                if (e.sinConexion) { pendiente = 'red'; break; }
                if (e.status === 403) { pendiente = e.message; break; }        // p. ej. el cajero solo cobra comprobantes de hoy: queda para quien tenga permiso de cobros
                avisos.push('Cobro ' + nombreMedio(m.medio) + ' no registrado: ' + e.message);
              }
            }
            // propina y dólares: el servidor no repite un movimiento con la misma referencia, así que sin red quedan para el próximo reintento
            const mov = async (body, aviso) => {
              if (pendiente === 'red' || !vigente()) { pendiente = 'red'; return; }   // un cobro rechazado no impide registrarlos (el servidor no los repite por su ref)
              try { await api('/api/bancos/movimientos', { method: 'POST', headers: cabEmpresa, body }); }
              catch (e) { if (e.sinConexion) pendiente = 'red'; else avisos.push(aviso + ': ' + e.message); }
            };
            if (v.propina > 0 && v.propina_medio !== '01') { const cuenta = this.cuentaPara(v.propina_medio); if (cuenta) await mov({ cuenta, monto: v.propina, fecha: hoy(), descripcion: 'Propina · ' + doc.consecutivo.slice(-10) + (v.salonero ? ' · ' + v.salonero : ''), ref: 'pos:propina:' + doc.consecutivo, moneda: 'CRC', tipo_cambio: 1 }, 'Propina no registrada'); }
            if (v.usd) { const ref = 'pos:cambio:' + doc.consecutivo, detalle = 'Dólares recibidos · ' + doc.consecutivo.slice(-10);
              if (v.usd.cuenta_usd) await mov({ cuenta: v.usd.cuenta_usd, monto: v.usd.monto_usd, fecha: hoy(), descripcion: detalle, ref: ref + ':usd', moneda: 'USD', tipo_cambio: v.usd.tc }, 'Dólares no registrados');
              if (v.usd.cuenta_crc) await mov({ cuenta: v.usd.cuenta_crc, monto: -r2(v.usd.monto_usd * v.usd.tc), fecha: hoy(), descripcion: detalle + ' · equivalente en colones (vuelto)', ref: ref + ':crc', moneda: 'CRC', tipo_cambio: 1 }, 'Vuelto en colones no registrado'); }
            if (pendiente === 'red') break;
            if (pendiente) {
              v.falta = r2(mediosFactura.reduce((s, m, i) => s + (v.cobrados[i + ':' + m.medio] ? 0 : (+m.monto || 0)), 0));   // lo que queda por registrar en Pagos recibidos
              v.error = 'falta registrar un cobro de ' + money(v.falta) + ': ' + pendiente; v.intentos = (v.intentos || 0) + 1;
              anotar(v.id, { error: v.error, intentos: v.intentos, falta: v.falta });
              if (manual || v0.falta === undefined || v0.falta === null) for (const a of avisos) toast(a, 'err');   // la primera vez o con «Reintentar ahora»: no cada 30 s
              continue;
            }
            if (!vigente()) break;
            mock.actualizar('pos_ventas', l => (l || []).map(x => (x.pendiente_id === v.id ? { ...x, doc_id: doc.id, consecutivo: doc.consecutivo, pendiente_id: null } : x)), []);
          } catch (e) { avisos.push('Emitida, pero hubo un problema después: ' + e.message); }
          if (!vigente()) break;
          this.quitarDeCola(clave, v.id); emitidas++;
          if (this.ultima && this.ultima.doc && this.ultima.doc.pendiente_id === v.id) this.ultima = { ...this.ultima, doc, pendiente: null };
          for (const a of avisos) toast(a, 'err');
        }
      } finally { this.reintentando = false; }
      if (emitidas) toast(emitidas + ' venta(s) pendiente(s) emitida(s) al recuperar la conexión', 'ok');
      else if (manual && this.cola.length) toast(this.cola.some(v => v.error) ? 'Hay ventas que el servidor rechazó: revise el motivo' : 'Todavía no hay conexión con el servidor', 'err');
    },
    // 4.8: el avance de una venta pendiente se escribe sobre lo que hay en este navegador en ese momento (otra pestaña pudo encolar
    // otra venta mientras se esperaba al servidor), con la clave de la empresa con que empezó el reintento
    anotarEnCola(clave, id, cambios) {
      let l; try { l = JSON.parse(localStorage.getItem(clave) || '[]'); } catch { l = []; }
      const x = l.find(y => y.id === id); if (!x) return false;
      Object.assign(x, cambios);
      try { localStorage.setItem(clave, JSON.stringify(l)); } catch { toast('No se pudo guardar la venta pendiente en este navegador', 'err'); }
      if (clave === this.claveCola()) this.cola = l;
      return true;
    },
    quitarDeCola(clave, id) {
      let l; try { l = JSON.parse(localStorage.getItem(clave) || '[]'); } catch { l = []; }
      l = l.filter(y => y.id !== id);
      try { localStorage.setItem(clave, JSON.stringify(l)); } catch { toast('No se pudo guardar la venta pendiente en este navegador', 'err'); }
      if (clave === this.claveCola()) this.cola = l;
    },
    // 4.8: venta ya emitida cuyo cobro el servidor no deja registrar desde la caja (p. ej. pasó de día y el cajero solo cobra lo de hoy):
    // queda en la sesión de caja con su comprobante y el cobro lo registra en Pagos recibidos alguien con ese permiso
    async entregarPendiente(v) {
      if (this.reintentando) return toast('Se están emitiendo las ventas pendientes: intente de nuevo en unos segundos', 'err');
      const falta = v.falta !== undefined && v.falta !== null ? v.falta : v.total, parte = v.cobrados && Object.keys(v.cobrados).length;
      if (!v.doc || !confirm('El comprobante ' + v.doc.consecutivo.slice(-10) + ' ya se emitió, pero ' + (parte ? 'parte de su cobro' : 'su cobro') + ' no se pudo registrar desde la caja. Se quita de esta lista y el cobro pendiente de ' + money(falta) + (parte ? ' (el resto ya quedó registrado)' : '') + ' debe registrarse en Ingresos › Pagos recibidos. ¿Continuar?')) return;
      const clave = this.claveCola();
      const hacer = () => {
        let l; try { l = JSON.parse(localStorage.getItem(clave) || '[]'); } catch { l = []; }
        const a = l.find(x => x.id === v.id); if (!a || !a.doc || !a.error) return false;   // solo si sigue con el cobro rechazado
        mock.actualizar('pos_ventas', l2 => (l2 || []).map(x => (x.pendiente_id === v.id ? { ...x, doc_id: a.doc.id, consecutivo: a.doc.consecutivo, pendiente_id: null } : x)), []);
        this.quitarDeCola(clave, v.id);
        return true;
      };
      const ok = navigator.locks ? await navigator.locks.request('facturacr:cola:' + (store.empresa ? store.empresa.id : 0), { ifAvailable: true }, l => (l ? hacer() : null)) : hacer();
      if (ok === null) toast('Otra pestaña está emitiendo las ventas pendientes: intente de nuevo en unos segundos', 'err');
      else if (ok) toast('Quitada de la lista: registre el cobro pendiente de ' + money(falta) + ' de ' + v.doc.consecutivo.slice(-10) + ' en Pagos recibidos', 'ok');
      else this.cargarCola();
    },
    async descartarPendiente(v) {
      this.cargarCola(); const actual = this.cola.find(x => x.id === v.id);
      if (!actual) return toast('Esa venta ya no está en espera: se emitió o se descartó en otra pestaña', 'ok');
      // 4.8: una venta que ya tiene comprobante (o parte del cobro registrado) no se descarta: se anula con nota de crédito
      if (actual.doc || (actual.cobrados && Object.keys(actual.cobrados).length)) return toast('Esta venta ya se emitió' + (actual.doc ? ' (' + actual.doc.consecutivo.slice(-10) + ')' : '') + ': no se puede descartar. ' + (actual.error ? 'Use «Quitar (cobrar en Pagos recibidos)».' : 'El cobro se termina de registrar solo al volver la conexión.') + ' Si hay que anularla, hágalo con nota de crédito cuando aparezca en la caja.', 'err');
      if (this.reintentando) return toast('Se están emitiendo las ventas pendientes: intente de nuevo en unos segundos', 'err');
      if (!confirm('¿Descartar la venta pendiente de ' + money(v.total) + '? No se emitirá ningún comprobante y se quitará de la caja.')) return;
      const clave = this.claveCola();
      const quitar = () => {
        let l; try { l = JSON.parse(localStorage.getItem(clave) || '[]'); } catch { l = []; }
        const a = l.find(x => x.id === v.id); if (!a || a.doc) return false;
        this.quitarDeCola(clave, v.id);
        mock.actualizar('pos_ventas', l2 => (l2 || []).filter(x => x.pendiente_id !== v.id), []);
        return true;
      };
      let hecho;
      if (navigator.locks) hecho = await navigator.locks.request('facturacr:cola:' + (store.empresa ? store.empresa.id : 0), { ifAvailable: true }, l => (l ? quitar() : null));   // no mientras otra pestaña la emite
      else hecho = quitar();
      if (hecho === null) toast('Otra pestaña está emitiendo las ventas pendientes: intente de nuevo en unos segundos', 'err');
      else if (!hecho) { this.cargarCola(); toast('Esa venta ya se emitió: no se descartó', 'err'); }
    },
    // ---- promociones y combos (3.23) ----
    aplicarPromos(forzar) {
      const activas = this.promosActivas.filter(p => p.tipo !== 'combo');
      /* 4.31: el 2x1 se calcula sobre la cantidad de todas las líneas que antes iban juntas en una (mismo producto, sin nota ni precio a mano, */
      /* sin enviar o enviadas en la misma comanda): el mismo producto agregado a una cuenta ya guardada va en una línea aparte y no pierde la promoción */
      /* 4.31 (cuarta vuelta): no se tocan el descuento que puso el cajero, el combo, el cupón o los puntos (también los de un pedido en línea), un */
      /* descuento por monto que no es de una promoción ni lo que queda de una línea partida (`de`: conserva el 2x1 con que se partió, salvo que el */
      /* cajero le cambie la cantidad: `forzar`). El descuento de la promoción sale siempre de la cantidad de ahora: sin promoción no queda ninguno */
      /* (antes quedaba el monto de cuando tenía más cantidad y la línea salía gratis). 4.31 (quinta vuelta): tampoco la línea que formaba el par */
      /* del 2x1 con otra que ya se cobró aparte («cobrar ahora solo esos»: `promo_fija`), salvo que el cajero le cambie la cantidad */
      /* 4.31 (sexta vuelta): con «+», «−» o la casilla la marca no se pierde: se guarda aparte (la cantidad que tenía al marcarse, su porcentaje */
      /* y su promoción) y, si la cantidad vuelve a esa, vuelve la marca con el 2x1 del par ya cobrado */
      if (forzar && forzar.promo_fija) { forzar.promo_fija_de = { cantidad: forzar.promo_fija === true ? null : +forzar.promo_fija, descuento_pct: +forzar.descuento_pct || 0, promo: forzar.promo || '' }; delete forzar.promo_fija; }
      else if (forzar && forzar.promo_fija_de && +forzar.promo_fija_de.cantidad === +forzar.cantidad) { const m = forzar.promo_fija_de; delete forzar.promo_fija_de; Object.assign(forzar, { promo_fija: m.cantidad, descuento_pct: m.descuento_pct, promo: m.promo }); forzar.descuento = r2(this.descuentoDe({ ...forzar, descuento: 0 })); }
      const ajena = l => !!l.descuento_manual || !!l.combo || /^(Cupón |Puntos$)/.test(String(l.promo || '')) || (!(+l.descuento_pct) && +l.descuento > 0 && !l.promo) || (l !== forzar && typeof l.de === 'string' && l.de !== '') || !!l.promo_fija;
      const junta = l => l.producto_id !== null && l.producto_id !== undefined && !ajena(l) && !l.precio_manual && !l.nota, grupo = l => String(l.producto_id) + '|' + String(l.enviado || ''), juntas = {};
      for (const l of this.lineas) if (junta(l)) juntas[grupo(l)] = (juntas[grupo(l)] || 0) + (+l.cantidad || 0);
      for (const l of this.lineas) {
        if (ajena(l)) continue;
        const p = activas.find(x => !(x.productos || []).length || (x.productos || []).map(Number).includes(+l.producto_id));
        let pct = 0, nombre = '';
        if (p && p.tipo === 'descuento' && +p.pct) { pct = +p.pct; nombre = p.nombre; }
        else if (p && p.tipo === '2x1') { const c = junta(l) ? juntas[grupo(l)] : +l.cantidad || 0; pct = c >= 2 ? r2(Math.floor(c / 2) / c * 100) : 0; nombre = c >= 2 ? p.nombre : ''; }
        const desc = r2(this.descuentoDe({ ...l, descuento_pct: pct, descuento: 0 }));
        if (pct !== (+l.descuento_pct || 0) || nombre !== (l.promo || '') || desc !== (+l.descuento || 0)) { l.descuento_pct = pct; l.descuento = desc; l.promo = nombre; }
      }
    },
    agregarCombo(p) {
      const items = (p.combo.items || []).map(i => ({ p: this.productos.find(x => x.id === +i.producto_id), cantidad: +i.cantidad || 1 })).filter(i => i.p);
      if (!items.length) return toast('El combo no tiene productos disponibles', 'err');
      const normal = items.reduce((s, i) => s + i.cantidad * precioPara(i.p, this.clienteId) * (1 + (+i.p.tarifa || 0) / 100), 0), factor = normal > 0 ? Math.min(1, (+p.combo.precio || 0) / normal) : 1;
      for (const i of items) this.lineas.push({ producto_id: i.p.id, detalle: i.p.nombre + ' · ' + p.nombre, cabys: i.p.cabys, cantidad: i.cantidad, precio_unitario: r2(precioPara(i.p, this.clienteId) * factor), descuento: 0, descuento_pct: 0, codigo_tarifa: i.p.codigo_tarifa, tarifa: +i.p.tarifa || 0, es_servicio: i.p.es_servicio, unidad_medida: i.p.unidad_medida, precio_manual: true, nota: '', enviado: null, ronda: 0, combo: p.nombre });
      this.$nextTick(() => { const el = this.$refs.carrito; if (el) el.scrollTop = el.scrollHeight; });
    },
    // ---- pedidos para llevar y a domicilio (3.23): una cuenta en espera con datos de entrega y estado ----
    // 4.6 (FISITAAP): el botón «Para llevar / Express» se toca ANTES de cargar los platos: se elige el cliente (por nombre o teléfono)
    // y su dirección (casa, trabajo…) y la cuenta queda abierta para agregar los productos y enviar la comanda. Con platos ya cargados
    // (botón «Pedido») registra el pedido como antes.
    abrirPedido() {
      const c = this.clienteReal, c0 = this.cuentaActual, prev = c0 && c0.pedido ? c0 : null, dirs = this.direccionesDe(c), dirPrev = prev ? String(prev.direccion || '') : '';
      const sel = dirs.some(d => d.detalle === dirPrev) ? dirPrev : (dirPrev ? '' : (dirs[0] ? dirs[0].detalle : ''));
      this.pedido = { tipo: prev ? prev.pedido : 'llevar', nombre: prev ? prev.nombre : (this.nombreEspera || (c ? c.nombre : '')), telefono: prev && prev.telefono ? prev.telefono : (c ? String(c.celular || c.telefono || '') : ''),
        direccion: dirPrev || sel, direccion_sel: sel, direccion_nombre: '', guardar_dir: true, hora_entrega: prev ? prev.hora_entrega || '' : '', nota: prev ? prev.nota || '' : '', seguir: !this.lineas.length, q: '' };
    },
    direccionesDe(c) { if (!c) return []; try { const l = typeof c.direcciones === 'string' ? JSON.parse(c.direcciones || '[]') : (c.direcciones || []); return Array.isArray(l) ? l.filter(d => d && d.detalle) : []; } catch { return []; } },
    elegirDireccion() { const p = this.pedido; if (p) p.direccion = p.direccion_sel || ''; },
    elegirClientePedido(c) { this.elegirCliente(c); const p = this.pedido; if (!p) return; p.q = ''; if (c) { p.nombre = c.nombre; p.telefono = String(c.celular || c.telefono || ''); const dirs = this.direccionesDe(c); p.direccion_sel = dirs[0] ? dirs[0].detalle : ''; p.direccion = p.direccion_sel; } },
    nuevoClientePedido() { this.qCliente = (this.pedido && this.pedido.q) || ''; this.abrirNuevoCliente(); },
    async confirmarPedido() {
      const p = this.pedido; if (!(p.nombre || '').trim()) return toast('Escriba el nombre del cliente', 'err');
      const dir = p.tipo === 'domicilio' ? (p.direccion || '').trim() : '';   // para llevar no lleva dirección de entrega
      if (p.tipo === 'domicilio' && !dir) return toast('Indique la dirección de entrega', 'err');
      if (!mock.puedeGuardar()) return;
      // 4.6: la dirección nueva queda en la ficha del cliente (casa, trabajo…) para la próxima vez
      const c = this.clienteReal;
      if (c && dir && p.guardar_dir && !this.direccionesDe(c).some(d => String(d.detalle).trim().toLowerCase() === dir.toLowerCase())) {
        try { const cc = await api('/api/clientes/' + c.id + '/direcciones', { method: 'POST', body: { nombre: (p.direccion_nombre || '').trim() || (p.tipo === 'domicilio' ? 'Entrega' : 'Otra'), detalle: dir } }); store.poner('clientes', cc); }
        catch (e) { toast('La dirección no se guardó en el cliente: ' + e.message, 'err'); }
      }
      // en restaurante la comanda sale a cocina (y a la pantalla de cocina) antes de guardar el pedido; si la cuenta ya estaba en espera se actualiza
      if (this.esRestaurante && this.lineas.some(l => !l.enviado)) { try { this.enviarComanda(); } catch {} }
      let id = this.esperaId;
      const nueva = !id;
      if (id) this.persistirCuenta(); else { const copias = this.lineas.map(x => ({ ...x })); id = this.nuevaCuentaEspera(p.nombre.trim(), copias, null); copias.forEach((x, i) => { if (this.lineas[i]) this.lineas[i].lid = x.lid; }); }   /* 4.31: la pantalla sigue con los lid de la cuenta creada */
      this.actualizarCuenta(id, x => ({ ...x, nombre: p.nombre.trim(), pedido: p.tipo, telefono: (p.telefono || '').trim(), direccion: dir, hora_entrega: p.hora_entrega || '', nota: p.nota || x.nota, estado: x.estado && x.estado !== 'entregado' ? x.estado : 'recibido', cliente_id: this.clienteId || null }));
      this.pedido = null;
      if (p.seguir) {   // 4.6: se abrió antes de cargar los platos: la cuenta sigue en pantalla para agregarlos y enviar la comanda
        if (nueva) this.tomarBase(this.espera.find(x => x.id === id), false);   /* 4.31: lo guardado de la cuenta recién creada */
        this.esperaId = id; this.nombreEspera = p.nombre.trim(); if (p.nota) this.nota = p.nota; this.mesaActual = null; this.rapida = false;
        toast((p.tipo === 'domicilio' ? '🛵 Express de ' : '🥡 Para llevar de ') + p.nombre.trim() + ': agregue los platos y envíe la comanda', 'ok');
        this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus()); return;
      }
      this.lineas = []; this.esperaId = null; this.nombreEspera = ''; this.nota = ''; this.idem = uuid(); this.mesaActual = null; this.modalEspera = true;
      toast('Pedido ' + (p.tipo === 'domicilio' ? 'a domicilio' : 'para llevar') + ' de ' + p.nombre.trim() + ' registrado', 'ok');
    },
    avanzarPedido(v) { const e = siguienteEstadoPedido(v.estado || 'recibido'); if (!e) return; this.actualizarCuenta(v.id, x => ({ ...x, estado: e, ['hora_' + e]: new Date().toISOString() })); },
    textoSiguiente(v) { const e = siguienteEstadoPedido(v.estado || 'recibido'); return e === 'en_cocina' ? 'A cocina' : e === 'listo' ? 'Listo' : e === 'entregado' ? 'Entregado' : ''; },
    waPedido(v) { const tel = String(v.telefono || '').replace(/\D/g, ''); const n = tel.length === 8 ? '506' + tel : tel; return 'https://wa.me/' + n + '?text=' + encodeURIComponent('Hola ' + v.nombre + ', su pedido en ' + (store.empresa?.nombre_comercial || store.empresa?.nombre || 'nuestro local') + ' está listo' + (v.pedido === 'domicilio' ? ' y va en camino' : ' para recoger') + '. Total: ' + money(v.total) + '.'); },
    nombreEstadoPedido,
    // ---- fiado y abonos (3.23): la venta se emite a crédito al cliente y los abonos se reciben en la caja ----
    async saldoFiado(cid) { const docs = await api('/api/comprobantes' + (cid != null ? '?cliente_id=' + encodeURIComponent(cid) + '&con_saldo=1' : '')); return docs.filter(d => d.cliente_id === cid && ['01', '02', '04', '09'].includes(d.tipo_documento) && d.estado !== 'rechazado' && ['02', '08', '10'].includes(d.condicion_venta || '01')).map(d => ({ ...d, saldo: r2((+d.total || 0) - (+d.pagado || 0) - (+d.acreditado || 0)), vencido: !!(d.fecha_vencimiento && String(d.fecha_vencimiento).slice(0, 10) < hoy()) })).filter(d => d.saldo > 0.005); },   // 3.87: el servidor filtra el cliente y lo que tiene saldo (antes bajaba todos los comprobantes); 4.9: lo que debe con las reglas del servidor (main.py, fiado de la caja) y del crédito de la revendedora: 01/02/04/09 en condición de crédito 02/08/10 (antes cualquier condición distinta de 01: la caja bloqueaba un fiado que el servidor y la página aceptaban, y dejaba pasar uno que el servidor rechazaba)
    async abrirFiados() { if (!(await this.cobroPermitido('recibir abonos'))) return; this.fiado = { q: '', cliente: this.cliente || null, docs: [], cargando: false, abono: null }; if (this.fiado.cliente) this.cargarFiados(); },
    async cargarFiados() { const f = this.fiado; if (!f || !f.cliente) return; f.cargando = true; try { f.docs = await this.saldoFiado(f.cliente.id); } catch (e) { toast(e.message, 'err'); f.docs = []; } f.cargando = false; },
    elegirFiado(c) { this.fiado.cliente = c; this.fiado.q = ''; this.cargarFiados(); },
    clientesFiado() { const q = (this.fiado.q || '').trim().toLowerCase(); if (q.length < 2) return []; return (store.clientes || []).filter(c => c.activo !== false && c.tipo !== 'Proveedor' && (c.nombre.toLowerCase().includes(q) || String(c.numero_id || '').includes(q))).slice(0, 8); },
    totalFiado() { return r2((this.fiado && this.fiado.docs || []).reduce((s, d) => s + d.saldo, 0)); },
    async abonar() {
      const f = this.fiado, a = f.abono; if (!a) return;
      const monto = r2(+a.monto || 0); if (monto <= 0) return toast('Indique el monto del abono', 'err');
      if (monto > a.doc.saldo + 0.005) return toast('El abono supera el saldo de ' + money(a.doc.saldo), 'err');
      const cuenta = this.cuentaPara(a.medio); if (!cuenta) return toast('Sin cuenta para ' + nombreMedio(a.medio) + ' en la configuración de la caja', 'err');
      if (!mock.puedeGuardar()) return;
      this.cobrando = true;
      try {
        const p = await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: f.cliente.id, detalles: 'Abono a ' + a.doc.consecutivo.slice(-10) + ' (fiado) · caja ' + this.cfg.nombre, fecha: hoy(), cuenta, condicion_venta: '01', medio_pago: a.medio, moneda: 'CRC', tipo_cambio: 1, monto, notas: this.cfg.nombre, facturas: [{ id: a.doc.id, monto }] } });
        if (this.caja) registrarVentaEnCaja(this.caja.id, { abono: true, tipo: 'abono', doc_id: a.doc.id, consecutivo: 'ABONO ' + a.doc.consecutivo.slice(-10), total: monto, medios: [{ medio: a.medio, monto }], cliente: f.cliente.nombre, hora: new Date().toISOString(), usuario: sesion.usuario?.correo, recibo: p.numero || null });
        if (this.caja) this.caja = cajaPorId(this.caja.id);
        toast('Abono de ' + money(monto) + ' recibido' + (p.numero ? ' (' + p.numero + ')' : ''), 'ok'); f.abono = null; await this.cargarFiados();
      } catch (e) { toast('No se registró el abono: ' + e.message, 'err'); }
      this.cobrando = false;
    },
    // ---- turnos (3.23): cambio de cajero sin cerrar la caja, con arqueo parcial ----
    async abrirTurno() {
      const dueno = this.duenoCaja;   // 4.6: el turno lo entrega quien lo tiene; otro usuario solo con la clave de supervisor (si no, cualquiera se quedaba con la caja)
      if (dueno && dueno !== usuarioActual()) { if (!this.cfg.clave_supervisor) return toast('El turno de «' + this.caja.caja + '» lo entrega ' + dueno + '. Para entregarlo en su lugar configure la clave de supervisor de la caja.', 'err'); if (!(await this.autorizar('Entregar el turno de ' + dueno))) return; }
      const t = this.turnoActual; this.turno = { conteo: null, nota: '', esperado: this.resumenCaja ? this.resumenCaja.efectivo_esperado : 0, ventas: t ? t.ventas : 0, total: t ? t.total : 0, desde: t ? t.desde : null }; },
    confirmarTurno() {
      const t = this.turno; if (t.conteo === null || t.conteo === '') return toast('Cuente el efectivo de la gaveta antes de entregar el turno', 'err');
      if (!mock.puedeGuardar()) return;
      const fin = new Date().toISOString(), conteo = r2(t.conteo), dif = r2(conteo - t.esperado);
      const dueno = this.duenoCaja, yo = sesion.usuario?.correo || sesion.usuario?.nombre || '';
      registrarTurno(this.caja.id, { usuario: dueno || yo, ...(dueno && dueno !== yo ? { entregado_por: yo } : {}), inicio: t.desde, fin, ventas: t.ventas, total: t.total, esperado: t.esperado, conteo, diferencia: dif, nota: t.nota || '' });
      this.caja = cajaPorId(this.caja.id); this.turno = null;
      /* 4.41: con la opción de la caja «el cajero ve el corte», al entregar el turno también ve la diferencia */
      if (!this.verMontosCaja && !opcionesCierre(this.caja).corte) return toast('Turno entregado con ' + money(conteo) + ' contados. La diferencia la revisa la administración. El siguiente cajero entra con su usuario desde Mi perfil.', 'ok');   // 4.2: a ciegas no se revela la diferencia (la caja sigue abierta); queda en el turno para quien ve resultados
      toast('Turno entregado: ' + money(conteo) + ' contados' + (Math.abs(dif) > 0.005 ? ' (diferencia ' + money(dif) + ')' : ' (cuadra)') + '. El siguiente cajero entra con su usuario desde Mi perfil.', Math.abs(dif) > 0.005 ? 'err' : 'ok');
    },
    // porciones que alcanzan con los insumos de la bodega (3.22): el ingrediente más escaso manda
    async cargarPorciones() { try { this.porciones = await api('/api/inventario/recetas/porciones' + (this.cfg && this.cfg.bodega_id ? '?bodega_id=' + this.cfg.bodega_id : '')); } catch { this.porciones = {}; } },
    // anular o devolver una venta desde la caja (3.22): nota de crédito si Hacienda ya la aceptó, anulación si nunca llegó; el dinero
    // sale de las cuentas donde entró y la venta queda fuera del cierre
    async anularVenta(v) {
      if (!(await this.cobroPermitido('anular o devolver ventas'))) return;   // 4.6
      if (v.tipo === 'hab') return toast('Un cargo a habitación se quita desde la cuenta del huésped en Recepción', 'err');
      if (!v.doc_id) return toast('Esta venta no tiene comprobante que anular', 'err');
      if (this.cfg.clave_anular && !(await this.autorizar('Anular la venta ' + v.consecutivo))) return;
      const motivo = prompt('Motivo de la anulación o devolución de ' + v.consecutivo, 'Devolución del cliente'); if (motivo === null) return;
      if (motivo.trim().length < 3) return toast('Escriba el motivo', 'err');
      if (!confirm('¿Anular la venta ' + v.consecutivo + ' por ' + money(v.total) + '? Si Hacienda ya la aceptó se emite una nota de crédito; el dinero se registra como devuelto.')) return;
      this.cobrando = true;
      try {
        const d = await api('/api/comprobantes/' + v.doc_id); let nc = null;
        if (d.estado === 'aceptado') {
          nc = await api('/api/comprobantes', { method: 'POST', headers: this.cabSucursal(), body: { tipo_documento: '03', cliente_id: d.cliente_id || null, condicion_venta: '01', medio_pago: v.medios && v.medios[0] && v.medios[0].medio !== 'hab' ? v.medios[0].medio : '01', moneda: d.moneda || 'CRC', tipo_cambio: d.tipo_cambio || 1, bodega_id: this.cfg.bodega_id || null,
            lineas: (d.lineas || []).map(l => ({ producto_id: l.producto_id || null, detalle: l.detalle, cabys: l.cabys || null, cantidad: l.cantidad, precio_unitario: l.precio_unitario, descuento: l.descuento || 0, codigo_tarifa: l.codigo_tarifa, tarifa: l.tarifa, es_servicio: l.es_servicio ?? false, unidad_medida: l.unidad_medida || 'Unid' })),
            referencia_clave: d.clave, referencia_fecha: d.fecha_emision, referencia_codigo: '01', referencia_razon: motivo.trim(), observaciones: 'Anulación desde la caja · ' + v.consecutivo, otros_cargos: d.otros_cargos || [], idempotencia: uuid() } });
          if (this.cfg.enviar_hacienda !== false && nc.estado === 'firmado') { try { await api('/api/comprobantes/' + nc.id + '/enviar', { method: 'POST' }); } catch (e) { toast('Nota de crédito firmada; queda en cola para Hacienda (' + e.message + ')', 'err'); } }   // 4.5: solo la firmada se envía (como en cobrar); la interna o sin firma no
        } else if (['generado', 'interno', 'error'].includes(d.estado)) {
          await api('/api/comprobantes/' + d.id + '/anular', { method: 'POST' });
        } else if (d.estado !== 'rechazado') { this.cobrando = false; return toast('El comprobante está «' + d.estado + '»: espere la respuesta de Hacienda para anularlo con nota de crédito', 'err'); }
        const rechazado = d.estado === 'rechazado';   // 4.15: Hacienda lo rechazó: no hay nada que anular allá y su cobro ya salió de Bancos en el servidor
        const avisos = [];
        for (const m of (rechazado ? [] : (v.medios || []))) {
          const cuenta = m.medio === 'hab' ? '' : (this.cfg.cuentas || {})[m.medio]; if (!cuenta || !(+m.monto > 0)) continue;
          try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta, monto: -(+m.monto), fecha: hoy(), descripcion: 'Devolución venta ' + v.consecutivo + ' · ' + motivo.trim(), ref: 'pos:anula:' + v.consecutivo + ':' + m.medio } }); } catch (e) { avisos.push(e.message); }
        }
        const po = v.prepago_online;   // 4.9: lo pagado en línea (SINPE o Tilopay) que entró a Bancos al cobrar sale también, con su propia ref (no choca con la del medio)
        if (po && po.cuenta && +po.monto > 0) { try { await api('/api/bancos/movimientos', { method: 'POST', body: { cuenta: po.cuenta, monto: -(+po.monto), fecha: hoy(), descripcion: 'Devolución venta ' + v.consecutivo + ' (pago en línea ' + nombreMedio(po.medio) + ') · ' + motivo.trim(), ref: 'pos:anula:' + v.consecutivo + ':online' } }); } catch (e) { avisos.push(e.message); } }
        mock.actualizar('pos_ventas', l => (l || []).map(x => (x.id === v.id ? { ...x, anulada: true, anulada_hora: new Date().toISOString(), anulada_por: sesion.usuario?.correo, motivo_anulacion: motivo.trim(), nc_id: nc ? nc.id : null, nc_consecutivo: nc ? nc.consecutivo : null } : x)), []);
        if (this.caja) this.caja = cajaPorId(this.caja.id);
        toast((nc ? 'Nota de crédito ' + nc.consecutivo + ' emitida: venta anulada' : rechazado ? 'Venta anulada: Hacienda ya la había rechazado y su cobro salió de Bancos' : 'Comprobante anulado') + (avisos.length ? ' · Bancos: ' + avisos.join('; ') : ''), avisos.length ? 'err' : 'ok');
      } catch (e) { toast('No se pudo anular: ' + e.message, 'err'); }
      this.cobrando = false;
    },
    // pedidos en línea (3.47): cada 30 s se consulta si hay pedidos nuevos; al entrar uno suena y se avisa (se confirman en Ventas en línea › Pedidos › Pedidos)
    async revisarOnline() {
      if (!sesion.tieneModulo('pedidos_online')) return;
      try {
        const r = await api('/api/pedidos/resumen');
        if (this._est) this._est.guardarResumen(r);   /* 4.31: el indicio de la estación de comandas */
        if (this.online.ultimo !== null && r.ultimo_id > this.online.ultimo) { toast('Entró un pedido en línea: tóquelo en «🌐 Pedidos web» para verlo.', 'ok'); try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 660; g.gain.value = 0.2; o.start(); o.stop(ac.currentTime + 0.35); } catch {} }
        this.online = { ...this.online, nuevos: r.nuevos, ultimo: r.ultimo_id };   /* 4.32: sin perder sinVer */
        if (this.panelWeb && !this.panelWeb.cargando) this.cargarPanelWeb();   /* 4.32: la ventana «Pedidos web» abierta, al día (sin esperar; no lanza) */
        if (r.ultimo_entrado_id !== undefined && sesion.empresaInfo && sesion.empresaInfo.pedidos_programa) this.avisarEntrados(r);   /* 4.32: sin esperar; no lanza */
        if (r.aviso_web && Array.isArray(r.pagados_en_la_web)) { const vistos = this._avisadosWeb || (this._avisadosWeb = new Set()); const nuevos = r.pagados_en_la_web.filter(n => !vistos.has(n)); nuevos.forEach(n => vistos.add(n)); if (nuevos.length) { toast(r.aviso_web, 'ok'); this.sonarPedido(); if (!this.panelWeb) this.online.sinVer = (+this.online.sinVer || 0) + nuevos.length; } }   /* validación 4.32 (B): pagado con tarjeta que atiende la página web; 4.33: también suma al botón «Pedidos web» */
      } catch {}
    },
    // 4.32 (§4.2): en el programa, un pedido en línea aceptado entra a esta caja (pagado con tarjeta nunca es «nuevo»): cuando sube
    // ultimo_entrado_id se traen las cuentas en espera y se avisa una vez por pedido, con el mismo sonido del pedido nuevo. La primera
    // respuesta solo marca desde dónde avisar. Si la cuenta todavía no llegó, se busca otra vez en las vueltas siguientes (hasta 6).
    async avisarEntrados(r) {
      try {
        const ent = +r.ultimo_entrado_id || 0;
        if (this._entPiso === undefined || this._entPiso === null) { this._entPiso = ent; this._entTope = ent; this._entIntentos = 0; this._entAvisados = this._entAvisados || new Set(); return; }
        if (ent > this._entTope) { this._entTope = ent; this._entIntentos = 0; }
        if (this._entTope <= this._entPiso) return;
        await this.sincronizar();
        const piso = this._entPiso, tope = this._entTope, nuevos = [];
        for (const v of enEspera()) { const id = v && v.canal === 'online' ? +v.pedido_id || 0 : 0; if (id > piso && id <= tope && !this._entAvisados.has(id)) { this._entAvisados.add(id); nuevos.push(v.pedido_numero || id); } }
        for (const n of nuevos) toast('Entró a la caja el pedido en línea #' + n + '.', 'ok');
        if (nuevos.length && !this.panelWeb) this.online.sinVer = (+this.online.sinVer || 0) + nuevos.length;   /* 4.32: el número del botón «Pedidos web» */
        if (nuevos.length) this.sonarPedido();
        /* 4.39 (duodécima vuelta): el piso sube cuando la cuenta del tope está en la lista traída (como antes): el pedido aceptado aquí ya figura como avisado */
        /* antes de llegar, y si el piso subía con la lista atrasada, otro pedido que entró en esos segundos se quedaba sin aviso. La primera respuesta no */
        /* olvida lo aceptado aquí */
        if (enEspera().some(v => v && v.canal === 'online' && +v.pedido_id === tope) || ++this._entIntentos >= 6) this._entPiso = tope;
      } catch {}
    },
    sonarPedido() { try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 660; g.gain.value = 0.2; o.start(); o.stop(ac.currentTime + 0.35); } catch {} },   /* 4.32: el mismo sonido del pedido nuevo */
    // 3.87: caja sin bodega propia → la de su sucursal (la de la caja o la activa) y, si no tiene, la principal (antes siempre la principal: la sucursal 002 rebajaba la Principal)
    bodegaDefecto() { const sid = (this.cfg && this.cfg.sucursal_id) || sesion.sucursal_id, suc = (sesion.sucursales || []).find(x => x.id === sid), b = suc && suc.bodega_id && this.bodegas.find(x => x.id === suc.bodega_id && x.activa !== false); return (b || this.bodegas.find(x => x.principal) || this.bodegas[0])?.id || null; },
    async cargarExistencias() { this.cargarPorciones(); if (!this.cfg || !this.cfg.bodega_id) { this.existenciasOk = false; return; } try { const l = await api('/api/inventario/existencias?bodega_id=' + this.cfg.bodega_id); const m = {}; for (const e of l) m[e.producto_id] = e.cantidad; this.existencias = m; this.existenciasOk = true; } catch { this.existenciasOk = false; } },
    tecla(e) {
      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }   /* 4.39 (tercera vuelta): con la ventana de la habitación abierta no se cobra, no se manda comanda ni se guarda por debajo (se cobraba o se cargaba dos veces) */
      /* 4.39 (decimocuarta vuelta): con el cursor en una casilla numérica, F9, F8 y F4 la dejan primero (corre su cambio: el 0 quita el plato o pide la clave) y, si */
      /* tenía 0 o queda un plato en 0, no siguen en esa pulsación: antes se guardaba o se cobraba con el plato en 0 (la cuenta lo conservaba, o salía sin la clave) */
      /* 4.39 (decimoquinta vuelta): el valor propio solo frena si es la casilla de la cantidad (con el precio a mano en 0, la tecla pedía dos pulsaciones) */
      if (['F9', 'F8', 'F4'].includes(e.key) && !this.pago && e.target && e.target.type === 'number' && typeof e.target.blur === 'function') { const v = e.target.value, cant = typeof e.target.closest !== 'function' || !!e.target.closest('.pos-linea .c'); e.target.blur(); if ((cant && !(+v > 0)) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; } }
      if (e.key === 'F9') { e.preventDefault(); if (this.pago) this.cobrar(); else if (this.vista === 'venta' && !this.dividir) this.abrirPago(); }   /* 4.39 (quinta vuelta): con «Dividir» abierto, F9 no abre el cobro completo debajo */
      else if (e.key === 'F10' && this.pago) { e.preventDefault(); this.cobrarOtro(); }   /* 4.29 (K-3, K-5): solo con la ventana de cobro abierta */
      else if (e.key === 'F7' && this.pago) { e.preventDefault(); if (!this.cobrando) this.cerrarPago(); }   /* 4.29 (K-5): como Cancelar y Esc */
      else if (e.key === 'F2') { e.preventDefault(); this.$refs.buscar && this.$refs.buscar.focus(); }
      else if (e.key === 'F8') { e.preventDefault(); if (this.esRestaurante && this.vista === 'venta' && !this.pago) this.enviarComanda(); }
      else if (e.key === 'F4') { e.preventDefault(); if (this.pago || this.cobrando) return; if (this.esRestaurante && this.vista === 'venta') this.guardarCuenta(); else this.modalEspera = true; }   /* 4.38: con la ventana de cobro abierta o cobrando no hace nada (como F8) */
      else if (e.key === 'Escape') { if (this.pago) { if (!this.cobrando) this.cerrarPago(); } else if (this.nuevoCliente) this.nuevoCliente = null; else if (this.pedido) this.pedido = null; else if (this.panelWeb) this.atrasWeb(); else if (this.modSel) this.modSel = null; else if (this.lineaNota) this.lineaNota = null; else if (this.modalEspera) this.modalEspera = false; else if (this.mover) this.mover = null; else if (this.unir) this.unir = null; else if (this.elegirCuenta) this.elegirCuenta = null; }
    },
  },
  async created() {
    /* 4.29: la suscripción va antes de la primera espera: la caja sigue los ids desde que se ve, y beforeUnmount (que corre después) la quita siempre */
    this._ids = mock.alCambiarIds ? mock.alCambiarIds((k, c) => this.seguirIds(k, c)) : null;   /* 4.29: la cuenta que el servidor guardó con otro id */
    try { this.bodegas = await api('/api/inventario/bodegas'); if (this.cfg && !this.cfg.bodega_id) this.cfg.bodega_id = this.bodegaDefecto(); } catch {}
    try { this.cuentas = await cuentasParaMovimientos(); } catch {}
    if (this.sinConfigurar) this.abrirGuia();   // primera venta guiada (3.21)
    try { const z = +localStorage.getItem('pos:zoom:' + (this.cfg ? this.cfg.id : 0)); if (z >= 1 && z <= 3 && window.innerWidth > 640) this.zoom = z; } catch {}   // zoom del plano (3.46); en celular siempre encuadrado
    this.cargarExistencias();
    if (sesion.empresaInfo?.es_local) cargarEquipo().catch(() => {});   // 4.25: la impresión de esta computadora (solo en el programa)
    this._tecla = e => this.tecla(e); window.addEventListener('keydown', this._tecla);
    this._reloj = setInterval(() => { this.reloj = Date.now(); }, 30000);
    if (this.cfg && this.cfg.pedir_apertura && !this.caja) this.abrirApertura();
    this.revisarOnline(); this._online = setInterval(() => this.revisarOnline(), sesion.empresaInfo && sesion.empresaInfo.pedidos_programa ? 10000 : 30000);   /* 4.32 (§4.2): en el programa que atiende los pedidos en línea, cada 10 s */
    this._sync = setInterval(() => this.sincronizar(), 15000); this._vis =() => { if (!document.hidden) this.sincronizar(); }; document.addEventListener('visibilitychange', this._vis);   // 4.6: cuentas, cajas y extras de otros equipos
    this.cargarCola(); this.reponerPendientes(); this._volvio = () => setTimeout(() => this.reintentarPendientes(), 1500); window.addEventListener('online', this._volvio);
    this._cola = setInterval(() => { if (this.cola.length && red.enLinea) this.reintentarPendientes(); }, 30000);
    if (this.cola.length) setTimeout(() => this.reintentarPendientes(), 2000);
    import('./_estacion.js').then(E => { if (this._fuera) return; this._est = E; E.iniciarEstacion('caja'); }).catch(() => {});   /* 4.31: estación de comandas (se carga al abrir la caja: si no carga, la caja sigue como antes) */
  },
  mounted() { this.$nextTick(() => this.$refs.buscar && this.$refs.buscar.focus()); if (this.clienteId) this.cargarExos(); },
  beforeUnmount() { this._fuera = true; if (this._ids) this._ids(); this._ids = null; window.removeEventListener('keydown', this._tecla); window.removeEventListener('online', this._volvio); clearInterval(this._reloj); clearInterval(this._online); clearInterval(this._cola); clearInterval(this._sync); document.removeEventListener('visibilitychange', this._vis); if (this._est) this._est.pararEstacion('caja'); },
  template: `
  <div class="page pos-page">
    <div class="alert" :class="red.enLinea ? 'warn' : 'danger'" v-if="!red.enLinea || cola.length" style="margin-bottom:8px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <span v-if="!red.enLinea"><b>Sin conexión con el servidor.</b> <template v-if="sesion.electronica">No se pueden emitir comprobantes hasta que regrese la conexión. Para vender sin internet use el programa FISITAAP Local.</template><template v-else>La caja sigue vendiendo de contado: cada venta se guarda aquí y se emite sola al volver la red.</template></span>
      <span v-else><b>{{cola.length}} venta(s) en espera</b> de emitirse.</span>
      <span v-if="red.enLinea && cola.length" class="small">Se reintentan solas cada 30 segundos.</span>
      <button class="btn sm ghost" style="margin-left:auto" @click="verCola=true" v-if="cola.length">Ver pendientes ({{cola.length}})</button>
      <button class="btn sm" @click="reintentarPendientes(true)" :disabled="reintentando" v-if="cola.length">{{reintentando ? 'Emitiendo…' : 'Reintentar ahora'}}</button>
    </div>
    <Modal v-if="verCola" title="Ventas pendientes de emitir" @close="verCola=false" size="lg">
      <p class="small muted" style="margin:0 0 8px">Se cobraron sin conexión. Al volver la red se emiten en orden con su tiquete electrónico; el cliente recibió un comprobante provisional.</p>
      <table class="tabla"><thead><tr><th>Hora</th><th>Cliente</th><th>Total</th><th>Medios</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="v in cola" :key="v.id"><td class="small">{{new Date(v.creado).toLocaleTimeString('es-CR', {hour:'2-digit', minute:'2-digit'})}}</td><td>{{v.cliente_nombre}}<div class="small muted" v-if="v.espera">{{v.espera}}</div></td><td><b>{{money(v.total)}}</b></td><td class="small">{{v.medios.map(m => nombreMedio(m.medio) + ' ' + money(m.monto)).join(', ')}}</td>
          <td class="small" :class="v.error ? 'danger' : 'muted'">{{v.doc ? 'Emitida ' + v.doc.consecutivo.slice(-10) + ' · ' + (v.error || 'cobro pendiente') : (v.error ? 'Rechazada: ' + v.error : 'Esperando conexión')}}</td>
          <td class="acts"><button class="btn sm ghost" @click="imprimirProvisional(v)">Reimprimir</button><button v-if="!v.doc" class="btn sm ghost" @click="descartarPendiente(v)">Descartar</button><button v-if="v.doc && v.error" class="btn sm ghost" @click="entregarPendiente(v)">Quitar (cobrar en Pagos recibidos)</button></td></tr></tbody></table>
      <template #foot><button class="btn ghost" @click="verCola=false">Cerrar</button><button class="btn" @click="reintentarPendientes(true)" :disabled="reintentando">Reintentar ahora</button></template>
    </Modal>
    <Modal v-if="guia" title="Primera venta: tres pasos" @close="guia=null">
      <div class="pasos" style="grid-template-columns:repeat(3,1fr)"><div :class="{on: guia.paso>=1}">1 Nombre</div><div :class="{on: guia.paso>=2}">2 Efectivo</div><div :class="{on: guia.paso>=3}">3 Mostrador o mesas</div></div>
      <template v-if="guia.paso===1"><Field label="Nombre de la caja" req help="Sale en el tiquete y en los cierres"><input v-model="guia.nombre" maxlength="40" placeholder="Caja 1, Restaurante, Soda…"></Field></template>
      <template v-else-if="guia.paso===2"><Field label="Cuenta donde entra el efectivo" req help="Una caja o cuenta de Bancos en colones; tarjeta, SINPE y transferencia entran a la cuenta principal"><Buscador v-model="guia.cuenta" :opciones="cuentas" valor="nombre" detalle="tipo" agregar="cuenta"></Buscador></Field><p class="small muted" v-if="!cuentas.length">No hay cuentas: escriba el nombre y use «+ Agregar cuenta».</p></template>
      <template v-else><Field label="Cómo vende"><select v-model="guia.modo"><option value="mostrador">Venta rápida / mostrador (tienda, soda, spa)</option><option value="restaurante">Restaurante con mesas</option></select></Field><Field label="Cantidad de mesas" v-if="guia.modo==='restaurante'"><input type="number" min="1" max="60" v-model.number="guia.mesas"></Field><Field label="Cobrar el impuesto de servicio 10 %" v-if="guia.modo==='restaurante'"><Toggle v-model="guia.servicio" label="Sí, es un restaurante"></Toggle></Field></template>
      <template #foot><button class="btn ghost" @click="guia=null">Después</button><button class="btn ghost" v-if="guia.paso>1" @click="guia.paso--">Atrás</button><button class="btn" v-if="guia.paso<3" @click="guia.paso++" :disabled="(guia.paso===1 && !guia.nombre.trim()) || (guia.paso===2 && !guia.cuenta)">Siguiente</button><button class="btn" v-else @click="terminarGuia">Listo, a vender</button></template>
    </Modal>
    <div class="card" v-if="!cfg"><h2>Elija la caja de este equipo</h2><p class="muted small">Se recuerda en este navegador; puede cambiarla después desde la barra de la caja.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button v-for="t in terminalesLista" :key="t.id" class="btn sec" @click="usarTerminal(t.id)">{{t.nombre}}<span class="small" v-if="t.modo==='restaurante'"> · restaurante</span></button></div>
    </div>
    <template v-else>
    <!-- plano de mesas (restaurante). 4.6: v-show en vez de v-if: la pantalla de venta (y su cuadrícula de 100 o 200 platos) queda montada
         y abrir una mesa no la vuelve a construir (medido: de 230 ms a unas decenas con CPU lenta) -->
    <!-- 4.27: «Preguntar cada vez»: al entrar a la caja se elige entre el plano de mesas y la venta rápida -->
    <div class="card" v-if="esRestaurante && vista==='elegir'" style="max-width:640px;margin:24px auto;text-align:center">
      <h2 style="margin-bottom:4px">{{cfg.nombre}}</h2><p class="muted" style="margin:0 0 16px">¿Cómo desea vender ahora?</p>
      <div class="grid cols-2" style="gap:12px">
        <button class="btn sec" style="padding:28px 12px;font-size:18px;flex-direction:column;white-space:normal;gap:0;min-width:0;text-align:center" @click="volverAMesas(false)"><span>🍽 Mesas</span><div class="small muted" style="font-weight:normal;margin-top:6px">Abrir el plano del salón y las cuentas de cada mesa</div></button>
        <button class="btn" style="padding:28px 12px;font-size:18px;flex-direction:column;white-space:normal;gap:0;min-width:0;text-align:center" @click="ventaRapida"><span>⚡ Venta rápida</span><div class="small" style="font-weight:normal;margin-top:6px;opacity:.85">Cobrar directo en la caja, sin mesa</div></button>
      </div>
      <div class="row" style="gap:8px;justify-content:center;margin-top:14px" v-if="terminalesLista.length>1 || !caja"><select class="inp" v-if="terminalesLista.length>1" :value="cfg.id" @change="usarTerminal(+$event.target.value)"><option v-for="t in terminalesLista" :key="t.id" :value="t.id">{{t.nombre}}</option></select><button class="btn sm sec" v-if="!caja" @click="abrirApertura">Abrir caja</button></div>
    </div>
    <div v-show="esRestaurante && vista==='mesas'">
      <div class="pos-top" style="margin-bottom:10px">
        <b style="font-size:16px">{{cfg.nombre}}</b>
        <select class="inp" v-if="terminalesLista.length>1" :value="cfg.id" @change="usarTerminal(+$event.target.value)"><option v-for="t in terminalesLista" :key="t.id" :value="t.id">{{t.nombre}}</option></select>
        <span class="small muted" v-if="caja"><a class="enlace-ventas" @click="modalVentas=true" title="Ver o reimprimir los tiquetes de esta caja">{{textoVentas(resumenCaja.ventas)}}<template v-if="verMontosCaja"> · {{money(resumenCaja.total)}}</template></a></span><button class="btn sm sec" v-else @click="abrirApertura">Abrir caja</button>
        <span style="flex:1"></span>
        <button class="btn sm ghost" @click="modalEspera=true" v-if="esperaSinMesa.length">Para llevar en espera ({{esperaSinMesa.length}})</button>
        <span class="seg" title="Cambiar entre el plano de mesas y la venta rápida (sin mesa)"><button :class="{on: enMesas}" @click="volverAMesas(false)">🍽 Mesas</button><button :class="{on: esVentaRapida}" @click="ventaRapida">⚡ Venta rápida</button></span>
<button class="btn sm" :class="avisoWeb ? 'pos-web-nuevo' : 'sec'" v-if="conPedidosWeb" @click="abrirPanelWeb" data-pedidos-web :title="avisoWeb ? 'Entró un pedido en línea: tóquelo para verlo' : 'Ver los pedidos en línea de la página'">🌐 Pedidos web<span class="badge" v-if="avisoWeb" style="margin-left:4px">{{avisoWeb}}</span></button><!-- 4.32 -->
<button class="btn sm ghost" v-if="pedidosActivos.length" @click="modalEspera=true">Pedidos ({{pedidosActivos.length}})</button><button class="btn sm ghost" v-if="caja && cfg.fiado !== false" @click="abrirFiados">Fiados</button><button class="btn sm ghost" v-if="caja" @click="abrirRegalo" title="Vender una tarjeta de regalo">🎁 Tarjeta</button><button class="btn sm ghost" v-if="caja" @click="abrirTurno" title="Cambio de cajero sin cerrar la caja">Turno</button><button class="btn sm ghost" v-if="caja" @click="modalVentas=true" title="Ventas de esta caja: ver, reimprimir, anular o devolver">🧾 Ventas</button><button class="btn sm ghost" v-if="caja" @click="nuevaEntrada" title="Entrada de efectivo a la gaveta">+ Entrada</button><button class="btn sm ghost" v-if="caja" @click="nuevaSalida" title="Salida de efectivo: retiro, depósito al banco o pago a un proveedor">− Salida</button><a class="btn sm ghost" v-if="caja" :href="'#/pos/cierres?cerrar=' + caja.id" title="Cierre de caja">Cerrar caja</a><a class="btn sm ghost" href="#/pos/cierres">Cierres</a><a class="btn sm ghost" href="#/pos/configuracion" title="Configuración del punto de venta" v-if="sesion.puede('configurar')">⚙</a>
      </div>
      <div class="alert info" v-if="enPruebas" style="margin-bottom:10px;padding:6px 10px">Ambiente de pruebas de Hacienda: los tiquetes no son válidos y las ventas no rebajan existencias. Al pasar a producción todo se mueve normal.</div>
      <div class="pos-sectores" v-if="mesas.length">
        <template v-if="sectores.length"><button class="pos-cat" :class="{on: !sectorFiltro}" @click="sectorFiltro=null">Todo el salón</button><button v-for="s in sectores" :key="s.id" class="pos-cat" :class="{on: sectorFiltro===s.id}" @click="sectorFiltro = sectorFiltro===s.id ? null : s.id">{{s.nombre}}<span class="small" v-if="s.servicio_pct !== null && s.servicio_pct !== undefined && s.servicio_pct !== ''"> · servicio {{s.servicio_pct}} %</span></button></template>
        <span style="flex:1"></span>
        <span class="seg"><button @click="cambiarZoom(-0.25)" title="Alejar">−</button><button @click="zoom=1" :class="{on: zoom===1}" title="Ajustar el plano al ancho de la pantalla">{{Math.round(zoom*100)}} %</button><button @click="cambiarZoom(0.25)" title="Acercar">+</button></span>
      </div>
      <div class="pos-plano-wrap" v-if="mesas.length"><div class="pos-plano" :style="estiloPlano">
        <template v-for="m in estadoMesas" :key="m.id">
          <div v-if="m.deco" class="pos-mesa deco" :class="m.forma" :style="estiloMesa(m)"><span class="n">{{m.forma==='planta' ? '🌿' : m.forma==='puerta' ? '🚪 ' + m.nombre : m.nombre}}</span></div>
          <button v-else class="pos-mesa" :class="[m.forma, m.estado, {tarde: m.tarde, unida: m.unida}]" :style="estiloMesa(m)" @click="abrirMesa(m)" :title="m.cuenta ? 'Abierta hace ' + tiempoTexto(m.min) + (m.com !== null ? ' · última comanda hace ' + tiempoTexto(m.com) : '') + (m.cuentas.length > 1 ? ' · ' + m.cuentas.length + ' cuentas' : '') : (m.asientos ? m.asientos + ' asientos' : '')">
            <span class="u" v-if="m.cuentas.length > 1" :title="m.cuentas.length + ' cuentas en esta mesa'">{{m.cuentas.length}}</span>
            <span class="n">{{m.nombre}}</span><span class="s" v-if="m.cuenta">{{money(m.total)}}<br>{{tiempoTexto(m.min)}} · {{textoEstado(m)}}</span><span class="s" v-else>libre{{m.asientos ? ' · ' + m.asientos + ' 🪑' : ''}}</span>
          </button>
        </template>
      </div></div>
      <div class="card" v-else><Empty icon="🍽" title="Sin mesas" :text="sesion.puede('configurar') ? 'Agregue las mesas del salón y acomódelas en Punto de venta › Configuración (caja en modo restaurante).' : 'Esta caja todavía no tiene mesas: pídale al administrador que las agregue en Punto de venta › Configuración.'"><button class="btn" @click="ventaRapida" data-sin-mesas-venta>⚡ Venta rápida</button><!-- 4.39 --> <a class="btn sec" href="#/pos/configuracion" v-if="sesion.puede('configurar')">Configurar mesas</a></Empty></div>
      <div class="pos-leyenda" v-if="mesas.length"><span><i class="libre"></i>Libre</span><span><i class="ocupada"></i>Ocupada (sin comanda)</span><span><i class="comanda"></i>Comanda enviada</span><span><i class="precuenta"></i>Precuenta pedida</span><span><i class="tarde"></i>Comanda tardía</span><span class="muted">Toque una mesa para abrir su cuenta; una mesa con varias cuentas muestra el número; las mesas unidas comparten la cuenta. Las cuentas quedan guardadas aunque se cierre la sesión.</span></div>
    </div>
    <!-- pantalla de venta -->
    <div class="pos" v-show="!esRestaurante || vista==='venta'">
      <div class="pos-izq">
        <div class="pos-top">
          <span class="seg" v-if="esRestaurante" title="Cambiar entre el plano de mesas y la venta rápida (sin mesa)"><button :class="{on: enMesas}" @click="volverAMesas(false)">🍽 Mesas</button><button :class="{on: esVentaRapida}" @click="ventaRapida">⚡ Venta rápida</button></span>
          <button class="btn sm ghost" v-if="esRestaurante && esVentaRapida && esperaRapida.length" @click="modalEspera=true" data-espera-rapida title="Cuentas guardadas sin mesa: tóquelo para recuperar una y cobrarla">Para llevar en espera ({{esperaRapida.length}})</button><!-- 4.36 -->
          <button class="btn sm" :class="avisoWeb ? 'pos-web-nuevo' : 'sec'" v-if="conPedidosWeb" @click="abrirPanelWeb" data-pedidos-web :title="avisoWeb ? 'Entró un pedido en línea: tóquelo para verlo' : 'Ver los pedidos en línea de la página'">🌐 Pedidos web<span class="badge" v-if="avisoWeb" style="margin-left:4px">{{avisoWeb}}</span></button><!-- 4.32 -->
          <span class="chip on" v-if="mesaActual" :title="mesasUnidas.length ? 'Mesas unidas: ' + mesasUnidas.join(' + ') : ''">🍽 {{nombreEspera || mesaActual.nombre}}<span v-if="mesaActual.sector_id && sectores.find(s => s.id === mesaActual.sector_id)" class="small"> · {{sectores.find(s => s.id === mesaActual.sector_id).nombre}}</span></span><button class="chip" :class="{on: cuentaActual && cuentaActual.pedido}" v-else-if="esRestaurante" @click="abrirPedido" title="Para llevar o Express (a domicilio): elija el cliente y su dirección; luego agregue los platos">{{etiquetaPedido}}</button>
          <span class="chip" v-if="esCredito" style="color:var(--warn);background:var(--warn-soft);border-color:color-mix(in srgb,var(--warn) 22%,var(--line));cursor:default" title="Pedido en línea a crédito: al cobrar se emite como fiado y queda en el estado de cuenta del cliente">📒 A crédito</span><!-- 4.9 -->
          <span class="chip" v-if="partesCuenta" :title="'Cuenta dividida en ' + partesCuenta.total + ' partes iguales'">parte {{(+partesCuenta.cobradas || 0) + 1}} de {{partesCuenta.total}}</span>
          <select class="inp" v-if="esRestaurante && (cfg.saloneros||[]).length" v-model="salonero" title="Salonero que atiende la cuenta" style="max-width:150px"><option value="">Salonero: yo</option><option v-for="s in cfg.saloneros" :key="s" :value="s">{{s}}</option></select>
          <input ref="buscar" class="pos-buscar" v-model="q" placeholder="Buscar por nombre, código o código de barras y Enter (F2)" @keyup.enter="buscarEnter" autocomplete="off">
          <select class="inp" v-if="terminalesLista.length>1 && (!esRestaurante || !mesas.length)" :value="cfg.id" @change="usarTerminal(+$event.target.value)" title="Caja de este equipo"><option v-for="t in terminalesLista" :key="t.id" :value="t.id">{{t.nombre}}</option></select>
          <span class="small muted" v-if="caja">{{caja.caja}} · <a class="enlace-ventas" @click="modalVentas=true" title="Ver o reimprimir los tiquetes de esta caja">{{textoVentas(resumenCaja.ventas)}}<template v-if="verMontosCaja"> · {{money(resumenCaja.total)}}</template></a></span><button class="btn sm sec" v-else @click="abrirApertura">Abrir caja</button><button class="btn sm ghost" v-if="caja && esRestaurante" @click="modalVentas=true" title="Ventas de esta caja: ver, reimprimir, anular o devolver">🧾 Ventas</button>
          <button class="btn sm ghost" v-if="caja" @click="nuevaEntrada" title="Entrada de efectivo a la gaveta (sencillo, fondo adicional, otro ingreso)">+ Entrada</button><button class="btn sm ghost" v-if="caja" @click="nuevaSalida" title="Salida de efectivo: retiro, depósito al banco o pago a un proveedor">− Salida</button>
          <template v-if="caja && !esRestaurante"><button class="btn sm ghost" @click="abrirFiados" title="Abonos de clientes a sus facturas de crédito (cuentas por cobrar y fiados)">Abonos</button><button class="btn sm ghost" @click="abrirRegalo" title="Vender una tarjeta de regalo">🎁 Tarjeta</button><button class="btn sm ghost" @click="abrirTurno" title="Cambio de cajero sin cerrar la caja">Turno</button><button class="btn sm ghost" @click="modalVentas=true" title="Ventas de esta caja: ver, reimprimir, anular o devolver">🧾 Ventas</button></template><!-- 3.87: en mostrador también (antes solo en el plano de mesas) -->
          <template v-if="caja && esRestaurante && !mesas.length"><button class="btn sm ghost" v-if="cfg.fiado !== false" @click="abrirFiados" title="Abonos de clientes a sus fiados">Fiados</button><button class="btn sm ghost" @click="abrirRegalo" title="Vender una tarjeta de regalo">🎁 Tarjeta</button><button class="btn sm ghost" @click="abrirTurno" title="Cambio de cajero sin cerrar la caja">Turno</button></template><!-- 4.39: el restaurante sin mesas no pasa por el plano: aquí también -->
          <a class="btn sm ghost" v-if="caja" :href="'#/pos/cierres?cerrar=' + caja.id" title="Cierre de caja: contar el efectivo y declarar datáfono, SINPE y transferencias">Cerrar caja</a><a class="btn sm ghost" href="#/pos/cierres" title="Cierres de caja">Cierres</a><a class="btn sm ghost" href="#/pos/configuracion" title="Configuración del punto de venta" v-if="sesion.puede('configurar')">⚙</a>
        </div>
        <div class="pos-cats">
          <button class="pos-cat" :class="{on: !catId}" @click="catId=null">Todos</button>
          <button v-for="c in raices" :key="c.id" class="pos-cat" :class="{on: catId===c.id}" @click="catId = catId===c.id ? null : c.id"><img v-if="c.imagen" :src="c.imagen" alt=""><span v-else-if="c.icono">{{c.icono}}</span> {{c.nombre}}</button>
        </div>
        <div class="pos-cats sub" v-if="subcats.length">
          <button class="pos-cat" :class="{on: !subId}" @click="subId=null">Todo {{catActual && !subId ? catActual.nombre : ''}}</button>
          <button v-for="c in subcats" :key="c.id" class="pos-cat" :class="{on: subId===c.id}" @click="subId = subId===c.id ? null : c.id"><span v-if="c.icono">{{c.icono}}</span> {{c.nombre}}</button>
        </div>
        <PosGrid :productos="filtrados" :combos="combosGrid" :cfg="cfg" :existencias="existencias" :existencias-ok="existenciasOk" :porciones="porciones" :cliente-id="clienteId" :version="sync" :vacio="textoVacio" :enlace-crear="!sesion.modoCajero" @agregar="agregar" @combo="agregarCombo"></PosGrid>
      </div>
      <div class="pos-der" :class="{plegado: carritoPlegado}">
        <div class="pos-barra" @click="carritoPlegado = !carritoPlegado"><span>{{lineas.length}} línea(s) · {{money(totales.total)}}</span><span class="small muted">{{carritoPlegado ? '▲ Ver carrito' : '▼ Ocultar'}}</span></div>
        <div class="pos-cliente">
          <div v-if="cliente" class="row" style="justify-content:space-between"><div><b>{{cliente.nombre}}</b><div class="small muted">{{cliente.numero_id || 'Sin identificación (solo tiquete)'}}<span v-if="cliente.correo"> · {{cliente.correo}}</span></div></div><button class="btn icon" title="Quitar cliente" @click="elegirCliente(null)">✕</button></div>
          <div v-if="cliente" class="small" style="margin-top:6px;display:flex;gap:6px;align-items:center;flex-wrap:wrap">
            <template v-if="exos.length">
              <span>Exoneración:</span>
              <select class="inp" style="max-width:230px;padding:2px 6px" v-model="exoId" @change="exoAuto = false"><option :value="null">— No aplicar —</option><option v-for="x in exos" :key="x.id" :value="x.id">{{x.numero}} · {{x.tarifa}} %{{x.fecha_vencimiento ? ' · vence ' + fecha(x.fecha_vencimiento) : ''}}</option></select>
              <a v-if="exoSel && exoSel.tiene_pdf" class="link" style="cursor:pointer" @click="verPdfExo(exoSel)">PDF</a>
              <span v-if="exoSel && lineas.length && !exoAplica" class="muted">no aplica a estos productos</span>
            </template>
            <span v-else-if="!exosCargando" class="muted">Sin exoneración</span>
            <button class="btn ghost sm" @click="exoNueva = true" title="Registrar la exoneración del cliente con su PDF o número (se verifica con Hacienda)">+ Exoneración</button>
          </div>
          <div v-else style="position:relative"><input class="inp" style="width:100%" v-model="qCliente" placeholder="Cliente (nombre, teléfono o cédula) · vacío = consumidor final" @focus="mostrarClientes=true" @input="mostrarClientes=true" @keyup.enter="clientesFiltrados.length ? elegirCliente(clientesFiltrados[0]) : abrirNuevoCliente()">
            <div class="pos-sug" v-if="mostrarClientes && qCliente.trim()"><div v-for="c in clientesFiltrados" :key="c.id" class="it" @mousedown.prevent="elegirCliente(c)">{{c.nombre}} <span class="muted small">{{c.numero_id || (c.celular || c.telefono ? '📞 ' + (c.celular || c.telefono) : '')}}</span></div><div class="it nuevo" @mousedown.prevent="abrirNuevoCliente">+ Nuevo cliente «{{qCliente}}»</div></div></div>
        </div>
        <div class="pos-carrito" ref="carrito">
          <div v-if="!lineas.length" class="muted" style="padding:30px 10px;text-align:center">{{mesaActual ? mesaActual.nombre + ' sin pedidos' : 'Carrito vacío'}}<br><span class="small">Busque o toque un producto</span></div>
          <div v-for="(l,i) in lineas" :key="l" class="pos-linea">
            <div class="d"><b>{{l.detalle}}<span v-if="l.enviado" class="small" style="font-weight:400;color:var(--muted)" :title="'Enviado a cocina a las ' + horaCorta(l.enviado)"> · r{{l.ronda}}</span><span v-if="l.entregado" class="badge" style="margin-left:4px;font-weight:400" :title="'Entregado a las ' + horaCorta(l.entregado)">entregado</span><span v-else-if="l.listo" class="badge ok" style="margin-left:4px;font-weight:400" :title="'Lista en cocina a las ' + horaCorta(l.listo)">listo</span><span v-else-if="l.preparando" class="badge info" style="margin-left:4px;font-weight:400" :title="'En preparación desde las ' + horaCorta(l.preparando)">en preparación</span></b><div class="small" v-if="l.nota" style="color:var(--primary)">✎ {{l.nota}}</div><div class="small muted"><span v-if="cfg.precio_editable">₡<input class="inp mini" type="number" step="0.01" min="0" v-model.number="l.precio_unitario" @input="l.precio_manual=true"></span><span v-else>{{money(l.precio_unitario)}}</span> + IVA {{fmt(l.tarifa,0)}} %<span v-if="descuentoDe(l)"> · desc. {{money(descuentoDe(l))}}{{l.descuento_pct ? ' (' + l.descuento_pct + ' %)' : ''}}</span> <a class="link small" style="cursor:pointer" @click="pedirDescuento(l)">desc.</a><a class="link small" v-if="esRestaurante" style="cursor:pointer;margin-left:6px" @click="abrirNota(l)" title="Observaciones para cocina (sin cebolla, término medio…)">obs.</a></div></div>
            <div class="c"><button class="btn icon" @click="cambiarCantidad(l,-1)">−</button><input class="inp mini" type="number" step="0.001" min="0" v-model.number="l.cantidad" @change="+l.cantidad > 0 ? aplicarPromos(l) : quitar(l)" style="width:58px;text-align:center"><button class="btn icon" @click="cambiarCantidad(l,1)">+</button></div>
            <div class="t">{{money(lineaTotal(l))}}<button class="btn icon" title="Quitar" @click="quitar(l)">✕</button></div>
          </div>
        </div>
        <div class="pos-tot">
          <div><span>Subtotal</span><b>{{money(totales.sub)}}</b></div>
          <div v-if="totales.desc"><span>Descuento</span><b>−{{money(totales.desc)}}</b></div>
          <div v-if="totales.exo"><span>IVA exonerado</span><b>−{{money(totales.exo)}}</b></div>
          <div><span>IVA</span><b>{{money(totales.iva)}}</b></div>
          <div v-if="totales.otros"><span>Otros impuestos</span><b>{{money(totales.otros)}}</b></div>
          <div v-if="+cfg.servicio_pct > 0"><span><label style="cursor:pointer"><input type="checkbox" v-model="servicio"> {{cfg.servicio_detalle || 'Servicio'}} ({{cfg.servicio_pct}} %)</label></span><b>{{money(totales.servicio)}}</b></div>
          <div class="total"><span>TOTAL</span><b>{{money(totales.total)}}</b></div>
        </div>
        <div class="pos-acciones" v-if="esRestaurante" style="flex-wrap:wrap">
          <button class="btn ghost" @click="vaciar" :disabled="!lineas.length" title="Vaciar">✕</button>
          <button class="btn sec" @click="enviarComanda" :disabled="!lineas.some(l => !l.enviado)" title="Imprimir la comanda de lo nuevo para cocina y bar (F8)">Comanda</button>
          <button class="btn sec" @click="guardarCuenta" :disabled="!lineas.length && !esperaId" data-guardar-cuenta :title="esVentaRapida ? 'Guardar esta venta en espera y empezar otra venta rápida (F4). La encuentra en «Para llevar en espera».' : 'Guardar la cuenta y volver al plano (F4)'">{{esVentaRapida ? 'Guardar y nueva venta' : 'Guardar cuenta'}}</button><!-- 4.37 -->
          <button class="btn sec" v-if="!mesaActual && lineas.length" @click="abrirPedido" title="Pedido para llevar o a domicilio con nombre, teléfono, hora y estado">🥡 Pedido</button>
          <button class="btn sec" @click="precuenta" :disabled="!lineas.length" title="Imprimir la precuenta para la mesa">Precuenta</button>
          <button class="btn ghost" @click="abrirDividir" :disabled="!lineas.length" title="Dividir la cuenta (por platos o en partes iguales), cobrar una parte o pasar platos a otra mesa">Dividir</button>
          <button class="btn sec" v-if="partesCuenta && lineas.length" @click="cobrarParte(partesCuenta.total)" :title="'Cobrar la siguiente parte de ' + partesCuenta.total">Cobrar parte {{(+partesCuenta.cobradas || 0) + 1}}</button>
          <button class="btn ghost" @click="mover={}" v-if="esperaId && mesaActual" title="Pasar la cuenta completa a otra mesa">Mover</button>
          <button class="btn ghost" @click="abrirUnir" v-if="mesaActual && lineas.length" title="Unir otras mesas a esta cuenta (una sola cuenta para varias mesas)">Unir</button>
          <button class="btn ghost" @click="separarMesas" v-if="mesasUnidas.length" title="Separar las mesas unidas; la cuenta se queda en esta mesa">Separar</button>
          <button class="btn ghost" @click="nuevaCuentaEnMesa(mesaActual)" v-if="mesaActual && esperaId" title="Abrir otra cuenta en esta misma mesa o barra (grupos que pagan aparte)">+ Cuenta</button>
          <button class="btn sec" v-if="hotelOn" @click="abrirCargoHab" :disabled="!lineas.length" title="Cargar el consumo a la cuenta del huésped (se factura al salir)">🛏 Habitación</button>
          <button class="btn ghost" @click="pedirCupon" :disabled="!lineas.length" :title="cupon ? 'Quitar el cupón ' + cupon.codigo : 'Aplicar un cupón de descuento'">{{cupon ? '🎟 ' + cupon.codigo + ' ✕' : '🎟 Cupón'}}</button>
          <button class="btn ghost" v-if="cliente" @click="abrirPuntos" :disabled="!lineas.length" title="Puntos del cliente">⭐ Puntos</button>
          <button class="btn pos-cobrar" @click="abrirPago" :disabled="!lineas.length" :title="tituloCobrar">Cobrar {{money(totales.total)}} <small>F9</small></button>
        </div>
        <div class="pos-acciones" v-else>
          <button class="btn ghost" @click="vaciar" :disabled="!lineas.length">Vaciar</button>
          <button class="btn sec" @click="modalEspera=true" title="Ventas en espera: cuentas abiertas (F4)">En espera<span v-if="esperaCaja.length" class="badge" style="margin-left:4px">{{esperaCaja.length}}</span></button>
          <button class="btn ghost" @click="pedirCupon" :disabled="!lineas.length" :title="cupon ? 'Quitar el cupón ' + cupon.codigo : 'Aplicar un cupón de descuento'">{{cupon ? '🎟 ' + cupon.codigo + ' ✕' : '🎟 Cupón'}}</button>
          <button class="btn ghost" v-if="cliente" @click="abrirPuntos" :disabled="!lineas.length" title="Puntos del cliente">⭐ Puntos</button>
          <button class="btn sec" v-if="hotelOn" @click="abrirCargoHab" :disabled="!lineas.length" title="Cargar el consumo a la cuenta del huésped (se factura al salir)">🛏 Habitación</button>
          <button class="btn pos-cobrar" @click="abrirPago" :disabled="!lineas.length" :title="tituloCobrar">Cobrar {{money(totales.total)}} <small>F9</small></button>
        </div>
        <div class="pos-ultima" v-if="ultima"><span>Última: <b>{{ultima.doc.consecutivo.slice(-10)}}</b> · {{money(ultima.total)}}<span v-if="ultima.vuelto"> · vuelto {{money(ultima.vuelto)}}</span></span><span><a class="link" style="cursor:pointer" @click="imprimir(ultima,'tiquete')">Tiquete</a> · <a class="link" style="cursor:pointer" @click="imprimir(ultima,'carta')">PDF</a></span></div>
      </div>
      <!-- celular (3.46): saltar entre Productos y Cuenta sin salir de la página de la mesa -->
      <div class="pos-salto seg" :class="{abajo: carritoPlegado}"><button :class="{on: carritoPlegado}" @click="carritoPlegado=true">Productos</button><button :class="{on: !carritoPlegado}" @click="carritoPlegado=false">Cuenta · {{money(totales.total)}}</button></div>
    </div>
    </template>

    <Modal v-if="pago" :title="cobrando ? (revisando ? 'Revisando…' : 'Emitiendo…') : 'Cobrar ' + money(totalCobro) + (cobroParcial ? (cobroParcial.de ? ' · parte ' + cobroParcial.parte + ' de ' + cobroParcial.de : ' · parte de la cuenta') : '')" @close="cerrarPago">
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:12px"><button v-for="m in MEDIOS.slice(0,4)" :key="m[0]" class="btn" :class="pago.medios.length===1 && pago.medios[0].medio===m[0] ? '' : 'sec'" @click="fijarMedio(m[0])">{{m[2]}} {{m[1]}}</button><button class="btn" :class="pago.medios.length===1 && pago.medios[0].medio==='fiado' ? '' : 'sec'" v-if="(cfg.fiado !== false || esCredito) && clienteId" @click="fijarMedio('fiado')" title="Crédito de casa: queda pendiente de cobro al cliente">📒 Fiado</button><button class="btn sec" @click="usarTarjeta" title="Pagar con una tarjeta de regalo (total o parcial)">🎁 Tarjeta de regalo</button><button class="btn ghost" @click="agregarMedio">+ Mixto</button></div>
      <div class="alert warn" v-if="esCredito" style="margin-bottom:8px">📒 Pedido{{cuentaCobro.pedido_numero ? ' #' + cuentaCobro.pedido_numero : ''}} hecho A CRÉDITO por {{cliente ? cliente.nombre : 'la revendedora'}}: se cierra como fiado y queda en su estado de cuenta<span v-if="pago.debe !== null && pago.debe !== undefined"> · debe {{money(pago.debe)}} de un límite de {{money((cliente && cliente.limite_credito) || 0)}}</span>. <b v-if="!pago.medios.some(m => m.medio==='fiado' && +m.monto > 0)">Está cobrándolo de contado.</b></div><!-- 4.9 -->
      <div class="alert info" v-if="prepago" style="margin-bottom:8px">Este pedido ya pagó {{money(prepago.monto)}} al hacerlo en línea ({{prepago.online && prepago.regalo ? (prepago.medio === '06' ? 'SINPE Móvil' : 'tarjeta en línea') + ' y tarjeta de regalo ' + prepago.tarjeta : prepago.online ? (prepago.medio === '06' ? 'por SINPE Móvil verificado' : 'con tarjeta, autorizado por Tilopay') : 'con la tarjeta de regalo ' + prepago.tarjeta}}); aquí se cobra solo el resto.</div><!-- 4.9: SINPE, Tilopay o tarjeta de regalo -->
      <div class="alert info" v-if="pago.medios.some(m => m.medio==='regalo')" style="margin-bottom:8px">Tarjeta de regalo: {{pago.medios.filter(m => m.medio==='regalo').map(m => m.codigo + ' ' + money(m.monto)).join(', ')}}. Se descuenta de la tarjeta al cobrar; no entra dinero a Bancos.</div>
      <div class="alert info" v-if="pago.medios.some(m => m.medio==='fiado')" style="margin-bottom:8px">Fiado a {{cliente ? cliente.nombre : ''}}: se emite a crédito a {{(cliente && cliente.termino_pago_dias) || 30}} días dentro de su límite ({{money((cliente && cliente.limite_credito) || 0)}}) y queda en sus cuentas por cobrar. Los abonos se reciben desde «Fiados».</div>
      <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px" v-if="cfg.propina !== false"><span class="small">Propina voluntaria</span><input class="inp mini" type="number" min="0" step="1" v-model.number="pago.propina" @input="propinaCambio" style="width:110px;text-align:right"><button class="btn sm ghost" v-for="p in [5, 10]" :key="p" @click="propinaPct(p)">{{p}} %</button><span class="small muted">aparte del comprobante</span><b v-if="pago.propina > 0" style="margin-left:auto">Total a cobrar {{money(totalCobro)}}</b></div>
      <div v-if="pago.medios.length===1 && pago.medios[0].medio==='01'">
        <div class="seg" style="margin-bottom:8px" v-if="cuentaUsd"><button :class="{on: pago.moneda!=='USD'}" @click="monedaCobro('CRC')">Paga en colones</button><button :class="{on: pago.moneda==='USD'}" @click="monedaCobro('USD')">Paga en dólares</button></div>
        <template v-if="enDolares">
          <div class="totals" style="margin:0 0 8px"><div><span>Total en dólares</span><b>{{money(totalUsd, 'USD')}}</b></div><div><span class="small muted">Tipo de cambio de la empresa</span><b class="small muted">₡{{fmt(pago.tc, 2)}} por dólar</b></div></div>
          <Field label="Dólares recibidos" help="Vacío = el monto exacto en dólares"><input ref="recibido" class="inp" type="number" step="1" min="0" v-model.number="pago.recibido_usd" style="font-size:22px;text-align:right" @keyup.enter="cobrar" :placeholder="fmt(totalUsd, 2)"></Field>
          <div class="row" style="gap:6px;margin:8px 0;flex-wrap:wrap"><button class="btn sm sec" v-for="v in [20, 50, 100]" :key="v" @click="pago.recibido_usd = v">{{money(v, 'USD')}}</button></div>
          <div class="totals" style="margin-top:4px"><div><span>Equivale a</span><b>{{money(pagoTot.pagado)}}</b></div><div class="total"><span>Vuelto en colones</span><b>{{money(pagoTot.vuelto)}}</b></div></div>
          <p class="small muted" style="margin:6px 0 0">Los dólares entran a «{{cuentaUsd}}» y el vuelto sale de la gaveta en colones.</p>
        </template>
        <template v-else>
        <Field label="Efectivo recibido"><input ref="recibido" class="inp" type="number" step="1" min="0" v-model.number="pago.recibido" @input="recibidoCambio" style="font-size:22px;text-align:right" @keyup.enter="cobrar"></Field>
        <div class="row" style="gap:6px;margin:8px 0;flex-wrap:wrap"><button class="btn sm sec" @click="montoRapido('exacto')">Exacto</button><button class="btn sm sec" v-for="v in montosRapidos" :key="v" @click="montoRapido(v)">{{money(v)}}</button></div>
        <div class="totals" style="margin-top:4px"><div class="total"><span>Vuelto</span><b>{{money(pagoTot.vuelto)}}</b></div></div>
        </template>
      </div>
      <div v-else>
        <table class="tbl"><thead><tr><th>Medio</th><th class="num">Monto</th><th></th></tr></thead>
          <tbody><tr v-for="(m,i) in pago.medios" :key="i"><td><select class="inp" v-model="m.medio"><option v-for="x in MEDIOS" :key="x[0]" :value="x[0]">{{x[1]}}</option><option value="fiado" v-if="m.medio==='fiado' || ((cfg.fiado !== false || esCredito) && clienteId)">📒 Fiado</option></select></td><td><input class="inp" type="number" step="0.01" min="0" v-model.number="m.monto" style="width:140px;text-align:right"></td><td><button class="btn icon" @click="pago.medios.splice(i,1)" v-if="pago.medios.length>1">✕</button></td></tr></tbody></table>
        <div class="totals"><div><span>Pagado</span><b>{{money(pagoTot.pagado)}}</b></div><div v-if="pagoTot.falta"><span>Falta</span><b style="color:var(--danger)">{{money(pagoTot.falta)}}</b></div><div v-if="pagoTot.vuelto"><span>Vuelto (efectivo)</span><b>{{money(pagoTot.vuelto)}}</b></div></div>
      </div>
      <div class="row" style="margin-top:12px;gap:14px;flex-wrap:wrap"><label class="row" style="cursor:pointer;gap:6px"><input type="radio" value="04" v-model="pago.tipo_documento"> Tiquete electrónico</label><label class="row" style="cursor:pointer;gap:6px"><input type="radio" value="01" v-model="pago.tipo_documento" :disabled="!clienteId || !(cliente && cliente.numero_id)"> Factura electrónica<span class="small muted" v-if="!clienteId"> (elija un cliente)</span><span class="small muted" v-else-if="!(cliente && cliente.numero_id)"> (el cliente no tiene identificación)</span></label></div>
      <p class="small muted" style="margin:8px 0 0">Cada medio entra en la cuenta configurada: <span v-for="(m,i) in pago.medios" :key="i">{{nombreMedio(m.medio)}} → {{cuentaPara(m.medio) || 'sin cuenta'}}<span v-if="i<pago.medios.length-1">; </span></span><span v-if="prepago && +prepago.online > 0">; pago en línea ({{nombreMedio(prepago.medio || '02')}}) → {{cuentaPara(prepago.medio || '02') || 'sin cuenta'}}</span>.</p><!-- 4.9: la cuenta de Bancos de lo pagado en línea -->
      <template #foot><button class="btn ghost" :disabled="cobrando" @click="cerrarPago" title="Cerrar sin cobrar (F7 o Esc)">Cancelar (F7)</button><button class="btn sec pos-cobrar" :disabled="cobrando || !pagoTot.ok" @click="cobrarOtro" :title="botonesCobro.otra + ': solo para esta venta; la caja sigue igual'">{{cobrando ? 'Emitiendo…' : botonesCobro.otra}}</button><button class="btn pos-cobrar" :disabled="cobrando || !pagoTot.ok" @click="cobrar">{{cobrando ? 'Emitiendo…' : botonesCobro.principal}}</button></template><!-- 4.29 (K-1): tres botones con su tecla; en el teléfono bajan de línea -->
    </Modal>

    <ExoneracionRapida v-if="exoNueva && cliente" :cliente-id="cliente.id" :numero-id="String(cliente.numero_id || '')" @close="exoNueva = false" @registrada="exoRegistrada"></ExoneracionRapida>

    <Modal v-if="pedido" :title="pedido.seguir ? 'Para llevar o Express: ¿para quién?' : 'Pedido para llevar o a domicilio'" @close="pedido=null">
      <div class="seg" style="margin-bottom:10px"><button :class="{on: pedido.tipo==='llevar'}" @click="pedido.tipo='llevar'">🥡 Para llevar</button><button :class="{on: pedido.tipo==='domicilio'}" @click="pedido.tipo='domicilio'">🛵 Express / a domicilio</button></div>
      <div class="pos-cliente" style="margin-bottom:10px"><!-- 4.6: cliente por nombre o teléfono, con sus direcciones guardadas -->
        <div v-if="clienteReal" class="row" style="justify-content:space-between"><div><b>{{clienteReal.nombre}}</b><div class="small muted">{{clienteReal.numero_id || 'Sin identificación'}}<span v-if="clienteReal.celular || clienteReal.telefono"> · 📞 {{clienteReal.celular || clienteReal.telefono}}</span></div></div><button class="btn icon" title="Otro cliente" @click="elegirClientePedido(null)">✕</button></div>
        <div v-else style="position:relative"><input class="inp" style="width:100%" v-model="pedido.q" placeholder="Buscar cliente por nombre o teléfono (vacío = sin registrar)" autofocus>
          <div class="pos-sug" v-if="pedido.q.trim()"><div v-for="c in clientesPedido" :key="c.id" class="it" @mousedown.prevent="elegirClientePedido(c)">{{c.nombre}} <span class="muted small">{{c.numero_id || (c.celular || c.telefono ? '📞 ' + (c.celular || c.telefono) : '')}}</span></div><div class="it nuevo" @mousedown.prevent="nuevoClientePedido">+ Nuevo cliente «{{pedido.q}}»</div></div></div>
      </div>
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="pedido.nombre" maxlength="60"></Field>
        <Field label="Teléfono (WhatsApp)"><input v-model="pedido.telefono" maxlength="20" placeholder="8888-8888"></Field>
        <template v-if="pedido.tipo==='domicilio'">
          <Field label="Dirección guardada" style="grid-column:1/-1" v-if="direccionesDe(clienteReal).length"><select v-model="pedido.direccion_sel" @change="elegirDireccion"><option v-for="d in direccionesDe(clienteReal)" :key="d.detalle" :value="d.detalle">{{d.nombre}}: {{d.detalle}}</option><option value="">Otra dirección…</option></select></Field>
          <Field label="Dirección de entrega" req style="grid-column:1/-1"><input v-model="pedido.direccion" maxlength="250" placeholder="Barrio, señas, referencia" @input="pedido.direccion_sel = direccionesDe(clienteReal).some(d => d.detalle === pedido.direccion) ? pedido.direccion : ''"></Field>
          <template v-if="clienteReal && pedido.direccion.trim() && !direccionesDe(clienteReal).some(d => d.detalle === pedido.direccion.trim())">
            <Field label="Guardarla en el cliente como"><input v-model="pedido.direccion_nombre" maxlength="40" placeholder="Casa, Trabajo, Donde la hermana…"></Field>
            <label class="row small" style="gap:6px;cursor:pointer;align-self:end;padding-bottom:10px"><input type="checkbox" v-model="pedido.guardar_dir"> Guardar esta dirección en la ficha de {{clienteReal.nombre}}</label>
          </template>
        </template>
        <Field label="Hora de entrega o recogida"><input type="time" v-model="pedido.hora_entrega"></Field>
        <Field label="Nota"><input v-model="pedido.nota" maxlength="120" placeholder="Sin cebolla, pagar con 20 mil…"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0" v-if="pedido.seguir">Después de confirmar, agregue los platos y envíe la comanda. El pedido queda en «Pedidos» con su estado y se cobra al entregarlo o al recogerlo.</p>
      <p class="small muted" style="margin:8px 0 0" v-else>El pedido queda en «Pedidos» con su estado; se cobra al entregarlo o al recogerlo con el botón Cobrar. Total {{money(totales.total)}}.</p>
      <template #foot><button class="btn ghost" @click="pedido=null">Cancelar</button><button class="btn" @click="confirmarPedido">{{pedido.seguir ? 'Continuar con los platos' : 'Registrar el pedido'}}</button></template>
    </Modal>
    <!-- 4.6: va después del modal del pedido para quedar encima cuando el cliente se crea desde «Para llevar / Express» -->
    <Modal v-if="nuevoCliente" title="Nuevo cliente" @close="nuevoCliente=null">
      <div class="grid cols-2">
        <Field label="Tipo de identificación" req><select v-model="nuevoCliente.tipo_id" @change="nuevoCliente.tipo_id || (nuevoCliente.numero_id = '')"><option v-for="o in opts(CAT.tipoId)" :key="o.value" :value="o.value">{{o.label}}</option><option value="">Sin identificación (solo tiquetes)</option></select></Field>
        <Field label="Identificación" :req="!!nuevoCliente.tipo_id"><div class="row" style="gap:6px"><input v-model="nuevoCliente.numero_id" style="flex:1" :placeholder="nuevoCliente.tipo_id ? 'Sin guiones' : 'Sin identificación'" :disabled="!nuevoCliente.tipo_id"><button class="btn sec sm" @click="buscarHacienda" :disabled="buscandoHac || !nuevoCliente.tipo_id">{{buscandoHac ? '…' : 'Hacienda'}}</button></div></Field>
        <Field label="Nombre" req style="grid-column:1/-1"><input v-model="nuevoCliente.nombre"></Field>
        <Field label="Correo" help="Para enviarle el comprobante"><input type="email" v-model="nuevoCliente.correo"></Field>
        <Field label="Teléfono"><input v-model="nuevoCliente.telefono" maxlength="8" inputmode="numeric"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Alta rápida: el resto de los datos (dirección, lista de precios, crédito) se completan después en Contactos.<template v-if="!nuevoCliente.tipo_id"> Sin identificación solo se le emiten tiquetes; si después necesita factura, agréguele la cédula en Contactos.</template></p>
      <template #foot><button class="btn ghost" @click="nuevoCliente=null">Cancelar</button><button class="btn" @click="guardarCliente">Guardar y usar</button></template>
    </Modal>
    <Modal v-if="fiado" title="Abonos a cuentas por cobrar" lg @close="fiado=null">
      <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px"><input class="inp" style="flex:1;min-width:220px" v-model="fiado.q" placeholder="Buscar cliente por nombre o cédula"><span class="chip on" v-if="fiado.cliente">{{fiado.cliente.nombre}} · límite {{money(fiado.cliente.limite_credito || 0)}}</span></div>
      <div class="card" v-if="clientesFiado().length" style="padding:6px;margin-bottom:10px"><div v-for="c in clientesFiado()" :key="c.id" class="row" style="justify-content:space-between;padding:4px 6px;cursor:pointer" @click="elegirFiado(c)"><span>{{c.nombre}} <small class="muted">{{c.numero_id}}</small></span><span class="small muted">límite {{money(c.limite_credito || 0)}}</span></div></div>
      <template v-if="fiado.cliente">
        <p class="small muted" v-if="fiado.cargando">Buscando…</p>
        <Empty v-else-if="!fiado.docs.length" icon="📒" title="Sin fiados pendientes" :text="fiado.cliente.nombre + ' no debe nada.'"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Comprobante</th><th>Fecha</th><th>Vence</th><th class="num">Total</th><th class="num">Saldo</th><th></th></tr></thead><tbody>
          <tr v-for="d in fiado.docs" :key="d.id"><td><b>{{d.consecutivo.slice(-10)}}</b></td><td>{{fecha(d.fecha_emision)}}</td><td :style="d.vencido ? 'color:var(--danger)' : ''">{{d.fecha_vencimiento ? fecha(d.fecha_vencimiento) : '—'}}</td><td class="num">{{money(d.total)}}</td><td class="num"><b>{{money(d.saldo)}}</b></td><td class="num"><button class="btn sm" @click="fiado.abono={doc: d, monto: d.saldo, medio: '01'}">Abonar</button></td></tr>
        </tbody></table></div>
        <div class="row" style="justify-content:flex-end;margin-top:6px" v-if="fiado.docs.length"><b>Debe en total {{money(totalFiado())}}</b></div>
        <div class="card" v-if="fiado.abono" style="padding:10px;margin-top:10px"><b>Abono a {{fiado.abono.doc.consecutivo.slice(-10)}}</b> <span class="small muted">saldo {{money(fiado.abono.doc.saldo)}}</span>
          <div class="grid cols-2" style="margin-top:6px"><Field label="Monto" req><input type="number" min="0" step="1" v-model.number="fiado.abono.monto" style="font-size:20px;text-align:right"></Field><Field label="Medio"><select v-model="fiado.abono.medio"><option v-for="m in MEDIOS.slice(0,4)" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field></div>
          <div class="row" style="justify-content:flex-end;gap:6px"><button class="btn ghost" @click="fiado.abono=null">Cancelar</button><button class="btn" @click="abonar" :disabled="cobrando">Recibir el abono</button></div></div>
      </template>
      <Empty v-else icon="📒" title="Elija el cliente" text="Los fiados son facturas a crédito emitidas desde la caja; aquí se reciben los abonos y entran a la gaveta o al banco."></Empty>
      <template #foot><button class="btn ghost" @click="fiado=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="turno && caja" title="Entregar el turno" @close="turno=null">
      <p class="small muted" style="margin:0 0 8px">La caja sigue abierta: el cajero que sale deja contado el efectivo y el que entra sigue vendiendo con su propio usuario. El cierre de caja muestra las ventas de cada cajero y cada arqueo.</p>
      <div class="totals" style="margin:0 0 8px"><div><span>Cajero que entrega</span><b>{{sesion.usuario?.nombre || sesion.usuario?.correo}}</b></div><div><span>Desde</span><b>{{turno.desde ? new Date(turno.desde).toLocaleString('es-CR', {day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'}) : '—'}}</b></div><div><span>Ventas del turno</span><b>{{turno.ventas}}<template v-if="verMontosCaja"> · {{money(turno.total)}}</template></b></div><div class="total" v-if="verMontosCaja"><span>Efectivo esperado en la gaveta</span><b>{{money(turno.esperado)}}</b></div></div>
      <p class="small muted" style="margin:0 0 8px" v-if="!verMontosCaja">Cuente todo el efectivo de la gaveta y anótelo. {{caja && opcionesCierre(caja).corte ? 'Al entregar el turno verá la diferencia.' : 'La diferencia la revisa la administración.'}}</p>
      <Field label="Efectivo contado" req><input type="number" min="0" step="1" v-model.number="turno.conteo" style="font-size:22px;text-align:right" autofocus></Field>
      <div class="small" v-if="verMontosCaja && turno.conteo !== null && turno.conteo !== ''" :style="Math.abs(turno.conteo - turno.esperado) > 0.005 ? 'color:var(--danger)' : 'color:var(--ok)'" style="margin:4px 0 8px">Diferencia: {{money(turno.conteo - turno.esperado)}}</div>
      <Field label="Nota"><input v-model="turno.nota" maxlength="120"></Field>
      <template #foot><button class="btn ghost" @click="turno=null">Cancelar</button><button class="btn" @click="confirmarTurno">Entregar el turno</button></template>
    </Modal>
    <Modal v-if="modalVentas && caja" title="Ventas de esta caja" lg @close="modalVentas=false">
      <Empty v-if="!ventasCaja.length" icon="🧾" title="Sin ventas todavía" text="Aquí salen las ventas de la caja abierta. Las de cajas anteriores están en Punto de venta › Ventas de caja."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Hora</th><th>Comprobante</th><th>Cliente / mesa</th><th>Medios</th><th class="num">Total</th><th></th></tr></thead><tbody>
        <tr v-for="v in ventasCaja" :key="v.id" :style="v.anulada ? 'opacity:.55' : ''">
          <td>{{new Date(v.hora).toLocaleTimeString('es-CR', {hour: '2-digit', minute: '2-digit'})}}</td><td><b>{{v.consecutivo}}</b><div class="small" v-if="v.anulada" style="color:var(--danger)">Anulada{{v.nc_consecutivo ? ' · NC ' + v.nc_consecutivo : ''}} · {{v.motivo_anulacion}}</div></td>
          <td>{{v.cliente || 'Consumidor final'}}<div class="small muted" v-if="v.mesa">{{v.mesa}}</div></td>
          <td class="small">{{(v.medios || []).map(m => nombreMedio(m.medio) + ' ' + money(m.monto)).concat(+v.fiado > 0 ? [nombreMedio('fiado') + ' ' + money(v.fiado)] : []).join(' · ')}}</td>
          <td class="num"><b>{{money(v.total)}}</b></td>
          <td class="num"><button class="btn sm ghost" v-if="v.doc_id && !v.anulada && v.tipo !== 'hab' && !v.abono" @click="verTiquete(v)" title="Ver el tiquete en pantalla (dice COPIA)">Ver</button> <button class="btn sm ghost" v-if="v.doc_id && !v.anulada && v.tipo !== 'hab' && !v.abono" @click="reimprimirVenta(v)" title="Tiquete de 80 mm con la palabra COPIA">Reimprimir</button> <button class="btn sm ghost" v-if="!v.anulada && v.tipo !== 'hab' && sesion.puede('facturar')" @click="anularVenta(v)" :disabled="cobrando">Anular / devolver</button><span class="small muted" v-else-if="!v.anulada && v.tipo !== 'hab'">Pida a un supervisor que la anule</span></td>
        </tr></tbody></table></div>
      <template #foot><a class="btn sm ghost" href="#/pos/ventas" @click="modalVentas=false" title="Todas las ventas, de hoy y de días anteriores, para ver, imprimir a carta o reimprimir">Ver todas las ventas</a><button class="btn ghost" @click="modalVentas=false">Cerrar</button></template>
    </Modal>
    <Modal v-if="modalEspera" title="Cuentas en espera" lg @close="modalEspera=false">
      <div class="row" style="gap:6px;margin-bottom:12px" v-if="lineas.length && !esRestaurante"><input class="inp" style="flex:1" v-model="nombreEspera" placeholder="Nombre: Juan, Pedido 12, Mesa 4…" @keyup.enter="ponerEnEspera"><button class="btn" @click="ponerEnEspera">Guardar el carrito en espera</button></div>
      <div class="row" style="gap:6px;margin-bottom:12px" v-if="lineas.length"><button class="btn sec" @click="abrirPedido">🥡 Pedido para llevar o a domicilio</button><span class="small muted">con nombre, teléfono, hora y estado (recibido, en cocina, listo, entregado)</span></div>
      <table class="tbl" v-if="esperaCaja.length"><thead><tr><th>Nombre</th><th>Desde</th><th class="num">Ítems</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="v in esperaCaja" :key="v.id"><td><b>{{v.nombre}}</b> <span class="badge warn" v-if="v.credito" title="Pedido en línea a crédito: al cobrarlo se emite como fiado">📒 A crédito</span><div class="small muted" v-if="v.cliente_id">{{(store.clientes.find(c=>c.id===v.cliente_id)||{}).nombre}}</div><div class="small" v-if="v.pedido"><span class="badge" :class="v.estado==='listo' ? 'ok' : v.estado==='en_cocina' ? 'warn' : v.estado==='entregado' ? '' : 'info'">{{nombreEstadoPedido(v.estado || 'recibido')}}</span> {{v.pedido==='domicilio' ? '🛵 Domicilio' : '🥡 Para llevar'}}{{v.telefono ? ' · ' + v.telefono : ''}}{{v.hora_entrega ? ' · ' + v.hora_entrega : ''}}<span v-if="v.direccion"> · {{v.direccion}}</span></div></td><td class="small">{{fechaHora(v.creado)}}</td><td class="num">{{(v.lineas||[]).length}}</td><td class="num">{{money(v.total)}}</td><td><div class="acts"><button class="btn sm sec" v-if="v.pedido && textoSiguiente(v)" @click="avanzarPedido(v)">{{textoSiguiente(v)}}</button><a class="btn sm ghost" v-if="v.pedido && v.telefono && v.estado==='listo'" :href="waPedido(v)" target="_blank" rel="noopener">WhatsApp</a><button class="btn sm" @click="recuperar(v)">{{v.pedido ? 'Cobrar' : 'Recuperar'}}</button><button class="btn icon" @click="borrarEspera(v)">🗑</button></div></td></tr></tbody></table>
      <Empty v-else icon="🍽" title="Nada en espera" text="Guarde el carrito con un nombre (mesa, cliente, pedido) y recupérelo cuando vaya a cobrar."></Empty>
    </Modal>

    <!-- 4.32 (pedido del 14 nov): «🌐 Pedidos web»: los pedidos en línea sin salir de la caja -->
    <Modal v-if="panelWeb" title="Pedidos en línea" lg @close="panelWeb=null">
      <!-- 4.39: «Ver pedido»: el resumen dentro de la misma ventana, con «← Atrás» arriba a la izquierda y abajo -->
      <div v-if="verWeb" data-detalle-web>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px"><button class="btn sm sec" @click="atrasWeb" data-atras-web title="Volver a la lista de pedidos (Esc)">← Atrás</button><b style="font-size:16px">Pedido #{{verWeb.numero}}</b><span class="badge" :class="['nuevo','cancelado'].includes(verWeb.estado) ? 'danger' : verWeb.estado==='listo' ? 'ok' : verWeb.estado==='en_preparacion' ? 'warn' : 'info'">{{verWeb.estado_nombre || verWeb.estado}}</span></div>
        <div style="display:grid;grid-template-columns:auto 1fr;gap:4px 12px;margin-bottom:12px">
          <span class="muted">Cliente</span><span data-cliente-web><b>{{verWeb.nombre}}</b><template v-if="verWeb.telefono"> · {{verWeb.telefono}}</template></span>
          <span class="muted">Entrega</span><span data-entrega-web>{{verWeb.tipo_nombre || verWeb.tipo}}<template v-if="verWeb.direccion && verWeb.tipo !== 'recoger'"> · {{verWeb.direccion}}</template><template v-if="verWeb.zona"> · zona {{verWeb.zona}}</template></span>
          <span class="muted">Hora</span><span data-hora-web>Pedido a las {{horaWeb(verWeb)}}<template v-if="verWeb.hora_programada"> · lo quiere para las <b>{{verWeb.hora_programada}}</b></template></span>
          <span class="muted">Pago</span><span data-pago-web>{{verWeb.forma_pago || 'Paga al recibir'}}<template v-if="verWeb.pago_estado_nombre && ['reembolsado','reembolso_pendiente'].includes(verWeb.pago_estado)"> · {{verWeb.pago_estado_nombre}}</template></span>
          <template v-if="+verWeb.atiende > 0 && !cuentaDePedidoWeb(verWeb)"><span class="muted">Caja</span><span>Lo atiende «{{verWeb.atiende_nombre || 'otra computadora'}}»: cóbrelo allá.</span></template>
          <template v-if="verWeb.estado==='cancelado' && verWeb.motivo"><span class="muted">Motivo</span><span>{{verWeb.motivo}}</span></template>
        </div>
        <table class="tbl"><thead><tr><th class="num">Cant.</th><th>Producto</th><th class="num">Total</th></tr></thead>
          <tbody><tr v-for="(l, i) in (verWeb.lineas || [])" :key="i" data-linea-web><td class="num">{{l.cantidad}}</td><td>{{l.detalle || l.nombre}}<div class="small muted" v-if="opcionesWeb(l)">Con: {{opcionesWeb(l)}}</div><div class="small muted" v-if="l.nota">Nota: {{l.nota}}</div></td><td class="num">{{money(l.total)}}</td></tr></tbody></table>
        <div style="text-align:right;margin-top:8px" data-total-web><div class="small muted" v-if="+verWeb.envio > 0">Envío {{money(verWeb.envio)}}</div><div class="small muted" v-if="+verWeb.descuento > 0">Descuento {{money(verWeb.descuento)}}</div><b>Total {{money(verWeb.total)}}</b></div>
        <div class="alert info" v-if="verWeb.nota" style="margin-top:10px;padding:6px 10px" data-nota-web>Nota del cliente: {{verWeb.nota}}</div>
        <div v-if="panelWeb.cancelar" style="margin-top:12px" data-cancelar-web>
          <label class="field"><span class="req">Justificación de la cancelación</span><textarea v-model="panelWeb.cancelar.motivo" rows="3" maxlength="200" placeholder="Por ejemplo: se nos acabó el producto"></textarea><span class="help">Al menos 8 caracteres. El cliente la ve y queda anotada con su usuario y la hora.</span></label>
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px"><button class="btn sm sec" @click="panelWeb.cancelar=null">Volver</button><button class="btn sm danger" :disabled="panelWeb.cancelar.enviando" @click="cancelarWeb(verWeb)">Confirmar cancelación</button></div>
        </div>
        <div v-else style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;margin-top:12px" data-acciones-web>
          <button class="btn sm sec" @click="atrasWeb">← Atrás</button>
          <button class="btn sm sec" v-if="!['entregado','cancelado'].includes(verWeb.estado)" @click="abrirCancelarWeb">Cancelar con justificación</button>
          <button class="btn sm sec" v-if="!puedeImprimirWeb(verWeb) && cuentaDePedidoWeb(verWeb)" @click="abrirCuentaWeb(cuentaDePedidoWeb(verWeb))">Abrir para cobrar</button>
          <button class="btn sm" v-if="puedeImprimirWeb(verWeb)" :disabled="!!panelWeb.aceptando[verWeb.id] || panelWeb.listo === false" @click="imprimirComandaWeb(verWeb)">{{panelWeb.aceptando[verWeb.id] ? 'Confirmando…' : textoImprimirWeb}}</button>
        </div>
      </div>
      <p class="muted" v-else-if="panelWeb.cargando && !panelWeb.lista.length">Cargando los pedidos…</p>
      <div class="alert warn" v-else-if="panelWeb.error && !panelWeb.lista.length">{{panelWeb.error}}</div>
      <!-- 4.39 (prueba de punta a punta): en el teléfono cada pedido es una tarjeta con sus botones abajo (tbl-ventas, como Ventas de caja); antes quedaban fuera de la pantalla -->
      <table class="tbl tbl-ventas" v-else-if="filasWeb.length"><thead><tr><th>Pedido</th><th>Hora</th><th>Entrega</th><th class="num">Total</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="p in filasWeb" :key="p.id" :data-pedido-web="p.id" :style="p.estado==='nuevo' ? 'background:var(--danger-soft)' : ''">
          <td style="white-space:normal"><b>#{{p.numero}}</b> {{p.nombre}}<div class="small muted" v-if="(p.lineas||[]).length">{{lineasWeb(p)}}</div><div class="small muted" v-if="p.nota">Nota: {{p.nota}}</div></td>
          <td data-l="Hora">{{horaWeb(p)}}<div class="small muted" v-if="p.hora_programada">para las {{p.hora_programada}}</div></td>
          <td data-l="Entrega">{{p.tipo_nombre || p.tipo}}</td>
          <td class="num" data-l="Total">{{money(p.total)}}<div class="small muted" v-if="p.forma_pago">{{p.forma_pago}}</div></td>
          <td data-l="Estado"><span class="badge" :class="p.estado==='nuevo' ? 'danger' : p.estado==='listo' ? 'ok' : p.estado==='en_preparacion' ? 'warn' : 'info'">{{p.estado_nombre || p.estado}}</span><div class="small muted" v-if="+p.atiende > 0 && p.atiende_nombre && !cuentaDePedidoWeb(p)">Lo atiende «{{p.atiende_nombre}}»</div></td>
          <td class="acciones-venta"><div class="row" style="gap:4px;flex-wrap:wrap;justify-content:flex-end">
            <button class="btn sm sec" @click="verPedidoWeb(p)" data-ver-web>Ver pedido</button><!-- 4.39: «Ver pedido» en todos; «Imprimir comanda» acepta e imprime (en la web y en el programa) -->
            <button class="btn sm" v-if="puedeImprimirWeb(p)" :disabled="!!panelWeb.aceptando[p.id] || panelWeb.listo === false" @click="imprimirComandaWeb(p)" data-aceptar-web>{{panelWeb.aceptando[p.id] ? 'Confirmando…' : textoImprimirWeb}}</button>
            <button class="btn sm sec" v-else-if="cuentaDePedidoWeb(p)" @click="abrirCuentaWeb(cuentaDePedidoWeb(p))" data-cobrar-web>Abrir para cobrar</button>
          </div></td></tr></tbody></table>
      <Empty v-else icon="🌐" title="Sin pedidos en línea pendientes" text="Aquí aparecen los pedidos de la página mientras no se entreguen. Cuando entra uno nuevo suena y el botón «Pedidos web» se pone rojo."></Empty>
      <div class="small muted" v-if="panelWeb.error && panelWeb.lista.length" style="margin-top:8px">{{panelWeb.error}}</div>
      <template #foot><a class="btn ghost" href="#/fisitaap/pedidos" @click="panelWeb=null">Ver todos en Ventas en línea › Pedidos</a><button class="btn" @click="panelWeb=null">Cerrar</button></template>
    </Modal>

    <Modal v-if="habCargo" :title="'Cargar ' + money(totales.total) + ' a una habitación'" @close="habCargo=null">
      <input class="inp" style="width:100%;margin-bottom:8px" v-model="habCargo.q" placeholder="Buscar por habitación o huésped" autofocus>
      <div style="max-height:300px;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px">
        <button v-for="r in enCasaHotel" :key="r.id" class="pos-prod" :class="{sel: habCargo.reserva_id===r.id}" :style="habCargo.reserva_id===r.id ? 'border-color:var(--primary);background:var(--primary-soft)' : ''" @click="habCargo.reserva_id=r.id"><span class="n">Hab. {{r.hab}}</span><span class="st">{{r.vip ? '★ ' : ''}}{{r.huesped_nombre}}</span></button>
        <div class="muted small" v-if="!enCasaHotel.length" style="grid-column:1/-1;padding:16px;text-align:center">No hay huéspedes en casa{{habCargo.q ? ' con «' + habCargo.q + '»' : ''}}.</div>
      </div>
      <Field label="Quién autoriza el cargo" help="Nombre de quien firma o autoriza (huésped o acompañante); queda en el detalle del cargo" style="margin-top:10px"><input v-model="habCargo.autoriza" maxlength="60" placeholder="Nombre del huésped que firma"></Field>
      <div class="alert warn" v-if="avisoHab" style="margin:8px 0 0">{{avisoHab}}</div>
      <label class="row" style="gap:6px;margin-top:10px;cursor:pointer"><input type="checkbox" v-model="habCargo.firma"> Imprimir la comanda para la firma del huésped</label>
      <p class="small muted" style="margin:8px 0 0">El consumo queda en la cuenta del huésped en la moneda del hotel y se factura al hacer el check-out. En el cierre de caja aparece como «Cargo a habitación» (no entra dinero).</p>
      <template #foot><button class="btn ghost" @click="habCargo=null">Cancelar</button><button class="btn" @click="cargarAHabitacion" :disabled="!habCargo.reserva_id">Cargar a la habitación</button></template>
    </Modal>

    <Modal v-if="modSel" :title="modSel.p.nombre" @close="modSel=null">
      <div v-for="g in modSel.grupos" :key="g.id" style="margin-bottom:10px"><b>{{g.nombre}}</b> <span class="small muted">{{g.minimo ? 'obligatorio' : 'opcional'}}{{+g.maximo === 1 ? ' · una opción' : +g.maximo ? ' · hasta ' + g.maximo : ''}}</span>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px"><button v-for="o in g.opciones" :key="o.id" class="btn sm" :class="modSel.sel[g.id].includes(o.id) ? '' : 'sec'" @click="toggleOpcion(g, o)">{{o.nombre}}<span v-if="+o.precio" class="small"> +{{money(o.precio)}}</span></button></div>
      </div>
      <template #foot><button class="btn ghost" @click="modSel=null">Cancelar</button><button class="btn" @click="confirmarMod">Agregar</button></template>
    </Modal>
    <Modal v-if="puntos" :title="'Puntos de ' + (cliente ? cliente.nombre : '')" @close="puntos=null">
      <p style="margin:0 0 8px">Saldo: <b style="font-size:20px">{{fmt(puntos.saldo, 0)}}</b> {{puntos.config.nombre}} · equivalen a {{money(puntos.valor)}}</p>
      <template v-if="puntos.config.activo && puntos.saldo >= puntos.config.minimo_canje && !puntos.canje">
        <Field :label="'Puntos a canjear (mínimo ' + puntos.config.minimo_canje + ', hasta el ' + puntos.config.maximo_pct + ' % de la compra)'"><input type="number" :min="puntos.config.minimo_canje" :max="puntos.saldo" step="1" v-model.number="puntos.usar" style="font-size:20px;text-align:right"></Field>
        <p class="small muted" style="margin:4px 0 0">Descuento: {{money((+puntos.usar || 0) * puntos.config.valor_punto)}}</p>
      </template>
      <div class="alert ok" v-else-if="puntos.canje">Se aplicaron {{puntos.aplicados}} puntos (−{{money(puntos.descuento)}}); se descuentan del saldo al cobrar.</div>
      <p class="small muted" v-else-if="!puntos.config.activo">El programa de puntos no está activo.</p>
      <p class="small muted" v-else>Todavía no alcanza el mínimo para canjear.</p>
      <template #foot><button class="btn ghost" @click="puntos=null">Cerrar</button><button class="btn" v-if="puntos.config.activo && puntos.saldo >= puntos.config.minimo_canje && !puntos.canje" @click="aplicarPuntos">Canjear</button></template>
    </Modal>
    <Modal v-if="regalo" title="Vender una tarjeta de regalo" @close="regalo=null">
      <div class="grid cols-2"><Field label="Monto" req><input type="number" min="1000" step="1000" v-model.number="regalo.monto" style="font-size:20px;text-align:right"></Field><Field label="Vigencia (meses)"><input type="number" min="0" max="120" v-model.number="regalo.meses"></Field><Field label="Para (beneficiario)"><input v-model="regalo.beneficiario" maxlength="80"></Field><Field label="Comprador"><input v-model="regalo.comprador" maxlength="80"></Field><Field label="Cómo paga" style="grid-column:1/-1"><select v-model="regalo.medio"><option v-for="m in MEDIOS.slice(0,4)" :key="m[0]" :value="m[0]">{{m[2]}} {{m[1]}}</option></select></Field></div>
      <p class="small muted" style="margin:8px 0 0">El dinero entra hoy a la caja como anticipo (sin tiquete); el tiquete electrónico sale cuando el cliente consuma con la tarjeta.</p>
      <template #foot><button class="btn ghost" @click="regalo=null">Cancelar</button><button class="btn" @click="venderRegalo">Vender</button></template>
    </Modal>

    <Modal v-if="lineaNota" :title="'Observaciones · ' + lineaNota.l.detalle" @close="lineaNota=null">
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px"><button v-for="m in modificadores(cfg)" :key="m" class="btn sm" :class="lineaNota.texto.split(',').map(x => x.trim()).includes(m) ? '' : 'sec'" @click="ponerMod(m)">{{m}}</button></div>
      <Field label="Observación para cocina o bar" help="Sale en la comanda y entre paréntesis en el comprobante"><input v-model="lineaNota.texto" maxlength="120" @keyup.enter="guardarNota" placeholder="Sin cebolla, término medio…"></Field>
      <template #foot><button class="btn ghost" @click="lineaNota=null">Cancelar</button><button class="btn" @click="guardarNota">Guardar</button></template>
    </Modal>

    <Modal v-if="dividir" title="Dividir la cuenta o pasar platos a otra mesa" @close="dividir=null">
      <div class="seg" style="margin-bottom:10px"><button :class="{on: dividir.modo==='articulos'}" @click="dividir.modo='articulos'">Por platos</button><button :class="{on: dividir.modo==='partes'}" @click="dividir.modo='partes'">En partes iguales</button></div>
      <template v-if="dividir.modo==='articulos'">
        <table class="tbl"><thead><tr><th></th><th>Plato</th><th class="num">En la cuenta</th><th class="num">Pasar</th></tr></thead>
          <tbody><tr v-for="(l,i) in lineas" :key="i"><td><input type="checkbox" :checked="(dividir.sel[i] || 0) > 0" @change="toggleSel(i, $event.target.checked)"></td><td>{{l.detalle}}<div class="small muted" v-if="l.nota">{{l.nota}}</div></td><td class="num">{{fmtCant(l.cantidad)}}</td><td class="num"><input class="inp mini" type="number" min="0" :max="l.cantidad" step="1" v-model.number="dividir.sel[i]" style="width:70px;text-align:right"></td></tr></tbody></table>
        <Field label="A dónde" style="margin-top:10px"><select v-model="dividir.destino"><option value="cobrar" v-if="esRestaurante && mesaActual">Cobrar ahora solo estos platos (el resto sigue en la mesa)</option><option value="nueva">Una cuenta aparte (para cobrarla por separado)</option><template v-for="m in mesas" :key="m.id"><option v-if="!mesaActual || m.id !== mesaActual.id" :value="m.id">{{m.nombre}}{{cuentaDeMesaId(m.id) ? (cuentaDeMesaId(m.id).id === esperaId ? ' (unida a esta cuenta)' : ' (tiene cuenta abierta: se juntan)') : ''}}</option></template></select></Field>
      </template>
      <template v-else>
        <Field label="¿En cuántas partes iguales?"><input type="number" min="2" max="12" v-model.number="dividir.partes" style="width:120px" :disabled="!!partesCuenta"></Field>
        <p class="small muted" style="margin:6px 0 0" v-if="esRestaurante && mesaActual">Se cobra ahora la primera parte (la fracción de cada plato, por ejemplo ½ pizza) con su propio tiquete; el resto se queda en la mesa y se cobra parte por parte con el botón «Cobrar parte». La mesa se libera al cobrar la última.</p>
        <p class="small muted" style="margin:6px 0 0" v-else>Cada parte queda como una cuenta aparte con la fracción de cada plato (por ejemplo ½ pizza) y se cobra por separado; esta cuenta conserva la parte 1.</p>
      </template>
      <template #foot><button class="btn ghost" @click="dividir=null">Cancelar</button><button class="btn" @click="confirmarDividir">{{dividir.modo==='partes' ? (esRestaurante && mesaActual ? 'Cobrar la parte 1' : 'Dividir') : (dividir.destino==='cobrar' ? 'Cobrar estos platos' : dividir.destino==='nueva' ? 'Separar' : 'Pasar a la mesa')}}</button></template>
    </Modal>

    <Modal v-if="elegirCuenta" :title="elegirCuenta.mesa.nombre + ': ¿cuál cuenta?'" @close="elegirCuenta=null">
      <p class="small muted" style="margin:0 0 8px">Esta mesa tiene varias cuentas abiertas (grupos que pagan aparte). Elija una o abra otra.</p>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button v-for="c in elegirCuenta.cuentas" :key="c.id" class="btn sec" style="justify-content:space-between" @click="abrirCuentaDeMesa(elegirCuenta.mesa, c)"><span>{{nombreCuentaCorto(c)}}<span class="small muted"> · {{(c.lineas||[]).length}} línea(s)</span></span><b>{{money(c.total)}}</b></button>
      </div>
      <template #foot><button class="btn ghost" @click="elegirCuenta=null">Cancelar</button><button class="btn" @click="nuevaCuentaEnMesa(elegirCuenta.mesa)">+ Otra cuenta en esta mesa</button></template>
    </Modal>

    <Modal v-if="unir" :title="'Unir mesas a ' + (nombreEspera || (mesaActual ? mesaActual.nombre : ''))" @close="unir=null">
      <p class="small muted" style="margin:0 0 8px">Las mesas unidas comparten esta cuenta y en el plano se ven ocupadas juntas. Al cobrar, o con «Separar», vuelven a quedar libres.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap"><label v-for="m in mesasLibres" :key="m.id" class="chip" :class="{on: unir.sel[m.id]}" style="cursor:pointer"><input type="checkbox" v-model="unir.sel[m.id]" style="margin:0"> {{m.nombre}}{{m.asientos ? ' · ' + m.asientos + ' 🪑' : ''}}</label></div>
      <p class="muted small" v-if="!mesasLibres.length">No hay mesas libres para unir.</p>
      <template #foot><button class="btn ghost" @click="unir=null">Cancelar</button><button class="btn" @click="confirmarUnir">Unir</button></template>
    </Modal>

    <Modal v-if="mover" :title="'Mover la cuenta de ' + (mesaActual ? mesaActual.nombre : '') + ' a…'" @close="mover=null">
      <div class="row" style="gap:8px;flex-wrap:wrap"><button v-for="m in mesasLibres" :key="m.id" class="btn sec" @click="moverA(m)">{{m.nombre}}</button></div>
      <p class="muted small" v-if="!mesasLibres.length">No hay mesas libres.</p>
    </Modal>

    <Modal v-if="apertura" title="Abrir caja" @close="apertura=null">
      <div class="grid cols-2"><Field label="Caja" req help="Se cambia en Configuración del punto de venta"><input v-model="apertura.caja" maxlength="40" disabled></Field><Field label="Efectivo inicial en la gaveta" req><input type="number" min="0" step="1" v-model.number="apertura.monto" class="mono"></Field><Field label="Notas" style="grid-column:1/-1"><input v-model="apertura.notas" maxlength="120"></Field></div>
      <p class="small muted" style="margin:8px 0 0">Las ventas de esta sesión quedan ligadas a la caja; al final del día se cierra con el conteo del efectivo en Cierres de caja.</p>
      <template #foot><button class="btn ghost" @click="apertura=null">Después</button><button class="btn" @click="confirmarApertura">Abrir caja</button></template>
    </Modal>

    <Modal v-if="retiro" title="Salida de efectivo" @close="retiro=null">
      <div class="tabs" style="margin-bottom:10px"><button type="button" :class="{on: retiro.tipo==='retiro'}" @click="retiro.tipo='retiro'">Retiro o depósito</button><button type="button" :class="{on: retiro.tipo==='proveedor'}" @click="retiro.tipo='proveedor'">Pago a proveedor</button></div>
      <div class="grid cols-2" v-if="retiro.tipo==='retiro'"><Field label="Monto" req><input type="number" min="0" step="1" v-model.number="retiro.monto" class="mono"></Field><Field label="Motivo" req><input v-model="retiro.motivo" placeholder="Depósito al banco, compra de hielo…"></Field>
        <Field label="Depositar en" help="Si el efectivo va al banco, elija la cuenta: en Bancos sale de la caja y entra ahí. Vacío = gasto o salida que no va a Bancos" style="grid-column:1/-1"><select v-model="retiro.cuenta_destino"><option value="">— No va a una cuenta —</option><option v-for="b in cuentasBanco()" :key="b.nombre" :value="b.nombre">{{b.nombre}}</option></select></Field></div>
      <div class="grid cols-2" v-else>
        <Field label="Proveedor" req><input v-model="retiro.proveedor" list="pos-proveedores" placeholder="Nombre del proveedor" @change="elegirProveedor"><datalist id="pos-proveedores"><option v-for="p in proveedoresCaja()" :key="p.id" :value="p.nombre"></option></datalist></Field>
        <Field label="Factura o documento"><input v-model="retiro.documento" maxlength="60" placeholder="Número de la factura del proveedor"></Field>
        <Field label="Monto" req><input type="number" min="0" step="1" v-model.number="retiro.monto" class="mono"></Field>
        <Field label="Aplicar a la compra" v-if="comprasPendientes().length" help="La factura de compra registrada que se rebaja con este pago"><select v-model="retiro.compra_id"><option value="">— Sin aplicar (gasto) —</option><option v-for="c in comprasPendientes()" :key="c.id" :value="c.id">{{c.numero || ('Compra ' + c.id)}} · debe {{money((+c.total || 0) - (+c.pagado || 0))}}</option></select></Field>
        <label v-if="sesion.puede('gastos')" class="row" style="grid-column:1/-1;gap:8px;cursor:pointer"><input type="checkbox" v-model="retiro.registrar"> Registrar también el pago en Gastos › Pagos a proveedores (sale de la caja de efectivo en Bancos)</label>
        <p v-else class="small muted" style="grid-column:1/-1;margin:0">Queda en el cierre de caja como pago a proveedor; la administración lo registra en Gastos.</p>
      </div>
      <template #foot><button class="btn ghost" @click="retiro=null">Cancelar</button><button class="btn" @click="confirmarRetiro">Registrar</button></template>
    </Modal>

    <Modal v-if="entrada" title="Entrada de efectivo" @close="entrada=null">
      <div class="grid cols-2"><Field label="Monto" req><input type="number" min="0" step="1" v-model.number="entrada.monto" class="mono"></Field><Field label="Motivo" req><input v-model="entrada.motivo" maxlength="120" placeholder="Sencillo, fondo adicional, otro ingreso…"></Field>
        <Field label="Viene de" help="Si el efectivo sale de una cuenta (por ejemplo, sencillo cambiado en el banco), elíjala: en Bancos sale de ahí y entra a la caja. Vacío = no viene de una cuenta" style="grid-column:1/-1"><select v-model="entrada.cuenta_origen"><option value="">— No viene de una cuenta —</option><option v-for="b in cuentasBanco()" :key="b.nombre" :value="b.nombre">{{b.nombre}}</option></select></Field></div>
      <template #foot><button class="btn ghost" @click="entrada=null">Cancelar</button><button class="btn" @click="confirmarEntrada">Registrar</button></template>
    </Modal>
  </div>`,
  setup() { return { store, sesion, modificadores }; },
};
