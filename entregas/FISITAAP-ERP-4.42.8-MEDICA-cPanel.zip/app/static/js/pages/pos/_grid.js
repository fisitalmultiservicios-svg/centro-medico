// Punto de venta › Caja: cuadrícula de productos y combos (4.6). Va en un componente aparte para que tocar los botones del
// carrito, agregar un plato o abrir una ventana NO redibuje los 100 o 200 productos: Vue solo vuelve a pintar esta cuadrícula
// cuando cambian los productos filtrados, el cliente (sus precios), las existencias o la configuración de la caja. Cada ficha
// (imagen, precio con IVA, existencia) se calcula una vez por cambio y no en cada pintada.
import { money, fmtCant } from '../../api.js';
import { precioPara, precioConIva } from './_datos.js';

export default {
  props: {
    productos: { type: Array, default: () => [] },      // ya filtrados por la caja (categoría, búsqueda, tope de 200)
    combos: { type: Array, default: () => [] },         // promociones tipo combo vigentes, con su título ya armado
    cfg: { type: Object, default: () => ({}) },         // terminal: columnas, mostrar_imagenes, mostrar_existencias
    existencias: { type: Object, default: () => ({}) }, porciones: { type: Object, default: () => ({}) }, existenciasOk: Boolean,
    clienteId: { default: null },                       // los precios dependen de la lista de precios del cliente
    vacio: { type: String, default: 'Sin productos.' }, enlaceCrear: Boolean,
    version: { type: Number, default: 0 },           // 4.6: la caja lo sube tras cada sincronización (listas de precios, items_extra)
  },
  emits: ['agregar', 'combo'],
  computed: {
    estilo() { return { gridTemplateColumns: 'repeat(auto-fill, minmax(' + Math.max(110, Math.round(760 / (+this.cfg.columnas || 4))) + 'px, 1fr))' }; },
    fichas() {
      void this.version;
      const conImg = !!this.cfg.mostrar_imagenes, conExist = !!this.cfg.mostrar_existencias, cid = this.clienteId;
      return this.productos.map(p => {
        const st = this.stock(p);
        return { p, img: conImg && p.imagen_nombre ? '/api/productos/' + p.id + '/imagen' : '', precio: money(precioConIva(p, precioPara(p, cid))), agotado: st !== null && st <= 0 && !p.venta_negativo,
          stock: conExist && st !== null ? (this.porciones[p.id] !== undefined && this.porciones[p.id] !== null ? '≈ ' + fmtCant(st) + ' porciones' : fmtCant(st) + ' en bodega') : '', titulo: p.codigo ? 'Código ' + p.codigo : '' };
      });
    },
  },
  methods: {
    money,
    // misma regla que la caja: porciones de la receta si las hay; sin existencias cargadas = desconocido (no «agotado»)
    stock(p) { const po = this.porciones[p.id]; if (po !== undefined && po !== null) return +po; return p.es_servicio || p.inventariable === false || !this.existenciasOk ? null : +(this.existencias[p.id] ?? 0); },
  },
  template: `
  <div class="pos-grid" :style="estilo">
    <button v-for="c in combos" :key="'combo' + c.id" class="pos-prod combo" @click="$emit('combo', c)" :title="c.titulo"><span class="n">🎁 {{c.nombre}}</span><span class="p">{{money(c.combo.precio)}}</span></button>
    <button v-for="f in fichas" :key="f.p.id" class="pos-prod" :class="{agotado: f.agotado}" @click="$emit('agregar', f.p)" :title="f.titulo">
      <img v-if="f.img" :src="f.img" alt="" loading="lazy">
      <span class="n">{{f.p.nombre}}</span>
      <span class="pr">{{f.precio}}</span>
      <span class="st" v-if="f.stock">{{f.stock}}</span>
    </button>
    <div class="muted" v-if="!fichas.length" style="padding:30px;grid-column:1/-1;text-align:center">{{vacio}} <a href="#/inventario/items/nuevo" v-if="enlaceCrear">Crear ítem</a></div>
  </div>`,
};
