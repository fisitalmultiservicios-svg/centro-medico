// Punto de venta › Mercadería y conteo (3.23): inventario rápido para el supervisor de caja sin pasar por Compras contables.
// «Recibir mercadería» registra lo que llegó (cantidad y costo) como entrada a la bodega; «Conteo físico» compara lo contado con
// lo que dice el sistema y ajusta las diferencias. Las dos usan los ajustes de inventario (AJ-0001…) con el permiso de inventario.
import { api, toast, money, fmt, fmtCant, hoy, fecha } from '../../api.js';
import { store } from '../../app.js';

const r4 = n => Math.round((+n || 0) * 10000) / 10000;

export default {
  props: ['params'],
  data() { return { tab: this.params.tab || 'recibir', bodegas: [], bodega: null, lineas: [{ producto_id: null, cantidad: 1, costo: null }], nota: '', proveedor: '', guardando: false, existencias: {}, cargado: false, conteo: {}, q: '', soloContados: false, ultimo: null }; },
  computed: {
    productos() { return (store.productos || []).filter(p => p.activo !== false && p.inventariable !== false && !p.es_servicio).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')); },
    porId() { const m = {}; for (const p of this.productos) m[p.id] = p; return m; },
    totalRecibido() { return r4(this.lineas.reduce((s, l) => s + (+l.cantidad || 0) * (+l.costo || 0), 0)); },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.productos.filter(p => !q || p.nombre.toLowerCase().includes(q) || String(p.codigo || '').toLowerCase().includes(q) || String(p.categoria || '').toLowerCase().includes(q))
        .map(p => { const sistema = +(this.existencias[p.id] ?? 0), c = this.conteo[p.id], contado = c === undefined || c === null || c === '' ? null : +c; return { ...p, sistema, contado, dif: contado === null ? null : r4(contado - sistema) }; })
        .filter(f => !this.soloContados || f.contado !== null);
    },
    diferencias() { return this.filas.filter(f => f.contado !== null && Math.abs(f.dif) > 1e-9); },
    contados() { return Object.values(this.conteo).filter(v => v !== null && v !== '' && v !== undefined).length; },
  },
  methods: {
    money, fmt, fmtCant,
    async cargarExistencias() { if (!this.bodega) return; try { const l = await api('/api/inventario/existencias?bodega_id=' + this.bodega); const m = {}; for (const e of l) m[e.producto_id] = +e.cantidad || 0; this.existencias = m; this.cargado = true; } catch (e) { toast('No se pudieron leer las existencias: ' + e.message, 'err'); } },
    elegir(l) { const p = this.porId[l.producto_id]; if (p && (l.costo === null || l.costo === '')) l.costo = +p.costo || null; },
    agregarLinea() { this.lineas.push({ producto_id: null, cantidad: 1, costo: null }); },
    async recibir() {
      const ls = this.lineas.filter(l => l.producto_id && +l.cantidad > 0);
      if (!ls.length) return toast('Agregue al menos un producto con cantidad', 'err');
      this.guardando = true;
      try {
        // 3.75: entra como compra (CO-####) con su capa de costo; sin costo digitado va el de referencia del ítem
        const r = await api('/api/inventario/compras', { method: 'POST', body: { bodega_id: this.bodega || null, fecha: hoy(), proveedor: this.proveedor || null, observaciones: ['Recepción de mercadería en caja', this.nota].filter(Boolean).join(' · ').slice(0, 200), lineas: ls.map(l => ({ producto_id: l.producto_id, cantidad: +l.cantidad, costo_unitario: l.costo === null || l.costo === '' ? (+(this.porId[l.producto_id] || {}).costo || 0) : +l.costo })) } });
        this.ultimo = { codigo: r.codigo || r.numero || '', n: ls.length, total: this.totalRecibido };
        this.lineas = [{ producto_id: null, cantidad: 1, costo: null }]; this.nota = ''; this.proveedor = '';
        toast('Mercadería recibida: ' + ls.length + ' producto(s) entraron a la bodega', 'ok'); this.cargarExistencias();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async ajustarConteo() {
      const d = this.diferencias;
      if (!d.length) return toast('No hay diferencias que ajustar', 'err');
      if (!confirm('¿Ajustar ' + d.length + ' producto(s) para que el sistema quede igual al conteo?')) return;
      this.guardando = true;
      try {
        const r = await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: this.bodega || null, fecha: hoy(), observaciones: ('Conteo físico ' + fecha(hoy()) + (this.nota ? ' · ' + this.nota : '')).slice(0, 200), lineas: d.map(f => ({ producto_id: f.id, tipo: f.dif > 0 ? 'incremento' : 'disminucion', cantidad: Math.abs(f.dif) })) } });
        toast('Conteo aplicado (' + (r.codigo || '') + '): ' + d.length + ' producto(s) ajustados', 'ok');
        this.conteo = {}; this.nota = ''; await this.cargarExistencias();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    try { this.bodegas = await api('/api/inventario/bodegas'); this.bodega = (this.bodegas.find(b => b.principal) || this.bodegas[0] || {}).id || null; } catch {}
    this.cargarExistencias();
  },
  template: `
  <div class="page">
    <PageHead title="Mercadería y conteo" sub="Registre lo que llegó y cuente lo que hay, sin pasar por las compras contables." :crumbs="[{label:'Punto de venta'},{label:'Mercadería y conteo'}]">
      <select class="inp" v-model="bodega" @change="cargarExistencias" v-if="bodegas.length > 1"><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select>
    </PageHead>
    <div class="seg" style="margin-bottom:10px"><button :class="{on: tab==='recibir'}" @click="tab='recibir'">Recibir mercadería</button><button :class="{on: tab==='conteo'}" @click="tab='conteo'">Conteo físico</button></div>
    <div class="card" v-if="tab==='recibir'">
      <p class="small muted" style="margin:0 0 10px">Lo que llegó del proveedor entra a la bodega con su costo; si la factura del proveedor se registra después en Gastos, no repita la entrada aquí.</p>
      <div class="alert ok" v-if="ultimo">Última recepción {{ultimo.codigo}}: {{ultimo.n}} producto(s) por {{money(ultimo.total)}}.</div>
      <div class="grid cols-2" style="margin-bottom:8px"><Field label="Proveedor"><input v-model="proveedor" maxlength="80" placeholder="Opcional"></Field><Field label="Nota"><input v-model="nota" maxlength="120" placeholder="Factura, guía, observación…"></Field></div>
      <table class="tbl"><thead><tr><th>Producto</th><th class="num" style="width:120px">Cantidad</th><th class="num" style="width:140px">Costo unitario</th><th class="num" style="width:120px">Total</th><th style="width:40px"></th></tr></thead><tbody>
        <tr v-for="(l, i) in lineas" :key="i"><td><Buscador v-model="l.producto_id" :opciones="productos" detalle="unidad_medida" vacio="Elegir" agregar="item" @change="elegir(l)"></Buscador></td>
          <td class="num"><input type="number" class="inp" min="0" step="0.01" v-model.number="l.cantidad" style="width:100%;text-align:right"></td>
          <td class="num"><input type="number" class="inp" min="0" step="0.01" v-model.number="l.costo" style="width:100%;text-align:right" placeholder="sin costo"></td>
          <td class="num">{{money((+l.cantidad || 0) * (+l.costo || 0))}}</td><td><button class="btn icon" @click="lineas.splice(i, 1)" v-if="lineas.length > 1">✕</button></td></tr></tbody></table>
      <div class="row" style="justify-content:space-between;margin-top:10px;flex-wrap:wrap;gap:8px"><button class="btn sm sec" @click="agregarLinea">+ Producto</button><span><b>Total {{money(totalRecibido)}}</b></span><button class="btn" @click="recibir" :disabled="guardando">Registrar la entrada</button></div>
    </div>
    <div class="card" v-else>
      <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px"><input class="search" style="flex:1;min-width:200px" v-model="q" placeholder="Buscar producto, código o categoría"><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="soloContados"> Solo contados</label><span class="small muted">{{contados}} contados · {{diferencias.length}} con diferencia</span></div>
      <Empty v-if="!filas.length" icon="📦" title="Sin productos inventariables"></Empty>
      <div class="table-wrap" v-else style="max-height:60vh;overflow:auto"><table class="tbl"><thead><tr><th>Producto</th><th>Categoría</th><th class="num">Sistema</th><th class="num" style="width:130px">Contado</th><th class="num">Diferencia</th></tr></thead><tbody>
        <tr v-for="f in filas" :key="f.id"><td><b>{{f.nombre}}</b><div class="small muted" v-if="f.codigo">{{f.codigo}}</div></td><td class="small">{{f.categoria || '—'}}</td><td class="num">{{fmtCant(f.sistema)}} {{f.unidad_medida || ''}}</td>
          <td class="num"><input type="number" class="inp" min="0" step="0.01" :value="conteo[f.id]" @input="conteo = { ...conteo, [f.id]: $event.target.value }" style="width:110px;text-align:right"></td>
          <td class="num" :style="f.dif === null ? '' : (Math.abs(f.dif) < 1e-9 ? 'color:var(--ok)' : 'color:var(--danger);font-weight:600')">{{f.dif === null ? '—' : (f.dif > 0 ? '+' : '') + fmtCant(f.dif)}}</td></tr></tbody></table></div>
      <div class="row" style="justify-content:space-between;margin-top:10px;flex-wrap:wrap;gap:8px"><input class="inp" v-model="nota" maxlength="120" placeholder="Nota del conteo (opcional)" style="flex:1;min-width:200px"><button class="btn" @click="ajustarConteo" :disabled="guardando || !diferencias.length">Ajustar {{diferencias.length}} diferencia(s)</button></div>
    </div>
  </div>`,
};
