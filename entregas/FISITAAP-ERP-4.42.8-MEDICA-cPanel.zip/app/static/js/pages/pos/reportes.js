// Punto de venta › Reportes de la caja (3.23): ventas por producto, por categoría, por hora y por día de la semana a partir de
// las ventas registradas en las sesiones de caja (pos_ventas). Vive dentro del plan Punto de venta (no requiere Reportes ni
// Contabilidad). Las ventas anteriores a la 3.23 no guardaban sus líneas: cuentan en hora y día, no en producto ni categoría.
import { money, fmt, fecha, hoy, mock, toast } from '../../api.js';
import { descargarReporte, imprimirReporte, impresorasReporte, descargarTabla, cargarImpresorasReporte } from '../reportes/_montos.js';
import { store } from '../../app.js';
import { posVentas, terminales, cajas } from './_datos.js';
import { avisoImpresion } from './_agente.js';   // 9c (J4): el aviso sin repetir la impresora

const r2 = n => Math.round((+n || 0) * 100) / 100;
const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const fechaLocal = iso => { const d = new Date(iso); if (isNaN(d)) return String(iso || '').slice(0, 10); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

export default {
  props: ['params'],
  data() { const h = hoy(); return { listo: false, desde: this.params.desde || h.slice(0, 8) + '01', hasta: this.params.hasta || h, terminal: '', tab: this.params.tab || 'producto', terms: terminales(), impsListas: false }; },
  async created() { if (await mock.completar('pos_ventas')) this.listo = true; },
  mounted() { cargarImpresorasReporte().then(() => { this.impsListas = true; }); },   // 9c (J1): en el programa, las impresoras como valen en esta computadora   // las ventas de más de 90 días no vienen al entrar (3.73): aquí sí hacen falta
  computed: {
    ventas() {
      this.listo;   // se recalcula cuando llega el historial completo (3.73)
      const porCaja = {}; for (const c of cajas()) porCaja[c.id] = c;
      return posVentas().filter(v => !v.anulada && !v.abono && v.tipo !== 'abono').map(v => ({ ...v, dia: fechaLocal(v.hora), terminal_id: (porCaja[v.caja_id] || {}).terminal_id || null }))
        .filter(v => v.dia >= this.desde && v.dia <= this.hasta && (!this.terminal || v.terminal_id === +this.terminal));
    },
    sinLineas() { return this.ventas.filter(v => !Array.isArray(v.lineas)).length; },
    porProducto() {
      const m = {};
      for (const v of this.ventas) for (const l of (v.lineas || [])) { const k = l.producto_id || l.detalle; const o = m[k] || (m[k] = { nombre: l.detalle, categoria: l.categoria || '—', cantidad: 0, neto: 0, total: 0, ventas: 0 }); const neto = r2((+l.cantidad || 0) * (+l.precio || 0) - (+l.descuento || 0)); o.cantidad = r2(o.cantidad + (+l.cantidad || 0)); o.neto = r2(o.neto + neto); o.total = r2(o.total + neto * (1 + (+l.tarifa || 0) / 100)); o.ventas++; }
      return Object.values(m).sort((a, b) => b.total - a.total);
    },
    porCategoria() {
      const m = {}; for (const p of this.porProducto) { const o = m[p.categoria] || (m[p.categoria] = { categoria: p.categoria, productos: 0, cantidad: 0, total: 0 }); o.productos++; o.cantidad = r2(o.cantidad + p.cantidad); o.total = r2(o.total + p.total); }
      const tot = Object.values(m).reduce((s, x) => s + x.total, 0);
      return Object.values(m).map(x => ({ ...x, pct: tot ? Math.round(x.total / tot * 100) : 0 })).sort((a, b) => b.total - a.total);
    },
    porHora() {
      const m = {}; for (const v of this.ventas) { const h = new Date(v.hora).getHours(); const o = m[h] || (m[h] = { hora: h, ventas: 0, total: 0 }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); }
      return Object.values(m).sort((a, b) => a.hora - b.hora).map(x => ({ ...x, etiqueta: String(x.hora).padStart(2, '0') + ':00 – ' + String(x.hora).padStart(2, '0') + ':59', promedio: x.ventas ? r2(x.total / x.ventas) : 0 }));
    },
    porDia() {
      const m = {}, dias = new Set(); for (const v of this.ventas) { const d = new Date(v.hora).getDay(); dias.add(v.dia + ':' + d); const o = m[d] || (m[d] = { dia: d, nombre: DIAS[d], ventas: 0, total: 0, fechas: new Set() }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); o.fechas.add(v.dia); }
      return Object.values(m).sort((a, b) => (a.dia || 7) - (b.dia || 7)).map(x => ({ ...x, dias_n: x.fechas.size, promedio_dia: x.fechas.size ? r2(x.total / x.fechas.size) : 0, ticket: x.ventas ? r2(x.total / x.ventas) : 0 }));
    },
    maxHora() { return Math.max(1, ...this.porHora.map(x => x.total)); },
    // 3.58: ventas por fecha del período (reporte mínimo de ventas para el plan Punto de venta básico, sin el módulo Reportes)
    porFecha() {
      const m = {}; for (const v of this.ventas) { const o = m[v.dia] || (m[v.dia] = { dia: v.dia, ventas: 0, total: 0, items: 0 }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); o.items = r2(o.items + (+v.items || 0)); }
      return Object.values(m).sort((a, b) => a.dia.localeCompare(b.dia)).map(x => ({ ...x, ticket: x.ventas ? r2(x.total / x.ventas) : 0 }));
    },
    maxFecha() { return Math.max(1, ...this.porFecha.map(x => x.total)); },
    totales() { const t = r2(this.ventas.reduce((s, v) => s + (+v.total || 0), 0)); return { ventas: this.ventas.length, total: t, ticket: this.ventas.length ? r2(t / this.ventas.length) : 0, items: r2(this.ventas.reduce((s, v) => s + (+v.items || 0), 0)) }; },
  },
  methods: {
    money, fmt, fecha,
    rapido(q) { const h = hoy(); if (q === 'hoy') { this.desde = h; this.hasta = h; } else if (q === 'semana') { const d = new Date(h + 'T12:00:00'); d.setDate(d.getDate() - 6); this.desde = fechaLocal(d.toISOString()); this.hasta = h; } else if (q === 'mes') { this.desde = h.slice(0, 8) + '01'; this.hasta = h; } },
    secciones() {
      const M = v => money(v || 0);
      return [
        { titulo: 'Por fecha', columnas: [{ key: 'dia', label: 'Fecha' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'items', label: 'Artículos', num: true }, { key: 'total', label: 'Vendido', num: true }, { key: 'ticket', label: 'Ticket promedio', num: true }], filas: this.porFecha.map(x => ({ ...x, dia: fecha(x.dia), items: fmt(x.items, 2), total: M(x.total), ticket: M(x.ticket) })) },
        { titulo: 'Por producto', columnas: [{ key: 'nombre', label: 'Producto' }, { key: 'categoria', label: 'Categoría' }, { key: 'cantidad', label: 'Cantidad', num: true }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true }], filas: this.porProducto.map(x => ({ ...x, cantidad: fmt(x.cantidad, 2), total: M(x.total) })) },
        { titulo: 'Por categoría', columnas: [{ key: 'categoria', label: 'Categoría' }, { key: 'productos', label: 'Productos', num: true }, { key: 'cantidad', label: 'Cantidad', num: true }, { key: 'total', label: 'Vendido', num: true }, { key: 'pct', label: '%', num: true }], filas: this.porCategoria.map(x => ({ ...x, cantidad: fmt(x.cantidad, 2), total: M(x.total), pct: x.pct + ' %' })) },
        { titulo: 'Por hora', columnas: [{ key: 'etiqueta', label: 'Hora' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true }, { key: 'promedio', label: 'Ticket promedio', num: true }], filas: this.porHora.map(x => ({ ...x, total: M(x.total), promedio: M(x.promedio) })) },
        { titulo: 'Por día de la semana', columnas: [{ key: 'nombre', label: 'Día' }, { key: 'dias_n', label: 'Días con venta', num: true }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true }, { key: 'promedio_dia', label: 'Promedio por día', num: true }, { key: 'ticket', label: 'Ticket promedio', num: true }], filas: this.porDia.map(x => ({ ...x, total: M(x.total), promedio_dia: M(x.promedio_dia), ticket: M(x.ticket) })) },
      ];
    },
    async imprimir(imp) {   // 4.3: impresora de tiquetes o la del equipo
      try { const d = await imprimirReporte({ titulo: 'Ventas de la caja', subtitulo: 'Por producto, categoría, hora y día de la semana', periodo: fecha(this.desde) + ' al ' + fecha(this.hasta), kpis: [{ t: 'Ventas', v: String(this.totales.ventas) }, { t: 'Vendido', v: money(this.totales.total) }, { t: 'Ticket promedio', v: money(this.totales.ticket) }], cols: [], rows: [], secciones: this.secciones() }, imp || null, store.empresa); if (d === 'agente') toast('Reporte enviado a «' + imp.nombre + '»', 'ok'); }
      catch (e) { toast(avisoImpresion('No se imprimió: ', e), 'err'); }
    },
    impresorasLista() { return this.impsListas ? impresorasReporte() : []; },   // 9c (J1): después de cargar lo de esta computadora
    descargar(formato) {
      const t = this.totales;
      if (formato === 'csv' || formato === 'xlsx') { const s = this.secciones().find(x => (this.tab === 'fecha' && x.titulo === 'Por fecha') || (this.tab === 'producto' && x.titulo === 'Por producto') || (this.tab === 'categoria' && x.titulo === 'Por categoría') || (this.tab === 'hora' && x.titulo === 'Por hora') || (this.tab === 'dia' && x.titulo === 'Por día de la semana')); return descargarTabla(formato, 'ventas-caja-' + this.tab, s.columnas, s.filas); }
      return descargarReporte(formato, { titulo: 'Ventas de la caja', subtitulo: 'Por producto, categoría, hora y día de la semana', periodo: fecha(this.desde) + ' al ' + fecha(this.hasta), kpis: [{ t: 'Ventas', v: String(t.ventas) }, { t: 'Vendido', v: money(t.total) }, { t: 'Ticket promedio', v: money(t.ticket) }], secciones: this.secciones(), archivo: 'ventas-caja', nota: this.sinLineas ? this.sinLineas + ' venta(s) anteriores a esta versión no traen el detalle por producto.' : '' });
    },
  },
  template: `
  <div class="page">
    <ReportesTabs></ReportesTabs>
    <PageHead title="Reportes de la caja" :sub="totales.ventas + ' ventas · ' + money(totales.total) + ' · ticket promedio ' + money(totales.ticket)" :crumbs="[{label:'Punto de venta'},{label:'Reportes de la caja'}]">
      <button class="btn sec" @click="imprimir()" title="Imprimir: el navegador deja elegir la impresora">⎙ Imprimir</button><button class="btn sec" v-for="i in impresorasLista()" :key="i.id" @click="imprimir(i)" :title="'Imprimir en la impresora de tiquetes ' + i.nombre">⎙ {{i.nombre}}</button><button class="btn sec" @click="descargar('pdf')">PDF</button><button class="btn sec" @click="descargar('docx')">Word</button><button class="btn sec" @click="descargar('xlsx')">Excel</button><button class="btn sec" @click="descargar('csv')">CSV</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
      <span class="small muted">Período:</span><input type="date" class="inp" v-model="desde"><input type="date" class="inp" v-model="hasta" :min="desde">
      <button class="btn sm sec" @click="rapido('hoy')">Hoy</button><button class="btn sm sec" @click="rapido('semana')">7 días</button><button class="btn sm sec" @click="rapido('mes')">Mes</button>
      <select class="inp" v-model="terminal" v-if="terms.length > 1"><option value="">Todas las cajas</option><option v-for="t in terms" :key="t.id" :value="t.id">{{t.nombre}}</option></select>
    </div></div>
    <div class="alert info" v-if="sinLineas">{{sinLineas}} venta(s) de antes de esta versión no traen el detalle por producto: cuentan en «Por hora» y «Por día», no en «Por producto» ni «Por categoría».</div>
    <div class="seg" style="margin-bottom:10px"><button :class="{on: tab==='fecha'}" @click="tab='fecha'">Por fecha</button><button :class="{on: tab==='producto'}" @click="tab='producto'">Por producto</button><button :class="{on: tab==='categoria'}" @click="tab='categoria'">Por categoría</button><button :class="{on: tab==='hora'}" @click="tab='hora'">Por hora</button><button :class="{on: tab==='dia'}" @click="tab='dia'">Por día de la semana</button></div>
    <div class="card">
      <template v-if="tab==='fecha'">
        <Empty v-if="!porFecha.length" icon="📆" title="Sin ventas en el período"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Fecha</th><th class="num">Ventas</th><th class="num">Artículos</th><th class="num">Vendido</th><th class="num">Ticket promedio</th><th style="width:30%"></th></tr></thead><tbody>
          <tr v-for="d in porFecha" :key="d.dia"><td><b>{{fecha(d.dia)}}</b></td><td class="num">{{d.ventas}}</td><td class="num">{{fmt(d.items, 2)}}</td><td class="num"><b>{{money(d.total)}}</b></td><td class="num">{{money(d.ticket)}}</td><td><div class="bar"><i :style="{width: Math.round(d.total / maxFecha * 100) + '%'}"></i></div></td></tr>
          <tr><td><b>Total</b></td><td class="num"><b>{{totales.ventas}}</b></td><td class="num"><b>{{fmt(totales.items, 2)}}</b></td><td class="num"><b>{{money(totales.total)}}</b></td><td class="num">{{money(totales.ticket)}}</td><td></td></tr></tbody></table></div>
      </template>
      <template v-else-if="tab==='producto'">
        <Empty v-if="!porProducto.length" icon="🛒" title="Sin ventas con detalle en el período"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Producto</th><th>Categoría</th><th class="num">Cantidad</th><th class="num">Ventas</th><th class="num">Vendido</th><th style="width:30%"></th></tr></thead><tbody>
          <tr v-for="p in porProducto" :key="p.nombre"><td><b>{{p.nombre}}</b></td><td>{{p.categoria}}</td><td class="num">{{fmt(p.cantidad, 2)}}</td><td class="num">{{p.ventas}}</td><td class="num"><b>{{money(p.total)}}</b></td><td><div class="bar"><i :style="{width: Math.round(p.total / porProducto[0].total * 100) + '%'}"></i></div></td></tr></tbody></table></div>
      </template>
      <template v-else-if="tab==='categoria'">
        <Empty v-if="!porCategoria.length" icon="🛒" title="Sin ventas con detalle en el período"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Categoría</th><th class="num">Productos</th><th class="num">Cantidad</th><th class="num">Vendido</th><th class="num">%</th><th style="width:30%"></th></tr></thead><tbody>
          <tr v-for="c in porCategoria" :key="c.categoria"><td><b>{{c.categoria}}</b></td><td class="num">{{c.productos}}</td><td class="num">{{fmt(c.cantidad, 2)}}</td><td class="num"><b>{{money(c.total)}}</b></td><td class="num">{{c.pct}} %</td><td><div class="bar"><i :style="{width: c.pct + '%'}"></i></div></td></tr></tbody></table></div>
      </template>
      <template v-else-if="tab==='hora'">
        <Empty v-if="!porHora.length" icon="🕐" title="Sin ventas en el período"></Empty>
        <template v-else>
          <div class="chart" style="height:160px;margin-bottom:12px"><div class="b" v-for="h in porHora" :key="h.hora"><i :style="{height: Math.max(3, Math.round(h.total / maxHora * 100)) + '%'}" :title="h.etiqueta + ': ' + money(h.total)"></i>{{String(h.hora).padStart(2, '0')}}h</div></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Hora</th><th class="num">Ventas</th><th class="num">Vendido</th><th class="num">Ticket promedio</th></tr></thead><tbody><tr v-for="h in porHora" :key="h.hora"><td>{{h.etiqueta}}</td><td class="num">{{h.ventas}}</td><td class="num"><b>{{money(h.total)}}</b></td><td class="num">{{money(h.promedio)}}</td></tr></tbody></table></div>
        </template>
      </template>
      <template v-else>
        <Empty v-if="!porDia.length" icon="📅" title="Sin ventas en el período"></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Día</th><th class="num">Días con venta</th><th class="num">Ventas</th><th class="num">Vendido</th><th class="num">Promedio por día</th><th class="num">Ticket promedio</th></tr></thead><tbody>
          <tr v-for="d in porDia" :key="d.dia"><td><b>{{d.nombre}}</b></td><td class="num">{{d.dias_n}}</td><td class="num">{{d.ventas}}</td><td class="num"><b>{{money(d.total)}}</b></td><td class="num">{{money(d.promedio_dia)}}</td><td class="num">{{money(d.ticket)}}</td></tr></tbody></table></div>
      </template>
    </div>
  </div>`,
};
