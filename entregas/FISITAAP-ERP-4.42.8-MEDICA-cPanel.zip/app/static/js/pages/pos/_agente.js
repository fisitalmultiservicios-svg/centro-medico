// Impresión térmica directa (3.11/3.12): comandas, tiquetes y gaveta en las impresoras USB o de red. Dos caminos, el mismo documento
// de bloques (texto, par, item, linea, qr):
//   - instalación local: el propio sistema imprime (/api/agente/*), un solo programa en la computadora;
//   - sistema en la nube: el agente de impresión suelto en http://127.0.0.1:9800.
// Se prueba primero el camino local; si la nube responde 404 se usa el agente. Si nada responde, la caja imprime por el navegador.
import { api, fmt, fecha } from '../../api.js';
const ZONA_CR = 'America/Costa_Rica';   // 4.41: la hora de la colilla en Costa Rica, sin importar la zona de la computadora

export const URL_AGENTE = 'http://127.0.0.1:9800';
let _estado = { ok: false, hora: 0, info: null, via: null };   // via: 'local' | 'agente'

export function porAgente(imp) { return !!imp && (imp.conexion === 'usb' || imp.conexion === 'red'); }
// 4.31: { soloAgente: true } (estación de comandas en la página web) no pregunta al servidor (/api/agente/estado): solo al 9800 de esta computadora
export async function agenteEstado(forzar, opciones) {
  const soloAgente = !!(opciones && opciones.soloAgente);
  if (!forzar && Date.now() - _estado.hora < 20000 && (!soloAgente || _estado.via === 'agente')) return _estado;
  if (!soloAgente) { try { const info = await api('/api/agente/estado'); if (info && info.agente) { _estado = { ok: true, hora: Date.now(), info, via: 'local' }; return _estado; } } catch { /* nube: sigue con el agente suelto */ } }
  try { const r = await fetch(URL_AGENTE + '/estado', { signal: AbortSignal.timeout(1500) }); _estado = { ok: r.ok, hora: Date.now(), info: r.ok ? await r.json() : null, via: 'agente' }; }
  catch { _estado = { ok: false, hora: Date.now(), info: null, via: 'agente' }; }
  return _estado;
}
// 4.31: lo último que esta pestaña ya sabe del servicio de impresión, sin preguntar a nadie (la estación de comandas lo mira antes de
// decidir si una impresora sale directo: si el 9800 ya dijo que es el programa 4.31, lee primero los ajustes de esta computadora)
export function ultimoEstadoAgente() { return _estado; }
async function pedir(ruta, cuerpo) {
  if (!_estado.via) await agenteEstado(true);
  if (_estado.via === 'local') {
    try { return await api('/api/agente' + ruta, { method: 'POST', body: cuerpo }); }
    catch (e) { const x = new Error(e.message || 'No se pudo imprimir'); x.rechazo = !!e.status; throw x; }   // 4.24: rechazo = el servicio respondió con un motivo (no es que no responda)
  }
  let r;
  try { r = await fetch(URL_AGENTE + ruta, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo), signal: AbortSignal.timeout(10000) }); }
  catch { _estado = { ok: false, hora: Date.now(), info: null, via: 'agente' }; throw new Error('El agente de impresión no responde en esta computadora'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.ok) { const x = new Error(j.error || 'El agente no pudo imprimir'); x.rechazo = true; throw x; }
  _estado.ok = true; _estado.hora = Date.now();
  return j;
}
// 9c (J4): el aviso de una impresión que no salió. Si el mensaje del servicio ya nombra la impresora («La impresora «X» no responde…»,
// «Windows no …»), se muestra solo; si no, con el prefijo de la pantalla («No se imprimió en «X»: »). LA ayuda común de todas las pantallas.
export function nombraImpresora(mensaje) { return /^(La impresora «|Windows no)/.test(String(mensaje || '').trim()); }
export function avisoImpresion(prefijo, e) { const m = String((e && e.message !== undefined ? e.message : e) || ''); return nombraImpresora(m) ? m : String(prefijo || '') + m; }
const datosImp = imp =>({ nombre: imp.nombre, conexion: imp.conexion, direccion: imp.direccion || '', ancho: +imp.ancho === 58 ? 58 : 80 });
export function imprimirAgente(imp, documento) { return pedir('/imprimir', { impresora: datosImp(imp), documento: { ancho: datosImp(imp).ancho, ...paraTermica(documento) } }); }
/* 4.41: la impresora térmica (página de códigos CP858) no tiene «₡» ni las rayas largas y salían como «?». Antes de mandar el trabajo se cambian por
   «¢» y «-» (también los espacios especiales y las comillas tipográficas); así sale bien aunque el agente de impresión sea uno anterior. El QR no se toca. */
const TERMICA = { '₡': '¢', '—': '-', '–': '-', '−': '-', '‑': '-', '…': '...', '“': '"', '”': '"', '„': '"', '‘': "'", '’': "'", ' ': ' ', ' ': ' ', ' ': ' ', '•': '·' };
const RE_TERMICA = /[₡—–−‑…“”„‘’   •]/g;
export function textoTermica(s) { return typeof s === 'string' ? s.replace(RE_TERMICA, ch => TERMICA[ch]) : s; }
export function paraTermica(documento) {
  if (!documento || !Array.isArray(documento.bloques)) return documento;
  const bloques = documento.bloques.map(bl => {
    if (!bl || typeof bl !== 'object' || !['texto', 'par', 'item'].includes(bl.t || 'texto')) return bl;
    const x = { ...bl };
    for (const k of ['x', 'i', 'd', 'cant']) if (typeof x[k] === 'string') x[k] = textoTermica(x[k]);
    if (Array.isArray(x.notas)) x.notas = x.notas.map(textoTermica);
    return x;
  });
  return { ...documento, bloques };
}
export function probarAgente(imp) { return pedir('/prueba', { impresora: datosImp(imp) }); }
export function abrirGaveta(imp) { return pedir('/gaveta', { impresora: datosImp(imp) }); }
// 4.24: etiquetas de productos directo a la impresora de etiquetas (TSPL o ZPL). Va por la misma ruta de imprimir; el trabajo son solo
// datos (nombre, código, precio, copias y medidas) y el servicio de impresión arma las órdenes de la impresora. Solo lo entiende el
// programa nuevo (su estado trae `etiquetas`): a uno anterior no se le manda, porque lo imprimiría como un tiquete vacío.
export function sabeEtiquetas(estado) { return !!(estado && estado.ok && estado.info && estado.info.etiquetas); }
export function imprimirEtiquetas(imp, trabajo) { return pedir('/imprimir', { impresora: { nombre: imp.nombre, conexion: imp.conexion, direccion: imp.direccion || '' }, etiquetas: trabajo }); }

// ---- 4.25 (tanda 8): impresión de ESTA computadora, solo en el programa de escritorio (registro equipo_impresion, /api/agente/equipo) ----
// {propias: [impresoras solo de esta computadora, id «eq-…»], ajustes: {<id de la empresa>: {conexion, direccion, densidad, separacion_mm, girar}},
//  tiquetes: <id> o '', etiquetas: <id> o ''}. En la web no se lee: solo se pide cuando el servicio de impresión es el del programa (via 'local').
let _equipo = { datos: null, web: false, hora: 0 };
export const IMPRESORAS_DE_LA_WEB = 'Las impresoras de la empresa se crean y se cambian en la página web. Aquí puede indicar cómo está conectada cada una en esta computadora, o agregar una impresora solo de esta computadora.';
export function equipoVacio() { return { propias: [], ajustes: {}, tiquetes: '', etiquetas: '' }; }
function normalEquipo(e) { const x = e && typeof e === 'object' ? e : {}; return { propias: Array.isArray(x.propias) ? x.propias.filter(i => i && i.nombre) : [], ajustes: x.ajustes && typeof x.ajustes === 'object' ? x.ajustes : {}, tiquetes: String(x.tiquetes || ''), etiquetas: String(x.etiquetas || '') }; }
// 4.31 (D-12): en la página web, si el agente del 9800 es el del programa 4.31 (su /estado trae `equipo: 1`), se leen los ajustes «En esta
// computadora» del programa en GET 127.0.0.1:9800/equipo?cedula=<cédula de la empresa> (solo lectura) y valen igual que en el programa.
// `opciones.cedula` la pasa la estación (pos/_estacion.js; este módulo no importa app.js) y se recuerda; `opciones.soloAgente` como agenteEstado.
let _cedula = '';
export function sabeEquipo(estado) { return !!(estado && estado.ok && estado.via === 'agente' && estado.info && +estado.info.equipo === 1); }
export async function cargarEquipo(forzar, opciones) {
  if (opciones && opciones.cedula !== undefined) _cedula = String(opciones.cedula || '');
  if (!forzar && _equipo.hora && Date.now() - _equipo.hora < 20000) return _equipo;
  const est = await agenteEstado(forzar, opciones);
  if (sabeEquipo(est)) {
    try {
      const r = await fetch(URL_AGENTE + '/equipo?cedula=' + encodeURIComponent(_cedula), { signal: AbortSignal.timeout(1500) });
      const j = r.ok ? await r.json() : null;
      _equipo = { datos: j && j.ok ? normalEquipo(j.equipo) : null, web: false, hora: Date.now() };
    } catch { _equipo = { datos: null, web: false, hora: Date.now() }; }
    return _equipo;
  }
  if (est.via !== 'local') { _equipo = { datos: null, web: false, hora: Date.now() }; return _equipo; }
  try { const r = await api('/api/agente/equipo'); _equipo = { datos: normalEquipo(r && r.equipo), web: !!(r && r.empresa_web), hora: Date.now() }; } catch { /* sin respuesta: queda lo anterior */ }
  return _equipo;
}
export function equipo() { return _equipo.datos; }                  // null = no es el programa (o todavía no se cargó)
export function empresaWeb() { return !!_equipo.web; }
export function ponerEquipo(datos, web) { _equipo = { datos: normalEquipo(datos), web: web === undefined ? _equipo.web : !!web, hora: Date.now() }; }
export function esPropia(i) { return !!i && String(i.id || '').startsWith('eq-'); }
// LA función que decide la impresora que vale en esta computadora (E-4): la de la empresa con sus ajustes de aquí encima, o una propia.
// La usan todos los caminos de impresión: tiquete, factura, colilla, gaveta, comandas, reportes, prueba y etiquetas.
export function impresoraAqui(imp, eq) {
  const e = eq === undefined ? _equipo.datos : eq;
  if (!imp || !e || imp.virtual || esPropia(imp)) return imp;
  const a = (e.ajustes || {})[String(imp.id)]; if (!a || typeof a !== 'object') return imp;
  const r = { ...imp };
  if (a.conexion === 'usb' || a.conexion === 'red') { r.conexion = a.conexion; r.direccion = a.direccion || ''; }
  if (imp.uso === 'etiquetas') { if (a.densidad !== undefined && a.densidad !== null && a.densidad !== '') r.densidad = +a.densidad; if (a.separacion_mm !== undefined && a.separacion_mm !== null && a.separacion_mm !== '') r.separacion_mm = +a.separacion_mm; if (typeof a.girar === 'boolean') r.girar = a.girar; }
  return r;
}
// La impresora con ese id: de la empresa (lista = pos_impresoras) o propia de esta computadora, ya como vale aquí (o null)
export function impresoraPorId(id, lista, eq) {
  const e = eq === undefined ? _equipo.datos : eq; if (id === '' || id === null || id === undefined) return null;
  const i = (lista || []).find(x => x && String(x.id) === String(id)) || (e ? (e.propias || []).find(x => String(x.id) === String(id)) : null);
  return i ? impresoraAqui(i, e) : null;
}
// Tiquetes y facturas (E-5): la elegida en esta computadora manda sobre la de la caja; vacío = la de la caja, con sus ajustes de aquí
export function impresoraTiqueteAqui(deCaja, lista, eq) {
  const e = eq === undefined ? _equipo.datos : eq;
  const i = e && e.tiquetes ? impresoraPorId(e.tiquetes, lista, e) : null;
  if (i && i.activa !== false && i.uso === 'comprobante') return i;
  return impresoraAqui(deCaja, e);
}
// Las de un uso que hay en esta computadora: las activas de la empresa (con sus ajustes) y las propias
export function impresorasAqui(lista, uso, eq) {
  const e = eq === undefined ? _equipo.datos : eq, de = i => i && i.nombre && i.activa !== false && (i.uso || 'comanda') === uso;
  return [...(lista || []).filter(de).map(i => impresoraAqui(i, e)), ...(e ? (e.propias || []).filter(de) : [])];
}

const M = v => fmt(+v || 0);
// Comanda para cocina o bar: una por impresora, solo los platos de esa ronda.
// 4.29: con `numero` (consecutivo de la comanda) sale arriba y en grande «COMANDA N.º 153»; sin número, el documento es el de siempre.
export function textoNumeroComanda(numero) { return numero ? 'COMANDA N.º ' + numero : ''; }
export function docComanda({ impresora, cuenta, ronda, salonero, caja, lineas, nota, numero }) {
  const bloques = [
    ...(numero ? [{ t: 'texto', x: textoNumeroComanda(numero), al: 'C', b: true, tam: 2 }] : []),
    { t: 'texto', x: String(impresora || 'COCINA').toUpperCase(), al: 'C', b: true, tam: 2 },
    { t: 'texto', x: (cuenta || 'Para llevar') + ' · ronda ' + ronda, al: 'C', b: true },
    { t: 'texto', x: new Date().toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) + (salonero ? ' · ' + salonero : '') + (caja ? ' · ' + caja : ''), al: 'C' },
    { t: 'linea' },
  ];
  for (const l of lineas) bloques.push({ t: 'item', cant: String(l.cantidad), x: l.detalle, notas: l.nota ? [l.nota] : [] });
  if (nota) { bloques.push({ t: 'linea' }); bloques.push({ t: 'texto', x: nota, b: true }); }
  return { bloques };
}
// Tiquete o factura con los datos del comprobante emitido (detalle del servidor) y de la empresa
export function docTiquete({ empresa, doc, cfg, recibido, vuelto, medios, cajero, nombreMedio, copia }) {
  const e = empresa || {}, mon = doc.moneda || 'CRC', lineas = doc.lineas || [];
  const titulo = { '01': 'FACTURA ELECTRÓNICA', '04': 'TIQUETE ELECTRÓNICO', '02': 'NOTA DE DÉBITO ELECTRÓNICA', '03': 'NOTA DE CRÉDITO ELECTRÓNICA' }[doc.tipo_documento] || 'COMPROBANTE ELECTRÓNICO';
  const sub = lineas.reduce((s, l) => s + (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0), 0), desc = lineas.reduce((s, l) => s + (+l.descuento || 0), 0);
  const otros = Array.isArray(doc.otros_cargos) ? doc.otros_cargos : [];
  const b = [
    ...(copia ? [{ t: 'texto', x: '*** COPIA ***', al: 'C', b: true, tam: 2 }, { t: 'texto', x: 'Reimpresión · no es un nuevo comprobante', al: 'C' }] : []),   // 4.33
    { t: 'texto', x: e.nombre_comercial || e.nombre || '', al: 'C', b: true, tam: 2 },
  ];
  if (e.nombre_comercial && e.nombre && e.nombre !== e.nombre_comercial) b.push({ t: 'texto', x: e.nombre, al: 'C' });
  if (e.numero_id) b.push({ t: 'texto', x: 'Cédula: ' + e.numero_id, al: 'C' });
  const dir = [e.barrio, e.otras_senas].filter(x => x && !/^\d+$/.test(String(x))).join(', '); if (dir) b.push({ t: 'texto', x: dir, al: 'C' });   // provincia/cantón/distrito son códigos: no se imprimen
  const con = [e.telefono ? 'Tel. ' + e.telefono : '', e.correo].filter(Boolean).join('  '); if (con) b.push({ t: 'texto', x: con, al: 'C' });
  b.push({ t: 'linea' }, { t: 'texto', x: titulo, al: 'C', b: true }, { t: 'texto', x: 'No. ' + (doc.consecutivo || ''), al: 'C', b: true },
    { t: 'texto', x: 'Fecha: ' + fecha(doc.fecha_emision) + ' ' + String(doc.fecha_emision || '').slice(11, 16), al: 'C' });
  if (cajero) b.push({ t: 'texto', x: 'Cajero: ' + cajero, al: 'C' });
  b.push({ t: 'linea' }, { t: 'texto', x: 'Cliente: ' + (doc.receptor_nombre || 'consumidor final') });
  b.push({ t: 'texto', x: 'Condición: ' + ({ '01': 'Contado', '02': 'Crédito' }[doc.condicion_venta] || 'Contado') + (medios && medios.length ? ' · ' + medios.map(m => nombreMedio ? nombreMedio(m.medio) : m.medio).join(', ') : '') }, { t: 'linea' });
  for (const l of lineas) {
    const totalLinea = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0) + (+l.impuesto || 0);
    b.push({ t: 'item', cant: fmt(+l.cantidad || 0, 0), x: l.detalle, d: M(totalLinea), notas: [] });
    b.push({ t: 'texto', x: '    ' + fmt(+l.cantidad || 0, 0) + ' x ' + M(l.precio_unitario) + (+l.descuento ? '  -' + M(l.descuento) : '') + (+l.tarifa ? '  IVA ' + fmt(+l.tarifa, 0) + '%' : '') });
  }
  b.push({ t: 'linea' }, { t: 'par', i: 'Subtotal', d: M(sub + desc) });
  if (desc) b.push({ t: 'par', i: 'Descuento', d: '-' + M(desc) });
  if (+doc.iva_exonerado) b.push({ t: 'par', i: 'IVA exonerado (no se cobra)', d: M(doc.iva_exonerado) });
  b.push({ t: 'par', i: 'IVA', d: M(doc.impuesto) });
  for (const oc of otros) b.push({ t: 'par', i: oc.detalle || 'Otros cargos', d: M(oc.monto) });
  b.push({ t: 'par', i: 'TOTAL ' + mon, d: M(doc.total), b: true });
  if (recibido !== null && recibido !== undefined) { b.push({ t: 'par', i: 'Recibido', d: M(recibido) }); b.push({ t: 'par', i: 'Cambio', d: M(vuelto || 0), b: true }); }
  if (medios && medios.length > 1) for (const m of medios) b.push({ t: 'par', i: nombreMedio ? nombreMedio(m.medio) : m.medio, d: M(m.monto) });
  b.push({ t: 'linea' });
  if (doc.clave) { b.push({ t: 'texto', x: 'Clave: ' + doc.clave, al: 'C' }); b.push({ t: 'qr', x: doc.clave, tam: 4 }); }
  b.push({ t: 'texto', x: 'Autorizada mediante resolución MH-DGT-RES-0027-2024 del 13 de noviembre del 2024', al: 'C' });
  if (cfg && cfg.pie_tiquete) b.push({ t: 'texto', x: cfg.pie_tiquete, al: 'C' });
  b.push({ t: 'texto', x: '¡Gracias por su compra!', al: 'C', b: true });
  return { bloques: b };
}

// 4.2: colilla del cierre de caja (control de turno): columna A = lo que el cajero declaró, B = lo que el sistema registró
// 4.41: completa = false (ciego completo): solo lo que el cajero declaró, sin lo del sistema, sin faltante ni resumen del turno
export function docColilla({ empresa, caja, corte, resumen, cajero, M, completa = true }) {
  const e = empresa || {}, c = caja, k = corte, r = resumen, D = (f, v) => (v === null || v === undefined ? '—' : M(v, f.usd ? 'USD' : 'CRC'));
  const b = [{ t: 'texto', x: e.nombre_comercial || e.nombre || '', al: 'C', b: true, tam: 2 }, { t: 'texto', x: 'CIERRE DE CAJA · ' + (c.caja || ''), al: 'C', b: true },
    { t: 'texto', x: new Date(c.cerrada_en || Date.now()).toLocaleString('es-CR', { timeZone: ZONA_CR, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }), al: 'C' },
    { t: 'texto', x: 'Cajero: ' + (cajero || c.cerrada_por || c.usuario || ''), al: 'C' }, { t: 'linea' }];
  if (!completa) {
    b.push({ t: 'texto', x: 'LO DECLARADO POR EL CAJERO', al: 'C', b: true }, { t: 'linea' });
    for (const f of k.filas.filter(f => f.declarado !== null && f.declarado !== undefined)) b.push({ t: 'par', i: f.nombre, d: D(f, f.declarado), b: true });
    if (c.notas_cierre) b.push({ t: 'linea' }, { t: 'texto', x: 'Notas: ' + c.notas_cierre });
    b.push({ t: 'linea' }, { t: 'texto', x: 'El corte lo revisa la administración', al: 'C' });
    b.push({ t: 'linea' }, { t: 'texto', x: ' ', al: 'C' }, { t: 'texto', x: '______________________', al: 'C' }, { t: 'texto', x: 'Entrega (cajero)', al: 'C' }, { t: 'texto', x: ' ', al: 'C' }, { t: 'texto', x: '______________________', al: 'C' }, { t: 'texto', x: 'Recibe (administración)', al: 'C' });
    return { bloques: b };
  }
  b.push({ t: 'texto', x: 'A = declarado por el cajero · B = según el sistema', al: 'C' }, { t: 'linea' });
  for (const f of k.filas) {
    b.push({ t: 'texto', x: f.nombre, b: true }, { t: 'par', i: '  A declarado', d: D(f, f.declarado) }, { t: 'par', i: '  B sistema', d: D(f, f.sistema) },
      { t: 'par', i: '  ' + (f.diferencia === null ? 'Sin declarar' : f.diferencia < -0.005 ? 'FALTANTE' : f.diferencia > 0.005 ? 'EXCEDENTE' : 'Cuadra'), d: D(f, f.diferencia), b: true });
  }
  b.push({ t: 'linea' }, { t: 'par', i: 'FALTANTE TOTAL', d: M(-k.faltante), b: true }, { t: 'par', i: 'EXCEDENTE TOTAL', d: M(k.sobrante), b: true }, { t: 'linea' }, { t: 'texto', x: 'RESUMEN DEL TURNO', al: 'C', b: true },
    { t: 'par', i: 'Fondo inicial', d: M(c.monto_inicial) }, { t: 'par', i: 'Ventas (' + r.ventas + ')', d: M(r.total) });
  for (const [m, v] of Object.entries(r.porMedio)) b.push({ t: 'par', i: '  ' + (r.nombreMedio ? r.nombreMedio(m) : m), d: M(v) });
  if (r.abonos) b.push({ t: 'par', i: 'Abonos a cuentas por cobrar', d: M(r.abonos) });
  if (r.entradas) b.push({ t: 'par', i: 'Entradas de efectivo', d: M(r.entradas) });
  if (r.salidas) b.push({ t: 'par', i: 'Retiros y depósitos', d: '-' + M(r.salidas) });
  if (r.pagos_proveedor) b.push({ t: 'par', i: 'Pagos a proveedores', d: '-' + M(r.pagos_proveedor) });
  if (r.propinas) b.push({ t: 'par', i: 'Propinas', d: M(r.propinas) });
  if (c.notas_cierre) b.push({ t: 'linea' }, { t: 'texto', x: 'Notas: ' + c.notas_cierre });
  b.push({ t: 'linea' }, { t: 'texto', x: ' ', al: 'C' }, { t: 'texto', x: '______________________', al: 'C' }, { t: 'texto', x: 'Entrega (cajero)', al: 'C' }, { t: 'texto', x: ' ', al: 'C' }, { t: 'texto', x: '______________________', al: 'C' }, { t: 'texto', x: 'Recibe (administración)', al: 'C' });
  return { bloques: b };
}
