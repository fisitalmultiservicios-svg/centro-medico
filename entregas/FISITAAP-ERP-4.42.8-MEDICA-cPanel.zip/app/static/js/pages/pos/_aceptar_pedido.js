// Punto de venta › Caja › «🌐 Pedidos web» (4.39, frente A; soporte de un restaurante del 16 nov 2026): aceptar un pedido en línea e
// imprimir su comanda desde la caja de la página web con la MISMA lógica de Ventas en línea › Pedidos (fis/pages/pedidos.js, 4.29 a
// 4.32): la ventana del navegador se abre en el toque si hay impresoras «del navegador»; se acepta con `reclama: true`; la comanda sale
// de la copia fija que el servidor guardó al aceptar, cada grupo se reclama antes de imprimirlo, se marca impresa y se suelta si falla;
// si lo atiende un programa de escritorio, solo se avisa; los avisos son los mismos.
//
// 4.39: por qué una copia y no un import de pedidos.js. pedidos.js es de la otra aplicación (/app/fisitaap/) e importa fis/sesion.js,
// que al cargarse cambia lo que hace la página cuando la sesión vence (api.js onExpirar guarda uno solo): cargarlo dentro de la caja del
// ERP cambiaría eso, y su `sesion` no tiene ahí ni el menú ni la caja de los pedidos (no imprimiría). Sacar estos métodos de pedidos.js
// cambiaría una pantalla que los restaurantes usan hoy y las pruebas que leen su texto (test_429, test_431, test_432). Por eso los
// métodos de abajo son copia EXACTA, letra por letra, de los de pedidos.js, y tests/test_439_pedidos_caja.py lo comprueba: quien cambie
// uno tiene que cambiar el otro igual (la prueba falla mientras no sean iguales). Lo único propio de aquí: de dónde salen `api`, `toast`
// y `sesion` (parámetros de crearAceptador), qué hace `cargar` (en la caja: trae la cuenta del pedido y vuelve a leer la ventana) y
// `preparar` (lee el negocio y la impresión antes del toque, como hacen fis/sesion.js y el created() de pedidos.js).
//
// `sesion` tiene la forma de fis/sesion.js en lo que estos métodos leen: empresaInfo (es_local, pedidos_programa), menu, negocio
// (terminal_id: la caja de los pedidos) y nombreUsuario. sesionDeCaja() la arma con la sesión del ERP.
// Este archivo no importa nada al cargarse (como pedidos.js, _comandas.js y _agente.js se cargan al usarse): si no carga, la caja sigue
// como antes.

// 4.32 (copia exacta de pedidos.js): aceptado en la página web y lo atiende el programa elegido (su comanda sale allá)
export const TEXTO_ACEPTADO_ALLA = nombre => 'Pedido aceptado: lo atiende «' + nombre + '»; su comanda sale allá.';

// 4.39: la sesión que leen los métodos copiados, con la forma de fis/sesion.js, armada con la del ERP (app.js): los mismos cálculos de
// `menu` y `nombreUsuario` que fis/sesion.js; `negocio` lo pone preparar() con /api/pedidos/negocio (como fis/sesion.js al entrar).
export function sesionDeCaja(base) {
  return {
    negocio: null,
    get empresaInfo() { return base ? base.empresaInfo : null; },
    get nombreUsuario() { return base?.usuario?.nombre || base?.usuario?.correo || ''; },
    get menu() { return base?.tipo === 'restaurante' || this.negocio?.presentacion === 'menu'; },
  };
}

// 4.39: un «aceptador» por caja abierta: los métodos de Ventas en línea › Pedidos sobre un objeto propio (su `aceptando`, su `impresion`
// y su `_equipo`, como cada pantalla de Pedidos). `recargar` = lo que en pedidos.js es volver a leer la lista (en la caja: sincronizar y
// leer otra vez la ventana «Pedidos en línea»).
export function crearAceptador({ api, toast, sesion, recargar }) {
  return {
    aceptando: {}, impresion: null, _com: null, _equipo: null,
    // 4.39: antes del toque (al abrir la ventana): el negocio (la caja de los pedidos y si usa menú) y lo de imprimir; nunca lanza.
    // 4.39 (revisión): un restaurante ya sabe que usa menú y lee las dos cosas a la vez; los demás leen primero el negocio (dice si usa menú)
    async preparar() {
      const negocio = (async () => { try { const n = await api('/api/pedidos/negocio'); if (n && typeof n === 'object') sesion.negocio = n; } catch { /* queda el que había */ } })();
      if (this.menu) { await Promise.all([negocio, this.cargarImpresion()]); return this; }
      await negocio;
      await this.cargarImpresion();
      return this;
    },
    // 4.39: en pedidos.js, `cargar(true)` vuelve a leer la lista; aquí lo hace la caja (nunca lanza)
    async cargar(silencioso) { try { if (recargar) await recargar(silencioso); } catch { /* la caja vuelve a leer en la próxima vuelta */ } },
    // ---- desde aquí, copia exacta de fis/pages/pedidos.js (computadas como get; métodos tal cual) ----
    get menu() { return sesion.menu; },
    // 4.29 (W-3): el botón del pedido nuevo imprime la comanda solo con menú, impresoras de comanda y la caja de los pedidos imprimiendo
    // comandas; sin esos datos (no se pudieron leer) dice «Aceptar pedido» y no imprime
    get conComanda() { const i = this.impresion; return !!(i && this._com && this._com.imprimeAlAceptar(this.menu, i.cfg, i.impresoras, sesion.negocio ? sesion.negocio.terminal_id : null)); },
    // 4.32: el programa de escritorio con los pedidos en línea (la bandera la manda la empresa); sin ella todo se porta como antes
    get enProg() { const i = sesion.empresaInfo; return !!(i && i.es_local && i.pedidos_programa); },
    nombreAtiende(p) { return (p && p.atiende_nombre) || 'otra computadora'; },
    // 4.29: lo que hace falta para imprimir la comanda al aceptar (módulo compartido con el monitor de cocina, cajas e impresoras). Solo
    // con menú; se lee aparte y sin esperar: si algo falta, la pantalla carga igual y el botón dice «Aceptar pedido».
    async cargarImpresion() {
      if (!this.menu || this.enProg) return;
      try {
        const [mod, cfg, imps] = await Promise.all([import('/js/pages/pos/_comandas.js'), api('/api/registros/pos_config'), api('/api/registros/pos_impresoras')]);
        this._com = mod; this.impresion = { cfg: cfg ? cfg.datos : null, impresoras: imps && Array.isArray(imps.datos) ? imps.datos : [] };
      } catch { this.impresion = null; }
    },
    // 4.29 (W-1 a W-5): aceptar el pedido nuevo. Primero se acepta (el servidor rechaza al segundo que acepta a la vez); solo quien lo
    // aceptó imprime la comanda, una vez. Si no se pudo imprimir, el pedido queda aceptado y la comanda sin marcar en Cocina.
    async aceptar(p) { return this.aceptarComo(p, null); },
    // 4.32: `extra` = { aqui: true } («Aceptar y atenderlo aquí») o { rescate: true } (el administrador atiende aquí lo de otra computadora)
    async aceptarComo(p, extra) {
      if (this.enProg) return this.aceptarEnPrograma(p);
      if (this.aceptando[p.id]) return false;
      this.aceptando = { ...this.aceptando, [p.id]: true };
      const vent = { w: null };
      const rescate = !!(extra && extra.rescate), aqui = !!(extra && extra.aqui);
      try {
        /* 4.29: la primera lectura falló o no terminó: se intenta otra vez, 1,5 s como mucho (pasado eso se acepta sin imprimir y con el aviso) */
        let tarde = false;
        if (this.menu && !this.impresion) { let tope = null; tarde = (await Promise.race([this.cargarImpresion(), new Promise(r => { tope = setTimeout(() => r('tope'), 1500); })])) === 'tope'; clearTimeout(tope); }
        const imprime = this.conComanda && !tarde, mod = this._com;
        // 4.29: la ventana de las impresoras «del navegador» se abre en el toque (después de esperar al servidor el navegador puede bloquearla)
        if (imprime && mod && mod.usaVentana(this.impresion.impresoras, !!(sesion.empresaInfo && sesion.empresaInfo.es_local))) { try { vent.w = window.open('', '_blank') || null; } catch { vent.w = null; } }
        let r;
        try { r = rescate ? await api('/api/pedidos/' + p.id + '/atender-aqui', { method: 'POST', body: { confirmo: true, reclama: true } }) : aqui ? await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado', reclama: true, aqui: true } }) : await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado', reclama: true } }); }   /* 4.32: «Aceptar y atenderlo aquí» manda aqui; el rescate del administrador es la ruta atender-aqui. 4.31: esta pestaña reclama cada grupo antes de imprimirlo (la estación espera 15 s, no 60) */
        catch (e) { toast(e.message, 'err'); return false; }
        Object.assign(p, r);
        if (r && +r.atiende > 0) { toast(TEXTO_ACEPTADO_ALLA(this.nombreAtiende(r)), 'ok'); await this.cargar(true); return true; }   /* 4.32: lo atiende un programa: su comanda sale allá, aquí no se imprime nada */
        const motivo = 'no se pudo leer a tiempo la configuración de impresión';
        const [texto, tipo] = imprime && mod ? await this.comandaDelPedido(mod, r, vent) : tarde ? [mod ? mod.avisoComandaNoImpresa(motivo) : 'Pedido aceptado. La comanda no se imprimió: ' + motivo + '. Imprímala desde Punto de venta › Cocina.', 'err'] : ['Pedido actualizado.', 'ok'];
        toast(texto, tipo);
        await this.cargar(true); return true;
      } finally { if (vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } } const a = { ...this.aceptando }; delete a[p.id]; this.aceptando = a; }
    },
    // 4.32 (programa de escritorio con los pedidos en línea): el pedido se acepta en la página web por la conexión de este programa y la cuenta
    // entra a esta caja. Los 409 y 400 se muestran como llegan.
    // Validación 4.32: Ventas en línea es otra página y aquí no corre la estación de la Caja: la comanda sale desde esta pantalla, de la copia
    // que el servidor guardó al aceptar (la misma lectura y los mismos reclamos por plato que la página web de la 4.31: nunca sale dos veces,
    // aunque la Caja esté abierta en otra pestaña). Después del aviso de aceptado se muestra lo que pasó con la comanda.
    async aceptarEnPrograma(p) {
      if (this.aceptando[p.id]) return false;
      this.aceptando = { ...this.aceptando, [p.id]: true };
      try {
        let r;
        try { r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); }
        catch (e) { toast(e.message, 'err'); return false; }
        Object.assign(p, r);
        toast(r && r.mensaje ? r.mensaje : 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.', 'ok');
        let res = null;
        try { res = await this.comandaDelPedido(await import('/js/pages/pos/_comandas.js'), { ...p, id: (r && r.id) || p.id }, { w: null }); } catch { res = null; }   /* sin el módulo de impresión: la saca la estación de la Caja */
        if (res && res[0] !== 'Pedido actualizado.') toast(res[0], res[1]);
        await this.cargar(true); return true;
      } finally { const a = { ...this.aceptando }; delete a[p.id]; this.aceptando = a; }
    },
    // 4.31 (estación de comandas, D-8 y D-16): la comanda sale de la copia fija que el servidor guardó al aceptar (GET
    // /api/pos/comanda/pendientes?pedido_id=) y cada grupo se reclama antes de imprimirlo; lo de impresoras USB o de red que no sale aquí lo
    // imprime sola la estación de la caja o de la cocina. Lecturas con tope de 5 s. Sin copia (servidor anterior a la 4.31): como en la 4.29
    // (comandaAnterior). Nunca lanza: devuelve el aviso para el usuario.
    async comandaDelPedido(C, r, vent) {
      try {
        const vacio = { datos: null };
        const lect = await C.conTope(Promise.all([C.pendientesComanda(api, { pedido_id: r.id }), api('/api/registros/pos_config').catch(() => null), api('/api/registros/pos_impresoras').catch(() => null),
          api('/api/registros/categorias').catch(() => vacio), api('/api/registros/items_extra').catch(() => vacio), api('/api/productos?venta=1').catch(() => [])]), 5000, null);
        if (!lect) return [C.avisoComandaNoImpresa(C.MOTIVO_LECTURA_TARDE, { saleSola: true }), 'info'];
        const [pen, cfg, imps, cats, ext, prods] = lect, i = this.impresion || {};
        const datos = { cfg: cfg ? cfg.datos : i.cfg, impresoras: imps && Array.isArray(imps.datos) ? imps.datos : (i.impresoras || []), categorias: cats && cats.datos, extras: ext && ext.datos, productos: prods };
        const copia = pen.resultado === 'ok' ? pen.copias.find(c => +c.pedido_id === +r.id) : null;
        if (copia) return await this.comandaDeCopia(C, r, vent, copia, pen.ahora, datos);
        /* 4.31: sin red o el servidor respondió con un error: la copia puede existir (la estación la imprime); como en la 4.29 solo sin la ruta o sin copia */
        if (pen.resultado === 'sin_red' || pen.resultado === 'error') return [C.avisoComandaNoImpresa(C.MOTIVO_SIN_RESERVA, { saleSola: true }), 'info'];
        return await this.comandaAnterior(C, r, vent, datos);
      } catch (e) { return [C.avisoComandaNoImpresa((e && e.message) || 'no se pudieron leer los datos de impresión'), 'err']; }
    },
    // 4.31: imprime de la copia. Grupos de la ventana del navegador: se reclaman y se escriben en la ventana abierta en el toque (una sola
    // llamada a imprimirComandas). Grupos de impresora USB o de red: se reclaman solo si el agente de este equipo responde. Se marca cada
    // grupo que salió (con los platos «sin comanda») y se suelta cada grupo que falló.
    async comandaDeCopia(C, r, vent, copia, ahora, datos) {
      const local = !!(sesion.empresaInfo && sesion.empresaInfo.es_local), pid = +r.id;
      if (copia.estado === 'cerrada') return ['Pedido actualizado.', 'ok'];
      const g = C.gruposDeCopia(copia, { ...datos, ahora, incluirReclamadas: true });
      const equipo = this._equipo || (this._equipo = C.nuevoEquipo()), nombre = 'Pedidos · ' + (sesion.nombreUsuario || '');
      const marca = ps => C.conTope(C.marcarComandaImpresa(api, { pedido_id: pid, equipo, lineas: ps, sin_comanda: g.sin_comanda }), 5000, { resultado: 'sin_red' });
      if (!g.grupos.length) {
        if (g.sin_comanda.length) await marca([]);
        return (copia.lineas || []).some(l => l && l.estado === 'impresa') ? ['Pedido aceptado y comanda impresa.', 'ok'] : ['Pedido actualizado.', 'ok'];
      }
      const dir = g.grupos.filter(x => x.directo), nav = g.grupos.filter(x => !x.directo);
      let agente = false;
      if (dir.length) { try { const A = await import('../../pages/pos/_agente.js'); const est = A.agenteEstado ? await C.conTope(A.agenteEstado(false, local ? undefined : { soloAgente: true }), 3000, null) : null; agente = !!(est && est.ok); } catch { agente = false; } }
      const ganados = [], motDir = new Set(), motNav = new Set();
      let ocupadaPor = '';
      for (const gr of [...nav, ...(agente ? dir : [])]) {
        if (gr.pos.some(n => C.EN_CURSO.has(C.claveEnCurso(pid, n)))) continue;
        const x = await C.conTope(C.reclamarComanda(api, { pedido_id: pid, lineas: gr.pos, grupo: gr.id, grupo_nombre: gr.imp.nombre, equipo, nombre, momento: 'aceptar' }), 5000, { resultado: 'sin_red' });
        if (x.resultado === 'ganada') ganados.push({ ...gr, lineas: Array.isArray(x.lineas) && x.lineas.length ? gr.lineas.filter(l => x.lineas.includes(+l.pos)) : gr.lineas });
        else if (x.resultado === 'ocupada') ocupadaPor = ocupadaPor || x.por || 'otra computadora';
        else if (!['impresa', 'cancelado', 'en_curso'].includes(x.resultado)) (gr.directo ? motDir : motNav).add(C.MOTIVO_SIN_RESERVA);
      }
      if (dir.length && !agente) motDir.add(C.MOTIVO_SIN_AGENTE);
      const ventana = vent ? vent.w : null; if (vent) vent.w = null;   /* imprimirComandas la usa o la cierra */
      if (!ganados.length && ventana) { try { ventana.close(); } catch { /* ya cerrada */ } }
      const claves = ganados.flatMap(gr => gr.lineas.map(l => C.claveEnCurso(pid, l.pos)));
      const sinMarca = [];
      for (const k of claves) C.EN_CURSO.add(k);
      try {
        const res = ganados.length ? await C.imprimirGrupoCopia(copia, ganados, { ventana, respaldoNavegador: false, local }) : { impresas: [], fallas: [] };
        const salio = new Set(res.impresas);
        for (const gr of ganados) {
          const todas = gr.lineas.map(l => +l.pos), ps = todas.filter(n => salio.has(n)), resto = todas.filter(n => !salio.has(n));
          if (ps.length) { const m = await marca(ps); if (C.marcaPorReintentar(m)) sinMarca.push(ps); }
          if (resto.length) {
            const propias = res.fallas.filter(f => f.includes('«' + gr.imp.nombre + '»')), motivo = (propias.length ? propias : res.fallas).join('; ') || 'no se pudo imprimir';
            await C.conTope(C.soltarComanda(api, { pedido_id: pid, equipo, lineas: resto, motivo }), 5000, null);
            (gr.directo ? motDir : motNav).add(motivo);
          }
        }
      } finally { for (const k of claves) C.EN_CURSO.delete(k); }
      /* 4.31: la marca que no llegó se reintenta sola unos 50 s (los platos siguen reservados por esta pestaña); solo si no llega se avisa */
      if (sinMarca.length) this.marcarDespues(C, sinMarca.map(ps => () => marca(ps)));
      const programado = !!copia.hora_entrega && Date.parse(copia.listo_desde || '') > (Date.parse(ahora || '') || Date.now());
      if (motNav.size) return [C.avisoComandaNoImpresa([...new Set([...motNav, ...motDir])]), 'err'];
      if (motDir.size) return programado ? [C.textoAceptadoMasTarde(copia.hora_entrega), 'ok'] : this.enProg && copia.vieja ? [C.avisoComandaNoImpresa([...motDir]), 'err'] : [C.avisoComandaNoImpresa([...motDir], { saleSola: true }), 'info'];   /* validación 4.32 (programa): la copia vieja (más de 30 min) ya no sale sola */
      if (ocupadaPor) return [C.textoAceptadoOcupada(ocupadaPor), 'ok'];
      return ganados.length ? ['Pedido aceptado y comanda impresa.', 'ok'] : ['Pedido actualizado.', 'ok'];
    },
    // 4.31: las marcas «impresa» que no llegaron se reintentan solas, cada 4 s y unos 50 s (sin esperar: el aviso de aceptar ya salió). Si
    // alguna no llega, entonces sí se avisa que no la imprima otra vez. `envios` = funciones que mandan cada marca.
    async marcarDespues(C, envios) {
      let quedan = envios.slice();
      for (let i = 0; i < 12 && quedan.length; i++) {
        await new Promise(r => setTimeout(r, 4000));
        const siguen = [];
        for (const f of quedan) { const m = await f(); if (C.marcaPorReintentar(m)) siguen.push(f); }
        quedan = siguen;
      }
      if (quedan.length) toast('Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez.', 'err');
      return !quedan.length;
    },
    // 4.29 (sin cambios de fondo; en la 4.31 solo si el servidor no tiene la copia de la comanda): imprime la comanda de la cuenta que el
    // servidor creó para el pedido (la misma función que «Imprimir» del monitor) y marca como impresas las líneas que salieron.
    async comandaAnterior(C, r, vent, datos) {
      try {
        const esp = await C.conTope(api('/api/registros/pos_espera'), 5000, 'tope');
        if (esp === 'tope') return [C.avisoComandaNoImpresa(C.MOTIVO_LECTURA_TARDE), 'err'];
        const cats = { datos: datos.categorias }, ext = { datos: datos.extras }, prods = datos.productos;
        const cuenta = ((esp && Array.isArray(esp.datos)) ? esp.datos : []).find(c => c && r.cuenta_espera_id && c.id === r.cuenta_espera_id);
        if (!cuenta) return [C.avisoComandaNoImpresa('no se encontró la cuenta del pedido en la caja'), 'err'];
        const conf = datos.cfg, impresoras = datos.impresoras;
        const caja = C.cajaDe(conf, cuenta.terminal_id);
        if (caja.imprimir_comanda === false) return ['Pedido actualizado.', 'ok'];
        const todas = C.lineasComandaPedido(cuenta, { impresoras, categorias: cats && cats.datos, extras: ext && ext.datos, productos: prods, terminal: caja });
        const ronda = todas.length ? (+todas[0].ronda || 1) : 1, lineas = todas.filter(l => (+l.ronda || 1) === ronda);
        if (!lineas.length) return ['Pedido actualizado.', 'ok'];
        const ventana = vent ? vent.w : null; if (vent) vent.w = null;   /* imprimirComandas la usa o la cierra */
        const res = await C.imprimirComandas({ cuenta, ronda, lineas, numero: C.numeroDeRonda(lineas), icono: '🌐', desde: lineas.map(l => l.enviado).sort()[0], local: !!(sesion.empresaInfo && sesion.empresaInfo.es_local), respaldoNavegador: false, ventana });
        const pos = res.impresas.map(l => l.pos).filter(n => Number.isInteger(n));
        // 4.29 (W-2): si todo salió, los platos «sin comanda» de esa ronda también quedan marcados: en Cocina la comanda se ve «Impresa»
        if (!res.fallas.length) cuenta.lineas.forEach((l, i) => { if (l && l.enviado && +l.cantidad > 0 && (+l.ronda || 1) === ronda && !pos.includes(i)) pos.push(i); });
        let marcada = true;
        if (pos.length) { try { await api('/api/pedidos/' + r.id + '/comanda/impresa', { method: 'POST', body: { lineas: pos } }); } catch { marcada = false; } }
        if (res.fallas.length) return [C.avisoComandaNoImpresa(res.fallas), 'err'];
        if (!marcada) return ['Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez.', 'err'];
        return ['Pedido aceptado y comanda impresa.', 'ok'];
      } catch (e) { return [C.avisoComandaNoImpresa((e && e.message) || 'no se pudieron leer los datos de impresión'), 'err']; }
    },
  };
}
