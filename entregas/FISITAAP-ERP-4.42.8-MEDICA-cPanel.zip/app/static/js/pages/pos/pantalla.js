// Punto de venta › Pantalla del cliente (3.21): se abre en el segundo monitor (o en una tableta del mismo equipo) y muestra lo que
// la caja va marcando: líneas, total, propina al cobrar y «gracias» al terminar. Recibe los datos de la pestaña de la caja por
// BroadcastChannel; no toca el servidor.
import { money } from '../../api.js';
import { sesion, store } from '../../app.js';

export default {
  props: ['params'],
  data() { return { d: null, hora: new Date() }; },
  computed: { empresa() { return store.empresa || {}; } },
  created() {
    try { this._canal = new BroadcastChannel('gf-pos-' + (sesion.empresa_id || 0)); this._canal.onmessage = e => { this.d = e.data; }; } catch {}
    this._reloj = setInterval(() => { this.hora = new Date(); }, 1000);
  },
  beforeUnmount() { if (this._canal) this._canal.close(); clearInterval(this._reloj); },
  methods: { money },
  template: `
  <div class="page" style="max-width:none;min-height:calc(100vh - 60px);display:flex;flex-direction:column">
    <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:14px"><div><div style="font-size:26px;font-weight:700">{{empresa.nombre_comercial || empresa.nombre || ''}}</div><div class="muted">{{d && d.caja ? d.caja : 'Pantalla del cliente'}}</div></div><div class="muted" style="font-size:20px">{{hora.toLocaleTimeString('es-CR', {hour: '2-digit', minute: '2-digit'})}}</div></div>
    <div class="card" style="flex:1;display:flex;flex-direction:column;font-size:20px" v-if="d && d.lineas && d.lineas.length">
      <div style="flex:1;overflow:auto"><table class="tbl" style="font-size:20px"><tbody><tr v-for="(l, i) in d.lineas" :key="i"><td style="width:60px;text-align:right">{{l.cantidad}}</td><td>{{l.detalle}}</td><td class="num" style="white-space:nowrap">{{money(l.total)}}</td></tr></tbody></table></div>
      <div class="totals" style="font-size:22px;margin-top:10px"><div><span>Subtotal</span><b>{{money(d.totales.neto)}}</b></div><div><span>IVA</span><b>{{money(d.totales.iva)}}</b></div><div v-if="d.totales.servicio"><span>Impuesto de servicio</span><b>{{money(d.totales.servicio)}}</b></div><div class="total" style="font-size:34px"><span>Total</span><b>{{money(d.totales.total)}}</b></div></div>
      <p class="muted" style="margin:10px 0 0;font-size:16px" v-if="d.cliente">Cliente: {{d.cliente}}</p>
    </div>
    <div class="card" style="flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px" v-else>
      <div style="font-size:42px">{{d && d.gracias ? '¡Gracias por su compra!' : 'Bienvenido'}}</div>
      <div class="muted" style="font-size:18px">{{d && d.gracias ? ('Total ' + money(d.gracias.total) + (d.gracias.vuelto ? ' · vuelto ' + money(d.gracias.vuelto) : '')) : 'Le atendemos en un momento'}}</div>
      <p class="small muted" style="margin-top:30px" v-if="!d">Abra esta pantalla en el mismo navegador que la caja (otra pestaña o ventana en el segundo monitor); se actualiza sola con cada venta.</p>
    </div>
  </div>`,
};
