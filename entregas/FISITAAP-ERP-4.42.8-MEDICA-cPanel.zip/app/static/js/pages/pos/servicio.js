// Punto de venta › Servicio 10 % y propinas (3.9): lo cobrado por impuesto de servicio y las propinas voluntarias en un período,
// por día (total general, para repartir entre todo el personal) y por salonero (cuando el negocio reparte por quien atendió).
// Lee las ventas de caja (pos_ventas: servicio, propina, salonero); PDF, Word y CSV. El reparto por personas es una calculadora.
import { money, fmt, fecha, hoy, sumarDias, toast } from '../../api.js';
import { sesion } from '../../app.js';
import { servicioPorDia, servicioPorSalonero, terminales } from './_datos.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;

export default {
  props: ['params'],
  data() { const h = hoy(); return { tab: this.params.tab === 'saloneros' ? 'saloneros' : 'general', desde: h.slice(0, 8) + '01', hasta: h, personas: 1, conPropinas: true, cfg: terminales()[0] || {} }; },
  computed: {
    dias() { return servicioPorDia(this.desde, this.hasta); },
    saloneros() { return servicioPorSalonero(this.desde, this.hasta); },
    tot() { const d = this.dias; return { ventas: d.reduce((s, x) => s + x.ventas, 0), total: r2(d.reduce((s, x) => s + x.total, 0)), servicio: r2(d.reduce((s, x) => s + x.servicio, 0)), propinas: r2(d.reduce((s, x) => s + x.propinas, 0)) }; },
    repartir() { return r2(this.tot.servicio + (this.conPropinas ? this.tot.propinas : 0)); },
    porPersona() { const n = Math.max(1, Math.floor(+this.personas || 1)); return r2(this.repartir / n); },
    sinDato() { return this.dias.length && this.tot.servicio === 0 && !(+this.cfg.servicio_pct > 0); },
  },
  methods: {
    money, fmt, fecha,
    rapido(q) { const h = hoy(); if (q === 'hoy') { this.desde = h; this.hasta = h; } else if (q === 'semana') { this.desde = sumarDias(h, -6); this.hasta = h; } else if (q === 'mes') { this.desde = h.slice(0, 8) + '01'; this.hasta = h; } else if (q === 'anterior') { const a = sumarDias(h.slice(0, 8) + '01', -1); this.desde = a.slice(0, 8) + '01'; this.hasta = a; } },
    exportar(formato) {
      const M = v => money(v), per = 'Del ' + fecha(this.desde) + ' al ' + fecha(this.hasta);
      if (this.tab === 'general') {
        const cols = [{ key: 'fecha', label: 'Día', fmt: 'date' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true, fmt: M }, { key: 'servicio', label: 'Impuesto de servicio', num: true, fmt: M }, { key: 'propinas', label: 'Propinas', num: true, fmt: M }, { key: 'repartir', label: 'Total a repartir', num: true, fmt: M }];
        if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'servicio_10_por_dia', cols, this.dias);
        return descargarReporte(formato, { titulo: 'Impuesto de servicio 10 % y propinas · total general', subtitulo: 'Por día · ' + (this.conPropinas ? 'incluye propinas' : 'solo impuesto de servicio'), periodo: per, cols, rows: this.dias, kpis: [{ t: 'Ventas', v: String(this.tot.ventas) }, { t: 'Impuesto de servicio', v: M(this.tot.servicio) }, { t: 'Propinas', v: M(this.tot.propinas) }, { t: 'A repartir', v: M(this.repartir) }], totales: [{ t: 'Total a repartir', v: M(this.repartir) }, { t: 'Entre ' + this.personas + ' persona(s)', v: M(this.porPersona) + ' cada una' }], nota: 'El impuesto de servicio (10 %) se cobra en el comprobante como otro cargo; las propinas voluntarias van aparte. Este documento no es un comprobante.', archivo: 'servicio_10_general' });
      }
      const cols = [{ key: 'salonero', label: 'Salonero' }, { key: 'ventas', label: 'Ventas', num: true }, { key: 'total', label: 'Vendido', num: true, fmt: M }, { key: 'servicio', label: 'Impuesto de servicio', num: true, fmt: M }, { key: 'propinas', label: 'Propinas', num: true, fmt: M }, { key: 'repartir', label: 'Total', num: true, fmt: M }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'servicio_10_por_salonero', cols, this.saloneros);
      return descargarReporte(formato, { titulo: 'Impuesto de servicio 10 % y propinas · por salonero', periodo: per, cols, rows: this.saloneros, kpis: [{ t: 'Saloneros', v: String(this.saloneros.length) }, { t: 'Impuesto de servicio', v: M(this.tot.servicio) }, { t: 'Propinas', v: M(this.tot.propinas) }, { t: 'Total', v: M(r2(this.tot.servicio + this.tot.propinas)) }], totales: this.saloneros.map(s => ({ t: s.salonero, v: M(s.repartir) })), nota: 'Las ventas sin salonero («—») son las cobradas sin elegir salonero en la caja. Este documento no es un comprobante.', archivo: 'servicio_10_por_salonero' });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Servicio 10 % y propinas" sub="Lo cobrado por impuesto de servicio y las propinas voluntarias: total general para repartir entre todo el personal o detalle por salonero." :crumbs="[{label:'Punto de venta'},{label:'Servicio 10 % y propinas'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!dias.length">PDF</button><button class="btn ghost sm" @click="exportar('docx')" :disabled="!dias.length">Word</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!dias.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!dias.length">CSV</button>
    </PageHead>
    <div class="card">
      <div class="toolbar"><label class="small">Del <input type="date" class="inp" v-model="desde"></label><label class="small">al <input type="date" class="inp" v-model="hasta"></label><div class="seg"><button @click="rapido('hoy')">Hoy</button><button @click="rapido('semana')">7 días</button><button @click="rapido('mes')">Este mes</button><button @click="rapido('anterior')">Mes anterior</button></div></div>
      <div class="kpis">
        <div class="kpi"><div class="t">Ventas</div><div class="v">{{tot.ventas}}</div><div class="d">{{money(tot.total)}} vendido</div></div>
        <div class="kpi"><div class="t">Impuesto de servicio 10 %</div><div class="v">{{money(tot.servicio)}}</div></div>
        <div class="kpi"><div class="t">Propinas voluntarias</div><div class="v">{{money(tot.propinas)}}</div></div>
        <div class="kpi"><div class="t">Total a repartir</div><div class="v">{{money(repartir)}}</div><div class="d">{{conPropinas ? 'servicio + propinas' : 'solo servicio'}}</div></div>
        <div class="kpi"><div class="t">Por persona</div><div class="v">{{money(porPersona)}}</div><div class="d">entre {{personas}}</div></div>
      </div>
      <p class="small" style="margin:0 0 10px;color:var(--danger)" v-if="sinDato">La caja no tiene porcentaje de servicio: actívelo en Punto de venta › Configuración (Restaurantes: impuesto de servicio) para que se cobre y aparezca aquí.</p>
      <div class="tabs"><button :class="{on: tab==='general'}" @click="tab='general'">Total general por día</button><button :class="{on: tab==='saloneros'}" @click="tab='saloneros'">Por salonero</button></div>
      <template v-if="tab==='general'">
        <div class="row" style="gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:10px"><label class="small">Repartir entre <input type="number" min="1" step="1" class="inp mini" v-model.number="personas" style="width:70px;text-align:right"> persona(s)</label><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="conPropinas"> incluir las propinas en el reparto</label><span class="small muted">Para cuando el 10 % se reparte entre todo el personal (cocina incluida).</span></div>
        <Empty v-if="!dias.length" icon="🧾" title="Sin ventas en el período" text="Las ventas de la caja con impuesto de servicio aparecen aquí por día."></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Día</th><th class="num">Ventas</th><th class="num">Vendido</th><th class="num">Impuesto de servicio</th><th class="num">Propinas</th><th class="num">Total a repartir</th></tr></thead>
          <tbody><tr v-for="d in dias" :key="d.fecha"><td>{{fecha(d.fecha)}}</td><td class="num">{{d.ventas}}</td><td class="num">{{money(d.total)}}</td><td class="num">{{money(d.servicio)}}</td><td class="num">{{money(d.propinas)}}</td><td class="num"><b>{{money(conPropinas ? d.repartir : d.servicio)}}</b></td></tr></tbody>
          <tfoot><tr><th>Total</th><th class="num">{{tot.ventas}}</th><th class="num">{{money(tot.total)}}</th><th class="num">{{money(tot.servicio)}}</th><th class="num">{{money(tot.propinas)}}</th><th class="num">{{money(repartir)}}</th></tr></tfoot></table></div>
      </template>
      <template v-else>
        <Empty v-if="!saloneros.length" icon="🧾" title="Sin ventas en el período" text="Elija el salonero en cada cuenta de la caja para ver aquí su 10 % y sus propinas."></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Salonero</th><th class="num">Ventas</th><th class="num">Vendido</th><th class="num">Impuesto de servicio</th><th class="num">Propinas</th><th class="num">Total</th></tr></thead>
          <tbody><tr v-for="s in saloneros" :key="s.salonero"><td><b>{{s.salonero}}</b></td><td class="num">{{s.ventas}}</td><td class="num">{{money(s.total)}}</td><td class="num">{{money(s.servicio)}}</td><td class="num">{{money(s.propinas)}}</td><td class="num"><b>{{money(s.repartir)}}</b></td></tr></tbody>
          <tfoot><tr><th>Total</th><th class="num">{{tot.ventas}}</th><th class="num">{{money(tot.total)}}</th><th class="num">{{money(tot.servicio)}}</th><th class="num">{{money(tot.propinas)}}</th><th class="num">{{money(tot.servicio + tot.propinas)}}</th></tr></tfoot></table></div>
        <p class="small muted" style="margin:8px 0 0">«—» = ventas cobradas sin elegir salonero. Los saloneros se definen por caja en Punto de venta › Configuración.</p>
      </template>
      <p class="small muted" style="margin:10px 0 0">El impuesto de servicio (10 %, Ley 4946) se cobra en el comprobante como «otros cargos» y es del personal; las propinas voluntarias se registran aparte al cobrar. Las ventas anteriores a esta versión no traen el dato del servicio.</p>
    </div>
  </div>`,
  setup() { return { sesion }; },
};
