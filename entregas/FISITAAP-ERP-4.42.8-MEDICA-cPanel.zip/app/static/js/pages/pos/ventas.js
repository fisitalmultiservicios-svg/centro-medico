// 4.34: Punto de venta › Ventas de caja. Todas las ventas de todas las cajas (no solo la abierta), con filtros por fecha, caja, estado y
// búsqueda; por venta: Ver el tiquete (con COPIA), Carta (el PDF del comprobante) y Reimprimir el tiquete por la impresora de tiquetes.
// Nunca abre la gaveta, nunca emite comprobantes ni manda nada a Hacienda: solo lee y reimprime.
import { money, fechaHora, fecha, hoy, toast, mock, api } from '../../api.js';
import { cajas, ventasDe, nombreMedio, config as configPos, impresoras, terminalCompleta, terminales } from './_datos.js';
import { descargarReporte, descargarTabla } from '../reportes/_montos.js';
import { sesion, store, rutaPermitida } from '../../app.js';
import { porAgente, imprimirAgente, docTiquete, cargarEquipo, impresoraTiqueteAqui, avisoImpresion } from './_agente.js';
import { filasVentas } from './_ventas.js';

const POR_PAGINA = 200;   // las primeras 200 filas; «Ver más» agrega otras 200 (no se cuelga el navegador con miles de filas)
// AAAA-MM-DD de hoy en Costa Rica y de hace n días
const diaMas = (dia, n) => { const d = new Date(dia + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

export default {
  props: ['params'],
  data() { return { listo: false, tick: 0, desde: hoy(), hasta: hoy(), cajaSel: '', q: '', estado: '', limite: POR_PAGINA, imprimiendo: {}, sesion }; },
  async created() { if (await mock.completar('pos_ventas')) this.listo = true; },   // las sesiones viejas muestran sus ventas (como Cierres de caja)
  // 4.34: cada minuto se recalcula la lista: corre la ventana del cajero y salen las ventas que llegan sincronizadas (mock no es reactivo)
  mounted() { this._tick = setInterval(() => { this.tick++; }, 60000); },
  beforeUnmount() { clearInterval(this._tick); },
  computed: {
    esCajero() { return !!sesion.modoCajero; },   // el servidor solo le abre los comprobantes de hoy (o las últimas 6 horas): su lista es esa
    terms() { return terminales(); },   // 4.34: solo las de la sucursal activa, como Reportes de caja
    terminalSel() { return this.cajaSel ? this.terms.find(t => String(t.id) === String(this.cajaSel)) || null : null; },
    sesiones() { this.listo; this.tick; return cajas(); },
    // 4.34: el código (3 dígitos) de la sucursal fija del usuario, como el de sus consecutivos; null = sin sucursal fija (ve e imprime todo).
    // La lista de la sesión lo trae; si la empresa tiene una sola sucursal activa esa lista viene vacía y lo da sucursal_fija_codigo
    codigoSucursal() {
      if (!sesion.sucursal_fija) return null;
      const x = (sesion.sucursales || []).find(s => s.id === sesion.sucursal_fija), c = x ? x.codigo : sesion.sucursal_fija_codigo;
      return c === null || c === undefined || c === '' ? null : String(c).padStart(3, '0');
    },
    res() {
      this.listo; this.tick;
      const t = this.terminalSel;
      return filasVentas(this.sesiones, { desde: this.desde, hasta: this.hasta, cajaId: t ? t.id : '', cajaNombre: t ? t.nombre : '', q: this.q, estado: this.estado, cajero: this.esCajero, codigoSucursal: this.codigoSucursal }, new Date(), { ventasDe, nombreMedio });
    },
    visibles() { return this.res.filas.slice(0, this.limite); },
    resumen() { const r = this.res, ex = r.filas.length - r.n; return r.n + (r.n === 1 ? ' venta · ' : ' ventas · ') + money(r.total) + (ex > 0 ? ' (' + ex + ' anulada' + (ex === 1 ? '' : 's') + ' o cargo' + (ex === 1 ? '' : 's') + ' a habitación no suman)' : ''); },
    puedeAbrirFactura() { return !sesion.modoCajero && rutaPermitida('/ventas/facturas'); },
  },
  watch: { desde() { this.limite = POR_PAGINA; }, hasta() { this.limite = POR_PAGINA; }, cajaSel() { this.limite = POR_PAGINA; }, q() { this.limite = POR_PAGINA; }, estado() { this.limite = POR_PAGINA; } },
  methods: {
    money, fechaHora, fecha,
    pagoTexto(r) { return r.pagos.map(p => p.nombre + ' ' + money(p.monto)).join(' · '); },
    rapido(k) { const h = hoy(); this.hasta = h; this.desde = k === 'semana' ? diaMas(h, -6) : k === 'mes' ? h.slice(0, 8) + '01' : h; },
    // la terminal de ESA venta: por id y, en sesiones viejas sin terminal_id, por el nombre de la caja (como terminalDe en cierres.js)
    terminalDe(c) { const l = configPos().terminales || []; return (c && c.terminal_id ? l.find(x => x.id === c.terminal_id) : null) || l.find(x => c && x.nombre === c.caja) || null; },
    urlTiquete(r) {
      const t = terminalCompleta(this.terminalDe(r.sesion) || {}), rec = r.recibido;
      return '/api/comprobantes/' + r.doc_id + '/tiquete?ancho=' + (t.ancho_ticket || 80) + (rec !== null && rec !== undefined ? '&recibido=' + rec + '&vuelto=' + (r.vuelto || 0) : '') + '&cajero=' + encodeURIComponent(r.sesion.caja || '') + '&copia=true';
    },
    ver(r) { if (r.imprimible) window.open(this.urlTiquete(r), '_blank'); },
    carta(r) { if (r.imprimible) window.open('/api/comprobantes/' + r.doc_id + '/pdf', '_blank'); },
    // El tiquete por la impresora de tiquetes de esta computadora o de la caja de esa venta; siempre con COPIA. Sin impresora por agente, abre el del navegador.
    async reimprimir(r) {
      if (!r.imprimible || this.imprimiendo[r.key]) return;
      this.imprimiendo = { ...this.imprimiendo, [r.key]: true };
      try {
        const t = this.terminalDe(r.sesion), cfg = terminalCompleta(t || {});
        const deCaja = t && t.impresora_comprobante_id ? impresoras().find(i => String(i.id) === String(t.impresora_comprobante_id) && i.activa !== false && i.uso !== 'etiquetas') : null;
        if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});
        const imp = impresoraTiqueteAqui(deCaja, impresoras());
        if (porAgente(imp)) {
          try {
            const doc = await api('/api/comprobantes/' + r.doc_id);
            await imprimirAgente(imp, docTiquete({ empresa: store.empresa, doc, cfg, recibido: r.recibido, vuelto: r.vuelto, medios: r.medios, cajero: cfg.vendedor || r.sesion.caja || '',   // 4.34: la copia lleva a quien vendió (la caja, como «Ver»), no a quien reimprime
 nombreMedio, copia: true }));
            toast('Tiquete enviado a «' + imp.nombre + '»', 'ok');
            return;
          } catch (e) { toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre el tiquete del navegador.', 'err'); }
        }
        this.ver(r);   // sin impresora por agente: el navegador deja imprimir
      } finally { this.imprimiendo = { ...this.imprimiendo, [r.key]: false }; }
    },
    // Exportar la lista filtrada (todas las filas, no solo las visibles): PDF, Excel y CSV
    async descargar(formato) {
      const filas = this.res.filas;
      if (!filas.length) return toast('No hay ventas que exportar en este período', 'err');
      const cols = [{ key: 'fecha_hora', label: 'Fecha y hora' }, { key: 'caja', label: 'Caja' }, { key: 'cajero', label: 'Cajero' }, { key: 'consecutivo', label: 'Comprobante' }, { key: 'cliente', label: 'Cliente' }, { key: 'pago', label: 'Pago' }, { key: 'total', label: 'Total', num: true }, { key: 'estado', label: 'Estado' }];
      const periodo = this.esCajero ? 'Ventas de hoy' : fecha(this.desde) + ' al ' + fecha(this.hasta);
      try {
        if (formato === 'pdf') {
          const rows = filas.map(r => ({ fecha_hora: r.hora ? fechaHora(r.hora) : '', caja: r.caja, cajero: r.cajero, consecutivo: r.consecutivo, cliente: r.cliente + (r.mesa ? ' · ' + r.mesa : ''), pago: this.pagoTexto(r), total: money(r.total), estado: r.estado }));
          return await descargarReporte('pdf', { titulo: 'Ventas de caja', subtitulo: 'Lo vigente suma; las anuladas y los cargos a habitación se muestran pero no suman', periodo, kpis: [{ t: 'Ventas', v: String(this.res.n) }, { t: 'Total', v: money(this.res.total) }], cols, rows, archivo: 'ventas-caja-lista' });
        }
        const rows = filas.map(r => ({ fecha_hora: r.hora ? fechaHora(r.hora) : '', caja: r.caja, cajero: r.cajero, consecutivo: r.consecutivo, cliente: r.cliente + (r.mesa ? ' · ' + r.mesa : ''), pago: this.pagoTexto(r), total: r.total, estado: r.estado }));
        await descargarTabla(formato, 'ventas-caja-lista', cols.map(c => (c.key === 'total' ? { ...c, fmt: 'money' } : c)), rows, { titulo: 'Ventas de caja', periodo });
      } catch (e) { toast(e.message, 'err'); }
    },
  },
  template: `
  <div class="page" :data-listo="listo">
    <PageHead title="Ventas de caja" :sub="res.filas.length ? resumen : 'Todas las ventas de las cajas: ver, imprimir a carta o reimprimir el tiquete'" :crumbs="[{label:'Punto de venta'},{label:'Ventas de caja'}]">
      <button class="btn sec" @click="descargar('pdf')">PDF</button><button class="btn sec" @click="descargar('xlsx')">Excel</button><button class="btn sec" @click="descargar('csv')">CSV</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
      <template v-if="!esCajero">
        <span class="small muted">Período:</span><input type="date" class="inp" v-model="desde"><input type="date" class="inp" v-model="hasta" :min="desde">
        <button class="btn sm sec" @click="rapido('hoy')">Hoy</button><button class="btn sm sec" @click="rapido('semana')">7 días</button><button class="btn sm sec" @click="rapido('mes')">Mes</button>
      </template>
      <select class="inp" v-model="cajaSel" v-if="terms.length > 1 && !esCajero"><option value="">Todas las cajas</option><option v-for="t in terms" :key="t.id" :value="t.id">{{t.nombre}}</option></select>
      <select class="inp" v-model="estado"><option value="">Todas</option><option value="vigentes">Vigentes</option><option value="anuladas">Anuladas</option></select>
      <input class="inp" style="flex:1;min-width:180px" v-model="q" placeholder="Buscar comprobante, cliente, mesa o cajero">
    </div>
    <p class="small muted" style="margin:8px 0 0" v-if="esCajero">Como cajero ve las ventas de hoy. Las anteriores las ve un supervisor o el administrador.</p></div>
    <div class="card">
      <Empty v-if="!sesiones.length" icon="🧾" title="Sin cajas todavía" text="La caja se abre desde Punto de venta › Caja."></Empty>
      <Empty v-else-if="!res.filas.length" icon="🧾" title="Sin ventas en el período" text="Pruebe con otras fechas, otra caja o quite la búsqueda."></Empty>
      <template v-else>
        <div class="table-wrap"><table class="tbl tbl-ventas"><thead><tr><th>Fecha y hora</th><th>Caja</th><th>Cajero</th><th>Comprobante</th><th>Cliente / mesa</th><th>Pago</th><th class="num">Total</th><th>Estado</th><th></th></tr></thead><tbody>
          <tr v-for="r in visibles" :key="r.key" :style="r.anulada ? 'opacity:.55' : ''">
            <td class="small" data-l="Fecha">{{r.hora ? fechaHora(r.hora) : '—'}}</td><td data-l="Caja">{{r.caja}}</td><td class="small" data-l="Cajero">{{r.cajero || '—'}}</td>
            <td class="mono" data-l="Comprobante"><a v-if="r.imprimible && puedeAbrirFactura" :href="'#/ventas/facturas/' + r.doc_id">{{r.consecutivo}}</a><template v-else>{{r.consecutivo}}</template></td>
            <td data-l="Cliente">{{r.cliente}}<div class="small muted" v-if="r.mesa">{{r.mesa}}</div></td>
            <td class="small" data-l="Pago">{{pagoTexto(r)}}</td><td class="num" data-l="Total"><b>{{money(r.total)}}</b></td>
            <td data-l="Estado"><span class="badge" :class="r.anulada ? 'danger' : r.estado === 'Vigente' ? 'ok' : 'warn'">{{r.estado}}</span></td>
            <td class="acciones-venta"><div class="row" style="gap:4px;flex-wrap:wrap" v-if="r.imprimible"><button class="btn sm ghost" @click="ver(r)" title="Ver el tiquete en pantalla (dice COPIA)">Ver</button><button class="btn sm ghost" @click="carta(r)" title="El comprobante en PDF, tamaño carta">Carta</button><button class="btn sm ghost" @click="reimprimir(r)" :disabled="imprimiendo[r.key]" title="Tiquete de 80 mm con la palabra COPIA">Reimprimir</button></div></td>
          </tr></tbody></table></div>
        <div class="row" style="justify-content:center;margin-top:10px;gap:8px;align-items:center" v-if="res.filas.length > limite"><span class="small muted">Se muestran {{limite}} de {{res.filas.length}}</span><button class="btn sm sec" @click="limite += 200">Ver más</button></div>
      </template>
    </div>
  </div>`,
};
