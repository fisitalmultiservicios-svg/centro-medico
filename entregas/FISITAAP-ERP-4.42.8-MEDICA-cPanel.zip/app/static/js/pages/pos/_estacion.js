// 4.31: estación de comandas (diseño exe430/diseno_estacion.md, 4.2 punto 3). La comanda de un pedido en línea SIEMPRE sale: la caja o
// la pantalla de cocina abierta y a la vista en una computadora del negocio con el programa de escritorio o el agente de impresión
// funcionando imprime sola, por las impresoras de comanda USB o de red, las comandas de los pedidos en línea que nadie imprimió (pago con
// tarjeta, aceptado desde un teléfono, una impresora que falló). Imprime de la COPIA FIJA de la comanda que guarda el servidor al crear
// la cuenta (GET /api/pos/comanda/pendientes) y reclama cada plato antes de imprimirlo (POST /api/pos/comanda/reclamar): un plato lo
// imprime una sola computadora, aunque haya dos estaciones. Nunca abre la ventana del navegador.
// Solo de Punto de venta: importa app.js y _datos.js (la pantalla de Pedidos de Ventas en línea usa _comandas.js, que no los importa).
//
// Quién no usa pedidos en línea no nota nada: sin el módulo `pedidos_online` ninguna función hace peticiones. En el programa de
// escritorio no actúa (ESTACION_EN_PROGRAMA = false, D-17).
//
// ---------------------------------------------------------------------------------------------------------------------------------------
// LO QUE LLAMAN caja.js Y cocina.js (una línea en cada lugar; nada de lógica nueva en esos archivos):
//
// caja.js
//   import (junto a los demás de './_...'):
//     import { revisarEstacion, guardarResumen, avisarSiPendiente, iniciarEstacion, pararEstacion } from './_estacion.js';   // 4.31: estación de comandas
//   created(), al final:                                   iniciarEstacion('caja');
//   beforeUnmount(), al final:                             pararEstacion('caja');
//   sincronizar(), justo después de `this.sync++;`:        revisarEstacion('caja');
//   revisarOnline(), justo después de `const r = await api('/api/pedidos/resumen');`:
//                                                          guardarResumen(r);
//   emitirCobro(), justo antes de `if (idFin) { this.espera = mock.actualizar('pos_espera', … idFin …`:
//                                                          avisarSiPendiente(idFin);
//   cargarAHabitacion(), justo antes de `if (esperaId) this.espera = mock.actualizar('pos_espera', … esperaId …`:
//                                                          avisarSiPendiente(esperaId);
//   (ninguna se espera con await: no demoran ni bloquean el cobro; ninguna lanza)
//
// cocina.js
//   import:
//     import { revisarEstacion, iniciarEstacion, pararEstacion, estadoEstacion, textoEstacion, imprimirCocinaEnLinea, imprimirListaCocina, TEXTO_LISTA_COCINA } from './_estacion.js';   // 4.31
//   created(), al final:                                   iniciarEstacion('cocina');      (con pedidos en línea: el resumen cada 30 s, D-15)
//   beforeUnmount(), al final:                             pararEstacion('cocina');
//   refrescar(), después de `this.reloj = Date.now();`:    revisarEstacion('cocina');
//   imprimir(t), al principio (cuentas de un pedido en línea con copia; sin copia, reimpresión o sin pedidos en línea sigue lo de hoy):
//     const enLinea = await imprimirCocinaEnLinea(t, ls => this.aplicar(… «impreso» solo en las líneas de la ronda que están en `ls` …));
//     true = resuelto; { resto } = Cocina imprime como hoy solo esos platos; false = Cocina imprime la tarjeta como hoy;
//     { ventana } o { resto, ventana } = lo mismo, con la ventana del navegador abierta en el toque: Cocina escribe ahí su comanda del
//     navegador (si no la necesita, la cierra) y nunca marca «impreso» lo que iba a una ventana que no se abrió. Si la pestaña cambió de
//     empresa mientras se imprimía, true: esa tarjeta era de la otra empresa y Cocina no imprime ni marca nada más
//   banda (plantilla, arriba, en data o setup: `estadoEstacion`; en methods: `textoEstacion`, `imprimirListaCocina`):
//     texto de estado:  {{textoEstacion()}}   (vacío = no se muestra)
//     lista:            estadoEstacion.lista  → [{ pedido_id, texto: '#45 · hace 2 min' }], título TEXTO_LISTA_COCINA,
//                       botón «Imprimir» → imprimirListaCocina(x.pedido_id)
//
// app.js (4.32, solo con sesion.empresaInfo.pedidos_programa):
//   al entrar con sesión:                                   iniciarDesdeApp();
//   al salir o al cambiar de empresa:                       pararDesdeApp();
//
// Estado reactivo para los textos (Cocina y la tarjeta de Configuración): estadoEstacion =
//   { activa, puede, conProgramaAnterior, ultima, resumen: {comandas_pendientes, comanda_espera_s, hora}, lista: [...] }
// ---------------------------------------------------------------------------------------------------------------------------------------
import { api, toast, mock } from '../../api.js';
import { sesion, store } from '../../app.js';
import { terminalActual, enEspera, categorias, impresoras, config } from './_datos.js';
import { agenteEstado, cargarEquipo, sabeEquipo, ultimoEstadoAgente, porAgente, impresoraAqui } from './_agente.js';
import { nuevoEquipo, EN_CURSO, claveEnCurso, conTope, reclamarComanda, marcarComandaImpresa, soltarComanda, pendientesComanda, gruposDeCopia, imprimirGrupoCopia, cajaDe, esLineaDeCopia, marcaPorReintentar, usaVentana } from './_comandas.js';
import { reactive } from '../../vendor/vue.esm-browser.prod.min.js';

export const ESTACION_EN_PROGRAMA = false;                 /* D-17: en la 4.31 la estación no actúa dentro del programa de escritorio */
export const EQUIPO = nuevoEquipo();                       /* el identificador de esta pestaña ante el servidor */
export const ESPERA_FALLA_MS = 60000, ESPERA_OCUPADA_MS = 15000, MAX_GRUPOS_PASADA = 10, VIGENCIA_CUENTA_MS = 30 * 60000;
export const REFRESCO_IMPRESION_MS = 60000, REFRESCO_SIN_COMANDA_MS = 15000;   /* impresoras y cajas: con copias listas, cada minuto; antes de decidir «sin comanda», de hace 15 s como mucho */
const CLAVES_IMPRESION = ['pos_config', 'pos_impresoras', 'categorias', 'items_extra'];

// ---- textos (5.4 del diseño, exactos) ----
export const TEXTO_ACTIVA = 'Las comandas de los pedidos en línea salen solas en esta computadora.';
export const TEXTO_SIN_IMPRESION = 'Las comandas de los pedidos en línea no salen solas en esta computadora: abra el programa de escritorio o el agente de impresión.';
export const TEXTO_LISTA_COCINA = 'Pedidos en línea con la comanda sin imprimir:';
export const TEXTO_SIN_RED_COCINA = 'No se pudo revisar si otra computadora está imprimiendo esta comanda. ¿Imprimirla de todos modos?';
export function textoOcupadaCocina(nombre) { return 'La computadora «' + String(nombre || 'otra computadora') + '» está imprimiendo esta comanda en este momento. ¿Imprimirla aquí también?'; }
export function textoSalio(num, imp) { return 'Comanda del pedido #' + num + ' impresa en «' + imp + '».'; }
export function textoFallo(num, imp, motivo) { return 'La comanda del pedido #' + num + ' no salió sola en «' + imp + '»: ' + String(motivo || 'no se pudo imprimir').trim().replace(/[.\s]+$/, '') + '. Imprímala desde Punto de venta › Cocina.'; }
export function textoAgotada(num, imp) { return 'La comanda del pedido #' + num + ' no pudo salir sola en «' + imp + '» después de 3 intentos. Imprímala desde Punto de venta › Cocina.'; }
export function textoCancelado(num) { return 'El pedido #' + num + ' se canceló mientras se imprimía su comanda: avise a la cocina.'; }
export function textoCobroSinImprimir(num) { return 'La comanda del pedido #' + num + ' todavía no se ha impreso. Saldrá sola en la computadora de la caja o de la cocina; si en un minuto no ha salido, imprímala desde Punto de venta › Cocina, en «Pedidos en línea con la comanda sin imprimir».'; }
export const ANTICIPO_PROGRAMADO_MIN = 45;               /* como el servidor (comandas.ANTICIPO_PROGRAMADO_MIN): un pedido para más tarde sale 45 minutos antes */
export function textoCobroMasTarde(num, hora) { return 'El pedido #' + num + ' es para las ' + hora + ': su comanda saldrá sola en la computadora de la caja o de la cocina ' + ANTICIPO_PROGRAMADO_MIN + ' minutos antes de esa hora.'; }
export const TEXTO_YA_IMPRESA = 'Esta comanda ya se imprimió. ¿Imprimirla otra vez?';   /* la pregunta de siempre de Cocina al reimprimir */
export const TEXTO_SIN_RED_LISTA = 'No se pudo revisar esa comanda porque no hay conexión con el servidor. Toque «Imprimir» otra vez en un momento.';
export function textoFalloCocina(num, imp, motivo) { return 'La comanda del pedido #' + num + ' no se imprimió en «' + imp + '»: ' + String(motivo || 'no se pudo imprimir').trim().replace(/[.\s]+$/, '') + '. Toque «Imprimir» otra vez cuando lo haya revisado.'; }
export function textoLista(num, minutos) { return '#' + num + ' · hace ' + Math.max(0, Math.round(+minutos || 0)) + ' min'; }
// Interruptor (Punto de venta › Configuración, tarjeta «En esta computadora» de la web)
export const TEXTOS_INTERRUPTOR = {
  titulo: 'En esta computadora', pie: 'Solo cambia esta computadora; las demás siguen como estén.',
  casilla: 'Esta computadora imprime sola las comandas de los pedidos en línea',
  ayuda: 'Si en esta computadora está abierta y a la vista la caja o la pantalla de cocina, y el programa de escritorio o el agente de impresión está funcionando, las comandas de los pedidos en línea que nadie imprimió salen solas por las impresoras de comanda conectadas por USB o por red. Apáguelo si esta computadora no debe imprimir comandas.',
  anterior: 'El programa de escritorio de esta computadora es anterior a la versión 4.31: se usan las impresoras como están en Punto de venta › Impresoras, no los ajustes de «En esta computadora» del programa.',
  encendida: 'Listo: esta computadora imprime sola las comandas de los pedidos en línea.',
  apagada: 'Listo: esta computadora ya no imprime sola las comandas de los pedidos en línea.',
};

export const estadoEstacion = reactive({ activa: false, puede: null, conProgramaAnterior: false, ultima: null, resumen: null, lista: [] });

// ---- interruptor (D-14): encendido por omisión; '0' en localStorage = apagado ----
const claveInterruptor = () => 'pos:estacion_comandas:' + (sesion.empresa_id || 0);
export function estacionEncendida() { try { return localStorage.getItem(claveInterruptor()) !== '0'; } catch { return true; } }
export function encenderEstacion(v) { try { localStorage.setItem(claveInterruptor(), v ? '1' : '0'); } catch { /* el navegador no guarda: queda como estaba */ } if (!v) { estadoEstacion.activa = false; estadoEstacion.lista = []; } return estacionEncendida(); }
// ¿Corre aquí? Con pedidos en línea, en la página web (no en el programa, D-17), y desde la 4.32 también en el programa con la bandera pedidos_programa
export function estacionPosible() { return !!(sesion.tieneModulo && sesion.tieneModulo('pedidos_online')) && (ESTACION_EN_PROGRAMA || !(sesion.empresaInfo && sesion.empresaInfo.es_local) || !!(sesion.empresaInfo && sesion.empresaInfo.comandas_programa) || !!(sesion.empresaInfo && sesion.empresaInfo.pedidos_programa)); }   /* 4.32 (§4.4): en el programa, con la bandera pedidos_programa; validación 4.32: o con comandas pendientes de pedidos ya asignados (comandas_programa) */
// El nombre de esta computadora ante las demás: «Caja 1 · Caja» o «Caja 1 · Cocina»
export function nombreEquipo(origen) { const t = terminalActual(); return String((t && t.nombre) || 'Esta computadora').slice(0, 45) + ' · ' + (origen === 'cocina' ? 'Cocina' : 'Caja'); }
// D-13: la sucursal de esta computadora (la de su caja; si no tiene, la de la sesión). Con «Todas» (vacío), solo cajas sin sucursal.
export function sucursalAqui() { const t = terminalActual(); return (t && t.sucursal_id) || sesion.sucursal_id || null; }
export function esDeEstaSucursal(copia, cfg, suc) { const c = cajaDe(cfg, copia ? copia.terminal_id : null); return suc ? String(c.sucursal_id || '') === String(suc) : !c.sucursal_id; }
const numeroPedido = c => (c && (c.pedido_numero || c.pedido_id)) || '';
// Las líneas de la ronda del pedido (enviadas con la cuenta) sin la marca de Cocina
const lineasSinImprimir = v => (v && Array.isArray(v.lineas) ? v.lineas : []).filter(l => l && l.enviado && String(l.enviado) === String(v.creado) && !l.impreso && +l.cantidad > 0);

// ---- D-15: ¿hay motivo para preguntar al servidor? Pura. ----
// true si el resumen dice que hay copias pendientes que una estación ya puede tomar, o si hay una cuenta en línea de menos de 30 min con
// platos de la ronda del pedido sin la marca «impreso» y su pedido no está en `resueltos` ni esperando (`esperando`: pedido → hasta, ms).
export function indicio(cuentas, resumen, { ahora = Date.now(), resueltos = null, esperando = null } = {}) {
  const r = resumen && typeof resumen === 'object' ? resumen : null;
  if (r && +r.comandas_pendientes > 0) {
    const esp = r.comanda_espera_s;
    if (esp === undefined) return true;
    if (esp !== null && esp !== '' && !isNaN(+esp) && (+r.hora || 0) + Math.max(0, +esp) * 1000 <= ahora) return true;
  }
  for (const v of Array.isArray(cuentas) ? cuentas : []) {
    if (!v || v.canal !== 'online' || !v.pedido_id) continue;
    const id = Number(v.pedido_id);
    if (resueltos && resueltos.has(id)) continue;
    if (esperando && (esperando.get(id) || 0) > ahora) continue;
    const c = Date.parse(v.creado || ''); if (isNaN(c) || ahora - c > VIGENCIA_CUENTA_MS) continue;
    if (lineasSinImprimir(v).length) return true;
  }
  return false;
}

// ---- memoria de la pestaña ----
const resueltos = new Set();          /* pedidos que el servidor dio por impresos, cerrados, viejos o sin comanda */
const esperas = new Map();            /* 'pedido|grupo' → hasta (ms): no intentar ese grupo antes */
const esperaPedido = new Map();       /* pedido → hasta (ms): pedidos para más tarde (no hace falta preguntar por ellos) */
const avisadas = new Set();           /* agotadas ya avisadas (una vez por comanda) */
let marcasPendientes = [];            /* marcas «impresa» que no llegaron: { cuerpo, num, eid } (se reintentan hasta que llegan, con la empresa de cada una) */
export const IMPRESAS_AQUI = new Set();   /* 'empresa|pedido|pos' que esta pestaña imprimió y cuya marca todavía no llegó: nunca se reclaman otra vez aquí */
let impresionFresca = 0;              /* cuándo se trajeron por última vez las impresoras y la configuración de las cajas */
let corriendo = false;
let empresaMemoria = null;            /* la empresa de lo que la pestaña recuerda por número de pedido (resueltos, esperas, avisadas) */
const timers = {};
const conEstacion = new Set();            /* 4.32: las pantallas (caja, cocina) que tienen la estación; mientras haya alguna, el temporizador de app.js cede */
let pasoAppCorriendo = false;        /* 4.32: una vuelta del temporizador de app.js a la vez */
let ultimoLatido = 0;                 /* 4.32: cuándo la pasada pidió por última vez los pendientes (así el programa le dice a la web que su estación vive) */
export const LATIDO_MS = 60000;
// 4.32 (§4.1): en el programa con pedidos_programa, la pasada pide los pendientes al menos cada 60 s aunque no haya indicio: sin esa consulta la
// web no le asigna pedidos (estacion_viva) y nunca llegaría a haber indicio. En la web y sin la bandera, nada cambia (como la 4.31).
export function latidoDebido(ahora = Date.now()) { const i = sesion.empresaInfo; return !!(i && i.es_local && i.pedidos_programa) && ahora - ultimoLatido >= LATIDO_MS; }
// Solo para las pruebas: deja la memoria como al abrir la pestaña
export function _reiniciar() { conEstacion.clear(); pasoAppCorriendo = false; ultimoLatido = 0; resueltos.clear(); esperas.clear(); esperaPedido.clear(); avisadas.clear(); marcasPendientes = []; IMPRESAS_AQUI.clear(); impresionFresca = 0; corriendo = false; empresaMemoria = null; EN_CURSO.clear(); Object.assign(estadoEstacion, { activa: false, puede: null, conProgramaAnterior: false, ultima: null, resumen: null, lista: [] }); }
export function _marcasPendientes() { return marcasPendientes.map(m => m.cuerpo); }   /* solo para las pruebas */

// La empresa de la sesión. El selector de empresa cambia de empresa sin recargar la página: las marcas que no llegaron y los platos impresos
// aquí llevan su empresa (se mandan y se cuentan solo con la sesión de esa empresa), y lo demás que la pestaña recuerda por número de
// pedido se olvida al cambiar de empresa (el pedido #12 de una empresa no es el #12 de otra).
const empresaAqui = () => String(sesion.empresa_id || 0);
const claveAqui = (eid, pedido, pos) => String(eid) + '|' + claveEnCurso(pedido, pos);
// Cada pasada de la estación (y cada «Imprimir» de Cocina o de la banda) recuerda la empresa con la que empezó y TODAS sus peticiones al
// servidor salen con esa empresa: pedirDe(eid) en lugar de api. Si la pestaña ya está en otra empresa, la petición no sale (queda como «sin
// conexión»: una marca espera en la cola con su empresa) y quien llama se detiene sin reclamar ni imprimir nada más (OTRA_EMPRESA). La
// comparación y la petición van en el mismo instante (api() toma la sesión al llamarla y la sesión cambia de una sola vez), y la petición
// lleva además la empresa (X-Empresa): el servidor rechaza la sesión de otra empresa.
export const OTRA_EMPRESA = 'otra_empresa';
function pedirDe(eid) {
  return (url, opt) => {
    if (empresaAqui() !== eid) return Promise.reject(new Error('La pestaña cambió de empresa'));
    const o = { ...(opt || {}) };
    if (/^[1-9]\d*$/.test(eid)) o.headers = { ...(o.headers || {}), 'X-Empresa': eid };
    return api(url, o);
  };
}
function alDiaConLaEmpresa() {
  const e = empresaAqui();
  if (empresaMemoria !== null && empresaMemoria !== e) { resueltos.clear(); esperas.clear(); esperaPedido.clear(); avisadas.clear(); impresionFresca = 0; Object.assign(estadoEstacion, { activa: false, puede: null, conProgramaAnterior: false, ultima: null, resumen: null, lista: [] }); }
  empresaMemoria = e;
}
// Un negocio que no es restaurante solo imprime comandas de las cajas en modo restaurante (como el aceptar, que solo imprime con menú)
const soloRestaurante = () => sesion.tipo !== 'restaurante';
// La copia con los platos que esta pestaña ya imprimió (y cuya marca no ha llegado) como impresos (solo los de la empresa de la sesión)
function conImpresasAqui(c) { const eid = empresaAqui(); return c && Array.isArray(c.lineas) ? { ...c, lineas: c.lineas.map(l => (l && IMPRESAS_AQUI.has(claveAqui(eid, c.pedido_id, l.pos)) ? { ...l, estado: 'impresa' } : l)) } : c; }
// D-19: cuándo sale sola la comanda de un pedido para más tarde (ms), con la regla del servidor (comandas.listo_desde): la hora de entrega
// («HH:MM», hora de Costa Rica) del día de `creado` menos 45 minutos; si esa hora queda más de una hora antes de `creado`, es del día
// siguiente. null = sin hora de entrega (sale apenas entra a la caja).
export function salidaProgramada(creado, hora) {
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(hora || '').trim()), c = Date.parse(creado || '');
  if (!m || isNaN(c)) return null;
  const CR = 6 * 3600000, d = new Date(c - CR);                /* Costa Rica: UTC−6 todo el año */
  let entrega = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), +m[1], +m[2]) + CR;
  if (entrega < c - 3600000) entrega += 86400000;
  return Math.max(c, entrega - ANTICIPO_PROGRAMADO_MIN * 60000);
}
// Cada plato de la tarjeta con su posición en la copia: [[línea, pos]] (cada plato de la copia, una sola vez); los que no son de la copia no van
function parejasDeCopia(lineas, copia) {
  const usadas = new Set(), out = [];
  for (const l of Array.isArray(lineas) ? lineas : []) {
    const c = ((copia && Array.isArray(copia.lineas)) ? copia.lineas : []).find(x => x && Number.isInteger(+x.pos) && !usadas.has(+x.pos) && esLineaDeCopia(l, x, copia));
    if (c) { usadas.add(+c.pos); out.push([l, +c.pos]); }
  }
  return out;
}
// Trae otra vez las impresoras y la configuración de las cajas (otra computadora pudo cambiarlas): «sin comanda» es definitivo en el servidor
// y nunca se decide con datos viejos. true = traídas hace menos de `edad` ms (o esta pantalla no tiene de dónde traerlas); false = no se pudo
// (también si la pestaña ya no está en la empresa `eid`: lo traído sería de la otra).
async function refrescarImpresion(edad, eid) {
  if (empresaAqui() !== eid) return false;
  if (typeof mock.refrescar !== 'function') return true;
  if (impresionFresca && Date.now() - impresionFresca < edad) return true;
  let r = false;
  try { r = await conTope(mock.refrescar(CLAVES_IMPRESION, { sinCorte: true }), 10000, false); } catch { r = false; }
  if (r === false || empresaAqui() !== eid) return false;
  impresionFresca = Date.now();
  return true;
}
// La marca «impresa» de lo que salió en esta pestaña: si no llega, queda para reintentarla en cada pasada hasta que llegue (con su empresa).
// Si la pestaña ya está en otra empresa, no sale: queda en la cola hasta que la pestaña vuelva a la suya.
async function marcarAqui(cuerpo, num, eid) {
  const m = await conTope(marcarComandaImpresa(pedirDe(eid), cuerpo), 10000, { resultado: 'sin_red' });
  if (marcaPorReintentar(m)) { marcasPendientes.push({ cuerpo, num, eid }); return m; }
  if (m.resultado !== 'error') for (const p of cuerpo.lineas || []) IMPRESAS_AQUI.delete(claveAqui(eid, cuerpo.pedido_id, p));
  if (m.cancelado && empresaAqui() === eid) toast(textoCancelado(num), 'err');
  return m;
}

// El resumen de pedidos (GET /api/pedidos/resumen): la caja lo guarda en revisarOnline; Cocina lo pide sola (iniciarEstacion)
export function guardarResumen(r) {
  if (!r || typeof r !== 'object') return;
  alDiaConLaEmpresa();
  estadoEstacion.resumen = { comandas_pendientes: +r.comandas_pendientes || 0, comanda_espera_s: r.comanda_espera_s === undefined ? undefined : r.comanda_espera_s, hora: Date.now() };
}
export async function revisarResumen() {
  if (!estacionPosible()) return;
  alDiaConLaEmpresa();
  const eid = empresaAqui();
  let r = null;
  try { r = await conTope(pedirDe(eid)('/api/pedidos/resumen'), 10000, null); } catch { r = null; /* sin red: en la próxima */ }
  if (empresaAqui() !== eid) return;                                              /* la pestaña cambió de empresa: el resumen era de la otra */
  guardarResumen(r);
  if (estadoEstacion.resumen && !estadoEstacion.resumen.comandas_pendientes) estadoEstacion.lista = [];
  else if (!estacionEncendida() && estadoEstacion.resumen && !document.hidden) await refrescarListaCocina(eid);   /* con la estación apagada, la banda igual se llena */
}
// Inicio y parada de la página (caja o cocina). Cocina consulta el resumen cada 30 s (solo con pedidos en línea, D-15).
export function iniciarEstacion(origen) {
  pararEstacion(origen);
  conEstacion.add(origen);
  if (!estacionPosible()) return;
  alDiaConLaEmpresa();
  if (origen === 'cocina') { revisarResumen(); timers.cocina = setInterval(() => revisarResumen(), 30000); }
}
export function pararEstacion(origen) { if (timers[origen]) { clearInterval(timers[origen]); delete timers[origen]; } conEstacion.delete(origen); }

// ---- 4.32 (§4.4): la estación en cualquier pantalla del programa. app.js llama iniciarDesdeApp() al entrar con sesión cuando
// sesion.empresaInfo.pedidos_programa es verdadero, y pararDesdeApp() al salir o al cambiar de empresa (las dos, cuantas veces quiera).
// Cada 10 s hace lo mismo que la caja en su refresco: el resumen de pedidos (guardarResumen) y LA PASADA (revisarEstacion('caja')).
// Cede mientras la Caja o Cocina tengan la estación (iniciarEstacion) y la retoma sola cuando la sueltan (pararEstacion). Nunca corren
// dos pasadas a la vez en la pestaña: revisarEstacion tiene su candado (corriendo) y este temporizador no empieza una vuelta si la
// anterior no terminó. Entre pestañas o computadoras manda el reclamo por plato del servidor, como siempre.
export const ESTACION_APP_MS = 10000;
export function estacionDesdeApp() { return !!timers.app; }
export function estacionCedida() { return conEstacion.size > 0; }
export async function pasoDesdeApp() {
  if (pasoAppCorriendo) return 'corriendo';
  if (conEstacion.size) return 'cedida';
  if (!estacionPosible()) return 'sin_modulo';
  if (typeof document !== 'undefined' && document.hidden) return 'oculta';
  pasoAppCorriendo = true;
  try {
    if (!estacionEncendida()) return await revisarEstacion('caja');        /* apagada en esta computadora: solo las marcas pendientes, sin preguntar más */
    await revisarResumen();
    if (conEstacion.size) return 'cedida';                                     /* la Caja o Cocina la tomó mientras llegaba el resumen */
    return await revisarEstacion('caja');
  } catch { return 'error'; } finally { pasoAppCorriendo = false; }
}
export function iniciarDesdeApp() {
  if (timers.app) return false;
  timers.app = setInterval(() => { pasoDesdeApp(); }, ESTACION_APP_MS);
  pasoDesdeApp();
  return true;
}
export function pararDesdeApp() { if (!timers.app) return false; clearInterval(timers.app); delete timers.app; return true; }

// El texto de la banda de Cocina ('' = no se muestra)
export function textoEstacion() {
  if (!estacionPosible() || !estacionEncendida()) return '';
  if (estadoEstacion.activa && estadoEstacion.puede === true) return TEXTO_ACTIVA;
  if (estadoEstacion.puede === false) return TEXTO_SIN_IMPRESION;
  return '';
}

// Los datos de impresión de esta pantalla (registros ya cargados)
function datosImpresion(ahora) {
  let extras = {}; try { extras = mock.get('items_extra', {}) || {}; } catch { extras = {}; }
  return { impresoras: impresoras(), categorias: categorias(), extras, productos: store.productos || [], cfg: config(), ahora };
}
const esperaDeOrigen = c => (c && c.origen === 'aceptar_anterior' ? 60 : 15) * 1000;
// La lista de la banda de Cocina: copias de esta sucursal con la espera ya pasada hace más de 60 s o cuya cuenta ya no está en la caja.
// Un pedido para más tarde no entra antes de su hora (espere_s); con `datos` (impresoras y cajas de esta pantalla), tampoco una copia sin
// ningún plato para una impresora de comanda (se atiende en la pantalla de Cocina).
export function listaCocina(copias, ahoraServidor, cfg, suc, datos) {
  const a = Date.parse(ahoraServidor || '') || Date.now(), out = [];
  for (const c0 of Array.isArray(copias) ? copias : []) {
    if (!c0 || c0.estado && c0.estado !== 'pendiente' || c0.vieja || +c0.espere_s > 0 || !esDeEstaSucursal(c0, cfg, suc)) continue;
    const c = conImpresasAqui(c0);
    if (!(c.lineas || []).some(l => l && l.estado !== 'impresa')) continue;
    if (datos && !gruposDeCopia(c, { ...datos, incluirReclamadas: true, soloRestaurante: soloRestaurante() }).grupos.length) continue;
    const listo = Date.parse(c.listo_desde || c.creado || '');
    if (!(c.cuenta_viva === false || (!isNaN(listo) && a - listo - esperaDeOrigen(c) > 60000))) continue;
    out.push({ pedido_id: c.pedido_id, numero: numeroPedido(c), texto: textoLista(numeroPedido(c), (a - (Date.parse(c.creado || '') || a)) / 60000) });
  }
  return out;
}
async function refrescarListaCocina(eid) {
  const pen = await conTope(pendientesComanda(pedirDe(eid)), 10000, { resultado: 'sin_red' });
  if (pen.resultado === 'ok' && empresaAqui() === eid) estadoEstacion.lista = listaCocina(pen.copias, pen.ahora, config(), sucursalAqui(), datosImpresion(pen.ahora));
}

// Reintenta las marcas «impresa» que no llegaron, hasta que lleguen. Solo las de la empresa de la sesión: las de otra esperan a que la
// pestaña vuelva a ella. Una marca que no llega (servidor caído u ocupado) queda para la pasada siguiente, al final de la cola, y se sigue
// con las demás: una marca que falla siempre no tapa a las otras. Sin conexión se para ahí (las demás tampoco llegarían ahora). Si la
// pestaña cambia de empresa en medio, también se para: las que faltan esperan con su empresa.
async function reintentarMarcas() {
  const lote = marcasPendientes, eid = empresaAqui(), pedir = pedirDe(eid), quedan = [], fallidas = [];
  marcasPendientes = [];
  for (let i = 0; i < lote.length; i++) {
    const m = lote[i];
    if (m.eid !== eid) { quedan.push(m); continue; }
    if (empresaAqui() !== eid) { quedan.push(...lote.slice(i)); break; }
    const r = await conTope(marcarComandaImpresa(pedir, m.cuerpo), 10000, { resultado: 'sin_red' });
    if (marcaPorReintentar(r)) {
      fallidas.push(m);
      if (r.resultado === 'sin_red') { quedan.push(...lote.slice(i + 1)); break; }
      continue;
    }
    if (r.resultado !== 'error') for (const p of m.cuerpo.lineas || []) IMPRESAS_AQUI.delete(claveAqui(m.eid, m.cuerpo.pedido_id, p));
    if (r.cancelado && empresaAqui() === eid) toast(textoCancelado(m.num), 'err');
  }
  marcasPendientes = quedan.concat(fallidas, marcasPendientes);
}

// ---- LA PASADA de la estación (al final del refresco de 15 s de la caja y de Cocina). Nunca lanza; devuelve por qué terminó. ----
export async function revisarEstacion(origen) {
  try {
    if (!estacionPosible()) return 'sin_modulo';
    alDiaConLaEmpresa();
    if (!estacionEncendida()) {
      estadoEstacion.activa = false;
      if (marcasPendientes.length && !corriendo && mock.cargado) { corriendo = true; try { await reintentarMarcas(); } finally { corriendo = false; } }   /* lo que se imprimió a mano en Cocina */
      return 'apagada';
    }
    if (typeof document !== 'undefined' && document.hidden) return 'oculta';
    if (!mock.cargado) return 'sin_datos';
    if (corriendo) return 'corriendo';
    corriendo = true;
    try { return await pasada(origen); } finally { corriendo = false; }
  } catch { return 'error'; }
}
const cedulaEmpresa = () => (sesion.empresaInfo && sesion.empresaInfo.numero_id) || '';
// 4.32 (§4.4): en el programa la estación imprime por el servicio de impresión del propio programa (/api/agente/*), como su Caja; el agente
// suelto del 9800 es solo de la página web (en la computadora del cliente el 9800 es otro programa, o nadie). Antes la pasada preguntaba
// solo al 9800 ({ soloAgente: true }) también en el programa: terminaba en «sin_agente» y la comanda del pedido en línea nunca salía.
const enPrograma = () => !!(sesion.empresaInfo && sesion.empresaInfo.es_local);
const opcionesAgente = () => (enPrograma() ? {} : { soloAgente: true });
// La pasada es de la empresa con la que empezó: después de cada espera, si la pestaña cambió de empresa, se detiene ahí (OTRA_EMPRESA) sin
// reclamar, imprimir, marcar ni anotar nada más en la memoria de la pestaña (que ya es la de la otra empresa).
async function pasada(origen) {
  const eid = empresaAqui(), pedir = pedirDe(eid), sigue = () => empresaAqui() === eid;
  estadoEstacion.activa = true;
  if (marcasPendientes.length) await reintentarMarcas();
  if (!sigue()) return OTRA_EMPRESA;
  if (!latidoDebido() && !indicio(enEspera(), estadoEstacion.resumen, { ahora: Date.now(), resueltos, esperando: esperaPedido })) return 'sin_indicio';
  ultimoLatido = Date.now();
  const pen = await conTope(pendientesComanda(pedir), 10000, { resultado: 'sin_red' });
  if (!sigue()) return OTRA_EMPRESA;
  if (pen.resultado !== 'ok') return pen.resultado;
  const ahora = Date.now(), suc = sucursalAqui();
  // una cuenta en línea cuyo pedido ya no tiene copia pendiente (impresa, sin comanda, vieja o anterior a la 4.31) deja de ser indicio
  if (pen.copias.length < 50) { const ids = new Set(pen.copias.map(c => Number(c.pedido_id))); for (const v of enEspera()) if (v && v.canal === 'online' && v.pedido_id && !ids.has(Number(v.pedido_id))) resueltos.add(Number(v.pedido_id)); }
  const copias = pen.copias.filter(c => c && (!c.estado || c.estado === 'pendiente') && !c.vieja && esDeEstaSucursal(c, config(), suc));
  for (const c of copias) { const e = +c.espere_s || 0; if (e > 0) esperaPedido.set(Number(c.pedido_id), ahora + e * 1000); else esperaPedido.delete(Number(c.pedido_id)); }
  const listas = copias.filter(c => !(+c.espere_s > 0)).map(conImpresasAqui);
  // con copias listas: las impresoras y las cajas al día (otra computadora pudo cambiarlas) y, si el servicio de impresión de esta
  // computadora ya dijo que es el programa 4.31, sus ajustes de «En esta computadora» (D-12), antes de decidir a dónde va cada plato
  if (listas.length) await refrescarImpresion(REFRESCO_IMPRESION_MS, eid);
  if (listas.length && (enPrograma() || sabeEquipo(ultimoEstadoAgente())) && sigue()) await conTope(cargarEquipo(false, { cedula: cedulaEmpresa(), ...opcionesAgente() }), 5000, null).catch(() => null);
  if (!sigue()) return OTRA_EMPRESA;
  let datos = datosImpresion(pen.ahora), conDirectos = false;
  estadoEstacion.lista = listaCocina(pen.copias, pen.ahora, config(), suc, datos);
  // los platos que no van a ninguna impresora: si son toda la copia, se avisa al servidor (la copia deja de ser candidata y queda en la
  // pantalla de Cocina sin marca de impresa). Solo con las impresoras y las cajas recién traídas: «sin comanda» es definitivo.
  const grupos = c => gruposDeCopia(c, { ...datos, paraEstacion: true, soloRestaurante: soloRestaurante() });
  const todoSin = (c, g) => { const yaSin = new Set((c.sin_comanda || []).map(Number)); return !g.grupos.length && g.sin_comanda.length > 0 && g.sin_comanda.length === (c.lineas || []).filter(l => l && l.estado !== 'impresa' && !yaSin.has(+l.pos)).length; };
  for (const c of listas) {
    let g = grupos(c);
    if (todoSin(c, g)) {
      const fresca = await refrescarImpresion(REFRESCO_SIN_COMANDA_MS, eid);
      if (!sigue()) return OTRA_EMPRESA;
      if (!fresca) continue;                                     /* sin datos frescos no se decide: en la próxima pasada */
      datos = datosImpresion(pen.ahora); g = grupos(c);
      if (todoSin(c, g)) {
        const r = await conTope(marcarComandaImpresa(pedir, { pedido_id: c.pedido_id, equipo: EQUIPO, lineas: [], sin_comanda: g.sin_comanda }), 10000, { resultado: 'sin_red' });
        if (!sigue()) return OTRA_EMPRESA;
        if (r.resultado !== 'sin_red' && r.resultado !== 'error') resueltos.add(Number(c.pedido_id));
      }
    }
    if (g.grupos.some(x => x.directo)) conDirectos = true;
  }
  if (!conDirectos) return 'sin_directos';                     /* sin impresoras USB o de red: ni una petición al agente */
  const est = await conTope(agenteEstado(false, opcionesAgente()), 5000, { ok: false });
  if (!sigue()) return OTRA_EMPRESA;
  if (!est || !est.ok) { estadoEstacion.puede = false; return 'sin_agente'; }
  estadoEstacion.puede = true;
  estadoEstacion.conProgramaAnterior = !enPrograma() && !sabeEquipo(est);
  await conTope(cargarEquipo(false, { cedula: cedulaEmpresa(), ...opcionesAgente() }), 5000, null).catch(() => null);
  if (!sigue()) return OTRA_EMPRESA;
  datos = datosImpresion(pen.ahora);                           /* con los ajustes de esta computadora ya cargados */
  let hechos = 0;
  for (const c of listas) {
    if (hechos >= MAX_GRUPOS_PASADA) break;
    const id = Number(c.pedido_id), num = numeroPedido(c);
    if (resueltos.has(id)) continue;
    let g = grupos(c), sinComanda = g.sin_comanda;
    if (sinComanda.length && g.grupos.some(x => x.directo)) {                   /* «sin comanda» va con la marca: también con datos de hace 15 s como mucho */
      const antes = impresionFresca, fresca = await refrescarImpresion(REFRESCO_SIN_COMANDA_MS, eid);
      if (!sigue()) return OTRA_EMPRESA;
      if (!fresca) sinComanda = [];
      else if (impresionFresca !== antes) { datos = datosImpresion(pen.ahora); g = grupos(c); sinComanda = g.sin_comanda; }
    }
    for (const gr of g.grupos) {
      if (!gr.directo || hechos >= MAX_GRUPOS_PASADA) continue;
      const clave = id + '|' + gr.id;
      if ((esperas.get(clave) || 0) > Date.now()) continue;
      if (gr.pos.some(p => EN_CURSO.has(claveEnCurso(id, p)))) continue;
      hechos++;
      const r = await conTope(reclamarComanda(pedir, { pedido_id: id, lineas: gr.pos, grupo: gr.id, grupo_nombre: gr.imp.nombre, equipo: EQUIPO, nombre: nombreEquipo(origen), momento: 'estacion' }), 10000, { resultado: 'sin_red' });
      if (!sigue()) return OTRA_EMPRESA;                       /* lo reclamado no se imprime: el reclamo vence solo en un minuto y sale después */
      if (r.resultado === 'ganada') { await imprimirGanado(c, gr, Array.isArray(r.lineas) && r.lineas.length ? r.lineas : gr.pos, sinComanda, num, clave, eid); if (!sigue()) return OTRA_EMPRESA; }
      else if (r.resultado === 'pronto' || r.resultado === 'reintente') esperas.set(clave, Date.now() + Math.max(5, +r.espere_s || 15) * 1000);
      else if (r.resultado === 'ocupada' || r.resultado === 'en_curso') esperas.set(clave, Date.now() + ESPERA_OCUPADA_MS);
      else if (r.resultado === 'impresa') esperas.set(clave, Date.now() + 10 * 60000);
      else if (r.resultado === 'agotada') { esperas.set(clave, Date.now() + 10 * 60000); if (!avisadas.has(clave)) { avisadas.add(clave); toast(textoAgotada(num, gr.imp.nombre), 'err'); } }
      else if (['cancelado', 'sin_copia', 'vieja'].includes(r.resultado)) { resueltos.add(id); break; }
      else return r.resultado;                                 /* sin red o error: en la próxima pasada */
    }
  }
  estadoEstacion.ultima = Date.now();
  return 'lista';
}
// Imprime el grupo ganado y lo marca (o lo suelta con el motivo y no lo vuelve a intentar en 60 s). Si la pestaña cambió de empresa mientras
// se imprimía, la marca queda en la cola con la empresa `eid` (sale cuando la pestaña vuelva a ella), no se suelta (el reclamo vence solo)
// y no se avisa ni se anota nada en la memoria de la pestaña, que ya es la de la otra empresa.
async function imprimirGanado(copia, gr, lineas, sinComanda, num, clave, eid) {
  const id = Number(copia.pedido_id), claves = lineas.map(p => claveEnCurso(id, p)), sigue = () => empresaAqui() === eid;
  for (const k of claves) EN_CURSO.add(k);
  try {
    const sel = { ...gr, lineas: gr.lineas.filter(l => lineas.includes(+l.pos)) };
    const res = await imprimirGrupoCopia(copia, sel, { respaldoNavegador: false, local: enPrograma() });
    if (!res.fallas.length && res.impresas.length) {
      for (const p of res.impresas) IMPRESAS_AQUI.add(claveAqui(eid, id, p));   /* salió aquí: esta pestaña no lo vuelve a reclamar aunque la marca tarde */
      const m = await marcarAqui({ pedido_id: id, equipo: EQUIPO, lineas: res.impresas, sin_comanda: sinComanda }, num, eid);
      if (!sigue()) return;
      if (!m.cancelado) toast(textoSalio(num, gr.imp.nombre), 'ok');
      esperas.set(clave, Date.now() + 10 * 60000);
    } else {
      const motivo = res.fallas.join('; ') || 'no se pudo imprimir';
      if (sigue()) await conTope(soltarComanda(pedirDe(eid), { pedido_id: id, equipo: EQUIPO, lineas, motivo }), 10000, null);
      if (!sigue()) return;
      esperas.set(clave, Date.now() + ESPERA_FALLA_MS);
      toast(textoFallo(num, gr.imp.nombre, motivo), 'err');
    }
  } finally { for (const k of claves) EN_CURSO.delete(k); }
}

// ---- D-19: al cobrar o cargar a la habitación (sin peticiones; no bloquea ni espera) ----
// `cuenta` = la cuenta de pos_espera o su id (se busca en la caja antes de quitarla). Avisa si es de un pedido en línea con la comanda sin
// imprimir y esta pestaña no es una estación activa que puede imprimir. Devuelve si avisó. No avisa si esos platos no van a ninguna
// impresora de comanda (sin impresoras de comanda, la caja con «imprimir la comanda» apagado, platos «sin comanda»): nada saldrá solo.
// Es un aviso informativo (la comanda saldrá sola), no un error. Un pedido para más tarde dice cuándo saldrá sola (45 minutos antes de la
// hora de entrega), no «si en un minuto no ha salido»: antes de esa hora no sale ni aparece en la banda de Cocina.
export function avisarSiPendiente(cuenta) {
  try {
    if (!estacionPosible()) return false;
    alDiaConLaEmpresa();
    const v = cuenta && typeof cuenta === 'object' ? cuenta : (cuenta !== null && cuenta !== undefined ? enEspera().find(x => x && x.id === cuenta) : null);
    if (!v || v.canal !== 'online' || !v.pedido_id || resueltos.has(Number(v.pedido_id))) return false;
    const faltan = lineasSinImprimir(v);
    if (!faltan.length) return false;
    if (!gruposDeCopia({ terminal_id: v.terminal_id, lineas: faltan.map((l, i) => ({ ...l, pos: i, estado: 'libre' })) }, { ...datosImpresion(null), soloRestaurante: soloRestaurante() }).grupos.length) return false;
    if (estacionEncendida() && estadoEstacion.activa && estadoEstacion.puede === true && !(typeof document !== 'undefined' && document.hidden)) return false;
    const num = v.pedido_numero || v.pedido_id, sale = salidaProgramada(v.creado, v.hora_entrega);
    toast(sale !== null && sale > Date.now() ? textoCobroMasTarde(num, String(v.hora_entrega).trim()) : textoCobroSinImprimir(num), 'info');
    return true;
  } catch { return false; }
}

// ---- D-9: Cocina a mano (también la banda). Reclama con momento 'cocina' (sin espera ni topes) y pregunta si otra la tiene. ----
// Solo lo de la tarjeta tocada: `lineas` = sus platos (su ronda y su estación); se reclaman, se imprimen y se marcan solo los platos de la
// copia que les corresponden. Sin `lineas` (la banda), todos los de la copia. `vent` = { w: la ventana del navegador abierta en el toque }:
// la usa la impresión de la copia (que la cierra si no le hace falta); si solo la necesitan los platos que no son de la copia, queda en
// vent.w para Cocina. Antes de cualquier pregunta se cierra, para que la pregunta se vea, y con «Sí» se abre otra enseguida (lo más cerca
// posible del toque). Nunca se marca impreso lo que no salió.
// Devuelve { hecho, resultado, marcar?, resto? }: `marcar` = los platos de la tarjeta que ya salieron (para la marca de la pantalla de Cocina),
// `resto` = los platos de la tarjeta que no son de la copia (Cocina los imprime como hoy). resultado:
//   'impresa'    se imprimió lo que faltaba (o lo de la copia ya estaba y queda `resto`)
//   'ya_impresa' según el servidor, todo lo de la tarjeta ya salió: imprimirla otra vez es una reimpresión a propósito
//   'sin_copia'  cuenta sin copia (anterior a la 4.31), platos de otra ronda o nada de la tarjeta va a una impresora de comanda: lo de hoy
//   'no'         el usuario no quiso, esta misma pestaña la está imprimiendo o el pedido se canceló
//   'sin_red'    (solo la banda) no se pudo leer la copia: sin ella la banda no tiene qué imprimir; no se pregunta nada
//   'otra_empresa' la pestaña cambió de empresa en medio: no se reclamó ni se imprimió nada más (lo que ya salió queda con su marca en la
//                cola de esa empresa) y no hay nada que hacer en la pantalla, que ya es de la otra empresa
const salida = (hecho, resultado, marcar, resto) => ({ hecho, resultado, ...(marcar && marcar.length ? { marcar } : {}), ...(resto && resto.length ? { resto } : {}) });
export async function imprimirPedidoCocina(pedidoId, { preguntar, lineas, vent } = {}) {
  const preguntarYa = typeof preguntar === 'function' ? preguntar : (x => (typeof confirm === 'function' ? confirm(x) : false));
  const cerrarVentana = () => { if (vent && vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } vent.w = null; } };
  const pregunta = x => { const habia = !!(vent && vent.w); cerrarVentana(); const si = preguntarYa(x); if (si && habia) vent.w = ventanaEnBlanco(); return si; };
  const id = Number(pedidoId), conTarjeta = Array.isArray(lineas);
  if (!estacionPosible() || !Number.isInteger(id) || id <= 0) return salida(false, 'sin_copia');
  alDiaConLaEmpresa();
  const eid = empresaAqui(), pedir = pedirDe(eid), sigue = () => empresaAqui() === eid;   /* todo con la empresa del toque */
  const otra = () => { cerrarVentana(); return salida(false, OTRA_EMPRESA); };
  const pen = await conTope(pendientesComanda(pedir, { pedido_id: id }), 10000, { resultado: 'sin_red' });
  if (!sigue()) return otra();
  if (pen.resultado === 'sin_red' || pen.resultado === 'error') {
    if (!conTarjeta) return salida(false, 'sin_red');
    if (!pregunta(TEXTO_SIN_RED_COCINA)) return salida(false, 'no');
    return salida(false, 'sin_copia');
  }
  const original = pen.resultado === 'ok' ? pen.copias.find(c => c && Number(c.pedido_id) === id) : null;
  if (!original || original.estado === 'sin_comanda') return salida(false, 'sin_copia');   /* sin copia, o nada va a una impresora de comanda: lo de hoy */
  const copia = conImpresasAqui(original), num = numeroPedido(copia);
  const pares = conTarjeta ? parejasDeCopia(lineas, copia) : (copia.lineas || []).filter(l => l && Number.isInteger(+l.pos)).map(l => [null, +l.pos]);
  if (!pares.length) return salida(false, 'sin_copia');                           /* ningún plato de la tarjeta es de la copia (otra ronda): lo de hoy */
  const resto = conTarjeta ? lineas.filter(l => !pares.some(([x]) => x === l)) : [];
  const mias = new Set(pares.map(([, p]) => p));
  const lineasDe = ps => pares.filter(([l, p]) => l && ps.includes(p)).map(([l]) => l);
  const yaSalieron = [...mias].filter(p => copia.estado === 'impresa' || ((copia.lineas || []).find(l => l && +l.pos === p) || {}).estado === 'impresa');
  const sub = { ...copia, lineas: (copia.lineas || []).filter(l => l && mias.has(+l.pos)) };
  const calcular = () => (copia.estado === 'impresa' ? { grupos: [], sin_comanda: [] } : gruposDeCopia(sub, { ...datosImpresion(pen.ahora), incluirReclamadas: true, soloRestaurante: soloRestaurante() }));
  let g = calcular();
  const fresca = g.sin_comanda.length ? await refrescarImpresion(REFRESCO_SIN_COMANDA_MS, eid) : false;
  if (!sigue()) return otra();
  if (fresca) g = calcular();
  const sinComanda = fresca ? g.sin_comanda : [];                                 /* «sin comanda» se manda solo con las impresoras y las cajas recién traídas */
  if (!g.grupos.length) {
    if (sinComanda.length && copia.estado === 'pendiente') await conTope(marcarComandaImpresa(pedir, { pedido_id: id, equipo: EQUIPO, lineas: [], sin_comanda: sinComanda }), 10000, null);
    if (!sigue()) return otra();
    if (!yaSalieron.length) return salida(false, 'sin_copia');                     /* nada de la tarjeta va a una impresora de comanda: no se marca nada */
    return resto.length ? salida(false, 'impresa', lineasDe(yaSalieron), resto) : salida(false, 'ya_impresa', lineasDe(yaSalieron));
  }
  const imprimir = [], sinReclamo = [], yaEstaban = [];
  for (const gr of g.grupos) {
    if (gr.pos.some(p => EN_CURSO.has(claveEnCurso(id, p)))) continue;          /* esta misma pestaña la está imprimiendo (la estación) */
    const r = await conTope(reclamarComanda(pedir, { pedido_id: id, lineas: gr.pos, grupo: gr.id, grupo_nombre: gr.imp.nombre, equipo: EQUIPO, nombre: nombreEquipo('cocina'), momento: 'cocina' }), 10000, { resultado: 'sin_red' });
    if (!sigue()) return otra();                                                   /* lo reclamado no se imprime: el reclamo vence solo en un minuto */
    if (r.resultado === 'ganada') {
      const tomadas = Array.isArray(r.lineas) && r.lineas.length ? r.lineas.map(Number) : gr.pos;
      yaEstaban.push(...gr.pos.filter(p => !tomadas.includes(p)));               /* las que ya estaban impresas en el servidor */
      imprimir.push({ ...gr, lineas: gr.lineas.filter(l => tomadas.includes(+l.pos)) });
    } else if (r.resultado === 'impresa') yaEstaban.push(...gr.pos);
    else if (r.resultado === 'ocupada') { if (pregunta(textoOcupadaCocina(r.por))) { imprimir.push(gr); sinReclamo.push(gr.id); } }
    else if (r.resultado === 'sin_red' || r.resultado === 'error' || r.resultado === 'sin_ruta') { if (pregunta(TEXTO_SIN_RED_COCINA)) { imprimir.push(gr); sinReclamo.push(gr.id); } }
    else if (r.resultado === 'cancelado') { cerrarVentana(); toast(textoCancelado(num), 'err'); return salida(false, 'no'); }
  }
  const salidas = [...yaSalieron, ...yaEstaban];
  if (!imprimir.length) {
    if (!resto.length) cerrarVentana();                                            /* con platos de fuera de la copia, queda para Cocina */
    const todo = g.grupos.every(gr => gr.pos.every(p => salidas.includes(p)));    /* otra la imprimió en este instante: reimprimir es a propósito */
    return todo && !resto.length ? salida(false, 'ya_impresa', lineasDe(salidas)) : salida(false, todo ? 'impresa' : 'no', lineasDe(salidas), resto);
  }
  const claves = imprimir.flatMap(gr => gr.lineas.map(l => claveEnCurso(id, l.pos)));
  for (const k of claves) EN_CURSO.add(k);
  try {
    const paraCopia = !resto.length || imprimir.some(gr => !gr.directo);          /* si solo la necesitan los platos de fuera de la copia, queda para Cocina */
    const ventana = vent && paraCopia ? vent.w : null; if (vent && paraCopia) vent.w = null;   /* imprimirComandas la usa o la cierra */
    const res = await imprimirGrupoCopia(copia, imprimir, { ventana, respaldoNavegador: true, local: !!(sesion.empresaInfo && sesion.empresaInfo.es_local) });
    const salieron = res.impresas.filter(p => Number.isInteger(p));
    for (const p of salieron) IMPRESAS_AQUI.add(claveAqui(eid, id, p));
    for (const gr of imprimir) {
      const todas = gr.lineas.map(l => +l.pos), ps = todas.filter(p => salieron.includes(p)), falta = todas.filter(p => !salieron.includes(p));
      if (ps.length) await marcarAqui({ pedido_id: id, equipo: EQUIPO, lineas: ps, sin_comanda: sinComanda }, num, eid);   /* con otra empresa en la pestaña, queda en la cola con la suya */
      if (falta.length) {                                                          /* no salió: no se marca; se suelta para que otra la imprima */
        const propias = res.fallas.filter(f => f.includes('«' + gr.imp.nombre + '»')), motivo = (propias.length ? propias : res.fallas).join('; ') || 'no se pudo imprimir';
        if (!sinReclamo.includes(gr.id) && sigue()) await conTope(soltarComanda(pedir, { pedido_id: id, equipo: EQUIPO, lineas: falta, motivo }), 10000, null);
        if (sigue()) toast(textoFalloCocina(num, gr.imp.nombre, motivo), 'err');
      }
    }
    if (!sigue()) return salida(salieron.length > 0, OTRA_EMPRESA);
    return salida(salieron.length > 0, 'impresa', lineasDe([...salidas, ...salieron]), resto);
  } finally { for (const k of claves) EN_CURSO.delete(k); }
}
// La ventana del navegador se abre en el toque (después de esperar al servidor el navegador puede bloquearla, sobre todo Safari): si algún
// plato de la tarjeta sale por la ventana del navegador, sea desde la copia o por el camino de siempre de Cocina (plato sin impresora, la
// «Cocina» del navegador o una impresora del navegador); sin tarjeta (la banda), si alguna impresora de comanda es del navegador. Si al
// final no hace falta, se cierra.
const vaPorVentana = l => !!l && (!l.imp || !!l.imp.virtual || !porAgente(impresoraAqui(l.imp)));
function ventanaEnBlanco() { try { return typeof window !== 'undefined' && typeof window.open === 'function' ? (window.open('', '_blank') || null) : null; } catch { return null; } }
function ventanaEnElToque(lineas) {
  try {
    if (sesion.empresaInfo && sesion.empresaInfo.es_local) return null;
    return (Array.isArray(lineas) ? lineas.some(vaPorVentana) : usaVentana(impresoras(), false)) ? ventanaEnBlanco() : null;
  } catch { return null; }
}
// La línea de cocina.js imprimir(t): true = ya se resolvió aquí (Cocina no sigue); false = Cocina imprime la tarjeta como hoy (cuenta sin
// copia, reimpresión a propósito, empresa sin pedidos en línea, nada para una impresora de comanda, o sin red y el usuario quiso imprimir de
// todos modos); { resto } = Cocina imprime como hoy solo esos platos (los de la tarjeta que no son de la copia). Si lo que Cocina imprime
// como hoy sale por el navegador, en vez de false va { ventana } y con el resto { resto, ventana }: la ventana abierta en el toque, donde
// Cocina escribe su comanda (abrirla después de esperar al servidor la dejaría bloqueada). `marcar(lineas)` = la marca «impreso» de la
// pantalla de Cocina, solo para los platos de la tarjeta que de verdad salieron (sin ellos no se marca nada). Si la pestaña cambió de empresa
// mientras tanto, true y nada más: ni la marca de Cocina ni la impresión de siempre (la pantalla ya es de la otra empresa).
export async function imprimirCocinaEnLinea(t, marcar) {
  const vent = { w: null }, eid = empresaAqui();
  const marcarLineas = async ls => { if (ls && ls.length && typeof marcar === 'function') { try { await marcar(ls); } catch { /* la marca de Cocina es solo para la pantalla */ } } };
  /* la ventana del toque para Cocina, si alguno de esos platos sale por el navegador (si no, se cierra aquí) */
  const paraCocina = ls => { const w = vent.w; vent.w = null; if (w && !w.closed && ls.some(vaPorVentana)) return w; if (w) { try { w.close(); } catch { /* ya cerrada */ } } return null; };
  try {
    if (!t || t.impresa || !t.cuenta || t.cuenta.canal !== 'online' || !t.cuenta.pedido_id || !estacionPosible()) return false;
    const lineas = Array.isArray(t.lineas) ? t.lineas : [];
    vent.w = ventanaEnElToque(lineas);
    const r = await imprimirPedidoCocina(t.cuenta.pedido_id, { lineas, vent });
    if (r.resultado === OTRA_EMPRESA || empresaAqui() !== eid) return true;
    if (r.resultado === 'sin_copia') { const w = paraCocina(lineas); return w ? { ventana: w } : false; }
    if (r.resultado === 'ya_impresa') {                                            /* (el servidor sabe que ya salió) la pregunta de siempre */
      if (vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } vent.w = null; }
      if (typeof confirm === 'function' && confirm(TEXTO_YA_IMPRESA)) { const w = ventanaEnElToque(lineas); return w ? { ventana: w } : false; }   /* «Sí»: otra ventana enseguida */
      await marcarLineas(r.marcar);
      return true;
    }
    await marcarLineas(r.marcar);
    if (r.resto && r.resto.length) { const w = paraCocina(r.resto); return w ? { resto: r.resto, ventana: w } : { resto: r.resto }; }
    return true;
  } catch { if (empresaAqui() !== eid) return true; const w = vent.w; vent.w = null; return w && !w.closed ? { ventana: w } : false; } finally { if (vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } } }
}
// El botón «Imprimir» de la lista de la banda de Cocina (todo lo que falta de la copia). Sin conexión para leer la copia no hay qué
// imprimir: se avisa y el pedido sigue en la lista.
export async function imprimirListaCocina(pedidoId) {
  const vent = { w: ventanaEnElToque(null) };
  try {
    const r = await imprimirPedidoCocina(pedidoId, { vent });
    if (r.resultado === OTRA_EMPRESA) return r;                                   /* la pestaña cambió de empresa: la lista ya es la de la otra */
    if (r.resultado === 'sin_red') { toast(TEXTO_SIN_RED_LISTA, 'err'); return r; }
    const fuera = r.hecho || r.resultado === 'sin_copia' || r.resultado === 'ya_impresa';
    if (r.resultado === 'sin_copia' || r.resultado === 'ya_impresa') toast('Esa comanda ya no está pendiente.', 'ok');
    estadoEstacion.lista = (estadoEstacion.lista || []).filter(x => Number(x.pedido_id) !== Number(pedidoId) || !fuera);
    return r;
  } finally { if (vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } } }
}
