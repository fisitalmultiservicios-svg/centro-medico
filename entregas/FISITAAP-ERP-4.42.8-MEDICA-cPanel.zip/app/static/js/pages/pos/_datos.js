// Punto de venta: terminales (registro pos_config: varias cajas, cada una con su modo, bodega, cuentas, categorías y mesas),
// sesiones de caja (pos_cajas) y sus ventas (pos_ventas), cuentas en espera y mesas (pos_espera), precios por lista de precios
// del cliente y árbol de categorías (categorías con padre_id = subcategorías).
import { mock, hoy, money, precioCliente, otroImpLinea } from '../../api.js';
import { sesion } from '../../app.js';

export const MEDIOS = [['01', 'Efectivo', '💵'], ['02', 'Tarjeta', '💳'], ['06', 'SINPE Móvil', '📱'], ['04', 'Transferencia', '🏦'], ['03', 'Cheque', '🧾'], ['99', 'Otro', '…']];
export function nombreMedio(c) { if (c === 'hab') return 'Cargo a habitación'; if (c === '01usd') return 'Efectivo en dólares'; if (c === 'fiado') return 'Fiado (crédito de casa)'; if (c === 'regalo') return 'Tarjeta de regalo'; return (MEDIOS.find(m => m[0] === c) || [c, c])[1]; }   // 'hab': consumo cargado a la cuenta del huésped del hotel (2.2)
export const MODOS = [['mostrador', 'Venta rápida / mostrador (tienda, soda, spa)'], ['restaurante', 'Restaurante (plano de mesas y cuentas abiertas)']];

export const TERMINAL_BASE = {
  id: 1, nombre: 'Caja 1', modo: 'mostrador', tipo_documento: '04', bodega_id: null, sucursal_id: null,   // sucursal_id (3.66): a qué sucursal pertenece la caja (vacío = todas) cuentas: { '01': '', '02': '', '06': '', '04': '', '03': '', '99': '', USD: '' },   // USD: caja en dólares para los billetes recibidos (3.20)
  imprimir_auto: true, formato: 'tiquete', ancho_ticket: 80, servicio_pct: 0, servicio_detalle: 'Impuesto de servicio 10 %',
  precio_editable: true, descuento_max_pct: 100, mostrar_imagenes: true, mostrar_existencias: true, pedir_apertura: true, enviar_hacienda: true,
  cierre_ciego: true,        // 4.2: el cajero cuenta sin ver cuánto debería haber; el faltante o sobrante lo ve la administración
  /* 4.41: ciego completo por omisión. cierre_corte_cajero: al cerrar (o entregar el turno) el cajero ve el corte (lo del sistema y el faltante o
     excedente); colilla_completa: su colilla lleva lo del sistema y el faltante; colilla_auto: la colilla sale sola al cerrar. Solo valen con cierre a ciegas. */
  cierre_corte_cajero: false, colilla_completa: false, colilla_auto: true,
  cliente_defecto_id: null, columnas: 4, vendedor: '', fiado: true,   // fiado a clientes con límite de crédito (3.23)
  correo_cierre: '',         // 3.87: correos que reciben el reporte de cierre (Z) en PDF al cerrar la caja (vacío = no se envía)
  categorias: [],            // ids de categorías principales que carga esta caja (vacío = todas): la carnicería solo ve carnes
  mesas: [],                 // modo restaurante: [{id, nombre, x, y, w, h, forma, asientos, sector_id, rot, deco}] en % del plano
  sectores: [],              // salón, terraza, barra… (3.46): [{id, nombre, servicio_pct}] servicio_pct null = el de la caja
  plano_aspecto: '5/3',      // proporción real del salón (3.46): '5/3', '4/3', '1/1', '2/1', '3/4'
  // restaurante avanzado (3.7)
  destinos: {},              // categoría principal (id) → 'cocina' | 'bar' | '' (sin comanda)
  modificadores: [],         // observaciones rápidas por plato (vacío = MODIFICADORES_BASE)
  saloneros: [],             // saloneros de esta caja (vacío = el usuario conectado)
  clave_supervisor: '',      // clave resumida (hashClave), nunca en claro
  clave_descuento: false, clave_anular: false, propina: true, imprimir_comanda: true,
  cobro_solo_cajero: null,   // 4.6: solo cobra quien abrió la caja o recibió el turno (null = sí en restaurante, no en mostrador)
  inicio: 'mesas',           // 4.27: restaurante: al entrar a la caja 'mesas' | 'venta' (venta rápida) | 'preguntar' (en mostrador no se usa)
  numerar_comanda: '',       // 4.29: restaurante: '' (no numerar) | 'dia' (consecutivo que vuelve a 1 cada día) | 'continuo'
  impresora_comprobante_id: '', abrir_gaveta: false, pie_tiquete: '',   // agente de impresión (3.11)
};
// 4.27: con qué pantalla abre una caja de restaurante: Mesas (como siempre), Venta rápida (venta sin mesa) o preguntar cada vez
export const INICIOS = [['mesas', 'Mesas'], ['venta', 'Venta rápida'], ['preguntar', 'Preguntar cada vez']];
// La vista inicial de la caja: 'venta' en mostrador; en restaurante según «inicio» ('mesas', 'venta' o 'elegir' = preguntar).
// Una caja vieja sin el campo, o con un valor desconocido, abre en Mesas como antes.
export function vistaInicial(t) {
  if (!t || t.modo !== 'restaurante') return 'venta';
  if (sinMesas(t)) return 'venta';   /* 4.39: una caja sin mesas nunca abre en un plano vacío */
  return t.inicio === 'venta' ? 'venta' : t.inicio === 'preguntar' ? 'elegir' : 'mesas';
}
// Después de cobrar (o cargar a la habitación): la venta rápida queda lista para la siguiente según «inicio»; la de una mesa,
// una cuenta guardada o un pedido para llevar vuelve a Mesas como antes. En mostrador, siempre la venta.
export function vistaTrasCobro(t, rapida) {
  if (!t || t.modo !== 'restaurante') return 'venta';
  if (sinMesas(t)) return 'venta';   /* 4.39: sin mesas, después de cobrar queda la venta rápida lista */
  return rapida ? vistaInicial(t) : 'mesas';
}
/* 4.39: la caja tiene el plano y no trae ninguna mesa de verdad (no cuentan las decoraciones: paredes, plantas, barra...). Una configuración sin el campo
   «mesas» (muy vieja) no se toca: sigue como antes. */
export function sinMesas(t) { return !!(t && Array.isArray(t.mesas) && !t.mesas.some(m => !esDeco(m))); }
// 4.29: número consecutivo de la comanda. Lo da el servidor (POST /api/pos/comanda/numero) de uno en uno; por omisión no se numera.
export const NUMERAR_COMANDA = [['', 'No numerar'], ['dia', 'Consecutivo del día (vuelve a 1 cada día)'], ['continuo', 'Consecutivo continuo']];
// El modo de numerar de una caja: solo una caja de restaurante con 'dia' o 'continuo'; cualquier otra cosa (caja vieja, valor raro) = no numerar
export function modoNumerarComanda(t) { return t && t.modo === 'restaurante' && (t.numerar_comanda === 'dia' || t.numerar_comanda === 'continuo') ? t.numerar_comanda : ''; }
// El número de la respuesta del servidor: un entero desde 1; cualquier otra cosa = sin número
export function numeroDeComanda(r) { const n = r && typeof r === 'object' ? Number(r.numero) : NaN; return Number.isInteger(n) && n >= 1 ? n : null; }
// Pide el número con un tope (3 s): nunca falla ni se queda esperando; sin respuesta a tiempo, con error o sin modo devuelve null
// (la comanda sale igual, sin número). `pedir` es api() de api.js (se recibe para poder probarla sola).
export function pedirNumeroComanda(modo, pedir, ms = 3000) {
  if (!modo || typeof pedir !== 'function') return Promise.resolve(null);
  return new Promise(listo => {
    let hecho = false; const fin = n => { if (hecho) return; hecho = true; clearTimeout(tope); listo(n); };
    const tope = setTimeout(() => fin(null), ms);
    Promise.resolve().then(() => pedir('/api/pos/comanda/numero', { method: 'POST', body: { modo }, limite: ms })).then(r => fin(numeroDeComanda(r)), () => fin(null));
  });
}
export function terminalCompleta(t) { return { ...TERMINAL_BASE, ...(t || {}), cuentas: { ...TERMINAL_BASE.cuentas, ...((t && t.cuentas) || {}) }, categorias: Array.isArray(t && t.categorias) ? t.categorias : [], mesas: Array.isArray(t && t.mesas) ? t.mesas : [], sectores: Array.isArray(t && t.sectores) ? t.sectores : [], destinos: t && t.destinos && typeof t.destinos === 'object' ? t.destinos : {}, modificadores: Array.isArray(t && t.modificadores) ? t.modificadores : [], saloneros: Array.isArray(t && t.saloneros) ? t.saloneros : [] }; }
// Plano al estilo FISITAAP (3.46): formas de mesa y objetos decorativos (no reciben cuenta), proporciones del salón
export const FORMAS_MESA = [['cuadrada', 'Cuadrada'], ['rectangular', 'Rectangular'], ['redonda', 'Redonda'], ['barra', 'Barra']];
export const FORMAS_DECO = [['pared', 'Pared'], ['planta', 'Planta'], ['puerta', 'Puerta'], ['cocina', 'Cocina / caja'], ['texto', 'Letrero']];
export const ASPECTOS_PLANO = [['5/3', 'Salón ancho (5:3)'], ['4/3', 'Salón (4:3)'], ['1/1', 'Cuadrado'], ['2/1', 'Muy ancho (2:1)'], ['3/4', 'Alargado (3:4)']];
export function esDeco(m) { return !!(m && (m.deco || FORMAS_DECO.some(f => f[0] === m.forma))); }
export function sectorDe(term, m) { return m && m.sector_id && term ? (term.sectores || []).find(s => s.id === m.sector_id) || null : null; }
// porcentaje de servicio que aplica a una mesa: el de su sector si lo fija (0 = sin servicio en ese sector), si no el de la caja
export function servicioDeMesa(term, m) { const s = sectorDe(term, m); return s && s.servicio_pct !== null && s.servicio_pct !== undefined && s.servicio_pct !== '' ? +s.servicio_pct || 0 : +((term || {}).servicio_pct) || 0; }
export const DESTINOS = [['cocina', 'Cocina'], ['bar', 'Bar'], ['', 'Sin comanda']];
export const MODIFICADORES_BASE = ['Sin cebolla', 'Sin tomate', 'Sin picante', 'Extra picante', 'Término medio', 'Bien cocido', 'Sin hielo', 'Sin azúcar', 'Sin sal', 'Para llevar'];
export function modificadores(t) { return t && Array.isArray(t.modificadores) && t.modificadores.length ? t.modificadores : MODIFICADORES_BASE; }
// Clave de supervisor (3.7): se guarda resumida (SHA-256 cuando el navegador lo permite); se compara con hashClave(lo escrito)
export async function hashClave(texto) {
  const s = String(texto || '').trim(); if (!s) return '';
  try { if (crypto.subtle) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('fe-pos:' + s)); return 'sha:' + [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); } } catch {}
  let h = 5381; for (const ch of 'fe-pos:' + s) h = ((h * 33) ^ ch.charCodeAt(0)) >>> 0; return 'djb:' + h.toString(16);
}
// Configuración: {terminales: [...]}; la de versiones anteriores (una sola caja, campos sueltos) se convierte sola
export function config() {
  const c = mock.get('pos_config', null);
  if (c && Array.isArray(c.terminales) && c.terminales.length) return { ...c, terminales: c.terminales.map(terminalCompleta) };
  if (c && typeof c === 'object' && Object.keys(c).length) { const { nombre_caja, ...resto } = c; return { terminales: [terminalCompleta({ ...resto, id: 1, nombre: c.nombre || nombre_caja || 'Caja 1' })] }; }   // config de una sola caja (1.22)
  return { terminales: [terminalCompleta({ id: 1 })] };
}
export function guardarConfig(cfg) { return mock.set('pos_config', { terminales: (cfg.terminales || []).map(terminalCompleta) }); }
// 3.66: con una sucursal activa solo se ven sus cajas (y las que no tienen sucursal)
export function terminales() { const sid = sesion.sucursal_id; return config().terminales.filter(t => !sid || !t.sucursal_id || t.sucursal_id === sid); }
export function terminal(id) { return terminales().find(t => t.id === id) || null; }
// La caja que usa ESTE equipo (se recuerda en el navegador, por empresa); con una sola caja no hay que elegir
const claveTerminal = () => 'pos:terminal:' + (sesion.empresa_id || 0);
export function terminalActual() {
  const l = terminales(); let id = null;
  try { id = +localStorage.getItem(claveTerminal()) || null; } catch {}
  return l.find(t => t.id === id) || (l.length === 1 ? l[0] : null);
}
export function fijarTerminal(id) { try { localStorage.setItem(claveTerminal(), String(id)); } catch {} }

// ---- sesiones de caja ----
export function cajas() { const l = mock.get('pos_cajas', []) || []; const sid = sesion.sucursal_id; if (!sid) return l; const ids = new Set(terminales().map(t => t.id)), nombres = new Set(terminales().map(t => t.nombre)); return l.filter(c => (c.terminal_id ? ids.has(c.terminal_id) : nombres.has(c.caja))); }   // 3.66: sesiones de las cajas de la sucursal activa
export function usuarioActual() { return (sesion.usuario && (sesion.usuario.correo || sesion.usuario.nombre)) || ''; }
export function cajaAbierta(term) { return cajas().find(c => c.estado === 'Abierta' && (!term || (c.terminal_id ? c.terminal_id === term.id : c.caja === term.nombre))) || null; }
export function cajaPorId(id) { return cajas().find(c => c.id === id) || null; }
export function abrirCaja(term, montoInicial, notas) {
  let nueva = null;
  mock.actualizar('pos_cajas', l => { const lista = Array.isArray(l) ? l : []; if (lista.some(c => c.estado === 'Abierta' && (c.terminal_id ? c.terminal_id === term.id : c.caja === term.nombre))) return lista; nueva = { id: mock.nextId(lista, 'pos_cajas'), caja: term.nombre, terminal_id: term.id, usuario: usuarioActual(), turno_usuario: usuarioActual(), abierta_en: new Date().toISOString(), fecha: hoy(), cerrada_en: null, monto_inicial: +montoInicial || 0, ventas: [], retiros: [], conteo: null, diferencia: null, estado: 'Abierta', notas: notas || '' }; return [...lista, nueva]; }, []);
  return nueva || cajaAbierta(term);
}
// Las ventas de cada sesión viven en su propio registro (una fila por venta, con caja_id): dos terminales o dos pestañas que
// venden a la vez no se pisan (las colecciones se funden por id), y cerrar la caja en otra pestaña no borra ventas.
export function posVentas() { return mock.get('pos_ventas', []) || []; }
export function ventasDe(c) { return [...(c.ventas || []), ...posVentas().filter(v => v.caja_id === c.id)]; }
export function registrarVentaEnCaja(cajaId, venta) {
  mock.actualizar('pos_ventas', l => { const lista = Array.isArray(l) ? l : []; return [...lista, { id: mock.nextId(lista, 'pos_ventas'), caja_id: cajaId, ...venta }]; }, []);
}
export function registrarAutorizacion(cajaId, aut) {   // descuentos y anulaciones autorizados con la clave de supervisor (3.7)
  mock.actualizar('pos_cajas', l => (l || []).map(c => (c.id === cajaId ? { ...c, autorizaciones: [...(c.autorizaciones || []), aut].slice(-200) } : c)), []);
}
export function registrarRetiro(cajaId, retiro) {
  mock.actualizar('pos_cajas', l => (l || []).map(c => (c.id === cajaId ? { ...c, retiros: [...(c.retiros || []), retiro] } : c)), []);
}
// 4.2: entradas de efectivo a la gaveta (sencillo, fondo adicional, otro ingreso): suben el efectivo esperado
export function registrarEntrada(cajaId, entrada) {
  mock.actualizar('pos_cajas', l => (l || []).map(c => (c.id === cajaId ? { ...c, entradas: [...(c.entradas || []), entrada] } : c)), []);
}
// Totales de una sesión: por medio de pago, efectivo esperado (inicial + efectivo cobrado + entradas − retiros y pagos a proveedores)
export function resumenCaja(c) {
  const r2 = x => Math.round((+x || 0) * 100) / 100, porMedio = {}, porSalonero = {}, propinasMedio = {}; let total = 0, n = 0, propinas = 0, propinasEfectivo = 0, dolares = 0, vueltoUsd = 0, abonos = 0;
  for (const v of ventasDe(c)) {
    if (v.abono) { abonos = r2(abonos + (+v.total || 0)); for (const m of v.medios || []) porMedio[m.medio] = r2((porMedio[m.medio] || 0) + (+m.monto || 0)); continue; }   // abonos de fiados (3.23): entran a la gaveta sin contar como venta
    if (v.anulada) continue; n++; total += +v.total || 0;
    // pago en dólares (3.20): a la gaveta entran dólares y sale el vuelto en colones; el cobro del comprobante sigue en colones
    const usd = v.usd && +v.usd.monto_usd > 0 ? v.usd : null;
    if (usd) { dolares = r2(dolares + (+usd.monto_usd || 0)); vueltoUsd = r2(vueltoUsd + (+usd.vuelto_crc || 0)); }
    for (const m of v.medios || []) { const k = usd && m.medio === '01' ? '01usd' : m.medio; porMedio[k] = r2((porMedio[k] || 0) + (+m.monto || 0)); }
    if (+v.fiado > 0) porMedio.fiado = r2((porMedio.fiado || 0) + (+v.fiado || 0));   // 3.87: lo fiado va a la cuenta del cliente (ni gaveta ni Bancos); antes no salía y las filas no sumaban el total
    // propinas (3.7): aparte del comprobante; las de efectivo quedan en la gaveta, las demás entraron a Bancos
    const p = +v.propina || 0; propinas += p; if (p && (v.propina_medio || '01') === '01') propinasEfectivo += p; else if (p) propinasMedio[v.propina_medio] = r2((propinasMedio[v.propina_medio] || 0) + p);   // 4.2: la propina con tarjeta va en el cierre del datáfono
    const s = v.salonero || '—', o = porSalonero[s] || (porSalonero[s] = { salonero: s, ventas: 0, total: 0, propinas: 0 }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); o.propinas = r2(o.propinas + p);
  }
  const retiros = (c.retiros || []).reduce((s, r) => s + (+r.monto || 0), 0);
  const entradas = r2((c.entradas || []).reduce((s, e) => s + (+e.monto || 0), 0));                                   // 4.2
  const pagosProveedor = r2((c.retiros || []).filter(x => x.tipo === 'proveedor').reduce((s, x) => s + (+x.monto || 0), 0));
  const efectivo = porMedio['01'] || 0;
  // 3.87: lo que entró a Bancos al cobrar (tarjeta, SINPE, transferencia…, también de los abonos); sin efectivo, fiado, cargo a habitación ni tarjeta de regalo
  const bancos = r2(Object.entries(porMedio).filter(([k]) => !['01', '01usd', 'fiado', 'hab', 'regalo'].includes(k)).reduce((s, [, m]) => s + m, 0));
  return { porMedio, bancos, total: r2(total), ventas: n, retiros, propinas: r2(propinas), propinas_efectivo: r2(propinasEfectivo), porSalonero: Object.values(porSalonero).sort((a, b) => b.total - a.total), abonos: r2(abonos),
    dolares, vuelto_usd: vueltoUsd, entradas, pagos_proveedor: pagosProveedor, salidas: r2(retiros - pagosProveedor), propinasMedio,
    efectivo_esperado: r2((+c.monto_inicial || 0) + efectivo + propinasEfectivo + entradas - retiros - vueltoUsd),
    // 4.2: lo que el sistema espera en cada medio para el corte (tarjeta, SINPE y transferencias con sus propinas)
    esperadoMedio: { '01': r2((+c.monto_inicial || 0) + efectivo + propinasEfectivo + entradas - retiros - vueltoUsd), '02': r2((porMedio['02'] || 0) + (propinasMedio['02'] || 0)),
      '06': r2((porMedio['06'] || 0) + (propinasMedio['06'] || 0)), '04': r2((porMedio['04'] || 0) + (propinasMedio['04'] || 0)) } };
}
// 4.2: corte de caja: lo que el sistema registró contra lo que el cajero declaró al cerrar, por medio de pago
const R2 = x => Math.round((+x || 0) * 100) / 100;
export const MEDIOS_CORTE = [['01', 'Efectivo en la gaveta'], ['02', 'Tarjeta (cierre del datáfono)'], ['06', 'SINPE Móvil'], ['04', 'Transferencias']];
export function corteCaja(c, r) {
  r = r || resumenCaja(c);
  const dec = c.declarado || (c.conteo !== null && c.conteo !== undefined ? { '01': c.conteo } : {});
  const filas = MEDIOS_CORTE.map(([k, nombre]) => {
    const sistema = R2(r.esperadoMedio[k] || 0), d = dec[k], declarado = d === null || d === undefined || d === '' ? null : R2(d);
    return { medio: k, nombre, sistema, declarado, diferencia: declarado === null ? null : R2(declarado - sistema) };
  }).filter(f => f.medio === '01' || f.sistema || f.declarado !== null);
  if (r.dolares || (c.conteo_usd !== null && c.conteo_usd !== undefined)) {
    const u = c.conteo_usd === null || c.conteo_usd === undefined ? null : R2(c.conteo_usd);
    filas.push({ medio: 'USD', nombre: 'Dólares en la gaveta', usd: true, sistema: R2(r.dolares), declarado: u, diferencia: u === null ? null : R2(u - r.dolares) });
  }
  const crc = filas.filter(f => !f.usd && f.diferencia !== null);
  return { filas, faltante: R2(crc.filter(f => f.diferencia < 0).reduce((s, f) => s + f.diferencia, 0)), sobrante: R2(crc.filter(f => f.diferencia > 0).reduce((s, f) => s + f.diferencia, 0)) };
}
// 4.2: quién ve lo esperado y el resultado del corte (faltante o sobrante): quien ve todo o configura (Administrador y Avanzado en el punto de venta)
export function veResultadoCaja() { return sesion.puede('ver_todo') || sesion.puede('configurar'); }
// La caja (terminal) de una sesión: por su id o, solo en sesiones viejas sin id, por el nombre (4.41: una caja borrada no toma la de otra con el mismo nombre)
export function terminalDeCaja(c) { if (!c) return null; const l = config().terminales; return c.terminal_id ? (l.find(x => x.id === c.terminal_id) || null) : (l.find(x => x.nombre === c.caja) || null); }
// 4.41: si la caja ya no existe, lo que quedó guardado en la sesión al cerrarla (una abierta o vieja sin el dato: a ciegas)
export function cierreCiego(c) { const t = terminalDeCaja(c); return t ? t.cierre_ciego !== false : !(c && c.cierre_ciego === false); }
/* 4.41: la caja deja ver el corte a cualquiera que la use (sin cierre a ciegas, o con «el cajero ve el corte»), sin mirar quién lo ve.
   Es la regla de lo que se comparte entre usuarios, como el paquete del cierre del día del hotel. */
export function corteDeLaCaja(c) { const t = terminalDeCaja(c); return !cierreCiego(c) || !!(t && t.cierre_corte_cajero === true); }
/* 4.41: la colilla propia de la caja (la que sale sola al cerrar y la que puede salir en su impresora) lleva lo del sistema y el faltante: sin
   cierre a ciegas, o con «el cajero ve el corte» y «la colilla también lleva lo del sistema». Tampoco mira quién imprime. */
export function colillaDeLaCaja(c) { const t = terminalDeCaja(c); return !cierreCiego(c) || !!(t && t.cierre_corte_cajero === true && t.colilla_completa === true); }
/* 4.41: qué ve este usuario del cierre según las opciones de la caja (ciego completo por omisión). ciego: cuenta sin ver lo esperado; corte: al
   cerrar o entregar el turno ve lo del sistema y el faltante o excedente; colilla: la colilla lleva lo del sistema y el faltante (solo si ve el
   corte; si no, solo lo declarado); auto: la colilla sale sola al cerrar; todo: sin cierre a ciegas o quien ve resultados (quien ve todo o
   configura), que ve siempre el corte completo. */
export function opcionesCierre(c) {
  const t = terminalDeCaja(c), ciego = cierreCiego(c), todo = !ciego || veResultadoCaja(), corte = todo || corteDeLaCaja(c);
  return { ciego, todo, corte, colilla: todo || colillaDeLaCaja(c), auto: !t || t.colilla_auto !== false };
}

// ---- ventas en espera (cuentas abiertas) y mesas ----
export function enEspera() { return mock.get('pos_espera', []) || []; }
// Una mesa puede tener varias cuentas (barra, grupos que pagan aparte) y una cuenta puede abarcar varias mesas unidas (3.46):
// la cuenta guarda mesa_id (principal) y mesas_ids (todas las que ocupa). cuentaDeMesa devuelve la primera; cuentasDeMesa, todas.
export function ocupaMesa(v, mesaId) { return v.mesa_id === mesaId || (Array.isArray(v.mesas_ids) && v.mesas_ids.includes(mesaId)); }
export function cuentasDeMesa(mesaId, termId) { return enEspera().filter(v => ocupaMesa(v, mesaId) && (v.terminal_id || termId) === termId).sort((a, b) => (+a.parte || 1) - (+b.parte || 1) || String(a.creado).localeCompare(String(b.creado))); }
export function cuentaDeMesa(mesaId, termId) { return cuentasDeMesa(mesaId, termId)[0] || null; }
export const MESA_BASE = { id: 1, nombre: 'Mesa 1', x: 5, y: 5, w: 12, h: 18, forma: 'cuadrada', asientos: 4, sector_id: null, rot: 0 };
// Estado de una mesa para el plano (3.46): libre, ocupada (sin comanda), comanda (enviada a cocina), precuenta (pedida), y si hay platos listos
export function estadoDeMesa(cuentas, ahora) {
  const t = ahora || Date.now();
  if (!cuentas.length) return { estado: 'libre', cuenta: null, cuentas: [], total: 0, min: 0, com: null, pend: false, listo: false };
  const c = cuentas[0], lineas = cuentas.flatMap(v => v.lineas || []);
  const ult = Math.max(0, ...lineas.map(l => (l.enviado ? new Date(l.enviado).getTime() : 0)));
  const creado = Math.min(...cuentas.map(v => new Date(v.creado).getTime()));
  const env = lineas.filter(l => l.enviado);
  const estado = cuentas.some(v => v.precuenta_pedida) ? 'precuenta' : env.length ? 'comanda' : 'ocupada';
  return { estado, cuenta: c, cuentas, total: Math.round(cuentas.reduce((s, v) => s + (+v.total || 0), 0) * 100) / 100, min: Math.max(0, Math.round((t - creado) / 60000)), com: ult ? Math.max(0, Math.round((t - ult) / 60000)) : null, pend: lineas.some(l => !l.enviado), listo: !!(env.length && env.every(l => l.listo)), cobros: cuentas.reduce((n, v) => n + ((v.cobros || []).length), 0) };
}
export function mesasEnCuadricula(n, desde = 1) {
  // columnas y tamaño según la cantidad: hasta 60 mesas sin que se monten unas sobre otras
  const out = []; const cols = Math.max(3, Math.min(10, Math.ceil(Math.sqrt(n * 5 / 3)))), filas = Math.max(1, Math.ceil(n / cols));
  const w = Math.min(12, Math.floor(84 / cols)), gx = (100 - cols * w) / (cols + 1), h = Math.min(18, Math.floor(88 / filas)), gy = Math.max(2, (100 - filas * h) / (filas + 1));
  for (let i = 0; i < n; i++) { const c = i % cols, f = Math.floor(i / cols); out.push({ ...MESA_BASE, id: desde + i, nombre: 'Mesa ' + (desde + i), w, h, x: Math.round(gx + c * (w + gx)), y: Math.round(gy + f * (h + gy)) }); }
  return out;
}

// ---- precios: lista de precios del cliente (contactos_extra.lista_precios_id + items_extra[pid].listas) ----
export function precioPara(p, clienteId) { return precioCliente(p, clienteId, 'CRC'); }   // (en api.js desde 1.26: también lo usan las facturas)
export function precioConIva(p, precio) {      // precio final de una unidad: con IVA y, si el ítem lo lleva, Selectivo o impuesto específico (3.41)
  const pct = +p.tarifa || 0, base = precio ?? (+p.precio || 0), oi = otroImpLinea(p.otro_impuesto, 1, base);
  return Math.round((base + oi.monto + (base + oi.base) * pct / 100) * 100) / 100;
}

// ---- categorías: raíces y subcategorías ----
export function categorias() { return (mock.get('categorias', []) || []).filter(c => c && c.nombre); }
export function raices(lista) { return (lista || categorias()).filter(c => !c.padre_id); }
export function hijas(lista, padreId) { return (lista || categorias()).filter(c => c.padre_id === padreId); }
// nombres de una categoría y de toda su descendencia (los productos guardan solo el nombre de su categoría)
export function nombresBajo(lista, catId) { const out = new Set(); const rec = id => { const c = lista.find(x => x.id === id); if (!c) return; out.add(c.nombre); for (const h of lista.filter(x => x.padre_id === id)) rec(h.id); }; rec(catId); return out; }

export function fmtMoney(v) { return money(v || 0); }

// ---- impuesto de servicio (10 %) y propinas por período (3.9): por día y por salonero, sobre las ventas de caja ----
export function ventasPeriodo(desde, hasta) { return posVentas().filter(v => !v.anulada && String(v.hora || '').slice(0, 10) >= desde && String(v.hora || '').slice(0, 10) <= hasta); }
function acumular(m, k, v, extra) { const r2 = x => Math.round((+x || 0) * 100) / 100; const o = m[k] || (m[k] = { ...extra, ventas: 0, total: 0, servicio: 0, propinas: 0, comandas: 0 }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); o.servicio = r2(o.servicio + (+v.servicio || 0)); o.propinas = r2(o.propinas + (+v.propina || 0)); o.comandas += +v.rondas || 0; o.repartir = r2(o.servicio + o.propinas); }
export function servicioPorDia(desde, hasta) { const m = {}; for (const v of ventasPeriodo(desde, hasta)) acumular(m, String(v.hora).slice(0, 10), v, { fecha: String(v.hora).slice(0, 10) }); return Object.values(m).sort((a, b) => a.fecha.localeCompare(b.fecha)); }
export function servicioPorSalonero(desde, hasta) { const m = {}; for (const v of ventasPeriodo(desde, hasta)) acumular(m, v.salonero || '—', v, { salonero: v.salonero || '—' }); return Object.values(m).sort((a, b) => b.repartir - a.repartir || b.total - a.total); }

// ---- impresoras (3.10): registro pos_impresoras [{id, nombre, uso comanda|comprobante|etiquetas, conexion navegador|usb|red, direccion, ancho, activa}] ----
// 4.24: la de uso 'etiquetas' lleva además {modelo, lenguaje tspl|zpl|pdf, dpi, etq_ancho_mm, etq_alto_mm, separacion_mm, densidad} (campos opcionales; ver inventario/_etiquetas.js)
// Hoy todas imprimen por el navegador; el agente local (instalable) tomará las USB y de red con estos mismos datos.
export const USOS_IMPRESORA = [['comanda', 'Comanda (cocina, bar, postres…)'], ['comprobante', 'Tiquetes y facturas'], ['etiquetas', 'Etiquetas de productos']];
export const CONEXIONES_IMPRESORA = [['navegador', 'Impresora del navegador'], ['usb', 'USB en la computadora (agente local)'], ['red', 'De red (agente local)']];
export function impresoras() { return (mock.get('pos_impresoras', []) || []).filter(i => i && i.nombre); }
export function impresorasComanda() { return impresoras().filter(i => i.activa !== false && (i.uso || 'comanda') === 'comanda'); }
// Impresora de comanda de un producto: la del ítem (Inventario › ítem › Opciones avanzadas); si no, la de su categoría o de una
// categoría superior (Configuración de la caja); si no, la primera de comanda. null = sin comanda. Los valores viejos 'cocina'/'bar'
// se resuelven por nombre (o como impresora virtual del navegador).
export function impresoraDe(p, cats, terminal, extras) {
  const lista = impresorasComanda(), porId = Object.fromEntries(lista.map(i => [String(i.id), i]));
  const virtual = n => ({ id: 'v:' + n, nombre: n, virtual: true });
  const resolver = v => { if (v === 'none') return null; if (v === '' || v === undefined || v === null) return undefined; if (porId[String(v)]) return porId[String(v)]; if (typeof v === 'string') { const i = lista.find(x => x.nombre.toLowerCase() === v.toLowerCase()); return i || virtual(v === 'cocina' ? 'Cocina' : v === 'bar' ? 'Bar' : v); } return undefined; };
  const ex = p && extras ? (extras[p.id] || {}) : {};
  let r = resolver(ex.impresora_id); if (r !== undefined) return r;
  const d = (terminal && terminal.destinos) || {}, lista2 = cats || [];
  let c = p ? lista2.find(x => x.nombre === (p.categoria || '')) : null, n = 0;
  while (c && n++ < 10) { r = resolver(d[c.id]); if (r !== undefined) return r; c = c.padre_id ? lista2.find(x => x.id === c.padre_id) : null; }
  return lista[0] || virtual('Cocina');
}
// Categorías en orden de árbol con su nivel (para la configuración de impresoras por categoría)
export function categoriasArbol(lista) {
  const l = lista || categorias(), out = [];
  const bajar = (padreId, nivel) => { for (const c of l.filter(x => (x.padre_id || null) === padreId).sort((a, b) => String(a.nombre).localeCompare(b.nombre))) { out.push({ ...c, nivel }); bajar(c.id, nivel + 1); } };
  bajar(null, 0); return out;
}

// ---- promociones y combos (3.23): registro pos_promos [{id, nombre, tipo descuento|2x1|combo, activa, dias [0-6], desde, hasta, pct, productos [ids], combo {precio, items [{producto_id, cantidad}]}}] ----
export function promos() { return (mock.get('pos_promos', []) || []).filter(p => p && p.activa !== false); }
export function promoVigente(p, ahora) {
  const d = ahora || new Date(), dias = Array.isArray(p.dias) ? p.dias.map(Number) : [];
  if (dias.length && !dias.includes(d.getDay())) return false;
  const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  if (p.desde && hm < p.desde) return false;
  if (p.hasta && hm > p.hasta) return false;
  return true;
}
// ---- turnos dentro de la misma caja (3.23): la sesión sigue abierta; cada cambio de cajero deja su arqueo parcial ----
export function registrarTurno(cajaId, turno) {
  mock.actualizar('pos_cajas', l => (l || []).map(c => (c.id === cajaId ? { ...c, turnos: [...(c.turnos || []), turno], turno_desde: turno.fin, turno_usuario: '' } : c)), []);
}
// 4.6 (FISITAAP): el cobro es de la caja. Con la opción encendida solo cobra quien abrió la sesión o quien tomó el último turno;
// los saloneros toman pedidos y envían comandas desde el celular. Turno entregado ('' tras registrarTurno) = el siguiente que cobre lo toma.
export function cobroSoloCajero(t) { return !!t && (t.cobro_solo_cajero === true || ((t.cobro_solo_cajero === null || t.cobro_solo_cajero === undefined) && t.modo === 'restaurante')); }
export function cajeroDeCaja(c) { return c && c.turno_usuario ? c.turno_usuario : ''; }   // sesiones abiertas antes de la 4.6 (o de la demo): sin dueño hasta que alguien cobre
export function tomarTurno(cajaId) { mock.actualizar('pos_cajas', l => (l || []).map(c => (c.id === cajaId ? { ...c, turno_usuario: usuarioActual(), turno_desde: c.turno_desde || c.abierta_en } : c)), []); }
export function porCajero(c) {
  const r2 = x => Math.round((+x || 0) * 100) / 100, m = {};
  for (const v of ventasDe(c)) { if (v.anulada || v.abono) continue; const k = v.usuario || '—'; const o = m[k] || (m[k] = { usuario: k, ventas: 0, total: 0, propinas: 0 }); o.ventas++; o.total = r2(o.total + (+v.total || 0)); o.propinas = r2(o.propinas + (+v.propina || 0)); }
  return Object.values(m).sort((a, b) => b.total - a.total);
}
// ---- pedidos para llevar y a domicilio (3.23): cuentas en espera con tipo, teléfono, hora y estado ----
export const ESTADOS_PEDIDO = [['recibido', 'Recibido'], ['en_cocina', 'En cocina'], ['listo', 'Listo'], ['entregado', 'Entregado']];
export function nombreEstadoPedido(e) { return (ESTADOS_PEDIDO.find(x => x[0] === e) || [e, e])[1]; }
export function siguienteEstadoPedido(e) { const i = ESTADOS_PEDIDO.findIndex(x => x[0] === e); return i >= 0 && i < ESTADOS_PEDIDO.length - 1 ? ESTADOS_PEDIDO[i + 1][0] : null; }
