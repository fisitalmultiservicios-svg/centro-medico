// Punto de venta › Configuración: varias cajas (terminales) por negocio. Cada una con su modo (mostrador o restaurante), comprobante
// por defecto, bodega, cuenta de Bancos por medio de pago, impuesto de servicio, impresión, apariencia, las categorías que carga
// (la caja de la carnicería solo ve carnes) y, en restaurantes, el plano de mesas que se acomoda arrastrando.
import { api, toast, money, mock, abrirArchivo } from '../../api.js';
import { store, sesion } from '../../app.js';
import { cobroSoloCajero, config, guardarConfig, MEDIOS, MODOS, terminalCompleta, raices, categorias, mesasEnCuadricula, MODIFICADORES_BASE, hashClave, impresoras, USOS_IMPRESORA, CONEXIONES_IMPRESORA, categoriasArbol, FORMAS_MESA, FORMAS_DECO, ASPECTOS_PLANO, esDeco, INICIOS } from './_datos.js';

// tamaño inicial (% del plano) de cada forma (3.46)
const TAMANOS = { cuadrada: [12, 18], rectangular: [18, 14], redonda: [12, 18], barra: [26, 10], pared: [30, 3], planta: [5, 8], puerta: [8, 3], cocina: [20, 12], texto: [20, 6] };
import { cuentasParaMovimientos } from '../bancos/cuentas.js';
import { NUMERAR_COMANDA } from './_datos.js';   // 4.29: número consecutivo de la comanda
import { agenteEstado, porAgente, probarAgente, abrirGaveta, URL_AGENTE, sabeEtiquetas, imprimirEtiquetas } from './_agente.js';   // agente de impresión local (3.11)
import { cargarEquipo, ponerEquipo, equipoVacio, impresoraAqui, esPropia, IMPRESORAS_DE_LA_WEB, avisoImpresion } from './_agente.js';   // 4.25 (tanda 8): la impresión de esta computadora (solo en el programa)
const CONEXIONES_AQUI = [['', 'Igual que en la configuración'], ['usb', 'Impresora de Windows (USB)'], ['red', 'Por red (dirección IP)']];
// 9c (J3): en lo que solo se ve en el programa, un solo nombre para cada conexión (sin «agente local» ni «instalable»)
const CONEXIONES_PROPIA = [['usb', 'Impresora de Windows (USB)'], ['red', 'Por red (dirección IP)']];
// 9c (J2): el servicio solo manda etiquetas al puerto 9100: la de etiquetas por red se escribe sin «:puerto» (las de tiquetes sí lo aceptan)
export const ETQ_SIN_PUERTO = 'La impresora de etiquetas por red se escribe solo con su dirección IP (sin «:puerto»).';
export function etiquetaConPuerto(uso, conexion, direccion) { return uso === 'etiquetas' && conexion === 'red' && String(direccion || '').includes(':'); }
const GIRAR_AQUI = [['', 'Como en la configuración'], ['si', 'Sí'], ['no', 'No']];
// 4.29 (K-8): en el programa conectado a la página web, las cajas (pos_config), las impresoras de la empresa (pos_impresoras), las
// promociones (pos_promos) y los modificadores (pos_modificadores) bajan de la web en cada sincronización (sinc.CLAVES_CATALOGO) y pisan
// lo guardado aquí; solo la impresión de esta computadora (equipo_impresion, la tarjeta «En esta computadora») se queda. Solo se avisa:
// el guardado sigue igual (una computadora sin conectar guarda como siempre).
export const AVISO_CONECTADA_WEB = 'Esta computadora está conectada a la página web: la configuración de las cajas, impresoras de la empresa, promociones y modificadores se cambia en la página web y baja sola al sincronizar. Lo que cambie aquí se pierde en la siguiente sincronización. Aquí solo queda guardado lo de la tarjeta «En esta computadora».';
import { MODELOS as MODELOS_ETQ, LENGUAJES as LENGUAJES_ETQ, MEDIDAS as MEDIDAS_ETQ, modeloDe, medidaValida, medidaImpresora, directa, trabajoEtiquetas, codigoBarrasPropio } from '../inventario/_etiquetas.js';   // 4.24: impresora de etiquetas
// 4.30: lo que se guarda en pos_modificadores. Cada grupo y cada opción parten de lo guardado con el mismo id (o de lo que hay en la
// pantalla, si es nuevo) y solo cambian lo que esta pantalla edita: nombre, mínimo, máximo, activo, opciones y precio. Todo lo demás
// (productos, categorias, tipo, fis y cualquier dato futuro) queda como estaba. Un grupo quitado en la pantalla no va: se borra.
// Un grupo que no está guardado es nuevo: nunca lleva productos, categorias, tipo ni fis (ni de otro grupo ni los que traiga la copia).
// H3: `alDia` es lo que tiene el servidor en este momento (guardarMods lo lee justo antes). Un grupo que esta pantalla cambió lleva las
// asignaciones de ahí, no las de la copia de la pestaña (FISITAAP pudo cambiarlas con la pestaña abierta); si ya no está en el servidor
// va sin ellas. Un grupo que aquí no cambió queda igual a la copia y no se manda.
export function modsParaGuardar(mods, guardados, alDia) {
  const ASIG = ['productos', 'categorias', 'tipo', 'fis'], sinAsignar = g => { const x = { ...g }; for (const k of ASIG) delete x[k]; return x; };
  const mapa = l => new Map((l || []).filter(g => g && g.id !== undefined && g.id !== null).map(g => [String(g.id), g]));
  const porId = mapa(guardados), frescos = alDia ? mapa(alDia) : null;
  return (mods || []).map(g => {
    const previo = porId.get(String(g.id)), base = previo || sinAsignar(g), ops = new Map((base.opciones || []).filter(o => o && o.id !== undefined && o.id !== null).map(o => [String(o.id), o]));
    const out = { ...base, id: g.id, nombre: String(g.nombre || '').trim(), minimo: Math.max(0, +g.minimo || 0), maximo: Math.max(0, +g.maximo || 0), activo: g.activo !== false,
      opciones: (g.opciones || []).map(o => ({ ...(ops.get(String(o.id)) || o), id: o.id, nombre: String(o.nombre || '').trim(), precio: Math.max(0, +o.precio || 0) })) };
    if (!previo || !frescos || JSON.stringify(out) === JSON.stringify(previo)) return out;
    const ahora = frescos.get(String(g.id)), r = sinAsignar(out);
    if (ahora) for (const k of ASIG) if (k in ahora) r[k] = ahora[k];
    return r;
  });
}

export default {
  props: ['params'],
  data() {
    const cfg = config();
    for (const t of cfg.terminales) { if (t.cobro_solo_cajero === null || t.cobro_solo_cajero === undefined) t.cobro_solo_cajero = cobroSoloCajero(t); t.modificadores_txt = (t.modificadores || []).join('\n'); t.saloneros_txt = (t.saloneros || []).join('\n'); t.clave_nueva = ''; t.quitar_clave = false; }   // campos de edición (3.7): no se guardan
    return { promos: JSON.parse(JSON.stringify(mock.get('pos_promos', []) || [])), guardandoPromos: false, mods: JSON.parse(JSON.stringify(mock.get('pos_modificadores', []) || [])), guardandoMods: false, modsQuitados: [], recMods: null, recEnWeb: '', recViendo: false, recuperandoMods: false, DIAS: [[1, 'L'], [2, 'K'], [3, 'M'], [4, 'J'], [5, 'V'], [6, 'S'], [0, 'D']], cfg, sel: cfg.terminales[0].id, bodegas: [], cuentas: [], guardando: false, MEDIOS, MODOS, INICIOS, MODIFICADORES_BASE, USOS_IMPRESORA, CONEXIONES_IMPRESORA, FORMAS_MESA, FORMAS_DECO, ASPECTOS_PLANO, mesaSel: null, arrastre: null, nMesas: 6, zoomEd: 1, sectorNuevo: '', imps: impresoras(), impForm: null, agente: null, buscandoAgente: false, URL_AGENTE, MODELOS_ETQ, LENGUAJES_ETQ, MEDIDAS_ETQ,
      estComandas: null,   /* 4.31: interruptor de la estación de comandas (solo en la web y con pedidos en línea): { encendida, textos } */
      eq: null, eqWeb: false, conectadaWeb: false, AVISO_CONECTADA_WEB, guardandoEq: false, CONEXIONES_AQUI, GIRAR_AQUI, IMPRESORAS_DE_LA_WEB, NUMERAR_COMANDA };   // 4.25: impresión de esta computadora
  },
  computed: {
    clientes() { return (store.clientes || []).filter(x => x.activo !== false && x.tipo !== 'Proveedor'); },
    puedeConfigurar() { return sesion.puede('configurar'); },
    // 3.87: cajas que incluye el plan (la misma regla que aplica el servidor al guardar: sin plan, en prueba o demo no hay límite)
    limiteCajas() { const e = sesion.empresaInfo || {}, p = e.plan || {}; return (!p.codigo || p.sin_plan || p.prueba || e.es_demo) ? 0 : (+p.cajas || 0); },
    topeCajas() { return this.limiteCajas > 0 && this.cfg.terminales.length >= this.limiteCajas; },
    textoLimite() { return 'Su plan incluye ' + this.limiteCajas + (this.limiteCajas === 1 ? ' caja' : ' cajas'); },
    sucursalesEmpresa() { return sesion.sucursales || []; },   // 3.66
    itemsVenta() { return (store.productos || []).filter(p => p.activo !== false && p.es_venta !== false).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')); },   // promociones y combos (3.23)
    t() { return this.cfg.terminales.find(x => x.id === this.sel) || this.cfg.terminales[0]; },
    raices() { return raices(categorias()); },
    arbol() { return categoriasArbol(categorias()); },
    impsComanda() { return this.imps.filter(i => i.activa !== false && (i.uso || 'comanda') === 'comanda'); },
    impsComprobante() { return this.imps.filter(i => i.activa !== false && i.uso === 'comprobante'); },
    // 4.24: la impresora de etiquetas va por USB o por red (o con su controlador de Windows, en PDF): no hay «del navegador» que elegir
    conexionesForm() { if (this.impForm && this.impForm.solo_aqui) return CONEXIONES_PROPIA; return this.impForm && (this.impForm.uso === 'etiquetas' || this.impForm.solo_aqui) ? CONEXIONES_IMPRESORA.filter(u => u[0] !== 'navegador') : CONEXIONES_IMPRESORA; },   // 4.25: la de esta computadora tampoco
    usosForm() { return this.impForm && this.impForm.solo_aqui ? USOS_IMPRESORA.filter(u => u[0] !== 'comanda') : USOS_IMPRESORA; },   // 4.25: solo de esta computadora: tiquetes o etiquetas
    // ---- 4.25 (tanda 8): impresión de esta computadora (solo en el programa de escritorio; en la web no se muestra ni se lee) ----
    esPrograma() { return !!(sesion.empresaInfo && sesion.empresaInfo.es_local); },
    avisoWeb() { return this.esPrograma && (this.conectadaWeb || this.eqWeb); },   /* 4.29 (K-8): solo en el programa conectado a la web */
    cajasEnWeb() { return this.esPrograma && !!(sesion.empresaInfo && (sesion.empresaInfo.datos_v2 || sesion.empresaInfo.sinc_pantallas)); },   /* 4.32: en el programa con el canal nuevo, las cajas se agregan y se quitan en la página web */
    impsActivas() { return this.imps.filter(i => i.activa !== false); },
    propiasActivas() { return this.eq ? this.eq.propias.filter(i => i.activa !== false) : []; },
    opcionesTiquetes() { return [...this.impsComprobante, ...this.propiasActivas.filter(i => i.uso === 'comprobante')]; },
    opcionesEtiquetas() { return [...this.imps.filter(i => i.activa !== false && i.uso === 'etiquetas'), ...this.propiasActivas.filter(i => i.uso === 'etiquetas')]; },
    etqPdf() { return !!this.impForm && this.impForm.uso === 'etiquetas' && this.impForm.lenguaje === 'pdf'; },
    mesa() { return this.t && this.mesaSel ? this.t.mesas.find(m => m.id === this.mesaSel) : null; },
    mesaEsDeco() { return esDeco(this.mesa); },
    soloMesas() { return (this.t ? this.t.mesas : []).filter(m => !esDeco(m)); },
    estiloPlano() { return { aspectRatio: (this.t && this.t.plano_aspecto) || '5/3', width: Math.round(this.zoomEd * 100) + '%' }; },
    // 4.31 (D-12): el agente que responde en esta computadora no es el del programa 4.31 (no trae los ajustes de «En esta computadora»)
    programaAnteriorEstacion() { const a = this.agente; return !!(a && a.ok && a.via === 'agente' && !(a.info && +a.info.equipo === 1)); },
  },
  methods: {
    money,
    // ---- 4.31: estación de comandas (D-14): el interruptor de esta computadora, guardado en este navegador ----
    async cargarEstacionComandas() {
      try { const m = await import('./_estacion.js'); this._est = m; this.estComandas = m.estacionPosible() ? { encendida: m.estacionEncendida(), textos: m.TEXTOS_INTERRUPTOR } : null; }
      catch { this.estComandas = null; }
    },
    cambiarEstacionComandas(v) {
      const m = this._est; if (!m || !this.estComandas) return;
      const ahora = m.encenderEstacion(!!v); this.estComandas = { ...this.estComandas, encendida: ahora };
      toast(ahora ? this.estComandas.textos.encendida : this.estComandas.textos.apagada, 'ok');
    },
    nueva() { if (this.topeCajas) return toast(this.textoLimite + ': para agregar otra, amplíe el plan en Configuración › Suscripción y planes.', 'err'); const id = Math.max(0, ...this.cfg.terminales.map(x => +x.id || 0), ...(mock.get('pos_cajas', []) || []).map(c => +(c && c.terminal_id) || 0)) + 1; const base = terminalCompleta({ ...this.t, id, nombre: 'Caja ' + id, mesas: [], categorias: [] }); this.cfg.terminales.push(base); this.sel = id; toast('Caja «' + base.nombre + '» agregada: ajústela y guarde', 'ok'); },   // 4.41: sin reusar el id de una caja borrada (sus cierres tomarían las opciones de la nueva)
    eliminar() { if (this.cfg.terminales.length <= 1) return toast('Debe quedar al menos una caja', 'err'); if (!confirm('¿Eliminar la caja «' + this.t.nombre + '»? Sus cierres anteriores se conservan.')) return; this.cfg.terminales = this.cfg.terminales.filter(x => x.id !== this.t.id); this.sel = this.cfg.terminales[0].id; },
    catMarcada(id) { return (this.t.categorias || []).includes(id); },
    // ---- impresoras (3.10) ----
    nuevaImp(uso) { this.impForm = { id: null, nombre: '', uso: uso || 'comanda', conexion: 'navegador', direccion: '', ancho: 80, activa: true }; this.alCambiarUso(); },
    editarImp(i) { this.impForm = { ...i }; this.alCambiarUso(); },
    // ---- impresora de etiquetas (4.24): modelo, lenguaje, medida de la etiqueta, separación y densidad ----
    alCambiarUso() {
      const f = this.impForm; if (!f || f.uso !== 'etiquetas') return;
      if (!f.modelo) { f.modelo = MODELOS_ETQ[0].id; f.lenguaje = MODELOS_ETQ[0].lenguaje; f.dpi = MODELOS_ETQ[0].dpi; f.densidad = MODELOS_ETQ[0].densidad; f.separacion_mm = 2; f.etq_ancho_mm = 50; f.etq_alto_mm = 30; if (f.conexion === 'navegador') f.conexion = 'usb'; }
      const [a, h] = medidaImpresora(f); f.etq_ancho_mm = a; f.etq_alto_mm = h;
      f.medida_sel = MEDIDAS_ETQ.some(m => m[0] === a && m[1] === h) ? a + 'x' + h : 'personalizada';   // solo del formulario: no se guarda
    },
    alCambiarModelo() { const f = this.impForm, m = modeloDe(f.modelo); if (!m) return; f.lenguaje = m.lenguaje; f.dpi = m.dpi; f.densidad = m.densidad; if (m.lenguaje !== 'pdf' && f.conexion !== 'usb' && f.conexion !== 'red') f.conexion = 'usb'; },
    alCambiarMedida() { const f = this.impForm; if (f.medida_sel !== 'personalizada') { const [a, h] = f.medida_sel.split('x'); f.etq_ancho_mm = +a; f.etq_alto_mm = +h; } },
    medidaEtq(i) { const [a, h] = medidaImpresora(i); return a + ' × ' + h + ' mm'; },
    // 9c (J3): la conexión con los nombres del programa (tarjeta «En esta computadora» y lista de las de esta computadora)
    conexionAqui(i) { if (i.uso === 'etiquetas' && i.lenguaje === 'pdf') return 'Controlador de Windows (PDF)'; return i.conexion === 'usb' ? 'Impresora de Windows (USB)' : i.conexion === 'red' ? 'Por red (dirección IP)' : 'Impresora del navegador'; },
    conexionTexto(i) { return i.uso === 'etiquetas' && i.lenguaje === 'pdf' ? 'Controlador de Windows (PDF)' : (CONEXIONES_IMPRESORA.find(u => u[0] === (i.conexion || 'navegador')) || [])[1]; },
    // Etiqueta de prueba: directa por el servicio de impresión local (TSPL o ZPL) o, si no se puede, en PDF del tamaño de la etiqueta
    async probarEtiqueta(i) {
      const medida = medidaImpresora(i);
      if (directa(i)) {
        const est = await agenteEstado(true); this.agente = est;
        if (sabeEtiquetas(est)) {
          try { await imprimirEtiquetas(i, trabajoEtiquetas(i, [{ nombre: 'Etiqueta de prueba áéíóú ñ', codigo: codigoBarrasPropio(0, '000'), copias: 1 }], 'nombre_codigo', medida)); return toast('Etiqueta de prueba enviada a «' + (i.nombre || 'la impresora') + '»', 'ok'); }
          catch (e) { toast(avisoImpresion('No se pudo imprimir en «' + (i.nombre || 'la impresora') + '»: ', e) + '. Se abre el PDF para imprimir a mano.', 'err'); }
        } else toast('El envío directo necesita el programa de escritorio actualizado: se abre el PDF para imprimir a mano', 'err');
      }
      try { if (await abrirArchivo('/api/productos/etiquetas', null, { prueba: true, formato: 'nombre_codigo', ancho_mm: medida[0], alto_mm: medida[1], ...(+i.dpi ? { dpi: +i.dpi } : {}) }, 'etiquetas.pdf') === 'descargado') toast('El navegador no dejó abrir la ventana: el PDF quedó en sus descargas'); } catch (e) { toast(e.message, 'err'); }
    },
    guardarImp() {
      const f = this.impForm; if (!(f.nombre || '').trim()) return toast('Indique el nombre de la impresora', 'err');
      const etq = f.uso === 'etiquetas';
      // 4.24: una impresora que una caja usa para sus tiquetes, o una categoría o un ítem para su comanda, no pasa a ser de etiquetas
      const antes = etq && f.id ? this.imps.find(x => x.id === f.id) : null;
      if (antes && antes.uso !== 'etiquetas') {
        const id = String(f.id), caja = this.cfg.terminales.find(x => String(x.impresora_comprobante_id || '') === id);
        // solo las asignaciones vigentes (las que se ven en la pantalla y se pueden quitar): categorías que existen, en cajas de restaurante, e ítems que no están inactivos
        const cats = new Set(categorias().map(c => String(c.id))), inactivos = new Set((store.productos || []).filter(p => p.activo === false).map(p => String(p.id)));
        const comanda = this.cfg.terminales.some(x => x.modo === 'restaurante' && Object.entries(x.destinos || {}).some(([c, v]) => cats.has(c) && String(v) === id))
          || Object.entries(mock.get('items_extra', {}) || {}).some(([pid, x]) => !inactivos.has(pid) && x && String(x.impresora_id || '') === id);
        if (caja || comanda) return toast('Esta impresora está asignada ' + (caja ? 'a la caja ' + caja.nombre : 'a comandas') + ': cree otra impresora para las etiquetas', 'err');
      }
      if (etq && f.lenguaje === 'pdf') { f.conexion = 'navegador'; f.direccion = ''; }
      if (etq && f.lenguaje !== 'pdf' && f.conexion !== 'usb' && f.conexion !== 'red') return toast('Indique cómo está conectada la impresora de etiquetas: por USB o por red', 'err');
      if (f.conexion === 'red' && !/^\d{1,3}(\.\d{1,3}){3}(:\d+)?$/.test((f.direccion || '').trim())) return toast('Indique la dirección IP de la impresora (por ejemplo 192.168.1.50)', 'err');
      if (f.solo_aqui && etiquetaConPuerto(f.uso, f.conexion, (f.direccion || '').trim())) return toast(ETQ_SIN_PUERTO, 'err');   // 9c (J2)
      if (etq && f.conexion === 'usb' && !(f.direccion || '').trim()) return toast('Indique el nombre de la impresora de etiquetas en Windows: sin él, las etiquetas saldrían por la impresora predeterminada del equipo', 'err');
      const sinDato = v => v === '' || v === null || v === undefined;
      if (etq) {
        if (!medidaValida(f.etq_ancho_mm, f.etq_alto_mm)) return toast('La medida de la etiqueta va de 20 a 110 mm de ancho y de 15 a 160 mm de alto', 'err');
        const mod = modeloDe(f.modelo);
        if (mod && +f.etq_ancho_mm > mod.ancho_max_mm) return toast('La ' + mod.nombre + ' imprime hasta ' + mod.ancho_max_mm + ' mm de ancho: elija una etiqueta más angosta', 'err');
        if (!sinDato(f.separacion_mm) && !(+f.separacion_mm >= 0 && +f.separacion_mm <= 20)) return toast('La separación entre etiquetas va de 0 a 20 mm', 'err');
        const tope = f.lenguaje === 'zpl' ? 30 : 15;
        if (!sinDato(f.densidad) && !(Number.isInteger(+f.densidad) && +f.densidad >= 0 && +f.densidad <= tope)) return toast('La densidad va de 0 a ' + tope + ' (o vacía, para usar la que tiene puesta la impresora)', 'err');
      }
      if (!mock.puedeGuardar()) return;
      const reg = { ...f, nombre: f.nombre.trim().slice(0, 40), direccion: (f.direccion || '').trim(), ancho: +f.ancho === 58 ? 58 : 80 };
      delete reg.medida_sel;
      if (etq) Object.assign(reg, { modelo: f.modelo || 'otra-tspl', lenguaje: ['tspl', 'zpl', 'pdf'].includes(f.lenguaje) ? f.lenguaje : 'tspl', dpi: +f.dpi || 203, etq_ancho_mm: +f.etq_ancho_mm, etq_alto_mm: +f.etq_alto_mm, separacion_mm: sinDato(f.separacion_mm) ? 2 : +f.separacion_mm, densidad: sinDato(f.densidad) ? null : +f.densidad, girar: f.lenguaje !== 'pdf' && !!f.girar });
      if (f.solo_aqui) return this.guardarPropia(reg);   // 4.25: una impresora solo de esta computadora no va a las de la empresa
      mock.actualizar('pos_impresoras', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'pos_impresoras'); lista.push(reg); } return lista; }, []);
      this.imps = impresoras(); this.impForm = null; toast('Impresora «' + reg.nombre + '» guardada', 'ok');
    },
    eliminarImp(i) { if (i.solo_aqui || esPropia(i)) return this.eliminarPropia(i); if (this.eqWeb) return this.alWeb(); if (!confirm('¿Eliminar la impresora «' + i.nombre + '»? Las categorías que la usaban pasan a la primera de comanda.')) return; mock.actualizar('pos_impresoras', l => (l || []).filter(x => x.id !== i.id), []); this.imps = impresoras(); this.impForm = null; },
    ejemplosImp() { if (!mock.puedeGuardar()) return; mock.actualizar('pos_impresoras', l => { const lista = Array.isArray(l) ? l : []; for (const [nombre, uso] of [['Cocina caliente', 'comanda'], ['Cocina fría', 'comanda'], ['Bar', 'comanda'], ['Postres', 'comanda'], ['Caja', 'comprobante']]) if (!lista.some(x => x.nombre === nombre)) lista.push({ id: mock.nextId(lista, 'pos_impresoras'), nombre, uso, conexion: 'navegador', direccion: '', ancho: 80, activa: true }); return lista; }, []); this.imps = impresoras(); toast('Impresoras de ejemplo creadas: asigne las categorías', 'ok'); },
    async buscarAgente() { this.buscandoAgente = true; this.agente = await agenteEstado(true); this.buscandoAgente = false; },
    async probarImp(i) {
      i = impresoraAqui(i);   // 4.25: en el programa, como está conectada en esta computadora
      if (i.uso === 'etiquetas') return this.probarEtiqueta(i);   // 4.24
      if (!porAgente(i)) { window.open(URL_AGENTE + '/', '_blank'); return toast('Las impresoras «del navegador» se prueban imprimiendo una comanda o un tiquete desde la caja (Ctrl+P)', 'ok'); }
      try { await probarAgente(i); toast('Prueba enviada a «' + i.nombre + '»', 'ok'); } catch (e) { toast(avisoImpresion('No se pudo imprimir en «' + i.nombre + '»: ', e), 'err'); }
    },
    async probarGaveta(i) { i = impresoraAqui(i); try { await abrirGaveta(i); toast('Gaveta abierta por «' + i.nombre + '»', 'ok'); } catch (e) { toast('La gaveta no abrió: ' + e.message, 'err'); } },
    nombreImp(id) { const i = this.imps.find(x => String(x.id) === String(id)); return i ? i.nombre : (id === 'cocina' ? 'Cocina (anterior)' : id === 'bar' ? 'Bar (anterior)' : String(id)); },
    // ---- 4.25 (tanda 8): impresión de esta computadora ----
    esPropia,
    usoTexto(i) { return (USOS_IMPRESORA.find(u => u[0] === (i.uso || 'comanda')) || [])[1]; },
    // E-6: con el programa conectado a la web, las impresoras de la empresa se crean y se cambian en la web: se abre lo de esta computadora
    alWeb(uso) {
      toast(IMPRESORAS_DE_LA_WEB, 'err');
      if (uso === 'comprobante' || uso === 'etiquetas') return this.nuevaPropia(uso);
      this.impForm = null; const el = typeof document !== 'undefined' && document.getElementById('cfg-equipo'); if (el) el.scrollIntoView({ block: 'start' });
    },
    nuevaImpEmpresa(uso) { if (this.eqWeb) return this.alWeb(uso); this.nuevaImp(uso); },
    editarImpEmpresa(i) { if (this.eqWeb) return this.alWeb(); this.editarImp(i); },
    ejemplosImpEmpresa() { if (this.eqWeb) return this.alWeb(); this.ejemplosImp(); },
    // copia para editar: cada impresora de la empresa con su fila de ajustes (vacía = igual que en la configuración)
    copiaEq(d) {
      const x = JSON.parse(JSON.stringify(d || equipoVacio())), aj = {};
      for (const i of this.imps) { const a = (x.ajustes || {})[String(i.id)] || {}; aj[String(i.id)] = { conexion: a.conexion === 'usb' || a.conexion === 'red' ? a.conexion : '', direccion: a.direccion || '', densidad: a.densidad ?? '', separacion_mm: a.separacion_mm ?? '', girar: a.girar === true ? 'si' : a.girar === false ? 'no' : '' }; }
      return { propias: Array.isArray(x.propias) ? x.propias : [], ajustes: aj, tiquetes: String(x.tiquetes || ''), etiquetas: String(x.etiquetas || '') };
    },
    // 4.29 (K-8): ¿esta computadora está conectada a la página web? Lo mismo que muestra Configuración › Instalación local (vinculada, sin
    // revocar ni descartar). Si no se puede saber (sin permiso o sin respuesta) no se avisa por aquí; queda la señal de las impresoras (eqWeb).
    async revisarConexionWeb() { try { const e = await api('/api/sinc/local/estado'); this.conectadaWeb = !!(e && e.modo_local && e.vinculado && !e.revocada_en && !e.descartada); } catch { this.conectadaWeb = false; } },
    async cargarEq() { const r = await cargarEquipo(true); this.eq = this.copiaEq(r.datos); this.eqWeb = !!r.web; },
    // lo que se guarda: solo los ajustes que cambian algo
    eqLimpio(eq) {
      const e = eq || this.eq, aj = {}, hay = v => v !== '' && v !== null && v !== undefined;
      for (const [id, a] of Object.entries(e.ajustes || {})) {
        const o = {};
        if (a.conexion === 'usb' || a.conexion === 'red') { o.conexion = a.conexion; o.direccion = String(a.direccion || '').trim(); }
        if (hay(a.densidad)) o.densidad = +a.densidad;
        if (hay(a.separacion_mm)) o.separacion_mm = +a.separacion_mm;
        if (a.girar === 'si' || a.girar === 'no') o.girar = a.girar === 'si';
        if (Object.keys(o).length) aj[id] = o;
      }
      return { propias: e.propias, ajustes: aj, tiquetes: e.tiquetes || '', etiquetas: e.etiquetas || '' };
    },
    async guardarEq() {
      if (!this.puedeConfigurar || !this.eq) return false;
      if (this.eqConPuerto()) { toast(ETQ_SIN_PUERTO, 'err'); return false; }   // 9c (J2)
      this.guardandoEq = true;
      try {
        const r = await api('/api/agente/equipo', { method: 'PUT', body: this.eqLimpio() });
        ponerEquipo(r.equipo, r.empresa_web); this.eq = this.copiaEq(r.equipo); this.eqWeb = !!r.empresa_web;
        toast('Impresión de esta computadora guardada', 'ok'); return true;
      } catch (e) { toast(e.message, 'err'); return false; } finally { this.guardandoEq = false; }
    },
    // 9c (J2): una impresora de etiquetas por red con «:puerto» en lo de esta computadora (ajuste de una de la empresa o una propia)
    eqConPuerto(eq) {
      const e = eq || this.eq; if (!e) return false;
      const deEmpresa = this.imps.some(i => i.uso === 'etiquetas' && (a => !!a && etiquetaConPuerto('etiquetas', a.conexion, a.direccion))((e.ajustes || {})[String(i.id)]));
      return deEmpresa || (e.propias || []).some(i => etiquetaConPuerto(i.uso, i.conexion, i.direccion));
    },
    // Probar con lo que vale aquí (lo que está en pantalla, aunque no se haya guardado)
    async probarAqui(i) {
      const imp = esPropia(i) ? i : impresoraAqui(i, this.eqLimpio());
      if (imp.uso === 'etiquetas') return this.probarEtiqueta(imp);
      if (!porAgente(imp)) return toast('«' + imp.nombre + '» imprime con la ventana del navegador en esta computadora: para probarla aquí elija «Impresora de Windows (USB)» o «Por red (dirección IP)»', 'err');
      try { await probarAgente(imp); toast('Prueba enviada a «' + imp.nombre + '»', 'ok'); } catch (e) { toast(avisoImpresion('No se pudo imprimir en «' + imp.nombre + '»: ', e), 'err'); }
    },
    windowsAqui(actual) { const l = (this.agente && this.agente.ok && this.agente.info && this.agente.info.impresoras_windows) || []; return actual && !l.includes(actual) ? [actual, ...l] : l; },
    nuevaPropia(uso) { this.impForm = { id: null, nombre: '', uso: uso === 'etiquetas' ? 'etiquetas' : 'comprobante', conexion: 'usb', direccion: '', ancho: 80, activa: true, solo_aqui: true }; this.alCambiarUso(); },
    editarPropia(i) { this.impForm = { ...i, solo_aqui: true }; this.alCambiarUso(); },
    async guardarPropia(reg) {
      if (!this.eq) return;
      if (!(reg.uso === 'etiquetas' && reg.lenguaje === 'pdf') && reg.conexion !== 'usb' && reg.conexion !== 'red') return toast('Indique cómo está conectada: impresora de Windows (USB) o por red', 'err');
      delete reg.solo_aqui; if (!reg.id) reg.id = 'eq-' + Date.now().toString(36);
      const antes = JSON.parse(JSON.stringify(this.eq)), l = this.eq.propias, i = l.findIndex(x => x.id === reg.id);
      if (i >= 0) l.splice(i, 1, reg); else l.push(reg);
      if (this.eq.tiquetes === reg.id && (reg.uso !== 'comprobante' || reg.activa === false)) this.eq.tiquetes = '';
      if (this.eq.etiquetas === reg.id && (reg.uso !== 'etiquetas' || reg.activa === false)) this.eq.etiquetas = '';
      if (await this.guardarEq()) this.impForm = null; else this.eq = antes;
    },
    async eliminarPropia(i) {
      if (!this.eq || !confirm('¿Eliminar la impresora «' + i.nombre + '» de esta computadora?')) return;
      const antes = JSON.parse(JSON.stringify(this.eq));
      this.eq.propias = this.eq.propias.filter(x => x.id !== i.id);
      if (this.eq.tiquetes === i.id) this.eq.tiquetes = '';
      if (this.eq.etiquetas === i.id) this.eq.etiquetas = '';
      if (await this.guardarEq()) this.impForm = null; else this.eq = antes;
    },
    toggleCat(id) { const l = this.t.categorias || []; this.t.categorias = l.includes(id) ? l.filter(x => x !== id) : [...l, id]; },
    // ---- plano de mesas (coordenadas en % del plano; se arrastran con el puntero) ----
    agregarMesas(n) { const desde = Math.max(0, ...this.t.mesas.map(m => +m.id || 0)) + 1; this.t.mesas.push(...mesasEnCuadricula(Math.max(1, Math.min(60, +n || 1)), desde)); },
    ordenar() { const mesas = this.t.mesas.filter(m => !esDeco(m)), grid = mesasEnCuadricula(mesas.length, 1); let i = 0; this.t.mesas = this.t.mesas.map(m => (esDeco(m) ? m : { ...m, x: grid[i].x, y: grid[i].y, w: m.forma === 'barra' ? Math.min(24, grid[i].w * 2) : grid[i].w, h: grid[i++].h, rot: 0 })); },
    agregarMesasTope(n) { if (this.soloMesas.length + (+n || 0) > 60) return toast('Una caja admite hasta 60 mesas', 'err'); this.agregarMesas(n); },
    quitarMesa(m) { this.t.mesas = this.t.mesas.filter(x => x.id !== m.id); if (this.mesaSel === m.id) this.mesaSel = null; },
    // ---- plano al estilo FISITAAP (3.46): objetos, forma y tamaño, rotación, sectores, proporciones y zoom ----
    agregarObjeto(forma) {
      const id = Math.max(0, ...this.t.mesas.map(m => +m.id || 0)) + 1, [w, h] = TAMANOS[forma] || [12, 18], deco = FORMAS_DECO.some(f => f[0] === forma);
      const nombre = deco ? (FORMAS_DECO.find(f => f[0] === forma) || [])[1] || forma : (forma === 'barra' ? 'Barra ' : 'Mesa ') + (this.soloMesas.length + 1);
      this.t.mesas.push({ id, nombre, x: 40, y: 40, w, h, forma, asientos: forma === 'barra' ? 6 : 4, sector_id: null, rot: 0, deco });
      this.mesaSel = id;
    },
    duplicarMesa(m) { const id = Math.max(0, ...this.t.mesas.map(x => +x.id || 0)) + 1; const copia = { ...m, id, nombre: esDeco(m) ? m.nombre : (m.nombre.replace(/\d+$/, '').trim() || 'Mesa') + ' ' + (this.soloMesas.length + 1), x: Math.min(100 - m.w, m.x + 3), y: Math.min(100 - m.h, m.y + 3) }; this.t.mesas.push(copia); this.mesaSel = id; },
    cambiarForma(m, forma) { const [w, h] = TAMANOS[forma] || [12, 18]; m.forma = forma; m.w = w; m.h = h; m.deco = FORMAS_DECO.some(f => f[0] === forma); if (!m.deco && !m.asientos) m.asientos = 4; },
    girar(m, grados) { m.rot = ((+m.rot || 0) + grados + 360) % 360; },
    agregarSector() {
      const n = (this.sectorNuevo || '').trim().slice(0, 30); if (!n) return;
      if ((this.t.sectores || []).some(s => s.nombre.toLowerCase() === n.toLowerCase())) return toast('Ya existe el sector «' + n + '»', 'err');
      const id = Math.max(0, ...(this.t.sectores || []).map(s => +s.id || 0)) + 1; this.t.sectores.push({ id, nombre: n, servicio_pct: null }); this.sectorNuevo = '';
    },
    quitarSector(s) { if (!confirm('¿Quitar el sector «' + s.nombre + '»? Sus mesas quedan sin sector.')) return; for (const m of this.t.mesas) if (m.sector_id === s.id) m.sector_id = null; this.t.sectores = this.t.sectores.filter(x => x.id !== s.id); },
    nombreSector(id) { const s = (this.t.sectores || []).find(x => x.id === id); return s ? s.nombre : ''; },
    estiloMesa(m) { return { left: m.x + '%', top: m.y + '%', width: m.w + '%', height: m.h + '%', transform: m.rot ? 'rotate(' + m.rot + 'deg)' : '' }; },
    iniciarArrastre(m, ev) {
      this.mesaSel = m.id; const plano = this.$refs.plano.getBoundingClientRect();
      this.arrastre = { id: m.id, dx: (ev.clientX - plano.left) / plano.width * 100 - m.x, dy: (ev.clientY - plano.top) / plano.height * 100 - m.y };
      ev.target.setPointerCapture && ev.target.setPointerCapture(ev.pointerId);
    },
    mover(ev) {
      if (!this.arrastre) return; const m = this.t.mesas.find(x => x.id === this.arrastre.id); if (!m) return;
      const plano = this.$refs.plano.getBoundingClientRect();
      m.x = Math.round(Math.max(0, Math.min(100 - m.w, (ev.clientX - plano.left) / plano.width * 100 - this.arrastre.dx)));
      m.y = Math.round(Math.max(0, Math.min(100 - m.h, (ev.clientY - plano.top) / plano.height * 100 - this.arrastre.dy)));
    },
    soltar() { this.arrastre = null; },
    // ---- modificadores (3.49, al estilo FISITAAP): grupos de opciones con mínimo, máximo y precio por opción ----
    // 4.30 (H1): el id de un grupo nuevo va por encima de los de la pantalla, de lo guardado, de los quitados en esta sesión y del mayor que
    // tuvo la clave en el servidor (mock.nextId): nunca es el de un grupo guardado o recién quitado, así sale como alta y no hereda nada.
    quitarMod(i) { const g = this.mods[i]; if (g && !this.modsQuitados.some(id => String(id) === String(g.id))) this.modsQuitados.push(g.id); this.mods.splice(i, 1); },
    nuevoMod() { const id = mock.nextId([...this.mods, ...(mock.get('pos_modificadores', []) || []), ...this.modsQuitados.map(x => ({ id: x }))].filter(g => g && g.id !== undefined && g.id !== null), 'pos_modificadores'); this.mods.push({ id, nombre: '', minimo: 1, maximo: 1, activo: true, opciones: [{ id: id * 100 + 1, nombre: '', precio: 0 }, { id: id * 100 + 2, nombre: '', precio: 0 }] }); },
    nuevaOpcion(g) { const id = Math.max(g.id * 100, ...g.opciones.map(o => +o.id || 0)) + 1; g.opciones.push({ id, nombre: '', precio: 0 }); },
    async guardarMods() {
      for (const g of this.mods) { if (!(g.nombre || '').trim()) return toast('Cada grupo necesita un nombre', 'err'); g.opciones = (g.opciones || []).filter(o => (o.nombre || '').trim()); if (!g.opciones.length) return toast('«' + g.nombre + '» necesita al menos una opción', 'err'); if (+g.maximo && +g.maximo < +g.minimo) return toast('«' + g.nombre + '»: el máximo no puede ser menor que el mínimo', 'err'); }
      this.guardandoMods = true;
      // 4.30: cada grupo parte del guardado (con el mismo id) y solo cambia lo que esta pantalla edita: así se conservan los productos,
      // categorías, tipo y demás datos que pone FISITAAP › Extras y Opcionales (antes se borraban y la caja y el catálogo dejaban de preguntarlos).
      // H3: las asignaciones de los grupos que aquí se cambian se leen del servidor justo antes; sin poder leerlas no se guarda nada.
      let alDia;
      try { const r = await api('/api/registros/pos_modificadores'); alDia = Array.isArray(r && r.datos) ? r.datos : []; }
      catch (e) { this.guardandoMods = false; return toast('No se pudieron guardar los modificadores: ' + e.message, 'err'); }
      const ok = await mock.set('pos_modificadores', modsParaGuardar(this.mods, mock.get('pos_modificadores', []) || [], alDia));
      this.guardandoMods = false; toast(ok ? 'Modificadores guardados' : 'No se pudieron guardar los modificadores', ok ? 'ok' : 'err');
    },
    // 4.30: ¿hay extras y opcionales que perdieron sus productos y categorías y se pueden recuperar de un respaldo? Los textos salen de
    // _recuperar_mods.js (los mismos de FISITAAP › Extras y Opcionales); se carga al abrir la pantalla, solo para quien puede configurar.
    // H6: en el programa conectado a la web el servidor no lo ofrece (lo pisaría la bajada) y manda la línea que dice que se recupera en la web.
    async cargarRecuperar() {
      try {
        const M = await import('./_recuperar_mods.js'), r = await api('/api/pos/modificadores/recuperar');
        this.recEnWeb = r && r.en_la_web ? String(r.aviso_web || '') : '';
        this.recMods = r && r.hay && !r.en_la_web && (r.grupos || []).length ? { respaldo: r.respaldo, texto: M.textoAviso(r.grupos.length, r.fecha), lineas: r.grupos.map(g => ({ id: g.id, nombre: g.nombre, texto: M.textoGrupo(g) })) } : null;
      } catch { this.recMods = null; }
    },
    async recuperarMods() {
      if (!this.recMods || this.recuperandoMods) return;
      this.recuperandoMods = true;
      try {
        const r = await api('/api/pos/modificadores/recuperar', { method: 'POST', body: { respaldo: this.recMods.respaldo } }), n = ((r && r.grupos) || []).length;
        toast(n === 1 ? 'Se recuperó 1 grupo' : 'Se recuperaron ' + n + ' grupos', 'ok'); this.recMods = null; this.recViendo = false;
        // H3: la copia de la pestaña no se refresca aquí (traería grupos que esta pantalla no muestra y el próximo guardado los borraría):
        // guardarMods lee del servidor las asignaciones de lo que cambia, así lo recuperado no se pierde
      } catch (e) { toast(e.message, 'err'); await this.cargarRecuperar(); }
      this.recuperandoMods = false;
    },
    // ---- promociones y combos (3.23) ----
    nuevaPromo(tipo) { const id = Math.max(0, ...this.promos.map(p => +p.id || 0)) + 1; this.promos.push({ id, nombre: tipo === 'combo' ? 'Combo ' + id : tipo === '2x1' ? '2×1' : 'Happy hour', tipo, activa: true, dias: [], desde: '', hasta: '', pct: tipo === 'descuento' ? 20 : 0, productos: [], combo: { precio: 0, items: [{ producto_id: null, cantidad: 1 }] } }); },
    precioNormalCombo(p) { return (p.combo.items || []).reduce((s, it) => { const x = this.itemsVenta.find(y => y.id === +it.producto_id); return s + (x ? (+it.cantidad || 1) * (+x.precio || 0) * (1 + (+x.tarifa || 0) / 100) : 0); }, 0); },
    async guardarPromos() {
      for (const p of this.promos) {
        if (!(p.nombre || '').trim()) return toast('Cada promoción necesita un nombre', 'err');
        if (p.tipo === 'descuento' && !(+p.pct > 0 && +p.pct <= 100)) return toast('«' + p.nombre + '»: el descuento va de 1 a 100 %', 'err');
        if (p.tipo === 'combo') { p.combo.items = (p.combo.items || []).filter(it => it.producto_id); if (!p.combo.items.length || !(+p.combo.precio > 0)) return toast('«' + p.nombre + '»: el combo necesita ítems y precio', 'err'); }
      }
      this.guardandoPromos = true;
      const ok = await mock.set('pos_promos', this.promos.map(p => ({ id: p.id, nombre: p.nombre.trim(), tipo: p.tipo, activa: p.activa !== false, dias: (p.dias || []).map(Number), desde: p.desde || '', hasta: p.hasta || '', pct: +p.pct || 0, productos: (p.productos || []).map(Number), combo: p.tipo === 'combo' ? { precio: +p.combo.precio || 0, items: p.combo.items.map(it => ({ producto_id: +it.producto_id, cantidad: +it.cantidad || 1 })) } : null })));
      this.guardandoPromos = false; toast(ok ? 'Promociones guardadas' : 'No se pudieron guardar las promociones', ok ? 'ok' : 'err');
    },
    async guardar() {
      for (const t of this.cfg.terminales) {
        if (!(t.nombre || '').trim()) return toast('Indique el nombre de cada caja', 'err');
        if (+t.servicio_pct < 0 || +t.servicio_pct > 100) return toast(t.nombre + ': el porcentaje de servicio debe estar entre 0 y 100', 'err');
        if (+t.servicio_pct > 0 && !(t.servicio_detalle || '').trim()) return toast(t.nombre + ': indique el nombre del cargo de servicio', 'err');
        t.correo_cierre = String(t.correo_cierre || '').split(/[,;\s]+/).map(x => x.trim()).filter(Boolean).join(', ');   // 3.87: correo del cierre (Z)
        const malCorreo = t.correo_cierre ? t.correo_cierre.split(', ').find(x => !/^[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}$/.test(x)) : null;
        if (malCorreo) return toast(t.nombre + ': el correo del cierre «' + malCorreo + '» no es válido', 'err');
        const nombres = new Set(); for (const m of t.mesas) { m.nombre = (m.nombre || '').trim().slice(0, 30) || (esDeco(m) ? m.forma : 'Mesa ' + m.id); m.w = Math.min(100, Math.max(2, +m.w || 12)); m.h = Math.min(100, Math.max(2, +m.h || 18)); m.rot = ((+m.rot || 0) % 360 + 360) % 360; m.asientos = esDeco(m) ? 0 : Math.max(1, Math.min(60, +m.asientos || 4)); if (m.sector_id && !(t.sectores || []).some(s => s.id === m.sector_id)) m.sector_id = null; if (esDeco(m)) continue; if (nombres.has(m.nombre.toLowerCase())) return toast(t.nombre + ': hay dos mesas llamadas «' + m.nombre + '»', 'err'); nombres.add(m.nombre.toLowerCase()); }
        for (const s of t.sectores || []) { s.nombre = (s.nombre || '').trim().slice(0, 30) || 'Sector'; s.servicio_pct = s.servicio_pct === '' || s.servicio_pct === null || s.servicio_pct === undefined ? null : Math.min(100, Math.max(0, +s.servicio_pct || 0)); }
        t.nombre = t.nombre.trim().slice(0, 40); t.servicio_pct = +t.servicio_pct || 0; t.descuento_max_pct = Math.min(100, Math.max(0, +t.descuento_max_pct || 0)); t.ancho_ticket = +t.ancho_ticket === 58 ? 58 : 80; t.columnas = Math.min(8, Math.max(2, +t.columnas || 4));
        // restaurante avanzado (3.7): listas por línea y clave de supervisor resumida (nunca en claro)
        t.modificadores = String(t.modificadores_txt || '').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 40); t.saloneros = String(t.saloneros_txt || '').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 40);
        if (t.quitar_clave) t.clave_supervisor = '';
        else if ((t.clave_nueva || '').trim()) { if (t.clave_nueva.trim().length < 4) return toast(t.nombre + ': la clave de supervisor debe tener al menos 4 caracteres', 'err'); t.clave_supervisor = await hashClave(t.clave_nueva); }
      }
      const nombres = this.cfg.terminales.map(t => t.nombre.toLowerCase()); if (new Set(nombres).size !== nombres.length) return toast('Cada caja debe tener un nombre distinto', 'err');
      this.guardando = true;
      const ok = await guardarConfig({ terminales: this.cfg.terminales.map(({ modificadores_txt, saloneros_txt, clave_nueva, quitar_clave, ...t }) => t) });
      this.guardando = false;
      if (ok) { for (const t of this.cfg.terminales) { t.clave_nueva = ''; t.quitar_clave = false; } toast('Configuración del punto de venta guardada', 'ok'); }
    },
  },
  // 3.37: las tarjetas de Configuración abren esta pantalla en su sección (?ir=caja|cuentas|carga|servicio|impresion|carrito|impresoras|restaurante|mesas)
  mounted() {
    const ir = this.params && this.params.ir; if (!ir) return;
    let n = 0; const t = setInterval(() => {                       // la sección aparece cuando cargan las cajas: se espera hasta 6 s
      const el = document.getElementById('cfg-' + ir);
      if (el || ++n > 30) { clearInterval(t); if (el) { el.scrollIntoView({ block: 'start' }); el.style.outline = '2px solid var(--primary)'; setTimeout(() => { el.style.outline = ''; }, 2500); } }
    }, 200);
  },
  async created() {
    try { this.bodegas = await api('/api/inventario/bodegas'); for (const t of this.cfg.terminales) if (!t.bodega_id) t.bodega_id = (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null; } catch {}
    try { this.cuentas = (await cuentasParaMovimientos()).filter(b => (b.moneda || 'CRC') === 'CRC'); } catch {}
    this.buscarAgente();
    if (this.esPrograma) this.cargarEq().catch(() => {});   // 4.25 (tanda 8): solo en el programa de escritorio
    if (this.esPrograma) this.revisarConexionWeb();   // 4.29 (K-8): en la página web no se pregunta
    if (!this.esPrograma && sesion.tieneModulo('pedidos_online')) this.cargarEstacionComandas();   /* 4.31: la tarjeta del interruptor (se carga aparte: la pantalla no depende de ella) */
    if (this.puedeConfigurar) this.cargarRecuperar();   // 4.30
  },
  // 4.25: una impresora de la empresa nueva tiene su fila de «En esta computadora»
  watch: { imps() { if (this.eq) for (const i of this.imps) if (!this.eq.ajustes[String(i.id)]) this.eq.ajustes[String(i.id)] = { conexion: '', direccion: '', densidad: '', separacion_mm: '', girar: '' }; } },
  template: `
  <div class="page">
    <PageHead title="Configuración del punto de venta" sub="Un negocio puede tener varias cajas: cada una con su modo (mostrador o restaurante), comprobante, bodega, cuentas, categorías que carga y, en restaurantes, su plano de mesas." :crumbs="[{label:'Punto de venta'},{label:'Configuración'}]">
      <a class="btn ghost" href="#/pos/caja">Ir a la caja</a><button class="btn" :disabled="guardando || !puedeConfigurar" @click="guardar">Guardar</button>
    </PageHead>
    <div class="alert warn" v-if="avisoWeb">{{AVISO_CONECTADA_WEB}}</div><!-- 4.29 (K-8) -->
    <div class="alert warn" v-if="!puedeConfigurar">Su rol puede usar la caja, pero la configuración del punto de venta la cambia un Administrador de la empresa.</div>
    <div class="alert warn" v-if="limiteCajas && cfg.terminales.length > limiteCajas">Tiene {{cfg.terminales.length}} cajas y su plan incluye {{limiteCajas}}: elimine las que sobran para poder guardar, o amplíe el plan en Configuración › Suscripción y planes.</div>
    <div class="card"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
      <span class="small muted">Cajas:</span><button v-for="x in cfg.terminales" :key="x.id" class="pos-cat" :class="{on: x.id===sel}" @click="sel=x.id; mesaSel=null">{{x.nombre}}<span class="small" v-if="x.modo==='restaurante'"> 🍽</span></button>
      <button class="btn sm sec" @click="nueva" :disabled="!puedeConfigurar || topeCajas" :title="topeCajas ? textoLimite : ''" v-if="!cajasEnWeb">+ Agregar caja</button><span class="small muted" v-if="limiteCajas">{{cfg.terminales.length}} de {{limiteCajas}} {{limiteCajas === 1 ? 'caja' : 'cajas'}} del plan</span><button class="btn sm ghost" @click="eliminar" v-if="cfg.terminales.length>1 && !cajasEnWeb">Eliminar «{{t.nombre}}»</button><span class="small muted" v-if="cajasEnWeb">Agregar o quitar cajas se hace en la página web. Aquí puede cambiar las cajas que ya existen.</span>
      <span class="small muted" style="margin-left:auto">Cada computadora elige su caja al abrir Punto de venta › Caja y la recuerda.</span>
    </div></div>
    <div id="cfg-modificadores" class="card" style="margin-bottom:12px"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:6px"><h2 style="margin:0">Modificadores <small>tamaño, extras, término… se preguntan al pedir el plato en la caja y en el catálogo en línea</small></h2><div class="row" style="gap:6px"><button class="btn sm sec" @click="nuevoMod" :disabled="!puedeConfigurar">+ Grupo</button><button class="btn sm" @click="guardarMods" :disabled="!puedeConfigurar || guardandoMods">Guardar modificadores</button></div></div>
      <div v-if="recMods" class="alert info" style="margin:8px 0"><div>{{recMods.texto}}</div>
        <div v-if="recViendo" style="margin-top:6px"><div class="small">Se repone solo lo que falta; lo que estos grupos tienen hoy no se cambia.</div><ul style="margin:4px 0 0 18px;padding:0"><li v-for="x in recMods.lineas" :key="x.id"><b>{{x.nombre}}</b>: {{x.texto}}</li></ul></div>
        <div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><button v-if="!recViendo" class="btn sm" type="button" @click="recViendo = true">Recuperar</button><button v-if="recViendo" class="btn sm" type="button" :disabled="recuperandoMods" @click="recuperarMods">Confirmar y recuperar</button><button v-if="recViendo" class="btn sm sec" type="button" @click="recViendo = false">Cancelar</button></div></div>
      <p class="small muted" style="margin:8px 0 0" v-if="recEnWeb">{{recEnWeb}}</p><p class="small muted" style="margin:8px 0 0" v-else>Si un extra u opcional de FISITAAP dejó de preguntarse en la caja o en el catálogo en línea y aquí no aparece el aviso para recuperarlo, vuelva a asignarle sus productos y categorías en FISITAAP › Extras u Opcionales.</p>
      <p class="small muted" v-if="!mods.length" style="margin:8px 0 0">Ejemplos: «Tamaño» (obligatorio, una opción: Regular ₡0, Grande ₡1.000); «Extras» (opcional, hasta 2: Queso ₡500, Aguacate ₡700). Luego, en cada ítem de Inventario, elija qué grupos le aplican. Los precios son sin IVA y se suman al precio del plato.</p>
      <div v-for="(g, i) in mods" :key="g.id" class="card" style="padding:10px;margin-top:8px;background:var(--bg2, #f7f8fa)">
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center"><input class="inp" v-model="g.nombre" maxlength="40" placeholder="Nombre del grupo" style="flex:1;min-width:160px;font-weight:600" :disabled="!puedeConfigurar"><span class="small muted">mínimo</span><input type="number" class="inp" min="0" max="10" v-model.number="g.minimo" style="width:64px" :disabled="!puedeConfigurar"><span class="small muted">máximo</span><input type="number" class="inp" min="0" max="20" v-model.number="g.maximo" style="width:64px" title="0 = sin límite" :disabled="!puedeConfigurar"><label class="row small" style="gap:4px"><input type="checkbox" v-model="g.activo" :disabled="!puedeConfigurar"> Activo</label><button class="btn icon" @click="quitarMod(i)" :disabled="!puedeConfigurar" title="Quitar grupo">✕</button></div>
        <div class="row" v-for="(o, j) in g.opciones" :key="o.id" style="gap:6px;align-items:center;margin-top:4px"><input class="inp" v-model="o.nombre" maxlength="40" placeholder="Opción" style="min-width:200px" :disabled="!puedeConfigurar"><span class="small muted">+ ₡</span><input type="number" class="inp" min="0" step="50" v-model.number="o.precio" style="width:100px" :disabled="!puedeConfigurar"><button class="btn icon" @click="g.opciones.splice(j, 1)" :disabled="!puedeConfigurar">✕</button></div>
        <button class="btn sm ghost" style="margin-top:6px" @click="nuevaOpcion(g)" :disabled="!puedeConfigurar">+ Opción</button>
      </div>
    </div>
    <div id="cfg-promos" class="card" style="margin-bottom:12px"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:6px"><h2 style="margin:0">Promociones y combos <small>para todas las cajas · descuento por horario, 2×1 y combos con precio fijo</small></h2><div class="row" style="gap:6px"><button class="btn sm sec" @click="nuevaPromo('descuento')" :disabled="!puedeConfigurar">+ Descuento por horario</button><button class="btn sm sec" @click="nuevaPromo('2x1')" :disabled="!puedeConfigurar">+ 2×1</button><button class="btn sm sec" @click="nuevaPromo('combo')" :disabled="!puedeConfigurar">+ Combo</button><button class="btn sm" @click="guardarPromos" :disabled="!puedeConfigurar || guardandoPromos">Guardar promociones</button></div></div>
      <p class="small muted" v-if="!promos.length" style="margin:8px 0 0">Ejemplos: «Happy hour» −20 % en cervezas de lunes a viernes de 5 a 7 pm; «2×1 en pizzas» los martes; «Combo almuerzo» (casado + refresco) a ₡4.500. La caja los aplica sola según el día y la hora; un descuento manual tiene prioridad.</p>
      <div v-for="(p, i) in promos" :key="p.id" class="card" style="padding:10px;margin-top:8px;background:var(--bg2, #f7f8fa)">
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
          <span class="badge info">{{p.tipo==='combo' ? 'Combo' : p.tipo==='2x1' ? '2×1' : 'Descuento'}}</span><input class="inp" v-model="p.nombre" maxlength="40" placeholder="Nombre" style="flex:1;min-width:160px;font-weight:600" :disabled="!puedeConfigurar">
          <label class="row small" style="gap:4px"><input type="checkbox" v-model="p.activa" :disabled="!puedeConfigurar"> Activa</label>
          <span class="small muted">Días:</span><label class="row small" style="gap:3px" v-for="d in DIAS" :key="d[0]"><input type="checkbox" :value="d[0]" v-model="p.dias" :disabled="!puedeConfigurar"> {{d[1]}}</label>
          <span class="small muted">de</span><input type="time" class="inp" v-model="p.desde" :disabled="!puedeConfigurar"><span class="small muted">a</span><input type="time" class="inp" v-model="p.hasta" :disabled="!puedeConfigurar">
          <button class="btn icon" @click="promos.splice(i, 1)" :disabled="!puedeConfigurar" title="Quitar">✕</button>
        </div>
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;margin-top:6px" v-if="p.tipo!=='combo'">
          <template v-if="p.tipo==='descuento'"><span class="small">Descuento</span><input type="number" class="inp" min="1" max="100" v-model.number="p.pct" style="width:80px" :disabled="!puedeConfigurar"><span class="small">%</span></template>
          <span class="small">en</span><select class="inp" multiple v-model="p.productos" style="min-width:260px;height:76px" :disabled="!puedeConfigurar"><option v-for="x in itemsVenta" :key="x.id" :value="x.id">{{x.nombre}}</option></select><span class="small muted">(sin elegir ninguno = todos los ítems; Ctrl para varios)</span>
        </div>
        <div v-else style="margin-top:6px">
          <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap"><span class="small">Precio del combo (con IVA)</span><input type="number" class="inp" min="0" step="1" v-model.number="p.combo.precio" style="width:120px" :disabled="!puedeConfigurar"><button class="btn sm ghost" @click="p.combo.items.push({producto_id: null, cantidad: 1})" :disabled="!puedeConfigurar">+ Ítem</button></div>
          <div class="row" v-for="(it, j) in p.combo.items" :key="j" style="gap:6px;align-items:center;margin-top:4px"><input type="number" class="inp" min="0.01" step="1" v-model.number="it.cantidad" style="width:70px" :disabled="!puedeConfigurar"><span class="small">×</span><select class="inp" v-model="it.producto_id" style="min-width:220px" :disabled="!puedeConfigurar"><option :value="null">— Ítem —</option><option v-for="x in itemsVenta" :key="x.id" :value="x.id">{{x.nombre}} · {{money(x.precio * (1 + (+x.tarifa || 0) / 100))}}</option></select><button class="btn icon" @click="p.combo.items.splice(j, 1)" :disabled="!puedeConfigurar">✕</button></div>
          <p class="small muted" style="margin:4px 0 0">Normal: {{money(precioNormalCombo(p))}} · el combo rebaja cada ítem en proporción para que el tiquete sume el precio del combo.</p>
        </div>
      </div>
    </div>
    <div class="grid cols-2" style="align-items:start" v-if="t">
      <div id="cfg-caja" class="card"><h2>Caja y comprobante</h2>
        <div class="grid">
          <Field label="Nombre de la caja" req help="Aparece en el tiquete y en los cierres"><input v-model="t.nombre" maxlength="40" placeholder="Caja 1, Carnicería, Barra…"></Field>
          <Field label="Sucursal" v-if="sucursalesEmpresa.length" help="La caja se ve y se usa solo en su sucursal; vacío = en todas"><select v-model="t.sucursal_id"><option :value="null">— Todas las sucursales —</option><option v-for="x in sucursalesEmpresa" :key="x.id" :value="x.id">{{x.nombre}}</option></select></Field>
          <Field label="Modo" req help="¿Quiere una caja aparte solo para venta rápida, con su propia apertura y cierre? Cree otra caja en modo Mostrador (según las cajas que incluye su plan)."><select v-model="t.modo"><option v-for="m in MODOS" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
          <Field label="Al entrar a esta caja" v-if="t.modo==='restaurante'" help="Mesas: abre el plano del salón. Venta rápida: abre directo la venta sin mesa. Preguntar cada vez: muestra las dos opciones. Arriba siempre puede pasar de una a otra."><select v-model="t.inicio"><option v-for="x in INICIOS" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></Field>
          <Field label="Comprobante por defecto" req help="El tiquete no necesita cliente; la factura sí"><select v-model="t.tipo_documento"><option value="04">Tiquete electrónico</option><option value="01">Factura electrónica</option></select></Field>
          <Field label="Bodega de la que se descuenta" req><Buscador v-model="t.bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
          <Field label="Cliente por defecto" help="Vacío = consumidor final (tiquete sin receptor)"><select v-model="t.cliente_defecto_id"><option :value="null">— Consumidor final —</option><option v-for="x in clientes" :key="x.id" :value="x.id">{{x.nombre}}</option></select></Field>
          <Field label="Vendedor o cajero" help="Se guarda en cada comprobante; vacío = el usuario conectado"><input v-model="t.vendedor"></Field>
          <Field label="Enviar el cierre a" help="Al cerrar la caja, a este correo le llega el reporte de cierre (Z) en PDF. Sale por el correo saliente de la empresa (Configuración › Facturación electrónica). Varios, separados por coma. Vacío = no se envía"><input type="email" multiple v-model.trim="t.correo_cierre" maxlength="300" placeholder="dueno@sunegocio.com"></Field>
        </div>
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">
          <Toggle v-model="t.pedir_apertura" label="Pedir apertura de caja (efectivo inicial) antes de la primera venta"></Toggle>
          <Toggle v-model="t.fiado" label="Permitir fiado (crédito de casa) a clientes con límite de crédito en Contactos"></Toggle>
          <Toggle v-model="t.enviar_hacienda" label="Enviar a Hacienda en el momento (si no, lo envía la cola en minutos)"></Toggle>
          <Toggle v-model="t.cierre_ciego" label="Cierre a ciegas: el cajero cuenta y declara sin ver cuánto debería haber"></Toggle>
          <div v-if="t.cierre_ciego" style="margin-left:28px;display:flex;flex-direction:column;gap:8px">
            <Toggle v-model="t.cierre_corte_cajero" label="Al cerrar la caja o entregar el turno, el cajero ve el corte: al cerrar, lo que registró el sistema y el faltante o excedente; al entregar el turno, la diferencia. Apagado: solo ve lo que declaró, en pantalla y en la colilla"></Toggle>
            <Toggle v-if="t.cierre_corte_cajero" v-model="t.colilla_completa" style="margin-left:28px" label="La colilla del cajero también lleva lo que registró el sistema y el faltante o excedente. Apagado: solo lo que declaró, con las firmas"></Toggle>
            <p class="small muted" style="margin:0">Ven siempre el corte completo en Cierres de caja, y desde ahí imprimen la colilla completa, el Administrador, el Avanzado y los roles con «Ver gastos, bancos, contabilidad y reportes» o «Configuración de la empresa». El Vendedor cierra como el cajero. Si la caja no da la colilla completa a su cajero, esa colilla sale en la impresora de tiquetes de la computadora desde donde se imprime o en el navegador, no en la de la caja.</p>
          </div>
          <Toggle v-model="t.colilla_auto" label="Imprimir la colilla al cerrar la caja (se deja con el dinero)"></Toggle>
          <Toggle v-model="t.cobro_solo_cajero" label="Solo cobra quien abrió la caja o recibió el turno (también entradas, salidas y anulaciones); los demás usuarios toman pedidos y envían comandas desde el celular. En restaurante viene encendido"></Toggle>
        </div>
      </div>
      <div id="cfg-cuentas" class="card"><h2>Cuentas por medio de pago <small>Bancos y cajas en colones</small></h2>
        <p class="small muted" style="margin:0 0 10px">Al cobrar, cada medio registra su cobro en la cuenta indicada (Pagos recibidos + Bancos). Vacío = la cuenta principal (efectivo: la primera cuenta de tipo Efectivo).</p>
        <div class="grid cols-2">
          <Field v-for="m in MEDIOS" :key="m[0]" :label="m[2] + ' ' + m[1]"><select v-model="t.cuentas[m[0]]"><option value="">— Automática —</option><option v-for="b in cuentas" :key="b.nombre" :value="b.nombre">{{b.nombre}} ({{b.tipo}})</option></select></Field>
          <Field label="💵 Efectivo en dólares" help="Caja o cuenta en dólares donde entran los billetes cuando el cliente paga en dólares; sin ella la caja no ofrece cobrar en dólares"><select v-model="t.cuentas.USD"><option value="">— No se reciben dólares —</option><option v-for="b in cuentas.filter(x => (x.moneda || 'CRC') === 'USD')" :key="b.nombre" :value="b.nombre">{{b.nombre}} ({{b.tipo}})</option></select></Field>
        </div>
        <p class="small muted" style="margin:8px 0 0" v-if="!cuentas.length">No hay cuentas en Bancos: créelas en Bancos › Bancos y cajas (por ejemplo «Caja general» de tipo Efectivo).</p>
      </div>
      <div id="cfg-carga" class="card"><h2>Qué carga esta caja <small>categorías principales</small></h2>
        <p class="small muted" style="margin:0 0 10px">Sin marcar ninguna, la caja muestra todos los productos. Marque solo las categorías de esta caja (por ejemplo, la carnicería del supermercado) y verá únicamente esos botones y productos.</p>
        <div class="row" style="gap:6px;flex-wrap:wrap"><button v-for="c in raices" :key="c.id" class="pos-cat" :class="{on: catMarcada(c.id)}" @click="toggleCat(c.id)">{{c.icono ? c.icono + ' ' : ''}}{{c.nombre}}</button></div>
        <p class="small muted" style="margin:8px 0 0" v-if="!raices.length">Cree las categorías en Inventario › Categorías.</p>
      </div>
      <div id="cfg-servicio" class="card"><h2>Restaurantes: impuesto de servicio</h2>
        <div class="grid cols-2">
          <Field label="Porcentaje de servicio" help="10 % en restaurantes (Ley 4946); 0 = no aplica"><input type="number" min="0" max="100" step="0.5" v-model.number="t.servicio_pct"></Field>
          <Field label="Nombre del cargo" help="Así sale en el comprobante (otros cargos, sin IVA)"><input v-model="t.servicio_detalle" maxlength="160"></Field>
        </div>
        <p class="small muted" style="margin:8px 0 0">Se agrega como «otros cargos» del comprobante electrónico (tipo 06) sobre la venta neta, sin IVA. En la caja se puede desmarcar para una venta (por ejemplo, para llevar).</p>
      </div>
      <div id="cfg-impresion" class="card"><h2>Impresión</h2>
        <div class="grid cols-2">
          <Field label="Formato al cobrar"><select v-model="t.formato"><option value="tiquete">Tiquete térmico</option><option value="carta">PDF carta</option></select></Field>
          <Field label="Ancho del tiquete"><select v-model.number="t.ancho_ticket"><option :value="80">80 mm</option><option :value="58">58 mm</option></select></Field>
        </div>
        <Field label="Impresora de tiquetes y facturas de esta caja" style="margin-top:10px" help='"La del navegador" abre el comprobante para imprimirlo con Ctrl+P. Una impresora USB o de red imprime directo, sin preguntar, por el servicio de impresión de esta computadora'><select v-model="t.impresora_comprobante_id"><option value="">— La del navegador —</option><option v-for="i in impsComprobante" :key="i.id" :value="String(i.id)">{{i.nombre}}</option></select></Field>
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px"><Toggle v-model="t.imprimir_auto" label="Abrir el comprobante para imprimir en cuanto se cobra"></Toggle><Toggle v-model="t.abrir_gaveta" label="Abrir la gaveta al cobrar en efectivo (por la impresora de tiquetes, con el agente)"></Toggle></div>
        <Field label="Pie del tiquete térmico" style="margin-top:10px" help="Una frase al final del tiquete que imprime el agente"><input v-model="t.pie_tiquete" maxlength="120" placeholder="¡Gracias por su visita! Síganos en Instagram @hotelplayaserena"></Field>
        <p class="small muted" style="margin:8px 0 0">El tiquete se abre en una pestaña nueva; con Ctrl+P sale por la impresora predeterminada. Configure en Windows la impresora térmica como predeterminada en la computadora de la caja y el tamaño de papel de 80 (o 58) mm.</p>
      </div>
      <div id="cfg-carrito" class="card"><h2>Carrito y rejilla</h2>
        <div class="grid cols-2">
          <Field label="Descuento máximo por línea (%)"><input type="number" min="0" max="100" v-model.number="t.descuento_max_pct"></Field>
          <Field label="Botones por fila en la rejilla"><input type="number" min="2" max="8" v-model.number="t.columnas"></Field>
        </div>
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px">
          <Toggle v-model="t.precio_editable" label="Permitir cambiar el precio en la caja"></Toggle>
          <Toggle v-model="t.mostrar_imagenes" label="Mostrar la imagen del producto en los botones"></Toggle>
          <Toggle v-model="t.mostrar_existencias" label="Mostrar existencias en los botones"></Toggle>
        </div>
        <p class="small muted" style="margin:10px 0 0">Las categorías y subcategorías de los botones se administran en Inventario › Categorías. Los códigos de barras se leen con cualquier lector USB.</p>
      </div>
      <div id="cfg-recetas" class="card" style="grid-column:1/-1"><h2>Recetas y fichas técnicas <small>qué lleva cada plato, bebida o cóctel; al venderlo se rebajan los insumos</small></h2>
        <p class="small muted" style="margin:0 0 8px">Los insumos (arroz, pollo, botella de vino) se crean en Inventario › Ítems con «Se vende» apagado. Cada receta crea su ítem de venta (copa de vino, casado) con su categoría para la caja; una receta con «Se vende» apagado es una preparación que sirve de ingrediente.</p>
        <a class="btn sec" href="#/pos/recetas">Abrir recetas y fichas técnicas</a>
      </div>
      <div id="cfg-impresoras" class="card" style="grid-column:1/-1"><h2>Impresoras <small>comanda (cocina caliente, cocina fría, bar, postres…), tiquetes y etiquetas</small></h2>
        <p class="small muted" style="margin:0 0 10px">Cree las impresoras con el nombre que quiera y asígnelas a las categorías o a cada ítem. Las «del navegador» imprimen con Ctrl+P en la ventana que se abre; las USB y de red imprimen directo a la térmica a través del agente de impresión instalado en la computadora de la caja. La impresora de etiquetas es aparte de la de tiquetes: se usa en Inventario › Ítems › Etiquetas, con su modelo y la medida de sus etiquetas.</p>
        <div class="alert" :class="agente && agente.ok ? 'ok' : 'warn'" style="margin:0 0 10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <span v-if="agente && agente.ok">🖨 {{agente.via === 'local' ? 'Impresión directa activa en esta instalación local' : 'Agente de impresión conectado en esta computadora'}} (versión {{agente.info.version}}).<span v-if="(agente.info.impresoras_windows||[]).length"> Impresoras de Windows: {{agente.info.impresoras_windows.join(', ')}}.</span></span>
          <span v-else>Impresión directa no disponible desde esta computadora: con el sistema en la nube instale el agente de impresión en la PC de la caja (se ejecuta y queda abierto); la instalación local ya la trae adentro.</span>
          <button class="btn sm ghost" @click="buscarAgente" :disabled="buscandoAgente">{{buscandoAgente ? 'Buscando…' : 'Volver a buscar'}}</button><a class="btn sm ghost" :href="URL_AGENTE + '/'" target="_blank" v-if="agente && agente.ok && agente.via !== 'local'">Página del agente</a>
        </div>
        <div class="alert" v-if="esPrograma && eqWeb" style="margin:0 0 10px">{{IMPRESORAS_DE_LA_WEB}}</div>
        <Empty v-if="!imps.length" icon="🖨" title="Sin impresoras" text="Agregue al menos una impresora de comanda y una de tiquetes, o cree los ejemplos (cocina caliente, cocina fría, bar, postres y caja)."><div class="row" style="gap:8px"><button class="btn" @click="nuevaImpEmpresa('comanda')">+ Impresora</button><button class="btn sec" @click="nuevaImpEmpresa('etiquetas')">+ Impresora de etiquetas</button><button class="btn sec" @click="ejemplosImpEmpresa">Crear ejemplos</button></div></Empty>
        <template v-else>
          <table class="tbl"><thead><tr><th>Nombre</th><th>Uso</th><th>Conexión</th><th>Dirección</th><th class="num">Ancho</th><th>Estado</th><th></th></tr></thead>
            <tbody><tr v-for="i in imps" :key="i.id" :style="i.activa===false ? 'opacity:.55' : ''"><td><b>{{i.nombre}}</b></td><td>{{(USOS_IMPRESORA.find(u => u[0] === (i.uso || 'comanda')) || [])[1]}}</td><td>{{conexionTexto(i)}}</td><td class="mono small">{{i.direccion || '—'}}</td><td class="num">{{i.uso==='etiquetas' ? medidaEtq(i) : (i.ancho || 80) + ' mm'}}</td><td><span :class="i.activa===false ? 'badge' : 'badge ok'">{{i.activa===false ? 'Inactiva' : 'Activa'}}</span></td><td style="white-space:nowrap"><div class="acts"><button class="btn sm ghost" @click="probarImp(i)" :title="i.uso==='etiquetas' ? 'Imprime una etiqueta de prueba con un código de barras' : 'Imprime una hoja de prueba'">Probar</button><button class="btn sm ghost" v-if="i.uso==='comprobante' && (i.conexion==='usb' || i.conexion==='red')" @click="probarGaveta(i)">Gaveta</button><button class="btn sm ghost" @click="editarImpEmpresa(i)">Editar</button></div></td></tr></tbody></table>
          <div class="row" style="gap:8px;margin-top:8px"><button class="btn sm sec" @click="nuevaImpEmpresa('comanda')">+ Impresora de comanda</button><button class="btn sm sec" @click="nuevaImpEmpresa('comprobante')">+ Impresora de tiquetes</button><button class="btn sm sec" @click="nuevaImpEmpresa('etiquetas')">+ Impresora de etiquetas</button></div>
        </template>
      </div>
      <div id="cfg-equipo" class="card" style="grid-column:1/-1" v-if="esPrograma && eq"><h2>En esta computadora <small>cómo imprime esta computadora; no cambia nada en las demás computadoras ni en la página web</small></h2>
        <div class="grid cols-2">
          <Field label="Impresora de tiquetes y facturas de esta computadora" help="Si elige una, los tiquetes, las facturas, la colilla del cierre y la gaveta de esta computadora salen por ella, sea cual sea la caja. Vacío = la de la caja"><select v-model="eq.tiquetes" :disabled="!puedeConfigurar"><option value="">— La de la caja —</option><option v-for="i in opcionesTiquetes" :key="i.id" :value="String(i.id)">{{i.nombre}}{{esPropia(i) ? ' (solo de esta computadora)' : ''}}</option></select></Field>
          <Field label="Impresora de etiquetas de esta computadora" help="Si elige una, las etiquetas salen por ella sin preguntar; al imprimir se puede elegir otra solo por esa vez. Vacío = se pregunta (o la única que haya)"><select v-model="eq.etiquetas" :disabled="!puedeConfigurar"><option value="">— Preguntar al imprimir —</option><option v-for="i in opcionesEtiquetas" :key="i.id" :value="String(i.id)">{{i.nombre}}{{esPropia(i) ? ' (solo de esta computadora)' : ''}}</option></select></Field>
        </div>
        <b class="small" style="display:block;margin-top:14px">Impresoras de la empresa: cómo está conectada cada una en esta computadora</b>
        <p class="small muted" style="margin:4px 0 0" v-if="!impsActivas.length">La empresa todavía no tiene impresoras activas.</p>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Impresora</th><th>Uso</th><th>Conexión en esta computadora</th><th>Impresora de Windows o dirección</th><th>Ajustes de etiquetas</th><th></th></tr></thead>
          <tbody><tr v-for="i in impsActivas" :key="i.id"><template v-if="eq.ajustes[String(i.id)]">
            <td><b>{{i.nombre}}</b><div class="small muted">En la configuración: {{conexionAqui(i)}}{{i.direccion ? ' · ' + i.direccion : ''}}</div></td><td>{{usoTexto(i)}}</td>
            <td><select v-model="eq.ajustes[String(i.id)].conexion" :disabled="!puedeConfigurar"><option v-for="c in CONEXIONES_AQUI" :key="c[0]" :value="c[0]">{{c[1]}}</option></select></td>
            <td><select v-if="eq.ajustes[String(i.id)].conexion==='usb'" v-model="eq.ajustes[String(i.id)].direccion" :disabled="!puedeConfigurar"><option value="">— Elija la impresora —</option><option v-for="n in windowsAqui(eq.ajustes[String(i.id)].direccion)" :key="n" :value="n">{{n}}</option></select><input v-else-if="eq.ajustes[String(i.id)].conexion==='red'" v-model.trim="eq.ajustes[String(i.id)].direccion" maxlength="120" placeholder="192.168.1.50" :disabled="!puedeConfigurar"><span v-else class="small muted">—</span></td>
            <td><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center" v-if="i.uso==='etiquetas' && i.lenguaje!=='pdf'"><span class="small">Densidad</span><input type="number" min="0" :max="i.lenguaje==='zpl' ? 30 : 15" step="1" v-model="eq.ajustes[String(i.id)].densidad" placeholder="Igual" style="width:72px" :disabled="!puedeConfigurar"><template v-if="i.lenguaje==='tspl'"><span class="small">Separación (mm)</span><input type="number" min="0" max="20" step="0.5" v-model="eq.ajustes[String(i.id)].separacion_mm" placeholder="Igual" style="width:72px" :disabled="!puedeConfigurar"></template><span class="small">Girar 180°</span><select v-model="eq.ajustes[String(i.id)].girar" :disabled="!puedeConfigurar"><option v-for="g in GIRAR_AQUI" :key="g[0]" :value="g[0]">{{g[1]}}</option></select></div><span v-else class="small muted">—</span></td>
            <td><button class="btn sm ghost" @click="probarAqui(i)" :title="i.uso==='etiquetas' ? 'Imprime una etiqueta de prueba como está conectada aquí' : 'Imprime una hoja de prueba como está conectada aquí'">Probar</button></td>
          </template></tr></tbody></table></div>
        <b class="small" style="display:block;margin-top:14px">Impresoras solo de esta computadora</b>
        <p class="small muted" style="margin:4px 0 0" v-if="!eq.propias.length">Ninguna. Agregue una si esta computadora tiene una impresora de tiquetes o de etiquetas que las demás no usan.</p>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Nombre</th><th>Uso</th><th>Conexión</th><th>Impresora de Windows o dirección</th><th>Estado</th><th></th></tr></thead>
          <tbody><tr v-for="i in eq.propias" :key="i.id" :style="i.activa===false ? 'opacity:.55' : ''"><td><b>{{i.nombre}}</b></td><td>{{usoTexto(i)}}</td><td>{{conexionAqui(i)}}</td><td class="mono small">{{i.direccion || '—'}}</td><td><span :class="i.activa===false ? 'badge' : 'badge ok'">{{i.activa===false ? 'Inactiva' : 'Activa'}}</span></td><td style="white-space:nowrap"><div class="acts"><button class="btn sm ghost" @click="probarAqui(i)">Probar</button><button class="btn sm ghost" @click="editarPropia(i)" :disabled="!puedeConfigurar">Editar</button></div></td></tr></tbody></table></div>
        <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn sm sec" @click="nuevaPropia('comprobante')" :disabled="!puedeConfigurar">+ Impresora de tiquetes solo de esta computadora</button><button class="btn sm sec" @click="nuevaPropia('etiquetas')" :disabled="!puedeConfigurar">+ Impresora de etiquetas solo de esta computadora</button><span style="flex:1"></span><button class="btn" @click="guardarEq" :disabled="guardandoEq || !puedeConfigurar">{{guardandoEq ? 'Guardando…' : 'Guardar lo de esta computadora'}}</button></div>
      </div>
      <div id="cfg-estacion" class="card" style="grid-column:1/-1" v-if="estComandas"><h2>{{estComandas.textos.titulo}} <small>{{estComandas.textos.pie}}</small></h2>
        <Toggle :modelValue="estComandas.encendida" @update:modelValue="cambiarEstacionComandas" :label="estComandas.textos.casilla"></Toggle>
        <p class="small muted" style="margin:8px 0 0">{{estComandas.textos.ayuda}}</p>
        <p class="small" style="margin:8px 0 0" v-if="estComandas.encendida && programaAnteriorEstacion">{{estComandas.textos.anterior}}</p>
      </div>
      <div id="cfg-restaurante" class="card" style="grid-column:1/-1" v-if="t.modo==='restaurante'"><h2>Restaurante: comandas, observaciones, saloneros y clave de supervisor</h2>
        <div class="grid cols-2" style="align-items:start">
          <div><b class="small">Impresora de comanda por categoría</b><p class="small muted" style="margin:2px 0 8px">Al enviar la comanda (botón Comanda o F8) cada plato sale en la impresora de su categoría; una subcategoría hereda la de su padre si no se le asigna otra, y un ítem puede fijar la suya en Inventario › ítem › Opciones avanzadas. «Sin comanda» = no se imprime (por ejemplo, bebidas de vitrina). Sin asignar nada, todo va a la primera impresora de comanda.</p>
            <div class="grid cols-2"><Field v-for="c in arbol" :key="c.id" :label="'\u00a0'.repeat(c.nivel * 3) + (c.nivel ? '↳ ' : '') + (c.icono ? c.icono + ' ' : '') + c.nombre"><select v-model="t.destinos[c.id]"><option value="">{{c.nivel ? '— Hereda de la categoría superior —' : '— Primera impresora de comanda —'}}</option><option value="none">Sin comanda</option><option v-for="i in impsComanda" :key="i.id" :value="String(i.id)">{{i.nombre}}</option><option v-if="['cocina','bar'].includes(t.destinos[c.id])" :value="t.destinos[c.id]">{{nombreImp(t.destinos[c.id])}}</option></select></Field></div>
            <p class="small muted" v-if="!arbol.length">Cree las categorías en Inventario › Categorías.</p>
          </div>
          <div>
            <Field label="Observaciones rápidas por plato (una por línea)" help="Botones del cuadro «obs.» de cada plato; vacío = lista base: sin cebolla, término medio, sin hielo…"><textarea rows="5" v-model="t.modificadores_txt" :placeholder="MODIFICADORES_BASE.join('\\n')"></textarea></Field>
            <Field label="Saloneros de esta caja (uno por línea)" help="Cada cuenta lleva su salonero; el cierre muestra ventas y propinas por salonero. Vacío = el usuario conectado"><textarea rows="4" v-model="t.saloneros_txt" placeholder="María&#10;Carlos"></textarea></Field>
          </div>
        </div>
        <div class="grid cols-3" style="margin-top:10px;align-items:start">
          <div><Field label="Clave de supervisor" :help="t.clave_supervisor ? 'Hay una clave guardada; escriba otra para cambiarla' : 'Sin clave no se pide autorización'"><input type="password" v-model="t.clave_nueva" maxlength="12" autocomplete="new-password" placeholder="4 a 12 caracteres"></Field><label class="row small" style="gap:6px;cursor:pointer" v-if="t.clave_supervisor"><input type="checkbox" v-model="t.quitar_clave"> Quitar la clave actual</label></div>
          <div style="display:flex;flex-direction:column;gap:8px;padding-top:22px"><Toggle v-model="t.clave_descuento" label="Pedir la clave para dar descuentos"></Toggle><Toggle v-model="t.clave_anular" label="Pedir la clave para quitar platos ya enviados a cocina o borrar cuentas"></Toggle></div>
          <div style="display:flex;flex-direction:column;gap:8px;padding-top:22px"><Toggle v-model="t.propina" label="Permitir propina voluntaria al cobrar (aparte del comprobante)"></Toggle><Toggle v-model="t.imprimir_comanda" label="Abrir la comanda para imprimir al enviarla"></Toggle><Field label="Numerar las comandas" help="Cada envío sale con su número, el mismo en cocina y en bar."><select v-model="t.numerar_comanda"><option v-for="x in NUMERAR_COMANDA" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></Field></div>
        </div>
        <p class="small muted" style="margin:8px 0 0">La clave no se guarda en claro. Cada autorización queda anotada en la sesión de caja (Punto de venta › Cierres de caja). Los platos se pueden dividir en cuentas aparte, en partes iguales o pasar a otra mesa con el botón Dividir.</p>
      </div>
      <div id="cfg-mesas" class="card" style="grid-column:1/-1" v-if="t.modo==='restaurante'"><h2>Plano del salón <small>arrastre cada mesa u objeto para acomodarlo como el salón real</small></h2>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:8px;align-items:center">
          <input type="number" class="inp" min="1" max="60" v-model.number="nMesas" style="width:70px"><button class="btn sm sec" @click="agregarMesasTope(nMesas)">+ Mesas</button>
          <button class="btn sm sec" @click="agregarObjeto('barra')">+ Barra</button><button class="btn sm ghost" @click="agregarObjeto('pared')">+ Pared</button><button class="btn sm ghost" @click="agregarObjeto('planta')">+ Planta</button><button class="btn sm ghost" @click="agregarObjeto('puerta')">+ Puerta</button><button class="btn sm ghost" @click="agregarObjeto('cocina')">+ Cocina / caja</button><button class="btn sm ghost" @click="agregarObjeto('texto')">+ Letrero</button>
          <button class="btn sm ghost" @click="ordenar" :disabled="!t.mesas.length">Acomodar en cuadrícula</button>
          <span style="flex:1"></span>
          <select class="inp" v-model="t.plano_aspecto" title="Proporciones del salón"><option v-for="a in ASPECTOS_PLANO" :key="a[0]" :value="a[0]">{{a[1]}}</option></select>
          <span class="seg"><button @click="zoomEd = Math.max(1, Math.round((zoomEd - 0.25) * 100) / 100)" title="Alejar">−</button><button @click="zoomEd = 1" :class="{on: zoomEd === 1}" title="Ajustar al ancho">{{Math.round(zoomEd * 100)}} %</button><button @click="zoomEd = Math.min(3, Math.round((zoomEd + 0.25) * 100) / 100)" title="Acercar">+</button></span>
        </div>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px;align-items:center"><span class="small muted">Sectores:</span>
          <span v-for="s in t.sectores" :key="s.id" class="chip" style="gap:6px"><input class="inp mini" v-model="s.nombre" maxlength="30" style="width:110px;padding:2px 6px"><span class="small muted">servicio</span><input class="inp mini" type="number" min="0" max="100" step="0.5" v-model.number="s.servicio_pct" :placeholder="String(t.servicio_pct || 0)" style="width:58px;padding:2px 6px" title="Vacío = el porcentaje de la caja; 0 = sin servicio en este sector">%<button class="btn icon" style="width:22px;height:22px" title="Quitar sector" @click="quitarSector(s)">✕</button></span>
          <input class="inp" v-model="sectorNuevo" maxlength="30" placeholder="Terraza, Salón, Barra…" style="width:170px" @keyup.enter="agregarSector"><button class="btn sm ghost" @click="agregarSector">+ Sector</button>
          <span class="small muted">Cada sector puede cobrar su propio porcentaje de servicio (por ejemplo, 0 % en la barra).</span>
        </div>
        <div class="pos-plano-wrap"><div class="pos-plano editor" ref="plano" :style="estiloPlano" @pointermove="mover" @pointerup="soltar" @pointerleave="soltar">
          <div v-for="m in t.mesas" :key="m.id" class="pos-mesa" :class="[m.forma, {sel: mesaSel===m.id, deco: m.deco || ['pared','planta','puerta','cocina','texto'].includes(m.forma)}]" :style="estiloMesa(m)" @pointerdown.prevent="iniciarArrastre(m, $event)"><span class="n">{{m.forma==='planta' ? '🌿' : m.forma==='puerta' ? '🚪' : ''}}{{m.forma==='planta' ? '' : m.nombre}}</span><span class="s" v-if="!(m.deco || ['pared','planta','puerta','cocina','texto'].includes(m.forma))">{{m.asientos}} 🪑<span v-if="m.sector_id"> · {{nombreSector(m.sector_id)}}</span></span></div>
          <div class="muted small" v-if="!t.mesas.length" style="position:absolute;inset:0;display:grid;place-items:center">Agregue mesas con el botón de arriba</div>
        </div></div>
        <p class="small muted" style="margin:6px 0 0">{{soloMesas.length}} mesa(s). Toque una mesa u objeto para cambiarle el nombre, la forma, el tamaño, el giro, el sector o los asientos. Las paredes, plantas, puertas y letreros son decorativos: no reciben cuentas.</p>
        <div class="grid cols-4" style="margin-top:12px" v-if="mesa">
          <Field :label="mesaEsDeco ? 'Texto del objeto' : 'Nombre de la mesa'"><input v-model="mesa.nombre" maxlength="30"></Field>
          <Field label="Forma"><select :value="mesa.forma" @change="cambiarForma(mesa, $event.target.value)"><optgroup label="Mesas"><option v-for="f in FORMAS_MESA" :key="f[0]" :value="f[0]">{{f[1]}}</option></optgroup><optgroup label="Objetos decorativos"><option v-for="f in FORMAS_DECO" :key="f[0]" :value="f[0]">{{f[1]}}</option></optgroup></select></Field>
          <Field label="Sector" v-if="!mesaEsDeco"><select v-model="mesa.sector_id"><option :value="null">— Sin sector —</option><option v-for="s in t.sectores" :key="s.id" :value="s.id">{{s.nombre}}</option></select></Field>
          <Field label="Asientos (capacidad)" v-if="!mesaEsDeco"><input type="number" min="1" max="60" v-model.number="mesa.asientos"></Field>
          <Field label="Ancho (% del salón)"><input type="number" min="2" max="100" v-model.number="mesa.w"></Field>
          <Field label="Alto (% del salón)"><input type="number" min="2" max="100" v-model.number="mesa.h"></Field>
          <Field label="Giro"><div class="row" style="gap:6px"><button class="btn sm ghost" @click="girar(mesa, -15)" title="Girar a la izquierda">↺</button><input type="number" min="0" max="359" v-model.number="mesa.rot" style="flex:1;text-align:center"><button class="btn sm ghost" @click="girar(mesa, 15)" title="Girar a la derecha">↻</button></div></Field>
          <Field label="Acciones"><div class="row" style="gap:6px"><button class="btn sm ghost" @click="duplicarMesa(mesa)" title="Crear una copia al lado">Duplicar</button><button class="btn sm ghost" title="Quitar del plano" @click="quitarMesa(mesa)">🗑 Quitar</button></div></Field>
        </div>
      </div>
    </div>
    <Modal v-if="impForm" :title="impForm.solo_aqui ? (impForm.id ? 'Impresora de esta computadora' : 'Nueva impresora solo de esta computadora') : impForm.id ? 'Impresora' : 'Nueva impresora'" @close="impForm=null">
      <div class="grid cols-2">
        <Field label="Nombre" req help="Como la llama el personal: Cocina caliente, Cocina fría, Bar, Postres, Caja…"><input v-model="impForm.nombre" maxlength="40"></Field>
        <Field label="Uso" req><select v-model="impForm.uso" @change="alCambiarUso"><option v-for="u in usosForm" :key="u[0]" :value="u[0]">{{u[1]}}</option></select></Field>
        <template v-if="impForm.uso==='etiquetas'">
          <Field label="Modelo" req help="El modelo pone el lenguaje y la densidad; si el suyo no está, elija «Otra»"><select v-model="impForm.modelo" @change="alCambiarModelo"><option v-for="m in MODELOS_ETQ" :key="m.id" :value="m.id">{{m.nombre}}</option></select></Field>
          <Field label="Lenguaje de la impresora" req help="TSPL: 3nStar, TSC, Xprinter, Gprinter y casi todas las de etiquetas. ZPL: Zebra. Si no sabe cuál usa la suya, elija «Controlador de Windows (PDF)»: imprime con el controlador que se instaló con la impresora"><select v-model="impForm.lenguaje"><option v-for="l in LENGUAJES_ETQ" :key="l[0]" :value="l[0]">{{l[1]}}</option></select></Field>
        </template>
        <Field label="Conexión" req v-if="!etqPdf"><select v-model="impForm.conexion"><option v-for="u in conexionesForm" :key="u[0]" :value="u[0]">{{u[1]}}</option></select></Field>
        <Field v-if="!etqPdf" :label="impForm.conexion==='red' ? 'Dirección IP' : impForm.conexion==='usb' ? 'Nombre en Windows' : 'Dirección'" :help="impForm.conexion==='navegador' ? 'No aplica: elige la impresora al imprimir' : impForm.solo_aqui ? 'La imprime este programa.' : 'La usará el agente local del instalable'"><input v-model="impForm.direccion" maxlength="60" list="imps-windows" :placeholder="impForm.conexion==='red' ? '192.168.1.50' : impForm.conexion==='usb' ? 'EPSON TM-T20' : ''" :disabled="impForm.conexion==='navegador'"><datalist id="imps-windows" v-if="agente && agente.ok"><option v-for="n in agente.info.impresoras_windows" :key="n" :value="n"></option></datalist></Field>
        <Field label="Ancho del papel" v-if="impForm.uso!=='etiquetas'"><select v-model.number="impForm.ancho"><option :value="80">80 mm</option><option :value="58">58 mm</option></select></Field>
        <template v-if="impForm.uso==='etiquetas'">
          <Field label="Medida de la etiqueta" help="La del rollo que tiene puesto; es la que propone el cuadro de etiquetas"><select v-model="impForm.medida_sel" @change="alCambiarMedida"><option v-for="m in MEDIDAS_ETQ" :key="m[0] + 'x' + m[1]" :value="m[0] + 'x' + m[1]">{{m[0]}} × {{m[1]}} mm</option><option value="personalizada">Personalizada</option></select></Field>
          <template v-if="impForm.medida_sel==='personalizada'"><Field label="Ancho de la etiqueta (mm)"><input type="number" min="20" max="110" v-model.number="impForm.etq_ancho_mm"></Field><Field label="Alto de la etiqueta (mm)"><input type="number" min="15" max="160" v-model.number="impForm.etq_alto_mm"></Field></template>
          <Field label="Separación entre etiquetas (mm)" v-if="impForm.lenguaje==='tspl'" help="El espacio entre una etiqueta y la siguiente en el rollo: lo normal son 2 o 3 mm; 0 = papel continuo"><input type="number" min="0" max="20" step="0.5" v-model.number="impForm.separacion_mm"></Field>
          <Field label="Densidad (qué tan oscuro imprime)" v-if="impForm.lenguaje!=='pdf'" :help="impForm.lenguaje==='zpl' ? 'De 0 a 30. Vacía = la que tiene puesta la impresora' : 'De 0 a 15; lo normal es 8. Vacía = la que tiene puesta la impresora'"><input type="number" min="0" :max="impForm.lenguaje==='zpl' ? 30 : 15" step="1" v-model="impForm.densidad" placeholder="La de la impresora"></Field>
          <label class="row" v-if="impForm.lenguaje!=='pdf'" style="gap:6px;cursor:pointer;align-items:flex-start;align-self:end"><input type="checkbox" v-model="impForm.girar" style="margin-top:3px"><span>Girar la impresión 180°<br><span class="small muted">Actívela si la etiqueta sale de cabeza</span></span></label>
        </template>
        <label class="row" style="gap:6px;cursor:pointer;align-self:end;height:36px"><input type="checkbox" v-model="impForm.activa"> Activa</label>
      </div>
      <template #foot><button class="btn danger" v-if="impForm.id" @click="eliminarImp(impForm)">Eliminar</button><span style="flex:1"></span><button class="btn sec" v-if="impForm.uso==='etiquetas'" @click="probarEtiqueta(impForm)">Imprimir etiqueta de prueba</button><button class="btn ghost" @click="impForm=null">Cancelar</button><button class="btn" @click="guardarImp">Guardar</button></template>
    </Modal>
  </div>`,
};
