// 4.30: aviso para recuperar de un respaldo los productos y categorías que perdieron los extras y opcionales de FISITAAP (los borraba
// «Guardar modificadores» de Punto de venta › Configuración hasta la 4.29). Sale SOLO si el servidor encuentra algo que recuperar
// (GET /api/pos/modificadores/recuperar, que a quien no puede configurar le responde que no hay nada). «Recuperar» muestra qué grupos
// y qué se repone; «Confirmar y recuperar» lo aplica (POST, con auditoría). Lo usan Punto de venta › Configuración › Modificadores
// y FISITAAP › Extras y FISITAAP › Opcionales.
import { api, toast } from '../../api.js';

export function textoAviso(n, fecha) {
  return 'Encontramos extras y opcionales que perdieron sus productos y categorías (' + n + (n === 1 ? ' grupo' : ' grupos') + '). Podemos recuperarlos del respaldo del ' + fecha + '.';
}

export function textoGrupo(g) {
  const r = (g && g.reponer) || {}, partes = [];
  if ((r.productos || []).length) partes.push('productos: ' + ((g.productos_nombres || []).filter(Boolean).join(', ') || r.productos.length));
  if ((r.categorias || []).length) partes.push('categorías: ' + r.categorias.join(', '));
  if (r.tipo) partes.push('vuelve a mostrarse como ' + (r.tipo === 'extra' ? 'extra' : 'opcional') + ' en FISITAAP');
  if (!partes.length && r.fis) partes.push('vuelve a mostrarse en FISITAAP');
  return partes.join('; ');
}

export const AvisoRecuperarMods = {
  props: { clase: { type: String, default: 'alert info' } },
  emits: ['recuperado'],
  data() { return { p: null, viendo: false, recuperando: false }; },
  computed: { texto() { return this.p ? textoAviso(this.p.grupos.length, this.p.fecha) : ''; } },
  methods: {
    textoGrupo,
    async cargar() { try { const r = await api('/api/pos/modificadores/recuperar'); this.p = r && r.hay && (r.grupos || []).length ? r : null; } catch { this.p = null; } },
    async confirmar() {
      if (!this.p || this.recuperando) return;
      this.recuperando = true;
      try {
        const r = await api('/api/pos/modificadores/recuperar', { method: 'POST', body: { respaldo: this.p.respaldo } }), n = ((r && r.grupos) || []).length;
        toast(n === 1 ? 'Se recuperó 1 grupo' : 'Se recuperaron ' + n + ' grupos', 'ok');
        this.p = null; this.viendo = false; this.$emit('recuperado');
      } catch (e) { toast(e.message, 'err'); await this.cargar(); }
      this.recuperando = false;
    },
  },
  created() { this.cargar(); },
  template: `<div v-if="p" :class="clase" style="margin:8px 0">
    <div>{{texto}}</div>
    <div v-if="viendo" style="margin-top:6px"><div class="small">Se repone solo lo que falta; lo que estos grupos tienen hoy no se cambia.</div>
      <ul style="margin:4px 0 0 18px;padding:0"><li v-for="g in p.grupos" :key="g.id"><b>{{g.nombre}}</b>: {{textoGrupo(g)}}</li></ul></div>
    <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">
      <button v-if="!viendo" class="btn sm" type="button" @click="viendo = true">Recuperar</button>
      <button v-if="viendo" class="btn sm" type="button" :disabled="recuperando" @click="confirmar">Confirmar y recuperar</button>
      <button v-if="viendo" class="btn sm sec btn-light" type="button" @click="viendo = false">Cancelar</button>
    </div>
  </div>`,
};
