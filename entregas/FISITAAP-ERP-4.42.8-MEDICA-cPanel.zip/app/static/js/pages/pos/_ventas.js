// 4.34: la lista de «Ventas de caja» (Punto de venta): funciones puras, sin imports, para poder probarlas solas con Node.
// Las fechas se comparan por día de Costa Rica (UTC-6, sin horario de verano): v.hora se guarda en ISO con Z.
export const HORAS_CAJERO = 6, MARGEN_CAJERO_MS = 10 * 60 * 1000;   // 4.34: margen: v.hora es el reloj de la caja y el servidor compara fecha_emision                 // igual que HORAS_CAJERO de app/main.py
const MS_HORA = 3600 * 1000, UTC_CR = 6;

// Día de Costa Rica (AAAA-MM-DD) de un instante ISO; '' si no es una fecha válida
export function diaCR(iso) {
  const ms = new Date(iso).getTime();
  return isNaN(ms) ? '' : new Date(ms - UTC_CR * MS_HORA).toISOString().slice(0, 10);
}
// Desde cuándo ve ventas el cajero: lo menor entre hoy 00:00 (Costa Rica) y ahora menos 6 horas, como _desde_cajero() del servidor. Devuelve ms.
export function desdeCajeroMs(ahora) {
  const ms = (ahora instanceof Date ? ahora : new Date(ahora)).getTime();
  const [a, m, d] = diaCR(new Date(ms).toISOString()).split('-').map(Number);
  return Math.min(Date.UTC(a, m - 1, d, UTC_CR), ms - HORAS_CAJERO * MS_HORA);
}
// El estado que se muestra de una venta
export function estadoVenta(v) { return v.anulada ? 'Anulada' : v.tipo === 'hab' ? 'Cargo a habitación' : !v.doc_id ? 'Pendiente de enviar' : 'Vigente'; }
// ¿Tiene comprobante que se pueda ver o reimprimir? (la misma condición de «Ventas de esta caja» en caja.js)
export function sePuedeImprimir(v) { return !!(v && v.doc_id && !v.anulada && v.tipo !== 'hab' && !v.abono); }
// ¿La sesión es de esa caja? Las sesiones viejas pueden no traer terminal_id: se compara también por el nombre
export function esDeCaja(c, cajaId, cajaNombre) { return !cajaId ? true : c.terminal_id ? String(c.terminal_id) === String(cajaId) : String(c.caja || '') === String(cajaNombre || ''); }
// 4.34: el código de sucursal de un consecutivo de Hacienda (sus 3 primeros dígitos, app/fe/clave.py); '' si falta o no es de 20 dígitos
export function dePrefijo(consecutivo) { const t = String(consecutivo || ''); return /^\d{20}$/.test(t) ? t.slice(0, 3) : ''; }
// 4.34: ¿el usuario fijo en la sucursal «codigo» puede abrir ese comprobante? La regla del servidor (_documento_ctx con sucursales.pertenece):
// se emite con el código de la sucursal activa (o el de la empresa con «Todas») y los códigos no se repiten en la empresa, así que basta el
// prefijo. Sin codigo (sin sucursal fija) no hay límite; con codigo, un consecutivo que falta o no es de 20 dígitos no se ofrece.
export function esDeSucursal(consecutivo, codigo) { return !codigo || dePrefijo(consecutivo) === String(codigo).padStart(3, '0'); }

// Las filas de la lista. filtros: { desde, hasta (AAAA-MM-DD, día de Costa Rica), cajaId, cajaNombre, q, estado ('' | 'vigentes' | 'anuladas'), cajero (true = solo desde _desde_cajero),
// codigoSucursal (4.34: '002' si el usuario está fijo en una sucursal; null = sin sucursal fija) }.
// ayudas: { ventasDe(sesion), nombreMedio(código) }. Los abonos a cuentas por cobrar no son ventas y no salen.
// Devuelve { filas (las más recientes primero), n, total }: n y total solo cuentan lo vigente (sin anuladas ni cargos a habitación).
export function filasVentas(sesiones, filtros, ahora, ayudas) {
  const f = filtros || {}, q = String(f.q || '').trim().toLowerCase(), medio = (ayudas && ayudas.nombreMedio) || (x => String(x));
  const minimo = f.cajero ? desdeCajeroMs(ahora) : null, filas = [];
  for (const c of sesiones || []) {
    if (!esDeCaja(c, f.cajaId, f.cajaNombre)) continue;
    for (const v of ayudas.ventasDe(c) || []) {
      if (!v || v.abono || v.tipo === 'abono') continue;
      const ms = v.hora ? new Date(v.hora).getTime() : NaN;
      if (minimo !== null) { if (isNaN(ms) || ms < minimo) continue; }
      else { const dia = isNaN(ms) ? String(c.fecha || '').slice(0, 10) : diaCR(v.hora); if ((f.desde && dia < f.desde) || (f.hasta && dia > f.hasta)) continue; }
      // 4.34: usuario fijo en una sucursal: la venta con el código de otra no se muestra, no se cuenta ni se exporta (el servidor le respondería 404)
      if (f.codigoSucursal && dePrefijo(v.consecutivo) && !esDeSucursal(v.consecutivo, f.codigoSucursal)) continue;
      const estado = estadoVenta(v);
      if (f.estado === 'anuladas' && !v.anulada) continue;
      if (f.estado === 'vigentes' && v.anulada) continue;
      const cajero = String(v.usuario || c.usuario || ''), cliente = v.cliente || 'Consumidor final', mesa = v.mesa || '';
      if (q && ![v.consecutivo, cliente, mesa, cajero].some(x => String(x || '').toLowerCase().includes(q))) continue;
      const pagos = (v.medios || []).map(m => ({ medio: m.medio, nombre: medio(m.medio), monto: +m.monto || 0 })).concat(+v.fiado > 0 ? [{ medio: 'fiado', nombre: medio('fiado'), monto: +v.fiado }] : []);   // solo nombres de medios, nunca números de tarjeta
      // 4.34: el cajero solo abre lo de la ventana con 10 minutos de margen (v.hora no es fecha_emision del servidor)
      const enBorde = minimo !== null && ms < minimo + MARGEN_CAJERO_MS;
      filas.push({ key: c.id + '-' + (v.id ?? v.doc_id ?? v.consecutivo ?? filas.length), ms: isNaN(ms) ? 0 : ms, hora: v.hora || null, caja: c.caja || '', cajero, consecutivo: v.consecutivo || '', cliente, mesa,
        pagos, medios: (v.medios || []).map(m => ({ medio: m.medio, monto: +m.monto || 0 })),   // 4.34: para el tiquete COPIA por agente (solo código y monto, sin referencias de tarjeta)
        total: +v.total || 0, estado, anulada: !!v.anulada, doc_id: v.doc_id || null, imprimible: sePuedeImprimir(v) && !enBorde,
        suma: !v.anulada && v.tipo !== 'hab', recibido: v.recibido, vuelto: v.vuelto, sesion: c });
    }
  }
  filas.sort((a, b) => b.ms - a.ms);
  const suman = filas.filter(x => x.suma);
  return { filas, n: suman.length, total: Math.round(suman.reduce((s, x) => s + x.total, 0) * 100) / 100 };
}
