// Punto de venta (4.31): la misma cuenta abierta en dos equipos sin perder platos. Módulo puro, sin importar nada (se carga tal cual en
// las pruebas de Node). Es la copia en JavaScript de la regla de app/fusion_cuentas.py: las dos se prueban con los mismos casos.
//  - Cada línea lleva su identificador `lid`. Las líneas guardadas sin él reciben uno determinista (igual aquí y en el servidor).
//  - Quien guarda una cuenta que ya existía manda `_fusion` = lo que ÉL cambió (líneas nuevas, quitadas con su cantidad, campos que
//    cambió de cada línea y de la cuenta). El servidor lo aplica sobre lo guardado (unir) y nunca lo guarda. La pantalla usa la misma
//    regla para mostrar al instante lo que ya tiene en su copia.
//  - Las líneas quitadas o cobradas quedan anotadas en la cuenta (`lids_quitados`): no vuelven nunca, ni por un reenvío.
//  - Una baja de cuenta viaja con la condición de lo que se cobró o quitó (cerrar): si queda algo que agregó otro equipo, no se borra.
//  - La línea que queda de una línea partida lleva `de` (la línea de la que sale): si otro equipo ya la partió, no se agrega dos veces.
//  - 4.31 (quinta vuelta): la parte de un cobro cerrado sin cobrar que se suma a una línea (`_fusion.vuelve`) nunca desaparece, y el cobro de
//    una parte se lleva el resto que otro equipo dejó de las líneas que cerró enteras (`_fusion.enteras`).
//  - 4.31 (sexta vuelta): esa parte vuelve solo si su línea estuvo en la cuenta, y la baja de un cobro también lleva lo que la pantalla quitó
//    o bajó sin guardar (cierreDeCobro).
//  - 4.31 (séptima vuelta): y vuelve sin la marca del 2x1 (`promo_fija`): aquí no se sabe si su par se cobró; lo decide la caja.

export const CAMPOS_MARCA = ['preparando', 'listo', 'entregado', 'impreso', 'comanda'];
const MAX_LAPIDAS = 300;
// lo del pedido en línea ya aplicado al cobrar: una cuenta recreada no lo toma de lo que llega; una baja por cobro no lo deja en la cuenta
const CAMPOS_PEDIDO_COBRADO = ['canal', 'pedido_id', 'pedido_numero', 'prepago', 'cupon', 'puntos_canjeados', 'credito'];
const CAMPOS_PAGADOS = ['prepago', 'cupon', 'puntos_canjeados'];

function azar() {
  try { if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') return globalThis.crypto.randomUUID().replace(/-/g, ''); } catch { /* sigue abajo */ }
  try {
    if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
      const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b);
      return Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
    }
  } catch { /* sigue abajo */ }
  return Date.now().toString(16) + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2);
}
// este equipo (cada carga de la página): un `_fusion` que todavía no se confirmó se reconoce como propio y se acumula
export const EQUIPO = 'e' + azar().slice(0, 16);
export function nuevoLid() { return 'l' + azar(); }
// una línea que pasa a otra cuenta, vuelve de un cobro o sale como pedido nuevo: otro lid y sin `de` (no es el resto de una línea partida)
export function conLidNuevo(l) { const { de, ...x } = l || {}; x.lid = nuevoLid(); return x; }
// lo que queda en la cuenta de una línea partida: otro lid y `de` = la línea de la que sale
export function restoDe(l, cantidad) { const { de, ...x } = l || {}; x.cantidad = cantidad; x.lid = nuevoLid(); if (l && typeof l.lid === 'string' && l.lid) x.de = l.lid; return x; }

const esObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const tiene = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const copia = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const num = v => (typeof v === 'number' && Number.isFinite(v) ? v : (Number.isFinite(+v) ? +v : 0));
export const esLid = v => typeof v === 'string' && v !== '';
// texto canónico (claves ordenadas, sin los valores «undefined»): dos valores iguales dan el mismo texto aunque cambie el orden
function canon(v) {
  if (Array.isArray(v)) return '[' + v.map(x => (x === undefined ? 'null' : canon(x))).join(',') + ']';
  if (esObj(v)) return '{' + Object.keys(v).filter(k => v[k] !== undefined).sort().map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
  return v === undefined ? 'null' : JSON.stringify(v);
}
const igual = (a, b) => canon(a) === canon(b);
const sinFusion = x => { if (!esObj(x) || !tiene(x, '_fusion')) return x; const { _fusion, ...resto } = x; return resto; };

// Redondeo «mitad hacia arriba» sobre el número escrito (como Decimal(str(x)).quantize(..., ROUND_HALF_UP) en Python)
export function redondear(x, d = 2) {
  const n = Number(x); if (!Number.isFinite(n)) return 0;
  const s = String(Math.abs(n));
  if (/e/i.test(s)) { const r = Math.round(Math.abs(n) * 10 ** d) / 10 ** d; return n < 0 ? -r : r; }
  const [ent, dec = ''] = s.split('.');
  if (dec.length <= d) return n;
  const v = Number(ent + dec.slice(0, d)) + (dec.charCodeAt(d) >= 53 ? 1 : 0);
  const r = v / 10 ** d;
  return n < 0 ? -r : r;
}

// ---- 4.1 identificador de línea ----
function claveLinea(l) { const p = l.producto_id; return typeof p === 'number' && Number.isInteger(p) ? String(Math.trunc(p)) : (typeof l.detalle === 'string' ? l.detalle : ''); }
const enviadoDe = l => (l.enviado ? String(l.enviado) : '');
// Pone `lid` a las líneas que no lo tienen (determinista: 'h:<cuenta>:<producto o detalle>:<enviado>:<k>[:<d>]') y desempata los repetidos.
// Cambia la cuenta que recibe (sus líneas) y la devuelve.
export function ponerLids(cuenta) {
  if (!esObj(cuenta) || !Array.isArray(cuenta.lineas) || !cuenta.lineas.every(esObj)) return cuenta;   // dato raro: igual
  const id = cuenta.id === null || cuenta.id === undefined ? '' : String(cuenta.id), ls = cuenta.lineas;
  const existentes = new Set(ls.map(l => l.lid).filter(esLid)), usados = new Set(), cuentaK = new Map();
  const libre = base => { if (!usados.has(base) && !existentes.has(base)) return base; for (let d = 1; ; d++) { const c = base + ':' + d; if (!usados.has(c) && !existentes.has(c)) return c; } };
  for (const l of ls) {
    if (esLid(l.lid)) { if (usados.has(l.lid)) l.lid = libre(l.lid); usados.add(l.lid); continue; }
    const c = claveLinea(l), e = enviadoDe(l), kk = c + '\u0000' + e, k = cuentaK.get(kk) || 0; cuentaK.set(kk, k + 1);
    l.lid = libre('h:' + id + ':' + c + ':' + e + ':' + k); usados.add(l.lid);
  }
  return cuenta;
}
const mapa = ls => { const m = new Map(); for (const l of ls || []) if (esObj(l) && esLid(l.lid) && !m.has(l.lid)) m.set(l.lid, l); return m; };

// ---- 4.2 lo que cambió quien guarda ----
export function diferencia(base, lineas) {
  const mb = mapa(base), ml = mapa(lineas), nuevas = [], quitadas = {}, campos = {};
  for (const k of ml.keys()) if (!mb.has(k)) nuevas.push(k);
  for (const [k, b] of mb) {
    if (!ml.has(k)) { quitadas[k] = num(b.cantidad); continue; }
    const l = ml.get(k), cs = [...new Set([...Object.keys(b), ...Object.keys(l)])].filter(c => c !== 'lid' && !igual(b[c], l[c])).sort();
    if (cs.length) campos[k] = cs;
  }
  return { nuevas, quitadas, campos };
}
const fValida = f => esObj(f) && f.v === 1;
// _fusion de un guardado; se acumula con el `_fusion` que la cuenta todavía tenga de ESTE equipo (guardado propio sin confirmar).
// 4.31 (quinta vuelta), `extra` (solo la caja): `vuelve` = {lid: cantidad} la parte de un cobro cerrado sin cobrar que se sumó a esa línea
// (si la línea ya no está, esa cantidad vuelve sola); `enteras` = [lid] las líneas que el cobro de esta pantalla cerró enteras (el resto que
// otro equipo dejó al partirlas sale con lo cobrado). Sin `extra` el `_fusion` es el de siempre
export function conFusion(prev, dif, cuenta, origen, extra) {
  const d = dif || {}, f = { v: 1, equipo: EQUIPO, origen: origen || 'caja', nuevas: [...(d.nuevas || [])], quitadas: { ...(d.quitadas || {}) }, campos: copia(d.campos || {}), cuenta: [...new Set(cuenta || [])].sort() };
  const e = esObj(extra) ? extra : {}, vuelve = {}, enteras = new Set();
  const sumar = v => { if (esObj(v)) for (const [k, q] of Object.entries(v)) if (esNum(q) && q > 0) vuelve[k] = redondear((tiene(vuelve, k) ? vuelve[k] : 0) + q, 3); };
  const p = prev && prev._fusion;
  if (fValida(p) && p.equipo === EQUIPO) {
    if (p.origen === 'caja') f.origen = 'caja';   // un guardado de la caja todavía sin confirmar no pierde sus platos por una marca de cocina
    const quit = { ...(esObj(p.quitadas) ? p.quitadas : {}) };
    for (const [k, q] of Object.entries(f.quitadas)) if (!tiene(quit, k)) quit[k] = q;
    f.nuevas = [...new Set([...(Array.isArray(p.nuevas) ? p.nuevas : []), ...f.nuevas])].filter(k => !tiene(f.quitadas, k));
    f.quitadas = quit;
    const campos = copia(esObj(p.campos) ? p.campos : {});
    for (const [k, cs] of Object.entries(f.campos)) campos[k] = [...new Set([...(Array.isArray(campos[k]) ? campos[k] : []), ...cs])].sort();
    f.campos = campos;
    f.cuenta = [...new Set([...(Array.isArray(p.cuenta) ? p.cuenta : []), ...f.cuenta])].sort();
    sumar(p.vuelve); for (const k of Array.isArray(p.enteras) ? p.enteras : []) if (esLid(k)) enteras.add(k);
  }
  sumar(e.vuelve); for (const k of Array.isArray(e.enteras) ? e.enteras : []) if (esLid(k)) enteras.add(k);
  if (Object.keys(vuelve).length) f.vuelve = vuelve;
  if (enteras.size) f.enteras = [...enteras].sort();
  return f;
}
// y = fn(x) con su `_fusion`: las líneas que cambió y los campos de la cuenta que cambió (sin lineas, actualizado ni _fusion)
export function conFusionDe(x, y, origen, extra) {
  if (!esObj(x) || !esObj(y)) return y;
  ponerLids(x); ponerLids(y);
  const dif = diferencia(Array.isArray(x.lineas) ? x.lineas : [], Array.isArray(y.lineas) ? y.lineas : []);
  const cuenta = [...new Set([...Object.keys(x), ...Object.keys(y)])].filter(k => k !== 'lineas' && k !== 'actualizado' && k !== '_fusion' && !igual(x[k], y[k]));
  return { ...y, _fusion: conFusion(x, dif, cuenta, origen, extra) };
}

// ---- 4.6 total desde el `importe` de cada línea (null si alguna no lo tiene al día) ----
function mismoValor(a, b) { return (a === undefined ? null : a) === (b === undefined ? null : b); }
function totalDeImportes(lineas) {
  let s = 0;
  for (const l of lineas) {
    const de = l.importe_de;
    if (typeof l.importe !== 'number' || !Number.isFinite(l.importe) || !Array.isArray(de) || de.length !== 4) return null;
    if (![l.cantidad, l.precio_unitario, l.descuento_pct, l.descuento].every((v, i) => mismoValor(de[i], v))) return null;
    s += l.importe;
  }
  return redondear(s, 2);
}

// Dato que no se puede unir con la regla (líneas que no son una lista de objetos, cantidades que no son números, `_fusion` con tipos
// raros): se hace lo de antes (paso 0). Las mismas comprobaciones que app/fusion_cuentas.py.
class Raro extends Error {}
const ORIGENES = ['caja', 'cocina', 'servidor'];
const esNum = v => typeof v === 'number' && Number.isFinite(v);
// cantidad como número (como el +x de la pantalla); sin valor: 0; texto que no es número: dato raro
function numR(v) {
  if (v === null || v === undefined) return 0;
  if (esNum(v)) return v;
  if (typeof v === 'string') { const s = v.trim(); if (!s) return 0; if (!/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) throw new Raro('cantidad'); const x = Number(s); if (!Number.isFinite(x)) throw new Raro('cantidad'); return x; }
  throw new Raro('cantidad');
}
// copia de las líneas de la cuenta, cada una con su lid; Raro si las líneas no son una lista de objetos
function lineasConLid(cuenta) {
  const ls = cuenta.lineas === null || cuenta.lineas === undefined ? [] : cuenta.lineas;
  if (!Array.isArray(ls) || !ls.every(esObj)) throw new Raro('lineas');
  return ponerLids(copia({ id: cuenta.id, lineas: ls })).lineas;
}
// valor «vacío» como lo lee Python (`x or {}`): sin valor, false, 0, '' y también la lista o el objeto vacíos (de cualquier tipo)
const oVacio = (v, d) => (v === null || v === undefined || v === false || v === 0 || v === '' || (Array.isArray(v) && !v.length) || (esObj(v) && !Object.keys(v).length) ? d : v);
function leerFusion(x) {
  const f = x._fusion;
  if (!ORIGENES.includes(f.origen)) throw new Raro('origen');
  const nuevas = oVacio(f.nuevas, []), quitadas = oVacio(f.quitadas, {}), campos = oVacio(f.campos, {}), cuenta = oVacio(f.cuenta, []);
  if (!Array.isArray(nuevas) || !nuevas.every(i => typeof i === 'string')) throw new Raro('nuevas');
  if (!esObj(quitadas) || !Object.values(quitadas).every(esNum)) throw new Raro('quitadas');
  if (!esObj(campos) || !Object.values(campos).every(c => Array.isArray(c) && c.every(k => typeof k === 'string'))) throw new Raro('campos');
  if (!Array.isArray(cuenta) || !cuenta.every(k => typeof k === 'string')) throw new Raro('cuenta');
  const vuelve = oVacio(f.vuelve, {}), enteras = oVacio(f.enteras, []);   /* 4.31 (quinta vuelta) */
  if (!esObj(vuelve) || !Object.values(vuelve).every(esNum)) throw new Raro('vuelve');
  if (!Array.isArray(enteras) || !enteras.every(k => typeof k === 'string')) throw new Raro('enteras');
  return { origen: f.origen, nuevas: new Set(nuevas), quitadas, campos, cuenta: new Set(cuenta), vuelve, enteras: new Set(enteras) };
}
const fusionEsValida = x => esObj(x) && fValida(x._fusion);
function lapidasDe(c) { return Array.isArray(c.lids_quitados) ? c.lids_quitados.filter(i => typeof i === 'string') : []; }
// lo que queda de una línea cobrada o quitada con menos cantidad de la que tenía guardada (D-6): lid~n (el primero libre), o null
function hacerResto(g, q, ocupados) {
  const cant = numR(g.cantidad);
  if (!(cant - q > 0.0005)) return null;
  let n = 1; while (ocupados.has(g.lid + '~' + n)) n++;
  const lid = g.lid + '~' + n; ocupados.add(lid);
  return { ...g, lid, cantidad: redondear(cant - q, 3) };
}
const va = l => !tiene(l, 'cantidad') || l.cantidad === null || l.cantidad === undefined || numR(l.cantidad) > 0;   // cantidad cero o menos: no va
// lo que quedó de partir otra línea (`de`) que otro equipo ya partió, cobró o quitó antes de este guardado: no se agrega otra vez
const restoAjeno = (l, lap0, gLids) => esLid(l.de) && lap0.has(l.de) && !gLids.has(l.de);
const cobradas = p => (esObj(p) ? numR(p.cobradas) : 0);
// 4.31 (quinta vuelta): lo que vuelve solo de la parte que se sumó a una línea que ya no llegó a la cuenta (otro equipo la cobró, la partió o
// la quitó antes): una línea nueva `<lid>+v` con esa cantidad, sin `de` y sin importe (el total lo rehace la pantalla). `tuvo`: los lid que
// la cuenta tenía o tuvo (un reenvío no la agrega dos veces); null en una cuenta recreada. Cambia `out`
// 4.31 (sexta vuelta): vuelve solo si esa línea estuvo en la cuenta (si no, era el resto que no se aceptó porque otro equipo partió los mismos
// platos a la vez: esa parte ya está en la del otro y se cobraba dos veces); en la recreada, no la de un resto de lo cerrado (`salta`).
// 4.31 (séptima vuelta): sin la marca del 2x1 (`promo_fija`): aquí no se sabe si su par se cobró o se quitó. Lo decide la caja (solo con el
// cobro confirmado por el servidor la parte vuelve marcada, y no a una línea ya cobrada); esta línea la caja la calcula como cualquier otra
function lasQueVuelven(f, nPor, out, tuvo, salta) {
  const enOut = new Set(out.map(l => l.lid));
  for (const lid of Object.keys(f.vuelve).sort()) {
    const q = f.vuelve[lid], y = nPor.get(lid), lv = lid + '+v';
    if (!y || tiene(f.quitadas, lid) || !(q > 0.0005) || enOut.has(lid) || enOut.has(lv) || (salta && salta.has(lid))) continue;
    if (tuvo && (!tuvo.has(lid) || tuvo.has(lv))) continue;
    const { de, importe, importe_de, promo_fija, ...z } = y, c = redondear(q, 3);
    out.push({ ...z, lid: lv, cantidad: c }); enOut.add(lv);
  }
}
function unirCobros(g, n) {
  const gl = Array.isArray(g) ? g : [];
  if (!Array.isArray(n)) return [...gl];
  const clave = c => (esObj(c) ? (c.doc_id !== null && c.doc_id !== undefined && c.doc_id !== '' ? 'd:' + String(c.doc_id) : c.consecutivo !== null && c.consecutivo !== undefined && c.consecutivo !== '' ? 'c:' + String(c.consecutivo) : null) : null);
  const out = [...gl], claves = new Set(gl.map(clave).filter(k => k !== null));
  for (const c of n) { const k = clave(c); if (k === null) { if (!out.some(x => igual(x, c))) out.push(c); } else if (!claves.has(k)) { out.push(c); claves.add(k); } }
  return out;
}
const OCULTOS = ['lids_quitados', 'recreada_de'];
const visible = c => { const o = {}; for (const k of Object.keys(c)) if (!OCULTOS.includes(k) && k !== '_fusion') o[k] = c[k]; return o; };

// 4.3 paso 0: sin `_fusion` válido o con datos raros, lo de antes (gana nueva), conservando los dos campos ocultos de la cuenta guardada
// y anotando como quitadas las líneas guardadas que ya no vienen (D-9)
function paso0(guardada, nueva) {
  const res = copia(sinFusion(nueva));
  if (!esObj(guardada)) return res;
  if (!tiene(res, 'recreada_de') && tiene(guardada, 'recreada_de')) res.recreada_de = copia(guardada.recreada_de);
  const lap = lapidasDe(guardada);
  for (const i of lapidasDe(res)) if (!lap.includes(i)) lap.push(i);
  try {
    const vienen = new Set(lineasConLid(nueva).map(l => l.lid));
    for (const l of lineasConLid(guardada)) if (!vienen.has(l.lid) && !lap.includes(l.lid)) lap.push(l.lid);
  } catch (e) { if (!(e instanceof Raro)) throw e; }
  if (lap.length || tiene(guardada, 'lids_quitados') || tiene(res, 'lids_quitados')) res.lids_quitados = lap.slice(-MAX_LAPIDAS);
  return res;
}

// 4.3: une lo que llega (nueva, con su _fusion) con lo guardado. Devuelve [resultado, fusiono]; fusiono = lo que queda es distinto de lo
// que llegó (sin contar `_fusion`, los lid puestos ni los dos campos ocultos). Nunca lanza.
export function unir(guardada, nueva) {
  if (!esObj(nueva)) return [nueva, false];
  try {
    if (!esObj(guardada) || !fusionEsValida(nueva)) return [paso0(guardada, nueva), false];
    return unirValido(guardada, nueva);
  } catch {
    try { return [paso0(guardada, nueva), false]; } catch { return [copia(sinFusion(nueva)), false]; }
  }
}
function unirValido(g, n) {
  const f = leerFusion(n), caja = f.origen === 'caja';
  const gl = lineasConLid(g), nl = lineasConLid(n), lap = lapidasDe(g), lapSet = new Set(lap), lap0 = new Set(lap);   /* lap0: las quitadas ANTES de este guardado */
  const nPor = new Map(nl.map(l => [l.lid, l])), gLids = new Set(gl.map(l => l.lid)), ocupados = new Set([...gLids, ...nPor.keys(), ...lap]);
  let out = [];
  for (const x of gl) {                                       // paso 2: en el orden de lo guardado
    const lid = x.lid;
    if (tiene(f.quitadas, lid)) {
      if (!lapSet.has(lid)) { lap.push(lid); lapSet.add(lid); }
      if (caja) { const r = hacerResto(x, f.quitadas[lid], ocupados); if (r) out.push(r); }
      continue;
    }
    const y = nPor.get(lid);
    if (!y) { out.push(x); continue; }                         // la agregó otro equipo, o este no la conocía
    if (caja && f.nuevas.has(lid)) { const z = { ...y }; for (const k of CAMPOS_MARCA) if (x[k] && !z[k]) z[k] = x[k]; out.push(z); continue; }   // reenvío de un plato propio
    const z = { ...x };
    for (const c of (f.campos[lid] || [])) {
      if (c === 'lid' || (!caja && !CAMPOS_MARCA.includes(c))) continue;
      if (tiene(y, c)) z[c] = y[c]; else delete z[c];
    }
    out.push(z);
  }
  if (caja) for (const l of nl) if (!gLids.has(l.lid) && f.nuevas.has(l.lid) && !lapSet.has(l.lid) && !restoAjeno(l, lap0, gLids)) out.push(l);   /* paso 3 */
  /* 4.31 (quinta vuelta): el resto (`de`) de una línea que el cobro de esta pantalla cerró entera es parte de lo cobrado: sale (lo haya
     dejado otro equipo o venga en este guardado) y queda como quitado, así un reenvío da lo mismo */
  if (caja && f.enteras.size) out = out.filter(l => { if (!esLid(l.de) || !f.enteras.has(l.de)) return true; if (!lapSet.has(l.lid)) { lap.push(l.lid); lapSet.add(l.lid); } return false; });
  out = out.filter(va);                                       // paso 4
  if (caja) lasQueVuelven(f, nPor, out, new Set([...gLids, ...lapSet]));   /* 4.31 (quinta vuelta): después del paso 4 (una línea en cero no la tapa) */
  const res = {}, recreada = tiene(g, 'recreada_de');         /* paso 5: campos de la cuenta */
  for (const k of [...Object.keys(g), ...Object.keys(n).filter(k => !tiene(g, k))]) {
    if (k === '_fusion' || k === 'lineas' || k === 'lids_quitados' || k === 'recreada_de' || k === 'total') continue;
    if (recreada && CAMPOS_PEDIDO_COBRADO.includes(k) && !tiene(g, k)) continue;   /* la recreada no hereda lo pagado ni el enlace de la ya cobrada */
    if (k === 'cobros') res[k] = tiene(g, k) ? unirCobros(g[k], n[k]) : n[k];
    else if (k === 'partes') {
      if (!tiene(g, k)) res[k] = n[k];
      else if (f.cuenta.has('partes')) {
        const p = tiene(n, 'partes') ? n.partes : null, gp = g.partes;
        if ((p === null || p === undefined) && cobradas(gp) > 0) res[k] = gp;
        else if (esObj(p) && esObj(gp) && (tiene(p, 'cobradas') || tiene(gp, 'cobradas'))) res[k] = { ...p, cobradas: Math.max(cobradas(p), cobradas(gp)) };
        else res[k] = p === undefined ? null : p;
      } else res[k] = g[k];
    } else if (k === 'actualizado' || k === 'usuario') res[k] = tiene(n, k) ? n[k] : g[k];
    else if (f.cuenta.has(k)) { if (tiene(n, k)) res[k] = n[k]; }
    else if (tiene(g, k)) res[k] = g[k];
    else res[k] = n[k];
  }
  res.lineas = out;
  if (lap.length || tiene(g, 'lids_quitados')) res.lids_quitados = lap.slice(-MAX_LAPIDAS);
  if (tiene(g, 'recreada_de')) res.recreada_de = g.recreada_de;
  const t = !igual(out, nl) ? totalDeImportes(out) : null;   // 4.6: solo si la fusión cambió las líneas
  if (t !== null) res.total = t; else if (tiene(n, 'total')) res.total = n.total; else if (tiene(g, 'total')) res.total = g.total;
  const r = copia(res);
  return [r, !igual(visible(r), visible({ ...n, lineas: nl }))];
}
export function fusionarCuenta(guardada, nueva) { return unir(guardada, nueva)[0]; }

// 4.4: baja condicional. null = se borra como antes (no queda nada); si quedó algo, la cuenta con lo que quedó. Una baja por cobro tampoco
// deja el resto (`de`) de una línea que ese cobro cerró entera
export function cerrar(guardada, condicion) {
  try {
    if (!esObj(guardada) || !esObj(condicion) || condicion.v !== 1) return null;
    const quit = oVacio(condicion.quitadas, {});
    if (!esObj(quit) || !Object.values(quit).every(esNum)) return null;
    const gl = lineasConLid(guardada), lap = lapidasDe(guardada), lapSet = new Set(lap), ocupados = new Set([...gl.map(l => l.lid), ...lap]), cobro = condicion.cobro === true;
    let quedan = [];
    for (const l of gl) {
      if (!tiene(quit, l.lid)) {
        /* 4.31 (cuarta vuelta): el resto que otro equipo dejó al partir una línea que este cobro cerró entera es parte de lo cobrado */
        if (cobro && esLid(l.de) && tiene(quit, l.de)) { if (!lapSet.has(l.lid)) { lap.push(l.lid); lapSet.add(l.lid); } continue; }
        quedan.push(l); continue;
      }
      if (!lapSet.has(l.lid)) { lap.push(l.lid); lapSet.add(l.lid); }
      const r = hacerResto(l, quit[l.lid], ocupados); if (r) quedan.push(r);
    }
    quedan = quedan.filter(va);
    if (!quedan.length) return null;
    const res = { ...sinFusion(guardada), lineas: quedan };
    if (cobro) for (const k of CAMPOS_PAGADOS) if (tiene(res, k)) res[k] = k === 'puntos_canjeados' ? 0 : null;   /* baja por un cobro: lo ya pagado no se cobra ni se registra otra vez (vacío, no borrado: un guardado atrasado no lo vuelve a poner) */
    if (lap.length || tiene(guardada, 'lids_quitados')) res.lids_quitados = lap.slice(-MAX_LAPIDAS);
    const t = totalDeImportes(quedan); if (t !== null) res.total = t;
    return copia(res);
  } catch { return null; }
}
export function cerrarCuenta(guardada, condicion) { return cerrar(guardada, condicion); }

// 4.5: guardado de la caja que llega a una cuenta ya cerrada: lo que ese equipo agregó queda en una cuenta nueva de la misma mesa
// (null = no corresponde: otro origen, nada agregado o dato raro)
const CAMPOS_RECREADA = ['nombre', 'mesa_id', 'mesas_ids', 'terminal_id', 'salonero', 'servicio', 'servicio_pct', 'cliente_id', 'nota'];
export function recrear(nueva, idViejo, idNuevo) {
  try {
    if (!esObj(nueva) || !fusionEsValida(nueva)) return null;
    const f = leerFusion(nueva);
    if (f.origen !== 'caja') return null;
    // 4.31 (tercera vuelta): el resto de una línea partida (`de`) cuya línea de origen esta pantalla tenía guardada (la quita en este
    // guardado) era de la cuenta ya cobrada o cerrada: no pasa a la nueva (se cobraba dos veces) y queda como quitado
    // 4.31 (quinta vuelta): también el de una línea que el cobro de esta pantalla cerró entera (`enteras`); y la parte de un cobro cerrado sin
    // cobrar que se sumó a una línea de la cuenta cerrada (`vuelve`) pasa sola a la nueva
    const nl = lineasConLid(nueva), restoDeCerrada = new Set(nl.filter(l => esLid(l.de) && (tiene(f.quitadas, l.de) || f.enteras.has(l.de))).map(l => l.lid));
    const lineas = nl.filter(l => f.nuevas.has(l.lid) && va(l) && !restoDeCerrada.has(l.lid));
    lasQueVuelven(f, new Map(nl.map(l => [l.lid, l])), lineas, null, restoDeCerrada);
    if (!lineas.length) return null;
    const res = { id: idNuevo };
    for (const k of CAMPOS_RECREADA) if (tiene(nueva, k)) res[k] = nueva[k];
    Object.assign(res, { lineas, cobros: [], partes: null, recreada_de: idViejo });
    const quitados = nl.filter(l => !f.nuevas.has(l.lid) || restoDeCerrada.has(l.lid)).map(l => l.lid).slice(-MAX_LAPIDAS);
    if (quitados.length) res.lids_quitados = quitados;
    const t = totalDeImportes(lineas); if (t !== null) res.total = t;
    return copia(res);
  } catch { return null; }
}
export function recrearCuenta(nueva, idViejo, idNuevo) { return recrear(nueva, idViejo, idNuevo); }
export function esRecreadaDe(datos, id) { return esObj(datos) && typeof datos.recreada_de === 'number' && typeof id === 'number' && datos.recreada_de === id; }

// condición de una baja: {v: 1, quitadas: {lid: cantidad}} con las líneas que la pantalla cobró, quitó o pasó; `cobro` si la baja viene de
// un cobro (la cuenta que se conserve no lleva lo ya pagado del pedido en línea)
export function condicionDe(id, lineas, cobro) {
  const c = ponerLids({ id, lineas: (Array.isArray(lineas) ? lineas : []).filter(esObj).map(l => ({ ...l })) }), quitadas = {};
  for (const l of c.lineas) if (!tiene(quitadas, l.lid)) quitadas[l.lid] = num(l.cantidad);
  return cobro === true ? { v: 1, quitadas, cobro: true } : { v: 1, quitadas };
}
// 4.31 (sexta vuelta): lo que cierra la baja del cobro de una cuenta: lo cobrado (lineas) y lo que esta pantalla quitó o bajó de lo que sabía
// guardado (base: sus líneas; quitadas: las de un guardado suyo todavía sin confirmar), con la cantidad mayor de cada línea. Si no, el
// servidor dejaba en la mesa el plato devuelto como si otro equipo lo hubiera agregado. Lo que otro equipo agregó es otra línea: queda
export function cierreDeCobro(base, lineas, quitadas) {
  const q = new Map(), poner = (lid, c) => { if (esLid(lid)) q.set(lid, Math.max(q.has(lid) ? q.get(lid) : 0, num(c))); };
  for (const l of Array.isArray(lineas) ? lineas : []) if (esObj(l)) poner(l.lid, l.cantidad);
  for (const l of Array.isArray(base) ? base : []) if (esObj(l)) poner(l.lid, l.cantidad);
  if (esObj(quitadas)) for (const [lid, c] of Object.entries(quitadas)) poner(lid, c);
  return [...q].map(([lid, cantidad]) => ({ lid, cantidad }));
}

// ---- ayudas de la pantalla de caja ----
// lo último que la pantalla sabe que está guardado para ESA cuenta
export function tomarBaseDe(v, existia = true) {
  const c = ponerLids(copia({ ...sinFusion(v || {}), lineas: (v && Array.isArray(v.lineas)) ? v.lineas : [] }));
  const { lineas, ...cuenta } = c;
  return { id: v ? v.id : null, lineas, cuenta, existia: !!existia };
}
export function baseDeCuenta(base, id, prev) { return base && id !== null && id !== undefined && base.id === id ? base : (prev ? tomarBaseDe(prev) : null); }
export function lidsDeBase(base, id) { return new Set(base && id !== null && id !== undefined && base.id === id ? (base.lineas || []).map(l => l.lid) : []); }
// Líneas de la pantalla sin `lid`: una ya enviada que es la misma de la cuenta guardada (su lid determinista está en prev) toma ese; las
// demás son nuevas de esta pantalla y reciben uno al azar
export function lidsPantalla(lineas, prev) {
  const sin = (lineas || []).filter(l => esObj(l) && !esLid(l.lid)); if (!sin.length) return lineas;
  const enPrev = new Set(esObj(prev) && Array.isArray(prev.lineas) ? prev.lineas.filter(esObj).map(l => l.lid).filter(esLid) : []);
  const usados = new Set((lineas || []).filter(esObj).map(l => l.lid).filter(esLid));
  const det = ponerLids({ id: esObj(prev) ? prev.id : null, lineas: sin.map(l => ({ ...l, lid: undefined })) }).lineas;
  sin.forEach((l, i) => { const d = det[i].lid; l.lid = l.enviado && enPrev.has(d) && !usados.has(d) ? d : nuevoLid(); usados.add(l.lid); });
  return lineas;
}
// pone en `actuales` (las líneas en pantalla) las de `nuevas`, en su orden: el mismo objeto para cada lid que sigue (una ventana
// abierta sobre una línea no se rompe), las que llegan al final y sin las que salieron. Devuelve la lista nueva.
export function aplicarEnLugar(actuales, nuevas) {
  const m = mapa(actuales), usados = new Set(), out = [];
  for (const n of nuevas || []) {
    const o = esObj(n) && esLid(n.lid) && !usados.has(n.lid) ? m.get(n.lid) : null;
    if (!o) { out.push(copia(n)); continue; }
    usados.add(n.lid);
    for (const k of Object.keys(o)) if (!tiene(n, k)) delete o[k];
    Object.assign(o, copia(n)); out.push(o);
  }
  return out;
}
// platos (líneas) que llegaron y que salieron entre dos listas. 4.31 (cuarta vuelta): lo que queda de una línea partida que llega en lugar
// de esa línea (`de`) no es un plato que sale y otro que entra (otro equipo cobró una parte): no cuenta
export function contarCambio(antes, despues) {
  const a = mapa(antes), d = mapa(despues), salen = new Set([...a.keys()].filter(k => !d.has(k))), llegan = [...d.keys()].filter(k => !a.has(k));
  const restos = llegan.filter(k => esLid(d.get(k).de) && salen.has(d.get(k).de)), partidas = new Set(restos.map(k => d.get(k).de));
  return { agregadas: llegan.length - restos.length, quitadas: [...salen].filter(k => !partidas.has(k)).length };
}
