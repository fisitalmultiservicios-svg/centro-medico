import { campo, citaRuta, clientes, enviar, fechaHora, Formulario, leer, lista, operaciones, opciones, productos } from './_comun.js';
import { money, toast } from '../../api.js';
import { sesion, store } from '../../app.js';

const periodo = [
  campo('inicio','Inicio (Costa Rica)','datetime-local',{req:true}),
  campo('fin','Fin (Costa Rica)','datetime-local',{req:true}),
];
const modalidades = opciones(['presencial','telemedicina','en sitio','en calle']);
const fechaCR = new Intl.DateTimeFormat('en-CA',{timeZone:'America/Costa_Rica',year:'numeric',month:'2-digit',day:'2-digit'});
const fechaVista = new Intl.DateTimeFormat('es-CR',{weekday:'long',day:'numeric',month:'long',timeZone:'UTC'});
const vistas = [['agenda','Agenda'],['pacientes','Pacientes'],['espera','Lista de espera'],['disponibilidad','Agenda web y bloqueos']];
const estados = {programada:'Programada',confirmada:'Confirmada','llegó':'En recepción','en espera':'En espera','en consulta':'En consulta',atendida:'Atendida',cancelada:'Cancelada','no se presentó':'Ausente'};
const grupos = [
  { id:'programadas', titulo:'Por llegar', estados:['programada','confirmada'] },
  { id:'esperando', titulo:'En recepción', estados:['llegó','en espera'] },
  { id:'enconsulta', titulo:'En consulta', estados:['en consulta'] },
  { id:'atendidas', titulo:'Atendidas', estados:['atendida'] },
];


export default {
  components: { Formulario },
  mixins: [operaciones],
  data() {
    return {
      pacientes: [], citas: [], profesionales: [], convenios: [], espera: [], horarios: [], bloqueos: [],
      paciente: null, ficha: null, coberturas: [], mensajes: [], representaciones: [], cita: null, validacion: null, cargos: [],
      invitacion: null, q: '', dia: fechaCR.format(new Date()), dias: 1, filtroEstado: '', profesional: null,
      pestaña: 'agenda', lineasCargo: null, buscarPara: null, buscarCita: '', candidatos: [], vistas, grupos, estados,
      clientesAlta: false, clienteQ: '', clientesEncontrados: [], fichaTab: 'datos', citaTab: 'atencion', itemsPendientes: [],
    };
  },
  computed: {
    sede() { return sesion.sucursalActual?.nombre || 'Sede principal'; },
    tituloAgenda() { return this.dia ? fechaVista.format(new Date(this.dia+'T12:00:00Z')) : 'Agenda'; },
    citasProfesional() { return this.citas.filter(c=>!this.profesional || c.profesional_id===this.profesional); },
    resumen() { return this.grupos.map(g=>({...g,total:this.citasProfesional.filter(c=>g.estados.includes(c.estado)).length})); },
    diasAgenda() {
      const visibles = this.citasProfesional.filter(c=>!this.filtroEstado || this.grupos.find(g=>g.id===this.filtroEstado)?.estados.includes(c.estado));
      const porDia = new Map();
      for (const c of [...visibles].sort((a,b)=>a.inicio.localeCompare(b.inicio))) {
        const dia = c.inicio.slice(0,10);
        if (!porDia.has(dia)) porDia.set(dia,[]);
        porDia.get(dia).push(c);
      }
      return [...porDia.entries()];
    },
    puedeFacturar() { return sesion.puede('facturar'); },
    puedeCobrar() { return sesion.puede('cobros'); },
    portal() { return '/medica/portal/' + sesion.empresa_id; },
  },
  methods: {
    fechaHora, money,
    puedeCatalogos() { return sesion.puede('catalogos'); },
    nombreDia(dia) { return fechaVista.format(new Date(dia+'T12:00:00Z')); },
    profesionalNombre(c) { return this.profesionales.find(p=>p.id===c.profesional_id)?.nombre || 'Profesional '+c.profesional_id; },
    moverFecha(cantidad) {
      const d = new Date((this.dia || fechaCR.format(new Date()))+'T12:00:00Z');
      d.setUTCDate(d.getUTCDate()+cantidad);
      this.dia = d.toISOString().slice(0,10);
      return this.ejecutar(this.cargarAgenda);
    },
    irHoy() { this.dia=fechaCR.format(new Date());this.dias=1;return this.ejecutar(this.cargarAgenda); },
    async cargarAgenda() { this.citas = await leer('/agenda',{dia:this.dia || fechaCR.format(new Date()),dias:this.dias}); },
    async abrirSelector(tipo) {
      this.buscarPara = tipo;
      this.buscarCita = '';
      this.candidatos = [];
      await this.ejecutar(this.buscarCandidatos);
    },
    async buscarCandidatos() { this.candidatos = await leer('/pacientes',{q:this.buscarCita}); },
    elegirPaciente(p) {
      const tipo=this.buscarPara;
      this.buscarPara=null;
      if (tipo==='llegada') this.llegadaDirecta(p);
      else this.programar(p);
    },
    llegadaDirecta(p) {
      this.pedir('Recibir sin cita · '+p.nombre,[
        this.facultativo(),campo('consultorio','Consultorio','text',{req:true}),
        campo('minutos','Minutos reservados','number',{req:true,min:5,limite:180}),
      ],{minutos:30},async d=>{
        await enviar('/agenda/sin-cita',{...d,paciente_id:p.id});
        this.dia=fechaCR.format(new Date());
        this.dias=1;
        this.filtroEstado='esperando';
        this.pestaña='agenda';
        await this.cargarAgenda();
        toast('Llegada registrada','ok');
      },'Registrar llegada');
    },
    async iniciar() {
      [this.citas, this.profesionales, this.convenios] = await Promise.all([
        leer('/agenda', {dia:this.dia,dias:this.dias}), leer('/profesionales'), leer('/catalogo-convenios'),
      ]);
    },
    async cambiar(tab) {
      this.pestaña = tab;
      await this.ejecutar(async () => {
        if (tab === 'pacientes') await this.buscar();
        if (tab === 'disponibilidad') [this.horarios,this.bloqueos] = await Promise.all([leer('/agenda/web'),leer('/bloqueos')]);
        if (tab === 'espera') this.espera = await leer('/espera');
        if (tab === 'agenda') await this.iniciar();
      });
    },
    async buscar() { this.pacientes = await leer('/pacientes', {q:this.q}); },
    async abrirClientesAlta() {
      this.clienteQ='';
      this.clientesEncontrados=[];
      this.clientesAlta=true;
      await this.ejecutar(this.buscarClientesAlta);
    },
    async buscarClientesAlta() { this.clientesEncontrados=await leer('/clientes-pacientes',{q:this.clienteQ}); },
    elegirCliente(c) {
      this.pedir('Paciente · '+c.nombre,[campo('nacimiento','Fecha de nacimiento','date',{req:true})],{},async d=>{
        const p=await enviar('/pacientes/desde-cliente',{cliente_id:c.id,nacimiento:d.nacimiento});
        this.clientesAlta=false;
        if (this.buscarPara) this.elegirPaciente(p);
        else {
          this.q=p.documento;
          this.pestaña='pacientes';
          await this.buscar();
          await this.abrirPaciente(p);
        }
      },'Vincular cliente');
    },
    editarIdentificacion(p) {
      this.pedir('Datos del paciente',[
        campo('nombre','Nombre completo','text',{req:true}), campo('documento','Documento','text',{req:true,max:32}),
        campo('nacimiento','Fecha de nacimiento','date',{req:true}), campo('telefono','Teléfono','tel'),
        campo('correo','Correo','email'),
      ],p,async d=>{
        await enviar('/pacientes/'+p.id,d,'PUT');
        await this.buscar();
        await this.abrirPaciente({...p,...d});
      });
    },
    async abrirPaciente(p) {
      const [ficha,coberturas,mensajes,representaciones] = await Promise.all([
        leer('/pacientes/' + p.id + '/ficha'), leer('/pacientes/' + p.id + '/coberturas'),
        leer('/pacientes/' + p.id + '/mensajes'), leer('/pacientes/' + p.id + '/representaciones'),
      ]);
      Object.assign(this,{paciente:p,ficha,coberturas,mensajes,representaciones,invitacion:null,fichaTab:'datos'});
    },
    representar() {
      const ruta='/pacientes/'+this.paciente.id+'/representaciones';
      this.pedir('Autorizar acceso como representante',[
        campo('representado_id','Expediente de la persona representada','number',{req:true,min:1}),
        campo('vence','Vence','date',{req:true}),
        campo('referencia','Referencia de la autorización verificada','textarea',{req:true,max:300}),
      ],{},async d=>{await enviar(ruta,d);this.representaciones=await leer(ruta);},'Autorizar');
    },
    async quitarRepresentacion(r) {
      const ruta='/pacientes/'+this.paciente.id+'/representaciones';
      await enviar(ruta+'/'+r.representado_id,undefined,'DELETE');
      this.representaciones=await leer(ruta);
    },
    responder() {
      const ruta='/pacientes/'+this.paciente.id+'/mensajes';
      this.pedir('Mensaje administrativo',[campo('texto','Mensaje','textarea',{req:true,max:2000})],{},
        async d=>{await enviar(ruta,d);this.mensajes=await leer(ruta);},'Enviar');
    },
    editarFicha() {
      const documento = texto => String(texto || '').toUpperCase().replace(/[^\p{L}\p{N}]/gu,'');
      const candidatos = (store.clientes || []).filter(c=>c.activo!==false && c.tipo!=='Proveedor'
        && documento(c.numero_id)===documento(this.paciente.documento));
      const contacto = this.ficha?.cliente_id || (candidatos.length===1 ? candidatos[0].id : null);
      this.pedir('Ficha administrativa', [
        campo('tipo','Tipo de paciente','select',{req:true,opciones:opciones(['particular','asegurado','corporativo'])}),
        campo('cliente_id','Contacto fiscal del ERP','select',{opciones:clientes()}),
        campo('direccion','Dirección'), campo('emergencia','Contacto de emergencia'), campo('idioma','Idioma'),
        campo('sexo','Sexo'), campo('genero','Género'), campo('nacionalidad','Nacionalidad'), campo('estado_civil','Estado civil'),
        campo('ocupacion','Ocupación'), campo('responsable_pago','Responsable de pago'),
        campo('observacion_administrativa','Alerta administrativa'),
        campo('consentimiento_datos','Consentimiento de datos registrado','checkbox'),
        campo('consentimiento_contacto','Autorizó avisos por correo','checkbox'),
      ], {tipo:'particular',...this.ficha,cliente_id:contacto}, async d => {
        await enviar('/pacientes/' + this.paciente.id + '/ficha', d, 'PUT');
        this.ficha = await leer('/pacientes/' + this.paciente.id + '/ficha');
      });
    },
    cobertura() {
      this.pedir('Agregar póliza o cobertura', [
        campo('tipo','Tipo','select',{req:true,opciones:opciones(['asegurado','corporativo'])}),
        campo('convenio_id','Aseguradora o convenio','select',{req:true,opciones:lista(this.convenios)}),
        campo('vigencia_desde','Desde','date',{req:true}), campo('vigencia_hasta','Hasta','date',{req:true}),
        campo('poliza','Número de póliza'), campo('autorizacion','Autorización'), campo('numero_empleado','Número de empleado'),
        campo('copago','Copago (CRC)','number',{min:0,paso:.01}), campo('deducible','Deducible (CRC)','number',{min:0,paso:.01}),
        campo('max_atenciones','Límite de atenciones (0 = sin límite)','number',{min:0}), campo('servicios','Servicios'), campo('exclusiones','Exclusiones'),
      ], {tipo:'asegurado',copago:0,deducible:0,max_atenciones:0}, async d => {
        const ruta = '/pacientes/' + this.paciente.id + '/coberturas';
        await enviar(ruta,d);
        this.coberturas = await leer(ruta);
      });
    },
    asignarClave() {
      this.pedir('Asignar contraseña temporal',[campo('password','Contraseña temporal (vacío = generar)','password',{max:128})],{},
        async d=>{this.invitacion=await enviar('/pacientes/'+this.paciente.id+'/portal/clave',d);},'Asignar contraseña');
    },
    async revocarPortal() {
      await enviar('/pacientes/' + this.paciente.id + '/portal', undefined, 'DELETE');
      this.invitacion = null;
      toast('Acceso al portal revocado','ok');
    },
    facultativo(req = true) {
      return campo('profesional_id','Profesional','select',{req,opciones:lista(this.profesionales)});
    },
    programar(paciente, cita = null, esperaId = null) {
      this.paciente = null;
      const campos = [
        this.facultativo(), campo('consultorio','Consultorio','text',{req:true}), ...periodo,
        campo('modalidad','Modalidad','select',{req:true,opciones:modalidades}),
        campo('tipo_atencion','Tipo de atención','select',{req:true,opciones:opciones(['consulta','pre-empleo','periódico','reintegro','egreso','campaña'])}),
        campo('ubicacion','Ubicación de atención en sitio o calle'),
      ];
      if (cita) campos.push(campo('motivo','Motivo del cambio','text',{req:true}));
      this.pedir(cita ? 'Reprogramar cita' : 'Programar cita', campos,
        cita ? {...cita,inicio:cita.inicio.slice(0,16),fin:cita.fin.slice(0,16)} : {paciente_id:paciente.id,espera_id:esperaId,modalidad:'presencial',tipo_atencion:'consulta'},
        async d => {
          await enviar(cita ? citaRuta(cita.id) + '/reprogramar' : '/agenda',d,cita ? 'PUT' : 'POST');
          this.cita = null;
          this.dia = d.inicio.slice(0,10);
          this.filtroEstado = '';
          await this.cargarAgenda();
          this.pestaña = 'agenda';
        });
    },
    codigoLlegada() {
      this.pedir('Registrar llegada con código',[campo('codigo','Código de llegada','text',{req:true,max:24})],{},
        async d=>{await enviar('/check-in',d);this.dia=fechaCR.format(new Date());await this.cargarAgenda();toast('Llegada registrada','ok');},'Registrar llegada');
    },
    async estado(c, estado) {
      await enviar(citaRuta(c.id) + '/estado',{estado},'PUT');
      await this.cargarAgenda();
      if (this.cita?.id===c.id) this.cita=this.citas.find(x=>x.id===c.id) || {...c,estado};
    },
    async verCita(c, tab = this.cita?.id===c.id ? this.citaTab : 'atencion') {
      const [validacion,coberturas,cargos,itemsPendientes] = await Promise.all([
        leer(citaRuta(c.id)+'/cobertura'), leer('/pacientes/'+c.paciente_id+'/coberturas'),
        this.puedeFacturar ? leer(citaRuta(c.id)+'/cargos') : [],
        this.puedeFacturar ? leer(citaRuta(c.id)+'/items-pendientes') : [],
      ]);
      Object.assign(this,{cita:c,citaTab:tab,validacion,coberturas,cargos,itemsPendientes});
    },
    validar() {
      this.pedir('Validar cobertura', [
        campo('cobertura_id','Cobertura','select',{req:true,opciones:this.coberturas.map(x=>[x.id,x.tipo+' · '+(x.poliza || x.numero_empleado || x.id)])}),
        campo('estado','Resultado de la verificación','select',{req:true,opciones:opciones(['cubierta','parcial','rechazada'])}),
        campo('producto_id','Servicio del ERP','select',{opciones:productos()}),
      ], this.validacion || {estado:'cubierta'}, async d => {
        await enviar(citaRuta(this.cita.id)+'/cobertura',d,'PUT');
        await this.verCita(this.cita);
      });
    },
    editarVideo() {
      this.pedir('Telemedicina', [
        campo('enlace','Enlace HTTPS individual','url',{max:900}),
        campo('consentida','Consentimiento de telemedicina registrado','checkbox'),
      ], {}, d => enviar(citaRuta(this.cita.id)+'/video',d,'PUT'));
    },
    async recordar() {
      await enviar(citaRuta(this.cita.id)+'/recordar');
      toast('Recordatorio enviado','ok');
    },
    cargo() {
      this.pedir('Preparar cargo', [
        campo('pagador','Responsable de pago','select',{req:true,opciones:opciones(['paciente','tercero','aseguradora','empresa'])}),
        campo('cliente_id','Contacto fiscal','select',{opciones:clientes()}),
        campo('tipo','Tipo de comprobante','select',{req:true,opciones:[['01','Factura'],['04','Tiquete']]}),
        campo('mostrar_portal','Mostrar comprobante al paciente','checkbox'),
      ], {pagador:'paciente',tipo:'01'}, async d => {
        const sugeridas=this.itemsPendientes.map(o=>({orden_id:o.orden_id,producto_id:o.producto_id,cantidad:o.cantidad}));
        this.lineasCargo = { datos:d, productos:productos(), lineas:sugeridas.length?sugeridas:[{cantidad:1}] };
      }, 'Agregar ítems');
    },
    async prepararCargo() {
      const f = this.lineasCargo;
      await enviar(citaRuta(this.cita.id)+'/cargos',{...f.datos,lineas:f.lineas.map(l=>({
        ...l,precio_unitario:l.precio_unitario === '' ? null : l.precio_unitario,
        orden_id:l.orden_id || null,
      }))});
      this.lineasCargo = null;
      await this.verCita(this.cita);
    },
    emitir(c) {
      this.pedir('Emitir comprobante', [
        campo('medio_pago','Medio de pago','select',{req:true,opciones:[['01','Efectivo'],['02','Tarjeta'],['03','Cheque'],['04','Transferencia'],['06','SINPE Móvil']]}),
        campo('condicion_venta','Condición','select',{req:true,opciones:[['01','Contado'],['02','Crédito']]}),
        campo('plazo_credito','Plazo en días','number',{min:1,limite:365}),
      ], {medio_pago:'01',condicion_venta:'01'}, async d => {
        await enviar('/cargos/'+c.id+'/emitir',d);
        await this.verCita(this.cita);
      }, 'Emitir');
    },
    async cancelarCargo(c) {
      await enviar('/cargos/'+c.id+'/cancelar');
      await this.verCita(this.cita);
    },
    conciliar(c) {
      this.pedir('Conciliar pago web',[
        campo('cuenta','Cuenta de Bancos (opcional)'),
      ],{},async d=>{
        const r=await enviar('/cargos/'+c.id+'/conciliar',d);
        toast('Pago web · '+r.estado,r.estado==='conciliado'?'ok':'');
        await this.verCita(this.cita);
      },'Consultar y conciliar');
    },
    nuevoHorario() {
      this.pedir('Publicar horario web',[
        this.facultativo(), campo('consultorio','Consultorio','text',{req:true}),
        campo('especialidad','Especialidad','text',{req:true}), campo('servicio','Servicio','text',{req:true}), ...periodo,
        campo('modalidad','Modalidad','select',{req:true,opciones:opciones(['presencial','telemedicina'])}),
      ],{modalidad:'presencial'},async d=>{await enviar('/agenda/web',d);this.horarios=await leer('/agenda/web');});
    },
    nuevoBloqueo() {
      this.pedir('Bloquear horario',[
        this.facultativo(false),campo('consultorio','Consultorio'),...periodo,campo('motivo','Motivo','text',{req:true}),
      ],{},async d=>{await enviar('/bloqueos',d);this.bloqueos=await leer('/bloqueos');});
    },
    async retirar(ruta) {
      await enviar(ruta,undefined,'DELETE');
      [this.horarios,this.bloqueos] = await Promise.all([leer('/agenda/web'),leer('/bloqueos')]);
    },
    registrarEspera() {
      this.pedir('Lista de espera',[campo('servicio','Servicio','text',{req:true}),campo('preferencia','Preferencia de horario')],
        {paciente_id:this.paciente.id},async d=>{await enviar('/espera',d);toast('Paciente en lista de espera','ok');});
    },
    async cerrarEspera(r) { await enviar('/espera/'+r.id+'/cerrar'); this.espera=await leer('/espera'); },
  },
  created() { this.ejecutar(this.iniciar); },
  template: `
  <div class="page medica-workspace">
    <PageHead title="Recepción y agenda" :crumbs="[{label:'Médica'}]">
      <a class="btn sec" :href="portal" target="_blank" rel="noopener noreferrer">Abrir portal de pacientes</a>
    </PageHead>
    <nav class="medica-tabs" aria-label="Recepción">
      <button v-for="[id,titulo] in vistas" :key="id" type="button" :aria-pressed="pestaña===id"
        :disabled="ocupado" @click="cambiar(id)">{{titulo}}</button>
    </nav>
    <template v-if="pestaña==='agenda'">
      <section class="medica-banner">
        <div><p class="medica-sede">{{sede}}</p><h2>{{tituloAgenda}}</h2></div>
        <div class="medica-actions">
          <button class="btn sec" :disabled="ocupado" @click="abrirSelector('llegada')">Recibir sin cita</button>
          <button class="btn" :disabled="ocupado" @click="abrirSelector('cita')">+ Nueva cita</button>
        </div>
      </section>
      <div class="medica-stats" aria-label="Filtrar por estado">
        <button v-for="g in resumen" :key="g.id" type="button" class="medica-stat" :data-estado="g.id"
          :aria-pressed="filtroEstado===g.id" @click="filtroEstado=filtroEstado===g.id?'':g.id">
          <span>{{g.titulo}}</span><strong>{{g.total}}</strong>
        </button>
      </div>
      <section class="card medica-panel" aria-label="Agenda de la sede">
        <div class="medica-toolbar">
          <div class="medica-actions">
            <button class="btn sm sec" aria-label="Período anterior" :disabled="ocupado" @click="moverFecha(-dias)">‹</button>
            <button class="btn sm sec" :disabled="ocupado" @click="irHoy">Hoy</button>
            <button class="btn sm sec" aria-label="Período siguiente" :disabled="ocupado" @click="moverFecha(dias)">›</button>
            <input v-model="dia" type="date" aria-label="Fecha de agenda" :disabled="ocupado" @change="ejecutar(cargarAgenda)">
          </div>
          <div class="medica-actions">
            <select v-model.number="dias" aria-label="Período" :disabled="ocupado" @change="ejecutar(cargarAgenda)"><option :value="1">Día</option><option :value="7">7 días</option></select>
            <select v-model="profesional" aria-label="Filtrar por profesional"><option :value="null">Todos los profesionales</option><option v-for="p in profesionales" :key="p.id" :value="p.id">{{p.nombre}}</option></select>
            <button class="btn sm sec" :disabled="ocupado" @click="codigoLlegada">Llegada con código</button>
          </div>
        </div>
        <div v-if="!diasAgenda.length" class="medica-empty">
          <strong>{{ocupado ? 'Cargando agenda…' : 'No hay citas en esta vista'}}</strong>
          <button v-if="filtroEstado" class="btn sm sec" @click="filtroEstado=''">Ver todos los estados</button>
        </div>
        <div v-for="[fecha,filas] in diasAgenda" :key="fecha">
          <h3 class="medica-date" v-if="dias>1">{{nombreDia(fecha)}}</h3>
          <article v-for="c in filas" :key="c.id" class="medica-row">
            <div class="medica-hora"><strong>{{c.inicio.slice(11,16)}}</strong><small>{{c.fin.slice(11,16)}}</small></div>
            <div class="medica-persona"><button class="medica-link" :disabled="ocupado" @click="ejecutar(()=>verCita(c,'atencion'))">{{c.paciente}}</button><small>{{profesionalNombre(c)}} · {{c.consultorio}}</small></div>
            <span class="medica-status" :data-estado="c.estado">{{estados[c.estado] || c.estado}}</span>
            <div class="medica-actions medica-row-actions">
              <button v-if="['programada','confirmada'].includes(c.estado)" class="btn sm" :disabled="ocupado" @click="ejecutar(()=>estado(c,'llegó'))">Registrar llegada</button>
              <button v-else-if="c.estado==='llegó'" class="btn sm sec" :disabled="ocupado" @click="ejecutar(()=>estado(c,'en espera'))">Poner en espera</button>
              <button v-else-if="c.estado==='atendida' && puedeFacturar" class="btn sm" :disabled="ocupado" @click="ejecutar(()=>verCita(c,'caja'))">Abrir caja</button>
              <button class="btn sm sec" :disabled="ocupado" @click="ejecutar(()=>verCita(c,'atencion'))">Detalle</button>
            </div>
          </article>
        </div>
      </section>
    </template>
    <section v-if="pestaña==='pacientes'" class="card medica-panel">
      <div class="medica-toolbar">
        <form class="medica-search" @submit.prevent="ejecutar(buscar)">
          <input v-model="q" type="search" aria-label="Buscar pacientes" placeholder="Nombre, documento, expediente o teléfono">
          <button class="btn sec" :disabled="ocupado">Buscar</button>
        </form>
        <button type="button" class="btn" @click="abrirClientesAlta">+ Vincular cliente</button>
      </div>
      <div v-if="!pacientes.length" class="medica-empty">Sin pacientes para mostrar.</div>
      <article v-for="p in pacientes" :key="p.id" class="medica-record">
        <div class="medica-persona"><button class="medica-link" @click="ejecutar(()=>abrirPaciente(p))">{{p.nombre}}</button>
          <small>Expediente #{{p.id}} · {{p.documento}}<span v-if="p.telefono"> · {{p.telefono}}</span></small></div>
        <div class="medica-actions"><button class="btn sm sec" @click="programar(p)">Nueva cita</button><button class="btn sm sec" @click="llegadaDirecta(p)">Recibir sin cita</button></div>
      </article>
    </section>
    <section v-if="pestaña==='disponibilidad'" class="card">
      <div class="acts"><button class="btn" @click="nuevoHorario">Publicar horario</button><button class="btn sec" @click="nuevoBloqueo">Bloquear horario</button></div>
      <h2>Horarios publicados</h2>
      <ul><li v-for="h in horarios" :key="h.id">{{fechaHora(h.inicio)}} · {{h.profesional}} · {{h.servicio}} · {{h.activo?'Publicado':'Retirado'}}
        <button v-if="h.activo" class="btn sm sec" @click="ejecutar(()=>retirar('/agenda/web/'+h.id))">Retirar</button></li></ul>
      <h2>Bloqueos</h2>
      <ul><li v-for="b in bloqueos" :key="b.id">{{fechaHora(b.inicio)}} · {{b.consultorio||'Profesional'}} · {{b.motivo}}
        <button class="btn sm sec" @click="ejecutar(()=>retirar('/bloqueos/'+b.id))">Desbloquear</button></li></ul>
    </section>
    <section v-if="pestaña==='espera'" class="card">
      <h2>Solicitudes en espera</h2>
      <p v-if="!espera.length">Sin solicitudes. Puedes agregar un paciente desde su ficha.</p>
      <ul class="medica-list"><li v-for="e in espera" :key="e.id">{{e.paciente}} · {{e.servicio}} · {{e.preferencia}} · {{e.atendida?'Cerrada':'Pendiente'}}<span v-if="e.origen==='web'" class="medica-status">Portal web</span>
        <div v-if="!e.atendida" class="medica-actions">
          <button class="btn sm" @click="programar({id:e.paciente_id,nombre:e.paciente},null,e.id)">Programar cita</button>
          <button class="btn sm sec" @click="ejecutar(()=>cerrarEspera(e))">Cerrar solicitud</button>
        </div></li></ul>
    </section>
    <Modal v-if="buscarPara && !formulario && !clientesAlta" :title="buscarPara==='llegada'?'Recibir sin cita':'Nueva cita'" @close="buscarPara=null" size="lg">
      <form class="medica-search" @submit.prevent="ejecutar(buscarCandidatos)">
        <input v-model="buscarCita" type="search" aria-label="Buscar paciente para atender" placeholder="Nombre o documento">
        <button class="btn sec" :disabled="ocupado">Buscar</button>
      </form>
      <div class="medica-selector">
        <p v-if="!candidatos.length">{{ocupado?'Buscando…':'Sin coincidencias'}}</p>
        <div v-for="p in candidatos" :key="p.id" class="medica-record">
          <div class="medica-persona"><strong>{{p.nombre}}</strong><small>{{p.documento}} · Expediente #{{p.id}}</small></div>
          <button class="btn sm sec" :disabled="ocupado" @click="elegirPaciente(p)">Seleccionar</button>
        </div>
      </div>
      <template #foot><button class="btn" @click="abrirClientesAlta">+ Buscar en Clientes del ERP</button></template>
    </Modal>
    <Modal v-if="clientesAlta && !formulario" title="Vincular cliente del ERP" @close="clientesAlta=false" size="lg">
      <form class="medica-search" @submit.prevent="ejecutar(buscarClientesAlta)">
        <input v-model="clienteQ" type="search" aria-label="Buscar cliente por cédula o nombre" placeholder="Cédula o nombre del cliente">
        <button class="btn sec" :disabled="ocupado">Buscar</button>
      </form>
      <div class="medica-selector">
        <p v-if="!clientesEncontrados.length">{{ocupado ? 'Buscando…' : 'No hay clientes con ese criterio'}}</p>
        <div v-for="c in clientesEncontrados" :key="c.id" class="medica-record">
          <div class="medica-persona"><strong>{{c.nombre}}</strong><small>{{c.documento || 'Sin identificación'}}</small></div>
          <button v-if="!c.expediente_id" class="btn sm" @click="elegirCliente(c)">Vincular</button>
          <span v-else class="medica-status">Expediente #{{c.expediente_id}}</span>
        </div>
      </div>
      <template #foot><a v-if="puedeCatalogos()" class="btn sec" href="#/contactos/nuevo">Crear cliente en el ERP</a></template>
    </Modal>
    <Modal v-if="paciente && !formulario" :title="paciente.nombre" @close="paciente=null" size="lg">
      <div class="medica-modal-head"><p>Expediente #{{paciente.id}} · {{paciente.documento}}<span v-if="paciente.telefono"> · {{paciente.telefono}}</span></p>
        <button class="btn sm" @click="programar(paciente)">+ Nueva cita</button></div>
      <nav class="medica-tabs" aria-label="Ficha del paciente">
        <button v-for="[id,nombre] in [['datos','Datos'],['coberturas','Coberturas'],['mensajes','Mensajes'],['portal','Portal y familiares']]"
          :key="id" :aria-pressed="fichaTab===id" @click="fichaTab=id">{{nombre}}</button>
      </nav>
      <div v-if="fichaTab==='datos'">
        <dl class="medica-ficha"><div><dt>Correo</dt><dd>{{paciente.correo || 'Sin correo'}}</dd></div>
          <div><dt>Tipo</dt><dd>{{ficha?.tipo || 'Particular'}}</dd></div><div><dt>Contacto de emergencia</dt><dd>{{ficha?.emergencia || 'Sin registrar'}}</dd></div></dl>
        <div class="medica-actions"><button class="btn sec" v-if="!paciente.cliente_origen_id" @click="editarIdentificacion(paciente)">Editar ficha anterior</button>
          <button class="btn sec" @click="editarFicha">Contacto fiscal y consentimientos</button>
          <a v-if="paciente.cliente_origen_id && puedeCatalogos()" class="btn sec" :href="'#/contactos/'+paciente.cliente_origen_id">Abrir cliente en el ERP</a>
          <button class="btn sec" @click="registrarEspera">Agregar a lista de espera</button></div>
      </div>
      <div v-if="fichaTab==='coberturas'">
        <button class="btn" @click="cobertura">+ Agregar cobertura</button>
        <p v-if="!coberturas.length">Sin coberturas registradas.</p>
        <ul class="medica-list"><li v-for="c in coberturas" :key="c.id">{{c.tipo}} · {{c.poliza || c.numero_empleado || c.id}} · Hasta {{c.vigencia_hasta}} · Copago {{money(c.copago)}}</li></ul>
      </div>
      <div v-if="fichaTab==='mensajes'">
        <button class="btn" @click="responder">Enviar mensaje administrativo</button>
        <ul class="medica-list"><li v-for="m in mensajes" :key="m.id">{{fechaHora(m.fecha)}} · {{m.direccion}} · {{m.texto}}</li></ul>
      </div>
      <div v-if="fichaTab==='portal'">
        <h3>Acceso del paciente</h3>
        <p>Verifica la identidad antes de entregar la contraseña temporal. Asignar otra clave cierra las sesiones anteriores.</p>
        <div class="medica-actions"><button class="btn sec" @click="asignarClave">Asignar contraseña temporal</button><button class="btn sec" @click="ejecutar(revocarPortal)">Revocar acceso</button></div>
        <p v-if="invitacion">Cédula {{invitacion.cedula}} · Contraseña temporal <code>{{invitacion.password}}</code> · Vence en {{invitacion.vigencia_dias}} días.</p>
        <h3>Representación de familiares</h3>
        <ul class="medica-list"><li v-for="r in representaciones" :key="r.representado_id">{{r.nombre}} · Vence {{r.vence}} · {{r.activa?'Autorizada':'Revocada'}}
          <button v-if="r.activa" class="btn sm sec" @click="ejecutar(()=>quitarRepresentacion(r))">Revocar</button></li></ul>
        <button class="btn sec" @click="representar">Autorizar representación</button>
      </div>
    </Modal>
    <Modal v-if="cita && !formulario && !lineasCargo" :title="'Cita · '+cita.paciente" @close="cita=null" size="lg">
      <div class="medica-modal-head">
        <p>{{fechaHora(cita.inicio)}} · {{profesionalNombre(cita)}} · {{cita.consultorio}}</p>
        <span class="medica-status" :data-estado="cita.estado">{{estados[cita.estado] || cita.estado}}</span>
      </div>
      <nav class="medica-tabs" aria-label="Detalle de cita">
        <button :aria-pressed="citaTab==='atencion'" @click="citaTab='atencion'">Atención</button>
        <button :aria-pressed="citaTab==='cobertura'" @click="citaTab='cobertura'">Cobertura</button>
        <button v-if="puedeFacturar" :aria-pressed="citaTab==='caja'" @click="citaTab='caja'">Caja y facturación</button>
      </nav>
      <div v-if="citaTab==='atencion'">
        <dl class="medica-ficha"><div><dt>Modalidad</dt><dd>{{cita.modalidad}}</dd></div><div><dt>Tipo de atención</dt><dd>{{cita.tipo_atencion}}</dd></div>
          <div v-if="cita.llegada"><dt>Llegada</dt><dd>{{fechaHora(cita.llegada)}}</dd></div></dl>
        <div class="medica-actions">
          <template v-if="['programada','confirmada'].includes(cita.estado)">
            <button class="btn" @click="ejecutar(()=>estado(cita,'llegó'))">Registrar llegada</button>
            <button v-if="cita.estado==='programada'" class="btn sec" @click="ejecutar(()=>estado(cita,'confirmada'))">Confirmar</button>
            <button class="btn sec" @click="programar(null,cita)">Reprogramar</button>
            <button class="btn sec" @click="ejecutar(recordar)">Enviar recordatorio</button>
            <button class="btn sec" @click="ejecutar(()=>estado(cita,'no se presentó'))">Registrar ausencia</button>
            <button class="btn sec" @click="ejecutar(()=>estado(cita,'cancelada'))">Cancelar cita</button>
          </template>
          <button v-if="cita.estado==='llegó'" class="btn sec" @click="ejecutar(()=>estado(cita,'en espera'))">Poner en espera</button>
          <button v-if="cita.modalidad==='telemedicina'" class="btn sec" @click="editarVideo">Enlace de video</button>
        </div>
      </div>
      <div v-if="citaTab==='cobertura'">
        <p>{{validacion ? 'Cobertura '+validacion.estado : 'Cobertura sin verificar'}}</p>
        <button v-if="coberturas.length" class="btn sec" @click="validar">Validar cobertura</button>
        <p v-else>Agrega una cobertura desde la ficha del paciente.</p>
      </div>
      <div v-if="citaTab==='caja' && puedeFacturar">
        <button v-if="!['cancelada','no se presentó'].includes(cita.estado)" class="btn" @click="cargo">Preparar cargo</button>
        <a v-if="puedeCatalogos()" class="btn sec" href="#/inventario/items">Catálogo del ERP</a>
        <h3>Servicios e ítems pendientes</h3>
        <p v-if="!itemsPendientes.length">No hay órdenes con ítems pendientes de cargo.</p>
        <ul v-else class="medica-list"><li v-for="o in itemsPendientes" :key="o.orden_id">{{o.nombre}} · {{o.cantidad}} × {{money(o.precio)}}</li></ul>
      <h3 v-if="cargos.length">Cargos y comprobantes</h3>
      <ul><li v-for="c in cargos" :key="c.id">Cargo #{{c.id}} · {{c.pagador}} · {{c.cancelado?'Cancelado':(c.documento?.estado || 'Pendiente')}}
        <template v-if="c.documento">
          <a :href="'#/ventas/facturas/'+c.documento.id">{{c.documento.consecutivo}}</a>
          <span> · ₡{{c.documento.total}} · Saldo ₡{{c.documento.saldo}}</span>
          <a v-if="c.cliente_id && c.documento.saldo>0 && puedeCobrar && !c.pago_web && !c.cancelado"
            class="btn sm sec" :href="'#/ventas/pagos/nuevo?factura='+c.documento.id">Registrar cobro</a>
          <button v-if="c.pago_web && puedeCobrar" class="btn sm sec" @click="conciliar(c)">Conciliar Tilopay</button>
          <button v-if="c.reabrible && !c.cancelado" class="btn sm sec" @click="ejecutar(()=>cancelarCargo(c))">Liberar cargo corregido</button>
        </template>
        <template v-else-if="!c.cancelado"><button class="btn sm" @click="emitir(c)">Emitir</button><button class="btn sm sec" @click="ejecutar(()=>cancelarCargo(c))">Cancelar cargo</button></template>
      </li></ul>
      </div>
    </Modal>
    <Modal v-if="lineasCargo" title="Ítems del cargo" @close="lineasCargo=null" size="lg">
      <form @submit.prevent="ejecutar(prepararCargo)">
        <div v-for="(l,i) in lineasCargo.lineas" :key="i" class="grid cols-2">
          <Field label="Ítem del catálogo"><select v-model="l.producto_id" :disabled="!!l.orden_id" required><option :value="null">Seleccionar</option>
            <option v-for="[id,nombre] in lineasCargo.productos" :key="id" :value="id">{{nombre}}</option></select></Field>
          <Field label="Cantidad"><input v-model.number="l.cantidad" :readonly="!!l.orden_id" type="number" min="0.001" step="0.001" required></Field>
          <Field label="Precio pactado (opcional)"><input v-model.number="l.precio_unitario" type="number" min="0" step="0.01"></Field>
          <p v-if="l.orden_id" class="muted">De una orden de la cita</p>
          <button v-if="lineasCargo.lineas.length>1" type="button" class="btn sec" @click="lineasCargo.lineas.splice(i,1)">Quitar línea</button>
        </div>
        <div class="acts"><button type="button" class="btn sec" @click="lineasCargo.lineas.push({cantidad:1})">Agregar línea</button>
          <button class="btn" :disabled="ocupado">Guardar cargo</button></div>
      </form>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
