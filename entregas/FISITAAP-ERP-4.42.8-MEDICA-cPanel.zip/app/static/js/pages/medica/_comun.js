import { api, toast, verDocumento } from '../../api.js';
import { sesion, store } from '../../app.js';

export const raiz = '/api/medica';
export const permiso = nombre => !!sesion.usuario?.mfa_activo && (sesion.permisos || []).includes(nombre);
export const lista = usuarios => usuarios.map(u => [u.id, u.nombre]);
export const clientes = () => lista(store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'));
export const productos = () => lista(store.productos.filter(p => p.activo !== false && p.es_venta !== false && p.moneda !== 'USD'));
export const fechaHora = valor => valor ? valor.replace('T', ' ').slice(0, 16) : '—';
export const citaRuta = id => '/agenda/' + id;
export const abrirPDF = (ruta, nombre) => verDocumento(raiz + ruta, nombre);
export const tiposOrden = ['laboratorio','imágenes','farmacia','receta','referencia','certificado','incapacidad','indicaciones'];
export const opciones = nombres => nombres.map(n => [n, n]);

export function url(ruta, parametros = {}) {
  const q = new URLSearchParams();
  Object.entries(parametros).forEach(([k, v]) => { if (v !== '' && v != null) q.set(k, v); });
  return raiz + ruta + (q.size ? '?' + q : '');
}
export const leer = (ruta, params) => api(url(ruta, params));
export const enviar = (ruta, body, method = 'POST') => api(url(ruta), { method, body });

export const operaciones = {
  data() { return { ocupado: false, formulario: null }; },
  methods: {
    async ejecutar(fn) {
      if (this.ocupado) return;
      this.ocupado = true;
      try { await fn(); }
      catch (e) { toast(e.message, 'err'); }
      finally { this.ocupado = false; }
    },
    pedir(titulo, campos, datos, guardar, boton = 'Guardar') {
      this.formulario = { titulo, campos, datos: { ...datos }, guardar, boton };
    },
    async confirmar() {
      const f = this.formulario;
      if (!f) return;
      await this.ejecutar(async () => {
        const datos = { ...f.datos };
        for (const c of f.campos) {
          if (datos[c.k] === '' && (c.tipo === 'number' || c.tipo === 'select' || c.tipo === 'date')) datos[c.k] = null;
        }
        await f.guardar(datos);
        if (this.formulario === f) this.formulario = null;
      });
    },
  },
};

export function campo(k, label, tipo = 'text', extra = {}) { return { k, label, tipo, ...extra }; }

export const Formulario = {
  props: ['f', 'ocupado'],
  emits: ['confirmar', 'cerrar'],
  template: `
    <Modal v-if="f" :title="f.titulo" @close="() => !ocupado && $emit('cerrar')" size="lg">
      <form @submit.prevent="$emit('confirmar')">
        <div class="grid cols-2">
          <Field v-for="c in f.campos" :key="c.k" :label="c.label" :req="c.req">
            <textarea v-if="c.tipo==='textarea'" v-model="f.datos[c.k]" :required="c.req" :maxlength="c.max || 8000" rows="3"></textarea>
            <select v-else-if="c.tipo==='select'" v-model="f.datos[c.k]" :required="c.req">
              <option :value="null">{{c.req ? 'Seleccionar' : 'Sin asignar'}}</option>
              <option v-for="[valor,nombre] in c.opciones" :key="valor" :value="valor">{{nombre}}</option>
            </select>
            <input v-else-if="c.tipo==='checkbox'" type="checkbox" v-model="f.datos[c.k]">
            <input v-else v-model="f.datos[c.k]" :type="c.tipo" :required="c.req" :max="c.limite" :min="c.min"
              :maxlength="c.max || 160" :step="c.paso || (c.tipo==='number' ? '1' : undefined)">
          </Field>
        </div>
        <div class="acts"><button class="btn" :disabled="ocupado">{{f.boton}}</button></div>
      </form>
    </Modal>
  `,
};
