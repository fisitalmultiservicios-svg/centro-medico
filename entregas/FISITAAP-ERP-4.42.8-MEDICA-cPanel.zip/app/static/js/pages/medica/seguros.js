import { campo, enviar, fechaHora, Formulario, leer, lista, operaciones, permiso, productos } from './_comun.js';
import { money } from '../../api.js';

export default {
  components:{Formulario},
  mixins:[operaciones],
  data(){return {planes:[],aseguradoras:[],solicitudes:[],tab:'',q:''};},
  computed:{
    gestor(){return permiso('medica_gestion');},
    recepcion(){return permiso('medica_recepcion');},
    resultados(){
      const q=this.q.trim().toLowerCase();
      return this.solicitudes.filter(s=>[s.paciente,s.plan,s.estado].join(' ').toLowerCase().includes(q));
    },
  },
  methods:{
    money,fechaHora,
    async cargar(){
      if (this.tab==='planes' || this.tab==='aseguradoras') {
        [this.planes,this.aseguradoras]=await Promise.all([leer('/seguros/planes'),leer('/operacion/aseguradora')]);
      } else this.solicitudes=await leer('/seguros/solicitudes');
    },
    cambiar(tab){this.tab=tab;return this.ejecutar(this.cargar);},
    aseguradora(r=null){
      this.pedir(r?'Editar aseguradora':'Registrar aseguradora',[
        campo('nombre','Nombre','text',{req:true}),
        campo('referencia','Código o referencia','text',{max:120}),
        campo('detalle','Datos de contacto y condiciones','textarea',{max:4000}),
      ],r||{estado:'activo'},async d=>{
        await enviar('/operacion/aseguradora'+(r?'/'+r.id:''),d,r?'PUT':'POST');await this.cargar();
      });
    },
    plan(r=null){
      this.pedir(r?'Editar plan':'Nuevo plan de seguro',[
        campo('nombre','Nombre comercial','text',{req:true}),
        campo('aseguradora_id','Aseguradora','select',{req:true,opciones:lista(this.aseguradoras.filter(x=>x.estado==='activo'))}),
        campo('producto_id','Servicio y precio del catálogo ERP','select',{opciones:productos()}),
        campo('copago','Copago (CRC)','number',{min:0,paso:.01}),
        campo('deducible','Deducible (CRC)','number',{min:0,paso:.01}),
        campo('max_atenciones','Atenciones incluidas (0 = sin límite)','number',{min:0}),
        campo('descripcion','Cobertura y condiciones que verá el paciente','textarea',{max:3000}),
        campo('activa','Plan vigente','checkbox'),campo('publica','Mostrar en Recepción web','checkbox'),
      ],r||{activa:true,publica:false,copago:0,deducible:0,max_atenciones:0},async d=>{
        await enviar('/seguros/planes'+(r?'/'+r.id:''),d,r?'PUT':'POST');await this.cargar();
      });
    },
    vincular(r){
      this.pedir('Vincular póliza · '+r.paciente,[
        campo('poliza','Número de póliza emitida','text',{req:true,max:120}),
        campo('vigencia_desde','Vigente desde','date',{req:true}),
        campo('vigencia_hasta','Vigente hasta','date',{req:true}),
        campo('autorizacion','Número de autorización','text',{max:120}),
      ],{},async d=>{await enviar('/seguros/solicitudes/'+r.id+'/vincular',d);await this.cargar();},'Guardar póliza');
    },
  },
  created(){this.tab=this.gestor?'planes':'solicitudes';this.ejecutar(this.cargar);},
  template:`
  <div class="page medica-workspace">
    <PageHead title="Seguros y pólizas" :crumbs="[{label:'Médica'}]">
      <button v-if="gestor && tab==='planes' && aseguradoras.some(x=>x.estado==='activo')" class="btn" @click="plan()">+ Nuevo plan</button>
      <button v-if="gestor && tab==='aseguradoras'" class="btn" @click="aseguradora()">+ Aseguradora</button>
    </PageHead>
    <nav class="medica-tabs" aria-label="Seguros">
      <button v-if="gestor" :aria-pressed="tab==='planes'" @click="cambiar('planes')">Planes ofrecidos</button>
      <button v-if="gestor" :aria-pressed="tab==='aseguradoras'" @click="cambiar('aseguradoras')">Aseguradoras</button>
      <button v-if="recepcion" :aria-pressed="tab==='solicitudes'" @click="cambiar('solicitudes')">Solicitudes de pacientes</button>
    </nav>
    <section v-if="tab==='planes' && gestor" class="medica-tarjetas">
      <article v-for="p in planes" :key="p.id" class="card medica-area">
        <div class="medica-modal-head"><h2>{{p.nombre}}</h2><span class="medica-status">{{p.activa?(p.publica?'Publicado':'Interno'):'Inactivo'}}</span></div>
        <p>{{p.aseguradora}}</p><p>{{p.descripcion}}</p>
        <dl class="medica-ficha"><div><dt>Copago</dt><dd>{{money(p.copago)}}</dd></div>
          <div><dt>Deducible</dt><dd>{{money(p.deducible)}}</dd></div>
          <div v-if="p.precio!=null"><dt>Precio ERP</dt><dd>{{money(p.precio,p.moneda)}}</dd></div></dl>
        <button class="btn sec" @click="plan(p)">Editar plan</button>
      </article>
      <div v-if="!planes.length" class="card medica-empty">No hay planes. Registra una aseguradora para empezar.</div>
    </section>
    <section v-if="tab==='aseguradoras' && gestor" class="card medica-panel">
      <p v-if="!aseguradoras.length" class="medica-empty">No hay aseguradoras registradas.</p>
      <article v-for="r in aseguradoras" :key="r.id" class="medica-record"><div class="medica-persona">
        <strong>{{r.nombre}}</strong><small>{{r.referencia}} {{r.detalle}}</small></div>
        <button class="btn sec sm" @click="aseguradora(r)">Editar</button></article>
    </section>
    <section v-if="tab==='solicitudes' && recepcion" class="card medica-panel">
      <div class="medica-toolbar"><input v-model="q" type="search" placeholder="Paciente, plan o estado" aria-label="Filtrar solicitudes">
        <button class="btn sm sec" @click="ejecutar(cargar)">Actualizar</button></div>
      <p v-if="!resultados.length" class="medica-empty">No hay solicitudes para mostrar.</p>
      <article v-for="r in resultados" :key="r.id" class="medica-record"><div class="medica-persona">
        <strong>{{r.paciente}} · {{r.plan}}</strong><small>{{fechaHora(r.creada)}} · {{r.estado}}</small></div>
        <button v-if="r.estado==='pendiente'" class="btn sm" @click="vincular(r)">Vincular póliza emitida</button>
        <span v-else class="medica-status">Cobertura #{{r.cobertura_id}}</span></article>
    </section>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
