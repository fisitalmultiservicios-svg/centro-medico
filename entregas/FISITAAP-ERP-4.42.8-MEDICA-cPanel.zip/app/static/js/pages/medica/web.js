import { enviar, leer, operaciones } from './_comun.js';
import { toast } from '../../api.js';

const plantillas=[
  {id:'serena',nombre:'Serena',detalle:'Marfil, verde botánico y bienvenida a dos columnas.'},
  {id:'vital',nombre:'Vital',detalle:'Coral cálido, fotografía envolvente y tipografía moderna.'},
  {id:'editorial',nombre:'Editorial',detalle:'Azul tinta, portada centrada e imagen panorámica.'},
];
const bloques=[['servicios','Servicios'],['equipo','Equipo médico'],['seguros','Seguros'],['contacto','Contacto']];

export default {
  mixins:[operaciones],
  data(){return {diseno:null,foto:null,publicado:false,url:'',plantillas,bloques,tab:'apariencia'};},
  computed:{
    imagen(){return this.foto?'data:image/jpeg;base64,'+this.foto:'/img/medica-clinica.png';},
    bloqueSeleccionado(){return ['servicios','equipo'].includes(this.tab)?this.diseno?.[this.tab]:null;},
  },
  methods:{
    async cargar(){const r=await leer('/recepcion-web');Object.assign(this,r);},
    async guardar(publicar){
      const r=await enviar('/recepcion-web',{diseno:this.diseno,publicar},'PUT');
      this.publicado=r.publicado;
      this.url=r.url;
      toast(publicar?'La recepción web ya está publicada':'Borrador guardado','ok');
    },
    async retirar(){
      if(!window.confirm('¿Retirar el diseño publicado? El portal de pacientes seguirá disponible.'))return;
      await enviar('/recepcion-web/publicacion',undefined,'DELETE');this.publicado=false;
      toast('Diseño retirado','ok');
    },
    async subir(evento){
      const f=evento.target.files[0];
      if(!f)return;
      const cuerpo=new FormData();cuerpo.append('archivo',f);
      try{this.foto=(await enviar('/recepcion-web/foto',cuerpo,'PUT')).foto;}
      finally{evento.target.value='';}
    },
    async quitar(){this.foto=(await enviar('/recepcion-web/foto',undefined,'DELETE')).foto;},
    cambiarSeccion(id){
      const i=this.diseno.secciones.indexOf(id);
      if(i<0)this.diseno.secciones.push(id);else this.diseno.secciones.splice(i,1);
    },
    mover(i,direccion){
      const a=this.diseno.secciones;
      const destino=i+direccion;
      if(destino<0||destino>=a.length)return;
      [a[i],a[destino]]=[a[destino],a[i]];
    },
    nombreBloque(id){return this.bloques.find(x=>x[0]===id)?.[1];},
  },
  created(){this.ejecutar(this.cargar);},
  template:`
    <div class="page medica-workspace">
      <PageHead title="Diseño de recepción web" :crumbs="[{label:'Médica'}]">
        <a v-if="url" :href="url" target="_blank" rel="noopener noreferrer" class="btn sec">Abrir sitio</a>
      </PageHead>
      <div v-if="diseno" class="medica-editor">
        <section class="card medica-area">
          <nav class="medica-tabs" aria-label="Editor de la clínica">
            <button v-for="[id,t] in [['apariencia','Plantilla'],['portada','Portada'],['servicios','Servicios'],['equipo','Equipo'],['contacto','Contacto'],['secciones','Orden']]" :key="id" :aria-pressed="tab===id" @click="tab=id">{{t}}</button>
          </nav>
          <form id="medica-diseno" @submit.prevent="ejecutar(()=>guardar(false))">
            <div v-show="tab==='apariencia'" class="medica-editor-campos">
              <button v-for="p in plantillas" :key="p.id" type="button" class="medica-plantilla" :data-plantilla="p.id" :aria-pressed="diseno.plantilla===p.id" @click="diseno.plantilla=p.id">
                <span class="medica-muestra"></span><span><strong>{{p.nombre}}</strong><small>{{p.detalle}}</small></span>
              </button>
              <Field label="Color de acento"><div class="medica-actions"><input type="color" :value="diseno.color || '#1f6551'" @input="diseno.color=$event.target.value"><button class="btn sm sec" type="button" @click="diseno.color=''">Usar color de plantilla</button></div></Field>
            </div>
            <div v-show="tab==='portada'" class="medica-editor-campos">
              <Field label="Marca"><input maxlength="90" v-model="diseno.marca"></Field>
              <Field label="Título de portada"><input maxlength="100" v-model="diseno.titulo"></Field>
              <Field label="Presentación"><textarea maxlength="450" rows="3" v-model="diseno.introduccion"></textarea></Field>
              <Field label="Texto del botón de citas"><input maxlength="35" v-model="diseno.boton"></Field>
              <Field label="Descripción de la fotografía"><input maxlength="120" v-model="diseno.texto_foto"></Field>
              <Field label="Foto de portada (JPG, PNG o WebP, hasta 4 MB)"><input type="file" accept="image/jpeg,image/png,image/webp" @change="ejecutar(()=>subir($event))"></Field>
              <button v-if="foto" class="btn sec" type="button" @click="ejecutar(quitar)">Usar foto de plantilla</button>
            </div>
            <div v-if="bloqueSeleccionado" class="medica-editor-campos">
              <div v-for="(t,i) in bloqueSeleccionado" :key="i" class="medica-editor-tarjeta">
                <Field label="Nombre"><input maxlength="100" v-model="t.titulo"></Field>
                <Field label="Descripción"><textarea rows="2" maxlength="500" v-model="t.texto"></textarea></Field>
                <button class="btn sm sec" type="button" @click="bloqueSeleccionado.splice(i,1)">Quitar tarjeta</button>
              </div>
              <button v-if="bloqueSeleccionado.length<12" class="btn sec" type="button" @click="bloqueSeleccionado.push({titulo:'',texto:''})">+ Agregar tarjeta</button>
            </div>
            <div v-show="tab==='contacto'" class="medica-editor-campos">
              <Field label="Dirección"><input maxlength="180" v-model="diseno.direccion"></Field>
              <Field label="Teléfono"><input maxlength="40" v-model="diseno.telefono"></Field>
              <Field label="Correo"><input type="email" maxlength="120" v-model="diseno.correo"></Field>
              <Field label="Horario de atención"><textarea maxlength="200" v-model="diseno.horario"></textarea></Field>
            </div>
            <div v-show="tab==='secciones'" class="medica-editor-campos">
              <label v-for="[id,nombre] in bloques" :key="id"><input type="checkbox" :checked="diseno.secciones.includes(id)" @change="cambiarSeccion(id)"> {{nombre}}</label>
              <div v-for="(id,i) in diseno.secciones" :key="id" class="medica-record"><strong>{{nombreBloque(id)}}</strong>
                <div class="medica-actions"><button class="btn sm sec" type="button" :disabled="i===0" @click="mover(i,-1)">Subir</button>
                  <button class="btn sm sec" type="button" :disabled="i===diseno.secciones.length-1" @click="mover(i,1)">Bajar</button></div></div>
            </div>
            <div class="medica-actions"><button class="btn sec" :disabled="ocupado">Guardar borrador</button>
              <button type="button" class="btn" :disabled="ocupado" @click="ejecutar(()=>guardar(true))">Publicar sitio</button>
              <button v-if="publicado" type="button" class="btn sec" :disabled="ocupado" @click="ejecutar(retirar)">Retirar diseño</button></div>
          </form>
        </section>
        <section class="medica-preview" aria-label="Vista previa">
          <div class="medica-toolbar"><strong>Vista previa</strong><span class="medica-status">{{publicado?'Sitio publicado':'Borrador'}}</span></div>
          <div class="clinica-sitio" :data-plantilla="diseno.plantilla" :style="diseno.color?{'--clinica-acento':diseno.color}:{}">
            <header class="clinica-nav"><span class="clinica-marca">{{diseno.marca || 'Clínica'}}</span><span>Portal de pacientes</span></header>
            <div class="clinica-hero"><div class="clinica-texto"><h2>{{diseno.titulo}}</h2><p>{{diseno.introduccion}}</p><span class="clinica-cta">{{diseno.boton}}</span></div>
              <img :src="imagen" :alt="diseno.texto_foto"></div>
            <div v-for="id in diseno.secciones" :key="id" class="clinica-bloque">
              <template v-if="['servicios','equipo'].includes(id) && diseno[id].length">
                <h2>{{nombreBloque(id)}}</h2><div class="clinica-tarjetas"><article v-for="(x,i) in diseno[id]" :key="i" class="clinica-tarjeta"><h3>{{x.titulo}}</h3><p>{{x.texto}}</p></article></div>
              </template>
              <template v-if="id==='contacto' && (diseno.direccion||diseno.telefono||diseno.correo||diseno.horario)">
                <h2>Contacto</h2><article class="clinica-tarjeta"><p>{{diseno.direccion}}</p><p>{{diseno.telefono}}</p><p>{{diseno.correo}}</p><p>{{diseno.horario}}</p></article>
              </template>
              <p v-if="id==='seguros'">Aquí aparecen las pólizas publicadas desde Seguros.</p>
            </div>
          </div>
        </section>
      </div>
    </div>`,
};
