import { campo, citaRuta, enviar, fechaHora, Formulario, leer, operaciones, permiso, productos } from './_comun.js';
import { sesion } from '../../app.js';

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() { return { citas:[], dia:new Intl.DateTimeFormat('en-CA',{timeZone:'America/Costa_Rica',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()), actual:null, notas:[], consulta:null, historia:null, preadmision:null }; },
  computed: {
    enfermeria() { return permiso('medica_enfermeria'); },
    profesional() { return permiso('medica_clinica'); },
  },
  methods: {
    fechaHora,
    asignada(c) { return this.profesional && c.profesional_id === sesion.usuario?.id; },
    async cargar() { this.citas = await leer('/agenda',{dia:this.dia}); },
    async abrir(c) {
      this.actual = c;
      this.notas = await leer(citaRuta(c.id)+'/notas');
      this.consulta = null;
      this.historia = null;
      this.preadmision = this.asignada(c) ? await leer(citaRuta(c.id)+'/preadmision') : null;
      if (this.asignada(c) && c.estado==='atendida') this.consulta = await leer(citaRuta(c.id)+'/consulta');
    },
    async actualizar() {
      await this.cargar();
      const c = this.citas.find(c=>c.id===this.actual?.id);
      if (c) await this.abrir(c);
    },
    async iniciar() { await enviar(citaRuta(this.actual.id)+'/iniciar'); await this.actualizar(); },
    cerrar() {
      this.pedir('Cerrar consulta',[
        campo('motivo','Motivo de consulta','textarea',{req:true,max:4000}),
        campo('diagnostico','Diagnóstico','textarea',{req:true,max:4000}),
        campo('cie','Código CIE','text',{max:20}),
        campo('examen','Hallazgos del examen físico','textarea'),
        campo('plan','Plan y tratamiento','textarea',{req:true}),
        campo('seguimiento','Seguimiento y próxima cita','textarea'),
      ],{},async d=>{await enviar(citaRuta(this.actual.id)+'/consulta',d);await this.actualizar();},'Cerrar consulta');
    },
    signos() {
      this.pedir('Registrar signos y observaciones',[
        campo('presion','Presión arterial'), campo('pulso','Pulso','number',{min:1,limite:300}),
        campo('saturacion','Saturación O₂ (%)','number',{min:1,limite:100}),
        campo('respiraciones','Respiraciones por minuto','number',{min:1,limite:200}),
        campo('temperatura','Temperatura °C','number',{min:20,limite:50,paso:.1}),
        campo('peso','Peso (kg)','number',{min:.1,limite:500,paso:.1}),
        campo('talla','Talla (cm)','number',{min:.1,limite:250,paso:.1}),
        campo('texto','Observaciones','textarea'),
      ],{},async d=>{await enviar(citaRuta(this.actual.id)+'/enfermeria',d);await this.actualizar();});
    },
    async verHistoria() { this.historia=await leer(citaRuta(this.actual.id)+'/historia'); },
    editarHistoria() {
      this.pedir('Actualizar historia clínica',[
        campo('antecedentes','Antecedentes personales','textarea',{max:6000}),
        campo('antecedentes_familiares','Antecedentes familiares','textarea',{max:4000}),
        campo('quirurgicos','Cirugías y hospitalizaciones','textarea',{max:4000}),
        campo('habitos','Hábitos','textarea',{max:4000}),
        campo('gineco_obstetricos','Antecedentes gineco-obstétricos','textarea',{max:4000}),
        campo('tipo_sangre','Tipo de sangre','text',{max:20}),
        campo('alergias','Alergias','textarea',{max:2000}),
        campo('medicamentos','Medicamentos actuales','textarea',{max:4000}),
        campo('vacunas','Vacunas','textarea',{max:3000}),
        campo('alertas','Alertas clínicas','textarea',{max:2000}),
      ],this.historia?.perfil || {},async d=>{await enviar(citaRuta(this.actual.id)+'/historia',d);await this.verHistoria();});
    },
    adenda() {
      this.pedir('Agregar adenda',[campo('texto','Texto de la adenda','textarea',{req:true})],{},
        async d=>{await enviar(citaRuta(this.actual.id)+'/adendas',d);await this.actualizar();});
    },
    orden(tipo) {
      const campos=[
        campo('titulo','Título o nombre','text',{req:true}),
        campo('indicaciones','Indicaciones','textarea'),
      ];
      if(['receta','farmacia'].includes(tipo)) campos.push(
        campo('dosis','Dosis y vía indicada','text',{max:150}),
        campo('frecuencia','Frecuencia','text',{max:150}),
        campo('duracion','Duración','text',{max:100}),
      );
      campos.push(campo('producto_id','Ítem facturable del ERP','select',{req:tipo==='farmacia',opciones:productos()}),
        campo('cantidad','Cantidad','number',{min:.001,paso:.001}));
      this.pedir('Registrar '+tipo,campos,{tipo,cantidad:1},d=>enviar(citaRuta(this.actual.id)+'/ordenes',d),'Guardar '+tipo);
    },
    compartir(){
      this.pedir('Publicar resumen en el expediente web',[
        campo('resumen','Resumen para el paciente','textarea',{req:true,max:5000}),
        campo('indicaciones','Indicaciones de seguimiento','textarea',{max:5000}),
      ],{},d=>enviar(citaRuta(this.actual.id)+'/expediente-publicado',d,'PUT'),'Publicar resumen');
    },
    async retirarResumen(){
      if(window.confirm('¿Retirar este resumen del portal del paciente?'))
        await enviar(citaRuta(this.actual.id)+'/expediente-publicado',undefined,'DELETE');
    },
  },
  created() { this.ejecutar(this.cargar); },
  template: `
  <div class="page medica-workspace">
    <PageHead title="Atención médica" :crumbs="[{label:'Médica'}]"></PageHead>
    <section class="card medica-panel">
      <div class="medica-toolbar"><strong>Agenda de atención</strong><div class="medica-actions">
        <input v-model="dia" type="date" aria-label="Fecha de atención" @change="ejecutar(cargar)">
        <button class="btn sm sec" :disabled="ocupado" @click="ejecutar(cargar)">Actualizar</button>
      </div></div>
      <p class="medica-empty" v-if="!citas.length">Sin citas para mostrar.</p>
      <article v-for="c in [...citas].reverse()" :key="c.id" class="medica-row">
        <div class="medica-hora"><strong>{{c.inicio.slice(11,16)}}</strong></div>
        <div class="medica-persona"><strong>{{c.paciente}}</strong><small>{{c.ubicacion || c.consultorio}}</small></div>
        <span class="medica-status" :data-estado="c.estado">{{c.estado}}</span>
        <div class="medica-row-actions"><button v-if="['llegó','en espera','en consulta','atendida'].includes(c.estado) && (enfermeria || asignada(c))" class="btn sm" :disabled="ocupado" @click="ejecutar(()=>abrir(c))">{{c.estado==='atendida'?'Ver atención':'Abrir atención'}}</button></div>
      </article>
    </section>
    <Modal v-if="actual && !formulario" :title="'Atención · '+actual.paciente" @close="actual=null" size="lg">
      <p>{{actual.modalidad}} · {{actual.ubicacion || actual.consultorio}} · {{actual.estado}}</p>
      <div class="acts">
        <button v-if="enfermeria && actual.estado!=='atendida'" class="btn sec" @click="signos">Registrar signos</button>
        <template v-if="asignada(actual)">
          <button v-if="['llegó','en espera'].includes(actual.estado)" class="btn" @click="ejecutar(iniciar)">Iniciar consulta</button>
          <button v-if="actual.estado==='en consulta'" class="btn" @click="cerrar">Cerrar consulta</button>
          <button v-if="actual.estado==='atendida'" class="btn sec" @click="compartir">Publicar resumen al paciente</button>
          <button v-if="actual.estado==='atendida'" class="btn sec" @click="ejecutar(retirarResumen)">Retirar resumen publicado</button>
          <button v-if="actual.estado==='atendida'" class="btn sec" @click="adenda">Agregar adenda</button>
          <button class="btn sec" @click="ejecutar(verHistoria)">Historia clínica</button>
        </template>
      </div>
      <div v-if="asignada(actual) && ['en consulta','atendida'].includes(actual.estado)" class="medica-tarjetas medica-acciones-clinicas">
        <section class="medica-editor-tarjeta"><h3>Receta y farmacia</h3><div class="medica-actions">
          <button class="btn sm sec" @click="orden('receta')">Nueva receta</button><button class="btn sm sec" @click="orden('farmacia')">Orden de farmacia</button></div></section>
        <section class="medica-editor-tarjeta"><h3>Exámenes</h3><div class="medica-actions">
          <button class="btn sm sec" @click="orden('laboratorio')">Laboratorio</button><button class="btn sm sec" @click="orden('imágenes')">Imágenes</button></div></section>
        <section class="medica-editor-tarjeta"><h3>Referencias y documentos</h3><div class="medica-actions">
          <button class="btn sm sec" @click="orden('referencia')">Referencia</button><button class="btn sm sec" @click="orden('certificado')">Certificado</button>
          <button class="btn sm sec" @click="orden('incapacidad')">Incapacidad</button><button class="btn sm sec" @click="orden('indicaciones')">Indicaciones</button></div></section>
      </div>
      <div v-if="preadmision"><h3>Motivo enviado por el paciente</h3><p>{{preadmision.motivo}}</p></div>
      <div v-if="consulta"><h3>Consulta cerrada</h3><p>{{consulta.motivo}}</p><p>{{consulta.cie}} {{consulta.diagnostico}}</p><p v-if="consulta.examen"><b>Examen físico</b> {{consulta.examen}}</p><p>{{consulta.plan}}</p><p v-if="consulta.seguimiento"><b>Seguimiento</b> {{consulta.seguimiento}}</p></div>
      <div v-if="historia"><h3>Historia</h3><button class="btn sm sec" @click="editarHistoria">Actualizar perfil clínico</button>
        <dl><template v-for="(valor,k) in historia.perfil" :key="k"><dt>{{k}}</dt><dd>{{valor}}</dd></template></dl>
        <details v-for="c in historia.consultas" :key="c.cita_id"><summary>{{fechaHora(c.inicio)}} · {{c.motivo}}</summary><p>{{c.cie}} {{c.diagnostico}}</p><p>{{c.plan}}</p></details>
      </div>
      <h3 v-if="notas.length">Notas de atención</h3>
      <div v-for="n in notas" :key="n.id"><b>{{n.tipo}} · {{fechaHora(n.fecha)}}</b>
        <p>{{n.texto}} <span v-if="n.presion">· PA {{n.presion}}</span><span v-if="n.pulso"> · Pulso {{n.pulso}}</span>
        <span v-if="n.saturacion"> · O₂ {{n.saturacion}} %</span><span v-if="n.respiraciones"> · FR {{n.respiraciones}}/min</span><span v-if="n.temperatura"> · {{n.temperatura}} °C</span><span v-if="n.peso"> · {{n.peso}} kg</span><span v-if="n.talla"> · {{n.talla}} cm</span></p>
      </div>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
