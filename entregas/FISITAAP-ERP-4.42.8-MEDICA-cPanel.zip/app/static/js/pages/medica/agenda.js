import { api, toast } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  data() {
    return {
      citas: [], pacientes: [], profesionales: [], busqueda: '', dia: '',
      paciente: null, cita: null, consulta: null, guardando: false,
    };
  },
  computed: {
    recepcion() { return sesion.permisos.includes('medica_recepcion'); },
    clinica() { return sesion.permisos.includes('medica_clinica'); },
  },
  methods: {
    async operar(fn) {
      if (this.guardando) return;
      this.guardando = true;
      try { await fn(); }
      catch (e) { toast(e.message, 'err'); }
      finally { this.guardando = false; }
    },
    async cargar() {
      const params = new URLSearchParams();
      if (this.dia) params.set('dia', this.dia);
      this.citas = await api('/api/medica/agenda?' + params);
    },
    async buscar() {
      const params = new URLSearchParams({ q: this.busqueda });
      this.pacientes = await api('/api/medica/pacientes?' + params);
    },
    async guardarPaciente() {
      await this.operar(async () => {
        await api('/api/medica/pacientes', { method: 'POST', body: this.paciente });
        this.paciente = null;
        this.busqueda = '';
        await this.buscar();
      });
    },
    async reservar() {
      await this.operar(async () => {
        await api('/api/medica/agenda', { method: 'POST', body: this.cita });
        this.cita = null;
        await this.cargar();
      });
    },
    async estado(cita, estado) {
      await this.operar(async () => {
        await api('/api/medica/agenda/' + cita.id + '/estado', { method: 'PUT', body: { estado } });
        await this.cargar();
      });
    },
    async abrir(cita) {
      await this.operar(async () => {
        const cerrada = cita.estado === 'atendida';
        const datos = cerrada ? await api('/api/medica/agenda/' + cita.id + '/consulta') : {};
        this.consulta = { id: cita.id, cerrada, ...datos };
      });
    },
    async cerrar() {
      await this.operar(async () => {
        if (this.consulta.cerrada) return;
        const { id, motivo, diagnostico, plan } = this.consulta;
        await api('/api/medica/agenda/' + id + '/consulta', { method: 'POST', body: { motivo, diagnostico, plan } });
        this.consulta = null;
        await this.cargar();
      });
    },
    asignada(cita) { return this.clinica && cita.profesional_id === sesion.usuario?.id; },
  },
  created() {
    this.operar(async () => {
      await this.cargar();
      if (this.recepcion) {
        this.profesionales = await api('/api/medica/profesionales');
        await this.buscar();
      }
    });
  },
  template: `
    <div class="page">
      <PageHead title="Recepción y agenda" :crumbs="[{label:'Médica'}]"></PageHead>
      <section v-if="recepcion" class="card">
        <h2>Pacientes</h2>
        <form @submit.prevent="operar(buscar)">
          <input v-model="busqueda" aria-label="Buscar pacientes" placeholder="Nombre, documento o teléfono">
          <button class="btn sec" :disabled="guardando">Buscar</button>
          <button type="button" class="btn" @click="paciente = {}">Nuevo paciente</button>
        </form>
        <p v-if="!pacientes.length">Sin pacientes para mostrar.</p>
        <ul v-else>
          <li v-for="p in pacientes" :key="p.id">
            {{p.nombre}} · Expediente {{p.id}}
            <button class="btn sm sec" @click="cita = {paciente_id:p.id}">Programar cita</button>
          </li>
        </ul>
      </section>
      <section class="card">
        <h2>Agenda</h2>
        <label>Fecha <input type="date" v-model="dia" @change="operar(cargar)"></label>
        <p v-if="!citas.length">Sin citas para mostrar.</p>
        <div v-for="c in citas" :key="c.id">
          <p>{{c.inicio.replace('T', ' ')}} · {{c.paciente}} · {{c.consultorio}} · {{c.estado}}
            <button v-if="recepcion && c.estado === 'programada'" class="btn sm sec" :disabled="guardando" @click="estado(c, 'confirmada')">Confirmar</button>
            <template v-if="recepcion && ['programada','confirmada'].includes(c.estado)">
              <button class="btn sm sec" :disabled="guardando" @click="estado(c, 'llegó')">Registrar llegada</button>
              <button class="btn sm sec" :disabled="guardando" @click="estado(c, 'no se presentó')">No se presentó</button>
            </template>
            <button v-if="recepcion && ['programada','confirmada','llegó'].includes(c.estado)" class="btn sm sec" :disabled="guardando" @click="estado(c, 'cancelada')">Cancelar cita</button>
            <button v-if="asignada(c) && ['llegó','atendida'].includes(c.estado)" class="btn sm" :disabled="guardando" @click="abrir(c)">Consulta</button>
          </p>
        </div>
      </section>
      <Modal v-if="paciente" title="Nuevo paciente" @close="paciente=null">
        <form @submit.prevent="guardarPaciente">
          <Field label="Nombre"><input v-model="paciente.nombre" required maxlength="160"></Field>
          <Field label="Documento"><input v-model="paciente.documento" required maxlength="32"></Field>
          <Field label="Fecha de nacimiento"><input v-model="paciente.nacimiento" type="date" required></Field>
          <Field label="Teléfono"><input v-model="paciente.telefono" type="tel" maxlength="40"></Field>
          <Field label="Correo"><input v-model="paciente.correo" type="email" maxlength="160"></Field>
          <button class="btn" :disabled="guardando">Guardar</button>
        </form>
      </Modal>
      <Modal v-if="cita" title="Programar cita" @close="cita=null">
        <form @submit.prevent="reservar">
          <Field label="Profesional"><select v-model="cita.profesional_id" required>
            <option disabled value="">Seleccionar</option>
            <option v-for="p in profesionales" :key="p.id" :value="p.id">{{p.nombre}}</option>
          </select></Field>
          <Field label="Consultorio"><input v-model="cita.consultorio" required maxlength="160"></Field>
          <Field label="Inicio"><input v-model="cita.inicio" type="datetime-local" required></Field>
          <Field label="Fin"><input v-model="cita.fin" type="datetime-local" required></Field>
          <button class="btn" :disabled="guardando">Reservar</button>
        </form>
      </Modal>
      <Modal v-if="consulta" title="Consulta" @close="consulta=null">
        <form @submit.prevent="cerrar">
          <Field label="Motivo"><textarea v-model="consulta.motivo" required maxlength="4000" :readonly="consulta.cerrada"></textarea></Field>
          <Field label="Diagnóstico"><textarea v-model="consulta.diagnostico" required maxlength="4000" :readonly="consulta.cerrada"></textarea></Field>
          <Field label="Plan"><textarea v-model="consulta.plan" required maxlength="8000" :readonly="consulta.cerrada"></textarea></Field>
          <button v-if="!consulta.cerrada" class="btn" :disabled="guardando">Cerrar consulta</button>
        </form>
      </Modal>
    </div>
  `,
};
