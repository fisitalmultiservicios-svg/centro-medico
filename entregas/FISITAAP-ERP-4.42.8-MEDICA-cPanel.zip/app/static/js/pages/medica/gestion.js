import { sesion } from '../../app.js';
import { campo, clientes, enviar, Formulario, leer, operaciones, opciones } from './_comun.js';

const pantallas = [
  ['consultorio','Consultorios'],['equipo','Equipos'],['profesional','Profesionales'],['tarea','Tareas'],
  ['aseguradora','Aseguradoras'],['convenio','Convenios'],['campaña','Campañas'],['incidente','Incidentes'],['reportes','Reportes'],
];
const fechaCR = () => new Intl.DateTimeFormat('en-CA',{timeZone:'America/Costa_Rica',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() { return { pantallas, tipo:'consultorio', filas:[], activos:[], profesionales:[], padron:null, q:'', reporte:null, desde:fechaCR(), hasta:fechaCR() }; },
  computed: {
    puedeActivos(){return sesion.puede('contabilidad');},
    filasVisibles(){
      const q=this.q.trim().toLowerCase();
      const perfiles=this.tipo==='profesional' ? this.profesionales.map(u=>{
        const perfil=this.filas.find(x=>x.responsable_id===u.id);
        return {estado:'Pendiente de completar',...perfil,nombre:u.nombre,responsable_id:u.id};
      }).concat(this.filas.filter(r=>!this.profesionales.some(u=>u.id===r.responsable_id))) : this.filas;
      return perfiles.filter(r=>[r.nombre,r.referencia,r.especialidad,r.detalle].join(' ').toLowerCase().includes(q));
    },
  },
  methods: {
    sesionUsuarios(){return sesion.puede('usuarios');},
    async abrirPadron(r){
      const filas=await leer('/operacion/convenio/'+r.id+'/padron');
      this.padron={nombre:r.nombre,filas};
    },
    async cargar() {
      if (this.tipo==='reportes') this.reporte=await leer('/reportes',{desde:this.desde,hasta:this.hasta});
      else {
        const tipo=this.tipo;
        const [filas,activos,profesionales]=await Promise.all([
          leer('/operacion/'+encodeURIComponent(tipo)),
          tipo==='equipo' && this.puedeActivos ? leer('/operacion-activos') : [],
          tipo==='profesional' ? leer('/operacion-profesionales') : [],
        ]);
        this.filas=filas;
        this.activos=activos;
        this.profesionales=profesionales;
      }
    },
    cambiar(tipo) { this.tipo=tipo; this.q=''; this.filas=[]; return this.ejecutar(this.cargar); },
    registro(r = null) {
      const tipo = this.tipo;
      const id = r?.id;
      this.pedir(id ? 'Editar registro' : 'Agregar registro',[
        ...(tipo==='profesional' ? [
          campo('responsable_id','Usuario de la clínica','select',{req:true,opciones:this.profesionales.map(u=>[u.id,u.nombre])}),
          campo('especialidad','Especialidad','text',{max:140}),
          campo('vinculo','Vínculo con la clínica','select',{opciones:opciones(['planilla','servicios profesionales','alquiler de consultorio'])}),
        ] : [campo('nombre','Nombre','text',{req:true})]),
        campo('estado','Estado','select',{req:true,opciones:opciones(['activo','inactivo','pendiente','en curso','cerrado'])}),
        campo('contacto_id','Contacto del ERP','select',{opciones:clientes()}),
        ...(tipo==='convenio' ? [
          campo('inicio_convenio','Inicio del convenio','date'),
          campo('ciclo_facturacion','Ciclo de facturación','select',{opciones:opciones(['por evento','mensual','trimestral','anual','mixto'])}),
          campo('servicios_convenio','Servicios incluidos','textarea',{max:2000}),
          campo('exclusiones_convenio','Exclusiones y restricciones','textarea',{max:2000}),
        ] : []),
        campo('vence','Vencimiento','date'),
        campo('referencia',tipo==='equipo'?'Serie o referencia del equipo':'Referencia contractual o colegiatura','text',{max:120}),
        ...(tipo==='equipo' && this.puedeActivos ? [campo('activo_id','Activo fijo del ERP','select',{opciones:this.activos.map(a=>[a.id,a.nombre])})] : []),
        campo('detalle','Detalle operativo','textarea',{max:4000}),
      ],{...r,estado:id?r.estado:'activo'},async d=>{
        if(tipo==='profesional') d.nombre=this.profesionales.find(u=>u.id===d.responsable_id)?.nombre || '';
        await enviar('/operacion/'+encodeURIComponent(tipo)+(id?'/'+id:''),d,id?'PUT':'POST');
        await this.cargar();
      });
    },
  },
  created() { this.ejecutar(this.cargar); },
  template: `
  <div class="page medica-workspace">
    <PageHead title="Operación y convenios" :crumbs="[{label:'Médica'}]">
      <button v-if="!['reportes','profesional'].includes(tipo)" class="btn" @click="registro()">Agregar registro</button>
    </PageHead>
    <nav class="medica-tabs" aria-label="Operación de la clínica"><button v-for="[id,label] in pantallas" :key="id" :aria-pressed="tipo===id" :disabled="ocupado" @click="cambiar(id)">{{label}}</button></nav>
    <section v-if="tipo!=='reportes'" class="card medica-panel">
      <div class="medica-toolbar"><input v-model="q" type="search" aria-label="Filtrar registros" placeholder="Buscar por nombre o referencia">
        <a v-if="tipo==='profesional' && sesionUsuarios()" class="btn sec sm" href="#/configuracion/usuarios">Administrar usuarios del ERP</a>
        <a v-if="tipo==='convenio'" class="btn sec sm" href="#/medica/seguros">Seguros y pólizas</a></div>
      <p v-if="!filasVisibles.length" class="medica-empty">Sin registros para mostrar.</p>
      <div v-else class="tablewrap"><table class="tabla"><thead><tr><th>Nombre</th><th>Estado</th><th>Vencimiento</th><th>Referencia</th><th></th></tr></thead>
        <tbody><tr v-for="r in filasVisibles" :key="r.id || r.responsable_id"><td><strong>{{r.nombre}}</strong><small v-if="r.especialidad"> · {{r.especialidad}}</small></td><td>{{r.estado}}</td><td>{{r.vence || '—'}}</td><td>{{r.referencia}}<small v-if="r.ciclo_facturacion"> · {{r.ciclo_facturacion}}</small></td>
          <td class="medica-actions"><button class="btn sm sec" @click="registro(r)">{{r.id?'Editar':'Completar perfil'}}</button>
            <button v-if="tipo==='convenio'" class="btn sm sec" @click="ejecutar(()=>abrirPadron(r))">Ver padrón</button>
            <a v-if="tipo==='equipo' && puedeActivos && r.activo_id" class="btn sm sec" :href="'#/contabilidad/activos/'+encodeURIComponent(r.activo_id)">Abrir activo ERP</a></td></tr></tbody>
      </table></div>
    </section>
    <section v-else class="card">
      <h2>Actividad de la sede</h2>
      <form class="acts" @submit.prevent="ejecutar(cargar)"><label>Desde <input v-model="desde" type="date" required></label>
        <label>Hasta <input v-model="hasta" type="date" required></label><button class="btn">Consultar</button></form>
      <div v-if="reporte">
        <p>{{reporte.citas}} citas · Espera promedio {{reporte.espera_minutos ?? '—'}} min · Atención promedio {{reporte.consulta_minutos ?? '—'}} min</p>
        <div class="grid cols-2"><div><h3>Por estado</h3><ul><li v-for="(n,t) in reporte.por_estado" :key="t">{{t}} · {{n}}</li></ul></div>
        <div><h3>Por modalidad</h3><ul><li v-for="(n,t) in reporte.por_modalidad" :key="t">{{t}} · {{n}}</li></ul></div></div>
        <h3>Consumo por convenio</h3><ul><li v-for="c in reporte.convenios" :key="c.nombre">{{c.nombre}} · {{c.atenciones}} atenciones</li></ul>
      </div>
    </section>
    <Modal v-if="padron" :title="'Padrón · '+padron.nombre" @close="padron=null" size="lg">
      <p v-if="!padron.filas.length">Todavía no hay coberturas corporativas vinculadas a este convenio.</p>
      <div v-for="(p,i) in padron.filas" :key="i" class="medica-record"><div class="medica-persona">
        <strong>{{p.paciente}}</strong><small>Expediente #{{p.expediente}} · {{p.numero_empleado || 'Sin número de empleado'}}</small></div>
        <div><span class="medica-status">{{p.vigente?'Vigente':'Fuera de vigencia'}}</span><small> hasta {{p.hasta}}</small></div></div>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
