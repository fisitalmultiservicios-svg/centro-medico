// Promociones › Tarjetas de regalo (3.49): código con saldo y vencimiento. Se venden desde la caja (el dinero entra ese día como
// anticipo, no como venta gravada) o desde aquí, y se usan como medio de pago en la caja o en el carrito en línea. Recargas,
// anulación y movimientos.
import { api, toast, money, fecha, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { lista: [], form: null, q: '', detalle: null, recarga: null }; },
  computed: { filtradas() { const q = this.q.trim().toLowerCase(); return this.lista.filter(t => !q || t.codigo.toLowerCase().includes(q) || (t.beneficiario || '').toLowerCase().includes(q) || (t.comprador || '').toLowerCase().includes(q)); } },
  methods: {
    money, fecha, fechaHora,
    async cargar() { try { this.lista = await api('/api/tarjetas'); } catch (e) { toast(e.message, 'err'); } },
    nueva() { this.form = { monto: 10000, comprador: '', beneficiario: '', telefono: '', mensaje: '', meses_vigencia: 12, codigo: '' }; },
    async guardar() {
      const f = this.form; if (!(+f.monto > 0)) return toast('Indique el monto', 'err');
      try { const t = await api('/api/tarjetas', { method: 'POST', body: { monto: +f.monto, comprador: f.comprador, beneficiario: f.beneficiario, telefono: f.telefono, mensaje: f.mensaje, meses_vigencia: +f.meses_vigencia || 0, codigo: (f.codigo || '').trim() || null } }); this.form = null; toast('Tarjeta ' + t.codigo + ' creada por ' + money(t.saldo), 'ok'); this.cargar(); this.detalle = t; }
      catch (e) { toast(e.message, 'err'); }
    },
    async recargar() { const r = this.recarga; if (!(+r.monto > 0)) return toast('Indique el monto', 'err'); try { await api('/api/tarjetas/' + r.t.codigo + '/recargar', { method: 'POST', body: { monto: +r.monto, referencia: 'recarga' } }); toast('Recarga aplicada', 'ok'); this.recarga = null; this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async anular(t) { if (!confirm('¿Anular la tarjeta ' + t.codigo + '? El saldo deja de poder usarse.')) return; try { await api('/api/tarjetas/' + t.codigo, { method: 'DELETE' }); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    estado(t) { if (!t.activa) return ['Anulada', 'danger']; if (t.vence && t.vence < new Date().toISOString().slice(0, 10)) return ['Vencida', 'warn']; if (t.saldo <= 0) return ['Sin saldo', '']; return ['Con saldo', 'ok']; },
    imprimir(t) {
      const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const html = '<!doctype html><html><head><meta charset="utf-8"><title>Tarjeta de regalo</title><style>body{font-family:Arial,sans-serif;margin:30px;color:#111}.t{border:2px dashed #0f766e;border-radius:16px;padding:24px;max-width:420px;text-align:center}.c{font-size:26px;letter-spacing:3px;font-weight:800;margin:10px 0}.m{font-size:22px;color:#0f766e;font-weight:800}p{margin:6px 0}</style></head><body><div class="t"><p><b>TARJETA DE REGALO</b></p><div class="m">' + esc(money(t.saldo)) + '</div><div class="c">' + esc(t.codigo) + '</div>' + (t.beneficiario ? '<p>Para: ' + esc(t.beneficiario) + '</p>' : '') + (t.mensaje ? '<p><i>' + esc(t.mensaje) + '</i></p>' : '') + (t.vence ? '<p>Válida hasta el ' + esc(fecha(t.vence)) + '</p>' : '') + '<p style="font-size:12px;color:#666">Presente este código en la caja o escríbalo en el catálogo en línea.</p></div></body></html>';
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Tarjetas de regalo" sub="Códigos con saldo que el cliente compra y regala. Se usan como medio de pago en la caja y en el catálogo en línea." :crumbs="[{label:'FISITAAP'},{label:'Promociones'},{label:'Tarjetas de regalo'}]">
      <button class="btn" @click="nueva">+ Tarjeta</button>
    </PageHead>
    <div class="alert info" style="margin-bottom:12px">Al vender una tarjeta el dinero entra ese día como un anticipo (no es una venta gravada); el tiquete electrónico sale cuando el cliente consume con ella. En la caja: botón «Tarjeta de regalo» para venderla y medio de pago «Tarjeta de regalo» para usarla.</div>
    <input class="inp" v-model="q" placeholder="Buscar por código, beneficiario o comprador" style="width:100%;max-width:420px;margin-bottom:10px">
    <Empty v-if="!lista.length" icon="🎁" title="Sin tarjetas" text="Cree la primera con «+ Tarjeta» o véndala desde la caja."></Empty>
    <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Código</th><th>Para / de</th><th class="num">Inicial</th><th class="num">Saldo</th><th>Vence</th><th>Estado</th><th></th></tr></thead><tbody>
      <tr v-for="t in filtradas" :key="t.id"><td><b class="mono">{{t.codigo}}</b><div class="small muted">{{fechaHora(t.creada)}}</div></td><td>{{t.beneficiario || '—'}}<div class="small muted" v-if="t.comprador">de {{t.comprador}}</div></td><td class="num">{{money(t.monto_inicial)}}</td><td class="num"><b>{{money(t.saldo)}}</b></td><td>{{t.vence ? fecha(t.vence) : 'No vence'}}</td><td><span class="badge" :class="estado(t)[1]">{{estado(t)[0]}}</span></td>
        <td class="num"><div class="acts"><button class="btn sm ghost" @click="detalle=t">Movimientos</button><button class="btn sm ghost" @click="imprimir(t)">Imprimir</button><button class="btn sm sec" v-if="t.activa" @click="recarga={t, monto: 5000}">Recargar</button><button class="btn icon" v-if="t.activa" @click="anular(t)">🗑</button></div></td></tr>
    </tbody></table></div>
    <Modal v-if="form" title="Nueva tarjeta de regalo" @close="form=null">
      <div class="grid cols-2">
        <Field label="Monto" req><input type="number" min="1000" step="1000" v-model.number="form.monto"></Field>
        <Field label="Vigencia (meses)" help="0 = no vence"><input type="number" min="0" max="120" v-model.number="form.meses_vigencia"></Field>
        <Field label="Para (beneficiario)"><input v-model="form.beneficiario" maxlength="80"></Field><Field label="Comprador"><input v-model="form.comprador" maxlength="80"></Field>
        <Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field><Field label="Código propio" help="Vacío = se genera uno"><input v-model="form.codigo" maxlength="20" style="text-transform:uppercase"></Field>
        <Field label="Mensaje" style="grid-column:1/-1"><input v-model="form.mensaje" maxlength="200" placeholder="¡Feliz cumpleaños!"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Si la vende aquí, registre el cobro en Bancos o en la caja; desde la caja el botón «Tarjeta de regalo» hace las dos cosas.</p>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Crear</button></template>
    </Modal>
    <Modal v-if="detalle" :title="'Tarjeta ' + detalle.codigo" @close="detalle=null">
      <p style="margin:0 0 8px">Saldo <b>{{money(detalle.saldo)}}</b> de {{money(detalle.monto_inicial)}}{{detalle.vence ? ' · vence ' + fecha(detalle.vence) : ''}}{{detalle.beneficiario ? ' · para ' + detalle.beneficiario : ''}}</p>
      <table class="tbl"><thead><tr><th>Fecha</th><th>Movimiento</th><th>Referencia</th><th class="num">Monto</th></tr></thead><tbody><tr v-for="(m,i) in detalle.movimientos" :key="i"><td>{{fechaHora(m.fecha)}}</td><td>{{m.tipo}}</td><td class="small">{{m.referencia}}</td><td class="num">{{money(m.monto)}}</td></tr></tbody></table>
      <template #foot><button class="btn ghost" @click="imprimir(detalle)">Imprimir</button><button class="btn ghost" @click="detalle=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="recarga" :title="'Recargar ' + recarga.t.codigo" @close="recarga=null">
      <Field label="Monto" req><input type="number" min="1000" step="1000" v-model.number="recarga.monto" autofocus></Field>
      <template #foot><button class="btn ghost" @click="recarga=null">Cancelar</button><button class="btn" @click="recargar">Recargar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
