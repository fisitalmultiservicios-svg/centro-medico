// Promociones › Fidelización (3.49): programa de puntos. Puntos por cada ₡1.000 de compra, valor de cada punto al canjear, mínimo
// de canje y porcentaje máximo de la compra que se paga con puntos. Un saldo por teléfono (clientes en línea) o por cliente de
// la empresa (caja). Aquí se configura, se consultan saldos y se hacen ajustes manuales con motivo.
import { api, toast, money, fmt, fechaHora } from '../../api.js';
import { store, sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { cfg: null, clientes: [], q: '', consulta: null, ajuste: null, guardando: false }; },
  computed: {
    filtrados() { const q = this.q.trim().toLowerCase(); return this.clientes.filter(c => !q || (c.nombre || '').toLowerCase().includes(q) || c.quien.includes(q)); },
    nombreCliente() { return q => { if (!q || !q.startsWith('cliente:')) return null; const c = (store.clientes || []).find(x => x.id === +q.slice(8)); return c ? c.nombre : null; }; },
  },
  methods: {
    money, fmt, fechaHora,
    async cargar() { try { this.cfg = await api('/api/fidelizacion/config'); this.clientes = await api('/api/fidelizacion/clientes'); } catch (e) { toast(e.message, 'err'); } },
    async guardar() { this.guardando = true; try { this.cfg = await api('/api/fidelizacion/config', { method: 'PUT', body: this.cfg }); toast('Programa de puntos guardado', 'ok'); } catch (e) { toast(e.message, 'err'); } this.guardando = false; },
    async ver(c) { try { this.consulta = await api('/api/fidelizacion/saldo?' + (c.quien.startsWith('cliente:') ? 'cliente_id=' + c.quien.slice(8) : 'telefono=' + c.quien)); this.consulta.nombre = c.nombre || this.nombreCliente(c.quien) || c.quien; } catch (e) { toast(e.message, 'err'); } },
    abrirAjuste(c) { this.ajuste = { quien: c ? c.quien : '', telefono: c && !c.quien.startsWith('cliente:') ? c.quien : '', cliente_id: c && c.quien.startsWith('cliente:') ? +c.quien.slice(8) : null, puntos: 0, motivo: '' }; },
    async guardarAjuste() {
      const a = this.ajuste; if (!(+a.puntos)) return toast('Indique los puntos (negativo para quitar)', 'err'); if (!(a.motivo || '').trim()) return toast('Escriba el motivo', 'err');
      try { await api('/api/fidelizacion/ajuste', { method: 'POST', body: { cliente_id: a.cliente_id || null, telefono: a.telefono || null, puntos: +a.puntos, motivo: a.motivo.trim() } }); toast('Ajuste registrado', 'ok'); this.ajuste = null; this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Fidelización por puntos" sub="Los clientes acumulan puntos por sus compras en la caja y en línea, y los canjean como descuento." :crumbs="[{label:'FISITAAP'},{label:'Promociones'},{label:'Fidelización'}]">
      <button class="btn sec" @click="abrirAjuste(null)">Ajuste manual</button><button class="btn" @click="guardar" :disabled="guardando || !cfg">Guardar</button>
    </PageHead>
    <div class="grid cols-2" style="align-items:start" v-if="cfg">
      <div class="card"><h2>Reglas del programa</h2>
        <Toggle v-model="cfg.activo" label="Programa de puntos activo"></Toggle>
        <div class="grid cols-2" style="margin-top:10px">
          <Field label="Nombre de los puntos"><input v-model="cfg.nombre" maxlength="30" placeholder="Puntos, Estrellas, Soles…"></Field>
          <Field label="Puntos por cada ₡1.000 de compra" help="Sobre el total con impuestos, sin el envío"><input type="number" min="0" step="0.5" v-model.number="cfg.puntos_por_mil"></Field>
          <Field label="Valor de cada punto al canjear (₡)"><input type="number" min="0" step="1" v-model.number="cfg.valor_punto"></Field>
          <Field label="Canje mínimo (puntos)"><input type="number" min="0" step="10" v-model.number="cfg.minimo_canje"></Field>
          <Field label="Máximo de la compra que se paga con puntos (%)"><input type="number" min="1" max="100" v-model.number="cfg.maximo_pct"></Field>
        </div>
        <p class="small muted" style="margin:8px 0 0">Ejemplo con estos valores: una compra de ₡10.000 da {{fmt(10 * (+cfg.puntos_por_mil || 0), 1)}} {{cfg.nombre || 'puntos'}}; {{cfg.minimo_canje}} {{cfg.nombre || 'puntos'}} valen {{money((+cfg.minimo_canje || 0) * (+cfg.valor_punto || 0))}}. En la caja los puntos se acreditan al cobrar con cliente identificado; en línea, al entregar el pedido, por teléfono.</p>
      </div>
      <div class="card"><h2>Clientes con puntos <small>{{clientes.length}}</small></h2>
        <input class="inp" v-model="q" placeholder="Buscar por nombre o teléfono" style="width:100%;margin-bottom:8px">
        <Empty v-if="!clientes.length" icon="⭐" title="Nadie ha acumulado todavía" text="Los saldos aparecen cuando se cobre con cliente o se entregue un pedido en línea."></Empty>
        <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Cliente</th><th class="num">Saldo</th><th class="num">Ganados</th><th class="num">Canjeados</th><th></th></tr></thead><tbody>
          <tr v-for="c in filtrados" :key="c.quien"><td>{{c.nombre || nombreCliente(c.quien) || '—'}}<div class="small muted mono">{{c.quien.startsWith('cliente:') ? 'cliente de la empresa' : c.quien}}</div></td><td class="num"><b>{{fmt(c.saldo, 0)}}</b></td><td class="num">{{fmt(c.ganados, 0)}}</td><td class="num">{{fmt(c.canjeados, 0)}}</td><td class="num"><div class="acts"><button class="btn sm ghost" @click="ver(c)">Movimientos</button><button class="btn sm ghost" @click="abrirAjuste(c)">Ajustar</button></div></td></tr>
        </tbody></table></div>
      </div>
    </div>
    <Modal v-if="consulta" :title="'Puntos de ' + consulta.nombre" @close="consulta=null">
      <p style="margin:0 0 8px"><b style="font-size:20px">{{fmt(consulta.saldo, 0)}}</b> {{cfg.nombre}} · equivalen a {{money(consulta.valor)}}</p>
      <table class="tbl"><thead><tr><th>Fecha</th><th>Motivo</th><th>Referencia</th><th class="num">Puntos</th></tr></thead><tbody><tr v-for="(m,i) in consulta.movimientos" :key="i"><td>{{fechaHora(m.fecha)}}</td><td>{{m.motivo}}</td><td class="small">{{m.referencia}}</td><td class="num" :style="m.puntos < 0 ? 'color:var(--danger)' : 'color:var(--ok)'">{{m.puntos > 0 ? '+' : ''}}{{fmt(m.puntos, 0)}}</td></tr></tbody></table>
      <template #foot><button class="btn ghost" @click="consulta=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="ajuste" title="Ajuste manual de puntos" @close="ajuste=null">
      <div class="grid cols-2">
        <Field label="Teléfono del cliente (en línea)" help="8 dígitos"><input v-model="ajuste.telefono" maxlength="12" inputmode="numeric" :disabled="!!ajuste.cliente_id"></Field>
        <Field label="O cliente de la empresa"><select v-model="ajuste.cliente_id" :disabled="!!ajuste.telefono"><option :value="null">—</option><option v-for="c in store.clientes.filter(x => x.activo !== false)" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
        <Field label="Puntos" req help="Negativo para quitar"><input type="number" step="1" v-model.number="ajuste.puntos"></Field>
        <Field label="Motivo" req><input v-model="ajuste.motivo" maxlength="120" placeholder="Bienvenida, corrección, promoción…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="ajuste=null">Cancelar</button><button class="btn" @click="guardarAjuste">Registrar</button></template>
    </Modal>
  </div>`,
  setup() { return { store, sesion }; },
};
