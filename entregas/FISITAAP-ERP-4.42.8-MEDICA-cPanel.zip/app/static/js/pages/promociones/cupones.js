// Promociones › Cupones (3.49): códigos de descuento por porcentaje o monto, con mínimo de compra, tope, vigencia, usos máximos y
// usos por cliente, válidos en la caja, en el catálogo en línea o en ambos. Cada uso queda registrado con su referencia.
import { api, toast, money, fecha, fechaHora, hoy } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { lista: [], form: null, usos: null }; },
  methods: {
    money, fecha, fechaHora,
    async cargar() { try { this.lista = await api('/api/cupones'); } catch (e) { toast(e.message, 'err'); } },
    nuevo() { this.form = { id: null, codigo: '', nombre: '', tipo: 'pct', valor: 10, minimo: 0, tope: null, desde: hoy(), hasta: '', usos_max: null, usos_cliente: 1, caja: true, online: true, activo: true }; },
    editar(c) { this.form = { ...c, caja: (c.canales || '').includes('caja'), online: (c.canales || '').includes('online') }; },
    async guardar() {
      const f = this.form; if (!(f.codigo || '').trim()) return toast('Escriba el código', 'err'); if (!(+f.valor > 0)) return toast('Indique el valor del descuento', 'err');
      const body = { codigo: f.codigo, nombre: f.nombre || '', tipo: f.tipo, valor: +f.valor, minimo: +f.minimo || 0, tope: f.tipo === 'pct' && +f.tope > 0 ? +f.tope : null, desde: f.desde || null, hasta: f.hasta || null, usos_max: +f.usos_max > 0 ? +f.usos_max : null, usos_cliente: +f.usos_cliente > 0 ? +f.usos_cliente : null, canales: [f.caja ? 'caja' : null, f.online ? 'online' : null].filter(Boolean), activo: f.activo !== false };
      if (!body.canales.length) return toast('Elija al menos un canal: caja o en línea', 'err');
      try { await api(f.id ? '/api/cupones/' + f.id : '/api/cupones', { method: f.id ? 'PUT' : 'POST', body }); toast('Cupón guardado', 'ok'); this.form = null; this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async borrar(c) { if (!confirm('¿Borrar el cupón ' + c.codigo + '?')) return; try { const r = await api('/api/cupones/' + c.id, { method: 'DELETE' }); toast(r.mensaje || 'Cupón borrado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async verUsos(c) { try { this.usos = { c, lista: await api('/api/cupones/' + c.id + '/usos') }; } catch (e) { toast(e.message, 'err'); } },
    vigencia(c) { const h = hoy(); if (c.activo === false) return ['Inactivo', '']; if (c.desde && h < c.desde) return ['Pendiente', 'info']; if (c.hasta && h > c.hasta) return ['Vencido', 'danger']; if (c.usos_max && c.usados >= c.usos_max) return ['Agotado', 'warn']; return ['Vigente', 'ok']; },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Cupones" sub="Códigos de descuento para la caja y para los pedidos en línea. El descuento se reparte entre los artículos y queda reflejado en el tiquete." :crumbs="[{label:'FISITAAP'},{label:'Promociones'},{label:'Cupones'}]">
      <a class="btn ghost" href="#/pos/configuracion?ir=promos">Promociones por horario y combos</a><button class="btn" @click="nuevo">+ Cupón</button>
    </PageHead>
    <Empty v-if="!lista.length" icon="🎟" title="Sin cupones" text="Cree el primero: por ejemplo BIENVENIDO con 10 % en la primera compra en línea."></Empty>
    <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Código</th><th>Descuento</th><th>Condiciones</th><th>Canal</th><th>Vigencia</th><th class="num">Usos</th><th></th></tr></thead><tbody>
      <tr v-for="c in lista" :key="c.id" :style="c.activo ? '' : 'opacity:.55'"><td><b class="mono">{{c.codigo}}</b><div class="small muted">{{c.nombre}}</div></td><td>{{c.tipo==='pct' ? c.valor + ' %' + (c.tope ? ' (máx. ' + money(c.tope) + ')' : '') : money(c.valor)}}</td>
        <td class="small">{{c.minimo ? 'mínimo ' + money(c.minimo) : 'sin mínimo'}}{{c.usos_cliente ? ' · ' + c.usos_cliente + ' por cliente' : ''}}</td><td class="small">{{(c.canales||'').replace('caja','Caja').replace('online','En línea').replace(',', ' y ')}}</td>
        <td><span class="badge" :class="vigencia(c)[1]">{{vigencia(c)[0]}}</span><div class="small muted" v-if="c.desde || c.hasta">{{c.desde ? fecha(c.desde) : '…'}} – {{c.hasta ? fecha(c.hasta) : '…'}}</div></td><td class="num">{{c.usados}}{{c.usos_max ? ' / ' + c.usos_max : ''}}</td>
        <td class="num"><div class="acts"><button class="btn sm ghost" @click="verUsos(c)" v-if="c.usados">Usos</button><button class="btn sm sec" @click="editar(c)">Editar</button><button class="btn icon" @click="borrar(c)">🗑</button></div></td></tr>
    </tbody></table></div>
    <Modal v-if="form" :title="form.id ? 'Cupón ' + form.codigo : 'Nuevo cupón'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Código" req help="Letras y números, sin espacios; el cliente lo escribe tal cual"><input v-model="form.codigo" maxlength="20" style="text-transform:uppercase" placeholder="BIENVENIDO"></Field>
        <Field label="Nombre interno"><input v-model="form.nombre" maxlength="80" placeholder="Primera compra en línea"></Field>
        <Field label="Tipo"><select v-model="form.tipo"><option value="pct">Porcentaje</option><option value="monto">Monto fijo</option></select></Field>
        <Field :label="form.tipo==='pct' ? 'Porcentaje' : 'Monto (con impuestos)'" req><input type="number" min="0" step="1" v-model.number="form.valor"></Field>
        <Field label="Compra mínima (con impuestos)"><input type="number" min="0" step="100" v-model.number="form.minimo"></Field>
        <Field label="Descuento máximo" v-if="form.tipo==='pct'" help="Vacío = sin tope"><input type="number" min="0" step="100" v-model.number="form.tope"></Field>
        <Field label="Desde"><input type="date" v-model="form.desde"></Field><Field label="Hasta" help="Vacío = sin vencimiento"><input type="date" v-model="form.hasta"></Field>
        <Field label="Usos máximos" help="Vacío = sin límite"><input type="number" min="1" v-model.number="form.usos_max"></Field><Field label="Usos por cliente" help="Vacío = sin límite"><input type="number" min="1" v-model.number="form.usos_cliente"></Field>
      </div>
      <div class="row" style="gap:14px;margin-top:10px;flex-wrap:wrap"><Toggle v-model="form.caja" label="Vale en la caja"></Toggle><Toggle v-model="form.online" label="Vale en pedidos en línea"></Toggle><Toggle v-model="form.activo" label="Activo"></Toggle></div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="usos" :title="'Usos del cupón ' + usos.c.codigo" @close="usos=null">
      <table class="tbl"><thead><tr><th>Fecha</th><th>Quién</th><th>Referencia</th><th>Canal</th><th class="num">Descuento</th></tr></thead><tbody><tr v-for="(u,i) in usos.lista" :key="i"><td>{{fechaHora(u.fecha)}}</td><td class="mono small">{{u.quien || '—'}}</td><td class="small">{{u.referencia}}</td><td class="small">{{u.canal}}</td><td class="num">{{money(u.monto)}}</td></tr></tbody></table>
      <template #foot><button class="btn ghost" @click="usos=null">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
