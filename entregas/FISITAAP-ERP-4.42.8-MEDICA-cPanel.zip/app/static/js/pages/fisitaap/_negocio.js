// FISITAAP (3.57): carga y guardado del negocio público compartidos por Mi página y Configuración. Las dos pantallas editan el mismo
// registro (GET/PUT /api/pedidos/negocio); cada una manda el objeto completo tal como lo tiene, así no se pisan campos.
import { api } from '../../api.js';

export function normalizar(n) {
  n.horarios = Array.from({ length: 7 }, (_, i) => (n.horarios && n.horarios[i] ? [n.horarios[i][0], n.horarios[i][1]] : null));
  n.redes = n.redes || {};
  return n;
}

export async function cargarNegocio() { return normalizar(await api('/api/pedidos/negocio')); }

// extra: campos que solo manda una pantalla (p. ej. las llaves de Tilopay; null = no se tocan, '' = se borran)
export async function guardarNegocio(n, extra = {}) {
  const body = { ...n, slug: String(n.slug || '').trim().toLowerCase(), horarios: n.horarios.map(h => (h && h[0] && h[1] ? [h[0], h[1]] : null)),
    costo_envio: +n.costo_envio || 0, minimo_pedido: +n.minimo_pedido || 0, terminal_id: n.terminal_id || null, marca_id: n.marca_id || null,
    tilopay_key: null, tilopay_user: null, tilopay_password: null, ...extra };
  delete body.portada; delete body.abierto; delete body.nombre_publico; delete body.url; delete body.visibles; delete body.id; delete body.tilopay;
  delete body.galeria; delete body.dominio_verificado; delete body.url_dominio; delete body.url_subdominio; delete body.url_publica; delete body.host_base;   // 3.58: los maneja el servidor
  if (!('agotado_auto' in extra)) delete body.agotado_auto;   // 4.40: solo Generales la cambia; Diseño de la página o Publicar abiertos desde antes no la apagan
  return normalizar(await api('/api/pedidos/negocio', { method: 'PUT', body }));
}

export const DIAS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
