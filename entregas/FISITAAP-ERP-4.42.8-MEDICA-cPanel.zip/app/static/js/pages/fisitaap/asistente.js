// FISITAAP › Asistente (3.57): la misma pantalla de Configuración › Asistente con IA, vista desde el módulo FISITAAP (el botón
// «Preguntar» del catálogo y los demás usos). Reutiliza el componente y solo cambia la miga de pan.
import ia from '../configuracion/ia.js';

export default {
  ...ia,
  template: ia.template.replace(/:crumbs="\[\{label:'Configuración'[^"]*"/, `:crumbs="[{label:'Ventas en línea'},{label:'Asistente'}]"`),
};
