// FISITAAP › Catálogo o menú (3.57): qué ítems del Inventario se venden en la página pública y cómo se muestran (visible, destacado,
// agotado, descripción pública). Los ítems siguen siendo del Inventario: precio, foto, impuestos y existencias se editan allá.
// 4.40: etiqueta «Sin existencias» cuando la página lo muestra agotado por existencias (it.agotado_existencias, opción «Mostrar agotado según existencias»).
import { api, toast, money } from '../../api.js';
import { sesion } from '../../app.js';

// 4.40: la bodega puede llegar como nombre o como {id, nombre}
const nombreBodega = b => (!b ? '' : typeof b === 'string' ? b : (b.nombre || ''));

export default {
  props: ['params'],
  data() { return { items: [], categorias: [], q: '', solo: 'todos', abierto: null, texto: '', cargando: true, bodega: '' }; },   // 4.40: bodega del agotado según existencias
  computed: {
    // 4.40: título de la etiqueta «Sin existencias»
    tituloSinExistencias() { return 'Se muestra agotado en la página porque no hay unidades disponibles en ' + (this.bodega || 'la bodega de la caja que recibe los pedidos') + '. Queda disponible de nuevo por sí solo cuando entren unidades.'; },
    puede() { return sesion.puede('catalogos'); },
    visibles() { return this.items.filter(i => i.visible_catalogo).length; },
    filtrados() {
      const q = this.q.trim().toLowerCase();
      return this.items.filter(i => (this.solo === 'todos' || (this.solo === 'visibles' ? i.visible_catalogo : !i.visible_catalogo)) && (!q || i.nombre.toLowerCase().includes(q) || (i.categoria || '').toLowerCase().includes(q)));
    },
    grupos() {
      const por = {}; for (const i of this.filtrados) (por[i.categoria || 'Otros'] = por[i.categoria || 'Otros'] || []).push(i);
      const orden = Object.fromEntries(this.categorias.map((c, n) => [c, n]));
      return Object.keys(por).sort((a, b) => ((orden[a] ?? 999) - (orden[b] ?? 999)) || a.localeCompare(b)).map(c => ({ nombre: c, items: por[c], visibles: por[c].filter(i => i.visible_catalogo).length }));
    },
  },
  methods: {
    money,
    async cargar() { this.cargando = true; try { const r = await api('/api/pedidos/catalogo'); this.items = r.items; this.categorias = r.categorias; this.bodega = nombreBodega(r.bodega) || this.bodega; } catch (e) { toast(e.message, 'err'); } this.cargando = false; this.cargarBodega(); },
    // 4.40: el nombre de la bodega viene en el listado; si no viene y algún ítem sale agotado por existencias, se pide a la vista previa;
    // si tampoco responde, el título dice «la bodega de la caja que recibe los pedidos»
    async cargarBodega() {
      if (this.bodega || !this.puede || !this.items.some(i => i.agotado_existencias)) return;
      try { const v = await api('/api/pedidos/catalogo/agotado-vista'); this.bodega = nombreBodega(v && v.bodega); } catch { this.bodega = ''; }
    },
    async cambiar(it, campo, valor) {
      if (!this.puede) return toast('Su rol no puede cambiar el catálogo', 'err');
      if ((campo === 'destacado' || campo === 'agotado') && !it.visible_catalogo) return toast('Primero muestre el ítem en la página', 'err');
      const antes = it[campo]; it[campo] = valor;
      try { const r = await api('/api/pedidos/catalogo/' + it.id, { method: 'PUT', body: { [campo]: valor } }); Object.assign(it, r); }
      catch (e) { it[campo] = antes; toast(e.message, 'err'); }
    },
    async grupo(g, valor) {
      const ids = g.items.filter(i => i.visible_catalogo !== valor).map(i => i.id); if (!ids.length) return;
      try { await api('/api/pedidos/catalogo/lote', { method: 'POST', body: { ids, visible_catalogo: valor } }); g.items.forEach(i => { if (ids.includes(i.id)) i.visible_catalogo = valor; }); toast((valor ? 'Publicados ' : 'Ocultos ') + ids.length + ' ítem(s) de ' + g.nombre, 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    editar(it) { if (this.abierto === it.id) { this.abierto = null; return; } this.abierto = it.id; this.texto = it.descripcion_publica || ''; },
    async guardarTexto(it) { await this.cambiar(it, 'descripcion_publica', this.texto.trim()); this.abierto = null; toast('Descripción guardada', 'ok'); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Catálogo o menú" sub="Elija qué ítems del Inventario se venden en su página y cómo se muestran. Precio, foto, impuestos y existencias se editan en Inventario › Ítems." :crumbs="[{label:'FISITAAP'},{label:'Catálogo o menú'}]">
      <a class="btn ghost" href="#/inventario/items/nuevo">Nuevo ítem</a>
      <a class="btn sec" href="#/fisitaap/pagina">Mi página</a>
    </PageHead>
    <div class="alert info" style="margin-bottom:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <span><b>{{visibles}}</b> de {{items.length}} ítem(s) a la venta se muestran en la página. Un ítem «agotado» se ve pero no se puede pedir. Con «Mostrar agotado según existencias» encendido, también se agota solo al llegar a 0. «Destacado» sale de primero.</span>
    </div>
    <div class="toolbar" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
      <input v-model="q" placeholder="Buscar por nombre o categoría" style="flex:1;min-width:200px">
      <select v-model="solo"><option value="todos">Todos</option><option value="visibles">Solo los que se muestran</option><option value="ocultos">Solo los ocultos</option></select>
    </div>
    <Empty v-if="!cargando && !items.length" icon="🛍" title="Sin ítems a la venta" text="Cree ítems en Inventario y vuelva aquí para publicarlos."></Empty>
    <div class="card" v-for="g in grupos" :key="g.nombre" style="margin-bottom:12px">
      <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><h2 style="margin:0">{{g.nombre}} <span class="small muted">· {{g.visibles}} de {{g.items.length}} en la página</span></h2>
        <div class="row" style="gap:6px" v-if="puede"><button class="btn sm ghost" @click="grupo(g, true)" :disabled="g.visibles === g.items.length">Mostrar todos</button><button class="btn sm ghost" @click="grupo(g, false)" :disabled="!g.visibles">Ocultar todos</button></div></div>
      <table class="tbl" style="margin-top:8px"><thead><tr><th style="width:52px"></th><th>Ítem</th><th class="num">Precio con IVA</th><th style="width:110px">En la página</th><th style="width:100px">Destacado</th><th style="width:90px">Agotado</th><th style="width:70px"></th></tr></thead>
        <tbody><template v-for="it in g.items" :key="it.id">
          <tr :style="it.visible_catalogo ? '' : 'opacity:.6'">
            <td><img v-if="it.foto" :src="it.foto" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:6px"><span v-else class="small muted" title="Sin foto: agréguela en Inventario">sin foto</span></td>
            <td><div><b>{{it.nombre}}</b></div><div class="small muted" v-if="it.descripcion_publica">{{it.descripcion_publica}}</div><div class="small muted" v-else>Sin descripción pública</div></td>
            <td class="num">{{money(it.precio, it.moneda)}}</td>
            <td><Toggle :modelValue="it.visible_catalogo" @update:modelValue="v => cambiar(it, 'visible_catalogo', v)" label="" :style="puede ? '' : 'opacity:.4'"></Toggle></td>
            <td><Toggle :modelValue="it.destacado" @update:modelValue="v => cambiar(it, 'destacado', v)" label="" :style="puede && it.visible_catalogo ? '' : 'opacity:.4'"></Toggle></td>
            <td><Toggle :modelValue="it.agotado" @update:modelValue="v => cambiar(it, 'agotado', v)" label="" :style="puede && it.visible_catalogo ? '' : 'opacity:.4'"></Toggle><div v-if="it.agotado_existencias && it.visible_catalogo" style="margin-top:4px" data-sin-existencias><span class="badge" :title="tituloSinExistencias">Sin existencias</span></div></td>
            <td class="row" style="gap:4px"><button class="btn sm ghost" @click="editar(it)" title="Descripción pública" :disabled="!puede">Texto</button><a class="btn sm ghost" :href="'#/inventario/items/' + it.id" title="Editar en Inventario">Ítem</a></td>
          </tr>
          <tr v-if="abierto === it.id"><td colspan="7"><div class="row" style="gap:8px;align-items:flex-start"><textarea rows="2" v-model="texto" maxlength="300" style="flex:1" placeholder="Lo que ve el cliente debajo del nombre (hasta 300 caracteres)"></textarea><button class="btn sm" @click="guardarTexto(it)">Guardar</button><button class="btn sm ghost" @click="abierto = null">Cerrar</button></div></td></tr>
        </template></tbody></table>
    </div>
  </div>`,
  setup() { return { sesion }; },
};
