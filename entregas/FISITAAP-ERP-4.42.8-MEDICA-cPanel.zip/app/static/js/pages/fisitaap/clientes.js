// FISITAAP › Clientes web (3.57): quienes compran por la página, con su teléfono, direcciones guardadas, cuántos pedidos han hecho y
// cuánto han comprado. Son los clientes finales del catálogo (entran con teléfono y clave); no son los Contactos de facturación.
import { api, toast, money, fecha } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { lista: [], q: '', abierto: null, cargando: true }; },
  computed: {
    filtrados() { const q = this.q.trim().toLowerCase(); return this.lista.filter(c => !q || c.telefono.includes(q) || (c.nombre || '').toLowerCase().includes(q)); },
    totales() { return { clientes: this.lista.length, pedidos: this.lista.reduce((a, c) => a + (c.pedidos || 0), 0), monto: this.lista.reduce((a, c) => a + (c.total || 0), 0) }; },
  },
  methods: {
    money, fecha,
    async cargar() { this.cargando = true; try { this.lista = await api('/api/pedidos/clientes'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    wa(c) { return 'https://wa.me/506' + c.telefono; },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Clientes web" sub="Quienes han pedido por su página. Entran con su teléfono y una clave, guardan direcciones y ven sus pedidos." :crumbs="[{label:'FISITAAP'},{label:'Clientes web'}]">
      <button class="btn sec" @click="cargar()" :disabled="cargando">Actualizar</button>
    </PageHead>
    <div class="grid cols-3" style="margin-bottom:12px">
      <div class="card"><div class="small muted">Clientes</div><div style="font-size:22px;font-weight:800">{{totales.clientes}}</div></div>
      <div class="card"><div class="small muted">Pedidos</div><div style="font-size:22px;font-weight:800">{{totales.pedidos}}</div></div>
      <div class="card"><div class="small muted">Comprado</div><div style="font-size:22px;font-weight:800">{{money(totales.monto)}}</div></div>
    </div>
    <div class="toolbar" style="margin-bottom:10px"><input v-model="q" placeholder="Buscar por teléfono o nombre" style="width:100%;max-width:360px"></div>
    <Empty v-if="!cargando && !lista.length" icon="📱" title="Todavía no hay clientes web" text="Aparecen cuando alguien pide por su página con su teléfono."></Empty>
    <div class="card" v-else>
      <table class="tbl"><thead><tr><th>Teléfono</th><th>Nombre</th><th class="num">Pedidos</th><th class="num">Comprado</th><th>Último pedido</th><th>Direcciones</th><th></th></tr></thead>
        <tbody><template v-for="c in filtrados" :key="c.id">
          <tr>
            <td><a :href="wa(c)" target="_blank" rel="noopener" title="Escribir por WhatsApp">{{c.telefono}}</a></td>
            <td>{{c.nombre || '—'}}</td>
            <td class="num">{{c.pedidos || 0}}</td>
            <td class="num">{{money(c.total || 0)}}</td>
            <td>{{c.ultimo_pedido ? fecha(c.ultimo_pedido) : '—'}}</td>
            <td><button class="btn sm ghost" v-if="c.direcciones.length" @click="abierto = abierto === c.id ? null : c.id">{{c.direcciones.length}} dirección(es)</button><span class="small muted" v-else>—</span></td>
            <td><a class="btn sm ghost" :href="'#/fisitaap/pedidos?q=' + c.telefono">Pedidos</a></td>
          </tr>
          <tr v-if="abierto === c.id"><td colspan="7"><ul class="small" style="margin:0;padding-left:18px"><li v-for="(d, i) in c.direcciones" :key="i"><b>{{d.nombre || 'Dirección'}}:</b> {{d.detalle}} <a v-if="d.enlace" :href="d.enlace" target="_blank" rel="noopener">mapa</a></li></ul></td></tr>
        </template></tbody></table>
    </div>
  </div>`,
  setup() { return { sesion }; },
};
