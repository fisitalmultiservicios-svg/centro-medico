// Ventas en línea › Configuración (3.57): formas de entrega, costo de envío, pedido mínimo, caja que recibe los pedidos, aviso al cliente,
// correo de aviso al negocio, pago con tarjeta en línea (Tilopay, llaves cifradas) y correos al cliente. 3.58: SINPE Móvil con
// comprobante y avisos de pedido nuevo en este dispositivo. Comparte el registro del negocio con Mi página (ver _negocio.js).
// 4.40: «Mostrar agotado según existencias» (n.agotado_auto) debajo de la caja que recibe los pedidos, con su vista previa y avisos.
// 4.40: en el programa de escritorio no se muestra la casilla ni se pide la vista previa; el aviso «No hay una bodega activa…» sale
// solo con la casilla marcada.
import { api, toast, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';
import { terminales } from '../pos/_datos.js';
import { cargarNegocio, guardarNegocio } from './_negocio.js';
import { avisosActivos, permisoAvisos, activarAvisos, desactivarAvisos } from '../../avisos.js';

export default {
  props: ['params'],
  data() { return { n: null, guardando: false, terms: terminales(), tl: { key: null, user: null, password: null }, probando: false, avisos: avisosActivos(), permiso: permisoAvisos(), vista: null, vistaError: false, verCuales: false }; },   // 4.40: vista previa del agotado según existencias
  computed: {
    // 4.40: textos del agotado según existencias; la bodega es la de la caja que recibe los pedidos (la dice la vista previa)
    bodegaAgotado() { const b = this.vista && this.vista.bodega; return !b ? '' : typeof b === 'string' ? b : (b.nombre || ''); },   // 4.40: llega el nombre o {id, nombre}
    ayudaAgotado() { return 'Cuando un producto llega a 0 en la bodega de la caja que recibe los pedidos' + (this.bodegaAgotado ? ' (' + this.bodegaAgotado + ')' : '') + ', la página lo muestra agotado y no deja pedirlo. Cuando entran unidades, queda disponible de nuevo por sí solo. La casilla «Agotado por ahora» de cada producto sigue sirviendo para agotarlo aunque tenga existencias. Un combo de Ventas en línea › Catálogo web › Combos se agota cuando las unidades de uno de sus componentes no alcanzan para armar uno; un plato con receta, cuando no alcanza uno de sus ingredientes. Los servicios, los productos sin control de inventario y los que permiten vender en negativo no se agotan solos.'; },   // 4.40: los combos de Catálogo web › Combos tienen receta y se agotan por sus componentes (decisión de Norman, 17/11/2026)
    enPrograma() { const i = sesion.empresaInfo; return !!(i && i.es_local); },   // 4.40: en el programa la casilla del agotado no se muestra (NegocioPublico no viaja)
    textoVista() { const v = this.vista; if (!v || !v.bodega) return ''; const a = +v.agotarian || 0, t = +v.total || 0; return 'Con las existencias de ahora, ' + a + ' de ' + t + (t === 1 ? ' producto del catálogo' : ' productos del catálogo') + (a === 1 ? ' se mostraría agotado.' : ' se mostrarían agotados.'); },
    textoSinRegistro() { const v = this.vista; const m = v && v.bodega ? +v.sin_registro || 0 : 0; if (!m) return ''; return m === 1 ? '1 producto no tiene existencias registradas en ' + this.bodegaAgotado + ': seguirá disponible hasta que se le cargue una cantidad.' : m + ' productos no tienen existencias registradas en ' + this.bodegaAgotado + ': seguirán disponibles hasta que se les cargue una cantidad.'; },
    masCuales() { const v = this.vista; return v && Array.isArray(v.ejemplos) ? Math.max(0, (+v.agotarian || 0) - v.ejemplos.length) : 0; },
  },
  methods: {
    fechaHora,
    async cargar() { try { this.n = await cargarNegocio(); } catch (e) { toast(e.message, 'err'); } this.cargarVista(); },
    // 4.40: vista previa del agotado según existencias; sin el permiso del catálogo o si no responde, la pantalla sigue sin ella
    async cargarVista() {
      this.verCuales = false;
      if (this.enPrograma || !sesion.puede('catalogos')) { this.vista = null; return; }   // 4.40: en el programa no se pide
      this.vistaError = false;
      try { this.vista = await api('/api/pedidos/catalogo/agotado-vista'); } catch { this.vista = null; this.vistaError = true; }   // 4.40: si falla, se avisa
    },
    async guardar() {
      if (!(this.n.slug || '').trim()) return toast('Primero escriba la dirección de su página en Ventas en línea › Mi página', 'err');
      this.guardando = true;
      try { this.n = await guardarNegocio(this.n, { tilopay_key: this.tl.key, tilopay_user: this.tl.user, tilopay_password: this.tl.password, agotado_auto: !!this.n.agotado_auto }); this.tl = { key: null, user: null, password: null }; toast('Guardado', 'ok'); }   // 4.40: solo esta pantalla manda la opción
      catch (e) { toast(e.message, 'err'); this.guardando = false; return false; }
      this.guardando = false; this.cargarVista(); return true;   // 4.40: si cambió la caja, cambia la bodega de la vista previa
    },
    async probarTilopay() {
      if (!(await this.guardar())) return;
      this.probando = true;
      try { const r = await api('/api/pedidos/negocio/tilopay/probar', { method: 'POST', body: {} }); this.n.tilopay.probado = r.probado; toast('Tilopay respondió bien: las llaves del negocio funcionan', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.probando = false;
    },
    // avisos en este dispositivo (3.58): permiso del navegador + interruptor guardado en este celular o computadora
    async cambiarAvisos(v) {
      if (v) { const ok = await activarAvisos(); this.permiso = permisoAvisos(); this.avisos = ok; toast(ok ? 'Avisos activados en este dispositivo' : (this.permiso === 'denied' ? 'El navegador tiene bloqueadas las notificaciones para este sitio: permítalas en la configuración del sitio' : 'No se pudo activar'), ok ? 'ok' : 'err'); }
      else { desactivarAvisos(); this.avisos = false; toast('Avisos desactivados en este dispositivo', 'ok'); }
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Configuración de ventas en línea" sub="Cómo entrega, cuánto cobra por el envío, a qué caja entran los pedidos, cómo cobra en línea y cómo se entera de cada pedido." :crumbs="[{label:'FISITAAP'},{label:'Configuración'}]">
      <button class="btn" @click="guardar()" :disabled="guardando || !n">Guardar</button>
    </PageHead>
    <template v-if="n">
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Formas de entrega</h2>
          <div style="display:flex;flex-direction:column;gap:8px"><Toggle v-model="n.acepta_recoger" label="Para recoger en el local"></Toggle><Toggle v-model="n.acepta_domicilio" label="A domicilio (con costo de envío fijo; las zonas llegan con FISITAAP · Entregas)"></Toggle><Toggle v-model="n.acepta_coordinado" label="Envío por coordinar (el negocio y el cliente acuerdan el envío)"></Toggle></div>
          <div class="grid cols-2" style="margin-top:10px">
            <Field label="Costo de envío a domicilio (con IVA)"><input type="number" min="0" step="100" v-model.number="n.costo_envio"></Field>
            <Field label="Pedido mínimo (con impuestos)" help="0 = sin mínimo"><input type="number" min="0" step="500" v-model.number="n.minimo_pedido"></Field>
            <Field label="Aviso al cliente al pedir" style="grid-column:1/-1" help="Formas de pago, tiempos, zonas…"><input v-model="n.nota_cliente" maxlength="300" placeholder="Pagamos con SINPE, efectivo o tarjeta al recibir. Entregas solo en el centro."></Field>
          </div>
        </div>
        <div class="card"><h2>Caja y avisos al negocio</h2>
          <Field label="Caja que recibe los pedidos" help="Al confirmar, el pedido entra como cuenta en espera de esta caja y a su monitor de preparación"><select v-model="n.terminal_id"><option :value="null">— La primera caja —</option><option v-for="t in terms" :key="t.id" :value="t.id">{{t.nombre}}</option></select></Field>
          <div v-if="enPrograma" style="margin:4px 0 10px;padding:10px 12px;border:1px solid var(--line);border-radius:10px" data-agotado-auto-programa><b>Mostrar agotado según existencias</b><p class="small muted" style="margin:6px 0 0">Esto se hace en la página web.</p></div>
          <div v-else style="margin:4px 0 10px;padding:10px 12px;border:1px solid var(--line);border-radius:10px" data-agotado-auto>
            <Toggle v-model="n.agotado_auto" label="Mostrar agotado según existencias"></Toggle>
            <p class="small muted" style="margin:6px 0 0">{{ayudaAgotado}}</p>
            <p class="small" style="margin:6px 0 0" v-if="textoVista" data-agotado-vista>{{textoVista}} <a href="#" v-if="vista.agotarian > 0 && vista.ejemplos && vista.ejemplos.length" @click.prevent="verCuales = !verCuales">{{verCuales ? 'Ocultar' : 'Ver cuáles'}}</a></p>
            <ul class="small muted" style="margin:4px 0 0;padding-left:18px" v-if="verCuales && vista && vista.ejemplos"><li v-for="(x, i) in vista.ejemplos" :key="i">{{x}}</li><li v-if="masCuales">y {{masCuales}} más</li></ul>
            <p class="small muted" style="margin:6px 0 0" v-if="textoSinRegistro">{{textoSinRegistro}}</p>
            <p class="small" style="margin:6px 0 0;color:var(--warn)" v-if="vistaError" data-agotado-vista-error>No se pudo calcular la vista previa en este momento. Vuelva a abrir esta pantalla para intentarlo de nuevo.</p>
            <p class="small" style="margin:6px 0 0;color:var(--warn)" v-if="n.agotado_auto && vista && !vista.bodega" data-agotado-sin-bodega>No hay una bodega activa para revisar existencias. Elija una en Punto de venta › Configuración, en la caja que recibe los pedidos.</p>
            <p class="small" style="margin:6px 0 0;color:var(--warn)" v-if="n.agotado_auto && vista && vista.pruebas" data-agotado-pruebas>La empresa está en ambiente de pruebas de Hacienda: las ventas no rebajan existencias, así que el catálogo no cambiará con ventas de prueba.</p>
            <p class="small muted" style="margin:6px 0 0" v-if="n.agotado_auto" data-agotado-programa>Si también se vende en el programa de escritorio: las ventas del programa se reflejan aquí cuando suben a la web. Las compras, ajustes y traslados de inventario deben hacerse en la web; los que se hacen en el programa no llegan al catálogo.</p>
          </div>
          <Field label="Correo de aviso por pedido" help="Vacío = el correo de la empresa. Necesita el correo saliente configurado"><input v-model="n.correo_aviso" maxlength="120" type="email"></Field>
          <div style="margin-top:8px;padding:10px 12px;border:1px solid var(--line);border-radius:10px">
            <Toggle :modelValue="avisos" @update:modelValue="cambiarAvisos" label="Avisos de pedido nuevo en este dispositivo (sonido y notificación)"></Toggle>
            <p class="small muted" style="margin:6px 0 0">Se activa por celular o computadora: con el sistema abierto (aunque esté en otra pestaña), cada pedido nuevo suena y muestra una notificación que abre Pedidos.<span v-if="permiso==='denied'"> El navegador tiene bloqueadas las notificaciones de este sitio: permítalas en la configuración del sitio (el candado junto a la dirección).</span><span v-else-if="permiso==='no_soportado'"> Este navegador no admite notificaciones.</span></p>
          </div>
          <p class="small muted" style="margin:6px 0 0">La caja también avisa con sonido cuando entra un pedido. Cada pedido se cobra en la caja como cualquier venta (tiquete o factura electrónica), así queda dentro del cierre del día.</p>
        </div>
      </div>
      <div class="card" style="margin-top:12px"><h2>SINPE Móvil con comprobante</h2>
        <p class="small muted" style="margin:0 0 8px">El cliente elige «SINPE Móvil» en el carrito, transfiere al número indicado y sube la foto del comprobante. En Pedidos usted ve el comprobante y marca «Pago verificado»: el pedido queda pagado también en la caja.</p>
        <div class="grid cols-3">
          <div style="display:flex;align-items:center"><Toggle v-model="n.pago_sinpe" label="Ofrecer SINPE Móvil en el carrito"></Toggle></div>
          <Field label="Número SINPE (8 dígitos)"><input v-model="n.sinpe_numero" maxlength="12" inputmode="numeric" placeholder="88888888"></Field>
          <Field label="A nombre de" help="Como aparece en el banco, para que el cliente lo reconozca"><input v-model="n.sinpe_nombre" maxlength="80"></Field>
        </div>
      </div>
      <div class="card" style="margin-top:12px"><h2>Pago con tarjeta en línea y correos al cliente</h2>
        <p class="small muted" style="margin:0 0 8px">Con su propia cuenta de Tilopay el cliente paga desde el carrito y el dinero entra directo a su cuenta. Las llaves están en su panel de Tilopay › Integración con plataformas; aquí se guardan cifradas y nunca se muestran completas.</p>
        <div class="grid cols-2">
          <Field label="Llave (key) de Tilopay" :help="n.tilopay.llave ? 'Guardada: ' + n.tilopay.llave + '. Escriba otra para cambiarla' : 'Sin llave guardada'"><input v-model="tl.key" maxlength="200" autocomplete="off" placeholder="1234-5678-9012-3456"></Field>
          <Field label="Usuario del API" :help="n.tilopay.usuario_guardado ? 'Guardado. Escriba otro para cambiarlo' : 'Sin usuario guardado'"><input v-model="tl.user" maxlength="120" autocomplete="off"></Field>
          <Field label="Clave del API" :help="n.tilopay.clave_guardada ? 'Guardada. Escriba otra para cambiarla' : 'Sin clave guardada'"><input v-model="tl.password" type="password" maxlength="200" autocomplete="new-password"></Field>
          <div style="display:flex;flex-direction:column;gap:8px;justify-content:center"><Toggle v-model="n.pago_tarjeta" label="Ofrecer «pagar con tarjeta» en el carrito"></Toggle><Toggle v-model="n.correo_cliente" label="Enviar correos al cliente por cada paso del pedido"></Toggle></div>
        </div>
        <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px"><button class="btn sm sec" @click="probarTilopay" :disabled="probando || guardando">{{probando ? 'Probando…' : 'Guardar y probar la conexión'}}</button><span class="small muted" v-if="n.tilopay.probado">Última prueba correcta: {{fechaHora(n.tilopay.probado)}}</span><span class="small muted" v-else-if="n.tilopay.listo">Llaves completas, todavía sin probar.</span></div>
        <p class="small muted" style="margin:8px 0 0">El pedido pagado entra a la caja ya confirmado y con el pago aplicado. Si cancela un pedido pagado, el reembolso se pide a Tilopay. Los correos al cliente salen con el correo saliente de la empresa.</p>
      </div>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
