// FISITAAP › Mi página (3.57; completa en 3.58): la página pública del negocio: nombre público, marca, portada, textos, color, contacto
// y redes, horario y estado, y desde 3.58 la presentación (catálogo con fotos o menú por secciones), «Nosotros», galería, tema claro u
// oscuro, tipo de letra, datos para buscadores, píxeles de Google y Meta, y el dominio propio (o el subdominio en el dominio del sistema).
// Lo que se publica (ítems) está en FISITAAP › Catálogo o menú; formas de entrega, caja y cobro en FISITAAP › Configuración.
// 4.40: la guía dice que el agotado puede ser a mano o, si se activa, según existencias.
import { api, toast, fechaHora } from '../../api.js';
import { store, sesion } from '../../app.js';
import { cargarNegocio, guardarNegocio, DIAS } from './_negocio.js';

const FUENTES = [['', 'La del sistema'], ['inter', 'Inter (moderna)'], ['manrope', 'Manrope (redondeada)'], ['clasica', 'Clásica (con serifas)']];

export default {
  props: ['params'],
  data() { return { n: null, guardando: false, marcas: [], DIAS, FUENTES, subiendo: false, subiendoFoto: false, copiado: false, tab: 'basico', dns: null, verificando: false }; },
  computed: {
    horarios() { return this.n ? this.DIAS.map((d, i) => ({ dia: d, i, h: this.n.horarios[i] })) : []; },
    sugerido() { const e = store.empresa || {}; return String(e.nombre_comercial || e.nombre || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); },
    hostBase() { return (this.n && this.n.host_base) || this.sistemaCfg().dominio; },
  },
  methods: {
    fechaHora,
    async cargar() {
      try { const n = await cargarNegocio(); if (!n.slug) n.slug = this.sugerido; this.n = n; } catch (e) { toast(e.message, 'err'); }
      try { this.marcas = await api('/api/marcas'); } catch { this.marcas = []; }
    },
    toggleDia(i) { this.n.horarios[i] = this.n.horarios[i] ? null : ['08:00', '20:00']; },
    copiarHorario() { const h = this.n.horarios.find(Boolean) || ['08:00', '20:00']; this.n.horarios = this.n.horarios.map(() => [h[0], h[1]]); },
    async guardar(publicar) {
      const n = this.n; if (publicar !== undefined) n.activo = publicar;
      if (!(n.slug || '').trim()) return toast('Escriba el nombre público (la dirección de su página)', 'err');
      this.guardando = true;
      try { this.n = await guardarNegocio(n); toast(this.n.activo ? 'Página publicada en ' + (this.n.url_publica || this.n.url) : 'Guardado (la página no está publicada)', 'ok'); }
      catch (e) { toast(e.message, 'err'); this.guardando = false; return false; }
      this.guardando = false; return true;
    },
    async subirPortada(ev) {
      const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = '';
      if (f.size > 4 * 1024 * 1024) return toast('La portada no puede pasar de 4 MB', 'err');
      this.subiendo = true;
      try { const fd = new FormData(); fd.append('archivo', f, f.name); const r = await api('/api/pedidos/negocio/portada', { method: 'POST', body: fd }); this.n.portada = r.portada; toast('Portada actualizada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
    async quitarPortada() { try { await api('/api/pedidos/negocio/portada', { method: 'DELETE' }); this.n.portada = null; } catch (e) { toast(e.message, 'err'); } },
    // galería (3.58; 4.4 sin tope): las fotos del slider del catálogo
    async subirFoto(ev) {
      const fs = Array.from(ev.target.files || []); ev.target.value = ''; if (!fs.length) return;
      this.subiendoFoto = true;
      for (const f of fs) {
        if (f.size > 4 * 1024 * 1024) { toast(f.name + ': cada foto puede pesar hasta 4 MB', 'err'); continue; }
        try { const fd = new FormData(); fd.append('archivo', f, f.name); const r = await api('/api/pedidos/negocio/galeria', { method: 'POST', body: fd }); this.n.galeria = r.galeria; }
        catch (e) { toast(e.message, 'err'); break; }
      }
      this.subiendoFoto = false;
    },
    async quitarFoto(g) { try { const r = await api('/api/pedidos/negocio/galeria/' + encodeURIComponent(g.nombre), { method: 'DELETE' }); this.n.galeria = r.galeria; } catch (e) { toast(e.message, 'err'); } },
    // dominio propio (3.58)
    async verificarDominio() {
      if (!(await this.guardar())) return;
      this.verificando = true; this.dns = null;
      try { this.dns = await api('/api/pedidos/negocio/dominio/verificar', { method: 'POST', body: {} }); } catch (e) { toast(e.message, 'err'); }
      this.verificando = false;
    },
    copiar(texto) { try { navigator.clipboard.writeText(texto || this.n.url_publica || this.n.url); this.copiado = true; setTimeout(() => { this.copiado = false; }, 2000); } catch { toast('Copie el enlace a mano', 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Mi página" sub="La página pública de su negocio: portada, textos, fotos, contacto, horario, apariencia, buscadores y dominio. Los clientes entran, ven su catálogo o menú y piden desde el celular." :crumbs="[{label:'FISITAAP'},{label:'Mi página'}]">
      <a class="btn ghost" :href="n && (n.url_publica || n.url)" target="_blank" rel="noopener" v-if="n && n.activo && n.url">Ver mi página</a>
      <button class="btn sec" @click="guardar()" :disabled="guardando || !n">Guardar</button>
      <button class="btn" @click="guardar(true)" :disabled="guardando || !n" v-if="n && !n.activo">Publicar</button><button class="btn danger" @click="guardar(false)" :disabled="guardando || !n" v-else-if="n">Despublicar</button>
    </PageHead>
    <template v-if="n">
      <div class="alert" :class="n.activo ? 'ok' : 'warn'" style="margin-bottom:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <span v-if="n.activo">Publicada en <b>{{n.url_publica || n.url}}</b><span v-if="n.url_publica && n.url_publica !== n.url"> (también {{n.url}})</span> · {{n.visibles}} ítem(s) en el catálogo · {{n.abierto.abierto ? 'abierto ahora' : (n.abierto.motivo || 'cerrado ahora')}}</span>
        <span v-else>La página no está publicada: nadie la ve hasta que pulse «Publicar». Elija qué se vende en <a href="#/fisitaap/catalogo">Catálogo o menú</a> ({{n.visibles}} ítem(s) marcados).</span>
        <button class="btn sm ghost" v-if="n.activo" @click="copiar()">{{copiado ? 'Copiado' : 'Copiar enlace'}}</button>
      </div>
      <div class="tabs" style="margin-bottom:12px">
        <button class="tab" :class="{on: tab==='basico'}" @click="tab='basico'">Portada y textos</button>
        <button class="tab" :class="{on: tab==='contacto'}" @click="tab='contacto'">Contacto y horario</button>
        <button class="tab" :class="{on: tab==='fotos'}" @click="tab='fotos'">Fotos y Nosotros</button>
        <button class="tab" :class="{on: tab==='apariencia'}" @click="tab='apariencia'">Apariencia</button>
        <button class="tab" :class="{on: tab==='buscadores'}" @click="tab='buscadores'">Buscadores y píxeles</button>
        <button class="tab" :class="{on: tab==='dominio'}" @click="tab='dominio'">Dominio</button>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='basico'">
        <div class="card"><h2>Nombre público y portada</h2>
          <Field label="Dirección de la página" req :help="'Solo letras, números y guiones. Queda en ' + hostBase + '/' + (n.slug || 'nombre')"><div class="row" style="gap:6px;align-items:center"><span class="small muted">{{hostBase}}/</span><input v-model="n.slug" maxlength="60" style="flex:1" placeholder="soda-el-punto"></div></Field>
          <Field label="Nombre que ve el público" help="Vacío = el nombre comercial de la empresa (o de la marca elegida)"><input v-model="n.nombre" maxlength="80"></Field>
          <Field label="Marca (logo y nombre)" help="De Configuración › Marcas y logos" v-if="marcas.length"><select v-model="n.marca_id"><option :value="null">— La empresa —</option><option v-for="m in marcas" :key="m.id" :value="m.id">{{m.nombre}}</option></select></Field>
          <Field label="Portada" help="Foto ancha (JPG, PNG o WEBP, hasta 4 MB)"><div class="row" style="gap:8px;align-items:center;flex-wrap:wrap"><img v-if="n.portada" :src="n.portada" alt="" style="height:70px;border-radius:8px;object-fit:cover;max-width:220px"><label class="btn sm sec" style="cursor:pointer">{{subiendo ? 'Subiendo…' : (n.portada ? 'Cambiar' : 'Subir portada')}}<input type="file" accept="image/*" style="display:none" @change="subirPortada" :disabled="subiendo"></label><button class="btn sm ghost" v-if="n.portada" @click="quitarPortada">Quitar</button></div></Field>
          <Field label="Frase de bienvenida"><input v-model="n.bienvenida" maxlength="200" placeholder="¡Pida en línea y recoja sin fila!"></Field>
          <Field label="Descripción corta"><textarea rows="2" v-model="n.descripcion" maxlength="600" placeholder="Comida casera, café y repostería en el centro de Liberia."></textarea></Field>
        </div>
        <div class="card"><h2>Cómo funciona</h2>
          <ol class="small" style="margin:0;padding-left:18px;line-height:1.7">
            <li>En <a href="#/fisitaap/catalogo">Catálogo o menú</a> marque qué ítems del Inventario se venden en la página, cuáles van destacados y cuáles están agotados (a mano o, si se activa, según existencias).</li>
            <li>En <a href="#/fisitaap/configuracion">Configuración</a> elija las formas de entrega, el costo de envío, la caja que recibe los pedidos y cómo cobra (tarjeta, SINPE Móvil o al recibir).</li>
            <li>En las pestañas de arriba complete fotos, «Nosotros», apariencia y datos para buscadores. Si tiene dominio propio, conéctelo en «Dominio».</li>
            <li>Publique y comparta el enlace en redes y WhatsApp. Los pedidos entran a <a href="#/fisitaap/pedidos">Pedidos</a> y a la caja; active los avisos en el celular en <a href="#/fisitaap/configuracion">Configuración</a>.</li>
          </ol>
        </div>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='contacto'">
        <div class="card"><h2>Contacto y redes</h2>
          <div class="grid cols-2">
            <Field label="WhatsApp (8 dígitos)" help="El pedido arma un mensaje listo para enviar a este número"><input v-model="n.whatsapp" maxlength="12" inputmode="numeric" placeholder="88888888"></Field>
            <Field label="Teléfono"><input v-model="n.telefono" maxlength="12" inputmode="numeric"></Field>
            <Field label="Instagram"><input v-model="n.redes.instagram" maxlength="60" placeholder="@minegocio"></Field>
            <Field label="Facebook"><input v-model="n.redes.facebook" maxlength="120" placeholder="enlace o nombre de la página"></Field>
            <Field label="Enlace de ubicación (Waze o Google Maps)" style="grid-column:1/-1"><input v-model="n.redes.maps" maxlength="200" placeholder="https://maps.app.goo.gl/…"></Field>
            <Field label="Dirección en texto" style="grid-column:1/-1"><input v-model="n.direccion" maxlength="200"></Field>
          </div>
        </div>
        <div class="card"><h2>Horario y estado</h2>
          <p class="small muted" style="margin:0 0 8px">Fuera del horario la página se ve, pero no recibe pedidos. Sin horarios, siempre recibe.</p>
          <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:6px" v-for="h in horarios" :key="h.i"><label class="row small" style="gap:6px;cursor:pointer;width:110px"><input type="checkbox" :checked="!!h.h" @change="toggleDia(h.i)"> {{h.dia}}</label><template v-if="h.h"><input type="time" class="inp" v-model="h.h[0]" style="width:110px"><span class="small muted">a</span><input type="time" class="inp" v-model="h.h[1]" style="width:110px"></template><span class="small muted" v-else>cerrado</span></div>
          <button class="btn sm ghost" @click="copiarHorario">Mismo horario todos los días</button>
          <Field label="Estado manual" style="margin-top:10px" help="Fuerza abierto o cerrado sin tocar el horario"><select v-model="n.abierto_manual"><option :value="null">Según el horario</option><option :value="true">Abierto siempre</option><option :value="false">Cerrado por ahora (vacaciones, sin existencias…)</option></select></Field>
          <Field label="Tiempo estimado" help="Se muestra al cliente"><input v-model="n.tiempo_estimado" maxlength="40" placeholder="30 a 45 min"></Field>
        </div>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='fotos'">
        <div class="card"><h2>Galería <small>las fotos del slider del catálogo o menú; sin límite</small></h2>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:8px"><div v-for="g in n.galeria" :key="g.nombre" style="position:relative"><img :src="g.url" alt="" style="width:110px;height:110px;object-fit:cover;border-radius:10px;display:block"><button class="btn sm ghost" style="position:absolute;top:4px;right:4px;background:#fff" @click="quitarFoto(g)" title="Quitar">✕</button></div></div>
          <label class="btn sm sec" style="cursor:pointer">{{subiendoFoto ? 'Subiendo…' : '+ Agregar fotos'}}<input type="file" accept="image/*" multiple style="display:none" @change="subirFoto" :disabled="subiendoFoto"></label>
          <p class="small muted" style="margin:6px 0 0">JPG, PNG o WEBP, hasta 4 MB cada una; recomendado 1600 × 900 px (horizontal). Fotos del local, de los platos o de los productos. Se guardan al subirlas (no hace falta pulsar Guardar).</p>
        </div>
        <div class="card"><h2>Nosotros</h2>
          <Field label="Texto «Nosotros»" help="Quiénes son, desde cuándo, qué los hace distintos. Hasta 2000 caracteres; los saltos de línea se respetan"><textarea rows="9" v-model="n.nosotros" maxlength="2000" placeholder="Somos una soda familiar en el centro de Liberia desde 2009…"></textarea></Field>
        </div>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='apariencia'">
        <div class="card"><h2>Presentación</h2>
          <Field label="Cómo se muestran los ítems"><select v-model="n.presentacion"><option value="catalogo">Catálogo: cuadrícula con foto grande (tiendas, productos)</option><option value="menu">Menú: lista por sección con foto pequeña (restaurantes, sodas)</option></select></Field>
          <p class="small muted" style="margin:0">Las secciones son las categorías del Inventario (Configuración › Categorías). En ambos casos el cliente toca el ítem para ver opciones, nota y cantidad.</p>
        </div>
        <div class="card"><h2>Colores y letra</h2>
          <div class="grid cols-2">
            <Field label="Color principal"><input type="color" v-model="n.color" style="width:60px;height:36px;padding:2px"></Field>
            <Field label="Tema"><select v-model="n.tema"><option value="claro">Claro</option><option value="oscuro">Oscuro</option></select></Field>
            <Field label="Tipo de letra" style="grid-column:1/-1"><select v-model="n.fuente"><option v-for="f in FUENTES" :key="f[0]" :value="f[0]">{{f[1]}}</option></select></Field>
          </div>
          <p class="small muted" style="margin:0">Guarde y abra «Ver mi página» para revisar cómo queda en el celular.</p>
        </div>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='buscadores'">
        <div class="card"><h2>Datos para buscadores</h2>
          <Field label="Título" help="Lo que muestra Google como título. Vacío = nombre del negocio · Pedidos en línea"><input v-model="n.seo_titulo" maxlength="70" placeholder="Soda El Punto · Comida casera en Liberia"></Field>
          <Field label="Descripción" help="Hasta 160 caracteres. Vacío = la descripción corta"><textarea rows="2" v-model="n.seo_descripcion" maxlength="160"></textarea></Field>
          <Field label="Palabras clave" help="Separadas por coma"><input v-model="n.seo_palabras" maxlength="200" placeholder="soda, casados, almuerzos, Liberia"></Field>
          <p class="small muted" style="margin:0">La página ya lleva los datos estructurados (nombre, teléfono, dirección, horario) y la imagen para compartir en WhatsApp y redes.</p>
        </div>
        <div class="card"><h2>Píxeles de medición</h2>
          <Field label="Etiqueta de Google (Analytics o Ads)" help="Tiene la forma G-XXXXXXXXXX (Analytics) o AW-XXXXXXXXX (Ads). Vacío = sin medición"><input v-model="n.google_id" maxlength="30" class="mono" placeholder="G-ABC123DEF4"></Field>
          <Field label="Píxel de Meta (Facebook e Instagram)" help="Número de 15 o 16 dígitos del administrador de eventos"><input v-model="n.pixel_meta" maxlength="20" class="mono" inputmode="numeric" placeholder="123456789012345"></Field>
          <p class="small muted" style="margin:0">Con esto Google y Meta registran las visitas, los ítems agregados al carrito y cada pedido enviado (con su monto), para medir las campañas. Solo se cargan en su página pública, nunca dentro del sistema.</p>
        </div>
      </div>
      <div class="grid cols-2" style="align-items:start" v-show="tab==='dominio'">
        <div class="card"><h2>Dominio propio</h2>
          <Field label="Su dominio" help="Por ejemplo www.minegocio.cr. Déjelo vacío si no tiene"><input v-model="n.dominio" maxlength="100" placeholder="www.minegocio.cr"></Field>
          <div class="alert" :class="n.dominio_verificado ? 'ok' : 'info'" v-if="n.dominio" style="margin:8px 0">
            <template v-if="n.dominio_verificado">Verificado: su página responde en <b>https://{{n.dominio}}</b> desde el {{fechaHora(n.dominio_verificado)}}. Los enlaces de los correos al cliente ya usan su dominio.</template>
            <template v-else>Pendiente: todavía no ha llegado ninguna visita por <b>{{n.dominio}}</b>. Complete los pasos de la derecha; en cuanto entre la primera visita queda verificado solo.</template>
          </div>
          <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap"><button class="btn sm sec" @click="verificarDominio" :disabled="verificando || !n.dominio">{{verificando ? 'Revisando…' : 'Guardar y revisar el DNS'}}</button><span class="small" v-if="dns" :class="dns.estado==='otro' || dns.estado==='sin_dns' ? 'danger' : 'muted'">{{dns.mensaje}}</span></div>
          <h2 style="margin-top:16px">Subdominio gratis</h2>
          <p class="small" style="margin:0" v-if="sesion.tieneFuncion('subdominio')">Su página también responde en <b>{{n.url_subdominio || (n.slug + '.' + hostBase)}}</b>; puede compartir esa dirección o <b>{{n.url}}</b>.</p>
          <p class="small muted" style="margin:0" v-else>Sin dominio propio, use <b>{{n.url}}</b>. El subdominio {{n.slug}}.{{hostBase}} se habilita por empresa cuando el servidor tenga el comodín configurado (pídalo a soporte).</p>
        </div>
        <div class="card"><h2>Cómo conectar su dominio</h2>
          <ol class="small" style="margin:0;padding-left:18px;line-height:1.7">
            <li>Escriba el dominio a la izquierda y guarde.</li>
            <li>En el proveedor donde compró el dominio, cree un registro <b>CNAME</b> con nombre <b>www</b> que apunte a <b>{{hostBase}}</b> (si quiere también sin «www», un registro <b>A</b> a la dirección del servidor; pídala a soporte).</li>
            <li>Escríbanos a soporte con el dominio: lo agregamos como alias del sitio y le emitimos el certificado de seguridad (https). Tarda unas horas.</li>
            <li>Pulse «Guardar y revisar el DNS» para confirmar que el registro ya apunta aquí. La primera visita por su dominio lo deja verificado y desde entonces los correos a sus clientes usan su dirección.</li>
          </ol>
          <p class="small muted" style="margin:8px 0 0">El panel del sistema y las facturas siguen en {{hostBase}}; solo la página de pedidos se ve en su dominio.</p>
        </div>
      </div>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
