// Recursos humanos › Planilla: genera la nómina de un período para los empleados activos (horas, extras, feriados, días no pagados,
// otros ingresos y deducciones editables; las ausencias, incapacidades y conceptos fijos del período se aplican solos), la guarda,
// la marca pagada (sale de la cuenta principal de Bancos salvo que elija otra), envía los comprobantes y la exporta.
import { api, abrirArchivo, money, fmt, fecha, hoy, toast, mock, sumarDias } from '../../api.js';
import { activos, empleados, nombreCompleto, PERIODOS, periodoNombre, paraServidor, tablas, ausenciasEn, conceptosEn, horasExtraEn, aplicarSaldos, planillas as planillasGuardadas, esPagada, esComplementaria, diasEntre, FACTOR_MES, refrescarDelServidor } from './_datos.js';
import { store, sesion } from '../../app.js';
import { cuentaPrincipal, cuentasParaMovimientos, registrarMovimientoBanco, revertirMovimientoBanco, refUnica, problemaMoneda } from '../bancos/cuentas.js';
import { descargarReporte, registrarExportable, descargarTabla, elegirFormato } from '../reportes/_montos.js';

// 4.7: también las líneas nuevas del cálculo (la diferencia de la cuota obrera por la base mínima: la del trabajador en «obrero» y la
// que paga la empresa en «patrono»; el INS aparte de la póliza); una clave sin nombre se muestra legible, no cruda (etiqueta)
const OBR = { sem: 'SEM', ivm: 'IVM', banco_popular: 'Banco Popular', base_minima: 'Dif. base mínima' };
const PAT = { sem: 'SEM', ivm: 'IVM', banco_popular: 'Banco Popular', fodesaf: 'FODESAF', imas: 'IMAS', ina: 'INA', fcl: 'FCL', rop_opc: 'ROP–OPC', rop_bp: 'ROP–BP', rop: 'ROP', ins_riesgos: 'INS riesgos', ins_adicional: 'INS aparte', base_minima_obrera: 'Base mín. obrera' };
const etiqueta = (nombres, k) => nombres[k] || String(k).replace(/_/g, ' ').replace(/^./, c => c.toUpperCase());
const PROV = { aguinaldo: 'Aguinaldo', vacaciones: 'Vacaciones', cesantia: 'Cesantía', preaviso: 'Preaviso', otros: 'Otros' };
// 4.21: quién generó (o corrigió) la planilla y quién la aprobó, con su fecha; los anota el servidor. Vacío en las planillas de antes
const selloDe = (p, k, texto) => (p && p[k + '_por'] ? texto + ' por ' + p[k + '_por'] + (p[k + '_en'] ? ' el ' + fecha(p[k + '_en']) : '') : '');
const sellosDe = p => [selloDe(p, 'generada', 'Generada'), selloDe(p, 'aprobada', 'Aprobada')].filter(Boolean).join(' · ');
// Planilla en PDF o Word: resumen por empleado, deducciones del trabajador, cargas patronales y reservas, con totales.
export function documentoPlanilla(p, formato) {
  const M = v => money(v || 0), filas = p.filas || [], tot = p.totales || {};
  const suma = k => filas.reduce((s, f) => s + (+f[k] || 0), 0), sumaDe = (obj, k) => filas.reduce((s, f) => s + (+((f[obj] || {})[k]) || 0), 0);
  const claves = (obj, orden) => { const set = new Set(); for (const f of filas) for (const k of Object.keys(f[obj] || {})) set.add(k); return [...Object.keys(orden).filter(k => set.has(k)), ...[...set].filter(k => !orden[k])]; };
  const hayAus = filas.some(f => +f.dias_ausencia), hayFer = filas.some(f => +f.feriado), hayNoSal = filas.some(f => +f.no_salariales);
  const resumen = { titulo: 'Resumen por empleado', columnas: [{ key: 'nombre', label: 'Empleado' }, { key: 'horas', label: 'Horas', num: true }, ...(hayAus ? [{ key: 'ausencia', label: 'Días no pag.', num: true }] : []), { key: 'bruto', label: 'Bruto', num: true }, { key: 'total_obrero', label: 'CCSS trabajador', num: true }, { key: 'renta', label: 'Renta', num: true }, { key: 'otras_deducciones', label: 'Otras ded.', num: true }, ...(hayNoSal ? [{ key: 'no_salariales', label: 'No salarial', num: true }] : []), { key: 'neto', label: 'Neto', num: true }, { key: 'total_patronal', label: 'Cargas patronales', num: true }, { key: 'total_provisiones', label: 'Reserva', num: true }, { key: 'costo_total', label: 'Costo total', num: true }],
    filas: filas.map(f => ({ nombre: f.nombre, horas: fmt(f.horas, 1) + (f.horas_extra ? ' +' + fmt(f.horas_extra, 1) : '') + (f.horas_feriado ? ' ✦' + fmt(f.horas_feriado, 1) : ''), ausencia: fmt(f.dias_ausencia || 0, 1), bruto: M(f.bruto), total_obrero: M(f.total_obrero), renta: M(f.renta), otras_deducciones: M(f.otras_deducciones), no_salariales: M(f.no_salariales), neto: M(f.neto), total_patronal: M(f.total_patronal), total_provisiones: M(f.total_provisiones), costo_total: M(f.costo_total) })),
    totales: [{ t: 'Bruto', v: M(tot.bruto) }, ...(hayNoSal ? [{ t: 'Pagos no salariales', v: M(tot.no_salariales) }] : []), { t: 'Neto a pagar a los empleados', v: M(tot.neto) }, { t: 'Cargas patronales', v: M(tot.total_patronal) }, { t: 'Reservas', v: M(tot.total_provisiones) }, { t: 'Costo total', v: M(tot.costo_total) }],
    nota: hayFer ? 'Horas: ordinarias +extra ✦feriado.' : null };
  const detalle = (obj, nombres, titulo, extra) => { const ks = claves(obj, nombres); return { titulo, columnas: [{ key: 'nombre', label: 'Empleado' }, ...ks.map(k => ({ key: k, label: etiqueta(nombres, k), num: true })), ...(extra || []).map(x => ({ key: x.key, label: x.label, num: true })), { key: '_total', label: 'Total', num: true }],
    filas: filas.map(f => ({ nombre: f.nombre, ...Object.fromEntries(ks.map(k => [k, M((f[obj] || {})[k])])), ...Object.fromEntries((extra || []).map(x => [x.key, M(f[x.key])])), _total: M(ks.reduce((s, k) => s + (+((f[obj] || {})[k]) || 0), 0) + (extra || []).reduce((s, x) => s + (+f[x.key] || 0), 0)) })),
    totales: [...ks.map(k => ({ t: etiqueta(nombres, k), v: M(sumaDe(obj, k)) })), ...(extra || []).map(x => ({ t: x.label, v: M(suma(x.key)) }))] };
  };
  const secciones = [resumen, detalle('obrero', OBR, 'Deducciones del trabajador', [{ key: 'renta', label: 'Renta' }, { key: 'otras_deducciones', label: 'Otras' }]), detalle('patrono', PAT, 'Cargas patronales'), detalle('provisiones', PROV, 'Reservas (aguinaldo, vacaciones, cesantía)')];
  const conceptos = []; for (const f of filas) { for (const d of f.detalle_deducciones || []) conceptos.push({ nombre: f.nombre, tipo: 'Deducción', concepto: d.concepto, monto: M(d.monto) }); for (const d of f.detalle_ingresos || []) conceptos.push({ nombre: f.nombre, tipo: d.salarial === false ? 'Ingreso no salarial' : 'Ingreso', concepto: d.concepto, monto: M(d.monto) }); }
  if (conceptos.length) secciones.push({ titulo: 'Deducciones e ingresos aplicados', columnas: [{ key: 'nombre', label: 'Empleado' }, { key: 'tipo', label: 'Tipo' }, { key: 'concepto', label: 'Concepto' }, { key: 'monto', label: 'Monto', num: true }], filas: conceptos });
  // 4.7: la planilla complementaria lo dice en el título, el subtítulo y la nota (pagos adicionales del período de la original)
  const comp = p.complementaria ? 'Complementaria de ' + String(p.referencia_numero || 'otra planilla').slice(0, 20) : '';
  const notaComp = comp ? ' ' + comp + ': pagos adicionales del mismo período' + (filas.some(f => f.renta_complementaria) ? '; la renta se calculó con lo ya pagado en el mes y se retiene solo la diferencia.' : '.') : '';
  return descargarReporte(formato, { titulo: (comp ? 'Planilla complementaria ' : 'Planilla ') + p.numero + ' · ' + periodoNombre(p.periodo), subtitulo: (comp ? comp + ' · ' : '') + (p.empleados || filas.length) + ' empleados · estado: ' + (p.estado || 'Generada') + (p.pagada_en ? ' · pagada el ' + fecha(p.pagada_en) + (p.cuenta ? ' desde ' + p.cuenta : '') : '') + (sellosDe(p) ? ' · ' + sellosDe(p) : ''),
    periodo: fecha(p.desde) + ' al ' + fecha(p.hasta), kpis: [{ t: 'Salarios brutos', v: M(tot.bruto) }, { t: 'Neto a pagar', v: M(tot.neto) }, { t: 'Cargas patronales', v: M(tot.total_patronal) }, { t: 'Costo total', v: M(tot.costo_total) }],
    cols: [], rows: [], secciones, nota: 'Las cargas patronales y las retenciones se pagan aparte a la CCSS, al INS y a Hacienda. Montos en colones.' + notaComp, archivo: 'planilla_' + p.numero, privado: true });
}

const ocupadas = new Set();     // planillas con un pago o una eliminación en curso (evita el doble clic)
// 4.21: refs de los pagos mandados con la aprobación exigida que el servidor no confirmó. Si la respuesta se perdió y el pago sí quedó
// guardado, la planilla aparece pagada con una de estas refs y sin su salida en Bancos: confirmarPago la reconoce y termina el pago
const pagosSinConfirmar = new Set();
// Las refs anotadas también se guardan en este navegador: si la página se recarga antes de reintentar, al volver a entrar a Planilla
// se terminan solas (terminarPendientes). Sin almacenamiento del navegador quedan solo en memoria, como antes.
const CLAVE_PENDIENTES = 'rrhh:pagos_sin_confirmar';
function guardarPendientes() { try { localStorage.setItem(CLAVE_PENDIENTES, JSON.stringify([...pagosSinConfirmar].slice(-50))); } catch { /* quedan en memoria */ } }
try { for (const r of JSON.parse(localStorage.getItem(CLAVE_PENDIENTES) || '[]')) if (typeof r === 'string' && r) pagosSinConfirmar.add(r); } catch { /* sin almacenamiento o dato dañado */ }
// 4.7: planillas complementarias ligadas a una planilla (referencia_id): mientras existan, esa planilla no se elimina
const complementariasDe = id => planillasGuardadas().filter(x => x.id !== id && esComplementaria(x) && String(x.referencia_id) === String(id));

function rangoPorDefecto(periodo) {
  const h = hoy(), d = new Date(h + 'T00:00:00');
  if (periodo === 'mensual') return [h.slice(0, 8) + '01', h];
  if (periodo === 'quincenal') return d.getDate() <= 15 ? [h.slice(0, 8) + '01', h.slice(0, 8) + '15'] : [h.slice(0, 8) + '16', h];
  return [sumarDias(h, -(periodo === 'bisemanal' ? 13 : 6)), h];   // en hora local (R194)
}
const filaNueva = e => ({ empleado: e, horas: null, horas_extra: 0, horas_feriado: 0, dias_ausencia: 0, otros_ingresos: 0, otras_deducciones: 0, no_salariales: 0, deducciones: [], ingresos: [], ausencias: [], auto: { dias_ausencia: 0, no_salariales: 0 } });
// 4.7: horas extra y de feriado registradas por día (el servidor avisa los días de más de 12 h); sin la nota escrita a mano
const detalleHoras = f => (f.horas_detalle || []).map(h => ({ fecha: h.fecha, tipo: h.tipo, horas: +h.horas || 0 }));

export default {
  props: ['params'],
  data() {
    const [desde, hasta] = rangoPorDefecto('quincenal');
    return { enviando: null, lista: planillasGuardadas(), nueva: false, editId: null, periodo: 'quincenal', desde, hasta, filas: [], otros: [], agregarId: null, diasCubre: 15, resultado: null, calculando: false, ver: null, pagar: null, PERIODOS, cuentas: [], cuentasLista: null, t: null, detalle: null, revision: null, imprimir: null };
  },
  computed: {
    correoListo() { const e = store.empresa || {}; return !!((e.rrhh_smtp_host && e.rrhh_smtp_remitente) || e.smtp_host); },   // hay por dónde enviar los comprobantes
    // 4.21: la empresa exige aprobar la planilla antes de marcarla pagada (Recursos humanos › Parámetros; apagado por omisión)
    exigeAprobacion() { return !!(this.t && this.t.efectivos && this.t.efectivos.exigir_aprobacion_planilla); },
    rows() { return this.lista.slice().sort((a, b) => b.id - a.id).map(p => ({ ...p, periodo_nombre: periodoNombre(p.periodo), bruto: p.totales.bruto, neto: p.totales.neto, costo: p.totales.costo_total })); },
    columns() { return [{ key: 'numero', label: 'Planilla', mono: true, link: r => this.ver = r }, { key: 'periodo_nombre', label: 'Período' }, { key: 'desde', label: 'Desde', fmt: 'date' }, { key: 'hasta', label: 'Hasta', fmt: 'date' }, { key: 'empleados', label: 'Empleados', num: true }, { key: 'bruto', label: 'Bruto', num: true, fmt: 'money' }, { key: 'neto', label: 'Neto pagado', num: true, fmt: 'money' }, { key: 'costo', label: 'Costo total', num: true, fmt: 'money' }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    // planillas guardadas del mismo período que se traslapan con las fechas elegidas y comparten empleados (evita pagar dos veces)
    repetidas() {
      if (!this.nueva || !this.desde || !this.hasta) return [];
      const ids = new Set(this.filas.map(f => f.empleado.id));
      // 4.7: sin las complementarias (pagos adicionales ligados a otra planilla): se compara con la original; cruzarse solo con un bono no es pagar dos veces
      return this.lista.filter(p => p.id !== this.editId && !p.complementaria && p.desde <= this.hasta && p.hasta >= this.desde && (p.filas || []).some(f => ids.has(f.empleado_id)));
    },
    hayAutomaticos() { return this.filas.some(f => f.deducciones.length || f.ingresos.length || f.ausencias.length); },
    // 4.7: avisos del último cálculo, los mismos que se guardan con la planilla: los generales (parámetros) y los de cada fila tal como
    // los devuelve el servidor; se listan debajo de la tabla (antes eran mensajes propios de la pantalla, algunos con números fijos)
    avisosCalculo() {
      const res = this.resultado;
      if (!res) return [];
      const out = [...(res.avisos || []), ...this.avisoAnio(res.anio_parametros)].map(a => (a && a.texto) || String(a));
      (res.filas || []).forEach((r, i) => { for (const a of this.avisosResultado(r, this.filas[i])) out.push((r.nombre || 'Empleado') + ': ' + a); });
      return out;
    },
  },
  // cualquier cambio obliga a recalcular (R151). 4.7: las fechas recalculan además los días que cubre un período manual
  // (sincronizarDias), y al cambiar el período la lista nueva de empleados se autocompleta aunque las fechas no cambien
  watch: { periodo(v) { if (!this.editId) { [this.desde, this.hasta] = rangoPorDefecto(v); if (this.nueva) { this.cargarEmpleados(); this.autocompletar(); } } this.sincronizarDias(); this.resultado = null; }, filas: { deep: true, handler() { this.resultado = null; } }, desde() { this.resultado = null; this.sincronizarDias(); this.autocompletar(); }, hasta() { this.resultado = null; this.sincronizarDias(); this.autocompletar(); }, diasCubre() { this.resultado = null; } },
  methods: {
    money, fmt, fecha, nombreCompleto,
    // solo los empleados cuyo período de pago coincide con el de la planilla; el resto se puede agregar a mano (R149)
    cargarEmpleados() {
      const todos = activos();
      const emps = this.periodo === 'manual' ? todos : todos.filter(e => (e.periodo_pago || 'quincenal') === this.periodo);
      if (!emps.length) toast('Ningún empleado tiene período de pago ' + periodoNombre(this.periodo).toLowerCase() + '; agréguelos abajo', 'err');
      this.filas = emps.map(filaNueva); this.otros = todos.filter(e => !emps.includes(e)); this.agregarId = null; this.resultado = null;
    },
    async iniciar() {
      const todos = activos();
      if (!todos.length) return toast('No hay empleados activos. Regístrelos primero en Empleados.', 'err');
      if (!this.t) { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } }   // los parámetros (incapacidades) antes de autocompletar
      // período inicial: el más común entre los empleados activos (antes siempre «quincenal», y con empleados mensuales la lista salía vacía)
      const conteo = {}; todos.forEach(e => { const p = e.periodo_pago || 'quincenal'; conteo[p] = (conteo[p] || 0) + 1; });
      this.periodo = Object.keys(conteo).sort((a, b) => conteo[b] - conteo[a])[0] || 'quincenal';
      [this.desde, this.hasta] = rangoPorDefecto(this.periodo);
      this.editId = null; this.cargarEmpleados(); this.sincronizarDias();
      this.resultado = null; this.nueva = true;
      this.autocompletar();
    },
    // Reabre una planilla generada (no pagada) para corregirla: al guardar sustituye la original con el mismo número. Mientras
    // se corrige, los préstamos recuperan lo que esa planilla les descontó (así las cuotas se recalculan con el saldo correcto);
    // al cancelar o salir sin guardar se vuelve a descontar.
    async editar(p) {
      if (p.estado === 'Pagada') return toast('La planilla ' + p.numero + ' está pagada y ya no se modifica: corríjala con un ajuste en la siguiente planilla o con una planilla complementaria', 'err');
      if (!mock.puedeGuardar()) return;
      // 4.21: corregir una planilla aprobada le quita la aprobación al guardar (el servidor no acepta cambiarla mientras esté aprobada)
      if (p.estado === 'Aprobada' && !confirm('La planilla ' + p.numero + ' está aprobada' + (p.aprobada_por ? ' por ' + p.aprobada_por : '') + '. Si la corrige y guarda los cambios, se le quita la aprobación y habrá que aprobarla de nuevo.\n\n¿Corregirla?')) return;
      if (this.editId) this.cancelarEdicion(false);
      if (!this.t) { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } }
      const emps = empleados(), todos = activos();
      aplicarSaldos(p, +1); this.editId = p.id; this._sinAuto = true;
      this.periodo = p.periodo; this.desde = p.desde; this.hasta = p.hasta;
      // 4.7: los días que cubre un período manual, los mismos con que se guardó (en las guardadas antes: los de sus fechas, tope 31)
      if (p.periodo === 'manual') this.diasCubre = +p.dias_cubre >= 1 ? Math.min(31, +p.dias_cubre) : Math.min(31, diasEntre(p.desde, p.hasta) || +this.diasCubre || 15);
      this.filas = (p.filas || []).map(f => { const e = emps.find(x => x.id === f.empleado_id); if (!e) return null; const en = f.entradas || {}; return { ...filaNueva(e), horas: en.horas ?? null, horas_extra: +en.horas_extra || 0, horas_feriado: +en.horas_feriado || 0, dias_ausencia: +en.dias_ausencia || 0, otros_ingresos: +en.otros_ingresos || 0, otras_deducciones: +en.otras_deducciones || 0, no_salariales: +en.no_salariales || 0, deducciones: en.deducciones || [], ingresos: en.ingresos || [], ausencias: en.ausencias || [], horas_detalle: Array.isArray(en.horas_detalle) ? en.horas_detalle : [], auto: en.auto || { dias_ausencia: +en.dias_ausencia || 0, no_salariales: +en.no_salariales || 0 } }; }).filter(Boolean);
      this.otros = todos.filter(e => !this.filas.some(f => f.empleado.id === e.id)); this.agregarId = null;
      this.resultado = null; this.nueva = true; this.ver = null;
      this.$nextTick(() => { this._sinAuto = false; });               // los watchers de las fechas no pisan lo restaurado
      toast('Planilla ' + p.numero + ' abierta para corregir: al guardar se sustituye', 'ok');
    },
    // Sale de la corrección sin guardar: los préstamos vuelven a quedar con la cuota de la planilla original descontada
    cancelarEdicion(cerrar = true) {
      if (this.editId) { const p = planillasGuardadas().find(x => x.id === this.editId); if (p && p.estado !== 'Pagada') aplicarSaldos(p, -1); }
      this.editId = null; if (cerrar) { this.nueva = false; this.resultado = null; }
    },
    agregar() { const e = this.otros.find(x => x.id === this.agregarId); if (!e) return; const f = filaNueva(e); this.filas.push(f); this.otros = this.otros.filter(x => x.id !== this.agregarId); this.agregarId = null; this.autocompletarFila(f); },
    // Ausencias e incapacidades del período y conceptos fijos vigentes: se recalculan al cambiar las fechas. Los días no pagados y
    // el monto no salarial escritos a mano se conservan (solo se reemplazan si siguen con el valor que se autocompletó antes).
    autocompletar() { if (!this.nueva || this._sinAuto) return; for (const f of this.filas) this.autocompletarFila(f); },
    // 4.7: en una planilla COMPLEMENTARIA, a quien ya está en la planilla original no se le vuelve a cargar lo del período (allá ya se
    // le pagó o rebajó): horas en 0, sin horas extra ni de feriado registradas, ausencias, subsidios ni deducciones o ingresos fijos
    // (préstamos, pensión, embargo, bonificaciones…). Solo cuenta lo que se escriba en la fila; si deja de serlo, vuelve lo automático.
    autocompletarFila(f) {
      if (!this.desde || !this.hasta) return;
      const ya = this.enOriginal(f.empleado), params = this.t && this.t.efectivos;
      const a = ya ? { dias_ausencia: 0, no_salariales: 0, deducciones: [], detalle: [] } : ausenciasEn(f.empleado, this.desde, this.hasta, params);
      const c = ya ? { deducciones: [], ingresos: [] } : conceptosEn(f.empleado, this.desde, this.hasta), hx = ya ? { horas_extra: 0, horas_feriado: 0, detalle: [] } : horasExtraEn(f.empleado, this.desde, this.hasta);
      const auto = f.auto || { dias_ausencia: 0, no_salariales: 0 };
      f.ausencias = a.detalle; f.deducciones = [...a.deducciones, ...c.deducciones]; f.ingresos = c.ingresos;
      if (+f.dias_ausencia === +auto.dias_ausencia) f.dias_ausencia = a.dias_ausencia;
      if (+f.no_salariales === +auto.no_salariales) f.no_salariales = a.no_salariales;
      // horas extra y de feriado registradas en Recursos humanos › Horas extra (2.3): se autocompletan igual que los días no pagados
      if (+f.horas_extra === (+auto.horas_extra || 0)) f.horas_extra = hx.horas_extra;
      if (+f.horas_feriado === (+auto.horas_feriado || 0)) f.horas_feriado = hx.horas_feriado;
      // 4.7: horas en 0 en la complementaria; de vuelta a la jornada completa (en blanco) si deja de serlo y nadie las cambió
      const vacia = v => v === null || v === undefined || v === '', hAuto = auto.horas === undefined ? null : auto.horas;
      if (vacia(f.horas) ? vacia(hAuto) : (!vacia(hAuto) && +f.horas === +hAuto)) f.horas = ya ? 0 : null;
      f.horas_detalle = hx.detalle;
      f.auto = { dias_ausencia: a.dias_ausencia, no_salariales: a.no_salariales, horas_extra: hx.horas_extra, horas_feriado: hx.horas_feriado, ...(ya ? { horas: 0 } : {}) };
    },
    // 4.7: ¿el empleado ya está en la planilla original que cubre estas fechas? (repetidas: las no complementarias que se cruzan)
    enOriginal(e) { return !!e && this.repetidas.some(p => (p.filas || []).some(x => x.empleado_id === e.id)); },
    // 4.7: lo automático del período que trae una fila: deducciones e ingresos fijos, ausencias e incapacidades, horas extra registradas
    traeAutomaticos(f) { return !!f && ['deducciones', 'ingresos', 'ausencias', 'horas_detalle'].some(k => (f[k] || []).length > 0); },
    // 4.7: quita lo automático a los empleados que ya están en la original (p. ej. al corregir una planilla que lo trae guardado)
    quitarAutomaticos() { for (const f of this.filas) if (this.enOriginal(f.empleado)) this.autocompletarFila(f); },
    // 4.7: períodos de pago por mes, como los usa el servidor (renta del período = renta del mes de bruto × factor, ÷ factor; una
    // quincena = 2): 30 ÷ días que cubre. Antes se mandaba días ÷ 30, al revés: 15 días daban 0,5 y la renta salía sobre la cuarta
    // parte del salario del mes (se retenía de menos)
    factor() { return this.periodo === 'manual' ? 30 / Math.min(31, Math.max(1, +this.diasCubre || 30)) : null; },
    // 4.7: «Días que cubre» de un período manual sale de las fechas (Desde y Hasta, ambas incluidas; tope 31); se puede cambiar a mano
    // y se guarda con la planilla. Mientras se restaura una corrección no se toca (editar pone los guardados)
    sincronizarDias() { if (this._sinAuto || this.periodo !== 'manual') return; const d = diasEntre(this.desde, this.hasta); if (d > 0) this.diasCubre = Math.min(31, d); },
    // 4.7: los días que cubre un período manual tal como se guardan con la planilla (los mismos del cálculo, factor)
    diasGuardados() { return this.periodo === 'manual' ? Math.min(31, Math.max(1, +this.diasCubre || 30)) : null; },
    // 4.7: además lo que el servidor usa para las excepciones de la base mínima y los avisos: las fechas del período (con ellas y la
    // ficha del empleado detecta un ingreso o una salida dentro del período), los tipos de ausencia y las horas extra por día (días de
    // más de 12 h). `previo`, solo en una complementaria: lo ya pagado en el mes (previoMes). Con la base mínima encendida, lo pagado
    // en el mes y si la planilla cierra el mes (baseMes)
    filaServidor(f, previo) {
      return { empleado: paraServidor(f.empleado), factor_manual: this.factor(), desde: this.desde, hasta: this.hasta, horas: f.horas === null || f.horas === '' ? null : +f.horas, horas_extra: +f.horas_extra || 0, horas_feriado: +f.horas_feriado || 0, dias_ausencia: +f.dias_ausencia || 0,
        otros_ingresos: +f.otros_ingresos || 0, otras_deducciones: +f.otras_deducciones || 0, no_salariales: +f.no_salariales || 0, deducciones: f.deducciones, ingresos: f.ingresos,
        ausencias: (f.ausencias || []).map(a => ({ tipo: a.tipo, dias: a.dias })), horas_detalle: detalleHoras(f), ...(previo || {}), ...this.baseMes(f.empleado) };
    },
    // 4.7: base mínima de la CCSS evaluada por MES, con «Cuotas sobre la base mínima» encendido en Parámetros: cada fila manda lo ya
    // pagado al empleado en el mes de «Hasta» (bruto de las planillas pagadas que cierran en ese mes, ordinarias y complementarias; la
    // que se corrige no cuenta) y si esta planilla cierra el mes. El servidor cobra la diferencia solo en la que cierra el mes
    baseMinimaMes() { return !!(this.t && this.t.efectivos && this.t.efectivos.aplicar_base_minima); },
    baseMes(e) { return this.baseMinimaMes() ? { bruto_mes_previo: this.previoMes(e).bruto_previo, cierra_mes: this.cierraMes() } : {}; },
    // 4.7: ¿cierra el mes de «Hasta»? Es la última planilla de su período con «Hasta» en ese mes: termina el último día del mes, es
    // mensual, es la segunda quincena, la siguiente semanal o bisemanal ya terminaría en el mes siguiente, o es manual y cubre los días
    // de un mes completo. Sin esto, con pago semanal (o la segunda quincena guardada antes del último día) ninguna planilla cerraba el
    // mes y la diferencia de la base mínima no se cobraba nunca
    cierraMes() {
      const h = String(this.hasta || '').slice(0, 10), mes = h.slice(0, 7), sigue = { semanal: 7, bisemanal: 14 }[this.periodo];
      if (!/^\d{4}-\d{2}-\d{2}$/.test(h)) return false;
      const diasMes = new Date(+mes.slice(0, 4), +mes.slice(5, 7), 0).getDate();
      return this.periodo === 'mensual' || h === mes + '-' + String(diasMes).padStart(2, '0') || (this.periodo === 'quincenal' && +h.slice(8, 10) > 15)
        || (!!sigue && sumarDias(h, sigue).slice(0, 7) !== mes) || (this.periodo === 'manual' && diasEntre(this.desde, h) >= diasMes);
    },
    // 4.7: lo ya pagado en el mes a cada empleado con que se calculó (renta de la complementaria, base mínima del mes): si cambia antes
    // de guardar (se pagó la original u otra planilla del mes entre Calcular y Guardar), hay que volver a calcular
    firmaMes() { return JSON.stringify(this.filas.map(f => this.previoMes(f.empleado))); },
    // 4.7: ¿se guardará como complementaria? Otra planilla ya cubre estas fechas con los mismos empleados, o se corrige una que ya lo es
    vaComoComplementaria() { const corr = this.editId ? planillasGuardadas().find(x => x.id === this.editId) : null; return this.repetidas.length > 0 || esComplementaria(corr); },
    // 4.7: renta de una COMPLEMENTARIA (rrhh.renta_complementaria): lo ya pagado y retenido al empleado en el mes, en las planillas
    // pagadas que cierran en el mes de esta (como en Informes; también las complementarias; la que se corrige no cuenta). Si lo ordinario
    // pagado cubre solo una parte del mes (p. ej. la primera quincena), lo que falta se estima en la misma proporción, salvo que el
    // empleado haya ingresado o salido en el mes. El servidor calcula la renta del mes completo y le resta lo ya retenido.
    previoMes(e) {
      const out = { bruto_previo: 0, renta_previa: 0, bruto_resto_mes: 0, renta_resto_mes: 0 }, mes = String(this.hasta || '').slice(0, 7);
      if (!e || !/^\d{4}-\d{2}$/.test(mes)) return out;
      const ini = mes + '-01', diasMes = new Date(+mes.slice(0, 4), +mes.slice(5, 7), 0).getDate(), fin = mes + '-' + String(diasMes).padStart(2, '0');
      // parte del mes que paga cada planilla ordinaria: por su período (quincena = 1/2) o, en la manual, por sus días
      const parte = p => (p.periodo && p.periodo !== 'manual' && FACTOR_MES[p.periodo] ? 1 / FACTOR_MES[p.periodo] : diasEntre(p.desde, p.hasta) / diasMes);
      let bOrd = 0, rOrd = 0, cubre = 0;
      for (const p of planillasGuardadas()) {
        if (!esPagada(p) || p.id === this.editId || !String(p.hasta || '').startsWith(mes)) continue;
        const f = (p.filas || []).find(x => x.empleado_id === e.id);
        if (!f) continue;
        out.bruto_previo += +f.bruto || 0; out.renta_previa += +f.renta || 0;
        if (!esComplementaria(p)) { bOrd += +f.bruto || 0; rOrd += +f.renta || 0; cubre += parte(p); }
      }
      const r = n => Math.round(n * 100) / 100, completo = !(e.fecha_ingreso && e.fecha_ingreso > ini) && !(e.fecha_salida && e.fecha_salida >= ini && e.fecha_salida < fin);
      if (cubre > 0 && cubre < 0.999 && completo) { out.bruto_resto_mes = r(bOrd * (1 - cubre) / cubre); out.renta_resto_mes = r(rOrd * (1 - cubre) / cubre); }
      out.bruto_previo = r(out.bruto_previo); out.renta_previa = r(out.renta_previa);
      return out;
    },
    async calcular() {
      if (!this.desde || !this.hasta || this.hasta < this.desde) return toast('Revise las fechas del período', 'err');
      if (!this.filas.length) return toast('Agregue al menos un empleado', 'err');
      this.calculando = true;
      const n = (this._calc = (this._calc || 0) + 1), firma = JSON.stringify(this.filas);
      // 4.7: con lo último guardado de las planillas (otra persona pudo pagar la original u otra del mes) y con los parámetros cargados
      await mock.refrescar(['planillas']); this.lista = planillasGuardadas();
      if (!this.t) { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } }
      if (n !== this._calc) return;
      // 4.7: una complementaria manda por fila lo ya pagado en el mes al empleado: su renta va sobre el mes completo (previoMes)
      const comp = this.vaComoComplementaria();
      // 4.7: lo ya pagado en el mes con que se calcula (renta de la complementaria, base mínima del mes): se compara al guardar
      const firmaMes = comp || this.baseMinimaMes() ? this.firmaMes() : null;
      try {
        const res = await api('/api/rrhh/planilla', { method: 'POST', body: { periodo: this.periodo, filas: this.filas.map(f => this.filaServidor(f, comp ? this.previoMes(f.empleado) : null)) } });
        if (n !== this._calc || firma !== JSON.stringify(this.filas)) { this.calculando = false; return; }   // cambió algo mientras calculaba: se recalcula
        this.resultado = { ...res, como_complementaria: comp, firma_mes: firmaMes };
        // 4.7: los avisos son los que devuelve el servidor por fila (salario bajo el mínimo, base mínima según se aplicó o no, embargo,
        // pensión con el % de Parámetros, lo que quedó sin rebajar, días de más de 12 h) y los generales, sin textos propios repetidos:
        // se listan debajo de la tabla y se guardan con la planilla
        const av = this.avisosCalculo;
        if (av.length) toast(av.length === 1 ? av[0] : av.length + ' avisos en esta planilla: revíselos debajo de la tabla antes de guardarla', 'err');
      } catch (e) { toast(e.message, 'err'); }
      this.calculando = false;
    },
    guardar() {
      if (!this.resultado) return toast('Calcule la planilla primero', 'err');
      if (!mock.puedeGuardar()) return;
      // 4.7: el cálculo tiene que ser del mismo tipo con que se guarda (la renta de una complementaria va sobre el mes)
      if (!!this.resultado.como_complementaria !== this.vaComoComplementaria()) return toast('Vuelva a calcular la planilla antes de guardarla: cambiaron las planillas que cubren estas fechas con los mismos empleados', 'err');
      // 4.7: y con lo mismo ya pagado en el mes: si entre Calcular y Guardar se pagó la original u otra planilla del mes de estos
      // empleados, cambian la renta de la complementaria y la base mínima del mes
      if (this.resultado.firma_mes !== null && this.resultado.firma_mes !== undefined && this.resultado.firma_mes !== this.firmaMes()) return toast('Vuelva a calcular la planilla antes de guardarla: cambiaron las planillas pagadas en el mes de estos empleados (la renta se calcula con lo ya pagado)', 'err');
      // 4.7: otra planilla ya cubre estas fechas con los mismos empleados. Ya no se guarda una repetida: solo una COMPLEMENTARIA
      // (pagos adicionales del mismo período, p. ej. un bono olvidado) ligada a la original; si no lo es, no se guarda.
      this._complementaria = null;
      if (this.repetidas.length) {
        const orig = this.repetidas[0], corrigiendo = this.editId ? planillasGuardadas().find(x => x.id === this.editId) : null;
        // 4.7: a quien ya está en la planilla original no se le vuelve a pagar ni a rebajar lo del período: se avisa si trae salario
        // ordinario o lo automático (deducciones e ingresos fijos, ausencias, horas extra registradas), que irían dos veces
        const ya = this.filas.map(f => this.enOriginal(f.empleado));
        const conSalario = (this.resultado.filas || []).filter((r, i) => ya[i] && +r.ordinario > 0).length, conAuto = this.filas.filter((f, i) => ya[i] && this.traeAutomaticos(f)).length;
        const doble = (conSalario ? '\n\nAtención: ' + conSalario + ' empleado(s) que ya están en la planilla original traen salario ordinario en esta planilla; si solo les paga un adicional, ponga sus horas en 0 y vuelva a calcular.' : '')
          + (conAuto ? '\n\nAtención: ' + conAuto + ' empleado(s) que ya están en la planilla original traen otra vez lo automático del período (deducciones o ingresos fijos, ausencias, horas extra registradas): se pagaría o rebajaría dos veces. Pulse «Quitar lo automático» y vuelva a calcular.' : '');
        if (corrigiendo && corrigiendo.complementaria) {
          if (doble && !confirm('Esta planilla es complementaria de ' + (corrigiendo.referencia_numero || orig.numero) + '.' + doble + '\n\n¿Guardarla de todos modos?')) return toast('No se guardó la planilla', 'err');
          this._complementaria = { complementaria: true, referencia_id: corrigiendo.referencia_id, referencia_numero: corrigiendo.referencia_numero };   // ya era complementaria: sigue ligada
        } else {
          if (!confirm('La planilla ' + orig.numero + ' (' + fecha(orig.desde) + ' – ' + fecha(orig.hasta) + ') ya cubre estas fechas con los mismos empleados.\n\n¿Esta es una planilla COMPLEMENTARIA, con pagos adicionales del mismo período (por ejemplo, un bono olvidado)?'
            + doble
            + '\nLa renta se calculó con lo ya pagado en el mes a cada empleado: se retiene solo la diferencia.' + (esPagada(orig) ? '' : '\nLa planilla ' + orig.numero + ' todavía no está pagada y su salario no se contó para la renta: si solo le falta un pago, es mejor corregirla que hacer una complementaria.') + '\n\nAceptar: se guarda como complementaria de ' + orig.numero + '.\nCancelar: no se guarda (cambie las fechas o quite a los empleados repetidos).')) return toast('No se guardó: repite fechas y empleados de la planilla ' + orig.numero, 'err');
          this._complementaria = { complementaria: true, referencia_id: orig.id, referencia_numero: orig.numero };
          // al corregir una planilla sin pagar, la marca va en la guardada: la corrección la conserva al sustituirla
          if (corrigiendo && corrigiendo.estado !== 'Pagada') mock.actualizar('planillas', l => (l || []).map(x => (x.id === corrigiendo.id ? { ...x, ...this._complementaria } : x)), []);
        }
      }
      const entradas = (f) => ({ horas: f.horas, horas_extra: f.horas_extra, horas_feriado: f.horas_feriado, dias_ausencia: f.dias_ausencia, otros_ingresos: f.otros_ingresos, otras_deducciones: f.otras_deducciones, no_salariales: f.no_salariales, deducciones: f.deducciones, ingresos: f.ingresos, ausencias: f.ausencias, horas_detalle: detalleHoras(f), auto: f.auto });
      // 4.7: cada fila guarda sus avisos (los del cálculo y los días de más de 12 h según las horas extra registradas); la planilla
      // guarda los suyos (parámetros de otro año) y con qué parámetros se calculó, para verlos en el detalle y al marcarla pagada
      const filas = this.resultado.filas.map((r, i) => ({ ...r, avisos: [...(r.avisos || []), ...this.avisosJornada(this.filas[i], r)], entradas: entradas(this.filas[i]) }));
      const avisosPl = [...(this.resultado.avisos || []), ...this.avisoAnio(this.resultado.anio_parametros)];
      let p = null;
      const anterior = this.editId ? planillasGuardadas().find(x => x.id === this.editId) : null;
      if (this.editId && !anterior) { toast('La planilla que corregía ya no existe: se guarda como nueva', 'err'); this.editId = null; }
      if (anterior) {
        if (anterior.estado === 'Pagada') return toast('La planilla se pagó mientras la corregía; no se puede sustituir', 'err');
        // los saldos de préstamos ya se devolvieron al abrir la corrección (editar): aquí solo se descuenta lo de la versión nueva
        // 4.21: quien la corrige pasa a ser quien la generó (el servidor lo anota con la sesión; aquí va para verlo de una vez) y, si
        // estaba aprobada, vuelve a «Generada» sin aprobación: hay que aprobar lo corregido
        const sinAprobar = anterior.estado === 'Aprobada' ? { estado: 'Generada', aprobada_por: null, aprobada_en: null } : {};
        p = { ...anterior, avisos: avisosPl, parametros_usados: this.resultado.parametros_usados || null, periodo: this.periodo, desde: this.desde, hasta: this.hasta, dias_cubre: this.diasGuardados(), fecha: hoy(), empleados: this.resultado.empleados, filas, totales: this.resultado.totales, ...sinAprobar, ...this.selloGenerada() };
        const id = anterior.id;
        this.lista = mock.actualizar('planillas', l => (l || []).map(x => (x.id === id ? p : x)), []);
      } else p = this.guardarNueva(filas, avisosPl);
      aplicarSaldos(p, -1);
      this.nueva = false; this.editId = null; this.resultado = null;
      toast('Planilla ' + p.numero + ' guardada', 'ok');
    },
    guardarNueva(filas, avisos = []) {
      const lista = planillasGuardadas(); const id = mock.nextId(lista, 'planillas');
      const p = { id, avisos, parametros_usados: this.resultado.parametros_usados || null, numero: 'PL-' + String(id).padStart(4, '0'), periodo: this.periodo, desde: this.desde, hasta: this.hasta, dias_cubre: this.diasGuardados(), fecha: hoy(), empleados: this.resultado.empleados, filas, totales: this.resultado.totales, estado: 'Generada', cuenta: '', pagada_en: null, ...this.selloGenerada() };
      if (this._complementaria) Object.assign(p, this._complementaria);   // 4.7: complementaria de la original (pagos adicionales del mismo período)
      lista.push(p); mock.set('planillas', lista); this.lista = lista;
      return p;
    },
    // 4.7: días con más de 12 horas entre la jornada ordinaria y las extras registradas (art. 136 del Código de Trabajo), si el
    // servidor no los avisó ya (la fila no le manda el detalle de las horas)
    avisosJornada(f, r) {
      if (!f || !r || (r.avisos || []).some(a => a && a.tipo === 'jornada')) return [];
      const dias = {}, hd = +r.horas_dia || 0;
      for (const h of f.horas_detalle || []) { const d = dias[h.fecha] = dias[h.fecha] || { extra: 0, feriado: 0 }; d[h.tipo === 'feriado' ? 'feriado' : 'extra'] += +h.horas || 0; }
      return Object.keys(dias).sort().map(k => [k, (dias[k].feriado || hd) + dias[k].extra]).filter(x => x[1] > 12)
        .map(([k, t]) => ({ tipo: 'jornada', texto: 'El ' + fecha(k) + ' suma ' + fmt(t, 1) + ' horas entre la jornada y las extras: pasa del máximo de 12 horas al día (artículo 136 del Código de Trabajo).' }));
    },
    // 4.7: avisos guardados de una fila; las planillas anteriores a la 4.7 no los guardaban: se arman con las marcas de la fila
    avisosFila(f) {
      if (!f) return [];
      if (Array.isArray(f.avisos)) return f.avisos.map(a => (a && a.texto) || String(a));
      return [...(f.bajo_minimo ? ['Salario mensual por debajo del mínimo de su categoría.'] : []), ...(f.bajo_base_minima ? ['Salario mensual bajo la base mínima contributiva de la CCSS: revíselo con su contador.'] : []),
        ...(f.embargo_excede ? ['El embargo supera lo que permite el artículo 172 del Código de Trabajo.'] : []), ...(f.pension_excede ? ['La pensión alimentaria pasa del 50 % del salario después de la CCSS y la renta.'] : [])];
    },
    // 4.7: todos los avisos de una planilla guardada: los generales y los de cada empleado
    avisosDe(p) {
      const out = ((p && p.avisos) || []).map(a => (a && a.texto) || String(a));
      for (const f of (p && p.filas) || []) for (const a of this.avisosFila(f)) out.push((f.nombre || 'Empleado') + ': ' + a);
      return out;
    },
    // 4.7: una clave sin nombre se muestra legible (etiqueta), no en mayúsculas crudas
    nombreCarga(k) { return etiqueta({ ...OBR, ...PAT, base_minima: 'Diferencia por base mínima', base_minima_obrera: 'Cuota obrera por base mínima (la paga la empresa)', ins_riesgos: 'INS riesgos del trabajo', ins_adicional: 'INS aparte de la póliza' }, k); },
    // 4.7: aviso general cuando las fechas son de un año posterior al de los parámetros de referencia (el servidor no lo sabe)
    avisoAnio(anio) { return anio && String(this.desde || '').slice(0, 4) > String(anio) ? [{ tipo: 'parametros', texto: 'Las tasas, los tramos de renta y los salarios mínimos de referencia son de ' + anio + ': confírmelos en Recursos humanos › Parámetros antes de pagar esta planilla.' }] : []; },
    // 4.7: avisos de una fila recién calculada, tal como los devuelve el servidor ({tipo, texto}: mínimo, base mínima, embargo, pensión,
    // lo que quedó sin rebajar, días de más de 12 h); los días largos solo se arman aquí si el servidor no los trajo
    avisosResultado(r, f) { return r ? [...(r.avisos || []), ...this.avisosJornada(f, r)].map(a => (a && a.texto) || String(a)) : []; },
    // 4.7: cómo se calculó la renta de una complementaria: sobre el mes completo, menos lo ya retenido (rrhh.renta_complementaria)
    textoRentaComp(x) {
      if (!x) return '';
      const ret = (+x.renta_previa || 0) + (+x.renta_resto || 0);
      return 'Renta del mes sobre ' + money(x.base_mes) + ' (ya pagado ' + money(x.bruto_previo) + (+x.bruto_resto ? ', resto del mes estimado ' + money(x.bruto_resto) : '') + ' y esta planilla): ' + money(x.renta_mes) + ' menos ' + money(ret) + (+x.renta_resto ? ' retenidos o por retener' : ' ya retenidos') + '.';
    },
    // 4.21: quién genera o corrige la planilla, para verlo sin esperar a recargar (el servidor pone el suyo: el usuario de la sesión)
    selloGenerada() { const yo = (sesion.usuario || {}).correo || ''; return yo ? { generada_por: yo, generada_en: hoy() } : {}; },
    textoSellos(p) { return sellosDe(p); },
    textoAprobada(p) { return selloDe(p, 'aprobada', 'Aprobada') || 'Aprobada'; },
    // 4.21: aprobar la planilla o quitarle la aprobación. Se hace sobre lo último guardado y se espera al servidor, que anota quién
    // y cuándo y puede rechazarla (por ejemplo, si la empresa pide que la apruebe un usuario distinto del que la generó)
    async aprobar(p) {
      const av = this.avisosDe(p);
      if (!confirm('¿Aprobar la planilla ' + p.numero + ' (' + fecha(p.desde) + ' – ' + fecha(p.hasta) + ', ' + p.empleados + ' empleados, neto ' + money(p.totales.neto) + ')?'
        + (av.length ? '\n\nAvisos de esta planilla:\n• ' + av.slice(0, 8).join('\n• ') + (av.length > 8 ? '\n• y ' + (av.length - 8) + ' más' : '') : '')
        + '\n\nQueda anotado que usted la aprobó. Después se puede marcar pagada.')) return;
      await this.cambiarAprobacion(p, true);
    },
    async quitarAprobacion(p) {
      if (!confirm('¿Quitar la aprobación de la planilla ' + p.numero + '? Vuelve a «Generada»' + (this.exigeAprobacion ? ' y habrá que aprobarla de nuevo antes de marcarla pagada.' : '.'))) return;
      await this.cambiarAprobacion(p, false);
    },
    async cambiarAprobacion(p, aprobar) {
      const id = p.id;
      if (ocupadas.has(id) || !mock.puedeGuardar()) return;
      ocupadas.add(id); const gen = mock.generacion;
      try {
        await mock.refrescar(['planillas'], { sinCorte: true });
        if (mock.generacion !== gen || !mock.cargado) return;
        const p0 = planillasGuardadas().find(x => x.id === id);
        this.lista = planillasGuardadas();
        if (!p0 || esPagada(p0)) return toast(p0 ? 'La planilla ' + p0.numero + ' ya está pagada' : 'La planilla ya no existe; recargue la página', 'err');
        if ((p0.estado === 'Aprobada') === aprobar) return toast('La planilla ' + p0.numero + (aprobar ? ' ya estaba aprobada' + (p0.aprobada_por ? ' por ' + p0.aprobada_por : '') : ' ya no está aprobada'), 'err');
        const yo = (sesion.usuario || {}).correo || '';
        const nueva = planillasGuardadas().map(x => (x.id === id ? { ...x, estado: aprobar ? 'Aprobada' : 'Generada', aprobada_por: aprobar ? yo : null, aprobada_en: aprobar ? hoy() : null } : x));
        this.lista = nueva;
        const ok = await mock.set('planillas', nueva);
        if (mock.generacion !== gen || !mock.cargado) return;
        this.lista = planillasGuardadas();
        if (!ok) return toast('La planilla ' + p0.numero + (aprobar ? ' no quedó aprobada' : ' sigue aprobada') + ': el servidor no aceptó el cambio', 'err');
        toast('Planilla ' + p0.numero + (aprobar ? ' aprobada: ya se puede marcar pagada' : ' sin aprobación: quedó como Generada'), 'ok');
      } finally { ocupadas.delete(id); }
    },
    async abrirPago(p) {
      // 4.21: con los parámetros al día (otra persona pudo encender la aprobación): sin aprobar no se abre el pago
      try { this.t = await tablas(true); } catch (e) { toast(e.message, 'err'); }
      if (this.exigeAprobacion && p.estado !== 'Aprobada') return toast('La planilla ' + p.numero + ' necesita aprobación antes de marcarla pagada (Recursos humanos › Parámetros)', 'err');
      if (!this.cuentasLista) { this.cuentasLista = await cuentasParaMovimientos(); this.cuentas = this.cuentasLista.filter(b => (b.moneda || 'CRC') === 'CRC').map(b => b.nombre);  /* la planilla se paga en colones (R153) */ }
      const b = cuentaPrincipal('CRC', this.cuentasLista); this.pagar = { p, cuenta: b ? b.nombre : (this.cuentas[0] || ''), fecha: hoy(), enviar: this.correoListo && (store.empresa?.rrhh_correo_auto !== false) };
      this.revisarCuentas('planilla', p);
    },
    async confirmarPago() {
      if (!mock.puedeGuardar()) return;
      const { cuenta, fecha: f, enviar } = this.pagar;
      if (!cuenta) return toast('Seleccione la cuenta de la que sale el pago', 'err');
      { const pm = problemaMoneda(cuenta, 'CRC', 1, this.cuentasLista || []); if (pm) return toast('La planilla se paga en colones: elija una cuenta en colones', 'err'); }
      // La tabla muestra copias de las planillas: se marca la planilla real de la lista (si no, el cambio no se guardaba)
      const id = this.pagar.p.id;
      if (!planillasGuardadas().some(x => x.id === id)) return toast('No se encontró la planilla; recargue la página', 'err');
      if (ocupadas.has(id)) return;
      ocupadas.add(id); const gen = mock.generacion;
      try {
        // 4.7: lo último guardado antes de tocar Bancos: otra persona (u otra pestaña) pudo pagarla o eliminarla mientras tanto. Si ya
        // está pagada, no se registra otra salida en Bancos ni se reenvían los comprobantes (el servidor rechazaría el cambio después)
        await mock.refrescar(['planillas'], { sinCorte: true });
        if (mock.generacion !== gen || !mock.cargado) return;
        const p0 = planillasGuardadas().find(x => x.id === id);
        // 4.21: está pagada con la ref de un pago que esta pantalla mandó y quedó sin respuesta: sí se guardó y solo le falta su salida
        if (p0 && esPagada(p0) && pagosSinConfirmar.has(p0.ref_mov)) return await this.terminarPago(p0, enviar);
        if (!p0 || esPagada(p0)) {
          this.lista = planillasGuardadas(); this.pagar = null;
          return toast(p0 ? 'La planilla ' + p0.numero + ' ya estaba pagada' + (p0.pagada_en ? ' (el ' + fecha(p0.pagada_en) + (p0.cuenta ? ' desde ' + p0.cuenta : '') + ')' : '') + ': no se registró otra salida en Bancos ni se enviaron los comprobantes' : 'La planilla ya no existe; recargue la página', 'err');
        }
        // 4.21: con la aprobación exigida, sin aprobar no se toca Bancos (el servidor también rechaza el pago)
        if (this.exigeAprobacion && p0.estado !== 'Aprobada') { this.lista = planillasGuardadas(); this.pagar = null; return toast('La planilla ' + p0.numero + ' necesita aprobación antes de marcarla pagada: no se registró ninguna salida en Bancos', 'err'); }
        // Planilla de una versión anterior: su salida pudo quedar registrada con la ref 'planilla:<id>' aunque siguiera como
        // «Generada». Se quita antes de registrar la nueva, para no descontar dos veces el neto de la cuenta.
        if (!p0.ref_mov && !(await revertirMovimientoBanco(['planilla:' + id]))) return;
        if (mock.generacion !== gen || !mock.cargado) return;                 // se cambió de empresa o se cerró la sesión
        const ref = p0.ref_mov || refUnica('planilla');
        let p = null;
        // se marca sobre lo guardado más reciente (no sobre la copia de la pantalla)
        if (this.exigeAprobacion) {
          // 4.21: el servidor puede rechazar el pago (falta la aprobación): se espera su respuesta ANTES de registrar la salida en Bancos.
          // Si no lo acepta o no responde, la marca se deshace aquí para que no suba después sin su movimiento
          const nueva = planillasGuardadas().map(x => (x.id === id && !esPagada(x) ? (p = { ...x, estado: 'Pagada', cuenta, pagada_en: f, ref_mov: ref }) : x));
          if (!p) return toast('La planilla ya no existe o ya está pagada; recargue la página', 'err');
          this.lista = nueva;
          const ok = await mock.set('planillas', nueva);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (!ok) {
            // Sin respuesta (red caída o error del servidor) el pago pudo guardarse igual: se anota su ref, se deshace la marca y se vuelve
            // a leer lo guardado. Si quedó pagada con una ref anotada, se termina el pago; si no se pudo leer, no se sabe: se avisa, y el
            // siguiente «Marcar pagada» de esta pantalla lo termina (arriba) o lo paga de nuevo, según lo que tenga el servidor.
            // 4.22: la copia sin conexión del navegador tampoco cuenta como lectura (refrescarDelServidor): con ella se decía «el servidor
            // no aceptó… sigue sin pagar» cuando en realidad no se sabía
            pagosSinConfirmar.add(ref); guardarPendientes();
            this.lista = mock.actualizar('planillas', l => (l || []).map(x => (x.id === id && esPagada(x) ? p0 : x)), []);
            const leido = await refrescarDelServidor(['planillas']);
            if (mock.generacion !== gen || !mock.cargado) return;
            const g = planillasGuardadas().find(x => x.id === id);
            if (g && esPagada(g) && pagosSinConfirmar.has(g.ref_mov)) return await this.terminarPago(g, enviar);
            this.lista = planillasGuardadas();
            if (!leido) return toast('No se pudo confirmar con el servidor el pago de la planilla ' + p.numero + ': pudo quedar guardado, pero todavía no se registró la salida en Bancos. Cuando vuelva la conexión pulse otra vez «Marcar pagada», sin salir de esta pantalla, para terminarlo. Si recarga la página, el sistema lo termina al volver a entrar a Planilla en este navegador', 'err');
            return toast('El servidor no aceptó el pago de la planilla ' + p.numero + ': ' + (g && esPagada(g) ? 'ya estaba pagada' : 'sigue sin pagar') + ' y no se registró la salida en Bancos', 'err');
          }
        } else {
          this.lista = mock.actualizar('planillas', l => (l || []).map(x => (x.id === id && !esPagada(x) ? (p = { ...x, estado: 'Pagada', cuenta, pagada_en: f, ref_mov: ref }) : x)), []);
          if (!p) return toast('La planilla ya no existe o ya está pagada; recargue la página', 'err');
        }
        registrarMovimientoBanco(cuenta, -p.totales.neto, f, 'Planilla ' + p.numero + ' · ' + p.empleados + ' empleados', ref, true, 'CRC', 1);
        this.pagar = null; toast('Planilla ' + p.numero + ' marcada como pagada: ' + money(p.totales.neto) + ' desde ' + cuenta, 'ok');
        if (enviar) await this.enviarComprobantes(p);
      } finally { ocupadas.delete(id); }
    },
    // 4.21: termina un pago que el servidor ya tiene guardado y cuya respuesta se perdió (pagosSinConfirmar): registra su salida en
    // Bancos con la cuenta, la fecha y la ref que quedaron guardadas (no las del diálogo) y envía los comprobantes, como confirmarPago
    async terminarPago(p, enviar) {
      pagosSinConfirmar.delete(p.ref_mov); guardarPendientes(); this.lista = planillasGuardadas();
      registrarMovimientoBanco(p.cuenta, -p.totales.neto, p.pagada_en, 'Planilla ' + p.numero + ' · ' + p.empleados + ' empleados', p.ref_mov, true, 'CRC', 1);
      this.pagar = null; toast('Planilla ' + p.numero + ' marcada como pagada: ' + money(p.totales.neto) + ' desde ' + p.cuenta, 'ok');
      if (enviar) await this.enviarComprobantes(p);
    },
    // 4.21: pagos que quedaron sin confirmar en una visita anterior (la página se recargó antes de reintentar): si el servidor los tiene
    // pagados con una ref anotada en este navegador, se registra ahora su salida en Bancos. No envía comprobantes: eso se hace a mano.
    async terminarPendientes() {
      if (!pagosSinConfirmar.size) return;
      const leido = await mock.refrescar(['planillas'], { sinCorte: true }).catch(() => false);
      if (leido === false || !mock.cargado) return;
      for (const p of planillasGuardadas()) if (esPagada(p) && p.ref_mov && pagosSinConfirmar.has(p.ref_mov)) await this.terminarPago(p, false);
    },
    // 4.7: una planilla PAGADA no se elimina (el servidor también lo rechaza): se corrige con un ajuste en la siguiente planilla o
    // con una planilla complementaria. Una sin pagar se elimina como antes y los préstamos recuperan lo que les descontó.
    async eliminar(p) {
      if (ocupadas.has(p.id) || !mock.puedeGuardar()) return;
      const id = p.id, pagada = x => !!x && x.estado === 'Pagada';
      const aviso = () => toast('La planilla ' + p.numero + ' está pagada y no se elimina: se corrige con un ajuste en la siguiente planilla o con una planilla complementaria', 'err');
      if (pagada(p) || pagada(planillasGuardadas().find(x => x.id === id))) return aviso();
      // 4.7: con planillas complementarias ligadas no se elimina: quedarían ligadas a una planilla borrada y una planilla nueva de las
      // mismas fechas ya no se compararía con ellas. Se corrige con «Corregir» o se eliminan antes las complementarias sin pagar
      const avisoComp = l => toast('La planilla ' + p.numero + ' tiene planilla(s) complementaria(s) ligada(s) (' + l.map(x => x.numero).join(', ') + ') y no se elimina: corríjala con «Corregir», o elimine antes las complementarias que no estén pagadas', 'err');
      if (complementariasDe(id).length) return avisoComp(complementariasDe(id));
      if (!confirm('¿Eliminar la planilla ' + p.numero + '? Los préstamos y adelantos recuperan lo que esta planilla les descontó.')) return;
      ocupadas.add(id); const gen = mock.generacion;
      try {
        if (this.editId === id) this.cancelarEdicion();             // se estaba corrigiendo: se cancela antes (si no, los préstamos recuperaban dos veces)
        await mock.refrescar(['planillas'], { sinCorte: true });                        // lo último guardado: otra persona pudo pagarla mientras tanto
        if (mock.generacion !== gen || !mock.cargado) return;
        const real = planillasGuardadas().find(x => x.id === id);
        if (!real || pagada(real)) { this.lista = planillasGuardadas(); this.ver = null; return real ? aviso() : toast('La planilla ya no existe; recargue la página', 'err'); }
        if (complementariasDe(id).length) { this.lista = planillasGuardadas(); this.ver = null; return avisoComp(complementariasDe(id)); }
        // también la ref de la versión anterior; si no hay movimiento no hace nada. Si falla, la planilla se queda.
        if (!(await revertirMovimientoBanco([real.ref_mov, 'planilla:' + id]))) return;
        if (mock.generacion !== gen || !mock.cargado) return;
        aplicarSaldos(real, +1);
        this.lista = mock.actualizar('planillas', l => (l || []).filter(x => x.id !== id), []); this.ver = null; toast('Planilla eliminada');
      } finally { ocupadas.delete(id); }
    },
    // Comprobante de pago (PDF) a cada empleado con correo, desde el correo de Recursos humanos. 4.42: lo arma y lo envía el servidor
    // con lo GUARDADO (los montos de la planilla pagada y el correo de la ficha de cada empleado): la pantalla solo dice cuál planilla.
    // Por eso primero se guarda lo pendiente: la marca «Pagada» recién puesta tiene que estar en el servidor antes de pedir el envío
    // (si no llegó a guardarse, el servidor responde que la planilla no está pagada y no envía nada)
    async enviarComprobantes(p) {
      if (!(p.filas || []).length) return toast('La planilla no tiene empleados', 'err');
      this.enviando = p.id;
      try {
        await mock.guardarTodo();
        const r = await api('/api/rrhh/comprobantes-pago/planilla/' + p.id, { method: 'POST', body: {} });
        const partes = [r.enviados + ' comprobante' + (r.enviados === 1 ? '' : 's') + ' enviado' + (r.enviados === 1 ? '' : 's')];
        if (r.sin_correo.length) partes.push(r.sin_correo.length + ' sin correo (' + r.sin_correo.slice(0, 3).join(', ') + (r.sin_correo.length > 3 ? '…' : '') + ')');
        if (r.fallidos.length) partes.push(r.fallidos.length + ' con error: ' + r.fallidos.map(x => x.nombre + ' (' + x.error + ')').slice(0, 2).join('; '));
        toast(partes.join(' · '), r.fallidos.length ? 'err' : 'ok');
      } catch (e) { toast('No se enviaron los comprobantes: ' + e.message, 'err'); }
      this.enviando = null;
    },
    // 4.21: el comprobante de pago de un empleado en PDF (el mismo que llega por correo; lo arma el servidor con lo guardado). Solo de
    // una planilla pagada; queda en el historial de descargas de Recursos humanos
    async comprobante(p, f) {
      const nombre = 'comprobante_pago_' + p.numero + '_' + String(f.nombre || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.pdf';
      try {
        await abrirArchivo('/api/rrhh/comprobante-pago/planilla/' + p.id + '/' + f.empleado_id, nombre);
        registrarExportable(nombre, 'Comprobante de pago · ' + f.nombre, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: revisión de cuentas del cuadro «Marcar pagada»: cómo cobra cada persona y lo que conviene confirmar antes de transferir
    // (transferencia sin cuenta IBAN, cuenta mal escrita o cambiada desde su último pago, neto en cero). La arma el servidor con lo
    // GUARDADO (el neto de cada fila y la ficha de cada empleado): por eso primero se guarda lo pendiente. Solo avisa: no frena
    // «Marcar pagada»; si no se pudo revisar, lo dice y el pago sigue como siempre
    async revisarCuentas(concepto, d) {
      this.revision = { id: d.id, cargando: true, avisos: [], formas: '' };
      const vigente = () => !!this.revision && this.revision.id === d.id && this.revision.cargando;
      try {
        await mock.guardarTodo();
        const r = await api('/api/rrhh/lista-pago/' + concepto + '/' + d.id);
        if (!vigente()) return;
        const avisos = [...(r.avisos_generales || []), ...(r.filas || []).flatMap(f => (f.avisos || []).map(a => f.nombre + ': ' + a))];
        const formas = (r.por_forma || []).map(x => x.nombre + ': ' + x.empleados + ' (' + money(x.monto) + ')').join(' · ');
        this.revision = { id: d.id, cargando: false, avisos, formas };
      } catch (e) { if (vigente()) this.revision = { id: d.id, cargando: false, error: e.message, avisos: [], formas: '' }; }
    },
    // 4.42: la lista de pago (quién cobra por transferencia, SINPE Móvil, efectivo o cheque; entidad, cuenta, neto, totales y avisos) en
    // PDF, Excel o CSV. El archivo lo arma el servidor con lo guardado, también antes de pagar; queda en el historial de descargas de
    // Recursos humanos
    async listaPago(concepto, d, numero) {
      const formato = await elegirFormato('Lista de pago · ' + numero);
      if (!formato) return;
      const nombre = 'lista_pago_' + String(numero).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.' + formato;
      try {
        await mock.guardarTodo();
        await abrirArchivo('/api/rrhh/lista-pago/' + concepto + '/' + d.id + '?formato=' + formato, nombre);
        registrarExportable(nombre, 'Lista de pago · ' + numero, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: los comprobantes de una planilla pagada en un solo PDF para imprimir: uno por página (los mismos que se envían por correo) y
    // al final una hoja de firmas de recibido. `imprimir.cuales`: solo quienes no tienen correo en su ficha, o todos
    async paraImprimir() {
      const { concepto, d, numero, cuales } = this.imprimir;
      const nombre = 'comprobantes_' + String(numero).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + (cuales === 'todos' ? '' : '_sin_correo') + '.pdf';
      this.imprimir.ocupado = true;
      try {
        await mock.guardarTodo();
        await abrirArchivo('/api/rrhh/comprobantes-imprimir/' + concepto + '/' + d.id + '?cuales=' + cuales, nombre);
        registrarExportable(nombre, 'Comprobantes para imprimir · ' + numero, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
        this.imprimir = null;
      } catch (e) { toast(e.message, 'err'); if (this.imprimir) this.imprimir.ocupado = false; }
    },
    async documento(p, formato) { try { await documentoPlanilla(p, formato); } catch (e) { toast(e.message, 'err'); } },
    csv(p, formato) {
      const cols = [{ key: 'nombre', label: 'Empleado' }, { key: 'horas', label: 'Horas' }, { key: 'horas_extra', label: 'Horas extra' }, { key: 'horas_feriado', label: 'Horas feriado' }, { key: 'dias_ausencia', label: 'Días no pagados' }, { key: 'bruto', label: 'Bruto' }, { key: 'total_obrero', label: 'CCSS trabajador' }, { key: 'renta', label: 'Renta' }, { key: 'otras_deducciones', label: 'Otras deducciones' }, { key: 'no_salariales', label: 'No salarial' }, { key: 'neto', label: 'Neto' }, { key: 'total_patronal', label: 'Cargas patronales' }, { key: 'total_provisiones', label: 'Reserva' }, { key: 'costo_total', label: 'Costo total' }];
      // 4.7: al historial de descargas de Recursos humanos (nombres y salarios), no al general que ve cualquier usuario
      descargarTabla(formato === 'xlsx' ? 'xlsx' : 'csv', 'planilla_' + p.numero, cols, p.filas, { titulo: 'Planilla ' + p.numero, registrar: archivo => registrarExportable(archivo, 'Planilla ' + p.numero, true) });
    },
    resumenAuto(f) {
      const partes = [];
      for (const a of f.ausencias || []) partes.push(a.nombre + ' ' + a.dias + ' d' + (a.tipo === 'maternidad' ? ' (cotiza completo; CCSS paga ' + money(a.ccss || 0) + ')' : a.subsidio ? ' (patrono ' + money(a.subsidio) + ')' : ''));
      for (const d of f.deducciones || []) partes.push('− ' + d.concepto + ' ' + (d.pct !== undefined && d.pct !== null ? fmt(d.pct, 2) + ' %' : money(d.monto)));
      for (const d of f.ingresos || []) partes.push('+ ' + d.concepto + ' ' + money(d.monto) + (d.salarial === false ? ' (no salarial)' : ''));
      return partes;
    },
  },
  async created() { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
  mounted() { this.terminarPendientes(); },
  beforeUnmount() { if (this.editId) this.cancelarEdicion(false); },   // salir de la pantalla a mitad de una corrección = cancelar
  template: `
  <div class="page">
    <PageHead title="Planilla" sub="Nómina por período: salario bruto, deducciones del trabajador (CCSS y renta), neto, cargas patronales y reserva mensual para aguinaldo, vacaciones y cesantía. Las ausencias, incapacidades y deducciones fijas del período se aplican solas." :crumbs="[{label:'Recursos humanos'},{label:'Planilla'}]"><Atajo to="/rrhh/parametros" label="Parámetros de planilla"></Atajo>
      <a class="btn sec" href="#/rrhh/informes" v-if="!nueva">Informes</a><button class="btn" @click="iniciar" v-if="!nueva">+ Nueva planilla</button>
    </PageHead>
    <div class="card" v-if="nueva">
      <div class="alert info" v-if="editId" style="margin-bottom:10px">Corrigiendo la planilla {{(lista.find(x => x.id === editId) || {}).numero}}: al guardar se sustituye con el mismo número.</div>
      <div class="grid cols-4">
        <Field label="Período de pago" req><select v-model="periodo" :disabled="!!editId"><option v-for="p in PERIODOS" :key="p[0]" :value="p[0]">{{p[1]}}</option></select></Field>
        <Field label="Días que cubre" v-if="periodo==='manual'" help="Salen de las fechas Desde y Hasta (puede cambiarlos). La renta se calcula sobre el mes equivalente y se reparte (15 = una quincena, 30 = un mes)"><input type="number" min="1" max="31" v-model.number="diasCubre"></Field>
        <Field label="Desde" req><input type="date" v-model="desde"></Field>
        <Field label="Hasta" req><input type="date" v-model="hasta"></Field>
        <div class="row end" style="align-self:end;gap:8px"><button class="btn ghost" @click="cancelarEdicion()">Cancelar</button><button class="btn sec" :disabled="calculando" @click="calcular">{{calculando ? 'Calculando…' : 'Calcular'}}</button><button class="btn" :disabled="!resultado" @click="guardar">{{editId ? 'Guardar cambios' : 'Guardar planilla'}}</button></div>
      </div>
      <div class="alert warn" v-if="repetidas.length" style="margin:8px 0 0">Ya hay planilla(s) que cubren estas fechas con los mismos empleados: {{repetidas.map(p => p.numero + ' (' + fecha(p.desde) + ' – ' + fecha(p.hasta) + ')').join(', ')}}. Solo se puede guardar como <b>planilla complementaria</b> (pagos adicionales del mismo período, por ejemplo un bono olvidado), ligada a la original. Si no lo es, cambie las fechas o quite a los empleados repetidos. A quien ya está en esa planilla no se le carga otra vez lo del período (horas en 0, sin horas extra registradas, ausencias, subsidios ni deducciones o ingresos fijos): escriba solo lo adicional.<button class="btn sm sec" v-if="filas.some(f => enOriginal(f.empleado) && traeAutomaticos(f))" style="margin-left:8px" title="Quita a los empleados que ya están en la planilla original las deducciones e ingresos fijos, las ausencias y las horas extra registradas del período" @click="quitarAutomaticos">Quitar lo automático</button></div>
      <p class="small muted" style="margin:4px 0 10px">Horas en blanco = jornada completa del período. Las horas extra se pagan a tiempo y medio y las de feriado con el recargo de Parámetros. Los <b>días no pagados</b>, el <b>subsidio</b> de incapacidad y las <b>deducciones e ingresos fijos</b> se toman de lo registrado para el período; puede corregirlos en cada fila. Con período <b>manual</b> indique las horas de cada empleado.</p>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th></th><th>Empleado</th><th style="width:90px">Horas</th><th style="width:80px">H. extra</th><th style="width:80px" title="Horas trabajadas en feriado de pago obligatorio">H. feriado</th><th style="width:85px" title="Días sin goce de salario (permisos, ausencias, incapacidades)">Días no pag.</th><th style="width:120px">Otros ingresos</th><th style="width:120px">Deducciones</th><th style="width:110px" title="Subsidios de incapacidad y viáticos: se pagan sin cotizar">No salarial</th><th class="num">Bruto</th><th class="num">CCSS</th><th class="num">Renta</th><th class="num">Neto</th><th class="num">Patronal</th><th class="num">Reserva</th></tr></thead>
        <tbody><tr v-for="(f,i) in filas" :key="f.empleado.id"><td style="width:28px"><button class="btn icon" title="Quitar de esta planilla" @click="otros.push(f.empleado); filas.splice(i,1)">✕</button></td>
          <td>{{nombreCompleto(f.empleado)}}<span v-if="resultado && resultado.filas[i] && avisosResultado(resultado.filas[i], f).length" :title="avisosResultado(resultado.filas[i], f).join(' · ')" style="color:var(--warn);margin-left:4px">⚠</span><div class="small muted">{{f.empleado.puesto}}</div>
            <div class="small" v-if="resumenAuto(f).length" style="margin-top:3px;white-space:normal;max-width:260px"><span v-for="(x,j) in resumenAuto(f)" :key="j" class="chip" style="font-size:11px;padding:1px 7px;margin:1px 2px 1px 0;cursor:default">{{x}}</span></div></td>
          <td><input class="inp" type="number" min="0" step="0.5" v-model="f.horas" :placeholder="resultado ? fmt(resultado.filas[i].horas,1) : 'jornada'" style="width:100%"></td>
          <td><input class="inp" type="number" min="0" step="0.5" v-model.number="f.horas_extra" style="width:100%"></td>
          <td><input class="inp" type="number" min="0" step="0.5" v-model.number="f.horas_feriado" style="width:100%"></td>
          <td><input class="inp" type="number" min="0" step="0.5" v-model.number="f.dias_ausencia" style="width:100%"></td>
          <td><input class="inp" type="number" min="0" step="0.01" v-model.number="f.otros_ingresos" style="width:100%" :title="f.ingresos.length ? 'Además se suman los ingresos fijos del empleado' : ''"></td>
          <td><input class="inp" type="number" min="0" step="0.01" v-model.number="f.otras_deducciones" style="width:100%" :title="f.deducciones.length ? 'Además se aplican las deducciones fijas del empleado' : ''"></td>
          <td><input class="inp" type="number" min="0" step="0.01" v-model.number="f.no_salariales" style="width:100%"></td>
          <template v-if="resultado && resultado.filas[i]"><td class="num">{{money(resultado.filas[i].bruto)}}</td><td class="num">{{money(resultado.filas[i].total_obrero)}}</td><td class="num" :title="textoRentaComp(resultado.filas[i].renta_complementaria)">{{money(resultado.filas[i].renta)}}<div class="small muted" v-if="resultado.filas[i].renta_complementaria">sobre el mes</div></td><td class="num"><b>{{money(resultado.filas[i].neto)}}</b><div class="small muted" v-if="resultado.filas[i].otras_deducciones">− otras {{money(resultado.filas[i].otras_deducciones)}}</div><div class="small" v-if="(resultado.filas[i].no_aplicado || []).length" style="color:var(--warn)">sin rebajar {{money(resultado.filas[i].no_aplicado.reduce((s, d) => s + (+d.monto || 0), 0))}}</div></td><td class="num">{{money(resultado.filas[i].total_patronal)}}</td><td class="num">{{money(resultado.filas[i].total_provisiones)}}</td></template>
          <template v-else><td class="num muted" colspan="6">Calcule para ver</td></template>
        </tr></tbody>
        <tbody><tr v-if="otros.length"><td colspan="8"><div class="row" style="gap:6px"><select class="inp" v-model="agregarId"><option :value="null">— Agregar empleado de otro período —</option><option v-for="e in otros" :key="e.id" :value="e.id">{{nombreCompleto(e)}}</option></select><button class="btn sec sm" :disabled="!agregarId" @click="agregar">Agregar</button></div></td></tr></tbody>
        <tfoot v-if="resultado"><tr><th colspan="8" style="text-align:right">Totales</th><th class="num">{{money(resultado.totales.bruto)}}</th><th class="num">{{money(resultado.totales.total_obrero)}}</th><th class="num">{{money(resultado.totales.renta)}}</th><th class="num">{{money(resultado.totales.neto)}}</th><th class="num">{{money(resultado.totales.total_patronal)}}</th><th class="num">{{money(resultado.totales.total_provisiones)}}</th></tr></tfoot>
      </table></div>
      <div class="alert warn" v-if="avisosCalculo.length" style="margin:10px 0 0"><b>Avisos del cálculo</b> (se guardan con la planilla)<ul style="margin:4px 0 0 18px;padding:0"><li v-for="(a,j) in avisosCalculo" :key="j">{{a}}</li></ul></div>
      <div class="totals" v-if="resultado" style="margin-top:12px"><div><span>Neto a pagar a los empleados</span><b>{{money(resultado.totales.neto)}}</b></div><div v-if="resultado.totales.no_salariales"><span>Incluye subsidios y pagos no salariales</span><b>{{money(resultado.totales.no_salariales)}}</b></div><div><span>Cargas patronales a pagar (CCSS, INS, LPT)</span><b>{{money(resultado.totales.total_patronal)}}</b></div><div><span>Reserva del período (aguinaldo, vacaciones, cesantía)</span><b>{{money(resultado.totales.total_provisiones)}}</b></div><div class="total"><span>Costo total de la planilla</span><b>{{money(resultado.totales.costo_total)}}</b></div></div>
    </div>
    <div class="card pad0">
      <DataTable :rows="rows" :columns="columns" empty-title="Aún no hay planillas" empty-text="Genere la primera planilla del período con los empleados activos." @row-click="ver=$event">
        <template #actions="{row}"><button class="btn sm sec" v-if="exigeAprobacion && row.estado!=='Pagada' && row.estado!=='Aprobada'" title="Revisada y lista para pagar: queda anotado quién la aprobó" @click.stop="aprobar(row)">Aprobar</button><button class="btn sm" v-if="row.estado!=='Pagada'" :disabled="exigeAprobacion && row.estado!=='Aprobada'" :title="exigeAprobacion && row.estado!=='Aprobada' ? 'Requiere aprobación (Parámetros)' : ''" @click.stop="abrirPago(row)">Marcar pagada</button><button class="btn sm ghost" v-if="row.estado==='Aprobada'" :title="textoAprobada(row) + '. Quitarle la aprobación la deja como Generada'" @click.stop="quitarAprobacion(row)">Quitar aprobación</button><button class="btn sm ghost" v-if="row.estado!=='Pagada'" @click.stop="editar(row)" title="Corregir horas, deducciones o fechas antes de pagarla">Corregir</button><button class="btn sm sec" v-if="row.estado==='Pagada' && correoListo" :disabled="enviando===row.id" title="Enviar a cada empleado su comprobante de pago desde el correo de Recursos humanos" @click.stop="enviarComprobantes(row)">{{enviando===row.id ? 'Enviando…' : '✉ Comprobantes'}}</button><button class="btn sm sec" @click.stop="documento(row, 'pdf')">⤓ PDF</button><button class="btn sm sec" @click.stop="documento(row, 'docx')">⤓ Word</button><button class="btn sm ghost" @click.stop="csv(row, 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click.stop="csv(row)">⤓ CSV</button><span class="badge" v-if="row.complementaria" :title="'Pagos adicionales del mismo período de la planilla ' + (row.referencia_numero || '')">Complementaria de {{row.referencia_numero || 'otra planilla'}}</span><button class="btn icon" v-if="row.estado!=='Pagada'" title="Eliminar" @click.stop="eliminar(row)">🗑</button><span class="muted" v-else style="cursor:help;padding:0 6px" title="Pagada: se corrige con un ajuste en la siguiente planilla o con una planilla complementaria" aria-label="Pagada: no se elimina">🔒</span></template>
        <template #empty><button class="btn" @click="iniciar">+ Nueva planilla</button></template>
      </DataTable>
    </div>
    <Modal v-if="ver" :title="'Planilla ' + ver.numero + ' · ' + periodoNombre(ver.periodo)" lg @close="ver=null">
      <div class="row" style="margin-bottom:10px;gap:10px;flex-wrap:wrap"><span class="chip">{{fecha(ver.desde)}} – {{fecha(ver.hasta)}}</span><span class="badge ok" v-if="ver.estado==='Aprobada'">{{textoAprobada(ver)}}</span><span class="chip on" v-else>{{ver.estado}}</span><span class="small muted" v-if="ver.cuenta">Pagada el {{fecha(ver.pagada_en)}} desde {{ver.cuenta}}</span></div>
      <div class="alert warn" v-if="avisosDe(ver).length" style="margin-bottom:10px"><b>Avisos de esta planilla</b><ul style="margin:4px 0 0 18px;padding:0"><li v-for="(a,j) in avisosDe(ver)" :key="j">{{a}}</li></ul></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Empleado</th><th class="num">Horas</th><th class="num">Bruto</th><th class="num">CCSS</th><th class="num">Renta</th><th class="num">Otras</th><th class="num">Neto</th><th class="num">Patronal</th><th class="num">Reserva</th><th></th></tr></thead>
        <tbody><tr v-for="f in ver.filas" :key="f.empleado_id" @click="detalle = detalle === f ? null : f" style="cursor:pointer" :title="'Ver el detalle de ' + f.nombre"><td>{{f.nombre}}<span v-if="avisosFila(f).length" style="color:var(--warn);margin-left:4px" :title="avisosFila(f).join(' · ')">⚠</span><div class="small muted" v-if="f.dias_ausencia || f.no_salariales">{{f.dias_ausencia ? f.dias_ausencia + ' d no pagados' : ''}}{{f.dias_ausencia && f.no_salariales ? ' · ' : ''}}{{f.no_salariales ? 'no salarial ' + money(f.no_salariales) : ''}}</div></td><td class="num">{{fmt(f.horas,1)}}<span v-if="f.horas_extra"> +{{fmt(f.horas_extra,1)}}</span><span v-if="f.horas_feriado"> ✦{{fmt(f.horas_feriado,1)}}</span></td><td class="num">{{money(f.bruto)}}</td><td class="num">{{money(f.total_obrero)}}</td><td class="num">{{money(f.renta)}}</td><td class="num">{{money(f.otras_deducciones)}}</td><td class="num"><b>{{money(f.neto)}}</b></td><td class="num">{{money(f.total_patronal)}}</td><td class="num">{{money(f.total_provisiones)}}</td><td style="text-align:right"><button class="btn icon" v-if="ver.estado==='Pagada'" title="Descargar el comprobante de pago de este empleado (PDF)" @click.stop="comprobante(ver, f)">⤓</button></td></tr></tbody>
        <tfoot><tr><th>Totales</th><th></th><th class="num">{{money(ver.totales.bruto)}}</th><th class="num">{{money(ver.totales.total_obrero)}}</th><th class="num">{{money(ver.totales.renta)}}</th><th class="num">{{money(ver.totales.otras_deducciones)}}</th><th class="num">{{money(ver.totales.neto)}}</th><th class="num">{{money(ver.totales.total_patronal)}}</th><th class="num">{{money(ver.totales.total_provisiones)}}</th><th></th></tr></tfoot></table></div>
      <div class="card" v-if="detalle" style="margin:12px 0 0;background:var(--bg)"><h2 style="margin-bottom:8px">{{detalle.nombre}} <small>detalle del cálculo</small></h2>
        <div class="alert warn small" v-if="avisosFila(detalle).length" style="margin-bottom:8px"><div v-for="(a,j) in avisosFila(detalle)" :key="j">{{a}}</div></div>
        <div class="grid cols-3 small">
          <div><b>Ingresos</b><div>Ordinario ({{fmt(detalle.horas,1)}} h): {{money(detalle.ordinario)}}</div><div v-if="detalle.descuento_ausencia">− Días no pagados ({{detalle.dias_ausencia}} d): {{money(detalle.descuento_ausencia)}}</div><div v-if="detalle.extras">Extras ({{fmt(detalle.horas_extra,1)}} h): {{money(detalle.extras)}}</div><div v-if="detalle.feriado">Feriado trabajado: {{money(detalle.feriado)}}</div><div v-for="(d,j) in detalle.detalle_ingresos" :key="'i'+j">{{d.concepto}}: {{money(d.monto)}}<span v-if="d.salarial===false"> (no salarial)</span></div><div v-if="detalle.otros_ingresos && !(detalle.detalle_ingresos||[]).length">Otros ingresos: {{money(detalle.otros_ingresos)}}</div><div><b>Bruto: {{money(detalle.bruto)}}</b></div></div>
          <div><b>Deducciones</b><div v-for="(v,k) in detalle.obrero" :key="k">{{nombreCarga(k)}}: {{money(v)}}</div><div v-if="detalle.renta">Renta: {{money(detalle.renta)}}</div><div class="muted" v-if="detalle.renta_complementaria">{{textoRentaComp(detalle.renta_complementaria)}}</div><div v-for="(d,j) in detalle.detalle_deducciones" :key="'d'+j">{{d.concepto}}: {{money(d.monto)}}</div><div v-if="detalle.otras_deducciones && !(detalle.detalle_deducciones||[]).length">Otras: {{money(detalle.otras_deducciones)}}</div><div><b>Total: {{money(detalle.total_deducciones)}}</b></div><div v-for="(d,j) in (detalle.no_aplicado || [])" :key="'n'+j" style="color:var(--warn)">Sin rebajar: {{d.concepto}} {{money(d.monto)}}</div></div>
          <div><b>Neto</b><div v-if="detalle.no_salariales">Subsidios y no salariales: {{money(detalle.no_salariales)}}</div><div><b>Neto pagado: {{money(detalle.neto)}}</b></div><div style="margin-top:6px"><b>Patrono</b></div><div v-for="(v,k) in detalle.patrono" :key="'p'+k">{{nombreCarga(k)}}: {{money(v)}}</div><div>Reservas: {{money(detalle.total_provisiones)}}</div></div>
        </div>
      </div>
      <template #foot><span class="small muted" v-if="textoSellos(ver)" style="margin-right:auto;align-self:center">{{textoSellos(ver)}}</span><span class="small muted" v-if="ver.complementaria" style="margin-right:auto">Complementaria de {{ver.referencia_numero || 'otra planilla'}}</span><button class="btn ghost" v-if="ver.estado!=='Pagada'" @click="editar(ver)">Corregir</button><span class="small muted" v-else style="align-self:center" title="Pagada: se corrige con un ajuste en la siguiente planilla o con una planilla complementaria">🔒 Pagada: se corrige con un ajuste o con una planilla complementaria</span><button class="btn sec" @click="documento(ver, 'pdf')">⤓ PDF</button><button class="btn sec" @click="documento(ver, 'docx')">⤓ Word</button><button class="btn ghost" @click="csv(ver, 'xlsx')">⤓ Excel</button><button class="btn ghost" @click="csv(ver)">⤓ CSV</button><button class="btn ghost" title="Cómo cobra cada persona (transferencia, SINPE Móvil, efectivo o cheque), con totales y avisos de las cuentas: PDF, Excel o CSV" @click="listaPago('planilla', ver, 'Planilla ' + ver.numero)">⤓ Lista de pago</button><button class="btn ghost" v-if="ver.estado==='Pagada'" title="Los comprobantes en un solo PDF, uno por página, con una hoja de firmas de recibido" @click="imprimir = { concepto: 'planilla', d: ver, numero: 'Planilla ' + ver.numero, cuales: 'sin_correo', ocupado: false }">⤓ Para imprimir</button><button class="btn" @click="ver=null; detalle=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="pagar" :title="'Pagar planilla ' + pagar.p.numero" @close="pagar=null">
      <div class="grid cols-2">
        <Field label="Cuenta de la que sale el pago" req help="Por defecto la cuenta principal en colones (Bancos)"><select v-model="pagar.cuenta"><option value="">— Seleccione —</option><option v-for="b in (cuentasLista || [])" :key="b.nombre" :value="b.nombre">{{b.nombre}} · {{b.moneda || 'CRC'}}</option></select></Field>
        <Field label="Fecha de pago" req><input type="date" v-model="pagar.fecha"></Field>
      </div>
      <div class="alert warn" v-if="avisosDe(pagar.p).length" style="margin:8px 0"><b>Revise estos avisos antes de marcarla pagada</b><ul style="margin:4px 0 0 18px;padding:0"><li v-for="(a,j) in avisosDe(pagar.p)" :key="j">{{a}}</li></ul></div>
      <div class="alert" :class="revision.cargando ? '' : (revision.error || revision.avisos.length ? 'warn' : 'ok')" v-if="revision && revision.id === pagar.p.id" style="margin:8px 0"><b>Revisión de cuentas</b><span v-if="revision.cargando"> · revisando cómo cobra cada persona…</span><span v-else-if="revision.error"> · no se pudo revisar ({{revision.error}}). Puede marcarla pagada igual: la revisión solo avisa.</span><span v-else-if="!revision.avisos.length"> · sin avisos.</span><span v-else> · confirme estos avisos antes de transferir. Solo avisan: puede marcarla pagada igual.</span><ul v-if="revision.avisos.length" style="margin:4px 0 0 18px;padding:0"><li v-for="(a,j) in revision.avisos.slice(0, 12)" :key="j">{{a}}</li><li v-if="revision.avisos.length > 12">Hay {{revision.avisos.length - 12}} más: salen todos en la lista de pago.</li></ul><div class="small" v-if="revision.formas" style="margin-top:4px">{{revision.formas}}</div><div style="margin-top:6px"><button class="btn sm ghost" title="Cómo cobra cada persona, con totales y avisos de las cuentas: PDF, Excel o CSV" @click="listaPago('planilla', pagar.p, 'Planilla ' + pagar.p.numero)">⤓ Lista de pago</button></div></div>
      <p class="small muted">Se registra la salida del neto ({{money(pagar.p.totales.neto)}}) en la cuenta y la planilla queda como pagada. Las cargas patronales y las retenciones se pagan aparte a la CCSS, al INS y a Hacienda.</p>
      <div style="margin-top:8px"><Toggle v-model="pagar.enviar" :disabled="!correoListo" label="Enviar a cada empleado su comprobante de pago por correo (PDF)"></Toggle><p class="small muted" style="margin:4px 0 0" v-if="!correoListo">Configure el correo de Recursos humanos (o el correo saliente general) en Configuración › Facturación electrónica para habilitar el envío.</p></div>
      <template #foot><button class="btn ghost" @click="pagar=null">Cancelar</button><button class="btn" @click="confirmarPago">Marcar pagada</button></template>
    </Modal>
    <Modal v-if="imprimir" :title="'Comprobantes para imprimir · ' + imprimir.numero" @close="imprimir=null">
      <p class="small muted" style="margin-top:0">Un solo PDF con un comprobante por página (los mismos que se envían por correo) y, al final, una hoja para que cada persona firme que lo recibió.</p>
      <label class="row" style="cursor:pointer;gap:8px;margin:8px 0"><input type="radio" value="sin_correo" v-model="imprimir.cuales"> Solo quienes no tienen correo en su ficha</label>
      <label class="row" style="cursor:pointer;gap:8px;margin:8px 0"><input type="radio" value="todos" v-model="imprimir.cuales"> Todos</label>
      <template #foot><button class="btn ghost" @click="imprimir=null">Cancelar</button><button class="btn" :disabled="imprimir.ocupado" @click="paraImprimir">{{imprimir.ocupado ? 'Preparando…' : '⤓ Descargar PDF'}}</button></template>
    </Modal>
  </div>`,
  setup() { return { periodoNombre }; },
};
