// Recursos humanos › Horarios de trabajo (3.43): calendario semanal por departamento. Cada departamento tiene sus turnos (Día,
// Tarde, Noche…) con hora de entrada y salida y cuántas personas necesita por día; el calendario asigna a cada empleado del
// departamento un turno o un día libre por fecha, avisa cuando falta gente en un turno o un empleado pasa de sus horas o trabaja
// los 7 días (art. 152: un día de descanso por semana), y puede armar la semana solo (rotación) o copiar la anterior. Las
// vacaciones y ausencias registradas bloquean la celda. Registros: rrhh_departamentos, rrhh_turnos, rrhh_horarios.
import { toast, hoy, fecha, fmt, money, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { empleados, nombreCompleto, horasSemana, departamentos, turnos, horarios, departamentoDe, lunesDe, sumarDiasISO, esFeriado, horasTurno, partesDe,
         turnoNocturno, diasDe, bloqueoDia, guardarHorario, departamentosSugeridos, turnosSugeridos, DIAS_SEMANA, COLORES_TURNO } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() {
    const tab = this.params && this.params.tab === 'config' ? 'config' : 'calendario';
    const tab0 = this.params && this.params.tab === 'planificar' ? 'planificar' : tab;
    return { tab: tab0, semana: lunesDe(hoy()), depto: null, celdas: {}, partes: {}, cargado: '', modalTurno: null, modalDepto: null, armando: false, rotar: true,
             extrasReales: false, extrasSemana: 8,                              // «Armar la semana» real: permitir horas extra (3.44)
             plan: { jornada: 48, extras: 0, salario_hora: null, personas: [] }, simulacion: null, verEscenario: null,
             deptos: departamentos(), turnosTodos: turnos(), DIAS_SEMANA };
  },
  computed: {
    hoyS() { return hoy(); },
    fechas() { return Array.from({ length: 7 }, (_, i) => sumarDiasISO(this.semana, i)); },
    deptosActivos() { return this.deptos.filter(d => d.activo !== false); },
    deptoSel() { return this.deptos.find(d => d.id === this.depto) || null; },
    turnosDepto() { return this.turnosTodos.filter(t => t.departamento_id === this.depto && t.activo !== false).sort((a, b) => String(a.inicio).localeCompare(String(b.inicio))); },
    turnoPorId() { return Object.fromEntries(this.turnosTodos.map(t => [t.id, t])); },
    // empleados activos del departamento elegido (por id o por el texto viejo del departamento)
    emps() {
      return empleados().filter(e => e.activo !== false).filter(e => { const d = departamentoDe(e); return d && d.id === this.depto; })
        .sort((a, b) => nombreCompleto(a).localeCompare(nombreCompleto(b)));
    },
    sinDepto() { return empleados().filter(e => e.activo !== false && !departamentoDe(e)); },
    // horas asignadas y avisos por empleado
    filas() {
      return this.emps.map(e => {
        const dias = this.celdas[e.id] || Array(7).fill(null), partes = this.partes[e.id] || Array(7).fill(null);
        let horas = 0, trabajados = 0, nocturnos = 0;
        dias.forEach((x, i) => { const t = this.turnoPorId[x]; if (t) { horas += partes[i] ? partes[i].reduce((s2, z) => s2 + (+z.h || 0), 0) : horasTurno(t); trabajados++; if (turnoNocturno(t) || (partes[i] || []).some(z => turnoNocturno(this.turnoPorId[z.t]))) nocturnos++; } });
        const avisos = [];
        const max = horasSemana(e);
        if (horas > max + 0.01) avisos.push(`Pasa de sus ${fmt(max, 0)} horas semanales (${fmt(horas, 1)} h): las de más se pagan como extra`);
        if (trabajados >= 7) avisos.push('Trabaja los 7 días: debe tener al menos un día de descanso por semana (art. 152)');
        if (nocturnos && e.jornada !== 'nocturna' && e.jornada !== 'mixta' && horas > 36) avisos.push('Con turnos de noche la jornada no puede pasar de 36 horas semanales');
        for (let i = 1; i < 7; i++) { const a = this.turnoPorId[dias[i - 1]], b = this.turnoPorId[dias[i]]; if (a && b && !this.descansoOk(a, b)) { avisos.push('Menos de 12 h de descanso entre el ' + DIAS_SEMANA[i - 1].toLowerCase() + ' y el ' + DIAS_SEMANA[i].toLowerCase()); break; } }
        return { e, nombre: nombreCompleto(e), dias, partes, horas: Math.round(horas * 10) / 10, trabajados, max, avisos, bloqueos: this.fechas.map(f => bloqueoDia(e.id, f)) };
      });
    },
    // cobertura: por día y turno, cuántos asignados frente a los que pide el turno
    cobertura() {
      return this.fechas.map((f, i) => this.turnosDepto.map(t => {
        const h = horasTurno(t), req = +t.personas || 0;
        const horas = this.filas.reduce((s2, r) => s2 + (r.partes[i] ? r.partes[i].filter(z => z.t === t.id).reduce((x, z) => x + (+z.h || 0), 0) : (r.dias[i] === t.id ? h : 0)), 0);
        const n = h ? Math.round(horas / h * 10) / 10 : 0;
        return { turno: t, n, req, falta: req > n + 0.01, sobra: req > 0 && n > req + 0.01 };
      }));
    },
    faltantes() { return this.cobertura.reduce((s, dia) => s + dia.filter(c => c.falta).length, 0); },
    totalHoras() { return Math.round(this.filas.reduce((s, r) => s + r.horas, 0) * 10) / 10; },
    puedeEditar() { return sesion.puede('rrhh'); },
    // demanda semanal del departamento (3.44)
    demanda() {
      const porTurno = this.turnosDepto.map(t => ({ t, horas: horasTurno(t), personas: +t.personas || 0, semana: Math.round(horasTurno(t) * (+t.personas || 0) * 7 * 10) / 10 }));
      const horas = Math.round(porTurno.reduce((s, x) => s + x.semana, 0) * 10) / 10, turnosDia = porTurno.reduce((s, x) => s + x.personas, 0);
      return { porTurno, horas, turnosDia, turnosSemana: turnosDia * 7 };
    },
    // escenarios: de 1 a 10 personas iguales a la plantilla, con las extras indicadas
    escenarios() {
      if (!this.turnosDepto.some(t => +t.personas > 0)) return [];
      const out = []; let cubierto = 0;
      for (let n = 1; n <= 10; n++) {
        const personas = Array.from({ length: n }, (_, k) => ({ ...this.personaSupuesta(k + 1), racha: 0, bloqueos: Array(7).fill(null), ultimo: null, preferido: null }));
        const r = this.planificar(personas, this.turnosDepto);
        const ord = r.filas.reduce((s, f) => s + f.ordinarias, 0) / n, ext = r.filas.reduce((s, f) => s + f.extras, 0) / n;
        out.push({ n, cubre: r.sinCubrir === 0, sinCubrir: r.sinCubrir, ordinarias: Math.round(ord * 10) / 10, extras: Math.round(ext * 10) / 10, horas: Math.round((ord + ext) * 10) / 10, costo: this.costoTotal(r), r });
        if (r.sinCubrir === 0) { cubierto++; if (cubierto >= 3) break; }                   // el mínimo que cubre y dos opciones más holgadas
      }
      return out;
    },
    minimoPersonas() { const e = this.escenarios.find(x => x.cubre); return e ? e.n : null; },
  },
  watch: {
    semana() { this.cargar(); },
    'params.tab'(v) { this.tab = v === 'config' || v === 'planificar' ? v : 'calendario'; },   // 4.42: el menú lleva a «Departamentos y turnos» sin volver a montar la pantalla
    depto() { this.cargar(); this.simulacion = null; },
    'plan.jornada'() { this.simulacion = null; }, 'plan.extras'() { this.simulacion = null; },
  },
  methods: {
    fecha, fmt, money, horasTurno, turnoNocturno, nombreCompleto, lunesDe,
    etiqueta(x) { if (x === 'L') return 'Libre'; const t = this.turnoPorId[x]; return t ? t.nombre : ''; },
    color(x) { if (x === 'L') return '#e5e7eb'; const t = this.turnoPorId[x]; return t ? t.color || COLORES_TURNO[0] : 'transparent'; },
    esHoy(f) { return f === this.hoyS; },
    feriado(f) { return esFeriado(f); },
    cargar() {
      const c = {}, pz = {}; for (const e of this.emps) { c[e.id] = diasDe(e.id, this.semana); pz[e.id] = partesDe(e.id, this.semana); }
      this.celdas = c; this.partes = pz; this.cargado = this.semana + ':' + this.depto;
    },
    semanaAnterior() { this.semana = sumarDiasISO(this.semana, -7); },
    semanaSiguiente() { this.semana = sumarDiasISO(this.semana, 7); },
    irHoy() { this.semana = lunesDe(hoy()); },
    fijar(empId, i, valor) {
      if (!this.puedeEditar || !mock.puedeGuardar()) return;
      const dias = (this.celdas[empId] || Array(7).fill(null)).slice(); dias[i] = valor === '' ? null : valor;
      const partes = (this.partes[empId] || Array(7).fill(null)).slice(); partes[i] = null;                 // al cambiar a mano, el día vuelve a ser un turno completo
      this.celdas = { ...this.celdas, [empId]: dias }; this.partes = { ...this.partes, [empId]: partes }; guardarHorario(empId, this.semana, dias, partes);
    },
    limpiarSemana() {
      if (!this.emps.length || !confirm('¿Quitar todos los turnos de esta semana en ' + this.deptoSel.nombre + '?')) return;
      for (const e of this.emps) { this.celdas[e.id] = Array(7).fill(null); guardarHorario(e.id, this.semana, this.celdas[e.id]); }
      this.celdas = { ...this.celdas }; toast('Semana en blanco');
    },
    // copia la semana anterior; con «rotar» cada empleado pasa al turno siguiente del departamento (Día → Tarde → Noche → Día)
    copiarAnterior() {
      if (!this.emps.length) return;
      const prev = sumarDiasISO(this.semana, -7), orden = this.turnosDepto.map(t => t.id); let n = 0;
      for (const e of this.emps) {
        const d = diasDe(e.id, prev); if (!d.some(x => x)) continue;
        const nuevo = d.map(x => { if (!this.rotar || x === 'L' || x === null) return x; const k = orden.indexOf(x); return k < 0 ? x : orden[(k + 1) % orden.length]; });
        this.celdas[e.id] = nuevo; guardarHorario(e.id, this.semana, nuevo); n++;
      }
      this.celdas = { ...this.celdas }; toast(n ? 'Semana copiada de la anterior' + (this.rotar ? ' con rotación de turnos' : '') + ' (' + n + ' empleado' + (n === 1 ? '' : 's') + ')' : 'La semana anterior no tiene turnos en este departamento', n ? 'ok' : 'err');
    },
    // Motor de reparto (3.44), común para la semana real y la simulación. personas: [{id, nombre, max (horas ordinarias por
    // semana), extras (horas extra permitidas por semana), bloqueos[7], racha (días seguidos al cierre de la semana anterior),
    // ultimo (turno del domingo anterior), preferido (turno con que arranca)}]. Por día y turno cubre las personas que pide cada
    // turno: reparte parejo (nadie se adelanta más de un día de trabajo al que menos lleva), mantiene a cada uno en su turno de un
    // día a otro mientras el reparto lo permita, no pasa de 6 días seguidos ni de 12 h por día (art. 140), prefiere a quien tiene
    // 12 h de descanso desde su turno anterior y, si se permiten extras, admite más de un turno por día o más horas que la jornada.
    planificar(personas, turnosDepto) {
      const r1 = x => Math.round(x * 10) / 10;
      const est = {};
      for (const p of personas) est[p.id] = { dias: Array(7).fill(null), partes: Array(7).fill(null), horas: 0, horasDia: Array(7).fill(0), trabajados: 0, racha: p.racha || 0, max: +p.max || 48, extras: +p.extras || 0,
                                             bloqueos: p.bloqueos || Array(7).fill(null), ultimo: p.ultimo || null, preferido: p.preferido || null };
      const min = x => { const [h, m] = String(x || '0:0').split(':').map(Number); return h * 60 + m; };
      const solapa = (a, b) => { if (!a || !b) return false; const fa = min(a.fin) <= min(a.inicio) ? min(a.fin) + 1440 : min(a.fin), fb = min(b.fin) <= min(b.inicio) ? min(b.fin) + 1440 : min(b.fin); return min(a.inicio) < fb && min(b.inicio) < fa; };
      const ultimoTurno = (p, i) => { const s = est[p.id]; if (i > 0) { const pz = s.partes[i - 1]; return this.turnoPorId[pz && pz.length ? pz[pz.length - 1].t : s.dias[i - 1]] || null; } return this.turnoPorId[s.ultimo] || null; };
      const cobertura = this.fechas.map(() => turnosDepto.map(t => ({ turno: t, horas: 0, necesarias: horasTurno(t) * (+t.personas || 0) })));
      // día de descanso planeado y escalonado (persona k descansa el día k·7/n): así los días con menos gente se reparten en la semana y,
      // con horas extra, quienes quedan pueden cubrir 12 h. Es una preferencia: si un turno no se cubre de otra forma, se usa igual a esa persona.
      const n = personas.length;
      personas.forEach((p, k) => { const s = est[p.id]; s.descanso = n > 1 && !s.bloqueos.some(Boolean) ? Math.floor(k * 7 / n) : null; });
      for (let i = 0; i < 7; i++) {
        const minTrab = Math.min(...personas.map(p => est[p.id].trabajados));
        turnosDepto.forEach((t, k) => {
          const h = horasTurno(t), cov = cobertura[i][k]; if (!cov.necesarias || !h) return;
          let guarda = 0;
          while (cov.horas < cov.necesarias - 0.01 && guarda++ < 60) {
            const falta = Math.min(h, cov.necesarias - cov.horas);          // lo que queda por cubrir de este turno (una persona cubre a lo sumo un turno completo)
            let relajar = false;
            const candidatos = () => personas.map(p => {
              const s = est[p.id]; if (s.bloqueos[i] || (s.descanso === i && !relajar && !s.dias[i])) return null;
              const piezas = s.partes[i] || [];
              if (piezas.some(z => z.t === t.id) || piezas.some(z => solapa(this.turnoPorId[z.t], t))) return null;   // ya está en este turno o se le cruza
              const nuevoDia = !s.dias[i];
              if (nuevoDia && s.racha >= 6) return null;                                       // séptimo día seguido: descanso semanal (art. 152)
              const capFull = Math.min(12 - s.horasDia[i], s.max + s.extras - s.horas);       // tope de 12 h por día (art. 140) y de la semana
              let cap = Math.min(capFull, falta);
              if (s.extras <= 0) { if (!nuevoDia || capFull < h - 0.01 || falta < h - 0.01) return null; cap = h; }   // sin extras: solo turnos completos, uno por día
              if (cap < 1) return null;
              const ant = nuevoDia ? ultimoTurno(p, i) : null;
              const sigue = (ant ? ant.id === t.id : nuevoDia && s.preferido === t.id) && s.trabajados <= minTrab + 1;
              return { p, s, cap, nuevoDia, clave: [cap >= falta - 0.01 ? 0 : 1, nuevoDia ? 0 : 1, this.descansoOk(ant, t) ? 0 : 1, sigue ? 0 : 1, s.horas + cap > s.max + 0.01 ? 1 : 0, s.trabajados, s.horas] };
            }).filter(Boolean);
            let cands = candidatos();
            if (!cands.length) { relajar = true; cands = candidatos(); }
            if (!cands.length) break;
            cands.sort((a, b) => { for (let n = 0; n < a.clave.length; n++) if (a.clave[n] !== b.clave[n]) return a.clave[n] - b.clave[n]; return String(a.p.nombre).localeCompare(String(b.p.nombre)); });
            const c = cands[0], horas = Math.round(c.cap * 100) / 100;
            if (c.nuevoDia) { c.s.dias[i] = t.id; c.s.trabajados++; }
            c.s.partes[i] = [...(c.s.partes[i] || []), { t: t.id, h: horas }];
            c.s.horas += horas; c.s.horasDia[i] += horas; cov.horas += horas;
          }
        });
        for (const p of personas) { const s = est[p.id]; if (s.dias[i]) s.racha++; else { if (!s.bloqueos[i]) s.dias[i] = 'L'; s.racha = 0; } }
      }
      const filas = personas.map(p => {
        const s = est[p.id]; const ord = Math.min(s.horas, s.max);
        // partes solo cuando el día no es un único turno completo (así la fila guardada sigue simple)
        const partes = s.partes.map(pz => pz && (pz.length > 1 || Math.abs(pz[0].h - horasTurno(this.turnoPorId[pz[0].t])) > 0.01) ? pz : null);
        return { p, dias: s.dias, partes, horas: r1(s.horas), ordinarias: r1(ord), extras: r1(s.horas - ord), trabajados: s.trabajados };
      });
      const cob = cobertura.map(dia => dia.map(c => { const h = horasTurno(c.turno); return { turno: c.turno, horas: r1(c.horas), necesarias: r1(c.necesarias), falta: c.necesarias - c.horas > 0.01, n: h ? r1(c.horas / h) : 0, req: +c.turno.personas || 0 }; }));
      return { filas, cobertura: cob, sinCubrir: cob.reduce((x, dia) => x + dia.filter(c => c.falta).length, 0) };
    },
    // Armar la semana con los empleados reales del departamento (solo horas ordinarias; las extras se planifican aparte)
    armar() {
      if (!this.turnosDepto.length) return toast('Primero defina los turnos del departamento (pestaña Departamentos y turnos)', 'err');
      if (!this.turnosDepto.some(t => +t.personas > 0)) return toast('Indique cuántas personas necesita cada turno por día', 'err');
      if (!this.emps.length) return toast('No hay empleados activos en este departamento', 'err');
      if (!mock.puedeGuardar()) return;
      const r = this.planificar(this.personasReales(this.emps, this.extrasReales ? +this.extrasSemana || 0 : 0), this.turnosDepto);
      for (const fila of r.filas) { this.celdas[fila.p.id] = fila.dias; this.partes[fila.p.id] = fila.partes; guardarHorario(fila.p.id, this.semana, fila.dias, fila.partes); }
      this.celdas = { ...this.celdas }; this.partes = { ...this.partes };
      const faltan = this.faltantes;
      toast(faltan ? 'Semana armada; faltan personas en ' + faltan + ' turno' + (faltan === 1 ? '' : 's') + ' (en rojo)' : 'Semana armada: todos los turnos cubiertos', faltan ? 'err' : 'ok');
    },
    // empleados reales → personas del motor (jornada, bloqueos y lo que traen de la semana anterior)
    personasReales(emps, extras) {
      const orden = this.turnosDepto.map(t => t.id), prev = sumarDiasISO(this.semana, -7);
      return emps.map(e => {
        const dPrev = diasDe(e.id, prev);
        let racha = 0; for (let k = 6; k >= 0 && dPrev[k] && dPrev[k] !== 'L'; k--) racha++;
        const trabajados = dPrev.filter(x => x && x !== 'L'); const ult = trabajados.length ? trabajados[trabajados.length - 1] : null; const k = orden.indexOf(ult);
        return { id: e.id, nombre: nombreCompleto(e), max: horasSemana(e), extras, racha, bloqueos: this.fechas.map(f => bloqueoDia(e.id, f)), ultimo: dPrev[6] && dPrev[6] !== 'L' ? dPrev[6] : null, preferido: k < 0 ? null : (this.rotar ? orden[(k + 1) % orden.length] : ult) };
      });
    },
    // ---- planificar con personal supuesto ----
    personaSupuesta(n) { return { id: 'v' + n, nombre: 'Persona ' + n, max: +this.plan.jornada || 48, extras: +this.plan.extras || 0, empleado_id: null }; },
    agregarPersona() { this.plan.personas.push(this.personaSupuesta(this.plan.personas.length + 1)); this.simulacion = null; },
    quitarPersona(i) { this.plan.personas.splice(i, 1); this.plan.personas.forEach((p, k) => { p.id = 'v' + (k + 1); if (/^Persona \d+$/.test(p.nombre)) p.nombre = 'Persona ' + (k + 1); }); this.simulacion = null; },
    simular(personas) {
      const lista = (personas || this.plan.personas).map(p => ({ ...p, racha: 0, bloqueos: Array(7).fill(null), ultimo: null, preferido: null }));
      return this.planificar(lista, this.turnosDepto);
    },
    simularPlan() {
      if (!this.turnosDepto.some(t => +t.personas > 0)) return toast('Indique cuántas personas necesita cada turno por día (pestaña Departamentos y turnos)', 'err');
      if (!this.plan.personas.length) return toast('Agregue al menos una persona supuesta', 'err');
      this.simulacion = this.simular();
    },
    costo(fila) { const sh = +this.plan.salario_hora || 0; return sh ? Math.round((fila.ordinarias * sh + fila.extras * sh * 1.5) * 100) / 100 : null; },
    costoTotal(r) { if (!(+this.plan.salario_hora > 0)) return null; return Math.round(r.filas.reduce((s, f) => s + (this.costo(f) || 0), 0) * 100) / 100; },
    usarEscenario(n) { this.plan.personas = Array.from({ length: n }, (_, k) => this.personaSupuesta(k + 1)); this.simulacion = this.simular(); },
    guardarSimulacion() {
      if (!this.simulacion) return;
      const asignadas = this.plan.personas.filter(p => p.empleado_id);
      if (!asignadas.length) return toast('Indique a qué empleado real corresponde cada persona supuesta', 'err');
      const ids = asignadas.map(p => p.empleado_id); if (new Set(ids).size !== ids.length) return toast('Un mismo empleado está asignado a dos personas', 'err');
      if (!confirm('¿Pasar esta semana simulada al calendario de ' + this.deptoSel.nombre + ' (semana del ' + fecha(this.semana) + ') para ' + asignadas.length + ' empleado(s)? Las celdas de esos empleados se reemplazan.')) return;
      if (!mock.puedeGuardar()) return;
      for (const p of asignadas) { const fila = this.simulacion.filas.find(x => x.p.id === p.id); if (!fila) continue; this.celdas[p.empleado_id] = fila.dias; this.partes[p.empleado_id] = fila.partes; guardarHorario(p.empleado_id, this.semana, fila.dias, fila.partes); }
      this.celdas = { ...this.celdas }; this.partes = { ...this.partes }; this.tab = 'calendario'; toast('Semana guardada en el calendario', 'ok');
    },
    // descanso entre el fin de un turno y el inicio del siguiente (al día siguiente): al menos 12 h
    descansoOk(prev, t) {
      if (!prev || !t) return true;
      const min = x => { const [h, m] = String(x || '0:0').split(':').map(Number); return h * 60 + m; };
      const fin = min(prev.fin), ini = min(t.inicio), cruza = min(prev.fin) <= min(prev.inicio);
      const gap = cruza ? ini - fin : (24 * 60 - fin) + ini;
      return gap >= 12 * 60;
    },
    // ---- departamentos y turnos ----
    abrirDepto(d) { this.modalDepto = d ? { ...d } : { id: null, nombre: '', activo: true, conTurnos: true }; },
    guardarDepto() {
      const m = this.modalDepto, nombre = (m.nombre || '').trim(); if (nombre.length < 2) return toast('Escriba el nombre del departamento', 'err');
      if (this.deptos.some(d => d.id !== m.id && d.nombre.trim().toLowerCase() === nombre.toLowerCase())) return toast('Ya existe un departamento con ese nombre', 'err');
      if (!mock.puedeGuardar()) return;
      let nuevo = null;
      this.deptos = mock.actualizar('rrhh_departamentos', l => { const lista = Array.isArray(l) ? l : []; if (m.id) { const i = lista.findIndex(x => x.id === m.id); if (i >= 0) lista.splice(i, 1, { ...lista[i], nombre, activo: m.activo !== false }); } else { nuevo = { id: mock.nextId(lista, 'rrhh_departamentos'), nombre, activo: true }; lista.push(nuevo); } return lista; }, []);
      if (nuevo && m.conTurnos) this.crearTurnosSugeridos(nuevo);
      this.modalDepto = null; toast('Departamento guardado', 'ok');
      if (nuevo && !this.depto) this.depto = nuevo.id;
    },
    crearTurnosSugeridos(d) {
      const sug = turnosSugeridos(d.nombre);
      this.turnosTodos = mock.actualizar('rrhh_turnos', l => { const lista = Array.isArray(l) ? l : []; sug.forEach(([nombre, codigo, inicio, fin], k) => lista.push({ id: mock.nextId(lista, 'rrhh_turnos'), departamento_id: d.id, nombre, codigo, inicio, fin, descanso_min: 0, personas: 1, color: COLORES_TURNO[k % COLORES_TURNO.length], activo: true })); return lista; }, []);
    },
    agregarSugeridos() {
      const faltan = departamentosSugeridos(sesion.tipo).filter(n => !this.deptos.some(d => d.nombre.trim().toLowerCase() === n.toLowerCase()));
      if (!faltan.length) return toast('Ya están todos los departamentos sugeridos');
      if (!confirm('¿Agregar ' + faltan.length + ' departamentos sugeridos con sus turnos típicos? (' + faltan.join(', ') + ')')) return;
      if (!mock.puedeGuardar()) return;
      const nuevos = [];
      this.deptos = mock.actualizar('rrhh_departamentos', l => { const lista = Array.isArray(l) ? l : []; for (const n of faltan) { const d = { id: mock.nextId(lista, 'rrhh_departamentos'), nombre: n, activo: true }; lista.push(d); nuevos.push(d); } return lista; }, []);
      for (const d of nuevos) this.crearTurnosSugeridos(d);
      toast('Departamentos agregados', 'ok');
    },
    importarDeEmpleados() {
      // los textos de «Departamento o área» que ya tienen los empleados pasan a ser departamentos del catálogo y se enlazan
      const nombres = [...new Set(empleados().map(e => String(e.departamento || '').trim()).filter(Boolean))].filter(n => !this.deptos.some(d => d.nombre.trim().toLowerCase() === n.toLowerCase()));
      if (!nombres.length) return toast('Los empleados no tienen departamentos nuevos que importar');
      if (!mock.puedeGuardar()) return;
      this.deptos = mock.actualizar('rrhh_departamentos', l => { const lista = Array.isArray(l) ? l : []; for (const n of nombres) lista.push({ id: mock.nextId(lista, 'rrhh_departamentos'), nombre: n, activo: true }); return lista; }, []);
      toast(nombres.length + ' departamento(s) tomados de los empleados: ' + nombres.join(', '), 'ok');
    },
    empleadosEn(d) { return empleados().filter(e => e.activo !== false && (departamentoDe(e) || {}).id === d.id).length; },
    turnosDe(d) { return this.turnosTodos.filter(t => t.departamento_id === d.id && t.activo !== false).sort((a, b) => String(a.inicio).localeCompare(String(b.inicio))); },
    abrirTurno(d, t) { this.modalTurno = t ? { ...t } : { id: null, departamento_id: d.id, nombre: '', codigo: '', inicio: '06:00', fin: '14:00', descanso_min: 0, personas: 1, color: COLORES_TURNO[this.turnosDe(d).length % COLORES_TURNO.length], activo: true }; },
    guardarTurno() {
      const m = this.modalTurno, nombre = (m.nombre || '').trim(); if (!nombre) return toast('Escriba el nombre del turno', 'err');
      if (!/^\d{2}:\d{2}$/.test(m.inicio || '') || !/^\d{2}:\d{2}$/.test(m.fin || '')) return toast('Indique la hora de entrada y de salida', 'err');
      if (horasTurno(m) <= 0 || horasTurno(m) > 16) return toast('El turno debe durar entre 1 y 16 horas', 'err');
      if (!mock.puedeGuardar()) return;
      const reg = { ...m, nombre, codigo: (m.codigo || nombre[0]).trim().slice(0, 3).toUpperCase(), descanso_min: Math.max(0, +m.descanso_min || 0), personas: Math.max(0, Math.round(+m.personas || 0)) };
      this.turnosTodos = mock.actualizar('rrhh_turnos', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'rrhh_turnos'); lista.push(reg); } return lista; }, []);
      this.modalTurno = null; toast('Turno guardado', 'ok');
    },
    eliminarTurno(t) {
      const usado = horarios().some(h => (h.dias || []).includes(t.id));
      if (!confirm(usado ? 'Este turno ya está en calendarios guardados. ¿Desactivarlo? Las semanas pasadas lo conservan y no se podrá asignar más.' : '¿Eliminar el turno «' + t.nombre + '»?')) return;
      this.turnosTodos = mock.actualizar('rrhh_turnos', l => usado ? (l || []).map(x => (x.id === t.id ? { ...x, activo: false } : x)) : (l || []).filter(x => x.id !== t.id), []);
    },
    // ---- exportar la semana ----
    exportar(formato) {
      if (!this.deptoSel) return;
      const cols = [{ key: 'nombre', label: 'Empleado' }, ...this.fechas.map((f, i) => ({ key: 'd' + i, label: DIAS_SEMANA[i] + ' ' + f.slice(8, 10) + '/' + f.slice(5, 7) })), { key: 'horas', label: 'Horas', num: true }];
      const rows = this.filas.map(r => { const o = { nombre: r.nombre, horas: fmt(r.horas, 1) }; r.dias.forEach((x, i) => { const t = this.turnoPorId[x]; o['d' + i] = r.bloqueos[i] ? r.bloqueos[i] : x === 'L' ? 'Libre' : r.partes[i] ? r.partes[i].map(z => this.etiqueta(z.t) + ' ' + fmt(z.h, 1) + ' h').join(' + ') : t ? t.nombre + ' ' + t.inicio + '–' + t.fin : ''; }); return o; });
      const titulo = 'Horario de ' + this.deptoSel.nombre, periodo = 'Semana del ' + fecha(this.semana) + ' al ' + fecha(this.fechas[6]);
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'horario_' + this.semana, cols, rows, { registrar: a => registrarExportable(a, titulo, true) });   // 4.21: al historial de Recursos humanos
      const turnosTxt = this.turnosDepto.map(t => t.nombre + ' ' + t.inicio + '–' + t.fin + ' (' + fmt(horasTurno(t), 1) + ' h' + (t.personas ? ', ' + t.personas + ' persona' + (t.personas === 1 ? '' : 's') : '') + ')').join(' · ');
      return descargarReporte(formato, { titulo, subtitulo: 'Turnos: ' + turnosTxt, periodo, cols, rows, kpis: [{ t: 'Empleados', v: String(rows.length) }, { t: 'Horas de la semana', v: fmt(this.totalHoras, 1) }, { t: 'Turnos sin cubrir', v: String(this.faltantes) }], archivo: 'horario_' + this.deptoSel.nombre.replace(/\W+/g, '_') + '_' + this.semana, privado: true });
    },
  },
  created() {
    if (!this.depto && this.deptosActivos.length) this.depto = this.deptosActivos[0].id;
    this.cargar();
  },
  template: `
  <div class="page">
    <PageHead title="Horarios de trabajo" sub="Arme el calendario semanal de cada departamento: turnos por día, personas que necesita cada turno y descanso semanal." :crumbs="[{label:'Recursos humanos'},{label:'Horarios'}]">
      <template v-if="tab==='calendario' && deptoSel"><button class="btn ghost sm" @click="exportar('pdf')" :disabled="!filas.length">PDF</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!filas.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!filas.length">CSV</button></template>
      <button class="btn" v-if="tab==='config' && puedeEditar" @click="abrirDepto(null)">+ Nuevo departamento</button>
    </PageHead>
    <div class="tabs" style="margin-bottom:12px"><button class="tab" :class="{on:tab==='calendario'}" @click="tab='calendario'">Calendario</button><button class="tab" :class="{on:tab==='planificar'}" @click="tab='planificar'">Planificar personal</button><button class="tab" :class="{on:tab==='config'}" @click="tab='config'">Departamentos y turnos</button></div>

    <template v-if="tab==='calendario'">
      <div class="card" v-if="!deptosActivos.length"><Empty icon="🗓" title="Todavía no hay departamentos" text="Cree los departamentos (Recepción, Seguridad, Cocina…) y sus turnos en la pestaña «Departamentos y turnos». Después asigne aquí a cada empleado su turno de cada día."><button class="btn" @click="tab='config'">Ir a Departamentos y turnos</button></Empty></div>
      <template v-else>
        <div class="card">
          <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
            <Field label="Departamento"><select v-model.number="depto"><option v-for="d in deptosActivos" :key="d.id" :value="d.id">{{d.nombre}}</option></select></Field>
            <Field label="Semana del"><div class="row" style="gap:6px"><button class="btn sec sm" @click="semanaAnterior" title="Semana anterior">‹</button><input type="date" :value="semana" @change="semana = lunesDe($event.target.value || semana)"><button class="btn sec sm" @click="semanaSiguiente" title="Semana siguiente">›</button><button class="btn ghost sm" @click="irHoy">Hoy</button></div></Field>
            <span style="flex:1"></span>
            <template v-if="puedeEditar">
              <label class="row small" style="gap:6px;align-items:center;padding-bottom:8px"><input type="checkbox" v-model="rotar"> Rotar turnos respecto a la semana anterior</label>
              <label class="row small" style="gap:6px;align-items:center;padding-bottom:8px" title="Si no alcanza la gente con la jornada ordinaria, el reparto admite horas extra: una persona puede cubrir parte de otro turno el mismo día, sin pasar de 12 h diarias, hasta este tope por semana"><input type="checkbox" v-model="extrasReales"> Permitir hasta <input type="number" class="inp" min="1" max="36" style="width:58px;padding:2px 6px" v-model.number="extrasSemana" :disabled="!extrasReales"> h extra por persona</label>
              <button class="btn sec" @click="copiarAnterior" :disabled="!emps.length">Copiar semana anterior</button>
              <button class="btn" @click="armar" :disabled="!emps.length">Armar la semana</button>
              <button class="btn ghost" @click="limpiarSemana" :disabled="!emps.length">Limpiar</button>
            </template>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px">
            <span class="chip" v-for="t in turnosDepto" :key="t.id"><i :style="{display:'inline-block',width:'10px',height:'10px',borderRadius:'5px',background:t.color}"></i> <b>{{t.nombre}}</b> {{t.inicio}}–{{t.fin}} · {{fmt(horasTurno(t),1)}} h{{t.personas ? ' · ' + t.personas + ' por día' : ''}}</span>
            <span class="chip" v-if="!turnosDepto.length">Este departamento no tiene turnos: <a href="javascript:void 0" @click="tab='config'">defínalos</a></span>
            <span class="chip" :class="{on: !faltantes}" v-if="turnosDepto.length && emps.length">{{faltantes ? faltantes + ' turno(s) sin cubrir' : 'Todos los turnos cubiertos'}}</span>
          </div>
        </div>
        <div class="card pad0" v-if="emps.length">
          <div class="table-wrap"><table class="tbl horario">
            <thead><tr><th style="min-width:180px">Empleado</th><th v-for="(f,i) in fechas" :key="f" :class="{hoy: esHoy(f)}" style="text-align:center;min-width:96px">{{DIAS_SEMANA[i]}} <span class="muted">{{f.slice(8,10)}}/{{f.slice(5,7)}}</span><div class="small" style="color:var(--danger)" v-if="feriado(f)">Feriado</div></th><th class="num">Horas</th></tr></thead>
            <tbody>
              <tr v-for="r in filas" :key="r.e.id">
                <td><a class="link" :href="'#/rrhh/empleados/' + r.e.id">{{r.nombre}}</a><div class="small muted">{{r.e.puesto || ''}}{{r.e.puesto ? ' · ' : ''}}{{fmt(r.max,0)}} h/sem · {{r.trabajados}} día{{r.trabajados === 1 ? '' : 's'}}</div><div class="small" style="color:var(--danger)" v-for="a in r.avisos" :key="a">⚠ {{a}}</div></td>
                <td v-for="(f,i) in fechas" :key="f" :class="{hoy: esHoy(f)}" style="text-align:center;padding:4px">
                  <span class="badge" v-if="r.bloqueos[i]" :title="r.bloqueos[i]==='Vac' ? 'Vacaciones' : r.bloqueos[i]==='Inc' ? 'Incapacidad' : r.bloqueos[i]==='Lic' ? 'Licencia' : 'Ausencia registrada'">{{r.bloqueos[i]}}</span>
                  <select v-else class="inp celda" :title="r.dias[i] && r.dias[i] !== 'L' && turnoPorId[r.dias[i]] ? turnoPorId[r.dias[i]].inicio + '–' + turnoPorId[r.dias[i]].fin : ''" :value="r.dias[i] === null || r.dias[i] === undefined ? '' : r.dias[i]" @change="fijar(r.e.id, i, $event.target.value === 'L' ? 'L' : ($event.target.value === '' ? '' : +$event.target.value))" :style="{background: color(r.dias[i]), color: r.dias[i] && r.dias[i] !== 'L' ? '#fff' : 'inherit', fontWeight: r.dias[i] ? 600 : 400}" :disabled="!puedeEditar">
                    <option value="">—</option><option v-for="t in turnosDepto" :key="t.id" :value="t.id" :title="t.inicio + '–' + t.fin">{{t.nombre}}</option><option value="L">Libre</option>
                  </select>
                  <div class="small" v-if="r.partes[i] && !r.bloqueos[i]" style="margin-top:2px;color:var(--warn, #b45309)" title="Horas por turno ese día (con horas extra)">{{r.partes[i].map(z => etiqueta(z.t) + ' ' + fmt(z.h,1) + ' h').join(' + ')}}</div>
                </td>
                <td class="num" :style="r.horas > r.max + 0.01 ? 'color:var(--danger);font-weight:600' : ''">{{fmt(r.horas,1)}}</td>
              </tr>
            </tbody>
            <tfoot v-if="turnosDepto.length">
              <tr v-for="t in turnosDepto" :key="'c'+t.id"><td class="small"><i :style="{display:'inline-block',width:'10px',height:'10px',borderRadius:'5px',background:t.color,marginRight:'6px'}"></i>{{t.nombre}} <span class="muted">({{t.personas || 0}} por día)</span></td>
                <td v-for="(dia,i) in cobertura" :key="i" style="text-align:center" class="small"><span :style="dia.find(c=>c.turno.id===t.id).falta ? 'color:var(--danger);font-weight:700' : dia.find(c=>c.turno.id===t.id).sobra ? 'color:var(--warn, #b45309)' : ''">{{fmt(dia.find(c=>c.turno.id===t.id).n, 1).replace(',0','')}}<span class="muted" v-if="t.personas"> / {{t.personas}}</span></span></td><td></td></tr>
              <tr><td><b>Total de horas</b></td><td v-for="(f,i) in fechas" :key="f"></td><td class="num"><b>{{fmt(totalHoras,1)}}</b></td></tr>
            </tfoot>
          </table></div>
          <p class="small muted" style="padding:8px 14px 12px">Cada cambio se guarda al momento. Vac = vacaciones, Inc = incapacidad, Lic = licencia, Aus = ausencia registrada (se asignan en sus pantallas). «Armar la semana» cubre las personas que pide cada turno repartiendo las horas, deja un día libre a cada uno y, con la rotación, pasa a cada empleado al turno siguiente al de la semana pasada.</p>
        </div>
        <div class="card" v-else><Empty icon="👥" title="Sin empleados en este departamento" text="Asigne el departamento a cada empleado en su ficha (Puesto y jornada › Departamento o área)."><a class="btn sec" href="#/rrhh/empleados">Ir a Empleados</a></Empty></div>
        <div class="alert warn" v-if="sinDepto.length" style="margin-top:12px">{{sinDepto.length}} empleado(s) activos sin departamento: <template v-for="(e,i) in sinDepto.slice(0,8)" :key="e.id"><a class="link" :href="'#/rrhh/empleados/' + e.id">{{nombreCompleto(e)}}</a>{{i < Math.min(sinDepto.length,8) - 1 ? ', ' : ''}}</template>{{sinDepto.length > 8 ? '…' : ''}}. Sin departamento no aparecen en ningún calendario.</div>
      </template>
    </template>

    <template v-if="tab==='planificar'">
      <div class="card" v-if="!deptosActivos.length"><Empty icon="🧮" title="Primero cree un departamento con sus turnos" text="El planificador usa los turnos del departamento y cuántas personas pide cada uno por día."><button class="btn" @click="tab='config'">Ir a Departamentos y turnos</button></Empty></div>
      <template v-else>
        <div class="card">
          <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
            <Field label="Departamento"><select v-model.number="depto"><option v-for="d in deptosActivos" :key="d.id" :value="d.id">{{d.nombre}}</option></select></Field>
            <Field label="Jornada de la persona plantilla" help="Horas ordinarias por semana"><select v-model.number="plan.jornada"><option :value="48">Diurna · 48 h</option><option :value="42">Mixta · 42 h</option><option :value="36">Nocturna · 36 h</option><option :value="24">Medio tiempo · 24 h</option></select></Field>
            <Field label="Horas extra permitidas por persona y semana" help="0 = solo horas ordinarias. Con extras una persona puede cubrir parte de otro turno el mismo día (por ejemplo 8 h de Tarde y 4 de Noche), sin pasar de 12 h por día (art. 140) ni trabajar 7 días seguidos"><input type="number" min="0" max="36" step="1" v-model.number="plan.extras" style="width:120px"></Field>
            <Field label="Salario por hora ordinaria" help="Opcional, para estimar el costo semanal (extra a tiempo y medio)"><input type="number" min="0" step="1" v-model.number="plan.salario_hora" style="width:140px" placeholder="1750"></Field>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px">
            <span class="chip" v-for="x in demanda.porTurno" :key="x.t.id"><i :style="{display:'inline-block',width:'10px',height:'10px',borderRadius:'5px',background:x.t.color}"></i> <b>{{x.t.nombre}}</b> {{fmt(x.horas,1)}} h × {{x.personas}} × 7 días = {{fmt(x.semana,1)}} h</span>
            <span class="chip on"><b>{{fmt(demanda.horas,1)}} h</b> por semana en {{demanda.turnosSemana}} turnos ({{demanda.turnosDia}} por día)</span>
            <span class="chip" v-if="minimoPersonas">Mínimo con esta plantilla: <b>{{minimoPersonas}} persona{{minimoPersonas===1?'':'s'}}</b></span>
          </div>
        </div>
        <div class="card pad0" v-if="escenarios.length"><div style="padding:14px 16px 0"><h2>¿Cuántas personas ocupo? <small>cada escenario usa personas iguales a la plantilla{{plan.extras ? ', con hasta ' + plan.extras + ' h extra cada una' : ', solo con horas ordinarias'}}</small></h2></div>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Personas</th><th>¿Cubre todos los turnos?</th><th class="num">Horas ordinarias por persona</th><th class="num">Horas extra por persona</th><th class="num">Turnos sin cubrir</th><th class="num" v-if="plan.salario_hora">Costo semanal estimado</th><th></th></tr></thead>
            <tbody><tr v-for="e in escenarios" :key="e.n" :style="e.cubre && e.n===minimoPersonas ? 'background:var(--primary-soft)' : ''"><td><b>{{e.n}}</b></td><td><Badge :value="e.cubre ? 'Cubre' : 'No alcanza'"></Badge></td><td class="num">{{fmt(e.ordinarias,1)}}</td><td class="num" :style="e.extras ? 'color:var(--warn, #b45309);font-weight:600' : ''">{{fmt(e.extras,1)}}</td><td class="num" :style="e.sinCubrir ? 'color:var(--danger);font-weight:600' : ''">{{e.sinCubrir}}</td><td class="num" v-if="plan.salario_hora">{{e.costo !== null ? money(e.costo) : '—'}}</td><td><button class="btn sm sec" @click="usarEscenario(e.n)">Ver la semana</button></td></tr></tbody></table></div>
          <p class="small muted" style="padding:8px 14px 12px">Las horas se reparten lo más parejo posible. Si un escenario «no alcanza», suba las horas extra o agregue personas. Con solo horas ordinarias nadie trabaja más de su jornada ni más de un turno por día.</p>
        </div>
        <div class="card">
          <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <h2 style="margin:0">Personal a la medida <small>por ejemplo: una persona a tiempo completo y otra que cubre el resto</small></h2>
            <div class="row" style="gap:6px"><button class="btn sm sec" @click="agregarPersona">+ Agregar persona</button><button class="btn sm" @click="simularPlan" :disabled="!plan.personas.length">Simular la semana</button></div>
          </div>
          <table class="tbl" style="margin-top:8px" v-if="plan.personas.length"><thead><tr><th>Persona</th><th class="num">Horas ordinarias / semana</th><th class="num">Extras máximas / semana</th><th>Empleado real (para guardar)</th><th></th></tr></thead>
            <tbody><tr v-for="(p,i) in plan.personas" :key="p.id">
              <td><input class="inp" v-model="p.nombre" maxlength="40" style="max-width:200px" @input="simulacion=null"></td>
              <td class="num"><input type="number" class="inp" min="4" max="72" step="1" v-model.number="p.max" style="width:90px;text-align:right" @input="simulacion=null"></td>
              <td class="num"><input type="number" class="inp" min="0" max="36" step="1" v-model.number="p.extras" style="width:90px;text-align:right" @input="simulacion=null"></td>
              <td><select class="inp" v-model.number="p.empleado_id" style="max-width:240px"><option :value="null">— Sin asignar (solo simular) —</option><option v-for="e in emps" :key="e.id" :value="e.id">{{nombreCompleto(e)}}</option></select></td>
              <td><button class="btn icon" title="Quitar" @click="quitarPersona(i)">✕</button></td></tr></tbody></table>
          <p class="small muted" style="margin:8px 0 0" v-else>Agregue personas o escoja un escenario de la tabla de arriba con «Ver la semana».</p>
        </div>
        <div class="card pad0" v-if="simulacion">
          <div class="row" style="padding:14px 16px 0;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
            <h2 style="margin:0">Semana simulada <small>{{simulacion.sinCubrir ? simulacion.sinCubrir + ' turno(s) sin cubrir' : 'todos los turnos cubiertos'}}{{costoTotal(simulacion) !== null ? ' · costo estimado ' + money(costoTotal(simulacion)) : ''}}</small></h2>
            <button class="btn" v-if="puedeEditar && emps.length" @click="guardarSimulacion" :disabled="!plan.personas.some(p=>p.empleado_id)">Guardar en el calendario (semana del {{fecha(semana)}})</button>
          </div>
          <div class="table-wrap" style="margin-top:8px"><table class="tbl horario">
            <thead><tr><th style="min-width:160px">Persona</th><th v-for="(f,i) in fechas" :key="f" style="text-align:center;min-width:96px">{{DIAS_SEMANA[i]}}</th><th class="num">Ordinarias</th><th class="num">Extra</th><th class="num" v-if="plan.salario_hora">Costo</th></tr></thead>
            <tbody><tr v-for="r in simulacion.filas" :key="r.p.id">
              <td><b>{{r.p.nombre}}</b><div class="small muted">{{fmt(r.p.max,0)}} h{{r.p.extras ? ' + ' + r.p.extras + ' extra' : ''}} · {{r.trabajados}} día{{r.trabajados===1?'':'s'}}{{r.p.empleado_id ? ' · ' + nombreCompleto(emps.find(e=>e.id===r.p.empleado_id) || {}) : ''}}</div></td>
              <td v-for="(f,i) in fechas" :key="f" style="text-align:center;padding:4px"><template v-if="r.partes[i]"><span class="badge" v-for="(z,k) in r.partes[i]" :key="k" :style="{background: color(z.t), color:'#fff', marginLeft: k ? '3px' : 0}" :title="etiqueta(z.t) + ': ' + fmt(z.h,1) + ' h'">{{etiqueta(z.t)}} {{fmt(z.h,1)}} h</span></template><span class="badge" v-else :style="{background: color(r.dias[i]), color: r.dias[i] && r.dias[i] !== 'L' ? '#fff' : 'inherit'}">{{etiqueta(r.dias[i]) || '—'}}</span></td>
              <td class="num">{{fmt(r.ordinarias,1)}}</td><td class="num" :style="r.extras ? 'color:var(--warn, #b45309);font-weight:600' : ''">{{fmt(r.extras,1)}}</td><td class="num" v-if="plan.salario_hora">{{costo(r) !== null ? money(costo(r)) : '—'}}</td></tr></tbody>
            <tfoot><tr v-for="t in turnosDepto" :key="'s'+t.id"><td class="small"><i :style="{display:'inline-block',width:'10px',height:'10px',borderRadius:'5px',background:t.color,marginRight:'6px'}"></i>{{t.nombre}} <span class="muted">({{t.personas || 0}} por día)</span></td><td v-for="(dia,i) in simulacion.cobertura" :key="i" style="text-align:center" class="small"><span :style="dia.find(c=>c.turno.id===t.id).falta ? 'color:var(--danger);font-weight:700' : ''">{{fmt(dia.find(c=>c.turno.id===t.id).n, 1).replace(',0','')}} / {{t.personas||0}}</span></td><td colspan="3"></td></tr></tfoot>
          </table></div>
          <p class="small muted" style="padding:8px 14px 12px">La simulación no se guarda. Para pasarla al calendario, indique en «Personal a la medida» a qué empleado real corresponde cada persona y pulse «Guardar en el calendario». Las horas extra se pagan a tiempo y medio (Parámetros de RRHH); el costo es una estimación con el salario por hora indicado.</p>
        </div>
      </template>
    </template>

    <template v-if="tab==='config'">
      <div class="card">
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
          <p class="small muted" style="margin:0;flex:1">Un departamento agrupa a los empleados que comparten horario (Recepción, Reservas, Seguridad…). Sus turnos indican la hora de entrada y salida y cuántas personas hacen falta cada día; con eso el sistema puede armar la semana solo.</p>
          <button class="btn sec sm" v-if="puedeEditar" @click="agregarSugeridos">Agregar departamentos sugeridos</button>
          <button class="btn sec sm" v-if="puedeEditar" @click="importarDeEmpleados">Tomar los de los empleados</button>
        </div>
      </div>
      <div class="card" v-for="d in deptos" :key="d.id" :style="d.activo === false ? 'opacity:.6' : ''">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <h2 style="margin:0">{{d.nombre}} <small>{{empleadosEn(d)}} empleado(s){{d.activo === false ? ' · inactivo' : ''}}</small></h2>
          <div class="row" style="gap:6px" v-if="puedeEditar"><button class="btn sm sec" @click="abrirTurno(d, null)">+ Turno</button><button class="btn sm ghost" @click="abrirDepto(d)">Editar</button></div>
        </div>
        <table class="tbl" style="margin-top:8px" v-if="turnosDe(d).length"><thead><tr><th>Turno</th><th>Entrada</th><th>Salida</th><th class="num">Horas</th><th class="num">Personas por día</th><th></th></tr></thead>
          <tbody><tr v-for="t in turnosDe(d)" :key="t.id"><td><i :style="{display:'inline-block',width:'10px',height:'10px',borderRadius:'5px',background:t.color,marginRight:'6px'}"></i><b>{{t.nombre}}</b> <span class="muted small">{{t.codigo}}</span></td><td>{{t.inicio}}</td><td>{{t.fin}}{{turnoNocturno(t) ? ' (noche)' : ''}}</td><td class="num">{{fmt(horasTurno(t),1)}}<span class="small muted" v-if="t.descanso_min"> (−{{t.descanso_min}} min)</span></td><td class="num">{{t.personas || 0}}</td>
            <td style="white-space:nowrap" v-if="puedeEditar"><button class="btn icon" title="Editar" @click="abrirTurno(d, t)">✎</button><button class="btn icon" title="Eliminar" @click="eliminarTurno(t)">🗑</button></td><td v-else></td></tr></tbody></table>
        <p class="small muted" style="margin:8px 0 0" v-else>Sin turnos. Agregue al menos uno para poder armar el calendario.</p>
      </div>
      <div class="card" v-if="!deptos.length"><Empty icon="🏷" title="Sin departamentos" text="Cree el primero o agregue los sugeridos para su tipo de negocio."></Empty></div>
    </template>

    <Modal v-if="modalDepto" :title="modalDepto.id ? 'Editar departamento' : 'Nuevo departamento'" @close="modalDepto=null">
      <Field label="Nombre" req><input v-model="modalDepto.nombre" maxlength="60" placeholder="Seguridad" autofocus @keyup.enter="guardarDepto"></Field>
      <label class="row" style="gap:6px;margin-top:6px" v-if="!modalDepto.id"><input type="checkbox" v-model="modalDepto.conTurnos"> Crear los turnos típicos para este tipo de departamento (después se ajustan)</label>
      <Toggle v-if="modalDepto.id" v-model="modalDepto.activo" label="Departamento activo"></Toggle>
      <template #foot><button class="btn ghost" @click="modalDepto=null">Cancelar</button><button class="btn" @click="guardarDepto">Guardar</button></template>
    </Modal>
    <Modal v-if="modalTurno" :title="modalTurno.id ? 'Editar turno' : 'Nuevo turno'" @close="modalTurno=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="modalTurno.nombre" maxlength="40" placeholder="Noche"></Field>
        <Field label="Abreviatura" help="Hasta 3 letras, para el calendario impreso"><input v-model="modalTurno.codigo" maxlength="3" placeholder="N"></Field>
        <Field label="Entrada" req><input type="time" v-model="modalTurno.inicio"></Field>
        <Field label="Salida" req help="Si es menor que la entrada, el turno termina al día siguiente"><input type="time" v-model="modalTurno.fin"></Field>
        <Field label="Descanso no pagado (minutos)" help="Se resta de las horas del turno"><input type="number" min="0" max="180" step="5" v-model.number="modalTurno.descanso_min"></Field>
        <Field label="Personas que necesita por día" help="Con esto se arma la semana y se marca en rojo lo que falte"><input type="number" min="0" max="99" v-model.number="modalTurno.personas"></Field>
        <Field label="Color"><div class="row" style="gap:6px;flex-wrap:wrap"><button v-for="c in ['#0f766e','#1d5fd1','#b45309','#a3204f','#5b21b6','#15803d','#0e7490','#7c2d12']" :key="c" type="button" class="btn icon" :style="{background:c, border: modalTurno.color===c ? '3px solid #111' : '3px solid transparent', width:'28px', height:'28px'}" @click="modalTurno.color=c"></button></div></Field>
      </div>
      <p class="small muted" style="margin:6px 0 0">Duración: <b>{{fmt(horasTurno(modalTurno),1)}} h</b>{{turnoNocturno(modalTurno) ? ' · turno de noche (jornada nocturna: máximo 6 h por día y 36 por semana)' : ''}}</p>
      <template #foot><button class="btn ghost" @click="modalTurno=null">Cancelar</button><button class="btn" @click="guardarTurno">Guardar</button></template>
    </Modal>
  </div>`,
};
