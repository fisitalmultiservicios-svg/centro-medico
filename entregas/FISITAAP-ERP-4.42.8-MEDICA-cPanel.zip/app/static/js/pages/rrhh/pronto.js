// Recursos humanos › Lo que viene (4.42): lo que está en preparación, sin fechas. #/rrhh/pronto (índice por grupo) y #/rrhh/pronto/<clave>
// (tarjeta de una función: qué hará y, si existe, lo que hoy ya se puede hacer). La lista es fija y vive en menu.js (RRHH_PRONTO): nada se
// guarda ni se pide al servidor. El permiso es el de toda la sección (/rrhh en menu.js: rrhh, módulo del plan y verificación en dos pasos).
import { RRHH_PRONTO, GRUPOS_PRONTO, prontoDe, hoyDe } from '../../menu.js';
import { rutaPermitida } from '../../app.js';

export const AVISO_PRONTO = 'En preparación. Sin fecha; pueden cambiar. Hoy no forman parte de su plan.';

export default {
  props: ['params'],
  computed: {
    clave() { return String((this.params && this.params.clave) || ''); },
    item() { return this.clave ? prontoDe(this.clave) : null; },
    // ya entregada (ya: su ruta real): la tarjeta vieja no se pinta y created() lleva a la pantalla de verdad
    entregada() { const ya = this.item && this.item.ya ? String(this.item.ya) : ''; return ya && !ya.startsWith('/rrhh/pronto') ? ya : ''; },
    grupos() { return GRUPOS_PRONTO.map(g => ({ grupo: g, items: RRHH_PRONTO.filter(p => p.grupo === g && !p.ya) })).filter(g => g.items.length); },
    // «Hoy ya puede…»: cada renglón enlaza solo si este rol abre esa pantalla (la misma regla del menú); si no, queda el texto
    hoy() { return this.item ? hoyDe(this.item).map(h => ({ texto: h.texto, ruta: h.ruta, abre: this.puedeAbrir(h.ruta) })) : []; },
  },
  created() { if (this.entregada) location.replace('#' + this.entregada); },   // un enlace guardado a la tarjeta sigue sirviendo
  methods: {
    puedeAbrir(ruta) { return !!ruta && rutaPermitida(String(ruta).split('?')[0]); },
  },
  setup() { return { AVISO_PRONTO }; },
  template: `
  <div class="page">
    <p v-if="entregada" class="muted small">Esta función ya está disponible. <a :href="'#' + entregada">Abrirla</a></p>
    <template v-else-if="!clave">
      <PageHead title="Lo que viene" sub="Funciones de Recursos humanos que estamos preparando." :crumbs="[{label:'Recursos humanos'},{label:'Lo que viene'}]"></PageHead>
      <div class="alert info" style="margin-bottom:12px">{{AVISO_PRONTO}}</div>
      <div class="card" v-for="g in grupos" :key="g.grupo" style="margin-bottom:12px">
        <h2>{{g.grupo}}</h2>
        <div v-for="p in g.items" :key="p.clave" style="padding:8px 0;border-top:1px solid var(--line)">
          <a :href="'#/rrhh/pronto/' + p.clave"><b>{{p.etiqueta}}</b></a><span class="soon">Próximamente</span>
          <div class="muted small">{{p.descripcion}}</div>
        </div>
      </div>
    </template>
    <template v-else-if="item">
      <PageHead :title="item.etiqueta" :sub="item.descripcion" soon :crumbs="[{label:'Recursos humanos'},{label:'Lo que viene',to:'/rrhh/pronto'},{label:item.etiqueta}]"></PageHead>
      <div class="card">
        <h2>Qué hará</h2>
        <ul><li v-for="(x, i) in item.que_hara" :key="i">{{x}}</li></ul>
        <template v-if="hoy.length">
          <h2 style="margin-top:14px">Hoy ya puede…</h2>
          <ul><li v-for="(h, i) in hoy" :key="i"><a v-if="h.abre" :href="'#' + h.ruta">{{h.texto}}</a><span v-else>{{h.texto}}</span></li></ul>
        </template>
        <p class="muted small">{{AVISO_PRONTO}}</p>
        <a class="btn sec" href="#/rrhh/pronto">Ver todo lo que viene</a>
      </div>
    </template>
    <template v-else>
      <PageHead title="Lo que viene" :crumbs="[{label:'Recursos humanos'},{label:'Lo que viene',to:'/rrhh/pronto'}]"></PageHead>
      <div class="card"><Empty icon="🔎" title="No encontramos esa función" text="Puede que haya cambiado de nombre o que ya esté disponible en el menú."><a class="btn sec" href="#/rrhh/pronto">Ver todo lo que viene</a></Empty></div>
    </template>
  </div>`,
};
