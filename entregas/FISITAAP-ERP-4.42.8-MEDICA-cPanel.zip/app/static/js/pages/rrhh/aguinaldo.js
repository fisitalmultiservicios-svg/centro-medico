// Recursos humanos › Aguinaldo: pago anual (Ley 2412: un doceavo de lo devengado del 1 de diciembre al 30 de noviembre; se paga
// a más tardar el 20 de diciembre). Lo devengado sale de las planillas PAGADAS (complementarias incluidas); cada monto se puede
// ajustar (por ejemplo, si parte del año se pagó fuera del sistema). Incluye a quien salió durante el período sin liquidación guardada
// (si tuvo liquidación, el aguinaldo proporcional ya se le pagó ahí). Al registrarlo sale del banco, se envía el comprobante y su
// asiento automático usa la provisión de aguinaldo que fueron reservando las planillas (solo el exceso va a gasto).
// 4.7: el pago registrado queda cerrado (no se cambia ni se elimina). Si faltó pagar algo (una planilla pagada después, un empleado
// que quedó fuera), «Calcular diferencia» compara con lo ya pagado del año y la diferencia se registra como PAGO ADICIONAL ligado al
// primero (adicional, referencia_id), con su propia salida del banco, comprobante y asiento.
import { api, abrirArchivo, money, fecha, hoy, toast, mock } from '../../api.js';
import { empleados, nombreCompleto, liquidaciones } from './_datos.js';
import { store } from '../../app.js';
import { cuentaPrincipal, cuentasParaMovimientos, registrarMovimientoBanco, revertirMovimientoBanco, refUnica, problemaMoneda } from '../bancos/cuentas.js';
import { descargarReporte, registrarExportable, elegirFormato } from '../reportes/_montos.js';
import { esPagada, crucesPagados } from './_datos.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const ocupados = new Set();           // pagos que se están registrando o eliminando (evita el doble clic)

// Período del aguinaldo del año: 1 de diciembre del año anterior al 30 de noviembre
export function periodoAguinaldo(anio) { return [(anio - 1) + '-12-01', anio + '-11-30']; }
// Planillas cuyo período termina dentro del rango (pagadas o no)
export function planillasDelPeriodo(planillas, desde, hasta) { return (planillas || []).filter(pl => { const f = String(pl.hasta || pl.fecha || ''); return f >= desde && f <= hasta; }); }
// Lo devengado por cada empleado en planillas PAGADAS cuyo período termina dentro del rango (salario bruto: ordinario, extras y otros).
// 4.7 (riesgo 2): antes sumaba también las planillas generadas sin pagar y el aguinaldo podía salir inflado; las complementarias
// pagadas sí cuentan (corrigen lo devengado). Las sin pagar y los cruces de fechas entre pagadas se avisan en la pantalla.
// 4.7 (C7): por empleado, solo lo pagado desde su fecha de ingreso de la ficha: a un recontratado no se le suma el contrato anterior
// (su aguinaldo proporcional ya se pagó en la liquidación de esa salida)
export function devengadoPorEmpleado(planillas, desde, hasta) {
  const out = {}, ingreso = Object.fromEntries(empleados().map(e => [e.id, e.fecha_ingreso || '']));
  for (const pl of planillasDelPeriodo(planillas, desde, hasta)) {
    if (!esPagada(pl)) continue;
    const f = String(pl.hasta || pl.fecha || '');
    for (const x of pl.filas || []) {
      if (ingreso[x.empleado_id] && f < ingreso[x.empleado_id]) continue;
      out[x.empleado_id] = r2((out[x.empleado_id] || 0) + (+x.bruto || 0));
    }
  }
  return out;
}
// 4.7: lo ya pagado del aguinaldo de un año por empleado (el pago del año y sus pagos adicionales), y una firma de esos pagos para
// notar que otra persona registró uno mientras se calculaba
export function pagadoPorEmpleado(aguinaldos, anio) {
  const out = {};
  for (const a of aguinaldos || []) if (+a.anio === +anio) for (const f of a.filas || []) out[f.empleado_id] = r2((out[f.empleado_id] || 0) + (+f.monto || 0));
  return out;
}
export function firmaPagos(aguinaldos, anio) { return (aguinaldos || []).filter(a => +a.anio === +anio).map(a => a.id + ':' + r2(a.total)).sort().join('|'); }
export function documentoAguinaldo(a, formato) {
  const M = v => money(v || 0);
  return descargarReporte(formato, { titulo: 'Aguinaldo ' + a.anio + (a.adicional ? ' · pago adicional' : ''), subtitulo: 'Un doceavo de lo devengado del ' + fecha(a.desde) + ' al ' + fecha(a.hasta) + ' (Ley 2412)' + (a.fecha ? ' · pagado el ' + fecha(a.fecha) + (a.cuenta ? ' desde ' + a.cuenta : '') : ''),
    periodo: fecha(a.desde) + ' al ' + fecha(a.hasta), kpis: [{ t: 'Total pagado', v: M(a.total) }, { t: 'Empleados', v: String((a.filas || []).length) }, { t: 'Devengado en el período', v: M((a.filas || []).reduce((s, f) => s + (+f.devengado || 0), 0)) }],
    cols: [{ key: 'nombre', label: 'Empleado' }, { key: 'numero_id', label: 'Identificación' }, { key: 'devengado', label: 'Devengado en planillas', num: true }, { key: 'monto', label: 'Aguinaldo', num: true }],
    rows: (a.filas || []).map(f => ({ nombre: f.nombre, numero_id: f.numero_id || '', devengado: M(f.devengado), monto: M(f.monto) })), totales: [{ t: 'Total del aguinaldo', v: M(a.total) }],
    nota: (a.adicional ? 'Pago adicional: diferencia sobre lo ya pagado del aguinaldo ' + a.anio + '. ' : '') + 'El aguinaldo no cotiza a la CCSS ni paga impuesto sobre la renta. Se paga a más tardar el 20 de diciembre.', archivo: 'aguinaldo_' + a.anio + (a.adicional ? '_adicional_' + a.id : '') });
}

export default {
  props: ['params'],
  data() {
    const anio = new Date().getMonth() === 11 || new Date().getMonth() === 10 ? new Date().getFullYear() : new Date().getFullYear() - 1;
    return { anio, lista: mock.get('rrhh_aguinaldos', []) || [], filas: [], cuentasLista: null, cuenta: '', fechaPago: hoy(), calculado: false, ver: null, enviar: true, enviando: null, revision: null, imprimir: null };
  },
  computed: {
    periodo() { return periodoAguinaldo(+this.anio); },
    // 4.7: lo que el cálculo no suma o que hay que revisar: planillas del período sin pagar y cruces de fechas entre pagadas
    sinPagar() { return planillasDelPeriodo(mock.get('planillas', []) || [], this.periodo[0], this.periodo[1]).filter(p => !esPagada(p)); },
    cruces() { const todas = mock.get('planillas', []) || []; return crucesPagados(todas, planillasDelPeriodo(todas, this.periodo[0], this.periodo[1])); },
    total() { return r2(this.filas.reduce((s, f) => s + (+f.monto || 0), 0)); },
    // 4.7: el pago del año (el primero, no un pago adicional); con él, «Calcular» calcula la diferencia contra lo ya pagado
    yaPagado() { return this.lista.find(a => +a.anio === +this.anio && !a.adicional) || this.lista.find(a => +a.anio === +this.anio) || null; },
    adicionales() { return this.lista.filter(a => +a.anio === +this.anio && a.adicional); },
    correoListo() { const e = store.empresa || {}; return !!((e.rrhh_smtp_host && e.rrhh_smtp_remitente) || e.smtp_host); },
    vence() { const d = this.anio + '-12-20'; return d >= hoy() ? Math.round((new Date(d + 'T00:00:00') - new Date(hoy() + 'T00:00:00')) / 86400000) : null; },
  },
  // 4.42: al abrir el detalle de un pago se revisan las cuentas de quienes cobran en él (el aguinaldo no tiene cuadro «Marcar pagada»)
  watch: { ver(a) { if (a) this.revisarCuentas('aguinaldo', a); } },
  methods: {
    money, fecha,
    // 4.7 (C4): texto de un cruce de fechas entre planillas pagadas: si una de las dos cierra fuera del período, solo la otra se suma en
    // lo devengado de este período
    textoCruce(c) {
      const [d, h] = this.periodo, en = p => { const f = String(p.hasta || p.fecha || ''); return f >= d && f <= h; };
      const fuera = !en(c.a) ? c.a : (!en(c.b) ? c.b : null), dentro = fuera === c.a ? c.b : c.a;
      return (c.nombre || 'Un empleado') + ' aparece en dos planillas pagadas con fechas que se cruzan: ' + c.a.numero + ' (' + fecha(c.a.desde) + ' – ' + fecha(c.a.hasta) + ') y ' + c.b.numero + ' (' + fecha(c.b.desde) + ' – ' + fecha(c.b.hasta) + '). '
        + (fuera ? 'Solo ' + dentro.numero + ' se suma en lo devengado de este período (' + fuera.numero + ' cierra fuera de él): revise si se le pagó dos veces.' : 'Las dos se suman en lo devengado: revise si se le pagó dos veces.');
    },
    calcular() {
      const [desde, hasta] = this.periodo, dev = devengadoPorEmpleado(mock.get('planillas', []) || [], desde, hasta);
      const pagos = mock.get('rrhh_aguinaldos', []) || [], ya = pagadoPorEmpleado(pagos, this.anio);
      this.lista = pagos; this._firmaPagos = firmaPagos(pagos, this.anio);
      const liq = liquidaciones();
      // activos, más quienes salieron dentro del período sin liquidación (la liquidación ya paga el aguinaldo proporcional)
      const emps = empleados().filter(e => e.activo !== false || (dev[e.id] > 0 && !liq.some(l => l.empleado_id === e.id) && (!e.fecha_salida || (e.fecha_salida >= desde && e.fecha_salida <= hasta))));
      this.filas = emps.map(e => ({ empleado_id: e.id, nombre: nombreCompleto(e), numero_id: e.numero_id || '', correo: e.correo || '', puesto: e.puesto || '', devengado: dev[e.id] || 0, ya_pagado: ya[e.id] || 0, monto: r2(Math.max(0, r2((dev[e.id] || 0) / 12) - (ya[e.id] || 0))), inactivo: e.activo === false }));
      this.calculado = true;
      if (!this.filas.length) toast('No hay empleados activos', 'err');
      else if (!Object.keys(dev).length) toast('No hay planillas pagadas en el período' + (this.sinPagar.length ? ' (' + this.sinPagar.length + ' sin pagar)' : '') + ': indique los montos a mano', 'err');
      else if (this.yaPagado) {
        // 4.7: con el año ya pagado, el aviso de planillas sin pagar de la pantalla no se muestra: se dice aquí. (C8) Los cruces de fechas
        // entre planillas pagadas sí se muestran arriba (también con el año pagado) y aquí se recuerdan: la diferencia los suma
        const sp = this.sinPagar.length ? (this.sinPagar.length === 1 ? '1 planilla del período no se suma porque no está pagada' : this.sinPagar.length + ' planillas del período no se suman porque no están pagadas') + ': ' + this.sinPagar.map(p => p.numero).join(', ') + '. ' : '';
        const cr = this.cruces.length ? (this.cruces.length === 1 ? 'Hay un empleado en dos planillas pagadas con fechas que se cruzan' : 'Hay ' + this.cruces.length + ' cruces de fechas entre planillas pagadas con el mismo empleado') + ': lo devengado los suma; revise el aviso de arriba antes de registrar la diferencia. ' : '';
        if (!this.filas.some(f => f.monto > 0)) toast(sp + cr + 'El aguinaldo ' + this.anio + ' ya se pagó completo según las planillas pagadas. ' + (sp ? 'Márquelas pagadas en Planilla y calcule de nuevo, o escriba el monto del empleado' : 'Si falta pagar algo, escriba el monto del empleado'), sp || cr ? 'err' : 'ok');
        else if (sp || cr) toast(sp + cr + (sp ? 'La diferencia se calculó sin ellas: márquelas pagadas en Planilla y calcule de nuevo, o ajuste a mano el monto del empleado' : 'Si se le pagó dos veces, ajuste a mano el monto del empleado'), 'err');
      }
    },
    async prepararCuentas() {
      if (!this.cuentasLista) this.cuentasLista = await cuentasParaMovimientos();
      if (!this.cuenta) { const b = cuentaPrincipal('CRC', this.cuentasLista); this.cuenta = b ? b.nombre : ''; }
    },
    async registrar() {
      if (!mock.puedeGuardar()) return;
      // 4.7: el pago del año ya registrado no se cambia ni se elimina: lo de ahora es un PAGO ADICIONAL (la diferencia que faltó pagar,
      // calculada contra lo ya pagado), ligado al primero y registrado como cualquier pago
      const orig = this.yaPagado;
      const filas = this.filas.filter(f => +f.monto > 0).map(f => ({ ...f, monto: r2(f.monto) }));
      if (!filas.length) return toast(orig ? 'No hay diferencias por pagar del aguinaldo ' + this.anio + ': ya se pagó lo calculado' : 'No hay montos por pagar', 'err');
      if (!this.cuenta) return toast('Seleccione la cuenta de la que sale el pago', 'err');
      if (problemaMoneda(this.cuenta, 'CRC', 1, this.cuentasLista || [])) return toast('El aguinaldo se paga en colones: elija una cuenta en colones', 'err');
      if (orig && !confirm('El aguinaldo ' + this.anio + ' ya se pagó el ' + fecha(orig.fecha) + ' y no se cambia.\n\nSe registrará un PAGO ADICIONAL de ' + money(r2(filas.reduce((s, f) => s + f.monto, 0))) + ' a ' + filas.length + (filas.length === 1 ? ' empleado' : ' empleados') + ', solo con la diferencia, ligado a ese pago. ¿Continuar?')) return;
      const clave = 'anio:' + this.anio;
      if (ocupados.has(clave)) return;
      ocupados.add(clave);
      try {
        // 4.7 (C5): lo último guardado antes de registrar: otra persona (u otra pestaña) pudo registrar un pago del año mientras se
        // calculaba y la copia de esta pantalla no lo sabría. Si los pagos del año cambiaron desde el cálculo, no se registra nada
        const gen = mock.generacion;
        await mock.refrescar(['rrhh_aguinaldos'], { sinCorte: true });
        if (mock.generacion !== gen || !mock.cargado) return;
        const frescos = mock.get('rrhh_aguinaldos', []) || [];
        if (firmaPagos(frescos, this.anio) !== this._firmaPagos) { this.lista = frescos; this.calculado = false; return toast('Otra persona registró un pago del aguinaldo ' + this.anio + ' mientras tanto: calcule de nuevo', 'err'); }
        const ref = refUnica('aguinaldo'), total = r2(filas.reduce((s, f) => s + f.monto, 0));
        let nuevo = null;
        this.lista = mock.actualizar('rrhh_aguinaldos', l => {
          const lista = Array.isArray(l) ? l : [];
          // otra persona registró un pago del año mientras se calculaba: no se registra (se calcula de nuevo contra lo último pagado)
          if (firmaPagos(lista, this.anio) !== this._firmaPagos) return lista;
          nuevo = { id: mock.nextId(lista, 'rrhh_aguinaldos'), anio: +this.anio, desde: this.periodo[0], hasta: this.periodo[1], fecha: this.fechaPago, cuenta: this.cuenta, filas, total, ref_mov: ref, estado: 'Pagado' };
          if (orig) Object.assign(nuevo, { adicional: true, referencia_id: orig.id });
          return [...lista, nuevo];
        }, []);
        if (!nuevo) { this.calculado = false; return toast('Otra persona registró un pago del aguinaldo ' + this.anio + ' mientras tanto: calcule de nuevo', 'err'); }
        registrarMovimientoBanco(this.cuenta, -total, this.fechaPago, 'Aguinaldo ' + this.anio + (orig ? ' (pago adicional)' : '') + ' · ' + filas.length + ' empleados', ref, true, 'CRC', 1);
        this.calculado = false; this.filas = [];
        toast((orig ? 'Pago adicional del aguinaldo ' : 'Aguinaldo ') + this.anio + ' registrado: ' + money(total) + ' desde ' + nuevo.cuenta, 'ok');
        if (this.enviar && this.correoListo) await this.enviarComprobantes(nuevo);
        await this.verRecienRegistrado(nuevo);
      } finally { ocupados.delete(clave); }
    },
    // 4.42: el comprobante de aguinaldo de cada empleado lo arma y lo envía el servidor con lo GUARDADO (los montos del pago y el correo
    // de la ficha de cada empleado): la pantalla solo dice cuál pago. Primero se guarda lo pendiente (el pago recién registrado tiene
    // que estar en el servidor) y después se busca el pago por su referencia: al guardarlo, el servidor pudo darle otro número interno.
    // Se envía solo si ese pago ya quedó guardado en el servidor (lo confirmado trae su misma referencia). Si el guardado falló o quedó
    // en duda no se pide nada: con el número de la pantalla el servidor respondería «ya no existe: recargue la página» (y al recargar se
    // perdería el pago, que sigue pendiente de subir) o enviaría los comprobantes de otro pago. Los pagos de versiones anteriores no
    // tienen referencia y ya vienen del servidor: van con su id
    async enviarComprobantes(a) {
      this.enviando = a.id;
      try {
        await mock.guardarTodo();
        const g = a.ref_mov ? (mock.get('rrhh_aguinaldos', []) || []).find(x => x.ref_mov === a.ref_mov) : a;
        const c = a.ref_mov && g ? mock.confirmadoDe('rrhh_aguinaldos', g.id) : null;
        if (a.ref_mov && !(c && c.ref_mov === a.ref_mov)) {
          this.enviando = null;
          return toast(g ? 'El pago del aguinaldo todavía no se guardó en el servidor y no se enviaron los comprobantes. No recargue la página: cuando se guarde, pulse ✉ Comprobantes'
            : 'El pago del aguinaldo no quedó guardado en el servidor y no se enviaron los comprobantes', 'err');
        }
        const r = await api('/api/rrhh/comprobantes-pago/aguinaldo/' + g.id, { method: 'POST', body: {} });
        const partes = [r.enviados + ' comprobante' + (r.enviados === 1 ? '' : 's') + ' enviado' + (r.enviados === 1 ? '' : 's')];
        if (r.sin_correo.length) partes.push(r.sin_correo.length + ' sin correo (' + r.sin_correo.slice(0, 3).join(', ') + (r.sin_correo.length > 3 ? '…' : '') + ')');
        if (r.fallidos.length) partes.push(r.fallidos.length + ' con error: ' + r.fallidos.map(x => x.nombre + ' (' + x.error + ')').slice(0, 2).join('; '));
        toast(partes.join(' · '), r.fallidos.length ? 'err' : 'ok');
      } catch (e) { toast('No se enviaron los comprobantes: ' + e.message, 'err'); }
      this.enviando = null;
    },
    // 4.21: el comprobante de aguinaldo de un empleado en PDF (el mismo que llega por correo; lo arma el servidor con lo guardado)
    async comprobante(a, f) {
      const nombre = 'comprobante_aguinaldo_' + a.anio + (a.adicional ? '_A' + a.id : '') + '_' + String(f.nombre || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.pdf';
      try {
        await abrirArchivo('/api/rrhh/comprobante-pago/aguinaldo/' + a.id + '/' + f.empleado_id, nombre);
        registrarExportable(nombre, 'Comprobante de aguinaldo · ' + f.nombre, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: el pago tal como quedó guardado EN EL SERVIDOR: al guardarlo, el servidor pudo darle otro número interno; se busca por su
    // referencia y se exige que lo confirmado traiga esa misma referencia, igual que el envío de comprobantes (los pagos de versiones
    // anteriores no tienen referencia y ya vienen del servidor: con su id). Se llama DESPUÉS de guardar lo pendiente. Si el pago recién
    // registrado todavía no quedó guardado (el guardado falló o quedó en duda) no se le pide nada al servidor: con el número de la
    // pantalla respondería «ya no existe: recargue la página» (y al recargar se perdería el pago, que sigue pendiente de subir) o
    // mostraría la lista de otro pago. Se dice con un error que cada quien muestra donde corresponde: la revisión, en su cuadro
    pagoGuardado(a) {
      if (!a.ref_mov) return a;
      const g = (mock.get('rrhh_aguinaldos', []) || []).find(x => x.ref_mov === a.ref_mov), c = g ? mock.confirmadoDe('rrhh_aguinaldos', g.id) : null;
      if (c && c.ref_mov === a.ref_mov) return g;
      throw new Error(g ? 'El pago del aguinaldo todavía no se guardó en el servidor. No recargue la página: cuando se guarde, vuelva a intentarlo' : 'El pago del aguinaldo no quedó guardado en el servidor');
    },
    nombrePago(a) { return 'Aguinaldo ' + a.anio + (a.adicional ? ' (adicional)' : ''); },
    // 4.42: al terminar de registrar un pago se abre su detalle, que revisa las cuentas (el aviso de `ver`): el aguinaldo se registra ya
    // pagado y no pasa por un cuadro «Marcar pagada», así que sin esto nadie veía la revisión antes de transferir, y como este pago pasa
    // a ser el «último pago» de cada persona, un cambio de cuenta anterior ya no se avisaba en la planilla siguiente. Primero se guarda
    // lo pendiente, para abrir el pago con el número que le dio el servidor; si todavía no quedó guardado se abre el de la pantalla y el
    // cuadro de la revisión lo dice. Si mientras tanto se cambió de empresa, no se abre nada
    async verRecienRegistrado(a) {
      const gen = mock.generacion;
      let g = a;
      try { await mock.guardarTodo(); g = this.pagoGuardado(a); } catch (e) { g = a; }
      if (mock.generacion !== gen || !mock.cargado) return;
      this.ver = g;
    },
    // 4.42: revisión de cuentas del detalle de un pago: cómo cobra cada persona y lo que conviene confirmar antes de transferir
    // (transferencia sin cuenta IBAN, cuenta mal escrita o cambiada desde su último pago, monto en cero). La arma el servidor con lo
    // GUARDADO (el monto de cada fila y la ficha de cada empleado): por eso primero se guarda lo pendiente. Solo avisa
    async revisarCuentas(concepto, a) {
      this.revision = { id: a.id, cargando: true, avisos: [], formas: '' };
      const vigente = () => !!this.revision && this.revision.id === a.id && this.revision.cargando;
      try {
        await mock.guardarTodo();
        const r = await api('/api/rrhh/lista-pago/' + concepto + '/' + this.pagoGuardado(a).id);
        if (!vigente()) return;
        const avisos = [...(r.avisos_generales || []), ...(r.filas || []).flatMap(f => (f.avisos || []).map(x => f.nombre + ': ' + x))];
        const formas = (r.por_forma || []).map(x => x.nombre + ': ' + x.empleados + ' (' + money(x.monto) + ')').join(' · ');
        this.revision = { id: a.id, cargando: false, avisos, formas };
      } catch (e) { if (vigente()) this.revision = { id: a.id, cargando: false, error: e.message, avisos: [], formas: '' }; }
    },
    // 4.42: la lista de pago del aguinaldo (quién cobra por transferencia, SINPE Móvil, efectivo o cheque; entidad, cuenta, monto, totales
    // y avisos) en PDF, Excel o CSV. El archivo lo arma el servidor con lo guardado; queda en el historial de descargas de Recursos humanos
    async listaPago(concepto, a, numero) {
      const formato = await elegirFormato('Lista de pago · ' + numero);
      if (!formato) return;
      const nombre = 'lista_pago_' + String(numero).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.' + formato;
      try {
        await mock.guardarTodo();
        await abrirArchivo('/api/rrhh/lista-pago/' + concepto + '/' + this.pagoGuardado(a).id + '?formato=' + formato, nombre);
        registrarExportable(nombre, 'Lista de pago · ' + numero, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: los comprobantes de un pago de aguinaldo en un solo PDF para imprimir: uno por página (los mismos que se envían por correo) y
    // al final una hoja de firmas de recibido. `imprimir.cuales`: solo quienes no tienen correo en su ficha, o todos
    async paraImprimir() {
      const { concepto, d, numero, cuales } = this.imprimir;
      const nombre = 'comprobantes_' + String(numero).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + (cuales === 'todos' ? '' : '_sin_correo') + '.pdf';
      this.imprimir.ocupado = true;
      try {
        await mock.guardarTodo();
        await abrirArchivo('/api/rrhh/comprobantes-imprimir/' + concepto + '/' + this.pagoGuardado(d).id + '?cuales=' + cuales, nombre);
        registrarExportable(nombre, 'Comprobantes para imprimir · ' + numero, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
        this.imprimir = null;
      } catch (e) { toast(e.message, 'err'); if (this.imprimir) this.imprimir.ocupado = false; }
    },
    async documento(a, formato) { try { await documentoAguinaldo(a, formato); } catch (e) { toast(e.message, 'err'); } },
    // 4.7: el aguinaldo se registra ya PAGADO (sale del banco al registrarlo) y queda cerrado: no se elimina (el servidor también lo
    // rechaza). Los registros de antes sin estado también son pagos. Uno que no esté pagado se elimina como antes.
    pagado(a) { return !!a && (!a.estado || a.estado === 'Pagado' || a.estado === 'Pagada'); },
    async eliminar(a) {
      if (!mock.puedeGuardar() || ocupados.has(a.id)) return;
      const aviso = () => toast('El aguinaldo ' + a.anio + ' está pagado y no se elimina: una diferencia se registra aparte como pago adicional (Calcular diferencia)', 'err');
      if (this.pagado(a) || this.pagado((mock.get('rrhh_aguinaldos', []) || []).find(x => x.id === a.id))) return aviso();
      if (!confirm('¿Eliminar el registro del aguinaldo ' + a.anio + '? Se revertirá la salida del banco.')) return;
      ocupados.add(a.id); const gen = mock.generacion;
      try {
        await mock.refrescar(['rrhh_aguinaldos'], { sinCorte: true });                  // lo último guardado antes de revertir nada
        if (mock.generacion !== gen || !mock.cargado) return;
        if (this.pagado((mock.get('rrhh_aguinaldos', []) || []).find(x => x.id === a.id))) { this.lista = mock.get('rrhh_aguinaldos', []) || []; this.ver = null; return aviso(); }
        if (!(await revertirMovimientoBanco([a.ref_mov]))) return;
        if (mock.generacion !== gen || !mock.cargado) return;
        this.lista = mock.actualizar('rrhh_aguinaldos', l => (Array.isArray(l) ? l : []).filter(x => x.id !== a.id), []); this.ver = null;
        toast('Registro del aguinaldo eliminado');
      } finally { ocupados.delete(a.id); }
    },
  },
  created() { this.prepararCuentas(); },
  template: `
  <div class="page">
    <PageHead title="Aguinaldo" sub="Pago anual: un doceavo de lo devengado del 1 de diciembre al 30 de noviembre (Ley 2412). Se paga a más tardar el 20 de diciembre." :crumbs="[{label:'Recursos humanos'},{label:'Aguinaldo'}]"></PageHead>
    <div class="alert warn" v-if="vence !== null && vence <= 45 && !yaPagado">Faltan <b>{{vence}}</b> días para el 20 de diciembre, fecha límite para pagar el aguinaldo {{anio}}.</div>
    <div class="card">
      <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
        <Field label="Año"><input type="number" v-model.number="anio" min="2020" max="2100" style="width:110px" @input="calculado=false"></Field>
        <div class="small muted" style="padding-bottom:10px">Período: {{fecha(periodo[0])}} – {{fecha(periodo[1])}}</div>
        <button class="btn" @click="calcular">{{yaPagado ? 'Calcular diferencia' : 'Calcular'}}</button>
      </div>
      <div class="alert ok" v-if="yaPagado" style="margin-top:12px">El aguinaldo {{anio}} ya se registró el {{fecha(yaPagado.fecha)}} por {{money(yaPagado.total)}}<span v-if="adicionales.length">, más {{adicionales.length === 1 ? '1 pago adicional' : adicionales.length + ' pagos adicionales'}} por {{money(adicionales.reduce((s, a) => s + (+a.total || 0), 0))}}</span>. Ese pago no se cambia ni se elimina; si faltó pagar algo (una planilla pagada después, un empleado que quedó fuera), use <b>Calcular diferencia</b>: se compara con lo ya pagado y la diferencia se registra como pago adicional.</div>
      <div class="alert warn" v-if="!yaPagado && sinPagar.length" style="margin-top:12px">{{sinPagar.length === 1 ? '1 planilla del período no se suma porque no está pagada' : sinPagar.length + ' planillas del período no se suman porque no están pagadas'}}: {{sinPagar.map(p => p.numero).join(', ')}}. Lo devengado solo cuenta lo pagado: márquelas pagadas en Planilla y calcule de nuevo, o ajuste a mano el monto del empleado.</div>
      <div class="alert warn" v-if="cruces.length" style="margin-top:12px"><div v-for="(c, i) in cruces.slice(0, 8)" :key="i">{{textoCruce(c)}}</div><div v-if="cruces.length > 8">Hay {{cruces.length - 8}} cruce(s) más.</div></div>
      <template v-if="calculado && filas.length">
        <div class="table-wrap" style="margin-top:12px"><table class="tbl">
          <thead><tr><th>Empleado</th><th class="num">Devengado en planillas</th><th class="num" v-if="yaPagado">Ya pagado</th><th class="num">{{yaPagado ? 'Diferencia por pagar' : 'Aguinaldo'}}</th></tr></thead>
          <tbody><tr v-for="f in filas" :key="f.empleado_id"><td>{{f.nombre}}<span class="badge" v-if="f.inactivo" style="margin-left:6px">salió en el período</span><div class="small muted" v-if="!f.correo">sin correo registrado</div></td><td class="num">{{money(f.devengado)}}</td><td class="num" v-if="yaPagado">{{money(f.ya_pagado)}}</td><td class="num"><input class="inp" type="number" min="0" step="0.01" v-model.number="f.monto" style="width:140px;text-align:right"></td></tr></tbody>
          <tfoot><tr><th :colspan="yaPagado ? 3 : 2" style="text-align:right">Total</th><th class="num">{{money(total)}}</th></tr></tfoot>
        </table></div>
        <p class="small muted">Lo devengado sale de las planillas pagadas en el período, complementarias incluidas (sin subsidios ni pagos no salariales). Si parte del año se pagó fuera del sistema, ajuste el monto del empleado.</p>
        <div class="grid cols-2" style="margin-top:8px">
          <Field label="Cuenta de la que sale el pago" req help="Por defecto la cuenta principal en colones (Bancos)"><select v-model="cuenta"><option value="">— Seleccione —</option><option v-for="b in (cuentasLista || [])" :key="b.nombre" :value="b.nombre">{{b.nombre}} · {{b.moneda || 'CRC'}}</option></select></Field>
          <Field label="Fecha de pago" req><input type="date" v-model="fechaPago"></Field>
        </div>
        <div style="margin-top:8px"><Toggle v-model="enviar" :disabled="!correoListo" label="Enviar a cada empleado su comprobante de aguinaldo por correo (PDF)"></Toggle></div>
        <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn" @click="registrar">{{yaPagado ? 'Registrar pago adicional de ' : 'Registrar pago de '}}{{money(total)}}</button></div>
      </template>
    </div>
    <div class="card pad0">
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Año</th><th>Fecha de pago</th><th>Cuenta</th><th class="num">Empleados</th><th class="num">Total</th><th></th></tr></thead>
        <tbody>
          <tr v-for="a in lista.slice().sort((x, y) => y.anio - x.anio)" :key="a.id" style="cursor:pointer" @click="ver=a"><td>{{a.anio}}<span class="badge" v-if="a.adicional" style="margin-left:6px">pago adicional</span></td><td>{{fecha(a.fecha)}}</td><td>{{a.cuenta}}</td><td class="num">{{(a.filas||[]).length}}</td><td class="num">{{money(a.total)}}</td><td style="text-align:right"><div class="acts"><button class="btn sm sec" v-if="correoListo && pagado(a)" :disabled="enviando===a.id" title="Enviar a cada empleado su comprobante de aguinaldo al correo que tiene en su ficha" @click.stop="enviarComprobantes(a)">{{enviando===a.id ? 'Enviando…' : '✉ Comprobantes'}}</button><button class="btn sm ghost" title="Cómo cobra cada persona (transferencia, SINPE Móvil, efectivo o cheque), con totales y avisos de las cuentas: PDF, Excel o CSV" @click.stop="listaPago('aguinaldo', a, nombrePago(a))">⤓ Lista de pago</button><button class="btn sm sec" @click.stop="documento(a, 'pdf')">⤓ PDF</button><button class="btn sm sec" @click.stop="documento(a, 'docx')">⤓ Word</button><button class="btn icon" v-if="!pagado(a)" title="Eliminar" @click.stop="eliminar(a)">🗑</button><span class="muted" v-else style="cursor:help;padding:0 6px" title="Pagado: queda cerrado y no se elimina. Una diferencia se registra como pago adicional." aria-label="Pagado: no se elimina">🔒</span></div></td></tr>
        </tbody>
      </table></div>
      <Empty v-if="!lista.length" icon="🎁" title="Aún no hay pagos de aguinaldo" text="Elija el año, calcule y registre el pago."></Empty>
    </div>
    <Modal v-if="ver" :title="'Aguinaldo ' + ver.anio + (ver.adicional ? ' · pago adicional' : '')" @close="ver=null">
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Empleado</th><th class="num">Devengado</th><th class="num">Aguinaldo</th><th></th></tr></thead>
        <tbody><tr v-for="f in ver.filas" :key="f.empleado_id"><td>{{f.nombre}}</td><td class="num">{{money(f.devengado)}}</td><td class="num">{{money(f.monto)}}</td><td style="text-align:right"><button class="btn icon" v-if="pagado(ver)" title="Descargar el comprobante de aguinaldo de este empleado (PDF)" @click.stop="comprobante(ver, f)">⤓</button></td></tr></tbody>
        <tfoot><tr><th colspan="2" style="text-align:right">Total</th><th class="num">{{money(ver.total)}}</th><th></th></tr></tfoot></table></div>
      <div class="alert" :class="revision.cargando ? '' : (revision.error || revision.avisos.length ? 'warn' : 'ok')" v-if="revision && revision.id === ver.id" style="margin:10px 0 0"><b>Revisión de cuentas</b><span v-if="revision.cargando"> · revisando cómo cobra cada persona…</span><span v-else-if="revision.error"> · no se pudo revisar ({{revision.error}}).</span><span v-else-if="!revision.avisos.length"> · sin avisos.</span><span v-else> · confirme estos avisos antes de transferir.</span><ul v-if="revision.avisos.length" style="margin:4px 0 0 18px;padding:0"><li v-for="(x,j) in revision.avisos.slice(0, 12)" :key="j">{{x}}</li><li v-if="revision.avisos.length > 12">Hay {{revision.avisos.length - 12}} más: salen todos en la lista de pago.</li></ul><div class="small" v-if="revision.formas" style="margin-top:4px">{{revision.formas}}</div></div>
      <template #foot><button class="btn sec" @click="documento(ver, 'pdf')">⤓ PDF</button><button class="btn sec" @click="documento(ver, 'docx')">⤓ Word</button><button class="btn ghost" title="Cómo cobra cada persona (transferencia, SINPE Móvil, efectivo o cheque), con totales y avisos de las cuentas: PDF, Excel o CSV" @click="listaPago('aguinaldo', ver, nombrePago(ver))">⤓ Lista de pago</button><button class="btn ghost" v-if="pagado(ver)" title="Los comprobantes en un solo PDF, uno por página, con una hoja de firmas de recibido" @click="imprimir = { concepto: 'aguinaldo', d: ver, numero: nombrePago(ver), cuales: 'sin_correo', ocupado: false }">⤓ Para imprimir</button><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="imprimir" :title="'Comprobantes para imprimir · ' + imprimir.numero" @close="imprimir=null">
      <p class="small muted" style="margin-top:0">Un solo PDF con un comprobante por página (los mismos que se envían por correo) y, al final, una hoja para que cada persona firme que lo recibió.</p>
      <label class="row" style="cursor:pointer;gap:8px;margin:8px 0"><input type="radio" value="sin_correo" v-model="imprimir.cuales"> Solo quienes no tienen correo en su ficha</label>
      <label class="row" style="cursor:pointer;gap:8px;margin:8px 0"><input type="radio" value="todos" v-model="imprimir.cuales"> Todos</label>
      <template #foot><button class="btn ghost" @click="imprimir=null">Cancelar</button><button class="btn" :disabled="imprimir.ocupado" @click="paraImprimir">{{imprimir.ocupado ? 'Preparando…' : '⤓ Descargar PDF'}}</button></template>
    </Modal>
  </div>`,
};
