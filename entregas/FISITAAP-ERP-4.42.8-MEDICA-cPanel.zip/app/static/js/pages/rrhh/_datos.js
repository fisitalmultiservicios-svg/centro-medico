// Recursos humanos: registros por empresa (empleados, planillas, vacaciones_tomadas, liquidaciones, rrhh_parametros) y tablas del
// servidor (/api/rrhh/parametros: tasas, tramos, salarios mínimos, puestos). Los cálculos los hace el servidor (app/rrhh.py).
import { api, mock, hoy, toast, red } from '../../api.js';

export const PERIODOS = [['semanal', 'Semanal'], ['bisemanal', 'Bisemanal (cada 14 días)'], ['quincenal', 'Quincenal'], ['mensual', 'Mensual'], ['manual', 'Manual (por horas)']];
export const JORNADAS = [['diurna', 'Diurna · 8 h/día · 48 h/semana'], ['mixta', 'Mixta · 7 h/día · 42 h/semana'], ['nocturna', 'Nocturna · 6 h/día · 36 h/semana'], ['medio_tiempo', 'Medio tiempo · 24 h/semana']];
export const HORAS_JORNADA = { diurna: 48, mixta: 42, nocturna: 36, medio_tiempo: 24 };
export const MOTIVOS = [['despido_con', 'Despido con responsabilidad patronal'], ['renuncia', 'Renuncia'], ['despido_sin', 'Despido sin responsabilidad patronal (causa justificada)'], ['fin_contrato', 'Fin de contrato a plazo u obra'], ['pension_muerte', 'Pensión o fallecimiento']];
export const FACTOR_MES = { semanal: 52 / 12, bisemanal: 26 / 12, quincenal: 2, mensual: 1, manual: 1 };

export function empleados() { return mock.get('empleados', []) || []; }
export function guardarEmpleados(l) { return mock.set('empleados', l); }   // 4.21: devuelve la promesa del guardado (true = quedó en el servidor)
export function activos() { return empleados().filter(e => e.activo !== false); }
export function nombreCompleto(e) { return [e.nombre, e.apellidos].filter(Boolean).join(' ').trim() || '—'; }
export function periodoNombre(p) { return (PERIODOS.find(x => x[0] === p) || [p, p])[1]; }
export function horasSemana(e) { return +e.horas_semana || HORAS_JORNADA[e.jornada] || 48; }
export function salarioMensual(e) { return e.modo_salario === 'mensual' ? +e.salario_mensual || 0 : Math.round((+e.salario_hora || 0) * (horasSemana(e) / 6) * 30 * 100) / 100; }   // hora × jornada × 30 (misma base que el servidor)
export function vacacionesTomadas() { return mock.get('vacaciones_tomadas', []) || []; }
export function diasDisfrutados(id) { return vacacionesTomadas().filter(v => v.empleado_id === id).reduce((s, v) => s + (+v.dias || 0), 0); }
export function mesesCompletos(desde, hasta) {
  if (!desde) return 0;
  const a = new Date(desde + 'T00:00:00'), b = new Date((hasta || hoy()) + 'T00:00:00');
  if (b < a) return 0;
  let m = (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth());
  if (b.getDate() < a.getDate() && b.getDate() !== new Date(b.getFullYear(), b.getMonth() + 1, 0).getDate()) m -= 1;   // fin de mes completa el mes, como el servidor (R307)
  return Math.max(0, m);
}
// Ficha del empleado en PDF o Word: datos, cálculo de un mes completo, cálculo del período de pago elegido y vacaciones.
// Los dos cálculos se piden al servidor (mismas reglas que el panel de la pantalla).
export async function fichaEmpleado(e, t, formato, descargarReporte, money, fmt, fecha) {
  const per = e.periodo_pago === 'manual' ? 'mensual' : e.periodo_pago;
  const pedir = p => api('/api/rrhh/calcular', { method: 'POST', body: { empleado: paraServidor(e), periodo: p, dias_vac_disfrutados: e.id ? diasDisfrutados(e.id) : 0 } });
  const mes = await pedir('mensual'); const periodo = per === 'mensual' ? mes : await pedir(per);
  const M = v => money(v || 0), kv = (dato, valor) => ({ dato, valor: valor === null || valor === undefined || valor === '' ? '—' : String(valor) });
  const cat = ((t && t.efectivos && t.efectivos.categorias) || []).find(c => c.codigo === e.categoria);
  const datos = [kv('Nombre', nombreCompleto(e)), kv('Identificación', (e.tipo_id === '01' ? 'Cédula' : e.tipo_id === '03' ? 'DIMEX' : e.tipo_id === '04' ? 'NITE' : 'Extranjero') + ' ' + (e.numero_id || '')), kv('Vence la identificación', e.vence_id ? fecha(e.vence_id) : ''), kv('Fecha de nacimiento', e.nacimiento ? fecha(e.nacimiento) : ''),
    kv('Nacionalidad', e.nacionalidad), kv('Vence el permiso de trabajo o residencia', e.vence_permiso ? fecha(e.vence_permiso) : ''), kv('Correo', e.correo), kv('Teléfono', e.telefono), kv('Dirección', e.direccion), kv('Contacto de emergencia', [e.emergencia_nombre, e.emergencia_telefono].filter(Boolean).join(' · ')),
    kv('Hijos / cónyuge', (e.hijos || 0) + (e.conyuge ? ' · con cónyuge' : '')), kv('Puesto', e.puesto), kv('Categoría salarial', cat ? cat.nombre + ' (' + cat.codigo + ')' : e.categoria),
    kv('Fecha de ingreso', fecha(e.fecha_ingreso)), kv('Antigüedad', mes.antiguedad ? mes.antiguedad.meses + ' meses (' + mes.antiguedad.anios + ' años)' : ''),
    kv('Jornada', (JORNADAS.find(j => j[0] === e.jornada) || [e.jornada, e.jornada])[1] + ' · ' + horasSemana(e) + ' h/semana'),
    kv('Salario', e.modo_salario === 'mensual' ? M(e.salario_mensual) + ' por mes' : M(e.salario_hora) + ' por hora'), kv('Período de pago', periodoNombre(e.periodo_pago)),
    kv('Forma de pago', { transferencia: 'Transferencia / depósito', efectivo: 'Efectivo', cheque: 'Cheque' }[e.forma_pago] || e.forma_pago), kv('Cuenta IBAN', e.cuenta_iban),
    kv('Retiene renta', e.aplica_renta === false ? 'No' : 'Sí, según tramos'), kv('Estado', e.activo === false ? 'Inactivo' + (e.fecha_salida ? ' desde ' + fecha(e.fecha_salida) : '') : 'Activo')];
  const PAT = { sem: 'CCSS – Seguro de salud (SEM)', ivm: 'CCSS – Pensiones (IVM)', banco_popular: 'Banco Popular (cuota patronal)', fodesaf: 'FODESAF', imas: 'IMAS', ina: 'INA', fcl: 'Fondo de capitalización laboral (FCL)', rop_opc: 'ROP – Operadora de pensiones (OPC)', rop_bp: 'ROP – Banco Popular (LPT)', rop: 'ROP', ins_riesgos: 'INS – riesgos del trabajo' };
  const OBR = { sem: 'CCSS – Seguro de salud (SEM)', ivm: 'CCSS – Pensiones (IVM)', banco_popular: 'Banco Popular' };
  const PROV = { aguinaldo: 'Aguinaldo', vacaciones: 'Vacaciones', cesantia: 'Cesantía', preaviso: 'Preaviso', otros: 'Otros' };
  const pct = (k, tabla) => { const v = t && t.efectivos && t.efectivos[tabla] && t.efectivos[tabla][k]; return v !== undefined ? fmt(v, 2) + ' %' : ''; };
  const desglose = (c, nombrePeriodo) => {
    const filas = [{ concepto: 'Salario bruto del período (' + fmt(c.horas, 1) + ' h)', pct: '', monto: M(c.bruto) }];
    for (const [k, v] of Object.entries(c.obrero || {})) filas.push({ concepto: '− ' + (OBR[k] || k), pct: pct(k, 'obrero'), monto: M(v) });
    filas.push({ concepto: '− Impuesto sobre la renta', pct: '', monto: M(c.renta) });
    filas.push({ concepto: 'Total de deducciones', pct: fmt(c.pct_obrero, 2) + ' % + renta', monto: M(c.total_deducciones) });
    filas.push({ concepto: 'NETO A PAGAR', pct: '', monto: M(c.neto) });
    for (const [k, v] of Object.entries(c.patrono || {})) filas.push({ concepto: 'Patrono: ' + (PAT[k] || k), pct: k === 'ins_riesgos' ? (e.ins_riesgos !== null && e.ins_riesgos !== '' && e.ins_riesgos !== undefined ? fmt(e.ins_riesgos, 2) + ' %' : pct('ins_riesgos', null) || '') : pct(k, 'patrono'), monto: M(v) });
    filas.push({ concepto: 'Total cargas patronales', pct: fmt(c.pct_patronal, 2) + ' %', monto: M(c.total_patronal) });
    for (const [k, v] of Object.entries(c.provisiones || {})) if (+v) filas.push({ concepto: 'Reserva: ' + (PROV[k] || k), pct: pct(k, 'provisiones'), monto: M(v) });
    filas.push({ concepto: 'Total reservas', pct: fmt(c.pct_provisiones, 2) + ' %', monto: M(c.total_provisiones) });
    return { titulo: nombrePeriodo, columnas: [{ key: 'concepto', label: 'Concepto' }, { key: 'pct', label: 'Tasa', num: true }, { key: 'monto', label: 'Monto', num: true }], filas: filas.map(f => ({ ...f, monto: String(f.monto), pct: String(f.pct) })),
      totales: [{ t: 'Neto a pagar', v: M(c.neto) }, { t: 'Costo total para la empresa', v: M(c.costo_total) }] };
  };
  const vac = mes.vacaciones || {};
  const secciones = [
    { titulo: 'Datos del empleado', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor' }], filas: datos },
    desglose(mes, 'Cálculo de un mes completo'),
  ];
  if (per !== 'mensual') secciones.push(desglose(periodo, 'Cálculo del período de pago: ' + periodoNombre(e.periodo_pago)));
  secciones.push({ titulo: 'Vacaciones', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor', num: true }],
    filas: [kv('Meses completos trabajados', vac.meses), kv('Días ganados', vac.dias_ganados), kv('Días disfrutados', vac.dias_disfrutados), kv('Saldo de días', vac.saldo)] });
  await descargarReporte(formato, { titulo: 'Ficha del empleado · ' + nombreCompleto(e), subtitulo: 'Datos, salario, deducciones, cargas patronales y reservas según los parámetros vigentes de la empresa.',
    periodo: 'Al ' + fecha(hoy()), kpis: [{ t: 'Salario mensual', v: M(mes.salario_mensual) }, { t: 'Neto mensual', v: M(mes.neto) }, { t: 'Costo mensual para la empresa', v: M(mes.costo_total) }, { t: 'Vacaciones (saldo)', v: (vac.saldo ?? 0) + ' días' }],
    cols: [], rows: [], secciones, nota: mes.minimo_mensual ? 'Salario mínimo de referencia de la categoría: ' + M(mes.minimo_mensual) + ' por mes.' : null, archivo: 'empleado_' + (e.numero_id || e.id || 'nuevo'), privado: true });   // 4.7: la ficha (nombre y cédula) va al historial de RRHH, no al general
}
// 4.21: constancia salarial en PDF o Word: datos del trabajador, salario bruto mensual actual y promedio de los últimos `meses` meses
// según las planillas PAGADAS (promedioSalarial), fecha de emisión y línea de firma. Texto genérico y montos brutos: no lleva
// deducciones ni datos fiscales. Antes de armarla trae lo último guardado (otra pestaña pudo pagar una planilla o cambiar la ficha)
// y sale SIEMPRE con la ficha guardada: ni con la fila de la lista calculada antes de refrescar ni con lo escrito en la ficha sin guardar.
export async function constanciaSalarial(e, { meses = 6, firmaNombre = '', firmaCargo = '' }, formato, descargarReporte, money, fecha) {
  await mock.refrescar(['planillas', 'empleados']);
  e = empleados().find(x => x.id === e.id) || e;
  const n =[3, 6, 12].includes(+meses) ? +meses : 6, pr = promedioSalarial(e.id, hoy(), n), activo = e.activo !== false;
  const kv = (dato, valor) => ({ dato, valor: valor === null || valor === undefined || valor === '' ? '—' : String(valor) });
  const secciones = [
    { titulo: 'Datos del trabajador', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor' }], filas: [kv('Nombre', nombreCompleto(e)),
      kv('Identificación', (e.tipo_id === '01' ? 'Cédula' : e.tipo_id === '03' ? 'DIMEX' : e.tipo_id === '04' ? 'NITE' : 'Extranjero') + ' ' + (e.numero_id || '')), kv('Puesto', e.puesto), kv('Departamento', e.departamento),
      kv('Fecha de ingreso', e.fecha_ingreso ? fecha(e.fecha_ingreso) : ''), ...(!activo && e.fecha_salida ? [kv('Fecha de salida', fecha(e.fecha_salida))] : []), kv('Estado', activo ? 'Activo' : 'Inactivo')] },
    { titulo: 'Salario', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor' }], filas: [kv('Salario bruto mensual actual' + (e.modo_salario === 'mensual' ? '' : ' (estimado: salario por hora por la jornada)'), money(salarioMensual(e))),
      kv('Promedio mensual de los últimos ' + n + ' meses', pr.meses ? money(pr.promedio) + ' (' + pr.planillas + (pr.planillas === 1 ? ' planilla pagada' : ' planillas pagadas') + ' desde el ' + fecha(pr.desde) + ')' : 'Sin planillas pagadas en el período')] },
  ];
  const texto = 'Se hace constar que ' + nombreCompleto(e) + ' ' + (activo ? 'labora' : 'laboró') + ' para la empresa' + (e.fecha_ingreso ? ' desde el ' + fecha(e.fecha_ingreso) : '') + (!activo && e.fecha_salida ? ' hasta el ' + fecha(e.fecha_salida) : '') + '.';
  await descargarReporte(formato, { titulo: ('Constancia salarial · ' + nombreCompleto(e)).slice(0, 120), subtitulo: texto.slice(0, 300), periodo: 'Emitida el ' + fecha(hoy()), cols: [], rows: [], secciones,
    nota: 'Montos brutos en colones, antes de deducciones. El promedio sale de las planillas pagadas registradas en el sistema.', firma: { nombre: firmaNombre, cargo: firmaCargo }, archivo: 'empleado_constancia_' + (e.numero_id || e.id), privado: true });
}
// Días ganados como los calcula el servidor: 12 por cada bloque completo de 50 semanas + 1 por mes completo del resto (R310)
export function diasGanados(desde, hasta, porMes = 1) {
  if (!desde) return 0;
  const a = new Date(desde + 'T00:00:00'), b = new Date((hasta || hoy()) + 'T00:00:00');
  if (b < a) return 0;
  const dias = Math.floor((b - a) / 86400000), bloques = Math.floor(dias / 350);
  const r = new Date(a); r.setDate(r.getDate() + bloques * 350);
  const resto = `${r.getFullYear()}-${String(r.getMonth() + 1).padStart(2, '0')}-${String(r.getDate()).padStart(2, '0')}`;
  return Math.round((bloques * 12 * porMes + mesesCompletos(resto, hasta) * porMes) * 100) / 100;
}
// Feriados de ley de fecha fija (los movibles, Jueves y Viernes Santo, se descuentan a mano si aplica) (R311)
export const FERIADOS_FIJOS = ['01-01', '04-11', '05-01', '07-25', '08-02', '08-15', '09-15', '12-01', '12-25'];
export function paraServidor(e) { const { historial, ...resto } = e; return { ...resto, nombre_completo: nombreCompleto(e) }; }

// ---- Acciones de personal (4.21, registro rrhh_acciones) ----
// [{id, numero 'AP-0001', empleado_id, nombre (copia del nombre), tipo, fecha, rige, hasta (solo suspensión), antes y despues (la foto
// del puesto: fotoPuesto), motivo, detalle, aplicada_a_ficha, estado 'Registrada' | 'Anulada', motivo_anulacion}] más lo que sella el
// servidor: registrada_por, registrada_en, anulada_por, anulada_en, aplicada_por y aplicada_en. Una acción guardada no se edita ni
// se elimina (el servidor lo rechaza): se anula con su motivo. Solo vive en la nube y solo la recibe quien tiene Recursos humanos.
export const TIPOS_ACCION = [['ingreso', 'Ingreso'], ['aumento', 'Aumento'], ['traslado', 'Traslado'], ['cambio_puesto', 'Cambio de puesto'], ['amonestacion', 'Amonestación'], ['suspension', 'Suspensión'], ['salida', 'Salida']];
// las que cambian la ficha (salario, o puesto, departamento y categoría); las demás solo dejan constancia
export const ACCIONES_A_FICHA = ['aumento', 'traslado', 'cambio_puesto'];
export function tipoAccion(t) { return (TIPOS_ACCION.find(x => x[0] === t) || [t, t])[1]; }
// 4.22: devuelve TODO lo guardado, también las marcas {id, numero, estado 'Eliminada', eliminada_en} que el servidor deja en lugar de
// las acciones de una ficha eliminada (sin ningún dato personal: solo guardan el número, para que no se repita jamás). NO se filtran
// aquí: de esta lista salen el número siguiente (numeroAccion) y lo que se guarda con mock.set; sin las marcas, el guardado intentaría
// borrarlas y el servidor respondería 403. Se filtran solo al MOSTRAR (rows() de acciones.js; accionesDe ya las deja fuera porque
// una marca no tiene empleado_id).
export function acciones() { return mock.get('rrhh_acciones', []) || []; }
export function accionesDe(empId) { return acciones().filter(a => a.empleado_id === empId); }
export function fotoPuesto(e) {
  return { puesto: e.puesto || '', departamento: e.departamento || '', departamento_id: e.departamento_id || null, categoria: e.categoria || '', modo_salario: e.modo_salario === 'mensual' ? 'mensual' : 'hora',
    salario: e.modo_salario === 'mensual' ? +e.salario_mensual || 0 : +e.salario_hora || 0, salario_mensual: salarioMensual(e) };
}
// 4.22: ¿dos fotos del puesto dicen lo mismo? Se compara campo por campo y no con JSON.stringify: la foto que guardó una acción (su
// «antes») vuelve del servidor, y ni el orden de sus claves ni un 600000.0 deben hacer fallar la comparación con la ficha de hoy.
// Puesto, departamento, categoría y modo de salario, como texto recortado; el id del departamento, con nulo, vacío o ausente como
// «sin departamento»; el salario y su equivalente mensual, como número con tolerancia de medio céntimo.
export function mismaFoto(a, b) {
  const x = a || {}, y = b || {}, texto = v => String(v ?? '').trim(), id = v => (v ? String(v) : ''), cerca = k => Math.abs((+x[k] || 0) - (+y[k] || 0)) < 0.005;
  return ['puesto', 'departamento', 'categoria', 'modo_salario'].every(k => texto(x[k]) === texto(y[k])) && id(x.departamento_id) === id(y.departamento_id) && cerca('salario') && cerca('salario_mensual');
}
// Hora de Costa Rica (UTC−6, sin horario de verano) con el formato del servidor; el sello que queda guardado lo pone el servidor
export function ahoraCR() { return new Date(Date.now() - 6 * 3600000).toISOString().slice(0, 19) + '-06:00'; }
export function numeroAccion(lista) {
  const usados = (lista || []).map(x => /^AP-(\d+)$/.exec(String((x && x.numero) || ''))).filter(Boolean).map(m => +m[1]);
  return 'AP-' + String((usados.length ? Math.max(...usados) : 0) + 1).padStart(4, '0');
}
// La acción que la ficha deja sola al guardarse: 'ingreso' en un alta; 'traslado' si cambió el departamento; 'cambio_puesto' si solo
// cambió el puesto; null si no cambió ninguno de los dos. El departamento se compara por id y, si alguna ficha no lo trae (fichas
// de antes de los departamentos), por nombre.
export function accionDeFicha(previo, e) {
  if (!previo) return 'ingreso';
  const texto = v => String(v || '').trim().toLowerCase();
  const mismoDepto = previo.departamento_id && e.departamento_id ? previo.departamento_id === e.departamento_id : texto(previo.departamento) === texto(e.departamento);
  if (!mismoDepto) return 'traslado';
  return texto(previo.puesto) !== texto(e.puesto) ? 'cambio_puesto' : null;
}
// La ficha como queda al aplicarle una acción (no guarda nada). Un aumento cambia el salario y deja su renglón en el historial de
// salario (una sola vez: aplicar de nuevo la misma acción no lo repite); un traslado o un cambio de puesto cambian puesto,
// departamento y categoría. Los demás tipos no tocan la ficha.
export function fichaConAccion(emp, a) {
  const d = a.despues || {}, e = { ...emp };
  if (a.tipo === 'aumento') {
    e.modo_salario = d.modo_salario === 'mensual' ? 'mensual' : 'hora';
    if (e.modo_salario === 'mensual') e.salario_mensual = +d.salario || 0; else e.salario_hora = +d.salario || 0;
    const motivo = 'Acción ' + a.numero, h = Array.isArray(emp.historial) ? emp.historial : [];
    e.historial = h.some(x => x.motivo === motivo) ? h : [...h, { fecha: a.rige, modo: e.modo_salario, salario: +d.salario || 0, mensual: salarioMensual(e), motivo }].slice(-60);
  } else if (a.tipo === 'traslado' || a.tipo === 'cambio_puesto') {
    e.puesto = d.puesto || ''; e.departamento = d.departamento || ''; e.departamento_id = d.departamento_id || null;
    if (d.categoria) e.categoria = d.categoria;
  }
  return e;
}
// ¿La ficha ya tiene lo que esa acción le pone? Con esto se decide si un guardado que quedó sin respuesta sí llegó al servidor
export function fichaTieneAccion(emp, a) {
  const q = fichaConAccion(emp, a), igual = k => (k.startsWith('salario_') ? (+emp[k] || 0) === (+q[k] || 0) : (emp[k] ?? null) === (q[k] ?? null));
  return ['puesto', 'departamento', 'departamento_id', 'categoria', 'modo_salario', 'salario_hora', 'salario_mensual'].every(igual) && (a.tipo !== 'aumento' || (emp.historial || []).some(x => x.motivo === 'Acción ' + a.numero));
}
// Lo guardado en el servidor de una lista (lectura directa: no toca la copia de esta pestaña); null si no se pudo leer. 4.22: tampoco
// vale la copia sin conexión: en la nube, sin red, el service worker responde esta lectura con la última copia que guardó (estado 200,
// y api() deja red.desdeCache en verdadero); eso no dice qué tiene el servidor ahora, así que cuenta como «no se pudo leer»
export async function leerGuardado(clave) { try { const r = await api('/api/registros/' + clave); if (red.desdeCache) return null; return Array.isArray(r.datos) ? r.datos : []; } catch { return null; } }
// 4.22: trae del servidor lo último guardado de esas claves, para decidir con eso. true solo si de verdad respondió el servidor; false si
// el refresco lanzó, si no se pudo consultar todo o si lo que llegó fue la copia sin conexión (red.desdeCache): en ese caso NO se sabe
// qué hay guardado, y quien llama no debe concluir ni «el servidor no aceptó» ni «no quedó»
export async function refrescarDelServidor(claves) {
  try { const r = await mock.refrescar(claves, { sinCorte: true }); return r !== false && !red.desdeCache; } catch { return false; }
}
// Registra una acción de personal y ESPERA la respuesta del servidor (que sella quién y cuándo, y no deja repetir el número).
// Devuelve { ok: true, accion } o { ok: false, incierto, numero }: «incierto» = no se pudo confirmar con el servidor si quedó o no, y
// `numero` es el que llevaba ese intento. Antes de numerar trae lo último guardado (4.22: si no se puede consultar al servidor, o solo
// responde la copia sin conexión, devuelve «incierto» sin mandar nada); si otra persona tomó el número mientras tanto,
// vuelve a numerar una vez. Si el servidor no confirma, relee lo guardado y decide con eso (no da por rechazado un guardado cuya
// respuesta se perdió) y suelta el alta de la copia local, para que no suba sola con otro guardado. Reintentar con los mismos datos y
// el número del intento que quedó en duda no la repite: si aquel intento sí se guardó, devuelve esa acción. Sigue aunque el usuario
// cambie de pantalla (la ficha sale a la lista).
export async function registrarAccion(datos, numeroReservado) {
  if (!mock.puedeGuardar(false)) return { ok: false, incierto: false };
  const gen = mock.generacion, vigente = () => mock.generacion === gen && mock.cargado;
  const CAMPOS = ['empleado_id', 'nombre', 'tipo', 'fecha', 'rige', 'hasta', 'antes', 'despues', 'motivo', 'detalle', 'aplicada_a_ficha'];
  const misma = (g, a) => !!g && g.numero === a.numero && CAMPOS.every(k => JSON.stringify(g[k] ?? null) === JSON.stringify(a[k] ?? null));
  let numero = numeroReservado || '';
  for (let intento = 0; intento < 2; intento++) {
    // 4.22: sin poder consultar al servidor (o con la copia sin conexión) no se sabe qué acciones hay ni si un intento anterior quedó:
    // no se numera ni se manda nada; queda «incierto» para reintentar cuando vuelva la conexión
    const consultado = await refrescarDelServidor(['rrhh_acciones']);
    if (!vigente() || !consultado) return { ok: false, incierto: true, numero };
    const lista = acciones(), ya = numero ? lista.find(x => misma(x, { ...datos, numero })) : null;
    if (ya) return { ok: true, accion: ya };               // un intento anterior con este número sí quedó guardado: no se registra otra vez
    if (!numero || lista.some(x => x.numero === numero)) numero = numeroAccion(lista);
    const a = { ...datos, id: mock.nextId(lista, 'rrhh_acciones'), numero, estado: 'Registrada' };
    const ok = await mock.set('rrhh_acciones', [...lista, a]);
    if (!vigente()) return { ok: false, incierto: true, numero };
    if (ok) return { ok: true, accion: acciones().find(x => misma(x, a)) || a };
    const srv = await leerGuardado('rrhh_acciones');
    if (!vigente()) return { ok: false, incierto: true, numero };
    const g = srv && srv.find(x => misma(x, a));
    if (g) { await mock.refrescar(['rrhh_acciones'], { sinCorte: true }).catch(() => false); return { ok: true, accion: g }; }
    mock.set('rrhh_acciones', acciones().filter(x => !(x.id === a.id && misma(x, a))));
    if (!srv) return { ok: false, incierto: true, numero };
    if (!srv.some(x => x.numero === a.numero)) return { ok: false, incierto: false };       // el servidor la rechazó por otra causa (ya lo avisó)
  }
  return { ok: false, incierto: false };
}
// Lo que la ficha deja sola al guardarse (accionDeFicha): espera a que la ficha quede guardada (si no se guardó, no registra nada) y
// no detiene la pantalla. Un alta cuyo id ya estaba ocupado recibe otro del servidor: por eso la ficha se busca por su identificación.
export async function registrarAccionDeFicha(guardada, tipo, previo, e, correo) {
  try {
    if (!tipo || !(await guardada)) return null;
    const ficha = empleados().find(x => x.id === e.id && x.numero_id === e.numero_id) || empleados().filter(x => x.numero_id === e.numero_id).pop();
    if (!ficha) return null;
    const nombre = nombreCompleto(ficha);
    const r = await registrarAccion({ empleado_id: ficha.id, nombre: nombre.slice(0, 200), tipo, fecha: hoy(), rige: tipo === 'ingreso' ? (ficha.fecha_ingreso || hoy()) : hoy(), hasta: '', antes: fotoPuesto(previo || ficha), despues: fotoPuesto(ficha),
      motivo: tipo === 'ingreso' ? 'Ingreso a la empresa' : 'Cambio en la ficha', detalle: '', aplicada_a_ficha: true, registrada_por: correo || '', registrada_en: ahoraCR() });
    if (r.ok) toast('Acción de personal ' + r.accion.numero + ' registrada: ' + tipoAccion(tipo) + ' de ' + nombre, 'ok');
    else toast('La ficha de ' + nombre + ' sí se guardó, pero ' + (r.incierto ? 'no se pudo confirmar' : 'no quedó') + ' su acción de personal (' + tipoAccion(tipo) + '): revísela en Recursos humanos › Acciones de personal y, si falta, regístrela ahí', 'err');
    return r;
  } catch { return null; }
}

// ---- Documentos del empleado (4.22, registro rrhh_documentos) ----
// [{id, empleado_id, tipo, nombre, vence 'AAAA-MM-DD' | '', archivo, bytes, mime, subido_por, subido_en}], cada uno con su archivo (PDF,
// JPG o PNG) en el servidor. El registro lo escribe SOLO el servidor, por sus rutas (/api/rrhh/empleados/<id>/documentos para subir
// y /api/rrhh/documentos/<id> para ver, cambiar y eliminar): aquí se lee y nunca se guarda con mock.set (el servidor lo rechaza).
// Solo vive en la nube y solo lo recibe quien tiene Recursos humanos.
export const TIPOS_DOCUMENTO = [['contrato', 'Contrato'], ['identificacion', 'Identificación'], ['permiso_trabajo', 'Permiso de trabajo'], ['titulo', 'Título o certificado'], ['otro', 'Otro']];
export const MAX_BYTES_DOCUMENTO = 5 * 1024 * 1024;
export function tipoDocumento(t) { return (TIPOS_DOCUMENTO.find(x => x[0] === t) || [t, t])[1]; }
export function documentos() { return mock.get('rrhh_documentos', []) || []; }
export function documentosDe(empId) { return documentos().filter(d => d.empleado_id === empId); }
export function tamanoArchivo(b) { const n = +b || 0; return n >= 1048576 ? (Math.round(n / 104857.6) / 10).toString().replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
// Lo que ya venció o vence dentro de `dias` días, de la más próxima a la más lejana: las dos fechas de la ficha (identificación y
// permiso de trabajo o residencia) y los documentos subidos que tengan vencimiento. `docs`: los documentos de ese empleado (sin ellos
// se leen del registro). Solo compara la fecha que escribió el usuario con la de hoy: no dice qué documentos pide la ley ni cuánto
// dura cada permiso. Devuelve [{que, fecha, vencido}]; «vencido» es que la fecha ya pasó (el día en que vence todavía vale).
export function vencimientos(e, dias = 30, docs = null) {
  const h = hoy(), lim = sumarDiasISO(h, dias), out = [];
  const ver = (que, f) => { if (/^\d{4}-\d{2}-\d{2}$/.test(String(f || '')) && f <= lim) out.push({ que, fecha: f, vencido: f < h }); };
  ver('Identificación', e && e.vence_id); ver('Permiso de trabajo o residencia', e && e.vence_permiso);
  for (const d of docs || (e && e.id ? documentosDe(e.id) : [])) ver(tipoDocumento(d.tipo) + (d.nombre && d.nombre !== tipoDocumento(d.tipo) ? ' «' + d.nombre + '»' : ''), d.vence);
  return out.sort((a, b) => a.fecha.localeCompare(b.fecha));
}

// ---- ausencias e incapacidades (registro rrhh_ausencias) y deducciones/ingresos recurrentes (rrhh_conceptos) ----
export const TIPOS_AUSENCIA = [['incapacidad_ccss', 'Incapacidad por enfermedad (CCSS)'], ['incapacidad_ins', 'Incapacidad por riesgo del trabajo (INS)'], ['maternidad', 'Licencia de maternidad'],
  ['permiso_sin_goce', 'Permiso sin goce de salario'], ['injustificada', 'Ausencia injustificada'], ['permiso_con_goce', 'Permiso con goce de salario']];
export const CATEGORIAS_DEDUCCION = [['prestamo', 'Préstamo de la empresa'], ['adelanto', 'Adelanto de salario'], ['embargo', 'Embargo judicial'], ['pension', 'Pensión alimentaria'],
  ['asociacion', 'Asociación solidarista (aporte del trabajador)'], ['seguro', 'Seguro o póliza'], ['otro', 'Otra deducción']];
export const CATEGORIAS_INGRESO = [['bonificacion', 'Bonificación'], ['comision', 'Comisión'], ['antiguedad', 'Plus por antigüedad'], ['viaticos', 'Viáticos (no salarial)'], ['subsidio', 'Subsidio (no salarial)'], ['otro', 'Otro ingreso']];
export const NO_SALARIAL = ['viaticos', 'subsidio'];
export function tipoAusencia(t) { return (TIPOS_AUSENCIA.find(x => x[0] === t) || [t, t])[1]; }
export function ausencias() { return mock.get('rrhh_ausencias', []) || []; }
export function conceptos() { return mock.get('rrhh_conceptos', []) || []; }
export function planillas() { return mock.get('planillas', []) || []; }
export function liquidaciones() { return mock.get('liquidaciones', []) || []; }
// 4.7: una planilla o una liquidación cuentan en los informes del mes y en el aguinaldo solo cuando están pagadas (estado 'Pagada',
// el que ponen Planilla y Liquidaciones al marcarlas pagadas); las generadas o pendientes de pago se avisan, no se suman
export const ESTADO_PAGADA = 'Pagada';
export function esPagada(x) { return !!x && x.estado === ESTADO_PAGADA; }
export function planillasPagadas() { return planillas().filter(esPagada); }
// 4.7: planilla complementaria: corrige o completa otra ya pagada y queda ligada a ella (referencia_id); cuenta si está pagada
export function esComplementaria(p) { return !!(p && p.complementaria); }
// 4.7: el mismo empleado en dos planillas pagadas no complementarias cuyas fechas se cruzan (posible pago doble en datos viejos).
// No se descarta ninguna: las pantallas lo avisan. `foco`: solo los cruces en los que participa alguna de esas planillas.
export function crucesPagados(lista, foco) {
  const pl = (lista || []).filter(p => esPagada(p) && !esComplementaria(p) && p.desde && p.hasta), ids = foco ? new Set(foco.map(p => p.id)) : null, out = [];
  for (let i = 0; i < pl.length; i++) for (let j = i + 1; j < pl.length; j++) {
    const a = pl[i], b = pl[j];
    if ((ids && !ids.has(a.id) && !ids.has(b.id)) || a.desde > b.hasta || b.desde > a.hasta) continue;
    const enA = new Set((a.filas || []).map(f => f.empleado_id).filter(x => x !== null && x !== undefined));
    for (const f of b.filas || []) if (enA.has(f.empleado_id)) out.push({ empleado_id: f.empleado_id, nombre: f.nombre || '', a, b });
  }
  return out;
}
// 4.7: rubros de una liquidación que son SALARIO y se reportan en el mes a la CCSS, al INS y en la renta: el salario pendiente y las
// vacaciones pagadas (la misma regla con que el servidor calcula la CCSS de la liquidación, rrhh.liquidacion). El preaviso, la
// cesantía y el aguinaldo proporcional NO son salario: no cotizan ni se reportan. Se comparan por el inicio del nombre del rubro.
export const RUBROS_LIQUIDACION_SALARIALES = ['Salario pendiente', 'Vacaciones'];
export function partesLiquidacion(l) {
  let salarial = 0, noSalarial = 0, dias = 0;
  for (const x of (l && l.rubros) || []) {
    const nombre = String((x && x.rubro) || ''), m = +(x && x.monto) || 0;
    if (/^deducci[oó]n/i.test(nombre)) continue;
    if (RUBROS_LIQUIDACION_SALARIALES.some(r => nombre.startsWith(r))) { salarial += m; if (nombre.startsWith('Salario pendiente')) dias += +x.dias || 0; }
    else noSalarial += m;
  }
  const r = n => Math.round(n * 100) / 100;
  return { salarial: r(salarial), no_salarial: r(noSalarial), dias: r(dias) };
}
// Días naturales entre dos fechas AAAA-MM-DD, ambas incluidas (0 si el orden está invertido)
export function diasEntre(a, b) { if (!a || !b) return 0; const d1 = new Date(a + 'T00:00:00'), d2 = new Date(b + 'T00:00:00'); return d2 < d1 ? 0 : Math.round((d2 - d1) / 86400000) + 1; }
export function horasDia(e) { const j = { diurna: 8, mixta: 7, nocturna: 6, medio_tiempo: 4 }[e.jornada] || 8; const hs = horasSemana(e); return hs === (HORAS_JORNADA[e.jornada] || 48) ? j : (hs ? hs / 6 : j); }
export function salarioDiario(e) { return Math.round(salarioMensual(e) / 30 * 100) / 100; }
// Lo que paga el patrono de una incapacidad (misma regla que el servidor: enfermedad 50 % de los primeros 3 días, riesgo el día del
// accidente, maternidad 50 % de todos). `desdeInicio`: días de la incapacidad que ya pasaron antes del tramo que se calcula.
export function subsidioPatrono(tipo, dias, diario, params, pctPatrono, desdeInicio = 0) {
  const inc = (params && params.incapacidad) || { enfermedad_dias_patrono: 3, enfermedad_pct: 50, riesgo_dias_patrono: 1, riesgo_pct: 100, maternidad_pct: 50 };
  let dp = 0, pct = 0;
  if (tipo === 'incapacidad_ccss') { dp = Math.max(0, Math.min(dias, (+inc.enfermedad_dias_patrono || 0) - desdeInicio)); pct = +inc.enfermedad_pct || 0; }
  else if (tipo === 'incapacidad_ins') { dp = Math.max(0, Math.min(dias, (+inc.riesgo_dias_patrono || 0) - desdeInicio)); pct = +inc.riesgo_pct || 0; }
  else if (tipo === 'maternidad') { dp = dias; pct = +inc.maternidad_pct || 0; }
  else return { dias_patrono: 0, pct: 0, monto: 0 };
  if (pctPatrono !== null && pctPatrono !== undefined && pctPatrono !== '') pct = +pctPatrono;
  return { dias_patrono: dp, pct, monto: Math.round(diario * dp * pct) / 100 };
}
// Ausencias de un empleado que caen en un período: días sin salario, subsidio patronal (no salarial), la parte de la licencia de
// maternidad que paga la CCSS (se descuenta del neto: el salario completo sigue cotizando, art. 95) y el detalle
export function ausenciasEn(e, desde, hasta, params) {
  const out = { dias_ausencia: 0, no_salariales: 0, deducciones: [], detalle: [] }, diario = salarioDiario(e);
  for (const a of ausencias().filter(x => x.empleado_id === e.id)) {
    const ini = a.desde > desde ? a.desde : desde, fin = (a.hasta || a.desde) < hasta ? (a.hasta || a.desde) : hasta;
    const dias = diasEntre(ini, fin);
    if (!dias) continue;
    const d = { tipo: a.tipo, nombre: tipoAusencia(a.tipo), desde: ini, hasta: fin, dias, subsidio: 0 };
    if (a.tipo === 'maternidad') {
      const s = subsidioPatrono(a.tipo, dias, diario, params, a.pct_patrono);
      const ccss = Math.round((diario * dias - s.monto) * 100) / 100;                 // lo que la CCSS le paga directamente a la trabajadora
      if (ccss > 0) out.deducciones.push({ concepto: 'Licencia de maternidad: parte que paga la CCSS (' + dias + ' d)', categoria: 'maternidad', monto: ccss });
      d.subsidio = s.monto; d.ccss = ccss;
    } else if (a.tipo !== 'permiso_con_goce') {
      out.dias_ausencia += dias;
      const s = subsidioPatrono(a.tipo, dias, diario, params, a.pct_patrono, Math.max(0, diasEntre(a.desde, ini) - 1));
      d.subsidio = s.monto; out.no_salariales = Math.round((out.no_salariales + s.monto) * 100) / 100;
    }
    out.detalle.push(d);
  }
  return out;
}
// ---- horas extra y de feriado (registro rrhh_horas_extra, 2.3): un registro por empleado y día; la planilla las suma sola ----
export const TIPOS_HORA = [['extra', 'Hora extra (tiempo y medio)'], ['feriado', 'Feriado trabajado (recargo del feriado)']];
export function tipoHora(t) { return (TIPOS_HORA.find(x => x[0] === t) || [t, t])[1]; }
export function horasExtra() { return mock.get('rrhh_horas_extra', []) || []; }
// Horas extra y de feriado de un empleado registradas dentro del período (ambas fechas incluidas)
export function horasExtraEn(e, desde, hasta) {
  const out = { horas_extra: 0, horas_feriado: 0, detalle: [] };
  for (const h of horasExtra().filter(x => x.empleado_id === e.id && x.fecha >= desde && x.fecha <= hasta)) {
    const n = +h.horas || 0; if (!n) continue;
    if (h.tipo === 'feriado') out.horas_feriado += n; else out.horas_extra += n;
    out.detalle.push({ fecha: h.fecha, tipo: h.tipo, horas: n, nota: h.nota || '' });
  }
  out.horas_extra = Math.round(out.horas_extra * 100) / 100; out.horas_feriado = Math.round(out.horas_feriado * 100) / 100;
  return out;
}
// Conceptos recurrentes vigentes de un empleado en el período, en el formato que espera el servidor
export function conceptosEn(e, desde, hasta) {
  const ded = [], ing = [];
  for (const c of conceptos().filter(x => x.empleado_id === e.id && x.activa !== false)) {
    if ((c.desde && c.desde > hasta) || (c.hasta && c.hasta < desde)) continue;
    const conSaldo = ['prestamo', 'adelanto'].includes(c.categoria);
    if (conSaldo && !(+c.saldo > 0)) continue;                                           // préstamo ya cancelado
    const base = { id: c.id, concepto: c.concepto, categoria: c.categoria };
    if (c.tipo === 'ingreso') ing.push({ ...base, monto: +c.valor || 0, salarial: !NO_SALARIAL.includes(c.categoria) && c.salarial !== false });
    else ded.push(c.modo === 'porcentaje' ? { ...base, pct: +c.valor || 0, tope: conSaldo ? +c.saldo : null } : { ...base, monto: +c.valor || 0, tope: conSaldo ? Math.min(+c.valor || 0, +c.saldo) : null });
  }
  return { deducciones: ded, ingresos: ing };
}
// Al guardar (signo −1) o eliminar (+1) una planilla, los préstamos y adelantos descuentan o recuperan lo aplicado
export function aplicarSaldos(planilla, signo) {
  const aplicados = [];
  for (const f of planilla.filas || []) for (const d of f.detalle_deducciones || []) if (d.id && ['prestamo', 'adelanto'].includes(d.categoria)) aplicados.push([d.id, +d.monto || 0]);
  if (!aplicados.length) return;
  mock.actualizar('rrhh_conceptos', l => (l || []).map(c => { const m = aplicados.filter(x => x[0] === c.id).reduce((s, x) => s + x[1], 0); return m ? { ...c, saldo: Math.max(0, Math.round(((+c.saldo || 0) + signo * m) * 100) / 100) } : c; }), []);
}
// 4.21: estado de cuenta de un préstamo o adelanto. Saldo inicial (el monto total), un abono por cada planilla guardada que le
// descontó cuota (las generadas sin pagar también: el saldo baja al guardar la planilla), las correcciones manuales del saldo
// (c.ajustes, las deja Deducciones e ingresos al editar el saldo) y el saldo actual. Si las cuentas no cuadran queda un renglón de
// diferencia (saldos corregidos antes de esta versión o abonos fuera del sistema). Un concepto viejo sin monto total usa como saldo
// inicial el saldo actual más lo abonado y lo marca «estimado». Las planillas eliminadas devolvieron su cuota y no aparecen.
export function estadoCuentaConcepto(c) {
  const r2 = n => Math.round((+n || 0) * 100) / 100, movimientos = [];
  for (const p of planillas()) for (const f of p.filas || []) {
    if (f.empleado_id !== c.empleado_id) continue;
    for (const d of f.detalle_deducciones || []) if (d.id === c.id && ['prestamo', 'adelanto'].includes(d.categoria)) movimientos.push({ tipo: 'abono', fecha: p.hasta || p.fecha || '', ref: p.numero || '', pagada: esPagada(p), monto: -r2(d.monto) });
  }
  for (const a of Array.isArray(c.ajustes) ? c.ajustes : []) movimientos.push({ tipo: 'ajuste', fecha: a.fecha || '', usuario: a.usuario || '', nota: a.nota || '', antes: r2(a.antes), despues: r2(a.despues), monto: r2((+a.despues || 0) - (+a.antes || 0)) });
  movimientos.sort((x, y) => String(x.fecha).localeCompare(String(y.fecha)));
  const saldo = r2(c.saldo), abonado = r2(-movimientos.filter(m => m.tipo === 'abono').reduce((s, m) => s + m.monto, 0));
  const estimado = !(+c.total > 0), inicial = estimado ? r2(saldo - movimientos.reduce((s, m) => s + m.monto, 0)) : r2(c.total);
  let corrido = inicial;
  for (const m of movimientos) { corrido = r2(corrido + m.monto); m.saldo = corrido; }
  const diferencia = r2(saldo - corrido);
  if (diferencia) movimientos.push({ tipo: 'diferencia', fecha: '', monto: diferencia, saldo });
  return { inicial, estimado, desde: c.desde || '', movimientos, abonado, saldo, diferencia };
}
// Salario promedio de los últimos `meses` meses según las planillas PAGADAS (para liquidaciones: art. 29 y 153). 4.7: antes sumaba
// también las generadas sin pagar; las complementarias pagadas sí cuentan (completan el salario de su período).
// 4.7 (C6): es lo pagado entre el TIEMPO que cubren las planillas del empleado (parteDelMes: una quincena es medio mes, una semana
// 12/52 y la manual sus días), no entre los meses distintos vistos: una última quincena sin pagar ya no cuenta como un mes completo.
// La ventana va del mismo día de hace `meses` meses (o el último de ese mes) a `hasta`; una planilla que empezó antes cuenta solo por
// sus días dentro (su salario y su tiempo en la misma proporción): una salida el día 30 ya no mete un séptimo mes. Una complementaria
// suma su monto, y su tiempo solo a quien no está en ninguna ordinaria pagada con fechas que se cruzan (se quedó fuera de la planilla
// de ese período y se le pagó ahí). (C7) Solo cuenta lo pagado desde la fecha de ingreso de la ficha: a un recontratado no se le mezcla
// el contrato anterior. Devuelve en `meses` el tiempo cubierto (puede tener decimales).
export function promedioSalarial(empId, hasta, meses = 6) {
  const h = hasta || hoy(), iso = x => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
  const d = new Date(+h.slice(0, 4), +h.slice(5, 7) - 1 - meses, 1);
  d.setDate(Math.min(+h.slice(8, 10) || 1, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()));
  const desde = iso(d); d.setDate(d.getDate() + 1);
  const primero = iso(d), ingreso = ingresoEmpleado(empId);
  let total = 0, n = 0, cubre = 0;
  for (const p of planillasPagadas()) {
    const f = String(p.hasta || p.fecha || '');
    if (f <= desde || f > h || (ingreso && f < ingreso)) continue;
    const suyas = (p.filas || []).filter(x => x.empleado_id === empId);
    if (!suyas.length) continue;
    const dias = diasEntre(p.desde, f), w = dias > 0 && String(p.desde) < primero ? diasEntre(primero, f) / dias : 1;
    for (const x of suyas) { total += (+x.bruto || 0) * w; n++; }
    if (!esComplementaria(p) || !enOrdinariaCruzada(p, empId)) cubre += parteDelMes(p) * w;
  }
  return { total: Math.round(total * 100) / 100, planillas: n, meses: Math.round(cubre * 100) / 100, promedio: cubre > 0 ? Math.round(total / cubre * 100) / 100 : 0, desde };
}
// 4.7 (C6): parte de un mes que paga una planilla: por su período (quincenal 1/2, semanal 12/52, bisemanal 12/26, como FACTOR_MES) o,
// en la manual (o sin período), por sus días entre los del mes en que cierra
export function parteDelMes(p) {
  if (p && p.periodo && p.periodo !== 'manual' && FACTOR_MES[p.periodo]) return 1 / FACTOR_MES[p.periodo];
  const f = String((p && p.hasta) || ''), dm = /^\d{4}-\d{2}/.test(f) ? new Date(+f.slice(0, 4), +f.slice(5, 7), 0).getDate() : 30;
  return (diasEntre(p && p.desde, p && p.hasta) || dm) / dm;
}
// 4.7 (C6): ¿el empleado está en una planilla ORDINARIA pagada con fechas que se cruzan con las de `p`? Si está, una complementaria de
// esas fechas solo completa montos de un período ya contado; si no, le pagó ese período (como en los informes, C2)
export function enOrdinariaCruzada(p, empId) {
  return planillasPagadas().some(q => !esComplementaria(q) && q.id !== p.id && q.desde && q.hasta && q.desde <= p.hasta && q.hasta >= p.desde && (q.filas || []).some(x => x.empleado_id === empId));
}
// 4.7 (C7): fecha de ingreso de la ficha (la del contrato actual de un recontratado); '' si no la tiene
export function ingresoEmpleado(empId) { const e = empleados().find(x => x.id === empId); return (e && e.fecha_ingreso) || ''; }
// Lo devengado por un empleado en planillas PAGADAS con cierre dentro del rango (aguinaldo proporcional en la liquidación). 4.7: antes
// sumaba también las generadas sin pagar; las complementarias pagadas sí cuentan. Las sin pagar se avisan (planillasSinPagarDe).
// 4.7 (C7): nunca antes de la fecha de ingreso de la ficha: lo del contrato anterior de un recontratado ya se pagó en su liquidación
export function devengadoDesde(empId, desde, hasta) {
  const ingreso = ingresoEmpleado(empId), ini = ingreso && ingreso > desde ? ingreso : desde;
  let t = 0;
  for (const p of planillasPagadas()) { const f = String(p.hasta || p.fecha || ''); if (f < ini || f > hasta) continue; for (const x of p.filas || []) if (x.empleado_id === empId) t += +x.bruto || 0; }
  return Math.round(t * 100) / 100;
}
// 4.7: planillas sin pagar de un empleado con cierre dentro del rango: no cuentan en el promedio ni en lo devengado y se avisan
export function planillasSinPagarDe(empId, desde, hasta) {
  return planillas().filter(p => { const f = String(p.hasta || p.fecha || ''); return !esPagada(p) && f >= desde && f <= hasta && (p.filas || []).some(x => x.empleado_id === empId); });
}
// 4.7: días de vacaciones disfrutados sin los que pagó una liquidación (registrados con liquidacion_id). Con ellos se recalcula la
// liquidación completa de quien ya tiene una pagada, para guardar solo la diferencia (diferenciaLiquidacion)
export function diasDisfrutadosSinLiquidacion(id) { return vacacionesTomadas().filter(v => v.empleado_id === id && !v.liquidacion_id).reduce((s, v) => s + (+v.dias || 0), 0); }
// 4.7: liquidaciones de un empleado en su contratación actual: las de una salida anterior a su fecha de ingreso son de un contrato
// anterior (lo volvieron a contratar) y no cuentan como lo ya pagado de esta salida
export function liquidacionesDelContrato(lista, emp) { return (lista || []).filter(l => !!emp && l.empleado_id === emp.id && !(emp.fecha_ingreso && l.fecha_salida && l.fecha_salida < emp.fecha_ingreso)); }
// 4.7: liquidación ADICIONAL. Una liquidación pagada no se cambia ni se elimina; si faltó pagar algo, se calcula de nuevo la liquidación
// completa (`r`, del servidor) y se paga solo la diferencia por rubro contra lo ya pagado (`previas`: la original y sus adicionales).
// Lo pagado de más no se rebaja aquí: sale en de_mas para avisarlo. La CCSS obrera y patronal van sobre la diferencia salarial
// (salario pendiente y vacaciones, RUBROS_LIQUIDACION_SALARIALES) con las tasas del mismo cálculo. Los rubros se reconocen por el nombre.
export const CLASES_RUBRO_LIQUIDACION = [['salario', /^salario pendiente/i], ['preaviso', /preaviso/i], ['cesantia', /cesant[ií]a/i], ['vacaciones', /^vacaciones/i], ['aguinaldo', /aguinaldo/i]];
export function claseRubroLiquidacion(nombre) { const n = String(nombre || '').trim(), c = CLASES_RUBRO_LIQUIDACION.find(x => x[1].test(n)); return c ? c[0] : n.toLowerCase(); }
export function diferenciaLiquidacion(r, previas) {
  const r2 = n => Math.round((+n || 0) * 100) / 100, esRebajo = x => !x || +x.monto < 0 || /^deducci[oó]n/i.test(String(x.rubro || ''));
  const pagado = {}, rubros = [], deMas = [];
  for (const l of previas || []) for (const x of (l && l.rubros) || []) {
    if (esRebajo(x)) continue;
    const k = claseRubroLiquidacion(x.rubro), y = pagado[k] = pagado[k] || { monto: 0, dias: 0 };
    y.monto += +x.monto || 0; y.dias += +x.dias || 0;
  }
  let base = 0;
  for (const x of (r && r.rubros) || []) {
    if (esRebajo(x)) continue;
    const y = pagado[claseRubroLiquidacion(x.rubro)] || { monto: 0, dias: 0 }, dif = r2((+x.monto || 0) - y.monto);
    if (dif > 0) {
      rubros.push({ rubro: x.rubro, dias: r2(Math.max(0, (+x.dias || 0) - y.dias)), monto: dif, base: 'Diferencia: ' + r2(x.monto).toFixed(2) + ' calculado − ' + r2(y.monto).toFixed(2) + ' ya pagado' });
      if (RUBROS_LIQUIDACION_SALARIALES.some(s => String(x.rubro || '').startsWith(s))) base += dif;
    } else if (dif < 0) deMas.push({ rubro: x.rubro, monto: -dif });
  }
  base = r2(base);
  const tasa = (k, monto) => (r && r[k] !== undefined && r[k] !== null ? +r[k] || 0 : (r && +r.base_ccss ? (+r[monto] || 0) * 100 / +r.base_ccss : 0));
  const pctO = tasa('ccss_obrera_pct', 'ccss_obrera'), pctP = tasa('ccss_patronal_pct', 'ccss_patronal'), ccssO = r2(base * pctO / 100), ccssP = r2(base * pctP / 100);
  if (ccssO > 0) rubros.push({ rubro: 'Deducción CCSS obrera', dias: 0, monto: -ccssO, base: r2(pctO) + ' % sobre la diferencia de salario pendiente y vacaciones (' + base.toFixed(2) + ')' });
  const pagadoTotal = r2((previas || []).reduce((s, l) => s + (+(l && l.total) || 0), 0));
  return { rubros, total: r2(rubros.reduce((s, x) => s + x.monto, 0)), base_ccss: base, ccss_obrera: ccssO, ccss_patronal: ccssP, pagado: pagadoTotal, de_mas: deMas };
}
export function inicioAguinaldo(fecha) { const f = fecha || hoy(), y = +f.slice(0, 4), m = +f.slice(5, 7); return (m < 12 ? y - 1 : y) + '-12-01'; }
export const TIPOS_CONTRATO = [['indefinido', 'Tiempo indefinido'], ['plazo_fijo', 'Plazo fijo'], ['obra', 'Obra determinada'], ['temporal', 'Temporal / por temporada']];
export const FORMAS_PAGO = { transferencia: 'Transferencia / depósito', efectivo: 'Efectivo', cheque: 'Cheque', sinpe: 'SINPE Móvil' };

let _tablas = null;
export async function tablas(forzar) { if (!_tablas || forzar) _tablas = await api('/api/rrhh/parametros'); return _tablas; }
export function limpiarTablas() { _tablas = null; }

// Fila base de un empleado nuevo
export function empleadoNuevo() {
  return { id: null, nombre: '', apellidos: '', tipo_id: '01', numero_id: '', nacimiento: '', nacionalidad: 'Costarricense', correo: '', telefono: '', direccion: '',
           emergencia_nombre: '', emergencia_telefono: '', hijos: 0, conyuge: false,
           puesto: '', categoria: 'TOSC', fecha_ingreso: hoy(), jornada: 'diurna', horas_semana: 48, modo_salario: 'hora', salario_hora: null, salario_mensual: null,
           periodo_pago: 'quincenal', forma_pago: 'transferencia', cuenta_iban: '', aplica_renta: true, ins_riesgos: null, activo: true, fecha_salida: '', notas: '',
           tipo_contrato: 'indefinido', fecha_fin_contrato: '', departamento: '', departamento_id: null, supervisor: '', vence_id: '', vence_permiso: '', historial: [] };
}

// ---- Horarios de trabajo (3.43): departamentos, turnos por departamento y asignación semanal ----
// rrhh_departamentos: [{id, nombre, activo}] · rrhh_turnos: [{id, departamento_id, nombre, codigo, inicio 'HH:MM', fin 'HH:MM',
// descanso_min, personas, color, activo}] · rrhh_horarios: [{id, empleado_id, semana 'AAAA-MM-DD' (lunes), dias: [7 × turno_id | 'L' | null]}]
export const DIAS_SEMANA = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
export const COLORES_TURNO = ['#0f766e', '#1d5fd1', '#b45309', '#a3204f', '#5b21b6', '#15803d', '#0e7490', '#7c2d12'];
export function departamentos() { return (mock.get('rrhh_departamentos', []) || []).filter(d => d && d.nombre); }
export function turnos() { return (mock.get('rrhh_turnos', []) || []).filter(t => t && t.nombre); }
export function horarios() { return mock.get('rrhh_horarios', []) || []; }
export function departamentoDe(e) {
  // el departamento del empleado: por id si lo tiene; si solo trae el texto viejo, se busca por nombre
  if (!e) return null; const ds = departamentos();
  if (e.departamento_id) return ds.find(d => d.id === e.departamento_id) || null;
  const n = String(e.departamento || '').trim().toLowerCase(); return n ? ds.find(d => d.nombre.trim().toLowerCase() === n) || null : null;
}
export function lunesDe(iso) { const d = new Date(String(iso || hoy()).slice(0, 10) + 'T00:00:00'); const k = (d.getDay() + 6) % 7; d.setDate(d.getDate() - k); return d.toISOString().slice(0, 10); }
export function sumarDiasISO(iso, n) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function esFeriado(iso) { return FERIADOS_FIJOS.includes(String(iso || '').slice(5)); }
export function horasTurno(t) {
  if (!t || !t.inicio || !t.fin) return 0;
  const [h1, m1] = t.inicio.split(':').map(Number), [h2, m2] = t.fin.split(':').map(Number);
  let min = (h2 * 60 + m2) - (h1 * 60 + m1); if (min <= 0) min += 24 * 60;          // cruza la medianoche (turno de noche)
  return Math.max(0, Math.round((min - (+t.descanso_min || 0)) / 6) / 10);
}
export function turnoNocturno(t) { if (!t || !t.inicio) return false; const h = +t.inicio.split(':')[0]; const hf = +t.fin.split(':')[0]; return h >= 19 || h < 5 || hf <= 6 && hf < h; }
// Horario de un empleado en una semana (fila guardada o vacía)
export function horarioDe(empId, semana) { return horarios().find(h => h.empleado_id === empId && h.semana === semana) || null; }
export function diasDe(empId, semana) { const h = horarioDe(empId, semana); return h && Array.isArray(h.dias) ? h.dias.slice(0, 7).concat(Array(7).fill(null)).slice(0, 7) : Array(7).fill(null); }
// partes del día (3.44): [{t: turno_id, h: horas}] cuando el día no es un único turno completo (horas extra); null si no aplica
export function partesDe(empId, semana) { const h = horarioDe(empId, semana); return h && Array.isArray(h.partes) ? h.partes.slice(0, 7).concat(Array(7).fill(null)).slice(0, 7).map(x => (Array.isArray(x) && x.length ? x : null)) : Array(7).fill(null); }
// Vacaciones y ausencias del empleado ese día → etiqueta corta o null
export function bloqueoDia(empId, iso) {
  if (vacacionesTomadas().some(v => v.empleado_id === empId && v.desde <= iso && (v.hasta || v.desde) >= iso)) return 'Vac';
  const a = ausencias().find(x => x.empleado_id === empId && x.desde <= iso && (x.hasta || x.desde) >= iso);
  return a ? (a.tipo && a.tipo.startsWith('incapacidad') ? 'Inc' : a.tipo === 'maternidad' ? 'Lic' : 'Aus') : null;
}
// Guarda la semana de un empleado (7 celdas). Vacía del todo = se borra la fila.
export function guardarHorario(empId, semana, dias, partes) {
  const vacia = !dias.some(x => x !== null && x !== undefined && x !== '');
  const pz = Array.isArray(partes) && partes.some(Boolean) ? partes.slice(0, 7).map(x => (Array.isArray(x) && x.length ? x.map(z => ({ t: z.t, h: Math.round((+z.h || 0) * 100) / 100 })) : null)) : null;
  mock.actualizar('rrhh_horarios', l => {
    const lista = Array.isArray(l) ? l : []; const i = lista.findIndex(h => h.empleado_id === empId && h.semana === semana);
    if (vacia) { if (i >= 0) lista.splice(i, 1); return lista; }
    const fila = { id: i >= 0 ? lista[i].id : mock.nextId(lista, 'rrhh_horarios'), empleado_id: empId, semana, dias: dias.slice(0, 7), ...(pz ? { partes: pz } : {}) };
    if (i >= 0) lista.splice(i, 1, fila); else lista.push(fila); return lista;
  }, []);
}
// Departamentos sugeridos según el tipo de negocio (se ofrecen una vez; el usuario los cambia a gusto)
export function departamentosSugeridos(tipo) {
  if (tipo === 'hospitalidad') return ['Recepción', 'Reservas', 'Seguridad', 'Ama de llaves', 'Mantenimiento', 'Restaurante y bar', 'Cocina', 'Administración'];
  if (tipo === 'comercio') return ['Caja', 'Salón', 'Cocina', 'Bodega', 'Administración'];
  return ['Administración', 'Ventas', 'Operaciones'];
}
// Turnos típicos para un departamento nuevo (el usuario los ajusta)
export function turnosSugeridos(nombre) {
  const n = String(nombre || '').toLowerCase();
  if (/segur|vigil/.test(n)) return [['Día', 'D', '06:00', '14:00'], ['Tarde', 'T', '14:00', '22:00'], ['Noche', 'N', '22:00', '06:00']];
  if (/recep|reserv|caja|salón|salon|restaur|bar|cocina/.test(n)) return [['Mañana', 'M', '06:00', '14:00'], ['Tarde', 'T', '14:00', '22:00']];
  return [['Ordinario', 'O', '08:00', '17:00']];
}
