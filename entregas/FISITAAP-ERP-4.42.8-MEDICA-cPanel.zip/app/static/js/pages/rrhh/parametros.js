// Recursos humanos › Parámetros: tasas de la CCSS (obrero y patronal), INS, reserva mensual, tramos de renta, jornadas y salarios
// mínimos por categoría del MTSS. Son valores de referencia: la empresa los verifica y corrige aquí (registro 'rrhh_parametros').
// 4.7: se guarda solo lo que difiere de los valores oficiales del sistema, más el año en que se guardó: lo legal guardado en un año
// anterior deja de aplicarse cuando el sistema trae los oficiales del año nuevo (con aviso) y lo propio de la empresa se conserva.
import { money, fmt, toast, mock } from '../../api.js';
import { tablas, limpiarTablas } from './_datos.js';

const OBRERO = [['sem', 'Seguro de salud (SEM)'], ['ivm', 'Pensiones (IVM)'], ['banco_popular', 'Banco Popular']];
const PATRONO = [['sem', 'Seguro de salud (SEM)'], ['ivm', 'Pensiones (IVM)'], ['banco_popular', 'Banco Popular'], ['fodesaf', 'Asignaciones familiares (FODESAF)'], ['imas', 'IMAS'], ['ina', 'INA'], ['fcl', 'Fondo de capitalización laboral (FCL)'], ['rop_opc', 'ROP – Operadora de pensiones complementarias (OPC)'], ['rop_bp', 'ROP – Banco Popular (Ley de Protección al Trabajador)']];   // (R314)
const PROV = [['aguinaldo', 'Aguinaldo (8,33 %: un salario mensual entre 12)'], ['vacaciones', 'Vacaciones (4,17 %: 12 días al año entre 288 días laborados)'], ['cesantia', 'Cesantía (5,33 %: 19,5 días por año entre 365)'], ['preaviso', 'Preaviso (opcional, según la política de la empresa)'], ['otros', 'Otros']];   // etiquetas que explican el porcentaje (R315)

// 4.7: datos del sistema que la empresa nunca guarda como valor suelto (las categorías se guardan aparte, por código)
const META = ['vigencia', 'anio', 'anio_guardado', 'avisos_parametros', 'parametros_ignorados', 'categorias', 'jornadas'];
const OPCION = { patrono: 'La empresa', trabajador: 'El trabajador', avisar: 'Solo avisar', limitar: 'Limitar al art. 172' };
const ETIQUETAS = {
  ...Object.fromEntries(OBRERO.map(([k, n]) => ['obrero.' + k, 'Trabajador: ' + n])), ...Object.fromEntries(PATRONO.map(([k, n]) => ['patrono.' + k, 'Patrono: ' + n])),
  ...Object.fromEntries(PROV.map(([k, n]) => ['provisiones.' + k, 'Reserva: ' + n.split(' (')[0]])),
  ins_riesgos: 'Póliza de riesgos del trabajo del INS (%)', ins_adicional: 'INS aparte de la póliza (%)', paga_ina: 'La empresa paga el INA',
  'renta.tramos': 'Tramos del impuesto sobre la renta', 'renta.credito_hijo': 'Crédito por hijo', 'renta.credito_conyuge': 'Crédito por cónyuge',
  dias_vacaciones_por_mes: 'Días de vacaciones por mes trabajado', hora_extra_factor: 'Factor de hora extra', dias_mes: 'Días por mes para el salario diario', feriado_factor: 'Factor de feriado trabajado',
  'incapacidad.enfermedad_dias_patrono': 'Enfermedad: días que paga el patrono', 'incapacidad.enfermedad_pct': 'Enfermedad: % que paga el patrono',
  'incapacidad.riesgo_dias_patrono': 'Riesgo del trabajo: días que paga el patrono', 'incapacidad.riesgo_pct': 'Riesgo del trabajo: % que paga el patrono', 'incapacidad.maternidad_pct': 'Maternidad: % que paga el patrono',
  'base_minima.sem': 'Base mínima contributiva SEM (₡)', 'base_minima.ivm': 'Base mínima contributiva IVM (₡)', aplicar_base_minima: 'Cuotas sobre la base mínima', base_minima_diferencia: 'Quién paga la diferencia de la base mínima',
  'embargo.tramo1_pct': 'Embargo: % del primer tramo', 'embargo.tramo2_pct': 'Embargo: % del segundo tramo', 'embargo.multiplo_minimo': 'Embargo: veces el menor salario mínimo',
  embargo_modo: 'Embargos que pasan del art. 172', pension_aviso_pct: 'Aviso de pensión alimentaria (%)',
  exigir_aprobacion_planilla: 'Exigir la planilla aprobada antes de marcarla pagada', aprobacion_otro_usuario: 'La aprueba un usuario distinto del que la generó',
};
const REBAJOS = { maternidad: 'parte de la licencia de maternidad que paga la CCSS', pension: 'pensión alimentaria', embargo: 'embargos', asociacion: 'asociación solidarista', prestamo: 'préstamos', adelanto: 'adelantos', seguro: 'seguros', sindicato: 'sindicato', otro: 'otras deducciones fijas', manual: 'deducciones escritas en la planilla' };
// {ruta con puntos: valor} de un objeto anidado (una lista, como los tramos de renta, es un solo valor)
function hojas(o, pre = '') { const out = {}; for (const [k, v] of Object.entries(o || {})) { const r = pre ? pre + '.' + k : k; if (v && typeof v === 'object' && !Array.isArray(v)) Object.assign(out, hojas(v, r)); else out[r] = v; } return out; }
function valorRuta(o, ruta) { return ruta.split('.').reduce((v, k) => (v && typeof v === 'object' ? v[k] : undefined), o); }
function iguales(a, b) { if (typeof b === 'number' && a !== '' && a !== null && a !== undefined && typeof a !== 'boolean' && !isNaN(+a)) return Math.abs(+a - b) < 1e-9; return JSON.stringify(a ?? null) === JSON.stringify(b ?? null); }
// lo que difiere de los valores oficiales, por hoja (los tramos de renta se comparan completos)
function diferencias(p, ref) {
  const out = {};
  for (const [k, v] of Object.entries(p)) {
    const r = ref ? ref[k] : undefined;
    if (v && typeof v === 'object' && !Array.isArray(v) && r && typeof r === 'object' && !Array.isArray(r)) { const d = diferencias(v, r); if (Object.keys(d).length) out[k] = d; }
    else if (!iguales(v, r)) out[k] = v;
  }
  return out;
}

export default {
  props: ['params'],
  data() { return { t: null, p: null, guardando: false, OBRERO, PATRONO, PROV }; },
  computed: {
    totObrero() { return this.p ? OBRERO.reduce((s, [k]) => s + (+this.p.obrero[k] || 0), 0) : 0; },
    totPatrono() { return this.p ? PATRONO.reduce((s, [k]) => s + (k === 'ina' && this.p.paga_ina === false ? 0 : +this.p.patrono[k] || 0), 0) : 0; },
    // 4.7: lo que hoy difiere de los valores oficiales del sistema, con su valor oficial (para verlo y regresar al oficial)
    personales() {
      if (!this.p || !this.t || !this.t.referencia) return [];
      const ref = this.t.referencia, out = [];
      for (const [ruta, v] of Object.entries(hojas(this.p))) { if (META.includes(ruta.split('.')[0])) continue; const r = valorRuta(ref, ruta); if (!iguales(v, r)) out.push({ ruta, valor: v, oficial: r }); }
      for (const c of this.p.categorias || []) { const r = (ref.categorias || []).find(x => x.codigo === c.codigo); if (r && !iguales(c.monto, r.monto)) out.push({ ruta: 'categorias.' + c.codigo, valor: c.monto, oficial: r.monto }); }
      return out;
    },
    totProv() { return this.p ? PROV.reduce((s, [k]) => s + (+this.p.provisiones[k] || 0), 0) : 0; },
  },
  // 4.21: «usuario distinto» solo cuenta con la aprobación exigida: al apagar la primera se apaga la segunda
  watch: { 'p.exigir_aprobacion_planilla'(v) { if (!v && this.p && this.p.aprobacion_otro_usuario) this.p.aprobacion_otro_usuario = false; } },
  methods: {
    money, fmt,
    async cargar() { try { this.t = await tablas(true); this.p = JSON.parse(JSON.stringify(this.t.efectivos)); } catch (e) { toast(e.message, 'err'); } },
    agregarTramo() { this.p.renta.tramos.splice(this.p.renta.tramos.length - 1, 0, [0, 0]); },
    quitarTramo(i) { if (this.p.renta.tramos.length > 2) this.p.renta.tramos.splice(i, 1); },
    guardar() {
      const p = this.p;
      const tramos = p.renta.tramos.map((t, i, a) => [i === a.length - 1 ? null : +t[0] || 0, +t[1] || 0]);
      for (let i = 1; i < tramos.length - 1; i++) if (tramos[i][0] <= tramos[i - 1][0]) return toast('Los límites de los tramos de renta deben ir de menor a mayor', 'err');
      const num = o => Object.fromEntries(Object.entries(o || {}).map(([k, v]) => [k, +v || 0]));   // tasa vacía = 0 (R155)
      const todo = { obrero: num(p.obrero), patrono: num(p.patrono), ins_riesgos: +p.ins_riesgos || 0, ins_adicional: +p.ins_adicional || 0, paga_ina: p.paga_ina !== false, provisiones: num(p.provisiones),
                     renta: { tramos, credito_hijo: +p.renta.credito_hijo || 0, credito_conyuge: +p.renta.credito_conyuge || 0 },
                     dias_vacaciones_por_mes: +p.dias_vacaciones_por_mes || 1, hora_extra_factor: +p.hora_extra_factor || 1.5, dias_mes: +p.dias_mes || 30,
                     feriado_factor: +p.feriado_factor || 2, incapacidad: num(p.incapacidad), base_minima: num(p.base_minima), aplicar_base_minima: !!p.aplicar_base_minima,
                     base_minima_diferencia: p.base_minima_diferencia === 'trabajador' ? 'trabajador' : 'patrono', embargo: num(p.embargo),
                     embargo_modo: p.embargo_modo === 'limitar' ? 'limitar' : 'avisar', pension_aviso_pct: +p.pension_aviso_pct || 50,
                     exigir_aprobacion_planilla: !!p.exigir_aprobacion_planilla, aprobacion_otro_usuario: !!(p.exigir_aprobacion_planilla && p.aprobacion_otro_usuario) };
      // 4.7: solo lo que difiere de los valores oficiales del sistema, más el año en que se guardó (así un año nuevo trae los oficiales)
      const ref = this.t.referencia, ajustes = { anio: ref.anio, ...diferencias(todo, ref) };
      const cats = p.categorias.filter(c => { const r = (ref.categorias || []).find(x => x.codigo === c.codigo); return !r || !iguales(+c.monto || 0, r.monto); });
      if (cats.length) ajustes.categorias = Object.fromEntries(cats.map(c => [c.codigo, +c.monto || 0]));
      mock.set('rrhh_parametros', ajustes); limpiarTablas(); this.t = { ...this.t, avisos: [], ignorados: [] }; toast('Parámetros guardados', 'ok');
    },
    restablecer() {
      if (!this.t || !confirm('¿Volver TODOS los valores a los oficiales del sistema? También los de la empresa, como la tasa de su póliza del INS.')) return;
      mock.set('rrhh_parametros', { anio: this.t.referencia.anio }); limpiarTablas();
      this.p = JSON.parse(JSON.stringify(this.t.referencia)); this.t = { ...this.t, avisos: [], ignorados: [] }; toast('Valores de referencia restablecidos', 'ok');
    },
    // 4.7: nombre de un valor, cómo se muestra, si es de la empresa (se conserva en un año nuevo) o legal, y poner otro valor en su lugar
    etiqueta(ruta) { return ETIQUETAS[ruta] || (ruta.startsWith('categorias.') ? 'Salario mínimo ' + ruta.slice(11) : ruta); },
    muestra(v) {
      if (typeof v === 'boolean') return v ? 'Sí' : 'No';
      if (Array.isArray(v)) return v.map(t => (Array.isArray(t) ? (t[0] === null ? 'resto' : 'hasta ' + fmt(t[0], 0)) + ': ' + fmt(t[1], 1) + ' %' : String(t))).join(' · ');
      if (typeof v === 'number') return fmt(v, 2);
      return OPCION[v] || (v === null || v === undefined || v === '' ? '—' : String(v));
    },
    esEmpresa(ruta) { return ((this.t && this.t.clasificacion && this.t.clasificacion.empresa) || []).includes(ruta.split('.')[0]); },
    nombreRebajo(c) { return REBAJOS[c] || c; },
    fijar(ruta, valor) {
      const partes = ruta.split('.');
      if (partes[0] === 'categorias') { const c = this.p.categorias.find(x => x.codigo === partes[1]); if (c) c.monto = +valor || 0; return; }
      const ult = partes.pop(); let o = this.p;
      for (const k of partes) { if (!o[k] || typeof o[k] !== 'object') o[k] = {}; o = o[k]; }
      o[ult] = JSON.parse(JSON.stringify(valor === undefined ? null : valor));
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Parámetros de recursos humanos" sub="Tasas, tramos y salarios mínimos que usa la planilla. Son valores de referencia: verifíquelos cada año con la CCSS, Hacienda y el decreto del MTSS." :crumbs="[{label:'Recursos humanos'},{label:'Parámetros'}]">
      <button class="btn ghost" @click="restablecer">Restablecer referencia</button><button class="btn" :disabled="!p || guardando" @click="guardar">Guardar</button>
    </PageHead>
    <template v-if="p">
      <div class="alert warn">{{p.vigencia}}</div>
      <div class="alert err" v-for="(a,i) in (t.avisos || [])" :key="'av'+i">{{a}}</div>
      <div class="card" v-if="(t.ignorados || []).length"><h2>Valores suyos de {{t.anio_guardado}} que ya no se aplican <small>la planilla usa los oficiales de {{t.referencia.anio}}</small></h2>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Valor</th><th class="num">El suyo ({{t.anio_guardado}})</th><th class="num">Oficial ({{t.referencia.anio}})</th><th></th></tr></thead>
          <tbody><tr v-for="x in t.ignorados" :key="x.clave"><td style="white-space:normal">{{etiqueta(x.clave)}}</td><td class="num" style="white-space:normal">{{muestra(x.valor)}}</td><td class="num" style="white-space:normal">{{muestra(x.oficial)}}</td><td><button class="btn sm ghost" @click="fijar(x.clave, x.valor)">Usar el mío</button></td></tr></tbody></table></div>
        <p class="small muted" style="margin:6px 0 0">Revíselos con los decretos del año. Si alguno sigue siendo el correcto para su empresa, pulse «Usar el mío» y luego Guardar.</p></div>
      <div class="card" v-if="personales.length"><h2>Valores personalizados <small>{{personales.length}} distinto(s) de los oficiales del sistema</small></h2>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Valor</th><th class="num">El suyo</th><th class="num">Oficial</th><th>En un año nuevo</th><th></th></tr></thead>
          <tbody><tr v-for="x in personales" :key="x.ruta"><td style="white-space:normal">{{etiqueta(x.ruta)}}</td><td class="num" style="white-space:normal">{{muestra(x.valor)}}</td><td class="num" style="white-space:normal">{{muestra(x.oficial)}}</td><td class="small" style="white-space:normal">{{esEmpresa(x.ruta) ? 'Se conserva: es de la empresa' : 'Se cambia por el oficial'}}</td><td><button class="btn sm ghost" @click="fijar(x.ruta, x.oficial)">Usar el oficial</button></td></tr></tbody></table></div>
        <p class="small muted" style="margin:6px 0 0">Solo se guarda lo que difiere del valor oficial. Los valores legales (tasas, tramos, mínimos, base mínima y factores) dejan de aplicarse cuando el sistema cargue los oficiales del año siguiente, con un aviso; los de la empresa se conservan. Los cambios se aplican al pulsar Guardar.</p></div>
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Cuota del trabajador <small>se descuenta del salario · total {{fmt(totObrero,2)}} %</small></h2>
          <div class="grid cols-3"><Field v-for="[k,n] in OBRERO" :key="k" :label="n"><input type="number" step="0.01" min="0" v-model.number="p.obrero[k]"></Field></div>
        </div>
        <div class="card"><h2>Cuota patronal <small>la paga la empresa · total {{fmt(totPatrono,2)}} % + INS</small></h2>
          <div class="grid cols-3"><Field v-for="[k,n] in PATRONO" :key="k" :label="n"><input type="number" step="0.01" min="0" v-model.number="p.patrono[k]"></Field>
            <Field label="Póliza de riesgos del trabajo del INS (%)" help="La tasa de su póliza según la actividad. Es de la empresa: se conserva al cambiar de año"><input type="number" step="0.01" min="0" v-model.number="p.ins_riesgos"></Field>
            <Field label="INS aparte de la póliza (%)" help="El 1 % del INS que completa el 26,83 % de las tablas, por confirmar con el contador. En 0, el 26,83 % se completa con su póliza; si el contador confirma que es un cobro aparte, ponga 1"><input type="number" step="0.01" min="0" v-model.number="p.ins_adicional"></Field></div>
          <div style="margin-top:8px"><Toggle v-model="p.paga_ina" label="La empresa paga el INA (apáguelo si por su actividad o tamaño no cotiza)"></Toggle></div>
        </div>
        <div class="card"><h2>Reserva mensual <small>sobre el salario bruto · total {{fmt(totProv,2)}} %</small></h2>
          <p class="small muted">Lo que conviene apartar cada mes para pagar aguinaldo, vacaciones y cesantía o liquidaciones sin descapitalizarse.</p>
          <div class="grid cols-3"><Field v-for="[k,n] in PROV" :key="k" :label="n"><input type="number" step="0.01" min="0" v-model.number="p.provisiones[k]"></Field></div>
        </div>
        <div class="card"><h2>Impuesto sobre la renta al salario <small>tramos mensuales (art. 33)</small></h2>
          <table class="tbl"><thead><tr><th>Hasta (₡ por mes)</th><th class="num">%</th><th></th></tr></thead>
            <tbody><tr v-for="(t,i) in p.renta.tramos" :key="i"><td><input class="inp mono" type="number" min="0" v-model.number="t[0]" :disabled="i===p.renta.tramos.length-1" :placeholder="i===p.renta.tramos.length-1 ? 'en adelante' : ''" style="width:100%"></td><td><input class="inp" type="number" min="0" max="100" step="0.5" v-model.number="t[1]" style="width:90px;text-align:right"></td><td><button class="btn icon" v-if="i<p.renta.tramos.length-1" @click="quitarTramo(i)">✕</button></td></tr></tbody></table>
          <div class="row" style="margin-top:8px;gap:8px"><button class="btn sm sec" @click="agregarTramo">+ Tramo</button></div>
          <div class="grid cols-2" style="margin-top:10px"><Field label="Crédito por hijo (₡ al mes)"><input type="number" min="0" v-model.number="p.renta.credito_hijo"></Field><Field label="Crédito por cónyuge (₡ al mes)"><input type="number" min="0" v-model.number="p.renta.credito_conyuge"></Field></div>
        </div>
        <div class="card"><h2>Jornadas y vacaciones</h2>
          <div class="grid cols-3">
            <Field label="Días de vacaciones por mes trabajado" help="12 al año según el Código de Trabajo"><input type="number" step="0.01" min="0" v-model.number="p.dias_vacaciones_por_mes"></Field>
            <Field label="Factor de hora extra" help="Tiempo y medio = 1,5"><input type="number" step="0.1" min="1" v-model.number="p.hora_extra_factor"></Field>
            <Field label="Días por mes para el salario diario"><input type="number" min="28" max="31" v-model.number="p.dias_mes"></Field>
            <Field label="Factor de feriado trabajado" help="Feriado de pago obligatorio trabajado: doble = 2 (art. 152)"><input type="number" step="0.1" min="1" v-model.number="p.feriado_factor"></Field>
          </div>
          <p class="small muted" style="margin:6px 0 0">Jornadas ordinarias: diurna {{p.jornadas.diurna.dia}} h/día y {{p.jornadas.diurna.semana}} h/semana · mixta {{p.jornadas.mixta.dia}}/{{p.jornadas.mixta.semana}} · nocturna {{p.jornadas.nocturna.dia}}/{{p.jornadas.nocturna.semana}}.</p>
        </div>
        <div class="card" v-if="p.incapacidad"><h2>Incapacidades <small>lo que paga el patrono; el resto lo paga la CCSS o el INS y no es salario</small></h2>
          <div class="grid cols-3">
            <Field label="Enfermedad (CCSS): días que paga el patrono" help="Los primeros 3 días (art. 79 del Código de Trabajo); la CCSS paga desde el 4.º"><input type="number" min="0" max="31" v-model.number="p.incapacidad.enfermedad_dias_patrono"></Field>
            <Field label="Enfermedad: % que paga el patrono" help="50 % por ley; 100 % si la empresa completa el salario"><input type="number" min="0" max="100" step="1" v-model.number="p.incapacidad.enfermedad_pct"></Field>
            <Field label="Riesgo del trabajo (INS): días que paga el patrono" help="El día del accidente; el INS paga desde el siguiente"><input type="number" min="0" max="31" v-model.number="p.incapacidad.riesgo_dias_patrono"></Field>
            <Field label="Riesgo del trabajo: % que paga el patrono"><input type="number" min="0" max="100" step="1" v-model.number="p.incapacidad.riesgo_pct"></Field>
            <Field label="Maternidad: % que paga el patrono" help="50 % patrono + 50 % CCSS; el salario completo sigue cotizando (art. 95)"><input type="number" min="0" max="100" step="1" v-model.number="p.incapacidad.maternidad_pct"></Field>
          </div>
          <p class="small muted" style="margin:6px 0 0">Lo que paga el patrono por una incapacidad (enfermedad o riesgo del trabajo) es un subsidio: no cotiza a la CCSS ni paga renta, y no cuenta para el aguinaldo. En la licencia de maternidad el salario completo cotiza y cuenta para todos los derechos; la parte que paga la CCSS se descuenta del neto. Se registra en Recursos humanos › Ausencias e incapacidades y la planilla lo aplica sola.</p>
        </div>
        <div class="card"><h2>Salarios mínimos por categoría <small>decreto del MTSS</small></h2>
          <table class="tbl"><thead><tr><th>Código</th><th>Categoría</th><th>Base</th><th class="num">Monto</th></tr></thead>
            <tbody><tr v-for="c in p.categorias" :key="c.codigo"><td class="mono">{{c.codigo}}</td><td style="white-space:normal">{{c.nombre}}</td><td>{{c.base==='dia' ? 'por día' : 'por mes'}}</td><td><input class="inp mono" type="number" min="0" step="0.01" v-model.number="c.monto" style="width:140px;text-align:right"></td></tr></tbody></table>
          <p class="small muted" style="margin:6px 0 0">Las categorías por día se comparan con el salario mensual multiplicándolas por {{p.dias_mes}}.</p>
        </div>
        <div class="card" v-if="p.base_minima"><h2>Base mínima contributiva de la CCSS <small>por confirmar con el contador</small></h2>
          <div class="grid cols-2">
            <Field label="Base mínima del seguro de salud SEM (₡ por mes)"><input type="number" min="0" step="0.01" v-model.number="p.base_minima.sem"></Field>
            <Field label="Base mínima de pensiones IVM (₡ por mes)"><input type="number" min="0" step="0.01" v-model.number="p.base_minima.ivm"></Field>
          </div>
          <div style="margin:8px 0"><Toggle v-model="p.aplicar_base_minima" label="Calcular las cuotas SEM e IVM sobre la base mínima cuando el salario del período es menor"></Toggle></div>
          <Field label="Quién paga la diferencia de la cuota del trabajador" v-if="p.aplicar_base_minima"><select v-model="p.base_minima_diferencia"><option value="patrono">La empresa (al trabajador no se le rebaja más)</option><option value="trabajador">El trabajador (línea aparte en su colilla)</option></select></Field>
          <p class="small muted" style="margin:6px 0 0">Apagado, la planilla solo avisa (como hasta ahora). Encendido, las cuotas de la empresa van sobre la base y la diferencia de la cuota del trabajador la paga quien usted elija. No se aplica a quien ingresó en el período, cuando hay incapacidad, licencia, permiso sin goce o días sin salario, ni en las planillas de período manual: en esos casos sale un aviso.</p>
        </div>
        <div class="card" v-if="p.embargo"><h2>Embargos y pensión alimentaria <small>por validar con un abogado</small></h2>
          <Field label="Cuando un embargo pasa de lo que permite el artículo 172"><select v-model="p.embargo_modo"><option value="avisar">Rebajar lo que diga el juzgado y avisar</option><option value="limitar">Rebajar solo hasta el máximo del artículo 172 y avisar el resto</option></select></Field>
          <div class="grid cols-2" style="margin-top:8px">
            <Field label="Embargable del primer tramo (%)" help="1/8 = 12,5 % de lo que pase del menor salario mínimo"><input type="number" min="0" max="100" step="0.01" v-model.number="p.embargo.tramo1_pct"></Field>
            <Field label="Embargable del segundo tramo (%)" help="1/4 = 25 % de lo que pase del múltiplo del mínimo"><input type="number" min="0" max="100" step="0.01" v-model.number="p.embargo.tramo2_pct"></Field>
            <Field label="Múltiplo del menor salario mínimo" help="3 veces, según el artículo 172"><input type="number" min="1" step="0.5" v-model.number="p.embargo.multiplo_minimo"></Field>
            <Field label="Avisar si la pensión alimentaria pasa del (%)" help="Del salario después de la CCSS y la renta"><input type="number" min="0" max="100" step="1" v-model.number="p.pension_aviso_pct"></Field>
          </div>
          <p class="small muted" style="margin:6px 0 0">Si el salario no alcanza para todos los rebajos, después de la CCSS y la renta se aplican en este orden: {{(t.orden_rebajos || []).map(c => nombreRebajo(c)).join(' → ')}}. Lo que no cupo queda como aviso en la planilla y los préstamos y adelantos conservan su saldo.</p>
        </div>
        <div class="card"><h2>Aprobación de la planilla <small>opcional · es de la empresa: se conserva al cambiar de año</small></h2>
          <div><Toggle v-model="p.exigir_aprobacion_planilla" label="Exigir que la planilla esté aprobada antes de marcarla pagada"></Toggle></div>
          <div style="margin-top:8px" :style="p.exigir_aprobacion_planilla ? '' : 'opacity:.5;pointer-events:none'" :title="p.exigir_aprobacion_planilla ? '' : 'Encienda primero la opción de arriba'"><Toggle v-model="p.aprobacion_otro_usuario" :disabled="!p.exigir_aprobacion_planilla" label="Quien aprueba debe ser un usuario distinto del que la generó o corrigió"></Toggle></div>
          <p class="small muted" style="margin:6px 0 0">Apagado, la planilla se paga como hasta ahora. Encendido, en Planilla aparece el botón «Aprobar» y «Marcar pagada» queda desactivado hasta que alguien con acceso a Recursos humanos la apruebe; corregir una planilla aprobada le quita la aprobación. La segunda opción solo cuenta con la primera encendida; si dos personas comparten un mismo usuario, no las distingue. Cada aprobación queda en el historial de operaciones. Los cambios se aplican al pulsar Guardar.</p>
        </div>
      </div>
    </template>
    <div class="card" v-else><p class="muted">Cargando…</p></div>
  </div>`,
};
