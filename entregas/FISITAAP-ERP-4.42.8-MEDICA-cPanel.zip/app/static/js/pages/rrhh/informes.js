// Recursos humanos › Informes: resumen mensual para la planilla de la CCSS (salarios reportados, cuotas obrera y patronal, INS),
// retenciones de renta del mes, costo de la planilla por empleado y por rubro. Todo sale de las planillas PAGADAS cuyo período
// cierra dentro del mes elegido (las complementarias pagadas también) y de la parte salarial (salario pendiente y vacaciones) de las
// liquidaciones pagadas con salida en el mes. 4.7: antes sumaba también las planillas sin pagar y dejaba fuera las liquidaciones;
// lo que no se suma o hay que revisar (sin pagar, fechas que se cruzan, apellidos supuestos) se avisa. Descargable en PDF, Word y CSV. 4.21: el Excel, el CSV y los archivos de la CCSS y del INS (salarios por empleado) quedan en el historial de descargas de Recursos humanos.
import { money, fmt, fecha, hoy, toast } from '../../api.js';
import { empleados, nombreCompleto, planillas, liquidaciones, tablas, diasEntre, esPagada, esComplementaria, crucesPagados, partesLiquidacion } from './_datos.js';
import { descargarReporte, descargarCSV, descargarTabla, registrarExportable } from '../reportes/_montos.js';
// 4.22: pago de las cargas del mes (CCSS, INS y renta retenida). El monto lo calcula el servidor con las planillas y las liquidaciones
// pagadas guardadas (/api/rrhh/cargas) y el pago lo guarda él mismo, con su salida en Bancos (/api/rrhh/pago-cargas): esta pantalla
// muestra, pide y vuelve a leer; nunca escribe el registro rrhh_pagos_cargas
import { api, mock } from '../../api.js';
import { cuentasParaMovimientos, cuentaPrincipal } from '../bancos/cuentas.js';
// 4.21: los indicadores (costo por departamento, ausentismo, rotación, cumpleaños y aniversarios) viven en esta misma pantalla, sin ruta
// propia: el botón «Indicadores» alterna la vista y #/rrhh/informes?ver=indicadores la abre de entrada
import Indicadores from './indicadores.js';

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'];
const r2 = n => Math.round((+n || 0) * 100) / 100;
// 4.7 (C3): también las claves nuevas del cálculo (el INS aparte de la póliza y la diferencia de la cuota obrera por la base mínima:
// la que paga la empresa va en «patrono» y la del trabajador en «obrero»); una clave sin nombre se muestra legible, no cruda (etiqueta)
const PAT = { sem: 'SEM', ivm: 'IVM', banco_popular: 'Banco Popular', fodesaf: 'FODESAF', imas: 'IMAS', ina: 'INA', fcl: 'FCL', rop_opc: 'ROP–OPC', rop_bp: 'ROP–BP', rop: 'ROP', ins_riesgos: 'INS', ins_adicional: 'INS aparte de la póliza', base_minima_obrera: 'Cuota obrera por base mínima (la paga la empresa)' };
const OBR = { sem: 'SEM', ivm: 'IVM', banco_popular: 'Banco Popular', base_minima: 'Diferencia por base mínima' };
const etiqueta = (nombres, k) => nombres[k] || String(k).replace(/_/g, ' ').replace(/^./, c => c.toUpperCase());
// 4.7 (C1): renta del MES con los tramos y los créditos de Parámetros, la misma regla del servidor (rrhh.renta_mensual). Sirve para
// revisar la renta del mes de quien tiene una liquidación pagada (rentaFaltante)
export function rentaMensual(bruto, renta, hijos, conyuge) {
  let restante = +bruto || 0, anterior = 0, imp = 0;
  for (const [limite, pct] of (renta && renta.tramos) || []) {
    const tope = limite === null || limite === undefined || limite === '' ? Infinity : +limite;
    imp += Math.max(0, Math.min(restante, tope) - anterior) * (+pct || 0) / 100;
    anterior = tope;
    if (restante <= tope) break;
  }
  imp -= (+(renta && renta.credito_hijo) || 0) * Math.max(0, parseInt(hijos, 10) || 0);
  if (conyuge) imp -= +(renta && renta.credito_conyuge) || 0;
  return r2(Math.max(0, imp));
}
// 4.7: «Tipo de salario» del archivo según la frecuencia de pago que guarda la ficha (antes buscaba 'catorcenal', que el sistema no
// usa, y a quien cobra cada 14 días lo reportaba «Mensual»). Sin dato: quincenal, como la planilla.
export const FRECUENCIA_INFORME = { semanal: 'Semanal', bisemanal: 'Bisemanal', catorcenal: 'Bisemanal', quincenal: 'Quincenal', mensual: 'Mensual', manual: 'Por horas' };
// 4.7: jornada del archivo con el dato real de la ficha (antes el medio tiempo salía «Diurna»)
export const JORNADA_INFORME = { diurna: 'Diurna', mixta: 'Mixta', nocturna: 'Nocturna', medio_tiempo: 'Medio tiempo' };
const NOTA_LIQ = 'El salario pendiente y las vacaciones pagadas en una liquidación se suman al salario reportado a la CCSS y al INS del mes de la salida, y la renta que se les retuvo en la liquidación (calculada con lo ya pagado en el mes) se suma a la renta retenida del mes. El preaviso, la cesantía y el aguinaldo proporcional no son salario: no cotizan ni se reportan.';
// 4.7: partículas que van pegadas al apellido siguiente («De la Cruz», «Del Valle», «Van der Laat»)
const PARTICULAS = new Set(['de', 'del', 'la', 'las', 'los', 'da', 'das', 'do', 'dos', 'di', 'van', 'von', 'der', 'den', 'san']);
function gruposNombre(s) {
  const out = []; let pend = [];
  for (const w of String(s || '').trim().split(/\s+/).filter(Boolean)) { pend.push(w); if (!PARTICULAS.has(w.toLowerCase())) { out.push(pend.join(' ')); pend = []; } }
  if (pend.length) { if (out.length) out[out.length - 1] += ' ' + pend.join(' '); else out.push(pend.join(' ')); }
  return out;
}
// 4.7: nombre, primer y segundo apellido para los archivos de la CCSS y el INS. Primero «Primer apellido» y «Segundo apellido» de la
// ficha; si no están, se separa «Apellidos» (el primer apellido con sus partículas: «De la Cruz Mora» → «De la Cruz» y «Mora»); y si
// la ficha trae todo en «Nombre» (Nombre [Nombre2] Apellido1 Apellido2): con 3 o más palabras las 2 últimas son los apellidos y con
// 2, la última. `seguro` = false cuando la separación es una suposición o los campos no coinciden (se avisa en la pantalla).
export function partirNombre(e) {
  const x = e || {}, nombre = String(x.nombre || '').trim(), a1 = String(x.apellido1 || '').trim(), a2 = String(x.apellido2 || '').trim();
  const junto = s => String(s || '').trim().replace(/\s+/g, ' ').toLowerCase();
  // «Primer apellido» y «Segundo apellido» salen tal cual si coinciden con «Apellidos» (o no hay «Apellidos»); si «Apellidos» se
  // cambió después a mano (o la ficha se duplicó) y ya no coinciden, manda «Apellidos», que es lo que muestran las pantallas, y se avisa
  const conAp = !!(a1 || a2);
  if (conAp && (!String(x.apellidos || '').trim() || junto(x.apellidos) === junto(a1 + ' ' + a2))) return { nombre, primero: a1, segundo: a2, seguro: true };
  const ap = gruposNombre(x.apellidos);
  if (ap.length) return { nombre, primero: ap[0], segundo: ap.slice(1).join(' '), seguro: ap.length <= 2 && !conAp };
  const n = gruposNombre(nombre);
  if (n.length >= 3) return { nombre: n.slice(0, -2).join(' '), primero: n[n.length - 2], segundo: n[n.length - 1], seguro: false };
  if (n.length === 2) return { nombre: n[0], primero: n[1], segundo: '', seguro: false };
  return { nombre, primero: '', segundo: '', seguro: false };
}

export default {
  props: ['params'],
  components: { Indicadores },
  data() { return { mes: hoy().slice(0, 7), t: null, emps: empleados(), cargas: null, pagosCargas: mock.get('rrhh_pagos_cargas', []) || [], pagoCargas: null, cuentasLista: null, registrandoSalida: false, verIndicadores: !!(this.params && this.params.ver === 'indicadores') }; },
  watch: { 'params.ver'(v) { this.verIndicadores = v === 'indicadores'; } },
  computed: {
    nombreMes() { const [y, m] = this.mes.split('-'); return (MESES[+m - 1] || m) + ' ' + y; },
    diasMes() { const [y, m] = this.mes.split('-'); return new Date(+y, +m, 0).getDate(); },
    // 4.7: solo cuentan las planillas pagadas (las complementarias pagadas también); las del mes sin pagar se avisan, no se suman
    plDelMes() { return planillas().filter(p => String(p.hasta || '').startsWith(this.mes)).sort((a, b) => String(a.desde).localeCompare(String(b.desde))); },
    plMes() { return this.plDelMes.filter(esPagada); },
    plSinPagar() { return this.plDelMes.filter(p => !esPagada(p)); },
    // 4.7: liquidaciones con salida en el mes; cuentan las pagadas (su salario pendiente y sus vacaciones son salario del mes)
    liqDelMes() { return liquidaciones().filter(l => String(l.fecha_salida || '').startsWith(this.mes)).sort((a, b) => String(a.fecha_salida).localeCompare(String(b.fecha_salida))); },
    liqMes() { return this.liqDelMes.filter(esPagada); },
    liqSinPagar() { return this.liqDelMes.filter(l => !esPagada(l)); },
    porId() { return Object.fromEntries(this.emps.map(e => [e.id, e])); },
    // la CCSS obrera y patronal y la renta son las que guardó la liquidación (4.7, C1: la renta de lo salarial, con lo ya pagado en el
    // mes; una liquidación de antes no la trae y la renta del mes se revisa en rentaFaltante); el INS se estima con la tasa de la
    // planilla (la del empleado o la de la empresa) porque la liquidación no lo calcula
    liqFilas() {
      const ef = (this.t && this.t.efectivos) || {};
      return this.liqMes.map(l => {
        const e = this.porId[l.empleado_id] || {}, p = partesLiquidacion(l);
        const insPct = e.ins_riesgos !== null && e.ins_riesgos !== undefined && e.ins_riesgos !== '' ? +e.ins_riesgos || 0 : +ef.ins_riesgos || 0;
        return { numero: l.numero || '', empleado_id: l.empleado_id, nombre: l.nombre || nombreCompleto(e), salida: l.fecha_salida, salarial: p.salarial, no_salarial: p.no_salarial, dias: p.dias,
          obrero: r2(l.ccss_obrera), patronal_ccss: r2(l.ccss_patronal), ins: r2(p.salarial * insPct / 100), renta: r2(l.renta), total: r2(l.total) };
      });
    },
    hayDatos() { return !!(this.plMes.length || this.liqMes.length); },
    // 4.7: el mismo empleado en dos planillas pagadas (no complementarias) con fechas que se cruzan: se suman las dos y se avisa
    cruces() { return crucesPagados(planillas(), this.plMes); },
    porEmpleado() {
      const out = {}, porId = this.porId;
      const fila = (k, empleado_id, nombre) => {
        if (!out[k]) { const e = porId[empleado_id] || {}; out[k] = { empleado_id, nombre: nombre || nombreCompleto(e), numero_id: e.numero_id || '', puesto: e.puesto || '', dias: 0, horas: 0, bruto: 0, obrero: 0, renta: 0, otras: 0, neto: 0, patronal_ccss: 0, ins: 0, provisiones: 0, costo: 0, no_salariales: 0, planillas: 0, ordinarias: 0, liquidaciones: 0 }; }
        return out[k];
      };
      // 4.7: primero las ordinarias; una complementaria corrige montos de un período ya contado y no vuelve a sumar días. (C2) Se decide
      // por fila: la complementaria suma los días de su período solo a quien no está en ninguna ordinaria pagada del mes con fechas que
      // se cruzan con las suyas (p. ej. alguien que se quedó fuera de la planilla de esa quincena y se le pagó en la complementaria)
      const mismo = (x, f) => (f.empleado_id !== null && f.empleado_id !== undefined ? x.empleado_id === f.empleado_id : x.nombre === f.nombre);
      const cubierta = (p, f) => this.plMes.some(q => !esComplementaria(q) && q.desde <= p.hasta && q.hasta >= p.desde && (q.filas || []).some(x => mismo(x, f)));
      for (const p of [...this.plMes.filter(pl => !esComplementaria(pl)), ...this.plMes.filter(esComplementaria)]) {
        const comp = esComplementaria(p), diasP = Math.min(this.diasMes, diasEntre(p.desde, p.hasta) || 0);
        for (const f of p.filas || []) {
          const o = fila(f.empleado_id || f.nombre, f.empleado_id, f.nombre), diasPl = comp && cubierta(p, f) ? 0 : diasP;
          if (!comp) o.ordinarias++;
          o.dias += Math.max(0, diasPl - (+f.dias_ausencia || 0)); o.horas += +f.horas || 0; o.bruto += +f.bruto || 0; o.obrero += +f.total_obrero || 0; o.renta += +f.renta || 0; o.otras += +f.otras_deducciones || 0; o.neto += +f.neto || 0;
          const ins = (f.patrono && +f.patrono.ins_riesgos) || 0; o.ins += ins; o.patronal_ccss += (+f.total_patronal || 0) - ins; o.provisiones += +f.total_provisiones || 0; o.costo += +f.costo_total || 0; o.no_salariales += +f.no_salariales || 0; o.planillas++;
        }
      }
      // 4.7 (riesgo 1): la parte salarial de las liquidaciones pagadas (salario pendiente y vacaciones) se reporta como salario del mes
      for (const x of this.liqFilas) {
        if (!(x.salarial > 0)) continue;
        const o = fila(x.empleado_id || x.nombre, x.empleado_id, x.nombre);
        o.dias += x.dias; o.bruto += x.salarial; o.obrero += x.obrero; o.renta += x.renta; o.neto += x.salarial - x.obrero - x.renta;
        o.patronal_ccss += x.patronal_ccss; o.ins += x.ins; o.costo += x.salarial + x.patronal_ccss + x.ins; o.liquidaciones++;
      }
      return Object.values(out).map(o => ({ ...o, dias: Math.min(this.diasMes, o.dias), bruto: r2(o.bruto), obrero: r2(o.obrero), renta: r2(o.renta), otras: r2(o.otras), neto: r2(o.neto), patronal_ccss: r2(o.patronal_ccss), ins: r2(o.ins), provisiones: r2(o.provisiones), costo: r2(o.costo), no_salariales: r2(o.no_salariales) })).sort((a, b) => a.nombre.localeCompare(b.nombre));
    },
    tot() { const t = { dias: 0, bruto: 0, obrero: 0, renta: 0, otras: 0, neto: 0, patronal_ccss: 0, ins: 0, provisiones: 0, costo: 0, no_salariales: 0 }; for (const o of this.porEmpleado) for (const k in t) t[k] = r2(t[k] + o[k]); return t; },
    rubrosPatronales() {
      const acc = {}; for (const p of this.plMes) for (const f of p.filas || []) for (const [k, v] of Object.entries(f.patrono || {})) acc[k] = r2((acc[k] || 0) + (+v || 0));
      const out = Object.entries(acc).map(([k, v]) => ({ rubro: etiqueta(PAT, k), monto: v }));
      // 4.7: la liquidación guarda la CCSS en un solo monto (sin desglose por rubro); el INS es la estimación de liqFilas
      const lq = this.liqFilas.filter(x => x.salarial > 0), ccss = r2(lq.reduce((s, x) => s + x.patronal_ccss, 0)), ins = r2(lq.reduce((s, x) => s + x.ins, 0));
      if (ccss) out.push({ rubro: 'Liquidaciones (CCSS)', monto: ccss });
      if (ins) out.push({ rubro: 'Liquidaciones (INS)', monto: ins });
      return out;
    },
    rubrosObreros() {
      const acc = {}; for (const p of this.plMes) for (const f of p.filas || []) for (const [k, v] of Object.entries(f.obrero || {})) acc[k] = r2((acc[k] || 0) + (+v || 0));
      const out = Object.entries(acc).map(([k, v]) => ({ rubro: etiqueta(OBR, k), monto: v }));
      const ccss = r2(this.liqFilas.filter(x => x.salarial > 0).reduce((s, x) => s + x.obrero, 0));
      if (ccss) out.push({ rubro: 'Liquidaciones (CCSS)', monto: ccss });
      return out;
    },
    conRenta() { return this.porEmpleado.filter(o => o.renta > 0); },
    // 4.7 (C1): quien tiene una liquidación pagada en el mes: la renta del mes según los tramos (sobre sus planillas y lo salarial de la
    // liquidación) contra lo retenido. Una liquidación calculada antes de que retuviera la renta, o sin las planillas del mes ya pagadas,
    // deja una diferencia: se avisa (lo pagado no se cambia)
    rentaFaltante() {
      const ren = this.t && this.t.efectivos && this.t.efectivos.renta;
      if (!ren) return [];
      const out = [];
      for (const o of this.porEmpleado) {
        const e = this.porId[o.empleado_id] || {};
        if (!o.liquidaciones || e.aplica_renta === false) continue;
        const esperada = rentaMensual(o.bruto, ren, e.hijos, e.conyuge), falta = r2(esperada - o.renta);
        if (falta > 0.5) out.push({ nombre: o.nombre, bruto: o.bruto, retenida: o.renta, esperada, falta });
      }
      return out;
    },
    // 4.7: avisos visibles en la pantalla y en el PDF/Word: lo que no se sumó y lo que hay que revisar antes de presentar
    avisos() {
      const out = [], n = this.plSinPagar.length, nl = this.liqSinPagar.length, cr = this.cruces, ids = new Set(this.plMes.map(p => p.id));
      if (n) out.push(n + (n === 1 ? ' planilla del mes no se incluye porque no está pagada' : ' planillas del mes no se incluyen porque no están pagadas') + ': ' + this.plSinPagar.map(p => p.numero).join(', ') + '. Cuando las pague, márquelas pagadas en Planilla y el informe se actualiza.');
      if (nl) out.push(nl + (nl === 1 ? ' liquidación con salida en el mes no se incluye porque no está pagada' : ' liquidaciones con salida en el mes no se incluyen porque no están pagadas') + ': ' + this.liqSinPagar.map(l => l.numero + (l.nombre ? ' (' + l.nombre + ')' : '')).join(', ') + '.');
      // (C4) una de las dos puede cerrar en otro mes: esa no se suma aquí, se reporta en el informe del mes en que cierra
      for (const c of cr.slice(0, 8)) {
        const fuera = !ids.has(c.a.id) ? c.a : (!ids.has(c.b.id) ? c.b : null), dentro = fuera === c.a ? c.b : c.a;
        out.push((c.nombre || 'Un empleado') + ' aparece en dos planillas pagadas con fechas que se cruzan: ' + c.a.numero + ' (' + fecha(c.a.desde) + ' – ' + fecha(c.a.hasta) + ') y ' + c.b.numero + ' (' + fecha(c.b.desde) + ' – ' + fecha(c.b.hasta) + '). '
          + (fuera ? 'Solo ' + dentro.numero + ' se suma en este informe; ' + fuera.numero + ' se reporta en el informe de ' + this.nombreDe(fuera.hasta) + ', el mes en que cierra: revise si se le pagó dos veces entre los dos meses.' : 'Las dos se suman en este informe: revise si se le pagó dos veces antes de presentarlo.'));
      }
      for (const x of this.rentaFaltante.slice(0, 6)) out.push('Renta de ' + x.nombre + ': su salario del mes con la liquidación (' + money(x.bruto) + ') da ' + money(x.esperada) + ' de renta según los tramos y se le retuvieron ' + money(x.retenida) + '; faltan ' + money(x.falta) + '. Puede ser una liquidación calculada sin las planillas del mes ya pagadas o antes de que la liquidación retuviera la renta: revísela con su contador antes de declarar.');
      if (this.rentaFaltante.length > 6) out.push('Hay ' + (this.rentaFaltante.length - 6) + ' trabajador(es) más con renta por revisar en sus liquidaciones.');
      if (cr.length > 8) out.push('Hay ' + (cr.length - 8) + ' cruce(s) más de planillas pagadas con el mismo empleado y fechas que se cruzan.');
      const dudosos = this.porEmpleado.filter(o => !partirNombre(this.porId[o.empleado_id] || { nombre: o.nombre }).seguro).map(o => o.nombre);
      if (dudosos.length) out.push('Revise los apellidos de ' + dudosos.slice(0, 6).join(', ') + (dudosos.length > 6 ? ' y ' + (dudosos.length - 6) + ' más' : '') + ': en los archivos de la CCSS y del INS se separaron con una suposición o no coinciden con «Apellidos». Para que salgan exactos, complete «Primer apellido» y «Segundo apellido» en la ficha del empleado.');
      return out;
    },
    // 4.22: las tres cargas del mes como las muestra la tarjeta: el monto que calculó el servidor, su pago si ya se registró, si ese
    // pago tiene su salida en Bancos y si el monto del mes cambió después de pagarlo (una planilla complementaria pagada más tarde).
    // Las de un mes anterior a esta función (c.anterior, lo dice el servidor) se pagaban a mano y el sistema no sabe si ya están
    // pagadas: no salen como «Pendiente» (insignia amarilla) sino como «Sin registrar aquí», con insignia neutra
    cargasFilas() {
      const c = this.cargas;
      if (!c || c.mes !== this.mes) return [];
      return (c.cargas || []).map(x => {
        const p = x.pago || null, monto = +x.monto || 0, det = x.detalle || null, dif = p ? r2(monto - (+p.monto || 0)) : 0;
        return { tipo: x.tipo, corto: x.corto, nombre: x.nombre, monto, pago: p, en_bancos: x.en_bancos,
          desglose: det ? 'Cuota obrera retenida ' + money(det.ccss_obrero) + ' + cargas patronales ' + money(det.ccss_patronal) : '',
          estado: p ? 'Pagado' : (monto > 0 ? (c.anterior ? 'Sin registrar aquí' : 'Pendiente') : 'Sin monto por pagar'),
          insignia: p ? 'ok' : (monto > 0 && !c.anterior ? 'warn' : ''),
          detallePago: p ? 'El ' + fecha(p.fecha_pago) + ' desde ' + (p.cuenta || '—') + (p.comprobante ? ' · comprobante ' + p.comprobante : '') + ' · ' + money(p.monto) : '',
          diferencia: p && Math.abs(dif) >= 0.01 ? 'Se pagaron ' + money(p.monto) + ' y el monto del mes ahora es ' + money(monto) + ' (cambió después del pago): la diferencia de ' + money(Math.abs(dif)) + ' se registra con un asiento manual.' : '',
          sePuede: !p && monto > 0 && !c.bloqueo,
          motivo: p ? '' : (c.bloqueo ? 'Hay planillas o liquidaciones del mes sin pagar' : (monto > 0 ? '' : 'Las planillas y las liquidaciones pagadas del mes no dejaron monto por pagar')) };
      });
    },
    cuentasCargas() { return (this.cuentasLista || []).filter(b => (b.moneda || 'CRC') === 'CRC').map(b => b.nombre); },
    pagosFilas() {
      const orden = ['ccss', 'ins', 'renta'], nombres = { ccss: 'CCSS', ins: 'INS', renta: 'Renta retenida' };
      return (this.pagosCargas || []).filter(p => p && p.mes).sort((a, b) => String(b.mes).localeCompare(String(a.mes)) || orden.indexOf(a.tipo) - orden.indexOf(b.tipo))
        .map(p => ({ id: p.id, mes: p.mes, mes_nombre: this.nombreDe(p.mes + '-01'), carga: nombres[p.tipo] || p.tipo, monto: +p.monto || 0, pagado: p.fecha_pago, cuenta: p.cuenta || '', comprobante: p.comprobante || '', registro: p.registrado_por || '' }));
    },
  },
  methods: {
    money, fmt, fecha,
    nombreDe(f) { const s = String(f || ''); return (MESES[+s.slice(5, 7) - 1] || s.slice(5, 7)) + ' ' + s.slice(0, 4); },
    cambiarMes(n) { const [y, m] = this.mes.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); this.mes = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); },
    secciones() {
      const M = v => money(v || 0), t = this.tot;
      const ccss = { titulo: 'Planilla mensual para la CCSS (salarios reportados y cuotas)', columnas: [{ key: 'numero_id', label: 'Identificación' }, { key: 'nombre', label: 'Trabajador' }, { key: 'dias', label: 'Días', num: true }, { key: 'bruto', label: 'Salario reportado', num: true }, { key: 'obrero', label: 'Cuota obrera', num: true }, { key: 'patronal_ccss', label: 'Cuota patronal (CCSS + LPT)', num: true }, { key: 'ins', label: 'INS', num: true }],
        filas: this.porEmpleado.map(o => ({ numero_id: o.numero_id, nombre: o.nombre, dias: String(o.dias), bruto: M(o.bruto), obrero: M(o.obrero), patronal_ccss: M(o.patronal_ccss), ins: M(o.ins) })),
        totales: [{ t: 'Salarios reportados', v: M(t.bruto) }, { t: 'Cuota obrera retenida', v: M(t.obrero) }, { t: 'Cuota patronal', v: M(t.patronal_ccss) }, { t: 'Total a pagar a la CCSS (obrera + patronal)', v: M(t.obrero + t.patronal_ccss) }, { t: 'INS riesgos del trabajo', v: M(t.ins) }],
        nota: 'Las cuotas patronales incluyen SEM, IVM, Banco Popular, FODESAF, IMAS, INA, FCL y ROP (Ley de Protección al Trabajador); verifique contra la planilla preliminar del SICERE antes de pagar.' };
      const renta = { titulo: 'Impuesto sobre la renta retenido a los salarios: TRIBU-CR, formulario 137 (patrono persona física) o 138 (persona jurídica) con su informativa 207 o 208, dentro de los primeros 15 días naturales del mes siguiente', columnas: [{ key: 'numero_id', label: 'Identificación' }, { key: 'nombre', label: 'Trabajador' }, { key: 'concepto', label: 'Concepto' }, { key: 'bruto', label: 'Monto bruto pagado', num: true }, { key: 'renta', label: 'Monto retenido', num: true }],
        filas: this.conRenta.map(o => ({ numero_id: o.numero_id, nombre: o.nombre, concepto: o.liquidaciones ? 'Salarios y liquidación' : 'Salarios', bruto: M(o.bruto), renta: M(o.renta) })), totales: [{ t: 'Total retenido', v: M(t.renta) }],
        nota: this.rentaFaltante.length ? 'Falta retener renta a ' + this.rentaFaltante.map(x => x.nombre).join(', ') + ' según los tramos del mes con su liquidación (' + M(this.rentaFaltante.reduce((s, x) => s + x.falta, 0)) + ' en total): revíselo antes de declarar.' : (this.conRenta.length ? null : 'Ningún salario superó el tramo exento este mes.') };
      const costo = { titulo: 'Costo de la planilla por empleado', columnas: [{ key: 'nombre', label: 'Empleado' }, { key: 'puesto', label: 'Puesto' }, { key: 'bruto', label: 'Bruto', num: true }, { key: 'neto', label: 'Neto pagado', num: true }, { key: 'no_salariales', label: 'No salarial', num: true }, { key: 'patronal', label: 'Cargas + INS', num: true }, { key: 'provisiones', label: 'Reservas', num: true }, { key: 'costo', label: 'Costo total', num: true }],
        filas: this.porEmpleado.map(o => ({ nombre: o.nombre, puesto: o.puesto, bruto: M(o.bruto), neto: M(o.neto), no_salariales: M(o.no_salariales), patronal: M(o.patronal_ccss + o.ins), provisiones: M(o.provisiones), costo: M(o.costo) })),
        totales: [{ t: 'Salarios brutos', v: M(t.bruto) }, { t: 'Neto pagado', v: M(t.neto) }, { t: 'Cargas patronales e INS', v: M(t.patronal_ccss + t.ins) }, { t: 'Reservas', v: M(t.provisiones) }, { t: 'Costo total', v: M(t.costo) }] };
      const rubros = { titulo: 'Cuotas por rubro', columnas: [{ key: 'rubro', label: 'Rubro' }, { key: 'monto', label: 'Monto', num: true }],
        filas: [...this.rubrosObreros.map(r => ({ rubro: 'Obrera · ' + r.rubro, monto: M(r.monto) })), ...this.rubrosPatronales.map(r => ({ rubro: 'Patronal · ' + r.rubro, monto: M(r.monto) }))] };
      if (this.liqFilas.some(x => x.salarial > 0)) costo.nota = 'De las liquidaciones solo se suma la parte salarial (salario pendiente y vacaciones) con sus cargas; el total pagado en cada una está en la sección de liquidaciones.';
      const secs = [ccss, renta, costo, rubros];
      // 4.7: las liquidaciones pagadas del mes, con lo que se reporta y lo que no
      if (this.liqFilas.length) secs.splice(1, 0, { titulo: 'Liquidaciones pagadas con salida en el mes', columnas: [{ key: 'numero', label: 'Liquidación' }, { key: 'nombre', label: 'Trabajador' }, { key: 'salarial', label: 'Salario pendiente y vacaciones (se reporta)', num: true }, { key: 'no_salarial', label: 'Preaviso, cesantía y aguinaldo (no se reporta)', num: true }, { key: 'obrero', label: 'CCSS obrera', num: true }, { key: 'patronal_ccss', label: 'CCSS patronal', num: true }, { key: 'renta', label: 'Renta retenida', num: true }, { key: 'total', label: 'Total pagado', num: true }],
        filas: this.liqFilas.map(x => ({ numero: x.numero, nombre: x.nombre, salarial: M(x.salarial), no_salarial: M(x.no_salarial), obrero: M(x.obrero), patronal_ccss: M(x.patronal_ccss), renta: M(x.renta), total: M(x.total) })),
        totales: [{ t: 'Se reporta como salario', v: M(this.liqFilas.reduce((s, x) => s + x.salarial, 0)) }, { t: 'No se reporta', v: M(this.liqFilas.reduce((s, x) => s + x.no_salarial, 0)) }, { t: 'Total pagado', v: M(this.liqFilas.reduce((s, x) => s + x.total, 0)) }], nota: NOTA_LIQ });
      return secs;
    },
    async documento(formato) {
      const M = v => money(v || 0), t = this.tot;
      // 4.7: el subtítulo dice qué se sumó (planillas y liquidaciones pagadas) y la nota lleva los avisos de la pantalla
      const sub = this.plMes.length + ' planilla(s) pagada(s) con cierre en el mes' + (this.plMes.length ? ': ' + this.plMes.map(p => p.numero + (esComplementaria(p) ? ' (complementaria)' : '')).join(', ') : '') + (this.liqMes.length ? '; ' + this.liqMes.length + ' liquidación(es) pagada(s) con salida en el mes: ' + this.liqMes.map(l => l.numero).join(', ') : '') + '.';
      const avisos = this.avisos.length ? ' Avisos: ' + this.avisos.join(' ') : '';
      try { await descargarReporte(formato, { titulo: 'Informe mensual de planilla · ' + this.nombreMes, subtitulo: sub, periodo: this.nombreMes, kpis: [{ t: 'Salarios reportados', v: M(t.bruto) }, { t: 'CCSS a pagar', v: M(t.obrero + t.patronal_ccss) }, { t: 'Renta retenida', v: M(t.renta) }, { t: 'Costo total', v: M(t.costo) }], cols: [], rows: [], secciones: this.secciones(), nota: 'Montos en colones. Solo se suman planillas y liquidaciones pagadas. Los días por trabajador se estiman con los períodos de las planillas menos los días no pagados, más los días de salario pendiente de las liquidaciones (tope: los días del mes).' + avisos, archivo: 'planilla_mensual_' + this.mes }); }
      catch (e) { toast(e.message, 'err'); }
    },
    // 3.67: archivos para cargar la planilla en la CCSS (SICERE) y en el INS, con las columnas que piden esos sitios
    // 4.7: los apellidos salen de partirNombre (primer y segundo apellido de la ficha o una separación con aviso)
    tipoIdTexto(e) { return ({ '01': 'Cédula física', '02': 'Cédula jurídica', '03': 'DIMEX', '04': 'NITE', '05': 'Extranjero no domiciliado' })[String((e && e.tipo_id) || '01')] || 'Cédula física'; },
    filasOficiales() {
      return this.porEmpleado.map(o => {
        const e = this.porId[o.empleado_id] || { nombre: o.nombre }, pn = partirNombre(e);
        return { tipo_id: this.tipoIdTexto(e), numero_id: String(o.numero_id || e.numero_id || '').replace(/[^0-9A-Za-z]/g, ''), nombre: pn.nombre || o.nombre, primer_apellido: pn.primero, segundo_apellido: pn.segundo, nombre_completo: o.nombre, salario: o.bruto.toFixed(2), dias: String(o.dias),
          jornada: JORNADA_INFORME[e.jornada || 'diurna'] || String(e.jornada), periodo_pago: FRECUENCIA_INFORME[e.periodo_pago || 'quincenal'] || String(e.periodo_pago),
          ocupacion: o.puesto || e.puesto || '', ingreso: e.fecha_ingreso ? fecha(e.fecha_ingreso) : '', salida: e.fecha_salida ? fecha(e.fecha_salida) : '', mes: this.mes };
      });
    },
    archivoCCSS() {
      const cols = [{ key: 'tipo_id', label: 'Tipo de identificación' }, { key: 'numero_id', label: 'Número de identificación' }, { key: 'nombre', label: 'Nombre' }, { key: 'primer_apellido', label: 'Primer apellido' }, { key: 'segundo_apellido', label: 'Segundo apellido' }, { key: 'salario', label: 'Salario devengado' }, { key: 'dias', label: 'Días laborados' }, { key: 'periodo_pago', label: 'Tipo de salario' }, { key: 'jornada', label: 'Jornada' }, { key: 'ocupacion', label: 'Ocupación' }, { key: 'ingreso', label: 'Fecha de ingreso' }, { key: 'salida', label: 'Fecha de salida' }];
      descargarCSV('planilla_ccss_sicere_' + this.mes, cols, this.filasOficiales(), a => registrarExportable(a, 'Archivo CCSS ' + this.mes, true)); toast('Archivo para la CCSS descargado: cárguelo en SICERE › Planilla en línea', 'ok');
    },
    archivoINS() {
      const cols = [{ key: 'tipo_id', label: 'Tipo de identificación' }, { key: 'numero_id', label: 'Número de identificación' }, { key: 'nombre_completo', label: 'Nombre completo' }, { key: 'salario', label: 'Salario reportado' }, { key: 'dias', label: 'Días laborados' }, { key: 'ocupacion', label: 'Ocupación' }, { key: 'mes', label: 'Mes' }];
      descargarCSV('planilla_ins_riesgos_' + this.mes, cols, this.filasOficiales(), a => registrarExportable(a, 'Archivo INS ' + this.mes, true)); toast('Archivo para el INS descargado: cárguelo en RT-Virtual › Planilla', 'ok');
    },
    csv(formato) {
      const cols = [{ key: 'numero_id', label: 'Identificación' }, { key: 'nombre', label: 'Trabajador' }, { key: 'dias', label: 'Días' }, { key: 'bruto', label: 'Salario reportado' }, { key: 'obrero', label: 'Cuota obrera' }, { key: 'patronal_ccss', label: 'Cuota patronal' }, { key: 'ins', label: 'INS' }, { key: 'renta', label: 'Renta retenida' }, { key: 'neto', label: 'Neto' }, { key: 'costo', label: 'Costo total' }];
      descargarTabla(formato === 'xlsx' ? 'xlsx' : 'csv', 'planilla_mensual_' + this.mes, cols, this.porEmpleado, { titulo: 'Planilla mensual ' + this.mes, registrar: a => registrarExportable(a, 'Planilla mensual ' + this.mes, true) });
    },
    // ---- 4.22: pago de las cargas del mes. El monto y las reglas son del servidor: aquí se piden, se muestran y se vuelven a leer
    async cargarCargas() {
      const mes = this.mes;
      if (this.cargas && this.cargas.mes !== mes) this.cargas = null;
      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(mes)) return false;
      try { const r = await api('/api/rrhh/cargas?mes=' + mes); if (this.mes === mes) this.cargas = r; return true; }
      catch { return false; }
    },
    async cargarPagosCargas() {
      try { await mock.refrescar(['rrhh_pagos_cargas', 'movimientos']); } catch { /* sin conexión: queda lo que ya tenía la pestaña */ }
      this.pagosCargas = mock.get('rrhh_pagos_cargas', []) || [];
    },
    async abrirPagoCargas(c) {
      if (!c.sePuede) return;
      if (!this.cuentasLista) this.cuentasLista = await cuentasParaMovimientos();
      const b = cuentaPrincipal('CRC', this.cuentasLista), nombres = this.cuentasCargas;
      this.pagoCargas = { tipo: c.tipo, corto: c.corto, nombre: c.nombre, monto: c.monto, mes: this.mes, mes_nombre: this.nombreMes, anterior: !!(this.cargas && this.cargas.anterior), cuenta: b && nombres.includes(b.nombre) ? b.nombre : (nombres[0] || ''), fecha: hoy(), comprobante: '', guardando: false };
    },
    cerrarPagoCargas() { if (this.pagoCargas && !this.pagoCargas.guardando) this.pagoCargas = null; },
    // El pago lo guarda el servidor (con su salida en Bancos) y él decide si procede. Con cualquier respuesta, o sin ella, se vuelve a
    // leer lo que quedó guardado antes de decir nada: una respuesta perdida no se toma por un rechazo ni se registra dos veces.
    // 4.22: el monto que se confirma es el que se guarda: viaja el que muestra el cuadro y, si el servidor calcula otro, no registra
    async confirmarPagoCargas() {
      const p = this.pagoCargas;
      if (!p || p.guardando) return;
      if (!p.cuenta) return toast('Seleccione la cuenta de Bancos de la que sale el pago', 'err');
      if (!p.fecha) return toast('Indique la fecha de pago', 'err');
      // 4.22: las cargas de un mes no se pagan antes de que ese mes empiece (un año mal escrito quedaría para siempre: el pago no se cambia)
      if (p.fecha < p.mes + '-01') return toast('Revise la fecha de pago: no puede ser anterior al mes que se paga ni estar a más de un mes de hoy', 'err');
      // 4.22: un mes anterior a esta función: sus cargas se pagaban a mano y el sistema no sabe si ya están en Bancos o en la
      // contabilidad. Se pregunta antes de enviar, y solo con el «sí» viaja confirma_anterior (sin él, el servidor responde 409)
      if (p.anterior && !confirm('Las cargas de ' + p.mes_nombre + ' son anteriores a esta función. Si ya las pagó y lo registró a mano en Bancos o en la contabilidad, NO las registre aquí. ¿Confirma que este pago todavía no está registrado?')) return;
      p.guardando = true;
      let r = null, error = null;
      // monto_esperado es el que el usuario ve en este cuadro: el servidor NO lo guarda (calcula el suyo), solo lo compara, y si el
      // monto del mes cambió entretanto no registra nada
      const cuerpo = { mes: p.mes, tipo: p.tipo, cuenta: p.cuenta, fecha_pago: p.fecha, comprobante: String(p.comprobante || '').trim(), monto_esperado: p.monto };
      if (p.anterior) cuerpo.confirma_anterior = true;
      try { r = await api('/api/rrhh/pago-cargas', { method: 'POST', body: cuerpo }); } catch (e) { error = e; }
      const leido = await this.cargarCargas();
      await this.cargarPagosCargas();
      const fila = leido && this.cargas && this.cargas.mes === p.mes ? (this.cargas.cargas || []).find(x => x.tipo === p.tipo) : null, g = (fila && fila.pago) || null;
      const que = p.corto + ' de ' + p.mes_nombre, sinRespuesta = !!error && (!error.status || error.status >= 500);
      if (r || (g && sinRespuesta && g.cuenta === p.cuenta && g.fecha_pago === p.fecha)) {
        const pago = (r && r.pago) || g;
        this.pagoCargas = null;
        toast('Pago de ' + que + ' registrado: ' + money(pago.monto) + ' desde ' + pago.cuenta, 'ok');
        if (r ? r.en_bancos === false : fila.en_bancos === false) toast('El pago quedó registrado, pero falta su salida en Bancos: regístrela con el botón de esa fila', 'err');
        return;
      }
      p.guardando = false;
      if (g) { this.pagoCargas = null; return toast(error.status === 409 ? error.message : 'Las cargas de ' + que + ' ya estaban registradas como pagadas: no se registró otro pago ni otra salida en Bancos', 'err'); }
      // 4.22: el monto del mes cambió desde que se abrió el cuadro (se pagó otra planilla del mes): no se registró nada. La tarjeta
      // ya se releyó arriba; el cuadro se cierra y se vuelve a abrir con el monto de ahora
      if (error.detail && error.detail.codigo === 'cargas_monto_cambio') { this.pagoCargas = null; return toast(error.message, 'err'); }
      if (sinRespuesta && !leido) return toast('No se pudo confirmar con el servidor si el pago de ' + que + ' quedó registrado. Cuando vuelva la conexión actualice la pantalla: si aparece como Pagado, ya está; si sigue ' + (p.anterior ? '«Sin registrar aquí»' : 'Pendiente') + ', regístrelo de nuevo (el sistema no deja registrarlo dos veces)', 'err');
      if (sinRespuesta) return toast('El servidor no registró el pago de ' + que + ' (' + error.message + '): sigue pendiente. Intente de nuevo', 'err');
      toast(error.message, 'err');
    },
    // Un pago guardado al que le falta su salida en Bancos (el servidor se detuvo entre los dos pasos): la registra él, con los datos del pago
    async salidaCargas(c) {
      if (this.registrandoSalida || !c.pago) return;
      this.registrandoSalida = true;
      try { const r = await api('/api/rrhh/pago-cargas/' + c.pago.id + '/banco', { method: 'POST' }); toast(r.ya ? 'La salida en Bancos ya estaba registrada' : 'Salida en Bancos registrada: ' + money(c.pago.monto) + ' desde ' + c.pago.cuenta, 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      await this.cargarCargas();
      await this.cargarPagosCargas();
      this.registrandoSalida = false;
    },
    async exportarPagos(formato) {
      const cols = [{ key: 'mes_nombre', label: 'Mes' }, { key: 'carga', label: 'Carga' }, { key: 'monto', label: 'Monto', num: true, fmt: 'money' }, { key: 'pagado', label: 'Pagado el', fmt: 'date' }, { key: 'cuenta', label: 'Cuenta' }, { key: 'comprobante', label: 'Comprobante' }, { key: 'registro', label: 'Registró' }];
      const rows = this.pagosFilas, titulo = 'Pagos de cargas';
      if (!rows.length) return toast('Todavía no hay pagos de cargas registrados');
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'pagos_cargas', cols, rows, { titulo, registrar: a => registrarExportable(a, titulo, true) });
      await descargarReporte(formato, { titulo, subtitulo: 'Pagos registrados de las cargas de cada mes: CCSS (cuota obrera y cargas patronales), INS (riesgos del trabajo) y renta retenida a los salarios, con la cuenta de la que salieron.', periodo: 'Al ' + fecha(hoy()), cols, rows, totales: [{ t: 'Total pagado', v: money(rows.reduce((s, x) => s + x.monto, 0)) }], archivo: 'pagos_cargas', privado: true });
    },
  },
  async created() { this.$watch('mes', () => this.cargarCargas()); this.cargarCargas(); this.cargarPagosCargas(); try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
  template: `
  <div class="page">
    <ReportesTabs></ReportesTabs>
    <PageHead title="Informes de planilla" sub="Resumen mensual con lo que se reporta a la CCSS, la renta retenida para la declaración de retenciones y el costo por empleado. Sale de las planillas pagadas cuyo período cierra en el mes y de lo salarial de las liquidaciones pagadas con salida en el mes." :crumbs="[{label:'Recursos humanos'},{label:'Informes'}]">
      <template v-if="!verIndicadores"><button class="btn sec" @click="documento('pdf')" :disabled="!hayDatos">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!hayDatos">⤓ Word</button><button class="btn ghost" @click="csv('xlsx')" :disabled="!hayDatos">⤓ Excel</button><button class="btn ghost" @click="csv" :disabled="!hayDatos">⤓ CSV</button><button class="btn ghost" @click="archivoCCSS" :disabled="!hayDatos" title="Columnas de la planilla en línea de la CCSS (SICERE)">⤓ Archivo CCSS</button><button class="btn ghost" @click="archivoINS" :disabled="!hayDatos" title="Columnas de la planilla de riesgos del trabajo del INS">⤓ Archivo INS</button></template><button class="btn sec" :title="verIndicadores ? 'Volver al informe mensual de planilla' : 'Costo por departamento, ausentismo, rotación, cumpleaños y aniversarios'" @click="verIndicadores = !verIndicadores">{{verIndicadores ? '‹ Informe mensual' : 'Indicadores'}}</button>
    </PageHead>
    <Indicadores v-if="verIndicadores" :mes-inicial="mes"></Indicadores>
    <template v-else>
    <div class="card"><div class="row" style="gap:10px;align-items:center;flex-wrap:wrap">
      <button class="btn ghost sm" @click="cambiarMes(-1)">‹</button><input type="month" class="inp" v-model="mes"><button class="btn ghost sm" @click="cambiarMes(1)">›</button>
      <span class="small muted">{{plMes.length}} planilla(s) pagada(s) con cierre en {{nombreMes}}<span v-if="plMes.length">: {{plMes.map(p => p.numero + ' (' + fecha(p.desde) + ' – ' + fecha(p.hasta) + ')').join(', ')}}</span><span v-if="liqMes.length"> · {{liqMes.length}} liquidación(es) pagada(s): {{liqMes.map(l => l.numero).join(', ')}}</span></span>
    </div></div>
    <div class="alert warn" v-if="avisos.length" style="margin-bottom:12px"><div v-for="(a, i) in avisos" :key="i" :style="i ? 'margin-top:6px' : ''">{{a}}</div></div>
    <template v-if="hayDatos">
      <div class="dash" style="margin-bottom:18px">
        <div class="kpi w3"><div class="t">Salarios reportados</div><div class="v">{{money(tot.bruto)}}</div><div class="d">{{porEmpleado.length}} trabajadores</div></div>
        <div class="kpi w3"><div class="t">CCSS a pagar</div><div class="v">{{money(tot.obrero + tot.patronal_ccss)}}</div><div class="d">obrera {{money(tot.obrero)}} + patronal {{money(tot.patronal_ccss)}}</div></div>
        <div class="kpi w3"><div class="t">Renta retenida</div><div class="v">{{money(tot.renta)}}</div><div class="d">{{conRenta.length}} con retención</div></div>
        <div class="kpi w3"><div class="t">Costo total</div><div class="v">{{money(tot.costo)}}</div><div class="d">INS {{money(tot.ins)}} · reservas {{money(tot.provisiones)}}</div></div>
      </div>
      <div class="card pad0"><div style="padding:14px 16px 0"><h2 style="margin:0">Planilla mensual para la CCSS <small>salarios reportados y cuotas por trabajador</small></h2></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Identificación</th><th>Trabajador</th><th class="num">Días</th><th class="num">Salario reportado</th><th class="num">Cuota obrera</th><th class="num">Cuota patronal</th><th class="num">INS</th><th class="num">Renta</th><th class="num">Neto pagado</th></tr></thead>
          <tbody><tr v-for="o in porEmpleado" :key="o.empleado_id || o.nombre"><td class="mono">{{o.numero_id || '—'}}</td><td>{{o.nombre}}<div class="small muted" v-if="o.puesto">{{o.puesto}}</div></td><td class="num">{{o.dias}}</td><td class="num">{{money(o.bruto)}}</td><td class="num">{{money(o.obrero)}}</td><td class="num">{{money(o.patronal_ccss)}}</td><td class="num">{{money(o.ins)}}</td><td class="num">{{money(o.renta)}}</td><td class="num"><b>{{money(o.neto)}}</b></td></tr></tbody>
          <tfoot><tr><th colspan="2">Totales</th><th class="num">{{tot.dias}}</th><th class="num">{{money(tot.bruto)}}</th><th class="num">{{money(tot.obrero)}}</th><th class="num">{{money(tot.patronal_ccss)}}</th><th class="num">{{money(tot.ins)}}</th><th class="num">{{money(tot.renta)}}</th><th class="num">{{money(tot.neto)}}</th></tr></tfoot></table></div>
        <p class="small muted" style="padding:10px 16px">Verifique estos montos contra la planilla preliminar del SICERE antes de pagar. Los subsidios de incapacidad y los viáticos no se reportan como salario.</p>
      </div>
      <div class="card pad0" v-if="liqFilas.length"><div style="padding:14px 16px 0"><h2 style="margin:0">Liquidaciones pagadas con salida en el mes <small>solo el salario pendiente y las vacaciones se reportan</small></h2></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Liquidación</th><th>Trabajador</th><th>Salida</th><th class="num">Salario pendiente y vacaciones</th><th class="num">Preaviso, cesantía y aguinaldo</th><th class="num">CCSS obrera</th><th class="num">CCSS patronal</th><th class="num">Renta</th><th class="num">Total pagado</th></tr></thead>
          <tbody><tr v-for="x in liqFilas" :key="'l' + x.numero + x.empleado_id"><td class="mono">{{x.numero}}</td><td>{{x.nombre}}</td><td>{{fecha(x.salida)}}</td><td class="num">{{money(x.salarial)}}</td><td class="num">{{money(x.no_salarial)}}</td><td class="num">{{money(x.obrero)}}</td><td class="num">{{money(x.patronal_ccss)}}</td><td class="num">{{money(x.renta)}}</td><td class="num"><b>{{money(x.total)}}</b></td></tr></tbody></table></div>
        <p class="small muted" style="padding:10px 16px">El salario pendiente y las vacaciones se suman arriba al salario reportado, a la CCSS y al INS, y la renta que se les retuvo en la liquidación (calculada con lo ya pagado en el mes) se suma a la renta del mes. El preaviso, la cesantía y el aguinaldo proporcional no son salario: no cotizan ni se reportan.</p>
      </div>
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Cuotas por rubro</h2>
          <table class="tbl"><tbody><tr v-for="r in rubrosObreros" :key="'o'+r.rubro"><td>Obrera · {{r.rubro}}</td><td class="num">{{money(r.monto)}}</td></tr><tr v-for="r in rubrosPatronales" :key="'p'+r.rubro"><td>Patronal · {{r.rubro}}</td><td class="num">{{money(r.monto)}}</td></tr></tbody></table>
        </div>
        <div class="card"><h2>Costo por empleado</h2>
          <table class="tbl"><thead><tr><th>Empleado</th><th class="num">Bruto</th><th class="num">Cargas + INS</th><th class="num">Reservas</th><th class="num">Costo</th></tr></thead>
            <tbody><tr v-for="o in porEmpleado" :key="'c'+(o.empleado_id || o.nombre)"><td>{{o.nombre}}</td><td class="num">{{money(o.bruto)}}</td><td class="num">{{money(o.patronal_ccss + o.ins)}}</td><td class="num">{{money(o.provisiones)}}</td><td class="num"><b>{{money(o.costo)}}</b></td></tr></tbody></table>
        </div>
      </div>
      <div class="card" v-if="cargasFilas.length"><h2>Pago de las cargas del mes <small>CCSS, INS y renta retenida de {{nombreMes}}</small></h2>
        <div class="alert warn" v-if="cargas.bloqueo" style="margin-bottom:10px">{{cargas.bloqueo}}.</div>
        <div class="alert info" v-if="cargas.anterior" style="margin-bottom:10px">Las cargas de meses anteriores a noviembre de 2026 se pagaban fuera de esta función. Regístrelas aquí solo si ese pago todavía no está en Bancos ni en la contabilidad: quedaría dos veces y un pago registrado no se elimina.</div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Carga</th><th class="num">Monto del mes</th><th>Estado</th><th></th></tr></thead>
          <tbody><tr v-for="c in cargasFilas" :key="c.tipo"><td style="white-space:normal">{{c.nombre}}<div class="small muted" v-if="c.desglose">{{c.desglose}}</div></td><td class="num"><b>{{money(c.monto)}}</b></td>
            <td style="white-space:normal"><span class="badge" :class="c.insignia">{{c.estado}}</span><div class="small muted" v-if="c.detallePago">{{c.detallePago}}</div><div class="small" v-if="c.diferencia"><b>{{c.diferencia}}</b></div><div class="small" v-if="c.pago && c.en_bancos === false"><b>Falta su salida en Bancos.</b></div></td>
            <td><button class="btn sm" v-if="!c.pago" :disabled="!c.sePuede" :title="c.motivo" @click.stop="abrirPagoCargas(c)">Registrar pago</button><button class="btn sm sec" v-else-if="c.en_bancos === false" :disabled="registrandoSalida" @click.stop="salidaCargas(c)">Registrar la salida en Bancos</button></td></tr></tbody></table></div>
        <p class="small muted" style="margin:10px 0 0">El monto es lo que las planillas y las liquidaciones pagadas de {{nombreMes}} dejaron por pagar en la contabilidad; lo calcula el sistema y no se edita. Las cargas patronales incluyen el INS aparte de la póliza, si la empresa lo usa; el INS que este informe estima para las liquidaciones no queda en la contabilidad y no entra aquí. Si la CCSS, el INS o Hacienda cobran otra cifra (redondeos, recargos, base mínima o una póliza del INS que no es mensual), registre la diferencia con un asiento manual. Un pago registrado no se cambia ni se elimina.</p>
      </div>
      <div class="card pad0" v-if="pagosFilas.length"><div style="padding:14px 16px 0"><h2 style="margin:0">Pagos de cargas registrados <small>todos los meses</small></h2></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Mes</th><th>Carga</th><th class="num">Monto</th><th>Pagado el</th><th>Cuenta</th><th>Comprobante</th><th>Registró</th></tr></thead>
          <tbody><tr v-for="p in pagosFilas" :key="p.id"><td>{{p.mes_nombre}}</td><td>{{p.carga}}</td><td class="num">{{money(p.monto)}}</td><td>{{fecha(p.pagado)}}</td><td style="white-space:normal">{{p.cuenta || '—'}}</td><td style="white-space:normal">{{p.comprobante || '—'}}</td><td style="white-space:normal">{{p.registro || '—'}}</td></tr></tbody></table></div>
        <div class="row" style="gap:8px;flex-wrap:wrap;padding:10px 16px;align-items:center"><button class="btn sm sec" @click="exportarPagos('pdf')">⤓ PDF</button><button class="btn sm ghost" @click="exportarPagos('xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportarPagos('csv')">⤓ CSV</button><span class="small muted">Cada pago sale de la cuenta en Bancos y la contabilidad lo registra contra lo que quedó por pagar.</span></div>
      </div>
      <Modal v-if="pagoCargas" :title="'Registrar el pago · ' + pagoCargas.nombre" @close="cerrarPagoCargas">
        <div class="totals" style="margin-top:0"><div class="total"><span>{{pagoCargas.corto}} de {{pagoCargas.mes_nombre}}</span><b>{{money(pagoCargas.monto)}}</b></div></div>
        <div class="grid cols-2" style="margin-top:10px">
          <Field label="Sale de la cuenta" req help="Cuentas de Bancos y cajas en colones"><select v-model="pagoCargas.cuenta"><option v-for="n in cuentasCargas" :key="n" :value="n">{{n}}</option></select></Field>
          <Field label="Fecha de pago" req><input type="date" v-model="pagoCargas.fecha" :min="pagoCargas.mes + '-01'"></Field>
          <Field label="Comprobante o recibo" help="Opcional: el número que dio SICERE, el INS o TRIBU-CR" style="grid-column:1/-1"><input v-model="pagoCargas.comprobante" maxlength="60"></Field>
        </div>
        <div class="alert warn" v-if="!cuentasCargas.length" style="margin:8px 0 0">No hay cuentas en colones en Bancos y cajas: cree una para registrar el pago.</div>
        <p class="small muted" style="margin:8px 0 0">El monto lo calcula el sistema con las planillas y las liquidaciones pagadas del mes y no se edita. Al confirmar se guarda el pago, sale de la cuenta en Bancos y la contabilidad lo registra contra lo que quedó por pagar. Un pago registrado no se cambia ni se elimina: revise la cuenta y la fecha; si le cobraron otra cifra, registre la diferencia con un asiento manual. Si el pago de este mes ya está en Bancos o en la contabilidad porque se registró a mano, no lo registre aquí: quedaría dos veces.</p>
        <template #foot><button class="btn ghost" :disabled="pagoCargas.guardando" @click="cerrarPagoCargas">Cancelar</button><button class="btn" :disabled="pagoCargas.guardando || !pagoCargas.cuenta" @click="confirmarPagoCargas">{{pagoCargas.guardando ? 'Registrando…' : 'Registrar pago'}}</button></template>
      </Modal>
    </template>
    <div class="card" v-else><Empty icon="📑" title="Sin planillas pagadas en el mes" text="Los informes se arman con las planillas pagadas cuyo período cierra en el mes elegido y con las liquidaciones pagadas con salida en ese mes."><a class="btn" href="#/rrhh/planilla">Ir a Planilla</a></Empty></div>
    </template>
  </div>`,
};
