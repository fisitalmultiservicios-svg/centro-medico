// Recursos humanos › Empleados: lista con costo mensual estimado (bruto, cargas patronales y provisiones) según los parámetros,
// avisos de lo que requiere atención (vacaciones acumuladas, contratos por vencer, salarios bajo el mínimo, datos faltantes),
// exportación en PDF, Word, Excel y CSV e importación de empleados nuevos desde un Excel o un CSV (4.21).
import { api, money, fecha, hoy, toast, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { empleados, guardarEmpleados, nombreCompleto, periodoNombre, salarioMensual, tablas, diasGanados, diasDisfrutados, liquidaciones, planillas, constanciaSalarial } from './_datos.js';
import { documentos, vencimientos } from './_datos.js';   // 4.22: documentos del empleado y sus vencimientos
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';
// 4.21: el día en que cae un cumpleaños o un aniversario dentro de un rango (la misma regla de Informes › Indicadores)
import { ocurrencia } from './indicadores.js';
import { sesion as sesionPlan } from '../../app.js';   // 3.87: empleados incluidos en el plan (con alias: otro cambio de la 3.87 importa «sesion» aquí)

// 4.21: columnas de la plantilla para importar empleados, en el orden del archivo: [columna, obligatoria, qué lleva, ejemplo]. Son las
// mismas de rrhh.COLUMNAS_IMPORTAR en el servidor. La fila de ejemplo es ficticia y su nombre empieza con «EJEMPLO»: el servidor
// nunca la importa.
export const COLUMNAS_IMPORTAR = [
  ['nombre', true, 'Nombre, sin los apellidos', 'EJEMPLO Ana María'], ['apellidos', false, 'Los dos apellidos juntos (o use apellido1 y apellido2)', 'Mora Rojas'],
  ['apellido1', false, 'Primer apellido (opcional)', 'Mora'], ['apellido2', false, 'Segundo apellido (opcional)', 'Rojas'],
  ['tipo_id', true, 'Cédula, DIMEX, NITE o Extranjero (o su código: 01, 03, 04, 05)', 'Cédula'], ['numero_id', true, 'Sin guiones. Cédula: 9 dígitos; DIMEX: 11 o 12', '101110111'],
  ['nacimiento', false, 'Fecha de nacimiento: AAAA-MM-DD o DD/MM/AAAA', '1990-05-20'], ['correo', false, 'Correo del empleado: ahí recibe sus comprobantes de pago', 'ana.ejemplo@example.com'],
  ['telefono', false, 'Teléfono, solo números', '88880000'], ['puesto', false, 'Nombre del puesto', 'Recepcionista'],
  ['categoria', false, 'Código de la categoría salarial de Parámetros (TOSC, TOC, BU…). Vacía: la del puesto o TOSC', 'TOSC'],
  ['departamento', false, 'Nombre del departamento, como está en Horarios de trabajo', 'Recepción'], ['fecha_ingreso', true, 'AAAA-MM-DD o DD/MM/AAAA', '2026-01-15'],
  ['jornada', false, 'diurna, mixta, nocturna o medio_tiempo. Vacía: diurna', 'diurna'], ['horas_semana', false, 'Horas por semana. Vacía: las de la jornada', '48'],
  ['modo_salario', true, 'hora o mensual', 'mensual'], ['salario', true, 'Por hora o por mes según el modo, sin separador de miles: 450000 o 450000,50', '450000'],
  ['periodo_pago', false, 'semanal, bisemanal, quincenal, mensual o manual. Vacío: quincenal', 'quincenal'], ['forma_pago', false, 'transferencia, efectivo, cheque o sinpe. Vacía: transferencia', 'transferencia'],
  ['cuenta_iban', false, 'Cuenta IBAN: CR y 20 dígitos', 'CR05015202001026284066'], ['hijos', false, 'Hijos a cargo (número). Vacío: 0', '0'], ['conyuge', false, 'Cónyuge a cargo: Sí o No. Vacío: No', 'No'],
  ['aplica_renta', false, 'Retener impuesto sobre la renta: Sí o No. Vacío: Sí', 'Sí'], ['codigo_reloj', false, 'Código del reloj marcador: 1 a 4 dígitos', '0001'],
  ['tipo_contrato', false, 'indefinido, plazo_fijo, obra o temporal. Vacío: indefinido', 'indefinido'], ['fecha_fin_contrato', false, 'Solo si el contrato no es indefinido: AAAA-MM-DD o DD/MM/AAAA', ''],
];

export default {
  props: ['params'],
  data() { return { lista: empleados(), q: '', t: null, ver: null, estado: 'activos', aguinaldos: mock.get('rrhh_aguinaldos', []) || [], imp: null, usuarios: null, constancia: null, generando: false }; },
  computed: {
    pct() { const t = this.t ? this.t.tasas : null; return t ? { patronal: t.patrono + (this.t.efectivos.ins_riesgos || 0), provisiones: t.provisiones } : { patronal: 26.83, provisiones: 17.83 }; },
    minimos() { const m = {}; for (const c of (this.t && this.t.efectivos.categorias) || []) m[c.codigo] = c.base === 'dia' ? c.monto * ((this.t.efectivos.dias_mes) || 30) : c.monto; return m; },
    todos() {
      return this.lista.map(e => { const m = salarioMensual(e); const hs = +e.horas_semana || 48, minimo = this.minimos[e.categoria] ? this.minimos[e.categoria] * Math.min(1, hs / 48) : null;
        const uc = String(e.usuario_correo || e.correo || '').trim().toLowerCase(), uw = uc && this.usuarios ? this.usuarios.find(u => u.correo === uc) : null;   // usuario web (3.71)
        return { ...e, usuario_web: this.usuarios === null ? '' : (uw ? uw.rol + (uw.bloqueado ? ' (bloqueado)' : '') : 'No'), nombre_completo: nombreCompleto(e), mensual: m, costo: Math.round(m * (1 + (this.pct.patronal + this.pct.provisiones) / 100)), periodo: periodoNombre(e.periodo_pago), estado: e.activo === false ? 'Inactivo' : 'Activo', bajo_minimo: !!(minimo && m + 0.5 < minimo),
          vac_saldo: Math.round((diasGanados(e.fecha_ingreso, e.activo === false && e.fecha_salida ? e.fecha_salida : undefined, (this.t && this.t.efectivos.dias_vacaciones_por_mes) || 1) - diasDisfrutados(e.id)) * 100) / 100 }; });   // misma regla que el servidor (R310)
    },
    rows() { return this.todos.filter(r => this.estado === 'todos' || (this.estado === 'activos' ? r.activo !== false : r.activo === false)); },
    columns() {
      return [
        { key: 'nombre_completo', label: 'Empleado', link: r => location.hash = '/rrhh/empleados/' + r.id, fmt: (v, r) => v + (r.bajo_minimo ? ' ⚠' : '') }, { key: 'numero_id', label: 'Identificación', mono: true },
        { key: 'puesto', label: 'Puesto', fmt: (v, r) => (v || '—') + (r.departamento ? ' · ' + r.departamento : '') }, { key: 'fecha_ingreso', label: 'Ingreso', fmt: 'date' }, { key: 'periodo', label: 'Pago' },
        { key: 'mensual', label: 'Salario mensual', num: true, fmt: 'money' }, { key: 'costo', label: 'Costo mensual', num: true, fmt: 'money' },
        { key: 'vac_saldo', label: 'Vacaciones', num: true, fmt: v => v + ' d' }, { key: 'estado', label: 'Estado', fmt: 'badge' },
        ...(this.usuarios !== null ? [{ key: 'usuario_web', label: 'Usuario web', fmt: v => v }] : []),   // solo quien administra usuarios lo ve (3.71)
      ];
    },
    activos() { return this.todos.filter(r => r.activo !== false); },
    totBruto() { return this.activos.reduce((s, r) => s + r.mensual, 0); },
    totCosto() { return this.activos.reduce((s, r) => s + r.costo, 0); },
    // 4.21: vista previa de la importación: cada fila del archivo con sus mensajes, las que hay que corregir y el aviso del plan
    filasVista() { return this.imp && this.imp.vista ? (this.imp.vista.filas || []).map(f => ({ ...f, mensajes: [...(f.errores || []), ...(f.avisos || [])] })) : []; },
    filasConMensajes() { return this.filasVista.filter(f => f.mensajes.length); },
    textoImportar() { const n = this.imp && this.imp.vista ? +this.imp.vista.validas || 0 : 0; return n === 1 ? 'Importar 1 empleado' : 'Importar ' + n + ' empleados'; },
    avisoPlanImportar() {
      const v = this.imp && this.imp.vista, p = v && v.plan, inc = p ? +p.incluidos || 0 : 0, serian = p ? (+p.activos || 0) + (this.imp.hecho === null ? +v.validas || 0 : 0) : 0;
      return inc && serian > inc ? 'Su plan incluye ' + inc + ' empleados y ' + (this.imp.hecho === null ? 'con esta importación tendrá ' + serian + ' activos: cada empleado adicional se cobra aparte. Puede importarlos igual.' : 'ya tiene ' + serian + ' activos: cada empleado adicional se cobra aparte.') : '';
    },
    // Lo que requiere atención: se revisa cada vez que se abre la lista
    avisos() {
      const out = [], h = hoy(), en30 = new Date(h + 'T00:00:00'); en30.setDate(en30.getDate() + 30);
      const lim = `${en30.getFullYear()}-${String(en30.getMonth() + 1).padStart(2, '0')}-${String(en30.getDate()).padStart(2, '0')}`;
      // 4.22: documentos subidos a cada ficha, para avisar los vencidos y los que vencen en 30 días junto con las dos fechas de la ficha
      const docsDe = {}; for (const d of documentos()) (docsDe[d.empleado_id] = docsDe[d.empleado_id] || []).push(d);
      for (const r of this.activos) {
        if (r.bajo_minimo) out.push({ k: 'warn', texto: r.nombre_completo + ': salario mensual (' + money(r.mensual) + ') por debajo del mínimo de su categoría', to: '/rrhh/empleados/' + r.id });
        if (r.vac_saldo >= 24) out.push({ k: 'warn', texto: r.nombre_completo + ' acumula ' + r.vac_saldo + ' días de vacaciones sin disfrutar', to: '/rrhh/vacaciones' });
        if (r.tipo_contrato && r.tipo_contrato !== 'indefinido' && r.fecha_fin_contrato && r.fecha_fin_contrato <= lim) out.push({ k: r.fecha_fin_contrato < h ? 'err' : 'warn', texto: r.nombre_completo + ': contrato a plazo ' + (r.fecha_fin_contrato < h ? 'vencido el ' : 'vence el ') + fecha(r.fecha_fin_contrato), to: '/rrhh/liquidaciones?empleado=' + r.id });
        // 4.22: un solo aviso por empleado con lo vencido (rojo) o por vencer en 30 días (amarillo): identificación, permiso y documentos
        const venc = vencimientos(r, 30, docsDe[r.id] || []);
        if (venc.length) out.push({ k: venc.some(v => v.vencido) ? 'err' : 'warn', texto: r.nombre_completo + ': ' + venc.slice(0, 3).map(v => v.que + (v.vencido ? ' venció el ' : ' vence el ') + fecha(v.fecha)).join('; ') + (venc.length > 3 ? ' y ' + (venc.length - 3) + ' más' : ''), to: '/rrhh/empleados/' + r.id });
        if (!r.correo) out.push({ k: 'info', texto: r.nombre_completo + ' no tiene correo: no recibirá sus comprobantes de pago', to: '/rrhh/empleados/' + r.id });
      }
      const plan = (sesionPlan.empresaInfo && sesionPlan.empresaInfo.plan) || {}, inc = +plan.empleados_incluidos || 0;   // 3.87: el extra de Recursos humanos incluye hasta 15 empleados (aviso; no bloquea)
      if (inc && this.activos.length > inc) out.unshift({ k: 'warn', texto: 'Tiene ' + this.activos.length + ' empleados activos y su plan incluye ' + inc + ': cada empleado adicional se cobra aparte (' + money(plan.precio_empleado_extra || 0) + ' al mes por empleado). Puede seguir registrándolos.', to: sesionPlan.puede('configurar') ? '/configuracion/suscripcion' : '/rrhh/empleados' });
      const m = +h.slice(5, 7), y = +h.slice(0, 4);
      if ((m === 11 || m === 12) && !(this.aguinaldos || []).some(a => +a.anio === y) && this.activos.length) out.push({ k: 'info', texto: 'El aguinaldo ' + y + ' se paga a más tardar el 20 de diciembre', to: '/rrhh/aguinaldo' });
      const pendientes = liquidaciones().filter(l => l.estado !== 'Pagada');
      if (pendientes.length) out.push({ k: 'info', texto: pendientes.length + ' liquidación(es) pendiente(s) de pago: ' + pendientes.map(l => l.nombre).slice(0, 3).join(', '), to: '/rrhh/liquidaciones' });
      const sinPagar = planillas().filter(p => p.estado !== 'Pagada');
      if (sinPagar.length) out.push({ k: 'info', texto: sinPagar.length + ' planilla(s) generada(s) sin marcar como pagada(s): ' + sinPagar.map(p => p.numero).slice(0, 4).join(', '), to: '/rrhh/planilla' });
      // 4.21: cumpleaños y aniversarios de ingreso de hoy y los próximos 7 días (informativos, al final). Más de 2 van en un solo aviso
      const en7 = new Date(h + 'T00:00:00'); en7.setDate(en7.getDate() + 7);
      const lim7 = `${en7.getFullYear()}-${String(en7.getMonth() + 1).padStart(2, '0')}-${String(en7.getDate()).padStart(2, '0')}`, dia = f => (f === h ? 'hoy' : 'el ' + fecha(f));
      const proximos = campo => this.activos.filter(r => /^\d{4}-\d{2}-\d{2}$/.test(String(r[campo] || ''))).map(r => ({ r, f: ocurrencia(r[campo].slice(5), h, lim7) })).filter(x => x.f).sort((a, b) => a.f.localeCompare(b.f));
      const juntos = (l, titulo) => ({ k: 'info', texto: l.length + ' ' + titulo + ' en los próximos 7 días: ' + l.slice(0, 5).map(x => x.r.nombre_completo + ' (' + dia(x.f) + ')').join(', ') + (l.length > 5 ? ' y ' + (l.length - 5) + ' más' : ''), to: '/rrhh/informes?ver=indicadores' });
      const cumples = proximos('nacimiento'), anivs = proximos('fecha_ingreso').map(x => ({ ...x, anios: +x.f.slice(0, 4) - +x.r.fecha_ingreso.slice(0, 4) })).filter(x => x.anios >= 1);
      if (cumples.length > 2) out.push(juntos(cumples, 'cumpleaños'));
      else for (const x of cumples) out.push({ k: 'info', texto: x.r.nombre_completo + ' cumple años ' + dia(x.f), to: '/rrhh/informes?ver=indicadores' });
      if (anivs.length > 2) out.push(juntos(anivs, 'aniversarios de ingreso'));
      else for (const x of anivs) out.push({ k: 'info', texto: x.r.nombre_completo + ' cumple ' + x.anios + (x.anios === 1 ? ' año' : ' años') + ' en la empresa ' + dia(x.f), to: '/rrhh/informes?ver=indicadores' });
      // 4.22: si no caben todos en el tope, primero lo vencido, después lo que hay que revisar y al final lo informativo (dentro de
      // cada grupo, en el orden de siempre): un documento vencido ya no queda fuera por los avisos de «no tiene correo»
      if (out.length > 12) { const peso = { err: 0, warn: 1 }; out.sort((a, b) => (peso[a.k] ?? 2) - (peso[b.k] ?? 2)); }
      return out.slice(0, 12);
    },
  },
  methods: {
    money, fecha,
    async cargar() { this.lista = empleados(); try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
    eliminar(e) {
      if (planillas().some(p => (p.filas || []).some(f => f.empleado_id === e.id))) return toast(nombreCompleto(e) + ' aparece en planillas guardadas: márquelo inactivo (o liquídelo) en lugar de eliminarlo, para conservar el historial', 'err');
      // 4.22: con la ficha se van, en el servidor, sus documentos (con sus archivos) y sus acciones de personal: se dice antes de eliminar
      if (!confirm('¿Eliminar a ' + nombreCompleto(e) + ' del registro? Con la ficha se eliminan también sus documentos guardados y sus acciones de personal, y no se pueden recuperar. Si salió de la empresa, use Liquidaciones para dejar constancia y márquelo inactivo.')) return;
      // se quita de lo guardado más reciente, no de la copia de esta pantalla (que pudo quedar sin un empleado que agregó otra persona)
      this.lista = empleados().filter(x => x.id !== e.id); guardarEmpleados(this.lista); toast('Empleado eliminado');
    },
    async documento(formato) {
      const M = v => money(v || 0);
      const cols = [{ key: 'nombre_completo', label: 'Empleado' }, { key: 'numero_id', label: 'Identificación' }, { key: 'puesto', label: 'Puesto' }, { key: 'ingreso', label: 'Ingreso' }, { key: 'periodo', label: 'Pago' }, { key: 'mensual', label: 'Salario mensual', num: true }, { key: 'costo', label: 'Costo mensual', num: true }, { key: 'vac', label: 'Vacaciones', num: true }, { key: 'estado', label: 'Estado' }];
      const rows = this.rows.map(r => ({ nombre_completo: r.nombre_completo, numero_id: r.numero_id || '', puesto: [r.puesto, r.departamento].filter(Boolean).join(' · '), ingreso: fecha(r.fecha_ingreso), periodo: r.periodo, mensual: M(r.mensual), costo: M(r.costo), vac: r.vac_saldo + ' d', estado: r.estado }));
      try { await descargarReporte(formato, { titulo: 'Empleados', subtitulo: 'Registro del personal con salario mensual, costo estimado (bruto + ' + this.pct.patronal.toFixed(2) + ' % patronal + ' + this.pct.provisiones.toFixed(2) + ' % de reserva) y saldo de vacaciones.', periodo: 'Al ' + fecha(hoy()), kpis: [{ t: 'Empleados activos', v: String(this.activos.length) }, { t: 'Salarios brutos al mes', v: M(this.totBruto) }, { t: 'Cargas y reservas', v: M(this.totCosto - this.totBruto) }, { t: 'Costo total mensual', v: M(this.totCosto) }], cols, rows, totales: [{ t: 'Salarios brutos (activos)', v: M(this.totBruto) }, { t: 'Costo mensual (activos)', v: M(this.totCosto) }], archivo: 'empleados', privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
    csv(formato) { descargarTabla(formato === 'xlsx' ? 'xlsx' : 'csv', 'empleados', [{ key: 'nombre_completo', label: 'Empleado' }, { key: 'numero_id', label: 'Identificación' }, { key: 'puesto', label: 'Puesto' }, { key: 'departamento', label: 'Departamento' }, { key: 'correo', label: 'Correo' }, { key: 'telefono', label: 'Teléfono' }, { key: 'fecha_ingreso', label: 'Ingreso' }, { key: 'periodo', label: 'Pago' }, { key: 'mensual', label: 'Salario mensual' }, { key: 'costo', label: 'Costo mensual' }, { key: 'vac_saldo', label: 'Vacaciones' }, { key: 'estado', label: 'Estado' }], this.rows, { titulo: 'Empleados', registrar: a => registrarExportable(a, 'Empleados', true) }); },   // 4.21: al historial de Recursos humanos (correos, teléfonos y salarios)
    // 4.21: constancia salarial (PDF o Word) de un empleado: meses del promedio y quién firma
    abrirConstancia(e) { this.constancia = { e, meses: 6, firmaNombre: '', firmaCargo: '' }; },
    async emitirConstancia(formato) {
      const c = this.constancia;
      if (!c || this.generando) return;
      this.generando = true;
      try { await constanciaSalarial(c.e, c, formato, descargarReporte, money, fecha); } catch (e) { toast(e.message, 'err'); }
      this.generando = false;
    },
    // 4.21: importar empleados NUEVOS desde un Excel (.xlsx) o un CSV de hasta 2 MB y 500 filas. El servidor revisa el archivo (formato
    // de la identificación y del IBAN, fechas, números, repetidos) y devuelve la vista previa; al importar lo vuelve a revisar y agrega
    // solo las filas sin errores. El archivo no se guarda en ninguna parte.
    abrirImportar() { this.imp = { archivo: null, nombre: '', vista: null, cargando: false, hecho: null }; },
    cerrarImportar() { if (this.imp && !this.imp.cargando) this.imp = null; },
    claseEstado(estado) { return estado === 'Con errores' ? 'danger' : estado === 'Con avisos' ? 'warn' : 'ok'; },
    elegirArchivo(ev) {
      const f = ev.target.files && ev.target.files[0], i = this.imp;
      if (!i) return;
      i.archivo = null; i.nombre = ''; i.vista = null; i.hecho = null;
      if (!f) return;
      if (!/\.(xlsx|csv)$/i.test(f.name)) { ev.target.value = ''; return toast('Elija un archivo de Excel (.xlsx) o un CSV (.csv)', 'err'); }
      if (f.size > 2 * 1024 * 1024) { ev.target.value = ''; return toast('El archivo pasa de 2 MB: divídalo en varios (hasta 500 empleados por archivo)', 'err'); }
      i.archivo = f; i.nombre = f.name;
    },
    // La plantilla: en Excel o CSV, los encabezados y una fila de ejemplo ficticia (el servidor nunca la importa); en PDF, la guía de las columnas
    plantilla(formato) {
      const guia = formato !== 'xlsx' && formato !== 'csv', cols = guia ? [{ key: 'columna', label: 'Columna' }, { key: 'obligatoria', label: 'Obligatoria' }, { key: 'contenido', label: 'Qué lleva' }, { key: 'ejemplo', label: 'Ejemplo' }] : COLUMNAS_IMPORTAR.map(c => ({ key: c[0], label: c[0] }));
      const rows = guia ? COLUMNAS_IMPORTAR.map(c => ({ columna: c[0], obligatoria: c[1] ? 'Sí' : '', contenido: c[2], ejemplo: c[3] })) : [Object.fromEntries(COLUMNAS_IMPORTAR.map(c => [c[0], c[3]]))];
      return descargarTabla(formato, guia ? 'plantilla_empleados_guia' : 'plantilla_empleados', cols, rows, { titulo: 'Plantilla de empleados', registrar: a => registrarExportable(a, 'Plantilla de empleados', true) });
    },
    async enviarArchivo(confirmar) {
      const fd = new FormData(); fd.append('archivo', this.imp.archivo); fd.append('confirmar', confirmar ? 'true' : 'false');
      return api('/api/rrhh/empleados/importar', { method: 'POST', body: fd });
    },
    async revisar() {
      const i = this.imp;
      if (!i || i.cargando) return;
      if (!i.archivo) return toast('Elija primero el archivo', 'err');
      i.cargando = true; i.hecho = null;
      try { i.vista = await this.enviarArchivo(false); } catch (e) { i.vista = null; toast(e.message, 'err'); }
      i.cargando = false;
    },
    async importar() {
      const i = this.imp;
      if (!i || i.cargando || !i.archivo || !i.vista || !i.vista.validas || i.hecho !== null) return;   // ya importado: para repetir se revisa de nuevo el archivo
      if (!confirm('¿Importar ' + i.vista.validas + (i.vista.validas === 1 ? ' empleado nuevo' : ' empleados nuevos') + '?' + (i.vista.con_error ? (i.vista.con_error === 1 ? ' La fila con errores no se importa.' : ' Las ' + i.vista.con_error + ' filas con errores no se importan.') : ''))) return;
      i.cargando = true;
      try {
        const r = await this.enviarArchivo(true);
        i.vista = r; i.hecho = r.importados;
        toast(r.importados ? r.importados + (r.importados === 1 ? ' empleado importado' : ' empleados importados') + ': revise sus fichas' : 'No se importó ningún empleado: revise los mensajes de cada fila', r.importados ? 'ok' : 'err');
      } catch (e) {
        // sin respuesta, la importación pudo hacerse igual: se trae la lista y no se da por rechazada. Repetirla no duplica: quien ya entró sale «ya existe»
        toast(e.status && e.status < 500 ? e.message : 'No se pudo confirmar la importación (' + e.message + '). Revise la lista de empleados antes de repetirla: quien ya entró saldrá como «ya existe» al revisar de nuevo el archivo', 'err');
      }
      await mock.refrescar(['empleados']).catch(() => false);
      this.lista = empleados();
      i.cargando = false;
    },
    // Lo que hay que corregir en el archivo (filas con errores o con avisos), al historial de Recursos humanos: lleva nombres e identificaciones
    exportarErrores(formato) {
      const cols = [{ key: 'fila', label: 'Fila del archivo' }, { key: 'nombre', label: 'Empleado' }, { key: 'numero_id', label: 'Identificación' }, { key: 'tipo', label: 'Tipo' }, { key: 'mensaje', label: 'Qué corregir o revisar' }];
      // un renglón por mensaje: el PDF recorta cada celda a 200 letras y así ninguno se pierde
      const rows = this.filasConMensajes.flatMap(f => [...(f.errores || []).map(m => ['Error', m]), ...(f.avisos || []).map(m => ['Aviso', m])].map(([tipo, mensaje]) => ({ fila: String(f.fila), nombre: f.nombre, numero_id: f.numero_id, tipo, mensaje })));
      if (!rows.length) return toast('El archivo no tiene errores ni avisos', 'ok');
      return descargarTabla(formato, 'importacion_empleados_revision', cols, rows, { titulo: 'Importación de empleados: filas por corregir', registrar: a => registrarExportable(a, 'Importación de empleados: filas por corregir', true) });
    },
  },
  created() { this.cargar(); if (sesion.puede('usuarios')) api('/api/auth/usuarios').then(u => { this.usuarios = u; }).catch(() => { this.usuarios = null; }); },   // usuario web (3.71); 3.87: solo quien administra usuarios
  template: `
  <div class="page">
    <PageHead title="Empleados" sub="Registro del personal: datos generales, contrato, puesto según la tabla del MTSS, jornada, salario y forma de pago.">
      <button class="btn sec" @click="documento('pdf')" :disabled="!rows.length">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!rows.length">⤓ Word</button><button class="btn ghost" @click="csv('xlsx')" :disabled="!rows.length">⤓ Excel</button><button class="btn ghost" @click="csv" :disabled="!rows.length">⤓ CSV</button>
      <a class="btn sec" href="#/rrhh/informes?ver=indicadores" title="Costo por departamento, ausentismo, rotación, cumpleaños y aniversarios">Indicadores</a><a class="btn sec" href="#/rrhh/planilla">Planilla</a><button class="btn sec" @click="abrirImportar" title="Agregar empleados nuevos desde un archivo de Excel o CSV">Importar</button><a class="btn" href="#/rrhh/empleados/nuevo">+ Nuevo empleado</a>
    </PageHead>
    <div class="dash" style="margin-bottom:18px">
      <div class="kpi w3"><div class="t">Empleados activos</div><div class="v">{{activos.length}}</div></div>
      <div class="kpi w3"><div class="t">Salarios brutos al mes</div><div class="v">{{money(totBruto)}}</div></div>
      <div class="kpi w3"><div class="t">Cargas patronales y provisiones</div><div class="v">{{money(totCosto - totBruto)}}</div><div class="d">{{pct.patronal.toFixed(2)}} % patronal + {{pct.provisiones.toFixed(2)}} % reserva</div></div>
      <div class="kpi w3"><div class="t">Costo total mensual</div><div class="v">{{money(totCosto)}}</div></div>
    </div>
    <div class="card" v-if="avisos.length"><h2>Requiere atención <small>{{avisos.length}} aviso(s)</small></h2>
      <div v-for="(a,i) in avisos" :key="i" class="alert" :class="a.k === 'err' ? 'err' : a.k === 'warn' ? 'warn' : 'info'" style="margin-bottom:6px;display:flex;justify-content:space-between;gap:10px;align-items:center"><span>{{a.texto}}</span><a class="btn sm ghost" :href="'#' + a.to">Ver</a></div>
    </div>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar por nombre, cédula o puesto" v-model="q"><div class="seg"><button :class="{on:estado==='activos'}" @click="estado='activos'">Activos</button><button :class="{on:estado==='inactivos'}" @click="estado='inactivos'">Inactivos</button><button :class="{on:estado==='todos'}" @click="estado='todos'">Todos</button></div></div>
      <DataTable :rows="rows" :columns="columns" :search="q" empty-title="Aún no hay empleados" empty-text="Registre a su personal para calcular planilla, vacaciones, cargas sociales y liquidaciones.">
        <template #actions="{row}"><a class="btn sm sec" :href="'#/rrhh/empleados/'+row.id">Editar</a><a class="btn icon" :href="'#/rrhh/empleados/nuevo?duplicar='+row.id" title="Duplicar: nuevo empleado con el mismo puesto, jornada, salario y departamento">⧉</a><a class="btn sm ghost" :href="'#/rrhh/acciones?empleado='+row.id" title="Acciones de personal: aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y salida">Acciones</a><a class="btn sm ghost" :href="'#/rrhh/liquidaciones?empleado='+row.id" v-if="row.activo!==false">Liquidar</a><button class="btn sm ghost" title="Constancia salarial en PDF o Word: salario actual y promedio de los últimos meses" @click.stop="abrirConstancia(row)">Constancia</button><button class="btn icon" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
        <template #empty><a class="btn" href="#/rrhh/empleados/nuevo">+ Nuevo empleado</a></template>
      </DataTable>
    </div>
    <Modal v-if="constancia" :title="'Constancia salarial · ' + constancia.e.nombre_completo" @close="constancia=null">
      <div class="grid cols-2">
        <Field label="Meses del promedio" help="Promedio del salario bruto según las planillas pagadas" style="grid-column:1/-1"><select v-model.number="constancia.meses"><option :value="3">Últimos 3 meses</option><option :value="6">Últimos 6 meses</option><option :value="12">Últimos 12 meses</option></select></Field>
        <Field label="Firma: nombre" help="Opcional: quien firma la constancia"><input v-model="constancia.firmaNombre" maxlength="90"></Field>
        <Field label="Firma: cargo" help="Opcional"><input v-model="constancia.firmaCargo" maxlength="90" placeholder="Ej. Gerente general"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Lleva los datos del trabajador, su salario bruto mensual actual, el promedio de los últimos meses según las planillas pagadas, la fecha de emisión y la línea de firma. El texto es general: revise si quien la pide exige otro formato.</p>
      <template #foot><button class="btn ghost" @click="constancia=null">Cerrar</button><button class="btn sec" :disabled="generando" @click="emitirConstancia('pdf')">⤓ PDF</button><button class="btn sec" :disabled="generando" @click="emitirConstancia('docx')">⤓ Word</button></template>
    </Modal>
    <Modal v-if="imp" title="Importar empleados" lg @close="cerrarImportar">
      <p class="small muted" style="margin:0 0 10px">Agrega empleados NUEVOS; no cambia a los que ya existen. Descargue la plantilla, llene una fila por empleado y suba el archivo: Excel (.xlsx) o CSV, de hasta 2 MB y 500 filas. El archivo se revisa y se descarta: no queda guardado.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center"><span class="small">Plantilla:</span><button class="btn sm sec" @click="plantilla('xlsx')">⤓ Excel</button><button class="btn sm sec" @click="plantilla('csv')">⤓ CSV</button><button class="btn sm ghost" @click="plantilla('pdf')" title="Guía de las columnas: qué lleva cada una y un ejemplo">⤓ PDF (guía de columnas)</button></div>
      <Field label="Archivo con los empleados" help="No cambie la fila de encabezados de la plantilla. Borre la fila de ejemplo."><input type="file" accept=".xlsx,.csv" @change="elegirArchivo" :disabled="imp.cargando"></Field>
      <template v-if="imp.vista">
        <div class="row" style="gap:8px;flex-wrap:wrap;margin:12px 0 8px"><span class="chip on" style="cursor:default" v-if="imp.hecho !== null">Importados: <b>{{imp.hecho}}</b></span><span class="chip" style="cursor:default">Filas: <b>{{filasVista.length}}</b></span><span class="chip" style="cursor:default">Sin errores: <b>{{imp.vista.validas}}</b></span><span class="chip" style="cursor:default">Con avisos: <b>{{imp.vista.con_avisos}}</b></span><span class="chip" style="cursor:default">Con errores: <b>{{imp.vista.con_error}}</b></span></div>
        <div class="alert info" v-if="avisoPlanImportar" style="margin-bottom:8px">{{avisoPlanImportar}}</div>
        <div class="alert warn" v-if="imp.vista.columnas_ignoradas && imp.vista.columnas_ignoradas.length" style="margin-bottom:8px">Columnas del archivo que no se usan (no están en la plantilla): {{imp.vista.columnas_ignoradas.join(', ')}}.</div>
        <div class="table-wrap" style="max-height:340px;overflow:auto"><table class="tbl"><thead><tr><th>Fila</th><th>Empleado</th><th>Identificación</th><th>Estado</th><th>Qué corregir o revisar</th></tr></thead>
          <tbody><tr v-for="f in filasVista" :key="f.fila"><td>{{f.fila}}</td><td>{{f.nombre}}</td><td class="mono">{{f.numero_id}}</td><td><span class="badge" :class="claseEstado(f.estado)">{{f.estado}}</span></td><td class="small" style="white-space:normal"><div v-for="(m,i) in f.mensajes" :key="i">{{m}}</div></td></tr></tbody></table></div>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center" v-if="filasConMensajes.length"><span class="small">Lista de lo que hay que corregir:</span><button class="btn sm sec" @click="exportarErrores('pdf')">⤓ PDF</button><button class="btn sm ghost" @click="exportarErrores('xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportarErrores('csv')">⤓ CSV</button></div>
        <p class="small muted" style="margin:8px 0 0" v-if="imp.hecho === null && imp.vista.con_error">Las filas con errores no se importan: corríjalas en el archivo y súbalo otra vez (las que ya entraron saldrán como «ya existe»), o importe solo las que están bien.</p>
        <p class="small muted" style="margin:8px 0 0" v-if="imp.hecho !== null">Quedó en el historial de operaciones cuántos empleados se importaron. Revise las fichas: la importación no crea usuarios web ni acciones de personal.</p>
      </template>
      <template #foot><button class="btn ghost" :disabled="imp.cargando" @click="cerrarImportar">Cerrar</button><button class="btn sec" :disabled="imp.cargando || !imp.archivo" @click="revisar">{{imp.cargando && !imp.vista ? 'Revisando…' : 'Revisar'}}</button><button class="btn" :disabled="imp.cargando || !imp.vista || !imp.vista.validas || imp.hecho !== null" @click="importar">{{imp.cargando && imp.vista ? 'Importando…' : textoImportar}}</button></template>
    </Modal>
  </div>`,
};
