// Recursos humanos › Empleado (nuevo o edición). El panel de la derecha muestra en vivo el cálculo del servidor: salario del período,
// deducciones del trabajador (CCSS y renta), costo patronal, reserva mensual y vacaciones acumuladas.
import { api, money, fmt, fecha, fechaHora, toast, mock, CAT, opts, hoy, claveFacil, verDocumento } from '../../api.js';
import { sesion } from '../../app.js';
import { empleados, guardarEmpleados, empleadoNuevo, PERIODOS, JORNADAS, HORAS_JORNADA, tablas, paraServidor, diasDisfrutados, nombreCompleto, fichaEmpleado, constanciaSalarial, TIPOS_CONTRATO, conceptos, ausencias, salarioMensual, departamentos, accionesDe, tipoAccion, accionDeFicha, registrarAccionDeFicha } from './_datos.js';
import { documentosDe, TIPOS_DOCUMENTO, tipoDocumento, MAX_BYTES_DOCUMENTO, tamanoArchivo, vencimientos } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() {
    const lista = empleados(); const id = this.params && this.params.id && this.params.id !== 'nuevo' ? +this.params.id : null;
    const ex = id ? lista.find(e => e.id === id) : null;
    // Duplicar (3.43): mismo puesto, jornada, salario, departamento y forma de pago; sin nombre, identificación, cuenta, código de reloj, usuario web ni historial
    const base = !ex && this.params && this.params.duplicar ? lista.find(e => e.id === +this.params.duplicar) : null;
    const copia = base ? { ...empleadoNuevo(), ...JSON.parse(JSON.stringify(base)), id: null, nombre: '', apellidos: '', apellido1: '', apellido2: '', numero_id: '', nacimiento: '', correo: '', usuario_correo: '', telefono: '', direccion: '', emergencia_nombre: '', emergencia_telefono: '',
                           hijos: 0, conyuge: false, cuenta_iban: '', codigo_reloj: '', fecha_ingreso: hoy(), fecha_salida: '', activo: true, notas: '', vence_id: '', vence_permiso: '', historial: [] } : null;
    return { usuarios: null, roles: [], acceso: { rol: 'Vendedor', password: '' }, creandoAcceso: false,   // usuario web del empleado (3.71)
             docs: ex ? documentosDe(ex.id) : [], subiendo: false, nuevoDoc: { tipo: 'contrato', nombre: '', vence: '', archivo: null }, claveArchivo: 0, docEdit: null, TIPOS_DOCUMENTO,   // documentos del empleado (4.22)
             lista, e: ex ? { ...empleadoNuevo(), ...ex, historial: Array.isArray(ex.historial) ? ex.historial : [] } : (copia || empleadoNuevo()), editando: !!ex, duplicadoDe: base ? nombreCompleto(base) : '', t: null, calc: null, calcError: '', timer: null, guardando: false, generando: false, constancia: null, bitacora: null, CAT, opts, PERIODOS, JORNADAS, TIPOS_CONTRATO };
  },
  computed: {
    puedeUsuarios() { return sesion.puede('usuarios'); },
    // usuario web del empleado (3.71): el que tenga su correo (o el correo de acceso que se le vinculó al crearlo)
    usuarioWeb() { const c = String(this.e.usuario_correo || this.e.correo || '').trim().toLowerCase(); return c && this.usuarios ? (this.usuarios.find(u => u.correo === c) || null) : null; },
    nConceptos() { return this.e.id ? conceptos().filter(c => c.empleado_id === this.e.id && c.activa !== false).length : 0; },
    nAusencias() { return this.e.id ? ausencias().filter(a => a.empleado_id === this.e.id).length : 0; },
    // 4.21: acciones de personal de este empleado, y su historial de puesto y departamento: el ingreso, los traslados y los cambios
    // de puesto que no estén anulados (no se guarda otra lista en la ficha: Duplicar no copia nada)
    accionesEmp() { return this.editando && this.e.id ? accionesDe(this.e.id) : []; },
    historialPuesto() {
      const cambio = (x, y) => (x && x !== y ? x + ' → ' : '') + (y || '—');
      return this.accionesEmp.filter(a => a.estado !== 'Anulada' && ['ingreso', 'traslado', 'cambio_puesto'].includes(a.tipo)).sort((a, b) => String(b.rige).localeCompare(String(a.rige)) || String(b.numero).localeCompare(String(a.numero)))
        .map(a => { const an = a.antes || {}, de = a.despues || {}, ingreso = a.tipo === 'ingreso'; return { id: a.id, rige: a.rige, accion: a.numero + ' · ' + tipoAccion(a.tipo), puesto: ingreso ? de.puesto || '—' : cambio(an.puesto, de.puesto), departamento: ingreso ? de.departamento || '—' : cambio(an.departamento, de.departamento), pendiente: !ingreso && !a.aplicada_a_ficha }; });
    },
    contratoVence() { if (this.e.tipo_contrato === 'indefinido' || !this.e.fecha_fin_contrato) return null; const d = Math.round((new Date(this.e.fecha_fin_contrato + 'T00:00:00') - new Date(hoy() + 'T00:00:00')) / 86400000); return d; },
    // 4.22: los documentos de la ficha como los muestra la tabla y los lleva la exportación (por tipo y, dentro de cada tipo, el más
    // reciente primero), y los avisos de las dos fechas de vencimiento de la ficha: vencida o a 30 días o menos de vencer.
    // En la tabla de pantalla quien lo subió va en el title de la fecha y los tres botones en una sola línea (con la columna «Subido
    // por» la tabla no cabía: los botones se apilaban y el nombre se partía en cuatro renglones); la exportación sí lleva la columna
    docsFilas() {
      const orden = TIPOS_DOCUMENTO.map(t => t[0]);
      return this.docs.slice().sort((a, b) => orden.indexOf(a.tipo) - orden.indexOf(b.tipo) || String(b.subido_en || '').localeCompare(String(a.subido_en || ''))).map(d => {
        const v = vencimientos(null, 30, [d])[0];
        return { ...d, tipo_nombre: tipoDocumento(d.tipo), vence_texto: d.vence ? fecha(d.vence) : '—', estado: v ? (v.vencido ? 'Vencido' : 'Por vencer') : '', tamano: tamanoArchivo(d.bytes), subido: fecha(d.subido_en) };
      });
    },
    avisosVence() { return vencimientos({ vence_id: this.e.vence_id, vence_permiso: this.e.vence_permiso }, 30, []).map(v => ({ k: v.vencido ? 'err' : 'warn', texto: v.que + ': ' + (v.vencido ? 'venció el ' : 'vence el ') + fecha(v.fecha) })); },
    puestos() { return this.t ? this.t.puestos : []; },
    deptos() { return departamentos().filter(d => d.activo !== false || d.id === this.e.departamento_id).map(d => ({ id: d.id, nombre: d.nombre })); },
    categorias() { return this.t ? this.t.efectivos.categorias : []; },
    categoria() { return this.categorias.find(c => c.codigo === this.e.categoria); },
    minimo() { return this.calc ? this.calc.minimo_mensual : null; },
    bajoMinimo() { return this.calc && this.minimo && this.calc.salario_mensual + 0.5 < this.minimo; },
    periodoPrev() { return this.e.periodo_pago === 'manual' ? 'mensual' : this.e.periodo_pago; },
    // 4.21: ¿lo que hay en pantalla difiere de la ficha guardada? La constancia sale siempre con lo guardado, y su cuadro lo avisa
    cambiosSinGuardar() { const g = this.lista.find(x => x.id === this.e.id); return !!g && JSON.stringify({ ...empleadoNuevo(), ...g, historial: this.e.historial }) !== JSON.stringify(this.e); },
  },
  watch: {
    'e.jornada'(v) { if (HORAS_JORNADA[v]) this.e.horas_semana = HORAS_JORNADA[v]; },
    'e.puesto'(v) { const p = this.puestos.find(x => x.nombre === v); if (p) this.e.categoria = p.categoria; },
    e: { deep: true, handler() { this.programar(); } },
  },
  methods: {
    money, fmt, nombreCompleto,
    // Ficha del empleado en PDF o Word: datos, mes completo, período de pago elegido y vacaciones
    async ficha(formato) {
      if (!(+this.e.salario_hora > 0 || +this.e.salario_mensual > 0)) return toast('Indique el salario para generar la ficha', 'err');
      this.generando = true;
      try { await fichaEmpleado(this.e, this.t, formato, descargarReporte, money, fmt, fecha); } catch (err) { toast(err.message, 'err'); }
      this.generando = false;
    },   /* el template la usa en las migas: sin exponerla, editar un empleado no cargaba */
    // 4.21: constancia salarial (PDF o Word): salario bruto actual, promedio de los últimos meses según las planillas pagadas y firma
    async emitirConstancia(formato) {
      if (!this.constancia || this.generando) return;
      this.generando = true;
      try { await constanciaSalarial(this.e, this.constancia, formato, descargarReporte, money, fecha); } catch (err) { toast(err.message, 'err'); }
      this.generando = false;
    },
    // 4.21: bitácora de la ficha: quién y cuándo cambió el salario, la cuenta, la forma de pago, los datos de renta o el % de riesgos
    // (la anota el servidor al guardar; dice qué cambió, no los valores). Solo de una ficha ya guardada.
    async cargarBitacora() {
      if (!this.editando) return;
      try { this.bitacora = (await api('/api/rrhh/empleados/' + this.e.id + '/bitacora')).map(b => ({ ...b, cuando: fechaHora(b.fecha), usuario: b.correo || '—', cambio: this.textoBitacora(b) })); } catch { this.bitacora = null; }
    },
    textoBitacora(b) {
      const d = String(b.detalle || ''), i = d.indexOf(': ');
      return b.accion === 'rrhh_ficha_creada' ? 'Ficha creada' : b.accion === 'rrhh_ficha_eliminada' ? 'Ficha eliminada' : 'Cambió: ' + (i >= 0 ? d.slice(i + 2) : d);
    },
    async exportarBitacora(formato) {
      const cols = [{ key: 'cuando', label: 'Fecha' }, { key: 'usuario', label: 'Usuario' }, { key: 'cambio', label: 'Cambio' }], rows = this.bitacora || [], titulo = 'Bitácora de ' + nombreCompleto(this.e);
      if (!rows.length) return;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'empleado_bitacora_' + (this.e.numero_id || this.e.id), cols, rows, { titulo, registrar: a => registrarExportable(a, titulo, true) });
      await descargarReporte(formato, { titulo: titulo.slice(0, 120), subtitulo: 'Cambios de salario, cuenta bancaria, forma de pago, datos de renta y riesgos del trabajo en la ficha. Dice quién y cuándo los hizo; los montos de antes y después están en el historial de salario.', periodo: 'Al ' + fecha(hoy()), cols, rows, archivo: 'empleado_bitacora_' + (this.e.numero_id || this.e.id), privado: true });
    },
    // 4.22: el historial de puesto y departamento también se exporta (toda lista sale en PDF, Excel y CSV), con lo que muestra la
    // tarjeta; la acción que sigue pendiente de aplicar lo dice junto a su número. Va al historial de descargas de Recursos humanos
    async exportarHistorialPuesto(formato) {
      const cols = [{ key: 'rige', label: 'Rige', fmt: 'date' }, { key: 'accion', label: 'Acción' }, { key: 'puesto', label: 'Puesto' }, { key: 'departamento', label: 'Departamento' }];
      const rows = this.historialPuesto.map(h => ({ ...h, accion: h.accion + (h.pendiente ? ' (pendiente de aplicar)' : '') })), titulo = 'Historial de puesto y departamento de ' + nombreCompleto(this.e), archivo = 'empleado_historial_puesto_' + (this.e.numero_id || this.e.id);
      if (!rows.length) return;
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, archivo, cols, rows, { titulo, registrar: a => registrarExportable(a, titulo, true) });
      await descargarReporte(formato, { titulo: titulo.slice(0, 120), subtitulo: 'Ingreso, traslados y cambios de puesto del empleado según sus acciones de personal, del más reciente al más antiguo. Las acciones anuladas no aparecen.', periodo: 'Al ' + fecha(hoy()), cols, rows, archivo, privado: true });
    },
    // ---- documentos del empleado (4.22). Los sube, los guarda y los borra el servidor (cada uno con su archivo): la pantalla nunca
    // escribe el registro rrhh_documentos, solo lo vuelve a leer después de cada cambio. Solo en una ficha ya guardada.
    async cargarDocs() {
      if (!this.editando) return;
      try { await mock.refrescar(['rrhh_documentos']); } catch { /* sin conexión: queda lo que ya tenía la pestaña */ }
      this.docs = documentosDe(this.e.id);
    },
    elegirDoc(ev) {
      const f = ev.target.files && ev.target.files[0];
      this.nuevoDoc.archivo = null;
      if (!f) return;
      if (f.size > MAX_BYTES_DOCUMENTO) { ev.target.value = ''; return toast('El archivo supera 5 MB: redúzcalo antes de subirlo', 'err'); }
      if (!['application/pdf', 'image/jpeg', 'image/png'].includes(f.type) && !/\.(pdf|jpe?g|png)$/i.test(f.name)) { ev.target.value = ''; return toast('Solo se admiten archivos PDF, JPG o PNG', 'err'); }
      this.nuevoDoc.archivo = f;
      if (!this.nuevoDoc.nombre.trim()) this.nuevoDoc.nombre = String(f.name || '').replace(/\.[^.]+$/, '').slice(0, 120);
    },
    async subirDoc() {
      const n = this.nuevoDoc;
      if (this.subiendo || !this.editando) return;
      if (!n.archivo) return toast('Elija el archivo: PDF, JPG o PNG, de hasta 5 MB', 'err');
      const fd = new FormData(); fd.append('archivo', n.archivo); fd.append('tipo', n.tipo); fd.append('nombre', n.nombre.trim().slice(0, 120)); fd.append('vence', n.vence || '');
      const antes = new Set(this.docs.map(d => d.id)), bytes = n.archivo.size;
      let ok = false, error = null;
      this.subiendo = true;
      try { await api('/api/rrhh/empleados/' + this.e.id + '/documentos', { method: 'POST', body: fd }); ok = true; } catch (err) { error = err; }
      await this.cargarDocs();
      // sin respuesta (red caída o error del servidor) el documento pudo guardarse igual: se decide con lo que quedó en el servidor,
      // para que no se suba dos veces
      if (!ok && (!error.status || error.status >= 500) && this.docs.some(d => !antes.has(d.id) && d.tipo === n.tipo && d.bytes === bytes)) ok = true;
      this.subiendo = false;
      if (!ok) return toast(error.message, 'err');
      this.nuevoDoc = { tipo: n.tipo, nombre: '', vence: '', archivo: null }; this.claveArchivo++;
      toast('Documento guardado en la ficha de ' + nombreCompleto(this.e), 'ok');
    },
    async verDoc(d) {
      try {
        await verDocumento('/api/rrhh/documentos/' + d.id, d.tipo_nombre + ' · ' + nombreCompleto(this.e));
        registrarExportable((d.nombre || d.tipo_nombre) + '.' + String(d.archivo || '').split('.').pop(), 'Documento de ' + nombreCompleto(this.e), true);
      } catch (err) { toast(err.message, 'err'); }
    },
    async guardarDoc() {
      const x = this.docEdit;
      if (!x || x.guardando) return;
      if (!String(x.nombre || '').trim()) return toast('Indique el nombre del documento', 'err');
      x.guardando = true;
      try { await api('/api/rrhh/documentos/' + x.id, { method: 'PUT', body: { tipo: x.tipo, nombre: String(x.nombre).trim().slice(0, 120), vence: x.vence || '' } }); this.docEdit = null; toast('Documento actualizado', 'ok'); }
      catch (err) { x.guardando = false; toast(err.message, 'err'); }
      await this.cargarDocs();
    },
    async quitarDoc(d) {
      if (!confirm('¿Eliminar «' + (d.nombre || d.tipo_nombre) + '» de la ficha de ' + nombreCompleto(this.e) + '? El archivo se borra del servidor y no se puede recuperar.')) return;
      try { await api('/api/rrhh/documentos/' + d.id, { method: 'DELETE' }); toast('Documento eliminado', 'ok'); } catch (err) { toast(err.message, 'err'); }
      await this.cargarDocs();
    },
    async exportarDocs(formato) {
      const cols = [{ key: 'tipo_nombre', label: 'Tipo' }, { key: 'nombre', label: 'Nombre' }, { key: 'vence_texto', label: 'Vence' }, { key: 'estado', label: 'Aviso' }, { key: 'tamano', label: 'Tamaño' }, { key: 'subido_por', label: 'Subido por' }, { key: 'subido', label: 'Fecha' }];
      const rows = this.docsFilas, titulo = 'Documentos de ' + nombreCompleto(this.e), archivo = 'empleado_documentos_' + (this.e.numero_id || this.e.id);
      if (!rows.length) return toast('Esta ficha todavía no tiene documentos');
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, archivo, cols, rows, { titulo, registrar: a => registrarExportable(a, titulo, true) });
      await descargarReporte(formato, { titulo: titulo.slice(0, 120), subtitulo: 'Lista de los documentos guardados en la ficha (contrato, identificación, permisos, títulos y otros) con su vencimiento. Los archivos se abren desde la ficha del empleado.', periodo: 'Al ' + fecha(hoy()), cols, rows, archivo, privado: true });
    },
    programar() { clearTimeout(this.timer); this.timer = setTimeout(() => this.calcular(), 400); },
    async calcular() {
      if (!(+this.e.salario_hora > 0 || +this.e.salario_mensual > 0)) { this.calc = null; return; }
      try { this.calc = await api('/api/rrhh/calcular', { method: 'POST', body: { empleado: paraServidor(this.e), periodo: this.periodoPrev, dias_vac_disfrutados: this.e.id ? diasDisfrutados(this.e.id) : 0 } }); this.calcError = ''; }
      catch (err) { this.calcError = err.message; }
    },
    // ---- usuario web (3.71)
    async cargarAcceso() {
      if (!this.editando || !this.puedeUsuarios) return;
      try { this.usuarios = await api('/api/auth/usuarios'); } catch { this.usuarios = null; }
      try { this.roles = ((await api('/api/auth/roles')).roles || []).filter(r => !r.sin_caja).map(r => r.rol); } catch { this.roles = ['Vendedor']; }   // 4.5: sin los de solo caja donde no hay punto de venta (como Usuarios de la empresa; el servidor tampoco los asigna)
      if (!this.roles.includes(this.acceso.rol)) this.acceso.rol = this.roles[0] || 'Vendedor';
      this.acceso.password = claveFacil();
    },
    nuevaClave() { this.acceso.password = claveFacil(); },
    // 4.7: con «Primer apellido» y «Segundo apellido» llenos, «Apellidos» (el que usan las listas y los documentos) se arma con ellos; con
    // uno solo, únicamente si «Apellidos» está vacío o trae una sola palabra (así no se pierde un segundo apellido ya escrito)
    unirApellidos() { this.e.apellido1 = String(this.e.apellido1 || '').trim(); this.e.apellido2 = String(this.e.apellido2 || '').trim(); const a = [this.e.apellido1, this.e.apellido2].filter(Boolean); if (a.length === 2 || (a.length === 1 && !/\s/.test(String(this.e.apellidos || '').trim()))) this.e.apellidos = a.join(' '); },
    async crearAcceso() {
      const correo = String(this.e.correo || '').trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) return toast('Ponga el correo del empleado: con él va a entrar al sistema', 'err');
      if ((this.acceso.password || '').length < 12) return toast('La contraseña temporal necesita 12 caracteres; use «Generar»', 'err');
      this.creandoAcceso = true;
      try {
        const r = await api('/api/auth/usuarios', { method: 'POST', body: { correo, nombre: nombreCompleto(this.e), rol: this.acceso.rol, password_temporal: this.acceso.password } });
        this.e.correo = correo; this.e.usuario_correo = correo;
        const i = this.lista.findIndex(x => x.id === this.e.id); if (i >= 0) { this.lista.splice(i, 1, { ...this.lista[i], correo, usuario_correo: correo }); guardarEmpleados(this.lista); }
        // 4.35: la temporal vale si la cuenta es nueva o había quedado sin empresas (r.password_aplica); si no, r.aviso dice por qué no se tocó
        toast(r.password_aplica ? (r.aviso ? r.aviso + ' ' : 'Usuario web creado. ') + 'Entréguele: ' + correo + ' / ' + this.acceso.password + ' (la cambia al entrar)' : (r.aviso || correo + ' ya tenía cuenta: se agregó a esta empresa con su contraseña de siempre'), r.motivo === 'bloqueada' ? 'err' : 'ok');
        await this.cargarAcceso();
      } catch (err) { toast(err.message, 'err'); }
      this.creandoAcceso = false;
    },
    guardar() {
      const e = this.e;
      if (!e.nombre.trim()) return toast('Indique el nombre', 'err');
      if (!e.numero_id.trim()) return toast('Indique la identificación', 'err');
      const antes = this.editando ? this.lista.find(x => x.id === e.id) : null;
      e.numero_id = String(e.numero_id).replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      { const d = departamentos().find(x => x.id === e.departamento_id); if (d) e.departamento = d.nombre; else if (e.departamento_id) e.departamento_id = null; }   /* 3.43: el nombre acompaña al id (listas, CSV, ficha) */
      if (!antes || antes.numero_id !== e.numero_id || antes.tipo_id !== e.tipo_id) {   // estricta solo al escribir o cambiar la identificación (los registros viejos siguen editables)
        if (e.tipo_id === '01' && !/^\d{9}$/.test(e.numero_id)) return toast('La cédula física debe tener 9 dígitos, sin guiones (p. ej. 101110111)', 'err');
        if (e.tipo_id === '03' && !/^\d{11,12}$/.test(e.numero_id)) return toast('El DIMEX debe tener 11 o 12 dígitos', 'err');
      }
      if (e.correo && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.correo.trim())) return toast('El correo no tiene un formato válido', 'err');
      // código del reloj marcador: 1 a 4 dígitos; 1, 01, 001 y 0001 son el mismo y se guarda con ceros a la izquierda (0001)
      const cr = String(e.codigo_reloj ?? '').trim();
      if (cr) {
        if (!/^\d{1,4}$/.test(cr) || +cr === 0) return toast('El código de reloj debe ser un número de 1 a 4 dígitos (por ejemplo 1, 01 o 0001)', 'err');
        e.codigo_reloj = cr.padStart(4, '0');
        const otro = this.lista.find(x => x.id !== e.id && x.codigo_reloj && String(x.codigo_reloj).padStart(4, '0') === e.codigo_reloj);
        if (otro) return toast('El código de reloj ' + e.codigo_reloj + ' ya es de ' + [otro.nombre, otro.apellidos].filter(Boolean).join(' '), 'err');
      } else e.codigo_reloj = '';
      if (!e.fecha_ingreso) return toast('Indique la fecha de ingreso', 'err');
      if (e.fecha_ingreso > hoy() && !confirm('La fecha de ingreso está en el futuro. ¿Guardar de todos modos?')) return;
      if (e.modo_salario === 'hora' ? !(+e.salario_hora > 0) : !(+e.salario_mensual > 0)) return toast('Indique el salario', 'err');
      if (e.tipo_contrato !== 'indefinido' && e.fecha_fin_contrato && e.fecha_fin_contrato < e.fecha_ingreso) return toast('La fecha de fin del contrato no puede ser anterior al ingreso', 'err');
      if (this.lista.some(x => x.id !== e.id && String(x.numero_id || '').toUpperCase() === e.numero_id) && !confirm('Ya hay otro empleado con la identificación ' + e.numero_id + '. ¿Guardar de todos modos?')) return;
      // historial de salario: cada cambio de salario queda con fecha (sirve para el promedio de la liquidación y para revisar aumentos)
      const previo = this.editando ? this.lista.find(x => x.id === e.id) : null;
      const salarioActual = e.modo_salario === 'mensual' ? +e.salario_mensual : +e.salario_hora, salarioPrevio = previo ? (previo.modo_salario === 'mensual' ? +previo.salario_mensual : +previo.salario_hora) : null;
      if (!previo || salarioPrevio !== salarioActual || (previo.modo_salario || 'hora') !== e.modo_salario) {
        e.historial = [...(e.historial || []), { fecha: hoy(), modo: e.modo_salario, salario: salarioActual, mensual: salarioMensual(e), motivo: previo ? 'Cambio de salario' : 'Ingreso' }].slice(-60);
      }
      if (this.bajoMinimo && !confirm('El salario mensual (' + money(this.calc.salario_mensual) + ') está por debajo del mínimo de referencia de la categoría (' + money(this.minimo) + '). ¿Guardar de todos modos?')) return;
      this.guardando = true;
      const lista = empleados();
      if (this.editando) { const i = lista.findIndex(x => x.id === e.id); if (i >= 0) lista.splice(i, 1, { ...e }); else lista.push({ ...e }); }
      else { e.id = mock.nextId(lista, 'empleados'); lista.push({ ...e }); }
      // 4.21: la ficha deja sola su acción de personal: «Ingreso» en un alta y «Traslado» o «Cambio de puesto» solo si cambió el
      // departamento o el puesto (accionDeFicha). Se registra cuando la ficha ya quedó guardada, sin detener la pantalla
      registrarAccionDeFicha(guardarEmpleados(lista), accionDeFicha(previo, e), previo, { ...e }, (sesion.usuario || {}).correo);
      toast('Empleado ' + nombreCompleto(e) + ' guardado', 'ok');
      this.guardando = false;
      location.hash = '/rrhh/empleados';
    },
  },
  async created() { this.cargarBitacora(); this.cargarDocs(); try { this.t = await tablas(); } catch (err) { toast(err.message, 'err'); } this.calcular(); this.cargarAcceso(); },
  template: `
  <div class="page">
    <PageHead :title="editando ? 'Editar empleado' : 'Nuevo empleado'" sub="Datos generales, puesto según la tabla del MTSS, jornada y salario. El sistema calcula deducciones, cargas y reserva mensual." :crumbs="[{label:'Recursos humanos'},{label:'Empleados',to:'/rrhh/empleados'},{label: editando ? nombreCompleto(e) : 'Nuevo'}]">
      <button class="btn sec" :disabled="generando || !calc" @click="ficha('pdf')" title="Ficha del empleado: datos, salario, deducciones y cargas de un mes completo y del período de pago">⤓ Ficha PDF</button><button class="btn sec" :disabled="generando || !calc" @click="ficha('docx')">⤓ Ficha Word</button>
      <button class="btn sec" v-if="editando" :disabled="generando" @click="constancia = { meses: 6, firmaNombre: '', firmaCargo: '' }" title="Constancia salarial en PDF o Word: salario actual y promedio de los últimos meses">Constancia</button>
      <a class="btn sec" v-if="editando" :href="'#/rrhh/empleados/nuevo?duplicar=' + e.id" title="Crear otro empleado con el mismo puesto, jornada, salario y departamento">Duplicar</a>
      <a class="btn ghost" href="#/rrhh/empleados">Cancelar</a><button class="btn" :disabled="guardando" @click="guardar">Guardar</button>
    </PageHead>
    <div class="alert info" v-if="duplicadoDe" style="margin-bottom:12px">Copia de <b>{{duplicadoDe}}</b>: revise los datos y complete el nombre y la identificación. No se guarda nada hasta que pulse Guardar.</div>
    <div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(300px,1fr);gap:16px;align-items:start">
      <div>
        <div class="card"><h2>Datos personales</h2>
          <div class="grid cols-3">
            <Field label="Nombre" req><input v-model="e.nombre"></Field>
            <Field label="Apellidos"><input v-model="e.apellidos"></Field>
            <Field label="Primer apellido" help="Opcional: sale tal cual en los archivos de la CCSS y del INS"><input v-model="e.apellido1" @change="unirApellidos"></Field>
            <Field label="Segundo apellido" help="Opcional: con los dos llenos, «Apellidos» se completa solo"><input v-model="e.apellido2" @change="unirApellidos"></Field>
            <Field label="Fecha de nacimiento"><input type="date" v-model="e.nacimiento"></Field>
            <Field label="Tipo de identificación" req><select v-model="e.tipo_id"><option v-for="o in opts(CAT.tipoId).filter(x=>['01','03','04','05'].includes(x.value))" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
            <Field label="Número de identificación" req><input v-model="e.numero_id" class="mono"></Field>
            <Field label="Nacionalidad"><input v-model="e.nacionalidad"></Field>
            <Field label="Correo"><input type="email" v-model="e.correo"></Field>
            <Field label="Teléfono"><input v-model="e.telefono" maxlength="8"></Field>
            <Field label="Hijos a cargo" help="Crédito fiscal por hijo en la renta"><input type="number" min="0" v-model.number="e.hijos"></Field>
            <Field label="Dirección" style="grid-column:1/-1"><input v-model="e.direccion"></Field>
            <Field label="Contacto de emergencia"><input v-model="e.emergencia_nombre"></Field>
            <Field label="Teléfono de emergencia"><input v-model="e.emergencia_telefono" maxlength="8"></Field>
            <Field label="Cónyuge a cargo" help="Crédito fiscal en la renta"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="e.conyuge"> Sí</label></Field>
            <Field label="Vence la identificación" help="Opcional: el sistema avisa 30 días antes"><input type="date" v-model="e.vence_id"></Field>
            <Field label="Vence el permiso de trabajo o residencia" help="Opcional: el sistema avisa 30 días antes"><input type="date" v-model="e.vence_permiso"></Field>
          </div>
          <div class="alert" :class="a.k" v-for="(a, i) in avisosVence" :key="i" style="margin:10px 0 0">{{a.texto}}: actualice el documento y la fecha.</div>
        </div>
        <div class="card"><h2>Puesto y jornada</h2>
          <div class="grid cols-3">
            <Field label="Puesto" req help="Elija de la lista o escriba el suyo; la categoría fija el salario mínimo de referencia" style="grid-column:span 2"><input v-model="e.puesto" list="puestos-mtss" placeholder="Ej. Recepcionista"><datalist id="puestos-mtss"><option v-for="p in puestos" :key="p.nombre" :value="p.nombre">{{p.categoria}}</option></datalist></Field>
            <Field label="Categoría del decreto de salarios mínimos" req><select v-model="e.categoria"><option v-for="c in categorias" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
            <Field label="Fecha de ingreso" req><input type="date" v-model="e.fecha_ingreso"></Field>
            <Field label="Código de reloj" help="Con este número (1 a 4 dígitos; 1 = 0001) y su clave personal el empleado marca en el quiosco; la clave se asigna en Recursos humanos › Marcas"><input v-model="e.codigo_reloj" class="mono" maxlength="4" inputmode="numeric" placeholder="0001"></Field>
            <Field label="Jornada" req><select v-model="e.jornada"><option v-for="j in JORNADAS" :key="j[0]" :value="j[0]">{{j[1]}}</option></select></Field>
            <Field label="Horas por semana" req><input type="number" min="1" max="72" step="0.5" v-model.number="e.horas_semana"></Field>
            <Field label="Tipo de contrato" req><select v-model="e.tipo_contrato"><option v-for="c in TIPOS_CONTRATO" :key="c[0]" :value="c[0]">{{c[1]}}</option></select></Field>
            <Field label="Fin del contrato" v-if="e.tipo_contrato!=='indefinido'" help="Al vencer, la salida se liquida como «fin de contrato»"><input type="date" v-model="e.fecha_fin_contrato"></Field>
            <Field label="Departamento o área" help="Los horarios de trabajo se arman por departamento"><Buscador v-model="e.departamento_id" :opciones="deptos" agregar="departamento" catalogo="rrhh_departamentos" placeholder="Ej. Recepción, Seguridad, Cocina"></Buscador></Field>
            <Field label="Jefe inmediato"><input v-model="e.supervisor"></Field>
          </div>
          <div class="alert warn" v-if="contratoVence !== null && contratoVence <= 30" style="margin:10px 0 0">{{contratoVence < 0 ? 'El contrato venció hace ' + (-contratoVence) + ' días' : 'El contrato vence en ' + contratoVence + ' días'}}: renuévelo o liquide al empleado (motivo «fin de contrato»).</div>
          <p class="small muted" style="margin:6px 0 0" v-if="categoria">Mínimo de referencia para <b>{{categoria.nombre}}</b>: {{money(categoria.monto)}} por {{categoria.base === 'dia' ? 'día (jornada ordinaria)' : 'mes'}}. Verifique el decreto vigente en Parámetros.</p>
        </div>
        <div class="card"><h2>Salario y pago</h2>
          <div class="grid cols-3">
            <Field label="Cómo se define el salario" req><select v-model="e.modo_salario"><option value="hora">Por hora</option><option value="mensual">Mensual fijo</option></select></Field>
            <Field v-if="e.modo_salario==='hora'" label="Salario por hora" req><input type="number" min="0" step="0.01" v-model.number="e.salario_hora" class="mono"></Field>
            <Field v-else label="Salario mensual" req><input type="number" min="0" step="0.01" v-model.number="e.salario_mensual" class="mono"></Field>
            <Field label="Período de pago" req help="Manual: se indican las horas en cada planilla"><select v-model="e.periodo_pago"><option v-for="p in PERIODOS" :key="p[0]" :value="p[0]">{{p[1]}}</option></select></Field>
            <Field label="Forma de pago"><select v-model="e.forma_pago"><option value="transferencia">Transferencia / depósito</option><option value="efectivo">Efectivo</option><option value="cheque">Cheque</option><option value="sinpe">SINPE Móvil</option></select></Field>
            <Field label="Cuenta IBAN del empleado"><input v-model="e.cuenta_iban" class="mono" placeholder="CR…"></Field>
            <Field label="Riesgos del trabajo (INS) %" help="Vacío = el porcentaje general de Parámetros"><input type="number" min="0" step="0.01" v-model.number="e.ins_riesgos"></Field>
            <Field label="Retener impuesto sobre la renta"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="e.aplica_renta"> Sí, según tramos</label></Field>
            <Field label="Estado"><select v-model="e.activo"><option :value="true">Activo</option><option :value="false">Inactivo</option></select></Field>
            <Field v-if="e.activo===false" label="Fecha de salida"><input type="date" v-model="e.fecha_salida"></Field>
            <Field label="Notas" style="grid-column:1/-1"><textarea rows="2" v-model="e.notas"></textarea></Field>
          </div>
        </div>
        <div class="card" v-if="editando"><h2>Deducciones, ingresos fijos y ausencias</h2>
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <a class="btn sec sm" :href="'#/rrhh/conceptos?empleado=' + e.id">Deducciones e ingresos fijos ({{nConceptos}} vigentes)</a>
            <a class="btn sec sm" :href="'#/rrhh/ausencias?empleado=' + e.id">Ausencias e incapacidades ({{nAusencias}})</a>
            <a class="btn sec sm" :href="'#/rrhh/vacaciones'">Vacaciones</a>
            <a class="btn sec sm" :href="'#/rrhh/acciones?empleado=' + e.id" title="Aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y salida de este empleado">Acciones de personal ({{accionesEmp.length}})</a>
          </div>
          <p class="small muted" style="margin:8px 0 0">Los préstamos, embargos, pensiones alimentarias, aportes a la asociación y bonificaciones se aplican solos en cada planilla; las incapacidades y permisos sin goce descuentan los días y calculan el subsidio patronal.</p>
        </div>
        <div class="card" v-if="editando"><h2>Documentos <small>contrato, identificación, permisos, títulos y otros</small></h2>
          <div class="table-wrap" v-if="docsFilas.length"><table class="tbl"><thead><tr><th>Tipo</th><th>Nombre</th><th>Vence</th><th class="num">Tamaño</th><th>Fecha</th><th></th></tr></thead>
            <tbody><tr v-for="d in docsFilas" :key="d.id"><td>{{d.tipo_nombre}}</td><td style="white-space:normal">{{d.nombre}}</td><td>{{d.vence_texto}}<span class="badge" :class="d.estado === 'Vencido' ? 'danger' : 'warn'" v-if="d.estado" style="margin-left:6px">{{d.estado}}</span></td><td class="num">{{d.tamano}}</td><td :title="d.subido_por ? 'Subido por ' + d.subido_por : null">{{d.subido}}</td>
              <td><div class="row" style="gap:6px;flex-wrap:nowrap;justify-content:flex-end"><button class="btn sm sec" @click.stop="verDoc(d)" title="Abre el archivo; desde ahí se puede descargar">Ver / descargar</button><button class="btn sm ghost" @click.stop="docEdit = { id: d.id, tipo: d.tipo, nombre: d.nombre, vence: d.vence || '', guardando: false }">Editar</button><button class="btn sm ghost" @click.stop="quitarDoc(d)">Eliminar</button></div></td></tr></tbody></table></div>
          <p class="small muted" style="margin:0" v-else>Esta ficha todavía no tiene documentos.</p>
          <div class="grid cols-3" style="margin-top:12px;align-items:end">
            <Field label="Archivo" help="PDF, JPG o PNG, de hasta 5 MB"><input type="file" :key="claveArchivo" accept="application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png" @change="elegirDoc" :disabled="subiendo"></Field>
            <Field label="Tipo"><select v-model="nuevoDoc.tipo"><option v-for="t in TIPOS_DOCUMENTO" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
            <Field label="Nombre" help="Como se verá en la lista"><input v-model="nuevoDoc.nombre" maxlength="120" placeholder="Ej. Contrato 2026"></Field>
            <Field label="Vence" help="Opcional: el sistema avisa 30 días antes"><input type="date" v-model="nuevoDoc.vence"></Field>
            <div style="padding-bottom:6px"><button class="btn" :disabled="subiendo || !nuevoDoc.archivo" @click="subirDoc">{{subiendo ? 'Subiendo…' : 'Subir documento'}}</button></div>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center"><button class="btn sm sec" :disabled="!docsFilas.length" @click="exportarDocs('pdf')">⤓ PDF</button><button class="btn sm ghost" :disabled="!docsFilas.length" @click="exportarDocs('xlsx')">⤓ Excel</button><button class="btn sm ghost" :disabled="!docsFilas.length" @click="exportarDocs('csv')">⤓ CSV</button><span class="small muted">Solo los ve quien tiene Recursos humanos. Se guardan al subirlos (no hace falta pulsar Guardar), van en los respaldos de la empresa y se eliminan si se elimina al empleado.</span></div>
        </div>
        <div class="card" v-if="e.historial && e.historial.length"><h2>Historial de salario</h2>
          <table class="tbl"><thead><tr><th>Fecha</th><th>Motivo</th><th>Salario</th><th class="num">Equivalente mensual</th></tr></thead>
            <tbody><tr v-for="(h,i) in e.historial.slice().reverse()" :key="i"><td>{{fecha(h.fecha)}}</td><td>{{h.motivo}}</td><td>{{money(h.salario)}} {{h.modo==='mensual' ? 'por mes' : 'por hora'}}</td><td class="num">{{money(h.mensual)}}</td></tr></tbody></table>
        </div>
        <div class="card" v-if="historialPuesto.length"><h2>Historial de puesto y departamento <small>según las acciones de personal</small></h2>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Rige</th><th>Acción</th><th>Puesto</th><th>Departamento</th></tr></thead>
            <tbody><tr v-for="h in historialPuesto" :key="h.id"><td>{{fecha(h.rige)}}</td><td>{{h.accion}}<span class="badge warn" v-if="h.pendiente" style="margin-left:6px">Pendiente de aplicar</span></td><td style="white-space:normal">{{h.puesto}}</td><td style="white-space:normal">{{h.departamento}}</td></tr></tbody></table></div>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center"><button class="btn sm sec" @click="exportarHistorialPuesto('pdf')">⤓ PDF</button><button class="btn sm ghost" @click="exportarHistorialPuesto('xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportarHistorialPuesto('csv')">⤓ CSV</button></div>
        </div>
        <div class="card" v-if="bitacora && bitacora.length"><h2>Bitácora de cambios <small>salario, cuenta, forma de pago, renta y riesgos</small></h2>
          <div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Usuario</th><th>Cambio</th></tr></thead>
            <tbody><tr v-for="b in bitacora" :key="b.id"><td>{{b.cuando}}</td><td>{{b.usuario}}</td><td style="white-space:normal">{{b.cambio}}</td></tr></tbody></table></div>
          <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center"><button class="btn sm sec" @click="exportarBitacora('pdf')">⤓ PDF</button><button class="btn sm ghost" @click="exportarBitacora('xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportarBitacora('csv')">⤓ CSV</button><span class="small muted">La anota el sistema al guardar la ficha: quién y cuándo. Los montos de cada cambio de salario están en el historial de salario.</span></div>
        </div>
      </div>
      <div>
        <div class="card" v-if="editando"><h2>Acceso al sistema <small>usuario web del empleado</small></h2>
          <template v-if="usuarioWeb">
            <p style="margin:0 0 8px"><span class="badge info">Tiene usuario web</span> <b>{{usuarioWeb.correo}}</b> · rol {{usuarioWeb.rol}} · {{usuarioWeb.bloqueado ? 'bloqueado' : 'activo'}}<span v-if="usuarioWeb.ultimo_acceso"> · último acceso {{fecha(usuarioWeb.ultimo_acceso.slice(0,10))}}</span><span v-else> · nunca ha entrado</span></p>
            <a class="btn sm sec" href="#/configuracion/usuarios">Rol, módulos y contraseña</a>
          </template>
          <p class="small muted" style="margin:0" v-else-if="!puedeUsuarios">Solo el administrador ve y crea los usuarios web.</p>
          <template v-else>
            <p class="small muted" style="margin:0 0 8px"><span class="badge">Sin usuario web</span> No entra al sistema. Si lo necesita (caja, ventas, marcas desde el celular…), créele el acceso aquí.</p>
            <Field label="Correo de acceso" req help="Es el correo del empleado; con él entra"><input type="email" v-model="e.correo"></Field>
            <Field label="Rol"><select v-model="acceso.rol"><option v-for="r in roles" :key="r" :value="r">{{r}}</option></select></Field>
            <Field label="Contraseña temporal" req help="Fácil de recordar; la cambia al entrar"><div class="row" style="gap:6px"><input v-model="acceso.password" class="mono" style="flex:1"><button class="btn ghost sm" @click="nuevaClave">Generar</button></div></Field>
            <button class="btn" :disabled="creandoAcceso" @click="crearAcceso">{{creandoAcceso ? 'Creando…' : 'Crear usuario web'}}</button>
          </template>
        </div>
        <div class="card" v-if="calc"><h2>Cálculo <small>{{PERIODOS.find(p=>p[0]===periodoPrev)[1].toLowerCase()}}</small></h2>
          <div class="alert warn" v-if="bajoMinimo" style="margin-bottom:10px">Salario mensual por debajo del mínimo de referencia ({{money(minimo)}}).</div>
          <div class="totals" style="margin-top:0">
            <div><span>Salario mensual</span><b>{{money(calc.salario_mensual)}}</b></div>
            <div><span>Salario por hora</span><b>{{money(calc.salario_hora)}}</b></div>
            <div><span>Bruto del período ({{fmt(calc.horas,1)}} h)</span><b>{{money(calc.bruto)}}</b></div>
            <div><span>− CCSS trabajador ({{calc.pct_obrero}} %)</span><b>{{money(calc.total_obrero)}}</b></div>
            <div><span>− Renta</span><b>{{money(calc.renta)}}</b></div>
            <div class="total"><span>Neto a pagar</span><b>{{money(calc.neto)}}</b></div>
          </div>
          <h3 style="margin:14px 0 6px">Costo para el patrono</h3>
          <div class="totals" style="margin-top:0">
            <div><span>Cargas patronales ({{calc.pct_patronal}} %)</span><b>{{money(calc.total_patronal)}}</b></div>
            <div class="small muted" style="grid-column:1/-1">CCSS SEM {{money(calc.patrono.sem)}} · IVM {{money(calc.patrono.ivm)}} · FODESAF {{money(calc.patrono.fodesaf)}} · IMAS {{money(calc.patrono.imas)}} · INA {{money(calc.patrono.ina)}} · Banco Popular {{money(calc.patrono.banco_popular)}} · FCL {{money(calc.patrono.fcl)}} · ROP–Operadora de pensiones {{money(calc.patrono.rop_opc)}} · ROP–Banco Popular {{money(calc.patrono.rop_bp)}} · INS {{money(calc.patrono.ins_riesgos)}}</div>
            <div><span>Reserva mensual ({{calc.pct_provisiones}} %)</span><b>{{money(calc.provision_mensual.total)}}</b></div>
            <div class="small muted" style="grid-column:1/-1">Aguinaldo {{money(calc.provision_mensual.detalle.aguinaldo)}} · Vacaciones {{money(calc.provision_mensual.detalle.vacaciones)}} · Cesantía {{money(calc.provision_mensual.detalle.cesantia)}}</div>
            <div class="total"><span>Costo total del período</span><b>{{money(calc.costo_total)}}</b></div>
          </div>
          <h3 style="margin:14px 0 6px">Vacaciones</h3>
          <div class="small">{{calc.antiguedad.meses}} meses trabajados ({{calc.antiguedad.anios}} años) · ganadas <b>{{calc.vacaciones.dias_ganados}}</b> · disfrutadas {{calc.vacaciones.dias_disfrutados}} · saldo <b>{{calc.vacaciones.saldo}} días</b></div>
        </div>
        <div class="card" v-else><p class="muted">Indique el salario para ver el cálculo.</p><p class="small muted" v-if="calcError">{{calcError}}</p></div>
      </div>
    </div>
    <Modal v-if="constancia" :title="'Constancia salarial · ' + nombreCompleto(e)" @close="constancia=null">
      <div class="grid cols-2">
        <Field label="Meses del promedio" help="Promedio del salario bruto según las planillas pagadas" style="grid-column:1/-1"><select v-model.number="constancia.meses"><option :value="3">Últimos 3 meses</option><option :value="6">Últimos 6 meses</option><option :value="12">Últimos 12 meses</option></select></Field>
        <Field label="Firma: nombre" help="Opcional: quien firma la constancia"><input v-model="constancia.firmaNombre" maxlength="90"></Field>
        <Field label="Firma: cargo" help="Opcional"><input v-model="constancia.firmaCargo" maxlength="90" placeholder="Ej. Gerente general"></Field>
      </div>
      <div class="alert warn" v-if="cambiosSinGuardar" style="margin:8px 0 0">Hay cambios sin guardar en esta ficha. La constancia sale con los datos guardados; guarde primero los cambios.</div>
      <p class="small muted" style="margin:8px 0 0">Lleva los datos del trabajador, su salario bruto mensual actual, el promedio de los últimos meses según las planillas pagadas, la fecha de emisión y la línea de firma. Sale con los datos guardados de la ficha. El texto es general: revise si quien la pide exige otro formato.</p>
      <template #foot><button class="btn ghost" @click="constancia=null">Cerrar</button><button class="btn sec" :disabled="generando" @click="emitirConstancia('pdf')">⤓ PDF</button><button class="btn sec" :disabled="generando" @click="emitirConstancia('docx')">⤓ Word</button></template>
    </Modal>
    <Modal v-if="docEdit" title="Editar documento" @close="docEdit=null">
      <div class="grid cols-2">
        <Field label="Tipo"><select v-model="docEdit.tipo"><option v-for="t in TIPOS_DOCUMENTO" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Vence" help="Vacío si no vence"><input type="date" v-model="docEdit.vence"></Field>
        <Field label="Nombre" req style="grid-column:1/-1"><input v-model="docEdit.nombre" maxlength="120"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">El archivo no cambia: para reemplazarlo suba el nuevo y elimine el anterior.</p>
      <template #foot><button class="btn ghost" @click="docEdit=null">Cancelar</button><button class="btn" :disabled="docEdit.guardando" @click="guardarDoc">Guardar</button></template>
    </Modal>
  </div>`,
};
