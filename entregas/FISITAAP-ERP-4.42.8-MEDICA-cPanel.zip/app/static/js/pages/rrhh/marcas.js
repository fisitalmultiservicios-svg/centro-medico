// Recursos humanos › Marcas de asistencia (3.46, traído de FISITAAP): los empleados marcan Entrada, Pausa, Regreso y Salida en
// un quiosco (la caja, una tableta o cualquier equipo) con su código de reloj y una clave personal; no necesitan usuario.
// Aquí se ven las marcas por día, se corrigen con motivo (la original queda en la bitácora), se anotan marcas manuales, se
// activan los quioscos, se fijan las claves y se revisa el resumen de asistencia contra el horario planificado (3.43): horas
// trabajadas, extra sugerida, tardías, ausencias y días incompletos. El reloj marcador (ZKTeco por archivo) y UniFi Access
// entrarán a la misma tabla de marcas cuando se conecten: conviven como opciones.
import { api, toast, fecha, fechaHora, hoy, fmt } from '../../api.js';
import { sesion } from '../../app.js';
import { exportarTabla } from '../reportes/_montos.js';

const ORIGEN = { quiosco: 'Quiosco', manual: 'Manual', correccion: 'Corrección', reloj: 'Reloj marcador', unifi: 'UniFi Access', sistema: 'Marca rápida ⏱' };   // 4.7: «sistema» salía con la palabra cruda
const lunesDe = iso => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.toLocaleDateString('en-CA'); };
const sumar = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toLocaleDateString('en-CA'); };

export default {
  props: ['params'],
  data() {
    const h = hoy();
    return { importando: false, activando: false, tab: (this.params && this.params.tab) || 'marcas', cfg: null, desde: lunesDe(h), hasta: h, empleado: '', marcas: [], resumen: null, cargando: false, incluirCorregidas: false,
             modal: null, correccion: null, quiosco: null, claveForm: null, detalle: null, ORIGEN, TIPOS: [['entrada', 'Entrada'], ['pausa', 'Pausa'], ['regreso', 'Regreso'], ['salida', 'Salida']] };
  },
  computed: {
    empleados() { return this.cfg ? this.cfg.empleados.filter(e => e.activo) : []; },
    nombres() { return Object.fromEntries((this.cfg ? this.cfg.empleados : []).map(e => [e.id, e.nombre])); },
    porDia() {
      const m = {}; for (const x of this.marcas) (m[x.fecha] = m[x.fecha] || []).push(x);
      return Object.entries(m).sort((a, b) => b[0].localeCompare(a[0])).map(([f, l]) => ({ fecha: f, marcas: l.sort((a, b) => (a.empleado || '').localeCompare(b.empleado || '') || a.fecha_hora.localeCompare(b.fecha_hora)) }));
    },
    sinCodigo() { return this.empleados.filter(e => !e.codigo_reloj); },
    urlQuiosco() { return location.origin + '/marcar.html'; },
  },
  methods: {
    // 3.67: marcas exportadas por un reloj marcador (Excel o CSV)
    async importarReloj(ev) {
      const f = ev.target.files && ev.target.files[0]; ev.target.value = ''; if (!f) return;
      const fd = new FormData(); fd.append('archivo', f); fd.append('equipo', f.name.replace(/\.[^.]+$/, '').slice(0, 60));
      this.importando = true;
      try {
        const r = await api('/api/asistencia/importar', { method: 'POST', body: fd });
        const partes = [r.creadas + ' marca(s) nueva(s)']; if (r.repetidas) partes.push(r.repetidas + ' ya estaban'); if (r.futuras) partes.push(r.futuras + ' en el futuro (no se cargan)');
        if (r.sin_empleado && r.sin_empleado.length) partes.push('sin empleado: ' + r.sin_empleado.map(x => x.codigo + ' (' + x.marcas + ')').join(', ') + ' — ponga ese código de reloj en la ficha del empleado');
        toast('Reloj: ' + partes.join(' · '), r.creadas ? 'ok' : 'err'); if (r.avisos && r.avisos.length) toast(r.avisos.slice(0, 3).join(' · '), 'err');
        await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.importando = false;
    },
    fecha, fechaHora, fmt,
    async cargarCfg() { try { this.cfg = await api('/api/asistencia/config'); } catch (e) { toast(e.message, 'err'); } },
    async cargar() {
      if (this.desde > this.hasta) return toast('La fecha inicial no puede ser mayor que la final', 'err');
      this.cargando = true;
      try {
        const q = '?desde=' + this.desde + '&hasta=' + this.hasta + (this.empleado ? '&empleado_id=' + this.empleado : '');
        if (this.tab === 'resumen') this.resumen = await api('/api/asistencia/resumen' + q);
        else this.marcas = await api('/api/asistencia/marcas' + q + (this.incluirCorregidas ? '&incluir_corregidas=1' : ''));
      } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    irTab(t) { this.tab = t; if (t === 'marcas' || t === 'resumen') this.cargar(); },
    semana(n) { this.desde = sumar(this.desde, 7 * n); this.hasta = sumar(this.desde, 6); this.cargar(); },
    estaSemana() { this.desde = lunesDe(hoy()); this.hasta = hoy(); this.cargar(); },
    mes() { const h = hoy(); this.desde = h.slice(0, 8) + '01'; this.hasta = h; this.cargar(); },
    // ---- marcas manuales y correcciones ----
    nuevaManual() { this.modal = { empleado_id: this.empleado || (this.empleados[0] ? this.empleados[0].id : null), tipo: 'entrada', fecha: hoy(), hora: '08:00', motivo: '' }; },
    async guardarManual() {
      const m = this.modal; if (!m.empleado_id) return toast('Elija el empleado', 'err'); if (!m.motivo.trim()) return toast('Escriba el motivo', 'err');
      try { await api('/api/asistencia/marcas', { method: 'POST', body: { empleado_id: +m.empleado_id, tipo: m.tipo, fecha_hora: m.fecha + 'T' + m.hora, motivo: m.motivo.trim() } }); this.modal = null; toast('Marca anotada', 'ok'); this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    abrirCorreccion(x) { this.correccion = { marca: x, tipo: x.tipo, fecha: x.fecha, hora: x.hora, motivo: '', anular: false }; },
    async guardarCorreccion() {
      const c = this.correccion; if (!c.motivo.trim()) return toast('El motivo es obligatorio', 'err');
      try {
        const cambioHora = c.fecha !== c.marca.fecha || c.hora !== c.marca.hora;   // si no se tocó la hora, la corrección conserva la original con sus segundos
        await api('/api/asistencia/marcas/' + c.marca.id + '/corregir', { method: 'PUT', body: { tipo: c.tipo, fecha_hora: cambioHora ? c.fecha + 'T' + c.hora : null, motivo: c.motivo.trim(), anular: c.anular } });
        this.correccion = null; toast(c.anular ? 'Marca anulada (queda en la bitácora)' : 'Marca corregida; la original queda en la bitácora', 'ok'); this.cargar();
      } catch (e) { toast(e.message, 'err'); }
    },
    // ---- quiosco ----
    // 4.42: cada pedido crea un equipo en la lista: uno solo a la vez, y con el enlace ya a la vista no se genera otro desde el mismo cuadro
    async activarQuiosco() {
      const q = this.quiosco; if (this.activando || !q || q.enlace) return;
      const nombre = (q.nombre || '').trim(); if (nombre.length < 2) return toast('Póngale nombre al equipo (Caja 1, Tableta cocina…)', 'err');
      this.activando = true;
      try {
        const r = await api('/api/asistencia/quiosco', { method: 'POST', body: { nombre } });
        if (q.aqui) { try { localStorage.setItem('asistencia:quiosco', r.token); } catch {} if (this.quiosco === q) this.quiosco = null; await this.cargarCfg(); toast('Este equipo quedó activado como quiosco «' + r.equipo + '»', 'ok'); window.open('/marcar.html', '_blank'); }
        else { q.enlace = location.origin + '/marcar.html#q=' + encodeURIComponent(r.token); await this.cargarCfg(); }
      } catch (e) { toast(e.message, 'err'); }
      finally { this.activando = false; }
    },
    copiar(t) { try { navigator.clipboard.writeText(t); toast('Enlace copiado: ábralo UNA vez en el equipo que será el quiosco', 'ok'); } catch { toast('Copie el enlace a mano', 'err'); } },
    async desactivarQuioscos() { if (!confirm('¿Desactivar todos los quioscos? Cada equipo tendrá que activarse de nuevo.')) return; try { await api('/api/asistencia/quiosco', { method: 'DELETE' }); try { localStorage.removeItem('asistencia:quiosco'); } catch {} toast('Quioscos desactivados', 'ok'); this.cargarCfg(); } catch (e) { toast(e.message, 'err'); } },
    async desactivarQuiosco(q) { if (!confirm('¿Desactivar el quiosco «' + q.nombre + '»? Ese equipo ya no podrá marcar; los demás siguen igual.')) return; try { await api('/api/asistencia/quiosco/' + q.id, { method: 'DELETE' }); toast('Quiosco «' + q.nombre + '» desactivado', 'ok'); await this.cargarCfg(); } catch (e) { toast(e.message, 'err'); } },
    // 4.7: también guarda la duración máxima de un turno (turnos de noche) y el descanso mínimo entre turnos (reloj sin tipo de marca)
    async guardarTolerancia() { try { await api('/api/asistencia/config', { method: 'PUT', body: { tolerancia_min: +this.cfg.tolerancia_min || 0, max_turno_horas: Math.round(+this.cfg.max_turno_horas) || 16, descanso_min_horas: Math.round(+this.cfg.descanso_min_horas) || 13 } }); toast('Guardado', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    // ---- claves ----
    abrirClave(e) { this.claveForm = { empleado: e, clave: '', clave2: '' }; },
    async guardarClave() {
      const f = this.claveForm; if (f.clave !== f.clave2) return toast('Las dos claves no coinciden', 'err');
      try { await api('/api/asistencia/clave', { method: 'PUT', body: { empleado_id: f.empleado.id, clave: f.clave } }); toast('Clave de ' + f.empleado.nombre + ' guardada', 'ok'); this.claveForm = null; this.cargarCfg(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async quitarClave(e) { if (!confirm('¿Quitar la clave para marcar de ' + e.nombre + '?')) return; try { await api('/api/asistencia/clave/' + e.id, { method: 'DELETE' }); this.cargarCfg(); } catch (ex) { toast(ex.message, 'err'); } },
    // ---- resumen ----
    exportarResumen() {
      if (!this.resumen) return;
      const cols = [{ key: 'nombre', label: 'Empleado' }, { key: 'codigo_reloj', label: 'Código' }, { key: 'dias_marcados', label: 'Días con marcas' }, { key: 'trabajado', label: 'Horas trabajadas' }, { key: 'planificado', label: 'Horas planificadas' }, { key: 'extra', label: 'Extra sugerida' }, { key: 'tardes', label: 'Llegadas tarde' }, { key: 'tarde_min', label: 'Minutos tarde' }, { key: 'ausencias', label: 'Ausencias' }, { key: 'incompletos', label: 'Días incompletos' }];
      exportarTabla('asistencia_' + this.desde + '_' + this.hasta, cols, this.resumen.empleados, { titulo: 'Asistencia', periodo: this.desde + ' al ' + this.hasta });
    },
    exportarDetalle() {
      if (!this.resumen) return;
      const rows = []; for (const e of this.resumen.empleados) for (const d of e.dias) rows.push({ nombre: e.nombre, fecha: d.fecha, marcas: this.marcasDia(d), trabajado: d.trabajado, planificado: d.planificado ?? '', extra: d.extra, tarde_min: d.tarde_min, estado: d.ausente ? 'Ausente' : d.incompleta ? (d.avisos && d.avisos.length ? 'Incompleto: ' + d.avisos.join(', ') : 'Incompleto') : d.en_curso ? 'En curso' : '' });
      exportarTabla('asistencia_detalle_' + this.desde + '_' + this.hasta, [{ key: 'nombre', label: 'Empleado' }, { key: 'fecha', label: 'Fecha' }, { key: 'marcas', label: 'Marcas' }, { key: 'trabajado', label: 'Horas' }, { key: 'planificado', label: 'Planificadas' }, { key: 'extra', label: 'Extra' }, { key: 'tarde_min', label: 'Min. tarde' }, { key: 'estado', label: 'Estado' }], rows, { titulo: 'Asistencia por día', periodo: this.desde + ' al ' + this.hasta });
    },
    // 4.7: «En curso» = turno todavía abierto dentro del tope; «Incompleto» lleva el motivo en d.avisos
    claseDia(d) { return d.ausente ? 'danger' : d.incompleta ? 'warn' : d.tarde_min ? 'warn' : d.en_curso ? 'info' : d.extra ? 'info' : 'ok'; },
    textoDia(d) { return d.ausente ? 'Ausente' : d.incompleta ? 'Incompleto' : d.tarde_min ? 'Tarde ' + d.tarde_min + ' min' : d.en_curso ? 'En curso' : d.extra ? '+' + fmt(d.extra, 2) + ' h' : 'OK'; },
    // 4.7: marcas del turno; la de madrugada de un turno de noche dice «(día siguiente)»
    marcasDia(d) { return (d.detalle || []).map(m => m.tipo_nombre + ' ' + m.hora + (m.fecha && m.fecha !== d.fecha ? ' (día siguiente)' : '')).join(' · '); },
  },
  async created() { await this.cargarCfg(); this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Marcas de asistencia" sub="Los empleados marcan entrada, pausa, regreso y salida en un quiosco con su código y una clave personal. Las marcas sirven para controlar la asistencia y sacar reportes; no pasan solas a la planilla: las horas extra se anotan en Recursos humanos › Horas extra." :crumbs="[{label:'Recursos humanos'},{label:'Marcas'}]">
      <button class="btn sec" @click="nuevaManual" v-if="tab==='marcas'">+ Marca manual</button>
      <button class="btn sec" @click="exportarResumen" v-if="tab==='resumen' && resumen">Exportar resumen</button><button class="btn ghost" @click="exportarDetalle" v-if="tab==='resumen' && resumen">Exportar detalle</button>
    <label class="btn sec" v-if="sesion.puede('rrhh')" style="cursor:pointer" title="Excel o CSV exportado por el reloj (ZKTeco, Anviz, Hikvision…): código del empleado, fecha y hora, y si trae, el tipo de marca">{{importando ? 'Importando…' : '⤒ Importar de un reloj'}}<input type="file" accept=".xlsx,.xlsm,.csv,.txt" style="display:none" @change="importarReloj" :disabled="importando"></label></PageHead>
    <div class="seg" style="margin-bottom:12px"><button :class="{on: tab==='marcas'}" @click="irTab('marcas')">Marcas</button><button :class="{on: tab==='resumen'}" @click="irTab('resumen')">Resumen de asistencia</button><button :class="{on: tab==='quiosco'}" @click="irTab('quiosco')">Quiosco y claves</button></div>

    <template v-if="tab==='marcas' || tab==='resumen'">
      <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end">
        <Field label="Desde"><input type="date" v-model="desde"></Field><Field label="Hasta"><input type="date" v-model="hasta"></Field>
        <Field label="Empleado"><select v-model="empleado"><option value="">Todos</option><option v-for="e in empleados" :key="e.id" :value="e.id">{{e.nombre}}</option></select></Field>
        <button class="btn" @click="cargar" :disabled="cargando">{{cargando ? 'Buscando…' : 'Buscar'}}</button>
        <span class="seg"><button @click="semana(-1)" title="Semana anterior">◀</button><button @click="estaSemana">Esta semana</button><button @click="semana(1)" title="Semana siguiente">▶</button></span><button class="btn ghost" @click="mes">Este mes</button>
        <label class="row small" style="gap:4px;cursor:pointer;margin-left:auto" v-if="tab==='marcas'"><input type="checkbox" v-model="incluirCorregidas" @change="cargar"> Ver corregidas y anuladas</label>
      </div></div>
      <div class="alert warn" v-if="cfg && sinCodigo.length" style="margin-bottom:12px">Sin código de reloj (no pueden marcar): {{sinCodigo.map(e => e.nombre).join(', ')}}. Póngaselo en la ficha del empleado.</div>
    </template>

    <template v-if="tab==='marcas'">
      <Empty v-if="!porDia.length" icon="⏱" title="Sin marcas en el período" text="Active un quiosco en la pestaña «Quiosco y claves» y dele a cada empleado su clave. También puede anotar una marca manual."></Empty>
      <div v-for="d in porDia" :key="d.fecha" class="card" style="margin-bottom:10px"><h2>{{fecha(d.fecha)}} <small>{{d.marcas.length}} marca(s)</small></h2>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Empleado</th><th>Marca</th><th>Hora</th><th>Origen</th><th>Equipo / quién</th><th>Nota</th><th></th></tr></thead><tbody>
          <tr v-for="m in d.marcas" :key="m.id" :style="m.corregida ? 'opacity:.55;text-decoration:line-through' : ''">
            <td><b>{{m.empleado}}</b></td><td><span class="badge" :class="m.tipo==='entrada' ? 'ok' : m.tipo==='salida' ? '' : 'info'">{{m.tipo_nombre}}</span></td><td class="mono">{{m.hora}}</td>
            <td class="small">{{ORIGEN[m.origen] || m.origen}}<span v-if="m.original_id" class="muted"> (reemplaza #{{m.original_id}})</span></td><td class="small">{{m.equipo || m.registrado_por || '—'}}<div class="muted" v-if="m.corregida">corregida por {{m.corregida_por}}</div></td>
            <td class="small">{{m.motivo || m.nota || ''}}</td><td class="num"><button class="btn sm ghost" v-if="!m.corregida" @click="abrirCorreccion(m)">Corregir</button></td>
          </tr></tbody></table></div>
      </div>
    </template>

    <template v-else-if="tab==='resumen'">
      <Empty v-if="!resumen || !resumen.empleados.length" icon="📊" title="Nada que resumir" text="No hay marcas ni horarios planificados en el período."></Empty>
      <template v-else>
        <p class="small muted" style="margin:0 0 8px">Horas trabajadas = de la entrada a la salida, menos las pausas. Un turno que pasa la medianoche cuenta completo en el día de su entrada (si la salida llega dentro de {{resumen.max_turno_horas || 16}} h). «Incompleto» = falta una marca (pausa sin regreso, salida sin entrada o turno sin salida): corríjala o anótela a mano. La extra sugerida es lo que pasa de las horas planificadas en Horarios de trabajo (o de la jornada diaria si no hay horario). Estas horas no pasan solas a la planilla: revise la extra y regístrela en <a href="#/rrhh/horas-extra">Horas extra</a>. Tolerancia de llegada: {{resumen.tolerancia_min}} min.</p>
        <div v-for="e in resumen.empleados" :key="e.empleado_id" class="card" style="margin-bottom:10px">
          <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;align-items:center"><h2 style="margin:0">{{e.nombre}} <small v-if="e.codigo_reloj">código {{e.codigo_reloj}}</small></h2>
            <div class="row small" style="gap:12px;flex-wrap:wrap"><span><b>{{fmt(e.trabajado, 2)}} h</b> trabajadas</span><span v-if="e.planificado"><b>{{fmt(e.planificado, 2)}} h</b> planificadas</span><span :style="e.extra ? 'color:var(--primary)' : ''"><b>{{fmt(e.extra, 2)}} h</b> extra sugerida</span><span :style="e.tardes ? 'color:var(--warn)' : ''">{{e.tardes}} tarde ({{e.tarde_min}} min)</span><span :style="e.ausencias ? 'color:var(--danger)' : ''">{{e.ausencias}} ausencia(s)</span><span :style="e.incompletos ? 'color:var(--warn)' : ''">{{e.incompletos}} incompleto(s)</span><a class="link" style="cursor:pointer" @click="detalle = detalle === e.empleado_id ? null : e.empleado_id">{{detalle === e.empleado_id ? 'Ocultar días' : 'Ver días'}}</a></div></div>
          <div class="table-wrap" v-if="detalle === e.empleado_id" style="margin-top:8px"><table class="tbl"><thead><tr><th>Día</th><th>Marcas</th><th class="num">Horas</th><th class="num">Planificadas</th><th class="num">Extra</th><th>Estado</th></tr></thead><tbody>
            <tr v-for="d in e.dias" :key="d.fecha"><td>{{fecha(d.fecha)}}</td><td class="small">{{marcasDia(d) || '—'}}</td><td class="num">{{fmt(d.trabajado, 2)}}</td><td class="num">{{d.planificado === null ? '—' : fmt(d.planificado, 2)}}</td><td class="num">{{d.extra ? fmt(d.extra, 2) : ''}}</td><td><span class="badge" :class="claseDia(d)" :title="(d.avisos || []).join(' · ')">{{textoDia(d)}}</span><div class="small muted" v-if="d.avisos && d.avisos.length">{{d.avisos.join(' · ')}}</div><div class="small muted" v-if="d.notas && d.notas.length">{{d.notas.join(' · ')}}</div></td></tr>
          </tbody></table></div>
        </div>
      </template>
    </template>

    <template v-else>
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Quioscos para marcar</h2>
          <p class="small muted" style="margin:0 0 10px">Un quiosco es cualquier equipo del negocio (la computadora de la caja, una tableta en la cocina, un celular en la entrada) con la página <b>{{urlQuiosco}}</b> abierta. Se activa una sola vez por equipo; después los empleados solo teclean su código y su clave. No hace falta iniciar sesión.</p>
          <div v-if="cfg">
            <div class="table-wrap" v-if="(cfg.quioscos || []).length" style="margin-bottom:8px"><table class="tbl"><thead><tr><th>Equipo</th><th>Activado</th><th></th></tr></thead><tbody>
              <tr v-for="q in cfg.quioscos" :key="q.id"><td>🖥 {{q.nombre}} <span class="badge warn" v-if="q.vencido" title="Pasó un año desde que se activó: ese equipo ya no marca. Actívelo de nuevo si lo sigue usando.">Vencido</span></td><td class="small parte fina">{{fechaHora(q.activado)}}<span class="muted" v-if="q.activado_por"> · {{q.activado_por}}</span></td><td class="num"><button class="btn sm ghost" @click="desactivarQuiosco(q)">Desactivar</button></td></tr>
            </tbody></table></div>
            <p class="small muted" v-if="(cfg.anteriores || []).length" style="margin:0 0 8px">Activados antes de esta versión (sin fecha): <b>{{cfg.anteriores.join(', ')}}</b>. Estos no se pueden desactivar uno por uno: use «Desactivar todos» y active de nuevo los que sigan en uso.</p>
            <p class="small muted" v-if="!cfg.equipos.length" style="margin:0 0 8px">Ningún quiosco activado todavía.</p>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn" @click="quiosco = {nombre: '', aqui: true, enlace: ''}" :disabled="activando">Activar este equipo</button><button class="btn sec" @click="quiosco = {nombre: '', aqui: false, enlace: ''}" :disabled="activando">Enlace para otro equipo</button><button class="btn ghost" @click="desactivarQuioscos" v-if="cfg && cfg.equipos.length">Desactivar todos</button></div>
          <div class="card" style="margin-top:10px;padding:10px;background:var(--bg2,#f7f8fa)" v-if="quiosco">
            <Field label="Nombre del equipo" req help="Sale en cada marca: Caja 1, Tableta cocina, Entrada…"><input v-model="quiosco.nombre" maxlength="40" @keyup.enter="activarQuiosco"></Field>
            <div class="row" style="gap:8px;margin-top:8px"><button class="btn" v-if="!quiosco.enlace" @click="activarQuiosco" :disabled="activando">{{quiosco.aqui ? 'Activar y abrir el quiosco' : 'Generar enlace'}}</button><button class="btn ghost" @click="quiosco=null" :disabled="activando">{{quiosco.enlace ? 'Cerrar' : 'Cancelar'}}</button></div>
            <div v-if="quiosco.enlace" style="margin-top:10px"><p class="small" style="margin:0 0 6px">Abra este enlace <b>una sola vez</b> en el equipo que será el quiosco (vale un año; deja de servir si lo desactiva en la lista o con «Desactivar todos»):</p><div class="row" style="gap:6px"><input class="inp mono small" :value="quiosco.enlace" readonly style="flex:1"><button class="btn sm sec" @click="copiar(quiosco.enlace)">Copiar</button></div></div>
          </div>
          <div style="margin-top:14px" v-if="cfg"><Field label="Tolerancia de llegada (minutos)" help="Una entrada después de la hora del turno más esta tolerancia cuenta como tardía en el resumen"><div class="row" style="gap:6px"><input type="number" min="0" max="120" v-model.number="cfg.tolerancia_min" style="width:100px"><button class="btn sm sec" @click="guardarTolerancia">Guardar</button></div></Field>
            <Field label="Duración máxima de un turno (horas)" help="Turnos de noche: después de la medianoche, una salida, pausa o regreso dentro de estas horas desde la entrada cuenta en ese turno. Pasado el tope, el turno queda incompleto y la siguiente marca empieza uno nuevo. Las marcas del mismo día de la entrada siempre cuentan en su turno, aunque la jornada sea más larga (el resumen lo anota). Póngalo unas horas por encima del turno más largo (de 12 a 36)."><div class="row" style="gap:6px"><input type="number" min="12" max="36" step="1" v-model.number="cfg.max_turno_horas" style="width:100px"><button class="btn sm sec" @click="guardarTolerancia">Guardar</button></div></Field>
            <Field label="Descanso mínimo entre turnos (horas)" help="Al importar un reloj que no trae el tipo de marca: si entre dos marcas seguidas pasan estas horas o más, la segunda empieza un turno nuevo, así una marca olvidada no cambia la entrada y la salida de los días siguientes. Póngalo por encima del tramo más largo que se trabaja sin marcar (de la entrada a la salida, si no marcan la pausa) y por debajo del descanso más corto entre dos turnos. Con turnos de 12 horas sirve el que trae (13); con turnos de 24 horas, póngalo en 25 o más (de 6 a 48)."><div class="row" style="gap:6px"><input type="number" min="6" max="48" step="1" v-model.number="cfg.descanso_min_horas" style="width:100px"><button class="btn sm sec" @click="guardarTolerancia">Guardar</button></div></Field></div>
          <p class="small muted" style="margin:12px 0 0">Otras formas de marcar, sobre la misma lista de marcas: reloj marcador ZKTeco (por archivo) y UniFi Access (por aviso automático). Se activan cuando el negocio las tenga; conviven con el quiosco.</p>
        </div>
        <div class="card"><h2>Claves para marcar</h2>
          <p class="small muted" style="margin:0 0 10px">Cada empleado marca con su <b>código de reloj</b> (de su ficha) y una <b>clave personal de 4 a 8 dígitos</b>, distinta de cualquier contraseña del sistema. Cinco claves incorrectas bloquean cinco minutos. El empleado puede cambiarla desde el quiosco.</p>
          <div class="table-wrap" v-if="cfg"><table class="tbl"><thead><tr><th>Empleado</th><th>Código</th><th>Clave</th><th></th></tr></thead><tbody>
            <tr v-for="e in empleados" :key="e.id"><td>{{e.nombre}}</td><td class="mono">{{e.codigo_reloj || '—'}}</td><td><span class="badge" :class="e.con_clave ? 'ok' : ''">{{e.con_clave ? 'Tiene clave' : 'Sin clave'}}</span></td><td class="num"><div class="acts"><button class="btn sm sec" @click="abrirClave(e)" :disabled="!e.codigo_reloj" :title="e.codigo_reloj ? '' : 'Primero póngale código de reloj en su ficha'">{{e.con_clave ? 'Cambiar' : 'Asignar'}}</button><button class="btn sm ghost" v-if="e.con_clave" @click="quitarClave(e)">Quitar</button></div></td></tr>
          </tbody></table></div>
          <p class="small muted" v-if="cfg && !empleados.length">No hay empleados activos. <a href="#/rrhh/empleados">Ir a Empleados</a>.</p>
        </div>
      </div>
    </template>

    <Modal v-if="modal" title="Marca manual (anotada por un supervisor)" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Empleado" req><select v-model="modal.empleado_id"><option v-for="e in empleados" :key="e.id" :value="e.id">{{e.nombre}}</option></select></Field>
        <Field label="Marca" req><select v-model="modal.tipo"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Fecha" req><input type="date" v-model="modal.fecha"></Field><Field label="Hora" req><input type="time" v-model="modal.hora"></Field>
        <Field label="Motivo" req style="grid-column:1/-1"><input v-model="modal.motivo" maxlength="200" placeholder="El quiosco estaba sin internet, olvidó marcar…"></Field>
      </div>
      <p class="small muted" style="margin:8px 0 0">Queda registrada como «manual» con su usuario y el motivo.</p>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="guardarManual">Anotar la marca</button></template>
    </Modal>
    <Modal v-if="correccion" :title="'Corregir la marca de ' + correccion.marca.empleado" @close="correccion=null">
      <p class="small muted" style="margin:0 0 8px">Original: <b>{{correccion.marca.tipo_nombre}}</b> a las {{correccion.marca.hora}} del {{fecha(correccion.marca.fecha)}} ({{ORIGEN[correccion.marca.origen] || correccion.marca.origen}}). No se borra: queda en la bitácora como corregida.</p>
      <div class="grid cols-3">
        <Field label="Marca"><select v-model="correccion.tipo" :disabled="correccion.anular"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Fecha"><input type="date" v-model="correccion.fecha" :disabled="correccion.anular"></Field><Field label="Hora"><input type="time" v-model="correccion.hora" :disabled="correccion.anular"></Field>
      </div>
      <Field label="Motivo" req style="margin-top:6px"><input v-model="correccion.motivo" maxlength="200" placeholder="Marcó tarde por fila en la caja, marcó dos veces…"></Field>
      <label class="row small" style="gap:6px;cursor:pointer;margin-top:8px"><input type="checkbox" v-model="correccion.anular"> Anular la marca (sin reemplazo)</label>
      <template #foot><button class="btn ghost" @click="correccion=null">Cancelar</button><button class="btn" :class="{danger: correccion.anular}" @click="guardarCorreccion">{{correccion.anular ? 'Anular' : 'Guardar la corrección'}}</button></template>
    </Modal>
    <Modal v-if="claveForm" :title="'Clave para marcar · ' + claveForm.empleado.nombre" @close="claveForm=null">
      <div class="grid cols-2"><Field label="Clave (4 a 8 dígitos)" req><input type="password" inputmode="numeric" maxlength="8" v-model="claveForm.clave" autocomplete="new-password"></Field><Field label="Repetir la clave" req><input type="password" inputmode="numeric" maxlength="8" v-model="claveForm.clave2" autocomplete="new-password" @keyup.enter="guardarClave"></Field></div>
      <p class="small muted" style="margin:8px 0 0">Entréguesela al empleado en persona; no se guarda en claro y nadie la puede consultar después. Si la olvida, asígnele otra.</p>
      <template #foot><button class="btn ghost" @click="claveForm=null">Cancelar</button><button class="btn" @click="guardarClave">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
