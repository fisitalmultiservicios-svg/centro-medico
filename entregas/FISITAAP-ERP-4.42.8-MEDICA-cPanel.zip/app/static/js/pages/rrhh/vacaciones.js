// Recursos humanos › Vacaciones: días ganados por tiempo trabajado (un día por mes, 12 al año), disfrutados y saldo por empleado.
// 4.42 (L8): los días que pagó una liquidación ya pagada no se eliminan (salen con la marca «Pagada»); las fechas se revisan antes
// de guardar, y registrar o eliminar espera la respuesta del servidor (que aplica las mismas reglas) y vuelve a leer lo guardado.
import { money, fecha, hoy, toast, mock } from '../../api.js';
import { empleados, nombreCompleto, mesesCompletos, vacacionesTomadas, tablas, salarioMensual, diasGanados, FERIADOS_FIJOS, liquidaciones, esPagada } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

const ES_FECHA = /^\d{4}-\d{2}-\d{2}$/;

export default {
  props: ['params'],
  data() { return { lista: empleados(), tomadas: vacacionesTomadas(), liqs: liquidaciones(), t: null, modal: null, guardando: false }; },
  computed: {
    porMes() { return (this.t && this.t.efectivos.dias_vacaciones_por_mes) || 1; },
    rows() {
      return this.lista.map(e => {
        const meses = mesesCompletos(e.fecha_ingreso, e.activo === false && e.fecha_salida ? e.fecha_salida : hoy());
        const ganados = diasGanados(e.fecha_ingreso, e.activo === false && e.fecha_salida ? e.fecha_salida : hoy(), this.porMes), disf = this.tomadas.filter(v => v.empleado_id === e.id).reduce((s, v) => s + (+v.dias || 0), 0);
        const diario = Math.round(salarioMensual(e) / 30 * 100) / 100;
        return { ...e, nombre_completo: nombreCompleto(e), meses, ganados, disfrutados: disf, saldo: Math.round((ganados - disf) * 100) / 100, valor: Math.round((ganados - disf) * diario), estado: e.activo === false ? 'Inactivo' : 'Activo' };
      });
    },
    columns() { return [{ key: 'nombre_completo', label: 'Empleado' }, { key: 'fecha_ingreso', label: 'Ingreso', fmt: 'date' }, { key: 'meses', label: 'Meses', num: true }, { key: 'ganados', label: 'Ganados', num: true }, { key: 'disfrutados', label: 'Disfrutados', num: true }, { key: 'saldo', label: 'Saldo (días)', num: true }, { key: 'valor', label: 'Valor del saldo', num: true, fmt: 'money' }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    // 4.42 (L8): las liquidaciones ya pagadas, por id
    pagadas() { return Object.fromEntries(this.liqs.filter(esPagada).map(l => [String(l.id), l])); },
    // liquidacion_pagada: el número de la liquidación ya pagada que pagó esos días ('' si no hay): esa fila no se elimina
    historial() { const n = Object.fromEntries(this.lista.map(e => [e.id, nombreCompleto(e)])); return this.tomadas.slice().sort((a, b) => b.desde.localeCompare(a.desde)).map(v => { const l = this.liquidacionPagada(v); return { ...v, empleado: n[v.empleado_id] || '—', liquidacion_pagada: l ? String(l.numero || 'n.º ' + l.id) : '' }; }); },
    // más de 24 días acumulados = dos períodos sin disfrutar: el Código de Trabajo no permite acumularlas (art. 158)
    acumulados() { return this.rows.filter(r => r.activo !== false && r.saldo >= 24); },
    totalValor() { return this.rows.filter(r => r.activo !== false).reduce((s, r) => s + (r.valor > 0 ? r.valor : 0), 0); },
    // días hábiles: sin domingos, sin feriados de ley y, para jornadas de 5 días (40 h o menos), sin sábados (R311)
    diasModal() { if (!this.modal || !this.modal.desde || !this.modal.hasta) return 0; const emp = this.lista.find(e => e.id === this.modal.empleado_id), cinco = emp && (+emp.horas_semana || 48) <= 40; const a = new Date(this.modal.desde + 'T00:00:00'), b = new Date(this.modal.hasta + 'T00:00:00'); let n = 0; for (let d = new Date(a); d <= b; d.setDate(d.getDate() + 1)) { const md = String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); if (d.getDay() !== 0 && !(cinco && d.getDay() === 6) && !FERIADOS_FIJOS.includes(md)) n++; } return n; },
  },
  watch: { 'modal.hasta'() { if (this.modal && !this.modal.manual) this.modal.dias = this.diasModal; }, 'modal.desde'() { if (this.modal && !this.modal.manual) this.modal.dias = this.diasModal; } },
  methods: {
    money, fecha,
    abrir(e) { this.modal = { empleado_id: e ? e.id : (this.lista[0] ? this.lista[0].id : null), desde: hoy(), hasta: hoy(), dias: 1, nota: '', manual: false }; },
    // 4.42 (L8): la liquidación ya pagada, del mismo empleado, que pagó esos días (o null). Es la misma regla del servidor
    liquidacionPagada(v) { const l = v && v.liquidacion_id ? this.pagadas[String(v.liquidacion_id)] : null; return l && l.empleado_id === v.empleado_id ? l : null; },
    // vuelve a leer lo guardado y las liquidaciones (para la marca «Pagada»); `delServidor`: antes trae lo que otra persona haya
    // cambiado. Sin conexión se queda con la copia de esta pestaña
    async recargar(delServidor) {
      const gen = mock.generacion;
      this.tomadas = vacacionesTomadas(); this.liqs = liquidaciones();
      if (!delServidor) return;
      try { await mock.refrescar(['vacaciones_tomadas', 'liquidaciones']); } catch (e) { return; }
      if (mock.generacion !== gen) return;
      this.tomadas = vacacionesTomadas(); this.liqs = liquidaciones();
    },
    // 4.42 (L8): revisa lo mismo que el servidor antes de mandar nada (un rechazo dejaría el registro en la copia de esta pestaña,
    // fallando en cada guardado) y espera la respuesta: si no se guardó, el registro no queda en la tabla
    async guardar() {
      const m = this.modal;
      if (!m || this.guardando) return;
      if (!m.empleado_id) return toast('Seleccione el empleado', 'err');
      if (!ES_FECHA.test(m.desde || '') || !ES_FECHA.test(m.hasta || '')) return toast('Indique las fechas «Desde» y «Hasta»', 'err');
      if (m.hasta < m.desde) return toast('«Hasta» no puede ser anterior a «Desde»', 'err');
      if (!(+m.dias > 0)) return toast('Indique los días (un número mayor que cero)', 'err');
      if (!mock.puedeGuardar()) return;
      const gen = mock.generacion, l = vacacionesTomadas(), id = mock.nextId(l, 'vacaciones_tomadas');
      l.push({ id, empleado_id: m.empleado_id, desde: m.desde, hasta: m.hasta, dias: +m.dias, nota: m.nota });
      this.guardando = true;
      try {
        const ok = await mock.set('vacaciones_tomadas', l);
        if (mock.generacion !== gen) return;
        if (!ok) {
          mock.actualizar('vacaciones_tomadas', x => (x || []).filter(y => y.id !== id), []);
          toast('Las vacaciones no se registraron: revise los datos e intente de nuevo', 'err');
          return await this.recargar(true);
        }
        await this.recargar(false);
        if (this.modal === m) this.modal = null;
        toast('Vacaciones registradas', 'ok');
      } finally { this.guardando = false; }
    },
    // 4.42 (L8): los días que pagó una liquidación ya pagada no se eliminan (el servidor tampoco lo permite). Lo demás espera la
    // respuesta: si no se eliminó, el registro vuelve a la tabla y la baja no queda esperando para subir con el próximo guardado
    async eliminar(v) {
      if (this.guardando) return;
      const lq = this.liquidacionPagada(v);
      if (lq) return toast('Esos días se pagaron en la liquidación ' + (lq.numero || '') + ', que ya está pagada: no se eliminan. Si faltó pagar algo, guarde la diferencia como liquidación adicional', 'err');
      if (!confirm('¿Eliminar este registro de vacaciones?')) return;
      if (!mock.puedeGuardar()) return;
      const gen = mock.generacion, original = vacacionesTomadas().find(x => x.id === v.id);
      if (!original) return this.recargar(false);                    // ya no está: otra persona lo eliminó
      this.guardando = true;
      try {
        const ok = await mock.set('vacaciones_tomadas', vacacionesTomadas().filter(x => x.id !== v.id));
        if (mock.generacion !== gen) return;
        if (!ok) {
          mock.actualizar('vacaciones_tomadas', x => ((x || []).some(y => y.id === original.id) ? x : [...(x || []), original]), []);
          toast('El registro de vacaciones no se eliminó', 'err');
          return await this.recargar(true);
        }
        await this.recargar(false);
        toast('Registro eliminado');
      } finally { this.guardando = false; }
    },
    async documento(formato) {
      const M = v => money(v || 0);
      const cols = [{ key: 'nombre_completo', label: 'Empleado' }, { key: 'ingreso', label: 'Ingreso' }, { key: 'meses', label: 'Meses', num: true }, { key: 'ganados', label: 'Ganados', num: true }, { key: 'disfrutados', label: 'Disfrutados', num: true }, { key: 'saldo', label: 'Saldo (días)', num: true }, { key: 'valor', label: 'Valor del saldo', num: true }, { key: 'estado', label: 'Estado' }];
      const rows = this.rows.map(r => ({ nombre_completo: r.nombre_completo, ingreso: fecha(r.fecha_ingreso), meses: String(r.meses), ganados: String(r.ganados), disfrutados: String(r.disfrutados), saldo: String(r.saldo), valor: M(r.valor), estado: r.estado }));
      const hist = { titulo: 'Vacaciones disfrutadas', columnas: [{ key: 'empleado', label: 'Empleado' }, { key: 'desde', label: 'Desde' }, { key: 'hasta', label: 'Hasta' }, { key: 'dias', label: 'Días', num: true }, { key: 'nota', label: 'Nota' }], filas: this.historial.map(v => ({ empleado: v.empleado, desde: fecha(v.desde), hasta: fecha(v.hasta), dias: String(v.dias), nota: v.nota || '' })) };
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'vacaciones', cols, rows, { titulo: 'Estado de vacaciones', registrar: a => registrarExportable(a, 'Estado de vacaciones', true) });   // 4.17
      try { await descargarReporte(formato, { titulo: 'Estado de vacaciones', subtitulo: 'Días ganados (12 por cada 50 semanas más uno por mes), disfrutados y saldo por empleado; el valor del saldo usa el salario diario actual.', periodo: 'Al ' + fecha(hoy()), kpis: [{ t: 'Empleados', v: String(this.rows.length) }, { t: 'Días de saldo (activos)', v: String(this.rows.filter(r => r.activo !== false).reduce((s, r) => s + r.saldo, 0)) }, { t: 'Valor del saldo', v: M(this.totalValor) }, { t: 'Con más de 24 días', v: String(this.acumulados.length) }], cols, rows, secciones: this.historial.length ? [hist] : [], nota: this.acumulados.length ? 'Empleados con más de 24 días acumulados: ' + this.acumulados.map(r => r.nombre_completo).join(', ') + '. Programe su disfrute: las vacaciones no se acumulan (art. 158).' : null, archivo: 'vacaciones', privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  async created() { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
  template: `
  <div class="page">
    <PageHead title="Vacaciones" sub="Un día de vacaciones por cada mes trabajado (dos semanas por cada cincuenta semanas, Código de Trabajo art. 153). El saldo se paga en la liquidación si no se disfrutó." :crumbs="[{label:'Recursos humanos'},{label:'Vacaciones'}]">
      <button class="btn sec" @click="documento('pdf')" :disabled="!lista.length">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!lista.length">⤓ Word</button><button class="btn sec" @click="documento('xlsx')" :disabled="!lista.length">⤓ Excel</button><button class="btn sec" @click="documento('csv')" :disabled="!lista.length">⤓ CSV</button>
      <button class="btn" @click="abrir(null)" :disabled="!lista.length">+ Registrar vacaciones</button>
    </PageHead>
    <div class="alert warn" v-if="acumulados.length"><b>{{acumulados.length}}</b> empleado(s) con 24 días o más sin disfrutar ({{acumulados.map(r => r.nombre_completo).join(', ')}}): programe sus vacaciones; la ley no permite acumularlas.</div>
    <div class="card pad0"><DataTable :rows="rows" :columns="columns" empty-title="Sin empleados" empty-text="Registre empleados para llevar sus vacaciones.">
      <template #actions="{row}"><button class="btn sm sec" @click.stop="abrir(row)">Registrar días</button></template>
    </DataTable></div>
    <div class="card"><h2>Vacaciones disfrutadas</h2>
      <Empty v-if="!historial.length" icon="🏖" title="Sin vacaciones registradas" text="Registre los días que cada persona disfruta para descontarlos del saldo."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Empleado</th><th>Desde</th><th>Hasta</th><th class="num">Días</th><th>Nota</th><th></th></tr></thead>
        <tbody><tr v-for="v in historial" :key="v.id"><td>{{v.empleado}}</td><td>{{fecha(v.desde)}}</td><td>{{fecha(v.hasta)}}</td><td class="num">{{v.dias}}</td><td>{{v.nota||'—'}}</td><td><span v-if="v.liquidacion_pagada" class="badge ok" :title="'Estos días se pagaron en la liquidación ' + v.liquidacion_pagada + ', que ya está pagada: no se eliminan'">Pagada</span><button v-else class="btn icon" @click="eliminar(v)" :disabled="guardando" title="Eliminar">🗑</button></td></tr></tbody></table></div>
    </div>
    <Modal v-if="modal" title="Registrar vacaciones" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Empleado" req style="grid-column:1/-1"><select v-model.number="modal.empleado_id"><option v-for="e in lista" :key="e.id" :value="e.id">{{nombreCompleto(e)}}</option></select></Field>
        <Field label="Desde" req><input type="date" v-model="modal.desde"></Field>
        <Field label="Hasta" req><input type="date" v-model="modal.hasta"></Field>
        <Field label="Días" req help="Se calculan sin domingos; puede corregirlos"><input type="number" min="0.5" step="0.5" v-model.number="modal.dias" @input="modal.manual=true"></Field>
        <Field label="Nota"><input v-model="modal.nota"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { nombreCompleto }; },
};
