// 3.94: marca de asistencia desde la barra del sistema (ícono ⏱): el empleado elige la marca y la confirma con su código de
// empleado y su PIN de 4 números (la misma clave del quiosco, que se asigna en Recursos humanos › Marcas).
import { api, toast } from '../../api.js';

const TIPOS = [['entrada', 'Entrada'], ['pausa', 'Salida a almuerzo o pausa'], ['regreso', 'Regreso'], ['salida', 'Salida']];
const uuid = () => { try { return crypto.randomUUID(); } catch { return String(Date.now()) + Math.random().toString(16).slice(2); } };

export default {
  emits: ['close'],
  data() { return { TIPOS, tipo: 'entrada', codigo: '', pin: '', enviando: false, error: '', hecho: null, peticion: uuid() }; },
  methods: {
    async marcar() {
      this.error = '';
      if (!this.codigo.trim()) { this.error = 'Escriba su código de empleado'; return; }
      if (!/^[0-9]{4,8}$/.test(this.pin)) { this.error = 'El PIN es de 4 números'; return; }
      this.enviando = true;
      try {
        const r = await api('/api/asistencia/sistema/marcar', { method: 'POST', body: { codigo: this.codigo.trim(), clave: this.pin, tipo: this.tipo, clave_peticion: this.peticion } });
        this.hecho = r.marca; this.pin = '';
        toast((r.marca.tipo_nombre || 'Marca') + ' registrada: ' + (r.marca.empleado || '') + ' · ' + r.marca.hora, 'ok');
        setTimeout(() => this.$emit('close'), 2500);
      } catch (e) { this.error = e.message; this.pin = ''; this.peticion = uuid(); }
      this.enviando = false;
    },
  },
  template: `
  <Modal title="Marcar asistencia" @close="$emit('close')">
    <div v-if="hecho" class="alert ok" style="font-size:15px">✓ {{hecho.tipo_nombre}} registrada · {{hecho.empleado}} · {{hecho.hora}}</div>
    <form v-else @submit.prevent="marcar">
      <p class="small muted" style="margin:0 0 10px">Elija la marca y confírmela con su código de empleado y su PIN.</p>
      <div class="grid cols-2" style="gap:8px;margin-bottom:12px">
        <button v-for="[k, n] in TIPOS" :key="k" type="button" class="btn" :class="tipo === k ? '' : 'sec'" @click="tipo = k">{{n}}</button>
      </div>
      <div class="grid cols-2">
        <Field label="Código de empleado"><input v-model="codigo" maxlength="4" inputmode="numeric" autocomplete="off"></Field>
        <Field label="PIN (4 números)"><input v-model="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off"></Field>
      </div>
      <p v-if="error" style="color:var(--danger);margin:8px 0 0">{{error}}</p>
      <button class="btn" type="submit" :disabled="enviando" style="width:100%;margin-top:10px">{{enviando ? 'Marcando…' : 'Confirmar marca'}}</button>
    </form>
  </Modal>`,
};
