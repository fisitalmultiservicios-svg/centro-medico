// Recursos humanos › Liquidaciones: cálculo de preaviso (art. 28), cesantía (art. 29), vacaciones no disfrutadas (art. 153),
// aguinaldo proporcional (Ley 2412) y salario pendiente según el motivo de salida. El salario promedio y lo devengado para el
// aguinaldo salen de las planillas PAGADAS (4.7: las generadas sin pagar se avisan y no se suman). Al guardar, el empleado queda
// inactivo; después se marca pagada (sale de Bancos) y se envía por correo al empleado. 4.7: una liquidación pagada no se cambia ni
// se elimina; si faltó pagar algo, se calcula de nuevo la liquidación completa y se guarda solo la DIFERENCIA como liquidación
// adicional ligada a la original (adicional, referencia_id), que se paga, se envía y (sin pagar) se elimina como cualquier otra.
// 4.42: si la persona tiene usuario para entrar al sistema, el cuadro «Marcar pagada» pregunta si se le quita el acceso (accesoDe,
// quitarAcceso): marcado en «sí» de antemano cuando consta que la cuenta es de esa persona, nunca sin preguntar, y solo después de que
// el pago quedó guardado.
import { api, abrirArchivo, money, fmt, fecha, hoy, toast, mock } from '../../api.js';
import { empleados, guardarEmpleados, nombreCompleto, MOTIVOS, paraServidor, diasDisfrutados, promedioSalarial, devengadoDesde, inicioAguinaldo, liquidaciones as liquidacionesGuardadas, planillas as planillasGuardadas } from './_datos.js';
import { esPagada, planillasSinPagarDe, diasDisfrutadosSinLiquidacion, diferenciaLiquidacion, liquidacionesDelContrato } from './_datos.js';
import { store, sesion } from '../../app.js';
import { cuentaPrincipal, cuentasParaMovimientos, registrarMovimientoBanco, revertirMovimientoBanco, refUnica, problemaMoneda } from '../bancos/cuentas.js';
import { descargarReporte, registrarExportable, elegirFormato } from '../reportes/_montos.js';

// Liquidación en PDF o Word: datos del empleado y de la salida, rubros con días, monto y base legal, CCSS y total.
export function documentoLiquidacion(l, emp, formato) {
  const M = v => money(v || 0), kv = (dato, valor) => ({ dato, valor: valor === null || valor === undefined || valor === '' ? '—' : String(valor) });
  const a = l.antiguedad || {}, motivo = l.motivo_nombre || (MOTIVOS.find(m => m[0] === l.motivo) || [l.motivo, l.motivo])[1];
  const datos = [kv('Empleado', l.nombre || (emp && nombreCompleto(emp))), kv('Identificación', emp && emp.numero_id), kv('Puesto', emp && emp.puesto), kv('Fecha de ingreso', emp && emp.fecha_ingreso ? fecha(emp.fecha_ingreso) : ''), kv('Fecha de salida', l.fecha_salida ? fecha(l.fecha_salida) : ''),
    kv('Motivo de salida', motivo), kv('Antigüedad', a.anios !== undefined ? a.anios + ' años y ' + (a.meses % 12) + ' meses (' + a.dias + ' días)' : ''), kv('Salario mensual de cálculo', M(l.salario_mensual)), kv('Salario diario', l.salario_diario ? M(l.salario_diario) : ''), kv('Estado', l.estado || 'Calculada (sin guardar)'),
    ...(l.pagada_en ? [kv('Pagada', fecha(l.pagada_en) + (l.cuenta ? ' desde ' + l.cuenta : ''))] : [])];
  const rubros = (l.rubros || []).map(x => ({ rubro: x.rubro, dias: fmt(x.dias || 0, 2), monto: M(x.monto), base: x.base || '' }));
  const secciones = [{ titulo: 'Datos de la liquidación', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor' }], filas: datos },
    { titulo: 'Rubros', columnas: [{ key: 'rubro', label: 'Rubro' }, { key: 'dias', label: 'Días', num: true }, { key: 'monto', label: 'Monto', num: true }, { key: 'base', label: 'Base' }], filas: rubros, totales: [{ t: 'Total de la liquidación', v: M(l.total) }] }];
  // 4.7 (C1): también la renta retenida sobre el salario pendiente y las vacaciones (calculada con lo ya pagado en el mes de la salida)
  if (l.ccss_obrera || l.ccss_patronal || +l.renta) secciones.push({ titulo: 'Seguridad social y renta sobre los rubros salariales', columnas: [{ key: 'dato', label: 'Concepto' }, { key: 'valor', label: 'Monto', num: true }], filas: [kv('CCSS retenida al trabajador', M(l.ccss_obrera)), kv('CCSS patronal', M(l.ccss_patronal)), ...(+l.renta ? [kv('Impuesto sobre la renta retenido', M(l.renta))] : [])] });
  return descargarReporte(formato, { titulo: 'Liquidación ' + (l.numero || 'calculada') + ' · ' + (l.nombre || (emp && nombreCompleto(emp)) || ''), subtitulo: 'Preaviso (art. 28), cesantía (art. 29), vacaciones (art. 153), aguinaldo proporcional (Ley 2412) y salario pendiente, según el motivo de salida.',
    periodo: 'Salida ' + (l.fecha_salida ? fecha(l.fecha_salida) : '—'), kpis: [{ t: 'Total de la liquidación', v: M(l.total) }, { t: 'Salario mensual', v: M(l.salario_mensual) }, { t: 'Antigüedad', v: a.anios !== undefined ? a.anios + ' años, ' + (a.meses % 12) + ' meses' : '—' }, { t: 'Motivo', v: motivo }],
    cols: [], rows: [], secciones, nota: (l.nota || 'El aguinaldo y las vacaciones proporcionales se pagan en toda salida; preaviso y cesantía solo con responsabilidad patronal.') + ' Recibí conforme: ______________________   Firma del patrono: ______________________', archivo: 'liquidacion_' + (l.numero || (emp && emp.numero_id) || 'calc') });
}

const ocupadas = new Set();
// 4.42: abrir el cuadro «Marcar pagada» espera al servidor (¿la persona tiene usuario?): si mientras tanto se pulsa otra liquidación,
// se abre solo el cuadro del último clic (una respuesta que llega tarde no cambia el cuadro que ya está a la vista). Otro clic en la
// MISMA liquidación no empieza otra espera: mientras llega la respuesta su botón dice «Abriendo…» (data › abriendo)
let turnoPago = 0;

export default {
  props: ['params'],
  data() {
    const lista = empleados(); const pre = this.params && this.params.empleado ? +this.params.empleado : null;
    const primero = pre || (lista[0] ? lista[0].id : null);
    return { lista, guardadas: liquidacionesGuardadas(), f: { empleado_id: primero, fecha_salida: hoy(), motivo: 'despido_con', dias_pendientes: 0, dias_vac_disfrutados: primero ? diasDisfrutadosSinLiquidacion(primero) : 0, salario_promedio: null, preaviso_otorgado: false, usar_devengado: null },
             r: null, calculando: false, ver: null, pagar: null, cuentasLista: null, enviando: null, revision: null, abriendo: null, MOTIVOS };
  },
  computed: {
    emp() { return this.lista.find(e => e.id === this.f.empleado_id); },
    correoListo() { const e = store.empresa || {}; return !!((e.rrhh_smtp_host && e.rrhh_smtp_remitente) || e.smtp_host); },
    // promedio de las planillas de los últimos 6 meses (arts. 29 y 153) y lo devengado para el aguinaldo (desde el 1 de diciembre).
    // 4.7 (C6): el promedio es por el tiempo que cubren las planillas pagadas (mesesPromedio, con un decimal si hace falta). (C7) Lo devengado
    // empieza en la fecha de ingreso si es posterior (inicioAg, como la cobertura y el servidor): a un recontratado no se le paga otra
    // vez el aguinaldo del contrato anterior, que ya pagó su liquidación
    promedio() { return this.emp ? promedioSalarial(this.emp.id, this.f.fecha_salida, 6) : null; },
    mesesPromedio() { const m = this.promedio ? Math.round((+this.promedio.meses || 0) * 10) / 10 : 0; return fmt(m, Number.isInteger(m) ? 0 : 1); },
    inicioAg() { if (!this.f.fecha_salida) return ''; const ini = inicioAguinaldo(this.f.fecha_salida); return this.emp && this.emp.fecha_ingreso && this.emp.fecha_ingreso > ini ? this.emp.fecha_ingreso : ini; },
    devengado() { return this.emp && this.f.fecha_salida ? devengadoDesde(this.emp.id, this.inicioAg, this.f.fecha_salida) : 0; },
    // 4.7 (C1): lo ya pagado y retenido al empleado en el mes de la salida: planillas pagadas que cierran en ese mes (complementarias
    // incluidas, desde su ingreso). Con eso el servidor calcula la renta del salario pendiente y de las vacaciones sobre el mes completo
    previoMes() {
      const out = { bruto_previo: 0, renta_previa: 0 }, s = String(this.f.fecha_salida || '');
      if (!this.emp || !/^\d{4}-\d{2}/.test(s)) return out;
      const mes = s.slice(0, 7), ing = this.emp.fecha_ingreso || '';
      for (const p of planillasGuardadas()) {
        const f = String(p.hasta || p.fecha || '');
        if (!esPagada(p) || !f.startsWith(mes) || (ing && f < ing)) continue;
        for (const x of p.filas || []) if (x.empleado_id === this.emp.id) { out.bruto_previo += +x.bruto || 0; out.renta_previa += +x.renta || 0; }
      }
      out.bruto_previo = Math.round(out.bruto_previo * 100) / 100; out.renta_previa = Math.round(out.renta_previa * 100) / 100;
      return out;
    },
    // ¿Las planillas PAGADAS cubren el período del aguinaldo? (4.7: las sin pagar no cuentan, como en lo devengado). Si el sistema
    // se adoptó a mitad de año, usar solo lo devengado en planillas dejaría el aguinaldo corto: en ese caso se propone la estimación
    // con el salario de cálculo.
    cobertura() {
      if (!this.emp || !this.f.fecha_salida) return { con: 0, total: 0 };
      const ini = inicioAguinaldo(this.f.fecha_salida), desde = this.emp.fecha_ingreso && this.emp.fecha_ingreso > ini ? this.emp.fecha_ingreso : ini, hasta = this.f.fecha_salida;
      const meses = new Set(); for (let d = new Date(desde.slice(0, 7) + '-01T00:00:00'); d <= new Date(hasta + 'T00:00:00'); d.setMonth(d.getMonth() + 1)) meses.add(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'));
      const con = new Set(); for (const p of planillasGuardadas()) { const f = String(p.hasta || ''); if (esPagada(p) && f >= desde && f <= hasta && (p.filas || []).some(x => x.empleado_id === this.emp.id)) con.add(f.slice(0, 7)); }
      return { con: con.size, total: meses.size };
    },
    coberturaCompleta() { return this.devengado > 0 && this.cobertura.con >= Math.max(1, this.cobertura.total - 1); },
    // 4.7: planillas del empleado sin pagar en el período del promedio o del aguinaldo (no se suman: se avisan) y sus liquidaciones ya
    // pagadas: con ellas, el cálculo nuevo se guarda solo como la diferencia (liquidación adicional)
    sinPagar() { if (!this.emp || !this.f.fecha_salida) return []; const ini = inicioAguinaldo(this.f.fecha_salida), pd = this.promedio && this.promedio.desde; return planillasSinPagarDe(this.emp.id, pd && pd < ini ? pd : ini, this.f.fecha_salida); },
    pagadas() { return this.emp ? liquidacionesDelContrato(this.guardadas, this.emp).filter(esPagada) : []; },
    diferencia() { return this.r && this.pagadas.length ? this.agregarRenta(diferenciaLiquidacion(this.r, this.pagadas), this.pagadas) : null; },
    usarDevengado: { get() { return this.f.usar_devengado === null ? this.coberturaCompleta : this.f.usar_devengado; }, set(v) { this.f.usar_devengado = v; } },
    rows() { const n = Object.fromEntries(this.lista.map(e => [e.id, nombreCompleto(e)])); return this.guardadas.slice().sort((a, b) => b.id - a.id).map(l => ({ ...l, empleado: n[l.empleado_id] || l.nombre || '—', motivo_nombre: (MOTIVOS.find(m => m[0] === l.motivo) || [l.motivo, l.motivo])[1] })); },
    columns() { return [{ key: 'numero', label: 'Liquidación', mono: true, link: r => this.ver = r }, { key: 'empleado', label: 'Empleado' }, { key: 'fecha_salida', label: 'Salida', fmt: 'date' }, { key: 'motivo_nombre', label: 'Motivo' }, { key: 'total', label: 'Total', num: true, fmt: 'money' }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    contratoFin() { return this.emp && this.emp.tipo_contrato && this.emp.tipo_contrato !== 'indefinido' && this.emp.fecha_fin_contrato ? this.emp.fecha_fin_contrato : null; },
  },
  watch: { 'f.empleado_id'(v) { this.f.dias_vac_disfrutados = diasDisfrutadosSinLiquidacion(v); this.r = null; if (this.contratoFin) { this.f.motivo = 'fin_contrato'; this.f.fecha_salida = this.contratoFin; } }, f: { deep: true, handler() { this.r = null; } } },   // cualquier cambio obliga a recalcular (R152)
  methods: {
    money, fmt, fecha,
    usarPromedio() { if (this.promedio && this.promedio.promedio) this.f.salario_promedio = this.promedio.promedio; },
    // 4.7 (C1): la renta de una liquidación ADICIONAL: la del cálculo completo (con lo ya pagado en el mes) menos la ya retenida en lo
    // pagado, sin pasar de lo salarial de la diferencia después de la CCSS; va como rubro de deducción y se rebaja del total. Lo que no
    // quepa lo avisa el informe de planilla del mes
    agregarRenta(d, previas) {
      if (!d) return d;
      const r2 = n => Math.round((+n || 0) * 100) / 100, rentaYa = r2((previas || []).reduce((s, l) => s + (+(l && l.renta) || 0), 0));
      d.renta = r2(Math.min(Math.max(0, r2((+(this.r && this.r.renta) || 0) - rentaYa)), Math.max(0, r2((+d.base_ccss || 0) - (+d.ccss_obrera || 0)))));
      if (d.renta > 0) { d.rubros.push({ rubro: 'Deducción impuesto sobre la renta', dias: 0, monto: -d.renta, base: 'Renta del cálculo completo (' + money(this.r.renta) + ') menos la ya retenida (' + money(rentaYa) + ')', categoria: 'renta' }); d.total = r2(d.total - d.renta); }
      return d;
    },
    async documento(l, formato) {
      const emp = this.lista.find(e => e.id === (l.empleado_id || (this.emp && this.emp.id)));
      try { await documentoLiquidacion(l, emp, formato); } catch (e) { toast(e.message, 'err'); }
    },
    async calcular() {
      if (!this.emp) return toast('Seleccione el empleado', 'err');
      if (!this.f.fecha_salida) return toast('Indique la fecha de salida', 'err');
      if (this.emp.fecha_ingreso && this.f.fecha_salida < this.emp.fecha_ingreso) return toast('La fecha de salida es anterior al ingreso', 'err');
      this.calculando = true;
      const firma = JSON.stringify(this.f);
      try { const res = await api('/api/rrhh/liquidacion', { method: 'POST', body: { empleado: paraServidor(this.emp), fecha_salida: this.f.fecha_salida, motivo: this.f.motivo, dias_vac_disfrutados: +this.f.dias_vac_disfrutados || 0, dias_pendientes: +this.f.dias_pendientes || 0, salario_promedio_mensual: this.f.salario_promedio || null, preaviso_otorgado: !!this.f.preaviso_otorgado, devengado_aguinaldo: this.usarDevengado && this.devengado > 0 ? this.devengado : null, bruto_previo: this.previoMes.bruto_previo, renta_previa: this.previoMes.renta_previa } }); if (firma === JSON.stringify(this.f)) this.r = res; }
      catch (e) { toast(e.message, 'err'); }
      this.calculando = false;
    },
    guardar() {
      if (!this.r) return toast('Calcule la liquidación primero', 'err');
      if (!mock.puedeGuardar()) return;
      // (R152) una pendiente de pago se corrige eliminándola y calculando de nuevo; 4.7: una PAGADA no se cambia: se guarda la diferencia
      const previas = liquidacionesDelContrato(liquidacionesGuardadas(), this.emp), pendiente = previas.find(l => !esPagada(l));
      if (pendiente) return toast(nombreCompleto(this.emp) + ' ya tiene la liquidación ' + pendiente.numero + ' pendiente de pago: para corregirla, elimínela y calcule de nuevo; si ya la entregó, márquela pagada y guarde aquí solo la diferencia como liquidación adicional', 'err');
      if (previas.length) return this.guardarAdicional(previas);
      if (!confirm('Se guardará la liquidación de ' + nombreCompleto(this.emp) + ' por ' + money(this.r.total) + ' y el empleado quedará inactivo desde el ' + fecha(this.f.fecha_salida) + '. ¿Continuar?')) return;
      const l = liquidacionesGuardadas(); const id = mock.nextId(l, 'liquidaciones');
      l.push({ id, numero: 'LQ-' + String(id).padStart(4, '0'), empleado_id: this.emp.id, nombre: nombreCompleto(this.emp), fecha: hoy(), fecha_salida: this.f.fecha_salida, motivo: this.f.motivo, motivo_nombre: this.r.motivo_nombre, rubros: this.r.rubros, total: this.r.total, ccss_obrera: this.r.ccss_obrera || 0, ccss_patronal: this.r.ccss_patronal || 0, renta: this.r.renta || 0, antiguedad: this.r.antiguedad, salario_mensual: this.r.salario_mensual, salario_diario: this.r.salario_diario, nota: this.r.nota, estado: 'Pendiente de pago' });
      mock.set('liquidaciones', l); this.guardadas = l;
      // los días de vacaciones pagados en la liquidación quedan registrados como disfrutados (R156)
      const vacPag = (this.r.rubros || []).find(x => /Vacaciones/i.test(x.rubro));
      if (vacPag && +vacPag.dias > 0) { const vt = mock.get('vacaciones_tomadas', []) || []; vt.push({ id: mock.nextId(vt, 'vacaciones_tomadas'), empleado_id: this.emp.id, desde: this.f.fecha_salida, hasta: this.f.fecha_salida, dias: +vacPag.dias, nota: 'Pagadas en la liquidación LQ-' + String(id).padStart(4, '0'), liquidacion_id: id }); mock.set('vacaciones_tomadas', vt); }
      const emps = empleados(); const e = emps.find(x => x.id === this.emp.id); if (e) { e.activo = false; e.fecha_salida = this.f.fecha_salida; guardarEmpleados(emps); this.lista = emps; }
      // los ingresos fijos del empleado se detienen (marcados con la liquidación: si se elimina, se reactivan); los préstamos pendientes quedan a la vista
      mock.actualizar('rrhh_conceptos', c => (c || []).map(x => (x.empleado_id === this.emp.id && x.tipo !== 'deduccion' && x.activa !== false ? { ...x, activa: false, pausado_por: id } : x)), []);
      toast('Liquidación guardada: márquela pagada cuando entregue el dinero', 'ok'); this.r = null;
    },
    // 4.7: liquidación ADICIONAL: la original (y sus adicionales) ya están pagadas y no se cambian; con el cálculo completo corregido se
    // guarda solo lo que falta por rubro (diferenciaLiquidacion), ligada a la original y con su misma fecha de salida. Se paga, se envía
    // y (sin pagar) se elimina como cualquier liquidación; los días de vacaciones de la diferencia quedan registrados como disfrutados.
    guardarAdicional(previas) {
      const orig = previas.find(l => !l.adicional) || previas[0], d = this.agregarRenta(diferenciaLiquidacion(this.r, previas), previas);
      if (orig.fecha_salida && this.f.fecha_salida !== orig.fecha_salida) return toast('La diferencia se calcula con la misma fecha de salida de la liquidación ' + orig.numero + ' (' + fecha(orig.fecha_salida) + '): corríjala y calcule de nuevo. Si es otra salida porque lo volvieron a contratar, actualice primero la fecha de ingreso en su ficha', 'err');
      if (!(d.total > 0)) return toast('No queda nada por pagar: lo calculado no supera lo ya pagado en ' + previas.map(l => l.numero).join(', ') + (d.de_mas.length ? ' (hay rubros pagados de más; no se rebajan aquí)' : ''), 'err');
      const deMas = d.de_mas.length ? '\n\nPagado de más (no se rebaja aquí; revíselo con su contador): ' + d.de_mas.map(x => x.rubro + ' ' + money(x.monto)).join(', ') + '.' : '';
      if (!confirm('La liquidación ' + orig.numero + ' de ' + nombreCompleto(this.emp) + ' ya está pagada y no se cambia.\n\nSe guardará una LIQUIDACIÓN ADICIONAL, ligada a ' + orig.numero + ', solo con la diferencia:\n' + d.rubros.map(x => '· ' + x.rubro + ': ' + money(x.monto)).join('\n') + '\nTotal: ' + money(d.total) + deMas + '\n\n¿Continuar?')) return;
      const l = liquidacionesGuardadas(); const id = mock.nextId(l, 'liquidaciones'), numero = 'LQ-' + String(id).padStart(4, '0');
      l.push({ id, numero, adicional: true, referencia_id: orig.id, referencia_numero: orig.numero, empleado_id: this.emp.id, nombre: nombreCompleto(this.emp), fecha: hoy(), fecha_salida: this.f.fecha_salida, motivo: this.f.motivo, motivo_nombre: this.r.motivo_nombre, rubros: d.rubros, total: d.total, ccss_obrera: d.ccss_obrera, ccss_patronal: d.ccss_patronal, renta: d.renta || 0, antiguedad: this.r.antiguedad, salario_mensual: this.r.salario_mensual, salario_diario: this.r.salario_diario, nota: 'Liquidación adicional de ' + orig.numero + ' (ya pagada): solo la diferencia que faltaba pagar. ' + (this.r.nota || ''), estado: 'Pendiente de pago' });
      mock.set('liquidaciones', l); this.guardadas = l;
      const vacPag = d.rubros.find(x => /Vacaciones/i.test(x.rubro));
      if (vacPag && +vacPag.dias > 0) { const vt = mock.get('vacaciones_tomadas', []) || []; vt.push({ id: mock.nextId(vt, 'vacaciones_tomadas'), empleado_id: this.emp.id, desde: this.f.fecha_salida, hasta: this.f.fecha_salida, dias: +vacPag.dias, nota: 'Pagadas en la liquidación adicional ' + numero, liquidacion_id: id }); mock.set('vacaciones_tomadas', vt); }
      toast('Liquidación adicional ' + numero + ' guardada por ' + money(d.total) + ': márquela pagada cuando entregue el dinero', 'ok'); this.r = null;
    },
    // 4.42: junto con las cuentas se averigua si la persona tiene usuario para entrar al sistema (accesoDe): el cuadro abre ya con la pregunta.
    // Mientras se espera al servidor, `abriendo` lleva la liquidación (su botón dice «Abriendo…» y queda deshabilitado) y otro clic en
    // esa misma liquidación no vuelve a empezar la espera; el turno queda para los clics en liquidaciones distintas
    async abrirPago(l) {
      if (this.abriendo === l.id) return;
      const turno = ++turnoPago; this.abriendo = l.id;
      let cuentas, acceso;
      try { [cuentas, acceso] = await Promise.all([this.cuentasLista || cuentasParaMovimientos(), this.accesoDe(l)]); }
      finally { if (turno === turnoPago) this.abriendo = null; }
      this.cuentasLista = cuentas;
      if (turno !== turnoPago) return;
      const b = cuentaPrincipal('CRC', this.cuentasLista); this.pagar = { l, cuenta: b ? b.nombre : '', fecha: hoy(), enviar: this.correoListo && (store.empresa?.rrhh_correo_auto !== false), acceso };
      this.revisarCuentas('liquidacion', l);
    },
    async confirmarPago() {
      if (!mock.puedeGuardar()) return;
      const { cuenta, fecha: f } = this.pagar, id = this.pagar.l.id;
      if (!cuenta) return toast('Seleccione la cuenta de la que sale el pago', 'err');
      if (problemaMoneda(cuenta, 'CRC', 1, this.cuentasLista || [])) return toast('La liquidación se paga en colones: elija una cuenta en colones', 'err');
      if (ocupadas.has(id)) return;
      ocupadas.add(id); const gen = mock.generacion;
      try {
        const ref = refUnica('liquidacion'); let l = null;
        // 4.7: asiento_pago, en el mismo guardado que la pasa a pagada: Contabilidad genera el asiento de su pago (las pagadas antes no)
        this.guardadas = mock.actualizar('liquidaciones', lista => (lista || []).map(x => (x.id === id ? (l = { ...x, estado: 'Pagada', cuenta, pagada_en: f, ref_mov: ref, asiento_pago: true }) : x)), []);
        if (!l) return toast('La liquidación ya no existe; recargue la página', 'err');
        if (mock.generacion !== gen || !mock.cargado) return;
        registrarMovimientoBanco(cuenta, -l.total, f, 'Liquidación ' + l.numero + ' · ' + l.nombre, ref, true, 'CRC', 1);
        const enviar = this.pagar.enviar, acceso = this.pagar.acceso; this.pagar = null; this.ver = null;
        toast('Liquidación ' + l.numero + ' marcada como pagada: ' + money(l.total) + ' desde ' + cuenta, 'ok');
        // 4.42: solo si en el cuadro quedó marcado «Quitarle el acceso»: primero el acceso y después el correo (si mientras tanto se
        // cambió de empresa, el correo ya no se pide: iría a la otra empresa)
        if (acceso && acceso.quitar === true) await this.quitarAcceso(l, acceso);
        if (mock.generacion !== gen || !mock.cargado) return;
        if (enviar) await this.enviar(l);
      } finally { ocupadas.delete(id); }
    },
    // 4.42: el comprobante de la liquidación lo arma y lo envía el servidor con lo GUARDADO (los montos de la liquidación pagada y el
    // correo de la ficha del empleado): la pantalla solo dice cuál liquidación. Primero se guarda lo pendiente: la marca «Pagada» recién
    // puesta tiene que estar en el servidor (si no llegó a guardarse, el servidor responde que no está pagada y no envía nada)
    async enviar(l) {
      const e = this.lista.find(x => x.id === l.empleado_id) || {};
      if (!e.correo) return toast(l.nombre + ' no tiene correo registrado en su ficha', 'err');
      this.enviando = l.id;
      try {
        await mock.guardarTodo();
        const r = await api('/api/rrhh/comprobantes-pago/liquidacion/' + l.id, { method: 'POST', body: {} });
        if (r.enviados) toast('Liquidación enviada a ' + e.correo, 'ok'); else toast('No se envió: ' + (r.fallidos[0] ? r.fallidos[0].error : l.nombre + ' no tiene correo registrado en su ficha'), 'err');
      } catch (err) { toast('No se envió la liquidación: ' + err.message, 'err'); }
      this.enviando = null;
    },
    // 4.21: el comprobante de la liquidación en PDF (el mismo que llega por correo; lo arma el servidor con lo guardado). Solo pagada
    async comprobante(l) {
      const nombre = 'liquidacion_' + l.numero + '_' + String(l.nombre || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.pdf';
      try {
        await abrirArchivo('/api/rrhh/comprobante-pago/liquidacion/' + l.id + '/' + l.empleado_id, nombre);
        registrarExportable(nombre, 'Liquidación · comprobante · ' + l.nombre, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: revisión de la cuenta del cuadro «Marcar pagada»: cómo cobra la persona y lo que conviene confirmar antes de transferir
    // (transferencia sin cuenta IBAN, cuenta mal escrita o cambiada desde su último pago, total en cero). La arma el servidor con lo
    // GUARDADO (el total de la liquidación y la ficha del empleado): por eso primero se guarda lo pendiente. Solo avisa: no frena
    // «Marcar pagada»; si no se pudo revisar, lo dice y el pago sigue como siempre
    async revisarCuentas(concepto, d) {
      this.revision = { id: d.id, cargando: true, avisos: [], formas: '' };
      const vigente = () => !!this.revision && this.revision.id === d.id && this.revision.cargando;
      try {
        await mock.guardarTodo();
        const r = await api('/api/rrhh/lista-pago/' + concepto + '/' + d.id);
        if (!vigente()) return;
        const avisos = [...(r.avisos_generales || []), ...(r.filas || []).flatMap(f => (f.avisos || []).map(a => f.nombre + ': ' + a))];
        const formas = (r.por_forma || []).map(x => x.nombre + ': ' + x.empleados + ' (' + money(x.monto) + ')').join(' · ');
        this.revision = { id: d.id, cargando: false, avisos, formas };
      } catch (e) { if (vigente()) this.revision = { id: d.id, cargando: false, error: e.message, avisos: [], formas: '' }; }
    },
    // 4.42: la lista de pago de la liquidación (cómo cobra la persona: forma de pago, entidad, cuenta, total y avisos) en PDF, Excel o
    // CSV. El archivo lo arma el servidor con lo guardado, también antes de pagar; queda en el historial de descargas de Recursos humanos
    async listaPago(concepto, d, numero) {
      const formato = await elegirFormato('Lista de pago · ' + numero);
      if (!formato) return;
      const nombre = 'lista_pago_' + String(numero).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w-]+/g, '_') + '.' + formato;
      try {
        await mock.guardarTodo();
        await abrirArchivo('/api/rrhh/lista-pago/' + concepto + '/' + d.id + '?formato=' + formato, nombre);
        registrarExportable(nombre, 'Lista de pago · ' + numero, true);
        toast('Archivo ' + nombre + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    // 4.42: ¿la persona de la liquidación tiene usuario para entrar al sistema? Es el usuario que tiene el correo de acceso de su ficha
    // (usuario_correo) o su correo: la misma regla de la ficha del empleado y de la lista de empleados. Lo que devuelve es lo que muestra
    // el cuadro «Marcar pagada»: null = no entra a esta empresa (no se muestra nada); { nota } = una línea (quien paga no administra los
    // usuarios, o no se pudo revisar); con `aviso` = tiene usuario pero aquí no se le quita (se dice por qué); con `quitar` = la pregunta.
    // «Quitar el acceso» es lo que hace 🗑 en Configuración › Usuarios: la persona deja de entrar a ESTA empresa y su cuenta no se borra.
    // La pregunta sale marcada en «sí» solo si hay evidencia de que la cuenta es de ESA persona (`suya`: el usuario se creó desde su
    // ficha, o la cuenta y la ficha llevan el mismo nombre) y las fichas se pudieron traer al día; y aun así queda sin marcar si ese
    // correo es también el de otro empleado activo, si la ficha de la persona está activa o si su fecha de salida todavía no llega. Sin
    // marcar, el cuadro dice por qué. Nunca se quita sin preguntar: sin el cuadro a la vista no hay `quitar`. El cuadro muestra el
    // correo, el nombre de la cuenta y el rol, y sin esa evidencia no afirma que la cuenta sea de la persona
    async accesoDe(l) {
      if (!sesion.puede('usuarios')) return { nota: 'Si esta persona tiene usuario para entrar al sistema, pida al administrador que le quite el acceso en Configuración › Usuarios.' };
      // las fichas, al día ANTES de decidir (como eliminar() con las liquidaciones): la pantalla abierta no se entera sola de que en otra
      // pestaña o en otro equipo corrigieron el correo de la ficha o reactivaron a la persona. Con tope de espera propio (8 segundos): si
      // no se pudo comprobar, se sigue con la copia de la pestaña y la pregunta nace sin marcar
      let frescas = false, tope = null;
      try { frescas = Array.isArray(await Promise.race([mock.refrescar(['empleados'], { sinCorte: true }), new Promise(r => { tope = setTimeout(() => r(false), 8000); })])); }
      catch { frescas = false; }
      finally { clearTimeout(tope); }
      const correoDe = x => String((x && (x.usuario_correo || x.correo)) || '').trim().toLowerCase();
      const fichas = empleados(), e = fichas.find(x => x.id === l.empleado_id) || {}, correo = correoDe(e);
      if (!correo) return null;
      let usuarios = null;
      try { usuarios = await api('/api/auth/usuarios', { limite: 8000 }); }
      catch (err) { return { nota: 'No se pudo revisar si esta persona tiene usuario para entrar al sistema (' + String(err.message).replace(/\.+$/, '') + '). Revíselo después en Configuración › Usuarios.' }; }
      const u = (Array.isArray(usuarios) ? usuarios : []).find(x => !!x && String(x.correo || '').trim().toLowerCase() === correo);
      if (!u) return null;
      // ¿la cuenta es de ESTA persona? El correo de contacto de la ficha puede ser el de otra cuenta (el contador, la recepción, el
      // dueño). Evidencia: el usuario se creó desde la ficha (usuario_correo) o la cuenta y la ficha llevan el mismo nombre (sin tildes
      // ni mayúsculas: las palabras de uno están en el otro)
      const palabras = x => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean), nc = palabras(u.nombre), nf = palabras(nombreCompleto(e));
      const suya = String(e.usuario_correo || '').trim().toLowerCase() === correo || (nc.length > 0 && nf.length > 0 && (nc.every(x => nf.includes(x)) || nf.every(x => nc.includes(x))));
      const yo = sesion.usuario || {}, acceso = { id: u.id, correo: u.correo, nombre: String(u.nombre || '').trim(), rol: u.rol || '', suya };
      if (yo.soporte) return { ...acceso, aviso: 'Usted entró como otro usuario y así no se quitan accesos: lo hace el administrador de la empresa, desde su propia cuenta, en Configuración › Usuarios.' };
      if (yo.id === u.id) return { ...acceso, aviso: 'Es el usuario con el que usted está trabajando: usted no puede quitarse el acceso. Si deja la empresa, otro Administrador se lo quita en Configuración › Usuarios.' };
      if (u.admin_sistema || u.editable === false) return { ...acceso, aviso: 'Es un administrador del sistema: su acceso no se quita desde aquí. Si hace falta, pídalo a soporte.' };
      if (sesion.empresaInfo && sesion.empresaInfo.es_local) return { ...acceso, aviso: 'En el programa de escritorio no se quita el acceso: hágalo en la página web, en Configuración › Usuarios.' };
      const otros = fichas.filter(x => x.id !== e.id && x.activo !== false && correoDe(x) === correo).map(nombreCompleto), activa = e.activo !== false, advertencias = [];
      const porSalir = /^\d{4}-\d{2}-\d{2}/.test(String(l.fecha_salida || '')) && String(l.fecha_salida).slice(0, 10) > hoy();
      if (u.rol === 'Administrador') advertencias.push('Es Administrador de esta empresa: si le quita el acceso, deja de administrarla.');
      if (otros.length) advertencias.push('Ese correo también está en la ficha de ' + otros.join(', ') + (otros.length === 1 ? ', que sigue trabajando aquí: si le quita el acceso, esa persona tampoco podrá entrar.' : ', que siguen trabajando aquí: si le quita el acceso, esas personas tampoco podrán entrar.') + ' Por eso queda sin marcar.');
      else if (activa) advertencias.push('La ficha de esta persona está activa (sigue o volvió a trabajar aquí). Por eso queda sin marcar: márquelo solo si ya no debe entrar al sistema.');
      else if (porSalir) advertencias.push('La salida de esta persona es el ' + fecha(l.fecha_salida) + ': todavía trabaja aquí. Por eso queda sin marcar: márquelo si ya no debe entrar al sistema.');
      if (!suya) advertencias.push((acceso.nombre ? 'La cuenta está a nombre de «' + acceso.nombre + '»' : 'La cuenta no tiene nombre') + ' y con la ficha de ' + (nf.length ? nombreCompleto(e) : (l.nombre || 'esta persona')) + ' solo coincide el correo: confirme que es el usuario de esa persona antes de marcarlo. Por eso queda sin marcar.');
      if (!frescas) advertencias.push('No se pudo comprobar que la ficha de esta persona esté al día. Por eso queda sin marcar: revise que sea la misma persona antes de marcarlo.');
      return { ...acceso, aviso: '', quitar: frescas && suya && !otros.length && !activa && !porSalir, advertencias };
    },
    // 4.42: quita el acceso que se preguntó en el cuadro «Marcar pagada» (DELETE /api/auth/usuarios/{id}, la misma ruta de Configuración ›
    // Usuarios: el servidor no deja quitarse a uno mismo, ni al único Administrador, ni a un administrador del sistema, y lo anota en el
    // historial). Va DESPUÉS de que el pago quedó guardado en el servidor y antes del correo: primero se sube lo pendiente y se comprueba
    // que ESTE pago (su referencia) sigue en lo guardado; si el servidor lo rechazó o no hay conexión, no se quita nada y se avisa. Si lo
    // que falla es quitar el acceso, la liquidación queda pagada igual y se dice claro dónde quitarlo a mano. Repetirlo no hace daño
    async quitarAcceso(l, acceso) {
      if (!acceso || acceso.quitar !== true || acceso.aviso || !acceso.id) return false;
      const gen = mock.generacion;
      let guardado = false;
      try { guardado = await mock.guardarTodo(); } catch { guardado = false; }
      if (mock.generacion !== gen || !mock.cargado) return false;
      if (!guardado || !l.ref_mov || !liquidacionesGuardadas().some(x => x.ref_mov === l.ref_mov && esPagada(x))) {
        toast('No se le quitó el acceso a ' + acceso.correo + ': no se pudo confirmar que el pago de la liquidación ' + l.numero + ' quedó guardado. Cuando la vea como pagada, quítele el acceso en Configuración › Usuarios', 'err');
        return false;
      }
      try { await api('/api/auth/usuarios/' + acceso.id, { method: 'DELETE' }); }
      catch (err) {
        toast('La liquidación ' + l.numero + ' quedó pagada, pero NO se le quitó el acceso a ' + acceso.correo + ': ' + String(err.message).replace(/\.+$/, '') + '. Quíteselo en Configuración › Usuarios', 'err');
        return false;
      }
      toast(acceso.correo + ' ya no entra a esta empresa. Su cuenta no se borró: para devolverle el acceso, agréguela de nuevo en Configuración › Usuarios', 'ok');
      return true;
    },
    // 4.7: una liquidación PAGADA queda cerrada y no se elimina (el servidor también lo rechaza); una pendiente de pago, como antes.
    async eliminar(l) {
      if (ocupadas.has(l.id) || !mock.puedeGuardar()) return;
      const pagada = x => !!x && x.estado === 'Pagada', aviso = () => toast('La liquidación ' + l.numero + ' está pagada y no se elimina: si faltó pagar algo, calcúlela de nuevo con los datos corregidos y la misma fecha de salida, y guarde la diferencia como liquidación adicional', 'err');
      if (pagada(l) || pagada(liquidacionesGuardadas().find(x => x.id === l.id))) return aviso();
      if (!confirm('¿Eliminar la liquidación ' + l.numero + '? El empleado no vuelve a activarse solo.')) return;
      ocupadas.add(l.id); const gen = mock.generacion;
      try {
        await mock.refrescar(['liquidaciones'], { sinCorte: true });                    // lo último guardado: otra persona pudo pagarla mientras tanto
        if (mock.generacion !== gen || !mock.cargado) return;
        if (pagada(liquidacionesGuardadas().find(x => x.id === l.id))) { this.guardadas = liquidacionesGuardadas(); this.ver = null; return aviso(); }
        if (l.ref_mov && !(await revertirMovimientoBanco([l.ref_mov]))) return;
        if (mock.generacion !== gen || !mock.cargado) return;
        this.guardadas = mock.actualizar('liquidaciones', lista => (lista || []).filter(x => x.id !== l.id), []); this.ver = null;
        // se deshace lo que la liquidación dejó registrado: vacaciones «pagadas» y conceptos pausados (así se puede recalcular)
        mock.actualizar('vacaciones_tomadas', vt => (vt || []).filter(v => v.liquidacion_id !== l.id), []);
        mock.actualizar('rrhh_conceptos', c => (c || []).map(x => (x.pausado_por === l.id ? { ...x, activa: true, pausado_por: null } : x)), []);
        toast('Liquidación eliminada. El empleado sigue inactivo: reactívelo en su ficha si vuelve a la empresa');
      } finally { ocupadas.delete(l.id); }
    },
  },
  created() { if (this.params && this.params.empleado && this.emp) { if (this.contratoFin) { this.f.motivo = 'fin_contrato'; this.f.fecha_salida = this.contratoFin; } this.calcular(); } },
  template: `
  <div class="page">
    <PageHead title="Liquidaciones" sub="Preaviso y cesantía según los artículos 28 y 29 del Código de Trabajo, vacaciones no disfrutadas, aguinaldo proporcional y salario pendiente, según el motivo de salida." :crumbs="[{label:'Recursos humanos'},{label:'Liquidaciones'}]"></PageHead>
    <div class="card"><h2>Calcular liquidación</h2>
      <div class="grid cols-3">
        <Field label="Empleado" req><select v-model.number="f.empleado_id"><option v-for="e in lista" :key="e.id" :value="e.id">{{nombreCompleto(e)}}{{e.activo===false ? ' (inactivo)' : ''}}</option></select></Field>
        <Field label="Fecha de salida" req :help="contratoFin ? 'Contrato a plazo: vence el ' + fecha(contratoFin) : ''"><input type="date" v-model="f.fecha_salida"></Field>
        <Field label="Motivo" req><select v-model="f.motivo"><option v-for="m in MOTIVOS" :key="m[0]" :value="m[0]">{{m[1]}}</option></select></Field>
        <Field label="Días de salario pendientes" help="Días trabajados del último período que no se han pagado"><input type="number" min="0" step="0.5" v-model.number="f.dias_pendientes"></Field>
        <Field label="Días de vacaciones ya disfrutados" help="Tomado de Vacaciones; puede corregirlo"><input type="number" min="0" step="0.5" v-model.number="f.dias_vac_disfrutados"></Field>
        <Field label="Salario promedio mensual" :help="promedio && promedio.meses ? 'Promedio de las planillas pagadas de los últimos ' + mesesPromedio + ' meses: ' + money(promedio.promedio) + ' (vacío = salario actual)' : 'Vacío = el salario actual; use el promedio de los últimos 6 meses si varió'"><div class="row" style="gap:6px"><input type="number" min="0" step="0.01" v-model.number="f.salario_promedio" class="mono" style="flex:1"><button class="btn sec sm" v-if="promedio && promedio.meses" @click="usarPromedio" title="Usar el promedio de las planillas pagadas">Usar promedio</button></div></Field>
        <Field label="Preaviso" v-if="f.motivo==='despido_con'"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="f.preaviso_otorgado"> Se otorgó el preaviso trabajado (no se paga)</label></Field>
        <Field label="Aguinaldo proporcional" :help="devengado > 0 ? 'Devengado en planillas pagadas desde el ' + fecha(inicioAg) + ': ' + money(devengado) + ' → ' + money(devengado / 12) + ' (' + cobertura.con + ' de ' + cobertura.total + ' meses con planilla' + (coberturaCompleta ? ')' : ': incompleto, se propone la estimación)') : 'Sin planillas pagadas en el período: se estima con el salario de cálculo'"><label class="row" style="cursor:pointer;margin-top:8px" v-if="devengado > 0"><input type="checkbox" v-model="usarDevengado"> Usar lo devengado en planillas (Ley 2412)</label><span class="small muted" v-else style="margin-top:10px;display:block">Estimado con el salario actual</span></Field>
      </div>
      <div class="alert warn" v-if="sinPagar.length" style="margin:10px 0 0">{{sinPagar.length === 1 ? '1 planilla de este empleado no se suma' : sinPagar.length + ' planillas de este empleado no se suman'}} al promedio ni a lo devengado porque no {{sinPagar.length === 1 ? 'está pagada' : 'están pagadas'}}: {{sinPagar.map(p => p.numero).join(', ')}}. Márquelas pagadas en Planilla y calcule de nuevo, o cuente esos días como salario pendiente.</div>
      <div class="alert warn" v-if="pagadas.length" style="margin:10px 0 0">{{nombreCompleto(emp)}} ya tiene pagado {{money(pagadas.reduce((s, l) => s + (+l.total || 0), 0))}} en {{pagadas.map(l => l.numero).join(', ')}}: lo pagado no se cambia ni se elimina. Si faltó pagar algo, calcule la liquidación completa con los datos corregidos y la misma fecha de salida: al guardar se registra solo la diferencia como liquidación adicional<span v-if="diferencia">: <b>{{money(diferencia.total)}}</b><span v-if="diferencia.de_mas.length"> (pagado de más, no se rebaja aquí: {{diferencia.de_mas.map(x => x.rubro + ' ' + money(x.monto)).join(', ')}})</span></span>.</div>
      <div class="row end" style="margin-top:10px;gap:8px"><button class="btn sec" :disabled="calculando" @click="calcular">{{calculando ? 'Calculando…' : 'Calcular'}}</button><button class="btn sec" :disabled="!r" @click="documento({ ...r, fecha_salida: f.fecha_salida, motivo: f.motivo, empleado_id: f.empleado_id }, 'pdf')">⤓ PDF</button><button class="btn sec" :disabled="!r" @click="documento({ ...r, fecha_salida: f.fecha_salida, motivo: f.motivo, empleado_id: f.empleado_id }, 'docx')">⤓ Word</button><button class="btn" :disabled="!r" @click="guardar">{{pagadas.length ? 'Guardar la diferencia' : 'Guardar y dar de baja'}}</button></div>
      <template v-if="r">
        <div class="row" style="margin:14px 0 8px;gap:10px;flex-wrap:wrap"><span class="chip">{{r.motivo_nombre}}</span><span class="chip">Antigüedad {{r.antiguedad.anios}} años y {{r.antiguedad.meses % 12}} meses ({{r.antiguedad.dias}} días)</span><span class="chip">Salario mensual {{money(r.salario_mensual)}} · diario {{money(r.salario_diario)}}</span></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Rubro</th><th class="num">Días</th><th class="num">Monto</th><th>Base</th></tr></thead>
          <tbody><tr v-for="x in r.rubros" :key="x.rubro"><td>{{x.rubro}}</td><td class="num">{{fmt(x.dias,2)}}</td><td class="num"><b>{{money(x.monto)}}</b></td><td class="small muted" style="white-space:normal">{{x.base}}</td></tr></tbody>
          <tfoot><tr><th colspan="2" style="text-align:right">Total de la liquidación</th><th class="num">{{money(r.total)}}</th><th></th></tr></tfoot></table></div>
        <p class="small muted" style="margin:8px 0 0">{{r.nota}}</p>
      </template>
    </div>
    <div class="card pad0"><DataTable :rows="rows" :columns="columns" empty-title="Sin liquidaciones guardadas" @row-click="ver=$event">
      <template #actions="{row}"><button class="btn sm" v-if="row.estado!=='Pagada'" :disabled="abriendo===row.id" @click.stop="abrirPago(row)">{{abriendo===row.id ? 'Abriendo…' : 'Marcar pagada'}}</button><button class="btn sm sec" v-if="row.estado==='Pagada' && correoListo" :disabled="enviando===row.id" @click.stop="enviar(row)" title="Enviar el comprobante de la liquidación pagada en PDF al correo que el empleado tiene en su ficha">{{enviando===row.id ? 'Enviando…' : '✉ Enviar'}}</button><button class="btn sm sec" @click.stop="documento(row, 'pdf')">⤓ PDF</button><button class="btn sm sec" @click.stop="documento(row, 'docx')">⤓ Word</button><button class="btn sm sec" v-if="row.estado==='Pagada'" title="Comprobante del pago en PDF, el mismo que se envía por correo" @click.stop="comprobante(row)">⤓ Comprobante</button><span class="badge" v-if="row.adicional" :title="'Diferencia de la liquidación ' + (row.referencia_numero || '') + ', ya pagada'">Adicional de {{row.referencia_numero || 'otra liquidación'}}</span><button class="btn icon" v-if="row.estado!=='Pagada'" title="Eliminar" @click.stop="eliminar(row)">🗑</button><span class="muted" v-else style="cursor:help;padding:0 6px" title="Pagada: queda cerrada y no se elimina. Una diferencia se paga aparte como liquidación adicional." aria-label="Pagada: no se elimina">🔒</span></template>
    </DataTable></div>
    <Modal v-if="ver" :title="'Liquidación ' + ver.numero + ' · ' + ver.empleado" lg @close="ver=null">
      <div class="row" style="margin-bottom:10px;gap:10px;flex-wrap:wrap"><span class="chip">{{ver.motivo_nombre}}</span><span class="chip">Salida {{fecha(ver.fecha_salida)}}</span><span class="chip" v-if="ver.adicional">Adicional de {{ver.referencia_numero || 'otra liquidación'}}</span><span class="chip">{{ver.antiguedad.anios}} años y {{ver.antiguedad.meses % 12}} meses</span><span class="chip on">{{ver.estado}}</span><span class="small muted" v-if="ver.pagada_en">Pagada el {{fecha(ver.pagada_en)}}<span v-if="ver.cuenta"> desde {{ver.cuenta}}</span></span></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Rubro</th><th class="num">Días</th><th class="num">Monto</th></tr></thead><tbody><tr v-for="x in ver.rubros" :key="x.rubro"><td>{{x.rubro}}</td><td class="num">{{fmt(x.dias,2)}}</td><td class="num">{{money(x.monto)}}</td></tr></tbody><tfoot><tr><th colspan="2" style="text-align:right">Total</th><th class="num">{{money(ver.total)}}</th></tr></tfoot></table></div>
      <template #foot><button class="btn" v-if="ver.estado!=='Pagada'" :disabled="abriendo===ver.id" @click="abrirPago(ver)">{{abriendo===ver.id ? 'Abriendo…' : 'Marcar pagada'}}</button><button class="btn sec" @click="documento(ver, 'pdf')">⤓ PDF</button><button class="btn sec" @click="documento(ver, 'docx')">⤓ Word</button><button class="btn sec" v-if="ver.estado==='Pagada'" title="Comprobante del pago en PDF, el mismo que se envía por correo" @click="comprobante(ver)">⤓ Comprobante</button><button class="btn ghost" title="Cómo cobra esta persona (transferencia, SINPE Móvil, efectivo o cheque), con los avisos de su cuenta: PDF, Excel o CSV" @click="listaPago('liquidacion', ver, 'Liquidación ' + ver.numero)">⤓ Lista de pago</button><button class="btn danger" v-if="ver.estado!=='Pagada'" @click="eliminar(ver)">Eliminar</button><span class="small muted" v-else style="align-self:center" title="Pagada: queda cerrada y no se elimina. Una diferencia se paga aparte como liquidación adicional.">🔒 Pagada</span><button class="btn ghost" @click="ver=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="pagar" :title="'Pagar liquidación ' + pagar.l.numero + ' · ' + pagar.l.nombre" @close="pagar=null">
      <div class="grid cols-2">
        <Field label="Cuenta de la que sale el pago" req help="Por defecto la cuenta principal en colones (Bancos)"><select v-model="pagar.cuenta"><option value="">— Seleccione —</option><option v-for="b in (cuentasLista || [])" :key="b.nombre" :value="b.nombre">{{b.nombre}} · {{b.moneda || 'CRC'}}</option></select></Field>
        <Field label="Fecha de pago" req><input type="date" v-model="pagar.fecha"></Field>
      </div>
      <p class="small muted">Se registra la salida de {{money(pagar.l.total)}} en la cuenta y la liquidación queda como pagada. El salario pendiente y las vacaciones se suman, ya pagada la liquidación, al informe de planilla del mes de la salida (CCSS, INS y renta); el preaviso, la cesantía y el aguinaldo proporcional no se reportan.</p>
      <div class="alert" :class="revision.cargando ? '' : (revision.error || revision.avisos.length ? 'warn' : 'ok')" v-if="revision && revision.id === pagar.l.id" style="margin:8px 0"><b>Revisión de la cuenta</b><span v-if="revision.cargando"> · revisando cómo cobra esta persona…</span><span v-else-if="revision.error"> · no se pudo revisar ({{revision.error}}). Puede marcarla pagada igual: la revisión solo avisa.</span><span v-else-if="!revision.avisos.length"> · sin avisos.</span><span v-else> · confirme estos avisos antes de transferir. Solo avisan: puede marcarla pagada igual.</span><ul v-if="revision.avisos.length" style="margin:4px 0 0 18px;padding:0"><li v-for="(a,j) in revision.avisos" :key="j">{{a}}</li></ul><div class="small" v-if="revision.formas" style="margin-top:4px">{{revision.formas}}</div><div style="margin-top:6px"><button class="btn sm ghost" title="Cómo cobra esta persona, con los avisos de su cuenta: PDF, Excel o CSV" @click="listaPago('liquidacion', pagar.l, 'Liquidación ' + pagar.l.numero)">⤓ Lista de pago</button></div></div>
      <div style="margin-top:8px"><Toggle v-model="pagar.enviar" :disabled="!correoListo" label="Enviar la liquidación en PDF al correo del empleado"></Toggle></div>
      <div class="alert" :class="pagar.acceso.aviso ? '' : 'warn'" v-if="pagar.acceso && pagar.acceso.correo" style="margin:10px 0 0">{{pagar.acceso.suya === false ? 'El correo de la ficha de esta persona es el de este usuario del sistema' : 'Esta persona tiene usuario para entrar al sistema'}} (<b>{{pagar.acceso.correo}}</b><span v-if="pagar.acceso.nombre"> · {{pagar.acceso.nombre}}</span>, rol {{pagar.acceso.rol}}). <span v-if="pagar.acceso.aviso">{{pagar.acceso.aviso}}</span><template v-else><label class="row" style="cursor:pointer;gap:8px;margin-top:6px"><input type="checkbox" v-model="pagar.acceso.quitar"> <b>Quitarle el acceso al marcar pagada la liquidación</b></label><div v-for="(t,j) in pagar.acceso.advertencias" :key="j" style="margin-top:4px">{{t}}</div><div class="small" style="margin-top:4px">Su cuenta no se borra: solo deja de entrar a esta empresa. Para devolverle el acceso hay que agregarla de nuevo en Configuración › Usuarios.</div></template></div>
      <p class="small muted" v-else-if="pagar.acceso && pagar.acceso.nota" style="margin:10px 0 0">{{pagar.acceso.nota}}</p>
      <template #foot><button class="btn ghost" @click="pagar=null">Cancelar</button><button class="btn" @click="confirmarPago">{{pagar.acceso && pagar.acceso.quitar === true ? 'Marcar pagada y quitar acceso' : 'Marcar pagada'}}</button></template>
    </Modal>
  </div>`,
  setup() { return { nombreCompleto, inicioAguinaldo }; },
};
