// Recursos humanos › Ausencias e incapacidades: incapacidades (CCSS, INS, maternidad), permisos sin goce y ausencias injustificadas
// por empleado (registro rrhh_ausencias). La planilla toma de aquí los días sin salario y el subsidio que paga el patrono.
// 4.21: «Traer de asistencia» propone los días planificados sin marcas; el tipo de cada una lo elige Recursos humanos (no hay
// valor por omisión) y solo se guardan las que marque (quedan con origen 'asistencia').
import { api, money, fecha, hoy, toast, mock, sumarDias } from '../../api.js';
import { empleados, nombreCompleto, ausencias, TIPOS_AUSENCIA, tipoAusencia, tablas, salarioDiario, subsidioPatrono, diasEntre } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() {
    const emps = empleados();
    return { lista: ausencias(), emps, empleado: this.params && this.params.empleado ? +this.params.empleado : null, anio: +hoy().slice(0, 4), modal: null, t: null, TIPOS_AUSENCIA, traer: null };
  },
  computed: {
    nombres() { return Object.fromEntries(this.emps.map(e => [e.id, nombreCompleto(e)])); },
    rows() {
      return this.lista.filter(a => (!this.empleado || a.empleado_id === this.empleado) && (!this.anio || String(a.desde || '').startsWith(String(this.anio)) || String(a.hasta || '').startsWith(String(this.anio))))
        .map(a => { const e = this.emps.find(x => x.id === a.empleado_id); const dias = diasEntre(a.desde, a.hasta || a.desde); const s = e ? subsidioPatrono(a.tipo, dias, salarioDiario(e), this.t && this.t.efectivos, a.pct_patrono) : { monto: 0, dias_patrono: 0 };
          return { ...a, empleado: this.nombres[a.empleado_id] || '—', tipo_nombre: tipoAusencia(a.tipo), dias, subsidio: s.monto, dias_patrono: s.dias_patrono, con_salario: a.tipo === 'permiso_con_goce' ? 'Con goce' : 'Sin salario' }; })
        .sort((a, b) => String(b.desde).localeCompare(String(a.desde)));
    },
    columns() { return [{ key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'desde', label: 'Desde', fmt: 'date' }, { key: 'hasta', label: 'Hasta', fmt: 'date' }, { key: 'dias', label: 'Días', num: true }, { key: 'subsidio', label: 'Paga el patrono', num: true, fmt: 'money' }, { key: 'boleta', label: 'Boleta / nota', fmt: (v, r) => [v, r.nota].filter(Boolean).join(' · ') || '—' }, { key: 'con_salario', label: 'Salario', fmt: 'badge' }]; },
    resumen() {
      const out = {}; for (const r of this.rows) { const k = r.tipo_nombre; out[k] = out[k] || { tipo: k, n: 0, dias: 0, subsidio: 0 }; out[k].n++; out[k].dias += r.dias; out[k].subsidio += r.subsidio; }
      return Object.values(out);
    },
    diasModal() { return this.modal ? diasEntre(this.modal.desde, this.modal.hasta || this.modal.desde) : 0; },
    subsidioModal() { if (!this.modal) return null; const e = this.emps.find(x => x.id === this.modal.empleado_id); if (!e) return null; return subsidioPatrono(this.modal.tipo, this.diasModal, salarioDiario(e), this.t && this.t.efectivos, this.modal.pct_patrono === '' ? null : this.modal.pct_patrono); },
    esIncapacidad() { return this.modal && ['incapacidad_ccss', 'incapacidad_ins', 'maternidad'].includes(this.modal.tipo); },
    marcadasTraer() { return this.traer && this.traer.filas ? this.traer.filas.filter(f => f.sel && f.tipo).length : 0; },
  },
  methods: {
    money, fecha,
    abrir(a) {
      this.modal = a ? { ...a, pct_patrono: a.pct_patrono ?? '' } : { id: null, empleado_id: this.empleado || (this.emps[0] ? this.emps[0].id : null), tipo: 'incapacidad_ccss', desde: hoy(), hasta: hoy(), pct_patrono: '', boleta: '', nota: '' };
    },
    guardar() {
      const m = this.modal;
      if (!m.empleado_id) return toast('Seleccione el empleado', 'err');
      if (!m.desde) return toast('Indique la fecha de inicio', 'err');
      if (m.hasta && m.hasta < m.desde) return toast('La fecha final no puede ser anterior a la inicial', 'err');
      const hasta = m.hasta || m.desde;
      const choca = this.lista.find(a => a.id !== m.id && a.empleado_id === m.empleado_id && a.desde <= hasta && (a.hasta || a.desde) >= m.desde);
      if (choca && !confirm('Ya hay un registro de ' + tipoAusencia(choca.tipo).toLowerCase() + ' del ' + fecha(choca.desde) + ' al ' + fecha(choca.hasta || choca.desde) + ' que se traslapa. ¿Guardar de todos modos?')) return;
      const reg = { id: m.id, empleado_id: m.empleado_id, tipo: m.tipo, desde: m.desde, hasta, pct_patrono: m.pct_patrono === '' || m.pct_patrono === null ? null : +m.pct_patrono, boleta: (m.boleta || '').trim(), nota: (m.nota || '').trim() };
      this.lista = mock.actualizar('rrhh_ausencias', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'rrhh_ausencias'); lista.push(reg); } return lista; }, []);
      this.modal = null; toast('Registro guardado', 'ok');
    },
    eliminar(a) { if (!confirm('¿Eliminar este registro? Si ya se aplicó en una planilla, esa planilla no cambia.')) return; this.lista = mock.actualizar('rrhh_ausencias', l => (l || []).filter(x => x.id !== a.id), []); toast('Registro eliminado'); },
    // 4.21: propuesta desde las marcas de asistencia: días planificados sin ninguna marca, anteriores a hoy, que no cubre ya una
    // ausencia ni unas vacaciones. El período por omisión son los últimos 30 días; el servidor admite hasta 62 días
    abrirTraer() {
      const h = hoy();
      this.traer = { desde: sumarDias(h, -30), hasta: h, filas: null, cargando: false, guardando: false };
      this.cargarPropuesta();
    },
    async cargarPropuesta() {
      const t = this.traer;
      if (!t || t.cargando) return;
      if (!t.desde || !t.hasta || t.hasta < t.desde) return toast('Revise las fechas del período', 'err');
      t.cargando = true;
      try {
        const r = await api('/api/asistencia/propuesta?desde=' + encodeURIComponent(t.desde) + '&hasta=' + encodeURIComponent(t.hasta));
        t.filas = (r.ausencias || []).map(f => ({ ...f, tipo: '', sel: false }));
      } catch (e) { t.filas = null; toast(e.message, 'err'); }
      t.cargando = false;
    },
    // al elegir el tipo la fila queda marcada (sin tipo no se puede marcar)
    tipoElegido(f, tipo) { f.tipo = tipo; f.sel = !!tipo; },
    // Guarda solo las filas marcadas y con tipo. Antes vuelve a leer lo guardado y omite las que se traslapan con otra ausencia del
    // mismo empleado (aquí no se pregunta: se omite y se informa); espera al servidor, que también lo revisa
    async guardarPropuesta() {
      const t = this.traer;
      if (!t || t.guardando) return;
      const sel = (t.filas || []).filter(f => f.sel && f.tipo);
      if (!sel.length) return toast('Elija el tipo de las ausencias que quiere guardar', 'err');
      if (!mock.puedeGuardar()) return;
      t.guardando = true;
      try {
        await mock.refrescar(['rrhh_ausencias'], { sinCorte: true });
        const lista = ausencias(), nuevos = [];
        let omitidas = 0;
        for (const f of sel) {
          if (lista.some(a => a.empleado_id === f.empleado_id && a.desde <= f.hasta && (a.hasta || a.desde) >= f.desde)) { omitidas++; continue; }
          const reg = { id: mock.nextId(lista, 'rrhh_ausencias'), empleado_id: f.empleado_id, tipo: f.tipo, desde: f.desde, hasta: f.hasta, pct_patrono: null, boleta: '', nota: 'Desde asistencia: días planificados sin marcas', origen: 'asistencia' };
          lista.push(reg); nuevos.push(reg.id);
        }
        if (!nuevos.length) { this.lista = ausencias(); this.traer = null; return toast('No se guardó nada: esas fechas ya tenían una ausencia registrada', 'err'); }
        const ok = await mock.set('rrhh_ausencias', lista);
        if (!ok) {
          this.lista = mock.actualizar('rrhh_ausencias', l => (l || []).filter(x => !nuevos.includes(x.id)), []);
          return toast('No se guardaron las ausencias traídas de asistencia: vuelva a traerlas e intente de nuevo', 'err');
        }
        this.lista = ausencias(); this.traer = null;
        toast(nuevos.length + (nuevos.length === 1 ? ' ausencia guardada' : ' ausencias guardadas') + (omitidas ? ' · ' + omitidas + (omitidas === 1 ? ' omitida porque se traslapa' : ' omitidas porque se traslapan') + ' con otra ya registrada' : ''), 'ok');
      } finally { t.guardando = false; }
    },
    async documento(formato) {
      const M = v => money(v || 0);
      const cols = [{ key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'desde', label: 'Desde' }, { key: 'hasta', label: 'Hasta' }, { key: 'dias', label: 'Días', num: true }, { key: 'subsidio', label: 'Paga el patrono', num: true }, { key: 'boleta', label: 'Boleta / nota' }];
      const rows = this.rows.map(r => ({ empleado: r.empleado, tipo_nombre: r.tipo_nombre, desde: fecha(r.desde), hasta: fecha(r.hasta), dias: String(r.dias), subsidio: M(r.subsidio), boleta: [r.boleta, r.nota].filter(Boolean).join(' · ') }));
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'ausencias_' + this.anio, cols, rows, { titulo: 'Ausencias e incapacidades ' + this.anio, registrar: a => registrarExportable(a, 'Ausencias e incapacidades ' + this.anio, true) });   // 4.17
      try { await descargarReporte(formato, { titulo: 'Ausencias e incapacidades ' + (this.anio || ''), subtitulo: (this.empleado ? this.nombres[this.empleado] + '. ' : '') + 'Incapacidades, licencias, permisos y ausencias registradas; «paga el patrono» es el subsidio a cargo de la empresa (el resto lo paga la CCSS o el INS).', periodo: 'Año ' + this.anio, kpis: this.resumen.slice(0, 4).map(r => ({ t: r.tipo, v: r.dias + ' días' })), cols, rows, totales: [{ t: 'Días en total', v: String(this.rows.reduce((s, r) => s + r.dias, 0)) }, { t: 'Subsidio patronal', v: M(this.rows.reduce((s, r) => s + r.subsidio, 0)) }], archivo: 'ausencias_' + this.anio, privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  async created() { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
  template: `
  <div class="page">
    <PageHead title="Ausencias e incapacidades" sub="Incapacidades de la CCSS y del INS, licencias de maternidad, permisos sin goce y ausencias injustificadas. La planilla descuenta los días sin salario y paga el subsidio que corresponde al patrono." :crumbs="[{label:'Recursos humanos'},{label:'Ausencias e incapacidades'}]">
      <button class="btn sec" @click="documento('pdf')" :disabled="!rows.length">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!rows.length">⤓ Word</button><button class="btn sec" @click="documento('xlsx')" :disabled="!rows.length">⤓ Excel</button><button class="btn sec" @click="documento('csv')" :disabled="!rows.length">⤓ CSV</button>
      <button class="btn sec" @click="abrirTraer" title="Propone los días planificados sin marcas de asistencia; usted elige el tipo de cada una y confirma cuáles se guardan">Traer de asistencia</button>
      <button class="btn" @click="abrir(null)" :disabled="!emps.length">+ Registrar</button>
    </PageHead>
    <div class="card">
      <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
        <Field label="Empleado"><select v-model.number="empleado"><option :value="null">— Todos —</option><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}{{e.activo===false ? ' (inactivo)' : ''}}</option></select></Field>
        <Field label="Año"><input type="number" v-model.number="anio" min="2020" max="2100" style="width:110px"></Field>
        <div class="row" style="gap:8px;flex-wrap:wrap;padding-bottom:4px"><span class="chip" v-for="r in resumen" :key="r.tipo">{{r.tipo}}: <b>{{r.dias}} d</b><span v-if="r.subsidio"> · patrono {{money(r.subsidio)}}</span></span></div>
      </div>
    </div>
    <div class="card pad0"><DataTable :rows="rows" :columns="columns" empty-title="Sin ausencias registradas" empty-text="Registre incapacidades, licencias, permisos sin goce y ausencias: la planilla del período las aplica sola.">
      <template #actions="{row}"><button class="btn icon" title="Editar" @click.stop="abrir(row)">✎</button><button class="btn icon" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
      <template #empty><button class="btn" @click="abrir(null)" :disabled="!emps.length">+ Registrar</button></template>
    </DataTable></div>
    <Modal v-if="modal" :title="modal.id ? 'Editar registro' : 'Registrar ausencia o incapacidad'" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Empleado" req style="grid-column:1/-1"><select v-model.number="modal.empleado_id"><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}</option></select></Field>
        <Field label="Tipo" req style="grid-column:1/-1"><select v-model="modal.tipo"><option v-for="t in TIPOS_AUSENCIA" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Desde" req><input type="date" v-model="modal.desde"></Field>
        <Field label="Hasta" req><input type="date" v-model="modal.hasta"></Field>
        <Field label="Número de boleta" v-if="esIncapacidad" help="Boleta de incapacidad de la CCSS o del INS"><input v-model="modal.boleta"></Field>
        <Field label="% que paga el patrono" v-if="esIncapacidad" help="Vacío = lo indicado en Parámetros"><input type="number" min="0" max="100" v-model="modal.pct_patrono" placeholder="según Parámetros"></Field>
        <Field label="Nota" style="grid-column:1/-1"><input v-model="modal.nota"></Field>
      </div>
      <div class="alert info" style="margin:12px 0 0" v-if="diasModal"><b>{{diasModal}}</b> día(s) naturales.
        <span v-if="modal.tipo==='permiso_con_goce'">Se pagan con salario normal: no afectan la planilla.</span>
        <span v-else-if="modal.tipo==='maternidad' && subsidioModal">El salario completo sigue cotizando a la CCSS y cuenta para aguinaldo, vacaciones y cesantía (art. 95). La empresa paga el {{subsidioModal.pct}} % ({{money(subsidioModal.monto)}}) y la CCSS le paga a la trabajadora el resto, que la planilla descuenta del neto.</span>
        <span v-else-if="esIncapacidad && subsidioModal">El patrono paga {{subsidioModal.dias_patrono}} día(s) al {{subsidioModal.pct}} % ({{money(subsidioModal.monto)}}, no es salario); el resto lo cubre {{modal.tipo==='incapacidad_ins' ? 'el INS' : 'la CCSS'}} y la planilla no lo paga.</span>
        <span v-else>Se descuentan del salario ordinario del período.</span>
      </div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="traer" title="Traer ausencias de asistencia" lg @close="traer=null">
      <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap;margin-bottom:10px">
        <Field label="Desde"><input type="date" v-model="traer.desde"></Field>
        <Field label="Hasta"><input type="date" v-model="traer.hasta"></Field>
        <button class="btn sec" :disabled="traer.cargando" @click="cargarPropuesta">{{traer.cargando ? 'Buscando…' : 'Buscar'}}</button>
      </div>
      <p class="small muted" style="margin:0 0 10px">Días planificados en el horario sin ninguna marca de asistencia (anteriores a hoy), unidos por días seguidos, hasta 62 días por consulta. No salen los que ya tienen una ausencia o unas vacaciones registradas. El sistema no decide el motivo: elija el tipo de cada fila que quiera guardar; las que deje sin tipo no se guardan.</p>
      <div class="table-wrap" v-if="traer.filas && traer.filas.length"><table class="tbl">
        <thead><tr><th style="width:34px"></th><th>Empleado</th><th>Desde</th><th>Hasta</th><th class="num">Días</th><th style="width:300px">Tipo</th></tr></thead>
        <tbody><tr v-for="f in traer.filas" :key="f.empleado_id + ':' + f.desde">
          <td><input type="checkbox" v-model="f.sel" :disabled="!f.tipo" :title="f.tipo ? '' : 'Elija primero el tipo'"></td>
          <td>{{f.nombre}}</td><td>{{fecha(f.desde)}}</td><td>{{fecha(f.hasta)}}</td><td class="num">{{f.dias}}</td>
          <td><select class="inp" v-model="f.tipo" @change="tipoElegido(f, $event.target.value)" style="width:100%"><option value="">— Elija —</option><option v-for="x in TIPOS_AUSENCIA" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></td>
        </tr></tbody></table></div>
      <p class="muted" v-else-if="traer.filas">No hay días planificados sin marcas en ese período (o ya tienen una ausencia o unas vacaciones registradas).</p>
      <p class="muted" v-else>{{traer.cargando ? 'Buscando en las marcas de asistencia…' : 'Elija el período y pulse Buscar.'}}</p>
      <template #foot><span class="small muted" style="margin-right:auto;align-self:center" v-if="traer.filas && traer.filas.length">{{marcadasTraer}} de {{traer.filas.length}} con tipo y marcada(s)</span><button class="btn ghost" @click="traer=null">Cancelar</button><button class="btn" :disabled="!marcadasTraer || traer.guardando" @click="guardarPropuesta">Guardar seleccionadas</button></template>
    </Modal>
  </div>`,
};
