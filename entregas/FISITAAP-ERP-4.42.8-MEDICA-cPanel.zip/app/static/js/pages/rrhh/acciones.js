// Recursos humanos › Acciones de personal (4.21): ingresos, aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y
// salidas de cada empleado, numeradas (AP-0001), con su motivo, el antes y el después del puesto y quién la registró. Una acción no
// se edita ni se elimina (el servidor lo rechaza): se anula con su motivo. Un aumento, un traslado o un cambio de puesto pueden
// aplicarse a la ficha al registrarlos o después («pendiente de aplicar»); las demás solo dejan constancia: no cambian la ficha, no
// descuentan días en la planilla ni inactivan al empleado (la salida se liquida en Liquidaciones). Solo función: no interpreta plazos
// ni efectos de la norma laboral. Todo lo que se descarga va al historial de Recursos humanos (nombres, cédulas y salarios).
import { money, fecha, fechaHora, hoy, toast, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { empleados, nombreCompleto, salarioMensual, tablas, departamentos, departamentoDe, TIPOS_ACCION, ACCIONES_A_FICHA, tipoAccion, acciones, fotoPuesto, mismaFoto, ahoraCR, numeroAccion, fichaConAccion, fichaTieneAccion, leerGuardado, refrescarDelServidor, registrarAccion } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

const LINEA_FIRMA = '______________________';
// Un texto largo en renglones de hasta `n` letras, cortando en los espacios y respetando los saltos de línea: el PDF y el Word
// recortan cada celda a 200 letras, y el motivo (500) y el detalle (2000) tienen que salir completos
export function partirTexto(t, n = 180) {
  const out = [];
  for (const parrafo of String(t || '').split(/\r?\n/)) {
    let s = parrafo.replace(/\s+/g, ' ').trim();
    while (s.length > n) {
      let i = s.lastIndexOf(' ', n);
      if (i < n / 2) i = n;
      out.push(s.slice(0, i).trim()); s = s.slice(i).trim();
    }
    if (s) out.push(s);
  }
  return out;
}
// Lo que cambia una acción, en una línea (columna «Antes → después» de la lista y de su PDF). 4.22: en un aumento, si el salario sigue
// definido igual (por mes o por hora), eso se dice una sola vez («₡600.000,00 → ₡650.000,00 por mes»); si cambia, en cada lado
export function cambioAccion(a, ayudas) {
  const an = a.antes || {}, de = a.despues || {};
  const modo = f => (f.modo_salario === 'mensual' ? ' por mes' : ' por hora'), sal = f => ayudas.money(+f.salario || 0) + modo(f), pd = f => [f.puesto, f.departamento].filter(Boolean).join(' · ') || '—';
  if (a.tipo === 'aumento') return (modo(an) === modo(de) ? ayudas.money(+an.salario || 0) : sal(an)) + ' → ' + sal(de);
  if (a.tipo === 'traslado' || a.tipo === 'cambio_puesto') return pd(an) + ' → ' + pd(de);
  if (a.tipo === 'ingreso') return pd(de);
  if (a.tipo === 'suspension') return 'Del ' + ayudas.fecha(a.rige) + ' al ' + ayudas.fecha(a.hasta || a.rige);
  return '—';
}
// El «después» de la foto del puesto según lo escrito en el formulario (m) y la ficha: en un aumento cambia el salario; en un traslado
// o un cambio de puesto, el puesto, el departamento (de la lista; sin elegir, queda el que tenía) y la categoría. Los demás, igual.
export function despuesDeAccion(m, emp, deptos) {
  const antes = fotoPuesto(emp);
  if (m.tipo === 'aumento') {
    const modo = m.modo_salario === 'mensual' ? 'mensual' : 'hora', sal = +m.salario || 0;
    return { ...antes, modo_salario: modo, salario: sal, salario_mensual: salarioMensual({ ...emp, modo_salario: modo, salario_hora: modo === 'hora' ? sal : emp.salario_hora, salario_mensual: modo === 'mensual' ? sal : emp.salario_mensual }) };
  }
  if (m.tipo === 'traslado' || m.tipo === 'cambio_puesto') {
    const d = (deptos || []).find(x => x.id === m.departamento_id);
    return { ...antes, puesto: String(m.puesto || '').trim().slice(0, 80), departamento: d ? d.nombre : antes.departamento, departamento_id: d ? d.id : antes.departamento_id, categoria: m.categoria || antes.categoria };
  }
  return antes;
}
// La acción impresa (PDF o Word): datos del colaborador, datos de la acción, el antes y el después, el motivo completo y el espacio
// para las firmas. Devuelve lo que recibe descargarReporte. Respeta los topes del servidor (título 120, subtítulo y nota 300, período
// 80, 12 secciones y celdas de 200 letras): si no, el servidor rechaza el documento entero.
export function documentoAccion(a, emp, ayudas) {
  const { money: M, fecha: F, fechaHora: FH } = ayudas, corto = (v, n = 190) => String(v ?? '').slice(0, n);
  const kv = (dato, valor) => ({ dato, valor: valor === null || valor === undefined || valor === '' ? '—' : corto(valor) });
  const DV = [{ key: 'dato', label: 'Dato' }, { key: 'valor', label: 'Valor' }];
  const an = a.antes || {}, de = a.despues || {}, tipo = tipoAccion(a.tipo), anulada = a.estado === 'Anulada';
  const nombre = String(a.nombre || (emp ? nombreCompleto(emp) : '') || '—');
  const sal = f => (f.salario === undefined || f.salario === null ? '—' : M(+f.salario || 0) + (f.modo_salario === 'mensual' ? ' por mes' : ' por hora'));
  const cambia = ACCIONES_A_FICHA.includes(a.tipo);
  const secciones = [
    { titulo: 'Datos del colaborador', columnas: DV, filas: [kv('Nombre', nombre), kv('Identificación', emp ? ({ '01': 'Cédula', '03': 'DIMEX', '04': 'NITE' }[emp.tipo_id] || 'Extranjero') + ' ' + (emp.numero_id || '') : ''),
      kv('Fecha de ingreso', emp && emp.fecha_ingreso ? F(emp.fecha_ingreso) : ''), ...(cambia ? [] : [kv('Puesto', de.puesto), kv('Departamento', de.departamento)])] },
    { titulo: 'Datos de la acción', columnas: DV, filas: [kv('Número', a.numero), kv('Tipo', tipo), kv('Fecha', F(a.fecha)), kv('Rige desde', F(a.rige)), ...(a.tipo === 'suspension' ? [kv('Hasta', F(a.hasta || a.rige))] : []),
      ...(cambia ? [kv('Aplicada a la ficha', a.aplicada_a_ficha ? 'Sí' : anulada ? 'No' : 'No: pendiente de aplicar')] : []), kv('Registrada por', [a.registrada_por, a.registrada_en ? FH(a.registrada_en) : ''].filter(Boolean).join(' · ')),
      kv('Estado', anulada ? 'ANULADA' : 'Registrada')] },
  ];
  if (cambia) secciones.push({ titulo: 'Antes y después', columnas: [{ key: 'dato', label: 'Dato' }, { key: 'antes', label: 'Antes' }, { key: 'despues', label: 'Después' }],
    filas: [['Puesto', an.puesto, de.puesto], ['Departamento', an.departamento, de.departamento], ['Categoría salarial', an.categoria, de.categoria], ['Salario', sal(an), sal(de)],
      ['Equivalente mensual', M(+an.salario_mensual || 0), M(+de.salario_mensual || 0)]].map(([dato, x, y]) => ({ dato, antes: corto(x || '—'), despues: corto(y || '—') })) });
  // el motivo, el detalle y la anulación van en una sola columna, a todo el ancho de la hoja y con su rótulo al inicio (en dos columnas
  // el texto largo caía en la angosta); cada renglón lleva hasta 180 letras, así ninguno se corta
  const textos = [];
  const parrafo = (dato, t) => { if (String(t || '').trim()) partirTexto(dato + ': ' + String(t).trim()).forEach(texto => textos.push({ texto })); };
  parrafo('Motivo', a.motivo); parrafo('Detalle', a.detalle);
  if (anulada) { parrafo('Motivo de la anulación', a.motivo_anulacion); parrafo('Anulada por', [a.anulada_por, a.anulada_en ? FH(a.anulada_en) : ''].filter(Boolean).join(' · ')); }
  secciones.push({ titulo: 'Motivo', columnas: [{ key: 'texto', label: 'Motivo y detalle' }], filas: textos.length ? textos : [{ texto: '—' }] });
  // los renglones en blanco antes de cada línea dejan espacio para firmar. Llevan un espacio duro: una celda vacía del todo sale en el
  // PDF con 2,5 mm de alto (sin renglón de texto) y no quedaba dónde firmar. 4.22: las tres firmas van lado a lado (una columna por persona) con dos renglones en blanco
  // encima: quedan unos 1,7 cm para firmar y la acción corta (aumento, traslado, cambio de puesto) sigue cabiendo en una hoja. Una
  // firma debajo de otra con ese espacio pasaba la del testigo, sola, a la segunda hoja
  const vacio = { dato: '\u00a0', c: '', p: '', t: '' };
  secciones.push({ titulo: 'Firmas', columnas: [{ key: 'dato', label: 'Firmas' }, { key: 'c', label: 'Colaborador' }, { key: 'p', label: 'Representante patronal' }, { key: 't', label: 'Testigo' }],
    filas: [vacio, vacio, ...[['Firma', LINEA_FIRMA], ['Nombre y cédula', LINEA_FIRMA], ['Fecha', '____________']].map(([dato, linea]) => ({ dato, c: linea, p: linea, t: linea }))] });
  return { titulo: ('Acción de personal ' + (a.numero || '')).slice(0, 120), subtitulo: (tipo + ' · ' + nombre).slice(0, 300), periodo: ('Rige desde el ' + F(a.rige)).slice(0, 80), cols: [], rows: [], secciones,
    nota: anulada ? 'Esta acción de personal está ANULADA y no tiene efecto.' : null, archivo: 'empleado_accion_' + String(a.numero || a.id || '').replace(/[^\w-]+/g, '_').slice(0, 30) };
}

export default {
  props: ['params'],
  data() {
    return { lista: acciones(), emps: empleados(), empleado: this.params && this.params.empleado ? +this.params.empleado : null, tipo: '', q: '', modal: null, reintento: null, anula: null, t: null, guardando: false, generando: false, TIPOS_ACCION };
  },
  computed: {
    nombres() { return Object.fromEntries(this.emps.map(e => [e.id, nombreCompleto(e)])); },
    activosPorId() { return Object.fromEntries(this.emps.map(e => [e.id, e.activo !== false])); },
    // para el buscador del formulario: los activos primero; un inactivo también puede recibir una acción (queda dicho en su nombre)
    opcionesEmp() { return this.emps.map(e => ({ id: e.id, nombre: nombreCompleto(e) + (e.activo === false ? ' (inactivo)' : ''), numero_id: e.numero_id || '', orden: e.activo === false ? 1 : 0 })).sort((a, b) => a.orden - b.orden || a.nombre.localeCompare(b.nombre)); },
    // 4.22: sin las marcas «Eliminada» (lo que queda de las acciones de una ficha eliminada: solo guardan el número, para que no se
    // repita). De aquí salen la lista, los contadores y las cuatro exportaciones. `lista` y acciones() sí las llevan: de ahí sale el
    // número siguiente y lo que se guarda (si faltaran, el guardado intentaría borrarlas y el servidor lo rechazaría)
    rows() {
      return this.lista.filter(a => a.estado !== 'Eliminada' && (!this.empleado || a.empleado_id === this.empleado) && (!this.tipo || a.tipo === this.tipo)).map(a => {
        const anulada = a.estado === 'Anulada', pendiente = !anulada && ACCIONES_A_FICHA.includes(a.tipo) && !a.aplicada_a_ficha;
        return { ...a, empleado: this.nombres[a.empleado_id] || a.nombre || '—', tipo_nombre: tipoAccion(a.tipo), cambio: cambioAccion(a, { money, fecha }), registro: a.registrada_por || '—', pendiente,
          estado_txt: anulada ? 'Anulada' : pendiente ? 'Pendiente de aplicar' : 'Registrada', liquidable: a.tipo === 'salida' && !anulada && this.activosPorId[a.empleado_id] === true };
      }).sort((a, b) => String(b.numero).localeCompare(String(a.numero), 'es', { numeric: true }));
    },
    // 4.22: lo que pinta la tabla con el buscador puesto. Se busca aquí y no dentro de la tabla (que solo busca en lo que pinta) para
    // seguir encontrando por el motivo completo (en pantalla va recortado), por quién la registró y por la fecha de la acción, que ya
    // no tienen columna. Las exportaciones y los contadores siguen saliendo de rows (los filtros de Empleado y Tipo, sin el buscador)
    visibles() {
      const q = String(this.q || '').toLowerCase().trim();
      return q ? this.rows.filter(r => [r.numero, r.empleado, r.tipo_nombre, fecha(r.rige), fecha(r.fecha), r.cambio, r.motivo, r.registro, r.estado_txt].some(v => String(v || '').toLowerCase().includes(q))) : this.rows;
    },
    // 4.22: la tabla tiene que caber en la pantalla con su «Estado» y sus botones (en 1440 px quedaban fuera de la vista): sin «Registró»
    // ni la fecha de la acción (siguen en el PDF, el Word, el Excel, el CSV y la acción impresa) y con el motivo en 40 letras
    columns() {
      const breve = v => { const s = String(v || ''); return s.length > 40 ? s.slice(0, 40) + '…' : s; };
      return [{ key: 'numero', label: 'Número', mono: true }, { key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'rige', label: 'Rige', fmt: 'date' },
        { key: 'cambio', label: 'Antes → después', class: 'parte' }, { key: 'motivo', label: 'Motivo', fmt: breve, class: 'parte' }, { key: 'estado_txt', label: 'Estado', fmt: 'badge' }];
    },
    pendientes() { return this.rows.filter(r => r.pendiente).length; },
    empModal() { return this.modal ? this.emps.find(e => e.id === this.modal.empleado_id) || null : null; },
    antes() { return this.empModal ? fotoPuesto(this.empModal) : null; },
    cambiaFicha() { return !!this.modal && ACCIONES_A_FICHA.includes(this.modal.tipo); },
    categorias() { return this.t ? this.t.efectivos.categorias : []; },
    puestos() { return this.t ? this.t.puestos : []; },
    deptos() { return departamentos().filter(d => d.activo !== false || (this.modal && d.id === this.modal.departamento_id)).map(d => ({ id: d.id, nombre: d.nombre })); },
    // qué pasa con la ficha según la casilla «Aplicar a la ficha» (se lee bajo la casilla)
    notaAplicar() {
      const m = this.modal;
      if (!m || !this.cambiaFicha) return '';
      if (!m.aplicar) return 'La acción queda «pendiente de aplicar»: la ficha no cambia hasta que pulse «Aplicar» en la lista (el sistema no la aplica solo cuando llega la fecha).';
      if (m.rige > hoy()) return 'Rige en una fecha futura, pero la ficha cambia HOY al registrar: desde ahora la planilla usa los datos nuevos.';
      return 'La ficha cambia al registrar.' + (m.tipo === 'aumento' ? ' El aumento queda en el historial de salario con la fecha desde la que rige.' : '');
    },
  },
  methods: {
    money, fecha,
    salarioTexto(f) { return f ? money(f.salario || 0) + (f.modo_salario === 'mensual' ? ' por mes' : ' por hora') : '—'; },
    releer() { this.lista = acciones(); this.emps = empleados(); },
    async cargar() {
      try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); }
      await mock.refrescar(['rrhh_acciones', 'empleados']).catch(() => false);
      this.releer();
    },
    nueva() {
      this.reintento = null;
      this.modal = { empleado_id: this.emps.some(e => e.id === this.empleado) ? this.empleado : null, tipo: 'aumento', fecha: hoy(), rige: hoy(), hasta: hoy(), motivo: '', detalle: '', aplicar: true, aplicarTocado: false,
        puesto: '', departamento_id: null, categoria: '', modo_salario: 'hora', salario: null };
      this.cargarDespues();
    },
    // al elegir el empleado o el tipo, el «después» parte de lo que la ficha tiene hoy
    cargarDespues() {
      const m = this.modal, e = this.empModal;
      if (!m || !e) return;
      const f = fotoPuesto(e), d = departamentoDe(e);
      Object.assign(m, { puesto: f.puesto, departamento_id: d ? d.id : null, categoria: f.categoria, modo_salario: f.modo_salario, salario: f.salario || null });
    },
    // «Aplicar a la ficha» viene marcada cuando la acción rige hoy o antes; si el usuario la cambió a mano, se respeta
    cambioRige() { const m = this.modal; if (m && !m.aplicarTocado) m.aplicar = !!m.rige && m.rige <= hoy(); },
    cerrarModal() {
      if (this.guardando) return;
      const x = this.reintento;
      if (x && !confirm(x.ficha === 'cambiada' ? 'La ficha ya cambió y la acción todavía no está registrada. ¿Cerrar de todos modos? Tendrá que dejar constancia por otro medio.'
        : x.ficha === 'incierta' ? 'No se sabe si la ficha cambió, y la acción no está registrada. ¿Cerrar de todos modos? Revise después la ficha del empleado.'
          : 'No se sabe si la acción quedó registrada. ¿Cerrar de todos modos? Revise la lista antes de registrarla otra vez.')) return;
      this.modal = null; this.reintento = null;
    },
    problema(m) {
      if (!m.empleado_id) return 'Seleccione el empleado';
      if (!TIPOS_ACCION.some(x => x[0] === m.tipo)) return 'Seleccione el tipo de acción';
      if (!m.fecha || !m.rige) return 'Indique la fecha de la acción y la fecha desde la que rige';
      if (m.tipo === 'suspension' && (!m.hasta || m.hasta < m.rige)) return 'En una suspensión, «Hasta» no puede ser anterior a «Rige desde»';
      if (!(m.motivo || '').trim()) return 'Indique el motivo';
      if (m.motivo.trim().length > 500) return 'El motivo admite hasta 500 letras';
      if ((m.detalle || '').trim().length > 2000) return 'El detalle admite hasta 2000 letras';
      if (m.tipo === 'aumento' && !(+m.salario > 0)) return 'Indique el salario nuevo';
      if (m.tipo === 'cambio_puesto' && !(m.puesto || '').trim()) return 'Indique el puesto nuevo';
      return '';
    },
    // Guarda la ficha con lo que la acción le cambia y ESPERA al servidor. Devuelve true (la ficha quedó cambiada), false (el servidor
    // no aceptó el cambio: la ficha sigue igual) o null (no se pudo confirmar con el servidor si cambió). Si el servidor no responde,
    // relee lo guardado y decide con eso; si la ficha no cambió (o no se sabe), deshace la copia local para que el cambio no suba
    // después sin su acción. No avisa: quien llama dice qué pasó con la acción
    async guardarFicha(emp, a, gen) {
      const ok = await mock.set('empleados', empleados().map(x => (x.id === emp.id ? fichaConAccion(x, a) : x)));
      if (mock.generacion !== gen || !mock.cargado) return false;
      if (ok) return true;
      const srv = await leerGuardado('empleados');
      if (mock.generacion !== gen || !mock.cargado) return false;
      const g = srv && srv.find(x => x.id === emp.id);
      if (g && fichaTieneAccion(g, a)) { await mock.refrescar(['empleados'], { sinCorte: true }).catch(() => false); return true; }
      mock.set('empleados', empleados().map(x => (x.id === emp.id ? emp : x)));
      this.releer();
      return srv ? false : null;
    },
    // Primero la ficha (si la acción se aplica) y después la acción: si la ficha no se guarda, no se registra nada; si la ficha cambió y
    // la acción no quedó (o no se pudo confirmar alguna de las dos), se avisa y el formulario queda en espera, con los datos de ese
    // intento, para terminarlo con «Reintentar el registro» sin cambiar la ficha otra vez ni repetir la acción
    async guardar() {
      const m = this.modal;
      if (!m || this.guardando) return;
      if (this.reintento) return this.reintentar();
      const problema = this.problema(m);
      if (problema) return toast(problema, 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true; const gen = mock.generacion;
      try {
        // lo último guardado: el «antes» sale de la ficha como está en el servidor, no de la copia de esta pantalla (4.22: ni de la
        // copia sin conexión del navegador: refrescarDelServidor)
        const leido = await refrescarDelServidor(['empleados', 'rrhh_acciones']);
        if (mock.generacion !== gen || !mock.cargado) return;
        if (!leido) return toast('No se pudo consultar al servidor: revise la conexión e intente de nuevo. No se registró nada', 'err');
        const emp = empleados().find(x => x.id === m.empleado_id);
        if (!emp) { this.releer(); return toast('Ese empleado ya no existe: recargue la página', 'err'); }
        const cambia = ACCIONES_A_FICHA.includes(m.tipo), antes = fotoPuesto(emp), despues = despuesDeAccion(m, emp, departamentos());
        if (cambia && JSON.stringify(antes) === JSON.stringify(despues)) { this.releer(); return toast('La ficha de ' + nombreCompleto(emp) + ' ya tiene esos datos: no hay nada que cambiar', 'err'); }
        const aplicar = cambia && !!m.aplicar, nombre = nombreCompleto(emp);
        const datos = { empleado_id: emp.id, nombre: nombre.slice(0, 200), tipo: m.tipo, fecha: m.fecha, rige: m.rige, hasta: m.tipo === 'suspension' ? m.hasta : '', antes, despues, motivo: m.motivo.trim(), detalle: (m.detalle || '').trim(),
          aplicada_a_ficha: aplicar, registrada_por: (sesion.usuario || {}).correo || '', registrada_en: ahoraCR() };
        const numero = numeroAccion(acciones());
        if (aplicar) {
          const r = await this.guardarFicha(emp, { ...datos, numero }, gen);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (r === null) {
            this.reintento = { datos, numero, numeroFicha: numero, nombre, ficha: 'incierta' };
            return toast('No se pudo confirmar con el servidor si la ficha de ' + nombre + ' cambió; la acción todavía no se registró. Cuando vuelva la conexión pulse «Reintentar el registro»: el sistema revisa la ficha y termina lo que falte', 'err');
          }
          if (!r) return toast('El servidor no aceptó el cambio en la ficha de ' + nombre + ': la ficha sigue igual y la acción no se registró', 'err');
        }
        await this.registrar(datos, numero, aplicar, nombre, gen);
      } finally { this.guardando = false; }
    },
    // Registra la acción (si se aplica, la ficha ya quedó guardada). `numeroFicha`: el número que cita el historial de salario de la
    // ficha. Si el registro no queda, o no se puede confirmar, el formulario queda en espera con los datos y el número de este intento
    async registrar(datos, numero, aplicada, nombre, gen, numeroFicha = numero) {
      const r = await registrarAccion(datos, numero);
      if (mock.generacion !== gen || !mock.cargado) return;
      this.releer();
      if (!r.ok) {
        if (!aplicada && !r.incierto) return toast('La acción no se registró', 'err');       // el servidor la rechazó y ya dijo por qué; la ficha no se tocó
        this.reintento = { datos, numero: r.numero || numero, numeroFicha, nombre, ficha: aplicada ? 'cambiada' : 'no' };
        return toast(aplicada ? 'ATENCIÓN: la ficha de ' + nombre + ' SÍ cambió, pero la acción de personal ' + (r.incierto ? 'no se pudo confirmar' : 'NO quedó registrada') + '. Pulse «Reintentar el registro»: la ficha no cambia de nuevo y, si la acción ya quedó, no se repite'
          : 'No se pudo confirmar con el servidor si la acción quedó registrada. Cuando vuelva la conexión pulse «Reintentar el registro»: si ya quedó, no se repite', 'err');
      }
      // otra persona tomó el número reservado mientras se guardaba la ficha: el renglón del historial de salario cita el número que quedó
      if (aplicada && datos.tipo === 'aumento' && r.accion.numero !== numeroFicha) {
        mock.actualizar('empleados', l => (l || []).map(x => (x.id === datos.empleado_id ? { ...x, historial: (x.historial || []).map(h => (h.motivo === 'Acción ' + numeroFicha ? { ...h, motivo: 'Acción ' + r.accion.numero } : h)) } : x)), []);
        this.releer();
      }
      this.modal = null; this.reintento = null;
      toast('Acción ' + r.accion.numero + ' registrada' + (aplicada ? ' y aplicada a la ficha de ' + nombre : ACCIONES_A_FICHA.includes(datos.tipo) ? ': queda pendiente de aplicar a la ficha' : ''), 'ok');
    },
    // Termina lo que quedó en espera con los datos de aquel intento (el «antes» de cuando se tomó), sin repetir nada. Si no se sabía si
    // la ficha cambió, primero lee lo guardado: si ya tiene lo de la acción, solo falta registrarla; si sigue como antes, la guarda
    // ahora. Después registra la acción con el número de aquel intento (si ya había quedado, registrarAccion devuelve esa misma)
    async reintentar() {
      const x = this.reintento;
      if (!x || this.guardando || !mock.puedeGuardar()) return;
      this.guardando = true; const gen = mock.generacion;
      try {
        if (x.ficha === 'incierta') {
          const leido = await refrescarDelServidor(['empleados']);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (!leido) return toast('Todavía no se pudo consultar al servidor: revise la conexión e intente de nuevo', 'err');
          const emp = empleados().find(e => e.id === x.datos.empleado_id), a = { ...x.datos, numero: x.numeroFicha };
          this.releer();
          if (!emp) { this.reintento = null; return toast('Ese empleado ya no existe: recargue la página. La acción no se registró', 'err'); }
          if (!fichaTieneAccion(emp, a)) {
            // la ficha no recibió el cambio. Si mientras tanto cambió por otro lado, el «antes» de aquel intento ya no vale: se empieza de nuevo
            if (!mismaFoto(fotoPuesto(emp), x.datos.antes)) { this.reintento = null; return toast('La ficha de ' + x.nombre + ' cambió mientras tanto y no recibió esta acción: revise los datos y regístrela de nuevo', 'err'); }
            const r = await this.guardarFicha(emp, a, gen);
            if (mock.generacion !== gen || !mock.cargado) return;
            if (r === null) return toast('Todavía no se pudo confirmar con el servidor el cambio en la ficha de ' + x.nombre + ': revise la conexión e intente de nuevo', 'err');
            if (!r) { this.reintento = null; return toast('El servidor no aceptó el cambio en la ficha de ' + x.nombre + ': la ficha sigue igual y la acción no se registró', 'err'); }
          }
          x.ficha = 'cambiada';
        }
        await this.registrar(x.datos, x.numero, x.ficha === 'cambiada', x.nombre, gen, x.numeroFicha);
      } finally { this.guardando = false; }
    },
    // Una acción que quedó pendiente (regía después, o se registró sin aplicar): primero la ficha, después se marca aplicada
    async aplicar(row) {
      if (this.guardando || !mock.puedeGuardar()) return;
      if (!confirm('¿Aplicar la acción ' + row.numero + ' a la ficha de ' + row.empleado + '?\n\n' + row.cambio + '\n\nLa ficha cambia desde ahora.')) return;
      this.guardando = true; const gen = mock.generacion;
      try {
        const leido = await refrescarDelServidor(['empleados', 'rrhh_acciones']);
        if (mock.generacion !== gen || !mock.cargado) return;
        if (!leido) return toast('No se pudo consultar al servidor: revise la conexión e intente de nuevo. No se cambió nada', 'err');
        const a = acciones().find(x => x.id === row.id), emp = a ? empleados().find(x => x.id === a.empleado_id) : null;
        this.releer();
        if (!a || a.estado === 'Anulada' || a.aplicada_a_ficha || !ACCIONES_A_FICHA.includes(a.tipo)) return toast('La acción ' + row.numero + ' ya no está pendiente de aplicar', 'err');
        if (!emp) return toast('El empleado de la acción ' + a.numero + ' ya no existe', 'err');
        if (!fichaTieneAccion(emp, a)) {
          // 4.22: solo se aplica si la ficha sigue como el «antes» de la acción. Si cambió por otro lado desde que se registró (otro
          // aumento, una corrección en la ficha), el «después» guardado pisaría ese cambio: un aumento viejo le bajaría el salario
          if (!mismaFoto(fotoPuesto(emp), a.antes)) return toast('La ficha de ' + nombreCompleto(emp) + ' cambió desde que se registró la acción ' + a.numero + ' y ya no tiene los datos de «antes»: no se aplicó. Anule esta acción y registre otra con los datos de hoy', 'err');
          const r = await this.guardarFicha(emp, a, gen);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (r === null) return toast('No se pudo confirmar con el servidor el cambio en la ficha de ' + nombreCompleto(emp) + '. Cuando vuelva la conexión pulse «Aplicar» otra vez: si la ficha ya cambió, no cambia de nuevo', 'err');
          if (!r) return toast('El servidor no aceptó el cambio en la ficha de ' + nombreCompleto(emp) + ': la ficha sigue igual y la acción ' + a.numero + ' sigue pendiente de aplicar', 'err');
        }
        const ok = await mock.set('rrhh_acciones', acciones().map(x => (x.id === a.id ? { ...x, aplicada_a_ficha: true, aplicada_por: (sesion.usuario || {}).correo || '', aplicada_en: ahoraCR() } : x)));
        if (mock.generacion !== gen || !mock.cargado) return;
        if (!ok) {
          const srv = await leerGuardado('rrhh_acciones'), g = srv && srv.find(x => x.id === a.id);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (g && g.aplicada_a_ficha) await mock.refrescar(['rrhh_acciones'], { sinCorte: true }).catch(() => false);
          else {
            mock.set('rrhh_acciones', acciones().map(x => (x.id === a.id ? a : x))); this.releer();
            // sin lectura del servidor (sin conexión o con la copia) no se sabe si quedó marcada: no se afirma que sigue pendiente
            return toast('ATENCIÓN: la ficha de ' + nombreCompleto(emp) + ' SÍ cambió, pero ' + (srv ? 'la acción ' + a.numero + ' sigue como pendiente de aplicar. Pulse' : 'no se pudo confirmar con el servidor si la acción ' + a.numero + ' quedó marcada como aplicada. Cuando vuelva la conexión pulse') + ' «Aplicar» otra vez para marcarla: la ficha no cambia de nuevo', 'err');
          }
        }
        this.releer(); toast('Acción ' + a.numero + ' aplicada a la ficha de ' + nombreCompleto(emp), 'ok');
      } finally { this.guardando = false; }
    },
    abrirAnular(row) { this.anula = { id: row.id, numero: row.numero, empleado: row.empleado, aplicada: ACCIONES_A_FICHA.includes(row.tipo) && !!row.aplicada_a_ficha, motivo: '' }; },
    cerrarAnular() { if (!this.guardando) this.anula = null; },
    async confirmarAnular() {
      const n = this.anula;
      if (!n || this.guardando) return;
      const motivo = (n.motivo || '').trim();
      if (!motivo) return toast('Indique el motivo de la anulación', 'err');
      if (motivo.length > 500) return toast('El motivo de la anulación admite hasta 500 letras', 'err');
      if (!mock.puedeGuardar()) return;
      this.guardando = true; const gen = mock.generacion;
      try {
        // 4.22: se anula sobre lo que el servidor tiene hoy; sin poder consultarlo (o con la copia sin conexión) no se manda nada
        const leido = await refrescarDelServidor(['rrhh_acciones']);
        if (mock.generacion !== gen || !mock.cargado) return;
        if (!leido) return toast('No se pudo consultar al servidor: revise la conexión e intente de nuevo. No se anuló nada', 'err');
        const a = acciones().find(x => x.id === n.id && x.estado !== 'Eliminada');      // 4.22: la marca de una eliminada con su ficha ya no es una acción
        if (!a || a.estado === 'Anulada') { this.releer(); this.anula = null; return toast(a ? 'La acción ' + a.numero + ' ya estaba anulada' : 'La acción ya no existe: recargue la página', 'err'); }
        const ok = await mock.set('rrhh_acciones', acciones().map(x => (x.id === a.id ? { ...x, estado: 'Anulada', motivo_anulacion: motivo, anulada_por: (sesion.usuario || {}).correo || '', anulada_en: ahoraCR() } : x)));
        if (mock.generacion !== gen || !mock.cargado) return;
        if (!ok) {
          const srv = await leerGuardado('rrhh_acciones'), g = srv && srv.find(x => x.id === a.id);
          if (mock.generacion !== gen || !mock.cargado) return;
          if (g && g.estado === 'Anulada') await mock.refrescar(['rrhh_acciones'], { sinCorte: true }).catch(() => false);
          else {
            mock.set('rrhh_acciones', acciones().map(x => (x.id === a.id ? a : x))); this.releer();
            return toast(srv ? 'El servidor no aceptó la anulación de la acción ' + a.numero + ': sigue registrada' : 'No se pudo confirmar con el servidor la anulación de la acción ' + a.numero + ': revise la lista cuando vuelva la conexión', 'err');
          }
        }
        this.releer(); this.anula = null; toast('Acción ' + a.numero + ' anulada', 'ok');
      } finally { this.guardando = false; }
    },
    // La acción impresa, con espacio para las firmas del colaborador, del representante patronal y de un testigo
    async imprimir(row, formato) {
      if (this.generando) return;
      this.generando = true;
      const a = this.lista.find(x => x.id === row.id) || row, emp = this.emps.find(e => e.id === a.empleado_id) || null;
      try { await descargarReporte(formato, { ...documentoAccion(a, emp, { money, fecha, fechaHora }), privado: true }); } catch (e) { toast(e.message, 'err'); }
      this.generando = false;
    },
    // La lista en PDF o Word (lo arma el servidor, que corta cada celda en 200 letras: lo largo va recortado aquí, con sus puntos suspensivos)
    async documento(formato) {
      const cols = [{ key: 'numero', label: 'Número' }, { key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'fecha_txt', label: 'Fecha' }, { key: 'rige_txt', label: 'Rige' }, { key: 'cambio', label: 'Antes → después' },
        { key: 'motivo_txt', label: 'Motivo' }, { key: 'registro', label: 'Registró' }, { key: 'estado_txt', label: 'Estado' }];
      const corto = v => { const s = String(v || ''); return s.length > 190 ? s.slice(0, 189) + '…' : s; };
      const rows = this.rows.map(r => ({ ...r, empleado: corto(r.empleado), cambio: corto(r.cambio), registro: corto(r.registro), fecha_txt: fecha(r.fecha), rige_txt: fecha(r.rige), motivo_txt: corto(r.motivo) }));
      const subtitulo = ((this.empleado && this.nombres[this.empleado] ? this.nombres[this.empleado] + '. ' : '') + 'Ingresos, aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y salidas registradas. Una acción no se edita ni se elimina: se anula con su motivo.').slice(0, 300);
      const kpis = [{ t: 'Acciones', v: String(rows.length) }, { t: 'Pendientes de aplicar a la ficha', v: String(this.pendientes) }, { t: 'Anuladas', v: String(rows.filter(r => r.estado === 'Anulada').length) }];
      try { await descargarReporte(formato, { titulo: 'Acciones de personal', subtitulo, periodo: 'Al ' + fecha(hoy()), kpis, cols, rows, archivo: 'empleado_acciones_personal', privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
    // La lista en Excel o CSV, con el antes y el después en columnas separadas. 4.22: las tres fechas llevan fmt 'date': descargarTabla
    // las escribe como en la pantalla y en el PDF (D/M/AAAA); antes salían como AAAA-MM-DD
    tabla(formato) {
      const cols = [{ key: 'numero', label: 'Número' }, { key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'rige', label: 'Rige', fmt: 'date' }, { key: 'hasta', label: 'Hasta', fmt: 'date' },
        { key: 'puesto_antes', label: 'Puesto antes' }, { key: 'depto_antes', label: 'Departamento antes' }, { key: 'salario_antes', label: 'Salario antes', num: true }, { key: 'puesto_despues', label: 'Puesto después' },
        { key: 'depto_despues', label: 'Departamento después' }, { key: 'salario_despues', label: 'Salario después', num: true }, { key: 'modo_salario', label: 'Salario por' }, { key: 'motivo', label: 'Motivo' }, { key: 'detalle', label: 'Detalle' },
        { key: 'aplicada', label: 'Aplicada a la ficha' }, { key: 'registro', label: 'Registró' }, { key: 'registrada', label: 'Registrada el' }, { key: 'estado', label: 'Estado' }, { key: 'motivo_anulacion', label: 'Motivo de la anulación' }];
      const rows = this.rows.map(r => { const an = r.antes || {}, de = r.despues || {}; return { numero: r.numero, empleado: r.empleado, tipo_nombre: r.tipo_nombre, fecha: r.fecha || '', rige: r.rige || '', hasta: r.hasta || '', puesto_antes: an.puesto || '', depto_antes: an.departamento || '',
        salario_antes: +an.salario || 0, puesto_despues: de.puesto || '', depto_despues: de.departamento || '', salario_despues: +de.salario || 0, modo_salario: de.modo_salario === 'mensual' ? 'mes' : 'hora', motivo: r.motivo || '', detalle: r.detalle || '',
        aplicada: ACCIONES_A_FICHA.includes(r.tipo) ? (r.aplicada_a_ficha ? 'Sí' : 'No') : '', registro: r.registrada_por || '', registrada: r.registrada_en ? fechaHora(r.registrada_en) : '', estado: r.estado || '', motivo_anulacion: r.motivo_anulacion || '' }; });
      return descargarTabla(formato, 'acciones_personal', cols, rows, { titulo: 'Acciones de personal', registrar: a => registrarExportable(a, 'Acciones de personal', true) });
    },
  },
  watch: { 'params.empleado'(v) { this.empleado = v ? +v : null; } },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Acciones de personal" sub="Ingresos, aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y salidas de cada empleado, con su número, su motivo y quién la registró. Una acción no se edita ni se elimina: se anula con su motivo." :crumbs="[{label:'Recursos humanos'},{label:'Acciones de personal'}]">
      <button class="btn sec" @click="documento('pdf')" :disabled="!rows.length">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!rows.length">⤓ Word</button><button class="btn ghost" @click="tabla('xlsx')" :disabled="!rows.length">⤓ Excel</button><button class="btn ghost" @click="tabla('csv')" :disabled="!rows.length">⤓ CSV</button>
      <button class="btn" @click="nueva" :disabled="!emps.length">+ Nueva acción</button>
    </PageHead>
    <div class="card"><div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
      <Field label="Empleado"><select v-model.number="empleado"><option :value="null">— Todos —</option><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}{{e.activo===false ? ' (inactivo)' : ''}}</option></select></Field>
      <Field label="Tipo"><select v-model="tipo"><option value="">— Todos —</option><option v-for="x in TIPOS_ACCION" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></Field>
      <p class="small muted" style="margin:0 0 10px" v-if="pendientes">{{pendientes}} acción(es) pendiente(s) de aplicar a la ficha: el sistema no las aplica solo cuando llega la fecha; use «Aplicar».</p>
    </div></div>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar por número, empleado o motivo" v-model="q"></div>
      <DataTable :rows="visibles" :columns="columns" empty-title="Sin acciones de personal" empty-text="Registre aquí los aumentos, traslados, cambios de puesto, amonestaciones, suspensiones y salidas. El ingreso y los cambios de puesto o departamento hechos en la ficha se registran solos.">
      <template #actions="{row}"><button class="btn sm ghost" :disabled="generando" title="La acción impresa, con espacio para las firmas" @click.stop="imprimir(row, 'pdf')">⤓ PDF</button><button class="btn sm ghost" :disabled="generando" title="La acción impresa, con espacio para las firmas" @click.stop="imprimir(row, 'docx')">⤓ Word</button><button class="btn sm sec" v-if="row.pendiente" :disabled="guardando" title="Cambia la ficha del empleado con lo que dice esta acción" @click.stop="aplicar(row)">Aplicar</button><a class="btn sm sec" v-if="row.liquidable" :href="'#/rrhh/liquidaciones?empleado='+row.empleado_id" title="La salida no inactiva al empleado ni calcula nada: se liquida en Liquidaciones">Liquidar</a><button class="btn sm ghost" v-if="row.estado!=='Anulada'" :disabled="guardando" @click.stop="abrirAnular(row)">Anular</button></template>
      <template #empty><button class="btn" @click="nueva" :disabled="!emps.length">+ Nueva acción</button></template>
    </DataTable></div>
    <Modal v-if="modal" title="Nueva acción de personal" lg @close="cerrarModal">
      <div class="alert warn" v-if="reintento" style="margin-bottom:12px"><template v-if="reintento.ficha==='cambiada'">La ficha de <b>{{reintento.nombre}}</b> ya cambió, pero la acción todavía no está registrada. Revise la conexión y pulse «Reintentar el registro»: la ficha no cambia de nuevo.</template><template v-else-if="reintento.ficha==='incierta'">No se pudo confirmar si la ficha de <b>{{reintento.nombre}}</b> cambió, y la acción todavía no está registrada. Revise la conexión y pulse «Reintentar el registro»: el sistema revisa la ficha y termina lo que falte, sin repetir nada.</template><template v-else>No se pudo confirmar si la acción de <b>{{reintento.nombre}}</b> quedó registrada. Revise la conexión y pulse «Reintentar el registro»: si ya quedó, no se repite.</template></div>
      <fieldset :disabled="!!reintento || guardando" style="border:0;padding:0;margin:0;min-width:0">
      <div class="grid cols-2">
        <Field label="Empleado" req style="grid-column:1/-1"><Buscador v-model="modal.empleado_id" :opciones="opcionesEmp" etiqueta="nombre" detalle="numero_id" placeholder="Escriba el nombre o la identificación" @change="cargarDespues"></Buscador></Field>
        <Field label="Tipo de acción" req><select v-model="modal.tipo" @change="cargarDespues"><option v-for="x in TIPOS_ACCION" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></Field>
        <Field label="Fecha de la acción" req><input type="date" v-model="modal.fecha"></Field>
        <Field :label="modal.tipo==='suspension' ? 'Rige desde (primer día de la suspensión)' : 'Rige desde'" req><input type="date" v-model="modal.rige" @change="cambioRige"></Field>
        <Field label="Hasta (último día)" req v-if="modal.tipo==='suspension'"><input type="date" v-model="modal.hasta" :min="modal.rige"></Field>
      </div>
      <div class="alert info" v-if="antes" style="margin:12px 0">Hoy en la ficha · Puesto: <b>{{antes.puesto || '—'}}</b> · Departamento: <b>{{antes.departamento || '—'}}</b> · Categoría: <b>{{antes.categoria || '—'}}</b> · Salario: <b>{{salarioTexto(antes)}}</b> (equivale a {{money(antes.salario_mensual)}} al mes)</div>
      <div class="grid cols-2" v-if="modal.tipo==='aumento'">
        <Field label="Cómo se define el salario" req><select v-model="modal.modo_salario"><option value="hora">Por hora</option><option value="mensual">Mensual fijo</option></select></Field>
        <Field :label="modal.modo_salario==='mensual' ? 'Salario mensual nuevo' : 'Salario por hora nuevo'" req><input type="number" min="0" step="0.01" v-model.number="modal.salario" class="mono"></Field>
      </div>
      <div class="grid cols-2" v-if="modal.tipo==='traslado' || modal.tipo==='cambio_puesto'">
        <Field label="Puesto nuevo" style="grid-column:1/-1"><input v-model="modal.puesto" list="puestos-accion" maxlength="80"><datalist id="puestos-accion"><option v-for="p in puestos" :key="p.nombre" :value="p.nombre">{{p.categoria}}</option></datalist></Field>
        <Field label="Departamento nuevo" help="Sin elegir, queda el que tiene hoy"><select v-model.number="modal.departamento_id"><option :value="null">— El mismo de hoy —</option><option v-for="d in deptos" :key="d.id" :value="d.id">{{d.nombre}}</option></select></Field>
        <Field label="Categoría salarial" help="La del decreto de salarios mínimos: solo es la referencia de la ficha"><select v-model="modal.categoria"><option v-for="c in categorias" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
      </div>
      <div class="grid cols-2">
        <Field label="Motivo" req style="grid-column:1/-1"><input v-model="modal.motivo" maxlength="500" placeholder="Ej. Revisión salarial anual, reorganización del área, falta al reglamento interno…"></Field>
        <Field label="Detalle" style="grid-column:1/-1" :help="modal.tipo==='amonestacion' || modal.tipo==='salida' || modal.tipo==='suspension' ? 'Describa los hechos o las condiciones; sale completo en el documento impreso' : 'Opcional; sale en el documento impreso'"><textarea rows="4" v-model="modal.detalle" maxlength="2000"></textarea></Field>
      </div>
      <label class="row" style="cursor:pointer;gap:8px;margin-top:6px" v-if="cambiaFicha"><input type="checkbox" v-model="modal.aplicar" @change="modal.aplicarTocado = true"> <span>Aplicar a la ficha del empleado al registrar</span></label>
      <p class="small muted" style="margin:6px 0 0" v-if="cambiaFicha">{{notaAplicar}}</p>
      <p class="small muted" style="margin:6px 0 0" v-if="modal.tipo==='suspension'">La suspensión solo deja constancia: no descuenta días en la planilla. Si es sin goce de salario, regístrela también en Ausencias e incapacidades.</p>
      <p class="small muted" style="margin:6px 0 0" v-if="modal.tipo==='salida'">La salida solo deja constancia: no inactiva al empleado ni calcula nada. Después de registrarla use «Liquidar» en la lista.</p>
      <p class="small muted" style="margin:6px 0 0" v-if="modal.tipo==='ingreso'">El ingreso se registra solo al crear la ficha. Úselo aquí para dejar constancia del ingreso de un empleado que ya estaba en el sistema.</p>
      </fieldset>
      <template #foot><button class="btn ghost" :disabled="guardando" @click="cerrarModal">Cancelar</button><button class="btn" :disabled="guardando" @click="guardar">{{guardando ? 'Guardando…' : reintento ? 'Reintentar el registro' : 'Registrar acción'}}</button></template>
    </Modal>
    <Modal v-if="anula" :title="'Anular la acción ' + anula.numero" @close="cerrarAnular">
      <p style="margin:0 0 10px">La acción <b>{{anula.numero}}</b> de <b>{{anula.empleado}}</b> queda en la lista como «Anulada», con el motivo, quién la anuló y cuándo. No se puede deshacer.</p>
      <div class="alert warn" v-if="anula.aplicada" style="margin-bottom:10px">Esta acción ya se aplicó a la ficha. Anularla NO devuelve la ficha a como estaba: si hace falta, corrija la ficha o registre otra acción.</div>
      <Field label="Motivo de la anulación" req><textarea rows="3" v-model="anula.motivo" maxlength="500"></textarea></Field>
      <template #foot><button class="btn ghost" :disabled="guardando" @click="cerrarAnular">Cancelar</button><button class="btn danger" :disabled="guardando" @click="confirmarAnular">{{guardando ? 'Anulando…' : 'Anular acción'}}</button></template>
    </Modal>
  </div>`,
};
