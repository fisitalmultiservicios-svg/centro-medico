// Recursos humanos › Horas extra: registro diario de horas extra (tiempo y medio) y horas en feriado trabajado por empleado
// (registro rrhh_horas_extra). La planilla del período las suma sola en las columnas «H. extra» y «H. feriado».
// 4.21: «Traer de asistencia» propone, según las marcas, las horas trabajadas por encima de lo planificado; Recursos humanos las
// revisa fila por fila y solo se guardan las que marque (quedan con origen 'asistencia').
import { api, money, fmt, fecha, hoy, toast, mock } from '../../api.js';
import { empleados, nombreCompleto, horasExtra, TIPOS_HORA, tipoHora, tablas, salarioMensual, horasSemana, FERIADOS_FIJOS, esFeriado } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() {
    const emps = empleados();
    return { lista: horasExtra(), emps, empleado: this.params && this.params.empleado ? +this.params.empleado : null, mes: hoy().slice(0, 7), modal: null, t: null, TIPOS_HORA, traer: null };
  },
  computed: {
    nombres() { return Object.fromEntries(this.emps.map(e => [e.id, nombreCompleto(e)])); },
    activos() { return this.emps.filter(e => e.activo !== false); },
    factores() { const p = this.t && this.t.efectivos; return { extra: p && +p.hora_extra_factor || 1.5, feriado: p && +p.feriado_factor || 2 }; },
    rows() {
      return this.lista.filter(h => (!this.empleado || h.empleado_id === this.empleado) && (!this.mes || String(h.fecha || '').startsWith(this.mes)))
        .map(h => { const e = this.emps.find(x => x.id === h.empleado_id); return { ...h, empleado: this.nombres[h.empleado_id] || '—', tipo_nombre: tipoHora(h.tipo), monto: e ? this.montoDe(e, h) : 0 }; })
        .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || a.empleado.localeCompare(b.empleado));
    },
    columns() { return [{ key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'horas', label: 'Horas', num: true, fmt: v => fmt(v, 1) }, { key: 'monto', label: 'Pago estimado', num: true, fmt: 'money' }, { key: 'nota', label: 'Motivo / nota', fmt: v => v || '—' }]; },
    resumen() {
      const por = {}; for (const r of this.rows) { const k = r.empleado; por[k] = por[k] || { empleado: k, extra: 0, feriado: 0, monto: 0 }; if (r.tipo === 'feriado') por[k].feriado += +r.horas || 0; else por[k].extra += +r.horas || 0; por[k].monto += r.monto; }
      return Object.values(por).sort((a, b) => b.monto - a.monto);
    },
    totales() { return { extra: this.rows.filter(r => r.tipo !== 'feriado').reduce((s, r) => s + (+r.horas || 0), 0), feriado: this.rows.filter(r => r.tipo === 'feriado').reduce((s, r) => s + (+r.horas || 0), 0), monto: this.rows.reduce((s, r) => s + r.monto, 0) }; },
    esFeriado() { return this.modal && FERIADOS_FIJOS.includes(String(this.modal.fecha || '').slice(5)); },
    montoModal() { if (!this.modal) return 0; const e = this.emps.find(x => x.id === this.modal.empleado_id); return e ? this.montoDe(e, this.modal) : 0; },
    marcadasTraer() { return this.traer && this.traer.filas ? this.traer.filas.filter(f => f.sel && f.marcable).length : 0; },
  },
  methods: {
    money, fmt, fecha,
    // salario por hora × factor (mismas reglas que la planilla: hora extra a tiempo y medio; feriado solo el recargo sobre la hora ordinaria)
    salarioHora(e) { return e.modo_salario === 'mensual' ? (salarioMensual(e) / 30) / (horasSemana(e) / 6) : (+e.salario_hora || 0); },
    montoDe(e, h) { const sh = this.salarioHora(e), n = +h.horas || 0; return Math.round((h.tipo === 'feriado' ? sh * Math.max(0, this.factores.feriado - 1) * n : sh * this.factores.extra * n) * 100) / 100; },
    abrir(h) { this.modal = h ? { ...h } : { id: null, empleado_id: this.empleado || (this.activos[0] ? this.activos[0].id : null), fecha: hoy(), tipo: 'extra', horas: 1, nota: '' }; },
    guardar() {
      const m = this.modal;
      if (!m.empleado_id) return toast('Seleccione el empleado', 'err');
      if (!m.fecha) return toast('Indique la fecha', 'err');
      if (!(+m.horas > 0) || +m.horas > 16) return toast('Indique las horas (entre 0,5 y 16)', 'err');
      if (!mock.puedeGuardar()) return;
      const reg = { id: m.id, empleado_id: m.empleado_id, fecha: m.fecha, tipo: m.tipo === 'feriado' ? 'feriado' : 'extra', horas: Math.round(+m.horas * 100) / 100, nota: (m.nota || '').trim(), usuario: m.usuario };
      this.lista = mock.actualizar('rrhh_horas_extra', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'rrhh_horas_extra'); lista.push(reg); } return lista; }, []);
      this.modal = null; toast('Horas registradas', 'ok');
    },
    eliminar(h) { if (!confirm('¿Eliminar este registro? Si ya se aplicó en una planilla, esa planilla no cambia.')) return; this.lista = mock.actualizar('rrhh_horas_extra', l => (l || []).filter(x => x.id !== h.id), []); toast('Registro eliminado'); },
    // 4.21: propuesta desde las marcas de asistencia. El período por omisión es el mes elegido; el servidor admite hasta 62 días
    feriadoFijo(iso) { return esFeriado(iso); },
    abrirTraer() {
      const m = /^\d{4}-\d{2}$/.test(this.mes || '') ? this.mes : hoy().slice(0, 7), fin = new Date(+m.slice(0, 4), +m.slice(5, 7), 0).getDate();
      this.traer = { desde: m + '-01', hasta: m + '-' + String(fin).padStart(2, '0'), filas: null, cargando: false, guardando: false };
      this.cargarPropuesta();
    },
    async cargarPropuesta() {
      const t = this.traer;
      if (!t || t.cargando) return;
      if (!t.desde || !t.hasta || t.hasta < t.desde) return toast('Revise las fechas del período', 'err');
      t.cargando = true;
      try {
        const r = await api('/api/asistencia/propuesta?desde=' + encodeURIComponent(t.desde) + '&hasta=' + encodeURIComponent(t.hasta));
        t.filas = (r.horas_extra || []).map(f => ({ ...f, sel: !!f.marcable, tipo: 'extra', asistencia_horas: f.horas }));
      } catch (e) { t.filas = null; toast(e.message, 'err'); }
      t.cargando = false;
    },
    // Guarda solo las filas marcadas. Antes vuelve a leer lo guardado (otra persona pudo registrar ese día) y no repite un día que ya
    // tenga horas de ese empleado; espera al servidor, que también lo revisa, y si no las acepta las quita de esta pantalla
    async guardarPropuesta() {
      const t = this.traer;
      if (!t || t.guardando) return;
      const sel = (t.filas || []).filter(f => f.sel && f.marcable);
      if (!sel.length) return toast('Marque al menos una fila para guardar', 'err');
      if (sel.some(f => !(+f.horas > 0) || +f.horas > 16)) return toast('Indique las horas de cada fila marcada (más de 0 y hasta 16)', 'err');
      if (!mock.puedeGuardar()) return;
      t.guardando = true;
      try {
        await mock.refrescar(['rrhh_horas_extra'], { sinCorte: true });
        const lista = horasExtra(), nuevos = [];
        let omitidas = 0;
        for (const f of sel) {
          if (lista.some(x => x.empleado_id === f.empleado_id && String(x.fecha || '').slice(0, 10) === f.fecha)) { omitidas++; continue; }
          const reg = { id: mock.nextId(lista, 'rrhh_horas_extra'), empleado_id: f.empleado_id, fecha: f.fecha, tipo: f.tipo === 'feriado' ? 'feriado' : 'extra', horas: Math.round(+f.horas * 100) / 100, nota: 'Desde asistencia', origen: 'asistencia', asistencia_horas: +f.asistencia_horas || 0 };
          lista.push(reg); nuevos.push(reg.id);
        }
        if (!nuevos.length) { this.lista = horasExtra(); this.traer = null; return toast('No se guardó nada: esos días ya tenían horas registradas', 'err'); }
        const ok = await mock.set('rrhh_horas_extra', lista);
        if (!ok) {
          this.lista = mock.actualizar('rrhh_horas_extra', l => (l || []).filter(x => !nuevos.includes(x.id)), []);
          return toast('No se guardaron las horas traídas de asistencia: vuelva a traerlas e intente de nuevo', 'err');
        }
        this.lista = horasExtra(); this.traer = null;
        toast(nuevos.length + (nuevos.length === 1 ? ' registro de horas guardado' : ' registros de horas guardados') + (omitidas ? ' · ' + omitidas + (omitidas === 1 ? ' omitido porque ya tenía' : ' omitidos porque ya tenían') + ' horas ese día' : ''), 'ok');
      } finally { t.guardando = false; }
    },
    exportar(formato) {
      const cols = [{ key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'horas', label: 'Horas', num: true, fmt: v => fmt(v, 1) }, { key: 'monto', label: 'Pago estimado', num: true, fmt: 'money' }, { key: 'nota', label: 'Nota' }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'horas_extra_' + this.mes, cols, this.rows, { registrar: a => registrarExportable(a, 'Horas extra y feriados ' + (this.mes || ''), true) });   // 4.21: al historial de Recursos humanos
      return descargarReporte(formato, { titulo: 'Horas extra y feriados ' + (this.mes || ''), subtitulo: (this.empleado ? this.nombres[this.empleado] + '. ' : '') + 'Horas extra a tiempo y medio y horas trabajadas en feriado con el recargo de Parámetros; el pago es estimado con el salario actual de cada empleado.', periodo: 'Mes ' + this.mes,
        kpis: [{ t: 'Horas extra', v: fmt(this.totales.extra, 1) }, { t: 'Horas en feriado', v: fmt(this.totales.feriado, 1) }, { t: 'Pago estimado', v: money(this.totales.monto) }], cols, rows: this.rows, totales: [{ t: 'Pago estimado', v: money(this.totales.monto) }], archivo: 'horas_extra_' + this.mes, privado: true });
    },
  },
  async created() { try { this.t = await tablas(); } catch (e) { toast(e.message, 'err'); } },
  template: `
  <div class="page">
    <PageHead title="Horas extra" sub="Registre cada día las horas extra (tiempo y medio) y las trabajadas en feriado de pago obligatorio. La planilla del período las suma sola; puede corregirlas en cada fila antes de calcular." :crumbs="[{label:'Recursos humanos'},{label:'Horas extra'}]">
      <button class="btn ghost sm" @click="exportar('pdf')" :disabled="!rows.length">PDF</button><button class="btn ghost sm" @click="exportar('docx')" :disabled="!rows.length">Word</button><button class="btn ghost sm" @click="exportar('xlsx')" :disabled="!rows.length">Excel</button><button class="btn ghost sm" @click="exportar('csv')" :disabled="!rows.length">CSV</button>
      <button class="btn sec" @click="abrirTraer" title="Propone las horas trabajadas por encima de lo planificado según las marcas de asistencia; usted confirma cuáles se guardan">Traer de asistencia</button>
      <button class="btn" @click="abrir(null)" :disabled="!activos.length">+ Registrar horas</button>
    </PageHead>
    <div class="card">
      <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
        <Field label="Empleado"><select v-model.number="empleado"><option :value="null">— Todos —</option><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}{{e.activo===false ? ' (inactivo)' : ''}}</option></select></Field>
        <Field label="Mes"><input type="month" v-model="mes"></Field>
        <div class="row" style="gap:8px;flex-wrap:wrap;padding-bottom:4px"><span class="chip">Extra: <b>{{fmt(totales.extra,1)}} h</b></span><span class="chip">Feriado: <b>{{fmt(totales.feriado,1)}} h</b></span><span class="chip">Pago estimado: <b>{{money(totales.monto)}}</b></span></div>
      </div>
      <p class="small muted" style="margin:10px 0 0">Factores de Parámetros: hora extra × {{factores.extra}} · feriado trabajado se paga {{factores.feriado}} veces la hora ordinaria (aquí se muestra solo el recargo, porque la hora ordinaria ya va en el salario). Jornada máxima con extras: 12 horas por día (art. 140 del Código de Trabajo).</p>
    </div>
    <div class="grid cols-2" style="align-items:start" v-if="resumen.length">
      <div class="card pad0" style="grid-column:1/-1"><DataTable :rows="rows" :columns="columns" :page-size="20" empty-title="Sin horas registradas" empty-text="Registre las horas extra y de feriado de cada día: la planilla las toma sola.">
        <template #actions="{row}"><button class="btn icon" title="Editar" @click.stop="abrir(row)">✎</button><button class="btn icon" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
      </DataTable></div>
    </div>
    <div class="card pad0" v-else><DataTable :rows="rows" :columns="columns" empty-title="Sin horas registradas" empty-text="Registre las horas extra y de feriado de cada día: la planilla las toma sola."><template #empty><button class="btn" @click="abrir(null)" :disabled="!activos.length">+ Registrar horas</button></template></DataTable></div>
    <div class="card" v-if="resumen.length"><h2>Resumen del mes por empleado</h2>
      <table class="tbl"><thead><tr><th>Empleado</th><th class="num">Horas extra</th><th class="num">Horas feriado</th><th class="num">Pago estimado</th></tr></thead>
        <tbody><tr v-for="r in resumen" :key="r.empleado"><td>{{r.empleado}}</td><td class="num">{{fmt(r.extra,1)}}</td><td class="num">{{fmt(r.feriado,1)}}</td><td class="num">{{money(r.monto)}}</td></tr></tbody></table>
    </div>
    <Modal v-if="modal" :title="modal.id ? 'Editar horas' : 'Registrar horas'" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Empleado" req style="grid-column:1/-1"><select v-model.number="modal.empleado_id"><option v-for="e in activos" :key="e.id" :value="e.id">{{nombres[e.id]}}</option></select></Field>
        <Field label="Fecha" req><input type="date" v-model="modal.fecha"></Field>
        <Field label="Horas" req><input type="number" min="0.5" max="16" step="0.5" v-model.number="modal.horas"></Field>
        <Field label="Tipo" req style="grid-column:1/-1"><select v-model="modal.tipo"><option v-for="t in TIPOS_HORA" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field label="Motivo o nota" style="grid-column:1/-1"><input v-model="modal.nota" maxlength="120" placeholder="Inventario de cierre, evento, cobertura de turno…"></Field>
      </div>
      <div class="alert info" style="margin:12px 0 0" v-if="modal.empleado_id">Pago estimado: <b>{{money(montoModal)}}</b><span v-if="esFeriado && modal.tipo !== 'feriado'"> · La fecha es feriado de pago obligatorio: si trabajó ese día, use el tipo «Feriado trabajado».</span></div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="traer" title="Traer horas extra de asistencia" lg @close="traer=null">
      <div class="row" style="gap:12px;align-items:end;flex-wrap:wrap;margin-bottom:10px">
        <Field label="Desde"><input type="date" v-model="traer.desde"></Field>
        <Field label="Hasta"><input type="date" v-model="traer.hasta"></Field>
        <button class="btn sec" :disabled="traer.cargando" @click="cargarPropuesta">{{traer.cargando ? 'Buscando…' : 'Buscar'}}</button>
      </div>
      <p class="small muted" style="margin:0 0 10px">Horas trabajadas por encima de lo planificado en el horario (o de la jornada, si el empleado no tiene horario) según las marcas de asistencia, hasta 62 días por consulta. Revise cada fila: puede cambiar las horas y el tipo, o desmarcarla. Los días con marcas incompletas o con el turno en curso no se pueden marcar (corrija las marcas en Marcas de asistencia y vuelva a traer), ni los que ya tienen horas registradas. Nada se guarda hasta pulsar «Guardar seleccionadas».</p>
      <div class="table-wrap" v-if="traer.filas && traer.filas.length"><table class="tbl">
        <thead><tr><th style="width:34px"></th><th>Fecha</th><th>Empleado</th><th class="num">Trabajado</th><th class="num">Planificado</th><th style="width:100px">Horas extra</th><th style="width:220px">Tipo</th><th>Observación</th></tr></thead>
        <tbody><tr v-for="f in traer.filas" :key="f.empleado_id + ':' + f.fecha">
          <td><input type="checkbox" v-model="f.sel" :disabled="!f.marcable"></td>
          <td>{{fecha(f.fecha)}}<span class="badge warn" v-if="feriadoFijo(f.fecha)" style="margin-left:6px" title="La fecha es un feriado de pago obligatorio: si corresponde, cambie el tipo a «Feriado trabajado»">¿feriado?</span></td>
          <td>{{f.nombre}}</td>
          <td class="num">{{fmt(f.trabajado,2)}} h</td>
          <td class="num">{{f.planificado === null || f.planificado === undefined ? fmt(f.jornada,2) + ' h (jornada)' : fmt(f.planificado,2) + ' h'}}</td>
          <td><input class="inp" type="number" min="0.5" max="16" step="0.5" v-model.number="f.horas" :disabled="!f.marcable" style="width:100%"></td>
          <td><select class="inp" v-model="f.tipo" :disabled="!f.marcable" style="width:100%"><option v-for="x in TIPOS_HORA" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></td>
          <td class="small" style="white-space:normal"><span class="badge" v-if="f.ya_registrado">ya registrado</span><span v-if="f.avisos && f.avisos.length" style="color:var(--warn)"> {{f.avisos.join(' · ')}}</span><span class="muted" v-if="f.marcable && !(f.avisos && f.avisos.length)">—</span></td>
        </tr></tbody></table></div>
      <p class="muted" v-else-if="traer.filas">No hay horas por encima de lo planificado en ese período.</p>
      <p class="muted" v-else>{{traer.cargando ? 'Buscando en las marcas de asistencia…' : 'Elija el período y pulse Buscar.'}}</p>
      <template #foot><span class="small muted" style="margin-right:auto;align-self:center" v-if="traer.filas && traer.filas.length">{{marcadasTraer}} de {{traer.filas.length}} marcada(s)</span><button class="btn ghost" @click="traer=null">Cancelar</button><button class="btn" :disabled="!marcadasTraer || traer.guardando" @click="guardarPropuesta">Guardar seleccionadas</button></template>
    </Modal>
  </div>`,
};
