// Recursos humanos › Deducciones e ingresos fijos: préstamos, adelantos, embargos, pensiones alimentarias, aportes a la asociación
// solidarista, bonificaciones, comisiones y viáticos por empleado (registro rrhh_conceptos). La planilla los aplica sola en cada
// período; los préstamos y adelantos llevan saldo y se detienen al cancelarse.
import { money, fecha, hoy, toast, mock, fmt } from '../../api.js';
import { sesion } from '../../app.js';
import { empleados, nombreCompleto, conceptos, CATEGORIAS_DEDUCCION, CATEGORIAS_INGRESO, NO_SALARIAL, estadoCuentaConcepto } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() {
    const emps = empleados();
    return { lista: conceptos(), emps, empleado: this.params && this.params.empleado ? +this.params.empleado : null, modal: null, cuenta: null, CATEGORIAS_DEDUCCION, CATEGORIAS_INGRESO };
  },
  computed: {
    nombres() { return Object.fromEntries(this.emps.map(e => [e.id, nombreCompleto(e)])); },
    rows() {
      return this.lista.filter(c => !this.empleado || c.empleado_id === this.empleado).map(c => {
        const conSaldo = ['prestamo', 'adelanto'].includes(c.categoria);
        const estado = c.activa === false ? 'Pausado' : (conSaldo && !(+c.saldo > 0)) ? 'Cancelado' : (c.hasta && c.hasta < hoy()) ? 'Terminado' : 'Activo';
        return { ...c, empleado: this.nombres[c.empleado_id] || '—', tipo_nombre: c.tipo === 'ingreso' ? 'Ingreso' : 'Deducción', categoria_nombre: this.catNombre(c), valor_txt: c.modo === 'porcentaje' ? fmt(c.valor, 2) + ' % del bruto' : money(c.valor), saldo_txt: conSaldo ? money(c.saldo || 0) : '—', vigencia: fecha(c.desde) + (c.hasta ? ' – ' + fecha(c.hasta) : ' en adelante'), estado };
      }).sort((a, b) => (a.empleado + a.tipo).localeCompare(b.empleado + b.tipo));
    },
    columns() { return [{ key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'concepto', label: 'Concepto', fmt: (v, r) => v + (r.categoria_nombre && r.categoria_nombre !== v ? ' · ' + r.categoria_nombre : '') }, { key: 'valor_txt', label: 'Por período', num: true }, { key: 'saldo_txt', label: 'Saldo', num: true }, { key: 'vigencia', label: 'Vigencia' }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    esDeduccion() { return this.modal && this.modal.tipo !== 'ingreso'; },
    conSaldo() { return this.esDeduccion && ['prestamo', 'adelanto'].includes(this.modal.categoria); },
    categorias() { return this.esDeduccion ? CATEGORIAS_DEDUCCION : CATEGORIAS_INGRESO; },
    // 4.21: estado de cuenta abierto: los préstamos y adelantos de ese empleado y los que se muestran (el elegido o todos los suyos)
    cuentaConceptos() { return this.cuenta ? this.lista.filter(c => c.empleado_id === this.cuenta.empleado_id && c.tipo !== 'ingreso' && ['prestamo', 'adelanto'].includes(c.categoria)) : []; },
    cuentaEstados() { return this.cuentaConceptos.filter(c => this.cuenta.alcance === 'todos' || c.id === this.cuenta.id).map(c => this.estadoDe(c)); },
  },
  methods: {
    money, fecha, fmt,
    catNombre(c) { return ((c.tipo === 'ingreso' ? CATEGORIAS_INGRESO : CATEGORIAS_DEDUCCION).find(x => x[0] === c.categoria) || [c.categoria, c.categoria])[1]; },
    abrir(c) {
      this.modal = c ? { ...c, total: c.total ?? null } : { id: null, empleado_id: this.empleado || (this.emps[0] ? this.emps[0].id : null), tipo: 'deduccion', categoria: 'prestamo', concepto: 'Préstamo de la empresa', modo: 'monto', valor: null, total: null, saldo: null, salarial: true, desde: hoy(), hasta: '', nota: '', activa: true };
    },
    cambiarTipo() { const m = this.modal; m.categoria = m.tipo === 'ingreso' ? 'bonificacion' : 'prestamo'; this.cambiarCategoria(); },
    cambiarCategoria() { const m = this.modal; const n = this.catNombre(m); if (!m.concepto || this.categorias.some(x => x[1] === m.concepto)) m.concepto = n; if (m.tipo === 'ingreso') m.salarial = !NO_SALARIAL.includes(m.categoria); if (m.tipo === 'ingreso' || !['asociacion', 'pension', 'embargo'].includes(m.categoria)) m.modo = 'monto'; },
    guardar() {
      const m = this.modal;
      if (!m.empleado_id) return toast('Seleccione el empleado', 'err');
      if (!(m.concepto || '').trim()) return toast('Indique el concepto', 'err');
      if (!(+m.valor > 0)) return toast('Indique el monto (o el porcentaje) por período', 'err');
      if (m.modo === 'porcentaje' && +m.valor > 100) return toast('El porcentaje no puede pasar de 100', 'err');
      if (this.conSaldo && !m.id && !(+m.total > 0)) return toast('Indique el monto total del ' + (m.categoria === 'adelanto' ? 'adelanto' : 'préstamo'), 'err');
      if (m.hasta && m.desde && m.hasta < m.desde) return toast('La fecha final no puede ser anterior a la inicial', 'err');
      if (this.conSaldo && m.id && +m.saldo < 0) return toast('El saldo pendiente no puede ser negativo', 'err');
      const reg = { id: m.id, empleado_id: m.empleado_id, tipo: m.tipo === 'ingreso' ? 'ingreso' : 'deduccion', categoria: m.categoria, concepto: m.concepto.trim().slice(0, 80), modo: this.esDeduccion ? m.modo : 'monto', valor: +m.valor,
        total: this.conSaldo ? +m.total || null : null, saldo: this.conSaldo ? (m.id ? +m.saldo || 0 : +m.total) : null, salarial: m.tipo === 'ingreso' ? m.salarial !== false : true, desde: m.desde || hoy(), hasta: m.hasta || null, nota: (m.nota || '').trim(), activa: m.activa !== false };
      // 4.21: corregir a mano el saldo de un préstamo o adelanto deja rastro (quién, cuándo, de cuánto a cuánto): lo muestra el estado de
      // cuenta. Se compara con lo guardado más reciente, no con la copia del modal, y se conservan las correcciones anteriores
      const prev = m.id ? conceptos().find(x => x.id === m.id) : null, ajustes = prev && Array.isArray(prev.ajustes) ? prev.ajustes.slice() : [];
      if (prev && this.conSaldo && Math.round(((+prev.saldo || 0) - reg.saldo) * 100) !== 0) ajustes.push({ fecha: hoy(), usuario: (sesion.usuario || {}).correo || '', antes: +prev.saldo || 0, despues: reg.saldo, nota: '' });
      if (ajustes.length) Object.assign(reg, { ajustes: ajustes.slice(-100) });
      this.lista = mock.actualizar('rrhh_conceptos', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'rrhh_conceptos'); lista.push(reg); } return lista; }, []);
      this.modal = null; toast('Concepto guardado', 'ok');
    },
    pausar(c) { this.lista = mock.actualizar('rrhh_conceptos', l => (l || []).map(x => (x.id === c.id ? { ...x, activa: x.activa === false } : x)), []); },
    eliminar(c) { if (!confirm('¿Eliminar «' + c.concepto + '» de ' + c.empleado + '? Las planillas ya guardadas no cambian.')) return; this.lista = mock.actualizar('rrhh_conceptos', l => (l || []).filter(x => x.id !== c.id), []); toast('Concepto eliminado'); },
    async documento(formato) {
      const cols = [{ key: 'empleado', label: 'Empleado' }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'concepto', label: 'Concepto' }, { key: 'categoria_nombre', label: 'Categoría' }, { key: 'valor_txt', label: 'Por período', num: true }, { key: 'saldo_txt', label: 'Saldo', num: true }, { key: 'vigencia', label: 'Vigencia' }, { key: 'estado', label: 'Estado' }];
      if (formato === 'csv' || formato === 'xlsx') return descargarTabla(formato, 'deducciones_e_ingresos', cols, this.rows, { titulo: 'Deducciones e ingresos fijos', registrar: a => registrarExportable(a, 'Deducciones e ingresos fijos', true) });   // 4.17
      try { await descargarReporte(formato, { titulo: 'Deducciones e ingresos fijos', subtitulo: (this.empleado ? this.nombres[this.empleado] + '. ' : '') + 'Conceptos que la planilla aplica en cada período: préstamos y adelantos con su saldo, embargos, pensiones, aportes y bonificaciones.', periodo: 'Al ' + fecha(hoy()), kpis: [{ t: 'Deducciones activas', v: String(this.rows.filter(r => r.tipo !== 'ingreso' && r.estado === 'Activo').length) }, { t: 'Ingresos fijos activos', v: String(this.rows.filter(r => r.tipo === 'ingreso' && r.estado === 'Activo').length) }, { t: 'Saldo de préstamos y adelantos', v: money(this.rows.reduce((s, r) => s + (['prestamo', 'adelanto'].includes(r.categoria) ? (+r.saldo || 0) : 0), 0)) }], cols, rows: this.rows, archivo: 'deducciones_ingresos', privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
    // 4.21: estado de cuenta de un préstamo o adelanto: saldo inicial, abonos por planilla, correcciones manuales y saldo actual
    verCuenta(row) { this.cuenta = { id: row.id, empleado_id: row.empleado_id, alcance: 'uno' }; },
    estadoDe(c) {
      const e = estadoCuentaConcepto(c), que = c.categoria === 'adelanto' ? 'adelanto' : 'préstamo';
      const filas = [{ fecha: e.desde ? fecha(e.desde) : '', movimiento: 'Saldo inicial' + (e.estimado ? ' (estimado)' : ''), detalle: e.estimado ? 'Sin monto total registrado: es el saldo actual más lo abonado' : 'Monto total del ' + que, monto: null, monto_txt: '', saldo: e.inicial, saldo_txt: money(e.inicial) }];
      for (const m of e.movimientos) {
        const movimiento = m.tipo === 'abono' ? 'Cuota en la planilla ' + m.ref : m.tipo === 'ajuste' ? 'Corrección manual del saldo' : 'Diferencia sin explicar';
        const detalle = m.tipo === 'abono' ? (m.pagada ? 'Pagada' : 'Generada: descontado, sin pagar') : m.tipo === 'ajuste' ? 'De ' + money(m.antes) + ' a ' + money(m.despues) + (m.usuario ? ' · ' + m.usuario : '') + (m.nota ? ' · ' + m.nota : '') : 'Ajuste anterior o abono fuera del sistema';
        filas.push({ fecha: m.fecha ? fecha(m.fecha) : '', movimiento, detalle, monto: m.monto, monto_txt: money(m.monto), saldo: m.saldo, saldo_txt: money(m.saldo) });
      }
      return { ...e, c, concepto: (c.concepto + ' · ' + this.catNombre(c)).slice(0, 120), filas };
    },
    async exportarCuenta(formato) {
      const ests = this.cuentaEstados;
      if (!ests.length) return;
      const varios = ests.length > 1, c = ests[0].c, empleado = this.nombres[c.empleado_id] || '—';
      const titulo = ('Estado de cuenta · ' + empleado + (varios ? '' : ' · ' + c.concepto)).slice(0, 120);
      if (formato === 'csv' || formato === 'xlsx') {
        const cols = [...(varios ? [{ key: 'concepto', label: 'Concepto' }] : []), { key: 'fecha', label: 'Fecha' }, { key: 'movimiento', label: 'Movimiento' }, { key: 'detalle', label: 'Detalle' }, { key: 'monto', label: 'Monto', num: true }, { key: 'saldo', label: 'Saldo', num: true }];
        const filas = ests.flatMap(x => x.filas.map(f => ({ ...f, concepto: x.concepto })));
        return descargarTabla(formato, varios ? 'estado_cuenta_empleado_' + c.empleado_id : 'estado_cuenta_' + c.id, cols, filas, { titulo, registrar: a => registrarExportable(a, 'Estado de cuenta · ' + empleado, true) });
      }
      if (ests.length > 12) return toast('El PDF y el Word admiten hasta 12 préstamos o adelantos juntos: descárguelo en Excel o CSV, o elija uno solo', 'err');
      const columnas = [{ key: 'fecha', label: 'Fecha' }, { key: 'movimiento', label: 'Movimiento' }, { key: 'detalle', label: 'Detalle' }, { key: 'monto_txt', label: 'Monto', num: true }, { key: 'saldo_txt', label: 'Saldo', num: true }];
      const suma = k => ests.reduce((s, x) => s + (+x[k] || 0), 0);
      const kpis = [{ t: 'Saldo inicial', v: money(suma('inicial')) }, { t: 'Abonado en planillas', v: money(suma('abonado')) }, { t: 'Saldo actual', v: money(suma('saldo')) }];
      const secciones = varios ? ests.map(x => ({ titulo: x.concepto, columnas, filas: x.filas, totales: [{ t: 'Saldo actual', v: money(x.saldo) }] })) : [];
      const subtitulo = (varios ? 'Préstamos y adelantos de ' + empleado : this.catNombre(c)) + ': saldo inicial, cuotas descontadas en cada planilla, correcciones manuales del saldo y saldo actual.';
      const nota = 'Cada planilla descuenta su cuota al guardarla, aunque todavía no esté pagada. Una diferencia sin explicar es una corrección del saldo anterior al registro de correcciones o un abono fuera del sistema.';
      const archivo = varios ? 'empleado_prestamos_' + c.empleado_id : 'empleado_prestamo_' + c.id;
      try { await descargarReporte(formato, { titulo, subtitulo: subtitulo.slice(0, 300), periodo: 'Al ' + fecha(hoy()), kpis, cols: varios ? [] : columnas, rows: varios ? [] : ests[0].filas, secciones, totales: varios ? [] : [{ t: 'Saldo actual', v: money(ests[0].saldo) }], nota, archivo, privado: true }); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  template: `
  <div class="page">
    <PageHead title="Deducciones e ingresos fijos" sub="Préstamos y adelantos (con saldo), embargos judiciales, pensiones alimentarias, aporte a la asociación solidarista, seguros, bonificaciones, comisiones y viáticos. La planilla los aplica sola en cada período del empleado." :crumbs="[{label:'Recursos humanos'},{label:'Deducciones e ingresos fijos'}]">
      <button class="btn sec" @click="documento('pdf')" :disabled="!rows.length">⤓ PDF</button><button class="btn sec" @click="documento('docx')" :disabled="!rows.length">⤓ Word</button><button class="btn sec" @click="documento('xlsx')" :disabled="!rows.length">⤓ Excel</button><button class="btn sec" @click="documento('csv')" :disabled="!rows.length">⤓ CSV</button>
      <button class="btn" @click="abrir(null)" :disabled="!emps.length">+ Nuevo concepto</button>
    </PageHead>
    <div class="card"><div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
      <Field label="Empleado"><select v-model.number="empleado"><option :value="null">— Todos —</option><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}{{e.activo===false ? ' (inactivo)' : ''}}</option></select></Field>
      <p class="small muted" style="margin:0 0 10px">El orden de aplicación en la planilla es el de esta lista; si el neto no alcanza, las deducciones se limitan para no dejarlo en negativo.</p>
    </div></div>
    <div class="card pad0"><DataTable :rows="rows" :columns="columns" empty-title="Sin deducciones ni ingresos fijos" empty-text="Registre préstamos, embargos, pensiones, aportes o bonificaciones y la planilla los aplicará en cada período.">
      <template #actions="{row}"><button class="btn sm ghost" v-if="row.tipo!=='ingreso' && ['prestamo','adelanto'].includes(row.categoria)" title="Abonos por planilla, correcciones del saldo y saldo actual" @click.stop="verCuenta(row)">Estado de cuenta</button><button class="btn sm ghost" @click.stop="pausar(row)">{{row.activa===false ? 'Reactivar' : 'Pausar'}}</button><button class="btn icon" title="Editar" @click.stop="abrir(row)">✎</button><button class="btn icon" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
      <template #empty><button class="btn" @click="abrir(null)" :disabled="!emps.length">+ Nuevo concepto</button></template>
    </DataTable></div>
    <Modal v-if="modal" :title="modal.id ? 'Editar concepto' : 'Nuevo concepto'" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Empleado" req style="grid-column:1/-1"><select v-model.number="modal.empleado_id"><option v-for="e in emps" :key="e.id" :value="e.id">{{nombres[e.id]}}</option></select></Field>
        <Field label="Tipo" req><select v-model="modal.tipo" @change="cambiarTipo"><option value="deduccion">Deducción (se resta del neto)</option><option value="ingreso">Ingreso (se suma)</option></select></Field>
        <Field label="Categoría" req><select v-model="modal.categoria" @change="cambiarCategoria"><option v-for="c in categorias" :key="c[0]" :value="c[0]">{{c[1]}}</option></select></Field>
        <Field label="Concepto (como sale en el comprobante)" req style="grid-column:1/-1"><input v-model="modal.concepto" maxlength="80"></Field>
        <Field label="Cómo se calcula" v-if="esDeduccion"><select v-model="modal.modo"><option value="monto">Monto fijo por período</option><option value="porcentaje">Porcentaje del salario bruto</option></select></Field>
        <Field :label="modal.modo==='porcentaje' ? 'Porcentaje por período' : 'Monto por período'" req :help="conSaldo ? 'Cuota de cada planilla; se detiene al cancelar el saldo' : ''"><input type="number" min="0" step="0.01" v-model.number="modal.valor" class="mono"></Field>
        <Field label="Monto total" v-if="conSaldo && !modal.id" req help="Saldo inicial del préstamo o adelanto"><input type="number" min="0" step="0.01" v-model.number="modal.total" class="mono"></Field>
        <Field label="Saldo pendiente" v-if="conSaldo && modal.id" help="Baja con cada planilla; corríjalo si hubo abonos fuera del sistema"><input type="number" min="0" step="0.01" v-model.number="modal.saldo" class="mono"></Field>
        <Field label="Es salario (cotiza y paga renta)" v-if="!esDeduccion" help="Viáticos y subsidios no son salario"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="modal.salarial"> Sí</label></Field>
        <Field label="Desde" req><input type="date" v-model="modal.desde"></Field>
        <Field label="Hasta" help="Vacío = sin fecha de fin"><input type="date" v-model="modal.hasta"></Field>
        <Field label="Nota" style="grid-column:1/-1"><input v-model="modal.nota" placeholder="Número de expediente, oficio del juzgado, condiciones…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="cuenta" :title="'Estado de cuenta · ' + (nombres[cuenta.empleado_id] || '—')" lg @close="cuenta=null">
      <Field label="Qué incluir" v-if="cuentaConceptos.length > 1"><select v-model="cuenta.alcance"><option value="uno">Solo este préstamo o adelanto</option><option value="todos">Todos los préstamos y adelantos de este empleado ({{cuentaConceptos.length}})</option></select></Field>
      <div v-for="x in cuentaEstados" :key="x.c.id" style="margin-bottom:14px">
        <div class="row" style="margin-bottom:8px;gap:10px;flex-wrap:wrap"><span class="chip">{{x.concepto}}</span><span class="chip">Abonado en planillas {{money(x.abonado)}}</span><span class="chip on">Saldo actual {{money(x.saldo)}}</span></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Movimiento</th><th>Detalle</th><th class="num">Monto</th><th class="num">Saldo</th></tr></thead>
          <tbody><tr v-for="(f,i) in x.filas" :key="i"><td>{{f.fecha}}</td><td>{{f.movimiento}}</td><td class="small muted" style="white-space:normal">{{f.detalle}}</td><td class="num">{{f.monto_txt}}</td><td class="num">{{f.saldo_txt}}</td></tr></tbody>
          <tfoot><tr><th colspan="4" style="text-align:right">Saldo actual</th><th class="num">{{money(x.saldo)}}</th></tr></tfoot></table></div>
      </div>
      <p class="small muted" style="margin:0">Cada planilla descuenta su cuota al guardarla (aunque todavía no esté pagada) y la devuelve si se elimina. Si corrige el saldo a mano al editar el concepto, la corrección queda anotada aquí con su usuario y la fecha. Una «diferencia sin explicar» es una corrección anterior a ese registro o un abono fuera del sistema.</p>
      <template #foot><button class="btn sec" @click="exportarCuenta('pdf')">⤓ PDF</button><button class="btn sec" @click="exportarCuenta('docx')">⤓ Word</button><button class="btn ghost" @click="exportarCuenta('xlsx')">⤓ Excel</button><button class="btn ghost" @click="exportarCuenta('csv')">⤓ CSV</button><button class="btn" @click="cuenta=null">Cerrar</button></template>
    </Modal>
  </div>`,
};
