// Recursos humanos › Informes › Indicadores (4.21). Componente sin ruta propia: lo muestra informes.js (botón «Indicadores», o
// #/rrhh/informes?ver=indicadores). Con un rango de meses (el mes en curso por omisión; 12 meses como máximo) arma, con los registros
// que Recursos humanos ya tiene: costo de la planilla por departamento (planillas PAGADAS cuyo «Hasta» cae en el rango), ausentismo por
// tipo, rotación, cumpleaños y aniversarios de ingreso. Son fórmulas de función, en días naturales y rotuladas en la pantalla: no
// interpretan la norma laboral (ni días hábiles, ni feriados, ni índices oficiales). Todo se descarga al historial de Recursos
// humanos, porque lleva nombres, salarios y fechas personales.
import { money, fmt, fecha, hoy, toast } from '../../api.js';
import { empleados, nombreCompleto, planillas, ausencias, tipoAusencia, departamentoDe, diasEntre, sumarDiasISO, esPagada } from './_datos.js';
import { descargarReporte, descargarTabla, registrarExportable } from '../reportes/_montos.js';

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'];
const r2 = n => Math.round((+n || 0) * 100) / 100;
const porcentaje = (parte, total) => (total > 0 ? Math.round(parte / total * 10000) / 100 : 0);
const esMes = m => /^\d{4}-(0[1-9]|1[0-2])$/.test(String(m || ''));
const esFecha = f => /^\d{4}-\d{2}-\d{2}$/.test(String(f || ''));
const nombreMes = m => MESES[+m.slice(5, 7) - 1] + ' ' + m.slice(0, 4);
const finDeMes = m => m + '-' + String(new Date(+m.slice(0, 4), +m.slice(5, 7), 0).getDate()).padStart(2, '0');
const diaYMes = f => +f.slice(8, 10) + ' de ' + MESES[+f.slice(5, 7) - 1];
// Rango de meses «AAAA-MM» → fechas, días naturales y texto; con error si falta un mes, van al revés o pasan de 12 meses
export function rangoDeMeses(desde, hasta) {
  if (!esMes(desde) || !esMes(hasta)) return { ok: false, error: 'Elija el mes inicial y el mes final.' };
  const meses = (+hasta.slice(0, 4) - +desde.slice(0, 4)) * 12 + (+hasta.slice(5, 7) - +desde.slice(5, 7)) + 1;
  if (meses < 1) return { ok: false, error: 'El mes final no puede ser anterior al mes inicial.' };
  if (meses > 12) return { ok: false, error: 'El rango no puede pasar de 12 meses: acorte el período.' };
  const ini = desde + '-01', fin = finDeMes(hasta);
  return { ok: true, ini, fin, meses, dias: diasEntre(ini, fin), texto: meses === 1 ? nombreMes(desde) : nombreMes(desde) + ' a ' + nombreMes(hasta) };
}
// La fecha en que cae un día y mes («MM-DD») dentro del rango, o '' si no cae (el 29 de febrero se toma el 28 en los años que no lo tienen)
export function ocurrencia(md, ini, fin) {
  for (let y = +ini.slice(0, 4); y <= +fin.slice(0, 4); y++) {
    const f = y + '-' + (md === '02-29' && new Date(y, 1, 29).getDate() !== 29 ? '02-28' : md);
    if (f >= ini && f <= fin) return f;
  }
  return '';
}
// Días naturales que cubren unos tramos [desde, hasta] («AAAA-MM-DD»), contando una sola vez los días en que se traslapan
export function diasUnidos(tramos) {
  let total = 0, tope = '';
  for (const [a, b] of tramos.slice().sort((x, y) => x[0].localeCompare(y[0]))) {
    if (b <= tope) continue;                                              // ya contado dentro de un tramo anterior
    total += diasEntre(a > tope ? a : sumarDiasISO(tope, 1), b); tope = b;
  }
  return total;
}
// Fecha de salida que cuenta: la de la ficha, salvo que sea anterior al ingreso (quedó de un contrato anterior)
export function salidaVigente(e) { return esFecha(e.fecha_salida) && !(esFecha(e.fecha_ingreso) && e.fecha_salida < e.fecha_ingreso) ? e.fecha_salida : ''; }
// ¿Trabajaba en la empresa ese día? Desde su ingreso y hasta su salida; sin fecha de salida, según esté activo hoy
export function activoEn(e, f) { const s = salidaVigente(e); return (!esFecha(e.fecha_ingreso) || e.fecha_ingreso <= f) && (s ? s >= f : e.activo !== false); }
// Departamento ACTUAL del empleado: el de la lista de departamentos o, si no está en ella, el texto de la ficha
export function nombreDepartamento(e) { if (!e) return 'Sin departamento'; const d = departamentoDe(e); return d ? d.nombre : (String(e.departamento || '').trim() || 'Sin departamento'); }

const COLS = {
  costo: [{ key: 'departamento', label: 'Departamento' }, { key: 'empleados', label: 'Empleados', num: true }, { key: 'bruto', label: 'Salarios brutos', num: true, fmt: 'money' },
    { key: 'patronal', label: 'Cargas patronales', num: true, fmt: 'money' }, { key: 'reservas', label: 'Reservas', num: true, fmt: 'money' },
    { key: 'costo', label: 'Costo total', num: true, fmt: 'money' }, { key: 'pct', label: '% del costo', num: true, fmt: v => fmt(v, 2) }],
  ausentismo: [{ key: 'tipo', label: 'Tipo de ausencia' }, { key: 'registros', label: 'Registros', num: true }, { key: 'dias', label: 'Días naturales en el rango', num: true },
    { key: 'pct', label: '% de ausentismo', num: true, fmt: v => fmt(v, 2) }],
  rotacion: [{ key: 'movimiento', label: 'Movimiento' }, { key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'empleado', label: 'Empleado' }, { key: 'puesto', label: 'Puesto' }, { key: 'departamento', label: 'Departamento' }],
  cumpleanos: [{ key: 'dia', label: 'Día' }, { key: 'empleado', label: 'Empleado' }, { key: 'puesto', label: 'Puesto' }, { key: 'departamento', label: 'Departamento' }],
  aniversarios: [{ key: 'dia', label: 'Día' }, { key: 'empleado', label: 'Empleado' }, { key: 'anios', label: 'Años en la empresa', num: true }, { key: 'ingreso', label: 'Ingreso', fmt: 'date' }, { key: 'departamento', label: 'Departamento' }],
};
const NOTAS = {
  costo: 'Suma las filas de las planillas pagadas (también las complementarias) cuyo «Hasta» cae en el rango. El departamento es el ACTUAL de cada empleado, no el que tenía cuando se pagó la planilla. No incluye liquidaciones ni aguinaldo.',
  ausentismo: 'Ausentismo = días naturales de ausencia registrados dentro del rango ÷ (empleados activos promedio × días naturales del rango) × 100. Cuenta todo lo registrado en Ausencias e incapacidades, con fines de semana y feriados incluidos; las vacaciones no cuentan. Si un empleado tiene dos registros que se traslapan, cada tipo muestra los días de sus registros, pero en el total y en el porcentaje general esos días cuentan una sola vez. Si el rango incluye días que aún no pasan, el porcentaje baja.',
  rotacion: 'Rotación = salidas del rango ÷ promedio de empleados (los del primer día del rango y los del último, entre 2) × 100. Ingresos y salidas según las fechas de la ficha; un inactivo sin fecha de salida no se cuenta.',
  cumpleanos: 'Empleados activos con fecha de nacimiento en la ficha cuyo cumpleaños cae en el rango.',
  aniversarios: 'Empleados activos que cumplen uno o más años de haber ingresado, según la fecha de ingreso de la ficha.',
};
// El servidor admite notas de sección de hasta 300 letras: al PDF y al Word va la nota hasta la última frase que quepa (en pantalla sale entera)
export const notaDoc = t => { const s = String(t || ''); if (s.length <= 300) return s; const c = s.slice(0, 300), i = c.lastIndexOf('. '); return i > 60 ? c.slice(0, i + 1) : c.slice(0, 299) + '…'; };
const texto = (c, r) => { const v = r[c.key]; return typeof c.fmt === 'function' ? c.fmt(v, r) : c.fmt === 'money' ? money(v || 0) : c.fmt === 'date' ? fecha(v) : String(v ?? ''); };

export default {
  props: { mesInicial: String },
  data() { const m = esMes(this.mesInicial) ? this.mesInicial : hoy().slice(0, 7); return { desde: m, hasta: m, emps: empleados(), generando: false }; },
  computed: {
    rango() { return rangoDeMeses(this.desde, this.hasta); },
    // empleados el primer día del rango, el último y su promedio (la base del ausentismo y de la rotación)
    planta() {
      const r = this.rango;
      if (!r.ok) return { inicio: 0, fin: 0, promedio: 0 };
      const inicio = this.emps.filter(e => activoEn(e, r.ini)).length, fin = this.emps.filter(e => activoEn(e, r.fin)).length;
      return { inicio, fin, promedio: (inicio + fin) / 2 };
    },
    costoDepto() {
      const r = this.rango, acc = {}, porId = Object.fromEntries(this.emps.map(e => [e.id, e]));
      let pagadas = 0;
      if (r.ok) for (const p of planillas()) {
        const h = String(p.hasta || '');
        if (!esPagada(p) || h < r.ini || h > r.fin) continue;
        pagadas++;
        for (const f of p.filas || []) {
          const d = nombreDepartamento(porId[f.empleado_id]), o = acc[d] = acc[d] || { id: d, departamento: d, ids: new Set(), bruto: 0, patronal: 0, reservas: 0, costo: 0 };
          o.ids.add(f.empleado_id || f.nombre); o.bruto += +f.bruto || 0; o.patronal += +f.total_patronal || 0; o.reservas += +f.total_provisiones || 0; o.costo += +f.costo_total || 0;
        }
      }
      const tot = { bruto: 0, patronal: 0, reservas: 0, costo: 0 };
      for (const o of Object.values(acc)) for (const k in tot) tot[k] = r2(tot[k] + o[k]);
      const filas = Object.values(acc).map(o => ({ id: o.id, departamento: o.departamento, empleados: o.ids.size, bruto: r2(o.bruto), patronal: r2(o.patronal), reservas: r2(o.reservas), costo: r2(o.costo), pct: porcentaje(o.costo, tot.costo) }))
        .sort((a, b) => b.costo - a.costo || a.departamento.localeCompare(b.departamento));
      return { filas, tot, pagadas };
    },
    ausentismo() {
      const r = this.rango, acc = {}, porEmpleado = {};
      if (r.ok) for (const a of ausencias()) {
        const ini = String(a.desde || ''), fin = String(a.hasta || a.desde || '');
        if (!esFecha(ini) || !esFecha(fin) || fin < r.ini || ini > r.fin) continue;
        const d1 = ini < r.ini ? r.ini : ini, d2 = fin > r.fin ? r.fin : fin;
        const dias = diasEntre(d1, d2), o = acc[a.tipo] = acc[a.tipo] || { id: a.tipo, tipo: tipoAusencia(a.tipo), registros: 0, dias: 0 };
        o.registros++; o.dias += dias;
        (porEmpleado[a.empleado_id] = porEmpleado[a.empleado_id] || []).push([d1, d2]);
      }
      // Ausencias deja guardar registros traslapados de un mismo empleado: cada tipo muestra los días de sus registros, pero en el
      // total y en el % general ese día cuenta una sola vez (si no, el ausentismo podía pasar de 100 %)
      const base = r.ok ? this.planta.promedio * r.dias : 0, dias = Object.values(porEmpleado).reduce((s, t) => s + diasUnidos(t), 0);
      const filas = Object.values(acc).map(o => ({ ...o, pct: porcentaje(o.dias, base) })).sort((a, b) => b.dias - a.dias || String(a.tipo).localeCompare(String(b.tipo)));
      return { filas, dias, base, pct: porcentaje(dias, base) };
    },
    rotacion() {
      const r = this.rango, filas = [];
      if (r.ok) for (const e of this.emps) {
        const fila = (movimiento, f) => filas.push({ id: movimiento + ':' + e.id, movimiento, fecha: f, empleado: nombreCompleto(e), puesto: e.puesto || '', departamento: nombreDepartamento(e) });
        if (esFecha(e.fecha_ingreso) && e.fecha_ingreso >= r.ini && e.fecha_ingreso <= r.fin) fila('Ingreso', e.fecha_ingreso);
        const s = salidaVigente(e);
        if (s && s >= r.ini && s <= r.fin) fila('Salida', s);
      }
      filas.sort((a, b) => a.fecha.localeCompare(b.fecha) || a.empleado.localeCompare(b.empleado));
      const ingresos = filas.filter(x => x.movimiento === 'Ingreso').length, salidas = filas.length - ingresos;
      return { filas, ingresos, salidas, pct: porcentaje(salidas, this.planta.promedio) };
    },
    cumpleanos() {
      const r = this.rango;
      if (!r.ok) return [];
      return this.emps.filter(e => e.activo !== false && esFecha(e.nacimiento)).map(e => ({ e, f: ocurrencia(e.nacimiento.slice(5), r.ini, r.fin) })).filter(x => x.f)
        .map(x => ({ id: x.e.id, fecha: x.f, dia: diaYMes(x.f), empleado: nombreCompleto(x.e), puesto: x.e.puesto || '', departamento: nombreDepartamento(x.e) }))
        .sort((a, b) => a.fecha.localeCompare(b.fecha) || a.empleado.localeCompare(b.empleado));
    },
    aniversarios() {
      const r = this.rango;
      if (!r.ok) return [];
      return this.emps.filter(e => e.activo !== false && esFecha(e.fecha_ingreso)).map(e => ({ e, f: ocurrencia(e.fecha_ingreso.slice(5), r.ini, r.fin) })).filter(x => x.f)
        .map(x => ({ id: x.e.id, fecha: x.f, dia: diaYMes(x.f), empleado: nombreCompleto(x.e), anios: +x.f.slice(0, 4) - +x.e.fecha_ingreso.slice(0, 4), ingreso: x.e.fecha_ingreso, departamento: nombreDepartamento(x.e) }))
        .filter(x => x.anios >= 1).sort((a, b) => a.fecha.localeCompare(b.fecha) || a.empleado.localeCompare(b.empleado));
    },
    kpis() {
      const c = this.costoDepto, a = this.ausentismo, ro = this.rotacion;
      return [{ t: 'Costo de la planilla', v: money(c.tot.costo), d: c.pagadas + (c.pagadas === 1 ? ' planilla pagada' : ' planillas pagadas') + ' en el rango' },
        { t: 'Ausentismo', v: fmt(a.pct, 2) + ' %', d: a.dias + (a.dias === 1 ? ' día' : ' días') + ' de ausencia · ' + fmt(this.planta.promedio, 1) + ' empleados en promedio' },
        { t: 'Rotación', v: fmt(ro.pct, 2) + ' %', d: ro.ingresos + (ro.ingresos === 1 ? ' ingreso' : ' ingresos') + ' · ' + ro.salidas + (ro.salidas === 1 ? ' salida' : ' salidas') },
        { t: 'Cumpleaños y aniversarios', v: this.cumpleanos.length + ' y ' + this.aniversarios.length, d: 'en el rango' }];
    },
    // las cinco tablas de la pantalla, con sus columnas, sus totales y su nota; de aquí salen también el PDF, el Excel y el CSV
    bloques() {
      const c = this.costoDepto, a = this.ausentismo, ro = this.rotacion, M = v => money(v || 0);
      return [
        { k: 'costo', titulo: 'Costo de la planilla por departamento', sub: 'planillas pagadas cuyo «Hasta» cae en el rango', rows: c.filas, cols: COLS.costo, vacio: 'Sin planillas pagadas en el rango', nota: NOTAS.costo,
          totales: [{ t: 'Salarios brutos', v: M(c.tot.bruto) }, { t: 'Cargas patronales', v: M(c.tot.patronal) }, { t: 'Reservas', v: M(c.tot.reservas) }, { t: 'Costo total', v: M(c.tot.costo) }] },
        { k: 'ausentismo', titulo: 'Ausentismo', sub: 'días de ausencia registrados, por tipo', rows: a.filas, cols: COLS.ausentismo, vacio: 'Sin ausencias registradas en el rango', nota: NOTAS.ausentismo,
          totales: [{ t: 'Días de ausencia en el rango', v: String(a.dias) }, { t: 'Empleados activos promedio × días naturales', v: fmt(a.base, 1) }, { t: 'Ausentismo', v: fmt(a.pct, 2) + ' %' }] },
        { k: 'rotacion', titulo: 'Rotación', sub: 'ingresos y salidas del rango', rows: ro.filas, cols: COLS.rotacion, vacio: 'Sin ingresos ni salidas en el rango', nota: NOTAS.rotacion,
          totales: [{ t: 'Ingresos', v: String(ro.ingresos) }, { t: 'Salidas', v: String(ro.salidas) }, { t: 'Empleados el primer día', v: String(this.planta.inicio) }, { t: 'Empleados el último día', v: String(this.planta.fin) }, { t: 'Rotación', v: fmt(ro.pct, 2) + ' %' }] },
        { k: 'cumpleanos', titulo: 'Cumpleaños', sub: 'empleados activos', rows: this.cumpleanos, cols: COLS.cumpleanos, vacio: 'Sin cumpleaños en el rango', nota: NOTAS.cumpleanos, totales: [] },
        { k: 'aniversarios', titulo: 'Aniversarios de ingreso', sub: 'años cumplidos en la empresa', rows: this.aniversarios, cols: COLS.aniversarios, vacio: 'Sin aniversarios en el rango', nota: NOTAS.aniversarios, totales: [] },
      ];
    },
  },
  methods: {
    // Una tabla en PDF, Excel o CSV, al historial de descargas de Recursos humanos
    exportar(k, formato) {
      const b = this.bloques.find(x => x.k === k);
      if (!this.rango.ok || !b || !b.rows.length) return toast('No hay datos que exportar en ese rango', 'err');
      const titulo = b.titulo + ' · ' + this.rango.texto;
      descargarTabla(formato, 'indicadores_' + k + '_' + this.desde + (this.hasta === this.desde ? '' : '_' + this.hasta), b.cols, b.rows, { titulo, periodo: 'Del ' + fecha(this.rango.ini) + ' al ' + fecha(this.rango.fin), registrar: a => registrarExportable(a, titulo, true) });
    },
    // Todo junto en PDF o Word (lo arma el servidor), también al historial de Recursos humanos
    async documento(formato) {
      if (!this.rango.ok || this.generando) return;
      this.generando = true;
      const secciones = this.bloques.map(b => ({ titulo: b.titulo, columnas: b.cols.map(c => ({ key: c.key, label: c.label, num: !!c.num })), filas: b.rows.map(r => Object.fromEntries(b.cols.map(c => [c.key, texto(c, r)]))), totales: b.totales, nota: notaDoc(b.rows.length ? b.nota : b.vacio + '. ' + b.nota) }));
      const kpis = this.kpis.map(x => ({ t: x.t, v: x.v })), periodo = 'Del ' + fecha(this.rango.ini) + ' al ' + fecha(this.rango.fin);
      const subtitulo = 'Costo de la planilla por departamento, ausentismo, rotación, cumpleaños y aniversarios de ' + this.rango.texto + '.';
      const nota = 'Indicadores de función calculados en días naturales con lo registrado en Recursos humanos; no son índices oficiales.';
      const archivo = 'indicadores_rrhh_' + this.desde + (this.hasta === this.desde ? '' : '_' + this.hasta);
      try { await descargarReporte(formato, { titulo: 'Indicadores de Recursos humanos', subtitulo, periodo, kpis, cols: [], rows: [], secciones, nota, archivo, privado: true }); }
      catch (e) { toast(e.message, 'err'); }
      this.generando = false;
    },
  },
  template: `
  <div>
    <div class="card"><div class="row" style="gap:12px;align-items:end;flex-wrap:wrap">
      <Field label="Desde (mes)"><input type="month" v-model="desde"></Field>
      <Field label="Hasta (mes)"><input type="month" v-model="hasta"></Field>
      <div class="row" style="gap:8px;flex-wrap:wrap;padding-bottom:4px"><button class="btn sec" :disabled="!rango.ok || generando" @click="documento('pdf')" title="Todos los indicadores en un documento">⤓ PDF</button><button class="btn sec" :disabled="!rango.ok || generando" @click="documento('docx')" title="Todos los indicadores en un documento">⤓ Word</button></div>
      <span class="small muted" style="padding-bottom:8px" v-if="rango.ok">{{rango.texto}} · {{rango.dias}} días naturales · el rango admite hasta 12 meses</span>
    </div></div>
    <div class="alert err" v-if="!rango.ok">{{rango.error}}</div>
    <template v-else>
      <div class="dash" style="margin-bottom:18px">
        <div class="kpi w3" v-for="x in kpis" :key="x.t"><div class="t">{{x.t}}</div><div class="v">{{x.v}}</div><div class="d">{{x.d}}</div></div>
      </div>
      <div class="card pad0" v-for="b in bloques" :key="b.k">
        <div class="row" style="padding:14px 16px 0;gap:10px;flex-wrap:wrap;justify-content:space-between;align-items:center"><h2 style="margin:0">{{b.titulo}} <small>{{b.sub}}</small></h2>
          <div class="row" style="gap:6px"><button class="btn sm ghost" :disabled="!b.rows.length" @click="exportar(b.k, 'pdf')">⤓ PDF</button><button class="btn sm ghost" :disabled="!b.rows.length" @click="exportar(b.k, 'xlsx')">⤓ Excel</button><button class="btn sm ghost" :disabled="!b.rows.length" @click="exportar(b.k, 'csv')">⤓ CSV</button></div>
        </div>
        <DataTable :rows="b.rows" :columns="b.cols" :page-size="20" :empty-title="b.vacio" empty-text="Pruebe con otro rango de meses."></DataTable>
        <div class="row" style="padding:6px 16px 0;gap:8px;flex-wrap:wrap" v-if="b.totales.length"><span class="chip" style="cursor:default" v-for="t in b.totales" :key="t.t">{{t.t}}: <b>{{t.v}}</b></span></div>
        <p class="small muted" style="padding:10px 16px;margin:0">{{b.nota}}</p>
      </div>
    </template>
  </div>`,
};
