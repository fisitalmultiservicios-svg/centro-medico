// Gastos › Nueva orden de compra — formulario (datos de ejemplo en mock 'ordenes'; PDF real con POST /api/pdf/documento)
import { api, toast, money, hoy, mock, CAT, monedas, siguienteNumero } from '../../api.js';
import { store, sesion } from '../../app.js';
import { proveedores, ordenes, totalLineas, BODEGAS, dias, payloadOrdenCompra } from './_datos.js';
import { abrirPdfDocumento } from '../ventas/cotizaciones.js';

export default {
  props: ['params'],
  data() {
    const lista = ordenes();
    const num = mock.get('ordenes_numeracion', { prefijo: 'OC-', siguiente: mock.nextId(lista, 'ordenes') });
    if (num.siguiente < mock.nextId(lista, 'ordenes')) num.siguiente = mock.nextId(lista, 'ordenes');
    num.siguiente = siguienteNumero(mock.get('ordenes', []), 'codigo', num.prefijo, num.siguiente);    // lo que se ve es lo que se guarda
    return {
      BODEGAS, bodegasApi: [], monedasOpc: monedas.opciones(), plazos: CAT.terminosPago, numModal: false, num, generando: false, duplicadoDe: '',
      f: { moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), bodega: 'Principal', proveedor_id: null, fecha: hoy(), entrega: dias(8), plazo: '30 días', lineas: [], terminos: '', notas: '', marca_id: null },
      marcas: [],
      reponerN: 0,   // 3.87: líneas que vinieron de Inventario › Por reponer
    };
  },
  /* 3.35: bodegas reales de la empresa (antes una lista de ejemplo) */
  async created() {
    if (this.params && this.params.duplicar) {      // Duplicar (3.43): mismo proveedor, líneas y condiciones; número y fechas nuevos
      const x = ordenes().find(o => o.id == this.params.duplicar);
      if (x) { const c = JSON.parse(JSON.stringify(x)); this.f = { ...this.f, ...c, id: undefined, codigo: undefined, estado: undefined, fecha: hoy(), entrega: dias(8), tipo_cambio: monedas.tc(c.moneda || monedas.principal().codigo) }; this.duplicadoDe = x.codigo; }
      else toast('No se encontró la orden a duplicar', 'err');
    }
    if (this.params && this.params.reponer) await this.desdeReponer();   // 3.87: orden sugerida desde Inventario › Por reponer
    api('/api/marcas').then(l => { this.marcas = (l || []).filter(m => m.activa || m.id === this.f.marca_id); if (!this.f.marca_id) { const p = this.marcas.find(m => m.id === sesion.marcaSucursal) || this.marcas.find(m => m.predeterminada); if (p) this.f.marca_id = p.id; } }).catch(() => {});   /* 3.45; 3.82: la de la sucursal */
    try { this.bodegasApi = await api('/api/inventario/bodegas'); const p = this.bodegasApi.find(b => b.principal) || this.bodegasApi[0]; if (p && !this.bodegasApi.some(b => b.nombre === this.f.bodega)) this.f.bodega = p.nombre; } catch (e) { /* sin bodegas: queda el nombre por defecto */ }
    if (this.params && this.params.reponer && this.params.bodega_id) { const b = this.bodegasApi.find(x => x.id == this.params.bodega_id); if (b) this.f.bodega = b.nombre; } },
  computed: {
    provs() { return proveedores(); },
    store() { return store; },
    prov() { return this.provs.find(p => p.id == this.f.proveedor_id) || null; },
    codigo() { return this.num.prefijo + String(this.num.siguiente).padStart(4, '0'); },
  },
  watch: { 'f.moneda'(v) { this.f.tipo_cambio = monedas.tcPrecio(v); } },
  methods: {
    money,
    // 3.87: líneas (cantidad sugerida al costo del ítem) y proveedor habitual que manda Inventario › Por reponer
    async desdeReponer() {
      try {
        const qs = new URLSearchParams({ ids: String(this.params.reponer) }); if (this.params.bodega_id) qs.set('bodega_id', this.params.bodega_id);
        const r = await api('/api/inventario/reponer?' + qs);
        this.f.lineas = (r.items || []).map(x => ({ producto_id: x.producto_id, detalle: x.nombre, cabys: x.cabys, cantidad: x.sugerido, precio_unitario: x.costo, descuento: 0, descuento_pct: 0, codigo_tarifa: x.codigo_tarifa, tarifa: x.tarifa, es_servicio: false, unidad_medida: x.unidad_medida }));
        const prov = this.params.proveedor ? this.provs.find(p => p.id == this.params.proveedor) : null; if (prov) this.f.proveedor_id = prov.id;
        this.reponerN = this.f.lineas.length;
        if (!this.reponerN) toast('Esos ítems ya no están por reponer', 'err');
      } catch (e) { toast(e.message, 'err'); }
    },
    guardarNumeracion() { mock.set('ordenes_numeracion', this.num); this.numModal = false; toast('Numeración actualizada', 'ok'); },
    guardar() {
      if (!this.f.proveedor_id) return toast('Seleccione el proveedor', 'err');
      if (!this.f.fecha || !this.f.entrega) return toast('Indique la fecha y la fecha de entrega', 'err');
      if (this.f.entrega < this.f.fecha) return toast('La fecha de entrega debe ser igual o posterior a la fecha de la orden', 'err');
      const lineas = this.f.lineas.filter(l => l.detalle || l.precio_unitario);
      if (!lineas.length) return toast('Agregue al menos una línea', 'err');
      const lista = ordenes();
      this.num.siguiente = siguienteNumero(mock.get('ordenes', []), 'codigo', this.num.prefijo, this.num.siguiente);   // nunca un código ya usado
      const o = { id: mock.nextId(lista, 'ordenes'), codigo: this.codigo, proveedor_id: this.prov.id, proveedor: this.prov.nombre, fecha: this.f.fecha, entrega: this.f.entrega, plazo: this.f.plazo, estado: 'Abierta', moneda: this.f.moneda, tipo_cambio: this.f.tipo_cambio, bodega: this.f.bodega, lineas, total: Math.round(totalLineas(lineas) * 100) / 100, terminos: this.f.terminos, notas: this.f.notas };
      lista.push(o); mock.set('ordenes', lista);
      this.num.siguiente++; mock.set('ordenes_numeracion', this.num);
      toast('Orden de compra ' + o.codigo + ' guardada', 'ok');
      location.hash = '/gastos/ordenes';
    },
    // Vista previa en PDF de la orden tal como está en pantalla (sin guardarla).
    async pdf() {
      const lineas = this.f.lineas.filter(l => l.detalle || l.precio_unitario);
      if (!lineas.length) return toast('Agregue al menos una línea para generar el PDF', 'err');
      this.generando = true;
      try { await abrirPdfDocumento(payloadOrdenCompra({ ...this.f, codigo: this.codigo, proveedor: this.prov ? this.prov.nombre : '', lineas })); }
      catch (err) { toast(err.message, 'err'); }
      this.generando = false;
    },
  },
  template: `
  <div class="page">
    <PageHead title="Nueva orden de compra" :crumbs="[{label:'Órdenes de compra',to:'/gastos/ordenes'},{label:'Nueva'}]"></PageHead>
    <div class="alert info" v-if="reponerN" style="margin-bottom:12px">Orden sugerida desde <a href="#/inventario/reponer">Inventario › Por reponer</a>: {{reponerN}} ítem{{reponerN === 1 ? '' : 's'}} con la cantidad sugerida al costo de cada uno. Revise el proveedor, las cantidades y los precios antes de guardar.</div>
    <div class="alert info" v-if="duplicadoDe" style="margin-bottom:12px">Copia de la orden <b>{{duplicadoDe}}</b> con fecha de hoy: revise proveedor, líneas y precios antes de guardar.</div>
    <div class="card">
      <div class="grid cols-3">
        <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda + ' (el del sistema; cámbielo si aplica otro)'"><input type="number" step="0.01" v-model.number="f.tipo_cambio"></Field>
        <Field label="Bodega"><Buscador v-model="f.bodega" :opciones="bodegasApi" valor="nombre" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        <Field label="Marca" v-if="marcas.length" help="Logo y nombre comercial del PDF"><select v-model.number="f.marca_id"><option :value="null">Empresa</option><option v-for="m in marcas" :key="m.id" :value="m.id">{{m.nombre}}</option></select></Field>
        <Field label="No."><div class="row"><input class="mono" :value="codigo" readonly style="flex:1"><button class="btn icon" title="Configurar numeración" @click="numModal=true">⚙</button></div></Field>
      </div>
      <h2 style="margin-top:12px">Proveedor</h2>
      <div class="grid cols-3">
        <Field label="Proveedor" req><Buscador v-model="f.proveedor_id" :opciones="provs" detalle="numero_id" vacio="Seleccionar" agregar="proveedor"></Buscador></Field>
        <Field label="Identificación"><input :value="prov ? prov.numero_id : ''" readonly></Field>
        <Field label="Teléfono"><input :value="prov ? prov.telefono : ''" readonly></Field>
        <Field label="Fecha" req><input type="date" v-model="f.fecha"></Field>
        <Field label="Fecha de entrega" req><input type="date" v-model="f.entrega"></Field>
        <Field label="Plazo de pago"><select v-model="f.plazo"><option v-for="p in plazos" :key="p.nombre">{{p.nombre}}</option></select></Field>
      </div>
    </div>
    <div class="card"><h2>Ítems</h2><LineEditor v-model="f.lineas" :productos="store.productos" :moneda="f.moneda" compra></LineEditor></div>
    <div class="card"><div class="grid cols-2">
      <Field label="Términos y condiciones"><textarea rows="3" v-model="f.terminos" placeholder="Condiciones de entrega y pago acordadas"></textarea></Field>
      <Field label="Notas"><textarea rows="3" v-model="f.notas" placeholder="Observaciones para el proveedor"></textarea></Field>
    </div></div>
    <div class="row end" style="margin-bottom:18px"><a class="btn ghost" href="#/gastos/ordenes">Cancelar</a><button class="btn sec" @click="pdf" :disabled="generando">{{generando ? 'Generando…' : 'Vista previa PDF'}}</button><button class="btn" @click="guardar">Guardar</button></div>
    <Comments :saved="false"></Comments>
    <Modal v-if="numModal" title="Numeración de órdenes de compra" @close="numModal=false">
      <div class="grid cols-2">
        <Field label="Prefijo"><input v-model="num.prefijo"></Field>
        <Field label="Siguiente número"><input type="number" min="1" step="1" v-model.number="num.siguiente"></Field>
      </div>
      <p class="small muted">Próximo código: <span class="mono">{{codigo}}</span></p>
      <template #foot><button class="btn ghost" @click="numModal=false">Cancelar</button><button class="btn" @click="guardarNumeracion">Guardar</button></template>
    </Modal>
  </div>`,
};
