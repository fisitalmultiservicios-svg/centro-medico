// Gastos › Recepción de comprobantes — real: /api/recepcion (comprobantes recibidos de proveedores), carga de XML, buzón IMAP,
// Mensaje Receptor (aceptar / aceptar parcialmente / rechazar) firmado y enviado a Hacienda, plazo de 8 días hábiles.
import { api, toast, money, fecha, hoy, fmtCant, token, cabecerasAuth } from '../../api.js';
import { store, sesion } from '../../app.js';
import { planCuentas } from '../contabilidad/catalogo.js';   // 4.3: cuenta contable de la compra o gasto
import { sinRegistrar, notaSinFactura, mesPasado, avisoRectificacion, motivoValido } from './_registro.js';   // 4.23: el registro de compras y gastos

const CONDICIONES = { '01': '01 · Genera crédito IVA total', '02': '02 · Genera crédito IVA parcial', '03': '03 · Bienes de capital', '04': '04 · Gasto corriente, no genera crédito', '05': '05 · Proporcionalidad' };
// 3.75: por qué se propone un ítem para una línea del comprobante
const MOTIVOS = { relacion: 'Relacionado en una factura anterior de este proveedor', codigo: 'Mismo código que el ítem', nombre: 'Mismo nombre que el ítem', cabys: 'Mismo CABYS y nombre parecido' };
const CON_MERCADERIA = ['01', '04', '08', '09'];

export default {
  props: ['params'],
  data() {
    return {
      lista: [], tab: 'pendientes', q: '', cargando: true, CONDICIONES, MOTIVOS,
      resp: null, procesando: false, subiendo: false, leyendo: false, hist: null, validando: false, validacion: null,
      inv: null,   // 3.75: ventana «Inventario»: líneas del comprobante relacionadas con los ítems
      reg: null,   // 4.23: ventana «Registrar como compra o gasto» de un aceptado que se eliminó del registro
      buzon: { imap_host: '', imap_puerto: 993, imap_seguridad: 'ssl', imap_usuario: '', imap_password: '', imap_carpeta: 'INBOX', imap_dias: 60, imap_ultima: null, imap_error: null, imap_intento: null }, buzonGuardado: false, guardandoBuzon: false,
      resultado: null,
    };
  },
  computed: {
    store() { return store; },
    sesion() { return sesion; },
    items() { return (store.productos || []).filter(p => p.activo !== false && !p.es_servicio && p.inventariable !== false); },   // ítems que pueden recibir mercadería (3.75)
    // un mensaje rechazado por Hacienda o con error se vuelve a responder: cuenta como pendiente (R139)
    pendientes() { return this.lista.filter(r => !r.respuesta || ['rechazado', 'error'].includes(r.estado_mensaje || '')); },
    anteriores() { return this.lista.filter(r => r.estado_mensaje === 'importado'); },   // 4.2: del sistema anterior
    sinValidar() { return this.anteriores.filter(r => !r.validacion).length; },
    respondidos() { return this.lista.filter(r => r.respuesta && !['rechazado', 'error'].includes(r.estado_mensaje || '')); },
    rows() { return (this.tab === 'pendientes' ? this.pendientes : this.respondidos).map(r => ({ ...r, numero: (r.consecutivo || r.clave.slice(21, 41)), plazo: this.plazo(r), hacienda: r.estado_mensaje === 'importado' ? (r.validacion ? (r.validacion.ok ? 'validado en Hacienda' : 'revisar: ' + (r.validacion.comprobante === 'http_error' ? 'sin respuesta' : r.validacion.texto)) : 'sistema anterior') : (r.estado_mensaje || ''),
      respuesta_nombre: sinRegistrar(r) ? 'Aceptado sin registrar' : r.respuesta_nombre })); },   // 4.23: aceptado ante Hacienda, pero fuera de los reportes y de la contabilidad
    columns() {
      const base = [
        { key: 'emisor_nombre', label: 'Emisor', fmt: (v, r) => v + ' · ' + r.emisor_id },
        { key: 'tipo_nombre', label: 'Tipo' },
        { key: 'fecha_emision', label: 'Fecha', fmt: 'date' },
        { key: 'numero', label: 'Número', mono: true },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
      ];
      return this.tab === 'pendientes'
        ? base.concat([{ key: 'plazo', label: 'Responder antes de', fmt: 'badge' }])
        : base.concat([{ key: 'respuesta_nombre', label: 'Respuesta', fmt: 'badge' }, { key: 'hacienda', label: 'Hacienda', fmt: 'badge' }]);
    },
    verBuzon() { return sesion.puede('gastos') || sesion.puede('configurar'); },   // 3.87: lo mismo que exige el servidor para leer el buzón (Solo lectura no)
    vencidas() { return this.pendientes.filter(r => r.dias_restantes !== null && r.dias_restantes < 0).length; },
    proximas() { return this.pendientes.filter(r => r.dias_restantes !== null && r.dias_restantes >= 0 && r.dias_restantes <= 3).length; },
  },
  methods: {
    money, fecha, fmtCant,
    plazo(r) { if (r.dias_restantes === null) return '—'; if (r.dias_restantes < 0) return 'Vencido ' + fecha(r.fecha_limite); if (r.dias_restantes <= 3) return fecha(r.fecha_limite) + ' (' + r.dias_restantes + ' d)'; return fecha(r.fecha_limite); },
    async cargar() {
      this.cargando = true;
      try { this.lista = await api('/api/recepcion'); } catch (e) { toast(e.message, 'err'); }
      if (this.verBuzon) { try { const b = await api('/api/recepcion/buzon'); this.buzon = { ...this.buzon, ...b, imap_password: '' }; this.buzonGuardado = !!b.imap_host; } catch {} }
      this.cargando = false;
    },
    abrirRespuesta(r, mensaje) {
      const ref = ['02', '03'].includes(r.tipo_documento) && r.referencia_clave ? this.lista.find(z => z.clave === r.referencia_clave) : null;   // 4.3: la nota del proveedor hereda de la factura a la que se refiere
      this.resp = { row: r, mensaje, condicion_impuesto: mensaje === '07' ? null : '01', detalle: mensaje === '07' ? '' : 'Comprobante recibido conforme.', monto_impuesto_acreditar: r.impuesto, monto_gasto_aplicable: r.total,
        clasificacion: r.clasificacion || (ref && ref.clasificacion) || (CON_MERCADERIA.includes(r.tipo_documento) ? 'compra' : 'gasto'), cuenta_contable: r.cuenta_contable || (ref && ref.cuenta_contable) || '' };
    },
    cambioCondicion() { const c = this.resp.condicion_impuesto, r = this.resp.row; this.resp.monto_impuesto_acreditar = c === '04' ? 0 : (c === '01' || c === '03') ? r.impuesto : this.resp.monto_impuesto_acreditar; },
    async confirmarRespuesta() {
      const x = this.resp;
      if (x.mensaje === '07' && !x.detalle.trim()) return toast('Indique el motivo del rechazo', 'err');
      if (x.mensaje !== '07' && x.row.impuesto && !x.condicion_impuesto) return toast('Indique la condición del IVA', 'err');
      this.procesando = true;
      try {
        const r = await api('/api/recepcion/' + x.row.id + '/responder', { method: 'POST', body: { mensaje: x.mensaje, condicion_impuesto: x.mensaje === '07' ? null : x.condicion_impuesto, detalle: x.detalle || null, monto_impuesto_acreditar: x.mensaje === '07' ? null : +x.monto_impuesto_acreditar, monto_gasto_aplicable: x.mensaje === '07' ? null : +x.monto_gasto_aplicable , clasificacion: x.mensaje === '07' ? null : x.clasificacion, cuenta_contable: x.mensaje === '07' ? null : (x.cuenta_contable || null) } });
        toast(`Mensaje receptor ${r.consecutivo_receptor}: ${r.estado_mensaje}${r.mensaje_hacienda ? ' · ' + r.mensaje_hacienda : ''}`, r.estado_mensaje === 'error' ? 'err' : 'ok');
        this.resp = null; this.tab = 'respondidos'; await this.cargar();
        // 3.75: aceptada la factura, se ofrece relacionar sus líneas con los ítems y darles entrada al inventario
        if (x.mensaje !== '07') { const fila = this.lista.find(z => z.id === x.row.id) || r; if (this.puedeInventario(fila)) this.abrirInventario(fila, true); }
      } catch (e) { toast(e.message, 'err'); }
      this.procesando = false;
    },
    async accion(r, a) {
      try { const x = await api(`/api/recepcion/${r.id}/${a}`, { method: 'POST' }); toast(`${x.estado_mensaje}: ${x.mensaje_hacienda || ''}`, ['rechazado', 'error'].includes(x.estado_mensaje) ? 'err' : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminar(r) {
      if (!confirm('¿Eliminar el comprobante de ' + r.emisor_nombre + '? Si vuelve a llegar por correo se registrará de nuevo.')) return;
      try { await api('/api/recepcion/' + r.id, { method: 'DELETE' }); toast('Comprobante eliminado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    registrar(r) { location.hash = '/gastos/compras/nueva?recepcion=' + r.id; },
    // 4.3: compra (costo de lo que se vende) o gasto, y la cuenta contable; el asiento automático se rehace solo
    cuentasCompra() { return planCuentas().filter(c => c.hoja && ['5', '6'].includes(c.raiz)).map(c => c.codigo + ' ' + c.nombre); },
    nombreClas(r) { return r.clasificacion === 'compra' ? 'Compra' : 'Gasto'; },
    async cambiarClasificacion(r, clasificacion) {
      const anterior = r.cuenta_contable;   // la cuenta elegida era de la clasificación anterior: no se hereda
      try { const x = await api('/api/recepcion/' + r.id + '/clasificacion', { method: 'PUT', body: { clasificacion, cuenta_contable: null } }); Object.assign(r, x); await this.cargar(); toast((r.consecutivo || '') + ' queda como ' + (clasificacion === 'compra' ? 'compra (costo de ventas)' : 'gasto') + (anterior ? '; la cuenta ' + anterior + ' se sustituye por la de Parametrización' : '') + '; la contabilidad se ajusta al abrir Contabilidad o los reportes', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- 4.23: un aceptado que se eliminó del registro de compras y gastos («Aceptado sin registrar») se vuelve a registrar aquí.
    // De un mes pasado es una rectificación: el cuadro lo explica y pide el motivo ----
    sinRegistrar, avisoRectificacion, motivoValido,
    // (la nota de crédito cuya factura está fuera del registro no cuenta todavía: registrarla no es una rectificación, como decide el servidor)
    abrirRegistrar(r) { this.reg = { row: r, clasificacion: r.clasificacion === 'compra' ? 'compra' : 'gasto', cuenta_contable: r.cuenta_contable || '', mes: notaSinFactura(r, this.lista) ? null : mesPasado(r.fecha_emision, hoy()), motivo: '' }; },
    async confirmarRegistrar() {
      const x = this.reg; if (!x || this.procesando) return;
      if (x.mes && !motivoValido(x.motivo)) return toast('Indique el motivo (de 5 a 300 letras)', 'err');
      this.procesando = true;
      try {
        const r = await api('/api/recepcion/' + x.row.id + '/registrar', { method: 'POST', body: { clasificacion: x.clasificacion, cuenta_contable: x.cuenta_contable || null, motivo: x.motivo.trim() || null } });
        toast((r.consecutivo || 'El comprobante') + ' queda registrado como ' + (x.clasificacion === 'compra' ? 'compra' : 'gasto') + (r.rectificacion ? ': quedó anotado en Gastos › Rectificaciones' : ''), 'ok');
        this.reg = null; await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.procesando = false;
    },
    // ---- 3.75: inventario desde las líneas del comprobante ----
    puedeInventario(r) { return !!r && sesion.puede('inventario') && !r.inventario_ajuste_id && CON_MERCADERIA.includes(r.tipo_documento) && r.respuesta !== '07'; },
    // 4.32: `auto` = se abre sola después de aceptar; una factura solo de servicios (CABYS 6 a 9) sin ningún ítem relacionado no abre
    // la ventana, porque no hay nada que dar entrada (antes quedaba abierta y el botón solo daba un aviso de error)
    async abrirInventario(r, auto) {
      const inv = { row: r, cargando: false, lineas: [], bodegas: [], bodega_id: null, fecha: hoy(), actualizar_costo: true, guardando: false, metodo: 'promedio' };
      try {
        const [d, bodegas] = await Promise.all([api('/api/recepcion/' + r.id + '/lineas'), api('/api/inventario/bodegas')]);
        inv.bodegas = bodegas.filter(b => b.activa !== false); inv.bodega_id = (inv.bodegas.find(b => b.principal) || inv.bodegas[0])?.id || null;
        inv.metodo = (d.config && d.config.metodo) || 'promedio'; inv.actualizar_costo = !d.config || d.config.actualizar_costo_compras !== false;
        inv.lineas = d.lineas.map(l => ({ ...l, accion: l.producto_id ? 'usar' : 'omitir', producto_id: l.producto_id || null, nuevo: { nombre: (l.detalle || '').slice(0, 200), codigo: l.codigo || '', cabys: l.cabys || '', precio: 0 } }));
        if (!d.lineas.length) toast('El comprobante no trae líneas de detalle', 'err');
        if (auto && d.lineas.length && d.lineas.every(l => !l.producto_id && /^[6-9]/.test(String(l.cabys || '')))) { toast('Factura de servicios: no hay nada que dar entrada al inventario. Quedó aceptada; regístrela como gasto como siempre.', 'ok'); return; }
      } catch (e) { toast(e.message, 'err'); return; }
      this.inv = inv;
    },
    cambioItem(l) { if (l.producto_id) l.accion = 'usar'; },
    algoEntra() { return !!(this.inv && this.inv.lineas.some(l => l.accion !== 'omitir')); },
    async confirmarInventario() {
      const x = this.inv, lineas = x.lineas.filter(l => l.accion !== 'omitir');
      // 4.32: con todo en «No entra» la ventana se cierra sin cambios (antes solo salía un aviso de error y parecía que no dejaba seguir)
      if (!lineas.length) { this.inv = null; return toast('Ninguna línea entra al inventario: la ventana se cerró sin cambios. Lo que es gasto o servicio no se da de entrada.', 'ok'); }
      if (!x.bodega_id) return toast('Elija la bodega', 'err');
      for (const l of lineas) {
        if (l.accion === 'usar' && !l.producto_id) return toast('Línea ' + l.numero + ': elija el ítem del inventario', 'err');
        if (l.accion === 'crear' && !(l.nuevo.nombre || '').trim()) return toast('Línea ' + l.numero + ': indique el nombre del ítem nuevo', 'err');
      }
      x.guardando = true;
      try {
        const r = await api('/api/recepcion/' + x.row.id + '/inventario', { method: 'POST', body: { bodega_id: x.bodega_id, fecha: x.fecha || null, actualizar_costo: !!x.actualizar_costo,
          lineas: lineas.map(l => ({ numero: l.numero, producto_id: l.accion === 'usar' ? l.producto_id : null, crear: l.accion === 'crear' ? { nombre: l.nuevo.nombre, codigo: l.nuevo.codigo || null, cabys: l.nuevo.cabys || null, precio: +l.nuevo.precio || 0 } : null })) } });
        toast(r.ajuste ? `Inventario actualizado: ${r.ajuste.codigo} · ${r.entradas} ítem(s)${r.creados.length ? ' · ' + r.creados.length + ' creado(s)' : ''}` : 'Relaciones guardadas; ninguna línea entró al inventario', 'ok');
        this.inv = null; await Promise.all([this.cargar(), store.cargar()]);
      } catch (e) { toast(e.message, 'err'); }
      if (this.inv) this.inv.guardando = false;
    },
    // 4.2: validar en Hacienda los del sistema anterior (lotes de 50)
    async validarAnteriores(ids) {
      if (this.validando) return;
      this.validando = true;
      try {
        let total = { validados: 0, ok: 0, con_problema: 0, detalle: [] }, j;
        do {
          j = await api('/api/recepcion/validar-anteriores', { method: 'POST', body: ids || null });
          total = { validados: total.validados + j.validados, ok: total.ok + j.ok, con_problema: total.con_problema + j.con_problema, detalle: total.detalle.concat(j.detalle || []) };
        } while (!ids && j.pendientes > 0 && j.validados > 0);
        this.validacion = total; await this.cargar(); this.tab = 'respondidos';
        toast(total.validados + ' comprobante(s) validado(s) en Hacienda: ' + total.ok + ' correcto(s)' + (total.con_problema ? ', ' + total.con_problema + ' para revisar' : ''), total.con_problema ? 'err' : 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.validando = false;
    },
    async subir(ev, historico) {
      const files = [...(ev.target.files || [])]; if (!files.length) return;
      this.subiendo = true;
      try {
        const fd = new FormData(); for (const f of files) fd.append('archivos', f, f.name);
        if (historico) { fd.append('historico', '1'); fd.append('pagados', this.hist && this.hist.pagados ? '1' : '0'); fd.append('clasificacion', (this.hist && this.hist.clasificacion) || 'gasto'); }   // 4.1; 4.3: compra o gasto
        const r = await fetch('/api/recepcion/cargar', { method: 'POST', headers: cabecerasAuth(), body: fd });
        const j = await r.json(); if (!r.ok) throw new Error(j.detail || 'Error al cargar');
        this.resultado = j; toast(`${j.nuevos} comprobante(s) nuevo(s), ${j.duplicados} ya registrado(s)${historico ? ', ' + (j.historicos || 0) + ' marcado(s) como respondidos en el sistema anterior' : ''}${j.descartados.length ? ', ' + j.descartados.length + ' descartado(s)' : ''}`, j.nuevos || j.historicos ? 'ok' : undefined);
        if (j.descartados.length) console.info('Descartados:', j.descartados);
        await this.cargar(); if (historico) { this.hist = null; this.tab = 'respondidos'; } else if (j.nuevos) this.tab = 'pendientes';
      } catch (e) { toast(e.message, 'err'); }
      this.subiendo = false; ev.target.value = '';
    },
    async guardarBuzon() {
      this.guardandoBuzon = true;
      try { const b = await api('/api/recepcion/buzon', { method: 'PUT', body: { ...this.buzon, imap_password: this.buzon.imap_password || null } }); this.buzon = { ...this.buzon, ...b, imap_password: '' }; this.buzonGuardado = !!b.imap_host; toast('Buzón guardado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardandoBuzon = false;
    },
    async leerBuzon() {
      this.leyendo = true;
      try { const j = await api('/api/recepcion/buzon/leer', { method: 'POST' }); this.resultado = j; toast(`${j.correos} correo(s) revisado(s): ${j.nuevos} comprobante(s) nuevo(s), ${j.duplicados} ya registrado(s)`, 'ok'); await this.cargar(); if (j.nuevos) this.tab = 'pendientes'; }
      catch (e) { toast(e.message, 'err'); }
      this.leyendo = false;
    },
    puertoSugerido() { this.buzon.imap_puerto = { ssl: 993, starttls: 143, ninguna: 143 }[this.buzon.imap_seguridad] || 993; },
  },
  created() { this.cargar(); if (this.params.tab && (this.params.tab !== 'buzon' || this.verBuzon)) this.tab = this.params.tab; },
  template: `
  <div class="page">
    <PageHead title="Recepción de comprobantes" sub="Comprobantes que sus proveedores le emiten. Hacienda exige aceptarlos o rechazarlos dentro de los primeros 8 días hábiles del mes siguiente a su emisión.">
      <label class="btn sec" v-if="sesion.puede('gastos')" :class="{disabled: subiendo}">{{subiendo ? 'Cargando…' : '⤒ Cargar XML'}}<input type="file" accept=".xml,.zip" multiple style="display:none" @change="subir($event)"></label>
      <button class="btn ghost" v-if="sesion.puede('gastos')" @click="hist = { pagados: true }" title="Comprobantes de proveedores que ya respondió en su sistema anterior (Alegra u otro)">⤒ Del sistema anterior</button>
      <button class="btn sec" v-if="sesion.puede('gastos') && sesion.electronica && anteriores.length" @click="validarAnteriores()" :disabled="validando" :title="sinValidar ? sinValidar + ' comprobante(s) del sistema anterior sin validar' : 'Todos los del sistema anterior ya se validaron; para repetir la validación use el botón de cada fila'">{{validando ? 'Consultando a Hacienda…' : '✔ Validar en Hacienda' + (sinValidar ? ' (' + sinValidar + ')' : '')}}</button>
      <button class="btn" v-if="sesion.puede('gastos') && !sesion.empresaInfo?.es_local" @click="leerBuzon" :disabled="leyendo || !buzonGuardado" :title="buzonGuardado ? '' : 'Configure el buzón en la pestaña Buzón'">{{leyendo ? 'Leyendo correo…' : '✉ Leer buzón ahora'}}</button>
    </PageHead>
    <div class="alert err" v-if="vencidas">Hay <b>{{vencidas}}</b> comprobante(s) con el plazo de respuesta vencido. Respóndalos hoy: Hacienda los da por aceptados tácitamente y pierde el control del IVA.</div>
    <div class="alert warn" v-else-if="proximas">Hay <b>{{proximas}}</b> comprobante(s) que vencen en los próximos 3 días.</div>

    <div class="seg" style="margin-bottom:12px">
      <button :class="{on: tab==='pendientes'}" @click="tab='pendientes'">Pendientes de respuesta <span class="badge warn" v-if="pendientes.length">{{pendientes.length}}</span></button>
      <button :class="{on: tab==='respondidos'}" @click="tab='respondidos'">Respondidos <span class="badge" v-if="respondidos.length">{{respondidos.length}}</span></button>
      <button v-if="verBuzon" :class="{on: tab==='buzon'}" @click="tab='buzon'">Buzón de correo</button>
    </div>

    <div class="card pad0" v-if="tab!=='buzon'">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar emisor o número" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :empty-title="tab==='pendientes' ? 'No hay comprobantes pendientes de respuesta' : 'Aún no ha respondido comprobantes'" empty-text="Los comprobantes de sus proveedores llegan por el buzón de correo o se cargan como XML.">
        <template #actions="{row}"><template v-if="sesion.puede('gastos')">
          <a class="btn icon" :href="'/api/recepcion/'+row.id+'/pdf'" target="_blank" title="Ver">⎙</a>
          <a class="btn icon" :href="'/api/recepcion/'+row.id+'/xml'" target="_blank" title="XML">{ }</a>
          <button class="btn icon" v-if="puedeInventario(row)" @click.stop="abrirInventario(row)" title="Inventario: relacionar las líneas con los ítems y darles entrada a la bodega">▦</button>
          <span class="small muted" v-else-if="row.inventario_codigo" :title="'Entró al inventario el ' + fecha(row.inventario_en)">▦ {{row.inventario_codigo}}</span>
          <template v-if="!row.respuesta || ['rechazado','error'].includes(row.estado_mensaje||'')">
            <span class="small muted" v-if="row.respuesta && sesion.electronica">Hacienda {{row.estado_mensaje}}: responda de nuevo</span>
            <template v-if="sesion.electronica"><button class="btn sm" @click.stop="abrirRespuesta(row, '05')">✔ Aceptar</button>
            <button class="btn sm sec" @click.stop="abrirRespuesta(row, '06')">Parcial</button>
            <button class="btn sm ghost" @click.stop="abrirRespuesta(row, '07')">✕ Rechazar</button></template>
            <button class="btn sm ghost" v-else-if="!row.compra_id && row.tipo_documento !== '03'" @click.stop="registrar(row)" title="Sin facturación electrónica no se responde a Hacienda; el comprobante se registra como compra">Registrar compra</button>
            <button class="btn icon danger" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
          </template>
          <template v-else>
            <button class="btn sm sec" v-if="['firmado','error'].includes(row.estado_mensaje)" @click.stop="accion(row, 'enviar')">Enviar</button>
            <button class="btn sm sec" v-if="['enviado','aceptado','rechazado'].includes(row.estado_mensaje)" @click.stop="accion(row, 'consultar')">Consultar</button>
            <button class="btn sm sec" v-if="row.estado_mensaje === 'importado' && sesion.electronica" @click.stop="validarAnteriores([row.id])" :disabled="validando" :title="row.validacion ? (row.validacion.texto || '') + (row.validado_en ? ' · ' + fecha(row.validado_en) : '') : 'Consultar en Hacienda si este comprobante y su respuesta están aceptados'">{{row.validacion ? 'Revalidar' : 'Validar'}}</button>
            <a class="btn icon" :href="'/api/recepcion/'+row.id+'/mensaje'" target="_blank" title="Mensaje receptor">✉</a>
            <button class="btn sm" v-if="sinRegistrar(row)" @click.stop="abrirRegistrar(row)" :title="'Se eliminó del registro de compras y gastos' + (row.registro_quitado_en ? ' el ' + fecha(row.registro_quitado_en) : '') + ': no cuenta en los reportes ni en la contabilidad'">Registrar como compra o gasto</button>
            <template v-else>
            <button class="btn sm ghost" v-if="row.respuesta !== '07'" @click.stop="cambiarClasificacion(row, row.clasificacion === 'compra' ? 'gasto' : 'compra')" :title="'Hoy es ' + nombreClas(row).toLowerCase() + (row.cuenta_contable ? ' · ' + row.cuenta_contable : '') + '. Clic para cambiarlo a ' + (row.clasificacion === 'compra' ? 'gasto' : 'compra')">{{nombreClas(row)}} ⇄</button>
            <button class="btn sm ghost" v-if="!row.compra_id && row.respuesta !== '07' && row.tipo_documento !== '03'" @click.stop="registrar(row)">Registrar compra</button>
            <span class="small muted" v-else-if="row.compra_id">Compra registrada</span>
            </template>
          </template>
        </template></template>
      </DataTable>
    </div>

    <div class="card" v-else>
      <h2>Buzón de correo <small>cuenta donde sus proveedores le envían las facturas</small></h2>
      <div class="alert info" style="margin-bottom:10px" v-if="sesion.empresaInfo?.es_local"><b>Requiere internet.</b> La lectura del buzón corre solo en la nube: en este programa no se ejecuta. Configúrelo en la página web.</div>
      <p class="small muted">El sistema entra al buzón por IMAP, toma los XML adjuntos (también dentro de ZIP) dirigidos a esta empresa y los registra como pendientes. Se lee una vez al día automáticamente y cuando pulse "Leer buzón ahora". No borra ni mueve correos.</p>
      <div class="grid">
        <Field label="Servidor IMAP" help="cPanel: mail.sudominio.com · Gmail: imap.gmail.com · Microsoft 365: outlook.office365.com"><input v-model="buzon.imap_host" placeholder="mail.itcoresync.com"></Field>
        <Field label="Seguridad"><select v-model="buzon.imap_seguridad" @change="puertoSugerido"><option value="ssl">SSL (puerto 993)</option><option value="starttls">STARTTLS (puerto 143)</option><option value="ninguna">Sin cifrado (143)</option></select></Field>
        <Field label="Puerto"><input type="number" min="1" max="65535" v-model.number="buzon.imap_puerto"></Field>
        <Field label="Usuario" help="Normalmente el correo completo"><input v-model="buzon.imap_usuario" placeholder="facturas@itcoresync.com"></Field>
        <Field label="Contraseña" :help="buzonGuardado ? 'Ya hay una contraseña guardada; deje en blanco para no cambiarla' : 'Gmail/365: contraseña de aplicación'"><input type="password" v-model="buzon.imap_password" autocomplete="new-password"></Field>
        <Field label="Carpeta"><input v-model="buzon.imap_carpeta" placeholder="INBOX"></Field>
        <Field label="Días hacia atrás" help="Cuántos días de correo se revisan en cada lectura"><input type="number" min="1" max="365" v-model.number="buzon.imap_dias"></Field>
      </div>
      <div class="row end" style="margin-top:12px;gap:8px">
        <span class="small muted" v-if="buzon.imap_ultima">Última lectura: {{fecha(buzon.imap_ultima)}}</span>
        <div class="alert err" v-if="buzon.imap_error" style="margin-top:8px">El buzón falló en el último intento ({{buzon.imap_intento ? fecha(buzon.imap_intento) : ''}}): {{buzon.imap_error}}. Se reintenta a lo sumo una vez por hora; corrija los datos y pulse «Leer ahora».</div>
        <span class="small muted" v-if="!sesion.puede('configurar')">Los datos del buzón los cambia el administrador.</span>
        <button class="btn sec" v-if="sesion.puede('configurar')" @click="guardarBuzon" :disabled="guardandoBuzon">Guardar buzón</button>
        <button class="btn" v-if="sesion.puede('gastos') && !sesion.empresaInfo?.es_local" @click="leerBuzon" :disabled="leyendo || !buzonGuardado">{{leyendo ? 'Leyendo…' : 'Leer buzón ahora'}}</button>
      </div>
      <div class="alert info" style="margin-top:12px" v-if="resultado">Última lectura o carga: {{resultado.correos !== undefined ? resultado.correos + ' correos revisados, ' : ''}}{{resultado.nuevos}} nuevos, {{resultado.duplicados}} ya registrados<span v-if="resultado.descartados && resultado.descartados.length">; descartados: <span v-for="(d,i) in resultado.descartados" :key="i">{{d}}<span v-if="i<resultado.descartados.length-1"> · </span></span></span></div>
    </div>

    <Modal v-if="validacion" title="Validación en Hacienda" lg @close="validacion=null">
      <div class="dash" style="margin-bottom:10px"><div class="kpi w3"><div class="t">Validados</div><div class="v">{{validacion.validados}}</div></div><div class="kpi w3"><div class="t">Correctos</div><div class="v" style="color:var(--ok)">{{validacion.ok}}</div></div><div class="kpi w3"><div class="t">Para revisar</div><div class="v" :style="validacion.con_problema ? 'color:var(--danger)' : ''">{{validacion.con_problema}}</div></div></div>
      <p class="small muted" style="margin:0 0 8px">«Correcto» = Hacienda tiene el comprobante del proveedor como aceptado y, si se subió el mensaje de receptor, también la respuesta. «Para revisar» = no está en Hacienda, fue rechazado, o Hacienda no respondió la consulta.</p>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Proveedor</th><th>Número</th><th>Resultado</th></tr></thead><tbody><tr v-for="d in validacion.detalle" :key="d.id"><td>{{d.emisor || ''}}</td><td class="mono">{{d.consecutivo}}</td><td><span class="badge" :class="d.ok ? 'ok' : 'danger'">{{d.ok ? 'Correcto' : 'Revisar'}}</span> <span class="small">{{d.texto}}</span></td></tr></tbody></table></div>
      <template #foot><button class="btn" @click="validacion=null">Listo</button></template>
    </Modal>
    <Modal v-if="hist" title="Cargar compras del sistema anterior" @close="hist=null">
      <p class="small">Suba los XML (sueltos o en un ZIP) de los comprobantes de proveedores que ya aceptó en su sistema anterior (Alegra u otro). Quedan como <b>aceptados</b> con crédito total del IVA, <b>sin enviar nada a Hacienda</b>. Si incluye también los mensajes de aceptación o rechazo que envió desde ese sistema, cada uno queda como dice su mensaje.</p>
      <label class="row" style="gap:8px;cursor:pointer"><input type="checkbox" v-model="hist.pagados"> Ya están pagados (no quedan como cuentas por pagar)</label>
      <Field label="¿Qué son?" help="Compra = mercadería o materia prima para vender (va al costo de ventas). Gasto = gastos del negocio (alquiler, servicios, suministros…). Se puede cambiar después en cada comprobante."><select v-model="hist.clasificacion"><option value="gasto">Gastos del negocio</option><option value="compra">Compras de mercadería para vender</option></select></Field>
      <p class="small muted">Para que aparezcan en el estado de resultados y el balance, active en Configuración › Contabilidad › Parametrización «Incluir los documentos importados de otro sistema». Los comprobantes que ya respondió desde aquí no se cambian. Después de cargarlos puede usar «✔ Validar en Hacienda» para confirmar que cada uno (y su respuesta) está aceptado allá.</p>
      <template #foot><button class="btn ghost" @click="hist=null">Cancelar</button><label class="btn" :class="{disabled: subiendo}">{{subiendo ? 'Cargando…' : 'Elegir archivos XML o ZIP'}}<input type="file" accept=".xml,.zip" multiple style="display:none" @change="subir($event, true)"></label></template>
    </Modal>
    <Modal v-if="reg" title="Registrar como compra o gasto" @close="reg=null">
      <p class="small muted" style="margin-top:0"><b>{{reg.row.emisor_nombre}}</b> · {{reg.row.tipo_nombre}} {{reg.row.consecutivo}} · {{money(reg.row.total, reg.row.moneda)}} (IVA {{money(reg.row.impuesto, reg.row.moneda)}})</p>
      <p class="small">Este comprobante está aceptado ante Hacienda, pero se eliminó del registro de compras y gastos<span v-if="reg.row.registro_quitado_en"> el {{fecha(reg.row.registro_quitado_en)}}</span><span v-if="reg.row.registro_motivo"> («{{reg.row.registro_motivo}}»)</span>: hoy no cuenta en los reportes ni en la contabilidad. Al registrarlo vuelve a contar; la respuesta dada a Hacienda no cambia.</p>
      <div class="grid cols-2">
        <Field label="¿Qué es?" req help="Compra = mercadería para vender (costo de ventas). Gasto = gasto del negocio"><select v-model="reg.clasificacion"><option value="compra">Compra de mercadería para vender</option><option value="gasto">Gasto del negocio</option></select></Field>
        <Field label="Cuenta contable" help="Vacío = la de Parametrización según la clasificación"><select v-model="reg.cuenta_contable"><option value="">— Según la clasificación —</option><option v-for="q in cuentasCompra()" :key="q" :value="q">{{q}}</option></select></Field>
      </div>
      <template v-if="reg.mes">
        <div class="alert warn">{{avisoRectificacion(reg.mes, 'registrarlo de nuevo')}}</div>
        <Field label="Motivo" req help="De 5 a 300 letras"><textarea rows="2" maxlength="300" v-model="reg.motivo" placeholder="Por qué se vuelve a registrar"></textarea></Field>
      </template>
      <template #foot><button class="btn ghost" @click="reg=null">Cancelar</button><button class="btn" @click="confirmarRegistrar" :disabled="procesando || (!!reg.mes && !motivoValido(reg.motivo))">{{procesando ? 'Guardando…' : 'Registrar'}}</button></template>
    </Modal>
    <Modal v-if="resp" :title="({'05':'Aceptar','06':'Aceptar parcialmente','07':'Rechazar'})[resp.mensaje] + ' comprobante'" @close="resp=null">
      <p class="small muted"><b>{{resp.row.emisor_nombre}}</b> · {{resp.row.tipo_nombre}} {{resp.row.consecutivo}} · {{money(resp.row.total, resp.row.moneda)}} (IVA {{money(resp.row.impuesto, resp.row.moneda)}})</p>
      <div class="grid cols-2" v-if="resp.mensaje!=='07'">
        <Field label="Condición del IVA" req style="grid-column:1/-1"><select v-model="resp.condicion_impuesto" @change="cambioCondicion"><option v-for="(n,k) in CONDICIONES" :key="k" :value="k">{{n}}</option></select></Field>
        <Field label="IVA a acreditar" help="Según la condición elegida"><input type="number" step="0.01" min="0" v-model.number="resp.monto_impuesto_acreditar" :disabled="['01','03','04'].includes(resp.condicion_impuesto)"></Field>
        <Field label="Gasto aplicable" help="Monto del comprobante que se registra como gasto"><input type="number" step="0.01" min="0" v-model.number="resp.monto_gasto_aplicable"></Field>
      </div>
      <div class="grid cols-2" v-if="resp.mensaje!=='07'">
        <Field label="¿Qué es?" req help="Compra = mercadería para vender (costo de ventas). Gasto = gasto del negocio"><select v-model="resp.clasificacion"><option value="compra">Compra de mercadería para vender</option><option value="gasto">Gasto del negocio</option></select></Field>
        <Field label="Cuenta contable" help="Vacío = la de Parametrización según la clasificación"><select v-model="resp.cuenta_contable"><option value="">— Según la clasificación —</option><option v-for="q in cuentasCompra()" :key="q" :value="q">{{q}}</option></select></Field>
      </div>
      <Field :label="resp.mensaje==='07' ? 'Motivo del rechazo' : 'Detalle'" :req="resp.mensaje==='07'"><textarea rows="2" v-model="resp.detalle" maxlength="160"></textarea></Field>
      <p class="small muted">Se genera el Mensaje Receptor, se firma con la llave de la empresa y se envía a Hacienda. Actividad económica: {{store.empresa?.actividad}}.</p>
      <template #foot><button class="btn ghost" @click="resp=null">Cancelar</button><button class="btn" @click="confirmarRespuesta" :disabled="procesando">{{procesando ? 'Enviando…' : 'Confirmar y enviar'}}</button></template>
    </Modal>

    <Modal v-if="inv" :title="'Inventario · ' + (inv.row.consecutivo || inv.row.clave.slice(21, 41))" lg @close="inv=null">
      <p class="small muted" style="margin-top:0"><b>{{inv.row.emisor_nombre}}</b> · {{inv.row.tipo_nombre}} · {{money(inv.row.total, inv.row.moneda)}}<span v-if="inv.row.moneda && inv.row.moneda !== 'CRC'"> · tipo de cambio {{inv.row.tipo_cambio}}</span></p>
      <p class="muted small" v-if="inv.cargando">Leyendo las líneas del comprobante…</p>
      <template v-else>
        <div class="grid cols-3">
          <Field label="Bodega" req><select v-model="inv.bodega_id"><option v-for="b in inv.bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
          <Field label="Fecha de entrada"><input type="date" v-model="inv.fecha"></Field>
          <Field label="Costo de los ítems" help="El costo de referencia del ítem pasa a ser el de esta factura"><label class="row" style="gap:6px;cursor:pointer;margin-top:6px"><input type="checkbox" v-model="inv.actualizar_costo"> Actualizar con esta compra</label></Field>
        </div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>#</th><th>Línea del proveedor</th><th class="num">Cant.</th><th class="num">Costo unit. ₡</th><th style="min-width:280px">Ítem del inventario</th></tr></thead>
          <tbody><tr v-for="l in inv.lineas" :key="l.numero">
            <td class="mono">{{l.numero}}</td>
            <td>{{l.detalle}}<div class="small muted">{{l.codigo ? 'Código ' + l.codigo + ' · ' : ''}}CABYS {{l.cabys || '—'}} · {{l.unidad_medida}}<span v-if="l.descuento"> · descuento {{money(l.descuento, inv.row.moneda)}}</span></div></td>
            <td class="num">{{fmtCant(l.cantidad)}}</td>
            <td class="num">{{money(l.costo_crc)}}</td>
            <td>
              <div class="row" style="gap:6px;flex-wrap:wrap">
                <select class="inp" v-model="l.accion" style="width:130px"><option value="usar">Ítem existente</option><option value="crear">Crear ítem</option><option value="omitir">No entra</option></select>
                <div style="flex:1;min-width:170px" v-if="l.accion==='usar'"><Buscador v-model="l.producto_id" :opciones="items" :etiqueta="p => (p.codigo ? p.codigo + ' · ' : '') + p.nombre" vacio="Elegir ítem" @change="cambioItem(l)"></Buscador></div>
              </div>
              <div class="small muted" v-if="l.accion==='usar' && l.motivo && l.producto_id">{{MOTIVOS[l.motivo] || l.motivo}}</div>
              <div class="grid cols-2" v-if="l.accion==='crear'" style="margin-top:6px;gap:6px"><input class="inp" v-model="l.nuevo.nombre" placeholder="Nombre del ítem nuevo"><input class="inp" v-model="l.nuevo.codigo" placeholder="Código (opcional)"><input class="inp" type="number" min="0" step="0.01" v-model.number="l.nuevo.precio" placeholder="Precio de venta sin IVA"><span class="small muted">CABYS {{l.nuevo.cabys || '—'}} · costo {{money(l.costo_crc)}}</span></div>
            </td>
          </tr></tbody>
        </table></div>
        <p class="small muted" style="margin:10px 0 0">Lo marcado entra a la bodega como compra al costo de la factura (sin IVA, en colones) y abre su capa de costo{{inv.metodo !== 'promedio' ? ' (' + inv.metodo.toUpperCase() + ')' : ''}}. La relación proveedor → ítem se recuerda para la próxima factura. Lo que es gasto o servicio se deja en «No entra».</p>
      </template>
      <template #foot><button class="btn ghost" @click="inv=null">Ahora no</button><button class="btn" @click="confirmarInventario" :disabled="inv.cargando || inv.guardando">{{inv.guardando ? 'Registrando…' : (algoEntra() ? 'Dar entrada al inventario' : 'Cerrar sin dar entrada')}}</button></template>
    </Modal>
  </div>`,
};
