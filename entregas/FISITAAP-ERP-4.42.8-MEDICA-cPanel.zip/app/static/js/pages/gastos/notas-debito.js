// Gastos › Notas de débito a proveedores — lista y formulario inline. Registro 'nd_gastos' por empresa. Una nota rebaja lo que se
// debe al proveedor: se aplica a sus facturas de compra (baja `pagado`), o el proveedor devuelve el dinero (movimiento de entrada
// en Bancos, ref nd_gasto:<id>); si la nota devuelve mercadería, sale del inventario (ajuste de disminución) y vuelve al eliminarla.
// El asiento contable lo genera contabilidad/automaticos.js (origen nd:<id>).
import { api, toast, money, fecha, hoy, mock, monedas } from '../../api.js';
import { store } from '../../app.js';
import { proveedores, compras, totalLineas } from './_datos.js';
import { cuentasActivas, cuentaPrincipal, registrarMovimientoBanco, revertirMovimientoBanco, problemaMoneda, refUnica } from '../bancos/cuentas.js';
import { sesion } from '../../app.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;

export default {
  props: ['params'],
  data() {
    const activas = cuentasActivas();
    return { lista: (mock.get('nd_gastos', []) || []).filter(x => x && x.id), bodegas: [], cuentasOpc: activas.map(b => ({ nombre: b.nombre, moneda: b.moneda || 'CRC' })), monedasOpc: monedas.opciones(), editando: false, f: null, q: '', ver: null, guardando: false };
  },
  computed: {
    provs() { return proveedores(); },
    store() { return store; },
    prov() { return this.f ? this.provs.find(p => p.id == this.f.proveedor_id) || null : null; },
    facturasProv() { return compras().filter(c => c.proveedor_id == this.f?.proveedor_id && c.moneda === this.f?.moneda && c.total - (c.pagado || 0) > 0.005).map(c => ({ ...c, por_pagar: r2(c.total - (c.pagado || 0)) })); },   // solo con saldo (R179)
    totalForm() { return this.f ? totalLineas(this.f.lineas) : 0; },
    aplicado() { return this.f ? (this.f.devolucion ? +this.f.devolucion.monto || 0 : 0) + this.f.facturas.reduce((s, x) => s + (+x.monto || 0), 0) : 0; },
    problemaDevolucion() { return this.f && this.f.devolucion ? problemaMoneda(this.f.devolucion.cuenta, this.f.moneda, this.f.tipo_cambio) : ''; },
    conInventario() { return this.f ? this.f.lineas.some(l => l.producto_id && !(store.productos.find(p => p.id === l.producto_id) || {}).es_servicio) : false; },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.ver = r },
        { key: 'proveedor', label: 'Proveedor' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'aplicado', label: 'Aplicado', num: true, fmt: 'money' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  watch: { 'f.moneda'(v) { if (!this.f) return; this.f.tipo_cambio = monedas.tc(v); this.f.facturas = []; if (this.f.devolucion) { const b = cuentaPrincipal(v); if (b) this.f.devolucion.cuenta = b.nombre; } } },
  methods: {
    money, fecha,
    async cargarBodegas() { try { this.bodegas = await api('/api/inventario/bodegas'); } catch { this.bodegas = []; } },
    siguienteNumero() { const n = (mock.get('nd_gastos', []) || []).reduce((m, x) => Math.max(m, +String(x.numero || '').replace(/\D/g, '') || 0), 0) + 1; return 'ND-' + String(n).padStart(4, '0'); },
    nueva() { const p = cuentaPrincipal(monedas.principal().codigo); this.f = { numero: this.siguienteNumero(), moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), bodega_id: (this.bodegas.find(b => b.principal) || this.bodegas[0] || {}).id || null, proveedor_id: null, fecha: hoy(), lineas: [], devolucion: null, facturas: [], notas: '', cuenta_defecto: p ? p.nombre : '' }; this.editando = true; window.scrollTo(0, 0); },
    agregarDevolucion() { const b = cuentaPrincipal(this.f.moneda); this.f.devolucion = { fecha: hoy(), cuenta: b ? b.nombre : (this.cuentasOpc[0] || {}).nombre || '', monto: null, obs: '' }; },
    agregarFactura() { if (!this.facturasProv.length) return toast('El proveedor no tiene facturas de compra con saldo en esta moneda'); this.f.facturas.push({ compra_id: this.facturasProv[0].id, monto: null }); },
    numFactura(id) { const c = compras().find(x => x.id == id); return c ? c.numero : ''; },
    nombreBodega(id) { return (this.bodegas.find(b => b.id === id) || {}).nombre || ''; },
    // al guardar: productos de inventario (no servicios) con cantidad; después: lo que realmente se descontó (nd.inventario)
    lineasInventario(nd) { if (Array.isArray(nd.inventario)) return nd.inventario; return (nd.lineas || []).filter(l => l.producto_id && +l.cantidad > 0 && !(store.productos.find(p => p.id === l.producto_id) || {}).es_servicio); },
    puedeEliminar(nd) { return !this.lineasInventario(nd).length || sesion.puede('inventario'); },
    async guardar() {
      if (this.guardando || !mock.puedeGuardar()) return;
      if (!this.f.proveedor_id) return toast('Seleccione el proveedor', 'err');
      if (!this.f.fecha) return toast('Indique la fecha', 'err');
      const lineas = this.f.lineas.filter(l => l.detalle || l.precio_unitario);
      if (!lineas.length) return toast('Agregue al menos una línea', 'err');
      const total = r2(this.totalForm), aplicado = r2(this.aplicado);
      if (!(total > 0)) return toast('El total de la nota debe ser mayor que cero', 'err');
      if (aplicado > total + 0.005) return toast('El monto aplicado no puede superar el total de la nota', 'err');
      for (const a of this.f.facturas) { const c = this.facturasProv.find(x => x.id == a.compra_id); if (!c) return toast('Elija la factura a la que se aplica', 'err'); if (+a.monto > c.por_pagar + 0.005) return toast('Lo aplicado a ' + c.numero + ' supera su saldo (' + money(c.por_pagar, c.moneda) + ')', 'err'); }   // (R179)
      if (this.f.devolucion && !(+this.f.devolucion.monto > 0)) return toast('Indique el monto de la devolución de dinero (o quítela)', 'err');
      if (this.f.devolucion && !this.f.devolucion.cuenta) return toast('Elija la cuenta de Bancos donde entra la devolución', 'err');
      if (this.problemaDevolucion) return toast(this.problemaDevolucion, 'err');
      if (this.conInventario && !this.f.bodega_id) return toast('Elija la bodega de la que sale la mercadería devuelta', 'err');
      if (this.conInventario && !sesion.puede('inventario')) return toast('Su rol no puede mover inventario: quite los productos de inventario de la nota o pida permiso de inventario', 'err');
      this.guardando = true;
      try {
        await mock.refrescar(['nd_gastos', 'compras'], { sinCorte: true });        // lo último que guardaron otros usuarios antes de numerar y aplicar
        const id = mock.nextId(mock.get('nd_gastos', []) || [], 'nd_gastos');
        const inv = this.lineasInventario(this.f).map(l => ({ producto_id: l.producto_id, cantidad: +l.cantidad, detalle: l.detalle || '' }));
        const nd = { ...this.f, id, numero: this.f.numero || this.siguienteNumero(), lineas, proveedor: this.prov.nombre, total, aplicado, estado: aplicado >= total - 0.005 ? 'Aplicada' : aplicado > 0 ? 'Aplicada parcialmente' : 'Por aplicar', ref_mov: this.f.devolucion ? refUnica('nd_gasto') : null, ajuste_id: null, inventario: inv };
        delete nd.cuenta_defecto;
        // 1) mercadería devuelta: sale del inventario (si no se puede, no se toca nada más)
        if (inv.length) {
          try { const r = await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: nd.bodega_id, fecha: nd.fecha, observaciones: 'Devolución al proveedor · nota de débito ' + nd.numero, lineas: inv.map(l => ({ producto_id: l.producto_id, tipo: 'disminucion', cantidad: +l.cantidad })) } }); nd.ajuste_id = r && r.id || null; }
          catch (e) { return toast('No se pudo descontar el inventario: ' + e.message, 'err'); }
        }
        const reingresar = async () => { if (!inv.length || !nd.bodega_id) return; try { await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: nd.bodega_id, fecha: nd.fecha, observaciones: 'Reversión: no se pudo guardar la nota de débito ' + nd.numero, lineas: inv.map(l => ({ producto_id: l.producto_id, tipo: 'incremento', cantidad: +l.cantidad })) } }); } catch {} };
        // 2) devolución de dinero: entra a Bancos (el servidor convierte a la moneda de la cuenta); si falla, se reingresa el inventario
        if (nd.devolucion) { const ok = await registrarMovimientoBanco(nd.devolucion.cuenta, +nd.devolucion.monto, nd.devolucion.fecha || nd.fecha, 'Devolución del proveedor · nota de débito ' + nd.numero + ' · ' + nd.proveedor, nd.ref_mov, false, nd.moneda, nd.tipo_cambio); if (!ok) { await reingresar(); return; } }
        // 3) la nota, sobre lo guardado más reciente; si el guardado falla se deshace el banco y el inventario
        const lista = [...(mock.get('nd_gastos', []) || []).filter(x => x && x.id), nd];
        const guardada = await mock.set('nd_gastos', lista);
        if (!guardada) { if (nd.ref_mov) await revertirMovimientoBanco([nd.ref_mov]); await reingresar(); return toast('No se pudo guardar la nota de débito; no quedó nada registrado', 'err'); }
        this.lista = (mock.get('nd_gastos', []) || []).filter(x => x && x.id);
        // 4) lo aplicado a las facturas
        if (nd.facturas.length) mock.actualizar('compras', todas => { for (const a of nd.facturas) { const c = (todas || []).find(x => x.id == a.compra_id); if (c) c.pagado = r2((c.pagado || 0) + (+a.monto || 0)); } return todas; }, []);
        this.editando = false; toast('Nota de débito ' + nd.numero + ' guardada' + (nd.devolucion ? ' · devolución registrada en Bancos' : '') + (inv.length ? ' · inventario descontado' : ''), 'ok');
      } finally { this.guardando = false; }
    },
    // al eliminar: lo aplicado a facturas vuelve a quedar por pagar, el dinero devuelto sale de Bancos y la mercadería vuelve a la bodega (R179)
    // Orden: primero vuelve la mercadería a la bodega (si no se puede, no se toca nada), luego sale la devolución de Bancos y por último las facturas
    async revertir(nds) {
      if (nds.some(nd => this.lineasInventario(nd).length) && !sesion.puede('inventario')) { toast('Su rol no puede mover inventario: la nota con mercadería devuelta la elimina quien tenga permiso de inventario', 'err'); return false; }
      for (const nd of nds) { const inv = this.lineasInventario(nd); if (inv.length && nd.bodega_id) { try { await api('/api/inventario/ajustes', { method: 'POST', body: { bodega_id: nd.bodega_id, fecha: hoy(), observaciones: 'Anulación de la nota de débito ' + nd.numero + ' (mercadería devuelta regresa)', lineas: inv.map(l => ({ producto_id: l.producto_id, tipo: 'incremento', cantidad: +l.cantidad })) } }); } catch (e) { toast('No se pudo reingresar el inventario de ' + nd.numero + ': ' + e.message + '. La nota no se eliminó.', 'err'); return false; } } }
      const refs = nds.map(nd => nd.ref_mov).filter(Boolean);
      if (refs.length && !(await revertirMovimientoBanco(refs))) { toast('El inventario ya se reingresó pero la devolución sigue en Bancos: quite el movimiento a mano en Bancos y vuelva a intentar', 'err'); return false; }
      mock.actualizar('compras', todas => { for (const nd of nds) for (const a of nd.facturas || []) { const c = (todas || []).find(x => x.id == a.compra_id); if (c) c.pagado = Math.max(0, r2((c.pagado || 0) - (+a.monto || 0))); } return todas; }, []);
      return true;
    },
    async eliminar(r) { if (!this.puedeEliminar(r)) return toast('Su rol no puede mover inventario: esta nota la elimina quien tenga permiso de inventario', 'err'); if (!confirm('¿Eliminar la nota de débito ' + r.numero + '? Lo aplicado a facturas vuelve a quedar por pagar' + (r.devolucion ? ', la devolución se quita de Bancos' : '') + (this.lineasInventario(r).length ? ' y la mercadería vuelve a la bodega' : '') + '.')) return; if (!(await this.revertir([r]))) return; this.lista = mock.actualizar('nd_gastos', l => (l || []).filter(x => x.id !== r.id), []); this.ver = null; toast('Nota de débito eliminada', 'ok'); },
    async eliminarVarios(rows) { rows = rows.filter(r => this.puedeEliminar(r)); if (!rows.length) return toast('Ninguna de las notas seleccionadas se puede eliminar con su rol', 'err'); if (!(await this.revertir(rows))) return; const ids = rows.map(r => r.id); this.lista = mock.actualizar('nd_gastos', l => (l || []).filter(x => !ids.includes(x.id)), []); toast(ids.length + ' notas de débito eliminadas', 'ok'); },
  },
  created() { this.cargarBodegas(); },
  template: `
  <div class="page">
    <PageHead title="Notas de débito" sub="Notas de débito a proveedores: devoluciones de mercadería, descuentos posteriores o ajustes que reducen lo que les debe. Se aplican a sus facturas, registran la devolución del dinero en Bancos, descuentan el inventario y generan su asiento.">
      <button class="btn" v-if="!editando" @click="nueva">+ Nueva nota de débito</button>
    </PageHead>
    <template v-if="editando">
      <div class="card">
        <div class="grid cols-3">
          <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
          <Field label="Bodega" :req="conInventario" help="De la que sale la mercadería devuelta"><Buscador v-model="f.bodega_id" :opciones="bodegas" placeholder="Sin bodega" agregar="bodega"></Buscador></Field>
          <Field label="No."><input v-model="f.numero" class="mono"></Field>
          <Field label="Proveedor" req><Buscador v-model="f.proveedor_id" :opciones="provs" detalle="numero_id" vacio="Seleccionar" agregar="proveedor"></Buscador></Field>
          <Field label="Identificación"><input :value="prov ? prov.numero_id : ''" readonly></Field>
          <Field label="Teléfono"><input :value="prov ? prov.telefono : ''" readonly></Field>
          <Field label="Fecha" req><input type="date" v-model="f.fecha"></Field>
          <Field label="Tipo de cambio" v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda"><input type="number" step="0.01" v-model.number="f.tipo_cambio"></Field>
        </div>
      </div>
      <div class="card"><h2>Ítems <small>los productos de inventario se descuentan de la bodega; los servicios y conceptos, no</small></h2><LineEditor v-model="f.lineas" :productos="store.productos" :moneda="f.moneda" compra></LineEditor></div>
      <div class="card"><h2>Aplicación</h2>
        <div class="row" style="gap:14px;margin-bottom:12px">
          <button class="btn sec sm" :disabled="!!f.devolucion" @click="agregarDevolucion">+ Agregar devolución de dinero</button>
          <button class="btn sec sm" :disabled="!f.proveedor_id" @click="agregarFactura">+ Agregar factura de proveedor</button>
        </div>
        <div v-if="f.devolucion" class="grid cols-3" style="margin-bottom:12px">
          <Field label="Fecha"><input type="date" v-model="f.devolucion.fecha"></Field>
          <Field label="Cuenta de Bancos" req><select v-model="f.devolucion.cuenta"><option v-for="c in cuentasOpc" :key="c.nombre" :value="c.nombre">{{c.nombre}} · {{c.moneda}}</option></select><div class="small neg" v-if="problemaDevolucion" style="margin-top:4px">{{problemaDevolucion}}</div></Field>
          <Field label="Monto" req><input type="number" step="0.01" min="0" v-model.number="f.devolucion.monto"></Field>
          <Field label="Observaciones" style="grid-column:span 2"><input v-model="f.devolucion.obs"></Field>
          <div style="align-self:end"><button class="btn ghost sm" @click="f.devolucion=null">Quitar devolución</button></div>
        </div>
        <div class="table-wrap" v-if="f.facturas.length"><table class="tbl">
          <thead><tr><th>Factura de proveedor</th><th class="num">Saldo</th><th class="num" style="width:160px">Monto a aplicar</th><th></th></tr></thead>
          <tbody><tr v-for="(a,i) in f.facturas" :key="i">
            <td><select class="inp" v-model="a.compra_id"><option v-for="c in facturasProv" :key="c.id" :value="c.id">{{c.numero}} · {{fecha(c.creacion)}}</option></select></td>
            <td class="num">{{money((facturasProv.find(c=>c.id==a.compra_id)||{por_pagar:0}).por_pagar, f.moneda)}}</td>
            <td><input class="inp" type="number" step="0.01" min="0" v-model.number="a.monto" style="width:100%;text-align:right"></td>
            <td><button class="btn icon" title="Quitar" @click="f.facturas.splice(i,1)">✕</button></td>
          </tr></tbody>
        </table></div>
        <div class="totals"><div><span>Total de la nota</span><b>{{money(totalForm, f.moneda)}}</b></div><div><span>Aplicado</span><b>{{money(aplicado, f.moneda)}}</b></div><div class="total"><span>Por aplicar</span><b>{{money(totalForm-aplicado, f.moneda)}}</b></div></div>
      </div>
      <div class="card"><Field label="Notas"><textarea rows="2" v-model="f.notas"></textarea></Field></div>
      <div class="row end" style="margin-bottom:18px"><button class="btn ghost" @click="editando=false">Cancelar</button><button class="btn" :disabled="guardando" @click="guardar">{{guardando ? 'Guardando…' : 'Guardar'}}</button></div>
    </template>
    <template v-else>
      <div class="card pad0" v-if="lista.length">
        <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar proveedor o número" v-model="q"></div>
        <DataTable :rows="lista" :columns="columns" :search="q" :selectable="puede('gastos')" :on-bulk-delete="eliminarVarios">
          <template #actions="{row}"><button class="btn icon" title="Ver" @click.stop="ver=row">👁</button><button class="btn icon" v-if="puede('gastos') && (puedeEliminar(row))" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
        </DataTable>
      </div>
      <div class="card" v-else><Empty icon="📝" title="Aún no has creado notas de débito" text="Las notas de débito a proveedores registran devoluciones de mercadería, descuentos posteriores o ajustes que disminuyen el saldo pendiente de pago con el proveedor. Puede aplicarlas a facturas de compra o registrar la devolución del dinero."><button class="btn" v-if="puede('gastos')" @click="nueva">+ Nueva nota de débito</button></Empty></div>
    </template>
    <Modal v-if="ver" :title="'Nota de débito ' + ver.numero" lg @close="ver=null">
      <div class="grid cols-3" style="margin-bottom:12px">
        <div><div class="small muted">Proveedor</div><b>{{ver.proveedor}}</b></div><div><div class="small muted">Fecha</div><b>{{fecha(ver.fecha)}}</b></div><div><div class="small muted">Estado</div><Badge :value="ver.estado"></Badge></div>
        <div><div class="small muted">Total</div><b>{{money(ver.total, ver.moneda)}}</b></div><div><div class="small muted">Aplicado</div><b>{{money(ver.aplicado, ver.moneda)}}</b></div>
        <div v-if="ver.devolucion"><div class="small muted">Devolución de dinero</div><b>{{money(ver.devolucion.monto||0, ver.moneda)}}</b> · {{ver.devolucion.cuenta}}</div>
        <div v-if="ver.bodega_id && lineasInventario(ver).length"><div class="small muted">Inventario</div><b>Descontado de {{nombreBodega(ver.bodega_id) || 'la bodega'}}</b></div>
      </div>
      <table class="tbl"><thead><tr><th>Detalle</th><th class="num">Cant.</th><th class="num">Precio</th></tr></thead><tbody><tr v-for="(l,i) in ver.lineas" :key="i"><td>{{l.detalle}}</td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio_unitario, ver.moneda)}}</td></tr></tbody></table>
      <p class="small muted" v-if="ver.facturas.length" style="margin-top:10px">Aplicada a: <span v-for="(a,i) in ver.facturas" :key="i" class="mono">{{numFactura(a.compra_id)}} ({{money(a.monto||0, ver.moneda)}}) </span></p>
      <p class="small muted" v-if="ver.notas">{{ver.notas}}</p>
      <template #foot><button class="btn ghost" @click="ver=null">Cerrar</button><button class="btn danger" v-if="puedeEliminar(ver)" @click="eliminar(ver)">Eliminar</button></template>
    </Modal>
  </div>`,
};
