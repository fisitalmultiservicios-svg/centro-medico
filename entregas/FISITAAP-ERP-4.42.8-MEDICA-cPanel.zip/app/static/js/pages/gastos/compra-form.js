// Gastos › Nueva compra o nuevo gasto — formulario de la factura (registro 'compras'). 4.23: la factura es una compra o un gasto según
// «¿Qué es?»; ?tipo=gasto lo trae elegido (botón «+ Nuevo gasto») y al guardar se vuelve a la lista de su tipo.
import { api, toast, money, fecha, hoy, mock, monedas, demo, CAT, opts } from '../../api.js';
import { store, sesion } from '../../app.js';
import { proveedores, compras, ordenes, totalLineas, BODEGAS, dias } from './_datos.js';

// 3.87: líneas de una compra que mueven inventario (ítem inventariable con cantidad) y su costo neto en colones. Lo usan el
// formulario y la lista de compras («Dar entrada al inventario» de una compra que guardó un rol sin permiso de inventario).
export function lineasInventario(doc, lineas) {
  const prods = store.productos || [], tc = doc.moneda === 'CRC' ? 1 : (+doc.tipo_cambio || 1);
  return (lineas || []).filter(l => l.producto_id && +l.cantidad > 0).filter(l => { const p = prods.find(x => x.id == l.producto_id); return p && p.inventariable !== false && !p.es_servicio; })
    .map(l => ({ producto_id: l.producto_id, cantidad: +l.cantidad, costo_unitario: Math.round(Math.max(0, ((+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0)) / (+l.cantidad || 1)) * tc * 10000) / 10000 }));   // el descuento de la línea es un monto
}
export function entradaCompra(doc, inv, bodegaId, recepcionId, clave) {   // clave: la misma no entra dos veces (el servidor responde 409)
  return api('/api/inventario/compras', { method: 'POST', body: { bodega_id: bodegaId, fecha: doc.creacion, numero: doc.numero, proveedor: doc.proveedor || null, recepcion_id: recepcionId || null, lineas: inv, ...(clave ? { clave } : {}) } });
}

export default {
  props: ['params'],
  data() {
    return {
      opciones: false, modalOrdenes: false, guardando: false, CAT, opts,   /* el template usa CAT.condicionVentaDe y opts(CAT.medioPago): sin exponerlos la pantalla fallaba */
      monedasOpc: monedas.opciones(), BODEGAS,
      recepcionId: null, recepcionClave: null, recepcionInventario: null, bodegasApi: [], bodegaId: null,   // recepcionInventario: CO-#### si ya entró al aceptar (3.75)
      f: { tipo: 'compra', numero: '', fec: false, proveedor_db_id: null, ref_tipo: '14', proveedor_id: null, creacion: hoy(), vencimiento: dias(30), condicion_venta: '02', medio_pago: '04', moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), bodega: 'Principal', lineas: [], retenciones: [], ordenes_ids: [], terminos: '', notas: '' },
      pref: { mostrarBodega: true, mostrarRetenciones: true, mostrarTerminos: true },
    };
  },
  computed: {
    store() { return store; },
    provs() { return proveedores(); },
    provsFec() { return (store.clientes || []).filter(c => c.activo !== false && (c.tipo === 'Proveedor' || c.tipo === 'Ambos')); },
    prov() { return this.provs.find(p => p.id == this.f.proveedor_id) || null; },
    lista() { return this.f.tipo === 'gasto' ? '/gastos/gastos' : '/gastos/compras'; },   // 4.23: la lista del tipo de esta factura
    ordenesProv() { return ordenes().filter(o => o.proveedor_id == this.f.proveedor_id && o.estado === 'Abierta'); },
    subtotal() { return totalLineas(this.f.lineas); },
    totalRet() { return this.f.retenciones.reduce((s, r) => s + this.subtotal * (+r.pct || 0) / 100, 0); },
    total() { return this.subtotal - this.totalRet; },
  },
  watch: {
    // En producción el proveedor de la compra ES el contacto real: la FEC se emite por cuenta de ese mismo contacto
    'f.proveedor_id'(v) { if (!demo.activo && this.provsFec.some(c => c.id === v)) this.f.proveedor_db_id = v; },
    'f.moneda'(v) { this.f.tipo_cambio = monedas.tc(v); },
  },
  methods: {
    async tcDelDia() {   // 4.18: una compra con fecha pasada toma la venta del BCCR de ese día (se puede cambiar a mano)
      if (this.f.moneda !== 'USD' || !this.f.creacion || this.f.creacion >= hoy()) return;
      try { const r = await api('/api/tipo-cambio/dia?fecha=' + this.f.creacion); if (r && r.venta) this.f.tipo_cambio = r.venta; } catch { /* queda el del día */ }
    },
    money, fecha,
    agregarRetencion() { this.f.retenciones.push({ nombre: 'Retención IVA 2 %', pct: 2 }); },
    quitarRetencion(i) { this.f.retenciones.splice(i, 1); },
    importarOrden(o) {
      if (this.f.ordenes_ids.includes(o.id)) { this.modalOrdenes = false; return toast('La orden ' + o.codigo + ' ya está incluida en esta factura', 'err'); }   // no duplica líneas (R276)
      if (this.f.lineas.some(l => l.detalle || l.precio_unitario) && o.moneda !== this.f.moneda) return toast('La orden ' + o.codigo + ' está en ' + o.moneda + ' y esta factura en ' + this.f.moneda + ': no se pueden mezclar monedas', 'err');
      for (const l of o.lineas) this.f.lineas.push({ ...l });
      this.f.ordenes_ids.push(o.id);
      this.f.moneda = o.moneda;
      this.modalOrdenes = false;
      toast('Se importaron ' + o.lineas.length + ' líneas de la orden ' + o.codigo, 'ok');
    },
    // Compra manual (sin FEC): la mercadería entra al inventario por la bodega elegida como compra (CO-####, 3.75), al costo neto
    // de la línea en colones (R277). Si el comprobante recibido ya entró al aceptarlo, no entra dos veces.
    async entradaInventario(doc, lineas) {
      const inv = lineasInventario(doc, lineas);
      if (!inv.length || !this.bodegaId) return;
      if (this.recepcionInventario) return toast('El inventario ya había entrado con ' + this.recepcionInventario + ' al aceptar el comprobante; no se repite', 'ok');
      if (doc.inventario_pendiente) return;   // 3.87: sin permiso de inventario no se pide (el servidor lo rechaza): la entrada queda pendiente en la compra
      try {
        const r = await entradaCompra(doc, inv, this.bodegaId, this.recepcionId);
        toast('Inventario: entrada ' + r.codigo + ' registrada por la compra', 'ok');
        store.cargar();   // el costo de los ítems pudo cambiar
      } catch (e) { toast('La compra se guardó, pero no se pudo registrar la entrada en inventario: ' + e.message, 'err'); }
    },
    // Un solo guardado a la vez: con la FEC marcada tarda varios segundos y un segundo clic emitía otra FEC a Hacienda,
    // registraba otra compra y daba entrada al inventario dos veces.
    async guardar(modo) {
      if (this.guardando) return;
      this.guardando = true;
      try { await this.guardarAhora(modo); } finally { this.guardando = false; }
    },
    async guardarAhora(modo) {
      if (!mock.puedeGuardar()) return;               // antes de emitir la factura de compra: si no, la compra quedaba sin guardar
      if (!this.f.proveedor_id || !this.prov) return toast('Seleccione el proveedor (el de la orden ya no está activo en Contactos)', 'err');
      if (!this.f.creacion || !this.f.vencimiento) return toast('Indique las fechas de creación y vencimiento', 'err');
      const lineas = this.f.lineas.filter(l => l.detalle || l.precio_unitario);
      if (!lineas.length) return toast('Agregue al menos una línea', 'err');
      // 3.87: un rol sin permiso de inventario (el Contador) registra la compra, pero la mercadería no puede entrar a la bodega: se avisa
      // antes de guardar y la compra queda marcada «entrada pendiente» para que quien tenga ese permiso la registre desde la lista de Compras o de Gastos
      const invPendiente = !this.f.fec && !this.recepcionInventario && !!this.bodegaId && !sesion.puede('inventario') && lineasInventario(this.f, lineas).length > 0;
      if (invPendiente && !confirm('Su rol no puede mover inventario: la compra se guardará, pero la mercadería no entrará a la bodega todavía. La entrada queda pendiente y la registra quien tenga permiso de inventario desde Gastos › Compras o Gastos › Gastos. ¿Guardar la compra?')) return;
      let fecDoc = null;
      if (this.f.fec) {
        // Factura electrónica de compra: la emite la empresa por cuenta del proveedor (contacto real de tipo Proveedor), se firma y se envía a Hacienda
        if (!this.f.proveedor_db_id) return toast('Para la FEC elija el proveedor registrado en Contactos (tipo Proveedor)', 'err');
        if (lineas.some(l => !l.cabys)) return toast('Cada línea de la FEC necesita código CABYS', 'err');
        try {
          const plazo = Math.max(1, Math.round((new Date(this.f.vencimiento + 'T00:00:00') - new Date(this.f.creacion + 'T00:00:00')) / 86400000));
          const body = { tipo_documento: '08', cliente_id: this.f.proveedor_db_id, bodega_id: this.bodegaId || null, condicion_venta: this.f.condicion_venta || '01', plazo_credito: ['02', '08', '10'].includes(this.f.condicion_venta) ? plazo : null, medio_pago: this.f.medio_pago || '04', moneda: this.f.moneda, tipo_cambio: this.f.tipo_cambio || 1,
                         lineas: lineas.map(l => ({ producto_id: l.producto_id || null, detalle: l.detalle, cabys: l.cabys, cantidad: +l.cantidad || 1, precio_unitario: +l.precio_unitario || 0, descuento: +l.descuento || 0, codigo_tarifa: l.codigo_tarifa || '08', tarifa: l.tarifa ?? 13, es_servicio: !!l.es_servicio, unidad_medida: l.unidad_medida || 'Unid' })),
                         referencia_tipo_doc: this.f.ref_tipo, referencia_numero: this.f.numero || 'S/N', referencia_fecha: this.f.creacion + 'T00:00:00-06:00', referencia_codigo: '04',
                         referencia_razon: 'Factura de compra: documento del proveedor ' + (this.f.numero || 'sin número'), observaciones: this.f.notas || null, fecha_vencimiento: this.f.vencimiento };
          fecDoc = await api('/api/comprobantes', { method: 'POST', body });
          try { const r = await api('/api/comprobantes/' + fecDoc.id + '/enviar', { method: 'POST' }); fecDoc.estado = r.estado; } catch (e) { toast('FEC firmada, pero no se pudo enviar ahora: ' + e.message, 'err'); }
        } catch (e) { return toast(e.message, 'err'); }
      }
      const lista = compras();
      const id = mock.nextId(lista, 'compras');
      const doc = { tipo: this.f.tipo === 'gasto' ? 'gasto' : 'compra', recepcion_id: this.recepcionId || null, clave: this.recepcionClave || null, id, numero: this.f.numero || ('FC-' + String(id).padStart(4, '0')), proveedor_id: this.prov.id, proveedor: this.prov.nombre, creacion: this.f.creacion, vencimiento: this.f.vencimiento,
        moneda: this.f.moneda, tipo_cambio: this.f.tipo_cambio, bodega: ((this.bodegasApi || []).find(b => b.id === this.bodegaId) || {}).nombre || this.f.bodega, lineas, retenciones: this.f.retenciones, total: Math.round(this.total * 100) / 100, pagado: 0,
        emision: fecDoc ? 'FEC ' + fecDoc.estado : 'No electrónica', fec_id: fecDoc ? fecDoc.id : null, fec_consecutivo: fecDoc ? fecDoc.consecutivo : null, terminos: this.f.terminos, notas: this.f.notas, ordenes_ids: this.f.ordenes_ids,
        ...(invPendiente ? { inventario_pendiente: true, bodega_id: this.bodegaId } : {}) };
      lista.push(doc); mock.set('compras', lista);
      if (!fecDoc) await this.entradaInventario(doc, lineas);
      if (this.recepcionId) { try { await api('/api/recepcion/' + this.recepcionId + '/compra', { method: 'PUT', body: { compra_id: id } }); } catch {} }   // la recepción queda vinculada (R140)
      if (this.f.ordenes_ids.length) { const ords = ordenes().map(o => this.f.ordenes_ids.includes(o.id) ? { ...o, estado: 'Recibida' } : o); mock.set('ordenes', ords); }
      toast('Factura de compra ' + doc.numero + ' guardada' + (fecDoc ? ' · FEC ' + fecDoc.consecutivo + ' ' + fecDoc.estado : '') + (invPendiente ? ' · entrada al inventario pendiente' : ''), fecDoc && fecDoc.estado === 'rechazado' ? 'err' : 'ok');
      if (modo === 'pago') location.hash = '/gastos/pagos/nuevo?compra=' + id;
      else if (modo === 'nueva') { this.f = { ...this.f, numero: '', lineas: [], retenciones: [], ordenes_ids: [], notas: '' }; this.recepcionId = null; this.recepcionClave = null; window.scrollTo(0, 0); }
      else location.hash = doc.tipo === 'gasto' ? '/gastos/gastos' : '/gastos/compras';   // 4.23: a la lista de su tipo
    },
  },
  async created() {
    try { this.bodegasApi = await api('/api/inventario/bodegas'); this.bodegaId = (this.bodegasApi.find(b => b.principal) || this.bodegasApi[0])?.id || null; } catch {}   // bodega real (R110, R178)
    if (this.params.tipo === 'gasto') this.f.tipo = 'gasto';   // 4.23: «+ Nuevo gasto»
    if (this.params.orden) { const o = ordenes().find(x => x.id == this.params.orden); if (o) { this.f.proveedor_id = this.provs.some(p => p.id == o.proveedor_id) ? o.proveedor_id : null; if (!this.f.proveedor_id) toast('El proveedor de la orden (' + (o.proveedor || '') + ') ya no está activo en Contactos: elija uno', 'err'); this.importarOrden(o); } }
    if (this.params.recepcion) {
      let r = null;
      try { r = (await api('/api/recepcion')).find(x => x.id == this.params.recepcion); } catch (e) { toast(e.message, 'err'); }
      if (r) { r = { ...r, emisor: r.emisor_nombre, fecha: (r.fecha_emision || '').slice(0, 10), tipo: r.tipo_nombre, detalle: '' };
        const p = this.provs.find(x => x.nombre === r.emisor) || this.provs.find(x => x.numero_id === r.emisor_id);
        this.f.proveedor_id = p ? p.id : null; this.f.numero = r.clave.slice(21, 41); this.f.creacion = r.fecha; this.f.moneda = r.moneda; if (r.clasificacion) this.f.tipo = r.clasificacion; this.recepcionId = r.id; this.recepcionClave = r.clave; this.recepcionInventario = r.inventario_codigo || null;
        if (r.moneda && r.moneda !== 'CRC' && +r.tipo_cambio) this.f.tipo_cambio = +r.tipo_cambio;
        this.f.lineas = [];   // el editor ya había puesto una línea vacía mientras llegaba el comprobante
        // 3.75: las líneas reales del XML, cada una con el ítem propuesto (relación guardada, código o nombre); si el XML no se puede leer, una línea resumen
        let xmlLineas = null;
        try { xmlLineas = (await api('/api/recepcion/' + r.id + '/lineas')).lineas; } catch {}
        if (xmlLineas && xmlLineas.length) {
          for (const l of xmlLineas) this.f.lineas.push({ producto_id: l.producto_id || null, detalle: l.detalle, cabys: l.cabys || '', cantidad: +l.cantidad || 1, precio_unitario: +l.precio_unitario || 0, descuento: +l.descuento || 0, codigo_tarifa: l.codigo_tarifa || (l.tarifa === 0 ? '01' : '08'), tarifa: l.tarifa ?? 13, unidad_medida: l.unidad_medida || 'Unid', es_servicio: /^[5-9]/.test(String(l.cabys || '')) });
          if (this.recepcionInventario) toast('Este comprobante ya entró al inventario con ' + this.recepcionInventario + ': la compra se registra sin repetir la entrada');
        } else {
        const baseR = Math.round(((+r.total || 0) - (+r.impuesto || 0)) * 100) / 100, tarR = baseR > 0 ? Math.round((+r.impuesto || 0) / baseR * 100 * 100) / 100 : 0;   // base e IVA reales del comprobante (R140)
        const MAPA = { 13: '08', 4: '04', 2: '03', 1: '02', 0.5: '09', 8: '07', 0: '01' };
        if (MAPA[tarR] !== undefined) {
        this.f.lineas.push({ producto_id: null, detalle: r.detalle || ('Comprobante ' + r.tipo + ' de ' + r.emisor), cabys: '', cantidad: 1, precio_unitario: baseR, descuento: 0, codigo_tarifa: ({ 13: '08', 4: '04', 2: '03', 1: '02', 0.5: '09', 8: '07', 0: '01' }[tarR] || '08'), tarifa: tarR });
        } else {   // tarifas mixtas en el comprobante: una línea gravada al 13 % por el IVA informado y otra exenta por el resto
          const grav = Math.round((+r.impuesto || 0) / 0.13 * 100) / 100, exen = Math.round((baseR - grav) * 100) / 100, det = r.detalle || ('Comprobante ' + r.tipo + ' de ' + r.emisor);
          if (grav > 0) this.f.lineas.push({ producto_id: null, detalle: det + ' (gravado)', cabys: '', cantidad: 1, precio_unitario: grav, descuento: 0, codigo_tarifa: '08', tarifa: 13 });
          if (exen > 0) this.f.lineas.push({ producto_id: null, detalle: det + ' (exento)', cabys: '', cantidad: 1, precio_unitario: exen, descuento: 0, codigo_tarifa: '01', tarifa: 0 });
          toast('El comprobante tiene varias tarifas de IVA: revise las líneas antes de guardar', 'err');
        }
        }
        if (!p) toast('El emisor ' + r.emisor + ' no existe como proveedor; créelo con "+ Nuevo proveedor"');
      }
    }
  },
  template: `
  <div class="page">
    <PageHead :title="f.tipo === 'gasto' ? 'Nuevo gasto' : 'Nueva compra'" :crumbs="[{label: f.tipo === 'gasto' ? 'Gastos' : 'Compras', to: lista},{label:'Nueva factura'}]">
      <button class="btn ghost" @click="opciones=true">Personalizar opciones</button>
    </PageHead>
    <div class="card">
      <div class="grid cols-3">
        <Field label="Moneda"><select v-model="f.moneda" @change="tcDelDia"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda + ' (el del sistema; cámbielo si aplica otro)'"><input type="number" step="0.01" v-model.number="f.tipo_cambio"></Field>
        <Field label="Bodega" v-if="pref.mostrarBodega"><Buscador v-model="bodegaId" :opciones="bodegasApi" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        <Field label="No." help="Número de factura del proveedor"><input v-model="f.numero" placeholder="Ej. 00100001010000001234"></Field>
      </div>
      <label class="row" style="margin:10px 0;cursor:pointer"><input type="checkbox" v-model="f.fec"> Emitir factura electrónica de compra</label>
      <div class="grid" v-if="f.fec" style="margin-top:8px"><Field label="Proveedor registrado (Contactos › Proveedor o Ambos)" req help="La FEC la emite y firma su empresa (con su propia llave) por cuenta de este proveedor, que no factura electrónicamente"><Buscador v-model="f.proveedor_db_id" :opciones="provsFec" detalle="numero_id" agregar="proveedor"></Buscador></Field><Field label="Documento del proveedor" help="Tipo de documento que respalda la compra (referencia obligatoria)"><select v-model="f.ref_tipo"><option value="14">14 · Comprobante aportado por contribuyente de régimen especial</option><option value="05">05 · Nota de despacho</option><option value="06">06 · Contrato</option><option value="07">07 · Procedimiento</option></select></Field></div>
      <div class="alert info" v-if="f.fec">La factura electrónica de compra (FEC, tipo 08) se usa cuando el proveedor no es emisor electrónico (régimen simplificado, personas físicas sin facturación). Al guardar, la empresa la emitirá con su propio certificado y la enviará a Hacienda.</div>
      <h2 style="margin-top:12px">Proveedor</h2>
      <div class="grid cols-3">
        <Field label="Proveedor" req><Buscador v-model="f.proveedor_id" :opciones="provs" detalle="numero_id" vacio="Seleccionar" agregar="proveedor"></Buscador></Field>
        <Field label="Identificación"><input :value="prov ? prov.numero_id : ''" readonly></Field>
        <Field label="Teléfono"><input :value="prov ? prov.telefono : ''" readonly></Field>
        <Field label="Creación" req><input type="date" v-model="f.creacion" @change="tcDelDia"></Field>
        <Field label="Vencimiento" req><input type="date" v-model="f.vencimiento"></Field>
        <Field label="¿Qué es?" help="Compra = mercadería o materia prima para vender (costo de ventas). Gasto = gasto del negocio"><select v-model="f.tipo"><option value="compra">Compra de mercadería para vender</option><option value="gasto">Gasto del negocio</option></select></Field>
        <Field label="Condición de venta" help="Va en la factura electrónica de compra; con crédito el plazo es creación → vencimiento"><select v-model="f.condicion_venta"><option v-for="o in CAT.condicionVentaDe('08')" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="Medio de pago"><select v-model="f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
      </div>
    </div>
    <div class="card"><h2>Conceptos <small>producto o cuenta contable</small></h2>
      <LineEditor v-model="f.lineas" :productos="store.productos" :moneda="f.moneda" compra></LineEditor>
      <div class="row" style="margin-top:10px;gap:14px">
        <button class="btn sec sm" v-if="pref.mostrarRetenciones" @click="agregarRetencion">+ Agregar retención</button>
        <button class="btn sec sm" @click="modalOrdenes=true" :disabled="!f.proveedor_id" :title="f.proveedor_id?'':'Seleccione primero el proveedor'">+ Órdenes de compra</button>
        <span class="small muted" v-if="f.ordenes_ids.length">Órdenes importadas: {{f.ordenes_ids.length}}</span>
      </div>
      <div v-if="f.retenciones.length" style="margin-top:12px"><div class="table-wrap"><table class="tbl">
        <thead><tr><th>Retención</th><th class="num" style="width:120px">%</th><th class="num">Monto</th><th></th></tr></thead>
        <tbody><tr v-for="(r,i) in f.retenciones" :key="i">
          <td><input class="inp" v-model="r.nombre" style="width:100%"></td>
          <td><input class="inp" type="number" step="0.01" v-model.number="r.pct" style="width:100%;text-align:right"></td>
          <td class="num">-{{money(subtotal*(r.pct||0)/100, f.moneda)}}</td>
          <td><button class="btn icon" title="Quitar" @click="quitarRetencion(i)">✕</button></td>
        </tr></tbody></table></div>
        <div class="totals"><div><span>Retenciones</span><b>-{{money(totalRet, f.moneda)}}</b></div><div class="total"><span>Total a pagar</span><b>{{money(total, f.moneda)}}</b></div></div>
      </div>
    </div>
    <div class="card"><div class="grid cols-2">
      <Field label="Términos y condiciones" v-if="pref.mostrarTerminos"><textarea rows="3" v-model="f.terminos" placeholder="Condiciones acordadas con el proveedor"></textarea></Field>
      <Field label="Notas"><textarea rows="3" v-model="f.notas" placeholder="Observaciones internas"></textarea></Field>
    </div></div>
    <div class="row end" style="margin-bottom:18px">
      <a class="btn ghost" :href="'#' + lista">Cancelar</a>
      <button class="btn sec" :disabled="guardando" @click="guardar('pago')">Guardar y agregar pago</button>
      <button class="btn sec" :disabled="guardando" @click="guardar('nueva')">Guardar y crear nueva</button>
      <button class="btn" :disabled="guardando" @click="guardar('guardar')">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </div>
    <Comments :saved="false"></Comments>
    <Drawer v-if="opciones" title="Personalizar opciones" @close="opciones=false">
      <p class="small muted">Elige qué campos se muestran en el formulario de facturas de compra.</p>
      <div class="row" style="flex-direction:column;align-items:flex-start;gap:10px">
        <Toggle v-model="pref.mostrarBodega" label="Bodega"></Toggle>
        <Toggle v-model="pref.mostrarRetenciones" label="Retenciones"></Toggle>
        <Toggle v-model="pref.mostrarTerminos" label="Términos y condiciones"></Toggle>
      </div>
      <h2 style="font-size:14px;margin-top:18px">Valores por defecto</h2>
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Moneda"><select v-model="f.moneda" @change="tcDelDia"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Bodega"><Buscador v-model="bodegaId" :opciones="bodegasApi" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
      </div>
      <template #foot><button class="btn" @click="opciones=false">Listo</button></template>
    </Drawer>
    <Modal v-if="modalOrdenes" title="Órdenes de compra abiertas del proveedor" lg @close="modalOrdenes=false">
      <div class="table-wrap" v-if="ordenesProv.length"><table class="tbl">
        <thead><tr><th>Código</th><th>Fecha</th><th>Entrega</th><th class="num">Líneas</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="o in ordenesProv" :key="o.id"><td class="mono">{{o.codigo}}</td><td>{{fecha(o.fecha)}}</td><td>{{fecha(o.entrega)}}</td><td class="num">{{o.lineas.length}}</td><td class="num">{{money(o.total, o.moneda)}}</td><td><button class="btn sm" @click="importarOrden(o)">Importar líneas</button></td></tr></tbody>
      </table></div>
      <Empty v-else icon="📋" title="Sin órdenes abiertas" text="Este proveedor no tiene órdenes de compra pendientes de recibir."><a class="btn sec" href="#/gastos/ordenes/nueva">+ Nueva orden de compra</a></Empty>
      <template #foot><button class="btn ghost" @click="modalOrdenes=false">Cerrar</button></template>
    </Modal>
  </div>`,
};
