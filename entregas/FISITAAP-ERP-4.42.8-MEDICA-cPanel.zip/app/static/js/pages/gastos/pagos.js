// Gastos › Pagos (comprobantes de egreso) — lista sobre el registro 'pagos_gastos'. El estado «Conciliado» viene del movimiento de
// Bancos de cada pago (se concilia en Bancos › Conciliaciones); comprobante de egreso en PDF o Word.
import { toast, money, fecha, mock, CAT, demo, hoy, sumarMeses } from '../../api.js';
import { store } from '../../app.js';
import { descargarReporte } from '../reportes/_montos.js';
import { revertirMovimientoBanco } from '../bancos/cuentas.js';
import { proveedores, CUENTAS_BANCARIAS, dias, sinEjemplos, compras } from './_datos.js';

const borrando = new Set();     // pagos que se están eliminando (un segundo clic no descuenta dos veces lo pagado)
function descontarPagado(pagos) {
  const aplicados = pagos.flatMap(p => p.facturas || []);
  if (!aplicados.length) return;
  mock.actualizar('compras', compras => {
    for (const f of aplicados) { const c = (compras || []).find(x => x.id === f.compra_id); if (c) c.pagado = Math.max(0, (c.pagado || 0) - f.monto); }
    return compras;
  }, []);
}

function semilla() {
  const p = proveedores();
  return [
    { id: 1, numero: 'CE-0001', contacto_id: p[1].id, contacto: p[1].nombre, fecha: dias(-28), cuenta: CUENTAS_BANCARIAS[0], medio: '04', moneda: 'CRC', monto: 33787, estado: 'Conciliado', nota: 'Pago suscripción octubre', facturas: [{ compra_id: 2, monto: 33787 }], cuentas: [] },
    { id: 2, numero: 'CE-0002', contacto_id: p[3].id, contacto: p[3].nombre, fecha: dias(-9), cuenta: CUENTAS_BANCARIAS[0], medio: '06', moneda: 'CRC', monto: 50000, estado: 'No conciliado', nota: 'Abono papelería', facturas: [{ compra_id: 4, monto: 50000 }], cuentas: [] },
    { id: 3, numero: 'CE-0003', contacto_id: p[3].id, contacto: p[3].nombre, fecha: dias(-55), cuenta: CUENTAS_BANCARIAS[2], medio: '03', moneda: 'CRC', monto: 135600, estado: 'Conciliado', nota: 'Limpieza agosto', facturas: [{ compra_id: 6, monto: 135600 }], cuentas: [] },
    { id: 4, numero: 'CE-0004', contacto_id: null, contacto: 'Municipalidad de San José', fecha: dias(-4), cuenta: CUENTAS_BANCARIAS[3], medio: '01', moneda: 'CRC', monto: 18500, estado: 'No conciliado', nota: 'Patente comercial IV trimestre', facturas: [], cuentas: [{ concepto: '5-01-001 Alquileres', valor: 18500, impuesto: 0, cantidad: 1, obs: 'Patente' }] },
    { id: 5, numero: 'CE-0005', contacto_id: p[0].id, contacto: p[0].nombre, fecha: dias(-1), cuenta: CUENTAS_BANCARIAS[1], medio: '04', moneda: 'USD', monto: 200, estado: 'No conciliado', nota: 'Abono licencias M365', facturas: [{ compra_id: 5, monto: 200 }], cuentas: [] },
  ];
}

export default {
  props: ['params'],
  data() { let lista = mock.get('pagos_gastos', null); if (!lista && demo.activo) { lista = semilla(); mock.set('pagos_gastos', lista); } lista = sinEjemplos(lista); return { lista, q: '', ver: null, desde: '', hasta: '', contacto: '', filtros: false }; },
  computed: {
    store() { return store; },
    contactosOpc() { return [...new Set(this.lista.map(p => p.contacto).filter(Boolean))].sort(); },
    rows() {
      // estado de conciliación: el del movimiento bancario del pago (Bancos › Conciliaciones); si no tiene movimiento, el del pago
      const movs = mock.get('movimientos', []) || [], porRef = new Map(movs.filter(m => m && m.ref).map(m => [m.ref, m]));
      return this.lista.filter(p => (!this.desde || String(p.fecha) >= this.desde) && (!this.hasta || String(p.fecha) <= this.hasta) && (!this.contacto || p.contacto === this.contacto))
        .map(p => { const m = porRef.get(p.ref_mov) || porRef.get('pago_gasto:' + p.id); return { ...p, estado: m ? (m.conciliado ? 'Conciliado' : 'No conciliado') : (p.estado || 'No conciliado'), sin_movimiento: !m }; })
        .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || b.id - a.id);
    },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.ver = r },
        { key: 'contacto', label: 'Contacto' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'cuenta', label: 'Cuenta bancaria', fmt: v => v.split(' · ')[0] },
        { key: 'medio', label: 'Medio de pago', fmt: v => CAT.medioPago[v] || v },
        { key: 'monto', label: 'Monto', num: true, fmt: 'money' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    numeroCompra(id) { const c = compras().find(x => x.id === id); return c ? c.numero + (c.proveedor ? ' · ' + c.proveedor : '') : '#' + id; },   // (R200)
    money, fecha,
    medio(v) { return CAT.medioPago[v] || v; },
    // Comprobante de egreso en PDF o Word (encabezado de la empresa, datos del pago, facturas aplicadas, cuentas y retenciones)
    comprobante(p, formato) {
      const cols = [{ key: 'c', label: 'Concepto' }, { key: 'd', label: 'Detalle' }, { key: 'm', label: 'Monto', num: true }];
      const filas = [...(p.facturas || []).map(f => ({ c: 'Factura de compra', d: this.numeroCompra(f.compra_id), m: money(f.monto, p.moneda) })),
        ...(p.cuentas || []).map(c => ({ c: c.concepto || c.cuenta || 'Gasto', d: c.obs || '', m: money((+c.valor || 0) * (+c.cantidad || 1) * (1 + (+c.impuesto || 0) / 100), p.moneda) })),
        ...(p.retenciones || []).map(r => ({ c: 'Retención', d: r.nombre, m: '-' + money(r.monto, p.moneda) }))];
      descargarReporte(formato, { titulo: 'Comprobante de egreso ' + p.numero, subtitulo: (p.contacto ? 'Pagado a: ' + p.contacto + ' · ' : '') + 'Cuenta: ' + String(p.cuenta || '').split(' · ')[0] + ' · Medio: ' + this.medio(p.medio) + (p.nota ? ' · ' + p.nota : ''), periodo: fecha(p.fecha),
        cols, rows: filas, kpis: [{ t: 'Monto pagado', v: money(p.monto, p.moneda) }, { t: 'Fecha', v: fecha(p.fecha) }, { t: 'Estado', v: p.estado || 'No conciliado' }], totales: [{ t: 'Total del pago', v: money(p.monto, p.moneda) }], nota: 'Comprobante interno de egreso.', archivo: 'egreso_' + p.numero });
    },
    limpiarFiltros() { this.desde = ''; this.hasta = ''; this.contacto = ''; },
    async eliminar(p) {
      if (borrando.has(p.id)) return;
      if (!confirm('¿Eliminar el pago ' + p.numero + '? Se revertirá el monto aplicado a las facturas.')) return;
      await this.quitar([p]);
      this.ver = null;
    },
    async eliminarVarios(rows) { await this.quitar(rows); },
    // Primero el movimiento en bancos: si no se puede quitar, los pagos se quedan (con su ref) para intentarlo de nuevo.
    // Después se trabaja sobre lo guardado más reciente (no sobre la copia de la pantalla) y solo si sigue la misma empresa.
    async quitar(rows) {
      if (!mock.puedeGuardar()) return;
      // Se buscan en lo guardado (por id, o por su movimiento si el servidor les dio otro id) ANTES de tocar el banco
      const antes = mock.get('pagos_gastos', []) || [];
      const buscar = p => antes.find(x => x.id === p.id && (!p.ref_mov || x.ref_mov === p.ref_mov)) || (p.ref_mov ? antes.find(x => x.ref_mov === p.ref_mov) : null);
      const hallados = rows.map(buscar);
      if (hallados.some(x => !x)) { this.lista = sinEjemplos(antes); return toast('La lista de pagos cambió mientras tanto; revísela y vuelva a intentar', 'err'); }
      const lote = hallados.filter(p => !borrando.has(p.id));
      if (!lote.length) return;
      lote.forEach(p => borrando.add(p.id));
      const gen = mock.generacion;
      try {
        if (!(await revertirMovimientoBanco(lote.flatMap(p => [p.ref_mov, 'pago_gasto:' + p.id])))) return;
        if (mock.generacion !== gen || !mock.cargado) return;                 // se cambió de empresa o se cerró la sesión
        // se vuelven a buscar con el mismo criterio: el servidor pudo darle otro id a un pago mientras se revertía el banco
        const ahora = mock.get('pagos_gastos', []) || [];
        const guardados = lote.map(p => ahora.find(x => x.id === p.id && (!p.ref_mov || x.ref_mov === p.ref_mov)) || (p.ref_mov ? ahora.find(x => x.ref_mov === p.ref_mov) : null)).filter(Boolean);
        if (!guardados.length) { this.lista = sinEjemplos(ahora); return toast('Esos pagos ya no están (otra persona los eliminó)', 'err'); }
        const ids = new Set(guardados.map(p => p.id));
        descontarPagado(guardados);
        const quedan = mock.actualizar('pagos_gastos', l => (l || []).filter(x => !ids.has(x.id)), []);
        this.lista = sinEjemplos(quedan);
        toast(guardados.length === 1 ? 'Pago eliminado' : guardados.length + ' pagos eliminados', 'ok');
      } finally { lote.forEach(p => borrando.delete(p.id)); }
    },
  },
  template: `
  <div class="page">
    <PageHead title="Pagos" sub="Comprobantes de egreso: pagos a proveedores y otros gastos desde sus cuentas de Bancos. Se concilian con el estado de cuenta en Bancos › Conciliaciones.">
      <a class="btn" v-if="puede('gastos')" href="#/gastos/pagos/nuevo">+ Nuevo pago</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar contacto o número" v-model="q"><button class="btn ghost sm" :class="{on: filtros}" @click="filtros=!filtros">⚲ Filtrar</button></div>
      <div class="row" style="padding:10px 12px 0;gap:10px;align-items:flex-end" v-if="filtros">
        <Field label="Desde"><input type="date" v-model="desde"></Field><Field label="Hasta"><input type="date" v-model="hasta"></Field>
        <Field label="Contacto"><select v-model="contacto"><option value="">Todos</option><option v-for="c in contactosOpc" :key="c">{{c}}</option></select></Field>
        <button class="btn ghost sm" @click="limpiarFiltros">Limpiar</button>
      </div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('gastos')" :on-bulk-delete="eliminarVarios" empty-title="Aún no has registrado pagos" empty-text="Registre el primer comprobante de egreso para llevar el control de sus salidas de dinero.">
        <template #actions="{row}">
          <button class="btn icon" title="Comprobante en PDF" @click.stop="comprobante(row, 'pdf')">⎙</button>
          <button class="btn icon" title="Ver" @click.stop="ver=row">👁</button>
          <button class="btn icon" v-if="puede('gastos')" title="Eliminar" @click.stop="eliminar(row)">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('gastos')" href="#/gastos/pagos/nuevo">+ Nuevo pago</a></template>
      </DataTable>
    </div>
    <Modal v-if="ver" :title="'Comprobante de egreso ' + ver.numero" lg @close="ver=null">
      <div class="grid cols-3" style="margin-bottom:12px">
        <div><div class="small muted">Contacto</div><b>{{ver.contacto||'—'}}</b></div>
        <div><div class="small muted">Fecha</div><b>{{fecha(ver.fecha)}}</b></div>
        <div><div class="small muted">Monto</div><b>{{money(ver.monto, ver.moneda)}}</b></div>
        <div><div class="small muted">Cuenta bancaria</div><b>{{ver.cuenta}}</b></div>
        <div><div class="small muted">Medio de pago</div><b>{{medio(ver.medio)}}</b></div>
        <div><div class="small muted">Estado</div><Badge :value="ver.estado"></Badge><div class="small muted" v-if="ver.sin_movimiento">Sin movimiento en Bancos</div></div>
      </div>
      <p v-if="ver.nota" class="small"><b>Nota de egreso:</b> {{ver.nota}}</p>
      <div v-if="ver.facturas && ver.facturas.length"><h2 style="font-size:14px">Facturas de compra aplicadas</h2>
        <table class="tbl"><tr v-for="(f,i) in ver.facturas" :key="i"><td>Factura #{{numeroCompra(f.compra_id)}}</td><td class="num">{{money(f.monto, ver.moneda)}}</td></tr></table></div>
      <div v-if="ver.cuentas && ver.cuentas.length"><h2 style="font-size:14px">Cuentas contables</h2>
        <table class="tbl"><tr v-for="(c,i) in ver.cuentas" :key="i"><td>{{c.concepto}}</td><td>{{c.obs}}</td><td class="num">{{money(c.valor*c.cantidad*(1+(c.impuesto||0)/100), ver.moneda)}}</td></tr></table></div>
      <div v-if="ver.retenciones && ver.retenciones.length"><h2 style="font-size:14px">Retenciones</h2>
        <table class="tbl"><tr v-for="(r,i) in ver.retenciones" :key="i"><td>{{r.nombre}}</td><td class="num">-{{money(r.monto, ver.moneda)}}</td></tr></table></div>
      <template #foot><button class="btn ghost" @click="ver=null">Cerrar</button><button class="btn sec" @click="comprobante(ver, 'docx')">⤓ Word</button><button class="btn" @click="comprobante(ver, 'pdf')">⤓ PDF</button></template>
    </Modal>
  </div>`,
};
