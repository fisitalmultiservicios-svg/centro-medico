// Gastos (4.23): reglas del registro de compras y gastos, sin dependencias (las usan Compras y Gastos, Recepción y Rectificaciones, y
// las pruebas las corren solas). No es una página. El «registro» junta las facturas del registro 'compras' y los comprobantes
// electrónicos recibidos, aceptados y registrados: de ahí salen los reportes y la contabilidad. Cuenta lo mismo que app/resumen.py.

// ¿Aceptado (05 o 06) sin que Hacienda rechazara la respuesta?
export const aceptado = r => !!r && ['05', '06'].includes(r.respuesta) && !['rechazado', 'error'].includes(r.estado_mensaje || '');
// ¿Está en el registro? Sin el dato, sí (lo aceptado antes de la 4.23); solo deja de estarlo cuando alguien lo elimina del registro
export const registrado = r => !!r && r.registrado !== false;
export const enRegistro = r => aceptado(r) && registrado(r);
// «Aceptado sin registrar»: aceptado ante Hacienda, fuera de reportes y contabilidad. Un recibo de pago (tipo 10) nunca forma parte del
// registro: no se le ofrece registrarlo (el servidor responde 409)
export const sinRegistrar = r => aceptado(r) && !registrado(r) && r.tipo_documento !== '10';

// Nota de crédito recibida (03) cuya factura no está en el registro: no resta en los reportes, así que registrarla o quitarla no cambia
// ningún mes (el servidor no pide motivo ni la anota: queda anotada cuando entra o sale su factura)
export const notaSinFactura = (r, recibidos) => !!r && r.tipo_documento === '03' && !!r.referencia_clave
  && !(Array.isArray(recibidos) ? recibidos : []).some(x => x && x.clave === r.referencia_clave && enRegistro(x));

// El mes 'AAAA-MM' de la fecha si es ANTERIOR al mes en curso (hoy: 'AAAA-MM-DD' de Costa Rica): eliminar, volver a registrar o
// reclasificar ese documento es una rectificación. Del mes en curso (o sin fecha): null
export function mesPasado(fecha, hoy) {
  const f = String(fecha || '').slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(f) && f.slice(0, 7) < String(hoy || '').slice(0, 7) ? f.slice(0, 7) : null;
}
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'];
export function mesLegible(mes) { const m = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(String(mes || '')); return m ? MESES[+m[2] - 1] + ' de ' + m[1] : String(mes || ''); }
// Lo que explica el cuadro que pide el motivo. hacerlo: 'eliminarlo', 'registrarlo de nuevo', 'cambiarlo de compra a gasto'…
export function avisoRectificacion(mes, hacerlo) {
  return 'Este documento es de ' + mesLegible(mes) + ': ' + hacerlo + ' cambia los reportes de ese mes. Queda anotado en Gastos › Rectificaciones; si ya presentó la declaración de ese mes, debe rectificarla.';
}
// El mes de la rectificación que deja ELIMINAR una fila de las listas (filasRegistro): null si el documento es del mes en curso o si
// hoy no cuenta en los reportes (fila.cuenta === false). Es la regla del servidor: en esos casos no pide motivo ni anota nada
export const mesRectificacion = (fila, hoy) => (fila && fila.cuenta !== false ? mesPasado(fila.fecha, hoy) : null);
export const MOTIVO_MIN = 5, MOTIVO_MAX = 300;
export function motivoValido(texto) { const n = String(texto || '').replace(/\s+/g, ' ').trim().length; return n >= MOTIVO_MIN && n <= MOTIVO_MAX; }

export const tipoCompra = c => (c && c.tipo === 'compra' ? 'compra' : 'gasto');                // sin el dato es gasto, como en los reportes
export const tipoRecibido = r => (r && r.clasificacion === 'compra' ? 'compra' : 'gasto');     // vacío = gasto
export const NOMBRE_TIPO = { compra: 'Compra', gasto: 'Gasto' };
export const ORIGEN = { electronica: 'Electrónica aceptada', manual: 'Manual', fec: 'Factura electrónica de compra', rechazado: 'Comprobante rechazado' };

const r2 = n => Math.round((+n || 0) * 100) / 100;
const finito = n => (Number.isFinite(+n) ? +n : 0);
// Base e IVA de las líneas de una factura hecha a mano, como los cuentan los reportes (cantidad × precio − descuento, y su tarifa)
export function montosLineas(lineas) {
  let base = 0, iva = 0;
  for (const l of Array.isArray(lineas) ? lineas : []) {
    if (!l || typeof l !== 'object') continue;
    const b = finito(l.cantidad) * finito(l.precio_unitario) - finito(l.descuento), p = finito(l.tarifa);
    base += b; iva += b * p / 100;
  }
  return { base: r2(base), iva: r2(iva) };
}

// Las filas del registro de un tipo ('compra' o 'gasto'), sin repetir:
//  a) las facturas del registro 'compras' (hechas a mano, con factura electrónica de compra o creadas desde un comprobante recibido), y
//  b) los comprobantes recibidos, aceptados y registrados que todavía no tienen su factura en 'compras' (si la tienen, sale una sola
//     fila: la de la factura, con el saldo por pagar).
// La factura creada desde un comprobante que está en el registro toma de él la clasificación, la fecha, el total y el IVA (es lo que
// cuentan los reportes). Las notas de crédito recibidas salen con su signo. No entran los recibos de pago (tipo 10) ni la nota de
// crédito cuya factura no está en el registro.
// La factura cuyo comprobante se RECHAZÓ (respuesta 07) sigue a la vista, para eliminarla, con el origen «Comprobante rechazado»: no
// cuenta en los reportes ni en la contabilidad (cuenta: false), se muestra atenuada y no suma en los totales del pie.
// Cada fila: { id, cid (id en 'compras' o null), rid (id del recibido o null), compra, recibido, tipo, origen, origenTexto, fecha, numero,
//   proveedor, moneda, total, iva, pagado, por_pagar (null sin factura en 'compras'), nota (nota de crédito recibida), tipo_documento,
//   cuenta (¿cuenta hoy en los reportes?: la regla con que el servidor pide el motivo y anota la rectificación), atenuada (!cuenta) }
export function filasRegistro(tipo, compras, recibidos) {
  compras = (Array.isArray(compras) ? compras : []).filter(c => c && typeof c === 'object' && c.id !== undefined && c.id !== null);
  recibidos = (Array.isArray(recibidos) ? recibidos : []).filter(r => r && typeof r === 'object');
  const porId = new Map(recibidos.map(r => [String(r.id), r])), porClave = new Map(recibidos.filter(r => r.clave).map(r => [r.clave, r]));
  // el recibido del que salió una factura: por su recepcion_id o por su clave. Es el único criterio, el mismo del servidor
  // (_recibido_de_compra), de los reportes (resumen.compras_manuales) y de los asientos (cm:): el compra_id que anota el recibido no
  // vincula por sí solo (esa factura y ese recibido son dos documentos, y así los cuentan los reportes)
  const recibidoDe = c => (c.recepcion_id !== undefined && c.recepcion_id !== null && porId.get(String(c.recepcion_id))) || (c.clave && porClave.get(c.clave)) || null;
  const clavesOk = new Set(recibidos.filter(enRegistro).map(r => r.clave));
  const notaValida = r => r.tipo_documento !== '03' || !r.referencia_clave || clavesOk.has(r.referencia_clave);
  const signo = r => (r.tipo_documento === '03' ? -1 : 1);
  const acreditar = r => finito(r.monto_impuesto_acreditar !== null && r.monto_impuesto_acreditar !== undefined ? r.monto_impuesto_acreditar : (r.iva !== null && r.iva !== undefined ? r.iva : r.impuesto));
  const numeroRec = r => r.consecutivo || String(r.clave || '').slice(21, 41);
  const conFactura = new Set(), filas = [];
  for (const c of compras) {
    const r = recibidoDe(c), reg = enRegistro(r) ? r : null;
    if (r) conFactura.add(String(r.id));
    const m = montosLineas(c.lineas), pagado = finito(c.pagado), sg = reg ? signo(reg) : 1;
    // ¿cuenta hoy en los reportes? No la factura de un comprobante rechazado (07); tampoco, aunque su comprobante esté aceptado, la de
    // un recibo de pago (tipo 10) ni la de una nota de crédito cuya factura no está en el registro (las mismas reglas del servidor)
    const rechazado = !reg && !c.fec_id && !!r && r.respuesta === '07', cuenta = reg ? reg.tipo_documento !== '10' && notaValida(reg) : !rechazado;
    filas.push({
      id: c.id, cid: c.id, rid: reg ? reg.id : null, compra: c, recibido: reg, tipo: reg ? tipoRecibido(reg) : tipoCompra(c), cuenta, atenuada: !cuenta,
      origen: c.fec_id ? 'fec' : (reg ? 'electronica' : (rechazado ? 'rechazado' : 'manual')), fecha: String((reg ? reg.fecha_emision : c.creacion) || '').slice(0, 10),
      numero: c.numero || (reg ? numeroRec(reg) : ''), proveedor: c.proveedor || (reg ? reg.emisor_nombre : '') || '—', moneda: c.moneda || (reg && reg.moneda) || 'CRC',
      total: reg ? r2(sg * finito(reg.total)) : (m.base || m.iva ? r2(m.base + m.iva) : r2(c.total)), iva: reg ? r2(sg * acreditar(reg)) : m.iva,
      pagado: r2(pagado), por_pagar: r2(Math.max(0, finito(c.total) - pagado)), nota: !!reg && reg.tipo_documento === '03', tipo_documento: reg ? reg.tipo_documento : null,
    });
  }
  for (const r of recibidos) {
    if (!enRegistro(r) || r.tipo_documento === '10' || !notaValida(r) || conFactura.has(String(r.id))) continue;
    const sg = signo(r);
    filas.push({
      id: 'r' + r.id, cid: null, rid: r.id, compra: null, recibido: r, tipo: tipoRecibido(r), cuenta: true, atenuada: false, origen: 'electronica', fecha: String(r.fecha_emision || '').slice(0, 10),
      numero: numeroRec(r), proveedor: r.emisor_nombre || '—', moneda: r.moneda || 'CRC', total: r2(sg * finito(r.total)), iva: r2(sg * acreditar(r)),
      pagado: 0, por_pagar: null, nota: r.tipo_documento === '03', tipo_documento: r.tipo_documento,
    });
  }
  return filas.filter(f => f.tipo === tipo).map(f => ({ ...f, origenTexto: ORIGEN[f.origen] + (f.nota ? ' · nota de crédito' : '') }))
    .sort((a, b) => b.fecha.localeCompare(a.fecha) || String(b.id).localeCompare(String(a.id), 'es', { numeric: true }));
}

// Totales al pie, por moneda (cada documento en la suya), de lo que cuenta en los reportes: [{ moneda, docs, total, iva, por_pagar }]
export function totalesRegistro(filas) {
  const m = new Map();
  for (const f of filas || []) {
    if (f.cuenta === false) continue;   // lo que hoy no cuenta en los reportes (la fila atenuada) no suma al pie
    const t = m.get(f.moneda) || { moneda: f.moneda, docs: 0, total: 0, iva: 0, por_pagar: 0 };
    t.docs++; t.total += finito(f.total); t.iva += finito(f.iva); t.por_pagar += finito(f.por_pagar);
    m.set(f.moneda, t);
  }
  return [...m.values()].map(t => ({ ...t, total: r2(t.total), iva: r2(t.iva), por_pagar: r2(t.por_pagar) })).sort((a, b) => (a.moneda !== 'CRC') - (b.moneda !== 'CRC') || a.moneda.localeCompare(b.moneda));
}

// Rectificaciones: resumen por mes afectado. Lo eliminado SALE del mes; lo vuelto a registrar ENTRA; lo reclasificado no cambia el
// total del mes (pasa de compra a gasto o al revés). Montos en colones (cada documento con su tipo de cambio).
export const ACCION = { eliminado: 'Eliminado', registrado: 'Registrado de nuevo', reclasificado: 'Cambio de clasificación' };
export function enColones(x, campo) { const v = finito(x && x[campo]), tc = finito(x && x.tipo_cambio); return r2((x && x.moneda && x.moneda !== 'CRC') ? v * (tc > 0 ? tc : 1) : v); }
export function resumenRectificaciones(lista) {
  const m = new Map();
  for (const x of Array.isArray(lista) ? lista : []) {
    if (!x || typeof x !== 'object') continue;
    const t = m.get(x.mes) || { mes: x.mes, cuantas: 0, eliminados: 0, registrados: 0, reclasificados: 0, salio_total: 0, salio_iva: 0, entro_total: 0, entro_iva: 0 };
    t.cuantas++;
    if (x.accion === 'eliminado') { t.eliminados++; t.salio_total += enColones(x, 'total'); t.salio_iva += enColones(x, 'iva_acreditar'); }
    else if (x.accion === 'registrado') { t.registrados++; t.entro_total += enColones(x, 'total'); t.entro_iva += enColones(x, 'iva_acreditar'); }
    else t.reclasificados++;
    m.set(x.mes, t);
  }
  return [...m.values()].map(t => ({ ...t, id: t.mes, salio_total: r2(t.salio_total), salio_iva: r2(t.salio_iva), entro_total: r2(t.entro_total), entro_iva: r2(t.entro_iva) }))
    .sort((a, b) => String(b.mes).localeCompare(String(a.mes)));
}
