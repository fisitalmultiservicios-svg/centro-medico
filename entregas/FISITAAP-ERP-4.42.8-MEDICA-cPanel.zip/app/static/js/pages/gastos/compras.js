// Gastos › Compras y Gastos › Gastos (4.23) — el registro de lo aceptado. Una sola pantalla con el tipo como parámetro: #/gastos/compras
// muestra lo clasificado como compra y #/gastos/gastos lo clasificado como gasto. Cada lista junta, sin repetir, las facturas del
// registro 'compras' (hechas a mano, con factura electrónica de compra o creadas desde un comprobante recibido) y los comprobantes
// electrónicos recibidos, aceptados y registrados que todavía no tienen su factura (filasRegistro, en _registro.js). De aquí salen los
// reportes y la contabilidad: eliminar una fila la saca de ahí, y si es de un mes pasado queda en Gastos › Rectificaciones.
import { toast, money, fecha, hoy, mock, api, fmtCant, verDocumento } from '../../api.js';
import { descargarTabla } from '../reportes/_montos.js';
import { store } from '../../app.js';
import { compras } from './_datos.js';
import { lineasInventario, entradaCompra } from './compra-form.js';
import { filasRegistro, totalesRegistro, mesPasado, mesRectificacion, mesLegible, avisoRectificacion, motivoValido, MOTIVO_MAX } from './_registro.js';

// el tipo sale de la dirección: la pantalla se monta de nuevo al pasar de una lista a la otra
const tipoDeRuta = () => (/^#?\/gastos\/gastos(\/|\?|$)/.test(String(location.hash || '')) ? 'gasto' : 'compra');
const TEXTOS = {
  compra: { titulo: 'Compras', sub: 'Mercadería y materia prima para vender (costo de ventas): lo que aceptó en Recepción de comprobantes y lo que registró a mano. De aquí salen los reportes y la contabilidad.',
    nueva: '+ Nueva compra', una: 'la compra', vacio: 'Aún no hay compras registradas', archivo: 'compras', otra: 'gasto', pasar: 'Pasar a gasto' },
  gasto: { titulo: 'Gastos', sub: 'Gastos del negocio (alquiler, servicios, suministros…): lo que aceptó en Recepción de comprobantes y lo que registró a mano. De aquí salen los reportes y la contabilidad.',
    nueva: '+ Nuevo gasto', una: 'el gasto', vacio: 'Aún no hay gastos registrados', archivo: 'gastos', otra: 'compra', pasar: 'Pasar a compra' },
};

export default {
  props: ['params'],
  data() { return { tipo: tipoDeRuta(), lista: compras(), recibidos: [], cargando: true, errorRecibidos: '', q: '', menu: false, ver: null, hoy: hoy(), dandoEntrada: null, enviando: false, rect: null, MOTIVO_MAX }; },
  computed: {
    t() { return TEXTOS[this.tipo]; },
    rows() { return filasRegistro(this.tipo, this.lista, this.recibidos); },
    totales() { return totalesRegistro(this.rows); },
    columns() {
      return [
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'numero', label: 'Número', mono: true, link: r => this.abrir(r) },
        { key: 'proveedor', label: 'Proveedor' },
        { key: 'origenTexto', label: 'Origen' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'iva', label: 'IVA', num: true, fmt: 'money' },
        { key: 'por_pagar', label: 'Por pagar', num: true, fmt: (v, r) => (v === null || v === undefined ? '—' : money(v, r.moneda)), csv: v => (v === null || v === undefined ? '' : +v) },
        ...(this.lista.some(c => c.inventario_pendiente) ? [{ key: 'inventario', label: 'Inventario', fmt: (v, r) => (r.compra ? (r.compra.inventario_pendiente ? 'Entrada pendiente' : (r.compra.inventario_codigo || '')) : (r.recibido && r.recibido.inventario_codigo) || '') }] : []),   // 3.87
      ];
    },
    rectTexto() { const x = this.rect; return x ? avisoRectificacion(x.mes, x.accion === 'eliminar' ? 'eliminarlo' : 'cambiarlo de ' + this.tipo + ' a ' + this.t.otra) : ''; },
    rectListo() { const x = this.rect; return !!x && !this.enviando && (x.accion === 'eliminar' ? motivoValido(x.motivo) : String(x.motivo || '').trim().length <= MOTIVO_MAX); },
  },
  methods: {
    money, fecha, mesLegible,
    // con saldo y la fecha de vencimiento ya pasada. La factura guardada (la que abre «Ver») no trae «por_pagar»: sale de su total y lo pagado
    vencida(c) { return Math.max(0, (+c.total || 0) - (+c.pagado || 0)) > 0 && c.vencimiento < this.hoy; },
    // «Ver»: la factura creada desde un comprobante electrónico dice su origen, como la lista («Electrónica aceptada»; «Comprobante
    // rechazado» si se rechazó), y no el «No electrónica» con que se guardó (que solo dice que no tiene factura electrónica de compra)
    emisionDe(c) { const f = this.rows.find(x => x.cid === c.id); return f && (f.origen === 'electronica' || f.origen === 'rechazado') ? f.origenTexto : c.emision; },
    guardar() { mock.set('compras', this.lista); },
    // lo aceptado en Recepción (los comprobantes recibidos): con ellos se arma la lista. Si no se pueden leer, se avisa: sin ellos faltarían filas
    async cargarRecibidos() {
      try { this.recibidos = await api('/api/recepcion'); this.errorRecibidos = ''; }
      catch (e) { this.errorRecibidos = e.message; }
      this.cargando = false;
    },
    async recargar() { await mock.refrescar(['compras'], { sinCorte: true }); this.lista = compras(); await this.cargarRecibidos(); },
    nombreFila(r) { return this.t.una + ' ' + (r.numero || '') + ' de ' + r.proveedor; },
    abrir(r) { if (r.compra) this.ver = r.compra; else verDocumento('/api/recepcion/' + r.rid + '/pdf', 'Comprobante ' + (r.numero || '') + ' · ' + r.proveedor).catch(e => toast(e.message, 'err')); },
    // estado vivo de la FEC desde el comprobante (la cola lo cambia después de guardar la compra) (R188)
    async refrescarFec() { try { const docs = await api('/api/comprobantes'); let n = 0; for (const c of this.lista) { if (!c.fec_id) continue; const d = docs.find(x => x.id === c.fec_id); if (d && c.emision !== 'FEC ' + d.estado) { c.emision = 'FEC ' + d.estado; n++; } } if (n) this.guardar(); } catch {} },
    registrarPago(c) { if (c.por_pagar <= 0) return toast('Esta factura ya está pagada'); location.hash = '/gastos/pagos/nuevo?compra=' + c.id; toast('Registrando pago de la factura ' + c.numero); },
    // un comprobante aceptado que todavía no tiene su factura para pagar: el flujo de siempre (la compra se crea desde el recibido)
    registrarParaPagar(r) { location.hash = '/gastos/compras/nueva?recepcion=' + r.rid; },
    // una compra con pagos o notas de débito aplicados, o con FEC emitida, no se elimina (el servidor también lo rechaza) (R180)
    bloqueada(r) { const c = r.compra; if (!c) return ''; return (c.pagado || 0) > 0.005 ? 'tiene pagos o notas de débito aplicados (elimínelos primero)' : c.fec_id ? 'tiene una factura electrónica de compra emitida' : ''; },
    // Eliminar: sale de los reportes y de la contabilidad. De un mes pasado es una rectificación: el cuadro pide el motivo. Lo que hoy no
    // cuenta en los reportes (la factura de un comprobante rechazado) no cambia ningún mes: basta confirmar, como decide el servidor
    eliminar(r) {
      const b = this.bloqueada(r); if (b) return toast('No se puede eliminar ' + this.nombreFila(r) + ': ' + b, 'err');
      const mes = mesRectificacion(r, hoy());
      if (mes) { this.rect = { fila: r, accion: 'eliminar', mes, motivo: '' }; return; }
      if (r.cuenta === false) { if (!confirm('¿Eliminar ' + this.nombreFila(r) + '? Hoy no cuenta en los reportes ni en la contabilidad: solo sale de esta lista.')) return; }
      else if (!confirm('¿Eliminar ' + this.nombreFila(r) + '? Sale de los reportes y de la contabilidad' + (r.rid ? '; la aceptación ante Hacienda no cambia.' : '.'))) return;
      this.enviarEliminar(r, '');
    },
    // la factura del registro 'compras' se elimina por su ruta (con ella sale su comprobante recibido); un aceptado sin factura, por la suya
    pedirEliminar(r, motivo) {
      const body = { motivo: String(motivo || '').trim() || null };
      return r.cid !== null ? api('/api/gastos/compras/' + r.cid + '/eliminar', { method: 'POST', body }) : api('/api/recepcion/' + r.rid + '/quitar-registro', { method: 'POST', body });
    },
    async enviarEliminar(r, motivo) {
      if (this.enviando || !mock.puedeGuardar()) return;
      this.enviando = true;
      try {
        await mock.guardarTodo();   // lo último que esta pestaña guardó de 'compras' ya está en el servidor
        const x = await this.pedirEliminar(r, motivo);
        this.rect = null; if (this.ver && r.compra && this.ver.id === r.compra.id) this.ver = null;
        toast((this.tipo === 'compra' ? 'Compra eliminada' : 'Gasto eliminado') + ' del registro' + (x.rectificacion ? ': quedó anotado en Gastos › Rectificaciones' : ''), 'ok');
        if (x.aviso) toast(x.aviso);
      } catch (e) {
        // el servidor ya lo tiene por un documento de un mes pasado (cambió el mes con la pantalla abierta): se abre el cuadro del motivo
        if (e.status === 400 && !this.rect && /motivo/i.test(e.message || '')) this.rect = { fila: r, accion: 'eliminar', mes: String(r.fecha || '').slice(0, 7), motivo: '' };
        toast(e.message, 'err');
      }
      try { await this.recargar(); } catch { /* la lista se actualiza al volver a entrar */ } finally { this.enviando = false; }
    },
    async eliminarVarios(rows) {
      const libres = rows.filter(r => !this.bloqueada(r)), pasadas = libres.filter(r => mesRectificacion(r, hoy())), ahora = libres.filter(r => !mesRectificacion(r, hoy()));
      if (libres.length < rows.length) toast((rows.length - libres.length) + ' con pagos, notas de débito o factura electrónica de compra no se eliminan', 'err');
      if (pasadas.length) toast(pasadas.length + ' de meses pasados no se eliminan en grupo: elimínelas una por una, con su motivo', 'err');
      if (!ahora.length || this.enviando || !mock.puedeGuardar()) return;
      this.enviando = true;
      let ok = 0;
      try { await mock.guardarTodo(); for (const r of ahora) { await this.pedirEliminar(r, ''); ok++; } }
      catch (e) { toast(e.message, 'err'); }
      if (ok) toast(ok + (ok === 1 ? ' documento eliminado' : ' documentos eliminados') + ' del registro', 'ok');
      try { await this.recargar(); } catch { /* la lista se actualiza al volver a entrar */ } finally { this.enviando = false; }
    },
    // Pasar de compra a gasto (o al revés) un comprobante aceptado: la ruta de clasificación de Recepción. De un mes pasado queda anotado
    reclasificar(r) {
      const mes = mesPasado(r.fecha, hoy());
      if (mes) { this.rect = { fila: r, accion: 'reclasificar', mes, motivo: '' }; return; }
      this.enviarReclasificar(r, '');
    },
    async enviarReclasificar(r, motivo) {
      if (this.enviando) return;
      this.enviando = true;
      try {
        await api('/api/recepcion/' + r.rid + '/clasificacion', { method: 'PUT', body: { clasificacion: this.t.otra, cuenta_contable: null, motivo: String(motivo || '').trim() || null } });
        this.rect = null;
        toast((r.numero || 'El documento') + ' pasa a ' + TEXTOS[this.t.otra].titulo + '; la contabilidad se ajusta al abrir Contabilidad o los reportes', 'ok');
      } catch (e) { toast(e.message, 'err'); }
      try { await this.cargarRecibidos(); } finally { this.enviando = false; }
    },
    confirmarRect() { const x = this.rect; if (!x || !this.rectListo) return; if (x.accion === 'eliminar') this.enviarEliminar(x.fila, x.motivo); else this.enviarReclasificar(x.fila, x.motivo); },
    // toda lista se exporta en PDF, Excel y CSV (4.17)
    exportar(formato) {
      if (!this.rows.length) return toast('No hay datos para exportar');
      return descargarTabla(formato, this.t.archivo, [...this.columns.slice(0, 4), { key: 'moneda', label: 'Moneda' }, ...this.columns.slice(4, 7)], this.rows, { titulo: this.t.titulo, periodo: 'Al ' + fecha(this.hoy) });
    },
    importar() { toast('La importación desde Excel estará disponible cuando el backend de compras esté listo'); },
    // 3.87: la compra la guardó un rol sin permiso de inventario (el Contador): quien sí lo tiene registra aquí la entrada a la bodega
    puedeEntrada(c) { return !!c.inventario_pendiente && this.puede('inventario') && this.puede('gastos'); },
    // 3.87: la entrada lleva la clave «compra:<id>»: si ya se registró (otro clic, otra persona o un guardado que no llegó) el servidor
    // responde 409 y solo se quita la marca. Antes se trae la lista del servidor, se muestra qué entra y se espera el guardado.
    async darEntrada(c) {
      if (this.dandoEntrada || !mock.puedeGuardar()) return;
      this.dandoEntrada = c.id;
      try {
        await mock.refrescar(['compras'], { sinCorte: true }); this.lista = compras();   // 4.8: sigue aunque el usuario cambie de pantalla
        const x = this.lista.find(y => y.id === c.id);
        if (!x || !x.inventario_pendiente) { if (this.ver && this.ver.id === c.id) this.ver = x || null; return toast('La compra ' + c.numero + ' ya no tiene la entrada al inventario pendiente' + (x && x.inventario_codigo ? ' (' + x.inventario_codigo + ')' : ''), 'ok'); }
        const inv = lineasInventario(x, x.lineas);
        if (!inv.length) return toast('Esta compra ya no tiene ítems de inventario', 'err');
        const prods = store.productos || [], nombre = id => (prods.find(p => p.id == id) || {}).nombre || ('Ítem ' + id);
        if (!confirm('Entrada al inventario de la factura de compra ' + x.numero + ' (costo unitario en colones):\n' + inv.map(l => '· ' + fmtCant(l.cantidad) + ' × ' + nombre(l.producto_id) + ' a ' + money(l.costo_unitario)).join('\n') + '\n\n¿Registrar la entrada?')) return;
        let bodega = x.bodega_id;
        if (!bodega) { const bs = await api('/api/inventario/bodegas'); bodega = ((bs.find(b => b.principal) || bs[0]) || {}).id; }
        let codigo = null, ya = null;
        try { codigo = (await entradaCompra(x, inv, bodega, x.recepcion_id, 'compra:' + x.id)).codigo; }
        catch (e) {   // ya había entrado (por esta compra o, por Recepción, por su comprobante): la compra no queda pendiente
          if (e.status !== 409 || typeof e.detail !== 'string' || !e.detail.includes('ya entró al inventario')) throw e;
          ya = (/\(([A-Z]{2}-\d+)\)/.exec(e.detail) || [])[1] || null;
          toast(e.message + '. La compra ya no queda pendiente.', 'ok');
        }
        delete x.inventario_pendiente; if (codigo || ya) x.inventario_codigo = codigo || ya;
        if (this.ver && this.ver.id === x.id) this.ver = x;
        const ok = await mock.set('compras', this.lista);
        if (codigo) toast(ok ? 'Inventario: entrada ' + codigo + ' registrada por la compra ' + x.numero : 'La entrada ' + codigo + ' quedó registrada, pero la compra no se pudo actualizar. No se registra dos veces: al intentarlo de nuevo solo se quita la marca.', ok ? 'ok' : 'err');
      } catch (e) { toast('No se pudo registrar la entrada al inventario: ' + e.message, 'err'); }
      finally { this.dandoEntrada = null; }
    },
  },
  created() { this.refrescarFec(); this.cargarRecibidos(); },
  template: `
  <div class="page">
    <PageHead :title="t.titulo" :sub="t.sub">
      <div style="position:relative"><button class="btn ghost" @click="menu=!menu">Más acciones ▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:220px;padding:6px" @click="menu=false">
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar('pdf')">⤓ PDF</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar('xlsx')">⤓ Excel</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar('csv')">⤓ CSV</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="importar">Importar desde Excel</a></div></div>
      <a class="btn sec" href="#/gastos/recepcion">Recepción de comprobantes</a>
      <a class="btn" v-if="puede('gastos')" :href="'#/gastos/compras/nueva?tipo=' + tipo">{{t.nueva}}</a>
    </PageHead>
    <div class="alert err" v-if="errorRecibidos">No se pudieron leer los comprobantes aceptados ({{errorRecibidos}}): la lista puede estar incompleta. <a class="link" @click="recargar">Intentar de nuevo</a></div>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar proveedor o número" v-model="q"></div>
      <p class="muted small" style="padding:12px" v-if="cargando">Cargando…</p>
      <DataTable v-else :rows="rows" :columns="columns" :search="q" :selectable="puede('gastos')" :on-bulk-delete="eliminarVarios" :empty-title="t.vacio" empty-text="Aquí aparece lo que acepte en Recepción de comprobantes y lo que registre a mano. Lo que elimine sale de los reportes y de la contabilidad.">
        <template #actions="{row}">
          <template v-if="row.compra">
            <button class="btn sm" v-if="puedeEntrada(row.compra)" :disabled="dandoEntrada===row.cid" @click.stop="darEntrada(row.compra)" title="La compra se guardó sin entrada al inventario">Dar entrada al inventario</button>
            <button class="btn sm sec" :disabled="row.por_pagar<=0" @click.stop="registrarPago({...row.compra, por_pagar: row.por_pagar})">Registrar pago</button>
            <button class="btn icon" title="Ver" @click.stop="ver=row.compra">👁</button>
          </template>
          <template v-else>
            <button class="btn icon" title="Ver el comprobante" @click.stop="abrir(row)">⎙</button>
            <button class="btn sm sec" v-if="puede('gastos') && !row.nota" @click.stop="registrarParaPagar(row)" title="Crea la factura por pagar a partir de este comprobante aceptado">Registrar para pagar</button>
          </template>
          <button class="btn sm ghost" v-if="puede('gastos') && row.rid" :disabled="enviando" @click.stop="reclasificar(row)">{{t.pasar}}</button>
          <button class="btn icon" v-if="puede('gastos')" :disabled="enviando" title="Eliminar del registro" @click.stop="eliminar(row)">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('gastos')" :href="'#/gastos/compras/nueva?tipo=' + tipo">{{t.nueva}}</a></template>
      </DataTable>
      <div class="row" style="padding:10px 12px;gap:18px;flex-wrap:wrap;border-top:1px solid var(--line)" v-if="!cargando && totales.length">
        <span v-for="x in totales" :key="x.moneda"><b>{{x.docs}}</b> {{x.docs===1 ? 'documento' : 'documentos'}} · Total <b>{{money(x.total, x.moneda)}}</b> · IVA <b>{{money(x.iva, x.moneda)}}</b> · Por pagar <b>{{money(x.por_pagar, x.moneda)}}</b></span>
      </div>
    </div>
    <Modal v-if="rect" :title="rect.accion === 'eliminar' ? 'Eliminar ' + t.una + ' de un mes pasado' : t.pasar + ': documento de un mes pasado'" @close="rect=null">
      <p class="small muted" style="margin-top:0"><b>{{rect.fila.proveedor}}</b> · {{rect.fila.numero}} · {{fecha(rect.fila.fecha)}} · {{money(rect.fila.total, rect.fila.moneda)}}</p>
      <div class="alert warn">{{rectTexto}}</div>
      <Field label="Motivo" :req="rect.accion === 'eliminar'" :help="rect.accion === 'eliminar' ? 'De 5 a 300 letras' : 'Opcional, hasta 300 letras'"><textarea rows="3" :maxlength="MOTIVO_MAX" v-model="rect.motivo" placeholder="Por qué se hace el cambio"></textarea></Field>
      <template #foot><button class="btn ghost" @click="rect=null">Cancelar</button><button class="btn" :class="{danger: rect.accion === 'eliminar'}" :disabled="!rectListo" @click="confirmarRect">{{enviando ? 'Guardando…' : (rect.accion === 'eliminar' ? 'Eliminar del registro' : t.pasar)}}</button></template>
    </Modal>
    <Modal v-if="ver" :title="'Factura ' + ver.numero" lg @close="ver=null">
      <div class="grid cols-3" style="margin-bottom:12px">
        <div><div class="small muted">Proveedor</div><b>{{ver.proveedor}}</b></div>
        <div><div class="small muted">Creación</div><b>{{fecha(ver.creacion)}}</b></div>
        <div><div class="small muted">Vencimiento</div><b :style="vencida(ver)?'color:var(--danger)':''">{{fecha(ver.vencimiento)}}</b></div>
        <div><div class="small muted">Total</div><b>{{money(ver.total, ver.moneda)}}</b></div>
        <div><div class="small muted">Pagado</div><b>{{money(ver.pagado||0, ver.moneda)}}</b></div>
        <div><div class="small muted">Estado de emisión</div><Badge :value="emisionDe(ver)"></Badge></div>
      </div>
      <div class="alert warn" v-if="ver.inventario_pendiente">La mercadería de esta compra todavía no entró al inventario: se guardó con un rol sin permiso de inventario.<span v-if="!puedeEntrada(ver)"> La registra quien tenga ese permiso.</span></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Concepto</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">IVA</th></tr></thead>
        <tbody><tr v-for="(l,i) in ver.lineas" :key="i"><td>{{l.detalle}}</td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio_unitario, ver.moneda)}}</td><td class="num">{{l.tarifa}} %</td></tr></tbody></table></div>
      <template #foot><button class="btn ghost" @click="ver=null">Cerrar</button><button class="btn sec" v-if="puedeEntrada(ver)" :disabled="dandoEntrada===ver.id" @click="darEntrada(ver)">Dar entrada al inventario</button><button class="btn" :disabled="ver.total-(ver.pagado||0)<=0" @click="registrarPago({...ver, por_pagar: ver.total-(ver.pagado||0)})">Registrar pago</button></template>
    </Modal>
  </div>`,
};
