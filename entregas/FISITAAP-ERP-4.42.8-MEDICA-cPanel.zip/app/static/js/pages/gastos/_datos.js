// Datos compartidos por las páginas de Gastos (compras, órdenes, pagos y notas en registros por empresa; proveedores = Contactos). No es una página.
import { mock, hoy, demo, sumarDias } from '../../api.js';
import { store } from '../../app.js';
import { lineasPdf } from '../ventas/cotizaciones.js';

// Payload de POST /api/pdf/documento (tipo 'orden_compra') a partir de una orden; el proveedor va en `cliente`.
export function payloadOrdenCompra(o) {
  const p = proveedores().find(x => x.id == o.proveedor_id) || {};
  return {
    tipo: 'orden_compra', numero: o.codigo, fecha: o.fecha, vence: o.entrega || null, moneda: o.moneda || 'CRC', tipo_cambio: o.tipo_cambio || 1, condicion: o.plazo || null,
    cliente: { nombre: o.proveedor || p.nombre || '', tipo_id: p.tipo_id || '', cedula: p.numero_id || '', telefono: p.telefono || '', direccion: p.direccion || '', correo: p.correo || '' },
    lineas: lineasPdf(o.lineas), terminos: o.terminos || null, notas: o.notas || null, marca_id: o.marca_id || null,   /* 3.45 */
  };
}

// Fecha ISO desplazada n días respecto a hoy
export function dias(n) { return sumarDias(hoy(), n); }   // hora local (R194)

export const CUENTAS_GASTO = [
  '5-01-001 Alquileres', '5-01-002 Servicios públicos (ICE, AyA)', '5-01-003 Telefonía e internet', '5-01-004 Papelería y suministros',
  '5-01-005 Honorarios profesionales', '5-01-006 Mantenimiento y reparaciones', '5-01-007 Publicidad y mercadeo', '5-01-008 Transporte y combustible',
  '5-02-001 Salarios', '5-02-002 Cargas sociales CCSS', '1-01-005 Inventario de mercadería',
];
export const CUENTAS_BANCARIAS = ['BAC Credomatic ₡ · CR05010200009012345678', 'Banco Nacional $ · CR72015100010012345678', 'BCR ₡ · CR12015201001012345679', 'Caja general'];
export const BODEGAS = ['Principal', 'Sucursal Cartago'];

const PROVEEDORES_EJEMPLO = [
  { nombre: 'Intcomex Costa Rica S.A.', tipo: 'Proveedor', tipo_id: '02', numero_id: '3101123456', correo: 'facturacion@intcomex.cr', telefono: '2201-5000' },
  { nombre: 'Alanube Soluciones S.A.', tipo: 'Proveedor', tipo_id: '02', numero_id: '3101654321', correo: 'cobros@alanube.cr', telefono: '4000-1234' },
  { nombre: 'CoopeServidores R.L.', tipo: 'Proveedor', tipo_id: '02', numero_id: '3004045111', correo: 'proveedores@cs.fi.cr', telefono: '2243-3333' },
  { nombre: 'Distribuidora La Florida S.A.', tipo: 'Proveedor', tipo_id: '02', numero_id: '3101007792', correo: 'ventas@florida.co.cr', telefono: '2437-6700' },
];

// Nombres de los emisores de ejemplo (proveedores, recepción de comprobantes); sirven para reconocer y quitar filas de ejemplo.
export const NOMBRES_EJEMPLO = [...PROVEEDORES_EJEMPLO.map(p => p.nombre), 'Instituto Costarricense de Electricidad', 'Compañía Nacional de Fuerza y Luz',
  'Office Depot de Costa Rica', 'Grupo Purdy Motor S.A.', 'Gollo (Unicomer de Costa Rica)', 'Walmart de Costa Rica'];
// Huellas exactas (id | número | proveedor) de las filas de ejemplo de compras, órdenes y pagos que pudieron quedar
// guardadas de versiones anteriores. Antes se quitaba toda fila que MENCIONARA a ICE, CNFL, Walmart…, y eso borraba
// compras reales a esas empresas.
const [P0, P1, P2, P3] = PROVEEDORES_EJEMPLO.map(p => p.nombre);
const HUELLAS_EJEMPLO = new Set([
  [1, '00100001010000004512', P0], [2, '00100001010000000871', P1], [3, 'FAC-2026-0319', P2], [4, '00100001010000011203', P3], [5, '00100001010000004590', P0], [6, 'REC-0092', P3],
  [1, 'OC-0001', P0], [2, 'OC-0002', P3], [3, 'OC-0003', P0], [4, 'OC-0004', P1],
  [1, 'CE-0001', P1], [2, 'CE-0002', P3], [3, 'CE-0003', P3], [4, 'CE-0004', 'Municipalidad de San José'], [5, 'CE-0005', P0],
].map(h => h.join('|')));
const huella = x => [x.id, x.numero || x.codigo || '', x.proveedor || x.contacto || ''].join('|');
// Producción: quita solo las filas de ejemplo exactas. Demo: deja la lista tal cual.
export function sinEjemplos(lista) {
  if (demo.activo || !Array.isArray(lista)) return lista || [];
  return lista.filter(x => !HUELLAS_EJEMPLO.has(huella(x)));
}
// Contactos para Gastos. Producción: los contactos reales del módulo Contactos (servidor, /api/clientes), activos; el id es el
// del contacto, así que sirve también para la factura electrónica de compra. Demo: el registro 'contactos' con 4 proveedores de
// ejemplo que usan las semillas de compras, órdenes y pagos.
export function contactos() {
  if (!demo.activo) {
    return (store.clientes || []).filter(c => c.activo !== false).map(c => ({ id: c.id, nombre: c.nombre, nombre_comercial: c.nombre_comercial || '', tipo: c.tipo || 'Cliente',
      tipo_id: c.tipo_id, numero_id: c.numero_id, correo: c.correo || '', telefono: c.telefono ? String(c.telefono) : '', direccion: c.direccion || '', real: true }));
  }
  const lista = mock.get('contactos', []);
  const faltan = PROVEEDORES_EJEMPLO.filter(p => !lista.some(c => c.numero_id === p.numero_id));   // las semillas usan estos 4 por posición
  if (faltan.length) { for (const p of faltan) lista.push({ id: mock.nextId(lista, 'contactos'), ...p }); mock.set('contactos', lista); }
  return lista;
}
export const esProveedor = c => c.tipo === 'Proveedor' || c.tipo === 'Ambos';
export function proveedores() { return contactos().filter(esProveedor); }

const linea = (detalle, cantidad, precio, cabys = '', codigo_tarifa = '08') => ({ producto_id: null, detalle, cabys, cantidad, precio_unitario: precio, descuento: 0, codigo_tarifa, tarifa: codigo_tarifa === '08' ? 13 : codigo_tarifa === '04' ? 4 : codigo_tarifa === '01' ? 0 : 0 });
export function totalLineas(lineas) { return (lineas || []).reduce((s, l) => { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); return s + m + m * (l.tarifa || 0) / 100; }, 0); }

// Facturas de compra de ejemplo (mock 'compras')
export function compras() {
  let lista = mock.get('compras', null);
  if (lista || !demo.activo) { if (!demo.activo) contactos(); return sinEjemplos(lista); }   // contactos() quita los proveedores de ejemplo
  const p = proveedores();
  const mk = (id, numero, prov, creacion, vencimiento, lineas, pagado, emision, moneda = 'CRC') => ({ id, numero, proveedor_id: prov.id, proveedor: prov.nombre, creacion, vencimiento, moneda, lineas, total: Math.round(totalLineas(lineas) * 100) / 100, pagado, emision, bodega: 'Principal', terminos: '', notas: '', retenciones: [] });
  lista = [
    mk(1, '00100001010000004512', p[0], dias(-45), dias(-15), [linea('Laptop Dell Latitude 5540', 2, 685000, '4522000000100'), linea('Monitor LG 27" IPS', 2, 145000, '4522000000200')], 0, 'Electrónica'),
    mk(2, '00100001010000000871', p[1], dias(-30), dias(0), [linea('Suscripción plataforma de facturación · octubre', 1, 29900, '8314000000000')], 29900 * 1.13, 'Electrónica'),
    mk(3, 'FAC-2026-0319', p[2], dias(-20), dias(10), [linea('Comisión por administración de planilla', 1, 85000, '7123000000000')], 0, 'No electrónica'),
    mk(4, '00100001010000011203', p[3], dias(-12), dias(18), [linea('Resma de papel bond carta (caja 10)', 6, 23500, '3217000000100'), linea('Tóner HP 85A', 3, 42000, '4521000000500')], 50000, 'Electrónica'),
    mk(5, '00100001010000004590', p[0], dias(-5), dias(25), [linea('Licencia Microsoft 365 Business (12 meses)', 5, 78, '8314100000000')], 0, 'Electrónica', 'USD'),
    mk(6, 'REC-0092', p[3], dias(-60), dias(-30), [linea('Servicio de limpieza · agosto', 1, 120000, '8532000000000')], 135600, 'No electrónica'),
  ];
  mock.set('compras', lista);
  return lista;
}

// Órdenes de compra de ejemplo (mock 'ordenes')
export function ordenes() {
  let lista = mock.get('ordenes', null);
  if (lista || !demo.activo) { if (!demo.activo) contactos(); return sinEjemplos(lista); }   // contactos() quita los proveedores de ejemplo
  const p = proveedores();
  const mk = (id, n, prov, fecha, entrega, plazo, estado, lineas, moneda = 'CRC') => ({ id, codigo: 'OC-' + String(n).padStart(4, '0'), proveedor_id: prov.id, proveedor: prov.nombre, fecha, entrega, plazo, estado, moneda, lineas, total: Math.round(totalLineas(lineas) * 100) / 100, bodega: 'Principal', terminos: '', notas: '' });
  lista = [
    mk(1, 1, p[0], dias(-40), dias(-25), '30 días', 'Recibida', [linea('Laptop Dell Latitude 5540', 2, 685000, '4522000000100'), linea('Monitor LG 27" IPS', 2, 145000, '4522000000200')]),
    mk(2, 2, p[3], dias(-10), dias(5), '15 días', 'Abierta', [linea('Resma de papel bond carta (caja 10)', 10, 23500, '3217000000100'), linea('Bolígrafos Pilot caja x12', 8, 6800, '3216000000300')]),
    mk(3, 3, p[0], dias(-3), dias(12), 'De contado', 'Abierta', [linea('Switch Ubiquiti 24 puertos PoE', 1, 215, '4522100000100'), linea('Access Point UniFi U6', 4, 129, '4522100000200')], 'USD'),
    mk(4, 4, p[1], dias(-90), dias(-80), '30 días', 'Cerrada', [linea('Implementación inicial plataforma', 1, 350000, '8314000000000')]),
  ];
  mock.set('ordenes', lista);
  return lista;
}

export { hoy };
