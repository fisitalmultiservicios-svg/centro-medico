// Gastos › Pagos recurrentes — registro 'recurrentes_gastos' por empresa. Cada recurrencia tiene inicio, frecuencia en meses y
// opcionalmente fin; en cada fecha programada queda PENDIENTE y desde aquí se registra el pago (crea el comprobante de egreso en
// 'pagos_gastos' con sus cuentas contables y el movimiento en Bancos), se cambia la fecha o se omite. Lo generado y lo omitido
// se recuerda en la recurrencia (`hechos` = ['2026-10', …]) para no repetirlo.
import { toast, money, fecha, hoy, mock, monedas, sumarMeses } from '../../api.js';
import { contactos } from './_datos.js';
import { cuentasActivas, cuentaPrincipal, registrarMovimientoBanco, refUnica, problemaMoneda } from '../bancos/cuentas.js';
import { planCuentas } from '../contabilidad/catalogo.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const nuevaLinea = (c) => ({ concepto: c, precio: null, impuesto: 13, cantidad: 1, obs: '' });
const periodo = f => String(f || '').slice(0, 7);

// Fechas programadas de una recurrencia hasta `hasta` (inclusive): inicio, inicio + n·frecuencia meses… sin pasar del fin
export function fechasProgramadas(r, hasta) {
  const out = [], paso = Math.max(1, +r.frecuencia || 1);
  if (!r.inicio) return out;
  for (let k = 0; k < 600; k++) { const f = sumarMeses(String(r.inicio).slice(0, 10), k * paso); if (f > hasta) break; if (r.fin && f > r.fin) break; out.push(f); }
  return out;
}
// Fechas que todavía no se registraron ni se omitieron (fecha cambiada: `reprogramadas[periodo] = fecha`)
export function pendientesDe(r, hasta) {
  if (r.estado !== 'Activo') return [];
  const hechos = new Set(r.hechos || []), re = r.reprogramadas || {};
  return fechasProgramadas(r, hasta).map(f => ({ periodo: periodo(f), fecha: re[periodo(f)] || f })).filter(x => !hechos.has(x.periodo) && x.fecha <= hasta);
}
export function proximaDe(r) {
  if (r.estado !== 'Activo' || !r.inicio) return '';
  const hechos = new Set(r.hechos || []), re = r.reprogramadas || {}, paso = Math.max(1, +r.frecuencia || 1);
  for (let k = 0; k < 600; k++) { const f = sumarMeses(String(r.inicio).slice(0, 10), k * paso); if (r.fin && f > r.fin) break; if (!hechos.has(periodo(f))) return re[periodo(f)] || f; }
  return '';
}

export default {
  props: ['params'],
  data() {
    const activas = cuentasActivas();
    return { lista: (mock.get('recurrentes_gastos', []) || []).filter(r => r && r.id), CUENTAS_GASTO: planCuentas().filter(c => c.hoja && ['5', '6'].includes(c.raiz)).map(c => c.codigo + ' ' + c.nombre), cuentasOpc: activas.map(b => ({ nombre: b.nombre, moneda: b.moneda || 'CRC' })), monedasOpc: monedas.opciones(), modal: false, f: null, q: '', posponer: null, nuevaFecha: hoy(), ocupado: false };
  },
  computed: {
    contactosLista() { return contactos(); },
    rows() { return this.lista.map(r => ({ ...r, frecuencia_txt: r.frecuencia === 1 ? 'Cada mes' : 'Cada ' + r.frecuencia + ' meses', contacto: r.contacto || '—', fin: r.fin || '', proxima: proximaDe(r), estado_calc: r.estado === 'Activo' ? (proximaDe(r) ? 'Activo' : 'Finalizado') : 'Pausado' })); },
    pendientes() { return this.lista.flatMap(r => pendientesDe(r, hoy()).map(p => ({ ...p, r, key: r.id + ':' + p.periodo }))).sort((a, b) => a.fecha.localeCompare(b.fecha)); },
    columns() {
      return [
        { key: 'contacto', label: 'Contacto', link: r => this.editar(r) },
        { key: 'cuenta', label: 'Cuenta de Bancos' },
        { key: 'frecuencia_txt', label: 'Frecuencia' },
        { key: 'proxima', label: 'Próximo pago', fmt: v => v ? fecha(v) : '—' },
        { key: 'inicio', label: 'Inicio', fmt: 'date' },
        { key: 'fin', label: 'Fin', fmt: v => v ? fecha(v) : 'Indefinido' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'estado_calc', label: 'Estado', fmt: 'badge' },
      ];
    },
    totalForm() { return this.f ? this.f.lineas.reduce((s, l) => s + this.totalLinea(l), 0) : 0; },
    problemaCuenta() { return this.f ? problemaMoneda(this.f.cuenta, this.f.moneda, this.f.tipo_cambio) : ''; },
  },
  methods: {
    money, fecha,
    totalLinea(l) { return (+l.precio || 0) * (+l.cantidad || 1) * (1 + (+l.impuesto || 0) / 100); },
    nuevo() { this.f = { id: null, nombre: '', cuenta: (cuentaPrincipal(monedas.principal().codigo) || {}).nombre || (this.cuentasOpc[0] || {}).nombre || '', medio: '04', obs: '', moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), contacto_id: null, inicio: hoy(), fin: '', frecuencia: 1, lineas: [nuevaLinea(this.CUENTAS_GASTO[0])], estado: 'Activo', hechos: [], reprogramadas: {} }; this.modal = true; },
    editar(r) { this.f = JSON.parse(JSON.stringify({ ...r, lineas: (r.lineas || []).length ? r.lineas : [nuevaLinea(this.CUENTAS_GASTO[0])], hechos: r.hechos || [], reprogramadas: r.reprogramadas || {} })); this.modal = true; },
    cambioMoneda() { this.f.tipo_cambio = monedas.tc(this.f.moneda); const b = cuentaPrincipal(this.f.moneda); if (b) this.f.cuenta = b.nombre; },
    guardar() {
      const f = this.f;
      if (!f.cuenta || !f.inicio || !f.frecuencia) return toast('Complete Cuenta de Bancos, Fecha de inicio y Frecuencia', 'err');
      if (this.problemaCuenta) return toast(this.problemaCuenta, 'err');
      if (f.fin && f.fin < f.inicio) return toast('La fecha de finalización debe ser posterior a la de inicio', 'err');
      const lineas = f.lineas.filter(l => +l.precio > 0);
      if (!lineas.length) return toast('Agregue al menos un concepto con precio', 'err');
      const c = this.contactosLista.find(x => x.id == f.contacto_id);
      const reg = { ...f, frecuencia: Math.max(1, Math.round(+f.frecuencia)), lineas, contacto: c ? c.nombre : (f.contacto || ''), nombre: (f.nombre || '').trim() || (c ? c.nombre : '') || 'Pago recurrente', total: r2(this.totalForm) };
      if (!reg.id) reg.id = mock.nextId(this.lista, 'recurrentes_gastos');
      // lo registrado u omitido mientras el formulario estaba abierto (otra pestaña u otro usuario) no se pierde
      this.lista = mock.actualizar('recurrentes_gastos', l => { const lista = (l || []).filter(x => x && x.id); const ant = lista.find(x => x.id === reg.id) || {}; reg.hechos = [...new Set([...(ant.hechos || []), ...(reg.hechos || [])])]; reg.reprogramadas = { ...(ant.reprogramadas || {}), ...(reg.reprogramadas || {}) }; return [...lista.filter(x => x.id !== reg.id), reg]; }, []);
      this.modal = false; toast('Pago recurrente guardado · próximo pago ' + (proximaDe(reg) ? fecha(proximaDe(reg)) : '—'), 'ok');
    },
    marcar(r, periodo, extra) { this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).map(x => (x.id === r.id ? { ...x, hechos: [...new Set([...(x.hechos || []), periodo])], ...(extra || {}) } : x)), []); },
    // Registra el comprobante de egreso de la fecha pendiente: pago en 'pagos_gastos' (cuentas contables = conceptos) y salida en Bancos
    async registrar(p) {
      if (this.ocupado || !mock.puedeGuardar()) return;
      // contra lo guardado más reciente: si otra pestaña ya lo registró u omitió, no se repite el pago
      await mock.refrescar(['recurrentes_gastos', 'pagos_gastos'], { sinCorte: true });
      const actual = (mock.get('recurrentes_gastos', []) || []).find(x => x && x.id === p.r.id);
      if (!actual || actual.estado !== 'Activo' || (actual.hechos || []).includes(p.periodo)) { this.lista = (mock.get('recurrentes_gastos', []) || []).filter(x => x && x.id); return toast('Ese pago ya fue registrado u omitido (o la recurrencia cambió)', 'err'); }
      const r = actual, cuenta = r.cuenta, medio = r.medio || '04';
      if (!cuenta) return toast('La recurrencia no tiene cuenta de Bancos: edítela', 'err');
      const tc = r.moneda === monedas.principal().codigo ? monedas.tc(r.moneda) : (monedas.tc(r.moneda) || r.tipo_cambio);
      const prob = problemaMoneda(cuenta, r.moneda, tc); if (prob) return toast(prob, 'err');
      if (!cuentasActivas().some(b => b.nombre === cuenta)) return toast('La cuenta «' + cuenta + '» ya no existe en Bancos: edite la recurrencia', 'err');
      if (!confirm('¿Registrar el pago de «' + (r.nombre || r.contacto) + '» del ' + fecha(p.fecha) + ' por ' + money(r.total, r.moneda) + ' desde ' + cuenta + '?')) return;
      this.ocupado = true;
      try {
        const lista = mock.get('pagos_gastos', []) || [];
        const n = lista.reduce((m, x) => Math.max(m, +String(x.numero || '').replace(/\D/g, '') || 0), 0) + 1;
        const pago = { id: mock.nextId(lista, 'pagos_gastos'), numero: 'CE-' + String(n).padStart(4, '0'), contacto_id: r.contacto_id || null, contacto: r.contacto || '', fecha: p.fecha, cuenta, medio, moneda: r.moneda, tipo_cambio: tc,
          monto: r2(r.total), ref_mov: refUnica('pago_gasto'), estado: 'No conciliado', nota: 'Pago recurrente «' + (r.nombre || r.contacto) + '» · ' + p.periodo + (r.obs ? ' · ' + r.obs : ''), facturas: [],
          cuentas: (r.lineas || []).map(l => ({ concepto: l.concepto, cuenta: l.concepto, valor: +l.precio, impuesto: +l.impuesto || 0, cantidad: +l.cantidad || 1, obs: l.obs || '' })), retenciones: [], recurrente_id: r.id, periodo: p.periodo };
        const ok = await registrarMovimientoBanco(cuenta, -pago.monto, pago.fecha, 'Pago recurrente ' + pago.numero + (pago.contacto ? ' · ' + pago.contacto : ''), pago.ref_mov, false, pago.moneda, pago.tipo_cambio);
        if (!ok) return;
        mock.actualizar('pagos_gastos', l => [...(l || []), pago], []);
        this.marcar(r, p.periodo);
        toast('Pago ' + pago.numero + ' registrado por ' + money(pago.monto, pago.moneda), 'ok');
      } finally { this.ocupado = false; }
    },
    omitir(p) { if (!confirm('¿Omitir el pago del ' + fecha(p.fecha) + '? No se registrará.')) return; this.marcar(p.r, p.periodo); toast('Pago omitido', 'ok'); },
    async refrescar() { await mock.refrescar(['recurrentes_gastos']); this.lista = (mock.get('recurrentes_gastos', []) || []).filter(x => x && x.id); },
    guardarFecha() {
      if (!this.nuevaFecha) return toast('Indique la fecha', 'err');
      const p = this.posponer; this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).map(x => (x.id === p.r.id ? { ...x, reprogramadas: { ...(x.reprogramadas || {}), [p.periodo]: this.nuevaFecha } } : x)), []);
      toast('Fecha cambiada al ' + fecha(this.nuevaFecha), 'ok'); this.posponer = null;
    },
    alternar(r) { const estado = r.estado === 'Activo' ? 'Pausado' : 'Activo'; this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).map(x => (x.id === r.id ? { ...x, estado } : x)), []); toast('Pago recurrente ' + estado.toLowerCase(), 'ok'); },
    eliminar(r) { if (!confirm('¿Eliminar este pago recurrente? Los pagos ya registrados no se tocan.')) return; this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).filter(x => x.id !== r.id), []); toast('Pago recurrente eliminado', 'ok'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).filter(x => !ids.includes(x.id)), []); toast(ids.length + ' pagos recurrentes eliminados', 'ok'); },
    estadoVarios(rows, estado) { const ids = rows.map(r => r.id); this.lista = mock.actualizar('recurrentes_gastos', l => (l || []).map(x => (ids.includes(x.id) ? { ...x, estado } : x)), []); toast(rows.length + ' pagos recurrentes ' + estado.toLowerCase() + 's', 'ok'); },
    bulk() {
      return [
        { label: '⏸ Pausar', kind: 'sec', handler: rows => this.estadoVarios(rows, 'Pausado') },
        { label: '▶ Activar', kind: 'sec', handler: rows => this.estadoVarios(rows, 'Activo') },
      ];
    },
  },
  created() { this.refrescar(); },
  template: `
  <div class="page">
    <PageHead title="Pagos recurrentes" sub="Programe los pagos que se repiten cada cierto número de meses (alquiler, servicios, suscripciones). En cada fecha quedan pendientes: usted los revisa y registra el pago con un clic.">
      <button class="btn" v-if="puede('gastos')" @click="nuevo">+ Nuevo pago recurrente</button>
    </PageHead>

    <div class="card" v-if="pendientes.length">
      <h2>Pendientes de registrar <span class="badge warn">{{pendientes.length}}</span></h2>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fecha</th><th>Pago</th><th>Contacto</th><th>Cuenta de Bancos</th><th class="num">Monto</th><th></th></tr></thead>
        <tbody><tr v-for="p in pendientes" :key="p.key">
          <td><b :style="p.fecha < hoy() ? 'color:var(--danger)' : ''">{{fecha(p.fecha)}}</b><span class="small muted" v-if="p.fecha < hoy()"> · atrasado</span></td>
          <td>{{p.r.nombre || p.r.contacto || ('#' + p.r.id)}}</td><td>{{p.r.contacto || '—'}}</td><td>{{p.r.cuenta}}</td>
          <td class="num">{{money(p.r.total, p.r.moneda)}}</td>
          <td><div class="acts">
            <button class="btn sm" :disabled="ocupado" @click="registrar(p)">Registrar pago</button>
            <button class="btn sm sec" @click="posponer=p; nuevaFecha=p.fecha">Cambiar fecha</button>
            <button class="btn sm ghost" @click="omitir(p)">Omitir</button>
          </div></td>
        </tr></tbody>
      </table></div>
    </div>

    <div class="card pad0" v-if="lista.length">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar contacto o cuenta" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('gastos')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios">
        <template #actions="{row}">
          <button class="btn icon" :title="row.estado==='Activo'?'Pausar':'Activar'" @click.stop="alternar(row)">{{row.estado==='Activo'?'⏸':'▶'}}</button>
          <button class="btn icon" v-if="puede('gastos')" title="Editar" @click.stop="editar(row)">✎</button>
          <button class="btn icon" v-if="puede('gastos')" title="Eliminar" @click.stop="eliminar(row)">🗑</button>
        </template>
      </DataTable>
    </div>
    <div class="card" v-else><Empty icon="🔁" title="Aún no tienes pagos recurrentes" text="Cree un pago recurrente: en cada fecha programada aparecerá aquí como pendiente y con un clic se registra el comprobante de egreso y la salida de Bancos."><button class="btn" v-if="puede('gastos')" @click="nuevo">+ Nuevo pago recurrente</button></Empty></div>

    <Modal v-if="modal" :title="f.id?'Editar pago recurrente':'Nuevo pago recurrente'" lg @close="modal=false">
      <div class="grid cols-3">
        <Field label="Nombre" help="Por ejemplo: Alquiler de oficina"><input v-model="f.nombre"></Field>
        <Field label="Cuenta de Bancos" req><select v-model="f.cuenta"><option v-for="c in cuentasOpc" :key="c.nombre" :value="c.nombre">{{c.nombre}} · {{c.moneda}}</option></select><div class="small neg" v-if="problemaCuenta" style="margin-top:4px">{{problemaCuenta}}</div></Field>
        <Field label="Moneda"><select v-model="f.moneda" @change="cambioMoneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Contacto"><Buscador v-model="f.contacto_id" :opciones="contactosLista" detalle="numero_id" vacio="Sin contacto" agregar="contacto"></Buscador></Field>
        <Field label="Fecha de inicio" req help="Primer pago; los siguientes caen el mismo día de cada período"><input type="date" v-model="f.inicio"></Field>
        <Field label="Fecha de finalización" help="Vacío = indefinido"><input type="date" v-model="f.fin"></Field>
        <Field label="Frecuencia (meses)" req><input type="number" min="1" step="1" v-model.number="f.frecuencia"></Field>
        <Field label="Medio de pago"><select v-model="f.medio"><option value="04">Transferencia</option><option value="06">SINPE Móvil</option><option value="02">Tarjeta</option><option value="01">Efectivo</option><option value="03">Cheque</option></select></Field>
        <Field label="Observaciones"><input v-model="f.obs"></Field>
      </div>
      <h2 style="font-size:14px;margin-top:14px">Conceptos (cuentas contables del gasto)</h2>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th style="width:240px">Concepto</th><th class="num">Precio</th><th style="width:100px">Impuesto</th><th class="num" style="width:90px">Cantidad</th><th>Observaciones</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="(l,i) in f.lineas" :key="i">
          <td><select class="inp" v-model="l.concepto" style="width:100%"><option v-for="k in CUENTAS_GASTO" :key="k">{{k}}</option></select></td>
          <td><input class="inp" type="number" step="0.01" v-model.number="l.precio" style="width:100%;text-align:right"></td>
          <td><select class="inp" v-model.number="l.impuesto"><option :value="13">13 %</option><option :value="4">4 %</option><option :value="2">2 %</option><option :value="1">1 %</option><option :value="0">Exento</option></select></td>
          <td><input class="inp" type="number" step="1" v-model.number="l.cantidad" style="width:100%;text-align:right"></td>
          <td><input class="inp" v-model="l.obs" style="width:100%"></td>
          <td class="num">{{money(totalLinea(l), f.moneda)}}</td>
          <td><button class="btn icon" title="Quitar" @click="f.lineas.splice(i,1)">✕</button></td>
        </tr></tbody>
      </table></div>
      <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="f.lineas.push({concepto:CUENTAS_GASTO[0],precio:null,impuesto:13,cantidad:1,obs:''})">+ Agregar línea</button></div>
      <div class="totals"><div class="total"><span>Total</span><b>{{money(totalForm, f.moneda)}}</b></div></div>
      <template #foot><button class="btn ghost" @click="modal=false">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
    <Modal v-if="posponer" title="Cambiar fecha del pago" @close="posponer=null">
      <p class="small muted">Pago de <b>{{posponer.r.nombre || posponer.r.contacto}}</b> programado para el {{fecha(posponer.fecha)}}.</p>
      <Field label="Nueva fecha" req><input type="date" v-model="nuevaFecha"></Field>
      <template #foot><button class="btn ghost" @click="posponer=null">Cancelar</button><button class="btn" @click="guardarFecha">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy }; },
};
