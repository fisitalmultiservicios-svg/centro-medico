// Gastos › Nuevo pago (comprobante de egreso). Registro 'pagos_gastos' por empresa: primero sale el dinero de Bancos (lo registra el
// servidor, ref pago_gasto:…) y solo entonces se guarda el pago y se rebaja lo aplicado a las facturas de compra.
import { toast, money, fecha, hoy, mock, CAT, opts, monedas } from '../../api.js';
import { contactos, compras, CUENTAS_BANCARIAS } from './_datos.js';
import { planCuentas } from '../contabilidad/catalogo.js';
import { cuentaPrincipal, cuentasActivas, registrarMovimientoBanco, refUnica, problemaMoneda, avisoConversion } from '../bancos/cuentas.js';

export default {
  props: ['params'],
  data() {
    const lista = mock.get('pagos_gastos', []);
    const activas = cuentasActivas(), cuentasBanco = activas.map(b => b.nombre); const principal = cuentaPrincipal(monedas.principal().codigo);
    return {
      CUENTAS_GASTO: planCuentas().filter(c => c.hoja && ['5', '6', '1'].includes(c.raiz)).map(c => c.codigo + ' ' + c.nombre), CUENTAS_BANCARIAS: cuentasBanco.length ? cuentasBanco : CUENTAS_BANCARIAS, CAT, opts, monedasOpc: monedas.opciones(), cuentaManual: false,
      // cuentas con su moneda para el selector (si no hay cuentas en Bancos, nombres genéricos sin moneda)
      cuentasOpc: activas.length ? activas.map(b => ({ nombre: b.nombre, moneda: b.moneda || 'CRC' })) : CUENTAS_BANCARIAS.map(n => ({ nombre: n, moneda: '' })),
      tab: 'facturas', retAbierto: false, guardando: false,
      retencionesCfg: (mock.get('retenciones', []) || []).filter(r => r && r.nombre),   // Configuración › Impuestos › Retenciones
      f: { numero: 'CE-' + String(lista.reduce((m, x) => Math.max(m, +String(x.numero || '').replace(/\D/g, '') || 0), 0) + 1).padStart(4, '0'), contacto_id: null, cuenta: principal ? principal.nombre : (cuentasBanco[0] || CUENTAS_BANCARIAS[0]), fecha: hoy(), medio: '04', moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), nota: '' },
      aplicar: {}, cuentas: [], retenciones: [],
    };
  },
  computed: {
    contactosLista() { return contactos(); },
    facturas() { return compras().filter(c => c.proveedor_id == this.f.contacto_id && c.moneda === this.f.moneda && c.total - (c.pagado || 0) > 0.005).map(c => ({ ...c, por_pagar: Math.round((c.total - (c.pagado || 0)) * 100) / 100 })); },
    totalFacturas() { return this.facturas.reduce((s, c) => s + (+this.aplicar[c.id] || 0), 0); },
    totalCuentas() { return this.cuentas.reduce((s, c) => s + this.totalCuenta(c), 0); },
    totalRet() { return this.retenciones.reduce((s, r) => s + (+r.monto || 0), 0); },
    // base de las retenciones: lo pagado SIN IVA (facturas en proporción a su subtotal; cuentas por valor × cantidad)
    baseSinIva() {
      let b = 0;
      for (const c of this.facturas) { const ap = +this.aplicar[c.id] || 0; if (!ap) continue; const sub = (c.lineas || []).reduce((s, l) => s + (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0), 0); b += c.total > 0 && sub > 0 ? ap * Math.min(1, sub / c.total) : ap; }
      for (const c of this.cuentas) b += (+c.valor || 0) * (+c.cantidad || 1);
      return Math.round(b * 100) / 100;
    },
    total() { return this.totalFacturas + this.totalCuentas - this.totalRet; },
    problemaCuenta() { return problemaMoneda(this.f.cuenta, this.f.moneda, this.f.tipo_cambio); },
    avisoCuenta() { return avisoConversion(this.f.cuenta, this.total, this.f.moneda, this.f.tipo_cambio); },
  },
  watch: {
    'f.moneda'(v) {
      this.f.tipo_cambio = monedas.tc(v); this.aplicar = {};
      if (!this.cuentaManual) { const b = cuentaPrincipal(v); if (b) this.f.cuenta = b.nombre; }
    },
    'f.contacto_id'() { this.aplicar = {}; },
    // las retenciones por porcentaje siguen a lo aplicado (salvo las editadas a mano)
    aplicar: { deep: true, handler() { this.recalcularRetenciones(); } },
    cuentas: { deep: true, handler() { this.recalcularRetenciones(); } },
  },
  methods: {
    money, fecha,
    totalCuenta(c) { return (+c.valor || 0) * (+c.cantidad || 1) * (1 + (+c.impuesto || 0) / 100); },
    pagarTodo(c) { this.aplicar[c.id] = c.por_pagar; },
    agregarCuenta() { this.cuentas.push({ concepto: this.CUENTAS_GASTO.find(c => /gastos generales/i.test(c)) || this.CUENTAS_GASTO[0], valor: null, impuesto: 13, cantidad: 1, obs: '' }); },
    agregarRetencion() { const c = this.retencionesCfg[0]; this.retenciones.push(c ? { nombre: c.nombre + ' (' + (+c.porcentaje || 0) + ' %)', pct: +c.porcentaje || 0, monto: this.montoRetencion(+c.porcentaje || 0) } : { nombre: 'Retención 2 % renta', pct: 2, monto: this.montoRetencion(2) }); },
    montoRetencion(pct) { return Math.round(this.baseSinIva * (+pct || 0)) / 100; },   // sobre lo pagado sin IVA
    recalcularRetenciones() { for (const r of this.retenciones) if (!r.manual && +r.pct > 0) r.monto = this.montoRetencion(r.pct); },
    elegirRetencion(r, ev) { const c = this.retencionesCfg.find(x => x.nombre === ev.target.value); if (c) { r.nombre = c.nombre + ' (' + (+c.porcentaje || 0) + ' %)'; r.pct = +c.porcentaje || 0; r.manual = false; r.monto = this.montoRetencion(r.pct); } },
    async guardar() {
      if (this.guardando || !mock.puedeGuardar()) return;               // antes de mover el banco: si no, el pago quedaba sin guardar
      if (!cuentasActivas().length) return toast('Cree primero la cuenta en Bancos › Bancos y cajas (por ejemplo «Caja general» o la cuenta del banco) para registrar pagos', 'err');
      if (!this.f.cuenta) return toast('Seleccione la cuenta bancaria', 'err');
      if (this.retenciones.some(r => !(+r.monto > 0))) return toast('Hay una retención sin monto: indíquelo o quítela', 'err');
      if (this.problemaCuenta) return toast(this.problemaCuenta, 'err');
      if (!this.f.fecha) return toast('Indique la fecha', 'err');
      for (const c of this.facturas) if (+this.aplicar[c.id] > c.por_pagar + 0.005) return toast(`El monto aplicado a ${c.numero} supera su saldo por pagar (${money(c.por_pagar, c.moneda)})`, 'err');   // (R175)
      const facturasAp = this.facturas.filter(c => +this.aplicar[c.id] > 0).map(c => ({ compra_id: c.id, monto: Math.min(+this.aplicar[c.id], c.por_pagar) }));
      const cuentasOk = this.cuentas.filter(c => +c.valor > 0);
      if (!facturasAp.length && !cuentasOk.length) return toast('Aplique el pago a una factura o agregue una cuenta contable', 'err');
      if (this.total <= 0) return toast('El monto del pago debe ser mayor que cero', 'err');
      const contacto = this.contactosLista.find(c => c.id == this.f.contacto_id);
      this.guardando = true;
      try {
        await mock.refrescar(['pagos_gastos', 'compras'], { sinCorte: true });     // lo último que guardaron otros usuarios antes de numerar y aplicar
        const lista = mock.get('pagos_gastos', []) || [];
        // número sobre lo guardado más reciente (otra persona pudo registrar un pago mientras tanto)
        const usado = lista.some(x => x.numero === this.f.numero), n = lista.reduce((m, x) => Math.max(m, +String(x.numero || '').replace(/\D/g, '') || 0), 0) + 1;
        const numero = usado || !this.f.numero ? 'CE-' + String(n).padStart(4, '0') : this.f.numero;
        const pago = { id: mock.nextId(lista, 'pagos_gastos'), numero, contacto_id: contacto?.id || null, contacto: contacto?.nombre || '', fecha: this.f.fecha, cuenta: this.f.cuenta, medio: this.f.medio, moneda: this.f.moneda, tipo_cambio: this.f.tipo_cambio,
          monto: Math.round(this.total * 100) / 100, ref_mov: refUnica('pago_gasto'), estado: 'No conciliado', nota: this.f.nota, facturas: facturasAp, cuentas: cuentasOk.map(c => ({ ...c, cuenta: c.concepto })), retenciones: this.retenciones.filter(r => +r.monto > 0).map(r => ({ nombre: r.nombre, pct: +r.pct || 0, monto: +r.monto })) };
        // 1) sale el dinero de Bancos (lo valida y convierte el servidor); si falla, no se guarda el pago
        const ok = await registrarMovimientoBanco(pago.cuenta, -pago.monto, pago.fecha, 'Pago a proveedor ' + pago.numero + (pago.contacto ? ' · ' + pago.contacto : ''), pago.ref_mov, false, pago.moneda, pago.tipo_cambio);
        if (!ok) return;
        // 2) el pago y lo aplicado a cada factura, sobre lo guardado más reciente
        mock.actualizar('pagos_gastos', l => [...(l || []), pago], []);
        if (facturasAp.length) mock.actualizar('compras', todas => { for (const a of facturasAp) { const c = (todas || []).find(x => x.id === a.compra_id); if (c) c.pagado = Math.round(((c.pagado || 0) + a.monto) * 100) / 100; } return todas; }, []);
        toast('Pago ' + pago.numero + ' registrado por ' + money(pago.monto, pago.moneda), 'ok');
        location.hash = '/gastos/pagos';
      } finally { this.guardando = false; }
    },
  },
  created() {
    if (this.params.compra) {
      const c = compras().find(x => x.id == this.params.compra);
      if (c) { this.f.contacto_id = c.proveedor_id; this.f.moneda = c.moneda; this.$nextTick(() => { this.aplicar = { [c.id]: Math.round((c.total - (c.pagado || 0)) * 100) / 100 }; }); }
    }
  },
  template: `
  <div class="page">
    <PageHead title="Nuevo pago" sub="Comprobante de egreso: pago de facturas de compra o gastos directos desde una cuenta de Bancos." :crumbs="[{label:'Pagos',to:'/gastos/pagos'},{label:'Nuevo'}]"></PageHead>
    <div class="alert info">Para trasladar dinero entre tus cuentas bancarias, utiliza <a href="#/bancos">Transferencias bancarias</a> en el módulo de Bancos.</div>
    <div class="card"><h2>Información general</h2>
      <div class="grid cols-3">
        <Field label="No."><input v-model="f.numero"></Field>
        <Field label="Contacto"><Buscador v-model="f.contacto_id" :opciones="contactosLista" detalle="numero_id" vacio="Sin contacto" agregar="contacto"></Buscador></Field>
        <Field label="Cuenta bancaria" req help="Por defecto la cuenta principal de la moneda del pago (Bancos); puede elegir otra"><select v-model="f.cuenta" @change="cuentaManual=true"><option v-for="c in cuentasOpc" :key="c.nombre" :value="c.nombre">{{c.nombre}}{{c.moneda ? ' · ' + c.moneda : ''}}</option></select><div class="small" :class="problemaCuenta ? 'neg' : 'muted'" v-if="problemaCuenta || avisoCuenta" style="margin-top:4px">{{problemaCuenta || avisoCuenta}}</div></Field>
        <Field label="Fecha" req><input type="date" v-model="f.fecha"></Field>
        <Field label="Medio de pago"><select v-model="f.medio"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="Moneda" req><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda + ' (el del sistema; cámbielo si aplica otro)'"><input type="number" step="0.01" v-model.number="f.tipo_cambio"></Field>
        <Field label="Nota de egreso" style="grid-column:1/-1"><textarea rows="2" v-model="f.nota" placeholder="Detalle del pago"></textarea></Field>
      </div>
    </div>
    <div class="card">
      <div class="seg" style="margin-bottom:14px"><button :class="{on:tab==='facturas'}" @click="tab='facturas'">Facturas de compra</button><button :class="{on:tab==='cuentas'}" @click="tab='cuentas'">Cuentas contables</button></div>
      <div v-if="tab==='facturas'">
        <p class="small muted" v-if="!f.contacto_id">Selecciona un contacto para ver sus facturas por pagar en {{f.moneda}}.</p>
        <div class="table-wrap" v-else-if="facturas.length"><table class="tbl">
          <thead><tr><th>Número</th><th>Creación</th><th>Vencimiento</th><th class="num">Total</th><th class="num">Por pagar</th><th class="num" style="width:160px">Monto a aplicar</th><th></th></tr></thead>
          <tbody><tr v-for="c in facturas" :key="c.id">
            <td class="mono">{{c.numero}}</td><td>{{fecha(c.creacion)}}</td><td>{{fecha(c.vencimiento)}}</td>
            <td class="num">{{money(c.total, c.moneda)}}</td><td class="num">{{money(c.por_pagar, c.moneda)}}</td>
            <td><input class="inp" type="number" step="0.01" min="0" :max="c.por_pagar" v-model.number="aplicar[c.id]" style="width:100%;text-align:right"></td>
            <td><button class="btn sm ghost" @click="pagarTodo(c)">Pagar todo</button></td>
          </tr></tbody>
        </table></div>
        <Empty v-else icon="✓" title="Sin facturas por pagar" text="Este contacto no tiene facturas de compra pendientes en esta moneda."></Empty>
      </div>
      <div v-else>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th style="width:260px">Concepto</th><th class="num">Valor</th><th style="width:110px">Impuesto</th><th class="num" style="width:90px">Cantidad</th><th>Observaciones</th><th class="num">Total</th><th></th></tr></thead>
          <tbody><tr v-for="(c,i) in cuentas" :key="i">
            <td><select class="inp" v-model="c.concepto" style="width:100%"><option v-for="k in CUENTAS_GASTO" :key="k">{{k}}</option></select></td>
            <td><input class="inp" type="number" step="0.01" v-model.number="c.valor" style="width:100%;text-align:right"></td>
            <td><select class="inp" v-model.number="c.impuesto"><option :value="13">13 %</option><option :value="4">4 %</option><option :value="2">2 %</option><option :value="1">1 %</option><option :value="0">Exento</option></select></td>
            <td><input class="inp" type="number" step="1" v-model.number="c.cantidad" style="width:100%;text-align:right"></td>
            <td><input class="inp" v-model="c.obs" style="width:100%"></td>
            <td class="num">{{money(totalCuenta(c), f.moneda)}}</td>
            <td><button class="btn icon" title="Quitar" @click="cuentas.splice(i,1)">✕</button></td>
          </tr></tbody>
        </table></div>
        <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="agregarCuenta">+ Agregar cuenta contable</button></div>
      </div>
      <div style="margin-top:16px;border-top:1px solid var(--line);padding-top:10px">
        <a class="link" @click="retAbierto=!retAbierto">{{retAbierto?'▾':'▸'}} Retenciones</a>
        <div v-if="retAbierto" style="margin-top:8px">
          <div class="table-wrap" v-if="retenciones.length"><table class="tbl"><thead><tr><th>Retención</th><th class="num" style="width:160px">Monto</th><th></th></tr></thead>
            <tbody><tr v-for="(r,i) in retenciones" :key="i"><td><div class="row" style="gap:6px"><select class="inp" v-if="retencionesCfg.length" @change="elegirRetencion(r, $event)" style="width:46%"><option value="">Configuradas…</option><option v-for="c in retencionesCfg" :key="c.id" :value="c.nombre">{{c.nombre}} · {{c.porcentaje}} %</option></select><input class="inp" v-model="r.nombre" style="flex:1"></div></td><td><input class="inp" type="number" step="0.01" min="0" v-model.number="r.monto" @input="r.manual=true" style="width:100%;text-align:right"></td><td><button class="btn icon" title="Quitar" @click="retenciones.splice(i,1)">✕</button></td></tr></tbody></table></div>
          <p class="small muted" style="margin:6px 0 0">El monto se calcula con el porcentaje sobre lo pagado sin IVA y se actualiza al cambiar facturas o cuentas; si lo edita a mano, queda fijo.</p>
          <button class="btn sec sm" @click="agregarRetencion">+ Agregar retención</button><span class="small muted" style="margin-left:10px" v-if="!retencionesCfg.length">Puede definir las retenciones habituales en Configuración › Impuestos › Retenciones.</span>
        </div>
      </div>
      <div class="totals">
        <div><span>Facturas aplicadas</span><b>{{money(totalFacturas, f.moneda)}}</b></div>
        <div><span>Cuentas contables</span><b>{{money(totalCuentas, f.moneda)}}</b></div>
        <div v-if="totalRet"><span>Retenciones</span><b>-{{money(totalRet, f.moneda)}}</b></div>
        <div class="total"><span>Total del pago</span><b>{{money(total, f.moneda)}}</b></div>
      </div>
    </div>
    <div class="row end" style="margin-bottom:18px"><a class="btn ghost" href="#/gastos/pagos">Cancelar</a><button class="btn" :disabled="guardando" @click="guardar">{{guardando ? 'Guardando…' : 'Guardar'}}</button></div>
  </div>`,
};
