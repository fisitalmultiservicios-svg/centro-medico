// Gastos › Órdenes de compra — lista (datos de ejemplo en mock 'ordenes'; PDF real con POST /api/pdf/documento)
import { toast, money, fecha, mock } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';
import { ordenes, payloadOrdenCompra } from './_datos.js';
import { abrirPdfDocumento } from '../ventas/cotizaciones.js';

export default {
  props: ['params'],
  data() { return { lista: ordenes(), q: '', ver: null }; },
  computed: {
    rows() { return this.lista.slice().sort((a, b) => b.fecha.localeCompare(a.fecha)); },
    columns() {
      return [
        { key: 'codigo', label: 'Código', mono: true, link: r => this.ver = r },
        { key: 'proveedor', label: 'Contacto' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'entrega', label: 'Fecha de entrega', fmt: 'date' },
        { key: 'plazo', label: 'Plazo de pago' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
      ];
    },
  },
  methods: {
    money, fecha,
    convertir(o) { if (o.estado === 'Cerrada') return toast('La orden está cerrada'); location.hash = '/gastos/compras/nueva?orden=' + o.id; },
    async pdf(o, descargar) { try { await abrirPdfDocumento(payloadOrdenCompra(o), descargar ? o.codigo + '.pdf' : null); } catch (e) { toast(e.message, 'err'); } },
    cerrar(o) { const x = this.lista.find(y => y.id === o.id); x.estado = x.estado === 'Cerrada' ? 'Abierta' : 'Cerrada'; mock.set('ordenes', this.lista); toast('Orden ' + x.codigo + ' ' + x.estado.toLowerCase(), 'ok'); },
    eliminar(o) { if (!confirm('¿Eliminar la orden de compra ' + o.codigo + '?')) return; this.lista = this.lista.filter(x => x.id !== o.id); mock.set('ordenes', this.lista); this.ver = null; toast('Orden eliminada', 'ok'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = this.lista.filter(x => !ids.includes(x.id)); mock.set('ordenes', this.lista); toast(ids.length + ' órdenes eliminadas', 'ok'); },
    estadoVarios(rows, estado) { for (const r of rows) { const x = this.lista.find(y => y.id === r.id); if (x) x.estado = estado; } mock.set('ordenes', this.lista); toast(rows.length + ' órdenes ' + estado.toLowerCase() + 's', 'ok'); },
    bulk() {
      return [
        { label: '⊘ Cerrar', kind: 'sec', confirm: '¿Cerrar {n} órdenes de compra?', handler: rows => this.estadoVarios(rows, 'Cerrada') },
        { label: '↺ Reabrir', kind: 'sec', handler: rows => this.estadoVarios(rows, 'Abierta') },
      ];
    },
    exportar() {
      exportarFilas('ordenes-compra', ['Código', 'Contacto', 'Fecha', 'Fecha de entrega', 'Plazo de pago', 'Estado', 'Moneda', 'Total'], this.rows.map(o => [o.codigo, o.proveedor, o.fecha, o.entrega, o.plazo, o.estado, o.moneda, o.total]), { titulo: 'Órdenes de compra', num: [7] });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Órdenes de compra" sub="Solicita productos o servicios a tus proveedores. Las órdenes de compra no afectan el inventario ni la contabilidad hasta convertirlas en factura de compra.">
      <button class="btn ghost" @click="exportar">Exportar</button>
      <a class="btn" v-if="puede('gastos')" href="#/gastos/ordenes/nueva">+ Nueva orden de compra</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar contacto o código" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('gastos')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado órdenes de compra" empty-text="Crea una orden de compra y conviértela en factura cuando recibas la mercadería.">
        <template #actions="{row}">
          <button class="btn icon" title="Ver" @click.stop="ver=row">👁</button>
          <a class="btn icon" v-if="puede('gastos')" :href="'#/gastos/ordenes/nueva?duplicar=' + row.id" @click.stop title="Duplicar: nueva orden con el mismo proveedor y las mismas líneas">⧉</a>
          <button class="btn sm sec" v-if="row.estado!=='Cerrada'" @click.stop="convertir(row)">Convertir en factura de compra</button>
          <button class="btn icon" title="Ver PDF" @click.stop="pdf(row)">⎙</button>
          <button class="btn icon" :title="row.estado==='Cerrada'?'Reabrir':'Cerrar orden'" @click.stop="cerrar(row)">{{row.estado==='Cerrada'?'↺':'⊘'}}</button>
          <button class="btn icon" v-if="puede('gastos')" title="Eliminar" @click.stop="eliminar(row)">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('gastos')" href="#/gastos/ordenes/nueva">+ Nueva orden de compra</a></template>
      </DataTable>
    </div>
    <Modal v-if="ver" :title="'Orden de compra ' + ver.codigo" lg @close="ver=null">
      <div class="grid cols-3" style="margin-bottom:12px">
        <div><div class="small muted">Contacto</div><b>{{ver.proveedor}}</b></div><div><div class="small muted">Fecha</div><b>{{fecha(ver.fecha)}}</b></div><div><div class="small muted">Fecha de entrega</div><b>{{fecha(ver.entrega)}}</b></div>
        <div><div class="small muted">Plazo de pago</div><b>{{ver.plazo}}</b></div><div><div class="small muted">Estado</div><Badge :value="ver.estado"></Badge></div><div><div class="small muted">Total</div><b>{{money(ver.total, ver.moneda)}}</b></div>
      </div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Detalle</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">IVA</th></tr></thead>
        <tbody><tr v-for="(l,i) in ver.lineas" :key="i"><td>{{l.detalle}}</td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio_unitario, ver.moneda)}}</td><td class="num">{{l.tarifa}} %</td></tr></tbody></table></div>
      <p class="small muted" v-if="ver.notas" style="margin-top:10px">{{ver.notas}}</p>
      <template #foot><button class="btn ghost" @click="ver=null">Cerrar</button><button class="btn sec" @click="pdf(ver, true)">Descargar PDF</button><button class="btn" v-if="ver.estado!=='Cerrada'" @click="convertir(ver)">Convertir en factura de compra</button></template>
    </Modal>
  </div>`,
};
