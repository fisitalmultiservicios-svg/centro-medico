// Gastos › Rectificaciones (4.23) — solo lectura. Compras y gastos de meses pasados que se eliminaron, se volvieron a registrar o
// cambiaron de clasificación. El registro 'gastos_rectificaciones' lo escribe solo el servidor (al eliminar, registrar de nuevo o
// reclasificar un documento cuya fecha cae en un mes anterior al mes en curso); aquí no se edita ni se borra nada.
import { money, fecha, fechaHora, hoy, mock, toast } from '../../api.js';
import { descargarTabla } from '../reportes/_montos.js';
import { mesLegible, resumenRectificaciones, ACCION, NOMBRE_TIPO } from './_registro.js';

const leer = () => { const v = mock.get('gastos_rectificaciones', []); return (Array.isArray(v) ? v : []).filter(x => x && typeof x === 'object'); };
// el periodo contable de ese mes HOY (Configuración › Periodos contables): true cerrado, false abierto, null si este rol no lo puede leer
function periodoCerradoHoy(mes) {
  const m = /^(\d{4})-(\d{2})$/.exec(String(mes || '')); if (!m) return null;
  const per = mock.get('periodos_' + m[1], null); if (!Array.isArray(per)) return null;
  const p = per.find(x => x && +x.n === +m[2]);
  return !!p && p.estado === 'Cerrado';
}

export default {
  props: ['params'],
  data() { return { lista: leer(), mes: '', accion: '', q: '', hoy: hoy(), ACCION }; },
  computed: {
    meses() { return [...new Set(this.lista.map(x => x.mes).filter(Boolean))].sort().reverse(); },
    filtradas() { return this.lista.filter(x => (!this.mes || x.mes === this.mes) && (!this.accion || x.accion === this.accion)); },
    rows() {
      return this.filtradas.map(x => {
        // el estado de HOY del periodo contable de ese mes (pudo cerrarse o reabrirse después de anotarla); si este rol no puede leer
        // los periodos, el que tenía al anotarla. Mientras esté cerrado, el asiento de ese mes no se toca y la contabilidad registra
        // el reverso (o el ajuste) en el mes en curso (asiento automático aj:, Contabilidad)
        const hoyC = periodoCerradoHoy(x.mes), cerrado = hoyC === null ? !!x.periodo_cerrado : hoyC;
        // el cambio de cuenta contable también es una reclasificación: se ve junto al tipo (vacío = la de su clasificación)
        const cuentas = x.accion === 'reclasificado' && (x.cuenta_anterior !== undefined || x.cuenta_nueva !== undefined) ? ' · cuenta: ' + (x.cuenta_anterior || 'la de su clasificación') + ' → ' + (x.cuenta_nueva || 'la de su clasificación') : '';
        return { id: x.id, fecha: x.fecha, usuario: x.usuario || '', accion: ACCION[x.accion] || x.accion || '',
          tipo: (x.accion === 'reclasificado' && x.tipo_anterior ? (NOMBRE_TIPO[x.tipo_anterior] || x.tipo_anterior) + ' → ' + (NOMBRE_TIPO[x.tipo] || x.tipo) : (NOMBRE_TIPO[x.tipo] || x.tipo || '')) + cuentas,
          documento: (x.documento || '') + (x.tipo_documento === '03' ? ' (nota de crédito)' : ''), proveedor: (x.proveedor || '—') + (x.proveedor_identificacion ? ' · ' + x.proveedor_identificacion : ''),
          fecha_documento: x.fecha_documento, mes: mesLegible(x.mes), moneda: x.moneda || 'CRC', total: +x.total || 0, iva: +x.iva_acreditar || 0, motivo: x.motivo || '',
          // lo eliminado deja un reverso; lo reclasificado o registrado de nuevo, un ajuste
          periodo: !cerrado ? 'Abierto' : (x.accion === 'eliminado' ? 'Cerrado: el reverso queda en el mes en curso' : 'Cerrado: el ajuste queda en el mes en curso') };
      }).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || (+b.id || 0) - (+a.id || 0));
    },
    // La tabla de PANTALLA debe caber en 1366 px de ancho sin desplazarse a los lados: la fecha y el usuario van en una sola columna,
    // la fecha del documento queda solo en las exportaciones (el mes afectado ya está) y los textos largos se parten en renglones
    // (clase de celda 'parte'; con 'fina' la columna cede más ancho y un correo largo también se parte). El número del documento no
    // se parte. El periodo va como texto: una insignia no se parte.
    columns() {
      return [
        { key: 'fecha', label: 'Fecha y usuario', fmt: (v, r) => fechaHora(v) + (r.usuario ? ' · ' + r.usuario : ''), class: 'parte fina' },
        { key: 'accion', label: 'Acción', fmt: 'badge' },
        { key: 'tipo', label: 'Tipo', class: 'parte fina' },
        { key: 'documento', label: 'Documento', mono: true, class: 'parte' },
        { key: 'proveedor', label: 'Proveedor', class: 'parte fina' },
        { key: 'mes', label: 'Mes afectado' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'iva', label: 'IVA', num: true, fmt: 'money' },
        { key: 'motivo', label: 'Motivo', class: 'parte fina' },
        { key: 'periodo', label: 'Periodo contable', class: 'parte fina' },
      ];
    },
    // las exportaciones siguen completas: cada dato en su columna, con la fecha del documento y la moneda
    columnasExportar() {
      return [
        { key: 'fecha', label: 'Fecha', fmt: v => fechaHora(v), csv: v => fechaHora(v) },
        { key: 'usuario', label: 'Usuario' },
        { key: 'accion', label: 'Acción', fmt: 'badge' },
        { key: 'tipo', label: 'Tipo' },
        { key: 'documento', label: 'Documento', mono: true },
        { key: 'proveedor', label: 'Proveedor' },
        { key: 'fecha_documento', label: 'Fecha del documento', fmt: 'date' },
        { key: 'mes', label: 'Mes afectado' },
        { key: 'moneda', label: 'Moneda' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'iva', label: 'IVA', num: true, fmt: 'money' },
        { key: 'motivo', label: 'Motivo' },
        { key: 'periodo', label: 'Periodo contable', fmt: 'badge' },
      ];
    },
    // por mes afectado: cuántas, y el total y el IVA que salieron (lo eliminado) y que entraron (lo vuelto a registrar), en colones
    resumen() { return resumenRectificaciones(this.filtradas).map(x => ({ ...x, nombre: mesLegible(x.mes) })); },
    colsResumen() {
      return [
        { key: 'nombre', label: 'Mes afectado' }, { key: 'cuantas', label: 'Rectificaciones', num: true },
        { key: 'eliminados', label: 'Eliminados', num: true }, { key: 'salio_total', label: 'Salió: total', num: true, fmt: 'money' }, { key: 'salio_iva', label: 'Salió: IVA', num: true, fmt: 'money' },
        { key: 'registrados', label: 'Registrados de nuevo', num: true }, { key: 'entro_total', label: 'Entró: total', num: true, fmt: 'money' }, { key: 'entro_iva', label: 'Entró: IVA', num: true, fmt: 'money' },
        { key: 'reclasificados', label: 'Cambios de clasificación', num: true },
      ];
    },
  },
  methods: {
    money, fecha, mesLegible,
    periodoTexto() { return (this.mes ? 'Mes afectado: ' + mesLegible(this.mes) : 'Todos los meses') + (this.accion ? ' · ' + ACCION[this.accion] : '') + ' · al ' + fecha(this.hoy); },
    // toda lista se exporta en PDF, Excel y CSV (4.17)
    exportar(formato) {
      if (!this.rows.length) return toast('No hay datos para exportar');
      return descargarTabla(formato, 'rectificaciones', this.columnasExportar, this.rows, { titulo: 'Rectificaciones de compras y gastos', periodo: this.periodoTexto() });
    },
    exportarResumen(formato) {
      if (!this.resumen.length) return toast('No hay datos para exportar');
      return descargarTabla(formato, 'rectificaciones_por_mes', this.colsResumen, this.resumen, { titulo: 'Rectificaciones por mes afectado (en colones)', periodo: this.periodoTexto() });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Rectificaciones" sub="Compras y gastos de meses pasados que se eliminaron, se volvieron a registrar o cambiaron de clasificación. Si ya presentó la declaración de ese mes, debe rectificarla.">
      <button class="btn sec" :disabled="!rows.length" @click="exportar('pdf')">⤓ PDF</button>
      <button class="btn sec" :disabled="!rows.length" @click="exportar('xlsx')">⤓ Excel</button>
      <button class="btn sec" :disabled="!rows.length" @click="exportar('csv')">⤓ CSV</button>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0;gap:10px;flex-wrap:wrap">
        <input class="search" placeholder="Buscar documento, proveedor, usuario o motivo" v-model="q">
        <select class="inp" v-model="mes" title="Mes afectado"><option value="">Todos los meses</option><option v-for="m in meses" :key="m" :value="m">{{mesLegible(m)}}</option></select>
        <select class="inp" v-model="accion" title="Acción"><option value="">Todas las acciones</option><option v-for="(n,k) in ACCION" :key="k" :value="k">{{n}}</option></select>
      </div>
      <DataTable :rows="rows" :columns="columns" :search="q" :page-size="20" empty-title="No hay rectificaciones" empty-text="Aquí queda anotado, sin que nadie tenga que escribirlo, cuando se elimina, se vuelve a registrar o se cambia de compra a gasto un documento de un mes anterior al mes en curso. Lo del mes en curso no es una rectificación."></DataTable>
    </div>
    <div class="card pad0" v-if="resumen.length">
      <div class="row" style="padding:12px;gap:8px;flex-wrap:wrap"><h2 style="margin:0;flex:1">Resumen por mes afectado <small>en colones</small></h2>
        <button class="btn sm sec" @click="exportarResumen('pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportarResumen('xlsx')">⤓ Excel</button><button class="btn sm sec" @click="exportarResumen('csv')">⤓ CSV</button></div>
      <DataTable :rows="resumen" :columns="colsResumen" :page-size="20"></DataTable>
      <p class="small muted" style="padding:0 12px 12px;margin:0">«Salió» es lo eliminado (dejó de contar en los reportes de ese mes) y «Entró» lo que se volvió a registrar. Un cambio de clasificación no cambia el total del mes: pasa de compra a gasto o al revés.</p>
    </div>
  </div>`,
};
