// Reportes — lista de reportes de una categoría (params.cat). Catálogo estático; favoritos en localStorage.
import { mock, toast } from '../../api.js';
import { CATALOGO, claveUsuario, puedeCategoria, puedeReporte, reportesDe, MODULO_REPORTES, reportesModulo } from './hub.js';

export default {
  props: ['params'],
  data() { return { q: '', favoritos: mock.get(claveUsuario('reportes_favoritos'), []) }; },
  computed: {
    cat() { return this.params.cat; },
    esFavoritos() { return this.cat === 'favoritos'; },
    modulo() { return String(this.cat || '').startsWith('de-') ? this.cat.slice(3) : null; },   // 4.1: reportes de un módulo
    categoria() { if (this.modulo && MODULO_REPORTES[this.modulo]) return { nombre: 'Reportes de ' + MODULO_REPORTES[this.modulo].nombre, ico: '▤', desc: 'Los reportes que corresponden a ' + MODULO_REPORTES[this.modulo].nombre.toLowerCase() + '.' }; return CATALOGO[this.cat] || null; },
    titulo() { return this.esFavoritos ? 'Favoritos' : (this.categoria ? this.categoria.nombre : 'Categoría no encontrada'); },
    permitida() { return this.modulo ? !!MODULO_REPORTES[this.modulo] : puedeCategoria(this.cat); },
    reportes() {
      let lista;
      // 3.87: solo los reportes cuyos datos el servidor le entrega a este rol (antes se listaba la categoría completa)
      if (this.esFavoritos) lista = this.favoritos.map(f => { const r = (CATALOGO[f.cat] || { reportes: [] }).reportes.find(x => x.slug === f.slug); return r && puedeReporte(f.cat, f.slug) ? { cat: f.cat, ...r } : null; }).filter(Boolean);
      else if (this.modulo) lista = reportesModulo(this.modulo);
      else lista = reportesDe(this.cat).map(r => ({ cat: this.cat, ...r }));
      const q = this.q.trim().toLowerCase();
      return q ? lista.filter(r => (r.nombre + ' ' + r.desc).toLowerCase().includes(q)) : lista;
    },
  },
  methods: {
    ir(r) { location.hash = r.ruta || `/reportes/${r.cat}/${r.slug}`; },   // 4.9: los que tienen pantalla propia (Revendedoras, Estado de cuenta de revendedora)
    esFav(r) { return this.favoritos.some(f => f.cat === r.cat && f.slug === r.slug); },
    toggleFav(r) {
      const i = this.favoritos.findIndex(f => f.cat === r.cat && f.slug === r.slug);
      if (i >= 0) { this.favoritos.splice(i, 1); toast('Quitado de favoritos'); } else { this.favoritos.push({ cat: r.cat, slug: r.slug }); toast('Agregado a favoritos', 'ok'); }
      mock.set(claveUsuario('reportes_favoritos'), this.favoritos);
    },
  },
  template: `
  <div class="page" v-if="!permitida"><div class="card"><Empty icon="🔒" title="Sin acceso a esta categoría" text="Su rol no tiene permiso sobre el módulo de estos reportes."><a class="btn sec" href="#/reportes">Volver a Reportes</a></Empty></div></div>
  <div class="page" v-else>
    <PageHead :title="titulo" :sub="categoria ? categoria.desc : (esFavoritos ? 'Los reportes que marque con estrella aparecerán aquí.' : '')" :crumbs="[{label:'Reportes',to:'/reportes'},{label:titulo}]">
      <a class="btn ghost" href="#/reportes">← Todas las categorías</a>
    </PageHead>
    <div class="card" v-if="!categoria && !esFavoritos">
      <Empty icon="⚠" title="Categoría no encontrada" text="La categoría indicada no existe."><a class="btn" href="#/reportes">Ir a reportes</a></Empty>
    </div>
    <template v-else>
      <div class="toolbar"><input class="search" placeholder="Buscar en esta categoría" v-model="q"><span class="muted small">{{reportes.length}} reporte(s)</span></div>
      <Empty v-if="!reportes.length" icon="★" :title="esFavoritos ? 'Aún no tiene favoritos' : 'Sin resultados'" :text="esFavoritos ? 'Abra cualquier categoría y marque la estrella de los reportes que más use.' : 'Pruebe con otro término.'"></Empty>
      <div class="tiles" v-else>
        <a class="tile" v-for="r in reportes" :key="r.cat+r.slug" @click="ir(r)">
          <div class="row" style="justify-content:space-between;align-items:flex-start"><h3>{{r.nombre}}</h3><button class="btn icon" :title="esFav(r)?'Quitar de favoritos':'Marcar como favorito'" @click.stop="toggleFav(r)">{{esFav(r)?'★':'☆'}}</button></div>
          <p>{{r.desc}}</p>
          <div class="links"><span class="badge" v-if="esFavoritos || modulo">{{CATALOGO[r.cat]?.nombre}}</span><span class="small muted">Ver reporte →</span></div>
        </a>
      </div>
    </template>
  </div>`,
  setup() { return { CATALOGO }; },
};
