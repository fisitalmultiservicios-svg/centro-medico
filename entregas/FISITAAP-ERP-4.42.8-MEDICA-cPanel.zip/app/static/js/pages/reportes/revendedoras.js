// 4.9: Contactos › Revendedoras y saldos. Cada revendedora o cliente con crédito (límite, pedidos en línea, acceso al catálogo o saldo
// abierto) con su límite, saldo, vencido, lo comprometido en pedidos, disponible, cantidad de pedidos y el último. No vive bajo
// /reportes ni pide el módulo Reportes (Comercio y Restaurante con Ventas en línea lo usan sin él); aparece en el catálogo de Reportes
// (hub.js, con «ruta»). Datos de GET /api/revendedoras; montos en la moneda principal (cada documento con su tipo de cambio).
// Consulta: ?q=texto&saldo=1 (solo con saldo)&pedidos=1 (solo con pedidos).
import { api, toast, money, fmt, fecha, hoy } from '../../api.js';
import { store } from '../../app.js';
import { descargarReporte, descargarExcel, imprimirReporte, impresorasReporte, principal, descargarTabla } from './_montos.js';
// 9c (J4): el aviso de una impresión que no salió, con la ayuda común de pos/_agente.js (se carga al usarla, como el resto de la impresión de esta pantalla)
async function avisoImpresion(prefijo, e) { try { const A = await import('../pos/_agente.js'); if (A.avisoImpresion) return A.avisoImpresion(prefijo, e); } catch { /* como antes */ } return prefijo + ((e && e.message) || ''); }
import { buscarReporte, registrarReciente, puedeReporte } from './hub.js';
import { telefonoWa, enlaceWhatsApp, textoEstadoCuenta, estadoSaldo } from './_revendedoras.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const TOPE = 2000;   // el servidor entrega hasta 2.000; con más, la búsqueda se le pide a él

export default {
  props: ['params'],
  data() {
    const p = this.params || {};
    return { filas: [], cargando: true, error: '', q: String(p.q || ''), soloSaldo: p.saldo === '1', soloPedidos: p.pedidos === '1', impSel: '', impresorasLista: impresorasReporte(), moneda: principal(), tope: false, qServidor: '', timer: null, seq: 0 };
  },
  computed: {
    empresaNombre() { const e = store.empresa || {}; return e.nombre_comercial || e.nombre || ''; },
    vista() {
      const q = this.q.trim().toLowerCase(), partes = q.split(/\s+/).filter(Boolean);
      return this.filas.filter(x => (!this.soloSaldo || x.saldo > 0.009) && (!this.soloPedidos || x.pedidos > 0)
        && (!partes.length || partes.every(t => [x.nombre, x.identificacion, x.telefono, x.correo, x.lista].join(' ').toLowerCase().includes(t))));
    },
    suma() { const s = k => r2(this.vista.reduce((a, x) => a + (+x[k] || 0), 0)); return { saldo: s('saldo'), vencido: s('vencido'), en_pedidos: s('en_pedidos'), disponible: r2(this.vista.filter(x => x.limite > 0).reduce((a, x) => a + (+x.disponible || 0), 0)), limite: s('limite'), pedidos: s('pedidos'), total_pedidos: s('total_pedidos') }; },
    kpis() {
      const m = v => money(v, this.moneda), s = this.suma;
      return [{ t: 'Revendedoras', v: String(this.vista.length) }, { t: 'Saldo por cobrar', v: m(s.saldo) }, { t: 'Vencido', v: m(s.vencido) }, { t: 'En pedidos por facturar', v: m(s.en_pedidos) }, { t: 'Crédito disponible', v: m(s.disponible) }, { t: 'Pedidos', v: fmt(s.pedidos, 0) + ' · ' + m(s.total_pedidos) }];
    },
    columns() {
      const mon = this.moneda, M = (key, label, extra) => ({ key, label, num: true, fmt: 'money', moneda: mon, ...(extra || {}) });
      return [
        { key: 'nombre', label: 'Revendedora', link: x => this.abrir(x) },
        { key: 'telefono', label: 'Celular', mono: true },
        { key: 'lista', label: 'Lista de precios' },
        M('limite', 'Límite', { fmt: v => ((+v || 0) > 0 ? money(v, mon) : 'Sin crédito') }),
        M('saldo', 'Saldo'), M('vencido', 'Vencido'), M('en_pedidos', 'En pedidos'),
        M('disponible', 'Disponible', { fmt: (v, r) => ((+r.limite || 0) > 0 ? money(v, mon) : '—') }),
        { key: 'pedidos', label: 'Pedidos', num: true, fmt: 'num', dec: 0 },
        { key: 'ultimo_pedido', label: 'Último pedido', fmt: 'date' },
        { key: 'estado', label: 'Cuenta', fmt: 'badge' },
        { key: 'acceso', label: 'Catálogo', fmt: 'badge' },
      ];
    },
    filtrosTexto() { return [this.q.trim() ? 'Búsqueda: «' + this.q.trim() + '»' : '', this.soloSaldo ? 'solo con saldo' : '', this.soloPedidos ? 'solo con pedidos' : ''].filter(Boolean).join(' · '); },
  },
  watch: {
    q() { this.sincronizar(); if (this.tope) { clearTimeout(this.timer); this.timer = setTimeout(() => this.cargar(), 400); } },
    soloSaldo() { this.sincronizar(); }, soloPedidos() { this.sincronizar(); },
    // 4.9: un enlace que solo cambia la consulta no vuelve a montar la pantalla
    'params.q'(v) { this.q = String(v || ''); }, 'params.saldo'(v) { this.soloSaldo = v === '1'; }, 'params.pedidos'(v) { this.soloPedidos = v === '1'; },
  },
  methods: {
    money, fecha,
    abrir(x) { if (x && x.id) location.hash = '/contactos/estado-cuenta/' + x.id; },
    async cargar(manual) {
      const n = ++this.seq, q = this.tope ? this.q.trim() : '';
      this.cargando = true; this.error = ''; this.moneda = principal();
      try {
        const l = await api('/api/revendedoras' + (q ? '?q=' + encodeURIComponent(q) : ''));
        if (n !== this.seq) return;
        this.filas = (Array.isArray(l) ? l : []).map(x => ({ ...x, id: x.contacto_id, limite: +x.limite || 0, saldo: +x.saldo || 0, vencido: +x.vencido || 0, en_pedidos: +x.en_pedidos || 0, disponible: +x.disponible || 0, pedidos: +x.pedidos || 0, total_pedidos: +x.total_pedidos || 0,
          estado: estadoSaldo(x), acceso: x.con_acceso ? 'Acceso activo' : 'Sin acceso' }));
        if (!q) this.tope = this.filas.length >= TOPE;
        this.qServidor = q;
        if (manual) toast('Lista actualizada', 'ok');
      } catch (e) { if (n !== this.seq) return; this.error = e.message; this.filas = []; }
      this.cargando = false;
    },
    // 4.9: la dirección refleja los filtros (se puede guardar o compartir) sin volver a cargar la pantalla
    sincronizar() {
      const p = new URLSearchParams(); if (this.q.trim()) p.set('q', this.q.trim()); if (this.soloSaldo) p.set('saldo', '1'); if (this.soloPedidos) p.set('pedidos', '1');
      try { const qs = p.toString(); history.replaceState(history.state, '', '#/contactos/revendedoras' + (qs ? '?' + qs : '')); } catch { /* sin historial: los filtros siguen en pantalla */ }
    },
    tel(r) { return telefonoWa(r); },
    waFila(r) { return enlaceWhatsApp(telefonoWa(r), textoEstadoCuenta({ empresa: this.empresaNombre, nombre: r.nombre, credito: r, moneda: this.moneda, al: hoy() })); },
    datosDoc() {
      return { titulo: 'Revendedoras y saldos', subtitulo: ('Revendedoras y clientes con crédito' + (this.filtrosTexto ? ' · ' + this.filtrosTexto : '')).slice(0, 300), periodo: 'Al ' + fecha(hoy()), cols: this.columns.filter(c => c.key !== 'acceso'), rows: this.vista, kpis: this.kpis,
        totales: [{ t: 'Saldo por cobrar', v: money(this.suma.saldo, this.moneda) }, { t: 'Vencido', v: money(this.suma.vencido, this.moneda) }, { t: 'En pedidos por facturar', v: money(this.suma.en_pedidos, this.moneda) }],
        nota: 'Montos en ' + this.moneda + ' (los documentos en otra moneda, con su tipo de cambio). Saldo = facturas y tiquetes a crédito pendientes; en pedidos = pedidos a crédito todavía sin facturar.' };
    },
    async imprimir() {
      const imp = this.impresorasLista.find(i => String(i.id) === String(this.impSel)) || null;
      try { const d = await imprimirReporte(this.datosDoc(), imp, store.empresa); if (d === 'agente') toast('Reporte enviado a «' + imp.nombre + '»', 'ok'); }
      catch (e) { toast(await avisoImpresion('No se imprimió' + (imp ? ' en «' + imp.nombre + '»' : '') + ': ', e), 'err'); }
    },
    pdf() { descargarReporte('pdf', { ...this.datosDoc(), archivo: 'revendedoras' }); },
    async excel(formato) {
      const cols = this.columns.map(c => {
        const num = c.fmt === 'money' || c.fmt === 'num';
        return { key: c.key, label: c.label, num, sumar: c.fmt === 'money', fecha: c.fmt === 'date', valor: r => { const v = r[c.key]; if (c.fmt === 'date') return fecha(v); if (num) return v === null || v === undefined || v === '' ? null : +v || 0; return v ?? ''; } };
      });
      if (formato === 'csv') return descargarTabla('csv', 'revendedoras', cols.map(c => ({ ...c, csv: (v, r) => c.valor(r) })), this.vista);   // 4.17
      try { const archivo = await descargarExcel('revendedoras', { titulo: 'Revendedoras y saldos', subtitulo: this.filtrosTexto || 'Revendedoras y clientes con crédito', periodo: 'Al ' + fecha(hoy()), cols, rows: this.vista }); toast('Archivo ' + archivo + ' descargado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  created() {
    const rep = buscarReporte('ventas', 'revendedoras');
    if (rep && puedeReporte('ventas', rep.slug)) registrarReciente('ventas', rep);
    this.cargar();
  },
  template: `
  <div class="page">
    <PageHead title="Revendedoras y saldos" sub="Cada revendedora o cliente con crédito: límite, saldo, vencido, lo comprometido en pedidos, disponible y sus pedidos." :crumbs="[{label:'Contactos',to:'/contactos'},{label:'Revendedoras y saldos'}]">
      <button class="btn ghost" @click="cargar(true)" :disabled="cargando">↻ Actualizar</button>
      <select class="inp" v-if="impresorasLista.length" v-model="impSel" title="Dónde imprimir" style="max-width:190px"><option value="">Impresora del equipo</option><option v-for="i in impresorasLista" :key="i.id" :value="i.id">{{i.nombre}} (tiquete)</option></select>
      <button class="btn sec" @click="imprimir" :disabled="!vista.length" title="Imprimir: el navegador deja elegir la impresora">⎙ Imprimir</button>
      <button class="btn sec" @click="pdf" :disabled="!vista.length">⤓ PDF</button>
      <button class="btn sec" @click="excel" :disabled="!vista.length" title="Excel con formato, listo para usar">⤓ Excel</button><button class="btn sec" @click="excel('csv')" :disabled="!vista.length">⤓ CSV</button>
      <a class="btn" href="#/contactos/estado-cuenta">Estado de cuenta de un cliente</a>
    </PageHead>

    <div class="toolbar">
      <input class="search" style="min-width:300px" placeholder="Buscar por nombre, cédula, celular, correo o lista" v-model="q">
      <label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" v-model="soloSaldo"> Solo con saldo</label>
      <label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" v-model="soloPedidos"> Solo con pedidos</label>
      <span class="small muted" style="margin-left:auto">{{vista.length}} de {{filas.length}} · montos en {{moneda}}</span>
    </div>

    <div class="alert" v-if="error">No se pudo cargar la lista: {{error}}</div>
    <div class="alert info" v-if="tope && !q.trim()">Se muestran las primeras {{filas.length}}: escriba en el buscador para buscar entre todas.</div>
    <div class="dash" style="margin-bottom:18px" v-if="!error">
      <div class="kpi w4" v-for="k in kpis" :key="k.t"><div class="t">{{k.t}}</div><div class="v">{{k.v}}</div><div class="d">Al {{fecha(hoy())}}</div></div>
    </div>

    <div class="card pad0" v-if="!error">
      <DataTable :rows="vista" :columns="columns" :page-size="20" :empty-title="cargando ? 'Cargando…' : (filas.length ? 'Sin coincidencias' : 'Todavía no hay revendedoras')" :empty-text="filas.length ? 'Pruebe con otro nombre o quite los filtros.' : 'Aquí aparecen los clientes con límite de crédito, con pedidos en línea, con acceso al catálogo de revendedoras o con saldo a crédito.'" @row-click="abrir">
        <template #actions="{ row }">
          <a class="btn sm ghost" v-if="tel(row)" :href="waFila(row)" target="_blank" rel="noopener" @click.stop title="Enviarle su saldo por WhatsApp">WhatsApp</a>
          <a class="btn sm sec" :href="'#/contactos/estado-cuenta/' + row.id" @click.stop>Estado de cuenta</a>
        </template>
      </DataTable>
      <div class="totals" style="padding:0 16px 14px" v-if="vista.length">
        <div><span>Saldo por cobrar</span><b>{{money(suma.saldo, moneda)}}</b></div>
        <div><span>Vencido</span><b>{{money(suma.vencido, moneda)}}</b></div>
        <div><span>En pedidos por facturar</span><b>{{money(suma.en_pedidos, moneda)}}</b></div>
        <div class="total"><span>Saldo más pedidos</span><b>{{money(suma.saldo + suma.en_pedidos, moneda)}}</b></div>
      </div>
      <p class="small muted" style="padding:0 16px 14px;margin:0">Saldo: facturas y tiquetes a crédito (también los fiados en la caja) pendientes de cobro. En pedidos: pedidos a crédito que todavía no se han facturado. Disponible: límite menos saldo y pedidos.</p>
    </div>
  </div>`,
  setup() { return { hoy }; },
};
