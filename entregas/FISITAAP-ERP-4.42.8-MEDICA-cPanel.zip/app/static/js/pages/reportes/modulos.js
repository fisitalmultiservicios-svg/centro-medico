// Reportes › Reporte ejecutivo por módulo (3.2): una tarjeta por módulo con sus cifras clave del mes y del día, y enlaces a sus
// reportes. Cada usuario ve solo los módulos a los que tiene permiso: la camarera ve Ama de llaves, el cajero el Punto de venta,
// el contador las finanzas. Todo se calcula con los registros ya cargados en el navegador (sin pedir nada al servidor), salvo
// el bloque financiero que usa el resumen del negocio cuando el rol puede verlo.
import { api, money, fmt, fecha, hoy, sumarDias, mock } from '../../api.js';
import { sesion, store, hotelActivo } from '../../app.js';
import * as H from '../hotel/_datos.js';
import { cajas, posVentas, resumenCaja, nombreMedio as medioPos } from '../pos/_datos.js';
import { empleados, planillas, ausencias, vacacionesTomadas, liquidaciones, nombreCompleto, salarioMensual, esPagada, esComplementaria } from '../rrhh/_datos.js';
import { principal } from './_montos.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const inicioMes = () => hoy().slice(0, 8) + '01';

export default {
  props: ['params'],
  data() { return { listo: false, h: hoy(), desde: inicioMes(), hasta: hoy(), r: null, cargando: false, reloj: 0 }; },
  computed: {
    tipo() { return sesion.tipo; },
    esHotel() { return this.tipo === 'hospitalidad' && hotelActivo(); },
    puedeFin() { return sesion.puede('reportes') || sesion.puede('ver_todo'); },
    cfgH() { return this.esHotel ? H.config() : null; },
    // ---- hotel (escribir o pos) ----
    hotel() {
      if (!this.esHotel || !(sesion.puede('escribir') || sesion.puede('pos'))) return null;
      const d = this.desde, h = this.hasta, hoyS = this.h, rs = H.reservas().filter(H.esEstadia), habs = H.habitaciones(), fs = H.folios(), m = this.cfgH.moneda;
      const dias = H.fechasEntre(d, Math.max(1, H.noches(d, h) + 1)), oc = dias.map(f => H.ocupacionDia(f, rs, habs));
      const ocupadasNoches = oc.reduce((s, o) => s + o.ocupadas, 0), totalNoches = oc.reduce((s, o) => s + o.total, 0);
      const cargos = fs.filter(f => f.tipo === 'cargo' && f.fecha >= d && f.fecha <= h), hosp = r2(cargos.filter(f => f.origen === 'hospedaje').reduce((s, f) => s + H.totalCargo(f), 0)), otros = r2(cargos.filter(f => f.origen !== 'hospedaje').reduce((s, f) => s + H.totalCargo(f), 0));
      const pagos = r2(fs.filter(f => f.tipo === 'pago' && f.fecha >= d && f.fecha <= h).reduce((s, f) => s + (+f.monto || 0), 0));
      const dia = H.listasDelDia(hoyS, rs), ocHoy = H.ocupacionDia(hoyS, rs, habs);
      const saldos = r2(rs.filter(r => r.estado === 'en_casa').reduce((s, r) => s + Math.max(0, H.totalesFolio(H.folioDe(r.id)).saldo), 0));
      const deps = r2(H.depositos().reduce((s, x) => s + (x.moneda === m ? H.depositoDisponible(x) : 0), 0));
      const agencias = r2(fs.filter(f => f.a_agencia && !f.documento_id).reduce((s, f) => s + H.totalCargo(f), 0));
      const creadas = rs.filter(r => String(r.creado || '').slice(0, 10) >= d && String(r.creado || '').slice(0, 10) <= h).length, cancel = rs.filter(r => ['cancelada', 'no_show'].includes(r.estado) && String(r.actualizado || r.creado || '').slice(0, 10) >= d).length;
      const origen = {}; for (const r of rs.filter(r => r.llegada >= d && r.llegada <= h && !['cancelada', 'no_show'].includes(r.estado))) origen[H.origenCorto(r.origen)] = (origen[H.origenCorto(r.origen)] || 0) + 1;
      return { m, pct: totalNoches ? Math.round(ocupadasNoches / totalNoches * 100) : 0, adr: ocupadasNoches ? r2(hosp / ocupadasNoches) : 0, revpar: totalNoches ? r2(hosp / totalNoches) : 0, hosp, otros, pagos, llegadas: dia.llegadas.length, salidas: dia.salidas.length, enCasa: dia.enCasa.length, ocHoy: ocHoy.pct, saldos, deps, agencias, creadas, cancel, origen: Object.entries(origen).sort((a, b) => b[1] - a[1]).slice(0, 5), proximas: dia.proximas.filter(r => r.llegada <= sumarDias(hoyS, 7)).length };
    },
    // ---- ama de llaves y mantenimiento ----
    limpieza() {
      if (!this.esHotel || !(sesion.puede('limpieza') || sesion.puede('escribir'))) return null;
      const habs = H.habitaciones(), rep = H.reportes().filter(r => r.modulo === 'limpieza'), d = this.desde, h = this.hasta;
      const porEstado = {}; for (const x of habs) porEstado[x.estado || 'limpia'] = (porEstado[x.estado || 'limpia'] || 0) + 1;
      const resueltos = rep.filter(r => r.estado === 'resuelto' && String(r.resuelto_en || '').slice(0, 10) >= d && String(r.resuelto_en || '').slice(0, 10) <= h);
      const horas = resueltos.map(r => (new Date(r.resuelto_en) - new Date(r.creado)) / 3600000).filter(x => isFinite(x) && x >= 0);
      const tipos = {}; for (const r of rep.filter(r => String(r.creado || '').slice(0, 10) >= d)) tipos[r.tipo || 'Otro'] = (tipos[r.tipo || 'Otro'] || 0) + 1;
      return { porEstado, abiertos: rep.filter(r => r.estado !== 'resuelto').length, urgentes: rep.filter(r => r.estado !== 'resuelto' && r.prioridad === 'urgente').length, resueltos: resueltos.length, horas: horas.length ? r2(horas.reduce((s, x) => s + x, 0) / horas.length) : null, tipos: Object.entries(tipos).sort((a, b) => b[1] - a[1]).slice(0, 5), sucias: habs.filter(x => x.estado === 'sucia').length };
    },
    mantenimiento() {
      if (!this.esHotel || !(sesion.puede('mantenimiento') || sesion.puede('escribir'))) return null;
      const rep = H.reportes().filter(r => r.modulo === 'mantenimiento'), d = this.desde, h = this.hasta, habs = H.todasHabitaciones();
      const resueltos = rep.filter(r => r.estado === 'resuelto' && String(r.resuelto_en || '').slice(0, 10) >= d && String(r.resuelto_en || '').slice(0, 10) <= h);
      const horas = resueltos.map(r => (new Date(r.resuelto_en) - new Date(r.creado)) / 3600000).filter(x => isFinite(x) && x >= 0);
      const tipos = {}; for (const r of rep.filter(r => String(r.creado || '').slice(0, 10) >= d)) tipos[r.tipo || 'Otro'] = (tipos[r.tipo || 'Otro'] || 0) + 1;
      const bloqueos = H.reservas().filter(r => r.tipo === 'bloqueo' && r.origen !== 'ical' && r.salida >= this.h).length;
      return { abiertos: rep.filter(r => r.estado !== 'resuelto').length, urgentes: rep.filter(r => r.estado !== 'resuelto' && r.prioridad === 'urgente').length, enProceso: rep.filter(r => r.estado === 'en_proceso').length, resueltos: resueltos.length, horas: horas.length ? r2(horas.reduce((s, x) => s + x, 0) / horas.length) : null, fuera: habs.filter(x => x.estado === 'mantenimiento').length, bloqueos, tipos: Object.entries(tipos).sort((a, b) => b[1] - a[1]).slice(0, 5) };
    },
    // ---- punto de venta ----
    pos() {
      this.listo;   // se recalcula cuando llega el historial completo de ventas de caja (3.73)
      if (this.tipo === 'facturacion' || !sesion.puede('pos')) return null;
      const d = this.desde, h = this.hasta, cs = cajas(), vs = posVentas().filter(v => !v.anulada);
      const enRango = v => { const f = String(v.hora || v.fecha || '').slice(0, 10); return f >= d && f <= h; };
      const ventas = vs.filter(enRango), hoyV = vs.filter(v => String(v.hora || v.fecha || '').slice(0, 10) === this.h);
      const total = r2(ventas.reduce((s, v) => s + (+v.total || 0), 0)), medios = {}; for (const v of ventas) for (const m of v.medios || []) medios[medioPos(m.medio)] = r2((medios[medioPos(m.medio)] || 0) + (+m.monto || 0));
      const porCaja = {}; for (const v of ventas) { const c = cs.find(x => x.id === v.caja_id); const k = c ? (c.caja || c.terminal || 'Caja') : 'Caja'; porCaja[k] = r2((porCaja[k] || 0) + (+v.total || 0)); }
      const abiertas = cs.filter(c => c.estado === 'Abierta');
      // 3.9: impuesto de servicio, propinas y comandas (rondas enviadas a cocina) del período, y los saloneros con más ventas
      const servicio = r2(ventas.reduce((s, v) => s + (+v.servicio || 0), 0)), propinas = r2(ventas.reduce((s, v) => s + (+v.propina || 0), 0)), comandas = ventas.reduce((s, v) => s + (+v.rondas || 0), 0);
      const sal = {}; for (const v of ventas) if (v.salonero) sal[v.salonero] = r2((sal[v.salonero] || 0) + (+v.total || 0));
      return { servicio, propinas, comandas, saloneros: Object.entries(sal).sort((a, b) => b[1] - a[1]).slice(0, 4), total, n: ventas.length, ticket: ventas.length ? r2(total / ventas.length) : 0, hoyTotal: r2(hoyV.reduce((s, v) => s + (+v.total || 0), 0)), hoyN: hoyV.length, medios: Object.entries(medios).sort((a, b) => b[1] - a[1]), porCaja: Object.entries(porCaja).sort((a, b) => b[1] - a[1]), abiertas: abiertas.length, cierres: cs.filter(c => c.estado !== 'Abierta' && String(c.cerrada_en || '').slice(0, 10) >= d && String(c.cerrada_en || '').slice(0, 10) <= h).length, hab: r2(ventas.filter(v => v.tipo === 'hab').reduce((s, v) => s + (+v.total || 0), 0)) };
    },
    // ---- recursos humanos ----
    // 4.7: lo pagado y lo por pagar por separado. La última planilla es la última PAGADA (no una complementaria); «pagado en el período»
    // suma el neto de las planillas pagadas (con sus complementarias), las liquidaciones pagadas y el aguinaldo, por su fecha de pago;
    // las planillas generadas sin pagar y las liquidaciones pendientes van aparte como «por pagar» (a hoy) y no se suman a lo pagado
    rrhh() {
      if (!sesion.puede('rrhh')) return null;
      const emp = empleados().filter(e => e.activo !== false), d = this.desde, h = this.hasta, enRango = f => { const x = String(f || '').slice(0, 10); return !!x && x >= d && x <= h; };
      const todas = planillas(), pagadas = todas.filter(esPagada), ult = pagadas.filter(p => !esComplementaria(p)).sort((a, b) => String(b.hasta).localeCompare(String(a.hasta)))[0] || null;
      const aus = ausencias().filter(a => String(a.desde || '').slice(0, 10) <= h && String(a.hasta || a.desde || '').slice(0, 10) >= d);
      const vac = vacacionesTomadas().filter(v => String(v.desde || '').slice(0, 10) >= d && String(v.desde || '').slice(0, 10) <= h);
      const liqs = liquidaciones(), liq = liqs.filter(l => esPagada(l) && enRango(l.pagada_en || l.fecha));
      const netoDe = p => +(p.totales || {}).neto || 0, plPer = pagadas.filter(p => enRango(p.pagada_en || p.hasta)), agPer = (mock.get('rrhh_aguinaldos', []) || []).filter(a => enRango(a.fecha));
      const aguinaldo = r2(agPer.reduce((s, a) => s + (+a.total || 0), 0)), pagado = r2(plPer.reduce((s, p) => s + netoDe(p), 0) + liq.reduce((s, l) => s + (+l.total || 0), 0) + aguinaldo);
      const plPend = todas.filter(p => !esPagada(p)), liqPend = liqs.filter(l => !esPagada(l));
      const porPagar = { planillas: plPend.length, liquidaciones: liqPend.length, monto: r2(plPend.reduce((s, p) => s + netoDe(p), 0) + liqPend.reduce((s, l) => s + (+l.total || 0), 0)) };
      const masa = r2(emp.reduce((s, e) => s + salarioMensual(e), 0));
      const cumple = emp.filter(e => e.fecha_ingreso && String(e.fecha_ingreso).slice(5, 10) >= this.h.slice(5, 10) && String(e.fecha_ingreso).slice(5, 10) <= sumarDias(this.h, 30).slice(5, 10)).map(nombreCompleto);
      return { empleados: emp.length, masa, ultima: ult, costo: ult ? +(ult.totales || {}).costo_total || 0 : 0, neto: ult ? netoDe(ult) : 0, pagado, planillasPagadas: plPer.length, aguinaldo, porPagar, ausencias: aus.length, vacaciones: vac.length, liquidaciones: liq.length, aniversarios: cumple.slice(0, 5) };
    },
    // ---- inventario y catálogo ----
    inventario() {
      if (!(sesion.puede('inventario') || sesion.puede('catalogos'))) return null;
      const ps = (store.productos || []), act = ps.filter(p => p.activo !== false), sinCabys = act.filter(p => !/^\d{13}$/.test(String(p.cabys || '')));
      return { items: act.length, inactivos: ps.length - act.length, servicios: act.filter(p => p.es_servicio || p.tipo === 'servicio').length, sinCabys: sinCabys.length, clientes: (store.clientes || []).filter(c => c.activo !== false && c.tipo !== 'Proveedor').length, proveedores: (store.clientes || []).filter(c => c.activo !== false && c.tipo === 'Proveedor').length };
    },
    // ---- finanzas (reportes o ver_todo): resumen del negocio ----
    finanzas() { return this.puedeFin && this.r ? this.r : null; },
    pMon() { return principal(); },
    modulos() { return [this.hotel, this.pos, this.limpieza, this.mantenimiento, this.rrhh, this.inventario, this.finanzas].filter(Boolean).length; },
  },
  methods: {
    money, fmt, fecha,
    rapido(q) { const h = hoy(); if (q === 'mes') { this.desde = inicioMes(); this.hasta = h; } else if (q === 'mes_anterior') { const a = sumarDias(inicioMes(), -1); this.desde = a.slice(0, 8) + '01'; this.hasta = a; } else if (q === 'semana') { this.desde = sumarDias(h, -6); this.hasta = h; } else if (q === 'hoy') { this.desde = h; this.hasta = h; } this.cargarFin(); },
    async cargarFin() { if (!this.puedeFin) return; this.cargando = true; try { this.r = await api('/api/resumen?periodo=rango&desde=' + this.desde + '&hasta=' + this.hasta); } catch { this.r = null; } this.cargando = false; },
    v(obj, k) { const x = obj && obj[k]; return x && typeof x === 'object' ? (x[this.pMon] || 0) : (+x || 0); },
  },
  watch: { desde() { this.cargarFin(); }, hasta() { this.cargarFin(); } },
  async created() { this.cargarFin(); if (await mock.completar('pos_ventas')) this.listo = true; },   // historial completo de ventas de caja (3.73)
  template: `
  <div class="page">
    <PageHead title="Reporte ejecutivo por módulo" :sub="'Cifras clave de cada módulo al que tiene acceso · ' + fecha(desde) + ' al ' + fecha(hasta)" :crumbs="[{label:'Reportes',to:'/reportes'},{label:'Por módulo'}]">
      <input type="date" class="inp" v-model="desde"><input type="date" class="inp" v-model="hasta"><button class="btn sm ghost" @click="rapido('hoy')">Hoy</button><button class="btn sm ghost" @click="rapido('semana')">7 días</button><button class="btn sm ghost" @click="rapido('mes')">Mes</button><button class="btn sm ghost" @click="rapido('mes_anterior')">Mes anterior</button>
    </PageHead>
    <div class="card" v-if="!modulos"><Empty icon="▤" title="Su rol no tiene módulos con reporte ejecutivo" text="Pida al administrador de la empresa que le asigne permisos en Configuración › Usuarios."></Empty></div>
    <div class="dash" v-else>
      <div class="card w6" v-if="hotel" style="margin:0"><h2>🛏 Hotel <small>ocupación, tarifa y cuentas</small></h2>
        <div class="dash" style="gap:10px;margin:0">
          <div class="kpi w3" style="margin:0"><div class="t">Ocupación del período</div><div class="v">{{hotel.pct}} %</div><div class="d">hoy {{hotel.ocHoy}} % · {{hotel.enCasa}} en casa</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Tarifa promedio (ADR)</div><div class="v">{{money(hotel.adr, hotel.m)}}</div><div class="d">RevPAR {{money(hotel.revpar, hotel.m)}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Hospedaje cargado</div><div class="v">{{money(hotel.hosp, hotel.m)}}</div><div class="d">otros cargos {{money(hotel.otros, hotel.m)}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Pagos recibidos</div><div class="v">{{money(hotel.pagos, hotel.m)}}</div><div class="d">saldos en casa {{money(hotel.saldos, hotel.m)}}</div></div>
        </div>
        <div class="grid cols-2 small" style="margin-top:10px;gap:4px 16px">
          <div><span class="muted">Hoy:</span> {{hotel.llegadas}} llegadas · {{hotel.salidas}} salidas · {{hotel.proximas}} llegan en 7 días</div>
          <div><span class="muted">Reservas creadas:</span> {{hotel.creadas}} · canceladas o no presentadas {{hotel.cancel}}</div>
          <div><span class="muted">Depósitos disponibles:</span> {{money(hotel.deps, hotel.m)}}</div>
          <div><span class="muted">Por facturar a agencias:</span> {{money(hotel.agencias, hotel.m)}}</div>
          <div style="grid-column:1/-1" v-if="hotel.origen.length"><span class="muted">Origen de las llegadas:</span> <span v-for="o in hotel.origen" :key="o[0]" class="badge" style="margin-right:4px">{{o[0]}} {{o[1]}}</span></div>
        </div>
        <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap"><a class="btn sm sec" :href="'#/hotel/reportes?rep=pronostico,ocupacion,origen&desde=' + desde + '&hasta=' + hasta">Pronóstico y ocupación</a><a class="btn sm ghost" :href="'#/hotel/reportes?rep=caja_recepcion,conceptos&desde=' + desde + '&hasta=' + hasta">Caja y producción</a><a class="btn sm ghost" href="#/hotel/cierre">Cierre del día</a></div>
      </div>
      <div class="card w6" v-if="pos" style="margin:0"><h2>🛒 Punto de venta <small>restaurante, bar y tienda</small></h2>
        <div class="dash" style="gap:10px;margin:0">
          <div class="kpi w3" style="margin:0"><div class="t">Ventas del período</div><div class="v">{{money(pos.total)}}</div><div class="d">{{pos.n}} ventas</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Ticket promedio</div><div class="v">{{money(pos.ticket)}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Hoy</div><div class="v">{{money(pos.hoyTotal)}}</div><div class="d">{{pos.hoyN}} ventas · {{pos.abiertas}} caja(s) abierta(s)</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Cargado a habitaciones</div><div class="v">{{money(pos.hab)}}</div><div class="d">{{pos.cierres}} cierre(s) en el período</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Impuesto de servicio 10 %</div><div class="v">{{money(pos.servicio)}}</div><div class="d">para el personal</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Propinas voluntarias</div><div class="v">{{money(pos.propinas)}}</div><div class="d">aparte del comprobante</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Comandas enviadas</div><div class="v">{{pos.comandas}}</div><div class="d">rondas a cocina y bar</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Servicio + propinas</div><div class="v">{{money(pos.servicio + pos.propinas)}}</div><div class="d">a repartir</div></div>
        </div>
        <div class="grid cols-2 small" style="margin-top:10px;gap:4px 16px">
          <div v-if="pos.medios.length"><span class="muted">Por medio:</span> <span v-for="m in pos.medios" :key="m[0]" class="badge" style="margin-right:4px">{{m[0]}} {{money(m[1])}}</span></div>
          <div v-if="pos.porCaja.length"><span class="muted">Por caja:</span> <span v-for="m in pos.porCaja" :key="m[0]" class="badge" style="margin-right:4px">{{m[0]}} {{money(m[1])}}</span></div>
          <div v-if="pos.saloneros.length"><span class="muted">Por salonero:</span> <span v-for="m in pos.saloneros" :key="m[0]" class="badge" style="margin-right:4px">{{m[0]}} {{money(m[1])}}</span></div>
        </div>
        <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap"><a class="btn sm sec" href="#/pos/cierres">Cierres de caja</a><a class="btn sm sec" href="#/pos/servicio">Servicio 10 % y propinas</a><a class="btn sm ghost" href="#/reportes/ventas/ventas-por-item" v-if="puedeFin">Ventas por ítem</a></div>
      </div>
      <div class="card w3" v-if="limpieza" style="margin:0"><h2>🧹 Ama de llaves</h2>
        <div class="totals" style="align-items:stretch">
          <div><span>Habitaciones sucias</span><b>{{limpieza.sucias}}</b></div><div><span>En limpieza</span><b>{{limpieza.porEstado.limpiando || 0}}</b></div><div><span>Limpias</span><b>{{limpieza.porEstado.limpia || 0}}</b></div>
          <div><span>Reportes abiertos</span><b>{{limpieza.abiertos}}<span class="badge danger" v-if="limpieza.urgentes" style="margin-left:6px">{{limpieza.urgentes}} urgentes</span></b></div>
          <div><span>Resueltos en el período</span><b>{{limpieza.resueltos}}</b></div><div v-if="limpieza.horas !== null"><span>Tiempo promedio de resolución</span><b>{{fmt(limpieza.horas, 1)}} h</b></div>
        </div>
        <div class="small" style="margin-top:8px" v-if="limpieza.tipos.length"><span class="muted">Más frecuentes:</span> <span v-for="t in limpieza.tipos" :key="t[0]" class="badge" style="margin-right:4px">{{t[0]}} {{t[1]}}</span></div>
        <div class="row" style="gap:6px;margin-top:10px"><a class="btn sm sec" href="#/hotel/ama-de-llaves/tablero">Tablero</a><a class="btn sm ghost" href="#/hotel/ama-de-llaves/incidencias">Reportes</a></div>
      </div>
      <div class="card w3" v-if="mantenimiento" style="margin:0"><h2>🔧 Mantenimiento</h2>
        <div class="totals" style="align-items:stretch">
          <div><span>Incidencias abiertas</span><b>{{mantenimiento.abiertos}}<span class="badge danger" v-if="mantenimiento.urgentes" style="margin-left:6px">{{mantenimiento.urgentes}} urgentes</span></b></div>
          <div><span>En proceso</span><b>{{mantenimiento.enProceso}}</b></div><div><span>Resueltas en el período</span><b>{{mantenimiento.resueltos}}</b></div>
          <div v-if="mantenimiento.horas !== null"><span>Tiempo promedio de resolución</span><b>{{fmt(mantenimiento.horas, 1)}} h</b></div>
          <div><span>Habitaciones fuera de servicio</span><b>{{mantenimiento.fuera}}</b></div><div><span>Bloqueos de fechas vigentes</span><b>{{mantenimiento.bloqueos}}</b></div>
        </div>
        <div class="small" style="margin-top:8px" v-if="mantenimiento.tipos.length"><span class="muted">Más frecuentes:</span> <span v-for="t in mantenimiento.tipos" :key="t[0]" class="badge" style="margin-right:4px">{{t[0]}} {{t[1]}}</span></div>
        <div class="row" style="gap:6px;margin-top:10px"><a class="btn sm sec" href="#/hotel/mantenimiento/incidencias">Incidencias</a><a class="btn sm ghost" href="#/hotel/mantenimiento/habitaciones">Fuera de servicio</a></div>
      </div>
      <div class="card w3" v-if="rrhh" style="margin:0"><h2>👥 Recursos humanos</h2>
        <div class="totals" style="align-items:stretch">
          <div><span>Empleados activos</span><b>{{rrhh.empleados}}</b></div><div><span>Masa salarial mensual</span><b>{{money(rrhh.masa)}}</b></div>
          <div v-if="rrhh.ultima"><span>Última planilla pagada {{rrhh.ultima.numero || ''}} (costo)</span><b>{{money(rrhh.costo)}}</b></div><div v-if="rrhh.ultima"><span>Neto pagado</span><b>{{money(rrhh.neto)}}</b></div>
          <div><span>Pagado en el período</span><b :title="rrhh.planillasPagadas + ' planilla(s) y ' + rrhh.liquidaciones + ' liquidación(es) pagadas' + (rrhh.aguinaldo ? ' y el aguinaldo' : '') + ', por fecha de pago'">{{money(rrhh.pagado)}}</b></div>
          <div v-if="rrhh.porPagar.planillas || rrhh.porPagar.liquidaciones"><span>Por pagar (no incluido)</span><b style="color:var(--warn)">{{money(rrhh.porPagar.monto)}}</b></div>
          <div><span>Ausencias en el período</span><b>{{rrhh.ausencias}}</b></div><div><span>Vacaciones tomadas</span><b>{{rrhh.vacaciones}}</b></div><div><span>Liquidaciones pagadas</span><b>{{rrhh.liquidaciones}}</b></div>
        </div>
        <div class="small" style="margin-top:8px" v-if="rrhh.porPagar.planillas || rrhh.porPagar.liquidaciones"><span class="muted">Por pagar:</span> {{rrhh.porPagar.planillas}} planilla(s) generada(s) y {{rrhh.porPagar.liquidaciones}} liquidación(es) pendiente(s) de pago; no se suman a lo pagado.</div>
        <div class="small" style="margin-top:8px" v-if="rrhh.aniversarios.length"><span class="muted">Aniversarios en 30 días:</span> {{rrhh.aniversarios.join(', ')}}</div>
        <div class="row" style="gap:6px;margin-top:10px"><a class="btn sm sec" href="#/rrhh/informes">Informes de planilla</a><a class="btn sm ghost" href="#/rrhh/planilla">Planilla</a></div>
      </div>
      <div class="card w3" v-if="inventario" style="margin:0"><h2>▦ Inventario y catálogo</h2>
        <div class="totals" style="align-items:stretch">
          <div><span>Ítems activos</span><b>{{inventario.items}}</b></div><div><span>Servicios</span><b>{{inventario.servicios}}</b></div><div><span>Inactivos</span><b>{{inventario.inactivos}}</b></div>
          <div><span>Sin código CABYS válido</span><b :style="inventario.sinCabys ? 'color:var(--danger)' : ''">{{inventario.sinCabys}}</b></div>
          <div><span>Clientes</span><b>{{inventario.clientes}}</b></div><div><span>Proveedores</span><b>{{inventario.proveedores}}</b></div>
        </div>
        <div class="row" style="gap:6px;margin-top:10px"><a class="btn sm sec" href="#/inventario/valor">Valor de inventario</a><a class="btn sm ghost" href="#/inventario/items">Ítems</a></div>
      </div>
      <div class="card w6" v-if="puedeFin" style="margin:0"><h2>₡ Finanzas <small>{{cargando ? 'cargando…' : 'ventas, cobros, pagos e IVA'}}</small></h2>
        <template v-if="finanzas">
          <div class="dash" style="gap:10px;margin:0">
            <div class="kpi w3" style="margin:0"><div class="t">Ventas</div><div class="v">{{money(v(finanzas,'ventas'), pMon)}}</div><div class="d">{{finanzas.documentos || 0}} documentos</div></div>
            <div class="kpi w3" style="margin:0"><div class="t">Cuentas por cobrar</div><div class="v">{{money(v(finanzas.cxc, 'total'), pMon)}}</div><div class="d">vencido {{money(v(finanzas.cxc, 'vencido'), pMon)}}</div></div>
            <div class="kpi w3" style="margin:0"><div class="t">Cuentas por pagar</div><div class="v">{{money(v(finanzas.cxp, 'total'), pMon)}}</div><div class="d">vencido {{money(v(finanzas.cxp, 'vencido'), pMon)}}</div></div>
            <div class="kpi w3" style="margin:0"><div class="t">IVA neto del período</div><div class="v">{{money(v(finanzas.iva, 'neto'), pMon)}}</div><div class="d">débito {{money(v(finanzas.iva, 'debito'), pMon)}}</div></div>
          </div>
          <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap"><a class="btn sm sec" :href="'#/reportes/ejecutivo?periodo=rango&desde=' + desde + '&hasta=' + hasta">Reporte ejecutivo completo</a><a class="btn sm ghost" href="#/reportes/contables">Contables</a><a class="btn sm ghost" href="#/reportes/fiscales">Fiscales</a></div>
        </template>
        <Empty v-else-if="!cargando" icon="₡" title="Sin cifras financieras" text="No se pudo cargar el resumen del negocio."></Empty>
      </div>
    </div>
  </div>`,
};
