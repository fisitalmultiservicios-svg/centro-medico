// 4.9: Revendedoras — funciones puras para el estado de cuenta y su envío (sin Vue, sin api.js ni app.js). Las usan las pantallas del
// ERP (pages/reportes/revendedoras.js, revendedora.js y la ficha del contacto) y las de Ventas en línea (js/fis/pages/), que no cargan
// app.js. Montos en la moneda que se indique (la principal de la empresa); fechas AAAA-MM-DD.

const SIM = { CRC: '₡', USD: '$', EUR: '€' };
const r2 = n => Math.round((+n || 0) * 100) / 100;

// 4.9: 1.234,56 como en el resto del sistema (api.js fmt/money, aquí sin importarlo)
export function cifra(n, dec = 2) { return Number(n || 0).toLocaleString('es-CR', { minimumFractionDigits: dec, maximumFractionDigits: dec }).replace(/[   ]/g, '.'); }
export function dinero(n, moneda = 'CRC') { return (SIM[moneda] || (moneda + ' ')) + cifra(n); }
export function cantidad(n) { return Number(n || 0).toLocaleString('es-CR', { minimumFractionDigits: 0, maximumFractionDigits: 3 }).replace(/[   ]/g, '.'); }
export function fechaCorta(iso) { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || '')); return m ? `${+m[3]}/${+m[2]}/${m[1]}` : String(iso || ''); }

// 4.9: los 8 dígitos de un teléfono de Costa Rica (sin 506, guiones ni espacios); '' si no es un número válido
export function digitosTel(v) { let d = String(v ?? '').replace(/\D/g, ''); if (d.length === 11 && d.startsWith('506')) d = d.slice(3); return d.length === 8 ? d : ''; }
// 4.9: número para WhatsApp (506 + 8 dígitos): del contacto (el celular primero, si no el teléfono), de una fila de la lista de
// revendedoras (telefono) o el número suelto. '' si no hay uno válido.
export function telefonoWa(c) {
  const vals = c && typeof c === 'object' ? [c.celular, c.telefono, c.tel] : [c];
  for (const v of vals) { const d = digitosTel(v); if (d) return '506' + d; }
  return '';
}
// 4.9: enlace de WhatsApp con el mensaje ya escrito. Sin número, WhatsApp le pide elegir el contacto.
export function enlaceWhatsApp(tel, texto) {
  const d = String(tel || '').replace(/\D/g, ''), n = d.length === 8 ? '506' + d : d;
  return 'https://wa.me/' + n + '?text=' + encodeURIComponent(String(texto || ''));
}
// 4.9: mailto: a los correos del cliente con asunto y cuerpo (el cuerpo se acorta: algunos programas de correo no abren enlaces muy largos)
export function enlaceCorreo(correos, asunto, cuerpo) {
  const para = [].concat(correos || []).flatMap(x => String(x || '').split(/[,;\s]+/)).map(x => x.trim()).filter(x => /^[^\s@,;<>"]+@[^\s@,;<>"]+\.[^\s@,;<>"]+$/.test(x));
  if (!para.length) return '';
  return 'mailto:' + para.map(x => encodeURIComponent(x).replace(/%40/g, '@')).join(',') + '?subject=' + encodeURIComponent(String(asunto || '')) + '&body=' + encodeURIComponent(String(cuerpo || '').slice(0, 1500));
}
export function asuntoEstadoCuenta({ empresa = '', al = '' } = {}) { return 'Estado de cuenta' + (empresa ? ' · ' + empresa : '') + (al ? ' al ' + fechaCorta(al) : ''); }

// 4.9: texto del estado de cuenta para enviárselo a la revendedora (WhatsApp o correo): saldo, vencido, lo comprometido en pedidos,
// límite y disponible, y hasta 10 documentos pendientes. credito: { limite, saldo, vencido, en_pedidos, disponible, documentos:
// [{ consecutivo, fecha, vence, dias, saldo }] } (la salida de /api/revendedoras/{id}/credito o una fila de la lista). Del consecutivo van
// los últimos 10 dígitos, como en el mensaje que arma el servidor. Máximo `max` caracteres: si no cabe, se quitan documentos de la lista
// (se dice cuántos quedan).
export function textoEstadoCuenta({ empresa = '', nombre = '', credito = {}, moneda = 'CRC', al = '', enlace = '', max = 1500 } = {}) {
  const c = credito || {}, $ = v => dinero(v, moneda), hay = v => (+v || 0) > 0.009;
  const docs = (Array.isArray(c.documentos) ? c.documentos : []).filter(d => d && hay(d.saldo));
  const cab = ['Hola' + (nombre ? ' ' + String(nombre).trim() : '') + ', le saludamos' + (empresa ? ' de ' + String(empresa).trim() : '') + '.', 'Su estado de cuenta' + (al ? ' al ' + fechaCorta(al) : '') + ':', '• Saldo pendiente: ' + $(c.saldo)];
  if (hay(c.vencido)) cab.push('• Vencido: ' + $(c.vencido));
  if (hay(c.en_pedidos)) cab.push('• En pedidos por facturar: ' + $(c.en_pedidos));
  if (hay(c.limite)) cab.push('• Límite de crédito: ' + $(c.limite), '• Disponible: ' + $(c.disponible));
  if (!hay(c.saldo) && !hay(c.en_pedidos)) cab.push('No tiene saldos pendientes.');
  const linea = d => '- ' + (d.consecutivo ? String(d.consecutivo).slice(-10) : ('Documento ' + (d.id || ''))) + (d.fecha ? ' del ' + fechaCorta(d.fecha) : '') + ': ' + $(d.saldo) + (d.vence ? ((+d.dias || 0) > 0 ? ' (venció el ' : ' (vence el ') + fechaCorta(d.vence) + ')' : '');
  const pie = [...(enlace ? ['', 'Detalle: ' + enlace] : []), '', 'Cualquier consulta, con gusto le atendemos.'];
  let n = Math.min(10, docs.length), texto = '';
  for (;;) {
    const lista = docs.length ? ['', 'Documentos pendientes:', ...docs.slice(0, n).map(linea), ...(docs.length > n ? ['… y ' + (docs.length - n) + ' documento(s) más.'] : [])] : [];
    texto = [...cab, ...lista, ...pie].join('\n');
    if (texto.length <= max || n === 0) break;
    n--;
  }
  return texto.length > max ? texto.slice(0, Math.max(0, max - 1)) + '…' : texto;
}

// 4.9: botones rápidos de fechas: Mes (desde el 1.º de este mes), 3 meses (desde el 1.º de hace dos meses), Año (desde el 1.º de
// enero) y Todo (sin fechas: toda la cuenta). hoy = AAAA-MM-DD en hora de Costa Rica.
export const RANGOS = [['mes', 'Mes'], ['3meses', '3 meses'], ['anio', 'Año'], ['todo', 'Todo']];
export function rangoRapido(q, hoy) {
  const h = String(hoy || '').slice(0, 10), a = +h.slice(0, 4), m = +h.slice(5, 7);
  if (!a || !m) return { desde: '', hasta: '' };
  if (q === 'mes') return { desde: h.slice(0, 8) + '01', hasta: h };
  if (q === '3meses') { const d = new Date(a, m - 3, 1); return { desde: d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-01', hasta: h }; }
  if (q === 'anio') return { desde: h.slice(0, 4) + '-01-01', hasta: h };
  return { desde: '', hasta: '' };
}
// 4.9: cuál botón rápido corresponde a las fechas elegidas ('' si es un rango libre); «hasta» vacío = hoy
export function rangoActivo(desde, hasta, hoy) {
  const h = String(hoy || '').slice(0, 10);
  if (!desde && (!hasta || hasta >= h)) return 'todo';
  for (const [k] of RANGOS) { if (k === 'todo') continue; const r = rangoRapido(k, h); if (r.desde === desde && (hasta || h) === r.hasta) return k; }
  return '';
}

// 4.9: resumen de las líneas de un pedido («2 × Blusa, 1 × Pantalón…»), corto para la tabla y el PDF
export function textoLineas(lineas, max = 120) {
  const t = (Array.isArray(lineas) ? lineas : []).filter(Boolean).map(l => cantidad(l.cantidad) + ' × ' + String(l.detalle || '').trim()).join(', ');
  return t.length > max ? t.slice(0, Math.max(0, max - 1)) + '…' : t;
}
// 4.9: estado del saldo de una revendedora para la lista (Badge: rojo, amarillo, gris)
export function estadoSaldo(f) { const x = f || {}; return (+x.vencido || 0) > 0.009 ? 'Vencido' : ((+x.saldo || 0) > 0.009 ? 'Por cobrar' : 'Al día'); }
// 4.9: saldo final del estado de cuenta (el del último movimiento o el saldo anterior si no hubo movimientos en el período)
export function saldoFinal(d) { const m = (d && Array.isArray(d.movimientos)) ? d.movimientos : []; return r2(m.length ? m[m.length - 1].saldo : (d && d.saldo_anterior) || 0); }
