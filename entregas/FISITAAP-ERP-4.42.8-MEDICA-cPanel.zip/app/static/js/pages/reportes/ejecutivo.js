// Reportes › Reporte ejecutivo. Mismas cifras del Inicio (/api/resumen?detalle=1) con el detalle de cada tema en todas las
// monedas de la empresa. Se abre desde cada tarjeta del Inicio con ?tema=… y el mismo período; cada tabla se exporta a CSV.
import { api, money, fmt, fecha, hoy, mock } from '../../api.js';
import { Monto, PERIODOS, otrasMonedas, principal, queryPeriodo, periodoDesdeParams, etiquetaPeriodo, serie, descargarReporte, descargarTabla } from './_montos.js';
import { registrarReciente } from './hub.js';

const TEMAS = [
  ['ventas', 'Ventas', 'Facturas, tiquetes, facturas de exportación y notas de débito emitidos en el período (no rechazados por Hacienda).'],
  ['devoluciones', 'Devoluciones de clientes', 'Notas de crédito emitidas en el período.'],
  ['cxc', 'Cuentas por cobrar', 'Ventas a crédito con saldo pendiente a hoy; vencidas según su fecha de vencimiento.'],
  ['cxp', 'Cuentas por pagar', 'Facturas de compra y de gasto registradas en Gastos con saldo pendiente a hoy.'],
  ['iva', 'IVA del período', 'IVA cobrado en lo emitido menos el IVA acreditable de los comprobantes recibidos y aceptados y de las facturas de compra.'],
  ['items', 'Ítems vendidos', 'Cantidades y montos por producto o servicio en el período.'],
  ['clientes', 'Clientes', 'Ventas por cliente en el período.'],
  ['egresos', 'Egresos y distribución de gastos', 'Comprobantes de proveedores recibidos y aceptados más facturas electrónicas de compra, y su distribución por proveedor.'],
  ['flujo', 'Flujo de transacciones', 'Ingresos y egresos por día (o por mes en períodos largos).'],
];
const eqCRC = { key: 'CRC', label: 'Equivale ₡', num: true, fmt: v => money(v, 'CRC') };
const eqUSD = { key: 'USD', label: 'Equivale $', num: true, fmt: v => money(v, 'USD') };
const F = (key, label) => ({ key, label, fmt: 'date' });
const N = (key, label, dec = 2) => ({ key, label, num: true, fmt: v => fmt(v, dec) });
const M = (key, label) => ({ key, label, num: true, fmt: 'money' });

export default {
  props: ['params'],
  components: { Monto },
  data() {
    const q = periodoDesdeParams(this.params);
    return { ...q, r: null, cargando: true, error: '', tema: (this.params && this.params.tema) || '', abiertos: {}, periodos: PERIODOS, temas: TEMAS };
  },
  computed: {
    p() { return principal(); },
    otras() { return otrasMonedas(this.r); },
    serie() { return serie(this.r, 400); },
    cols() {
      const base = [F('fecha', 'Fecha'), { key: 'tipo', label: 'Tipo' }, { key: 'consecutivo', label: 'Consecutivo', mono: true }, { key: 'cliente', label: 'Cliente' }, { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('impuesto', 'IVA'), N('tipo_cambio', 'T. cambio'), eqCRC, eqUSD, { key: 'estado', label: 'Estado', fmt: 'badge' }];
      const recib = [F('fecha', 'Fecha'), { key: 'proveedor', label: 'Proveedor' }, { key: 'consecutivo', label: 'Consecutivo', mono: true }, { key: 'origen', label: 'Origen' }, { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('impuesto', 'IVA'), eqCRC, eqUSD];
      return {
        ventas: base, devoluciones: base,
        cxc: [F('fecha', 'Emitida'), { key: 'consecutivo', label: 'Consecutivo', mono: true }, { key: 'cliente', label: 'Cliente' }, F('vencimiento', 'Vence'), N('dias', 'Días vencida', 0), { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('pagado', 'Pagado'), M('acreditado', 'Notas de crédito'), M('saldo', 'Saldo'), { ...eqCRC, label: 'Saldo ₡' }, { ...eqUSD, label: 'Saldo $' }, { key: 'estado', label: 'Estado', fmt: 'badge' }],
        cxp: [{ key: 'numero', label: 'Documento', mono: true }, { key: 'proveedor', label: 'Proveedor' }, F('fecha', 'Fecha'), F('vencimiento', 'Vence'), N('dias', 'Días vencida', 0), { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('pagado', 'Pagado'), M('saldo', 'Saldo'), { ...eqCRC, label: 'Saldo ₡' }, { ...eqUSD, label: 'Saldo $' }, { key: 'estado', label: 'Estado', fmt: 'badge' }],
        iva_emitidos: [F('fecha', 'Fecha'), { key: 'tipo', label: 'Tipo' }, { key: 'consecutivo', label: 'Consecutivo', mono: true }, { key: 'cliente', label: 'Cliente' }, { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('impuesto', 'IVA cobrado'), { key: 'impuesto_CRC', label: 'IVA ₡', num: true, fmt: v => money(v, 'CRC') }, { key: 'impuesto_USD', label: 'IVA $', num: true, fmt: v => money(v, 'USD') }],
        iva_recibidos: [F('fecha', 'Fecha'), { key: 'proveedor', label: 'Proveedor' }, { key: 'consecutivo', label: 'Consecutivo', mono: true }, { key: 'origen', label: 'Origen' }, { key: 'respuesta', label: 'Respuesta' }, { key: 'moneda', label: 'Moneda' }, M('total', 'Total'), M('impuesto', 'IVA del comprobante'), M('acreditar', 'IVA acreditable'), { key: 'acreditar_CRC', label: 'Acreditable ₡', num: true, fmt: v => money(v, 'CRC') }, { key: 'acreditar_USD', label: 'Acreditable $', num: true, fmt: v => money(v, 'USD') }],
        items: [{ key: 'detalle', label: 'Ítem' }, N('cantidad', 'Cantidad'), N('docs', 'Líneas', 0), { key: 'CRC', label: 'Venta ₡', num: true, fmt: (v, r) => money(r.monto.CRC, 'CRC') }, { key: 'USD', label: 'Venta $', num: true, fmt: (v, r) => money(r.monto.USD, 'USD') }],
        clientes: [{ key: 'nombre', label: 'Cliente' }, N('docs', 'Documentos', 0), { key: 'CRC', label: 'Ventas ₡', num: true, fmt: (v, r) => money(r.monto.CRC, 'CRC') }, { key: 'USD', label: 'Ventas $', num: true, fmt: (v, r) => money(r.monto.USD, 'USD') }],
        egresos: recib,
        proveedores: [{ key: 'nombre', label: 'Proveedor' }, N('docs', 'Documentos', 0), { key: 'CRC', label: 'Monto ₡', num: true, fmt: (v, r) => money(r.monto.CRC, 'CRC') }, { key: 'USD', label: 'Monto $', num: true, fmt: (v, r) => money(r.monto.USD, 'USD') }, N('pct', '% del total', 0)],
        flujo: [{ key: 'k', label: 'Fecha' }, { key: 'ingresos', label: 'Ingresos', num: true, fmt: v => money(v, this.p) }, { key: 'egresos', label: 'Egresos', num: true, fmt: v => money(v, this.p) }, { key: 'neto', label: 'Neto', num: true, fmt: v => money(v, this.p) }],
      };
    },
    proveedores() { const l = (this.r && this.r.detalle && this.r.detalle.proveedores) || []; const tot = l.reduce((s, x) => s + (x.monto[this.p] || 0), 0) || 1; return l.map(x => ({ ...x, pct: Math.round((x.monto[this.p] || 0) / tot * 100) })); },
    flujo() { return this.serie.map(d => ({ ...d, neto: d.ingresos - d.egresos })); },
  },
  methods: {
    money, fmt, fecha, etiquetaPeriodo,
    abierto(t) { return this.abiertos[t] !== undefined ? this.abiertos[t] : (!this.tema || this.tema === t); },
    alternar(t) { this.abiertos[t] = !this.abierto(t); },
    async cargar() {
      this.cargando = true; this.error = '';
      try { this.r = await api('/api/resumen?detalle=1&' + queryPeriodo(this.periodo, this.desde, this.hasta)); }
      catch (e) { this.error = e.message; }
      this.cargando = false;
      this.$nextTick(() => { if (this.tema) { const el = document.getElementById('tema-' + this.tema); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); } });
    },
    filas(k) { if (k === 'proveedores') return this.proveedores; if (k === 'flujo') return this.flujo; return (this.r && this.r.detalle && this.r.detalle[k]) || []; },
    kpisResumen() {
      const r = this.r, p = this.p;
      return [{ t: 'Total de ventas', v: money(r.ventas[p] || 0, p) }, { t: 'Cuentas por cobrar', v: money(r.cxc.total[p] || 0, p) }, { t: 'Cuentas por pagar', v: money(r.cxp.total[p] || 0, p) }, { t: 'IVA del período', v: money(r.iva.neto[p] || 0, p) }];
    },
    // PDF o Word de una sección con el encabezado de la empresa y las cifras principales del período
    documento(k, nombre, formato) {
      const t = this.temas.find(x => x[0] === k) || ['', nombre, ''];
      const rows = this.filas(k), cols = this.cols[k] || [];
      const sumas = cols.filter(c => c.key === 'CRC' || c.key === 'USD' || ['ingresos', 'egresos', 'neto'].includes(c.key) || (c.fmt === 'money' && ['impuesto_CRC', 'impuesto_USD', 'acreditar_CRC', 'acreditar_USD'].includes(c.key))).slice(0, 6)
        .map(c => { const mon = c.key.endsWith('USD') || c.key === 'USD' ? 'USD' : (c.key.endsWith('CRC') || c.key === 'CRC' ? 'CRC' : this.p); const s = rows.reduce((a, r) => a + (+(r.monto ? r.monto[c.key] : r[c.key]) || 0), 0); return { t: c.label, v: money(s, mon) }; });
      descargarReporte(formato, { titulo: 'Reporte ejecutivo · ' + t[1], subtitulo: t[2], periodo: etiquetaPeriodo(this.r), cols: cols.map(c => ({ ...c, fmt: c.fmt === 'money' ? (v, r) => money(v, (r && r.moneda) || this.p) : c.fmt })), rows, kpis: this.kpisResumen(), totales: sumas, nota: this.r.tc_disponible ? 'Tipo de cambio del día aplicado: ' + money(this.r.tc, 'CRC') + ' por dólar.' : null, archivo: 'ejecutivo_' + nombre });
    },
    exportar(k, nombre, formato) {
      if (formato && formato !== 'xlsx') return this.documento(k, nombre, formato);
      const rows = this.filas(k); if (!rows.length) return;
      const cols = this.cols[k].map(c => ({ ...c, csv: c.fmt === 'date' ? v => fecha(v) : (typeof c.fmt === 'function' && (c.key === 'CRC' || c.key === 'USD') && rows[0].monto) ? (v, r) => r.monto[c.key] : undefined }));
      descargarTabla(formato === 'xlsx' ? 'xlsx' : 'csv', 'ejecutivo_' + nombre, cols, rows, { titulo: 'Reporte ejecutivo · ' + nombre, registrar: archivo => { const l = mock.get('reportes_exportables', []); l.unshift({ archivo, reporte: 'Reporte ejecutivo · ' + nombre, fecha: new Date().toISOString() }); mock.set('reportes_exportables', l.slice(0, 30)); } });
    },
    imprimir() { window.print(); },
  },
  watch: { periodo() { if (this.periodo !== 'rango') this.cargar(); }, desde() { if (this.periodo === 'rango') this.cargar(); }, hasta() { if (this.periodo === 'rango') this.cargar(); } },
  created() { this.cargar(); registrarReciente('ejecutivo', { slug: '', nombre: 'Reporte ejecutivo' }); },
  template: `
  <div class="page">
    <PageHead title="Reporte ejecutivo" :sub="'Las cifras del Inicio con su detalle' + (r ? ', del ' + etiquetaPeriodo(r) : '') + '. Los equivalentes usan el tipo de cambio de cada comprobante y, para lo emitido en colones, el del día.'" :crumbs="[{label:'Reportes',to:'/reportes'},{label:'Reporte ejecutivo'}]">
      <select class="inp" v-model="periodo"><option v-for="p in periodos" :value="p[0]">{{p[1]}}</option></select>
      <template v-if="periodo==='rango'"><input type="date" class="inp" v-model="desde"><input type="date" class="inp" v-model="hasta"></template>
      <button class="btn sec" @click="exportar('ventas', 'ventas', 'pdf')" :disabled="!r">⤓ PDF</button><button class="btn sec" @click="exportar('ventas', 'ventas', 'docx')" :disabled="!r">⤓ Word</button>
      <button class="btn ghost" @click="imprimir">Imprimir</button>
    </PageHead>
    <div class="alert warn" v-if="error">No se pudo cargar el reporte: {{error}}</div>
    <template v-if="r">
      <div class="alert info" v-if="otras.length"><b>Monedas:</b> cada cifra se muestra en {{p}} y en {{otras.join(', ')}}. <span v-if="r.tc_disponible">Tipo de cambio del día aplicado: {{money(r.tc, 'CRC')}} por dólar.</span><span v-else>No hay tipo de cambio del día: los equivalentes usan el de cada comprobante.</span></div>
      <div class="dash" style="margin-bottom:18px">
        <div class="kpi w3"><div class="t">Total de ventas</div><Monto :m="r.ventas" :otras="otras" grande></Monto><div class="d">{{r.documentos}} documentos · {{r.variacion === null ? 'sin período anterior' : (r.variacion >= 0 ? '+' : '') + fmt(r.variacion, 1) + ' % vs. anterior'}}</div></div>
        <div class="kpi w3"><div class="t">Cuentas por cobrar</div><Monto :m="r.cxc.total" :otras="otras" grande></Monto><div class="d">vencidas {{money(r.cxc.vencido[p], p)}} · {{r.cxc.docs}} documentos</div></div>
        <div class="kpi w3"><div class="t">Cuentas por pagar</div><Monto :m="r.cxp.total" :otras="otras" grande></Monto><div class="d">vencidas {{money(r.cxp.vencido[p], p)}} · {{r.cxp.docs}} documentos</div></div>
        <div class="kpi w3"><div class="t">IVA del período</div><Monto :m="r.iva.neto" :otras="otras" grande></Monto><div class="d">cobrado {{money(r.iva.debito[p], p)}} − acreditable {{money(r.iva.credito[p], p)}}</div></div>
      </div>

      <div class="card" v-for="t in temas" :key="t[0]" :id="'tema-' + t[0]" :style="tema===t[0] ? 'border-color:var(--primary)' : ''">
        <div class="row" style="justify-content:space-between;align-items:center;cursor:pointer;gap:10px;flex-wrap:wrap" @click="alternar(t[0])">
          <div><h2 style="margin:0">{{abierto(t[0]) ? '▾' : '▸'}} {{t[1]}}</h2><div class="small muted">{{t[2]}}</div></div>
          <div class="row" style="gap:8px;align-items:center" @click.stop>
            <Monto v-if="t[0]==='ventas'" :m="r.ventas" :otras="otras"></Monto>
            <Monto v-else-if="t[0]==='devoluciones'" :m="r.devoluciones" :otras="otras"></Monto>
            <Monto v-else-if="t[0]==='cxc'" :m="r.cxc.total" :otras="otras"></Monto>
            <Monto v-else-if="t[0]==='cxp'" :m="r.cxp.total" :otras="otras"></Monto>
            <Monto v-else-if="t[0]==='iva'" :m="r.iva.neto" :otras="otras"></Monto>
            <Monto v-else-if="t[0]==='egresos'" :m="r.egresos" :otras="otras"></Monto>
            <span v-else-if="t[0]==='items'" class="v" style="font-size:18px">{{fmt(r.unidades, 0)}} unidades</span>
            <span v-else-if="t[0]==='clientes'" class="v" style="font-size:18px">{{r.clientes}} clientes</span>
          </div>
        </div>
        <div v-if="abierto(t[0])" style="margin-top:12px">
          <template v-if="t[0]==='iva'">
            <div class="grid cols-3" style="margin-bottom:12px">
              <div><div class="small muted">IVA cobrado en lo emitido (ventas − devoluciones)</div><b><Monto :m="r.iva.debito" :otras="otras"></Monto></b><div class="small muted">{{r.iva.docs_emitidos}} documentos</div></div>
              <div><div class="small muted">IVA acreditable en lo recibido y aceptado + facturas de compra</div><b><Monto :m="r.iva.credito" :otras="otras"></Monto></b><div class="small muted">{{r.iva.docs_recibidos}} documentos</div></div>
              <div><div class="small muted">IVA del período (a pagar si es positivo, a favor si es negativo)</div><b><Monto :m="r.iva.neto" :otras="otras"></Monto></b></div>
            </div>
            <div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:8px 0">Emitidos</h3><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar('iva_emitidos', 'iva_emitidos', 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar('iva_emitidos', 'iva_emitidos', 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar('iva_emitidos', 'iva_emitidos', 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar('iva_emitidos', 'iva_emitidos')">⤓ CSV</button></span></div>
            <DataTable :rows="filas('iva_emitidos')" :columns="cols.iva_emitidos" :pageSize="15" emptyTitle="Sin comprobantes emitidos en el período"></DataTable>
            <div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:14px 0 8px">Recibidos y aceptados, y facturas de compra</h3><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar('iva_recibidos', 'iva_recibidos', 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar('iva_recibidos', 'iva_recibidos', 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar('iva_recibidos', 'iva_recibidos', 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar('iva_recibidos', 'iva_recibidos')">⤓ CSV</button></span></div>
            <DataTable :rows="filas('iva_recibidos')" :columns="cols.iva_recibidos" :pageSize="15" emptyTitle="Sin comprobantes aceptados en el período" emptyText="Acepte los comprobantes de sus proveedores en Gastos › Recepción de comprobantes para que su IVA cuente como crédito."></DataTable>
          </template>
          <template v-else-if="t[0]==='egresos'">
            <div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:8px 0">Por proveedor</h3><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar('proveedores', 'gastos_por_proveedor', 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar('proveedores', 'gastos_por_proveedor', 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar('proveedores', 'gastos_por_proveedor', 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar('proveedores', 'gastos_por_proveedor')">⤓ CSV</button></span></div>
            <DataTable :rows="filas('proveedores')" :columns="cols.proveedores" :pageSize="10" emptyTitle="Sin egresos en el período"></DataTable>
            <div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:14px 0 8px">Comprobantes</h3><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar('egresos', 'egresos', 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar('egresos', 'egresos', 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar('egresos', 'egresos', 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar('egresos', 'egresos')">⤓ CSV</button></span></div>
            <DataTable :rows="filas('egresos')" :columns="cols.egresos" :pageSize="15" emptyTitle="Sin egresos en el período"></DataTable>
          </template>
          <template v-else-if="t[0]==='flujo'">
            <div class="chart" style="height:160px"><div class="b" v-for="d in serie.slice(-31)" :key="d.k"><div class="row" style="align-items:flex-end;gap:2px;width:100%;height:100%"><i :style="{height:d.hi+'%'}" :title="'Ingresos ' + money(d.ingresos, p)"></i><i class="red" :style="{height:d.he+'%'}" :title="'Egresos ' + money(d.egresos, p)"></i></div>{{d.label}}</div><Empty v-if="!serie.length" icon="📊" title="Sin transacciones en el período" style="width:100%;padding:20px"></Empty></div>
            <div class="legend" style="margin-bottom:8px"><span><i style="background:var(--primary)"></i>Ingresos</span><span><i style="background:var(--danger)"></i>Egresos</span><span class="muted">en {{p}}</span></div>
            <div class="row end"><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar('flujo', 'flujo', 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar('flujo', 'flujo', 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar('flujo', 'flujo', 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar('flujo', 'flujo')">⤓ CSV</button></span></div>
            <DataTable :rows="filas('flujo')" :columns="cols.flujo" :pageSize="31" emptyTitle="Sin transacciones en el período"></DataTable>
          </template>
          <template v-else>
            <div class="row end" style="margin-bottom:6px"><span class="row" style="gap:6px"><button class="btn sm sec" @click="exportar(t[0], t[0], 'pdf')">⤓ PDF</button><button class="btn sm sec" @click="exportar(t[0], t[0], 'docx')">⤓ Word</button><button class="btn sm ghost" @click="exportar(t[0], t[0], 'xlsx')">⤓ Excel</button><button class="btn sm ghost" @click="exportar(t[0], t[0])">⤓ CSV</button></span></div>
            <DataTable :rows="filas(t[0])" :columns="cols[t[0]]" :pageSize="15" :emptyTitle="'Sin registros' + (t[0]==='cxc' || t[0]==='cxp' ? ' pendientes' : ' en el período')"></DataTable>
          </template>
        </div>
      </div>
    </template>
    <div class="card" v-else-if="cargando"><p class="muted">Calculando…</p></div>
  </div>`,
};
