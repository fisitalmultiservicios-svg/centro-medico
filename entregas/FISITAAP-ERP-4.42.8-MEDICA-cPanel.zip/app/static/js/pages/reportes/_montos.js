// Montos en varias monedas (Inicio y Reporte ejecutivo). El servidor entrega cada cifra consolidada en CRC y USD más el desglose
// nativo; aquí se muestra en la moneda principal de la empresa y, debajo, en las otras monedas que aparecen en el período.
import { money, fmt, fecha, monedas, hoy, abrirArchivo, toast, mock } from '../../api.js';
import { sesion } from '../../app.js';

export const PERIODOS = [['mes', 'Mes actual'], ['mes-ant', 'Mes anterior'], ['bimestre', 'Bimestre'], ['trimestre', 'Trimestre'], ['semestre', 'Semestre'], ['anio', 'Año'], ['rango', 'Rango de fechas']];

export function principal() { return (monedas.principal() || { codigo: 'CRC' }).codigo; }
export function otrasMonedas(r) { const p = principal(); return ((r && r.monedas_usadas) || []).filter(c => c !== p); }
export function valor(m, moneda) { if (!m) return 0; if (m[moneda] !== undefined) return m[moneda]; return (m.nativo && m.nativo[moneda]) || 0; }
export function etiquetaMoneda(c) { return { CRC: 'colones', USD: 'dólares' }[c] || c; }

// Parámetros de período para la URL y para la API.
export function queryPeriodo(periodo, desde, hasta) {
  return 'periodo=' + periodo + (periodo === 'rango' ? '&desde=' + (desde || hoy()) + '&hasta=' + (hasta || hoy()) : '');
}
export function periodoDesdeParams(params) {
  const p = (params && params.periodo) || 'mes';
  return { periodo: PERIODOS.some(x => x[0] === p) ? p : 'mes', desde: (params && params.desde) || hoy().slice(0, 8) + '01', hasta: (params && params.hasta) || hoy() };
}
export function etiquetaPeriodo(r) { return r ? r.desde.split('-').reverse().join('/') + ' al ' + r.hasta.split('-').reverse().join('/') : ''; }

// Agrupa la serie diaria por mes cuando el período es largo.
export function serie(r, maxPuntos = 31) {
  const dias = (r && r.por_dia) || [];
  if (!dias.length) return [];
  const largo = r.desde && r.hasta && (new Date(r.hasta) - new Date(r.desde)) / 86400000 > 62;
  const p = principal();
  const m = {};
  for (const d of dias) {
    const k = largo ? d.fecha.slice(0, 7) : d.fecha;
    const x = m[k] || (m[k] = { k, ingresos: 0, egresos: 0 });
    x.ingresos += valor(d.ingresos, p); x.egresos += valor(d.egresos, p);
  }
  const keys = Object.keys(m).sort().slice(-maxPuntos);
  const max = Math.max(1, ...keys.map(k => Math.max(m[k].ingresos, m[k].egresos)));
  return keys.map(k => ({ ...m[k], label: largo ? k.slice(5) + '/' + k.slice(0, 4) : k.slice(8) + '/' + k.slice(5, 7), hi: Math.round(m[k].ingresos / max * 100), he: Math.round(m[k].egresos / max * 100) }));
}

// CSV con BOM y ; (Excel en español). Registra el archivo en el historial de exportables de Reportes.
// 3.98: Excel con formato (números como números, totales, filtro). cols: [{ key, label, num, sumar, fecha, valor(r) }]
export async function descargarExcel(nombre, { titulo, subtitulo, periodo, cols, rows, tipo_cambio }) {
  const columnas = cols.map(c => ({ key: c.key, label: c.label, num: !!c.num, sumar: !!c.sumar, fecha: !!c.fecha }));
  const filas = rows.slice(0, 20000).map(r => Object.fromEntries(cols.map(c => [c.key, typeof c.valor === 'function' ? c.valor(r) : r[c.key]])));
  const archivo = String(nombre || titulo || 'reporte').replace(/[^\w-]+/g, '_') + '_' + hoy() + '.xlsx';
  await abrirArchivo('/api/reportes/xlsx', archivo, { titulo, subtitulo: subtitulo || null, periodo: periodo || null, columnas, filas, archivo: String(nombre || '').slice(0, 80) || null, tipo_cambio: tipo_cambio || null });
  return archivo;
}

export function descargarCSV(nombre, cols, rows, registrar, pie) {
  // números con coma decimal y sin separador de miles: Excel en español los lee como número (R326)
  const enc = v => { const s = v === null || v === undefined ? '' : (typeof v === 'number' ? String(Math.round(v * 100000) / 100000).replace('.', ',') : String(v)); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const csv = [cols.map(c => enc(c.label)).join(';')].concat(rows.map(r => cols.map(c => enc(typeof c.csv === 'function' ? c.csv(r[c.key], r) : r[c.key])).join(';'))).join('\r\n');
  const archivo = nombre + '_' + hoy() + '.csv';
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv + (pie ? '\r\n\r\n' + enc(pie) : '')], { type: 'text/csv;charset=utf-8' })); a.download = archivo; a.click(); URL.revokeObjectURL(a.href);
  if (registrar) registrar(archivo);
  return archivo;
}

// 4.17: toda lista se exporta en PDF, Excel y CSV con estas funciones. cols: las de la tabla ({ key, label, num, fmt, csv }).
// descargarTabla: el formato ya elegido por un botón. exportarTabla: pregunta el formato. exportarFilas: lo mismo con encabezados y filas sueltas.
export function elegirFormato(titulo) {
  return new Promise(resolver => {
    const fondo = document.createElement('div'); fondo.className = 'overlay';
    const caja = document.createElement('div'); caja.className = 'modal'; caja.style.maxWidth = '420px';
    const cab = document.createElement('div'); cab.className = 'm-head';
    const h = document.createElement('h3'); h.textContent = titulo || 'Exportar';
    const x = document.createElement('button'); x.className = 'x'; x.textContent = '×';
    cab.append(h, x);
    const cuerpo = document.createElement('div'); cuerpo.className = 'm-body';
    const nota = document.createElement('p'); nota.className = 'small muted'; nota.style.marginTop = '0'; nota.textContent = '¿En qué formato lo quiere?';
    const fila = document.createElement('div'); fila.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap';
    const cerrar = f => { document.removeEventListener('keydown', tecla); fondo.remove(); resolver(f); };
    const tecla = e => { if (e.key === 'Escape') cerrar(null); };
    for (const [f, t] of [['pdf', 'PDF'], ['xlsx', 'Excel'], ['csv', 'CSV']]) {
      const b = document.createElement('button'); b.className = 'btn sec'; b.dataset.formato = f; b.textContent = t; b.style.flex = '1'; b.onclick = () => cerrar(f); fila.append(b);
    }
    x.onclick = () => cerrar(null);
    fondo.addEventListener('mousedown', e => { if (e.target === fondo) cerrar(null); });
    document.addEventListener('keydown', tecla);
    cuerpo.append(nota, fila); caja.append(cab, cuerpo); fondo.append(caja); document.body.append(fondo);
  });
}

function tituloDe(nombre) { const t = String(nombre || 'Reporte').replace(/[_-]+/g, ' ').trim(); return t.charAt(0).toUpperCase() + t.slice(1); }

export async function descargarTabla(formato, nombre, cols, rows, opts = {}) {
  try {
    const titulo = String(opts.titulo || tituloDe(nombre)).slice(0, 120), base = String(nombre || 'reporte');
    // lo mismo que deja el CSV: la fecha legible y el dinero como número
    const columnas = cols.filter(c => c.key && c.key !== 'acciones').map(c => ({ ...c, csv: c.csv || (c.fmt === 'date' ? v => fecha(v) : (c.fmt === 'money' ? v => +v || 0 : undefined)) }));
    let archivo;
    if (formato === 'csv') {
      archivo = descargarCSV(base, columnas, rows);
    } else if (formato === 'xlsx') {
      const crudo = (c, r) => (typeof c.csv === 'function' ? c.csv(r[c.key], r) : r[c.key]);
      const vacio = v => v === null || v === undefined || v === '';
      const esNum = c => !!c.num || c.fmt === 'money' || (rows.some(r => typeof crudo(c, r) === 'number') && rows.every(r => vacio(crudo(c, r)) || typeof crudo(c, r) === 'number'));
      archivo = await descargarExcel(base, { titulo, periodo: opts.periodo, cols: columnas.map(c => ({ key: c.key, label: c.etiqueta || c.label, num: esNum(c), sumar: !!c.sumar, valor: r => crudo(c, r) })), rows });
    } else {
      if (rows.length > 5000) { toast('El PDF admite hasta 5.000 filas: use Excel o CSV, o acorte el período', 'err'); return null; }
      const texto = (c, r) => {
        const v = r[c.key];
        if (c.fmt === 'money') return money(v || 0, r.moneda || principal());   // cada fila en su moneda
        if (typeof c.csv === 'function' && typeof c.fmt !== 'function' && c.fmt !== 'date') { const x = c.csv(v, r); return typeof x === 'number' ? fmt(x, 2) : String(x ?? ''); }
        if (typeof v === 'number' && c.num && !c.fmt) return fmt(v, 2);
        return String(celdaTexto(r, c) ?? '');
      };
      archivo = base.replace(/[^\w-]+/g, '_') + '_' + hoy() + '.pdf';
      await abrirArchivo('/api/reportes/pdf', archivo, { titulo, periodo: opts.periodo || null, columnas: columnas.map(c => ({ key: c.key, label: c.etiqueta || c.label, num: !!c.num })),
        filas: rows.map(r => Object.fromEntries(columnas.map(c => [c.key, texto(c, r)]))), archivo: base.slice(0, 80) });
    }
    if (opts.registrar) opts.registrar(archivo);
    toast('Archivo ' + archivo + ' descargado', 'ok');
    return archivo;
  } catch (e) { toast(e.message, 'err'); return null; }
}

export async function exportarTabla(nombre, cols, rows, opts = {}) {
  if (!rows.length) return toast('No hay datos para exportar');
  const formato = await elegirFormato(opts.titulo ? 'Exportar: ' + opts.titulo : 'Exportar');
  return formato ? descargarTabla(formato, nombre, cols, rows, opts) : null;
}

export function exportarFilas(nombre, encabezados, filas, opts = {}) {
  const cols = encabezados.map((label, i) => ({ key: 'c' + i, label, etiqueta: opts.etiquetas && opts.etiquetas[i], num: (opts.num || []).includes(i) }));
  return exportarTabla(nombre, cols, filas.map(f => Object.fromEntries(f.map((v, i) => ['c' + i, v]))), opts);
}

// Celda tal como la muestra DataTable (dinero, fecha, función) para los reportes en PDF/Word.
export function celdaTexto(row, c) {
  const v = row[c.key];
  if (typeof c.fmt === 'function') return c.fmt(v, row);
  if (c.fmt === 'money') return money(v, principal());
  if (c.fmt === 'date') return fecha(v);
  if (c.fmt === 'num') return fmt(v, 0);
  return v === null || v === undefined ? '' : String(v);
}
// 4.7: historial de exportables. Lo descargado en Recursos humanos (fichas y liquidaciones llevan el nombre y la cédula del empleado)
// se anota en rrhh_exportables, que el servidor solo entrega a quien tiene Recursos humanos; reportes_exportables lo recibe cualquier
// usuario con «ver». La opción «privado» lo pide así; sin ella decide la pantalla desde donde se descargó (#/rrhh/…).
export const CLAVE_EXPORTABLES = 'reportes_exportables';
export const CLAVE_EXPORTABLES_RRHH = 'rrhh_exportables';
// Lo anotado antes de la 4.7 en el historial general con datos de un empleado: su ficha (nombre y cédula) o su liquidación
const ARCHIVO_RRHH = /^empleado_/;
const TITULO_RRHH = /^(Ficha del empleado|Liquidación (?!a proveedores))/;
export function esExportableRRHH(x) { return !!x && (ARCHIVO_RRHH.test(String(x.archivo || '')) || TITULO_RRHH.test(String(x.reporte || ''))); }
export function claveExportables(privado) {
  let h = '';
  try { h = String(location.hash || ''); } catch { h = ''; }
  return (privado || h.startsWith('#/rrhh')) ? CLAVE_EXPORTABLES_RRHH : CLAVE_EXPORTABLES;
}
function listaExportables(clave) { const v = mock.get(clave, []); return Array.isArray(v) ? v : []; }
// Lo viejo con datos de un empleado que siga en el general, junto al historial de Recursos humanos como lo hace el arranque del
// servidor (mover_exportables_rrhh): sin repetir, del más reciente al más viejo y 30 como máximo.
function juntarConRRHH(viejos) {
  const vistos = new Set(), juntos = [];
  const todos = [...viejos, ...listaExportables(CLAVE_EXPORTABLES_RRHH)].filter(x => x && typeof x === 'object');
  for (const x of todos.sort((a, b) => String(b.fecha || '').localeCompare(String(a.fecha || '')))) {
    const k = [x.archivo, x.reporte, x.fecha].map(v => String(v || '')).join('|');
    if (!vistos.has(k)) { vistos.add(k); juntos.push(x); }
  }
  return juntos.slice(0, 30);
}
// «privado»: true lo anota siempre en el historial de Recursos humanos; también puede venir la clave ya decidida (descargarReporte la
// toma al pedir el archivo, no cuando llega). Una descarga general no borra lo viejo con datos de un empleado que encuentre en el general:
// lo pasa al historial de Recursos humanos si este usuario tiene ese permiso; si no lo tiene (no puede escribir ese historial), lo saca
// del general igual, para no dejar nombres de empleados a la vista de cualquier usuario.
export function registrarExportable(archivo, reporte, privado) {
  const clave = [CLAVE_EXPORTABLES, CLAVE_EXPORTABLES_RRHH].includes(privado) ? privado : claveExportables(privado), item = { archivo, reporte, fecha: new Date().toISOString() };
  const general = listaExportables(CLAVE_EXPORTABLES), viejos = general.filter(esExportableRRHH), limpio = general.filter(x => !esExportableRRHH(x));
  if (clave === CLAVE_EXPORTABLES) {
    if (viejos.length && sesion.puede('rrhh')) mock.set(CLAVE_EXPORTABLES_RRHH, juntarConRRHH(viejos));
    mock.set(CLAVE_EXPORTABLES, [item, ...limpio].slice(0, 30));
    return clave;
  }
  if (viejos.length) mock.set(CLAVE_EXPORTABLES, limpio);
  mock.set(clave, [item, ...viejos, ...listaExportables(clave)].slice(0, 30));
  return clave;
}
// Reporte formateado (encabezado de la empresa, cifras, tabla y totales) en PDF o Word; lo arma el servidor.
export async function descargarReporte(formato, { titulo, subtitulo, periodo, cols, rows, kpis, totales, nota, archivo, tipo_cambio, firma, secciones, privado }) {
  const columnas = cols.map(c => ({ key: c.key, label: c.label, num: !!c.num }));
  const filas = rows.slice(0, 5000).map(r => Object.fromEntries(cols.map(c => [c.key, String(celdaTexto(r, c) ?? '')])));
  const base = (archivo || titulo || 'reporte').replace(/[^\w-]+/g, '_') + '_' + hoy();
  const nombre = base + '.' + formato;
  // 4.7: el historial (general o de Recursos humanos) se decide al pedir el archivo; si se cambia de pantalla mientras el servidor lo arma, no cambia
  const clave = claveExportables(privado);
  try {
    await abrirArchivo('/api/reportes/' + formato, nombre, { tipo_cambio: tipo_cambio || null, titulo, subtitulo: subtitulo || null, periodo: periodo || null, columnas, filas, secciones: (secciones || []).map(s => ({ titulo: s.titulo, columnas: s.columnas.map(c => ({ key: c.key, label: c.label, num: !!c.num })), filas: s.filas.map(r => Object.fromEntries(s.columnas.map(c => [c.key, String(r[c.key] ?? '')]))), totales: (s.totales || []).map(k => ({ t: String(k.t), v: String(k.v) })), nota: s.nota || null })), kpis: (kpis || []).map(k => ({ t: String(k.t), v: String(k.v) })), totales: (totales || []).map(k => ({ t: String(k.t), v: String(k.v) })), nota: nota || null, archivo: base,
      firma: firma ? { nombre: String(firma.nombre || '').slice(0, 90), cargo: String(firma.cargo || '').slice(0, 90) } : null });   // 4.21: línea de firma (constancia salarial); sin ella el documento sale igual
    registrarExportable(nombre, titulo, clave);   // 4.7: lo de Recursos humanos no queda en el historial que ve cualquier usuario
    toast('Archivo ' + nombre + ' descargado', 'ok');
    if (rows.length > 5000) toast('El reporte tiene más de 5.000 filas; se incluyeron las primeras 5.000', 'err');
  } catch (e) { toast('No se pudo generar el reporte: ' + e.message, 'err'); }
}

// <Monto :m="r.ventas" :otras="otras" grande> → ₡ en la moneda principal y, debajo, las otras monedas; el título muestra el desglose nativo.
export const Monto = {
  props: { m: Object, otras: { type: Array, default: () => [] }, grande: Boolean, signo: Boolean },
  computed: { p() { return principal(); } },
  methods: {
    txt(moneda) { const v = valor(this.m, moneda); return (this.signo && v > 0 ? '+' : '') + money(v, moneda); },
    titulo() { const n = (this.m && this.m.nativo) || {}; const partes = Object.entries(n).filter(([, v]) => Math.abs(v) > 0.004).map(([c, v]) => 'Emitido en ' + etiquetaMoneda(c) + ': ' + money(v, c)); return partes.length ? partes.join(' · ') : ''; },
  },
  template: `<span :title="titulo()" style="display:inline-block"><span :class="grande ? 'v' : ''" style="display:block">{{txt(p)}}</span><span v-for="o in otras" :key="o" class="d" style="display:block">{{txt(o)}}</span></span>`,
};

export { money, fmt };

// 4.3: imprimir un reporte en la impresora de tiquetes (agente local) o en la del equipo (el navegador deja elegirla)
import { porAgente, imprimirAgente } from '../pos/_agente.js';
import { impresoras } from '../pos/_datos.js';
export function impresorasReporte() {
  if (_repAqui && _repAqui.equipo()) return impresorasReporteAqui(impresoras(), _repAqui);   // 9c (J1): en el programa, como valen en esta computadora
  return impresoras().filter(i => i.activa !== false && i.uso !== 'etiquetas' && porAgente(i));   // 4.24: la de etiquetas no imprime reportes
}
// 9c (J1): en el programa, las impresoras para reportes y cierres TAL COMO VALEN AQUÍ: las de la empresa con sus ajustes de esta computadora
// (una que en la web es «del navegador» y aquí está por Windows o por red sí aparece) y las de tiquetes solo de esta computadora. La primera
// es la «Impresora de tiquetes y facturas de esta computadora» si está elegida. A = el módulo pos/_agente.js; eq = lo de esta computadora.
let _repAqui = null;   // pos/_agente.js, cuando ya se cargó la impresión de esta computadora (solo en el programa)
export function impresorasReporteAqui(lista, A, eq) {
  const e = eq === undefined ? A.equipo() : eq; if (!e) return [];
  const sirve = i => !!i && !!i.nombre && i.activa !== false && i.uso !== 'etiquetas';
  const todas = [...(lista || []).filter(sirve).map(i => A.impresoraAqui(i, e)), ...(e.propias || []).filter(i => sirve(i) && i.uso === 'comprobante')].filter(porAgente);
  const elegida = e.tiquetes ? todas.find(i => String(i.id) === String(e.tiquetes) && i.uso === 'comprobante') : null;
  return elegida ? [elegida, ...todas.filter(i => i !== elegida)] : todas;
}
// Se llama al montar Reportes de la caja y Cierres de caja: en el programa carga lo de esta computadora (en la web no pide nada y queda como antes)
export async function cargarImpresorasReporte() {
  if (!(sesion && sesion.empresaInfo && sesion.empresaInfo.es_local)) return false;
  try {
    const A = await import('../pos/_agente.js');
    if (!A.cargarEquipo || !A.equipo || !A.impresoraAqui) return false;
    await A.cargarEquipo().catch(() => {});
    _repAqui = A.equipo() ? A : null;
    return !!_repAqui;
  } catch { return false; }
}
function celdas(cols, r) { return cols.map(c => ({ num: !!c.num, v: String(celdaTexto(r, c) ?? '') })); }
export function docReporteTermico({ titulo, subtitulo, periodo, cols, rows, kpis, totales, nota, secciones }) {
  const b = [{ t: 'texto', x: String(titulo || 'Reporte').toUpperCase(), al: 'C', b: true, tam: 2 }];
  if (periodo) b.push({ t: 'texto', x: periodo, al: 'C' });
  if (subtitulo) b.push({ t: 'texto', x: subtitulo, al: 'C' });
  b.push({ t: 'texto', x: new Date().toLocaleString('es-CR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }), al: 'C' }, { t: 'linea' });
  for (const k of kpis || []) b.push({ t: 'par', i: String(k.t), d: String(k.v) });
  if ((kpis || []).length) b.push({ t: 'linea' });
  const tabla = (columnas, filas, tots) => {
    const txtCols = columnas.filter(c => !c.num), numCols = columnas.filter(c => c.num);
    for (const r of filas.slice(0, 400)) {
      const cs = celdas(columnas, r), tx = txtCols.map(c => cs[columnas.indexOf(c)].v.trim()).filter(Boolean).join(' · ');   // todas las columnas de texto
      if (!numCols.length) b.push({ t: 'texto', x: tx });
      else if (numCols.length === 1) b.push({ t: 'par', i: tx, d: cs[columnas.indexOf(numCols[0])].v });
      else { b.push({ t: 'texto', x: tx, b: true }); for (const c of numCols) b.push({ t: 'par', i: '  ' + c.label, d: cs[columnas.indexOf(c)].v }); }
    }
    if (filas.length > 400) b.push({ t: 'texto', x: '… ' + (filas.length - 400) + ' fila(s) más: vea el reporte en pantalla', al: 'C' });
    for (const x of tots || []) b.push({ t: 'par', i: String(x.t), d: String(x.v), b: true });
  };
  if ((secciones || []).length) for (const s of secciones) { b.push({ t: 'texto', x: s.titulo, al: 'C', b: true }); tabla(s.columnas, s.filas.map(f => ({ ...f })), s.totales); b.push({ t: 'linea' }); }
  else { tabla(cols || [], rows || [], totales); b.push({ t: 'linea' }); }
  if (nota) b.push({ t: 'texto', x: nota });
  return { bloques: b };
}
export function htmlReporte({ titulo, subtitulo, periodo, cols, rows, kpis, totales, nota, secciones }, empresa) {
  const esc = x => String(x ?? '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));
  const tabla = (columnas, filas, tots) => '<table><thead><tr>' + columnas.map(c => '<th' + (c.num ? ' class="n"' : '') + '>' + esc(c.label) + '</th>').join('') + '</tr></thead><tbody>'
    + filas.map(r => '<tr>' + celdas(columnas, r).map(c => '<td' + (c.num ? ' class="n"' : '') + '>' + esc(c.v) + '</td>').join('') + '</tr>').join('') + '</tbody>'
    + ((tots || []).length ? '<tfoot>' + tots.map(x => '<tr><th colspan="' + Math.max(1, columnas.length - 1) + '">' + esc(x.t) + '</th><th class="n">' + esc(x.v) + '</th></tr>').join('') + '</tfoot>' : '') + '</table>';
  const e = empresa || {};
  return '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>' + esc(titulo) + '</title><style>body{font-family:Arial,sans-serif;font-size:12px;margin:18px;color:#111}h1{font-size:18px;margin:0 0 2px}h2{font-size:14px;margin:16px 0 6px}.m{color:#555;margin:0 0 10px}table{width:100%;border-collapse:collapse;margin:6px 0 12px}th,td{padding:4px 6px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}th{background:#f3f4f6}.n{text-align:right;font-variant-numeric:tabular-nums}tfoot th{border-top:2px solid #333}.kpis{display:flex;gap:18px;flex-wrap:wrap;margin:8px 0 12px}.kpi b{display:block;font-size:15px}@media print{body{margin:8mm}}</style></head><body>'
    + '<div class="m" style="font-size:11px">' + esc(e.nombre_comercial || e.nombre || '') + (e.numero_id ? ' · ' + esc(e.numero_id) : '') + '</div><h1>' + esc(titulo) + '</h1><p class="m">' + esc([periodo, subtitulo].filter(Boolean).join(' · ')) + '</p>'
    + ((kpis || []).length ? '<div class="kpis">' + kpis.map(k => '<div class="kpi"><span>' + esc(k.t) + '</span><b>' + esc(k.v) + '</b></div>').join('') + '</div>' : '')
    + ((secciones || []).length ? secciones.map(s => '<h2>' + esc(s.titulo) + '</h2>' + tabla(s.columnas, s.filas, s.totales)).join('') : tabla(cols || [], rows || [], totales))
    + (nota ? '<p class="m">' + esc(nota) + '</p>' : '') + '<p class="m" style="font-size:10px">Impreso ' + esc(new Date().toLocaleString('es-CR')) + '</p></body></html>';
}
// impresora: una de impresorasReporte() (térmica por el agente) o vacío = la del equipo (se abre el diálogo de impresión y ahí se elige)
export async function imprimirReporte(datos, impresora, empresa) {
  // 4.25: en el programa, la impresora como está conectada en esta computadora (la función única de pos/_agente.js; se toma al usarla)
  // 9b (U16): antes se cargaba la impresión de esta computadora (si en la pestaña no se abrió la caja, el reporte salía con la conexión de la empresa)
  if (impresora) { try { const A = await import('../pos/_agente.js'); if (A.cargarEquipo) await A.cargarEquipo().catch(() => {}); if (A.impresoraAqui) impresora = A.impresoraAqui(impresora); } catch { /* como venía */ } }
  if (impresora && porAgente(impresora)) { await imprimirAgente(impresora, docReporteTermico(datos)); return 'agente'; }
  const w = window.open('', '_blank'); if (!w) throw new Error('Permita las ventanas emergentes para imprimir el reporte');
  w.document.write(htmlReporte(datos, empresa)); w.document.close(); setTimeout(() => { try { w.focus(); w.print(); } catch {} }, 400);
  return 'navegador';
}
