// Reportes — página genérica de reporte (params.cat / params.rep). Todos los reportes del catálogo leen datos reales:
// comprobantes emitidos (/api/comprobantes), pagos (/api/pagos), resumen del negocio (/api/resumen), IVA por tarifa
// (/api/resumen/iva), inventario (/api/inventario/*) y los registros de la empresa (asientos y catálogo contable, bancos y
// movimientos, compras y pagos a proveedores, tareas). Montos en la moneda principal (cada documento convertido con su
// tipo de cambio); la declaración de IVA siempre en colones.
import { api, toast, money, fmt, fecha, hoy, mock, monedas, sumarDias, sumarMeses, abrirArchivo, verDocumento } from '../../api.js';
import { store, rutaPermitida } from '../../app.js';
import { CATALOGO, buscarReporte, registrarReciente, puedeCategoria, puedeReporte } from './hub.js';
import { descargarReporte, descargarCSV, descargarExcel, valor, imprimirReporte, impresorasReporte } from './_montos.js';
// 9c (J4): el aviso de una impresión que no salió, con la ayuda común de pos/_agente.js (se carga al usarla, como el resto de la impresión de esta pantalla)
async function avisoImpresion(prefijo, e) { try { const A = await import('../pos/_agente.js'); if (A.avisoImpresion) return A.avisoImpresion(prefijo, e); } catch { /* como antes */ } return prefijo + ((e && e.message) || ''); }
import { planCuentas } from '../contabilidad/catalogo.js';
import { aPrincipal } from '../contabilidad/automaticos.js';
import { cargarAsientos as cargarAsientosTodos, planConUsadas, balanceGeneral, estadoResultados, balancePrueba, libroMayor, auxiliarTerceros, saldos, NOMBRE_RAIZ } from '../contabilidad/_mayor.js';
import { centrosCosto } from '../contabilidad/centros-costo.js';
import { presupuesto } from '../contabilidad/presupuesto.js';
import { servicioPorDia, servicioPorSalonero } from '../pos/_datos.js';
import { filasRegistro } from '../gastos/_registro.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const mesLabel = ym => { const [a, m] = String(ym).split('-'); return (MESES[+m - 1] || m) + ' ' + a; };
const finMes = ym => { const [a, m] = ym.split('-').map(Number); return ym + '-' + String(new Date(a, m, 0).getDate()).padStart(2, '0'); };
// días vencida: contra la fecha de vencimiento (la de emisión si no tiene); 0 si todavía no vence
function diasVencida(d) { const v = String(d.fecha_vencimiento || d.fecha_emision || '').slice(0, 10); if (!v) return 0; return Math.max(0, Math.floor((new Date(hoy() + 'T00:00:00') - new Date(v + 'T00:00:00')) / 86400000)); }
const M = (key, label, extra) => ({ key, label, num: true, fmt: 'money', ...(extra || {}) });
// columna de dinero que deja en blanco las celdas sin valor (saldo inicial de un estado de cuenta o del libro mayor); suma como las demás
const MB = (key, label, extra) => ({ key, label, num: true, sumar: true, fmt: (v) => (v === null || v === undefined ? '' : fmt(v)), ...(extra || {}) });
const N = (key, label) => ({ key, label, num: true, fmt: 'num' });
const D = (key, label) => ({ key, label, fmt: 'date' });
const enRango = (f, desde, hasta) => { const x = String(f || '').slice(0, 10); return x && (!desde || x >= desde) && (!hasta || x <= hasta); };
// 4.9: desde y hasta del enlace, solo si son fechas válidas (si no, quedan las del reporte)
const FECHA_RE = /^\d{4}-\d{2}-\d{2}$/;
const fechasEnlace = p => ({ ...(p && FECHA_RE.test(p.desde || '') ? { desde: p.desde } : {}), ...(p && FECHA_RE.test(p.hasta || '') ? { hasta: p.hasta } : {}) });

// Qué filtros muestra cada reporte
const CON_CLIENTE = ['ventas-generales', 'ventas-por-cliente', 'cuentas-por-cobrar', 'estado-cuenta-cliente', 'auxiliar-terceros'];
const CON_VENDEDOR = ['ventas-generales', 'ventas-por-vendedor'];
const CON_CUENTA = ['libro-mayor', 'movimientos-por-cuenta'];
const CON_BANCO = ['transacciones', 'flujo-caja', 'documentos-por-conciliar'];
const CON_BODEGA = ['valor-inventario'];
const SIN_DESDE = ['balance-general', 'balance-general-comparativo', 'libro-inventarios-balances', 'valor-inventario', 'cuentas-por-cobrar', 'cuentas-por-pagar', 'documentos-por-conciliar'];
const EN_COLONES = ['declaracion-iva-d104', 'compras-trimestre'];   // declaraciones: en colones con el tipo de cambio de cada comprobante, como pide Hacienda
// 3.99: los demás reportes muestran cada moneda por separado y SIN tipo de cambio: «Colones» trae solo lo hecho en colones y «Dólares»
// solo lo hecho en dólares, con sus montos originales. «Convertir todo» (control interno) usa el tipo de cambio como antes.
const MODO = { sinTc: false, moneda: 'CRC' };
// 4.0: los de bancos juntan cuentas de varias monedas y el presupuesto está en la moneda principal: sin selector de moneda
const SIN_SELECTOR = new Set(['documentos-por-conciliar', 'flujo-caja', 'presupuesto-vs-real', 'transacciones']);
// 4.1: los contables (salen de los asientos) también por moneda: «Colones» = el estado de lo hecho en colones, en colones; «Dólares» = lo
// hecho en dólares, en dólares; «Convertir todo» = la contabilidad completa en la moneda principal. La moneda de cada asiento es la de su
// documento: el automático de un documento en otra moneda lleva «(USD 100,00 × 510,00)» al final de la descripción; los demás
// (manuales, planillas, saldos iniciales) están en la moneda principal.
const ASIENTOS_MON = new Set(['auxiliar-terceros', 'balance-general', 'balance-general-comparativo', 'balance-prueba', 'comprobantes-contables', 'estado-resultados',
  'estado-resultados-comparativo', 'estado-resultados-mensual', 'libro-diario', 'libro-mayor', 'movimientos-por-cuenta', 'resultados-centro-costo']);
const REF_MON = /\((CRC|USD|EUR) ([\d.]+,\d{2}) × [\d.,]+\)\s*$/;
export function monedaAsiento(a, princ) {
  if (a && a.moneda_doc && !a.ajustado && (a.lineas || []).every(l => l.debito_doc !== undefined)) return { moneda: a.moneda_doc, exacto: true };   // montos originales guardados
  const m = REF_MON.exec(String((a && a.observaciones) || ''));
  return m ? { moneda: m[1], total: +m[2].replace(/\./g, '').replace(',', '.') } : { moneda: princ, total: null };
}
// Los asientos de una moneda, con sus montos en esa moneda (proporción del total original del documento); `otras`: cuántos hay en
// las otras monedas entre desde y hasta (para avisar que existe el otro estado)
export function asientosEnMoneda(as, mon, princ, desde, hasta) {
  const asientos = [], otras = {};
  for (const a of as || []) {
    const x = monedaAsiento(a, princ);
    if (x.moneda !== mon) {
      const f = String(a.fecha || '').slice(0, 10);
      if (!a.cierre && (!hasta || f <= hasta) && (!desde || f >= desde)) otras[x.moneda] = (otras[x.moneda] || 0) + 1;
      continue;
    }
    if (x.exacto) { asientos.push({ ...a, lineas: (a.lineas || []).map(l => ({ ...l, debito: +l.debito_doc || 0, credito: +l.credito_doc || 0 })) }); continue; }
    if (x.moneda === princ || !x.total) { asientos.push(a); continue; }
    const deb = (a.lineas || []).reduce((s, l) => s + (+l.debito || 0), 0), k = deb > 0 ? x.total / deb : 1;
    asientos.push({ ...a, lineas: (a.lineas || []).map(l => ({ ...l, debito: (+l.debito || 0) * k, credito: (+l.credito || 0) * k })) });
  }
  return { asientos, otras };
}
const OTRAS = { n: {} };
async function cargarAsientos() {
  const as = await cargarAsientosTodos();
  OTRAS.n = {};
  if (MODO.sombra) {                                             // 4.19: los mismos asientos, con sus montos en colones
    const princ = monedas.principal().codigo || 'CRC', tcs = princ === 'CRC' ? null : await tcOrigenes();
    return (MODO.sinTc ? as.filter(a => monedaAsiento(a, princ).moneda === MODO.moneda) : as).map(a => asientoEnColones(a, princ, tcs));
  }
  if (!MODO.sinTc) return as;
  const r = asientosEnMoneda(as, MODO.moneda, monedas.principal().codigo || 'CRC', MODO.desde, MODO.hasta);
  OTRAS.n = r.otras;
  return r.asientos;
}
const NOMBRE_MON = { CRC: 'colones', USD: 'dólares', EUR: 'euros' };
// 4.0: el documento de una compra o un gasto se abre desde el reporte (el PDF del comprobante recibido muestra lo que se compró)
const abrirEgreso = x => { if (x.rid) verDocumento('/api/recepcion/' + x.rid + '/pdf', 'Comprobante ' + (x.doc || '') + ' · ' + (x.proveedor || x.tercero || '')).catch(e => toast(e.message, 'err')); else if (x.cid) location.hash = x.lista || '/gastos/compras'; };
// 4.23: una factura del registro 'compras' no tiene pantalla propia: se abre la lista donde sale, Gastos › Compras o Gastos › Gastos
// según su tipo (la creada desde un comprobante aceptado sale donde está clasificado ese comprobante: la regla de filasRegistro)
const listaDeTipo = tipo => (tipo === 'compra' ? '/gastos/compras' : '/gastos/gastos');
const idsEgreso = x => ({ rid: /recibid/i.test(x.origen || '') ? x.id : null, cid: x.origen === 'Compra registrada' ? x.id : null, lista: listaDeTipo(x.clasificacion) });
async function abrirCompra(id) {
  const c = compras().find(x => String(x.id) === String(id));
  let recibidos = [];
  if (c && (c.recepcion_id || c.clave)) { try { recibidos = await api('/api/recepcion'); } catch { recibidos = []; } }
  location.hash = listaDeTipo(!c || filasRegistro('compra', [c], recibidos).some(f => f.cid === c.id) ? 'compra' : 'gasto');
}
const val = (m, mon) => (MODO.sombra ? (MODO.sinTc ? r2((m && m.USD_CRC) || 0) : valor(m, 'CRC')) : (MODO.sinTc ? r2((m && m.nativo && m.nativo[mon]) || 0) : valor(m, mon)));
const VENTAS = ['01', '02', '04', '09'];
const TIPO_DOC = { '01': 'Factura electrónica', '02': 'Nota de débito', '03': 'Nota de crédito', '04': 'Tiquete', '09': 'Factura de exportación' };   // 4.9: columna Tipo de Cuentas por cobrar

// ---- fuentes de datos (cada una se pide una sola vez por carga) ----
async function docs() { return api('/api/comprobantes'); }
async function pagos() { try { return await api('/api/pagos'); } catch { return []; } }
async function resumen(desde, hasta, detalle) { const u = '/api/resumen?periodo=rango&desde=' + desde + '&hasta=' + hasta + (detalle ? '&detalle=1' : ''); if (!MODO.memo) return api(u); return MODO.memo[u] || (MODO.memo[u] = api(u)); }   // 4.19: la sombra no repite las consultas
function bancos() { return (mock.get('bancos', []) || []).filter(b => b && b.nombre); }
function movimientos() { return mock.get('movimientos', []) || []; }
function compras() { return (mock.get('compras', []) || []).filter(c => c && c.id); }
function pagosGastos() { return (mock.get('pagos_gastos', []) || []).filter(p => p && p.id); }

// Documentos de venta válidos convertidos a la moneda principal (notas de crédito en negativo)
function ventas(lista, p) {
  return (lista || []).filter(d => [...VENTAS, '03'].includes(d.tipo_documento) && !['rechazado', 'error', 'generado'].includes(d.estado) && (!MODO.sinTc || (d.moneda || 'CRC') === p)).map(d => {
    const sg = d.tipo_documento === '03' ? -1 : 1, tcd = tcFila(d.tipo_cambio, d.fecha_emision), conv = v => r2(sg * (MODO.sinTc ? (+v || 0) : aPrincipal(v || 0, d.moneda, tcd)));
    const saldoDoc = Math.max(0, r2((d.total || 0) - (d.pagado || 0) - (d.acreditado || 0)));
    const otros = +d.total_otros_cargos || 0;
    return { ...d, __tc: tcUsd(d.tipo_cambio, d.fecha_emision), moneda: p, moneda_doc: d.moneda || 'CRC', total_doc: d.total, subtotal: conv((d.total || 0) - (d.impuesto || 0) - (d.otros_impuestos || 0) - otros), impuesto: conv(d.impuesto || 0), otros_imp: conv(d.otros_impuestos || 0), otros: conv(otros), total: conv(d.total || 0),
             saldo: r2(MODO.sinTc ? saldoDoc : aPrincipal(saldoDoc, d.moneda, tcd)), saldo_doc: saldoDoc, cliente: d.receptor_nombre || 'Tiquete (sin receptor)', vendedor_nombre: String(d.vendedor || '').trim() || 'Sin vendedor' };
  });
}
const deCRC = (v, p) => p === 'CRC' ? r2(v) : r2((+v || 0) / (monedas.tc(p) || 1));
// 4.18: el tipo de cambio de cada documento: el suyo; si no lo trae, la venta del BCCR de su día (registro de Configuración › Monedas)
let TC_DIA = null;
async function cargarTcDia() { if (TC_DIA) return TC_DIA; try { TC_DIA = await api('/api/tipo-cambio/mapa'); } catch { TC_DIA = {}; } return TC_DIA; }
function tcDia(f) { const d0 = String(f || '').slice(0, 10); if (!FECHA_RE.test(d0) || !TC_DIA) return 0; const d = new Date(d0 + 'T12:00:00'); for (let i = 0; i < 8; i++) { const v = TC_DIA[d.toISOString().slice(0, 10)]; if (v) return +v; d.setDate(d.getDate() - 1); } return 0; }
const tcFila = (tc, f) => (+tc > 1 ? +tc : tcDia(f));
const tcUsd = (tc, f) => tcFila(tc, f) || monedas.tc('USD');
const tcConv = x => (x && +x.USD ? (+x.CRC || 0) / +x.USD : 0);
// 4.18: lo que se muestra en dólares lleva una columna y totales en colones, cada fila con el tipo de cambio de su documento (__tc)
// Los que no van documento por documento (contabilidad, meses) se calculan dos veces: la segunda, «sombra», con todo en colones (MODO.sombra).
const COL_BASE = { 'libro-mayor': ['debito', 'credito', 'saldo'], 'movimientos-por-cuenta': ['debito', 'credito', 'saldo'], 'libro-diario': ['debito', 'credito'], 'comprobantes-contables': ['debito', 'credito'],
  'auxiliar-terceros': ['debito', 'credito', 'saldo'], 'balance-prueba': ['debitos', 'creditos', 'final'], 'ingresos-gastos': ['ingresos', 'gastos', 'neto'], 'reporte-anual': ['ventas', 'compras', 'iva_neto'],
  'flujo-caja': ['entradas', 'salidas', 'neto'], 'resultados-centro-costo': ['resultado'], 'estado-cuenta-cliente': ['cargo', 'abono'], 'retenciones': ['monto'] };
const CON_SOMBRA = new Set([...ASIENTOS_MON, 'ingresos-gastos', 'reporte-anual', 'flujo-caja', 'libro-inventarios-balances']);
const colColones = (key, label) => ({ key, label, num: true, sumar: true, noTotal: true, monedaFija: 'CRC', fmt: v => (v === null || v === undefined ? '' : money(v, 'CRC')) });
const aColones = (v, mon, tc) => (!mon || mon === 'CRC' ? +v || 0 : (+v || 0) * (+tc > 1 ? +tc : monedas.tc(mon)));
// a la moneda del reporte, con el tipo de cambio del documento
const aRep = (v, mon, tc) => { const m = mon || 'CRC', t = +tc > 1 ? +tc : monedas.tc('USD'); if (m === MODO.moneda) return r2(v); const crc = m === 'CRC' ? +v : +v * (m === 'USD' ? t : monedas.tc(m)); return MODO.moneda === 'CRC' ? r2(crc) : r2(crc / t); };
// el tipo de cambio que trae el documento de cada asiento: en moneda principal USD el asiento no lo guarda
async function tcOrigenes() {
  if (MODO.tcOrigen) return MODO.tcOrigen;
  const m = {}, poner = (pre, l) => { for (const x of Array.isArray(l) ? l : []) if (x && +x.tipo_cambio > 1) m[pre + x.id] = +x.tipo_cambio; };
  try { poner('doc:', await docs()); } catch { /* queda la venta de su día */ }
  try { poner('rec:', await api('/api/recepcion')); } catch { /* idem */ }
  try { poner('pago:', await pagos()); } catch { /* idem */ }
  poner('cm:', compras()); poner('pg:', pagosGastos());
  return (MODO.tcOrigen = m);
}
function asientoEnColones(a, princ, tcs) {
  if (princ === 'CRC') return a;                                 // ya está en colones, con el tipo de cambio de su documento
  const x = monedaAsiento(a, princ);
  if (x.moneda === 'CRC' && x.exacto) return { ...a, lineas: (a.lineas || []).map(l => ({ ...l, debito: +l.debito_doc || 0, credito: +l.credito_doc || 0 })) };
  const ref = /×\s*([\d.]+,\d+)\)\s*$/.exec(String(a.observaciones || '')), tc = ref ? +ref[1].replace(/\./g, '').replace(',', '.') : ((tcs && tcs[a.origen]) || tcDia(a.fecha) || monedas.tc('USD'));
  return { ...a, lineas: (a.lineas || []).map(l => ({ ...l, debito: (+l.debito || 0) * tc, credito: (+l.credito || 0) * tc })) };
}
function agregarColones(r, p, sombra, bases) {
  if (p !== 'USD' || !r || !Array.isArray(r.rows) || !Array.isArray(r.cols) || !r.rows.length) return r;
  const dinero = r.cols.filter(c => (c.fmt === 'money' || c.sumar) && !c.monedaFija);
  const elegidas = bases ? bases.map(k => dinero.find(c => c.key === k)).filter(Boolean) : [['saldo', 'total', 'venta', 'monto', 'neto'].map(k => dinero.find(c => c.key === k)).find(Boolean) || dinero[dinero.length - 1]].filter(Boolean);
  if (!elegidas.length) return r;
  let valor;
  if (sombra && Array.isArray(sombra.rows)) {
    const llave = (x, i) => (x.id !== undefined ? x.id : i), por = new Map(sombra.rows.map((x, i) => [llave(x, i), x]));
    valor = (x, i, c) => { const s = por.get(llave(x, i)), v = s ? s[c.key] : null; return v === null || v === undefined ? null : r2(v); };
  } else {
    for (const x of r.rows) if (x.__crc !== undefined && !x.__tc) x.__tc = x.total ? x.__crc / x.total : 0;
    if (!r.rows.some(x => +x.__tc > 0)) return r;
    valor = (x, i, c) => (+x.__tc > 0 && x[c.key] !== null && x[c.key] !== undefined ? r2((+x[c.key] || 0) * x.__tc) : null);
  }
  for (const c of elegidas) {
    const clave = c.key + '_colones';
    r.rows.forEach((x, i) => { x[clave] = valor(x, i, c); });
    r.cols.splice(r.cols.indexOf(c) + 1, 0, colColones(clave, c.label + ' en colones'));
  }
  r.totalesColones = [...dinero.filter(c => !c.noTotal).map(c => ({ label: c.label + ' en colones', moneda: 'CRC', v: r2(r.rows.reduce((s, x, i) => s + (+valor(x, i, c) || 0), 0)) })),
    ...((sombra && sombra.totales) || []).map(t => ({ label: t.label + ' en colones', moneda: 'CRC', v: r2(t.v) }))];
  if (sombra && Array.isArray(r.secciones)) {                    // balance general en PDF y Word: va por secciones
    const cuenta = new Map(sombra.rows.filter(x => x.cuenta).map(x => [x.cuenta, x]));
    for (const s of r.secciones) if ((s.columnas || []).some(c => c.key === 'saldo') && (s.filas || []).some(f => f.cuenta !== undefined)) {
      s.columnas.push({ key: 'saldo_colones', label: 'Saldo en colones', num: true });
      for (const f of s.filas) { const x = cuenta.get(f.cuenta); f.saldo_colones = x ? money(x.saldo, 'CRC') : ''; }
    }
  }
  return r;
}
const linkDoc = x => location.hash = '/ventas/facturas/' + x.id;

// ---- un cargador por reporte: devuelve {cols, rows, kpis?, totales?, secciones?, nota?} ----
const REPORTES = {
  async 'ventas-generales'(c) {
    const rows = ventas(await docs(), c.p).filter(d => enRango(d.fecha_emision, c.desde, c.hasta)).filter(c.filtroCliente).filter(c.filtroVendedor);
    const conOtros = rows.some(x => Math.abs(x.otros) > 0.004);
    return { cols: [{ key: 'consecutivo', label: 'Número', mono: true, link: linkDoc }, { key: 'cliente', label: 'Cliente' }, D('fecha_emision', 'Fecha'), { key: 'moneda_doc', label: 'Moneda' }, M('subtotal', 'Subtotal'), M('impuesto', 'IVA'), ...(rows.some(x => x.otros_imp) ? [M('otros_imp', 'Otros impuestos')] : []), ...(conOtros ? [M('otros', 'Otros cargos')] : []), M('total', 'Total')], rows,
      kpis: [{ t: 'Documentos', v: rows.length }, { t: 'Subtotal', v: c.din(c.suma(rows, 'subtotal')) }, { t: 'IVA', v: c.din(c.suma(rows, 'impuesto')) }, { t: 'Total', v: c.din(c.suma(rows, 'total')) }] };
  },
  async 'ventas-por-cliente'(c) {
    const m = {};
    for (const f of ventas(await docs(), c.p).filter(d => enRango(d.fecha_emision, c.desde, c.hasta)).filter(c.filtroCliente)) { const k = f.cliente; m[k] = m[k] || { id: k, cliente: k, docs: 0, subtotal: 0, impuesto: 0, total: 0 }; m[k].docs++; m[k].subtotal = r2(m[k].subtotal + f.subtotal); m[k].impuesto = r2(m[k].impuesto + f.impuesto); m[k].total = r2(m[k].total + f.total); m[k].__crc = (m[k].__crc || 0) + f.total * f.__tc; }
    const rows = Object.values(m).sort((a, b) => b.total - a.total);
    return { cols: [{ key: 'cliente', label: 'Cliente' }, N('docs', 'Documentos'), M('subtotal', 'Subtotal'), M('impuesto', 'IVA'), M('total', 'Total')], rows,
      kpis: [{ t: 'Clientes', v: rows.length }, { t: 'Documentos', v: c.suma(rows, 'docs') }, { t: 'IVA', v: c.din(c.suma(rows, 'impuesto')) }, { t: 'Total', v: c.din(c.suma(rows, 'total')) }] };
  },
  async 'cuentas-por-cobrar'(c) {
    // 4.9: también los tiquetes a crédito (04: el fiado de la caja), con la columna Tipo; el cliente lleva a su estado de cuenta
    const rows = ventas(await docs(), c.p).filter(f => ['01', '02', '04', '09'].includes(f.tipo_documento) && ['02', '08', '10'].includes(f.condicion_venta) && f.saldo > 0).filter(c.filtroCliente)
      .map(f => { const dias = f.fecha_vencimiento ? diasVencida(f) : 0; return { ...f, dias, tipo_nombre: TIPO_DOC[f.tipo_documento] || f.tipo_documento, estado_cobro: dias > 0 ? 'Vencida' : 'Por cobrar' }; }).sort((a, b) => b.dias - a.dias);
    const aCuenta = rutaPermitida('/contactos/estado-cuenta') ? { link: x => { if (x.cliente_id) location.hash = '/contactos/estado-cuenta/' + x.cliente_id; } } : {};
    return { cols: [{ key: 'consecutivo', label: 'Número', mono: true, link: linkDoc }, { key: 'tipo_nombre', label: 'Tipo' }, { key: 'cliente', label: 'Cliente', ...aCuenta }, D('fecha_emision', 'Emisión'), D('fecha_vencimiento', 'Vence'), N('dias', 'Días vencida'), { key: 'moneda_doc', label: 'Moneda' }, M('total', 'Total'), M('saldo', 'Saldo'), { key: 'estado_cobro', label: 'Estado', fmt: 'badge' }], rows,
      kpis: [{ t: 'Documentos pendientes', v: rows.length }, { t: 'Saldo por cobrar', v: c.din(c.suma(rows, 'saldo')) }, { t: 'Vencidas', v: c.din(c.suma(rows.filter(x => x.dias > 0), 'saldo')) }], nota: 'Saldos abiertos a hoy, sin filtro de fechas. Incluye las facturas y los tiquetes a crédito (fiados en la caja).' };
  },
  async 'ventas-por-item'(c) {
    const r = await resumen(c.desde, c.hasta, true);
    const rows = ((r.detalle && r.detalle.items) || []).map((x, i) => ({ id: x.producto_id || 'x' + i, item: x.detalle, cantidad: x.cantidad, docs: x.docs, venta: val(x.monto, c.p), __tc: +x.usd_tc || 0 }));
    return { cols: [{ key: 'item', label: 'Ítem' }, N('cantidad', 'Cantidad'), N('docs', 'Líneas'), M('venta', 'Venta')], rows, kpis: [{ t: 'Ítems', v: rows.length }, { t: 'Unidades', v: fmt(c.suma(rows, 'cantidad'), 2) }, { t: 'Venta', v: c.din(c.suma(rows, 'venta')) }] };
  },
  async 'rentabilidad-por-item'(c) {
    const [r, movs] = await Promise.all([resumen(c.desde, c.hasta, true), api('/api/inventario/movimientos?limite=5000&desde=' + c.desde + '&hasta=' + c.hasta)]);
    const costo = {};
    for (const m of movs) if (m.tipo === 'venta') costo[m.producto_id] = (costo[m.producto_id] || 0) + (-(+m.cantidad || 0)) * (+m.costo_unitario || 0);   // las devoluciones tampoco restan la venta en el ranking
    const rows = ((r.detalle && r.detalle.items) || []).map((x, i) => { const venta = valor(x.monto, c.p), cos = x.producto_id ? deCRC(costo[x.producto_id] || 0, c.p) : 0; return { id: x.producto_id || 'x' + i, __tc: +x.usd_tc || 0, item: x.detalle, cantidad: x.cantidad, venta, costo: cos, utilidad: r2(venta - cos), margen: venta ? r2((venta - cos) / venta * 100) : 0 }; });
    return { cols: [{ key: 'item', label: 'Ítem' }, N('cantidad', 'Cantidad'), M('venta', 'Venta'), M('costo', 'Costo'), M('utilidad', 'Utilidad'), { key: 'margen', label: 'Margen %', num: true, fmt: v => fmt(v, 1) + ' %' }], rows,
      kpis: [{ t: 'Venta', v: c.din(c.suma(rows, 'venta')) }, { t: 'Costo', v: c.din(c.suma(rows, 'costo')) }, { t: 'Utilidad', v: c.din(c.suma(rows, 'utilidad')) }], nota: 'Venta con IVA incluido en el precio de línea; costo = costo promedio del inventario al momento de la venta (los servicios y los ítems sin inventario van sin costo).' };
  },
  async 'ventas-por-sucursal'(c) {
    // 3.66: lo calcula el servidor en colones con el tipo de cambio de cada comprobante; en otra moneda principal se convierte al tipo del día
    const r = await api('/api/sucursales/ventas?desde=' + c.desde + '&hasta=' + c.hasta);
    const rows = (r.filas || []).map(x => ({ id: x.id, codigo: x.codigo, sucursal: x.sucursal, docs: x.documentos, subtotal: deCRC(x.subtotal, c.p), impuesto: deCRC(x.impuesto, c.p), total: deCRC(x.total, c.p), __tc: monedas.tc('USD') })).sort((a, b) => b.total - a.total);
    return { cols: [{ key: 'codigo', label: 'Código', mono: true }, { key: 'sucursal', label: 'Sucursal' }, N('docs', 'Documentos'), M('subtotal', 'Subtotal'), M('impuesto', 'IVA'), M('total', 'Total')], rows,
      kpis: [{ t: 'Sucursales', v: rows.length }, { t: 'Documentos', v: c.suma(rows, 'docs') }, { t: 'IVA', v: c.din(c.suma(rows, 'impuesto')) }, { t: 'Total', v: c.din(c.suma(rows, 'total')) }], nota: 'Una fila por sucursal; las notas de crédito restan. Los comprobantes anteriores a las sucursales se asignan por el código en su número.' };
  },
  async 'ventas-por-vendedor'(c) {
    const m = {};
    for (const f of ventas(await docs(), c.p).filter(d => enRango(d.fecha_emision, c.desde, c.hasta)).filter(c.filtroVendedor)) { const k = f.vendedor_nombre; m[k] = m[k] || { id: k, vendedor: k, docs: 0, subtotal: 0, impuesto: 0, total: 0 }; m[k].docs++; m[k].subtotal = r2(m[k].subtotal + f.subtotal); m[k].impuesto = r2(m[k].impuesto + f.impuesto); m[k].total = r2(m[k].total + f.total); m[k].__crc = (m[k].__crc || 0) + f.total * f.__tc; }
    const rows = Object.values(m).sort((a, b) => b.total - a.total);
    return { cols: [{ key: 'vendedor', label: 'Vendedor' }, N('docs', 'Documentos'), M('subtotal', 'Subtotal'), M('impuesto', 'IVA'), M('total', 'Total')], rows, kpis: [{ t: 'Vendedores', v: rows.length }, { t: 'Documentos', v: c.suma(rows, 'docs') }, { t: 'Total', v: c.din(c.suma(rows, 'total')) }] };
  },
  async 'estado-cuenta-cliente'(c) {
    if (!c.cliente) return { cols: [], rows: [], aviso: 'Elija un cliente para ver su estado de cuenta.' };
    const [ds, ps] = await Promise.all([docs(), pagos()]);
    const cid = String(c.cliente), nombre = (store.clientes.find(x => String(x.id) === cid) || {}).nombre || '';
    const mov = [], conPago = new Set(ps.flatMap(p => (p.facturas || []).map(f => f.id)));
    for (const d of ventas(ds, c.p)) if (String(d.cliente_id) === cid) {
      mov.push({ __tc: d.__tc, fecha: String(d.fecha_emision).slice(0, 10), doc: d.consecutivo, id: d.id, detalle: ({ '01': 'Factura electrónica', '02': 'Nota de débito', '03': 'Nota de crédito', '04': 'Tiquete', '09': 'Factura de exportación' })[d.tipo_documento] || d.tipo_documento, cargo: d.total > 0 ? d.total : 0, abono: d.total < 0 ? -d.total : 0 });
      // venta de contado sin recibo registrado: se pagó al emitirse
      if (d.total > 0 && !['02', '08', '10'].includes(d.condicion_venta) && !conPago.has(d.id)) mov.push({ __tc: d.__tc, fecha: String(d.fecha_emision).slice(0, 10), doc: d.consecutivo, id: d.id, detalle: 'Pago de contado', cargo: 0, abono: d.total });
    }
    for (const p of ps) if (String(p.cliente_id) === cid && +p.monto > 0 && (!MODO.sinTc || (p.moneda || 'CRC') === c.p)) mov.push({ __tc: tcUsd(p.tipo_cambio, p.fecha), fecha: String(p.fecha).slice(0, 10), doc: p.consecutivo || ('Recibo #' + p.numero), detalle: (p.tipo === 'rep' ? 'Recibo electrónico de pago' : 'Pago recibido') + (p.medio_pago ? ' · ' + (({ '01': 'efectivo', '02': 'tarjeta', '03': 'cheque', '04': 'transferencia', '06': 'SINPE Móvil' })[p.medio_pago] || p.medio_pago) : ''), cargo: 0, abono: MODO.sinTc ? r2(p.monto) : r2(aPrincipal(p.monto, p.moneda, tcFila(p.tipo_cambio, p.fecha))) });
    mov.sort((a, b) => a.fecha.localeCompare(b.fecha) || (a.cargo ? -1 : 1));
    let saldo = r2(mov.filter(m => m.fecha < c.desde).reduce((s, m) => s + m.cargo - m.abono, 0));
    let saldoC = mov.filter(m => m.fecha < c.desde).reduce((s, m) => s + (m.cargo - m.abono) * (m.__tc || 0), 0);   // 4.19
    const rows = [{ id: 'ini', fecha: c.desde, doc: '', detalle: 'Saldo anterior', cargo: null, abono: null, saldo, saldo_c: r2(saldoC) }];
    for (const m of mov) { if (!enRango(m.fecha, c.desde, c.hasta)) continue; saldo = r2(saldo + m.cargo - m.abono); saldoC += (m.cargo - m.abono) * (m.__tc || 0); rows.push({ id: m.doc + m.fecha + rows.length, ...m, saldo, saldo_c: r2(saldoC) }); }
    return { cols: [D('fecha', 'Fecha'), { key: 'doc', label: 'Documento', mono: true, link: x => x.id && linkDoc(x) }, { key: 'detalle', label: 'Detalle' }, MB('cargo', 'Cargo'), MB('abono', 'Abono'), M('saldo', 'Saldo', { noTotal: true }), ...(c.p === 'USD' ? [colColones('saldo_c', 'Saldo en colones')] : [])], rows,
      kpis: [{ t: 'Cargos', v: c.din(c.suma(rows, 'cargo')) }, { t: 'Abonos', v: c.din(c.suma(rows, 'abono')) }, { t: 'Saldo al ' + fecha(c.hasta), v: c.din(saldo) }], subtitulo: 'Cliente: ' + nombre };
  },
  async 'ventas-por-bodega'(c) {
    const r = await api('/api/inventario/ventas-por-bodega?desde=' + c.desde + '&hasta=' + c.hasta);
    const rows = (r.filas || []).map((x, i) => ({ id: x.bodega_id || 'sin' + i, bodega: x.bodega, documentos: x.documentos, unidades: x.unidades, venta: deCRC(x.venta_crc, c.p), costo: deCRC(x.costo_crc, c.p), utilidad: deCRC(x.venta_crc - x.costo_crc, c.p), __tc: monedas.tc('USD') }));
    return { cols: [{ key: 'bodega', label: 'Bodega' }, N('documentos', 'Documentos'), N('unidades', 'Unidades'), M('venta', 'Venta'), M('costo', 'Costo'), M('utilidad', 'Utilidad')], rows, kpis: [{ t: 'Bodegas', v: rows.length }, { t: 'Venta', v: c.din(c.suma(rows, 'venta')) }, { t: 'Costo', v: c.din(c.suma(rows, 'costo')) }], nota: 'Cada línea vendida se asigna a la bodega de la que salió el inventario; los servicios van en «Sin bodega».' + (r.tc_disponible === false ? ' Sin tipo de cambio del día: los documentos en dólares sin tipo de cambio propio no se convierten.' : '') };
  },
  async 'cuentas-por-pagar'(c) {
    const r = await resumen(c.desde, c.hasta, true);
    const rows = ((r.detalle && r.detalle.cxp) || []).map(x => ({ id: x.id, proveedor: x.proveedor, doc: x.numero, fecha: x.fecha, vence: x.vencimiento, dias: x.dias, moneda_doc: x.moneda, total_doc: x.total, saldo: val(x, c.p), __tc: tcConv(x), estado: x.estado === 'Vencida' ? 'Vencida' : 'Por pagar' }));
    return { cols: [{ key: 'proveedor', label: 'Proveedor' }, { key: 'doc', label: 'Documento', mono: true, link: x => abrirCompra(x.id) }, D('fecha', 'Fecha'), D('vence', 'Vencimiento'), N('dias', 'Días vencida'), { key: 'moneda_doc', label: 'Moneda' }, M('saldo', 'Saldo'), { key: 'estado', label: 'Estado', fmt: 'badge' }], rows,
      kpis: [{ t: 'Facturas pendientes', v: rows.length }, { t: 'Saldo por pagar', v: c.din(c.suma(rows, 'saldo')) }, { t: 'Vencido', v: c.din(c.suma(rows.filter(x => x.dias > 0), 'saldo')) }], nota: 'Facturas de compra registradas con saldo, a hoy.' };
  },
  async 'compras'(c) {
    // el resumen ya incluye los comprobantes recibidos y aceptados, las facturas electrónicas de compra y las compras registradas a mano
    const r = await resumen(c.desde, c.hasta, true);
    const rows = ((r.detalle && r.detalle.egresos) || []).filter(x => !MODO.sinTc || (x.moneda || 'CRC') === c.p).map((x, i) => ({ id: 'e' + i, ...idsEgreso(x), fecha: x.fecha, proveedor: x.proveedor, doc: x.consecutivo || '', origen: x.origen, clas: x.clasificacion === 'compra' ? 'Compra' : 'Gasto', __tc: tcConv(x), moneda_doc: x.moneda, total: MODO.sinTc ? r2(+x.total || 0) : val(x, c.p), impuesto: MODO.sinTc ? r2(+(x.acreditar ?? x.impuesto) || 0) : (c.p === 'CRC' ? r2(x.acreditar_CRC) : r2(x.acreditar_USD)) }))
      .sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)));
    return { cols: [D('fecha', 'Fecha'), { key: 'proveedor', label: 'Proveedor' }, { key: 'doc', label: 'Documento', mono: true, link: abrirEgreso }, { key: 'origen', label: 'Origen' }, { key: 'clas', label: 'Tipo' }, { key: 'moneda_doc', label: 'Moneda' }, M('impuesto', 'IVA'), M('total', 'Total')], rows, kpis: [{ t: 'Documentos', v: rows.length }, { t: 'IVA acreditable', v: c.din(c.suma(rows, 'impuesto')) }, { t: 'Total', v: c.din(c.suma(rows, 'total')) }], nota: 'Comprobantes recibidos y aceptados, facturas electrónicas de compra emitidas y compras registradas a mano (estas por su fecha de registro).' };
  },
  async 'gastos'(c) {   // 3.99: todo lo que sale: comprobantes y facturas de proveedores, gastos pagados sin factura y la planilla pagada
    const r = await resumen(c.desde, c.hasta, true);
    const rows = [];
    for (const [i, x] of ((r.detalle && r.detalle.egresos) || []).entries()) {
      if (MODO.sinTc && (x.moneda || 'CRC') !== c.p) continue;
      if (x.clasificacion === 'compra') continue;   // 4.3: la mercadería para vender es costo de ventas, no gasto (está en Compras)
      rows.push({ id: 'e' + i, ...idsEgreso(x), fecha: x.fecha, tipo: x.origen || 'Compra', tercero: x.proveedor || '—', doc: x.consecutivo || '', concepto: '', __tc: tcConv(x), moneda_doc: x.moneda || 'CRC',
        impuesto: MODO.sinTc ? r2(+(x.acreditar ?? x.impuesto) || 0) : (c.p === 'CRC' ? r2(x.acreditar_CRC) : r2(x.acreditar_USD)), total: MODO.sinTc ? r2(+x.total || 0) : valor(x, c.p) });
    }
    for (const p of pagosGastos()) {
      if (!enRango(p.fecha, c.desde, c.hasta)) continue;
      const mon = p.moneda || 'CRC';
      if (MODO.sinTc && mon !== c.p) continue;
      for (const [j, l] of (p.cuentas || []).entries()) {
        const monto = +l.valor || 0;
        if (monto <= 0) continue;
        rows.push({ id: 'g' + p.id + '-' + j, __tc: tcUsd(p.tipo_cambio, p.fecha), fecha: p.fecha, tipo: 'Gasto sin factura', tercero: p.contacto || '—', doc: p.numero ? 'Pago ' + p.numero : '', concepto: l.concepto || l.cuenta || l.detalle || '',
          moneda_doc: mon, impuesto: 0, total: MODO.sinTc ? r2(monto) : r2(aPrincipal(monto, mon, tcFila(p.tipo_cambio, p.fecha))) });
      }
    }
    if (!MODO.sinTc || c.p === 'CRC') for (const pl of (mock.get('planillas', []) || [])) {
      if (!pl || pl.estado !== 'Pagada') continue;
      const f = String(pl.pagada_en || pl.hasta || pl.fecha || '').slice(0, 10);
      if (!enRango(f, c.desde, c.hasta)) continue;
      const tt = pl.totales || {}, costo = (+tt.bruto || 0) + (+tt.total_patronal || 0);
      rows.push({ id: 'p' + pl.id, fecha: f, tipo: 'Planilla', tercero: (pl.empleados || 0) + ' empleado(s)', doc: pl.numero || '', concepto: 'Salarios y cargas sociales ' + (pl.desde ? 'del ' + fecha(pl.desde) + ' al ' + fecha(pl.hasta) : ''),
        moneda_doc: 'CRC', impuesto: 0, total: r2(MODO.sinTc ? costo : aPrincipal(costo, 'CRC', null)) });
    }
    rows.sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)));
    const porTipo = {};
    for (const x of rows) porTipo[x.tipo] = r2((porTipo[x.tipo] || 0) + x.total);
    return { cols: [D('fecha', 'Fecha'), { key: 'tipo', label: 'Tipo' }, { key: 'tercero', label: 'Proveedor o beneficiario' }, { key: 'doc', label: 'Documento', mono: true, link: abrirEgreso }, { key: 'concepto', label: 'Concepto' },
      { key: 'moneda_doc', label: 'Moneda' }, M('impuesto', 'IVA'), M('total', 'Total')], rows,
      kpis: [{ t: 'Registros', v: rows.length }, { t: 'Total de gastos', v: c.din(c.suma(rows, 'total')) }, ...Object.entries(porTipo).slice(0, 4).map(([k, v]) => ({ t: k, v: c.din(v) }))] };
  },
  async 'compras-trimestre'(c) {
    // 3.61: base de la declaración trimestral del régimen simplificado (D-105): todo lo comprado, por trimestre
    const r = await resumen(c.desde, c.hasta, true), m = {};
    for (const x of (r.detalle && r.detalle.egresos) || []) {
      const f = String(x.fecha || ''), q = f.slice(0, 4) + '-T' + (Math.floor((+f.slice(5, 7) - 1) / 3) + 1);
      const o = m[q] || (m[q] = { id: q, trimestre: q.slice(0, 4) + ' · Trimestre ' + q.slice(6), docs: 0, impuesto: 0, total: 0 });
      if (MODO.sinTc && (x.moneda || 'CRC') !== c.p) continue;   // 4.3: vista por moneda
      o.docs++; o.total = r2(o.total + val(x, c.p)); o.impuesto = r2(o.impuesto + (MODO.sinTc ? +(x.acreditar ?? x.impuesto) || 0 : c.p === 'CRC' ? +x.acreditar_CRC || 0 : +x.acreditar_USD || 0));
    }
    const rows = Object.values(m).sort((a, b) => a.id.localeCompare(b.id));
    return { cols: [{ key: 'trimestre', label: 'Trimestre' }, N('docs', 'Documentos'), M('impuesto', 'IVA pagado'), M('total', 'Total comprado')], rows,
      kpis: [{ t: 'Trimestres', v: rows.length }, { t: 'Documentos', v: c.suma(rows, 'docs') }, { t: 'Total comprado', v: c.din(c.suma(rows, 'total')) }],
      nota: 'Comprobantes electrónicos recibidos de proveedores, facturas electrónicas de compra y compras registradas a mano, sumados por trimestre. Es la base de la declaración trimestral del régimen de tributación simplificada; confirme con su contador qué compras entran en el cálculo.' };
  },
  async 'ingresos-gastos'(c) {
    const r = await resumen(c.desde, c.hasta, false), m = {};
    for (const d of r.por_dia || []) { const k = d.fecha.slice(0, 7); const x = m[k] || (m[k] = { id: k, mes: mesLabel(k), ingresos: 0, gastos: 0 }); x.ingresos = r2(x.ingresos + val(d.ingresos, c.p)); x.gastos = r2(x.gastos + val(d.egresos, c.p)); }
    const rows = Object.values(m).sort((a, b) => a.id.localeCompare(b.id)).map(x => ({ ...x, neto: r2(x.ingresos - x.gastos) }));
    return { cols: [{ key: 'mes', label: 'Mes' }, M('ingresos', 'Ingresos'), M('gastos', 'Gastos'), M('neto', 'Resultado')], rows, kpis: [{ t: 'Ingresos', v: c.din(c.suma(rows, 'ingresos')) }, { t: 'Gastos', v: c.din(c.suma(rows, 'gastos')) }, { t: 'Resultado', v: c.din(c.suma(rows, 'neto')) }], nota: 'Ingresos = ventas emitidas; gastos = comprobantes recibidos y aceptados más facturas de compra, por fecha de emisión.' };
  },
  async 'valor-inventario'(c) {
    const v = await api('/api/inventario/valor?hasta=' + c.hasta + (c.bodega ? '&bodega_id=' + c.bodega : ''));
    const rows = (v.items || []).filter(x => Math.abs(+x.cantidad || 0) > 0.0001 || c.bodega).map(x => ({ id: x.producto_id, __tc: monedas.tc('USD'), item: x.nombre, codigo: x.codigo, existencias: x.cantidad, costo: deCRC(x.costo_promedio, c.p), total: deCRC(x.total, c.p) }));
    return { cols: [{ key: 'item', label: 'Ítem' }, { key: 'codigo', label: 'Código', mono: true }, N('existencias', 'Existencias'), M('costo', 'Costo unitario'), M('total', 'Valor total')], rows, kpis: [{ t: 'Ítems', v: rows.length }, { t: 'Unidades', v: fmt(c.suma(rows, 'existencias'), 2) }, { t: 'Valor al ' + fecha(c.hasta), v: c.din(c.suma(rows, 'total')) }] };
  },
  async 'transacciones'(c) {
    const bs = bancos(), porId = Object.fromEntries(bs.map(b => [b.id, b]));
    const rows = movimientos().filter(m => enRango(m.fecha, c.desde, c.hasta) && porId[m.banco_id] && (!c.banco || String(m.banco_id) === String(c.banco)))
      .map(m => { const b = porId[m.banco_id]; return { id: m.id, __tc: tcUsd(m.tipo_cambio, m.fecha), fecha: m.fecha, cuenta: b.nombre, detalle: m.descripcion || '', tipo: +m.monto >= 0 ? 'Entrada' : 'Salida', monto_cuenta: Math.abs(+m.monto || 0), moneda_doc: b.moneda || 'CRC', monto: r2(aPrincipal(Math.abs(+m.monto || 0), b.moneda, tcFila(m.tipo_cambio, m.fecha))), estado: m.conciliado ? 'Conciliado' : 'No conciliado' }; })
      .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    return { cols: [D('fecha', 'Fecha'), { key: 'cuenta', label: 'Cuenta' }, { key: 'detalle', label: 'Detalle' }, { key: 'tipo', label: 'Tipo' }, { key: 'moneda_doc', label: 'Moneda' }, M('monto', 'Monto'), { key: 'estado', label: 'Estado', fmt: 'badge' }], rows,
      kpis: [{ t: 'Movimientos', v: rows.length }, { t: 'Entradas', v: c.din(c.suma(rows.filter(x => x.tipo === 'Entrada'), 'monto')) }, { t: 'Salidas', v: c.din(c.suma(rows.filter(x => x.tipo === 'Salida'), 'monto')) }] };
  },
  async 'reporte-anual'(c) {
    const anio = c.hasta.slice(0, 4), ultimo = anio === hoy().slice(0, 4) ? +hoy().slice(5, 7) : 12;
    const meses = Array.from({ length: ultimo }, (_, i) => anio + '-' + String(i + 1).padStart(2, '0'));
    const rs = await Promise.all(meses.map(ym => resumen(ym + '-01', finMes(ym), false)));
    const rows = rs.map((r, i) => ({ id: meses[i], mes: mesLabel(meses[i]), ventas: val(r.ventas, c.p), devoluciones: val(r.devoluciones, c.p), compras: val(r.egresos, c.p), iva_debito: val(r.iva && r.iva.debito, c.p), iva_credito: val(r.iva && r.iva.credito, c.p), iva_neto: val(r.iva && r.iva.neto, c.p), docs: r.documentos }));
    return { cols: [{ key: 'mes', label: 'Mes' }, N('docs', 'Documentos'), M('ventas', 'Ventas'), M('devoluciones', 'Devoluciones'), M('compras', 'Compras y gastos'), M('iva_debito', 'IVA débito'), M('iva_credito', 'IVA crédito'), M('iva_neto', 'IVA neto')], rows,
      kpis: [{ t: 'Ventas ' + anio, v: c.din(c.suma(rows, 'ventas')) }, { t: 'Compras y gastos', v: c.din(c.suma(rows, 'compras')) }, { t: 'IVA neto', v: c.din(c.suma(rows, 'iva_neto')) }], subtitulo: 'Año ' + anio + ' (según la fecha «Hasta»)' };
  },
  async 'flujo-caja'(c) {
    const bs = bancos().filter(b => b.tipo !== 'Tarjeta de crédito' && (!c.banco || String(b.id) === String(c.banco))), porId = Object.fromEntries(bs.map(b => [b.id, b]));
    const conv = (b, v, tcMov) => r2(MODO.sombra ? aColones(v, b.moneda, tcMov) : aPrincipal(v, b.moneda, tcMov));   // cuentas en otra moneda: con el tipo de cambio del movimiento (si lo trae) o el actual
    let saldo = r2(bs.reduce((s, b) => s + conv(b, +b.saldo_inicial || 0, null), 0));
    const m = {};
    for (const x of movimientos()) {
      const b = porId[x.banco_id]; if (!b) continue; const f = String(x.fecha || '').slice(0, 10), v = conv(b, +x.monto || 0, tcFila(x.tipo_cambio, x.fecha));
      if (f < c.desde) { saldo = r2(saldo + v); continue; } if (f > c.hasta) continue;
      const k = f.slice(0, 7), r = m[k] || (m[k] = { id: k, mes: mesLabel(k), entradas: 0, salidas: 0 }); if (v >= 0) r.entradas = r2(r.entradas + v); else r.salidas = r2(r.salidas - v);
    }
    const inicial = saldo, rows = [];
    for (const r of Object.values(m).sort((a, b) => a.id.localeCompare(b.id))) { saldo = r2(saldo + r.entradas - r.salidas); rows.push({ ...r, neto: r2(r.entradas - r.salidas), saldo }); }
    return { cols: [{ key: 'mes', label: 'Mes' }, M('entradas', 'Entradas'), M('salidas', 'Salidas'), M('neto', 'Flujo neto'), M('saldo', 'Saldo acumulado', { noTotal: true })], rows,
      kpis: [{ t: 'Saldo inicial', v: c.din(inicial) }, { t: 'Entradas', v: c.din(c.suma(rows, 'entradas')) }, { t: 'Salidas', v: c.din(c.suma(rows, 'salidas')) }, { t: 'Saldo final', v: c.din(saldo) }], nota: 'Efectivo real: saldos iniciales de Bancos y cajas más todos sus movimientos (cobros, pagos, planillas, transferencias), sin importar la fecha del saldo inicial.' };
  },
  async 'balance-general'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), b = balanceGeneral(as, plan, c.hasta);
    const sec = r => ({ titulo: ({ 1: 'Activos', 2: 'Pasivos', 3: 'Patrimonio' })[r], columnas: [{ key: 'cuenta', label: 'Cuenta' }, { key: 'nombre', label: 'Nombre' }, { key: 'saldo', label: 'Saldo', num: true }], filas: b.rows.filter(x => x.raiz === r).map(x => ({ cuenta: x.cuenta, nombre: x.nombre, saldo: c.din(x.saldo) })) });
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('saldo', 'Saldo', { noTotal: true })], rows: b.rows, secciones: [sec('1'), sec('2'), sec('3')],
      kpis: [{ t: 'Activos', v: c.din(b.activos) }, { t: 'Pasivos', v: c.din(b.pasivos) }, { t: 'Patrimonio', v: c.din(b.patrimonio) }, { t: 'Diferencia', v: c.din(b.diferencia) }], nota: 'Saldos acumulados al ' + fecha(c.hasta) + ' (saldos iniciales más todos los asientos); el resultado del período no cerrado se muestra en el patrimonio.' };
  },
  async 'estado-resultados'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), e = estadoResultados(as, plan, c.desde, c.hasta);
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('monto', 'Monto', { noTotal: true })], rows: e.rows,
      kpis: [{ t: 'Ingresos', v: c.din(e.ingresos) }, { t: 'Costos', v: c.din(e.costos) }, { t: 'Gastos', v: c.din(e.gastos) }, { t: (e.neta >= 0 ? 'Utilidad' : 'Pérdida') + ' neta', v: c.din(e.neta) }], totales: [{ label: 'Utilidad bruta (ingresos − costos)', v: e.bruta }, { label: 'Utilidad neta', v: e.neta }] };
  },
  async 'estado-resultados-mensual'(c) {   // 4.1: el mes de la barra (acumulado o solo ese mes) o el rango de fechas que elija
    const as = await cargarAsientos(), plan = planConUsadas(as), e = estadoResultados(as, plan, c.desde, c.hasta);
    const anio = c.hasta.slice(0, 4), porMes = {};
    for (const a of as || []) { const f = String(a.fecha || ''); if (f.startsWith(anio) && !a.cierre) porMes[f.slice(5, 7)] = (porMes[f.slice(5, 7)] || 0) + 1; }
    const NOM = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'], mes = NOM[+c.hasta.slice(5, 7) - 1];
    const finDeMes = c.hasta === finMes(c.hasta.slice(0, 7));
    const titulo = finDeMes && c.desde === c.hasta.slice(0, 7) + '-01' ? 'Mes de ' + mes : finDeMes && c.desde === anio + '-01-01' ? 'Acumulado a ' + mes : 'Del ' + fecha(c.desde) + ' al ' + fecha(c.hasta);
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('monto', titulo, { noTotal: true })], rows: e.rows, meses: porMes,
      kpis: [{ t: 'Ingresos', v: c.din(e.ingresos) }, { t: 'Costos', v: c.din(e.costos) }, { t: 'Gastos', v: c.din(e.gastos) }, { t: (e.neta >= 0 ? 'Utilidad' : 'Pérdida') + ' neta', v: c.din(e.neta) }],
      totales: [{ label: 'Utilidad bruta (ingresos − costos)', v: e.bruta }, { label: (e.neta >= 0 ? 'Utilidad' : 'Pérdida') + ' neta', v: e.neta }], subtitulo: titulo };
  },
  async 'balance-prueba'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), b = balancePrueba(as, plan, c.desde, c.hasta);
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('inicial', 'Saldo inicial', { noTotal: true }), M('debitos', 'Débitos'), M('creditos', 'Créditos'), M('final', 'Saldo final', { noTotal: true })], rows: b.rows,
      kpis: [{ t: 'Cuentas', v: b.rows.length }, { t: 'Débitos', v: c.din(b.totales.debitos) }, { t: 'Créditos', v: c.din(b.totales.creditos) }, { t: 'Diferencia', v: c.din(r2(b.totales.debitos - b.totales.creditos)) }], nota: b.cuadra ? 'Los débitos y créditos del período cuadran.' : 'Atención: los débitos y créditos del período NO cuadran; revise los asientos.' };
  },
  // ---- 3.8: comparativos, centros de costo y presupuesto ----
  async 'estado-resultados-comparativo'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), d1 = sumarMeses(c.desde, -12), h1 = sumarMeses(c.hasta, -12);
    const e = estadoResultados(as, plan, c.desde, c.hasta), e1 = estadoResultados(as, plan, d1, h1), prev = Object.fromEntries(e1.rows.map(x => [x.cuenta, x]));
    const rows = e.rows.map(x => ({ ...x, anterior: prev[x.cuenta] ? prev[x.cuenta].monto : 0 }));
    for (const x of e1.rows) if (!rows.some(y => y.cuenta === x.cuenta)) rows.push({ ...x, monto: 0, anterior: x.monto });
    const k = s => s.split('.').map(x => x.padStart(4, '0')).join('.');
    rows.sort((a, b) => k(a.cuenta).localeCompare(k(b.cuenta)));
    for (const x of rows) { x.variacion = r2(x.monto - x.anterior); x.pct = x.anterior ? r2((x.monto - x.anterior) / Math.abs(x.anterior) * 100) : null; }
    const pc = { key: 'pct', label: 'Variación %', num: true, fmt: v => (v === null || v === undefined ? '' : fmt(v, 1) + ' %') };
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('monto', 'Período', { noTotal: true }), M('anterior', 'Año anterior', { noTotal: true }), M('variacion', 'Variación', { noTotal: true }), pc], rows,
      kpis: [{ t: 'Ingresos', v: c.din(e.ingresos) + ' / ' + c.din(e1.ingresos) }, { t: 'Costos y gastos', v: c.din(r2(e.costos + e.gastos)) + ' / ' + c.din(r2(e1.costos + e1.gastos)) }, { t: (e.neta >= 0 ? 'Utilidad' : 'Pérdida') + ' neta', v: c.din(e.neta) }, { t: 'Año anterior', v: c.din(e1.neta) }],
      totales: [{ label: 'Utilidad bruta del período', v: e.bruta }, { label: 'Utilidad bruta año anterior', v: e1.bruta }, { label: 'Utilidad neta del período', v: e.neta }, { label: 'Utilidad neta año anterior', v: e1.neta }, { label: 'Variación de la utilidad neta', v: r2(e.neta - e1.neta) }],
      nota: 'Comparado con el mismo período del año anterior (' + fecha(d1) + ' – ' + fecha(h1) + '). Las cifras van período / año anterior.' };
  },
  async 'balance-general-comparativo'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), h1 = sumarMeses(c.hasta, -12);
    const b = balanceGeneral(as, plan, c.hasta), b1 = balanceGeneral(as, plan, h1), prev = Object.fromEntries(b1.rows.map(x => [x.id, x]));
    const rows = b.rows.map(x => ({ ...x, anterior: prev[x.id] ? prev[x.id].saldo : 0 }));
    for (const x of b1.rows) if (!rows.some(y => y.id === x.id)) rows.push({ ...x, saldo: 0, anterior: x.saldo });
    const k = s => String(s).split('.').map(x => x.padStart(4, '0')).join('.');
    rows.sort((a, b2) => (a.raiz || '').localeCompare(b2.raiz || '') || k(a.cuenta).localeCompare(k(b2.cuenta)));
    for (const x of rows) { x.variacion = r2(x.saldo - x.anterior); x.pct = x.anterior ? r2((x.saldo - x.anterior) / Math.abs(x.anterior) * 100) : null; }
    const sec = rz => ({ titulo: ({ 1: 'Activos', 2: 'Pasivos', 3: 'Patrimonio' })[rz], columnas: [{ key: 'cuenta', label: 'Cuenta' }, { key: 'nombre', label: 'Nombre' }, { key: 'saldo', label: 'Al ' + fecha(c.hasta), num: true }, { key: 'anterior', label: 'Al ' + fecha(h1), num: true }, { key: 'variacion', label: 'Variación', num: true }], filas: rows.filter(x => x.raiz === rz).map(x => ({ cuenta: x.cuenta, nombre: x.nombre, saldo: c.din(x.saldo), anterior: c.din(x.anterior), variacion: c.din(x.variacion) })) });
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, M('saldo', 'Al ' + fecha(c.hasta), { noTotal: true }), M('anterior', 'Al ' + fecha(h1), { noTotal: true }), M('variacion', 'Variación', { noTotal: true }), { key: 'pct', label: 'Variación %', num: true, fmt: v => (v === null || v === undefined ? '' : fmt(v, 1) + ' %') }], rows, secciones: [sec('1'), sec('2'), sec('3')],
      kpis: [{ t: 'Activos', v: c.din(b.activos) + ' / ' + c.din(b1.activos) }, { t: 'Pasivos', v: c.din(b.pasivos) + ' / ' + c.din(b1.pasivos) }, { t: 'Patrimonio', v: c.din(b.patrimonio) + ' / ' + c.din(b1.patrimonio) }, { t: 'Diferencia', v: c.din(b.diferencia) }],
      nota: 'Saldos acumulados al ' + fecha(c.hasta) + ' contra la misma fecha del año anterior (' + fecha(h1) + '). Las cifras van fecha de corte / año anterior.' };
  },
  async 'resultados-centro-costo'(c) {
    const as = (await cargarAsientos()).filter(a => enRango(a.fecha, c.desde, c.hasta) && !a.cierre), nombres = Object.fromEntries(centrosCosto().map(x => [x.codigo, x.nombre])), m = {};
    for (const a of as) for (const l of a.lineas || []) {
      const rz = String(l.cuenta || '')[0]; if (!['4', '5', '6'].includes(rz)) continue;
      const k = l.centro || '', o = m[k] || (m[k] = { id: k || 'sin', centro: k ? k + ' · ' + (nombres[k] || '') : 'Sin centro de costo', lineas: 0, ingresos: 0, costos: 0, gastos: 0 });
      const v = (+l.debito || 0) - (+l.credito || 0); o.lineas++;
      if (rz === '4') o.ingresos = r2(o.ingresos - v); else if (rz === '5') o.costos = r2(o.costos + v); else o.gastos = r2(o.gastos + v);
    }
    const rows = Object.values(m).map(o => ({ ...o, resultado: r2(o.ingresos - o.costos - o.gastos) })).sort((a, b) => (a.id === 'sin') - (b.id === 'sin') || b.resultado - a.resultado);
    return { cols: [{ key: 'centro', label: 'Centro de costo' }, N('lineas', 'Líneas'), M('ingresos', 'Ingresos'), M('costos', 'Costos'), M('gastos', 'Gastos'), M('resultado', 'Resultado')], rows,
      kpis: [{ t: 'Centros', v: rows.filter(x => x.id !== 'sin').length }, { t: 'Ingresos', v: c.din(c.suma(rows, 'ingresos')) }, { t: 'Costos y gastos', v: c.din(r2(c.suma(rows, 'costos') + c.suma(rows, 'gastos'))) }, { t: 'Resultado', v: c.din(c.suma(rows, 'resultado')) }],
      nota: 'Solo cuentas de resultados (ingresos, costos y gastos) según el centro de costo indicado en cada línea del asiento; lo que no tiene centro queda en «Sin centro de costo». Los centros se administran en Contabilidad › Centros de costo.' };
  },
  async 'presupuesto-vs-real'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as), s = saldos(as, plan, c.desde, c.hasta);
    const meses = []; let ym = c.desde.slice(0, 7); while (ym <= c.hasta.slice(0, 7) && meses.length < 60) { meses.push(ym); ym = sumarMeses(ym + '-01', 1).slice(0, 7); }
    const pres = {}, porAnio = {};
    for (const x of meses) { const [a, mm] = x.split('-'); const p = porAnio[a] || (porAnio[a] = presupuesto(+a)); for (const [cod, arr] of Object.entries(p.cuentas || {})) pres[cod] = r2((pres[cod] || 0) + (+((arr || [])[+mm - 1]) || 0)); }
    const rows = Object.values(s).filter(o => o.hoja && ['4', '5', '6'].includes(o.raiz) && (Math.abs(o.movimiento) > 0.004 || pres[o.cuenta])).map(o => { const p = pres[o.cuenta] || 0, real = o.movimiento; return { id: o.cuenta, cuenta: o.cuenta, nombre: o.nombre, grupo: NOMBRE_RAIZ[o.raiz], presupuesto: p, real, diferencia: r2(real - p), pct: p ? r2(real / p * 100) : null }; });
    const tot = rz => rows.filter(x => x.cuenta[0] === rz).reduce((t, x) => ({ p: r2(t.p + x.presupuesto), r: r2(t.r + x.real) }), { p: 0, r: 0 });
    const i = tot('4'), co = tot('5'), g = tot('6'), resP = r2(i.p - co.p - g.p), resR = r2(i.r - co.r - g.r);
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, { key: 'grupo', label: 'Grupo' }, M('presupuesto', 'Presupuesto', { noTotal: true }), M('real', 'Real', { noTotal: true }), M('diferencia', 'Diferencia', { noTotal: true }), { key: 'pct', label: 'Ejecución %', num: true, fmt: v => (v === null || v === undefined ? '' : fmt(v, 1) + ' %') }], rows,
      kpis: [{ t: 'Ingresos presupuesto / real', v: c.din(i.p) + ' / ' + c.din(i.r) }, { t: 'Costos y gastos presupuesto / real', v: c.din(r2(co.p + g.p)) + ' / ' + c.din(r2(co.r + g.r)) }, { t: 'Resultado presupuestado', v: c.din(resP) }, { t: 'Resultado real', v: c.din(resR) }],
      totales: [{ label: 'Ingresos: presupuesto', v: i.p }, { label: 'Ingresos: real', v: i.r }, { label: 'Costos y gastos: presupuesto', v: r2(co.p + g.p) }, { label: 'Costos y gastos: real', v: r2(co.r + g.r) }, { label: 'Resultado presupuestado', v: resP }, { label: 'Resultado real', v: resR }],
      nota: (Object.keys(pres).length ? 'Presupuesto de los meses del período (' + meses.length + ') contra el movimiento real de los asientos.' : 'No hay presupuesto para estos meses: cárguelo en Contabilidad › Presupuesto.') + ' Ejecución % = real entre presupuesto.' };
  },
  // ---- punto de venta (3.9): impuesto de servicio 10 % y propinas ----
  async 'servicio-10'(c) {
    const rows = servicioPorDia(c.desde, c.hasta).map(x => ({ id: x.fecha, ...x }));
    return { cols: [D('fecha', 'Día'), N('ventas', 'Ventas'), M('total', 'Vendido'), M('servicio', 'Impuesto de servicio'), M('propinas', 'Propinas'), M('repartir', 'Total a repartir')], rows,
      kpis: [{ t: 'Ventas', v: c.suma(rows, 'ventas') }, { t: 'Impuesto de servicio', v: c.din(c.suma(rows, 'servicio')) }, { t: 'Propinas', v: c.din(c.suma(rows, 'propinas')) }, { t: 'Total a repartir', v: c.din(c.suma(rows, 'repartir')) }],
      nota: 'Ventas de la caja con impuesto de servicio (otros cargos, 10 %) y propinas voluntarias. Para repartir entre todo el personal; la calculadora por persona está en Punto de venta › Servicio 10 % y propinas.' };
  },
  async 'servicio-por-salonero'(c) {
    const rows = servicioPorSalonero(c.desde, c.hasta).map(x => ({ id: x.salonero, ...x }));
    return { cols: [{ key: 'salonero', label: 'Salonero' }, N('ventas', 'Ventas'), M('total', 'Vendido'), M('servicio', 'Impuesto de servicio'), M('propinas', 'Propinas'), M('repartir', 'Total')], rows,
      kpis: [{ t: 'Saloneros', v: rows.filter(x => x.salonero !== '—').length }, { t: 'Impuesto de servicio', v: c.din(c.suma(rows, 'servicio')) }, { t: 'Propinas', v: c.din(c.suma(rows, 'propinas')) }, { t: 'Total', v: c.din(c.suma(rows, 'repartir')) }],
      nota: '«—» = ventas cobradas sin elegir salonero. Los saloneros se definen por caja en Punto de venta › Configuración.' };
  },
  async 'libro-mayor'(c) {
    const as = await cargarAsientos(), plan = planConUsadas(as);
    const rows = libroMayor(as, plan, c.desde, c.hasta, c.cuenta || null);
    return { cols: [{ key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, D('fecha', 'Fecha'), { key: 'asiento', label: 'Asiento', mono: true }, { key: 'descripcion', label: 'Descripción' }, MB('debito', 'Débito', { noTotal: true }), MB('credito', 'Crédito', { noTotal: true }), M('saldo', 'Saldo', { noTotal: true })], rows,
      kpis: [{ t: 'Cuentas con movimiento', v: new Set(rows.map(x => x.cuenta)).size }, { t: 'Movimientos', v: rows.filter(x => !x.inicial && !x.final).length }] };
  },
  async 'movimientos-por-cuenta'(c) {
    if (!c.cuenta) return { cols: [], rows: [], aviso: 'Elija una cuenta contable para ver sus movimientos.' };
    const r = await REPORTES['libro-mayor'](c); return { ...r, subtitulo: 'Cuenta ' + c.cuenta + ' · ' + (c.plan.find(x => x.codigo === c.cuenta) || {}).nombre };
  },
  async 'libro-diario'(c) {
    const as = (await cargarAsientos()).filter(a => enRango(a.fecha, c.desde, c.hasta)).sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)) || a.id - b.id);
    const rows = as.flatMap(a => (a.lineas || []).map((l, i) => ({ id: a.id + '-' + i, fecha: a.fecha, asiento: a.codigo, tipo: a.tipo, cuenta: l.cuenta, nombre: l.cuenta_nombre, descripcion: l.descripcion || a.observaciones || '', contacto: l.contacto || '', debito: +l.debito || 0, credito: +l.credito || 0 })));
    return { cols: [D('fecha', 'Fecha'), { key: 'asiento', label: 'Asiento', mono: true }, { key: 'tipo', label: 'Tipo' }, { key: 'cuenta', label: 'Cuenta', mono: true }, { key: 'nombre', label: 'Nombre' }, { key: 'descripcion', label: 'Descripción' }, M('debito', 'Débito'), M('credito', 'Crédito')], rows, kpis: [{ t: 'Asientos', v: as.length }, { t: 'Movimientos', v: rows.length }, { t: 'Débitos', v: c.din(c.suma(rows, 'debito')) }, { t: 'Créditos', v: c.din(c.suma(rows, 'credito')) }] };
  },
  async 'libro-inventarios-balances'(c) {
    const [bg, inv] = await Promise.all([REPORTES['balance-general'](c), REPORTES['valor-inventario']({ ...c, bodega: '' })]);
    const invSec = { titulo: 'Inventario valorado al ' + fecha(c.hasta), columnas: inv.cols.map(x => ({ key: x.key, label: x.label, num: !!x.num })), filas: inv.rows.map(r => ({ item: r.item, codigo: r.codigo, existencias: fmt(r.existencias, 2), costo: c.din(r.costo), total: c.din(r.total) })), totales: [{ t: 'Valor del inventario', v: c.din(c.suma(inv.rows, 'total')) }] };
    return { ...bg, kpis: [{ t: 'Inventario', v: c.din(c.suma(inv.rows, 'total')) }, ...bg.kpis.slice(0, 3)], secciones: [invSec, ...bg.secciones], extra: { titulo: 'Inventario valorado', cols: inv.cols, rows: inv.rows } };
  },
  async 'auxiliar-terceros'(c) {
    const tipos = Object.fromEntries(store.clientes.map(x => [x.nombre, x.tipo === 'Ambos' ? 'Cliente y proveedor' : (x.tipo || 'Cliente')]));
    const nombre = c.cliente ? (store.clientes.find(x => String(x.id) === String(c.cliente)) || {}).nombre : '';
    const rows = auxiliarTerceros(await cargarAsientos(), c.desde, c.hasta, t => tipos[t] || 'Tercero').filter(x => !nombre || x.tercero === nombre);
    return { cols: [{ key: 'tercero', label: 'Tercero' }, { key: 'tipo', label: 'Tipo' }, N('movimientos', 'Movimientos'), M('debito', 'Débitos'), M('credito', 'Créditos'), M('saldo', 'Saldo (débitos − créditos)', { noTotal: true })], rows, kpis: [{ t: 'Terceros', v: rows.length }, { t: 'Débitos', v: c.din(c.suma(rows, 'debito')) }, { t: 'Créditos', v: c.din(c.suma(rows, 'credito')) }] };
  },
  async 'comprobantes-contables'(c) {
    const rows = (await cargarAsientos()).filter(a => enRango(a.fecha, c.desde, c.hasta)).map(a => ({ id: a.id, codigo: a.codigo, numeracion: a.numeracion || String(a.codigo || '').split('-')[0], fecha: a.fecha, tipo: a.tipo, origen: a.automatico ? (a.ajustado ? 'Automático ajustado' : 'Automático') : 'Manual', observaciones: a.observaciones || '', debito: r2((a.lineas || []).reduce((s, l) => s + (+l.debito || 0), 0)), credito: r2((a.lineas || []).reduce((s, l) => s + (+l.credito || 0), 0)) }))
      .sort((a, b) => a.numeracion.localeCompare(b.numeracion) || (+String(a.codigo).split('-')[1] || 0) - (+String(b.codigo).split('-')[1] || 0));
    return { cols: [{ key: 'codigo', label: 'Código', mono: true, link: x => location.hash = '/contabilidad/asientos/' + x.id }, { key: 'numeracion', label: 'Numeración' }, D('fecha', 'Fecha'), { key: 'tipo', label: 'Tipo' }, { key: 'origen', label: 'Origen', fmt: 'badge' }, { key: 'observaciones', label: 'Observaciones' }, M('debito', 'Débito'), M('credito', 'Crédito')], rows, kpis: [{ t: 'Asientos', v: rows.length }, { t: 'Manuales', v: rows.filter(x => x.origen === 'Manual').length }, { t: 'Automáticos', v: rows.filter(x => x.origen !== 'Manual').length }] };
  },
  async 'declaracion-iva-d104'(c) {
    const porMon = MODO.sinTc ? c.p : '';   // 4.3: vista por moneda (solo lo hecho en esa moneda, en esa moneda); sin ella, la declaración en colones
    const r = await api('/api/resumen/iva?desde=' + c.desde + '&hasta=' + c.hasta + (porMon ? '&moneda=' + porMon : ''));
    const rows = (r.filas || []).map(f => ({ id: f.codigo, ...f }));
    const deb = c.suma(rows, 'debito'), cred = c.suma(rows, 'credito'), neto = r2(deb - cred);
    const exo = c.suma(rows, 'exonerado');      // ventas con exoneración: IVA que no se cobró (fila aparte)
    return { cols: [{ key: 'tarifa', label: 'Tarifa' }, M('ventas', 'Ventas (base)'), M('debito', 'IVA débito'), ...(exo ? [M('exonerado', 'IVA exonerado')] : []), M('compras', 'Compras (base)'), M('credito', 'IVA crédito')], rows,
      kpis: [{ t: 'IVA débito (ventas)', v: money(deb, c.p) }, { t: 'IVA crédito (compras)', v: money(cred, c.p) }, ...(exo ? [{ t: 'IVA exonerado (no cobrado)', v: money(exo, c.p) }] : []), { t: neto >= 0 ? 'Impuesto a pagar' : 'Saldo a favor', v: money(Math.abs(neto), c.p) }],
      nota: (porMon ? 'Solo lo hecho en ' + (porMon === 'USD' ? 'dólares, en dólares' : 'colones') + ', sin tipo de cambio: es una vista de control, NO lo que se declara (la declaración va en colones con el tipo de cambio de cada comprobante). ' : 'Montos en colones con el tipo de cambio de cada comprobante: así se declara. ') + 'Ventas: líneas de los comprobantes emitidos (las ventas con IVA diferido entran con su recibo electrónico de pago). Compras: facturas electrónicas de compra y compras registradas a mano por tarifa; de los comprobantes recibidos se toma el IVA acreditable indicado al aceptarlos. Las ventas con exoneración van en una fila aparte con el IVA no cobrado. Verifique la proporcionalidad antes de declarar.' + (r.tc_disponible === false ? ' Sin tipo de cambio del día: los documentos en dólares sin tipo de cambio propio no se convierten.' : '') };
  },
  async 'retenciones'(c) {
    const rows = [];
    for (const x of compras()) if (enRango(x.creacion, c.desde, c.hasta) && (x.retenciones || []).length) {
      const base = (x.lineas || []).reduce((s, l) => s + (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0), 0);
      for (const [i, rt] of (x.retenciones || []).entries()) rows.push({ id: 'c' + x.id + '-' + i, fecha: x.creacion, tercero: x.proveedor || '—', origen: 'Factura de compra ' + (x.numero || ''), tipo: rt.nombre || 'Retención', __tc: tcUsd(x.tipo_cambio, x.creacion), base: aRep(base, x.moneda, tcFila(x.tipo_cambio, x.creacion)), pct: +rt.pct || 0, monto: aRep(base * (+rt.pct || 0) / 100, x.moneda, tcFila(x.tipo_cambio, x.creacion)) });
    }
    for (const p of pagosGastos()) if (enRango(p.fecha, c.desde, c.hasta)) for (const [i, rt] of (p.retenciones || []).entries()) if (+rt.monto > 0) rows.push({ id: 'p' + p.id + '-' + i, fecha: p.fecha, tercero: p.contacto || '—', origen: 'Pago ' + (p.numero || ''), tipo: rt.nombre || 'Retención', base: null, pct: null, __tc: tcUsd(p.tipo_cambio, p.fecha), monto: aRep(+rt.monto, p.moneda, tcFila(p.tipo_cambio, p.fecha)) });
    rows.sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)));
    return { cols: [D('fecha', 'Fecha'), { key: 'tercero', label: 'Proveedor' }, { key: 'origen', label: 'Origen' }, { key: 'tipo', label: 'Tipo de retención' }, MB('base', 'Base'), { key: 'pct', label: '%', num: true, fmt: v => v === null || v === undefined ? '' : fmt(v, 2) }, M('monto', 'Retenido')], rows,
      kpis: [{ t: 'Retenciones', v: rows.length }, { t: 'Total retenido', v: c.din(c.suma(rows, 'monto')) }], nota: 'Retenciones aplicadas a proveedores en facturas de compra y pagos (por pagar a Hacienda). Las retenciones que le aplican sus clientes se registran al cobrar.' };
  },
  async 'tareas-pendientes'(c) {
    const rows = (mock.get('tareas', []) || []).filter(t => t.estado !== 'Hecho' && t.estado !== 'Archivados' && (!t.fecha || enRango(t.fecha, c.desde, c.hasta))).sort((a, b) => String(a.fecha || '').localeCompare(String(b.fecha || '')));
    return { cols: [{ key: 'titulo', label: 'Tarea' }, D('fecha', 'Fecha de entrega'), { key: 'responsable', label: 'Responsable' }, { key: 'prioridad', label: 'Prioridad', fmt: 'badge' }, { key: 'estado', label: 'Estado', fmt: 'badge' }], rows, kpis: [{ t: 'Pendientes', v: rows.length }, { t: 'Vencidas', v: rows.filter(t => t.fecha && t.fecha < hoy()).length }, { t: 'Prioridad alta', v: rows.filter(t => t.prioridad === 'Alta').length }] };
  },
  async 'documentos-por-conciliar'(c) {
    const bs = bancos(), porId = Object.fromEntries(bs.map(b => [b.id, b])), rows = [], refs = new Set(movimientos().map(m => m.ref).filter(Boolean));
    for (const m of movimientos()) { const b = porId[m.banco_id]; if (!b || m.conciliado || (c.banco && String(m.banco_id) !== String(c.banco))) continue; rows.push({ id: 'm' + m.id, fecha: m.fecha, origen: 'Movimiento bancario', cuenta: b.nombre, detalle: m.descripcion || '', monto: r2(aPrincipal(+m.monto || 0, b.moneda, m.tipo_cambio)), estado: 'Sin conciliar' }); }
    for (const p of await pagos()) if (!refs.has('pago:' + p.id) && (p.estado || 'No conciliado') === 'No conciliado' && (!c.banco || (porId[c.banco] || {}).nombre === p.cuenta)) rows.push({ id: 'p' + p.id, fecha: p.fecha, origen: 'Pago recibido', cuenta: p.cuenta || '—', detalle: (p.cliente_nombre || '') + (p.consecutivo ? ' · ' + p.consecutivo : ' · Recibo #' + p.numero), monto: r2(aPrincipal(+p.monto || 0, p.moneda, p.tipo_cambio)), estado: 'Sin conciliar' });
    for (const p of pagosGastos()) if (!(p.ref_mov && refs.has(p.ref_mov)) && (p.estado || 'No conciliado') === 'No conciliado' && (!c.banco || (porId[c.banco] || {}).nombre === String(p.cuenta || '').split(' · ')[0])) rows.push({ id: 'g' + p.id, fecha: p.fecha, origen: 'Pago a proveedor', cuenta: String(p.cuenta || '—').split(' · ')[0], detalle: (p.contacto || '') + ' · ' + (p.numero || ''), monto: r2(-aPrincipal(+p.monto || 0, p.moneda, p.tipo_cambio)), estado: 'Sin conciliar' });
    rows.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    return { cols: [D('fecha', 'Fecha'), { key: 'origen', label: 'Origen' }, { key: 'cuenta', label: 'Cuenta' }, { key: 'detalle', label: 'Detalle' }, M('monto', 'Monto'), { key: 'estado', label: 'Estado', fmt: 'badge' }], rows, kpis: [{ t: 'Pendientes', v: rows.length }, { t: 'Movimientos bancarios', v: rows.filter(x => x.origen === 'Movimiento bancario').length }, { t: 'Pagos', v: rows.filter(x => x.origen !== 'Movimiento bancario').length }], nota: 'Movimientos de Bancos sin marcar como conciliados y pagos registrados que aún no se han conciliado con el banco.' };
  },
};

export default {
  props: ['params'],
  data() {
    const erm = this.params && this.params.rep === 'estado-resultados-mensual', y = +hoy().slice(0, 4), ym = hoy().slice(0, 7);   // 4.1: por mes arranca en el acumulado del mes
    return { vistaDecl: 'decl', impSel: '', impresorasLista: impresorasReporte(), erAnio: y, erMes: +hoy().slice(5, 7), erModo: 'acumulado', tcPie: null, monedaRep: '', princ: monedas.principal().codigo || 'CRC', convertir: false, res: null, cargando: true, ...(erm ? { desde: y + '-01-01', hasta: finMes(ym) } : { desde: sumarMeses(hoy(), -1), hasta: hoy() }), ...fechasEnlace(this.params), cliente: this.params && this.params.cliente ? String(this.params.cliente) : '', vendedor: '', cuenta: '', banco: '', bodega: '', bodegas: [], vendedores: mock.get('vendedores', []) || [], plan: [], timer: null, seq: 0 };
  },
  computed: {
    cat() { return CATALOGO[this.params.cat]; },
    rep() { return buscarReporte(this.params.cat, this.params.rep); },
    slug() { return this.params.rep; },
    existe() { return !!REPORTES[this.slug]; },
    permitido() { return puedeReporte(this.params.cat, this.slug); },   // 3.87: el permiso del reporte, no solo el de su categoría
    conCliente() { return CON_CLIENTE.includes(this.slug); },
    conVendedor() { return CON_VENDEDOR.includes(this.slug); },
    conCuenta() { return CON_CUENTA.includes(this.slug); },
    conBanco() { return CON_BANCO.includes(this.slug); },
    conBodega() { return CON_BODEGA.includes(this.slug); },
    conDesde() { return !SIN_DESDE.includes(this.slug); },
    p() { if (EN_COLONES.includes(this.slug)) return this.vistaDecl === 'decl' ? 'CRC' : this.vistaDecl; if (SIN_SELECTOR.has(this.slug)) return this.princ; return this.convertir ? this.princ : (this.monedaRep || this.princ); },   // 4.1: sin elegir, la moneda principal de la empresa
    monedaSel: { get() { return this.monedaRep || this.princ; }, set(v) { this.monedaRep = v === this.princ ? '' : v; } },   // 3.99: moneda del reporte (sin tipo de cambio salvo «Convertir todo»)
    porMes() { return this.slug === 'estado-resultados-mensual'; },   // 4.1: cuántos asientos tiene cada mes
    // 4.1: el mes de la barra que corresponde a las fechas (0 si es un rango libre)
    mesSel() {
      const h = String(this.hasta || ''), y = +h.slice(0, 4), m = +h.slice(5, 7);
      if (!y || !m || y !== this.erAnio || h !== finMes(h.slice(0, 7))) return 0;
      if (!this.conDesde) return m;
      return this.desde === h.slice(0, 7) + '-01' || this.desde === y + '-01-01' ? m : 0;
    },
    enColones() { return EN_COLONES.includes(this.slug) || SIN_SELECTOR.has(this.slug); },   // sin selector de moneda
    esDeclaracion() { return EN_COLONES.includes(this.slug); },   // 4.3: selector propio: declaración en colones o vista por moneda
    bancosOpc() { return bancos(); },
    columns() { return ((this.res && this.res.cols) || []).map(c => (c.fmt === 'money' || c.sumar ? { ...c, moneda: this.p } : c)); },   // símbolo de la moneda del reporte, no de la fila
    rows() { return (this.res && this.res.rows) || []; },
    kpis() {
      if (this.res && this.res.kpis) return this.res.kpis;
      const rs = this.rows, numCols = this.columns.filter(c => (c.fmt === 'money' || c.sumar) && !c.noTotal).slice(0, 3);
      return [{ t: 'Registros', v: rs.length }, ...numCols.map(c => ({ t: 'Total ' + c.label.toLowerCase(), v: money(this.suma(rs, c.key), this.p) }))];
    },
    totales() { const extra = (this.res && this.res.totalesColones) || []; if (this.res && this.res.totales) return [...this.res.totales, ...extra]; return [...this.columns.filter(c => (c.fmt === 'money' || c.sumar) && !c.noTotal).map(c => ({ label: c.label, v: this.suma(this.rows, c.key) })), ...extra]; },
    tcMostrar() { return this.tcPie && (this.p === 'USD' || this.esDeclaracion || this.rows.some(r => r.moneda_doc === 'USD')) ? this.tcPie : null; },   // 4.18
    tcTexto() { const t = this.tcMostrar; return t ? 'Tipo de cambio de referencia del Banco Central de Costa Rica al ' + fecha(t.fecha) + ': compra ' + money(t.compra, 'CRC') + ' · venta ' + money(t.venta, 'CRC') + ' (la que se usa)' : ''; },
    nota() { return (this.res && this.res.nota) || ''; },
    aviso() { return (this.res && this.res.aviso) || ''; },
    info() { return (this.res && this.res.info) || ''; },
    extra() { return this.res && this.res.extra; },
    periodoTexto() { return (this.conDesde ? fecha(this.desde) + ' – ' : 'Al ') + fecha(this.hasta); },
    filtroCliente() { const c = this.cliente; return d => !c || String(d.cliente_id) === String(c); },
    filtroVendedor() { const v = String(this.vendedor || '').trim().toLowerCase(); return d => !v || String(d.vendedor || '').trim().toLowerCase() === v; },
  },
  watch: {
    monedaRep() { this.recargar(); }, convertir() { this.recargar(); }, vistaDecl() { this.recargar(); }, erModo() { if (this.mesSel) this.aplicarMes(); }, erAnio() { this.aplicarMes(); },
    desde() { this.recargar(); }, hasta() { this.recargar(); }, cliente() { this.recargar(); }, vendedor() { this.recargar(); }, cuenta() { this.recargar(); }, banco() { this.recargar(); }, bodega() { this.recargar(); },
    'params.rep'() { this.res = null; this.cuenta = ''; this.banco = ''; this.recargar(); },
    // 4.9: enlace directo (?cliente=&desde=&hasta=, p. ej. desde la ficha del contacto): si solo cambia la consulta la pantalla no se vuelve a montar
    'params.cliente'(v) { this.cliente = v ? String(v) : ''; }, 'params.desde'(v) { if (FECHA_RE.test(v || '')) this.desde = v; }, 'params.hasta'(v) { if (FECHA_RE.test(v || '')) this.hasta = v; },
  },
  methods: {
    puedeCategoria,
    money, fmt, fecha,
    suma(rows, k) { return r2(rows.reduce((s, x) => s + (+x[k] || 0), 0)); },
    din(v) { return money(v, this.p); },
    // 4.1: barra de meses: Acumulado = del 1 de enero al fin del mes; Mensual = solo ese mes; en los reportes «al día», el cierre del mes
    elegirMes(m) { this.erMes = m; this.aplicarMes(); },
    aplicarMes() {
      const mm = String(this.erMes).padStart(2, '0'), fin = finMes(this.erAnio + '-' + mm);
      if (this.conDesde) this.desde = this.erModo === 'mensual' ? this.erAnio + '-' + mm + '-01' : this.erAnio + '-01-01';
      this.hasta = fin;
    },
    recargar() { clearTimeout(this.timer); this.timer = setTimeout(() => this.cargar(), 250); },
    async cargar(manual) {
      if (!this.rep || !this.existe || !this.permitido) { this.cargando = false; return; }
      if (this.desde > this.hasta && this.conDesde) { toast('La fecha «Desde» es posterior a «Hasta»', 'err'); return; }
      this.cargando = true;
      const n = ++this.seq;     // si llega otra carga mientras tanto, la respuesta vieja se descarta
      this.princ = monedas.principal().codigo || 'CRC';   // 4.1: la moneda principal vigente en cada carga
      MODO.sinTc = (!this.convertir && !EN_COLONES.includes(this.slug) && !SIN_SELECTOR.has(this.slug)) || (EN_COLONES.includes(this.slug) && this.vistaDecl !== 'decl'); MODO.moneda = this.p;   /* 3.99; 4.3: declaraciones por moneda */
      MODO.desde = this.conDesde ? this.desde : ''; MODO.hasta = this.hasta; MODO.memo = {}; MODO.tcOrigen = null; MODO.sombra = false;
      const ctx = { desde: this.conDesde ? this.desde : '', hasta: this.hasta, cliente: this.cliente, vendedor: this.vendedor, cuenta: this.cuenta, banco: this.banco, bodega: this.bodega, p: this.p, plan: this.plan, suma: this.suma, din: this.din, filtroCliente: this.filtroCliente, filtroVendedor: this.filtroVendedor };
      api('/api/tipo-cambio/dia?fecha=' + this.hasta).then(d => { if (n === this.seq) this.tcPie = d && d.venta ? d : null; }).catch(() => {});   // 4.18: el pie del reporte
      try { await cargarTcDia(); const r = await REPORTES[this.slug](ctx); if (n !== this.seq) return;
        if (ASIENTOS_MON.has(this.slug) && MODO.sinTc && r && !r.aviso) { const o = Object.entries(OTRAS.n).filter(([, k]) => k > 0); if (o.length) r.info = 'Este estado muestra solo lo hecho en ' + (NOMBRE_MON[this.p] || this.p) + '. En el período también hay ' + o.map(([m, k]) => k + ' asiento(s) en ' + (NOMBRE_MON[m] || m)).join(' y ') + ': elija esa moneda arriba para ver su propio estado, o marque «Convertir todo» para verlo completo en la moneda principal.'; }   /* 4.1 */
        let sombra = null;
        if (this.p === 'USD' && CON_SOMBRA.has(this.slug) && r && !r.aviso) { MODO.sombra = true; try { sombra = await REPORTES[this.slug](ctx); } finally { MODO.sombra = false; } if (n !== this.seq) return; }   // 4.19
        this.res = agregarColones(r, this.p, sombra, COL_BASE[this.slug]); if (manual) toast('Reporte actualizado', 'ok'); }
      catch (e) { if (n !== this.seq) return; toast('No se pudo cargar el reporte: ' + e.message, 'err'); this.res = { cols: [], rows: [] }; }
      this.cargando = false;
    },
    celda(row, c) {
      const v = row[c.key];
      if (typeof c.fmt === 'function') return c.fmt(v, row);
      if (c.fmt === 'money') return v === null || v === undefined ? '' : fmt(v);
      if (c.fmt === 'date') return fecha(v);
      return v ?? '';
    },
    colsDoc(cols) { return cols.map(c => ({ ...c, fmt: c.fmt === 'money' || c.sumar ? v => (v === null || v === undefined ? '' : money(v, c.monedaFija || this.p)) : c.fmt })); },
    datosDoc() {   // 4.3: lo mismo que va al PDF, para imprimir
      const cli = this.cliente ? ((store.clientes || []).find(c => String(c.id) === String(this.cliente)) || {}).nombre : '', secciones = (this.res && this.res.secciones) || [];
      const sub = [this.rep.desc, (this.res && this.res.subtitulo) || '', cli ? 'Cliente: ' + cli : '', this.vendedor ? 'Vendedor: ' + this.vendedor : ''].filter(Boolean).join(' · ').slice(0, 300);
      return { titulo: this.rep.nombre, subtitulo: sub, periodo: this.periodoTexto, cols: secciones.length ? [] : this.colsDoc(this.columns), rows: secciones.length ? [] : this.rows, kpis: this.kpis,
        totales: secciones.length ? [] : this.totales.map(t => ({ t: t.label, v: money(t.v, t.moneda || this.p) })), nota: (this.nota ? this.nota + ' ' : '') + 'Montos en ' + this.p + '.' + (this.tcTexto ? ' ' + this.tcTexto + '.' : ''), secciones };
    },
    async imprimir() {   // 4.3: impresora de tiquetes (agente) o la del equipo
      const imp = this.impresorasLista.find(i => String(i.id) === String(this.impSel)) || null;
      try { const d = await imprimirReporte(this.datosDoc(), imp, store.empresa); if (d === 'agente') toast('Reporte enviado a «' + imp.nombre + '»', 'ok'); }
      catch (e) { toast(await avisoImpresion('No se imprimió' + (imp ? ' en «' + imp.nombre + '»' : '') + ': ', e), 'err'); }
    },
    descargarDoc(formato) {   // PDF o Word con el encabezado de la empresa, las cifras y los totales
      const cli = this.cliente ? (store.clientes.find(c => String(c.id) === String(this.cliente)) || {}).nombre : '';
      const sub = [this.rep.desc, (this.res && this.res.subtitulo) || '', cli ? 'Cliente: ' + cli : '', this.vendedor ? 'Vendedor: ' + this.vendedor : ''].filter(Boolean).join(' · ').slice(0, 300);
      const secciones = (this.res && this.res.secciones) || [];
      descargarReporte(formato, { titulo: this.rep.nombre, subtitulo: sub, periodo: this.periodoTexto, cols: secciones.length ? [] : this.colsDoc(this.columns), rows: secciones.length ? [] : this.rows, kpis: this.kpis,
        totales: secciones.length ? [] : this.totales.map(t => ({ t: t.label, v: money(t.v, t.moneda || this.p) })), nota: (this.nota ? this.nota + ' ' : '') + 'Montos en ' + this.p + '.', archivo: this.slug, secciones, tipo_cambio: this.tcMostrar ? { fecha: this.tcMostrar.fecha, compra: this.tcMostrar.compra, venta: this.tcMostrar.venta } : null });
    },
    async excel() {   // 3.98: Excel con formato, listo para usar
      const texto = v => String(v ?? '').replace(/<[^>]*>/g, '');
      const unaMoneda = new Set(this.rows.map(r => r.moneda).filter(Boolean)).size <= 1;   /* colones y dólares no se suman juntos */
      const cols = this.columns.map(c => {
        const num = c.fmt === 'money' || c.fmt === 'num' || !!c.sumar;
        return { key: c.key, label: c.label, num, sumar: unaMoneda && (c.fmt === 'money' || !!c.sumar), fecha: c.fmt === 'date',
          valor: r => { const v = r[c.key]; if (c.fmt === 'date') return fecha(v); if (num) return v === null || v === undefined || v === '' ? null : +v || 0; return typeof c.fmt === 'function' ? texto(c.fmt(v, r)) : v; } };
      });
      try {
        const archivo = await descargarExcel(`${this.slug}_${this.desde}_${this.hasta}`, { tipo_cambio: this.tcMostrar ? { fecha: this.tcMostrar.fecha, compra: this.tcMostrar.compra, venta: this.tcMostrar.venta } : null, titulo: this.rep.nombre, subtitulo: this.rep.desc, periodo: this.periodoTexto, cols, rows: this.rows });
        toast('Archivo ' + archivo + ' descargado', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    },
    descargar() {   // una sola función de CSV para todos los reportes (R326)
      const cols = this.columns.map(c => ({ ...c, csv: c.fmt === 'date' ? v => fecha(v) : (c.fmt === 'money' || c.fmt === 'num' || c.sumar ? v => (v === null || v === undefined ? '' : +v || 0) : (typeof c.fmt === 'function' ? (v, r) => c.fmt(v, r) : undefined)) }));
      const archivo = descargarCSV(`${this.slug}_${this.desde}_${this.hasta}`, cols, this.rows, archivo => { const h = mock.get('reportes_exportables', []); h.unshift({ archivo, reporte: this.rep?.nombre, fecha: new Date().toISOString() }); mock.set('reportes_exportables', h.slice(0, 20)); }, this.tcTexto);
      toast('Archivo ' + archivo + ' descargado', 'ok');
    },
  },
  async created() {
    if (this.rep && this.rep.ruta) { location.replace('#' + this.rep.ruta); return; }   // 4.9: el reporte tiene pantalla propia (Revendedoras, Estado de cuenta de revendedora)
    if (this.rep && this.permitido) registrarReciente(this.params.cat, this.rep);
    try { this.plan = planCuentas(); } catch { this.plan = []; }
    if (this.conBodega) { try { this.bodegas = await api('/api/inventario/bodegas'); } catch { this.bodegas = []; } }
    this.cargar();
  },
  template: `
  <div class="page" v-if="!permitido"><div class="card"><Empty icon="🔒" title="Sin acceso a este reporte" text="Su rol no tiene permiso sobre el módulo de este reporte."><a class="btn sec" href="#/reportes">Volver a Reportes</a></Empty></div></div>
  <div class="page" v-else>
    <PageHead :title="rep ? rep.nombre : 'Reporte no encontrado'" :sub="rep ? rep.desc : ''"
      :crumbs="[{label:'Reportes',to:'/reportes'},{label:cat ? cat.nombre : params.cat, to:'/reportes/'+params.cat},{label:rep ? rep.nombre : params.rep}]">
      <button class="btn ghost" @click="cargar(true)" :disabled="cargando">↻ Actualizar</button>
      <select class="inp" v-if="impresorasLista.length" v-model="impSel" title="Dónde imprimir" style="max-width:190px"><option value="">Impresora del equipo</option><option v-for="i in impresorasLista" :key="i.id" :value="i.id">{{i.nombre}} (tiquete)</option></select>
      <button class="btn sec" @click="imprimir" :disabled="!rows.length && !(res && res.secciones && res.secciones.length)" :title="impSel ? 'Imprimir en la impresora de tiquetes' : 'Imprimir: el navegador deja elegir la impresora'">⎙ Imprimir</button>
      <button class="btn sec" @click="descargarDoc('pdf')" :disabled="!rows.length">⤓ PDF</button>
      <button class="btn sec" @click="descargarDoc('docx')" :disabled="!rows.length">⤓ Word</button>
      <button class="btn sec" @click="excel" :disabled="!rows.length" title="Excel con formato, listo para usar">⤓ Excel</button>
      <button class="btn ghost" @click="descargar" :disabled="!rows.length" title="Archivo de texto para importar en otros sistemas">⤓ CSV</button>
    </PageHead>

    <div class="card" v-if="!rep || !existe"><Empty icon="⚠" title="Reporte no encontrado" text="El reporte indicado no existe en esta categoría."><a class="btn" href="#/reportes">Ir a reportes</a></Empty></div>
    <template v-else>
      <div class="card">
        <div class="grid">
          <Field label="Desde" v-if="conDesde"><input type="date" v-model="desde"></Field>
          <Field :label="conDesde ? 'Hasta' : 'Al día'"><input type="date" v-model="hasta"></Field>
          <div style="grid-column:1/-1;display:flex;flex-wrap:wrap;gap:6px;align-items:center">
            <button class="btn sm ghost" type="button" @click="erAnio--">‹</button><b style="min-width:44px;text-align:center">{{erAnio}}</b><button class="btn sm ghost" type="button" @click="erAnio++">›</button>
            <button v-for="(n, i) in ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Set','Oct','Nov','Dic']" :key="i" type="button" class="btn sm" :class="mesSel === i + 1 ? '' : 'sec'" @click="elegirMes(i + 1)" style="position:relative">{{n}}<span v-if="porMes && res && res.meses && res.meses[String(i + 1).padStart(2, '0')]" class="badge" style="position:absolute;top:-8px;right:-6px;font-size:10px;padding:0 5px" :title="res.meses[String(i + 1).padStart(2, '0')] + ' asiento(s)'">{{res.meses[String(i + 1).padStart(2, '0')]}}</span></button>
            <template v-if="conDesde"><label style="display:flex;gap:4px;align-items:center;margin-left:10px"><input type="radio" value="acumulado" v-model="erModo"> Acumulado</label>
            <label style="display:flex;gap:4px;align-items:center"><input type="radio" value="mensual" v-model="erModo"> Mensual</label></template>
            <span class="small muted" style="margin-left:10px">{{mesSel ? (conDesde ? (erModo === 'mensual' ? 'Solo ese mes' : 'Del 1 de enero al cierre del mes') : 'Al cierre del mes') : 'Rango de fechas: ' + periodoTexto}}</span>
          </div>
          <Field label="Vista" v-if="esDeclaracion" :help="vistaDecl === 'decl' ? 'Lo que se declara: todo en colones con el tipo de cambio de cada comprobante' : 'Control: solo lo hecho en esa moneda, con sus montos originales'"><select v-model="vistaDecl"><option value="decl">Declaración (colones, con tipo de cambio)</option><option value="CRC">Solo lo hecho en colones</option><option value="USD">Solo lo hecho en dólares</option></select></Field>
          <Field label="Moneda" v-if="!enColones" :help="convertir ? 'Todo convertido con el tipo de cambio de cada documento' : 'Solo lo hecho en esa moneda, sin tipo de cambio'"><select v-model="monedaSel" :disabled="convertir"><option value="CRC">Colones</option><option value="USD">Dólares</option></select></Field>
          <label v-if="!enColones" style="display:flex;gap:6px;align-items:center;font-size:13px;margin-top:22px"><input type="checkbox" v-model="convertir"> Convertir todo a la moneda principal (control interno)</label>
          <Field label="Cliente" v-if="conCliente"><select v-model="cliente"><option value="">Todos los clientes</option><option v-for="c in store.clientes" :key="c.id" :value="c.id">{{c.nombre}}</option></select></Field>
          <Field label="Vendedor" v-if="conVendedor"><select v-model="vendedor"><option value="">Todos los vendedores</option><option v-for="v in vendedores" :key="v.id" :value="v.nombre">{{v.nombre}}</option></select></Field>
          <Field label="Cuenta contable" v-if="conCuenta"><select v-model="cuenta"><option value="">{{slug==='libro-mayor' ? 'Todas las cuentas' : 'Elija una cuenta'}}</option><option v-for="c in plan" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
          <Field label="Cuenta de Bancos" v-if="conBanco"><select v-model="banco"><option value="">Todas las cuentas</option><option v-for="b in bancosOpc" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
          <Field label="Bodega" v-if="conBodega"><select v-model="bodega"><option value="">Todas las bodegas</option><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
        </div>
      </div>

      <div class="alert" v-if="aviso">{{aviso}}</div>
      <div class="alert info" v-if="info && !aviso">{{info}}</div>
      <div class="dash" style="margin-bottom:18px" v-if="!aviso">
        <div class="kpi" :class="kpis.length>3?'w3':'w4'" v-for="k in kpis" :key="k.t"><div class="t">{{k.t}}</div><div class="v">{{k.v}}</div><div class="d">{{periodoTexto}}</div></div>
      </div>

      <div class="card pad0" v-if="!aviso">
        <DataTable :rows="rows" :columns="columns" :page-size="25" :empty-title="cargando ? 'Cargando…' : 'Sin datos para el período'" empty-text="Ajuste el rango de fechas o los filtros para ver resultados."></DataTable>
        <div class="totals" style="padding:0 16px 14px" v-if="rows.length && totales.length">
          <div v-for="t in totales" :key="t.label" :class="{total: /^Total|Saldo|Utilidad neta/.test(t.label)}"><span>{{t.label}}</span><b>{{money(t.v, t.moneda || p)}}</b></div>
        </div>
        <p class="small muted" style="padding:0 16px 14px;margin:0" v-if="nota">{{nota}}</p>
        <p class="small" style="padding:0 16px 14px;margin:0" v-if="tcMostrar">Tipo de cambio de referencia del Banco Central de Costa Rica al {{fecha(tcMostrar.fecha)}}: compra {{money(tcMostrar.compra, 'CRC')}} · <b>venta {{money(tcMostrar.venta, 'CRC')}}</b> (la que se usa)</p>
      </div>
      <div class="card pad0" v-if="extra && !aviso">
        <h2 style="padding:14px 16px 0;margin:0">{{extra.titulo}}</h2>
        <DataTable :rows="extra.rows" :columns="extra.cols.map(c => c.fmt === 'money' ? { ...c, moneda: p } : c)" :page-size="25" empty-title="Sin existencias a la fecha"></DataTable>
      </div>
    </template>
  </div>`,
  setup() { return { store }; },
};
