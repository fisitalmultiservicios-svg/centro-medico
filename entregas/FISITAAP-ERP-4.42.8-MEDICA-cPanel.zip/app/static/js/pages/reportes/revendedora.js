// 4.9: Estado de cuenta de una revendedora (o de cualquier cliente). Arriba, el crédito al día (límite, saldo, vencido, lo comprometido
// en pedidos y disponible) con los documentos pendientes; abajo, las pestañas Pedidos (en línea), Estado de cuenta (cargos, abonos y
// saldo corrido) y Artículos comprados, en el período elegido (Mes, 3 meses, Año o Todo). Imprimir y PDF llevan todas las secciones;
// Excel, la pestaña abierta; WhatsApp y correo le envían el resumen. Sin cliente (#/contactos/estado-cuenta) muestra un buscador.
// Datos de GET /api/revendedoras/{id}/estado-cuenta; no vive bajo /reportes ni pide el módulo Reportes. Consulta:
// ?desde=&hasta=&tab=pedidos|movimientos|articulos&volver=fis (volver=fis: botón «Volver a pedidos» de Ventas en línea).
import { api, toast, money, fmt, fecha, hoy } from '../../api.js';
import { store, sesion } from '../../app.js';
import { descargarReporte, descargarExcel, imprimirReporte, impresorasReporte, principal, descargarTabla } from './_montos.js';
// 9c (J4): el aviso de una impresión que no salió, con la ayuda común de pos/_agente.js (se carga al usarla, como el resto de la impresión de esta pantalla)
async function avisoImpresion(prefijo, e) { try { const A = await import('../pos/_agente.js'); if (A.avisoImpresion) return A.avisoImpresion(prefijo, e); } catch { /* como antes */ } return prefijo + ((e && e.message) || ''); }
import { buscarReporte, registrarReciente, puedeReporte } from './hub.js';
import { telefonoWa, enlaceWhatsApp, enlaceCorreo, asuntoEstadoCuenta, textoEstadoCuenta, textoLineas, rangoRapido, rangoActivo, RANGOS, saldoFinal, cantidad } from './_revendedoras.js';
import { AbonoRevendedora } from './_abono.js';   // 4.10: abono desde aquí

const r2 = n => Math.round((+n || 0) * 100) / 100;
const FECHA_RE = /^\d{4}-\d{2}-\d{2}$/;
const TABS = [['pedidos', 'Pedidos'], ['movimientos', 'Estado de cuenta'], ['articulos', 'Artículos comprados']];
const MAX_PDF = 1200;   // filas por sección en el PDF: el servidor dibuja hasta 30.000 celdas
const linkDoc = id => { if (id) location.hash = '/ventas/facturas/' + id; };

export default {
  props: ['params'],
  components: { AbonoRevendedora },
  data() {
    const p = this.params || {}, tabOk = TABS.some(t => t[0] === p.tab);
    return { d: null, cargando: false, error: '', noExiste: false, primera: true, desde: FECHA_RE.test(p.desde || '') ? p.desde : '', hasta: FECHA_RE.test(p.hasta || '') ? p.hasta : '', tab: tabOk ? p.tab : 'pedidos', tabPedida: tabOk,
      elegido: null, abono: null, impSel: '', impresorasLista: impresorasReporte(), timer: null, seq: 0, RANGOS };
  },
  computed: {
    cid() { const v = this.params && this.params.id; return v !== undefined && /^\d+$/.test(String(v)) ? +v : null; },
    moneda() { return (this.d && this.d.moneda) || principal(); },
    puedeCobrar() { return sesion.puede('cobros'); },   // 4.10: registrar abonos (el servidor también lo exige)
    contacto() { return (this.d && this.d.contacto) || {}; },
    nombre() { return this.contacto.nombre || ''; },
    cred() { return (this.d && this.d.credito) || {}; },
    empresaNombre() { const e = store.empresa || {}; return e.nombre_comercial || e.nombre || ''; },
    volverFis() { return !!(this.params && this.params.volver === 'fis'); },
    clientesOpc() { return (store.clientes || []).filter(c => (c.tipo || 'Cliente') !== 'Proveedor' && c.activo !== false); },
    rapidoSel() { return rangoActivo(this.desde, this.hasta, hoy()); },
    periodoTexto() { if (!this.desde && !this.hasta) return 'Todo el historial'; if (!this.desde) return 'Hasta el ' + fecha(this.hasta); return fecha(this.desde) + ' al ' + fecha(this.hasta || hoy()); },
    conPedidos() { return sesion.tieneModulo('pedidos_online') || !!(this.d && (this.d.pedidos || []).length); },
    tabs() { return TABS.filter(t => t[0] !== 'pedidos' || this.conPedidos); },
    verPedidoFis() { return sesion.tieneModulo('pedidos_online') && sesion.puede('pos'); },   // el pedido se abre en Ventas en línea
    subtitulo() { const c = this.contacto; return [c.identificacion ? 'Cédula ' + c.identificacion : '', c.telefono ? 'Tel. ' + c.telefono : '', c.correo || '', c.lista ? 'Lista ' + c.lista : '', (+c.termino_pago_dias || 0) > 0 ? 'Crédito a ' + c.termino_pago_dias + ' días' : '', c.con_acceso ? 'Con acceso al catálogo' : ''].filter(Boolean).join(' · '); },
    kpis() {
      const m = v => money(v, this.moneda), c = this.cred, rp = (this.d && this.d.resumen_pedidos) || {}, al = 'Al ' + fecha(hoy()), conLim = (+c.limite || 0) > 0;
      const k = [{ t: 'Límite de crédito', v: conLim ? m(c.limite) : 'Sin crédito', d: al }, { t: 'Saldo pendiente', v: m(c.saldo), d: al }, { t: 'Vencido', v: m(c.vencido), d: al }, { t: 'En pedidos por facturar', v: m(c.en_pedidos), d: al }, { t: 'Disponible', v: conLim ? m(c.disponible) : '—', d: al }];
      if (this.conPedidos) k.push({ t: 'Pedidos del período', v: fmt(rp.cantidad || 0, 0) + ' · ' + m(rp.total), d: this.periodoTexto });
      return k;
    },
    // ---- columnas (montos con función: siempre en la moneda del estado de cuenta, también en el PDF) ----
    colsPend() { return [{ key: 'consecutivo', label: 'Documento', mono: true, link: x => linkDoc(x.doc_id) }, { key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'vence', label: 'Vence', fmt: 'date' }, { key: 'dias', label: 'Días vencido', num: true, fmt: v => ((+v || 0) > 0 ? String(v) : '') }, this.colDin('total', 'Total'), this.colDin('saldo', 'Saldo'), { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
    colsPendPed() { return [{ key: 'detalle', label: 'Artículo' }, { key: 'cantidad', label: 'Cantidad', num: true, fmt: v => cantidad(v) }, this.colDin('total', 'Monto')]; },
    colsPed() {
      // 4.9: con ?contacto_id= Ventas en línea busca el pedido entre todos los de la revendedora; sin él, solo entre los 500 más nuevos
      // de la empresa y los pedidos viejos salían «Pedido no disponible»
      const ver = this.verPedidoFis, cid = this.cid;
      return [{ key: 'numero_txt', label: 'Pedido', ...(ver ? { link: x => { location.href = '/app/fisitaap/#/pedido/' + x.pid + (cid ? '?contacto_id=' + cid : ''); } } : {}) }, { key: 'creado', label: 'Fecha', fmt: 'date' }, { key: 'estado_nombre', label: 'Estado', fmt: 'badge' }, { key: 'forma_pago', label: 'Pago' }, { key: 'articulos', label: 'Artículos' }, this.colDin('total', 'Total'),
        { key: 'comprobante', label: 'Comprobante', mono: true, link: x => linkDoc(x.doc_id) }, this.colDin('saldo_doc', 'Saldo', { vacio: true })];
    },
    colsMov() { return [{ key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'consecutivo', label: 'Documento', mono: true, link: x => linkDoc(x.documento_id) }, { key: 'detalle_txt', label: 'Detalle' }, { key: 'vence', label: 'Vence', fmt: 'date' }, this.colDin('cargo', 'Cargo', { vacio: true }), this.colDin('abono', 'Abono', { vacio: true }), this.colDin('saldo', 'Saldo', { noTotal: true })]; },
    colsArt() { return [{ key: 'detalle', label: 'Artículo' }, { key: 'codigo', label: 'Código', mono: true }, { key: 'cantidad', label: 'Cantidad', num: true, fmt: v => cantidad(v) }, { key: 'veces', label: 'Compras', num: true, fmt: 'num', dec: 0 }, this.colDin('total', 'Monto'), { key: 'ultima', label: 'Última compra', fmt: 'date' }]; },
    // ---- filas ----
    filasPend() { return (this.cred.documentos || []).map((x, i) => ({ ...x, id: 'p' + (x.id || i), doc_id: x.id || null, dias: +x.dias || 0, total: +x.total || 0, saldo: +x.saldo || 0, estado: (+x.dias || 0) > 0 ? 'Vencida' : 'Por cobrar' })); },
    filasPendPed() { return ((this.d && this.d.items_pendientes) || []).map((x, i) => ({ ...x, id: 'q' + i, total: +x.total || 0 })); },
    // 4.9: documento null con facturado (comprobante de otro cliente o de otra sucursal): «Facturado», sin enlace ni saldo. cancelado: no suma
    // en el total del Excel, como resumen_pedidos del servidor (cantidad y cancelados son conteos; total, a_credito y pagados_en_linea, montos)
    filasPed() {
      return ((this.d && this.d.pedidos) || []).map(p => { const doc = p.documento || null; return { id: 'pe' + p.id, pid: p.id, numero_txt: '#' + (p.numero ?? p.id), creado: p.creado, estado_nombre: p.estado_nombre || p.estado || '', cancelado: p.estado === 'cancelado', forma_pago: p.forma_pago || (p.a_credito ? 'A crédito' : ''), articulos: textoLineas(p.lineas, 90), total: +p.total || 0,
        comprobante: doc ? (doc.consecutivo || ('#' + doc.id)) : (p.facturado ? 'Facturado' : '—'), doc_id: doc ? doc.id : null, saldo_doc: doc ? +doc.saldo || 0 : null }; });
    },
    filasMov() {
      const d = this.d || {}, out = [];
      if (this.desde || Math.abs(+d.saldo_anterior || 0) > 0.004) out.push({ id: 'ini', fecha: this.desde, consecutivo: '', detalle_txt: 'Saldo anterior', vence: '', cargo: null, abono: null, saldo: r2(d.saldo_anterior) });
      (d.movimientos || []).forEach((m, i) => out.push({ ...m, id: 'm' + i, detalle_txt: String(m.detalle || '') + (m.pedido_numero ? ' · Pedido #' + m.pedido_numero : ''), cargo: (+m.cargo || 0) ? +m.cargo : null, abono: (+m.abono || 0) ? +m.abono : null, saldo: +m.saldo || 0 }));
      return out;
    },
    filasArt() { return ((this.d && this.d.items) || []).map((x, i) => ({ ...x, id: 'a' + i, cantidad: +x.cantidad || 0, total: +x.total || 0, veces: +x.veces || 0 })); },
    totalesMov() { const mv = (this.d && this.d.movimientos) || []; return { cargos: r2(mv.reduce((s, m) => s + (+m.cargo || 0), 0)), abonos: r2(mv.reduce((s, m) => s + (+m.abono || 0), 0)), saldo: saldoFinal(this.d) }; },
    totalArt() { return r2(this.filasArt.reduce((s, x) => s + x.total, 0)); },
    resumenPed() {
      const rp = (this.d && this.d.resumen_pedidos) || {}, m = v => money(v, this.moneda);
      return [fmt(rp.cantidad || 0, 0) + ' pedido(s) por ' + m(rp.total), (+rp.a_credito || 0) > 0 ? m(rp.a_credito) + ' a crédito' : '', (+rp.pagados_en_linea || 0) > 0 ? m(rp.pagados_en_linea) + ' pagado en línea' : '', rp.cancelados ? rp.cancelados + ' cancelado(s), que no suman' : ''].filter(Boolean).join(' · ');   // a_credito y pagados_en_linea son montos
    },
    // 4.9: con todo el historial, el saldo corrido debería ser el de los documentos a crédito pendientes; si no, se avisa
    diferencia() {
      if (!this.d || this.desde || (this.hasta && this.hasta < hoy()) || this.d.sucursal_parcial) return 0;
      const dif = r2(saldoFinal(this.d) - (+this.cred.saldo || 0));
      return Math.abs(dif) > 0.01 ? dif : 0;
    },
    textoMensaje() { return textoEstadoCuenta({ empresa: this.empresaNombre, nombre: this.nombre, credito: this.cred, moneda: this.moneda, al: hoy() }); },
    telWa() { return !!((this.d && this.d.enlaces && this.d.enlaces.whatsapp) || telefonoWa(this.contacto)); },
    enlaceWa() { const e = this.d && this.d.enlaces; return (e && e.whatsapp) || enlaceWhatsApp(telefonoWa(this.contacto), this.textoMensaje); },
    correos() { const e = this.d && this.d.enlaces, l = e && Array.isArray(e.correo) ? e.correo.filter(Boolean) : []; return l.length ? l : (this.contacto.correo ? [this.contacto.correo] : []); },
    enlaceMail() { return enlaceCorreo(this.correos, asuntoEstadoCuenta({ empresa: this.empresaNombre, al: hoy() }), this.textoMensaje); },
  },
  watch: {
    desde() { this.sincronizar(); this.recargar(); }, hasta() { this.sincronizar(); this.recargar(); }, tab() { this.sincronizar(); },
    // 4.9: un enlace que solo cambia la consulta no vuelve a montar la pantalla
    'params.desde'(v) { const x = FECHA_RE.test(v || '') ? v : ''; if (x !== this.desde) this.desde = x; },
    'params.hasta'(v) { const x = FECHA_RE.test(v || '') ? v : ''; if (x !== this.hasta) this.hasta = x; },
    'params.tab'(v) { if (TABS.some(t => t[0] === v)) this.tab = v; },
  },
  methods: {
    alGuardar() { this.abono = null; this.cargar(true); },   // 4.10: el estado de cuenta se actualiza con el abono
    money, fecha, cantidad,
    // columna de dinero en la moneda del estado de cuenta; vacio: deja en blanco las celdas sin valor (saldo anterior, sin comprobante)
    colDin(key, label, o = {}) { const mon = this.moneda; return { key, label, num: true, sumar: !o.noTotal, noTotal: !!o.noTotal, fmt: v => (o.vacio && (v === null || v === undefined) ? '' : money(v || 0, mon)) }; },
    detalleCliente(c) { return [c.numero_id, c.celular || c.telefono].filter(Boolean).join(' · '); },
    ir(v) { if (v) location.hash = '/contactos/estado-cuenta/' + v + (this.volverFis ? '?volver=fis' : ''); },
    rapido(q) { const r = rangoRapido(q, hoy()); this.desde = r.desde; this.hasta = r.hasta; },
    conteo(t) { return t === 'pedidos' ? this.filasPed.length : (t === 'articulos' ? this.filasArt.length : ((this.d && this.d.movimientos) || []).length); },
    recargar() { clearTimeout(this.timer); this.timer = setTimeout(() => this.cargar(), 300); },
    async cargar(manual) {
      if (!this.cid) return;
      if (this.desde && this.hasta && this.desde > this.hasta) { toast('La fecha «Desde» es posterior a «Hasta»', 'err'); return; }
      const n = ++this.seq, p = new URLSearchParams();
      if (this.desde) p.set('desde', this.desde); if (this.hasta) p.set('hasta', this.hasta);
      this.cargando = true; this.error = '';
      try {
        const d = await api('/api/revendedoras/' + this.cid + '/estado-cuenta' + (p.toString() ? '?' + p : ''));
        if (n !== this.seq) return;
        this.d = d || null; this.noExiste = false;
        if (this.primera) {   // la primera vez: sin pedidos (o sin Ventas en línea) abre en el estado de cuenta, salvo que la dirección pida otra pestaña
          this.primera = false;
          if (this.tab === 'pedidos' && (!this.conPedidos || (!this.tabPedida && !this.filasPed.length && (this.d.movimientos || []).length))) this.tab = 'movimientos';
        }
        if (manual) toast('Estado de cuenta actualizado', 'ok');
      } catch (e) { if (n !== this.seq) return; if (e.status === 404) { this.noExiste = true; this.d = null; } else this.error = e.message; }
      this.cargando = false;
    },
    // 4.9: la dirección refleja el período y la pestaña (se puede guardar o compartir) sin volver a cargar la pantalla
    sincronizar() {
      if (!this.cid) return;
      const p = new URLSearchParams(); if (this.desde) p.set('desde', this.desde); if (this.hasta) p.set('hasta', this.hasta); if (this.tab !== 'pedidos') p.set('tab', this.tab); if (this.volverFis) p.set('volver', 'fis');
      try { const qs = p.toString(); history.replaceState(history.state, '', '#/contactos/estado-cuenta/' + this.cid + (qs ? '?' + qs : '')); } catch { /* sin historial: sigue en pantalla */ }
    },
    // ---- documento (imprimir, PDF y Excel): celdas ya formateadas en la moneda del estado de cuenta ----
    celda(r, c) { const v = r[c.key]; if (typeof c.fmt === 'function') return String(c.fmt(v, r) ?? ''); if (c.fmt === 'date') return fecha(v); if (c.fmt === 'num') return fmt(v, c.dec ?? 2); return v === null || v === undefined ? '' : String(v); },
    seccion(titulo, cols, rows, totales, nota) {
      const corto = rows.length > MAX_PDF ? 'Se incluyen las primeras ' + MAX_PDF + ' de ' + rows.length + ' filas: acorte el período para ver el resto. ' : '';
      const nt = (corto + (nota || '')).trim();
      return { titulo: String(titulo).slice(0, 120), columnas: cols.map(c => ({ key: c.key, label: c.label, num: !!c.num })), filas: rows.slice(0, MAX_PDF).map(r => Object.fromEntries(cols.map(c => [c.key, this.celda(r, c)]))), totales: totales || [], nota: nt ? nt.slice(0, 300) : null };
    },
    secciones() {
      const m = v => money(v, this.moneda), out = [], tm = this.totalesMov, rp = (this.d && this.d.resumen_pedidos) || {};
      if (this.filasPend.length) out.push(this.seccion('Documentos pendientes al ' + fecha(hoy()), this.colsPend, this.filasPend, [{ t: 'Saldo pendiente', v: m(this.cred.saldo) }]));
      if (this.filasPendPed.length) out.push(this.seccion('Artículos en pedidos por facturar', this.colsPendPed, this.filasPendPed, [{ t: 'En pedidos por facturar', v: m(this.cred.en_pedidos) }]));
      out.push(this.seccion('Estado de cuenta · ' + this.periodoTexto, this.colsMov, this.filasMov, [{ t: 'Cargos', v: m(tm.cargos) }, { t: 'Abonos', v: m(tm.abonos) }, { t: 'Saldo final', v: m(tm.saldo) }]));
      if (this.conPedidos) out.push(this.seccion('Pedidos · ' + this.periodoTexto, this.colsPed, this.filasPed, [{ t: 'Pedidos', v: fmt(rp.cantidad || 0, 0) }, { t: 'Total', v: m(rp.total) }], this.resumenPed));
      out.push(this.seccion('Artículos comprados · ' + this.periodoTexto, this.colsArt, this.filasArt, [{ t: 'Monto', v: m(this.totalArt) }]));
      return out;
    },
    datosDoc() {
      return { titulo: ('Estado de cuenta · ' + this.nombre).slice(0, 120), subtitulo: ['Cliente: ' + this.nombre, this.subtitulo].filter(Boolean).join(' · ').slice(0, 300), periodo: this.periodoTexto.slice(0, 80), cols: [], rows: [],
        kpis: this.kpis.map(k => ({ t: k.t, v: k.v })), secciones: this.secciones(),
        nota: ('Montos en ' + this.moneda + '. Crédito y documentos pendientes al ' + fecha(hoy()) + '; estado de cuenta, pedidos y artículos: ' + this.periodoTexto.toLowerCase() + '.' + (this.d && this.d.sucursal_parcial ? ' Solo los documentos y pagos de su sucursal.' : '')).slice(0, 300) };
    },
    archivo() { return ('estado-cuenta-' + (this.nombre || this.cid)).slice(0, 70); },
    async imprimir() {
      const imp = this.impresorasLista.find(i => String(i.id) === String(this.impSel)) || null;
      try { const r = await imprimirReporte(this.datosDoc(), imp, store.empresa); if (r === 'agente') toast('Estado de cuenta enviado a «' + imp.nombre + '»', 'ok'); }
      catch (e) { toast(await avisoImpresion('No se imprimió' + (imp ? ' en «' + imp.nombre + '»' : '') + ': ', e), 'err'); }
    },
    pdf() { descargarReporte('pdf', { ...this.datosDoc(), archivo: this.archivo() }); },
    async excel(formato) {   // la pestaña abierta, con números como números
      const [cols, rows, titulo] = this.tab === 'pedidos' ? [this.colsPed, this.filasPed, 'Pedidos'] : (this.tab === 'articulos' ? [this.colsArt, this.filasArt, 'Artículos comprados'] : [this.colsMov, this.filasMov, 'Estado de cuenta']);
      const cx = cols.map(c => ({ key: c.key, label: c.label, num: !!c.num, sumar: !!c.sumar, fecha: c.fmt === 'date',
        valor: r => { const v = r[c.key]; if (c.fmt === 'date') return fecha(v); if (c.sumar && r.cancelado) return null; if (c.num) return v === null || v === undefined || v === '' ? null : +v || 0; return v ?? ''; } }));   // 4.9: el pedido cancelado no suma
      const sub = [this.subtitulo, this.tab === 'pedidos' ? this.resumenPed : ''].filter(Boolean).join(' · ');   // 4.9: Pedidos lleva su resumen (cuántos, total, cancelados)
      if (formato === 'csv') return descargarTabla('csv', this.archivo() + '-' + this.tab, cx.map(c => ({ ...c, csv: (v, r) => c.valor(r) })), rows);   // 4.17
      try { const a = await descargarExcel(this.archivo() + '-' + this.tab, { titulo: (titulo + ' · ' + this.nombre).slice(0, 120), subtitulo: sub.slice(0, 300) || null, periodo: this.periodoTexto, cols: cx, rows }); toast('Archivo ' + a + ' descargado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  created() {
    const rep = buscarReporte('ventas', 'estado-cuenta-revendedora');
    if (rep && puedeReporte('ventas', rep.slug)) registrarReciente('ventas', rep);
    if (this.cid) this.cargar();
  },
  template: `
  <div class="page" v-if="!cid">
    <PageHead title="Estado de cuenta" sub="Elija una revendedora o un cliente para ver sus pedidos, su estado de cuenta, su crédito y lo que ha comprado." :crumbs="[{label:'Contactos',to:'/contactos'},{label:'Revendedoras y saldos',to:'/contactos/revendedoras'},{label:'Estado de cuenta'}]">
      <a class="btn ghost" v-if="volverFis" href="/app/fisitaap/#/pedidos">← Volver a pedidos</a>
      <a class="btn sec" href="#/contactos/revendedoras">Ver todas con su saldo</a>
    </PageHead>
    <div class="card" style="max-width:620px">
      <Field label="Revendedora o cliente" help="Escriba el nombre, la cédula o el celular"><Buscador v-model="elegido" :opciones="clientesOpc" :detalle="detalleCliente" placeholder="Buscar cliente…" @change="ir"></Buscador></Field>
    </div>
  </div>
  <div class="page" v-else>
    <PageHead :title="nombre ? 'Estado de cuenta de ' + nombre : 'Estado de cuenta'" :sub="subtitulo" :crumbs="[{label:'Contactos',to:'/contactos'},{label:'Revendedoras y saldos',to:'/contactos/revendedoras'},{label:nombre || 'Estado de cuenta'}]">
      <a class="btn ghost" v-if="volverFis" href="/app/fisitaap/#/pedidos">← Volver a pedidos</a>
      <button class="btn" v-if="d && puedeCobrar" @click="abono = { solo: null }" title="Cancelar todo o elegir las facturas y tiquetes a los que se aplica">＋ Registrar abono</button>
      <button class="btn ghost" @click="cargar(true)" :disabled="cargando">↻ Actualizar</button>
      <select class="inp" v-if="impresorasLista.length" v-model="impSel" title="Dónde imprimir" style="max-width:190px"><option value="">Impresora del equipo</option><option v-for="i in impresorasLista" :key="i.id" :value="i.id">{{i.nombre}} (tiquete)</option></select>
      <button class="btn sec" @click="imprimir" :disabled="!d" title="Todas las secciones: pendientes, estado de cuenta, pedidos y artículos">⎙ Imprimir</button>
      <button class="btn sec" @click="pdf" :disabled="!d" title="Todas las secciones: pendientes, estado de cuenta, pedidos y artículos">⤓ PDF</button>
      <button class="btn sec" @click="excel" :disabled="!d" title="La pestaña abierta, en Excel con formato">⤓ Excel</button><button class="btn sec" @click="excel('csv')" :disabled="!d" title="La pestaña abierta, en CSV">⤓ CSV</button>
      <a class="btn sec" v-if="d" :href="enlaceWa" target="_blank" rel="noopener" :title="telWa ? 'Enviarle el resumen de su cuenta por WhatsApp' : 'Sin celular registrado: WhatsApp le pedirá elegir el contacto'">WhatsApp</a>
      <a class="btn sec" v-if="d && enlaceMail" :href="enlaceMail" title="Abre su programa de correo con el resumen (adjunte el PDF si lo necesita)">✉ Correo</a>
      <button class="btn sec" v-else-if="d" disabled title="El cliente no tiene correo registrado">✉ Correo</button>
    </PageHead>
    <div class="row small" style="gap:16px;flex-wrap:wrap;margin:-4px 0 12px">
      <a class="link" :href="'#/contactos/' + cid">Ficha del contacto</a>
      <a class="link" href="#/contactos/revendedoras">Todas las revendedoras</a>
      <a class="link" href="#/contactos/estado-cuenta">Otro cliente</a>
      <a class="link" v-if="verPedidoFis" :href="'/app/fisitaap/#/pedidos?contacto_id=' + cid">Sus pedidos en Ventas en línea</a>
    </div>

    <div class="alert" v-if="error">No se pudo cargar el estado de cuenta: {{error}}</div>
    <div class="card" v-if="noExiste"><Empty icon="⚠" title="Cliente no encontrado" text="El cliente no existe en esta empresa o ya no está disponible."><a class="btn" href="#/contactos/estado-cuenta">Buscar otro cliente</a></Empty></div>
    <template v-else-if="d">
      <div class="alert info" v-if="d.sucursal_parcial">Su usuario trabaja en una sola sucursal: el estado de cuenta, los pedidos y los artículos muestran solo los documentos y pagos de esa sucursal. El crédito de arriba es el de toda la cuenta.</div>
      <div class="dash" style="margin-bottom:14px">
        <div class="kpi w4" v-for="k in kpis" :key="k.t"><div class="t">{{k.t}}</div><div class="v">{{k.v}}</div><div class="d">{{k.d}}</div></div>
      </div>
      <div class="card pad0" style="margin-bottom:14px">
        <h2 style="padding:14px 16px 0;margin:0">Documentos pendientes <small>{{filasPend.length}} · saldo {{money(cred.saldo, moneda)}} al {{fecha(hoy())}}</small></h2>
        <DataTable :rows="filasPend" :columns="colsPend" :page-size="10" empty-title="Sin documentos pendientes" empty-text="No tiene facturas ni tiquetes a crédito por pagar."><template #actions="{ row }" v-if="puedeCobrar"><button class="btn sm ghost" v-if="row.doc_id" @click.stop="abono = { solo: row.doc_id }">Abonar</button></template></DataTable>
        <template v-if="filasPendPed.length">
          <h2 style="padding:6px 16px 0;margin:0">Artículos en pedidos por facturar <small>{{money(cred.en_pedidos, moneda)}} comprometidos en pedidos a crédito</small></h2>
          <DataTable :rows="filasPendPed" :columns="colsPendPed" :page-size="10"></DataTable>
        </template>
      </div>

      <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
        <span class="small muted">Período:</span>
        <button v-for="r in RANGOS" :key="r[0]" type="button" class="btn sm" :class="rapidoSel === r[0] ? '' : 'sec'" @click="rapido(r[0])">{{r[1]}}</button>
        <input type="date" class="inp" v-model="desde" title="Desde (vacío: desde el inicio)"><input type="date" class="inp" v-model="hasta" :min="desde || null" title="Hasta (vacío: hoy)">
        <span class="small muted">{{periodoTexto}}</span>
      </div></div>
      <div class="seg" style="margin-bottom:10px"><button v-for="t in tabs" :key="t[0]" type="button" :class="{on: tab===t[0]}" @click="tab=t[0]">{{t[1]}} ({{conteo(t[0])}})</button></div>
      <div class="card pad0">
        <template v-if="tab==='pedidos' && conPedidos">
          <p class="small muted" style="padding:12px 16px 0;margin:0">{{resumenPed}}</p>
          <DataTable :rows="filasPed" :columns="colsPed" :page-size="20" :empty-title="cargando ? 'Cargando…' : 'Sin pedidos en el período'" empty-text="Los pedidos de la página o del catálogo de revendedoras de este cliente aparecen aquí."></DataTable>
        </template>
        <template v-else-if="tab==='articulos'">
          <DataTable :rows="filasArt" :columns="colsArt" :page-size="25" :empty-title="cargando ? 'Cargando…' : 'Sin compras en el período'" empty-text="Artículos de sus facturas y tiquetes (menos las notas de crédito)."></DataTable>
          <div class="totals" style="padding:0 16px 14px" v-if="filasArt.length"><div class="total"><span>Monto comprado</span><b>{{money(totalArt, moneda)}}</b></div></div>
        </template>
        <template v-else>
          <DataTable :rows="filasMov" :columns="colsMov" :page-size="25" :empty-title="cargando ? 'Cargando…' : 'Sin movimientos en el período'" empty-text="Facturas, tiquetes, notas y pagos de este cliente."></DataTable>
          <div class="totals" style="padding:0 16px 14px" v-if="filasMov.length">
            <div><span>Cargos</span><b>{{money(totalesMov.cargos, moneda)}}</b></div>
            <div><span>Abonos</span><b>{{money(totalesMov.abonos, moneda)}}</b></div>
            <div class="total"><span>Saldo final</span><b>{{money(totalesMov.saldo, moneda)}}</b></div>
          </div>
          <p class="small muted" style="padding:0 16px 14px;margin:0">Cargos: facturas, tiquetes y notas de débito; abonos: pagos recibidos, ventas de contado pagadas al emitirse y notas de crédito. Montos en {{moneda}}.</p>
        </template>
      </div>
      <div class="alert info" v-if="diferencia" style="margin-top:12px">El saldo final del estado de cuenta ({{money(totalesMov.saldo, moneda)}}) no coincide con el saldo de los documentos a crédito pendientes ({{money(cred.saldo, moneda)}}). Suele deberse a pagos o notas de crédito que no se aplicaron a una factura, o a notas de débito: revíselos en Pagos recibidos.</div>
    </template>
    <div class="card" v-else-if="cargando"><Empty icon="⏳" title="Cargando el estado de cuenta…"></Empty></div>
    <AbonoRevendedora v-if="abono && cid" :cid="cid" :nombre="nombre" :solo="abono.solo" @close="abono = null" @guardado="alGuardar"></AbonoRevendedora>
  </div>`,
  setup() { return { hoy }; },
};
