// 4.10: registrar un abono desde el estado de cuenta (Norman 8/11: «desde acá debería poder aplicar pagos … donde cancela todo o
// bien ciertas facturas que las pueda seleccionar»). Recibo de caja a las facturas y tiquetes A CRÉDITO con saldo del cliente:
// «Cancelar todo», marcar solo algunos (con el monto de cada uno, para abonos parciales) o repartir un monto recibido de la más vieja
// a la más nueva. Va por POST /api/pagos como Ingresos › Pagos recibidos (mismas reglas del servidor: permiso de cobros, saldo, moneda
// de la cuenta) con una clave de idempotencia por ventana: un doble clic o un reintento no registra el abono dos veces.
// Las facturas con IVA diferido o al Estado (condición 10/08) se cobran con recibo electrónico en Pagos recibidos: aquí solo se avisan.
import { api, toast, money, hoy, fecha, CAT, opts, monedas } from '../../api.js';
import { cuentasParaMovimientos, cuentaParaMedio, problemaMoneda } from '../bancos/cuentas.js';

// 4.10: a céntimos igual que Python round(x, 2), que es como el servidor calcula el saldo en crear_pago: valor binario exacto y los
// empates exactos al par. Con Math.round un total de 5 decimales como 113,565 daba 113,57 y el servidor (113,56) rechazaba «Cancelar todo»
const r2 = n => { const x = +n || 0, f = +x.toFixed(2); return /\.\d\d50*$/.test(x.toFixed(20)) && Math.round(Math.abs(f) * 100) % 2 ? +(f - Math.sign(x) * 0.01).toFixed(2) : f; };
const CREDITO = ['02', '08', '10'];
const TIPOS = ['01', '02', '04', '09'];
const clave = () => 'abono:' + (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(36).slice(2));
export const saldoDoc = d => Math.max(0, r2((+d.total || 0) - (+d.pagado || 0) - (+d.acreditado || 0)));
// Cobrable con recibo de caja: a crédito, con saldo, no rechazado; las 10/08 que no son tiquete solo cuando Hacienda las aceptó (o internas)
export const cobrableCaja = d => TIPOS.includes(d.tipo_documento) && d.estado !== 'rechazado' && CREDITO.includes(d.condicion_venta || '01') && saldoDoc(d) > 0.005
  && (d.tipo_documento === '04' || !['10', '08'].includes(d.condicion_venta) || ['aceptado', 'interno'].includes(d.estado));
// Reparte `monto` de la más vieja a la más nueva; devuelve { montos: {id: monto}, sobra }
export function repartir(docs, monto) {
  const montos = {}; let resto = r2(monto);
  for (const d of docs) { if (resto <= 0.005) break; const m = r2(Math.min(saldoDoc(d), resto)); if (m > 0) { montos[d.id] = m; resto = r2(resto - m); } }
  return { montos, sobra: resto > 0.005 ? resto : 0 };
}

export const AbonoRevendedora = {
  props: { cid: { type: Number, required: true }, nombre: { type: String, default: '' }, solo: { type: Number, default: null } },
  emits: ['close', 'guardado'],
  data() {
    const m = monedas.principal().codigo;
    return { cargando: true, guardando: false, docs: [], cuentasLista: [], cuentaManual: false, tcManual: false, sel: {}, montos: {}, monto: null, CAT, opts, idem: clave(),
      f: { fecha: hoy(), medio_pago: '01', medio_pago_otros: '', cuenta: '', moneda: m, tipo_cambio: monedas.tc(m), notas: '' } };
  },
  computed: {
    // a crédito con saldo de este cliente, de la más vieja a la más nueva
    base() { return this.docs.filter(d => +d.cliente_id === +this.cid && cobrableCaja(d)).sort((a, b) => String(a.fecha_emision || '').localeCompare(String(b.fecha_emision || '')) || (a.id - b.id)); },
    conRep() { return this.docs.filter(d => +d.cliente_id === +this.cid && TIPOS.includes(d.tipo_documento) && d.estado !== 'rechazado' && CREDITO.includes(d.condicion_venta || '01') && saldoDoc(d) > 0.005 && !cobrableCaja(d)).length; },
    monedasDocs() { return [...new Set(this.base.map(d => d.moneda || 'CRC'))]; },
    lista() { return this.base.filter(d => (d.moneda || 'CRC') === this.f.moneda); },
    saldoTotal() { return r2(this.lista.reduce((s, d) => s + saldoDoc(d), 0)); },
    elegidos() { return this.lista.filter(d => this.sel[d.id] && +this.montos[d.id] > 0); },
    total() { return r2(this.elegidos.reduce((s, d) => s + (+this.montos[d.id] || 0), 0)); },
    esPrincipal() { return this.f.moneda === 'CRC'; },
    cuentasMoneda() { return this.cuentasLista.filter(b => (b.moneda || 'CRC') === this.f.moneda || (b.moneda || 'CRC') === 'CRC'); },
    problemaCuenta() { return this.f.cuenta ? problemaMoneda(this.f.cuenta, this.f.moneda, this.f.tipo_cambio, this.cuentasLista) : ''; },
    todosMarcados() { return this.lista.length > 0 && this.lista.every(d => this.sel[d.id] && Math.abs((+this.montos[d.id] || 0) - saldoDoc(d)) < 0.005); },
  },
  watch: {
    'f.medio_pago'(m) { if (!this.cuentaManual) this.cuentaPropuesta(m); },
    'f.moneda'(v) {
      this.f.tipo_cambio = monedas.tc(v); this.tcManual = false; this.sel = {}; this.montos = {}; this.monto = null; if (!this.cuentaManual) this.cuentaPropuesta(this.f.medio_pago);
    },
    // el tipo de cambio de la factura marcada (como Pagos recibidos), salvo que el usuario lo haya escrito
    sel() {
      if (this.tcManual || this.esPrincipal) return;
      const d = this.lista.find(x => this.sel[x.id] && +x.tipo_cambio > 1); if (d) this.f.tipo_cambio = +d.tipo_cambio;
    },
  },
  methods: {
    money, fecha, saldoDoc,
    cuentaPropuesta(m) { const b = cuentaParaMedio(m, this.f.moneda, this.cuentasLista); this.f.cuenta = b ? b.nombre : (this.cuentasMoneda.some(x => x.nombre === this.f.cuenta) ? this.f.cuenta : ''); },
    marcar(d, v) { this.sel = { ...this.sel, [d.id]: v }; if (v && !(+this.montos[d.id] > 0)) this.montos = { ...this.montos, [d.id]: saldoDoc(d) }; },
    escribirMonto(d, v) { const n = r2(v); this.montos = { ...this.montos, [d.id]: n }; this.sel = { ...this.sel, [d.id]: n > 0 }; },
    cancelarTodo() { const s = {}, m = {}; for (const d of this.lista) { s[d.id] = true; m[d.id] = saldoDoc(d); } this.sel = s; this.montos = m; this.monto = null; },
    ninguno() { this.sel = {}; this.montos = {}; this.monto = null; },
    repartirMonto() {
      const v = r2(this.monto); if (!(v > 0)) return toast('Escriba el monto recibido', 'err');
      const { montos, sobra } = repartir(this.lista, v);
      this.montos = montos; this.sel = Object.fromEntries(Object.keys(montos).map(k => [k, true]));
      if (sobra) toast('El monto supera lo que debe: se aplican ' + money(r2(v - sobra), this.f.moneda) + ' y sobran ' + money(sobra, this.f.moneda) + ' (no se registran)', 'err');
    },
    async guardar() {
      const f = this.f;
      if (!this.elegidos.length || !(this.total > 0)) return toast('Marque al menos una factura o tiquete y su monto', 'err');
      for (const d of this.elegidos) if (+this.montos[d.id] > saldoDoc(d) + 0.005) return toast('El abono a ' + d.consecutivo + ' supera su saldo (' + money(saldoDoc(d), d.moneda) + ')', 'err');
      if (!f.fecha) return toast('Indique la fecha del abono', 'err');
      if (!f.cuenta && this.cuentasMoneda.length) return toast('Elija la cuenta donde entra el dinero', 'err');
      if (this.problemaCuenta) return toast(this.problemaCuenta, 'err');
      if (f.medio_pago === '99' && (f.medio_pago_otros || '').trim().length < 3) return toast('Con el medio de pago «Otros» describa cuál es (mínimo 3 caracteres)', 'err');
      const docs = this.elegidos.map(d => ({ id: d.id, monto: r2(this.montos[d.id]) }));
      const detalles = (docs.length === 1 ? 'Abono a ' : 'Abono a ' + docs.length + ' documentos: ') + this.elegidos.map(d => String(d.consecutivo || '').slice(-10)).join(', ');
      this.guardando = true;
      try {
        const p = await api('/api/pagos', { method: 'POST', body: { tipo: 'caja', cliente_id: this.cid, detalles: detalles.slice(0, 250), fecha: f.fecha, cuenta: f.cuenta, condicion_venta: '01',
          medio_pago: f.medio_pago, medio_pago_otros: f.medio_pago === '99' ? (f.medio_pago_otros || '').trim() : null, moneda: f.moneda, tipo_cambio: this.esPrincipal ? 1 : +f.tipo_cambio || 1,
          monto: this.total, notas: f.notas || '', facturas: docs, idempotencia: this.idem } });
        const mReg = p && p.monto != null ? +p.monto : this.total, distinto = !!(p && p.repetido) && Math.abs(mReg - this.total) > 0.005;
        toast((p && p.repetido ? 'El abono ya estaba registrado: recibo de caja #' : 'Abono registrado: recibo de caja #') + (p && p.numero ? p.numero : '') + ' por ' + money(mReg, f.moneda)
          + (distinto ? '. Lo que cambió después no se aplicó: revise el estado de cuenta y registre el resto como otro abono' : ''), distinto ? 'err' : 'ok');
        this.$emit('guardado', p);
      } catch (e) {
        toast(e.message, 'err');
        if (e.status >= 400 && e.status < 500) this.idem = clave();   // 4xx: el servidor lo rechazó sin guardar; sin respuesta, límite o 5xx (un proxy pudo cortar después de guardar): la misma clave, no se duplica
      }
      this.guardando = false;
    },
  },
  async created() {
    try { this.cuentasLista = await cuentasParaMovimientos(); } catch { this.cuentasLista = []; }
    try { this.docs = await api('/api/comprobantes?cliente_id=' + encodeURIComponent(this.cid), { headers: { 'X-Sucursal': '0' } }); } catch (e) { toast('No se pudieron cargar los documentos por cobrar: ' + e.message, 'err'); this.docs = []; }   // como el estado de cuenta: la sucursal elegida en la barra no limita
    if (!this.monedasDocs.includes(this.f.moneda) && this.monedasDocs.length) this.f.moneda = this.monedasDocs[0];
    this.cuentaPropuesta(this.f.medio_pago);
    if (this.solo) { const d = this.lista.find(x => +x.id === +this.solo) || this.base.find(x => +x.id === +this.solo); if (d) { if ((d.moneda || 'CRC') !== this.f.moneda) this.f.moneda = d.moneda || 'CRC'; this.$nextTick(() => this.marcar(d, true)); }
      else toast('Ese documento no se abona desde aquí: ya no tiene saldo o es a crédito con IVA diferido o al Estado (se cobra con recibo electrónico en Ingresos › Pagos recibidos cuando Hacienda lo acepte)', 'err'); }
    this.cargando = false;
  },
  template: `
  <Modal :title="'Registrar abono' + (nombre ? ' · ' + nombre : '')" lg @close="guardando || $emit('close')">
    <p class="muted" v-if="cargando">Cargando documentos por cobrar…</p>
    <template v-else>
      <Empty v-if="!base.length" icon="✓" title="Nada por abonar" :text="conRep ? conRep + ' factura(s) a crédito con IVA diferido o al Estado se cobran con recibo electrónico en Ingresos › Pagos recibidos cuando Hacienda las acepte.' : 'No tiene facturas ni tiquetes a crédito con saldo pendiente.'"></Empty>
      <template v-else>
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
          <button class="btn sec sm" @click="cancelarTodo" :class="{on: todosMarcados}">Cancelar todo · {{money(saldoTotal, f.moneda)}}</button>
          <button class="btn ghost sm" @click="ninguno">Quitar selección</button>
          <span class="small muted" style="margin-left:8px">o repartir un monto recibido (de la más vieja a la más nueva):</span>
          <input class="inp" type="number" min="0" step="0.01" v-model.number="monto" placeholder="Monto recibido" style="max-width:150px;text-align:right" @keyup.enter="repartirMonto">
          <button class="btn ghost sm" @click="repartirMonto" :disabled="!(+monto > 0)">Repartir</button>
          <select class="inp" v-if="monedasDocs.length > 1" v-model="f.moneda" style="max-width:120px" title="Las facturas en otra moneda se abonan aparte"><option v-for="m in monedasDocs" :key="m" :value="m">{{m}}</option></select>
        </div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th style="width:34px"></th><th>Documento</th><th>Fecha</th><th>Vence</th><th class="num">Total</th><th class="num">Saldo</th><th class="num" style="width:160px">Abono</th></tr></thead>
          <tbody><tr v-for="d in lista" :key="d.id">
            <td><input type="checkbox" :checked="!!sel[d.id]" @change="marcar(d, $event.target.checked)"></td>
            <td class="mono">{{d.consecutivo}}<span class="small muted" v-if="d.tipo_documento === '04'"> · tiquete</span></td>
            <td>{{fecha(d.fecha_emision)}}</td><td>{{d.fecha_vencimiento ? fecha(d.fecha_vencimiento) : '—'}}</td>
            <td class="num">{{money(d.total, d.moneda)}}</td><td class="num">{{money(saldoDoc(d), d.moneda)}}</td>
            <td><input class="inp" type="number" min="0" step="0.01" :max="saldoDoc(d)" :value="sel[d.id] ? montos[d.id] : ''" @input="escribirMonto(d, $event.target.value)" placeholder="0,00" style="width:100%;text-align:right"></td>
          </tr></tbody>
        </table></div>
        <p class="small muted" v-if="conRep">{{conRep}} factura(s) a crédito con IVA diferido o al Estado se cobran con recibo electrónico en Ingresos › Pagos recibidos cuando Hacienda las acepte.</p>
        <div class="grid" style="margin-top:12px">
          <Field label="Fecha del abono" req><input type="date" v-model="f.fecha"></Field>
          <Field label="Medio de pago" req><select v-model="f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
          <Field label="¿Cuál medio de pago?" req v-if="f.medio_pago === '99'"><input v-model="f.medio_pago_otros" maxlength="100"></Field>
          <Field label="Cuenta donde entra" req help="La propone el medio de pago (efectivo → caja; tarjeta, SINPE o transferencia → banco)"><select v-model="f.cuenta" @change="cuentaManual = true"><option value="" disabled>Elegir cuenta</option><option v-for="b in cuentasMoneda" :key="b.nombre" :value="b.nombre">{{b.nombre}}{{(b.moneda || 'CRC') !== f.moneda ? ' (' + (b.moneda || 'CRC') + ')' : ''}}</option></select></Field>
          <Field label="Tipo de cambio" v-if="!esPrincipal" help="Colones por unidad"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio" @input="tcManual = true"></Field>
          <Field label="Referencia o notas"><input v-model="f.notas" maxlength="300" placeholder="Ej.: SINPE 12345678, depósito BN…"></Field>
        </div>
        <div class="alert warn" v-if="problemaCuenta" style="margin-top:8px">{{problemaCuenta}}</div>
        <p class="small muted" v-if="!cuentasMoneda.length" style="margin-top:8px">No hay cuentas en Bancos para {{f.moneda}}: el abono se registra igual, sin movimiento bancario. Créelas en Bancos › Cuentas para que el dinero quede registrado.</p>
      </template>
    </template>
    <template #foot>
      <span style="margin-right:auto">Total del abono: <b>{{money(total, f.moneda)}}</b><span class="small muted" v-if="elegidos.length"> · {{elegidos.length}} documento(s)</span></span>
      <button class="btn ghost" @click="$emit('close')" :disabled="guardando">Cerrar</button>
      <button class="btn" @click="guardar" :disabled="guardando || !(total > 0)">{{guardando ? 'Guardando…' : 'Registrar abono'}}</button>
    </template>
  </Modal>`,
};
