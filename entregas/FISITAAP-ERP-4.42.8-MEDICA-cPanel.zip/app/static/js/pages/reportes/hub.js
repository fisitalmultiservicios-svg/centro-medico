// Reportes — hub de categorías. Catálogo de reportes compartido (CATALOGO) con categoria.js y reporte.js; recientes y favoritos por usuario (registros).
import { mock, toast, fechaHora } from '../../api.js';
import { sesion, hotelActivo } from '../../app.js';
import { CLAVE_EXPORTABLES, CLAVE_EXPORTABLES_RRHH, esExportableRRHH } from './_montos.js';   // 4.7: historial de exportables de Recursos humanos
// recientes y favoritos son de cada usuario, no de la empresa (R205)
export const claveUsuario = k => k + '_u' + (sesion.usuario?.id || 0);

// Catálogo completo de reportes por categoría (slug de ruta → nombre y descripción según la spec).
export const CATALOGO = {
  ventas: { nombre: 'Ventas', ico: '↗', desc: 'Qué vendiste, a quién y con qué margen.', reportes: [
    { slug: 'ventas-generales', nombre: 'Ventas generales', desc: 'Todas las facturas y tiquetes emitidos en un período, con subtotal, IVA y total.' },
    { slug: 'ventas-por-item', nombre: 'Ventas por ítem', desc: 'Cantidades y montos vendidos por producto o servicio.' },
    { slug: 'ventas-por-cliente', nombre: 'Ventas por cliente', desc: 'Ventas agrupadas por cliente con cantidad de documentos y total.' },
    { slug: 'rentabilidad-por-item', nombre: 'Rentabilidad por ítem', desc: 'Costo, venta y utilidad por cada producto vendido.' },
    { slug: 'ventas-por-vendedor', nombre: 'Ventas por vendedor', desc: 'Desempeño de cada vendedor en el período.' },
    { slug: 'estado-cuenta-cliente', nombre: 'Estado de cuenta por cliente', desc: 'Facturas, pagos y saldo pendiente de un cliente.' },
    // 4.9: pantallas propias bajo Contactos (ruta: no piden el módulo Reportes); aquí aparecen para buscarlas, marcarlas y verlas en Recientes
    { slug: 'revendedoras', nombre: 'Revendedoras', ruta: '/contactos/revendedoras', desc: 'Cada revendedora o cliente con crédito: límite, saldo, vencido, comprometido en pedidos, disponible, cantidad de pedidos y último pedido.' },
    { slug: 'estado-cuenta-revendedora', nombre: 'Estado de cuenta de revendedora', ruta: '/contactos/estado-cuenta', desc: 'Pedidos, facturas y tiquetes (también fiados), abonos, saldo corrido, crédito disponible y artículos comprados de una revendedora; para imprimir o enviarle.' },
    { slug: 'ventas-por-bodega', nombre: 'Ventas por bodega', desc: 'Ventas distribuidas por bodega o punto de venta.' },
    { slug: 'ventas-por-sucursal', nombre: 'Ventas por sucursal', desc: 'Documentos, IVA y total de cada sucursal en el período (consolidado).' },
  ] },
  administrativos: { nombre: 'Administrativos', ico: '▦', desc: 'Control de cobros, pagos, inventario y compras.', reportes: [
    { slug: 'cuentas-por-cobrar', nombre: 'Cuentas por cobrar', desc: 'Facturas y tiquetes a crédito (fiados) pendientes de cobro, con saldo y antigüedad.' },   // 4.9: también los tiquetes 04
    { slug: 'cuentas-por-pagar', nombre: 'Cuentas por pagar', desc: 'Facturas de compra pendientes de pago por proveedor.' },
    { slug: 'ingresos-gastos', nombre: 'Ingresos y gastos', desc: 'Comparativo mensual de lo que entra y lo que sale.' },
    { slug: 'valor-inventario', nombre: 'Valor de inventario', desc: 'Existencias y valor total del inventario a una fecha de corte.' },
    { slug: 'transacciones', nombre: 'Transacciones', desc: 'Movimientos de bancos y cajas en el período.' },
    { slug: 'compras', nombre: 'Compras', desc: 'Facturas de compra recibidas por proveedor y período.' },
    { slug: 'gastos', nombre: 'Gastos', desc: 'Todos los gastos del período: comprobantes y facturas de proveedores clasificados como gasto, gastos pagados sin factura y la planilla pagada. Las compras de mercadería para vender están en Compras.' },
    { slug: 'compras-trimestre', nombre: 'Compras por trimestre', desc: 'Total comprado por trimestre: base de la declaración del régimen simplificado.' },
    { slug: 'reporte-anual', nombre: 'Reporte anual', desc: 'Resumen de ventas, compras e impuestos de todo el año.' },
  ] },
  financieros: { nombre: 'Financieros', ico: '₡', desc: 'Liquidez y proyección de efectivo.', reportes: [
    { slug: 'flujo-caja', nombre: 'Flujo de caja', desc: 'Entradas y salidas de efectivo por período y saldo acumulado.' },
  ] },
  contables: { nombre: 'Contables', ico: '≡', desc: 'Estados financieros y libros contables.', reportes: [
    { slug: 'balance-general', nombre: 'Balance general', desc: 'Activos, pasivos y patrimonio a una fecha de corte.' },
    { slug: 'estado-resultados', nombre: 'Estado de resultados', desc: 'Ingresos, costos y gastos del período; utilidad o pérdida.' },
    { slug: 'estado-resultados-mensual', nombre: 'Estado de resultados por mes', desc: 'El mes que elija en la barra (acumulado de enero a ese mes, o solo ese mes) o el rango de fechas que necesite.' },
    { slug: 'balance-prueba', nombre: 'Balance de prueba', desc: 'Saldos iniciales, movimientos y saldos finales por cuenta.' },
    { slug: 'libro-mayor', nombre: 'Libro mayor', desc: 'Movimientos y saldo de cada cuenta contable.' },
    { slug: 'libro-diario', nombre: 'Libro diario', desc: 'Todos los asientos contables en orden cronológico.' },
    { slug: 'libro-inventarios-balances', nombre: 'Libro de inventarios y balances', desc: 'Inventario valorado y balance de cierre del período.' },
    { slug: 'movimientos-por-cuenta', nombre: 'Movimientos por cuenta', desc: 'Detalle de débitos y créditos de una cuenta específica.' },
    { slug: 'auxiliar-terceros', nombre: 'Auxiliar de terceros', desc: 'Saldos y movimientos por cliente o proveedor.' },
    { slug: 'comprobantes-contables', nombre: 'Comprobantes contables', desc: 'Listado de asientos por tipo y numeración.' },
    { slug: 'estado-resultados-comparativo', nombre: 'Estado de resultados comparativo', desc: 'El período contra el mismo período del año anterior, con la variación.' },
    { slug: 'balance-general-comparativo', nombre: 'Balance general comparativo', desc: 'Saldos a la fecha de corte contra la misma fecha del año anterior.' },
    { slug: 'resultados-centro-costo', nombre: 'Resultados por centro de costo', desc: 'Ingresos, costos y gastos del período por centro de costo.' },
    { slug: 'presupuesto-vs-real', nombre: 'Presupuesto contra real', desc: 'Lo presupuestado por cuenta contra lo registrado en el período, con la diferencia y el porcentaje de ejecución.' },
  ] },
  fiscales: { nombre: 'Fiscales', ico: '⚖', desc: 'Lo que necesita para declarar ante Hacienda.', reportes: [
    { slug: 'declaracion-iva-d104', nombre: 'Declaración de IVA (D-104)', desc: 'Ventas y compras por tarifa de IVA para la declaración mensual.' },
    { slug: 'retenciones', nombre: 'Retenciones', desc: 'Retenciones aplicadas y recibidas en el período.' },
  ] },
  pos: { nombre: 'Punto de venta', ico: '🛒', desc: 'Impuesto de servicio, propinas y lo que se reparte al personal.', reportes: [
    { slug: 'servicio-10', nombre: 'Impuesto de servicio 10 % · total general', desc: 'Por día: lo cobrado por servicio y las propinas, para repartir entre todo el personal.' },
    { slug: 'servicio-por-salonero', nombre: 'Impuesto de servicio 10 % · por salonero', desc: 'Lo cobrado por servicio y las propinas de cada salonero en el período.' },
  ] },
  'para-trabajar': { nombre: 'Para trabajar', ico: '✓', desc: 'Pendientes operativos del día a día.', reportes: [
    { slug: 'tareas-pendientes', nombre: 'Tareas pendientes', desc: 'Tareas abiertas por responsable y fecha de entrega.' },
    { slug: 'documentos-por-conciliar', nombre: 'Documentos por conciliar', desc: 'Pagos y movimientos bancarios sin conciliar.' },
  ] },
};

// Quién ve cada categoría (3.2): cada usuario solo los reportes de los módulos a los que tiene permiso
export const PERMISOS_CATEGORIA = { ventas: ['facturar', 'reportes', 'ver_todo'], administrativos: ['gastos', 'reportes', 'ver_todo', 'inventario'], financieros: ['reportes', 'ver_todo', 'gastos'], contables: ['contabilidad', 'reportes', 'ver_todo'], fiscales: ['contabilidad', 'reportes', 'ver_todo'], pos: ['pos', 'reportes', 'ver_todo'], 'para-trabajar': [] };
export function puedeCategoria(cat) { if (cat === 'pos' && sesion.tipo === 'facturacion') return false; const l = PERMISOS_CATEGORIA[cat]; if (cat === 'favoritos' || !l || !l.length) return true; return l.some(p => sesion.puede(p)); }
// 3.87: además de la categoría, cada reporte pide el permiso que el servidor exige para sus datos: el resumen del negocio, las ventas
// por bodega y por sucursal y el IVA, reportes o ver_todo; bancos, compras y pagos a proveedores, gastos o ver_todo; los asientos,
// contabilidad o ver_todo; las ventas de la caja, quien ve montos de la caja. Antes la categoría Administrativos se abría con 'inventario'
// y el Vendedor veía Cuentas por pagar, Compras o Ingresos y gastos, que al abrirlos daban «Su rol no tiene acceso a los reportes».
const P_RESUMEN = ['reportes', 'ver_todo'], P_BANCOS = ['gastos', 'ver_todo'], P_CAJA = ['pos', 'ver_todo', 'escribir', 'cobros', 'facturar'];
const P_CUENTA = ['facturar', 'cobros', 'catalogos', 'ver_todo'];   // 4.9: los de GET /api/revendedoras (lector_cuentas) y de la ruta (menu.js PERMISO_RUTA_ALGUNO)
export const PERMISOS_REPORTE = {
  'ventas-por-item': P_RESUMEN, 'rentabilidad-por-item': P_RESUMEN, 'ventas-por-bodega': P_RESUMEN, 'ventas-por-sucursal': P_RESUMEN, 'cuentas-por-pagar': P_RESUMEN,
  'ingresos-gastos': P_RESUMEN, compras: P_RESUMEN, gastos: P_RESUMEN, 'compras-trimestre': P_RESUMEN, 'reporte-anual': P_RESUMEN, 'declaracion-iva-d104': P_RESUMEN,
  transacciones: P_BANCOS, 'flujo-caja': P_BANCOS, retenciones: P_BANCOS, 'documentos-por-conciliar': P_BANCOS, 'servicio-10': P_CAJA, 'servicio-por-salonero': P_CAJA,
  revendedoras: P_CUENTA, 'estado-cuenta-revendedora': P_CUENTA,
};
const PERMISOS_REPORTE_CAT = { contables: ['contabilidad', 'ver_todo'] };
export function puedeReporte(cat, slug) { if (!puedeCategoria(cat)) return false; const l = PERMISOS_REPORTE[slug] || PERMISOS_REPORTE_CAT[cat]; return !l || l.some(p => sesion.puede(p)); }
export function reportesDe(cat) { return ((CATALOGO[cat] || {}).reportes || []).filter(r => puedeReporte(cat, r.slug)); }
// Reportes propios de otros módulos (viven en su módulo); aparecen aquí como accesos según el permiso
export function accesosModulos() {
  const out = [];
  if (sesion.tipo === 'hospitalidad' && hotelActivo() && (sesion.puede('escribir') || sesion.puede('pos'))) out.push({ key: 'hotel', nombre: 'Hotel', ico: '🛏', desc: 'Entradas, salidas, ocupación, pronóstico, informe diario, caja de recepción, segmentos, agencias y más.', n: 18, to: '/hotel/reportes' });
  if (sesion.tipo !== 'facturacion' && sesion.puede('pos')) out.push({ key: 'cierres-caja', nombre: 'Cierres de caja', ico: '🛒', desc: 'Cierres de caja por sesión, ventas por medio de pago y por cajero.', n: 1, to: '/pos/cierres' });   // 3.87: clave propia (con 'pos' la tarjeta de la categoría Punto de venta también llevaba a los cierres)
  if (sesion.puede('rrhh')) out.push({ key: 'rrhh', nombre: 'Recursos humanos', ico: '👥', desc: 'Planillas, costo patronal, vacaciones, horas extra y liquidaciones.', n: 1, to: '/rrhh/informes' });
  if (sesion.tipo === 'hospitalidad' && hotelActivo() && (sesion.puede('limpieza') || sesion.puede('escribir'))) out.push({ key: 'limpieza', nombre: 'Ama de llaves', ico: '🧹', desc: 'Reportes de limpieza y estado de las habitaciones.', n: 1, to: '/hotel/ama-de-llaves/incidencias' });
  if (sesion.tipo === 'hospitalidad' && hotelActivo() && (sesion.puede('mantenimiento') || sesion.puede('escribir'))) out.push({ key: 'mantenimiento', nombre: 'Mantenimiento', ico: '🔧', desc: 'Incidencias, tiempos de resolución y habitaciones fuera de servicio.', n: 1, to: '/hotel/mantenimiento/incidencias' });
  return out;
}

export function buscarReporte(cat, slug) {
  const c = CATALOGO[cat];
  return c ? c.reportes.find(r => r.slug === slug) : null;
}

export function registrarReciente(cat, rep) {
  const lista = mock.get(claveUsuario('reportes_recientes'), []).filter(x => !(x.cat === cat && x.slug === rep.slug));
  lista.unshift({ cat, slug: rep.slug, nombre: rep.nombre, fecha: new Date().toISOString() });
  mock.set(claveUsuario('reportes_recientes'), lista.slice(0, 6));
}
// 4.7: Historial de exportables. El general (reportes_exportables) lo recibe cualquier usuario con «ver»; el de Recursos humanos
// (rrhh_exportables: fichas, liquidaciones y demás descargas de RRHH) el servidor solo lo entrega con ese permiso. Quien tiene Recursos
// humanos ve los dos juntos, del más reciente al más viejo; lo anotado en el general antes de la 4.7 con datos de un empleado (la regla
// esExportableRRHH, la misma de la limpieza del servidor) solo lo ve quien tiene Recursos humanos.
export function historialExportables() {
  const lista = k => { const v = mock.get(k, []); return Array.isArray(v) ? v.filter(x => x && typeof x === 'object') : []; };
  const conRrhh = sesion.puede('rrhh'), vistos = new Set(), out = [];
  const todos = [...lista(CLAVE_EXPORTABLES).map(x => ({ ...x, rrhh: esExportableRRHH(x) })), ...(conRrhh ? lista(CLAVE_EXPORTABLES_RRHH).map(x => ({ ...x, rrhh: true })) : [])];
  for (const x of todos) {
    const k = [x.archivo, x.reporte, x.fecha].join('|');
    if ((x.rrhh && !conRrhh) || vistos.has(k)) continue;
    vistos.add(k); out.push(x);
  }
  return out.sort((a, b) => String(b.fecha || '').localeCompare(String(a.fecha || '')));
}

export default {
  props: ['params'],
  data() {
    return {
      q: '',
      recientes: mock.get(claveUsuario('reportes_recientes'), []),
      favoritos: mock.get(claveUsuario('reportes_favoritos'), []),
      historial: false,
      exportables: historialExportables(),
    };
  },
  computed: {
    tiles() {
      const t = Object.entries(CATALOGO).map(([key, c]) => ({ key, nombre: c.nombre, ico: c.ico, desc: c.desc, n: reportesDe(key).length })).filter(x => x.n);   // 3.87: solo los reportes que el rol puede abrir
      for (const a of accesosModulos()) t.push(a);
      t.push({ key: 'favoritos', nombre: 'Favoritos', ico: '★', desc: 'Los reportes que marque con estrella aparecerán aquí.', n: this.favoritos.filter(f => puedeReporte(f.cat, f.slug)).length });
      return t;
    },
    resultados() {
      const q = this.q.trim().toLowerCase();
      if (!q) return [];
      const out = [];
      for (const [key, c] of Object.entries(CATALOGO)) for (const r of reportesDe(key)) if ((r.nombre + ' ' + r.desc).toLowerCase().includes(q)) out.push({ cat: key, catNombre: c.nombre, ...r });
      return out;
    },
    recientesVis() { return this.recientes.filter(r => !CATALOGO[r.cat] || puedeReporte(r.cat, r.slug)); },   // 3.87: sin los que el rol ya no puede abrir
  },
  methods: {
    ir(cat, slug) { const a = accesosModulos().find(x => x.key === cat); if (a && !slug) { location.hash = a.to; return; } const r = slug && buscarReporte(cat, slug); location.hash = r && r.ruta ? r.ruta : (slug ? `/reportes/${cat}/${slug}` : `/reportes/${cat}`); },   // 4.9: los que tienen pantalla propia (ruta)
    puedeFin() { return sesion.puede('reportes') || sesion.puede('ver_todo'); },
    fechaHora(iso) { return fechaHora(iso); },
    invitar() { location.hash = '/configuracion/usuarios?rol=Contador'; },   // agregarlo como usuario con rol Contador (R164); 3.87: solo quien administra usuarios ve el botón (los demás llegaban a «Sin acceso»)
    ayuda() { toast('Centro de ayuda: cómo leer e interpretar cada reporte.'); },
    abrirHistorial() { this.exportables = historialExportables(); this.historial = true; },   // 4.7: al abrirlo, lo último descargado (también lo de RRHH)
  },
  template: `
  <div class="page">
    <ReportesTabs></ReportesTabs>
    <div class="alert info" v-if="puedeFin() && puede('usuarios')" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
      <span><b>Invite a su contador.</b> Comparta los reportes contables y fiscales sin darle acceso a toda la empresa.</span>
      <button class="btn sm" @click="invitar">Invitar a mi contador</button>
    </div>
    <PageHead title="Reportes" sub="Analice la información de su negocio y tome mejores decisiones.">
      <button class="btn ghost" @click="ayuda">? Ayuda</button>
      <button class="btn sec" @click="abrirHistorial">Historial de exportables</button>
    </PageHead>

    <div class="toolbar"><input class="search" style="min-width:320px" placeholder="Buscar reporte por nombre" v-model="q"></div>

    <div class="card" v-if="q.trim()">
      <h2>Resultados <small>{{resultados.length}} reporte(s)</small></h2>
      <Empty v-if="!resultados.length" icon="⌕" title="Sin coincidencias" text="Pruebe con otro nombre, por ejemplo: ventas, IVA, balance."></Empty>
      <div class="tiles" v-else>
        <a class="tile" v-for="r in resultados" :key="r.cat+r.slug" @click="ir(r.cat, r.slug)"><h3>{{r.nombre}}</h3><p>{{r.desc}}</p><div class="links"><span class="badge">{{r.catNombre}}</span></div></a>
      </div>
    </div>

    <a class="card" v-if="!q.trim()" href="#/reportes/modulos" style="display:block;margin:0 0 14px;border-color:var(--primary);text-decoration:none;color:inherit">
      <div class="row" style="justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0">▤ Reporte ejecutivo por módulo</h2><div class="small muted">Las cifras clave de cada módulo al que tiene acceso: hotel, punto de venta, ama de llaves, mantenimiento, recursos humanos, inventario y finanzas.</div></div><span class="btn sm sec">Abrir</span></div>
    </a>
    <a class="card" v-if="!q.trim() && puedeFin()" href="#/reportes/ejecutivo" style="display:block;margin:0 0 14px;border-color:var(--primary);text-decoration:none;color:inherit">
      <div class="row" style="justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0">★ Reporte ejecutivo</h2><div class="small muted">Las cifras del Inicio con su detalle: ventas, devoluciones, cuentas por cobrar y por pagar, IVA, ítems, clientes, egresos y flujo, en todas sus monedas y exportables a CSV.</div></div><span class="btn">Abrir</span></div>
    </a>
    <div class="tiles" v-if="!q.trim()">
      <a class="tile" v-for="t in tiles" :key="t.key" @click="ir(t.key)">
        <div class="row" style="justify-content:space-between"><h3>{{t.ico}} {{t.nombre}}</h3><span class="badge primary">{{t.n}}</span></div>
        <p>{{t.desc}}</p>
      </a>
    </div>

    <div class="card" style="margin-top:18px">
      <h2>Recientes <small>últimos reportes consultados</small></h2>
      <Empty v-if="!recientesVis.length" icon="🕘" title="Todavía no ha consultado reportes" text="Los reportes que abra aparecerán aquí para acceder más rápido."></Empty>
      <div class="table-wrap" v-else><table class="tbl">
        <thead><tr><th>Reporte</th><th>Categoría</th><th>Consultado</th></tr></thead>
        <tbody><tr v-for="r in recientesVis" :key="r.cat+r.slug"><td><a class="link" @click="ir(r.cat, r.slug)">{{r.nombre}}</a></td><td>{{CATALOGO[r.cat]?.nombre || (r.cat === 'ejecutivo' ? 'Ejecutivo' : r.cat)}}</td><td class="muted">{{fechaHora(r.fecha)}}</td></tr></tbody>
      </table></div>
    </div>

    <Modal v-if="historial" title="Historial de exportables" @close="historial=false">
      <Empty v-if="!exportables.length" icon="⤓" title="Sin exportaciones" text="Los archivos CSV que descargue desde un reporte quedarán registrados aquí."></Empty>
      <div class="table-wrap" v-else><table class="tbl">
        <thead><tr><th>Archivo</th><th>Reporte</th><th>Fecha</th></tr></thead>
        <tbody><tr v-for="(e,i) in exportables" :key="i"><td class="mono">{{e.archivo}}</td><td>{{e.reporte}}<span v-if="e.rrhh" class="small muted"> · Recursos humanos</span></td><td class="muted">{{fechaHora(e.fecha)}}</td></tr></tbody>
      </table></div>
      <template #foot><button class="btn sec" @click="historial=false">Cerrar</button></template>
    </Modal>
  </div>`,
  setup() { return { CATALOGO }; },
};

// 4.1: los reportes de cada módulo (menú › Ingresos › Reportes, Gastos › Reportes…): /reportes/de-<módulo>
export const MODULO_REPORTES = {
  ingresos: { nombre: 'Ingresos', slugs: ['ventas-generales', 'ventas-por-item', 'ventas-por-cliente', 'ventas-por-vendedor', 'rentabilidad-por-item', 'ventas-por-sucursal', 'ventas-por-bodega', 'cuentas-por-cobrar', 'estado-cuenta-cliente', 'revendedoras', 'estado-cuenta-revendedora', 'reporte-anual', 'declaracion-iva-d104'] },
  compras: { nombre: 'Compras y gastos', slugs: ['compras', 'gastos', 'cuentas-por-pagar', 'retenciones', 'compras-trimestre', 'ingresos-gastos'] },
  clientes: { nombre: 'Clientes', slugs: ['estado-cuenta-cliente', 'revendedoras', 'estado-cuenta-revendedora', 'ventas-por-cliente', 'cuentas-por-cobrar', 'ventas-generales', 'auxiliar-terceros'] },
  proveedores: { nombre: 'Proveedores', slugs: ['compras', 'gastos', 'cuentas-por-pagar', 'retenciones', 'compras-trimestre', 'auxiliar-terceros'] },
  ambos: { nombre: 'Clientes y proveedores', slugs: ['auxiliar-terceros', 'estado-cuenta-cliente', 'cuentas-por-cobrar', 'cuentas-por-pagar'] },
  pos: { nombre: 'Punto de venta', slugs: ['ventas-generales', 'ventas-por-item', 'ventas-por-vendedor', 'ventas-por-sucursal', 'servicio-10', 'servicio-por-salonero', 'rentabilidad-por-item'] },
  contactos: { nombre: 'Contactos', slugs: ['estado-cuenta-cliente', 'revendedoras', 'estado-cuenta-revendedora', 'ventas-por-cliente', 'cuentas-por-cobrar', 'cuentas-por-pagar', 'auxiliar-terceros'] },
  inventario: { nombre: 'Inventario', slugs: ['valor-inventario', 'ventas-por-item', 'rentabilidad-por-item', 'ventas-por-bodega'] },
  bancos: { nombre: 'Bancos', slugs: ['transacciones', 'flujo-caja', 'documentos-por-conciliar'] },
  contabilidad: { nombre: 'Contabilidad', slugs: ['estado-resultados', 'estado-resultados-mensual', 'balance-general', 'balance-prueba', 'libro-diario', 'libro-mayor', 'movimientos-por-cuenta', 'auxiliar-terceros', 'comprobantes-contables', 'estado-resultados-comparativo', 'balance-general-comparativo', 'resultados-centro-costo', 'presupuesto-vs-real', 'libro-inventarios-balances', 'declaracion-iva-d104'] },
};
export function reportesModulo(mod) {
  const m = MODULO_REPORTES[mod];
  if (!m) return [];
  const out = [];
  for (const slug of m.slugs) for (const [cat, c] of Object.entries(CATALOGO)) { const r = (c.reportes || []).find(x => x.slug === slug); if (r && puedeReporte(cat, slug)) { out.push({ cat, ...r }); break; } }
  return out;
}
