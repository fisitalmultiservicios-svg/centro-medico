// Asientos contables — lista sobre el registro 'asientos' (manuales y automáticos; la semilla solo en modo demo).
import { money, fecha, toast, mock, monedas } from '../../api.js';
import { sincronizarAutomaticos, resumenSync } from './automaticos.js';
import { periodoCerrado } from './parametros.js';

function dias(n) { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); }

// Tipos de asiento con su código
export const TIPOS_ASIENTO = [
  ['AC', 'Asiento contable'], ['AJ', 'Ajuste contable'], ['AP', 'Apertura'], ['CI', 'Cierre de período'], ['DP', 'Depreciación'],
  ['NM', 'Nómina'], ['PR', 'Provisión'], ['RC', 'Reclasificación'], ['DC', 'Diferencial cambiario'], ['IM', 'Impuestos'],
  ['IN', 'Ingreso'], ['EG', 'Egreso'], ['CP', 'Compra'], ['VT', 'Venta'], ['TR', 'Traslado entre cuentas'], ['CV', 'Costo de ventas'], ['SI', 'Saldos iniciales'],
];
export const NUMERACIONES = [{ nombre: 'Asientos contables', prefijo: 'AC' }, { nombre: 'Ajustes', prefijo: 'AJ' }, { nombre: 'Saldos iniciales', prefijo: 'SI' }];

export function asientosMock() {
  const L = (cuenta, cuenta_nombre, debito, credito, descripcion = '', contacto = '', documento = '') => ({ cuenta, cuenta_nombre, contacto, documento, descripcion, debito, credito });
  const semilla = [
      { id: 1, codigo: 'AC-1', fecha: dias(28), tipo: 'Asiento contable', numeracion: 'AC', observaciones: 'Alquiler de oficina en Sabana, mes en curso', lineas: [
        L('6.2.02.02.02', 'Arrendamiento de oficinas', 650000, 0, 'Alquiler oficina', 'Inmobiliaria Sabana S.A.', 'FE-00045'), L('1.1.04.02.01', 'IVA soportado', 84500, 0, 'IVA 13 %'), L('1.1.01.02.01.01', 'Banco Nacional', 0, 734500, 'Transferencia BN')] },
      { id: 2, codigo: 'AC-2', fecha: dias(20), tipo: 'Depreciación', numeracion: 'AC', observaciones: 'Depreciación mensual vehículo Toyota Hilux', lineas: [
        L('6.2.03.02.04', 'Depreciación vehiculos y equipos de transporte', 133333, 0, 'Depreciación lineal'), L('1.2.02.04', 'Depreciación acumulada vehiculos y equipos de transporte', 0, 133333)] },
      { id: 3, codigo: 'AC-3', fecha: dias(10), tipo: 'Nómina', numeracion: 'AC', observaciones: 'Planilla quincenal administrativa', lineas: [
        L('6.2.01.01', 'Sueldos y salarios', 1250000, 0, 'Salarios brutos'), L('6.2.01.03', 'Gastos por cargas sociales', 330625, 0, 'Cuota patronal 26,45 %'),
        L('2.1.02.02.01', 'Retención laboral CCSS por pagar', 0, 462500, 'Patronal + obrera 10,5 %'), L('1.1.01.02.01.01', 'Banco Nacional', 0, 1118125, 'Pago neto planilla')] },
      { id: 4, codigo: 'AJ-1', fecha: dias(4), tipo: 'Diferencial cambiario', numeracion: 'AJ', observaciones: 'Revaluación cuenta BAC USD al tipo de cambio de cierre', lineas: [
        L('1.1.01.02.02.01', 'Banco De Costa Rica', 42300, 0, 'Ajuste por tipo de cambio'), L('4.2.02.01', 'Ganancia por diferencia en cambio', 0, 42300)] },
  ];
  return mock.ejemplos('asientos', semilla, 'observaciones');
}
export function totalesAsiento(a) { return a.lineas.reduce((t, l) => ({ debito: t.debito + (+l.debito || 0), credito: t.credito + (+l.credito || 0) }), { debito: 0, credito: 0 }); }

export default {
  props: ['params'],
  data() { return { asientos: asientosMock(), q: '', menu: false, ver: null, sync: null }; },
  async created() { await this.sincronizar(); },
  computed: {
    monP() { return monedas.principal().codigo; },   // la moneda principal, no siempre ₡ (R222)
    rows() { return this.asientos.slice().sort((a, b) => String(b.fecha || "").localeCompare(String(a.fecha || "")) || b.id - a.id).map(a => ({ ...a, ...totalesAsiento(a), origen_badge: a.automatico ? (a.ajustado ? ((this.sync && this.sync.huerfanos || []).includes(a.id) ? 'Ajustado · sin origen' : 'Automático ajustado') : 'Automático') : 'Manual' })); },
    columns() {
      return [
        { key: 'codigo', label: 'Código', mono: true, link: r => this.ver = r },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'tipo', label: 'Tipo' },
        { key: 'origen_badge', label: 'Origen', fmt: 'badge' },
        { key: 'observaciones', label: 'Observaciones', fmt: v => v || '—' },
        { key: 'debito', label: 'Débito', num: true, fmt: 'money' },
        { key: 'credito', label: 'Crédito', num: true, fmt: 'money' },
      ];
    },
    totVer() { return this.ver ? totalesAsiento(this.ver) : { debito: 0, credito: 0 }; },
  },
  methods: {
    async sincronizar() { try { this.sync = await sincronizarAutomaticos(); this.asientos = asientosMock(); const t = resumenSync(this.sync); if (t) toast(t, 'ok'); if (this.sync && this.sync.huerfanos && this.sync.huerfanos.length) toast(this.sync.huerfanos.length + ' asiento(s) ajustado(s) cuyo origen ya no existe: revíselos (etiqueta "sin origen")', 'err'); } catch {} },
    // un ajustado vuelve a automático: en la siguiente sincronización se regenera desde su origen o se elimina si ya no existe (R216)
    async volverAutomatico(a) { if (!confirm('¿Devolver el asiento ' + a.codigo + ' a automático? Se regenerará desde su origen (o se eliminará si el origen ya no existe) y se perderán los ajustes manuales.')) return; const l = asientosMock(); const x = l.find(y => y.id === a.id); if (x) { x.ajustado = false; await mock.set('asientos', l); } await this.sincronizar(); toast('Asiento devuelto a automático', 'ok'); },
    money, fecha,
    editar(a) { location.hash = '/contabilidad/asientos/' + a.id; },
    importar(e) { const f = e.target.files[0]; if (!f) return; e.target.value = ''; this.menu = false; toast('Archivo «' + f.name + '» recibido. La importación de asientos estará disponible cuando el backend de contabilidad esté listo.'); },
    eliminar(a) {
      if (a.automatico && !a.ajustado) return toast('Este asiento es automático: se genera del comprobante o pago de origen y volvería a crearse. Anule o elimine el origen, o edítelo para ajustarlo.', 'err');
      { const per = periodoCerrado(a.fecha); if (per) return toast('El periodo ' + per.mes + ' ' + per.anio + ' está cerrado: reábralo en Configuración › Periodos contables', 'err'); }
      if (!confirm('¿Eliminar el asiento ' + a.codigo + '?')) return; this.asientos = mock.actualizar('asientos', l => (l || []).filter(x => x.id !== a.id), []); this.ver = null; toast('Asiento eliminado'); },
    eliminarVarios(rows) {
      const auto = rows.filter(r => r.automatico && !r.ajustado).length; if (auto) toast(auto + ' asiento(s) automático(s) no se eliminan: volverían a generarse', 'err');
      const cerrados = rows.filter(r => periodoCerrado(r.fecha)).length; if (cerrados) toast(cerrados + ' asiento(s) de periodos cerrados no se eliminan', 'err');
      rows = rows.filter(r => !(r.automatico && !r.ajustado) && !periodoCerrado(r.fecha)); const ids = rows.map(r => r.id);
      if (!ids.length) return;
      this.asientos = mock.actualizar('asientos', l => (l || []).filter(x => !ids.includes(x.id)), []); toast(ids.length + ' asientos eliminados', 'ok');
    },
  },
  template: `
  <div class="page">
    <PageHead title="Asientos contables" sub="Asientos automáticos por cada comprobante emitido, recibido y aceptado, y cada pago (con su IVA), más los manuales: ajustes, depreciaciones, nómina y más. Todos se pueden editar."><Atajo to="/contabilidad/catalogo" label="Catálogo de cuentas"></Atajo>
      <div class="row" style="gap:0;position:relative">
        <a class="btn" v-if="puede('contabilidad')" href="#/contabilidad/asientos/nuevo" style="border-radius:7px 0 0 7px">+ Nuevo asiento contable</a>
        <button class="btn" style="border-radius:0 7px 7px 0;border-left-color:rgba(255,255,255,.4);padding:8px 10px" @click="menu=!menu">▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:240px;padding:6px">
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/contabilidad/asientos/nuevo">Crear asiento contable</a>
          <label class="item" style="display:block;padding:8px 10px;cursor:pointer">Importar asientos (Excel/CSV)<input type="file" accept=".xlsx,.xls,.csv" style="display:none" @change="importar"></label>
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/contabilidad/saldos-iniciales">Crear saldos iniciales</a>
        </div>
      </div>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar por código, tipo u observaciones" v-model="q"><button class="btn ghost sm">⚲ Filtrar</button></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('contabilidad')" :on-bulk-delete="eliminarVarios" empty-title="Aún no tienes asientos contables" empty-text="Crea tu primer asiento contable para registrar movimientos entre cuentas, o importa tus asientos desde Excel." @row-click="ver=$event">
        <template #actions="{row}"><button class="btn icon" title="Ver" @click.stop="ver=row">👁</button><button class="btn icon" v-if="puede('contabilidad')" title="Editar" @click.stop="editar(row)">✎</button><button class="btn sm ghost" v-if="row.automatico && row.ajustado && puede('contabilidad')" title="Vuelve a generarse desde su origen (o se elimina si el origen ya no existe)" @click.stop="volverAutomatico(row)">↺ Automático</button><button class="btn icon" v-if="puede('contabilidad')" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
        <template #empty><a class="btn" v-if="puede('contabilidad')" href="#/contabilidad/asientos/nuevo">+ Nuevo asiento contable</a><a class="btn sec" href="#/contabilidad/saldos-iniciales" style="margin-left:8px">Crear saldos iniciales</a></template>
      </DataTable>
    </div>

    <Modal v-if="ver" :title="'Asiento ' + ver.codigo" lg @close="ver=null">
      <div class="row" style="margin-bottom:12px"><span class="chip">{{fecha(ver.fecha)}}</span><span class="chip on">{{ver.tipo}}</span><span class="chip" v-if="ver.automatico">{{ver.ajustado ? 'Automático · ajustado' : 'Automático'}}</span><span class="small muted" v-if="ver.observaciones">{{ver.observaciones}}</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Cuenta contable</th><th>Contacto</th><th>N° documento</th><th>Descripción</th><th class="num">Débito</th><th class="num">Crédito</th></tr></thead>
        <tbody><tr v-for="(l,i) in ver.lineas" :key="i"><td><span class="mono">{{l.cuenta}}</span> {{l.cuenta_nombre}}</td><td>{{l.contacto||'—'}}</td><td class="mono">{{l.documento||'—'}}</td><td style="white-space:normal">{{l.descripcion||'—'}}</td><td class="num">{{l.debito ? money(l.debito, monP) : ''}}</td><td class="num">{{l.credito ? money(l.credito, monP) : ''}}</td></tr></tbody>
        <tfoot><tr><th colspan="4" style="text-align:right">Totales</th><th class="num">{{money(totVer.debito, monP)}}</th><th class="num">{{money(totVer.credito, monP)}}</th></tr></tfoot>
      </table></div>
      <template #foot><button class="btn danger" @click="eliminar(ver)">Eliminar</button><button class="btn sec" @click="editar(ver)">Editar</button><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
  </div>`,
};
