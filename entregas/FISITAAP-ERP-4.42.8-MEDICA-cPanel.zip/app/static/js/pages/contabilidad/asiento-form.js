// Asiento contable — formulario de alta y edición sobre el registro 'asientos'.
import { money, hoy, toast, mock, monedas } from '../../api.js';
import { store } from '../../app.js';
import { planCuentas } from './catalogo.js';
import { asientosMock, TIPOS_ASIENTO, NUMERACIONES } from './asientos.js';
import { centrosCosto } from './centros-costo.js';   // centros de costo por línea (3.8)

const linea = () => ({ cuenta: '', contacto: '', documento: '', descripcion: '', centro: '', debito: null, credito: null });

export default {
  props: ['params'],
  data() {
    const asientos = asientosMock();
    const id = this.params && this.params.id && this.params.id !== 'nuevo' ? +this.params.id : null;
    const ex = id ? asientos.find(a => a.id === id) : null;
    const tipoCod = ex ? ((TIPOS_ASIENTO.find(t => t[1] === ex.tipo) || [ex.tipo])[0]) : 'AC';
    const f = ex ? { fecha: ex.fecha, tipo: tipoCod, numeracion: ex.numeracion || 'AC', observaciones: ex.observaciones || '',
                     lineas: ex.lineas.map(l => ({ cuenta: l.cuenta, cuenta_nombre: l.cuenta_nombre || '', contacto: l.contacto || '', documento: l.documento || '', descripcion: l.descripcion || '', centro: l.centro || '', debito: l.debito || null, credito: l.credito || null })) }
                 : { fecha: hoy(), tipo: 'AC', numeracion: 'AC', observaciones: '', lineas: [linea(), linea()] };
    const usadas = new Set(f.lineas.map(l => l.cuenta));
    // numeraciones: las base más las creadas en Configuración › Contabilidad › Numeraciones contables (por prefijo)
    const numeraciones = NUMERACIONES.slice();
    for (const n of (mock.get('numeraciones_contables', []) || [])) { const p = String(n.prefijo || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); if (p && !numeraciones.some(x => x.prefijo === p)) numeraciones.push({ nombre: n.nombre || p, prefijo: p }); }
    if (ex && ex.numeracion && !numeraciones.some(x => x.prefijo === ex.numeracion)) numeraciones.push({ nombre: ex.numeracion, prefijo: ex.numeracion });
    return { plan: planCuentas().filter(c => c.hoja || usadas.has(c.codigo)), TIPOS_ASIENTO, NUMERACIONES: numeraciones, asientos, editando: ex || null, f, centros: centrosCosto().filter(c => c.activo !== false) };
  },
  computed: {
    monP() { return monedas.principal().codigo; },   // la moneda principal, no siempre ₡ (R222)
    store() { return store; },
    codigo() { if (this.editando) return this.editando.codigo; const p = this.f.numeracion; const n = this.asientos.filter(a => (a.codigo || '').startsWith(p + '-')).reduce((m, a) => Math.max(m, +a.codigo.split('-')[1] || 0), 0) + 1; return p + '-' + n; },
    // Solo cuentan las líneas que se van a guardar (con cuenta y monto positivo). Antes los totales sumaban también líneas sin
    // cuenta, la diferencia daba 0 y se guardaba un asiento que no cuadraba.
    lineasValidas() { return this.f.lineas.filter(l => l.cuenta && (((+l.debito || 0) > 0) !== ((+l.credito || 0) > 0)) && (+l.debito || 0) >= 0 && (+l.credito || 0) >= 0); },
    problemas() {
      const out = [];
      this.f.lineas.forEach((l, i) => {
        const d = +l.debito || 0, c = +l.credito || 0, n = 'Línea ' + (i + 1);
        if ((d || c) && !l.cuenta) out.push(n + ': tiene monto pero no tiene cuenta');
        if (d < 0 || c < 0) out.push(n + ': los montos no pueden ser negativos');
        if (d > 0 && c > 0) out.push(n + ': use débito o crédito, no los dos');
      });
      return out;
    },
    totDebito() { return this.lineasValidas.reduce((s, l) => s + (+l.debito || 0), 0); },
    totCredito() { return this.lineasValidas.reduce((s, l) => s + (+l.credito || 0), 0); },
    diferencia() { return +(this.totDebito - this.totCredito).toFixed(2); },
    puedeGuardar() { return !this.problemas.length && this.diferencia === 0 && this.totDebito > 0 && this.lineasValidas.length >= 2 && !!this.f.fecha && !!this.f.tipo; },
  },
  methods: {
    money,
    nombreCuenta(c) { return this.plan.find(x => x.codigo === c)?.nombre || ''; },
    agregar() { this.f.lineas.push(linea()); },
    quitar(i) { this.f.lineas.splice(i, 1); if (!this.f.lineas.length) this.agregar(); },
    exclusivo(l, campo) { if (+l[campo] > 0) l[campo === 'debito' ? 'credito' : 'debito'] = null; },
    guardar(otro) {
      if (this.problemas.length) return toast(this.problemas[0], 'err');
      if (!this.puedeGuardar) return toast('El asiento debe cuadrar: total débito igual a total crédito, con al menos dos líneas.', 'err');
      const tipo = TIPOS_ASIENTO.find(t => t[0] === this.f.tipo);
      { const [an, me] = String(this.f.fecha).slice(0, 7).split('-'); const per = (mock.get('periodos_' + an, null) || []).find(x => x.n === +me); if (per && per.estado === 'Cerrado') return toast('El periodo ' + per.mes + ' ' + an + ' está cerrado: reábralo en Configuración › Periodos contables o cambie la fecha', 'err'); }   // (R213)
      const lineas = this.lineasValidas.map(l => ({ cuenta: l.cuenta, cuenta_nombre: this.nombreCuenta(l.cuenta) || l.cuenta_nombre || '', contacto: l.contacto, documento: l.documento, descripcion: l.descripcion, centro: l.centro || '', debito: +l.debito || 0, credito: +l.credito || 0 }));
      if (this.editando) {
        const i = this.asientos.findIndex(x => x.id === this.editando.id);
        const tipoN = tipo ? tipo[1] : this.f.tipo, ed = this.editando;
        const cambio = JSON.stringify({ f: ed.fecha, t: ed.tipo, o: ed.observaciones || '', l: (ed.lineas || []).map(l => [l.cuenta, +l.debito || 0, +l.credito || 0, l.descripcion || '', l.contacto || '', l.documento || '']) })
          !== JSON.stringify({ f: this.f.fecha, t: tipoN, o: this.f.observaciones || '', l: lineas.map(l => [l.cuenta, l.debito, l.credito, l.descripcion || '', l.contacto || '', l.documento || '']) });
        // un automático queda "ajustado" solo si de verdad cambió algo (R216)
        const a = { ...ed, fecha: this.f.fecha, tipo: tipoN, numeracion: this.f.numeracion, observaciones: this.f.observaciones, lineas, ajustado: ed.automatico ? (!!ed.ajustado || cambio) : !!ed.ajustado };
        if (i >= 0) this.asientos.splice(i, 1, a); else this.asientos.push(a);
        this.asientos = mock.actualizar('asientos', l => { const lista = Array.isArray(l) ? l : []; const k = lista.findIndex(x => x.id === a.id); if (k >= 0) lista.splice(k, 1, a); else lista.push(a); return lista; }, []);
        toast('Asiento ' + a.codigo + ' actualizado' + (a.automatico ? ' · marcado como ajustado, no se regenera' : ''), 'ok');
        location.hash = '/contabilidad/asientos'; return;
      }
      // número sobre la lista guardada más reciente (otra persona pudo crear un asiento con esa numeración mientras tanto)
      const recientes = mock.get('asientos', []) || [], p = this.f.numeracion;
      const codigo = p + '-' + (recientes.filter(x => (x.codigo || '').startsWith(p + '-')).reduce((m, x) => Math.max(m, +String(x.codigo).split('-')[1] || 0), Math.max(0, +this.codigo.split('-')[1] - 1)) + 1);
      const a = { id: mock.nextId(this.asientos, 'asientos'), codigo, fecha: this.f.fecha, tipo: tipo ? tipo[1] : this.f.tipo, numeracion: this.f.numeracion, observaciones: this.f.observaciones, lineas };
      this.asientos = mock.actualizar('asientos', l => [...(Array.isArray(l) ? l : []), a], []);
      toast('Asiento ' + a.codigo + ' guardado', 'ok');
      if (otro) this.f = { fecha: this.f.fecha, tipo: this.f.tipo, numeracion: this.f.numeracion, observaciones: '', lineas: [linea(), linea()] };
      else location.hash = '/contabilidad/asientos';
    },
  },
  template: `
  <div class="page">
    <PageHead :title="editando ? 'Editar asiento ' + editando.codigo : 'Nuevo asiento contable'" :sub="editando && editando.automatico ? 'Asiento generado automáticamente (' + editando.observaciones + '). Al guardar queda marcado como ajustado y el sistema no lo vuelve a regenerar.' : 'Registre un movimiento manual entre cuentas. El asiento debe cuadrar antes de guardarse.'" :crumbs="[{label:'Asientos contables',to:'/contabilidad/asientos'},{label: editando ? editando.codigo : 'Nuevo'}]">
      <a class="btn ghost" href="#/contabilidad/asientos">Cancelar</a>
      <button class="btn sec" v-if="!editando" :disabled="!puedeGuardar" @click="guardar(true)">Guardar y crear otro</button>
      <button class="btn" :disabled="!puedeGuardar" @click="guardar(false)">Guardar</button>
    </PageHead>

    <div class="card">
      <div class="grid">
        <Field label="Fecha" req><input type="date" v-model="f.fecha"></Field>
        <Field label="Tipo de asiento" req><select v-model="f.tipo"><option v-for="t in TIPOS_ASIENTO" :key="t[0]" :value="t[0]">{{t[0]}} · {{t[1]}}</option></select></Field>
        <Field label="Numeración" req><select v-model="f.numeracion"><option v-for="n in NUMERACIONES" :key="n.prefijo" :value="n.prefijo">{{n.nombre}} ({{n.prefijo}})</option></select></Field>
        <Field label="Código" help="Se genera automáticamente"><input :value="codigo" disabled class="mono"></Field>
        <Field label="Observaciones" style="grid-column:1/-1"><textarea rows="2" v-model="f.observaciones" placeholder="Describa el motivo del asiento"></textarea></Field>
      </div>
    </div>

    <div class="card">
      <h2>Movimientos</h2>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th style="width:280px">Cuenta contable</th><th style="width:180px">Contacto</th><th style="width:170px" v-if="centros.length">Centro de costo</th><th style="width:120px">N° documento</th><th>Descripción</th><th class="num" style="width:140px">Débito</th><th class="num" style="width:140px">Crédito</th><th></th></tr></thead>
        <tbody><tr v-for="(l,i) in f.lineas" :key="i">
          <td><select class="inp" v-model="l.cuenta" style="width:100%"><option value="">— Seleccione —</option><option v-for="c in plan" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></td>
          <td><Buscador v-model="l.contacto" :opciones="store.clientes" valor="nombre" detalle="numero_id" agregar="contacto"></Buscador></td>
          <td v-if="centros.length"><select class="inp" v-model="l.centro" style="width:100%"><option value="">—</option><option v-for="c in centros" :key="c.id" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></td>
          <td><input class="inp mono" v-model="l.documento" style="width:100%" placeholder="FE-0001"></td>
          <td><input class="inp" v-model="l.descripcion" style="width:100%;min-width:160px"></td>
          <td><input class="inp" type="number" step="0.01" min="0" v-model.number="l.debito" @input="exclusivo(l,'debito')" style="width:100%;text-align:right"></td>
          <td><input class="inp" type="number" step="0.01" min="0" v-model.number="l.credito" @input="exclusivo(l,'credito')" style="width:100%;text-align:right"></td>
          <td><button class="btn icon" @click="quitar(i)" title="Quitar">✕</button></td>
        </tr></tbody>
      </table></div>
      <div class="row" style="margin-top:8px"><button class="btn sec sm" @click="agregar">+ Agregar línea</button></div>
      <div class="totals">
        <div><span>Total débito</span><b>{{money(totDebito, monP)}}</b></div>
        <div><span>Total crédito</span><b>{{money(totCredito, monP)}}</b></div>
        <div class="total"><span>Diferencia</span><b :style="{color: diferencia===0 ? 'var(--ok)' : 'var(--danger)'}">{{money(diferencia, monP)}}</b></div>
      </div>
      <div class="alert warn" v-if="problemas.length" style="margin:12px 0 0"><div v-for="x in problemas" :key="x">{{x}}</div></div>
      <div class="alert warn" v-else-if="diferencia!==0" style="margin:12px 0 0">El asiento no cuadra: los débitos deben ser iguales a los créditos para poder guardar.</div>
    </div>
    <Comments :saved="false"></Comments>
  </div>`,
};
