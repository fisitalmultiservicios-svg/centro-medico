// Asientos automáticos. Por cada comprobante emitido (venta, nota de crédito o débito, factura de compra), cada comprobante de
// proveedor recibido y aceptado, y cada pago recibido, se genera un asiento con las cuentas de Configuración › Contabilidad ›
// Parametrización (IVA débito/crédito, ventas, cuentas por cobrar y por pagar, caja y bancos). Quedan marcados como automáticos
// (origen = comprobante o pago); si el usuario los ajusta no se vuelven a tocar, y si el origen deja de ser válido (comprobante
// rechazado, pago eliminado) y no fue ajustado, se eliminan. Montos en la moneda principal: lo emitido en otra moneda se
// convierte con el tipo de cambio del comprobante.
import { api, mock, monedas, fmt, hoy } from '../../api.js';
import { mesLegible } from '../gastos/_registro.js';
import { asientosMock } from './asientos.js';
import { paramContable, cuentaDe, fechaAbierta, periodoCerrado } from './parametros.js';
import { bancosMock } from '../bancos/cuentas.js';
import { activosMock, periodosDepreciados, cuota, baseDepreciable, fechaPeriodo } from './activos.js';
import { sesion } from '../../app.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;
const NOMBRE = { '01': 'Factura', '02': 'Nota de débito', '03': 'Nota de crédito', '04': 'Tiquete', '08': 'Factura de compra', '09': 'Factura de exportación' };

// Monto del documento en la moneda principal de la empresa (lo emitido en otra moneda × tipo de cambio del comprobante).
// 4.1: con una moneda «forzada» (la del documento) los montos quedan en esa moneda: así se guardan los originales en cada asiento
let _forzada = null;
export function aPrincipal(monto, moneda, tcDoc) {
  const p = _forzada || monedas.principal().codigo;
  if (!moneda || moneda === p) return r2(monto);
  const tc = +tcDoc > 1 ? +tcDoc : monedas.tc(moneda);           // documentos viejos sin tipo de cambio: la venta BCCR
  const enColones = moneda === 'CRC' ? +monto : +monto * tc;
  // principal distinta de CRC: un documento en CRC se pasa con el tipo de cambio del propio documento (si lo trae) o la venta BCCR
  return p === 'CRC' ? r2(enColones) : r2(enColones / (moneda === 'CRC' && +tcDoc > 1 ? +tcDoc : monedas.tc(p)));
}

function L(param, clave, debito, credito, descripcion, contacto, documento) {
  const c = cuentaDe(param[clave]);
  return { cuenta: c.cuenta, cuenta_nombre: c.nombre, contacto: contacto || '', documento: documento || '', descripcion: descripcion || '', debito: r2(debito), credito: r2(credito) };
}
function ref(d) { const p = monedas.principal().codigo; return d.moneda && d.moneda !== p ? ` (${d.moneda} ${fmt(d.total)} × ${fmt(+d.tipo_cambio > 1 ? d.tipo_cambio : (monedas.get(d.moneda)?.tipo_cambio || 1))})` : ''; }

function asientoDoc(d, param, compra) {   // compra: la factura de compra registrada que emitió esta FEC (08), con su tipo compra/gasto (4.3)
  const tipo = d.tipo_documento, total = aPrincipal(d.total, d.moneda, d.tipo_cambio), iva = aPrincipal(d.impuesto || 0, d.moneda, d.tipo_cambio);
  // 3.41: el Selectivo y los específicos cobrados se deben a Hacienda (no son venta); en la factura de compra son parte del costo
  const otrosImp = ['01', '02', '03', '04', '09'].includes(tipo) ? aPrincipal(d.otros_impuestos || 0, d.moneda, d.tipo_cambio) : 0, base = r2(total - iva - otrosImp);
  const doc = d.consecutivo, con = d.receptor_nombre || '', obs = `${NOMBRE[tipo] || tipo} ${doc}${con ? ' · ' + con : ''}${ref(d)}`;
  if (['01', '02', '04', '09'].includes(tipo)) return { tipo: 'Venta', obs, lineas: [L(param, 'cxc', total, 0, 'Por cobrar al cliente', con, doc), L(param, 'ventas_ingresos', 0, base, 'Venta', con, doc), ...(iva ? [L(param, 'iva_debito', 0, iva, 'IVA cobrado', con, doc)] : []), ...(otrosImp ? [L(param, 'otros_impuestos', 0, otrosImp, 'Selectivo o impuesto específico cobrado', con, doc)] : [])] };
  if (tipo === '03') return { tipo: 'Venta', obs, lineas: [L(param, 'ventas_devoluciones', base, 0, 'Devolución', con, doc), ...(iva ? [L(param, 'iva_debito', iva, 0, 'IVA devuelto', con, doc)] : []), ...(otrosImp ? [L(param, 'otros_impuestos', otrosImp, 0, 'Selectivo o impuesto específico devuelto', con, doc)] : []), L(param, 'cxc', 0, total, 'Menos por cobrar al cliente', con, doc)] };
  if (tipo === '08') return { tipo: 'Compra', obs, lineas: [LC(cuentaCompra(param, compra), base, 0, compra && compra.tipo === 'compra' ? 'Compra de mercadería' : 'Gasto', con, doc), ...(iva ? [L(param, 'iva_credito', iva, 0, 'IVA acreditable', con, doc)] : []), L(param, 'cxp', 0, total, 'Por pagar al proveedor', con, doc)] };
  return null;
}
// 4.3: la cuenta de una compra o gasto: la elegida en el comprobante; si no, según su clasificación (compra = costo de ventas, gasto = gastos)
function cuentaCompra(param, x) { return (x && x.cuenta_contable) || ((x && (x.clasificacion || x.tipo)) === 'compra' ? param.compras_costo || param.compras_gastos : param.compras_gastos); }
function LC(texto, debito, credito, descripcion, contacto, documento) { const c = cuentaDe(texto); return { cuenta: c.cuenta, cuenta_nombre: c.nombre, contacto: contacto || '', documento: documento || '', descripcion: descripcion || '', debito: r2(debito), credito: r2(credito) }; }
function asientoRecibido(r, param) {
  const total = aPrincipal(r.total, r.moneda, r.tipo_cambio);
  // 3.41: sin decisión de acreditación se acredita solo el IVA (el Selectivo y los específicos del proveedor son costo)
  const acred = aPrincipal(r.monto_impuesto_acreditar !== null && r.monto_impuesto_acreditar !== undefined ? r.monto_impuesto_acreditar : (r.iva !== null && r.iva !== undefined ? r.iva : (r.impuesto || 0)), r.moneda, r.tipo_cambio);
  const gasto = r2(total - acred), con = r.emisor_nombre || '', doc = r.consecutivo || r.clave;
  if (r.tipo_documento === '10') return null;              // recibo de pago del proveedor: documenta un pago, no es una compra
  if (r.tipo_documento === '03')                           // nota de crédito del proveedor: rebaja la deuda, el gasto y el IVA acreditable
    return { tipo: 'Compra', obs: `Nota de crédito recibida ${doc}${con ? ' · ' + con : ''}${ref(r)}`,
      lineas: [L(param, 'cxp', total, 0, 'Menos por pagar al proveedor', con, doc), LC(cuentaCompra(param, r), 0, gasto, r.clasificacion === 'compra' ? 'Rebaja de compra' : 'Rebaja de gasto', con, doc), ...(acred ? [L(param, 'iva_credito', 0, acred, 'Menos IVA acreditable', con, doc)] : [])] };
  return { tipo: 'Compra', obs: `Comprobante recibido ${doc}${con ? ' · ' + con : ''}${r.respuesta === '06' ? ' · aceptado parcialmente' : ''}${ref(r)}`,
    lineas: [LC(cuentaCompra(param, r), gasto, 0, r.clasificacion === 'compra' ? 'Compra de mercadería' : 'Gasto', con, doc), ...(acred ? [L(param, 'iva_credito', acred, 0, 'IVA acreditable', con, doc)] : []), L(param, 'cxp', 0, total, 'Por pagar al proveedor', con, doc)] };
}
// 4.1: lo que ya se cobró de una venta importada (el cobro se hizo en el sistema anterior): sale de cuentas por cobrar
function asientoCobroAnterior(d, param) {
  const pagado = Math.min(+d.pagado || 0, +d.total || 0), m = aPrincipal(pagado, d.moneda, d.tipo_cambio), con = d.receptor_nombre || '', doc = d.consecutivo;
  if (!(m > 0)) return null;
  return { tipo: 'Ingreso', obs: `Cobro en el sistema anterior · ${NOMBRE[d.tipo_documento] || 'Documento'} ${doc}${con ? ' · ' + con : ''}${ref({ moneda: d.moneda, total: pagado, tipo_cambio: d.tipo_cambio })}`,
    lineas: [L(param, 'importados_cobro', m, 0, 'Cobrado en el sistema anterior', con, doc), L(param, 'cxc', 0, m, 'Cobro de la factura', con, doc)] };
}
// 4.1: un comprobante recibido del sistema anterior que ya se pagó allá: sale de cuentas por pagar
function asientoPagoAnterior(r, param) {
  const t = aPrincipal(r.total, r.moneda, r.tipo_cambio), con = r.emisor_nombre || '', doc = r.consecutivo || r.clave;
  if (!(t > 0) || ['03', '10'].includes(r.tipo_documento)) return null;
  return { tipo: 'Egreso', obs: `Pago en el sistema anterior · comprobante ${doc}${con ? ' · ' + con : ''}${ref(r)}`,
    lineas: [L(param, 'cxp', t, 0, 'Pago al proveedor', con, doc), L(param, 'importados_pago', 0, t, 'Pagado en el sistema anterior', con, doc)] };
}
// Línea de caja/bancos: la cuenta contable de la cuenta de Bancos usada en el pago; si no tiene, la de Parametrización según el medio.
function lineaBanco(param, pago, debito, credito, descripcion, contacto, documento) {
  const b = (bancosMock() || []).find(x => x.nombre === pago.cuenta);
  if (b && b.cuenta_contable) { const c = cuentaDe(b.cuenta_contable); return { cuenta: c.cuenta, cuenta_nombre: c.nombre, contacto: contacto || '', documento: documento || '', descripcion: descripcion || '', debito: r2(debito), credito: r2(credito) }; }
  return L(param, (pago.medio_pago || pago.medio) === '01' ? 'caja' : 'bancos', debito, credito, descripcion, contacto, documento);
}
// Diferencia entre lo que entra o sale del banco (tipo de cambio del pago) y lo que cancela la cuenta por cobrar o pagar
// (tipo de cambio de cada factura): ganancia o pérdida por diferencia en cambio (R58)
function lineaCambio(param, dif, con, doc) {
  if (Math.abs(dif) < 1) return [];       // centavos de redondeo entre facturas no son diferencia en cambio
  return [dif > 0 ? L(param, 'dc_ganancia', 0, dif, 'Diferencia en cambio', con, doc) : L(param, 'dc_perdida', -dif, 0, 'Diferencia en cambio', con, doc)];
}
function asientoPago(p, param, porDoc) {
  const monto = aPrincipal(p.monto, p.moneda, p.tipo_cambio), con = p.cliente_nombre || '', doc = p.consecutivo || ('Recibo #' + p.numero);
  const aFacturas = (p.facturas || []).length > 0;
  // cada factura aplicada se cancela al tipo de cambio con que se emitió (si no se conoce, al del pago)
  const cxc = aFacturas ? r2((p.facturas || []).reduce((s, f) => { const d = porDoc && porDoc.get(f.id); return s + aPrincipal(f.monto, d ? d.moneda : p.moneda, d ? d.tipo_cambio : p.tipo_cambio); }, 0)) : monto;
  return { tipo: 'Ingreso', obs: `${p.tipo === 'rep' ? 'Recibo electrónico de pago' : 'Recibo de caja'} #${p.numero}${con ? ' · ' + con : ''}${p.detalles ? ' · ' + p.detalles : ''}${ref({ moneda: p.moneda, total: p.monto, tipo_cambio: p.tipo_cambio })}`,
    lineas: [lineaBanco(param, p, monto, 0, 'Cobro' + (p.cuenta ? ' · ' + p.cuenta : ''), con, doc), L(param, aFacturas ? 'cxc' : 'ventas_ingresos', 0, aFacturas ? cxc : monto, aFacturas ? 'Cancela cuentas por cobrar' : 'Otros ingresos', con, doc), ...(aFacturas ? lineaCambio(param, r2(monto - cxc), con, doc) : [])] };
}
// Compra registrada a mano (sin FEC ni recepción): gasto o inventario + IVA acreditable contra cuentas por pagar (R55)
function asientoCompraManual(c, param) {
  let base = 0, iva = 0;
  for (const l of c.lineas || []) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); base += m; iva += m * (+l.tarifa || 0) / 100; }
  // c.total ya viene neto de retenciones: gasto + IVA = cuentas por pagar (neto) + retenciones por pagar
  const baseP = aPrincipal(base, c.moneda, c.tipo_cambio), ivaP = aPrincipal(iva, c.moneda, c.tipo_cambio), total = aPrincipal(c.total || base + iva, c.moneda, c.tipo_cambio);
  const ret = r2(baseP + ivaP - total), con = c.proveedor || '', doc = c.numero || ('Compra #' + c.id);
  return { tipo: 'Compra', obs: `Factura de compra ${doc}${con ? ' · ' + con : ''} (registrada a mano)${ref({ moneda: c.moneda, total: c.total, tipo_cambio: c.tipo_cambio })}`,
    lineas: [LC(cuentaCompra(param, c), baseP, 0, c.tipo === 'compra' ? 'Compra de mercadería' : 'Gasto', con, doc), ...(ivaP ? [L(param, 'iva_credito', ivaP, 0, 'IVA acreditable', con, doc)] : []), L(param, 'cxp', 0, total, 'Por pagar al proveedor', con, doc), ...(ret >= 1 ? [L(param, 'ret_por_pagar', 0, ret, 'Retenciones por pagar', con, doc)] : [])] };
}
// Pago a proveedor por partes: cuentas por pagar por lo aplicado a facturas (al tipo de cambio de cada una), cada cuenta directa
// con su IVA acreditable, retenciones por pagar y el banco por el neto (R56)
function asientoPagoProveedor(p, param, porCompra) {
  const monto = aPrincipal(p.monto, p.moneda, p.tipo_cambio), con = p.contacto || '', doc = p.numero || ('Pago #' + p.id);
  const aFacturas = (p.facturas || []).length > 0, lineas = [];
  let debitos = 0;
  if (aFacturas) {
    const cxp = r2((p.facturas || []).reduce((s, f) => { const c = porCompra && porCompra.get(f.compra_id); return s + aPrincipal(f.monto, c ? c.moneda : p.moneda, c ? c.tipo_cambio : p.tipo_cambio); }, 0));
    lineas.push(L(param, 'cxp', cxp, 0, 'Cancela cuentas por pagar', con, doc)); debitos += cxp;
  }
  for (const c of p.cuentas || []) {
    const bruto = aPrincipal((+c.valor || 0) * (+c.cantidad || 1), p.moneda, p.tipo_cambio), ivaC = r2(bruto * (+c.impuesto || 0) / 100);
    const cta = cuentaDe(c.cuenta || c.concepto || param.compras_gastos);
    lineas.push({ cuenta: cta.cuenta, cuenta_nombre: cta.nombre, contacto: con, documento: doc, descripcion: c.obs || c.concepto || 'Gasto pagado', debito: r2(bruto), credito: 0 }); debitos += bruto;
    if (ivaC) { lineas.push(L(param, 'iva_credito', ivaC, 0, 'IVA acreditable', con, doc)); debitos += ivaC; }
  }
  if (!lineas.length) { lineas.push(L(param, 'compras_gastos', monto, 0, 'Gasto pagado', con, doc)); debitos += monto; }
  let ret = 0;
  for (const r of p.retenciones || []) { const m = aPrincipal(+r.monto || 0, p.moneda, p.tipo_cambio); if (m > 0) { lineas.push(L(param, 'ret_por_pagar', 0, m, r.nombre || 'Retención por pagar', con, doc)); ret += m; } }
  lineas.push(lineaBanco(param, p, 0, monto, 'Pago' + (p.cuenta ? ' · ' + p.cuenta : ''), con, doc));
  lineas.push(...lineaCambio(param, r2(debitos - ret - monto), con, doc));   // débitos − (retenciones + banco): si sobra débito falta crédito (ganancia)
  return { tipo: 'Egreso', obs: `Pago a proveedor ${doc}${con ? ' · ' + con : ''}${ref({ moneda: p.moneda, total: p.monto, tipo_cambio: p.tipo_cambio })}`, lineas };
}

// Nota de débito a proveedor (Gastos › Notas de débito): rebaja la cuenta por pagar (lo aplicado a facturas), el dinero devuelto
// entra a Bancos y lo no aplicado queda como saldo a favor en cuentas por pagar; contra el gasto y el IVA acreditable.
function asientoNotaDebitoProveedor(nd, param, porCompra) {
  let base = 0, iva = 0;
  for (const l of nd.lineas || []) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); base += m; iva += m * (+l.tarifa || 0) / 100; }
  const baseP = aPrincipal(base, nd.moneda, nd.tipo_cambio), ivaP = aPrincipal(iva, nd.moneda, nd.tipo_cambio), totalDoc = +nd.total || base + iva;
  const devDoc = nd.devolucion ? (+nd.devolucion.monto || 0) : 0, dev = aPrincipal(devDoc, nd.moneda, nd.tipo_cambio), con = nd.proveedor || '', doc = nd.numero || ('Nota #' + nd.id);
  // lo aplicado a cada factura se cancela al tipo de cambio con que se registró esa compra (como en los pagos a proveedores);
  // el resto (saldo a favor) al tipo de cambio de la nota
  let aplicadoDoc = 0, cxp = 0;
  for (const a of nd.facturas || []) { const c = porCompra && porCompra.get(a.compra_id); const m = +a.monto || 0; aplicadoDoc += m; cxp += aPrincipal(m, c ? c.moneda : nd.moneda, c ? c.tipo_cambio : nd.tipo_cambio); }
  const resto = Math.max(0, totalDoc - devDoc - aplicadoDoc);
  cxp = r2(cxp + aPrincipal(resto, nd.moneda, nd.tipo_cambio));
  const lineas = [];
  if (dev > 0) lineas.push(lineaBanco(param, { cuenta: nd.devolucion.cuenta, medio_pago: '04' }, dev, 0, 'Devolución del proveedor · ' + nd.devolucion.cuenta, con, doc));
  if (cxp > 0) lineas.push(L(param, 'cxp', cxp, 0, 'Menos por pagar al proveedor', con, doc));
  const cRef = porCompra ? (nd.facturas || []).slice().sort((x, y) => (+y.monto || 0) - (+x.monto || 0)).map(a => porCompra.get(a.compra_id)).find(Boolean) || null : null;   // 4.3: la compra a la que se refiere (la de mayor monto aplicado)
  lineas.push(LC(cuentaCompra(param, cRef), 0, baseP, 'Rebaja de compra o gasto', con, doc));
  if (ivaP) lineas.push(L(param, 'iva_credito', 0, ivaP, 'Menos IVA acreditable', con, doc));
  lineas.push(...lineaCambio(param, r2(dev + cxp - baseP - ivaP), con, doc));
  return { tipo: 'Compra', obs: `Nota de débito a proveedor ${doc}${con ? ' · ' + con : ''}${ref({ moneda: nd.moneda, total: nd.total, tipo_cambio: nd.tipo_cambio })}`, lineas };
}

// 4.7: cuenta de Parametrización de cada rebajo de la planilla según su categoría (Deducciones e ingresos fijos y ausencias). Antes
// todos iban a «Embargos y pensiones alimentarias por pagar». Préstamos y adelantos son dinero que el empleado le debe a la empresa
// (cuentas por cobrar): el rebajo los ACREDITA. La parte de la licencia de maternidad que paga la CCSS no la paga la empresa: se
// acredita a salarios (rebaja el gasto). Seguros, «otra deducción» y el rebajo escrito a mano van a «Seguros y otros rebajos».
export const CTA_REBAJO = { prestamo: 'rrhh_prestamos', adelanto: 'rrhh_adelantos', embargo: 'rrhh_embargos', pension: 'rrhh_pensiones', asociacion: 'rrhh_asociacion', maternidad: 'rrhh_maternidad_ccss', seguro: 'rrhh_otras_deducciones', otro: 'rrhh_otras_deducciones' };
const TXT_REBAJO = { rrhh_prestamos: 'Cuotas de préstamos a empleados', rrhh_adelantos: 'Rebajo de adelantos de salario', rrhh_embargos: 'Embargos judiciales retenidos', rrhh_pensiones: 'Pensiones alimentarias retenidas', rrhh_asociacion: 'Aporte del trabajador a la asociación solidarista', rrhh_maternidad_ccss: 'Licencia de maternidad: parte que paga la CCSS', rrhh_otras_deducciones: 'Seguros y otros rebajos' };
// categoría desconocida (o sin categoría) → «Seguros y otros rebajos»; solo claves propias del mapa (nunca las heredadas de Object)
const ctaRebajo = c => (Object.prototype.hasOwnProperty.call(CTA_REBAJO, c) ? CTA_REBAJO[c] : 'rrhh_otras_deducciones');
// Rebajos de la planilla por cuenta, en orden fijo: [[clave, monto]]. Lo que no trae detalle (el rebajo escrito a mano en la fila) va a
// «Seguros y otros rebajos»: la suma siempre es el total de otras deducciones de la planilla y el asiento sigue cuadrado.
export function rebajosPlanilla(pl) {
  const suma = {};
  for (const f of pl.filas || []) for (const d of f.detalle_deducciones || []) {
    const k = ctaRebajo(d.categoria);
    if (k !== 'rrhh_otras_deducciones') suma[k] = r2((suma[k] || 0) + (+d.monto || 0));
  }
  const resto = r2((+(pl.totales || {}).otras_deducciones || 0) - Object.values(suma).reduce((s, m) => s + m, 0));
  return [...Object.keys(TXT_REBAJO).filter(k => suma[k]).map(k => [k, suma[k]]), ...(resto ? [['rrhh_otras_deducciones', resto]] : [])];
}
// 4.7: aporte patronal a la asociación solidarista, si la planilla lo trae: dentro de las cargas patronales o de las reservas (una
// clave con «asociacion», «solidarista» o «ase») o en su propio campo de la fila. Va a su gasto contra «Asociación solidarista por pagar».
const esAse = k => /asociaci|solidari|(^|[^a-z])ase([^a-z]|$)/i.test(String(k || ''));
export function aportePatronalAsociacion(f) {
  const de = o => Object.entries(o || {}).reduce((s, [k, v]) => s + (esAse(k) ? +v || 0 : 0), 0);
  const patrono = r2(de(f.patrono)), provision = r2(de(f.provisiones));
  // el campo propio de la fila solo cuenta si el aporte no viene ya en las cargas o en las reservas (no se suma dos veces)
  const aparte = patrono || provision ? 0 : r2(+f.aporte_patronal_asociacion || +f.asociacion_patronal || 0);
  return { patrono, provision, aparte };
}
// 4.7: valor de las vacaciones disfrutadas (Recursos humanos › Vacaciones) que caen en el período de la planilla: se pagaron como
// salario ordinario, así que salen de la provisión de vacaciones (antes el gasto quedaba doble: la reserva y el salario). Días del
// registro dentro del período (proporcionales si el registro sale de él) × salario mensual entre 30, sin pasar del ordinario de la
// fila. Las pagadas en una liquidación (liquidacion_id) ya se cargan en la liquidación. Cada día de vacaciones se carga a una sola
// planilla: la primera que lo cubre en el orden de usoProvisiones (primero las ordinarias); una complementaria del mismo período o
// una planilla vieja que se cruza con otra ya no vuelve a cargar esos días a la provisión.
const _dia = s => Date.parse(String(s || '').slice(0, 10) + 'T00:00:00Z');
// registros de vacaciones por empleado con las fechas ya leídas: se recorren una vez por sincronización y no por cada fila de cada planilla.
// «usados»: los tramos de días del registro que ya tomó alguna planilla en esta sincronización
export function tomadasPorEmpleado(tomadas) {
  const m = new Map();
  for (const v of Array.isArray(tomadas) ? tomadas : []) {
    if (!v || v.liquidacion_id || !(+v.dias > 0)) continue;
    const a = _dia(v.desde), b = _dia(v.hasta || v.desde), k = String(v.empleado_id);
    if (!(b >= a)) continue;
    if (!m.has(k)) m.set(k, []);
    m.get(k).push({ a, b, dias: +v.dias, usados: [] });
  }
  return m;
}
// días del tramo [ini, fin] que ninguna planilla tomó todavía; quedan tomados (los tramos guardados nunca se cruzan entre sí)
export function tomarDias(v, ini, fin) {
  if (!Array.isArray(v.usados)) v.usados = [];
  let libres = [[ini, fin]];
  for (const [x, y] of v.usados) libres = libres.flatMap(([p, q]) => (y < p || x > q ? [[p, q]] : [...(x > p ? [[p, x - 864e5]] : []), ...(y < q ? [[y + 864e5, q]] : [])]));
  v.usados.push(...libres);
  return libres.reduce((s, [p, q]) => s + (q - p) / 864e5 + 1, 0);
}
export function vacacionesEnPlanilla(f, pl, porEmp) {
  const d0 = _dia(pl.desde), d1 = _dia(pl.hasta);
  if (!(d1 >= d0) || !porEmp) return 0;
  let dias = 0;
  for (const v of porEmp.get(String(f.empleado_id)) || []) {
    const ini = Math.max(v.a, d0), fin = Math.min(v.b, d1);
    if (fin >= ini) dias += v.dias * tomarDias(v, ini, fin) / ((v.b - v.a) / 864e5 + 1);
  }
  return r2(Math.min(Math.max(0, +f.ordinario || 0), dias * (+f.salario_mensual || 0) / 30));
}
// Planilla: gasto de salarios, extras, cargas e INS y reserva; pasivos por retenciones, cargas, INS y provisiones; neto a banco (pagada) o salarios por pagar.
// 4.7: uso = usoProvisiones(…): las vacaciones disfrutadas en el período se cargan a la provisión (hasta su saldo) y no a salarios.
function asientoPlanilla(pl, param, uso) {
  const t = pl.totales || {}, r2 = n => Math.round((+n || 0) * 100) / 100, doc = pl.numero, filas = pl.filas || [];
  const extras = r2(filas.reduce((s, f) => s + (+f.extras || 0) + (+f.feriado || 0), 0)), ord = r2((+t.bruto || 0) - extras);   // 4.7: salarios = bruto − extras (cuadra aunque el bruto traiga otro rubro)
  const noSal = r2(filas.reduce((s, f) => s + (+f.no_salariales || 0), 0));   // subsidios de incapacidad y viáticos: gasto que va al neto sin cotizar
  const ase = filas.reduce((s, f) => { const a = aportePatronalAsociacion(f); return { pat: s.pat + a.patrono, prov: s.prov + a.provision, aparte: s.aparte + a.aparte }; }, { pat: 0, prov: 0, aparte: 0 });
  const ins = r2(filas.reduce((s, f) => s + ((f.patrono && +f.patrono.ins_riesgos) || 0), 0)), cargas = r2((+t.total_patronal || 0) - ins - ase.pat), aporteAse = r2(ase.pat + ase.prov + ase.aparte);
  const prov = k => r2(filas.reduce((s, f) => s + ((f.provisiones && +f.provisiones[k]) || 0), 0));
  const pa = prov('aguinaldo'), pv = prov('vacaciones'), pc = prov('cesantia'), otrasProv = r2((+t.total_provisiones || 0) - pa - pv - pc - ase.prov);
  const vacProv = r2(Math.max(0, Math.min(ord, ((uso || {})['pl:' + pl.id] || {}).vacaciones || 0)));   // 4.7: vacaciones disfrutadas cubiertas por la provisión
  const lineas = [L(param, 'rrhh_salarios', r2(ord - vacProv), 0, 'Salarios del período', '', doc)];
  if (vacProv > 0) lineas.push(L(param, 'rrhh_prov_vacaciones', vacProv, 0, 'Vacaciones disfrutadas en el período (de la provisión)', '', doc));
  if (extras) lineas.push(L(param, 'rrhh_extras', extras, 0, 'Horas extra y feriados', '', doc));
  if (noSal) lineas.push(L(param, 'rrhh_salarios', noSal, 0, 'Subsidios y pagos no salariales', '', doc));
  lineas.push(L(param, 'rrhh_cargas', cargas, 0, 'Cargas sociales patronales', '', doc));
  if (aporteAse) lineas.push(L(param, 'rrhh_asociacion_patronal', aporteAse, 0, 'Aporte patronal a la asociación solidarista', '', doc));
  if (ins) lineas.push(L(param, 'rrhh_ins_gasto', ins, 0, 'Riesgos del trabajo', '', doc));
  if (pa) lineas.push(L(param, 'rrhh_gasto_aguinaldo', pa, 0, 'Reserva de aguinaldo', '', doc));
  if (pv) lineas.push(L(param, 'rrhh_gasto_vacaciones', pv, 0, 'Reserva de vacaciones', '', doc));
  if (pc + otrasProv) lineas.push(L(param, 'rrhh_gasto_cesantia', r2(pc + otrasProv), 0, 'Reserva de cesantía y otras', '', doc));
  lineas.push(L(param, 'rrhh_ccss_obrero', 0, +t.total_obrero || 0, 'CCSS retenida al trabajador', '', doc));
  if (+t.renta) lineas.push(L(param, 'rrhh_renta', 0, +t.renta, 'Renta retenida', '', doc));
  for (const [k, m] of rebajosPlanilla(pl)) lineas.push(m > 0 ? L(param, k, 0, m, TXT_REBAJO[k], '', doc) : L(param, k, -m, 0, TXT_REBAJO[k] + ' (ajuste)', '', doc));   // 4.7: cada rebajo en su cuenta
  lineas.push(L(param, 'rrhh_ccss_patronal', 0, cargas, 'Cargas patronales por pagar', '', doc));
  if (aporteAse) lineas.push(L(param, 'rrhh_asociacion', 0, aporteAse, 'Aporte patronal a la asociación por pagar', '', doc));
  if (ins) lineas.push(L(param, 'rrhh_ins_por_pagar', 0, ins, 'INS por pagar', '', doc));
  if (pa) lineas.push(L(param, 'rrhh_prov_aguinaldo', 0, pa, 'Provisión de aguinaldo', '', doc));
  if (pv) lineas.push(L(param, 'rrhh_prov_vacaciones', 0, pv, 'Provisión de vacaciones', '', doc));
  if (pc + otrasProv) lineas.push(L(param, 'rrhh_prov_cesantia', 0, r2(pc + otrasProv), 'Provisión de cesantía y otras', '', doc));
  lineas.push(L(param, 'rrhh_salarios_por_pagar', 0, +t.neto || 0, 'Salarios netos por pagar', '', doc));   // el devengo siempre contra "por pagar"; el pago es otro asiento (R215)
  return { tipo: 'Nómina', obs: `Planilla ${doc} · ${pl.empleados} empleados · ${pl.desde} a ${pl.hasta}`, lineas };
}
function asientoPagoPlanilla(pl, param) {
  const t = pl.totales || {}, doc = pl.numero, neto = +t.neto || 0;
  return { tipo: 'Nómina', obs: `Pago de planilla ${doc}${pl.cuenta ? ' · ' + pl.cuenta : ''}`, lineas: [L(param, 'rrhh_salarios_por_pagar', neto, 0, 'Pago de salarios netos', '', doc), lineaBanco(param, { cuenta: pl.cuenta, medio_pago: '04' }, 0, neto, 'Pago de planilla' + (pl.cuenta ? ' · ' + pl.cuenta : ''), '', doc)] };
}
// ---- provisiones de aguinaldo, vacaciones y cesantía por empleado ----
// Cada planilla las reserva (crédito a rrhh_prov_*). Lo que se paga después (aguinaldo anual, liquidación) se carga primero a la
// provisión de ese empleado hasta su saldo y solo el exceso va a gasto (antes iba todo a gasto: el gasto quedaba duplicado y las
// provisiones crecían para siempre). Los eventos se recorren por fecha; devuelve lo que usa cada pago: {'lq:3': {aguinaldo, …}}.
const r2p = n => Math.round((+n || 0) * 100) / 100;
export function tipoRubro(rubro) {
  return /Aguinaldo/i.test(rubro) ? 'aguinaldo' : /Vacaciones/i.test(rubro) ? 'vacaciones' : /cesant/i.test(rubro) ? 'cesantia' : null;   // el preaviso no se provisiona
}
// 4.7: el monto que el asiento congelado de una planilla debitó de verdad a la provisión de vacaciones, repartido entre sus filas en
// proporción a lo recalculado (si ya no queda nada recalculado, al ordinario de cada fila). Las líneas del asiento no dicen de qué
// empleado es cada parte; así, al menos, el total usado queda igual que en los libros.
export function repartirVacLibros(monto, calc, filas) {
  const m = r2p(Math.max(0, +monto || 0)), pesos = calc.some(x => x > 0) ? calc : filas.map(f => Math.max(0, +(f && f.ordinario) || 0));
  const suma = pesos.reduce((s, x) => s + (x > 0 ? x : 0), 0), ult = pesos.reduce((u, x, i) => (x > 0 ? i : u), -1);
  let resto = m;
  return pesos.map((x, i) => {
    if (!(m > 0) || !(suma > 0) || !(x > 0)) return 0;
    const v = i === ult ? r2p(Math.max(0, resto)) : r2p(m * x / suma);
    resto = r2p(resto - v);
    return v;
  });
}
// 4.7: tomadas (vacaciones_tomadas): las vacaciones disfrutadas en el período de cada planilla usan la provisión de vacaciones del
// empleado (origen 'pl:<id>'), después de la reserva de esa misma planilla; lo que quede es lo que paga la liquidación. Cada día se
// asigna a una sola planilla (de las que llevan asiento): primero las ordinarias, por fecha, y después las complementarias (que
// repiten el período).
// vacLibros: Map 'pl:<id>' → lo que debitó a la provisión de vacaciones el asiento de esa planilla que ya no se reescribe (ajustado a
// mano o de un periodo cerrado): se usa ese monto (0 si no la usó) y no el recalculado con los registros de hoy, que pueden haber
// cambiado después. El aporte patronal a la asociación que venga en las reservas no es provisión.
export function usoProvisiones(planillas, aguinaldos, liquidaciones, tomadas, vacLibros) {
  const ev = [], porEmp = tomadasPorEmpleado(tomadas);
  for (const pl of planillas || []) for (const f of pl.filas || []) {
    const p = f.provisiones || {}, otras = Object.entries(p).filter(([k]) => !['aguinaldo', 'vacaciones', 'cesantia'].includes(k) && !esAse(k)).reduce((s, [, v]) => s + (+v || 0), 0);
    ev.push({ fecha: String(pl.hasta || pl.fecha || ''), orden: 0, emp: f.empleado_id, suma: { aguinaldo: +p.aguinaldo || 0, vacaciones: +p.vacaciones || 0, cesantia: (+p.cesantia || 0) + otras } });
  }
  const enOrden = (planillas || []).filter(pl => pl && pl.id && pl.totales && +pl.totales.bruto > 0).sort((x, y) => (x.complementaria ? 1 : 0) - (y.complementaria ? 1 : 0) || String(x.desde || '').localeCompare(String(y.desde || '')) || String(x.hasta || '').localeCompare(String(y.hasta || '')) || (+x.id || 0) - (+y.id || 0));
  for (const pl of enOrden) {
    const filas = pl.filas || [], o = 'pl:' + pl.id, calc = filas.map(f => vacacionesEnPlanilla(f, pl, porEmp));
    const vac = vacLibros && vacLibros.has(o) ? repartirVacLibros(typeof vacLibros.get === 'function' ? +vacLibros.get(o) || 0 : 0, calc, filas) : calc;
    filas.forEach((f, i) => { if (vac[i] > 0) ev.push({ fecha: String(pl.hasta || pl.fecha || ''), orden: 1, emp: f.empleado_id, origen: o, usa: { vacaciones: vac[i] } }); });
  }
  for (const ag of aguinaldos || []) for (const f of ag.filas || []) ev.push({ fecha: String(ag.fecha || ''), orden: 1, emp: f.empleado_id, origen: 'ag:' + ag.id, usa: { aguinaldo: +f.monto || 0 } });
  for (const lq of liquidaciones || []) {
    const usa = { aguinaldo: 0, vacaciones: 0, cesantia: 0 };
    for (const r of lq.rubros || []) { const t = tipoRubro(r.rubro); if (t && +r.monto > 0) usa[t] += +r.monto; }
    ev.push({ fecha: String(lq.fecha_salida || lq.fecha || ''), orden: 1, emp: lq.empleado_id, origen: 'lq:' + lq.id, usa });
  }
  ev.sort((a, b) => a.fecha.localeCompare(b.fecha) || a.orden - b.orden);
  const saldo = {}, uso = {};
  for (const e of ev) {
    const s = saldo[e.emp] = saldo[e.emp] || { aguinaldo: 0, vacaciones: 0, cesantia: 0 };
    if (e.suma) { for (const k in e.suma) s[k] += e.suma[k]; continue; }
    const u = uso[e.origen] = uso[e.origen] || { aguinaldo: 0, vacaciones: 0, cesantia: 0 };
    for (const k in e.usa) { const x = Math.max(0, Math.min(e.usa[k], s[k])); u[k] = r2p(u[k] + x); s[k] -= x; }
  }
  return uso;
}
const CTA_PROV = { aguinaldo: ['rrhh_prov_aguinaldo', 'rrhh_gasto_aguinaldo'], vacaciones: ['rrhh_prov_vacaciones', 'rrhh_gasto_vacaciones'], cesantia: ['rrhh_prov_cesantia', 'rrhh_gasto_cesantia'] };
// Un monto de aguinaldo, vacaciones o cesantía: débito a la provisión hasta lo que queda y a gasto el resto
function lineasConProvision(param, tipo, monto, disponible, texto, con, doc) {
  const desdeProv = r2p(Math.min(monto, disponible || 0)), exceso = r2p(monto - desdeProv), [prov, gasto] = CTA_PROV[tipo], out = [];
  if (desdeProv > 0) out.push(L(param, prov, desdeProv, 0, texto + ' (de la provisión)', con, doc));
  if (exceso > 0) out.push(L(param, gasto, exceso, 0, texto + (desdeProv > 0 ? ' (exceso sobre la provisión)' : ''), con, doc));
  return out;
}
// 4.7: cuenta de un rebajo de la liquidación (monto negativo): por su categoría si la trae; si no, por su nombre (la CCSS obrera
// sigue en «CCSS por pagar»; una renta, un préstamo o un embargo que se rebaje en la liquidación va a su propia cuenta)
function cuentaRebajoLiquidacion(r) {
  if (r.categoria) return r.categoria === 'ccss' ? 'rrhh_ccss_obrero' : r.categoria === 'renta' ? 'rrhh_renta' : ctaRebajo(r.categoria);
  const n = String(r.rubro || '');
  return /CCSS/i.test(n) ? 'rrhh_ccss_obrero' : /renta/i.test(n) ? 'rrhh_renta' : /pr[eé]stamo/i.test(n) ? 'rrhh_prestamos' : /adelanto/i.test(n) ? 'rrhh_adelantos' : /embargo/i.test(n) ? 'rrhh_embargos' : /pensi[oó]n/i.test(n) ? 'rrhh_pensiones' : esAse(n) ? 'rrhh_asociacion' : 'rrhh_otras_deducciones';
}
function asientoLiquidacion(lq, param, uso) {
  const doc = lq.numero, con = lq.nombre || '', lineas = [], u = { ...((uso || {})['lq:' + lq.id] || {}) };
  const rebajos = {};
  for (const r of lq.rubros || []) {
    if (+r.monto < 0) { const k = cuentaRebajoLiquidacion(r); rebajos[k] = (rebajos[k] || 0) - r.monto; continue; }      // deducción CCSS obrera u otro rebajo: va a su cuenta por pagar (abajo)
    if (!(+r.monto > 0)) continue;
    const t = tipoRubro(r.rubro);
    if (t) { const disp = u[t] || 0; lineas.push(...lineasConProvision(param, t, +r.monto, disp, r.rubro, con, doc)); u[t] = Math.max(0, disp - +r.monto); continue; }
    lineas.push(L(param, /Preaviso/i.test(r.rubro) ? 'rrhh_gasto_cesantia' : 'rrhh_salarios', +r.monto, 0, r.rubro, con, doc));
  }
  for (const k of Object.keys(rebajos)) if (r2p(rebajos[k]) > 0) lineas.push(L(param, k, 0, r2p(rebajos[k]), k === 'rrhh_ccss_obrero' ? 'CCSS retenida en la liquidación' : k === 'rrhh_renta' ? 'Renta retenida en la liquidación' : (TXT_REBAJO[k] || 'Rebajo') + ' en la liquidación', con, doc));
  const pat = r2p(+lq.ccss_patronal || 0);
  if (pat > 0) { lineas.push(L(param, 'rrhh_cargas', pat, 0, 'Cargas patronales de la liquidación', con, doc)); lineas.push(L(param, 'rrhh_ccss_patronal', 0, pat, 'CCSS patronal por pagar', con, doc)); }
  lineas.push(L(param, 'rrhh_liquidaciones', 0, +lq.total || 0, 'Liquidación por pagar (neto)', con, doc));
  return { tipo: 'Nómina', obs: `Liquidación ${doc} · ${con} · salida ${lq.fecha_salida}`, lineas };
}
// 4.7: pago de la liquidación (Recursos humanos › Liquidaciones › Marcar pagada guarda el estado 'Pagada', la cuenta de Bancos y la
// fecha de pago): cancela «Liquidaciones por pagar» contra la cuenta contable de esa cuenta de Bancos (si no tiene, la de
// Parametrización), igual que el pago de la planilla. Antes solo se registraba la salida en Bancos y el pasivo que acredita
// asientoLiquidacion quedaba abierto para siempre. El monto es el mismo neto (lq.total) que acreditó la liquidación y que salió del banco.
function asientoPagoLiquidacion(lq, param) {
  const doc = lq.numero, con = lq.nombre || '', total = +lq.total || 0, cta = lq.cuenta ? ' · ' + lq.cuenta : '';
  return { tipo: 'Nómina', obs: `Pago de liquidación ${doc}${con ? ' · ' + con : ''}${cta}`, lineas: [L(param, 'rrhh_liquidaciones', total, 0, 'Pago de la liquidación (neto)', con, doc), lineaBanco(param, { cuenta: lq.cuenta, medio_pago: '04' }, 0, total, 'Pago de liquidación' + cta, con, doc)] };
}
// 4.7: ¿el pago de cada liquidación ya está en los libros a mano? Antes de esta versión ese pago no tenía asiento y el contador pudo
// registrarlo él mismo; si lo sigue haciendo, no se genera otro (la salida del banco quedaría dos veces en los libros). Cuenta:
// - el asiento de la liquidación ajustado a mano que ya no deja nada en «Liquidaciones por pagar»;
// - lo que los asientos manuales (uno o varios) debitan a «Liquidaciones por pagar» nombrando la liquidación: su número como
//   documento de la línea (LQ-0002, LQ-2 o 0002, sin importar mayúsculas) o escrito en la descripción de la línea o en las
//   observaciones del asiento;
// - lo que debitan a esa cuenta sin nombrar ninguna liquidación pero con el empleado como contacto: se reparte entre sus
//   liquidaciones pagadas, de la más antigua a la más nueva.
// Cuenta como pagada a mano la liquidación pagada cuyo total queda cubierto; si lo que la nombra no alcanza su total, no toma nada
// (queda para otra liquidación del mismo empleado). Devuelve los ids (en texto) de esas liquidaciones.
export function pagosLiquidacionAMano(asientos, liquidaciones, ctaLiq) {
  const hechas = new Set(), todas = (liquidaciones || []).filter(l => l && l.id !== null && l.id !== undefined);
  const txt = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const numDe = s => { const m = /^(?:lq[\s#-]*)?(\d+)$/.exec(txt(s)); return m ? String(+m[1]) : ''; };
  const porNum = new Map(todas.map(l => [numDe(l.numero), l.id]).filter(([k]) => k));
  const citadas = s => [...new Set((txt(s).match(/\blq[\s#-]*\d+/g) || []).map(t => porNum.get(String(+t.replace(/\D/g, '')))).filter(x => x !== undefined))];
  const saldo = ls => r2p(ls.reduce((s, l) => s + (l && l.cuenta === ctaLiq ? (+l.credito || 0) - (+l.debito || 0) : 0), 0));
  const bolsas = new Map();
  for (const a of asientos || []) {
    if (!a || !Array.isArray(a.lineas)) continue;
    if (a.automatico) { if (a.ajustado && String(a.origen || '').startsWith('lq:') && saldo(a.lineas) <= 0.005) hechas.add(String(a.origen).slice(3)); continue; }
    if (!ctaLiq) continue;
    let enObs = null;
    for (const l of a.lineas) {
      if (!l || l.cuenta !== ctaLiq) continue;
      const doc = porNum.get(numDe(l.documento));
      let ids = doc !== undefined ? [doc] : citadas(l.documento);
      if (!ids.length) ids = citadas(l.descripcion);
      if (!ids.length) ids = enObs || (enObs = citadas(a.observaciones));
      if (!ids.length && txt(l.contacto)) ids = todas.filter(x => txt(x.nombre) === txt(l.contacto)).map(x => x.id);
      if (!ids.length) continue;
      const k = ids.map(String).sort().join(','), b = bolsas.get(k) || { ids: new Set(ids), monto: 0 };
      b.monto += (+l.debito || 0) - (+l.credito || 0);
      bolsas.set(k, b);
    }
  }
  const lista = [...bolsas.values()].sort((x, y) => x.ids.size - y.ids.size);
  for (const lq of todas.filter(x => x.estado === 'Pagada' && !hechas.has(String(x.id))).sort((x, y) => (+x.id || 0) - (+y.id || 0))) {
    const mias = lista.filter(b => b.monto > 0.005 && b.ids.has(lq.id));
    let falta = r2p(+lq.total || 0);
    if (mias.reduce((s, b) => s + b.monto, 0) < falta - 0.005) continue;
    for (const b of mias) if (falta > 0.005) { const m = Math.min(falta, b.monto); b.monto -= m; falta = r2p(falta - m); }
    hechas.add(String(lq.id));
  }
  return hechas;
}
// 4.22: pago de las cargas del mes (Recursos humanos › Reportes › Pago de las cargas del mes; registro rrhh_pagos_cargas, que escribe
// el servidor con el monto que él mismo calcula). Cancela los pasivos que dejaron las planillas y las liquidaciones del mes contra
// la cuenta contable de la cuenta de Bancos usada: la CCSS debita «CCSS retenida al trabajador» y «Cargas patronales por pagar» (el
// desglose viene en el pago), el INS «INS por pagar» y la renta «Renta retenida». Los débitos suman siempre el monto que sale del banco.
const NOMBRE_CARGA = { ccss: 'CCSS', ins: 'INS', renta: 'renta retenida' };
export function asientoPagoCargas(c, param) {
  const monto = r2p(c.monto), mes = String(c.mes || ''), doc = 'Cargas ' + mes, cta = c.cuenta ? ' · ' + c.cuenta : '', lineas = [];
  if (c.tipo === 'ccss') {
    const obrero = r2p(Math.min(monto, Math.max(0, +(c.detalle || {}).ccss_obrero || 0))), patronal = r2p(monto - obrero);
    if (obrero > 0) lineas.push(L(param, 'rrhh_ccss_obrero', obrero, 0, 'Pago de la CCSS retenida al trabajador', '', doc));
    if (patronal > 0) lineas.push(L(param, 'rrhh_ccss_patronal', patronal, 0, 'Pago de las cargas patronales', '', doc));
  } else lineas.push(L(param, c.tipo === 'ins' ? 'rrhh_ins_por_pagar' : 'rrhh_renta', monto, 0, c.tipo === 'ins' ? 'Pago del INS (riesgos del trabajo)' : 'Pago de la renta retenida a los salarios', '', doc));
  lineas.push(lineaBanco(param, { cuenta: c.cuenta, medio_pago: '04' }, 0, monto, 'Pago de cargas' + cta, '', doc));
  return { tipo: 'Nómina', obs: `Pago de cargas · ${NOMBRE_CARGA[c.tipo] || c.tipo} de ${mes}${cta}`, lineas };
}
// Pago anual del aguinaldo (Recursos humanos › Aguinaldo): contra la provisión de cada empleado; el exceso a gasto; sale del banco.
function asientoAguinaldo(ag, param, uso) {
  const doc = 'Aguinaldo ' + ag.anio, total = r2p(ag.total), desdeProv = r2p(((uso || {})['ag:' + ag.id] || {}).aguinaldo || 0);
  const lineas = lineasConProvision(param, 'aguinaldo', total, desdeProv, 'Aguinaldo ' + ag.anio, '', doc);
  lineas.push(lineaBanco(param, { cuenta: ag.cuenta, medio_pago: '04' }, 0, total, 'Pago de aguinaldo' + (ag.cuenta ? ' · ' + ag.cuenta : ''), '', doc));
  return { tipo: 'Nómina', obs: `Aguinaldo ${ag.anio} · ${(ag.filas || []).length} empleados · pagado el ${ag.fecha}`, lineas };
}

// ---- activos fijos (Contabilidad › Activos): alta, depreciación por período y baja ----
// nombres del catálogo al momento de sincronizar (sin caché: cambian al renombrar cuentas o al cambiar de empresa)
export function nombresCatalogo() { return Object.fromEntries((mock.get('catalogo', []) || []).map(x => [x.codigo, x.nombre])); }
export function fuentesActivo(a, param, nombres) {
  const nom = nombres || nombresCatalogo();
  const lineaCta = (codigo, debito, credito, descripcion, contacto, documento) => ({ cuenta: codigo, cuenta_nombre: nom[codigo] || '', contacto: contacto || '', documento: documento || '', descripcion: descripcion || '', debito: r2(debito), credito: r2(credito) });
  const out = [], doc = a.referencia || ('Activo #' + a.id), con = a.proveedor || '', nombre = a.nombre || doc;
  const total = aPrincipal(+a.monto_total || 0, a.moneda, a.tipo_cambio), iva = aPrincipal(+a.iva || 0, a.moneda, a.tipo_cambio);
  if (!(total > 0) || !a.cuenta_activo) return out;
  // alta: activo (+ IVA acreditable) contra cuentas por pagar o la cuenta de Bancos con que se pagó
  const alta = [lineaCta(a.cuenta_activo, total, 0, 'Compra del activo ' + nombre, con, doc)];
  if (iva > 0) alta.push(L(param, 'iva_credito', iva, 0, 'IVA acreditable', con, doc));
  alta.push(a.pago === 'banco' && a.cuenta_banco ? lineaBanco(param, { cuenta: a.cuenta_banco, medio_pago: '04' }, 0, r2(total + iva), 'Pago del activo · ' + a.cuenta_banco, con, doc) : L(param, 'cxp', 0, r2(total + iva), 'Por pagar al proveedor', con, doc));
  out.push({ origen: 'act:' + a.id, fecha: fechaAbierta(String(a.fecha_adquisicion || a.fecha_inicio || '').slice(0, 10)), tipo: 'Compra de activo', obs: `Alta del activo ${nombre}${con ? ' · ' + con : ''}${ref({ moneda: a.moneda, total: a.monto_total, tipo_cambio: a.tipo_cambio })}`, lineas: alta });
  // depreciación: un asiento por período completo (mes o año) hasta hoy o hasta la baja; la última cuota ajusta al valor depreciable
  const n = periodosDepreciados(a), c = aPrincipal(cuota(a), a.moneda, a.tipo_cambio), base = aPrincipal(baseDepreciable(a), a.moneda, a.tipo_cambio);
  let acum = 0;
  if (a.cuenta_depreciacion && a.cuenta_gasto) for (let k = 1; k <= Math.min(n, 720); k++) {
    const m = r2(Math.min(c, base - acum)); if (!(m > 0)) break; acum = r2(acum + m);
    out.push({ origen: 'dep:' + a.id + ':' + k, fecha: fechaAbierta(fechaPeriodo(a, k)), tipo: 'Depreciación', obs: `Depreciación ${a.periodo === 'Anual' ? 'anual' : 'mensual'} ${k} · ${nombre}`, lineas: [lineaCta(a.cuenta_gasto, m, 0, 'Depreciación del período ' + k, '', doc), lineaCta(a.cuenta_depreciacion, 0, m, 'Depreciación acumulada', '', doc)] });
  }
  // baja: sale el activo y su depreciación acumulada; el valor en libros pendiente va a la cuenta de gasto del activo
  if (a.fecha_baja && a.cuenta_depreciacion && a.cuenta_gasto) {
    const libros = r2(total - acum), lineas = [];
    if (acum > 0) lineas.push(lineaCta(a.cuenta_depreciacion, acum, 0, 'Depreciación acumulada a la baja', '', doc));
    if (libros > 0) lineas.push(L(param, 'activos_perdida_baja', libros, 0, 'Valor en libros dado de baja (pérdida)', '', doc));
    lineas.push(lineaCta(a.cuenta_activo, 0, total, 'Baja del activo', '', doc));
    out.push({ origen: 'actb:' + a.id, fecha: fechaAbierta(String(a.fecha_baja).slice(0, 10)), tipo: 'Ajuste contable', obs: `Baja del activo ${nombre}${a.baja_motivo ? ' · ' + a.baja_motivo : ''}`, lineas });
  }
  return out;
}

function siguienteCodigo(asientos, prefijo) { return prefijo + '-' + (asientos.filter(a => (a.codigo || '').startsWith(prefijo + '-')).reduce((m, a) => Math.max(m, +String(a.codigo).split('-')[1] || 0), 0) + 1); }
const firma = f => JSON.stringify(f.lineas.map(l => [l.cuenta, l.debito, l.credito]));
// 4.1: el asiento de un documento en otra moneda guarda también sus montos en la moneda del documento (debito_doc, credito_doc y
// moneda_doc): el estado de resultados en colones o en dólares sale exacto, sin los redondeos de pasar por la moneda principal
function dual(gen, moneda) {
  const f = gen(), p = monedas.principal().codigo;
  if (!f || !f.lineas || !moneda || moneda === p) return f;
  let o = null;
  _forzada = moneda;
  try { o = gen(); } catch { o = null; } finally { _forzada = null; }
  if (!o || !o.lineas || o.lineas.length !== f.lineas.length || o.lineas.some((l, i) => l.cuenta !== f.lineas[i].cuenta)) return f;
  return { ...f, moneda_doc: moneda, lineas: f.lineas.map((l, i) => ({ ...l, debito_doc: o.lineas[i].debito, credito_doc: o.lineas[i].credito })) };
}
// Un asiento automático de un periodo cerrado no se reescribe ni se borra: se avisa (igual que un manual, que tampoco se puede tocar)
// 4.23: el de una compra o un gasto (rec: o cm:) tampoco se toca, pero ya no se queda en el aviso: si el documento se eliminó del
// registro, o cambió de clasificación o de cuenta, la diferencia se registra en el mes en curso con UN asiento de ajuste (origen
// 'aj:<origen>', por ejemplo 'aj:rec:12'). Sus líneas son, cuenta por cuenta, lo que hoy daría el origen (nada, si se eliminó) menos
// lo que dice el asiento cerrado: al eliminar es el reverso completo; al reclasificar, el traslado de una cuenta a la otra. Las
// cuentas sin diferencia no llevan línea (sin ninguna diferencia no hay asiento). conDoc: también en la moneda del documento.
export function lineasAjuste(deHoy, cerrado, texto, conDoc) {
  const porCuenta = new Map();
  for (const [lineas, signo] of [[deHoy, 1], [cerrado, -1]]) for (const l of lineas || []) {
    if (!l || !l.cuenta) continue;
    const x = porCuenta.get(l.cuenta) || { l, neto: 0, doc: 0 };
    x.neto += signo * ((+l.debito || 0) - (+l.credito || 0)); x.doc += signo * ((+l.debito_doc || 0) - (+l.credito_doc || 0));
    porCuenta.set(l.cuenta, x);
  }
  const out = [];
  for (const { l, neto, doc } of porCuenta.values()) {
    const n = r2(neto), d = conDoc ? r2(doc) : 0;
    if (!n && !d) continue;
    out.push({ cuenta: l.cuenta, cuenta_nombre: l.cuenta_nombre || '', contacto: l.contacto || '', documento: l.documento || '', descripcion: texto + (l.descripcion ? ' · ' + l.descripcion : ''),
      debito: n > 0 ? n : 0, credito: n < 0 ? -n : 0, ...(conDoc ? { debito_doc: d > 0 ? d : 0, credito_doc: d < 0 ? -d : 0 } : {}) });
  }
  return out;
}

// Genera o actualiza los asientos automáticos. Devuelve {creados, actualizados, eliminados, total}.
export async function sincronizarAutomaticos() {
  // Solo quien puede escribir la contabilidad genera asientos (Solo lectura o un Vendedor solo los ven)
  if (!sesion.puede('contabilidad')) return { creados: 0, actualizados: 0, eliminados: 0, desactivado: true };
  const param = paramContable();
  if (param.asientos_automaticos === false) return { creados: 0, actualizados: 0, eliminados: 0, desactivado: true };
  // (4.23: también 'compras': con una copia vieja de esa lista se crearían o borrarían ajustes aj:cm: de meses cerrados)
  await mock.refrescar(['asientos', 'compras', 'pagos_gastos', 'nd_gastos', 'gastos_rectificaciones', 'planillas', 'liquidaciones', 'rrhh_aguinaldos', 'rrhh_pagos_cargas', 'vacaciones_tomadas', 'bancos', 'activos', 'catalogo'], { sinCorte: true });   // lo último que guardaron otros usuarios
  let docs, recibidos, pagos;
  // si cualquier fuente falla se aborta: antes una consulta caída se tomaba como lista vacía y se borraban los automáticos (R57)
  try { [docs, recibidos, pagos] = await Promise.all([api('/api/comprobantes'), api('/api/recepcion'), api('/api/pagos')]); }
  catch (e) { return { creados: 0, actualizados: 0, eliminados: 0, error: e.message }; }
  const compras = (mock.get('compras', []) || []), porDoc = new Map(docs.map(d => [d.id, d])), porCompra = new Map(compras.map(c => [c.id, c]));
  const porFec = new Map(compras.filter(c => c.fec_id).map(c => [c.fec_id, c]));   // 4.3: la compra registrada de cada FEC (su tipo compra/gasto)
  const fuentes = [];
  // 4.1: los importados de otro sistema (Alegra…) entran solo si se pide en Parametrización y nunca en un mes ya cerrado
  const importadoOk = d => !d.importado_de || (param.contabilizar_importados === true && !periodoCerrado(String(d.fecha_emision || d.creado || '').slice(0, 10)));
  for (const d of docs) if (!['rechazado', 'error', 'generado'].includes(d.estado) && importadoOk(d)) { /* los importados de otro sistema ya están en su contabilidad anterior (3.27) */ const a = dual(() => asientoDoc(d, param, porFec.get(d.id)), d.moneda); if (a) fuentes.push({ origen: 'doc:' + d.id, fecha: String(d.fecha_emision || '').slice(0, 10), ...a }); }
  // la nota de crédito de un proveedor solo se contabiliza si la factura a la que se refiere está aceptada (si se rechazó,
  // sigue sin respuesta o se eliminó, esa compra nunca se contabilizó)
  // 4.23: un aceptado que se quitó del registro de compras y gastos (Gastos › Compras o Gastos › Eliminar) no se contabiliza: su asiento
  // rec: se va en esta sincronización como el de cualquier origen que desaparece (si su mes está cerrado no se toca: se reversa en el
  // mes en curso con el asiento de ajuste aj:, más abajo)
  const registrado = r => r.registrado !== false;
  const aceptadasOk = new Set(recibidos.filter(r => ['05', '06'].includes(r.respuesta) && !['rechazado', 'error'].includes(r.estado_mensaje || '') && registrado(r)).map(r => r.clave));
  const notaValida = r => r.tipo_documento !== '03' || !r.referencia_clave || aceptadasOk.has(r.referencia_clave);
  // 4.1: los del sistema anterior (estado «importado») siguen la misma regla que las ventas importadas
  const recOk = r => r.estado_mensaje !== 'importado' || (param.contabilizar_importados === true && !periodoCerrado(String(r.fecha_emision || '').slice(0, 10)));
  for (const r of recibidos) if (['05', '06'].includes(r.respuesta) && registrado(r) && recOk(r) && !['rechazado', 'error'].includes(r.estado_mensaje || '') && notaValida(r)) { const a = dual(() => asientoRecibido(r, param), r.moneda); if (a) fuentes.push({ origen: 'rec:' + r.id, fecha: String(r.fecha_emision || '').slice(0, 10), ...a }); }
  // 4.1: cobros y pagos que se hicieron en el sistema anterior (las facturas importadas cobradas y los recibidos marcados como pagados)
  for (const d of docs) if (d.importado_de && importadoOk(d) && ['01', '02', '04', '09'].includes(d.tipo_documento) && !['rechazado', 'error', 'generado'].includes(d.estado) && +d.pagado > 0.005) {
    const f = dual(() => asientoCobroAnterior(d, param), d.moneda); if (f) fuentes.push({ origen: 'impc:' + d.id, fecha: String(d.fecha_emision || '').slice(0, 10), ...f });
  }
  for (const r of recibidos) if (r.estado_mensaje === 'importado' && r.pagado_anterior && ['05', '06'].includes(r.respuesta) && registrado(r) && recOk(r)) {
    const f = dual(() => asientoPagoAnterior(r, param), r.moneda); if (f) fuentes.push({ origen: 'recp:' + r.id, fecha: String(r.fecha_emision || '').slice(0, 10), ...f });
  }
  for (const p of pagos) if (+p.monto > 0) fuentes.push({ origen: 'pago:' + p.id, fecha: String(p.fecha || '').slice(0, 10), ...dual(() => asientoPago(p, param, porDoc), p.moneda) });
  // compras registradas a mano (sin FEC ni recepción): gasto + IVA acreditable contra cuentas por pagar (R55)
  // 4.23: la factura registrada desde un comprobante recibido (por su recepcion_id o por su clave) cuenta por sí misma mientras ese
  // recibido no esté aceptado y registrado (en una empresa sin facturación electrónica el XML no se «acepta»); cuando lo está, cuenta
  // el recibido (rec:) y la factura no. La misma regla de resumen.compras_manuales y de las listas Compras y Gastos.
  // La factura de un comprobante que se RECHAZÓ (respuesta 07) tampoco cuenta por sí misma: un rechazado no es una compra (como antes de la 4.23)
  const idsOk = new Set(recibidos.filter(r => r.clave && aceptadasOk.has(r.clave)).map(r => String(r.id)));
  const rechazados = recibidos.filter(r => r.respuesta === '07'), idsNo = new Set([...idsOk, ...rechazados.map(r => String(r.id))]), clavesNo = new Set([...aceptadasOk, ...rechazados.map(r => r.clave)]);
  for (const c of compras) if (c.id && !c.fec_id && !(c.recepcion_id && idsNo.has(String(c.recepcion_id))) && !(c.clave && clavesNo.has(c.clave)) && +c.total > 0) fuentes.push({ origen: 'cm:' + c.id, fecha: String(c.creacion || '').slice(0, 10), ...dual(() => asientoCompraManual(c, param), c.moneda) });
  for (const p of (mock.get('pagos_gastos', []) || [])) if (+p.monto > 0 && p.id) fuentes.push({ origen: 'pg:' + p.id, fecha: String(p.fecha || '').slice(0, 10), ...dual(() => asientoPagoProveedor(p, param, porCompra), p.moneda) });
  for (const nd of (mock.get('nd_gastos', []) || [])) if (nd && nd.id && +nd.total > 0) fuentes.push({ origen: 'nd:' + nd.id, fecha: String(nd.fecha || '').slice(0, 10), ...dual(() => asientoNotaDebitoProveedor(nd, param, porCompra), nd.moneda) });
  // 4.7: el uso de las provisiones se calcula antes del asiento de cada planilla: las vacaciones disfrutadas en su período se cargan a la provisión
  const planillas = mock.get('planillas', []) || [], liquidaciones = mock.get('liquidaciones', []) || [], aguinaldos = mock.get('rrhh_aguinaldos', []) || [];
  // 4.7: planilla cuyo asiento ya no se reescribe (ajustado a mano o de un periodo cerrado): usa la provisión de vacaciones por lo que
  // ese asiento le debitó de verdad (0 si no la usó), aunque los registros de vacaciones hayan cambiado después. Con dos asientos del
  // mismo origen cuenta el que se queda (el ajustado o el más antiguo).
  const ctaVac = cuentaDe(param.rrhh_prov_vacaciones).cuenta, vacLibros = new Map();
  const congeladas = asientosMock().filter(a => a && a.automatico && String(a.origen || '').startsWith('pl:') && (a.ajustado || periodoCerrado(a.fecha)));
  for (const a of congeladas.sort((x, y) => (y.ajustado ? 1 : 0) - (x.ajustado ? 1 : 0) || (+x.id || 0) - (+y.id || 0))) if (!vacLibros.has(a.origen)) vacLibros.set(a.origen, r2p((a.lineas || []).reduce((s, l) => s + (l && l.cuenta === ctaVac ? +l.debito || 0 : 0), 0)));
  const uso = usoProvisiones(planillas, aguinaldos, liquidaciones, mock.get('vacaciones_tomadas', []) || [], vacLibros);
  for (const pl of planillas) if (pl.id && pl.totales && +pl.totales.bruto > 0) {
    fuentes.push({ origen: 'pl:' + pl.id, fecha: String(pl.hasta || pl.fecha || '').slice(0, 10), ...asientoPlanilla(pl, param, uso) });   // devengo en la fecha de la planilla (R215)
    if (pl.estado === 'Pagada' && +pl.totales.neto > 0) fuentes.push({ origen: 'plp:' + pl.id, fecha: String(pl.pagada_en || pl.hasta || pl.fecha || '').slice(0, 10), ...asientoPagoPlanilla(pl, param) });
  }
  // 4.7: la liquidación pagada lleva además el asiento de su pago ('lqp:<id>', uno solo por liquidación), como la planilla pagada
  // ('plp:<id>'); su fecha pasa por fechaAbierta y sigue las reglas de siempre (periodos cerrados y asientos ajustados a mano). Solo la
  // marcada pagada desde esta versión (asiento_pago, que pone Marcar pagada en el mismo guardado): las pagadas antes no tenían ese
  // asiento y el contador pudo registrar su pago a mano de cualquier forma. Tampoco si su pago ya está a mano en los libros.
  const ctaLiq = cuentaDe(param.rrhh_liquidaciones).cuenta, aMano = pagosLiquidacionAMano(asientosMock(), liquidaciones, ctaLiq);
  for (const lq of liquidaciones) if (lq.id && +lq.total > 0) {
    fuentes.push({ origen: 'lq:' + lq.id, fecha: String(lq.fecha_salida || lq.fecha || '').slice(0, 10), ...asientoLiquidacion(lq, param, uso) });
    if (lq.estado === 'Pagada' && lq.asiento_pago === true && !aMano.has(String(lq.id))) fuentes.push({ origen: 'lqp:' + lq.id, fecha: String(lq.pagada_en || lq.fecha_salida || lq.fecha || '').slice(0, 10), ...asientoPagoLiquidacion(lq, param) });
  }
  for (const ag of aguinaldos) if (ag.id && +ag.total > 0) fuentes.push({ origen: 'ag:' + ag.id, fecha: String(ag.fecha || '').slice(0, 10), ...asientoAguinaldo(ag, param, uso) });
  // 4.22: cada pago de las cargas del mes lleva su asiento ('cg:<id>', uno por pago) en la fecha en que se pagó
  for (const c of mock.get('rrhh_pagos_cargas', []) || []) if (c && c.id && NOMBRE_CARGA[c.tipo] && +c.monto > 0 && c.estado === 'Pagado') fuentes.push({ origen: 'cg:' + c.id, fecha: String(c.fecha_pago || '').slice(0, 10), ...asientoPagoCargas(c, param) });
  // activos fijos: alta, depreciación de cada período y baja (solo los marcados «contabilizar»)
  // solo los activos marcados «contabilizar» en su formulario (los registrados antes de esta función no se tocan)
  const nombres = nombresCatalogo();
  for (const ac of activosMock()) if (ac.id && ac.contabilizar === true) fuentes.push(...fuentesActivo(ac, param, nombres));
  // 3.87: un documento fechado en un mes ya cerrado (factura aceptada tarde, cobro con fecha atrasada) se registra en el primer mes
  // abierto, como los activos: el servidor rechaza el asiento de un periodo cerrado y con él todo el lote (no entraba ningún automático)
  for (const f of fuentes) f.fecha = fechaAbierta(f.fecha);
  let asientos = asientosMock();
  // Si dos usuarios generaron a la vez el mismo automático, queda uno (el ajustado o el más antiguo)
  const vistos = new Map(); let duplicados = 0;
  for (const a of asientos.slice().sort((x, y) => (y.ajustado ? 1 : 0) - (x.ajustado ? 1 : 0) || x.id - y.id)) {
    if (!a.automatico || !a.origen) continue;
    if (vistos.has(a.origen) && !a.ajustado && !periodoCerrado(a.fecha)) { a._duplicado = true; duplicados++; } else vistos.set(a.origen, a);   // 3.87: el de un periodo cerrado se queda
  }
  if (duplicados) asientos = asientos.filter(a => !a._duplicado);
  const porOrigen = new Map(asientos.filter(a => a.automatico && a.origen).map(a => [a.origen, a]));
  // Solo se revisan (y borran) los automáticos cuyo origen este rol puede leer: un Contador sin RRHH no ve planillas ni
  // liquidaciones, y sin esto borraría sus asientos.
  const leibles = new Set(['doc', 'rec', 'pago', 'act', 'dep', 'actb', 'impc', 'recp']);
  if (sesion.puede('gastos') || sesion.puede('ver_todo')) { leibles.add('pg'); leibles.add('cm'); leibles.add('nd'); }
  if (sesion.puede('rrhh')) { leibles.add('pl'); leibles.add('plp'); leibles.add('lq'); leibles.add('lqp'); leibles.add('ag'); leibles.add('cg'); }
  leibles.add('aj');
  let creados = 0, actualizados = 0, bloqueados = 0;
  const vivos = new Set();
  // 4.23: compras y gastos de un mes con el periodo contable cerrado. El asiento cerrado (rec: o cm:, sin ajustar a mano) no se toca
  // ni se avisa: lo que cambió (el documento se eliminó del registro, o cambió de clasificación o de cuenta) va en su asiento de
  // ajuste aj:<origen>, uno por documento, con la fecha de la rectificación más reciente de ese documento (si no hay, hoy) llevada al
  // primer mes abierto. Sigue las reglas de cualquier automático: si la diferencia vuelve a cero (el documento se registró de nuevo
  // tal como estaba) deja de tener origen y se quita si su mes está abierto. Quien no puede leer el origen (cm sin el permiso de
  // gastos) no genera ni borra su ajuste. Los importados de otro sistema siguen como antes (su regla ya mira el mes cerrado), y
  // también el asiento cerrado que el contador ajustó a mano.
  // El ajuste es solo para lo que se rectificó: el documento ya no está en el registro, o tiene una rectificación anotada en
  // 'gastos_rectificaciones', o ya lleva un ajuste. El asiento cerrado que cambiaría por otra causa (por ejemplo, se cambió una cuenta
  // en Parametrización) sigue con el aviso de siempre, sin ajuste: no se trasladan los saldos de los meses cerrados.
  // El ajuste que quedó en un mes que después también se cerró tampoco se toca y cuenta como parte de lo cerrado: lo que cambie
  // después (el documento se registró de nuevo, o cambió otra vez) va en el siguiente de la cadena, 'aj:<origen>:2', ':3'…
  const cubiertos = new Set(), porFuente = new Map(fuentes.map(f => [f.origen, f]));
  const rectificaciones = (mock.get('gastos_rectificaciones', []) || []).filter(x => x && typeof x === 'object');
  const importados = new Set(recibidos.filter(r => r.estado_mensaje === 'importado').map(r => 'rec:' + r.id));
  const cadenas = new Map();
  for (const [origen, a] of porOrigen) { const p = String(origen).split(':'); if (p[0] === 'aj') cadenas.set(p[1] + ':' + p[2], [...(cadenas.get(p[1] + ':' + p[2]) || []), a]); }
  for (const [origen, ex] of porOrigen) {
    const [pref, id] = String(origen).split(':');
    // un ajuste ya guardado ('aj:cm:5': su segunda parte es el prefijo de su origen) que este rol no puede revisar se deja como está
    if (pref === 'aj') { if (!leibles.has(id)) vivos.add(origen); continue; }
    if ((pref !== 'rec' && pref !== 'cm') || ex.ajustado || !leibles.has(pref) || importados.has(origen) || !periodoCerrado(ex.fecha)) continue;
    const f = porFuente.get(origen), cadena = cadenas.get(origen) || [], fijos = cadena.filter(a => periodoCerrado(a.fecha));
    const ultima = rectificaciones.filter(x => String(pref === 'rec' ? x.recibido_id : x.compra_id) === id).map(x => String(x.fecha || '').slice(0, 10)).sort().pop();
    if (f && !ultima && !cadena.length) continue;
    for (const a of fijos) cubiertos.add(a.origen);
    const cerradas = [...(ex.lineas || []), ...fijos.flatMap(a => a.lineas || [])];
    const texto = !f ? 'Reverso por rectificación' : fijos.length ? 'Ajuste por rectificación' : 'Ajuste por reclasificación';
    const conDoc = !!ex.moneda_doc && (!f || f.moneda_doc === ex.moneda_doc) && cerradas.every(l => l && l.debito_doc !== undefined);
    const lineas = lineasAjuste(f ? f.lineas : [], cerradas, texto, conDoc);
    // con el aviso de siempre, sin ajuste: lo que solo cambió por el tipo de cambio del día (en la moneda del documento los montos
    // son los mismos: no es una rectificación) y una diferencia que no cuadra (el asiento de ajuste cuadra siempre)
    if (f && conDoc && lineas.length && lineas.every(l => !l.debito_doc && !l.credito_doc)) continue;
    if (Math.abs(lineas.reduce((s, l) => s + l.debito - l.credito, 0)) >= 0.005) continue;
    cubiertos.add(origen);
    if (!lineas.length) continue;
    // va en el ajuste de la cadena que sigue en un mes abierto; si todos quedaron en meses cerrados, en uno nuevo
    const abierto = cadena.find(a => !periodoCerrado(a.fecha));
    let sufijo = abierto ? String(abierto.origen).slice(('aj:' + origen).length) : '';
    for (let n = 2; !abierto && porOrigen.has('aj:' + origen + sufijo); n++) sufijo = ':' + n;
    const doc = ((ex.lineas || []).find(l => l && l.documento) || {}).documento || origen;
    fuentes.push({ origen: 'aj:' + origen + sufijo, fecha: fechaAbierta(ultima || hoy()), tipo: ex.tipo || 'Compra', obs: `${texto} · ${doc} de ${mesLegible(String(ex.fecha || '').slice(0, 7))}`, lineas, ...(conDoc ? { moneda_doc: ex.moneda_doc } : {}) });
  }
  for (const f of fuentes) {
    vivos.add(f.origen);
    if (cubiertos.has(f.origen)) continue;
    const ex = porOrigen.get(f.origen);
    if (!ex) { asientos.push({ id: mock.nextId(asientos, 'asientos'), codigo: siguienteCodigo(asientos, 'AU'), fecha: f.fecha, tipo: f.tipo, numeracion: 'AU', observaciones: f.obs, lineas: f.lineas, ...(f.moneda_doc ? { moneda_doc: f.moneda_doc } : {}), automatico: true, origen: f.origen, firma: firma(f), ajustado: false }); creados++; }
    else if (!ex.ajustado && (ex.firma !== firma(f) || (f.moneda_doc || null) !== (ex.moneda_doc || null))) { if (periodoCerrado(ex.fecha)) { bloqueados++; continue; } ex.lineas = f.lineas; ex.fecha = f.fecha; ex.observaciones = f.obs; ex.firma = firma(f); if (f.moneda_doc) ex.moneda_doc = f.moneda_doc; else delete ex.moneda_doc; actualizados++; }   // 4.1: también para guardar la moneda del documento
  }
  const antes = asientos.length;
  asientos = asientos.filter(a => !(a.automatico && a.origen && !a.ajustado && leibles.has(String(a.origen).split(':')[0]) && !vivos.has(a.origen) && !periodoCerrado(a.fecha)));
  const eliminados = antes - asientos.length + duplicados;
  // ajustados cuyo origen desapareció (comprobante rechazado o registro eliminado) y automáticos de periodos cerrados sin
  // origen: se avisan, no se borran (R216). 4.23: menos las compras y los gastos de un mes cerrado que ya llevan su asiento de ajuste
  const huerfanos = asientos.filter(a => a.automatico && a.origen && leibles.has(String(a.origen).split(':')[0]) && !vivos.has(a.origen) && !cubiertos.has(a.origen) && (a.ajustado || periodoCerrado(a.fecha))).map(a => a.id);
  if (creados || actualizados || eliminados) await mock.set('asientos', asientos);
  return { creados, actualizados, eliminados, bloqueados, total: asientos.length, huerfanos };
}

export function resumenSync(r) {
  if (!r || r.desactivado || r.error) return '';
  const partes = []; if (r.creados) partes.push(r.creados + ' nuevo' + (r.creados === 1 ? '' : 's')); if (r.actualizados) partes.push(r.actualizados + ' actualizado' + (r.actualizados === 1 ? '' : 's')); if (r.eliminados) partes.push(r.eliminados + ' eliminado' + (r.eliminados === 1 ? '' : 's'));
  return partes.length ? 'Asientos automáticos: ' + partes.join(', ') : '';
}
