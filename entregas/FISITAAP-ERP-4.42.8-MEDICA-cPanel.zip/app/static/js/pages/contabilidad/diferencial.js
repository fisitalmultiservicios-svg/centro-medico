// Contabilidad › Diferencial cambiario (3.8): revalúa a la fecha los saldos en otra moneda (cuentas de Bancos en dólares y las
// cuentas que se agreguen a mano: clientes o proveedores en dólares) al tipo de cambio del día y genera el asiento DC con la
// ganancia o pérdida por diferencia en cambio contra las cuentas de Parametrización.
import { money, fmt, fecha, toast, mock, hoy, monedas } from '../../api.js';
import { sesion } from '../../app.js';
import { planCuentas } from './catalogo.js';
import { cargarAsientos, planConUsadas, saldos, esDeudora, periodoCerrado } from './_mayor.js';
import { paramContable, cuentaDe } from './parametros.js';
import { aPrincipal } from './automaticos.js';

const r2 = n => Math.round((+n || 0) * 100) / 100;

export default {
  props: ['params'],
  data() { return { fecha: hoy(), tc: +monedas.tc('USD') || 0, moneda: 'USD', filas: [], asientos: [], plan: [], cargando: true, manual: null, param: paramContable() }; },
  computed: {
    puede() { return sesion.puede('contabilidad'); },
    monP() { return monedas.principal().codigo; },
    saldosContables() { return this.plan.length ? saldos(this.asientos, this.plan, null, this.fecha) : {}; },
    calculo() {
      return this.filas.map(f => {
        const o = this.saldosContables[f.cuenta] || null, contable = o ? o.final : 0;
        const valor = r2(aPrincipal(+f.saldo_me || 0, f.moneda, this.tc)), dif = r2(valor - contable), deudora = esDeudora(f.cuenta);
        // deudora (banco, cliente): vale más = ganancia; acreedora (proveedor): vale más = pérdida
        const ganancia = deudora ? dif > 0 : dif < 0;
        return { ...f, nombre: o ? o.nombre : (this.plan.find(c => c.codigo === f.cuenta) || {}).nombre || '', contable, valor, dif, deudora, ganancia, tiene: !!o };
      });
    },
    incluidas() { return this.calculo.filter(f => f.incluir && Math.abs(f.dif) >= 0.01); },
    totales() { const g = r2(this.incluidas.filter(f => f.ganancia).reduce((s, f) => s + Math.abs(f.dif), 0)), p = r2(this.incluidas.filter(f => !f.ganancia).reduce((s, f) => s + Math.abs(f.dif), 0)); return { ganancia: g, perdida: p, neto: r2(g - p) }; },
    anteriores() { return this.asientos.filter(a => String(a.codigo || '').startsWith('DC-')).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || b.id - a.id).slice(0, 12); },
    cuentasPlan() { return this.plan.filter(c => c.hoja && ['1', '2'].includes(c.raiz)); },
    cerrado() { return periodoCerrado(this.fecha); },
  },
  methods: {
    money, fmt, fecha,
    traerTc() { const t = +monedas.tc('USD') || 0; if (!t) return toast('No hay tipo de cambio cargado: revise Configuración › Monedas', 'err'); this.tc = t; },
    async cargar() {
      this.cargando = true;
      try { this.asientos = await cargarAsientos(); this.plan = planConUsadas(this.asientos, planCuentas()); } catch (e) { toast(e.message, 'err'); }
      // cuentas de Bancos en otra moneda: saldo = inicial + movimientos (en su moneda)
      const bancos = (mock.get('bancos', []) || []).filter(b => b && b.nombre && (b.moneda || 'CRC') !== this.monP), movs = mock.get('movimientos', []) || [];
      const bc = cuentaDe(this.param.bancos);
      this.filas = bancos.map(b => { const saldo = r2((+b.saldo_inicial || 0) + movs.filter(m => m.banco_id === b.id).reduce((s, m) => s + (+m.monto || 0), 0)); const cc = b.cuenta_contable ? cuentaDe(b.cuenta_contable) : bc; return { id: 'b' + b.id, origen: 'Bancos · ' + b.nombre, moneda: b.moneda, saldo_me: saldo, cuenta: cc.cuenta, incluir: true, manual: false }; });
      this.cargando = false;
    },
    agregarManual() { this.manual = { cuenta: '', saldo_me: null, moneda: this.moneda, nota: '' }; },
    confirmarManual() { const m = this.manual; if (!m.cuenta) return toast('Elija la cuenta contable', 'err'); if (this.filas.some(f => f.cuenta === m.cuenta)) return toast('Esa cuenta ya está en la lista', 'err'); this.filas.push({ id: 'm' + Date.now(), origen: (m.nota || 'Saldo en ' + m.moneda).trim(), moneda: m.moneda, saldo_me: r2(m.saldo_me), cuenta: m.cuenta, incluir: true, manual: true }); this.manual = null; },
    quitar(f) { this.filas = this.filas.filter(x => x.id !== f.id); },
    generar() {
      if (!this.incluidas.length) return toast('No hay diferencias que ajustar', 'err');
      if (this.cerrado) return toast('El período de ' + this.fecha + ' está cerrado', 'err');
      if (!(this.tc > 0)) return toast('Indique el tipo de cambio', 'err');
      if (!mock.puedeGuardar()) return;
      const g = cuentaDe(this.param.dc_ganancia), p = cuentaDe(this.param.dc_perdida), lineas = [];
      for (const f of this.incluidas) {
        const m = r2(Math.abs(f.dif)), desc = 'Revaluación ' + f.moneda + ' ' + fmt(f.saldo_me) + ' × ' + fmt(this.tc, 2) + ' · ' + f.origen;
        const sube = f.deudora ? f.dif > 0 : f.dif < 0;   // ¿la cuenta se debita?  deudora que vale más / acreedora que vale menos
        lineas.push({ cuenta: f.cuenta, cuenta_nombre: f.nombre, contacto: '', documento: '', descripcion: desc, debito: sube ? m : 0, credito: sube ? 0 : m });
        if (f.ganancia) lineas.push({ cuenta: g.cuenta, cuenta_nombre: g.nombre, contacto: '', documento: '', descripcion: 'Ganancia por diferencia en cambio · ' + f.origen, debito: 0, credito: m });
        else lineas.push({ cuenta: p.cuenta, cuenta_nombre: p.nombre, contacto: '', documento: '', descripcion: 'Pérdida por diferencia en cambio · ' + f.origen, debito: m, credito: 0 });
      }
      let a = null;
      mock.actualizar('asientos', l => { const lista = Array.isArray(l) ? l : []; const n = lista.filter(x => String(x.codigo || '').startsWith('DC-')).reduce((mx, x) => Math.max(mx, +String(x.codigo).split('-')[1] || 0), 0) + 1; a = { id: mock.nextId(lista, 'asientos'), codigo: 'DC-' + n, fecha: this.fecha, tipo: 'Diferencial cambiario', numeracion: 'DC', observaciones: 'Diferencial cambiario al ' + fecha(this.fecha) + ' · tipo de cambio ' + fmt(this.tc, 2), lineas, diferencial: { fecha: this.fecha, tc: this.tc } }; return [...lista, a]; }, []);
      toast('Asiento ' + a.codigo + ' generado: ' + (this.totales.neto >= 0 ? 'ganancia ' : 'pérdida ') + money(Math.abs(this.totales.neto), this.monP), 'ok');
      this.cargar();
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Diferencial cambiario" sub="Revalúa a la fecha los saldos en dólares (Bancos y las cuentas que agregue) al tipo de cambio del día y genera el asiento DC con la ganancia o pérdida por diferencia en cambio." :crumbs="[{label:'Contabilidad'},{label:'Diferencial cambiario'}]">
      <button class="btn" @click="generar" :disabled="!puede || !incluidas.length">Generar asiento DC</button>
    </PageHead>
    <div class="card">
      <div class="grid cols-3">
        <Field label="Fecha de revaluación" req><input type="date" v-model="fecha"></Field>
        <Field label="Tipo de cambio (₡ por US$)" req><div class="row" style="gap:6px"><input type="number" step="0.01" min="0" v-model.number="tc" style="flex:1"><button class="btn sm sec" @click="traerTc" title="Tipo de cambio cargado en Configuración › Monedas">Del día</button></div></Field>
        <div class="totals" style="align-self:end;margin:0"><div><span>Ganancia</span><b>{{money(totales.ganancia, monP)}}</b></div><div><span>Pérdida</span><b>{{money(totales.perdida, monP)}}</b></div><div class="total"><span>Neto</span><b :style="totales.neto < 0 ? 'color:var(--danger)' : ''">{{money(totales.neto, monP)}}</b></div></div>
      </div>
      <p class="small" style="margin:6px 0 0;color:var(--danger)" v-if="cerrado">El período de esa fecha está cerrado: elija otra fecha.</p>
    </div>
    <div class="card">
      <div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">Saldos a revaluar</h3><button class="btn sm sec" @click="agregarManual" :disabled="!puede">+ Otra cuenta en dólares</button></div>
      <Empty v-if="!filas.length && !cargando" icon="💱" title="Nada que revaluar" text="No hay cuentas de Bancos en dólares. Agregue a mano una cuenta contable con su saldo en dólares (por ejemplo, clientes o proveedores en dólares)."></Empty>
      <div class="table-wrap" v-else><table class="tbl"><thead><tr><th></th><th>Origen</th><th>Cuenta contable</th><th class="num">Saldo en moneda</th><th class="num">Valor al tipo de cambio</th><th class="num">Saldo contable</th><th class="num">Diferencia</th><th>Efecto</th><th></th></tr></thead>
        <tbody><tr v-for="f in calculo" :key="f.id" :style="f.incluir ? '' : 'opacity:.5'">
          <td><input type="checkbox" v-model="f.incluir"></td><td>{{f.origen}}</td><td><span class="mono small">{{f.cuenta}}</span> <span class="small">{{f.nombre}}</span><div class="small" style="color:var(--danger)" v-if="!f.tiene">Sin saldo contable: revise la cuenta</div></td>
          <td class="num">{{money(f.saldo_me, f.moneda)}}</td><td class="num">{{money(f.valor, monP)}}</td><td class="num">{{money(f.contable, monP)}}</td><td class="num" :style="Math.abs(f.dif) >= 0.01 ? (f.ganancia ? 'color:var(--ok)' : 'color:var(--danger)') : ''"><b>{{money(f.dif, monP)}}</b></td>
          <td><span v-if="Math.abs(f.dif) < 0.01" class="badge">Sin cambio</span><span v-else :class="f.ganancia ? 'badge ok' : 'badge danger'">{{f.ganancia ? 'Ganancia' : 'Pérdida'}}</span></td><td><button class="btn icon" v-if="f.manual" @click="quitar(f)">✕</button></td>
        </tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0">Las cuentas de Bancos en otra moneda usan su cuenta contable (o la de Parametrización › Bancos) y su saldo real (inicial más movimientos). La diferencia se registra contra «{{param.dc_ganancia}}» o «{{param.dc_perdida}}» (Configuración › Contabilidad › Parametrización). Revise que la fecha sea la del cierre del mes.</p>
    </div>
    <div class="card" v-if="anteriores.length"><h3 style="margin:0 0 8px">Asientos de diferencial anteriores</h3>
      <table class="tbl"><thead><tr><th>Asiento</th><th>Fecha</th><th>Observaciones</th><th class="num">Monto</th></tr></thead><tbody><tr v-for="a in anteriores" :key="a.id"><td class="mono"><a :href="'#/contabilidad/asientos/' + a.id">{{a.codigo}}</a></td><td>{{fecha(a.fecha)}}</td><td class="small">{{a.observaciones}}</td><td class="num">{{money((a.lineas||[]).reduce((s,l)=>s+(+l.debito||0),0), monP)}}</td></tr></tbody></table>
    </div>
    <Modal v-if="manual" title="Otra cuenta en dólares" @close="manual=null">
      <div class="grid cols-2">
        <Field label="Cuenta contable" req style="grid-column:1/-1"><select v-model="manual.cuenta"><option value="">— Elegir —</option><option v-for="c in cuentasPlan" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
        <Field label="Saldo en dólares a la fecha" req><input type="number" step="0.01" v-model.number="manual.saldo_me"></Field>
        <Field label="Nombre para el asiento"><input v-model="manual.nota" maxlength="60" placeholder="Clientes en dólares, proveedor X…"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="manual=null">Cancelar</button><button class="btn" @click="confirmarManual">Agregar</button></template>
    </Modal>
  </div>`,
};
