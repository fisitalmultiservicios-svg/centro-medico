// Parametrización contable: cuentas por defecto (Configuración › Contabilidad › Parametrización) que usan los asientos automáticos.
import { mock } from '../../api.js';

export const DEF = {
  ventas_ingresos: '4.1.01 Ventas', ventas_devoluciones: '4.1.02 Devoluciones en ventas',
  inv_inventario: '1.1.06.01 Inventario de mercancías', inv_ajustes: '5.1.01.02 Ajustes al inventario',
  cxc: '1.1.02.01.01 Cuentas por cobrar clientes nacionales', dev_clientes: '2.1.01.03.01 Devoluciones de clientes',
  cxp: '2.1.01.01.01 Cuentas por pagar a proveedores nacionales', dev_proveedores: '1.1.02.04.06 Devoluciones a proveedores',
  iva_debito: '2.1.04.01.01.01 IVA débito fiscal', iva_credito: '1.1.04.01.01.01 IVA crédito fiscal',
  otros_impuestos: '2.1.04.01.03 Otro tipo de impuesto por pagar',   // 3.41: Selectivo de Consumo e impuestos específicos cobrados
  compras_gastos: '6.2.02.20 Otros gastos generales', compras_costo: '5.1.01.01 Costos del inventario',   // 4.3: gasto vs compra de mercadería (costo de ventas)
  caja: '1.1.01.01.02 Caja general', bancos: '1.1.01.02.01.01 Banco Nacional',
  ganancias: '3.4 Ganancias acumuladas', resultado: '3.3.01 Utilidad del ejercicio', ajuste_bancos: '3.6.01 Ajustes iniciales en bancos', ajuste_inventario: '3.6.02 Ajustes iniciales en inventario',
  dc_ganancia: '4.2.02.01 Ganancia por diferencia en cambio', dc_perdida: '6.4.02 Pérdida por diferencia en cambio',
  ret_por_pagar: '2.1.06.01 Retenciones por pagar',   // retenciones hechas a proveedores (2 % IVA, renta) pendientes de pagar a Hacienda
  activos_perdida_baja: '6.4.04 Pérdida por disposición de activos',   // valor en libros de un activo dado de baja
  aprox_ingresos: '4.2.02.02 Ajustes por aproximaciones en cálculos', aprox_gastos: '6.4.03 Ajustes por aproximaciones en cálculos',
  rrhh_salarios: '6.2.01.01 Sueldos y salarios', rrhh_extras: '6.2.01.02 Horas extras', rrhh_cargas: '6.2.01.03 Gastos por cargas sociales', rrhh_ins_gasto: '6.2.01.09 Seguro de riesgos del trabajo (INS)',
  rrhh_gasto_aguinaldo: '6.2.01.08 Aguinaldo', rrhh_gasto_vacaciones: '6.2.01.06 Vacaciones', rrhh_gasto_cesantia: '6.2.01.07 Cesantia',
  rrhh_salarios_por_pagar: '2.1.02.01.01.01 Salarios por pagar', rrhh_liquidaciones: '2.1.02.01.01.02 Liquidaciones laborales por pagar', rrhh_ccss_obrero: '2.1.02.02.01 Retención laboral CCSS por pagar',
  rrhh_renta: '2.1.02.02.02 Impuesto de renta al salario por pagar', rrhh_ccss_patronal: '2.1.02.02.04 Cargas sociales patronales CCSS por pagar', rrhh_ins_por_pagar: '2.1.02.02.05 INS riesgos del trabajo por pagar',
  rrhh_otras_deducciones: '2.1.06.02 Otro tipo de retención por pagar', rrhh_prov_aguinaldo: '2.1.02.01.02 Aguinaldo por pagar (provisión)', rrhh_prov_vacaciones: '2.1.02.01.03 Vacaciones por pagar (provisión)', rrhh_prov_cesantia: '2.1.02.01.04 Cesantía por pagar (provisión)',
  // 4.7: cada rebajo de la planilla en su cuenta (antes todos iban a «Embargos y pensiones alimentarias por pagar»); préstamos y adelantos son cuentas por cobrar al empleado
  rrhh_embargos: '2.1.02.02.06 Embargos y pensiones alimentarias por pagar', rrhh_pensiones: '2.1.02.02.06 Embargos y pensiones alimentarias por pagar', rrhh_asociacion: '2.1.02.02.03 Asociación solidaristas por pagar',
  rrhh_prestamos: '1.1.02.04.01 Cuentas por cobrar empleados', rrhh_adelantos: '1.1.02.03.02 Avances y anticipos a empleados',
  rrhh_maternidad_ccss: '6.2.01.01 Sueldos y salarios', rrhh_asociacion_patronal: '6.2.01.03 Gastos por cargas sociales',
  asientos_automaticos: true,
  contabilizar_importados: false,
  importados_cobro: '1.1.01.01.02 Caja general', importados_pago: '1.1.01.02.01.01 Banco Nacional',   // 4.1: dónde entraron los cobros y salieron los pagos del sistema anterior   // 4.1: las ventas traídas de otro sistema (Alegra…) también generan asientos
};

export const SECCIONES = [
  ['Ventas', [['ventas_ingresos', 'Ingresos'], ['ventas_devoluciones', 'Devoluciones']]],
  ['Impuestos', [['iva_debito', 'IVA débito fiscal (cobrado en ventas)'], ['iva_credito', 'IVA crédito fiscal (acreditable en compras)'], ['otros_impuestos', 'Selectivo de Consumo e impuestos específicos (cobrados en ventas)']]],
  ['Compras y pagos', [['compras_costo', 'Compras de mercadería para vender (costo de ventas)'], ['compras_gastos', 'Gastos del negocio (comprobantes clasificados como gasto)'], ['caja', 'Caja (pagos en efectivo)'], ['bancos', 'Bancos (transferencia, tarjeta, SINPE)']]],
  ['Inventario', [['inv_inventario', 'Inventario'], ['inv_ajustes', 'Ajustes de inventario']]],
  ['Clientes y proveedores', [['cxc', 'Cuentas por cobrar'], ['dev_clientes', 'Devoluciones de clientes'], ['cxp', 'Cuentas por pagar'], ['dev_proveedores', 'Devoluciones a proveedores']]],
  ['Patrimonio', [['ganancias', 'Ganancias acumuladas'], ['resultado', 'Utilidad o pérdida del ejercicio'], ['ajuste_bancos', 'Ajustes saldos iniciales de bancos'], ['ajuste_inventario', 'Ajustes saldos iniciales de inventarios']]],
  ['Recursos humanos', [['rrhh_salarios', 'Sueldos y salarios (gasto)'], ['rrhh_extras', 'Horas extra (gasto)'], ['rrhh_cargas', 'Cargas sociales patronales (gasto)'], ['rrhh_ins_gasto', 'Riesgos del trabajo INS (gasto)'], ['rrhh_gasto_aguinaldo', 'Aguinaldo (gasto)'], ['rrhh_gasto_vacaciones', 'Vacaciones (gasto)'], ['rrhh_gasto_cesantia', 'Cesantía (gasto)'], ['rrhh_salarios_por_pagar', 'Salarios por pagar'], ['rrhh_liquidaciones', 'Liquidaciones por pagar'], ['rrhh_ccss_obrero', 'Retención CCSS del trabajador por pagar'], ['rrhh_renta', 'Renta al salario por pagar'], ['rrhh_ccss_patronal', 'Cargas patronales CCSS por pagar'], ['rrhh_ins_por_pagar', 'INS por pagar'], ['rrhh_prov_aguinaldo', 'Provisión de aguinaldo'], ['rrhh_prov_vacaciones', 'Provisión de vacaciones'], ['rrhh_prov_cesantia', 'Provisión de cesantía']]],
  // 4.7: cada rebajo de la planilla y de la liquidación en su cuenta; préstamos y adelantos son cuentas por cobrar al empleado (el rebajo las acredita)
  ['Rebajos de la planilla', [['rrhh_embargos', 'Embargos judiciales por pagar'], ['rrhh_pensiones', 'Pensiones alimentarias por pagar'], ['rrhh_asociacion', 'Asociación solidarista por pagar (aporte del trabajador y patronal)'], ['rrhh_otras_deducciones', 'Seguros y otros rebajos por pagar'], ['rrhh_prestamos', 'Préstamos a empleados (por cobrar: la cuota de la planilla los rebaja)'], ['rrhh_adelantos', 'Adelantos de salario (por cobrar: el rebajo de la planilla los cancela)'], ['rrhh_maternidad_ccss', 'Licencia de maternidad: parte que paga la CCSS (rebaja el gasto de salarios)'], ['rrhh_asociacion_patronal', 'Aporte patronal a la asociación solidarista (gasto)']]],
  ['Ajustes', [['dc_ganancia', 'Diferencia en cambio (ganancia)'], ['dc_perdida', 'Diferencia en cambio (pérdida)'], ['ret_por_pagar', 'Retenciones a proveedores por pagar'], ['activos_perdida_baja', 'Pérdida por baja de activos fijos'], ['aprox_ingresos', 'Aproximación decimal (ingresos)'], ['aprox_gastos', 'Aproximación decimal (gastos)']]],
  ['Documentos del sistema anterior', [['importados_cobro', 'Cobros de las ventas importadas (ya cobradas allá)'], ['importados_pago', 'Pagos de las compras del sistema anterior (ya pagadas allá)']]],   // 4.1
];

export function paramContable() { return { ...DEF, ...(mock.get('param_contable', {}) || {}) }; }

// ---- periodos contables (Configuración › Contabilidad › Periodos): registro periodos_<año> = [{n, mes, estado}] ----
export function periodoCerrado(fecha) {
  const f = String(fecha || '').slice(0, 10); if (f.length < 7) return null;
  const [an, me] = f.split('-'); const per = (mock.get('periodos_' + an, null) || []).find(x => x.n === +me);
  return per && per.estado === 'Cerrado' ? { ...per, anio: an } : null;
}
const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
// Primer día del primer mes abierto a partir de la fecha (un asiento automático cuyo mes ya se cerró se registra en el siguiente mes abierto)
export function fechaAbierta(fecha) {
  let f = String(fecha || '').slice(0, 10);
  for (let i = 0; i < 36 && periodoCerrado(f); i++) { const d = new Date(f.slice(0, 7) + '-01T00:00:00'); d.setMonth(d.getMonth() + 1); f = iso(d); }
  return f;
}

// '4.1.01 Ventas' → { cuenta: '4.1.01', nombre: 'Ventas' }
export function cuentaDe(valor) { const s = String(valor || '').trim(); const i = s.indexOf(' '); return i > 0 ? { cuenta: s.slice(0, i), nombre: s.slice(i + 1) } : { cuenta: s, nombre: '' }; }
