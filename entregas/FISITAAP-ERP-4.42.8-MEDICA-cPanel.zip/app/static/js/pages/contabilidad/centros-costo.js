// Contabilidad › Centros de costo (3.8): departamentos o proyectos a los que se atribuyen ingresos, costos y gastos. Cada línea
// de un asiento puede llevar su centro; el reporte «Resultados por centro de costo» los resume. Registro 'centros_costo'.
import { toast, mock } from '../../api.js';
import { sesion } from '../../app.js';
import { asientosMock } from './asientos.js';

export function centrosCosto() { return (mock.get('centros_costo', []) || []).filter(c => c && c.nombre); }
export function nombreCentro(codigo) { const c = centrosCosto().find(x => x.codigo === codigo); return c ? c.codigo + ' · ' + c.nombre : (codigo || ''); }
const EJEMPLOS = [['ADM', 'Administración'], ['VEN', 'Ventas'], ['OPE', 'Operaciones'], ['PRO', 'Producción']];

export default {
  props: ['params'],
  data() { return { lista: centrosCosto(), form: null }; },
  computed: {
    puede() { return sesion.puede('contabilidad'); },
    filas() { return this.lista.slice().sort((a, b) => (a.activo === false) - (b.activo === false) || a.codigo.localeCompare(b.codigo)); },
    usados() { const m = {}; for (const a of asientosMock()) for (const l of a.lineas || []) if (l.centro) m[l.centro] = (m[l.centro] || 0) + 1; return m; },
  },
  methods: {
    nuevo() { this.form = { id: null, codigo: '', nombre: '', descripcion: '', activo: true }; },
    editar(c) { this.form = { ...c }; },
    cargarEjemplos() { if (!mock.puedeGuardar()) return; mock.actualizar('centros_costo', l => { const lista = Array.isArray(l) ? l : []; for (const [codigo, nombre] of EJEMPLOS) if (!lista.some(x => x.codigo === codigo)) lista.push({ id: mock.nextId(lista, 'centros_costo'), codigo, nombre, descripcion: '', activo: true }); return lista; }, []); this.lista = centrosCosto(); toast('Centros de ejemplo cargados: cámbielos a su gusto', 'ok'); },
    guardar() {
      const f = this.form, codigo = String(f.codigo || '').trim().toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 10);
      if (!codigo) return toast('Indique un código corto (letras o números)', 'err'); if (!(f.nombre || '').trim()) return toast('Indique el nombre', 'err');
      if (this.lista.some(x => x.codigo === codigo && x.id !== f.id)) return toast('Ya existe un centro con el código ' + codigo, 'err');
      if (!mock.puedeGuardar()) return;
      const reg = { ...f, codigo, nombre: f.nombre.trim(), descripcion: (f.descripcion || '').trim() };
      mock.actualizar('centros_costo', l => { const lista = Array.isArray(l) ? l : []; if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); if (i >= 0) lista.splice(i, 1, reg); else lista.push(reg); } else { reg.id = mock.nextId(lista, 'centros_costo'); lista.push(reg); } return lista; }, []);
      this.lista = centrosCosto(); this.form = null; toast('Centro de costo «' + reg.nombre + '» guardado', 'ok');
    },
    eliminar(c) {
      if (this.usados[c.codigo]) return toast('Tiene asientos: desactívelo en lugar de eliminarlo', 'err');
      if (!confirm('¿Eliminar el centro de costo «' + c.nombre + '»?')) return;
      mock.actualizar('centros_costo', l => (l || []).filter(x => x.id !== c.id), []); this.lista = centrosCosto(); this.form = null;
    },
  },
  template: `
  <div class="page">
    <PageHead title="Centros de costo" sub="Departamentos, sucursales o proyectos a los que se atribuyen los ingresos, costos y gastos. Cada línea del asiento puede llevar su centro; vea el resultado en Reportes › Contables › Resultados por centro de costo." :crumbs="[{label:'Contabilidad'},{label:'Centros de costo'}]">
      <a class="btn ghost" href="#/reportes/contables/resultados-centro-costo" v-if="lista.length">Ver reporte</a>
      <button class="btn" @click="nuevo" v-if="puede">+ Centro de costo</button>
    </PageHead>
    <div class="card">
      <Empty v-if="!lista.length" icon="🏷" title="Sin centros de costo" text="Cree los centros (Administración, Ventas, Producción, una sucursal, un proyecto…) y asígnelos en las líneas de los asientos."><div class="row" style="gap:8px"><button class="btn" @click="nuevo" v-if="puede">+ Centro de costo</button><button class="btn sec" @click="cargarEjemplos" v-if="puede">Cargar ejemplos</button></div></Empty>
      <table class="tbl" v-else><thead><tr><th>Código</th><th>Nombre</th><th>Descripción</th><th class="num">Líneas de asiento</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="c in filas" :key="c.id" :style="c.activo===false ? 'opacity:.55' : ''"><td class="mono"><b>{{c.codigo}}</b></td><td>{{c.nombre}}</td><td class="small muted">{{c.descripcion}}</td><td class="num">{{usados[c.codigo] || 0}}</td><td><span :class="c.activo===false ? 'badge' : 'badge ok'">{{c.activo===false ? 'Inactivo' : 'Activo'}}</span></td><td><button class="btn sm ghost" @click="editar(c)" v-if="puede">Editar</button></td></tr></tbody></table>
    </div>
    <Modal v-if="form" :title="form.id ? 'Centro de costo' : 'Nuevo centro de costo'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Código" req help="Corto: ADM, VEN, SUC1…"><input v-model="form.codigo" maxlength="10" class="mono" style="text-transform:uppercase"></Field>
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="60"></Field>
        <Field label="Descripción" style="grid-column:1/-1"><input v-model="form.descripcion" maxlength="160"></Field>
        <label class="row" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="form.activo"> Activo (se puede elegir en los asientos)</label>
      </div>
      <template #foot><button class="btn danger" v-if="form.id" @click="eliminar(form)">Eliminar</button><span style="flex:1"></span><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};
