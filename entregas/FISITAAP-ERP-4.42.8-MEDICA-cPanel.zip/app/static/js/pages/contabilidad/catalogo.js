// Catálogo de cuentas — plan contable base (estructura estándar de Costa Rica), jerárquico; se guarda en el servidor por empresa (registro 'catalogo')
import { toast, mock } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';
import { sesion } from '../../app.js';

// Plan de cuentas predeterminado: catálogo genérico (estructura estándar usada en Costa Rica, sin datos de ninguna empresa), numerado
// 1 Activos … 8 Transferencias respetando la jerarquía. Formato: [código, nombre, uso, descripción]. (R223)
const PLAN_BASE = [
  ['1', 'Activos', 'Agrupación', 'Bajo esta categoría se encuentran los activos que tiene la empresa'],
  ['1.1', 'Activos corrientes', 'Agrupación'],
  ['1.1.01', 'Efectivo y equivalentes de efectivo', 'Bancos'],
  ['1.1.01.01', 'Caja', 'Bancos'],
  ['1.1.01.01.01', 'Caja chica', 'Bancos'],
  ['1.1.01.01.02', 'Caja general', 'Bancos'],
  ['1.1.01.02', 'Bancos', 'Bancos'],
  ['1.1.01.02.01', 'Banco Nacional', 'Bancos'],
  ['1.1.01.02.01.01', 'Banco Nacional', 'Bancos'],
  ['1.1.01.02.01.02', 'Banco Nacional dólares', 'Bancos', 'Cuenta en USD (IBAN CR29…).'],
  ['1.1.01.02.02', 'Banco De Costa Rica', 'Bancos'],
  ['1.1.01.02.02.01', 'Banco De Costa Rica', 'Bancos'],
  ['1.1.01.02.03', 'BAC Credomatic', 'Bancos'],
  ['1.1.01.02.04', 'Otros bancos', 'Bancos'],
  ['1.1.01.03', 'Inversiones temporales', 'Bancos'],
  ['1.1.02', 'Deudores comerciales y otras cuentas por cobrar', 'Cuentas por cobrar'],
  ['1.1.02.01', 'Cuentas por cobrar clientes', 'Cuentas por cobrar'],
  ['1.1.02.01.01', 'Cuentas por cobrar clientes nacionales', 'Cuentas por cobrar'],
  ['1.1.02.01.02', 'Cuentas por cobrar clientes internacionales', 'Cuentas por cobrar'],
  ['1.1.02.01.03', 'Deterioro acumulado de cuentas por cobrar', 'Cuentas por cobrar'],
  ['1.1.02.01.04', 'Cuentas por cobrar tarjetas y pasarelas de pago (por liquidar)', 'Cuentas por cobrar', 'Ventas con tarjeta/SINPE pendientes de depósito del adquirente.'],
  ['1.1.02.01.05', 'Documentos por cobrar', 'Cuentas por cobrar'],
  ['1.1.02.02', 'Cuentas por cobrar a socios y accionistas', 'Cuentas por cobrar'],
  ['1.1.02.02.01', 'Cuentas por cobrar a socios', 'Cuentas por cobrar'],
  ['1.1.02.02.02', 'Cuentas por cobrar a accionistas', 'Cuentas por cobrar'],
  ['1.1.02.03', 'Avances y anticipos entregados', 'Anticipos'],
  ['1.1.02.03.01', 'Avances y anticipos a proveedores', 'Anticipos'],
  ['1.1.02.03.02', 'Avances y anticipos a empleados', 'Anticipos'],
  ['1.1.02.04', 'Otros deudores y cuentas por cobrar', 'Cuentas por cobrar'],
  ['1.1.02.04.01', 'Cuentas por cobrar empleados', 'Cuentas por cobrar'],
  ['1.1.02.04.02', 'Consumo de empleados', 'Cuentas por cobrar'],
  ['1.1.02.04.03', 'Préstamos a terceros', 'Cuentas por cobrar'],
  ['1.1.02.04.04', 'Otras cuentas por cobrar', 'Cuentas por cobrar'],
  ['1.1.02.04.05', 'Pagos por cuenta de terceros', 'Cuentas por cobrar'],
  ['1.1.02.04.06', 'Devoluciones a proveedores', 'Cuentas por cobrar'],
  ['1.1.02.04.07', 'Intereses por cobrar', 'Cuentas por cobrar'],
  ['1.1.03', 'Inversiones financieras a corto plazo', 'Inversiones'],
  ['1.1.03.01', 'Fondo de inversiones', 'Inversiones'],
  ['1.1.03.02', 'Acciones de otras compañias', 'Inversiones'],
  ['1.1.03.03', 'Depositos a plazos fijos', 'Inversiones'],
  ['1.1.03.04', 'Otras inversiones', 'Inversiones'],
  ['1.1.04', 'Activos por impuestos corrientes', 'Impuestos'],
  ['1.1.04.01', 'Impuestos a favor', 'Impuestos'],
  ['1.1.04.01.01', 'Impuesto sobre el valor agregado a favor', 'Impuestos'],
  ['1.1.04.01.01.01', 'IVA crédito fiscal', 'Impuestos'],
  ['1.1.04.01.01.02', 'Exento a favor', 'Impuestos'],
  ['1.1.04.01.02', 'Otro tipo de impuesto a favor', 'Impuestos'],
  ['1.1.04.01.03', 'Pagos parciales del impuesto sobre la renta', 'Impuestos', 'Los tres pagos parciales anuales (junio, setiembre, diciembre).'],
  ['1.1.04.02', 'Impuesto al Valor Agregado Soportado', 'Impuestos'],
  ['1.1.04.02.01', 'IVA soportado', 'Impuestos'],
  ['1.1.04.02.02', 'IVA bienes usados soportado', 'Impuestos'],
  ['1.1.05', 'Activos por retenciones a favor', 'Retenciones'],
  ['1.1.05.01', 'Retenciones a favor', 'Retenciones'],
  ['1.1.05.01.01', 'Retención 2 % de renta aplicada por clientes', 'Retenciones', 'Retenciones del Estado y grandes contribuyentes.'],
  ['1.1.05.01.02', 'Retención de renta por tarjetas (adquirente)', 'Retenciones'],
  ['1.1.05.01.03', 'Retención de IVA por tarjetas (adquirente)', 'Retenciones'],
  ['1.1.05.02', 'Otro tipo de retención a favor', 'Retenciones'],
  ['1.1.06', 'Inventarios', 'Inventario'],
  ['1.1.06.01', 'Inventario de mercancías', 'Inventario'],
  ['1.1.06.02', 'Inventario en tránsito', 'Inventario', 'Equipo comprado que todavía no llega a bodega.'],
  ['1.1.07', 'Activos pagados por anticipado', 'Anticipos'],
  ['1.1.07.01', 'Seguros pagados por anticipado', 'Anticipos'],
  ['1.1.07.02', 'Alquileres pagados por anticipado', 'Anticipos'],
  ['1.1.07.03', 'Licencias y suscripciones pagadas por anticipado', 'Anticipos'],
  ['1.1.08', 'Otros activos corrientes', 'Otros activos'],
  ['1.1.08.01', 'Depósitos en garantía', 'Otros activos', 'Depósitos de alquiler y servicios.'],
  ['1.2', 'Activos no corrientes', 'Agrupación'],
  ['1.2.01', 'Propiedad, planta y equipo (Activos fijos)', 'Activos fijos'],
  ['1.2.01.01', 'Terrenos', 'Activos fijos'],
  ['1.2.01.02', 'Edificios e instalaciones', 'Activos fijos'],
  ['1.2.01.03', 'Construcciones en tránsito', 'Activos fijos'],
  ['1.2.01.04', 'Mobiliario y equipo de oficina', 'Activos fijos'],
  ['1.2.01.05', 'Equipo de computación', 'Activos fijos'],
  ['1.2.01.06', 'Vehiculos y equipos de transporte', 'Activos fijos'],
  ['1.2.01.07', 'Equipo de redes y telecomunicaciones', 'Activos fijos', 'Routers, switches, access points, servidores.'],
  ['1.2.01.08', 'Maquinaria, equipo y herramientas', 'Activos fijos'],
  ['1.2.01.09', 'Mejoras a propiedades arrendadas', 'Activos fijos'],
  ['1.2.02', 'Depreciación acumulada', 'Depreciación'],
  ['1.2.02.01', 'Depreciación acumulada edificios e instalaciones', 'Depreciación'],
  ['1.2.02.02', 'Depreciación acumulada mobiliario y equipo de oficina', 'Depreciación'],
  ['1.2.02.03', 'Depreciación acumulada equipo de computación', 'Depreciación'],
  ['1.2.02.04', 'Depreciación acumulada vehiculos y equipos de transporte', 'Depreciación'],
  ['1.2.02.05', 'Depreciación acumulada equipo de redes y telecomunicaciones', 'Depreciación'],
  ['1.2.02.06', 'Depreciación acumulada maquinaria, equipo y herramientas', 'Depreciación'],
  ['1.2.02.07', 'Depreciación acumulada mejoras a propiedades arrendadas', 'Depreciación'],
  ['1.2.03', 'Deterioro acumulado de valor', 'Depreciación'],
  ['1.2.04', 'Activos intangibles', 'Activos fijos', 'Software, licencias y desarrollos propios.'],
  ['1.2.04.01', 'Software y licencias', 'Activos fijos'],
  ['1.2.04.02', 'Sitio web y plataformas digitales', 'Activos fijos'],
  ['1.2.04.03', 'Marcas y patentes', 'Activos fijos'],
  ['1.2.05', 'Amortización acumulada de intangibles', 'Depreciación'],
  ['1.2.05.01', 'Amortización acumulada software y licencias', 'Depreciación'],
  ['1.2.05.02', 'Amortización acumulada sitio web y plataformas digitales', 'Depreciación'],
  ['1.2.05.03', 'Amortización acumulada marcas y patentes', 'Depreciación'],
  ['1.2.06', 'Inversiones a largo plazo', 'Inversiones'],
  ['1.2.07', 'Activos por impuestos diferidos', 'Impuestos'],
  ['2', 'Pasivos', 'Agrupación', 'Bajo esta categoría se encuentran los pasivos de la empresa'],
  ['2.1', 'Pasivos corrientes', 'Agrupación'],
  ['2.1.01', 'Acreedores comerciales y otras cuentas por pagar', 'Cuentas por pagar'],
  ['2.1.01.01', 'Cuentas por pagar a proveedores', 'Cuentas por pagar'],
  ['2.1.01.01.01', 'Cuentas por pagar a proveedores nacionales', 'Cuentas por pagar'],
  ['2.1.01.01.02', 'Cuentas por pagar a proveedores del exterior', 'Cuentas por pagar'],
  ['2.1.01.02', 'Avances y anticipos recibidos', 'Cuentas por pagar'],
  ['2.1.01.02.01', 'Avances y anticipos recibidos de clientes', 'Cuentas por pagar'],
  ['2.1.01.02.02', 'Ingresos diferidos por contratos de soporte y suscripciones', 'Cuentas por pagar', 'Planes de soporte cobrados por adelantado.'],
  ['2.1.01.03', 'Otras cuentas por pagar', 'Cuentas por pagar'],
  ['2.1.01.03.01', 'Devoluciones de clientes', 'Cuentas por pagar'],
  ['2.1.01.03.02', 'Documentos por pagar', 'Cuentas por pagar'],
  ['2.1.01.03.03', 'Gastos acumulados por pagar', 'Cuentas por pagar'],
  ['2.1.01.03.04', 'Cuentas por pagar a socios', 'Cuentas por pagar'],
  ['2.1.01.03.05', 'Dividendos por pagar', 'Cuentas por pagar'],
  ['2.1.01.03.06', 'Intereses por pagar', 'Cuentas por pagar'],
  ['2.1.02', 'Obligaciones laborales y de seguridad social', 'Obligaciones laborales'],
  ['2.1.02.01', 'Salarios y prestaciones sociales', 'Obligaciones laborales'],
  ['2.1.02.01.01', 'Salarios a empleados por pagar', 'Obligaciones laborales'],
  ['2.1.02.01.01.01', 'Salarios por pagar', 'Obligaciones laborales'],
  ['2.1.02.01.01.02', 'Liquidaciones laborales por pagar', 'Obligaciones laborales'],
  ['2.1.02.01.02', 'Aguinaldo por pagar (provisión)', 'Obligaciones laborales'],
  ['2.1.02.01.03', 'Vacaciones por pagar (provisión)', 'Obligaciones laborales'],
  ['2.1.02.01.04', 'Cesantía por pagar (provisión)', 'Obligaciones laborales'],
  ['2.1.02.02', 'Obligaciones seguridad social social', 'Obligaciones laborales'],
  ['2.1.02.02.01', 'Retención laboral CCSS por pagar', 'Obligaciones laborales'],
  ['2.1.02.02.02', 'Impuesto de renta al salario por pagar', 'Obligaciones laborales'],
  ['2.1.02.02.03', 'Asociación solidaristas por pagar', 'Obligaciones laborales'],
  ['2.1.02.02.04', 'Cargas sociales patronales CCSS por pagar', 'Obligaciones laborales', 'Cuota patronal (26,67 %).'],
  ['2.1.02.02.05', 'INS riesgos del trabajo por pagar', 'Obligaciones laborales'],
  ['2.1.02.02.06', 'Embargos y pensiones alimentarias por pagar', 'Obligaciones laborales'],
  ['2.1.03', 'Obligaciones financieras a corto plazo', 'Préstamos'],
  ['2.1.03.01', 'Préstamos a corto plazo bancos nacionales', 'Préstamos'],     // nombres que estaban cruzados con 2.2.01.01 (R219)
  ['2.1.03.01.01', 'Préstamos bancarios a corto plazo', 'Préstamos'],
  ['2.1.03.02', 'Tarjetas de crédito', 'Préstamos'],
  ['2.1.04', 'Pasivos por impuestos corrientes', 'Impuestos'],
  ['2.1.04.01', 'Impuestos por pagar', 'Impuestos'],
  ['2.1.04.01.01', 'Impuesto sobre el valor agregado por pagar', 'Impuestos'],
  ['2.1.04.01.01.01', 'IVA débito fiscal', 'Impuestos'],
  ['2.1.04.01.01.02', 'Exento por pagar', 'Impuestos'],
  ['2.1.04.01.02', 'Impuesto sobre la renta por pagar', 'Impuestos'],
  ['2.1.04.01.03', 'Otro tipo de impuesto por pagar', 'Impuestos'],
  ['2.1.04.01.04', 'Impuesto municipal (patente) por pagar', 'Impuestos'],
  ['2.1.04.01.05', 'Impuesto a las personas jurídicas por pagar', 'Impuestos'],
  ['2.1.04.01.06', 'Timbre de educación y cultura por pagar', 'Impuestos'],
  ['2.1.04.02', 'Impuesto al valor agregado repercutido', 'Impuestos'],
  ['2.1.04.02.01', 'IVA repercutido', 'Impuestos'],
  ['2.1.04.02.02', 'IVA bienes usados repercutidos', 'Impuestos'],
  ['2.1.05', 'Pasivos por otros cargos', 'Otros cargos'],
  ['2.1.05.01', 'Contribuciones parafiscales por pagar', 'Otros cargos'],
  ['2.1.05.01.01', 'Timbre de la Cruz Roja por pagar', 'Otros cargos'],
  ['2.1.05.01.02', 'Timbre de Benemérito Cuerpo de Bomberos de Costa Rica por pagar', 'Otros cargos'],
  ['2.1.05.02', 'Timbre de Colegio Profesionales por pagar', 'Otros cargos'],
  ['2.1.05.03', 'Cuentas por pagar a saloneros y meseros', 'Otros cargos'],
  ['2.1.05.04', 'Cuentas por pagar otros Cargos', 'Otros cargos'],
  ['2.1.06', 'Pasivos por retenciones corrientes', 'Retenciones'],
  ['2.1.06.01', 'Retenciones por pagar', 'Retenciones'],
  ['2.1.06.01.01', 'Retención ISR por pagar', 'Retenciones'],
  ['2.1.06.01.02', 'Retención de IVA por pagar', 'Retenciones'],
  ['2.1.06.01.03', 'ISR retenido a empleados por pagar', 'Retenciones'],
  ['2.1.06.02', 'Otro tipo de retención por pagar', 'Retenciones'],
  ['2.1.07', 'Otros pasivos corrientes', 'Otros pasivos'],
  ['2.1.07.01', 'Ingresos recibidos para terceros', 'Otros pasivos'],
  ['2.2', 'Pasivos no corrientes', 'Agrupación'],
  ['2.2.01', 'Obligaciones financieras a largo plazo', 'Préstamos'],
  ['2.2.01.01', 'Préstamos a largo plazo bancos nacionales', 'Préstamos'],
  ['2.2.01.01.01', 'Préstamos bancarios a largo plazo', 'Préstamos'],
  ['2.2.01.02', 'Préstamos de socios a largo plazo', 'Préstamos'],
  ['2.2.02', 'Otros pasivos no corrientes', 'Otros pasivos'],
  ['2.2.02.01', 'Provisión para prestaciones legales', 'Otros pasivos'],
  ['2.2.02.02', 'Depósitos recibidos en garantía', 'Otros pasivos'],
  ['3', 'Patrimonio', 'Patrimonio', 'Bajo esta categoría se encuentra el patrimonio de la empresa'],
  ['3.1', 'Capital social', 'Patrimonio'],
  ['3.1.01', 'Capital social suscrito y pagado', 'Patrimonio'],
  ['3.1.01.01', 'Capital social suscrito', 'Patrimonio'],
  ['3.1.01.01.01', 'Capital social autorizado', 'Patrimonio'],
  ['3.1.01.01.02', 'Capital por suscribir o Acciones', 'Patrimonio'],
  ['3.1.02', 'Capital social suscrito por cobrar', 'Patrimonio'],
  ['3.1.02.01', 'Capital suscrito por cobrar o Accionistas comunes', 'Patrimonio'],
  ['3.2', 'Reservas', 'Patrimonio'],
  ['3.2.01', 'Reserva legal', 'Patrimonio'],
  ['3.2.02', 'Reserva facultativa', 'Patrimonio'],
  ['3.3', 'Resultado del ejercicio', 'Patrimonio'],
  ['3.3.01', 'Utilidad del ejercicio', 'Patrimonio'],
  ['3.3.02', 'Pérdida del ejercicio', 'Patrimonio'],
  ['3.4', 'Ganancias acumuladas', 'Patrimonio'],
  ['3.5', 'Superávit', 'Patrimonio'],
  ['3.6', 'Ajustes por saldos iniciales', 'Patrimonio'],
  ['3.6.01', 'Ajustes iniciales en bancos', 'Patrimonio'],
  ['3.6.02', 'Ajustes iniciales en inventario', 'Patrimonio'],
  ['3.7', 'Pérdidas acumuladas', 'Patrimonio'],
  ['3.8', 'Aportes adicionales de socios', 'Patrimonio'],
  ['3.9', 'Dividendos decretados', 'Patrimonio'],
  ['4', 'Ingresos', 'Ingresos', 'Bajo esta categoría se encuentran todos los tipos de ingresos'],
  ['4.1', 'Ingresos de actividades ordinarias', 'Ingresos'],
  ['4.1.01', 'Ventas', 'Ingresos'],
  ['4.1.02', 'Devoluciones en ventas', 'Ingresos'],
  ['4.1.03', 'Ventas de equipo y productos', 'Ingresos', 'Separa la venta de hardware de los servicios.'],
  ['4.1.04', 'Ingresos por servicios de soporte y consultoría', 'Ingresos'],
  ['4.1.05', 'Ingresos por licencias y suscripciones', 'Ingresos'],
  ['4.1.06', 'Ingresos por desarrollo de software y sitios web', 'Ingresos'],
  ['4.1.07', 'Descuentos en ventas', 'Ingresos'],
  ['4.2', 'Otros Ingresos', 'Otros ingresos'],
  ['4.2.01', 'Ingresos financieros', 'Otros ingresos'],
  ['4.2.01.01', 'Ingresos por Intereses financieros', 'Otros ingresos'],
  ['4.2.02', 'Otros ingresos', 'Otros ingresos'],
  ['4.2.02.01', 'Ganancia por diferencia en cambio', 'Otros ingresos'],
  ['4.2.02.02', 'Ajustes por aproximaciones en cálculos', 'Otros ingresos'],
  ['4.2.02.03', 'Otros ingresos por otros cargos', 'Otros ingresos'],
  ['4.2.02.04', 'Ingresos por alquileres', 'Otros ingresos'],
  ['4.2.02.05', 'Recuperación de cuentas incobrables', 'Otros ingresos'],
  ['4.2.02.06', 'Ganancia por venta de activos', 'Otros ingresos'],
  ['4.2.02.07', 'Ingresos por comisiones', 'Otros ingresos'],
  ['5', 'Costos', 'Costos', 'Bajo esta categoría se encuentran todos los tipos de costos'],
  ['5.1', 'Costos de ventas y operación', 'Costos'],
  ['5.1.01', 'Costos de la mercancía vendida', 'Costos'],
  ['5.1.01.01', 'Costos del inventario', 'Costos'],
  ['5.1.01.02', 'Ajustes al inventario', 'Costos'],
  ['5.1.01.03', 'Descuentos financieros', 'Costos'],
  ['5.1.01.04', 'Devoluciones en compras de inventario', 'Costos'],
  ['5.1.01.05', 'Fletes y aduanas en compras', 'Costos'],
  ['5.1.01.06', 'Mermas y daños de inventario', 'Costos'],
  ['5.1.02', 'Costo de los servicios vendidos', 'Costos'],
  ['5.1.02.01', 'Licencias y suscripciones revendidas', 'Costos', 'Microsoft 365, antivirus, etc. comprados para clientes.'],
  ['5.1.02.02', 'Hosting y servicios en la nube para clientes', 'Costos'],
  ['5.1.02.03', 'Subcontratación de servicios técnicos', 'Costos'],
  ['5.1.02.04', 'Repuestos y materiales usados en servicios', 'Costos'],
  ['6', 'Gastos', 'Gastos', 'Bajo esta categoría se encuentran todos los tipos de gastos'],
  ['6.1', 'Gastos de venta', 'Gastos'],
  ['6.1.01', 'Gastos de personal de ventas', 'Gastos'],
  ['6.1.01.01', 'Salarios personal de ventas', 'Gastos'],
  ['6.1.01.02', 'Horas extras personal de ventas', 'Gastos'],
  ['6.1.01.03', 'Gastos cargas sociales personal de ventas', 'Gastos'],
  ['6.1.01.04', 'Gastos capacitación personal de ventas', 'Gastos'],
  ['6.1.01.05', 'Comisiones y bonos personal de ventas', 'Gastos'],
  ['6.1.01.06', 'Vacaciones personal de ventas', 'Gastos'],
  ['6.1.01.07', 'Cesantia personal de ventas', 'Gastos'],
  ['6.1.01.08', 'Aguinaldo personal de ventas', 'Gastos'],
  ['6.2', 'Gastos de administración', 'Gastos'],
  ['6.2.01', 'Gastos de personal', 'Gastos'],
  ['6.2.01.01', 'Sueldos y salarios', 'Gastos'],
  ['6.2.01.02', 'Horas extras', 'Gastos'],
  ['6.2.01.03', 'Gastos por cargas sociales', 'Gastos'],
  ['6.2.01.04', 'Gastos capacitación', 'Gastos'],
  ['6.2.01.05', 'Comisiones y bonos', 'Gastos'],
  ['6.2.01.06', 'Vacaciones', 'Gastos'],
  ['6.2.01.07', 'Cesantia', 'Gastos'],
  ['6.2.01.08', 'Aguinaldo', 'Gastos'],
  ['6.2.01.09', 'Seguro de riesgos del trabajo (INS)', 'Gastos'],
  ['6.2.01.10', 'Atención y bienestar del personal', 'Gastos'],
  ['6.2.02', 'Gastos generales', 'Gastos'],
  ['6.2.02.01', 'Servicios profesionales', 'Gastos'],
  ['6.2.02.01.01', 'Asesoria jurídica', 'Gastos'],
  ['6.2.02.01.02', 'Asesoria contable', 'Gastos'],
  ['6.2.02.02', 'Arrendamientos', 'Gastos'],
  ['6.2.02.02.01', 'Arrendamiento de equipos', 'Gastos'],
  ['6.2.02.02.02', 'Arrendamiento de oficinas', 'Gastos'],
  ['6.2.02.03', 'Servicios públicos', 'Gastos'],
  ['6.2.02.03.01', 'Gas', 'Gastos'],
  ['6.2.02.03.02', 'Aseo', 'Gastos'],
  ['6.2.02.03.03', 'Agua', 'Gastos'],
  ['6.2.02.03.04', 'Energia eléctrica', 'Gastos'],
  ['6.2.02.03.05', 'Teléfono/Internet', 'Gastos'],
  ['6.2.02.04', 'Asistencia técnica', 'Gastos'],
  ['6.2.02.05', 'Otros servicios', 'Gastos'],
  ['6.2.02.05.01', 'Vigilancia y seguridad', 'Gastos'],
  ['6.2.02.06', 'Gastos de representacion', 'Gastos'],
  ['6.2.02.06.01', 'Comidas y entretenimiento', 'Gastos'],
  ['6.2.02.06.02', 'Viáticos y gastos de viaje', 'Gastos'],
  ['6.2.02.07', 'Artículos de oficina', 'Gastos'],
  ['6.2.02.07.01', 'Papelería', 'Gastos'],
  ['6.2.02.08', 'Combustibles y lubricantes', 'Gastos'],
  ['6.2.02.09', 'Fletes y gastos de envios', 'Gastos'],
  ['6.2.02.09.01', 'Envios y Mensajería', 'Gastos'],
  ['6.2.02.10', 'Estacionamiento', 'Gastos'],
  ['6.2.02.11', 'Propaganda y publicidad', 'Gastos'],
  ['6.2.02.12', 'Capacitación al personal', 'Gastos'],
  ['6.2.02.13', 'Seguros', 'Gastos'],
  ['6.2.02.13.01', 'Seguro de accidentes', 'Gastos'],
  ['6.2.02.13.02', 'Seguro de vehiculos', 'Gastos'],
  ['6.2.02.13.03', 'Seguro contra Incendios', 'Gastos'],
  ['6.2.02.14', 'Patentes y marcas', 'Gastos'],
  ['6.2.02.15', 'Servicios Online', 'Gastos'],
  ['6.2.02.15.01', 'Software contables', 'Gastos'],
  ['6.2.02.16', 'Gastos constitución', 'Gastos'],
  ['6.2.02.17', 'Gastos legales', 'Gastos'],
  ['6.2.02.17.01', 'Notariales', 'Gastos'],
  ['6.2.02.17.02', 'Registro mercantiles', 'Gastos'],
  ['6.2.02.17.03', 'Trámites legales', 'Gastos'],
  ['6.2.02.18', 'Mantenimiento y conservación', 'Gastos'],
  ['6.2.02.18.01', 'Construcción y edificación', 'Gastos'],
  ['6.2.02.18.02', 'Equipo oficina', 'Gastos'],
  ['6.2.02.18.03', 'Equipo computación', 'Gastos'],
  ['6.2.02.18.04', 'Adecuaciones e instalaciones', 'Gastos'],
  ['6.2.02.19', 'Cuotas y suscripciones', 'Gastos'],
  ['6.2.02.20', 'Otros gastos generales', 'Gastos'],
  ['6.2.02.21', 'Hosting, dominios y servicios en la nube', 'Gastos', 'Uso interno (cPanel, dominios, correo).'],
  ['6.2.02.22', 'Licencias de software de uso interno', 'Gastos'],
  ['6.2.02.23', 'Telefonía celular', 'Gastos'],
  ['6.2.02.24', 'Comisiones por tarjetas y pasarelas de pago', 'Gastos', 'Comisión del adquirente/datafono.'],
  ['6.2.02.25', 'Mantenimiento de vehículos', 'Gastos'],
  ['6.2.02.26', 'Peajes y transporte', 'Gastos'],
  ['6.2.02.27', 'Limpieza y suministros', 'Gastos'],
  ['6.2.02.28', 'Herramientas y suministros técnicos', 'Gastos'],
  ['6.2.02.29', 'Timbres y especies fiscales', 'Gastos'],
  ['6.2.02.30', 'Donaciones', 'Gastos'],
  ['6.2.02.31', 'Multas y sanciones (no deducible)', 'Gastos'],
  ['6.2.02.32', 'Gastos no deducibles', 'Gastos'],
  ['6.2.03', 'Depreciaciones, amortizaciones y desvalorizaciones', 'Gastos'],
  ['6.2.03.01', 'Deterioro de cuentas por cobrar', 'Gastos'],
  ['6.2.03.02', 'Depreciación de propiedad, planta y equipo', 'Gastos'],
  ['6.2.03.02.01', 'Depreciación construcciones y edificaciones', 'Gastos'],
  ['6.2.03.02.02', 'Depreciación mobiliario y equipo de oficina', 'Gastos'],
  ['6.2.03.02.03', 'Depreciación equipo de computación', 'Gastos'],
  ['6.2.03.02.04', 'Depreciación vehiculos y equipos de transporte', 'Gastos'],
  ['6.2.03.02.05', 'Depreciación equipo de redes y telecomunicaciones', 'Gastos'],
  ['6.2.03.02.06', 'Depreciación maquinaria, equipo y herramientas', 'Gastos'],
  ['6.2.03.02.07', 'Depreciación mejoras a propiedades arrendadas', 'Gastos'],
  ['6.2.03.03', 'Amortización de intangibles', 'Gastos'],
  ['6.3', 'Gastos financieros', 'Otros gastos'],
  ['6.3.01', 'Gastos por Intereses financieros', 'Otros gastos'],
  ['6.3.02', 'Gastos por Intereses de mora', 'Otros gastos'],
  ['6.4', 'Otros gastos', 'Otros gastos'],
  ['6.4.01', 'Comisiones bancarias', 'Otros gastos'],
  ['6.4.02', 'Pérdida por diferencia en cambio', 'Otros gastos'],
  ['6.4.03', 'Ajustes por aproximaciones en cálculos', 'Otros gastos'],
  ['6.4.04', 'Pérdida por disposición de activos', 'Otros gastos'],
  ['6.4.05', 'Pérdida por robo o siniestro', 'Otros gastos'],
  ['6.5', 'Gastos por otros cargos', 'Otros gastos'],
  ['6.5.01', 'Contribución parafiscal', 'Otros gastos'],
  ['6.5.01.01', 'Timbre de la cruz roja', 'Otros gastos'],
  ['6.5.01.02', 'Timbre de Benemérito Cuerpo de Bomberos de Costa Rica', 'Otros gastos'],
  ['6.5.02', 'Gastos por cobro de un tercero', 'Otros gastos'],
  ['6.5.03', 'Costos de Exportación', 'Otros gastos'],
  ['6.5.04', 'Timbre de Colegio Profesionales', 'Otros gastos'],
  ['6.5.05', 'Impuesto de servicio 10%', 'Otros gastos'],
  ['6.5.06', 'Gastos por otros cargos', 'Otros gastos'],
  ['6.6', 'Gastos por impuestos', 'Otros gastos'],
  ['6.6.01', 'Impuestos de renta', 'Otros gastos'],
  ['6.6.02', 'Gastos por impuestos no acreditables', 'Otros gastos'],
  ['6.6.03', 'Impuesto municipal (patente)', 'Otros gastos'],
  ['6.6.04', 'Impuesto a las personas jurídicas', 'Otros gastos'],
  ['6.6.05', 'Timbre de educación y cultura', 'Otros gastos'],
  ['7', 'Cuentas de orden', 'Orden', 'Bajo esta categoría se encuentran todos los tipos de cuentas de orden'],
  ['7.1', 'Cuentas de orden deudoras', 'Orden'],
  ['7.2', 'Cuentas de orden acreedoras', 'Orden'],
  ['8', 'Transferencias bancarias', 'Bancos', 'Bajo esta categoría se ubican todas las transferencias que se hagan entre bancos de la empresa'],
  ['8.1', 'Transferencias entre cuentas propias', 'Bancos', 'Cuenta puente para traslados entre bancos y cajas.'],
];

export const USOS = ['Agrupación', 'Bancos', 'Cuentas por cobrar', 'Inversiones', 'Impuestos', 'Retenciones', 'Inventario', 'Anticipos', 'Otros activos', 'Activos fijos', 'Depreciación', 'Cuentas por pagar', 'Obligaciones laborales', 'Préstamos', 'Otros cargos', 'Otros pasivos', 'Patrimonio', 'Ingresos', 'Otros ingresos', 'Costos', 'Gastos', 'Otros gastos', 'Orden'];
export const COLOR_RAIZ = { 1: '#2563eb', 2: '#dc2626', 3: '#7c3aed', 4: '#059669', 5: '#d97706', 6: '#ea580c', 7: '#64748b', 8: '#0891b2' };

function padreDe(codigo) { const i = codigo.lastIndexOf('.'); return i < 0 ? null : codigo.slice(0, i); }
function construir() {
  return PLAN_BASE.map(([codigo, nombre, uso, descripcion]) => ({ codigo, nombre, uso: uso || 'Agrupación', descripcion: descripcion || '', cabys: '' }));
}
function ordenarCuentas(lista) {
  const k = c => c.codigo.split('.').map(x => x.padStart(4, '0')).join('.');
  return lista.slice().sort((a, b) => k(a).localeCompare(k(b)));
}
// ¿Dónde se usa una cuenta? (asientos, parametrización, cuentas de banco): no se elimina ni se renombra el código si está en uso (R59)
export function usosDeCuenta(codigo) {
  const usos = [];
  if ((mock.get('asientos', []) || []).some(a => (a.lineas || []).some(l => l.cuenta === codigo))) usos.push('asientos');
  const pc = mock.get('param_contable', {}) || {};
  if (Object.values(pc).some(v => String(v || '').split(' ')[0] === codigo)) usos.push('parametrización contable');
  if ((mock.get('bancos', []) || []).some(b => String(b.cuenta_contable || '').split(' ')[0] === codigo)) usos.push('cuentas de banco');
  if ((mock.get('activos', []) || []).some(a => a && [a.cuenta_activo, a.cuenta_depreciacion, a.cuenta_gasto].includes(codigo))) usos.push('activos fijos');
  if ((mock.get('pagos_gastos', []) || []).some(p => p && (p.cuentas || []).some(c => String(c.cuenta || c.concepto || '').split(' ')[0] === codigo))) usos.push('pagos a proveedores');
  if ((mock.get('recurrentes_gastos', []) || []).some(p => p && (p.lineas || []).some(c => String(c.cuenta || '').split(' ')[0] === codigo))) usos.push('pagos recurrentes');
  return usos;
}
function decorar(lista) {
  const padres = new Set(lista.map(c => padreDe(c.codigo)).filter(Boolean));
  return lista.map(c => ({ ...c, padre: padreDe(c.codigo), nivel: c.codigo.split('.').length, raiz: c.codigo.split('.')[0], hoja: !padres.has(c.codigo) }));
}

// Lista plana del plan de cuentas (con padre, nivel, raiz y hoja). Precarga el catálogo la primera vez.
// Versión del plan predeterminado: si cambia, el navegador reemplaza el plan guardado por el nuevo (se pierden cuentas agregadas a mano al plan viejo).
const PLAN_VERSION = 'alegra-2026-10-10c';
export function planCuentas() {
  let l = mock.get('catalogo', null);
  // Solo quien lleva la contabilidad guarda el plan inicial; los demás roles lo ven armado en memoria sin escribir nada
  if (!l || !l.length) { l = construir(); if (sesion.puede('contabilidad')) { mock.set('catalogo', l); mock.set('catalogo_version', PLAN_VERSION); } }
  else if (mock.get('catalogo_version', '') !== PLAN_VERSION) {
    // plan base nuevo: se AGREGAN las cuentas que falten y se conservan las de la empresa (antes se reemplazaba todo) (R60)
    const tiene = new Set(l.map(c => c.codigo)), nuevas = construir().filter(c => !tiene.has(c.codigo));
    if (nuevas.length) { l = ordenarCuentas([...l, ...nuevas]); }
    if (sesion.puede('contabilidad')) { if (nuevas.length) mock.set('catalogo', l); mock.set('catalogo_version', PLAN_VERSION); }
  }
  return decorar(l);
}

export default {
  props: ['params'],
  data() {
    return { cuentas: planCuentas(), q: '', open: { 1: true, 2: true, 3: true, 4: true, 5: true, 6: true, 7: true, 8: true }, filtro: null, menu: false, modal: false, USOS, COLOR_RAIZ,
      f: { padre: '1.1.01', codigo: '', nombre: '', descripcion: '', cabys: '', uso: 'Bancos' } };
  },
  computed: {
    raices() { return this.cuentas.filter(c => c.nivel === 1); },
    visibles() {
      const q = this.q.toLowerCase().trim();
      return this.cuentas.filter(c => {
        if (this.filtro && c.raiz !== this.filtro) return false;
        if (q) return c.nombre.toLowerCase().includes(q) || c.codigo.startsWith(q) || c.uso.toLowerCase().includes(q) || (c.cabys || '').includes(q);
        let p = c.padre; while (p) { if (!this.open[p]) return false; p = padreDe(p); }
        return true;
      });
    },
    // como padre no sirve una cuenta de movimiento que ya tenga asientos o esté en la parametrización contable (R220)
    padresOpc() { const usadas = new Set([...(mock.get('asientos', []) || []).flatMap(a => (a.lineas || []).map(l => l.cuenta)), ...Object.values(mock.get('param_contable', {}) || {}).map(v => String(v || '').split(' ')[0])]); return this.cuentas.filter(c => !c.hoja || (c.nivel <= 3 && !usadas.has(c.codigo))); },
  },
  watch: { 'f.padre'(v) { this.sugerirCodigo(v); } },
  methods: {
    color(c) { return COLOR_RAIZ[c.raiz] || '#64748b'; },
    tieneHijos(c) { return !c.hoja; },
    tog(c) { if (c.hoja) return; this.open[c.codigo] = !this.open[c.codigo]; },
    expandir(todo) { const o = {}; if (todo) for (const c of this.cuentas) o[c.codigo] = true; else for (const r of this.raices) o[r.codigo] = true; this.open = o; this.menu = false; },
    guardar() { mock.set('catalogo', this.cuentas.map(({ codigo, nombre, uso, descripcion, cabys }) => ({ codigo, nombre, uso, descripcion, cabys }))); this.cuentas = planCuentas(); },
    sugerirCodigo(padre) {
      const p = this.cuentas.find(c => c.codigo === padre); if (!p) return;
      const n = this.cuentas.filter(c => c.padre === padre).reduce((m, c) => Math.max(m, +String(c.codigo).slice(padre.length + 1) || 0), 0) + 1;   // mayor + 1: nunca un código ocupado (R220)
      this.f.codigo = padre + '.' + String(n).padStart(2, '0');
      if (p.uso !== 'Agrupación') this.f.uso = p.uso;
    },
    nueva(nombre = '') { this.f = { padre: '1.1.01', codigo: '', nombre, descripcion: '', cabys: '', uso: 'Bancos' }; this.sugerirCodigo('1.1.01'); this.modal = true; this.menu = false; },
    crear() {
      const f = this.f;
      if (!f.nombre.trim() || !f.codigo.trim() || !f.padre) return toast('Complete cuenta padre, código y nombre', 'err');
      if (this.cuentas.some(c => c.codigo === f.codigo.trim())) return toast('Ya existe una cuenta con el código ' + f.codigo, 'err');
      if (!f.codigo.startsWith(f.padre + '.')) return toast('El código debe comenzar con el de la cuenta padre (' + f.padre + '.)', 'err');
      let idx = this.cuentas.findIndex(c => c.codigo === f.padre);
      while (idx + 1 < this.cuentas.length && this.cuentas[idx + 1].codigo.startsWith(f.padre + '.')) idx++;
      this.cuentas.splice(idx + 1, 0, { codigo: f.codigo.trim(), nombre: f.nombre.trim(), uso: f.uso, descripcion: f.descripcion, cabys: f.cabys });
      this.guardar(); let p = f.padre; while (p) { this.open[p] = true; p = padreDe(p); }
      this.modal = false; this.q = ''; toast('Cuenta ' + f.codigo + ' creada', 'ok');
    },
    eliminar(c) {
      if (!c.hoja) return toast('Elimine primero las subcuentas', 'err');
      const usos = usosDeCuenta(c.codigo); if (usos.length) return toast('La cuenta ' + c.codigo + ' está en uso (' + usos.join(', ') + '); no se puede eliminar', 'err');
      if (!confirm('¿Eliminar la cuenta ' + c.codigo + ' · ' + c.nombre + '?')) return;
      this.cuentas = this.cuentas.filter(x => x.codigo !== c.codigo); this.guardar(); toast('Cuenta eliminada');
    },
    exportar() {
      exportarFilas('catalogo-de-cuentas', ['Código', 'Nombre', 'Uso de cuenta', 'Descripción', 'CABYS', 'Cuenta padre'], this.cuentas.map(c => [c.codigo, c.nombre, c.uso, c.descripcion, c.cabys, c.padre || '']), { titulo: 'Catálogo de cuentas' });
      this.menu = false;
    },
    restaurar() { if (!confirm('¿Restaurar el plan de cuentas predeterminado? Se perderán las cuentas agregadas.')) return; mock.set('catalogo', construir()); this.cuentas = planCuentas(); this.menu = false; toast('Plan de cuentas restaurado', 'ok'); },
  },
  template: `
  <div class="page">
    <PageHead title="Catálogo de cuentas" sub="Plan de cuentas de la empresa sobre un catálogo base estándar. Organice las cuentas que usará en sus asientos contables.">
      <div style="position:relative"><button class="btn ghost" @click="menu=!menu">Acciones ▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:230px;padding:6px">
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar">⤓ Exportar</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="expandir(true)">Expandir todo</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="expandir(false)">Contraer todo</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer;color:var(--danger)" @click="restaurar">Restaurar plan predeterminado</a>
        </div></div>
      <button class="btn" v-if="puede('contabilidad')" @click="nueva()">+ Nueva cuenta</button>
    </PageHead>

    <div class="row" style="margin-bottom:12px">
      <span class="chip" :class="{on: !filtro}" @click="filtro=null">Todas · {{cuentas.length}}</span>
      <span class="chip" v-for="r in raices" :key="r.codigo" :class="{on: filtro===r.codigo}" @click="filtro = filtro===r.codigo ? null : r.codigo"><i style="width:9px;height:9px;border-radius:50%;display:inline-block" :style="{background:color(r)}"></i>{{r.nombre}}</span>
    </div>

    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0">
        <input class="search" placeholder="Buscar o crear cuenta…" v-model="q" @keyup.enter="q && !visibles.length && nueva(q)">
        <button class="btn sm sec" v-if="q && !visibles.length" @click="nueva(q)">+ Crear «{{q}}»</button>
        <span class="small muted" v-else-if="q">{{visibles.length}} coincidencias</span>
      </div>
      <div class="tree">
        <div class="node" style="background:#fafbfc;font-size:11.5px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted);font-weight:600">
          <span style="flex:3;min-width:260px">Nombre</span><span style="width:110px">Código</span><span style="width:170px">Uso de cuenta</span><span style="flex:3;min-width:200px">Descripción</span><span style="width:120px">CABYS</span><span style="width:40px"></span>
        </div>
        <div class="node" v-for="c in visibles" :key="c.codigo" :style="{background: c.nivel===1 ? 'var(--bg)' : ''}">
          <span style="flex:3;min-width:260px;display:flex;align-items:center;gap:6px" :style="{paddingLeft: (q ? 0 : (c.nivel-1)*18) + 'px'}">
            <span class="tog" @click="tog(c)">{{c.hoja ? '·' : (open[c.codigo] ? '▾' : '▸')}}</span>
            <i style="width:9px;height:9px;border-radius:50%;display:inline-block;flex:none" :style="{background:color(c), opacity: c.nivel===1 ? 1 : .55}"></i>
            <b v-if="c.nivel<=2">{{c.nombre}}</b><span v-else :style="{fontWeight: c.hoja ? 400 : 500}">{{c.nombre}}</span>
          </span>
          <span style="width:110px" class="mono">{{c.codigo}}</span>
          <span style="width:170px"><span class="badge" :class="c.uso==='Agrupación' ? '' : 'info'">{{c.uso}}</span></span>
          <span style="flex:3;min-width:200px" class="small muted">{{c.descripcion || '—'}}</span>
          <span style="width:120px" class="mono">{{c.cabys || '—'}}</span>
          <span style="width:40px;text-align:right"><button class="btn icon" v-if="c.hoja && puede('contabilidad')" title="Eliminar" @click="eliminar(c)">🗑</button></span>
        </div>
        <Empty v-if="!visibles.length" icon="≡" title="Sin coincidencias" :text="'Ninguna cuenta coincide con «' + q + '».'"><button class="btn" v-if="puede('contabilidad')" @click="nueva(q)">+ Crear cuenta «{{q}}»</button></Empty>
      </div>
    </div>

    <Modal v-if="modal" title="Nueva cuenta contable" @close="modal=false">
      <div class="grid cols-2">
        <Field label="Cuenta padre" req style="grid-column:1/-1"><select v-model="f.padre"><option v-for="p in padresOpc" :key="p.codigo" :value="p.codigo">{{'  '.repeat(p.nivel-1)}}{{p.codigo}} · {{p.nombre}}</option></select></Field>
        <Field label="Código" req help="Se sugiere el siguiente consecutivo bajo la cuenta padre"><input v-model="f.codigo" class="mono"></Field>
        <Field label="Nombre" req><input v-model="f.nombre" placeholder="Ej. Banco Popular CRC"></Field>
        <Field label="Uso de cuenta" req><select v-model="f.uso"><option v-for="u in USOS" :key="u">{{u}}</option></select></Field>
        <Field label="CABYS" help="Opcional. Código de bienes y servicios asociado"><input v-model="f.cabys" maxlength="13" class="mono"></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea rows="2" v-model="f.descripcion"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="modal=false">Cancelar</button><button class="btn" @click="crear">Guardar</button></template>
    </Modal>
  </div>`,
};
