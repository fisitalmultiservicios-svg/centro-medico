// Activos fijos — lista. Registro 'activos' por empresa; la alta, la depreciación mensual (o anual) y la baja se contabilizan solas
// (asientos automáticos act:/dep:/actb: en contabilidad/automaticos.js).
import { money, fecha, hoy, toast, mock, monedas, sumarMeses } from '../../api.js';
import { sesion } from '../../app.js';

function dias(n) { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); }

export function activosMock() {
  const semilla = [
      { id: 1, clase: 'tangible', nombre: 'Toyota Hilux 2023', referencia: 'VH-001', tipo: 'Vehículos', fecha_adquisicion: dias(400), proveedor: 'Purdy Motor S.A.', costo: 18500000, cantidad: 1, monto_total: 18500000, moneda: 'CRC', cuenta_activo: '1.2.01.06', cuenta_depreciacion: '1.2.02.04', cuenta_gasto: '6.2.03.02.04', valor_residual: 2500000, fecha_inicio: dias(400), metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: 10, porcentaje: 10 },
      { id: 2, clase: 'tangible', nombre: 'Laptops Dell Latitude 5540', referencia: 'EQ-014', tipo: 'Equipo de cómputo', fecha_adquisicion: dias(200), proveedor: 'Grupo Monge', costo: 700000, cantidad: 3, monto_total: 2100000, moneda: 'CRC', cuenta_activo: '1.2.01.05', cuenta_depreciacion: '1.2.02.03', cuenta_gasto: '6.2.03.02.03', valor_residual: 0, fecha_inicio: dias(200), metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: 3, porcentaje: 33.33 },
      { id: 3, clase: 'tangible', nombre: 'Mobiliario de oficina Sabana', referencia: 'MB-003', tipo: 'Mobiliario y equipo de oficina', fecha_adquisicion: dias(600), proveedor: 'Muebles Metálicos Alvarado', costo: 1450000, cantidad: 1, monto_total: 1450000, moneda: 'CRC', cuenta_activo: '1.2.01.04', cuenta_depreciacion: '1.2.02.02', cuenta_gasto: '6.2.03.02.02', valor_residual: 50000, fecha_inicio: dias(600), metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: 10, porcentaje: 10 },
      { id: 4, clase: 'intangible', nombre: 'Licencia ERP contable', referencia: 'IN-001', tipo: 'Software y licencias', fecha_adquisicion: dias(150), proveedor: 'Soluciones TI del Este', costo: 3200000, cantidad: 1, monto_total: 3200000, moneda: 'CRC', cuenta_activo: '1.2.04.01', cuenta_depreciacion: '1.2.05.01', cuenta_gasto: '6.2.03.03', valor_residual: 0, fecha_inicio: dias(150), metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: 5, porcentaje: 20 },
  ];
  return mock.ejemplos('activos', semilla, 'nombre');
}

// Años de vida útil (por vida útil o por porcentaje anual); 0 si no se deprecia (terrenos o sin datos)
export function aniosVida(a) { if (a.tipo === 'Terrenos') return 0; return a.forma === 'Porcentaje' ? (a.porcentaje > 0 ? 100 / a.porcentaje : 0) : (+a.vida_util || 0); }   // (R221)
export function baseDepreciable(a) { return Math.max(0, (+a.monto_total || 0) - (+a.valor_residual || 0)); }
// Períodos COMPLETOS (meses, o años si el período es anual) transcurridos desde el inicio de la depreciación hasta `hasta`
// (hoy, o la fecha de baja si es anterior). Fechas en hora local: con 'AAAA-MM-DD' solo, JS las tomaba en UTC (R64).
// Cantidad total de períodos de la vida útil (36 meses para 3 años o 33,33 % anual; 3 si es anual)
export function totalPeriodos(a) { const anios = aniosVida(a); if (!anios) return 0; return Math.max(1, Math.round(anios * 12 / (a.periodo === 'Anual' ? 12 : 1))); }
export function periodosDepreciados(a, hasta) {
  if (!a.fecha_inicio || !aniosVida(a)) return 0;
  let fin = String(hasta || hoy()).slice(0, 10); if (a.fecha_baja && String(a.fecha_baja).slice(0, 10) < fin) fin = String(a.fecha_baja).slice(0, 10);
  const total = totalPeriodos(a); let n = 0;
  while (n < total && fechaPeriodo(a, n + 1) <= fin) n++;      // un período cuenta cuando se cumple su fecha (fin de mes si el día no existe)
  return n;
}
// Cuota de cada período (mensual o anual)
export function cuota(a) { const t = totalPeriodos(a); if (!t) return 0; return Math.round(baseDepreciable(a) / t * 100) / 100; }
// Depreciación lineal acumulada a la fecha (hoy si no se indica; hasta la baja si la hubo)
export function depreciacion(a, hasta) {
  const n = periodosDepreciados(a, hasta); if (!n) return 0;
  return Math.min(baseDepreciable(a), Math.round(cuota(a) * n * 100) / 100);
}
// Fecha en que se completa el período k (k = 1..n): inicio + k meses (o años)
export function fechaPeriodo(a, k) { return sumarMeses(String(a.fecha_inicio).slice(0, 10), k * (a.periodo === 'Anual' ? 12 : 1)); }   // recorta al último día del mes (31/1 + 1 mes = 28/2)

export default {
  props: ['params'],
  data() { return { activos: activosMock(), q: '', menu: false, ver: null, baja: null }; },
  computed: {
    puedeEditar() { return sesion.puede('contabilidad'); },
    rows() { return this.activos.map(a => { const dep = depreciacion(a); return { ...a, depreciacion: dep, valor_actual: Math.round(((+a.monto_total || 0) - dep) * 100) / 100, estado: a.fecha_baja ? 'Dado de baja' : (a.contabilizar === true ? 'Activo' : 'Sin contabilizar'), periodos: periodosDepreciados(a) }; }); },
    // totales en colones: los activos en otra moneda se convierten con el tipo de cambio actual de esa moneda (R65)
    enCRC() { return this.rows.map(r => { const f = (r.moneda || 'CRC') === 'CRC' ? 1 : monedas.tc(r.moneda); return { costo: r.monto_total * f, dep: r.depreciacion * f, baja: !!r.fecha_baja }; }); },
    columns() {
      return [
        { key: 'nombre', label: 'Nombre', link: r => this.ver = r },
        { key: 'referencia', label: 'Referencia', mono: true },
        { key: 'tipo', label: 'Tipo' },
        { key: 'fecha_adquisicion', label: 'Fecha de adquisición', fmt: 'date' },
        { key: 'monto_total', label: 'Costo', num: true, fmt: 'money' },
        { key: 'depreciacion', label: 'Depreciación acumulada', num: true, fmt: 'money' },
        { key: 'valor_actual', label: 'Valor actual', num: true, fmt: 'money' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
    totCosto() { return this.enCRC.filter(r => !r.baja).reduce((s, r) => s + r.costo, 0); },
    totDep() { return this.enCRC.filter(r => !r.baja).reduce((s, r) => s + r.dep, 0); },
  },
  methods: {
    money, fecha,
    editar(a) { location.hash = '/contabilidad/activos/' + a.id; },
    // CSV con columnas: nombre;referencia;tipo;fecha_adquisicion;costo;cantidad;vida_util;valor_residual;moneda (la primera fila son los encabezados)
    importar(e) {
      const f = e.target.files[0]; if (!f) return; e.target.value = ''; this.menu = false;
      const r = new FileReader();
      r.onload = () => {
        const lineas = String(r.result || '').replace(/^\uFEFF/, '').split(/\r?\n/).filter(l => l.trim()); if (lineas.length < 2) return toast('El archivo no tiene filas (la primera fila debe tener los encabezados)', 'err');
        const sep = lineas[0].includes(';') ? ';' : ','; const cab = lineas[0].split(sep).map(s => s.trim().toLowerCase().replace(/"/g, ''));
        const col = n => cab.indexOf(n); const num = v => +String(v || '').replace(/"/g, '').replace(/\./g, '').replace(',', '.') || 0;
        if (col('nombre') < 0 || col('costo') < 0) return toast('Faltan las columnas obligatorias «nombre» y «costo»', 'err');
        const nuevos = [], base = activosMock(); let n = 0;
        for (const l of lineas.slice(1)) {
          const c = l.split(sep).map(s => s.trim().replace(/^"|"$/g, '')), get = k => (col(k) >= 0 ? c[col(k)] : '');
          const costo = num(get('costo')), cantidad = Math.max(1, Math.round(num(get('cantidad')) || 1)); if (!get('nombre') || !(costo > 0)) continue;
          const fechaAdq = /^\d{4}-\d{2}-\d{2}$/.test(get('fecha_adquisicion')) ? get('fecha_adquisicion') : hoy();
          nuevos.push({ id: mock.nextId([...base, ...nuevos], 'activos'), clase: 'tangible', nombre: get('nombre'), referencia: get('referencia'), tipo: get('tipo') || 'Equipo de cómputo', fecha_adquisicion: fechaAdq, proveedor: get('proveedor'), costo, cantidad, monto_total: Math.round(costo * cantidad * 100) / 100,
            moneda: (get('moneda') || monedas.principal().codigo).toUpperCase(), cuenta_activo: '1.2.01.05', cuenta_depreciacion: '1.2.02.03', cuenta_gasto: '6.2.03.02.03', valor_residual: num(get('valor_residual')), fecha_inicio: fechaAdq, metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: Math.max(1, Math.round(num(get('vida_util')) || 3)), porcentaje: 33.33, contabilizar: false, pago: 'credito', iva: 0 });
          n++;
        }
        if (!n) return toast('No se encontró ninguna fila válida (nombre y costo mayor que cero)', 'err');
        this.activos = mock.actualizar('activos', l => [...(Array.isArray(l) ? l : []), ...nuevos], []);
        toast(n + ' activos importados sin contabilizar: revise las cuentas de cada uno y marque «Contabilizar»', 'ok');
      };
      r.readAsText(f, 'utf-8');
    },
    darDeBaja(a) { this.baja = { id: a.id, nombre: a.nombre, fecha: hoy(), motivo: '' }; this.ver = null; },
    confirmarBaja() {
      const b = this.baja; if (!b || !b.fecha) return toast('Indique la fecha de la baja', 'err');
      this.activos = mock.actualizar('activos', l => (l || []).map(x => (x.id === b.id ? { ...x, fecha_baja: b.fecha, baja_motivo: b.motivo } : x)), []);
      this.baja = null; toast('Activo «' + b.nombre + '» dado de baja: el asiento de baja se genera en Asientos contables', 'ok');
    },
    reactivar(a) { if (!confirm('¿Anular la baja de «' + a.nombre + '»?')) return; this.activos = mock.actualizar('activos', l => (l || []).map(x => (x.id === a.id ? { ...x, fecha_baja: null, baja_motivo: '' } : x)), []); this.ver = null; toast('Baja anulada', 'ok'); },
    eliminar(a) { if (!confirm('¿Eliminar el activo «' + a.nombre + '»? Sus asientos automáticos (alta, depreciación y baja) se eliminarán al sincronizar.')) return; this.activos = mock.actualizar('activos', l => (l || []).filter(x => x.id !== a.id), []); this.ver = null; toast('Activo eliminado'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.activos = mock.actualizar('activos', l => (l || []).filter(x => !ids.includes(x.id)), []); toast(ids.length + ' activos eliminados', 'ok'); },
  },
  template: `
  <div class="page">
    <PageHead title="Activos" sub="Activos fijos tangibles e intangibles: alta, depreciación mensual o anual y baja, contabilizadas automáticamente en Asientos contables.">
      <div class="row" style="gap:0;position:relative" v-if="puedeEditar">
        <a class="btn" href="#/contabilidad/activos/nuevo" style="border-radius:7px 0 0 7px">+ Nuevo activo</a>
        <button class="btn" style="border-radius:0 7px 7px 0;border-left-color:rgba(255,255,255,.4);padding:8px 10px" @click="menu=!menu">▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:230px;padding:6px">
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/contabilidad/activos/nuevo">Crear activo</a>
          <label class="item" style="display:block;padding:8px 10px;cursor:pointer" title="CSV con columnas nombre;referencia;tipo;fecha_adquisicion;costo;cantidad;vida_util;valor_residual;moneda">Importar desde CSV<input type="file" accept=".csv,.txt" style="display:none" @change="importar"></label>
        </div>
      </div>
    </PageHead>

    <div class="dash" style="margin-bottom:18px" v-if="activos.length">
      <div class="kpi w4"><div class="t">Costo total de activos (₡)</div><div class="v">{{money(totCosto)}}</div><div class="d">{{activos.length}} activos registrados</div></div>
      <div class="kpi w4"><div class="t">Depreciación acumulada</div><div class="v">{{money(totDep)}}</div><div class="bar"><i :style="{width: (totCosto ? totDep/totCosto*100 : 0)+'%'}"></i></div></div>
      <div class="kpi w4"><div class="t">Valor en libros</div><div class="v">{{money(totCosto - totDep)}}</div><div class="d">costo − depreciación acumulada</div></div>
    </div>

    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar por nombre, referencia o tipo" v-model="q"><button class="btn ghost sm">⚲ Filtrar</button></div>
      <DataTable :rows="rows" :columns="columns" :search="q" selectable :on-bulk-delete="eliminarVarios" empty-title="Aún no tienes activos registrados" empty-text="Registra tus activos fijos para llevar el control de su depreciación y valor en libros." @row-click="ver=$event">
        <template #actions="{row}"><button class="btn icon" title="Ver" @click.stop="ver=row">👁</button><button class="btn icon" v-if="puedeEditar" title="Editar" @click.stop="editar(row)">✎</button><button class="btn icon" v-if="puedeEditar" title="Eliminar" @click.stop="eliminar(row)">🗑</button></template>
        <template #empty><a class="btn" href="#/contabilidad/activos/nuevo" v-if="puedeEditar">+ Nuevo activo</a></template>
      </DataTable>
    </div>

    <Modal v-if="ver" :title="ver.nombre" @close="ver=null">
      <div class="row" style="margin-bottom:12px"><span class="chip on">{{ver.clase==='intangible' ? 'Intangible' : 'Tangible'}}</span><span class="chip">{{ver.tipo}}</span><span class="chip mono" v-if="ver.referencia">{{ver.referencia}}</span></div>
      <div class="grid cols-2">
        <div><div class="small muted">Fecha de adquisición</div><b>{{fecha(ver.fecha_adquisicion)}}</b></div>
        <div><div class="small muted">Proveedor</div><b>{{ver.proveedor||'—'}}</b></div>
        <div><div class="small muted">Costo ({{ver.cantidad}} × {{money(ver.costo)}})</div><b>{{money(ver.monto_total)}}</b></div>
        <div><div class="small muted">Valor residual</div><b>{{money(ver.valor_residual)}}</b></div>
        <div><div class="small muted">Método</div><b>{{ver.metodo}} · {{ver.periodo}} · {{ver.forma==='Porcentaje' ? ver.porcentaje+' % anual' : ver.vida_util+' años'}}</b></div>
        <div><div class="small muted">Inicio de depreciación</div><b>{{fecha(ver.fecha_inicio)}}</b></div>
        <div><div class="small muted">Depreciación acumulada ({{ver.periodos}} {{ver.periodo==='Anual' ? 'años' : 'meses'}})</div><b style="color:var(--danger)">{{money(ver.depreciacion, ver.moneda)}}</b></div>
        <div><div class="small muted">Valor en libros</div><b style="color:var(--ok)">{{money(ver.valor_actual, ver.moneda)}}</b></div>
        <div><div class="small muted">Contabilización</div><b>{{ver.contabilizar===true ? 'Alta y depreciación automáticas' : 'No se contabiliza (actívela al editar el activo)'}}</b></div>
        <div v-if="ver.fecha_baja"><div class="small muted">Baja</div><b>{{fecha(ver.fecha_baja)}}</b> <span class="small muted">{{ver.baja_motivo}}</span></div>
        <div style="grid-column:1/-1"><div class="small muted">Cuentas contables</div><span class="mono">{{ver.cuenta_activo}}</span> activo · <span class="mono">{{ver.cuenta_depreciacion}}</span> dep. acumulada · <span class="mono">{{ver.cuenta_gasto}}</span> gasto</div>
      </div>
      <template #foot><template v-if="puedeEditar"><button class="btn danger" @click="eliminar(ver)">Eliminar</button><button class="btn sec" v-if="!ver.fecha_baja" @click="darDeBaja(ver)">Dar de baja</button><button class="btn sec" v-else @click="reactivar(ver)">Anular baja</button><button class="btn sec" @click="editar(ver)">Editar</button></template><button class="btn" @click="ver=null">Cerrar</button></template>
    </Modal>
    <Modal v-if="baja" :title="'Dar de baja: ' + baja.nombre" @close="baja=null">
      <p class="small muted">La baja detiene la depreciación y genera el asiento que saca el activo y su depreciación acumulada de los libros; el valor en libros pendiente se lleva a la cuenta de gasto del activo.</p>
      <div class="grid"><Field label="Fecha de baja" req><input type="date" v-model="baja.fecha"></Field><Field label="Motivo"><input v-model="baja.motivo" placeholder="Venta, obsolescencia, pérdida, donación…"></Field></div>
      <template #foot><button class="btn ghost" @click="baja=null">Cancelar</button><button class="btn danger" @click="confirmarBaja">Dar de baja</button></template>
    </Modal>
  </div>`,
};
