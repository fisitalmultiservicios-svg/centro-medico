// Saldos iniciales — saldos de apertura por cuenta. Se guardan como un asiento SI-n en el registro 'asientos'; si ya existe uno se
// carga para corregirlo. Importación desde CSV (codigo;saldo;contacto).
import { money, hoy, toast, mock, monedas } from '../../api.js';
import { store } from '../../app.js';
import { planCuentas, COLOR_RAIZ } from './catalogo.js';
import { asientosMock } from './asientos.js';
import { periodoCerrado } from './parametros.js';
import { esDeudora } from './_mayor.js';

const SECCIONES = [
  { id: 'sf', titulo: 'Situación financiera', sub: 'Activos, pasivos y patrimonio', raices: ['1', '2', '3'] },
  { id: 'er', titulo: 'Estado de resultados', sub: 'Ingresos, costos y gastos acumulados del período', raices: ['4', '5', '6'] },
  { id: 'co', titulo: 'Cuentas de orden', sub: 'Registros de control', raices: ['7'] },
];

export default {
  props: ['params'],
  data() {
    const plan = planCuentas();
    const open = {}; for (const c of plan) if (c.nivel <= 2) open[c.codigo] = true;
    // si ya hay saldos iniciales guardados (el SI más reciente), se cargan para corregirlos en vez de crear otro
    const existentes = asientosMock().filter(a => (a.codigo || '').startsWith('SI-')).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)) || b.id - a.id);
    const ed = existentes[0] || null, saldos = {}, contactos = {};
    if (ed) for (const l of ed.lineas || []) { const c = plan.find(x => x.codigo === l.cuenta); const deudora = esDeudora(l.cuenta); const v = (+l.debito || 0) - (+l.credito || 0); saldos[l.cuenta] = Math.round((deudora ? v : -v) * 100) / 100; if (l.contacto) contactos[l.cuenta] = l.contacto; }
    return { plan, SECCIONES, COLOR_RAIZ, abierta: { sf: true, er: false, co: false }, open, saldos, contactos, editando: ed, f: { fecha: ed ? ed.fecha : hoy(), numeracion: 'SI' } };
  },
  computed: {
    store() { return store; },
    codigo() { if (this.editando) return this.editando.codigo; const n = asientosMock().filter(a => (a.codigo || '').startsWith('SI-')).reduce((m, a) => Math.max(m, +String(a.codigo).split('-')[1] || 0), 0) + 1; return 'SI-' + n; },   // mayor + 1, no cantidad + 1 (R217)
    totalActivos() { return this.suma('1'); },
    totalPasivoPat() { return this.suma('2') + this.suma('3') + this.suma('4') - this.suma('5') - this.suma('6'); },
    diferencia() { return +(this.totalActivos - this.totalPasivoPat).toFixed(2); },
    conSaldo() { return Object.values(this.saldos).filter(v => +v).length; },
  },
  methods: {
    money(v) { return money(v, monedas.principal().codigo); },   // 4.1: los saldos van en la moneda principal (antes siempre ₡)
    suma(prefijo) { let s = 0; for (const c of this.plan) if (c.hoja && (c.codigo === prefijo || c.codigo.startsWith(prefijo + '.'))) s += +this.saldos[c.codigo] || 0; return s; },
    nodos(sec) {
      return this.plan.filter(c => {
        if (!sec.raices.includes(c.raiz)) return false;
        let p = c.padre; while (p) { if (!this.open[p]) return false; p = p.includes('.') ? p.slice(0, p.lastIndexOf('.')) : null; }
        return true;
      });
    },
    tog(c) { if (!c.hoja) this.open[c.codigo] = !this.open[c.codigo]; },
    // depreciación acumulada, deterioro, pérdidas acumuladas, dividendos, devoluciones en ventas: saldo contrario a su raíz (R63)
    correctora(c) { return /deprec|deterioro|amortizaci|p[ée]rdidas? acumulad|dividendo|estimaci[oó]n/i.test(c.nombre || '') || (/devoluc/i.test(c.nombre || '') && ['4', '5'].includes(c.raiz)); },
    totalSeccion(sec) { return sec.raices.reduce((s, r) => s + this.suma(r), 0); },
    limpiar() { if (confirm('¿Borrar todos los saldos ingresados?')) { this.saldos = {}; this.contactos = {}; } },
    // CSV: codigo;saldo;contacto (la primera fila puede ser el encabezado). Solo cuentas de movimiento del catálogo.
    importar(e) {
      const f = e.target.files[0]; if (!f) return; e.target.value = '';
      const r = new FileReader();
      r.onload = () => {
        const lineas = String(r.result || '').replace(/^\uFEFF/, '').split(/\r?\n/).filter(l => l.trim()); let n = 0, desconocidas = [];
        for (const l of lineas) {
          const sep = l.includes(';') ? ';' : ','; const c = l.split(sep).map(s => s.trim().replace(/^"|"$/g, ''));
          if (!/^\d+(\.\d+)*$/.test(c[0] || '')) continue;
          const cta = this.plan.find(x => x.codigo === c[0]); if (!cta || !cta.hoja) { desconocidas.push(c[0]); continue; }
          const v = +String(c[1] || '').replace(/\s/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.'); if (!isFinite(v)) continue;
          this.saldos[cta.codigo] = Math.round(v * 100) / 100; if (c[2]) this.contactos[cta.codigo] = c[2]; n++;
        }
        toast(n + ' saldos cargados' + (desconocidas.length ? '; sin cuenta de movimiento en el catálogo: ' + desconocidas.slice(0, 5).join(', ') : '') + '. Revise y guarde.', n ? 'ok' : 'err');
      };
      r.readAsText(f, 'utf-8');
    },
    guardar() {
      if (this.diferencia !== 0) return toast('Los saldos no cuadran: TOTAL ACTIVOS debe ser igual a TOTAL PASIVOS + PATRIMONIO.', 'err');
      { const per = periodoCerrado(this.f.fecha); if (per) return toast('El periodo ' + per.mes + ' ' + per.anio + ' está cerrado: reábralo en Configuración › Periodos contables o cambie la fecha', 'err'); }
      if (Math.abs(this.suma('7.1') - this.suma('7.2')) > 0.005) return toast('Las cuentas de orden deudoras (7.1) y acreedoras (7.2) deben sumar lo mismo', 'err');   // (R62)
      if (!this.conSaldo) return toast('Ingrese al menos un saldo', 'err');
      const lineas = [];
      for (const c of this.plan) {
        const v = +this.saldos[c.codigo]; if (!c.hoja || !v) continue;
        const deudora = esDeudora(c.codigo);
        lineas.push({ cuenta: c.codigo, cuenta_nombre: c.nombre, contacto: this.contactos[c.codigo] || '', documento: '', descripcion: 'Saldo inicial', debito: deudora ? (v > 0 ? v : 0) : (v < 0 ? -v : 0), credito: deudora ? (v < 0 ? -v : 0) : (v > 0 ? v : 0) });
      }
      if (this.editando) {
        const a = { ...this.editando, fecha: this.f.fecha, observaciones: 'Saldos iniciales al ' + this.f.fecha, lineas };
        mock.actualizar('asientos', l => (l || []).map(x => (x.id === a.id ? a : x)), []);
        toast('Saldos iniciales ' + a.codigo + ' actualizados (' + lineas.length + ' cuentas)', 'ok');
        location.hash = '/contabilidad/asientos'; return;
      }
      const a = { id: mock.nextId(asientosMock(), 'asientos'), codigo: this.codigo, fecha: this.f.fecha, tipo: 'Saldos iniciales', numeracion: 'SI', observaciones: 'Saldos iniciales al ' + this.f.fecha, lineas };
      mock.actualizar('asientos', l => [...(Array.isArray(l) ? l : []), a], []);
      toast('Saldos iniciales ' + a.codigo + ' guardados (' + lineas.length + ' cuentas)', 'ok');
      location.hash = '/contabilidad/asientos';
    },
  },
  template: `
  <div class="page" style="padding-bottom:90px">
    <PageHead title="Saldos iniciales" :sub="(editando ? 'Está corrigiendo los saldos iniciales ' + editando.codigo + '. ' : '') + 'Ingrese los saldos de apertura de cada cuenta. Los saldos de las cuentas padre se calculan automáticamente.'" :crumbs="[{label:'Asientos contables',to:'/contabilidad/asientos'},{label:'Saldos iniciales'}]">
      <label class="btn ghost" style="cursor:pointer" title="CSV: codigo;saldo;contacto">⤒ Importar CSV<input type="file" accept=".csv,.txt" style="display:none" @change="importar"></label>
      <a class="btn ghost" href="#/contabilidad/asientos">Posponer</a>
      <button class="btn" :disabled="diferencia!==0 || !conSaldo" @click="guardar">Guardar</button>
    </PageHead>

    <div class="card"><div class="grid cols-3">
      <Field label="Fecha" req help="Fecha de corte de los saldos de apertura"><input type="date" v-model="f.fecha"></Field>
      <Field label="Numeración" req><select v-model="f.numeracion"><option value="SI">Saldos iniciales (SI)</option></select></Field>
      <Field label="Código"><input :value="codigo" disabled class="mono"></Field>
    </div></div>

    <div class="card pad0" v-for="sec in SECCIONES" :key="sec.id" style="margin-bottom:14px">
      <div class="row" style="padding:14px 16px;cursor:pointer;justify-content:space-between" @click="abierta[sec.id]=!abierta[sec.id]">
        <div><b>{{abierta[sec.id] ? '▾' : '▸'}} {{sec.titulo}}</b> <span class="small muted" style="margin-left:8px">{{sec.sub}}</span></div>
        <b>{{money(totalSeccion(sec))}}</b>
      </div>
      <div class="tree" v-show="abierta[sec.id]" style="border-top:1px solid var(--line)">
        <div class="node" style="background:#fafbfc;font-size:11.5px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted);font-weight:600"><span style="flex:3;min-width:260px">Cuenta</span><span style="width:220px">Contacto</span><span style="width:170px;text-align:right">Saldo</span></div>
        <div class="node" v-for="c in nodos(sec)" :key="c.codigo">
          <span style="flex:3;min-width:260px;display:flex;align-items:center;gap:6px" :style="{paddingLeft:(c.nivel-1)*18+'px'}">
            <span class="tog" @click="tog(c)">{{c.hoja ? '·' : (open[c.codigo] ? '▾' : '▸')}}</span>
            <i style="width:9px;height:9px;border-radius:50%;display:inline-block;flex:none" :style="{background:COLOR_RAIZ[c.raiz]}"></i>
            <span class="mono muted">{{c.codigo}}</span><b v-if="!c.hoja">{{c.nombre}}</b><span v-else>{{c.nombre}}</span>
          </span>
          <span style="width:220px"><Buscador v-if="c.hoja" v-model="contactos[c.codigo]" :opciones="store.clientes" valor="nombre" detalle="numero_id" agregar="contacto"></Buscador></span>
          <span style="width:170px;text-align:right">
            <input class="inp" v-if="c.hoja" type="number" step="0.01" v-model.number="saldos[c.codigo]" :placeholder="correctora(c) ? 'en negativo' : '0,00'" :title="correctora(c) ? 'Cuenta correctora: digite el saldo en negativo' : ''" style="width:100%;text-align:right;padding:5px 8px">
            <b v-else>{{money(suma(c.codigo))}}</b>
          </span>
        </div>
      </div>
    </div>

    <div class="card" style="position:fixed;left:0;right:0;bottom:0;margin:0;border-radius:0;z-index:30;padding:12px 24px;display:flex;gap:28px;align-items:center;flex-wrap:wrap;justify-content:flex-end">
      <div><div class="small muted">TOTAL ACTIVOS</div><b style="font-size:17px">{{money(totalActivos)}}</b></div>
      <div class="muted">vs</div>
      <div><div class="small muted">TOTAL PASIVOS + PATRIMONIO <span title="Incluye el resultado del período (ingresos − costos − gastos)">ⓘ</span></div><b style="font-size:17px">{{money(totalPasivoPat)}}</b></div>
      <div><div class="small muted">Diferencia</div><b style="font-size:17px" :style="{color: diferencia===0 ? 'var(--ok)' : 'var(--danger)'}">{{money(diferencia)}}</b></div>
      <button class="btn ghost sm" @click="limpiar">Limpiar</button>
      <button class="btn" :disabled="diferencia!==0 || !conSaldo" @click="guardar">Guardar</button>
    </div>
  </div>`,
};
