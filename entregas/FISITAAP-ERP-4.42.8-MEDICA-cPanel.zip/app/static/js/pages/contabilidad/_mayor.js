// Motor de saldos contables sobre los asientos (registro 'asientos') y el catálogo: mayor por cuenta, balance de prueba,
// balance general, estado de resultados, libro mayor con saldo corrido, cierre anual y control de periodos cerrados.
// Montos en la moneda principal (los asientos ya vienen convertidos). Naturaleza deudora: 1 activos, 5 costos, 6 gastos y 7.1
// (orden deudoras); acreedora: 2 pasivos, 3 patrimonio, 4 ingresos y 7.2. Un saldo «natural» positivo es lo normal de la cuenta;
// negativo indica saldo contrario (cuenta correctora o error).
import { mock, hoy } from '../../api.js';
import { planCuentas } from './catalogo.js';
import { asientosMock } from './asientos.js';
import { sincronizarAutomaticos } from './automaticos.js';
import { paramContable, cuentaDe, periodoCerrado, fechaAbierta } from './parametros.js';
export { periodoCerrado, fechaAbierta };

const r2 = n => Math.round((+n || 0) * 100) / 100;
export const NOMBRE_RAIZ = { 1: 'Activos', 2: 'Pasivos', 3: 'Patrimonio', 4: 'Ingresos', 5: 'Costos', 6: 'Gastos', 7: 'Cuentas de orden', 8: 'Transferencias' };
export function esDeudora(codigo) { const c = String(codigo || ''); return ['1', '5', '6', '8'].includes(c[0]) || c === '7.1' || c.startsWith('7.1.'); }
function padreDe(codigo) { const i = codigo.lastIndexOf('.'); return i < 0 ? null : codigo.slice(0, i); }

// Asientos al día (regenera los automáticos si el rol puede) y catálogo con todas las cuentas que aparecen en asientos
export async function cargarAsientos() { try { await sincronizarAutomaticos(); } catch {} return asientosMock(); }
export function planConUsadas(asientos, plan) {
  const l = (plan || planCuentas()).slice(), tiene = new Set(l.map(c => c.codigo));
  for (const a of asientos || []) for (const x of a.lineas || []) if (x.cuenta && !tiene.has(x.cuenta)) { tiene.add(x.cuenta); l.push({ codigo: x.cuenta, nombre: x.cuenta_nombre || '(cuenta eliminada del catálogo)', uso: 'Agrupación', padre: padreDe(x.cuenta), nivel: x.cuenta.split('.').length, raiz: x.cuenta.split('.')[0], hoja: true, fuera: true }); }
  const k = c => c.codigo.split('.').map(x => x.padStart(4, '0')).join('.');
  return l.sort((a, b) => k(a).localeCompare(k(b)));
}

// Saldos por cuenta: {codigo: {cuenta, nombre, nivel, raiz, hoja, deudora, inicial, debitos, creditos, final}} con los padres
// acumulando a sus hijas. inicial = movimientos anteriores a `desde` (si no hay desde, 0); todo hasta `hasta` inclusive.
// inicial y final llevan el signo de la naturaleza de la cuenta (positivo = saldo normal).
export function saldos(asientos, plan, desde, hasta) {
  const mov = {};
  for (const a of asientos || []) {
    const f = String(a.fecha || '').slice(0, 10); if (hasta && f > hasta) continue;
    // el asiento de cierre anual no es movimiento del período (dejaría el estado de resultados del año en cero): con `desde`
    // solo cuenta como saldo inicial si es anterior; sin `desde` (balance general) entra en el acumulado
    const anterior = desde && f < desde;
    if (a.cierre && desde && !anterior) continue;
    for (const l of a.lineas || []) {
      if (!l.cuenta) continue;
      const x = mov[l.cuenta] = mov[l.cuenta] || { ini: 0, d: 0, c: 0 };
      if (anterior) x.ini += (+l.debito || 0) - (+l.credito || 0); else { x.d += +l.debito || 0; x.c += +l.credito || 0; }
    }
  }
  const out = {};
  for (const c of plan) out[c.codigo] = { cuenta: c.codigo, nombre: c.nombre, nivel: c.nivel, raiz: c.raiz, hoja: c.hoja, padre: c.padre, uso: c.uso, deudora: esDeudora(c.codigo), ini: 0, d: 0, c: 0 };
  for (const [codigo, x] of Object.entries(mov)) {
    let p = codigo;
    while (p) { const o = out[p]; if (o) { o.ini += x.ini; o.d += x.d; o.c += x.c; } p = padreDe(p); }
  }
  for (const o of Object.values(out)) {
    const sg = o.deudora ? 1 : -1;
    o.inicial = r2(sg * o.ini); o.debitos = r2(o.d); o.creditos = r2(o.c); o.final = r2(sg * (o.ini + o.d - o.c)); o.movimiento = r2(sg * (o.d - o.c));
    delete o.ini; delete o.d; delete o.c;
  }
  return out;
}
const conSaldo = o => Math.abs(o.inicial) > 0.004 || o.debitos > 0.004 || o.creditos > 0.004 || Math.abs(o.final) > 0.004;
export function sangria(o) { return ' '.repeat(Math.max(0, o.nivel - 1) * 3) + o.nombre; }

// Balance de prueba del período: solo cuentas de movimiento (hojas) con saldo o movimiento; totales de débitos y créditos
export function balancePrueba(asientos, plan, desde, hasta) {
  const s = saldos(asientos, plan, desde, hasta);
  const rows = Object.values(s).filter(o => o.hoja && conSaldo(o)).map(o => ({ id: o.cuenta, ...o }));
  const tot = rows.reduce((t, o) => ({ debitos: t.debitos + o.debitos, creditos: t.creditos + o.creditos, inicialD: t.inicialD + (o.deudora ? o.inicial : 0), inicialC: t.inicialC + (o.deudora ? 0 : o.inicial), finalD: t.finalD + (o.deudora ? o.final : 0), finalC: t.finalC + (o.deudora ? 0 : o.final) }), { debitos: 0, creditos: 0, inicialD: 0, inicialC: 0, finalD: 0, finalC: 0 });
  return { rows, totales: Object.fromEntries(Object.entries(tot).map(([k, v]) => [k, r2(v)])), cuadra: Math.abs(tot.debitos - tot.creditos) < 0.01 };
}

// Estado de resultados del período: ingresos (4) − costos (5) − gastos (6) con el movimiento del período (no el acumulado)
export function estadoResultados(asientos, plan, desde, hasta) {
  const s = saldos(asientos, plan, desde, hasta);
  const grupo = r => Object.values(s).filter(o => o.raiz === r && Math.abs(o.movimiento) > 0.004).map(o => ({ id: o.cuenta, cuenta: o.cuenta, nombre: sangria(o), monto: o.movimiento, nivel: o.nivel, hoja: o.hoja }));
  const total = r => r2(Object.values(s).filter(o => o.raiz === r && o.nivel === 1).reduce((t, o) => t + o.movimiento, 0));
  const ingresos = total('4'), costos = total('5'), gastos = total('6');
  const rows = [...grupo('4'), ...grupo('5'), ...grupo('6')];
  return { rows, ingresos, costos, gastos, bruta: r2(ingresos - costos), neta: r2(ingresos - costos - gastos) };
}

// Balance general a una fecha: activos (1), pasivos (2) y patrimonio (3) acumulados desde el inicio, más el resultado
// acumulado no cerrado (4 − 5 − 6 hasta la fecha) como línea del patrimonio.
export function balanceGeneral(asientos, plan, hasta, param) {
  const s = saldos(asientos, plan, null, hasta);
  const grupo = r => Object.values(s).filter(o => o.raiz === r && Math.abs(o.final) > 0.004).map(o => ({ id: o.cuenta, cuenta: o.cuenta, nombre: sangria(o), saldo: o.final, nivel: o.nivel, hoja: o.hoja, raiz: r }));
  const total = r => r2(Object.values(s).filter(o => o.raiz === r && o.nivel === 1).reduce((t, o) => t + o.final, 0));
  const activos = total('1'), pasivos = total('2'), patrimonioCtas = total('3');
  const resultado = r2(total('4') - total('5') - total('6'));
  const p = param || paramContable(), cr = cuentaDe(p.resultado);
  const rows = [...grupo('1'), ...grupo('2'), ...grupo('3')];
  if (Math.abs(resultado) > 0.004) rows.push({ id: 'resultado', cuenta: cr.cuenta || '3.3', nombre: '  ' + (resultado >= 0 ? 'Utilidad' : 'Pérdida') + ' acumulada del período (sin cerrar)', saldo: resultado, nivel: 2, hoja: true, raiz: '3', virtual: true });
  const patrimonio = r2(patrimonioCtas + resultado);
  return { rows, activos, pasivos, patrimonio, resultado, diferencia: r2(activos - pasivos - patrimonio) };
}

// Libro mayor: por cada cuenta de movimiento con actividad, su saldo inicial y los movimientos del período con saldo corrido.
// `cuenta`: solo esa cuenta (o sus subcuentas si es de agrupación).
export function libroMayor(asientos, plan, desde, hasta, cuenta) {
  const nombres = Object.fromEntries(plan.map(c => [c.codigo, c.nombre]));
  const pertenece = c => !cuenta || c === cuenta || c.startsWith(cuenta + '.');
  const ini = {}, lineas = [];
  for (const a of (asientos || []).slice().sort((x, y) => String(x.fecha).localeCompare(String(y.fecha)) || (x.id - y.id))) {
    const f = String(a.fecha || '').slice(0, 10); if (hasta && f > hasta) continue;
    for (const l of a.lineas || []) {
      if (!l.cuenta || !pertenece(l.cuenta)) continue;
      if (desde && f < desde) { ini[l.cuenta] = (ini[l.cuenta] || 0) + (+l.debito || 0) - (+l.credito || 0); continue; }
      lineas.push({ cuenta: l.cuenta, fecha: f, asiento: a.codigo, tipo: a.tipo, descripcion: l.descripcion || a.observaciones || '', contacto: l.contacto || '', documento: l.documento || '', debito: +l.debito || 0, credito: +l.credito || 0 });
    }
  }
  const cuentas = [...new Set([...Object.keys(ini), ...lineas.map(l => l.cuenta)])].sort((a, b) => a.split('.').map(x => x.padStart(4, '0')).join('.').localeCompare(b.split('.').map(x => x.padStart(4, '0')).join('.')));
  const rows = []; let n = 0;
  for (const c of cuentas) {
    const sg = esDeudora(c) ? 1 : -1, nombre = nombres[c] || '(cuenta eliminada del catálogo)';
    let saldo = r2(sg * (ini[c] || 0));
    const mov = lineas.filter(l => l.cuenta === c);
    if (!mov.length && Math.abs(saldo) < 0.005) continue;
    rows.push({ id: 'i' + (n++), cuenta: c, nombre, fecha: desde || '', asiento: '', descripcion: 'Saldo inicial', debito: null, credito: null, saldo, inicial: true });
    for (const l of mov) { saldo = r2(saldo + sg * (l.debito - l.credito)); rows.push({ id: 'm' + (n++), nombre, ...l, saldo }); }
    rows.push({ id: 'f' + (n++), cuenta: c, nombre, fecha: hasta || '', asiento: '', descripcion: 'Saldo final', debito: r2(mov.reduce((t, l) => t + l.debito, 0)), credito: r2(mov.reduce((t, l) => t + l.credito, 0)), saldo, final: true });
  }
  return rows;
}

// Auxiliar de terceros: débitos, créditos y saldo por contacto (líneas con contacto) en el período
export function auxiliarTerceros(asientos, desde, hasta, tipoDe) {
  const m = {};
  for (const a of asientos || []) {
    const f = String(a.fecha || '').slice(0, 10); if ((desde && f < desde) || (hasta && f > hasta)) continue;
    for (const l of a.lineas || []) {
      const t = String(l.contacto || '').trim(); if (!t) continue;
      const x = m[t] = m[t] || { id: t, tercero: t, tipo: tipoDe ? tipoDe(t) : '', movimientos: 0, debito: 0, credito: 0 };
      x.movimientos++; x.debito += +l.debito || 0; x.credito += +l.credito || 0;
    }
  }
  return Object.values(m).map(x => ({ ...x, debito: r2(x.debito), credito: r2(x.credito), saldo: r2(x.debito - x.credito) })).sort((a, b) => b.debito + b.credito - a.debito - a.credito);
}

// Asiento de cierre del año: salda ingresos, costos y gastos al 31/12 y lleva la utilidad o pérdida a la cuenta de resultado
// de Parametrización. Devuelve null si no hay nada que cerrar.
export function asientoCierre(asientos, plan, anio, param) {
  const hasta = anio + '-12-31', s = saldos(asientos, plan, null, hasta), p = param || paramContable();
  const lineas = [];
  for (const o of Object.values(s)) {
    if (!o.hoja || !['4', '5', '6'].includes(o.raiz)) continue;
    const dh = o.deudora ? o.final : -o.final;      // débitos − créditos acumulados
    if (Math.abs(dh) < 0.005) continue;
    lineas.push({ cuenta: o.cuenta, cuenta_nombre: o.nombre, contacto: '', documento: '', descripcion: 'Cierre del período ' + anio, debito: dh < 0 ? r2(-dh) : 0, credito: dh > 0 ? r2(dh) : 0 });
  }
  if (!lineas.length) return null;
  const resultado = r2(lineas.reduce((t, l) => t + l.debito - l.credito, 0));   // se debitan los ingresos y se acreditan costos y gastos: utilidad si > 0
  const cr = cuentaDe(p.resultado);
  lineas.push({ cuenta: cr.cuenta, cuenta_nombre: cr.nombre, contacto: '', documento: '', descripcion: (resultado >= 0 ? 'Utilidad' : 'Pérdida') + ' del ejercicio ' + anio, debito: resultado < 0 ? r2(-resultado) : 0, credito: resultado > 0 ? resultado : 0 });
  const n = (asientos || []).filter(a => (a.codigo || '').startsWith('CI-')).reduce((m, a) => Math.max(m, +String(a.codigo).split('-')[1] || 0), 0) + 1;
  return { codigo: 'CI-' + n, fecha: hasta, tipo: 'Cierre de período', numeracion: 'CI', observaciones: 'Cierre del ejercicio ' + anio, lineas, cierre: +anio, resultado };
}
