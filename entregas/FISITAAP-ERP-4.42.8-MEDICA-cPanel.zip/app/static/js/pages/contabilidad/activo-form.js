// Activo fijo — formulario de alta y edición. Registro 'activos'; la alta, la depreciación y la baja se contabilizan solas (automaticos.js).
import { money, fecha, hoy, toast, mock, monedas } from '../../api.js';
import { store } from '../../app.js';
import { planCuentas } from './catalogo.js';
import { activosMock, depreciacion, cuota, periodosDepreciados } from './activos.js';
import { cuentasActivas } from '../bancos/cuentas.js';

const TIPOS = { tangible: ['Vehículos', 'Equipo de cómputo', 'Mobiliario y equipo de oficina', 'Maquinaria y equipo', 'Edificios', 'Terrenos', 'Mejoras a propiedades arrendadas'], intangible: ['Software y licencias', 'Marcas y patentes', 'Derechos de llave'] };
const nuevo = () => ({ clase: 'tangible', nombre: '', referencia: '', tipo: 'Equipo de cómputo', fecha_adquisicion: hoy(), proveedor: '', costo: null, cantidad: 1, moneda: monedas.principal().codigo, cuenta_activo: '1.2.01.05',
  cuenta_depreciacion: '1.2.02.03', cuenta_gasto: '6.2.03.02.03', valor_residual: 0, fecha_inicio: hoy(), metodo: 'Lineal', periodo: 'Mensual', forma: 'Vida útil', vida_util: 3, porcentaje: 33.33, contabilizar: true, pago: 'credito', cuenta_banco: '', iva: 0, tipo_cambio: null, foto: null, documentos: [] });

export default {
  props: ['params'],
  data() {
    const id = this.params && this.params.id && this.params.id !== 'nuevo' ? +this.params.id : null;
    const ex = id ? activosMock().find(a => a.id === id) : null;
    const f = ex ? { ...nuevo(), ...ex, documentos: Array.isArray(ex.documentos) ? ex.documentos.slice() : [] } : nuevo();
    return { f, editando: ex || null, plan: planCuentas().filter(c => c.hoja), TIPOS, avanzado: false, monedasOpc: monedas.opciones(), cuentasBanco: cuentasActivas().map(b => b.nombre) };
  },
  computed: {
    store() { return store; },
    periodosHoy() { return periodosDepreciados({ ...this.f, monto_total: this.montoTotal }); },
    enOtraMoneda() { return this.f.moneda && this.f.moneda !== monedas.principal().codigo; },
    // Activos fijos e intangibles (1.2.04 / 1.2.05, agregados por FISITAAP by Brillante Agencia) comparten los usos 'Activos fijos' y 'Depreciación'
    ctasActivo() { return this.plan.filter(c => c.uso === 'Activos fijos'); },
    ctasDep() { return this.plan.filter(c => c.uso === 'Depreciación'); },
    ctasGasto() { return this.plan.filter(c => c.raiz === '6'); },
    montoTotal() { return (+this.f.costo || 0) * (+this.f.cantidad || 0); },
    valorRestante() { return Math.max(0, this.montoTotal - (+this.f.valor_residual || 0)); },
    cuotaDep() { return cuota({ ...this.f, monto_total: this.montoTotal }); },
    proxima() { if (!this.f.fecha_inicio) return ''; const d = new Date(String(this.f.fecha_inicio).slice(0, 10) + 'T00:00:00'), hoyD = new Date(); const paso = this.f.periodo === 'Anual' ? 12 : 1; let m = (hoyD.getFullYear() - d.getFullYear()) * 12 + hoyD.getMonth() - d.getMonth(); if (hoyD.getDate() < d.getDate()) m -= 1; d.setMonth(d.getMonth() + (Math.max(0, Math.floor(Math.max(m, 0) / paso)) + 1) * paso); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; },   // hora local (R64)
    acumuladaHoy() { return depreciacion({ ...this.f, monto_total: this.montoTotal }); },
    valido() { const f = this.f; return f.nombre.trim() && f.fecha_adquisicion && +f.costo > 0 && +f.cantidad > 0 && f.cuenta_activo && (f.tipo === 'Terrenos' || (f.cuenta_depreciacion && f.cuenta_gasto && f.fecha_inicio && (f.forma === 'Porcentaje' ? +f.porcentaje > 0 : +f.vida_util > 0))); },   // los terrenos no se deprecian (R221)
  },
  watch: {
    'f.moneda'(v) { if (v && v !== monedas.principal().codigo && !(+this.f.tipo_cambio > 0)) this.f.tipo_cambio = monedas.tc(v); },
    'f.clase'(v, ant) { if (!ant || v === ant) return; this.f.tipo = TIPOS[v][0]; this.f.cuenta_activo = v === 'intangible' ? '1.2.04.01' : '1.2.01.05'; this.f.cuenta_depreciacion = v === 'intangible' ? '1.2.05.01' : '1.2.02.03'; this.f.cuenta_gasto = v === 'intangible' ? '6.2.03.03' : '6.2.03.02.03'; },
    'f.fecha_adquisicion'(v) { if (v > this.f.fecha_inicio) this.f.fecha_inicio = v; },
  },
  methods: {
    money, fecha,
    foto(e) { const file = (e.dataTransfer || e.target).files[0]; if (!file || !file.type.startsWith('image/')) return toast('Seleccione una imagen', 'err'); const r = new FileReader(); r.onload = () => this.f.foto = r.result; r.readAsDataURL(file); },
    adjuntar(e) { for (const file of (e.dataTransfer || e.target).files) this.f.documentos.push({ nombre: file.name, tamano: Math.round(file.size / 1024) + ' KB' }); if (e.target.value !== undefined) e.target.value = ''; },
    guardar(otro) {
      if (!this.valido) return toast('Complete los campos obligatorios (*)', 'err');
      if (this.f.pago === 'banco' && !this.f.cuenta_banco) return toast('Elija la cuenta de Bancos con la que se pagó el activo', 'err');
      if (+this.f.iva < 0) return toast('El IVA no puede ser negativo', 'err');
      if (this.enOtraMoneda && !(+this.f.tipo_cambio > 0)) return toast('Indique el tipo de cambio de la compra (colones por ' + this.f.moneda + ')', 'err');
      // el tipo de cambio queda fijo en el activo: el alta y las depreciaciones no cambian con el dólar de cada día
      const datos = { ...this.f, costo: +this.f.costo, cantidad: +this.f.cantidad, monto_total: this.montoTotal, iva: +this.f.iva || 0, tipo_cambio: this.enOtraMoneda ? +this.f.tipo_cambio : null, foto: this.f.foto && this.f.foto.length < 200000 ? this.f.foto : (this.f.foto ? '(foto)' : null) };
      if (this.editando) {
        const a = { ...this.editando, ...datos, id: this.editando.id };
        mock.actualizar('activos', l => (l || []).map(x => (x.id === a.id ? a : x)), []);
        toast('Activo «' + a.nombre + '» actualizado', 'ok'); location.hash = '/contabilidad/activos'; return;
      }
      const a = { id: mock.nextId(activosMock(), 'activos'), ...datos };
      mock.actualizar('activos', l => [...(Array.isArray(l) ? l : []), a], []);
      toast('Activo «' + a.nombre + '» guardado' + (a.contabilizar ? ': el asiento de alta y la depreciación se generan en Asientos contables' : ''), 'ok');
      if (otro) this.f = nuevo(); else location.hash = '/contabilidad/activos';
    },
  },
  template: `
  <div class="page">
    <PageHead :title="editando ? 'Editar activo' : 'Nuevo activo'" sub="Registre la información del activo y la configuración de su depreciación." :crumbs="[{label:'Activos',to:'/contabilidad/activos'},{label: editando ? editando.nombre : 'Nuevo'}]">
      <a class="btn ghost" href="#/contabilidad/activos">Cancelar</a>
    </PageHead>

    <div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(260px,1fr);gap:18px;align-items:start">
      <div>
        <div class="card">
          <h2>Información general</h2>
          <div class="seg" style="margin-bottom:14px"><button :class="{on:f.clase==='tangible'}" @click="f.clase='tangible'">Tangible</button><button :class="{on:f.clase==='intangible'}" @click="f.clase='intangible'">Intangible</button></div>
          <div class="grid">
            <Field label="Nombre" req><input v-model="f.nombre" placeholder="Ej. Impresora multifuncional"></Field>
            <Field label="Referencia" help="Código interno o placa"><input v-model="f.referencia" class="mono"></Field>
            <Field label="Tipo de activo"><select v-model="f.tipo"><option v-for="t in TIPOS[f.clase]" :key="t">{{t}}</option></select></Field>
            <Field label="Fecha de adquisición" req><input type="date" v-model="f.fecha_adquisicion"></Field>
            <Field label="Proveedor"><Buscador v-model="f.proveedor" :opciones="store.clientes" valor="nombre" detalle="numero_id" agregar="proveedor"></Buscador></Field>
            <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
            <Field v-if="enOtraMoneda" label="Tipo de cambio de la compra" req help="Colones por unidad; fija el costo en la contabilidad"><input type="number" step="0.01" min="0.01" v-model.number="f.tipo_cambio"></Field>
            <Field label="Costo" req><input type="number" step="0.01" min="0" v-model.number="f.costo"></Field>
            <Field label="Cantidad" req><input type="number" step="1" min="1" v-model.number="f.cantidad"></Field>
            <Field label="Monto total" req><input :value="money(montoTotal, f.moneda)" disabled></Field>
            <Field label="Cuenta contable del activo" req style="grid-column:1/-1"><select v-model="f.cuenta_activo"><option v-for="c in ctasActivo" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
          </div>
        </div>

        <div class="card">
          <h2>Contabilización</h2>
          <label class="row" style="cursor:pointer;gap:8px;margin-bottom:10px"><input type="checkbox" v-model="f.contabilizar"> <b>Generar los asientos automáticos</b> <span class="small muted">alta del activo, depreciación de cada período y baja</span></label>
          <div class="grid" v-if="f.contabilizar">
            <Field label="Forma de pago de la compra"><select v-model="f.pago"><option value="credito">A crédito (cuentas por pagar al proveedor)</option><option value="banco">Pagado desde una cuenta de Bancos</option></select></Field>
            <Field label="Cuenta de Bancos" :req="f.pago==='banco'" v-if="f.pago==='banco'"><select v-model="f.cuenta_banco"><option value="">—</option><option v-for="n in cuentasBanco" :key="n">{{n}}</option></select></Field>
            <Field label="IVA pagado (acreditable)" help="Monto de IVA de la factura de compra; va a IVA crédito fiscal, no al costo"><input type="number" step="0.01" min="0" v-model.number="f.iva"></Field>
          </div>
          <p class="small muted" style="margin:8px 0 0" v-if="f.contabilizar">El asiento de alta lleva la fecha de adquisición; cada depreciación, la fecha en que se completa el mes (o año). Si ese mes ya está cerrado en Periodos contables, el asiento se registra en el siguiente mes abierto.</p>
        </div>

        <div class="card">
          <h2>Datos de la depreciación</h2>
          <div class="grid">
            <Field label="Cuenta de depreciación acumulada" req><select v-model="f.cuenta_depreciacion"><option v-for="c in ctasDep" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
            <Field label="Cuenta de gasto" req><select v-model="f.cuenta_gasto"><option v-for="c in ctasGasto" :key="c.codigo" :value="c.codigo">{{c.codigo}} · {{c.nombre}}</option></select></Field>
            <Field label="Valor residual" help="Valor estimado al final de la vida útil"><input type="number" step="0.01" min="0" v-model.number="f.valor_residual"></Field>
            <Field label="Fecha de inicio de depreciación" req><input type="date" v-model="f.fecha_inicio" :min="f.fecha_adquisicion"></Field>
            <Field label="Método"><select v-model="f.metodo"><option>Lineal</option></select></Field>
            <Field label="Período"><select v-model="f.periodo"><option>Mensual</option><option>Anual</option></select></Field>
            <Field label="Forma de depreciación"><select v-model="f.forma"><option>Vida útil</option><option>Porcentaje</option></select></Field>
            <Field v-if="f.forma==='Vida útil' && f.tipo!=='Terrenos'" label="Vida útil (años)" req><input type="number" step="1" min="1" v-model.number="f.vida_util"></Field>
            <Field v-else label="Porcentaje anual (%)" req><input type="number" step="0.01" min="0.01" max="100" v-model.number="f.porcentaje"></Field>
          </div>
          <a class="link" style="display:inline-block;margin-top:12px;color:var(--primary);cursor:pointer;font-size:13px" @click="avanzado=!avanzado">{{avanzado ? '▾' : '▸'}} Opciones avanzadas</a>
          <div class="grid" v-if="avanzado" style="margin-top:10px;padding:12px;background:var(--bg);border-radius:8px">
            <div><div class="small muted">Valor restante por depreciar</div><b>{{money(valorRestante, f.moneda)}}</b></div>
            <div><div class="small muted">Cuota {{f.periodo.toLowerCase()}}</div><b>{{money(cuotaDep, f.moneda)}}</b></div>
            <div><div class="small muted">Próxima depreciación</div><b>{{fecha(proxima)}}</b></div>
            <div><div class="small muted">Acumulada a hoy</div><b>{{money(acumuladaHoy, f.moneda)}}</b></div>
          </div>
        </div>

        <div class="card">
          <h2>Documentos adjuntos <small>facturas, garantías, pólizas</small></h2>
          <label class="drop" style="display:block" @dragover.prevent @drop.prevent="adjuntar">Arrastre archivos aquí o haga clic para seleccionarlos<input type="file" multiple style="display:none" @change="adjuntar"></label>
          <div class="row" style="margin-top:10px" v-if="f.documentos.length"><span class="chip" v-for="(d,i) in f.documentos" :key="i">📎 {{d.nombre}} <span class="muted">{{d.tamano}}</span><span style="cursor:pointer" @click="f.documentos.splice(i,1)">✕</span></span></div>
        </div>
      </div>

      <div>
        <div class="card">
          <label class="drop" style="padding:0;overflow:hidden;min-height:160px;display:grid;place-items:center" @dragover.prevent @drop.prevent="foto">
            <img v-if="f.foto" :src="f.foto" style="width:100%;max-height:220px;object-fit:cover" alt="Foto del activo">
            <span v-else style="padding:22px">📷<br>Arrastre o seleccione una foto del activo</span>
            <input type="file" accept="image/*" style="display:none" @change="foto">
          </label>
          <button class="btn ghost sm" v-if="f.foto" style="margin-top:8px" @click="f.foto=null">Quitar foto</button>
          <div class="totals" style="align-items:stretch;margin-top:16px">
            <div><span>Monto total</span><b>{{money(montoTotal, f.moneda)}}</b></div>
            <div><span>Depreciación {{f.periodo.toLowerCase()}}</span><b>{{money(cuotaDep, f.moneda)}}</b></div>
            <div><span>Períodos depreciados a hoy</span><b>{{periodosHoy}}</b></div>
            <div><span>Acumulada a hoy</span><b>{{money(acumuladaHoy, f.moneda)}}</b></div>
          </div>
          <div class="row" style="margin-top:16px;flex-direction:column;align-items:stretch">
            <button class="btn" :disabled="!valido" @click="guardar(false)">{{editando ? 'Guardar cambios' : 'Guardar'}}</button>
            <button class="btn sec" :disabled="!valido" v-if="!editando" @click="guardar(true)">Guardar y crear otro</button>
          </div>
        </div>
      </div>
    </div>
  </div>`,
};
