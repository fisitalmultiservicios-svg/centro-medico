// Libro diario — movimientos contables por rango de fechas sobre el registro 'asientos' (sincroniza los automáticos al abrir).
import { money, fecha, hoy, toast, monedas } from '../../api.js';
import { exportarFilas } from '../reportes/_montos.js';
import { asientosMock } from './asientos.js';
import { sincronizarAutomaticos } from './automaticos.js';

function primerDiaMes() { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10); }

export default {
  props: ['params'],
  data() { return { asientos: asientosMock(), desde: primerDiaMes(), hasta: hoy(), tipo: '' }; },
  async created() { try { await sincronizarAutomaticos(); this.asientos = asientosMock(); } catch {} },
  computed: {
    monP() { return monedas.principal().codigo; },   // la moneda principal, no siempre ₡ (R222)
    tipos() { return [...new Set(this.asientos.map(a => a.tipo))].sort(); },
    enRango() { return this.asientos.filter(a => a.fecha >= this.desde && a.fecha <= this.hasta && (!this.tipo || a.tipo === this.tipo)).sort((a, b) => a.fecha.localeCompare(b.fecha) || a.id - b.id); },
    filas() { return this.enRango.flatMap(a => a.lineas.map((l, i) => ({ key: a.id + '-' + i, primera: i === 0, n: a.lineas.length, fecha: a.fecha, codigo: a.codigo, tipo: a.tipo, obs: a.observaciones, ...l }))); },
    totDebito() { return this.filas.reduce((s, f) => s + (+f.debito || 0), 0); },
    totCredito() { return this.filas.reduce((s, f) => s + (+f.credito || 0), 0); },
  },
  methods: {
    money, fecha,
    rango(n) { const d = new Date(); if (n === 'mes') { this.desde = primerDiaMes(); this.hasta = hoy(); } else if (n === 'anterior') { this.desde = new Date(d.getFullYear(), d.getMonth() - 1, 1).toISOString().slice(0, 10); this.hasta = new Date(d.getFullYear(), d.getMonth(), 0).toISOString().slice(0, 10); } else { this.desde = new Date(d.getFullYear(), 0, 1).toISOString().slice(0, 10); this.hasta = hoy(); } },
    descargar() {
      if (!this.filas.length) return toast('No hay movimientos para descargar en el período', 'err');
      exportarFilas('libro-diario-' + this.desde + '-' + this.hasta, ['Fecha', 'Código', 'Tipo', 'Cuenta', 'Nombre de cuenta', 'Contacto', 'Documento', 'Descripción', 'Débito', 'Crédito'],
        this.filas.map(f => [f.fecha, f.codigo, f.tipo, f.cuenta, f.cuenta_nombre, f.contacto, f.documento, f.descripcion || f.obs, +f.debito || 0, +f.credito || 0]).concat([['', '', '', '', '', '', '', 'TOTALES', +this.totDebito || 0, +this.totCredito || 0]]),
        { titulo: 'Libro diario', periodo: this.desde + ' al ' + this.hasta, num: [8, 9] });
    },
  },
  template: `
  <div class="page">
    <PageHead title="Libro diario" sub="Detalle cronológico de todos los movimientos contables registrados en el período." :crumbs="[{label:'Contabilidad',to:'/contabilidad/asientos'},{label:'Libro diario'}]">
      <button class="btn sec" @click="descargar">⤓ Descargar</button>
    </PageHead>

    <div class="card">
      <div class="row" style="align-items:flex-end">
        <Field label="Desde"><input type="date" v-model="desde"></Field>
        <Field label="Hasta"><input type="date" v-model="hasta"></Field>
        <Field label="Tipo de registro"><select v-model="tipo"><option value="">Todos los tipos</option><option v-for="t in tipos" :key="t">{{t}}</option></select></Field>
        <div class="seg"><button @click="rango('mes')">Mes actual</button><button @click="rango('anterior')">Mes anterior</button><button @click="rango('anio')">Año</button></div>
        <span class="small muted" style="margin-left:auto">{{enRango.length}} asientos · {{filas.length}} movimientos</span>
      </div>
    </div>

    <div class="card pad0">
      <div class="table-wrap" v-if="filas.length"><table class="tbl">
        <thead><tr><th>Fecha</th><th>Código</th><th>Cuenta</th><th>Descripción</th><th class="num">Débito</th><th class="num">Crédito</th></tr></thead>
        <tbody>
          <tr v-for="f in filas" :key="f.key" :style="f.primera && f.key!==filas[0].key ? 'border-top:2px solid var(--line-strong)' : ''">
            <td>{{f.primera ? fecha(f.fecha) : ''}}</td>
            <td><span class="mono" v-if="f.primera" :title="f.tipo">{{f.codigo}}</span></td>
            <td><span class="mono muted">{{f.cuenta}}</span> {{f.cuenta_nombre}}</td>
            <td style="white-space:normal">{{f.descripcion || f.obs || '—'}}<span v-if="f.contacto" class="small muted"> · {{f.contacto}}</span><span v-if="f.documento" class="small mono muted"> · {{f.documento}}</span></td>
            <td class="num">{{f.debito ? money(f.debito, monP) : ''}}</td>
            <td class="num">{{f.credito ? money(f.credito, monP) : ''}}</td>
          </tr>
        </tbody>
        <tfoot><tr><th colspan="4" style="text-align:right">Totales del período</th><th class="num">{{money(totDebito, monP)}}</th><th class="num">{{money(totCredito, monP)}}</th></tr></tfoot>
      </table></div>
      <Empty v-else icon="📒" title="No hay movimientos en el período" text="Los asientos contables, facturas y pagos registrados entre las fechas seleccionadas aparecerán aquí."><a class="btn" href="#/contabilidad/asientos/nuevo">+ Nuevo asiento contable</a></Empty>
    </div>
  </div>`,
};
