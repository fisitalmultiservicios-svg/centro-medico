// Contabilidad › Presupuesto (3.8): monto mensual por cuenta de resultados (ingresos, costos y gastos) para cada año. Se llena a
// mano, repartiendo un monto anual en doce meses, copiando lo real del año anterior o el presupuesto del año anterior. El
// reporte «Presupuesto contra real» compara con los asientos del período. Registro 'presupuesto_<año>' = {anio, cuentas: {codigo: [12]}}.
import { money, fmt, toast, mock, hoy, monedas } from '../../api.js';
import { sesion } from '../../app.js';
import { planCuentas } from './catalogo.js';
import { cargarAsientos, planConUsadas, saldos, NOMBRE_RAIZ } from './_mayor.js';
import { exportarTabla } from '../reportes/_montos.js';

export const MESES_CORTOS = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Set', 'Oct', 'Nov', 'Dic'];
const r2 = n => Math.round((+n || 0) * 100) / 100;
const doce = () => Array.from({ length: 12 }, () => 0);
export function presupuesto(anio) { const p = mock.get('presupuesto_' + anio, null); return p && p.cuentas && typeof p.cuentas === 'object' ? { anio: +anio, cuentas: p.cuentas } : { anio: +anio, cuentas: {} }; }
export function finMes(anio, m) { return anio + '-' + String(m).padStart(2, '0') + '-' + String(new Date(anio, m, 0).getDate()).padStart(2, '0'); }

export default {
  props: ['params'],
  data() { const a = +hoy().slice(0, 4); return { anio: a, cuentas: {}, raiz: '', q: '', cargando: false, guardando: false, MESES_CORTOS, NOMBRE_RAIZ }; },
  computed: {
    puede() { return sesion.puede('contabilidad'); },
    monP() { return monedas.principal().codigo; },
    anios() { const a = +hoy().slice(0, 4); return [a - 1, a, a + 1, a + 2]; },
    plan() { return planCuentas().filter(c => c.hoja && ['4', '5', '6'].includes(c.raiz)); },
    filas() {
      const q = this.q.trim().toLowerCase();
      return this.plan.filter(c => (!this.raiz || c.raiz === this.raiz) && (!q || c.codigo.includes(q) || c.nombre.toLowerCase().includes(q))).map(c => ({ ...c, meses: this.cuentas[c.codigo] || doce(), total: r2((this.cuentas[c.codigo] || []).reduce((s, v) => s + (+v || 0), 0)) }));
    },
    totales() {
      const porRaiz = {}; for (const r of ['4', '5', '6']) porRaiz[r] = doce();
      for (const c of this.plan) { const arr = this.cuentas[c.codigo]; if (!arr) continue; for (let i = 0; i < 12; i++) porRaiz[c.raiz][i] = r2(porRaiz[c.raiz][i] + (+arr[i] || 0)); }
      const resultado = doce().map((_, i) => r2(porRaiz['4'][i] - porRaiz['5'][i] - porRaiz['6'][i]));
      const anual = o => r2(o.reduce((s, v) => s + v, 0));
      return { porRaiz, resultado, anual: { 4: anual(porRaiz['4']), 5: anual(porRaiz['5']), 6: anual(porRaiz['6']), resultado: anual(resultado) } };
    },
    conDatos() { return Object.values(this.cuentas).some(arr => (arr || []).some(v => +v)); },
  },
  watch: { anio() { this.cargar(); } },
  methods: {
    money, fmt,
    cargar() { const p = presupuesto(this.anio); this.cuentas = Object.fromEntries(Object.entries(p.cuentas).map(([k, v]) => [k, Array.from({ length: 12 }, (_, i) => r2((v || [])[i] || 0))])); },
    valor(c, i) { return (this.cuentas[c.codigo] || doce())[i]; },
    poner(c, i, v) { const arr = (this.cuentas[c.codigo] || doce()).slice(); arr[i] = r2(String(v).replace(',', '.')); this.cuentas = { ...this.cuentas, [c.codigo]: arr }; },
    repartir(c) {
      const v = window.prompt('Monto anual para ' + c.codigo + ' · ' + c.nombre + ' (se reparte en 12 meses iguales)', String(c.total || '')); if (v === null) return;
      const anual = r2(String(v).replace(',', '.')), m = r2(anual / 12), arr = doce().map(() => m); arr[11] = r2(anual - m * 11);
      this.cuentas = { ...this.cuentas, [c.codigo]: arr };
    },
    async copiarReal() {
      const a = this.anio - 1; if (this.conDatos && !confirm('Se reemplaza el presupuesto de ' + this.anio + ' con lo real de ' + a + '. ¿Continuar?')) return;
      this.cargando = true;
      try {
        const as = await cargarAsientos(), plan = planConUsadas(as), out = {};
        for (let m = 1; m <= 12; m++) { const s = saldos(as, plan, a + '-' + String(m).padStart(2, '0') + '-01', finMes(a, m)); for (const o of Object.values(s)) { if (!o.hoja || !['4', '5', '6'].includes(o.raiz) || Math.abs(o.movimiento) < 0.005) continue; (out[o.cuenta] = out[o.cuenta] || doce())[m - 1] = r2(o.movimiento); } }
        this.cuentas = out; toast(Object.keys(out).length ? 'Copiado lo real de ' + a + ' en ' + Object.keys(out).length + ' cuentas: ajuste y guarde' : 'No hay movimientos en ' + a, Object.keys(out).length ? 'ok' : 'err');
      } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    copiarAnterior() { const p = presupuesto(this.anio - 1); if (!Object.keys(p.cuentas).length) return toast('No hay presupuesto de ' + (this.anio - 1), 'err'); if (this.conDatos && !confirm('Se reemplaza el presupuesto de ' + this.anio + ' con el de ' + (this.anio - 1) + '. ¿Continuar?')) return; this.cuentas = Object.fromEntries(Object.entries(p.cuentas).map(([k, v]) => [k, Array.from({ length: 12 }, (_, i) => r2((v || [])[i] || 0))])); toast('Presupuesto de ' + (this.anio - 1) + ' copiado: ajuste y guarde', 'ok'); },
    ajustar() { const v = window.prompt('Ajustar todo el presupuesto en un porcentaje (por ejemplo 5 o -3)', '5'); if (v === null) return; const pct = +String(v).replace(',', '.') || 0; this.cuentas = Object.fromEntries(Object.entries(this.cuentas).map(([k, arr]) => [k, arr.map(x => r2(x * (1 + pct / 100)))])); },
    limpiar() { if (!confirm('¿Borrar todos los montos del presupuesto de ' + this.anio + '? (no se guarda hasta pulsar Guardar)')) return; this.cuentas = {}; },
    async guardar() {
      if (!mock.puedeGuardar()) return;
      const cuentas = {}; for (const [k, arr] of Object.entries(this.cuentas)) if ((arr || []).some(v => +v)) cuentas[k] = arr.map(v => r2(v));
      this.guardando = true; const ok = await mock.set('presupuesto_' + this.anio, { anio: this.anio, cuentas, actualizado: new Date().toISOString() }); this.guardando = false;
      if (ok) toast('Presupuesto de ' + this.anio + ' guardado (' + Object.keys(cuentas).length + ' cuentas)', 'ok');
    },
    exportar() { const cols = [{ key: 'codigo', label: 'Cuenta' }, { key: 'nombre', label: 'Nombre' }, ...MESES_CORTOS.map((m, i) => ({ key: 'm' + i, label: m + ' ' + this.anio, num: true })), { key: 'total', label: 'Total', num: true }]; const rows = this.filas.filter(f => f.total).map(f => { const o = { codigo: f.codigo, nombre: f.nombre, total: f.total }; f.meses.forEach((v, i) => { o['m' + i] = v; }); return o; }); exportarTabla('presupuesto_' + this.anio, cols, rows, { titulo: 'Presupuesto ' + this.anio }); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Presupuesto" sub="Monto mensual por cuenta de ingresos, costos y gastos. Compare con lo real en Reportes › Contables › Presupuesto contra real." :crumbs="[{label:'Contabilidad'},{label:'Presupuesto'}]">
      <a class="btn ghost" href="#/reportes/contables/presupuesto-vs-real">Presupuesto contra real</a>
      <button class="btn ghost" @click="exportar" :disabled="!conDatos">Exportar</button>
      <button class="btn" @click="guardar" :disabled="!puede || guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </PageHead>
    <div class="card">
      <div class="toolbar" style="flex-wrap:wrap;gap:8px">
        <label class="small">Año <select class="inp" v-model.number="anio"><option v-for="a in anios" :key="a" :value="a">{{a}}</option></select></label>
        <div class="seg"><button :class="{on: raiz===''}" @click="raiz=''">Todas</button><button :class="{on: raiz==='4'}" @click="raiz='4'">Ingresos</button><button :class="{on: raiz==='5'}" @click="raiz='5'">Costos</button><button :class="{on: raiz==='6'}" @click="raiz='6'">Gastos</button></div>
        <input class="search" placeholder="Buscar cuenta" v-model="q" style="max-width:240px">
        <span style="flex:1"></span>
        <button class="btn sm sec" @click="copiarReal" :disabled="!puede || cargando" title="Toma el movimiento real de cada mes del año anterior">{{cargando ? 'Calculando…' : 'Copiar lo real de ' + (anio - 1)}}</button>
        <button class="btn sm sec" @click="copiarAnterior" :disabled="!puede">Copiar presupuesto de {{anio - 1}}</button>
        <button class="btn sm ghost" @click="ajustar" :disabled="!puede || !conDatos" title="Subir o bajar todo en un porcentaje">± %</button>
        <button class="btn sm ghost" @click="limpiar" :disabled="!puede || !conDatos">Limpiar</button>
      </div>
      <div class="table-wrap" style="max-height:70vh;overflow:auto"><table class="tbl" style="min-width:1500px">
        <thead><tr><th style="position:sticky;left:0;background:var(--card, #fff);z-index:1;min-width:260px">Cuenta</th><th class="num" v-for="(m,i) in MESES_CORTOS" :key="i">{{m}}</th><th class="num">Total {{anio}}</th><th></th></tr></thead>
        <tbody>
          <tr v-for="c in filas" :key="c.codigo"><td style="position:sticky;left:0;background:var(--card, #fff)"><span class="mono small">{{c.codigo}}</span> <span class="small">{{c.nombre}}</span></td>
            <td class="num" v-for="(v,i) in c.meses" :key="i"><input class="inp mini" type="number" step="0.01" :value="v || ''" @change="poner(c, i, $event.target.value)" style="width:88px;text-align:right" :disabled="!puede"></td>
            <td class="num"><b>{{money(c.total, monP)}}</b></td><td><button class="btn icon" title="Repartir un monto anual en 12 meses" @click="repartir(c)" :disabled="!puede">÷12</button></td></tr>
        </tbody>
        <tfoot>
          <tr v-for="r in ['4','5','6']" :key="r"><th style="position:sticky;left:0;background:var(--card, #fff)">{{NOMBRE_RAIZ[r]}}</th><th class="num" v-for="(v,i) in totales.porRaiz[r]" :key="i">{{v ? fmt(v) : ''}}</th><th class="num">{{money(totales.anual[r], monP)}}</th><th></th></tr>
          <tr><th style="position:sticky;left:0;background:var(--card, #fff)">Resultado presupuestado</th><th class="num" v-for="(v,i) in totales.resultado" :key="i" :style="v < 0 ? 'color:var(--danger)' : ''">{{v ? fmt(v) : ''}}</th><th class="num" :style="totales.anual.resultado < 0 ? 'color:var(--danger)' : ''">{{money(totales.anual.resultado, monP)}}</th><th></th></tr>
        </tfoot>
      </table></div>
      <p class="small muted" style="margin:8px 0 0">Solo cuentas de movimiento (hojas) de ingresos, costos y gastos; los montos van en {{monP}} sin IVA, como los asientos. Los cambios se guardan al pulsar Guardar.</p>
    </div>
  </div>`,
};
