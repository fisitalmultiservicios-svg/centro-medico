// TiKe › Configuración (3.52): prefijo y categorías, SLA por prioridad, correo del equipo y firma, portal del cliente (dirección,
// textos y accesos con correo + clave) y buzón de correo (IMAP) que abre tickets y pega respuestas.
import { api, toast, fechaHora } from '../../api.js';
import { store, sesion } from '../../app.js';
import { PRIORIDADES } from './_comun.js';

export default {
  props: ['params'],
  data() { return { c: null, guardando: false, catsTxt: '', imapClave: null, accesos: [], acc: null, claveNueva: null, probando: false, leyendo: false, PRIORIDADES, dosPasosGuardado: true }; },
  computed: { clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); }, servicios() { return store.productos.filter(p => p.activo !== false && p.es_venta !== false); } },
  methods: {
    fechaHora,
    async cargar() {
      try { const c = await api('/api/tike/config'); this.catsTxt = (c.categorias || []).join('\n'); this.c = c; this.dosPasosGuardado = c.claves_2fa !== false; } catch (e) { toast(e.message, 'err'); }
      try { this.accesos = await api('/api/tike/accesos'); } catch { this.accesos = []; }
      // 3.58: desde Primeros pasos (?ir=buzon) se abre directo en la tarjeta del buzón
      if (new URLSearchParams(location.hash.split('?')[1] || '').get('ir') === 'buzon') this.$nextTick(() => { const el = document.getElementById('cfg-buzon'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    },
    pasoBuzon() {   // 1 sin servidor, 2 con datos sin probar, 3 probado con error, 4 listo
      const c = this.c; if (!c) return 0;
      if (!c.imap_host) return 1;
      if (!c.buzon_ultimo) return 2;
      return c.buzon_error ? 3 : 4;
    },
    async guardar() {
      const c = this.c; this.guardando = true;
      const body = { prefijo: c.prefijo, categorias: this.catsTxt.split('\n').map(x => x.trim()).filter(Boolean), sla: c.sla, correo_aviso: c.correo_aviso || null, firma: c.firma || '', portal_activo: !!c.portal_activo, slug: c.slug || '',
        portal_titulo: c.portal_titulo || '', portal_texto: c.portal_texto || '', buzon_activo: !!c.buzon_activo, imap_host: c.imap_host || null, imap_puerto: +c.imap_puerto || 993, imap_seguridad: c.imap_seguridad || 'ssl',
        imap_usuario: c.imap_usuario || null, imap_password: this.imapClave, imap_carpeta: c.imap_carpeta || 'INBOX', producto_horas_id: c.producto_horas_id || null, claves_2fa: c.claves_2fa !== false };
      try { const r = await api('/api/tike/config', { method: 'PUT', body }); this.c = r; this.dosPasosGuardado = r.claves_2fa !== false; this.catsTxt = (r.categorias || []).join('\n'); this.imapClave = null; toast('Configuración guardada', 'ok'); return true; }
      catch (e) { toast(e.message, 'err'); return false; }
      finally { this.guardando = false; }
    },
    async probarBuzon() { if (!(await this.guardar())) return; this.probando = true; try { const r = await api('/api/tike/buzon/probar', { method: 'POST', body: {} }); toast('El buzón responde: ' + r.sin_leer + ' correo(s) sin leer', 'ok'); } catch (e) { toast(e.message, 'err'); } this.probando = false; },
    async leerBuzon() { this.leyendo = true; try { const r = await api('/api/tike/buzon/leer', { method: 'POST', body: {} }); toast('Buzón leído: ' + r.nuevos + ' ticket(s) nuevo(s), ' + r.respuestas + ' respuesta(s)', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } this.leyendo = false; },
    nuevoAcceso() { this.acc = { correo: '', nombre: '', cliente_id: null, clave: '' }; this.claveNueva = null; },
    clienteElegido() { const c = this.clientes.find(x => x.id === this.acc.cliente_id); if (c) { if (!this.acc.correo) this.acc.correo = c.correo || ''; if (!this.acc.nombre) this.acc.nombre = c.nombre_comercial || c.nombre; } },
    async crearAcceso() {
      const a = this.acc; if (!(a.correo || '').includes('@')) return toast('Escriba el correo', 'err');
      try { const r = await api('/api/tike/accesos', { method: 'POST', body: { correo: a.correo.trim(), nombre: a.nombre || '', cliente_id: a.cliente_id || null, clave: (a.clave || '').trim() || null } }); this.claveNueva = r.clave_temporal; this.acc = null; this.accesos.unshift(r); toast('Acceso creado' + (r.clave_temporal ? '. Clave temporal: ' + r.clave_temporal : ''), 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async resetClave(a) { try { const r = await api('/api/tike/accesos/' + a.id + '/clave', { method: 'POST', body: {} }); Object.assign(a, r); this.claveNueva = r.clave_temporal; toast('Clave nueva: ' + r.clave_temporal + ' (también se envió por correo si hay correo saliente)', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async quitar(a) { if (!confirm('¿Quitar el acceso de ' + a.correo + '?')) return; try { await api('/api/tike/accesos/' + a.id, { method: 'DELETE' }); a.activo = false; } catch (e) { toast(e.message, 'err'); } },
    copiar() { try { navigator.clipboard.writeText(this.c.portal_url); toast('Enlace copiado', 'ok'); } catch { toast('Copie el enlace a mano', 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Configuración de TiKe" sub="Categorías, plazos de atención (SLA), portal del cliente y buzón de correo." :crumbs="[{label:'TiKe'},{label:'Configuración'}]">
      <button class="btn" @click="guardar" :disabled="guardando || !c">Guardar</button>
    </PageHead>
    <template v-if="c">
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Tickets</h2>
          <div class="grid cols-2">
            <Field label="Prefijo del código" help="TK → TK-0001"><input v-model="c.prefijo" maxlength="6" style="text-transform:uppercase"></Field>
            <Field label="Correo del equipo" help="Recibe un aviso por cada ticket nuevo. Vacío = correo de la empresa"><input v-model="c.correo_aviso" type="email" maxlength="120"></Field>
          </div>
          <Field label="Categorías (una por línea)"><textarea rows="6" v-model="catsTxt"></textarea></Field>
          <Field label="Firma de los correos al cliente"><textarea rows="3" v-model="c.firma" maxlength="600" placeholder="Soporte técnico · tel. 2222-2222 · lunes a viernes 8 a 5"></textarea></Field>
          <Toggle v-model="c.claves_2fa" label="Ver contraseñas de la documentación exige el código de dos pasos del usuario" v-if="sesion.puede('configurar') || !dosPasosGuardado"></Toggle>
          <p class="small muted" style="margin:6px 0" v-else>Ver contraseñas de la documentación exige el código de dos pasos del usuario. Solo el administrador puede quitarlo.</p>
          <Field label="Ítem con que se facturan las horas" :help="sesion.puede('facturar') ? 'Un servicio del inventario (por ejemplo «Hora de soporte técnico»). Su precio es la tarifa cuando el contrato no indica otra' : 'Lo cambia quien factura'"><Buscador v-model="c.producto_horas_id" :opciones="servicios" detalle="cabys" vacio="Sin ítem (se usa un CABYS de servicios de informática)" :disabled="!sesion.puede('facturar')"></Buscador></Field>
        </div>
        <div class="card"><h2>Plazos de atención (SLA) <small>Horas corridas desde que se abre el ticket</small></h2>
          <div class="grid cols-2"><Field v-for="p in PRIORIDADES" :key="p[0]" :label="'Prioridad ' + p[1].toLowerCase() + ' (horas)'"><input type="number" min="0.5" step="0.5" v-model.number="c.sla[p[0]]"></Field></div>
          <p class="small muted" style="margin:6px 0 0">El tablero marca en ámbar los tickets a los que les queda menos del 25 % del plazo y en rojo los vencidos.</p>
        </div>
        <div class="card"><h2>Portal del cliente <small>Sus clientes abren y siguen tickets desde el celular</small></h2>
          <div class="grid cols-2">
            <Field label="Dirección del portal" :help="'Queda en ' + (c.portal_url || sistemaCfg().dominio + '/soporte/nombre')"><div class="row" style="gap:6px;align-items:center"><span class="small muted">/soporte/</span><input v-model="c.slug" maxlength="60" placeholder="mi-empresa"></div></Field>
            <div style="display:flex;flex-direction:column;gap:8px;justify-content:center"><Toggle v-model="c.portal_activo" label="Portal publicado"></Toggle><button class="btn sm ghost" @click="copiar" v-if="c.portal_activo && c.portal_url">Copiar enlace</button></div>
            <Field label="Título" help="Vacío = Soporte · nombre de la empresa"><input v-model="c.portal_titulo" maxlength="80"></Field>
            <Field label="Texto de bienvenida"><input v-model="c.portal_texto" maxlength="400" placeholder="Cuéntenos qué pasa y le respondemos en menos de 24 horas."></Field>
          </div>
          <p class="small muted" style="margin:6px 0 0">Cada correo al cliente lleva un enlace con el que ve y responde su ticket sin clave. Con un acceso (abajo) ve además todos sus tickets.</p>
        </div>
        <div class="card" id="cfg-buzon"><h2>Buzón de correo <small>Un correo nuevo abre un ticket; una respuesta se pega a su bitácora</small></h2>
          <div class="alert" :class="pasoBuzon() === 4 ? 'ok' : pasoBuzon() === 3 ? 'err' : 'info'" style="margin:0 0 10px"><b>Guía rápida</b>
            <ol style="margin:6px 0 0;padding-left:20px" class="small">
              <li :style="pasoBuzon() > 1 ? 'opacity:.6' : ''">Cree en su correo un buzón solo para soporte (por ejemplo soporte@suempresa.com) y anote el servidor IMAP, el usuario y la contraseña.</li>
              <li :style="pasoBuzon() > 2 ? 'opacity:.6' : ''">Escriba aquí el servidor, el puerto, el usuario y la contraseña.</li>
              <li :style="pasoBuzon() === 4 ? 'opacity:.6' : ''">Pulse «Guardar y probar»: el sistema se conecta y le dice cuántos correos hay sin leer.</li>
              <li>Envíese un correo de prueba a ese buzón, encienda «Leer el buzón en cada pasada» y pulse «Leer ahora»: debe aparecer como ticket nuevo en el Tablero.</li>
            </ol>
            <div style="margin-top:6px"><b>Estado:</b> {{pasoBuzon() === 4 ? 'buzón conectado; última lectura ' + fechaHora(c.buzon_ultimo) : pasoBuzon() === 3 ? 'la última prueba falló: ' + c.buzon_error : pasoBuzon() === 2 ? 'datos escritos, todavía sin probar' : 'sin buzón configurado'}}</div>
          </div>
          <div class="grid cols-2">
            <Field label="Servidor IMAP"><input v-model="c.imap_host" maxlength="120" placeholder="mail.suempresa.com"></Field>
            <Field label="Puerto"><input type="number" v-model.number="c.imap_puerto" min="1" max="65535"></Field>
            <Field label="Seguridad"><select v-model="c.imap_seguridad"><option value="ssl">SSL (993)</option><option value="starttls">STARTTLS (143)</option><option value="ninguna">Ninguna</option></select></Field>
            <Field label="Carpeta"><input v-model="c.imap_carpeta" maxlength="60"></Field>
            <Field label="Usuario"><input v-model="c.imap_usuario" maxlength="120" placeholder="soporte@suempresa.com" autocomplete="off"></Field>
            <Field label="Contraseña" :help="c.clave_guardada ? 'Guardada. Escriba otra para cambiarla' : 'Sin guardar'"><input v-model="imapClave" type="password" maxlength="200" autocomplete="new-password"></Field>
          </div>
          <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px"><Toggle v-model="c.buzon_activo" label="Leer el buzón en cada pasada"></Toggle><button class="btn sm sec" @click="probarBuzon" :disabled="probando">{{probando ? 'Probando…' : 'Guardar y probar'}}</button><button class="btn sm ghost" @click="leerBuzon" :disabled="leyendo || !c.buzon_activo">{{leyendo ? 'Leyendo…' : 'Leer ahora'}}</button></div>
          <p class="small" :class="c.buzon_error ? 'danger' : 'muted'" style="margin:6px 0 0" v-if="c.buzon_ultimo">Última lectura {{fechaHora(c.buzon_ultimo)}}{{c.buzon_error ? ': ' + c.buzon_error : ''}}</p>
          <p class="small muted" style="margin:6px 0 0">Use un buzón solo para soporte (por ejemplo soporte@). Los correos leídos se marcan como leídos; las respuestas automáticas y los rebotes se ignoran.</p>
        </div>
      </div>
      <div class="card" style="margin-top:12px"><h2>Accesos al portal <small>Correo y clave con los que el cliente entra</small><button class="btn sm" style="margin-left:auto" @click="nuevoAcceso">+ Acceso</button></h2>
        <div class="alert ok" v-if="claveNueva">Clave temporal: <b>{{claveNueva}}</b>. Dígasela al cliente si no tiene correo saliente configurado; se le pedirá cambiarla al entrar.</div>
        <Empty v-if="!accesos.length" icon="👤" title="Sin accesos" text="Cree uno por cada persona del cliente que abra tickets."></Empty>
        <table class="tabla" v-else><thead><tr><th>Correo</th><th>Nombre</th><th>Cliente</th><th>Último acceso</th><th></th></tr></thead>
          <tbody><tr v-for="a in accesos" :key="a.id" :style="a.activo ? '' : 'opacity:.5'"><td>{{a.correo}}</td><td>{{a.nombre}}</td><td>{{(clientes.find(c => c.id === a.cliente_id) || {}).nombre || '—'}}</td><td class="small muted">{{a.ultimo_acceso ? fechaHora(a.ultimo_acceso) : (a.activo ? 'Nunca' : 'Inactivo')}}</td>
            <td class="acts"><button class="btn sm ghost" @click="resetClave(a)">Clave nueva</button><button class="btn sm ghost" @click="quitar(a)" v-if="a.activo">Quitar</button></td></tr></tbody></table>
      </div>
      <Modal v-if="acc" title="Acceso al portal" @close="acc=null">
        <Field label="Cliente (opcional)" help="Con cliente, ve todos los tickets de ese cliente; sin cliente, solo los de su correo"><Buscador v-model="acc.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Sin cliente" @update:modelValue="clienteElegido"></Buscador></Field>
        <Field label="Correo" req><input v-model="acc.correo" type="email" maxlength="120"></Field>
        <Field label="Nombre"><input v-model="acc.nombre" maxlength="80"></Field>
        <Field label="Clave" help="Vacío = se genera una temporal y se envía por correo"><input v-model="acc.clave" maxlength="60" autocomplete="off"></Field>
        <template #foot><button class="btn ghost" @click="acc=null">Cancelar</button><button class="btn" @click="crearAcceso">Crear acceso</button></template>
      </Modal>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
