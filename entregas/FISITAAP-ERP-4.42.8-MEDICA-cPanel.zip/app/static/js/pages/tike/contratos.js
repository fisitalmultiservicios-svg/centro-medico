// TiKe › Contratos de soporte (3.53): bolsa de horas, visitas o ilimitado por cliente; tarifas fuera de contrato; cuota fija que se
// factura sola con una factura recurrente; consumo del periodo con aviso cuando queda poco.
import { api, toast, money, fecha, hoy } from '../../api.js';
import { store, sesion } from '../../app.js';

const TIPOS = [['horas', 'Bolsa de horas'], ['visitas', 'Visitas'], ['ilimitado', 'Ilimitado']];

export default {
  props: ['params'],
  data() { return { lista: [], form: null, detalle: null, guardando: false, TIPOS }; },
  computed: {
    clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); },
    servicios() { return store.productos.filter(p => p.activo !== false && p.es_venta !== false); },
  },
  methods: {
    money, fecha,
    async cargar() { try { this.lista = await api('/api/tike/contratos'); } catch (e) { toast(e.message, 'err'); } },
    nuevo() { this.form = { id: null, cliente_id: null, nombre: '', tipo: 'horas', cantidad: 10, periodo: 'mensual', tarifa_hora: 0, tarifa_visita: 0, cuota: 0, producto_id: null, dia_cobro: 1, inicio: hoy(), fin: '', renovacion_auto: true, notas: '', activo: true, facturar_cuota: true }; },
    editar(c) { this.form = { ...c, fin: c.fin || '', facturar_cuota: !!c.recurrente_id || c.cuota > 0 }; },
    async guardar() {
      const f = this.form; if (!f.cliente_id) return toast('Elija el cliente', 'err'); if (!f.inicio) return toast('Indique la fecha de inicio', 'err');
      this.guardando = true;
      const body = { cliente_id: f.cliente_id, nombre: f.nombre || '', tipo: f.tipo, cantidad: +f.cantidad || 0, periodo: f.periodo, tarifa_hora: +f.tarifa_hora || 0, tarifa_visita: +f.tarifa_visita || 0, cuota: +f.cuota || 0, producto_id: f.producto_id || null,
        dia_cobro: +f.dia_cobro || 1, inicio: f.inicio, fin: f.fin || null, renovacion_auto: !!f.renovacion_auto, notas: f.notas || '', activo: !!f.activo, facturar_cuota: !!f.facturar_cuota && +f.cuota > 0 };
      try { await api(f.id ? '/api/tike/contratos/' + f.id : '/api/tike/contratos', { method: f.id ? 'PUT' : 'POST', body }); toast('Contrato guardado', 'ok'); this.form = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async ver(c) { try { this.detalle = await api('/api/tike/contratos/' + c.id); } catch (e) { toast(e.message, 'err'); } },
    uso(c) { const k = c.consumo; if (!k || k.incluido === null) return c.tipo === 'ilimitado' ? 'Ilimitado · ' + k.horas + ' h en el periodo' : '—'; return k.usado + ' de ' + k.incluido + (c.tipo === 'horas' ? ' h' : ' visitas') + (k.excedente ? ' · excede ' + k.excedente : ''); },
    pct(c) { const k = c.consumo; if (!k || !k.incluido) return 0; return Math.min(100, Math.round(k.usado * 100 / k.incluido)); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Contratos de soporte" sub="Bolsa de horas o visitas por cliente, tarifas fuera de contrato y cuota que se factura sola cada periodo." :crumbs="[{label:'TiKe'},{label:'Contratos'}]">
      <button class="btn" @click="nuevo" v-if="sesion.puede('facturar')">+ Contrato</button>
    </PageHead>
    <p class="small muted" v-if="!sesion.puede('facturar')" style="margin:0 0 8px">Los contratos los crea y cambia quien factura; usted los ve y los elige en cada ticket.</p>
    <Empty v-if="!lista.length" icon="📄" title="Sin contratos" text="Cree uno por cliente: por ejemplo 10 horas al mes con cuota fija y ₡15.000 la hora extra."></Empty>
    <div class="card" v-else style="padding:0;overflow:auto"><table class="tabla">
      <thead><tr><th>Cliente</th><th>Contrato</th><th>Incluye</th><th>Consumo del periodo</th><th>Cuota</th><th>Vigencia</th><th></th></tr></thead>
      <tbody><tr v-for="c in lista" :key="c.id" :style="c.activo ? '' : 'opacity:.55'">
        <td><b>{{c.cliente_nombre}}</b></td><td>{{c.nombre || c.tipo_nombre}}<div class="small muted">{{c.tipo_nombre}} · {{c.periodo}}</div></td>
        <td>{{c.tipo === 'ilimitado' ? 'Ilimitado' : c.cantidad + (c.tipo === 'horas' ? ' h' : ' visitas')}}<div class="small muted" v-if="c.tarifa_hora">extra {{money(c.tarifa_hora)}}/h</div></td>
        <td><div>{{uso(c)}}</div><div style="height:6px;background:var(--line);border-radius:4px;margin-top:4px;max-width:160px" v-if="c.consumo && c.consumo.incluido"><div :style="'height:6px;border-radius:4px;width:' + pct(c) + '%;background:' + (c.consumo.alerta ? 'var(--warn)' : 'var(--ok)')"></div></div></td>
        <td>{{c.cuota ? money(c.cuota) + '/' + (c.periodo === 'anual' ? 'año' : 'mes') : '—'}}<div class="small muted" v-if="c.recurrente_id">factura recurrente</div></td>
        <td class="small">{{fecha(c.inicio)}}{{c.fin ? ' → ' + fecha(c.fin) : ''}}<span class="badge" :class="c.vigente ? 'ok' : 'danger'" style="margin-left:6px">{{c.vigente ? 'vigente' : 'vencido'}}</span></td>
        <td class="acts"><button class="btn sm ghost" @click="ver(c)">Tickets</button><button class="btn sm ghost" @click="editar(c)" v-if="sesion.puede('facturar')">Editar</button></td>
      </tr></tbody></table></div>
    <Modal v-if="form" :title="form.id ? 'Contrato' : 'Contrato nuevo'" @close="form=null" size="lg">
      <div class="grid cols-2">
        <Field label="Cliente" req><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Seleccionar"></Buscador></Field>
        <Field label="Nombre del contrato"><input v-model="form.nombre" maxlength="80" placeholder="Soporte mensual"></Field>
        <Field label="Tipo"><select v-model="form.tipo"><option v-for="t in TIPOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></Field>
        <Field :label="form.tipo === 'visitas' ? 'Visitas incluidas por periodo' : 'Horas incluidas por periodo'" v-if="form.tipo !== 'ilimitado'"><input type="number" min="0" step="1" v-model.number="form.cantidad"></Field>
        <Field label="Periodo"><select v-model="form.periodo"><option value="mensual">Mensual</option><option value="anual">Anual</option></select></Field>
        <Field label="Tarifa por hora fuera de contrato (sin IVA)"><input type="number" min="0" step="500" v-model.number="form.tarifa_hora"></Field>
        <Field label="Tarifa por visita extra (sin IVA)" v-if="form.tipo === 'visitas'"><input type="number" min="0" step="500" v-model.number="form.tarifa_visita"></Field>
        <Field label="Cuota fija por periodo (sin IVA)" help="0 = sin cuota"><input type="number" min="0" step="1000" v-model.number="form.cuota"></Field>
        <Field label="Ítem con que se factura la cuota" v-if="form.cuota > 0"><Buscador v-model="form.producto_id" :opciones="servicios" detalle="cabys" vacio="Línea de servicio genérica"></Buscador></Field>
        <Field label="Día de cobro" v-if="form.cuota > 0"><input type="number" min="1" max="28" v-model.number="form.dia_cobro"></Field>
        <Field label="Inicio" req><input type="date" v-model="form.inicio"></Field>
        <Field label="Fin" help="Vacío = sin fecha final"><input type="date" v-model="form.fin"></Field>
        <div style="display:flex;flex-direction:column;gap:8px;justify-content:center"><Toggle v-model="form.renovacion_auto" label="Se renueva solo al vencer"></Toggle><Toggle v-model="form.activo" label="Activo"></Toggle><Toggle v-model="form.facturar_cuota" label="Facturar la cuota sola (factura recurrente)" v-if="form.cuota > 0"></Toggle></div>
        <Field label="Notas" style="grid-column:1/-1"><textarea rows="2" v-model="form.notas" maxlength="600"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
    </Modal>
    <Modal v-if="detalle" :title="(detalle.nombre || detalle.tipo_nombre) + ' · ' + detalle.cliente_nombre" @close="detalle=null" size="lg">
      <p class="small muted" style="margin:0 0 8px">Periodo {{fecha(detalle.consumo.desde)}} al {{fecha(detalle.consumo.hasta)}}: {{detalle.consumo.horas}} h en {{detalle.consumo.visitas}} visita(s) · {{detalle.consumo.tickets}} ticket(s) en total.</p>
      <Empty v-if="!detalle.tickets.length" icon="🎫" title="Sin tickets con este contrato" text=""></Empty>
      <table class="tabla" v-else><thead><tr><th>Código</th><th>Asunto</th><th>Estado</th><th>Tiempo</th><th>Creado</th></tr></thead><tbody><tr v-for="t in detalle.tickets" :key="t.id"><td><a :href="'#/tike/tickets/' + t.id">{{t.codigo}}</a></td><td>{{t.asunto}}</td><td>{{t.estado_nombre}}</td><td>{{t.minutos}} min</td><td class="small muted">{{fecha(t.creado)}}</td></tr></tbody></table>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
