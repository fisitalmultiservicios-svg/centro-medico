// TiKe › Mis tickets (3.53): pantalla para el celular del técnico. Sus tickets abiertos con botones grandes: llamar o WhatsApp al
// cliente, «Llegué al sitio», nota rápida con foto de la cámara, tiempo trabajado y cierre. La ficha completa sigue en Tickets.
import { api, toast, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';
import { clasePrioridad, semaforo, horas } from './_comun.js';

export default {
  props: ['params'],
  data() { return { lista: [], sel: null, nota: { texto: '', minutos: 0 }, subiendo: false, cargando: false, todos: false }; },
  computed: { mios() { const uid = sesion.usuario && sesion.usuario.id; return this.todos ? this.lista : this.lista.filter(t => t.tecnico_id === uid); } },
  methods: {
    fechaHora, clasePrioridad, semaforo, horas,
    async cargar() { this.cargando = true; try { this.lista = await api('/api/tike/tickets?abiertos=1'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    tel(t) { return (t.telefono || '').replace(/\D/g, ''); },
    async abrir(t) { try { this.sel = await api('/api/tike/tickets/' + t.id); this.nota = { texto: '', minutos: 0 }; window.scrollTo(0, 0); } catch (e) { toast(e.message, 'err'); } },
    async tomar(t) { try { Object.assign(t, await api('/api/tike/tickets/' + t.id + '/asignar', { method: 'POST', body: { tecnico_id: sesion.usuario.id } })); toast(t.codigo + ' es suyo', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async visita() { try { this.sel = await api('/api/tike/tickets/' + this.sel.id + '/entradas', { method: 'POST', body: { tipo: 'visita', texto: 'Llegada al sitio' } }); toast('Llegada registrada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async guardarNota(tipo) {
      if (!(this.nota.texto || '').trim() && !this.nota.minutos) return toast('Escriba la nota o el tiempo', 'err');
      try { this.sel = await api('/api/tike/tickets/' + this.sel.id + '/entradas', { method: 'POST', body: { tipo, texto: (this.nota.texto || '').trim() || (tipo === 'nota' ? 'Tiempo trabajado' : 'Avance'), minutos: +this.nota.minutos || 0 } }); this.nota = { texto: '', minutos: 0 }; toast(tipo === 'respuesta' ? 'Enviado al cliente' : 'Nota guardada', 'ok'); this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async foto(ev) {
      const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = '';
      if (f.size > 8 * 1024 * 1024) return toast('La foto no puede pasar de 8 MB', 'err');
      this.subiendo = true;
      try { const fd = new FormData(); fd.append('archivo', f, f.name || 'foto.jpg'); await api('/api/tike/tickets/' + this.sel.id + '/adjuntos', { method: 'POST', body: fd }); toast('Foto guardada', 'ok'); this.sel = await api('/api/tike/tickets/' + this.sel.id); }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
    async estado(estado) {
      try { this.sel = await api('/api/tike/tickets/' + this.sel.id + '/estado', { method: 'POST', body: { estado } }); toast('Ticket ' + this.sel.estado_nombre.toLowerCase(), 'ok'); this.cargar(); if (!this.sel.abierto) this.sel = null; }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page" style="max-width:640px">
    <template v-if="!sel">
      <PageHead title="Mis tickets" sub="Lo suyo, para atender desde el celular." :crumbs="[{label:'TiKe'},{label:'Mis tickets'}]">
        <label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="todos"> Ver todos</label><button class="btn ghost" @click="cargar">Actualizar</button>
      </PageHead>
      <Empty v-if="!mios.length && !cargando" icon="✓" title="Nada pendiente" :text="todos ? 'No hay tickets abiertos.' : 'No tiene tickets asignados. Marque «Ver todos» para tomar uno.'"></Empty>
      <div v-for="t in mios" :key="t.id" class="card" style="margin-bottom:10px;cursor:pointer" :style="'border-left:4px solid ' + semaforo(t).color" @click="abrir(t)">
        <div class="row" style="justify-content:space-between;gap:6px"><b>{{t.codigo}}</b><span class="badge" :class="clasePrioridad(t.prioridad)">{{t.prioridad_nombre}}</span></div>
        <div style="font-weight:600;margin:4px 0">{{t.asunto}}</div>
        <div class="small muted">{{t.cliente_nombre || t.solicitante}} · {{t.estado_nombre}}</div>
        <div class="small" :style="'color:' + semaforo(t).color">{{semaforo(t).texto}}</div>
        <button class="btn sm" style="margin-top:6px" v-if="!t.tecnico_id" @click.stop="tomar(t)">Tomarlo</button>
      </div>
    </template>
    <template v-else>
      <PageHead :title="sel.codigo + ' · ' + sel.asunto" :sub="(sel.cliente_nombre || sel.solicitante || '') + ' · ' + sel.estado_nombre" :crumbs="[{label:'TiKe'},{label:'Mis tickets'}]">
        <button class="btn ghost" @click="sel=null">← Volver</button><a class="btn ghost" :href="'#/tike/tickets/' + sel.id">Ficha completa</a>
      </PageHead>
      <div class="card"><p style="white-space:pre-wrap;margin:0">{{sel.descripcion || '—'}}</p>
        <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap">
          <a class="btn sec" v-if="tel(sel)" :href="'tel:' + tel(sel)">📞 Llamar</a><a class="btn sec" v-if="tel(sel)" :href="'https://wa.me/506' + tel(sel)" target="_blank" rel="noopener">💬 WhatsApp</a>
          <button class="btn" @click="visita">📍 Llegué al sitio</button>
        </div>
      </div>
      <div class="card" style="margin-top:10px"><h2>Nota rápida</h2>
        <textarea rows="3" v-model="nota.texto" maxlength="5000" placeholder="Qué se hizo…" style="width:100%"></textarea>
        <div class="row" style="gap:8px;margin-top:8px;align-items:flex-end;flex-wrap:wrap">
          <Field label="Minutos" style="margin:0;width:110px"><input type="number" min="0" step="5" v-model.number="nota.minutos"></Field>
          <button class="btn sec" @click="guardarNota('nota')">Guardar nota</button><button class="btn" @click="guardarNota('respuesta')">Enviar al cliente</button>
          <label class="btn ghost" style="cursor:pointer">{{subiendo ? 'Subiendo…' : '📷 Foto'}}<input type="file" accept="image/*" capture="environment" style="display:none" @change="foto" :disabled="subiendo"></label>
        </div>
      </div>
      <div class="card" style="margin-top:10px"><h2>Terminar</h2>
        <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn sec" @click="estado('espera_cliente')">En espera del cliente</button><button class="btn" @click="estado('resuelto')">✓ Resuelto</button></div>
        <p class="small muted" style="margin:8px 0 0">Trabajado en este ticket: <b>{{horas(sel.minutos)}}</b>. Al marcarlo resuelto, el cliente recibe el correo para calificar.</p>
      </div>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
