// TiKe › Documentación del cliente (3.54): lo que el técnico necesita de cada cliente en un solo lugar. Contactos y ubicaciones,
// contraseñas (bóveda: ocultas, ver y copiar con código de dos pasos y bitácora), procedimientos con versiones y plantillas, redes,
// dominios y certificados, licencias; relaciones entre elementos, equipos y tickets; búsqueda global; vencimientos; exportación.
import { api, toast, fecha, fechaHora } from '../../api.js';
import { store, sesion } from '../../app.js';

const TIPOS = [['contacto', 'Contactos', '👤'], ['ubicacion', 'Ubicaciones', '📍'], ['clave', 'Contraseñas', '🔑'], ['procedimiento', 'Procedimientos', '📘'], ['red', 'Redes', '🌐'], ['dominio', 'Dominios', '🔗'], ['certificado', 'Certificados', '🔒'], ['licencia', 'Licencias', '🧾']];
const CAMPOS = {
  contacto: [['cargo', 'Cargo'], ['telefono', 'Teléfono'], ['correo', 'Correo'], ['notas', 'Notas', 'area']],
  ubicacion: [['direccion', 'Dirección', 'area'], ['horario', 'Horario'], ['telefono', 'Teléfono'], ['acceso', 'Notas de acceso (quién abre, parqueo, alarma…)', 'area']],
  clave: [['usuario', 'Usuario'], ['url', 'Dirección (URL o IP)'], ['categoria', 'Categoría'], ['notas', 'Notas', 'area']],
  procedimiento: [['resumen', 'Resumen corto'], ['contenido', 'Contenido (títulos con #, listas con -, tablas con |)', 'doc']],
  red: [['rango_ip', 'Rango de IP'], ['vlan', 'VLAN'], ['gateway', 'Puerta de enlace'], ['dns', 'DNS'], ['wifi_ssid', 'Wi-Fi (nombre)'], ['proveedor', 'Proveedor de internet'], ['contrato_isp', 'Contrato / cuenta del proveedor'], ['notas', 'Notas', 'area']],
  dominio: [['dominio', 'Dominio'], ['registrador', 'Registrador'], ['dns_proveedor', 'Proveedor de DNS'], ['auto_renueva', 'Se renueva solo (sí/no)'], ['notas', 'Notas', 'area']],
  certificado: [['dominio', 'Dominio'], ['emisor', 'Emisor'], ['tipo_cert', 'Tipo'], ['notas', 'Notas', 'area']],
  licencia: [['producto', 'Producto'], ['cantidad', 'Cantidad'], ['proveedor', 'Proveedor'], ['costo', 'Costo'], ['facturar_a', 'A quién se factura'], ['notas', 'Notas', 'area']],
};

function generarClave(n = 16) { const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!#$%&*+-=?'; const a = new Uint32Array(n); crypto.getRandomValues(a); return Array.from(a, x => abc[x % abc.length]).join(''); }

export default {
  props: ['params'],
  data() { return { clienteId: this.params && this.params.cliente_id ? +this.params.cliente_id : null, tipo: 'clave', lista: [], form: null, det: null, revel: null, secretoVisto: null, guardando: false, q: '', busq: null, venc: null, plantillas: [], equipos: [], rel: null, versionVista: null, TIPOS, CAMPOS, exportar: null }; },
  computed: {
    clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); },
    cliente() { return this.clientes.find(c => c.id === this.clienteId) || null; },
    porTipo() { const m = {}; for (const t of this.TIPOS) m[t[0]] = this.lista.filter(x => x.tipo === t[0]); return m; },
    visibles() { return this.porTipo[this.tipo] || []; },
    puedeClaves() { return sesion.permisos.includes('tike_claves') || sesion.esAdmin; },
  },
  methods: {
    fecha, fechaHora,
    nombreTipo(t) { return (this.TIPOS.find(x => x[0] === t) || [t, t])[1]; },
    async cargar() {
      if (!this.clienteId) { this.lista = []; return; }
      try { [this.lista, this.equipos] = await Promise.all([api('/api/tike/docs?cliente_id=' + this.clienteId), api('/api/tike/equipos?cliente_id=' + this.clienteId)]); } catch (e) { toast(e.message, 'err'); }
    },
    async cargarVenc() { try { this.venc = await api('/api/tike/docs/vencimientos?dias=90'); } catch (e) { toast(e.message, 'err'); } },
    async buscar() { if (this.q.trim().length < 2) return (this.busq = null); try { this.busq = await api('/api/tike/docs/buscar?q=' + encodeURIComponent(this.q.trim())); } catch (e) { toast(e.message, 'err'); } },
    irA(x) { this.busq = null; this.q = ''; this.clienteId = x.cliente_id; this.tipo = x.tipo; this.cargar().then(() => this.ver({ id: x.id })); },
    nuevo(tipo) { const t = tipo || this.tipo; if (!this.clienteId) return toast('Elija el cliente', 'err'); this.form = { id: null, tipo: t, cliente_id: this.clienteId, nombre: '', datos: {}, secreto: t === 'clave' ? generarClave() : null, vence: '', equipo_id: null, etiquetas: '', visible_cliente: false, verSecreto: t === 'clave' }; },
    editar(x) { this.form = { id: x.id, tipo: x.tipo, cliente_id: x.cliente_id, nombre: x.nombre, datos: { ...x.datos }, secreto: null, vence: x.vence || '', equipo_id: x.equipo_id, etiquetas: (x.etiquetas || []).join(', '), visible_cliente: x.visible_cliente, verSecreto: false }; },
    usarPlantilla(p) { this.form.datos.contenido = p.contenido; if (!this.form.nombre) this.form.nombre = p.nombre; },
    async guardar() {
      const f = this.form; if (!(f.nombre || '').trim()) return toast('Escriba el nombre', 'err');
      this.guardando = true;
      const body = { cliente_id: f.cliente_id, tipo: f.tipo, nombre: f.nombre, datos: f.datos, secreto: f.tipo === 'clave' && f.secreto ? f.secreto : null, vence: f.vence || null, equipo_id: f.equipo_id || null, etiquetas: String(f.etiquetas || '').split(',').map(x => x.trim()).filter(Boolean), visible_cliente: !!f.visible_cliente };
      try { const r = await api(f.id ? '/api/tike/docs/' + f.id : '/api/tike/docs', { method: f.id ? 'PUT' : 'POST', body }); toast('Guardado', 'ok'); this.form = null; this.tipo = f.tipo; await this.cargar(); if (this.det && this.det.id === r.id) this.det = r; }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async quitar(x) { if (!confirm('¿Quitar «' + x.nombre + '»?')) return; try { await api('/api/tike/docs/' + x.id, { method: 'DELETE' }); this.det = null; this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async ver(x) { this.secretoVisto = null; this.versionVista = null; try { this.det = await api('/api/tike/docs/' + x.id); } catch (e) { toast(e.message, 'err'); } },
    pedirSecreto(accion) { this.revel = { accion, codigo: '' }; },
    async revelar() {
      const r = this.revel;
      try { const x = await api('/api/tike/docs/' + this.det.id + '/revelar', { method: 'POST', body: { codigo: r.codigo || null, accion: r.accion } });
        this.revel = null;
        try { this.det = await api('/api/tike/docs/' + this.det.id); } catch {}                       // refresca la bitácora sin perder lo revelado
        if (r.accion === 'copiar') { try { await navigator.clipboard.writeText(x.secreto); toast('Contraseña copiada (queda en la bitácora)', 'ok'); } catch { this.secretoVisto = x.secreto; } } else { this.secretoVisto = x.secreto; setTimeout(() => { this.secretoVisto = null; }, 60000); } }
      catch (e) { toast(e.message, 'err'); }
    },
    async verVersion(v) { try { this.versionVista = await api('/api/tike/docs/' + this.det.id + '/versiones/' + v.version); } catch (e) { toast(e.message, 'err'); } },
    async restaurar(v) { if (!confirm('¿Restaurar la versión ' + v.version + '?')) return; try { this.det = await api('/api/tike/docs/' + this.det.id + '/restaurar/' + v.version, { method: 'POST', body: {} }); this.versionVista = null; toast('Versión restaurada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    abrirRel() { this.rel = { tipo: 'elemento', ref_id: null, ticket: '' }; },
    async relacionar() {
      const r = this.rel; let ref = r.ref_id;
      if (r.tipo === 'ticket') { const cod = (r.ticket || '').trim(); if (!cod) return toast('Escriba el código del ticket', 'err'); try { const l = await api('/api/tike/tickets?q=' + encodeURIComponent(cod)); const t = l.find(x => x.codigo.toLowerCase() === cod.toLowerCase()) || l[0]; if (!t) return toast('Ticket no encontrado', 'err'); ref = t.id; } catch (e) { return toast(e.message, 'err'); } }
      if (!ref) return toast('Elija qué relacionar', 'err');
      try { this.det.relaciones = await api('/api/tike/docs/' + this.det.id + '/relaciones', { method: 'POST', body: { tipo: r.tipo, ref_id: ref } }); this.rel = null; toast('Relación agregada', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    async quitarRel(r) { try { await api('/api/tike/docs/' + this.det.id + '/relaciones/' + r.id, { method: 'DELETE' }); this.det.relaciones = this.det.relaciones.filter(x => x.id !== r.id); } catch (e) { toast(e.message, 'err'); } },
    async subir(ev) { const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = ''; if (f.size > 8 * 1024 * 1024) return toast('El adjunto no puede pasar de 8 MB', 'err'); try { const fd = new FormData(); fd.append('archivo', f, f.name); this.det.adjuntos = await api('/api/tike/docs/' + this.det.id + '/adjuntos', { method: 'POST', body: fd }); toast('Adjunto guardado', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async quitarAdj(a) { try { this.det.adjuntos = await api('/api/tike/docs/' + this.det.id + '/adjuntos/' + a.archivo, { method: 'DELETE' }); } catch (e) { toast(e.message, 'err'); } },
    irRel(r) { if (r.tipo === 'elemento') this.ver({ id: r.ref_id }); else if (r.tipo === 'equipo') location.hash = '#/tike/equipos/' + r.ref_id; else location.hash = '#/tike/tickets/' + r.ref_id; },
    abrirExportar() { this.exportar = { con_claves: false, codigo: '' }; },
    async descargar() {
      const x = this.exportar; const url = '/api/tike/docs/exportar/' + this.clienteId + '?con_claves=' + (x.con_claves ? 1 : 0) + (x.codigo ? '&codigo=' + encodeURIComponent(x.codigo) : '');
      try { const r = await fetch(url, { headers: { Authorization: 'Bearer ' + localStorage.getItem('facturacr:token') } }); if (!r.ok) { let d = null; try { d = (await r.json()).detail; } catch {} throw new Error(typeof d === 'string' ? d : (d && d.mensaje) || 'No se pudo exportar'); }
        const blob = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'documentacion-' + (this.cliente ? (this.cliente.nombre_comercial || this.cliente.nombre).replace(/[^\w-]+/g, '_') : this.clienteId) + '.zip'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); this.exportar = null; toast('Exportación descargada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    render(md) {
      const e = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const lineas = String(md || '').replace(/\r/g, '').split('\n'); let html = '', lista = null, tabla = null;
      const cerrar = () => { if (lista) { html += '</' + lista + '>'; lista = null; } if (tabla) { html += '</table>'; tabla = null; } };
      for (const l of lineas) {
        const m = /^(#{1,3})\s+(.*)$/.exec(l);
        if (m) { cerrar(); html += '<h' + (m[1].length + 2) + '>' + e(m[2]) + '</h' + (m[1].length + 2) + '>'; continue; }
        if (/^\s*[-*]\s+/.test(l)) { if (tabla) cerrar(); if (lista !== 'ul') { cerrar(); html += '<ul>'; lista = 'ul'; } html += '<li>' + e(l.replace(/^\s*[-*]\s+/, '')) + '</li>'; continue; }
        if (/^\s*\d+[.)]\s+/.test(l)) { if (tabla) cerrar(); if (lista !== 'ol') { cerrar(); html += '<ol>'; lista = 'ol'; } html += '<li>' + e(l.replace(/^\s*\d+[.)]\s+/, '')) + '</li>'; continue; }
        if (/^\s*\|.*\|\s*$/.test(l)) { if (/^\s*\|[\s:-]+\|\s*$/.test(l) && /^[|\s:-]+$/.test(l)) continue; if (lista) cerrar(); if (!tabla) { html += '<table class="tabla">'; tabla = true; } const celdas = l.trim().slice(1, -1).split('|'); html += '<tr>' + celdas.map(c => '<td>' + e(c.trim()) + '</td>').join('') + '</tr>'; continue; }
        if (!l.trim()) { cerrar(); continue; }
        cerrar(); html += '<p>' + e(l) + '</p>';
      }
      cerrar(); return html;
    },
    generar() { this.form.secreto = generarClave(); this.form.verSecreto = true; },
  },
  watch: { clienteId() { this.cargar(); this.det = null; } },
  async created() {
    this.cargar(); this.cargarVenc();
    try { this.plantillas = await api('/api/tike/docs/plantillas'); } catch { this.plantillas = []; }
    if (this.params && this.params.ticket_id) { try { const t = await api('/api/tike/tickets/' + this.params.ticket_id); if (!this.clienteId && t.cliente_id) this.clienteId = t.cliente_id; } catch {} }
  },
  template: `
  <div class="page">
    <PageHead title="Documentación del cliente" sub="Contraseñas, procedimientos, redes, dominios y licencias de cada cliente, enlazados con sus equipos y tickets." :crumbs="[{label:'TiKe'},{label:'Documentación'}]">
      <button class="btn ghost" @click="abrirExportar" v-if="clienteId">Exportar</button><button class="btn" @click="nuevo()" :disabled="!clienteId">+ {{nombreTipo(tipo).replace(/s$/, '')}}</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="grid cols-2">
      <Field label="Cliente" style="margin:0"><Buscador v-model="clienteId" :opciones="clientes" detalle="numero_id" vacio="Elija el cliente"></Buscador></Field>
      <Field label="Buscar en toda la documentación" style="margin:0"><input v-model="q" placeholder="Nombre, IP, dominio, serie, ticket…" @keyup.enter="buscar" @input="q.length < 2 && (busq = null)"></Field>
    </div>
      <div class="card" v-if="busq" style="margin-top:8px"><div class="row" style="justify-content:space-between"><b>Resultados</b><button class="btn sm ghost" @click="busq=null">Cerrar</button></div>
        <div v-for="x in busq.elementos" :key="'e' + x.id" class="small" style="padding:3px 0"><a href="#" @click.prevent="irA(x)">{{x.tipo_nombre}}: <b>{{x.nombre}}</b></a> · {{x.cliente_nombre}}</div>
        <div v-for="x in busq.equipos" :key="'q' + x.id" class="small" style="padding:3px 0"><a :href="'#/tike/equipos/' + x.id">Equipo {{x.codigo}}: <b>{{x.nombre}}</b></a> · {{x.cliente_nombre}}</div>
        <div v-for="x in busq.tickets" :key="'t' + x.id" class="small" style="padding:3px 0"><a :href="'#/tike/tickets/' + x.id">Ticket {{x.codigo}}: <b>{{x.asunto}}</b></a> · {{x.cliente_nombre}}</div>
        <p class="small muted" v-if="!busq.elementos.length && !busq.equipos.length && !busq.tickets.length" style="margin:4px 0 0">Nada con ese texto.</p></div>
    </div>
    <div class="card" v-if="venc && venc.length" style="margin-bottom:12px"><h2>Vencimientos en 90 días <small>Dominios, certificados, licencias, garantías y contratos</small></h2>
      <div class="row" style="gap:6px;flex-wrap:wrap"><span v-for="v in venc" :key="v.tipo + v.id" class="badge" :class="v.dias < 0 ? 'danger' : v.dias <= 7 ? 'warn' : 'info'" :title="v.cliente_nombre">{{v.tipo_nombre}}: {{v.nombre}} · {{v.dias < 0 ? 'vencido' : 'en ' + v.dias + ' d'}}</span></div></div>
    <Empty v-if="!clienteId" icon="📚" title="Elija un cliente" text="Toda su documentación queda aquí, por cliente, y se puede buscar desde la caja de arriba."></Empty>
    <div v-else class="grid" style="grid-template-columns:minmax(0,1fr) minmax(300px,1.2fr);gap:12px;align-items:start">
      <div>
        <div class="row" style="gap:4px;flex-wrap:wrap;margin-bottom:8px"><button v-for="t in TIPOS" :key="t[0]" class="btn sm" :class="tipo===t[0] ? '' : 'ghost'" @click="tipo=t[0]">{{t[2]}} {{t[1]}} <span class="badge" v-if="porTipo[t[0]].length">{{porTipo[t[0]].length}}</span></button><a class="btn sm ghost" :href="'#/tike/equipos?cliente_id=' + clienteId">🖥 Equipos <span class="badge" v-if="equipos.length">{{equipos.length}}</span></a></div>
        <Empty v-if="!visibles.length" icon="📄" :title="'Sin ' + nombreTipo(tipo).toLowerCase()" text="Agregue el primero con el botón de arriba."></Empty>
        <div v-for="x in visibles" :key="x.id" class="card" style="margin-bottom:8px;cursor:pointer" :style="det && det.id === x.id ? 'border-color:var(--primary)' : ''" @click="ver(x)">
          <div class="row" style="justify-content:space-between;gap:6px"><b>{{x.nombre}}</b><span class="small muted">v{{x.version}}</span></div>
          <div class="small muted" v-if="x.tipo==='clave'">{{x.datos.usuario}}{{x.datos.url ? ' · ' + x.datos.url : ''}} · ••••••••</div>
          <div class="small muted" v-else-if="x.tipo==='procedimiento'">{{x.datos.resumen || x.datos.contenido}}</div>
          <div class="small muted" v-else>{{Object.values(x.datos).filter(Boolean).slice(0, 3).join(' · ')}}</div>
          <div class="small" v-if="x.vence" :class="x.vencido ? 'danger' : x.por_vencer ? 'warn' : 'muted'">Vence {{fecha(x.vence)}}{{x.vencido ? ' (vencido)' : x.por_vencer ? ' (pronto)' : ''}}</div>
          <div class="row" style="gap:4px;flex-wrap:wrap;margin-top:4px"><span class="badge" v-for="e in x.etiquetas" :key="e">{{e}}</span><span class="badge ok" v-if="x.visible_cliente">visible al cliente</span></div>
        </div>
      </div>
      <div class="card" v-if="det">
        <div class="row" style="justify-content:space-between;gap:6px;align-items:flex-start"><div><span class="badge">{{det.tipo_nombre}}</span> <b style="font-size:16px">{{det.nombre}}</b><div class="small muted">Versión {{det.version}} · {{det.usuario}} · {{fechaHora(det.actualizado)}}</div></div>
          <div class="acts"><button class="btn sm ghost" @click="editar(det)">Editar</button><button class="btn sm ghost" @click="quitar(det)" v-if="det.tipo!=='clave' || puedeClaves">Quitar</button></div></div>
        <template v-if="det.tipo==='clave'">
          <div style="margin-top:8px"><div class="small">Usuario: <b>{{det.datos.usuario || '—'}}</b></div><div class="small" v-if="det.datos.url">Dirección: <a :href="/^https?:/.test(det.datos.url) ? det.datos.url : '#'" target="_blank" rel="noopener">{{det.datos.url}}</a></div>
            <div style="margin:8px 0;font-family:monospace;font-size:16px;background:var(--bg2,#f5f7fa);padding:8px 10px;border-radius:8px">{{secretoVisto || '••••••••••••'}}</div>
            <div class="row" style="gap:6px" v-if="puedeClaves"><button class="btn sm" @click="pedirSecreto('ver')">👁 Ver</button><button class="btn sm sec" @click="pedirSecreto('copiar')">⧉ Copiar</button></div>
            <p class="small muted" v-else>Su rol no puede ver contraseñas.</p>
            <p class="small" v-if="det.datos.notas" style="white-space:pre-wrap">{{det.datos.notas}}</p></div>
          <h3 style="font-size:13px;margin:10px 0 4px">Quién la vio o la cambió</h3><p class="small muted" v-if="!det.accesos || !det.accesos.length">Nadie todavía.</p>
          <div v-for="(a, i) in det.accesos" :key="i" class="small">{{a.usuario}} · {{a.accion}} · {{fechaHora(a.creado)}}{{a.ip ? ' · ' + a.ip : ''}}</div>
        </template>
        <div v-else-if="det.tipo==='procedimiento'" class="tk-doc" style="margin-top:8px" v-html="render(det.datos.contenido)"></div>
        <div v-else style="margin-top:8px"><div class="small" v-for="c in CAMPOS[det.tipo]" :key="c[0]" v-show="det.datos[c[0]]"><b>{{c[1]}}:</b> <span style="white-space:pre-wrap">{{det.datos[c[0]]}}</span></div><div class="small" v-if="det.vence"><b>Vence:</b> {{fecha(det.vence)}}</div></div>
        <div class="small" v-if="det.equipo" style="margin-top:6px">Equipo: <a :href="'#/tike/equipos/' + det.equipo.id">{{det.equipo.codigo}} · {{det.equipo.nombre}}</a></div>
        <h3 style="font-size:13px;margin:10px 0 4px">Relacionado <button class="btn sm ghost" style="margin-left:6px" @click="abrirRel">+</button></h3>
        <p class="small muted" v-if="!det.relaciones.length">Sin relaciones.</p>
        <div v-for="r in det.relaciones" :key="r.id" class="small row" style="justify-content:space-between"><a href="#" @click.prevent="irRel(r)">{{r.nombre}}</a><button class="btn sm ghost" @click="quitarRel(r)">×</button></div>
        <h3 style="font-size:13px;margin:10px 0 4px">Adjuntos <label class="btn sm ghost" style="margin-left:6px;cursor:pointer">+<input type="file" style="display:none" @change="subir"></label></h3>
        <p class="small muted" v-if="!det.adjuntos.length">Sin adjuntos.</p>
        <div v-for="a in det.adjuntos" :key="a.archivo" class="small row" style="justify-content:space-between"><a :href="'/api/tike/docs/' + det.id + '/adjuntos/' + a.archivo" target="_blank" rel="noopener">📎 {{a.nombre}}</a><button class="btn sm ghost" @click="quitarAdj(a)">×</button></div>
        <h3 style="font-size:13px;margin:10px 0 4px" v-if="det.versiones.length > 1">Versiones</h3>
        <div v-for="v in det.versiones" :key="v.version" class="small row" style="justify-content:space-between" v-show="det.versiones.length > 1"><span>v{{v.version}} · {{v.usuario}} · {{fechaHora(v.creado)}}</span><span><button class="btn sm ghost" @click="verVersion(v)">Ver</button><button class="btn sm ghost" @click="restaurar(v)" v-if="v.version !== det.version">Restaurar</button></span></div>
        <div class="card" v-if="versionVista" style="margin-top:6px;background:var(--bg2,#f5f7fa)"><div class="row" style="justify-content:space-between"><b>Versión {{versionVista.version}}</b><button class="btn sm ghost" @click="versionVista=null">Cerrar</button></div><div class="tk-doc" v-if="det.tipo==='procedimiento'" v-html="render(versionVista.datos.contenido)"></div><pre class="small" v-else style="white-space:pre-wrap">{{JSON.stringify(versionVista.datos, null, 1)}}</pre></div>
      </div>
      <div class="card" v-else><p class="muted" style="margin:0">Elija un elemento de la lista para ver el detalle, sus relaciones, adjuntos y versiones.</p></div>
    </div>

    <Modal v-if="form" :title="(form.id ? 'Editar ' : 'Nuevo ') + nombreTipo(form.tipo).toLowerCase().replace(/s$/, '')" @close="form=null" size="lg">
      <Field label="Nombre" req><input v-model="form.nombre" maxlength="120" :placeholder="form.tipo==='clave' ? 'Router principal · admin' : form.tipo==='procedimiento' ? 'Alta de usuario' : ''"></Field>
      <p class="small muted" v-if="form.tipo==='clave' && form.id && !puedeClaves" style="margin:0 0 8px">Se conserva la contraseña guardada: su rol no puede cambiarla.</p>
      <template v-if="form.tipo==='clave' && (!form.id || puedeClaves)"><Field label="Contraseña" :help="form.id ? 'Vacío = se conserva la actual' : ''"><div class="row" style="gap:6px"><input :type="form.verSecreto ? 'text' : 'password'" v-model="form.secreto" maxlength="500" autocomplete="new-password" style="flex:1;font-family:monospace"><button class="btn sm ghost" @click="form.verSecreto=!form.verSecreto">{{form.verSecreto ? 'Ocultar' : 'Ver'}}</button><button class="btn sm ghost" @click="generar">Generar</button></div></Field></template>
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:6px" v-if="form.tipo==='procedimiento' && plantillas.length"><span class="small muted">Plantillas:</span><button v-for="p in plantillas" :key="p.nombre" class="btn sm ghost" @click="usarPlantilla(p)">{{p.nombre}}</button></div>
      <div class="grid cols-2">
        <Field v-for="c in CAMPOS[form.tipo]" :key="c[0]" :label="c[1]" :style="c[2] ? 'grid-column:1/-1' : ''"><textarea v-if="c[2]==='doc'" rows="14" v-model="form.datos[c[0]]" style="font-family:monospace;font-size:13px"></textarea><textarea v-else-if="c[2]==='area'" rows="3" v-model="form.datos[c[0]]"></textarea><input v-else v-model="form.datos[c[0]]"></Field>
        <Field label="Vence" v-if="['dominio','certificado','licencia'].includes(form.tipo)"><input type="date" v-model="form.vence"></Field>
        <Field label="Equipo relacionado" v-if="equipos.length"><select v-model="form.equipo_id"><option :value="null">—</option><option v-for="q in equipos" :key="q.id" :value="q.id">{{q.codigo}} · {{q.nombre}}</option></select></Field>
        <Field label="Etiquetas (separadas por coma)"><input v-model="form.etiquetas" maxlength="300" placeholder="wifi, recepción, crítico"></Field>
        <div style="display:flex;align-items:center" v-if="form.tipo!=='clave'"><Toggle v-model="form.visible_cliente" label="Visible para el cliente en el portal"></Toggle></div>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
    </Modal>
    <Modal v-if="revel" :title="revel.accion === 'copiar' ? 'Copiar la contraseña' : 'Ver la contraseña'" @close="revel=null">
      <p class="small muted" style="margin:0 0 8px">Queda registrado quién la {{revel.accion === 'copiar' ? 'copió' : 'vio'}}, cuándo y desde dónde. Si la configuración lo exige, escriba el código de su aplicación de verificación.</p>
      <Field label="Código de dos pasos"><input v-model="revel.codigo" maxlength="12" inputmode="numeric" autofocus @keyup.enter="revelar" placeholder="123456"></Field>
      <template #foot><button class="btn ghost" @click="revel=null">Cancelar</button><button class="btn" @click="revelar">{{revel.accion === 'copiar' ? 'Copiar' : 'Ver'}}</button></template>
    </Modal>
    <Modal v-if="rel" title="Relacionar con…" @close="rel=null">
      <Field label="Qué"><select v-model="rel.tipo"><option value="elemento">Otro elemento de este cliente</option><option value="equipo">Un equipo</option><option value="ticket">Un ticket (por código)</option></select></Field>
      <Field label="Elemento" v-if="rel.tipo==='elemento'"><select v-model="rel.ref_id"><option :value="null">—</option><option v-for="x in lista.filter(x => x.id !== det.id)" :key="x.id" :value="x.id">{{x.tipo_nombre}}: {{x.nombre}}</option></select></Field>
      <Field label="Equipo" v-else-if="rel.tipo==='equipo'"><select v-model="rel.ref_id"><option :value="null">—</option><option v-for="q in equipos" :key="q.id" :value="q.id">{{q.codigo}} · {{q.nombre}}</option></select></Field>
      <Field label="Código del ticket" v-else><input v-model="rel.ticket" placeholder="TK-0001"></Field>
      <template #foot><button class="btn ghost" @click="rel=null">Cancelar</button><button class="btn" @click="relacionar">Relacionar</button></template>
    </Modal>
    <Modal v-if="exportar" title="Exportar la documentación del cliente" @close="exportar=null">
      <p class="small muted" style="margin:0 0 8px">Un archivo comprimido con un documento legible, los datos y los adjuntos, para entregárselo al cliente si termina la relación.</p>
      <label class="row small" style="gap:6px;cursor:pointer" v-if="puedeClaves"><input type="checkbox" v-model="exportar.con_claves"> Incluir las contraseñas (queda en la bitácora)</label>
      <Field label="Código de dos pasos" v-if="exportar.con_claves" style="margin-top:8px"><input v-model="exportar.codigo" maxlength="12" inputmode="numeric" placeholder="123456"></Field>
      <template #foot><button class="btn ghost" @click="exportar=null">Cancelar</button><button class="btn" @click="descargar">Descargar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
