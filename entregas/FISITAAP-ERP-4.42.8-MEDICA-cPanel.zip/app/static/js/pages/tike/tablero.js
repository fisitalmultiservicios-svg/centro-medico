// TiKe › Tablero (3.52): los tickets abiertos en columnas (Nuevos, Asignados, En proceso, En espera del cliente) con el semáforo del
// SLA, filtro «solo los míos» y asignación rápida. Se refresca solo cada 30 segundos.
import { api, toast, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';
import { clasePrioridad, semaforo, horas } from './_comun.js';

const COLUMNAS = [['nuevo', 'Nuevos', 'pendiente'], ['asignado', 'Asignados', ''], ['en_proceso', 'En proceso', 'preparando'], ['espera_cliente', 'En espera del cliente', 'listo']];

export default {
  props: ['params'],
  data() { return { lista: [], resumen: null, tecnicos: [], mios: false, cargando: false, COLUMNAS, _t: null }; },
  computed: {
    visibles() { const uid = sesion.usuario && sesion.usuario.id; return this.mios && uid ? this.lista.filter(t => t.tecnico_id === uid) : this.lista; },
    columnas() { return this.COLUMNAS.map(c => ({ estado: c[0], titulo: c[1], clase: c[2], items: this.visibles.filter(t => t.estado === c[0]) })); },
    resueltos() { return this.lista.filter(t => t.estado === 'resuelto'); },
  },
  methods: {
    fechaHora, clasePrioridad, semaforo, horas,
    async cargar(silencioso) {
      if (!silencioso) this.cargando = true;
      try { const [l, r] = await Promise.all([api('/api/tike/tickets?abiertos=1'), api('/api/tike/resumen')]); this.lista = l.concat(await api('/api/tike/tickets?estado=resuelto')); this.resumen = r; }
      catch (e) { if (!silencioso) toast(e.message, 'err'); }
      this.cargando = false;
    },
    async asignarme(t) {
      try { const r = await api('/api/tike/tickets/' + t.id + '/asignar', { method: 'POST', body: { tecnico_id: sesion.usuario.id } }); Object.assign(t, r); toast(t.codigo + ' asignado a usted', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async asignar(t, ev) {
      const id = +ev.target.value || null; ev.target.value = '';
      try { const r = await api('/api/tike/tickets/' + t.id + '/asignar', { method: 'POST', body: { tecnico_id: id } }); Object.assign(t, r); toast(t.codigo + (id ? ' asignado' : ' sin asignar'), 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async cerrar(t) {
      try { const r = await api('/api/tike/tickets/' + t.id + '/estado', { method: 'POST', body: { estado: 'cerrado' } }); Object.assign(t, r); this.lista = this.lista.filter(x => x.id !== t.id); toast(t.codigo + ' cerrado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  async created() { this.cargar(); try { this.tecnicos = await api('/api/tike/tecnicos'); } catch { this.tecnicos = []; } this._t = setInterval(() => this.cargar(true), 30000); },
  unmounted() { clearInterval(this._t); },
  template: `
  <div class="page">
    <PageHead title="Tablero de tickets" sub="Lo abierto, de un vistazo: el color de cada tarjeta es el plazo del SLA (verde al día, ámbar por vencer, rojo vencido)." :crumbs="[{label:'TiKe'},{label:'Tablero'}]">
      <label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="mios"> Solo los míos</label>
      <a class="btn ghost" href="#/tike/tickets">Lista completa</a><a class="btn" href="#/tike/tickets?nuevo=1">+ Ticket</a>
    </PageHead>
    <div class="grid cols-4" style="margin-bottom:12px" v-if="resumen">
      <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800">{{resumen.abiertos}}</div><div class="small muted">Abiertos</div></div>
      <div class="card" style="text-align:center" :style="resumen.vencidos ? 'border-color:var(--danger)' : ''"><div style="font-size:26px;font-weight:800" :style="resumen.vencidos ? 'color:var(--danger)' : ''">{{resumen.vencidos}}</div><div class="small muted">Vencidos</div></div>
      <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800" :style="resumen.por_vencer ? 'color:var(--warn)' : ''">{{resumen.por_vencer}}</div><div class="small muted">Vencen en 4 h</div></div>
      <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800">{{resumen.resueltos_mes}}</div><div class="small muted">Resueltos este mes{{resumen.calificacion_mes ? ' · ★ ' + resumen.calificacion_mes : ''}}</div></div>
    </div>
    <div class="kds-cols" style="grid-template-columns:repeat(4,minmax(0,1fr))">
      <div v-for="c in columnas" :key="c.estado" class="kds-col" :class="c.clase">
        <div class="kds-col-t">{{c.titulo}} <span class="badge" style="margin-left:auto">{{c.items.length}}</span></div>
        <div v-for="t in c.items" :key="t.id" class="card kds-card" :style="'border-left:4px solid ' + semaforo(t).color">
          <div class="row" style="justify-content:space-between;gap:6px;align-items:flex-start">
            <a :href="'#/tike/tickets/' + t.id" style="font-weight:700">{{t.codigo}}</a>
            <span class="badge" :class="clasePrioridad(t.prioridad)">{{t.prioridad_nombre}}</span>
          </div>
          <div style="margin:4px 0;font-weight:600">{{t.asunto}}</div>
          <div class="small muted">{{t.cliente_nombre || t.solicitante || 'Sin cliente'}}<span v-if="t.categoria"> · {{t.categoria}}</span></div>
          <div class="small" :style="'color:' + semaforo(t).color">{{semaforo(t).texto}}<span class="muted" v-if="t.minutos"> · {{horas(t.minutos)}}</span></div>
          <div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap;align-items:center">
            <span class="small" v-if="t.tecnico_nombre">👤 {{t.tecnico_nombre}}</span>
            <button class="btn sm ghost" v-else @click="asignarme(t)">Tomarlo</button>
            <select class="sm" style="max-width:150px" @change="asignar(t, $event)" :title="'Asignar ' + t.codigo"><option value="">Asignar a…</option><option v-for="u in tecnicos" :key="u.id" :value="u.id">{{u.nombre}}</option></select>
          </div>
        </div>
        <Empty v-if="!c.items.length" icon="✓" :title="'Nada en ' + c.titulo.toLowerCase()" text=""></Empty>
      </div>
    </div>
    <div class="card" style="margin-top:12px" v-if="resueltos.length"><h2>Resueltos, pendientes de cierre <small>El cliente los cierra al calificar; también puede cerrarlos aquí</small></h2>
      <div class="row" v-for="t in resueltos" :key="t.id" style="justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid var(--line);flex-wrap:wrap">
        <div><a :href="'#/tike/tickets/' + t.id"><b>{{t.codigo}}</b></a> · {{t.asunto}} <span class="small muted">{{t.cliente_nombre || t.solicitante}} · resuelto {{fechaHora(t.resuelto_en)}}</span></div>
        <button class="btn sm ghost" @click="cerrar(t)">Cerrar</button>
      </div>
    </div>
  </div>`,
  setup() { return { sesion }; },
};
