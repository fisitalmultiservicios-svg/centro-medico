// TiKe › Reportes (3.53): tiempo por técnico, cumplimiento del SLA, tickets por cliente y categoría, horas por contrato y
// calificación del cliente en un rango de fechas.
import { api, toast, fecha, hoy } from '../../api.js';
import { sesion } from '../../app.js';
import { horas } from './_comun.js';

export default {
  props: ['params'],
  data() { const h = hoy(); return { desde: h.slice(0, 8) + '01', hasta: h, r: null, cargando: false }; },
  methods: {
    fecha, horas,
    async cargar() { this.cargando = true; try { this.r = await api('/api/tike/reportes?desde=' + this.desde + '&hasta=' + this.hasta); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    filas(obj) { return Object.entries(obj || {}); },
    nombreEstado(e) { return { nuevo: 'Nuevos', asignado: 'Asignados', en_proceso: 'En proceso', espera_cliente: 'En espera del cliente', resuelto: 'Resueltos', cerrado: 'Cerrados' }[e] || e; },
    nombrePrioridad(p) { return { baja: 'Baja', media: 'Media', alta: 'Alta', critica: 'Crítica' }[p] || p; },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Reportes de TiKe" sub="Cómo va el soporte: tiempo por técnico, plazos cumplidos, clientes que más piden y consumo de los contratos." :crumbs="[{label:'TiKe'},{label:'Reportes'}]"></PageHead>
    <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;align-items:flex-end;flex-wrap:wrap">
      <Field label="Desde" style="margin:0"><input type="date" v-model="desde"></Field><Field label="Hasta" style="margin:0"><input type="date" v-model="hasta"></Field><button class="btn sec" @click="cargar" :disabled="cargando">Ver</button>
    </div></div>
    <template v-if="r">
      <div class="grid cols-4" style="margin-bottom:12px">
        <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800">{{r.tickets}}</div><div class="small muted">Tickets abiertos en el rango</div></div>
        <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800" :style="r.sla.porcentaje !== null && r.sla.porcentaje < 80 ? 'color:var(--danger)' : 'color:var(--ok)'">{{r.sla.porcentaje === null ? '—' : r.sla.porcentaje + ' %'}}</div><div class="small muted">SLA cumplido ({{r.sla.cumplidos}} a tiempo, {{r.sla.vencidos}} tarde)</div></div>
        <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800">{{horas(r.minutos_total)}}</div><div class="small muted">Tiempo trabajado{{r.primera_respuesta_horas !== null ? ' · 1.ª respuesta en ' + r.primera_respuesta_horas + ' h' : ''}}</div></div>
        <div class="card" style="text-align:center"><div style="font-size:26px;font-weight:800">{{r.calificacion.promedio === null ? '—' : '★ ' + r.calificacion.promedio}}</div><div class="small muted">Calificación ({{r.calificacion.cantidad}} respuestas)</div></div>
      </div>
      <div class="grid cols-2" style="align-items:start">
        <div class="card"><h2>Tiempo por técnico</h2><p class="small muted" v-if="!filas(r.por_tecnico_minutos).length">Sin tiempo registrado.</p>
          <table class="tabla" v-else><tbody><tr v-for="[k, v] in filas(r.por_tecnico_minutos)" :key="k"><td>{{k}}</td><td style="text-align:right"><b>{{horas(v)}}</b></td><td style="width:40%"><div style="height:8px;background:var(--line);border-radius:4px"><div :style="'height:8px;border-radius:4px;background:var(--primary);width:' + Math.round(v * 100 / Math.max(1, r.minutos_total)) + '%'"></div></div></td></tr></tbody></table></div>
        <div class="card"><h2>Por estado y prioridad</h2>
          <table class="tabla"><tbody><tr v-for="[k, v] in filas(r.por_estado)" :key="k" v-show="v"><td>{{nombreEstado(k)}}</td><td style="text-align:right"><b>{{v}}</b></td></tr></tbody></table>
          <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px"><span class="badge" v-for="[k, v] in filas(r.por_prioridad)" :key="k">{{nombrePrioridad(k)}}: {{v}}</span></div></div>
        <div class="card"><h2>Clientes que más piden</h2><p class="small muted" v-if="!filas(r.por_cliente).length">Sin tickets.</p>
          <table class="tabla" v-else><tbody><tr v-for="[k, v] in filas(r.por_cliente)" :key="k"><td>{{k}}</td><td style="text-align:right"><b>{{v}}</b></td></tr></tbody></table></div>
        <div class="card"><h2>Por categoría</h2><p class="small muted" v-if="!filas(r.por_categoria).length">Sin tickets.</p>
          <table class="tabla" v-else><tbody><tr v-for="[k, v] in filas(r.por_categoria)" :key="k"><td>{{k}}</td><td style="text-align:right"><b>{{v}}</b></td></tr></tbody></table></div>
        <div class="card" style="grid-column:1/-1"><h2>Contratos activos <small>Consumo del periodo en curso</small></h2><p class="small muted" v-if="!r.contratos.length">Sin contratos.</p>
          <table class="tabla" v-else><thead><tr><th>Cliente</th><th>Contrato</th><th>Incluido</th><th>Usado</th><th>Restante</th><th>Excede</th><th>Cuota</th></tr></thead>
            <tbody><tr v-for="c in r.contratos" :key="c.id"><td>{{c.cliente_nombre}}</td><td>{{c.nombre || c.tipo_nombre}}</td><td>{{c.consumo.incluido === null ? 'Ilimitado' : c.consumo.incluido}}</td><td>{{c.consumo.usado}}</td><td :class="c.consumo.alerta ? 'warn' : ''">{{c.consumo.restante === null ? '—' : c.consumo.restante}}</td><td :class="c.consumo.excedente ? 'danger' : ''">{{c.consumo.excedente || '—'}}</td><td>{{c.cuota ? '₡' + Math.round(c.cuota).toLocaleString('es-CR') : '—'}}</td></tr></tbody></table></div>
      </div>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
