// TiKe › Equipos del cliente (3.53): inventario de equipos por cliente (tipo, marca, modelo, serie, ubicación, garantía), historial
// de tickets y código QR para pegar en el equipo: al escanearlo se abre el portal con el equipo elegido.
import { api, toast, fecha } from '../../api.js';
import { store, sesion } from '../../app.js';

const TIPOS = ['Computadora', 'Portátil', 'Servidor', 'Impresora', 'Router', 'Switch', 'Cámara', 'Teléfono', 'UPS', 'Otro'];

export default {
  props: ['params'],
  data() { return { lista: [], f: { cliente_id: null, q: '' }, form: null, detalle: null, guardando: false, TIPOS }; },
  computed: { clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); } },
  methods: {
    fecha,
    nombreCliente(id) { const c = store.clientes.find(x => x.id === id); return c ? (c.nombre_comercial || c.nombre) : '—'; },
    async cargar() { const q = new URLSearchParams(); if (this.f.cliente_id) q.set('cliente_id', this.f.cliente_id); if (this.f.q.trim()) q.set('q', this.f.q.trim()); try { this.lista = await api('/api/tike/equipos?' + q.toString()); } catch (e) { toast(e.message, 'err'); } },
    nuevo() { this.form = { id: null, cliente_id: this.f.cliente_id || null, nombre: '', tipo: 'Computadora', marca: '', modelo: '', serie: '', ubicacion: '', fecha_compra: '', garantia_hasta: '', notas: '', activo: true }; },
    editar(e) { this.form = { ...e, fecha_compra: e.fecha_compra || '', garantia_hasta: e.garantia_hasta || '' }; },
    async guardar() {
      const f = this.form; if (!f.cliente_id) return toast('Elija el cliente', 'err'); if ((f.nombre || '').trim().length < 2) return toast('Escriba el nombre del equipo', 'err');
      this.guardando = true;
      const body = { ...f, fecha_compra: f.fecha_compra || null, garantia_hasta: f.garantia_hasta || null }; delete body.id; delete body.codigo; delete body.creado; delete body.garantia_vencida; delete body.garantia_por_vencer; delete body.tickets_abiertos;
      try { await api(f.id ? '/api/tike/equipos/' + f.id : '/api/tike/equipos', { method: f.id ? 'PUT' : 'POST', body }); toast('Equipo guardado', 'ok'); this.form = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async ver(e) { try { this.detalle = await api('/api/tike/equipos/' + e.id); } catch (e2) { toast(e2.message, 'err'); } },
    imprimirQr() { const d = this.detalle; const w = window.open('', '_blank'); if (!w) return toast('Permita las ventanas emergentes', 'err'); w.document.write('<title>' + d.codigo + '</title><div style="font-family:system-ui;text-align:center;padding:20px"><img src="/api/tike/equipos/' + d.id + '/qr.png" style="width:220px"><div style="font-weight:700;font-size:18px">' + d.codigo + ' · ' + d.nombre + '</div><div style="font-size:13px;color:#555">Escanee para reportar un problema</div></div>'); w.document.close(); setTimeout(() => w.print(), 400); },
  },
  created() { this.cargar(); if (this.params && this.params.id) api('/api/tike/equipos/' + this.params.id).then(d => { this.detalle = d; }).catch(() => {}); },
  template: `
  <div class="page">
    <PageHead title="Equipos del cliente" sub="Qué tiene cada cliente, con su historial de tickets y un QR para pegar en el equipo." :crumbs="[{label:'TiKe'},{label:'Equipos'}]">
      <button class="btn" @click="nuevo">+ Equipo</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="grid cols-3">
      <Field label="Cliente"><Buscador v-model="f.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Todos" @update:modelValue="cargar"></Buscador></Field>
      <Field label="Buscar"><input v-model="f.q" placeholder="Nombre, serie, marca, ubicación…" @keyup.enter="cargar"></Field>
      <div style="display:flex;align-items:flex-end"><button class="btn sec" @click="cargar">Buscar</button></div>
    </div></div>
    <Empty v-if="!lista.length" icon="🖥" title="Sin equipos" text="Registre las computadoras, impresoras y demás equipos de cada cliente para llevar su historial."></Empty>
    <div class="card" v-else style="padding:0;overflow:auto"><table class="tabla">
      <thead><tr><th>Código</th><th>Equipo</th><th>Cliente</th><th>Serie</th><th>Ubicación</th><th>Garantía</th><th>Tickets</th><th></th></tr></thead>
      <tbody><tr v-for="e in lista" :key="e.id" :style="e.activo ? '' : 'opacity:.55'">
        <td><b>{{e.codigo}}</b></td><td>{{e.nombre}}<div class="small muted">{{e.tipo}}{{e.marca ? ' · ' + e.marca : ''}}{{e.modelo ? ' ' + e.modelo : ''}}</div></td><td>{{nombreCliente(e.cliente_id)}}</td><td class="small">{{e.serie || '—'}}</td><td class="small">{{e.ubicacion || '—'}}</td>
        <td class="small"><span v-if="e.garantia_hasta" :class="e.garantia_vencida ? 'danger' : e.garantia_por_vencer ? 'warn' : ''">{{fecha(e.garantia_hasta)}}{{e.garantia_vencida ? ' (vencida)' : e.garantia_por_vencer ? ' (por vencer)' : ''}}</span><span v-else>—</span></td>
        <td><span class="badge" :class="e.tickets_abiertos ? 'warn' : ''">{{e.tickets_abiertos}} abierto(s)</span></td>
        <td class="acts"><button class="btn sm ghost" @click="ver(e)">Ficha y QR</button><button class="btn sm ghost" @click="editar(e)">Editar</button></td>
      </tr></tbody></table></div>
    <Modal v-if="form" :title="form.id ? 'Equipo' : 'Equipo nuevo'" @close="form=null" size="lg">
      <div class="grid cols-2">
        <Field label="Cliente" req><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Seleccionar"></Buscador></Field>
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="80" placeholder="PC de recepción"></Field>
        <Field label="Tipo"><select v-model="form.tipo"><option v-for="t in TIPOS" :key="t" :value="t">{{t}}</option></select></Field>
        <Field label="Marca"><input v-model="form.marca" maxlength="60"></Field><Field label="Modelo"><input v-model="form.modelo" maxlength="60"></Field><Field label="Número de serie"><input v-model="form.serie" maxlength="80"></Field>
        <Field label="Ubicación"><input v-model="form.ubicacion" maxlength="120" placeholder="Recepción, 2.º piso"></Field>
        <Field label="Fecha de compra"><input type="date" v-model="form.fecha_compra"></Field><Field label="Garantía hasta"><input type="date" v-model="form.garantia_hasta"></Field>
        <div style="display:flex;align-items:center"><Toggle v-model="form.activo" label="Activo"></Toggle></div>
        <Field label="Notas" style="grid-column:1/-1"><textarea rows="3" v-model="form.notas" maxlength="1000" placeholder="Usuario, accesos, particularidades…"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Guardar</button></template>
    </Modal>
    <Modal v-if="detalle" :title="detalle.codigo + ' · ' + detalle.nombre" @close="detalle=null" size="lg">
      <div class="grid" style="grid-template-columns:240px 1fr;gap:12px;align-items:start">
        <div style="text-align:center"><img :src="'/api/tike/equipos/' + detalle.id + '/qr.png'" alt="QR" style="width:200px;border:1px solid var(--line);border-radius:8px"><div class="small muted" style="margin-top:4px">Escanear para reportar un problema</div><button class="btn sm ghost" style="margin-top:6px" @click="imprimirQr">Imprimir etiqueta</button></div>
        <div>
          <div class="small">{{detalle.tipo}}{{detalle.marca ? ' · ' + detalle.marca : ''}}{{detalle.modelo ? ' ' + detalle.modelo : ''}}{{detalle.serie ? ' · serie ' + detalle.serie : ''}}</div>
          <div class="small">{{nombreCliente(detalle.cliente_id)}}{{detalle.ubicacion ? ' · ' + detalle.ubicacion : ''}}</div>
          <div class="small" v-if="detalle.garantia_hasta">Garantía hasta {{fecha(detalle.garantia_hasta)}}</div>
          <p class="small" style="white-space:pre-wrap" v-if="detalle.notas">{{detalle.notas}}</p>
          <h3 style="font-size:14px;margin:10px 0 4px">Historial de tickets</h3>
          <p class="small muted" v-if="!detalle.tickets.length">Sin tickets.</p>
          <table class="tabla" v-else><thead><tr><th>Código</th><th>Asunto</th><th>Estado</th><th>Creado</th></tr></thead><tbody><tr v-for="t in detalle.tickets" :key="t.id"><td><a :href="'#/tike/tickets/' + t.id">{{t.codigo}}</a></td><td>{{t.asunto}}</td><td>{{t.estado_nombre}}</td><td class="small muted">{{fecha(t.creado)}}</td></tr></tbody></table>
        </div>
      </div>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
