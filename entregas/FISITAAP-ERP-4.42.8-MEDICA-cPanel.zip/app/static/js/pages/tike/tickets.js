// TiKe › Tickets (3.52): lista con filtros (estado, técnico, cliente, texto, fechas) y creación de tickets desde el sistema.
import { api, toast, fechaHora, hoy } from '../../api.js';
import { store, sesion } from '../../app.js';
import { PRIORIDADES, ESTADOS, clasePrioridad, claseEstado, semaforo, horas } from './_comun.js';

export default {
  props: ['params'],
  data() { return { lista: [], cfg: null, tecnicos: [], f: { estado: '', tecnico_id: '', cliente_id: null, q: '', desde: '', hasta: '', abiertos: 1 }, form: null, guardando: false, PRIORIDADES, ESTADOS }; },
  computed: { clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); } },
  methods: {
    fechaHora, clasePrioridad, claseEstado, semaforo, horas,
    async cargar() {
      const f = this.f; const q = new URLSearchParams();
      if (f.estado) q.set('estado', f.estado); else if (f.abiertos) q.set('abiertos', '1');
      if (f.tecnico_id) q.set('tecnico_id', f.tecnico_id); if (f.cliente_id) q.set('cliente_id', f.cliente_id); if (f.q.trim()) q.set('q', f.q.trim());
      if (f.desde) q.set('desde', f.desde); if (f.hasta) q.set('hasta', f.hasta);
      try { this.lista = await api('/api/tike/tickets?' + q.toString()); } catch (e) { toast(e.message, 'err'); }
    },
    nuevo() { this.form = { asunto: '', descripcion: '', cliente_id: null, solicitante: '', correo: '', telefono: '', categoria: (this.cfg && this.cfg.categorias[0]) || '', prioridad: 'media', tecnico_id: null }; },
    clienteElegido() { const c = this.clientes.find(x => x.id === this.form.cliente_id); if (c) { if (!this.form.correo) this.form.correo = c.correo || ''; if (!this.form.telefono) this.form.telefono = String(c.celular || c.telefono || ''); } },
    async guardar() {
      const f = this.form; if ((f.asunto || '').trim().length < 3) return toast('Escriba el asunto', 'err');
      this.guardando = true;
      try { const t = await api('/api/tike/tickets', { method: 'POST', body: { ...f, cliente_id: f.cliente_id || null, tecnico_id: f.tecnico_id || null } }); toast(t.codigo + ' creado', 'ok'); this.form = null; location.hash = '#/tike/tickets/' + t.id; }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    try { this.cfg = await api('/api/tike/config'); } catch (e) { toast(e.message, 'err'); }
    try { this.tecnicos = await api('/api/tike/tecnicos'); } catch { this.tecnicos = []; }
    this.cargar();
    if (this.params && this.params.query && this.params.query.nuevo) this.nuevo();
    else if (location.hash.includes('nuevo=1')) this.nuevo();
  },
  template: `
  <div class="page">
    <PageHead title="Tickets" sub="Todas las solicitudes de soporte: busque por código, asunto o cliente y filtre por estado o técnico." :crumbs="[{label:'TiKe'},{label:'Tickets'}]">
      <a class="btn ghost" href="#/tike/tablero">Tablero</a><button class="btn" @click="nuevo">+ Ticket</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="grid cols-4">
      <Field label="Buscar"><input v-model="f.q" placeholder="TK-0001, asunto, cliente…" @keyup.enter="cargar"></Field>
      <Field label="Estado"><select v-model="f.estado" @change="cargar"><option value="">Abiertos</option><option v-for="e in ESTADOS" :key="e[0]" :value="e[0]">{{e[1]}}</option></select></Field>
      <Field label="Técnico"><select v-model="f.tecnico_id" @change="cargar"><option value="">Todos</option><option v-for="u in tecnicos" :key="u.id" :value="u.id">{{u.nombre}}</option></select></Field>
      <Field label="Cliente"><Buscador v-model="f.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Todos" @update:modelValue="cargar"></Buscador></Field>
      <Field label="Desde"><input type="date" v-model="f.desde" @change="cargar"></Field><Field label="Hasta"><input type="date" v-model="f.hasta" @change="cargar"></Field>
      <div style="display:flex;align-items:flex-end;gap:8px"><button class="btn sec" @click="cargar">Buscar</button><button class="btn ghost" @click="f={estado:'',tecnico_id:'',cliente_id:null,q:'',desde:'',hasta:'',abiertos:1};cargar()">Limpiar</button></div>
    </div></div>
    <Empty v-if="!lista.length" icon="🎫" title="Sin tickets" text="Cree el primero con «+ Ticket», o active el portal del cliente y el buzón de correo en Configuración."></Empty>
    <div class="card" v-else style="padding:0;overflow:auto"><table class="tabla">
      <thead><tr><th>Código</th><th>Asunto</th><th>Cliente</th><th>Prioridad</th><th>Estado</th><th>Técnico</th><th>Plazo</th><th>Tiempo</th><th>Creado</th></tr></thead>
      <tbody><tr v-for="t in lista" :key="t.id">
        <td><a :href="'#/tike/tickets/' + t.id"><b>{{t.codigo}}</b></a></td><td>{{t.asunto}}<div class="small muted" v-if="t.categoria">{{t.categoria}}</div></td>
        <td>{{t.cliente_nombre || t.solicitante}}<div class="small muted" v-if="t.cliente_nombre && t.solicitante">{{t.solicitante}}</div></td>
        <td><span class="badge" :class="clasePrioridad(t.prioridad)">{{t.prioridad_nombre}}</span></td><td><span class="badge" :class="claseEstado(t.estado)">{{t.estado_nombre}}</span></td>
        <td>{{t.tecnico_nombre || '—'}}</td><td><span :style="'color:' + semaforo(t).color">{{semaforo(t).texto}}</span></td><td>{{t.minutos ? horas(t.minutos) : '—'}}</td><td class="small muted">{{fechaHora(t.creado)}}</td>
      </tr></tbody></table></div>
    <Modal v-if="form" title="Ticket nuevo" @close="form=null" size="lg">
      <div class="grid cols-2">
        <Field label="Asunto" req style="grid-column:1/-1"><input v-model="form.asunto" maxlength="160" autofocus placeholder="La impresora de recepción no imprime"></Field>
        <Field label="Cliente"><Buscador v-model="form.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Sin cliente" @update:modelValue="clienteElegido"></Buscador></Field>
        <Field label="Quién solicita"><input v-model="form.solicitante" maxlength="80" placeholder="Nombre de la persona"></Field>
        <Field label="Correo" help="Recibe los avisos del ticket"><input v-model="form.correo" type="email" maxlength="120"></Field>
        <Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field>
        <Field label="Categoría"><select v-model="form.categoria"><option value="">—</option><option v-for="c in (cfg ? cfg.categorias : [])" :key="c" :value="c">{{c}}</option></select></Field>
        <Field label="Prioridad" :help="cfg ? 'SLA: ' + cfg.sla[form.prioridad] + ' h' : ''"><select v-model="form.prioridad"><option v-for="p in PRIORIDADES" :key="p[0]" :value="p[0]">{{p[1]}}</option></select></Field>
        <Field label="Técnico" style="grid-column:1/-1"><select v-model="form.tecnico_id"><option :value="null">Sin asignar</option><option v-for="u in tecnicos" :key="u.id" :value="u.id">{{u.nombre}}</option></select></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea rows="5" v-model="form.descripcion" maxlength="5000" placeholder="Qué pasa, desde cuándo, qué ya se intentó…"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">Crear ticket</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
