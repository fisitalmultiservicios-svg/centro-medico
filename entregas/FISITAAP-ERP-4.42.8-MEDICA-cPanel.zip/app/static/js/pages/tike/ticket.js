// TiKe › Ticket (3.52): detalle de un ticket con la bitácora (notas internas, respuestas al cliente que salen por correo, cambios y
// adjuntos), tiempo trabajado, asignación, prioridad y estado. Lo público lo ve el cliente en el portal.
import { api, toast, fechaHora, money } from '../../api.js';
import { store, sesion } from '../../app.js';
import { PRIORIDADES, ESTADOS, clasePrioridad, claseEstado, semaforo, horas } from './_comun.js';

export default {
  props: ['params'],
  data() { return { t: null, cfg: null, tecnicos: [], nueva: { tipo: 'respuesta', texto: '', minutos: 0, estado: '' }, enviando: false, edit: null, subiendo: false, PRIORIDADES, ESTADOS, item: null, fact: null, firma: false, equipos: [], contratos: [], ia: null, iaCargando: false }; },
  computed: {
    id() { return +this.params.id; },
    clientes() { return store.clientes.filter(c => c.activo !== false && c.tipo !== 'Proveedor'); },
    productos() { return store.productos.filter(p => p.activo !== false && p.es_venta !== false); },
    totalItems() { return (this.t && this.t.items ? this.t.items : []).reduce((s, x) => s + x.total, 0); },
    entradas() { return (this.t ? this.t.entradas : []).slice().reverse(); },
    estadosSiguientes() { if (!this.t) return []; const e = this.t.estado; const m = { nuevo: ['en_proceso', 'espera_cliente', 'resuelto', 'cerrado'], asignado: ['en_proceso', 'espera_cliente', 'resuelto', 'cerrado'], en_proceso: ['espera_cliente', 'resuelto', 'cerrado'], espera_cliente: ['en_proceso', 'resuelto', 'cerrado'], resuelto: ['en_proceso', 'cerrado'], cerrado: [] }; return this.ESTADOS.filter(x => (m[e] || []).includes(x[0])); },
  },
  methods: {
    fechaHora, clasePrioridad, claseEstado, semaforo, horas, money,
    async cargar() { try { this.t = await api('/api/tike/tickets/' + this.id); this.cargarRelaciones(); } catch (e) { toast(e.message, 'err'); } },
    async cargarRelaciones() {
      if (!this.t || !this.t.cliente_id) { this.equipos = []; this.contratos = []; return; }
      try { [this.equipos, this.contratos] = await Promise.all([api('/api/tike/equipos?cliente_id=' + this.t.cliente_id), api('/api/tike/contratos?cliente_id=' + this.t.cliente_id)]); } catch { this.equipos = []; this.contratos = []; }
    },
    async borradorIA() {
      const instruccion = window.prompt('Indicación para el borrador (opcional): por ejemplo «dile que vamos mañana a las 9»', '');
      if (instruccion === null) return;
      this.iaCargando = true;
      try { const r = await api('/api/ia/ticket/' + this.id + '/borrador', { method: 'POST', body: { instruccion: instruccion || '' } }); this.nueva.tipo = 'respuesta'; this.nueva.texto = r.borrador; toast('Borrador listo: revíselo antes de enviar', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.iaCargando = false;
    },
    async visita() { try { this.t = await api('/api/tike/tickets/' + this.id + '/entradas', { method: 'POST', body: { tipo: 'visita', texto: 'Llegada al sitio' } }); toast('Visita registrada', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async cambiarEquipo(ev) { try { this.t = await api('/api/tike/tickets/' + this.id, { method: 'PUT', body: { equipo_id: +ev.target.value || 0 } }); toast('Equipo actualizado', 'ok'); } catch (e) { toast(e.message, 'err'); this.cargar(); } },
    async cambiarContrato(ev) { try { this.t = await api('/api/tike/tickets/' + this.id, { method: 'PUT', body: { contrato_id: +ev.target.value || 0 } }); toast('Contrato actualizado', 'ok'); } catch (e) { toast(e.message, 'err'); this.cargar(); } },
    nuevoItem() { this.item = { producto_id: null, detalle: '', cantidad: 1, precio_unitario: null }; },
    productoElegido() { const p = this.productos.find(x => x.id === this.item.producto_id); if (p) { this.item.detalle = p.nombre; this.item.precio_unitario = +p.precio; } },
    async guardarItem() {
      const i = this.item; if (!i.producto_id && !(i.detalle || '').trim()) return toast('Elija un ítem o escriba el repuesto', 'err');
      try { await api('/api/tike/tickets/' + this.id + '/items', { method: 'POST', body: { producto_id: i.producto_id || null, detalle: i.detalle || '', cantidad: +i.cantidad || 1, precio_unitario: i.precio_unitario === null || i.precio_unitario === '' ? null : +i.precio_unitario } }); this.item = null; toast('Repuesto agregado', 'ok'); this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async quitarItem(x) { try { await api('/api/tike/tickets/' + this.id + '/items/' + x.id, { method: 'DELETE' }); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async abrirFacturar() {
      try { const p = await api('/api/tike/tickets/' + this.id + '/facturar'); this.fact = { ...p, tipo_documento: this.t.cliente_id ? '01' : '04', incluir_horas: p.horas > 0, horas_cobrar: p.horas, tarifa: p.tarifa_sugerida, incluir_items: p.items.length > 0, condicion_venta: '01', plazo_credito: 30, enviando: false }; }
      catch (e) { toast(e.message, 'err'); }
    },
    async facturar() {
      const f = this.fact; if (f.enviando) return; f.enviando = true;   // 3.87: un doble clic no arma dos borradores
      try { const r = await api('/api/tike/tickets/' + this.id + '/facturar', { method: 'POST', body: { tipo_documento: f.tipo_documento, incluir_horas: !!f.incluir_horas, horas: f.incluir_horas ? +f.horas_cobrar || 0 : 0, tarifa_hora: f.tarifa === null || f.tarifa === '' ? null : +f.tarifa, incluir_items: !!f.incluir_items, condicion_venta: f.condicion_venta, plazo_credito: f.condicion_venta === '02' ? +f.plazo_credito || 30 : null, cobrado_visto: f.cobrado_marca ?? null } }); this.fact = null; toast('Borrador creado por ' + money(r.total) + '; revíselo y emítalo', 'ok'); location.hash = '#' + r.ruta; }
      catch (e) { toast(e.message, 'err'); f.enviando = false; }
    },
    abrirFirma() { this.firma = true; this.$nextTick(() => { const c = this.$refs.lienzo; if (!c) return; const ctx = c.getContext('2d'); ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#111'; let dib = false, last = null;
      const pos = ev => { const r = c.getBoundingClientRect(); const p = ev.touches ? ev.touches[0] : ev; return { x: (p.clientX - r.left) * c.width / r.width, y: (p.clientY - r.top) * c.height / r.height }; };
      const ini = ev => { dib = true; last = pos(ev); ev.preventDefault(); }; const mov = ev => { if (!dib) return; const p = pos(ev); ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke(); last = p; ev.preventDefault(); }; const fin = () => { dib = false; };
      c.onmousedown = ini; c.onmousemove = mov; c.onmouseup = fin; c.onmouseleave = fin; c.ontouchstart = ini; c.ontouchmove = mov; c.ontouchend = fin; }); },
    limpiarFirma() { const c = this.$refs.lienzo; if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height); },
    async guardarFirma() {
      const c = this.$refs.lienzo; if (!c) return;
      c.toBlob(async blob => { try { const fd = new FormData(); fd.append('archivo', blob, 'firma-cliente.png'); await api('/api/tike/tickets/' + this.id + '/adjuntos', { method: 'POST', body: fd }); this.firma = false; toast('Firma guardada en la bitácora', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } }, 'image/png');
    },
    async enviar() {
      const n = this.nueva; if (!(n.texto || '').trim()) return toast('Escriba el texto', 'err');
      this.enviando = true;
      try { this.t = await api('/api/tike/tickets/' + this.id + '/entradas', { method: 'POST', body: { tipo: n.tipo, texto: n.texto.trim(), minutos: +n.minutos || 0, estado: n.estado || null } }); this.nueva = { tipo: n.tipo, texto: '', minutos: 0, estado: '' }; toast(n.tipo === 'respuesta' ? 'Respuesta enviada al cliente' : 'Nota guardada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.enviando = false;
    },
    async asignar(ev) { const id = ev.target.value ? +ev.target.value : null; try { this.t = await api('/api/tike/tickets/' + this.id + '/asignar', { method: 'POST', body: { tecnico_id: id } }); toast(id ? 'Asignado' : 'Sin asignar', 'ok'); } catch (e) { toast(e.message, 'err'); this.cargar(); } },
    async cambiarEstado(estado) {
      let motivo = '';
      if (estado === 'cerrado' && !['resuelto', 'cerrado'].includes(this.t.estado)) { motivo = window.prompt('Motivo del cierre sin resolver'); if (!motivo) return; }
      try { this.t = await api('/api/tike/tickets/' + this.id + '/estado', { method: 'POST', body: { estado, motivo } }); toast('Estado: ' + this.t.estado_nombre, 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    async cambiarPrioridad(ev) { try { this.t = await api('/api/tike/tickets/' + this.id, { method: 'PUT', body: { prioridad: ev.target.value } }); toast('Prioridad: ' + this.t.prioridad_nombre, 'ok'); } catch (e) { toast(e.message, 'err'); this.cargar(); } },
    editar() { const t = this.t; this.edit = { asunto: t.asunto, descripcion: t.descripcion, cliente_id: t.cliente_id, solicitante: t.solicitante, correo: t.correo, telefono: t.telefono, categoria: t.categoria }; },
    async guardarEdicion() { try { this.t = await api('/api/tike/tickets/' + this.id, { method: 'PUT', body: { ...this.edit, cliente_id: this.edit.cliente_id || 0 } }); this.edit = null; toast('Ticket actualizado', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async subir(ev) {
      const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = '';
      if (f.size > 8 * 1024 * 1024) return toast('El adjunto no puede pasar de 8 MB', 'err');
      this.subiendo = true;
      try { const fd = new FormData(); fd.append('archivo', f, f.name); await api('/api/tike/tickets/' + this.id + '/adjuntos', { method: 'POST', body: fd }); toast('Adjunto guardado', 'ok'); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
    iconoEntrada(x) { return { nota: '📝', respuesta: '📤', cliente: '👤', cambio: '↻', sistema: '⚙', visita: '📍' }[x.tipo] || '•'; },
    claseEntrada(x) { return x.tipo === 'cliente' ? 'cliente' : x.tipo === 'respuesta' ? 'respuesta' : x.tipo === 'nota' ? 'nota' : 'sistema'; },
  },
  async created() { this.cargar(); try { this.cfg = await api('/api/tike/config'); } catch {} try { this.tecnicos = await api('/api/tike/tecnicos'); } catch { this.tecnicos = []; } try { this.ia = await api('/api/ia/config'); } catch { this.ia = null; } },
  template: `
    <Modal v-if="item" title="Repuesto o material" @close="item=null">
      <Field label="Ítem del inventario" help="O escriba el detalle a mano"><Buscador v-model="item.producto_id" :opciones="productos" detalle="cabys" vacio="A mano" @update:modelValue="productoElegido"></Buscador></Field>
      <Field label="Detalle"><input v-model="item.detalle" maxlength="160"></Field>
      <div class="grid cols-2"><Field label="Cantidad"><input type="number" min="0.01" step="1" v-model.number="item.cantidad"></Field><Field label="Precio sin IVA" help="Vacío = el del ítem"><input type="number" min="0" step="100" v-model.number="item.precio_unitario"></Field></div>
      <template #foot><button class="btn ghost" @click="item=null">Cancelar</button><button class="btn" @click="guardarItem">Agregar</button></template>
    </Modal>
    <Modal v-if="fact" title="Facturar desde el ticket" @close="fact=null" size="lg">
      <p class="small muted" style="margin:0 0 8px">Se crea un borrador en Ventas con lo marcado; allí lo revisa y lo emite. {{fact.motivo}}.</p>
      <div class="grid cols-2">
        <Field label="Comprobante"><select v-model="fact.tipo_documento"><option value="01" :disabled="!t.cliente_id">Factura electrónica</option><option value="04">Tiquete electrónico</option></select></Field>
        <Field label="Condición"><select v-model="fact.condicion_venta"><option value="01">Contado</option><option value="02">Crédito</option></select></Field>
        <Field label="Plazo (días)" v-if="fact.condicion_venta==='02'"><input type="number" min="1" max="365" v-model.number="fact.plazo_credito"></Field>
      </div>
      <div class="card" style="margin-top:8px"><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="fact.incluir_horas"> Cobrar horas fuera de contrato</label>
        <div class="grid cols-2" style="margin-top:6px" v-if="fact.incluir_horas"><Field label="Horas" :help="'Quedan ' + fact.horas + ' h por cobrar' + (+fact.horas_cobrar > fact.horas ? ': está cobrando más de lo anotado (hora mínima o tarifa fija)' : '')"><input type="number" min="0" step="0.25" v-model.number="fact.horas_cobrar"></Field><Field label="Tarifa por hora (sin IVA)"><input type="number" min="0" step="500" v-model.number="fact.tarifa"></Field></div>
        <p class="small muted" style="margin:4px 0 0" v-if="fact.producto_horas">Ítem: {{fact.producto_horas.nombre}}</p></div>
      <div class="card" style="margin-top:8px" v-if="fact.items && fact.items.length"><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" v-model="fact.incluir_items"> Incluir {{fact.items.length}} repuesto(s): {{money(fact.items.reduce((s, x) => s + x.total, 0))}} + IVA</label></div>
      <template #foot><button class="btn ghost" @click="fact=null">Cancelar</button><button class="btn" @click="facturar" :disabled="fact.enviando">{{fact.enviando ? 'Creando…' : 'Crear el borrador'}}</button></template>
    </Modal>
    <Modal v-if="firma" title="Firma del cliente" @close="firma=false">
      <p class="small muted" style="margin:0 0 6px">Pida al cliente que firme con el dedo o el mouse. Queda como adjunto en la bitácora.</p>
      <canvas ref="lienzo" width="600" height="220" style="width:100%;border:1px dashed var(--line);border-radius:8px;background:#fff;touch-action:none"></canvas>
      <template #foot><button class="btn ghost" @click="limpiarFirma">Limpiar</button><button class="btn" @click="guardarFirma">Guardar firma</button></template>
    </Modal>
  <div class="page" v-if="t">
    <PageHead :title="t.codigo + ' · ' + t.asunto" :sub="(t.cliente_nombre || t.solicitante || 'Sin cliente') + (t.categoria ? ' · ' + t.categoria : '') + ' · abierto ' + fechaHora(t.creado) + ' por ' + t.origen" :crumbs="[{label:'TiKe'},{label:'Tickets',to:'/tike/tickets'},{label:t.codigo}]">
      <a class="btn ghost" href="#/tike/tablero">Tablero</a><button class="btn ghost" @click="editar" v-if="t.estado!=='cerrado'">Editar datos</button>
    </PageHead>
    <div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(280px,1fr);gap:12px;align-items:start">
      <div>
        <div class="card" v-if="t.estado!=='cerrado'"><h2>{{nueva.tipo==='respuesta' ? 'Responder al cliente' : 'Nota interna'}} <small>{{nueva.tipo==='respuesta' ? 'Sale por correo y se ve en el portal' : 'Solo la ve el equipo'}}</small></h2>
          <div class="seg" style="margin-bottom:8px;max-width:360px"><button :class="{on: nueva.tipo==='respuesta'}" @click="nueva.tipo='respuesta'">📤 Respuesta al cliente</button><button :class="{on: nueva.tipo==='nota'}" @click="nueva.tipo='nota'">📝 Nota interna</button></div>
          <textarea rows="4" v-model="nueva.texto" maxlength="5000" :placeholder="nueva.tipo==='respuesta' ? 'Hola, ya revisamos…' : 'Qué se hizo, qué falta…'" style="width:100%"></textarea>
          <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap;align-items:flex-end">
            <Field label="Tiempo trabajado (min)" style="margin:0;width:150px"><input type="number" min="0" step="5" v-model.number="nueva.minutos"></Field>
            <Field label="Y dejar el ticket en" style="margin:0;width:220px"><select v-model="nueva.estado"><option value="">— Sin cambiar —</option><option v-for="e in estadosSiguientes" :key="e[0]" :value="e[0]">{{e[1]}}</option></select></Field>
            <button class="btn" @click="enviar" :disabled="enviando">{{nueva.tipo==='respuesta' ? 'Enviar respuesta' : 'Guardar nota'}}</button>
            <label class="btn ghost" style="cursor:pointer">{{subiendo ? 'Subiendo…' : '📎 Adjuntar'}}<input type="file" style="display:none" @change="subir" :disabled="subiendo"></label>
            <button class="btn ghost" @click="visita" title="Registra la llegada al sitio (cuenta como visita del contrato)">📍 Llegué al sitio</button>
            <button class="btn ghost" @click="borradorIA" :disabled="iaCargando" v-if="ia && ia.disponible && ia.activo && ia.tickets" title="Redacta una respuesta con la bitácora del ticket">{{iaCargando ? 'Redactando…' : '✨ Borrador con IA'}}</button>
            <button class="btn ghost" @click="abrirFirma">✍ Firma del cliente</button>
          </div>
        </div>
        <div class="card" v-else><div class="alert info">Ticket cerrado {{fechaHora(t.cerrado_en)}}{{t.motivo_cierre ? ': ' + t.motivo_cierre : ''}}. Para seguir, abra uno nuevo.</div></div>
        <div class="card" style="margin-top:12px"><h2>Repuestos y materiales <small>Se facturan desde el ticket</small><button class="btn sm ghost" style="margin-left:auto" @click="nuevoItem" v-if="t.estado!=='cerrado'">+ Repuesto</button></h2>
          <p class="small muted" v-if="!t.items || !t.items.length" style="margin:0">Sin repuestos.</p>
          <table class="tabla" v-else><thead><tr><th>Detalle</th><th>Cant.</th><th>Precio</th><th>Total</th><th></th></tr></thead><tbody><tr v-for="x in t.items" :key="x.id"><td>{{x.detalle}}<span class="badge ok" v-if="x.facturado" style="margin-left:6px">facturado</span></td><td>{{x.cantidad}}</td><td>{{money(x.precio_unitario)}}</td><td>{{money(x.total)}}</td><td><button class="btn sm ghost" v-if="!x.facturado" @click="quitarItem(x)">Quitar</button></td></tr></tbody></table>
          <div class="row" style="gap:8px;margin-top:8px;align-items:center;flex-wrap:wrap"><b v-if="t.items && t.items.length">Repuestos: {{money(totalItems)}} + IVA</b><button class="btn sm" @click="abrirFacturar" v-if="sesion.puede('facturar') && (t.estado!=='cerrado' || (t.items && t.items.some(x => !x.facturado)) || (t.por_cobrar && (t.por_cobrar.horas > 0 || t.por_cobrar.repuestos > 0)))">🧾 Facturar desde el ticket</button><span class="small muted" v-if="t.por_cobrar && t.por_cobrar.ya_horas">{{t.por_cobrar.ya_horas}} h ya pasaron a un borrador de factura</span></div>
        </div>
        <div class="card" style="margin-top:12px"><h2>Descripción</h2><p style="white-space:pre-wrap;margin:0">{{t.descripcion || '—'}}</p></div>
        <div class="card" style="margin-top:12px"><h2>Bitácora <small>{{t.entradas.length}} entradas · {{horas(t.minutos)}} trabajadas</small></h2>
          <div v-for="x in entradas" :key="x.id" class="tk-entrada" :class="claseEntrada(x)">
            <div class="row small muted" style="gap:6px;justify-content:space-between;flex-wrap:wrap"><span>{{iconoEntrada(x)}} <b>{{x.usuario}}</b> · {{ {nota:'nota interna', respuesta:'respuesta al cliente', cliente:'el cliente', cambio:'cambio', sistema:'sistema', visita:'visita en sitio'}[x.tipo] }}<span v-if="x.origen!=='sistema'"> · por {{x.origen}}</span><span v-if="x.publico" class="badge ok" style="margin-left:6px">visible al cliente</span></span><span>{{fechaHora(x.creado)}}<span v-if="x.minutos"> · {{horas(x.minutos)}}</span></span></div>
            <div style="white-space:pre-wrap;margin-top:4px">{{x.texto}}</div>
            <div v-if="x.adjuntos && x.adjuntos.length" class="row" style="gap:6px;margin-top:4px;flex-wrap:wrap"><a v-for="a in x.adjuntos" :key="a.archivo" class="btn sm ghost" :href="'/api/tike/tickets/' + t.id + '/adjuntos/' + a.archivo" target="_blank" rel="noopener">📎 {{a.nombre}} <span class="muted">({{Math.round(a.tamano/1024)}} KB)</span></a></div>
          </div>
        </div>
      </div>
      <div>
        <div class="card"><h2>Estado</h2>
          <div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><span class="badge" :class="claseEstado(t.estado)" style="font-size:13px">{{t.estado_nombre}}</span><span class="badge" :class="clasePrioridad(t.prioridad)">{{t.prioridad_nombre}}</span></div>
          <div class="small" :style="'color:' + semaforo(t).color + ';margin-top:6px'">{{semaforo(t).texto}}<span class="muted" v-if="t.vence"> · plazo {{fechaHora(t.vence)}}</span></div>
          <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap"><button v-for="e in estadosSiguientes" :key="e[0]" class="btn sm" :class="e[0]==='resuelto' ? '' : 'sec'" @click="cambiarEstado(e[0])">{{e[1]}}</button></div>
          <Field label="Técnico" style="margin-top:10px"><select :value="t.tecnico_id || ''" @change="asignar" :disabled="!t.abierto"><option value="">Sin asignar</option><option v-for="u in tecnicos" :key="u.id" :value="u.id">{{u.nombre}}</option></select></Field>
          <Field label="Prioridad" :help="cfg ? 'SLA ' + cfg.sla[t.prioridad] + ' h desde la apertura' : ''"><select :value="t.prioridad" @change="cambiarPrioridad" :disabled="t.estado==='cerrado'"><option v-for="p in PRIORIDADES" :key="p[0]" :value="p[0]">{{p[1]}}</option></select></Field>
          <div class="small" v-if="t.calificacion" style="margin-top:6px">Calificación del cliente: <b>{{'★'.repeat(t.calificacion)}}{{'☆'.repeat(5 - t.calificacion)}}</b><div class="muted" v-if="t.calificacion_nota">{{t.calificacion_nota}}</div></div>
        </div>
        <div class="card" style="margin-top:12px"><h2>Cliente</h2>
          <div><b>{{t.cliente_nombre || 'Sin cliente del catálogo'}}</b></div>
          <div class="small" v-if="t.solicitante">Solicita: {{t.solicitante}}</div>
          <div class="small" v-if="t.correo">✉ <a :href="'mailto:' + t.correo">{{t.correo}}</a></div>
          <div class="small" v-if="t.telefono">☎ {{t.telefono}}<a class="btn sm ghost" :href="'https://wa.me/506' + t.telefono.replace(/\\D/g,'')" target="_blank" rel="noopener" style="margin-left:6px">WhatsApp</a></div>
          <div class="small muted" style="margin-top:6px" v-if="!t.correo">Sin correo: el cliente no recibe avisos de este ticket.</div>
          <a class="btn sm ghost" style="margin-top:6px" :href="'#/tike/documentacion?cliente_id=' + t.cliente_id + '&ticket_id=' + t.id" v-if="t.cliente_id">📚 Documentación del cliente</a>
          <Field label="Equipo" style="margin-top:8px" v-if="t.cliente_id"><select :value="t.equipo_id || ''" @change="cambiarEquipo" :disabled="t.estado==='cerrado'"><option value="">—</option><option v-for="q in equipos" :key="q.id" :value="q.id">{{q.codigo}} · {{q.nombre}}</option></select></Field>
          <Field label="Contrato" v-if="t.cliente_id" :help="t.contrato && t.contrato.consumo && t.contrato.consumo.incluido !== null ? 'Usado ' + t.contrato.consumo.usado + ' de ' + t.contrato.consumo.incluido + ' en el periodo' : ''"><select :value="t.contrato_id || ''" @change="cambiarContrato" :disabled="t.estado==='cerrado'"><option value="">Sin contrato (se cobra todo)</option><option v-for="c in contratos" :key="c.id" :value="c.id">{{c.nombre || c.tipo_nombre}}{{c.vigente ? '' : ' (vencido)'}}</option></select></Field>
          <div class="alert warn" v-if="t.contrato && t.contrato.consumo && t.contrato.consumo.alerta" style="margin-top:6px">La bolsa del contrato está por agotarse: usado {{t.contrato.consumo.usado}} de {{t.contrato.consumo.incluido}}.</div>
        </div>
        <div class="card" style="margin-top:12px"><h2>Tiempos</h2>
          <div class="small">Abierto: {{fechaHora(t.creado)}}</div><div class="small" v-if="t.primera_respuesta">Primera respuesta: {{fechaHora(t.primera_respuesta)}}</div>
          <div class="small" v-if="t.resuelto_en">Resuelto: {{fechaHora(t.resuelto_en)}}</div><div class="small" v-if="t.cerrado_en">Cerrado: {{fechaHora(t.cerrado_en)}}</div>
          <div class="small">Trabajado: <b>{{horas(t.minutos)}}</b></div>
        </div>
      </div>
    </div>
    <Modal v-if="edit" title="Datos del ticket" @close="edit=null" size="lg">
      <div class="grid cols-2">
        <Field label="Asunto" req style="grid-column:1/-1"><input v-model="edit.asunto" maxlength="160"></Field>
        <Field label="Cliente"><Buscador v-model="edit.cliente_id" :opciones="clientes" detalle="numero_id" vacio="Sin cliente"></Buscador></Field>
        <Field label="Quién solicita"><input v-model="edit.solicitante" maxlength="80"></Field>
        <Field label="Correo"><input v-model="edit.correo" type="email" maxlength="120"></Field><Field label="Teléfono"><input v-model="edit.telefono" maxlength="20"></Field>
        <Field label="Categoría"><select v-model="edit.categoria"><option value="">—</option><option v-for="c in (cfg ? cfg.categorias : [])" :key="c" :value="c">{{c}}</option></select></Field>
        <Field label="Descripción" style="grid-column:1/-1"><textarea rows="5" v-model="edit.descripcion" maxlength="5000"></textarea></Field>
      </div>
      <template #foot><button class="btn ghost" @click="edit=null">Cancelar</button><button class="btn" @click="guardarEdicion">Guardar</button></template>
    </Modal>
  </div>
  <div class="page" v-else><div class="card"><p class="muted">Cargando…</p></div></div>`,
  setup() { return { sesion }; },
};
