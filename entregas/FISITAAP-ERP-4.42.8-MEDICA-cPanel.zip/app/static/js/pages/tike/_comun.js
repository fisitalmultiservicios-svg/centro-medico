// TiKe (3.52): utilidades compartidas por las pantallas de tickets.
export const PRIORIDADES = [['baja', 'Baja'], ['media', 'Media'], ['alta', 'Alta'], ['critica', 'Crítica']];
export const ESTADOS = [['nuevo', 'Nuevo'], ['asignado', 'Asignado'], ['en_proceso', 'En proceso'], ['espera_cliente', 'En espera del cliente'], ['resuelto', 'Resuelto'], ['cerrado', 'Cerrado']];

export function clasePrioridad(p) { return { baja: '', media: 'info', alta: 'warn', critica: 'danger' }[p] || ''; }
export function claseEstado(e) { return { nuevo: 'warn', asignado: 'info', en_proceso: 'info', espera_cliente: '', resuelto: 'ok', cerrado: '' }[e] || ''; }

// Semáforo del SLA: verde con más del 25 % del plazo, ámbar con menos, rojo vencido; gris si está resuelto o cerrado.
export function semaforo(t) {
  if (!t.vence || !t.abierto) return { color: '#9ca3af', texto: t.abierto ? 'Sin plazo' : 'Cerrado' };
  const total = new Date(t.vence) - new Date(t.creado), resta = new Date(t.vence) - Date.now();
  if (resta < 0) return { color: 'var(--danger)', texto: 'Vencido hace ' + duracion(-resta) };
  if (total > 0 && resta / total < 0.25) return { color: 'var(--warn)', texto: 'Vence en ' + duracion(resta) };
  return { color: 'var(--ok)', texto: 'Vence en ' + duracion(resta) };
}

export function duracion(ms) {
  const m = Math.round(ms / 60000); if (m < 60) return m + ' min';
  const h = Math.floor(m / 60); if (h < 48) return h + ' h' + (m % 60 ? ' ' + (m % 60) + ' min' : '');
  return Math.floor(h / 24) + ' d ' + (h % 24) + ' h';
}

export function horas(min) { const m = +min || 0; return m < 60 ? m + ' min' : (m / 60).toFixed(m % 60 ? 1 : 0) + ' h'; }
