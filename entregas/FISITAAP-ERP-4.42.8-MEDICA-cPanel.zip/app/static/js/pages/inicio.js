// Inicio — Resumen del negocio. Cifras reales del servidor (/api/resumen) en todas las monedas de la empresa; cada tarjeta abre
// la sección correspondiente del Reporte ejecutivo (Reportes › Reporte ejecutivo) con el mismo período.
import { api, money, fmt, hoy, mock, fecha, toast } from '../api.js';
import { store, sesion, menuVisible, ICONO_MENU, hotelActivo, rutaPermitida } from '../app.js';
import { Monto, PERIODOS, otrasMonedas, principal, queryPeriodo, serie, etiquetaPeriodo } from './reportes/_montos.js';
// 3.87: las cuentas del hotel (pages/hotel/_datos.js, 68 KB) se importan solo en Hospitalidad, en created(); los demás tipos no las descargan
import { sumarDias } from '../api.js';
import { cajas as cajasPos, posVentas, resumenCaja as resumenCajaPos, ventasDe as ventasDePos, opcionesCierre } from './pos/_datos.js';   // Inicio de caja (3.23); 4.41: cierre ciego

const r2 = n => Math.round((+n || 0) * 100) / 100;

// Portada de FISITAAP by Brillante Agencia: una tarjeta por aplicación, sacadas del menú que ve esta empresa (tipo de negocio, plan, hotel y rol);
// aquí solo va el texto y el color de cada una
const APP_INFO = {
  'Ventas en línea': ['Página web, catálogo o menú, pedidos y entregas', '#eaf3ec', '#367c5a'], 'Punto de venta': ['Caja, mesas, cierres y cocina', '#eaf3ec', '#237658'],
  Ingresos: ['Facturas, cotizaciones y cobros', '#edf2f8', '#466b92'], Gastos: ['Compras, gastos, proveedores y cuentas por pagar', '#f7f1e9', '#aa8350'],
  Inventario: ['Ítems, existencias y costos', '#f1eef8', '#8a71a6'], Contactos: ['Clientes y proveedores', '#eaf4f5', '#4f8691'], 'Contactos y fiado': ['Clientes, proveedores y crédito', '#eaf4f5', '#4f8691'],
  Bancos: ['Cuentas de dinero y conciliaciones', '#edf2f8', '#466b92'], Contabilidad: ['Asientos, activos y presupuesto', '#f1f1f6', '#7b7ba0'],
  'Recursos humanos': ['Empleados, asistencia y planilla', '#f1eef8', '#8a71a6'], TiKe: ['Tickets, contratos y equipos del cliente', '#eaf4f5', '#4f8691'],
  Recepción: ['Tablero del día, huéspedes y cuentas', '#f8efef', '#a77777'], Reservaciones: ['Reservas, cotizaciones y grupos', '#eef2f8', '#6584aa'],
  Servicios: ['Agenda de servicios y liquidaciones', '#edf6ed', '#4b8b55'], 'Eventos y banquetes': ['Eventos, cotizaciones y salones', '#f9f3e6', '#ae8b48'],
  'Ama de llaves': ['Habitaciones, limpieza y lavandería', '#eaf3ec', '#367c5a'], Mantenimiento: ['Incidencias y preventivo', '#f7f1e9', '#aa8350'],
  Seguridad: ['Bitácora, visitantes e incidentes', '#f1f1f6', '#7b7ba0'], Reportes: ['Analítica del negocio', '#edf6ed', '#4b8b55'], Configuración: ['Empresa, usuarios y catálogos', '#eef2f8', '#6584aa'],
};
const primeraRuta = it => it.href || (it.to ? '#' + it.to : (it.children || []).map(primeraRuta).find(Boolean));

const WIDGETS = [['cobros', 'Cobros de los próximos 30 días'], ['planilla', 'Planilla y personal'], ['cxc', 'Cuentas por cobrar'], ['cxp', 'Cuentas por pagar'], ['iva', 'IVA del período'], ['items', 'Ítems vendidos'], ['devoluciones', 'Devoluciones de clientes'],
  ['clientes', 'Clientes con ventas'], ['ventas', 'Total de ventas'], ['flujo', 'Flujo de transacciones'], ['gastos', 'Distribución de gastos'], ['top-productos', 'Productos más vendidos'], ['top-clientes', 'Mejores clientes']];

export default {
  props: ['params'],
  components: { Monto },
  data() {
    return {
      periodo: 'mes', desde: hoy().slice(0, 8) + '01', hasta: hoy(), r: null, cargando: true, menu: false, error: '', iaOk: false, iaTexto: '', iaCargando: false,
      periodos: PERIODOS, widgets: WIDGETS, avisos: null, plan: null, tike: null,   // tike: configuración de TiKe para el paso del buzón (3.58, Servicios)
      H: null,   // 3.87: módulo pages/hotel/_datos.js (solo Hospitalidad)
      ocultos: JSON.parse(localStorage.getItem('dash:ocultos') || '[]'),
      pasosOcultos: !!localStorage.getItem('dash:pasos:' + sesion.empresa_id),
    };
  },
  computed: {
    // 3.87: el resumen financiero es de quien ve reportes o todo (el servidor responde 403 a los demás: Vendedor, Cajero, técnicos…)
    veResumen() { return sesion.puede('reportes') || sesion.puede('ver_todo'); },
    // 4.28 (P-5): pago pendiente del plan dentro de los días de gracia (el sistema funciona completo); vencido lo dice la franja de arriba
    pagoPendiente() { const p = sesion.empresaInfo && sesion.empresaInfo.plan; return p && p.estado_pago === 'en_gracia' && p.aviso_pago ? p : null; },
    pagoEnLinea() { return !!(this.pagoPendiente && this.pagoPendiente.pago_en_linea) && rutaPermitida('/configuracion/suscripcion'); },   /* 4.28 (C4): la misma regla del menú para esa pantalla */
    apps() {
      if (!sesion.empresa_id) return [];
      return menuVisible().filter(it => !it.accion && !['Inicio', 'Mis tareas'].includes(it.label)).map(it => {
        const info = APP_INFO[it.label] || ['', '#eef4f8', '#3e647e'];
        const sub = it.label === 'Contabilidad' && (it.children || []).some(c => c.label === 'Ingresos') ? 'Ingresos, bancos y contabilidad' : info[0];
        return { nombre: it.label, sub, tint: info[1], color: info[2], icono: it.icono || ICONO_MENU[it.label] || 'box', href: primeraRuta(it) };
      }).filter(a => a.href);
    },
    // Primeros pasos (2.5): lista de arranque según el tipo de negocio, para quien configura; se oculta cuando ya no hace falta
    pasos() {
      if (!sesion.empresa_id || !sesion.puede('configurar') || this.pasosOcultos) return null;
      const e = store.empresa || {}, hacienda = !!(e.usuario_hacienda && e.p12_nombre), items = (store.productos || []).length > 0, contactos = (store.clientes || []).length > 0;
      // (3.19) el punto de venta cuenta como configurado cuando alguna caja tiene cuenta para el efectivo, mesas o bodega; la primera
      // reserva, venta o factura se reconocen por los registros y por los documentos del resumen
      const pc = mock.get('pos_config', null), terms = pc && Array.isArray(pc.terminales) ? pc.terminales : (pc && typeof pc === 'object' && Object.keys(pc).length ? [pc] : []);
      const posListo = terms.some(t => t && ((t.cuentas && Object.values(t.cuentas).some(Boolean)) || (Array.isArray(t.mesas) && t.mesas.length) || t.bodega_id));
      const reservaHecha = (mock.get('hotel_reservas', []) || []).some(r => r && r.tipo !== 'bloqueo');
      const ventaHecha = (mock.get('pos_ventas', []) || []).length > 0 || (mock.get('pos_cajas', []) || []).some(c => (c.ventas || []).length);
      const facturaHecha = ventaHecha || !!(this.r && this.r.documentos > 0);
      const base = [sesion.electronica ? { t: 'Complete los datos de la empresa y la conexión con Hacienda (usuario, llave criptográfica)', a: '#/configuracion', ok: hacienda }
        : { t: 'Facturación electrónica apagada: el sistema emite comprobantes internos (se enciende en Configuración › Hacienda cuando la necesite)', a: '#/configuracion/hacienda', ok: true }];   /* 3.61 */
      const lista = sesion.tipo === 'hospitalidad'
        ? [...base, { t: 'Defina categorías, habitaciones, temporadas y precios, y marque «Hotel activo»', a: '#/hotel/configuracion', ok: hotelActivo() },
           { t: 'Cree los ítems de venta del restaurante, bar o tienda (también sirven para cargos a la habitación)', a: '#/inventario/items', ok: items },
           { t: 'Configure el punto de venta (cajas, medios de pago, impresión)', a: '#/pos/configuracion', ok: posListo },
           { t: 'Registre su primera reservación', a: '#/hotel/reservaciones', ok: reservaHecha }]
        : sesion.tipo === 'comercio'
        ? [...base, { t: 'Cree los ítems de venta con sus precios e inventario', a: '#/inventario/items', ok: items },
           { t: 'Configure el punto de venta (cajas, medios de pago, impresión)', a: '#/pos/configuracion', ok: posListo },
           { t: 'Abra la caja y haga su primera venta', a: '#/pos/caja', ok: ventaHecha }]
        : sesion.tipo === 'restaurante'   // 3.57: antes caía en la lista de Facturación («Emita su primera factura»)
        ? [...base, { t: 'Cree los platos y bebidas del menú con sus precios', a: '#/inventario/items', ok: items },
           { t: 'Configure el punto de venta (cajas, mesas, medios de pago, impresión)', a: '#/pos/configuracion', ok: posListo },
           { t: 'Abra la caja y haga su primera venta', a: '#/pos/caja', ok: ventaHecha },
           { t: 'Publique su página en Ventas en línea › Mi página para recibir pedidos en línea', a: '#/fisitaap/pagina', ok: ventaHecha && facturaHecha }]
        : sesion.tipo === 'servicios'
        ? [...base, { t: 'Agregue sus clientes en Contactos', a: '#/contactos', ok: contactos },
           { t: 'Cree sus servicios de venta (con su código CABYS)', a: '#/inventario/items', ok: items },
           { t: 'Configure TiKe (categorías, plazos de atención y portal del cliente)', a: '#/tike/configuracion', ok: facturaHecha },
           // 3.58: prueba guiada del buzón: queda listo cuando la última lectura del buzón fue correcta
           { t: 'Conecte el buzón de correo de TiKe y pruébelo (los correos a soporte@ abren tickets)', a: '#/tike/configuracion?ir=buzon', ok: !!(this.tike && this.tike.buzon_ultimo && !this.tike.buzon_error) },
           { t: 'Emita su primera factura', a: '#/ventas/facturas/nueva', ok: facturaHecha }]
        : [...base, { t: 'Agregue sus clientes y proveedores en Contactos', a: '#/contactos', ok: contactos },
           { t: 'Cree sus ítems de venta (productos o servicios con su código CABYS)', a: '#/inventario/items', ok: items },
           { t: 'Emita su primera factura', a: '#/ventas/facturas/nueva', ok: facturaHecha }];
      return lista.every(p => p.ok) ? null : lista;
    },
    p() { return principal(); },
    // Inicio de caja (3.23): para comercio (o cualquier empresa con caja): ventas de hoy por hora, ticket promedio, lo más vendido hoy,
    // cajas abiertas y diferencias de los últimos cierres. No aplica al hotel (tiene su propio tablero).
    pg() {
      if (sesion.tipo !== 'comercio' || !sesion.puede('pos')) return null;   /* solo Comercio: Facturación no tiene caja y el hotel tiene su tablero (3.42) */
      const todas = cajasPos(), ventas = posVentas(); if (!todas.length && !ventas.length) return null;
      const hoyS = hoy(), local = iso => { const d = new Date(iso); return isNaN(d) ? String(iso || '').slice(0, 10) : d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
      const porCaja = {}; for (const c of todas) porCaja[c.id] = c;
      const vh = [...ventas, ...todas.flatMap(c => (c.ventas || []).map(v => ({ ...v, caja_id: c.id })))].filter(v => !v.anulada && !v.abono && local(v.hora) === hoyS);
      const total = r2(vh.reduce((s, v) => s + (+v.total || 0), 0)), n = vh.length;
      const horas = {}; for (const v of vh) { const h = new Date(v.hora).getHours(); horas[h] = r2((horas[h] || 0) + (+v.total || 0)); }
      const hs = Object.keys(horas).map(Number); const h0 = hs.length ? Math.min(...hs) : 8, h1 = hs.length ? Math.max(...hs) : 20;
      const serie = []; for (let h = h0; h <= h1; h++) serie.push({ h, total: horas[h] || 0 });
      const maxH = Math.max(1, ...serie.map(x => x.total));
      const prods = {}; let conDetalle = 0;
      for (const v of vh) { if (!Array.isArray(v.lineas)) continue; conDetalle++; for (const l of v.lineas) { const o = prods[l.detalle] || (prods[l.detalle] = { nombre: l.detalle, cantidad: 0, total: 0 }); o.cantidad = r2(o.cantidad + (+l.cantidad || 0)); o.total = r2(o.total + ((+l.cantidad || 0) * (+l.precio || 0) - (+l.descuento || 0)) * (1 + (+l.tarifa || 0) / 100)); } }
      const top = Object.values(prods).sort((a, b) => b.total - a.total).slice(0, 6);
      const abiertas = todas.filter(c => c.estado === 'Abierta').map(c => { const r = resumenCajaPos(c); return { id: c.id, caja: c.caja, usuario: c.usuario, abierta_en: c.abierta_en, ventas: r.ventas, total: r.total }; });
      /* 4.41: la diferencia (o «cuadró») de un cierre solo si este usuario puede ver el corte de esa caja (cierre ciego completo); si no, null */
      const cierres = todas.filter(c => c.estado !== 'Abierta' && c.cerrada_en).sort((a, b) => String(b.cerrada_en).localeCompare(String(a.cerrada_en))).slice(0, 5).map(c => ({ id: c.id, caja: c.caja, fecha: c.fecha, usuario: c.usuario, total: resumenCajaPos(c).total, diferencia: opcionesCierre(c).corte ? (+c.diferencia || 0) : null }));
      const porMedio = {}; for (const v of vh) for (const m of v.medios || []) porMedio[m.medio] = r2((porMedio[m.medio] || 0) + (+m.monto || 0));
      return { n, total, ticket: n ? r2(total / n) : 0, items: r2(vh.reduce((s, v) => s + (+v.items || 0), 0)), serie, maxH, top, conDetalle, abiertas, cierres, porMedio };
    },
    otras() { return otrasMonedas(this.r); },
    serie() { return serie(this.r, 31); },
    visibles() { return this.widgets.filter(w => !this.ocultos.includes(w[0])); },
    // planilla: de los registros de RRHH (empleados activos, último mes pagado y aguinaldo acumulado desde diciembre)
    planilla() {
      if (!sesion.puede('rrhh')) return null;
      const emp = (mock.get('empleados', []) || []).filter(e => e.activo !== false), pl = (mock.get('planillas', []) || []).slice().sort((a, b) => String(b.hasta).localeCompare(String(a.hasta)));
      if (!emp.length && !pl.length) return null;
      const ult = pl[0] || null, hoyS = hoy(), inicioAg = (+hoyS.slice(0, 4) - (+hoyS.slice(5, 7) === 12 ? 0 : 1)) + '-12-01';
      const bruto = pl.filter(p => String(p.desde) >= inicioAg).reduce((s, p) => s + (+(p.totales || {}).bruto || 0), 0);
      return { empleados: emp.length, ultima: ult, costo: ult ? +(ult.totales || {}).costo_total || 0 : 0, neto: ult ? +(ult.totales || {}).neto || 0 : 0,
               cargas: ult ? +(ult.totales || {}).total_patronal || 0 : 0, aguinaldo: Math.round(bruto / 12) };
    },
    // hotel (2.2): llegadas, salidas, en casa y ocupación de hoy
    hotel() { const H = this.H; if (!H || !H.hotelActivo()) return null; const d = H.listasDelDia(H.hoyHotel()), o = H.ocupacionDia(H.hoyHotel(), undefined, H.habitaciones()); return { llegadas: d.llegadas.length, salidas: d.salidas.length, en_casa: d.enCasa.length, ocupacion: o.pct, libres: o.libres, total: o.total }; },
    // Tablero del gerente del hotel (3.20): el mes y el año (ocupación, ADR, RevPAR) contra el mes anterior, ingresos del mes por
    // concepto, pick-up de la semana, pronóstico a 30 días, por cobrar a agencias y cancelaciones; todo de los registros del hotel
    hg() {
      const H = this.H; if (!H || !H.hotelActivo()) return null;
      const { ocupacionDia, habitaciones: habitacionesHotel, reservas: reservasHotel, folios: foliosHotel, esEstadia, conceptoDe, nombreConcepto, totalCargo, config: configHotel, fechasEntre, noches: nochesHotel } = H;
      const cfg = configHotel(), mon = cfg.moneda || 'USD', hoyS = hoy(), todas = reservasHotel(), rs = todas.filter(esEstadia), fs = foliosHotel(), habs = habitacionesHotel();
      const mesIni = hoyS.slice(0, 8) + '01', anioIni = hoyS.slice(0, 4) + '-01-01', antFin = sumarDias(mesIni, -1), antIni = antFin.slice(0, 8) + '01';
      const periodo = (d, h) => {
        let oc = 0, tot = 0;
        for (const f of fechasEntre(d, nochesHotel(d, h) + 1)) { const o = ocupacionDia(f, todas, habs); oc += o.ocupadas; tot += o.total; }
        const ing = r2(fs.filter(x => x.tipo === 'cargo' && x.origen === 'hospedaje' && x.fecha >= d && x.fecha <= h).reduce((s, x) => s + totalCargo(x), 0));
        return { pct: tot ? Math.round(oc / tot * 100) : 0, adr: oc ? r2(ing / oc) : 0, revpar: tot ? r2(ing / tot) : 0, ing, noches: oc };
      };
      const mes = periodo(mesIni, hoyS), ant = periodo(antIni, antFin), anio = periodo(anioIni, hoyS);
      const porC = {};
      for (const f of fs.filter(x => x.tipo === 'cargo' && x.fecha >= mesIni && x.fecha <= hoyS)) { const k = conceptoDe(f); porC[k] = r2((porC[k] || 0) + totalCargo(f)); }
      const conceptos = Object.entries(porC).map(([k, v]) => ({ k, nombre: nombreConcepto(k), monto: v })).sort((a, b) => b.monto - a.monto);
      const totalMes = r2(conceptos.reduce((s, c) => s + c.monto, 0));
      const d7 = sumarDias(hoyS, -6), nuevas = rs.filter(r => String(r.creado || '').slice(0, 10) >= d7 && !['cancelada', 'no_show'].includes(r.estado));
      const pickup = { reservas: nuevas.length, noches: nuevas.reduce((s, r) => s + nochesHotel(r.llegada, r.salida), 0), total: r2(nuevas.reduce((s, r) => s + (+r.total || 0), 0)) };
      const pron = fechasEntre(hoyS, 30).map(f => { const o = ocupacionDia(f, todas, habs); return { f, pct: o.pct, ocupadas: o.ocupadas, total: o.total }; });
      const pronProm = Math.round(pron.reduce((s, x) => s + x.pct, 0) / 30);
      const agencias = r2(fs.filter(f => f.a_agencia && !f.documento_id).reduce((s, f) => s + totalCargo(f), 0));
      const enMes = r => r.llegada >= mesIni && r.llegada <= hoyS;
      // mejores huéspedes del mes (G2): gasto de sus cuentas (cargos del mes) por huésped; las agencias aparte
      const porRes = {}; for (const r of rs) porRes[r.id] = r;
      const gasto = {};
      for (const f of fs.filter(x => x.tipo === 'cargo' && x.fecha >= mesIni && x.fecha <= hoyS)) { const r = porRes[f.reserva_id]; if (!r) continue; const k = r.huesped_id ? 'h' + r.huesped_id : 'r' + r.id; const o = gasto[k] || (gasto[k] = { nombre: r.huesped_nombre || r.numero, monto: 0, noches: 0, ids: new Set() }); o.monto = r2(o.monto + totalCargo(f)); o.ids.add(r.id); }
      const topHuespedes = Object.values(gasto).map(x => ({ nombre: x.nombre, monto: x.monto, estadias: x.ids.size })).sort((a, b) => b.monto - a.monto).slice(0, 6);
      // H7: indicadores, alertas y tareas de hoy, con la fecha de trabajo del hotel. Quien no recibe montos (hotel_folios llega vacío)
      // vería ADR, RevPAR y RevPOR en cero como si fueran reales: esos tres y la gráfica se muestran solo con veMontos
      const veMontos = sesion.puede('escribir') || sesion.puede('cobros') || sesion.puede('facturar') || sesion.puede('ver_todo');
      return { hoyT: H.tableroHotel(H.hoyHotel()), veMontos, mon, mes, ant, anio, conceptos, totalMes, pickup, pron, pronProm, agencias, topHuespedes, canc: rs.filter(r => enMes(r) && r.estado === 'cancelada').length, ns: rs.filter(r => enMes(r) && r.estado === 'no_show').length,
               varPct: ant.noches ? mes.pct - ant.pct : null, varAdr: ant.adr ? r2((mes.adr - ant.adr) / ant.adr * 100) : null, mesNombre: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'][+hoyS.slice(5, 7) - 1] };
    },
    maxFlujo() { const f = this.avisos && this.avisos.flujo; return f ? Math.max(f.vencido, ...f.semanas.map(x => x.monto), 1) : 1; },
    gastos() { const g = (this.r && this.r.gastos_por_proveedor) || []; const tot = g.reduce((s, x) => s + (x.monto[this.p] || 0), 0) || 1; return g.map(x => ({ ...x, pct: Math.round((x.monto[this.p] || 0) / tot * 100) })); },
  },
  methods: {
    async resumenIA() {
      this.iaCargando = true;
      try { const q = queryPeriodo(this.periodo, this.desde, this.hasta); const r = await api('/api/ia/resumen', { method: 'POST', body: { desde: q.desde || null, hasta: q.hasta || null } }); this.iaTexto = r.resumen; }
      catch (e) { toast(e.message, 'err'); }
      this.iaCargando = false;
    },
    money, fmt, etiquetaPeriodo, fecha,
    toggle(w) { const i = this.ocultos.indexOf(w); i >= 0 ? this.ocultos.splice(i, 1) : this.ocultos.push(w); localStorage.setItem('dash:ocultos', JSON.stringify(this.ocultos)); },
    vis(w) { return (!this.veResumen && (w === 'cobros' || w === 'planilla')) || !this.ocultos.includes(w); },   // 3.87: sin resumen no hay «Agregar gráfica» para volver a mostrarlas (dash:ocultos es del navegador)
    ocultarPasos() { this.pasosOcultos = true; localStorage.setItem('dash:pasos:' + sesion.empresa_id, '1'); },
    link(tema) { if (!(sesion.puede('reportes') || sesion.puede('ver_todo'))) return null; return '#/reportes/ejecutivo?tema=' + tema + '&' + queryPeriodo(this.periodo, this.desde, this.hasta); },
    async cargar() {
      this.cargando = true; this.error = '';
      const avisos = this.avisos ? null : api('/api/inicio/alertas').catch(e => { if (e && e.detail && e.detail.codigo === 'sin_caja') this.error = e.message; return { alertas: [], flujo: null }; });   // 3.87: en paralelo con el resumen; sin_caja: el aviso queda fijo (respaldo de la pantalla SinCaja)
      if (this.veResumen) {
        try { this.r = await api('/api/resumen?' + queryPeriodo(this.periodo, this.desde, this.hasta)); }
        catch (e) { this.error = e.message; }
      } else this.r = null;   // 3.87: sin reportes ni ver_todo no se pide (daba «No se pudo cargar el resumen: Su rol no tiene acceso a los reportes»)
      this.cargando = false;
      if (avisos) this.avisos = await avisos;
    },
    pct(v, max) { return max ? Math.max(4, Math.round(v / max * 100)) : 0; },
  },
  watch: { periodo() { if (this.periodo !== 'rango') this.cargar(); }, desde() { if (this.periodo === 'rango') this.cargar(); }, hasta() { if (this.periodo === 'rango') this.cargar(); } },
  created() {
    if (!sesion.empresa_id) { this.cargando = false; return; }   // 3.87: sin empresa elegida no hay resumen que pedir
    if (sesion.inicio !== '/inicio') { this.cargando = false; return; }   // 3.87: montada un instante mientras el rol salta a su pantalla (recarga): no pide nada
    if (sesion.tipo === 'hospitalidad') import('./hotel/_datos.js').then(m => { this.H = m; }).catch(() => {});
    this.cargar(); if (sesion.puede('ver_todo')) api('/api/ia/config').then(c => { this.iaOk = !!(c && c.disponible && c.activo && c.resumen); }).catch(() => {}); api('/api/plan').then(p => { this.plan = p; }).catch(() => {});
    if (sesion.tipo === 'servicios' && sesion.tieneModulo('tike') && sesion.puede('configurar')) api('/api/tike/config').then(c => { this.tike = c; }).catch(() => {});   // paso del buzón (3.58)
  },
  template: `
  <div class="page">
    <div class="alert warn" v-if="pagoPendiente" style="margin-bottom:12px;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap"><span><b>{{pagoPendiente.aviso_pago}}</b><template v-if="!pagoEnLinea"> Para ponerse al día escríbanos a {{sistemaCfg().correo_ventas}}.</template></span><a v-if="pagoEnLinea" class="btn sm" href="#/configuracion/suscripcion">Pagar ahora</a></div>
    <Modal v-if="iaTexto" title="Resumen con IA" @close="iaTexto=''" size="lg"><p style="white-space:pre-wrap;line-height:1.55;margin:0">{{iaTexto}}</p><p class="small muted" style="margin:10px 0 0">Redactado por la IA con los datos del periodo elegido. Revise las cifras en los reportes antes de tomar decisiones.</p><template #foot><button class="btn" @click="iaTexto=''">Cerrar</button></template></Modal>
    <div class="erp-intro">
      <div><p class="eyebrow">{{store.sistema.nombre || 'FISITAAP by Brillante Agencia'}} · Mi espacio</p><h1>Un ERP. Muchas posibilidades.</h1><p>Hola, {{store.empresa?.nombre_comercial || store.empresa?.nombre || 'bienvenido'}}. Sus aplicaciones comparten clientes, inventario y finanzas{{r ? ' · así va el negocio del ' + etiquetaPeriodo(r) : ''}}.</p></div>
      <div class="erp-page-tools" v-if="veResumen">
        <select class="inp" v-model="periodo"><option v-for="p in periodos" :value="p[0]">{{p[1]}}</option></select>
        <template v-if="periodo==='rango'"><input type="date" class="inp" v-model="desde"><input type="date" class="inp" v-model="hasta"></template>
        <button class="btn ghost" v-if="iaOk" @click="resumenIA" :disabled="iaCargando">{{iaCargando ? 'Redactando…' : '✨ Resumen con IA'}}</button>
        <div style="position:relative"><button class="btn sec" @click="menu=!menu">Agregar gráfica ▾</button>
          <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:240px;padding:8px">
            <label v-for="w in widgets" :key="w[0]" class="row" style="padding:5px 8px;cursor:pointer"><input type="checkbox" :checked="vis(w[0])" @change="toggle(w[0])"> {{w[1]}}</label>
          </div></div>
      </div>
    </div>
    <div class="erp-apps" v-if="apps.length"><a v-for="a in apps" :key="a.nombre" class="app-card" :href="a.href" :style="'--tint:' + a.tint + ';--color:' + a.color"><span class="app-dot"></span><span class="app-icon"><Icono :n="a.icono"></Icono></span><strong>{{a.nombre}}</strong><small>{{a.sub}}</small></a></div>
    <div class="alert warn" v-if="error">No se pudo cargar el resumen: {{error}}</div>
    <div class="alert" :class="plan.docs_usados >= plan.limite_docs ? 'danger' : (plan.docs_usados >= plan.limite_docs * 0.8 ? 'warn' : 'info')" v-if="plan && plan.limite_docs" style="margin-bottom:12px" title="Solo cuentan los comprobantes electrónicos emitidos a Hacienda en producción; los internos, los de pruebas y los importados de otro sistema no (4.5)"><b>Plan {{plan.nombre}}:</b> {{plan.docs_usados}} de {{plan.limite_docs}} comprobantes electrónicos {{plan.periodo === 'anio' ? 'este año' : 'este mes'}}<span v-if="plan.vence"> · vence el {{plan.vence}}</span><span v-if="plan.docs_usados >= plan.limite_docs"> · llegó al límite: agregue un paquete de comprobantes o pase al plan siguiente ({{sistemaCfg().correo_ventas}})</span><span v-else-if="plan.docs_usados >= plan.limite_docs * 0.8"> · se acerca al límite</span></div>
    <div class="alert info" v-else-if="r && otras.length && !r.tc_disponible">No hay tipo de cambio disponible (ni el del día ni uno anterior guardado): lo emitido en dólares se convierte con el tipo de cambio de cada comprobante, pero lo emitido en colones no tiene equivalente en dólares hasta que se actualice en Configuración › Monedas.</div>
    <div class="card" v-if="pasos" style="margin-bottom:14px"><h2>Primeros pasos <small>{{pasos.filter(p=>p.ok).length}} de {{pasos.length}} listos</small><button class="btn sm ghost" style="float:right" @click="ocultarPasos">Ocultar</button></h2>
      <div v-for="(p, i) in pasos" :key="i" class="row" style="gap:10px;padding:6px 0;align-items:center;border-top:1px solid var(--line)"><span :class="p.ok ? 'badge ok' : 'badge'">{{p.ok ? '✓' : i + 1}}</span><span :style="p.ok ? 'text-decoration:line-through;opacity:.6' : ''" style="flex:1">{{p.t}}</span><a v-if="!p.ok" class="btn sm sec" :href="p.a">Ir</a></div>
    </div>
    <div class="card" v-if="avisos && avisos.alertas.length" style="margin-bottom:14px"><h2>Requiere su atención</h2>
      <div v-for="(a, i) in avisos.alertas" :key="i" class="alert" :class="a.nivel" style="margin:6px 0;display:flex;justify-content:space-between;gap:10px;align-items:center">
        <span>{{a.texto}}</span><a v-if="a.enlace" class="btn sm sec" :href="a.enlace">Ver</a></div>
    </div>
    <div class="dash" v-if="r || !veResumen">
      <a class="card w6" v-if="r && hotel" href="#/hotel/recepcion" style="margin:0"><h2>Hotel hoy <small>{{hotel.ocupacion}} % de ocupación · {{hotel.libres}} de {{hotel.total}} libres</small></h2>
        <div class="dash" style="gap:10px;margin:0">
          <div class="kpi w3" style="margin:0"><div class="t">Llegadas pendientes</div><div class="v">{{hotel.llegadas}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Salidas de hoy</div><div class="v">{{hotel.salidas}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">En casa</div><div class="v">{{hotel.en_casa}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Ocupación</div><div class="v">{{hotel.ocupacion}} %</div></div>
        </div></a>
      <template v-if="r && hg">
      <a class="card w6" :href="'#/hotel/reportes?rep=ocupacion&desde=' + hoy().slice(0, 8) + '01&hasta=' + hoy()" style="margin:0" title="Ocupación diaria del mes"><h2>{{hg.mesNombre}} <small>ocupación, tarifa promedio y RevPAR contra el mes anterior · hospedaje {{money(hg.mes.ing, hg.mon)}}</small></h2>
        <div class="dash" style="gap:10px;margin:0">
          <div class="kpi w3" style="margin:0"><div class="t">Ocupación</div><div class="v">{{hg.mes.pct}} %</div><div class="d" v-if="hg.varPct !== null" :style="hg.varPct >= 0 ? 'color:var(--ok)' : 'color:var(--danger)'">{{hg.varPct >= 0 ? '+' : ''}}{{hg.varPct}} pts vs. {{hg.ant.pct}} %</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Tarifa promedio (ADR)</div><div class="v" style="font-size:18px">{{money(hg.mes.adr, hg.mon)}}</div><div class="d" v-if="hg.varAdr !== null" :style="hg.varAdr >= 0 ? 'color:var(--ok)' : 'color:var(--danger)'">{{hg.varAdr >= 0 ? '+' : ''}}{{fmt(hg.varAdr, 1)}} % vs. {{money(hg.ant.adr, hg.mon)}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">RevPAR</div><div class="v" style="font-size:18px">{{money(hg.mes.revpar, hg.mon)}}</div><div class="d">mes anterior {{money(hg.ant.revpar, hg.mon)}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Año a la fecha</div><div class="v">{{hg.anio.pct}} %</div><div class="d">ADR {{money(hg.anio.adr, hg.mon)}} · {{money(hg.anio.ing, hg.mon)}}</div></div>
        </div></a>
      <a class="card w6" :href="'#/hotel/reportes?rep=informe_diario&desde=' + hg.hoyT.fecha + '&hasta=' + hg.hoyT.fecha" style="margin:0" title="Informe diario"><h2>Hoy <small>{{fecha(hg.hoyT.fecha)}} · {{hg.hoyT.ocupadas}} de {{hg.hoyT.total}} habitaciones ocupadas ({{hg.hoyT.pct}} %)</small></h2>
        <div class="dash" style="gap:10px;margin:0 0 8px">
          <template v-if="hg.veMontos">
          <div class="kpi w3" style="margin:0" title="Tarifa promedio: el hospedaje de hoy entre las habitaciones ocupadas"><div class="t">Tarifa promedio (ADR)</div><div class="v" style="font-size:18px">{{money(hg.hoyT.adr, hg.mon)}}</div><div class="d">solo hospedaje</div></div>
          <div class="kpi w3" style="margin:0" title="El hospedaje de hoy entre todas las habitaciones, ocupadas o no"><div class="t">RevPAR</div><div class="v" style="font-size:18px">{{money(hg.hoyT.revpar, hg.mon)}}</div><div class="d">solo hospedaje</div></div>
          <div class="kpi w3" style="margin:0" title="Todos los cargos de hoy (hospedaje, restaurante, servicios y los demás conceptos) entre las habitaciones ocupadas"><div class="t">RevPOR</div><div class="v" style="font-size:18px">{{money(hg.hoyT.revpor, hg.mon)}}</div><div class="d">todos los conceptos</div></div>
          </template>
          <div class="kpi w3" style="margin:0" title="Habitaciones que hoy no se pueden vender: con un bloqueo de fechas o en mantenimiento"><div class="t">Bloqueadas o fuera de servicio</div><div class="v">{{hg.hoyT.bloqueadas + hg.hoyT.fuera}}</div><div class="d">{{hg.hoyT.bloqueadas}} con bloqueo · {{hg.hoyT.fuera}} en mantenimiento</div></div>
        </div>
        <div class="chart" style="height:110px" v-if="hg.veMontos" title="Ingreso de los últimos 8 días: todos los cargos, con IVA"><div class="b" v-for="d in hg.hoyT.ingresos8" :key="d.fecha"><i :style="{height: Math.max(3, Math.round(d.total / hg.hoyT.maxIngreso * 100)) + '%'}" :title="fecha(d.fecha) + ': ' + money(d.total, hg.mon)"></i>{{+d.fecha.slice(8)}}</div></div></a>
      <div class="card w6" style="margin:0"><h2>Alertas y tareas <small>{{hg.hoyT.alertas.length ? hg.hoyT.alertas.length + ' alerta(s) del hotel' : 'sin alertas del hotel'}}</small></h2>
        <div v-for="a in hg.hoyT.alertas" :key="a.clave" class="alert" :class="a.nivel" style="margin:6px 0;display:flex;justify-content:space-between;gap:10px;align-items:center"><span>{{a.texto}}</span><a v-if="a.enlace" class="btn sm sec" :href="a.enlace">Ver</a></div>
        <div class="dash" style="gap:10px;margin:10px 0 0">
          <div class="kpi w3" style="margin:0" title="Incidencias de ama de llaves y de mantenimiento que nadie ha tomado"><div class="t">Tareas pendientes</div><div class="v">{{hg.hoyT.tareas.pendientes}}</div></div>
          <div class="kpi w3" style="margin:0" title="Incidencias que alguien ya tomó"><div class="t">En proceso</div><div class="v">{{hg.hoyT.tareas.en_proceso}}</div></div>
          <div class="kpi w3" style="margin:0" title="Pendientes o en proceso con más de 24 horas o urgentes, y planes de mantenimiento preventivo vencidos"><div class="t">Atrasadas</div><div class="v" :style="hg.hoyT.tareas.atrasadas ? 'color:var(--danger)' : ''">{{hg.hoyT.tareas.atrasadas}}</div><div class="d" v-if="hg.hoyT.tareas.preventivo">{{hg.hoyT.tareas.preventivo}} de preventivo</div></div>
          <div class="kpi w3" style="margin:0" title="Incidencias resueltas hoy"><div class="t">Completadas hoy</div><div class="v">{{hg.hoyT.tareas.completadas}}</div></div>
        </div>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px"><a class="btn sm ghost" href="#/hotel/ama-de-llaves/incidencias" v-if="puede('limpieza')">Ama de llaves · {{hg.hoyT.tareas.porModulo.limpieza.pendientes + hg.hoyT.tareas.porModulo.limpieza.en_proceso}} abierta(s)</a><a class="btn sm ghost" href="#/hotel/mantenimiento/incidencias" v-if="puede('mantenimiento')">Mantenimiento · {{hg.hoyT.tareas.porModulo.mantenimiento.pendientes + hg.hoyT.tareas.porModulo.mantenimiento.en_proceso}} abierta(s)</a></div>
      </div>
      <a class="card w4" :href="'#/hotel/reportes?rep=conceptos&desde=' + hoy().slice(0, 8) + '01&hasta=' + hoy()" style="margin:0" title="Producción por concepto"><h2>Ingresos del mes <small>por concepto, con IVA</small></h2>
        <table class="tbl" v-if="hg.conceptos.length"><tr v-for="c in hg.conceptos" :key="c.k"><td>{{c.nombre}}<div class="bar" style="margin:4px 0 0"><i :style="{width: (hg.totalMes ? Math.round(c.monto / hg.totalMes * 100) : 0) + '%'}"></i></div></td><td class="num" style="white-space:nowrap">{{money(c.monto, hg.mon)}}</td></tr><tr><th>Total</th><th class="num">{{money(hg.totalMes, hg.mon)}}</th></tr></table>
        <Empty v-else icon="🛏" title="Sin cargos este mes"></Empty></a>
      <div class="card w4" style="margin:0"><h2>Ventas y cobros <small>últimos 7 días y mes</small></h2>
        <div class="totals" style="align-items:stretch;margin:0">
          <div><span>Reservas nuevas (7 días)</span><b>{{hg.pickup.reservas}}</b></div><div><span>Noches vendidas (7 días)</span><b>{{hg.pickup.noches}}</b></div><div><span>Valor reservado (7 días)</span><b>{{money(hg.pickup.total, hg.mon)}}</b></div>
          <div><span>Canceladas este mes</span><b>{{hg.canc}}</b></div><div><span>No presentados este mes</span><b>{{hg.ns}}</b></div>
          <div class="total"><span>Por cobrar a agencias</span><b><a :href="'#/hotel/agencias'" class="link">{{money(hg.agencias, hg.mon)}}</a></b></div>
        </div></div>
      <a class="card w4" :href="'#/hotel/reportes?rep=pronostico,pronostico_tipo&desde=' + hoy() + '&hasta=' + sumarDias(hoy(), 29)" style="margin:0" title="Pronóstico de ocupación y por tipo de habitación"><h2>Próximos 30 días <small>ocupación promedio {{hg.pronProm}} %</small></h2>
        <div class="chart" style="height:130px"><div class="b" v-for="d in hg.pron" :key="d.f"><i :style="{height: Math.max(3, d.pct) + '%'}" :title="d.f + ': ' + d.ocupadas + ' de ' + d.total + ' (' + d.pct + ' %)'"></i>{{+d.f.slice(8) % 5 === 0 ? d.f.slice(8) : ''}}</div></div></a>
      </template>
      <template v-if="r && pg">
      <a class="card w6" href="#/pos/reportes?tab=hora" style="margin:0" title="Reportes de la caja"><h2>Ventas de hoy <small>{{pg.n}} ventas · ticket promedio {{money(pg.ticket, 'CRC')}}</small></h2>
        <div class="dash" style="gap:10px;margin:0 0 8px">
          <div class="kpi w3" style="margin:0"><div class="t">Vendido hoy</div><div class="v" style="font-size:18px">{{money(pg.total, 'CRC')}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Ventas</div><div class="v">{{pg.n}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Ticket promedio</div><div class="v" style="font-size:18px">{{money(pg.ticket, 'CRC')}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Ítems vendidos</div><div class="v">{{fmt(pg.items, 0)}}</div></div>
        </div>
        <div class="chart" style="height:110px" v-if="pg.n"><div class="b" v-for="x in pg.serie" :key="x.h"><i :style="{height: Math.max(3, Math.round(x.total / pg.maxH * 100)) + '%'}" :title="x.h + ':00 · ' + money(x.total, 'CRC')"></i>{{x.h}}h</div></div>
        <Empty v-else icon="🛒" title="Todavía no hay ventas hoy"></Empty></a>
      <a class="card w3" href="#/pos/reportes?tab=producto" style="margin:0" title="Por producto"><h2>Lo más vendido hoy</h2>
        <table class="tbl" v-if="pg.top.length"><tr v-for="p in pg.top" :key="p.nombre"><td>{{p.nombre}}<div class="small muted">{{fmt(p.cantidad, 0)}} und.</div></td><td class="num"><b>{{money(p.total, 'CRC')}}</b></td></tr></table>
        <Empty v-else icon="🍽" title="Sin detalle todavía" :text="pg.n ? 'Las ventas de hoy no traen el detalle por producto' : ''"></Empty></a>
      <a class="card w3" href="#/pos/cierres" style="margin:0" title="Cierres de caja"><h2>Cajas <small>{{pg.abiertas.length}} abierta(s)</small></h2>
        <div class="totals" style="align-items:stretch;margin:0">
          <div v-for="c in pg.abiertas" :key="'a' + c.id"><span>{{c.caja}} <small class="muted">{{c.usuario}}</small></span><b>{{c.ventas}} · {{money(c.total, 'CRC')}}</b></div>
          <div v-for="c in pg.cierres" :key="'c' + c.id"><span class="small">{{c.caja}} · cerrada {{fecha(c.fecha)}}</span><b class="small muted" v-if="c.diferencia === null">cerrada</b><b class="small" v-else :style="Math.abs(c.diferencia) > 0.005 ? 'color:var(--danger)' : 'color:var(--ok)'">{{Math.abs(c.diferencia) > 0.005 ? 'diferencia ' + money(c.diferencia, 'CRC') : 'cuadró'}}</b></div>
        </div>
        <Empty v-if="!pg.abiertas.length && !pg.cierres.length" icon="🧾" title="Sin cajas abiertas ni cierres"></Empty></a>
      </template>
      <div class="card w6" v-if="vis('cobros') && avisos && avisos.flujo" style="margin:0"><h2>Cobros de los próximos 30 días <small>saldos por vencimiento, en colones</small></h2>
        <div class="chart" style="height:150px"><div class="b"><i class="red" :style="{height: pct(avisos.flujo.vencido, maxFlujo) + '%'}" :title="money(avisos.flujo.vencido, 'CRC')"></i>Vencido</div>
          <div class="b" v-for="(w, i) in avisos.flujo.semanas" :key="i"><i :style="{height: pct(w.monto, maxFlujo) + '%'}" :title="money(w.monto, 'CRC')"></i>{{i === 0 ? 'Esta semana' : 'Semana ' + (i + 1)}}</div></div>
        <div class="row" style="justify-content:space-between;margin-top:8px"><span class="small">Vencido <b style="color:var(--danger)">{{money(avisos.flujo.vencido, 'CRC')}}</b></span><span class="small">Por cobrar en 30 días <b>{{money(avisos.flujo.semanas.reduce((s, w) => s + w.monto, 0), 'CRC')}}</b></span></div>
      </div>
      <a class="card w6" v-if="vis('planilla') && planilla" href="#/rrhh/planilla" style="margin:0"><h2>Planilla y personal <small>{{planilla.ultima ? 'última: ' + planilla.ultima.numero : 'sin planillas todavía'}}</small></h2>
        <div class="dash" style="gap:10px;margin:0">
          <div class="kpi w3" style="margin:0"><div class="t">Empleados activos</div><div class="v">{{planilla.empleados}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Costo de la última planilla</div><div class="v" style="font-size:18px">{{money(planilla.costo, 'CRC')}}</div><div class="d">cargas patronales {{money(planilla.cargas, 'CRC')}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Neto pagado</div><div class="v" style="font-size:18px">{{money(planilla.neto, 'CRC')}}</div></div>
          <div class="kpi w3" style="margin:0"><div class="t">Aguinaldo acumulado</div><div class="v" style="font-size:18px">{{money(planilla.aguinaldo, 'CRC')}}</div><div class="d">desde el 1 de diciembre</div></div>
        </div></a>
      <template v-if="r">
      <a class="kpi w3" v-if="vis('cxc')" :href="r.alcance === 'completo' ? link('cxc') : null" title="Ver el detalle en el reporte ejecutivo"><div class="t">Cuentas por cobrar</div><Monto :m="r.cxc.total" :otras="otras" grande></Monto>
        <div class="bar"><i :style="{width: (r.cxc.total[p] ? Math.round(r.cxc.vigente[p]/r.cxc.total[p]*100) : 100) + '%'}"></i></div>
        <div class="row" style="justify-content:space-between"><span class="small"><b class="muted">Vigentes</b><br>{{money(r.cxc.vigente[p], p)}} · {{r.cxc.docs - r.cxc.docs_vencidos}} docs</span><span class="small" style="text-align:right"><b class="muted">Vencidas</b><br>{{money(r.cxc.vencido[p], p)}} · {{r.cxc.docs_vencidos}} docs</span></div></a>
      <a class="kpi w3" v-if="vis('cxp') && r.cxp" :href="link('cxp')" title="Ver el detalle en el reporte ejecutivo"><div class="t">Cuentas por pagar</div><Monto :m="r.cxp.total" :otras="otras" grande></Monto>
        <div class="bar"><i :style="{width: (r.cxp.total[p] ? Math.round(r.cxp.vigente[p]/r.cxp.total[p]*100) : 100) + '%'}"></i></div>
        <div class="row" style="justify-content:space-between"><span class="small"><b class="muted">Vigentes</b><br>{{money(r.cxp.vigente[p], p)}} · {{r.cxp.docs - r.cxp.docs_vencidos}} docs</span><span class="small" style="text-align:right"><b class="muted">Vencidas</b><br>{{money(r.cxp.vencido[p], p)}} · {{r.cxp.docs_vencidos}} docs</span></div></a>
      <a class="kpi w3" v-if="vis('iva') && r.iva" :href="link('iva')" title="Ver el detalle en el reporte ejecutivo"><div class="t">IVA del período <small class="muted">{{(r.iva.neto[p] || 0) < 0 ? 'saldo a favor' : 'a pagar'}}</small></div><Monto :m="r.iva.neto" :otras="otras" grande></Monto>
        <div class="d">Cobrado en ventas {{money(r.iva.debito[p], p)}}<br>Acreditable en compras aceptadas {{money(r.iva.credito[p], p)}}</div></a>
      <a class="kpi w3" v-if="vis('items')" :href="link('items')" title="Ver el detalle en el reporte ejecutivo"><div class="t">Ítems vendidos</div><div class="v">{{fmt(r.unidades, 0)}}</div><div class="d">unidades en {{r.documentos}} documento{{r.documentos===1?'':'s'}} emitido{{r.documentos===1?'':'s'}}</div></a>
      <a class="kpi w3" v-if="vis('devoluciones')" :href="link('devoluciones')" title="Ver el detalle en el reporte ejecutivo"><div class="t">Devoluciones de clientes</div><Monto :m="r.devoluciones" :otras="otras" grande></Monto><div class="d">{{r.devoluciones_docs}} nota{{r.devoluciones_docs===1?'':'s'}} de crédito · incluye impuestos</div></a>
      <a class="kpi w3" v-if="vis('clientes')" :href="link('clientes')" title="Ver el detalle en el reporte ejecutivo"><div class="t">Clientes con ventas</div><div class="v">{{r.clientes}}</div><div class="d">en el período</div></a>
      <a class="card w6" v-if="vis('ventas')" :href="link('ventas')" style="margin:0" title="Ver el detalle en el reporte ejecutivo"><h2>Total de ventas <small>con impuestos incluidos</small></h2>
        <div class="row" style="justify-content:space-between;align-items:flex-start"><div style="font-size:22px;font-weight:650"><Monto :m="r.ventas" :otras="otras"></Monto></div>
          <span class="badge" :class="r.variacion === null ? '' : (r.variacion >= 0 ? 'ok' : 'danger')">{{r.variacion === null ? 'Sin ventas en el período anterior' : (r.variacion >= 0 ? '+' : '') + fmt(r.variacion, 1) + ' % vs. período anterior'}}</span></div>
        <div class="chart"><div class="b" v-for="d in serie" :key="d.k"><i :style="{height:d.hi+'%'}" :title="money(d.ingresos, p)"></i>{{d.label}}</div><Empty v-if="!serie.length" icon="📈" title="Sin ventas registradas" text="Durante este período no emitiste facturas." style="width:100%;padding:20px"></Empty></div></a>
      <a class="card w6" v-if="vis('flujo')" :href="link('flujo')" style="margin:0" title="Ver el detalle en el reporte ejecutivo"><h2>Flujo de transacciones <small>ingresos vs. egresos</small></h2>
        <div class="row" style="gap:30px;align-items:flex-start"><div><div class="t small muted">Total ingresos</div><b><Monto :m="r.ventas" :otras="otras"></Monto></b></div><div v-if="r.egresos"><div class="t small muted">Total egresos <small class="muted">recibidos aceptados y facturas de compra</small></div><b><Monto :m="r.egresos" :otras="otras"></Monto></b></div></div>
        <div class="chart"><div class="b" v-for="d in serie" :key="d.k"><div class="row" style="align-items:flex-end;gap:2px;width:100%;height:100%"><i :style="{height:d.hi+'%'}" :title="'Ingresos ' + money(d.ingresos, p)"></i><i class="red" :style="{height:d.he+'%'}" :title="'Egresos ' + money(d.egresos, p)"></i></div>{{d.label}}</div><Empty v-if="!serie.length" icon="📊" title="Sin transacciones" style="width:100%;padding:20px"></Empty></div>
        <div class="legend"><span><i style="background:var(--primary)"></i>Ingresos</span><span><i style="background:var(--danger)"></i>Egresos</span></div></a>
      <a class="card w4" v-if="vis('gastos') && r.gastos_por_proveedor" :href="link('egresos')" style="margin:0" title="Ver el detalle en el reporte ejecutivo"><h2>Distribución de gastos <small>top 5 proveedores</small></h2>
        <table class="tbl" v-if="gastos.length"><tr v-for="g in gastos" :key="g.nombre"><td>{{g.nombre}}<div class="bar" style="margin:4px 0 0"><i :style="{width:g.pct+'%'}"></i></div></td><td class="num" style="white-space:nowrap">{{money(g.monto[p], p)}}<div class="small muted">{{g.pct}} %</div></td></tr></table>
        <Empty v-else icon="◔" title="Sin gastos en el período" text="Acepte los comprobantes de sus proveedores en Gastos › Recepción de comprobantes o registre facturas de compra."></Empty></a>
      <a class="card w4" v-if="vis('top-productos')" :href="link('items')" style="margin:0" title="Ver el detalle en el reporte ejecutivo"><h2>Productos más vendidos</h2>
        <table class="tbl" v-if="r.top_productos.length"><tr v-for="t in r.top_productos" :key="t.detalle"><td>{{t.detalle}}<div class="small muted">{{fmt(t.cantidad, 0)}} unidades</div></td><td class="num" style="white-space:nowrap">{{money(t.monto[p], p)}}</td></tr></table>
        <Empty v-else icon="◑" title="Sin ventas registradas" text="Durante este período no se vendieron ítems."></Empty></a>
      <a class="card w4" v-if="vis('top-clientes') && hg" href="#/hotel/huespedes" style="margin:0" title="Huéspedes"><h2>Mejores huéspedes <small>gasto del mes en sus cuentas</small></h2>
        <table class="tbl" v-if="hg.topHuespedes.length"><tr v-for="c in hg.topHuespedes" :key="c.nombre"><td>{{c.nombre}}<div class="small muted">{{c.estadias}} estadía{{c.estadias===1?'':'s'}}</div></td><td class="num" style="white-space:nowrap">{{money(c.monto, hg.mon)}}</td></tr></table>
        <Empty v-else icon="◕" title="Sin cargos este mes"></Empty></a>
      <a class="card w4" v-else-if="vis('top-clientes')" :href="link('clientes')" style="margin:0" title="Ver el detalle en el reporte ejecutivo"><h2>Mejores clientes</h2>
        <table class="tbl" v-if="r.top_clientes.length"><tr v-for="c in r.top_clientes" :key="c.nombre"><td>{{c.nombre}}<div class="small muted">{{c.docs}} documento{{c.docs===1?'':'s'}}</div></td><td class="num" style="white-space:nowrap">{{money(c.monto[p], p)}}</td></tr></table>
        <Empty v-else icon="◕" title="Sin ventas registradas"></Empty></a>
      </template>
    </div>
    <div class="card" v-else-if="cargando"><p class="muted">Calculando el resumen…</p></div>
  </div>`,
  setup() { return { store, hoy, sumarDias }; },
};
