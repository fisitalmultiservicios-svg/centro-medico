// Nuevo pago recibido (Recibo de caja | Recibo electrónico de pago). Backend real: POST /api/pagos; las facturas por cobrar
// vienen de /api/comprobantes y su saldo (total − pagado) se actualiza al guardar. Las cuentas salen de Bancos (registro 'bancos').
import { api, toast, money, hoy, mock, CAT, opts, monedas, fecha } from '../../api.js';
import { store, sesion } from '../../app.js';
import { cuentaPrincipal, cuentaParaMedio, cuentasParaMovimientos, problemaMoneda, avisoConversion } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta

export default {
  props: ['params'],
  data() {
    return {
      tipo: 'caja', docs: [], cargando: true, guardando: false, CAT, opts, monedasOpc: monedas.opciones(),
      cuentas: [], cuentasLista: [],
      cuentaManual: false, tcManual: false,
      f: { cliente_id: null, cuenta: '', fecha: hoy(), condicion_venta: '01', medio_pago: '04', medio_pago_otros: '', moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), tipo_ingreso: 'factura', concepto: '', monto_otro: null, notas: '' },
      aplicar: {},
    };
  },
  computed: {
    problemaCuenta() { return problemaMoneda(this.f.cuenta, this.f.moneda, this.f.tipo_cambio, this.cuentasLista); },
    avisoCuenta() { return avisoConversion(this.f.cuenta, this.total, this.f.moneda, this.f.tipo_cambio, this.cuentasLista); },
    store() { return store; },
    sesion() { return sesion; },
    e() { return store.empresa; },
    cliente() { return store.clientes.find(c => c.id == this.f.cliente_id); },
    // Facturas del cliente con saldo pendiente (acepta pagos parciales) y en la misma moneda del pago
    facturas() {
      if (!this.f.cliente_id) return [];
      return this.docs.filter(d => d.cliente_id == this.f.cliente_id && ['01', '04', '09', '02'].includes(d.tipo_documento) && d.estado !== 'rechazado' && d.moneda === this.f.moneda && this.saldo(d) > 0.005   // la nota de débito también se cobra (R183)
        && (this.tipo !== 'rep' || (d.estado === 'aceptado' && ['10', '08'].includes(d.condicion_venta) && d.tipo_documento !== '04'))
        // una venta 10/08 (no tiquete) se cobra con REP cuando Hacienda la acepte: no se le registra recibo de caja antes.
        // 3.87: la interna (facturación electrónica apagada) nunca irá a Hacienda: se cobra con recibo de caja, igual que en el servidor
        && (this.tipo !== 'caja' || d.tipo_documento === '04' || !['10', '08'].includes(d.condicion_venta) || ['aceptado', 'interno'].includes(d.estado)));
    },
    // solo las facturas que se ven y se envían (antes, al pasar de recibo de caja a recibo electrónico quedaban sumados los
    // montos de facturas ocultas y entraba al banco más de lo aplicado)
    total() {
      if (this.f.tipo_ingreso === 'otros') return +this.f.monto_otro || 0;
      return this.facturas.reduce((s, d) => s + (+this.aplicar[d.id] || 0), 0);
    },
    esPrincipal() { return this.f.moneda === 'CRC'; },   // el tipo de cambio es colones por unidad: solo el CRC no lo necesita
    detalles() {
      if (this.f.tipo_ingreso === 'otros') return 'Otros ingresos: ' + (this.f.concepto || 'sin concepto');
      const apl = this.facturas.filter(d => +this.aplicar[d.id] > 0).map(d => d.consecutivo);
      return apl.length ? (apl.length === 1 ? 'Factura ' : 'Facturas ') + apl.join(', ') : '';
    },
  },
  watch: {
    'f.moneda'(v) { this.f.tipo_cambio = monedas.tc(v); this.tcManual = false; this.aplicar = {}; if (!this.cuentaManual) { const b = cuentaParaMedio(this.f.medio_pago, v, this.cuentasLista); if (b) this.f.cuenta = b.nombre; } },
    // 4.5: el medio decide la cuenta propuesta (efectivo → Efectivo; tarjeta, SINPE o transferencia → Banco), salvo que el usuario ya la haya elegido
    'f.medio_pago'(m) { if (!this.cuentaManual) { const b = cuentaParaMedio(m, this.f.moneda, this.cuentasLista); if (b) this.f.cuenta = b.nombre; } },
    // tipo de cambio de la factura aplicada (no el del día con margen), salvo que el usuario lo haya escrito
    aplicar: { deep: true, handler() {
      if (this.tcManual || this.esPrincipal) return;
      const d = this.facturas.find(x => +this.aplicar[x.id] > 0 && +x.tipo_cambio > 1);
      if (d) this.f.tipo_cambio = +d.tipo_cambio;
    } },
    tipo() { const vis = new Set(this.facturas.map(d => String(d.id))); for (const k of Object.keys(this.aplicar)) if (!vis.has(String(k))) delete this.aplicar[k]; },
    'f.cliente_id'() { this.aplicar = {}; },
  },
  methods: {
    monedaDe(nombre) { const b = this.cuentasLista.find(x => x.nombre === nombre); return b ? (b.moneda || 'CRC') : ''; },
    money,
    saldo(d) { return Math.max(0, Math.round(((d.total || 0) - (d.pagado || 0) - (d.acreditado || 0)) * 100) / 100); },   // menos notas de crédito aceptadas
    aplicarTodo(d) { this.aplicar[d.id] = this.saldo(d); },
    async guardar() {
      const f = this.f;
      if (!f.cuenta) return toast('Seleccione la cuenta bancaria', 'err');
      { const pm = problemaMoneda(f.cuenta, f.moneda, f.tipo_cambio, this.cuentasLista); if (pm) return toast(pm, 'err'); }
      if (this.tipo === 'caja' && !f.fecha) return toast('Indique la fecha de pago', 'err');
      if (f.tipo_ingreso === 'factura' && !f.cliente_id) return toast('Seleccione el cliente', 'err');
      if (this.tipo === 'rep' && !f.notas.trim()) return toast('La razón es obligatoria en el recibo electrónico de pago', 'err');
      if (f.medio_pago === '99' && (f.medio_pago_otros || '').trim().length < 3) return toast('Con el medio de pago «Otros» describa cuál es (mínimo 3 caracteres)', 'err');
      if (this.total <= 0) return toast('El monto del pago debe ser mayor a cero', 'err');
      for (const d of this.facturas) if (+this.aplicar[d.id] > this.saldo(d) + 0.005) return toast(`El monto aplicado a ${d.consecutivo} supera su saldo`, 'err');
      this.guardando = true;
      try {
        const body = { tipo: this.tipo, cliente_id: f.cliente_id || null, detalles: this.detalles, fecha: this.tipo === 'rep' ? hoy() : f.fecha, cuenta: f.cuenta, condicion_venta: f.condicion_venta,
                       medio_pago: f.medio_pago, medio_pago_otros: f.medio_pago === '99' ? (f.medio_pago_otros || '').trim() : null, moneda: f.moneda, tipo_cambio: f.tipo_cambio, monto: this.total, notas: f.notas,
                       facturas: f.tipo_ingreso === 'factura' ? this.facturas.filter(d => +this.aplicar[d.id] > 0).map(d => ({ id: d.id, monto: +this.aplicar[d.id] })) : [] };
        const p = await api('/api/pagos', { method: 'POST', body });
        if (this.tipo === 'rep') { for (const r of (p.rep || [])) toast(`REP ${r.consecutivo}: ${r.estado}${r.mensaje ? ' · ' + r.mensaje : ''}`, ['rechazado', 'error'].includes(r.estado) ? 'err' : 'ok'); }
        else toast(`Recibo de caja #${p.numero} guardado`, 'ok');
        location.hash = '/ventas/pagos';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    if (!sesion.electronica) this.tipo = 'caja';   // 3.87: sin facturación electrónica no hay recibo electrónico (va a Hacienda)
    this.cuentasLista = await cuentasParaMovimientos();
    this.cuentas = this.cuentasLista.length ? this.cuentasLista.map(b => b.nombre) : ['Caja general', 'Banco Nacional', 'Banco De Costa Rica', 'BAC Credomatic'];
    { const b = cuentaParaMedio(this.f.medio_pago, this.f.moneda, this.cuentasLista); if (b && !this.f.cuenta) this.f.cuenta = b.nombre; }   // 4.5: según el medio
    try {
      this.docs = await api('/api/comprobantes');
      const origen = this.docs.find(d => d.id === Number(this.params?.factura));
      if (origen?.cliente_id && this.saldo(origen) > 0.005) {
        this.f.cliente_id = origen.cliente_id;
        this.f.moneda = origen.moneda || 'CRC';
        await this.$nextTick();
        const visible = this.facturas.find(d => d.id === origen.id);
        if (visible) this.aplicarTodo(visible);
      }
    } catch (e) { toast('No se pudieron cargar las facturas por cobrar: ' + e.message, 'err'); }
    this.cargando = false;
  },
  template: `
  <div class="page">
    <PageHead title="Nuevo pago recibido" :crumbs="[{label:'Pagos recibidos',to:'/ventas/pagos'},{label:'Nuevo'}]">
      <span class="badge primary" v-if="tipo==='rep'">Versión 4.4</span>
    </PageHead>
    <div class="card">
      <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap;gap:12px">
        <div>
          <div class="small muted" style="margin-bottom:6px">Tipo de documento</div>
          <div class="seg"><button :class="{on:tipo==='caja'}" @click="tipo='caja'">Recibo de caja</button><button v-if="sesion.electronica" :class="{on:tipo==='rep'}" @click="tipo='rep'">Recibo electrónico (REP)</button></div>
          <p class="small muted" style="margin:6px 0 0" v-if="tipo==='rep'">Se emite y envía a Hacienda un REP por cada factura aplicada. Solo aplica a facturas <b>aceptadas</b> emitidas a crédito con IVA diferido (condición de venta 10) o de servicios al Estado (08).</p>
        </div>
        <div style="text-align:right">
          <div style="font-size:16px;font-weight:650">{{e?.nombre_comercial || e?.nombre || 'Mi empresa'}}</div>
          <div class="small muted">{{CAT.tipoId[e?.tipo_id]||''}}: {{e?.numero_id}} · {{e?.correo}}</div>
          <div class="small muted" style="margin-top:4px">El número se asigna al guardar<span v-if="tipo==='rep'"> · Fecha {{fecha(hoy())}}</span></div>
        </div>
      </div>
      <div class="grid">
        <Field label="Cliente" :req="f.tipo_ingreso==='factura'"><Buscador v-model="f.cliente_id" :opciones="store.clientes.filter(c=>c.activo!==false && c.tipo!=='Proveedor')" detalle="numero_id" vacio="Seleccionar" agregar="cliente"></Buscador></Field>
        <Field label="Cuenta bancaria" req help="Por defecto la cuenta principal de la moneda del pago (Bancos); puede elegir otra"><Buscador v-model="f.cuenta" :opciones="cuentas.map(c => ({ nombre: c, moneda: monedaDe(c) }))" valor="nombre" detalle="moneda" agregar="cuenta" @change="cuentaManual=true"></Buscador><div class="small" :class="problemaCuenta ? 'neg' : 'muted'" v-if="problemaCuenta || avisoCuenta" style="margin-top:4px">{{problemaCuenta || avisoCuenta}}</div></Field>
        <Field v-if="tipo==='caja'" label="Fecha de pago" req><input type="date" v-model="f.fecha"></Field>
        <Field v-else label="Condición de venta del REP" help="La fija Hacienda según la factura: 11 (pago de venta a crédito con IVA diferido) o 09 (pago de servicios al Estado)"><input value="Se toma de la factura aplicada" disabled></Field>
        <Field label="Medio de pago" req><select v-model="f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="¿Cuál medio de pago?" req v-if="f.medio_pago==='99'" help="Hacienda exige describirlo (3 a 100 caracteres)"><input v-model="f.medio_pago_otros" maxlength="100"></Field>
        <Field label="Moneda" req help="Se muestran las facturas en esta moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" v-if="!esPrincipal" help="Colones por unidad: el de la factura aplicada; cámbielo si el banco aplicó otro"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio" @input="tcManual = true"></Field>
      </div>
      <div style="margin-top:16px">
        <div class="small muted" style="margin-bottom:6px">Tipo de ingreso</div>
        <div class="seg"><button :class="{on:f.tipo_ingreso==='factura'}" @click="f.tipo_ingreso='factura'">Pago a factura de cliente</button><button :class="{on:f.tipo_ingreso==='otros'}" @click="f.tipo_ingreso='otros'">Otros ingresos</button></div>
      </div>
    </div>

    <div class="card" v-if="f.tipo_ingreso==='factura'">
      <h2>Facturas por cobrar</h2>
      <p class="muted small" v-if="!f.cliente_id">Seleccione un cliente para ver sus facturas pendientes de cobro.</p>
      <p class="muted small" v-else-if="cargando">Cargando facturas…</p>
      <Empty v-else-if="!facturas.length" icon="✓" title="Sin facturas por cobrar" :text="tipo==='rep' ? 'Este cliente no tiene facturas aceptadas con IVA diferido (condición 10) o al Estado (08) pendientes de cobro en esta moneda.' : 'Este cliente no tiene facturas pendientes de cobro en esta moneda.'"></Empty>
      <div class="table-wrap" v-else><table class="tbl">
        <thead><tr><th>Número</th><th>Fecha</th><th>Estado</th><th class="num">Total</th><th class="num">Saldo</th><th class="num" style="width:160px">Monto a aplicar</th><th></th></tr></thead>
        <tbody><tr v-for="d in facturas" :key="d.id">
          <td class="mono">{{d.consecutivo}}</td><td>{{fecha(d.fecha_emision)}}</td><td><Badge :value="d.estado"></Badge></td>
          <td class="num">{{money(d.total, d.moneda)}}</td><td class="num">{{money(saldo(d), d.moneda)}}</td>
          <td><input class="inp" type="number" step="0.01" min="0" :max="saldo(d)" v-model.number="aplicar[d.id]" style="width:100%;text-align:right" placeholder="0,00"></td>
          <td><button class="btn sm ghost" @click="aplicarTodo(d)">Aplicar todo</button></td>
        </tr></tbody>
      </table></div>
    </div>
    <div class="card" v-else>
      <h2>Otros ingresos</h2>
      <div class="grid cols-2">
        <Field label="Concepto" req><input v-model="f.concepto" placeholder="Ej.: depósito en garantía, venta de activo"></Field>
        <Field label="Monto" req><input type="number" step="0.01" min="0" v-model.number="f.monto_otro"></Field>
      </div>
    </div>

    <div class="card">
      <div class="grid cols-2">
        <Field :label="tipo==='rep' ? 'Razón' : 'Notas'" :req="tipo==='rep'" :help="tipo==='rep' ? 'Obligatoria en el recibo electrónico de pago.' : 'Visibles en el recibo impreso'"><textarea rows="3" v-model="f.notas" :placeholder="tipo==='rep' ? 'Ej.: Pago de factura a crédito según condición de venta' : 'Comentarios'"></textarea></Field>
        <div class="totals" style="align-self:end"><div class="total"><span>Total</span><b>{{money(total, f.moneda)}}</b></div></div>
      </div>
    </div>
    <div class="row end" style="margin-bottom:18px">
      <a class="btn ghost" href="#/ventas/pagos">Cancelar</a>
      <button class="btn" @click="guardar" :disabled="guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </div>
  </div>`,
  setup() { return { hoy }; },
};
