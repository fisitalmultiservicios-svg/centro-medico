// Nueva nota de crédito (03) / nota de débito (02) — formulario compartido (backend real: POST /api/comprobantes + /enviar)
import { api, toast, money, hoy, CAT, opts, monedas, fecha } from '../../api.js';
import { store, sesion } from '../../app.js';

// 3.87: con la facturación electrónica apagada las facturas son internas (no van a Hacienda) y la nota también: se pueden referenciar
const referenciable = d => d.estado === 'aceptado' || (!sesion.electronica && d.estado === 'interno');

export default {
  props: ['params'],
  data() {
    const tipo = location.hash.includes('notas-credito') ? '03' : '02';
    return {
      tipo, docs: [], cargando: true, guardando: false, CAT, opts, monedasOpc: monedas.opciones(),
      exos: [], exosListas: false, exoElegida: null,     // exoneraciones del cliente: la nota hereda la de la factura; si la factura no tenía, se puede elegir (p. ej. código 12)
      f: { cliente_id: null, referencia_codigo: tipo === '03' ? '01' : '10', referencia_codigo_otro: '', factura_id: null, fecha: hoy(), condicion_venta: '01', condicion_venta_otros: '', plazo_credito: 30, medio_pago: '01', medio_pago_otros: '', moneda: monedas.principal().codigo, tipo_cambio: monedas.tc(monedas.principal().codigo), razon: '', lineas: [], observaciones: '', otros_cargos: [], incluir_cargos: true },
    };
  },
  computed: {
    store() { return store; },
    e() { return store.empresa; },
    esNC() { return this.tipo === '03'; },
    nombre() { return this.esNC ? 'nota de crédito' : 'nota de débito'; },
    titulo() { return this.esNC ? 'Nueva nota de crédito electrónica' : 'Nueva nota de débito electrónica'; },
    ruta() { return this.esNC ? '/ventas/notas-credito' : '/ventas/notas-debito'; },
    codSuc() { return String(sesion.sucursalActual?.codigo || this.e?.sucursal || 1).padStart(3, '0'); },   // 3.82: la sucursal con que se emite
    sucursalEmite() { return sesion.sucursalActual ? sesion.sucursalActual.nombre : 'Principal'; },
    numero() { return `${this.codSuc}${String(this.e?.terminal || 1).padStart(5, '0')}${this.tipo}…`; },
    // Solo facturas ACEPTADAS por Hacienda: una nota contra un comprobante no aceptado es rechazada o queda sin respaldo.
    // sin cliente: los tiquetes sin receptor (devoluciones de mostrador); también las facturas de exportación (R76)
    facturas() { return this.docs.filter(d => (this.f.cliente_id ? d.cliente_id == this.f.cliente_id : !d.cliente_id) && ['01', '04', '09'].includes(d.tipo_documento) && referenciable(d)); },
    factura() { return this.docs.find(d => d.id == this.f.factura_id); },
    // la de la factura (para el aviso); para calcular en pantalla solo con sus datos reales ya cargados
    exoHeredada() { const fa = this.factura; return fa && fa.exoneracion_id ? { id: fa.exoneracion_id, numero: fa.exoneracion_numero } : null; },
    exoHeredadaDatos() { const fa = this.factura; return fa && fa.exoneracion_id ? (this.exos.find(x => x.id === fa.exoneracion_id) || null) : null; },
    exoDisponibles() { return this.exos.filter(x => x.activa && x.estado !== 'vencida'); },
    exoSel() { return this.exoHeredada ? this.exoHeredadaDatos : (this.exos.find(x => x.id === this.exoElegida) || null); },
  },
  watch: {
    'f.moneda'(v) { this.f.tipo_cambio = monedas.tc(v); },
    async 'f.cliente_id'(v) {
      this.f.factura_id = null; this.exoElegida = null; this.exos = []; this.exosListas = false;
      if (v) { try { const l = await api('/api/clientes/' + v + '/exoneraciones'); if (this.f.cliente_id === v) { this.exos = l; this.exosListas = true; } } catch (e) { toast('No se pudieron cargar las exoneraciones del cliente: ' + e.message, 'err'); } }
    },
    async 'f.factura_id'(v) {
      const d = this.docs.find(x => x.id == v); this.f.otros_cargos = [];
      if (d) {
        this.f.moneda = d.moneda || this.f.moneda; this.$nextTick(() => { this.f.tipo_cambio = +d.tipo_cambio > 1 ? +d.tipo_cambio : monedas.tc(this.f.moneda); });   // el de la factura, no el del día
        // otros cargos de la factura (impuesto de servicio, timbres): no están en las líneas; se incluyen en la nota para que pueda anularla completa
        try { const det = await api('/api/comprobantes/' + d.id); if (this.f.factura_id == v) this.f.otros_cargos = (det.otros_cargos || []).map(x => ({ tipo: x.tipo, tipo_otro: x.tipo_otro || null, detalle: x.detalle, monto: +x.monto })); } catch {}
      }
    },
  },
  methods: {
    money,
    etiquetaFactura(d) { return `${d.consecutivo} · ${fecha(d.fecha_emision)} · ${money(d.total, d.moneda)}`; },
    async guardar(emitir = true) {
      const f = this.f;
      if (!f.cliente_id && !(this.factura && !this.factura.cliente_id)) return toast('Seleccione el cliente (o un tiquete sin receptor)', 'err');
      if (!this.factura) return toast('Seleccione la factura asociada', 'err');
      if (!f.razon.trim()) return toast('La razón es obligatoria', 'err');
      if (f.referencia_codigo === '99' && f.referencia_codigo_otro.trim().length < 5) return toast('Con el código 99 (Otros) describa el tipo de nota (mínimo 5 caracteres)', 'err');
      if (!f.lineas.length || !f.lineas.some(l => l.detalle || l.producto_id)) return toast('Agregue al menos una línea', 'err');
      if (f.condicion_venta === '99' && (f.condicion_venta_otros || '').trim().length < 5) return toast('Con la condición de venta «Otros» describa cuál es (mínimo 5 caracteres)', 'err');
      if (f.medio_pago === '99' && (f.medio_pago_otros || '').trim().length < 3) return toast('Con el medio de pago «Otros» describa cuál es (mínimo 3 caracteres)', 'err');
      if (['02', '08', '10'].includes(f.condicion_venta) && !(parseInt(f.plazo_credito, 10) >= 1)) return toast('Indique el plazo de crédito en días (un número entero mayor que cero)', 'err');
      this.guardando = true;
      try {
        const body = {
          tipo_documento: this.tipo, cliente_id: f.cliente_id, condicion_venta: f.condicion_venta, condicion_venta_otros: f.condicion_venta === '99' ? f.condicion_venta_otros.trim() : null,
          medio_pago: f.medio_pago, medio_pago_otros: f.medio_pago === '99' ? f.medio_pago_otros.trim() : null, plazo_credito: ['02', '08', '10'].includes(f.condicion_venta) ? parseInt(f.plazo_credito, 10) : null, moneda: f.moneda, tipo_cambio: f.tipo_cambio,
          lineas: f.lineas.map(l => ({ producto_id: l.producto_id || null, detalle: l.detalle, cabys: l.cabys || null, cantidad: l.cantidad, precio_unitario: l.precio_unitario ?? null, descuento: l.descuento || 0, codigo_tarifa: l.codigo_tarifa, tarifa: l.tarifa, es_servicio: l.es_servicio ?? false, unidad_medida: l.unidad_medida || 'Unid' , exonerar: l.exonerar === false ? false : null})),
          referencia_clave: this.factura.clave, referencia_fecha: this.factura.fecha_emision, referencia_codigo: f.referencia_codigo, referencia_codigo_otro: f.referencia_codigo === '99' ? f.referencia_codigo_otro.trim() : null, referencia_razon: f.razon, observaciones: f.observaciones || null,
          otros_cargos: f.incluir_cargos ? (f.otros_cargos || []) : [],
          ...(this.exoHeredada ? {} : { exoneracion_id: this.exoElegida || null }),   // sin campo: el servidor hereda la de la factura
        };
        const d = await api('/api/comprobantes', { method: 'POST', body });
        if (emitir && d.estado === 'firmado') { try { await api(`/api/comprobantes/${d.id}/enviar`, { method: 'POST' }); } catch (e) { toast('Firmada, pero no se pudo enviar a Hacienda: ' + e.message, 'err'); } }
        toast(`${this.esNC ? 'Nota de crédito' : 'Nota de débito'} ${d.consecutivo} ${emitir ? (d.estado === 'generado' ? 'generada sin firmar: cargue el certificado .p12 para enviarla a Hacienda' : 'emitida') : 'guardada'}`, 'ok');   // 3.87: a Hacienda solo va lo firmado (la interna y la que no tiene firma no)
        location.hash = this.ruta;
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  async created() {
    try { this.docs = await api('/api/comprobantes'); } catch (e) { toast('No se pudieron cargar las facturas: ' + e.message, 'err'); }
    this.cargando = false;
    // Desde el detalle de la factura (botón «Nota de crédito», 2.3): se precargan el cliente, la factura y sus líneas (anulación completa; se pueden quitar líneas para una nota parcial)
    if (this.params.factura) {
      const d = this.docs.find(x => x.id == this.params.factura);
      if (!d) return toast('No se encontró la factura indicada', 'err');
      if (!referenciable(d)) return toast('Solo se hacen notas sobre comprobantes aceptados por Hacienda (este está ' + d.estado + ')', 'err');
      this.f.cliente_id = d.cliente_id || null;
      await this.$nextTick();
      this.f.factura_id = d.id;
      try {
        const det = await api('/api/comprobantes/' + d.id);
        this.f.lineas = (det.lineas || []).map(l => ({ producto_id: l.producto_id || null, detalle: l.detalle, cabys: l.cabys, cantidad: +l.cantidad, precio_unitario: +l.precio_unitario, descuento: +l.descuento || 0, codigo_tarifa: l.codigo_tarifa, tarifa: +l.tarifa, es_servicio: /^[5-9]/.test(String(l.cabys || '')), unidad_medida: l.unidad_medida || 'Unid', ...((+l.iva_exonerado || 0) > 0 ? {} : {}) }));
        if (!this.f.razon) this.f.razon = 'Anulación de la factura ' + d.consecutivo;
        toast('Líneas de la factura ' + d.consecutivo + ' cargadas: quite las que no se devuelven si la nota es parcial', 'ok');
      } catch (e) { toast('No se pudieron cargar las líneas: ' + e.message, 'err'); }
    }
  },
  template: `
  <div class="page">
    <PageHead :title="titulo" :crumbs="[{label: esNC ? 'Notas de crédito' : 'Notas de débito', to: ruta},{label:'Nueva'}]">
      <span class="badge primary">Versión 4.4</span>
    </PageHead>
    <div class="alert warn" v-if="!e">Configure primero los datos de la empresa emisora en <a href="#/configuracion/empresa">Configuración › Empresa</a>.</div>
    <div class="card">
      <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:16px">
        <div><div style="font-size:16px;font-weight:650">{{e?.nombre_comercial || e?.nombre || 'Mi empresa'}}</div><div class="small muted">{{CAT.tipoId[e?.tipo_id]||''}}: {{e?.numero_id}} · Actividad {{e?.actividad}} · {{e?.correo}}</div></div>
        <div style="text-align:right"><div class="small muted">Numeración</div><select class="inp"><option>{{sucursalEmite}} electrónica</option></select><div class="small muted" style="margin-top:4px">No. <span class="mono">{{numero}}</span> · Sucursal {{codSuc}} · Punto de venta {{String(e?.terminal||1).padStart(5,'0')}}</div></div>
      </div>
      <h2>Información de la {{nombre}}</h2>
      <div class="grid">
        <Field label="Cliente" req><Buscador v-model="f.cliente_id" :opciones="store.clientes" detalle="numero_id" vacio="Sin cliente: tiquetes sin receptor"></Buscador></Field>
        <Field :label="'Tipo de ' + nombre" req help="Código de referencia de Hacienda (v4.4)"><select v-model="f.referencia_codigo"><option v-for="o in opts(CAT.codigoRef)" :key="o.value" :value="o.value">{{o.value}} - {{o.label}}</option></select></Field>
        <Field v-if="f.referencia_codigo === '99'" label="Descripción del código 99" req help="Hacienda la exige con 'Otros' (5 a 100 caracteres)"><input v-model="f.referencia_codigo_otro" maxlength="100" placeholder="Ej.: Ajuste por diferencia cambiaria"></Field>
        <Field label="Factura de venta asociada" req :help="!f.cliente_id ? 'Seleccione primero el cliente' : (cargando ? 'Cargando facturas…' : (facturas.length ? '' : 'El cliente no tiene facturas emitidas'))">
          <select v-model="f.factura_id" :disabled="!facturas.length"><option :value="null">— Seleccionar —</option><option v-for="d in facturas" :key="d.id" :value="d.id">{{etiquetaFactura(d)}}</option></select>
        </Field>
        <Field label="Fecha" req><input type="date" :value="f.fecha" disabled></Field>
        <Field label="Condición" req><select v-model="f.condicion_venta"><option v-for="o in CAT.condicionVentaDe(tipo)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="¿Cuál condición?" req v-if="f.condicion_venta==='99'"><input v-model="f.condicion_venta_otros" maxlength="100"></Field>
        <Field label="Plazo de crédito (días)" req v-if="['02','08','10'].includes(f.condicion_venta)" help="El de la factura que se corrige"><input type="number" min="1" v-model.number="f.plazo_credito"></Field>
        <Field label="Medio de pago" req><select v-model="f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="¿Cuál medio de pago?" req v-if="f.medio_pago==='99'"><input v-model="f.medio_pago_otros" maxlength="100"></Field>
        <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" req v-if="f.moneda !== 'CRC'" help="Colones por unidad: el de la factura que se corrige"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio"></Field>
        <Field label="Actividad económica" req><input :value="e?.actividad" disabled></Field>
      </div>
      <div class="alert info" v-if="factura" style="margin-top:12px">
        Referencia: <b class="mono">{{factura.consecutivo}}</b> del {{fecha(factura.fecha_emision)}} por {{money(factura.total, factura.moneda)}} · Estado <Badge :value="factura.estado"></Badge>
        <div class="small muted mono" style="margin-top:4px">Clave {{factura.clave}}</div>
      </div>
      <Field label="Razón" req help="Va al PDF y al campo Razón del XML de la referencia" style="margin-top:12px"><textarea rows="2" v-model="f.razon" :placeholder="esNC ? 'Ej.: Devolución de mercadería por producto defectuoso' : 'Ej.: Intereses moratorios por pago tardío'"></textarea></Field>
    </div>
    <div class="card" v-if="exoHeredada || exoDisponibles.length">
      <h2>Exoneración</h2>
      <div class="alert info" v-if="exoHeredada" style="margin:0">La factura se emitió con la exoneración <b class="mono">{{exoHeredada.numero}}</b>: la {{nombre}} la lleva también, en las mismas líneas.<span v-if="!exoHeredadaDatos"> (Los totales en pantalla no la descuentan hasta cargar sus datos; el comprobante sí la lleva.)</span></div>
      <Field v-else label="Documento de exoneración" help="Para acreditar una exoneración posterior a la factura use el tipo 12 (Crédito por exoneración posterior a la facturación)"><select v-model="exoElegida"><option :value="null">— Sin exoneración —</option><option v-for="x in exoDisponibles" :key="x.id" :value="x.id">{{x.numero}} · exonera {{x.tarifa}} % · {{x.tipo_nombre}}</option></select></Field>
    </div>
    <div class="card"><h2>Ítems</h2><LineEditor v-model="f.lineas" :productos="store.productos.filter(p=>p.es_venta!==false)" :moneda="f.moneda" :cliente-id="f.cliente_id" :exoneracion="exoSel"></LineEditor>
      <div class="alert info" v-if="f.otros_cargos.length" style="margin:10px 0 0"><label class="row" style="cursor:pointer;gap:8px"><input type="checkbox" v-model="f.incluir_cargos"> Incluir los otros cargos de la factura ({{f.otros_cargos.map(x => x.detalle + ' ' + money(x.monto, f.moneda)).join(', ')}}): se suman al total de la nota sin IVA. Desmárquelo si la nota es parcial y no los devuelve.</label></div>
    </div>
    <div class="card"><Field label="Notas" help="Visibles en el PDF (campo OtroTexto del XML)"><textarea rows="3" v-model="f.observaciones" placeholder="Agrega comentarios para aclarar datos de la nota"></textarea></Field>
      <p class="small muted" style="margin:12px 0 0">Autorizada mediante resolución MH-DGT-RES-0027-2024 del 13 de noviembre del 2024 (Alcance N°186 a La Gaceta N°217 del 19/11/2024).</p></div>
    <div class="row end" style="margin-bottom:18px">
      <a class="btn ghost" :href="'#'+ruta">Cancelar</a>
      <button class="btn" @click="guardar(true)" :disabled="guardando">{{guardando?'Procesando…':'Emitir'}}</button>
    </div>
    <Comments :saved="false"></Comments>
  </div>`,
};
