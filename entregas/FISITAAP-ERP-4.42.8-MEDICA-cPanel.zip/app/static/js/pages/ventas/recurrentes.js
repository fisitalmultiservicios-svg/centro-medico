// Facturas recurrentes — lista real (/api/recurrentes) + facturas pendientes de emitir (/api/recurrentes/pendientes).
// El formulario es el mismo de factura con el bloque "Recurrencia" (#/ventas/facturas/nueva?recurrente=nueva | ?recurrente=ID).
// En cada fecha programada el servidor genera una factura PENDIENTE: se emite desde aquí (?pendiente=ID), se pospone o se omite.
import { api, toast, money, hoy, fecha } from '../../api.js';
import { store } from '../../app.js';

const PERIODOS = { diaria: 'Diaria', semanal: 'Semanal', quincenal: 'Quincenal', mensual: 'Mensual', bimensual: 'Bimestral (cada 2 meses)', trimestral: 'Trimestral', semestral: 'Semestral', anual: 'Anual' };

export default {
  props: ['params'],
  data() { return { lista: [], pendientes: [], q: '', cargando: true, posponer: null, nuevaFecha: hoy() }; },
  computed: {
    store() { return store; },
    rows() {
      return this.lista.map(r => ({ ...r, nombre_calc: r.nombre || r.cliente_nombre || ('Recurrencia #' + r.id), periodo: PERIODOS[r.periodicidad] || r.periodicidad,
        total: this.total(r), estado_calc: r.activa ? 'Activa' : (r.fin && (r.fin < hoy() || (r.proxima && r.proxima > r.fin)) ? 'Finalizada' : 'Pausada') }));   // terminó: la próxima fecha pasa del fin (R333)
    },
    columns() {
      return [
        { key: 'nombre_calc', label: 'Nombre', link: r => location.hash = '/ventas/facturas/nueva?recurrente=' + r.id },
        { key: 'cliente_nombre', label: 'Cliente', fmt: v => v || 'Tiquete (sin receptor)' },
        { key: 'periodo', label: 'Periodicidad' },
        { key: 'proxima', label: 'Próxima emisión', fmt: v => v ? fecha(v) : '—' },
        { key: 'inicio', label: 'Inicio', fmt: 'date' },
        { key: 'fin', label: 'Fin', fmt: v => v ? fecha(v) : 'Indefinido' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'estado_calc', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    money, fecha,
    total(r) { return (r.lineas || []).reduce((s, l) => { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); return s + m + m * (l.tarifa || 0) / 100; }, 0); },
    async cargar() {
      this.cargando = true;
      try { [this.lista, this.pendientes] = await Promise.all([api('/api/recurrentes'), api('/api/recurrentes/pendientes')]); } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async pausar(r) {
      try {
        const body = { nombre: r.nombre, cliente_id: r.cliente_id, tipo_documento: r.tipo_documento, condicion_venta: r.condicion_venta, plazo_credito: r.plazo_credito, medio_pago: r.medio_pago, moneda: r.moneda,
                       periodicidad: r.periodicidad, dia_emision: r.dia_emision, mes_emision: r.mes_emision ?? null, dia_semana: r.dia_semana ?? null, dia_emision2: r.dia_emision2 ?? null, actividad_emisor: r.actividad_emisor ?? null, dias_vencimiento: r.dias_vencimiento ?? null, inicio: r.inicio, fin: r.fin, lineas: r.lineas, observaciones: r.observaciones, terminos: r.terminos, vendedor: r.vendedor, activa: !r.activa };
        await api('/api/recurrentes/' + r.id, { method: 'PUT', body });
        toast(r.activa ? 'Recurrencia pausada' : 'Recurrencia activada', 'ok'); this.cargar();
      } catch (e) { toast(e.message, 'err'); }
    },
    async eliminar(r) {
      if (!confirm('¿Eliminar la factura recurrente "' + (r.nombre || r.cliente_nombre || r.id) + '"? Las facturas ya emitidas no se tocan.')) return;
      try { await api('/api/recurrentes/' + r.id, { method: 'DELETE' }); toast('Factura recurrente eliminada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async omitir(p) {
      if (!confirm('¿Omitir la factura del ' + fecha(p.fecha_programada) + '? No se emitirá.')) return;
      try { await api('/api/recurrentes/pendientes/' + p.id, { method: 'DELETE' }); toast('Factura omitida', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async guardarFecha() {
      if (!this.nuevaFecha) return toast('Indique la fecha', 'err');
      try { await api('/api/recurrentes/pendientes/' + this.posponer.id, { method: 'PUT', body: { fecha_programada: this.nuevaFecha } }); toast('Fecha cambiada al ' + fecha(this.nuevaFecha), 'ok'); this.posponer = null; this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    totalPendiente(p) { return this.total(p.recurrente || {}); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Facturas recurrentes" sub="Programe facturas que se repiten. En cada fecha el sistema las genera y quedan pendientes de su aprobación para emitirlas a Hacienda.">
      <a class="btn" v-if="puede('facturar')" href="#/ventas/facturas/nueva?recurrente=nueva">+ Nueva factura recurrente</a>
    </PageHead>

    <div class="card" v-if="pendientes.length">
      <h2>Pendientes de emitir <span class="badge warn">{{pendientes.length}}</span></h2>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fecha programada</th><th>Recurrencia</th><th>Cliente</th><th class="num">Total</th><th></th></tr></thead>
        <tbody><tr v-for="p in pendientes" :key="p.id">
          <td><b :style="p.fecha_programada < hoy() ? 'color:var(--danger)' : ''">{{fecha(p.fecha_programada)}}</b><span class="small muted" v-if="p.fecha_programada < hoy()"> · atrasada</span></td>
          <td>{{p.recurrente?.nombre || ('#' + p.recurrente_id)}}</td>
          <td>{{p.recurrente?.cliente_nombre || 'Tiquete (sin receptor)'}}</td>
          <td class="num">{{money(totalPendiente(p), p.recurrente?.moneda || 'CRC')}}</td>
          <td><div class="acts">
            <a class="btn sm" :href="'#/ventas/facturas/nueva?pendiente=' + p.id">Revisar y emitir</a>
            <button class="btn sm sec" @click="posponer=p; nuevaFecha=p.fecha_programada">Cambiar fecha</button>
            <button class="btn sm ghost" @click="omitir(p)">Omitir</button>
          </div></td>
        </tr></tbody>
      </table></div>
    </div>

    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o nombre" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" empty-title="Aún no hay facturas recurrentes" empty-text="Programe una factura que se repita cada mes, quincena o semana; el sistema la generará en cada fecha y la dejará pendiente de emitir.">
        <template #actions="{row}">
          <a class="btn icon" :href="'#/ventas/facturas/nueva?recurrente=' + row.id" title="Editar">✎</a>
          <a class="btn icon" v-if="puede('facturar')" :href="'#/ventas/facturas/nueva?recurrente=nueva&copiar=' + row.id" title="Duplicar: nueva recurrencia con las mismas líneas y programación">⧉</a>
          <button class="btn sm sec" @click.stop="pausar(row)">{{row.activa ? 'Pausar' : 'Activar'}}</button>
          <button class="btn icon danger" v-if="puede('facturar')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/facturas/nueva?recurrente=nueva">+ Nueva factura recurrente</a></template>
      </DataTable>
    </div>

    <Modal v-if="posponer" title="Cambiar fecha de emisión" @close="posponer=null">
      <p class="small muted">Factura de <b>{{posponer.recurrente?.cliente_nombre || posponer.recurrente?.nombre}}</b> programada para el {{fecha(posponer.fecha_programada)}}.</p>
      <Field label="Nueva fecha" req><input type="date" v-model="nuevaFecha"></Field>
      <template #foot><button class="btn ghost" @click="posponer=null">Cancelar</button><button class="btn" @click="guardarFecha">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { hoy }; },
};
