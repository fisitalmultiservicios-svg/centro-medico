// Notas de crédito — lista (datos de ejemplo mock 'notas-credito' + documentos reales tipo 03 de /api/comprobantes)
import { api, toast, money, mock, CAT, fecha, avisoSesion } from '../../api.js';
import { exportarTabla } from '../reportes/_montos.js';
import { sesion } from '../../app.js';

const EJEMPLO = [
  { id: 1, numero: '00100001030000000001', cliente_nombre: 'Distribuidora La Central S.A.', fecha: '2026-08-14', codigo_ref: '02', moneda: 'CRC', total: 45200, por_aplicar: 0, emision: 'Aceptada', estado: 'Aplicada', razon: 'Corrección de precio unitario en la factura 00100001010000000009' },
  { id: 2, numero: '00100001030000000002', cliente_nombre: 'Ferretería El Progreso S.A.', fecha: '2026-09-03', codigo_ref: '01', moneda: 'CRC', total: 158200, por_aplicar: 158200, emision: 'Aceptada', estado: 'Por aplicar', razon: 'Anulación de la factura 00100001010000000014 por duplicidad' },
  { id: 3, numero: '00100001030000000003', cliente_nombre: 'Hotel Montaña Verde S.A.', fecha: '2026-09-22', codigo_ref: '06', moneda: 'USD', total: 120, por_aplicar: 120, emision: 'Rechazada', estado: 'Por aplicar', razon: 'Devolución de artículos dañados' },
  { id: 4, numero: '00100001030000000004', cliente_nombre: 'Comercializadora Del Valle Ltda.', fecha: '2026-10-01', codigo_ref: '02', moneda: 'CRC', total: 22600, por_aplicar: 0, emision: 'Aceptada', estado: 'Aplicada', razon: 'Descuento comercial no aplicado' },
];

export default {
  props: ['params'],
  data() { return { ejemplo: [], docs: [], q: '', detalle: null, enviarDoc: null }; },
  computed: {
    rows() {
      const reales = this.docs.filter(d => d.tipo_documento === '03').map(d => ({
        id: 'r' + d.id, real: d, numero: d.consecutivo, cliente_nombre: d.receptor_nombre || '—', fecha: d.fecha_emision, codigo_ref: d.referencia_codigo || '', moneda: d.moneda, total: d.total,
        // una nota real se aplica sola a su factura cuando Hacienda la acepta (rebaja el saldo por cobrar)
        factura: d.referencia_clave ? d.referencia_clave.slice(21, 41) : '',
        por_aplicar: ['aceptado', 'interno', 'rechazado', 'error'].includes(d.estado) ? 0 : d.total, emision: this.emision(d),   /* 3.87: la nota interna ya rebajó su factura */
        estado: d.estado === 'rechazado' ? 'Anulada' : ['aceptado', 'interno'].includes(d.estado) ? 'Aplicada' : d.estado === 'error' ? 'Con error' : 'Pendiente de Hacienda',
      }));
      return [...reales, ...this.ejemplo].sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.detalle = r },
        { key: 'cliente_nombre', label: 'Cliente' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'codigo_ref', label: 'Tipo', fmt: v => CAT.codigoRef[v] || 'Nota de crédito' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'por_aplicar', label: 'Por aplicar', num: true, fmt: 'money' },
        { key: 'emision', label: 'Estado de emisión', fmt: 'badge' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    exportarCSV() { const cols = this.columns.filter(c => c.key).map(c => ({ ...c, csv: c.fmt === 'date' ? v => fecha(v) : (c.fmt === 'money' ? v => +v || 0 : undefined) })); exportarTabla('notas_credito', cols, this.rows, { titulo: 'Notas de crédito' }); },   // (R261) en methods: como computed se ejecutaba solo al abrir la pantalla
    money,
    emision(d) { return { generado: 'Sin emitir', firmado: 'Firmada', enviado: 'Enviada', aceptado: 'Aceptada', interno: 'Interna', rechazado: 'Rechazada', error: 'Error' }[d.estado] || d.estado; },
    async cargar() { try { this.docs = await api('/api/comprobantes'); } catch (e) { toast(e.message, 'err'); } },
    async consultar(d) { try { const r = await api(`/api/comprobantes/${d.id}/consultar`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, r.estado === 'rechazado' ? 'err' : 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    aplicar(r) { const x = this.ejemplo.find(x => x.id === r.id); if (!x) return; x.por_aplicar = 0; x.estado = 'Aplicada'; mock.set('notas-credito', this.ejemplo); toast('Nota de crédito aplicada', 'ok'); },
    eliminar(r) { if (!confirm(`¿Eliminar la nota de crédito ${r.numero}?`)) return; this.ejemplo = this.ejemplo.filter(x => x.id !== r.id); mock.set('notas-credito', this.ejemplo); toast('Nota eliminada', 'ok'); },
    // Acciones masivas. Los comprobantes electrónicos reales (con clave) no se eliminan.
    eliminarVarios(rows) {
      const reales = rows.filter(r => r.real).length, ids = rows.filter(r => !r.real).map(r => r.id);
      this.ejemplo = this.ejemplo.filter(x => !ids.includes(x.id)); mock.set('notas-credito', this.ejemplo);
      toast(`${ids.length} notas eliminadas${reales ? `; ${reales} comprobantes electrónicos omitidos (no se pueden eliminar)` : ''}`, reales ? undefined : 'ok');
    },
    async enviar(d) { try { const r = await api(`/api/comprobantes/${d.id}/enviar`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, ['rechazado', 'error'].includes(r.estado) ? 'err' : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async consultarVarios(rows) {
      const reales = rows.filter(r => r.real && ['enviado', 'aceptado', 'rechazado'].includes(r.real.estado));
      if (!reales.length) return toast('Seleccione comprobantes electrónicos enviados a Hacienda');
      let ok = 0, err = 0;
      for (const r of reales) { try { await api(`/api/comprobantes/${r.real.id}/consultar`, { method: 'POST' }); ok++; } catch (e) { err++; } }
      toast(`Consulta: ${ok} correctos${err ? `, ${err} con error` : ''}`, err ? 'err' : 'ok'); this.cargar();
    },
    bulk() {
      return [
        ...(this.ejemplo.length ? [{ label: 'Aplicar', kind: 'sec', handler: rows => { let n = 0; for (const r of rows) { const x = this.ejemplo.find(x => x.id === r.id); if (x && x.por_aplicar > 0) { x.por_aplicar = 0; x.estado = 'Aplicada'; n++; } } mock.set('notas-credito', this.ejemplo); toast(`${n} notas aplicadas`, 'ok'); } }] : []),   // solo para notas de ejemplo
        { label: '↻ Consultar estado', kind: 'sec', handler: rows => this.consultarVarios(rows) },
        { label: '⎙ Descargar PDFs', kind: 'sec', handler: rows => rows.filter(r => r.real).forEach((r, i) => setTimeout(() => !avisoSesion.mensaje && window.open(`/api/comprobantes/${r.real.id}/pdf`, '_blank'), i * 300)) },
      ];
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Notas de crédito" sub="Documentos que disminuyen el saldo de una factura de venta: devoluciones, descuentos o anulaciones.">
      <button class="btn ghost" @click="exportarCSV">⤓ Exportar</button>
      <a class="btn" v-if="puede('facturar')" href="#/ventas/notas-credito/nueva">+ Nueva nota de crédito</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('facturar')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado notas de crédito" empty-text="Emita una nota de crédito electrónica para corregir o anular una factura.">
        <template #actions="{row}">
          <template v-if="row.real">
            <a class="btn icon" :href="'/api/comprobantes/'+row.real.id+'/pdf'" target="_blank" title="PDF">⎙</a>
            <a class="btn icon" :href="'/api/comprobantes/'+row.real.id+'/xml'" target="_blank" title="XML">{ }</a>
            <button class="btn icon" v-if="row.real.estado==='aceptado' && puede('facturar')" @click.stop="enviarDoc=row.real" :title="row.real.correo_enviado ? 'Reenviar por correo' : 'Enviar por correo'">✉</button>
            <span class="small muted" v-if="row.real.estado==='aceptado' && !row.real.correo_enviado && row.real.cliente_id && sesion.empresaInfo?.correo_en_nube" title="El correo al cliente lo envía la nube cuando este comprobante sube">Correo por la nube</span>
            <button class="btn sm" v-if="['firmado','error'].includes(row.real.estado)" @click.stop="enviar(row.real)" title="Enviar (o reenviar) a Hacienda">⇪ Enviar</button>
            <button class="btn sm sec" v-if="['enviado','aceptado','rechazado'].includes(row.real.estado)" @click.stop="consultar(row.real)">Consultar</button>
          </template>
          <template v-else>
            <button class="btn sm sec" v-if="row.por_aplicar>0 && !row.real" @click.stop="aplicar(row)">Aplicar</button>
            <button class="btn icon danger" v-if="puede('facturar')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
          </template>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/notas-credito/nueva">+ Nueva nota de crédito</a></template>
      </DataTable>
    </div>
    <Modal v-if="detalle" :title="'Nota de crédito '+detalle.numero" @close="detalle=null">
      <div class="grid cols-2">
        <div><div class="small muted">Cliente</div><b>{{detalle.cliente_nombre}}</b></div>
        <div><div class="small muted">Fecha</div><b>{{fecha(detalle.fecha)}}</b></div>
        <div><div class="small muted">Tipo</div><b>{{CAT.codigoRef[detalle.codigo_ref] || '—'}}</b></div>
        <div><div class="small muted">Estado de emisión</div><Badge :value="detalle.emision"></Badge></div>
        <div style="grid-column:1/-1" v-if="detalle.razon || detalle.real?.mensaje_hacienda"><div class="small muted">{{detalle.real ? 'Hacienda' : 'Razón'}}</div>{{detalle.razon || detalle.real.mensaje_hacienda}}</div>
        <div style="grid-column:1/-1" v-if="detalle.real"><div class="small muted">Clave</div><span class="mono">{{detalle.real.clave}}</span></div>
      </div>
      <div class="totals"><div><span>Por aplicar</span><b>{{money(detalle.por_aplicar, detalle.moneda)}}</b></div><div class="total"><span>Total</span><b>{{money(detalle.total, detalle.moneda)}}</b></div></div>
      <template #foot><button class="btn ghost" @click="detalle=null">Cerrar</button></template>
    </Modal>
    <EnviarCorreo v-if="enviarDoc" :doc="enviarDoc" @close="enviarDoc=null" @enviado="enviarDoc=null; cargar()"></EnviarCorreo>
  </div>`,
  setup() { return { CAT, sesion }; },
};
