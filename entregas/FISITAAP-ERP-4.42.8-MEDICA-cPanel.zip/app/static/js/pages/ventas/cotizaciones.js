// Cotizaciones — lista (datos de ejemplo en localStorage: mock 'cotizaciones'; el PDF se genera con el backend real POST /api/pdf/documento)
import { api, toast, money, mock, token, fecha, cabecerasAuth, hoy } from '../../api.js';
import { exportarTabla } from '../reportes/_montos.js';
import { store } from '../../app.js';

// ---- helpers compartidos de PDF (también los usan cotizacion-form, remisiones y gastos) ----
// Abre en una pestaña nueva (o descarga, si se indica nombre) el PDF devuelto por POST /api/pdf/documento.
export async function abrirPdfDocumento(payload, descargarComo) {
  const w = descargarComo ? null : window.open('', '_blank');
  try {
    // POST exige el token en el header (la cookie HttpOnly solo vale para GET)
    const r = await fetch('/api/pdf/documento', { method: 'POST', headers: cabecerasAuth({ 'Content-Type': 'application/json' }), body: JSON.stringify(payload) });
    if (!r.ok) { const j = await r.json().catch(() => null); const d = j && j.detail; throw new Error(typeof d === 'string' ? d : 'No se pudo generar el PDF'); }
    const url = URL.createObjectURL(await r.blob());
    if (descargarComo) { const a = document.createElement('a'); a.href = url; a.download = descargarComo; a.click(); setTimeout(() => URL.revokeObjectURL(url), 10000); }
    else if (w) w.location.href = url; else window.open(url, '_blank');
  } catch (err) { if (w) w.close(); throw err; }
}
// Líneas del LineEditor al formato del PDF (descuento en monto).
export function lineasPdf(lineas) {
  return (lineas || []).filter(l => l.detalle || l.producto_id || +l.precio_unitario).map(l => ({
    producto_id: l.producto_id || null, detalle: l.detalle || '', descripcion: l.descripcion || '', referencia: l.referencia || '', cabys: l.cabys || '', cantidad: +l.cantidad || 0, precio_unitario: +l.precio_unitario || 0,
    descuento: +l.descuento || 0, tarifa: +l.tarifa || 0, tarifa_exonerada: +l.tarifa_exonerada || 0, unidad_medida: l.unidad_medida || (l.es_servicio ? 'Sp' : 'Unid'), es_servicio: !!l.es_servicio,
  }));
}
// Payload de POST /api/pdf/documento para una cotización o remisión (cliente desde store.clientes cuando existe).
export function payloadDocumentoVenta(doc, tipo) {
  const c = (store.clientes || []).find(x => x.id == doc.cliente_id) || {};
  const p = {
    tipo, numero: doc.numero, fecha: doc.fecha, vence: doc.vence || null, moneda: doc.moneda || 'CRC', tipo_cambio: doc.tipo_cambio || 1, vendedor: doc.vendedor || null,
    cliente: { nombre: doc.cliente_nombre || c.nombre || '', tipo_id: c.tipo_id || '', cedula: doc.cliente_cedula || c.numero_id || '', telefono: c.telefono || '', direccion: c.direccion || '', correo: c.correo || '' },
    lineas: lineasPdf(doc.lineas), terminos: doc.terminos || null, notas: doc.notas || null,
    exoneracion: doc.exoneracion || null, marca_id: doc.marca_id || null,   /* 3.45 */
  };
  if (tipo === 'remision' && doc.tipo && doc.tipo !== 'Remisión') p.titulo = doc.tipo;
  return p;
}

function lin(detalle, cantidad, precio) { return { producto_id: null, detalle, cabys: '', cantidad, precio_unitario: precio, descuento: 0, codigo_tarifa: '08', tarifa: 13 }; }
export const COTIZACIONES_EJEMPLO = [
  { id: 1, numero: 'COT-0001', cliente_id: null, cliente_nombre: 'Distribuidora La Central S.A.', cliente_cedula: '3-101-234567', fecha: '2026-09-01', vence: '2026-09-15', moneda: 'CRC', estado: 'Facturada', lineas: [lin('Instalación de red estructurada (puntos)', 12, 45000)], notas: 'Incluye certificación de puntos.', terminos: 'Validez de la oferta: 15 días. Precios en colones, IVA incluido.' },
  { id: 2, numero: 'COT-0002', cliente_id: null, cliente_nombre: 'Hotel Montaña Verde S.A.', cliente_cedula: '3-101-890123', fecha: '2026-09-12', vence: '2026-10-12', moneda: 'USD', estado: 'Sin facturar', lineas: [lin('Licencia anual software de reservas', 1, 1200), lin('Capacitación al personal (horas)', 8, 45)], notas: '', terminos: 'Pago 50 % adelantado, 50 % contra entrega.' },
  { id: 3, numero: 'COT-0003', cliente_id: null, cliente_nombre: 'Comercializadora Del Valle Ltda.', cliente_cedula: '3-102-567890', fecha: '2026-09-20', vence: '2026-10-05', moneda: 'CRC', estado: 'Sin facturar', lineas: [lin('Computadora portátil 14" i5 16GB', 3, 485000), lin('Mouse inalámbrico', 3, 12500)], notas: 'Garantía de 1 año con el fabricante.', terminos: 'Validez de la oferta: 15 días.' },
  { id: 4, numero: 'COT-0004', cliente_id: null, cliente_nombre: 'Consultores Asociados de Heredia S.A.', cliente_cedula: '3-101-789012', fecha: '2026-10-02', vence: '2026-10-17', moneda: 'CRC', estado: 'Sin facturar', lineas: [lin('Desarrollo de sitio web institucional', 1, 850000)], notas: 'Entrega en 6 semanas a partir de la aprobación.', terminos: 'Cuenta BAC ₡ CR12010200009123456789.' },
];

export default {
  props: ['params'],
  data() {
    // En demo, mock.ejemplos ya guarda la semilla la primera vez (para que "Convertir a factura" la encuentre); abrir la lista no guarda nada
    const lista = mock.ejemplos('cotizaciones', COTIZACIONES_EJEMPLO, 'numero');
    return { lista, q: '', menu: false, docs: [] };
  },
  computed: {
    rows() { return this.lista.map(c => ({ ...c, total: this.total(c), vencida: c.estado === 'Sin facturar' && c.vence && c.vence < hoy(),
      // la factura vinculada fue rechazada por Hacienda: se puede volver a convertir (R329)
      reconvertible: c.estado === 'Facturada' && c.factura_id && this.docs.some(d => d.id === c.factura_id && ['rechazado', 'error'].includes(d.estado)) })).sort((a, b) => b.id - a.id); },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.ver(r) },
        { key: 'cliente_nombre', label: 'Cliente' },
        { key: 'fecha', label: 'Creación', fmt: v => this.f(v) },
        { key: 'vence', label: 'Vencimiento', fmt: (v, r) => this.f(v) + (r.vencida ? ' (vencida)' : '') },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    exportar() { exportarTabla('cotizaciones', this.columns, this.rows, { titulo: 'Cotizaciones' }); },   // 4.17
    money,
    f(v) { return v ? fecha(v) : ''; },
    total(c) { return (c.lineas || []).reduce((s, l) => { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); return s + m + m * ((+l.tarifa || 0) - (+l.tarifa_exonerada || 0)) / 100; }, 0); },   // menos la exoneración guardada
    ver(r) { location.hash = '/ventas/cotizaciones/' + r.id; },
    convertir(r) { location.hash = '/ventas/facturas/nueva?cotizacion=' + r.id; },
    async imprimir(r) { try { await abrirPdfDocumento(payloadDocumentoVenta(r, 'cotizacion')); } catch (e) { toast(e.message, 'err'); } },
    eliminar(r) { if (!confirm(`¿Eliminar la cotización ${r.numero}?`)) return; this.lista = this.lista.filter(x => x.id !== r.id); mock.set('cotizaciones', this.lista); toast('Cotización eliminada', 'ok'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = this.lista.filter(x => !ids.includes(x.id)); mock.set('cotizaciones', this.lista); toast(`${ids.length} cotizaciones eliminadas`, 'ok'); },
    pronto() { this.menu = false; toast('Muy pronto: crear cotizaciones desde archivo o imagen con IA'); },
  },
  async created() { try { this.docs = await api('/api/comprobantes'); } catch {} },   // estado de la factura vinculada (R329)
  template: `
  <div class="page">
    <PageHead title="Cotizaciones" sub="Envíe propuestas a sus clientes y conviértalas en factura con un clic.">
      <button class="btn ghost" @click="exportar">Exportar</button>
      <div class="row" style="gap:0;position:relative">
        <a class="btn" v-if="puede('facturar')" href="#/ventas/cotizaciones/nueva" style="border-top-right-radius:0;border-bottom-right-radius:0">+ Nueva cotización</a>
        <button class="btn" style="border-top-left-radius:0;border-bottom-left-radius:0;padding:0 10px;border-left:1px solid rgba(255,255,255,.35)" @click="menu=!menu">▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:250px;padding:6px">
          <a class="item" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/ventas/cotizaciones/nueva" @click="menu=false">Crear manualmente</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer;color:inherit" @click="pronto">Crear desde archivo o imagen</a>
        </div>
      </div>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('facturar')" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado cotizaciones" empty-text="Cree una cotización para enviar una propuesta formal a su cliente.">
        <template #actions="{row}">
          <button class="btn icon" @click.stop="ver(row)" title="Ver / editar">✎</button>
          <a class="btn icon" v-if="puede('facturar')" :href="'#/ventas/cotizaciones/nueva?duplicar=' + row.id" @click.stop title="Duplicar: nueva cotización con las mismas líneas">⧉</a>
          <button class="btn sm sec" v-if="row.estado==='Sin facturar' || row.reconvertible" @click.stop="convertir(row)">{{row.reconvertible ? 'Volver a convertir (rechazada)' : 'Convertir a factura'}}</button>
          <button class="btn icon" @click.stop="imprimir(row)" title="Ver PDF">⎙</button>
          <button class="btn icon danger" v-if="puede('facturar')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/cotizaciones/nueva">+ Nueva cotización</a></template>
      </DataTable>
    </div>
  </div>`,
  setup() { return { toast }; },
};
