// Pagos recibidos — lista real (/api/pagos). Cada pago aplicado a facturas actualiza su saldo por cobrar.
import { api, toast, money, mock, fecha } from '../../api.js';

export default {
  props: ['params'],
  data() { return { lista: [], q: '', detalle: null, cargando: true }; },
  computed: {
    rows() { return this.lista.slice().sort((a, b) => b.numero - a.numero).map(p => ({ ...p, hacienda: p.tipo === 'rep' ? (p.documentos || []).map(d => d.estado).join(', ') || 'sin emitir' : '' })); },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, width: '90px', link: r => this.detalle = r },
        { key: 'cliente_nombre', label: 'Cliente', fmt: v => v || 'Sin cliente' },
        { key: 'detalles', label: 'Detalles' },
        { key: 'fecha', label: 'Creación', fmt: 'date' },
        { key: 'cuenta', label: 'Cuenta bancaria' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
        { key: 'hacienda', label: 'REP', fmt: 'badge' },
        { key: 'monto', label: 'Monto', num: true, fmt: 'money' },
      ];
    },
  },
  methods: {
    money,
    async cargar() { this.cargando = true; try { this.lista = await api('/api/pagos'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    async conciliar(r) {
      const estado = r.estado === 'Conciliado' ? 'No conciliado' : 'Conciliado';
      try { await api('/api/pagos/' + r.id + '/estado', { method: 'PUT', body: { estado } }); toast(`Pago #${r.numero} marcado como ${estado.toLowerCase()}`, 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminar(r) {
      if (!confirm(`¿Eliminar el pago #${r.numero} de ${r.cliente_nombre || 'sin cliente'}? El saldo de las facturas aplicadas se restaura.`)) return;
      try { await api('/api/pagos/' + r.id, { method: 'DELETE' }); toast('Pago eliminado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    imprimir(r) { this.detalle = r; setTimeout(() => window.print(), 300); },
    async consultarRep(d) { try { const r = await api(`/api/comprobantes/${d.id}/${['firmado', 'error'].includes(d.estado) ? 'enviar' : 'consultar'}`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, ['rechazado', 'error'].includes(r.estado) ? 'err' : 'ok'); await this.cargar(); this.detalle = this.lista.find(x => x.id === this.detalle.id) || null; } catch (e) { toast(e.message, 'err'); } },
    async conciliarVarios(rows, estado) {
      let ok = 0, err = 0;
      for (const r of rows) { try { await api('/api/pagos/' + r.id + '/estado', { method: 'PUT', body: { estado } }); ok++; } catch { err++; } }
      toast(`${ok} pagos marcados como ${estado.toLowerCase()}` + (err ? `, ${err} con error` : ''), err ? 'err' : 'ok'); this.cargar();   // (R198)
    },
    bulk() {
      return [
        { label: 'Conciliar', kind: 'sec', handler: rows => this.conciliarVarios(rows, 'Conciliado') },
        { label: 'Desconciliar', kind: 'sec', handler: rows => this.conciliarVarios(rows, 'No conciliado') },
      ];
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Pagos recibidos" sub="Registre los pagos de sus clientes y aplíquelos a las facturas por cobrar.">
      <a class="btn" v-if="puede('cobros')" href="#/ventas/pagos/nuevo">+ Nuevo pago recibido</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('cobros')" :bulk-actions="bulk()" empty-title="Aún no has registrado pagos" empty-text="Registre el primer pago recibido de un cliente para llevar el control de sus cuentas por cobrar.">
        <template #actions="{row}">
          <button class="btn icon" @click.stop="imprimir(row)" title="Imprimir">⎙</button>
          <button class="btn sm sec" v-if="puede('cobros')" @click.stop="conciliar(row)">{{row.estado==='Conciliado'?'Desconciliar':'Conciliar'}}</button>
          <button class="btn icon danger" v-if="puede('cobros')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('cobros')" href="#/ventas/pagos/nuevo">+ Nuevo pago recibido</a></template>
      </DataTable>
    </div>

    <Modal v-if="detalle" :title="(detalle.tipo==='rep'?'Recibo electrónico de pago ':'Recibo de caja #')+(detalle.tipo==='rep' ? detalle.consecutivo : detalle.numero)" @close="detalle=null">
      <div class="grid cols-2">
        <div><div class="small muted">Cliente</div><b>{{detalle.cliente_nombre || 'Sin cliente'}}</b><div class="small muted">{{detalle.cliente_cedula}}</div></div>
        <div><div class="small muted">Fecha</div><b>{{fecha(detalle.fecha)}}</b></div>
        <div><div class="small muted">Cuenta bancaria</div><b>{{detalle.cuenta || '—'}}</b></div>
        <div><div class="small muted">Estado</div><Badge :value="detalle.estado"></Badge></div>
        <div style="grid-column:1/-1"><div class="small muted">Detalles</div>{{detalle.detalles}}</div>
        <div style="grid-column:1/-1" v-if="detalle.facturas && detalle.facturas.length"><div class="small muted">Facturas aplicadas</div><div v-for="f in detalle.facturas" :key="f.id"><span class="mono">{{f.consecutivo}}</span> · {{money(f.monto, detalle.moneda)}}</div></div>
        <div style="grid-column:1/-1" v-if="detalle.notas"><div class="small muted">Notas</div>{{detalle.notas}}</div>
        <div style="grid-column:1/-1" v-if="detalle.documentos && detalle.documentos.length"><div class="small muted">Recibos electrónicos de pago</div><div v-for="d in detalle.documentos" :key="d.id" class="row" style="gap:8px;align-items:center"><span class="mono">{{d.consecutivo}}</span> <Badge :value="d.estado"></Badge> <a class="btn icon" :href="'/api/comprobantes/'+d.id+'/pdf'" target="_blank" title="PDF">⎙</a><a class="btn icon" :href="'/api/comprobantes/'+d.id+'/xml'" target="_blank" title="XML">{ }</a><button class="btn sm sec" v-if="['enviado','aceptado','rechazado','firmado','error'].includes(d.estado)" @click="consultarRep(d)">{{d.estado==='firmado' ? 'Enviar' : 'Consultar'}}</button></div></div>
      </div>
      <div class="totals"><div class="total"><span>Monto</span><b>{{money(detalle.monto, detalle.moneda)}}</b></div></div>
      <template #foot><button class="btn ghost" @click="detalle=null">Cerrar</button><button class="btn sec" @click="window.print()">Imprimir</button></template>
    </Modal>
  </div>`,
  setup() { return { window }; },
};
