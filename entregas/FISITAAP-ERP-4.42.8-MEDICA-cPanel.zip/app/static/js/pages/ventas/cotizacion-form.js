// Formulario compartido de Cotización y Remisión / Orden de servicio (datos de ejemplo: mock 'cotizaciones' o 'remisiones'; PDF real con POST /api/pdf/documento)
import { api, toast, money, hoy, mock, CAT, monedas, fecha, siguienteNumero, demo, abrirArchivo } from '../../api.js';
import ExoneracionRapida, { tarifaExoLinea, fotoExoneracion } from '../contactos/exoneracion-rapida.js';
import { store, sesion } from '../../app.js';
import { COTIZACIONES_EJEMPLO, abrirPdfDocumento, payloadDocumentoVenta } from './cotizaciones.js';
import { REMISIONES_EJEMPLO } from './remisiones.js';

function masDias(iso, n) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }

export default {
  props: ['params'],
  components: { ExoneracionRapida },
  data() {
    const esRemision = location.hash.includes('remisiones');
    const clave = esRemision ? 'remisiones' : 'cotizaciones';
    // producción arranca en 1; solo la demo arranca después de sus ejemplos
    const num = mock.get('numeracion-' + clave, { prefijo: esRemision ? 'REM-' : 'COT-', siguiente: demo.activo ? (esRemision ? REMISIONES_EJEMPLO : COTIZACIONES_EJEMPLO).length + 1 : 1 });
    num.siguiente = siguienteNumero(mock.get(clave, []), 'numero', num.prefijo, num.siguiente);    // lo que se ve es lo que se guarda
    return {
      esRemision, clave, num, numModal: false, numEdit: { ...num }, ajustes: false, preview: false, generando: false, CAT, monedasOpc: monedas.opciones(),
      errores: {},
      exos: [], exoAuto: false, exosCargando: false, exoNueva: false,   // exoneraciones vigentes del cliente (la primera se aplica sola)
      bodegasApi: [], duplicadoDe: '', marcas: [],
      f: { id: null, numero: '', tipo: 'Remisión', cliente_id: null, cliente_nombre: '', cliente_cedula: '', fecha: hoy(), vence: masDias(hoy(), 15), moneda: monedas.principal().codigo, tipo_cambio: null, bodega: 'Principal', vendedor: '', lineas: [], notas: '', estado: 'Sin facturar',
           terminos: '', exoneracion_id: undefined, marca_id: null },   // exoneracion_id: undefined = la elige el sistema, null = sin exoneración; terminos vacío: el PDF usa los términos de Configuración › Documentos (R50)
    };
  },
  computed: {
    store() { return store; },
    e() { return store.empresa; },
    marcaNombre() { const m = this.marcas.find(x => x.id === this.f.marca_id); return m ? m.nombre : (this.e?.nombre_comercial || this.e?.nombre || 'Mi empresa'); },
    lista() { return mock.ejemplos(this.clave, this.esRemision ? REMISIONES_EJEMPLO : COTIZACIONES_EJEMPLO, 'numero'); },
    // Tipo de cambio efectivo: el escrito a mano o, en blanco, el configurado (venta BCCR + margen) para el USD
    tcConfigurado() { return monedas.tcPrecio('USD'); },    // colones por 1 USD con margen de protección (precios)
    tcEfectivo() { return +this.f.tipo_cambio > 0 ? +this.f.tipo_cambio : this.tcConfigurado; },
    otraMoneda() { return this.f.moneda === 'USD' ? 'CRC' : (this.f.moneda === 'CRC' ? 'USD' : null); },
    conv() { const tc = this.tcEfectivo; return v => (this.f.moneda === 'USD' ? v * tc : v / tc); },
    titulo() { return this.f.id ? `${this.esRemision ? this.f.tipo : 'Cotización'} ${this.f.numero}` : (this.esRemision ? 'Nueva remisión' : 'Nueva cotización'); },
    rutaLista() { return this.esRemision ? '/ventas/remisiones' : '/ventas/cotizaciones'; },
    numeroPrevisto() { return this.f.numero || `${this.num.prefijo}${String(this.num.siguiente).padStart(4, '0')}`; },
    totales() {
      let sub = 0, desc = 0, iva = 0, exo = 0;
      for (const l of this.f.lineas) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); const d = +l.descuento || 0; const te = tarifaExoLinea(this.exoEfectiva, l); sub += m; desc += d; iva += (m - d) * ((+l.tarifa || 0) - te) / 100; exo += (m - d) * te / 100; }
      return { sub, desc, neto: sub - desc, iva, exo, total: sub - desc + iva };
    },
    exoSel() { return this.exos.find(x => x.id === this.f.exoneracion_id) || null; },
    exoSinLineas() { const x = this.exoSel; return !!x && this.f.lineas.some(l => l.cabys || l.producto_id) && !this.f.lineas.some(l => tarifaExoLinea(x, l) > 0); },
    // la elegida por el sistema que no cubre ninguna línea no se usa
    exoEfectiva() { return this.exoSel && !(this.exoAuto && this.exoSinLineas) ? this.exoSel : null; },
    numeroCliente() { const c = (store.clientes || []).find(x => x.id == this.f.cliente_id); return String((c && c.numero_id) || this.f.cliente_cedula || ''); },
  },
  watch: {
    'f.moneda'() { this.f.tipo_cambio = null; },     // en blanco = tipo de cambio configurado
    'f.cliente_id'(v, antes) { if (antes != null && v !== antes) this.f.exoneracion_id = undefined; this.cargarExos(); },
  },
  methods: {
    money,
    fmtFecha(v) { return v ? fecha(v) : ''; },
    async cargarExos() {
      const cid = this.f.cliente_id;
      if (!cid) { this.exos = []; return; }
      this.exosCargando = true;
      try {
        const l = (await api('/api/clientes/' + cid + '/exoneraciones')).filter(x => x.activa && x.estado !== 'vencida' && !x.solo_notas);
        if (this.f.cliente_id !== cid) return;
        this.exos = l;
        if (this.f.exoneracion_id === undefined) { this.f.exoneracion_id = l.length ? l[0].id : undefined; this.exoAuto = !!l.length; }
        else if (this.f.exoneracion_id && !l.some(x => x.id === this.f.exoneracion_id)) { this.f.exoneracion_id = null; this.exoAuto = false; toast('La exoneración de este documento ya no está vigente: se quitó', 'err'); }
      } catch { this.exos = []; }
      if (this.f.cliente_id === cid) this.exosCargando = false;
    },
    async exoRegistrada(x) { this.exoNueva = false; await this.cargarExos(); if (x && this.exos.some(e => e.id === x.id)) { this.f.exoneracion_id = x.id; this.exoAuto = false; } },
    async verPdfExo(x) { try { await abrirArchivo('/api/exoneraciones/' + x.id + '/pdf'); } catch (e) { toast(e.message, 'err'); } },
    // documento con la exoneración aplicada: foto de la exoneración y tarifa exonerada por línea (lista, PDF y conversión a factura)
    conExoneracion(doc) {
      const x = this.exoEfectiva;
      return { ...doc, exoneracion: fotoExoneracion(x), exoneracion_id: x ? x.id : (this.f.exoneracion_id === null ? null : undefined),
        lineas: (doc.lineas || []).map(l => ({ ...l, tarifa_exonerada: tarifaExoLinea(x, l) })) };
    },
    exoEtiqueta(x) { return x.numero + ' · exonera ' + (+x.tarifa).toLocaleString('es-CR') + ' % · ' + (x.fecha_vencimiento ? 'vence ' + fecha(x.fecha_vencimiento) : 'sin vencimiento') + (x.posee_cabys ? ' · ' + x.cabys.length + ' CABYS' : ''); },
    setCliente() { const c = store.clientes.find(x => x.id == this.f.cliente_id); if (c) { this.f.cliente_nombre = c.nombre; this.f.cliente_cedula = c.numero_id; } },
    guardarNumeracion() {
      if (!this.numEdit.prefijo.trim()) return toast('Indique el prefijo', 'err');
      if (!(+this.numEdit.siguiente > 0)) return toast('El siguiente número debe ser mayor a cero', 'err');
      this.num = { prefijo: this.numEdit.prefijo.trim(), siguiente: +this.numEdit.siguiente }; mock.set('numeracion-' + this.clave, this.num); this.numModal = false; toast('Numeración actualizada', 'ok');
    },
    // Validación con mensaje junto al campo (además del aviso flotante) y desplazamiento al campo con error
    falla(campo, msg) { this.errores = { ...this.errores, [campo]: msg }; toast(msg, 'err'); this.$nextTick(() => document.querySelector('.inv')?.scrollIntoView({ behavior: 'smooth', block: 'center' })); return false; },
    guardar() {
      const f = this.f;
      this.errores = {};
      if (!f.cliente_nombre) return this.falla('cliente', 'Seleccione el cliente');
      if (!f.lineas.length || !f.lineas.some(l => l.detalle || l.producto_id)) return this.falla('lineas', 'Agregue al menos una línea');
      if (f.vence && f.vence < f.fecha) return this.falla('vence', 'La fecha de vencimiento debe ser posterior a la de creación');
      const lista = this.lista.slice();
      const reg = JSON.parse(JSON.stringify(this.conExoneracion(f)));
      reg.tipo_cambio_manual = +f.tipo_cambio > 0; reg.tipo_cambio = this.tcEfectivo;   // se guarda el valor usado, para que el PDF no cambie después
      if (!this.esRemision) delete reg.tipo;
      if (reg.id) { const i = lista.findIndex(x => x.id === reg.id); lista.splice(i, 1, reg); }
      else {
        // número del contador, salvo que ya lo use otro documento (contador viejo u otra persona a la vez)
        if (!this.f.numero) this.num = { ...this.num, siguiente: siguienteNumero(mock.get(this.clave, []), 'numero', this.num.prefijo, this.num.siguiente) };
        reg.id = mock.nextId(lista, this.clave); reg.numero = this.numeroPrevisto; lista.push(reg); this.num = { ...this.num, siguiente: this.num.siguiente + 1 }; mock.set('numeracion-' + this.clave, this.num);
      }
      mock.set(this.clave, lista);
      toast(`${this.esRemision ? reg.tipo : 'Cotización'} ${reg.numero} guardada`, 'ok');
      location.hash = this.rutaLista;
    },
    // Genera el PDF real del documento actual (abre en pestaña nueva o descarga).
    async pdf(descargar) {
      if (!this.f.lineas.some(l => l.detalle || l.producto_id)) return toast('Agregue al menos una línea para generar el PDF', 'err');
      this.generando = true;
      try { await abrirPdfDocumento(payloadDocumentoVenta({ ...this.conExoneracion(this.f), tipo_cambio: this.tcEfectivo, numero: this.numeroPrevisto }, this.esRemision ? 'remision' : 'cotizacion'), descargar ? this.numeroPrevisto + '.pdf' : null); }
      catch (err) { toast(err.message, 'err'); }
      this.generando = false;
    },
    imprimir() { this.pdf(false); },
  },
  created() {
    api('/api/inventario/bodegas').then(l => { this.bodegasApi = l || []; }).catch(() => {});   /* 3.35: bodegas reales */
    api('/api/marcas').then(l => { this.marcas = (l || []).filter(m => m.activa || m.id === this.f.marca_id); if (!this.f.id && !this.f.marca_id) { const p = this.marcas.find(m => m.id === sesion.marcaSucursal) || this.marcas.find(m => m.predeterminada); if (p) this.f.marca_id = p.id; } }).catch(() => {});   /* 3.45; 3.82: la de la sucursal */
    if (this.params.id) {
      const x = this.lista.find(x => x.id == this.params.id);
      if (x) { this.f = { ...this.f, ...JSON.parse(JSON.stringify(x)) }; this.$nextTick(() => { this.f.tipo_cambio = x.tipo_cambio_manual ? x.tipo_cambio : null; }); } else toast('No se encontró el documento', 'err');
    } else if (this.params.duplicar) {       // Duplicar (3.43): mismas líneas, cliente y condiciones; número nuevo, fecha de hoy y sin facturar
      const x = this.lista.find(x => x.id == this.params.duplicar);
      if (x) { const c = JSON.parse(JSON.stringify(x)); this.f = { ...this.f, ...c, id: null, numero: '', fecha: hoy(), vence: masDias(hoy(), 15), estado: 'Sin facturar', factura_id: undefined, facturada: undefined, convertida: undefined }; this.$nextTick(() => { this.f.tipo_cambio = null; }); this.duplicadoDe = x.numero; }
      else toast('No se encontró el documento a duplicar', 'err');
    }
    if (this.params.imprimir) setTimeout(() => this.imprimir(), 400);
  },
  template: `
  <div class="page">
    <PageHead :title="titulo" :crumbs="[{label: esRemision ? 'Remisiones' : 'Cotizaciones', to: rutaLista},{label: f.id ? f.numero : 'Nueva'}]">
      <Badge v-if="f.id" :value="f.estado"></Badge>
      <a class="btn ghost" v-if="f.id" :href="'#' + rutaLista + '/nueva?duplicar=' + f.id" title="Nuevo documento con las mismas líneas y el mismo cliente">Duplicar</a>
      <button class="btn ghost" @click="ajustes=true">Más ajustes</button>
    </PageHead>
    <div class="alert info" v-if="duplicadoDe" style="margin-bottom:12px">Copia de <b>{{duplicadoDe}}</b> con fecha de hoy: revise las líneas y los precios antes de guardar.</div>
    <div class="card">
      <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap;gap:12px">
        <div><div style="font-size:16px;font-weight:650">{{marcaNombre}}</div><div class="small muted">{{CAT.tipoId[e?.tipo_id]||''}}: {{e?.numero_id}} · {{e?.correo}}</div></div>
        <div style="text-align:right">
          <div class="small muted">{{esRemision ? 'Plantilla: Remisión' : 'Plantilla: Cotización'}}</div>
          <div class="row" style="justify-content:flex-end;gap:6px"><span>No. <b class="mono">{{numeroPrevisto}}</b></span><button class="btn icon" title="Configurar numeración" @click="numEdit={...num};numModal=true" :disabled="!!f.id">⚙</button></div>
        </div>
      </div>
      <div class="grid">
        <Field v-if="esRemision" label="Tipo de documento" req>
          <div class="seg"><button :class="{on:f.tipo==='Remisión'}" @click="f.tipo='Remisión'">Remisión</button><button :class="{on:f.tipo==='Orden de servicio'}" @click="f.tipo='Orden de servicio'">Orden de servicio</button></div>
        </Field>
        <Field label="Cliente" req :help="errores.cliente">
          <Buscador v-if="store.clientes.length" v-model="f.cliente_id" :opciones="store.clientes" detalle="numero_id" vacio="Seleccionar" agregar="cliente" :invalido="!!errores.cliente" @change="setCliente(); errores.cliente=''"></Buscador>
          <input v-else v-model="f.cliente_nombre" placeholder="Nombre del cliente" :class="{inv: errores.cliente}" @input="errores.cliente=''">
        </Field>
        <Field label="Fecha de creación"><input type="date" v-model="f.fecha"></Field>
        <Field label="Fecha de vencimiento"><input type="date" v-model="f.vence"></Field>
        <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :key="m.value" :value="m.value">{{m.label}}</option></select></Field>
        <Field label="Tipo de cambio" :help="'En blanco usa el configurado: ' + money(tcConfigurado, 'CRC') + ' por USD (venta BCCR + margen). Escriba un valor para ajustarlo a mano.'"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio" :placeholder="tcConfigurado.toFixed(2)"></Field>
      </div>
      <p class="small muted" v-if="store.clientes.length && f.cliente_nombre && !f.cliente_id" style="margin:8px 0 0">Cliente: <b>{{f.cliente_nombre}}</b> {{f.cliente_cedula}}</p>
    </div>
    <div class="card" v-if="f.cliente_id && (exos.length || puede('facturar') || puede('catalogos'))">
      <h2>Exoneración del cliente <small>Se refleja en los totales y en el PDF; al convertir a factura pasa con el documento</small></h2>
      <div class="grid cols-2">
        <p class="small muted" v-if="!exos.length && !exosCargando" style="margin:0;align-self:center">El cliente no tiene exoneraciones vigentes. Si presenta una, cárguela con su PDF o número.</p>
        <Field v-else label="Documento de exoneración"><select v-model="f.exoneracion_id" @change="exoAuto = false"><option :value="null">— No aplicar exoneración —</option><option v-for="x in exos" :key="x.id" :value="x.id">{{exoEtiqueta(x)}}</option></select></Field>
        <div class="small muted" v-if="exoSel" style="align-self:center">{{exoSel.tipo}} · {{exoSel.tipo_nombre}}<br>{{exoSel.institucion_nombre}}<span v-if="exoSel.tiene_pdf"> · <a class="link" style="cursor:pointer" @click="verPdfExo(exoSel)">ver PDF</a></span></div>
      </div>
      <div class="alert info" v-if="exoSinLineas" style="margin:10px 0 0">Esta exoneración no aplica a ninguna de las líneas (CABYS no autorizados o sin IVA){{exoAuto ? ': el documento sale sin exoneración' : ''}}.</div>
      <div class="row" style="margin-top:8px" v-if="puede('facturar') || puede('catalogos')"><button class="btn sec sm" @click="exoNueva = true">+ Exoneración (PDF o número)</button></div>
      <ExoneracionRapida v-if="exoNueva" :cliente-id="f.cliente_id" :numero-id="numeroCliente" @close="exoNueva = false" @registrada="exoRegistrada"></ExoneracionRapida>
    </div>
    <div class="card"><h2>Productos o servicios</h2>
      <LineEditor v-model="f.lineas" :productos="store.productos.filter(p=>p.es_venta!==false)" :moneda="f.moneda" :cliente-id="f.cliente_id" :exoneracion="exoEfectiva" con-referencia sin-totales></LineEditor>
      <p class="small muted" style="margin:8px 0 0"><a class="link" href="#/inventario/items/nuevo">+ Crear nuevo producto</a></p>
      <div class="table-wrap" style="margin-top:12px;max-width:520px;margin-left:auto"><table class="tbl">
        <thead><tr><th></th><th class="num">{{f.moneda}}</th><th class="num" v-if="otraMoneda">{{otraMoneda}}</th></tr></thead>
        <tbody>
          <tr><td class="muted">Subtotal</td><td class="num">{{money(totales.sub, f.moneda)}}</td><td class="num" v-if="otraMoneda">{{money(conv(totales.sub), otraMoneda)}}</td></tr>
          <tr v-if="totales.desc"><td class="muted">Descuento</td><td class="num">-{{money(totales.desc, f.moneda)}}</td><td class="num" v-if="otraMoneda">-{{money(conv(totales.desc), otraMoneda)}}</td></tr>
          <tr v-if="totales.exo"><td class="muted">IVA exonerado</td><td class="num">-{{money(totales.exo, f.moneda)}}</td><td class="num" v-if="otraMoneda">-{{money(conv(totales.exo), otraMoneda)}}</td></tr>
          <tr><td class="muted">Impuestos</td><td class="num">{{money(totales.iva, f.moneda)}}</td><td class="num" v-if="otraMoneda">{{money(conv(totales.iva), otraMoneda)}}</td></tr>
          <tr style="font-weight:700;font-size:15px"><td>Total</td><td class="num">{{money(totales.total, f.moneda)}}</td><td class="num" v-if="otraMoneda">{{money(conv(totales.total), otraMoneda)}}</td></tr>
        </tbody>
      </table><p class="small muted" style="text-align:right;margin:4px 8px 0" v-if="otraMoneda">Tipo de cambio {{money(tcEfectivo, 'CRC')}} por USD{{+f.tipo_cambio > 0 ? ' (manual)' : ' (configurado)'}}</p></div>
    </div>
    <div class="card"><div class="grid cols-2">
      <Field label="Notas" help="Visibles para el cliente en el PDF"><textarea rows="3" v-model="f.notas" placeholder="Comentarios o aclaraciones para el cliente"></textarea></Field>
      <Field label="Términos y condiciones"><textarea rows="3" v-model="f.terminos"></textarea></Field>
    </div></div>
    <div class="row end" style="margin-bottom:18px">
      <a class="btn ghost" :href="'#'+rutaLista">Cancelar</a>
      <button class="btn sec" @click="preview=true">Vista previa</button>
      <button class="btn sec" @click="pdf(false)" :disabled="generando">{{generando ? 'Generando…' : 'PDF'}}</button>
      <button class="btn" @click="guardar">Guardar</button>
    </div>
    <Comments :saved="!!f.id"></Comments>

    <Modal v-if="numModal" title="Numeración" @close="numModal=false">
      <div class="grid cols-2">
        <Field label="Prefijo" req><input v-model="numEdit.prefijo" placeholder="COT-"></Field>
        <Field label="Siguiente número" req><input type="number" min="1" v-model.number="numEdit.siguiente"></Field>
      </div>
      <p class="small muted">Próximo documento: <b class="mono">{{numEdit.prefijo}}{{String(numEdit.siguiente||0).padStart(4,'0')}}</b> · <a class="link" href="#/configuracion/numeraciones">Ver todas las numeraciones</a></p>
      <template #foot><button class="btn ghost" @click="numModal=false">Cancelar</button><button class="btn" @click="guardarNumeracion">Guardar</button></template>
    </Modal>

    <Modal v-if="preview" :title="'Vista previa · ' + (esRemision ? f.tipo : 'Cotización') + ' ' + numeroPrevisto" lg @close="preview=false">
      <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:12px">
        <div><div style="font-size:16px;font-weight:650">{{marcaNombre}}</div><div class="small muted">{{e?.numero_id}} · {{e?.correo}}</div></div>
        <div style="text-align:right"><div class="small muted">Creación {{fmtFecha(f.fecha)}}</div><div class="small muted">Vence {{fmtFecha(f.vence)}}</div></div>
      </div>
      <div style="margin-bottom:12px"><div class="small muted">Cliente</div><b>{{f.cliente_nombre || '—'}}</b> <span class="muted">{{f.cliente_cedula}}</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Ítem</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">Desc.</th><th class="num">IVA</th><th class="num">Total</th></tr></thead>
        <tbody><tr v-for="(l,i) in f.lineas" :key="i"><td>{{l.detalle || '—'}}</td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio_unitario, f.moneda)}}</td><td class="num">{{money(l.descuento, f.moneda)}}</td><td class="num">{{l.tarifa}} %</td><td class="num">{{money(((+l.cantidad||0)*(+l.precio_unitario||0)-(+l.descuento||0))*(1+(l.tarifa||0)/100), f.moneda)}}</td></tr></tbody>
      </table></div>
      <div class="totals">
        <div><span>Subtotal</span><b>{{money(totales.sub, f.moneda)}}</b></div>
        <div v-if="totales.desc"><span>Descuento</span><b>-{{money(totales.desc, f.moneda)}}</b></div>
        <div><span>Impuestos</span><b>{{money(totales.iva, f.moneda)}}</b></div>
        <div class="total"><span>Total</span><b>{{money(totales.total, f.moneda)}}</b></div>
        <div v-if="otraMoneda"><span>Equivalente en {{otraMoneda}} (TC {{money(tcEfectivo, 'CRC')}})</span><b>{{money(conv(totales.total), otraMoneda)}}</b></div>
      </div>
      <p class="small" v-if="f.notas" style="margin-top:12px"><b>Notas:</b> {{f.notas}}</p>
      <p class="small muted" v-if="f.terminos"><b>Términos y condiciones:</b> {{f.terminos}}</p>
      <template #foot><button class="btn ghost" @click="preview=false">Cerrar</button><button class="btn sec" @click="window.print()">Imprimir</button><button class="btn" @click="pdf(true)" :disabled="generando">{{generando ? 'Generando…' : 'Descargar PDF'}}</button></template>
    </Modal>

    <Drawer v-if="ajustes" title="Más ajustes" @close="ajustes=false">
      <h2 style="font-size:14px">Parámetros adicionales</h2>
      <div class="grid" style="grid-template-columns:1fr">
        <Field label="Bodega"><Buscador v-model="f.bodega" :opciones="bodegasApi" valor="nombre" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        <Field label="Vendedor"><Buscador v-model="f.vendedor" catalogo="vendedores" valor="nombre" placeholder="Sin vendedor" agregar="vendedor"></Buscador></Field>
        <Field label="Marca" v-if="marcas.length" help="Logo y nombre comercial con que sale el PDF"><select v-model.number="f.marca_id"><option :value="null">Empresa ({{e?.nombre_comercial || e?.nombre}})</option><option v-for="m in marcas" :key="m.id" :value="m.id">{{m.nombre}}{{m.predeterminada ? ' · predeterminada' : ''}}</option></select></Field>
      </div>
      <template #foot><button class="btn ghost" @click="ajustes=false">Cancelar</button><button class="btn" @click="ajustes=false">Guardar</button></template>
    </Drawer>
  </div>`,
  setup() { return { window }; },
};
