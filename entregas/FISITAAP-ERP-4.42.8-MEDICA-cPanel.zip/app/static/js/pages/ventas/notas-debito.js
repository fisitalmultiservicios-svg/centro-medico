// Notas de débito (ingresos) — lista (datos de ejemplo mock 'notas-debito' + documentos reales tipo 02 de /api/comprobantes)
import { api, toast, money, mock, CAT, fecha, avisoSesion } from '../../api.js';
import { exportarTabla } from '../reportes/_montos.js';
import { sesion } from '../../app.js';

const EJEMPLO = [
  { id: 1, numero: '00100001020000000001', cliente_nombre: 'Soluciones Tecnológicas Alfa S.A.', fecha: '2026-08-20', codigo_ref: '10', moneda: 'CRC', total: 18080, por_aplicar: 0, emision: 'Aceptada', estado: 'Cobrada', razon: 'Intereses por mora sobre la factura 00100001010000000011' },
  { id: 2, numero: '00100001020000000002', cliente_nombre: 'Distribuidora La Central S.A.', fecha: '2026-09-08', codigo_ref: '02', moneda: 'CRC', total: 33900, por_aplicar: 33900, emision: 'Aceptada', estado: 'Por cobrar', razon: 'Cargo por flete no incluido en la factura 00100001010000000012' },
  { id: 3, numero: '00100001020000000003', cliente_nombre: 'Consultores Asociados de Heredia S.A.', fecha: '2026-09-29', codigo_ref: '10', moneda: 'CRC', total: 5650, por_aplicar: 5650, emision: 'Enviada', estado: 'Por cobrar', razon: 'Diferencia de precio por error de digitación' },
];

export default {
  props: ['params'],
  data() { return { ejemplo: [], docs: [], q: '', detalle: null, enviarDoc: null }; },
  computed: {
    rows() {
      const reales = this.docs.filter(d => d.tipo_documento === '02').map(d => ({
        id: 'r' + d.id, real: d, numero: d.consecutivo, cliente_nombre: d.receptor_nombre || '—', fecha: d.fecha_emision, codigo_ref: d.referencia_codigo || '', moneda: d.moneda, total: d.total,
        por_aplicar: d.estado === 'rechazado' ? 0 : d.total, emision: this.emision(d), estado: d.estado === 'rechazado' ? 'Anulada' : 'Por cobrar',
      }));
      return [...reales, ...this.ejemplo].sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.detalle = r },
        { key: 'cliente_nombre', label: 'Cliente' },
        { key: 'fecha', label: 'Fecha', fmt: 'date' },
        { key: 'codigo_ref', label: 'Tipo', fmt: v => CAT.codigoRef[v] || 'Nota de débito' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'por_aplicar', label: 'Por cobrar', num: true, fmt: 'money' },
        { key: 'emision', label: 'Estado de emisión', fmt: 'badge' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    exportarCSV() { const cols = this.columns.filter(c => c.key).map(c => ({ ...c, csv: c.fmt === 'date' ? v => fecha(v) : (c.fmt === 'money' ? v => +v || 0 : undefined) })); exportarTabla('notas_debito', cols, this.rows, { titulo: 'Notas de débito' }); },   // (R261) en methods: como computed se ejecutaba solo al abrir la pantalla
    money,
    emision(d) { return { generado: 'Sin emitir', firmado: 'Firmada', enviado: 'Enviada', aceptado: 'Aceptada', interno: 'Interna', rechazado: 'Rechazada', error: 'Error' }[d.estado] || d.estado; },
    async cargar() { try { this.docs = await api('/api/comprobantes'); } catch (e) { toast(e.message, 'err'); } },
    async consultar(d) { try { const r = await api(`/api/comprobantes/${d.id}/consultar`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, r.estado === 'rechazado' ? 'err' : 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    cobrar(r) { const x = this.ejemplo.find(x => x.id === r.id); if (!x) return; x.por_aplicar = 0; x.estado = 'Cobrada'; mock.set('notas-debito', this.ejemplo); toast('Nota de débito marcada como cobrada', 'ok'); },
    eliminar(r) { if (!confirm(`¿Eliminar la nota de débito ${r.numero}?`)) return; this.ejemplo = this.ejemplo.filter(x => x.id !== r.id); mock.set('notas-debito', this.ejemplo); toast('Nota eliminada', 'ok'); },
    // Acciones masivas. Los comprobantes electrónicos reales (con clave) no se eliminan.
    eliminarVarios(rows) {
      const reales = rows.filter(r => r.real).length, ids = rows.filter(r => !r.real).map(r => r.id);
      this.ejemplo = this.ejemplo.filter(x => !ids.includes(x.id)); mock.set('notas-debito', this.ejemplo);
      toast(`${ids.length} notas eliminadas${reales ? `; ${reales} comprobantes electrónicos omitidos (no se pueden eliminar)` : ''}`, reales ? undefined : 'ok');
    },
    async enviar(d) { try { const r = await api(`/api/comprobantes/${d.id}/enviar`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, ['rechazado', 'error'].includes(r.estado) ? 'err' : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async consultarVarios(rows) {
      const reales = rows.filter(r => r.real && ['enviado', 'aceptado', 'rechazado'].includes(r.real.estado));
      if (!reales.length) return toast('Seleccione comprobantes electrónicos enviados a Hacienda');
      let ok = 0, err = 0;
      for (const r of reales) { try { await api(`/api/comprobantes/${r.real.id}/consultar`, { method: 'POST' }); ok++; } catch (e) { err++; } }
      toast(`Consulta: ${ok} correctos${err ? `, ${err} con error` : ''}`, err ? 'err' : 'ok'); this.cargar();
    },
    bulk() {
      return [
        ...(this.ejemplo.length ? [{ label: 'Registrar cobro', kind: 'sec', handler: rows => { let n = 0; for (const r of rows) { const x = this.ejemplo.find(x => x.id === r.id); if (x && x.por_aplicar > 0) { x.por_aplicar = 0; x.estado = 'Cobrada'; n++; } } mock.set('notas-debito', this.ejemplo); toast(`${n} notas marcadas como cobradas`, 'ok'); } }] : []),   // solo para notas de ejemplo
        { label: '↻ Consultar estado', kind: 'sec', handler: rows => this.consultarVarios(rows) },
        { label: '⎙ Descargar PDFs', kind: 'sec', handler: rows => rows.filter(r => r.real).forEach((r, i) => setTimeout(() => !avisoSesion.mensaje && window.open(`/api/comprobantes/${r.real.id}/pdf`, '_blank'), i * 300)) },
      ];
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Notas de débito" sub="Documentos que aumentan el saldo de una factura de venta: intereses, cargos adicionales o correcciones.">
      <span class="badge primary">Versión 4.4</span>
      <button class="btn ghost" @click="exportarCSV">⤓ Exportar</button>
      <a class="btn" v-if="puede('facturar')" href="#/ventas/notas-debito/nueva">+ Nueva nota de débito</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"><button class="btn ghost sm">⚲ Filtro</button></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('facturar')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado notas de débito" empty-text="Emita una nota de débito electrónica para agregar cargos a una factura ya emitida.">
        <template #actions="{row}">
          <template v-if="row.real">
            <a class="btn icon" :href="'/api/comprobantes/'+row.real.id+'/pdf'" target="_blank" title="PDF">⎙</a>
            <a class="btn icon" :href="'/api/comprobantes/'+row.real.id+'/xml'" target="_blank" title="XML">{ }</a>
            <button class="btn icon" v-if="row.real.estado==='aceptado' && puede('facturar')" @click.stop="enviarDoc=row.real" :title="row.real.correo_enviado ? 'Reenviar por correo' : 'Enviar por correo'">✉</button>
            <span class="small muted" v-if="row.real.estado==='aceptado' && !row.real.correo_enviado && row.real.cliente_id && sesion.empresaInfo?.correo_en_nube" title="El correo al cliente lo envía la nube cuando este comprobante sube">Correo por la nube</span>
            <button class="btn sm" v-if="['firmado','error'].includes(row.real.estado)" @click.stop="enviar(row.real)" title="Enviar (o reenviar) a Hacienda">⇪ Enviar</button>
            <button class="btn sm sec" v-if="['enviado','aceptado','rechazado'].includes(row.real.estado)" @click.stop="consultar(row.real)">Consultar</button>
          </template>
          <template v-else>
            <button class="btn sm sec" v-if="row.por_aplicar>0" @click.stop="cobrar(row)">Registrar cobro</button>
            <button class="btn icon danger" v-if="puede('facturar')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
          </template>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/notas-debito/nueva">+ Nueva nota de débito</a></template>
      </DataTable>
    </div>
    <Modal v-if="detalle" :title="'Nota de débito '+detalle.numero" @close="detalle=null">
      <div class="grid cols-2">
        <div><div class="small muted">Cliente</div><b>{{detalle.cliente_nombre}}</b></div>
        <div><div class="small muted">Fecha</div><b>{{fecha(detalle.fecha)}}</b></div>
        <div><div class="small muted">Tipo</div><b>{{CAT.codigoRef[detalle.codigo_ref] || '—'}}</b></div>
        <div><div class="small muted">Estado de emisión</div><Badge :value="detalle.emision"></Badge></div>
        <div style="grid-column:1/-1" v-if="detalle.razon || detalle.real?.mensaje_hacienda"><div class="small muted">{{detalle.real ? 'Hacienda' : 'Razón'}}</div>{{detalle.razon || detalle.real.mensaje_hacienda}}</div>
        <div style="grid-column:1/-1" v-if="detalle.real"><div class="small muted">Clave</div><span class="mono">{{detalle.real.clave}}</span></div>
      </div>
      <div class="totals"><div><span>Por cobrar</span><b>{{money(detalle.por_aplicar, detalle.moneda)}}</b></div><div class="total"><span>Total</span><b>{{money(detalle.total, detalle.moneda)}}</b></div></div>
      <template #foot><button class="btn ghost" @click="detalle=null">Cerrar</button></template>
    </Modal>
    <EnviarCorreo v-if="enviarDoc" :doc="enviarDoc" @close="enviarDoc=null" @enviado="enviarDoc=null; cargar()"></EnviarCorreo>
  </div>`,
  setup() { return { CAT, sesion }; },
};
