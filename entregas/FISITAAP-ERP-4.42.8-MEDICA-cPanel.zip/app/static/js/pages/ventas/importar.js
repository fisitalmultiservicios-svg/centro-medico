// Ingresos › Importar facturas de otro sistema (3.27): las facturas, tiquetes y notas que la empresa ya emitió en su sistema
// anterior (Alegra u otro) se traen desde sus XML firmados. Quedan como históricas: no se reenvían a Hacienda, no mueven
// inventario, no cuentan en el plan ni generan asientos; la numeración sigue después de la última importada.
import { api, toast, money, fecha } from '../../api.js';
import { store, sesion } from '../../app.js';

const NOMBRE_TIPO = { '01': 'Facturas', '02': 'Notas de débito', '03': 'Notas de crédito', '04': 'Tiquetes', '09': 'Facturas de exportación' };

export default {
  props: ['params'],
  data() { return { archivos: [], listado: null, credito: 'pendientes', origen: 'Alegra', subiendo: false, res: null }; },
  computed: {
    puede() { return sesion.puede('configurar'); },
    peso() { return this.archivos.reduce((s, f) => s + f.size, 0); },
  },
  methods: {
    money, fecha,
    elegir(ev) { const fs = [...(ev.target.files || ev.dataTransfer?.files || [])].filter(f => /\.(xml|zip)$/i.test(f.name)); this.archivos = [...this.archivos, ...fs]; if (ev.target) ev.target.value = ''; },
    elegirListado(ev) { const f = (ev.target.files || [])[0]; this.listado = f && /\.(xlsx|xlsm|csv|txt)$/i.test(f.name) ? f : null; if (f && !this.listado) toast('El listado debe ser Excel (.xlsx) o CSV', 'err'); },
    quitar(i) { this.archivos.splice(i, 1); },
    tam(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; },
    nombreTipo(t) { return NOMBRE_TIPO[t] || t; },
    async importar() {
      if (!this.archivos.length) return toast('Elija los XML o el ZIP del sistema anterior', 'err');
      if (!confirm('Se registrarán como comprobantes ya emitidos (no se envían a Hacienda). ¿Continuar?')) return;
      const fd = new FormData();
      for (const f of this.archivos) fd.append('archivos', f, f.name);
      if (this.listado) fd.append('listado', this.listado, this.listado.name);
      fd.append('credito', this.credito); fd.append('origen', this.origen || 'Sistema anterior');
      this.subiendo = true; this.res = null;
      try { this.res = await api('/api/comprobantes/importar', { method: 'POST', body: fd }); this.archivos = []; toast(this.res.importados + ' comprobante(s) importados', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
  },
  template: `
  <div class="page">
    <PageHead title="Importar facturas de otro sistema" sub="Traiga las facturas, tiquetes y notas que ya emitió en su sistema anterior para tener aquí su historial, sus clientes y lo que falta cobrar." :crumbs="[{label:'Ingresos'},{label:'Facturas de venta', to:'#/ventas/facturas'},{label:'Importar'}]"></PageHead>
    <div class="alert warn" v-if="!puede">Solo quien configura la empresa puede importar comprobantes.</div>
    <template v-else>
    <div class="grid cols-2" style="align-items:start">
      <div class="card">
        <h2>1. Los XML firmados <small>obligatorio</small></h2>
        <p class="small muted" style="margin:0 0 8px">Descargue de su sistema anterior los XML de los comprobantes (el «XML firmado» de cada factura; si también tiene la «respuesta de Hacienda», súbala junto: así queda el estado exacto). Puede subir los XML sueltos o en uno o varios ZIP.</p>
        <label class="drop" style="display:block" @dragover.prevent @drop.prevent="elegir">
          <input type="file" multiple accept=".xml,.zip" style="display:none" @change="elegir">
          <span>Arrastre aquí los XML o ZIP, o haga clic para elegirlos</span>
        </label>
        <div v-if="archivos.length" style="margin-top:8px;max-height:180px;overflow:auto">
          <div v-for="(f, i) in archivos" :key="i" class="row small" style="justify-content:space-between;padding:3px 0;border-bottom:1px solid var(--line)"><span>{{f.name}}</span><span class="muted">{{tam(f.size)}} <a class="link" style="cursor:pointer;margin-left:6px" @click="quitar(i)">quitar</a></span></div>
        </div>
        <p class="small" v-if="archivos.length" style="margin:6px 0 0"><b>{{archivos.length}}</b> archivo(s) · {{tam(peso)}}</p>
      </div>
      <div class="card">
        <h2>2. Lo que falta cobrar <small>opcional, recomendado</small></h2>
        <p class="small muted" style="margin:0 0 8px">El XML no dice si la factura ya se cobró. Suba el listado de facturas exportado del sistema anterior (Excel o CSV) con las columnas <b>Número</b> y <b>Por cobrar</b> (o «Saldo»); si trae <b>Vencimiento</b>, también se toma.</p>
        <input type="file" accept=".xlsx,.xlsm,.csv,.txt" @change="elegirListado">
        <p class="small" v-if="listado" style="margin:6px 0 0">Listado: <b>{{listado.name}}</b></p>
        <div style="margin-top:10px" v-if="!listado">
          <div class="small muted" style="margin-bottom:4px">Sin listado, las facturas de contado quedan cobradas. Las de crédito:</div>
          <label class="row small" style="gap:6px;cursor:pointer"><input type="radio" value="pendientes" v-model="credito"> Quedan por cobrar (podrá registrar los cobros después)</label>
          <label class="row small" style="gap:6px;cursor:pointer;margin-top:4px"><input type="radio" value="cobradas" v-model="credito"> Se marcan cobradas</label>
        </div>
        <Field label="Nombre del sistema anterior" help="Queda anotado en cada comprobante importado" style="margin-top:10px"><input v-model="origen" maxlength="40"></Field>
      </div>
    </div>
    <div class="card" style="margin-top:12px">
      <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <p class="small muted" style="margin:0;max-width:760px">Se importan facturas, tiquetes, notas de crédito y débito y facturas de exportación emitidas con la cédula de esta empresa. Quedan como ya emitidas: no se envían a Hacienda, no rebajan inventario, no cuentan en el plan ni generan asientos contables. Los clientes que no existan se crean con los datos del XML. Si sube el mismo comprobante dos veces, no se duplica. La numeración sigue después del último consecutivo importado.</p>
        <button class="btn" @click="importar" :disabled="subiendo || !archivos.length">{{subiendo ? 'Importando…' : 'Importar'}}</button>
      </div>
    </div>
    <div class="card" v-if="res" style="margin-top:12px">
      <h2>Resultado</h2>
      <div class="alert warn" v-if="res.importados && res.ambiente_empresa !== 'produccion'">La empresa está en el ambiente de pruebas: los comprobantes importados son reales y quedaron en producción. Los verá en las listas cuando la empresa pase a producción.</div>
      <div class="dash" style="gap:10px;margin:0 0 10px">
        <div class="kpi w3" style="margin:0"><div class="t">Importados</div><div class="v">{{res.importados}}</div><div class="d" v-if="res.desde">{{fecha(res.desde)}} al {{fecha(res.hasta)}}</div></div>
        <div class="kpi w3" style="margin:0"><div class="t">Ya estaban</div><div class="v">{{res.duplicados}}</div></div>
        <div class="kpi w3" style="margin:0"><div class="t">Clientes nuevos</div><div class="v">{{res.clientes_nuevos}}</div></div>
        <div class="kpi w3" style="margin:0"><div class="t">Quedan por cobrar</div><div class="v">{{res.por_cobrar}}</div><div class="d"><span v-for="(m, k) in res.monto_por_cobrar" :key="k" style="margin-right:6px">{{money(m, k)}}</span></div></div>
      </div>
      <div class="small" v-if="Object.keys(res.por_tipo).length">Por tipo: <span v-for="(n, t) in res.por_tipo" :key="t" style="margin-right:10px">{{nombreTipo(t)}} <b>{{n}}</b></span></div>
      <div class="small" v-if="res.respuestas">Respuestas de Hacienda guardadas: <b>{{res.respuestas}}</b></div>
      <div class="small" v-if="res.listado !== null && res.listado !== undefined">Facturas leídas del listado: <b>{{res.listado}}</b></div>
      <details v-if="res.descartados.length" style="margin-top:8px"><summary class="small" style="cursor:pointer">{{res.descartados.length}} archivo(s) no se importaron</summary><ul class="small" style="margin:6px 0 0;padding-left:18px"><li v-for="(x, i) in res.descartados" :key="i">{{x}}</li></ul></details>
      <div class="row" style="gap:8px;margin-top:10px"><a class="btn sec" href="#/ventas/facturas">Ver las facturas</a><a class="btn ghost" href="#/configuracion/numeraciones">Revisar la numeración</a></div>
    </div>
    </template>
  </div>`,
};
