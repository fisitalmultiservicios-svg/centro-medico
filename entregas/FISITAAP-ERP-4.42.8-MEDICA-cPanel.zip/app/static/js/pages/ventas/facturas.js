// Facturas de venta — lista (backend real: /api/comprobantes). Botón "Pagada" al pasar el mouse por una factura por cobrar:
// abre el registro del pago con todo precargado (monto = saldo, transferencia/depósito, cuenta bancaria en la moneda de la factura).
import { api, toast, money, fmt, fecha, hoy, CAT, opts, monedas, avisoSesion, mock } from '../../api.js';
import { cuentaPrincipal, cuentaParaMedio, cuentasParaMovimientos, problemaMoneda, avisoConversion } from '../bancos/cuentas.js';   // 4.5: cuentaParaMedio: el medio decide la cuenta
import { sesion } from '../../app.js';
import { exportarTabla } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() { return { enviarDoc: null, docs: [], borradores: [], q: '', cargando: true, menu: false, ocupado: false, hac: null, pendientes: [], pago: null, guardandoPago: false, CAT, opts, cuentasApi: null, compartir: null }; },
  computed: {
    rows() {
      // los borradores (guardados sin emitir) van primero: sin número, sin estado de Hacienda y sin cobro
      const bor = this.borradores.filter(b => ['01', '04', '09'].includes(b.tipo_documento)).map(b => ({ ...b, id: 'b' + b.id, borrador_id: b.id, consecutivo: 'Borrador', fecha_emision: b.actualizado || b.creado,
        receptor_nombre: b.receptor_nombre || (b.tipo_documento === '04' ? 'Tiquete (sin receptor)' : '—'), estado: 'borrador', estado_cobro: 'Borrador', por_cobrar: 0, emision: 'Borrador (sin emitir)', pagado: 0 }));
      return [...bor, ...this.docs.filter(d => ['01', '04', '09', '02'].includes(d.tipo_documento)).map(d => {   // la nota de débito al cliente también se cobra aquí (R183)
        const saldo = this.saldo(d);
        const acreditada = (d.acreditado || 0) > 0.005;
        const credito = ['02', '08', '10'].includes(d.condicion_venta);
        const estado_cobro = d.estado === 'rechazado' ? 'Anulada' : saldo <= 0.005 ? (acreditada && !(d.pagado > 0.005) ? 'Acreditada' : 'Cobrada') : ((d.pagado > 0 || acreditada) ? 'Cobro parcial' : (credito ? 'Por cobrar' : 'Contado sin registrar cobro'));   // (R184)
        return { ...d, estado_cobro, por_cobrar: d.estado === 'rechazado' ? 0 : saldo, emision: this.emision(d) };
      })];
    },
    columns() {
      return [
        { key: 'consecutivo', label: 'Número', mono: true, link: r => location.hash = r.estado === 'borrador' ? '/ventas/facturas/nueva?borrador=' + r.borrador_id : '/ventas/facturas/' + r.id },
        { key: 'receptor_nombre', label: 'Cliente', fmt: v => v || 'Tiquete (sin receptor)' },
        { key: 'fecha_emision', label: 'Creación', fmt: 'date' },
        { key: 'fecha_vencimiento', label: 'Vencimiento', fmt: 'date' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'emision', label: 'Estado de emisión', fmt: 'badge' },
        { key: 'por_cobrar', label: 'Por cobrar', num: true, fmt: 'money' },
        { key: 'estado_cobro', label: 'Estado', fmt: 'badge' },
      ];
    },
    // Cuentas de Bancos en la moneda de la factura (bancos primero); si no hay ninguna en esa moneda, todas.
    cuentasPago() {
      if (!this.pago) return [];
      const todas = this.cuentasBancos();
      // primero las cuentas en la moneda de la factura y después las de colones (un pago en dólares depositado en colones se
      // convierte con el tipo de cambio); si no hay ninguna de esas, todas
      const m = this.pago.doc.moneda || 'CRC', grupo = b => ((b.moneda || 'CRC') === m ? 0 : (b.moneda || 'CRC') === 'CRC' ? 1 : 2);
      const sirven = todas.filter(b => grupo(b) < 2), lista = sirven.length ? sirven : todas;
      const efectivo = this.pago.f.medio_pago === '01', ef = b => ((b.tipo === 'Efectivo') === efectivo ? 0 : 1);
      return lista.slice().sort((a, b) => grupo(a) - grupo(b) || ef(a) - ef(b));
    },
    sinCuentaEnMoneda() { return this.pago && !this.cuentasBancos().some(b => (b.moneda || 'CRC') === this.pago.doc.moneda); },
    sinBancos() { return !(this.cuentasApi || []).length; },
    problemaPago() { return this.pago ? problemaMoneda(this.pago.f.cuenta, this.pago.doc.moneda, this.pago.f.tipo_cambio, this.cuentasApi || []) : ''; },
    avisoPago() { return this.pago ? avisoConversion(this.pago.f.cuenta, this.pago.f.monto, this.pago.doc.moneda, this.pago.f.tipo_cambio, this.cuentasApi || []) : ''; },
    pagoEsRep() { return this.pago && ['10', '08'].includes(this.pago.doc.condicion_venta) && this.pago.doc.estado === 'aceptado'; },
  },
  watch: {
    // 4.5: al cambiar el medio del cobro rápido («Pagada»), la cuenta propuesta lo sigue: efectivo → cuenta de Efectivo; tarjeta, SINPE o transferencia → Banco
    'pago.f.medio_pago'(m) { if (!this.pago) return; const b = cuentaParaMedio(m, this.pago.doc.moneda, this.cuentasBancos()); if (b) this.pago.f.cuenta = b.nombre; },
  },
  methods: {
    // la lista tal como se ve (R261). 4.17: en methods; como computed se ejecutaba sola al abrir «Más acciones»
    exportar() {
      const cols = this.columns.filter(c => c.key && c.key !== 'acciones').map(c => ({ ...c, csv: c.fmt === 'date' ? v => fecha(v) : (c.fmt === 'money' ? v => +v || 0 : undefined) }));
      const i = cols.findIndex(c => c.key === 'total');   // IVA y otros cargos (impuesto de servicio, timbres) junto al total
      cols.splice(i < 0 ? cols.length : i, 0, { key: 'moneda', label: 'Moneda' }, { key: 'impuesto', label: 'IVA', csv: v => +v || 0 }, { key: 'otros_impuestos', label: 'Otros impuestos', csv: v => +v || 0 }, { key: 'total_otros_cargos', label: 'Otros cargos', csv: v => +v || 0 });
      exportarTabla('facturas', cols, this.rows.filter(r => r.estado !== 'borrador'), { titulo: 'Facturas de venta' });
    },
    money, fmt,
    // lo que falta cobrar: total − cobros − notas de crédito aceptadas
    saldo(d) { return Math.max(0, Math.round(((d.total || 0) - (d.pagado || 0) - (d.acreditado || 0)) * 100) / 100); },
    // Cuentas de Bancos › Cuentas; si no hay ninguna, nombres genéricos (igual que Pagos recibidos) en la moneda principal.
    cuentasBancos() {
      const reales = this.cuentasApi || [];
      if (reales.length) return reales;
      const p = monedas.principal().codigo;
      return [{ id: 'g1', nombre: 'Banco Nacional', tipo: 'Banco', moneda: p }, { id: 'g2', nombre: 'Banco De Costa Rica', tipo: 'Banco', moneda: p }, { id: 'g3', nombre: 'BAC Credomatic', tipo: 'Banco', moneda: p }, { id: 'g4', nombre: 'Caja general', tipo: 'Efectivo', moneda: p }];
    },
    emision(d) { return ({ generado: 'Sin emitir', interno: 'Interna', firmado: 'Firmada', enviado: 'Enviada', aceptado: 'Aceptada', rechazado: 'Rechazada', error: 'Error' }[d.estado] || d.estado) + (d.ambiente === 'sandbox' && d.estado !== 'interno' ? ' (pruebas)' : '') + (d.importado_de ? ' · ' + d.importado_de : ''); },   // importada de otro sistema (3.27)
    async anular(d) {
      if (!confirm(`¿Anular ${d.consecutivo}? ${d.estado === 'interno' ? 'Es un comprobante interno' : 'No fue aceptado por Hacienda'}: queda anulado y el inventario que descontó se devuelve.`)) return;
      try { await api('/api/comprobantes/' + d.id + '/anular', { method: 'POST' }); toast('Comprobante anulado', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async eliminarBorrador(b) {
      if (!confirm('¿Eliminar este borrador? No se ha emitido nada, así que no queda rastro en Hacienda.')) return;
      try { await api('/api/borradores/' + b.borrador_id, { method: 'DELETE' }); toast('Borrador eliminado'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async cargar() {
      this.cargando = true;
      try { this.docs = await api('/api/comprobantes'); try { this.borradores = await api('/api/borradores'); } catch { this.borradores = []; } } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
      // Cola de Hacienda en segundo plano: envía lo firmado pendiente y consulta lo enviado (si Hacienda responde).
      if (this.docs.some(d => ['firmado', 'enviado'].includes(d.estado))) {
        try {
          const r = await api('/api/comprobantes/procesar-pendientes', { method: 'POST' });
          if ((r.enviados || 0) + (r.aceptados || 0) + (r.rechazados || 0)) {
            try { this.docs = await api('/api/comprobantes'); } catch {}
            toast(`Hacienda: ${r.enviados} enviado(s), ${r.aceptados} aceptado(s), ${r.rechazados} rechazado(s)`, r.rechazados ? 'err' : 'ok');
          }
        } catch {}
      }
      try { this.hac = await api('/api/hacienda/estado'); } catch { this.hac = null; }
      try { this.pendientes = await api('/api/recurrentes/pendientes'); } catch { this.pendientes = []; }
    },
    // ---- cobro rápido: "Pagada" sobre una factura por cobrar
    async abrirPago(d) {
      if (!this.cuentasApi) this.cuentasApi = await cuentasParaMovimientos();
      const m = monedas.get(d.moneda);
      const cuentas = this.cuentasBancos();
      const preferida = cuentaParaMedio('04', d.moneda, this.cuentasApi) || cuentas.find(b => (b.moneda || 'CRC') === d.moneda && b.tipo === 'Banco') || cuentas.find(b => (b.moneda || 'CRC') === d.moneda) || null;   // 4.5: el medio decide la cuenta (transferencia → Banco)
      // una venta con condición 10 u 08 se cobra con REP, y el REP solo existe cuando Hacienda aceptó la factura: antes se podía
      // registrar un recibo de caja y después el REP ya no tenía saldo (R99)
      if (['10', '08'].includes(d.condicion_venta) && d.tipo_documento !== '04' && !['aceptado', 'interno'].includes(d.estado)) return toast('Esta venta a crédito se cobra con un recibo electrónico de pago: espere a que Hacienda acepte la factura (estado ' + d.estado + ') y registre el cobro entonces', 'err');
      this.pago = { doc: d, f: { fecha: hoy(), medio_pago: '04', cuenta: preferida ? preferida.nombre : '', monto: this.saldo(d), tipo_cambio: +d.tipo_cambio > 1 ? +d.tipo_cambio : monedas.tc(d.moneda), notas: '', rep: sesion.electronica && ['10', '08'].includes(d.condicion_venta) && d.estado === 'aceptado' && d.tipo_documento !== '04' } };   // 3.87: interna o sin facturación electrónica, recibo de caja
    },
    async guardarPago() {
      const { doc: d, f } = this.pago;
      if (!f.cuenta) return toast('Seleccione la cuenta donde recibió el dinero', 'err');
      { const pm = problemaMoneda(f.cuenta, d.moneda, f.tipo_cambio, this.cuentasApi || []); if (pm) return toast(pm, 'err'); }
      if (!(+f.monto > 0)) return toast('El monto recibido debe ser mayor a cero', 'err');
      if (+f.monto > this.saldo(d) + 0.005) return toast('El monto supera el saldo de la factura (' + money(this.saldo(d), d.moneda) + ')', 'err');
      if (f.rep && !f.notas.trim()) return toast('El recibo electrónico de pago necesita una razón (por ejemplo: pago de la factura)', 'err');
      if (f.medio_pago === '99' && (f.medio_pago_otros || '').trim().length < 3) return toast('Con el medio de pago «Otros» describa cuál es (mínimo 3 caracteres)', 'err');
      this.guardandoPago = true;
      try {
        const body = { tipo: f.rep ? 'rep' : 'caja', cliente_id: d.cliente_id || null, detalles: 'Factura ' + d.consecutivo, fecha: f.fecha, cuenta: f.cuenta, condicion_venta: d.condicion_venta || '01',
                       medio_pago: f.medio_pago, medio_pago_otros: f.medio_pago === '99' ? (f.medio_pago_otros || '').trim() : null, moneda: d.moneda, tipo_cambio: +f.tipo_cambio || 1, monto: +f.monto, notas: f.notas, facturas: [{ id: d.id, monto: +f.monto }] };
        const p = await api('/api/pagos', { method: 'POST', body });
        if (f.rep) for (const r of (p.rep || [])) toast(`REP ${r.consecutivo}: ${r.estado}${r.mensaje ? ' · ' + r.mensaje : ''}`, ['rechazado', 'error'].includes(r.estado) ? 'err' : 'ok');
        toast(`Pago de ${money(+f.monto, d.moneda)} registrado para la factura ${d.consecutivo}` + (+f.monto < this.saldo(d) - 0.005 ? ' (cobro parcial)' : '') + ' · recibo #' + p.numero, 'ok');
        this.pago = null;
        await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardandoPago = false;
    },
    async accion(d, a) {
      if (this.ocupado) return;             // evita el doble clic (dos envíos de la misma clave)
      this.ocupado = true;
      try { const r = await api(`/api/comprobantes/${d.id}/${a}`, { method: 'POST' }); toast(`${r.estado}: ${r.mensaje_hacienda || ''}`, r.estado === 'error' || r.estado === 'rechazado' ? 'err' : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
      this.ocupado = false;
    },
    async correo(d) {
      if (!['aceptado', 'interno'].includes(d.estado)) return toast('Solo se envían por correo comprobantes aceptados por Hacienda', 'err');
      this.enviarDoc = d;      /* 3.38: ventana con Para, copia y mensaje */
    },
    // Acciones masivas. Los comprobantes electrónicos no se eliminan: se anulan con nota de crédito.
    async masivo(rows, fn, nombre) {
      if (this.ocupado) return;
      rows = rows.filter(r => r.estado !== 'borrador');    // los borradores no son comprobantes: nada que enviar, consultar ni imprimir
      this.ocupado = true;
      let ok = 0, err = 0;
      for (const r of rows) { try { await fn(r); ok++; } catch (e) { err++; } }
      toast(`${nombre}: ${ok} correctos${err ? `, ${err} con error` : ''}`, err ? 'err' : 'ok');
      this.ocupado = false;
      this.cargar();
    },
    // Compartir: enlace público de consulta (PDF y XML sin iniciar sesión) y mensaje de WhatsApp con la plantilla de la empresa
    async compartirDoc(row) {
      try {
        const r = await api('/api/comprobantes/' + row.id + '/enlace');
        const pl = (mock.get('plantillas_correo', null) || {}).whatsapp || {};
        const clave = { '03': 'nota_credito', '02': 'nota_debito', '10': 'pago_recibido' }[row.tipo_documento] || 'factura';
        const base = (pl[clave] && pl[clave].cuerpo) || 'Hola {{cliente}}, le compartimos el comprobante {{numero}} del {{fecha}} por {{total}}. Gracias por su preferencia. — {{empresa}} {{telefono}}';
        const v = r.variables || {}, texto = base.replace(/\{\{\s*([a-zA-Z_]+)\s*\}\}/g, (m, k) => (v[k] === undefined || v[k] === null ? '' : String(v[k])));
        const tel = String(r.telefono_cliente || '').replace(/\D/g, '');
        this.compartir = { row, url: r.url || '', tel: tel ? (tel.length === 8 ? '506' + tel : tel) : '', mensaje: texto + (r.url && !texto.includes(r.url) ? '\n' + r.url : '') };
      } catch (e) { toast(e.message, 'err'); }
    },
    whatsappUrl() { const c = this.compartir; if (!c) return '#'; const tel = String(c.tel || '').replace(/\D/g, ''); return 'https://wa.me/' + (tel.length === 8 ? '506' + tel : tel) + '?text=' + encodeURIComponent(c.mensaje); },
    async copiar(txt) { try { await navigator.clipboard.writeText(txt); toast('Copiado', 'ok'); } catch { toast('Seleccione y copie el texto a mano'); } },
    bulk() {
      if (!sesion.puede('facturar')) return [];   // acciones masivas solo con permiso (R133)
      return [
        { label: '⇪ Enviar a Hacienda', handler: rows => this.masivo(rows.filter(r => r.estado === 'firmado'), r => api(`/api/comprobantes/${r.id}/enviar`, { method: 'POST' }), 'Envío a Hacienda') },
        { label: '↻ Consultar estado', handler: rows => this.masivo(rows.filter(r => ['enviado', 'aceptado', 'rechazado', 'error'].includes(r.estado)), r => api(`/api/comprobantes/${r.id}/consultar`, { method: 'POST' }), 'Consulta') },
        { label: '✉ Enviar por correo', confirm: '¿Enviar {n} comprobantes aceptados por correo a sus clientes?', handler: rows => this.masivo(rows.filter(r => ['aceptado', 'interno'].includes(r.estado)), r => api(`/api/comprobantes/${r.id}/correo`, { method: 'POST', body: {} }), 'Correos') },
        { label: '⎙ Descargar PDFs', handler: rows => rows.filter(r => r.estado !== 'borrador').forEach((r, i) => setTimeout(() => !avisoSesion.mensaje && window.open(`/api/comprobantes/${r.id}/pdf`, '_blank'), i * 300)) },
      ];
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Facturas de venta" sub="Cree y gestione los documentos que respaldan sus operaciones comerciales.">
      <div style="position:relative"><button class="btn ghost" @click="menu=!menu">Más acciones ▾</button>
        <div v-if="menu" class="card" style="position:absolute;right:0;top:40px;z-index:10;min-width:230px;padding:6px" @click="menu=false">
          <a class="item" v-if="puede('facturar') || puede('pos')" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/ventas/facturas/nueva?tipo=04">Nuevo tiquete de venta</a>
          <a class="item" style="display:block;padding:8px 10px;cursor:pointer" @click="exportar">Exportar</a>
          <a class="item" v-if="puede('configurar')" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/ventas/importar">Importar facturas de otro sistema</a></div></div>
      <a class="btn" v-if="puede('facturar')" href="#/ventas/facturas/nueva">+ Nueva factura de venta</a>
    </PageHead>
    <div class="alert info" v-if="pendientes.length" style="margin-bottom:12px">Hay <b>{{pendientes.length}}</b> factura(s) recurrente(s) pendiente(s) de emitir. <a href="#/ventas/recurrentes">Revisar y emitir</a></div>
    <div class="alert err" v-if="hac && hac.disponible === false && hac.credenciales === false">Hacienda rechaza las credenciales de la empresa: revise Configuración › Facturación electrónica. {{hac.detalle}}</div>
    <div class="alert warn" v-else-if="hac && hac.disponible === false">Hacienda no está respondiendo ({{hac.detalle}}). Puede seguir facturando: {{hac.pendientes_envio}} comprobante(s) firmados esperan envío y {{hac.pendientes_consulta}} esperan respuesta; se procesarán automáticamente en cuanto Hacienda vuelva.</div>
    <div class="alert info" v-else-if="hac && (hac.pendientes_envio || hac.con_error)">{{hac.pendientes_envio}} comprobante(s) en cola de envío<span v-if="hac.con_error"> y {{hac.con_error}} con error que requieren revisión</span>.</div>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('facturar')" :bulk-actions="bulk()" empty-title="Aún no has creado facturas" empty-text="Crea tu primera factura de venta y envíala a Hacienda en segundos.">
        <template #actions="{row}">
          <template v-if="row.estado === 'borrador'">
            <a class="btn sm" v-if="sesion.puede('facturar')" :href="'#/ventas/facturas/nueva?borrador=' + row.borrador_id" @click.stop title="Abrir el borrador para revisarlo y emitirlo">Editar y emitir</a>
            <button v-if="sesion.puede(\'facturar\')" class="btn icon" title="Eliminar borrador" @click.stop="eliminarBorrador(row)">🗑</button>
          </template>
          <template v-else>
          <button class="btn sm hover-only" v-if="row.por_cobrar > 0.005 && row.estado !== 'rechazado' && sesion.puede('cobros')" @click.stop="abrirPago(row)" title="Registrar el pago de esta factura">✓ Pagada</button>
          <button class="btn sm sec" v-if="['generado','interno','error'].includes(row.estado) && sesion.puede('facturar')" @click.stop="anular(row)" title="Anula este comprobante (nunca llegó a Hacienda) y devuelve el inventario">Anular</button>
          <a class="btn icon" :href="'/api/comprobantes/'+row.id+'/pdf'" target="_blank" title="PDF">⎙</a>
          <a class="btn icon" v-if="row.estado!=='interno'" :href="'/api/comprobantes/'+row.id+'/xml'" target="_blank" title="XML">{ }</a>
          <a class="btn icon" v-if="['01','04'].includes(row.tipo_documento) && sesion.puede('facturar')" :href="'#/ventas/facturas/nueva?duplicar=' + row.id" @click.stop title="Duplicar: nueva factura con el mismo cliente y las mismas líneas">⧉</a>
          <button class="btn icon" v-if="['aceptado','interno'].includes(row.estado) && puede('facturar')" @click.stop="correo(row)" :title="row.correo_enviado?'Enviado '+row.correo_enviado:'Enviar por correo'">{{row.correo_enviado?'✉✓':'✉'}}</button>
          <span class="small muted" v-if="row.estado==='aceptado' && !row.correo_enviado && row.cliente_id && sesion.empresaInfo?.correo_en_nube" title="El correo al cliente lo envía la nube cuando este comprobante sube">Correo por la nube</span>
          <button class="btn icon" v-if="!['generado','error'].includes(row.estado) && (puede('facturar') || puede('cobros'))" @click.stop="compartirDoc(row)" title="Compartir: enlace de consulta y WhatsApp">⇪</button>
          <button class="btn sm" v-if="['firmado','error'].includes(row.estado) && (puede('facturar') || puede('pos'))" :disabled="ocupado" @click.stop="accion(row,'enviar')">Enviar a Hacienda</button>
          <button class="btn sm sec" v-if="['enviado','aceptado','rechazado','error'].includes(row.estado) && (puede('facturar') || puede('pos'))" :disabled="ocupado" @click.stop="accion(row,'consultar')">Consultar</button>
          <a class="btn icon" v-if="row.respuesta_nombre" :href="'/api/comprobantes/'+row.id+'/respuesta'" target="_blank" title="Respuesta de Hacienda">✔</a>
          </template>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/facturas/nueva">+ Nueva factura de venta</a></template>
      </DataTable>
    </div>

    <Modal v-if="compartir" :title="'Compartir ' + compartir.row.consecutivo" @close="compartir=null">
      <p class="small muted">El enlace muestra el comprobante (estado, total, PDF y XML) sin iniciar sesión; puede enviarlo por cualquier medio.</p>
      <Field label="Enlace de consulta" v-if="compartir.url"><div class="row" style="gap:8px"><input class="inp mono" :value="compartir.url" readonly style="flex:1" @focus="$event.target.select()"><button class="btn sec" @click="copiar(compartir.url)">Copiar</button></div></Field>
      <div class="alert warn" v-else>No hay una dirección pública configurada para los enlaces; comparta el PDF.</div>
      <Field label="Mensaje de WhatsApp" help="Se edita en Configuración › Plantillas de correo › WhatsApp"><textarea v-model="compartir.mensaje" rows="5"></textarea></Field>
      <Field label="Número de WhatsApp del cliente" help="Con código de país (506 para Costa Rica); vacío abre WhatsApp para elegir el contacto"><input v-model="compartir.tel" class="mono" placeholder="50688888888"></Field>
      <template #foot><button class="btn ghost" @click="compartir=null">Cerrar</button><button class="btn sec" @click="copiar(compartir.mensaje)">Copiar mensaje</button><a class="btn" :href="whatsappUrl()" target="_blank" rel="noopener">Abrir WhatsApp</a></template>
    </Modal>
    <Modal v-if="pago" :title="'Registrar pago · factura ' + pago.doc.consecutivo" @close="pago=null">
      <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:12px">
        <div><div class="small muted">Cliente</div><b>{{pago.doc.receptor_nombre || 'Tiquete (sin receptor)'}}</b></div>
        <div><div class="small muted">Total</div><b>{{money(pago.doc.total, pago.doc.moneda)}}</b></div>
        <div><div class="small muted">Saldo por cobrar</div><b>{{money(saldo(pago.doc), pago.doc.moneda)}}</b></div>
      </div>
      <div class="alert info" v-if="pagoEsRep" style="margin-bottom:10px">Esta factura es a crédito con IVA diferido: el pago genera y envía a Hacienda el recibo electrónico de pago (REP). Indique la razón.</div>
      <div class="alert warn" v-if="sinBancos" style="margin-bottom:10px">Todavía no hay cuentas en Bancos › Cuentas: se usan nombres genéricos. Cree sus cuentas (con su moneda) para que el pago vaya a la cuenta correcta.</div>
      <div class="alert warn" v-else-if="sinCuentaEnMoneda" style="margin-bottom:10px">No hay una cuenta en {{pago.doc.moneda}} en Bancos; elija la cuenta donde recibió el dinero o cree una en Bancos › Cuentas.</div>
      <div class="grid cols-2">
        <Field label="Monto recibido" req :help="'En ' + pago.doc.moneda + '; puede ser menor al saldo (cobro parcial)'"><input type="number" step="0.01" min="0.01" :max="saldo(pago.doc)" v-model.number="pago.f.monto" class="mono" style="font-size:18px"></Field>
        <Field label="Fecha del pago" req><input type="date" v-model="pago.f.fecha"></Field>
        <Field label="Medio de pago" req><select v-model="pago.f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
        <Field label="¿Cuál medio de pago?" req v-if="pago.f.medio_pago==='99'" help="Hacienda exige describirlo (3 a 100 caracteres)"><input v-model="pago.f.medio_pago_otros" maxlength="100"></Field>
        <Field label="Cuenta donde se recibió" req :help="'Por defecto la cuenta principal en ' + pago.doc.moneda + ' (Bancos); puede elegir otra'"><select v-model="pago.f.cuenta"><option value="">— Seleccione —</option><option v-for="b in cuentasPago" :key="b.id" :value="b.nombre">{{b.nombre}} · {{b.moneda || 'CRC'}}{{b.tipo ? ' · ' + b.tipo : ''}}</option></select><div class="small" :class="problemaPago ? 'neg' : 'muted'" v-if="problemaPago || avisoPago" style="margin-top:4px">{{problemaPago || avisoPago}}</div></Field>
        <Field v-if="pago.doc.moneda !== 'CRC'" label="Tipo de cambio" help="El de la factura; cámbielo si el banco aplicó otro"><input type="number" step="0.01" min="0" v-model.number="pago.f.tipo_cambio" class="mono"></Field>
        <Field :label="pagoEsRep ? 'Razón del recibo electrónico' : 'Notas'" :req="pagoEsRep" style="grid-column:1/-1"><input v-model="pago.f.notas" :placeholder="pagoEsRep ? 'Pago de la factura ' + pago.doc.consecutivo : 'Referencia de la transferencia, observaciones…'"></Field>
      </div>
      <template #foot><button class="btn ghost" @click="pago=null">Cancelar</button><button class="btn" :disabled="guardandoPago" @click="guardarPago">{{guardandoPago ? 'Guardando…' : (pagoEsRep ? 'Registrar pago y emitir REP' : 'Registrar pago')}}</button></template>
    </Modal>
    <EnviarCorreo v-if="enviarDoc" :doc="enviarDoc" @close="enviarDoc=null" @enviado="enviarDoc=null; cargar()"></EnviarCorreo>
  </div>`,
  setup() { return { monedas, sesion }; },
};
