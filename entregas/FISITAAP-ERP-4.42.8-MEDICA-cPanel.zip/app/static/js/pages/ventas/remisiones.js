// Remisiones y órdenes de servicio — lista (datos de ejemplo en localStorage: mock 'remisiones'; PDF real con POST /api/pdf/documento)
import { toast, money, mock, fecha } from '../../api.js';
import { exportarTabla } from '../reportes/_montos.js';
import { abrirPdfDocumento, payloadDocumentoVenta } from './cotizaciones.js';

function lin(detalle, cantidad, precio) { return { producto_id: null, detalle, cabys: '', cantidad, precio_unitario: precio, descuento: 0, codigo_tarifa: '08', tarifa: 13 }; }
export const REMISIONES_EJEMPLO = [
  { id: 1, numero: 'REM-0001', tipo: 'Remisión', cliente_id: null, cliente_nombre: 'Ferretería El Progreso S.A.', cliente_cedula: '3-101-678901', fecha: '2026-09-05', vence: '2026-09-20', moneda: 'CRC', estado: 'Facturada', lineas: [lin('Cable UTP Cat6 (rollo 305 m)', 2, 68000), lin('Conectores RJ45 (bolsa 100)', 3, 9500)], notas: 'Entregado en bodega central.', terminos: '' },
  { id: 2, numero: 'REM-0002', tipo: 'Orden de servicio', cliente_id: null, cliente_nombre: 'Soluciones Tecnológicas Alfa S.A.', cliente_cedula: '3-101-456789', fecha: '2026-09-18', vence: '2026-09-30', moneda: 'CRC', estado: 'Sin facturar', lineas: [lin('Visita técnica de diagnóstico', 1, 25000), lin('Horas de soporte en sitio', 4, 18000)], notas: 'Atendido por: Luis Araya.', terminos: '' },
  { id: 3, numero: 'REM-0003', tipo: 'Remisión', cliente_id: null, cliente_nombre: 'Comercializadora Del Valle Ltda.', cliente_cedula: '3-102-567890', fecha: '2026-10-01', vence: '2026-10-15', moneda: 'CRC', estado: 'Sin facturar', lineas: [lin('Impresora multifuncional láser', 1, 215000)], notas: 'Pendiente de firma de recibido.', terminos: '' },
];

export default {
  props: ['params'],
  data() { return { lista: mock.ejemplos('remisiones', REMISIONES_EJEMPLO, 'numero'), q: '', detalle: null }; },
  computed: {
    rows() { return this.lista.map(c => ({ ...c, total: this.total(c) })).sort((a, b) => b.id - a.id); },
    columns() {
      return [
        { key: 'numero', label: 'Número', mono: true, link: r => this.detalle = r },
        { key: 'cliente_nombre', label: 'Cliente' },
        { key: 'tipo', label: 'Tipo' },
        { key: 'fecha', label: 'Creación', fmt: v => v ? fecha(v) : '' },
        { key: 'total', label: 'Total', num: true, fmt: 'money' },
        { key: 'estado', label: 'Estado', fmt: 'badge' },
      ];
    },
  },
  methods: {
    exportar() { exportarTabla('remisiones', this.columns, this.rows, { titulo: 'Remisiones' }); },   // 4.17
    money,
    total(c) { return (c.lineas || []).reduce((s, l) => s + this.lt(l), 0); },
    lt(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0); return m + m * ((+l.tarifa || 0) - (+l.tarifa_exonerada || 0)) / 100; },   // menos la exoneración guardada
    // la remisión queda «Facturada» cuando la factura se emite (factura-form la marca con el número); antes se marcaba al abrir el formulario (R51)
    facturar(r) { location.hash = '/ventas/facturas/nueva?remision=' + r.id; },
    async imprimir(r, descargar) { try { await abrirPdfDocumento(payloadDocumentoVenta(r, 'remision'), descargar ? r.numero + '.pdf' : null); } catch (e) { toast(e.message, 'err'); } },
    eliminar(r) { if (!confirm(`¿Eliminar ${r.numero}?`)) return; this.lista = this.lista.filter(x => x.id !== r.id); mock.set('remisiones', this.lista); toast('Remisión eliminada', 'ok'); },
    eliminarVarios(rows) { const ids = rows.map(r => r.id); this.lista = this.lista.filter(x => !ids.includes(x.id)); mock.set('remisiones', this.lista); toast(`${ids.length} remisiones eliminadas`, 'ok'); },
    facturarVarios(rows) { let n = 0; for (const r of rows) { const x = this.lista.find(x => x.id === r.id); if (x && x.estado === 'Sin facturar') { x.estado = 'Facturada'; n++; } } mock.set('remisiones', this.lista); toast(`${n} remisiones marcadas como facturadas`, n ? 'ok' : undefined); },
    bulk() { return [{ label: 'Marcar como facturadas', kind: 'sec', confirm: '¿Marcar {n} remisiones como facturadas?', handler: rows => this.facturarVarios(rows) }]; },
  },
  template: `
  <div class="page">
    <PageHead title="Remisiones" sub="Registre entregas de mercadería y órdenes de servicio antes de facturarlas.">
      <button class="btn ghost" @click="exportar">Exportar</button>
      <a class="btn" v-if="puede('facturar')" href="#/ventas/remisiones/nueva">+ Nueva remisión</a>
    </PageHead>
    <div class="card pad0">
      <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar cliente o número" v-model="q"><button class="btn ghost sm">⚲ Filtrar</button></div>
      <DataTable :rows="rows" :columns="columns" :search="q" :selectable="puede('facturar')" :bulk-actions="bulk()" :on-bulk-delete="eliminarVarios" empty-title="Aún no has creado remisiones" empty-text="Cree una remisión u orden de servicio para documentar una entrega pendiente de facturar.">
        <template #actions="{row}">
          <button class="btn icon" @click.stop="detalle=row" title="Ver">👁</button>
          <a class="btn icon" v-if="puede('facturar')" :href="'#/ventas/remisiones/nueva?duplicar=' + row.id" @click.stop title="Duplicar: nueva remisión con las mismas líneas">⧉</a>
          <button class="btn sm sec" v-if="row.estado==='Sin facturar'" @click.stop="facturar(row)">Facturar</button>
          <button class="btn icon" @click.stop="imprimir(row)" title="Ver PDF">⎙</button>
          <button class="btn icon danger" v-if="puede('facturar')" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
        <template #empty><a class="btn" v-if="puede('facturar')" href="#/ventas/remisiones/nueva">+ Nueva remisión</a></template>
      </DataTable>
    </div>
    <Modal v-if="detalle" :title="detalle.tipo+' '+detalle.numero" lg @close="detalle=null">
      <div class="grid cols-3">
        <div><div class="small muted">Cliente</div><b>{{detalle.cliente_nombre}}</b><div class="small muted">{{detalle.cliente_cedula}}</div></div>
        <div><div class="small muted">Creación</div><b>{{fecha(detalle.fecha)}}</b></div>
        <div><div class="small muted">Estado</div><Badge :value="detalle.estado"></Badge></div>
      </div>
      <div class="table-wrap" style="margin-top:12px"><table class="tbl">
        <thead><tr><th>Ítem</th><th class="num">Cant.</th><th class="num">Precio</th><th class="num">IVA</th><th class="num">Total</th></tr></thead>
        <tbody><tr v-for="(l,i) in detalle.lineas" :key="i"><td>{{l.detalle}}</td><td class="num">{{l.cantidad}}</td><td class="num">{{money(l.precio_unitario, detalle.moneda)}}</td><td class="num">{{l.tarifa}} %</td><td class="num">{{money(lt(l), detalle.moneda)}}</td></tr></tbody>
      </table></div>
      <div class="totals"><div class="total"><span>Total</span><b>{{money(detalle.total, detalle.moneda)}}</b></div></div>
      <p v-if="detalle.notas" class="small muted">{{detalle.notas}}</p>
      <template #foot><button class="btn ghost" @click="detalle=null">Cerrar</button><button class="btn sec" @click="window.print()">Imprimir</button><button class="btn" @click="imprimir(detalle, true)">Descargar PDF</button></template>
    </Modal>
  </div>`,
  setup() { return { toast, window }; },
};
