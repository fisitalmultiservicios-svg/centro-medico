// Inicio de sesión (correo + contraseña, segundo factor si está activo) y configuración inicial del administrador del sistema.
import { api, toast } from '../api.js';
import { sesion, conexion } from '../app.js';
import { pintarTurnstile } from '../turnstile.js';
import ConexionLocal from '../conexion-local.js';   // 4.25 (tanda 7): conectar el programa con la cuenta de la página web

const AVISO_TS = {
  carga: 'No se pudo cargar la verificación contra robots. Revise su conexión; si usa un bloqueador de anuncios, permita este sitio y recargue la página.',
  falla: 'La verificación contra robots tuvo un problema. Si no se arregla sola en unos segundos, recargue la página.',
};

export default {
  props: ['params'],
  components: { ConexionLocal },
  data() {
    // #/restablecer?t=… (enlace del correo de recuperación) abre directamente el formulario de contraseña nueva
    const h = location.hash || ''; const mm = h.match(/^#\/restablecer\?t=([^&]+)/);
    let tokenReset = ''; try { tokenReset = mm ? decodeURIComponent(mm[1]) : ''; } catch { tokenReset = ''; }
    return { AVISO_TS, pinModo: false, pin: '', estado: null, correo: '', password: '', nombre: '', codigo: '', tokenMfa: null, cargando: false, mostrar: false, modo: tokenReset ? 'restablecer' : 'login', tokenReset, nueva: '', repetir: '', tokenInstalacion: '',
      captcha: '', tsError: '',
      // 4.25 (tanda 7, programa local): conectada = nombre de la empresa recién conectada; soporte = formulario del administrador local
      // (solo con FE_LOCAL_ADMIN=1); reconectar = conectar de nuevo una computadora conectada donde nadie llegó a entrar
      conectada: '', soporte: false, reconectar: false, avisoConexion: '' };
  },
  computed: {
    // 4.25 (tanda 7): en el programa (estado.local) ya no se crea el administrador del sistema, salvo en modo soporte y a pedido
    setup() { return !!this.estado && !this.estado.hay_admin && (!this.local || (!!this.local.admin_local && this.soporte)); },
    local() { return (this.estado && this.estado.local) || null; },
    programaCerrado() { return !!this.local && !this.local.admin_local; },   // en el programa la contraseña se recupera en la web
    // computadora sin estrenar: en lugar del formulario, «Conecte esta computadora con su cuenta» (con la configuración escrita y nadie
    // que haya entrado todavía no se ofrece de entrada: primero se entra; «Conectar de nuevo» queda como enlace)
    primerIngreso() { const l = this.local; return !!l && !!l.nueva && !this.soporte && !this.conectada && (!l.vinculada || this.reconectar); },
    pendienteWeb() { return !this.local && conexion.activa; },              // web: hay una computadora esperando que la aprueben
    // 4.25 (programa local): la sincronización anotó que no hay internet: se entra con lo guardado en esta computadora
    sinInternet() { const d = this.estado && this.estado.sin_internet_desde; if (!d) return ''; const f = new Date(d); return isNaN(f) ? 'sin fecha' : f.toLocaleString('es-CR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); },
    paginaWeb() { return (this.estado && this.estado.pagina_web) || ''; },
    // 9b (U9a): en el programa conectado se entra con la cuenta de la página web (en la web, el texto de siempre)
    subtitulo() {
      if (this.setup) return 'Aún no existe un administrador. Cree la cuenta con la que gestionará las empresas.';
      const l = this.local;
      if (l && l.vinculada && !l.admin_local) return 'Entre con el correo y la contraseña de su cuenta de ' + (l.web || 'la página web') + '.';
      return 'Ingrese con el correo y la contraseña que le entregó el administrador.';
    } },   // 4.25: en el programa, la contraseña se recupera en la página web
  watch: { modo() { this.pintarTs(); }, tokenMfa(v) { if (!v) this.pintarTs(); else this.quitarTs(); } },
  beforeUnmount() { this.quitarTs(); },
  methods: {
    // ---- verificación contra robots (3.84): se pinta en el formulario visible y se renueva después de cada intento
    quitarTs() { this.tsN = (this.tsN || 0) + 1; if (this.ts) { this.ts.quitar(); this.ts = null; } },
    async pintarTs() {
      this.quitarTs(); this.tsError = '';
      if (!this.captcha || this.setup || this.primerIngreso || this.tokenMfa || !['login', 'recuperar'].includes(this.modo)) return;
      const n = this.tsN = (this.tsN || 0) + 1;       // si cambia el formulario mientras carga, gana el último
      await this.$nextTick();
      const el = this.$refs.ts; if (!el) return;
      try {
        const ctl = await pintarTurnstile(el, this.captcha, this.modo, { token: t => { if (t) this.tsError = ''; }, error: () => { this.tsError = 'falla'; } });
        if (n !== this.tsN) ctl.quitar(); else this.ts = ctl;
      } catch { if (n === this.tsN) this.tsError = 'carga'; }
    },
    async tokenTs() {                 // el token del recuadro ('' si no hace falta o no llegó: el servidor decide)
      if (!this.captcha || !this.ts) return '';
      return this.ts.esperar(this.tsError ? 1 : 15000);
    },
    renovarTs() { if (this.ts) this.ts.reiniciar(); },
    volverLogin() { this.modo = 'login'; this.password = ''; if (location.hash.startsWith('#/restablecer')) location.hash = ''; },
    async recuperar() {
      if (!this.correo) return toast('Indique su correo electrónico', 'err');
      this.cargando = true;
      try {
        const turnstile = await this.tokenTs();
        const r = await api('/api/auth/recuperar', { method: 'POST', body: { correo: this.correo, turnstile: turnstile || null } }); toast(r.mensaje || 'Revise su correo', 'ok'); this.modo = 'login';
      }
      catch (e) { toast(e.message, 'err'); this.renovarTs(); }
      this.cargando = false;
    },
    async restablecer() {
      if (!this.nueva) return toast('Indique la contraseña nueva', 'err');
      if (this.nueva !== this.repetir) return toast('La contraseña nueva y su repetición no coinciden', 'err');
      this.cargando = true;
      try { await api('/api/auth/restablecer', { method: 'POST', body: { token: this.tokenReset, nueva: this.nueva } }); toast('Contraseña restablecida: inicie sesión con la nueva', 'ok'); this.volverLogin(); }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async entrar() {
      if (!this.correo || !this.password) return toast('Indique correo y contraseña', 'err');
      this.cargando = true;
      try {
        if (this.setup) {
          const r = await api('/api/auth/setup', { method: 'POST', body: { correo: this.correo, password: this.password, nombre: this.nombre || 'Administrador', token: this.tokenInstalacion.trim() || null } });
          sesion.iniciar(r); toast('Administrador creado. Bienvenido.', 'ok');
        } else {
          const turnstile = await this.tokenTs();
          const r = await api('/api/auth/login', { method: 'POST', body: { correo: this.correo, password: this.password, turnstile: turnstile || null } });
          if (r.mfa_requerido) { this.tokenMfa = r.token_mfa; this.$nextTick(() => this.$refs.cod?.focus()); }
          else { sesion.iniciar(r); if (r.aviso_ingreso) toast(r.aviso_ingreso); }   // 4.25: p. ej. «Esta computadora está conectada a otra dirección…»
        }
      } catch (e) { toast(e.message, 'err'); this.renovarTs(); }
      this.cargando = false;
    },
    async entrarPin() {   // etapa 1: PIN de caja en el programa local
      if (!this.correo || !this.pin) return toast('Indique correo y PIN', 'err');
      this.cargando = true;
      try { sesion.iniciar(await api('/api/auth/pin/entrar', { method: 'POST', body: { correo: this.correo, pin: this.pin } })); }
      catch (e) { toast(e.message, 'err'); this.pin = ''; }
      this.cargando = false;
    },
    // 4.25 (tanda 7): la conexión terminó: vuelve el formulario de siempre con el aviso «Listo» (la computadora sigue «sin estrenar»
    // hasta que alguien entra, por eso se recuerda aquí y no se vuelve a ofrecer la conexión)
    async conectadaLista(ev) {
      const e = ev && ev.empresa;
      this.conectada = (e && (e.nombre_comercial || e.nombre)) || 'su empresa'; this.reconectar = false;
      await this.leerEstado();
    },
    async leerEstado() {
      try {
        const j = await api('/api/auth/estado');
        // en el programa, el enlace para recuperar la contraseña siempre abre la página web: si el estado no la trae, se arma con su nombre
        const l = j && j.local;
        // 9b (U7): la dirección completa de la página web (URL_NUBE, con su puerto) la manda el programa en local.pagina
        if (l && !l.admin_local && !j.pagina_web && l.pagina) j.pagina_web = l.pagina;
        this.estado = j; this.captcha = this.estado.captcha || ''; this.pintarTs();
      } catch (e) { toast(e.message, 'err'); }
    },
    async verificar() {
      if (!this.codigo) return;
      this.cargando = true;
      try { sesion.iniciar(await api('/api/auth/mfa/verificar', { method: 'POST', body: { token_mfa: this.tokenMfa, codigo: this.codigo } })); }
      catch (e) { toast(e.message, 'err'); this.codigo = ''; }
      this.cargando = false;
    },
  },
  async created() {
    // 4.25 (tanda 7): aviso que dejó Instalación local cuando la conexión retiró la cuenta de esta computadora (se muestra una vez)
    try { this.avisoConexion = sessionStorage.getItem('conexion:aviso') || ''; sessionStorage.removeItem('conexion:aviso'); } catch { this.avisoConexion = ''; }
    await this.leerEstado();
  },
  template: `
  <div class="login-wrap">
    <div class="login-card">
      <div class="brand" style="padding:0 0 18px"><span class="erp-brand"><img src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP" style="height:40px;width:auto;max-width:132px"><span class="erp-by">by Brillante Agencia</span></span></div>
      <template v-if="primerIngreso">
        <h1 style="font-size:20px;margin:0 0 4px">Conecte esta computadora con su cuenta</h1>
        <p class="muted small" style="margin:0 0 16px">Para empezar a usar el programa, conéctelo con la cuenta de su empresa en {{local.web}}. Un administrador de la empresa lo aprueba desde la página web. Esta primera vez la computadora necesita internet.</p>
        <ConexionLocal :web="local.web || ''" :equipo="local.equipo || ''" @lista="conectadaLista"></ConexionLocal>
        <a v-if="reconectar" class="link small" style="display:block;text-align:center;margin-top:12px;cursor:pointer" @click="reconectar=false">Volver al inicio de sesión</a>
        <a v-if="local.admin_local" class="link small" style="display:block;text-align:center;margin-top:12px;cursor:pointer" @click="soporte=true">Crear un administrador de esta computadora (soporte)</a>
      </template>
      <template v-else-if="modo==='recuperar'">
        <h1 style="font-size:20px;margin:0 0 4px">Recuperar contraseña</h1>
        <template v-if="programaCerrado">
          <p class="muted small" style="margin:0 0 18px">La contraseña se recupera en la página web: abra {{local.web}} y use, en su pantalla de ingreso, el enlace para recuperarla. El cambio llega solo a esta computadora en unos minutos.</p>
          <a v-if="paginaWeb" class="btn" style="width:100%;justify-content:center;padding:11px" :href="paginaWeb + '/app/'" target="_blank" rel="noopener">Abrir la página web</a>
        </template>
        <template v-else>
        <p class="muted small" style="margin:0 0 18px">Indique el correo con el que ingresa. Le enviaremos un enlace, válido por 30 minutos, para elegir una contraseña nueva.</p>
        <Field label="Correo electrónico"><input type="email" v-model="correo" autocomplete="username" @keyup.enter="recuperar"></Field>
        <div v-if="captcha" ref="ts" class="ts-caja"></div>
        <p v-if="captcha && tsError" class="small ts-aviso">{{AVISO_TS[tsError]}}</p>
        <button class="btn" style="width:100%;justify-content:center;margin-top:18px;padding:11px" @click="recuperar" :disabled="cargando">{{cargando?'Enviando…':'Enviar enlace'}}</button>
        </template>
        <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="modo='login'">Volver</button>
      </template>
      <template v-else-if="modo==='restablecer'">
        <h1 style="font-size:20px;margin:0 0 4px">Contraseña nueva</h1>
        <p class="muted small" style="margin:0 0 18px">Elija una contraseña de al menos 12 caracteres que no haya usado antes.</p>
        <div class="grid" style="grid-template-columns:1fr;gap:12px">
          <Field label="Contraseña nueva"><input type="password" v-model="nueva" autocomplete="new-password"></Field>
          <Field label="Repita la contraseña nueva"><input type="password" v-model="repetir" autocomplete="new-password" @keyup.enter="restablecer"></Field>
        </div>
        <button class="btn" style="width:100%;justify-content:center;margin-top:18px;padding:11px" @click="restablecer" :disabled="cargando">{{cargando?'Guardando…':'Guardar contraseña'}}</button>
        <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="volverLogin">Volver al inicio de sesión</button>
      </template>
      <template v-else-if="!tokenMfa">
        <h1 style="font-size:20px;margin:0 0 4px">{{setup ? 'Configurar administrador del sistema' : 'Iniciar sesión'}}</h1>
        <p class="muted small" style="margin:0 0 18px">{{subtitulo}}</p>
        <div class="alert ok small" style="margin:0 0 14px" v-if="!setup && conectada">Listo. Esta computadora quedó conectada a {{conectada}}. Ahora entre con su correo y su contraseña de {{local && local.web}}.</div>
        <div class="alert info small" style="margin:0 0 14px" v-else-if="!setup && avisoConexion">{{avisoConexion}}</div>
        <div class="alert info small" style="margin:0 0 14px" v-else-if="!setup && local && local.nueva && local.vinculada">Esta computadora ya está conectada a la página web. Entre con su correo y su contraseña de {{local.web}}.</div>
        <div class="alert info small" style="margin:0 0 14px" v-if="pendienteWeb">Entre con su cuenta para aprobar la computadora nueva.</div>
        <div class="alert info small" style="margin:0 0 14px" v-if="!setup && sinInternet"><b>Sin internet: entra con lo guardado en esta computadora.</b> Sin conexión desde el {{sinInternet}}. Solo entra quien ya entró aquí con internet; los cambios de usuarios y contraseñas hechos en la página web llegan cuando vuelva la conexión.</div>
        <div class="grid" style="grid-template-columns:1fr;gap:12px">
          <Field label="Token de instalación" v-if="setup" help="El valor de la variable FE_SETUP_TOKEN del servidor (en una instalación en internet es obligatorio)"><input v-model="tokenInstalacion" autocomplete="off" class="mono"></Field>
          <Field label="Nombre" v-if="setup"><input v-model="nombre" placeholder="Su nombre"></Field>
          <Field label="Correo electrónico"><input type="email" v-model="correo" autocomplete="username" @keyup.enter="entrar"></Field>
          <Field label="PIN de caja" v-if="pinModo"><input type="password" inputmode="numeric" maxlength="6" v-model="pin" autocomplete="off" @keyup.enter="entrarPin"></Field>
          <Field label="Contraseña" v-if="!pinModo"><div class="row" style="gap:6px"><input :type="mostrar?'text':'password'" v-model="password" autocomplete="current-password" @keyup.enter="entrar" style="flex:1"><button class="btn ghost sm" @click="mostrar=!mostrar" tabindex="-1">{{mostrar?'Ocultar':'Ver'}}</button></div></Field>
        </div>
        <div v-if="captcha && !setup" ref="ts" class="ts-caja"></div>
        <p v-if="captcha && !setup && tsError" class="small ts-aviso">{{AVISO_TS[tsError]}}</p>
        <button class="btn" style="width:100%;justify-content:center;margin-top:18px;padding:11px" @click="pinModo ? entrarPin() : entrar()" :disabled="cargando">{{cargando?'Verificando…':(setup?'Crear administrador':'Entrar')}}</button>
        <a v-if="!setup && paginaWeb" class="link small" style="display:block;text-align:center;margin-top:12px" :href="paginaWeb + '/app/'" target="_blank" rel="noopener" title="Su contraseña se cambia en la página web">¿Olvidó su contraseña?</a>
        <a v-else-if="!setup" class="link small" style="display:block;text-align:center;margin-top:12px;cursor:pointer" @click="modo='recuperar'">¿Olvidó su contraseña?</a>
        <a v-if="!setup && estado && estado.pin_local" class="link small" style="display:block;text-align:center;margin-top:8px;cursor:pointer" @click="pinModo = !pinModo">{{pinModo ? 'Entrar con contraseña' : 'Entrar con PIN de caja'}}</a>
        <a v-if="!setup && local && local.nueva && local.vinculada" class="link small muted" style="display:block;text-align:center;margin-top:8px;cursor:pointer" @click="reconectar=true; conectada=''">¿Nadie puede entrar todavía? Conectar esta computadora de nuevo</a>
        <a v-if="!setup && local && local.admin_local && !estado.hay_admin" class="link small muted" style="display:block;text-align:center;margin-top:8px;cursor:pointer" @click="soporte=true">Crear un administrador de esta computadora (soporte)</a>
        <a v-if="setup && local" class="link small" style="display:block;text-align:center;margin-top:12px;cursor:pointer" @click="soporte=false">Volver</a>
      </template>
      <template v-else>
        <h1 style="font-size:20px;margin:0 0 4px">Verificación en dos pasos</h1>
        <p class="muted small" style="margin:0 0 18px">Escriba el código de 6 dígitos de su aplicación de autenticación (Google Authenticator, Microsoft Authenticator o Authy) o uno de sus códigos de respaldo.</p>
        <Field label="Código"><input ref="cod" v-model="codigo" maxlength="9" class="mono" style="font-size:22px;letter-spacing:6px;text-align:center" @keyup.enter="verificar"></Field>
        <button class="btn" style="width:100%;justify-content:center;margin-top:18px;padding:11px" @click="verificar" :disabled="cargando">Verificar</button>
        <button class="btn ghost" style="width:100%;justify-content:center;margin-top:8px" @click="tokenMfa=null;codigo=''">Volver</button>
      </template>
      <p class="small muted" style="margin:22px 0 0;text-align:center">Facturación electrónica Costa Rica · Hacienda v4.4</p>
      <p class="small muted" style="margin:6px 0 0;text-align:center;font-size:11.5px">Un servicio de <a href="https://itcoresync.com/" target="_blank" rel="noopener">IT Core Sync S.R.L.</a></p>
    </div>
  </div>`,
};
