// Configuración › Marcas (3.45): una misma cédula factura con varios nombres comerciales y logos (p. ej. IT Core Sync factura como
// FISITAAP by Brillante Agencia o como Brillante Agencia). La marca cambia el logo y el nombre comercial del PDF, el tiquete, el correo y la página de
// consulta, y el nombre comercial del XML; el emisor legal (nombre, cédula, actividad, ubicación) es siempre el de la empresa. La
// marca predeterminada se usa en los documentos que no indican una (punto de venta, hotel, recurrentes).
import { api, toast } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  data() { return { lista: [], cargando: true, modal: null, guardando: false, subiendo: null }; },
  computed: {
    puede() { return sesion.puede('configurar'); },
    predeterminada() { return this.lista.find(m => m.predeterminada && m.activa); },
  },
  methods: {
    async cargar() { try { this.lista = await api('/api/marcas'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    abrir(m) { this.modal = m ? { ...m } : { id: null, nombre: '', sitio_web: '', correo: '', telefono: '', predeterminada: !this.lista.length, activa: true }; },
    async guardar() {
      const m = this.modal; if (!(m.nombre || '').trim()) return toast('Escriba el nombre comercial de la marca', 'err');
      const tel = String(m.telefono || '').replace(/\D/g, '');
      const body = { nombre: m.nombre.trim(), sitio_web: (m.sitio_web || '').trim() || null, correo: (m.correo || '').trim() || null, telefono: tel ? +tel : null, predeterminada: !!m.predeterminada, activa: m.activa !== false };
      this.guardando = true;
      try {
        const r = m.id ? await api('/api/marcas/' + m.id, { method: 'PUT', body }) : await api('/api/marcas', { method: 'POST', body });
        toast(m.id ? 'Marca actualizada' : 'Marca creada: ahora súbale el logo', 'ok'); this.modal = null; await this.cargar();
        if (!m.id) this.abrir(this.lista.find(x => x.id === r.id));
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async subirLogo(m, ev) {
      const file = ev.target.files && ev.target.files[0]; if (!file) return;
      if (!/^image\/(png|jpe?g)$/.test(file.type)) { ev.target.value = ''; return toast('El logo debe ser PNG o JPG', 'err'); }
      const fd = new FormData(); fd.append('archivo', file); this.subiendo = m.id;
      try { await api('/api/marcas/' + m.id + '/logo', { method: 'POST', body: fd }); toast('Logo de «' + m.nombre + '» actualizado', 'ok'); await this.cargar(); if (this.modal && this.modal.id === m.id) this.modal = { ...this.lista.find(x => x.id === m.id) }; }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = null; ev.target.value = '';
    },
    async quitarLogo(m) { if (!confirm('¿Quitar el logo de «' + m.nombre + '»? Sus documentos usarán el logo de la empresa.')) return; try { await api('/api/marcas/' + m.id + '/logo', { method: 'DELETE' }); await this.cargar(); if (this.modal) this.modal = { ...this.lista.find(x => x.id === m.id) }; } catch (e) { toast(e.message, 'err'); } },
    async predeterminar(m) { try { await api('/api/marcas/' + m.id, { method: 'PUT', body: { nombre: m.nombre, sitio_web: m.sitio_web, correo: m.correo, telefono: m.telefono, predeterminada: true, activa: true } }); toast('«' + m.nombre + '» es ahora la marca predeterminada', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async borrar(m) {
      if (!confirm('¿Eliminar la marca «' + m.nombre + '»? Si ya tiene comprobantes emitidos, solo se desactiva.')) return;
      try { const r = await api('/api/marcas/' + m.id, { method: 'DELETE' }); toast(r.mensaje || 'Marca eliminada', r.desactivada ? '' : 'ok'); this.modal = null; await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Marcas y logos" sub="Una misma cédula puede facturar con varios nombres comerciales y logos. Cada factura, cotización u orden escoge su marca; la predeterminada se usa cuando no se indica ninguna." :crumbs="[{label:'Configuración',to:'/configuracion'},{label:'Marcas y logos'}]">
      <button class="btn" v-if="puede" @click="abrir(null)">+ Nueva marca</button>
    </PageHead>
    <div class="alert info" style="margin-bottom:12px">La marca cambia solo lo que ve el cliente: el logo y el nombre comercial en el PDF, el tiquete, el correo y la página de consulta, y el «nombre comercial» del XML. El nombre legal, la cédula, la actividad y la dirección son siempre los de la empresa, que Hacienda exige.</div>
    <div class="card" v-if="cargando"><p class="muted">Cargando…</p></div>
    <div class="card" v-else-if="!lista.length"><Empty icon="🏷" title="Sin marcas" text="Hoy todos los documentos salen con el logo y el nombre comercial de la empresa (Configuración › Empresa). Cree una marca para poder cambiarlos por documento."><button class="btn" v-if="puede" @click="abrir(null)">+ Nueva marca</button></Empty></div>
    <div class="grid cols-2" v-else style="align-items:start">
      <div class="card" v-for="m in lista" :key="m.id" :style="m.activa ? '' : 'opacity:.6'">
        <div class="row" style="gap:14px;align-items:flex-start">
          <label class="drop" :style="{width:'150px',minHeight:'84px',padding:'8px',display:'flex',alignItems:'center',justifyContent:'center',cursor: puede ? 'pointer' : 'default'}" :title="puede ? 'Cambiar el logo' : ''">
            <img v-if="m.logo" :src="m.logo" :alt="m.nombre" style="max-height:70px;max-width:100%">
            <span v-else class="small">{{subiendo===m.id ? 'Subiendo…' : 'Sin logo: se usa el de la empresa. Clic para subirlo'}}</span>
            <input v-if="puede" type="file" accept="image/png,image/jpeg" style="display:none" @change="subirLogo(m, $event)">
          </label>
          <div style="flex:1">
            <h2 style="margin:0 0 4px">{{m.nombre}} <span class="badge ok" v-if="m.predeterminada">Predeterminada</span><span class="badge" v-if="!m.activa">Inactiva</span></h2>
            <div class="small muted">{{[m.sitio_web, m.correo, m.telefono].filter(Boolean).join(' · ') || 'Contacto: el de la empresa'}}</div>
            <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap" v-if="puede">
              <button class="btn sm sec" @click="abrir(m)">Editar</button>
              <button class="btn sm ghost" v-if="!m.predeterminada && m.activa" @click="predeterminar(m)">Hacer predeterminada</button>
              <button class="btn sm ghost" v-if="m.logo" @click="quitarLogo(m)">Quitar logo</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="card" v-if="lista.length"><h2>Cómo se usa</h2>
      <ul class="small" style="margin:0;padding-left:18px;line-height:1.7">
        <li>En una factura, cotización, remisión u orden de compra, el campo <b>Marca</b> (en «Más ajustes» o junto a la moneda) cambia el logo y el nombre comercial de ese documento.</li>
        <li>Los documentos que no eligen marca (punto de venta, hotel, facturas recurrentes) salen con la <b>predeterminada</b>{{predeterminada ? ': ' + predeterminada.nombre : ''}}. Sin predeterminada, con el logo y el nombre comercial de la empresa.</li>
        <li>El correo con que se envía la factura sale a nombre de la marca, desde la misma cuenta de correo de la empresa.</li>
      </ul>
    </div>
    <Modal v-if="modal" :title="modal.id ? 'Editar marca' : 'Nueva marca'" @close="modal=null">
      <div class="grid cols-2">
        <Field label="Nombre comercial" req help="Como lo verá el cliente; va al PDF y al XML" style="grid-column:1/-1"><input v-model="modal.nombre" maxlength="80" placeholder="Brillante Agencia"></Field>
        <Field label="Sitio web" help="Vacío = el de la empresa"><input v-model="modal.sitio_web" maxlength="120" placeholder="brillanteagencia.com"></Field>
        <Field label="Correo de contacto" help="Vacío = el de la empresa"><input type="email" v-model="modal.correo" maxlength="120"></Field>
        <Field label="Teléfono" help="8 dígitos; vacío = el de la empresa"><input v-model="modal.telefono" maxlength="12" inputmode="numeric"></Field>
        <div style="display:flex;flex-direction:column;gap:8px;justify-content:center"><Toggle v-model="modal.predeterminada" label="Marca predeterminada"></Toggle><Toggle v-if="modal.id" v-model="modal.activa" label="Activa"></Toggle></div>
      </div>
      <div v-if="modal.id" style="margin-top:10px">
        <label class="drop" style="display:block"><img v-if="modal.logo" :src="modal.logo" alt="Logo" style="max-height:80px;max-width:100%;display:block;margin:0 auto 8px"><span>{{subiendo===modal.id ? 'Subiendo…' : (modal.logo ? 'Cambiar logo' : 'Haga clic para subir el logo de esta marca')}}</span><br><span class="small">PNG o JPG, máx. 2 MB. Recomendado: PNG con fondo transparente, 600 × 200 px (horizontal)</span><input type="file" accept="image/png,image/jpeg" style="display:none" @change="subirLogo(modal, $event)"></label>
      </div>
      <p class="small muted" v-else style="margin:8px 0 0">Guarde la marca y después súbale el logo.</p>
      <template #foot><button class="btn ghost" v-if="modal.id" @click="borrar(modal)" style="margin-right:auto">Eliminar</button><button class="btn ghost" @click="modal=null">Cancelar</button><button class="btn" :disabled="guardando" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};
