// Configuración › Instalación local (3.12, 3.13, 3.14): en la nube, genera el código de vinculación y lista las instalaciones locales
// con lo que subió cada una; en una instalación local, vincula con la nube, muestra el estado de la sincronización (última bajada y
// subida, comprobantes y cobros pendientes, lo subido, errores) y configura la red local (clave de red y las otras computadoras).
// 4.9: aviso «Sin acceso a la nube» (la nube negó el acceso sin revocar: se sigue trabajando y reintentando, nunca se bloquea ni
// se borra) y la terminal y la sucursal fijas desde la vinculación (solo se muestran: no se editan aquí ni en Hacienda).
// 4.25 (tanda 7): en la web, «Computadoras conectadas» (con quién conectó cada una), «Conectar una computadora nueva» (lleva a #/conectar)
// y, plegado, «Otra forma de conectar (programas anteriores a la 4.25 o soporte)» con el código de siempre (7b, T4: con la instrucción
// para un programa anterior, que solo se vincula con «Vincular esta instalación con la nube», la dirección de este sitio y el código). En el programa, «Conectar con mi cuenta» (mismo flujo de
// código y número que la pantalla de ingreso, con sesión, sobre la empresa abierta), «Tengo un código» SIN campo de dirección (el
// programa usa siempre la dirección de la web con la que se armó) y las cuentas que solo existen en esta computadora.
import { api, toast, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';
import ConexionLocal from '../../conexion-local.js';

// 9b (U5): un intento guardado en la pestaña es de «Conectar otra empresa» si lleva su marca (la pone otraEstado): al recargar se vuelve a
// abrir. Sin la marca es de «Conectar con mi cuenta» (la tarjeta de conectar de nuevo tiene los dos caminos y solo uno a la vez)
function intentoGuardado() { try { return sessionStorage.getItem('conexion:intento') || ''; } catch { return ''; } }
function otraGuardada() { const i = intentoGuardado(); try { return !!i && sessionStorage.getItem('conexion:otra') === i; } catch { return false; } }

export default {
  props: ['params'],
  components: { ConexionLocal },
  data() { return { est: null, inst: null, codigo: null, cargando: true, guardando: false, red: { clave: '', pcs: [], nuevo: { nombre: '', url: '' }, probando: null, prueba: null }, f: { codigo: '', nombre: '' },
                   web: '', equipo: '', conCodigo: false, cuentas: null,   // 4.25 (tanda 7): programa
                   otra: otraGuardada(),                                    // 9b (U5): «Conectar otra empresa en esta computadora» abierto
                   enCurso: !!intentoGuardado(),                            // 9b: hay un intento a medias en la pestaña: no se cambia de camino hasta que termine
                   origen: (typeof location !== 'undefined' && location.origin) || '',   // 7b (T4): dirección de este sitio para los programas anteriores a la 4.25
                   cxLista: false,                                          // 9c (J10): «Conectar con mi cuenta» llegó a «Listo»
                   instalador: null,                                        // 4.26: el programa publicado para descargar (solo en la web)
                   prog: null, reiniciando: false, revisando: false }; },   // 3.58: versión del programa y actualización automática
  computed: { puede() { return sesion.puede('configurar'); }, verPisados() { return !!(sesion.empresaInfo && (sesion.empresaInfo.datos_v2 || sesion.empresaInfo.sinc_pantallas)); } },   // 4.32: «Cambios que no quedaron» solo con la bandera datos_v2
  methods: {
    fechaHora,
    mb(b) { return ((Number(b) || 0) / 1048576).toFixed(1) + ' MB'; },   // 4.26: tamaño del programa para descargar
    cargarRed() { const r = (this.est && this.est.red) || {}; this.red.pcs = (r.pcs || []).map(p => ({ nombre: p.nombre, url: p.url, ultimo_ok: p.ultimo_ok, ultimo_error: p.ultimo_error, enviados: p.enviados })); },
    agregarPc() { const n = this.red.nuevo; if (!n.url.trim()) return toast('Indique la dirección de la otra computadora, por ejemplo 192.168.1.20:8020', 'err'); this.red.pcs.push({ nombre: n.nombre.trim() || n.url.trim(), url: n.url.trim() }); this.red.nuevo = { nombre: '', url: '' }; this.guardarRed(); },
    quitarPc(i) { if (!confirm('¿Quitar «' + this.red.pcs[i].nombre + '» de la red local? Dejará de recibir los cambios de esta computadora.')) return; this.red.pcs.splice(i, 1); this.guardarRed(); },
    async guardarRed() {
      if (this.red.clave && this.red.clave.trim().length < 6) return toast('La clave de red debe tener al menos 6 caracteres', 'err');
      this.guardando = true;
      try { this.est = await api('/api/sinc/local/red', { method: 'POST', body: { clave: this.red.clave.trim() || null, pcs: this.red.pcs.map(p => ({ nombre: p.nombre, url: p.url })) } }); this.red.clave = ''; this.cargarRed(); toast('Red local guardada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async probarPc(p) { this.red.probando = p.url; this.red.prueba = null; try { const r = await api('/api/sinc/local/red/probar', { method: 'POST', body: { url: p.url } }); this.red.prueba = { url: p.url, ok: true, texto: 'Responde: ' + r.nombre + (r.terminal ? ' · terminal ' + r.terminal : '') + (r.version ? ' · versión ' + r.version : '') + (r.vinculada ? '' : ' · todavía no vinculada a la nube') }; } catch (e) { this.red.prueba = { url: p.url, ok: false, texto: e.message }; } this.red.probando = null; },
    async enviarRed() { this.guardando = true; try { this.est = await api('/api/sinc/local/red/ahora', { method: 'POST' }); this.cargarRed(); const err = (this.est.red.pcs || []).filter(p => p.ultimo_error); toast(err.length ? 'Terminó con avisos: ' + err.map(p => p.nombre + ': ' + p.ultimo_error).join(' · ') : 'Cambios enviados a las otras computadoras', err.length ? 'err' : 'ok'); } catch (e) { toast(e.message, 'err'); } this.guardando = false; },
    async cargar() {
      this.cargando = true;
      try { this.est = await api('/api/sinc/local/estado'); if (!this.est.modo_local) this.inst = await api('/api/sinc/instalaciones'); this.cargarRed(); } catch (e) { toast(e.message, 'err'); }
      if (this.est && this.est.modo_local) { try { this.prog = await api('/api/local/estado'); } catch { this.prog = null; } }
      if (this.est && !this.est.modo_local) { try { const p = await api('/api/local/instalador'); this.instalador = p && p.version ? p : null; } catch { this.instalador = null; } }   /* 4.26: si falla, sin botón y ya */
      if (this.est && this.est.modo_local) {   // 4.25 (tanda 7): nombre de la página web para los textos y cuentas solo de esta computadora
        try { const j = await api('/api/auth/estado'); this.web = (j.local && j.local.web) || ''; this.equipo = (j.local && j.local.equipo) || ''; } catch { this.web = ''; }
        if (this.puede) { try { this.cuentas = await api('/api/sinc/local/cuentas'); } catch { this.cuentas = null; } }
      }
      this.cargando = false;
    },
    // 4.25 (tanda 7): la conexión con la cuenta terminó en esta computadora
    conexionLista(ev) { toast('Esta computadora quedó conectada: ya se están bajando los datos de su empresa.', 'ok'); this.cxLista = false; this.enCurso = !!intentoGuardado(); this.cargar(); this.refrescarSesion(ev); },
    // 9c (J10): la conexión empezada con sesión terminó y la sesión sigue abierta (la cuenta es de la página web: una cuenta creada solo en
    // esta computadora queda retirada y la atiende «retirada»): se pone al día la empresa de la sesión, para que la franja y el aviso de
    // «revocada» se vayan sin recargar
    sigueConSesion(v) { return !!sesion.usuario?.de_nube && (!v || v.con_sesion === undefined || v.con_sesion === null || !!v.con_sesion); },
    refrescarSesion(v) { if (this.sigueConSesion(v) && sesion.refrescarEmpresas) sesion.refrescarEmpresas().catch(() => {}); },
    // la cuenta con la que se entró se creó solo en esta computadora: al conectarse quedó retirada (401). No es un error: se explica en
    // la pantalla de ingreso, que ahora pide el correo y la contraseña de la página web
    retirada(ev) {
      const texto = ev && ev.conectada ? this.textoRetirada() : ((ev && ev.mensaje) || '');
      try { if (texto) sessionStorage.setItem('conexion:aviso', texto); } catch {}
      sesion.cerrar(false);
    },
    textoRetirada() { return 'Esta computadora quedó conectada a la página web. La cuenta con la que entró se creó solo en esta computadora y ya no se usa: entre con su correo y su contraseña de ' + (this.web || 'la página web') + '.'; },
    // 7b (T6): con una cuenta DE LA COMPUTADORA, la marca del aviso se deja ANTES de empezar: si el 401 lo recibe otra consulta de la
    // pestaña (la franja, cada 60 s), el ingreso igual explica que la computadora quedó conectada. Se borra si la conexión no se aplica.
    antesDeConectar() { if (!sesion.usuario?.de_nube) { try { sessionStorage.setItem('conexion:aviso', this.textoRetirada()); } catch {} } },
    estadoConexion(e) { this.cxLista = e === 'lista'; if (e === 'lista') this.refrescarSesion(this.$refs && this.$refs.cx ? this.$refs.cx.v : null); this.enCurso = !!intentoGuardado() || this.cxLista;   /* 9c (J10): en «Listo» no se ofrece otro camino */ if (!['esperando', 'retenida', 'confirmar', 'aplicando', 'fallo', 'lista'].includes(e)) { try { sessionStorage.removeItem('conexion:aviso'); } catch {} } },
    tengoCodigo() { location.hash = '/conectar'; },   // web: la pantalla de aprobación (#/conectar, nivel superior)
    // 9b (U5): la otra empresa quedó en esta computadora (la empresa abierta y la sesión no cambian)
    otraLista() { this.otra = false; this.cargar(); if (sesion.refrescarEmpresas) sesion.refrescarEmpresas().catch(() => {}); },   // 9c (J8): la empresa nueva aparece en el menú de empresas sin recargar
    // 9c (J11): «Volver» cancela el intento de «Conectar otra empresa» que esté en curso (el cancelar del componente) y borra lo guardado en la pestaña
    async volverDeOtra() {
      const cx = this.$refs && this.$refs.otraCx, v = cx && cx.v;
      if (v && v.intento && !cx.final && v.estado !== 'lista') { try { await cx.cancelar(); } catch { /* el intento vence solo */ } }
      else {
        const id = intentoGuardado();
        if (cx && cx.parar) cx.parar();
        if (id && otraGuardada()) api('/api/sinc/local/conexion/cancelar', { method: 'POST', body: { intento: id }, sinExpirar: true }).catch(() => {});
      }
      try { if (otraGuardada()) sessionStorage.removeItem('conexion:intento'); sessionStorage.removeItem('conexion:otra'); } catch {}
      this.otra = false; this.enCurso = !!intentoGuardado();
    },
    // corrección de la 9c: el bloque se cierra solo cuando la persona canceló (el componente ya no tiene vista). Si el intento lo terminó el
    // programa o la página web, la vista llega «cancelada» con su mensaje (por ejemplo, la empresa sin cédula): el bloque sigue abierto
    // para que el mensaje se vea, con «Empezar de nuevo»
    otraEstado(e) { const i = intentoGuardado(), cx = this.$refs && this.$refs.otraCx; this.enCurso = !!i; try { sessionStorage.setItem('conexion:otra', i); } catch {} if (e === 'cancelada' && !(cx && cx.v && cx.v.estado === 'cancelada')) this.otra = false; },
    // 3.58: actualización automática del programa local
    async revisarPrograma() { this.revisando = true; try { const r = await api('/api/local/revisar', { method: 'POST' }); this.prog = await api('/api/local/estado'); toast(r.error ? r.error : r.nueva ? 'Versión ' + r.nueva + (r.descargada ? ' descargada y lista para instalar' : ' encontrada') : 'Ya tiene la versión más reciente', r.error ? 'err' : 'ok'); } catch (e) { toast(e.message, 'err'); } this.revisando = false; },
    async reiniciarPrograma() {
      if (!confirm('El programa se cierra y se vuelve a abrir con la versión nueva. Cierre primero lo que tenga a medias en esta computadora. ¿Continuar?')) return;
      this.reiniciando = true;
      try { const r = await api('/api/local/reiniciar', { method: 'POST' }); toast(r.mensaje || 'El programa se reinicia en unos segundos; recargue la página.', 'ok'); }
      catch (e) { toast(e.message, 'err'); this.reiniciando = false; }
    },
    async generar() { try { this.codigo = await api('/api/sinc/codigo', { method: 'POST', body: { nombre: '' } }); toast('Código generado: vale 15 minutos y se usa una sola vez', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async renombrar(i) { const n = prompt('Nuevo nombre para «' + i.nombre + '» (terminal ' + i.terminal + ')', i.nombre); if (n === null || !n.trim()) return; try { const r = await api('/api/sinc/instalaciones/' + i.terminal, { method: 'PUT', body: { nombre: n.trim() } }); this.inst.instalaciones = r.instalaciones; toast('Nombre guardado: le baja a la computadora en su siguiente sincronización', 'ok'); } catch (e) { toast(e.message, 'err'); } },
    async quitar(i) { if (!confirm('¿Revocar «' + i.nombre + '» (terminal ' + i.terminal + ')? Esa computadora dejará de sincronizar con la nube y con las demás; a los 3 días de enterarse se bloqueará y a los 30 borrará sus datos, salvo que un administrador la conecte de nuevo. Lo que ya subió se conserva.')) return; try { await api('/api/sinc/instalaciones/' + i.terminal, { method: 'DELETE' }); toast('Instalación desvinculada', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async vincular() {   // 4.25: sin dirección: el programa usa siempre la de la página web con la que se armó
      if (!this.f.codigo.trim()) return toast('Indique el código', 'err');
      this.guardando = true;
      try { this.est = await api('/api/sinc/local/vincular', { method: 'POST', body: { codigo: this.f.codigo.trim(), nombre: this.f.nombre.trim() } }); toast('Instalación vinculada: ya se están bajando los catálogos. Recargue la página en un momento.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async ahora() { this.guardando = true; try { this.est = await api('/api/sinc/local/ahora', { method: 'POST' }); toast(this.est.ultimo_error ? 'Terminó con error: ' + this.est.ultimo_error : 'Sincronización terminada', this.est.ultimo_error ? 'err' : 'ok'); } catch (e) { toast(e.message, 'err'); } this.guardando = false; },
    async desvincular() { if (!confirm('¿Desvincular esta instalación de la nube? Seguirá trabajando sola, sin sincronizar.')) return; try { this.est = await api('/api/sinc/local/desvincular', { method: 'POST' }); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Instalación local" sub="El programa instalado en las computadoras del negocio: trabaja aunque falte internet y se sincroniza con la nube (clientes, ítems, configuración y comprobantes)." :crumbs="[{label:'Configuración',to:'/configuracion'},{label:'Instalación local'}]"></PageHead>
    <div class="card" v-if="cargando"><p class="muted">Cargando…</p></div>
    <template v-else-if="est && est.modo_local">
      <div class="card" v-if="prog"><h2>Programa instalado en esta computadora <small>versión {{prog.version_local || '—'}}</small></h2>
        <div class="alert ok" style="margin:0 0 10px;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap" v-if="prog.descargada"><span><b>Hay una versión nueva descargada ({{prog.descargada.version}})</b> y verificada. Se instala al reiniciar el programa.</span><button class="btn" @click="reiniciarPrograma" :disabled="reiniciando || !puede">{{reiniciando ? 'Reiniciando…' : 'Reiniciar y actualizar'}}</button></div>
        <p class="small muted" style="margin:0" v-else>El programa revisa la nube al arrancar y cada 6 horas; cuando hay una versión nueva la descarga en segundo plano y la instala al reiniciar. {{prog.revisado ? 'Última revisión: ' + fechaHora(prog.revisado) + '.' : 'Todavía no ha revisado.'}}<span v-if="prog.error" style="color:var(--danger)"> {{prog.error}}</span><span v-if="!prog.nube"> Vincule la instalación con la nube para que pueda actualizarse sola.</span></p>
        <div class="row" style="gap:8px;margin-top:10px"><button class="btn ghost sm" @click="revisarPrograma" :disabled="revisando || !prog.nube">{{revisando ? 'Revisando…' : 'Buscar versión nueva ahora'}}</button></div>
      </div>
      <div class="alert warn" v-if="est.revocada_en && !cxLista" style="margin-bottom:12px"><b>Esta instalación fue revocada en la nube</b> ({{fechaHora(est.revocada_en)}}).
        <template v-if="est.bloqueada_en"> Está bloqueada desde {{fechaHora(est.bloqueada_en)}}: no emite ni sincroniza. Sus datos se borrarán el {{fechaHora(est.elimina_el)}} salvo que la vincule de nuevo.<span v-if="est.respaldo"> Respaldo guardado al bloquear.</span></template>
        <template v-else> Sigue trabajando hasta {{fechaHora(est.bloquea_el)}}; después se bloqueará.</template>
        Para seguir, conéctela de nuevo con su cuenta (abajo). Si esta computadora conserva sus datos, mantiene su número de terminal.</div>
      <div class="alert warn" v-if="est.sin_acceso_desde && !est.revocada_en" style="margin-bottom:12px"><b>Sin acceso a la nube</b> desde {{fechaHora(est.sin_acceso_desde)}}<span v-if="est.sin_acceso_motivo"> ({{est.sin_acceso_motivo}})</span>.
        Esta computadora sigue trabajando con sus datos, guarda lo pendiente y vuelve a intentar sola cada dos minutos; por esto no se bloquea ni se borra nada.
        Suele pasar cuando la empresa está bloqueada en la nube (por ejemplo, por un pago pendiente) o cuando el cortafuegos del hosting rechaza la conexión: revíselo en la nube o con soporte.</div>
      <div class="card" v-if="!est.vinculado || est.revocada_en"><h2>{{est.revocada_en ? 'Conectar de nuevo esta computadora' : 'Conectar esta computadora'}}</h2>
        <div class="alert warn" style="margin:0 0 10px" v-if="est.descartada">{{est.ultimo_error}} Mientras tanto esta computadora sigue trabajando, pero no sube ni baja nada de la página web.</div>
        <p class="small muted" style="margin:0 0 10px">Conéctela con la cuenta de su empresa en {{web || 'la página web'}}. Un administrador lo aprueba desde la página web. La computadora recibe los datos de la empresa, sus credenciales de Hacienda y su propio número de terminal, y empieza a sincronizar: bajan clientes, ítems y configuración; suben los comprobantes que se emitan aquí.</p>
        <p class="small" style="margin:0 0 10px;color:var(--danger)" v-if="!puede">Solo un administrador de la empresa puede conectar esta computadora.</p>
        <div v-else-if="otra && est.terminal" style="max-width:520px"><h3 style="margin:0 0 6px">Conectar otra empresa en esta computadora</h3>
          <p class="small muted" style="margin:0 0 10px">Para trabajar aquí con otra empresa suya. Un administrador de esa empresa lo aprueba en {{web || 'la página web'}}: elija ahí la otra empresa. La empresa abierta no cambia.</p>
          <ConexionLocal ref="otraCx" :web="web" :equipo="est.nombre || equipo" con-sesion otra-empresa boton="Conectar otra empresa" @lista="otraLista" @retirada="retirada" @estado="otraEstado"></ConexionLocal>
          <a class="link small" style="display:inline-block;margin-top:10px;cursor:pointer" @click="volverDeOtra">Volver</a>
        </div>
        <template v-else-if="!conCodigo">
          <div style="max-width:520px"><ConexionLocal ref="cx" :web="web" :equipo="est.nombre || equipo" con-sesion boton="Conectar con mi cuenta" @lista="conexionLista" @retirada="retirada" @antes="antesDeConectar" @estado="estadoConexion"></ConexionLocal></div>
          <a v-if="!cxLista" class="link small" style="display:inline-block;margin-top:12px;cursor:pointer" @click="conCodigo = true">Tengo un código</a>
        </template>
        <template v-else>
          <p class="small muted" style="margin:0 0 10px">Solo si soporte se lo pidió: un administrador genera el código en la página web, en Configuración › Instalación local › «Otra forma de conectar (programas anteriores a la 4.25 o soporte)».</p>
          <div class="grid cols-2">
            <Field label="Código" req><input v-model="f.codigo" class="mono" placeholder="L12-A2B3-C4D5-E6F7-G8H9" style="text-transform:uppercase" autocomplete="off"></Field>
            <Field label="Nombre de esta computadora" help="Como quiere verla en la página web: Caja 1, Recepción…"><input v-model="f.nombre" maxlength="60" placeholder="Caja 1"></Field>
          </div>
          <div class="row" style="margin-top:12px;gap:8px;flex-wrap:wrap"><button class="btn" @click="vincular" :disabled="!puede || guardando">{{guardando ? 'Conectando…' : 'Conectar con el código'}}</button><button class="btn ghost" @click="conCodigo = false">Volver</button></div>
        </template>
        <template v-if="puede && !(otra && est.terminal)">
          <a v-if="est.terminal && !enCurso" class="link small" style="display:block;margin-top:12px;cursor:pointer" @click="otra = true">Conectar otra empresa en esta computadora</a>
          <p v-else-if="!est.terminal" class="small muted" style="margin:12px 0 0">Para agregar otra empresa a esta computadora, conecte primero esta empresa con «Conectar con mi cuenta». Después aparece aquí «Conectar otra empresa en esta computadora».</p>
        </template>
      </div>
      <div class="card" v-if="cuentas && cuentas.cuentas && cuentas.cuentas.length"><h2>Cuentas que solo existen en esta computadora</h2>
        <p class="small muted" style="margin:0 0 10px" v-if="est.vinculado || est.terminal">Estas cuentas se crearon aquí y no están en la página web. Ya no pueden entrar al programa. Si la persona necesita entrar, agréguela en la página web, en Configuración › Usuarios.</p>
        <p class="small muted" style="margin:0 0 10px" v-else>Estas cuentas se crearon aquí y no están en la página web. Cuando conecte esta computadora con la página web dejarán de entrar al programa: si la persona necesita entrar, agréguela en la página web, en Configuración › Usuarios.</p>
        <p class="small" style="margin:0 0 10px;color:var(--danger)" v-if="!cuentas.retiradas">Modo soporte: mientras esté activo, estas cuentas todavía pueden entrar.</p>
        <table class="tbl"><thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th></tr></thead>
          <tbody><tr v-for="c in cuentas.cuentas" :key="c.correo"><td><b>{{c.nombre}}</b></td><td class="small">{{c.correo}}</td><td class="small">{{c.admin_sistema ? 'Administrador de esta computadora' : (c.rol || '—')}}</td></tr></tbody></table>
      </div>
      <div class="card" v-if="est.vinculado && !est.revocada_en"><h2>Instalación local vinculada a la nube</h2>
        <div class="grid cols-2 small" style="gap:6px 20px">
          <div><b>Nube:</b> {{est.url}}</div><div><b>Esta instalación:</b> {{est.nombre}} · terminal {{String(est.terminal).padStart(5, '0')}}<span v-if="est.fijas && est.fijas.sucursal"> · sucursal {{String(est.fijas.sucursal).padStart(3, '0')}}</span></div>
          <div v-if="est.fijas" class="muted" style="grid-column:1/-1">{{est.fijas.sucursal ? 'La terminal y la sucursal de esta computadora quedaron fijas' : 'La terminal de esta computadora quedó fija'}} al vincularla: no se cambian aquí ni en Configuración › Hacienda, porque con otro número se repetirían consecutivos.</div>
          <div><b>Última bajada:</b> {{est.ultima_bajada ? fechaHora(est.ultima_bajada) : 'todavía no'}}<span v-if="est.clientes !== undefined && est.clientes !== null"> · {{est.clientes}} clientes, {{est.productos}} ítems<span v-if="est.existencias"> · {{est.existencias}} existencias igualadas</span></span></div>
          <div><b>Última subida:</b> {{est.ultima_subida ? fechaHora(est.ultima_subida) : 'todavía no'}}</div>
          <div><b>Pendientes de subir:</b> <span :class="est.pendientes ? 'badge warn' : 'badge ok'">{{est.pendientes}} comprobantes</span> <span :class="est.pagos_pendientes ? 'badge warn' : 'badge ok'">{{est.pagos_pendientes || 0}} cobros</span></div>
          <div v-if="est.subidos"><b>Subido a la nube:</b> {{est.subidos.documentos || 0}} comprobantes · {{est.subidos.pagos || 0}} cobros · {{est.subidos.registros || 0}} cambios de caja y hotel · {{est.subidos.clientes || 0}} clientes e ítems</div>
          <div v-if="est.ultimo_error" style="color:var(--danger);grid-column:1/-1"><b>Último error:</b> {{est.ultimo_error}}</div>
          <div v-if="est.aviso" style="color:var(--warn, #b45309);grid-column:1/-1"><b>Aviso:</b> {{est.aviso}}</div>
        </div>
        <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn" @click="ahora" :disabled="guardando || est.sincronizando">{{guardando || est.sincronizando ? 'Sincronizando…' : 'Sincronizar ahora'}}</button><button class="btn ghost" @click="cargar">Actualizar</button><span style="flex:1"></span><button class="btn ghost" @click="desvincular" :disabled="!puede">Desvincular</button></div>
        <template v-if="puede">
          <a v-if="!otra" class="link small" style="display:inline-block;margin-top:12px;cursor:pointer" @click="otra = true">Conectar otra empresa en esta computadora</a>
          <div v-else style="max-width:520px;margin-top:14px"><h3 style="margin:0 0 6px">Conectar otra empresa en esta computadora</h3>
            <p class="small muted" style="margin:0 0 10px">Para trabajar aquí con otra empresa suya. Un administrador de esa empresa lo aprueba en {{web || 'la página web'}}: elija ahí la otra empresa. La empresa abierta no cambia.</p>
            <ConexionLocal ref="otraCx" :web="web" :equipo="est.nombre || equipo" con-sesion otra-empresa boton="Conectar otra empresa" @lista="otraLista" @retirada="retirada" @estado="otraEstado"></ConexionLocal>
            <a class="link small" style="display:inline-block;margin-top:10px;cursor:pointer" @click="volverDeOtra">Volver</a>
          </div>
        </template>
        <p class="small muted" style="margin:10px 0 0">Se sincroniza sola cada dos minutos mientras haya internet. Sin internet, esta instalación sigue emitiendo, firmando e imprimiendo; los comprobantes se envían a Hacienda y se suben a la nube cuando vuelve la conexión. Suben también los cobros, las cajas y ventas del punto de venta, las reservas, huéspedes y folios del hotel y los clientes o ítems creados aquí; bajan los catálogos, la configuración y las existencias (la nube manda en el inventario).</p>
      </div>
      <div class="card"><h2>Red local: las otras computadoras de este negocio</h2>
        <p class="small muted" style="margin:0 0 10px">Las computadoras del mismo local se mandan directamente lo que cambia (comprobantes, cuentas abiertas, cajas y ventas, reservas, clientes e ítems nuevos) sin pasar por la nube ni necesitar internet. Ninguna es indispensable: cada una guarda todo. Pasos: 1) en todas, abra el programa con la opción de red (<span class="mono">--red</span>) y acepte el aviso del cortafuegos de Windows; 2) escriba la misma clave de red en todas; 3) en cada una, agregue las demás por su dirección.</p>
        <div class="small" style="margin:0 0 10px" v-if="est.direcciones && est.direcciones.length"><b>Dirección de esta computadora para las demás:</b> <span class="mono" v-for="d in est.direcciones" :key="d" style="margin-right:10px">{{d}}</span></div>
        <div class="grid cols-2">
          <Field :label="est.red && est.red.clave_definida ? 'Clave de red (definida; escriba otra solo para cambiarla)' : 'Clave de red (la misma en todas las computadoras)'" :req="!(est.red && est.red.clave_definida)"><input v-model="red.clave" type="password" minlength="6" placeholder="mínimo 6 caracteres" autocomplete="new-password"></Field>
          <div class="row" style="align-items:flex-end"><button class="btn" @click="guardarRed" :disabled="!puede || guardando || (!red.clave && !(est.red && est.red.clave_definida))">Guardar clave</button></div>
        </div>
        <h3 style="margin:14px 0 6px">Computadoras</h3>
        <Empty v-if="!red.pcs.length" icon="🖧" title="Sin otras computadoras" text="Agregue las demás computadoras del local por su dirección (la que muestra cada una en esta misma pantalla)."></Empty>
        <table class="tbl" v-else><thead><tr><th>Nombre</th><th>Dirección</th><th>Último envío</th><th class="num">Enviado</th><th></th></tr></thead>
          <tbody><tr v-for="(p, i) in red.pcs" :key="p.url"><td><b>{{p.nombre}}</b></td><td class="mono small">{{p.url}}</td>
            <td class="small">{{p.ultimo_ok ? fechaHora(p.ultimo_ok) : 'todavía no'}}<div v-if="p.ultimo_error" style="color:var(--danger)">{{p.ultimo_error}}</div><div v-if="red.prueba && red.prueba.url === p.url" :style="{color: red.prueba.ok ? 'var(--ok, #15803d)' : 'var(--danger)'}">{{red.prueba.texto}}</div></td>
            <td class="num small" v-if="p.enviados">{{p.enviados.documentos || 0}} comprobantes · {{p.enviados.registros || 0}} cambios · {{p.enviados.catalogos || 0}} clientes e ítems</td><td class="num small" v-else>—</td>
            <td><div class="row" style="gap:6px;justify-content:flex-end"><button class="btn sm ghost" @click="probarPc(p)" :disabled="red.probando === p.url || !(est.red && est.red.clave_definida)">{{red.probando === p.url ? 'Probando…' : 'Probar'}}</button><button class="btn sm ghost" @click="quitarPc(i)" :disabled="!puede">Quitar</button></div></td></tr></tbody></table>
        <div class="grid cols-3" style="margin-top:10px;align-items:end">
          <Field label="Nombre"><input v-model="red.nuevo.nombre" maxlength="40" placeholder="Recepción"></Field>
          <Field label="Dirección" help="IP de esa computadora y puerto 8020"><input v-model="red.nuevo.url" placeholder="192.168.1.20:8020"></Field>
          <div class="row"><button class="btn ghost" @click="agregarPc" :disabled="!puede || guardando">Agregar computadora</button></div>
        </div>
        <div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap" v-if="red.pcs.length"><button class="btn" @click="enviarRed" :disabled="guardando || est.sincronizando">Enviar cambios ahora</button><span class="small muted">Se envían solos cada 30 segundos. Lo que llega de otra computadora no se vuelve a subir a la nube: lo sube la que lo creó.</span></div>
        <div class="small muted" style="margin-top:10px" v-if="est.red && est.red.recibido_de && Object.keys(est.red.recibido_de).length"><b>Recibido de:</b> <span v-for="(v, n) in est.red.recibido_de" :key="n" style="margin-right:12px">{{n}} (terminal {{v.terminal}}) · {{fechaHora(v.ultimo)}}</span></div>
      </div>
    </template>
    <template v-else-if="est">
      <div class="card"><h2>Computadoras conectadas</h2>
        <p class="small muted" style="margin:0 0 10px">Cada computadora con el programa tiene el sistema completo: trabaja sin internet y se sincroniza con la página web cuando hay conexión. Cada una recibe su propio número de terminal.</p>
        <Empty v-if="!inst || !inst.instalaciones.length" icon="💻" title="Todavía no hay computadoras conectadas." text="Cuando conecte una computadora aparecerá aquí con quién la conectó, su terminal y su última sincronización."></Empty>
        <table class="tbl" v-else><thead><tr><th>Nombre</th><th>Conectada por</th><th class="num">Terminal</th><th>Vinculada</th><th>Última bajada</th><th>Última subida</th><th class="num">Comprobantes</th><th class="num">Cobros</th><th class="num">Caja y hotel</th><th>Versión</th><th></th></tr></thead>
          <tbody><tr v-for="i in inst.instalaciones" :key="i.terminal"><td><b>{{i.nombre}}</b><div class="small muted">Identificador: <span class="mono">{{i.prefijo}}…</span></div><span v-if="i.sin_estrenar" class="badge warn" title="Se aprobó, pero la computadora todavía no habló con la página web">Sin terminar de conectar</span></td><td class="small">{{i.por || '—'}}</td><td class="num">{{i.terminal}}</td><td class="small">{{fechaHora(i.creado)}}</td><td class="small">{{i.ultima_bajada ? fechaHora(i.ultima_bajada) : '—'}}</td><td class="small">{{i.ultima_subida ? fechaHora(i.ultima_subida) : '—'}}</td><td class="num">{{i.documentos || 0}}</td><td class="num">{{i.pagos || 0}}</td><td class="num">{{i.registros || 0}}</td><td class="small">{{i.version || '—'}}</td><td><div class="row" style="gap:6px;justify-content:flex-end"><button class="btn sm ghost" @click="renombrar(i)" :disabled="!puede">Renombrar</button><button class="btn sm ghost" @click="quitar(i)" :disabled="!puede">Revocar</button></div></td></tr></tbody></table>
        <p class="small muted" style="margin:8px 0 0">Lo que suben las instalaciones queda aquí como cualquier otro dato: los comprobantes en Ingresos › Facturas de venta con su terminal (rebajan el inventario), los cobros en Pagos recibidos (entran en Bancos), las cajas y ventas en el punto de venta y las reservas en el hotel. Lo que una instalación crea es de ella: si lo cambia aquí, el cambio no regresa a esa computadora. Al revocar una, deja de sincronizar con la nube y con las demás computadoras del local; a los 3 días se bloquea y a los 30 borra sus datos, salvo que se vincule de nuevo. Cada computadora trabaja con una llave propia de la empresa, que no depende de ninguna persona; se administra solo aquí.</p>
      </div>
      <div class="card"><h2>Conectar una computadora nueva</h2>
        <p class="small muted" style="margin:0 0 8px">Para el programa 4.25 o posterior. Si esa computadora tiene un programa anterior, use «Otra forma de conectar», más abajo.</p>
        <div v-if="instalador" style="margin:0 0 12px"><div class="row" style="gap:10px;align-items:center;flex-wrap:wrap"><a class="btn" href="/api/local/descargar" download="FISITAAPLocal.exe">Descargar el programa para Windows</a><span class="small muted">versión {{instalador.version}} · {{mb(instalador.bytes)}}</span></div>
          <p class="small muted" style="margin:6px 0 0">Windows puede avisar que no conoce al editor: toque «Más información» y después «Ejecutar de todas formas».</p></div>
        <ol class="small" style="margin:0 0 12px;padding-left:20px"><li>{{instalador ? 'Descargue el programa en esa computadora y ábralo.' : 'Instale el programa en la computadora y ábralo.'}}</li><li>Póngale un nombre y toque «Conectar esta computadora».</li><li>Se abre esta página: revise el código y apruebe. La página le muestra un número de comprobación: escríbalo en el programa.</li></ol>
        <button class="btn" @click="tengoCodigo" :disabled="!puede">Tengo un código del programa</button>
      </div>
      <details class="card"><summary style="cursor:pointer"><b>Otra forma de conectar (programas anteriores a la 4.25 o soporte)</b></summary>
        <p class="small muted" style="margin:10px 0">Para una computadora con un programa anterior a la 4.25, o si soporte se lo pide: genere un código. Vale 15 minutos y se usa una sola vez.</p>
        <div class="row" style="gap:10px;align-items:center;flex-wrap:wrap"><button class="btn sec" @click="generar" :disabled="!puede">Generar código</button><span v-if="codigo" class="mono" style="font-size:22px;font-weight:700;letter-spacing:1px">{{codigo.codigo}}</span><span v-if="codigo" class="small muted">vale hasta {{fechaHora(codigo.vence)}}</span></div>
        <ul class="small" style="margin:10px 0 0;padding-left:20px">
          <li><b>Programa anterior a la 4.25:</b> en esa computadora entre a Configuración › Instalación local. En «Vincular esta instalación con la nube» escriba en «Dirección de la nube» la dirección de este sitio, <b class="mono">{{origen}}</b>, y en «Código de vinculación» el código que generó aquí.</li>
          <li><b>Programa 4.25 o posterior</b> (solo si soporte se lo pide): escriba el código en el programa, en «Tengo un código».</li>
        </ul>
        <p class="small" style="margin:8px 0 0;color:var(--danger)" v-if="codigo">Con el código, la instalación recibe las credenciales de Hacienda de la empresa (usuario, clave y llave): compártalo solo con quien instala.</p>
      </details>
    </template>
    <div class="card" v-if="verPisados && est"><h2>Cambios que no quedaron</h2>
      <p class="small muted" style="margin:0 0 10px">Cuando dos personas cambian lo mismo y uno de los cambios no queda, aquí lo puede ver. La lista es solo para leer.</p>
      <a class="btn sec" href="#/sinc/pisados">Ver los cambios que no quedaron</a>
    </div>
  </div>`,
};
