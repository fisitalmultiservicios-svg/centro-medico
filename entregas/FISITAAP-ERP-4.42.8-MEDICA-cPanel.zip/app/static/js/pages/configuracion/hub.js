// Configuración — hub de secciones. Cabecera con datos reales de la empresa (store.empresa); régimen/plan desde datos de ejemplo (mock 'empresa_extra').
import { CAT, mock, monedas } from '../../api.js';
import { store, sesion, rutaPermitida } from '../../app.js';
import { PERMISO_CONFIG } from '../../menu.js';   // 3.87: la misma tabla decide la portada y la ruta escrita a mano

export const GRUPOS = [
  // 3.37: un solo lugar para configurar. Una entrada que empieza con «/» abre una pantalla de su módulo (misma dirección de siempre);
  // las demás son secciones de Configuración. Cada tarjeta y enlace se filtra por rol, tipo de negocio y plan.
  { nombre: 'Empresa', ico: '🏢', desc: 'Datos, usuarios y plan.', links: [['empresa', 'Empresa'], ['sucursales', 'Sucursales'], ['marcas', 'Marcas y logos'], ['usuarios', 'Usuarios y roles'], ['perfil', 'Mi perfil'], ['monedas', 'Monedas'], ['suscripcion', 'Suscripción y planes']] },
  { nombre: 'Facturación', ico: '🧾', desc: 'Hacienda, numeraciones e impuestos.', links: [['hacienda', 'Hacienda'], ['numeraciones', 'Numeraciones'], ['terminos-pago', 'Términos de pago'], ['otros-cargos', 'Otros cargos'], ['vendedores', 'Vendedores'], ['impuestos', 'Impuestos'], ['retenciones', 'Retenciones']] },
  { nombre: 'Documentos e impresión', ico: '🖨', desc: 'Lo que ve el cliente en papel y correo.', links: [['plantillas', 'Plantillas de impresión'], ['documentos', 'Datos por documento'], ['plantillas-correo', 'Plantillas de correo'], ['notificaciones', 'Notificaciones de cobro']] },
  { nombre: 'Inventario', ico: '▦', desc: 'Catálogos de los ítems y método de costeo.', links: [['inventario-costeo', 'Método de costeo (promedio, PEPS, UEPS)'], ['/inventario/bodegas', 'Bodegas'], ['/inventario/categorias', 'Categorías'], ['/inventario/atributos', 'Atributos'], ['/inventario/listas-precios', 'Listas de precios'], ['campos-adicionales', 'Campos adicionales'], ['variantes', 'Variantes']] },
  { nombre: 'Punto de venta', ico: '🛒', desc: 'Cajas, cobro y comprobante.', links: [['/pos/configuracion?ir=caja', 'Caja y comprobante'], ['/pos/configuracion?ir=cuentas', 'Medios de pago y cuentas'], ['/pos/configuracion?ir=carga', 'Qué carga cada caja'], ['/pos/configuracion?ir=servicio', 'Impuesto de servicio'], ['/pos/configuracion?ir=carrito', 'Carrito y rejilla'], ['/pos/configuracion?ir=promos', 'Promociones y combos']] },
  { nombre: 'Restaurante', ico: '🍽', desc: 'Solo si hay mesas o cocina.', links: [['/pos/configuracion?ir=restaurante', 'Comandas, saloneros y clave de supervisor'], ['/pos/configuracion?ir=mesas', 'Plano de mesas']] },
  { nombre: 'Impresoras y equipos', ico: '🖨', desc: 'Lo que se conecta a la caja.', links: [['/pos/configuracion?ir=impresoras', 'Impresoras de tiquete y comanda'], ['/pos/configuracion?ir=impresion', 'Impresión del tiquete']] },
  { nombre: 'Hotel', ico: '🛏', desc: 'Habitaciones, tarifas y reglas.', links: [['/hotel/configuracion?tab=hotel', 'Datos del hotel'], ['/hotel/configuracion?tab=categorias', 'Categorías'], ['/hotel/configuracion?tab=habitaciones', 'Habitaciones'], ['/hotel/configuracion?tab=tarifas', 'Temporadas y precios'], ['/hotel/configuracion?tab=politicas', 'Políticas y mensajes'], ['/hotel/configuracion?tab=automatico', 'Automático e iCal']] },
  { nombre: 'Servicios y eventos', ico: '🧖', desc: 'Catálogos de lo que se vende aparte.', links: [['/hotel/servicios?tab=catalogo', 'Catálogo de servicios'], ['/hotel/eventos?tab=salones', 'Salones']] },
  { nombre: 'Ama de llaves y mantenimiento', ico: '🧹', desc: 'Tipos de problema que se reportan.', links: [['/hotel/ama-de-llaves/tipos', 'Tipos de problema de limpieza'], ['/hotel/mantenimiento/tipos', 'Tipos de problema de mantenimiento']] },
  { nombre: 'Contabilidad', ico: '≡', desc: 'Catálogos y parámetros contables.', links: [['/contabilidad/catalogo', 'Catálogo de cuentas'], ['/contabilidad/centros-costo', 'Centros de costo'], ['contabilidad-parametrizacion', 'Parametrización'], ['contabilidad-periodos', 'Periodos'], ['contabilidad-tipos-asiento', 'Tipos de asientos'], ['contabilidad-numeraciones', 'Numeraciones contables'], ['contabilidad-registros', 'Actualizar registros']] },
  { nombre: 'Recursos humanos', ico: '👥', desc: 'Lo que no cambia cada mes.', links: [['/rrhh/parametros', 'Parámetros (CCSS, renta, jornadas)'], ['/rrhh/conceptos', 'Deducciones e ingresos fijos'], ['/rrhh/horarios?tab=config', 'Departamentos y turnos']] },
  { nombre: 'Integraciones', ico: '⇄', desc: 'Conexiones con otros sistemas.', links: [['integraciones', 'Integraciones y API'], ['instalacion-local', 'Instalación local'], ['ia', 'Asistente con IA']] },
  { nombre: 'Sistema', ico: '🛠', desc: 'Preferencias, historial y datos.', links: [['preferencias', 'Preferencias'], ['exportar', 'Exportar datos'], ['respaldos', 'Respaldos'], ['historial-correos', 'Historial de correos'], ['historial-operaciones', 'Historial de operaciones'], ['perfil?tab=version', 'Versión del sistema']] },
];

// 3.32: permiso que pide cada opción; el hub solo muestra lo que el rol puede usar (el servidor igual valida al guardar).
// 3.87: la tabla vive en menu.js (PERMISO_CONFIG) para que la sección escrita a mano diga «Sin acceso» con la misma regla
export { PERMISO_CONFIG };
export const puedeConfig = slug => {
  if (slug.startsWith('/')) return rutaPermitida(slug.split('?')[0]);      // pantalla de un módulo: mismas reglas que el menú (rol, tipo de negocio y plan) (3.37)
  slug = slug.split('?')[0];
  const p = PERMISO_CONFIG[slug] || (slug.startsWith('contabilidad-') ? 'contabilidad' : 'configurar');
  return [].concat(p).every(x => sesion.puede(x)) && rutaPermitida('/configuracion/' + slug);      // 3.87: una opción puede pedir varios (Respaldos)
};
export const hrefConfig = slug => '#' + (slug.startsWith('/') ? slug : '/configuracion/' + slug);

export default {
  props: ['params'],
  data() { return { q: '', extra: mock.get('empresa_extra', { regimen: 'tradicional', plan: 'Contabilidad · anual' }) }; },
  computed: {
    e() { return store.empresa; },
    grupos() {
      const q = this.q.trim().toLowerCase();
      const permitidos = GRUPOS.map(g => ({ ...g, links: g.links.filter(l => puedeConfig(l[0])) })).filter(g => g.links.length);
      if (!q) return permitidos;
      return permitidos.map(g => ({ ...g, links: g.links.filter(l => (l[1] + ' ' + g.nombre).toLowerCase().includes(q)) })).filter(g => g.links.length);
    },
    moneda() { const m = monedas.principal(); return m ? m.codigo + ' - ' + m.nombre : 'CRC'; },
  },
  methods: { ir(slug) { location.hash = '/configuracion/' + slug; } },
  template: `
  <div class="page">
    <PageHead title="Configuración" sub="Administre los datos de su empresa y personalice el sistema a su medida."></PageHead>

    <div class="card">
      <div class="row" style="gap:24px;align-items:flex-start;flex-wrap:wrap">
        <div style="width:64px;height:64px;border-radius:12px;background:var(--primary-soft);color:var(--primary);display:grid;place-items:center;font-size:28px;font-weight:700">{{(e?.nombre_comercial || e?.nombre || 'E').slice(0,1)}}</div>
        <div style="flex:1;min-width:240px">
          <h2 style="margin:0 0 4px">{{e?.nombre_comercial || e?.nombre || 'Empresa sin configurar'}}</h2>
          <div class="muted small" v-if="e">{{e.nombre}}</div>
          <div class="alert warn" v-else style="margin:8px 0 0">Todavía no ha configurado la empresa emisora. <a href="#/configuracion/empresa">Configurar ahora</a></div>
        </div>
        <div class="grid" style="flex:2;min-width:320px">
          <div><div class="small muted">Identificación</div><b class="mono">{{e ? (CAT.tipoId[e.tipo_id] || e.tipo_id) + ' · ' + e.numero_id : '—'}}</b></div>
          <div><div class="small muted">Régimen</div><b>{{extra.regimen === 'simplificado' ? 'Régimen simplificado' : 'Régimen tradicional'}}</b></div>
          <div><div class="small muted">Versión de facturación</div><b>4.4</b></div>
          <div><div class="small muted">Moneda principal</div><b>{{moneda}}</b></div>
          <div><div class="small muted">{{e?.factura_electronica === false ? 'Facturación electrónica' : 'Ambiente Hacienda'}}</div><Badge :value="e?.factura_electronica === false ? 'Apagada · comprobantes internos' : (e?.ambiente === 'produccion' ? 'Producción' : 'Pruebas (sandbox)')"></Badge></div>
        </div>
      </div>
    </div>

    <div class="toolbar"><input class="search" placeholder="Buscar una opción de configuración" v-model="q"></div>

    <Empty v-if="!grupos.length" icon="⌕" title="Sin coincidencias" text="Pruebe con otro término, por ejemplo: numeraciones, impuestos, correo."></Empty>
    <div class="tiles" v-else>
      <div class="tile" v-for="g in grupos" :key="g.nombre" style="cursor:default">
        <h3>{{g.ico}} {{g.nombre}}</h3>
        <p>{{g.desc}}</p>
        <div class="links"><a v-for="l in g.links" :key="l[0]" :href="hrefConfig(l[0])">{{l[1]}}</a></div>
      </div>
    </div>
  </div>`,
  setup() { return { store, CAT, hrefConfig }; },
};
