// Configuración › Asistente con IA (3.56): la empresa enciende el asistente y elige dónde lo usa (catálogo en línea, resumen del
// negocio, descripciones de ítems, borradores de tickets). La clave y el modelo los pone el administrador del sistema.
import { api, toast } from '../../api.js';
import { sesion } from '../../app.js';

export default {
  props: ['params'],
  data() { return { c: null, uso: null, guardando: false }; },
  computed: { puede() { return sesion.puede('configurar'); } },
  methods: {
    async cargar() { try { this.c = await api('/api/ia/config'); } catch (e) { toast(e.message, 'err'); } try { this.uso = await api('/api/ia/uso'); } catch { this.uso = null; } },
    async guardar() {
      this.guardando = true;
      try { this.c = await api('/api/ia/config', { method: 'PUT', body: { activo: !!this.c.activo, catalogo: !!this.c.catalogo, resumen: !!this.c.resumen, productos: !!this.c.productos, tickets: !!this.c.tickets } }); toast('Guardado', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Asistente con IA" sub="Respuestas automáticas a los clientes en el catálogo, resumen del negocio, descripciones de ítems y borradores de respuesta a tickets." :crumbs="[{label:'Configuración',to:'/configuracion'},{label:'Asistente con IA'}]">
      <button class="btn" @click="guardar" :disabled="guardando || !c || !puede">Guardar</button>
    </PageHead>
    <template v-if="c">
      <div class="alert" :class="c.disponible ? (c.activo ? 'ok' : 'info') : 'warn'" style="margin-bottom:12px">
        <span v-if="!c.disponible">El asistente con IA no está configurado en este servidor. Pídaselo al administrador del sistema.</span>
        <span v-else-if="c.activo">Asistente ENCENDIDO · modelo {{c.modelo}} · {{c.uso_mes}} de {{c.limite_mes || 'sin límite'}} consultas usadas este mes.</span>
        <span v-else>Asistente apagado. Enciéndalo y elija dónde lo quiere usar. Modelo disponible: {{c.modelo}}.</span>
      </div>
      <div class="card"><h2>Dónde se usa</h2>
        <div style="display:flex;flex-direction:column;gap:10px">
          <Toggle v-model="c.activo" label="Encender el asistente con IA en esta empresa" :disabled="!c.disponible"></Toggle>
          <Toggle v-model="c.catalogo" label="Botón «Preguntar» en el catálogo en línea: responde a los clientes con el menú, precios y horarios" :disabled="!c.activo || !c.tiene_catalogo"></Toggle>
          <p class="small muted" style="margin:-6px 0 0 0" v-if="!c.tiene_catalogo">El catálogo en línea (Ventas en línea) no está en su plan: esta opción queda apagada.</p>
          <Toggle v-model="c.resumen" label="«Resumen con IA» en Inicio: ventas, pedidos y tickets del periodo en lenguaje sencillo" :disabled="!c.activo"></Toggle>
          <Toggle v-model="c.productos" label="«Redactar con IA» la descripción pública de los ítems del catálogo" :disabled="!c.activo"></Toggle>
          <Toggle v-model="c.tickets" label="«Borrador con IA» de la respuesta al cliente en los tickets de TiKe" :disabled="!c.activo || !c.tiene_tike"></Toggle>
        </div>
        <p class="small muted" style="margin:10px 0 0">El asistente solo usa los datos de su empresa que están en el sistema y no guarda las conversaciones del catálogo. Cada consulta cuenta para el límite mensual que fija el administrador del sistema.</p>
      </div>
      <div class="card" style="margin-top:12px" v-if="uso"><h2>Consumo del mes {{uso.mes}}</h2>
        <div class="grid cols-4">
          <div><div class="small muted">Consultas</div><div style="font-size:22px;font-weight:800">{{uso.consultas}}<span class="small muted" v-if="uso.limite_mes"> / {{uso.limite_mes}}</span></div></div>
          <div><div class="small muted">Catálogo</div><div style="font-size:22px;font-weight:800">{{uso.por_tipo.catalogo || 0}}</div></div>
          <div><div class="small muted">Resúmenes y descripciones</div><div style="font-size:22px;font-weight:800">{{(uso.por_tipo.resumen || 0) + (uso.por_tipo.producto || 0)}}</div></div>
          <div><div class="small muted">Tickets</div><div style="font-size:22px;font-weight:800">{{uso.por_tipo.ticket || 0}}</div></div>
        </div>
      </div>
    </template>
  </div>`,
  setup() { return { sesion }; },
};
