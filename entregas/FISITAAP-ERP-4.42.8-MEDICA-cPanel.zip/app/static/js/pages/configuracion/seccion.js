// Configuración — todas las secciones (#/configuracion/:seccion). Usan backend real: "empresa", "hacienda", "documentos" (GET/PUT /api/empresa, POST /api/empresa/certificado, /api/empresa/logo, /api/config/documentos, POST /api/pdf/documento), "usuarios" y "perfil" (/api/auth/*), "historial-operaciones" (/api/auth/auditoria) e "historial-correos" (parcial, /api/comprobantes); el resto guarda sus registros en el servidor por empresa (mock.get/set → /api/registros) y solo en modo demo precarga ejemplos.
import { api, toast, money, fmt, fecha, hoy, mock, CAT, opts, monedas, token, fechaHora, cabecerasAuth, demo, claveFacil, red } from '../../api.js';   // 4.5: red.enLinea para el logo sin conexión
import { exportarFilas, exportarTabla } from '../reportes/_montos.js';
import { store, sesion, SelectorPaleta } from '../../app.js';
import { aplicarPaleta } from '../../paletas.js';
import { cantones, distritos } from '../../ubicaciones.js';
import { DEF as PARAM_DEF, SECCIONES as PARAM_SECCIONES, paramContable } from '../contabilidad/parametros.js';
import { planCuentas } from '../contabilidad/catalogo.js';
import { sincronizarAutomaticos, resumenSync } from '../contabilidad/automaticos.js';
import { asientoCierre, planConUsadas } from '../contabilidad/_mayor.js';
import { periodoCerrado } from '../contabilidad/parametros.js';
import { TIPOS_ASIENTO } from '../contabilidad/asientos.js';
import SecMarcas from './marcas.js';   /* 3.45 */
import { AVISO_RRHH_MFA } from '../../menu.js';   // 4.7: aviso de Recursos humanos sin la verificación en dos pasos
import RenunciaMfa, { fechaRenuncia, marcaRenuncia, estadoRenuncia, claseRenuncia } from '../../renuncia-mfa.js';   // 4.7: renuncia a la verificación (descargo)

// ------------------------------------------------------------------ utilidades comunes
const SecHead = {
  props: { title: String, sub: String, mock: Boolean, soon: Boolean },
  template: `<PageHead :title="title" :sub="sub" :mock="mock" :soon="soon" :crumbs="[{label:'Configuración',to:'/configuracion'},{label:title}]"><slot></slot></PageHead>`,
};

const CUENTAS = ['1.1.01.01.02 Caja general', '1.1.01.02.01.01 Banco Nacional', '1.1.01.02.02.01 Banco De Costa Rica', '1.1.02.01.01 Cuentas por cobrar clientes nacionales', '1.1.02.04.06 Devoluciones a proveedores', '1.1.05.01 Retenciones a favor', '1.1.06.01 Inventario de mercancías', '2.1.01.01.01 Cuentas por pagar a proveedores nacionales', '2.1.01.03.01 Devoluciones de clientes', '1.1.04.01.01.01 IVA crédito fiscal', '1.1.04.02.01 IVA soportado', '2.1.04.01.01.01 IVA débito fiscal', '2.1.05.04 Cuentas por pagar otros Cargos', '2.1.06.01 Retenciones por pagar', '3.1.01.01 Capital social suscrito', '3.3.01 Utilidad del ejercicio', '3.4 Ganancias acumuladas', '3.6.01 Ajustes iniciales en bancos', '3.6.02 Ajustes iniciales en inventario', '4.1.01 Ventas', '4.1.02 Devoluciones en ventas', '4.2.02.01 Ganancia por diferencia en cambio', '4.2.02.02 Ajustes por aproximaciones en cálculos', '5.1.01 Costos de la mercancía vendida', '5.1.01.02 Ajustes al inventario', '5.1.02 Costo de los servicios vendidos', '6.4.02 Pérdida por diferencia en cambio', '6.4.03 Ajustes por aproximaciones en cálculos', '6.2.02.01 Servicios profesionales', '6.2.02.20 Otros gastos generales', '6.2.01.01 Sueldos y salarios', '6.2.01.02 Horas extras', '6.2.01.03 Gastos por cargas sociales', '6.2.01.06 Vacaciones', '6.2.01.07 Cesantia', '6.2.01.08 Aguinaldo', '6.2.01.09 Seguro de riesgos del trabajo (INS)', '2.1.02.01.01.01 Salarios por pagar', '2.1.02.01.01.02 Liquidaciones laborales por pagar', '2.1.02.01.02 Aguinaldo por pagar (provisión)', '2.1.02.01.03 Vacaciones por pagar (provisión)', '2.1.02.01.04 Cesantía por pagar (provisión)', '2.1.02.02.01 Retención laboral CCSS por pagar', '2.1.02.02.02 Impuesto de renta al salario por pagar', '2.1.02.02.04 Cargas sociales patronales CCSS por pagar', '2.1.02.02.05 INS riesgos del trabajo por pagar', '2.1.02.02.06 Embargos y pensiones alimentarias por pagar', '1.1.01.02.01.02 Banco Nacional dólares', '1.1.02.01.02 Cuentas por cobrar clientes internacionales', '6.5.01.02 Timbre de Benemérito Cuerpo de Bomberos de Costa Rica', '6.5.02 Gastos por cobro de un tercero', '6.5.03 Costos de Exportación', '6.5.04 Timbre de Colegio Profesionales', '6.5.05 Impuesto de servicio 10%'];
const pad = (n, l) => String(n ?? '').padStart(l, '0');
const siNo = v => (v ? 'Sí' : 'No');
const hace = (d) => { const x = new Date(); x.setDate(x.getDate() - d); return x.toISOString(); };

// Fábrica de secciones tipo lista (tabla + modal de alta/edición) con datos de ejemplo.
function listaSimple(cfg) {
  return {
    components: { SecHead },
    data() {
      // cfg.base: valores por defecto del sistema (términos de pago, IVA, numeraciones, otros cargos). Sin base: solo ejemplos (demo).
      const semilla = cfg.semilla.map((x, i) => ({ id: i + 1, ...x }));
      const rows = cfg.base ? (mock.get(cfg.clave, null) || semilla) : mock.ejemplos(cfg.clave, semilla, 'nombre');   // se guarda al cambiar algo
      return { cfg, rows, q: '', modal: false, form: {} };
    },
    methods: {
      nuevo() { this.form = { id: null }; for (const c of cfg.campos) this.form[c.key] = c.def ?? (c.tipo === 'check' ? false : ''); this.modal = true; },
      editar(r) { this.form = { ...r }; this.modal = true; },
      guardar() {
        for (const c of cfg.campos) if (c.req && String(this.form[c.key] ?? '').trim() === '') return toast('El campo "' + c.label + '" es obligatorio', 'err');
        if (this.form.id) { const i = this.rows.findIndex(x => x.id === this.form.id); this.rows.splice(i, 1, { ...this.form }); }
        else this.rows.push({ ...this.form, id: mock.nextId(this.rows, cfg.clave) });
        mock.set(cfg.clave, this.rows); this.modal = false; toast('Guardado correctamente', 'ok');
      },
      eliminar(r) {
        if (cfg.fijo && cfg.fijo(r)) return toast('Este registro es del sistema y no se puede eliminar');
        if (!confirm('¿Eliminar "' + (r.nombre || r.id) + '"?')) return;
        this.rows.splice(this.rows.indexOf(r), 1); mock.set(cfg.clave, this.rows); toast('Eliminado');
      },
      eliminarVarios(rows) {
        const ok = rows.filter(r => !(cfg.fijo && cfg.fijo(r))).map(r => r.id), omit = rows.length - ok.length;
        this.rows = this.rows.filter(r => !ok.includes(r.id)); mock.set(cfg.clave, this.rows);
        toast(ok.length + ' registros eliminados' + (omit ? '; ' + omit + ' del sistema omitidos' : ''), omit ? undefined : 'ok');
      },
      opciones(c) { return (c.opciones || []).map(o => (typeof o === 'string' ? { value: o, label: o } : o)); },
    },
    template: `
    <div class="page">
      <SecHead :title="cfg.titulo" :sub="cfg.sub"><button class="btn" @click="nuevo">{{cfg.textoNuevo || '+ Nuevo'}}</button></SecHead>
      <div class="card pad0">
        <div class="toolbar" style="padding:12px 12px 0"><input class="search" placeholder="Buscar" v-model="q"></div>
        <DataTable :rows="rows" :columns="cfg.columnas" :search="q" selectable :on-bulk-delete="eliminarVarios" :empty-title="cfg.vacioTitulo || 'Sin registros'" :empty-text="cfg.vacioTexto">
          <template #actions="{row}"><button class="btn icon" @click.stop="editar(row)" title="Editar">✎</button><button class="btn icon" @click.stop="eliminar(row)" title="Eliminar">🗑</button></template>
          <template #empty><button class="btn" @click="nuevo">{{cfg.textoNuevo || '+ Nuevo'}}</button></template>
        </DataTable>
      </div>
      <Modal v-if="modal" :title="(form.id ? 'Editar ' : 'Nuevo ') + (cfg.singular || 'registro')" @close="modal=false">
        <div class="grid cols-2">
          <template v-for="c in cfg.campos" :key="c.key">
            <label v-if="c.tipo==='check'" class="row" style="align-self:end;padding:8px 0"><input type="checkbox" v-model="form[c.key]"> {{c.label}}</label>
            <Field v-else :label="c.label" :req="c.req" :help="c.help" :style="c.ancho ? 'grid-column:1/-1' : ''">
              <select v-if="c.tipo==='select'" v-model="form[c.key]"><option v-for="o in opciones(c)" :key="o.value" :value="o.value">{{o.label}}</option></select>
              <textarea v-else-if="c.tipo==='textarea'" v-model="form[c.key]" rows="3"></textarea>
              <input v-else-if="c.tipo==='number'" type="number" step="any" v-model.number="form[c.key]">
              <input v-else v-model="form[c.key]" :placeholder="c.placeholder || ''">
            </Field>
          </template>
        </div>
        <template #foot><button class="btn sec" @click="modal=false">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
      </Modal>
    </div>`,
  };
}

// ------------------------------------------------------------------ Empresa (backend real)
// Teléfono: solo 8 dígitos (se quitan guiones, espacios y el 506 inicial). Devuelve null si está vacío.
export function telefono8(v) { let d = String(v ?? '').replace(/\D/g, ''); if (d.length === 11 && d.startsWith('506')) d = d.slice(3); return d ? +d : null; }
const EMPRESA_BASE = () => ({ nombre: '', nombre_comercial: '', tipo_id: '02', numero_id: '', actividad: '', provincia: 1, canton: 1, distrito: 1, barrio: '', otras_senas: '', telefono: null, correo: '', sucursal: 1, terminal: 1, proveedor_sistemas: '', ambiente: 'sandbox', usuario_hacienda: '', password_hacienda: '', smtp_host: '', smtp_puerto: 465, smtp_usuario: '', smtp_password: '', smtp_remitente: '', smtp_seguridad: 'ssl', smtp_nombre: '', smtp_copia: '', correo_automatico: true, actividad_nombre: '', sitio_web: '', margen_cambiario: 5, registro_fiscal_8707: '', factura_electronica: true });
// 4.31 (16a): los datos de la empresa que manda la página web a un programa conectado (CAMPOS_EMPRESA del servidor que trae EmpresaIn, sin
// la sucursal, que tiene su propia regla). En el programa conectado se ven deshabilitados con la nota y no se cambian aquí.
const CAMPOS_WEB = ['nombre', 'nombre_comercial', 'tipo_id', 'numero_id', 'actividad', 'provincia', 'canton', 'distrito', 'barrio', 'otras_senas', 'telefono', 'correo', 'proveedor_sistemas', 'ambiente', 'registro_fiscal_8707', 'factura_electronica'];
function textoSoloWeb(url) { let w = ''; try { w = url ? new URL(url).host : ''; } catch { w = ''; } return 'Se cambia en la página web (' + (w || 'la página web') + ').'; }
// Construye el cuerpo completo de EmpresaIn a partir de la empresa cargada + cambios. 4.31 (16a): lleva además «antes», lo que tenían los
// datos que manda la web al cargarse la pantalla (en el programa conectado el servidor ignora lo que no se cambió y rechaza lo cambiado).
function cuerpoEmpresa(actual, cambios) {
  const out = cuerpoBase(actual, cambios);
  if (actual) { const a = cuerpoBase(actual, {}); out.antes = {}; for (const k of CAMPOS_WEB) out.antes[k] = a[k]; }
  return out;
}
function cuerpoBase(actual, cambios) {
  const base = EMPRESA_BASE(), out = {};
  for (const k of Object.keys(base)) { const v = cambios[k] !== undefined ? cambios[k] : (actual || {})[k]; out[k] = v === undefined || v === null ? base[k] : v; }
  out.telefono = telefono8(out.telefono);
  for (const k of ['provincia', 'canton', 'distrito', 'sucursal', 'terminal', 'smtp_puerto']) out[k] = +out[k] || base[k];
  out.nombre_comercial = out.nombre_comercial || null; out.barrio = out.barrio || null; out.proveedor_sistemas = out.proveedor_sistemas || null;
  out.sitio_web = String(out.sitio_web || '').trim() || null;
  out.registro_fiscal_8707 = String(out.registro_fiscal_8707 || '').trim().slice(0, 12) || null;
  return out;
}
const EXTRA_BASE = () => ({ registro_alcohol: '', regimen: 'tradicional', sector: '', empleados: '', moneda: 'CRC', precision: 2, separador: ',', secundarias: [], plan: 'Contabilidad · anual' });

const SecEmpresa = {
  components: { SecHead },
  data() { return { e: null, f: EMPRESA_BASE(), extra: { ...EXTRA_BASE(), ...mock.get('empresa_extra', {}) }, actividades: [], nuevaSec: '', buscando: false, guardando: false, logo: null, logoPendiente: false, subiendoLogo: false, CAT, monedaOpts: monedas.opciones(),
    soloWeb: '' }; },   /* 4.31 (16a): en el programa conectado, la nota «Se cambia en la página web (…)» de los datos que manda la web */
  computed: {
    // 4.21: la actividad económica y la dirección solo las pide Hacienda: se exigen únicamente a quien emite comprobantes electrónicos.
    // Ni con la facturación electrónica apagada ni con «No contribuyente» (06), que al guardar queda sin facturación electrónica.
    exigeFiscal() { return !((this.e && this.e.factura_electronica === false) || this.f.tipo_id === '06'); },
    estadoFE() {   // revisa llave, PIN, usuario Y contraseña de Hacienda, y el vencimiento de la llave (R203)
      if (!this.e) return { txt: 'Pendiente', k: 'warn', d: 'Complete los datos de la empresa para emitir comprobantes.' };
      const e = this.e, amb = e.ambiente === 'produccion' ? 'producción' : 'pruebas';
      if (e.factura_electronica === false) return { txt: 'Apagada', k: 'info', d: 'Esta empresa trabaja con comprobantes internos, sin Hacienda. Si llega a necesitarla, se enciende en Ajustes.' };   // 4.21: antes decía «Incompleto: falta la llave…» a quien no la necesita
      if (!(e.p12_nombre && e.p12_pin && e.usuario_hacienda && e.password_hacienda)) return { txt: 'Incompleto', k: 'warn', d: 'Falta ' + [!e.p12_nombre && 'la llave criptográfica (.p12)', e.p12_nombre && !e.p12_pin && 'el PIN de la llave', !e.usuario_hacienda && 'el usuario de Hacienda', !e.password_hacienda && 'la contraseña de Hacienda'].filter(Boolean).join(', ') + '.' };
      const dias = e.p12_vence ? Math.floor((new Date(e.p12_vence) - new Date()) / 86400000) : null;
      if (dias !== null && dias < 0) return { txt: 'Llave vencida', k: 'danger', d: 'La llave criptográfica venció el ' + fecha(e.p12_vence) + ': genere una nueva en TRIBU-CR y cárguela.' };
      if (dias !== null && dias < 30) return { txt: 'Por vencer', k: 'warn', d: 'Configuración completa (' + amb + '), pero la llave vence en ' + dias + ' días (' + fecha(e.p12_vence) + ').' };
      return { txt: 'Completado', k: 'ok', d: 'Certificado y credenciales de Hacienda configurados (' + amb + ').' };
    },
    enLinea() { return red.enLinea; },   // 4.5: para reintentar el logo al volver la conexión
  },
  watch: { enLinea(v) { if (v && this.logoPendiente) this.cargarLogo(); } },   // 4.5: sin red el logo no se pidió (o falló): se vuelve a pedir en silencio al volver la conexión
  methods: {
    async cargar() {
      await this.cargarWeb();
      try { this.e = await api('/api/empresa'); } catch (err) { toast(err.message, 'err'); }
      if (this.e) { const b = EMPRESA_BASE(); for (const k of Object.keys(b)) this.f[k] = this.e[k] ?? b[k]; this.f.telefono = this.e.telefono || ''; }
      // el registro de bebidas alcohólicas vivía solo en el navegador (empresa_extra) y nunca llegaba al XML: se pasa al servidor al guardar
      // (4.31, 16a: no en el programa conectado, donde ese dato lo manda la web)
      if (this.e && !this.soloWeb && !this.f.registro_fiscal_8707 && this.extra.registro_alcohol) this.f.registro_fiscal_8707 = String(this.extra.registro_alcohol).slice(0, 12);
    },
    // 4.31 (16a): programa conectado a la página web: los datos que manda la web se ven deshabilitados con la nota
    async cargarWeb() { try { const est = await api('/api/sinc/local/estado'); this.soloWeb = est && est.modo_local && est.vinculado ? textoSoloWeb(est.url) : ''; } catch { this.soloWeb = ''; } },
    async buscarHacienda() {
      const n = String(this.f.numero_id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      if (!n) return toast('Digite el número de identificación', 'err');
      this.buscando = true;
      try {
        const d = await api('/api/hacienda/contribuyente/' + n);
        if (d.nombre) this.f.nombre = d.nombre;
        this.actividades = d.actividades || [];
        if (!this.f.actividad && this.actividades.length) { this.f.actividad = this.actividades[0].codigo; this.f.actividad_nombre = this.actividades[0].descripcion || ''; }
        else { const a = this.actividades.find(x => x.codigo === this.f.actividad); if (a && !this.f.actividad_nombre) this.f.actividad_nombre = a.descripcion || ''; }
        if (d.regimen) this.extra.regimen = /simplificado/i.test(d.regimen) ? 'simplificado' : 'tradicional';
        toast('Contribuyente encontrado: ' + d.nombre + (d.situacion ? ' (' + d.situacion + ')' : ''), 'ok');
      } catch (err) { toast(err.message, 'err'); }
      this.buscando = false;
    },
    agregarSecundaria() { const c = this.nuevaSec.trim(); if (!c) return; if (!this.extra.secundarias.includes(c)) this.extra.secundarias.push(c); this.nuevaSec = ''; },
    quitarSecundaria(i) { this.extra.secundarias.splice(i, 1); },
    cantones, distritos,
    // la principal anterior pasa a secundaria (antes desaparecía de la lista) (R53)
    usarActividad(a) { if (this.f.actividad && this.f.actividad !== a.codigo && !this.extra.secundarias.includes(this.f.actividad)) this.extra.secundarias.push(this.f.actividad); this.f.actividad = a.codigo; this.f.actividad_nombre = a.descripcion || ''; this.extra.secundarias = this.extra.secundarias.filter(x => x !== a.codigo); },
    async cargarLogo() {   // 3.87: sin logo el servidor responde 204 (antes 404 y un error en la consola); 4.5: sin conexión no se intenta (ni error en consola ni aviso) y se reintenta al volver la red
      if (!red.enLinea) { this.logo = null; this.logoPendiente = true; return; }
      this.logoPendiente = false;
      try { const r = await fetch('/api/empresa/logo', { cache: 'no-store' }); this.logo = r.status === 200 ? '/api/empresa/logo?v=' + Date.now() : null; } catch { this.logo = null; this.logoPendiente = true; }
    },
    async subirLogo(ev) {
      const file = ev.target.files && ev.target.files[0]; if (!file) return;
      if (!/^image\/(png|jpe?g)$/.test(file.type)) { ev.target.value = ''; return toast('El logo debe ser PNG o JPG', 'err'); }
      const fd = new FormData(); fd.append('archivo', file);
      this.subiendoLogo = true;
      try { const r = await api('/api/empresa/logo', { method: 'POST', body: fd }); this.logo = r.logo; toast('Logo actualizado', 'ok'); } catch (err) { toast(err.message, 'err'); }
      this.subiendoLogo = false; ev.target.value = '';
    },
    async guardar() {
      const tel = telefono8(this.f.telefono);
      if (!this.soloWeb && tel !== null && String(tel).length !== 8 && String(tel).length !== 3) return toast('El teléfono debe tener 8 dígitos, sin guiones ni el 506 (p. ej. 40701198), o ser un número especial de 3 (911)', 'err');
      const req = [['tipo_id', 'Tipo de identificación'], ['numero_id', 'Número de identificación'], ['nombre', 'Nombre'], ['correo', 'Correo'], ...(this.exigeFiscal ? [['actividad', 'Actividad económica principal'], ['otras_senas', 'Dirección']] : [])];   /* 3.94: sin facturación electrónica no se exigen; 4.21: con «No contribuyente» tampoco */
      for (const [k, l] of (this.soloWeb ? [] : req)) if (String(this.f[k] ?? '').trim() === '') return toast('El campo "' + l + '" es obligatorio' + (k === 'actividad' || k === 'otras_senas' ? ' para emitir comprobantes electrónicos. Si esta empresa no los emite, apague la facturación electrónica en Ajustes (o elija «No contribuyente» si no está inscrita ante Hacienda)' : ''), 'err');
      // 4.21: «No contribuyente» deja la empresa sin facturación electrónica: se confirma antes, para que nadie la apague por elegir mal el tipo
      const apagaFe = this.f.tipo_id === '06' && !(this.e && this.e.factura_electronica === false);
      if (apagaFe && !confirm('Como «No contribuyente», esta empresa quedará SIN facturación electrónica: sus comprobantes serán internos y no se enviarán a Hacienda.\n\nSi su empresa está inscrita ante Hacienda y debe emitir comprobantes electrónicos, cancele y elija su tipo de identificación (cédula física, jurídica, DIMEX o NITE).\n\n¿Guardar como «No contribuyente»?')) return;
      this.guardando = true;
      try {
        const r = await api('/api/empresa', { method: 'PUT', body: { ...cuerpoEmpresa(this.e, this.f), confirma_sin_fe: apagaFe } });
        mock.set('empresa_extra', this.extra);
        await store.cargar(); await this.cargar();
        if (r && r.facturacion_apagada) { try { await sesion.restaurar(); } catch { /* el menú se pone al día al recargar */ } }   // 4.21: el menú y las pantallas leen sesion.electronica
        toast(r && r.facturacion_apagada ? 'Empresa guardada. Como «No contribuyente» quedó sin facturación electrónica: sus comprobantes son internos, sin Hacienda' : 'Empresa guardada correctamente', 'ok');
      } catch (err) { toast(err.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); this.cargarLogo(); },
  template: `
  <div class="page">
    <SecHead title="Empresa" sub="Datos del emisor que aparecerán en sus comprobantes electrónicos.">
      <button class="btn" @click="guardar" :disabled="guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </SecHead>

    <div class="grid" style="grid-template-columns:2fr 1fr;align-items:start">
      <div>
        <div class="card"><h2>Datos generales</h2>
          <div class="grid cols-2">
            <Field label="Tipo de identificación" req :help="soloWeb"><select v-model="f.tipo_id" :disabled="!!soloWeb"><option v-for="o in opts(CAT.tipoId)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
            <Field label="Número de identificación" req :help="soloWeb || 'Sin guiones ni espacios'"><div class="row" style="gap:6px"><input v-model="f.numero_id" class="mono" style="flex:1" placeholder="3101123456" :disabled="!!soloWeb"><button class="btn sec sm" @click="buscarHacienda" :disabled="buscando || !!soloWeb">{{buscando ? 'Buscando…' : 'Buscar en Hacienda'}}</button></div></Field>
            <Field label="Nombre o razón social" req :help="soloWeb"><input v-model="f.nombre" placeholder="Tal como aparece en Hacienda" :disabled="!!soloWeb"></Field>
            <Field label="Nombre comercial" :help="soloWeb"><input v-model="f.nombre_comercial" :disabled="!!soloWeb"></Field>
            <Field label="Teléfono" :help="soloWeb || '8 dígitos, sin guiones ni 506'"><input v-model="f.telefono" placeholder="40701198" maxlength="8" inputmode="numeric" :disabled="!!soloWeb"></Field>
            <Field label="Correo" req :help="soloWeb"><input type="email" v-model="f.correo" placeholder="facturacion@empresa.cr" :disabled="!!soloWeb"></Field>
            <Field label="Sitio web" help="Se imprime en el encabezado de sus documentos"><input v-model="f.sitio_web" placeholder="https://www.empresa.cr"></Field>
            <div class="alert info" v-if="f.tipo_id === '06'" style="grid-column:1/-1;margin:0">Como <b>«No contribuyente»</b>, esta empresa no emite comprobantes electrónicos ante Hacienda: sus comprobantes son <b>internos</b> (numerados, con PDF y envío por correo). No necesita actividad económica ni dirección; al guardar, la facturación electrónica queda apagada.</div>
          </div>
        </div>

        <div class="card"><h2>Actividades económicas <small>códigos según el registro de Hacienda</small></h2>
          <div class="grid cols-2">
            <Field label="Actividad principal" :req="exigeFiscal" :help="soloWeb || 'Código de Hacienda tal como aparece en la consulta (p. ej. 6201.0)'"><input v-model="f.actividad" class="mono" placeholder="6201.0" maxlength="6" :disabled="!!soloWeb"></Field>
            <Field label="Descripción de la actividad" help="Se imprime en las facturas; se llena sola al buscar en Hacienda"><input v-model="f.actividad_nombre"></Field>
            <Field label="Actividades secundarias"><div class="row" style="gap:6px"><input v-model="nuevaSec" class="mono" placeholder="Código" @keyup.enter="agregarSecundaria" style="flex:1"><button class="btn sec sm" @click="agregarSecundaria">Agregar</button></div></Field>
          </div>
          <div class="row" style="margin-top:8px" v-if="extra.secundarias.length"><span class="chip" v-for="(s,i) in extra.secundarias" :key="s">{{s}} <a @click="quitarSecundaria(i)" title="Quitar">✕</a></span></div>
          <div v-if="actividades.length" style="margin-top:12px"><div class="small muted" style="margin-bottom:6px">Actividades registradas en Hacienda (haga clic para usar como principal):</div>
            <div class="row"><span class="chip" :class="{on: f.actividad===a.codigo}" v-for="a in actividades" :key="a.codigo" @click="usarActividad(a)"><b class="mono">{{a.codigo}}</b> {{a.descripcion}}</span></div></div>
        </div>

        <div class="card"><h2>Datos de ubicación</h2>
          <div class="grid cols-3">
            <Field label="Provincia" req :help="soloWeb"><select v-model.number="f.provincia" :disabled="!!soloWeb" @change="f.canton = cantones(f.provincia)[0]?.value || 1; f.distrito = 1"><option v-for="(n,c) in CAT.provincias" :key="c" :value="+c">{{n}}</option></select></Field>
            <Field label="Cantón" req :help="soloWeb"><select v-model.number="f.canton" :disabled="!!soloWeb" @change="f.distrito = distritos(f.provincia, f.canton)[0]?.value || 1"><option v-for="o in cantones(f.provincia)" :key="o.value" :value="o.value">{{o.value}} · {{o.label}}</option></select></Field>
            <Field label="Distrito" req :help="soloWeb"><select v-model.number="f.distrito" :disabled="!!soloWeb"><option v-for="o in distritos(f.provincia, f.canton)" :key="o.value" :value="o.value">{{o.value}} · {{o.label}}</option></select></Field>
            <Field label="Barrio" :help="soloWeb"><input v-model="f.barrio" :disabled="!!soloWeb"></Field>
            <Field label="Dirección (otras señas)" :req="exigeFiscal" style="grid-column:2/-1" :help="soloWeb"><input v-model="f.otras_senas" placeholder="200 m norte de la iglesia, edificio azul" :disabled="!!soloWeb"></Field>
          </div>
        </div>

        <div class="card"><h2>Datos adicionales</h2>
          <div class="grid cols-3">
            <Field label="Versión de facturación"><input value="4.4" disabled></Field>
            <Field label="Registro fiscal de bebidas alcohólicas" :help="soloWeb || 'Solo si vende licor (Ley 8707): va en el Emisor de cada comprobante'"><input v-model="f.registro_fiscal_8707" maxlength="12" placeholder="Opcional" :disabled="!!soloWeb"></Field>
          </div>
        </div>
      </div>

      <div>
        <div class="card"><h2>Logo <small><a class="link" href="#/configuracion/marcas">¿Varias marcas o logos?</a></small></h2>
          <label class="drop" style="display:block"><img v-if="logo" :src="logo" alt="Logo" style="max-height:90px;max-width:100%;display:block;margin:0 auto 8px"><span>{{subiendoLogo ? 'Subiendo…' : (logo ? 'Cambiar logo' : 'Haga clic para subir su logo')}}</span><br><span class="small">PNG o JPG, máx. 2 MB. Recomendado: PNG con fondo transparente, 600 × 200 px (horizontal); va en facturas, tiquetes, correos y la página en línea</span><input type="file" accept="image/png,image/jpeg" style="display:none" @change="subirLogo" :disabled="subiendoLogo"></label>
        </div>
        <div class="card"><h2>Facturación electrónica</h2>
          <div class="row" style="justify-content:space-between"><span class="badge" :class="estadoFE.k">{{estadoFE.txt}}</span><a class="btn sec sm" href="#/configuracion/hacienda">Ajustes</a></div>
          <p class="small muted" style="margin:10px 0 0">{{estadoFE.d}}</p>
          <div class="small" style="margin-top:10px" v-if="e"><div><span class="muted">Ambiente:</span> {{e.ambiente === 'produccion' ? 'Producción' : 'Pruebas (sandbox)'}}</div><div><span class="muted">Certificado:</span> {{e.p12_nombre ? 'Cargado' : 'Sin cargar'}}</div><div><span class="muted">Sucursal / terminal:</span> <span class="mono">{{pad(e.sucursal,3)}} / {{pad(e.terminal,5)}}</span></div></div>
        </div>
      </div>
    </div>
  </div>`,
  setup() { return { opts, pad }; },
};

// ------------------------------------------------------------------ Facturación electrónica / Hacienda (backend real)
const SecHacienda = {
  components: { SecHead },
  data() { return { e: null, f: EMPRESA_BASE(), pwd: '', smtpPwd: '', archivo: null, pin: '', cert: null, guardando: false, subiendo: false, pruebaPara: sesion.usuario?.correo || '', probando: false, pruebaResultado: null,
    fijas: null,   // 4.9: instalación local vinculada: la terminal y la sucursal quedaron fijas (/api/sinc/local/estado)
    soloWeb: '',   /* 4.31 (16a): programa conectado: el ambiente, el proveedor y el interruptor los manda la web */
    rh: { smtp_host: '', smtp_puerto: 465, smtp_seguridad: 'ssl', smtp_usuario: '', smtp_remitente: '', smtp_nombre: '', smtp_copia: '', correo_auto: true }, rhPwd: '', rhGuardando: false, rhProbando: false, rhResultado: null }; },
  methods: {
    async cargar() { try { this.e = await api('/api/empresa'); } catch (err) { toast(err.message, 'err'); } if (this.e) { const b = EMPRESA_BASE(); for (const k of Object.keys(b)) this.f[k] = this.e[k] ?? b[k]; for (const k of Object.keys(this.rh)) { const v = this.e['rrhh_' + k]; if (v !== undefined && v !== null) this.rh[k] = v; } if (this.rh.smtp_host === '***') this.rh.smtp_host = ''; if (this.rh.smtp_usuario === '***') this.rh.smtp_usuario = ''; } this.cargarFijas(); },
    // 4.9: en la instalación local vinculada, la terminal y la sucursal quedaron fijas al vincular (el servidor ya rechaza otro número)
    async cargarFijas() { try { const est = await api('/api/sinc/local/estado'); this.fijas = (est && est.modo_local && est.fijas) || null; this.soloWeb = est && est.modo_local && est.vinculado ? textoSoloWeb(est.url) : ''; if (this.fijas) { if (this.fijas.terminal) this.f.terminal = this.fijas.terminal; if (this.fijas.sucursal) this.f.sucursal = this.fijas.sucursal; } } catch { this.fijas = null; this.soloWeb = ''; } },
    // Correo de Recursos humanos: los comprobantes de pago salen de esta cuenta (las respuestas de los empleados llegan a RRHH)
    rhPuerto() { const p = { ssl: 465, starttls: 587, ninguna: 25 }[this.rh.smtp_seguridad]; if (p && [25, 465, 587, null, undefined, ''].includes(this.rh.smtp_puerto)) this.rh.smtp_puerto = p; },
    async guardarRH() {
      if (this.rh.smtp_host && !this.rh.smtp_remitente) return toast('Indique el correo remitente de Recursos humanos', 'err');
      this.rhGuardando = true;
      try { await api('/api/rrhh/correo', { method: 'PUT', body: { ...this.rh, smtp_password: this.rhPwd || null } }); this.rhPwd = ''; await this.cargar(); toast('Correo de Recursos humanos guardado', 'ok'); }
      catch (err) { toast(err.message, 'err'); }
      this.rhGuardando = false;
    },
    async probarRH() {
      this.rhProbando = true; this.rhResultado = null;
      try { const r = await api('/api/rrhh/correo/probar', { method: 'POST', body: { para: this.pruebaPara || null } }); this.rhResultado = { ok: true, detalle: r.detalle + '. Revise la bandeja de ' + r.para + ' (y la carpeta de spam).' }; toast('Correo de prueba enviado', 'ok'); }
      catch (err) { this.rhResultado = { ok: false, detalle: err.message }; toast(err.message, 'err'); }
      this.rhProbando = false;
    },
    // 4.21: el interruptor se guarda SOLO. Antes viajaba con toda la empresa y cualquier otro dato guardado sin completar (una empresa nace
    // sin número de identificación) impedía apagarlo: quien no factura electrónicamente quedaba sin salida entre esta pantalla y Empresa.
    async guardarInterruptor() {
      const activa = !!this.f.factura_electronica;
      this.guardando = true;
      try {
        await api('/api/empresa/facturacion-electronica', { method: 'POST', body: { activa } });
        this.e.factura_electronica = activa;                                                  // sin recargar ni volver a montar la pantalla: lo escrito en Conexión y en Correo saliente sigue ahí
        const info = sesion.empresaInfo; if (info) info.factura_electronica = activa;         // el menú y las pantallas leen sesion.electronica (3.61)
        toast(activa ? 'Facturación electrónica encendida' : 'Facturación electrónica apagada: desde ahora los comprobantes son internos', 'ok');
      } catch (err) { this.f.factura_electronica = !this.e || this.e.factura_electronica !== false; toast(err.message, 'err'); }
      this.guardando = false;
    },
    async guardar(parte) {
      if (!this.e) return toast('Primero guarde los datos generales de la empresa', 'err');
      if (parte === 'fe') return this.guardarInterruptor();
      if (!!this.f.factura_electronica !== (this.e.factura_electronica !== false)) return toast('Movió el interruptor de facturación electrónica y todavía no lo ha guardado: guárdelo primero con su botón «Guardar» y después guarde aquí', 'err');   // 4.21: antes este botón lo encendía o apagaba de paso, sin revisar nada
      const cambios = { ...this.f, password_hacienda: this.pwd || '***', smtp_password: this.smtpPwd || '***' };
      cambios.factura_electronica = this.e.factura_electronica !== false;   // 4.21: el interruptor solo lo cambia su propio Guardar (antes «Guardar correo saliente» lo encendía o apagaba de paso)
      if (parte === 'smtp' || parte === 'fe') cambios.ambiente = this.e.ambiente;      // el botón de correo (y el interruptor, 3.61) no tocan el ambiente (R202)
      else if (cambios.ambiente !== this.e.ambiente && !confirm('Va a cambiar el ambiente de Hacienda a ' + (cambios.ambiente === 'produccion' ? 'PRODUCCIÓN' : 'PRUEBAS') + '. La llave criptográfica cargada se quitará y deberá cargar la del nuevo ambiente; las series de numeración son independientes por ambiente. ¿Continuar?')) return;
      this.guardando = true;
      try {
        const r = await api('/api/empresa', { method: 'PUT', body: cuerpoEmpresa(this.e, cambios) });
        this.pwd = ''; this.smtpPwd = '';
        await store.cargar(); await this.cargar();
        if (parte === 'fe') { try { await sesion.restaurar(); } catch {} }   // el menú y las pantallas leen sesion.electronica (3.61)
        toast(parte === 'smtp' ? 'Correo saliente guardado' : parte === 'fe' ? (cambios.factura_electronica ? 'Facturación electrónica encendida' : 'Facturación electrónica apagada: desde ahora los comprobantes son internos') : 'Conexión con Hacienda guardada', 'ok');
        if (r && r.cambio_ambiente) toast('Ambiente cambiado: la llave anterior se quitó. Cargue la llave del nuevo ambiente antes de emitir', 'err');
      } catch (err) { toast(err.message + (/identificación|nombre de la empresa|nombre comercial|otras señas|actividad económica|ubicación de la empresa|barrio/i.test(err.message || '') ? ' — Ese dato se corrige en Configuración › Empresa; después vuelva a guardar aquí.' : ''), 'err'); }   // 4.21: este guardado manda toda la empresa
      this.guardando = false;
    },
    diasVence(iso) { return Math.floor((new Date(iso) - new Date()) / 86400000); },
    // 3.87: interruptor del aviso de rechazos (se guarda solo, aparte de la conexión)
    async guardarAvisoRechazo(v) {
      if (!this.e) return toast('Primero guarde los datos generales de la empresa', 'err');
      try { const r = await api('/api/empresa/aviso-rechazo', { method: 'PUT', body: { activo: !!v } }); this.e = { ...this.e, aviso_rechazo: r.aviso_rechazo }; toast(r.aviso_rechazo ? 'Aviso de rechazos encendido' : 'Aviso de rechazos apagado', 'ok'); }
      catch (err) { toast(err.message, 'err'); }
    },
    puertoSugerido() { const p = { ssl: 465, starttls: 587, ninguna: 25 }[this.f.smtp_seguridad]; if (p && [25, 465, 587, null, undefined, ''].includes(this.f.smtp_puerto)) this.f.smtp_puerto = p; },
    async probarCorreo() {
      this.probando = true; this.pruebaResultado = null;
      try { const r = await api('/api/empresa/smtp/probar', { method: 'POST', body: { para: this.pruebaPara || null } }); this.pruebaResultado = { ok: true, detalle: r.detalle + '. Revise la bandeja de ' + r.para + ' (y la carpeta de spam).' }; toast('Correo de prueba enviado', 'ok'); }
      catch (e) { this.pruebaResultado = { ok: false, detalle: e.message }; toast(e.message, 'err'); }
      this.probando = false;
    },
    async subirCertificado() {
      if (!this.archivo) return toast('Seleccione el archivo .p12', 'err');
      if (!this.pin) return toast('Digite el PIN del certificado', 'err');
      const fd = new FormData(); fd.append('archivo', this.archivo); fd.append('pin', this.pin);
      this.subiendo = true;
      try { this.cert = await api('/api/empresa/certificado', { method: 'POST', body: fd }); this.pin = ''; this.archivo = null; await this.cargar(); toast('Llave criptográfica cargada correctamente', 'ok'); }
      catch (err) { toast(err.message, 'err'); }
      this.subiendo = false;
    },
    fecha,
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <SecHead title="Facturación electrónica" sub="Conexión con el Ministerio de Hacienda, llave criptográfica y correo saliente."><a class="btn ghost" href="#/configuracion/empresa">← Datos de la empresa</a></SecHead>
    <div class="alert warn" v-if="!e">Primero complete y guarde los datos generales de la empresa. <a href="#/configuracion/empresa">Ir a Empresa</a></div>

    <div class="card"><h2>Facturación electrónica <small>{{f.factura_electronica ? 'encendida: los comprobantes se firman y se envían a Hacienda' : 'apagada: comprobantes internos, sin Hacienda'}}</small></h2>
      <Toggle v-model="f.factura_electronica" label="Esta empresa emite comprobantes electrónicos ante Hacienda (factura, tiquete, notas de crédito y débito)" :style="soloWeb ? 'pointer-events:none;opacity:.55' : ''"></Toggle>
      <p class="small muted" style="margin:6px 0 0" v-if="soloWeb">{{soloWeb}}</p>
      <div class="alert warn" style="margin-top:8px" v-if="e && e.tipo_id === '06'">Esta empresa está registrada como <b>«No contribuyente»</b>, y así no emite comprobantes electrónicos. Para encenderla, cambie primero el tipo de identificación en <a href="#/configuracion/empresa">Datos de la empresa</a>.</div>
      <p class="small muted" style="margin:8px 0 0" v-if="f.factura_electronica">Necesita el usuario de Hacienda y la llave criptográfica de abajo. Si todavía no los tiene, puede apagarla y trabajar con comprobantes internos mientras tanto.</p>
      <div class="alert info" style="margin-top:8px" v-else><b>Apagada:</b> el sistema emite <b>comprobantes internos</b> numerados, con PDF y envío por correo, sin XML ni Hacienda. Es para quien no está obligado a facturar electrónicamente (régimen de tributación simplificada, actividades muy pequeñas). La recepción de las facturas de sus proveedores sigue funcionando y el reporte «Compras por trimestre» le da la base de su declaración. Puede encenderla cuando quiera: el historial se conserva y los comprobantes internos no se envían.</div>
      <div class="row end" style="margin-top:8px"><button class="btn" @click="guardar('fe')" :disabled="guardando || !e || !!soloWeb">Guardar</button></div>
    </div>

    <div class="card" v-if="f.factura_electronica"><h2>Conexión con Hacienda <small>credenciales de la Administración Tributaria Virtual (ATV)</small></h2>
      <div class="grid cols-3">
        <Field label="Ambiente" req :help="soloWeb || 'Al cambiar de ambiente se exige cargar la llave .p12 de ese ambiente'"><select v-model="f.ambiente" :disabled="!!soloWeb"><option value="sandbox">Pruebas (sandbox)</option><option value="produccion">Producción</option></select></Field>
        <Field label="Usuario de API de Hacienda" help="Pruebas: cpj-3-102-xxxxxx@stag.comprobanteselectronicos.go.cr · Producción: ...@prod.comprobanteselectronicos.go.cr"><input v-model="f.usuario_hacienda"></Field>
        <Field label="Contraseña ATV" :help="e?.password_hacienda ? 'Ya hay una contraseña guardada; deje en blanco para no cambiarla' : ''"><input type="password" v-model="pwd" autocomplete="new-password" placeholder="••••••••"></Field>
        <Field label="Sucursal" req :help="fijas ? 'Quedó fija al vincular esta instalación con la nube (Configuración › Instalación local)' : '3 dígitos en el consecutivo'"><input type="number" min="1" max="999" v-model.number="f.sucursal" :disabled="!!fijas"></Field>
        <Field label="Terminal" req :help="fijas ? 'Quedó fija al vincular esta instalación con la nube: con otro número se repetirían consecutivos' : '5 dígitos en el consecutivo'"><input type="number" min="1" max="99999" v-model.number="f.terminal" :disabled="!!fijas"></Field>
        <Field label="Proveedor de sistemas (cédula, sin guiones; IT Core Sync salvo que use otro software)" :help="soloWeb || 'Vacío = IT Core Sync (3102956970), el proveedor de este sistema; solo cámbielo si emite con otro software'"><input v-model="f.proveedor_sistemas" class="mono" placeholder="3102956970" :disabled="!!soloWeb"></Field>
      </div>
      <div style="margin:10px 0 4px"><Toggle :model-value="!!e && e.aviso_rechazo !== false" @update:model-value="guardarAvisoRechazo" label="Avisarme por correo si Hacienda rechaza un comprobante o no lo responde en un día"></Toggle>
        <div class="muted small">El aviso llega al correo de la empresa y a quienes facturan o administran, con el motivo en palabras simples. Solo en producción.</div></div>
      <div class="row end"><button class="btn" @click="guardar('hacienda')" :disabled="guardando || !e">Guardar conexión</button></div>
    </div>

    <div class="card" v-if="f.factura_electronica"><h2>Llave criptográfica <small>certificado .p12 emitido por Hacienda</small></h2>
      <div class="row" style="margin-bottom:12px"><span class="muted small">Estado actual:</span><Badge :value="e?.p12_nombre ? 'Certificado cargado' : 'Pendiente'"></Badge><span class="mono small" v-if="e?.p12_nombre">{{e.p12_nombre}}</span><span class="small" v-if="e?.p12_vence" :class="{danger: diasVence(e.p12_vence) < 30}">· Vence: {{fecha(e.p12_vence)}}<b v-if="diasVence(e.p12_vence) < 30"> (quedan {{diasVence(e.p12_vence)}} días: genere una llave nueva en TRIBU-CR)</b></span></div>
      <div class="alert warn" v-if="e && !e.p12_nombre">Sin llave cargada no se puede emitir en producción. Cargue la llave del ambiente seleccionado arriba (la de pruebas y la de producción son distintas).</div>
      <div class="grid cols-3">
        <Field label="Archivo .p12" req><input type="file" accept=".p12,.pfx" @change="archivo=$event.target.files[0] || null"></Field>
        <Field label="PIN" req help="4 dígitos en llaves anteriores; 14+ caracteres en llaves generadas desde julio 2026"><input type="password" v-model="pin" autocomplete="off" maxlength="64"></Field>
        <div style="align-self:end"><button class="btn" @click="subirCertificado" :disabled="subiendo || !e">{{subiendo ? 'Cargando…' : 'Cargar llave'}}</button></div>
      </div>
      <div class="alert ok" v-if="cert" style="margin-top:12px"><b>Certificado válido.</b> Sujeto: <span class="mono">{{cert.sujeto}}</span> · Vence: {{fecha(cert.vence)}}</div>
    </div>

    <div class="card"><h2>Correo saliente (SMTP) <small>para enviar los comprobantes a sus clientes</small></h2>
      <div class="grid cols-3">
        <Field label="Servidor (host)" help="cPanel: mail.sudominio.com · Gmail: smtp.gmail.com · Microsoft 365: smtp.office365.com"><input v-model="f.smtp_host" placeholder="mail.itcoresync.com"></Field>
        <Field label="Seguridad" help="SSL → puerto 465 (cPanel) · STARTTLS → 587 (Gmail/365) · Sin cifrado → 25, solo redes internas"><select v-model="f.smtp_seguridad" @change="puertoSugerido"><option value="ssl">SSL (puerto 465)</option><option value="starttls">STARTTLS (puerto 587)</option><option value="ninguna">Sin cifrado (puerto 25)</option></select></Field>
        <Field label="Puerto" req><input type="number" min="1" max="65535" v-model.number="f.smtp_puerto" placeholder="465"></Field>
        <Field label="Correo remitente" req help="Debe ser una cuenta real del mismo servidor"><input type="email" v-model="f.smtp_remitente" placeholder="facturas@itcoresync.com"></Field>
        <Field label="Nombre del remitente" help="Lo que verá el cliente en 'De:'"><input v-model="f.smtp_nombre" placeholder="IT Core Sync · Facturación"></Field>
        <Field label="Usuario" help="Normalmente el correo completo"><input v-model="f.smtp_usuario" placeholder="facturas@itcoresync.com"></Field>
        <Field label="Contraseña" :help="e?.smtp_password ? 'Ya hay una contraseña guardada; deje en blanco para no cambiarla' : 'Gmail/365: use una contraseña de aplicación'"><input type="password" v-model="smtpPwd" autocomplete="new-password" placeholder="••••••••"></Field>
        <Field label="Copia oculta a (opcional)" help="Recibe una copia de cada comprobante enviado"><input type="email" v-model="f.smtp_copia" placeholder="contabilidad@itcoresync.com"></Field>
      </div>
      <div style="margin:10px 0 4px"><Toggle v-model="f.correo_automatico" label="Enviar el comprobante al cliente automáticamente en cuanto Hacienda lo acepte (PDF + XML + respuesta)"></Toggle>

        <div class="muted small">Si falla el envío queda registrado en Historial › Operaciones y el botón ✉ sigue disponible para reintentar.</div></div>

      <div class="row end"><button class="btn" @click="guardar('smtp')" :disabled="guardando || !e">Guardar correo saliente</button></div>
      <div class="row" style="margin-top:14px;align-items:flex-end;gap:10px;flex-wrap:wrap">
        <Field label="Enviar correo de prueba a" help="Primero guarde la configuración; la prueba usa lo guardado"><input type="email" v-model="pruebaPara" placeholder="su@correo.com"></Field>
        <button class="btn sec" @click="probarCorreo" :disabled="probando || !e?.smtp_host">{{probando ? 'Enviando…' : 'Enviar correo de prueba'}}</button>
      </div>
      <div v-if="pruebaResultado" :class="['alert', pruebaResultado.ok ? 'ok' : 'err']" style="margin-top:10px"><b>{{pruebaResultado.ok ? 'Correo de prueba enviado.' : 'No se pudo enviar.'}}</b> {{pruebaResultado.detalle}}</div>
    </div>

    <div class="card"><h2>Correo de Recursos humanos <small>para enviar a cada empleado su comprobante de pago al marcar pagada la planilla</small></h2>
      <p class="small muted" style="margin:0 0 10px">Si deja el servidor en blanco, los comprobantes salen por el correo saliente general y las respuestas de los empleados se dirigen al correo remitente de Recursos humanos que indique aquí.</p>
      <div class="grid cols-3">
        <Field label="Servidor (host)" help="En blanco: usa el correo saliente general"><input v-model="rh.smtp_host" placeholder="mail.sudominio.com"></Field>
        <Field label="Seguridad"><select v-model="rh.smtp_seguridad" @change="rhPuerto"><option value="ssl">SSL (puerto 465)</option><option value="starttls">STARTTLS (puerto 587)</option><option value="ninguna">Sin cifrado (puerto 25)</option></select></Field>
        <Field label="Puerto"><input type="number" min="1" max="65535" v-model.number="rh.smtp_puerto" placeholder="465"></Field>
        <Field label="Correo remitente de RRHH" help="Aquí llegan las respuestas de los empleados"><input type="email" v-model="rh.smtp_remitente" placeholder="rrhh@sudominio.com"></Field>
        <Field label="Nombre del remitente"><input v-model="rh.smtp_nombre" placeholder="Recursos humanos · Su empresa"></Field>
        <Field label="Usuario"><input v-model="rh.smtp_usuario" placeholder="rrhh@sudominio.com"></Field>
        <Field label="Contraseña" :help="e?.rrhh_smtp_password ? 'Ya hay una contraseña guardada; deje en blanco para no cambiarla' : 'Gmail/365: use una contraseña de aplicación'"><input type="password" v-model="rhPwd" autocomplete="new-password" placeholder="••••••••"></Field>
        <Field label="Copia oculta a (opcional)"><input type="email" v-model="rh.smtp_copia" placeholder="archivo.rrhh@sudominio.com"></Field>
      </div>
      <div style="margin:10px 0 4px"><Toggle v-model="rh.correo_auto" label="Al marcar pagada una planilla, enviar a cada empleado con correo su comprobante de pago (PDF)"></Toggle></div>
      <div class="row end" style="gap:8px"><button class="btn sec" @click="probarRH" :disabled="rhProbando || !e">{{rhProbando ? 'Enviando…' : 'Enviar correo de prueba de RRHH'}}</button><button class="btn" @click="guardarRH" :disabled="rhGuardando || !e">Guardar correo de RRHH</button></div>
      <div v-if="rhResultado" :class="['alert', rhResultado.ok ? 'ok' : 'err']" style="margin-top:10px"><b>{{rhResultado.ok ? 'Correo de prueba enviado.' : 'No se pudo enviar.'}}</b> {{rhResultado.detalle}}</div>
    </div>
  </div>`,
};

// ------------------------------------------------------------------ Usuarios
const ROLES = ['Administrador', 'Avanzado', 'Contador', 'Vendedor', 'Cajero', 'Solo lectura'];
const SecUsuarios = {
  // Usuarios de la empresa activa (/api/auth/usuarios) y roles (/api/auth/roles): base fijos y personalizados por empresa.
  components: { SecHead },
  setup() { return { store, sesion }; },
  data() { return { rows: [], modal: false, contador: false, form: { correo: '', nombre: '', rol: 'Vendedor', password_temporal: '' }, cargando: true, roles: null, rolModal: null, cambio: null, guardando: false, modulos: null, politica: null, guardandoPolitica: false, clave: null }; },   // 4.35: clave = la contraseña temporal que se muestra una vez
  computed: {
    esLocal() { return !!(sesion.empresaInfo && sesion.empresaInfo.es_local); },   // 4.35: en el programa, restablecer la contraseña se hace en la página web (solo_web)
    columnas() { return [{ key: 'nombre', label: 'Nombre' }, { key: 'correo', label: 'Correo' }, { key: 'rol', label: 'Rol', fmt: 'badge' }, ...(sesion.sucursales.length ? [{ key: 'sucursal', label: 'Sucursal' }] : []), { key: 'mfa', label: 'Verificación en 2 pasos', fmt: (v, r) => v ? 'Activa' : (r && r.mfa_renuncia ? marcaRenuncia(r.mfa_renuncia) : 'No') }, { key: 'estado', label: 'Estado', fmt: 'badge' }, { key: 'ultimo_acceso', label: 'Último acceso', fmt: v => v ? fechaHora(v) : 'Nunca' }]; },
    esAdmin() { return sesion.puede('usuarios'); },
    ROLES() { return this.roles ? this.roles.roles.filter(r => !r.sin_caja).map(r => r.rol) : ROLES; },   // 3.87: sin los de solo caja donde no hay punto de venta (el servidor tampoco los asigna)
    rolesCambio() { const a = this.cambio && this.cambio.usuario.rol; return a && !this.ROLES.includes(a) ? [a, ...this.ROLES] : this.ROLES; },   // 3.87: el rol actual sigue a la vista
    rolesCaja() { return this.roles ? this.roles.roles.filter(r => r.solo_caja).map(r => r.rol) : ['Cajero']; },   // 3.87: los que solo usan el punto de venta
  },
  methods: {
    async cargar() {
      this.cargando = true;
      // 3.87: la lista con correos, rol, dos pasos y último acceso es de quien administra usuarios (el servidor ya no la da a los demás)
      if (!sesion.puede('usuarios')) { this.cargando = false; try { this.roles = await api('/api/auth/roles'); } catch { this.roles = null; } return; }
      try { this.rows = (await api('/api/auth/usuarios')).map(u => ({ ...u, mfa: u.mfa_activo, estado: u.bloqueado ? 'Bloqueado' : 'Activo', sucursal: u.sucursal_id ? ((sesion.sucursales.find(x => x.id === u.sucursal_id) || {}).nombre || '#' + u.sucursal_id) : 'Todas' })); } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
      try { this.roles = await api('/api/auth/roles'); } catch { this.roles = null; }
      this.cargarPolitica();
    },
    // ---- 4.7: política de la verificación en dos pasos de la empresa y quién de sus usuarios renunció a ella (descargo)
    marcaRenuncia, fechaRenuncia, estadoRenuncia, claseRenuncia,
    async cargarPolitica() { if (!sesion.puede('usuarios')) { this.politica = null; return; } try { this.politica = await api('/api/auth/mfa/politica'); } catch { this.politica = null; } },
    async guardarPolitica(ev) {
      const v = ev.target.checked, p = this.politica;
      const afectados = v ? p.renuncias.filter(x => x.vigente && !x.mfa_activo) : [];
      const nombres = afectados.slice(0, 8).map(x => x.nombre || x.correo).join(', ') + (afectados.length > 8 ? ' y ' + (afectados.length - 8) + ' más' : '');
      const pregunta = v ? 'Con la verificación sin excepción, nadie de esta empresa podrá reemplazarla aceptando el descargo de responsabilidad.' + (afectados.length ? ' Deberán activarla (al entrar o para ver Recursos humanos): ' + nombres + '.' : '') + ' ¿Encenderla?'
        : 'Al apagarla, quienes aceptaron el descargo de responsabilidad podrán usar el sistema sin la verificación en dos pasos. ¿Apagarla?';
      if (!confirm(pregunta)) { ev.target.checked = !v; return; }
      this.guardandoPolitica = true;
      try { const r = await api('/api/auth/mfa/politica', { method: 'PUT', body: { sin_excepcion: v } }); this.politica = r; toast(v ? 'Verificación sin excepción encendida' + (r.afectados && r.afectados.length ? ': ' + r.afectados.length + ' persona(s) deberán activarla' : '') : 'Verificación sin excepción apagada: vale la renuncia aceptada', 'ok'); this.cargar(); }
      catch (e) { ev.target.checked = !v; toast(e.message, 'err'); }
      this.guardandoPolitica = false;
    },
    generar() { this.form.password_temporal = claveFacil(); },   // 3.70: dos palabras y cuatro dígitos, azar criptográfico (R301)
    // ---- matriz de módulos por empresa y por usuario (3.70)
    async cargarModulos() { try { this.modulos = await api('/api/auth/modulos'); } catch { this.modulos = null; } },
    apagadoEmpresa(c) { return !!(this.modulos && this.modulos.ocultos.includes(c)); },
    apagadoUsuario(u, c) { return this.apagadoEmpresa(c) || (u.modulos_ocultos || []).includes(c); },
    cajaFija(u, c) { return c === 'pos' && !this.apagadoUsuario(u, c) && !u.admin_sistema && this.rolesCaja.includes(u.rol); },   // 3.87: a un Cajero no se le apaga la caja (no tendría nada que hacer)
    async toggleEmpresa(c, encendido) {
      // 3.87: apagar el punto de venta deja sin nada que hacer a los cajeros: se pregunta antes, y el servidor avisa de todos modos
      const cajeros = c === 'pos' && !encendido ? this.rows.filter(u => this.rolesCaja.includes(u.rol) && !u.admin_sistema && !(u.modulos_ocultos || []).includes('pos')) : [];
      if (cajeros.length && !confirm('Apagar el punto de venta deja sin nada que hacer a ' + (cajeros.length === 1 ? '1 usuario' : cajeros.length + ' usuarios') + ' con un rol que solo usa la caja (' + cajeros.slice(0, 5).map(u => u.nombre || u.correo).join(', ') + '). Cámbieles el rol después. ¿Apagarlo de todos modos?')) { const m = this.modulos; this.modulos = null; this.$nextTick(() => { this.modulos = m; }); return; }   // la casilla vuelve a su estado
      const ocultos = this.modulos.ocultos.filter(x => x !== c); if (!encendido) ocultos.push(c);
      try { const r = await api('/api/auth/modulos', { method: 'PUT', body: { ocultos } }); this.modulos.ocultos = r.ocultos; toast(r.aviso || ((encendido ? 'Encendido' : 'Apagado') + ' para toda la empresa'), r.aviso ? 'err' : 'ok'); await sesion.restaurar(); }
      catch (e) { toast(e.message, 'err'); await this.cargarModulos(); }
    },
    async toggleUsuario(u, c, encendido) {
      const lista = (u.modulos_ocultos || []).filter(x => x !== c); if (!encendido) lista.push(c);
      try { const r = await api('/api/auth/usuarios/' + u.id, { method: 'PUT', body: { rol: u.rol, modulos_ocultos: lista } }); u.modulos_ocultos = r.modulos_ocultos; toast((encendido ? 'Encendido' : 'Apagado') + ' para ' + (u.nombre || u.correo), 'ok'); if (sesion.usuario && sesion.usuario.id === u.id) await sesion.restaurar(); }
      catch (e) { toast(e.message, 'err'); await this.cargar(); }
    },
    invitar(rol) { this.form = { correo: '', nombre: '', rol: rol || 'Vendedor', password_temporal: '' }; this.generar(); this.contador = rol === 'Contador'; this.modal = true; },
    async enviar() {
      if (!/.+@.+\..+/.test(this.form.correo)) return toast('Digite un correo válido', 'err');
      if (!this.form.nombre) return toast('Indique el nombre', 'err');
      // 4.35: lo que dijo el servidor sobre la contraseña: la temporal vale (cuenta nueva, o la que había quedado sin empresas) o no se tocó (r.aviso dice por qué)
      try { const r = await api('/api/auth/usuarios', { method: 'POST', body: this.form }); this.modal = false; if (r.password_aplica) this.clave = { titulo: 'Usuario agregado', correo: this.form.correo, clave: this.form.password_temporal, aviso: r.aviso || '' }; else toast(r.aviso || `${this.form.correo} ya tenía cuenta: se agregó a esta empresa con su contraseña de siempre`, r.motivo === 'bloqueada' ? 'err' : 'ok'); this.cargar(); /* R135 */ }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- 4.35: restablecer la contraseña de una persona del equipo (solo en la web; si la cuenta entra a otras empresas, la restablece el soporte)
    async restablecer(u) {
      if (!confirm('¿Restablecer la contraseña de ' + u.correo + '? Se le cerrarán las sesiones abiertas y deberá cambiar la contraseña temporal al entrar.')) return;
      try { const r = await api('/api/auth/usuarios/' + u.id + '/password', { method: 'POST', body: {} }); this.clave = { titulo: 'Contraseña restablecida', correo: r.correo, clave: r.password, aviso: '', mfa: !!r.mfa_activo }; }
      catch (e) { toast(e.message, 'err'); }
    },
    async copiarClave() { try { await navigator.clipboard.writeText(this.clave.clave); toast('Contraseña copiada', 'ok'); } catch { toast('Seleccione y copie la contraseña a mano', 'err'); } },
    async eliminar(u) { if (!confirm('¿Quitar acceso a ' + u.correo + '?')) return; try { await api('/api/auth/usuarios/' + u.id, { method: 'DELETE' }); toast('Acceso retirado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async eliminarVarios(rows) { let n = 0; for (const u of rows) { try { await api('/api/auth/usuarios/' + u.id, { method: 'DELETE' }); n++; } catch {} } toast('Acceso retirado a ' + n + ' usuarios', 'ok'); this.cargar(); },
    // ---- cambio de rol de un usuario
    cambiarRol(u) { this.cambio = { usuario: u, rol: u.rol, sucursal_id: u.sucursal_id || null }; },
    async guardarCambio() {
      const c = this.cambio;
      try { await api('/api/auth/usuarios/' + c.usuario.id, { method: 'PUT', body: { rol: c.rol, sucursal_id: c.sucursal_id || null, sucursal_definida: sesion.sucursales.length > 0 } }); toast('Rol de ' + c.usuario.correo + ' cambiado a ' + c.rol, 'ok'); this.cambio = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- roles personalizados
    asignables() { return this.roles ? this.roles.asignables : []; },
    nuevoRol(base) { this.rolModal = { id: null, nombre: base ? base.rol + ' (copia)' : '', descripcion: base ? base.descripcion : '', permisos: base ? base.permisos.filter(p => this.asignables().includes(p)) : [] }; },
    editarRol(r) { this.rolModal = { id: r.id, nombre: r.rol, descripcion: r.descripcion || '', permisos: r.permisos.filter(p => this.asignables().includes(p)) }; },
    togglePermiso(p) { const i = this.rolModal.permisos.indexOf(p); i >= 0 ? this.rolModal.permisos.splice(i, 1) : this.rolModal.permisos.push(p); },
    async guardarRol() {
      const r = this.rolModal;
      if (!r.nombre.trim()) return toast('Indique el nombre del rol', 'err');
      if (!r.permisos.length) return toast('Marque al menos un permiso', 'err');
      this.guardando = true;
      try { await api(r.id ? '/api/auth/roles/' + r.id : '/api/auth/roles', { method: r.id ? 'PUT' : 'POST', body: { nombre: r.nombre, descripcion: r.descripcion, permisos: r.permisos } }); toast('Rol «' + r.nombre.trim() + '» guardado', 'ok'); this.rolModal = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async eliminarRol(r) {
      if (!confirm('¿Eliminar el rol «' + r.rol + '»?')) return;
      try { await api('/api/auth/roles/' + r.id, { method: 'DELETE' }); toast('Rol eliminado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); },
  mounted() { if (/rol=Contador/.test(location.hash) && sesion.puede('usuarios')) this.invitar('Contador'); if (sesion.puede('configurar') || sesion.puede('usuarios')) this.cargarModulos(); },   // desde «Invitar a mi contador» (R164); matriz (3.70)
  template: `
  <div class="page">
    <SecHead title="Usuarios" sub="Las personas de su empresa que pueden entrar al sistema, cada una con su correo, contraseña y rol. Los roles base son fijos; puede crear roles propios marcando permisos.">
      <button class="btn ghost" @click="nuevoRol(null)" v-if="esAdmin && roles">+ Nuevo rol</button>
      <button class="btn sec" @click="invitar('Contador')" v-if="esAdmin">+ Agregar contador</button><button class="btn" @click="invitar()" v-if="esAdmin">+ Agregar usuario</button>
    </SecHead>
    <div class="alert info" v-if="!esAdmin">Solo el administrador de la empresa ve la lista de usuarios, los agrega o quita y administra los roles.</div>
    <div class="card pad0" v-if="esAdmin">
      <DataTable :rows="rows" :columns="columnas" :selectable="esAdmin" :on-bulk-delete="esAdmin ? eliminarVarios : undefined" empty-title="Sin usuarios">
        <template #actions="{row}"><template v-if="row.editable !== false"><button class="btn sm sec" v-if="esAdmin" @click.stop="cambiarRol(row)">Cambiar rol</button><template v-if="esAdmin && !esLocal && !(sesion.usuario && sesion.usuario.soporte) && !row.admin_sistema && !(sesion.usuario && sesion.usuario.id === row.id)"><button class="btn icon" v-if="row.restablecible" @click.stop="restablecer(row)" title="Restablecer contraseña">🔑</button><span class="btn icon" v-else style="cursor:help;opacity:.45;filter:grayscale(1)" role="img" aria-label="La restablece el soporte de FISITAAP" title="La restablece el soporte de FISITAAP">🔑</span></template><button class="btn icon" v-if="esAdmin" @click.stop="eliminar(row)" title="Quitar acceso">🗑</button></template><span class="badge info" v-else title="3.87: su acceso a esta empresa lo cambia solo el super administrador del sistema">Administrador del sistema</span></template>
      </DataTable>
    </div>
    <div class="card" v-if="esAdmin && politica"><h2>Verificación en dos pasos <small>quién puede no usarla</small></h2>
      <label class="row" style="gap:10px;align-items:flex-start;cursor:pointer"><input type="checkbox" :checked="politica.sin_excepcion" :disabled="guardandoPolitica" @change="guardarPolitica($event)" style="margin-top:4px"><span><b>Exigir la verificación en dos pasos sin excepción</b><div class="small muted">Encendida, en esta empresa nadie puede reemplazarla aceptando el descargo de responsabilidad: el Administrador, los roles que cambian la configuración o los usuarios y quien ve Recursos humanos deberán activarla. Apagada, cada persona puede decidir no usarla si acepta el descargo con su contraseña (queda registrado y le llega una copia por correo). Para encenderla, active primero su propia verificación.</div></span></label>
      <div class="alert info" style="margin:10px 0 0" v-if="!politica.renuncia_permitida">Por ahora el sistema no permite la renuncia: la verificación se pide a todos los que la necesitan.</div>
      <div class="table-wrap" style="margin-top:10px" v-if="politica.renuncias.length"><table class="tbl"><thead><tr><th>Usuario</th><th>Rol</th><th>Aceptó el descargo</th><th>Versión</th><th>Estado</th></tr></thead>
        <tbody><tr v-for="x in politica.renuncias" :key="x.id"><td><b>{{x.nombre || x.correo}}</b><div class="small muted">{{x.correo}}</div></td><td>{{x.rol}}</td><td>{{fechaRenuncia(x.fecha)}}</td><td class="mono">{{x.version}}</td><td><span class="badge" :class="claseRenuncia(x)">{{estadoRenuncia(x)}}</span></td></tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0" v-else>Nadie de esta empresa ha renunciado a la verificación en dos pasos.</p>
      <p class="small muted" style="margin:6px 0 0">Texto del descargo: <a class="link" :href="politica.url" target="_blank" rel="noopener">versión {{politica.version}}</a>.</p>
    </div>
    <div class="card" v-if="modulos && esAdmin"><h2>Módulos por usuario <small>apague lo que esta empresa o una persona no usa; el menú se ajusta solo y los datos no se tocan</small></h2>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Módulo</th><th>Toda la empresa</th><th v-for="u in rows" :key="u.id">{{u.nombre || u.correo}}<div class="small muted">{{u.rol}}</div></th></tr></thead>
        <tbody><tr v-for="m in modulos.disponibles" :key="m.codigo"><td>{{m.nombre}}</td>
          <td><label class="row small" style="gap:6px;cursor:pointer"><input type="checkbox" :checked="!apagadoEmpresa(m.codigo)" @change="toggleEmpresa(m.codigo, $event.target.checked)"> {{apagadoEmpresa(m.codigo) ? 'Apagado' : 'Encendido'}}</label></td>
          <td v-for="u in rows" :key="u.id"><input type="checkbox" :disabled="apagadoEmpresa(m.codigo) || u.editable === false || u.rol === 'Administrador' && false || cajaFija(u, m.codigo)" :checked="!apagadoUsuario(u, m.codigo)" @change="toggleUsuario(u, m.codigo, $event.target.checked)" :title="apagadoEmpresa(m.codigo) ? 'Apagado para toda la empresa' : cajaFija(u, m.codigo) ? 'Es lo único que usa su rol: cámbiele el rol antes de apagárselo' : ''"></td>
        </tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0">Aquí solo aparece lo que su plan incluye. Lo que no existe para su tipo de negocio ya viene apagado. Los módulos de facturación, gastos e inventario siempre están.</p>
    </div>
    <div class="card" v-if="roles"><h2>Qué puede hacer cada rol <small>los roles base no se editan; duplíquelos para crear uno propio</small></h2>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Rol</th><th>Alcance</th><th>Permisos</th><th class="num">Usuarios</th><th></th></tr></thead>
        <tbody><tr v-for="r in roles.roles" :key="r.rol">
          <td><Badge :value="r.rol"></Badge><div class="small muted" v-if="r.personalizado">personalizado</div><div class="small muted" v-if="r.exige_mfa">exige verificación en 2 pasos</div><div class="small muted" v-if="r.sin_caja">no se asigna: la empresa no tiene el punto de venta activo</div></td>
          <td style="white-space:normal;max-width:360px">{{r.descripcion || '—'}}</td>
          <td style="white-space:normal" class="small muted">{{r.permisos.map(p => roles.permisos[p] || p).join(' · ')}}</td>
          <td class="num">{{r.usuarios}}</td>
          <td><div class="acts" v-if="esAdmin"><button class="btn sm sec" v-if="!r.personalizado" @click="nuevoRol(r)">Duplicar</button><template v-else><button class="btn sm sec" @click="editarRol(r)">Editar</button><button class="btn icon" :disabled="r.usuarios > 0" :title="r.usuarios > 0 ? 'Tiene usuarios asignados' : 'Eliminar'" @click="eliminarRol(r)">🗑</button></template></div></td>
        </tr></tbody></table></div>
    </div>
    <Modal v-if="modal" :title="contador ? 'Agregar contador' : 'Agregar usuario'" @close="modal=false">
      <p class="muted small">La persona entrará con este correo y la contraseña temporal, y deberá cambiarla en su primer ingreso. Si el correo ya entra a otras empresas, conserva su contraseña de siempre.</p>
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="form.nombre"></Field>
        <Field label="Correo" req><input type="email" v-model="form.correo" placeholder="persona@empresa.cr"></Field>
        <Field label="Rol" req><select v-model="form.rol"><option v-for="r in ROLES" :key="r">{{r}}</option></select></Field>
        <Field label="Contraseña temporal" req><div class="row" style="gap:6px"><input v-model="form.password_temporal" class="mono" style="flex:1"><button class="btn ghost sm" @click="generar">Generar</button></div></Field>
      </div>
      <template #foot><button class="btn sec" @click="modal=false">Cancelar</button><button class="btn" @click="enviar">Agregar</button></template>
    </Modal>
    <Modal v-if="clave" :title="clave.titulo" @close="clave=null">
      <div class="alert info" style="margin:0 0 10px" v-if="clave.aviso">{{clave.aviso}}</div>
      <p style="margin:0">Contraseña temporal para <b>{{clave.correo}}</b>: <b class="mono">{{clave.clave}}</b>. Désela a la persona: deberá cambiarla al entrar.</p>
      <p class="small muted" style="margin:8px 0 0" v-if="clave.mfa">Conserva su verificación en dos pasos: al entrar también necesitará el código de su teléfono.</p>
      <template #foot><button class="btn sec" @click="copiarClave">Copiar contraseña</button><button class="btn" @click="clave=null">Listo</button></template>
    </Modal>
    <Modal v-if="cambio" :title="'Cambiar rol · ' + cambio.usuario.correo" @close="cambio=null">
      <Field label="Rol" req><select v-model="cambio.rol"><option v-for="r in rolesCambio" :key="r">{{r}}</option></select></Field>
      <Field label="Sucursal" v-if="sesion.sucursales.length" help="Amarrado a una sucursal solo ve y vende lo de ella; «Todas» puede cambiar desde la barra"><select v-model="cambio.sucursal_id"><option :value="null">Todas (puede cambiar)</option><option v-for="x in sesion.sucursales" :key="x.id" :value="x.id">{{x.nombre}}</option></select></Field>
      <p class="small muted" style="margin:8px 0 0">La empresa siempre conserva al menos un Administrador. Si el rol nuevo exige verificación en dos pasos, la persona deberá activarla al entrar.</p>
      <template #foot><button class="btn sec" @click="cambio=null">Cancelar</button><button class="btn" @click="guardarCambio">Guardar</button></template>
    </Modal>
    <Modal v-if="rolModal" :title="rolModal.id ? 'Editar rol' : 'Nuevo rol'" @close="rolModal=null">
      <div class="grid cols-2">
        <Field label="Nombre del rol" req><input v-model="rolModal.nombre" placeholder="Ej. Cajero, Asistente contable"></Field>
        <Field label="Descripción"><input v-model="rolModal.descripcion" placeholder="Para qué sirve este rol"></Field>
      </div>
      <h3 style="margin:12px 0 6px">Permisos</h3>
      <div class="grid cols-2" style="gap:6px">
        <label v-for="p in asignables()" :key="p" class="row" style="cursor:pointer;gap:8px;align-items:flex-start"><input type="checkbox" :checked="rolModal.permisos.includes(p)" @change="togglePermiso(p)" style="margin-top:3px"> <span>{{roles.permisos[p] || p}}</span></label>
      </div>
      <p class="small muted" style="margin:10px 0 0">Entrar y consultar va siempre incluido. Administrar usuarios y roles es solo del Administrador.</p>
      <div class="alert warn" style="margin-top:8px" v-if="rolModal.permisos.includes('configurar')">Este rol puede cambiar la configuración de la empresa: quienes lo tengan deberán activar la verificación en dos pasos.</div>
      <template #foot><button class="btn sec" @click="rolModal=null">Cancelar</button><button class="btn" :disabled="guardando" @click="guardarRol">{{guardando ? 'Guardando…' : 'Guardar rol'}}</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Mi perfil (contraseña y verificación en dos pasos — backend real)
const SecPerfil = {
  components: { SecHead, SelectorPaleta, RenunciaMfa },
  setup() { return { store, sesion, AVISO_RRHH_MFA }; },
  data() { return { pinCaja: { pin: '', password: '' }, pass: { actual: '', nueva: '', repetir: '' }, mfa: null, abiertas: {}, codigo: '', codigoOff: '', codigoResp: '', respaldo: null, sesiones: [], guardando: false, tab: 'cuenta', version: null, renuncia: null, verRenuncia: false, retirando: false, renunciaSync: false }; },
  computed: { usuario() { return sesion.usuario || {}; } },
  async created() { if (new URLSearchParams(location.hash.split('?')[1] || '').get('tab') === 'version') this.tab = 'version'; this.cargarSesiones(); this.cargarVersion(); this.cargarRenuncia(); },
  mounted() { if (new URLSearchParams(location.hash.split('?')[1] || '').get('aviso') === 'rrhh') this.$nextTick(() => { const el = this.$refs.tarjetaMfa; if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); }); },   // 4.7: llega desde Recursos humanos con candado
  methods: {
    async cargarSesiones() { try { this.sesiones = await api('/api/auth/sesiones'); } catch {} },
    async cargarVersion(todo) { try { this.version = await api('/api/version' + (todo ? '?todo=1' : '')); } catch {} },   // 3.72: las últimas 12; «ver todas» trae el resto
    async cambiarPaleta(p) {
      aplicarPaleta(p);
      try { await api('/api/auth/paleta', { method: 'POST', body: { paleta: p } }); if (sesion.usuario) sesion.usuario.paleta = p; toast('Colores actualizados', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    cambiosDe(v) { return this.abiertas[v.version] ? v.cambios : v.cambios.slice(0, 5); },   // 5 cambios por versión y «Ver más»
    // R124: cambiar de teléfono con el MFA activo exige la contraseña y un código vigente
    async cambiarTelefono() {
      const password = prompt('Para cambiar de teléfono, escriba su contraseña actual:'); if (!password) return;
      const codigo = prompt('Escriba el código actual de su aplicación (o un código de respaldo):'); if (!codigo) return;
      try { this.mfa = await api('/api/auth/mfa/activar', { method: 'POST', body: { password, codigo } }); this.codigo = ''; toast('Escanee el código nuevo y confírmelo', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
    tipo(t) { return { nuevo: 'Nuevo', arreglo: 'Arreglo', cambio: 'Cambio', hacienda: 'Hacienda' }[t] || t; },
    async cerrarTodas() {
      if (!confirm('Se cerrarán todas sus sesiones en todos los dispositivos, incluida esta. ¿Continuar?')) return;
      try { await api('/api/auth/salir-todas', { method: 'POST' }); } catch {} sesion.cerrar(false);
    },
    async guardarPin() {   // etapa 1
      try { await api('/api/auth/pin', { method: 'PUT', body: this.pinCaja }); toast(this.pinCaja.pin ? 'PIN de caja guardado' : 'PIN de caja quitado', 'ok'); this.pinCaja = { pin: '', password: '' }; }
      catch (e) { toast(e.message, 'err'); }
    },
    async cambiarPass() {
      if (this.pass.nueva.length < 12) return toast('La nueva contraseña debe tener al menos 12 caracteres', 'err');
      if (this.pass.nueva !== this.pass.repetir) return toast('Las contraseñas no coinciden', 'err');
      this.guardando = true;
      try { await api('/api/auth/password', { method: 'POST', body: { actual: this.pass.actual, nueva: this.pass.nueva } }); toast('Contraseña actualizada. Las sesiones en otros dispositivos se cerraron.', 'ok'); this.pass = { actual: '', nueva: '', repetir: '' }; if (sesion.usuario) sesion.usuario.debe_cambiar_password = false; this.cargarSesiones(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async activarMfa() { try { this.mfa = await api('/api/auth/mfa/activar', { method: 'POST' }); this.codigo = ''; } catch (e) { toast(e.message, 'err'); } },
    async confirmarMfa() {
      try { const r = await api('/api/auth/mfa/confirmar', { method: 'POST', body: { codigo: this.codigo } }); toast('Verificación en dos pasos activada', 'ok'); this.mfa = null; this.respaldo = r.respaldo; if (sesion.usuario) sesion.usuario.mfa_activo = true; this.refrescarSesion(); }
      catch (e) { toast(e.message, 'err'); }
    },
    // 4.7: después de activar o quitar la verificación se vuelve a leer la sesión del servidor: Recursos humanos aparece (o se va) del
    // menú sin recargar la página, y esta pantalla sigue a la vista con los códigos de respaldo
    async refrescarSesion() {
      const conCandado = sesion.rrhhConCandado;
      try { await sesion.refrescarPermisos(); if (conCandado && sesion.puede('rrhh')) toast('Recursos humanos ya está en el menú', 'ok'); }
      catch (e) { toast('No se pudo actualizar el menú: recargue la página (' + e.message + ')', 'err'); }
      this.cargarRenuncia();   // 4.7: activar la verificación borra la renuncia; aceptarla o retirarla cambia lo que muestra la tarjeta
    },
    // ---- 4.7: renuncia a la verificación en dos pasos (descargo de responsabilidad): estado, aceptarla y retirarla
    fechaRenuncia,
    async cargarRenuncia() {
      try { this.renuncia = await api('/api/auth/mfa/renuncia'); } catch { this.renuncia = null; return; }
      // cambió en el servidor (interruptor del sistema, política «sin excepción» de una empresa, otra pestaña): la sesión se pone al día una vez
      const s = sesion.usuario && sesion.usuario.mfa_renuncia, r = this.renuncia;
      if (!this.renunciaSync && s && (!!s.vigente !== !!r.vigente || (r.vigente && r.aplica && !r.permitida))) { this.renunciaSync = true; await this.refrescarSesion(); }
    },
    async trasRenuncia(r) { this.verRenuncia = false; if (r) this.renuncia = r; await this.refrescarSesion(); },
    claveCambiada() { if (sesion.usuario) sesion.usuario.debe_cambiar_password = false; },
    async retirarRenuncia() {
      const u = this.usuario;
      const sigue = u.mfa_activo ? 'Su verificación sigue activa' + (u.mfa_exigido_rol ? ' y ya no podrá desactivarla.' : '.')
        : (u.mfa_exigido_rol ? 'Deberá activar la verificación en dos pasos para seguir usando el sistema.' : 'Deberá activar la verificación en dos pasos para usar lo que la requiere, como Recursos humanos.');
      if (!confirm('¿Retirar su renuncia a la verificación en dos pasos? ' + sigue)) return;
      this.retirando = true;
      try { const r = await api('/api/auth/mfa/renuncia', { method: 'DELETE' }); this.renuncia = r; toast(r.mfa_pendiente ? 'Renuncia retirada: active la verificación en dos pasos para continuar' : 'Renuncia retirada', 'ok'); await this.refrescarSesion(); }
      catch (e) { toast(e.message, 'err'); }
      this.retirando = false;
    },
    async nuevoRespaldo() {
      if (!this.codigoResp) return toast('Escriba el código actual de su aplicación', 'err');
      try { const r = await api('/api/auth/mfa/respaldo', { method: 'POST', body: { codigo: this.codigoResp } }); this.respaldo = r.respaldo; this.codigoResp = ''; toast('Códigos de respaldo nuevos; los anteriores ya no sirven', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    copiarRespaldo() { navigator.clipboard?.writeText(this.respaldo.join('\n')).then(() => toast('Códigos copiados', 'ok')); },
    async desactivarMfa() {
      if (!this.codigoOff) return toast('Escriba el código actual de su aplicación para desactivar', 'err');
      try { await api('/api/auth/mfa/desactivar', { method: 'POST', body: { codigo: this.codigoOff } }); toast('Verificación en dos pasos desactivada', 'ok'); this.codigoOff = ''; if (sesion.usuario) sesion.usuario.mfa_activo = false; this.refrescarSesion(); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  template: `
  <div class="page">
    <SecHead title="Mi perfil" sub="Su cuenta de acceso (contraseña, verificación en dos pasos, sesiones) y la versión instalada del sistema."></SecHead>
    <div class="tabs"><button :class="{on: tab==='cuenta'}" @click="tab='cuenta'">Cuenta y seguridad</button><button :class="{on: tab==='version'}" @click="tab='version'">Versión<span v-if="version" class="muted"> · {{version.actual.version}}</span></button></div>
    <template v-if="tab==='cuenta'">
    <div class="alert warn" v-if="usuario.debe_cambiar_password">Su contraseña fue asignada por el administrador. Cámbiela ahora por una que solo usted conozca.</div>
    <div class="grid cols-2" style="align-items:start">
      <div class="card" style="grid-column:1/-1"><h2>Colores del sistema <small>Solo para su usuario</small></h2>
        <SelectorPaleta :model-value="usuario.paleta || 'turquesa'" @update:model-value="cambiarPaleta"></SelectorPaleta>
      </div>
      <div class="card"><h2>Cuenta</h2>
        <div class="grid" style="grid-template-columns:1fr">
          <div><div class="small muted">Nombre</div><b>{{usuario.nombre}}</b></div>
          <div><div class="small muted">Correo de acceso</div><b>{{usuario.correo}}</b></div>
          <div><div class="small muted">Rol en el sistema</div><Badge :value="usuario.es_superadmin ? 'Administrador del sistema' : (store.empresa?.rol || sesion.rol || 'Usuario')"></Badge></div>
        </div>
        <h2 style="margin-top:20px">Cambiar contraseña</h2>
        <div class="grid" style="grid-template-columns:1fr">
          <Field label="Contraseña actual" req><input type="password" v-model="pass.actual" autocomplete="current-password"></Field>
          <Field label="Nueva contraseña" req help="Mínimo 12 caracteres; evite palabras comunes o su correo"><input type="password" v-model="pass.nueva" autocomplete="new-password"></Field>
          <Field label="Repetir nueva contraseña" req><input type="password" v-model="pass.repetir" autocomplete="new-password" @keyup.enter="cambiarPass"></Field>
        </div>
        <div class="row end" style="margin-top:12px"><button class="btn" @click="cambiarPass" :disabled="guardando">Guardar contraseña</button></div>
        <div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--line)">
          <div style="font-weight:600;margin-bottom:4px">PIN de caja</div>
          <p class="small muted" style="margin:0 0 8px">Para entrar rápido en el programa FISITAAP Local. De 4 a 6 números. Solo sirve para usuarios de caja. Déjelo vacío para quitarlo.</p>
          <div class="row" style="gap:8px;flex-wrap:wrap"><input class="inp" type="password" inputmode="numeric" maxlength="6" v-model="pinCaja.pin" placeholder="PIN" autocomplete="off" style="max-width:120px"><input class="inp" type="password" v-model="pinCaja.password" placeholder="Su contraseña" autocomplete="current-password" style="max-width:220px"><button class="btn sec" @click="guardarPin">Guardar PIN</button></div>
        </div>
      </div>
      <div class="card" ref="tarjetaMfa"><h2>Verificación en dos pasos (MFA) <Badge :value="usuario.mfa_activo ? 'Activa' : 'Desactivada'" style="margin-left:8px"></Badge></h2>
        <div class="alert warn" v-if="sesion.rrhhConCandado"><b>{{AVISO_RRHH_MFA}}.</b> Su rol incluye Recursos humanos (salarios, cuentas bancarias y cédulas del personal): la sección aparece en el menú en cuanto la active<span v-if="renuncia && renuncia.aplica && renuncia.permitida && !renuncia.vigente"> o acepte el descargo de responsabilidad (al final de esta tarjeta)</span>.</div>
        <div class="alert warn" v-if="renuncia && renuncia.vigente && !usuario.mfa_activo"><b>Usted renunció a la verificación en dos pasos el {{fechaRenuncia(renuncia.fecha)}} (versión {{renuncia.version_aceptada}}).</b> Su cuenta queda protegida solo con su contraseña y usted asume la responsabilidad descrita en el <a class="link" :href="renuncia.url" target="_blank" rel="noopener">descargo</a>. Le recomendamos activarla.
          <div style="margin-top:6px" v-if="!renuncia.permitida && renuncia.motivo">{{renuncia.motivo}}</div>
          <div style="margin-top:6px" v-else-if="(renuncia.empresas_sin_excepcion || []).length">En {{renuncia.empresas_sin_excepcion.join(', ')}} se le sigue pidiendo: la empresa la exige sin excepción.</div>
          <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn" v-if="!mfa" @click="activarMfa">Activar la verificación (recomendado)</button><button class="btn ghost" @click="retirarRenuncia" :disabled="retirando">Retirar la renuncia</button></div></div>
        <div class="alert info" v-else-if="renuncia && renuncia.vigente"><b>Aceptó la renuncia a la verificación en dos pasos el {{fechaRenuncia(renuncia.fecha)}} (versión {{renuncia.version_aceptada}}).</b> Su verificación sigue activa y se le pide al entrar{{usuario.mfa_obligatorio ? '.' : '; si quiere dejar de usarla, desactívela abajo con un código de su aplicación.'}}
          <div style="margin-top:6px" v-if="!renuncia.permitida && renuncia.motivo">{{renuncia.motivo}}</div>
          <div class="row" style="margin-top:8px"><button class="btn ghost sm" @click="retirarRenuncia" :disabled="retirando">Retirar la renuncia</button></div></div>
        <div class="alert warn" v-else-if="renuncia && renuncia.aceptada && !usuario.mfa_activo"><b>La renuncia que aceptó el {{fechaRenuncia(renuncia.fecha)}} ya no vale.</b> {{renuncia.desactualizada ? 'El texto del descargo cambió: léalo y acéptelo de nuevo al final de esta tarjeta, o active la verificación.' : (renuncia.motivo || 'Active la verificación en dos pasos.')}}</div>
        <p class="small muted">Además de su contraseña, se le pedirá un código de 6 dígitos generado por una aplicación como Google Authenticator, Microsoft Authenticator o Authy.</p>
        <div class="row" style="margin:0 0 10px" v-if="usuario.mfa_activo && !mfa"><button class="btn sec sm" @click="cambiarTelefono">Cambiar de teléfono</button><span class="small muted">Si cambió de celular (pide su contraseña y un código vigente o de respaldo)</span></div>
        <template v-if="!usuario.mfa_activo">
          <button class="btn" v-if="!mfa" v-show="!(renuncia && renuncia.vigente)" @click="activarMfa">Activar verificación en dos pasos</button>
          <div v-else>
            <ol class="small" style="padding-left:18px;margin:0 0 10px"><li>Abra su aplicación de autenticación y escanee el código.</li><li>Escriba el código de 6 dígitos que muestra la aplicación y confirme.</li></ol>
            <div class="row" style="align-items:flex-start;gap:16px">
              <img :src="mfa.qr" style="width:170px;height:170px;border:1px solid var(--line);border-radius:8px">
              <div style="flex:1"><div class="small muted">Si no puede escanear, escriba esta clave en la aplicación:</div><div class="mono" style="word-break:break-all;margin:4px 0 12px">{{mfa.secreto}}</div>
                <Field label="Código de 6 dígitos"><input v-model="codigo" inputmode="numeric" maxlength="6" class="mono" style="font-size:20px;letter-spacing:6px" @keyup.enter="confirmarMfa"></Field>
                <div class="row" style="margin-top:10px"><button class="btn" @click="confirmarMfa">Confirmar y activar</button><button class="btn ghost" @click="mfa=null">Cancelar</button></div></div>
            </div>
          </div>
        </template>
        <template v-else>
          <div v-if="respaldo" style="margin-bottom:14px">
            <div class="small"><b>Códigos de respaldo</b> (cada uno sirve una sola vez; no se volverán a mostrar):</div>
            <div class="mono" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:10px;border:1px dashed var(--line);border-radius:8px;margin:6px 0"><span v-for="c in respaldo" :key="c">{{c}}</span></div>
            <button class="btn sm sec" @click="copiarRespaldo">Copiar</button>
          </div>
          <Field label="Generar códigos de respaldo nuevos (escriba el código actual de su aplicación)"><div class="row" style="gap:6px"><input v-model="codigoResp" inputmode="numeric" maxlength="6" class="mono" style="max-width:160px;font-size:18px;letter-spacing:6px"><button class="btn sec" @click="nuevoRespaldo">Generar</button></div></Field>
          <template v-if="!usuario.mfa_obligatorio">
            <Field label="Para desactivar, escriba el código actual de su aplicación" style="margin-top:12px"><input v-model="codigoOff" inputmode="numeric" maxlength="6" class="mono" style="max-width:200px;font-size:18px;letter-spacing:6px"></Field>
            <div class="row" style="margin-top:10px"><button class="btn danger" @click="desactivarMfa">Desactivar verificación en dos pasos</button></div>
          </template>
          <p class="small muted" v-else style="margin-top:12px">La verificación en dos pasos es obligatoria para el Administrador y para cualquier rol que pueda cambiar la configuración o los usuarios.</p>
        </template>
        <div class="small" style="margin-top:14px;padding-top:10px;border-top:1px solid var(--line)" v-if="renuncia && renuncia.aplica && renuncia.permitida && !renuncia.vigente && !mfa">
          <span class="muted">{{usuario.mfa_activo ? '¿Quiere dejar de usarla? Antes acepte el descargo de responsabilidad; después podrá desactivarla con un código sin perder el acceso.' : '¿Prefiere no usarla? Puede seguir sin ella si acepta el descargo de responsabilidad.'}}</span>
          <a class="link" style="cursor:pointer;margin-left:4px" @click="verRenuncia = true">{{renuncia.desactualizada ? 'Leer y aceptar el texto nuevo' : 'Continuar sin verificación en dos pasos'}}</a>
        </div>
        <RenunciaMfa v-if="verRenuncia" :correo="usuario.correo" @cerrar="verRenuncia = false" @aceptada="trasRenuncia" @clave="claveCambiada"></RenunciaMfa>
      </div>
    </div>
    <div class="card" style="margin-top:16px"><h2>Sesiones abiertas</h2>
      <p class="small muted">Dispositivos donde su cuenta tiene sesión activa. Las sesiones se cierran solas tras 60 minutos sin uso o 12 horas en total.</p>
      <table class="tbl"><thead><tr><th>Inicio</th><th>Última actividad</th><th>IP</th><th>Navegador</th><th></th></tr></thead>
        <tbody><tr v-for="s in sesiones" :key="s.id"><td>{{fechaHora(s.creada)}}</td><td>{{fechaHora(s.ultimo_uso)}}</td><td class="mono">{{s.ip||'—'}}</td><td class="small muted" style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{s.agente||'—'}}</td><td><Badge v-if="s.actual" value="Esta sesión"></Badge></td></tr></tbody></table>
      <div class="row end" style="margin-top:12px"><button class="btn danger" @click="cerrarTodas">Cerrar todas las sesiones</button></div>
    </div>
    </template>
    <template v-else>
      <div class="card" v-if="version">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div><div class="small muted">Versión instalada</div><div style="font-size:28px;font-weight:700;line-height:1.1">{{version.actual.version}}</div><div class="small muted" style="margin-top:4px">{{version.actual.fecha}} · {{version.actual.titulo}}</div></div>
          <div class="small muted" style="max-width:440px">Cada versión corresponde a una actualización del sistema. Abajo está lo nuevo y lo corregido en cada una.</div>
        </div>
        <div class="small muted" style="margin-top:14px;padding-top:12px;border-top:1px solid var(--line)">FISITAAP by Brillante Agencia es un servicio de <a class="link" href="https://itcoresync.com/" target="_blank" rel="noopener">IT Core Sync S.R.L.</a></div>
      </div>
      <div class="card" v-if="version"><h2>Historial de versiones</h2>
        <div v-for="v in version.historial" :key="v.version" style="padding:12px 0;border-top:1px solid var(--line)">
          <div class="row" style="gap:10px;align-items:baseline;flex-wrap:wrap"><b style="font-size:15px">Versión {{v.version}}</b><span class="small muted">{{v.fecha}}</span><Badge v-if="v.version===version.actual.version" value="Instalada"></Badge></div>
          <div style="margin:2px 0 6px">{{v.titulo}}</div>
          <ul class="small" style="margin:0;padding-left:18px"><li v-for="(c,i) in cambiosDe(v)" :key="i" style="margin:4px 0"><span v-if="c.tipo" class="muted" style="font-weight:600;margin-right:6px">[{{tipo(c.tipo)}}]</span>{{c.texto}}</li></ul>
          <a class="link small" style="cursor:pointer;display:inline-block;margin-top:6px" v-if="v.cambios.length > 5" @click="abiertas[v.version] = !abiertas[v.version]">{{abiertas[v.version] ? 'Ver menos' : 'Ver más (' + (v.cambios.length - 5) + ' cambios más)'}}</a>
        </div>
        <button class="btn sec sm" v-if="version.total > version.historial.length" @click="cargarVersion(true)" style="margin-top:8px">Ver las {{version.total}} versiones</button>
      </div>
      <div class="card" v-else><Empty icon="ℹ" title="Sin información de versión" text="No se pudo leer las novedades del sistema."></Empty></div>
    </template>
  </div>`,
};

// ------------------------------------------------------------------ Monedas (helper monedas de api.js)
const SecMonedas = {
  components: { SecHead },
  data() { return { lista: monedas.list(), modal: false, form: { codigo: '', nombre: '', simbolo: '', tipo_cambio: 1 }, editando: false, tc: store.tc, margen: store.empresa?.margen_cambiario ?? 5, cargandoTC: false, hist: { anios: [], filas: [] }, histAnio: null, histMes: '' }; },
  async created() { this.cargarHist(); if (!this.tc) await this.actualizarTC(false); },
  computed: {
    principal() { return this.lista.find(m => m.principal) || this.lista[0]; },
    histFilas() { return this.histMes ? this.hist.filas.filter(f => f.fecha.slice(5, 7) === this.histMes) : this.hist.filas; },   // 4.18
    histCols() { return [{ key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'compra', label: 'Compra', num: true, fmt: v => fmt(v, 2) }, { key: 'venta', label: 'Venta', num: true, fmt: v => fmt(v, 2) }]; },
    columnas() { return [{ key: 'codigo', label: 'Código', mono: true }, { key: 'nombre', label: 'Nombre' }, { key: 'simbolo', label: 'Símbolo' }, { key: 'tipo_cambio', label: 'Tipo de cambio', num: true, fmt: v => fmt(v, 2) }, { key: 'principal', label: 'Principal', fmt: v => (v ? 'Principal' : '—') }]; },
  },
  methods: {
    fmt,
    refrescar() { this.lista = monedas.list(); },
    async cargarHist() { try { this.hist = await api('/api/tipo-cambio/historico' + (this.histAnio ? '?anio=' + this.histAnio : '')); this.histAnio = this.hist.anio; } catch (e) { toast(e.message, 'err'); } },   // 4.18
    exportarHist() { exportarTabla('tipo_cambio_dolar_' + this.histAnio, [{ key: 'fecha', label: 'Fecha', fmt: 'date' }, { key: 'compra', label: 'Compra', num: true }, { key: 'venta', label: 'Venta', num: true }], this.histFilas, { titulo: 'Tipo de cambio del dólar ' + this.histAnio }); },
    async actualizarTC(forzar = true) { this.cargandoTC = true; try { this.tc = await api('/api/tipo-cambio' + (forzar ? '?forzar=1' : '')); store.tc = this.tc; monedas.fijarVentaBCCR(this.tc && this.tc.venta); if (forzar) monedas.desfijarUSD(); if (this.tc.aplicado) monedas.actualizarUSD(this.tc.aplicado); this.refrescar(); if (forzar) toast(this.tc.error ? this.tc.error : 'Tipo de cambio actualizado', this.tc.error ? 'err' : 'ok'); } catch (e) { toast(e.message, 'err'); } this.cargandoTC = false; },
    async guardarMargen() { if (!(+this.margen >= 0 && +this.margen <= 100)) return toast('El margen debe estar entre 0 y 100 %', 'err'); try { this.tc = await api('/api/empresa/margen-cambiario', { method: 'PUT', body: { margen: +this.margen } }); store.tc = this.tc; monedas.fijarVentaBCCR(this.tc && this.tc.venta); if (store.empresa) store.empresa.margen_cambiario = +this.margen; if (this.tc.aplicado) monedas.actualizarUSD(this.tc.aplicado); this.refrescar(); toast('Margen guardado: el USD queda en ' + fmt(this.tc.aplicado, 2), 'ok'); } catch (e) { toast(e.message, 'err'); } },
    nuevo() { this.form = { codigo: '', nombre: '', simbolo: '', tipo_cambio: 1 }; this.editando = false; this.modal = true; },
    editar(m) { this.form = { ...m }; this.editando = true; this.modal = true; },
    guardar() {
      const c = String(this.form.codigo || '').toUpperCase().trim();
      if (!/^[A-Z]{3}$/.test(c)) return toast('El código debe tener 3 letras (ISO 4217), p. ej. EUR', 'err');
      if (!this.form.nombre.trim()) return toast('El nombre es obligatorio', 'err');
      if (!(+this.form.tipo_cambio > 0)) return toast('El tipo de cambio debe ser mayor que cero', 'err');
      // un USD editado a mano queda FIJO (no lo reemplaza el del día al volver a entrar); "Actualizar ahora" lo libera (R204)
      if (this.editando) monedas.save(this.lista.map(m => (m.codigo === c ? { ...m, nombre: this.form.nombre, simbolo: this.form.simbolo, tipo_cambio: +this.form.tipo_cambio, fijo: c === 'USD' ? +this.form.tipo_cambio !== +m.tipo_cambio || !!m.fijo : m.fijo } : m)));
      else { if (this.lista.some(m => m.codigo === c)) return toast('Esa moneda ya existe', 'err'); monedas.add({ codigo: c, nombre: this.form.nombre.trim(), simbolo: this.form.simbolo || c + ' ', tipo_cambio: +this.form.tipo_cambio }); }
      this.refrescar(); this.modal = false; toast('Moneda guardada', 'ok');
    },
    marcarPrincipal(m) { if (!['CRC', 'USD'].includes(m.codigo)) return toast('Por ahora la moneda principal solo puede ser CRC o USD: el Inicio y los reportes consolidan en esas dos monedas', 'err'); monedas.setPrincipal(m.codigo); this.refrescar(); toast(m.codigo + ' es ahora la moneda principal', 'ok'); },   // (R321)
    eliminar(m) { if (['CRC', 'USD'].includes(m.codigo)) return toast('CRC y USD son monedas del sistema y no se pueden eliminar'); if (m.principal) return toast('Marque otra moneda como principal antes de eliminar esta', 'err'); if (!confirm('¿Eliminar la moneda ' + m.codigo + '?')) return; monedas.remove(m.codigo); this.refrescar(); toast('Moneda eliminada'); },
    eliminarVarios(rows) { const ok = rows.filter(m => !['CRC', 'USD'].includes(m.codigo) && !m.principal); for (const m of ok) monedas.remove(m.codigo); this.refrescar(); const omit = rows.length - ok.length; toast(ok.length + ' monedas eliminadas' + (omit ? '; ' + omit + ' omitidas (del sistema o principal)' : ''), omit ? undefined : 'ok'); },
  },
  template: `
  <div class="page">
    <SecHead title="Monedas" sub="Moneda principal de la empresa y monedas adicionales con su tipo de cambio."><button class="btn" @click="nuevo">+ Crear moneda</button></SecHead>
    <div class="alert info">Moneda principal: <b>{{principal.codigo}} - {{principal.nombre}}</b>. Los tipos de cambio se expresan en colones (CRC) por cada unidad de la otra moneda, como los exige Hacienda, aunque la principal sea otra, y pueden ajustarse en cada documento.</div>
    <div class="card">
      <h2>Tipo de cambio del dólar <small>referencia BCCR publicada por Hacienda, se actualiza cada día</small></h2>
      <div v-if="tc && tc.venta" class="grid cols-4" style="align-items:end">
        <div><div class="small muted">Compra BCCR · {{fecha(tc.fecha)}}</div><b>₡{{fmt(tc.compra, 2)}}</b></div>
        <div><div class="small muted">Venta BCCR · {{fecha(tc.fecha)}}</div><b>₡{{fmt(tc.venta, 2)}}</b></div>
        <Field label="Margen de protección cambiaria (%)" help="Se suma a la venta del día"><input type="number" step="0.5" min="0" max="100" v-model.number="margen"></Field>
        <div><div class="small muted">Tipo de cambio aplicado al USD</div><b style="font-size:18px">₡{{fmt(tc.venta * (1 + (+margen || 0) / 100), 2)}}</b></div>
      </div>
      <div v-else class="muted">{{tc?.error || 'Consultando el tipo de cambio…'}}</div>
      <div class="alert warn" v-if="tc?.error" style="margin-top:8px">{{tc.error}}</div>
      <div class="row end" style="margin-top:10px;gap:8px"><button class="btn sec" @click="actualizarTC()" :disabled="cargandoTC">↻ Actualizar ahora</button><button class="btn" @click="guardarMargen" :disabled="!tc?.venta">Guardar margen</button></div>
      <p class="small muted" style="margin:8px 0 0">Con el margen guardado, cada documento en dólares toma este tipo de cambio automáticamente (se puede cambiar a mano en el documento). Ejemplo: venta ₡455,60 + 5 % = ₡478,38.</p>
    </div>
    <div class="card pad0">
      <DataTable :rows="lista" :columns="columnas" selectable :on-bulk-delete="eliminarVarios" empty-title="Sin monedas">
        <template #actions="{row}">
          <button class="btn sm sec" v-if="!row.principal" @click.stop="marcarPrincipal(row)">Marcar principal</button>
          <button class="btn icon" @click.stop="editar(row)" title="Editar tipo de cambio">✎</button>
          <button class="btn icon" v-if="!['CRC','USD'].includes(row.codigo)" @click.stop="eliminar(row)" title="Eliminar">🗑</button>
        </template>
      </DataTable>
    </div>
    <div class="card pad0" style="margin-top:14px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;padding:14px 16px 8px">
        <h2 style="margin:0">Histórico del dólar <small>referencia del Banco Central de Costa Rica; el sistema guarda su propio registro cada día</small></h2>
        <div class="row" style="gap:8px">
          <select v-model.number="histAnio" @change="cargarHist" aria-label="Año"><option v-for="a in hist.anios" :key="a" :value="a">{{a}}</option></select>
          <select v-model="histMes" aria-label="Mes"><option value="">Todo el año</option><option v-for="(m, i) in ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Setiembre','Octubre','Noviembre','Diciembre']" :key="i" :value="String(i + 1).padStart(2, '0')">{{m}}</option></select>
          <button class="btn sec" @click="exportarHist" :disabled="!histFilas.length">⤓ Exportar</button>
        </div>
      </div>
      <DataTable :rows="histFilas" :columns="histCols" :page-size="31" empty-title="Sin datos para ese período"></DataTable>
      <p class="small muted" style="padding:0 16px 14px;margin:0">La venta es la que se usa para pasar a colones. Cada documento usa el tipo de cambio que trae; si no trae uno, el de la venta de su día.</p>
    </div>
    <Modal v-if="modal" :title="editando ? 'Editar moneda ' + form.codigo : 'Crear moneda'" @close="modal=false">
      <div class="grid cols-2">
        <Field label="Código ISO" req help="3 letras, p. ej. EUR"><input v-model="form.codigo" maxlength="3" class="mono" :disabled="editando" style="text-transform:uppercase"></Field>
        <Field label="Símbolo"><input v-model="form.simbolo" maxlength="4" placeholder="€"></Field>
        <Field label="Nombre" req style="grid-column:1/-1"><input v-model="form.nombre" placeholder="Euro"></Field>
        <Field label="Tipo de cambio" req :help="'Colones (CRC) por 1 ' + (form.codigo || 'unidad')"><input type="number" step="0.0001" min="0" v-model.number="form.tipo_cambio" :disabled="form.codigo === 'CRC'"></Field>
      </div>
      <template #foot><button class="btn sec" @click="modal=false">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Numeraciones de comprobantes
// Documentos internos (3.26): no van a Hacienda; cada uno guarda su contador {prefijo, siguiente} en un registro de la empresa
// (el mismo que usa su formulario) y su número sale de prefijo + número de 4 dígitos. Nunca se repite uno ya usado.
const INTERNOS = [
  { clave: 'numeracion-cotizaciones', lista: 'cotizaciones', campo: 'numero', nombre: 'Cotización', plural: 'cotizaciones', prefijo: 'COT-', permiso: 'facturar', ruta: '#/ventas/cotizaciones' },
  { clave: 'numeracion-remisiones', lista: 'remisiones', campo: 'numero', nombre: 'Remisión', plural: 'remisiones', prefijo: 'REM-', permiso: 'facturar', ruta: '#/ventas/remisiones' },
  { clave: 'ordenes_numeracion', lista: 'ordenes', campo: 'codigo', nombre: 'Orden de compra', plural: 'órdenes de compra', prefijo: 'OC-', permiso: 'gastos', ruta: '#/gastos/ordenes' },
];
function usadosInternos(d, prefijo) {
  return (mock.get(d.lista, []) || []).map(x => String((x && x[d.campo]) || '')).filter(n => n.startsWith(prefijo || '')).map(n => n.slice((prefijo || '').length)).filter(n => /^\d+$/.test(n)).map(n => parseInt(n, 10));
}
const SecNumeraciones = {
  // Backend real: GET /api/numeraciones, PUT /api/numeraciones/{tipo}. Permite continuar la numeración de un sistema anterior.
  components: { SecHead },
  data() { return { info: null, edit: {}, guardando: false, cargando: true, internos: this.leerInternos() }; },
  computed: { esAdmin() { return sesion.puede('configurar') || sesion.esAdmin; } },   // cualquier rol con 'configurar', como exige el servidor (R298)
  methods: {
    // ---- documentos internos (3.26) ----
    leerInternos() {
      return INTERNOS.filter(d => sesion.puede(d.permiso) || sesion.puede('configurar')).map(d => {
        const g = mock.get(d.clave, null) || {}, prefijo = g.prefijo || d.prefijo, usados = usadosInternos(d, prefijo), maxUsado = usados.length ? Math.max(...usados) : 0;
        const siguiente = Math.max(+g.siguiente || 1, maxUsado + 1);
        return { ...d, prefijo, ultimo: siguiente - 1, minimo: maxUsado, emitidos: usados.length, prefijo0: prefijo, ultimo0: siguiente - 1 };
      });
    },
    proximoInterno(d) { return (d.prefijo || '') + String((+d.ultimo || 0) + 1).padStart(4, '0'); },
    cambioInterno(d) { return d.prefijo !== d.prefijo0 || +d.ultimo !== d.ultimo0; },
    guardarInterno(d) {
      const pre = String(d.prefijo || '').trim(), v = Number(d.ultimo);
      if (!pre || pre.length > 10) return toast('Indique un prefijo de 1 a 10 caracteres (por ejemplo COT-)', 'err');
      if (!Number.isInteger(v) || v < 0 || v > 99999999) return toast('Indique un número entero desde 0', 'err');
      const usados = usadosInternos(d, pre), maxUsado = usados.length ? Math.max(...usados) : 0;
      if (v < maxUsado) return toast(`Con el prefijo ${pre} ya existe el número ${maxUsado}: el último usado no puede ser menor`, 'err');
      if (!confirm(`La próxima ${d.nombre.toLowerCase()} saldrá con el número ${pre}${String(v + 1).padStart(4, '0')}. ¿Confirmar?`)) return;
      if (!mock.puedeGuardar()) return;
      mock.set(d.clave, { prefijo: pre, siguiente: v + 1 });
      toast('Numeración de ' + d.nombre.toLowerCase() + ' actualizada', 'ok');
      this.internos = this.leerInternos();
    },
    async cargar() {
      this.cargando = true;
      try { this.info = await api('/api/numeraciones'); this.edit = Object.fromEntries(this.info.numeraciones.map(n => [n.tipo, n.ultimo])); } catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    proximo(n) { const i = this.info || {}; return pad(n.sucursal || i.sucursal || 1, 3) + pad(i.terminal || 1, 5) + n.tipo + pad((+this.edit[n.tipo] || 0) + 1, 10); },   // 3.87: la serie de la sucursal activa (el REP, la principal)
    async guardar(n) {
      const v = Number(this.edit[n.tipo]);
      if (!Number.isInteger(v) || v < 0 || v > 9999999999) return toast('Indique un número entero entre 0 y 9999999999', 'err');
      if (v < n.minimo) return toast(`No puede ser menor que ${n.minimo}, el último consecutivo ya emitido en este ambiente`, 'err');
      if (v === n.ultimo) return toast('Sin cambios');
      if (!confirm(`El próximo ${n.nombre.toLowerCase()} saldrá con el número ${this.proximo(n)}. ¿Confirmar?`)) return;
      this.guardando = true;
      try { await api(`/api/numeraciones/${n.tipo}`, { method: 'PUT', body: { ultimo: v } }); toast('Numeración actualizada', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <SecHead title="Numeraciones" sub="Comprobantes electrónicos: consecutivo de 20 dígitos (sucursal + terminal + tipo + número). Más abajo, los documentos internos: cotizaciones, remisiones y órdenes de compra."><a class="btn ghost" href="#/configuracion/hacienda">Sucursal y terminal →</a></SecHead>
    <div class="alert info">¿Viene de otro sistema? Escriba en <b>Último número usado</b> el último consecutivo que emitió allí (solo el número, sin ceros a la izquierda) y el siguiente comprobante continuará la serie. La numeración es independiente por tipo de documento y por ambiente (pruebas / producción) y nunca puede retroceder por debajo de lo ya emitido aquí.</div>
    <div v-if="info" class="muted small" style="margin-bottom:10px">Ambiente actual: <b>{{info.ambiente === 'produccion' ? 'Producción' : 'Pruebas (sandbox)'}}</b> · Sucursal {{pad(info.sucursal,3)}} · Terminal {{pad(info.terminal,5)}}</div>
    <div class="grid cols-2" v-if="info">
      <div class="card" v-for="n in info.numeraciones" :key="n.tipo">
        <h2>{{n.nombre}} <small>tipo {{n.tipo}} · {{n.emitidos}} emitido(s) en este ambiente</small></h2>
        <div class="grid cols-2">
          <Field label="Último número usado" :help="n.minimo ? 'Mínimo permitido: ' + n.minimo : 'Aún no se ha emitido ninguno'"><input type="number" min="0" max="9999999999" step="1" v-model.number="edit[n.tipo]" :disabled="!esAdmin"></Field>
          <Field label="Próximo consecutivo"><input class="mono" :value="proximo(n)" disabled></Field>
        </div>
        <div class="row end"><button class="btn" @click="guardar(n)" :disabled="guardando || !esAdmin || edit[n.tipo] === n.ultimo">Guardar</button></div>
      </div>
    </div>
    <div class="alert warn" v-if="info && !esAdmin">Solo un Administrador de la empresa puede cambiar la numeración.</div>
    <template v-if="internos.length">
      <h2 style="margin:22px 0 4px">Documentos internos <small>no van a Hacienda: cotizaciones, remisiones y órdenes de compra</small></h2>
      <p class="small muted" style="margin:0 0 10px">Cada uno lleva su propio prefijo y número. Escriba el último número que usó en su sistema anterior y el siguiente continúa la serie; nunca se repite un número ya usado con el mismo prefijo.</p>
      <div class="grid cols-2">
        <div class="card" v-for="d in internos" :key="d.clave">
          <h2>{{d.nombre}} <small>{{d.emitidos}} registrada(s) con el prefijo {{d.prefijo0}}</small></h2>
          <div class="grid cols-3">
            <Field label="Prefijo"><input v-model="d.prefijo" maxlength="10" :disabled="!esAdmin"></Field>
            <Field label="Último número usado" :help="d.minimo ? 'Mínimo permitido: ' + d.minimo : 'Aún no hay ninguna'"><input type="number" min="0" step="1" v-model.number="d.ultimo" :disabled="!esAdmin"></Field>
            <Field label="Próximo número"><input class="mono" :value="proximoInterno(d)" disabled></Field>
          </div>
          <div class="row end" style="gap:8px"><a class="btn ghost" :href="d.ruta">Ver {{d.plural}}</a><button class="btn" @click="guardarInterno(d)" :disabled="!esAdmin || !cambioInterno(d)">Guardar</button></div>
        </div>
      </div>
    </template>
  </div>`,
  setup() { return { pad }; },
};

// ------------------------------------------------------------------ Configuración de documentos (backend real: GET/PUT/DELETE /api/config/documentos, /api/empresa/logo, POST /api/pdf/documento)
const TIPOS_DOC = [['factura', 'Factura'], ['tiquete', 'Tiquete'], ['nota_credito', 'Nota de crédito'], ['nota_debito', 'Nota de débito'], ['recibo_pago', 'Recibo electrónico de pago'], ['cotizacion', 'Cotización'], ['remision', 'Remisión'], ['orden_compra', 'Orden de compra'], ['recibo', 'Recibo']];   // (R207)
const TIPOS_PDF_DIRECTO = ['cotizacion', 'remision', 'orden_compra', 'recibo'];
const OPCIONES_DOC_BASE = () => ({ envio_auto: true, estado_cuenta: true, diferir_iva: false });

// Abre en una pestaña nueva el PDF devuelto por POST /api/pdf/documento (la pestaña se abre antes del fetch para evitar el bloqueo de ventanas emergentes).
async function abrirPdfDocumento(payload) {
  const w = window.open('', '_blank');
  try {
    // POST exige el token en el header (la cookie HttpOnly solo vale para GET)
    const r = await fetch('/api/pdf/documento', { method: 'POST', headers: cabecerasAuth({ 'Content-Type': 'application/json' }), body: JSON.stringify(payload) });
    if (!r.ok) { const j = await r.json().catch(() => null); const d = j && j.detail; throw new Error(typeof d === 'string' ? d : 'No se pudo generar el PDF'); }
    const url = URL.createObjectURL(await r.blob());
    if (w) w.location.href = url; else window.open(url, '_blank');
  } catch (err) { if (w) w.close(); throw err; }
}

// Documento de ejemplo para la vista previa de la configuración de impresión.
function documentoEjemplo(tipo, titulo, campos, terminos, notas) {
  const h = hoy(), v = new Date(h + 'T00:00:00'); v.setDate(v.getDate() + 15);
  const vence = `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  const numero = { cotizacion: 'COT-0001', remision: 'REM-0001', orden_compra: 'OC-0001', recibo: 'REC-0001' }[tipo] || '00100001010000000001';
  // comprobantes electrónicos: el PDF usa su diseño real (tabla de impuestos y leyenda), no el de cotización (R54)
  const tipoPdf = TIPOS_PDF_DIRECTO.includes(tipo) ? tipo : ({ factura: 'factura', tiquete: 'tiquete', nota_credito: 'nota_credito', nota_debito: 'nota_debito', notas: 'nota_credito' }[tipo] || 'cotizacion');
  return {
    tipo: tipoPdf, titulo, numero, fecha: h, vence, moneda: 'CRC', tipo_cambio: 1, clave: '5'.repeat(50), estado: 'Vista previa (sin valor fiscal)',
    condicion: 'Contado', vendedor: 'María Fernández', medio_pago: 'Transferencia',
    cliente: { nombre: 'Comercializadora Del Valle Ltda.', tipo_id: '02', cedula: '3102567890', telefono: '2222-3344', direccion: 'San José, Curridabat, 200 m norte de la iglesia', correo: 'compras@delvalle.cr' },
    lineas: [
      { detalle: 'Computadora portátil 14" i5 16 GB', descripcion: 'Garantía de 1 año con el fabricante', cabys: '4321500000100', cantidad: 2, precio_unitario: 485000, descuento: 20000, tarifa: 13, unidad_medida: 'Unid', es_servicio: false },
      { detalle: 'Instalación y configuración', descripcion: '', cabys: '8313000000000', cantidad: 3, precio_unitario: 25000, descuento: 0, tarifa: 13, unidad_medida: 'Sp', es_servicio: true },
    ],
    terminos: terminos || null, notas: notas || null, vista_previa_campos: campos,
  };
}

const SecDocumentos = {
  components: { SecHead },
  data() {
    return { cfg: null, tab: 'factura', form: { titulo: '', campos: [], terminos: '', notas: '' }, opciones: { ...OPCIONES_DOC_BASE(), ...mock.get('config_documentos_opciones', {}) }, logo: null, logoPendiente: false, guardando: false, generando: false, subiendo: false, TIPOS_DOC };
  },
  computed: {
    puedeLogo() { return sesion.puede('configurar'); },   // el servidor exige 'configurar' para subir el logo (R299)
    actual() { return this.cfg ? this.cfg.tipos[this.tab] : null; },
    nombreTab() { return (TIPOS_DOC.find(t => t[0] === this.tab) || [])[1] || ''; },
    ordenCatalogo() { const o = []; if (this.cfg) for (const g of Object.values(this.cfg.catalogo.grupos)) for (const c of g) o.push(c.clave); return o; },
    enLinea() { return red.enLinea; },   // 4.5: para reintentar el logo al volver la conexión
  },
  watch: { enLinea(v) { if (v && this.logoPendiente) this.cargarLogo(); } },   // 4.5: sin red el logo no se pidió (o falló): se vuelve a pedir en silencio al volver la conexión
  methods: {
    async cargar() {
      try { this.cfg = await api('/api/config/documentos'); this.seleccionar(this.tab); } catch (err) { toast(err.message, 'err'); }
    },
    async cargarLogo() {   // 3.87: sin logo, 204; 4.5: sin conexión no se intenta (ni error en consola ni aviso) y se reintenta al volver la red
      if (!red.enLinea) { this.logo = null; this.logoPendiente = true; return; }
      this.logoPendiente = false;
      try { const r = await fetch('/api/empresa/logo', { cache: 'no-store' }); this.logo = r.status === 200 ? '/api/empresa/logo?v=' + Date.now() : null; } catch { this.logo = null; this.logoPendiente = true; }
    },
    seleccionar(t) {
      this.tab = t; const d = this.cfg && this.cfg.tipos[t]; if (!d) return;
      this.form = { titulo: d.titulo || '', campos: [...(d.campos || [])], terminos: d.terminos || '', notas: d.notas || '' };
    },
    marcado(clave) { return this.form.campos.includes(clave); },
    alternar(clave) {
      const i = this.form.campos.indexOf(clave);
      if (i >= 0) this.form.campos.splice(i, 1); else this.form.campos.push(clave);
      this.form.campos.sort((a, b) => this.ordenCatalogo.indexOf(a) - this.ordenCatalogo.indexOf(b));
    },
    marcarGrupo(items, valor) { for (const c of items) { const tiene = this.marcado(c.clave); if (valor && !tiene) this.form.campos.push(c.clave); if (!valor && tiene) this.form.campos.splice(this.form.campos.indexOf(c.clave), 1); } this.form.campos.sort((a, b) => this.ordenCatalogo.indexOf(a) - this.ordenCatalogo.indexOf(b)); },
    async guardar() {
      if (!this.form.titulo.trim()) return toast('El título del documento es obligatorio', 'err');
      this.guardando = true;
      try {
        const r = await api('/api/config/documentos/' + this.tab, { method: 'PUT', body: { titulo: this.form.titulo.trim(), campos: this.form.campos, terminos: this.form.terminos || null, notas: this.form.notas || null } });
        this.cfg.tipos[this.tab] = r; this.seleccionar(this.tab);
        toast('Configuración de ' + this.nombreTab.toLowerCase() + ' guardada', 'ok');
      } catch (err) { toast(err.message, 'err'); }
      this.guardando = false;
    },
    async restaurar() {
      if (!confirm('¿Restaurar la configuración de "' + this.nombreTab + '" a los valores por defecto? Se perderán el título, los campos y los textos personalizados.')) return;
      try { const r = await api('/api/config/documentos/' + this.tab, { method: 'DELETE' }); this.cfg.tipos[this.tab] = r; this.seleccionar(this.tab); toast('Valores por defecto restaurados'); }
      catch (err) { toast(err.message, 'err'); }
    },
    async vistaPrevia() {
      if (!this.form.campos.length) return toast('Marque al menos un campo para la vista previa', 'err');
      this.generando = true;
      try { await abrirPdfDocumento(documentoEjemplo(this.tab, this.form.titulo.trim() || this.nombreTab, this.form.campos, this.form.terminos, this.form.notas)); }
      catch (err) { toast(err.message, 'err'); }
      this.generando = false;
    },
    async subirLogo(ev) {
      const file = ev.target.files && ev.target.files[0]; if (!file) return;
      if (!/^image\/(png|jpe?g)$/.test(file.type)) { ev.target.value = ''; return toast('El logo debe ser PNG o JPG', 'err'); }
      const fd = new FormData(); fd.append('archivo', file);
      this.subiendo = true;
      try { const r = await api('/api/empresa/logo', { method: 'POST', body: fd }); this.logo = r.logo; toast('Logo actualizado', 'ok'); }
      catch (err) { toast(err.message, 'err'); }
      this.subiendo = false; ev.target.value = '';
    },
    guardarOpciones() { mock.set('config_documentos_opciones', this.opciones); toast('Opciones guardadas', 'ok'); },
  },
  created() { this.cargar(); this.cargarLogo(); },
  template: `
  <div class="page">
    <SecHead title="Configuración de documentos" sub="Título, campos que se imprimen, términos y notas por defecto de cada tipo de documento.">
      <button class="btn sec" @click="vistaPrevia" :disabled="!cfg || generando">{{generando ? 'Generando…' : 'Vista previa PDF'}}</button>
      <button class="btn ghost" @click="restaurar" :disabled="!cfg">Restaurar valores por defecto</button>
      <button class="btn" @click="guardar" :disabled="!cfg || guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button>
    </SecHead>

    <div class="tabs"><button v-for="t in TIPOS_DOC" :key="t[0]" :class="{on: tab===t[0]}" @click="seleccionar(t[0])">{{t[1]}}<span v-if="cfg && cfg.tipos[t[0]].guardada" title="Configuración personalizada"> •</span></button></div>
    <div class="card" v-if="!cfg"><p class="muted" style="margin:0">Cargando configuración…</p></div>

    <template v-else>
      <div class="card"><h2>{{nombreTab}} <small>{{form.campos.length}} campos activos · {{actual.guardada ? 'configuración personalizada' : 'valores por defecto'}}</small></h2>
        <Field label="Título del documento" req help="Texto que encabeza el PDF" style="max-width:460px"><input v-model="form.titulo" :placeholder="cfg.catalogo.tipos[tab]"></Field>
        <div v-for="(items, grupo) in cfg.catalogo.grupos" :key="grupo" style="margin-top:16px">
          <div class="row" style="justify-content:space-between;margin-bottom:4px"><h3 style="margin:0;font-size:13px">{{grupo}}</h3><span class="small"><a class="link" @click="marcarGrupo(items, true)">Todos</a> · <a class="link" @click="marcarGrupo(items, false)">Ninguno</a></span></div>
          <div class="grid cols-3" style="gap:2px 16px">
            <label class="row" v-for="c in items" :key="c.clave" style="padding:4px 0"><input type="checkbox" :checked="marcado(c.clave)" @change="alternar(c.clave)"> {{c.etiqueta}}</label>
          </div>
        </div>
      </div>

      <div class="card"><h2>Textos por defecto <small>se imprimen al pie cuando los campos "Términos y condiciones" y "Notas" están activos</small></h2>
        <div class="grid cols-2">
          <Field label="Términos y condiciones" help="Por ejemplo, cuentas bancarias IBAN para el pago"><textarea v-model="form.terminos" rows="5"></textarea></Field>
          <Field label="Notas"><textarea v-model="form.notas" rows="5" placeholder="Gracias por su preferencia."></textarea></Field>
        </div>
      </div>

      <div class="card" v-if="tab==='factura'"><h2>Opciones</h2>
        <p class="small muted" style="margin:0">El envío automático de los comprobantes al cliente cuando Hacienda los acepta se activa en <a href="#/configuracion/empresa">Empresa › Correo saliente</a> («Envío automático»); ahí mismo se configura el remitente. Las opciones de estado de cuenta e IVA diferido se retiraron porque no tenían efecto; la condición de venta 10 (IVA diferido) se elige en cada factura.</p>
      </div>
    </template>

    <div class="card"><h2>Logo de la empresa <small>se imprime en el encabezado cuando el campo "Logo de la empresa" está activo</small></h2>
      <div class="row" style="gap:20px;align-items:center;flex-wrap:wrap">
        <div style="min-width:220px;min-height:90px;display:grid;place-items:center;border:1px solid var(--line);border-radius:6px;padding:8px;background:#fff"><img v-if="logo" :src="logo" alt="Logo" style="max-height:90px;max-width:280px"><span v-else class="muted">Sin logo</span></div>
        <div>
          <label class="btn sec" style="cursor:pointer" v-if="puedeLogo">{{subiendo ? 'Subiendo…' : (logo ? 'Cambiar logo' : 'Subir logo')}}<input type="file" accept="image/png,image/jpeg" style="display:none" @change="subirLogo" :disabled="subiendo"></label>
          <span class="small muted" v-else>Solo un rol con permiso de configuración puede cambiar el logo.</span>
          <div class="small muted" style="margin-top:6px">PNG o JPG, máx. 2 MB.</div>
        </div>
      </div>
    </div>
  </div>`,
};

// ------------------------------------------------------------------ Plantillas de impresión (estilo por empresa: registro estilo_impresion + firma_documentos; el servidor los aplica en cada PDF)
const ESTILO_BASE = { color: '#0f766e', tamano: 9.5, papel: 'carta', pie: '', firma_texto: '', mostrar_firma: true };
const SecPlantillas = {
  components: { SecHead },
  data() { return { e: { ...ESTILO_BASE, ...(mock.get('estilo_impresion', {}) || {}) }, firma: mock.get('firma_documentos', null), tipo: 'factura', tipos: [['factura', 'Factura'], ['cotizacion', 'Cotización'], ['orden_compra', 'Orden de compra'], ['recibo', 'Recibo']], generando: false }; },
  computed: { store() { return store; }, puede() { return sesion.puede('configurar'); } },
  methods: {
    guardar() {
      if (!/^#[0-9a-fA-F]{6}$/.test(this.e.color)) return toast('El color debe ser un valor como #0f766e', 'err');
      const e = { color: this.e.color.toLowerCase(), tamano: Math.min(12, Math.max(7.5, +this.e.tamano || 9.5)), papel: this.e.papel === 'a4' ? 'a4' : 'carta', pie: String(this.e.pie || '').slice(0, 200), firma_texto: String(this.e.firma_texto || '').slice(0, 80), mostrar_firma: this.e.mostrar_firma !== false };
      mock.set('estilo_impresion', e); this.e = { ...this.e, ...e }; toast('Estilo de impresión guardado: se aplica a todos los documentos desde ahora', 'ok');
    },
    restaurar() { this.e = { ...ESTILO_BASE }; mock.set('estilo_impresion', { ...ESTILO_BASE }); toast('Estilo restaurado al original', 'ok'); },
    subirFirma(ev) { const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = ''; if (!/^image\/(png|jpeg|webp)$/.test(f.type)) return toast('Suba una imagen PNG (fondo transparente) o JPG', 'err'); if (f.size > 300 * 1024) return toast('La firma debe pesar menos de 300 KB', 'err'); const rd = new FileReader(); rd.onload = () => { this.firma = rd.result; mock.set('firma_documentos', this.firma); toast('Firma guardada: se imprime al pie de facturas, cotizaciones y demás documentos', 'ok'); }; rd.readAsDataURL(f); },
    quitarFirma() { this.firma = null; mock.set('firma_documentos', null); toast('Firma quitada'); },
    // vista previa con el estilo YA guardado (el servidor lee el registro): una cotización de muestra
    async vistaPrevia() {
      if (JSON.stringify({ ...ESTILO_BASE, ...(mock.get('estilo_impresion', {}) || {}) }) !== JSON.stringify({ ...ESTILO_BASE, ...this.e })) toast('Guarde primero para ver los cambios en la vista previa');
      this.generando = true;
      const muestra = { tipo: this.tipo === 'factura' ? 'cotizacion' : this.tipo, numero: 'MUESTRA-001', fecha: hoy(), vence: hoy(), moneda: monedas.principal().codigo, tipo_cambio: 1, condicion: 'Contado',
        cliente: { nombre: 'Cliente de muestra S.A.', tipo_id: '02', cedula: '3101000000', telefono: '2222-2222', direccion: 'San José', correo: 'cliente@ejemplo.com' },
        lineas: [{ detalle: 'Producto de muestra', cantidad: 2, precio_unitario: 10000, descuento: 0, tarifa: 13, codigo_tarifa: '08', unidad_medida: 'Unid', es_servicio: false, cabys: '' }, { detalle: 'Servicio de muestra', cantidad: 1, precio_unitario: 25000, descuento: 0, tarifa: 13, codigo_tarifa: '08', unidad_medida: 'Sp', es_servicio: true, cabys: '' }], terminos: null, notas: 'Documento de muestra para revisar el estilo de impresión.' };
      try { await abrirPdfDocumento(muestra); } catch (e) { toast('No se pudo generar la vista previa: ' + e.message, 'err'); }
      this.generando = false;
    },
  },
  template: `
  <div class="page">
    <SecHead title="Plantillas de impresión" sub="Color, tamaño de letra, papel, firma y texto al pie de todos los documentos impresos y enviados (facturas, tiquetes, notas, cotizaciones, órdenes y recibos). Qué datos se imprimen en cada tipo se elige en Configuración de documentos."><button class="btn ghost" @click="restaurar" v-if="puede">Restaurar original</button><button class="btn sec" :disabled="generando" @click="vistaPrevia">{{generando ? 'Generando…' : '👁 Vista previa'}}</button><button class="btn" @click="guardar" v-if="puede">Guardar</button></SecHead>
    <div class="grid cols-2" style="align-items:start">
      <div class="card" style="margin:0"><h2>Estilo</h2>
        <div class="grid cols-2">
          <Field label="Color principal" help="Nombre de la empresa, título y número del documento"><div class="row" style="gap:8px"><input type="color" v-model="e.color" style="width:46px;height:36px;padding:2px"><input v-model="e.color" class="mono" style="flex:1" maxlength="7"></div></Field>
          <Field label="Tamaño de letra"><select v-model.number="e.tamano"><option :value="8.5">Pequeña (8,5)</option><option :value="9.5">Normal (9,5)</option><option :value="10.5">Grande (10,5)</option><option :value="11.5">Muy grande (11,5)</option></select></Field>
          <Field label="Tamaño de papel"><select v-model="e.papel"><option value="carta">Carta (21,6 × 27,9 cm)</option><option value="a4">A4 (21 × 29,7 cm)</option></select></Field>
          <Field label="Texto al pie de página" help="Hasta 200 caracteres; aparece centrado sobre la leyenda legal" style="grid-column:1/-1"><input v-model="e.pie" maxlength="200" placeholder="Gracias por su preferencia · www.suempresa.com"></Field>
        </div>
        <div style="margin-top:14px;padding:14px;border:1px solid var(--line);border-radius:8px;background:#fff">
          <div class="small muted" style="margin-bottom:6px">Muestra del encabezado</div>
          <div style="font-weight:700;font-size:15px" :style="{color: e.color, fontSize: (e.tamano+4.5)+'px'}">{{store.empresa?.nombre_comercial || store.empresa?.nombre || 'Su empresa'}}</div>
          <div :style="{fontSize: e.tamano+'px'}">Cédula · Teléfono · Correo</div>
          <div style="text-align:right;font-weight:700" :style="{color: e.color, fontSize: (e.tamano+2.5)+'px'}">Factura electrónica</div>
          <div class="small muted" style="margin-top:10px;text-align:center" v-if="e.pie">{{e.pie}}</div>
        </div>
      </div>
      <div class="card" style="margin:0"><h2>Firma en los documentos <small>imagen que se imprime al pie de facturas, cotizaciones y demás documentos</small></h2>
        <label class="drop" style="display:block"><img v-if="firma" :src="firma" style="max-height:80px;display:block;margin:0 auto 8px"><span>{{firma ? 'Cambiar firma' : 'Suba una imagen PNG con fondo transparente (máx. 300 KB)'}}</span><input type="file" accept="image/png,image/jpeg,image/webp" style="display:none" @change="subirFirma" :disabled="!puede"></label>
        <div class="row" style="margin-top:10px;gap:14px;align-items:flex-end">
          <Field label="Texto bajo la firma" style="flex:1"><input v-model="e.firma_texto" maxlength="80" placeholder="Firma autorizada"></Field>
          <label class="row" style="gap:6px;padding-bottom:10px"><input type="checkbox" v-model="e.mostrar_firma"> Imprimir la firma</label>
          <button class="btn ghost sm" v-if="firma && puede" @click="quitarFirma" style="margin-bottom:10px">Quitar firma</button>
        </div>
        <p class="small muted" style="margin:10px 0 0">El texto bajo la firma y la casilla se guardan con el botón Guardar.</p>
      </div>
    </div>
    <div class="card" style="margin-top:14px"><h2>Vista previa por tipo</h2><div class="row"><span class="chip" v-for="t in tipos" :key="t[0]" :class="{on: tipo===t[0]}" @click="tipo=t[0]">{{t[1]}}</span><button class="btn sec sm" :disabled="generando" @click="vistaPrevia">Abrir muestra en PDF</button></div>
      <p class="small muted" style="margin:8px 0 0">La factura de muestra se genera como cotización (los comprobantes electrónicos reales se imprimen desde Facturas de venta con el mismo estilo).</p></div>
  </div>`,
};

// ------------------------------------------------------------------ Contabilidad — Actualizar registros
const FUENTES_AUTO = [['doc', 'Comprobantes emitidos (ventas, notas, facturas de compra)'], ['rec', 'Comprobantes recibidos y aceptados'], ['pago', 'Pagos recibidos'], ['cm', 'Compras registradas a mano'], ['pg', 'Pagos a proveedores'], ['nd', 'Notas de débito a proveedores'], ['aj', 'Reversos y ajustes de compras y gastos de meses cerrados (rectificaciones)'],
  ['impc', 'Cobros hechos en el sistema anterior (ventas importadas)'], ['recp', 'Pagos hechos en el sistema anterior (comprobantes recibidos importados)'],
  ['pl', 'Planillas (devengo)'], ['plp', 'Pago de planillas'], ['lq', 'Liquidaciones'], ['lqp', 'Pago de liquidaciones'], ['ag', 'Aguinaldo'], ['cg', 'Pago de las cargas del mes (CCSS, INS y renta)'], ['act', 'Alta de activos fijos'], ['dep', 'Depreciación de activos'], ['actb', 'Baja de activos']];
const SecContabRegistros = {
  components: { SecHead },
  data() { return { sync: null, corriendo: false, ultima: mock.get('contab_sync', null), asientos: mock.get('asientos', []) || [] }; },
  computed: {
    filas() { const l = this.asientos.filter(a => a && a.automatico && a.origen); return FUENTES_AUTO.map(([k, nombre]) => { const de = l.filter(a => String(a.origen).split(':')[0] === k); return { k, nombre, total: de.length, ajustados: de.filter(a => a.ajustado).length, ultima: de.reduce((m, a) => (String(a.fecha) > m ? String(a.fecha) : m), '') }; }); },
  },
  methods: {
    fecha, fechaHora,
    async actualizar() {
      this.corriendo = true;
      try { this.sync = await sincronizarAutomaticos(); this.asientos = mock.get('asientos', []) || []; const u = { fecha: new Date().toISOString(), usuario: (sesion.usuario && sesion.usuario.correo) || '', ...this.sync }; mock.set('contab_sync', u); this.ultima = u;
        toast(this.sync.error ? 'No se pudo sincronizar: ' + this.sync.error : (resumenSync(this.sync) || 'Asientos automáticos al día: nada que cambiar') + (this.sync.bloqueados ? ' · ' + this.sync.bloqueados + ' de periodos cerrados sin cambios' : ''), this.sync.error ? 'err' : 'ok'); }
      catch (e) { toast('No se pudo sincronizar: ' + e.message, 'err'); }
      this.corriendo = false;
    },
  },
  template: `
  <div class="page">
    <SecHead title="Actualizar registros contables" sub="Regenera los asientos automáticos a partir de los comprobantes, pagos, compras, planillas y activos actuales. Los asientos ajustados a mano no se tocan."><button class="btn" :disabled="corriendo" @click="actualizar">{{corriendo ? 'Sincronizando…' : '↻ Actualizar ahora'}}</button></SecHead>
    <div class="card" v-if="ultima"><b>Última actualización:</b> {{fechaHora(ultima.fecha)}} <span class="muted" v-if="ultima.usuario">· {{ultima.usuario}}</span> <span class="muted" v-if="ultima.creados!==undefined">· {{ultima.creados||0}} nuevos, {{ultima.actualizados||0}} actualizados, {{ultima.eliminados||0}} eliminados</span></div>
    <div class="card"><p class="small muted" style="margin:0">Los asientos automáticos también se actualizan cada vez que se abre Contabilidad › Asientos contables, Libro diario o un reporte contable. Use este botón después de cambiar la parametrización contable o si sospecha que falta algún asiento.</p></div>
    <div class="card pad0"><div class="table-wrap"><table class="tbl">
      <thead><tr><th>Origen</th><th class="num">Asientos</th><th class="num">Ajustados a mano</th><th>Fecha más reciente</th></tr></thead>
      <tbody><tr v-for="r in filas" :key="r.k"><td>{{r.nombre}}</td><td class="num">{{r.total}}</td><td class="num">{{r.ajustados}}</td><td class="muted">{{r.ultima ? fecha(r.ultima) : '—'}}</td></tr></tbody>
    </table></div></div>
  </div>`,
};

// ------------------------------------------------------------------ Contabilidad — Parametrización
const SecContabParam = {
  components: { SecHead },
  data() {
    // cuentas de movimiento (hojas) del catálogo de la empresa: las creadas a mano también se pueden elegir (R59)
    const cuentasOpc = planCuentas().filter(c => c.hoja).map(c => c.codigo + ' ' + c.nombre);
    return { p: { ...PARAM_DEF, ...mock.get('param_contable', {}) }, CUENTAS, cuentasOpc, secciones: PARAM_SECCIONES };
  },
  methods: { guardar() { mock.set('param_contable', this.p); toast('Parametrización contable guardada', 'ok'); } },
  template: `
  <div class="page">
    <SecHead title="Parametrización contable" sub="Cuentas contables que el sistema usa al generar los asientos automáticos (ventas, IVA, compras, cobros)."><button class="btn" @click="guardar">Guardar</button></SecHead>
    <div class="card"><label class="row" style="cursor:pointer;gap:8px"><input type="checkbox" v-model="p.asientos_automaticos"> <b>Generar asientos automáticos</b></label>
      <p class="small muted" style="margin:6px 0 0">Por cada factura, nota, factura de compra, comprobante recibido y aceptado, y pago recibido, el sistema crea un asiento con estas cuentas (IVA débito y crédito incluidos). Se pueden ajustar en Contabilidad › Asientos contables; los ajustados no se vuelven a tocar.</p>
      <label class="row" style="cursor:pointer;gap:8px;margin-top:10px" v-if="p.asientos_automaticos !== false"><input type="checkbox" v-model="p.contabilizar_importados"> <b>Incluir los documentos importados de otro sistema (Alegra u otro)</b></label>
      <p class="small muted" style="margin:6px 0 0" v-if="p.asientos_automaticos !== false">Actívelo si la contabilidad del año se lleva aquí: las facturas y notas importadas también generan su asiento (ventas, IVA y cuentas por cobrar) y aparecen en el estado de resultados. Los meses ya cerrados no se tocan. Si esas ventas ya se cobraron en el otro sistema, registre los cobros o un asiento de ajuste para que las cuentas por cobrar queden al día. Déjelo apagado si esos documentos ya están en otra contabilidad.</p></div>
    <div class="card" v-for="s in secciones" :key="s[0]"><h2>{{s[0]}}</h2>
      <div class="grid cols-2"><Field v-for="c in s[1]" :key="c[0]" :label="c[1]" req><select v-model="p[c[0]]"><option v-if="p[c[0]] && !cuentasOpc.includes(p[c[0]])" :value="p[c[0]]">{{p[c[0]]}} (no está en el catálogo)</option><option v-for="q in cuentasOpc" :key="q">{{q}}</option></select></Field></div>
    </div>
  </div>`,
};

// ------------------------------------------------------------------ Contabilidad — Periodos
const MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const SecContabPeriodos = {
  components: { SecHead },
  data() { const anio = new Date().getFullYear(); return { anio, anios: [anio - 2, anio - 1, anio, anio + 1], meses: [] }; },
  watch: { anio: { immediate: true, handler() { this.cargar(); } } },
  methods: {
    fecha,
    cargar() {
      const hoyD = new Date();
      // sin datos guardados todos los meses arrancan abiertos: antes se pintaban cierres que nunca ocurrieron (R213)
      this.meses = mock.get('periodos_' + this.anio, null) || MESES.map((m, i) => ({ n: i + 1, mes: m, apertura: new Date(this.anio, i, 1).toISOString(), cierre: null, estado: 'Abierto' }));
    },
    guardar() { mock.set('periodos_' + this.anio, this.meses); },
    cierreExistente() { return (mock.get('asientos', []) || []).find(a => a && a.cierre === +this.anio); },
    async asientoCierre() {
      await sincronizarAutomaticos().catch(() => null);
      const ex = this.cierreExistente(); if (ex) return toast('El cierre del año ' + this.anio + ' ya existe: asiento ' + ex.codigo + '. Elimínelo en Asientos contables si necesita rehacerlo.', 'err');
      if (+this.anio >= new Date().getFullYear()) { if (!confirm('El año ' + this.anio + ' todavía no termina. ¿Generar de todas formas el asiento de cierre al 31/12/' + this.anio + '?')) return; }
      const asientos = mock.get('asientos', []) || [], a = asientoCierre(asientos, planConUsadas(asientos, planCuentas()), String(this.anio), paramContable());
      if (!a) return toast('No hay ingresos, costos ni gastos acumulados al 31/12/' + this.anio + ' para cerrar', 'err');
      { const per = periodoCerrado(a.fecha); if (per) return toast('Diciembre ' + this.anio + ' está cerrado: reábralo, genere el asiento de cierre y vuelva a cerrarlo', 'err'); }
      if (!confirm('Se creará el asiento ' + a.codigo + ' al 31/12/' + this.anio + ' que salda ingresos, costos y gastos y lleva ' + (a.resultado >= 0 ? 'una utilidad' : 'una pérdida') + ' de ' + money(Math.abs(a.resultado)) + ' a la cuenta de resultado (Parametrización contable). ¿Continuar?')) return;
      const nuevo = { id: mock.nextId(asientos, 'asientos'), ...a };
      mock.actualizar('asientos', l => [...(Array.isArray(l) ? l : []), nuevo], []);
      toast('Asiento de cierre ' + nuevo.codigo + ' creado', 'ok');
    },
    alternar(m) { if (m.estado === 'Abierto') { m.estado = 'Cerrado'; m.cierre = new Date().toISOString(); } else { m.estado = 'Abierto'; m.apertura = new Date().toISOString(); } this.guardar(); toast('Periodo ' + m.mes + ' ' + (m.estado === 'Cerrado' ? 'cerrado' : 'reabierto'), 'ok'); },
    cerrarAnio() { if (!confirm('¿Cerrar todos los periodos del año ' + this.anio + '? No se podrán registrar más asientos en esas fechas.')) return; for (const m of this.meses) if (m.estado === 'Abierto') { m.estado = 'Cerrado'; m.cierre = new Date().toISOString(); } this.guardar(); toast('Año ' + this.anio + ' cerrado', 'ok'); },
  },
  template: `
  <div class="page">
    <SecHead title="Control de periodos contables" sub="Cierre los meses ya contabilizados: no se podrán crear, editar ni eliminar asientos con esas fechas (los automáticos de un mes cerrado se registran en el siguiente mes abierto).">
      <select class="inp" v-model.number="anio"><option v-for="a in anios" :key="a" :value="a">{{a}}</option></select>
      <button class="btn sec" @click="asientoCierre" title="Salda ingresos, costos y gastos al 31/12 y lleva el resultado a la cuenta de utilidad o pérdida del ejercicio">Asiento de cierre del año</button>
      <button class="btn danger" @click="cerrarAnio">Cerrar año</button>
    </SecHead>
    <div class="card pad0"><div class="table-wrap"><table class="tbl">
      <thead><tr><th>N°</th><th>Mes</th><th>Última apertura</th><th>Último cierre</th><th>Estado</th><th></th></tr></thead>
      <tbody><tr v-for="m in meses" :key="m.n"><td class="muted">{{m.n}}</td><td>{{m.mes}} {{anio}}</td><td>{{fecha(m.apertura)}}</td><td>{{m.cierre ? fecha(m.cierre) : '—'}}</td><td><Badge :value="m.estado==='Abierto' ? 'Abierto' : 'Cerrado'"></Badge></td><td><div class="acts"><button class="btn sm" :class="m.estado==='Abierto' ? 'sec' : 'ghost'" @click="alternar(m)">{{m.estado==='Abierto' ? 'Cerrar' : 'Reabrir'}}</button></div></td></tr></tbody>
    </table></div></div>
  </div>`,
};

// ------------------------------------------------------------------ Contabilidad — Tipos de asientos
const SecContabTipos = {
  components: { SecHead },
  data() { return { rows: TIPOS_ASIENTO.map((t, i) => ({ id: i + 1, codigo: t[0], nombre: t[1] })), q: '' }; },
  template: `
  <div class="page">
    <SecHead title="Tipos de asientos contables" sub="Clasificación de los asientos manuales y automáticos. Los códigos son fijos; el tipo se elige al crear un asiento."></SecHead>
    <div class="card pad0"><div class="toolbar" style="padding:12px 12px 0"><input class="search" v-model="q" placeholder="Buscar"></div>
      <DataTable :rows="rows" :columns="[{key:'nombre',label:'Nombre'},{key:'codigo',label:'Código',mono:true,width:'120px'}]" :search="q" :page-size="20"></DataTable></div>
  </div>`,
};

// ------------------------------------------------------------------ Notificaciones de cobro
const SecNotificaciones = {
  components: { SecHead },
  data() {
    const base = {
      proximas: { activo: true, dias: 3, correo: true, whatsapp: false, asunto: 'Recordatorio: factura {{numero}} vence pronto', cuerpo: 'Estimado(a) {{cliente}}:\nLe recordamos que la factura {{numero}} por {{total}} vence el {{vencimiento}}. Puede realizar el pago por transferencia o SINPE Móvil.\n\n{{empresa}} · {{telefono}} · {{correo}}' },
      vencimiento: { activo: true, correo: true, whatsapp: true, asunto: 'Hoy vence la factura {{numero}}', cuerpo: 'Estimado(a) {{cliente}}:\nHoy {{fecha}} vence la factura {{numero}} por {{total}}. Agradecemos su pronto pago.\n\n{{empresa}}' },
      vencidas: { activo: false, dias: 5, correo: true, whatsapp: false, asunto: 'Factura {{numero}} vencida', cuerpo: 'Estimado(a) {{cliente}}:\nLa factura {{numero}} por {{total}} se encuentra vencida desde el {{vencimiento}}. Le solicitamos regularizar el pago a la brevedad.\n\n{{empresa}} · {{telefono}}' },
    };
    return { n: mock.get('notificaciones', null) || base, edit: null, vars: '{{numero}} {{fecha}} {{vencimiento}} {{total}} {{saldo}} {{empresa}} {{correo}} {{telefono}} {{cliente}} {{enlace}} {{hoy}}', bloques: [['proximas', 'Facturas próximas a vencer', 'Se envía {dias} días antes de la fecha de vencimiento.'], ['vencimiento', 'Facturas en su día de vencimiento', 'Se envía el mismo día del vencimiento.'], ['vencidas', 'Facturas vencidas', 'Se envía {dias} días después del vencimiento.']] };
  },
  methods: {
    guardar() { mock.set('notificaciones', this.n); toast('Notificaciones de cobro guardadas', 'ok'); },
    editar(k) { this.edit = { k, asunto: this.n[k].asunto, cuerpo: this.n[k].cuerpo }; },
    aplicar() { this.n[this.edit.k].asunto = this.edit.asunto; this.n[this.edit.k].cuerpo = this.edit.cuerpo; this.edit = null; this.guardar(); },
    desc(b) { return b[2].replace('{dias}', this.n[b[0]].dias ?? ''); },
  },
  template: `
  <div class="page">
    <SecHead title="Notificaciones de cobro" sub="Recordatorios automáticos por correo a los clientes con facturas a crédito pendientes: días antes del vencimiento, el día del vencimiento y días después. Se envían una vez al día con el correo de la empresa (Configuración › Facturación electrónica › Correo); cada factura recibe cada recordatorio una sola vez."><button class="btn" @click="guardar">Guardar</button></SecHead>
    <div class="alert info">Los recordatorios por WhatsApp no se envían solos: use el botón ⇪ Compartir de cada factura (abre WhatsApp con el mensaje y el enlace de consulta).</div>
    <div class="card" v-for="b in bloques" :key="b[0]">
      <div class="row" style="justify-content:space-between"><h2 style="margin:0">{{b[1]}}</h2><Toggle v-model="n[b[0]].activo" :label="n[b[0]].activo ? 'Activa' : 'Inactiva'"></Toggle></div>
      <p class="small muted" style="margin:6px 0 12px">{{desc(b)}}</p>
      <div class="grid cols-3" :style="n[b[0]].activo ? '' : 'opacity:.5;pointer-events:none'">
        <Field v-if="b[0]==='proximas'" label="Días antes del vencimiento" req><input type="number" min="1" max="60" v-model.number="n.proximas.dias"></Field>
        <Field v-else-if="b[0]==='vencidas'" label="Días después del vencimiento" req><input type="number" min="1" max="90" v-model.number="n.vencidas.dias"></Field>
        <div v-else></div>
        <Field label="Canales"><div class="row" style="padding:8px 0"><label class="row"><input type="checkbox" v-model="n[b[0]].correo"> Correo</label><label class="row"><input type="checkbox" v-model="n[b[0]].whatsapp"> WhatsApp</label></div></Field>
        <Field label="Plantilla"><div><button class="btn sec sm" @click="editar(b[0])">Ver y editar vista previa</button></div></Field>
      </div>
      <div class="small" style="margin-top:10px;padding:10px 12px;background:var(--bg);border-radius:6px"><b>{{n[b[0]].asunto}}</b><div class="muted" style="white-space:pre-line;margin-top:4px">{{n[b[0]].cuerpo}}</div></div>
    </div>
    <Modal v-if="edit" title="Vista previa de la plantilla" lg @close="edit=null">
      <p class="small muted">Variables disponibles: <span class="mono">{{vars}}</span></p>
      <Field label="Asunto"><input v-model="edit.asunto"></Field>
      <Field label="Mensaje"><textarea v-model="edit.cuerpo" rows="8"></textarea></Field>
      <template #foot><button class="btn sec" @click="edit=null">Cancelar</button><button class="btn" @click="aplicar">Guardar plantilla</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Plantillas de correo y WhatsApp
const DOCS_CORREO = [['factura', 'Factura de venta'], ['cotizacion', 'Cotización'], ['nota_credito', 'Nota de crédito'], ['remision', 'Remisión'], ['pago_recibido', 'Pago recibido'], ['pago_realizado', 'Pago realizado'], ['orden_compra', 'Orden de compra'], ['estado_cuenta', 'Estado de cuenta'], ['nota_debito', 'Nota de débito']];
function plantillasBase() {
  const correo = {}, whatsapp = {};
  for (const [k, n] of DOCS_CORREO) {
    correo[k] = { asunto: n + ' {{numero}} — {{empresa}}', cuerpo: 'Estimado(a) {{cliente}}:\n\nAdjuntamos la ' + n.toLowerCase() + ' {{numero}} con fecha {{fecha}}. Encontrará el PDF y el XML en este correo.\n\nCualquier consulta, con gusto le atendemos.\n\n{{empresa}}\n{{correo}} · {{telefono}}' };
    whatsapp[k] = { asunto: '', cuerpo: 'Hola {{cliente}}, le compartimos la ' + n.toLowerCase() + ' {{numero}} del {{fecha}}. Gracias por su preferencia. — {{empresa}} {{telefono}}' };
  }
  return { correo, whatsapp };
}
const SecPlantillasCorreo = {
  components: { SecHead },
  data() { return { tab: 'correo', p: { ...plantillasBase(), ...(mock.get('plantillas_correo', null) || {}) }, edit: null, vars: '{{numero}} {{fecha}} {{total}} {{empresa}} {{correo}} {{telefono}} {{cliente}} {{clave}} {{enlace}} {{hoy}}', DOCS_CORREO }; },
  methods: {
    editar(k) { this.edit = { k, ...this.p[this.tab][k] }; },
    aplicar() { this.p[this.tab][this.edit.k] = { asunto: this.edit.asunto, cuerpo: this.edit.cuerpo }; mock.set('plantillas_correo', this.p); this.edit = null; toast('Plantilla guardada', 'ok'); },
    restaurar() { if (!confirm('¿Restaurar todas las plantillas a los textos originales?')) return; this.p = plantillasBase(); mock.set('plantillas_correo', this.p); toast('Plantillas restauradas'); },
    nombre(k) { return (DOCS_CORREO.find(d => d[0] === k) || [])[1]; },
  },
  template: `
  <div class="page">
    <SecHead title="Plantillas de correo" sub="Textos con que se envían los comprobantes por correo (asunto y cuerpo; el PDF y el XML van adjuntos y el correo incluye el enlace de consulta) y mensaje para compartir por WhatsApp."><button class="btn ghost" @click="restaurar">Restaurar originales</button></SecHead>
    <div class="tabs"><button :class="{on: tab==='correo'}" @click="tab='correo'">Correo</button><button :class="{on: tab==='whatsapp'}" @click="tab='whatsapp'">WhatsApp</button></div>
    <p class="small muted">Variables disponibles: <span class="mono">{{vars}}</span>. El sistema usa «Factura de venta» para facturas, tiquetes y facturas de exportación, «Nota de crédito» y «Nota de débito» para las notas, y «Pago recibido» para los recibos electrónicos de pago; las demás quedan listas para cotizaciones y otros envíos manuales.</p>
    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(340px,1fr))">
      <div class="card" v-for="d in DOCS_CORREO" :key="d[0]" style="margin:0">
        <div class="row" style="justify-content:space-between"><h2 style="margin:0">{{d[1]}}</h2><button class="btn icon" @click="editar(d[0])" title="Editar">✎</button></div>
        <div class="small" style="margin-top:10px" v-if="tab==='correo'"><span class="muted">Asunto:</span> <b>{{p.correo[d[0]].asunto}}</b></div>
        <div class="small muted" style="white-space:pre-line;margin-top:6px;max-height:110px;overflow:hidden">{{p[tab][d[0]].cuerpo}}</div>
      </div>
    </div>
    <Modal v-if="edit" :title="'Plantilla · ' + nombre(edit.k) + (tab==='whatsapp' ? ' (WhatsApp)' : '')" lg @close="edit=null">
      <Field v-if="tab==='correo'" label="Asunto"><input v-model="edit.asunto"></Field>
      <Field :label="tab==='correo' ? 'Cuerpo del correo' : 'Mensaje de WhatsApp'"><textarea v-model="edit.cuerpo" rows="9"></textarea></Field>
      <template #foot><button class="btn sec" @click="edit=null">Cancelar</button><button class="btn" @click="aplicar">Guardar</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Preferencias de comunicación
const SecPreferencias = {
  components: { SecHead },
  data() { return { p: { novedades: true, consejos: true, facturacion: true, seguridad: true, encuestas: false, eventos: false, ...mock.get('preferencias_u' + (sesion.usuario?.id || 0), {}) }, items: [['novedades', 'Novedades del producto', 'Nuevas funciones y mejoras.'], ['consejos', 'Consejos y buenas prácticas', 'Guías para sacarle provecho al sistema.'], ['facturacion', 'Avisos de facturación y suscripción', 'Cobros, vencimientos y cambios de plan.'], ['seguridad', 'Alertas de seguridad', 'Aviso por correo al iniciar sesión desde una conexión nueva (no se puede desactivar).'], ['encuestas', 'Encuestas de satisfacción', 'Ayúdenos a mejorar.'], ['eventos', 'Eventos y capacitaciones', 'Webinars sobre facturación electrónica y contabilidad.']] }; },
  methods: { guardar() { this.p.seguridad = true; mock.set('preferencias_u' + (sesion.usuario?.id || 0), this.p); toast('Preferencias guardadas', 'ok'); } },   // por usuario, no por empresa (R205)
  template: `
  <div class="page">
    <SecHead title="Preferencias de comunicación" sub="Elija qué comunicaciones desea recibir de nuestra parte (se guardan por usuario)."><button class="btn" @click="guardar">Guardar</button></SecHead>
    <div class="card">
      <div class="row" v-for="it in items" :key="it[0]" style="justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--line)"><div><b>{{it[1]}}</b><div class="small muted">{{it[2]}}</div></div><Toggle v-model="p[it[0]]" :style="it[0]==='seguridad' ? 'opacity:.6;pointer-events:none' : ''"></Toggle></div>
    </div>
  </div>`,
};

// ------------------------------------------------------------------ Integraciones (tokens de API para terceros: /api/auth/tokens-api)
const PERMISOS_API = [['facturar', 'Emitir comprobantes y cotizaciones'], ['cobros', 'Registrar cobros'], ['catalogos', 'Clientes e ítems'], ['inventario', 'Inventario'], ['gastos', 'Compras, pagos y bancos'], ['contabilidad', 'Contabilidad'], ['reportes', 'Reportes y resumen'], ['ver_todo', 'Lectura de todo']];
const SecIntegraciones = {
  components: { SecHead },
  data() { return { tokens: [], cargando: true, modal: false, f: { nombre: '', permisos: ['facturar'] }, nuevoToken: null, PERMISOS_API, origen: location.origin,
    tiles: [['✉', 'Correo IMAP', 'Lea el buzón de su empresa y reciba automáticamente los comprobantes que le envían sus proveedores.', '#/gastos/recepcion', 'Disponible'], ['☏', 'WhatsApp', 'Comparta facturas, notas y cotizaciones por WhatsApp con el enlace de consulta (botón ⇪ Compartir en Facturas de venta) y edite el mensaje en Plantillas de correo.', '#/ventas/facturas', 'Disponible'], ['🏦', 'Bancos', 'Importación de movimientos del banco para conciliar.', null, 'Próximamente'], ['🛍', 'Tiendas en línea', 'Facturación automática de ventas en línea.', null, 'Próximamente']] }; },
  computed: { puede() { return sesion.puede('configurar'); } },
  methods: {
    fechaHora,
    async cargar() { this.cargando = true; try { this.tokens = await api('/api/auth/tokens-api'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    nuevo() { this.f = { nombre: '', permisos: ['facturar'] }; this.nuevoToken = null; this.modal = true; },
    async crear() {
      if (String(this.f.nombre || '').trim().length < 3) return toast('Indique un nombre (por ejemplo, el sistema que se conecta)', 'err');
      if (!this.f.permisos.length) return toast('Elija al menos un permiso', 'err');
      try { const r = await api('/api/auth/tokens-api', { method: 'POST', body: { nombre: this.f.nombre.trim(), permisos: this.f.permisos } }); this.nuevoToken = r.token; await this.cargar(); toast('Token creado: cópielo ahora, no se volverá a mostrar', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async revocar(t) { if (!confirm('¿Revocar el token «' + t.nombre + '»? El sistema que lo usa dejará de tener acceso.')) return; try { await api('/api/auth/tokens-api/' + t.id, { method: 'DELETE' }); toast('Token revocado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async copiar(txt) { try { await navigator.clipboard.writeText(txt); toast('Copiado', 'ok'); } catch { toast('Seleccione y copie el texto a mano'); } },
    permisosTxt(p) { return (p || []).map(k => (PERMISOS_API.find(x => x[0] === k) || [k, k])[1]).join(', '); },
    async invalidarEnlaces() {
      if (!confirm('¿Invalidar todos los enlaces de consulta enviados hasta ahora? Los clientes que reciban un enlace viejo verán que ya no es válido; los correos nuevos llevarán enlaces nuevos.')) return;
      try { await api('/api/empresa/enlaces/invalidar', { method: 'POST', body: {} }); toast('Enlaces de consulta invalidados', 'ok'); } catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { if (this.puede) this.cargar(); else this.cargando = false; },
  template: `
  <div class="page">
    <SecHead title="Integraciones" sub="Conecte su cuenta con otras herramientas y permita que sus propios sistemas facturen y consulten datos a través de la API."><button class="btn ghost" v-if="puede" @click="invalidarEnlaces" title="Los enlaces públicos de consulta ya enviados dejan de abrir">Invalidar enlaces de consulta</button><button class="btn" v-if="puede" @click="nuevo">+ Nuevo token de API</button></SecHead>
    <div class="tiles"><a class="tile" v-for="t in tiles" :key="t[1]" :href="t[3] || null" style="cursor:default"><h3>{{t[0]}} {{t[1]}}</h3><p>{{t[2]}}</p><div class="links"><span class="badge" :class="t[3] ? 'ok' : ''">{{t[4]}}</span></div></a></div>
    <div class="card" style="margin-top:18px"><h2>API para sus sistemas <small>tokens de acceso</small></h2>
      <p class="small muted">Cada token actúa sobre esta empresa con los permisos que elija, en nombre de quien lo creó. Se envía en cada petición como <span class="mono">Authorization: Bearer fcr_…</span> a las mismas direcciones que usa esta aplicación (por ejemplo <span class="mono">GET {{origen}}/api/comprobantes</span>, <span class="mono">POST {{origen}}/api/comprobantes</span>, <span class="mono">GET {{origen}}/api/clientes</span>, <span class="mono">GET {{origen}}/api/productos</span>). Límite: 600 peticiones cada 5 minutos por token. Revoque el token si deja de usarse.</p>
      <div class="table-wrap" v-if="tokens.length"><table class="tbl">
        <thead><tr><th>Nombre</th><th>Identificador</th><th>Permisos</th><th>Creado</th><th>Último uso</th><th>Estado</th><th></th></tr></thead>
        <tbody><tr v-for="t in tokens" :key="t.id"><td>{{t.nombre}}</td><td class="mono">{{t.prefijo}}…</td><td class="small">{{permisosTxt(t.permisos)}}</td><td>{{fechaHora(t.creado)}}</td><td>{{t.ultimo_uso ? fechaHora(t.ultimo_uso) : '—'}}</td><td><Badge :value="t.revocado ? 'Revocado' : 'Activo'"></Badge></td><td><div class="acts"><button class="btn sm danger" v-if="!t.revocado && puede" @click="revocar(t)">Revocar</button></div></td></tr></tbody>
      </table></div>
      <p class="small muted" v-if="!puede">Solo un rol con permiso de configuración puede ver y administrar los tokens de API.</p>
      <Empty v-else-if="!cargando" icon="⌘" title="Aún no hay tokens de API" text="Cree un token para que su sistema (tienda en línea, ERP, hoja de cálculo) emita comprobantes o consulte datos de esta empresa."></Empty>
    </div>
    <Modal v-if="modal" title="Nuevo token de API" @close="modal=false">
      <template v-if="!nuevoToken">
        <Field label="Nombre" req help="Qué sistema lo usará"><input v-model="f.nombre" placeholder="Tienda en línea"></Field>
        <Field label="Permisos"><div><label class="row" v-for="p in PERMISOS_API" :key="p[0]" style="gap:8px;padding:4px 0"><input type="checkbox" :value="p[0]" v-model="f.permisos"> {{p[1]}}</label></div></Field>
      </template>
      <template v-else>
        <div class="alert ok">Token creado. Cópielo y guárdelo en su sistema: <b>no se volverá a mostrar</b>.</div>
        <div class="row" style="gap:8px"><input class="inp mono" :value="nuevoToken" readonly style="flex:1" @focus="$event.target.select()"><button class="btn sec" @click="copiar(nuevoToken)">Copiar</button></div>
        <p class="small muted" style="margin-top:10px">Ejemplo:<br><span class="mono">curl -H "Authorization: Bearer {{nuevoToken.slice(0,12)}}…" {{origen}}/api/comprobantes</span></p>
      </template>
      <template #foot><button class="btn ghost" @click="modal=false">{{nuevoToken ? 'Cerrar' : 'Cancelar'}}</button><button class="btn" v-if="!nuevoToken" @click="crear">Crear token</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Historial de correos (documentos reales + ejemplos)
const SecHistorialCorreos = {
  components: { SecHead },
  data() { return { docs: [], q: '', fallidos: [] }; },
  computed: {
    esDemo() { return demo.activo; },
    rows() {
      const de = store.empresa?.smtp_remitente || store.empresa?.correo || 'facturacion@empresa.cr';
      const reales = this.docs.filter(d => d.correo_enviado).map(d => ({ id: 'd' + d.id, fecha: d.correo_enviado, de, descripcion: (CAT.tipoDoc[d.tipo_documento] || 'Documento') + ' ' + d.consecutivo + ' enviada a ' + (d.receptor_nombre || 'cliente'), estado: 'Entregado' }));
      const fallidos = this.fallidos.map(a => ({ id: 'f' + a.id, fecha: a.fecha, de, descripcion: 'No se pudo enviar: ' + (a.detalle || ''), estado: 'Error' }));   // (R209)
      if (!demo.activo) return [...reales, ...fallidos].sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
      const ejemplos = [['Cotización COT-00018 enviada a Clínica Dental Sonrisas', 'Leído', 2], ['Recordatorio de cobro FE-5712 a Ferretería El Tornillo Feliz', 'Entregado', 4], ['Estado de cuenta mensual a Importadora Guanacaste Ltda.', 'Error rebote', 9], ['Factura electrónica FE-5698 enviada a Restaurante La Casona', 'Error', 15]].map((x, i) => ({ id: 'e' + i, fecha: hace(x[2]), de, descripcion: x[0], estado: x[1], ejemplo: true }));
      return [...reales, ...fallidos, ...ejemplos].sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    },
    columnas() { return [{ key: 'fecha', label: 'Fecha de envío', fmt: v => fechaHora(v) }, { key: 'de', label: 'De' }, { key: 'descripcion', label: 'Descripción', fmt: (v, r) => v + (r.ejemplo ? ' (ejemplo)' : '') }, { key: 'estado', label: 'Estado', fmt: 'badge' }]; },
  },
  async created() { try { this.docs = await api('/api/comprobantes'); } catch (e) { toast(e.message, 'err'); } try { this.fallidos = (await api('/api/auth/auditoria?limite=300')).filter(a => a.accion === 'correo_fallido'); } catch {} },
  template: `
  <div class="page">
    <SecHead title="Historial de correos" sub="Comprobantes enviados por correo desde el sistema y los envíos que fallaron." :mock="esDemo"></SecHead>
    <div class="card pad0"><div class="toolbar" style="padding:12px 12px 0"><input class="search" v-model="q" placeholder="Buscar por descripción o estado"></div>
      <DataTable :rows="rows" :columns="columnas" :search="q" empty-title="Sin correos enviados"></DataTable></div>
  </div>`,
};

// ------------------------------------------------------------------ Historial de operaciones (auditoría real del servidor)
export const ACCIONES = {
  login: ['Plataforma', 'Inicio de sesión'], login_programa: ['Plataforma', 'Inicio de sesión en el programa local'], login_fallido: ['Seguridad', 'Intento de inicio de sesión fallido'], login_bloqueado: ['Seguridad', 'Intento durante bloqueo temporal'],
  login_rechazado: ['Seguridad', 'Acceso rechazado (cuenta bloqueada)'], captcha_fallido: ['Seguridad', 'Verificación contra robots no superada'],
  captcha_sin_respuesta: ['Seguridad', 'Cloudflare no respondió (se permitió la entrada)'], mfa_fallido: ['Seguridad', 'Código MFA incorrecto'], acceso_denegado: ['Seguridad', 'Intento de entrar a una empresa sin autorización'],
  cambio_empresa: ['Plataforma', 'Cambio de empresa activa'], cambio_password: ['Seguridad', 'Cambio de contraseña'], mfa_activado: ['Seguridad', 'Verificación en 2 pasos activada'],
  mfa_desactivado: ['Seguridad', 'Verificación en 2 pasos desactivada'], usuario_autorizado: ['Usuarios', 'Usuario autorizado en la empresa'], usuario_retirado: ['Usuarios', 'Autorización retirada'],
  config_empresa: ['Configuración', 'Datos de la empresa actualizados'], certificado_cargado: ['Configuración', 'Llave criptográfica (.p12) cargada'],
  emitir: ['Facturación', 'Comprobante emitido'], enviar_hacienda: ['Facturación', 'Comprobante enviado a Hacienda'], correo_enviado: ['Facturación', 'Comprobante enviado por correo'],
  setup_admin: ['Plataforma', 'Administrador del sistema creado'], cuenta_creada: ['Administración', 'Cuenta de cliente creada'], empresa_bloqueada: ['Administración', 'Acceso de la empresa bloqueado'],
  empresa_desbloqueada: ['Administración', 'Acceso de la empresa restablecido'], usuario_bloqueado: ['Administración', 'Usuario bloqueado'], usuario_desbloqueado: ['Administración', 'Usuario desbloqueado'],
  password_restablecida: ['Administración', 'Contraseña restablecida'], empresa_eliminada: ['Administración', 'Empresa eliminada'],
  usuario_password_restablecida: ['Usuarios', 'Contraseña de un usuario restablecida'],   // 4.35: desde Configuración › Usuarios
  soporte_entro_como: ['Seguridad', 'El soporte de FISITAAP entró como un usuario'], soporte_salio: ['Seguridad', 'El soporte de FISITAAP salió de la cuenta de un usuario'],   // 4.35: «Entrar como» desde la consola
  logout: ['Plataforma', 'Cierre de sesión'], logout_todas: ['Seguridad', 'Cierre de todas las sesiones'], cambio_ambiente: ['Configuración', 'Cambio de ambiente de Hacienda'],
  empresa_actualizada: ['Administración', 'Empresa actualizada'], numeracion_modificada: ['Configuración', 'Numeración modificada'], mfa_respaldo_usado: ['Seguridad', 'Código de respaldo usado'],
  mfa_respaldo_regenerado: ['Seguridad', 'Códigos de respaldo regenerados'], usuario_rol: ['Usuarios', 'Cambio de rol'], rol_creado: ['Usuarios', 'Rol creado'], rol_editado: ['Usuarios', 'Rol editado'],
  rol_eliminado: ['Usuarios', 'Rol eliminado'], anular: ['Facturación', 'Comprobante anulado'], correo_fallido: ['Facturación', 'Fallo al enviar el comprobante por correo'], correo_prueba: ['Configuración', 'Correo de prueba enviado'],
  pago_registrado: ['Cobros', 'Pago registrado'], pago_eliminado: ['Cobros', 'Pago eliminado'], recurrente_creada: ['Facturación', 'Factura recurrente creada'], recurrente_editada: ['Facturación', 'Factura recurrente editada'],
  recurrente_eliminada: ['Facturación', 'Factura recurrente eliminada'], recepcion_carga: ['Gastos', 'Comprobantes recibidos cargados'], recepcion_buzon: ['Gastos', 'Buzón de correo revisado'],
  recepcion_respuesta: ['Gastos', 'Respuesta a un comprobante recibido'], exportacion: ['Configuración', 'Exportación de datos'],
  // 4.23: el registro de compras y gastos (lo de un mes pasado queda además en Gastos › Rectificaciones)
  recepcion_clasificacion: ['Gastos', 'Comprobante recibido clasificado como compra o gasto'], gastos_registro_quitado: ['Gastos', 'Compra o gasto eliminado del registro'],
  gastos_registro_puesto: ['Gastos', 'Comprobante aceptado registrado de nuevo como compra o gasto'], gastos_reclasificado: ['Gastos', 'Factura de un mes pasado cambiada de compra a gasto o al revés'],
  mfa_renuncia_aceptada: ['Seguridad', 'Renuncia a la verificación en 2 pasos aceptada (descargo de responsabilidad)'], mfa_renuncia_retirada: ['Seguridad', 'Renuncia a la verificación en 2 pasos retirada'],
  mfa_renuncia_fallida: ['Seguridad', 'Contraseña incorrecta al aceptar la renuncia a la verificación en 2 pasos'], mfa_politica_empresa: ['Seguridad', 'Política de la verificación en 2 pasos de la empresa'],
  mfa_renuncia_interruptor: ['Seguridad', 'Renuncia a la verificación en 2 pasos permitida o apagada en el sistema'], mfa_renuncia_sin_correo: ['Seguridad', 'Constancia de la renuncia sin enviar (no hay correo configurado)'],
  mfa_renuncia_correo_fallido: ['Seguridad', 'No se pudo enviar la constancia de la renuncia por correo'],
  // 4.21: Recursos humanos (el servidor solo entrega las acciones «rrhh_…» a quien tiene ese permiso)
  rrhh_ficha_cambiada: ['Recursos humanos', 'Ficha de empleado cambiada'], rrhh_ficha_creada: ['Recursos humanos', 'Ficha de empleado creada'], rrhh_ficha_eliminada: ['Recursos humanos', 'Ficha de empleado eliminada'],
  rrhh_comprobante_descargado: ['Recursos humanos', 'Comprobante de pago descargado'],
  rrhh_lista_pago: ['Recursos humanos', 'Lista de pago descargada'], rrhh_comprobantes_impresos: ['Recursos humanos', 'Comprobantes descargados para imprimir'],
  rrhh_planilla_aprobada: ['Recursos humanos', 'Planilla aprobada'], rrhh_aprobacion_quitada: ['Recursos humanos', 'Aprobación de planilla quitada'],
  rrhh_parametro_aprobacion: ['Recursos humanos', 'Aprobación de planillas encendida o apagada'],
  rrhh_accion: ['Recursos humanos', 'Acción de personal registrada'], rrhh_accion_anulada: ['Recursos humanos', 'Acción de personal anulada'],
  rrhh_accion_aplicada: ['Recursos humanos', 'Acción de personal aplicada a la ficha'], rrhh_ficha_importada: ['Recursos humanos', 'Empleados importados desde un archivo'],
  // 4.22: documentos del empleado y pago de las cargas del mes
  rrhh_documento_subido: ['Recursos humanos', 'Documento de empleado subido'], rrhh_documento_cambiado: ['Recursos humanos', 'Documento de empleado cambiado'],
  rrhh_documento_descargado: ['Recursos humanos', 'Documento de empleado descargado'], rrhh_documento_eliminado: ['Recursos humanos', 'Documento de empleado eliminado'],
  rrhh_accion_eliminada: ['Recursos humanos', 'Acciones de personal eliminadas con la ficha del empleado'],
  rrhh_cargas_pagadas: ['Recursos humanos', 'Pago de las cargas del mes registrado'], rrhh_cargas_banco: ['Recursos humanos', 'Salida en Bancos de un pago de cargas registrada'],
  // 4.42 (L8): vacaciones, ausencias y horas extra (quién, de qué empleado y en qué fechas; nunca días, horas, montos ni el tipo de ausencia)
  rrhh_vacaciones: ['Recursos humanos', 'Vacaciones registradas'], rrhh_vacaciones_cambiadas: ['Recursos humanos', 'Vacaciones cambiadas'], rrhh_vacaciones_eliminadas: ['Recursos humanos', 'Vacaciones eliminadas'],
  rrhh_ausencia: ['Recursos humanos', 'Ausencia o incapacidad registrada'], rrhh_ausencia_cambiada: ['Recursos humanos', 'Ausencia o incapacidad cambiada'], rrhh_ausencia_eliminada: ['Recursos humanos', 'Ausencia o incapacidad eliminada'],
  rrhh_horas_extra: ['Recursos humanos', 'Horas extra registradas'], rrhh_horas_extra_cambiadas: ['Recursos humanos', 'Horas extra cambiadas'], rrhh_horas_extra_eliminadas: ['Recursos humanos', 'Horas extra eliminadas'],
  // 4.25: computadoras con el programa local (conectar una computadora nueva desde la página web)
  sinc_vinculada: ['Plataforma', 'Computadora conectada al programa local'], sinc_desvinculada: ['Plataforma', 'Computadora del programa local revocada'],
  sinc_descartada: ['Plataforma', 'Computadora descartada: no terminó de conectarse'], sinc_conexion_aprobada: ['Seguridad', 'Conexión de una computadora aprobada en la página web'],
  sinc_conexion_rechazada: ['Seguridad', 'Conexión de una computadora rechazada en la página web'], sinc_conexion_fallida: ['Seguridad', 'Número de comprobación equivocado en una computadora'],
  sinc_conexion_cancelada: ['Seguridad', 'Conexión de una computadora cancelada antes de entregarse'], sinc_conexion_anulada: ['Seguridad', 'Conexión de una computadora anulada en la revisión final'],
  sinc_aviso_reconocida: ['Seguridad', 'Computadora nueva reconocida por un administrador'],
  // 4.25 (tanda 6): en el programa local (esta computadora)
  sinc_local_vinculada: ['Plataforma', 'Esta computadora se conectó a la página web'], sinc_local_conexion_fallida: ['Plataforma', 'No se pudo guardar la conexión de esta computadora'],
  sinc_local_conexion_deshecha: ['Seguridad', 'Conexión de esta computadora deshecha: la web la revocó antes de terminar'],
  sinc_local_conexion_descartada: ['Seguridad', 'Conexión de esta computadora descartada: no se terminó a tiempo'],
  login_cuenta_local: ['Seguridad', 'Acceso rechazado: cuenta de esta computadora que ya no se usa'],
  cuenta_local_convertida: ['Seguridad', 'Administrador de esta computadora convertido en cuenta de la página web'], sinc_local_modo_soporte: ['Seguridad', 'Programa abierto en modo soporte'],
  // 4.25 (9b): ítem de la página web eliminado (o desactivado) desde el programa; código de otra empresa rechazado en esta computadora
  producto_eliminado_programa: ['Plataforma', 'Ítem eliminado desde el programa'], sinc_local_codigo_otra: ['Seguridad', 'Código de otra empresa rechazado en esta computadora'],
  // 4.31 (16a): conexión detenida porque la computadora tiene datos que no están en la página web
  sinc_conexion_bloqueada: ['Seguridad', 'Conexión de una computadora detenida: trae ventas que no están en la página web'],
  sinc_local_conexion_detenida: ['Seguridad', 'Conexión de esta computadora detenida: la empresa tiene datos que no están en la página web'],
};
export function filaAuditoria(a) {
  const legible = s => String(s || '').replace(/_/g, ' ').replace(/^./, c => c.toUpperCase());   // acción desconocida: texto legible, no el código (R206)
  const [solucion, descripcion] = ACCIONES[a.accion] || ['Otros', legible(a.accion)];
  return { id: a.id, usuario: a.correo || '—', fecha: a.fecha, solucion, descripcion: descripcion + (a.detalle ? ': ' + a.detalle : ''), ip: a.ip || '', empresa_id: a.empresa_id };
}
export function exportarAuditoria(rows, nombre) {
  exportarFilas(nombre, ['Usuario', 'Fecha', 'Solución', 'Descripción', 'IP'], rows.map(r => [r.usuario, fechaHora(r.fecha), r.solucion, r.descripcion, r.ip]), { titulo: 'Historial de operaciones' });
}
const SecHistorialOperaciones = {
  components: { SecHead },
  data() {
    return { rows: [], q: '', cargando: true, columnas: [{ key: 'usuario', label: 'Usuario' }, { key: 'fecha', label: 'Fecha', fmt: v => fechaHora(v) }, { key: 'solucion', label: 'Solución' }, { key: 'descripcion', label: 'Descripción' }, { key: 'ip', label: 'IP' }] };
  },
  async created() { try { this.rows = (await api('/api/auth/auditoria?limite=500')).map(filaAuditoria); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
  methods: { exportar() { exportarAuditoria(this.rows, 'historial_operaciones'); } },
  template: `
  <div class="page">
    <SecHead title="Historial de operaciones" sub="Auditoría de las acciones realizadas en esta empresa: quién, cuándo y desde qué dirección IP."><button class="btn sec" @click="exportar" :disabled="!rows.length">⤓ Exportar</button></SecHead>
    <div class="card pad0"><div class="toolbar" style="padding:12px 12px 0"><input class="search" v-model="q" placeholder="Buscar operación"></div>
      <DataTable :rows="rows" :columns="columnas" :search="q" empty-title="Sin operaciones registradas" empty-text="Aquí aparecerán los inicios de sesión, comprobantes emitidos, cambios de configuración y demás acciones."></DataTable></div>
  </div>`,
};

// ------------------------------------------------------------------ Suscripción y planes (solo visual)
const SecSuscripcion = {
  // 3.36: plan real de la empresa (/api/plan/suscripcion) y pago automático con tarjeta por Tilopay cuando el administrador del
  // sistema lo activó. La configuración de la pasarela no se ve aquí: vive en la consola de administración.
  components: { SecHead },
  data() { return { d: null, cargando: true, correo: '', activando: false, cancelando: false }; },
  computed: {
    s() { return this.d && this.d.suscripcion; },
    estadoTexto() { const e = this.s && this.s.estado; return ({ activa: 'Activo', pendiente: 'Pendiente de registrar la tarjeta', rechazada: 'Último cobro rechazado', pausada: 'En pausa', cancelada: 'Cancelado' })[e] || 'Sin pago automático'; },
    puedeActivar() { const e = this.s && this.s.estado; return !e || ['pendiente', 'cancelada', 'rechazada'].includes(e); },
    periodoTxt() { return this.d && this.d.monto && this.d.monto.periodo === 'anio' ? 'año' : 'mes'; },
  },
  methods: {
    money, fecha,
    async cargar(sinc) {
      this.cargando = true;
      try { this.d = await api('/api/plan/suscripcion' + (sinc ? '?sincronizar_ahora=1' : '')); if (!this.correo) this.correo = (this.s && this.s.correo) || this.d.correo_sugerido || ''; }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async pagarUnaVez() {   /* 3.97: un periodo con tarjeta, sin pago automático */
      if (!this.correo || !this.correo.includes('@')) return toast('Indique el correo para el comprobante del pago', 'err');
      this.activando = true;
      try { const r = await api('/api/plan/pago-unico', { method: 'POST', body: { correo: this.correo } }); location.href = r.url; }
      catch (e) { toast(e.message, 'err'); this.activando = false; }
    },
    async activar() {
      if (!/.+@.+\..+/.test(this.correo)) return toast('Escriba el correo donde recibirá los comprobantes de cada cobro', 'err');
      this.activando = true;
      try { const r = await api('/api/plan/suscripcion/activar', { method: 'POST', body: { correo: this.correo } }); location.href = r.url; }
      catch (e) { toast(e.message, 'err'); this.activando = false; }
    },
    async cancelar() {
      if (!confirm('¿Cancelar el pago automático? Su plan sigue vigente hasta la fecha de vencimiento; después debe pagar de otra forma.')) return;
      this.cancelando = true;
      try { await api('/api/plan/suscripcion/cancelar', { method: 'POST' }); toast('Pago automático cancelado', 'ok'); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.cancelando = false;
    },
  },
  async created() {
    const unico = (location.hash.match(/[?&]pago_unico=([a-z]+)/) || [])[1];   /* 3.97: vuelve de Tilopay (pago de una sola vez) */
    if (unico) { history.replaceState(null, '', '#/configuracion/suscripcion'); toast(unico === 'pagado' ? 'Pago recibido: su plan quedó al día' : unico === 'pendiente' ? 'Estamos confirmando su pago con Tilopay; en unos minutos se actualiza aquí' : 'El pago no se completó. Puede intentarlo de nuevo', unico === 'rechazado' ? 'err' : 'ok'); }
    const volvio = /[?&]tilopay=1/.test(location.hash);
    await this.cargar(volvio);
    if (volvio) {
      history.replaceState(null, '', '#/configuracion/suscripcion');
      if (this.s && this.s.estado === 'activa') toast('Listo: el pago automático quedó activo', 'ok');
      else toast('Estamos confirmando el registro con Tilopay; en unos minutos se actualiza aquí', 'ok');
    }
  },
  template: `
  <div class="page">
    <SecHead title="Suscripción y planes" sub="Su plan, el pago automático con tarjeta y el historial de pagos."></SecHead>
    <div class="card" v-if="cargando && !d"><p class="muted">Cargando…</p></div>
    <template v-else-if="d">
      <div class="card"><h2>Su plan</h2>
        <div class="row" style="gap:30px;flex-wrap:wrap">
          <div><div class="small muted">Plan</div><b>{{d.plan.nombre || 'Sin plan asignado'}}</b><div class="small muted" v-if="d.monto && d.monto.nombre && d.monto.nombre !== d.plan.nombre">{{d.monto.nombre}}</div></div>
          <div v-if="d.monto && d.monto.total"><div class="small muted">Precio</div><b>{{money(d.monto.total)}}</b><span class="chip" v-if="d.monto.acordado" style="margin-left:6px">Precio acordado</span> <span class="small muted">/ {{periodoTxt}} con IVA ({{money(d.monto.sin_iva)}} + {{money(d.monto.iva)}} de IVA)</span></div>
          <div><div class="small muted">Vence</div><b :class="{neg: d.plan.vencido}">{{d.plan.vence ? fecha(d.plan.vence) : '—'}}</b><div class="small neg" v-if="d.plan.vencido">Vencido: el sistema queda en modo de consulta hasta que se registre el pago</div></div>
          <div v-if="d.plan.limite_docs" title="Solo cuentan los comprobantes electrónicos emitidos a Hacienda en producción; los internos, los de pruebas y los importados de otro sistema no (4.5)"><div class="small muted">Comprobantes electrónicos del periodo</div><b>{{d.plan.docs_usados ?? '—'}} de {{d.plan.limite_docs}}</b></div>
        </div>
      </div>
      <div class="card" v-if="d.disponible"><h2>Pago automático con tarjeta</h2>
        <div class="alert warn" style="margin:0 0 10px" v-if="d.modo_prueba">Modo de prueba: los cobros no son reales.</div>
        <div class="alert info" style="margin:0 0 10px" v-if="d.monto && d.monto.motivo">{{d.monto.motivo}}</div>
        <template v-else>
          <div class="row" style="gap:30px;flex-wrap:wrap;margin-bottom:10px">
            <div><div class="small muted">Estado</div><Badge :value="estadoTexto"></Badge></div>
            <div v-if="s && s.proximo_cobro && s.estado === 'activa'"><div class="small muted">Próximo cobro</div><b>{{fecha(s.proximo_cobro)}}</b></div>
            <div v-if="s && s.estado === 'activa'"><div class="small muted">Monto de cada cobro</div><b>{{money(s.monto, s.moneda)}}</b></div>
            <div v-if="s && s.correo && s.estado !== 'cancelada'"><div class="small muted">Comprobantes de cobro a</div><b>{{s.correo}}</b></div>
          </div>
          <div class="alert warn" style="margin:0 0 10px" v-if="s && s.estado === 'rechazada'">Tilopay no pudo cobrar con la tarjeta registrada y lo vuelve a intentar en los próximos días. Si cambió de tarjeta, regístrela de nuevo abajo.</div>
          <div class="alert warn" style="margin:0 0 10px" v-if="s && s.estado === 'activa' && s.monto_distinto">El precio de su plan cambió. Para que el cobro automático use el monto nuevo, cancele el pago automático y vuelva a activarlo.</div>
          <template v-if="puedeActivar">
            <p class="small muted" style="margin:0 0 8px">Al activar, se abre la página segura de Tilopay para registrar su tarjeta una sola vez. Después se cobra {{periodoTxt === 'año' ? 'cada año' : 'cada mes'}} sin que tenga que hacer nada. FISITAAP by Brillante Agencia no ve ni guarda los datos de su tarjeta.</p>
            <div class="row" style="gap:8px;align-items:flex-end;flex-wrap:wrap"><Field label="Correo para los comprobantes de cobro" style="min-width:280px;margin:0"><input type="email" v-model="correo"></Field>
              <button class="btn sec" v-if="d.monto && d.monto.total && !(s && s.estado === 'activa')" @click="pagarUnaVez" :disabled="activando" title="Paga un periodo del plan con tarjeta, sin dejar el pago automático">Pagar {{periodoTxt === 'año' ? 'un año' : 'un mes'}} con tarjeta (una vez)</button>
              <button class="btn" @click="activar" :disabled="activando">{{activando ? 'Abriendo Tilopay…' : (s && s.estado === 'rechazada' ? 'Registrar otra tarjeta' : 'Activar pago automático')}}</button></div>
          </template>
          <div class="row" style="gap:8px;margin-top:10px" v-if="s && ['activa', 'rechazada', 'pausada', 'pendiente'].includes(s.estado)"><button class="btn ghost" @click="cancelar" :disabled="cancelando">Cancelar pago automático</button><button class="btn ghost" @click="cargar(true)">Actualizar estado</button></div>
        </template>
      </div>
      <div class="card" v-else><h2>Cómo pagar</h2><p class="muted" style="margin:0">Pague su plan por SINPE Móvil o transferencia y envíe el comprobante a su asesor de FISITAAP by Brillante Agencia; el pago se registra aquí y el vencimiento se extiende.</p></div>
      <div class="card pad0"><div style="padding:14px 16px 0"><h2>Historial de pagos</h2></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Medio</th><th class="num">Monto</th><th>Vigente hasta</th></tr></thead>
          <tbody><tr v-for="(p, i) in d.pagos" :key="i"><td>{{fecha(p.fecha)}}</td><td>{{p.medio || '—'}}</td><td class="num">{{money(p.monto, p.moneda)}}</td><td>{{p.vence_nuevo ? fecha(p.vence_nuevo) : '—'}}</td></tr>
            <tr v-if="!d.pagos.length"><td colspan="4" class="muted" style="text-align:center;padding:18px">Todavía no hay pagos registrados.</td></tr></tbody></table></div>
      </div>
    </template>
  </div>`,
};

// ------------------------------------------------------------------ Secciones tipo lista (fábrica)
const OTROS_CARGOS = ['Timbre Bomberos', 'Cobro de un tercero', 'Costos de exportación', 'Impuesto de servicio 10 %', 'Timbre Colegios Profesionales', 'Depósitos de garantía', 'Otros cargos'];
const pct = v => fmt(v, 2) + ' %';

const SecCentrosCostos = listaSimple({ titulo: 'Centros de costos', sub: 'Clasifique ingresos y gastos por área, proyecto o sucursal.', clave: 'centros_costos', singular: 'centro de costo', textoNuevo: '+ Nuevo centro de costo',
  semilla: [{ nombre: 'Administración', codigo: 'ADM', descripcion: 'Gastos administrativos generales' }, { nombre: 'Ventas', codigo: 'VEN', descripcion: 'Fuerza de ventas y mercadeo' }, { nombre: 'Sucursal Heredia', codigo: 'HER', descripcion: 'Operación de la sucursal' }],
  columnas: [{ key: 'codigo', label: 'Código', mono: true }, { key: 'nombre', label: 'Nombre' }, { key: 'descripcion', label: 'Descripción' }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true }, { key: 'codigo', label: 'Código' }, { key: 'descripcion', label: 'Descripción', tipo: 'textarea', ancho: true }] });

const SecTerminosPago = listaSimple({ titulo: 'Términos de pago', sub: 'Plazos de crédito que podrá elegir al facturar.', clave: 'terminos_pago', base: true, singular: 'plazo', textoNuevo: '+ Nuevo plazo',
  semilla: [...CAT.terminosPago.map(t => ({ ...t })), { nombre: 'Vencimiento manual', dias: null, sistema: true }],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'dias', label: 'Días', num: true, fmt: (v, r) => (r.sistema ? 'Definido en cada documento' : v) }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true, placeholder: '45 días' }, { key: 'dias', label: 'Días', tipo: 'number', req: true }], fijo: r => r.sistema });

const SecVendedores = listaSimple({ titulo: 'Vendedores', sub: 'Personas a quienes se les atribuyen las ventas para comisiones y reportes.', clave: 'vendedores', singular: 'vendedor', textoNuevo: '+ Nuevo vendedor',
  semilla: [{ nombre: 'María Fernández', identificacion: '108760432', observaciones: 'Zona GAM' }, { nombre: 'Carlos Jiménez', identificacion: '203450678', observaciones: 'Zona Guanacaste y Puntarenas' }, { nombre: 'Ana Rodríguez', identificacion: '304560123', observaciones: 'Ventas en línea' }],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'identificacion', label: 'Identificación', mono: true }, { key: 'observaciones', label: 'Observaciones' }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true }, { key: 'identificacion', label: 'Identificación' }, { key: 'observaciones', label: 'Observaciones', tipo: 'textarea', ancho: true }] });

const SecOtrosCargos = listaSimple({ titulo: 'Otros cargos', sub: 'Recargos de ley que se agregan al comprobante y están excluidos del IVA.', clave: 'otros_cargos', base: true, singular: 'cargo', textoNuevo: '+ Nuevo cargo',
  semilla: [{ nombre: 'Impuesto de servicio 10 %', porcentaje: 10, descripcion: 'Servicio en restaurantes y afines', cuenta_ventas: '2.1.05.02 Otros cargos por pagar', cuenta_compras: '6.5.01 Otros gastos' }, { nombre: 'Timbre Colegios Profesionales', porcentaje: 0, descripcion: 'Monto fijo según colegio', cuenta_ventas: '2.1.05.02 Timbre de Colegio Profesionales por pagar', cuenta_compras: '6.2.02.29 Timbres y especies fiscales' }],   // códigos del catálogo real (R208)
  columnas: [{ key: 'nombre', label: 'Nombre del cargo' }, { key: 'porcentaje', label: 'Porcentaje', num: true, fmt: pct }, { key: 'descripcion', label: 'Descripción' }, { key: 'cuenta_ventas', label: 'Cuenta ventas' }, { key: 'cuenta_compras', label: 'Cuenta compras' }],
  campos: [{ key: 'nombre', label: 'Nombre del cargo', req: true, tipo: 'select', opciones: OTROS_CARGOS, def: OTROS_CARGOS[0] }, { key: 'porcentaje', label: 'Porcentaje %', tipo: 'number', def: 0 }, { key: 'descripcion', label: 'Descripción', tipo: 'textarea', ancho: true }, { key: 'cuenta_ventas', label: 'Cuenta contable para ventas (pasivo por pagar)', req: true, tipo: 'select', opciones: CUENTAS, def: CUENTAS.find(c => c.startsWith('2.1.05')) || CUENTAS[0] }, { key: 'cuenta_compras', label: 'Cuenta contable para compras (gasto)', req: true, tipo: 'select', opciones: CUENTAS, def: CUENTAS.find(c => c.startsWith('6.')) || CUENTAS[0] }] });

const SecImpuestos = listaSimple({ titulo: 'Impuestos', sub: 'Tarifas de IVA vigentes en Costa Rica y otros impuestos que aplique en sus documentos.', clave: 'impuestos', base: true, singular: 'impuesto', textoNuevo: '+ Nuevo impuesto',
  semilla: [
    { nombre: 'IVA 13 %', tipo: 'IVA', porcentaje: 13, acreditable: true, descripcion: 'Tarifa general (código 08)', activo: true },
    { nombre: 'IVA exento', tipo: 'IVA', porcentaje: 0, acreditable: false, descripcion: 'Exento (código 10)', activo: true },
    { nombre: 'IVA 0,5 % reducido', tipo: 'IVA', porcentaje: 0.5, acreditable: true, descripcion: 'Canasta básica (código 09)', activo: true },
    { nombre: 'IVA 1 % reducido', tipo: 'IVA', porcentaje: 1, acreditable: true, descripcion: 'Canasta básica y agro (código 02)', activo: true },
    { nombre: 'IVA 2 % reducido', tipo: 'IVA', porcentaje: 2, acreditable: true, descripcion: 'Medicamentos, educación privada (código 03)', activo: true },
    { nombre: 'IVA 4 % reducido', tipo: 'IVA', porcentaje: 4, acreditable: true, descripcion: 'Boletos aéreos, salud privada (código 04)', activo: true },
    { nombre: 'IVA 8 % transitorio', tipo: 'IVA', porcentaje: 8, acreditable: true, descripcion: 'Tarifa transitoria (código 07)', activo: true },
    { nombre: 'Factor bienes usados 5,8 %', tipo: 'IVA factor', porcentaje: 5.8, acreditable: false, descripcion: 'Régimen de bienes usados', activo: false },
    { nombre: 'Factor bienes usados 5 %', tipo: 'IVA factor', porcentaje: 5, acreditable: false, descripcion: 'Régimen de bienes usados', activo: false },
    { nombre: 'Factor bienes usados 4,4 %', tipo: 'IVA factor', porcentaje: 4.4, acreditable: false, descripcion: 'Régimen de bienes usados', activo: false },
  ],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'tipo', label: 'Tipo' }, { key: 'porcentaje', label: 'Porcentaje', num: true, fmt: pct }, { key: 'acreditable', label: 'Impuesto acreditable', fmt: siNo }, { key: 'descripcion', label: 'Descripción' }, { key: 'activo', label: 'Activo', fmt: v => (v ? 'Activo' : 'Inactivo') }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true }, { key: 'tipo', label: 'Tipo', tipo: 'select', opciones: ['IVA', 'IVA factor', 'Selectivo de consumo', 'Otro'], def: 'IVA' }, { key: 'porcentaje', label: 'Porcentaje', tipo: 'number', req: true, def: 13 }, { key: 'descripcion', label: 'Descripción' }, { key: 'acreditable', label: 'Impuesto acreditable', tipo: 'check', def: true }, { key: 'activo', label: 'Activo', tipo: 'check', def: true }] });

const SecRetenciones = listaSimple({ titulo: 'Retenciones', sub: 'Retenciones que le aplican sus clientes o que usted aplica a proveedores.', clave: 'retenciones', singular: 'retención', textoNuevo: '+ Nueva retención', semilla: [],
  vacioTitulo: 'Aún no ha creado retenciones', vacioTexto: 'Cree, por ejemplo, la retención del 2 % de renta sobre servicios profesionales.',
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'porcentaje', label: 'Porcentaje', num: true, fmt: pct }, { key: 'tipo', label: 'Tipo' }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true, placeholder: 'Renta 2 % servicios profesionales' }, { key: 'porcentaje', label: 'Porcentaje', tipo: 'number', req: true, def: 2 }, { key: 'tipo', label: 'Tipo', tipo: 'select', opciones: ['Renta', 'IVA', 'Tarjetas (Decreto 37898)', 'Otra'], def: 'Renta' }] });

const SecContabNumeraciones = listaSimple({ titulo: 'Numeraciones contables', sub: 'Consecutivos para los asientos contables.', clave: 'numeraciones_contables', base: true, singular: 'numeración', textoNuevo: '+ Nueva numeración',
  semilla: [{ nombre: 'Asientos contables', prefijo: 'AC', siguiente: 1, preferida: true }, { nombre: 'Saldos iniciales', prefijo: 'SI', siguiente: 1, preferida: false }],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'prefijo', label: 'Prefijo', mono: true }, { key: 'siguiente', label: 'Siguiente número', num: true }, { key: 'preferida', label: 'Preferida', fmt: siNo }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true }, { key: 'prefijo', label: 'Prefijo', req: true }, { key: 'siguiente', label: 'Siguiente número', tipo: 'number', def: 1 }, { key: 'preferida', label: 'Preferida', tipo: 'check' }], fijo: r => r.preferida });

const SecCamposAdicionales = listaSimple({ titulo: 'Campos adicionales', sub: 'Información extra que podrá registrar en sus ítems e imprimir en la factura.', clave: 'campos_adicionales', singular: 'campo', textoNuevo: '+ Nuevo campo',
  semilla: [{ nombre: 'Marca', tipo: 'Texto', defecto: '', descripcion: 'Marca del producto', requerido: false, imprimir: true }, { nombre: 'Garantía (meses)', tipo: 'Número', defecto: '12', descripcion: '', requerido: false, imprimir: true }, { nombre: 'Fecha de vencimiento', tipo: 'Fecha', defecto: '', descripcion: 'Para perecederos', requerido: false, imprimir: false }],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'tipo', label: 'Tipo de campo' }, { key: 'defecto', label: 'Valor por defecto' }, { key: 'requerido', label: 'Requerido', fmt: siNo }, { key: 'imprimir', label: 'Imprimir en factura', fmt: siNo }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true }, { key: 'tipo', label: 'Tipo de campo', tipo: 'select', opciones: ['Texto', 'Número', 'Fecha', 'Lista'], def: 'Texto' }, { key: 'defecto', label: 'Valor por defecto' }, { key: 'descripcion', label: 'Descripción' }, { key: 'requerido', label: 'Requerido', tipo: 'check' }, { key: 'imprimir', label: 'Imprimir en factura', tipo: 'check' }] });

const SecVariantes = listaSimple({ titulo: 'Variantes', sub: 'Atributos (color, talla, material) para crear ítems con variantes.', clave: 'variantes', singular: 'variante', textoNuevo: '+ Nueva variante',
  semilla: [{ nombre: 'Color', atributos: 'Rojo, Azul, Negro, Blanco' }, { nombre: 'Talla', atributos: 'S, M, L, XL' }, { nombre: 'Material', atributos: 'Algodón, Poliéster' }],
  columnas: [{ key: 'nombre', label: 'Nombre' }, { key: 'atributos', label: 'Atributos' }],
  campos: [{ key: 'nombre', label: 'Nombre', req: true, placeholder: 'Color' }, { key: 'atributos', label: 'Atributos (separados por coma)', req: true, placeholder: 'Rojo, Azul, Negro', ancho: true }] });

// ------------------------------------------------------------------ enrutamiento interno
// ------------------------------------------------------------------ Sucursales (3.66)
const SecSucursales = {
  components: { SecHead },
  setup() { return { sesion }; },
  data() { return { lista: [], bodegas: [], marcas: [], form: null, cargando: true, guardando: false }; },
  computed: { puede() { return sesion.puede('configurar'); }, marcasElegibles() { return this.marcas.filter(m => m.activa || m.id === this.form?.marca_id); } },
  methods: {
    async cargar() {
      this.cargando = true;
      try { const r = await api('/api/sucursales'); this.lista = r.sucursales; } catch (e) { toast(e.message, 'err'); }
      try { this.bodegas = await api('/api/inventario/bodegas'); } catch { this.bodegas = []; }
      try { this.marcas = await api('/api/marcas'); } catch { this.marcas = []; }   /* 3.82 */
      this.cargando = false;
    },
    nombreMarca(id) { const m = this.marcas.find(x => x.id === id); return m ? m.nombre + (m.activa ? '' : ' (inactiva)') : 'La predeterminada'; },
    nombreBodega(id) { const b = this.bodegas.find(x => x.id === id); return b ? b.nombre : (id ? '#' + id : 'La principal'); },
    nueva() { const cod = Math.max(0, ...this.lista.map(x => +x.codigo || 0)) + 1; this.form = { id: null, codigo: cod, nombre: '', direccion: '', telefono: '', bodega_id: null, marca_id: null, activa: true, principal: false }; },
    editar(x) { this.form = { ...x }; },
    async guardar() {
      const f = this.form;
      if (!(f.nombre || '').trim()) return toast('Indique el nombre de la sucursal', 'err');
      if (!(+f.codigo >= 1 && +f.codigo <= 999)) return toast('El código va de 1 a 999', 'err');
      this.guardando = true;
      try { await api(f.id ? '/api/sucursales/' + f.id : '/api/sucursales', { method: f.id ? 'PUT' : 'POST', body: { codigo: +f.codigo, nombre: f.nombre.trim(), direccion: f.direccion || '', telefono: f.telefono || '', bodega_id: f.bodega_id || null, marca_id: f.marca_id || null, activa: !!f.activa } }); toast('Sucursal guardada. Si cambió algo que ve la barra superior, recargue la página.', 'ok'); this.form = null; await this.cargar(); try { await sesion.restaurar(); } catch {} }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async eliminar(x) {
      if (!confirm('¿Eliminar la sucursal «' + x.nombre + '»? Solo se puede si nunca emitió comprobantes.')) return;
      try { await api('/api/sucursales/' + x.id, { method: 'DELETE' }); toast('Sucursal eliminada', 'ok'); await this.cargar(); try { await sesion.restaurar(); } catch {} } catch (e) { toast(e.message, 'err'); }
    },
    codigo(x) { return String(x.codigo).padStart(3, '0'); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <SecHead title="Sucursales" sub="Una sola empresa y una sola cédula con varios locales. Cada sucursal lleva su código de Hacienda en el consecutivo, su bodega, sus cajas y su gente; el catálogo, los clientes, la contabilidad y los reportes consolidados se comparten."><button class="btn" v-if="puede" @click="nueva">+ Nueva sucursal</button></SecHead>
    <div class="alert info" v-if="lista.length <= 1">Hoy toda la empresa es una sola sucursal (la principal). Al crear la segunda aparece el selector de sucursal en la barra superior; a cada caja (Punto de venta › Configuración) y a cada usuario (Usuarios) se le indica su sucursal. Las sucursales adicionales son un extra del plan.</div>
    <div class="card pad0">
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Sucursal</th><th>Dirección</th><th>Teléfono</th><th>Bodega que rebaja</th><th>Marca (logo)</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          <tr v-for="x in lista" :key="x.id"><td class="mono">{{codigo(x)}}</td><td><b>{{x.nombre}}</b> <Badge v-if="x.principal" value="Principal"></Badge></td><td class="small">{{x.direccion || '—'}}</td><td class="small">{{x.telefono || '—'}}</td><td class="small">{{nombreBodega(x.bodega_id)}}</td><td class="small">{{nombreMarca(x.marca_id)}}</td><td><Badge :value="x.activa ? 'Activa' : 'Inactiva'"></Badge></td>
            <td style="text-align:right;white-space:nowrap"><button class="btn sm sec" v-if="puede" @click="editar(x)">Editar</button> <button class="btn icon" v-if="puede && !x.principal" @click="eliminar(x)" title="Eliminar">🗑</button></td></tr>
          <tr v-if="!lista.length && !cargando"><td colspan="8" class="muted" style="text-align:center;padding:18px">Sin sucursales</td></tr>
        </tbody></table></div>
    </div>
    <p class="small muted" style="margin:10px 0 0">El consecutivo de Hacienda lleva el código de sucursal (001, 002…). El código de la principal es el que la empresa ya usaba. Un usuario amarrado a una sucursal solo ve y vende lo de esa sucursal; el dueño y el contador cambian de sucursal desde la barra superior o ven todo con «Todas». Si la sucursal tiene marca, sus facturas, tiquetes, cotizaciones y órdenes de compra salen con ese logo y ese nombre comercial (se puede cambiar en cada documento).</p>
    <Modal v-if="form" :title="form.id ? 'Sucursal · ' + form.nombre : 'Nueva sucursal'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Código de Hacienda" req help="3 dígitos del consecutivo (1 a 999); no se cambia si ya emitió"><input type="number" min="1" max="999" v-model.number="form.codigo" :disabled="form.principal && form.id"></Field>
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="80" placeholder="Cartago, Alajuela…"></Field>
        <Field label="Dirección" style="grid-column:1/-1"><input v-model="form.direccion" maxlength="250"></Field>
        <Field label="Teléfono"><input v-model="form.telefono" maxlength="20"></Field>
        <Field label="Bodega que rebajan sus ventas" help="Vacío = la bodega principal"><select v-model="form.bodega_id"><option :value="null">— La principal —</option><option v-for="b in bodegas" :key="b.id" :value="b.id">{{b.nombre}}</option></select></Field>
        <Field label="Marca con que salen sus comprobantes" help="Logo y nombre comercial del PDF, del correo y de la factura; la cédula es siempre la de la empresa. Vacío = la marca predeterminada"><select v-model="form.marca_id"><option :value="null">— La predeterminada —</option><option v-for="m in marcasElegibles" :key="m.id" :value="m.id">{{m.nombre}}{{m.activa ? '' : ' (inactiva)'}}</option></select><div class="small muted" v-if="!marcas.length" style="margin-top:4px">Aún no hay marcas: créelas en <a class="link" href="#/configuracion/marcas">Marcas y logos</a>.</div></Field>
        <Field label="Activa" v-if="!form.principal"><Toggle v-model="form.activa" label="Se puede elegir y vender en ella"></Toggle></Field>
      </div>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar" :disabled="guardando">{{guardando ? 'Guardando…' : 'Guardar'}}</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Respaldos de la empresa (3.59)
const SecRespaldos = {
  components: { SecHead },
  data() { return { lista: null, maximo: 10, creando: false, bajando: '', restaurar: null, subiendo: false }; },
  created() { this.cargar(); },
  methods: {
    fechaHora,
    abrirRestaurar(r) { this.restaurar = { r, texto: '', trabajando: false }; },
    async confirmarRestaurar(programa) {
      const x = this.restaurar; if (!x || x.trabajando) return;
      if ((x.texto || '').trim().toUpperCase() !== 'RESTAURAR') return toast('Escriba RESTAURAR para confirmar', 'err');
      x.trabajando = true;
      try { const r = await api('/api/respaldos/' + encodeURIComponent(x.r.nombre) + '/restaurar', { method: 'POST', body: { confirmacion: x.texto, programa: programa === true } }); toast('Empresa restaurada desde ' + r.nombre + '. Se guardó una copia de seguridad del estado anterior (' + r.seguridad + '). La página se recarga.', 'ok'); if (r.pendiente && r.pendiente.length) alert((r.otra_instalacion ? 'Respaldo de otra instalación restaurado. ' : 'Empresa restaurada. ') + 'Queda pendiente:\n\n• ' + r.pendiente.join('\n• ')); setTimeout(() => location.reload(), 2500); }
      catch (e) {
        x.trabajando = false;
        /* 4.31 (16a): un respaldo del programa de una computadora se restaura en la web solo si la persona lo confirma */
        if (e && e.status === 409 && e.detail && e.detail.codigo === 'respaldo_programa' && programa !== true) { if (confirm(e.message)) this.confirmarRestaurar(true); return; }
        toast(e.message, 'err');
      }
    },
    async subir(ev) {
      const f = ev.target.files && ev.target.files[0]; ev.target.value = ''; if (!f) return;
      const fd = new FormData(); fd.append('archivo', f); this.subiendo = true;
      try { const r = await api('/api/respaldos/subir', { method: 'POST', body: fd }); toast('Respaldo subido: ' + r.nombre + (r.aviso ? '. ' + r.aviso : ''), r.aviso ? undefined : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
    kb(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB'; },
    async cargar() { try { const r = await api('/api/respaldos'); this.lista = r.respaldos; this.maximo = r.maximo; } catch (e) { toast(e.message, 'err'); this.lista = []; } },
    async crear() {
      this.creando = true;
      try { const r = await api('/api/respaldos', { method: 'POST' }); toast('Respaldo creado: ' + r.nombre + ' (' + this.kb(r.bytes) + ')', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
      this.creando = false;
    },
    async descargar(r) {
      this.bajando = r.nombre;
      try {
        const resp = await fetch('/api/respaldos/' + encodeURIComponent(r.nombre), { headers: cabecerasAuth() });
        if (!resp.ok) { const j = await resp.json().catch(() => ({})); throw new Error(j.detail || 'No se pudo descargar el respaldo'); }
        const blob = await resp.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = r.nombre; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      } catch (e) { toast(e.message, 'err'); }
      this.bajando = '';
    },
    async eliminar(r) {
      if (!confirm('¿Eliminar el respaldo ' + r.nombre + '? Si no lo descargó antes, se pierde.')) return;
      try { await api('/api/respaldos/' + encodeURIComponent(r.nombre), { method: 'DELETE' }); toast('Respaldo eliminado', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
  },
  template: `
  <div class="page">
    <SecHead title="Respaldos" sub="Copia completa de los datos de su empresa: base de datos, comprobantes electrónicos emitidos y recibidos, certificado, logo, exoneraciones, adjuntos y los documentos guardados en las fichas de los empleados. Créela cuando quiera, descárguela y guárdela fuera del sistema."></SecHead>
    <div class="card">
      <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <div class="small muted">Se guardan hasta {{maximo}} respaldos en el servidor: elimine los que ya descargó. Aparte, el sistema hace un respaldo general automático todos los días.</div>
        <div class="row" style="gap:8px"><label class="btn sec" :class="{disabled: subiendo}" style="cursor:pointer">{{subiendo ? 'Subiendo…' : '⤒ Subir un respaldo'}}<input type="file" accept=".zip" style="display:none" @change="subir" :disabled="subiendo"></label><button class="btn" @click="crear" :disabled="creando || (lista && lista.length >= maximo)">{{creando ? 'Creando…' : 'Crear respaldo ahora'}}</button></div>
      </div>
      <div class="table-wrap" style="margin-top:10px" v-if="lista && lista.length"><table class="tbl"><thead><tr><th>Archivo</th><th>Fecha</th><th class="num">Tamaño</th><th></th></tr></thead>
        <tbody><tr v-for="r in lista" :key="r.nombre"><td class="mono">{{r.nombre}} <span class="badge info" v-if="r.origen" :title="'Empresa número ' + r.origen + ' en el otro sistema'">De otra instalación</span></td><td>{{fechaHora(r.fecha)}}</td><td class="num">{{kb(r.bytes)}}</td><td style="text-align:right;white-space:nowrap"><button class="btn sm sec" @click="descargar(r)" :disabled="bajando===r.nombre">{{bajando===r.nombre ? 'Bajando…' : '⤓ Descargar'}}</button> <button class="btn sm sec" @click="eliminar(r)">Eliminar</button> <button class="btn sm" @click="abrirRestaurar(r)" title="Vuelve la empresa al estado de este respaldo">Restaurar</button></td></tr></tbody></table></div>
      <p class="small muted" style="margin:8px 0 0" v-else-if="lista">Aún no tiene respaldos. Conviene crear uno antes de cambios grandes (importaciones, cierres de año) y descargarlo.</p>
      <p class="small muted" style="margin:10px 0 0">«Restaurar» vuelve la empresa al estado de ese respaldo: antes se guarda una copia de seguridad del estado actual, así que siempre puede volver atrás. El certificado y las contraseñas guardadas van cifrados dentro del archivo y solo sirven en FISITAAP by Brillante Agencia. Un respaldo descargado antes se vuelve a subir con «Subir un respaldo».</p>
    </div>
    <Modal v-if="restaurar" title="Restaurar la empresa" @close="restaurar=null">
      <div class="alert warn"><b>La empresa volverá al estado de {{restaurar.r.nombre}}</b> ({{fechaHora(restaurar.r.fecha)}}). Todo lo registrado después de ese momento desaparece de la pantalla: ventas, cobros, inventario, reservas, todo. Antes se guarda una copia de seguridad del estado actual para poder volver.</div>
      <p class="small" style="margin:10px 0 6px">Avise a los demás usuarios: cuando termine, cada uno debe recargar la página.</p>
      <Field label="Escriba RESTAURAR para confirmar" req><input v-model="restaurar.texto" maxlength="12" placeholder="RESTAURAR"></Field>
      <template #foot><button class="btn ghost" @click="restaurar=null" :disabled="restaurar.trabajando">Cancelar</button><button class="btn danger" @click="confirmarRestaurar" :disabled="restaurar.trabajando">{{restaurar.trabajando ? 'Restaurando…' : 'Restaurar'}}</button></template>
    </Modal>
  </div>`,
};

// ------------------------------------------------------------------ Exportar datos (reglamento 44739-H art. 5.4)
const SecExportar = {
  components: { SecHead },
  data() { const h = hoy(); return { desde: h.slice(0, 4) + '-01-01', hasta: h, pdf: false, generando: false, avisoXml: '' }; },
  computed: { esPrograma() { return !!sesion.empresaInfo?.es_local; } },   // 4.25: en el programa los comprobantes viejos se traen de la web al exportar
  methods: {
    // 4.25 (X3): el aviso final con las cuentas de XML traídos y no traídos (cabeceras de /api/exportar)
    textoXml(traidos, faltan, motivo, kb) {
      const n = (k) => k === 1 ? '1 XML' : k + ' XML';
      if (faltan > 0) {
        const porque = { 'sin-internet': 'no se pudieron traer porque no hay internet', tiempo: 'no se pudieron traer porque se acabó el tiempo para traerlos', 'sin-acceso': 'no se pudieron traer porque la página web no atendió a esta computadora' }[motivo] || 'no están en la página web';
        const despues = { 'sin-internet': ' Vuelva a exportar cuando haya conexión.', tiempo: ' Vuelva a exportar o exporte un período más corto.', 'sin-acceso': ' Revise Configuración › Instalación local y vuelva a exportar.' }[motivo] || '';
        return 'Exportación descargada, pero ' + n(faltan) + ' ' + porque + '. Están anotados en FALTANTES.txt dentro del archivo.' + despues;
      }
      if (traidos > 0) return 'Exportación descargada. ' + (traidos === 1 ? '1 XML se trajo de la web.' : traidos + ' XML se trajeron de la web.');
      return 'Exportación descargada (' + kb + ' KB)';
    },
    async descargar() {
      this.generando = true; this.avisoXml = '';
      try {
        const r = await fetch('/api/exportar?desde=' + this.desde + '&hasta=' + this.hasta + '&pdf_incluir=' + (this.pdf ? 1 : 0), { headers: cabecerasAuth() });
        if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || 'No se pudo generar la exportación'); }
        const blob = await r.blob(); const nombre = (r.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/)?.[1] || 'exportacion.zip';
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nombre; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
        const traidos = parseInt(r.headers.get('X-Xml-Traidos') || '0', 10) || 0, faltan = parseInt(r.headers.get('X-Xml-Faltantes') || '0', 10) || 0;
        const texto = this.textoXml(traidos, faltan, r.headers.get('X-Xml-Motivo') || '', Math.round(blob.size / 1024));
        if (faltan > 0) this.avisoXml = texto;
        toast(texto, faltan > 0 ? 'err' : 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.generando = false;
    },
  },
  template: `
  <div class="page">
    <SecHead title="Exportar datos" sub="Descargue todo lo emitido y recibido en un periodo: XML firmados, respuestas de Hacienda, comprobantes de proveedores, mensajes de receptor, tablas en CSV y los registros de los demás módulos."></SecHead>
    <div class="card">
      <div class="grid cols-3">
        <Field label="Desde" req><input type="date" v-model="desde"></Field>
        <Field label="Hasta" req><input type="date" v-model="hasta"></Field>
        <Field label="Incluir PDF" help="Más lento si hay muchos comprobantes"><label class="row" style="cursor:pointer;margin-top:8px"><input type="checkbox" v-model="pdf"> Generar también el PDF de cada comprobante</label></Field>
      </div>
      <div class="row end" style="margin-top:12px"><button class="btn" @click="descargar" :disabled="generando">{{generando ? 'Generando…' : '⤓ Descargar ZIP'}}</button></div>
      <p class="small muted" style="margin:6px 0 0;text-align:right" v-if="esPrograma">Los comprobantes anteriores a la conexión de esta computadora se traen de la web al exportar: hace falta internet.</p>
      <div class="alert warn" style="margin:10px 0 0" v-if="avisoXml">{{avisoXml}}</div>
      <p class="small muted" style="margin:10px 0 0">Los comprobantes electrónicos deben conservarse al menos 5 años. Este ZIP sirve como respaldo propio, para entregar al contador o para llevarse los datos a otro sistema. Las contraseñas y la llave criptográfica no se exportan.</p>
    </div>
  </div>`,
};

// ------------------------------------------------------------------ Inventario › Método de costeo (3.75): promedio ponderado, PEPS o UEPS
const SecCosteo = {
  components: { SecHead },
  data() {
    return {
      c: { metodo: 'promedio', actualizar_costo_compras: true }, cargando: true, guardando: false,
      METODOS: [
        ['promedio', 'Costo promedio ponderado', 'Cada entrada recalcula el costo promedio y las salidas (ventas, ajustes, transferencias) salen a ese promedio. Es el método más sencillo y el que usaba el sistema hasta ahora.'],
        ['peps', 'PEPS · primero en entrar, primero en salir', 'Las salidas toman primero las unidades más antiguas, al costo con que entraron. El inventario queda valorado a los costos más recientes.'],
        ['ueps', 'UEPS · último en entrar, primero en salir', 'Las salidas toman primero las unidades más recientes, al costo con que entraron. El costo de ventas refleja los precios más nuevos y el inventario queda a los más antiguos.'],
      ],
    };
  },
  methods: {
    async cargar() { this.cargando = true; try { const r = await api('/api/inventario/config'); this.c = { metodo: r.metodo, actualizar_costo_compras: r.actualizar_costo_compras !== false }; } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    async guardar() {
      this.guardando = true;
      try {
        const r = await api('/api/inventario/config', { method: 'PUT', body: { metodo: this.c.metodo, actualizar_costo_compras: !!this.c.actualizar_costo_compras } });
        toast('Método de costeo guardado' + (r.recalculados ? ' · ' + r.recalculados + ' existencia(s) revaloradas con sus capas' : ''), 'ok');
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <SecHead title="Método de costeo del inventario" sub="Define con qué costo salen las unidades al vender, ajustar o transferir, y cómo se valora lo que queda en bodega."><button class="btn" @click="guardar" :disabled="guardando || cargando">{{guardando ? 'Guardando…' : 'Guardar'}}</button></SecHead>
    <div class="card">
      <label class="row" v-for="m in METODOS" :key="m[0]" style="gap:12px;align-items:flex-start;padding:12px 0;border-bottom:1px solid var(--line);cursor:pointer">
        <input type="radio" :value="m[0]" v-model="c.metodo" style="margin-top:4px">
        <div><b>{{m[1]}}</b><div class="small muted">{{m[2]}}</div></div>
      </label>
      <div class="row" style="justify-content:space-between;padding:12px 0"><div><b>Las compras actualizan el costo del ítem</b><div class="small muted">Al dar entrada a una compra (factura de compra, comprobante recibido o mercadería recibida en caja), el costo de referencia del ítem pasa a ser el de esa compra.</div></div><Toggle v-model="c.actualizar_costo_compras"></Toggle></div>
    </div>
    <div class="alert info">Cada entrada con costo abre una <b>capa</b> (cantidad y costo). Con PEPS o UEPS cada salida consume capas en ese orden y el movimiento guarda qué capas usó; la rentabilidad por ítem y las ventas por bodega usan ese costo. Las existencias que ya tenía antes de activar el método salen al costo promedio que llevaban. Puede cambiar de método cuando quiera: las capas se llevan siempre.</div>
  </div>`,
};

import SecInstalacionLocal from './instalacion-local.js';   // nube ↔ instalación local (3.12)
import SecIA from './ia.js';   // asistente con IA (3.56)
// 4.14: en el programa local estas secciones dependen de la nube
const SOLO_NUBE = { ia: 'El asistente con inteligencia artificial', suscripcion: 'El pago del plan', notificaciones: 'El envío de recordatorios de cobro', usuarios: 'La administración de usuarios y roles' };   // 4.25 (tanda 7): usuarios y roles se administran en la web
const SECCIONES = {
  'instalacion-local': SecInstalacionLocal, ia: SecIA, exportar: SecExportar, respaldos: SecRespaldos, sucursales: SecSucursales, empresa: SecEmpresa, hacienda: SecHacienda, usuarios: SecUsuarios, perfil: SecPerfil, 'centros-costos': SecCentrosCostos, monedas: SecMonedas,
  'terminos-pago': SecTerminosPago, numeraciones: SecNumeraciones, documentos: SecDocumentos, vendedores: SecVendedores, 'otros-cargos': SecOtrosCargos,
  plantillas: SecPlantillas, impuestos: SecImpuestos, retenciones: SecRetenciones,
  'contabilidad-registros': SecContabRegistros, 'contabilidad-parametrizacion': SecContabParam, 'contabilidad-periodos': SecContabPeriodos, 'contabilidad-tipos-asiento': SecContabTipos, 'contabilidad-numeraciones': SecContabNumeraciones,
  notificaciones: SecNotificaciones, 'plantillas-correo': SecPlantillasCorreo, preferencias: SecPreferencias,
  'campos-adicionales': SecCamposAdicionales, variantes: SecVariantes, integraciones: SecIntegraciones, 'inventario-costeo': SecCosteo,
  'historial-correos': SecHistorialCorreos, 'historial-operaciones': SecHistorialOperaciones, suscripcion: SecSuscripcion, marcas: SecMarcas,
};

export default {
  props: ['params'],
  computed: { comp() { return SECCIONES[this.params.seccion] || null; }, soloNube() { return sesion.empresaInfo?.es_local ? SOLO_NUBE[this.params.seccion] || '' : ''; } },
  template: `
  <div class="alert info" style="margin:12px 24px 0" v-if="soloNube"><b>Requiere internet.</b> {{soloNube}} corre solo en la nube: en este programa no se ejecuta. Configúrelo en la página web.</div>
  <component v-if="comp" :is="comp" :key="params.seccion"></component>
  <div v-else class="page">
    <PageHead title="Sección no encontrada" :crumbs="[{label:'Configuración',to:'/configuracion'},{label:params.seccion}]"></PageHead>
    <div class="card"><Empty icon="⚠" title="Sección no encontrada" text="La opción de configuración indicada no existe."><a class="btn" href="#/configuracion">Volver a Configuración</a></Empty></div>
  </div>`,
};
