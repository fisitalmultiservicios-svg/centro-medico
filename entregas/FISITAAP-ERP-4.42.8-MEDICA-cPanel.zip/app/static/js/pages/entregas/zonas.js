// Entregas › Zonas en el mapa (FISITAAP, 3.48): la ubicación del negocio y las zonas de entrega como círculos sobre el mapa
// (OpenStreetMap, sin clave). Cada zona tiene nombre, radio, precio para el cliente, pago al motorizado y tiempo estimado.
// El cliente marca su ubicación en el catálogo y la zona que lo contiene fija el costo de envío (si cae fuera, no se recibe a
// domicilio). Clic en el mapa para agregar una zona; arrastre el pin del negocio para moverlo.
import { api, toast, money } from '../../api.js';
import { sesion, store } from '../../app.js';
import { crearMapa, centroEmpresa, miPosicion } from '../../mapa.js';

const COLORES = ['#0f766e', '#1d4ed8', '#b45309', '#a3204f', '#5b21b6', '#15803d', '#0e7490', '#7c2d12'];

export default {
  props: ['params'],
  data() { return { ubic: { lat: null, lng: null }, zonas: [], sel: null, mapa: null, capas: {}, pin: null, guardando: false, cargado: false }; },
  computed: { ordenadas() { return this.zonas.slice().sort((a, b) => (+a.radio_km - +b.radio_km)); } },
  methods: {
    money,
    async cargar() {
      try { const r = await api('/api/entregas/zonas'); this.ubic = r.ubicacion || { lat: null, lng: null }; this.zonas = r.zonas; this.cargado = true; await this.$nextTick(); this.dibujar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async dibujar() {
      if (!this.$refs.mapa) return;
      // sin ubicación ni zonas, el mapa arranca en la provincia de la empresa (3.58), no en todo el país
      const prov = centroEmpresa(store.empresa);
      const centro = this.ubic.lat ? this.ubic : (this.zonas[0] ? { lat: +this.zonas[0].lat, lng: +this.zonas[0].lng } : prov);
      if (!this.mapa) {
        this.mapa = await crearMapa(this.$refs.mapa, centro, this.ubic.lat ? 14 : (this.zonas[0] ? 12 : prov.zoom));
        this.mapa.on('click', ev => this.clicMapa(ev.latlng));
      }
      const L = window.L;
      if (this.pin) this.pin.remove();
      if (this.ubic.lat) { this.pin = L.marker([this.ubic.lat, this.ubic.lng], { draggable: true, title: 'Negocio' }).addTo(this.mapa).bindPopup('Su negocio (arrástrelo para moverlo)'); this.pin.on('dragend', () => { const p = this.pin.getLatLng(); this.ubic = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6) }; this.guardarUbicacion(); }); }
      for (const k of Object.keys(this.capas)) { this.capas[k].remove(); delete this.capas[k]; }
      this.zonas.forEach((z, i) => {
        const c = L.circle([+z.lat, +z.lng], { radius: +z.radio_km * 1000, color: COLORES[i % COLORES.length], weight: this.sel && this.sel.id === z.id ? 4 : 2, fillOpacity: z.activa ? .12 : .03, dashArray: z.activa ? null : '6 6' }).addTo(this.mapa).bindTooltip(z.nombre + ' · ' + money(z.precio));
        c.on('click', ev => { L.DomEvent.stopPropagation(ev); this.editar(z); });
        this.capas[z.id || 'n' + i] = c;
      });
    },
    clicMapa(ll) {
      if (this.sel && !this.sel.id) { this.sel.lat = +ll.lat.toFixed(6); this.sel.lng = +ll.lng.toFixed(6); this.dibujar(); return; }
      if (!this.ubic.lat) { this.ubic = { lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6) }; this.guardarUbicacion(); return; }
      this.nueva({ lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6) });
    },
    async usarMiPosicion() { const p = await miPosicion(); if (!p) return toast('El navegador no dio la ubicación; haga clic en el mapa donde está el negocio', 'err'); this.ubic = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6) }; this.mapa.setView([p.lat, p.lng], 15); this.guardarUbicacion(); },
    async guardarUbicacion() { try { await api('/api/entregas/ubicacion', { method: 'PUT', body: this.ubic }); toast('Ubicación del negocio guardada', 'ok'); this.dibujar(); } catch (e) { toast(e.message, 'err'); } },
    nueva(p) { const n = this.zonas.length + 1; this.sel = { id: null, nombre: 'Zona ' + n, lat: p ? p.lat : this.ubic.lat, lng: p ? p.lng : this.ubic.lng, radio_km: n === 1 ? 2 : 2 + n, precio: 1500, pago_motorizado: null, tiempo: '', activa: true, orden: n }; if (p) this.zonas = this.zonas.filter(z => z.id); this.zonas.push(this.sel); this.dibujar(); },
    editar(z) { this.sel = z; this.dibujar(); },
    redibujar() { this.dibujar(); },
    async guardarZona() {
      const z = this.sel; if (!(z.nombre || '').trim()) return toast('Póngale nombre a la zona', 'err'); if (!(+z.radio_km > 0)) return toast('Indique el radio en kilómetros', 'err');
      this.guardando = true;
      try {
        const body = { nombre: z.nombre.trim(), lat: +z.lat, lng: +z.lng, radio_km: +z.radio_km, precio: +z.precio || 0, pago_motorizado: z.pago_motorizado === '' || z.pago_motorizado === null ? null : +z.pago_motorizado, tiempo: z.tiempo || '', activa: z.activa !== false, orden: +z.orden || 0 };
        const r = z.id ? await api('/api/entregas/zonas/' + z.id, { method: 'PUT', body }) : await api('/api/entregas/zonas', { method: 'POST', body });
        toast('Zona «' + r.nombre + '» guardada', 'ok'); this.sel = null; await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async borrarZona(z) { if (!z.id) { this.zonas = this.zonas.filter(x => x !== z); this.sel = null; return this.dibujar(); } if (!confirm('¿Borrar la zona «' + z.nombre + '»?')) return; try { await api('/api/entregas/zonas/' + z.id, { method: 'DELETE' }); this.sel = null; await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    centrar(z) { if (this.mapa) this.mapa.setView([+z.lat, +z.lng], 14); },
  },
  mounted() { this.cargar(); },
  beforeUnmount() { if (this.mapa) this.mapa.remove(); },
  template: `
  <div class="page">
    <PageHead title="Zonas de entrega" sub="Dibuje sobre el mapa hasta dónde entrega y cuánto cobra en cada zona. El cliente marca su ubicación al pedir y el sistema calcula el envío." :crumbs="[{label:'FISITAAP'},{label:'Entregas'},{label:'Zonas en el mapa'}]">
      <button class="btn ghost" @click="usarMiPosicion">📍 Mi posición</button><button class="btn" @click="nueva()" :disabled="!ubic.lat">+ Zona</button>
    </PageHead>
    <div class="alert warn" v-if="cargado && !ubic.lat" style="margin-bottom:12px">Primero marque dónde está el negocio: haga clic en el mapa sobre su local (o use «Mi posición» desde un celular en el negocio). Luego agregue las zonas.</div>
    <div class="grid" style="grid-template-columns:2fr 1fr;align-items:start;gap:12px">
      <div class="card" style="padding:8px"><div ref="mapa" style="height:520px;border-radius:10px"></div><p class="small muted" style="margin:6px 0 0">Clic en el mapa: {{!ubic.lat ? 'fija la ubicación del negocio' : (sel && !sel.id ? 'mueve el centro de la zona nueva' : 'agrega una zona')}}. Clic en un círculo: edita esa zona. Mapa de OpenStreetMap, sin costo.</p></div>
      <div>
        <div class="card" v-if="sel"><h2>{{sel.id ? 'Zona' : 'Zona nueva'}}</h2>
          <Field label="Nombre" req><input v-model="sel.nombre" maxlength="60" placeholder="Centro, Barrio Sur…"></Field>
          <Field label="Radio (km)" req><input type="number" min="0.2" max="200" step="0.1" v-model.number="sel.radio_km" @input="redibujar"></Field>
          <div class="grid cols-2"><Field label="Precio del envío (con IVA)"><input type="number" min="0" step="100" v-model.number="sel.precio"></Field><Field label="Pago al motorizado" help="Vacío = la tarifa de cada motorizado"><input type="number" min="0" step="100" v-model.number="sel.pago_motorizado"></Field></div>
          <Field label="Tiempo estimado"><input v-model="sel.tiempo" maxlength="40" placeholder="30 a 45 min"></Field>
          <Toggle v-model="sel.activa" label="Activa"></Toggle>
          <p class="small muted" style="margin:6px 0 0">Centro: {{(+sel.lat).toFixed(5)}}, {{(+sel.lng).toFixed(5)}}. Si dos zonas se traslapan, manda la de radio menor.</p>
          <div class="row" style="gap:6px;margin-top:10px;flex-wrap:wrap"><button class="btn" @click="guardarZona" :disabled="guardando">Guardar</button><button class="btn ghost" @click="sel=null; dibujar()">Cancelar</button><button class="btn ghost" style="margin-left:auto" @click="borrarZona(sel)">🗑 Borrar</button></div>
        </div>
        <div class="card"><h2>Zonas <small>{{zonas.length}}</small></h2>
          <Empty v-if="!zonas.length" icon="🗺" title="Sin zonas" text="Agregue la primera con «+ Zona» o haciendo clic en el mapa."></Empty>
          <div v-for="z in ordenadas" :key="z.id || z.nombre" class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);gap:8px;cursor:pointer" @click="editar(z); centrar(z)">
            <div><b>{{z.nombre}}</b> <span class="small muted">{{z.radio_km}} km{{z.tiempo ? ' · ' + z.tiempo : ''}}{{z.activa === false ? ' · inactiva' : ''}}</span></div><b>{{money(z.precio)}}</b>
          </div>
        </div>
      </div>
    </div>
  </div>`,
  setup() { return { sesion }; },
};
