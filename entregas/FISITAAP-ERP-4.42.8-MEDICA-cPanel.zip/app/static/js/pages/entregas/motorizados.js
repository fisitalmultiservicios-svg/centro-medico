// Entregas › Motorizados (FISITAAP, 3.48): quiénes entregan. No son usuarios del sistema: entran al panel /motorizado.html con
// el nombre público del negocio, su teléfono y una clave. Cada uno tiene su vehículo, placa y tarifa por entrega.
import { api, toast, money, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';

const VEHICULOS = [['moto', 'Motocicleta'], ['bici', 'Bicicleta'], ['carro', 'Carro'], ['pie', 'A pie']];

export default {
  props: ['params'],
  data() { return { lista: [], form: null, negocio: null, VEHICULOS, copiado: false }; },
  computed: { enlace() { return this.negocio && this.negocio.slug ? location.origin + '/motorizado.html#n=' + this.negocio.slug : location.origin + '/motorizado.html'; } },
  methods: {
    money, fechaHora,
    async cargar() { try { this.lista = await api('/api/entregas/motorizados'); } catch (e) { toast(e.message, 'err'); } try { this.negocio = await api('/api/pedidos/negocio'); } catch {} },
    nuevo() { this.form = { id: null, nombre: '', telefono: '', vehiculo: 'moto', placa: '', activo: true, pago_entrega: 1000, notas: '', clave: '' }; },
    editar(m) { this.form = { ...m, clave: '' }; },
    async guardar() {
      const f = this.form; if (!f.nombre.trim() || !f.telefono.trim()) return toast('Nombre y teléfono son obligatorios', 'err');
      if (!f.id && !f.clave) return toast('Asigne la clave con la que entrará al panel', 'err');
      try {
        const body = { nombre: f.nombre, telefono: f.telefono, vehiculo: f.vehiculo, placa: f.placa || '', activo: f.activo !== false, pago_entrega: +f.pago_entrega || 0, notas: f.notas || '', clave: f.clave || null };
        await api(f.id ? '/api/entregas/motorizados/' + f.id : '/api/entregas/motorizados', { method: f.id ? 'PUT' : 'POST', body });
        toast('Motorizado guardado', 'ok'); this.form = null; this.cargar();
      } catch (e) { toast(e.message, 'err'); }
    },
    async borrar(m) { if (!confirm('¿Quitar a ' + m.nombre + '?')) return; try { const r = await api('/api/entregas/motorizados/' + m.id, { method: 'DELETE' }); toast(r.mensaje || 'Motorizado eliminado', 'ok'); this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    copiar() { try { navigator.clipboard.writeText(this.enlace); this.copiado = true; setTimeout(() => { this.copiado = false; }, 2000); } catch { toast('Copie el enlace a mano', 'err'); } },
    wa(m) { return 'https://wa.me/506' + m.telefono + '?text=' + encodeURIComponent('Hola ' + m.nombre + ', este es su panel de entregas: ' + this.enlace + ' . Entre con su teléfono y la clave que le dimos. En el celular use «Agregar a pantalla de inicio» para tenerlo como aplicación.'); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Motorizados" sub="Quienes hacen las entregas. Entran a su panel desde el celular con su teléfono y una clave; no necesitan usuario del sistema." :crumbs="[{label:'FISITAAP'},{label:'Entregas'},{label:'Motorizados'}]">
      <button class="btn" @click="nuevo">+ Motorizado</button>
    </PageHead>
    <div class="card" style="margin-bottom:12px"><div class="row" style="gap:8px;align-items:center;flex-wrap:wrap"><b>Enlace del panel:</b><input class="inp mono small" :value="enlace" readonly style="flex:1;min-width:260px"><button class="btn sm sec" @click="copiar">{{copiado ? 'Copiado' : 'Copiar'}}</button><span class="small muted">Mándeselo a cada motorizado; en Android se instala como aplicación con «Agregar a pantalla de inicio».</span></div></div>
    <Empty v-if="!lista.length" icon="🛵" title="Sin motorizados" text="Agregue el primero con «+ Motorizado». Podrá tomar las entregas liberadas o las que usted le asigne."></Empty>
    <div class="table-wrap" v-else><table class="tbl"><thead><tr><th>Nombre</th><th>Teléfono</th><th>Vehículo</th><th class="num">Pago por entrega</th><th>Estado</th><th>Último acceso</th><th></th></tr></thead><tbody>
      <tr v-for="m in lista" :key="m.id" :style="m.activo ? '' : 'opacity:.55'"><td><b>{{m.nombre}}</b><div class="small muted" v-if="m.notas">{{m.notas}}</div></td><td class="mono">{{m.telefono}}</td><td>{{m.vehiculo_nombre}}<span class="small muted" v-if="m.placa"> · {{m.placa}}</span></td><td class="num">{{money(m.pago_entrega)}}</td><td><span class="badge" :class="m.activo ? 'ok' : ''">{{m.activo ? 'Activo' : 'Inactivo'}}</span><span class="badge warn" v-if="!m.con_clave" style="margin-left:4px">Sin clave</span></td><td class="small">{{m.ultimo_acceso ? fechaHora(m.ultimo_acceso) : '—'}}</td>
        <td class="num"><div class="acts"><a class="btn sm ghost" :href="wa(m)" target="_blank" rel="noopener">WhatsApp</a><button class="btn sm sec" @click="editar(m)">Editar</button><button class="btn icon" @click="borrar(m)">🗑</button></div></td></tr>
    </tbody></table></div>
    <Modal v-if="form" :title="form.id ? 'Motorizado' : 'Nuevo motorizado'" @close="form=null">
      <div class="grid cols-2">
        <Field label="Nombre" req><input v-model="form.nombre" maxlength="60"></Field>
        <Field label="Teléfono (8 dígitos)" req help="Con él entra al panel"><input v-model="form.telefono" maxlength="12" inputmode="numeric"></Field>
        <Field label="Vehículo"><select v-model="form.vehiculo"><option v-for="v in VEHICULOS" :key="v[0]" :value="v[0]">{{v[1]}}</option></select></Field>
        <Field label="Placa"><input v-model="form.placa" maxlength="12"></Field>
        <Field label="Pago por entrega" help="Lo que se le liquida por cada entrega (una zona puede fijar otro monto)"><input type="number" min="0" step="100" v-model.number="form.pago_entrega"></Field>
        <Field :label="form.id ? 'Nueva clave (vacío = no cambia)' : 'Clave (4 a 8 dígitos)'" :req="!form.id"><input type="password" inputmode="numeric" maxlength="8" v-model="form.clave" autocomplete="new-password"></Field>
        <Field label="Notas" style="grid-column:1/-1"><input v-model="form.notas" maxlength="200"></Field>
      </div>
      <Toggle v-model="form.activo" label="Activo (puede entrar y tomar entregas)" style="margin-top:8px"></Toggle>
      <template #foot><button class="btn ghost" @click="form=null">Cancelar</button><button class="btn" @click="guardar">Guardar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
