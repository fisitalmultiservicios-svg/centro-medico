// Entregas › Seguimiento (FISITAAP, 3.48): las entregas abiertas del día en una lista y en el mapa, con asignación directa a
// un motorizado o liberada para que uno afiliado la tome, cancelar con motivo y cerrar a mano. Se refresca sola cada 20 s.
import { api, toast, money, fechaHora } from '../../api.js';
import { sesion } from '../../app.js';
import { crearMapa, CR } from '../../mapa.js';

export default {
  props: ['params'],
  data() { return { lista: [], motos: [], vista: 'abiertas', desde: '', hasta: '', cancelar: null, mapa: null, capas: [], ubic: null, cargando: false }; },
  computed: {
    abiertas() { return this.lista.filter(x => x.abierta); },
    activos() { return this.motos.filter(m => m.activo); },
  },
  methods: {
    money, fechaHora,
    async cargar(silencioso) {
      if (!silencioso) this.cargando = true;
      try {
        const q = this.vista === 'abiertas' ? '?abiertas=1' : (this.desde || this.hasta ? '?desde=' + (this.desde || '2000-01-01') + '&hasta=' + (this.hasta || '2099-12-31') : '');
        this.lista = await api('/api/entregas' + q); await this.$nextTick(); this.dibujar();
      } catch (e) { if (!silencioso) toast(e.message, 'err'); }
      this.cargando = false;
    },
    async dibujar() {
      if (!this.$refs.mapa) return;
      try {
        if (!this.mapa) { const z = await api('/api/entregas/zonas').catch(() => null); this.ubic = z && z.ubicacion && z.ubicacion.lat ? z.ubicacion : null; this.mapa = await crearMapa(this.$refs.mapa, this.ubic || CR, this.ubic ? 13 : 8); }
        const L = window.L; for (const c of this.capas) c.remove(); this.capas = [];
        if (this.ubic) this.capas.push(L.circleMarker([this.ubic.lat, this.ubic.lng], { radius: 8, color: '#0f766e', fillOpacity: .9 }).addTo(this.mapa).bindTooltip('Negocio'));
        for (const x of this.abiertas) if (x.lat) this.capas.push(L.marker([x.lat, x.lng]).addTo(this.mapa).bindTooltip('#' + x.pedido_numero + ' · ' + x.nombre_cliente + ' · ' + x.estado_nombre));
        for (const m of this.motos) if (m.lat && this.abiertas.some(x => x.motorizado_id === m.id && x.estado === 'en_camino')) this.capas.push(L.circleMarker([m.lat, m.lng], { radius: 7, color: '#1d4ed8', fillOpacity: .9 }).addTo(this.mapa).bindTooltip('🛵 ' + m.nombre));
      } catch {}
    },
    async asignar(x, mid) { try { const r = await api('/api/entregas/' + x.id + '/asignar', { method: 'PUT', body: { motorizado_id: mid ? +mid : null } }); Object.assign(x, r); toast(mid ? 'Asignada a ' + r.motorizado : 'Entrega liberada: cualquier motorizado puede tomarla', 'ok'); this.dibujar(); } catch (e) { toast(e.message, 'err'); } },
    async cerrar(x) { if (!confirm('¿Marcar la entrega #' + x.pedido_numero + ' como entregada?')) return; try { const r = await api('/api/entregas/' + x.id + '/entregada', { method: 'PUT' }); Object.assign(x, r); this.cargar(true); } catch (e) { toast(e.message, 'err'); } },
    async confirmarCancelar() { const c = this.cancelar; if (!(c.motivo || '').trim()) return toast('Escriba el motivo', 'err'); try { const r = await api('/api/entregas/' + c.x.id + '/cancelar', { method: 'PUT', body: { motivo: c.motivo.trim() } }); Object.assign(c.x, r); this.cancelar = null; this.cargar(true); } catch (e) { toast(e.message, 'err'); } },
    badge(e) { return e === 'entregada' ? 'ok' : e === 'cancelada' || e === 'incidencia' ? 'danger' : e === 'liberada' || e === 'pendiente' ? 'warn' : 'info'; },
    wa(x) { return 'https://wa.me/506' + x.telefono_cliente; },
  },
  async created() { try { this.motos = await api('/api/entregas/motorizados'); } catch {} await this.cargar(); this._t = setInterval(async () => { try { this.motos = await api('/api/entregas/motorizados'); } catch {} this.cargar(true); }, 20000); },
  beforeUnmount() { clearInterval(this._t); if (this.mapa) this.mapa.remove(); },
  template: `
  <div class="page">
    <PageHead title="Entregas" sub="Las entregas a domicilio de los pedidos en línea: asígnelas a un motorizado o libérelas para que uno las tome. El cliente da su código de 4 dígitos al recibir." :crumbs="[{label:'FISITAAP'},{label:'Entregas'},{label:'Seguimiento'}]">
      <span class="seg"><button :class="{on: vista==='abiertas'}" @click="vista='abiertas'; cargar()">Abiertas</button><button :class="{on: vista==='historial'}" @click="vista='historial'; cargar()">Historial</button></span>
      <button class="btn sec" @click="cargar()" :disabled="cargando">Actualizar</button>
    </PageHead>
    <div class="alert warn" v-if="!activos.length" style="margin-bottom:12px">No hay motorizados activos: <a href="#/entregas/motorizados">agregue uno</a> para poder asignar o liberar entregas.</div>
    <div class="card" v-if="vista==='historial'" style="margin-bottom:12px"><div class="row" style="gap:8px;align-items:flex-end;flex-wrap:wrap"><Field label="Desde"><input type="date" v-model="desde"></Field><Field label="Hasta"><input type="date" v-model="hasta"></Field><button class="btn sm ghost" @click="cargar()">Buscar</button><span class="small muted">Sin fechas: los últimos 3 días.</span></div></div>
    <div class="grid" style="grid-template-columns:3fr 2fr;align-items:start;gap:12px">
      <div>
        <Empty v-if="!lista.length" icon="🛵" title="Sin entregas" text="Cuando confirme un pedido a domicilio en Ventas en línea › Pedidos, aparece aquí para despacharlo."></Empty>
        <div v-for="x in lista" :key="x.id" class="card" style="margin-bottom:8px" :style="x.estado==='incidencia' ? 'border-color:var(--danger)' : x.estado==='pendiente' ? 'border-color:var(--warn)' : ''">
          <div class="row" style="justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:flex-start">
            <div><b>#{{x.pedido_numero}} · {{x.nombre_cliente}}</b> <span class="badge" :class="badge(x.estado)">{{x.estado_nombre}}</span>
              <div class="small muted">📍 {{x.direccion}}{{x.zona_nombre ? ' · ' + x.zona_nombre : ''}} · envío {{money(x.monto_envio)}} · {{fechaHora(x.creada)}}</div>
              <div class="small" v-if="x.motorizado">🛵 {{x.motorizado}}{{x.vehiculo ? ' (' + x.vehiculo + ')' : ''}} · le pagan {{money(x.pago_motorizado)}}{{x.en_camino_en ? ' · en camino desde ' + fechaHora(x.en_camino_en).slice(-5) : ''}}</div>
              <div class="small" v-if="x.incidencia" style="color:var(--danger)">⚠ {{x.incidencia}}</div>
            </div>
            <div class="acts" style="flex-wrap:wrap;justify-content:flex-end" v-if="x.abierta">
              <select class="inp" :value="x.motorizado_id || ''" @change="asignar(x, $event.target.value)" style="max-width:170px"><option value="">— Liberar (cualquiera) —</option><option v-for="m in activos" :key="m.id" :value="m.id">{{m.nombre}}</option></select>
              <a class="btn sm ghost" :href="wa(x)" target="_blank" rel="noopener">WhatsApp</a>
              <button class="btn sm sec" @click="cerrar(x)" v-if="x.estado!=='pendiente'">Entregada</button>
              <button class="btn sm ghost" @click="cancelar={x, motivo: ''}">Cancelar</button>
            </div>
          </div>
        </div>
      </div>
      <div class="card" style="padding:8px"><div ref="mapa" style="height:460px;border-radius:10px"></div><p class="small muted" style="margin:6px 0 0">Pines: clientes de las entregas abiertas. Punto azul: motorizado en camino (su última posición). Punto verde: el negocio.</p></div>
    </div>
    <Modal v-if="cancelar" :title="'Cancelar la entrega #' + cancelar.x.pedido_numero" @close="cancelar=null">
      <Field label="Motivo" req><input v-model="cancelar.motivo" maxlength="200" autofocus @keyup.enter="confirmarCancelar"></Field>
      <p class="small muted" style="margin:8px 0 0">El pedido sigue en la caja; si también se cancela el pedido, hágalo desde Ventas en línea › Pedidos › Pedidos.</p>
      <template #foot><button class="btn ghost" @click="cancelar=null">Volver</button><button class="btn danger" @click="confirmarCancelar">Cancelar la entrega</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
