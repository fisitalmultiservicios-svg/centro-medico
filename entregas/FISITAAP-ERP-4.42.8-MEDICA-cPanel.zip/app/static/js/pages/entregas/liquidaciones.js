// Entregas › Liquidaciones (FISITAAP, 3.48): lo que se le paga a cada motorizado por las entregas hechas y no liquidadas. Al
// liquidar quedan marcadas y nace el registro con fecha, cantidad y total; se exporta a CSV.
import { api, toast, money, fecha, fechaHora, hoy } from '../../api.js';
import { sesion } from '../../app.js';
import { exportarTabla } from '../reportes/_montos.js';

export default {
  props: ['params'],
  data() { return { pendientes: [], historial: [], liq: null, detalle: null }; },
  methods: {
    money, fecha, fechaHora,
    async cargar() { try { this.pendientes = await api('/api/entregas/liquidaciones/pendientes'); this.historial = await api('/api/entregas/liquidaciones'); } catch (e) { toast(e.message, 'err'); } },
    abrir(p) { this.liq = { p, hasta: hoy(), nota: '' }; },
    async liquidar() {
      const l = this.liq;
      try { const r = await api('/api/entregas/liquidaciones', { method: 'POST', body: { motorizado_id: l.p.motorizado_id, hasta: l.hasta, nota: l.nota } }); toast('Liquidado a ' + r.motorizado + ': ' + r.entregas + ' entrega(s), ' + money(r.total), 'ok'); this.liq = null; this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    exportar(p) { exportarTabla('liquidacion_' + p.motorizado.replace(/\s+/g, '_'), [{ key: 'pedido_numero', label: 'Pedido' }, { key: 'nombre_cliente', label: 'Cliente' }, { key: 'direccion', label: 'Dirección' }, { key: 'zona_nombre', label: 'Zona' }, { key: 'entregada_en', label: 'Entregada' }, { key: 'monto_envio', label: 'Envío cobrado' }, { key: 'pago_motorizado', label: 'Pago' }], p.detalle); },
    exportarHistorial() { exportarTabla('liquidaciones', [{ key: 'fecha', label: 'Fecha' }, { key: 'motorizado', label: 'Motorizado' }, { key: 'desde', label: 'Desde' }, { key: 'hasta', label: 'Hasta' }, { key: 'entregas', label: 'Entregas' }, { key: 'total', label: 'Total' }, { key: 'nota', label: 'Nota' }, { key: 'usuario', label: 'Usuario' }], this.historial); },
  },
  created() { this.cargar(); },
  template: `
  <div class="page">
    <PageHead title="Liquidaciones a motorizados" sub="Entregas hechas que todavía no se han pagado, por motorizado. Liquide cuando les pague." :crumbs="[{label:'FISITAAP'},{label:'Entregas'},{label:'Liquidaciones'}]">
      <button class="btn ghost" @click="exportarHistorial" v-if="historial.length">Exportar historial</button>
    </PageHead>
    <Empty v-if="!pendientes.length" icon="💸" title="Nada pendiente de liquidar" text="Cuando los motorizados cierren entregas, aquí aparece lo que se les debe."></Empty>
    <div v-for="p in pendientes" :key="p.motorizado_id" class="card" style="margin-bottom:10px">
      <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;align-items:center"><div><b style="font-size:16px">🛵 {{p.motorizado}}</b><div class="small muted">{{p.entregas}} entrega(s) · del {{fechaHora(p.desde)}} al {{fechaHora(p.hasta)}}</div></div>
        <div class="row" style="gap:6px;align-items:center"><b style="font-size:20px">{{money(p.total)}}</b><button class="btn sm ghost" @click="detalle = detalle===p.motorizado_id ? null : p.motorizado_id">{{detalle===p.motorizado_id ? 'Ocultar' : 'Detalle'}}</button><button class="btn sm ghost" @click="exportar(p)">Exportar</button><button class="btn sm" @click="abrir(p)">Liquidar</button></div></div>
      <div class="table-wrap" v-if="detalle===p.motorizado_id" style="margin-top:8px"><table class="tbl"><thead><tr><th>Pedido</th><th>Cliente</th><th>Zona</th><th>Entregada</th><th class="num">Envío cobrado</th><th class="num">Pago</th></tr></thead><tbody>
        <tr v-for="x in p.detalle" :key="x.id"><td>#{{x.pedido_numero}}</td><td>{{x.nombre_cliente}}<div class="small muted">{{x.direccion}}</div></td><td>{{x.zona_nombre || '—'}}</td><td class="small">{{fechaHora(x.entregada_en)}}</td><td class="num">{{money(x.monto_envio)}}</td><td class="num">{{money(x.pago_motorizado)}}</td></tr>
      </tbody></table></div>
    </div>
    <div class="card" v-if="historial.length"><h2>Liquidaciones hechas</h2>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Motorizado</th><th>Período</th><th class="num">Entregas</th><th class="num">Total</th><th>Nota</th></tr></thead><tbody>
        <tr v-for="l in historial" :key="l.id"><td>{{fechaHora(l.fecha)}}</td><td>{{l.motorizado}}</td><td>{{fecha(l.desde)}} – {{fecha(l.hasta)}}</td><td class="num">{{l.entregas}}</td><td class="num"><b>{{money(l.total)}}</b></td><td class="small">{{l.nota}}<span class="muted" v-if="l.usuario"> · {{l.usuario}}</span></td></tr>
      </tbody></table></div>
    </div>
    <Modal v-if="liq" :title="'Liquidar a ' + liq.p.motorizado" @close="liq=null">
      <p style="margin:0 0 8px">{{liq.p.entregas}} entrega(s) por <b>{{money(liq.p.total)}}</b>.</p>
      <div class="grid cols-2"><Field label="Entregas hasta el" req><input type="date" v-model="liq.hasta"></Field><Field label="Nota"><input v-model="liq.nota" maxlength="200" placeholder="Pagado en efectivo, SINPE…"></Field></div>
      <p class="small muted" style="margin:8px 0 0">Las entregas quedan marcadas como liquidadas y no vuelven a aparecer. El pago en sí lo registra usted en Bancos o Gastos como siempre.</p>
      <template #foot><button class="btn ghost" @click="liq=null">Cancelar</button><button class="btn" @click="liquidar">Liquidar</button></template>
    </Modal>
  </div>`,
  setup() { return { sesion }; },
};
