// Consola › Publicidad (3.39): lista propia de contactos, campañas por correo con vista previa y prueba, envío por lotes con tope por
// hora y baja con un clic. Solo el administrador del sistema.
import { api, toast, fecha, fechaHora } from '../api.js';
import { sesion } from '../app.js';

const VACIA = () => ({ id: null, nombre: '', asunto: '', titulo: '', antetitulo: '', preencabezado: '', tema: 'fisitaap', cuerpo: '', imagen_url: '', boton_texto: '', boton_url: '', etiquetas: '' });
const ESTADOS = { borrador: 'Borrador', enviando: 'Enviando', pausada: 'Pausada', enviada: 'Completada', cancelada: 'Cancelada' };
const PERMISOS = { expreso: 'Pidió recibir novedades', relacion: 'Cliente o prospecto' };
const ORIGENES = { manual: 'A mano', importado: 'Importado', sitio: 'Página web', plataforma: 'Cliente del sistema' };
const ESTADOS_C = { activo: 'Activo', baja: 'De baja', rebotado: 'Rebote' };

export default {
  data() {
    return {
      sub: 'campanas', resumen: null, campanas: [], contactos: [], q: '', filtroEstado: 'activo', filtroEtiqueta: '',
      editor: null, previa: null, publico: null, para: (sesion.usuario && sesion.usuario.correo) || '', probando: false, guardando: false,
      plantillas: null, temas: [], eligiendo: false,
      contacto: null, importar: null, resultadoImport: null, cfg: null, cfgForm: null, guardandoCfg: false, envios: null, verEnvios: null,
      PERMISOS, ORIGENES, ESTADOS_C, timer: null, bloqueado: '',   // 3.87: el administrador con empresas ocultas no usa Publicidad (403)
      colContactos: [
        { key: 'correo', label: 'Correo' }, { key: 'nombre', label: 'Nombre' }, { key: 'empresa', label: 'Empresa' },
        { key: 'etiquetas', label: 'Etiquetas' }, { key: 'permiso', label: 'Permiso', fmt: v => PERMISOS[v] || v },
        { key: 'origen', label: 'Origen', fmt: v => ORIGENES[v] || v }, { key: 'estado', label: 'Estado', fmt: v => ESTADOS_C[v] || v },
      ],
    };
  },
  computed: {
    etiquetas() { return (this.resumen && this.resumen.etiquetas) || []; },
    contactosFiltrados() {
      return this.contactos.filter(c => (!this.filtroEstado || c.estado === this.filtroEstado)
        && (!this.filtroEtiqueta || (c.etiquetas || '').split(',').map(x => x.trim()).includes(this.filtroEtiqueta)));
    },
    enCurso() { return this.campanas.some(c => c.estado === 'enviando'); },
  },
  async created() { await this.cargar(); },
  unmounted() { clearInterval(this.timer); },
  methods: {
    fecha, fechaHora,
    estado(v) { return ESTADOS[v] || v; },
    async cargar() {
      try {
        [this.resumen, this.campanas] = await Promise.all([api('/api/admin/publicidad/resumen'), api('/api/admin/publicidad/campanas')]);
        if (this.sub === 'contactos') this.contactos = await api('/api/admin/publicidad/contactos');
      } catch (e) { if (e.status === 403) { this.bloqueado = e.message; return; } toast(e.message, 'err'); }
      clearInterval(this.timer);
      if (this.enCurso) this.timer = setInterval(() => this.refrescar(), 30000);   /* el avance se ve solo mientras envía */
    },
    async refrescar() { try { this.campanas = await api('/api/admin/publicidad/campanas'); this.resumen = await api('/api/admin/publicidad/resumen'); if (!this.enCurso) clearInterval(this.timer); } catch {} },
    async ir(sub) {
      this.sub = sub;
      if (sub === 'contactos') { try { this.contactos = await api('/api/admin/publicidad/contactos'); } catch (e) { toast(e.message, 'err'); } }
      if (sub === 'config') { try { this.cfg = await api('/api/admin/publicidad/config'); this.cfgForm = { usar_sistema: this.cfg.usar_sistema, por_hora: this.cfg.por_hora, pie: this.cfg.pie, smtp: { ...this.cfg.smtp, password: '' } }; } catch (e) { toast(e.message, 'err'); } }
    },
    // ---- campañas
    async nueva() {
      this.eligiendo = true;
      if (!this.plantillas) { try { const r = await api('/api/admin/publicidad/plantillas'); this.plantillas = r.plantillas; this.temas = r.temas; } catch (e) { toast(e.message, 'err'); this.plantillas = []; } }
    },
    async cargarTemas() { if (this.temas.length) return; try { const r = await api('/api/admin/publicidad/plantillas'); this.plantillas = r.plantillas; this.temas = r.temas; } catch {} },
    colorTema(id) { const t = this.temas.find(x => x.id === id); return t ? t.oscuro : '#0f3d36'; },
    usar(p) {
      this.eligiendo = false; this.previa = null; this.publico = null;
      this.editor = p ? { ...VACIA(), nombre: p.nombre, asunto: p.asunto, titulo: p.titulo, antetitulo: p.antetitulo || '', preencabezado: p.preencabezado || '', tema: p.tema || 'verde',
                          cuerpo: p.cuerpo, boton_texto: p.boton_texto || '', boton_url: p.boton_url || '' } : VACIA();
      this.vistaPrevia();
    },
    editar(c) { this.cargarTemas(); this.editor = { ...VACIA(), ...c, antetitulo: c.antetitulo || '', preencabezado: c.preencabezado || '', tema: c.tema || 'verde', titulo: c.titulo || '', imagen_url: c.imagen_url || '', boton_texto: c.boton_texto || '', boton_url: c.boton_url || '', etiquetas: c.etiquetas || '' }; this.vistaPrevia(); },
    cuerpoEditor() { const e = this.editor; return { nombre: e.nombre || 'Sin nombre', asunto: e.asunto || '(sin asunto)', titulo: e.titulo || null, antetitulo: e.antetitulo || null, preencabezado: e.preencabezado || null, tema: e.tema || 'verde', cuerpo: e.cuerpo || '', imagen_url: e.imagen_url || null, boton_texto: e.boton_texto || null, boton_url: e.boton_url || null, etiquetas: e.etiquetas || null }; },
    alternarEtiqueta(t) {
      const l = (this.editor.etiquetas || '').split(',').map(x => x.trim()).filter(Boolean);
      const i = l.indexOf(t); i >= 0 ? l.splice(i, 1) : l.push(t);
      this.editor.etiquetas = l.join(', '); this.vistaPrevia();
    },
    tieneEtiqueta(t) { return (this.editor.etiquetas || '').split(',').map(x => x.trim()).includes(t); },
    vistaPrevia() {
      clearTimeout(this._pv);
      this._pv = setTimeout(async () => {
        if (!this.editor) return;
        try { const r = await api('/api/admin/publicidad/vista-previa', { method: 'POST', body: this.cuerpoEditor() }); this.previa = r.html; this.publico = r.publico; } catch (e) { this.previa = null; }
      }, 400);
    },
    async guardar(cerrar = true) {
      if (!this.editor.nombre.trim() || !this.editor.asunto.trim()) { toast('Escriba el nombre de la campaña y el asunto del correo', 'err'); return null; }
      this.guardando = true;
      try {
        const r = this.editor.id ? await api('/api/admin/publicidad/campanas/' + this.editor.id, { method: 'PUT', body: this.cuerpoEditor() })
                                 : await api('/api/admin/publicidad/campanas', { method: 'POST', body: this.cuerpoEditor() });
        this.editor.id = r.id; toast('Campaña guardada', 'ok');
        if (cerrar) this.editor = null;
        await this.cargar(); return r;
      } catch (e) { toast(e.message, 'err'); return null; } finally { this.guardando = false; }
    },
    async probar() {
      this.probando = true;
      try { await api('/api/admin/publicidad/prueba', { method: 'POST', body: { ...this.cuerpoEditor(), para: this.para } }); toast('Prueba enviada a ' + this.para, 'ok'); }
      catch (e) { toast(e.message, 'err'); } finally { this.probando = false; }
    },
    horas(n) { const ph = (this.resumen && this.resumen.config.por_hora) || 100; const h = Math.ceil(n / ph); return h <= 1 ? 'menos de una hora' : 'unas ' + h + ' horas'; },
    async enviar(c) {
      if (this.editor) { const r = await this.guardar(false); if (!r) return; c = r; }
      const n = this.editor ? this.publico : null;
      if (!confirm('¿Enviar «' + c.nombre + '»' + (n !== null ? ' a ' + n + ' contacto(s)' : '') + '? Salen hasta ' + ((this.resumen && this.resumen.config.por_hora) || 100) + ' por hora' + (n ? ' (tarda ' + this.horas(n) + ')' : '') + '. Ya no se podrá editar.')) return;
      try { const r = await api('/api/admin/publicidad/campanas/' + c.id + '/enviar', { method: 'POST' }); toast('Enviando a ' + r.total + ' contacto(s)', 'ok'); this.editor = null; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async accion(c, a) {
      if (a === 'cancelar' && !confirm('¿Cancelar el envío de «' + c.nombre + '»? Los que ya salieron no se pueden recuperar; los pendientes no se mandan.')) return;
      try { await api('/api/admin/publicidad/campanas/' + c.id + '/' + a, { method: 'POST' }); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async duplicar(c) { try { const n = await api('/api/admin/publicidad/campanas/' + c.id + '/duplicar', { method: 'POST' }); await this.cargar(); this.editar(n); } catch (e) { toast(e.message, 'err'); } },
    async borrar(c) {
      if (!confirm('¿Borrar la campaña «' + c.nombre + '»?')) return;
      try { await api('/api/admin/publicidad/campanas/' + c.id, { method: 'DELETE' }); await this.cargar(); } catch (e) { toast(e.message, 'err'); }
    },
    async abrirEnvios(c) { this.verEnvios = c; this.envios = null; try { this.envios = await api('/api/admin/publicidad/campanas/' + c.id + '/envios'); } catch (e) { toast(e.message, 'err'); } },
    async procesarAhora() { try { const r = await api('/api/admin/publicidad/procesar', { method: 'POST' }); toast(r.espera ? 'Se llegó al tope por hora: el resto sale solo en la próxima hora' : r.error ? r.error : 'Enviados ' + (r.enviados || 0) + ' más', r.error ? 'err' : 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    // ---- contactos
    nuevoContacto() { this.contacto = { id: null, correo: '', nombre: '', empresa: '', etiquetas: '', permiso: 'relacion', estado: 'activo', nota: '' }; },
    abrirContacto(c) { this.contacto = { ...c, nombre: c.nombre || '', empresa: c.empresa || '', etiquetas: c.etiquetas || '', nota: c.nota || '' }; },
    async guardarContacto() {
      const c = this.contacto;
      try {
        if (c.id) await api('/api/admin/publicidad/contactos/' + c.id, { method: 'PUT', body: c });
        else await api('/api/admin/publicidad/contactos', { method: 'POST', body: c });
        toast('Contacto guardado', 'ok'); this.contacto = null; await this.ir('contactos'); this.resumen = await api('/api/admin/publicidad/resumen');
      } catch (e) { toast(e.message, 'err'); }
    },
    async borrarContacto() {
      if (!confirm('¿Borrar ' + this.contacto.correo + '? Si lo que quiere es no volver a escribirle, márquelo «De baja» en vez de borrarlo: así una importación futura no lo vuelve a agregar.')) return;
      try { await api('/api/admin/publicidad/contactos/' + this.contacto.id, { method: 'DELETE' }); this.contacto = null; await this.ir('contactos'); } catch (e) { toast(e.message, 'err'); }
    },
    textoResultado(r) {
      const t = { nuevo: 'nuevos', actualizado: 'actualizados', existe: 'ya estaban', baja: 'de baja (no se reactivan)', invalido: 'con formato inválido' };
      return Object.entries(r).map(([k, v]) => v + ' ' + (t[k] || k)).join(' · ') || 'Nada que agregar';
    },
    async hacerImportar() {
      if (!this.importar.permiso) { toast('Indique cómo obtuvo estos correos', 'err'); return; }
      try { const r = await api('/api/admin/publicidad/contactos/importar', { method: 'POST', body: this.importar }); toast(this.textoResultado(r), 'ok'); this.importar = null; await this.ir('contactos'); this.resumen = await api('/api/admin/publicidad/resumen'); }
      catch (e) { toast(e.message, 'err'); }
    },
    async traer(que) {
      const msj = que === 'sitio' ? '¿Agregar a la lista a las personas que escribieron por el formulario de la página? Entran con la etiqueta «prospectos».' : '¿Agregar a la lista a los administradores de las empresas que usan el sistema? Entran con la etiqueta «clientes» (o «pruebas» si están en prueba gratis).';
      if (!confirm(msj)) return;
      try { const r = await api('/api/admin/publicidad/contactos/importar-' + que, { method: 'POST' }); toast(this.textoResultado(r), 'ok'); await this.ir('contactos'); this.resumen = await api('/api/admin/publicidad/resumen'); }
      catch (e) { toast(e.message, 'err'); }
    },
    // ---- configuración
    async guardarCfg() {
      this.guardandoCfg = true;
      try { this.cfg = await api('/api/admin/publicidad/config', { method: 'PUT', body: this.cfgForm }); this.cfgForm.smtp.password = ''; toast('Configuración guardada', 'ok'); this.resumen = await api('/api/admin/publicidad/resumen'); }
      catch (e) { toast(e.message, 'err'); } finally { this.guardandoCfg = false; }
    },
  },
  template: `
  <div>
    <div class="card" v-if="bloqueado"><h2>Publicidad</h2><p class="muted" style="margin:0">{{bloqueado}}.</p></div>
    <template v-else>
    <div class="dash" style="margin-bottom:14px" v-if="resumen">
      <div class="kpi w3"><div class="t">Contactos activos</div><div class="v">{{resumen.activos}}</div></div>
      <div class="kpi w3"><div class="t">Dados de baja</div><div class="v">{{resumen.bajas}}</div></div>
      <div class="kpi w3"><div class="t">Rebotados</div><div class="v">{{resumen.rebotados}}</div></div>
      <div class="kpi w3"><div class="t">Enviados en la última hora</div><div class="v">{{resumen.ultima_hora}} <span class="small muted">/ {{resumen.config.por_hora}}</span></div></div>
    </div>
    <div class="alert warn" style="margin:0 0 12px" v-if="resumen && !resumen.config.listo">Falta el correo de salida para la publicidad. Configúrelo en la pestaña <a href="javascript:void 0" @click="ir('config')">Configuración</a> antes de enviar.</div>
    <div class="tabs" style="margin-bottom:12px">
      <button class="tab" :class="{on:sub==='campanas'}" @click="ir('campanas')">Campañas</button>
      <button class="tab" :class="{on:sub==='contactos'}" @click="ir('contactos')">Contactos</button>
      <button class="tab" :class="{on:sub==='config'}" @click="ir('config')">Configuración</button>
    </div>

    <template v-if="sub==='campanas'">
      <div class="card pad0">
        <div class="row" style="padding:14px 16px 0;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
          <h2 style="margin:0">Campañas</h2>
          <div class="row" style="gap:8px"><button class="btn sec" v-if="enCurso" @click="procesarAhora">Enviar el siguiente lote ahora</button><button class="btn" @click="nueva">+ Nueva campaña</button></div>
        </div>
        <div class="table-wrap" style="margin-top:10px"><table class="tbl">
          <thead><tr><th>Campaña</th><th>Público</th><th>Estado</th><th class="num">Avance</th><th>Fecha</th><th></th></tr></thead>
          <tbody>
            <tr v-for="c in campanas" :key="c.id">
              <td><b>{{c.nombre}}</b><div class="small muted">{{c.asunto}}</div><div class="small" style="color:var(--danger)" v-if="c.ultimo_error && (c.estado==='enviando' || c.estado==='pausada')">{{c.ultimo_error}}</div></td>
              <td class="small">{{c.etiquetas || 'Todos los activos'}}</td>
              <td><Badge :value="estado(c.estado)"></Badge></td>
              <td class="num small"><template v-if="c.total">{{c.enviados}} de {{c.total}}<div class="muted" v-if="c.fallidos || c.omitidos">{{c.fallidos ? c.fallidos + ' fallidos' : ''}}{{c.fallidos && c.omitidos ? ' · ' : ''}}{{c.omitidos ? c.omitidos + ' omitidos' : ''}}</div><div class="muted" v-if="c.pendientes">{{c.pendientes}} pendientes · {{horas(c.pendientes)}}</div></template><span v-else class="muted">—</span></td>
              <td class="small">{{fechaHora(c.terminada || c.iniciada || c.creada)}}</td>
              <td style="white-space:nowrap">
                <template v-if="c.estado==='borrador'"><button class="btn sm sec" @click="editar(c)">Editar</button> <button class="btn sm" @click="enviar(c)">Enviar</button></template>
                <button class="btn sm sec" v-if="c.estado==='enviando'" @click="accion(c,'pausar')">Pausar</button>
                <button class="btn sm" v-if="c.estado==='pausada'" @click="accion(c,'reanudar')">Reanudar</button>
                <button class="btn sm ghost" v-if="c.estado==='enviando' || c.estado==='pausada'" @click="accion(c,'cancelar')">Cancelar</button>
                <button class="btn sm ghost" v-if="c.total" @click="abrirEnvios(c)">Detalle</button>
                <button class="btn sm ghost" @click="duplicar(c)">Duplicar</button>
                <button class="btn sm ghost" v-if="c.estado!=='enviando' && c.estado!=='pausada'" @click="borrar(c)" title="Borrar">✕</button>
              </td>
            </tr>
            <tr v-if="!campanas.length"><td colspan="6" class="muted" style="text-align:center;padding:18px">Todavía no hay campañas. Cree la primera con «+ Nueva campaña».</td></tr>
          </tbody>
        </table></div>
      </div>
    </template>

    <template v-if="sub==='contactos'">
      <div class="card pad0">
        <div class="toolbar" style="padding:12px 12px 0;gap:8px;flex-wrap:wrap">
          <input class="search" placeholder="Buscar correo, nombre o empresa" v-model="q">
          <select v-model="filtroEstado" style="width:auto"><option value="">Todos los estados</option><option value="activo">Activos</option><option value="baja">De baja</option><option value="rebotado">Rebotados</option></select>
          <select v-model="filtroEtiqueta" style="width:auto"><option value="">Todas las etiquetas</option><option v-for="t in etiquetas" :key="t[0]" :value="t[0]">{{t[0]}} ({{t[1]}})</option></select>
          <span style="flex:1"></span>
          <button class="btn sec sm" @click="traer('sitio')">Traer solicitudes de la página</button>
          <button class="btn sec sm" @click="traer('clientes')">Traer clientes del sistema</button>
          <button class="btn sec sm" @click="importar={texto:'',etiquetas:'',permiso:''};resultadoImport=null">Importar lista</button>
          <button class="btn sm" @click="nuevoContacto">+ Agregar contacto</button>
        </div>
        <DataTable :rows="contactosFiltrados" :columns="colContactos" :search="q" :page-size="50" empty-title="Sin contactos" empty-text="Agregue contactos a mano, importe una lista o traiga las solicitudes de la página." @row-click="abrirContacto"></DataTable>
      </div>
    </template>

    <template v-if="sub==='config'">
      <div class="card" v-if="!cfgForm"><p class="muted">Cargando…</p></div>
      <template v-else>
        <div class="card"><h2>Correo de salida</h2>
          <p class="small muted" style="margin:0 0 10px">Recomendado: una cuenta aparte solo para publicidad (por ejemplo novedades@ de su dominio). Así, si alguien marca un correo como spam, no se afectan los correos de facturas ni los de contraseñas.</p>
          <div class="row" style="gap:18px;flex-wrap:wrap;margin-bottom:12px">
            <label class="row" style="gap:6px"><input type="radio" :value="false" v-model="cfgForm.usar_sistema"> Una cuenta aparte para publicidad</label>
            <label class="row" style="gap:6px"><input type="radio" :value="true" v-model="cfgForm.usar_sistema" :disabled="!cfg.sistema_disponible"> El correo del sistema{{cfg.sistema_remitente ? ' (' + cfg.sistema_remitente + ')' : ' (no está configurado en el servidor)'}}</label>
          </div>
          <div class="grid cols-3" v-if="!cfgForm.usar_sistema">
            <Field label="Servidor SMTP" req><input v-model="cfgForm.smtp.host" placeholder="mail.sudominio.com"></Field>
            <Field label="Seguridad"><select v-model="cfgForm.smtp.seguridad"><option value="ssl">SSL (puerto 465)</option><option value="starttls">STARTTLS (puerto 587)</option><option value="ninguna">Ninguna</option></select></Field>
            <Field label="Puerto"><input type="number" v-model.number="cfgForm.smtp.puerto"></Field>
            <Field label="Usuario"><input v-model="cfgForm.smtp.usuario" autocomplete="off" placeholder="novedades@sudominio.com"></Field>
            <Field label="Contraseña" :help="cfg.smtp.clave_guardada ? 'Guardada. Escriba solo para cambiarla' : ''"><input type="password" v-model="cfgForm.smtp.password" autocomplete="new-password" :placeholder="cfg.smtp.clave_guardada ? 'Sin cambios' : ''"></Field>
            <Field label="Remitente" req><input v-model="cfgForm.smtp.remitente" placeholder="novedades@sudominio.com"></Field>
            <Field label="Nombre visible"><input v-model="cfgForm.smtp.nombre" placeholder="FISITAAP by Brillante Agencia"></Field>
            <Field label="Respuestas a" help="Opcional: a dónde llegan las respuestas"><input v-model="cfgForm.smtp.responder_a" placeholder="ventas@sudominio.com"></Field>
          </div>
        </div>
        <div class="card"><h2>Envío</h2>
          <div class="grid cols-3">
            <Field label="Máximo de correos por hora" help="El hosting limita los correos por hora de todo el dominio. Pasarse bloquea también las facturas. 100 es seguro en la mayoría de cPanel."><input type="number" min="10" max="1000" v-model.number="cfgForm.por_hora"></Field>
          </div>
          <Field label="Pie de los correos" help="Quién envía. Va al final de cada correo, junto al enlace para darse de baja."><input v-model="cfgForm.pie" maxlength="300"></Field>
          <div class="row" style="gap:8px;margin-top:12px"><button class="btn" @click="guardarCfg" :disabled="guardandoCfg">{{guardandoCfg ? 'Guardando…' : 'Guardar'}}</button></div>
        </div>
        <div class="card"><h2>Antes de la primera campaña</h2>
          <ul class="small" style="margin:0;padding-left:18px;line-height:1.6">
            <li>En cPanel › Email Deliverability, el dominio del remitente debe tener SPF y DKIM en verde. Sin eso, Gmail y Outlook mandan los correos a spam.</li>
            <li>Escriba solo a quien pidió novedades o ya es cliente o prospecto. A los demás, primero pídales permiso.</li>
            <li>Cada correo lleva el enlace para darse de baja. Quien se da de baja no recibe más, aunque se vuelva a importar.</li>
            <li>Mande primero una prueba a su propio correo y revísela en el teléfono.</li>
          </ul>
        </div>
      </template>
    </template>

    <Modal v-if="editor" lg :title="editor.id ? 'Editar campaña' : 'Nueva campaña'" @close="editor=null">
      <div class="grid cols-2" style="align-items:start;gap:16px">
        <div style="display:grid;gap:10px">
          <Field label="Nombre de la campaña" req help="Solo para usted; no lo ve el cliente"><input v-model="editor.nombre" maxlength="120" placeholder="Promoción de octubre"></Field>
          <Field label="Color del correo"><div class="row" style="gap:6px;flex-wrap:wrap"><button v-for="t in temas" :key="t.id" type="button" class="btn sm" :class="editor.tema===t.id ? '' : 'ghost'" @click="editor.tema=t.id;vistaPrevia()"><span :style="{display:'inline-block',width:'12px',height:'12px',borderRadius:'6px',background:t.color,marginRight:'6px',verticalAlign:'-1px'}"></span>{{t.nombre}}</button></div></Field>
          <Field label="Asunto del correo" req><input v-model="editor.asunto" maxlength="200" @input="vistaPrevia" placeholder="{nombre}, su factura electrónica sin complicaciones"></Field>
          <Field label="Texto de vista previa" help="Lo que la bandeja de entrada muestra al lado del asunto"><input v-model="editor.preencabezado" maxlength="200" @input="vistaPrevia"></Field>
          <Field label="Antetítulo" help="Texto pequeño en mayúsculas sobre el título"><input v-model="editor.antetitulo" maxlength="80" @input="vistaPrevia" placeholder="Oferta especial"></Field>
          <Field label="Título"><input v-model="editor.titulo" maxlength="200" @input="vistaPrevia" placeholder="Pruebe FISITAAP by Brillante Agencia gratis"></Field>
          <Field label="Texto" help="{nombre} y {empresa} se cambian por los del contacto; si no los tiene, se quitan."><textarea rows="14" v-model="editor.cuerpo" @input="vistaPrevia" maxlength="20000"></textarea></Field>
          <details class="small" style="margin:-4px 0 4px"><summary style="cursor:pointer;color:var(--primary)">Cómo dar formato al texto</summary>
            <table class="tbl" style="margin-top:6px"><tbody>
              <tr><td class="mono">## Subtítulo</td><td>Subtítulo de sección</td></tr>
              <tr><td class="mono">&gt; Texto</td><td>Recuadro destacado</td></tr>
              <tr><td class="mono">- Texto</td><td>Lista con viñetas</td></tr>
              <tr><td class="mono">✓ Texto</td><td>Lista con marcas de verificación (también «+ »)</td></tr>
              <tr><td class="mono">1. Texto</td><td>Pasos numerados</td></tr>
              <tr><td class="mono">* 2 meses | gratis</td><td>Cifras grandes en recuadros (hasta 3 por fila)</td></tr>
              <tr><td class="mono">" Frase | Quién</td><td>Cita</td></tr>
              <tr><td class="mono">---</td><td>Línea separadora</td></tr>
              <tr><td class="mono">**texto**</td><td>Negrita</td></tr>
              <tr><td class="mono">[texto](https://…)</td><td>Enlace</td></tr>
            </tbody></table>
            <p class="muted" style="margin:6px 0 0">Una línea en blanco separa los bloques. El correo se arma sin imágenes: se ve completo apenas se abre.</p>
          </details>
          <Field label="Imagen (opcional)" help="Mejor sin imagen: muchos programas de correo las bloquean hasta que el lector las permite. Si la usa: https, 600 px de ancho"><input v-model="editor.imagen_url" @change="vistaPrevia" placeholder="https://…"></Field>
          <div class="grid cols-2"><Field label="Botón: texto"><input v-model="editor.boton_texto" maxlength="60" @input="vistaPrevia" placeholder="Ver planes"></Field><Field label="Botón: enlace"><input v-model="editor.boton_url" @change="vistaPrevia" :placeholder="'https://' + sistemaCfg().dominio + '/precios'"></Field></div>
          <Field label="¿A quién se envía?" :help="'Sin etiquetas marcadas = a todos los contactos activos. Con etiquetas = a los que tengan alguna de ellas.' + (publico !== null ? ' Recibirán: ' + publico + ' contacto(s).' : '')">
            <div class="row" style="gap:6px;flex-wrap:wrap"><button v-for="t in etiquetas" :key="t[0]" type="button" class="btn sm" :class="tieneEtiqueta(t[0]) ? '' : 'ghost'" @click="alternarEtiqueta(t[0])">{{t[0]}} ({{t[1]}})</button><span class="small muted" v-if="!etiquetas.length">Aún no hay etiquetas en los contactos.</span></div>
          </Field>
          <div class="row" style="gap:8px;align-items:flex-end;margin-top:8px"><Field label="Enviar una prueba a" style="flex:1;margin:0"><input type="email" v-model="para"></Field><button class="btn sec" @click="probar" :disabled="probando || !para">{{probando ? 'Enviando…' : 'Enviar prueba'}}</button></div>
        </div>
        <div>
          <div class="small muted" style="margin-bottom:6px">Vista previa{{publico !== null ? ' · ' + publico + ' destinatario(s)' : ''}}</div>
          <iframe v-if="previa" :srcdoc="previa" sandbox="" style="width:100%;height:560px;border:1px solid var(--border);border-radius:8px;background:#f3f5f4"></iframe>
          <p class="muted" v-else>Escriba el asunto para ver la vista previa.</p>
        </div>
      </div>
      <template #foot><button class="btn ghost" @click="editor=null">Cerrar</button><button class="btn sec" @click="guardar()" :disabled="guardando">Guardar borrador</button><button class="btn" @click="enviar(editor)" :disabled="guardando || !publico">Enviar{{publico ? ' a ' + publico : ''}}</button></template>
    </Modal>

    <Modal v-if="eligiendo" lg title="Nueva campaña: escoja una plantilla" @close="eligiendo=false">
      <p class="muted" v-if="!plantillas">Cargando…</p>
      <div class="grid cols-3" v-else style="gap:12px">
        <button type="button" class="card plantilla" style="text-align:left;cursor:pointer;margin:0;padding:14px;border:1px dashed var(--border)" @click="usar(null)">
          <b>En blanco</b><div class="small muted" style="margin-top:6px">Empiece desde cero con el diseño de FISITAAP by Brillante Agencia.</div></button>
        <button type="button" v-for="p in plantillas" :key="p.id" class="card plantilla" style="text-align:left;cursor:pointer;margin:0;padding:0;overflow:hidden;display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch" @click="usar(p)">
          <div :style="{background: colorTema(p.tema), color:'#fff', padding:'12px 14px'}"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;opacity:.8">{{p.antetitulo}}</div><div style="font-weight:bold;margin-top:4px;line-height:1.3">{{p.titulo}}</div></div>
          <div style="padding:10px 14px 14px"><b>{{p.nombre}}</b><div class="small muted" style="margin-top:4px">{{p.descripcion}}</div></div>
        </button>
      </div>
    </Modal>

    <Modal v-if="contacto" :title="contacto.id ? contacto.correo : 'Nuevo contacto'" @close="contacto=null">
      <div class="grid cols-2">
        <Field label="Correo" req><input type="email" v-model="contacto.correo"></Field>
        <Field label="Nombre"><input v-model="contacto.nombre" maxlength="80"></Field>
        <Field label="Empresa"><input v-model="contacto.empresa" maxlength="100"></Field>
        <Field label="Etiquetas" help="Separadas por coma: hoteles, clientes…"><input v-model="contacto.etiquetas"></Field>
        <Field label="Permiso"><select v-model="contacto.permiso"><option value="expreso">Pidió recibir novedades</option><option value="relacion">Cliente o prospecto con trato previo</option></select></Field>
        <Field label="Estado" v-if="contacto.id" :help="contacto.estado==='baja' ? 'Reactívelo solo si la persona lo pidió de nuevo' : ''"><select v-model="contacto.estado"><option value="activo">Activo</option><option value="baja">De baja</option><option value="rebotado" disabled>Rebote</option></select></Field>
      </div>
      <Field label="Nota"><input v-model="contacto.nota" maxlength="300"></Field>
      <p class="small muted" v-if="contacto.id">Origen: {{ORIGENES[contacto.origen] || contacto.origen}} · agregado el {{fecha(contacto.creado)}}{{contacto.baja_en ? ' · de baja desde el ' + fecha(contacto.baja_en) : ''}}</p>
      <template #foot><button class="btn ghost" v-if="contacto.id" @click="borrarContacto" style="margin-right:auto">Borrar</button><button class="btn ghost" @click="contacto=null">Cancelar</button><button class="btn" @click="guardarContacto">Guardar</button></template>
    </Modal>

    <Modal v-if="importar" title="Importar lista de correos" @close="importar=null">
      <Field label="Pegue la lista" help="Un contacto por línea: correo, nombre, empresa (separados por coma o punto y coma), o simplemente un texto con correos. También sirve copiar columnas de Excel."><textarea rows="9" v-model="importar.texto" placeholder="ana@hotel.cr; Ana Solís; Hotel Playa Serena&#10;luis@soda.cr, Luis Mora"></textarea></Field>
      <Field label="Etiquetas para todos" help="Separadas por coma"><input v-model="importar.etiquetas" placeholder="hoteles, feria octubre"></Field>
      <Field label="¿Cómo obtuvo estos correos?" req>
        <label class="row" style="gap:6px;margin:4px 0"><input type="radio" value="expreso" v-model="importar.permiso"> Pidieron recibir novedades (formulario, feria, lista de interesados)</label>
        <label class="row" style="gap:6px;margin:4px 0"><input type="radio" value="relacion" v-model="importar.permiso"> Son clientes o prospectos con los que ya tuve trato</label>
      </Field>
      <p class="small muted" style="margin:6px 0 0">No importe listas compradas ni correos sacados de internet: generan reclamos, bloquean el dominio y la ley pide consentimiento.</p>
      <template #foot><button class="btn ghost" @click="importar=null">Cancelar</button><button class="btn" @click="hacerImportar" :disabled="!importar.texto.trim()">Importar</button></template>
    </Modal>

    <Modal v-if="verEnvios" lg :title="'Envíos de «' + verEnvios.nombre + '»'" @close="verEnvios=null">
      <p class="muted" v-if="!envios">Cargando…</p>
      <div class="table-wrap" v-else style="max-height:60vh"><table class="tbl"><thead><tr><th>Correo</th><th>Estado</th><th>Hora</th><th>Detalle</th></tr></thead>
        <tbody><tr v-for="e in envios" :key="e.id"><td>{{e.correo}}</td><td><Badge :value="({pendiente:'Pendiente',enviando:'Procesando',enviado:'Entregado',fallido:'Rechazado',omitido:'Omitido'})[e.estado] || e.estado"></Badge></td><td class="small">{{e.enviado_en ? fechaHora(e.enviado_en) : '—'}}</td><td class="small muted" style="white-space:normal">{{e.error || ''}}</td></tr></tbody></table></div>
    </Modal>
    </template>
  </div>`,
};
