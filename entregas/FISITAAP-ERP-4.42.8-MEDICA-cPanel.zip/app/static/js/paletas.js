// Diseños de la interfaz por usuario (FISITAAP by Brillante Agencia; antes «paletas», 1.35). Cada uno redefine las variables de ui.css
// (:root[data-paleta=...]). El elegido se guarda en la cuenta del usuario y en este navegador (para pintarlo antes de que cargue la
// sesión). Las paletas anteriores (turquesa, océano, índigo, grafito, terracota) siguen aceptadas y se ven como «fusión».
export const PALETAS = [
  { id: 'fusion', nombre: 'Fusión', desc: 'Claro, azul marino y verde: el diseño de FISITAAP by Brillante Agencia', colores: ['#193c56', '#237658', '#eaf0f5'] },
  { id: 'estudio', nombre: 'Estudio', desc: 'Cálido, tonos tierra y títulos con serifa', colores: ['#30342f', '#865c42', '#f4f1eb'] },
  { id: 'noche', nombre: 'Noche', desc: 'Oscuro, descansa la vista', colores: ['#141b21', '#c4dbad', '#2b3842'] },
];
const CLAVE = 'gf:paleta';
const VIEJAS = { turquesa: 'fusion', oceano: 'fusion', indigo: 'fusion', grafito: 'noche', terracota: 'estudio' };

export function aplicarPaleta(id) {
  const p = PALETAS.find(x => x.id === id) ? id : (VIEJAS[id] || 'fusion');
  document.documentElement.dataset.paleta = p;
  try { localStorage.setItem(CLAVE, p); } catch { /* sin almacenamiento: solo esta vista */ }
  return p;
}
