// Cliente HTTP + utilidades compartidas.
export const TOKEN_KEY = 'facturacr:token';
export function token() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; } }
// El servidor además emite una cookie HttpOnly (el JS no la toca) que solo vale para descargas GET (PDF, XML, logo, imágenes)
export function setToken(t) {
  try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch {}
}
// Cierra la sesión en el servidor (revoca el token y borra la cookie) antes de limpiar el estado local
export async function cerrarSesionServidor() { try { await api('/api/auth/salir', { method: 'POST' }); } catch {} avisarSWLimpiar(); }   // también se borran las copias sin conexión (3.55)
// Se invoca cuando el servidor responde 401 (sesión vencida) para volver a la pantalla de inicio de sesión
export let alExpirar = () => {};
export function onExpirar(fn) { alExpirar = fn; }
// Empresa que muestra ESTA pestaña: va en cada petición (X-Empresa) y el servidor la compara con la sesión
let _empresaTab = null;
export function fijarEmpresaTab(id) { _empresaTab = id || null; }
// Sucursal activa de esta pestaña (3.66): va en cada petición (X-Sucursal); el servidor la valida contra la empresa y la del usuario
let _sucursalTab = null;
export function fijarSucursal(id) { _sucursalTab = id || null; }
// Aviso que bloquea la pestaña cuando la sesión cambió en otra (otra empresa, otro usuario o sesión cerrada)
export const avisoSesion = reactive({ mensaje: '' });
// Cabeceras de sesión para las llamadas que usan fetch directo (subir archivos, descargar ZIP o PDF)
export function cabecerasAuth(extra = {}) { return { Authorization: 'Bearer ' + token(), ...(_empresaTab ? { 'X-Empresa': String(_empresaTab) } : {}), ...(_sucursalTab ? { 'X-Sucursal': String(_sucursalTab) } : {}), ...extra }; }
// Contenido del token (uid, eid): solo para comparar entre pestañas; la validez la decide el servidor
export function datosToken(t) {
  try { const c = String(t || '').split('.')[0].replace(/-/g, '+').replace(/_/g, '/'); return JSON.parse(atob(c + '==='.slice((c.length + 3) % 4))); } catch { return null; }
}

// Suma días a una fecha 'AAAA-MM-DD' en hora local (después de las 6 p. m. toISOString() daba el día siguiente, UTC) (R194)
export function sumarDias(iso, n) { const d = new Date(String(iso || hoy()).slice(0, 10) + 'T00:00:00'); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function sumarMeses(iso, n, dia) { const d = new Date(String(iso || hoy()).slice(0, 10) + 'T00:00:00'); const dd = dia === undefined ? d.getDate() : dia; d.setMonth(d.getMonth() + n, 1); if (dia === undefined) d.setDate(Math.min(dd, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); else d.setMonth(d.getMonth(), dd); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }

// Cantidades de inventario con hasta 3 decimales, sin ceros sobrantes (R120)
export function fmtCant(v) { const n = +v || 0; return n.toLocaleString('es-CR', { minimumFractionDigits: 0, maximumFractionDigits: 3 }).replace(/[\u202f\u00a0 ]/g, '.'); }

// Estado de la conexión con el servidor (3.55): la caja lo usa para seguir vendiendo sin internet y avisar.
export const red = reactive({ enLinea: typeof navigator === 'undefined' ? true : navigator.onLine !== false, desdeCache: false, ultimoFallo: 0 });
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => { red.enLinea = true; try { mock.guardarTodo(); } catch {} });
  window.addEventListener('offline', () => { red.enLinea = false; });
  // service worker: deja abrir el sistema sin conexión con la última copia de los datos (solo en la nube; el programa local ya trabaja sin internet)
  // 3.87: se registra al terminar de cargar la página: la primera visita ya no compite con la descarga del programa que guarda el service worker
  if ('serviceWorker' in navigator && location.pathname.startsWith('/app')) { const registrar = () => { try { navigator.serviceWorker.register('/sw-app.js').catch(() => {}); } catch {} }; if (document.readyState === 'complete') registrar(); else window.addEventListener('load', registrar, { once: true }); }
}
export function avisarSWLimpiar() { try { navigator.serviceWorker && navigator.serviceWorker.controller && navigator.serviceWorker.controller.postMessage({ tipo: 'limpiar' }); } catch {} }

export async function api(url, opt = {}) {
  opt.headers = { ...(opt.headers || {}) };
  if (opt.body && !(opt.body instanceof FormData)) {
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(opt.body);
  }
  const t = token();
  if (t && !opt.headers.Authorization) opt.headers.Authorization = 'Bearer ' + t;
  if (_empresaTab && !opt.headers['X-Empresa']) opt.headers['X-Empresa'] = String(_empresaTab);
  const sinSucursal = !!opt.sinSucursal; delete opt.sinSucursal;   // 4.25 (7b, T8): la llamada va con el token de OTRA empresa: sin la sucursal de esta pestaña
  if (_sucursalTab && !sinSucursal && !opt.headers['X-Sucursal']) opt.headers['X-Sucursal'] = String(_sucursalTab);
  // 4.8: opt.limite (ms) = cuánto se espera a que el servidor EMPIECE a responder; vencido, no es «sin conexión» (el servidor está lento)
  let r, tope = null, vencido = false;
  const lim = opt.limite; delete opt.limite;
  const sinExpirar = !!opt.sinExpirar; delete opt.sinExpirar;   // 4.25 (tanda 7): quien llama atiende él mismo un 401 (la conexión de esta computadora retira la cuenta local)
  if (lim && typeof AbortController !== 'undefined') { const ac = new AbortController(); opt.signal = ac.signal; tope = setTimeout(() => { vencido = true; ac.abort(); }, lim); }
  try { r = await fetch(url, opt); }
  catch (ex) {                                             // sin red (o servidor caído): la caja lo distingue de un rechazo del servidor
    if (vencido) { const err = new Error('El servidor tardó demasiado en responder. Intente de nuevo en un momento.'); err.limite = true; throw err; }
    red.enLinea = false; red.ultimoFallo = Date.now();
    const err = new Error('Sin conexión con el servidor'); err.sinConexion = true; throw err;
  } finally { if (tope) clearTimeout(tope); }             // con la respuesta empezada, el contenido baja sin límite (como antes)
  red.enLinea = true; red.desdeCache = r.headers.get('X-Desde-Cache') === '1';
  if (red.desdeCache) red.enLinea = false;
  const j = r.status === 204 ? null : await r.json().catch(() => null);
  if (!r.ok) {
    if (r.status === 503 && red.desdeCache) { const err = new Error('Sin conexión con el servidor'); err.sinConexion = true; throw err; }
    if (r.status === 401 && !url.startsWith('/api/auth/') && !sinExpirar) alExpirar();
    const d = j && j.detail;
    if (r.status === 409 && d && d.codigo === 'empresa_cambiada') avisoSesion.mensaje = d.mensaje;
    const err = new Error(!j ? ('Error del servidor (' + r.status + '). Intente de nuevo en un momento.') : typeof d === 'string' ? d : d?.mensaje ? d.mensaje + (d.errores ? '\n' + d.errores.join('\n') : '') : Array.isArray(d) ? d.map(x => x.msg).join('; ') : (d || j) ? JSON.stringify(d || j) : 'el servidor no respondió (error ' + r.status + ')');
    err.status = r.status; err.detail = d;
    throw err;
  }
  return j;
}
// URL de descarga autenticada (PDF/XML abren en pestaña nueva): se obtiene el blob con el token y se abre
// 4.1: visor de documentos dentro del sistema: el PDF (o el XML) se ve en una ventana sobre la pantalla, con «Descargar» y «Abrir aparte».
export async function verDocumento(url, titulo, nombre) {
  const cab = { Authorization: 'Bearer ' + token(), ...(_empresaTab ? { 'X-Empresa': String(_empresaTab) } : {}), ...(_sucursalTab ? { 'X-Sucursal': String(_sucursalTab) } : {}) };
  const r = await fetch(url, { headers: cab });
  if (r.status === 405) throw new Error('Esta opción todavía no está activa en el servidor: reinicie la aplicación en el hosting después de actualizar');
  if (!r.ok) { const j = await r.json().catch(() => null); const d = j && j.detail; throw new Error(typeof d === 'string' ? d : (d && d.mensaje) || 'No se pudo abrir el documento'); }
  const blob = await r.blob();
  const u = URL.createObjectURL(blob);
  const nomArch = nombre || ((r.headers.get('Content-Disposition') || '').match(/filename="?([^";]+)/) || [])[1] || 'documento';
  const capa = document.createElement('div');
  capa.setAttribute('style', 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:12px');
  capa.innerHTML = '<div style="background:var(--card,#fff);color:var(--text,#111);width:min(1000px,100%);height:min(94vh,100%);border-radius:12px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,.4)">'
    + '<div style="display:flex;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid var(--line,#ddd)"><b data-t style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></b>'
    + '<a class="btn sm sec" data-d>⤓ Descargar</a><a class="btn sm ghost" data-a target="_blank" rel="noopener">Abrir aparte</a><button class="btn sm ghost" data-c type="button" aria-label="Cerrar">✕</button></div>'
    + '<iframe data-f style="flex:1;border:0;width:100%;background:#fff" title="Documento"></iframe></div>';
  capa.querySelector('[data-t]').textContent = titulo || nomArch;
  const d = capa.querySelector('[data-d]'); d.href = u; d.download = nomArch;
  capa.querySelector('[data-a]').href = u;
  capa.querySelector('[data-f]').src = u;
  const cerrar = () => { capa.remove(); document.removeEventListener('keydown', esc); setTimeout(() => URL.revokeObjectURL(u), 1000); };
  const esc = e => { if (e.key === 'Escape') cerrar(); };
  capa.querySelector('[data-c]').onclick = cerrar;
  capa.addEventListener('click', e => { if (e.target === capa) cerrar(); });
  document.addEventListener('keydown', esc);
  document.body.appendChild(capa);
}
// Los enlaces a PDF y XML de comprobantes, recibidos y exoneraciones se abren en el visor (Ctrl/Cmd o la rueda siguen abriéndolos aparte).
const DOC_RE = /^\/api\/(comprobantes|recepcion|exoneraciones|pagos|pedidos)\/[^?#]+\/(pdf|xml|tiquete|mensaje|respuesta|recibo|comprobante)(\?|$)/;
try {
  document.addEventListener('click', e => {
    const a = e.target && e.target.closest && e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || a.hasAttribute('download')) return;
    const href = a.getAttribute('href') || '';
    if (!DOC_RE.test(href)) return;
    e.preventDefault();
    verDocumento(href, a.getAttribute('title') && a.getAttribute('title').length > 3 ? a.getAttribute('title') : null).catch(err => toast(err.message, 'err'));
  }, true);
} catch { /* sin documento (pruebas) */ }

export async function abrirArchivo(url, nombre, body, respaldo) {   // con `body` hace POST (reportes en PDF/Word)
  const cab = { Authorization: 'Bearer ' + token(), ...(_empresaTab ? { 'X-Empresa': String(_empresaTab) } : {}), ...(_sucursalTab ? { 'X-Sucursal': String(_sucursalTab) } : {}) };
  const r = await fetch(url, body ? { method: 'POST', headers: { ...cab, 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : { headers: cab });
  if (r.status === 405) throw new Error('Esta opción todavía no está activa en el servidor: reinicie la aplicación en el hosting después de actualizar');   // 3.99: el servidor sigue con la versión anterior
  if (!r.ok) { const j = await r.json().catch(() => null); const d = j && j.detail; throw new Error(typeof d === 'string' ? d : Array.isArray(d) ? d.map(x => x.msg).join('; ') : (d && d.mensaje) || ('Error ' + r.status)); }
  const blob = await r.blob();
  const u = URL.createObjectURL(blob);
  setTimeout(() => URL.revokeObjectURL(u), 60000);
  if (nombre) { const a = document.createElement('a'); a.href = u; a.download = nombre; a.click(); }
  // 4.24: si el archivo tardó en prepararse el navegador ya no toma la ventana como pedida por el clic y la bloquea (window.open da null): se dice, no se calla.
  // Con `respaldo` (un nombre de archivo) no hace falta pedirlo otra vez: el archivo ya bajado se descarga con ese nombre y se devuelve 'descargado'
  else if (!window.open(u, '_blank')) {
    if (!respaldo) throw new Error('El navegador bloqueó la ventana del archivo: use el botón de descargar, o permita las ventanas emergentes de este sitio y vuelva a intentarlo');
    const a = document.createElement('a'); a.href = u; a.download = respaldo; a.click();
    return 'descargado';
  }
}

// Formato costarricense: 1.234,56
// El navegador separa los miles del es-CR con un espacio fino: se cambia por punto, como en el PDF (1.234.567,89) (R268)
export function fmt(n, dec = 2) {
  return Number(n || 0).toLocaleString('es-CR', { minimumFractionDigits: dec, maximumFractionDigits: dec }).replace(/[\u202f\u00a0 ]/g, '.');
}
export const SIM = { CRC: '₡', USD: '$', EUR: '€' };
export function money(n, moneda = 'CRC') { return `${SIM[moneda] || moneda + ' '}${fmt(n)}`; }
// ---- fechas: SIEMPRE en hora de Costa Rica, sin importar la zona horaria de la PC del usuario ----
export const TZ_CR = 'America/Costa_Rica';
// Sellos sin zona (p. ej. "2026-10-09T03:00:06", auditoría/creado) vienen en UTC desde el servidor: se marcan como UTC.
function _dt(x) {
  if (x instanceof Date) return x;
  let v = String(x);
  if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(v)) v = v.replace(' ', 'T') + 'Z';
  return new Date(v);
}
// Fecha sin hora (YYYY-MM-DD) se muestra tal cual (si se parsea, el navegador la toma como UTC y en UTC-7 sale el día anterior).
export function fecha(iso) {
  if (!iso) return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso));
  if (m) return `${+m[3]}/${+m[2]}/${m[1]}`;
  const d = _dt(iso); return isNaN(d) ? String(iso).slice(0, 10) : d.toLocaleDateString('es-CR', { timeZone: TZ_CR });
}
// Fecha y hora (para auditoría, sesiones, historial): hora de Costa Rica
export function fechaHora(iso) {
  const d = iso === undefined ? new Date() : _dt(iso);
  return isNaN(d) ? String(iso ?? '') : d.toLocaleString('es-CR', { timeZone: TZ_CR, hour12: false });
}
// Fecha de HOY en Costa Rica (no la UTC del navegador: de noche daba el día siguiente)
// 3.70: contraseña temporal fácil de escribir y de recordar (dos palabras y cuatro dígitos); cumple la política de 12+ caracteres
const PALABRAS_CLAVE = ['Tucan', 'Volcan', 'Playa', 'Cafe', 'Monte', 'Selva', 'Nube', 'Perla', 'Coral', 'Arena', 'Brisa', 'Palma', 'Cedro', 'Ambar', 'Norte', 'Lago', 'Isla', 'Valle', 'Cielo', 'Flor', 'Mango', 'Coco', 'Lluvia', 'Luna', 'Pino', 'Roble', 'Ceiba', 'Garza', 'Colibri', 'Mono', 'Iguana', 'Rana', 'Puma', 'Jaguar', 'Delfin', 'Tortuga', 'Cacao', 'Trigo', 'Miel', 'Plata', 'Cobre', 'Bronce', 'Verde', 'Azul', 'Lila', 'Limon', 'Papaya', 'Guayaba', 'Nance', 'Yuca', 'Frijol', 'Sol', 'Mar', 'Rio', 'Oro'];
export function claveFacil() {
  const r = crypto.getRandomValues(new Uint32Array(3));
  const a = PALABRAS_CLAVE[r[0] % PALABRAS_CLAVE.length]; let b = PALABRAS_CLAVE[r[1] % PALABRAS_CLAVE.length];
  if (b === a) b = PALABRAS_CLAVE[(r[1] + 1) % PALABRAS_CLAVE.length];
  return `${a}-${b}-${1000 + (r[2] % 9000)}`;
}
export function hoy() { try { return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Costa_Rica' }); } catch { return new Date().toISOString().slice(0, 10); } }

// ---- toasts (reactivo: si no, Vue no repinta hasta la siguiente navegación) ----
import { reactive } from './vendor/vue.esm-browser.prod.min.js';
export const toasts = reactive({ list: [] });
export function toast(text, kind = '') {
  const t = { id: Date.now() + Math.random(), text: String(text), kind };
  toasts.list.push(t);
  setTimeout(() => { const i = toasts.list.indexOf(t); if (i >= 0) toasts.list.splice(i, 1); }, kind === 'err' ? 9000 : 4000);
}

// ---- registros de la empresa (compras, bancos, asientos, cotizaciones, empleados, listas de configuración…) ----
// Se cargan al entrar a la empresa (mock.cargar) y se refrescan al cambiar de pantalla (mock.refrescar) con lo que otros
// usuarios cambiaron. mock.set guarda en el servidor ~300 ms después enviando SOLO lo que cambió:
//  - listas de objetos con id (colecciones): altas, cambios y bajas por id (POST /cambios). Dos personas que agregan o
//    cambian elementos distintos no se pisan; si dos usan el mismo id nuevo, el servidor asigna otro y aquí se corrige.
//  - cualquier otro valor: PUT con la versión leída; si otro lo cambió, el servidor responde 409 y aquí se fusiona.
// El nombre `mock` se conserva por compatibilidad (antes era localStorage).
// Datos de ejemplo: solo cuando el servidor corre con FE_DATOS_EJEMPLO=1 (instalaciones demo). app.js lo fija al iniciar sesión.
export const demo = { activo: false };
// La pantalla abierta se montó sin los registros de la empresa (fallaron al entrar). Aunque después lleguen, sus copias son
// viejas (vacías): lo que guarde se rechaza hasta que se actualice la pantalla (app.js muestra el botón).
export const pantalla = { sinDatos: false };
const _reg = { datos: {}, base: {}, ver: {}, cargado: false, timers: {}, enCurso: {}, esperas: {}, remaps: {}, vuelo: {}, incierto: {}, topes: {}, parciales: {}, conds: {}, rango: 0, gen: 0 };   /* parciales: colecciones recortadas al entrar (3.73); conds: condiciones de bajas (4.31) */
/* 4.31: un elemento que viaja con `_fusion` (lo que cambió quien guarda una cuenta de la caja) lo pierde en cuanto el envío se confirma */
const _sinFusion = x => { if (!_esObj(x) || !Object.prototype.hasOwnProperty.call(x, '_fusion')) return x; const { _fusion, ...resto } = x; return resto; };
// ids por instalación (3.13): la nube da ids de 1 a 9 999 999; una instalación local con terminal t los da desde t·10 000 000.
// Los ids de otro rango (sincronizados) no cuentan para dar el siguiente, así nunca chocan entre instalaciones.
const _RANGO = 10000000;
function _mio(id) { return Math.floor((+id || 0) / _RANGO) === (_reg.rango || 0); }
function _maxPropio(l, key, extras) {
  return Math.max((l || []).reduce((m, x) => Math.max(m, _mio(x.id) ? +x.id || 0 : 0), 0), key && _mio(_reg.topes[key]) ? +_reg.topes[key] || 0 : 0,
    (_reg.rango || 0) * _RANGO, ...(extras || []).map(Number).filter(_mio));
}
// 4.29: quien recuerda el id de un elemento (la caja, su cuenta abierta) se entera cuando ese id cambia aquí: el servidor reasignó un alta
// que chocaba con la de otro equipo (los dos usaron el mismo id siguiente). antes y despues: la misma lista, elemento por elemento.
const _alCambiarIds = new Set();
function _avisarIds(key, antes, despues) {
  const cambios = {};
  (antes || []).forEach((x, i) => { const y = despues[i]; if (x && y && String(x.id) !== String(y.id)) cambios[String(x.id)] = y.id; });
  if (!Object.keys(cambios).length) return;
  for (const f of [..._alCambiarIds]) { try { f(key, cambios); } catch { /* un aviso que falla no detiene el guardado */ } }
}
const _copia = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const _igual = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const _esObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
export function esListaIds(v) { return Array.isArray(v) && v.every(x => _esObj(x) && x.id !== undefined && x.id !== null && x.id !== '' && Number.isInteger(+x.id)); }

// Fusión de tres versiones: lo que cambié yo respecto de la base se aplica sobre lo que hay ahora en el servidor.
const _porCodigo = v => Array.isArray(v) && v.length > 0 && v.every(x => _esObj(x) && typeof x.codigo === 'string' && x.codigo !== '');
export function fusionar(base, mio, suyo) {
  if (_igual(mio, base)) return _copia(suyo);
  if (suyo === undefined || suyo === null || _igual(suyo, base)) return _copia(mio);
  const porId = esListaIds(mio) && esListaIds(suyo) && (base === undefined || esListaIds(base));
  // listas sin id pero con código (monedas, catálogo de cuentas): se unen por código, no por el texto completo (si no, un
  // USD con otro tipo de cambio quedaba repetido)
  const porCod = !porId && _porCodigo(mio) && _porCodigo(suyo) && (base === undefined || (Array.isArray(base) && (!base.length || _porCodigo(base))));
  if (porId || porCod) {
    const k = porId ? (x => String(x.id)) : (x => x.codigo);
    const b = new Map((base || []).map(x => [k(x), x])), m = new Map(mio.map(x => [k(x), x]));
    const out = new Map(suyo.map(x => [k(x), x]));
    for (const [k, x] of m) if (!b.has(k) || !_igual(b.get(k), x)) out.set(k, x);
    for (const k of b.keys()) if (!m.has(k)) out.delete(k);
    return _copia([...out.values()]);
  }
  if (Array.isArray(mio) && Array.isArray(suyo) && Array.isArray(base || [])) {
    const t = x => JSON.stringify(x), bs = new Set((base || []).map(t)), ms = new Set(mio.map(t));
    const quitar = new Set([...bs].filter(x => !ms.has(x)));
    const res = suyo.filter(x => !quitar.has(t(x)));
    for (const x of mio) if (!bs.has(t(x)) && !res.some(y => t(y) === t(x))) res.push(x);
    return _copia(res);
  }
  if (_esObj(mio) && _esObj(suyo)) {
    const out = {}, bb = _esObj(base) ? base : {};
    for (const k of new Set([...Object.keys(bb), ...Object.keys(mio), ...Object.keys(suyo)])) {
      const enMio = k in mio, enBase = k in bb;
      if (enBase && !enMio) { if (k in suyo && !_igual(suyo[k], bb[k])) out[k] = suyo[k]; continue; }     // lo borré yo (salvo que el otro lo cambiara)
      if (!enMio) { out[k] = suyo[k]; continue; }
      out[k] = fusionar(bb[k], mio[k], suyo[k]);
    }
    return out;
  }
  return _copia(mio);                                           // conflicto en un mismo dato: gana lo mío (lo último que guardé)
}

async function _subirAhora(key, keepalive, cierre = false) {
  let val = _copia(_reg.datos[key]), base = _reg.base[key];
  const gen = _reg.gen, vuelo = cierre ? _reg.vuelo[key] : null, dudosas = cierre ? (_reg.incierto[key] || []) : [];
  if ((vuelo || dudosas.length) && Array.isArray(val) && esListaIds(val) && (base === undefined || esListaIds(base))) {
    // Se cierra la pestaña con un envío de esta clave en camino (o uno que falló sin respuesta): se manda solo lo que ese
    // envío no lleva. Sus altas no se repiten (reenviadas se duplicarían si el servidor les dio otro id) ni se tocan.
    const m = new Map((base || []).map(x => [String(x.id), x]));
    const altas = new Set([...(vuelo ? vuelo.nuevos : []), ...dudosas.map(x => x.id)].map(String));
    for (const id of (vuelo ? vuelo.deletes : [])) m.delete(String(id));
    for (const x of (vuelo ? vuelo.upserts : [])) m.set(String(x.id), x);
    base = [...m.values()].filter(x => !altas.has(String(x.id)));
    val = val.filter(x => !altas.has(String(x.id)));
  }
  const url = '/api/registros/' + encodeURIComponent(key), verAntes = _reg.ver[key];
  if (!cierre && _reg.incierto[key] && esListaIds(val) && (base === undefined || esListaIds(base))) {
    // El envío anterior de esta clave falló sin respuesta (red o servidor) y pudo haberse guardado igual. Antes de reenviar
    // sus altas (o de dar por terminado, si el usuario las borró) se buscan en el servidor por contenido: las que ya están se
    // toman como guardadas con el id que les dio el servidor (si no, quedaban dos copias del mismo asiento, compra o pago;
    // y si el usuario la borró, el borrado sale como baja).
    const srv = await api(url);
    if (_reg.gen !== gen) return true;
    const sinId = x => { const { id, ...resto } = x; return JSON.stringify(resto); };
    const enServidor = new Map();                            // contenido → elementos del servidor (puede haber iguales)
    for (const x of (esListaIds(srv.datos) ? srv.datos : [])) { const k = sinId(x); if (!enServidor.has(k)) enServidor.set(k, []); enServidor.get(k).push(x); }
    const bm = new Map((base || []).map(x => [String(x.id), x])), traduccion = {};
    for (const a of _reg.incierto[key]) {
      const x = (enServidor.get(sinId(a)) || []).find(y => !bm.has(String(y.id)));      // cada elemento del servidor, una sola vez
      if (x) { bm.set(String(x.id), x); traduccion[String(a.id)] = x.id; }
    }
    delete _reg.incierto[key];
    base = [...bm.values()]; _reg.base[key] = _copia(base);
    if (srv.ultimo_id) _reg.topes[key] = Math.max(+_reg.topes[key] || 0, +srv.ultimo_id);
    if (Object.keys(traduccion).length) {
      const destinos = new Set(Object.values(traduccion).map(String));
      const tr = l => {
        let max = _maxPropio(l, key, Object.values(traduccion));
        return l.map(x => { const k = String(x.id); if (traduccion[k] !== undefined) return { ...x, id: traduccion[k] }; return destinos.has(k) ? { ...x, id: ++max } : x; });
      };
      if (Array.isArray(_reg.datos[key])) { const previa = _reg.datos[key]; _reg.datos[key] = tr(previa); val = _copia(_reg.datos[key]); _avisarIds(key, previa, _reg.datos[key]); } else val = tr(val);
      _reg.remaps[key] = { ...(_reg.remaps[key] || {}), ...traduccion };
    }
  }
  if (val === undefined || _igual(val, base)) return true;
  if (Array.isArray(val) && !val.length && base === undefined) {          // lista vacía de una clave que esta pestaña no tenía
    // versión 0 = «la clave no existe»: si otro usuario ya la creó, el servidor responde 409 y no se borra lo suyo
    try {
      const r = await api(url, { method: 'PUT', body: { datos: [], version: 0 }, keepalive });
      if (_reg.gen === gen) { _reg.base[key] = []; _reg.ver[key] = r.version; }
    } catch (e) {
      if (e.status !== 409 || !e.detail || typeof e.detail !== 'object') throw e;
      // Otro usuario ya la creó. Lo suyo NO se toma como base: la pantalla sigue con su copia vacía y su próximo guardado lo
      // borraría. La base queda sin definir (lo que se agregue aquí va como alta nueva) y la próxima pantalla trae lo del servidor.
    }
    return true;
  }
  if (esListaIds(val) && (base === undefined || esListaIds(base))) {
    const b = new Map((base || []).map(x => [String(x.id), x])), c = new Map(val.map(x => [String(x.id), x]));
    const upserts = val.filter(x => !b.has(String(x.id)) || !_igual(b.get(String(x.id)), x));
    const deletes = [...b.keys()].filter(k => !c.has(k)).map(k => b.get(k).id);
    const nuevos = val.filter(x => !b.has(String(x.id))).map(x => x.id);
    if (!upserts.length && !deletes.length) { _reg.base[key] = val; return true; }
    /* 4.31: la condición de una baja (mock.condicionBaja) viaja solo con esa baja; sin condiciones el cuerpo es el de siempre */
    const conds = _reg.conds[key] || {}, condiciones = {};
    for (const x of upserts) delete conds[String(x.id)];                    // el elemento sigue (o volvió): su condición ya no vale
    for (const id of deletes) if (conds[String(id)]) condiciones[String(id)] = conds[String(id)];
    const cuerpo = { upserts, deletes, nuevos }; if (Object.keys(condiciones).length) cuerpo.condiciones = condiciones;
    let r;
    if (!cierre) _reg.vuelo[key] = { upserts, deletes, nuevos };          // lo que va en camino (por si se cierra la pestaña)
    try { r = await api(url + '/cambios', { method: 'POST', body: cuerpo, keepalive }); }
    catch (e) {
      // sin respuesta (red caída o error del servidor): pudo guardarse; el próximo envío lo comprueba antes de repetir las altas
      if (!cierre && _reg.gen === gen && (!e.status || e.status >= 500)) {
        const nv = new Set(nuevos.map(String));
        _reg.incierto[key] = [...(_reg.incierto[key] || []), ...upserts.filter(x => nv.has(String(x.id)))];
      }
      throw e;
    }
    finally { if (!cierre && _reg.gen === gen) delete _reg.vuelo[key]; }
    if (_reg.gen !== gen) return true;                                      // se cambió de empresa mientras tanto
    if (r.ultimo_id) _reg.topes[key] = Math.max(+_reg.topes[key] || 0, +r.ultimo_id);
    const remap = r.remap || {}, nuevoId = x => (remap[String(x.id)] !== undefined ? { ...x, id: remap[String(x.id)] } : x);
    if (Object.keys(remap).length) _reg.remaps[key] = { ...(_reg.remaps[key] || {}), ...remap };
    for (const [id, c] of Object.entries(condiciones)) if (conds[id] === c) delete conds[id];   /* 4.31: las condiciones mandadas ya se aplicaron */
    for (const id of deletes) b.delete(String(id));
    for (const x of upserts.map(nuevoId)) b.set(String(x.id), _sinFusion(x));
    _reg.base[key] = [...b.values()];
    if (Array.isArray(_reg.datos[key])) {
      // ids reasignados por el servidor; si un alta local hecha mientras tanto quedó con el mismo id, recibe otro libre
      /* 4.31: el elemento que sigue igual al que se mandó queda sin `_fusion` (uno cambiado después conserva el suyo, que lo incluye) */
      const enviados = new Map(upserts.map(nuevoId).filter(x => _esObj(x) && '_fusion' in x).map(x => [String(x.id), x]));
      const lista = _reg.datos[key].map(nuevoId).map(x => (enviados.size && _esObj(x) && enviados.has(String(x.id)) && _igual(enviados.get(String(x.id)), x) ? _sinFusion(x) : x)), confirmados = new Map(_reg.base[key].map(x => [String(x.id), x]));
      let max = _maxPropio(lista, key); const usados = new Set();
      const orden = lista.map((x, i) => [i, confirmados.has(String(x.id)) && _igual(confirmados.get(String(x.id)), x) ? 0 : 1]).sort((a, z) => a[1] - z[1]);
      for (const [i] of orden) { const k = String(lista[i].id); if (usados.has(k)) lista[i] = { ...lista[i], id: ++max }; usados.add(String(lista[i].id)); }
      const previa = _reg.datos[key]; _reg.datos[key] = lista; _avisarIds(key, previa, lista);
    }
    // Si otro usuario guardó entre mi última lectura y esto, la versión saltó más de uno: refrescar en la próxima pantalla
    _reg.ver[key] = verAntes !== undefined && verAntes !== null && r.version === verAntes + 1 ? r.version : null;
    /* 4.31: el servidor unió el guardado con lo de otro equipo o no borró una cuenta (le quedaba algo): se baja en la próxima sincronización */
    if ((Array.isArray(r.conservados) && r.conservados.length) || (Array.isArray(r.fusionados) && r.fusionados.length)) _reg.ver[key] = null;
    return true;
  }
  // clave que esta pestaña no tenía: 0 = «no existe». Versión desconocida: -1 (el servidor responde 409 con lo actual y se fusiona)
  let datos = val, version = verAntes ?? (base === undefined ? 0 : -1), b = base;
  for (let intento = 0; intento < 4; intento++) {
    if (_reg.gen !== gen) return true;                                      // se cambió de empresa: no reintentar con la sesión nueva
    try {
      const r = await api(url, { method: 'PUT', body: { datos, version }, keepalive });
      _reg.ver[key] = r.version; _reg.base[key] = _copia(datos);
      if (_igual(_reg.datos[key], val)) _reg.datos[key] = _copia(datos);     // si el usuario no lo volvió a cambiar, queda la versión fusionada
      return true;
    } catch (e) {
      if (e.status !== 409 || !e.detail || typeof e.detail !== 'object') throw e;
      datos = fusionar(b, datos, e.detail.datos); b = _copia(e.detail.datos); version = e.detail.version;
    }
  }
  throw new Error('Otros usuarios están cambiando estos datos al mismo tiempo; intente de nuevo');
}

// Guarda una clave ya (sin esperar los 300 ms). Las escrituras de una misma clave van en fila.
function _subir(key, keepalive = false) {
  clearTimeout(_reg.timers[key]); delete _reg.timers[key];
  const esperas = _reg.esperas[key] || []; delete _reg.esperas[key];
  const p = (_reg.enCurso[key] || Promise.resolve(true)).catch(() => false).then(() => _subirAhora(key, keepalive))
    .then(() => { esperas.forEach(f => f(true)); return true; })
    .catch(e => {
      toast('No se pudo guardar "' + key + '" en el servidor: ' + e.message, 'err');
      if (e.status === 403) { if (_reg.base[key] === undefined) delete _reg.datos[key]; else _reg.datos[key] = _copia(_reg.base[key]); }   // sin permiso: se descarta el cambio local
      esperas.forEach(f => f(false)); return false;
    })
    .finally(() => { if (_reg.enCurso[key] === p) delete _reg.enCurso[key]; });
  _reg.enCurso[key] = p;
  return p;
}

// Siguiente número de un documento propio (COT-, REM-, OC-…): el contador, pero nunca uno que ya use otro documento de la
// lista (un contador viejo, de otra pestaña o de dos personas a la vez, lo repetía).
export function siguienteNumero(lista, campo, prefijo, contador) {
  const usados = (lista || []).map(x => String((x && x[campo]) || '')).filter(n => n.startsWith(prefijo || ''))
    .map(n => n.slice(prefijo.length)).filter(n => /^\d+$/.test(n)).map(n => parseInt(n, 10));       // solo números completos
  return Math.max(+contador || 1, (usados.length ? Math.max(...usados) : 0) + 1);
}

// Precio de venta de un producto para un cliente: su lista de precios (Contactos › Lista de precios / Inventario › Listas de precios);
// sin lista, o lista principal o en otra moneda, el precio normal. Lo usan el punto de venta y las líneas de factura y cotización.
// Precio base del ítem en la moneda pedida (3.25): un ítem puede estar en dólares; se convierte con el tipo de cambio de la empresa
export function precioProducto(p, moneda) {
  const de = p.moneda || monedas.principal().codigo, a = moneda || 'CRC', v = +p.precio || 0;
  if (de === a) return v;
  const enCRC = de === 'CRC' ? v : v * (+monedas.tc(de) || 1);
  const r = a === 'CRC' ? enCRC : enCRC / (+monedas.tc(a) || 1);
  return Math.round(r * 100000) / 100000;
}
export function precioCliente(p, clienteId, moneda) {
  const base = precioProducto(p, moneda);
  if (!clienteId) return base;
  const ex = (mock.get('contactos_extra', {}) || {})[clienteId]; const listaId = ex && ex.lista_precios_id;
  if (!listaId || listaId === 1) return base;
  const listas = mock.get('listas_precios', []) || [], def = listas.find(x => x.id === listaId);
  // la lista solo aplica si está en la moneda del documento (sin moneda indicada: colones)
  if (!def || def.principal || (def.moneda || 'CRC') !== (moneda || 'CRC')) return base;
  const l = (((mock.get('items_extra', {}) || {})[p.id] || {}).listas || []).find(x => x.lista_id === def.id);
  if (!l) return base;
  return def.tipo === 'Porcentaje' ? Math.round(base * (1 - (+l.valor || 0) / 100) * 100) / 100 : (+l.valor || base);
}

const _refrescosEnCurso = new Set();   // 4.8: refrescos que todavía pueden escribir en el registro
// 4.8: sube cada vez que se monta otra pantalla (app.js). Un refresco empezado antes ya no escribe nada: la pantalla nueva copió el
// registro al montarse y, si algo cambiara debajo, al guardar su copia borraría o revertiría lo que guardaron otros. Los flujos que
// refrescan justo antes de numerar o aplicar (y que siguen aunque el usuario se vaya) piden { sinCorte: true }.
let _pantallaGen = 0;

export const mock = {
  get(key, fallback) {
    if (_reg.cargado) return key in _reg.datos ? _copia(_reg.datos[key]) : fallback;
    try { const v = localStorage.getItem('mock:' + key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
  },
  // Devuelve una promesa que se resuelve (true/false) cuando quedó guardado en el servidor; no hace falta esperarla.
  set(key, val) {
    // Sin registros cargados (cierre de sesión o cambio de empresa en curso) no se guarda nada: antes iba a este navegador
    // y se subía a la siguiente empresa que se abriera.
    if (!_reg.cargado) {
      if (_reg.fallo) toast('No se guardó: los datos de la empresa no se pudieron cargar. Recargue la página.', 'err');
      return Promise.resolve(false);
    }
    if (pantalla.sinDatos) {
      toast('Los datos de la empresa llegaron después de abrir esta pantalla: actualícela (botón arriba) y vuelva a hacer el cambio.', 'err');
      return Promise.resolve(false);
    }
    const rm = _reg.remaps[key];
    if (rm && Array.isArray(val)) val = val.map(x => { const n = x && rm[String(x.id)]; return n !== undefined && !val.some(y => String(y && y.id) === String(n)) ? { ...x, id: n } : x; });
    _reg.datos[key] = _copia(val);
    clearTimeout(_reg.timers[key]);
    return new Promise(res => {
      (_reg.esperas[key] = _reg.esperas[key] || []).push(res);
      _reg.timers[key] = setTimeout(() => _subir(key), 300);
    });
  },
  // Lee el valor más reciente (con lo fusionado de otros usuarios), aplica fn y lo guarda. Devuelve el valor nuevo.
  actualizar(key, fn, fallback) { const v = this.get(key, fallback); const r = fn(v); const nuevo = r === undefined ? v : r; this.set(key, nuevo); return nuevo; },
  // Guarda ya todo lo pendiente (antes de recargar datos, cambiar de empresa o salir).
  // También las claves con un envío dudoso (falló sin respuesta): se comprueban y, si hace falta, se reenvían.
  guardarTodo(keepalive = false) {
    const claves = new Set([...Object.keys(_reg.timers), ...Object.keys(_reg.enCurso), ...Object.keys(_reg.incierto)]);
    return Promise.all([...claves].map(k => (_reg.timers[k] || !_reg.enCurso[k] ? _subir(k, keepalive) : _reg.enCurso[k]))).then(r => r.every(Boolean));
  },
  // ¿Se puede guardar desde esta pantalla? (registros cargados y la pantalla se montó con ellos). Las acciones que hacen algo
  // en el servidor antes de guardar (emitir la factura de compra, mover el banco) lo revisan ANTES, para no quedar a medias.
  puedeGuardar(avisar = true) {
    if (!_reg.cargado) { if (avisar) toast('No se puede guardar: los datos de la empresa no se pudieron cargar. Recargue la página.', 'err'); return false; }
    if (pantalla.sinDatos) { if (avisar) toast('Actualice la pantalla (botón arriba) antes de guardar.', 'err'); return false; }
    return true;
  },
  get pendientes() { return new Set([...Object.keys(_reg.timers), ...Object.keys(_reg.enCurso), ...Object.keys(_reg.incierto)]).size; },
  // Cambia al cargar otra empresa o cerrar sesión: una acción que esperó al servidor la compara para no escribir en otra empresa.
  get generacion() { return _reg.gen; },
  // Carga todos los registros de la empresa activa. Los que solo existían en este navegador (versiones anteriores) suben al
  // servidor una vez y se borran del navegador, para que no se mezclen con otra empresa.
  // Si ya hay una carga en curso para la misma empresa, se espera esa (no se empieza otra descarga completa).
  cargar(pre) {                          // pre: los registros que ya trajo /api/arranque (3.73)
    if (_reg.cargando && _reg.cargando.gen === _reg.gen) return _reg.cargando.p;
    const gen = ++_reg.gen;
    const p = this._cargar(gen, pre).finally(() => { if (_reg.cargando && _reg.cargando.p === p) _reg.cargando = null; });
    _reg.cargando = { gen, p };
    return p;
  },
  async _cargar(gen, pre) {
    let r;
    try { r = pre || await api('/api/registros?v=2'); }
    catch (e) { if (_reg.gen === gen) _reg.fallo = true; throw e; }
    if (_reg.gen !== gen) return;                // se cambió de empresa mientras tanto: esta carga ya no corresponde
    _reg.fallo = false;
    _reg.datos = (r && r.datos) || {}; _reg.ver = (r && r.versiones) || {}; _reg.base = _copia(_reg.datos); _reg.remaps = {}; _reg.vuelo = {}; _reg.conds = {};
    _reg.topes = (r && r.topes) || {}; _reg.rango = (r && +r.rango) || 0; _reg.incierto = {}; _reg.parciales = (r && r.parciales) || {};
    try {
      // Restos de versiones anteriores a 1.11 en este navegador: se descartan (ya no se sube nada desde localStorage a la
      // empresa que esté abierta: podía ser otra) (R68)
      for (const k of Object.keys(localStorage).filter(k => k.startsWith('mock:'))) localStorage.removeItem(k);
      for (const [key, txt] of []) {
        if (key in _reg.datos) continue;
        const v = JSON.parse(txt);
        if (v === null) continue;
        _reg.datos[key] = v; _reg.cargado = true;
        try { await _subirAhora(key, false); }
        catch (e) {
          if (_reg.gen !== gen) return;                                   // otra empresa: lo que falte no se le sube a ella
          if (e.status >= 400 && e.status < 500) {
            // rechazo definitivo (p. ej. un rol sin permiso): sin aviso, queda en este navegador para alguien con permiso
            delete _reg.datos[key]; try { localStorage.setItem('mock:' + key, txt); } catch {}
          } else if (!_reg.incierto[key]) {
            // sin respuesta: se reintenta desde la memoria con esperas crecientes (hasta 6 veces) y cuenta como pendiente,
            // así el navegador avisa antes de cerrar. Las listas ya quedan como dudosas y se reintentan solas.
            const reintentar = (espera, n) => {
              _reg.timers[key] = setTimeout(async () => {
                const ok = await _subir(key);
                if (!ok && n < 6 && _reg.gen === gen && !_reg.timers[key] && _reg.datos[key] !== undefined && !_igual(_reg.datos[key], _reg.base[key])) reintentar(Math.min(espera * 2, 60000), n + 1);
              }, espera);
            };
            reintentar(5000, 1);
          }
        }
        if (_reg.gen !== gen) return;
      }
    } catch {}
    _reg.cargado = true;
    monedas.refrescarSimbolos();
  },
  // Trae del servidor las claves que otro usuario cambió (o `claves`, si se indican) antes de mostrar una pantalla.
  // ctrl.cancelado (o un cambio de empresa) detiene el refresco: no se tocan los datos de una pantalla ya montada.
  // 4.8: devuelve la lista de lo aplicado, o false si no se pudo consultar todo (sin red, error del servidor); y queda anotado
  // mientras corre (refrescando / esperarRefrescos): app.js no monta una pantalla mientras un refresco anterior todavía puede escribir.
  refrescar(claves, ctrl) {
    const p = this._refrescar(claves, ctrl);
    _refrescosEnCurso.add(p);
    const fin = () => _refrescosEnCurso.delete(p);
    p.then(fin, fin);
    return p;
  },
  refrescando() { return _refrescosEnCurso.size > 0; },
  async esperarRefrescos() { while (_refrescosEnCurso.size) await Promise.allSettled([..._refrescosEnCurso]); },   // también los que empiecen mientras se espera
  nuevaPantalla() { _pantallaGen++; },
  async _refrescar(claves, ctrl) {
    if (!_reg.cargado) return false;
    const gen = _reg.gen, pg = _pantallaGen;
    const cortar = () => (ctrl && ctrl.cancelado) || _reg.gen !== gen || (_pantallaGen !== pg && !(ctrl && ctrl.sinCorte));
    let vers;
    try { vers = await api('/api/registros/versiones', { limite: 20000 }); } catch { return false; }   // 4.8: una petición colgada no deja el refresco abierto para siempre
    if (!vers || typeof vers !== 'object') return false;
    // un envío dudoso se comprueba (y reenvía si no llegó) aunque la clave no haya cambiado en el servidor
    for (const k of Object.keys(_reg.incierto)) {
      if (cortar()) return false;
      if ((!claves || claves.includes(k)) && !_reg.timers[k] && !_reg.enCurso[k]) await _subir(k);   // si no se puede subir, el refresco falla como antes (quien numera o aplica se detiene)
    }
    const cambiadas = Object.keys(vers).filter(k => (!claves || claves.includes(k)) && vers[k] !== _reg.ver[k]);
    // 4.8: de a 4 a la vez (antes una tras otra: con varias claves cambiadas, cada clic esperaba la suma de todas las descargas)
    const aplicadas = [], cola = cambiadas.slice();
    let fallo = false, errorSubir = null;
    const una = async (k) => {          // no lanza: un GET fallido deja `fallo`; un envío local que no se pudo subir detiene las demás descargas y el refresco lanza al final (como antes)
      if (_reg.timers[k] || _reg.enCurso[k] || _reg.incierto[k]) { try { await _subir(k); } catch (e) { errorSubir = errorSubir || e; return; } }
      const base0 = _reg.base[k];   // 4.6: todo envío confirmado reasigna la base; si cambió mientras el GET iba en vuelo, la respuesta ya es vieja
      try {
        const r = await api('/api/registros/' + encodeURIComponent(k), { limite: 30000 });
        if (cortar()) return;
        if (_reg.timers[k] || _reg.enCurso[k] || _reg.incierto[k] || _reg.base[k] !== base0) return;    // el usuario lo cambió mientras tanto (o falta confirmar un envío): después
        _reg.datos[k] = r.datos; _reg.base[k] = _copia(r.datos); _reg.ver[k] = r.version;
        if (r.ultimo_id) _reg.topes[k] = +r.ultimo_id;
        delete _reg.remaps[k];             // con los datos frescos, un id que se reasignó antes puede ser ya de otro usuario
        aplicadas.push(k);
      } catch { fallo = true; }
    };
    await Promise.all(Array.from({ length: Math.min(4, cola.length) }, async () => { while (cola.length && !cortar() && !errorSubir) await una(cola.shift()); }));
    if (errorSubir) throw errorSubir;
    if (cortar()) return false;
    if (cambiadas.includes('monedas')) monedas.refrescarSimbolos();
    return fallo ? false : aplicadas;
  },
  // Una colección que llegó recortada al entrar (ventas de caja viejas, 3.73): la pantalla que necesita el historial completo la
  // pide aquí antes de calcular. No pisa cambios locales que estén sin subir (primero se suben; si no se puede, queda como está).
  parcial(key) { return !!(_reg.parciales && _reg.parciales[key]); },
  async completar(key) {
    if (!_reg.cargado || !this.parcial(key)) return false;
    const gen = _reg.gen;
    if (_reg.timers[key] || _reg.enCurso[key] || _reg.incierto[key]) { try { await _subir(key); } catch {} }
    if (_reg.gen !== gen) return false;
    try {
      const r = await api('/api/registros/' + encodeURIComponent(key));
      if (_reg.gen !== gen || _reg.timers[key] || _reg.enCurso[key] || _reg.incierto[key] || !_igual(_reg.datos[key], _reg.base[key])) return false;
      _reg.datos[key] = r.datos; _reg.base[key] = _copia(r.datos); _reg.ver[key] = r.version;
      if (r.ultimo_id) _reg.topes[key] = Math.max(+_reg.topes[key] || 0, +r.ultimo_id);
      delete _reg.parciales[key];
      return true;
    } catch { return false; }
  },
  // Antes de limpiar (cambio de empresa o cierre de sesión) se guarda lo pendiente.
  async descargar(guardar = true) {
    if (_reg.cargado && guardar) { try { await this.guardarTodo(); } catch {} }
    _reg.gen++; _reg.datos = {}; _reg.base = {}; _reg.ver = {}; _reg.remaps = {}; _reg.vuelo = {}; _reg.conds = {}; _reg.incierto = {}; _reg.topes = {}; _reg.parciales = {}; _reg.cargado = false; _reg.fallo = false; _reg.cargando = null; _tcDia = null;
    for (const t of Object.values(_reg.timers)) clearTimeout(t);
    _reg.timers = {}; _reg.esperas = {};
  },
  get cargado() { return _reg.cargado; },
  // id para un elemento nuevo: por encima de la lista y del mayor id que tuvo la clave en el servidor (no reutiliza uno
  // borrado: una pantalla vieja que edite el borrado no pisa el nuevo). Indique la clave siempre que la lista se guarde.
  nextId(list, key) { return _maxPropio(list, key) + 1; },
  // 4.29: fn(clave, {id_viejo: id_nuevo}) cada vez que aquí cambia el id de un elemento ya guardado; devuelve cómo dejar de escuchar
  alCambiarIds(fn) { _alCambiarIds.add(fn); return () => _alCambiarIds.delete(fn); },
  /* 4.31: la baja del elemento `id` de la lista `key` viaja con esta condición (la caja: lo que cobró o quitó de la cuenta). No sube nada */
  /* por sí sola: va con el próximo envío que lleve esa baja; si el envío falla, se reenvía con él. */
  condicionBaja(key, id, cond) { (_reg.conds[key] = _reg.conds[key] || {})[String(id)] = cond; },
  /* 4.31: el elemento `id` de la lista `key` ya quedó guardado en el servidor (está en lo confirmado; un alta todavía en camino, no) */
  confirmado(key, id) { const b = _reg.base[key]; return Array.isArray(b) && b.some(x => _esObj(x) && String(x.id) === String(id)); },
  /* 4.31 (sexta vuelta): una copia del elemento `id` de la lista `key` como está en lo confirmado (lo último que se sabe del servidor); null si no está */
  confirmadoDe(key, id) { const b = _reg.base[key], x = Array.isArray(b) ? b.find(y => _esObj(y) && String(y.id) === String(id)) : null; return x ? JSON.parse(JSON.stringify(x)) : null; },
  /* 4.31: la copia de `key` es lo que tenía el servidor en la última consulta: nada pendiente de subir y la versión conocida */
  alDia(key) { return !_reg.timers[key] && !_reg.enCurso[key] && !_reg.incierto[key] && _reg.ver[key] !== null && _reg.ver[key] !== undefined && _igual(_reg.datos[key], _reg.base[key]); },
  // Lista con semilla de ejemplo. Demo: devuelve lo guardado o la semilla (y la persiste). Producción: devuelve solo lo que
  // creó el usuario y borra las filas de ejemplo que hubieran quedado guardadas (mismo id y mismo valor en `campo`).
  // Lista con semilla de ejemplo. Demo: devuelve lo guardado o la semilla (y la persiste, marcada con ejemplo: true).
  // Producción: devuelve lo guardado tal cual y solo quita las filas MARCADAS como ejemplo (las que guardó una demo). Antes se
  // tomaba por ejemplo cualquier fila con el mismo id y nombre que la semilla, y como los ids reales también empiezan en 1,
  // desaparecían registros reales (la variante 'Color', la categoría 'Abarrotes', la cuenta 'Caja general'…).
  ejemplos(key, semilla, campo = 'nombre') {
    const guardado = this.get(key, null);
    if (demo.activo) {
      if (Array.isArray(guardado)) return guardado;
      const marcada = semilla.map(s => ({ ...s, ejemplo: true })); this.set(key, marcada); return marcada;
    }
    if (!Array.isArray(guardado)) return [];
    // Versiones anteriores guardaban la semilla sin marca: solo se quita una fila si es idéntica a la semilla campo por campo
    // (una fila real con el mismo id y nombre, pero cualquier otro dato distinto, se conserva).
    const canon = v => Array.isArray(v) ? '[' + v.map(canon).join(',') + ']' : (v && typeof v === 'object') ? '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}' : JSON.stringify(v ?? null);
    const firmas = new Set((semilla || []).map(canon));
    const limpio = guardado.filter(r => !(r && (r.ejemplo === true || firmas.has(canon(r)))));
    if (limpio.length !== guardado.length) this.set(key, limpio);
    return limpio;
  },
};
// Al cerrar o recargar la pestaña, lo pendiente se envía ya (keepalive, sin esperar la fila de la clave); si quedara algo
// pendiente, el navegador pregunta antes de salir.
try {
  window.addEventListener('pagehide', () => {
    if (!_reg.cargado) return;
    // también las claves en fila detrás de un envío (ya sin timer): se manda solo lo que ese envío no lleva
    const claves = new Set([...Object.keys(_reg.timers), ...Object.keys(_reg.enCurso), ...Object.keys(_reg.incierto)]);
    for (const k of claves) { clearTimeout(_reg.timers[k]); delete _reg.timers[k]; _subirAhora(k, true, true).catch(() => {}); }
  });
  window.addEventListener('beforeunload', e => { if (_reg.cargado && mock.pendientes) { e.preventDefault(); e.returnValue = ''; } });
} catch {}

// ---- monedas: CRC y USD precargadas; el usuario puede agregar más (Configuración › Monedas) ----
const MONEDAS_BASE = [
  { codigo: 'CRC', nombre: 'Colón costarricense', simbolo: '₡', principal: true, tipo_cambio: 1 },
  { codigo: 'USD', nombre: 'Dólar estadounidense', simbolo: '$', principal: false, tipo_cambio: 510 },
];
let _tcVenta = null;   // venta BCCR del día sin margen (R75)
let _tcDia = null;            // USD del día (BCCR + margen), en memoria
export const monedas = {
  list() {
    const g = mock.get('monedas', null), l = g && g.length ? g : MONEDAS_BASE;
    // tipo_cambio = colones por 1 unidad de la moneda (Hacienda lo exige así en el comprobante): el CRC siempre vale 1 y el
    // USD toma el del día aunque el dólar sea la moneda principal (antes quedaba en 1 y las facturas en USD salían con TipoCambio 1)
    // un USD marcado como fijo (editado a mano en Configuración › Monedas) no se reemplaza por el del día (R204)
    return l.map(m => (m.codigo === 'CRC' ? { ...m, tipo_cambio: 1 } : (m.codigo === 'USD' && _tcDia && !m.fijo ? { ...m, tipo_cambio: _tcDia } : m)));
  },
  principal() { return this.list().find(m => m.principal) || this.list()[0]; },
  get(codigo) { return this.list().find(m => m.codigo === codigo); },
  // Tipo de cambio para un COMPROBANTE (va a Hacienda): colones por 1 unidad de `codigo` (1 para CRC). Para el USD es la venta
  // del BCCR del día SIN margen (Hacienda y TRIBU-CR convierten con ese valor; con el margen las ventas y el IVA en colones
  // quedaban inflados ~5 %) (R75). El margen de protección queda para precios, cotizaciones y órdenes: tcPrecio().
  tc(codigo) { return codigo === 'CRC' ? 1 : (codigo === 'USD' && _tcVenta ? _tcVenta : (+this.get(codigo)?.tipo_cambio || 1)); },
  tcPrecio(codigo) { return codigo === 'CRC' ? 1 : (+this.get(codigo)?.tipo_cambio || 1); },
  fijarVentaBCCR(valor) { if (+valor > 0) _tcVenta = +valor; },
  save(list) {
    // un USD editado a mano rige desde ya (antes el del día lo tapaba hasta el siguiente inicio de sesión); si el servidor
    // no acepta el guardado (rol sin permiso), vuelve el que había
    const u = list.find(m => m.codigo === 'USD'), antes = _tcDia;
    if (_tcDia && u && +u.tipo_cambio > 0) _tcDia = +u.tipo_cambio;
    const puesto = _tcDia;
    mock.set('monedas', list).then(ok => { if (!ok && _tcDia === puesto) _tcDia = antes; });
    for (const m of list) SIM[m.codigo] = m.simbolo || m.codigo + ' ';
  },
  add(m) { const l = this.list().slice(); if (!l.some(x => x.codigo === m.codigo)) l.push({ principal: false, tipo_cambio: 1, ...m }); this.save(l); return l; },
  // Tipo de cambio del USD = venta BCCR del día + margen de protección (GET /api/tipo-cambio al entrar). Se aplica en memoria
  // para todos los roles; solo quien puede configurar lo guarda (antes un 403 devolvía el valor viejo a Vendedor y Contador).
  actualizarUSD(valor, persistir = true) {   // valor = venta BCCR + margen (precios)
    if (!(+valor > 0)) return; _tcDia = +valor;
    if (!persistir) return;
    const g = mock.get('monedas', null); const l = (g && g.length ? g : MONEDAS_BASE).map(m => ({ ...m }));
    const u = l.find(m => m.codigo === 'USD'); if (u && !u.fijo && u.tipo_cambio !== +valor) { u.tipo_cambio = +valor; this.save(l); }
  },
  desfijarUSD() { const g = mock.get('monedas', null); if (!g || !g.some(m => m.codigo === 'USD' && m.fijo)) return; this.save(g.map(m => (m.codigo === 'USD' ? { ...m, fijo: false } : m))); },   // vuelve al tipo de cambio del día (R204)
  remove(codigo) { if (['CRC', 'USD'].includes(codigo)) return this.list(); const l = this.list().filter(m => m.codigo !== codigo); this.save(l); return l; },
  setPrincipal(codigo) { const l = this.list().map(m => ({ ...m, principal: m.codigo === codigo })); this.save(l); return l; },
  opciones() { return this.list().map(m => ({ value: m.codigo, label: `${m.codigo} - ${m.nombre}` })); },
  refrescarSimbolos() { for (const m of this.list()) SIM[m.codigo] = m.simbolo || m.codigo + ' '; },
};
for (const m of monedas.list()) SIM[m.codigo] = m.simbolo || m.codigo + ' ';

// Catálogos de Hacienda
export const CAT = {
  tipoId: { '01': 'Cédula física', '02': 'Cédula jurídica', '03': 'DIMEX', '04': 'NITE', '05': 'Extranjero no domiciliado', '06': 'No contribuyente' },
  condicionVenta: { '01': 'Contado', '02': 'Crédito', '03': 'Consignación', '04': 'Apartado', '05': 'Arrendamiento con opción de compra', '06': 'Arrendamiento en función financiera', '07': 'Cobro a favor de un tercero', '08': 'Servicios prestados al Estado', '09': 'Pago de servicios prestados al Estado', '10': 'Venta a crédito hasta 90 días', '11': 'Pago de venta a crédito en IVA hasta 90 días', '99': 'Otros', '12': 'Venta de mercancía no nacionalizada', '13': 'Venta de bienes usados no contribuyente', '14': 'Arrendamiento con opción de compra (bienes usados)', '15': 'Arrendamiento en función financiera (bienes usados)' },
  // Condiciones de venta que admite el XSD de cada tipo (R74): 09 y 11 no existen en FE/TE/FEE/FEC; 12 a 15 sí. El tiquete sin 10 (no tiene REP).
  condicionVentaPorTipo: {"01": ["01", "02", "03", "04", "05", "06", "07", "08", "10", "12", "13", "14", "15", "99"], "04": ["01", "02", "03", "04", "05", "06", "07", "08", "13", "14", "15", "99"], "09": ["01", "02", "03", "04", "05", "06", "07", "08", "10", "13", "14", "15", "99"], "08": ["01", "02", "03", "04", "05", "06", "07", "08", "10", "13", "14", "15", "99"], "03": ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "99"], "02": ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "99"]},
  // lista ordenada [{value,label}] (un objeto reordenaría las claves numéricas: 10, 12… antes que 01)
  condicionVentaDe(tipo) { const l = this.condicionVentaPorTipo[tipo] || this.condicionVentaPorTipo['01']; return l.filter(k => this.condicionVenta[k]).map(k => ({ value: k, label: this.condicionVenta[k] })); },
  medioPago: { '01': 'Efectivo', '02': 'Tarjeta', '03': 'Cheque', '04': 'Transferencia / depósito', '05': 'Recaudado por terceros', '06': 'SINPE Móvil', '07': 'Plataforma digital', '99': 'Otros' },
  // lista ordenada para selectores (un objeto reordena las claves numéricas: 10 y 11 salían antes que 08)
  get tarifaIvaLista() { return ['08', '04', '03', '02', '09', '07', '01', '10', '11'].filter(k => this.tarifaIva[k]).map(k => ({ value: k, label: this.tarifaIva[k] })); },
  tarifaIva: { '08': '13 % general', '04': '4 % reducida', '03': '2 % reducida', '02': '1 % reducida', '09': '0,5 % reducida', '07': '8 % transitoria', '01': '0 %', '10': 'Exento', '11': '0 % sin derecho a crédito' },
  tarifaPct: { '08': 13, '04': 4, '03': 2, '02': 1, '09': 0.5, '07': 8, '01': 0, '10': 0, '11': 0 },
  tipoDoc: { '01': 'Factura electrónica', '02': 'Nota de débito', '03': 'Nota de crédito', '04': 'Tiquete electrónico', '08': 'Factura de compra', '09': 'Factura de exportación', '10': 'Recibo electrónico de pago' },
  // Códigos de referencia del XSD v4.4 (CodigoReferenciaType). El '03 Corrige monto' de la v4.3 ya no existe. Con '99' Hacienda exige describirlo.
  codigoRef: { '01': 'Anula documento de referencia', '02': 'Corrige texto del documento de referencia', '04': 'Referencia a otro documento', '05': 'Sustituye comprobante provisional por contingencia', '06': 'Devolución de mercancía', '07': 'Sustituye comprobante electrónico', '08': 'Factura endosada', '09': 'Nota de crédito financiera', '10': 'Nota de débito financiera', '11': 'Proveedor no domiciliado', '12': 'Crédito por exoneración posterior a la facturación', '13': 'Anula documento de referencia por error material', '14': 'Corrige monto por error material', '15': 'Sustituye comprobante electrónico por error material', '16': 'Sustituye comprobante electrónico rechazado', '99': 'Otros' },
  // Unidades de medida del catálogo oficial (UnidadMedidaType del esquema v4.4): las de uso común primero y el resto después.
  // Hacienda distingue mayúsculas: 'G' gramo, 'M' metro, 'D' día (con 'g', 'm' y 'd' el comprobante no pasaba el esquema).
  unidades: ["Unid", "Sp", "St", "Os", "Spe", "Kg", "G", "L", "mL", "M", "cm", "Mm", "Km", "m²", "m³", "h", "Min", "D", "Gal", "Oz", "Cm", "Otros", "1", "´", "´´", "°C", "1/m", "A", "A/m", "A/m²", "Acv", "Al", "Alc", "B", "Bq", "C", "C/kg", "C/m²", "C/m³", "Cc", "Cd", "cd/m²", "Cu", "eV", "F", "F/m", "Fa", "Gy", "Gy/s", "H", "H/m", "Hz", "I", "J", "J/(kg·K)", "J/(mol·K)", "J/K", "J/kg", "J/m³", "J/mol", "K", "Kat", "kat/m³", "kg/m³", "Kw", "kWh", "Lm", "Ln", "Lx", "m/s", "m/s²", "Mol", "mol/m³", "N", "N/m", "N·m", "Np", "º", "Pa", "Pa·s", "Qq", "Rad", "rad/s", "rad/s²", "S", "s", "Sr", "Sv", "t", "T", "U", "Ua", "V", "V/m", "W", "W/(m·K)", "W/(m²·sr)", "W/m²", "W/sr", "Wb", "Ω"],
  unidadesNombre: { Unid: 'Unidad', Sp: 'Servicios profesionales', St: 'Servicios técnicos', Os: 'Otro tipo de servicio', Spe: 'Servicios personales', Kg: 'Kilogramo', G: 'Gramo', L: 'Litro', mL: 'Mililitro', M: 'Metro', cm: 'Centímetro', Mm: 'Milímetro', Km: 'Kilómetro', 'm²': 'Metro cuadrado', 'm³': 'Metro cúbico', h: 'Hora', Min: 'Minuto', D: 'Día', Gal: 'Galón', Oz: 'Onza', Cm: 'Comisiones', Otros: 'Otros' },
  provincias: { 1: 'San José', 2: 'Alajuela', 3: 'Cartago', 4: 'Heredia', 5: 'Guanacaste', 6: 'Puntarenas', 7: 'Limón' },
  terminosPago: [{ nombre: 'De contado', dias: 0 }, { nombre: '8 días', dias: 8 }, { nombre: '15 días', dias: 15 }, { nombre: '30 días', dias: 30 }, { nombre: '60 días', dias: 60 }],
};
export const opts = (obj) => Object.entries(obj).map(([value, label]) => ({ value, label }));

// ---- 3.41: Selectivo de Consumo e impuestos específicos (las mismas fórmulas que app/fe/calculo.py) ----
export const OTROS_IMP = { '02': 'Selectivo de consumo', '03': 'Imp. combustibles', '04': 'Imp. bebidas alcohólicas', '05': 'Imp. bebidas y jabones', '06': 'Imp. tabaco', '12': 'Imp. cemento' };
const _EN_BASE_IVA = ['02', '04', '05', '12'];         // los que el Anexo suma a la base del IVA
export function otroImp(v) {
  if (!v) return null;
  if (typeof v === 'string') { try { v = JSON.parse(v); } catch { return null; } }
  return v && typeof v === 'object' && v.codigo ? v : null;
}
// impuesto de la línea: el que trae la línea ({} = ninguno) o, si no trae, el del ítem
export function otroImpDe(l, productos) {
  if (l && l.otro_impuesto !== undefined && l.otro_impuesto !== null) return otroImp(l.otro_impuesto);
  const p = l && l.producto_id ? (productos || []).find(x => x.id == l.producto_id) : null;
  return p ? otroImp(p.otro_impuesto) : null;
}
// {monto, base}: monto del impuesto y la parte que se suma a la base del IVA. tc: colones por unidad de la moneda del documento
// (los montos fijos que fija Hacienda son en colones; en dólares se dividen entre el tipo de cambio, como en el servidor)
export function otroImpLinea(v, cantidad, subtotal, tc = 1) {
  const o = otroImp(v); if (!o) return { monto: 0, base: 0 };
  const div = +tc > 0 ? +tc : 1, fijo = k => Math.round((+o[k] || 0) / div * 100000) / 100000;
  const q = +cantidad || 0, n = k => (k === 'monto_unidad' || k === 'impuesto_unidad' ? fijo(k) : +o[k] || 0), r2 = x => Math.round(x * 100) / 100, r5 = x => Math.round(x * 100000) / 100000;
  let m = 0;
  if (o.codigo === '02') m = o.monto_unidad !== undefined && o.monto_unidad !== null && o.monto_unidad !== '' ? q * n('monto_unidad') : (+subtotal || 0) * n('tarifa') / 100;
  else if (o.codigo === '12') m = (+subtotal || 0) * 5 / 100;
  else if (o.codigo === '03') m = r2(q * n('cantidad_unidad')) * n('impuesto_unidad');
  else if (o.codigo === '04') m = q * r5(r2(n('cantidad_unidad')) * n('porcentaje') / 100) * n('impuesto_unidad');
  else if (o.codigo === '05') m = o.jabon ? q * r2(n('volumen_unidad')) * n('impuesto_unidad') : q * r2(n('cantidad_unidad')) * n('impuesto_unidad') / (r2(n('volumen_unidad')) || 1);
  else if (o.codigo === '06') m = q * r2(n('cantidad_unidad')) * n('impuesto_unidad');
  m = r5(m);
  return { monto: m, base: _EN_BASE_IVA.includes(o.codigo) ? m : 0 };
}
export function otroImpTexto(v) {
  const o = otroImp(v); if (!o) return '';
  const f = x => (+x || 0).toLocaleString('es-CR', { maximumFractionDigits: 5 });
  if (o.codigo === '02') return 'Selectivo de consumo ' + (o.monto_unidad !== undefined && o.monto_unidad !== null ? f(o.monto_unidad) + ' por unidad' : f(o.tarifa) + ' %');
  if (o.codigo === '04') return 'Bebidas alcohólicas · ' + f(o.cantidad_unidad) + ' ml al ' + f(o.porcentaje) + ' %';
  if (o.codigo === '05') return o.jabon ? 'Jabón de tocador · ' + f(o.volumen_unidad) + ' g' : 'Bebida sin alcohol · ' + f(o.cantidad_unidad) + ' ml';
  if (o.codigo === '06') return 'Tabaco · ' + f(o.cantidad_unidad) + ' unidades';
  if (o.codigo === '03') return 'Combustible · ' + f(o.cantidad_unidad) + ' L';
  if (o.codigo === '12') return 'Cemento 5 %';
  return OTROS_IMP[o.codigo] || '';
}
