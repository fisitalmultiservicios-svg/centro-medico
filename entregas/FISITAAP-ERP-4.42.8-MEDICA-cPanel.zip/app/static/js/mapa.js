// Mapa incrustado (3.48): OpenStreetMap con Leaflet servido desde el propio sistema (sin clave ni cobro por uso). Carga la
// librería una sola vez (hoja de estilo + script) y devuelve el objeto global L. Lo usan el catálogo público, el panel del
// motorizado y las pantallas de Entregas.
let _promesa = null;
export const CR = { lat: 9.9281, lng: -84.0907 };   // centro por defecto: San José
// Centro de cada provincia (3.58): el mapa de zonas arranca en la provincia de la empresa en vez de en todo el país
export const CENTRO_PROVINCIA = { 1: { lat: 9.9281, lng: -84.0907, zoom: 11 }, 2: { lat: 10.0162, lng: -84.2116, zoom: 11 }, 3: { lat: 9.8644, lng: -83.9194, zoom: 11 }, 4: { lat: 9.9981, lng: -84.1170, zoom: 11 },
                                  5: { lat: 10.6346, lng: -85.4406, zoom: 11 }, 6: { lat: 9.9763, lng: -84.8384, zoom: 11 }, 7: { lat: 9.9907, lng: -83.0360, zoom: 11 } };
export function centroEmpresa(empresa) { const c = CENTRO_PROVINCIA[+((empresa || {}).provincia || 0)]; return c ? { ...c } : { ...CR, zoom: 8 }; }
export const TILES = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
export const ATRIBUCION = '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';

export function cargarLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (_promesa) return _promesa;
  _promesa = new Promise((resolve, reject) => {
    if (!document.querySelector('link[data-leaflet]')) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = '/js/vendor/leaflet/leaflet.css'; l.dataset.leaflet = '1'; document.head.appendChild(l); }
    const s = document.createElement('script'); s.src = '/js/vendor/leaflet/leaflet.js'; s.async = true;
    s.onload = () => { if (window.L) { window.L.Icon.Default.imagePath = '/js/vendor/leaflet/images/'; resolve(window.L); } else reject(new Error('El mapa no cargó')); };
    s.onerror = () => reject(new Error('No se pudo cargar el mapa')); document.head.appendChild(s);
  });
  return _promesa;
}

// Crea el mapa en el elemento indicado con la capa de OpenStreetMap
export async function crearMapa(el, centro, zoom = 14, opciones = {}) {
  const L = await cargarLeaflet();
  const m = L.map(el, { zoomControl: true, attributionControl: true, ...opciones }).setView([centro.lat || CR.lat, centro.lng || CR.lng], zoom);
  L.tileLayer(TILES, { maxZoom: 19, attribution: ATRIBUCION }).addTo(m);
  return m;
}

export function kmEntre(a, b) {
  const R = 6371, r = x => x * Math.PI / 180, dp = r(b.lat - a.lat), dl = r(b.lng - a.lng);
  const h = Math.sin(dp / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

// La zona (círculo) más pequeña que contiene el punto, como lo calcula el servidor
export function zonaPara(zonas, p) { const dentro = (zonas || []).filter(z => kmEntre({ lat: +z.lat, lng: +z.lng }, p) <= +z.radio_km); return dentro.sort((a, b) => (+a.radio_km - +b.radio_km) || (+a.precio - +b.precio))[0] || null; }

// Posición del navegador (celular) o null si no se concede
export function miPosicion(timeout = 8000) {
  return new Promise(resolve => { if (!navigator.geolocation) return resolve(null); navigator.geolocation.getCurrentPosition(p => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }), () => resolve(null), { enableHighAccuracy: true, timeout, maximumAge: 30000 }); });
}
