// Portal de soporte TiKe (3.52): página /soporte/<empresa> sin sesión del sistema. Dos entradas: el enlace con token que llega en cada
// correo (ver y responder un ticket) y el acceso con correo + clave (todos los tickets del cliente, abrir tickets nuevos).
import { createApp } from '/js/vendor/vue.esm-browser.prod.min.js';

const SLUG = document.getElementById('app').dataset.slug;
const KEY = 'tike:portal:' + SLUG;
const ESTADOS_CLASE = { nuevo: 'warn', asignado: 'info', en_proceso: 'info', espera_cliente: 'danger', resuelto: 'ok', cerrado: '' };

function fecha(iso) { if (!iso) return ''; const d = new Date(iso); return d.toLocaleDateString('es-CR', { day: 'numeric', month: 'short' }) + ', ' + d.toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }); }

createApp({
  data() {
    let g = {}; try { g = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch {}
    const h = new URLSearchParams(location.hash.replace(/^#/, ''));
    // 3.58: el enlace «Ayuda y soporte» de la aplicación llega con ?correo= y &empresa=: se prellenan el correo y la empresa del ticket
    const q = new URLSearchParams(location.search || '');
    return { d: null, error: '', msg: '', vista: 'inicio', acceso: g.acceso || null, tokenTicket: h.get('t') || null, modoToken: false, tickets: [], t: null, cargando: false,
             desdeApp: { correo: (q.get('correo') || '').trim(), empresa: (q.get('empresa') || '').trim() },
             login: { correo: (q.get('correo') || '').trim() || g.correo || '', clave: '' }, docs: null, docAbierto: null, nuevo: { asunto: '', descripcion: '', categoria: '', prioridad: 'media', telefono: '' }, respuesta: '', calif: { puntos: 0, comentario: '' }, claves: { actual: '', nueva: '', repetir: '' }, enviando: false };
  },
  computed: {
    abiertos() { return this.tickets.filter(t => t.abierto); },
    cerrados() { return this.tickets.filter(t => !t.abierto); },
    entradas() { return this.t ? this.t.entradas.slice().reverse() : []; },
  },
  methods: {
    fecha, claseEstado(e) { return ESTADOS_CLASE[e] || ''; },
    async api(url, body, method) {
      const h = { 'Content-Type': 'application/json' }; if (this.acceso && this.acceso.token) h['X-Portal'] = this.acceso.token;
      const r = await fetch(url, { method: method || (body ? 'POST' : 'GET'), headers: h, body: body ? JSON.stringify(body) : undefined });
      let j = null; try { j = await r.json(); } catch {}
      if (r.status === 401 && this.acceso) { this.acceso = null; this.guardar(); }
      // 3.87: con la clave temporal el servidor solo deja cambiarla; se vuelve a «Elija su clave» (también al recargar). Sin mensaje rojo:
      // esa vista ya explica que la clave es temporal
      if (r.status === 403 && this.acceso && j && j.detail && j.detail.codigo === 'cambiar_clave') { this.acceso.debe_cambiar = true; this.guardar(); this.vista = 'clave'; throw new Error(''); }
      if (!r.ok) { const d = j && j.detail; throw new Error(typeof d === 'string' ? d : (d && d.mensaje) || (Array.isArray(d) && d[0] && d[0].msg) || 'No se pudo completar (' + r.status + ')'); }
      return j;
    },
    guardar() { try { localStorage.setItem(KEY, JSON.stringify({ acceso: this.acceso, correo: this.login.correo })); } catch {} },
    aviso(t) { this.msg = t; clearTimeout(this._m); this._m = setTimeout(() => { this.msg = ''; }, 2500); },
    async cargar() {
      try { this.d = await this.api('/api/soporte/' + SLUG); document.title = this.d.titulo; } catch (e) { this.error = e.message; return; }
      if (this.tokenTicket) return this.verToken(this.tokenTicket);
      // 3.87: con un acceso guardado se pregunta siempre al servidor: si la clave sigue siendo temporal responde «cambiar_clave» y api()
      // lleva a «Elija su clave» (recargar ya no salta el cambio, y una marca vieja guardada en este navegador no lo pide de más)
      if (this.acceso) return this.misTickets();
    },
    // 3.87: el texto del documento se arma aquí y no en la plantilla: dentro del template literal, '\n' llegaba a Vue como un salto
    // real dentro de la cadena, la plantilla no compilaba y el portal entero (también el enlace de los correos) quedaba en blanco
    textoDoc(d) { const x = d.datos || {}; return x.contenido || Object.entries(x).filter(([k, v]) => v).map(([k, v]) => k.replace('_', ' ') + ': ' + v).join('\n'); },
    async entrar() {
      this.error = ''; if (!this.login.correo.includes('@') || !this.login.clave) return (this.error = 'Escriba su correo y su clave');
      try { const r = await this.api('/api/soporte/' + SLUG + '/acceso', { correo: this.login.correo.trim(), clave: this.login.clave }); this.acceso = r; this.login.clave = ''; this.guardar(); if (r.debe_cambiar) { this.vista = 'clave'; } else this.misTickets(); }
      catch (e) { this.error = e.message; }
    },
    salir() { this.acceso = null; this.tickets = []; this.t = null; this.guardar(); this.vista = 'inicio'; },
    async cambiarClave() {
      this.error = ''; const c = this.claves; if (c.nueva.length < 8) return (this.error = 'La clave nueva debe tener al menos 8 caracteres'); if (c.nueva !== c.repetir) return (this.error = 'Las claves no coinciden');
      try { await this.api('/api/soporte/' + SLUG + '/clave', { clave_actual: c.actual, clave_nueva: c.nueva }); this.acceso.debe_cambiar = false; this.guardar(); this.claves = { actual: '', nueva: '', repetir: '' }; this.aviso('Clave cambiada'); this.misTickets(); }
      catch (e) { this.error = e.message; }
    },
    async misTickets() {
      // 3.87: si este navegador recuerda una clave temporal se muestra «Elija su clave» mientras el servidor confirma; si responde con los
      // tickets, la marca era vieja (la cambió en otro equipo) y se borra. Si la sesión venció (401), se vuelve a «Entrar».
      const dudosa = !!(this.acceso && this.acceso.debe_cambiar);
      this.vista = dudosa ? 'clave' : 'lista'; this.cargando = true; this.error = '';
      try { this.tickets = await this.api('/api/soporte/' + SLUG + '/tickets'); if (dudosa) { this.acceso.debe_cambiar = false; this.guardar(); this.vista = 'lista'; } }
      catch (e) { this.error = e.message; if (!this.acceso) this.vista = 'inicio'; }
      this.cargando = false;
    },
    async verDocs() { this.vista = 'docs'; this.error = ''; try { this.docs = await this.api('/api/soporte/' + SLUG + '/docs'); } catch (e) { this.error = e.message; } },
    async ver(t) { this.error = ''; try { this.t = await this.api('/api/soporte/' + SLUG + '/tickets/' + t.id); this.modoToken = false; this.vista = 'ticket'; this.calif = { puntos: 0, comentario: '' }; window.scrollTo(0, 0); } catch (e) { this.error = e.message; } },
    async verToken(tok) { this.vista = 'ticket'; this.error = ''; try { this.t = await this.api('/api/soporte/' + SLUG + '/t/' + tok); this.modoToken = true; this.calif = { puntos: 0, comentario: '' }; } catch (e) { this.error = e.message; this.t = null; } },
    rutaTicket(sufijo) { return this.modoToken ? '/api/soporte/' + SLUG + '/t/' + this.tokenTicket + sufijo : '/api/soporte/' + SLUG + '/tickets/' + this.t.id + sufijo; },
    async responder() {
      if (!this.respuesta.trim()) return; this.enviando = true; this.error = '';
      try { this.t = await this.api(this.rutaTicket('/responder'), { texto: this.respuesta.trim() }); this.respuesta = ''; this.aviso('Respuesta enviada'); } catch (e) { this.error = e.message; }
      this.enviando = false;
    },
    async calificar() {
      if (!this.calif.puntos) return (this.error = 'Elija las estrellas'); this.enviando = true; this.error = '';
      try { this.t = await this.api(this.rutaTicket('/calificar'), { puntos: this.calif.puntos, comentario: this.calif.comentario }); this.aviso('¡Gracias por calificar!'); } catch (e) { this.error = e.message; }
      this.enviando = false;
    },
    abrirNuevo() { this.vista = 'nuevo'; this.error = ''; this.nuevo = { asunto: '', descripcion: this.desdeApp.empresa ? 'Empresa: ' + this.desdeApp.empresa + '\n' : '', categoria: (this.d.categorias || [])[0] || '', prioridad: 'media', telefono: '' }; },
    async crear() {
      const n = this.nuevo; this.error = ''; if (n.asunto.trim().length < 3) return (this.error = 'Escriba el asunto'); if (n.descripcion.trim().length < 3) return (this.error = 'Cuéntenos qué pasa');
      this.enviando = true;
      try { const t = await this.api('/api/soporte/' + SLUG + '/tickets', { asunto: n.asunto.trim(), descripcion: n.descripcion.trim(), categoria: n.categoria, prioridad: n.prioridad, telefono: n.telefono }); this.aviso('Ticket ' + t.codigo + ' abierto'); await this.misTickets(); this.ver(t); }
      catch (e) { this.error = e.message; }
      this.enviando = false;
    },
    volver() { this.t = null; this.error = ''; if (this.acceso) this.misTickets(); else this.vista = 'inicio'; },
  },
  mounted() { this.cargar(); },
  template: `
  <div v-if="d">
    <div class="sp-top"><h1>{{d.titulo}}</h1><p>{{d.texto || 'Abra un ticket y siga su atención desde aquí.'}}</p></div>
    <div class="msg ok" v-if="msg" style="margin:10px 16px 0">{{msg}}</div>

    <!-- inicio: entrar -->
    <template v-if="vista==='inicio'">
      <div class="sp-card"><h2 style="margin:0 0 8px;font-size:17px">Entrar</h2>
        <p class="s" style="font-size:13px;color:var(--muted);margin:0 0 8px" v-if="desdeApp.empresa">Soporte para <b>{{desdeApp.empresa}}</b>{{desdeApp.correo ? ' · ' + desdeApp.correo : ''}}. Entre con su clave del portal; si no la tiene, pídala a {{d.empresa}}{{d.correo ? ' (' + d.correo + ')' : ''}}{{d.whatsapp ? ' o por WhatsApp al ' + d.whatsapp : ''}}.</p>
        <label class="f">Correo</label><input class="sp" type="email" v-model="login.correo" placeholder="su@correo.com" @keyup.enter="entrar">
        <label class="f">Clave</label><input class="sp" type="password" v-model="login.clave" @keyup.enter="entrar">
        <div class="msg err" v-if="error">{{error}}</div>
        <button class="btn" style="width:100%;margin-top:12px" @click="entrar">Entrar</button>
        <p class="s" style="font-size:13px;color:var(--muted);margin:10px 0 0">¿Sin acceso? Pídaselo a {{d.empresa}}{{d.correo ? ' escribiendo a ' + d.correo : ''}}. Si ya tiene un ticket, use el enlace del correo que recibió.</p>
      </div>
    </template>

    <!-- cambio de clave obligatorio -->
    <template v-else-if="vista==='clave'">
      <div class="sp-card"><h2 style="margin:0 0 8px;font-size:17px">Elija su clave</h2><p class="s" style="font-size:13px;color:var(--muted);margin:0 0 8px">Su clave actual es temporal: cámbiela para seguir.</p>
        <label class="f">Clave temporal</label><input class="sp" type="password" v-model="claves.actual">
        <label class="f">Clave nueva (mínimo 8)</label><input class="sp" type="password" v-model="claves.nueva">
        <label class="f">Repita la clave nueva</label><input class="sp" type="password" v-model="claves.repetir">
        <div class="msg err" v-if="error">{{error}}</div>
        <button class="btn" style="width:100%;margin-top:12px" @click="cambiarClave">Guardar</button><button class="btn gris" style="width:100%;margin-top:8px" @click="salir">Salir</button>
      </div>
    </template>

    <!-- lista de tickets (3.87: la cabecera envuelve en el celular; antes «Salir» quedaba fuera de la pantalla) -->
    <template v-else-if="vista==='lista'">
      <div class="sp-card" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div style="min-width:0;overflow-wrap:anywhere"><b>{{acceso.nombre || acceso.correo}}</b><div class="s" style="font-size:12px;color:var(--muted)">{{acceso.correo}}</div></div><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" @click="abrirNuevo">+ Ticket</button><button class="btn sm gris" @click="verDocs">📚 Documentos</button><button class="btn sm gris" @click="salir">Salir</button></div></div>
      <div class="msg err" v-if="error" style="margin:0 16px">{{error}}</div>
      <p v-if="cargando" style="margin:12px 16px;color:var(--muted)">Cargando…</p>
      <template v-else>
        <h2 style="margin:12px 16px 0;font-size:16px">Abiertos ({{abiertos.length}})</h2>
        <p v-if="!abiertos.length" style="margin:8px 16px;color:var(--muted);font-size:14px">No tiene tickets abiertos.</p>
        <a v-for="t in abiertos" :key="t.id" class="sp-ticket" href="#" @click.prevent="ver(t)"><div class="h"><b>{{t.codigo}}</b><span class="badge" :class="claseEstado(t.estado)">{{t.estado_nombre}}</span></div><div class="a">{{t.asunto}}</div><div class="s">{{t.categoria ? t.categoria + ' · ' : ''}}{{fecha(t.creado)}}{{t.tecnico_nombre ? ' · atiende ' + t.tecnico_nombre : ''}}</div></a>
        <h2 style="margin:12px 16px 0;font-size:16px" v-if="cerrados.length">Resueltos y cerrados</h2>
        <a v-for="t in cerrados" :key="t.id" class="sp-ticket" href="#" @click.prevent="ver(t)" style="opacity:.8"><div class="h"><b>{{t.codigo}}</b><span class="badge" :class="claseEstado(t.estado)">{{t.estado_nombre}}</span></div><div class="a">{{t.asunto}}</div><div class="s">{{fecha(t.creado)}}{{t.calificacion ? ' · ' + '★'.repeat(t.calificacion) : ''}}</div></a>
      </template>
    </template>

    <!-- documentos y equipos visibles para el cliente -->
    <template v-else-if="vista==='docs'">
      <div class="sp-card" style="display:flex;justify-content:space-between;align-items:center"><b>Sus documentos</b><button class="btn sm gris" @click="misTickets">Mis tickets</button></div>
      <div class="msg err" v-if="error" style="margin:0 16px">{{error}}</div>
      <template v-if="docs">
        <p v-if="!docs.elementos.length && !docs.equipos.length" style="margin:12px 16px;color:var(--muted);font-size:14px">Todavía no hay documentos compartidos con usted.</p>
        <a v-for="d in docs.elementos" :key="'e' + d.id" class="sp-ticket" href="#" @click.prevent="docAbierto = docAbierto === d.id ? null : d.id"><div class="h"><span class="badge">{{d.tipo_nombre}}</span><span class="s">{{fecha(d.actualizado)}}</span></div><div class="a">{{d.nombre}}</div>
          <div class="s" v-if="d.vence">Vence {{d.vence}}</div>
          <div v-if="docAbierto === d.id" style="margin-top:8px;font-size:14px;white-space:pre-wrap">{{textoDoc(d)}}</div></a>
        <h2 style="margin:12px 16px 0;font-size:16px" v-if="docs.equipos.length">Sus equipos</h2>
        <div v-for="q in docs.equipos" :key="'q' + q.id" class="sp-ticket"><div class="h"><b>{{q.codigo}}</b><span class="badge">{{q.tipo}}</span></div><div class="a">{{q.nombre}}</div><div class="s">{{q.ubicacion}}{{q.garantia_hasta ? ' · garantía hasta ' + q.garantia_hasta : ''}}</div></div>
      </template>
    </template>

    <!-- ticket nuevo -->
    <template v-else-if="vista==='nuevo'">
      <div class="sp-card"><h2 style="margin:0 0 8px;font-size:17px">Ticket nuevo</h2>
        <label class="f">Asunto</label><input class="sp" v-model="nuevo.asunto" maxlength="160" placeholder="Qué necesita, en pocas palabras">
        <label class="f">Cuéntenos qué pasa</label><textarea class="sp" rows="5" v-model="nuevo.descripcion" maxlength="5000" placeholder="Desde cuándo, a quién afecta, qué ya intentó…"></textarea>
        <label class="f">Categoría</label><select class="sp" v-model="nuevo.categoria"><option v-for="c in d.categorias" :key="c" :value="c">{{c}}</option></select>
        <label class="f">Urgencia</label><div class="seg"><button v-for="p in [['baja','Baja'],['media','Media'],['alta','Alta']]" :key="p[0]" :class="{on: nuevo.prioridad===p[0]}" @click="nuevo.prioridad=p[0]">{{p[1]}}</button></div>
        <label class="f">Teléfono para contactarle (opcional)</label><input class="sp" v-model="nuevo.telefono" maxlength="20" inputmode="numeric">
        <div class="msg err" v-if="error">{{error}}</div>
        <button class="btn" style="width:100%;margin-top:12px" @click="crear" :disabled="enviando">{{enviando ? 'Enviando…' : 'Abrir el ticket'}}</button><button class="btn gris" style="width:100%;margin-top:8px" @click="misTickets">Volver</button>
      </div>
    </template>

    <!-- detalle de un ticket -->
    <template v-else-if="vista==='ticket'">
      <div class="sp-card" v-if="t">
        <div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>{{t.codigo}}</b><span class="badge" :class="claseEstado(t.estado)">{{t.estado_nombre}}</span></div>
        <h2 style="margin:4px 0 2px;font-size:17px">{{t.asunto}}</h2>
        <div class="s" style="font-size:13px;color:var(--muted)">{{t.categoria ? t.categoria + ' · ' : ''}}abierto {{fecha(t.creado)}}{{t.tecnico_nombre ? ' · lo atiende ' + t.tecnico_nombre : ''}}</div>
        <p style="white-space:pre-wrap;margin:10px 0 0;font-size:14px">{{t.descripcion}}</p>
        <div class="msg info" v-if="t.estado==='espera_cliente'">Estamos esperando su respuesta para continuar.</div>
        <template v-if="t.estado==='resuelto' && !t.calificacion"><div class="msg ok">Marcamos su ticket como resuelto. ¿Cómo fue la atención?</div>
          <div class="sp-estrellas" style="text-align:center"><button v-for="n in 5" :key="n" :class="{on: n <= calif.puntos}" @click="calif.puntos=n">★</button></div>
          <input class="sp" v-model="calif.comentario" maxlength="400" placeholder="Comentario (opcional)">
          <button class="btn" style="width:100%;margin-top:8px" @click="calificar" :disabled="enviando">Enviar calificación y cerrar</button>
          <p class="s" style="font-size:13px;color:var(--muted);margin:8px 0 0">¿No quedó resuelto? Respóndanos abajo y lo retomamos.</p></template>
        <div class="msg ok" v-else-if="t.calificacion">Su calificación: {{'★'.repeat(t.calificacion)}}{{'☆'.repeat(5 - t.calificacion)}}</div>
      </div>
      <div class="sp-card" v-if="t && t.estado!=='cerrado'"><label class="f" style="margin-top:0">Responder</label><textarea class="sp" rows="3" v-model="respuesta" maxlength="5000" placeholder="Escriba su respuesta…"></textarea>
        <div class="msg err" v-if="error">{{error}}</div>
        <button class="btn" style="width:100%;margin-top:8px" @click="responder" :disabled="enviando || !respuesta.trim()">Enviar</button></div>
      <div class="sp-card" v-if="t"><h2 style="margin:0 0 4px;font-size:15px">Seguimiento</h2>
        <div v-for="x in entradas" :key="x.id" class="sp-entrada" :class="x.tipo"><div class="q">{{x.tipo==='cliente' ? 'Usted' : x.tipo==='respuesta' ? x.usuario : 'Sistema'}} · {{fecha(x.creado)}}</div>{{x.texto}}</div>
        <p v-if="!entradas.length" style="color:var(--muted);font-size:14px">Todavía no hay novedades.</p>
      </div>
      <div class="sp-card" v-if="!t"><p>{{error || 'Buscando el ticket…'}}</p></div>
      <div style="margin:0 16px"><button class="btn gris" style="width:100%" @click="volver">{{acceso ? 'Mis tickets' : 'Inicio'}}</button></div>
    </template>

    <div class="sp-pie">Tickets de soporte con TiKe · {{d.empresa}}</div>
  </div>
  <div v-else class="sp-card"><p>{{error || 'Cargando…'}}</p></div>`,
}).mount('#app');
