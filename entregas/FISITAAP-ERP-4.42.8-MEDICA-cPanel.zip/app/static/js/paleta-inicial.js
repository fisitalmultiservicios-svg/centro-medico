// Se carga en <head> antes de pintar: aplica la última paleta usada en este navegador (evita el destello de la predeterminada).
try { const p = localStorage.getItem('gf:paleta'); if (p) document.documentElement.dataset.paleta = p; } catch { /* sin almacenamiento */ }
