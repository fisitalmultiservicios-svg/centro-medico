// 4.7: renuncia a la verificación en dos pasos (pedido de Norman). Quien debe usarla (el Administrador, los roles que cambian la
// configuración o los usuarios, y quien ve Recursos humanos) puede no hacerlo si lee el descargo (/renuncia-mfa.html), marca las dos
// casillas, escribe su contraseña actual y la palabra ACEPTO. El servidor decide y registra todo (GET/POST /api/auth/mfa/renuncia:
// nunca el administrador del sistema, nunca con un token de API, solo para sí mismo); esta ventana solo muestra el texto y pide los datos,
// siempre con la recomendación de activarla a la vista. La abren la pantalla que obliga a activar la verificación (app.js, que la carga
// solo cuando hace falta) y Mi perfil. Las marcas de las listas de usuarios (Configuración › Usuarios y la consola) salen de aquí.
import { api, toast } from './api.js';

const TZ_CR = 'America/Costa_Rica';

// fecha de la renuncia (ISO con zona, en UTC) como dd/mm/aaaa en hora de Costa Rica
export function fechaRenuncia(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return String(iso).slice(0, 10);
  try { return d.toLocaleDateString('es-CR', { timeZone: TZ_CR, day: '2-digit', month: '2-digit', year: 'numeric' }); } catch { return String(iso).slice(0, 10); }
}

// marca de las listas de usuarios: «Sin verificación: renuncia aceptada el dd/mm/aaaa» y, si no vale, por qué
export function marcaRenuncia(r) {
  if (!r) return '';
  const base = 'Sin verificación: renuncia aceptada el ' + fechaRenuncia(r.fecha);
  if (r.desactualizada) return base + ' (texto anterior: debe aceptarlo de nuevo o activar la verificación)';
  if (!r.vigente) return base + ' (sin efecto)';
  if (r.vale_aqui === false) return base + ' (no vale aquí: la empresa exige la verificación sin excepción)';
  return base;
}

// estado corto de una fila con renuncia (tablas de Configuración › Usuarios y de la consola del sistema) y el color de su etiqueta
export function estadoRenuncia(x) {
  if (!x) return '';
  if (x.mfa_activo) return 'Usa la verificación';
  if (x.desactualizada) return 'Texto anterior: debe aceptarlo de nuevo';
  if (!x.vigente) return 'Sin efecto: el sistema no la permite';
  if (x.vale_aqui === false) return 'No vale aquí: verificación sin excepción';
  return 'Sin verificación (renuncia vigente)';
}
export function claseRenuncia(x) { return x && !x.mfa_activo && x.vigente && x.vale_aqui !== false ? 'warn' : 'info'; }

const normal = v => String(v || '').trim().split(' ').filter(Boolean).join(' ').toUpperCase();   // como el servidor: no importan mayúsculas ni espacios

export default {
  name: 'RenunciaMfa',
  props: { correo: String },
  emits: ['cerrar', 'aceptada', 'clave'],
  data() { return { estado: null, error: '', lee: false, asume: false, password: '', palabra: '', guardando: false, clave: { actual: '', nueva: '', repetir: '' } }; },
  computed: {
    palabraClave() { return (this.estado && this.estado.palabra) || 'ACEPTO'; },
    texto() { const e = this.estado; return e ? (e.url || '/renuncia-mfa.html') + '?v=' + encodeURIComponent(e.version || '') : ''; },
    disponible() { const e = this.estado; return !!(e && e.aplica && e.permitida); },
    puedeAceptar() { return this.disponible && !this.estado.requiere_cambiar_password; },
    completo() { return this.puedeAceptar && this.lee && this.asume && !!this.password && normal(this.palabra) === this.palabraClave; },
  },
  created() { this.cargar(); },
  methods: {
    async cargar() {
      this.error = '';
      try { this.estado = await api('/api/auth/mfa/renuncia'); }
      catch (e) { this.estado = null; this.error = e.message; }
    },
    // con la contraseña temporal primero se cambia: la aceptación es personal y la confirma una contraseña que solo la persona conoce
    async cambiarClave() {
      const k = this.clave;
      if (!k.actual || !k.nueva) return toast('Indique la contraseña temporal y la nueva', 'err');
      if (k.nueva.length < 12) return toast('La nueva contraseña debe tener al menos 12 caracteres', 'err');
      if (k.nueva !== k.repetir) return toast('La nueva contraseña y su repetición no coinciden', 'err');
      this.guardando = true;
      try { await api('/api/auth/password', { method: 'POST', body: { actual: k.actual, nueva: k.nueva } }); this.clave = { actual: '', nueva: '', repetir: '' }; toast('Contraseña actualizada', 'ok'); this.$emit('clave'); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async aceptar() {
      if (!this.completo || this.guardando) return;
      this.guardando = true;
      try {
        const r = await api('/api/auth/mfa/renuncia', { method: 'POST', body: { acepta: true, asume_responsabilidad: true, version: this.estado.version, password: this.password, confirmacion: this.palabra } });
        this.password = '';
        toast('Renuncia registrada.' + (r.correo ? ' Enviamos una copia del descargo a su correo.' : ' No fue posible enviarle la copia por correo; el texto del descargo sigue disponible en Mi perfil.'), 'ok');
        this.$emit('aceptada', r);
      } catch (e) {
        const c = e.detail && e.detail.codigo;
        // el texto cambió (409), hay que cambiar la contraseña temporal o ya no se permite: se vuelve a leer y se empieza de nuevo
        if (c === 'renuncia_version' || c === 'cambiar_password' || c === 'renuncia_no_permitida') { this.lee = false; this.asume = false; this.palabra = ''; this.password = ''; await this.cargar(); }
        else if (e.status === 400 && /contraseña/i.test(e.message)) this.password = '';
        toast(e.message, 'err');
      }
      this.guardando = false;
    },
  },
  template: `
  <Modal lg title="Continuar sin verificación en dos pasos" @close="$emit('cerrar')">
    <div class="alert warn" style="margin:0 0 12px"><b>Le recomendamos activar la verificación en dos pasos.</b> Es gratuita, toma un minuto y protege su cuenta aunque otra persona llegue a conocer su contraseña. Si decide no usarla, lea el descargo completo: al aceptarlo, usted asume la responsabilidad por lo que se haga con su cuenta.</div>
    <p class="muted" v-if="!estado && !error">Cargando…</p>
    <div class="alert danger" v-else-if="error">{{error}}</div>
    <div class="alert danger" v-else-if="!disponible">{{estado.motivo || 'La renuncia a la verificación en dos pasos no está disponible para su cuenta.'}}</div>
    <template v-else-if="estado.requiere_cambiar_password">
      <p style="margin:0 0 10px">Antes de aceptar el descargo, cambie su contraseña temporal por una que solo usted conozca: la aceptación es personal y se confirma con su contraseña.</p>
      <div class="grid" style="grid-template-columns:1fr;gap:10px">
        <Field label="Contraseña temporal"><input type="password" v-model="clave.actual" autocomplete="current-password"></Field>
        <Field label="Contraseña nueva" help="Mínimo 12 caracteres; evite palabras comunes o su correo"><input type="password" v-model="clave.nueva" autocomplete="new-password"></Field>
        <Field label="Repita la contraseña nueva"><input type="password" v-model="clave.repetir" autocomplete="new-password" @keyup.enter="cambiarClave"></Field>
      </div>
    </template>
    <template v-else>
      <div class="row" style="justify-content:space-between;align-items:baseline;gap:8px;flex-wrap:wrap;margin:0 0 6px"><b>Descargo de responsabilidad · versión {{estado.version}}</b><a class="link small" :href="texto" target="_blank" rel="noopener">Abrir en otra pestaña</a></div>
      <iframe :src="texto" title="Descargo de responsabilidad: renuncia a la verificación en dos pasos" style="display:block;width:100%;height:min(48vh,440px);border:1px solid var(--line);border-radius:8px;background:#fff"></iframe>
      <div class="alert info" style="margin:10px 0 0" v-if="estado.desactualizada">El texto cambió desde que aceptó la versión {{estado.version_aceptada}}: léalo de nuevo antes de aceptarlo.</div>
      <div class="alert info" style="margin:10px 0 0" v-if="(estado.empresas_sin_excepcion || []).length">En {{estado.empresas_sin_excepcion.join(', ')}} se le seguirá pidiendo la verificación en dos pasos: la empresa la exige sin excepción.</div>
      <div class="alert info" style="margin:10px 0 0" v-if="estado.mfa_activo">Su verificación sigue activa: después de aceptar puede desactivarla en Mi perfil con un código de su aplicación. Mientras esté activa, se le pedirá al entrar.</div>
      <label class="row" style="gap:10px;align-items:flex-start;margin:14px 0 8px;cursor:pointer"><input type="checkbox" v-model="lee" style="margin-top:4px"><span>He leído el descargo de responsabilidad completo (versión {{estado.version}}) y lo acepto.</span></label>
      <label class="row" style="gap:10px;align-items:flex-start;margin:0 0 12px;cursor:pointer"><input type="checkbox" v-model="asume" style="margin-top:4px"><span>Entiendo los riesgos de no usar la verificación en dos pasos y asumo la responsabilidad por los accesos y las operaciones que se hagan con mis credenciales, en los términos del descargo.</span></label>
      <div class="grid cols-2" style="gap:10px">
        <Field label="Su contraseña actual" req><input type="password" v-model="password" autocomplete="current-password"></Field>
        <Field :label="'Para confirmar, escriba ' + palabraClave" req><input v-model="palabra" autocomplete="off" autocapitalize="characters" spellcheck="false" :placeholder="palabraClave" @keyup.enter="aceptar"></Field>
      </div>
      <p class="small muted" style="margin:10px 0 0">Quedan registrados la fecha, la hora, su dirección IP, su navegador y la versión del texto, y, si el envío de correos está disponible, le enviaremos una copia del descargo {{correo ? 'a ' + correo : 'a su correo'}}. Puede retirar la renuncia o activar la verificación cuando quiera desde Mi perfil.</p>
    </template>
    <template #foot>
      <button class="btn sec" @click="$emit('cerrar')">{{disponible ? 'Cancelar' : 'Cerrar'}}</button>
      <button class="btn" v-if="disponible && estado.requiere_cambiar_password" :disabled="guardando" @click="cambiarClave">{{guardando ? 'Guardando…' : 'Guardar contraseña y continuar'}}</button>
      <button class="btn danger" v-else-if="puedeAceptar" :disabled="!completo || guardando" @click="aceptar">{{guardando ? 'Guardando…' : 'Acepto y continúo sin verificación'}}</button>
    </template>
  </Modal>`,
};
