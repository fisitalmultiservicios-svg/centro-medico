// Página pública del negocio (FISITAAP embebido, 3.74): la misma página de FISITAAP, con sus hojas de estilo originales y su
// estructura (portada del negocio, catálogo o menú con slider y categorías, carrito en cajón, personalización de opciones,
// cuenta del cliente, trazabilidad del pedido y FISIChat), sobre los datos y pedidos de FISITAAP by Brillante Agencia. Sin sesión del sistema:
// lee /api/publico/<negocio>, arma el carrito en el navegador y el servidor recalcula los precios al enviar el pedido.
// Conserva lo que ya teníamos: zonas en el mapa, cupones, puntos, tarjeta de regalo, SINPE Móvil con comprobante, pago con
// tarjeta (Tilopay), avisos a los píxeles y el acceso del cliente por teléfono y clave.
// 4.40: el carrito guardado se revisa contra el catálogo: lo agotado (a mano o según existencias) se marca «Se agotó» con «Quitar los agotados»,
// y si el pedido se rechaza por existencias se recarga el catálogo y se muestra el mensaje tal como llega.
// 4.40: la línea cuyo producto salió del catálogo dice «Ya no está en el catálogo»; «Quitar los agotados» quita las dos.
import { createApp } from '/js/vendor/vue.esm-browser.prod.min.js';
import { crearMapa, zonaPara, miPosicion } from '/js/mapa.js';

const SLUG = document.getElementById('app').dataset.slug;
const KEY = 'tienda:' + SLUG;
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
const money = v => '₡' + Number(v || 0).toLocaleString('es-CR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const DIAS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
const ESTADOS = [['nuevo', 'Recibido'], ['confirmado', 'Confirmado'], ['en_preparacion', 'En preparación'], ['listo', 'Listo'], ['entregado', 'Entregado']];
const PLACEHOLDER = '/fisitaap/assets/product-placeholder.svg';

function leerHash() {
  const h = location.hash.replace(/^#/, '');
  if (h.startsWith('pedido=')) return { vista: 'seguimiento', token: h.slice(7) };
  if (h === 'catalogo' || h === 'menu') return { vista: 'catalogo' };
  if (h === 'cuenta' || h === 'account') return { vista: 'cuenta' };
  return { vista: 'inicio', ancla: h };
}

createApp({
  data() {
    let guardado = {}; try { guardado = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { /* sin almacenamiento */ }
    const r = leerHash();
    return { d: null, error: '', vista: r.vista, menu: false, cat: '', q: '', cant: {}, slide: 0, PLACEHOLDER,
             carrito: guardado.carrito || [], carritoAbierto: false, item: null, cantidad: 1, nota: '', selOp: {}, msg: '',
             pedido: { tipo: '', nombre: guardado.nombre || '', telefono: guardado.telefono || '', direccion: guardado.direccion || '', referencia: '', nota: '', hora: '', correo: guardado.correo || '', pago: 'Efectivo' },
             enviando: false, resultado: null, seguimiento: r.token || null, seg: null, cliente: guardado.cliente || null, acceso: { telefono: guardado.telefono || '', pin: '', nombre: '', nuevo: false, error: '', codigo: '' }, mios: null, clavePeticion: uuid(),
             dirNueva: { nombre: 'Casa', detalle: '' }, ESTADOS, pos: guardado.pos || null, mapaC: null, marcador: null, mapaS: null, capasS: [], buscandoPos: false,
             codigo: '', cupon: null, puntosInfo: null, usarPuntos: false, tarjeta: null, pagoAviso: new URLSearchParams(location.hash.replace(/^#/, '')).get('pago') || '', pagando: false,
             sinpeArchivo: null, sinpeRef: '', subiendoSinpe: false, galeriaIdx: null,
             chat: false, chatMsgs: [], chatTxt: '', chatCargando: false, contacto: { nombre: '', correo: '', telefono: '', asunto: '', mensaje: '' }, contactoEnviado: false };
  },
  computed: {
    ds() { return (this.d && this.d.diseno) || {}; },
    aj() { return (this.d && this.d.ajustes) || {}; },
    etiquetaMin() { return this.d ? this.d.etiqueta.toLowerCase() : 'catálogo'; },
    items() { const q = this.q.trim().toLowerCase(); return (this.d ? this.d.items : []).filter(i => (!this.cat || i.categoria === this.cat) && (!q || i.nombre.toLowerCase().includes(q) || (i.descripcion || '').toLowerCase().includes(q))); },
    cantidadCarrito() { return this.carrito.reduce((s, l) => s + l.cantidad, 0); },
    // 4.40: líneas del carrito cuyo producto ya no se puede pedir (agotado o fuera del catálogo); se recalcula cada vez que cargar() trae d.items.
    // Con el catálogo privado sin sesión no hay productos que comparar: no se marca nada.
    agotadosCarrito() {
      if (!this.d || this.d.privado || !Array.isArray(this.d.items)) return [];
      const por = new Map(this.d.items.map(i => [i.id, i]));
      return this.carrito.filter(l => { const i = por.get(l.id); return !i || !!i.agotado; });
    },
    subtotal() { return this.carrito.reduce((s, l) => s + l.cantidad * l.precio, 0); },
    descuentoCupon() { if (!this.cupon) return 0; const d = this.cupon.tipo === 'pct' ? this.subtotal * this.cupon.valor / 100 : this.cupon.valor; return Math.min(this.cupon.tope_aplicado !== undefined ? this.cupon.tope_aplicado : d, d, this.subtotal); },
    puntosCanje() { const p = this.puntosInfo; if (!this.usarPuntos || !p || !p.activo || p.saldo < p.minimo_canje) return { puntos: 0, descuento: 0 }; const base = this.subtotal - this.descuentoCupon; const maxDesc = base * (+p.maximo_pct || 100) / 100; const puntos = Math.min(p.saldo, Math.floor(maxDesc / (+p.valor_punto || 1))); return puntos >= p.minimo_canje ? { puntos, descuento: Math.round(puntos * p.valor_punto * 100) / 100 } : { puntos: 0, descuento: 0 }; },
    conZonas() { return !!(this.d && this.d.con_zonas); },
    zonaSel() { return this.conZonas && this.pos ? zonaPara(this.d.zonas, this.pos) : null; },
    fueraZona() { return this.pedido.tipo === 'domicilio' && this.conZonas && !!this.pos && !this.zonaSel; },
    envio() { if (this.pedido.tipo !== 'domicilio' || !this.d) return 0; if (this.conZonas) return this.zonaSel ? +this.zonaSel.precio || 0 : 0; return +this.d.costo_envio || 0; },
    total() { return Math.max(0, this.subtotal - this.descuentoCupon - this.puntosCanje.descuento) + this.envio; },
    montoTarjeta() { return this.tarjeta ? Math.min(+this.tarjeta.saldo || 0, this.total) : 0; },
    aPagar() { return Math.max(0, this.total - this.montoTarjeta); },
    conTarjeta() { return !!(this.pedido.pago === 'Tarjeta en línea' && this.d && this.d.pago_tarjeta && this.aPagar > 0); },
    conSinpe() { return !!(this.pedido.pago === 'SINPE Móvil' && this.d && this.d.sinpe && this.aPagar > 0); },
    sinpePendiente() { const s = this.seg; return !!(s && s.pago_medio === 'sinpe' && s.pago_estado !== 'aprobado' && s.estado !== 'cancelado'); },
    tipos() { if (!this.d) return []; const a = this.d.acepta; return [['domicilio', 'Delivery', a.domicilio], ['recoger', 'Recoger en el negocio', a.recoger], ['coordinado', 'Envío coordinado', a.coordinado]].filter(t => t[2]); },
    metodosPago() {
      if (!this.d) return [];
      const m = (this.aj.metodos_pago || ['Efectivo']).filter(x => x !== 'SINPE Móvil' || this.d.sinpe);
      if (this.d.sinpe && !m.includes('SINPE Móvil')) m.push('SINPE Móvil');
      if (this.d.pago_tarjeta) m.push('Tarjeta en línea');
      if (this.credito && this.credito.permitido) m.push('A crédito');
      return m;
    },
    abierto() { return this.d ? this.d.abierto.abierto : false; },
    // modo mayorista (3.79): catálogo privado para revendedoras, precios de su lista y crédito
    mayorista() { return !!(this.d && this.d.mayorista); },
    privado() { return !!(this.d && this.d.privado); },
    credito() { const c = this.d && this.d.cliente; return c && c.credito ? c.credito : null; },
    conCredito() { return this.pedido.pago === 'A crédito' && !!(this.credito && this.credito.permitido); },
    horariosTexto() { return this.d ? (this.d.horarios || []).map((h, i) => ({ dia: DIAS[i], txt: h && h[0] ? h[0] + ' – ' + h[1] : 'Cerrado' })) : []; },
    // 3.87: sin ningún día con horario el negocio recibe pedidos siempre: no se muestra la lista (decía «Cerrado» los 7 días)
    conHorario() { return this.horariosTexto.some(h => h.txt !== 'Cerrado'); },
    minimoFalta() { return this.d && +this.d.minimo_pedido > 0 && this.subtotal < +this.d.minimo_pedido ? +this.d.minimo_pedido - this.subtotal : 0; },
    wa() { const n = this.d ? String(this.d.whatsapp || this.d.telefono || '').replace(/\D/g, '') : ''; return n.length >= 8 ? 'https://wa.me/506' + n.slice(-8) : '#contacto'; },   // 4.4: sin WhatsApp configurado usa el teléfono del negocio
    aboutText() { return this.ds.about_text || this.d.nosotros || this.d.descripcion || ''; },
    promesas() { return ['about_promise_1', 'about_promise_2', 'about_promise_3'].map(k => (this.ds[k] || '').trim()).filter(Boolean); },
    servicios() { return [1, 2, 3].map(i => ({ i, t: this.ds['service_' + i + '_title'] || '', x: this.ds['service_' + i + '_text'] || '', img: this.ds['service_' + i + '_image'] || '' })).filter(s => s.t || s.x || s.img); },
    mapaSrc() { const m = /src=["'](https:\/\/(?:www\.)?google\.com\/maps\/embed[^"']*)["']/i.exec(this.aj.mapa_embed || ''); return m ? m[1] : ''; },
    redesPie() { const r = (this.d && this.d.redes) || {}; const out = []; if (r.facebook) out.push({ label: 'Facebook', href: String(r.facebook).startsWith('http') ? r.facebook : 'https://facebook.com/' + r.facebook }); if (r.instagram) out.push({ label: 'Instagram', href: String(r.instagram).startsWith('http') ? r.instagram : 'https://instagram.com/' + String(r.instagram).replace('@', '') }); if (this.aj.tiktok) out.push({ label: 'TikTok', href: this.aj.tiktok }); return out; },
    slides() {
      const ds = this.ds, out = [];
      if (Array.isArray(ds.catalog_slides) && ds.catalog_slides.length) {   // 4.4: la portada y todas las fotos de la galería, sin límite
        return ds.catalog_slides.map((image, i) => ({ image, title: i === 0 ? (ds.catalog_intro_title || this.d.etiqueta) : '', body: i === 0 ? (ds.catalog_intro_text || 'Elige una categoría y agrega tus productos.') : '' }));
      }
      for (const [k, suf] of [['catalog_intro_image', ''], ['catalog_intro_image_2', '_2'], ['catalog_intro_image_3', '_3']]) {
        const image = ds[k] || '', title = ds['catalog_intro_title' + suf] || (suf ? '' : this.d.etiqueta), body = ds['catalog_intro_text' + suf] || (suf ? '' : 'Elige una categoría y agrega tus productos.');
        if (image) out.push({ image, title, body });
      }
      return out.length ? out : [{ image: '', title: ds.catalog_intro_title || this.d.etiqueta, body: ds.catalog_intro_text || 'Elige una categoría y agrega tus productos.' }];
    },
    sugerencias() { return ['¿Qué productos venden?', '¿Cómo hago un pedido?', 'Horarios y contacto']; },
    anio() { return new Date().getFullYear(); },
    pinSeg() { return this.seg && this.seg.entrega && this.seg.entrega.pin ? this.seg.entrega.pin : ''; },
    eventosSeg() {
      const p = this.seg; if (!p) return [];
      const ev = [[p.creado, 'Pedido recibido desde la página']];
      if (p.confirmado) ev.push([p.confirmado, 'Pedido aceptado por el negocio']);
      if (p.entregado) ev.push([p.entregado, 'Pedido entregado']);
      if (p.estado === 'cancelado') ev.push([p.actualizado, 'Pedido cancelado' + (p.motivo ? ': ' + p.motivo : '')]);
      return ev.filter(x => x[0]).sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    },
  },
  watch: { carrito: { deep: true, handler() { this.guardar(); } } },
  methods: {
    money,
    tel(n) { return String(n || '').replace(/[^+0-9]/g, ''); },
    sinFoto(ev) { if (ev.target.src !== location.origin + PLACEHOLDER) ev.target.src = PLACEHOLDER; },
    telFmt(n) { const d = String(n || '').replace(/\D/g, ''); return d.length === 8 ? d.slice(0, 4) + '-' + d.slice(4) : d; },
    evento(nombre, datos) { try { if (window.gfEvento) window.gfEvento(nombre, datos); } catch { /* sin píxeles */ } },
    fecha(iso) { return iso ? new Date(iso).toLocaleString('es-CR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''; },
    fechaCorta(iso) { return iso ? new Date(iso).toLocaleDateString('es-CR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : ''; },
    async api(url, body, method) {
      const h = { 'Content-Type': 'application/json' }; if (this.cliente && this.cliente.token) h['X-Cliente'] = this.cliente.token;
      const r = await fetch(url, { method: method || (body ? 'POST' : 'GET'), headers: h, body: body ? JSON.stringify(body) : undefined });
      let j = null; try { j = await r.json(); } catch { /* sin cuerpo */ }
      if (!r.ok) { const d = j && j.detail; const e = new Error(typeof d === 'string' ? d : (d && d.mensaje) || (Array.isArray(d) && d[0] && d[0].msg) || 'No se pudo completar (' + r.status + ')'); e.codigo = d && d.codigo; e.status = r.status; throw e; }
      return j;
    },
    guardar() { try { localStorage.setItem(KEY, JSON.stringify({ carrito: this.carrito, nombre: this.pedido.nombre, telefono: this.pedido.telefono, direccion: this.pedido.direccion, correo: this.pedido.correo, cliente: this.cliente, pos: this.pos })); } catch { /* sin almacenamiento */ } },
    enrutar() {
      const r = leerHash(); this.vista = r.vista; this.menu = false; this.error = '';
      if (r.vista === 'seguimiento') this.verSeguimiento(r.token);
      else if (r.vista === 'cuenta') { if (this.cliente) this.verMios(); }
      else if (r.vista === 'inicio' && r.ancla) this.$nextTick(() => { const el = document.getElementById(r.ancla); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
      if (r.vista !== 'inicio' || !r.ancla) window.scrollTo(0, 0);
    },
    // 4.40: soloCatalogo = refrescar el catálogo y las marcas del carrito sin cambiar de vista (tras un pedido rechazado por existencias)
    async cargar(soloCatalogo) {
      try {
        this.d = await this.api('/api/publico/' + SLUG);
        if (this.d.privado) { this.vista = 'cuenta'; if (this.cliente) { this.acceso.telefono = this.cliente.telefono || this.acceso.telefono; this.cliente = null; this.mios = null; this.guardar(); } }   // catálogo mayorista: primero la puerta de acceso (3.87: también si la sesión dejó de ser de revendedora)
        for (const i of this.d.items) if (!soloCatalogo || !this.cant[i.id]) this.cant[i.id] = 1;   // 4.40: al refrescar se conservan las cantidades elegidas
        if (!this.pedido.tipo) this.pedido.tipo = (this.tipos[0] || [''])[0];
        if (!this.metodosPago.includes(this.pedido.pago)) this.pedido.pago = this.metodosPago[0] || 'Efectivo';
        this.rotarSlider();
      } catch (e) { this.error = e.message; }
      if (soloCatalogo) return;
      if (this.seguimiento) this.verSeguimiento(this.seguimiento); else if (this.vista === 'cuenta' && this.cliente) this.verMios();
      if (this.pagoAviso === 'ok') this.aviso('Pago aprobado'); else if (this.pagoAviso === 'perdido') this.error = 'No encontramos el pedido de ese pago. Escríbanos por WhatsApp.';
    },
    rotarSlider() { clearInterval(this._sl); const seg = Math.max(2, Math.min(60, +this.ds.catalog_slide_seconds || 5)); this._sl = setInterval(() => { if (this.slides.length > 1) this.slide = (this.slide + 1) % this.slides.length; }, seg * 1000); },
    // ---- carrito ----
    abrirCarrito() { this.carritoAbierto = true; document.body.style.overflow = 'hidden'; if (this.pedido.tipo === 'domicilio') this.mostrarMapaCarrito(); },
    cerrarCarrito() { this.carritoAbierto = false; document.body.style.overflow = ''; },
    enCarrito(i) { return this.carrito.filter(x => x.id === i.id).reduce((s, x) => s + x.cantidad, 0); },
    agregarDirecto(i) { if (i.agotado) return; const q = Math.max(1, Math.round(+this.cant[i.id] || 1)); const l = this.carrito.find(x => x.id === i.id && !x.nota && !x.clave); if (l) l.cantidad += q; else this.carrito.push({ id: i.id, nombre: i.nombre, precio: i.precio, cantidad: q, nota: '', foto: i.foto, unidad: i.unidad, opciones: [], opcionesTxt: '', clave: '' }); this.aviso('✓ ' + i.nombre + ' agregado al carrito'); this.evento('carrito', { valor: q * i.precio }); },
    personalizar(i) { if (i.agotado) return; this.item = i; this.cantidad = Math.max(1, Math.round(+this.cant[i.id] || 1)); this.nota = ''; this.selOp = Object.fromEntries((i.modificadores || []).map(g => [g.id, []])); document.body.style.overflow = 'hidden'; },
    cerrarPersonalizar() { this.item = null; document.body.style.overflow = ''; },
    toggleOp(g, o) { const l = this.selOp[g.id]; const k = l.findIndex(x => x.id === o.id); if (k >= 0) l.splice(k, 1); else { if (+g.maximo === 1) l.splice(0, l.length); if (+g.maximo && l.length >= +g.maximo) return this.aviso('«' + g.nombre + '»: máximo ' + g.maximo); l.push(o); } },
    tieneOp(g, o) { return (this.selOp[g.id] || []).some(x => x.id === o.id); },
    precioItem(i) { return i.precio + Object.values(this.selOp).flat().reduce((s, o) => s + (+o.precio || 0), 0); },
    agregar() {
      const i = this.item; const nota = this.nota.trim().slice(0, 120);
      for (const g of i.modificadores || []) if ((this.selOp[g.id] || []).length < (+g.minimo || 0)) return this.aviso('Revisa la selección de ' + g.nombre + '.');
      const ops = Object.values(this.selOp).flat(); const extra = ops.reduce((s, o) => s + (+o.precio || 0), 0); const clave = ops.map(o => o.id).sort().join(',');
      const l = this.carrito.find(x => x.id === i.id && x.nota === nota && (x.clave || '') === clave);
      if (l) l.cantidad += this.cantidad; else this.carrito.push({ id: i.id, nombre: i.nombre, precio: Math.round((i.precio + extra) * 100) / 100, cantidad: this.cantidad, nota, foto: i.foto, unidad: i.unidad, opciones: ops.map(o => o.id), opcionesTxt: ops.map(o => o.nombre).join(', '), clave });
      this.cerrarPersonalizar(); this.aviso('✓ ' + i.nombre + ' agregado al carrito'); this.evento('carrito', { valor: this.cantidad * (i.precio + extra) });
    },
    cambiarCant(l, v) { const n = Math.max(0, Math.round(+v || 0)); if (!n) this.carrito = this.carrito.filter(x => x !== l); else l.cantidad = n; },
    quitar(l) { this.carrito = this.carrito.filter(x => x !== l); },
    // 4.40: marca «Se agotó» y «Quitar los agotados»
    lineaAgotada(l) { return this.agotadosCarrito.includes(l); },
    // 4.40: la línea cuyo producto ya no sale en el catálogo (oculto, inactivo o borrado) no está «agotada»: se dice tal cual
    lineaFuera(l) { return !!(this.d && Array.isArray(this.d.items)) && !this.d.items.some(i => i.id === l.id); },
    quitarAgotados() { const fuera = this.agotadosCarrito; this.carrito = this.carrito.filter(x => !fuera.includes(x)); this.error = ''; },
    aviso(t) { this.msg = t; clearTimeout(this._m); this._m = setTimeout(() => { this.msg = ''; }, 1800); },
    // ---- mapa de entrega (zonas) ----
    async mostrarMapaCarrito() {
      await this.$nextTick(); const el = this.$refs.mapaC; if (!el || !this.d || !this.d.mapa) return;
      try {
        if (this.mapaC) { this.mapaC.remove(); this.mapaC = null; }
        const centro = this.pos || (this.d.negocio_ubicacion && this.d.negocio_ubicacion.lat ? this.d.negocio_ubicacion : { lat: +this.d.zonas[0].lat, lng: +this.d.zonas[0].lng });
        this.mapaC = await crearMapa(el, centro, this.pos ? 16 : 14); const L = window.L;
        for (const z of this.d.zonas || []) L.circle([+z.lat, +z.lng], { radius: +z.radio_km * 1000, color: this.d.color || '#0f766e', weight: 1, fillOpacity: .08 }).addTo(this.mapaC).bindTooltip(z.nombre + ' · ' + money(z.precio));
        if (this.d.negocio_ubicacion && this.d.negocio_ubicacion.lat) L.circleMarker([this.d.negocio_ubicacion.lat, this.d.negocio_ubicacion.lng], { radius: 7, color: this.d.color || '#0f766e', fillOpacity: .9 }).addTo(this.mapaC).bindTooltip(this.d.nombre);
        this.marcador = L.marker([centro.lat, centro.lng], { draggable: true }).addTo(this.mapaC);
        this.marcador.on('dragend', () => { const p = this.marcador.getLatLng(); this.pos = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6) }; this.guardar(); });
        this.mapaC.on('click', ev => { this.marcador.setLatLng(ev.latlng); this.pos = { lat: +ev.latlng.lat.toFixed(6), lng: +ev.latlng.lng.toFixed(6) }; this.guardar(); });
        if (!this.pos) this.pos = { lat: +centro.lat.toFixed(6), lng: +centro.lng.toFixed(6) };
      } catch (e) { this.error = 'El mapa no cargó: ' + e.message; }
    },
    async usarMiUbicacion() {
      this.buscandoPos = true; const p = await miPosicion(); this.buscandoPos = false;
      if (!p) return (this.error = 'El celular no dio la ubicación. Mueva el pin en el mapa hasta su casa.');
      this.pos = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6) }; this.guardar();
      if (this.mapaC && this.marcador) { this.marcador.setLatLng([p.lat, p.lng]); this.mapaC.setView([p.lat, p.lng], 16); }
    },
    cambiarTipo() { if (this.pedido.tipo === 'domicilio') this.mostrarMapaCarrito(); },
    // ---- códigos: cupón, tarjeta de regalo y puntos ----
    async aplicarCodigo() {
      const cod = this.codigo.trim().toUpperCase(); if (!cod) return; this.error = '';
      try { const r = await this.api('/api/publico/' + SLUG + '/cupon', { codigo: cod, subtotal: this.subtotal, telefono: this.pedido.telefono || null }); this.cupon = { ...r, tope_aplicado: r.descuento }; this.codigo = ''; this.aviso('Cupón ' + r.codigo + ' aplicado'); return; }
      catch (e) { if (e.status === 429) { this.error = e.message; return; } /* no es cupón: se prueba como tarjeta de regalo */ }
      try { this.tarjeta = await this.api('/api/publico/' + SLUG + '/tarjeta/' + encodeURIComponent(cod)); this.codigo = ''; this.aviso('Tarjeta con saldo ' + money(this.tarjeta.saldo)); }
      catch (e) { this.error = e.status === 429 ? e.message : 'El código no es válido o ya no aplica.'; }
    },
    async cargarPuntos() { if (!this.cliente) { this.puntosInfo = null; return; } try { this.puntosInfo = await this.api('/api/publico/' + SLUG + '/puntos'); } catch { this.puntosInfo = null; } },
    // ---- pedido ----
    async enviar() {
      const p = this.pedido; this.error = '';
      if (!this.carrito.length) return (this.error = 'Agrega productos al carrito.');
      if (!p.nombre.trim()) return (this.error = 'Escribe tu nombre');
      if (!/^\d{8}$/.test(p.telefono.replace(/\D/g, '').replace(/^506/, ''))) return (this.error = 'Escribe un teléfono de Costa Rica de 8 dígitos, con 506 opcional.');
      if (p.tipo === 'domicilio' && !p.direccion.trim()) return (this.error = 'Indica la dirección de entrega');
      if (p.tipo === 'domicilio' && this.conZonas && !this.pos) return (this.error = 'Marca tu ubicación en el mapa');
      if (this.fueraZona) return (this.error = 'Tu ubicación está fuera de las zonas de entrega: elige «recoger» o escríbenos por WhatsApp');
      if (!this.abierto) return (this.error = (this.d.abierto.motivo || 'El negocio está cerrado por ahora') + ': puedes ver el catálogo, pero no recibimos pedidos.');
      if (this.minimoFalta > 0) return (this.error = 'Pedido mínimo ' + money(this.d.minimo_pedido) + ': faltan ' + money(this.minimoFalta) + '.');
      const direccion = p.tipo === 'recoger' ? '' : (p.direccion.trim() + (p.referencia.trim() ? ' · Ref: ' + p.referencia.trim() : '')).slice(0, 200);
      const notaPago = !this.conTarjeta && !this.conSinpe && !this.conCredito && p.pago && p.pago !== 'Efectivo' ? ('Pago: ' + p.pago) : '';
      this.enviando = true;
      try {
        const r = await this.api('/api/publico/' + SLUG + '/pedido', { nombre: p.nombre.trim(), telefono: p.telefono, tipo: p.tipo, direccion, nota: [notaPago, p.nota.trim()].filter(Boolean).join(' · ').slice(0, 300), hora_programada: p.hora || null,
          lineas: this.carrito.map(l => ({ producto_id: l.id, cantidad: l.cantidad, nota: l.nota || null, opciones: l.opciones || [] })), clave_peticion: this.clavePeticion, lat: p.tipo === 'domicilio' && this.pos ? this.pos.lat : null, lng: p.tipo === 'domicilio' && this.pos ? this.pos.lng : null,
          cupon: this.cupon ? this.cupon.codigo : null, puntos: this.puntosCanje.puntos || null, tarjeta: this.tarjeta ? this.tarjeta.codigo : null,
          correo: (p.correo || '').trim() || null, pagar_tarjeta: this.conTarjeta, pago: this.conTarjeta ? 'tarjeta' : this.conSinpe ? 'sinpe' : this.conCredito ? 'credito' : 'recibir' });
        this.carrito = []; this.cupon = null; this.tarjeta = null; this.usarPuntos = false; this.clavePeticion = uuid(); this.guardar(); this.cerrarCarrito();
        if (r.pago_url) { this.evento('pago', { valor: r.total, numero: r.numero }); location.href = r.pago_url; return; }
        this.evento('pedido', { valor: r.total, numero: r.numero });
        this.resultado = r; this.cargarPuntos();
        if (r.whatsapp) { try { window.open(r.whatsapp, '_blank', 'noopener'); } catch { /* el enlace queda en el aviso */ } }
      } catch (e) {
        // 4.40: rechazo por existencias, agotado o producto fuera del catálogo: se recarga el catálogo para marcar el carrito y se muestra el mensaje que llega
        if (e.status === 400 && /unidades suficientes|agotado por ahora|ya no está en el catálogo/.test(e.message)) await this.cargar(true);
        this.error = e.message;
      }
      this.enviando = false;
    },
    irSeguimiento(token) { this.resultado = null; location.hash = 'pedido=' + token; },
    async verSeguimiento(token) {
      this.vista = 'seguimiento'; this.seg = null; this.seguimiento = token; if (this.mapaS) { this.mapaS.remove(); this.mapaS = null; this.capasS = []; }
      try { this.seg = await this.api('/api/publico/' + SLUG + '/pedido/' + token); this.mostrarMapaSeg(); } catch (e) { this.error = e.message; }
      clearInterval(this._s); this._s = setInterval(async () => { if (this.vista !== 'seguimiento') return clearInterval(this._s); try { this.seg = await this.api('/api/publico/' + SLUG + '/pedido/' + token); this.mostrarMapaSeg(); } catch { /* reintenta luego */ } }, 20000);
    },
    async mostrarMapaSeg() {
      await this.$nextTick(); const el = this.$refs.mapaS; const s = this.seg; if (!el || !s || !s.lat) return;
      try {
        if (!this.mapaS) this.mapaS = await crearMapa(el, { lat: s.lat, lng: s.lng }, 15);
        const L = window.L; for (const c of this.capasS) c.remove(); this.capasS = [];
        this.capasS.push(L.marker([s.lat, s.lng]).addTo(this.mapaS).bindTooltip('Tu ubicación'));
        const pos = s.entrega && s.entrega.posicion;
        if (pos) { this.capasS.push(L.circleMarker([pos.lat, pos.lng], { radius: 8, color: '#1d4ed8', fillOpacity: .9 }).addTo(this.mapaS).bindTooltip('🛵 ' + (s.entrega.motorizado ? s.entrega.motorizado.nombre : 'Motorizado'))); this.mapaS.fitBounds([[s.lat, s.lng], [pos.lat, pos.lng]], { padding: [30, 30] }); }
      } catch { /* sin mapa */ }
    },
    async subirSinpe(token) {
      if (!this.sinpeArchivo) return (this.error = 'Elige la foto o el PDF del comprobante');
      if (this.sinpeArchivo.size > 5 * 1024 * 1024) return (this.error = 'El comprobante puede pesar hasta 5 MB');
      this.subiendoSinpe = true; this.error = '';
      try {
        const fd = new FormData(); fd.append('archivo', this.sinpeArchivo, this.sinpeArchivo.name); fd.append('referencia', this.sinpeRef || '');
        const r = await fetch('/api/publico/' + SLUG + '/pedido/' + token + '/sinpe', { method: 'POST', body: fd });
        const j = await r.json().catch(() => null);
        if (!r.ok) throw new Error((j && (typeof j.detail === 'string' ? j.detail : j.detail && j.detail.mensaje)) || 'No se pudo subir el comprobante');
        this.seg = j; this.sinpeArchivo = null; this.sinpeRef = ''; this.aviso('Comprobante enviado');
      } catch (e) { this.error = e.message; }
      this.subiendoSinpe = false;
    },
    async pagarAhora() {
      if (!this.seg) return; this.pagando = true; this.error = '';
      try { const r = await this.api('/api/publico/' + SLUG + '/pedido/' + this.seg.token + '/pagar', {}); if (r.pago_url) { location.href = r.pago_url; return; } this.seg = r; this.aviso('El pago ya estaba aprobado'); }
      catch (e) { this.error = e.message; }
      this.pagando = false;
    },
    indiceEstado(e) { return ESTADOS.findIndex(x => x[0] === e); },
    claseEntrega(e) { return e === 'entregada' ? 'ok' : e === 'cancelada' || e === 'incidencia' ? 'danger' : e === 'pendiente' || e === 'liberada' ? 'warn' : 'info'; },
    claseEstado(e) { return e === 'listo' || e === 'entregado' ? 'ok' : e === 'cancelado' ? 'danger' : e === 'nuevo' ? 'warn' : 'info'; },
    // ---- cuenta del cliente ----
    async entrar() {
      const a = this.acceso; a.error = '';
      try {
        const r = await this.api('/api/publico/' + SLUG + '/cliente/acceso', { telefono: a.telefono, pin: a.pin, nombre: a.nuevo ? a.nombre : null, codigo: (a.codigo || '').trim() || null });
        this.cliente = { token: r.token, nombre: r.nombre, telefono: r.telefono }; this.pedido.nombre = this.pedido.nombre || r.nombre; this.pedido.telefono = r.telefono; this.guardar(); a.pin = ''; this.cargarPuntos(); this.verMios();
        if (this.mayorista || this.privado || (this.d && this.d.mayorista_mixto)) { await this.cargar(); this.vista = 'catalogo'; location.hash = 'catalogo'; }   /* 3.91: modo mixto */   // 3.79: ya con los precios de su lista
      } catch (e) { if (e.codigo === 'nuevo') a.nuevo = true; a.error = e.message; }
    },
    async verMios() { this.mios = null; try { this.mios = await this.api('/api/publico/' + SLUG + '/mis-pedidos'); this.cargarPuntos(); } catch (e) { if (/Ingrese/.test(e.message)) { this.cliente = null; this.guardar(); } else this.error = e.message; } },
    salir() { this.cliente = null; this.mios = null; this.puntosInfo = null; this.usarPuntos = false; this.pedido.nombre = ''; this.pedido.telefono = ''; this.pedido.correo = ''; this.pedido.direccion = ''; if ('referencia' in this.pedido) this.pedido.referencia = ''; if (this.acceso) this.acceso.telefono = ''; this.guardar();   /* 3.87: en un equipo compartido no queda nada de la clienta */ if (this.mayorista) { this.carrito = []; this.cargar(); } location.hash = 'catalogo'; },
    // repetir un pedido anterior (3.79): las mismas líneas con los precios de hoy; lo que ya no está en el catálogo se omite
    repetir(p) {
      let n = 0;
      for (const l of p.lineas || []) {
        const i = (this.d.items || []).find(x => x.id === l.producto_id); if (!i || i.agotado) continue;
        const q = Math.max(1, Math.round(+l.cantidad || 1)); const e = this.carrito.find(x => x.id === i.id && !x.nota && !x.clave);
        if (e) e.cantidad += q; else this.carrito.push({ id: i.id, nombre: i.nombre, precio: i.precio, cantidad: q, nota: '', foto: i.foto, unidad: i.unidad, opciones: [], opcionesTxt: '', clave: '' });
        n += q;
      }
      if (!n) return (this.error = 'Los productos de ese pedido ya no están en el catálogo.');
      this.error = ''; this.aviso('✓ ' + n + ' producto(s) agregados al carrito'); location.hash = 'catalogo'; this.$nextTick(() => this.abrirCarrito());
    },
    usarDireccion(x) { this.pedido.direccion = x.detalle; this.pedido.tipo = 'domicilio'; location.hash = 'catalogo'; this.$nextTick(() => this.abrirCarrito()); },
    async guardarDireccion() {
      const det = this.dirNueva.detalle.trim(); if (!det) return (this.error = 'Nombre y dirección son obligatorios.');
      try { const r = await this.api('/api/publico/' + SLUG + '/cliente/direcciones', { direcciones: [...(this.mios.direcciones || []), { nombre: this.dirNueva.nombre.trim() || 'Dirección ' + ((this.mios.direcciones || []).length + 1), detalle: det }] }, 'PUT'); this.mios.direcciones = r.direcciones; this.dirNueva = { nombre: 'Casa', detalle: '' }; this.aviso('Dirección guardada.'); }
      catch (e) { this.error = e.message; }
    },
    async borrarDireccion(i) { try { const r = await this.api('/api/publico/' + SLUG + '/cliente/direcciones', { direcciones: (this.mios.direcciones || []).filter((_, k) => k !== i) }, 'PUT'); this.mios.direcciones = r.direcciones; this.aviso('Dirección eliminada.'); } catch (e) { this.error = e.message; } },
    // ---- contacto y FISIChat ----
    async enviarContacto() {
      const c = this.contacto; this.error = '';
      try { await this.api('/api/publico/' + SLUG + '/contacto', { nombre: c.nombre, correo: c.correo, telefono: c.telefono, asunto: c.asunto, mensaje: c.mensaje }); this.contactoEnviado = true; this.contacto = { nombre: '', correo: '', telefono: '', asunto: '', mensaje: '' }; }
      catch (e) { this.error = e.message; }
    },
    abrirChat() { this.chat = !this.chat; if (this.chat && !this.chatMsgs.length) this.chatMsgs.push({ rol: 'asistente', texto: 'Hola. Te ayudo con el catálogo, tus pedidos, horarios y contacto de ' + this.d.nombre + '. ¿Qué necesitas?' }); },
    respuestaFija(t) {
      const q = t.toLowerCase();
      if (/horario|abierto|cierra|abre|contacto|tel|whatsapp/.test(q)) return (this.aj.horario_texto ? 'Horario: ' + this.aj.horario_texto + '. ' : '') + (this.d.whatsapp ? 'WhatsApp: ' + this.telFmt(this.d.whatsapp) + '. ' : '') + (this.d.direccion ? 'Estamos en ' + this.d.direccion + '.' : '') || 'Escríbenos por WhatsApp y te atendemos.';
      if (/pedido|pedir|comprar|carrito|cómo/.test(q)) return 'Elige una categoría en el catálogo, agrega los productos al carrito y envía el pedido: te damos un número y un enlace para seguirlo. Puedes recoger o recibirlo a domicilio.';
      const cats = (this.d.categorias || []).map(c => c.nombre).join(', ');
      return cats ? 'Tenemos ' + this.d.items.length + ' productos en ' + cats + '. Abre el catálogo para verlos con sus precios.' : 'Abre el catálogo para ver los productos y sus precios.';
    },
    async preguntar(texto) {
      const t = (texto || this.chatTxt || '').trim(); if (!t || this.chatCargando) return;
      const historial = this.chatMsgs.slice(1).slice(-8).map(m => ({ rol: m.rol, texto: m.texto }));
      this.chatMsgs.push({ rol: 'cliente', texto: t }); this.chatTxt = ''; this.chatCargando = true;
      try { const r = this.d.ia ? await this.api('/api/publico/' + SLUG + '/ia', { pregunta: t, historial }) : { respuesta: this.respuestaFija(t) }; this.chatMsgs.push({ rol: 'asistente', texto: r.respuesta }); }
      catch (e) { this.chatMsgs.push({ rol: 'asistente', texto: 'No pude responder ahora (' + e.message + '). Escríbenos por WhatsApp.' }); }
      this.chatCargando = false; this.$nextTick(() => { const el = this.$refs.chatLista; if (el) el.scrollTop = el.scrollHeight; });
    },
  },
  mounted() { this.cargar(); this.cargarPuntos(); window.addEventListener('hashchange', this.enrutar); if (this.vista === 'inicio' && leerHash().ancla) this.enrutar(); },
  template: `
  <div v-if="d">
    <!-- ===== Portada del negocio (r2_landing) ===== -->
    <div class="r2-landing" v-if="vista==='inicio'">
      <header class="r2-public-nav"><a class="r2-wordmark" href="#inicio"><img v-if="d.logo" :src="d.logo" :alt="d.nombre"><template v-else>{{d.nombre}}</template></a><nav><a href="#inicio">Inicio</a><a href="#nosotros">Nosotros</a><a href="#servicios">Productos</a><a href="#contacto">Contacto</a><a class="btn" href="#catalogo">Ver {{etiquetaMin}}</a></nav></header>
      <main>
        <section id="inicio" class="r2-hero"><img v-if="ds.hero_image" :src="ds.hero_image" alt=""><div><h1>{{ds.hero_title}}</h1><p style="white-space:pre-line">{{ds.hero_text}}</p><a class="btn" href="#catalogo">{{ds.hero_button_label || 'Ver catálogo o menú'}}</a><a class="r2-outline" href="#nosotros">Conoce nuestro negocio</a></div></section>
        <section id="nosotros" class="r2-about"><img v-if="ds.about_image" :src="ds.about_image" alt=""><div v-else class="r2-about-placeholder">{{d.nombre}}</div><div><small>{{ds.about_label}}</small><h2>{{ds.about_title}}</h2><p style="white-space:pre-line">{{aboutText}}</p><div class="r2-promises"><span v-for="p in promesas" :key="p">{{p}}</span></div><a class="btn" href="#catalogo">{{ds.about_button_label}}</a></div></section>
        <section id="servicios" class="r2-services"><h2>{{ds.services_title}}</h2><div class="r2-service-grid"><article v-for="s in servicios" :key="s.i"><img v-if="s.img" :src="s.img" alt=""><div><h3>{{s.t}}</h3><p>{{s.x}}</p><a :href="s.i === 2 ? wa : '#catalogo'" :target="s.i === 2 && wa.startsWith('http') ? '_blank' : null">{{s.i === 2 ? 'Consultar' : 'Ver productos'}} →</a></div></article></div><p class="r3-business-catalog"><a class="btn" href="#catalogo">{{ds.catalog_button_label || 'Ver catálogo completo →'}}</a></p></section>
        <section id="contacto" class="r2-contact"><div><small>CONTACTO</small><h2>{{ds.contact_title}}</h2><p style="white-space:pre-line">{{ds.contact_text || aj.horario_texto}}</p><p v-if="d.direccion">⌖ {{d.direccion}}</p><p v-if="d.telefono">☎ <a :href="'tel:' + tel(d.telefono)">{{d.telefono}}</a></p><p v-if="aj.correo_contacto"><a :href="'mailto:' + aj.correo_contacto">{{aj.correo_contacto}}</a></p><p v-if="aj.horario_texto">◷ {{aj.horario_texto}}</p><a class="btn" v-if="wa.startsWith('http')" :href="wa" target="_blank" rel="noopener">Escríbenos por WhatsApp</a></div>
          <div><iframe v-if="mapaSrc" :src="mapaSrc" loading="lazy" title="Mapa" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <form class="card admin-card" @submit.prevent="enviarContacto" style="margin-top:14px"><h3>Escríbenos</h3><p v-if="contactoEnviado" class="msg ok">Gracias. Recibimos tu mensaje y te contactamos pronto.</p><div class="split"><div class="form-group"><label>Nombre</label><input class="input" v-model="contacto.nombre" maxlength="120" required></div><div class="form-group"><label>Teléfono</label><input class="input" v-model="contacto.telefono" maxlength="12" inputmode="numeric"></div></div><div class="form-group"><label>Correo</label><input class="input" type="email" v-model="contacto.correo" maxlength="120"></div><div class="form-group"><label>Asunto</label><input class="input" v-model="contacto.asunto" maxlength="150"></div><div class="form-group"><label>Mensaje</label><textarea class="input" v-model="contacto.mensaje" maxlength="4000" required rows="3"></textarea></div><p class="msg err" v-if="error">{{error}}</p><button class="btn btn-light">Enviar mensaje</button></form></div></section>
      </main>
      <footer><strong>{{d.nombre}}</strong><span>Catálogo / Menú</span><a v-for="r in redesPie" :key="r.label" :href="r.href" rel="noopener" target="_blank">{{r.label}}</a><a :href="d.plataforma || '/'" class="r2-platform-offer" rel="noopener"><img src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP" style="width:110px;max-height:40px;object-fit:contain"><span>¿Quieres vender con FISITAAP?</span></a></footer>
    </div>

    <!-- ===== Tienda: catálogo, cuenta y seguimiento (catalog_page_v6 + customer_account_page_v1 + op180_order_detail) ===== -->
    <div v-else :data-tenant="d.slug">
      <header class="topbar"><div class="container nav"><a class="brand" href="#inicio"><img v-if="d.logo" class="brand-logo" :src="d.logo" alt=""><span v-else class="brand-mark">{{d.nombre.slice(0, 1)}}</span><span>{{d.nombre}}</span></a>
        <nav class="nav-links"><a href="#inicio">Inicio</a><a href="#catalogo" data-catalog-nav :class="{active: vista === 'catalogo'}">{{d.etiqueta}}</a><a href="#cuenta" class="r11-customer-login" :class="{active: vista === 'cuenta'}">{{cliente ? 'Mi cuenta' : 'Mis pedidos'}}</a></nav>
        <button class="icon-btn nav-cart" type="button" data-open-cart aria-label="Ver carrito" @click="abrirCarrito">🛒<span class="nav-cart-count" v-if="cantidadCarrito">{{cantidadCarrito}}</span></button>
        <button class="icon-btn mobile-menu-toggle" type="button" data-mobile-menu-toggle :aria-expanded="menu" aria-label="Abrir menú" @click="menu = !menu"><span>{{menu ? '×' : '☰'}}</span></button></div>
        <div class="mobile-menu-panel" data-mobile-menu :hidden="!menu"><div class="container mobile-menu-inner"><a href="#inicio" @click="menu = false">Inicio</a><a href="#catalogo" @click="menu = false">{{d.etiqueta}}</a><a href="#cuenta" @click="menu = false">Mi cuenta</a><a href="#contacto" @click="menu = false">Contacto</a><form v-if="cliente" @submit.prevent="menu = false; salir()"><button class="mobile-menu-action" data-cerrar-sesion>Cerrar sesión</button></form></div></div></header>
      <main>
        <!-- catálogo -->
        <template v-if="vista === 'catalogo'">
          <section class="branch-current"><div class="container"><div><small>Sucursal</small><strong>{{d.nombre}}</strong></div><span class="badge" :class="abierto ? 'ok' : 'danger'">{{abierto ? 'Abierto' : (d.abierto.motivo || 'Cerrado')}}</span></div></section>
          <section class="hero catalog-hero"><div class="container">
            <header class="r15-catalog-heading"><h1>{{mayorista ? 'Catálogo para revendedoras' : 'Tu tienda, cerca de ti.'}}</h1><p>{{d.nombre}}<span v-if="mayorista && d.cliente"> · {{d.cliente.nombre}}{{d.cliente.lista ? ' · precios de la lista ' + d.cliente.lista : ''}}</span> · {{[d.acepta.recoger ? 'retiro' : '', d.acepta.domicilio ? 'entrega a domicilio' : ''].filter(Boolean).join(' y ') || 'pedidos en línea'}}</p></header>
            <div class="slider" v-if="ds.catalog_intro_mode !== 'hidden'" :data-slider-seconds="ds.catalog_slide_seconds">
              <article v-for="(sl, i) in slides" :key="i" class="slide adaptive-slide" :class="{active: i === slide, 'slide-no-image': !sl.image, 'slide-solo-imagen': sl.image && !sl.title && !sl.body}"><template v-if="sl.image"><img class="slide-blur" :src="sl.image" decoding="async" alt="" aria-hidden="true"><img class="slide-image" :src="sl.image" decoding="async" alt=""></template><span class="slide-shade" style="background:none"></span><div class="slide-content" :style="{'--catalog-text-color': ds.catalog_text_color, color: ds.catalog_text_color}"><h1 v-if="sl.title">{{sl.title}}</h1><p v-if="sl.body">{{sl.body}}</p></div></article>
              <div class="slider-dots" v-if="slides.length > 1"><button v-for="(sl, i) in slides" :key="'d' + i" class="slider-dot" :class="{active: i === slide}" type="button" :aria-label="'Promoción ' + (i + 1)" @click="slide = i"></button></div>
            </div>
            <section class="category-launcher r15-catalog-filter" data-category-launcher><div class="r15-catalog-chips"><button type="button" class="chip" :class="{active: !cat}" @click="cat = ''">Todos</button><button v-for="c in d.categorias" :key="c.nombre" type="button" class="chip" :class="{active: cat === c.nombre}" @click="cat = c.nombre">{{c.nombre}}</button></div><input id="catalogSearch" class="search" v-model="q" placeholder="Buscar tu favorito…" aria-label="Buscar productos"></section>
            <div class="catalog-results" data-catalog-results><div class="catalog-selection-title" data-catalog-title><span class="tag">CATEGORÍA</span><h2>{{cat || 'Todos'}}</h2></div></div>
            <div class="grid grid-4 catalog-products" data-catalog-products>
              <article v-for="i in items" :key="i.id" class="card product-card" :data-category="i.categoria"><div class="product-gallery"><img class="product-img" data-gallery-main loading="lazy" :src="i.foto || PLACEHOLDER" decoding="async" :alt="i.nombre" @error="sinFoto"></div><div class="product-info"><span v-if="i.destacado" class="tag">DESTACADO</span><span v-if="i.promo" class="tag combo-tag">{{i.promo.etiqueta.toUpperCase()}}</span><h3>{{i.nombre}}</h3><p class="muted">{{i.descripcion}}</p><div class="product-price">{{money(i.precio)}} <s v-if="i.promo && i.promo.precio_antes" style="font-size:.7em;opacity:.6">{{money(i.promo.precio_antes)}}</s></div><div class="product-meta">Por {{(i.unidad || 'unidad').toLowerCase()}} · IVA incluido<span v-if="enCarrito(i)"> · {{enCarrito(i)}} en el carrito</span></div><div class="qty-row"><input data-qty class="qty" type="number" min="1" step="1" v-model.number="cant[i.id]" :disabled="i.agotado" aria-label="Cantidad"><button class="btn btn-block" type="button" :disabled="i.agotado" @click="i.modificadores && i.modificadores.length ? personalizar(i) : agregarDirecto(i)">{{i.agotado ? 'Agotado' : 'Agregar al carrito'}}</button></div></div></article>
              <div class="card empty" v-if="!items.length">{{q ? 'Nada que mostrar para «' + q + '».' : 'Todavía no hay productos publicados.'}}</div>
            </div>
          </div></section>
          <section class="section" v-if="d.nota_cliente || conHorario"><div class="container"><div class="split"><div class="card admin-card" v-if="d.nota_cliente"><h3>Antes de pedir</h3><p>{{d.nota_cliente}}</p></div><div class="card admin-card" v-if="conHorario"><h3>Horario</h3><p v-for="h in horariosTexto" :key="h.dia">{{h.dia}}: {{h.txt}}</p></div></div></div></section>
        </template>

        <!-- cuenta del cliente (3.87: «Cerrar sesión» va en «Datos de mi cuenta» y en el menú ☰; la tarjeta lateral account-nav la ocultan las hojas de FISITAAP en todos los anchos) -->
        <template v-else-if="vista === 'cuenta'">
          <main class="auth-page" v-if="!cliente"><section class="card auth-card"><h1>{{privado ? 'Catálogo para revendedoras' : 'Mi cuenta'}}</h1><p v-if="privado">Este catálogo es privado. Entra con tu teléfono registrado, una clave de 4 a 8 dígitos y, la primera vez, tu código personal (te lo envía {{d.nombre}} a tu celular). Verás los precios de tu lista y podrás repetir pedidos.</p><p v-else>Con tu teléfono y una clave de 4 a 8 dígitos ves tus pedidos en {{d.nombre}} y guardas direcciones. No es una contraseña del sistema.</p>
            <form @submit.prevent="entrar"><div class="form-group"><label>Teléfono</label><input class="input" v-model="acceso.telefono" inputmode="numeric" maxlength="12" required></div><div class="form-group"><label>Clave</label><input class="input" type="password" v-model="acceso.pin" inputmode="numeric" maxlength="8" required></div><div class="form-group" v-if="privado || mayorista || (d && d.mayorista_mixto)"><label>Código de acceso<span v-if="d && d.mayorista_mixto && !mayorista"> (solo revendedoras)</span></label><input class="input" v-model="acceso.codigo" maxlength="40" style="text-transform:uppercase" placeholder="Tu código personal (solo la primera vez)" autocomplete="off"></div><div class="form-group" v-if="acceso.nuevo"><label>Tu nombre (para crear el acceso)</label><input class="input" v-model="acceso.nombre" maxlength="60" required></div><p class="msg err" v-if="acceso.error">{{acceso.error}}</p><button class="btn btn-block">{{acceso.nuevo ? 'Crear mi acceso' : 'Ingresar'}}</button></form><p><a href="#catalogo">Volver al {{etiquetaMin}}</a></p></section></main>
          <div class="r15-customer-page t-cuenta" v-else><div class="container account-layout r11-phone-account">
            <aside class="card admin-card account-nav"><h2>Mi cuenta</h2><p>{{cliente.nombre}}<br><small class="muted">{{cliente.telefono}}</small></p><a class="btn btn-light btn-block" href="#cuenta">Mis pedidos</a><a class="btn btn-light btn-block" href="#fidelizacion" v-if="puntosInfo && puntosInfo.activo">Mi fidelización</a><form @submit.prevent="salir" style="margin-top:10px"><button class="btn btn-light btn-block">Cerrar sesión</button></form></aside>
            <section><p class="msg err" v-if="error">{{error}}</p>
              <section class="card admin-card" v-if="mios && mios.cuenta"><h1>Mi cuenta de revendedora</h1><p>{{mios.cuenta.nombre}}<span v-if="mios.cuenta.lista"> · precios de la lista {{mios.cuenta.lista}}</span></p>
                <div class="split" v-if="mios.cuenta.credito.permitido"><div><small class="muted">Límite de crédito</small><br><strong>{{money(mios.cuenta.credito.limite)}}</strong></div><div><small class="muted">Saldo (facturado + pedidos en curso)</small><br><strong>{{money(mios.cuenta.credito.saldo + mios.cuenta.credito.en_pedidos)}}</strong></div><div><small class="muted">Disponible</small><br><strong>{{money(mios.cuenta.credito.disponible)}}</strong></div></div>
                <p class="muted" v-else>Sin crédito asignado: los pedidos se pagan al recibir o por SINPE Móvil.</p>
                <div class="table-wrap" v-if="mios.cuenta.credito.documentos.length"><table class="table"><tr><th>Documento</th><th>Fecha</th><th>Total</th><th>Saldo</th></tr><tr v-for="x in mios.cuenta.credito.documentos" :key="x.consecutivo"><td>{{x.consecutivo}}</td><td>{{x.fecha}}</td><td>{{money(x.total)}}</td><td>{{money(x.saldo)}}</td></tr></table></div></section>
              <section class="card admin-card"><h1>Mis pedidos</h1><p>Cliente: {{cliente.nombre}}</p><div class="table-wrap"><table class="table r11-customer-orders"><tr><th>Pedido</th><th>Negocio</th><th>Total</th><th>Estado</th><th>PIN de entrega</th><th>Fecha</th><th></th></tr>
                <tr v-for="p in (mios ? mios.pedidos : [])" :key="p.id"><td>#{{p.numero}}</td><td>{{d.nombre}}</td><td>{{money(p.total)}}</td><td><span class="status">{{p.estado_nombre}}</span></td><td><strong>{{p.entrega && p.entrega.pin ? p.entrega.pin : '—'}}</strong></td><td>{{fechaCorta(p.creado)}}</td><td><a class="btn btn-light" :href="'#pedido=' + p.token">Ver trazabilidad</a> <button class="btn btn-light" type="button" @click="repetir(p)">Repetir</button></td></tr>
                <tr v-if="mios && !mios.pedidos.length"><td colspan="7">Todavía no tienes pedidos.</td></tr><tr v-if="!mios"><td colspan="7">Cargando…</td></tr></table></div></section>
              <section id="fidelizacion" class="loyalty-customer" v-if="puntosInfo && puntosInfo.activo"><div class="section-head loyalty-head"><div><span class="tag">BENEFICIOS</span><h2>Mi fidelización</h2><p class="muted">Tus avances se acreditan cuando cada pedido queda entregado.</p></div></div>
                <div class="loyalty-wallet"><article class="loyalty-digital-card" :style="{'--card-primary': d.color, '--card-accent': ds.accent_color}"><header><img v-if="d.logo" :src="d.logo" alt=""><span v-else class="loyalty-brand-mark">F</span><div><strong>{{d.nombre}}</strong><small>{{puntosInfo.nombre}}</small></div></header><div class="loyalty-card-main"><span>Tu progreso</span><strong>{{Math.round(puntosInfo.saldo)}} <small>puntos</small></strong><div class="loyalty-progress" role="progressbar"><i :style="{width: Math.min(100, puntosInfo.minimo_canje ? puntosInfo.saldo / puntosInfo.minimo_canje * 100 : 100) + '%'}"></i></div><p>Equivalen a <b>{{money(puntosInfo.valor)}}</b>. Canje mínimo {{puntosInfo.minimo_canje}} puntos; los usas al pedir, en el carrito.</p></div><footer><span>Gana {{puntosInfo.puntos_por_mil}} por cada ₡1.000</span><code>{{cliente.telefono}}</code></footer></article></div></section>
              <div id="perfil" class="split" style="margin-top:20px"><section class="card admin-card"><h2>Datos de mi cuenta</h2><div class="form-group"><label>Nombre</label><input class="input" :value="cliente.nombre" readonly></div><div class="form-group"><label>Teléfono</label><input class="input" :value="cliente.telefono" readonly></div><p>Usuario: {{cliente.telefono}}</p><form @submit.prevent="salir" style="margin-top:10px"><button class="btn btn-light btn-block" data-cerrar-sesion>Cerrar sesión</button></form></section>
                <section class="card admin-card"><h2>Nueva dirección</h2><form @submit.prevent="guardarDireccion"><div class="form-group"><label>Nombre</label><input class="input" v-model="dirNueva.nombre" maxlength="40" required></div><div class="form-group"><label>Dirección</label><textarea class="input" v-model="dirNueva.detalle" maxlength="200" required></textarea></div><button class="btn btn-block" style="margin-top:12px">Guardar dirección</button></form></section></div>
              <section class="card admin-card" style="margin-top:20px"><h2>Direcciones guardadas</h2><article class="address-row" v-for="(x, i) in (mios ? mios.direcciones : [])" :key="i"><div><strong>{{x.nombre || 'Dirección'}}</strong><p>{{x.detalle}}</p><a v-if="x.enlace" :href="x.enlace" target="_blank" rel="noopener noreferrer">Abrir en Google Maps</a></div><form @submit.prevent="borrarDireccion(i)"><button class="btn btn-light" type="button" @click="usarDireccion(x)">Usar</button> <button class="btn btn-danger">Eliminar</button></form></article><p class="muted" v-if="mios && !(mios.direcciones || []).length">Todavía no guardaste direcciones.</p></section>
            </section></div></div>
        </template>

        <!-- seguimiento del pedido -->
        <template v-else-if="vista === 'seguimiento'">
          <main class="container section"><section class="card admin-card" data-live-region="order-detail" v-if="seg"><h2>{{d.nombre}} · Pedido #{{seg.numero}}</h2><p>Estado actual: <strong>{{seg.entrega && !['cancelada','entregada'].includes(seg.entrega.estado) ? seg.entrega.estado_nombre : seg.estado_nombre}}</strong></p>
            <div class="t-estados" v-if="seg.estado !== 'cancelado'"><span v-for="(e, i) in ESTADOS" :key="e[0]" :class="{on: i <= indiceEstado(seg.estado)}">{{e[1]}}</span></div><p class="msg err" v-else>Cancelado{{seg.motivo ? ': ' + seg.motivo : ''}}</p>
            <p>{{seg.nombre}} · {{seg.telefono}}</p><p>{{seg.tipo_nombre}}{{seg.direccion ? ' · ' + seg.direccion : ''}}{{seg.hora_programada ? ' · para las ' + seg.hora_programada : ''}}</p>
            <div class="op180-pin" v-if="pinSeg && seg.tipo !== 'recoger'"><small>PIN PARA RECIBIR EL PEDIDO</small><strong>{{pinSeg}}</strong><p>Guárdalo y compártelo con el motorizado únicamente cuando recibas tu pedido.</p></div>
            <p v-if="seg.entrega && seg.entrega.motorizado">Motorizado: {{seg.entrega.motorizado.nombre}}{{seg.entrega.motorizado.vehiculo_nombre ? ' · ' + seg.entrega.motorizado.vehiculo_nombre : ''}}{{seg.entrega.motorizado.placa ? ' · placa ' + seg.entrega.motorizado.placa : ''}}</p>
            <div ref="mapaS" class="t-mapa" v-if="seg.lat"></div>
            <p class="msg ok" v-if="seg.pago_estado === 'aprobado' && seg.pago_medio !== 'sinpe'">Pagado con tarjeta en línea{{seg.pago_auth ? ' · autorización ' + seg.pago_auth : ''}}.</p>
            <div class="msg err" v-else-if="seg.estado === 'pendiente_pago'">{{seg.pago_estado === 'rechazado' ? 'El pago fue rechazado' + (seg.pago_detalle ? ' (' + seg.pago_detalle + ')' : '') : 'Falta completar el pago'}}. El negocio recibe el pedido cuando el pago se apruebe.<button class="btn btn-block" style="margin-top:8px" type="button" :disabled="pagando" @click="pagarAhora">{{pagando ? 'Abriendo…' : 'Pagar ahora · ' + money(seg.pago_monto)}}</button></div>
            <div class="card admin-card" v-if="sinpePendiente" style="margin:12px 0"><h3>SINPE Móvil · {{money(seg.a_pagar)}}</h3><p v-if="d.sinpe">Transfiere al <b>{{telFmt(d.sinpe.numero)}}</b>{{d.sinpe.nombre ? ' (' + d.sinpe.nombre + ')' : ''}} con el detalle «Pedido {{seg.numero}}» y sube el comprobante.{{seg.pago_estado === 'rechazado' ? ' El negocio no pudo validar el comprobante anterior' + (seg.pago_detalle ? ' (' + seg.pago_detalle + ')' : '') + ': súbelo de nuevo o paga al recibir.' : ''}}</p><p v-if="seg.sinpe && seg.sinpe.comprobante">El negocio revisa el comprobante{{seg.sinpe.referencia ? ' (ref. ' + seg.sinpe.referencia + ')' : ''}} y confirma el pago.</p><div class="form-group"><label>Número de comprobante o referencia (opcional)</label><input class="input" v-model="sinpeRef" maxlength="40" inputmode="numeric"></div><div class="form-group"><label>Foto o PDF del comprobante</label><input class="input" type="file" accept="image/*,.pdf" @change="sinpeArchivo = ($event.target.files && $event.target.files[0]) || null"></div><button class="btn btn-block" type="button" :disabled="subiendoSinpe || !sinpeArchivo" @click="subirSinpe(seg.token)">{{subiendoSinpe ? 'Subiendo…' : (seg.sinpe && seg.sinpe.comprobante ? 'Subir otro comprobante' : 'Enviar el comprobante')}}</button></div>
            <p class="msg ok" v-else-if="seg.pago_medio === 'sinpe' && seg.pago_estado === 'aprobado'">SINPE verificado por el negocio{{seg.sinpe && seg.sinpe.referencia ? ' · ref. ' + seg.sinpe.referencia : ''}}.</p>
            <h3>Productos</h3><div class="table-wrap"><table class="table"><tr><th>Cantidad</th><th>Producto</th><th>Total</th></tr><tr v-for="(l, i) in seg.lineas" :key="i"><td>{{l.cantidad}}</td><td>{{l.detalle}}<small v-if="l.opciones && l.opciones.length"> · {{l.opciones.map(o => o.nombre).join(', ')}}</small><small v-if="l.nota"> · {{l.nota}}</small></td><td>{{money(l.total)}}</td></tr></table></div>
            <p>Subtotal {{money(seg.subtotal + seg.impuestos)}}<span v-if="seg.descuento"> · Cupón {{seg.cupon}} −{{money(seg.descuento)}}</span><span v-if="seg.descuento_puntos"> · Puntos −{{money(seg.descuento_puntos)}}</span><span v-if="seg.envio"> · Envío {{money(seg.envio)}}</span> · <strong>Total {{money(seg.total)}}</strong><span v-if="seg.tarjeta_monto"> · Tarjeta de regalo −{{money(seg.tarjeta_monto)}}</span><span v-if="seg.a_pagar !== seg.total"> · Por pagar al recibir {{money(seg.a_pagar)}}</span></p>
            <h3>Bitácora de tiempos</h3><ol class="op180-timeline"><li v-for="(e, i) in eventosSeg" :key="i"><time>{{fecha(e[0])}}</time><strong>{{e[1]}}</strong></li></ol>
            <p class="msg err" v-if="error">{{error}}</p>
            <a v-if="seg.whatsapp && seg.estado === 'nuevo'" class="btn btn-accent" :href="seg.whatsapp" target="_blank" rel="noopener">Avisar por WhatsApp</a> <a class="btn btn-light" href="#catalogo">Volver al {{etiquetaMin}}</a></section>
          <section class="card admin-card" v-else><p>{{error || 'Buscando el pedido…'}}</p><a class="btn btn-light" href="#catalogo">Volver</a></section></main>
        </template>
      </main>
      <footer class="footer"><div class="container footer-grid"><div><span class="footer-logo-wrap"><img class="footer-logo" :src="d.logo || '/fisitaap/assets/fisitapp-logo.webp'" :alt="d.nombre"></span><p>{{d.descripcion || d.bienvenida}}</p></div><div><strong>Contacto</strong><p v-if="d.direccion">{{d.direccion}}</p><p v-if="d.telefono">Tel. {{d.telefono}}</p><p v-if="d.whatsapp">WhatsApp {{telFmt(d.whatsapp)}}</p><p><a v-for="r in redesPie" :key="r.label" :href="r.href" target="_blank" rel="noopener" style="margin-right:10px">{{r.label}}</a></p></div><div v-if="aj.horario_texto || conHorario"><strong>Horario</strong><p v-if="aj.horario_texto">{{aj.horario_texto}}</p><p v-for="h in horariosTexto" :key="h.dia" v-else>{{h.dia}}: {{h.txt}}</p></div></div><div class="container footer-credit">© {{anio}} {{d.nombre}} · Pedidos en línea con tecnología FISITAAP · FISITAAP by Brillante Agencia</div></footer>

      <!-- carrito en cajón (cart_drawer_v6) -->
      <aside id="cartDrawer" class="drawer" :class="{open: carritoAbierto}"><div class="drawer-bg" data-close-cart @click="cerrarCarrito"></div><div class="drawer-panel"><div class="drawer-head"><div><small>{{d.nombre}}</small><h2>Tu pedido</h2></div><button class="icon-btn" type="button" data-close-cart @click="cerrarCarrito">×</button></div>
        <div id="cartItems"><div class="cart-item" v-for="(l, n) in carrito" :key="n"><div><strong>{{l.nombre}}</strong> <span v-if="lineaAgotada(l)" class="tag" style="background:#fee4e2;color:#912018" data-se-agoto>{{lineaFuera(l) ? 'Ya no está en el catálogo' : 'Se agotó'}}</span><small class="muted"><br><span v-if="l.opcionesTxt">{{l.opcionesTxt}}<br></span>{{money(l.precio)}} / {{(l.unidad || 'unidad').toLowerCase()}}<em v-if="l.nota"><br>{{l.nota}}</em></small></div><input class="input" type="number" min="1" step="1" :value="l.cantidad" @change="cambiarCant(l, $event.target.value)" aria-label="Cantidad"><button class="icon-btn" type="button" @click="quitar(l)">×</button></div><div class="empty" v-if="!carrito.length">Tu carrito está vacío</div><button v-if="agotadosCarrito.length" class="btn btn-danger btn-block" type="button" style="margin-top:12px" @click="quitarAgotados" data-quitar-agotados>Quitar los agotados</button></div>
        <div class="cart-summary"><div class="summary-row"><span>Subtotal estimado</span><strong id="cartSubtotal">{{money(subtotal)}}</strong></div><div class="summary-row" v-if="descuentoCupon"><span>Cupón {{cupon.codigo}}</span><strong>−{{money(descuentoCupon)}}</strong></div><div class="summary-row" v-if="puntosCanje.descuento"><span>{{puntosCanje.puntos}} {{puntosInfo.nombre.toLowerCase()}}</span><strong>−{{money(puntosCanje.descuento)}}</strong></div><div class="summary-row" v-if="envio"><span>Envío</span><strong>{{money(envio)}}</strong></div><div class="summary-row" v-if="montoTarjeta"><span>Tarjeta de regalo</span><strong>−{{money(montoTarjeta)}}</strong></div><div class="summary-row"><span><b>Total</b></span><strong>{{money(aPagar)}}</strong></div><small class="muted">IVA incluido. {{minimoFalta ? 'Pedido mínimo ' + money(d.minimo_pedido) + ': faltan ' + money(minimoFalta) + '.' : 'El negocio confirma el envío y el tiempo.'}}</small></div>
        <form id="checkoutForm" @submit.prevent="enviar">
          <div class="split"><div class="form-group"><label>Tu nombre</label><input class="input" v-model="pedido.nombre" maxlength="60" required></div><div class="form-group"><label>Teléfono</label><input class="input" v-model="pedido.telefono" inputmode="numeric" maxlength="12" required></div></div>
          <div class="form-group"><label>Forma de pago</label><select class="input" v-model="pedido.pago" required><option v-for="m in metodosPago" :key="m">{{m}}</option></select></div>
          <p class="muted" v-if="conTarjeta">Pagas en la página segura de Tilopay y vuelves aquí con el pedido confirmado.</p>
          <p class="msg info" v-if="conSinpe">Haz el SINPE Móvil por <b>{{money(aPagar)}}</b> al <b>{{telFmt(d.sinpe.numero)}}</b>{{d.sinpe.nombre ? ' (' + d.sinpe.nombre + ')' : ''}}. Al enviar el pedido podrás subir la foto del comprobante.</p>
          <p class="msg info" v-if="conCredito">Se carga a tu cuenta de revendedora. Crédito disponible: <b>{{money(credito.disponible)}}</b>.</p>
          <div class="form-group"><label>Tipo de entrega</label><select class="input" v-model="pedido.tipo" @change="cambiarTipo"><option v-for="t in tipos" :key="t[0]" :value="t[0]">{{t[1]}}</option></select></div>
          <fieldset data-delivery-fields style="border:0;padding:0;margin:0;min-width:0" v-if="pedido.tipo !== 'recoger'">
            <template v-if="pedido.tipo === 'domicilio' && d.mapa"><div class="form-group"><label>Zona de envío</label><div ref="mapaC" class="t-mapa"></div><div class="split"><button class="btn btn-light" type="button" @click="usarMiUbicacion" :disabled="buscandoPos">{{buscandoPos ? 'Buscando…' : 'Usar mi ubicación'}}</button><small class="muted" v-if="conZonas && zonaSel">Zona {{zonaSel.nombre}} · envío {{money(zonaSel.precio)}}{{zonaSel.tiempo ? ' · ' + zonaSel.tiempo : ''}}</small><small class="muted" v-else-if="fueraZona" style="color:#912018">Fuera de las zonas de entrega</small><small class="muted" v-else>Mueve el pin hasta tu casa</small></div></div></template>
            <div class="form-group" v-if="mios && mios.direcciones && mios.direcciones.length"><label>Dirección guardada</label><select class="input" @change="pedido.direccion = $event.target.value"><option value="">Escribir otra dirección</option><option v-for="(x, i) in mios.direcciones" :key="i" :value="x.detalle">{{x.nombre || 'Dirección'}} · {{x.detalle}}</option></select></div>
            <div class="form-group"><label>Dirección</label><textarea class="input" v-model="pedido.direccion" maxlength="200" placeholder="Provincia, cantón y distrito"></textarea></div><div class="form-group"><label>Referencia</label><textarea class="input" v-model="pedido.referencia" maxlength="120" placeholder="Señas para llegar"></textarea></div></fieldset>
          <div class="form-group"><label>Hora programada (opcional)</label><input class="input" type="time" v-model="pedido.hora"></div>
          <div class="form-group"><label>Código de descuento o premio</label><div class="split"><input class="input" v-model="codigo" maxlength="60" placeholder="Cupón o tarjeta de regalo" style="text-transform:uppercase" @keydown.enter.prevent="aplicarCodigo"><button class="btn btn-light" type="button" @click="aplicarCodigo">Aplicar</button></div><small class="muted" v-if="cupon">Cupón {{cupon.codigo}} aplicado. <a href="#catalogo" @click.prevent="cupon = null">Quitar</a></small><small class="muted" v-if="tarjeta">Tarjeta {{tarjeta.codigo}} · saldo {{money(tarjeta.saldo)}}. <a href="#catalogo" @click.prevent="tarjeta = null">Quitar</a></small></div>
          <label v-if="puntosInfo && puntosInfo.activo && puntosInfo.saldo >= puntosInfo.minimo_canje" style="display:flex;gap:8px;align-items:center"><input type="checkbox" v-model="usarPuntos"> Usar mis {{Math.round(puntosInfo.saldo)}} {{puntosInfo.nombre.toLowerCase()}} en este pedido</label>
          <div class="form-group"><label>Correo (opcional, para avisarte de tu pedido)</label><input class="input" type="email" v-model="pedido.correo" maxlength="120" @change="guardar"></div>
          <div class="form-group"><label>Notas</label><textarea class="input" v-model="pedido.nota" maxlength="300" placeholder="Detalles para el negocio"></textarea></div>
          <p class="msg err" v-if="error">{{error}}</p>
          <button class="btn btn-accent btn-block" type="submit" :disabled="enviando || !carrito.length">{{enviando ? 'Creando pedido…' : conTarjeta ? 'Pagar con tarjeta · ' + money(aPagar) : conCredito ? 'Enviar pedido a crédito' : 'Enviar pedido por WhatsApp'}}</button></form></div></aside>

      <!-- personalizar producto (productCustomizer) -->
      <div id="productCustomizer" class="product-modal" :class="{open: !!item}" :aria-hidden="!item" v-if="item"><div class="product-modal-bg" data-close-customizer @click="cerrarPersonalizar"></div><section class="card product-modal-panel"><div class="drawer-head"><div><span class="tag">PERSONALIZAR</span><h2 id="customizerTitle">{{item.nombre}}</h2></div><button class="icon-btn" type="button" data-close-customizer @click="cerrarPersonalizar">×</button></div>
        <div id="customizerGroups"><fieldset class="custom-group" v-for="g in item.modificadores" :key="g.id"><legend>{{g.nombre}} <span v-if="+g.minimo">*</span></legend><small class="muted">{{+g.maximo === 1 ? 'Elige una opción' : 'Elige de ' + (+g.minimo || 0) + ' a ' + (+g.maximo || g.opciones.length)}}</small><label v-for="o in g.opciones" :key="o.id"><input :type="+g.maximo === 1 ? 'radio' : 'checkbox'" :name="'custom_' + g.id" :checked="tieneOp(g, o)" @click="toggleOp(g, o)"> <span>{{o.nombre}}</span><strong>{{+o.precio > 0 ? '+' + money(o.precio) : 'Incluido'}}</strong></label></fieldset></div>
        <div class="form-group"><label>Observaciones para este producto</label><textarea id="customizerNote" class="input" v-model="nota" maxlength="120" placeholder="Detalles para este producto…"></textarea></div>
        <div class="split"><div class="form-group"><label>Cantidad</label><input id="customizerQty" class="input" type="number" min="1" step="1" v-model.number="cantidad"></div><div class="customizer-total"><small>Total unitario</small><strong id="customizerPrice">{{money(precioItem(item))}}</strong></div></div>
        <button id="customizerAdd" type="button" class="btn btn-accent btn-block" @click="agregar">Agregar al carrito</button></section></div>

      <!-- pedido enviado -->
      <div class="product-modal open" v-if="resultado"><div class="product-modal-bg" @click="resultado = null"></div><section class="card product-modal-panel t-pedido-listo"><div class="drawer-head"><div><span class="tag">PEDIDO ENVIADO</span><h2>Pedido #{{resultado.numero}} recibido</h2></div><button class="icon-btn" type="button" @click="resultado = null">×</button></div><p class="big">✓</p><p>{{resultado.tipo_nombre}} · total {{money(resultado.total)}}{{resultado.hora_programada ? ' · para las ' + resultado.hora_programada : ''}}. El negocio lo confirma en breve.</p>
        <p class="msg info" v-if="resultado.pago_medio === 'sinpe' && d.sinpe">Haz el SINPE Móvil por <b>{{money(resultado.a_pagar)}}</b> al <b>{{telFmt(d.sinpe.numero)}}</b>{{d.sinpe.nombre ? ' (' + d.sinpe.nombre + ')' : ''}} con el detalle «Pedido {{resultado.numero}}» y sube el comprobante en la trazabilidad.</p>
        <a v-if="resultado.whatsapp" class="btn btn-accent btn-block" :href="resultado.whatsapp" target="_blank" rel="noopener">Enviar pedido por WhatsApp</a><button class="btn btn-light btn-block" type="button" style="margin-top:8px" @click="irSeguimiento(resultado.token)">{{resultado.pago_medio === 'sinpe' ? 'Subir el comprobante del SINPE' : 'Ver trazabilidad'}}</button></section></div>

      <div class="product-modal open" v-if="galeriaIdx !== null" @click.self="galeriaIdx = null"><div class="product-modal-bg" @click="galeriaIdx = null"></div><img class="t-grande" :src="d.galeria[galeriaIdx]" alt="" style="position:relative;z-index:1;display:block;margin:5vh auto" @click="galeriaIdx = (galeriaIdx + 1) % d.galeria.length"></div>
      <div id="cartNotice" class="cart-notice" :class="{show: !!msg}">{{msg}}</div>
    </div>

    <!-- FISIChat -->
    <button class="fc-launch" type="button" data-fc-open aria-controls="fc-panel" :aria-expanded="chat" @click="abrirChat"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 3v-3H3V6a2 2 0 0 1 2-2Z"/><path d="M7 9h10M7 13h6"/></svg><span>FISIChat</span></button>
    <section id="fc-panel" class="fc-panel" data-fc :hidden="!chat" role="dialog" aria-labelledby="fc-title"><header class="fc-header"><div class="fc-avatar"><img v-if="d.logo" :src="d.logo" :alt="d.nombre"><span v-else>F</span></div><div><h2 id="fc-title">FISIChat</h2><p>{{d.nombre}}</p></div><button class="fc-icon" type="button" aria-label="Nueva conversación" title="Nueva conversación" @click="chatMsgs = []; abrirChat(); chat = true">↻</button><button class="fc-icon" type="button" aria-label="Cerrar chat" @click="chat = false">×</button></header>
      <div class="fc-scroll" ref="chatLista"><div class="fc-messages" role="log" aria-live="polite"><p class="fc-day">Conversemos</p><div v-for="(m, i) in chatMsgs" :key="i" class="fc-bubble" :class="{'fc-user': m.rol === 'cliente'}">{{m.texto}}</div><div class="fc-bubble fc-typing" v-if="chatCargando">…</div></div><div class="fc-suggestions"><button v-for="s in sugerencias" :key="s" type="button" @click="preguntar(s)">{{s}}</button></div></div>
      <p class="fc-status" role="status"></p><form class="fc-compose" @submit.prevent="preguntar()"><label class="fc-sr" for="fc-message">Tu mensaje</label><textarea id="fc-message" v-model="chatTxt" maxlength="1500" rows="1" placeholder="Escribe tu mensaje…" required @keydown.enter.exact.prevent="preguntar()"></textarea><button type="submit" aria-label="Enviar mensaje"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 4 17 8-17 8 3-8-3-8Zm3 8h14"/></svg></button></form><footer class="fc-footer"><a :href="wa" :target="wa.startsWith('http') ? '_blank' : null" rel="noopener">Contactar tienda ↗</a><span>Te ayudamos paso a paso</span></footer></section>
  </div>
  <div v-else class="container section" style="text-align:center;color:#667085">{{error || 'Cargando…'}}</div>`,
}).mount('#app');
