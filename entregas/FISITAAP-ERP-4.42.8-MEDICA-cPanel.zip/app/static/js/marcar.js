// Quiosco de marcas de asistencia (3.46): página /marcar.html, sin sesión de usuario; el equipo se activa con el token del
// encabezado X-Quiosco guardado en este navegador. Código de reloj + clave personal → marcas en orden (ver app/asistencia.py).
import { createApp } from '/js/vendor/vue.esm-browser.prod.min.js';
const CLAVE = 'asistencia:quiosco';
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
createApp({
  data() {
    let token = '';
    try { const h = new URLSearchParams(location.hash.replace(/^#/, '')).get('q'); if (h) { localStorage.setItem(CLAVE, h); history.replaceState(null, '', location.pathname); } token = localStorage.getItem(CLAVE) || ''; } catch {}
    return { token, estado: null, estadoError: '', paso: 'codigo', codigo: '', clave: '', nueva: '', nueva2: '', quien: null, marca: null, siguiente: '', error: '', cargando: false, cuenta: 6, ahora: new Date(), peticion: null };
  },
  computed: {
    hora() { return this.ahora.toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Costa_Rica' }); },
    fechaTxt() { return this.ahora.toLocaleDateString('es-CR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Costa_Rica' }); },
    hoyIso() { return this.ahora.toLocaleDateString('en-CA', { timeZone: 'America/Costa_Rica' }); },
    // 4.7: aviso del turno con los datos del servidor (antes decía siempre «Ayer no marcó la salida… Hoy empieza con Entrada»).
    // turno_desde de otro día: el turno de noche sigue abierto y se cierra con Salida (o sigue con Regreso si está en pausa) hasta que
    // pasen las horas máximas de un turno (max_turno_horas). Cuándo usar Entrada se explica solo si el servidor la ofrece (la última
    // marca es de otro día; con una Pausa o un Regreso de hoy no la ofrece). ultima_sin_salida: el turno pasó ese tope sin salida,
    // quedó incompleto y empieza otro con Entrada. «hoy» es el día del servidor (q.ahora), no el reloj de este equipo.
    avisoTurno() {
      const q = this.quien; if (!q) return '';
      const hoy = String(q.ahora || '').slice(0, 10) || this.hoyIso;
      const otroDia = n => { const d = new Date(hoy + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
      const dia = f => (f === hoy ? 'hoy' : f === otroDia(-1) ? 'ayer' : f === otroDia(1) ? 'mañana' : 'el ' + String(f).split('-').reverse().join('/'));
      const tope = +(q.max_turno_horas || (this.estado && this.estado.max_turno_horas)) || 0;
      const tipos = (q.permitidas || []).map(p => p.tipo), desde = String(q.turno_desde || '');
      if (desde && desde.slice(0, 10) !== hoy) {
        const zona = { timeZone: 'America/Costa_Rica' }, fin = tope ? new Date(Date.parse(desde) + tope * 3600000) : null;
        const hasta = fin && !isNaN(fin) ? ' (puede hacerlo hasta ' + dia(fin.toLocaleDateString('en-CA', zona)) + ' a las ' + fin.toLocaleTimeString('es-CR', { ...zona, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }) + ')' : '';
        return 'Su turno empezó ' + dia(desde.slice(0, 10)) + ' a las ' + desde.slice(11, 16) + (tipos.includes('regreso') ? ' y está en pausa: marque Regreso para seguir con ese turno' : ' y sigue abierto: marque Salida para cerrarlo') + hasta + '.'
          + (tipos.includes('entrada') ? ' Marque Entrada solo si ese turno ya terminó y olvidó la salida: quedará incompleto y su supervisor la anota.' : '');
      }
      if (q.ultima_sin_salida && q.ultima) {
        const u = q.ultima;
        return 'Su turno anterior quedó sin salida (última marca: ' + u.tipo_nombre + ' ' + dia(u.fecha) + ' a las ' + u.hora + ') y ya pasó el máximo de '
          + (tope ? tope + ' horas' : 'horas') + ' de un turno: avise a su supervisor para que anote la salida. Ahora empieza un turno nuevo con Entrada.';
      }
      return '';
    },
  },
  methods: {
    icono(t) { return { entrada: '🟢', pausa: '☕', regreso: '🔵', salida: '🏁' }[t] || '⏱'; },
    async api(url, body) {
      const r = await fetch(url, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', 'X-Quiosco': this.token }, body: body ? JSON.stringify(body) : undefined });
      let j = null; try { j = await r.json(); } catch {}
      if (!r.ok) { const d = j && j.detail; throw new Error(typeof d === 'string' ? d : (d && d.mensaje) || (Array.isArray(d) && d[0] && d[0].msg) || 'No se pudo completar (' + r.status + ')'); }
      return j;
    },
    async cargarEstado() { this.estadoError = ''; try { this.estado = await this.api('/api/asistencia/quiosco/estado'); } catch (e) { this.estadoError = e.message; } },
    foco(r) { this.$nextTick(() => this.$refs[r] && this.$refs[r].focus()); },
    tecla(k) {
      const campo = document.activeElement === this.$refs.clave ? 'clave' : 'codigo';
      if (k === '↵') { if (campo === 'codigo') return this.foco('clave'); return this.identificar(); }
      if (k === '⌫') { this[campo] = this[campo].slice(0, -1); return; }
      if (campo === 'codigo' && this.codigo.length >= 4) { this.clave += k; return this.foco('clave'); }
      if (campo === 'clave' && this.clave.length >= 8) return;
      this[campo] += k; if (campo === 'codigo' && this.codigo.length === 4) this.foco('clave');
    },
    async identificar() {
      if (this.cargando || !this.codigo || this.clave.length < 4) return; this.error = ''; this.cargando = true;
      try { this.quien = await this.api('/api/asistencia/quien', { codigo: this.codigo, clave: this.clave }); this.paso = 'marcar'; this.peticion = uuid(); this.armarReinicio(40); this.api('/api/asistencia/quiosco/estado').then(x => { this.estado = x; }).catch(() => {}); }
      catch (e) { this.error = e.message; this.clave = ''; this.foco('clave'); }
      this.cargando = false;
    },
    async marcar(tipo) {
      if (this.cargando) return; this.error = ''; this.cargando = true;
      try {
        const r = await this.api('/api/asistencia/marcar', { codigo: this.codigo, clave: this.clave, tipo, clave_peticion: this.peticion });
        this.marca = r.marca; this.siguiente = r.permitidas.map(p => p.nombre).join(' o '); this.paso = 'listo'; this.cuenta = 6; this.armarReinicio(6, true);
      } catch (e) { this.error = e.message; }
      this.cargando = false;
    },
    async cambiarClave() {
      if (this.nueva !== this.nueva2) { this.error = 'Las dos claves nuevas no coinciden'; return; }
      this.error = ''; this.cargando = true;
      try { await this.api('/api/asistencia/clave/propia', { codigo: this.codigo, clave: this.clave, nueva: this.nueva }); this.reiniciar(); this.error = ''; alert('Clave cambiada. Úsela desde ahora.'); }
      catch (e) { this.error = e.message; }
      this.cargando = false;
    },
    armarReinicio(seg, contar) { clearInterval(this._r); this.cuenta = seg; this._r = setInterval(() => { this.cuenta--; if (this.cuenta <= 0) this.reiniciar(); }, 1000); },
    reiniciar() { clearInterval(this._r); this.paso = 'codigo'; this.codigo = ''; this.clave = ''; this.nueva = ''; this.nueva2 = ''; this.quien = null; this.marca = null; this.error = ''; this.peticion = null; this.foco('codigo'); },
    desactivar() { if (!confirm('¿Quitar la activación de este equipo? Un administrador tendrá que activarlo de nuevo.')) return; try { localStorage.removeItem(CLAVE); } catch {} this.token = ''; },
  },
  mounted() { setInterval(() => { this.ahora = new Date(); }, 1000); if (this.token) this.cargarEstado(); this.foco('codigo'); },
}).mount('#app');
