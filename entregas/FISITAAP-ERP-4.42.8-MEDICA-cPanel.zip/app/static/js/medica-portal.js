const el = id => document.getElementById(id);
const empresa = location.pathname.split('/').filter(Boolean).at(-1);
const base = '/api/medica/portal/' + empresa;
let token = '';
let tokenTitular = '';
let tokenTemporal = '';
let ofertas = [];
let disenoWeb = null;
let horarios = [];
let sede = null;
let reemplaza = null;
const fecha = s => s?.replace('T',' ').slice(0,16) || '';
const dinero = n => new Intl.NumberFormat('es-CR',{style:'currency',currency:'CRC'}).format(n);

function estado(texto, error = false) {
  el('mensaje').textContent = texto;
  el('mensaje').className = error ? 'error' : '';
}

function cerrar() {
  token = '';
  tokenTitular = '';
  tokenTemporal = '';
  el('ingreso').hidden = false;
  el('cambiar-clave').hidden = true;
  el('form-solicitud').hidden = true;
  el('solicitud-login').hidden = false;
  el('representaciones').replaceChildren();
  sede = null;
  reemplaza = null;
  el('cambio-cita').hidden = true;
  el('cuenta').hidden = true;
  el('acceso').hidden = false;
  for (const id of ['citas','documentos','facturas','mensajes','expediente','solicitudes']) el(id).replaceChildren();
  el('paciente').textContent = 'Mi cuenta';
  el('form-preadmision').reset();
  if (el('preadmision').open) el('preadmision').close();
  if (el('llegada').open) el('llegada').close();
  el('qr-llegada').replaceChildren();
  el('codigo-llegada').textContent='';
  pintarHorarios();
  pintarSitio();
}

async function pedir(ruta, datos, archivo = false) {
  const headers = token ? {'X-Medica-Portal':token} : {};
  if (datos !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + ruta,{
    method:datos === undefined ? 'GET' : 'POST', headers, credentials:'omit', cache:'no-store',
    body:datos === undefined ? undefined : JSON.stringify(datos),
  });
  if (!res.ok) {
    if (res.status === 401 && token) cerrar();
    const j = await res.json().catch(()=>null);
    throw new Error(typeof j?.detail === 'string' ? j.detail : 'No se pudo completar la operación.');
  }
  return archivo ? res.blob() : res.json();
}

function boton(texto, fn) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'sec';
  b.textContent = texto;
  b.addEventListener('click', () => ejecutar(fn,b));
  return b;
}

async function ejecutar(fn, botonActual) {
  if (botonActual) botonActual.disabled = true;
  estado('');
  try { await fn(); }
  catch (e) { estado(e.message,true); }
  finally { if (botonActual) botonActual.disabled = false; }
}

function renglon(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  return li;
}

function parrafo(li,texto) {
  if (!texto) return;
  const p = document.createElement('p');
  p.textContent = texto;
  li.append(p);
}

async function descargar(ruta, nombre) {
  const blob = await pedir(ruta,undefined,true);
  const u = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = u;
  a.download = nombre;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(u),1000);
}

function render(id, filas, mensaje) {
  el(id).replaceChildren(...(filas.length ? filas : [renglon(mensaje)]));
}

async function actualizarCuenta() {
  const c = await pedir('/cuenta');
  sede = c.sede;
  el('cuenta').hidden = false;
  el('acceso').hidden = true;
  el('paciente').textContent = c.nombre;
  el('form-solicitud').hidden = false;
  el('solicitud-login').hidden = true;
  pintarSitio();
  render('expediente',(c.expediente || []).map(x=>{
    const li=renglon(fecha(x.inicio));
    parrafo(li,x.resumen);
    parrafo(li,x.indicaciones);
    return li;
  }),'Aún no hay resúmenes publicados.');
  render('solicitudes',(c.solicitudes || []).map(x=>renglon(x.servicio+' · '+x.estado)),'Aún no has solicitado citas.');
  await mostrarRepresentaciones();
  render('citas',c.citas.map(x=>{
    const li = renglon(fecha(x.inicio) + ' · ' + x.modalidad + ' · ' + x.estado);
    if (x.video) {
      const video = document.createElement('a');
      video.href = x.video;
      video.target = '_blank';
      video.rel = 'noopener noreferrer';
      video.textContent = 'Entrar a la videollamada';
      li.append(' ', video);
    }
    if (['programada','confirmada'].includes(x.estado)) {
      if (x.modalidad !== 'telemedicina') li.append(boton('Código de llegada',async()=>{
        const d=await pedir('/citas/'+x.id+'/check-in',{});
        el('qr-llegada').replaceChildren();
        const qr=document.createElement('img');
        qr.alt='Código QR de llegada';
        qr.src='data:image/png;base64,'+d.qr;
        el('qr-llegada').append(qr);
        el('codigo-llegada').textContent=d.codigo+' · vence en '+d.minutos+' min';
        el('llegada').showModal();
      }));
      li.append(boton('Preadmisión',()=>{
        el('form-preadmision').reset();
        el('form-preadmision').dataset.cita = x.id;
        el('preadmision').showModal();
      }));
      li.append(boton('Reprogramar',()=>{
        reemplaza=x.id;
        el('cambio-cita').hidden=false;
        pintarHorarios();
        el('buscar').focus();
      }));
      li.append(boton('Cancelar cita',async()=>{
        if (!confirm('¿Cancelar esta cita?')) return;
        await pedir('/citas/'+x.id+'/cancelar',{});
        await Promise.all([actualizarCuenta(),cargarHorarios()]);
        estado('Cita cancelada.');
      }));
    }
    return li;
  }),'Aún no hay citas en el expediente.');
  render('documentos',c.documentos.map(x=>{
    const li = renglon(x.titulo + ' · ' + x.tipo);
    parrafo(li,x.indicaciones);
    parrafo(li,[x.dosis,x.frecuencia,x.duracion].filter(Boolean).join(' · '));
    parrafo(li,x.resultado);
    if (x.adjunto) li.append(boton('Descargar PDF',()=>descargar('/documentos/'+x.id+'/pdf','documento-'+x.id+'.pdf')));
    return li;
  }),'Aún no hay documentos publicados.');
  render('facturas',c.facturas.map(x=>{
    const li = renglon(x.consecutivo + ' · ' + dinero(x.total) + ' · Saldo ' + dinero(x.saldo));
    li.append(boton('Descargar comprobante',()=>descargar('/facturas/'+x.id+'/pdf',x.consecutivo+'.pdf')));
    if (x.pagable) {
      li.append(boton('Pagar con tarjeta',async()=>{
        const pago = await pedir('/facturas/'+x.id+'/pagar',{});
        location.assign(pago.url);
      }));
      li.append(boton('Consultar pago',async()=>{
        const pago = await pedir('/facturas/'+x.id+'/pago');
        estado('Estado del pago: '+pago.estado+'.');
      }));
    }
    return li;
  }),'Aún no hay comprobantes disponibles.');
  pintarHorarios();
  await cargarMensajes();
}

async function mostrarRepresentaciones() {
  const caja=el('representaciones');
  caja.replaceChildren();
  if (token!==tokenTitular) {
    caja.append(boton('Volver a mi expediente',async()=>{token=tokenTitular;reemplaza=null;el('cambio-cita').hidden=true;await actualizarCuenta();}));
    return;
  }
  const r=await pedir('/representaciones');
  for (const persona of r) caja.append(boton('Ver expediente de '+persona.nombre,async()=>{
    ({token}=await pedir('/representaciones/'+persona.id+'/sesion',{}));
    reemplaza=null;
    el('cambio-cita').hidden=true;
    await actualizarCuenta();
  }));
}

async function cargarMensajes() {
  const filas = await pedir('/mensajes');
  render('mensajes',filas.map(x=>renglon(fecha(x.fecha)+' · '+x.direccion+' · '+x.texto)),'Aún no hay mensajes.');
}

el('enviar-mensaje').addEventListener('submit',e=>{
  e.preventDefault();
  const f=e.currentTarget;
  const texto=new FormData(f).get('texto');
  ejecutar(async()=>{await pedir('/mensajes',{texto});f.reset();await cargarMensajes();},e.submitter);
});
el('form-preadmision').addEventListener('submit',e=>{
  e.preventDefault();
  const f=e.currentTarget;
  const datos=new FormData(f);
  ejecutar(async()=>{
    await pedir('/citas/'+f.dataset.cita+'/preadmision',{motivo:datos.get('motivo'),preparacion:datos.has('preparacion')});
    f.reset();
    el('preadmision').close();
    estado('Preadmisión guardada.');
  },e.submitter);
});
el('cerrar-preadmision').addEventListener('click',()=>el('preadmision').close());

function pintarHorarios() {
  const busca = el('buscar').value.trim().toLocaleLowerCase('es');
  const dia = el('dia').value;
  const filas = horarios.filter(h=>(!token || h.sede===sede) && (!dia || h.inicio.startsWith(dia))
    && [h.profesional,h.especialidad,h.servicio].join(' ').toLocaleLowerCase('es').includes(busca));
  render('horarios',filas.map(h=>{
    const li = renglon(fecha(h.inicio) + ' · ' + h.servicio + ' · ' + h.profesional + ' · ' + h.modalidad);
    if (token) li.append(boton(reemplaza?'Cambiar a este horario':'Reservar',async()=>{
      const anterior=reemplaza;
      if (!confirm((anterior?'¿Cambiar la cita al ':'¿Reservar la cita del ')+fecha(h.inicio)+'?')) return;
      await pedir('/horarios/'+h.id+'/reservar',{reemplaza:anterior});
      reemplaza=null;
      el('cambio-cita').hidden=true;
      await Promise.all([actualizarCuenta(),cargarHorarios()]);
      estado(anterior?'Cita reprogramada.':'Cita confirmada.');
    }));
    return li;
  }),'Sin horarios disponibles con esos filtros.');
}

async function cargarHorarios() {
  horarios = await pedir('/horarios');
  pintarHorarios();
}

async function abrirCuenta(nuevoToken) {
  token = nuevoToken;
  tokenTitular = token;
  tokenTemporal = '';
  el('ingreso').hidden = false;
  el('cambiar-clave').hidden = true;
  await actualizarCuenta();
  estado('Sesión iniciada.');
}

for (const id of ['ingreso','registro','cambiar-clave']) {
  el(id).addEventListener('submit',evento=>{
    evento.preventDefault();
    const f = evento.currentTarget;
    const datos = Object.fromEntries(new FormData(f));
    ejecutar(async()=>{
      if (id === 'registro') {
        datos.expediente = Number(datos.expediente);
        await pedir('/registro',datos);
        estado('Cuenta activada. Entra con tu cédula.');
      } else if (id === 'cambiar-clave') {
        const r = await pedir('/cambiar-clave',{...datos,token_temporal:tokenTemporal});
        await abrirCuenta(r.token);
      } else {
        const r = await pedir('/sesion',datos);
        if (r.cambiar_password) {
          tokenTemporal = r.token_temporal;
          el('ingreso').hidden = true;
          el('cambiar-clave').hidden = false;
          el('cambiar-clave').elements.password.focus();
          estado('Elige tu contraseña personal para continuar.');
        } else await abrirCuenta(r.token);
      }
      f.reset();
    },evento.submitter);
  });
}

el('form-solicitud').addEventListener('submit',evento=>{
  evento.preventDefault();
  const f=evento.currentTarget;
  const datos=Object.fromEntries(new FormData(f));
  ejecutar(async()=>{
    await pedir('/solicitudes-cita',datos);
    f.reset();
    el('solicitar-cita').open=false;
    await actualizarCuenta();
    estado('Recepción recibió tu solicitud de cita.');
  },evento.submitter);
});

document.querySelector('.portal-tabs').addEventListener('click',evento=>{
  const b=evento.target.closest('button[data-panel]');
  if (!b) return;
  for (const item of document.querySelectorAll('.portal-tabs button[data-panel]')) {
    item.setAttribute('aria-pressed',item===b ? 'true' : 'false');
    el(item.dataset.panel).hidden=item!==b;
  }
});

function nodo(etiqueta,texto,clase) {
  const n=document.createElement(etiqueta);
  if (texto) n.textContent=texto;
  if (clase) n.className=clase;
  return n;
}

function tarjeta(titulo,textos) {
  const n=nodo('article','','clinica-tarjeta');
  n.append(nodo('h3',titulo));
  for (const texto of textos.filter(Boolean)) n.append(nodo('p',texto));
  return n;
}

function pintarSitio() {
  if (!disenoWeb) return;
  const d=disenoWeb;
  el('sitio').dataset.plantilla=d.plantilla;
  if (d.color) el('sitio').style.setProperty('--clinica-acento',d.color);
  el('clinica').textContent=d.marca;
  el('titular-web').textContent=d.titulo;
  el('intro-web').textContent=d.introduccion;
  el('boton-web').textContent=d.boton;
  el('foto-web').src=d.foto_url || '/img/medica-clinica.png';
  el('foto-web').alt=d.texto_foto;
  const bloques=[];
  const nombres={servicios:'Servicios',equipo:'Equipo médico',seguros:'Seguros y pólizas',contacto:'Contacto'};
  for (const seccion of d.secciones) {
    let tarjetas=[];
    if (seccion==='contacto') {
      const valores=[d.direccion,d.telefono,d.correo,d.horario];
      if (valores.some(Boolean)) tarjetas=[tarjeta('Información de la clínica',valores)];
    } else if (seccion==='seguros') {
      tarjetas=ofertas.filter(o=>!token || o.sede===sede).map(o=>{
        const n=tarjeta(o.nombre,[o.aseguradora,o.descripcion,o.precio!=null?new Intl.NumberFormat('es-CR',{style:'currency',currency:o.moneda==='USD'?'USD':'CRC'}).format(o.precio):'']);
        if (token) n.append(boton('Solicitar información',async()=>{
          await pedir('/seguros/'+o.id+'/solicitar',{});
          estado('La clínica recibió tu solicitud de póliza.');
        }));
        else {
          const a=nodo('a','Entra para solicitar información');
          a.href='#acceso';
          n.append(a);
        }
        return n;
      });
    } else tarjetas=d[seccion].map(x=>tarjeta(x.titulo,[x.texto]));
    if (!tarjetas.length) continue;
    const bloque=nodo('section','','clinica-bloque');
    const rejilla=nodo('div','','clinica-tarjetas');
    rejilla.append(...tarjetas);
    bloque.append(nodo('h2',nombres[seccion]),rejilla);
    bloques.push(bloque);
  }
  el('bloques-web').replaceChildren(...bloques);
}

el('salir').addEventListener('click',()=>{ cerrar(); estado('Sesión cerrada.'); });
el('cancelar-cambio').addEventListener('click',()=>{
  reemplaza=null;
  el('cambio-cita').hidden=true;
  pintarHorarios();
});
el('refrescar').addEventListener('click',()=>ejecutar(cargarHorarios,el('refrescar')));
for (const id of ['buscar','dia']) el(id).addEventListener('input',pintarHorarios);
ejecutar(async()=>{
  [disenoWeb,ofertas] = await Promise.all([pedir('/diseno'),pedir('/seguros')]);
  document.title=disenoWeb.marca+' · Recepción web';
  pintarSitio();
  await cargarHorarios();
});
