// Panel del motorizado (Ventas en línea · Entregas, 3.48; estilo FISITAAP by Brillante Agencia desde 3.77): página /motorizado.html sin usuario del sistema. El motorizado entra con el
// nombre público del negocio (viene en el enlace #n=<negocio>), su teléfono y su clave. Ve las entregas liberadas y las suyas,
// acepta, marca recogida, en camino y entregada con el código del cliente, reporta incidencias y manda su posición mientras va
// en camino. Se instala como aplicación («Agregar a pantalla de inicio») y suena cuando entra una entrega nueva.
import { createApp } from '/js/vendor/vue.esm-browser.prod.min.js';
import { crearMapa, miPosicion } from '/js/mapa.js';

const KEY = 'motorizado:sesion';
const money = v => '₡' + (Math.round((+v || 0) * 100) / 100).toLocaleString('es-CR', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

createApp({
  data() {
    let ses = null; try { ses = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch {}
    const h = new URLSearchParams(location.hash.replace(/^#/, '')); const slug = h.get('n') || (ses && ses.slug) || '';
    if (h.get('n')) history.replaceState(null, '', location.pathname);
    return { slug, ses, acceso: { telefono: '', clave: '' }, error: '', d: null, cargando: false, sel: null, pin: '', incidencia: null, vistos: null, sonido: true, mapa: null, marcadores: [], enviandoPos: false, instalar: null, ahora: Date.now() };
  },
  computed: {
    activas() { return this.d ? this.d.mias.filter(x => x.abierta) : []; },
    enCamino() { return this.activas.some(x => x.estado === 'en_camino'); },
  },
  methods: {
    money,
    hora(iso) { return iso ? new Date(iso).toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) : ''; },
    min(iso) { return iso ? Math.max(0, Math.round((this.ahora - new Date(iso).getTime()) / 60000)) : 0; },
    async api(url, body, method) {
      const r = await fetch('/api/publico/' + encodeURIComponent(this.slug) + url, { method: method || (body ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json', ...(this.ses ? { 'X-Motorizado': this.ses.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
      let j = null; try { j = await r.json(); } catch {}
      if (!r.ok) { const d = j && j.detail; const e = new Error(typeof d === 'string' ? d : (d && d.mensaje) || (Array.isArray(d) && d[0] && d[0].msg) || 'No se pudo completar (' + r.status + ')'); e.status = r.status; throw e; }
      return j;
    },
    async entrar() {
      this.error = ''; if (!this.slug.trim()) return (this.error = 'Indique el nombre público del negocio (el que va al final de la dirección de su página)');
      this.slug = this.slug.trim().toLowerCase();
      try { const r = await this.api('/motorizado/acceso', { telefono: this.acceso.telefono, clave: this.acceso.clave }); this.ses = { token: r.token, nombre: r.nombre, negocio: r.negocio, slug: this.slug, ubic: r.negocio_ubicacion }; localStorage.setItem(KEY, JSON.stringify(this.ses)); this.acceso.clave = ''; this.cargar(); }
      catch (e) { this.error = e.message; }
    },
    salir() { this.ses = null; this.d = null; try { localStorage.removeItem(KEY); } catch {} },
    async cargar(silencioso) {
      if (!this.ses) return; if (!silencioso) this.cargando = true;
      try {
        const d = await this.api('/motorizado/entregas');
        const claves = new Set([...d.libres, ...d.mias].map(x => x.id + ':' + x.estado));
        if (this.vistos && this.sonido && [...claves].some(k => !this.vistos.has(k) && (k.endsWith(':liberada') || k.endsWith(':asignada')))) this.beep();
        this.vistos = claves; this.d = d; this.ahora = Date.now();
        if (this.sel && ![...d.libres, ...d.mias].some(x => x.id === this.sel.id)) this.sel = null;
        else if (this.sel) this.sel = [...d.libres, ...d.mias].find(x => x.id === this.sel.id) || null;
      } catch (e) { if (e.status === 401) this.salir(); else this.error = e.message; }
      this.cargando = false;
    },
    async accion(x, paso, body) {
      this.error = '';
      try { const r = await this.api('/motorizado/entregas/' + x.id + '/' + paso, body || {}, 'PUT'); Object.assign(x, r); await this.cargar(true); if (paso === 'entregada') { this.sel = null; this.pin = ''; } if (paso === 'en-camino') this.mandarPosicion(); }
      catch (e) { this.error = e.message; }
    },
    async entregar(x) { if (!/^\d{4}$/.test(this.pin)) return (this.error = 'Escriba los 4 dígitos del código del cliente'); await this.accion(x, 'entregada', { pin: this.pin }); },
    async reportar() { const t = (this.incidencia.texto || '').trim(); if (t.length < 3) return; await this.accion(this.incidencia.x, 'incidencia', { texto: t }); this.incidencia = null; },
    async mandarPosicion() {
      if (!this.ses || this.enviandoPos || !this.enCamino) return; this.enviandoPos = true;
      try { const p = await miPosicion(6000); if (p) await this.api('/motorizado/posicion', p, 'PUT'); } catch {}
      this.enviandoPos = false;
    },
    async abrir(x) {
      this.sel = x; this.pin = ''; this.error = '';
      await this.$nextTick();
      try {
        if (this.mapa) { this.mapa.remove(); this.mapa = null; }
        const el = this.$refs.mapa; if (!el) return;
        const centro = x.lat ? { lat: x.lat, lng: x.lng } : (this.ses.ubic && this.ses.ubic.lat ? this.ses.ubic : null);
        if (!centro) return;
        this.mapa = await crearMapa(el, centro, 15);
        const L = window.L;
        if (x.lat) L.marker([x.lat, x.lng]).addTo(this.mapa).bindPopup('Cliente: ' + (x.direccion || '')).openPopup();
        if (this.ses.ubic && this.ses.ubic.lat) L.circleMarker([this.ses.ubic.lat, this.ses.ubic.lng], { radius: 8, color: '#0f766e', fillOpacity: .8 }).addTo(this.mapa).bindPopup('Negocio');
      } catch {}
    },
    rutaUrl(x) { return x.lat ? 'https://www.google.com/maps/dir/?api=1&destination=' + x.lat + ',' + x.lng : null; },
    wazeUrl(x) { return x.lat ? 'https://waze.com/ul?ll=' + x.lat + ',' + x.lng + '&navigate=yes' : null; },
    beep() { try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 740; g.gain.value = 0.25; o.start(); o.stop(ac.currentTime + 0.4); } catch {} },
    clase(x) { return x.estado === 'liberada' ? 'libre' : x.estado === 'incidencia' ? 'inc' : 'mia'; },
    badge(e) { return e === 'entregada' ? 'ok' : e === 'cancelada' || e === 'incidencia' ? 'danger' : e === 'liberada' ? 'warn' : 'info'; },
  },
  mounted() {
    if (this.ses) this.cargar();
    this._t = setInterval(() => this.cargar(true), 15000); this._p = setInterval(() => this.mandarPosicion(), 30000); this._r = setInterval(() => { this.ahora = Date.now(); }, 30000);
    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); this.instalar = e; });
    if ('serviceWorker' in navigator) { try { navigator.serviceWorker.register('/sw-motorizado.js'); } catch {} }
  },
  template: `
  <div class="m-wrap">
    <div class="m-top"><div class="m-brand"><img src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP"><span class="erp-by">by Brillante Agencia</span><span class="sep"></span><div style="min-width:0"><b>Entregas</b><div class="muted" v-if="ses">{{ses.negocio}} · {{ses.nombre}}</div><div class="muted" v-else>Mi ruta, al día</div></div></div>
      <div class="m-acciones"><button class="btn sm gris" v-if="instalar" @click="instalar.prompt(); instalar=null">Instalar</button><label class="muted" style="display:flex;gap:4px;align-items:center" v-if="ses"><input type="checkbox" v-model="sonido"> Sonido</label><button class="btn sm gris" v-if="ses" @click="salir">Salir</button></div></div>

    <div class="m-card" v-if="!ses">
      <p class="m-intro">Entre con el teléfono y la clave que le dio el negocio.</p>
      <label class="f">Negocio (nombre público)</label><input v-model="slug" placeholder="mi-negocio" autocapitalize="none">
      <label class="f">Teléfono</label><input v-model="acceso.telefono" inputmode="numeric" maxlength="12">
      <label class="f">Clave</label><input type="password" v-model="acceso.clave" inputmode="numeric" maxlength="8" @keyup.enter="entrar">
      <div class="msg err" v-if="error">{{error}}</div>
      <button class="btn" style="width:100%;margin-top:12px" @click="entrar">Entrar</button>
    </div>

    <template v-else>
      <div class="msg err" v-if="error">{{error}}</div>
      <div class="m-resumen" v-if="d"><div><b>{{activas.length}}</b><span>en curso</span></div><div><b>{{d.libres.length}}</b><span>libres</span></div><div><b>{{money(d.por_liquidar.total)}}</b><span>{{d.por_liquidar.entregas}} por liquidar</span></div></div>

      <!-- detalle de una entrega -->
      <div class="m-card" :class="clase(sel)" v-if="sel">
        <div class="m-h"><b>Pedido #{{sel.pedido_numero}} · {{sel.nombre_cliente}}</b><span class="badge" :class="badge(sel.estado)">{{sel.estado_nombre}}</span></div>
        <div class="m-dir">📍 {{sel.direccion || 'Sin dirección escrita'}}<span v-if="sel.zona_nombre" class="muted"> · {{sel.zona_nombre}}</span></div>
        <div ref="mapa" class="m-mapa" v-if="sel.lat || (ses.ubic && ses.ubic.lat)"></div>
        <div class="m-lineas">{{(sel.lineas || []).map(l => l.cantidad + ' × ' + l.detalle).join(' · ')}}<span v-if="sel.nota_pedido"> · ✎ {{sel.nota_pedido}}</span></div>
        <div class="m-lineas" style="margin-top:4px">Cobrar al cliente: <b>{{money(sel.total_pedido)}}</b> (incluye envío {{money(sel.monto_envio)}}) · le pagan {{money(sel.pago_motorizado)}}<span v-if="!sel.lista_para_recoger && sel.estado!=='liberada'"> · ⏳ la cocina todavía lo prepara</span></div>
        <div class="msg err" v-if="sel.incidencia">Incidencia: {{sel.incidencia}}</div>
        <div class="m-btns">
          <div class="fila"><a class="btn sm sec" :href="'tel:' + sel.telefono_cliente">📞 Llamar</a><a class="btn sm sec" :href="'https://wa.me/506' + sel.telefono_cliente" target="_blank" rel="noopener">💬 WhatsApp</a><a class="btn sm sec" v-if="wazeUrl(sel)" :href="wazeUrl(sel)" target="_blank" rel="noopener">🧭 Waze</a><a class="btn sm sec" v-if="rutaUrl(sel)" :href="rutaUrl(sel)" target="_blank" rel="noopener">🗺 Maps</a></div>
          <button class="btn" v-if="sel.estado==='liberada' || sel.estado==='asignada'" @click="accion(sel, 'aceptar')">✅ Aceptar la entrega</button>
          <button class="btn" v-else-if="sel.estado==='aceptada'" @click="accion(sel, 'recogida')" :disabled="false">📦 Ya recogí el pedido</button>
          <button class="btn" v-else-if="sel.estado==='recogida'" @click="accion(sel, 'en-camino')">🛵 Voy en camino</button>
          <template v-else-if="sel.estado==='en_camino' || sel.estado==='incidencia'">
            <div class="m-pin"><label class="f">Código del cliente (4 dígitos)</label><input v-model="pin" inputmode="numeric" maxlength="4" placeholder="••••"></div>
            <button class="btn" @click="entregar(sel)">🏁 Entregado</button>
            <button class="btn gris" v-if="sel.estado==='incidencia'" @click="accion(sel, 'en-camino')">Seguir en camino</button>
          </template>
          <button class="btn gris" v-if="sel.motorizado_id && sel.estado!=='entregada'" @click="incidencia={x: sel, texto: ''}">⚠ Reportar incidencia</button>
          <button class="btn gris" @click="sel=null">Volver</button>
        </div>
      </div>

      <template v-else-if="d">
        <div class="m-sec">Mis entregas en curso</div>
        <p class="m-intro" v-if="!activas.length">Ninguna por ahora.</p>
        <div class="m-card" :class="clase(x)" v-for="x in activas" :key="x.id" @click="abrir(x)" style="cursor:pointer">
          <div class="m-h"><b>#{{x.pedido_numero}} · {{x.nombre_cliente}}</b><span class="badge" :class="badge(x.estado)">{{x.estado_nombre}}</span></div>
          <div class="m-dir">📍 {{x.direccion}}</div><div class="m-lineas">{{money(x.total_pedido)}} · hace {{min(x.asignada_en || x.creada)}} min<span v-if="!x.lista_para_recoger"> · ⏳ en cocina</span></div>
        </div>
        <div class="m-sec">Entregas libres</div>
        <p class="m-intro" v-if="!d.libres.length">No hay entregas liberadas.</p>
        <div class="m-card libre" v-for="x in d.libres" :key="'l' + x.id" @click="abrir(x)" style="cursor:pointer">
          <div class="m-h"><b>#{{x.pedido_numero}} · {{x.nombre_cliente}}</b><span class="badge warn">Libre</span></div>
          <div class="m-dir">📍 {{x.direccion}}<span v-if="x.zona_nombre" class="muted"> · {{x.zona_nombre}}</span></div><div class="m-lineas">{{money(x.total_pedido)}} · hace {{min(x.creada)}} min<span v-if="x.lista_para_recoger"> · ✓ listo para recoger</span></div>
        </div>
        <div class="m-sec" v-if="d.cerradas.length">Últimas cerradas</div>
        <div class="m-card" v-for="x in d.cerradas" :key="'c' + x.id" style="opacity:.75"><div class="m-h"><b>#{{x.pedido_numero}} · {{x.nombre_cliente}}</b><span class="badge" :class="badge(x.estado)">{{x.estado_nombre}}</span></div><div class="m-lineas">{{hora(x.entregada_en || x.cancelada_en)}}<span v-if="x.estado==='entregada'"> · {{money(x.pago_motorizado)}}{{x.liquidada ? ' (liquidada)' : ''}}</span></div></div>
      </template>
      <p v-else style="color:var(--muted)">Cargando…</p>
    </template>

    <div class="t-modal" v-if="incidencia" @click.self="incidencia=null"><div class="t-hoja"><h3>Incidencia<button @click="incidencia=null">✕</button></h3>
      <label class="f">¿Qué pasó?</label><input v-model="incidencia.texto" maxlength="200" placeholder="Cliente no contesta, dirección equivocada…">
      <button class="btn" style="width:100%;margin-top:12px" @click="reportar">Reportar</button></div></div>
    <div class="t-pie">Entregas con tecnología <img src="/img/fisitaap.webp" alt="FISITAAP"> · FISITAAP by Brillante Agencia</div>
  </div>`,
}).mount('#app');
