// Avisos de pedido nuevo en el dispositivo (FISITAAP, 3.58): con la aplicación abierta (aunque esté en otra pestaña o el celular
// bloqueado con el navegador abierto), cada pedido nuevo que entra por la página del negocio suena y muestra una notificación del
// sistema que abre FISITAAP › Pedidos. Se enciende por dispositivo en FISITAAP › Configuración › Avisos en este dispositivo.
import { api } from './api.js';

const CLAVE = 'fisitaap:avisos';          // '1' = avisar en este dispositivo
const INTERVALO = 30000;
let _sesion = null, _timer = null, _ultimo = {};

export function avisosActivos() { try { return localStorage.getItem(CLAVE) === '1'; } catch { return false; } }
export function permisoAvisos() { return typeof Notification === 'undefined' ? 'no_soportado' : Notification.permission; }   // granted | denied | default | no_soportado

// Pide el permiso del navegador y deja encendidos los avisos en este dispositivo. Devuelve true si quedó activo.
export async function activarAvisos() {
  if (typeof Notification === 'undefined') return false;
  let p = Notification.permission;
  if (p === 'default') { try { p = await Notification.requestPermission(); } catch { p = 'denied'; } }
  if (p !== 'granted') return false;
  try { localStorage.setItem(CLAVE, '1'); } catch {}
  revisar(true);
  return true;
}
export function desactivarAvisos() { try { localStorage.removeItem(CLAVE); } catch {} }

function sonar() {
  try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 660; g.gain.value = 0.2; o.start(); o.stop(ac.currentTime + 0.35); } catch {}
}

async function notificar(titulo, cuerpo) {
  const opciones = { body: cuerpo, icon: '/img/fisitaap-icono.svg', tag: 'fisitaap-pedido', renotify: true, data: { url: '/app/fisitaap/#/pedidos' } };
  try {
    const reg = navigator.serviceWorker && await navigator.serviceWorker.getRegistration();
    if (reg && reg.showNotification) { await reg.showNotification(titulo, opciones); return; }
  } catch {}
  try { const n = new Notification(titulo, opciones); n.onclick = () => { window.focus(); location.href = '/app/fisitaap/#/pedidos'; n.close(); }; } catch {}
}

// Consulta cuántos pedidos nuevos hay; avisa solo cuando entra uno que no se había visto (el último id se recuerda por empresa).
async function revisar(primera) {
  const s = _sesion;
  if (!s || !s.activa || !s.empresa_id || !avisosActivos() || !s.tieneModulo('pedidos_online') || !s.puede('pos')) return;
  let r; try { r = await api('/api/pedidos/resumen'); } catch { return; }
  const k = 'fisitaap:ultimo:' + s.empresa_id;
  let visto = _ultimo[s.empresa_id]; if (visto === undefined) { try { visto = +(localStorage.getItem(k) || 0); } catch { visto = 0; } }
  if (!primera && r.ultimo_id > visto && r.nuevos > 0) {
    sonar();
    notificar('Pedido nuevo en su página', r.nuevos === 1 ? 'Entró un pedido en línea. Toque para confirmarlo.' : 'Hay ' + r.nuevos + ' pedidos en línea sin confirmar. Toque para verlos.');
  }
  _ultimo[s.empresa_id] = Math.max(visto, r.ultimo_id || 0);
  try { localStorage.setItem(k, String(_ultimo[s.empresa_id])); } catch {}
}

export function iniciarAvisos(sesion) {
  _sesion = sesion;
  if (_timer) clearInterval(_timer);
  revisar(true);
  _timer = setInterval(() => revisar(false), INTERVALO);
}
