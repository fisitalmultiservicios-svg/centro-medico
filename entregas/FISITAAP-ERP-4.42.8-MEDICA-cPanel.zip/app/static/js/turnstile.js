// Verificación contra robots de Cloudflare (Turnstile) dentro de la aplicación (3.84): inicio de sesión, recuperación de
// contraseña y la prueba de las claves en el panel de administración. El script de Cloudflare se carga solo cuando hace falta.
let carga = null;

export function cargarTurnstile() {
  if (window.turnstile) return Promise.resolve(window.turnstile);
  if (!carga) {
    carga = new Promise((ok, mal) => {
      const s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      s.onload = () => (window.turnstile ? ok(window.turnstile) : mal(new Error('Cloudflare no respondió')));
      s.onerror = () => { carga = null; s.remove(); mal(new Error('No se pudo cargar la verificación de Cloudflare')); };
      document.head.appendChild(s);
    });
  }
  return carga;
}

// Pinta el recuadro en `el`. `al.token(t)` recibe cada token nuevo ('' cuando vence) y `al.error(código)` los errores de
// Cloudflare. Devuelve un control con: token, esperar(ms) (el token o '' si no llegó a tiempo), reiniciar() y quitar().
export async function pintarTurnstile(el, sitekey, accion, al = {}) {
  const ts = await cargarTurnstile();
  let token = '', esperando = [];
  const avisar = () => { const fs = esperando; esperando = []; fs.forEach(f => f(token)); };
  const id = ts.render(el, {
    sitekey, action: accion, language: 'es', theme: 'light', size: (el.clientWidth || 300) < 300 ? 'compact' : 'flexible',
    callback: t => { token = t; al.token && al.token(t); avisar(); },
    'expired-callback': () => { token = ''; al.token && al.token(''); },
    'timeout-callback': () => { token = ''; al.token && al.token(''); },
    'error-callback': codigo => { token = ''; al.error && al.error(codigo); avisar(); return true; },
  });
  return {
    get token() { return token; },
    esperar(ms = 15000) { return token ? Promise.resolve(token) : new Promise(ok => { esperando.push(ok); setTimeout(() => ok(token), ms); }); },
    reiniciar() { token = ''; try { ts.reset(id); } catch { /* el recuadro ya no está */ } },
    quitar() { try { ts.remove(id); } catch { /* el recuadro ya no está */ } },
  };
}
