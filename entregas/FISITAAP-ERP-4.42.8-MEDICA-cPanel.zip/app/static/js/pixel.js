// Píxeles de la página del negocio (FISITAAP, 3.58): etiqueta de Google (Analytics o Ads) y píxel de Meta (Facebook e Instagram).
// Solo se carga cuando el negocio escribió sus códigos en FISITAAP › Mi página; los ids vienen en etiquetas <meta> de la página
// (la política de seguridad no permite scripts escritos en la página). Expone window.gfEvento(nombre, datos) para que la tienda
// avise el pedido enviado (conversión).
const meta = n => { const el = document.querySelector('meta[name="' + n + '"]'); return el ? (el.getAttribute('content') || '').trim() : ''; };
const google = meta('gf:google'), fb = meta('gf:meta');

if (google) {
  const s = document.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(google); document.head.appendChild(s);
  window.dataLayer = window.dataLayer || [];
  window.gtag = function () { window.dataLayer.push(arguments); };
  window.gtag('js', new Date()); window.gtag('config', google, { anonymize_ip: true });
}
if (fb) {
  const s = document.createElement('script'); s.async = true; s.src = 'https://connect.facebook.net/en_US/fbevents.js';
  const n = window.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); };
  if (!window._fbq) window._fbq = n; n.push = n; n.loaded = true; n.version = '2.0'; n.queue = [];
  document.head.appendChild(s);
  window.fbq('init', fb); window.fbq('track', 'PageView');
}

// nombre: 'pedido' (pedido enviado), 'carrito' (ítem agregado), 'pago' (pago iniciado). datos: { valor, moneda, numero }
window.gfEvento = function (nombre, datos) {
  const d = datos || {};
  try {
    if (google && window.gtag) {
      if (nombre === 'pedido') window.gtag('event', 'purchase', { transaction_id: String(d.numero || ''), value: +d.valor || 0, currency: d.moneda || 'CRC' });
      else if (nombre === 'carrito') window.gtag('event', 'add_to_cart', { value: +d.valor || 0, currency: d.moneda || 'CRC' });
      else if (nombre === 'pago') window.gtag('event', 'begin_checkout', { value: +d.valor || 0, currency: d.moneda || 'CRC' });
    }
    if (fb && window.fbq) {
      if (nombre === 'pedido') window.fbq('track', 'Purchase', { value: +d.valor || 0, currency: d.moneda || 'CRC' });
      else if (nombre === 'carrito') window.fbq('track', 'AddToCart', { value: +d.valor || 0, currency: d.moneda || 'CRC' });
      else if (nombre === 'pago') window.fbq('track', 'InitiateCheckout', { value: +d.valor || 0, currency: d.moneda || 'CRC' });
    }
  } catch {}
};
