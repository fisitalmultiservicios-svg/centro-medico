// Enlaces de antes de la 1.36 (el sistema estaba en la raíz): /#/ventas, /#/restablecer?t=… → /app/#/…
(function () {
  function ir() { if (location.hash.indexOf('#/') === 0) location.replace('/app/' + location.hash); }
  ir();
  window.addEventListener('hashchange', ir);
})();
