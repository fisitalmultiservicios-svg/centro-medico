// 4.25 (tanda 7): conectar ESTA computadora (programa local) con la cuenta de la empresa en la página web. La usan la pantalla de
// ingreso (computadora sin estrenar, sin sesión) y Configuración › Instalación local (con sesión, sobre la empresa abierta).
// El programa pide el pase (POST /api/sinc/local/conexion/iniciar) y aquí se muestra el CÓDIGO con un enlace real a la página web
// (un window.open después de esperar al servidor lo bloquean los navegadores). Un administrador lo aprueba allá y la PÁGINA le muestra
// el NÚMERO DE COMPROBACIÓN (E-1): se escribe AQUÍ, junto con «Sí, es mi empresa», después de ver el nombre legal, la cédula y quién
// aprobó (E-4). El sondeo a la web vive en el servidor del programa (esta pestaña puede quedar oculta mientras se aprueba): la pantalla
// solo pregunta el estado cada 2 segundos y al volver a estar visible. El navegador nunca conoce el secreto: solo la llave del intento.
// Sin v-html: el nombre de la computadora, la empresa y quien aprobó se muestran con interpolación.
import { api } from './api.js';

const FINALES = ['rechazada', 'vencida', 'anulada', 'cancelada', 'perdida', 'otra_empresa', 'ya_esta'];   // 9b (U5): ya_esta
const CADA_MS = 2000;                 // consulta del estado a este programa (el programa pregunta a la web por su cuenta)
const ESPERA_BAJADA_MS = 180000;      // «Bajando los datos…»: tope de espera antes de ofrecer la salida
// 7b (T5): la llave del intento (no el secreto ni el número) queda en la pestaña: al recargar se retoma; se borra en cualquier final
const CLAVE_INTENTO = 'conexion:intento';
function guardarIntento(id) { try { if (id) sessionStorage.setItem(CLAVE_INTENTO, String(id)); else sessionStorage.removeItem(CLAVE_INTENTO); } catch {} }
function leerIntento() { try { return sessionStorage.getItem(CLAVE_INTENTO) || ''; } catch { return ''; } }
// 9c (J12): «Conectar otra empresa» tiene su marca propia en la pestaña ('conexion:otra' = la llave de SU intento; la pone la pantalla de
// Instalación local). Cada componente retoma solo un intento de su camino: el de otra empresa no retoma una reconexión, ni al revés.
function intentoDeOtra(id) { try { return !!id && sessionStorage.getItem('conexion:otra') === String(id); } catch { return false; } }

export default {
  props: {
    web: { type: String, default: '' },              // anfitrión de la página web (estado.local.web), para los textos
    equipo: { type: String, default: '' },           // nombre sugerido (el de Windows)
    conSesion: { type: Boolean, default: false },    // con sesión (Instalación local): un 401 lo atiende quien la usa (cuenta retirada)
    boton: { type: String, default: 'Conectar esta computadora' },
    otraEmpresa: { type: Boolean, default: false },  // 9b (U5): «Conectar otra empresa en esta computadora» (con sesión; no cambia la empresa abierta)
  },
  emits: ['lista', 'retirada', 'cancelar', 'antes', 'estado'],
  data() { return { nombre: (this.equipo || '').slice(0, 60), v: null, error: '', cargando: false, numero: '', ahora: Date.now(), recibido: 0, listaDesde: 0, vivo: true }; },
  computed: {
    sitio() { return (this.v && this.v.web) || this.web || 'la página web'; },
    restante() {
      if (!this.v) return '';
      const s = Math.max(0, Math.round((this.v.segundos || 0) - (this.ahora - this.recibido) / 1000));
      return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
    },
    final() { return !!this.v && FINALES.includes(this.v.estado); },
    bajando() { return !!this.v && this.v.estado === 'lista' && !this.v.bajada && this.ahora - this.listaDesde < ESPERA_BAJADA_MS; },
    pideNumero() { return !!this.v && (this.v.estado === 'confirmar' || (this.v.estado === 'retenida' && !this.v.numero_escrito)); },
    avanzado() { return !!this.v && (['aplicando', 'lista', 'fallo'].includes(this.v.estado) || !!this.v.numero_escrito); },
    // 9c (J9): «Le queda 1 intento.» / «Le quedan N intentos.»
    textoIntentos() { const n = this.v ? this.v.intentos_restantes : null; return n === null || n === undefined ? '' : (+n === 1 ? 'Le queda 1 intento.' : 'Le quedan ' + n + ' intentos.'); },
    // 9c (J10): la conexión se empezó con sesión (la vista del servidor trae con_sesion; si no viene, cómo se montó el componente): al
    // terminar, quien la hizo sigue adentro y el paso final dice solo «Listo»
    sigueConSesion() { return !!this.v && (this.v.con_sesion !== undefined && this.v.con_sesion !== null ? !!this.v.con_sesion : this.conSesion); },
  },
  methods: {
    opciones(body) { return { method: 'POST', body, sinExpirar: this.conSesion }; },
    poner(r) {
      if (!r || !r.estado) return;
      if (r.estado === 'lista' && !(this.v && this.v.estado === 'lista')) this.listaDesde = Date.now();
      this.v = r; this.recibido = Date.now(); this.error = '';
      if (FINALES.includes(r.estado) || r.estado === 'lista') guardarIntento('');
      this.$emit('estado', r.estado);
    },
    // 401 con sesión: al aplicarse la conexión, la cuenta creada en esta computadora quedó retirada (E-13); 410: el intento ya no está
    fallo(e) {
      if (e && e.status === 401 && this.conSesion) { this.parar(); guardarIntento(''); this.$emit('retirada', { mensaje: e.message, conectada: this.avanzado }); return; }
      if (e && e.status === 410) { this.parar(); guardarIntento(''); this.v = { ...(this.v || {}), estado: 'perdida', mensaje: e.message }; this.$emit('estado', 'perdida'); return; }
      this.error = (e && e.message) || 'No se pudo terminar de conectar. Intente de nuevo.';
    },
    async iniciar() {
      if (this.cargando) return;
      this.error = ''; this.cargando = true;
      this.$emit('antes');                 // 7b (T6): quien usa el componente deja su marca ANTES de empezar (síncrono)
      try {
        const r = await api('/api/sinc/local/conexion/iniciar', this.opciones(this.otraEmpresa ? { nombre: this.nombre.trim(), otra_empresa: true } : { nombre: this.nombre.trim() }));
        this.numero = ''; this.listaDesde = 0;
        guardarIntento(r.intento);
        // 7b (T5): sin sesión, si ya se había escrito el número en un intento, el programa devuelve ESE intento (retomado) y no crea otro
        if (r.retomado) this.poner(r);
        else this.poner({ intento: r.intento, estado: 'esperando', codigo: r.codigo, segundos: r.segundos, url: r.url, web: r.web, mensaje: '' });
        this.programar();
      } catch (e) { this.fallo(e); if (!(e && e.status === 401 && this.conSesion)) this.$emit('estado', 'sin_iniciar'); }
      this.cargando = false;
    },
    // 7b (T5): al crearse, retoma el intento guardado en la pestaña (410: ya no está; se borra y queda el formulario)
    async retomar(id) {
      if (intentoDeOtra(id) !== !!this.otraEmpresa) return;   // 9c (J12): ese intento es del otro camino
      this.cargando = true;
      try { this.poner(await api('/api/sinc/local/conexion/estado', this.opciones({ intento: id }))); this.programar(); }
      catch (e) {
        if (e && e.status === 410) { guardarIntento(''); this.v = null; this.$emit('estado', 'perdida'); }
        else if (e && e.status === 401) { if (this.conSesion) this.fallo(e); else guardarIntento(''); }   // sin sesión: era un intento con sesión
        else this.error = (e && e.message) || 'No se pudo consultar la conexión. Intente de nuevo.';
      }
      this.cargando = false;
    },
    programar() {
      clearTimeout(this._t);
      if (!this.vivo || !this.v || !this.v.intento || this.final) return;
      if (this.v.estado === 'lista' && (this.v.bajada || !this.bajando)) return;      // terminó, o pasó el tope de espera de la bajada
      this._t = setTimeout(() => this.consultar(), CADA_MS);
    },
    parar() { clearTimeout(this._t); this._t = null; },
    async consultar() {
      if (!this.vivo || !this.v || !this.v.intento || this.final) return;
      try { this.poner(await api('/api/sinc/local/conexion/estado', this.opciones({ intento: this.v.intento }))); }
      catch (e) {
        if (e.status === 401 || e.status === 410) return this.fallo(e);
        this.error = e.sinConexion ? 'El programa no responde: revise que siga abierto en esta computadora. Seguimos intentando.' : e.message;   // se sigue intentando
      }
      this.programar();
    },
    async confirmar() {
      const n = String(this.numero || '').replace(/\D/g, '');
      if (n.length !== 3) { this.error = 'Escriba las 3 cifras del número de comprobación que muestra la página web.'; return; }
      this.cargando = true;
      try { this.poner(await api('/api/sinc/local/conexion/confirmar', this.opciones({ intento: this.v.intento, numero: n, es_mia: true }))); this.numero = ''; }
      catch (e) { if (e.status === 401 || e.status === 410) this.fallo(e); else this.error = e.message; }
      this.cargando = false; this.programar();
    },
    async noEsMia() {
      if (!confirm('¿Esta no es su empresa? La conexión se cancela y esta computadora no recibe nada.')) return;
      this.cargando = true;
      try { this.poner(await api('/api/sinc/local/conexion/confirmar', this.opciones({ intento: this.v.intento, numero: '', es_mia: false }))); }
      catch (e) { if (e.status === 401 || e.status === 410) this.fallo(e); else this.error = e.message; }
      this.cargando = false; this.programar();
    },
    async reintentar() {
      this.cargando = true;
      try { this.poner(await api('/api/sinc/local/conexion/reintentar', this.opciones({ intento: this.v.intento }))); }
      catch (e) { this.fallo(e); }
      this.cargando = false; this.programar();
    },
    async cancelar() {
      this.parar();
      const intento = this.v && this.v.intento;
      this.v = null; this.error = ''; this.numero = '';
      guardarIntento('');
      if (intento) { try { await api('/api/sinc/local/conexion/cancelar', this.opciones({ intento })); } catch { /* el intento vence solo */ } }
      this.$emit('estado', 'cancelada');
      this.$emit('cancelar');
    },
    deNuevo() {
      this.parar();
      const intento = this.v && !this.final && this.v.estado !== 'lista' && this.v.intento;   // «fallo»: se suelta lo que quedó en memoria
      if (intento) api('/api/sinc/local/conexion/cancelar', this.opciones({ intento })).catch(() => {});
      guardarIntento('');
      if (intento) this.$emit('estado', 'cancelada');
      this.v = null; this.error = ''; this.numero = '';
    },
    entrar() { this.parar(); guardarIntento(''); this.$emit('lista', { empresa: (this.v && this.v.empresa) || null, empresa_id: this.v && this.v.empresa_id, con_sesion: this.sigueConSesion }); },
    alVolver() { if (document.visibilityState === 'visible' && this.v && !this.final) { this.parar(); this.consultar(); } },
  },
  created() { const id = leerIntento(); if (id) this.retomar(id); },
  mounted() {
    this._reloj = setInterval(() => { this.ahora = Date.now(); }, 1000);
    this._vis = () => this.alVolver();
    document.addEventListener('visibilitychange', this._vis);
  },
  beforeUnmount() { this.vivo = false; this.parar(); clearInterval(this._reloj); document.removeEventListener('visibilitychange', this._vis); },
  template: `
  <div class="conexion-local">
    <template v-if="!v">
      <Field label="Nombre de esta computadora" help="Así la verá en la lista de computadoras de su empresa: Caja 1, Recepción, Bodega…"><input v-model="nombre" maxlength="60" placeholder="Caja 1" @keyup.enter="iniciar"></Field>
      <div class="alert err small" style="margin:12px 0 0" v-if="error">{{error}}</div>
      <button class="btn" style="width:100%;justify-content:center;margin-top:14px;padding:11px" @click="iniciar" :disabled="cargando">{{cargando ? 'Pidiendo el código…' : (error ? 'Reintentar' : boton)}}</button>
    </template>
    <template v-else-if="v.estado === 'esperando'">
      <h2 style="font-size:17px;margin:0 0 10px">Apruebe esta computadora en la página web</h2>
      <p class="small" style="margin:0 0 8px">1. Abra la página web y entre con su correo y su contraseña de siempre. <a class="link" :href="v.url" target="_blank" rel="noopener"><b>Abrir {{sitio}}</b></a></p>
      <p class="small" style="margin:0 0 4px">2. Revise que la página muestre este mismo código:</p>
      <div class="mono" style="font-size:30px;font-weight:700;letter-spacing:3px;text-align:center;margin:4px 0 12px">{{v.codigo}}</div>
      <p class="small" style="margin:0 0 8px">3. Al aprobar, la página le muestra un <b>número de comprobación</b> de 3 cifras. Este programa se lo pedirá para terminar: escríbalo aquí, en esta computadora.</p>
      <p class="small" :class="v.sin_internet ? '' : 'muted'" :style="v.sin_internet ? 'color:var(--danger);margin:0 0 8px' : 'margin:0 0 8px'">{{v.sin_internet ? v.mensaje : 'Estamos esperando que la aprueben… Este código vence en ' + restante + '.'}}</p>
      <p class="small muted" style="margin:0 0 10px">¿La página no se abre? Desde cualquier computadora o celular entre a {{sitio}}, vaya a Configuración › Instalación local, toque «Tengo un código del programa» y escriba el código.</p>
      <div class="alert warn small" style="margin:0 0 12px">No comparta este código ni el número de comprobación por teléfono, correo o mensaje. Solo sirven para aprobar ESTA computadora.</div>
      <button class="btn ghost" style="width:100%;justify-content:center" @click="cancelar">Cancelar</button>
    </template>
    <template v-else-if="v.estado === 'confirmar' || v.estado === 'retenida'">
      <h2 style="font-size:17px;margin:0 0 8px">{{v.estado === 'retenida' ? 'Aprobada. Por seguridad se completa en unos minutos' : 'Aprobada en la página web'}}</h2>
      <p class="small" style="margin:0 0 8px">Antes de seguir, revise que esta sea su empresa:</p>
      <div class="small" style="border:1px solid var(--line);border-radius:8px;padding:10px 12px;margin:0 0 12px;display:grid;gap:4px">
        <div><b>Empresa:</b> {{(v.empresa && v.empresa.nombre) || '—'}}<span class="muted" v-if="v.empresa && v.empresa.nombre_comercial && v.empresa.nombre_comercial !== v.empresa.nombre"> ({{v.empresa.nombre_comercial}})</span></div>
        <div><b>Cédula:</b> <span class="mono">{{(v.empresa && v.empresa.numero_id) || '—'}}</span></div>
        <div><b>La aprobó:</b> {{(v.aprobo && v.aprobo.nombre) || ''}} <span class="muted">{{v.aprobo && v.aprobo.correo}}</span></div>
      </div>
      <p class="small muted" style="margin:0 0 10px" v-if="v.estado === 'retenida'">Quien aprobó usa otra conexión a internet que esta computadora (o no se pudo comprobar). Por seguridad la conexión espera unos minutos y se avisó a los administradores de la empresa.</p>
      <template v-if="pideNumero">
        <Field label="Número de comprobación" help="Son las 3 cifras que muestra la página web al aprobar. Si usted no aprobó en la página, o no está con quien la aprobó, toque «No es mi empresa»."><input v-model="numero" inputmode="numeric" maxlength="3" class="mono" style="font-size:22px;letter-spacing:6px;text-align:center" autocomplete="off" @keyup.enter="confirmar"></Field>
        <div class="alert err small" style="margin:10px 0 0" v-if="v.error">{{v.error}}<span v-if="textoIntentos"> {{textoIntentos}}</span></div>
        <div class="row" style="gap:8px;margin-top:14px;flex-wrap:wrap">
          <button class="btn" style="flex:1;justify-content:center" @click="confirmar" :disabled="cargando">Sí, es mi empresa</button>
          <button class="btn danger" style="flex:1;justify-content:center" @click="noEsMia" :disabled="cargando">No es mi empresa</button>
        </div>
      </template>
      <template v-else>
        <p class="small" style="margin:0 0 10px">Número recibido. La conexión se completa sola cuando termine la espera; no cierre el programa.</p>
        <button class="btn danger" style="width:100%;justify-content:center" @click="noEsMia" :disabled="cargando">No es mi empresa</button>
      </template>
    </template>
    <template v-else-if="v.estado === 'aplicando' || bajando">
      <h2 style="font-size:17px;margin:0 0 8px">Aprobada</h2>
      <p style="margin:0">Aprobada. Bajando los datos de su empresa… No cierre el programa; puede tardar un minuto.</p>
    </template>
    <template v-else-if="v.estado === 'lista'">
      <h2 style="font-size:17px;margin:0 0 8px">Listo</h2>
      <div class="alert ok" style="margin:0 0 10px">{{v.mensaje}}<template v-if="!v.con_sesion"><template v-if="v.reconexion"> Cada persona tiene que entrar una vez con su contraseña, con internet, para volver a usar su PIN y poder entrar sin internet en esta computadora.</template></template></div>
      <p class="small muted" style="margin:0 0 10px" v-if="!v.bajada">Los datos de su empresa todavía están bajando. Si al entrar le dice que esta computadora todavía está bajando los datos, espere un minuto e intente de nuevo.</p>
      <button class="btn" style="width:100%;justify-content:center;padding:11px" @click="entrar">{{otraEmpresa || sigueConSesion ? 'Listo' : 'Entrar'}}</button>
    </template>
    <template v-else-if="v.estado === 'fallo'">
      <div class="alert err" style="margin:0 0 12px">{{v.mensaje}}</div>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn" style="flex:1;justify-content:center" @click="reintentar" :disabled="cargando">{{cargando ? 'Reintentando…' : 'Reintentar'}}</button><button class="btn ghost" style="flex:1;justify-content:center" @click="deNuevo">Empezar de nuevo</button></div>
    </template>
    <template v-else>
      <div class="alert warn" style="margin:0 0 12px">{{v.mensaje || 'No se pudo terminar de conectar. Empiece de nuevo.'}}</div>
      <button class="btn" style="width:100%;justify-content:center" @click="deNuevo">Empezar de nuevo</button>
    </template>
    <div class="alert err small" style="margin:12px 0 0" v-if="v && error">{{error}}</div>
  </div>`,
};
