// FISITAAP › Resumen (r15_owner_dashboard del zip): saludo, cuatro indicadores, gráfica del período, pedidos que necesitan
// atención, «pequeños detalles» y la franja de FISIChat. Los números salen de /api/fisitaap/resumen (ventas del día = facturas y
// tiquetes emitidos; pedidos = pedidos web activos).
import { api, toast } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  data() { return { sesion, r: null, periodo: 'today', sucursal: 0, cargando: true }; },
  computed: {
    nombre() { return String(sesion.nombreUsuario || '').trim().split(/\s+/)[0] || ''; },
    pendientes() { return this.r ? this.r.pedidos.pendientes : []; },
    detalles() {
      if (!this.r) return [];
      const d = [{ ico: 'box', b: this.r.bajo_minimo + ' productos por revisar', p: 'Anticípate al mínimo de inventario.', a: 'Ver inventario', href: '/app/#/inventario/items' },
                 { ico: 'wallet', b: 'Tu caja, al día', p: 'Revisa el estado de tus turnos.', a: 'Revisar turno', href: '/app/#/pos/cierres' }];
      if (sesion.fisica && sesion.tieneModulo('entregas')) d.push({ ico: 'truck', b: 'Entregas en movimiento', p: 'Coordina a tu equipo de motorizados.', a: 'Ver Express', href: '#/express-pendientes' });
      return d;
    },
  },
  methods: {
    dinero,
    ini(n) { const p = String(n || '').trim().split(/\s+/); return ((p[0] || '')[0] || '').toUpperCase() + ((p[1] || '')[0] || '').toUpperCase(); },
    async cargar() {
      this.cargando = true;
      try { this.r = await api('/api/fisitaap/resumen?periodo=' + this.periodo + (this.sucursal ? '&sucursal_id=' + this.sucursal : '')); }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    tab(p) { this.periodo = p; this.cargar(); },
    chat() { window.dispatchEvent(new CustomEvent('fisichat:abrir')); },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <div class="page-heading"><div><p class="eyebrow">{{r ? r.hoy : ''}}</p><h1>Todo en orden, {{nombre}}.</h1><p>Esto es lo que está pasando en {{sesion.nombreNegocio}}.</p></div>
      <div class="toolbar"><form @submit.prevent><select class="input" v-model="sucursal" @change="cargar" aria-label="Sucursal del resumen" v-if="r && r.sucursales.length"><option :value="0">Todas las sucursales</option><option v-for="b in r.sucursales" :key="b.id" :value="b.id">{{b.nombre}}</option></select></form><a class="btn primary" href="/app/#/pos/caja"><Icono n="plus"/>Nueva venta</a></div></div>
    <div class="r15-overview-data" data-live-region="overview" v-if="r">
      <div class="metrics">
        <article class="card metric"><div class="metric-label">Ventas de hoy<Icono n="sales"/></div><strong class="metric-value" :title="dinero(r.ventas.total)">{{dinero(r.ventas.total)}}</strong><div class="metric-foot"><strong>Hoy</strong><span>ventas registradas</span></div></article>
        <article class="card metric"><div class="metric-label">Pedidos activos<Icono n="orders"/></div><strong class="metric-value">{{String(r.pedidos.activos).padStart(2, '0')}}</strong><div class="metric-foot"><strong>{{r.pedidos.nuevos}} nuevos</strong><span>por aceptar</span></div></article>
        <article class="card metric"><div class="metric-label">Ticket promedio<Icono n="credit"/></div><strong class="metric-value">{{dinero(r.ventas.ticket)}}</strong><div class="metric-foot"><strong>Hoy</strong><span>por venta</span></div></article>
        <article class="card metric"><div class="metric-label">Clientes atendidos<Icono n="users"/></div><strong class="metric-value">{{r.ventas.n}}</strong><div class="metric-foot"><strong>Hoy</strong><span>transacciones</span></div></article>
      </div>
      <div class="dash-grid">
        <section class="card dash-chart"><header class="card-header"><div><h2>Así se mueve tu negocio</h2><p>Ventas registradas · CRC</p></div><div class="tabs" aria-label="Período del gráfico"><a v-for="[k, l] in [['today','Hoy'],['week','Semana'],['month','Mes']]" :key="k" :class="{active: periodo===k}" href="#/resumen" @click.prevent="tab(k)">{{l}}</a></div></header>
          <Grafica :filas="r.grafica"></Grafica>
          <div class="chart-caption"><span><i class="dot"></i>Ventas completadas</span><a href="/app/#/pos/reportes">Ver reporte <Icono n="arrow"/></a></div></section>
        <section class="card dash-orders"><header class="card-header"><div><h2>Pedidos que necesitan atención</h2><p>{{r.pedidos.activos}} pedidos activos en este momento</p></div><span class="pill">{{r.pedidos.activos}}</span></header>
          <div class="orders-mini">
            <article class="order-mini" v-for="o in pendientes" :key="o.id"><span class="avatar">{{ini(o.nombre)}}</span><a :href="'#/pedido/' + o.id"><strong>{{o.nombre}}</strong><small>P-{{o.numero}} · {{o.tipo === 'recoger' ? 'Retiro en tienda' : 'Entrega'}}</small></a><div class="amount"><b>{{dinero(o.total)}}</b><span class="pill">{{o.estado_nombre}}</span></div></article>
            <div class="empty" v-if="!pendientes.length">Todos los pedidos están al día.</div>
          </div>
          <footer class="card-footer"><span>Cada pedido, en el momento correcto</span><a href="#/pedidos">Ver todos <Icono n="arrow"/></a></footer></section>
        <section class="card dash-activity"><header class="card-header"><h2>Pequeños detalles, gran diferencia</h2></header><div class="card-body activity-grid">
          <article class="activity-item" v-for="d in detalles" :key="d.b"><Icono :n="d.ico"/><div><b>{{d.b}}</b><p>{{d.p}}</p><a :href="d.href">{{d.a}} →</a></div></article>
        </div></section>
      </div>
      <div class="welcome-strip"><div><b>Más tiempo para lo que hace especial a tu negocio.</b><p>Ventas, pedidos y personas, conectados en un solo espacio.</p></div><button class="btn small" type="button" @click="chat">Hablar con FISIChat <Icono n="arrow"/></button></div>
    </div>
    <div v-else class="fis-cargando">{{cargando ? 'Cargando…' : 'Sin datos'}}</div>
  </div>`,
};
