// FISITAAP › Producto › Extras y opcionales (qa180_modifier_assignment del zip): qué extras y grupos de opcionales lleva un
// producto. Las asignaciones manuales se conservan al cambiar de categoría; las heredadas vienen de la categoría.
import { api, toast } from '/js/api.js';
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  data() { return { producto: null, grupos: [], sel: [], guardando: false }; },
  methods: {
    dinero,
    etiqueta(g) { return g.tipo === 'extra' ? dinero(g.precio) : 'Opcional'; },
    nombre(g) { return g.tipo === 'extra' ? g.nombre : g.nombre + ' · ' + g.opciones.map(o => o.nombre).join(', '); },
    async cargar() {
      try { const r = await api('/api/fisitaap/productos/' + this.params.id + '/modificadores'); this.producto = r.producto; this.grupos = r.grupos; this.sel = r.grupos.filter(g => g.manual || g.heredado).map(g => g.id); }
      catch (e) { toast(e.message, 'err'); }
    },
    async guardar() {
      this.guardando = true;
      try { await api('/api/fisitaap/productos/' + this.params.id + '/modificadores', { method: 'PUT', body: { grupos: this.sel } }); toast('Asignaciones guardadas.', 'ok'); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <section class="card admin-card" v-if="producto"><nav class="qa180-tabs"><a class="btn btn-light" :href="'/app/#/inventario/items/' + producto.id">General</a><a class="btn" :href="'#/producto-extras/' + producto.id">Extras y opcionales</a></nav><h2>{{producto.nombre}}</h2><p>Asignaciones manuales del producto se conservan al cambiar de categoría. Las heredadas se sustituyen por las de la nueva categoría. Si un extra es manual y heredado a la vez, aparece una sola vez.</p>
    <form @submit.prevent="guardar"><div class="qa180-modifier-list"><label v-for="g in grupos" :key="g.id"><input type="checkbox" :value="g.id" v-model="sel"> {{nombre(g)}} · {{etiqueta(g)}}<small v-if="g.heredado"> · heredado de la categoría</small></label><p v-if="!grupos.length">Todavía no hay extras ni opcionales. <a href="#/extras">Crear extras</a> · <a href="#/opcionales">Crear opcionales</a></p></div><button class="btn" :disabled="guardando">Guardar asignaciones</button></form></section>
  <div v-else class="fis-cargando">Cargando…</div>`,
};
