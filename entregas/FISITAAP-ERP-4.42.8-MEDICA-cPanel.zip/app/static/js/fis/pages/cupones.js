// FISITAAP › Códigos de descuento (qa180_coupons del zip): crear o editar un código (porcentaje o monto fijo, compra mínima,
// máximo de usos, vigencia) y la tabla de códigos existentes. Son los cupones del ERP, válidos en la caja y en la página.
import { api, toast } from '/js/api.js';
import { dinero, fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { lista: [], f: this.vacio(), guardando: false }; },
  methods: {
    dinero, fechaCorta,
    vacio() { return { id: null, codigo: '', nombre: '', tipo: 'pct', valor: 10, minimo: 0, usos_max: '', desde: '', hasta: '', caja: true, online: true, activo: true }; },
    async cargar() { try { this.lista = await api('/api/cupones'); } catch (e) { toast(e.message, 'err'); } },
    editar(c) { this.f = { id: c.id, codigo: c.codigo, nombre: c.nombre || '', tipo: c.tipo, valor: c.valor, minimo: c.minimo || 0, usos_max: c.usos_max || '', desde: c.desde || '', hasta: c.hasta || '', caja: (c.canales || '').includes('caja'), online: (c.canales || '').includes('online'), activo: c.activo !== false }; window.scrollTo(0, 0); },
    async guardar() {
      const f = this.f; const codigo = f.codigo.trim().toUpperCase();
      if (!/^[A-Z0-9_-]{2,20}$/.test(codigo)) return toast('Usa letras, números, guion o guion bajo (2 a 20 caracteres).', 'err');
      if (!(+f.valor > 0)) return toast('Indique el valor del descuento', 'err');
      if (f.tipo === 'pct' && +f.valor > 100) return toast('El descuento porcentual no puede superar 100%.', 'err');
      const canales = [f.caja ? 'caja' : null, f.online ? 'online' : null].filter(Boolean); if (!canales.length) return toast('Elija al menos un canal: caja o en línea', 'err');
      this.guardando = true;
      try {
        await api(f.id ? '/api/cupones/' + f.id : '/api/cupones', { method: f.id ? 'PUT' : 'POST', body: { codigo, nombre: f.nombre || '', tipo: f.tipo, valor: +f.valor, minimo: +f.minimo || 0, tope: null, desde: f.desde || null, hasta: f.hasta || null, usos_max: +f.usos_max > 0 ? +f.usos_max : null, usos_cliente: null, canales, activo: f.activo !== false } });
        toast('Código guardado. La aplicación valida los usos al confirmar.', 'ok'); this.f = this.vacio(); await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="card admin-card"><h2>{{f.id ? 'Editar código' : 'Crear código'}}</h2><p>Los límites se comprueban al confirmar; cada pedido o cuenta usa el código una vez. Vale en la caja, en la página o en ambas.</p>
      <form @submit.prevent="guardar">
        <div class="form-group"><label>Código</label><input class="input" v-model="f.codigo" maxlength="20" required style="text-transform:uppercase"></div>
        <label>Tipo<select class="input" v-model="f.tipo"><option value="pct">Porcentaje</option><option value="monto">Monto fijo</option></select></label>
        <div class="form-group"><label>Valor</label><input class="input" type="number" step=".01" min="0" v-model="f.valor" required></div>
        <div class="form-group"><label>Compra mínima</label><input class="input" type="number" step=".01" min="0" v-model="f.minimo"></div>
        <div class="form-group"><label>Máximo de usos (vacío = sin límite)</label><input class="input" type="number" step="1" min="1" v-model="f.usos_max"></div>
        <div class="form-group"><label>Inicio</label><input class="input" type="date" v-model="f.desde"></div>
        <div class="form-group"><label>Fin</label><input class="input" type="date" v-model="f.hasta"></div>
        <div class="form-group"><label>Nombre interno (opcional)</label><input class="input" v-model="f.nombre" maxlength="80"></div>
        <label><input type="checkbox" v-model="f.caja"> Vale en la caja</label><label><input type="checkbox" v-model="f.online"> Vale en pedidos en línea</label><label><input type="checkbox" v-model="f.activo"> Activo</label>
        <button class="btn" :disabled="guardando">Guardar código</button> <a class="btn btn-light" href="#/promociones">Precios especiales y 2 × 1</a> <button v-if="f.id" class="btn btn-light" type="button" @click="f = vacio()">Cancelar</button></form></section>
    <section class="card admin-card"><h2>Códigos existentes</h2><div class="table-wrap"><table class="table"><thead><tr><th>Código</th><th>Descuento</th><th>Usos</th><th>Estado</th><th></th></tr></thead><tbody>
      <tr v-for="c in lista" :key="c.id"><td>{{c.codigo}}</td><td>{{c.tipo === 'pct' ? c.valor + '%' : dinero(c.valor)}}</td><td>{{c.usados || 0}} / {{c.usos_max || 'Sin límite'}}</td><td>{{c.activo === false ? 'Inactivo' : 'Activo'}}</td><td><a href="#/cupones" @click.prevent="editar(c)">Editar</a></td></tr>
      <tr v-if="!lista.length"><td colspan="5">Todavía no hay códigos.</td></tr></tbody></table></div></section>
  </div>`,
};
