// FISITAAP › Promociones (r2_promotions del zip): precio especial o 2 × 1 por producto con vigencia. Los cupones y la
// fidelización tienen sus pantallas propias; el catálogo público aplica la promoción vigente al precio.
import { api, toast } from '/js/api.js';
import { dinero, fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { productos: [], lista: [], f: { producto_id: 0, tipo: 'special', valor: 0, desde: '', hasta: '' }, guardando: false }; },
  methods: {
    dinero, fechaCorta,
    async cargar() {
      try { const [p, l] = await Promise.all([api('/api/productos'), api('/api/fisitaap/promociones')]); this.productos = p.filter(x => x.activo !== false && x.es_venta !== false).sort((a, b) => a.nombre.localeCompare(b.nombre)); this.lista = l; if (!this.f.producto_id && this.productos.length) this.f.producto_id = this.productos[0].id; }
      catch (e) { toast(e.message, 'err'); }
    },
    async guardar() {
      if (!this.f.producto_id) return toast('Producto no disponible.', 'err');
      this.guardando = true;
      try { await api('/api/fisitaap/promociones', { method: 'POST', body: { ...this.f, valor: +this.f.valor || 0 } }); toast('Promoción guardada.', 'ok'); this.f = { ...this.f, valor: 0, desde: '', hasta: '' }; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async quitar(p) { try { await api('/api/fisitaap/promociones/' + p.id, { method: 'DELETE' }); toast('Promoción desactivada.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="r17-benefits-head"><span class="eyebrow">INCENTIVA LA PRÓXIMA COMPRA</span><h2>Ofertas claras para tus clientes</h2><p>Elige un precio especial o 2 × 1 por producto. Los cupones se aplican con un código; fidelización premia las compras de cada cliente.</p><nav class="r17-benefits-nav"><a class="btn btn-light" href="#/cupones">Cupones</a><a class="btn btn-light" href="#/fidelizacion">Fidelización</a></nav></section>
    <p><a class="btn btn-light" href="#/cupones">Administrar cupones</a></p>
    <div class="split"><section class="card admin-card"><form @submit.prevent="guardar"><label>Producto<select class="input" v-model="f.producto_id"><option v-for="p in productos" :key="p.id" :value="p.id">{{p.nombre}}</option></select></label><label>Promoción<select class="input" v-model="f.tipo"><option value="special">Precio especial</option><option value="bogo">2 × 1</option></select></label><div class="form-group"><label>Precio especial (no se usa en 2 × 1)</label><input class="input" type="number" step=".01" min="0" v-model="f.valor"></div><div class="form-group"><label>Inicio</label><input class="input" type="datetime-local" v-model="f.desde"></div><div class="form-group"><label>Fin</label><input class="input" type="datetime-local" v-model="f.hasta"></div><p>En 2 × 1, cada dos unidades de la misma selección pagan una. Los extras se cobran en todas las unidades.</p><button class="btn" :disabled="guardando">Guardar promoción</button></form></section>
    <section class="card admin-card">
      <article class="r2-row" v-for="p in lista" :key="p.id"><strong>{{p.producto}}</strong><span>{{p.tipo === 'bogo' ? '2 × 1' : dinero(p.valor)}}</span><small>{{(p.desde ? fechaCorta(p.desde) : 'Ahora') + ' — ' + (p.hasta ? fechaCorta(p.hasta) : 'Sin vencimiento')}}</small><form @submit.prevent="quitar(p)"><button class="btn btn-danger">Desactivar</button></form></article>
      <p v-if="!lista.length">Todavía no hay promociones activas.</p>
    </section></div>
  </div>`,
};
