// FISITAAP › Contactos (qa180_contacts del zip): bandeja de los mensajes del formulario de la página pública, con búsqueda,
// filtro por estado y lectura con cambio de estado (nuevo, leído, resuelto).
import { api, toast } from '/js/api.js';
import { fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { q: '', estado: '', lista: [], estados: { new: 'Nuevo', read: 'Leído', resolved: 'Resuelto' }, sel: null, nuevo: '', guardando: false }; },
  computed: { detalle() { return this.lista.find(x => x.id === this.sel) || null; } },
  methods: {
    fechaCorta,
    async cargar() { try { const r = await api('/api/fisitaap/contactos?q=' + encodeURIComponent(this.q) + '&estado=' + this.estado); this.lista = r.lista; } catch (e) { toast(e.message, 'err'); } },
    abrir(x) { this.sel = x.id; this.nuevo = x.estado; if (x.estado === 'new') this.guardarEstado('read', true); },
    async guardarEstado(est, silencioso) {
      const x = this.detalle; if (!x) return; this.guardando = true;
      try { const r = await api('/api/fisitaap/contactos/' + x.id, { method: 'PUT', body: { estado: est || this.nuevo } }); Object.assign(x, r); this.nuevo = x.estado; if (!silencioso) toast('Estado guardado.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="card admin-card"><form class="qa180-filter" @submit.prevent="cargar"><div class="form-group"><label>Buscar en mensajes</label><input class="input" v-model="q" maxlength="100"></div><label>Estado<select class="input" v-model="estado"><option value="">Todos</option><option value="new">Nuevos</option><option value="read">Leídos</option><option value="resolved">Resueltos</option></select></label><button class="btn">Buscar</button></form></section>
    <div class="qa180-inbox"><section class="card admin-card qa180-inbox-list">
      <a v-for="x in lista" :key="x.id" class="qa180-message" :class="{selected: sel === x.id, unread: x.estado === 'new'}" href="#/contactos" @click.prevent="abrir(x)"><span>{{x.nombre}}<small>{{fechaCorta(x.creado)}}</small></span><strong>{{x.asunto}}</strong><p>{{(x.mensaje || '').slice(0, 100)}}</p></a>
      <p v-if="!lista.length">No hay mensajes con estos filtros.</p>
    </section><section class="card admin-card qa180-reading">
      <template v-if="detalle"><h2>{{detalle.asunto}}</h2><p><strong>{{detalle.nombre}}</strong> · {{detalle.correo || 'sin correo'}}<br>{{detalle.telefono || 'sin teléfono'}} · {{fechaCorta(detalle.creado)}}</p><div class="qa180-message-body" style="white-space:pre-line">{{detalle.mensaje}}</div>
        <form @submit.prevent="guardarEstado()"><label>Estado<select class="input" v-model="nuevo"><option v-for="(l, k) in estados" :key="k" :value="k">{{l}}</option></select></label><button class="btn btn-light" :disabled="guardando">Guardar estado</button></form></template>
      <template v-else><h2>Bandeja de mensajes</h2><p>Selecciona un contacto para leerlo y cambiar su estado.</p></template>
    </section></div>
  </div>`,
};
