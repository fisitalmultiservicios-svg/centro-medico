// FISITAAP › Administración › Diseño web (qa180_design del zip): secciones plegables (portada, Nosotros, productos y servicios,
// slider del catálogo, contacto, colores y botones), imágenes con «quitar», y la vista previa publicada. Textos y colores en el
// diseño de FISITAAP; portada, galería, Nosotros, contacto y color principal en el negocio público del ERP.
import { api, toast } from '/js/api.js';
import { cargarNegocio, guardarNegocio } from '/js/pages/fisitaap/_negocio.js';
import { sesion } from '../sesion.js';

const CAMPOS = { hero_title: 'Título principal', hero_text: 'Texto principal', about_label: 'Etiqueta de la sección Nosotros', about_promise_1: 'Frase destacada 1', about_promise_2: 'Frase destacada 2', about_promise_3: 'Frase destacada 3', about_button_label: 'Botón de la sección Nosotros', about_title: 'Título de presentación', about_text: 'Presentación del negocio', services_title: 'Título de productos y servicios', service_1_title: 'Tarjeta 1 · título', service_1_text: 'Tarjeta 1 · texto', service_2_title: 'Tarjeta 2 · título', service_2_text: 'Tarjeta 2 · texto', service_3_title: 'Tarjeta 3 · título', service_3_text: 'Tarjeta 3 · texto', contact_title: 'Título de contacto', contact_text: 'Texto de contacto', catalog_intro_title: 'Título de portada del catálogo', catalog_intro_text: 'Texto de portada del catálogo', catalog_intro_title_2: 'Título de imagen 2', catalog_intro_text_2: 'Texto de imagen 2', catalog_intro_title_3: 'Título de imagen 3', catalog_intro_text_3: 'Texto de imagen 3', hero_button_label: 'Botón principal', catalog_button_label: 'Botones de catálogo / menú' };
const SECCIONES = [['portada', 'Portada', ['hero_title', 'hero_text'], ['hero_image']], ['nosotros', 'Nosotros', ['about_label', 'about_title', 'about_text', 'about_promise_1', 'about_promise_2', 'about_promise_3', 'about_button_label'], ['about_image']], ['servicios', 'Productos y servicios', ['services_title', 'service_1_title', 'service_1_text', 'service_2_title', 'service_2_text', 'service_3_title', 'service_3_text'], ['service_1_image', 'service_2_image', 'service_3_image']], ['catalogo', 'Portada del catálogo o menú', [], []], ['contacto', 'Contacto', ['contact_title', 'contact_text'], []]];

export default {
  props: ['params'],
  data() { return { sesion, n: null, d: null, CAMPOS, SECCIONES, abiertas: { portada: true, catalogo: true }, guardando: false, subiendo: '' }; },
  computed: {
    galeria() { return this.n ? this.n.galeria : []; },
    url() { const n = this.n; return n ? (n.url_publica || n.url) : ''; },
    // 3.87: la vista previa se carga desde este mismo servidor (/t/<negocio>): la dirección pública (dominio propio, www o la de la
    // nube vista desde la instalación local) es otro origen y la política de seguridad del panel la bloqueaba
    vista() { const n = this.n; return n && n.slug ? '/t/' + encodeURIComponent(n.slug) : ''; },
    urlCatalogo() { return this.url ? this.url + '#catalogo' : ''; },
  },
  methods: {
    imagen(k) { const nombre = this.d[k]; if (!nombre) return ''; if (k === 'hero_image' && !nombre && this.n.portada) return this.n.portada; const g = this.galeria.find(x => x.nombre === nombre); return g ? g.url : ''; },
    async cargar() { try { this.n = await cargarNegocio(); this.d = await api('/api/fisitaap/diseno'); if (!this.d.hero_image && this.n.portada) this.d.hero_image = '__portada__'; } catch (e) { toast(e.message, 'err'); } },
    imagenDe(k) { if (k === 'hero_image' && this.d.hero_image === '__portada__') return this.n.portada; return this.imagen(k); },
    async subir(k, ev) {
      const f = ev.target.files && ev.target.files[0]; ev.target.value = ''; if (!f) return;
      if (f.size > 4 * 1024 * 1024) return toast('Imágenes JPG, PNG o WebP de hasta 4 MB.', 'err');
      this.subiendo = k;
      try {
        const fd = new FormData(); fd.append('archivo', f, f.name);
        if (k === 'hero_image') { const r = await api('/api/pedidos/negocio/portada', { method: 'POST', body: fd }); this.n.portada = r.portada; this.d.hero_image = '__portada__'; }
        else { const r = await api('/api/pedidos/negocio/galeria', { method: 'POST', body: fd }); const antes = new Set(this.n.galeria.map(x => x.nombre)); this.n.galeria = r.galeria; const nueva = r.galeria.find(x => !antes.has(x.nombre)); if (nueva) this.d[k] = nueva.nombre; }
      } catch (e) { toast(e.message, 'err'); }
      this.subiendo = '';
    },
    quitar(k) { if (k === 'hero_image') { api('/api/pedidos/negocio/portada', { method: 'DELETE' }).then(() => { this.n.portada = null; }).catch(e => toast(e.message, 'err')); } this.d[k] = ''; },
    async guardar() {
      this.guardando = true;
      try {
        const campos = { ...this.d }; if (campos.hero_image === '__portada__') campos.hero_image = '';
        const n = this.n; n.color = this.d.primary_color || n.color;
        this.n = await guardarNegocio(n); this.d = await api('/api/fisitaap/diseno', { method: 'PUT', body: { campos } }); if (!this.d.hero_image && this.n.portada) this.d.hero_image = '__portada__';
        await sesion.recargarNegocio(); toast('Diseño guardado. La vista previa muestra la página publicada.', 'ok');
        const f = this.$refs.vista; if (f) f.src = f.src;
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div v-if="n && d">
    <p>Abre una sección, cambia sus textos o imágenes y guarda. Los colores se aplican a tu página y catálogo; el panel de administración mantiene su estilo.</p><p>Imágenes JPG, PNG o WebP de hasta 4 MB. Tamaños recomendados: portada 1600 × 900 px (horizontal); Nosotros 800 × 800 px (cuadrada) o 1000 × 700 px; tarjetas de productos y servicios 800 × 600 px (horizontal); slider del catálogo 1600 × 700 px (horizontal). En la página cada imagen se recorta al tamaño de su espacio, así que una foto más grande no la desborda.</p>
    <nav class="qa180-design-links"><a class="btn btn-light" href="#design-nosotros" @click="abiertas.nosotros = true">Editar Nosotros y frases</a> <a class="btn btn-light" href="#design-contacto" @click="abiertas.contacto = true">Editar contacto</a> <a class="btn btn-light" href="#design-catalogo" @click="abiertas.catalogo = true">Editar slider del catálogo</a></nav>
    <div class="qa180-design"><form class="card admin-card" @submit.prevent="guardar">
      <details v-for="s in SECCIONES" :key="s[0]" :id="'design-' + s[0]" class="qa180-design-section" :open="abiertas[s[0]] || null" @toggle="e => abiertas[s[0]] = e.target.open"><summary>{{s[1]}}</summary>
        <template v-if="s[0] === 'catalogo'">
          <p>Este slider es el banner que aparece arriba del catálogo. Elige «Usar la portada y todas las fotos de la galería» para pasar sin límite todas las fotos que suba en Publicar › Portada y galería, o cargue aquí hasta tres imágenes con su propio texto. Tamaño recomendado: 1600 × 700 px (horizontal); cada imagen se muestra completa, sin recortes.</p>
          <label>Mostrar slider<select class="input" v-model="d.catalog_intro_mode"><option value="auto">Usar la portada y todas las fotos de la galería (sin límite)</option><option value="custom">Usar estas tres imágenes con texto</option><option value="hidden">Ocultar slider</option></select></label>
          <div class="form-group"><label>Segundos entre imágenes</label><input class="input" type="number" min="2" max="60" step="1" v-model="d.catalog_slide_seconds" required></div><small>De 2 a 60 segundos. Con una sola imagen no hay cambios automáticos.</small>
          <div class="r11-slider-editor"><fieldset v-for="i in [1, 2, 3]" :key="i"><legend>Imagen {{i}}</legend><img v-if="imagenDe('catalog_intro_image' + (i === 1 ? '' : '_' + i))" class="r2-editor-image" :src="imagenDe('catalog_intro_image' + (i === 1 ? '' : '_' + i))" :alt="'Imagen ' + i + ' actual'"><p class="muted" v-else>Sin imagen cargada</p><label>Seleccionar imagen {{i}}<input class="input" type="file" accept="image/jpeg,image/png,image/webp" @change="subir('catalog_intro_image' + (i === 1 ? '' : '_' + i), $event)" :disabled="!!subiendo"></label><div class="form-group"><label>Título (opcional)</label><input class="input" v-model="d['catalog_intro_title' + (i === 1 ? '' : '_' + i)]" maxlength="80"></div><div class="form-group"><label>Texto (opcional)</label><input class="input" v-model="d['catalog_intro_text' + (i === 1 ? '' : '_' + i)]" maxlength="300"></div><label><input type="checkbox" :checked="!d['catalog_intro_image' + (i === 1 ? '' : '_' + i)]" @change="quitar('catalog_intro_image' + (i === 1 ? '' : '_' + i))"> Quitar imagen {{i}}</label></fieldset></div>
          <div class="form-group"><label>Color de títulos y textos del slider</label><input class="input" type="color" v-model="d.catalog_text_color" required></div><p>Los cambios se publican al pulsar Guardar diseño. Las imágenes se comprimen automáticamente.</p>
        </template>
        <template v-else>
          <label v-for="k in s[2]" :key="k">{{CAMPOS[k]}}<textarea class="input" rows="2" maxlength="3000" v-model="d[k]"></textarea></label>
          <template v-for="k in s[3]" :key="k"><label>Imagen <small class="muted">({{k === 'hero_image' ? '1600 × 900 px (horizontal)' : k === 'about_image' ? '800 × 800 px (cuadrada) o 1000 × 700 px' : '800 × 600 px (horizontal)'}})</small><img v-if="imagenDe(k)" class="r2-editor-image" :src="imagenDe(k)" alt="Imagen actual"><input class="input" type="file" accept="image/jpeg,image/png,image/webp" @change="subir(k, $event)" :disabled="!!subiendo"></label><label v-if="imagenDe(k)"><input type="checkbox" @change="quitar(k)"> Quitar imagen</label></template>
          <fieldset v-if="s[0] === 'contacto'"><legend>Datos de contacto publicados</legend>
            <div class="form-group"><label>Teléfono</label><input class="input" v-model="n.telefono" maxlength="12" inputmode="numeric"></div><div class="form-group"><label>WhatsApp</label><input class="input" v-model="n.whatsapp" maxlength="12" inputmode="numeric"><small class="muted">Número al que llevan «Escríbenos por WhatsApp», «Consultar» y el envío del pedido. Vacío = se usa el teléfono; sin ninguno de los dos, el botón no se muestra.</small></div><div class="form-group"><label>Dirección</label><input class="input" v-model="n.direccion" maxlength="200"></div>
            <div class="form-group"><label>Facebook</label><input class="input" v-model="n.redes.facebook" maxlength="1000"></div><div class="form-group"><label>Instagram</label><input class="input" v-model="n.redes.instagram" maxlength="1000"></div><div class="form-group"><label>Enlace de ubicación (Waze o Google Maps)</label><input class="input" v-model="n.redes.maps" maxlength="200"></div>
          </fieldset><p v-if="s[0] === 'contacto'">Estos datos se comparten con Administración → Generales y el catálogo. Al guardarlos aquí se actualizan en ambos lugares.</p><a v-if="s[0] === 'contacto'" class="btn btn-light" href="#/configuracion">Abrir datos generales</a>
        </template>
      </details>
      <details class="qa180-design-section"><summary>Colores y botones</summary>
        <div class="form-group"><label>Color principal</label><input class="input" type="color" v-model="n.color" required></div><div class="form-group"><label>Color de acento</label><input class="input" type="color" v-model="d.accent_color" required></div>
        <div class="form-group"><label>{{CAMPOS.hero_button_label}}</label><input class="input" v-model="d.hero_button_label" maxlength="80"></div><div class="form-group"><label>{{CAMPOS.catalog_button_label}}</label><input class="input" v-model="d.catalog_button_label" maxlength="80"></div>
        <label>Tema<select class="input" v-model="n.tema"><option value="claro">Claro</option><option value="oscuro">Oscuro</option></select></label><label>Tipo de letra<select class="input" v-model="n.fuente"><option value="">La del sistema</option><option value="inter">Inter (moderna)</option><option value="manrope">Manrope (redondeada)</option><option value="clasica">Clásica (con serifas)</option></select></label>
        <a v-if="url" class="btn btn-light" target="_blank" rel="noopener" :href="urlCatalogo">Abrir catálogo / menú</a></details>
      <button class="btn" :disabled="guardando">Guardar diseño</button></form>
      <aside class="card admin-card"><h2>Vista previa publicada</h2><p>Los cambios aparecen después de guardar.</p><a v-if="url" class="btn btn-light" target="_blank" rel="noopener" :href="url">Abrir página completa</a><p v-else>La página todavía no tiene dirección: escríbala en <a href="#/publicar">Publicar y dominio</a>.</p><iframe v-if="vista && n.activo" ref="vista" class="qa180-design-preview" title="Vista previa de la página de tu tienda" loading="lazy" :src="vista"></iframe><p v-else-if="url">La página no está publicada todavía: pulse Publicar en <a href="#/publicar">Publicar y dominio</a>.</p></aside>
    </div>
  </div>
  <div v-else class="fis-cargando">Cargando…</div>`,
};
