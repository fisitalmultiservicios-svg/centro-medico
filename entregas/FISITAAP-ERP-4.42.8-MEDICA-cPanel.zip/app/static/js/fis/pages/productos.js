// FISITAAP › Productos (tenant_products_v5 del zip, con la regla de la fusión): los productos son los ítems del Inventario del
// ERP; aquí se decide qué se publica en la página, cómo se muestra (destacado, agotado, descripción pública) y sus extras.
// Precio, foto, impuestos y existencias se editan en el ERP.
// 4.40: etiqueta «Sin existencias» cuando la página lo muestra agotado por existencias (it.agotado_existencias, opción «Mostrar agotado según existencias»).
import { api, toast } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero } from '../ui.js';

// 4.40: la bodega puede llegar como nombre o como {id, nombre}
const nombreBodega = b => (!b ? '' : typeof b === 'string' ? b : (b.nombre || ''));

export default {
  props: ['params'],
  data() { return { sesion, items: [], categorias: [], grupos: [], q: '', solo: 'todos', abierto: null, texto: '', cargando: true, bodega: '' }; },   // 4.40: bodega del agotado según existencias
  computed: {
    // 4.40: título de la etiqueta «Sin existencias»
    tituloSinExistencias() { return 'Se muestra agotado en la página porque no hay unidades disponibles en ' + (this.bodega || 'la bodega de la caja que recibe los pedidos') + '. Queda disponible de nuevo por sí solo cuando entren unidades.'; },
    puede() { return sesion.puede('catalogos'); },
    visibles() { return this.items.filter(i => i.visible_catalogo).length; },
    filtrados() {
      const q = this.q.trim().toLowerCase();
      return this.items.filter(i => (this.solo === 'todos' || (this.solo === 'visibles' ? i.visible_catalogo : !i.visible_catalogo)) && (!q || i.nombre.toLowerCase().includes(q) || (i.categoria || '').toLowerCase().includes(q)));
    },
    porCategoria() {
      const por = {}; for (const c of this.categorias) por[c] = { nombre: c, total: 0, visibles: 0 };
      for (const i of this.items) { const c = i.categoria || 'Otros'; por[c] = por[c] || { nombre: c, total: 0, visibles: 0 }; por[c].total++; if (i.visible_catalogo) por[c].visibles++; }
      return Object.values(por).filter(c => c.total);
    },
  },
  methods: {
    dinero,
    opciones(it) { return this.grupos.filter(g => g.productos.includes(it.id) || (it.categoria && g.categorias.includes(it.categoria))).length; },
    estado(it) { return !it.visible_catalogo ? 'Oculto' : it.agotado ? 'Agotado' : 'Activo'; },
    async cargar() {
      this.cargando = true;
      try { const [r, m] = await Promise.all([api('/api/pedidos/catalogo'), api('/api/fisitaap/modificadores')]); this.items = r.items; this.categorias = r.categorias; this.grupos = m.grupos; this.bodega = nombreBodega(r.bodega) || this.bodega; }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false; this.cargarBodega();
    },
    // 4.40: el nombre de la bodega viene en el listado; si no viene y algún producto sale agotado por existencias, se pide a la vista previa;
    // si tampoco responde, el título dice «la bodega de la caja que recibe los pedidos»
    async cargarBodega() {
      if (this.bodega || !this.puede || !this.items.some(i => i.agotado_existencias)) return;
      try { const v = await api('/api/pedidos/catalogo/agotado-vista'); this.bodega = nombreBodega(v && v.bodega); } catch { this.bodega = ''; }
    },
    async cambiar(it, campo, valor) {
      if (!this.puede) return toast('Su rol no puede cambiar el catálogo', 'err');
      if ((campo === 'destacado' || campo === 'agotado') && !it.visible_catalogo) return toast('Primero muestre el ítem en la página', 'err');
      const antes = it[campo]; it[campo] = valor;
      try { const r = await api('/api/pedidos/catalogo/' + it.id, { method: 'PUT', body: { [campo]: valor } }); Object.assign(it, r); }
      catch (e) { it[campo] = antes; toast(e.message, 'err'); }
    },
    async grupo(c, valor) {
      const ids = this.items.filter(i => (i.categoria || 'Otros') === c.nombre && i.visible_catalogo !== valor).map(i => i.id); if (!ids.length) return;
      try { await api('/api/pedidos/catalogo/lote', { method: 'POST', body: { ids, visible_catalogo: valor } }); this.items.forEach(i => { if (ids.includes(i.id)) i.visible_catalogo = valor; }); toast((valor ? 'Publicados ' : 'Ocultos ') + ids.length + ' producto(s) de ' + c.nombre, 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    },
    editar(it) { if (this.abierto === it.id) { this.abierto = null; return; } this.abierto = it.id; this.texto = it.descripcion_publica || ''; },
    async guardarTexto(it) { await this.cambiar(it, 'descripcion_publica', this.texto.trim()); this.abierto = null; toast('Producto guardado.', 'ok'); },
  },
  created() { this.cargar(); },
  template: `
  <div class="split"><section class="card admin-card"><h2>Publicar en la página</h2><p><strong>{{visibles}}</strong> de {{items.length}} producto(s) a la venta se muestran en tu catálogo. Un producto «agotado» se ve pero no se puede pedir. Con «Mostrar agotado según existencias» encendido, también se agota solo al llegar a 0. «Destacado» sale de primero.</p>
      <div class="form-group"><label>Buscar</label><input class="input" v-model="q" placeholder="Nombre o categoría"></div>
      <label>Mostrar<select class="input" v-model="solo"><option value="todos">Todos</option><option value="visibles">Solo los publicados</option><option value="ocultos">Solo los ocultos</option></select></label>
      <h3>Por categoría</h3><div class="qa180-modifier-list"><div class="r2-row" v-for="c in porCategoria" :key="c.nombre"><strong>{{c.nombre}}</strong><span>{{c.visibles}} de {{c.total}}</span><button class="btn btn-light" type="button" @click="grupo(c, true)" :disabled="!puede || c.visibles === c.total">Mostrar todos</button><button class="btn btn-light" type="button" @click="grupo(c, false)" :disabled="!puede || !c.visibles">Ocultar todos</button></div></div>
      <p>Los productos nuevos, sus precios, fotos e impuestos se crean en el ERP.</p><a class="btn btn-block" href="/app/#/inventario/items/nuevo">Nuevo producto en el ERP</a></section>
    <section class="card admin-card"><h2>Catálogo</h2><div class="table-wrap"><table class="table"><tr><th>Producto</th><th>Tipo</th><th>Precio</th><th>Opciones</th><th>Estado</th><th></th></tr>
      <template v-for="it in filtrados" :key="it.id"><tr><td><strong>{{it.nombre}}</strong><br><small>{{it.categoria || 'Sin categoría'}}</small></td><td>{{it.tipo || 'Producto'}}</td><td>{{dinero(it.precio)}}</td><td>{{opciones(it)}}</td><td><span class="status" :class="{'status-off': !it.visible_catalogo || it.agotado}">{{estado(it)}}</span></td>
        <td class="fis-tabla-acciones"><a class="btn btn-light" href="#/productos" @click.prevent="cambiar(it, 'visible_catalogo', !it.visible_catalogo)">{{it.visible_catalogo ? 'Ocultar' : 'Publicar'}}</a> <a class="btn btn-light" href="#/productos" @click.prevent="cambiar(it, 'destacado', !it.destacado)" v-if="it.visible_catalogo">{{it.destacado ? 'Quitar destacado' : 'Destacar'}}</a> <a class="btn btn-light" href="#/productos" @click.prevent="cambiar(it, 'agotado', !it.agotado)" v-if="it.visible_catalogo">{{it.agotado ? 'Disponible' : 'Agotado'}}</a> <span v-if="it.agotado_existencias && it.visible_catalogo" class="status" style="background:#f2f4f7;color:#475467" :title="tituloSinExistencias" data-sin-existencias>Sin existencias</span> <a class="btn btn-light" href="#/productos" @click.prevent="editar(it)">Descripción</a> <a class="btn btn-light" :href="'#/producto-extras/' + it.id">Extras / opcionales</a> <a class="btn btn-light" :href="'/app/#/inventario/items/' + it.id">Editar en el ERP</a></td></tr>
        <tr v-if="abierto === it.id"><td colspan="6"><form @submit.prevent="guardarTexto(it)"><label>Descripción pública<textarea class="input" rows="2" v-model="texto" maxlength="300" placeholder="Lo que ve el cliente debajo del nombre (hasta 300 caracteres)"></textarea></label><button class="btn">Guardar producto</button> <button class="btn btn-light" type="button" @click="abierto = null">Cerrar</button></form></td></tr></template>
      <tr v-if="!cargando && !filtrados.length"><td colspan="6">No hay productos con ese filtro. Cree ítems en el ERP y vuelva aquí para publicarlos.</td></tr></table></div></section></div>`,
};
