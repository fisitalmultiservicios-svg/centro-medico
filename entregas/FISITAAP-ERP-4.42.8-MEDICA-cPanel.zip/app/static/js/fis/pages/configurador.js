// FISITAAP › Configurador (academy17_setup del zip): recorrido guiado por pasos para dejar la tienda lista. Cada paso abre la
// pantalla correspondiente (de FISITAAP o del ERP) y «Listo, continuar» avanza; se puede pausar y retomar.
import { api, toast } from '/js/api.js';
import { sesion } from '../sesion.js';

export default {
  props: ['params'],
  data() { return { sesion, c: null, ocupado: false }; },
  computed: {
    paso() { return this.c ? Math.min(this.c.total, this.c.paso) : 0; },
    actual() { return this.c && this.paso < this.c.total ? this.c.pasos[this.paso] : null; },
    enlace() {
      if (!this.actual) return '#';
      const r = this.actual[2];
      if (r === 'tienda') { const n = sesion.negocio; return n && n.slug && n.activo ? (n.url_publica || ('/' + n.slug)) : '#/publicar'; }
      return r;
    },
  },
  methods: {
    async cargar() { try { this.c = await api('/api/fisitaap/configurador'); } catch (e) { toast(e.message, 'err'); } },
    async accion(a) {
      this.ocupado = true;
      try { this.c = await api('/api/fisitaap/configurador', { method: 'PUT', body: { accion: a, paso: a === 'next' ? this.paso : null } }); if (a === 'pause') { toast('Configurador pausado. Puedes retomarlo desde el menú.', 'ok'); location.hash = '#/bienvenida'; } }
      catch (e) { toast(e.message, 'err'); }
      this.ocupado = false;
    },
  },
  created() { if (!sesion.esDueno) { toast('El configurador está disponible para el dueño.', 'err'); location.hash = '#/resumen'; return; } this.cargar(); },
  template: `
  <section class="card a17-config" v-if="c"><span class="eyebrow">A TU RITMO</span><h1>Configuremos FISITAAP juntos</h1><p>Completa cada pantalla, guarda y vuelve con el botón «Volver al configurador». Puedes omitir pasos que no correspondan a tu plan.</p><progress :max="c.total" :value="paso"></progress><p>Paso {{Math.min(c.total, paso + 1)}} de {{c.total}}</p>
    <template v-if="actual"><h2>{{actual[0]}}</h2><p>{{actual[1]}}</p><a class="btn" :href="enlace" :target="actual[2] === 'tienda' ? '_blank' : null">Abrir {{actual[0].toLowerCase()}} →</a><form @submit.prevent="accion('next')"><button class="btn btn-light" :disabled="ocupado">Listo, continuar</button></form></template>
    <template v-else><h2>Tu recorrido de configuración está completo</h2><p>Puedes volver a cualquier pantalla desde el menú o practicar en Academiaap.</p><a class="btn" href="#/resumen">Ir al resumen</a></template>
    <div class="a17-config-actions"><form v-if="paso" @submit.prevent="accion('back')"><button class="btn btn-light" :disabled="ocupado">Paso anterior</button></form><form @submit.prevent="accion('pause')"><button class="btn btn-light" :disabled="ocupado">Pausar y salir</button></form></div>
  </section>
  <div v-else class="fis-cargando">Cargando…</div>`,
};
