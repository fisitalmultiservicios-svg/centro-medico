// FISITAAP › Grupos de opcionales (qa180_optional_groups del zip): Tallas con S, M y L; Colores con Rojo y Azul. Sin costo
// adicional; obligatorio o no; de una o varias opciones; asignados a productos o categorías. Mismo registro que los extras.
import { api, toast } from '/js/api.js';
import { AvisoRecuperarMods } from '/js/pages/pos/_recuperar_mods.js';   // 4.30: recuperar de un respaldo los productos y categorías perdidos

export default {
  props: ['params'],
  components: { AvisoRecuperarMods },
  data() { return { grupos: [], productos: [], categorias: [], f: this.vacio(), guardando: false }; },
  computed: { editando() { return !!this.f.id; } },
  methods: {
    vacio() { return { id: null, nombre: '', opciones: [{ id: null, nombre: '' }], obligatorio: false, multiple: false, productos: [], categorias: [] }; },
    async cargar() { try { const r = await api('/api/fisitaap/modificadores?tipo=opcional'); this.grupos = r.grupos; this.productos = r.productos; this.categorias = r.categorias; } catch (e) { toast(e.message, 'err'); } },
    editar(g) { this.f = { id: g.id, nombre: g.nombre, opciones: g.opciones.map(o => ({ id: o.id, nombre: o.nombre })), obligatorio: g.obligatorio, multiple: g.multiple, productos: [...g.productos], categorias: [...g.categorias] }; if (!this.f.opciones.length) this.f.opciones.push({ id: null, nombre: '' }); window.scrollTo(0, 0); },
    agregar() { if (this.f.opciones.length >= 50) return toast('El grupo permite hasta 50 opciones.', 'err'); this.f.opciones.push({ id: null, nombre: '' }); },
    quitar(i) { this.f.opciones.splice(i, 1); if (!this.f.opciones.length) this.f.opciones.push({ id: null, nombre: '' }); },
    async guardar() {
      if (!this.f.nombre.trim()) return toast('Escribe un nombre de grupo de hasta 120 caracteres, por ejemplo Tallas o Colores.', 'err');
      if (!this.f.opciones.some(o => o.nombre.trim())) return toast('Agrega al menos una opción al grupo.', 'err');
      this.guardando = true;
      try { await api(this.f.id ? '/api/fisitaap/opcionales/' + this.f.id : '/api/fisitaap/opcionales', { method: this.f.id ? 'PUT' : 'POST', body: this.f }); toast('Grupo de opcionales guardado.', 'ok'); this.f = this.vacio(); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async desactivar(g) { try { await api('/api/fisitaap/modificadores/' + g.id, { method: 'DELETE' }); toast('Grupo de opcionales guardado.', 'ok'); if (this.f.id === g.id) this.f = this.vacio(); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="split"><section class="card admin-card"><h2>{{editando ? 'Editar grupo' : 'Crear grupo de opcionales'}}</h2><p>Por ejemplo: Tallas con S, M y L; Colores con Rojo y Azul. Las opciones no tienen costo adicional.</p><form @submit.prevent="guardar">
      <div class="form-group"><label>Nombre del grupo</label><input class="input" v-model="f.nombre" maxlength="120" required></div>
      <h3>Opciones del grupo</h3><div data-optional180-lines><div class="qa180-filter" v-for="(o, i) in f.opciones" :key="i"><div class="form-group"><label>Opción {{i + 1}}</label><input class="input" v-model="o.nombre" maxlength="120" placeholder="Por ejemplo S, M o L"></div><button class="btn btn-light" type="button" @click="quitar(i)">Quitar</button></div></div>
      <button class="btn btn-light" type="button" @click="agregar">Agregar opción</button>
      <label><input type="checkbox" v-model="f.obligatorio"> Selección obligatoria</label><label><input type="checkbox" v-model="f.multiple"> Permitir varias opciones a la vez</label>
      <h3>Asignar a productos</h3><label>Seleccionar productos<select class="input" multiple size="6" v-model="f.productos"><option v-for="p in productos" :key="p.id" :value="p.id">{{p.nombre}} · {{p.codigo}}</option></select></label>
      <h3>Asignar a categorías completas</h3><div class="qa180-modifier-list"><label v-for="c in categorias" :key="c"><input type="checkbox" :value="c" v-model="f.categorias"> {{c}}</label><p v-if="!categorias.length">Sus ítems todavía no tienen categorías.</p></div>
      <p>Al mover un producto, conserva sus asignaciones manuales y hereda las de la categoría nueva.</p>
      <button class="btn" :disabled="guardando">Guardar grupo</button> <button v-if="editando" class="btn btn-light" type="button" @click="f = vacio()">Cancelar</button></form></section>
    <section class="card admin-card"><h2>Grupos creados</h2><AvisoRecuperarMods clase="card" @recuperado="cargar"/>
      <article class="r2-row" v-for="g in grupos" :key="g.id"><strong>{{g.nombre}}</strong><span>{{g.opciones.map(o => o.nombre).join(', ')}}</span><small>{{g.obligatorio ? 'Obligatorio' : 'Opcional'}}{{g.multiple ? ' · varias' : ''}}</small><a class="btn btn-light" href="#/opcionales" @click.prevent="editar(g)">Editar</a><form @submit.prevent="desactivar(g)"><button class="btn btn-danger">Desactivar</button></form></article>
      <p v-if="!grupos.length">Todavía no hay grupos de opcionales.</p>
    </section></div>`,
};
