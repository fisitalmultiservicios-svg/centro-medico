// FISITAAP › Combos (r2_combos del zip): un combo con precio, impuesto, descripción y los productos que incluye con su cantidad;
// el costo estimado se calcula con el costo de cada componente. En el ERP queda como ítem «Combo» con su ficha técnica.
import { api, toast } from '/js/api.js';
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  data() { return { combos: [], productos: [], f: this.vacio(), guardando: false }; },
  computed: {
    costo() { return this.f.lineas.reduce((s, l) => { const p = this.productos.find(x => x.id === +l.producto_id); return s + (p ? (+p.costo || 0) * (+l.cantidad || 0) : 0); }, 0); },
    conCosto() { return this.productos.some(p => 'costo' in p); },   // 3.87: la caja no recibe costos
  },
  methods: {
    dinero,
    vacio() { return { id: null, nombre: '', precio: 0, tarifa: 13, descripcion: '', lineas: [{ producto_id: 0, cantidad: 1 }] }; },
    async cargar() { try { const r = await api('/api/fisitaap/combos'); this.combos = r.combos; this.productos = r.productos; } catch (e) { toast(e.message, 'err'); } },
    editar(c) { this.f = { id: c.id, nombre: c.nombre, precio: c.precio, tarifa: c.tarifa, descripcion: c.descripcion, lineas: c.componentes.length ? c.componentes.map(x => ({ ...x })) : [{ producto_id: 0, cantidad: 1 }] }; window.scrollTo(0, 0); },
    agregar() { this.f.lineas.push({ producto_id: 0, cantidad: 1 }); },
    quitar(i) { this.f.lineas.splice(i, 1); if (!this.f.lineas.length) this.agregar(); },
    async guardar() {
      if (!this.f.nombre.trim()) return toast('Escribe un nombre.', 'err');
      const componentes = this.f.lineas.filter(l => +l.producto_id && +l.cantidad > 0).map(l => ({ producto_id: +l.producto_id, cantidad: +l.cantidad }));
      if (!componentes.length) return toast('Selecciona los productos del combo.', 'err');
      this.guardando = true;
      try { await api('/api/fisitaap/combos', { method: 'POST', body: { id: this.f.id, nombre: this.f.nombre, precio: +this.f.precio || 0, tarifa: +this.f.tarifa || 0, descripcion: this.f.descripcion, componentes } }); toast('Combo guardado. Su inventario se descuenta de los componentes.', 'ok'); this.f = this.vacio(); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async ocultar(c) { try { await api('/api/fisitaap/combos/' + c.id, { method: 'DELETE' }); toast('Combo oculto.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="split"><section class="card admin-card"><form @submit.prevent="guardar">
      <div class="form-group"><label>Nombre</label><input class="input" v-model="f.nombre" maxlength="190" required></div>
      <div class="form-group"><label>Precio del combo</label><input class="input" type="number" step=".01" min="0" v-model="f.precio" required></div>
      <div class="form-group"><label>Impuesto %</label><input class="input" type="number" step=".01" min="0" max="100" v-model="f.tarifa" required></div>
      <div class="form-group"><label>Descripción</label><input class="input" v-model="f.descripcion" maxlength="500"></div>
      <h3>Productos incluidos</h3><p>Indica la cantidad de cada producto. Cero significa que no está incluido.</p>
      <div data-combo180-lines><div class="qa180-filter" v-for="(l, i) in f.lineas" :key="i" data-combo180-line><label>Producto<select class="input" v-model="l.producto_id"><option :value="0">Selecciona un producto</option><option v-for="p in productos" :key="p.id" :value="p.id">{{p.nombre}}</option></select></label><div class="form-group"><label>Cantidad</label><input class="input" type="number" step=".001" min="0" v-model="l.cantidad" required></div><button class="btn btn-light" type="button" @click="quitar(i)">Quitar</button></div></div>
      <button class="btn btn-light" type="button" @click="agregar">Agregar producto al combo</button><p><span v-if="conCosto">Costo estimado: <strong>{{dinero(costo)}}</strong>. </span>Los componentes repetidos se suman al guardar.</p>
      <button class="btn" :disabled="guardando">Guardar combo</button> <button v-if="f.id" class="btn btn-light" type="button" @click="f = vacio()">Cancelar</button></form></section>
    <section class="card admin-card">
      <article class="r2-row" v-for="c in combos" :key="c.id"><strong>{{c.nombre}}</strong><span>{{dinero(c.precio)}}</span><a class="btn btn-light" href="#/combos" @click.prevent="editar(c)">Editar</a><form @submit.prevent="ocultar(c)"><button class="btn btn-danger">Ocultar</button></form></article>
      <p v-if="!combos.length">Todavía no hay combos.</p>
    </section></div>`,
};
