// FISITAAP › Administración › Zonas de envío (tenant_simple_module_v3 «delivery» del zip): formulario de la zona y tabla de
// registros con editar, activar o desactivar y eliminar. Las zonas del ERP son círculos en el mapa: el formulario incluye el
// mapa para ubicarlas (clic para fijar el centro) y el radio en kilómetros.
import { api, toast } from '/js/api.js';
import { crearMapa, centroEmpresa, miPosicion } from '/js/mapa.js';
import { sesion } from '../sesion.js';
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  data() { return { sesion, zonas: [], ubic: { lat: null, lng: null }, f: this.vacio(), mapa: null, capas: [], pin: null, guardando: false }; },
  methods: {
    dinero,
    vacio() { return { id: null, nombre: '', precio: 0, radio_km: 2, tiempo: '', lat: null, lng: null, activa: true, pago_motorizado: null, orden: 0 }; },
    async cargar() { try { const r = await api('/api/entregas/zonas'); this.zonas = r.zonas; this.ubic = r.ubicacion || { lat: null, lng: null }; await this.$nextTick(); this.dibujar(); } catch (e) { toast(e.message, 'err'); } },
    async dibujar() {
      if (!this.$refs.mapa) return;
      try {
        const prov = centroEmpresa(sesion.empresa);
        const centro = this.ubic.lat ? this.ubic : (this.zonas[0] ? { lat: +this.zonas[0].lat, lng: +this.zonas[0].lng } : prov);
        if (!this.mapa) { this.mapa = await crearMapa(this.$refs.mapa, centro, this.ubic.lat ? 14 : (this.zonas[0] ? 12 : prov.zoom)); this.mapa.on('click', ev => this.clic(ev.latlng)); }
        const L = window.L; for (const c of this.capas) c.remove(); this.capas = []; if (this.pin) { this.pin.remove(); this.pin = null; }
        if (this.ubic.lat) this.pin = L.marker([this.ubic.lat, this.ubic.lng], { title: 'Negocio' }).addTo(this.mapa).bindTooltip('Su negocio');
        for (const z of this.zonas) this.capas.push(L.circle([+z.lat, +z.lng], { radius: +z.radio_km * 1000, color: this.f.id === z.id ? '#1d7550' : '#244f6d', weight: this.f.id === z.id ? 4 : 2, fillOpacity: z.activa ? .12 : .03 }).addTo(this.mapa).bindTooltip(z.nombre + ' · ' + dinero(z.precio)));
        if (this.f.lat && !this.f.id) this.capas.push(L.circle([+this.f.lat, +this.f.lng], { radius: +this.f.radio_km * 1000, color: '#1d7550', weight: 3, fillOpacity: .15 }).addTo(this.mapa));
      } catch { /* sin mapa (sin internet) */ }
    },
    clic(ll) { if (!this.ubic.lat) { this.ubic = { lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6) }; this.guardarUbicacion(); return; } this.f.lat = +ll.lat.toFixed(6); this.f.lng = +ll.lng.toFixed(6); this.dibujar(); },
    async guardarUbicacion() { try { await api('/api/entregas/ubicacion', { method: 'PUT', body: this.ubic }); toast('Ubicación del negocio guardada.', 'ok'); this.dibujar(); } catch (e) { toast(e.message, 'err'); } },
    async miPos() { const p = await miPosicion(); if (!p) return toast('El navegador no dio la ubicación; haga clic en el mapa sobre el negocio.', 'err'); this.ubic = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6) }; if (this.mapa) this.mapa.setView([p.lat, p.lng], 15); this.guardarUbicacion(); },
    editar(z) { this.f = { ...z }; this.dibujar(); window.scrollTo(0, 0); },
    async guardar() {
      const z = this.f; if (!(z.nombre || '').trim() || !(+z.precio >= 0)) return toast('Completa los campos obligatorios.', 'err');
      if (!(+z.radio_km > 0)) return toast('Indique el radio en kilómetros.', 'err');
      const lat = z.lat || this.ubic.lat, lng = z.lng || this.ubic.lng; if (!lat) return toast('Primero marque dónde está el negocio con un clic en el mapa.', 'err');
      this.guardando = true;
      try {
        const body = { nombre: z.nombre.trim(), lat: +lat, lng: +lng, radio_km: +z.radio_km, precio: +z.precio || 0, pago_motorizado: z.pago_motorizado === '' || z.pago_motorizado === null ? null : +z.pago_motorizado, tiempo: z.tiempo || '', activa: z.activa !== false, orden: +z.orden || 0 };
        await (z.id ? api('/api/entregas/zonas/' + z.id, { method: 'PUT', body }) : api('/api/entregas/zonas', { method: 'POST', body })); toast('Registro guardado.', 'ok'); this.f = this.vacio(); await this.cargar();
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async alternar(z) { try { await api('/api/entregas/zonas/' + z.id, { method: 'PUT', body: { nombre: z.nombre, lat: +z.lat, lng: +z.lng, radio_km: +z.radio_km, precio: +z.precio || 0, pago_motorizado: z.pago_motorizado, tiempo: z.tiempo || '', activa: !z.activa, orden: +z.orden || 0 } }); toast('Estado actualizado.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async eliminar(z) { if (!confirm('¿Eliminar este registro?')) return; try { await api('/api/entregas/zonas/' + z.id, { method: 'DELETE' }); toast('Registro eliminado.', 'ok'); if (this.f.id === z.id) this.f = this.vacio(); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  mounted() { this.cargar(); },
  beforeUnmount() { if (this.mapa) this.mapa.remove(); },
  template: `
  <div class="split"><section class="card admin-card"><h2>{{f.id ? 'Editar' : 'Agregar'}}</h2><form @submit.prevent="guardar">
      <div class="form-group"><label>Zona</label><input class="input" v-model="f.nombre" maxlength="60" required></div>
      <div class="form-group"><label>Precio</label><input class="input" type="number" step="0.01" min="0" v-model="f.precio" required></div>
      <div class="form-group"><label>Radio (km)</label><input class="input" type="number" step="0.1" min="0.2" max="200" v-model="f.radio_km" required @input="dibujar"></div>
      <div class="form-group"><label>Tiempo estimado</label><input class="input" v-model="f.tiempo" maxlength="40" placeholder="30 a 45 min"></div>
      <div class="form-group"><label>Pago al motorizado (vacío = su tarifa)</label><input class="input" type="number" step="100" min="0" v-model="f.pago_motorizado"></div>
      <div ref="mapa" style="height:320px;border-radius:9px;border:1px solid var(--line)"></div><p>{{!ubic.lat ? 'Clic en el mapa: fija la ubicación del negocio.' : 'Clic en el mapa: centro de la zona. Mapa de OpenStreetMap, sin costo.'}} <a href="#/delivery" @click.prevent="miPos">Usar mi posición</a></p>
      <button class="btn btn-block" :disabled="guardando">Guardar</button> <button v-if="f.id" class="btn btn-light btn-block" type="button" @click="f = vacio(); dibujar()">Cancelar</button></form></section>
    <section class="card admin-card"><h2>Registros</h2><div class="table-wrap"><table class="table"><tr><th>Zona</th><th>Precio</th><th>Radio (km)</th><th>Tiempo</th><th>Acciones</th></tr>
      <tr v-for="z in zonas" :key="z.id"><td>{{z.nombre}}</td><td>{{dinero(z.precio)}}</td><td>{{z.radio_km}}</td><td>{{z.tiempo || '—'}}</td><td class="fis-tabla-acciones"><a class="btn btn-light" href="#/delivery" @click.prevent="editar(z)">Editar</a><form class="inline-form" @submit.prevent><button class="btn btn-light" type="button" @click="alternar(z)">{{z.activa ? 'Desactivar' : 'Activar'}}</button><button class="btn btn-danger" type="button" @click="eliminar(z)">Eliminar</button></form></td></tr>
      <tr v-if="!zonas.length"><td colspan="5">Todavía no hay zonas.</td></tr></table></div></section></div>`,
};
