// FISITAAP › Express pendientes (tenant_express_v12 + express_web_pending_v12 del zip): pedidos listos para publicar, invitar
// motorizado, motorizados y solicitudes, y los express publicados con sus acciones. Son las entregas y motorizados del ERP.
// 3.87: la caja publica, asigna y cancela express; invitar, pausar y bloquear motorizados es de quien administra ('catalogos').
import { api, toast } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { sesion, pendientes: [], motos: [], abiertas: [], cargando: false, inv: { nombre: '', telefono: '', clave: '' }, pagos: {} }; },
  computed: {
    publicados() { return this.abiertas.filter(x => x.estado !== 'pendiente'); },
    activos() { return this.motos.filter(m => m.activo); },
  },
  methods: {
    dinero, fechaCorta,
    estadoMoto(m) { return !m.activo ? 'Pausado' : m.ultimo_acceso ? 'Activo' : 'Esperando aceptación'; },
    async cargar() {
      this.cargando = true;
      try { const [r, a, m] = await Promise.all([api('/api/fisitaap/express/pendientes'), api('/api/entregas?abiertas=1'), api('/api/entregas/motorizados')]); this.pendientes = r.entregas.filter(x => x.estado === 'pendiente'); this.abiertas = a; this.motos = m; for (const x of this.pendientes) if (!(x.id in this.pagos)) this.pagos[x.id] = x.pago_motorizado || 0; }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
    async publicar(x) { try { const r = await api('/api/entregas/' + x.id + '/asignar', { method: 'PUT', body: { motorizado_id: null } }); toast('Express publicado. PIN de entrega: ' + (r.pin || 'en el detalle del pedido') + '. Compártelo con el cliente para confirmar la entrega.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async asignar(x, mid) { try { await api('/api/entregas/' + x.id + '/asignar', { method: 'PUT', body: { motorizado_id: mid ? +mid : null } }); toast(mid ? 'Express asignado.' : 'Express liberado para cualquier motorizado.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async cancelarJob(x) { const motivo = (prompt('Motivo de la cancelación del express', 'Reprogramado por el negocio') || '').trim(); if (!motivo) return; try { await api('/api/entregas/' + x.id + '/cancelar', { method: 'PUT', body: { motivo } }); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async invitar() {
      const i = this.inv; if (!i.nombre.trim() || !i.telefono.trim()) return toast('Nombre y teléfono son obligatorios.', 'err'); if (!/^\d{4,8}$/.test(i.clave)) return toast('Asigne una clave de 4 a 8 dígitos para su panel.', 'err');
      try { await api('/api/entregas/motorizados', { method: 'POST', body: { nombre: i.nombre.trim(), telefono: i.telefono.trim(), vehiculo: 'moto', placa: '', activo: true, pago_entrega: 0, notas: '', clave: i.clave } }); toast('Invitación enviada a ' + i.nombre.trim() + '. Entra a su panel con su teléfono y la clave.', 'ok'); this.inv = { nombre: '', telefono: '', clave: '' }; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async estado(m, activo) { try { await api('/api/entregas/motorizados/' + m.id, { method: 'PUT', body: { nombre: m.nombre, telefono: m.telefono, vehiculo: m.vehiculo, placa: m.placa || '', activo, pago_entrega: +m.pago_entrega || 0, notas: m.notas || '', clave: null } }); toast('Afiliación actualizada.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async bloquear(m) { if (!confirm('¿Bloquear a ' + m.nombre + '? Se quita de los motorizados del negocio.')) return; try { await api('/api/entregas/motorizados/' + m.id, { method: 'DELETE' }); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    enlacePanel() { const n = sesion.negocio; return location.origin + '/motorizado.html' + (n && n.slug ? '#n=' + n.slug : ''); },
  },
  async created() { await this.cargar(); this._t = setInterval(() => this.cargar(), 20000); },
  beforeUnmount() { clearInterval(this._t); },
  template: `
  <div>
    <div class="split"><section class="card admin-card"><h2>Pedidos listos para publicar</h2>
        <form class="express-order" v-for="x in pendientes" :key="x.id" @submit.prevent="publicar(x)"><div><strong>#{{x.pedido_numero}} · {{x.cliente}}</strong><small>{{x.direccion}}{{x.zona ? ' · ' + x.zona : ''}}</small></div><input class="input compact" type="number" min="0" step="100" :value="x.pago_motorizado" aria-label="Pago" readonly><button class="btn">Publicar express</button></form>
        <p class="muted" v-if="!pendientes.length">No hay pedidos pendientes de publicación.</p></section>
      <section class="card admin-card" v-if="sesion.puede('catalogos')"><span class="tag">RED MULTINEGOCIO</span><h2>Invitar motorizado</h2><p class="muted">El motorizado entra a su panel con su teléfono y la clave que le asigne.</p><form @submit.prevent="invitar"><div class="form-group"><label>Nombre</label><input class="input" v-model="inv.nombre" maxlength="60" required></div><div class="form-group"><label>Teléfono (8 dígitos)</label><input class="input" v-model="inv.telefono" maxlength="12" inputmode="numeric" required></div><div class="form-group"><label>Clave (4 a 8 dígitos)</label><input class="input" type="password" v-model="inv.clave" maxlength="8" inputmode="numeric" autocomplete="new-password" required></div><button class="btn btn-block">Enviar invitación</button></form><small class="muted">Panel para motorizados: {{enlacePanel()}}</small></section></div>
    <section class="card admin-card express-affiliations"><h2>Motorizados y solicitudes</h2>
      <article class="affiliation-row" v-for="m in motos" :key="m.id"><div><span class="driver-dot" :class="{online: m.lat && m.activo}"></span><strong>{{m.nombre}}</strong><small>{{m.telefono}} · {{m.vehiculo_nombre}}{{m.placa ? ' · ' + m.placa : ''}} · {{estadoMoto(m)}}</small></div><form class="driver-actions" @submit.prevent v-if="sesion.puede('catalogos')"><span class="status" v-if="!m.ultimo_acceso && m.activo">Esperando aceptación</span><button v-else-if="!m.activo" class="btn btn-accent" type="button" @click="estado(m, true)">Aprobar/activar</button><button v-else class="btn btn-light" type="button" @click="estado(m, false)">Pausar</button><button class="btn btn-danger" type="button" @click="bloquear(m)">Bloquear</button></form></article>
      <div class="empty" v-if="!motos.length">Todavía no hay solicitudes ni motorizados afiliados.</div></section>
    <section class="card admin-card" style="margin-top:20px"><h2>Express publicados</h2><div class="table-wrap"><table class="table"><tr><th>Pedido</th><th>Destino</th><th>Pago</th><th>Motorizado</th><th>Estado</th><th></th></tr>
      <tr v-for="x in publicados" :key="x.id"><td>#{{x.pedido_numero}}</td><td>{{x.direccion}}{{x.zona_nombre ? ' · ' + x.zona_nombre : ''}}</td><td>{{dinero(x.pago_motorizado)}}</td><td>{{x.motorizado || 'Disponible'}}</td><td><span class="status">{{x.estado_nombre}}</span></td><td><form @submit.prevent v-if="['liberada','asignada'].includes(x.estado)"><select class="input compact" :value="x.motorizado_id || ''" @change="asignar(x, $event.target.value)"><option value="">Cualquier motorizado</option><option v-for="m in activos" :key="m.id" :value="m.id">{{m.nombre}}</option></select> <button class="btn btn-danger" type="button" @click="cancelarJob(x)">Cancelar</button></form><a v-if="x.estado === 'incidencia'" class="btn btn-accent" :href="'#/pedido/' + x.pedido_id">Revisar y resolver incidencia</a></td></tr>
      <tr v-if="!publicados.length"><td colspan="6">Todavía no se publicaron express.</td></tr></table></div></section>
  </div>`,
};
