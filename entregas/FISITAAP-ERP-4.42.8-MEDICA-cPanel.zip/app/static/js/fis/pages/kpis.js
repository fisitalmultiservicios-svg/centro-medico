// FISITAAP › KPIs (qa180_kpis del zip): período y sucursal, cinco indicadores, ventas registradas por día, pedidos web por día
// (sus importes aparte para no contarlos dos veces) y los productos más vendidos.
import { api, toast, hoy, sumarDias } from '/js/api.js';
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  data() { return { desde: sumarDias(hoy(), -29), hasta: hoy(), sucursal: 0, r: null, cargando: false }; },
  computed: {
    stats() {
      if (!this.r) return [];
      return [['Ventas registradas', dinero(this.r.total)], ['Operaciones de venta', String(this.r.n)], ['Ticket promedio', dinero(this.r.ticket)], ['Pedidos web', String(this.r.pedidos_n)], ['Importe solicitado en web', dinero(this.r.pedidos_total)]];
    },
  },
  methods: {
    dinero,
    alto(v, filas) { const mx = Math.max(1, ...filas.map(x => +x.total || 0)); return Math.max(1, Math.round((+v || 0) / mx * 180)) + 'px'; },
    async cargar() {
      this.cargando = true;
      try { this.r = await api('/api/fisitaap/kpis?desde=' + this.desde + '&hasta=' + this.hasta + (this.sucursal ? '&sucursal_id=' + this.sucursal : '')); }
      catch (e) { toast(e.message, 'err'); }
      this.cargando = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="card admin-card"><form @submit.prevent="cargar"><div class="split"><div class="form-group"><label>Desde</label><input class="input" type="date" v-model="desde" required></div><div class="form-group"><label>Hasta</label><input class="input" type="date" v-model="hasta" required></div></div><label>Sucursal<select class="input" v-model="sucursal"><option :value="0">Todas</option><option v-for="b in (r ? r.sucursales : [])" :key="b.id" :value="b.id">{{b.nombre}}</option></select></label><button class="btn" :disabled="cargando">Consultar</button></form><p>Ventas muestra documentos cobrados o registrados a crédito. Pedidos web muestra solicitudes; sus importes se presentan aparte para evitar contarlos dos veces.</p></section>
    <template v-if="r">
      <div class="grid grid-3"><article class="card stat" v-for="[l, v] in stats" :key="l"><small>{{l}}</small><h2>{{v}}</h2></article></div>
      <section class="card admin-card" v-for="[t, filas] in [['Ventas registradas por día', r.ventas], ['Pedidos web por día', r.pedidos]]" :key="t"><h2>{{t}}</h2><div class="r2-chart" role="img" :aria-label="t">
        <div class="r2-bar" v-for="f in filas" :key="f.dia"><span>{{dinero(f.total)}}</span><i :style="{height: alto(f.total, filas)}"></i><small>{{f.dia}}</small></div>
        <p v-if="!filas.length">No hay movimientos en este periodo.</p></div></section>
      <section class="card admin-card"><h2>Productos más vendidos</h2><div class="table-wrap"><table class="table"><tr><th>Producto</th><th>Cantidad</th><th>Neto</th></tr><tr v-for="p in r.productos" :key="p.nombre"><td>{{p.nombre}}</td><td>{{p.cantidad}}</td><td>{{dinero(p.monto)}}</td></tr><tr v-if="!r.productos.length"><td colspan="3">Sin ventas en el período.</td></tr></table></div></section>
    </template>
  </div>`,
};
