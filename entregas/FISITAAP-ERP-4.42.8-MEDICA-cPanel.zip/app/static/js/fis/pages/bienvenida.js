// FISITAAP › Bienvenida (qa180_welcome del zip): la imagen o el anuncio de bienvenida y, para el dueño en sus primeros días, la
// invitación al configurador (academy17_shell).
import { api } from '/js/api.js';
import { sesion } from '../sesion.js';

export default {
  props: ['params'],
  data() { return { sesion, conf: null, cerrada: false }; },
  computed: { invitar() { return !this.cerrada && this.conf && this.conf.invitar && sesion.esDueno; } },
  async created() { if (sesion.esDueno) { try { this.conf = await api('/api/fisitaap/configurador'); } catch { this.conf = null; } } },
  template: `
  <div>
    <aside class="a17-invite" v-if="invitar" data-setup-invite><button type="button" class="icon-button" aria-label="Cerrar invitación" @click="cerrada = true">×</button><small>BIENVENIDO A TU NEGOCIO</small><h2>Vamos paso a paso</h2><p>Te acompañamos a dejar tu tienda lista. Puedes pausar cuando necesites.</p><a class="btn" href="#/configurador">CONFIGUREMOS FISITAAP JUNTOS</a></aside>
    <section class="qa180-welcome" aria-label="Bienvenida a FISITAAP">
      <div class="qa180-welcome-ad"><img src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP"><h1>Tu negocio, al día.</h1><p>Vende, atiende y organiza desde un solo lugar.</p><span>Web · Windows · Android</span></div>
    </section>
  </div>`,
};
