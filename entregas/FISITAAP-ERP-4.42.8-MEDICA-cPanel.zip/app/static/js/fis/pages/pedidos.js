// FISITAAP › Pedidos (op180_orders_list del zip): filtros por origen, estado y período; tabla con pedido y fecha, cliente y
// origen, estado actual, total y pago, y las acciones de cada fila (aceptar, abrir monitor, marcar entregado, asignar a Express,
// ver cuenta, detalle y bitácora, cancelar con justificación). Los pedidos web son los de FISITAAP; las cuentas de caja salen de
// la caja del ERP. Se actualiza sola cada 20 segundos y suena cuando entra un pedido nuevo.
// 3.87: «Pausar pedidos en línea» (y reanudar) desde aquí: es operación de la caja; lo demás de la página se configura en Mi página.
// También «Avisar en este dispositivo» (el mismo interruptor de Mi página › Generales), para que la caja lo encienda sin entrar ahí.
// 4.9 (Revendedoras): la forma de pago la manda el servidor (`forma_pago`, «A crédito» en los fiados); `#/pedidos?contacto_id=N` muestra
// todos los pedidos de esa revendedora (todas las fechas) y cada pedido de una revendedora enlaza a su estado de cuenta en el ERP.
import { api, toast, hoy, sumarDias, abrirArchivo } from '/js/api.js';
import { avisosActivos, activarAvisos, desactivarAvisos } from '/js/avisos.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta, formaPago, puedeEstadoCuenta, urlEstadoCuenta } from '../ui.js';

// 4.9: revendedora pedida en la ruta (?contacto_id=), solo dígitos
function contactoDe(params) { return String((params && params.query && params.query.contacto_id) || '').replace(/\D/g, ''); }

// 4.32: aceptado en la página web y lo atiende el programa elegido (su comanda sale allá)
export const TEXTO_ACEPTADO_ALLA = nombre => 'Pedido aceptado: lo atiende «' + nombre + '»; su comanda sale allá.';

const ESTADOS = [['nuevo', 'Nuevo'], ['confirmado', 'Confirmado'], ['en_preparacion', 'En preparación'], ['listo', 'Listo'], ['entregado', 'Entregado'], ['cancelado', 'Cancelado'], ['pendiente_pago', 'Esperando pago']];

export default {
  props: ['params'],
  data() { const contacto = contactoDe(this.params); return { sesion, origen: '', estado: contacto ? 'todos' : '', dias: 2, contacto, pedidos: [], cuentas: [], motos: [], cargando: false, ultimo: null, cancelar: null, despacho: null, ESTADOS, pausando: false, avisos: avisosActivos(), impresion: null, aceptando: {}, atendiendo: {}, sinImprimir: 0 }; },
  computed: {
    menu() { return sesion.menu; },
    // 4.29 (W-3): el botón del pedido nuevo imprime la comanda solo con menú, impresoras de comanda y la caja de los pedidos imprimiendo
    // comandas; sin esos datos (no se pudieron leer) dice «Aceptar pedido» y no imprime
    conComanda() { const i = this.impresion; return !!(i && this._com && this._com.imprimeAlAceptar(this.menu, i.cfg, i.impresoras, sesion.negocio ? sesion.negocio.terminal_id : null)); },
    entregas() { return sesion.fisica && sesion.tieneModulo('entregas'); },
    // 4.32: el programa de escritorio con los pedidos en línea (la bandera la manda la empresa); sin ella todo se porta como antes
    enProg() { const i = sesion.empresaInfo; return !!(i && i.es_local && i.pedidos_programa); },
    enWeb() { const i = sesion.empresaInfo; return !(i && i.es_local); },
    // 4.32: la tienda tiene elegido un programa para atender los pedidos (solo la página web lo sabe)
    conProgramaElegido() { const n = sesion.negocio; return !!(this.enWeb && n && n.atiende_terminal); },
    puedeRescatar() { return this.enWeb && sesion.puede('configurar'); },
    pausada() { const n = sesion.negocio; return !!(n && n.abierto_manual === false); },
    puedeCuenta() { return puedeEstadoCuenta(sesion); },   // 4.9: el estado de cuenta (ERP) no es del modo cajero
    // 4.9: con el filtro por revendedora, su nombre (del pedido más reciente) y lo que suman sus pedidos que no se cancelaron
    nombreRev() { const p = this.pedidos.find(x => String(x.contacto_id || '') === this.contacto); return p ? p.nombre : ''; },
    resumenRev() { const l = this.pedidos.filter(p => p.estado !== 'cancelado'); return { n: l.length, total: l.reduce((a, p) => a + (+p.total || 0), 0), credito: l.filter(p => p.a_credito).reduce((a, p) => a + (+p.total || 0), 0) }; },
    filas() {
      const f = [];
      if (this.origen !== 'caja') for (const p of this.pedidos) f.push({ origen: 'web', id: p.id, numero: p.numero, cliente: p.nombre, total: p.total, estado: p.estado, estado_nombre: p.estado_nombre, tipo: p.tipo, creado: p.creado, pago: this.pago(p), p });
      if (this.origen !== 'web') for (const c of this.cuentas) if (!c.pedido_id && ((c.lineas || []).length || (c.cobros || []).length) && (!this.estado || this.estado === 'todos' || this.estadoCuenta(c) === this.estado) && (!this.contacto || String(c.cliente_id || '') === this.contacto)) f.push({ origen: 'caja', id: c.id, numero: c.nombre || ('Cuenta ' + c.id), cliente: c.cliente_nombre || c.nombre || 'Consumidor final', total: c.total, estado: this.estadoCuenta(c), estado_nombre: this.nombreCuenta(c), tipo: c.pedido || (c.mesa_id ? 'mesa' : 'llevar'), creado: c.creado, pago: (c.cobros || []).length ? 'Con cobros' : 'Cobro pendiente', c });
      return f.sort((a, b) => String(b.creado || '').localeCompare(String(a.creado || '')));
    },
  },
  methods: {
    dinero, fechaCorta, urlEstadoCuenta,
    estadoCuenta(c) { return c.estado === 'listo' ? 'listo' : c.estado === 'entregado' ? 'entregado' : 'en_preparacion'; },
    nombreCuenta(c) { return { listo: 'Listo', entregado: 'Entregado', en_preparacion: 'En preparación' }[this.estadoCuenta(c)]; },
    pago(p) { return formaPago(p); },   // 4.9: `forma_pago` del servidor (con el cálculo de antes si no viene): los pedidos a crédito ya no dicen «Paga al recibir»
    envio(p) { return ['domicilio', 'coordinado'].includes(p.tipo); },
    async cargar(silencioso) {
      if (!silencioso) { this.cargando = true; this.ultimo = null; }   // 4.9: cambiar el filtro no cuenta como pedido nuevo (no suena)
      if (silencioso && this.menu && !this.impresion && !this.enProg) this.cargarImpresion();   /* 4.29: si la primera lectura de la impresión falló, se reintenta en cada recarga de 20 s */
      const turno = this._turno = (this._turno || 0) + 1;
      try {
        // 4.9: con revendedora, todas las fechas y solo sus pedidos (el servidor filtra por contacto_id; aquí se filtra otra vez por si acaso)
        const rango = this.contacto ? 'desde=2000-01-01&hasta=2099-12-31&contacto_id=' + encodeURIComponent(this.contacto) : 'desde=' + sumarDias(hoy(), -this.dias + 1) + '&hasta=' + hoy();
        const est = this.estado === 'todos' ? '' : this.estado;
        const [l0, r] = await Promise.all([api('/api/pedidos?' + rango + (est ? '&estado=' + est : '')), this.origen === 'web' ? Promise.resolve(null) : api('/api/registros/pos_espera').catch(() => null)]);
        if (turno !== this._turno) return;   // 4.9: una carga anterior (con otro filtro) que llegó tarde no pisa la nueva
        const l = this.contacto ? l0.filter(p => String(p.contacto_id || '') === this.contacto) : l0;
        const maxId = Math.max(0, ...l.filter(p => p.estado === 'nuevo').map(p => p.id));
        if (this.ultimo !== null && maxId > this.ultimo) this.beep();
        this.ultimo = maxId;
        this.pedidos = this.estado ? l : l.filter(p => !['entregado', 'cancelado'].includes(p.estado));
        this.cuentas = r && Array.isArray(r.datos) ? r.datos.filter(c => c && this.cuentaVisible(c)) : [];
        if (this.enProg) { let x = null; try { x = await api('/api/pedidos/resumen'); } catch { x = null; } if (turno === this._turno) this.sinImprimir = x && !(+x.comanda_espera_s > 0) ? (+x.comandas_pendientes || 0) : 0; }   /* validación 4.32: el aviso de comandas_pendientes (aquí no corre la estación de la Caja) */
      } catch (e) { if (!silencioso) toast(e.message, 'err'); }
      this.cargando = false;
    },
    cuentaVisible(c) { if (this.contacto) return true; const desde = sumarDias(hoy(), -this.dias + 1); return !c.creado || String(c.creado).slice(0, 10) >= desde; },
    async estadoWeb(p, estado, motivo) {
      try { const r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado, motivo } }); Object.assign(p, r); if (this.enProg && r && r.mensaje) toast(r.mensaje, 'ok'); else toast('Pedido actualizado.', 'ok'); await this.cargar(true); return true; }
      catch (e) { toast(e.message, 'err'); return false; }
    },
    // 4.29: lo que hace falta para imprimir la comanda al aceptar (módulo compartido con el monitor de cocina, cajas e impresoras). Solo
    // con menú; se lee aparte y sin esperar: si algo falta, la pantalla carga igual y el botón dice «Aceptar pedido».
    async cargarImpresion() {
      if (!this.menu || this.enProg) return;
      try {
        const [mod, cfg, imps] = await Promise.all([import('/js/pages/pos/_comandas.js'), api('/api/registros/pos_config'), api('/api/registros/pos_impresoras')]);
        this._com = mod; this.impresion = { cfg: cfg ? cfg.datos : null, impresoras: imps && Array.isArray(imps.datos) ? imps.datos : [] };
      } catch { this.impresion = null; }
    },
    // 4.29 (W-1 a W-5): aceptar el pedido nuevo. Primero se acepta (el servidor rechaza al segundo que acepta a la vez); solo quien lo
    // aceptó imprime la comanda, una vez. Si no se pudo imprimir, el pedido queda aceptado y la comanda sin marcar en Cocina.
    async aceptar(p) { return this.aceptarComo(p, null); },
    // 4.32: `extra` = { aqui: true } («Aceptar y atenderlo aquí») o { rescate: true } (el administrador atiende aquí lo de otra computadora)
    async aceptarComo(p, extra) {
      if (this.enProg) return this.aceptarEnPrograma(p);
      if (this.aceptando[p.id]) return false;
      this.aceptando = { ...this.aceptando, [p.id]: true };
      const vent = { w: null };
      const rescate = !!(extra && extra.rescate), aqui = !!(extra && extra.aqui);
      try {
        /* 4.29: la primera lectura falló o no terminó: se intenta otra vez, 1,5 s como mucho (pasado eso se acepta sin imprimir y con el aviso) */
        let tarde = false;
        if (this.menu && !this.impresion) { let tope = null; tarde = (await Promise.race([this.cargarImpresion(), new Promise(r => { tope = setTimeout(() => r('tope'), 1500); })])) === 'tope'; clearTimeout(tope); }
        const imprime = this.conComanda && !tarde, mod = this._com;
        // 4.29: la ventana de las impresoras «del navegador» se abre en el toque (después de esperar al servidor el navegador puede bloquearla)
        if (imprime && mod && mod.usaVentana(this.impresion.impresoras, !!(sesion.empresaInfo && sesion.empresaInfo.es_local))) { try { vent.w = window.open('', '_blank') || null; } catch { vent.w = null; } }
        let r;
        try { r = rescate ? await api('/api/pedidos/' + p.id + '/atender-aqui', { method: 'POST', body: { confirmo: true, reclama: true } }) : aqui ? await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado', reclama: true, aqui: true } }) : await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado', reclama: true } }); }   /* 4.32: «Aceptar y atenderlo aquí» manda aqui; el rescate del administrador es la ruta atender-aqui. 4.31: esta pestaña reclama cada grupo antes de imprimirlo (la estación espera 15 s, no 60) */
        catch (e) { toast(e.message, 'err'); return false; }
        Object.assign(p, r);
        if (r && +r.atiende > 0) { toast(TEXTO_ACEPTADO_ALLA(this.nombreAtiende(r)), 'ok'); await this.cargar(true); return true; }   /* 4.32: lo atiende un programa: su comanda sale allá, aquí no se imprime nada */
        const motivo = 'no se pudo leer a tiempo la configuración de impresión';
        const [texto, tipo] = imprime && mod ? await this.comandaDelPedido(mod, r, vent) : tarde ? [mod ? mod.avisoComandaNoImpresa(motivo) : 'Pedido aceptado. La comanda no se imprimió: ' + motivo + '. Imprímala desde Punto de venta › Cocina.', 'err'] : ['Pedido actualizado.', 'ok'];
        toast(texto, tipo);
        await this.cargar(true); return true;
      } finally { if (vent.w) { try { vent.w.close(); } catch { /* ya cerrada */ } } const a = { ...this.aceptando }; delete a[p.id]; this.aceptando = a; }
    },
    // 4.32 (programa de escritorio con los pedidos en línea): el pedido se acepta en la página web por la conexión de este programa y la cuenta
    // entra a esta caja. Los 409 y 400 se muestran como llegan.
    // Validación 4.32: Ventas en línea es otra página y aquí no corre la estación de la Caja: la comanda sale desde esta pantalla, de la copia
    // que el servidor guardó al aceptar (la misma lectura y los mismos reclamos por plato que la página web de la 4.31: nunca sale dos veces,
    // aunque la Caja esté abierta en otra pestaña). Después del aviso de aceptado se muestra lo que pasó con la comanda.
    async aceptarEnPrograma(p) {
      if (this.aceptando[p.id]) return false;
      this.aceptando = { ...this.aceptando, [p.id]: true };
      try {
        let r;
        try { r = await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); }
        catch (e) { toast(e.message, 'err'); return false; }
        Object.assign(p, r);
        toast(r && r.mensaje ? r.mensaje : 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.', 'ok');
        let res = null;
        try { res = await this.comandaDelPedido(await import('/js/pages/pos/_comandas.js'), { ...p, id: (r && r.id) || p.id }, { w: null }); } catch { res = null; }   /* sin el módulo de impresión: la saca la estación de la Caja */
        if (res && res[0] !== 'Pedido actualizado.') toast(res[0], res[1]);
        await this.cargar(true); return true;
      } finally { const a = { ...this.aceptando }; delete a[p.id]; this.aceptando = a; }
    },
    // 4.32 (rescate del administrador, solo en la página web): la primera llamada no cambia nada y trae la advertencia de cobro doble; solo si
    // la persona acepta se atiende aquí (la misma aceptación de siempre, con su comanda).
    async atenderAqui(p) {
      if (this.aceptando[p.id] || this.atendiendo[p.id]) return false;
      this.atendiendo = { ...this.atendiendo, [p.id]: true };
      try {
        let texto = '';
        try { await api('/api/pedidos/' + p.id + '/atender-aqui', { method: 'POST', body: { confirmo: false } }); }
        catch (e) { if (e && e.detail && e.detail.codigo === 'confirmar' && e.detail.mensaje) texto = e.detail.mensaje; else { toast(e.message, 'err'); return false; } }
        if (!texto || !confirm(texto)) return false;
      } finally { const a = { ...this.atendiendo }; delete a[p.id]; this.atendiendo = a; }
      return this.aceptarComo(p, { rescate: true });
    },
    nombreAtiende(p) { return (p && p.atiende_nombre) || 'otra computadora'; },
    // 4.32 (web): lo atiende un programa y su cuenta todavía no entró a esa caja (el pedido sigue «confirmado»)
    esperandoCaja(p) { return this.enWeb && +p.atiende > 0 && p.estado === 'confirmado' && !p.documento_id; },
    lejos(p) { return this.enWeb && +p.atiende > 0; },
    // 4.32 (programa): lo que solo se hace en la página web: verificar un SINPE y asignar la entrega
    soloWebFila(f) { const p = f.p; return this.enProg && f.origen === 'web' && !['entregado', 'cancelado'].includes(f.estado) && ((p.pago_medio === 'sinpe' && p.pago_estado !== 'aprobado') || (['confirmado', 'en_preparacion', 'listo'].includes(f.estado) && this.envio(p) && this.entregas)); },
    // 4.31 (estación de comandas, D-8 y D-16): la comanda sale de la copia fija que el servidor guardó al aceptar (GET
    // /api/pos/comanda/pendientes?pedido_id=) y cada grupo se reclama antes de imprimirlo; lo de impresoras USB o de red que no sale aquí lo
    // imprime sola la estación de la caja o de la cocina. Lecturas con tope de 5 s. Sin copia (servidor anterior a la 4.31): como en la 4.29
    // (comandaAnterior). Nunca lanza: devuelve el aviso para el usuario.
    async comandaDelPedido(C, r, vent) {
      try {
        const vacio = { datos: null };
        const lect = await C.conTope(Promise.all([C.pendientesComanda(api, { pedido_id: r.id }), api('/api/registros/pos_config').catch(() => null), api('/api/registros/pos_impresoras').catch(() => null),
          api('/api/registros/categorias').catch(() => vacio), api('/api/registros/items_extra').catch(() => vacio), api('/api/productos?venta=1').catch(() => [])]), 5000, null);
        if (!lect) return [C.avisoComandaNoImpresa(C.MOTIVO_LECTURA_TARDE, { saleSola: true }), 'info'];
        const [pen, cfg, imps, cats, ext, prods] = lect, i = this.impresion || {};
        const datos = { cfg: cfg ? cfg.datos : i.cfg, impresoras: imps && Array.isArray(imps.datos) ? imps.datos : (i.impresoras || []), categorias: cats && cats.datos, extras: ext && ext.datos, productos: prods };
        const copia = pen.resultado === 'ok' ? pen.copias.find(c => +c.pedido_id === +r.id) : null;
        if (copia) return await this.comandaDeCopia(C, r, vent, copia, pen.ahora, datos);
        /* 4.31: sin red o el servidor respondió con un error: la copia puede existir (la estación la imprime); como en la 4.29 solo sin la ruta o sin copia */
        if (pen.resultado === 'sin_red' || pen.resultado === 'error') return [C.avisoComandaNoImpresa(C.MOTIVO_SIN_RESERVA, { saleSola: true }), 'info'];
        return await this.comandaAnterior(C, r, vent, datos);
      } catch (e) { return [C.avisoComandaNoImpresa((e && e.message) || 'no se pudieron leer los datos de impresión'), 'err']; }
    },
    // 4.31: imprime de la copia. Grupos de la ventana del navegador: se reclaman y se escriben en la ventana abierta en el toque (una sola
    // llamada a imprimirComandas). Grupos de impresora USB o de red: se reclaman solo si el agente de este equipo responde. Se marca cada
    // grupo que salió (con los platos «sin comanda») y se suelta cada grupo que falló.
    async comandaDeCopia(C, r, vent, copia, ahora, datos) {
      const local = !!(sesion.empresaInfo && sesion.empresaInfo.es_local), pid = +r.id;
      if (copia.estado === 'cerrada') return ['Pedido actualizado.', 'ok'];
      const g = C.gruposDeCopia(copia, { ...datos, ahora, incluirReclamadas: true });
      const equipo = this._equipo || (this._equipo = C.nuevoEquipo()), nombre = 'Pedidos · ' + (sesion.nombreUsuario || '');
      const marca = ps => C.conTope(C.marcarComandaImpresa(api, { pedido_id: pid, equipo, lineas: ps, sin_comanda: g.sin_comanda }), 5000, { resultado: 'sin_red' });
      if (!g.grupos.length) {
        if (g.sin_comanda.length) await marca([]);
        return (copia.lineas || []).some(l => l && l.estado === 'impresa') ? ['Pedido aceptado y comanda impresa.', 'ok'] : ['Pedido actualizado.', 'ok'];
      }
      const dir = g.grupos.filter(x => x.directo), nav = g.grupos.filter(x => !x.directo);
      let agente = false;
      if (dir.length) { try { const A = await import('../../pages/pos/_agente.js'); const est = A.agenteEstado ? await C.conTope(A.agenteEstado(false, local ? undefined : { soloAgente: true }), 3000, null) : null; agente = !!(est && est.ok); } catch { agente = false; } }
      const ganados = [], motDir = new Set(), motNav = new Set();
      let ocupadaPor = '';
      for (const gr of [...nav, ...(agente ? dir : [])]) {
        if (gr.pos.some(n => C.EN_CURSO.has(C.claveEnCurso(pid, n)))) continue;
        const x = await C.conTope(C.reclamarComanda(api, { pedido_id: pid, lineas: gr.pos, grupo: gr.id, grupo_nombre: gr.imp.nombre, equipo, nombre, momento: 'aceptar' }), 5000, { resultado: 'sin_red' });
        if (x.resultado === 'ganada') ganados.push({ ...gr, lineas: Array.isArray(x.lineas) && x.lineas.length ? gr.lineas.filter(l => x.lineas.includes(+l.pos)) : gr.lineas });
        else if (x.resultado === 'ocupada') ocupadaPor = ocupadaPor || x.por || 'otra computadora';
        else if (!['impresa', 'cancelado', 'en_curso'].includes(x.resultado)) (gr.directo ? motDir : motNav).add(C.MOTIVO_SIN_RESERVA);
      }
      if (dir.length && !agente) motDir.add(C.MOTIVO_SIN_AGENTE);
      const ventana = vent ? vent.w : null; if (vent) vent.w = null;   /* imprimirComandas la usa o la cierra */
      if (!ganados.length && ventana) { try { ventana.close(); } catch { /* ya cerrada */ } }
      const claves = ganados.flatMap(gr => gr.lineas.map(l => C.claveEnCurso(pid, l.pos)));
      const sinMarca = [];
      for (const k of claves) C.EN_CURSO.add(k);
      try {
        const res = ganados.length ? await C.imprimirGrupoCopia(copia, ganados, { ventana, respaldoNavegador: false, local }) : { impresas: [], fallas: [] };
        const salio = new Set(res.impresas);
        for (const gr of ganados) {
          const todas = gr.lineas.map(l => +l.pos), ps = todas.filter(n => salio.has(n)), resto = todas.filter(n => !salio.has(n));
          if (ps.length) { const m = await marca(ps); if (C.marcaPorReintentar(m)) sinMarca.push(ps); }
          if (resto.length) {
            const propias = res.fallas.filter(f => f.includes('«' + gr.imp.nombre + '»')), motivo = (propias.length ? propias : res.fallas).join('; ') || 'no se pudo imprimir';
            await C.conTope(C.soltarComanda(api, { pedido_id: pid, equipo, lineas: resto, motivo }), 5000, null);
            (gr.directo ? motDir : motNav).add(motivo);
          }
        }
      } finally { for (const k of claves) C.EN_CURSO.delete(k); }
      /* 4.31: la marca que no llegó se reintenta sola unos 50 s (los platos siguen reservados por esta pestaña); solo si no llega se avisa */
      if (sinMarca.length) this.marcarDespues(C, sinMarca.map(ps => () => marca(ps)));
      const programado = !!copia.hora_entrega && Date.parse(copia.listo_desde || '') > (Date.parse(ahora || '') || Date.now());
      if (motNav.size) return [C.avisoComandaNoImpresa([...new Set([...motNav, ...motDir])]), 'err'];
      if (motDir.size) return programado ? [C.textoAceptadoMasTarde(copia.hora_entrega), 'ok'] : this.enProg && copia.vieja ? [C.avisoComandaNoImpresa([...motDir]), 'err'] : [C.avisoComandaNoImpresa([...motDir], { saleSola: true }), 'info'];   /* validación 4.32 (programa): la copia vieja (más de 30 min) ya no sale sola */
      if (ocupadaPor) return [C.textoAceptadoOcupada(ocupadaPor), 'ok'];
      return ganados.length ? ['Pedido aceptado y comanda impresa.', 'ok'] : ['Pedido actualizado.', 'ok'];
    },
    // 4.31: las marcas «impresa» que no llegaron se reintentan solas, cada 4 s y unos 50 s (sin esperar: el aviso de aceptar ya salió). Si
    // alguna no llega, entonces sí se avisa que no la imprima otra vez. `envios` = funciones que mandan cada marca.
    async marcarDespues(C, envios) {
      let quedan = envios.slice();
      for (let i = 0; i < 12 && quedan.length; i++) {
        await new Promise(r => setTimeout(r, 4000));
        const siguen = [];
        for (const f of quedan) { const m = await f(); if (C.marcaPorReintentar(m)) siguen.push(f); }
        quedan = siguen;
      }
      if (quedan.length) toast('Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez.', 'err');
      return !quedan.length;
    },
    // 4.29 (sin cambios de fondo; en la 4.31 solo si el servidor no tiene la copia de la comanda): imprime la comanda de la cuenta que el
    // servidor creó para el pedido (la misma función que «Imprimir» del monitor) y marca como impresas las líneas que salieron.
    async comandaAnterior(C, r, vent, datos) {
      try {
        const esp = await C.conTope(api('/api/registros/pos_espera'), 5000, 'tope');
        if (esp === 'tope') return [C.avisoComandaNoImpresa(C.MOTIVO_LECTURA_TARDE), 'err'];
        const cats = { datos: datos.categorias }, ext = { datos: datos.extras }, prods = datos.productos;
        const cuenta = ((esp && Array.isArray(esp.datos)) ? esp.datos : []).find(c => c && r.cuenta_espera_id && c.id === r.cuenta_espera_id);
        if (!cuenta) return [C.avisoComandaNoImpresa('no se encontró la cuenta del pedido en la caja'), 'err'];
        const conf = datos.cfg, impresoras = datos.impresoras;
        const caja = C.cajaDe(conf, cuenta.terminal_id);
        if (caja.imprimir_comanda === false) return ['Pedido actualizado.', 'ok'];
        const todas = C.lineasComandaPedido(cuenta, { impresoras, categorias: cats && cats.datos, extras: ext && ext.datos, productos: prods, terminal: caja });
        const ronda = todas.length ? (+todas[0].ronda || 1) : 1, lineas = todas.filter(l => (+l.ronda || 1) === ronda);
        if (!lineas.length) return ['Pedido actualizado.', 'ok'];
        const ventana = vent ? vent.w : null; if (vent) vent.w = null;   /* imprimirComandas la usa o la cierra */
        const res = await C.imprimirComandas({ cuenta, ronda, lineas, numero: C.numeroDeRonda(lineas), icono: '🌐', desde: lineas.map(l => l.enviado).sort()[0], local: !!(sesion.empresaInfo && sesion.empresaInfo.es_local), respaldoNavegador: false, ventana });
        const pos = res.impresas.map(l => l.pos).filter(n => Number.isInteger(n));
        // 4.29 (W-2): si todo salió, los platos «sin comanda» de esa ronda también quedan marcados: en Cocina la comanda se ve «Impresa»
        if (!res.fallas.length) cuenta.lineas.forEach((l, i) => { if (l && l.enviado && +l.cantidad > 0 && (+l.ronda || 1) === ronda && !pos.includes(i)) pos.push(i); });
        let marcada = true;
        if (pos.length) { try { await api('/api/pedidos/' + r.id + '/comanda/impresa', { method: 'POST', body: { lineas: pos } }); } catch { marcada = false; } }
        if (res.fallas.length) return [C.avisoComandaNoImpresa(res.fallas), 'err'];
        if (!marcada) return ['Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez.', 'err'];
        return ['Pedido aceptado y comanda impresa.', 'ok'];
      } catch (e) { return [C.avisoComandaNoImpresa((e && e.message) || 'no se pudieron leer los datos de impresión'), 'err']; }
    },
    async confirmarCancelar() {
      const c = this.cancelar; const motivo = (c.motivo || '').trim();
      if (motivo.length < 8) return toast('Explica la justificación (al menos 8 caracteres).', 'err');
      if (await this.estadoWeb(c.p, 'cancelado', motivo)) this.cancelar = null;
    },
    abrirDespacho(p) { this.despacho = { p, motorizado_id: p.entrega && p.entrega.motorizado_id ? p.entrega.motorizado_id : '' }; },
    async despachar() {
      const d = this.despacho; if (!d.p.entrega) return toast('Este pedido no tiene entrega a domicilio.', 'err');
      try { const r = await api('/api/entregas/' + d.p.entrega.id + '/asignar', { method: 'PUT', body: { motorizado_id: d.motorizado_id ? +d.motorizado_id : null } }); d.p.entrega = r; toast(d.motorizado_id ? 'Express asignado a ' + r.motorizado : 'Express publicado: cualquier motorizado afiliado puede tomarlo', 'ok'); this.despacho = null; }
      catch (e) { toast(e.message, 'err'); }
    },
    verComprobante(p) { abrirArchivo('/api/pedidos/' + p.id + '/sinpe/comprobante').catch(e => toast(e.message, 'err')); },
    async sinpe(p, ok) {
      const motivo = ok ? null : (prompt('¿Por qué se rechaza el comprobante? (el cliente lo ve)', 'No aparece el SINPE en la cuenta') || '').trim();
      if (!ok && !motivo) return;
      try { const r = await api('/api/pedidos/' + p.id + '/sinpe', { method: 'PUT', body: { verificado: ok, motivo } }); Object.assign(p, r); toast(ok ? 'Pago por SINPE verificado' : 'Comprobante rechazado: el pedido queda por pagar al recibir', ok ? 'ok' : 'err'); }
      catch (e) { toast(e.message, 'err'); }
    },
    beep() { try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 660; g.gain.value = 0.2; o.start(); o.stop(ac.currentTime + 0.35); } catch { /* sin audio */ } },
    async pausar() {
      const n = sesion.negocio; if (!n) return; const reanudar = this.pausada;
      if (!reanudar && !confirm('¿Pausar los pedidos en línea? La página sigue visible, pero no recibe pedidos hasta que la reanude.')) return;
      this.pausando = true;
      try { const r = await api('/api/pedidos/negocio/abierto', { method: 'PUT', body: { abierto_manual: reanudar ? null : false } }); n.abierto_manual = r.abierto_manual; n.abierto = r.abierto; toast(reanudar ? (r.abierto.abierto ? 'La página vuelve a recibir pedidos' : 'Pausa quitada: la página sigue el horario (' + (r.abierto.motivo || 'cerrada ahora') + ')') : 'Pedidos en línea en pausa', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.pausando = false;
    },
    async cambiarAvisos(v) {
      if (v) { const ok = await activarAvisos(); this.avisos = ok; toast(ok ? 'Avisos activados en este dispositivo' : 'No se pudo activar: revise los permisos del navegador', ok ? 'ok' : 'err'); }
      else { desactivarAvisos(); this.avisos = false; toast('Avisos desactivados en este dispositivo', 'ok'); }
    },
    jobActivo(p) { return p.entrega && !['cancelada', 'entregada'].includes(p.entrega.estado) && !['pendiente', 'liberada'].includes(p.entrega.estado); },
  },
  // 4.9: ir de #/pedidos a #/pedidos?contacto_id=N (o volver) no vuelve a montar la página: se vigila la consulta de la ruta
  watch: { 'params.query'() { const c = contactoDe(this.params); if (c === this.contacto) return; this.contacto = c; this.estado = c ? 'todos' : ''; this.cargar(); } },
  async created() { this.cargarImpresion(); if (this.entregas) { try { this.motos = (await api('/api/entregas/motorizados')).filter(m => m.activo); } catch { this.motos = []; } } await this.cargar(); this._t = setInterval(() => this.cargar(true), 20000); },
  beforeUnmount() { clearInterval(this._t); },
  template: `
  <div>
    <div class="page-heading"><div><h1>Pedidos · {{sesion.sucursalActual ? sesion.sucursalActual.nombre : sesion.nombreNegocio}}</h1></div><div class="toolbar"><label class="fis-inline" title="Sonido y notificación de cada pedido nuevo, aunque esté en otra pestaña"><input type="checkbox" :checked="avisos" @change="cambiarAvisos($event.target.checked)"> Avisar en este dispositivo</label><button v-if="sesion.negocio && sesion.negocio.activo && !enProg" class="btn btn-light" type="button" :disabled="pausando" @click="pausar">{{pausada ? 'Reanudar pedidos en línea' : 'Pausar pedidos en línea'}}</button><small v-if="enProg && sesion.negocio && sesion.negocio.activo" class="muted" title="Pausar pedidos en línea" data-solo-web="pausar">Esto se hace en la página web.</small><a v-if="sesion.negocio && sesion.negocio.url" class="btn" target="_blank" rel="noopener" :href="sesion.negocio.url_publica || sesion.negocio.url">Ver tienda</a></div></div>
    <section v-if="enProg" class="card admin-card" data-franja-programa><p class="muted">Aquí ve los pedidos de los últimos días. Se aceptan y se cobran en este programa. Para verificar un SINPE, asignar una entrega o ver pedidos anteriores, use la página web.</p><p v-if="sinImprimir > 0" class="alert warn" data-comandas-sin-imprimir>{{sinImprimir === 1 ? 'Hay 1 comanda de pedidos sin imprimir: abra la Caja.' : 'Hay ' + sinImprimir + ' comandas de pedidos sin imprimir: abra la Caja.'}} <a class="btn btn-light" href="/app/#/pos/caja">Abrir la Caja</a></p></section>
    <section class="card admin-card"><form class="qa180-filter" @submit.prevent="cargar()"><label>Origen<select class="input" v-model="origen"><option value="">Todos</option><option value="web">Pedidos web</option><option value="caja">Cuentas de caja</option></select></label><label>Estado<select class="input" v-model="estado"><option value="">Activos</option><option value="todos">Todos</option><option v-for="e in ESTADOS" :key="e[0]" :value="e[0]">{{e[1]}}</option></select></label><label v-if="!contacto">Periodo<select class="input" v-model="dias"><option :value="2">2 días</option><option :value="7">7 días</option><option :value="30">30 días</option></select></label><button class="btn" :disabled="cargando">Filtrar</button></form>
      <div v-if="contacto" class="fis-inline" style="margin-top:10px"><span><strong>Pedidos de {{nombreRev || 'la revendedora'}}</strong> · todas las fechas · {{resumenRev.n}} pedido(s) por {{dinero(resumenRev.total)}}<template v-if="resumenRev.credito"> · a crédito {{dinero(resumenRev.credito)}}</template></span><a v-if="puedeCuenta" class="btn" :href="urlEstadoCuenta(contacto)">Estado de cuenta</a><a class="btn btn-light" href="#/pedidos">Ver todos los pedidos</a></div></section>
    <section class="op180-order-list card admin-card" data-live-region="orders"><p class="muted">Los pedidos se actualizan automáticamente. Cobro, preparación y entrega se registran por separado.</p><div class="table-wrap"><table class="table"><thead><tr><th>Pedido / fecha</th><th>Cliente / origen</th><th>Estado actual</th><th>Total / pago</th><th>Acciones</th></tr></thead><tbody>
      <tr v-for="f in filas" :key="f.origen + '-' + f.id" :data-order-row="f.origen + '-' + f.id"><td><strong>#{{f.numero}}</strong><small>{{fechaCorta(f.creado)}}</small></td><td>{{f.cliente}}<small>{{f.origen === 'web' ? 'Pedido / ' + (f.tipo === 'recoger' ? 'retiro' : 'entrega') : 'Caja · ' + f.tipo}}</small><small v-if="f.origen === 'web' && f.p.contacto_id && String(f.p.contacto_id) !== contacto"><a :href="'#/pedidos?contacto_id=' + f.p.contacto_id">Revendedora · ver sus pedidos</a></small></td>
        <td><span class="op180-status">{{f.origen === 'web' && jobActivo(f.p) ? f.p.entrega.estado_nombre : f.estado_nombre}}</span><small v-if="f.origen === 'web' && f.p.entrega && f.p.entrega.motorizado">{{f.p.entrega.motorizado}}</small><small v-if="f.origen === 'web' && +f.p.atiende > 0" class="op180-atiende" data-atiende>Lo atiende «{{nombreAtiende(f.p)}}»</small><small v-if="f.origen === 'web' && esperandoCaja(f.p)" class="op180-espera" data-espera>Esperando a «{{nombreAtiende(f.p)}}»: el pedido todavía no entra a esa caja.</small></td>
        <td>{{dinero(f.total)}}<small>{{f.pago}}</small><small v-if="f.origen === 'web' && f.p.comprobante" data-comprobante>{{f.p.comprobante}}</small></td>
        <td class="op180-actions">
          <template v-if="f.origen === 'web'">
            <form v-if="!(+f.p.atiende > 0) && (f.estado === 'nuevo' || (f.estado === 'confirmado' && !f.p.cuenta_espera_id && !f.p.documento_id)) && (!enProg || f.estado === 'nuevo')" @submit.prevent="aceptar(f.p)"><button class="btn btn-light" :disabled="!!aceptando[f.id]">{{conComanda ? 'Aceptar e imprimir comanda' : 'Aceptar pedido'}}</button><small v-if="enProg && aceptando[f.id]" class="muted" data-confirmando>Confirmando con la página web…</small></form>
            <a v-else-if="menu && ['confirmado','en_preparacion'].includes(f.estado) && !lejos(f.p)" class="btn btn-light" href="/app/#/pos/cocina">Abrir monitor</a>
            <form v-else-if="!enProg && !menu && ['confirmado','en_preparacion'].includes(f.estado) && !(envio(f.p) && entregas) && !lejos(f.p)" @submit.prevent="estadoWeb(f.p, 'entregado')"><button class="btn btn-light">Marcar entregado</button></form>
            <button v-else-if="!enProg && ['confirmado','en_preparacion','listo'].includes(f.estado) && envio(f.p) && entregas && f.p.entrega && !jobActivo(f.p)" class="btn" type="button" @click="abrirDespacho(f.p)">Asignar a Express</button>
            <form v-else-if="!enProg && f.estado === 'listo' && !jobActivo(f.p) && !lejos(f.p)" @submit.prevent="estadoWeb(f.p, 'entregado')"><button class="btn btn-light">Entregar</button></form>
            <form v-if="conProgramaElegido && f.estado === 'nuevo'" @submit.prevent="aceptarComo(f.p, { aqui: true })"><button class="btn btn-light" :disabled="!!aceptando[f.id]" data-aceptar-aqui>Aceptar y atenderlo aquí</button></form>
            <button v-if="puedeRescatar && lejos(f.p) && !['entregado','cancelado'].includes(f.estado)" class="btn btn-light" type="button" :disabled="!!aceptando[f.id] || !!atendiendo[f.id]" @click="atenderAqui(f.p)" data-rescate>Atenderlo aquí</button>
            <small v-if="lejos(f.p) && !['entregado','cancelado'].includes(f.estado)" class="muted" data-cobrar-alla>Este pedido lo atiende «{{nombreAtiende(f.p)}}»: cóbrelo allá.</small>
            <small v-if="soloWebFila(f)" class="muted" data-solo-web="fila">Esto se hace en la página web.</small>
            <template v-if="!enProg && f.p.pago_medio === 'sinpe' && f.p.pago_estado !== 'aprobado' && !['entregado','cancelado'].includes(f.estado)"><button v-if="f.p.sinpe && f.p.sinpe.comprobante" class="btn btn-light" type="button" @click="verComprobante(f.p)">Ver comprobante SINPE</button><button class="btn btn-light" type="button" @click="sinpe(f.p, true)">Pago verificado</button><button v-if="f.p.pago_estado === 'sinpe_pendiente'" class="btn btn-light" type="button" @click="sinpe(f.p, false)">Rechazar pago</button></template>
            <a v-if="f.p.cuenta_espera_id && !['entregado','cancelado'].includes(f.estado)" class="btn btn-light" href="/app/#/pos/caja">Ver cuenta</a>
            <a v-if="f.p.contacto_id && puedeCuenta" class="btn btn-light" :href="urlEstadoCuenta(f.p.contacto_id)">Estado de cuenta</a>
            <a class="btn btn-light" :href="'#/pedido/' + f.id + (f.p.contacto_id ? '?contacto_id=' + f.p.contacto_id : '')">Detalle y bitácora</a>
            <button v-if="!['entregado','cancelado'].includes(f.estado)" class="btn btn-light" type="button" @click="cancelar = {p: f.p, motivo: ''}">Cancelar con justificación</button>
          </template>
          <template v-else><a class="btn btn-light" href="/app/#/pos/caja">Ver cuenta</a><a v-if="menu" class="btn btn-light" href="/app/#/pos/cocina">Abrir monitor</a></template>
        </td></tr>
      <tr v-if="!filas.length"><td colspan="5">No hay pedidos en este filtro.</td></tr></tbody></table></div></section>
    <dialog class="qa180-dispatch-dialog" :open="!!despacho" v-if="despacho"><form @submit.prevent="despachar"><h2>Asignar a Express · pedido #{{despacho.p.numero}}</h2><p>{{despacho.p.direccion}}<span v-if="despacho.p.zona"> · zona {{despacho.p.zona}}</span> · pago al motorizado {{dinero(despacho.p.entrega ? despacho.p.entrega.pago_motorizado : 0)}}</p><label>Motorizado<select class="input" v-model="despacho.motorizado_id"><option value="">Publicar para cualquier motorizado afiliado</option><option v-for="m in motos" :key="m.id" :value="m.id">{{m.nombre}} · {{m.vehiculo_nombre}}</option></select></label><button class="btn btn-light" type="button" @click="despacho = null">Volver</button><button class="btn">Confirmar</button></form></dialog>
    <dialog id="op180Cancel" class="qa180-dispatch-dialog" :open="!!cancelar" v-if="cancelar"><form @submit.prevent="confirmarCancelar"><h2>Cancelar pedido #{{cancelar.p.numero}}</h2><label>Justificación<textarea class="input" v-model="cancelar.motivo" required minlength="8" maxlength="500"></textarea></label><p>Quedará registrada con tu usuario y fecha. Un pedido con cobros requiere revisar la devolución.</p><button class="btn btn-light" type="button" @click="cancelar = null">Volver</button><button class="btn">Confirmar cancelación</button></form></dialog>
  </div>`,
};
