// FISITAAP › Extras (qa180_modifiers del zip, tipo «extra»): un elemento con precio adicional, obligatorio o no, asignado a
// productos o a categorías completas. Son grupos de modificadores del punto de venta: la caja y el catálogo ya los cobran.
import { api, toast } from '/js/api.js';
import { AvisoRecuperarMods } from '/js/pages/pos/_recuperar_mods.js';   // 4.30: recuperar de un respaldo los productos y categorías perdidos
import { dinero } from '../ui.js';

export default {
  props: ['params'],
  components: { AvisoRecuperarMods },
  data() { return { grupos: [], productos: [], categorias: [], f: this.vacio(), guardando: false }; },
  computed: { editando() { return !!this.f.id; } },
  methods: {
    dinero,
    vacio() { return { id: null, nombre: '', precio: 0, obligatorio: false, productos: [], categorias: [] }; },
    async cargar() { try { const r = await api('/api/fisitaap/modificadores?tipo=extra'); this.grupos = r.grupos; this.productos = r.productos; this.categorias = r.categorias; } catch (e) { toast(e.message, 'err'); } },
    editar(g) { this.f = { id: g.id, nombre: g.nombre, precio: g.precio, obligatorio: g.obligatorio, productos: [...g.productos], categorias: [...g.categorias] }; window.scrollTo(0, 0); },
    async guardar() {
      if (!this.f.nombre.trim()) return toast('Escribe el nombre.', 'err');
      this.guardando = true;
      try { await api(this.f.id ? '/api/fisitaap/extras/' + this.f.id : '/api/fisitaap/extras', { method: this.f.id ? 'PUT' : 'POST', body: { ...this.f, precio: +this.f.precio || 0 } }); toast('Elemento guardado.', 'ok'); this.f = this.vacio(); await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async desactivar(g) { try { await api('/api/fisitaap/modificadores/' + g.id, { method: 'DELETE' }); toast('Elemento guardado.', 'ok'); if (this.f.id === g.id) this.f = this.vacio(); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div class="split"><section class="card admin-card"><h2>{{editando ? 'Editar elemento' : 'Crear elemento'}}</h2><form @submit.prevent="guardar">
      <div class="form-group"><label>Nombre</label><input class="input" v-model="f.nombre" maxlength="120" required></div>
      <div class="form-group"><label>Precio adicional</label><input class="input" type="number" step=".01" min="0" v-model="f.precio" required></div>
      <label><input type="checkbox" v-model="f.obligatorio"> Selección obligatoria</label>
      <h3>Asignar a productos</h3><label>Seleccionar productos<select class="input" multiple size="6" v-model="f.productos"><option v-for="p in productos" :key="p.id" :value="p.id">{{p.nombre}} · {{p.codigo}}</option></select></label>
      <h3>Asignar a categorías completas</h3><div class="qa180-modifier-list"><label v-for="c in categorias" :key="c"><input type="checkbox" :value="c" v-model="f.categorias"> {{c}}</label><p v-if="!categorias.length">Sus ítems todavía no tienen categorías.</p></div>
      <p>Al mover un producto, conserva sus asignaciones manuales y hereda las de la categoría nueva.</p>
      <button class="btn" :disabled="guardando">Guardar elemento</button> <button v-if="editando" class="btn btn-light" type="button" @click="f = vacio()">Cancelar</button></form></section>
    <section class="card admin-card"><h2>Elementos creados</h2><AvisoRecuperarMods clase="card" @recuperado="cargar"/>
      <article class="r2-row" v-for="g in grupos" :key="g.id"><strong>{{g.nombre}}</strong><span>{{dinero(g.precio)}}</span><a class="btn btn-light" href="#/extras" @click.prevent="editar(g)">Editar</a><form @submit.prevent="desactivar(g)"><button class="btn btn-danger">Desactivar</button></form></article>
      <p v-if="!grupos.length">Todavía no hay extras. Crea el primero a la izquierda.</p>
    </section></div>`,
};
