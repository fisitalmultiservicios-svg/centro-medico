// FISITAAP › Clientes › Historial (r2_customers del zip): búsqueda, tabla con compras, origen y crédito, y las compras del cliente
// elegido con su fidelización. Crear y buscar clientes abre Contactos del ERP; aquí están los clientes de la página (teléfono).
// 4.9 (Revendedoras): la columna Crédito trae el límite, lo que debe y lo disponible de verdad (lista /api/revendedoras, por los
// últimos 8 dígitos del teléfono) con el enlace a su estado de cuenta; sin permiso de cuentas la columna no se muestra. El historial
// pide /api/pedidos?telefono= (todas sus compras, sin el tope de la lista general) y muestra la forma de pago.
import { api, toast } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta, formaPago, puedeEstadoCuenta, urlEstadoCuenta, tel8 } from '../ui.js';
import { telefonoWa, enlaceWhatsApp } from '/js/pages/reportes/_revendedoras.js';   // 4.9: funciones puras compartidas con el ERP (sin app.js)

export default {
  props: ['params'],
  // 4.9: revs = {últimos 8 dígitos: fila de /api/revendedoras}; null = sin datos de crédito (sin permiso, 403, o todavía cargando)
  data() { return { sesion, q: '', lista: [], sel: null, pedidos: [], puntos: null, cargando: false, revs: null }; },
  computed: {
    filtrados() { const q = this.q.trim().toLowerCase(); return this.lista.filter(c => !q || c.telefono.includes(q) || (c.nombre || '').toLowerCase().includes(q)); },
    puedeCuenta() { return puedeEstadoCuenta(sesion); },
    // 4.9: la revendedora (contacto del ERP) del cliente elegido: por su teléfono en la lista de saldos o por sus pedidos
    selContacto() { const r = this.rev(this.sel); return (r && r.contacto_id) || (this.pedidos.find(p => p.contacto_id) || {}).contacto_id || null; },
  },
  methods: {
    dinero, fechaCorta, formaPago, urlEstadoCuenta, telefonoWa, enlaceWhatsApp,
    async cargar() { this.cargando = true; try { this.lista = await api('/api/pedidos/clientes'); } catch (e) { toast(e.message, 'err'); } this.cargando = false; },
    // 4.9: crédito real de cada cliente; si un teléfono está en dos contactos, gana el que tiene límite o saldo
    async cargarCreditos() {
      if (!this.puedeCuenta) { this.revs = null; return; }
      try {
        const l = await api('/api/revendedoras'); const m = {}, peso = r => (+r.limite || 0) + (+r.saldo || 0);
        for (const r of (Array.isArray(l) ? l : [])) { const t = tel8(r.telefono); if (t.length === 8 && (!m[t] || peso(r) > peso(m[t]))) m[t] = r; }
        this.revs = m;
      } catch { this.revs = null; }   // 403 (sin permiso de cuentas) u otro error: la columna Crédito no se muestra
    },
    rev(c) { return (this.revs && c && this.revs[tel8(c.telefono)]) || null; },
    async ver(c) {
      this.sel = c; this.pedidos = []; this.puntos = null;
      // 4.9: todas las compras de ese teléfono; se filtra otra vez aquí (mismo teléfono o pedidos hechos con este acceso) por si el
      // servidor no conoce el filtro
      try { const t = tel8(c.telefono); const l = await api('/api/pedidos?telefono=' + encodeURIComponent(c.telefono) + '&desde=2000-01-01&hasta=2099-12-31'); if (this.sel === c) this.pedidos = l.filter(p => tel8(p.telefono) === t || p.cliente_final_id === c.id); } catch (e) { toast(e.message, 'err'); }
      try { this.puntos = await api('/api/fidelizacion/saldo?telefono=' + c.telefono); } catch { this.puntos = null; }
    },
    // 3.87: libera el teléfono (otra persona creó el acceso con ese número, o el cliente olvidó su clave): sus sesiones dejan de valer
    // y el dueño del teléfono crea un acceso nuevo; los pedidos quedan en Pedidos
    async restablecer(c) {
      if (!confirm('¿Restablecer el acceso del teléfono ' + c.telefono + '? Quien haya entrado con ese número deja de ver la cuenta, y el dueño del teléfono crea su acceso de nuevo con una clave nueva (y, si es revendedora, con su código personal). Sus pedidos anteriores vuelven a la cuenta nueva cuando abre el enlace de seguimiento de cada uno.')) return;
      try { await api('/api/pedidos/clientes/' + c.id, { method: 'DELETE' }); toast('Acceso restablecido. El dueño del teléfono ya puede crear uno nuevo.', 'ok'); if (this.sel && this.sel.id === c.id) this.sel = null; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
  },
  created() { this.cargar(); this.cargarCreditos(); },
  template: `
  <div>
    <section class="card admin-card"><form @submit.prevent><div class="form-group"><label>Nombre o teléfono</label><input class="input" v-model="q" maxlength="100"></div><a class="btn btn-light" href="/app/#/contactos">Buscar en Contactos del ERP</a></form>
      <div class="table-wrap"><table class="table"><tr><th>Cliente</th><th>Compras</th><th>Origen</th><th v-if="revs">Crédito</th><th>Detalle</th></tr>
        <tr v-for="c in filtrados" :key="c.id"><td>{{c.nombre || '—'}}<br>{{c.telefono}}</td><td>{{c.pedidos || 0}} · {{dinero(c.total || 0)}}</td><td>{{rev(c) ? 'Revendedora' + (rev(c).lista ? ' · ' + rev(c).lista : '') : 'Web'}}<br>{{c.ultimo_pedido ? fechaCorta(c.ultimo_pedido) : ''}}</td>
          <td v-if="revs"><template v-if="rev(c)"><template v-if="+rev(c).limite > 0 || +rev(c).saldo > 0">Límite {{dinero(rev(c).limite)}} · debe {{dinero(rev(c).saldo)}}<template v-if="+rev(c).en_pedidos > 0"> · en pedidos {{dinero(rev(c).en_pedidos)}}</template><br><template v-if="+rev(c).vencido > 0">Vencido {{dinero(rev(c).vencido)}} · </template>Disponible {{dinero(rev(c).disponible)}}</template><template v-else>Sin límite de crédito</template><br><a :href="urlEstadoCuenta(rev(c).contacto_id)">Estado de cuenta</a></template><template v-else>Sin crédito<br><a href="/app/#/contactos">Fiado en el ERP</a></template></td>
          <td><a class="btn btn-light" href="#/clientes-historial" @click.prevent="ver(c)">Historial</a> <button v-if="sesion.puede('catalogos')" class="btn btn-light" type="button" title="Libera el teléfono para que su dueño cree un acceso nuevo" @click="restablecer(c)">Restablecer acceso</button></td></tr>
        <tr v-if="!cargando && !filtrados.length"><td colspan="5">Todavía no hay clientes de la página. Aparecen cuando alguien pide con su teléfono.</td></tr></table></div></section>
    <section class="card admin-card" style="margin-top:20px" v-if="sel"><h2>Compras del cliente</h2><p>{{sel.nombre || sel.telefono}}<template v-if="telefonoWa(sel.telefono)"> · <a :href="enlaceWhatsApp(telefonoWa(sel.telefono))" target="_blank" rel="noopener">WhatsApp</a></template><span v-for="(d, i) in sel.direcciones" :key="i"> · {{d.nombre || 'Dirección'}}: {{d.detalle}}</span></p>
      <p v-if="selContacto" class="fis-inline">Revendedora<a class="btn btn-light" :href="'#/pedidos?contacto_id=' + selContacto">Ver sus pedidos en Pedidos</a><a v-if="puedeCuenta" class="btn btn-light" :href="urlEstadoCuenta(selContacto)">Estado de cuenta</a></p>
      <div class="table-wrap"><table class="table"><tr><th>Fecha</th><th>Documento</th><th>Canal</th><th>Total</th><th>Pago</th><th>Estado</th></tr><tr v-for="p in pedidos" :key="p.id"><td>{{fechaCorta(p.creado)}}</td><td><a :href="'#/pedido/' + p.id + (p.contacto_id ? '?contacto_id=' + p.contacto_id : '')">#{{p.numero}}</a></td><td>Web</td><td>{{dinero(p.total)}}</td><td>{{formaPago(p)}}</td><td>{{p.estado_nombre}}</td></tr><tr v-if="!pedidos.length"><td colspan="6">Sin pedidos.</td></tr></table></div>
      <h3>Fidelización</h3><p v-if="puntos">Saldo: <strong>{{Math.round(puntos.saldo)}}</strong> puntos · equivalen a {{dinero(puntos.valor)}}</p><p v-for="(m, i) in (puntos ? puntos.movimientos : [])" :key="i">{{fechaCorta(m.fecha)}} · {{m.motivo}} · {{m.puntos > 0 ? '+' : ''}}{{Math.round(m.puntos)}}</p><p v-if="!puntos">Sin movimientos de puntos.</p></section>
  </div>`,
};
