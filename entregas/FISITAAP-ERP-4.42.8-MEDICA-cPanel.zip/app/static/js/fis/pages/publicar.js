// Ventas en línea › Mi página › Publicar y dominio (3.78). Al embeber FISITAAP (3.74) se perdió la pantalla del ERP «Mi página»,
// que era la única con el botón Publicar, la dirección pública, los datos para buscadores, los píxeles y el dominio propio: la
// página del negocio no se podía activar desde la interfaz. Aquí vuelve todo eso con las piezas de la aplicación embebida. Los
// textos, fotos y colores del diseño siguen en «Diseño de la página»; las formas de entrega y el cobro, en «Generales».
// 4.9 (Revendedoras): la pestaña Revendedoras enlaza el estado de cuenta de cada una (ERP, #/contactos/estado-cuenta/:id), sus pedidos
// y la lista con los saldos de todas (#/contactos/revendedoras).
// 4.40: la guía dice que el agotado puede ser a mano o, si se activa, según existencias.
import { api, toast, fechaHora } from '/js/api.js';
import { cargarNegocio, guardarNegocio } from '/js/pages/fisitaap/_negocio.js';
import { sesion } from '../sesion.js';
import { urlEstadoCuenta } from '../ui.js';

const FUENTES = [['', 'La del sistema'], ['inter', 'Inter (moderna)'], ['manrope', 'Manrope (redondeada)'], ['clasica', 'Clásica (con serifas)']];
const TABS = [['publicar', 'Publicar'], ['portada', 'Portada, fotos y Nosotros'], ['apariencia', 'Presentación'], ['mayorista', 'Revendedoras'], ['buscadores', 'Buscadores y píxeles'], ['dominio', 'Dominio propio']];

export default {
  props: ['params'],
  data() { return { n: null, guardando: false, marcas: [], FUENTES, TABS, subiendo: false, subiendoFoto: false, copiado: false, tab: 'publicar', dns: null, verificando: false, sis: { dominio: '' }, revs: null, qRev: '' }; },
  computed: {
    sugerido() { const e = sesion.empresa || sesion.empresaInfo || {}; return String(e.nombre_comercial || e.nombre || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); },
    cobros() { return sesion.puede('configurar'); },   // 3.87: dominio y píxeles, solo quien configura la empresa (como el servidor)
    hostBase() { return (this.n && this.n.host_base) || this.sis.dominio || location.host; },
    url() { return this.n ? (this.n.url_publica || this.n.url || '') : ''; },
    abiertaTexto() { const a = this.n && this.n.abierto; return a && a.abierto ? 'abierta ahora' : ((a && a.motivo) || 'cerrada ahora'); },
    revsFiltradas() { const q = this.qRev.trim().toLowerCase(); return (this.revs || []).filter(r => !q || r.telefono.includes(q) || (r.nombre || '').toLowerCase().includes(q)).slice(0, 300); },
  },
  // 3.87: los códigos personales de las revendedoras se cargan al abrir la pestaña (y otra vez después de guardar el código del negocio);
  // los ve quien administra Clientes e ítems ('catalogos', como en el servidor), el mismo que registra a la revendedora en Contactos
  watch: { tab(v) { if (v === 'mayorista' && sesion.puede('catalogos')) this.cargarRevendedoras(); } },
  methods: {
    fechaHora,
    async cargar() {
      try { const n = await cargarNegocio(); if (!n.slug) n.slug = this.sugerido; if (!n.redes) n.redes = {}; if (!n.galeria) n.galeria = []; this.n = n; } catch (e) { toast(e.message, 'err'); }
      try { this.marcas = await api('/api/marcas'); } catch { this.marcas = []; }
      try { const r = await fetch('/api/sistema'); if (r.ok) this.sis = await r.json(); } catch { /* sin dominio del sistema: queda el del navegador */ }
    },
    async guardar(publicar) {
      const n = this.n; if (publicar !== undefined) n.activo = publicar;
      if (!(n.slug || '').trim()) return toast('Escriba la dirección de la página (el nombre público)', 'err');
      this.guardando = true;
      try { this.n = await guardarNegocio(n); await sesion.recargarNegocio(); if (this.tab === 'mayorista' && sesion.puede('catalogos')) this.cargarRevendedoras(); toast(this.n.activo ? 'Página publicada en ' + (this.n.url_publica || this.n.url) : 'Guardado (la página no está publicada)', 'ok'); }
      catch (e) { toast(e.message, 'err'); this.guardando = false; return false; }
      this.guardando = false; return true;
    },
    async subirPortada(ev) {
      const f = ev.target.files && ev.target.files[0]; if (!f) return; ev.target.value = '';
      if (f.size > 4 * 1024 * 1024) return toast('La portada no puede pasar de 4 MB', 'err');
      this.subiendo = true;
      try { const fd = new FormData(); fd.append('archivo', f, f.name); const r = await api('/api/pedidos/negocio/portada', { method: 'POST', body: fd }); this.n.portada = r.portada; toast('Portada actualizada', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.subiendo = false;
    },
    async quitarPortada() { try { await api('/api/pedidos/negocio/portada', { method: 'DELETE' }); this.n.portada = null; } catch (e) { toast(e.message, 'err'); } },
    async subirFoto(ev) {
      const fs = Array.from(ev.target.files || []); ev.target.value = ''; if (!fs.length) return;
      this.subiendoFoto = true;
      for (const f of fs) {
        if (f.size > 4 * 1024 * 1024) { toast(f.name + ': cada foto puede pesar hasta 4 MB', 'err'); continue; }
        try { const fd = new FormData(); fd.append('archivo', f, f.name); const r = await api('/api/pedidos/negocio/galeria', { method: 'POST', body: fd }); this.n.galeria = r.galeria; }
        catch (e) { toast(e.message, 'err'); break; }
      }
      this.subiendoFoto = false;
    },
    async quitarFoto(g) { try { const r = await api('/api/pedidos/negocio/galeria/' + encodeURIComponent(g.nombre), { method: 'DELETE' }); this.n.galeria = r.galeria; } catch (e) { toast(e.message, 'err'); } },
    async verificarDominio() {
      if (!(await this.guardar())) return;
      this.verificando = true; this.dns = null;
      try { this.dns = await api('/api/pedidos/negocio/dominio/verificar', { method: 'POST', body: {} }); } catch (e) { toast(e.message, 'err'); }
      this.verificando = false;
    },
    async cargarRevendedoras() { try { this.revs = await api('/api/pedidos/revendedoras'); } catch (e) { this.revs = []; toast(e.message, 'err'); } },
    // 3.87: el código va solo al celular de esa revendedora (así nadie más puede crear el acceso con su teléfono)
    waRevendedora(r) {
      const txt = 'Hola ' + r.nombre + ', este es su acceso al catálogo de ' + (this.n.nombre_publico || '') + ': ' + this.url + '#cuenta\n'
        + 'Entre con este celular, elija una clave de 4 a 8 dígitos y escriba su código personal: ' + r.codigo + '\nEl código es solo para usted; no lo comparta.';
      return 'https://wa.me/506' + r.telefono + '?text=' + encodeURIComponent(txt);
    },
    copiar() { try { navigator.clipboard.writeText(this.url); this.copiado = true; setTimeout(() => { this.copiado = false; }, 2000); } catch { toast('Copie el enlace a mano', 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div v-if="n">
    <div class="alert fis-estado" :class="n.activo ? 'alert-success' : 'fis-pendiente'">
      <template v-if="n.activo"><span>Publicada en <b>{{url}}</b><span v-if="n.url_publica && n.url_publica !== n.url"> (también {{n.url}})</span> · {{n.visibles}} ítem(s) en el catálogo · {{abiertaTexto}}</span><span class="fis-inline"><button type="button" class="btn btn-light" @click="copiar">{{copiado ? 'Copiado' : 'Copiar enlace'}}</button><a class="btn btn-light" :href="url" target="_blank" rel="noopener">Ver mi página</a></span></template>
      <template v-else><span>La página <b>no está publicada</b>: nadie la ve hasta que pulse «Publicar». Marque qué se vende en <a href="#/productos">Productos en línea</a> ({{n.visibles}} ítem(s) marcados) y revise las formas de entrega en <a href="#/configuracion">Generales</a>.</span></template>
    </div>
    <div class="fis-tabs"><button v-for="t in TABS" :key="t[0]" type="button" :class="{on: tab===t[0]}" @click="tab=t[0]">{{t[1]}}</button></div>
    <form @submit.prevent="guardar()">
      <div class="fis-dos">
        <template v-if="tab==='publicar'">
          <section class="card admin-card"><h2>Dirección y publicación</h2>
            <div class="form-group"><label>Dirección de la página</label><div class="fis-inline"><span class="muted">{{hostBase}}/</span><input class="input" v-model="n.slug" maxlength="60" placeholder="soda-el-punto" style="flex:1"></div><p class="fis-ayuda">Solo letras minúsculas, números y guiones (2 a 60). Queda en {{hostBase}}/{{n.slug || 'nombre'}}.</p></div>
            <div class="form-group" v-if="marcas.length"><label>Marca (logo y nombre)</label><select class="input" v-model="n.marca_id"><option :value="null">— La empresa —</option><option v-for="m in marcas" :key="m.id" :value="m.id">{{m.nombre}}</option></select><p class="fis-ayuda">De Configuración › Marcas y logos.</p></div>
            <div class="form-group"><label>Frase de bienvenida</label><input class="input" v-model="n.bienvenida" maxlength="200" placeholder="¡Pida en línea y recoja sin fila!"></div>
            <div class="form-group"><label>Descripción corta</label><textarea class="input" rows="2" v-model="n.descripcion" maxlength="600" placeholder="Comida casera, café y repostería en el centro de Liberia."></textarea></div>
            <div class="fis-inline"><button class="btn" type="submit" :disabled="guardando">Guardar</button><button type="button" class="btn" v-if="!n.activo" :disabled="guardando" @click="guardar(true)">Publicar</button><button type="button" class="btn btn-light" v-else :disabled="guardando" @click="guardar(false)">Despublicar</button></div>
          </section>
          <section class="card admin-card"><h2>Cómo funciona</h2>
            <ol class="fis-pasos">
              <li>En <a href="#/productos">Productos en línea</a> marque qué ítems del Inventario se venden en la página, cuáles van destacados y cuáles están agotados (a mano o, si se activa, según existencias).</li>
              <li>En <a href="#/configuracion">Generales</a> elija las formas de entrega, el costo de envío, la caja que recibe los pedidos y cómo cobra (tarjeta, SINPE Móvil o al recibir).</li>
              <li>En <a href="#/contenido">Diseño de la página</a> ponga sus colores, el slider y los datos de contacto; aquí, la portada, las fotos, los datos para buscadores y el dominio.</li>
              <li>Pulse <b>Publicar</b> y comparta el enlace en redes y WhatsApp. Los pedidos entran a <a href="#/pedidos">Pedidos</a> y a la caja; active los avisos en el celular en Generales.</li>
            </ol>
          </section>
        </template>
        <template v-else-if="tab==='portada'">
          <section class="card admin-card"><h2>Portada</h2>
            <p class="fis-ayuda">Foto ancha (JPG, PNG o WEBP, hasta 4 MB). Portada: 1600 × 900 px (horizontal). Se recorta para llenar el ancho. Se guarda al subirla.</p>
            <div class="fis-inline" style="margin-top:8px"><img v-if="n.portada" :src="n.portada" alt="" style="height:70px;border-radius:8px;object-fit:cover;max-width:220px"><label class="btn btn-light" style="cursor:pointer">{{subiendo ? 'Subiendo…' : (n.portada ? 'Cambiar portada' : 'Subir portada')}}<input type="file" accept="image/*" style="display:none" @change="subirPortada" :disabled="subiendo"></label><button type="button" class="btn btn-light" v-if="n.portada" @click="quitarPortada">Quitar</button></div>
            <h2 style="margin-top:18px">Galería</h2>
            <p class="fis-ayuda">Fotos del local, de los platos o de los productos: son las imágenes del slider del catálogo o menú (Diseño de la página › slider: «Usar la portada y todas las fotos de la galería»). Fotos de la galería: 1600 × 900 px (horizontal); se ven en el slider del catálogo y se recortan al centro. Sin límite de fotos; cada una hasta 4 MB.</p>
            <div class="fis-galeria" style="margin:8px 0"><div v-for="g in n.galeria" :key="g.nombre"><img :src="g.url" alt=""><button type="button" class="btn btn-light" @click="quitarFoto(g)" title="Quitar">✕</button></div></div>
            <label class="btn btn-light" style="cursor:pointer">{{subiendoFoto ? 'Subiendo…' : '+ Agregar fotos'}}<input type="file" accept="image/*" multiple style="display:none" @change="subirFoto" :disabled="subiendoFoto"></label>
          </section>
          <section class="card admin-card"><h2>Nosotros</h2>
            <div class="form-group"><label>Texto «Nosotros»</label><textarea class="input" rows="10" v-model="n.nosotros" maxlength="2000" placeholder="Somos una soda familiar en el centro de Liberia desde 2009…"></textarea><p class="fis-ayuda">Quiénes son, desde cuándo, qué los hace distintos. Hasta 2000 caracteres; los saltos de línea se respetan.</p></div>
          </section>
        </template>
        <template v-else-if="tab==='apariencia'">
          <section class="card admin-card"><h2>Presentación</h2>
            <div class="form-group"><label>Cómo se muestran los ítems</label><select class="input" v-model="n.presentacion"><option value="catalogo">Catálogo: cuadrícula con foto grande (tiendas, productos)</option><option value="menu">Menú: lista por sección con foto pequeña (restaurantes, sodas)</option></select><p class="fis-ayuda">Las secciones son las categorías del Inventario. En ambos casos el cliente toca el ítem para ver opciones, nota y cantidad.</p></div>
            <div class="form-group"><label>Estado manual</label><select class="input" v-model="n.abierto_manual"><option :value="null">Según el horario</option><option :value="true">Abierta siempre</option><option :value="false">Cerrada por ahora (vacaciones, sin existencias…)</option></select><p class="fis-ayuda">Fuerza abierta o cerrada sin tocar el horario de Generales.</p></div>
            <div class="form-group"><label>Tiempo estimado</label><input class="input" v-model="n.tiempo_estimado" maxlength="40" placeholder="30 a 45 min"><p class="fis-ayuda">Se muestra al cliente.</p></div>
          </section>
          <section class="card admin-card"><h2>Tema y letra</h2>
            <div class="form-group"><label>Tema</label><select class="input" v-model="n.tema"><option value="claro">Claro</option><option value="oscuro">Oscuro</option></select></div>
            <div class="form-group"><label>Tipo de letra</label><select class="input" v-model="n.fuente"><option v-for="f in FUENTES" :key="f[0]" :value="f[0]">{{f[1]}}</option></select></div>
            <p class="fis-ayuda">Los colores, el slider y los botones se eligen en <a href="#/contenido">Diseño de la página</a>. Guarde y abra «Ver mi página» para revisar cómo queda en el celular.</p>
          </section>
        </template>
        <template v-else-if="tab==='mayorista'">
          <section class="card admin-card"><h2>Catálogo para revendedoras (mayorista)</h2>
            <label class="fis-inline" style="margin:6px 0"><input type="checkbox" v-model="n.mayorista"> Catálogo privado: solo entran revendedoras registradas</label>
            <p class="fis-ayuda">Cada revendedora debe existir en Contactos como cliente, con su celular, su lista de precios y, si le fía, su límite de crédito. Entra a la página con su teléfono, una clave y su código personal<template v-if="sesion.puede('catalogos')"> (la tabla de abajo)</template>, y ve los precios de su lista.</p>
            <div class="form-group"><label>Código del negocio</label><input class="input" v-model="n.mayorista_codigo" maxlength="40" placeholder="COLONIAS2026" style="text-transform:uppercase"><p class="fis-ayuda">Es la base de los códigos personales de cada revendedora (no se le da a nadie). Si lo cambia y guarda, cambian todos los códigos que todavía no se usaron; las revendedoras que ya entraron siguen igual.</p></div>
            <label class="fis-inline" style="margin:6px 0" v-if="n.mayorista"><input type="checkbox" v-model="n.mayorista_mixto"> Página pública + revendedoras: el público también compra, con los precios normales</label>
            <p class="fis-ayuda" v-if="n.mayorista && n.mayorista_mixto">La página queda abierta para todos. Quien no es revendedora compra a precio normal y sin crédito; las revendedoras entran con su teléfono y su código personal (en «Código de acceso, solo revendedoras») y ven los precios de su lista. Los teléfonos de las revendedoras solo entran con su código.</p>
            <label class="fis-inline" style="margin:6px 0"><input type="checkbox" v-model="n.mayorista_credito"> Permitir pedidos a crédito (dentro del límite de cada contacto)</label>
            <p class="fis-ayuda">El pedido a crédito entra a la caja como cuenta del cliente, marcado «A crédito», y se cierra como fiado. Lo que debe cada revendedora, sus pedidos y lo que ha comprado están en su <b>estado de cuenta</b> (botón en la tabla de abajo) y en <a href="/app/#/contactos/revendedoras">Revendedoras y saldos</a>; su ficha en Contactos también muestra el saldo.</p>
          </section>
          <section class="card admin-card"><h2>Cómo funciona</h2>
            <ol class="fis-pasos">
              <li>Cree o revise la revendedora en <a href="/app/#/contactos">Contactos</a>: celular, lista de precios y límite de crédito.</li>
              <li>Ponga los precios de mayorista en esa lista (Inventario › Ítems › Listas de precios), por valor o por porcentaje de descuento.</li>
              <li>Active el catálogo privado, guarde y envíe a cada revendedora su enlace y su código personal con el botón «Enviar por WhatsApp» de la tabla: le llega a su propio celular.</li>
              <li>Los pedidos llegan a <a href="#/pedidos">Pedidos</a> como siempre; los que son a crédito vienen marcados «A crédito» y la revendedora puede repetir pedidos anteriores desde su cuenta.</li>
              <li>Revise lo que debe cada una y envíele su estado de cuenta desde <a href="/app/#/contactos/revendedoras">Revendedoras y saldos</a> (o con el botón «Estado de cuenta» de la tabla).</li>
            </ol>
          </section>
        </template>
        <template v-else-if="tab==='buscadores'">
          <section class="card admin-card"><h2>Datos para buscadores</h2>
            <div class="form-group"><label>Título</label><input class="input" v-model="n.seo_titulo" maxlength="70" placeholder="Soda El Punto · Comida casera en Liberia"><p class="fis-ayuda">Lo que muestra Google como título. Vacío = nombre del negocio · Pedidos en línea.</p></div>
            <div class="form-group"><label>Descripción</label><textarea class="input" rows="2" v-model="n.seo_descripcion" maxlength="160"></textarea><p class="fis-ayuda">Hasta 160 caracteres. Vacío = la descripción corta.</p></div>
            <div class="form-group"><label>Palabras clave</label><input class="input" v-model="n.seo_palabras" maxlength="200" placeholder="soda, casados, almuerzos, Liberia"><p class="fis-ayuda">Separadas por coma. La página ya lleva los datos estructurados (nombre, teléfono, dirección, horario) y la imagen para compartir en WhatsApp y redes.</p></div>
          </section>
          <section class="card admin-card"><h2>Píxeles de medición</h2>
            <div class="form-group"><label>Etiqueta de Google (Analytics o Ads)</label><input class="input" v-model="n.google_id" :disabled="!cobros" maxlength="30" placeholder="G-ABC123DEF4"><p class="fis-ayuda">Tiene la forma G-XXXXXXXXXX (Analytics) o AW-XXXXXXXXX (Ads). Vacío = sin medición.</p></div>
            <div class="form-group"><label>Píxel de Meta (Facebook e Instagram)</label><input class="input" v-model="n.pixel_meta" :disabled="!cobros" maxlength="20" inputmode="numeric" placeholder="123456789012345"><p class="fis-ayuda">Número de 15 o 16 dígitos del administrador de eventos.</p></div>
            <p class="fis-ayuda">Con esto Google y Meta registran las visitas, los ítems agregados al carrito y cada pedido enviado (con su monto), para medir las campañas. Solo se cargan en su página pública, nunca dentro del sistema.</p>
          </section>
        </template>
        <template v-else-if="tab==='dominio'">
          <section class="card admin-card"><h2>Dominio propio</h2>
            <div class="form-group"><label>Su dominio</label><input class="input" v-model="n.dominio" :disabled="!cobros" maxlength="100" placeholder="www.minegocio.cr"><p class="fis-ayuda">Por ejemplo www.minegocio.cr. Déjelo vacío si no tiene.</p></div>
            <div class="alert" :class="n.dominio_verificado ? 'alert-success' : 'fis-pendiente'" v-if="n.dominio">
              <template v-if="n.dominio_verificado">Verificado: su página responde en <b>https://{{n.dominio}}</b> desde el {{fechaHora(n.dominio_verificado)}}. Los enlaces de los correos al cliente ya usan su dominio.</template>
              <template v-else>Pendiente: todavía no ha llegado ninguna visita por <b>{{n.dominio}}</b>. Complete los pasos de la derecha; en cuanto entre la primera visita queda verificado solo.</template>
            </div>
            <div class="fis-inline"><button type="button" class="btn btn-light" @click="verificarDominio" :disabled="verificando || !n.dominio || !cobros">{{verificando ? 'Revisando…' : 'Guardar y revisar el DNS'}}</button><span class="fis-ayuda" v-if="dns">{{dns.mensaje}}</span></div>
            <h2 style="margin-top:18px">Subdominio</h2>
            <p class="fis-ayuda" v-if="sesion.tieneFuncion('subdominio')">Su página también responde en <b>{{n.url_subdominio || (n.slug + '.' + hostBase)}}</b>; puede compartir esa dirección o <b>{{n.url}}</b>.</p>
            <p class="fis-ayuda" v-else>Sin dominio propio, use <b>{{n.url}}</b>. El subdominio {{n.slug}}.{{hostBase}} se habilita por empresa cuando el servidor tenga el comodín configurado (pídalo a soporte).</p>
          </section>
          <section class="card admin-card"><h2>Cómo conectar su dominio</h2>
            <ol class="fis-pasos">
              <li>Escriba el dominio a la izquierda y guarde.</li>
              <li>En el proveedor donde compró el dominio, cree un registro <b>CNAME</b> con nombre <b>www</b> que apunte a <b>{{hostBase}}</b> (si quiere también sin «www», un registro <b>A</b> a la dirección del servidor; pídala a soporte).</li>
              <li>Escríbanos a soporte con el dominio: lo agregamos como alias del sitio y le emitimos el certificado de seguridad (https). Tarda unas horas.</li>
              <li>Pulse «Guardar y revisar el DNS» para confirmar que el registro ya apunta aquí. La primera visita por su dominio lo deja verificado y desde entonces los correos a sus clientes usan su dirección.</li>
            </ol>
            <p class="fis-ayuda">El panel del sistema y las facturas siguen en {{hostBase}}; solo la página de pedidos se ve en su dominio.</p>
          </section>
        </template>
      </div>
      <section class="card admin-card" style="margin-top:12px" v-if="tab==='mayorista' && sesion.puede('catalogos')"><h2>Códigos de acceso de las revendedoras</h2>
        <p class="fis-ayuda">Cada revendedora crea su acceso la primera vez con su código personal: así nadie puede entrar con el teléfono de otra y cargarle pedidos a crédito. Envíelo solo a su celular. Si una revendedora no puede entrar (olvidó la clave u otra persona usó su número), restablezca su acceso en <a href="#/clientes-historial">Clientes web › Historial de clientes</a>: vuelve a entrar con su código personal, y cada pedido anterior regresa a su cuenta cuando abre el enlace de seguimiento de ese pedido.</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:flex-start"><div class="form-group" style="flex:1;min-width:220px"><input class="input" v-model="qRev" maxlength="60" placeholder="Buscar por nombre o celular" @keydown.enter.prevent></div><a class="btn btn-light" href="/app/#/contactos/revendedoras">Ver saldos de todas</a></div>
        <div class="table-wrap"><table class="table"><tr><th>Revendedora</th><th>Celular</th><th>Lista de precios</th><th>Código personal</th><th>Acceso</th><th></th></tr>
          <tr v-for="r in revsFiltradas" :key="r.contacto_id"><td>{{r.nombre}}</td><td>{{r.telefono}}</td><td>{{r.lista || 'General'}}</td><td><b style="font-family:monospace;letter-spacing:1px">{{r.codigo}}</b></td><td>{{r.con_acceso ? 'Ya entró' : 'Pendiente'}}</td>
            <td><a class="btn btn-light" :href="waRevendedora(r)" target="_blank" rel="noopener">Enviar por WhatsApp</a> <a class="btn btn-light" :href="urlEstadoCuenta(r.contacto_id)">Estado de cuenta</a> <a class="btn btn-light" :href="'#/pedidos?contacto_id=' + r.contacto_id">Pedidos</a></td></tr>
          <tr v-if="revs && !revsFiltradas.length"><td colspan="6">No hay contactos tipo cliente con celular. Regístrelos en <a href="/app/#/contactos">Contactos</a>.</td></tr>
          <tr v-if="!revs"><td colspan="6">Cargando…</td></tr></table></div>
      </section>
      <p class="fis-inline" style="margin-top:12px" v-if="tab!=='publicar'"><button class="btn" type="submit" :disabled="guardando">Guardar</button></p>
    </form>
  </div>
  <div v-else class="fis-cargando">Cargando…</div>`,
  setup() { return { sesion, urlEstadoCuenta }; },
};
