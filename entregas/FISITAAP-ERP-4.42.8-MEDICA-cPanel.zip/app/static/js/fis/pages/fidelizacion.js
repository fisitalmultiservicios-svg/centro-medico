// FISITAAP › Fidelización (tenant_loyalty_v12 + qa180_loyalty_manual + r2_gift_form del zip): cabecera de beneficios, guía de
// uso, tarjeta de regalo, el programa (puntos por monto comprado) con su canje, el progreso de clientes y las tarjetas recientes.
// Usa el programa de puntos y las tarjetas de regalo del ERP.
// 3.87: la caja ('pos') ve el programa, el progreso de clientes y valida tarjetas; cambiar el programa, el ajuste manual de puntos,
// la tarjeta promocional (sin cobro) y la lista de tarjetas son de quien administra los ítems ('catalogos'), como en el servidor.
import { api, toast, hoy, sumarMeses } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { cfg: null, clientes: [], tarjetas: [], regalo: { beneficiario: '', monto: '', vence: sumarMeses(hoy(), 12) }, canje: { codigo: '', resultado: null }, ajuste: { quien: '', puntos: 0, motivo: '' }, guardando: false }; },
  computed: { gestiona() { return sesion.puede('catalogos'); } },
  methods: {
    dinero, fechaCorta,
    async cargar() {
      try { const [c, l, t] = await Promise.all([api('/api/fidelizacion/config'), api('/api/fidelizacion/clientes'), this.gestiona ? api('/api/tarjetas') : Promise.resolve([])]); this.cfg = c; this.clientes = l; this.tarjetas = t.slice(0, 30); }
      catch (e) { toast(e.message, 'err'); }
    },
    async guardar() { this.guardando = true; try { this.cfg = await api('/api/fidelizacion/config', { method: 'PUT', body: this.cfg }); toast('Programa de fidelización actualizado.', 'ok'); } catch (e) { toast(e.message, 'err'); } this.guardando = false; },
    async crearRegalo() {
      const r = this.regalo; if (!(+r.monto > 0)) return toast('Indique el valor de regalo.', 'err'); if (!r.vence || r.vence < hoy()) return toast('Revisa la fecha de vencimiento.', 'err');
      try { const t = await api('/api/tarjetas', { method: 'POST', body: { monto: +r.monto, comprador: '', beneficiario: r.beneficiario, telefono: '', mensaje: '', meses_vigencia: 0, codigo: null } }); toast('Tarjeta de regalo creada: ' + t.codigo + '. El cliente puede usar su código en un pedido web o presentarla en tienda.', 'ok'); this.regalo = { beneficiario: '', monto: '', vence: sumarMeses(hoy(), 12) }; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async canjear() {
      const c = this.canje.codigo.trim().toUpperCase(); if (!c) return toast('El código del premio no es válido.', 'err');
      try { this.canje.resultado = await api('/api/tarjetas/' + encodeURIComponent(c)); if (!this.canje.resultado.activa) toast('Este premio ya fue utilizado o no está disponible.', 'err'); else toast('Tarjeta válida con saldo ' + dinero(this.canje.resultado.saldo) + '. Para descontarla, cóbrela como medio de pago en la caja.', 'ok'); }
      catch (e) { this.canje.resultado = null; toast('El premio no pertenece a esta tienda.', 'err'); }
    },
    async registrarAjuste() {
      const a = this.ajuste; if (!(+a.puntos)) return toast('Indique los puntos (negativo para quitar)', 'err'); if (!(a.motivo || '').trim()) return toast('Escriba el motivo', 'err');
      const tel = String(a.quien || '').replace(/\D/g, ''); if (tel.length !== 8) return toast('Escriba el teléfono del cliente (8 dígitos)', 'err');
      try { await api('/api/fidelizacion/ajuste', { method: 'POST', body: { cliente_id: null, telefono: tel, puntos: +a.puntos, motivo: a.motivo.trim() } }); toast('Ajuste registrado', 'ok'); this.ajuste = { quien: '', puntos: 0, motivo: '' }; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    estadoTarjeta(t) { if (!t.activa) return 'anulada'; if (t.vence && t.vence < hoy()) return 'vencida'; return t.saldo > 0 ? 'available' : 'used'; },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="r17-benefits-head"><span class="eyebrow">CLIENTES QUE REGRESAN</span><h2>Premia la confianza de tus clientes</h2><p>Configura una meta, define el premio y consulta sus avances. Las tarjetas de regalo mantienen un saldo independiente de los puntos.</p><nav class="r17-benefits-nav"><a class="btn btn-light" href="/app/#/contactos">Ver clientes</a><a class="btn btn-light" href="#/promociones">Promociones</a></nav></section>
    <section class="card admin-card"><h2>Cómo usar Fidelización</h2><details><summary>Configurar, acumular y canjear</summary><ol><li><strong>Elige la regla.</strong> Puntos por cada ₡1.000 de compra y el valor de cada punto al canjear.</li><li><strong>Elige el premio.</strong> Los puntos se canjean como descuento en la caja y en el carrito; las tarjetas de regalo son un saldo aparte.</li><li><strong>Identifica al cliente en la venta.</strong> Consumidor final no acumula beneficios. En la caja los puntos se acreditan al cobrar con cliente identificado; en línea, al entregar el pedido, por teléfono.</li><li><strong>Consulta el progreso.</strong> El cliente ve sus puntos en su cuenta de la página; aquí ves los saldos y haces ajustes con motivo.</li><li><strong>Canjea una vez.</strong> Valida aquí el código de una tarjeta de regalo; el descuento se aplica al cobrar en la caja o en el pedido web.</li></ol></details></section>
    <section class="card admin-card" style="margin-bottom:20px" v-if="gestiona"><h2>Tarjeta de regalo promocional</h2><p>Un saldo para las compras del cliente. Se usa como medio de pago en la caja y en el catálogo en línea.</p><form @submit.prevent="crearRegalo"><div class="split"><div class="form-group"><label>Cliente (beneficiario)</label><input class="input" v-model="regalo.beneficiario" maxlength="80"></div><div class="form-group"><label>Valor de regalo</label><input class="input" type="number" step=".01" min="1" v-model="regalo.monto" required></div><div class="form-group"><label>Vence</label><input class="input" type="date" v-model="regalo.vence" required></div></div><button class="btn">Crear tarjeta de regalo</button></form></section>
    <div class="split" v-if="cfg">
      <form class="card admin-card" @submit.prevent="guardar"><h2>Programa global</h2><fieldset :disabled="!gestiona" style="border:0;padding:0;margin:0;min-width:0">
        <div class="form-group"><label>Nombre</label><input class="input" v-model="cfg.nombre" maxlength="30" placeholder="Puntos" required></div>
        <div class="form-group"><label>Modo</label><select class="input" disabled><option>Puntos por monto comprado</option></select></div>
        <div class="split"><div class="form-group"><label>Puntos por cada ₡1.000</label><input class="input" type="number" step="0.5" min="0" v-model="cfg.puntos_por_mil" required></div><div class="form-group"><label>Canje mínimo (puntos)</label><input class="input" type="number" step="1" min="0" v-model="cfg.minimo_canje" required></div></div>
        <div class="split"><div class="form-group"><label>Valor de cada punto (₡)</label><input class="input" type="number" step="1" min="0" v-model="cfg.valor_punto" required></div><div class="form-group"><label>Máximo de la compra con puntos (%)</label><input class="input" type="number" step="1" min="1" max="100" v-model="cfg.maximo_pct" required></div></div>
        <label><input type="checkbox" v-model="cfg.activo"> Programa activo</label><button v-if="gestiona" class="btn btn-block" style="margin-top:14px" :disabled="guardando">Guardar programa</button></fieldset><p v-if="!gestiona" class="muted">El programa lo cambia quien administra los ítems.</p></form>
      <section class="card admin-card"><h2>Canjear premio</h2><p class="muted">Escribe el código de la tarjeta de regalo del cliente para validarla.</p><form class="loyalty-redeem-form" @submit.prevent="canjear"><div class="form-group"><label>Código del premio</label><input class="input" v-model="canje.codigo" required maxlength="20" autocomplete="off" style="text-transform:uppercase"></div><button class="btn btn-block">Validar</button></form>
        <p v-if="canje.resultado"><strong>{{canje.resultado.codigo}}</strong> · saldo {{dinero(canje.resultado.saldo)}}{{canje.resultado.vence ? ' · vence ' + fechaCorta(canje.resultado.vence) : ''}}{{canje.resultado.beneficiario ? ' · ' + canje.resultado.beneficiario : ''}}</p>
        <template v-if="gestiona"><hr><h3>Ajuste manual de puntos</h3><form @submit.prevent="registrarAjuste"><div class="form-group"><label>Teléfono del cliente</label><input class="input" v-model="ajuste.quien" maxlength="12" inputmode="numeric"></div><div class="split"><div class="form-group"><label>Puntos (negativo para quitar)</label><input class="input" type="number" step="1" v-model="ajuste.puntos"></div><div class="form-group"><label>Motivo</label><input class="input" v-model="ajuste.motivo" maxlength="120"></div></div><button class="btn btn-light btn-block">Registrar ajuste</button></form></template>
        <hr><h3>Cómo se acredita</h3><p class="muted">Solo suma cuando el pedido queda entregado o la venta se cobra con cliente. Los pedidos cancelados no suman.</p></section>
    </div>
    <section class="card admin-card" style="margin-top:20px"><h2>Progreso de clientes</h2><div class="table-wrap"><table class="table"><tr><th>Cliente</th><th>Puntos</th><th>Ganados</th><th>Canjeados</th><th>Valor</th></tr>
      <tr v-for="c in clientes" :key="c.quien"><td>{{c.nombre || '—'}}<br><small>{{c.quien.startsWith('cliente:') ? 'cliente de la empresa' : c.quien}}</small></td><td>{{Math.round(c.saldo)}}</td><td>{{Math.round(c.ganados)}}</td><td>{{Math.round(c.canjeados)}}</td><td>{{dinero((+c.saldo || 0) * (cfg ? +cfg.valor_punto || 0 : 0))}}</td></tr>
      <tr v-if="!clientes.length"><td colspan="5">Todavía no hay movimientos.</td></tr></table></div></section>
    <section class="card admin-card" style="margin-top:20px" v-if="gestiona"><h2>Tarjetas de regalo recientes</h2><div class="table-wrap"><table class="table"><tr><th>Código</th><th>Cliente</th><th>Premio</th><th>Estado</th><th>Vence</th></tr>
      <tr v-for="t in tarjetas" :key="t.id"><td><code>{{t.codigo}}</code></td><td>{{t.beneficiario || '—'}}</td><td>{{dinero(t.saldo)}} de {{dinero(t.monto_inicial)}}</td><td><span class="status" :class="{'status-off': estadoTarjeta(t) !== 'available'}">{{estadoTarjeta(t)}}</span></td><td>{{t.vence ? fechaCorta(t.vence) : 'No vence'}}</td></tr>
      <tr v-if="!tarjetas.length"><td colspan="5">Todavía no hay premios.</td></tr></table></div></section>
  </div>`,
};
