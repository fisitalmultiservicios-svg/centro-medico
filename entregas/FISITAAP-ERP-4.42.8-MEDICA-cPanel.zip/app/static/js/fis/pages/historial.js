// FISITAAP › Entregas › Historial (r2_drivers del zip, sección historial): entregas de todas las sucursales por período y estado,
// con el pedido, el motorizado, el estado, la fecha y el pago al motorizado; debajo, las liquidaciones hechas.
// 3.87: las liquidaciones hechas solo para quien administra Entregas ('catalogos', como el servidor); la caja ve las entregas.
import { api, toast, hoy, sumarDias } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta } from '../ui.js';

const ESTADOS = [['pendiente', 'Pendiente de despachar'], ['liberada', 'Liberada'], ['asignada', 'Asignada'], ['aceptada', 'Aceptada'], ['recogida', 'Recogida'], ['en_camino', 'En camino'], ['entregada', 'Entregada'], ['incidencia', 'Con incidencia'], ['cancelada', 'Cancelada']];

export default {
  props: ['params'],
  data() { return { sesion, desde: sumarDias(hoy(), -29), hasta: hoy(), estado: '', lista: [], liquidaciones: [], ESTADOS }; },
  methods: {
    dinero, fechaCorta,
    async cargar() { try { this.lista = await api('/api/entregas?desde=' + this.desde + '&hasta=' + this.hasta + (this.estado ? '&estado=' + this.estado : '')); this.liquidaciones = sesion.puede('catalogos') ? await api('/api/entregas/liquidaciones') : []; } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="card admin-card" data-live-region="delivery-history"><p>Entregas de todas las sucursales, incluidas las pendientes y finalizadas. Express pendientes muestra las que siguen activas.</p>
      <form @submit.prevent="cargar"><div class="split"><div class="form-group"><label>Desde</label><input class="input" type="date" v-model="desde" required></div><div class="form-group"><label>Hasta</label><input class="input" type="date" v-model="hasta" required></div></div><label>Estado<select class="input" v-model="estado"><option value="">Todos</option><option v-for="e in ESTADOS" :key="e[0]" :value="e[0]">{{e[1]}}</option></select></label><button class="btn btn-light">Filtrar</button></form>
      <div class="table-wrap"><table class="table"><tr><th>Pedido</th><th>Sucursal</th><th>Motorizado</th><th>Estado</th><th>Fecha</th><th>Pago al motorizado</th></tr>
        <tr v-for="r in lista" :key="r.id" :data-express-job="r.id"><td><a :href="'#/pedido/' + r.pedido_id">{{r.pedido_numero}} · Ver bitácora</a></td><td>{{sesion.sucursalActual ? sesion.sucursalActual.nombre : 'Principal'}}</td><td>{{r.motorizado || 'Sin asignar'}}</td><td>{{r.estado_nombre}}</td><td>{{fechaCorta(r.creada)}}</td><td>{{dinero(r.pago_motorizado)}}</td></tr>
        <tr v-if="!lista.length"><td colspan="6">No hay entregas con estos filtros.</td></tr></table></div></section>
    <section class="card admin-card" style="margin-top:20px" v-if="sesion.puede('catalogos')"><h2>Liquidaciones hechas</h2><div class="table-wrap"><table class="table"><tr><th>Fecha</th><th>Motorizado</th><th>Período</th><th>Entregas</th><th>Total</th><th>Nota</th></tr>
      <tr v-for="l in liquidaciones" :key="l.id"><td>{{fechaCorta(l.fecha)}}</td><td>{{l.motorizado}}</td><td>{{fechaCorta(l.desde)}} – {{fechaCorta(l.hasta)}}</td><td>{{l.entregas}}</td><td>{{dinero(l.total)}}</td><td>{{l.nota}}<span v-if="l.usuario"> · {{l.usuario}}</span></td></tr>
      <tr v-if="!liquidaciones.length"><td colspan="6">Todavía no hay liquidaciones.</td></tr></table></div></section>
  </div>`,
};
