// FISITAAP › Administración › Generales (qa180_settings del zip): nombre comercial, correo, teléfono, WhatsApp, cédula, dirección,
// horario, mapa, logo, catálogo o menú, mensaje al suspender, redes, métodos de pago, formas de entrega, precios con IVA,
// recepción de pedidos web. Edita el negocio público del ERP y los ajustes propios de FISITAAP.
// 4.40: «Mostrar agotado según existencias» (n.agotado_auto) debajo de la caja que recibe los pedidos, con su vista previa y avisos.
// 4.40: en el programa de escritorio no se muestra la casilla ni se pide la vista previa («Esto se hace en la página web.»); el aviso
// «No hay una bodega activa…» sale solo con la casilla marcada.
import { api, toast, red } from '/js/api.js';   // 4.5: red.enLinea para el logo sin conexión
import { cargarNegocio, guardarNegocio, DIAS } from '/js/pages/fisitaap/_negocio.js';
import { avisosActivos, permisoAvisos, activarAvisos, desactivarAvisos } from '/js/avisos.js';
import { sesion } from '../sesion.js';

const METODOS = ['SINPE Móvil', 'Efectivo', 'Tarjeta al recibir', 'Transferencia'];

export default {
  props: ['params'],
  data() { return { sesion, n: null, a: null, DIAS, METODOS, guardando: false, avisos: avisosActivos(), permiso: permisoAvisos(), terms: [], tl: { key: null, user: null, password: null }, logo: null, logoPendiente: false, atiende: '', guardandoAtiende: false, atiendeElegido: false, vista: null, vistaError: false, verCuales: false }; },   // 4.5: logo por cargarLogo; 4.32: quién atiende los pedidos en línea (aparte del guardado general); 4.40: vista previa del agotado según existencias
  computed: {
    // 4.40: textos del agotado según existencias; la bodega es la de la caja que recibe los pedidos (la dice la vista previa)
    bodegaAgotado() { const b = this.vista && this.vista.bodega; return !b ? '' : typeof b === 'string' ? b : (b.nombre || ''); },   // 4.40: llega el nombre o {id, nombre}
    ayudaAgotado() { return 'Cuando un producto llega a 0 en la bodega de la caja que recibe los pedidos' + (this.bodegaAgotado ? ' (' + this.bodegaAgotado + ')' : '') + ', la página lo muestra agotado y no deja pedirlo. Cuando entran unidades, queda disponible de nuevo por sí solo. La casilla «Agotado por ahora» de cada producto sigue sirviendo para agotarlo aunque tenga existencias. Un combo de Ventas en línea › Catálogo web › Combos se agota cuando las unidades de uno de sus componentes no alcanzan para armar uno; un plato con receta, cuando no alcanza uno de sus ingredientes. Los servicios, los productos sin control de inventario y los que permiten vender en negativo no se agotan solos.'; },   // 4.40: los combos de Catálogo web › Combos tienen receta y se agotan por sus componentes (decisión de Norman, 17/11/2026)
    textoVista() { const v = this.vista; if (!v || !v.bodega) return ''; const a = +v.agotarian || 0, t = +v.total || 0; return 'Con las existencias de ahora, ' + a + ' de ' + t + (t === 1 ? ' producto del catálogo' : ' productos del catálogo') + (a === 1 ? ' se mostraría agotado.' : ' se mostrarían agotados.'); },
    textoSinRegistro() { const v = this.vista; const m = v && v.bodega ? +v.sin_registro || 0 : 0; if (!m) return ''; return m === 1 ? '1 producto no tiene existencias registradas en ' + this.bodegaAgotado + ': seguirá disponible hasta que se le cargue una cantidad.' : m + ' productos no tienen existencias registradas en ' + this.bodegaAgotado + ': seguirán disponibles hasta que se les cargue una cantidad.'; },
    masCuales() { const v = this.vista; return v && Array.isArray(v.ejemplos) ? Math.max(0, (+v.agotarian || 0) - v.ejemplos.length) : 0; },
    entregas: {
      get() { const n = this.n; return n ? [n.acepta_domicilio ? 'delivery' : null, n.acepta_recoger ? 'pickup' : null, n.acepta_coordinado ? 'coordinated' : null].filter(Boolean) : []; },
      set(v) { this.n.acepta_domicilio = v.includes('delivery'); this.n.acepta_recoger = v.includes('pickup'); this.n.acepta_coordinado = v.includes('coordinated'); },
    },
    cedula() { return (sesion.empresa && (sesion.empresa.cedula || sesion.empresa.identificacion)) || ''; },
    enLinea() { return red.enLinea; },   // 4.5: para reintentar el logo al volver la conexión (antes leía un logo_url de la sesión que no existe: nunca se mostraba)
    // 3.87: el SINPE, la tarjeta (Tilopay) y el correo de aviso los cambia solo quien configura la empresa (el servidor lo exige)
    cobros() { return sesion.puede('configurar'); },
    // 4.32: «Los pedidos en línea los atiende». En la página web solo si hay una computadora conectada; en el programa (con los pedidos en línea) solo el aviso
    enPrograma() { const i = sesion.empresaInfo; return !!(i && i.es_local); },   // 4.40: en el programa la casilla del agotado no se muestra (NegocioPublico no viaja); en cualquier programa, no solo con pedidos_programa
    enProg() { const i = sesion.empresaInfo; return !!(i && i.es_local && i.pedidos_programa); },
    opcionesAtiende() { const n = this.n; return n && Array.isArray(n.atiende_opciones) ? n.atiende_opciones : []; },
    mostrarAtiende() { const i = sesion.empresaInfo; return !(i && i.es_local) && (this.opcionesAtiende.length > 0 || !!(this.n && this.n.atiende_terminal)); },
    avisoAtiende() { return this.mostrarAtiende && !this.atiende && !this.atiendeElegido && this.opcionesAtiende.length > 0; },
  },
  methods: {
    // 4.5: logo de la empresa; sin conexión no se pide (ni error en consola ni aviso) y se reintenta al volver la red; sin logo el servidor responde 204
    async cargarLogo() {
      if (!red.enLinea) { this.logo = null; this.logoPendiente = true; return; }
      this.logoPendiente = false;
      try { const r = await fetch('/api/empresa/logo', { cache: 'no-store' }); this.logo = r.status === 200 ? '/api/empresa/logo?v=' + Date.now() : null; } catch { this.logo = null; this.logoPendiente = true; }
    },
    async cargar() {
      try { this.n = await cargarNegocio(); this.a = await api('/api/fisitaap/ajustes'); this.atiende = this.n.atiende_terminal || ''; this.atiendeElegido = this.leerElegido(); } catch (e) { toast(e.message, 'err'); }
      try { const r = await api('/api/registros/pos_config'); this.terms = ((r && r.datos && r.datos.terminales) || []).filter(t => t && t.id); } catch { this.terms = []; }
      this.cargarVista();
    },
    // 4.40: vista previa del agotado según existencias; sin el permiso del catálogo o si no responde, la pantalla sigue sin ella
    async cargarVista() {
      this.verCuales = false;
      if (this.enPrograma || !sesion.puede || !sesion.puede('catalogos')) { this.vista = null; return; }   // 4.40: en el programa no se pide
      this.vistaError = false;
      try { this.vista = await api('/api/pedidos/catalogo/agotado-vista'); } catch { this.vista = null; this.vistaError = true; }   // 4.40: si falla, se avisa
    },
    // 4.32: el aviso de elegir se oculta cuando esta persona ya eligió (aunque haya elegido «La página web»); solo una comodidad de este navegador
    claveAtiende() { return 'fis_atiende_elegido_' + (sesion.empresa_id || ''); },
    leerElegido() { try { return localStorage.getItem(this.claveAtiende()) === '1'; } catch { return false; } },
    async cambiarAtiende(v) {
      if (this.guardandoAtiende) return;
      this.atiende = v === undefined || v === null ? this.atiende : v;
      const antes = (this.n && this.n.atiende_terminal) || '';
      this.guardandoAtiende = true;
      try {
        const r = await api('/api/pedidos/negocio/atiende', { method: 'PUT', body: { terminal: this.atiende ? +this.atiende : null } });
        this.n.atiende_terminal = r.atiende_terminal || null; this.n.atiende_nombre = r.atiende_nombre || ''; this.atiende = r.atiende_terminal || '';
        if (sesion.negocio) { sesion.negocio.atiende_terminal = this.n.atiende_terminal; sesion.negocio.atiende_nombre = this.n.atiende_nombre; }
        this.atiendeElegido = true; try { localStorage.setItem(this.claveAtiende(), '1'); } catch { /* sin almacenamiento */ }
        toast('Datos guardados.', 'ok');
      } catch (e) { this.atiende = antes; toast(e.message, 'err'); }
      this.guardandoAtiende = false;
    },
    toggleDia(i) { this.n.horarios[i] = this.n.horarios[i] ? null : ['08:00', '20:00']; },
    async guardar() {
      const n = this.n; if (!(n.nombre || '').trim() && !sesion.nombreNegocio) return toast('Revisa el nombre y el correo del negocio.', 'err');
      if (!this.entregas.length || !this.a.metodos_pago.length) return toast('Selecciona al menos un método de pago y una forma de entrega.', 'err');
      if (!n.pago_sinpe && this.a.metodos_pago.includes('SINPE Móvil') && !n.sinpe_numero) { /* SINPE anunciado sin número: se avisa */ }
      this.guardando = true;
      try {
        this.n = await guardarNegocio(n, { tilopay_key: this.tl.key, tilopay_user: this.tl.user, tilopay_password: this.tl.password, agotado_auto: !!n.agotado_auto }); this.tl = { key: null, user: null, password: null };   // 4.40: solo esta pantalla manda la opción
        this.a = await api('/api/fisitaap/ajustes', { method: 'PUT', body: this.a });
        await sesion.recargarNegocio(); toast('Datos guardados. La identificación se imprime en los nuevos recibos.', 'ok');
        this.cargarVista();   // 4.40: si cambió la caja, cambia la bodega de la vista previa
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async cambiarAvisos(v) {
      if (v) { const ok = await activarAvisos(); this.permiso = permisoAvisos(); this.avisos = ok; toast(ok ? 'Avisos activados en este dispositivo' : 'No se pudo activar: revise los permisos del navegador', ok ? 'ok' : 'err'); }
      else { desactivarAvisos(); this.avisos = false; toast('Avisos desactivados en este dispositivo', 'ok'); }
    },
  },
  watch: { enLinea(v) { if (v && this.logoPendiente) this.cargarLogo(); } },   // 4.5: reintento del logo al volver la conexión
  created() { this.cargar(); this.cargarLogo(); },
  template: `
  <section class="card admin-card" v-if="n && a"><form @submit.prevent="guardar">
    <div class="form-group"><label>Nombre comercial</label><input class="input" v-model="n.nombre" maxlength="80" :placeholder="sesion.nombreNegocio"></div>
    <div class="split"><div class="form-group"><label>Correo</label><input class="input" type="email" v-model="a.correo_contacto" maxlength="190"></div><div class="form-group"><label>Teléfono</label><input class="input" v-model="n.telefono" maxlength="12" inputmode="numeric"></div></div>
    <div class="form-group"><label>WhatsApp de pedidos</label><input class="input" v-model="n.whatsapp" maxlength="12" inputmode="numeric"></div>
    <div class="form-group"><label>Cédula del negocio</label><input class="input" :value="cedula" readonly></div><label><input type="checkbox" v-model="a.cedula_requerida"> Identificación requerida en los datos del negocio</label><p>Esta identificación se muestra en recibos y la factura electrónica la toma de la empresa en el ERP.</p>
    <div class="form-group"><label>Dirección</label><input class="input" v-model="n.direccion" maxlength="200"></div>
    <div class="form-group"><label>Horario</label><input class="input" v-model="a.horario_texto" maxlength="1000" placeholder="Lunes a sábado de 8 a. m. a 8 p. m."></div>
    <div class="qa180-modifier-list"><label v-for="(d, i) in DIAS" :key="d"><input type="checkbox" :checked="!!n.horarios[i]" @change="toggleDia(i)"> {{d}}<template v-if="n.horarios[i]"> <input class="input compact" type="time" v-model="n.horarios[i][0]"> a <input class="input compact" type="time" v-model="n.horarios[i][1]"></template><small v-else> cerrado</small></label></div>
    <label>Mapa de Google (iframe)<textarea class="input" rows="3" v-model="a.mapa_embed" maxlength="5000"></textarea></label>
    <label>Logo de tu tienda<img v-if="logo" class="r2-editor-image" :src="logo" alt="Logo actual"><small class="muted">Logo: PNG con fondo transparente, 600 × 200 px (horizontal). En la página se muestra a 48 px de alto; un logo cuadrado también sirve.</small><a class="btn btn-light" href="/app/#/configuracion/marcas">Cambiar el logo en el ERP</a></label>
    <label>Catálogo o menú<select class="input" v-model="n.presentacion"><option value="catalogo">Catálogo</option><option value="menu">Menú</option></select></label>
    <div class="form-group"><label>Mensaje al suspender el negocio</label><input class="input" v-model="a.mensaje_suspendido" maxlength="1000"></div>
    <label>Estado<select class="input" v-model="n.abierto_manual"><option :value="null">Según el horario</option><option :value="true">Abierto siempre</option><option :value="false">Suspendido por ahora</option></select></label>
    <div class="form-group"><label>Facebook</label><input class="input" type="url" v-model="n.redes.facebook" maxlength="1000"></div>
    <div class="form-group"><label>Instagram</label><input class="input" v-model="n.redes.instagram" maxlength="1000"></div>
    <div class="form-group"><label>TikTok</label><input class="input" type="url" v-model="a.tiktok" maxlength="1000"></div>
    <fieldset><legend>Métodos de pago</legend><label v-for="m in METODOS" :key="m"><input type="checkbox" :value="m" v-model="a.metodos_pago"> {{m}}</label></fieldset>
    <fieldset><legend>Formas de entrega</legend><label><input type="checkbox" value="delivery" v-model="entregas"> Envío</label><label><input type="checkbox" value="pickup" v-model="entregas"> Recoger</label><label><input type="checkbox" value="coordinated" v-model="entregas"> Coordinado</label></fieldset>
    <div class="split"><div class="form-group"><label>Costo de envío a domicilio (con IVA)</label><input class="input" type="number" min="0" step="100" v-model="n.costo_envio"></div><div class="form-group"><label>Pedido mínimo (0 = sin mínimo)</label><input class="input" type="number" min="0" step="500" v-model="n.minimo_pedido"></div></div>
    <label><input type="checkbox" v-model="a.precios_con_iva"> Los precios del catálogo incluyen IVA</label><p>Esta opción afecta nuevos consumos. Las cuentas abiertas conservan los importes ya registrados.</p>
    <label>Pedidos web<select class="input" v-model="a.pedidos_aceptacion"><option :value="true">Requieren recibir / aceptar</option><option :value="false">Recibir y enviar comanda automáticamente</option></select></label><p>La opción se aplica a pedidos nuevos. La impresión usa la caja elegida abajo.</p>
    <label>Caja que recibe los pedidos<select class="input" v-model="n.terminal_id"><option :value="null">— La primera caja —</option><option v-for="t in terms" :key="t.id" :value="t.id">{{t.nombre}}</option></select></label>
    <label v-if="mostrarAtiende" data-atiende-web>Los pedidos en línea los atiende<select class="input" v-model="atiende" :disabled="!cobros || guardandoAtiende" @change="cambiarAtiende($event.target.value)"><option value="">La página web</option><option v-for="o in opcionesAtiende" :key="o.terminal" :value="o.terminal">El programa de «{{o.nombre}}»</option></select><small class="muted">Los pedidos aceptados pasan a la caja de esa computadora: su comanda sale allá y se cobran allá. En la página web se siguen viendo y aceptando.</small></label>
    <p v-if="avisoAtiende" class="muted" data-atiende-aviso>Hay una computadora conectada y todavía no ha elegido quién atiende los pedidos en línea. Hoy los atiende la página web.</p>
    <div v-if="enProg" class="form-group" data-atiende-programa><label>Los pedidos en línea los atiende</label><p class="muted">Esto se hace en la página web.</p></div>
    <div v-if="enPrograma" class="form-group" data-agotado-auto-programa><label>Mostrar agotado según existencias</label><p class="muted">Esto se hace en la página web.</p></div>
    <div v-else class="form-group" data-agotado-auto><label><input type="checkbox" v-model="n.agotado_auto"> Mostrar agotado según existencias</label><p class="muted">{{ayudaAgotado}}</p>
      <p v-if="textoVista" data-agotado-vista>{{textoVista}} <a href="#/configuracion" v-if="vista.agotarian > 0 && vista.ejemplos && vista.ejemplos.length" @click.prevent="verCuales = !verCuales">{{verCuales ? 'Ocultar' : 'Ver cuáles'}}</a></p>
      <ul class="muted" v-if="verCuales && vista && vista.ejemplos"><li v-for="(x, i) in vista.ejemplos" :key="i">{{x}}</li><li v-if="masCuales">y {{masCuales}} más</li></ul>
      <p v-if="textoSinRegistro" class="muted">{{textoSinRegistro}}</p>
      <p v-if="vistaError" class="alert fis-pendiente" data-agotado-vista-error>No se pudo calcular la vista previa en este momento. Vuelva a abrir esta pantalla para intentarlo de nuevo.</p>
      <p v-if="n.agotado_auto && vista && !vista.bodega" class="alert fis-pendiente" data-agotado-sin-bodega>No hay una bodega activa para revisar existencias. Elija una en Punto de venta › Configuración, en la caja que recibe los pedidos.</p>
      <p v-if="n.agotado_auto && vista && vista.pruebas" class="alert fis-pendiente" data-agotado-pruebas>La empresa está en ambiente de pruebas de Hacienda: las ventas no rebajan existencias, así que el catálogo no cambiará con ventas de prueba.</p>
      <p v-if="n.agotado_auto" class="muted" data-agotado-programa>Si también se vende en el programa de escritorio: las ventas del programa se reflejan aquí cuando suben a la web. Las compras, ajustes y traslados de inventario deben hacerse en la web; los que se hacen en el programa no llegan al catálogo.</p></div>
    <fieldset :disabled="!cobros"><legend>SINPE Móvil con comprobante</legend><p v-if="!cobros" class="muted">Los datos de cobro, el correo de aviso y el dominio solo los cambia el administrador de la empresa.</p><label><input type="checkbox" v-model="n.pago_sinpe"> Ofrecer SINPE Móvil en el carrito</label><div class="split"><div class="form-group"><label>Número SINPE (8 dígitos)</label><input class="input" v-model="n.sinpe_numero" maxlength="12" inputmode="numeric"></div><div class="form-group"><label>A nombre de</label><input class="input" v-model="n.sinpe_nombre" maxlength="80"></div></div></fieldset>
    <fieldset><legend>Pago con tarjeta en línea (Tilopay)</legend><label><input type="checkbox" v-model="n.pago_tarjeta" :disabled="!cobros"> Ofrecer «pagar con tarjeta» en el carrito</label><div class="split"><div class="form-group"><label>Llave (key)</label><input class="input" v-model="tl.key" :disabled="!cobros" maxlength="200" autocomplete="off" :placeholder="n.tilopay && n.tilopay.llave ? 'Guardada: ' + n.tilopay.llave : 'Sin llave guardada'"></div><div class="form-group"><label>Usuario del API</label><input class="input" v-model="tl.user" :disabled="!cobros" maxlength="120" autocomplete="off" :placeholder="n.tilopay && n.tilopay.usuario_guardado ? 'Guardado' : ''"></div><div class="form-group"><label>Clave del API</label><input class="input" type="password" v-model="tl.password" :disabled="!cobros" maxlength="200" autocomplete="new-password" :placeholder="n.tilopay && n.tilopay.clave_guardada ? 'Guardada' : ''"></div></div><label><input type="checkbox" v-model="n.correo_cliente"> Enviar correos al cliente por cada paso del pedido</label></fieldset>
    <fieldset class="r18-seller-setting"><legend>Avisos de pedido nuevo</legend><label><input type="checkbox" :checked="avisos" @change="cambiarAvisos($event.target.checked)"> Avisar en este dispositivo (sonido y notificación)</label><p>Con el sistema abierto, aunque esté en otra pestaña, cada pedido nuevo suena y muestra una notificación que abre Pedidos.<span v-if="permiso === 'denied'"> El navegador tiene bloqueadas las notificaciones de este sitio.</span></p><div class="form-group"><label>Correo de aviso por pedido (vacío = el de la empresa)</label><input class="input" type="email" v-model="n.correo_aviso" :disabled="!cobros" maxlength="120"></div></fieldset>
    <button class="btn" :disabled="guardando">Guardar datos</button> <a class="btn btn-light" href="#/publicar">Publicar y dominio</a> <a class="btn btn-light" href="#/contenido">Colores y diseño público</a></form></section>
  <div v-else class="fis-cargando">Cargando…</div>`,
};
