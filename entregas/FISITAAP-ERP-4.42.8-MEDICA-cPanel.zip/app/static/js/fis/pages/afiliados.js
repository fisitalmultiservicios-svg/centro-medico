// FISITAAP › Entregas › Afiliados e Invitaciones (r2_drivers del zip): la tabla de motorizados con contacto, estado y acciones
// (pausar, activar, bloquear); en Invitaciones, el formulario para invitar y la lista de los que aún no han entrado. En
// Afiliados también la liquidación de lo que se les debe (op180_affiliate_finance). Son los motorizados del ERP.
// 3.87: invitar, pausar y bloquear piden 'catalogos' (como el servidor) y liquidar, 'gastos' (pago a terceros).
import { api, toast, hoy } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { sesion, motos: [], inv: { nombre: '', telefono: '', clave: '', vehiculo: 'moto', pago_entrega: 0 }, pendientes: [], liq: null }; },
  computed: {
    seccion() { return this.params.seccion === 'invitaciones' ? 'invitaciones' : 'afiliados'; },
    filas() { return this.seccion === 'invitaciones' ? this.motos.filter(m => !m.ultimo_acceso) : this.motos; },
  },
  methods: {
    dinero, fechaCorta,
    estadoMoto(m) { return !m.activo ? 'Pausado' : m.ultimo_acceso ? 'Activo' : 'Esperando al motorizado'; },
    async cargar() { try { this.motos = await api('/api/entregas/motorizados'); if (this.seccion === 'afiliados' && sesion.puede('catalogos')) this.pendientes = await api('/api/entregas/liquidaciones/pendientes'); } catch (e) { toast(e.message, 'err'); } },
    async invitar() {
      const i = this.inv; if (!i.nombre.trim() || !i.telefono.trim()) return toast('Nombre y teléfono son obligatorios.', 'err'); if (!/^\d{4,8}$/.test(i.clave)) return toast('Asigne una clave de 4 a 8 dígitos.', 'err');
      try { await api('/api/entregas/motorizados', { method: 'POST', body: { nombre: i.nombre.trim(), telefono: i.telefono.trim(), vehiculo: i.vehiculo, placa: '', activo: true, pago_entrega: +i.pago_entrega || 0, notas: '', clave: i.clave } }); toast('Invitación enviada a ' + i.nombre.trim() + '.', 'ok'); this.inv = { nombre: '', telefono: '', clave: '', vehiculo: 'moto', pago_entrega: 0 }; await this.cargar(); }
      catch (e) { toast(e.message, 'err'); }
    },
    async estado(m, activo) { try { await api('/api/entregas/motorizados/' + m.id, { method: 'PUT', body: { nombre: m.nombre, telefono: m.telefono, vehiculo: m.vehiculo, placa: m.placa || '', activo, pago_entrega: +m.pago_entrega || 0, notas: m.notas || '', clave: null } }); toast('Afiliación actualizada.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    async bloquear(m) { if (!confirm('¿Bloquear a ' + m.nombre + '? Se quita de los motorizados del negocio.')) return; try { const r = await api('/api/entregas/motorizados/' + m.id, { method: 'DELETE' }); toast(r.mensaje || 'Motorizado bloqueado.', 'ok'); await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
    wa(m) { const n = sesion.negocio; const enlace = location.origin + '/motorizado.html' + (n && n.slug ? '#n=' + n.slug : ''); return 'https://wa.me/506' + m.telefono + '?text=' + encodeURIComponent('Hola ' + m.nombre + ', este es su panel de entregas: ' + enlace + ' . Entre con su teléfono y la clave que le dimos.'); },
    async liquidar() { const l = this.liq; try { const r = await api('/api/entregas/liquidaciones', { method: 'POST', body: { motorizado_id: l.p.motorizado_id, hasta: l.hasta, nota: l.nota } }); toast('Liquidado a ' + r.motorizado + ': ' + r.entregas + ' entrega(s), ' + dinero(r.total), 'ok'); this.liq = null; await this.cargar(); } catch (e) { toast(e.message, 'err'); } },
  },
  created() { this.cargar(); },
  template: `
  <div>
    <section class="card admin-card" v-if="seccion === 'invitaciones' && sesion.puede('catalogos')"><form @submit.prevent="invitar"><div class="form-group"><label>Nombre del motorizado</label><input class="input" v-model="inv.nombre" maxlength="60" required></div><div class="form-group"><label>Teléfono (8 dígitos)</label><input class="input" v-model="inv.telefono" maxlength="12" inputmode="numeric" required></div><div class="split"><label>Vehículo<select class="input" v-model="inv.vehiculo"><option value="moto">Motocicleta</option><option value="bici">Bicicleta</option><option value="carro">Carro</option><option value="pie">A pie</option></select></label><div class="form-group"><label>Pago por entrega</label><input class="input" type="number" min="0" step="100" v-model="inv.pago_entrega"></div></div><div class="form-group"><label>Clave para su panel (4 a 8 dígitos)</label><input class="input" type="password" v-model="inv.clave" maxlength="8" inputmode="numeric" autocomplete="new-password" required></div><button class="btn">Crear invitación</button></form><p>El motorizado entra a su panel con su teléfono y la clave; en el celular puede instalarlo como aplicación. Mándele el enlace por WhatsApp desde la tabla.</p></section>
    <section class="card admin-card"><table class="table"><tr><th>Motorizado</th><th>Contacto</th><th>Estado</th><th>Acciones</th></tr>
      <tr v-for="m in filas" :key="m.id"><td>{{m.nombre}}</td><td>{{m.telefono}} · {{m.vehiculo_nombre}}{{m.placa ? ' · ' + m.placa : ''}} · {{dinero(m.pago_entrega)}} por entrega</td><td>{{estadoMoto(m)}}</td><td class="fis-tabla-acciones"><a class="btn btn-light" :href="wa(m)" target="_blank" rel="noopener">WhatsApp</a> <template v-if="sesion.puede('catalogos')"><template v-if="m.ultimo_acceso || !m.activo"><button class="btn btn-light" type="button" @click="estado(m, !m.activo)">{{m.activo ? 'Pausar' : 'Activar'}}</button> </template><button class="btn btn-danger" type="button" @click="bloquear(m)">Bloquear</button></template></td></tr>
      <tr v-if="!filas.length"><td colspan="4">{{seccion === 'invitaciones' ? 'No hay invitaciones pendientes.' : 'Todavía no hay motorizados afiliados.'}}</td></tr></table><a class="btn btn-light" href="#/express-pendientes">Sucursales autorizadas y pedidos express</a></section>
    <section class="card admin-card" style="margin-top:20px" v-if="seccion === 'afiliados' && sesion.puede('catalogos')"><h2>Liquidación a motorizados</h2><p>Entregas hechas que todavía no se han pagado, por motorizado. Liquide cuando les pague.</p>
      <table class="table"><tr><th>Motorizado</th><th>Entregas</th><th>Período</th><th>Total</th><th></th></tr><tr v-for="p in pendientes" :key="p.motorizado_id"><td>{{p.motorizado}}</td><td>{{p.entregas}}</td><td>{{fechaCorta(p.desde)}} – {{fechaCorta(p.hasta)}}</td><td>{{dinero(p.total)}}</td><td><button class="btn btn-light" type="button" v-if="sesion.puede('gastos')" @click="liq = {p, hasta: hoyTexto(), nota: ''}">Liquidar</button></td></tr><tr v-if="!pendientes.length"><td colspan="5">Nada pendiente de liquidar.</td></tr></table>
      <form v-if="liq" @submit.prevent="liquidar" style="margin-top:12px"><h3>Liquidar a {{liq.p.motorizado}} · {{dinero(liq.p.total)}}</h3><div class="split"><div class="form-group"><label>Entregas hasta el</label><input class="input" type="date" v-model="liq.hasta" required></div><div class="form-group"><label>Nota</label><input class="input" v-model="liq.nota" maxlength="200" placeholder="Pagado en efectivo, SINPE…"></div></div><button class="btn">Liquidar</button> <button class="btn btn-light" type="button" @click="liq = null">Cancelar</button></form></section>
  </div>`,
  setup() { return { hoyTexto: hoy }; },
};
