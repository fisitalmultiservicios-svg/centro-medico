// FISITAAP › Pedido › Detalle y bitácora (op180_order_detail del zip): negocio y número, estado actual, cliente, dirección y
// ubicación, PIN de entrega, comprobante SINPE, motorizado, bitácora de tiempos, artículos y acciones de corrección.
// 4.9 (Revendedoras): la forma de pago es la del servidor (`forma_pago`, «A crédito» en los fiados) y el pedido de una revendedora
// enlaza a su estado de cuenta (ERP) y a todos sus pedidos. `?contacto_id=` (lo ponen Pedidos y Clientes) busca entre todos los
// pedidos de esa revendedora, así abren también los pedidos viejos que no caben en la lista general.
import { api, toast, abrirArchivo } from '/js/api.js';
import { sesion } from '../sesion.js';
import { dinero, fechaCorta, formaPago, puedeEstadoCuenta, urlEstadoCuenta } from '../ui.js';

export default {
  props: ['params'],
  data() { return { sesion, p: null, nota: '', ocupado: false }; },
  computed: {
    contacto() { return String((this.params && this.params.query && this.params.query.contacto_id) || '').replace(/\D/g, ''); },   // 4.9
    volver() { return '#/pedidos' + (this.contacto ? '?contacto_id=' + this.contacto : ''); },
    puedeCuenta() { return puedeEstadoCuenta(sesion); },
    // 4.9: la forma de pago; un reembolso (que antes se leía aquí en pago_estado_nombre) se sigue anotando
    pagoTexto() { const p = this.p; if (!p) return ''; const f = formaPago(p); return ['reembolsado', 'reembolso_pendiente'].includes(p.pago_estado) && p.pago_estado_nombre ? f + ' · ' + p.pago_estado_nombre : f; },
    maps() { const p = this.p; return p && p.lat && p.lng ? 'https://www.google.com/maps?q=' + p.lat + ',' + p.lng : ''; },
    eventos() {
      const p = this.p; if (!p) return [];
      const ev = [[p.creado, 'Pedido recibido desde la página']];
      if (p.confirmado) ev.push([p.confirmado, 'Pedido aceptado y enviado a la caja']);
      const e = p.entrega || {};
      for (const [k, t] of [['asignada_en', 'Express asignado'], ['aceptada_en', 'Motorizado aceptó la entrega'], ['recogida_en', 'Pedido recogido'], ['en_camino_en', 'En camino al cliente'], ['entregada_en', 'Entregado con PIN'], ['cancelada_en', 'Entrega cancelada']]) if (e[k]) ev.push([e[k], t]);
      if (p.entregado) ev.push([p.entregado, 'Pedido entregado']);
      if (p.estado === 'cancelado') ev.push([p.actualizado, 'Pedido cancelado: ' + (p.motivo || '')]);
      ev.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
      return ev.map((x, i) => ({ fecha: x[0], texto: x[1], lapso: i + 1 < ev.length ? this.lapso(x[0], ev[i + 1][0]) : null }));
    },
  },
  methods: {
    dinero, fechaCorta, urlEstadoCuenta,
    lapso(a, b) { const s = Math.max(0, Math.round((new Date(b) - new Date(a)) / 1000)); return Math.floor(s / 60) + ' min ' + (s % 60) + ' s hasta el siguiente paso'; },
    async cargar() { try { const l = await api('/api/pedidos?desde=2000-01-01&hasta=2099-12-31' + (this.contacto ? '&contacto_id=' + this.contacto : '')); this.p = l.find(x => x.id === +this.params.id) || null; if (!this.p) toast('Pedido no disponible.', 'err'); } catch (e) { toast(e.message, 'err'); } },
    verComprobante() { abrirArchivo('/api/pedidos/' + this.p.id + '/sinpe/comprobante').catch(e => toast(e.message, 'err')); },
    async cancelarEntrega() {
      const motivo = this.nota.trim(); if (motivo.length < 8) return toast('Explica la corrección o solución (al menos 8 caracteres).', 'err');
      this.ocupado = true;
      try { const r = await api('/api/entregas/' + this.p.entrega.id + '/cancelar', { method: 'PUT', body: { motivo } }); this.p.entrega = r; toast('Corrección registrada.', 'ok'); this.nota = ''; }
      catch (e) { toast(e.message, 'err'); }
      this.ocupado = false;
    },
    async liberar() {
      this.ocupado = true;
      try { const r = await api('/api/entregas/' + this.p.entrega.id + '/asignar', { method: 'PUT', body: { motorizado_id: null } }); this.p.entrega = r; toast('Express publicado de nuevo para los motorizados afiliados.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      this.ocupado = false;
    },
  },
  created() { this.cargar(); },
  template: `
  <div v-if="p">
    <div class="page-heading"><div><h1>Pedido #{{p.numero}}</h1></div><div class="toolbar"><a class="btn btn-light" :href="volver">← Pedidos</a></div></div>
    <section class="card admin-card" data-live-region="order-detail"><h2>{{sesion.nombreNegocio}} · Pedido #{{p.numero}}</h2><p>Estado actual: <strong>{{p.entrega && !['cancelada','entregada'].includes(p.entrega.estado) ? p.entrega.estado_nombre : p.estado_nombre}}</strong></p><p>{{p.nombre}} · {{p.telefono}}<span v-if="p.correo"> · {{p.correo}}</span></p>
      <p v-if="p.contacto_id" class="fis-inline">Revendedora<template v-if="p.a_credito"> · pedido a crédito</template><a v-if="puedeCuenta" class="btn btn-light" :href="urlEstadoCuenta(p.contacto_id)">Estado de cuenta</a><a class="btn btn-light" :href="'#/pedidos?contacto_id=' + p.contacto_id">Todos sus pedidos</a></p><p>{{p.tipo_nombre}}{{p.direccion ? ' · ' + p.direccion : ''}}{{p.zona ? ' · zona ' + p.zona : ''}}{{p.hora_programada ? ' · para las ' + p.hora_programada : ''}}</p>
      <a v-if="maps" class="btn btn-light" :href="maps" target="_blank" rel="noopener noreferrer">Abrir ubicación en Google Maps</a>
      <div class="op180-pin" v-if="p.entrega && p.entrega.pin && p.tipo !== 'recoger'"><small>PIN PARA RECIBIR EL PEDIDO</small><strong>{{p.entrega.pin}}</strong><p>El cliente se lo da al motorizado únicamente cuando recibe su pedido.</p></div>
      <p v-if="p.pago_medio === 'sinpe'"><button class="btn btn-light" type="button" @click="verComprobante" v-if="p.sinpe && p.sinpe.comprobante">Ver comprobante SINPE</button> <span v-else>SINPE sin comprobante todavía.</span></p>
      <p v-if="p.entrega">Motorizado: {{p.entrega.motorizado || 'Por asignar'}}</p>
      <h3>Artículos</h3><table class="table"><tr><th>Cantidad</th><th>Detalle</th><th>Precio</th><th>Total</th></tr><tr v-for="(l, i) in p.lineas" :key="i"><td>{{l.cantidad}}</td><td>{{l.detalle}}<small v-if="l.nota"> · {{l.nota}}</small><small v-if="l.opciones && l.opciones.length"> · {{l.opciones.map(o => o.nombre).join(', ')}}</small></td><td>{{dinero(l.precio_unitario)}}</td><td>{{dinero(l.total || l.cantidad * l.precio_unitario)}}</td></tr></table>
      <p>Subtotal {{dinero(p.subtotal)}} · Impuestos {{dinero(p.impuestos)}}<span v-if="p.envio"> · Envío {{dinero(p.envio)}}</span><span v-if="p.descuento"> · Descuento {{dinero(p.descuento)}}</span> · <strong>Total {{dinero(p.total)}}</strong> · {{pagoTexto}}</p>
      <p v-if="p.comprobante" data-comprobante>Comprobante: <strong>{{p.comprobante}}</strong></p>
      <p v-if="p.nota">Nota del cliente: {{p.nota}}</p>
      <h3>Bitácora de tiempos</h3><ol class="op180-timeline"><li v-for="(e, i) in eventos" :key="i"><time>{{fechaCorta(e.fecha)}}</time><strong>{{e.texto}}</strong><small v-if="e.lapso">{{e.lapso}}</small></li></ol></section>
    <section class="card admin-card" v-if="p.entrega && !['entregada','cancelada'].includes(p.entrega.estado) && !['entregado','cancelado'].includes(p.estado)"><h3>Corregir entrega / incidencia</h3>
      <p v-if="p.entrega.incidencia">Incidencia reportada: {{p.entrega.incidencia}}</p>
      <form @submit.prevent="liberar"><button class="btn" :disabled="ocupado">Resolver y publicar de nuevo para los motorizados</button></form>
      <details><summary>Cancelar la entrega de este pedido</summary><form @submit.prevent="cancelarEntrega"><div class="form-group"><label>Motivo de la corrección</label><input class="input" v-model="nota" required></div><button class="btn" :disabled="ocupado">Guardar corrección</button></form></details></section>
  </div>
  <div v-else class="fis-cargando">Cargando…</div>`,
};
