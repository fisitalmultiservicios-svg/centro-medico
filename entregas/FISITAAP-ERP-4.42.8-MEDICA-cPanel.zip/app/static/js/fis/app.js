// Ventas en línea dentro de FISITAAP by Brillante Agencia (3.74; un solo cascarón desde 3.77). Esta es la aplicación de FISITAAP (sus pantallas y
// sus hojas de estilo originales del zip 1.8.0-R22) con el cascarón del ERP: el mismo árbol de menú (js/menu.js) en el cajón, la
// marca FISITAAP by Brillante Agencia arriba, migas «Mi espacio / Ventas en línea / pantalla» y buscador Ctrl K. Lo que ya existe en el ERP no se
// duplica: esas entradas abren la pantalla del ERP (/app/#/...).
import { createApp, reactive } from '/js/vendor/vue.esm-browser.prod.min.js';
import { api, toasts, toast, token, cerrarSesionServidor, setToken } from '/js/api.js';
import { menuVisibleDe, ICONO_MENU } from '/js/menu.js';
import { sesion } from './sesion.js';
import { Icono, Grafica, Avisos, dinero } from './ui.js';

const HOY = (() => { const d = new Date(); const dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'], meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']; try { const cr = new Date(d.toLocaleString('en-US', { timeZone: 'America/Costa_Rica' })); return `${dias[cr.getDay()]}, ${cr.getDate()} de ${meses[cr.getMonth()]}`; } catch { return `${dias[d.getDay()]}, ${d.getDate()} de ${meses[d.getMonth()]}`; } })();

// Pantallas propias de Ventas en línea (archivo en js/fis/pages/) con su título, como admin_shell_start(título). css: hoja que
// FISITAAP solo carga en esa pantalla (restructure-r2.css en las r2). 3.87: modulo, el extra del plan que la pantalla necesita.
const PAGINAS = {
  resumen: { m: 'resumen', titulo: 'Resumen', propio: true }, bienvenida: { m: 'bienvenida', titulo: 'Bienvenida' }, configurador: { m: 'configurador', titulo: 'Configurador' },
  productos: { m: 'productos', titulo: 'Productos', css: 'r2' }, extras: { m: 'extras', titulo: 'Extras', css: 'r2' }, opcionales: { m: 'opcionales', titulo: 'Grupos de opcionales', css: 'r2' },
  combos: { m: 'combos', titulo: 'Combos', css: 'r2' }, promociones: { m: 'promociones', titulo: 'Promociones', css: 'r2' }, cupones: { m: 'cupones', titulo: 'Códigos de descuento' },
  pedidos: { m: 'pedidos', titulo: 'Pedidos', propio: true }, pedido: { m: 'pedido', titulo: 'Pedido', propio: true }, 'express-pendientes': { m: 'express', titulo: 'Express pendientes', modulo: 'entregas' },
  'clientes-historial': { m: 'clientes', titulo: 'Historial de clientes', css: 'r2' }, fidelizacion: { m: 'fidelizacion', titulo: 'Fidelización' }, kpis: { m: 'kpis', titulo: 'KPIs', css: 'r2' },
  publicar: { m: 'publicar', titulo: 'Publicar y dominio' }, configuracion: { m: 'configuracion', titulo: 'Generales' }, contenido: { m: 'contenido', titulo: 'Diseño de la página' }, delivery: { m: 'delivery', titulo: 'Zonas de envío', modulo: 'entregas' },
  afiliados: { m: 'afiliados', titulo: 'Motorizados afiliados', css: 'r2', modulo: 'entregas' }, invitaciones: { m: 'afiliados', titulo: 'Invitaciones', css: 'r2', modulo: 'entregas' }, 'entregas-historial': { m: 'historial', titulo: 'Historial de entregas', css: 'r2', modulo: 'entregas' },
  contactos: { m: 'contactos', titulo: 'Contactos de la página' }, 'producto-extras': { m: 'producto-extras', titulo: 'Extras y opcionales del producto' },
};

// ---- el árbol del menú (menu.js), el mismo que ve el usuario en el ERP ----
// hotel activo según lo que trajo /api/arranque (en el ERP lo leen los registros)
const hotelActivo = () => sesion.tipo === 'hospitalidad' && !!(sesion.hotelConfig && sesion.hotelConfig.activo);
// las pantallas de Ventas en línea se abren dentro de esta aplicación (#/clave); el resto del árbol, en el ERP
const enlace = it => (it.clave ? '#/' + it.clave : (it.href || ('/app/#' + it.to)));
const planos = (items, pref) => items.flatMap(c => c.children ? planos(c.children, (pref ? pref + ' · ' : '') + c.label) : (c.accion || c.soon ? [] : [{ clave: 'erp:' + (c.to || c.href || c.label), label: (pref ? pref + ' · ' : '') + c.label, href: enlace(c) }]));
const iconoDe = it => it.icono || ICONO_MENU[it.label] || 'box';
// Grupos del cajón para Ventas en línea: las entradas sueltas de la sección y cada subsección como grupo
function gruposFis(nodo) {
  if (!nodo) return [];
  const sueltas = nodo.children.filter(c => !c.children).map(c => ({ clave: c.clave, label: c.label, href: enlace(c), grupo: 'Ventas en línea' }));
  const g = sueltas.length ? [{ nombre: 'Ventas en línea', items: sueltas }] : [];
  for (const sub of nodo.children.filter(c => c.children)) g.push({ nombre: sub.label, items: sub.children.filter(c => !c.children).map(c => ({ clave: c.clave, label: c.label, href: enlace(c), grupo: sub.label })) });
  return g;
}
// El resto del ERP: entradas sueltas como enlace y secciones con sus pantallas (los subniveles se aplanan con su prefijo)
function gruposErp(items) {
  return items.filter(it => it.label !== 'Ventas en línea' && !it.accion).map(it => it.children
    ? { label: it.label, icono: iconoDe(it), items: planos(it.children, '') }
    : { label: it.label, icono: iconoDe(it), href: enlace(it) });
}

const estado = reactive({ ruta: 'resumen', params: {}, comp: null, titulo: '', propio: false, cargando: false, avisos: [], sistema: { nombre: 'FISITAAP by Brillante Agencia' } });

function leerHash() {
  const h = (location.hash || '#/resumen').replace(/^#\/?/, '');
  const [camino, consulta] = h.split('?');
  const partes = camino.split('/').filter(Boolean);
  const query = {}; new URLSearchParams(consulta || '').forEach((v, k) => { query[k] = v; });
  return { ruta: partes[0] || 'resumen', id: partes[1] || null, query };
}

async function cargarRuta() {
  const { ruta, id, query } = leerHash();
  const def = PAGINAS[ruta];
  if (!def) { estado.comp = null; estado.titulo = 'Página no disponible'; estado.ruta = ruta; return; }
  // 3.87: el modo cajero (Cajero, Mesero) solo atiende los pedidos (CLAVES_CAJA de menu.js y el detalle): otra pantalla escrita a mano vuelve a Pedidos
  if (sesion.listo && sesion.modoCajero && !['pedidos', 'pedido', 'express-pendientes'].includes(ruta)) { location.replace('#/pedidos'); return; }
  // 3.87: sin el extra que la pantalla necesita (Entregas) no se carga para fallar con 403: «No incluido en su plan», como el ERP
  if (def.modulo && sesion.listo && !sesion.tieneModulo(def.modulo)) { estado.comp = null; estado.titulo = 'No incluido en su plan'; estado.ruta = ruta; document.title = estado.titulo + ' · Ventas en línea'; return; }
  estado.cargando = true;
  try {
    const mod = await import(`/js/fis/pages/${def.m}.js`);
    estado.comp = mod.default; estado.ruta = ruta; estado.params = { id, query, seccion: ruta }; estado.titulo = def.titulo; estado.propio = !!def.propio;
    for (const [idc, clave] of [['css-r2', 'r2'], ['css-p148', 'p148']]) { const l = document.getElementById(idc); if (l) l.disabled = def.css !== clave; }
    document.title = def.titulo + ' · Ventas en línea · ' + (sesion.nombreNegocio || estado.sistema.nombre);
    window.scrollTo(0, 0); const v = document.getElementById('r15Viewport'); if (v) v.scrollTop = 0;
  } catch (e) {
    estado.comp = null; estado.titulo = 'No se pudo abrir la pantalla'; toast(e.message, 'err');
  }
  estado.cargando = false;
}

const App = {
  data() { return { sesion, estado, toasts, menuAbierto: false, abiertos: {}, busqueda: '', HOY, pila: [] }; },
  computed: {
    arbol() { return menuVisibleDe(this.sesion, hotelActivo); },
    seccion() { return this.arbol.find(it => it.label === 'Ventas en línea') || null; },
    gruposFis() { return gruposFis(this.seccion); },
    erp() { return gruposErp(this.arbol); },
    activo() { return this.estado.ruta; },
    urlTienda() { const n = this.sesion.negocio; return n && n.slug ? (n.url_publica || ('/' + n.slug)) : null; },
    nombreEmpresa() { const e = this.sesion.empresaInfo; return (e && (e.nombre_comercial || e.nombre)) || this.sesion.nombreNegocio; },
    resultados() {
      const q = this.busqueda.trim().toLocaleLowerCase('es');
      const todo = [...this.gruposFis.flatMap(g => g.items), ...this.erp.flatMap(it => it.items ? it.items.map(c => ({ ...c, grupo: it.label })) : [{ clave: 'erp:' + it.label, label: it.label, href: it.href, grupo: 'ERP' }])];
      return todo.filter(it => !q || it.label.toLocaleLowerCase('es').includes(q) || it.grupo.toLocaleLowerCase('es').includes(q));
    },
    puedeAtras() { return this.estado.ruta !== 'resumen' || !!this.sesion.modoCajero; },   /* 4.39: no sale en la portada; el cajero lo tiene en todas, también en Pedidos (vuelve a la caja) */
    sinModulo() { return this.sesion.listo && this.sesion.empresa_id && !this.sesion.tieneModulo('pedidos_online'); },
    sinPermiso() { return this.sesion.listo && this.sesion.empresa_id && !this.sesion.puede('pos'); },
  },
  methods: {
    abrirGrupoActivo() { const g = this.gruposFis.find(x => x.items.some(it => it.clave === this.activo)); this.abiertos = { 'Ventas en línea': true, ...(g ? { [g.nombre]: true } : {}) }; },
    abrirBuscador() { const d = this.$refs.cmd; if (!d) return; this.busqueda = ''; if (!d.open) d.showModal(); this.$nextTick(() => this.$refs.q && this.$refs.q.focus()); },
    cerrarBuscador() { const d = this.$refs.cmd; if (d && d.open) d.close(); },
    irA(it) { this.cerrarBuscador(); this.menuAbierto = false; location.href = it.href; },
    async salir() { await cerrarSesionServidor(); setToken(''); location.href = '/app/#/login'; },
    teclas(e) { if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === 'k') { e.preventDefault(); this.abrirBuscador(); } },
    /* 4.39: «Atrás» arriba a la izquierda. pila = las pantallas abiertas desde que se cargó esta página (si se entró directo o desde otro sitio solo hay una:
       si se llegó desde el sistema, como la caja, se vuelve allá; si no, a la portada de Ventas en línea, y el cajero a la caja). El cajero solo vuelve a
       las pantallas que puede abrir. */
    marcarPaso() { const h = location.hash || '#/resumen', p = this.pila; if (p.length >= 2 && p[p.length - 2] === h) p.pop(); else if (p[p.length - 1] !== h) p.push(h); if (p.length > 60) p.shift(); },
    atras() {
      const ant = this.pila.length > 1 ? this.pila[this.pila.length - 2] : '';
      const ruta = String(ant).replace(/^#\/?/, '').split('?')[0].split('/')[0];
      if (ant && history.length > 1 && (!this.sesion.modoCajero || ['pedidos', 'pedido', 'express-pendientes'].includes(ruta))) { history.back(); return; }
      if (!ant && history.length > 1 && this.vieneDelSistema()) { history.back(); return; }   /* 4.39: se entró desde la caja u otra pantalla del sistema: se vuelve allá */
      if (this.sesion.modoCajero) location.href = '/app/#/pos/caja'; else location.hash = '#/resumen';   /* 4.39: el cajero, a la caja */
    },
    vieneDelSistema() { try { const u = new URL(document.referrer); return u.origin === location.origin && /^\/app\/(?!fisitaap(\/|$))/.test(u.pathname); } catch (e) { return false; } },   /* 4.39: la página anterior es del sistema (/app/), no de Ventas en línea ni de otro sitio */
    abrirChat() { window.dispatchEvent(new CustomEvent('fisichat:abrir')); },
  },
  watch: { 'estado.ruta'() { this.abrirGrupoActivo(); } },
  async created() {
    if (!token()) { location.href = '/app/#/login'; return; }
    fetch('/api/sistema').then(r => (r.ok ? r.json() : null)).then(j => { if (j && j.nombre) estado.sistema = j; }).catch(() => {});
    await sesion.restaurar();
    if (!sesion.activa) { location.href = '/app/#/login'; return; }
    await cargarRuta(); this.abrirGrupoActivo();
    this.pila = [location.hash || '#/resumen']; window.addEventListener('hashchange', () => { this.marcarPaso(); cargarRuta(); });
    document.addEventListener('keydown', this.teclas);
  },
  template: `
  <div id="r15App" class="r15-shell admin-shell" v-if="sesion.listo && sesion.activa">
    <aside id="navigation" class="sidebar" :class="{'admin-menu-open': menuAbierto, open: menuAbierto}" data-admin-menu :inert="!menuAbierto">
      <div class="sidebar-head nav-brand"><a class="brand admin-brand" href="/app/#/inicio" title="Inicio del ERP" @click="menuAbierto=false"><img src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP"><span class="erp-by">by Brillante Agencia</span></a><button class="icon-btn admin-menu-toggle" type="button" aria-controls="adminMenuLinks" :aria-expanded="menuAbierto" aria-label="Cerrar menú" @click="menuAbierto=false"><span aria-hidden="true">×</span></button></div>
      <nav id="adminMenuLinks" class="sidebar-groups nav-groups">
        <div class="nav-zona">Ventas en línea · {{nombreEmpresa}}</div>
        <details v-for="g in gruposFis" :key="g.nombre" class="nav-group" data-nav-group :open="abiertos[g.nombre] || null" @toggle="e => abiertos[g.nombre] = e.target.open"><summary><span>{{g.nombre}}</span><span class="nav-chevron">⌄</span></summary><div class="nav-group-links">
          <a v-for="it in g.items" :key="it.clave" class="side-link nav-link" :class="{active: it.clave===activo}" :href="it.href" @click="menuAbierto=false">{{it.label}}</a>
        </div></details>
        <div class="nav-zona">Todo el ERP</div>
        <a v-if="sesion.esAdmin" class="side-link nav-link nav-erp-link" href="/app/#/admin"><Icono n="shield"/>Administración</a>
        <template v-for="it in erp" :key="it.label">
          <a v-if="!it.items" class="side-link nav-link nav-erp-link" :href="it.href"><Icono :n="it.icono"/>{{it.label}}</a>
          <details v-else class="nav-group" data-nav-group :open="abiertos['erp:' + it.label] || null" @toggle="e => abiertos['erp:' + it.label] = e.target.open"><summary><span class="nav-erp-titulo"><Icono :n="it.icono"/>{{it.label}}</span><span class="nav-chevron">⌄</span></summary><div class="nav-group-links">
            <a v-for="c in it.items" :key="c.clave" class="side-link nav-link" :href="c.href">{{c.label}}</a>
          </div></details>
        </template>
      </nav>
      <div class="sidebar-foot nav-foot"><span>{{sesion.nombreUsuario}}</span><a class="side-link" href="/app/#/configuracion/perfil">Mi perfil</a><form @submit.prevent="salir"><button class="side-logout">Cerrar sesión</button></form></div>
    </aside>
    <header class="topbar r15-topbar">
      <button class="icon-button admin-mobile-launch" type="button" :aria-expanded="menuAbierto" aria-controls="adminMenuLinks" aria-label="Abrir menú" @click="menuAbierto=!menuAbierto"><Icono n="menu"/></button>
      <a class="brand" href="/app/#/inicio" title="Inicio del ERP"><img class="hybrid-brand" src="/fisitaap/assets/fisitapp-logo.webp" alt="FISITAAP"><span class="erp-by">by Brillante Agencia</span><span class="hybrid-brand-divider"></span><span><strong>{{nombreEmpresa}}</strong><small>{{sesion.sucursalActual ? sesion.sucursalActual.nombre : 'Ventas en línea'}}</small></span></a>
      <button class="header-search r15-search-launch" type="button" aria-label="Buscar una pantalla" @click="abrirBuscador"><Icono n="search"/><span>Buscar una pantalla…</span><span class="keycap">Ctrl K</span></button>
      <span class="profile-select right" :title="sesion.rolNombre"><span v-if="sesion.empresaInfo?.es_demo">Demo · </span><span v-else-if="sesion.empresaInfo?.prueba_hasta">Prueba · </span>{{sesion.rolNombre}}</span>
      <details class="r15-profile"><summary class="avatar" aria-label="Mi cuenta">{{sesion.iniciales}}</summary><div><strong>{{sesion.nombreUsuario}}</strong><small>{{sesion.rolNombre}}</small><a href="/app/#/configuracion/perfil">Mi perfil, contraseña y verificación</a><a v-if="urlTienda" :href="urlTienda" target="_blank" rel="noopener">Ver mi página en línea</a><a href="/app/#/inicio">Inicio del ERP</a><form @submit.prevent="salir"><button>Cerrar sesión</button></form></div></details>
    </header>
    <div class="breadcrumb"><div class="hstack"><button type="button" class="atras-btn" v-if="puedeAtras" title="Volver a la pantalla anterior" aria-label="Volver a la pantalla anterior" @click="atras">← Atrás</button><a href="/app/#/inicio">Mi espacio</a><span>/</span><a :href="sesion.modoCajero ? '#/pedidos' : '#/resumen'">Ventas en línea</a><span>/</span><span class="current">{{estado.titulo}}</span></div><div class="hstack"><span class="design-label">{{estado.sistema.nombre}}</span><span class="r15-live-state" data-r15-live-status></span></div></div>
    <div class="view-container" id="r15Viewport"><main class="view admin-main" :data-r15-page="activo">
      <div v-if="sinModulo" class="card admin-card fis-modulo-inactivo"><h2>Ventas en línea no está en su plan</h2><p>Pedidos en línea, catálogo web, promociones y entregas se activan con el módulo Ventas en línea. Puede verlo y contratarlo desde su suscripción.</p><a class="btn" href="/app/#/configuracion/suscripcion">Ver mi plan</a> <a class="btn btn-light" href="/app/#/inicio">Volver al inicio</a></div>
      <div v-else-if="sinPermiso" class="card admin-card fis-modulo-inactivo"><h2>Su rol no tiene acceso a Ventas en línea</h2><p>Pida a la persona administradora el permiso de punto de venta.</p><a class="btn btn-light" href="/app/#/inicio">Volver al inicio</a></div>
      <template v-else>
        <div v-if="!estado.propio" class="page-heading"><div><h1>{{estado.titulo}}</h1></div><div class="toolbar"><a v-if="urlTienda" class="btn" target="_blank" rel="noopener" :href="urlTienda">Ver mi página</a></div></div>
        <Avisos :lista="estado.avisos"></Avisos>
        <div v-if="estado.cargando && !estado.comp" class="fis-cargando">Cargando…</div>
        <component v-else-if="estado.comp" :is="estado.comp" :params="estado.params" :key="estado.ruta + ':' + (estado.params.id || '')"></component>
        <div v-else class="card admin-card"><h2>{{estado.titulo}}</h2><p v-if="estado.titulo === 'No incluido en su plan'">Esta pantalla es parte del extra Ventas en línea · Entregas, que su plan no trae. <a href="#/pedidos">Ir a Pedidos</a>.</p><p v-else>Esa pantalla no existe. <a :href="sesion.modoCajero ? '#/pedidos' : '#/resumen'">{{sesion.modoCajero ? 'Ir a Pedidos' : 'Volver al resumen'}}</a>.</p></div>
      </template>
      <footer class="view-footer"><span><i class="dot"></i> {{estado.sistema.nombre}} · Ventas en línea</span><span>{{HOY}}</span></footer>
    </main></div>
    <dialog class="r15-command" id="r15Command" ref="cmd" @click.self="cerrarBuscador"><header class="dialog-head"><h2>Buscar una pantalla</h2><button class="icon-button" type="button" aria-label="Cerrar búsqueda" @click="cerrarBuscador"><Icono n="close"/></button></header><div class="dialog-body"><input class="input" ref="q" v-model="busqueda" placeholder="Escriba una pantalla o función…" aria-label="Buscar pantalla" @keydown.enter.prevent="resultados.length && irA(resultados[0])" @keydown.esc.prevent="cerrarBuscador"><div data-r15-command-results><a v-for="it in resultados" :key="it.clave" :href="it.href" @click.prevent="irA(it)">{{it.label}}<small>{{it.grupo}}</small></a></div></div></dialog>
    <div id="toasts"><div v-for="t in toasts.list" :key="t.id" class="toast" :class="t.kind">{{t.text}}</div></div>
  </div>
  <div v-else class="fis-cargando">{{sesion.error || 'Cargando Ventas en línea…'}}</div>`,
};

const app = createApp(App);
app.component('Icono', Icono); app.component('Grafica', Grafica); app.component('Avisos', Avisos);
app.config.globalProperties.dinero = dinero;
app.mount('#app');
