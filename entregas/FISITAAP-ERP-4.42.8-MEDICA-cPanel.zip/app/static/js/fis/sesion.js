// FISITAAP dentro de FISITAAP by Brillante Agencia (3.74): sesión compartida con el ERP. Misma cuenta, misma empresa activa, mismos permisos.
// La aplicación de FISITAAP vive en /app/fisitaap/ con las hojas de estilo originales del zip; esta sesión es un espejo reducido
// de la del ERP (js/app.js) para que las pantallas pregunten `sesion.puede(...)`, `sesion.tieneModulo(...)` y lean la empresa.
import { reactive } from '/js/vendor/vue.esm-browser.prod.min.js';
import { api, token, setToken, fijarEmpresaTab, fijarSucursal, onExpirar } from '/js/api.js';

export const TIPOS_NEGOCIO = { facturacion: 'Facturación', comercio: 'Comercio', restaurante: 'Restaurante', hospitalidad: 'Hospitalidad', servicios: 'Servicios' };

export const sesion = reactive({
  usuario: null, empresas: [], empresa_id: null, rol: null, permisos: [], listo: false, empresa: null, negocio: null, sucursales: [], sucursal_id: null, error: '',
  hotelConfig: null,   // registro hotel_config de la empresa (3.77): el menú de Hospitalidad solo muestra el hotel si está activo
  get activa() { return !!this.usuario; },
  get esAdmin() { return !!this.usuario?.es_superadmin; },
  get empresaInfo() { return this.empresas.find(e => e.id === this.empresa_id) || null; },
  get tipo() { const t = this.empresaInfo?.tipo_negocio; return TIPOS_NEGOCIO[t] ? t : 'facturacion'; },
  tieneModulo(m) { const p = this.empresaInfo?.plan; return !p || !Array.isArray(p.modulos) || p.modulos.includes(m); },
  puede(p) { if (this.esAdmin && !(this.empresa_id && this.permisos.length)) return true; return this.permisos.includes(p); },   // 3.87: como en el ERP, con empresa manda la lista del servidor (filtrada por plan)
  tieneFuncion(f) { const p = this.empresaInfo?.plan; return !!(p && Array.isArray(p.funciones) && p.funciones.includes(f)); },   // funciones en prueba por empresa (3.58)
  // modo cajero (rol Cajero), igual que en el ERP: solo ve el punto de venta (3.77, menu.js lo usa para el cajón)
  get modoCajero() { return this.tipo !== 'facturacion' && !this.esAdmin && this.puede('pos') && this.permisos.every(p => p === 'ver' || p === 'pos'); },
  get esDueno() { return this.esAdmin || this.rol === 'Administrador'; },
  // «tienda física» de FISITAAP = la empresa tiene punto de venta; «modo Menú» = restaurante o presentación de menú en la página
  get fisica() { return this.tieneModulo('pos') && this.tipo !== 'facturacion'; },
  get menu() { return this.tipo === 'restaurante' || this.negocio?.presentacion === 'menu'; },
  get nombreNegocio() { return this.negocio?.nombre_publico || this.empresa?.nombre_comercial || this.empresa?.nombre || this.empresaInfo?.nombre || ''; },
  get sucursalActual() { return this.sucursales.find(x => x.id === this.sucursal_id) || null; },
  get nombreUsuario() { return this.usuario?.nombre || this.usuario?.correo || ''; },
  get iniciales() { const p = String(this.nombreUsuario).trim().split(/\s+/); return ((p[0] || '')[0] || '').toUpperCase() + ((p[1] || '')[0] || '').toUpperCase(); },
  get rolNombre() { return this.esAdmin ? 'Administrador del sistema' : this.rol === 'Administrador' ? 'Administrador del negocio' : (this.rol || 'Usuario'); },
  async restaurar() {
    this.error = '';
    if (!token()) { this.listo = true; return; }
    try {
      const a = await api('/api/arranque'); const r = a.yo;
      this.usuario = r.usuario; this.empresas = r.empresas || []; this.empresa_id = r.empresa_id; this.rol = r.rol; this.permisos = r.permisos || [];
      fijarEmpresaTab(this.empresa_id);
      this.sucursales = r.sucursales || []; let sid = r.sucursal_fija || null;
      if (!sid) { try { sid = +localStorage.getItem('sucursal:' + this.empresa_id) || null; } catch { sid = null; } }
      if (sid && !this.sucursales.some(x => x.id === sid)) sid = null;
      this.sucursal_id = sid; fijarSucursal(sid);
      this.empresa = a.empresa || null;
      this.hotelConfig = (a.registros && a.registros.datos && a.registros.datos.hotel_config) || null;
      if (this.empresa_id && this.tieneModulo('pedidos_online')) { try { this.negocio = await api('/api/pedidos/negocio'); } catch { this.negocio = null; } }
    } catch (e) {
      if (e.status === 401 || e.status === 403) setToken(''); else this.error = 'No se pudo conectar con el servidor. Recargue la página en un momento.';
    }
    this.listo = true;
  },
  async recargarNegocio() { try { this.negocio = await api('/api/pedidos/negocio'); } catch { /* sin página todavía */ } return this.negocio; },
});

// sesión vencida: de vuelta a la entrada del ERP
onExpirar(() => { setToken(''); location.href = '/app/#/login'; });

export function irAlERP(ruta = '/inicio') { location.href = '/app/#' + ruta; }
