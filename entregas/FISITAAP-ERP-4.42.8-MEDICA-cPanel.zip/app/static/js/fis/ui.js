// FISITAAP embebido (3.74): piezas compartidas de las pantallas. Los íconos son los mismos trazos del zip (r15_icon), los
// importes se muestran como FISITAAP (₡ sin decimales) y las fechas en español de Costa Rica.
import { fmt } from '/js/api.js';
import { PATHS } from '/js/iconos.js';   // iconos del ERP (3.77): los nombres de ICONO_MENU que no están en TRAZOS

export const TRAZOS = {
  trash: 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7', menu: 'M4 6h16M4 12h16M4 18h16', close: 'm6 6 12 12M18 6 6 18',
  search: 'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0', arrow: 'M5 12h14m-5-5 5 5-5 5', plus: 'M12 5v14M5 12h14',
  overview: 'M3 3h7v7H3zm11 0h7v7h-7zM3 14h7v7H3zm11 0h7v7h-7z', bag: 'M5 7h14l2 14H3L5 7zm3 0V5a4 4 0 0 1 8 0v2',
  orders: 'M6 3h12v18l-3-2-3 2-3-2-3 2V3zm3 5h6m-6 4h6',
  users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M13 3a4 4 0 0 1 0 8m9 10v-2a4 4 0 0 0-3-3.87M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  box: 'm3 7 9-5 9 5v10l-9 5-9-5V7zm0 0 9 5 9-5m-9 5v10M7 4.8l10 5.6', wallet: 'M3 6h17v15H3V6zm0 0V4h15v2m-3 6h6v5h-6z',
  truck: 'M1 4h14v13H1zm14 5h4l3 4v4h-7M8 18a2 2 0 1 1-4 0 2 2 0 0 1 4 0m13 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0', sales: 'M3 20h18M6 16V9m6 7V4m6 7v-6',
  full: 'M3 9V3h6m6 0h6v6M3 15v6h6m6 0h6v-6', chat: 'M4 3h16v14H9l-5 4V3zm4 5h8m-8 4h5', clock: 'M12 8v5l3 2M22 12A10 10 0 1 1 2 12a10 10 0 0 1 20 0',
  credit: 'M2 5h20v14H2zM2 10h20M6 15h3', store: 'M3 9l2-6h14l2 6M4 10v11h16V10M9 21v-8h6v8M3 9h18',
};

export const Icono = { props: { n: { type: String, default: 'box' } }, template: `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path :d="TRAZOS[n] || PATHS[n] || TRAZOS.box"/></svg>`, data() { return { TRAZOS, PATHS }; } };

export function dinero(v) { return '₡' + fmt(Math.round(+v || 0), 0); }
export function dineroDec(v) { return '₡' + fmt(+v || 0, 2); }
export function fechaCorta(iso) { if (!iso) return ''; const s = String(iso); return s.slice(8, 10) + '/' + s.slice(5, 7) + '/' + s.slice(0, 4) + (s.length > 10 ? ' ' + s.slice(11, 16) : ''); }
export function fechaLocal(iso) { if (!iso) return ''; const s = String(iso); return s.slice(0, 16).replace(' ', 'T'); }   // para input datetime-local

// Gráfica de línea idéntica a r15_line_chart: puntos [{label, total}], 560 × 190, rejilla en tres alturas
export const Grafica = {
  props: { filas: { type: Array, default: () => [] }, moneda: { type: Boolean, default: true }, titulo: { type: String, default: 'Ventas registradas del período' } },
  computed: {
    mx() { return Math.max(1, ...this.filas.map(r => +r.total || 0)); },
    pts() { const n = this.filas.length; return this.filas.map((r, i) => ({ x: +(45 + (n > 1 ? i * 474 / (n - 1) : 0)).toFixed(2), y: +(148 - ((+r.total || 0) / this.mx) * 115).toFixed(2), r })); },
    path() { return 'M' + this.pts.map(p => p.x + ',' + p.y).join(' L'); },
    etiquetas() { const n = this.filas.length, paso = Math.max(1, Math.ceil(n / 7)); return this.pts.filter((p, i) => i === 0 || i === n - 1 || i % paso === 0); },
  },
  methods: { f(n) { return this.moneda ? dinero(n) : fmt(n, 0); } },
  template: `<div class="chart-wrap"><svg viewBox="0 0 560 190" role="img" :aria-label="titulo"><g class="chart-grid"><path d="M42 33H535M42 91H535M42 148H535"/></g>
    <g class="chart-axis"><text x="3" y="37">{{f(mx)}}</text><text x="3" y="95">{{f(mx/2)}}</text><text x="3" y="152">{{moneda ? '₡0' : '0'}}</text><text v-for="p in etiquetas" :key="'l'+p.x" :x="p.x" y="177" text-anchor="middle">{{p.r.label}}</text></g>
    <template v-if="pts.length"><path class="chart-fill" :d="path + ' L519,148 L45,148 Z'"/><path class="chart-line" :d="path"/><circle v-for="p in pts" :key="p.x" class="chart-point" :cx="p.x" :cy="p.y" r="3"><title>{{p.r.label}} · {{f(p.r.total)}}</title></circle></template></svg></div>`,
};

// Mensajes de la pantalla (los «flash» de FISITAAP): verde o rojo encima del contenido
export const Avisos = { props: ['lista'], template: `<div v-for="(a, i) in lista" :key="i" class="alert" :class="a.tipo === 'error' ? 'alert-error' : 'alert-success'">{{a.texto}}</div>` };

// 4.9: forma de pago de un pedido web. El servidor la manda hecha en `forma_pago` («A crédito» si la revendedora pidió fiado); si no
// viene (servidor anterior), el mismo cálculo de antes, ahora también con los pedidos a crédito.
export function formaPago(p) {
  if (!p) return '';
  if (p.forma_pago) return p.forma_pago;
  if (p.a_credito || p.pago_medio === 'credito') return 'A crédito';
  return p.pago_estado === 'aprobado' ? (p.pago_medio === 'sinpe' ? 'SINPE verificado' : 'Pagado en línea') : p.pago_estado === 'sinpe_pendiente' ? 'SINPE por verificar' : p.pago_medio === 'sinpe' && p.pago_estado === 'rechazado' ? 'SINPE rechazado · paga al recibir' : p.estado === 'pendiente_pago' ? (p.pago_estado_nombre || 'Pago pendiente') : p.pago_medio === 'tarjeta' && p.estado === 'cancelado' ? (['reembolsado', 'reembolso_pendiente'].includes(p.pago_estado) ? 'Pagado en línea' : 'Tarjeta en línea · no se pagó') : p.pago_medio === 'sinpe' && ['reembolsado', 'reembolso_pendiente'].includes(p.pago_estado) ? 'SINPE verificado' : 'Paga al recibir';   // 4.40: tarjeta que no se pagó
}

// 4.9: estado de cuenta de una revendedora y lista de saldos: viven en el ERP (#/contactos/estado-cuenta/:id y #/contactos/revendedoras),
// con los mismos permisos que el servidor (/api/revendedoras); el modo cajero no los ve. `volver=fis` pone «Volver a pedidos» allá.
export const PERMISOS_CUENTAS = ['facturar', 'cobros', 'catalogos', 'ver_todo'];
export const URL_REVENDEDORAS = '/app/#/contactos/revendedoras';
export function puedeEstadoCuenta(s) { return !!s && !s.modoCajero && PERMISOS_CUENTAS.some(p => s.puede(p)); }
export function urlEstadoCuenta(id) { return '/app/#/contactos/estado-cuenta/' + encodeURIComponent(id) + '?volver=fis'; }
// 4.9: los teléfonos se comparan por sus últimos 8 dígitos (con o sin 506, guiones o espacios). Los enlaces de WhatsApp salen de
// /js/pages/reportes/_revendedoras.js (telefonoWa, enlaceWhatsApp: funciones puras, sin app.js), los mismos del ERP.
export function tel8(t) { return String(t || '').replace(/\D/g, '').slice(-8); }
