// Página pública: menú en celular, página actual en el menú, plan elegido al pulsar «Probar gratis», origen de la visita
// (utm de redes o anuncios) y envío del formulario de contacto.
(function () {
  const abierta = Date.now();
  const menu = document.getElementById('menu'), ham = document.getElementById('hamburguesa');
  if (ham && menu) {
    ham.addEventListener('click', () => { const a = menu.classList.toggle('abierto'); ham.setAttribute('aria-expanded', a ? 'true' : 'false'); });
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => menu.classList.remove('abierto')));
  }
  // página actual: /guias/x marca «Guías»; /factura-electronica marca «Facturación»
  if (menu) {
    const ruta = location.pathname.replace(/\/+$/, '') || '/';
    menu.querySelectorAll('a').forEach(a => {
      const h = a.getAttribute('href');
      if (h !== '/' && (ruta === h || ruta.indexOf(h + '/') === 0)) a.setAttribute('aria-current', 'page');
    });
  }
  // origen: el primero de la visita (utm_source/medium/campaign o el sitio de donde viene); se guarda solo en esta pestaña
  let origen = '';
  try {
    const q = new URLSearchParams(location.search);
    const utm = ['utm_source', 'utm_medium', 'utm_campaign'].map(k => q.get(k)).filter(Boolean).join(' / ');
    let ref = '';
    try { const h = document.referrer ? new URL(document.referrer).hostname : ''; if (h && h !== location.hostname) ref = 'ref: ' + h; } catch (e) { /* sin referente */ }
    origen = sessionStorage.getItem('gf:origen') || utm || ref || 'directo';
    sessionStorage.setItem('gf:origen', origen);
  } catch (e) { /* sin almacenamiento */ }
  const form = document.getElementById('formulario'), estado = document.getElementById('estado');
  // 3.87: un plan que no está en la lista (enlace viejo o plan renombrado) deja «Prueba gratis de 1 mes», no el campo en blanco
  const elegir = plan => { const sel = form && form.querySelector('select[name=plan]'); if (!sel || !plan) return; sel.value = plan; if (sel.selectedIndex < 0) sel.selectedIndex = 0; };
  document.querySelectorAll('[data-plan]').forEach(b => b.addEventListener('click', () => elegir(b.getAttribute('data-plan'))));
  try { elegir(new URLSearchParams(location.search).get('plan')); } catch (e) { /* sin parámetros */ }
  if (!form) return;
  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(form).entries());
    estado.className = 'estado';
    if (!d.nombre || d.nombre.trim().length < 2) { estado.textContent = 'Escriba su nombre.'; estado.classList.add('err'); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.correo || '')) { estado.textContent = 'Revise su correo electrónico.'; estado.classList.add('err'); return; }
    // 3.68: prueba automática: la cuenta se crea sola, así que se piden los datos de la empresa
    if (form.dataset.auto && d.plan) {
      const falta = m => { estado.textContent = m; estado.classList.add('err'); };
      const ced = (d.cedula || '').replace(/\D/g, ''), tel = (d.telefono || '').replace(/\D/g, '').replace(/^506(?=\d{8}$)/, '');
      if ((d.empresa || '').trim().length < 3) return falta('Escriba el nombre de su empresa.');
      if (ced.length < 9 || ced.length > 12) return falta('Escriba su cédula física o jurídica, solo números.');
      if (tel.length !== 8) return falta('Escriba un teléfono o WhatsApp de 8 dígitos.');
      if (!d.tipo) return falta('Elija el tipo de negocio.');
      if ((d.mensaje || '').trim().length < 15) return falta('Cuéntenos en una línea a qué se dedica su empresa.');
    }
    if (d['cf-turnstile-response'] !== undefined) { d.turnstile = d['cf-turnstile-response']; delete d['cf-turnstile-response']; }
    d.segundos = (Date.now() - abierta) / 1000;
    d.origen = origen.slice(0, 120); d.pagina = location.pathname.slice(0, 80);
    const boton = form.querySelector('button[type=submit]'); boton.disabled = true; estado.textContent = 'Enviando…';
    try {
      const r = await fetch('/api/contacto', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(typeof j.detail === 'string' ? j.detail : 'No se pudo enviar. Escríbanos por WhatsApp o correo.');
      form.reset(); estado.classList.add('bien');
      if (j.prueba && j.correo_enviado) {
        estado.textContent = '¡Listo! Le enviamos a ' + d.correo + ' el enlace y su contraseña temporal. Si no lo ve, revise el correo no deseado. ';
        const a = document.createElement('a'); a.href = '/app/'; a.textContent = 'Entrar al sistema'; estado.appendChild(a);
      } else if (j.prueba) estado.textContent = 'Su prueba quedó creada. En breve le enviamos el acceso por correo o WhatsApp.';
      else estado.textContent = '¡Gracias! Le contactaremos pronto.';
    } catch (e) { estado.textContent = e.message; estado.classList.add('err'); }
    try { if (window.turnstile) window.turnstile.reset(); } catch (e) { /* sin widget */ }
    boton.disabled = false;
  });
})();
