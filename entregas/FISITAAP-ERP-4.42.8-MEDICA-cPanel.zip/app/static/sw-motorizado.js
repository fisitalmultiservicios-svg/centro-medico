// Service worker mínimo del panel del motorizado (3.48): hace la página instalable como aplicación en Android. No guarda
// datos: todo se pide al servidor; sin conexión solo se muestra la página base.
const CACHE = 'motorizado-v3.77';
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(['/motorizado.html', '/tienda.css', '/js/motorizado.js', '/js/mapa.js', '/js/vendor/vue.esm-browser.prod.min.js', '/img/fisitaap.webp', '/fisitaap/assets/fisitapp-logo.webp']).catch(() => null))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname.startsWith('/api/') || u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { if (r.ok) { const copia = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copia)); } return r; }).catch(() => caches.match(e.request)));
});
