"""Recepción de comprobantes electrónicos (los que emiten los proveedores a la empresa).

Reglamento 44739-H / resolución 0027-2024: el receptor confirma ante Hacienda cada comprobante recibido (Mensaje Receptor:
05 aceptado, 06 aceptado parcialmente, 07 rechazado) dentro de los primeros 8 días hábiles del mes siguiente a la emisión.
Aquí se guardan los comprobantes recibidos (tabla `recibido`), se calcula la fecha límite, se construye y firma el Mensaje
Receptor y se envía/consulta con la misma API de recepción. Los XML entran por el buzón IMAP de la empresa o cargados a mano.
"""
import calendar
import email
import imaplib
import json
import re
import ssl
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Optional

from lxml import etree
from sqlmodel import Field, SQLModel, select

from .config import DATA_DIR, NS_BASE, ahora_cr
from .db import por_empresa

DIR_RECIBIDOS = DATA_DIR / "recibidos"
DIR_RECIBIDOS.mkdir(exist_ok=True)
TIPO_POR_RAIZ = {"FacturaElectronica": "01", "NotaDebitoElectronica": "02", "NotaCreditoElectronica": "03", "TiqueteElectronico": "04",
                 "FacturaElectronicaCompra": "08", "FacturaElectronicaExportacion": "09", "ReciboElectronicoPago": "10"}
NOMBRE_TIPO = {"01": "Factura electrónica", "02": "Nota de débito", "03": "Nota de crédito", "04": "Tiquete electrónico",
               "08": "Factura electrónica de compra", "09": "Factura de exportación", "10": "Recibo electrónico de pago"}
MENSAJES = {"05": ("1", "Aceptado"), "06": ("2", "Aceptado parcialmente"), "07": ("3", "Rechazado")}
CONDICIONES_IVA = {"01": "Genera crédito IVA total", "02": "Genera crédito IVA parcial", "03": "Bienes de capital",
                   "04": "Gasto corriente no genera crédito", "05": "Proporcionalidad"}


class Recibido(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    clave: str = Field(index=True)
    tipo_documento: str = "01"
    consecutivo: str = ""
    emisor_nombre: str = ""
    emisor_id: str = ""
    emisor_tipo_id: str = "02"
    fecha_emision: str = ""            # ISO del comprobante
    moneda: str = "CRC"
    tipo_cambio: float = 1             # del comprobante; para consolidar montos en CRC/USD
    total: float = 0
    impuesto: float = 0                # TotalImpuesto del comprobante (va tal cual en el mensaje de aceptación)
    iva: Optional[float] = None        # 3.41: solo el IVA (código 01); el Selectivo y los específicos no se acreditan. None = registro viejo
    condicion_venta: Optional[str] = None
    referencia_clave: Optional[str] = None   # notas del proveedor: clave del comprobante al que se refieren
    xml_nombre: str = ""
    origen: str = "carga"              # carga | correo
    correo_asunto: Optional[str] = None
    correo_de: Optional[str] = None
    fecha_limite: str = ""             # último día hábil para responder
    respuesta: Optional[str] = None    # 05 | 06 | 07
    condicion_impuesto: Optional[str] = None
    monto_impuesto_acreditar: Optional[float] = None
    monto_gasto_aplicable: Optional[float] = None
    detalle_mensaje: Optional[str] = None
    consecutivo_receptor: Optional[str] = None
    mensaje_xml_nombre: Optional[str] = None
    estado_mensaje: Optional[str] = None   # firmado | enviado | aceptado | rechazado | error
    ambiente: Optional[str] = None         # ambiente en que se respondió (una respuesta de pruebas no bloquea la real)
    mensaje_hacienda: Optional[str] = None
    respondido_en: Optional[str] = None
    compra_id: Optional[int] = None
    inventario_ajuste_id: Optional[int] = None   # 3.75: entrada CO-#### con la que sus líneas entraron al inventario
    inventario_codigo: Optional[str] = None
    inventario_en: Optional[str] = None
    pagado_anterior: Optional[bool] = None   # 4.1: comprobante del sistema anterior que ya se pagó allá (no queda por pagar)
    clasificacion: Optional[str] = None      # 4.3: 'compra' (mercadería para vender: costo de ventas) | 'gasto' (gasto del negocio); vacío = gasto
    cuenta_contable: Optional[str] = None    # 4.3: cuenta del plan para el asiento (vacío = la de Parametrización según la clasificación)
    validacion: Optional[str] = None         # 4.2: resultado de validar en Hacienda un comprobante del sistema anterior (JSON: comprobante, respuesta, fecha, texto)
    validado_en: Optional[str] = None
    # 4.23: «registrado» = el aceptado cuenta en las listas Compras y Gastos, en los reportes y en la contabilidad. Se puede quitar
    # del registro (la aceptación ante Hacienda no cambia) y volver a registrar. Las bases que ya existen reciben la columna con 1
    # (db._agregar_columnas_faltantes copia este valor por omisión): todo lo aceptado antes de la 4.23 sigue registrado
    registrado: bool = True
    registro_quitado_en: Optional[str] = None     # cuándo se quitó del registro (hora de Costa Rica)
    registro_quitado_por: Optional[str] = None    # correo de quien lo quitó
    registro_motivo: Optional[str] = None         # motivo indicado al quitarlo (obligatorio si era de un mes pasado)
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


por_empresa(Recibido)


def esta_registrado(r) -> bool:
    """4.23: un recibido cuenta en listas, reportes y contabilidad solo si está registrado. Sin el dato (fila o diccionario de antes
    de la 4.23) está registrado: solo deja de estarlo cuando alguien lo quita del registro."""
    v = r.get("registrado") if isinstance(r, dict) else getattr(r, "registrado", None)
    return v is None or bool(v)


def aceptado_registrable(r) -> bool:
    """4.23: aceptado (05 o 06) cuya respuesta Hacienda no rechazó: lo único que puede estar (o dejar de estar) en el registro."""
    return (r.respuesta or "") in ("05", "06") and (r.estado_mensaje or "") not in ("rechazado", "error")


# ----------------------------------------------------------------------------- plazo
def fecha_limite(fecha_emision: str) -> date:
    """Octavo día hábil (lunes a viernes) del mes siguiente al de emisión. Feriados no se descuentan: el plazo real puede ser un
    día o dos más largo, nunca más corto."""
    f = date.fromisoformat(fecha_emision[:10])
    anio, mes = (f.year + 1, 1) if f.month == 12 else (f.year, f.month + 1)
    d, habiles = date(anio, mes, 1), 0
    while True:
        if d.weekday() < 5:
            habiles += 1
            if habiles == 8:
                return d
        d += timedelta(days=1)


# ----------------------------------------------------------------------------- lectura del XML recibido
def _t(el, tag, default=""):
    x = el.find(tag) if el is not None else None
    return (x.text or "").strip() if x is not None and x.text else default


def parsear(xml: bytes) -> dict:
    """Datos principales de un comprobante v4.4 recibido. Lanza ValueError si no es un comprobante."""
    try:
        root = etree.fromstring(xml)
    except etree.XMLSyntaxError as ex:
        raise ValueError(f"XML inválido: {ex}")
    raiz = etree.QName(root).localname
    if raiz == "MensajeHacienda":
        raise ValueError("Es la respuesta de Hacienda a un comprobante, no un comprobante")
    if raiz == "MensajeReceptor":
        raise ValueError("Es un mensaje de receptor, no un comprobante")
    tipo = TIPO_POR_RAIZ.get(raiz)
    if not tipo:
        raise ValueError(f"No es un comprobante electrónico conocido ({raiz})")
    emisor, receptor, res = root.find("{*}Emisor"), root.find("{*}Receptor"), root.find("{*}ResumenFactura")
    return {
        "tipo_documento": tipo, "clave": _t(root, "{*}Clave"), "consecutivo": _t(root, "{*}NumeroConsecutivo"),
        "fecha_emision": _t(root, "{*}FechaEmision"), "emisor_nombre": _t(emisor, "{*}Nombre"),
        "emisor_id": _t(emisor, "{*}Identificacion/{*}Numero"), "emisor_tipo_id": _t(emisor, "{*}Identificacion/{*}Tipo", "02"),
        "receptor_id": _t(receptor, "{*}Identificacion/{*}Numero"),
        "moneda": _t(res, "{*}CodigoTipoMoneda/{*}CodigoMoneda", "CRC"), "total": float(_t(res, "{*}TotalComprobante", "0") or 0),
        "impuesto": float(_t(res, "{*}TotalImpuesto", "0") or 0), "iva": _iva_de(res), "condicion_venta": _t(root, "{*}CondicionVenta") or None,
        "tipo_cambio": float(_t(res, "{*}CodigoTipoMoneda/{*}TipoCambio", "1") or 1),
        "referencia_clave": (_t(root, "{*}InformacionReferencia/{*}Numero") or None) if tipo in ("02", "03") else None,
    }


def _iva_de(res) -> float:
    """IVA del comprobante recibido: el desglose del código 01 (sin Selectivo de Consumo ni impuestos específicos). Sin desglose
    (comprobantes viejos) se toma el TotalImpuesto, como antes (3.41)."""
    if res is None:
        return 0.0
    desg = res.findall("{*}TotalDesgloseImpuesto")
    if not desg:
        return float(_t(res, "{*}TotalImpuesto", "0") or 0)
    return round(sum(float(_t(d, "{*}TotalMontoImpuesto", "0") or 0) for d in desg if (_t(d, "{*}Codigo") or "01") == "01"), 5)


def lineas_xml(xml: bytes) -> list[dict]:
    """Líneas de detalle de un comprobante recibido (3.75): código del proveedor, CABYS, detalle, cantidad, unidad, precio,
    descuento, subtotal e IVA de cada una, con el costo unitario neto (subtotal ÷ cantidad) en la moneda del comprobante.
    Acepta v4.4 (CodigoCABYS) y v4.3 (Codigo)."""
    root = etree.fromstring(xml)
    out = []
    for n, ld in enumerate(root.findall("{*}DetalleServicio/{*}LineaDetalle"), start=1):
        cant = float(_t(ld, "{*}Cantidad", "0") or 0)
        monto = float(_t(ld, "{*}MontoTotal", "0") or 0)
        desc = sum(float(_t(d, "{*}MontoDescuento", "0") or 0) for d in ld.findall("{*}Descuento"))
        sub_txt = _t(ld, "{*}SubTotal")
        sub = float(sub_txt) if sub_txt else round(monto - desc, 5)
        tarifa = codigo_tarifa = iva = None
        for imp in ld.findall("{*}Impuesto"):
            if (_t(imp, "{*}Codigo") or "01") == "01":
                tarifa = float(_t(imp, "{*}Tarifa", "0") or 0)
                codigo_tarifa = _t(imp, "{*}CodigoTarifaIVA") or _t(imp, "{*}CodigoTarifa") or None
                iva = float(_t(imp, "{*}Monto", "0") or 0)
                break
        codigos = [_t(cc, "{*}Codigo") for cc in ld.findall("{*}CodigoComercial")]
        try:
            numero = int(_t(ld, "{*}NumeroLinea", str(n)) or n)
        except ValueError:
            numero = n
        out.append({"numero": numero, "cabys": _t(ld, "{*}CodigoCABYS") or _t(ld, "{*}Codigo") or "", "codigo": next((c for c in codigos if c), ""),
                    "detalle": _t(ld, "{*}Detalle"), "cantidad": cant, "unidad_medida": _t(ld, "{*}UnidadMedida", "Unid") or "Unid",
                    "precio_unitario": float(_t(ld, "{*}PrecioUnitario", "0") or 0), "monto_total": monto, "descuento": round(desc, 5), "subtotal": sub,
                    "tarifa": tarifa, "codigo_tarifa": codigo_tarifa, "impuesto": iva, "total_linea": float(_t(ld, "{*}MontoTotalLinea", "0") or 0),
                    "costo_unitario": round(sub / cant, 5) if cant else 0.0})
    return out


def iva_recibido(r) -> float:
    """IVA de un recibido para acreditar y para la contabilidad: el campo iva o, en registros viejos, el impuesto total."""
    v = r.get("iva") if isinstance(r, dict) else getattr(r, "iva", None)
    if v is None:
        v = r.get("impuesto", 0) if isinstance(r, dict) else getattr(r, "impuesto", 0)
    return float(v or 0)


def rellenar_referencias(s) -> int:
    """Notas de proveedores registradas antes de guardar su referencia: se lee del XML una sola vez."""
    from lxml import etree
    from sqlmodel import select as _sel
    n = 0
    for r in s.exec(_sel(Recibido).where(Recibido.tipo_documento.in_(("02", "03")), Recibido.referencia_clave == None)).all():  # noqa: E711
        if not r.xml_nombre:
            continue
        try:
            ref = etree.fromstring((DIR_RECIBIDOS / r.xml_nombre).read_bytes()).findtext(".//{*}InformacionReferencia/{*}Numero")
        except Exception:  # noqa: BLE001
            continue
        if ref:
            r.referencia_clave = ref.strip(); s.add(r); n += 1
    if n:
        s.commit()
    return n


def rellenar_tipo_cambio(s) -> int:
    """Recibidos registrados antes de existir la columna tipo_cambio: se lee del XML una sola vez (consolidación en colones)."""
    from lxml import etree
    from sqlmodel import select as _sel
    n = 0
    for r in s.exec(_sel(Recibido).where(Recibido.moneda != "CRC")).all():
        if (r.tipo_cambio or 1) != 1 or not r.xml_nombre:
            continue
        try:
            tc = etree.fromstring((DIR_RECIBIDOS / r.xml_nombre).read_bytes()).findtext(".//{*}ResumenFactura/{*}CodigoTipoMoneda/{*}TipoCambio")
        except Exception:  # noqa: BLE001
            continue
        if tc:
            r.tipo_cambio = float(tc); s.add(r); n += 1
    if n:
        s.commit()
    return n


def registrar(s, empresa, xml: bytes, origen: str = "carga", correo_asunto: str | None = None, correo_de: str | None = None) -> tuple[Optional[Recibido], str]:
    """Guarda un comprobante recibido. Devuelve (fila, 'nuevo' | 'duplicado' | motivo de rechazo)."""
    try:
        d = parsear(xml)
    except ValueError as ex:
        return None, str(ex)
    if not d["clave"] or len(d["clave"]) != 50:
        return None, "El comprobante no trae una clave válida"
    mia = re.sub(r"[^A-Za-z0-9]", "", empresa.numero_id or "").upper()
    if re.sub(r"[^A-Za-z0-9]", "", d["receptor_id"]).upper() != mia:
        return None, f"El comprobante está dirigido a {d['receptor_id'] or 'otro receptor'}, no a esta empresa"
    if re.sub(r"[^A-Za-z0-9]", "", d["emisor_id"]).upper() == mia:
        return None, "Es un comprobante emitido por la propia empresa"
    existe = s.exec(select(Recibido).where(Recibido.empresa_id == empresa.id, Recibido.clave == d["clave"])).first()
    if existe:
        return existe, "duplicado"
    nombre = f"recibido_{empresa.id}_{d['clave']}.xml"
    (DIR_RECIBIDOS / nombre).write_bytes(xml)
    r = Recibido(empresa_id=empresa.id, xml_nombre=nombre, origen=origen, correo_asunto=correo_asunto, correo_de=correo_de,
                 fecha_limite=fecha_limite(d["fecha_emision"]).isoformat() if d["fecha_emision"] else "",
                 **{k: v for k, v in d.items() if k != "receptor_id"})
    try:                                                   # 3.69: la factura de un traslado del grupo ya tiene su compra registrada
        from .traslados import compra_por_clave
        r.compra_id = compra_por_clave(s, empresa.id, d["clave"])
    except Exception:  # noqa: BLE001
        __import__("logging").getLogger("facturacr.recepcion").exception("No se pudo buscar la compra del comprobante recibido %s", d["clave"])
    s.add(r); s.commit(); s.refresh(r)
    return r, "nuevo"


def leer_mensaje_receptor(xml: bytes) -> Optional[dict]:
    """4.1: datos del Mensaje Receptor que la empresa envió desde su sistema anterior (aceptación, parcial o rechazo); None si no es uno."""
    try:
        root = etree.fromstring(xml)
    except etree.XMLSyntaxError:
        return None
    if etree.QName(root).localname != "MensajeReceptor":
        return None
    clave = _t(root, "{*}Clave")
    if len(clave) != 50:
        return None

    def num(tag):
        v = _t(root, tag)
        try:
            return float(v) if v != "" else None
        except ValueError:
            return None
    return {"clave": clave, "mensaje": _t(root, "{*}Mensaje", "1"), "condicion": _t(root, "{*}CondicionImpuesto") or None,
            "acreditar": num("{*}MontoTotalImpuestoAcreditar"), "gasto": num("{*}MontoTotalDeGastoAplicable"), "detalle": _t(root, "{*}DetalleMensaje") or None,
            "consecutivo_receptor": _t(root, "{*}NumeroConsecutivoReceptor") or None}


def marcar_historico(r: Recibido, msg: Optional[dict], pagado: bool, clasificacion: Optional[str] = None) -> bool:
    """4.1: comprobante recibido que ya se respondió en el sistema anterior (Alegra u otro): queda aceptado (o como diga su Mensaje
    Receptor, si se subió) sin enviar nada a Hacienda, con estado «importado». Uno ya respondido desde aquí no se toca."""
    if r.respuesta and (r.estado_mensaje or "") != "importado":
        return False
    msg = msg or {}
    cod = {"1": "05", "2": "06", "3": "07"}.get(str(msg.get("mensaje") or "1").strip(), "05")
    r.respuesta = cod
    if cod in ("05", "06"):
        iva = float(iva_recibido(r) or 0)
        cond = msg.get("condicion") or ("01" if iva else None)
        r.condicion_impuesto = cond
        if msg.get("acreditar") is not None:
            r.monto_impuesto_acreditar = float(msg["acreditar"])
        else:
            r.monto_impuesto_acreditar = (0.0 if cond == "04" else iva) if cond else None
        r.monto_gasto_aplicable = float(msg["gasto"]) if msg.get("gasto") is not None else float(r.total or 0)
        r.pagado_anterior = bool(pagado)
    else:
        r.condicion_impuesto = None; r.monto_impuesto_acreditar = None; r.monto_gasto_aplicable = None; r.pagado_anterior = None
    if clasificacion in ("compra", "gasto"):
        r.clasificacion = clasificacion
    r.detalle_mensaje = (msg.get("detalle") or "Respondido en el sistema anterior")[:160]
    if msg.get("consecutivo_receptor"):                # 4.2: con el consecutivo del mensaje se puede validar en Hacienda la respuesta misma
        r.consecutivo_receptor = msg["consecutivo_receptor"]
    r.estado_mensaje = "importado"
    r.mensaje_hacienda = "Respondido en el sistema anterior: no se envía de nuevo a Hacienda"
    r.respondido_en = r.respondido_en or ahora_cr().isoformat(timespec="seconds")
    return True


TEXTO_VALIDACION = {"aceptado": "aceptado por Hacienda", "rechazado": "RECHAZADO por Hacienda", "no_encontrado": "no está en Hacienda",
                    "recibido": "en proceso en Hacienda", "procesando": "en proceso en Hacienda", "error": "con error en Hacienda"}


def validar_en_hacienda(cli, r: Recibido) -> dict:
    """4.2: confirma en Hacienda un comprobante del sistema anterior: (1) que el comprobante del proveedor exista y esté aceptado y
    (2) si se conoce el consecutivo del mensaje de receptor, que esa aceptación o rechazo también esté aceptada. Deja el resultado en
    r.validacion (JSON) y devuelve el diccionario."""
    comp = cli.consultar(r.clave)
    out = {"comprobante": comp.get("estado"), "fecha": comp.get("fecha"), "respuesta": None, "ok": False}
    resp: dict = {}
    if r.consecutivo_receptor and out["comprobante"] != "http_error":      # si ya falló la consulta del comprobante, no se insiste
        resp = cli.consultar(f"{r.clave}-{r.consecutivo_receptor}")
        out["respuesta"] = resp.get("estado")
    if out["comprobante"] == "http_error":
        out["texto"] = "No se pudo consultar: " + str(comp.get("error") or comp.get("status"))[:200]
    else:
        partes = ["Comprobante " + TEXTO_VALIDACION.get(out["comprobante"] or "", out["comprobante"] or "desconocido")]
        if out["respuesta"] == "http_error":
            partes.append("no se pudo consultar la respuesta: " + str(resp.get("error") or resp.get("status"))[:200])
        elif out["respuesta"]:
            partes.append("respuesta " + TEXTO_VALIDACION.get(out["respuesta"], out["respuesta"]))
        elif out["comprobante"] == "aceptado":
            partes.append("sin el mensaje de receptor no se puede confirmar la respuesta")
        out["texto"] = " · ".join(partes)
        out["ok"] = out["comprobante"] == "aceptado" and out["respuesta"] in (None, "aceptado")
    r.validacion = json.dumps(out, ensure_ascii=False)
    r.validado_en = ahora_cr().isoformat(timespec="seconds")
    return out


def recibido_dict(r: Recibido) -> dict:
    d = r.model_dump()
    try:
        d["validacion"] = json.loads(r.validacion) if r.validacion else None
    except ValueError:
        d["validacion"] = None
    hoy = ahora_cr().date()
    try:
        lim = date.fromisoformat(r.fecha_limite)
        d["dias_restantes"] = (lim - hoy).days
    except ValueError:
        d["dias_restantes"] = None
    d["registrado"] = esta_registrado(r)               # 4.23: siempre verdadero o falso (las pantallas y los asientos se saltan los falsos)
    d["tipo_nombre"] = NOMBRE_TIPO.get(r.tipo_documento, r.tipo_documento)
    d["respuesta_nombre"] = MENSAJES[r.respuesta][1] if r.respuesta in MENSAJES else None
    return d


# ----------------------------------------------------------------------------- mensaje receptor
def construir_mensaje_receptor(r: Recibido, empresa, mensaje: str, consecutivo_receptor: str, condicion_impuesto: str | None,
                               detalle: str | None, monto_acreditar: Decimal | None, gasto_aplicable: Decimal | None,
                               actividad: str | None) -> etree._Element:
    ns = NS_BASE + "mensajeReceptor"
    root = etree.Element(f"{{{ns}}}MensajeReceptor", nsmap={None: ns, "xsd": "http://www.w3.org/2001/XMLSchema",
                                                            "xsi": "http://www.w3.org/2001/XMLSchema-instance"})
    def sub(tag, text):
        el = etree.SubElement(root, f"{{{ns}}}{tag}"); el.text = str(text); return el
    sub("Clave", r.clave)
    sub("NumeroCedulaEmisor", r.emisor_id)
    sub("FechaEmisionDoc", ahora_cr().isoformat(timespec="seconds"))
    sub("Mensaje", MENSAJES[mensaje][0])
    if detalle:
        sub("DetalleMensaje", detalle[:160])
    if r.impuesto:
        sub("MontoTotalImpuesto", f"{Decimal(str(r.impuesto)):.5f}")
    if mensaje in ("05", "06"):
        if actividad:
            sub("CodigoActividad", actividad)
        if condicion_impuesto:
            sub("CondicionImpuesto", condicion_impuesto)
        if monto_acreditar is not None:
            sub("MontoTotalImpuestoAcreditar", f"{monto_acreditar:.5f}")
        if gasto_aplicable is not None:
            sub("MontoTotalDeGastoAplicable", f"{gasto_aplicable:.5f}")
    sub("TotalFactura", f"{Decimal(str(r.total)):.5f}")
    sub("NumeroCedulaReceptor", re.sub(r"[^A-Za-z0-9]", "", empresa.numero_id or "").upper())
    sub("NumeroConsecutivoReceptor", consecutivo_receptor)
    return root


# ----------------------------------------------------------------------------- buzón IMAP
def _carpeta_imap(nombre: str) -> str:
    """Nombre de carpeta IMAP entre comillas y en UTF-7 modificado (espacios y tildes fallaban o daban 500) (R143)."""
    import base64
    out, buf = [], []
    def vaciar():
        if buf:
            b = base64.b64encode("".join(buf).encode("utf-16-be")).decode().rstrip("=").replace("/", ",")
            out.append("&" + b + "-"); buf.clear()
    for ch in nombre:
        if ch == "&":
            vaciar(); out.append("&-")
        elif 0x20 <= ord(ch) <= 0x7E:
            vaciar(); out.append(ch)
        else:
            buf.append(ch)
    vaciar()
    return '"' + "".join(out).replace("\\", "\\\\").replace('"', '\\"') + '"'


def leer_buzon(empresa, password: str, dias: int = 60, limite: int = 200) -> dict:
    """Lee el buzón IMAP de la empresa y devuelve los XML adjuntos (bytes) con asunto y remitente. No marca ni borra correos:
    los duplicados se descartan por clave al registrarlos."""
    host, puerto = empresa.imap_host, int(empresa.imap_puerto or 993)
    seg = (empresa.imap_seguridad or "ssl").lower()
    ctx = ssl.create_default_context()
    try:
        if seg == "ssl":
            M = imaplib.IMAP4_SSL(host, puerto, ssl_context=ctx, timeout=40)
        else:
            M = imaplib.IMAP4(host, puerto, timeout=40)
            if seg == "starttls":
                M.starttls(ssl_context=ctx)
        M.login(empresa.imap_usuario, password)
    except imaplib.IMAP4.error as ex:
        raise RuntimeError(f"El servidor rechazó el usuario o la contraseña del buzón ({ex})")
    except (OSError, ssl.SSLError) as ex:
        raise RuntimeError(f"No se pudo conectar con {host}:{puerto} ({ex}). Revise servidor, puerto y seguridad")
    try:
        typ, _ = M.select(_carpeta_imap(empresa.imap_carpeta or "INBOX"), readonly=True)
        if typ != "OK":
            raise RuntimeError(f"No existe la carpeta {empresa.imap_carpeta or 'INBOX'} en el buzón")
        desde = (ahora_cr().date() - timedelta(days=dias)).strftime("%d-%b-%Y")
        typ, datos = M.search(None, f'(SINCE {desde})')
        ids = datos[0].split() if typ == "OK" and datos and datos[0] else []
        adjuntos, correos = [], 0
        for uid in ids[-limite:]:
            typ, partes = M.fetch(uid, "(RFC822)")
            if typ != "OK" or not partes or not isinstance(partes[0], tuple):
                continue
            msg = email.message_from_bytes(partes[0][1])
            correos += 1
            asunto = _decodificar(msg.get("Subject")); de = _decodificar(msg.get("From"))
            for parte in msg.walk():
                nombre = parte.get_filename()
                if not nombre:
                    continue
                nombre_l = _decodificar(nombre).lower()
                datos_adj = parte.get_payload(decode=True) or b""
                if nombre_l.endswith(".xml"):
                    adjuntos.append({"xml": datos_adj, "asunto": asunto, "de": de, "archivo": nombre_l})
                elif nombre_l.endswith(".zip"):
                    import io, zipfile
                    try:
                        with zipfile.ZipFile(io.BytesIO(datos_adj)) as z:
                            for n in z.namelist():
                                if n.lower().endswith(".xml") and z.getinfo(n).file_size < 2_000_000:
                                    adjuntos.append({"xml": z.read(n), "asunto": asunto, "de": de, "archivo": n.lower()})
                    except zipfile.BadZipFile:
                        continue
        return {"correos": correos, "adjuntos": adjuntos}
    finally:
        try:
            M.logout()
        except Exception:  # noqa: BLE001
            pass


def _decodificar(v) -> str:
    if not v:
        return ""
    try:
        from email.header import decode_header, make_header
        return str(make_header(decode_header(v)))
    except Exception:  # noqa: BLE001
        return str(v)


def procesar_adjuntos(s, empresa, adjuntos: list[dict]) -> dict:
    nuevos, duplicados, descartados = 0, 0, []
    for a in adjuntos:
        r, res = registrar(s, empresa, a["xml"], origen="correo", correo_asunto=a.get("asunto"), correo_de=a.get("de"))
        if res == "nuevo":
            nuevos += 1
        elif res == "duplicado":
            duplicados += 1
        elif "respuesta de Hacienda" in res or "mensaje de receptor" in res:
            continue                                # acompañan a las facturas: no son un problema
        else:
            descartados.append(f"{a.get('archivo', 'xml')}: {res}")
    return {"nuevos": nuevos, "duplicados": duplicados, "descartados": descartados[:20]}
