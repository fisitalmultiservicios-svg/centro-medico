"""Comercio avanzado (3.49, fase 3 de la fusión con FISITAAP): modificadores de platos, cupones, fidelización por puntos y tarjetas
de regalo. Sirven a la caja (punto de venta) y al catálogo público de pedidos en línea.

- Modificadores: grupos de opciones (tamaño, extras, término) con mínimo y máximo de opciones y precio por opción. Viven en el
  registro `pos_modificadores` y cada ítem indica sus grupos en `items_extra[id].modificadores`. El servidor los valida y los
  cobra en los pedidos en línea; la caja los pide al agregar el plato.
- Cupones: código con porcentaje o monto, mínimo de compra, vigencia, usos máximos y usos por cliente, válidos en caja, en línea o
  en ambos. Cada uso queda registrado (CuponUso) con su referencia.
- Fidelización: puntos por cada ₡1.000 de compra (configurable) y canje a un valor por punto. Un solo saldo por teléfono del
  cliente (en línea) o por cliente de la empresa (caja). Los movimientos quedan en MovimientoPuntos.
- Tarjetas de regalo: código con saldo, vencimiento y movimientos. Se venden en la caja (el dinero entra ese día; no es venta
  gravada hasta que se consume) y se usan como medio de pago en la caja o en el carrito en línea."""
import json
import secrets
from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from . import modulos
from .auth import Contexto, limitar_ip, requiere, sesion_empresa, solo_pos, solo_pos
from .config import ahora_cr
from .db import por_empresa, sesion_de

router = APIRouter(tags=["promociones"])


def r2(x) -> float:
    return round(float(x or 0) + 1e-9, 2)


def gestion(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    """3.87: crear, cambiar o borrar cupones, configurar la fidelización, regalar puntos y listar, recargar o anular tarjetas de
    regalo es de quien administra ítems y precios ('catalogos'). La caja ('pos') valida y usa cupones, acredita y canjea puntos, y
    vende y cobra con tarjetas: el Cajero ya no se crea un cupón del 100 % ni se salta el descuento máximo de su caja."""
    ctx.exigir("catalogos")
    return ctx


def sin_cajero(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    """4.5: la lista de cupones (todos los códigos con su valor), los usos de un cupón y los clientes con puntos son de quien administra
    las promociones; esas pantallas no se abren en modo cajero. La caja valida y usa cupones por código y consulta el saldo de un cliente."""
    if solo_pos(ctx.permisos):
        raise HTTPException(403, "Su rol no tiene acceso a las listas de promociones")
    return ctx


def _hoy() -> str:
    return ahora_cr().date().isoformat()


# ------------------------------------------------------------------------------------------------- tablas
class Cupon(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    codigo: str = Field(index=True)              # mayúsculas, sin espacios
    nombre: str = ""
    tipo: str = "pct"                            # pct | monto
    valor: float = 0
    minimo: float = 0                            # compra mínima (con impuestos)
    tope: Optional[float] = None                 # descuento máximo cuando es porcentaje
    desde: Optional[str] = None                  # AAAA-MM-DD
    hasta: Optional[str] = None
    usos_max: Optional[int] = None               # vacío = sin límite
    usos_cliente: Optional[int] = None           # por teléfono o cliente
    usados: int = 0
    canales: str = "caja,online"
    activo: bool = True
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class CuponUso(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cupon_id: int = Field(index=True)
    quien: str = ""                              # teléfono del cliente final o «cliente:<id>»
    referencia: str = ""                         # pedido:<id> o doc:<consecutivo>
    monto: float = 0
    canal: str = "online"
    fecha: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class FidelizacionConfig(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    activo: bool = False
    puntos_por_mil: float = 1                    # puntos por cada ₡1.000 de compra (sin envío)
    valor_punto: float = 10                      # colones de descuento por punto al canjear
    minimo_canje: int = 100                      # puntos mínimos para canjear
    maximo_pct: float = 50                       # porcentaje máximo de la compra que se paga con puntos
    vencen_meses: int = 0                        # 0 = no vencen
    nombre: str = "Puntos"


class MovimientoPuntos(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    quien: str = Field(index=True)               # teléfono (8 dígitos) o «cliente:<id>»
    nombre: str = ""
    puntos: float = 0                            # + acumula, − canjea
    motivo: str = ""
    referencia: str = ""
    fecha: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    usuario: str = ""


class TarjetaRegalo(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    codigo: str = Field(index=True)
    monto_inicial: float = 0
    saldo: float = 0
    comprador: str = ""
    beneficiario: str = ""
    telefono: str = ""
    mensaje: str = ""
    vence: Optional[str] = None
    activa: bool = True
    movimientos: str = "[]"                      # JSON [{fecha, tipo venta|canje|recarga|ajuste, monto, referencia, usuario}]
    creada: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    usuario: str = ""


por_empresa(Cupon, CuponUso, FidelizacionConfig, MovimientoPuntos, TarjetaRegalo)


# ------------------------------------------------------------------------------------------------- modificadores (registros)
def grupos_modificadores(s: Session, eid: int) -> dict:
    """{id: grupo} de pos_modificadores: [{id, nombre, minimo, maximo, opciones: [{id, nombre, precio}], activo}]."""
    out = {}
    for g in modulos.leer(s, eid, "pos_modificadores", []) or []:
        if isinstance(g, dict) and g.get("id") is not None and g.get("activo", True) is not False:
            out[int(g["id"])] = g
    return out


def grupos_de_producto(s: Session, eid: int, pid: int, grupos: Optional[dict] = None, categoria: Optional[str] = None) -> list:
    """Grupos del ítem: los asignados en el ítem (items_extra) más los que FISITAAP asignó al producto o a su categoría (3.74)."""
    grupos = grupos if grupos is not None else grupos_modificadores(s, eid)
    ex = (modulos.leer(s, eid, "items_extra", {}) or {}).get(str(pid)) or {}
    ids = [int(g) for g in (ex.get("modificadores") or []) if int(g) in grupos]
    if categoria is None:
        from .db import Producto
        p = s.get(Producto, pid)
        categoria = (p.categoria or "") if p else ""
    for gid, g in grupos.items():
        if gid in ids:
            continue
        if pid in [int(x) for x in (g.get("productos") or []) if str(x).lstrip("-").isdigit()] or (categoria and categoria in [str(c) for c in (g.get("categorias") or [])]):
            ids.append(gid)
    return [grupos[g] for g in ids]


def resolver_opciones(grupos_prod: list, ids: list) -> tuple[list, float]:
    """Valida las opciones elegidas contra los grupos del ítem (mínimos y máximos) y devuelve [(grupo, opción)] y el extra sin IVA."""
    elegidas = []; extra = 0.0; ids = [int(x) for x in (ids or [])]
    for g in grupos_prod:
        ops = [o for o in (g.get("opciones") or []) if isinstance(o, dict) and int(o.get("id", -1)) in ids]
        mn, mx = int(g.get("minimo") or 0), int(g.get("maximo") or 0)
        if len(ops) < mn:
            raise HTTPException(400, f"Elija al menos {mn} opción(es) de «{g.get('nombre')}»")
        if mx and len(ops) > mx:
            raise HTTPException(400, f"«{g.get('nombre')}» admite máximo {mx} opción(es)")
        for o in ops:
            elegidas.append({"grupo": g.get("nombre"), "nombre": o.get("nombre"), "precio": float(o.get("precio") or 0), "id": int(o["id"])}); extra += float(o.get("precio") or 0)
    validos = {int(o["id"]) for g in grupos_prod for o in (g.get("opciones") or []) if isinstance(o, dict) and "id" in o}
    if any(i not in validos for i in ids):
        raise HTTPException(400, "Una de las opciones elegidas ya no existe; revise el carrito")
    return elegidas, r2(extra)


def texto_opciones(opciones: list) -> str:
    return ", ".join(o["nombre"] for o in opciones) if opciones else ""


# ------------------------------------------------------------------------------------------------- cupones
def cupon_por_codigo(s: Session, eid: int, codigo: str) -> Optional[Cupon]:
    c = (codigo or "").strip().upper().replace(" ", "")
    return s.exec(select(Cupon).where(Cupon.empresa_id == eid, Cupon.codigo == c)).first() if c else None


def evaluar_cupon(s: Session, eid: int, codigo: str, subtotal: float, canal: str, quien: str = "") -> tuple[Cupon, float]:
    """Cupón válido para ese canal, fecha, mínimo y usos → (cupón, descuento). Lanza 400 con el motivo si no aplica."""
    c = cupon_por_codigo(s, eid, codigo)
    if not c or not c.activo:
        raise HTTPException(400, "El cupón no existe o está inactivo")
    hoy = _hoy()
    if c.desde and hoy < c.desde:
        raise HTTPException(400, "El cupón todavía no está vigente")
    if c.hasta and hoy > c.hasta:
        raise HTTPException(400, "El cupón venció")
    if canal not in (c.canales or "caja,online").split(","):
        raise HTTPException(400, "El cupón no aplica en este canal")
    if c.usos_max is not None and c.usados >= c.usos_max:
        raise HTTPException(400, "El cupón ya se agotó")
    if c.usos_cliente and quien:
        n = len(s.exec(select(CuponUso).where(CuponUso.empresa_id == eid, CuponUso.cupon_id == c.id, CuponUso.quien == quien)).all())
        if n >= c.usos_cliente:
            raise HTTPException(400, "Ya usó este cupón el máximo de veces")
    if subtotal < float(c.minimo or 0):
        raise HTTPException(400, f"El cupón pide una compra mínima de ₡{float(c.minimo):,.0f}".replace(",", "."))
    desc = subtotal * float(c.valor) / 100 if c.tipo == "pct" else float(c.valor)
    if c.tipo == "pct" and c.tope:
        desc = min(desc, float(c.tope))
    return c, r2(min(desc, subtotal))


def registrar_uso(s: Session, eid: int, c: Cupon, quien: str, referencia: str, monto: float, canal: str):
    s.add(CuponUso(empresa_id=eid, cupon_id=c.id, quien=quien or "", referencia=referencia, monto=r2(monto), canal=canal)); c.usados += 1; s.add(c); s.commit()


def anular_uso(s: Session, eid: int, referencia: str):
    for u in s.exec(select(CuponUso).where(CuponUso.empresa_id == eid, CuponUso.referencia == referencia)).all():
        c = s.get(Cupon, u.cupon_id)
        if c and c.usados > 0:
            c.usados -= 1; s.add(c)
        s.delete(u)
    s.commit()


def _salida_cupon(c: Cupon) -> dict:
    return {k: getattr(c, k) for k in ("id", "codigo", "nombre", "tipo", "valor", "minimo", "tope", "desde", "hasta", "usos_max", "usos_cliente", "usados", "canales", "activo", "creado")}


class CuponIn(BaseModel):
    codigo: str = PField(min_length=3, max_length=20)
    nombre: Optional[str] = PField("", max_length=80)
    tipo: str = "pct"
    valor: float = PField(gt=0, le=1e7)
    minimo: float = PField(0, ge=0, le=1e8)
    tope: Optional[float] = PField(None, ge=0, le=1e8)
    desde: Optional[str] = None
    hasta: Optional[str] = None
    usos_max: Optional[int] = PField(None, ge=1, le=1000000)
    usos_cliente: Optional[int] = PField(None, ge=1, le=1000)
    canales: list[str] = ["caja", "online"]
    activo: bool = True


def _limpiar_cupon(data: CuponIn) -> dict:
    cod = data.codigo.strip().upper().replace(" ", "")
    if not cod.isalnum():
        raise HTTPException(400, "El código del cupón solo lleva letras y números")
    if data.tipo not in ("pct", "monto"):
        raise HTTPException(400, "Tipo de cupón desconocido")
    if data.tipo == "pct" and data.valor > 100:
        raise HTTPException(400, "El porcentaje no puede pasar de 100")
    canales = [c for c in data.canales if c in ("caja", "online")] or ["caja", "online"]
    return {"codigo": cod, "nombre": (data.nombre or "").strip()[:80], "tipo": data.tipo, "valor": r2(data.valor), "minimo": r2(data.minimo), "tope": r2(data.tope) if data.tope else None,
            "desde": (data.desde or None), "hasta": (data.hasta or None), "usos_max": data.usos_max, "usos_cliente": data.usos_cliente, "canales": ",".join(canales), "activo": data.activo}


@router.get("/api/cupones")
def cupones(ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5: la caja valida por código (/api/cupones/validar), no lee la lista
    return [_salida_cupon(c) for c in s.exec(select(Cupon).where(Cupon.empresa_id == ctx.empresa.id).order_by(Cupon.activo.desc(), Cupon.id.desc())).all()]


@router.post("/api/cupones")
def crear_cupon(data: CuponIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    d = _limpiar_cupon(data)
    if cupon_por_codigo(s, ctx.empresa.id, d["codigo"]):
        raise HTTPException(400, f"Ya existe el cupón {d['codigo']}")
    c = Cupon(empresa_id=ctx.empresa.id, **d); s.add(c); s.commit(); s.refresh(c)
    return _salida_cupon(c)


@router.put("/api/cupones/{cid}")
def editar_cupon(cid: int, data: CuponIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    c = s.get(Cupon, cid)
    if not c or c.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Cupón no encontrado")
    d = _limpiar_cupon(data)
    otro = cupon_por_codigo(s, ctx.empresa.id, d["codigo"])
    if otro and otro.id != cid:
        raise HTTPException(400, f"Ya existe el cupón {d['codigo']}")
    for k, v in d.items():
        setattr(c, k, v)
    s.add(c); s.commit(); s.refresh(c)
    return _salida_cupon(c)


@router.delete("/api/cupones/{cid}")
def borrar_cupon(cid: int, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    c = s.get(Cupon, cid)
    if not c or c.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Cupón no encontrado")
    if c.usados:
        c.activo = False; s.add(c); s.commit()
        return {"ok": True, "desactivado": True, "mensaje": "El cupón ya se usó: se desactivó en vez de borrarse"}
    s.delete(c); s.commit()
    return {"ok": True}


class ValidarCuponIn(BaseModel):
    codigo: str = PField(min_length=1, max_length=20)
    subtotal: float = PField(ge=0)
    cliente_id: Optional[int] = None
    telefono: Optional[str] = None


class UsarCuponIn(ValidarCuponIn):
    referencia: str = PField(min_length=1, max_length=80)


def _quien(cliente_id, telefono) -> str:
    if telefono:
        import re
        t = re.sub(r"\D", "", telefono)[-8:]
        if t:
            return t
    return f"cliente:{cliente_id}" if cliente_id else ""


@router.post("/api/cupones/validar")
def validar_cupon(data: ValidarCuponIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    c, desc = evaluar_cupon(s, ctx.empresa.id, data.codigo, data.subtotal, "caja", _quien(data.cliente_id, data.telefono))
    return {"cupon": _salida_cupon(c), "descuento": desc}


@router.post("/api/cupones/usar")
def usar_cupon(data: UsarCuponIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """La caja registra el uso al cobrar (la referencia es el consecutivo del tiquete)."""
    quien = _quien(data.cliente_id, data.telefono)
    c, desc = evaluar_cupon(s, ctx.empresa.id, data.codigo, data.subtotal, "caja", quien)
    registrar_uso(s, ctx.empresa.id, c, quien, data.referencia, desc, "caja")
    return {"ok": True, "descuento": desc, "usados": c.usados}


@router.get("/api/cupones/{cid}/usos")
def usos_cupon(cid: int, ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5
    return [{"quien": u.quien, "referencia": u.referencia, "monto": u.monto, "canal": u.canal, "fecha": u.fecha} for u in s.exec(select(CuponUso).where(CuponUso.empresa_id == ctx.empresa.id, CuponUso.cupon_id == cid).order_by(CuponUso.id.desc())).all()[:500]]


# ------------------------------------------------------------------------------------------------- fidelización
def config_fid(s: Session, eid: int) -> FidelizacionConfig:
    c = s.exec(select(FidelizacionConfig).where(FidelizacionConfig.empresa_id == eid)).first()
    if not c:
        c = FidelizacionConfig(empresa_id=eid); s.add(c); s.commit(); s.refresh(c)
    return c


def saldo_puntos(s: Session, eid: int, quien: str) -> float:
    if not quien:
        return 0.0
    return r2(sum(m.puntos for m in s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == eid, MovimientoPuntos.quien == quien)).all()))


def acreditar(s: Session, eid: int, quien: str, monto: float, referencia: str, nombre: str = "", usuario: str = "") -> float:
    """Puntos ganados por una compra (sin envío). Idempotente por referencia."""
    cfg = config_fid(s, eid)
    if not cfg.activo or not quien or monto <= 0:
        return 0.0
    if s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == eid, MovimientoPuntos.referencia == referencia, MovimientoPuntos.puntos > 0)).first():
        return 0.0
    puntos = r2(monto / 1000 * float(cfg.puntos_por_mil or 0))
    if puntos <= 0:
        return 0.0
    s.add(MovimientoPuntos(empresa_id=eid, quien=quien, nombre=nombre or "", puntos=puntos, motivo="Compra", referencia=referencia, usuario=usuario)); s.commit()
    return puntos


def canjear(s: Session, eid: int, quien: str, puntos: float, total: float, referencia: str, nombre: str = "", usuario: str = "") -> float:
    """Descuenta puntos y devuelve el descuento en colones (valida saldo, mínimo y porcentaje máximo)."""
    cfg = config_fid(s, eid)
    if not cfg.activo:
        raise HTTPException(400, "El programa de puntos no está activo")
    puntos = float(puntos or 0)
    if puntos <= 0:
        return 0.0
    if puntos < float(cfg.minimo_canje or 0):
        raise HTTPException(400, f"El canje mínimo es {int(cfg.minimo_canje)} puntos")
    if puntos > saldo_puntos(s, eid, quien) + 1e-6:
        raise HTTPException(400, "No tiene suficientes puntos")
    desc = r2(puntos * float(cfg.valor_punto or 0))
    tope = r2(total * float(cfg.maximo_pct or 100) / 100)
    if desc > tope + 0.005:
        raise HTTPException(400, f"Con puntos solo se puede pagar hasta el {cfg.maximo_pct:.0f} % de la compra (₡{tope:,.0f})".replace(",", "."))
    s.add(MovimientoPuntos(empresa_id=eid, quien=quien, nombre=nombre or "", puntos=-puntos, motivo="Canje", referencia=referencia, usuario=usuario)); s.commit()
    return desc


def revertir(s: Session, eid: int, referencia: str):
    for m in s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == eid, MovimientoPuntos.referencia == referencia)).all():
        s.delete(m)
    s.commit()


def _salida_cfg(c: FidelizacionConfig) -> dict:
    return {k: getattr(c, k) for k in ("activo", "puntos_por_mil", "valor_punto", "minimo_canje", "maximo_pct", "vencen_meses", "nombre")}


class FidelizacionIn(BaseModel):
    activo: bool = False
    puntos_por_mil: float = PField(1, ge=0, le=1000)
    valor_punto: float = PField(10, ge=0, le=100000)
    minimo_canje: int = PField(100, ge=0, le=1000000)
    maximo_pct: float = PField(50, ge=1, le=100)
    vencen_meses: int = PField(0, ge=0, le=120)
    nombre: Optional[str] = PField("Puntos", max_length=30)


class PuntosIn(BaseModel):
    cliente_id: Optional[int] = None
    telefono: Optional[str] = None
    nombre: Optional[str] = PField("", max_length=80)
    monto: Optional[float] = PField(None, ge=0)     # acreditar: monto de la compra; canjear: total de la compra
    puntos: Optional[float] = PField(None, ge=0)    # canjear o ajuste manual (puede ser negativo en ajuste)
    referencia: str = PField("", max_length=80)
    motivo: Optional[str] = PField("", max_length=120)


class AjusteIn(BaseModel):
    cliente_id: Optional[int] = None
    telefono: Optional[str] = None
    nombre: Optional[str] = PField("", max_length=80)
    puntos: float = PField(ge=-1e7, le=1e7)          # negativo quita puntos
    referencia: Optional[str] = PField("", max_length=80)
    motivo: Optional[str] = PField("", max_length=120)


@router.get("/api/fidelizacion/config")
def fid_config(ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    return _salida_cfg(config_fid(s, ctx.empresa.id))


@router.put("/api/fidelizacion/config")
def fid_guardar(data: FidelizacionIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    c = config_fid(s, ctx.empresa.id)
    for k, v in data.model_dump().items():
        setattr(c, k, (v or "Puntos") if k == "nombre" else v)
    s.add(c); s.commit(); s.refresh(c)
    return _salida_cfg(c)


@router.get("/api/fidelizacion/saldo")
def fid_saldo(cliente_id: Optional[int] = None, telefono: Optional[str] = None, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    q = _quien(cliente_id, telefono)
    cfg = config_fid(s, ctx.empresa.id); saldo = saldo_puntos(s, ctx.empresa.id, q)
    return {"quien": q, "saldo": saldo, "valor": r2(saldo * float(cfg.valor_punto or 0)), "config": _salida_cfg(cfg),
            "movimientos": [{"fecha": m.fecha, "puntos": m.puntos, "motivo": m.motivo, "referencia": m.referencia} for m in s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == ctx.empresa.id, MovimientoPuntos.quien == q).order_by(MovimientoPuntos.id.desc())).all()[:50]] if q else []}


def _compra_de_la_caja(s: Session, eid: int, q: str, data: PuntosIn) -> float:
    """3.87: la caja acredita puntos por una compra que existe: el comprobante (referencia «doc:<consecutivo>», con el cliente de ese
    comprobante) o el pedido en línea («pedido:<id>», con su teléfono). Devuelve el monto acreditable, con tope en el total de esa
    compra. Sin una compra que lo respalde, 403: los puntos de regalo son el ajuste manual de quien administra los ítems."""
    tipo, _, ref = (data.referencia or "").strip().partition(":")
    monto = float(data.monto or 0)
    if tipo == "doc" and ref:
        from .db import Cliente, Documento
        d = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.consecutivo == ref, Documento.tipo_documento.in_(("01", "04", "09")),
                                           Documento.estado != "rechazado").order_by(Documento.id.desc())).first()
        c = s.get(Cliente, d.cliente_id) if d and d.cliente_id else None
        if not d or not c or c.empresa_id != eid:
            raise HTTPException(400, "No se encontró esa venta con cliente: los puntos se acreditan al cobrar en la caja")
        if q not in {f"cliente:{c.id}"} | {_quien(None, str(t)) for t in (c.celular, c.telefono) if t}:
            raise HTTPException(400, "Los puntos de una venta son del cliente de esa venta")
        return min(monto, r2(float(d.total or 0) * (float(d.tipo_cambio or 1) if (d.moneda or "CRC") != "CRC" else 1)))
    if tipo == "pedido" and ref.isdigit():
        from .pedidos import Pedido
        p = s.get(Pedido, int(ref))
        if not p or p.empresa_id != eid or p.estado == "cancelado":
            raise HTTPException(400, "No se encontró ese pedido")
        if q != _quien(None, p.telefono):
            raise HTTPException(400, "Los puntos de un pedido son del teléfono de ese pedido")
        return min(monto, r2(p.total or 0))
    raise HTTPException(403, "La caja acredita puntos solo por una venta o un pedido; para regalar puntos use el ajuste manual (lo hace quien administra los ítems)")


def _cuenta_del_pedido(s: Session, eid: int, referencia: str) -> str:
    """3.87: «pedido:<id>»: quién gana los puntos de ese pedido en línea (pedidos.telefono_puntos: el acceso con que se hizo; de invitado,
    el teléfono del pedido). La caja manda el teléfono de la cuenta en espera, que es el escrito en el formulario. Otra referencia: ""."""
    tipo, _, ref = (referencia or "").strip().partition(":")
    if tipo != "pedido" or not ref.isdigit():
        return ""
    from .pedidos import Pedido, telefono_puntos
    p = s.get(Pedido, int(ref))
    return _quien(None, telefono_puntos(s, p)) if p and p.empresa_id == eid else ""


def _pedido_lo_premia_la_web(eid: int) -> bool:
    """4.32 (§4.5): en el programa con el canal nuevo, los puntos de un pedido en línea los acredita la web al enlazar su cobro; la caja
    del programa no escribe nada (si no, se darían dos veces)."""
    from . import pedidos
    return pedidos.en_programa_v2(eid)


@router.post("/api/fidelizacion/acreditar")
def fid_acreditar(data: PuntosIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    q = _quien(data.cliente_id, data.telefono)
    if not q:
        raise HTTPException(400, "Indique el cliente o su teléfono")
    if str(data.referencia or "").startswith("pedido:") and _pedido_lo_premia_la_web(ctx.empresa.id):
        return {"puntos": 0, "saldo": saldo_puntos(s, ctx.empresa.id, q)}   # 4.32 (§4.5): los puntos del pedido en línea los da la web
    if not ctx.puede("catalogos"):                 # 3.87: el Cajero ya no se regala puntos con una «compra» inventada
        data.monto = _compra_de_la_caja(s, ctx.empresa.id, q, data)
    q = _cuenta_del_pedido(s, ctx.empresa.id, data.referencia) or q   # 3.87: los de un pedido en línea, a la cuenta con que se pidió
    p = acreditar(s, ctx.empresa.id, q, float(data.monto or 0), data.referencia or f"caja:{secrets.token_hex(4)}", data.nombre or "", ctx.usuario.correo or "")
    return {"puntos": p, "saldo": saldo_puntos(s, ctx.empresa.id, q)}


@router.post("/api/fidelizacion/canjear")
def fid_canjear(data: PuntosIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    q = _quien(data.cliente_id, data.telefono)
    if not q:
        raise HTTPException(400, "Indique el cliente o su teléfono")
    desc = canjear(s, ctx.empresa.id, q, float(data.puntos or 0), float(data.monto or 0), data.referencia or f"caja:{secrets.token_hex(4)}", data.nombre or "", ctx.usuario.correo or "")
    return {"descuento": desc, "saldo": saldo_puntos(s, ctx.empresa.id, q)}


@router.post("/api/fidelizacion/ajuste")
def fid_ajuste(data: AjusteIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    """Ajuste manual (regalo de bienvenida, corrección); puntos negativos para quitar."""
    q = _quien(data.cliente_id, data.telefono)
    if not q or not data.puntos:
        raise HTTPException(400, "Indique el cliente y los puntos")
    s.add(MovimientoPuntos(empresa_id=ctx.empresa.id, quien=q, nombre=data.nombre or "", puntos=r2(data.puntos), motivo=(data.motivo or "Ajuste").strip(), referencia=data.referencia or "", usuario=ctx.usuario.correo or "")); s.commit()
    return {"saldo": saldo_puntos(s, ctx.empresa.id, q)}


@router.get("/api/fidelizacion/clientes")
def fid_clientes(ctx: Contexto = Depends(sin_cajero), s: Session = Depends(sesion_empresa)):   # 4.5: la caja consulta un saldo (/api/fidelizacion/saldo), no la lista de clientes
    tot: dict = {}
    for m in s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == ctx.empresa.id)).all():
        o = tot.setdefault(m.quien, {"quien": m.quien, "nombre": m.nombre, "saldo": 0.0, "ganados": 0.0, "canjeados": 0.0, "ultimo": m.fecha})
        o["saldo"] = r2(o["saldo"] + m.puntos); o["ganados" if m.puntos > 0 else "canjeados"] = r2(o["ganados" if m.puntos > 0 else "canjeados"] + abs(m.puntos)); o["ultimo"] = max(o["ultimo"], m.fecha); o["nombre"] = o["nombre"] or m.nombre
    return sorted(tot.values(), key=lambda x: -x["saldo"])[:500]


# ------------------------------------------------------------------------------------------------- tarjetas de regalo
def _codigo_tarjeta() -> str:
    alfa = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "GF-" + "".join(secrets.choice(alfa) for _ in range(4)) + "-" + "".join(secrets.choice(alfa) for _ in range(4))


def tarjeta_por_codigo(s: Session, eid: int, codigo: str) -> Optional[TarjetaRegalo]:
    c = (codigo or "").strip().upper().replace(" ", "")
    return s.exec(select(TarjetaRegalo).where(TarjetaRegalo.empresa_id == eid, TarjetaRegalo.codigo == c)).first() if c else None


def _mov(t: TarjetaRegalo, tipo: str, monto: float, referencia: str, usuario: str = ""):
    ms = json.loads(t.movimientos or "[]"); ms.append({"fecha": ahora_cr().isoformat(timespec="seconds"), "tipo": tipo, "monto": r2(monto), "referencia": referencia, "usuario": usuario}); t.movimientos = json.dumps(ms[-200:], ensure_ascii=False)


def tarjeta_vigente(t: Optional[TarjetaRegalo]) -> TarjetaRegalo:
    if not t or not t.activa:
        raise HTTPException(400, "La tarjeta de regalo no existe o está anulada")
    if t.vence and _hoy() > t.vence:
        raise HTTPException(400, "La tarjeta de regalo venció")
    if t.saldo <= 0:
        raise HTTPException(400, "La tarjeta de regalo no tiene saldo")
    return t


def consumir_tarjeta(s: Session, eid: int, codigo: str, monto: float, referencia: str, usuario: str = "") -> float:
    """Descuenta del saldo hasta `monto` y devuelve lo aplicado."""
    t = tarjeta_vigente(tarjeta_por_codigo(s, eid, codigo))
    aplicado = r2(min(float(monto or 0), t.saldo))
    if aplicado <= 0:
        return 0.0
    t.saldo = r2(t.saldo - aplicado); _mov(t, "canje", -aplicado, referencia, usuario); s.add(t); s.commit()
    return aplicado


def devolver_tarjeta(s: Session, eid: int, codigo: str, monto: float, referencia: str):
    t = tarjeta_por_codigo(s, eid, codigo)
    if t and monto > 0:
        t.saldo = r2(t.saldo + monto); _mov(t, "devolucion", monto, referencia); s.add(t); s.commit()


def _salida_tarjeta(t: TarjetaRegalo, completa: bool = True) -> dict:
    d = {"codigo": t.codigo, "saldo": t.saldo, "vence": t.vence, "activa": t.activa, "beneficiario": t.beneficiario}
    if completa:
        d |= {"id": t.id, "monto_inicial": t.monto_inicial, "comprador": t.comprador, "telefono": t.telefono, "mensaje": t.mensaje, "creada": t.creada, "usuario": t.usuario, "movimientos": json.loads(t.movimientos or "[]")}
    return d


class TarjetaIn(BaseModel):
    monto: float = PField(gt=0, le=1e7)
    comprador: Optional[str] = PField("", max_length=80)
    beneficiario: Optional[str] = PField("", max_length=80)
    telefono: Optional[str] = PField("", max_length=20)
    mensaje: Optional[str] = PField("", max_length=200)
    meses_vigencia: int = PField(12, ge=0, le=120)
    codigo: Optional[str] = PField(None, max_length=20)   # vacío = se genera
    medio: Optional[str] = PField(None, max_length=5)      # 4.5: medio con que se cobró en la caja (01 efectivo, 02 tarjeta…), para el movimiento
    cuenta: Optional[str] = PField(None, max_length=80)    # 4.5: cuenta de Bancos donde entra el dinero: el servidor registra el cobro con la tarjeta


class MontoIn(BaseModel):
    monto: float = PField(gt=0, le=1e7)
    referencia: str = PField("", max_length=80)


@router.get("/api/tarjetas")
def tarjetas(ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    return [_salida_tarjeta(t) for t in s.exec(select(TarjetaRegalo).where(TarjetaRegalo.empresa_id == ctx.empresa.id).order_by(TarjetaRegalo.id.desc())).all()[:500]]


@router.post("/api/tarjetas")
def crear_tarjeta(data: TarjetaIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    cod = (data.codigo or "").strip().upper().replace(" ", "") or _codigo_tarjeta()
    while tarjeta_por_codigo(s, eid, cod):
        if data.codigo:
            raise HTTPException(400, f"Ya existe la tarjeta {cod}")
        cod = _codigo_tarjeta()
    vence = (ahora_cr() + timedelta(days=30 * data.meses_vigencia)).date().isoformat() if data.meses_vigencia else None
    t = TarjetaRegalo(empresa_id=eid, codigo=cod, monto_inicial=r2(data.monto), saldo=r2(data.monto), comprador=(data.comprador or "").strip()[:80], beneficiario=(data.beneficiario or "").strip()[:80],
                      telefono=(data.telefono or "").strip()[:20], mensaje=(data.mensaje or "").strip()[:200], vence=vence, usuario=ctx.usuario.correo or "")
    # 4.5: la tarjeta queda activa solo con el cobro registrado. Con `cuenta`, el dinero entra a Bancos en la misma transacción
    # (ref pos:regalo:<código>, la que caja.js registraba aparte DESPUÉS de crearla): si el movimiento falla, no hay tarjeta. Quien
    # solo opera la caja no la crea sin cuenta; quien administra (Promociones › Tarjetas, FISITAAP) sigue creándolas sin cobro.
    cuenta = (data.cuenta or "").strip()
    if not cuenta and solo_pos(ctx.permisos):
        raise HTTPException(400, "Para vender una tarjeta de regalo desde la caja indique la cuenta de Bancos del medio de pago (Punto de venta › Configuración)")
    _mov(t, "venta", data.monto, f"{data.medio or ''} {cuenta}".strip(), ctx.usuario.correo or ""); s.add(t); s.flush()
    if cuenta:
        try:
            ok = modulos.registrar_movimiento_banco(s, eid, cuenta, data.monto, _hoy(), f"Venta de tarjeta de regalo {cod}", f"pos:regalo:{cod}", False, "CRC", 1)
        except ValueError as ex:
            s.rollback()
            raise HTTPException(400, str(ex))
        if not ok:                              # cuenta inexistente: nada se escribió; se descarta la tarjeta pendiente
            s.rollback()
            raise HTTPException(400, f"La cuenta «{cuenta}» no existe en Bancos: la tarjeta no se vendió")
    s.commit(); s.refresh(t)
    return _salida_tarjeta(t)


@router.get("/api/tarjetas/{codigo}")
def ver_tarjeta(codigo: str, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    t = tarjeta_por_codigo(s, ctx.empresa.id, codigo)
    if not t:
        raise HTTPException(404, "Tarjeta no encontrada")
    return _salida_tarjeta(t, completa=not solo_pos(ctx.permisos))   # 4.5: la caja cobra con código, saldo y vigencia; comprador, teléfono y movimientos son de quien administra


@router.post("/api/tarjetas/{codigo}/canjear")
def canjear_tarjeta(codigo: str, data: MontoIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    aplicado = consumir_tarjeta(s, ctx.empresa.id, codigo, data.monto, data.referencia or "caja", ctx.usuario.correo or "")
    t = tarjeta_por_codigo(s, ctx.empresa.id, codigo)
    return {"aplicado": aplicado, "saldo": t.saldo if t else 0}


@router.post("/api/tarjetas/{codigo}/recargar")
def recargar_tarjeta(codigo: str, data: MontoIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    t = tarjeta_por_codigo(s, ctx.empresa.id, codigo)
    if not t or not t.activa:
        raise HTTPException(404, "Tarjeta no encontrada o anulada")
    t.saldo = r2(t.saldo + data.monto); _mov(t, "recarga", data.monto, data.referencia or "caja", ctx.usuario.correo or ""); s.add(t); s.commit(); s.refresh(t)
    return _salida_tarjeta(t)


@router.delete("/api/tarjetas/{codigo}")
def anular_tarjeta(codigo: str, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    t = tarjeta_por_codigo(s, ctx.empresa.id, codigo)
    if not t:
        raise HTTPException(404, "Tarjeta no encontrada")
    t.activa = False; _mov(t, "anulacion", 0, "", ctx.usuario.correo or ""); s.add(t); s.commit()
    return {"ok": True}


# ------------------------------------------------------------------------------------------------- público (catálogo en línea)
class CuponPublicoIn(BaseModel):
    codigo: str = PField(min_length=1, max_length=20)
    subtotal: float = PField(ge=0)
    telefono: Optional[str] = PField(None, max_length=20)


@router.post("/api/publico/{slug}/cupon")
def cupon_publico(slug: str, data: CuponPublicoIn, request: Request):
    from .auth import _ip
    from .pedidos import _publico
    e, eid = _publico(slug)
    # 3.87: el tope es por negocio Y por conexión: antes era uno solo por negocio y 30 consultas de cualquiera dejaban sin cupones a todos
    limitar_ip(request, clave="pedidos", maximo=30, ventana=600, sujeto=f"cupon:{eid}:{_ip(request) or '?'}", mensaje="Demasiados intentos con cupones. Espere unos minutos.")
    with sesion_de(eid) as s:
        c, desc = evaluar_cupon(s, eid, data.codigo, data.subtotal, "online", _quien(None, data.telefono))
        return {"codigo": c.codigo, "nombre": c.nombre, "descuento": desc, "tipo": c.tipo, "valor": c.valor}


@router.get("/api/publico/{slug}/tarjeta/{codigo}")
def tarjeta_publica(slug: str, codigo: str, request: Request):
    from .auth import _ip
    from .pedidos import _publico
    e, eid = _publico(slug)
    limitar_ip(request, clave="pedidos", maximo=20, ventana=600, sujeto=f"tarjeta:{eid}:{_ip(request) or '?'}", mensaje="Demasiados intentos. Espere unos minutos.")   # 3.87: por conexión
    with sesion_de(eid) as s:
        t = tarjeta_vigente(tarjeta_por_codigo(s, eid, codigo))
        return _salida_tarjeta(t, completa=False)


@router.get("/api/publico/{slug}/puntos")
def puntos_publico(slug: str, x_cliente: str | None = Header(default=None)):
    from .pedidos import _publico, _cliente
    e, eid = _publico(slug)
    with sesion_de(eid) as s:
        c = _cliente(s, eid, x_cliente); cfg = config_fid(s, eid); saldo = saldo_puntos(s, eid, c.telefono)
        return {"activo": cfg.activo, "nombre": cfg.nombre, "saldo": saldo, "valor": r2(saldo * float(cfg.valor_punto or 0)), "minimo_canje": cfg.minimo_canje, "maximo_pct": cfg.maximo_pct, "valor_punto": cfg.valor_punto, "puntos_por_mil": cfg.puntos_por_mil,
                "movimientos": [{"fecha": m.fecha, "puntos": m.puntos, "motivo": m.motivo} for m in s.exec(select(MovimientoPuntos).where(MovimientoPuntos.empresa_id == eid, MovimientoPuntos.quien == c.telefono).order_by(MovimientoPuntos.id.desc())).all()[:30]]}
