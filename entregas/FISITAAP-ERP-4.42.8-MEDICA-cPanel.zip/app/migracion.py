"""Migraciones al arrancar.

1. Si la base central todavía contiene las tablas de negocio (clientes, productos, documentos, inventario...) de la
   versión anterior, copia las filas de cada empresa a su base propia `data/empresas/empresa_<id>.db` y renombra las
   tablas centrales a `_migrada_<tabla>` (no se borran, por seguridad).
2. Garantiza que toda empresa tenga clave de cifrado y cifra los secretos que estén en texto plano.
"""
import logging
from pathlib import Path

from sqlalchemy import inspect, text
from sqlmodel import Session, select

from . import secretos
from .db import TABLAS_EMPRESA, Empresa, engine, engine_empresa

log = logging.getLogger(__name__)


def _empresa_de_fila(tabla: str, fila: dict, conn, cache: dict) -> int | None:
    if "empresa_id" in fila and fila["empresa_id"] is not None:
        return int(fila["empresa_id"])
    if tabla == "documentolinea":
        return cache.setdefault(("doc", fila["documento_id"]),
                                conn.execute(text("SELECT empresa_id FROM documento WHERE id=:i"), {"i": fila["documento_id"]}).scalar())
    if tabla == "existencia":
        return cache.setdefault(("bod", fila["bodega_id"]),
                                conn.execute(text("SELECT empresa_id FROM bodega WHERE id=:i"), {"i": fila["bodega_id"]}).scalar())
    return 1


def mover_tablas_de_negocio():
    insp = inspect(engine)
    existentes = set(insp.get_table_names())
    pendientes = [t for t in TABLAS_EMPRESA if t.name in existentes]
    if not pendientes:
        return
    log.warning("Migrando %d tablas de negocio a bases por empresa", len(pendientes))
    copiadas: dict[int, dict[str, int]] = {}
    with engine.begin() as conn:
        for tabla in pendientes:
            cols = [c["name"] for c in insp.get_columns(tabla.name)]
            filas = [dict(zip(cols, r)) for r in conn.execute(text(f"SELECT {', '.join(cols)} FROM {tabla.name}")).fetchall()]
            cache: dict = {}
            por_empresa: dict[int, list] = {}
            for f in filas:
                eid = _empresa_de_fila(tabla.name, f, conn, cache)
                if eid:
                    por_empresa.setdefault(eid, []).append(f)
            for eid, lote in por_empresa.items():
                eng = engine_empresa(eid)
                n = 0
                with eng.begin() as ce:
                    for f in lote:
                        datos = {}
                        for col in tabla.columns:
                            if col.name not in f:
                                continue
                            v = f[col.name]
                            if v is None and not col.nullable:
                                # columnas agregadas por migraciones anteriores quedaron NULL: usar el valor por defecto
                                d = col.default.arg if col.default is not None and getattr(col.default, "is_scalar", False) else None
                                if d is None:
                                    continue
                                v = d
                            datos[col.name] = v
                        if ce.execute(text(f"INSERT OR IGNORE INTO {tabla.name} ({', '.join(datos)}) VALUES ({', '.join(':' + k for k in datos)})"), datos).rowcount:
                            n += 1
                if n != len(lote):
                    log.error("Empresa %s tabla %s: %d de %d filas copiadas", eid, tabla.name, n, len(lote))
                copiadas.setdefault(eid, {})[tabla.name] = n
        for tabla in pendientes:
            conn.execute(text(f"ALTER TABLE {tabla.name} RENAME TO _migrada_{tabla.name}"))
    for eid, det in copiadas.items():
        log.warning("Empresa %s: %s", eid, det)


def cifrar_secretos(cert_dir: Path):
    with Session(engine) as s:
        for e in s.exec(select(Empresa)).all():
            try:
                if secretos.cifrar_secretos_empresa(e, cert_dir):
                    s.add(e)
            except Exception as ex:  # noqa: BLE001  una empresa con datos dañados no frena a las demás (R171)
                log.exception("Empresa %s: no se pudieron cifrar sus secretos: %s", e.id, ex)
        s.commit()


def ejecutar(cert_dir: Path):
    try:
        mover_tablas_de_negocio()
    except Exception as ex:          # no impedir el arranque; se reintenta en el siguiente
        log.exception("Fallo migrando tablas de negocio: %s", ex)
    try:
        cifrar_secretos(cert_dir)
    except Exception as ex:  # noqa: BLE001
        log.exception("Fallo cifrando secretos: %s", ex)
    with Session(engine) as s:
        for e in s.exec(select(Empresa)).all():
            try:
                engine_empresa(e.id)     # asegura que cada empresa tenga su base creada
            except Exception as ex:  # noqa: BLE001  base dañada: la app arranca para las demás (R171)
                log.exception("Empresa %s: no se pudo abrir su base: %s", e.id, ex)
