"""Exportación masiva de una empresa (reglamento 44739-H art. 5.4: el proveedor de sistemas debe permitir la descarga de todo lo
emitido y recibido; y para el cliente que se va): un ZIP con los XML firmados, las respuestas de Hacienda, los XML recibidos y sus
mensajes receptor, opcionalmente los PDF, y tablas CSV (comprobantes, líneas, clientes, productos, pagos, recibidos, inventario)
más los registros de los módulos comerciales en JSON."""
import csv
import io
import json
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from sqlmodel import select

from .config import ahora_cr
from .db import Cliente, Documento, DocumentoLinea, Producto
from . import inventario as inv, modulos, recepcion, resumen

TIPOS = {"01": "Factura electrónica", "02": "Nota de débito", "03": "Nota de crédito", "04": "Tiquete electrónico",
         "08": "Factura electrónica de compra", "09": "Factura de exportación", "10": "Recibo electrónico de pago"}


def _csv(filas: list[dict]) -> bytes:
    """CSV con ; y BOM (lo abre Excel en español sin preguntar)."""
    if not filas:
        return "﻿".encode("utf-8")
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=list(filas[0].keys()), delimiter=";", lineterminator="\r\n")
    w.writeheader(); w.writerows(filas)
    return ("﻿" + out.getvalue()).encode("utf-8")


def _fila(obj, quitar=()) -> dict:
    """Columnas en el orden en que están definidas en el modelo (model_dump de una tabla cargada no lo garantiza)."""
    d = obj.model_dump()
    orden = [k for k in type(obj).model_fields if k in d and k not in quitar] + [k for k in d if k not in type(obj).model_fields and k not in quitar]
    out = {}
    for k in orden:
        v = d[k]
        out[k] = v.isoformat(timespec="seconds") if isinstance(v, datetime) else v
    return out


MAX_DOCS = 100          # comprobantes por exportación (R324)


def generar_zip(s, empresa, xml_dir: Path, desde: Optional[str], hasta: Optional[str], con_pdf: bool = False,
                render_pdf: Optional[Callable[[Documento], bytes]] = None, ambiente: Optional[str] = None, permisos: Optional[set] = None,
                traer: Optional[Callable[[list], dict]] = None, xml_traidos: Optional[dict] = None) -> bytes:
    """4.25 (X3): `traer(docs)` (en el programa local, sinc.traer_archivos_lote) trae de la web los XML que faltan antes de recorrer
    los comprobantes; su resultado ({faltaban, traidos, sin_traer, motivo, por_clave}) se copia en `xml_traidos` si se pasa, y el motivo
    de cada uno que no llegó va a FALTANTES.txt. Al que no llegó tampoco se le arma el PDF (no se vuelve a intentar la bajada)."""
    buf = io.BytesIO()
    desde, hasta = desde or "0000-00-00", hasta or "9999-12-31"
    en_rango = lambda f: desde <= (f or "")[:10] <= hasta
    ambiente = ambiente or empresa.ambiente                       # solo el ambiente activo: pruebas y producción no se mezclan (R165)
    faltantes: list[str] = []
    docs = [d for d in s.exec(select(Documento).where(Documento.empresa_id == empresa.id, Documento.ambiente == ambiente)).all() if en_rango(d.fecha_emision)]
    if len(docs) > MAX_DOCS:                                     # el ZIP y los PDF se arman en memoria en una sola petición (R324)
        raise ValueError(f"El período abarca {len(docs)} comprobantes y la exportación admite hasta {MAX_DOCS}: acorte el rango de fechas y exporte por partes")
    docs.sort(key=lambda d: (d.fecha_emision, d.id))
    ids = {d.id for d in docs}
    traido: dict = {}
    if traer is not None:
        try:
            traido = traer(docs) or {}
        except Exception:  # noqa: BLE001  sin los XML viejos la exportación sale igual, con lo que hay
            traido = {}
    if xml_traidos is not None:
        xml_traidos.update(traido)
    motivos = traido.get("por_clave") or {}
    _por = lambda d: f"; {motivos[d.clave]}" if d.clave in motivos else ""
    linea_traidos = (f"\nXML traídos de la web para esta exportación: {int(traido.get('traidos') or 0)}; sin traer: {int(traido.get('sin_traer') or 0)}"
                     + (" (están anotados en FALTANTES.txt).\n" if traido.get("sin_traer") else ".\n")) if traido.get("faltaban") else ""
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("LEEME.txt", (
            f"Exportación de {empresa.nombre} ({empresa.numero_id}) generada el {ahora_cr().strftime('%d/%m/%Y %H:%M')} (hora de Costa Rica)\n"
            f"Periodo: {desde} a {hasta} · Ambiente: {ambiente}\n"
            "El periodo aplica a los comprobantes emitidos y recibidos (carpetas emitidos/, recibidos/ y sus CSV); clientes, productos, "
            "bodegas, existencias y registros se exportan completos.\n\n"
            "emitidos/      XML firmados de los comprobantes emitidos (nombre: consecutivo_clave.xml) y la respuesta de Hacienda (_respuesta.xml)"
            + (" y el PDF\n" if con_pdf else "\n") +
            "recibidos/     XML de comprobantes de proveedores y los mensajes de receptor enviados a Hacienda (mensajes/)\n"
            "csv/           comprobantes, lineas, clientes, productos, pagos, recibidos, bodegas, existencias, movimientos (separador ;)\n"
            "registros/     cotizaciones, compras, bancos, contabilidad y demás módulos, en JSON\n"
            "empresa.json   datos públicos de la empresa (sin contraseñas ni llaves)\n"
            "Los comprobantes electrónicos deben conservarse al menos 5 años (Reglamento 44739-H, art. 22).\n" + linea_traidos))
        for d in docs:
            if d.xml_nombre and (xml_dir / d.xml_nombre).exists():
                z.write(xml_dir / d.xml_nombre, f"emitidos/{d.consecutivo}_{d.clave}.xml")
            elif d.xml_nombre:
                faltantes.append(f"{d.consecutivo} ({d.clave}): falta el XML {d.xml_nombre}{_por(d)}")    # (R173)
            if d.respuesta_nombre and (xml_dir / d.respuesta_nombre).exists():
                z.write(xml_dir / d.respuesta_nombre, f"emitidos/{d.consecutivo}_{d.clave}_respuesta.xml")   # con la clave: no se sobrescriben (R165)
            elif d.respuesta_nombre:
                faltantes.append(f"{d.consecutivo} ({d.clave}): falta la respuesta {d.respuesta_nombre}{_por(d)}")
            if con_pdf and render_pdf and d.xml_nombre and d.clave in motivos and not (xml_dir / d.xml_nombre).exists():
                faltantes.append(f"{d.consecutivo} ({d.clave}): sin PDF porque falta el XML")      # 4.25: no se vuelve a intentar la bajada
            elif con_pdf and render_pdf and d.xml_nombre:
                try:
                    z.writestr(f"emitidos/{d.consecutivo}_{d.clave}.pdf", render_pdf(d))
                except Exception as ex:  # noqa: BLE001
                    z.writestr(f"emitidos/{d.consecutivo}_{d.clave}.pdf.error.txt", str(ex))
        recibidos = [r for r in s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == empresa.id)).all() if en_rango(r.fecha_emision)]
        for r in recibidos:
            p = recepcion.DIR_RECIBIDOS / r.xml_nombre
            if p.exists():
                z.write(p, f"recibidos/{r.consecutivo or r.clave}_{r.clave}.xml")
            else:
                faltantes.append(f"recibido {r.clave}: falta el XML {r.xml_nombre}")
            if r.mensaje_xml_nombre and (recepcion.DIR_RECIBIDOS / r.mensaje_xml_nombre).exists():
                z.write(recepcion.DIR_RECIBIDOS / r.mensaje_xml_nombre, f"recibidos/mensajes/{r.mensaje_xml_nombre}")
        z.writestr("csv/comprobantes.csv", _csv([{**_fila(d, ("xml_nombre", "respuesta_nombre")), "tipo_nombre": TIPOS.get(d.tipo_documento, d.tipo_documento),
                                                  "total_otros_cargos": resumen.otros_cargos_de(d)} for d in docs]))
        lineas = s.exec(select(DocumentoLinea)).all() if ids else []
        z.writestr("csv/lineas.csv", _csv([_fila(l) for l in lineas if l.documento_id in ids]))
        z.writestr("csv/clientes.csv", _csv([_fila(c) for c in s.exec(select(Cliente).where(Cliente.empresa_id == empresa.id)).all()]))
        z.writestr("csv/productos.csv", _csv([_fila(p, ("imagen",)) for p in s.exec(select(Producto).where(Producto.empresa_id == empresa.id)).all()]))
        z.writestr("csv/pagos.csv", _csv([{**_fila(p), } for p in s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == empresa.id)).all() if en_rango(p.fecha)]))
        z.writestr("csv/recibidos.csv", _csv([_fila(r, ("xml_nombre", "mensaje_xml_nombre")) for r in recibidos]))
        z.writestr("csv/recurrentes.csv", _csv([_fila(r) for r in s.exec(select(modulos.Recurrente).where(modulos.Recurrente.empresa_id == empresa.id)).all()]))
        for nombre, modelo in (("bodegas", inv.Bodega), ("existencias", inv.Existencia), ("movimientos_inventario", inv.MovimientoInventario)):
            try:
                filas = s.exec(select(modelo).where(modelo.empresa_id == empresa.id)).all()
            except Exception:  # noqa: BLE001  modelos sin empresa_id
                filas = s.exec(select(modelo)).all()
            z.writestr(f"csv/{nombre}.csv", _csv([_fila(x) for x in filas]))
        datos_reg, _ = modulos.leer_todo(s, empresa.id)
        from .auth import puede_leer_registro
        for clave, valor in datos_reg.items():
            if permisos is not None and not puede_leer_registro(permisos, clave):        # RRHH y contabilidad solo con su permiso (R129)
                faltantes.append(f"registros/{clave}.json: omitido (su rol no tiene acceso)"); continue
            z.writestr(f"registros/{clave}.json", json.dumps(valor, ensure_ascii=False, indent=1).encode("utf-8"))
        if faltantes:
            z.writestr("FALTANTES.txt", "Comprobantes o registros que no se pudieron incluir:\n" + "\n".join(faltantes) + "\n")
        pub = {k: v for k, v in empresa.model_dump().items() if k not in ("password_hacienda", "p12_pin", "smtp_password", "imap_password", "clave_cifrada", "p12_nombre")}
        for k, v in pub.items():
            if isinstance(v, datetime):
                pub[k] = v.isoformat(timespec="seconds")
        z.writestr("empresa.json", json.dumps(pub, ensure_ascii=False, indent=2))
    return buf.getvalue()
