# -*- coding: utf-8 -*-
"""4.32 (bloque B1, lado programa): el canal nuevo de datos entre el programa (FE_MODO_LOCAL=1) y la página web.

El diseño está en scratchpad/exe432/reingenieria_432.md (§2.6 a §2.10) y la forma exacta en contrato_432.md (§2, §3.2, §3.3, §4, §5).
La declaración de cada dato (Dato, declarar, huella y las tres tablas) es de app/sinc_datos.py; aquí está lo que hace el programa:

- La COLA (`sinc_cambio`): `anotar` la llama el oyente de app/sinc_datos.py en modo réplica, dentro de la transacción del guardado
  (before_commit), con el contenido de antes y el de después. Arma la operación (alta, cambio por grupo con [antes, después, cuándo],
  baja o copia) y la funde con la que ya está abierta para ese dato: por dato hay como mucho una abierta; una que ya salió («enviada»)
  no cambia nunca (I10) y lo que venga después abre otra.
- El HILO propio (`iniciar_hilo`), aparte del ciclo viejo de sinc.py: cada `siguiente_en` segundos (o antes, si una pantalla dejó algo
  en la cola; nunca menos de 2 s entre llamadas) hace UNA ida y vuelta `POST /api/sinc/datos`: manda las operaciones y recibe el goteo
  desde su cursor. Con un candado por empresa.
- `aplicar_canonico`: la única función que escribe aquí lo que viene de la web (I8). Solo aplica una versión mayor que la que ya tiene,
  comprobado dentro de la transacción que escribe (I2); no pisa un grupo con una operación propia sin veredicto (I3); una lápida
  quita el dato con la regla de baja de su declaración (I7: nada con lápida revive solo); la ausencia no es eliminación (I9).
- La PAUSA única: si la web contesta 404 o 405 en /datos (interruptor FE_SINC_DATOS=0, o una web 4.31 donde el POST cae en los archivos
  fijos) o si /api/sinc/catalogo no trae `datos_v2: true`, el programa sigue en protocolo 2 (guarda aquí y encola) y vuelve a probar
  cada SEGUNDOS_PAUSA. Sin vuelta a los caminos 4.31.
- La ÉPOCA mínima: si la web ya vio números de esta autora que aquí no están (respaldo restaurado en el programa), se estrena otra
  época antes de mandar nada; si cambia la época de la web (respaldo restaurado en la web), se relee desde 0 aceptando lo de la web
  salvo los grupos con operación pendiente, y lo que difería queda en `sinc_pisado` (motivo «programa_anterior»).

Sin protocolo guardado (0) nada de esto actúa: el programa es la 4.31. Ni el token, ni los cuerpos, ni los detalles de una respuesta de
error van al registro (log) ni al estado: solo el tipo del error o el código HTTP (reglas, l.37)."""
import importlib
import json
import logging
import os
import random
import secrets
import string
import threading
import time
from datetime import date, datetime, timezone
from typing import Optional

import httpx
from fastapi import HTTPException
from httpx import ConnectError, ConnectTimeout
from sqlalchemy import Date as _TipoFecha
from sqlalchemy import DateTime as _TipoFechaHora
from sqlalchemy import text as _sql
from sqlmodel import Session, select

from . import modulos
from . import sinc_diario as diario
from .db import engine, engine_empresa

log = logging.getLogger(__name__)

CLAVE_ESTADO = "sinc_datos_estado"
RUTA_DATOS, RUTA_FILAS, RUTA_ACCION = "/api/sinc/datos", "/api/sinc/datos/filas", "/api/sinc/datos/accion"
PROTOCOLO = 2
VERSION_PROTOCOLO = "4.32"
ABIERTA, ENVIADA, HECHA, RECHAZADA = "abierta", "enviada", "hecha", "rechazada"
TOPE_OPS = 100                       # contrato §2.2: hasta 100 ops por llamada
TOPE_BYTES = 900_000                 # y el cuerpo hasta 1 MB (margen para el resto del cuerpo)
SEGUNDOS_MINIMO = 2                  # nunca dos llamadas seguidas con menos de esto (plan §2.6)
SEGUNDOS_OCIOSO = 15                 # si la web no dijo otra cosa
SEGUNDOS_SIN_CONEXION = 15           # sin internet: vuelve a probar
SEGUNDOS_ERROR = 30                  # 5xx, respuesta inesperada, sin acceso
SEGUNDOS_PAUSA = max(5, int(os.environ.get("FE_DATOS_PAUSA_SEGUNDOS", "60") or 60))       # contrato §5: en pausa prueba otra vez cada 60 s
SEGUNDOS_PROBAR = max(60, int(os.environ.get("FE_DATOS_PROBAR_SEGUNDOS", "1800") or 1800))  # sin protocolo: cada cuánto se prueba si la web ya tiene /datos
RECORDAR_CANAL = 60                  # 4.35: la web dijo que tiene el canal nuevo y la última subida esperaba el candado: en este rato no se le vuelve a preguntar
SEGUNDOS_SIN_VINCULAR = 60           # empresa sin conectar: cada cuánto se revisa si ya se conectó
SEGUNDOS_ESTACION = 120              # estacion_viva: una pantalla corrió la pasada de la estación en los últimos 120 s
SEGUNDOS_ULTIMO_OK = 60              # «ultimo_ok» se guarda como mucho cada 60 s (no escribir la base en cada vuelta de 5 s)
INTENTOS_FILA = 5                    # una fila del goteo que falla 5 veces seguidas se salta (con registro), para no trabar el cursor
PLAZO_LLAMADA = 20                   # plan §2.6: Timeout(20, connect=3); 2 s de conexión si ya se sabe que no hay internet
PLAZO_ACCION = 15                    # contrato §3.2: Timeout(15, connect=2 o 4)
SEGUNDOS_REINTENTAR = 15             # (I-2) la web contestó «reintentar»: las ops vuelven a salir después de esto, el doble cada vez...
SEGUNDOS_REINTENTAR_MAX = 300        # ... hasta 5 minutos (el goteo de bajada sigue a su ritmo)
ESTADOS_FINALES = ("aplicado", "fusionado", "rechazado", "repetido", "renumerar")   # contrato §2.2; cualquier otro («reintentar») NO es veredicto
DIAS_COLA, DIAS_PISADO, TOPE_PISADO = 30, 365, 5000
QUEDO_WEB, PERDIO_AQUI = "la página web", "esta computadora"
_LETRAS = string.ascii_lowercase + string.digits
_SIN_CAMBIO = object()


class SinConexionWeb(Exception):
    """No se pudo conectar: la web NO recibió nada."""


class SinRespuestaWeb(Exception):
    """Se conectó y no contestó a tiempo: la web PUDO recibirla."""


# ======================================================================================================================
# Ayudas
# ======================================================================================================================
def _sd():
    from . import sinc_datos            # app/sinc_datos.py (P1): Dato, DATOS, huella y las tablas; se importa al usarlo (evita el ciclo)
    return sinc_datos


def _sinc():
    from . import sinc
    return sinc


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _version() -> str:
    """La versión de este programa (solo para Salud en la web; hasta 20 caracteres)."""
    try:
        return (_sinc()._version_sistema() or VERSION_PROTOCOLO)[:20]
    except Exception:  # noqa: BLE001
        return VERSION_PROTOCOLO


def _hora_local() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def _texto(x) -> str:
    return json.dumps(x, ensure_ascii=False, default=str)


def _json(texto, defecto=None):
    try:
        return json.loads(texto) if texto not in (None, "") else defecto
    except (TypeError, ValueError):
        return defecto


def _igual(a, b) -> bool:
    return json.dumps(_normal(a), sort_keys=True, default=str) == json.dumps(_normal(b), sort_keys=True, default=str)


def _normal(x):
    """Como la huella del contrato (§1.5): un float entero vale lo mismo que el int (1500.0 == 1500)."""
    if isinstance(x, float) and x.is_integer():
        return int(x)
    if isinstance(x, dict):
        return {k: _normal(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_normal(v) for v in x]
    return x


def _iso(x):
    if isinstance(x, (datetime, date)):
        return x.isoformat()
    return str(x)


def _resolver(f):
    """Una función, o «modulo.funcion» de app/ (contrato §1.1)."""
    if f is None or callable(f):
        return f
    modulo, _, nombre = str(f).rpartition(".")
    return getattr(importlib.import_module(f"app.{modulo}"), nombre)


def _forma(d) -> str:
    if d.forma:
        return d.forma
    if d.modelo is not None:
        return "fila"
    return "parte" if d.partir else "elemento"


def _pasa(d, contenido) -> bool:
    if contenido is None:
        return False
    f = _resolver(d.filtro)
    if f is None:
        return True
    try:
        return bool(f(contenido))
    except Exception:  # noqa: BLE001  un filtro que falla no deja salir nada
        return False


def _dueno(d, ref: str, contenido) -> Optional[int]:
    f = d.dueno_de
    if f == "rango":
        try:
            return int(ref) // modulos.RANGO
        except (TypeError, ValueError):
            return None
    f = _resolver(f)
    try:
        return int(f(contenido or {})) if f else None
    except Exception:  # noqa: BLE001
        return None


def _terminal(s, eid: int) -> int:
    fila = s.connection().execute(_sql("SELECT datos FROM registro WHERE empresa_id = :e AND clave = :c ORDER BY id LIMIT 1"),
                                  {"e": eid, "c": "sinc_local"}).first()
    cfg = _json(fila[0], {}) if fila else {}
    try:
        return int((cfg or {}).get("terminal") or 0)
    except (TypeError, ValueError):
        return 0


# ======================================================================================================================
# Estado (registro de valor «sinc_datos_estado», aparte de «sinc_local»: no compite con sinc._guardar_cfg)
# ======================================================================================================================
ESTADO_INICIAL = {"protocolo": 0, "cursor": 0, "epoca": None, "epoca_web": None, "carga": None, "ultimo_ok": None,
                  "sin_conexion_desde": None, "pausa_desde": None, "pedidos_programa": False, "releyendo": False,
                  "filas_propias": False, "desfase_s": None}
_cache: dict[int, tuple[float, dict]] = {}          # {eid: (cuándo se leyó, estado)}: protocolo() lo pide el oyente en cada guardado
SEGUNDOS_CACHE = 5


def _leer_estado(s, eid: int) -> dict:
    fila = s.connection().execute(_sql("SELECT datos FROM registro WHERE empresa_id = :e AND clave = :c ORDER BY id LIMIT 1"),
                                  {"e": eid, "c": CLAVE_ESTADO}).first()
    v = _json(fila[0], {}) if fila else {}
    return {**ESTADO_INICIAL, **(v if isinstance(v, dict) else {})}


def estado(eid: int) -> dict:
    """El registro sinc_datos_estado de la empresa (contrato §4.5), con sus valores por omisión."""
    hit = _cache.get(eid)
    if hit is not None and time.monotonic() - hit[0] < SEGUNDOS_CACHE:
        return dict(hit[1])
    try:
        with Session(engine_empresa(eid)) as s:
            est = _leer_estado(s, eid)
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos: no se pudo leer el estado de la empresa %s (%s)", eid, type(ex).__name__)
        return dict(ESTADO_INICIAL)
    _cache[eid] = (time.monotonic(), est)
    return dict(est)


def olvidar(eid: int) -> None:
    """Descarta lo que se recuerda en memoria de la empresa (respaldo restaurado, pruebas)."""
    _cache.pop(eid, None); _n_web.pop(eid, None); _fallos_fila.pop(eid, None); _reintentar.pop(eid, None); _filas_despues.pop(eid, None)
    _espera_ops.pop(eid, None); _tabla_ganchos.discard(eid); _web_vieja.pop(eid, None); _canal_visto.pop(eid, None)


def _guardar_estado(eid: int, **cambios) -> dict:
    """Guarda solo esas llaves sobre el estado vigente (relee antes: otra escritura del mismo estado no se pierde)."""
    for _ in range(3):
        with Session(engine_empresa(eid)) as s:
            actual = _leer_estado(s, eid)
            nuevo = {**actual, **cambios}
            r = modulos._registro(s, eid, CLAVE_ESTADO)
            try:
                modulos.reemplazar(s, eid, CLAVE_ESTADO, nuevo, version=(r.version or 0) if r else 0)
            except modulos.ConflictoRegistro:
                s.rollback()
                continue
            _cache[eid] = (time.monotonic(), nuevo)
            return dict(nuevo)
    raise RuntimeError("no se pudo guardar el estado del canal de datos")


def protocolo(eid: int) -> int:
    """0 = como la 4.31 (el oyente no hace nada); 2 = canal nuevo. En la web siempre 0."""
    if not _sinc().MODO_LOCAL:
        return 0
    return PROTOCOLO if int(estado(eid).get("protocolo") or 0) == PROTOCOLO else 0


def en_pausa(eid: int) -> bool:
    return protocolo(eid) == PROTOCOLO and bool(estado(eid).get("pausa_desde"))


def _epoca_nueva() -> str:
    return "".join(secrets.choice(_LETRAS) for _ in range(6))


def pasar_a_protocolo_2(eid: int) -> dict:
    """Primera vez que esta computadora habla por el canal nuevo: goteo desde 0, con lo que difiera anotado como «programa_anterior»
    (plan §2.8, paso 2). Los demás pasos de la carga inicial (subida vieja, /datos/filas, reenlace) son del bloque B3/B6."""
    est = estado(eid)
    if int(est.get("protocolo") or 0) == PROTOCOLO:
        return est
    return _guardar_estado(eid, protocolo=PROTOCOLO, cursor=0, epoca=est.get("epoca") or _epoca_nueva(), epoca_web=None,
                           carga="pendiente", pausa_desde=None, releyendo=True)


# ---- en memoria, por proceso ----
_estacion: dict[int, float] = {}                    # {eid: última vez que una pantalla corrió la pasada de la estación de comandas}
_n_web: dict[int, tuple[str, int]] = {}             # {eid: (autora, n_max que contestó la web)}
_senal_no: dict[int, bool] = {}                     # {eid: True si /api/sinc/catalogo dijo que la web no tiene el canal}
_web_vieja: dict[int, dict] = {}                    # validación 4.32 (A): {eid: {"datos": 405?, "catalogo": sin la llave datos_v2?}}
_fallos_fila: dict[int, tuple[int, int]] = {}       # {eid: (versión que falla, intentos)}
_reintentar: dict[int, set] = {}                    # {eid: {(tipo, ref)}} al_aplicar que pidió volver a llamarse (contrato §3.3)
_espera_ops: dict[int, tuple[int, float]] = {}      # (I-2) {eid: (veces seguidas con «reintentar», no mandar ops antes de este monotonic)}
_tabla_ganchos: set = set()                         # eids con la tabla sinc_gancho ya creada en este proceso
_avisadas: set = set()
_despertar = threading.Event()
_candados: dict[int, threading.RLock] = {}
_candados_ciclo: dict[int, threading.Lock] = {}
_lock = threading.Lock()


def candado(eid: int) -> threading.RLock:
    """El candado por empresa con el que corre al_aplicar (contrato §3.3)."""
    with _lock:
        return _candados.setdefault(eid, threading.RLock())


def _candado_ciclo(eid: int) -> threading.Lock:
    with _lock:
        return _candados_ciclo.setdefault(eid, threading.Lock())


def marcar_estacion(eid: int) -> None:
    """La estación de comandas de una pantalla consultó sus pendientes (para estacion_viva)."""
    _estacion[eid] = time.time()


def estacion_viva(eid: int) -> bool:
    return time.time() - _estacion.get(eid, 0.0) < SEGUNDOS_ESTACION


def avisar(eid: int) -> None:
    """Una pantalla dejó algo en la cola: el hilo llama antes (respetando SEGUNDOS_MINIMO)."""
    _avisadas.add(eid)
    _despertar.set()


def senal_catalogo(eid: int, datos_v2) -> None:
    """Lo llama sinc._bajar con el campo `datos_v2` de /api/sinc/catalogo (contrato §5). Sin la señal: pausa."""
    _web_vieja.setdefault(eid, {})["catalogo"] = datos_v2 is None   # validación 4.32 (A): sin la llave = web 4.31; false = 4.32 apagada
    if protocolo(eid) != PROTOCOLO:
        return
    if datos_v2 is True:
        _senal_no.pop(eid, None)
        return
    _senal_no[eid] = True
    if not estado(eid).get("pausa_desde"):
        _guardar_estado(eid, pausa_desde=_ahora())
        log.warning("sinc_datos empresa %s: la página web no tiene el canal nuevo: en pausa (se guarda aquí y se sube después)", eid)


def claves_declaradas() -> set:
    """Los registros declarados que bajan por el canal nuevo (el _bajar viejo no los toca con el protocolo 2)."""
    try:
        return {d.registro for d in _sd().DATOS.values() if d.registro and d.viaja in ("dos", "baja")}
    except Exception:  # noqa: BLE001
        return set()


def salta_en_bajar(eid: int, clave: str) -> bool:
    """Para sinc._bajar: con el protocolo 2 un registro declarado no se escribe con lo del catálogo (lo trae el goteo)."""
    return protocolo(eid) == PROTOCOLO and clave in claves_declaradas()


# ======================================================================================================================
# B3: lo que ya viaja por el canal nuevo (los saltos de sinc.py), la pausa, la retención de comprobantes y la carga inicial
# ======================================================================================================================
def por_canal(eid: int, tipo: str) -> bool:
    """¿Este dato (p. ej. «producto», «cliente») ya viaja por /api/sinc/datos en esta empresa? Protocolo 2 y declarado. Con la empresa en
    pausa también es verdadero (en pausa no se vuelve a los caminos 4.31: plan §7)."""
    return protocolo(eid) == PROTOCOLO and _sd().dato(tipo) is not None


def registro_por_canal(eid: int, clave: str) -> bool:
    """Lo mismo para un registro (p. ej. «pos_impresoras»): protocolo 2 y algún dato declarado sobre ese registro."""
    if protocolo(eid) != PROTOCOLO:
        return False
    try:
        return any(d.registro == clave for d in _sd().DATOS.values())
    except Exception:  # noqa: BLE001
        return False


def _refs_con_op(s, tipo: str) -> set:
    return {str(r) for (r,) in s.connection().execute(_sql("SELECT ref FROM sinc_cambio WHERE tipo = :t AND estado IN (:a, :e)"),
                                                     {"t": tipo, "a": ABIERTA, "e": ENVIADA}).all()}


def _refs_lapida(s, tipo: str) -> set:
    return {str(r) for (r,) in s.connection().execute(_sql("SELECT ref FROM sinc_dato WHERE tipo = :t AND borrado"), {"t": tipo}).all()}


def filas_en_pausa(s, eid: int, tipo: str, filas: list) -> list:
    """Pausa (contrato §5): el _bajar viejo baja lo declarado SALVO lo que tiene una operación propia sin veredicto (I3) y lo que aquí ya tiene
    lápida (I7). Quien llama escribe dentro de aplicando(0), para que el oyente no lo devuelva a la cola."""
    fuera = _refs_con_op(s, tipo) | _refs_lapida(s, tipo)
    return [f for f in filas if not (isinstance(f, dict) and str(modulos._id_entero(f.get("id"))) in fuera)]


NO_ESCRIBIR = object()


def registro_en_pausa(s, eid: int, clave: str, datos):
    """Pausa: el valor del registro `clave` que manda el catálogo viejo, con lo propio pendiente conservado (elemento por elemento o llave por
    llave) y sin revivir lápidas. NO_ESCRIBIR si no se puede separar (forma «parte» con algo pendiente): ese registro espera a /datos."""
    for d in [d for d in _sd().DATOS.values() if d.registro == clave]:
        pend, lapidas = _refs_con_op(s, d.tipo), _refs_lapida(s, d.tipo)
        forma = _forma(d)
        if forma == "elemento" and isinstance(datos, list):
            lista = [x for x in datos if not (isinstance(x, dict) and str(modulos._id_entero(x.get("id"))) in (pend | lapidas))]
            for ref in sorted(pend):
                c = contenido_local(s, eid, d, ref)
                if isinstance(c, dict):
                    lista.append({**c, "id": int(ref)})
            datos = lista
        elif forma == "llave" and isinstance(datos, dict):
            nuevo = dict(datos)
            for ref in pend | lapidas:
                c = contenido_local(s, eid, d, ref) if ref in pend else None
                if c is None:
                    nuevo.pop(ref, None)
                else:
                    nuevo[ref] = c
            datos = nuevo
        elif pend:
            return NO_ESCRIBIR
    return datos


# ---- retención de comprobantes (plan §2.7 y §5.3 paso 2) ----
_retenciones: list = []


def registrar_retencion(fn) -> None:
    """Gancho para la carga inicial (B6, app/sinc_completar.py): `fn(s, eid) -> {"producto": set[int], "cliente": set[int]}` con los ítems y
    clientes cuyos comprobantes todavía no deben subir (p. ej. los del rango 0 sin veredicto). Solo corre con el protocolo 2. Una excepción del
    gancho se registra (sin datos) y no retiene nada."""
    if fn not in _retenciones:
        _retenciones.append(fn)


def ids_en_espera(s, eid: int) -> dict:
    """{"producto": ids, "cliente": ids} cuyos comprobantes esperan: un alta propia todavía en la cola (sin veredicto), más lo que digan los
    ganchos registrados."""
    out = {"producto": set(), "cliente": set()}
    for tipo, ref in s.connection().execute(_sql("SELECT tipo, ref FROM sinc_cambio WHERE op = 'alta' AND estado IN (:a, :e) "
                                                 "AND tipo IN ('producto', 'cliente')"), {"a": ABIERTA, "e": ENVIADA}).all():
        i = modulos._id_entero(ref)
        if i is not None:
            out[tipo].add(i)
    for fn in list(_retenciones):
        try:
            extra = fn(s, eid) or {}
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc_datos empresa %s: el gancho de retención falló (%s)", eid, type(ex).__name__)
            continue
        for tipo in out:
            out[tipo].update(modulos._id_entero(i) for i in (extra.get(tipo) or ()) if modulos._id_entero(i) is not None)
    return out


def web_vieja(eid: int) -> bool:
    """Validación 4.32 (A): True si la web parece una 4.31 (/datos contestó 405 o el catálogo vino sin la llave datos_v2) o si todavía no se
    sabe; False solo si la web dijo ser una 4.32 (404 en /datos con el interruptor apagado, 200, o datos_v2 presente en el catálogo)."""
    d = _web_vieja.get(eid) or {}
    return not d or any(d.values())


def documentos_en_espera(s, eid: int, docs) -> set:
    """Los ids de los comprobantes de `docs` que esperan a la vuelta siguiente (sinc._subir_documentos): usan un ítem (directo o como
    ingrediente de su receta, la lógica de sinc._sin_subir) o un cliente en espera. Así ninguna venta llega a la web con producto_id vacío.
    Sin el protocolo 2: ninguno (como la 4.31)."""
    docs = list(docs or [])
    if not docs or protocolo(eid) != PROTOCOLO:
        return set()
    fuera = set()
    if _leer_estado(s, eid).get("pausa_desde") and web_vieja(eid):
        # revisión n.º 10: en pausa la web puede ser la 4.31, que no guarda de qué pedido es un cobro (y el comprobante ya no se reenvía):
        # el cobro de un pedido en línea espera a que vuelva el canal nuevo, que sí lo enlaza.
        # Validación 4.32 (A): con la web 4.32 apagada (404 y datos_v2 = false) el cobro SÍ sube: esa web lo enlaza y ya no deja cancelarlo
        # ni rescatarlo. Sin dato todavía (recién abierto el programa), se retiene, que es lo seguro.
        fuera = {doc.id for doc in docs if getattr(doc, "pedido_id", None)}
    espera = ids_en_espera(s, eid)
    if not espera["producto"] and not espera["cliente"]:
        return fuera
    from .db import DocumentoLinea
    from . import inventario
    recs = None
    for doc in docs:
        if doc.id in fuera:
            continue
        if doc.cliente_id and int(doc.cliente_id) in espera["cliente"]:
            fuera.add(doc.id)
            continue
        pila = [int(x) for x in s.exec(select(DocumentoLinea.producto_id).where(DocumentoLinea.documento_id == doc.id)).all() if x]
        vistos = set()
        while pila:
            i = pila.pop()
            if i in vistos:
                continue
            vistos.add(i)
            if i in espera["producto"]:
                fuera.add(doc.id)
                break
            if recs is None:
                recs = inventario.recetas(s, eid)
            for ing in (recs.get(i) or {}).get("ingredientes") or []:
                j = modulos._id_entero(ing.get("producto_id")) if isinstance(ing, dict) else None
                if j:
                    pila.append(j)
    return fuera


def en_espera(eid: int) -> dict:
    """Para la franja (B7): {"cambios": ops sin veredicto, "ventas": comprobantes retenidos, "pausa": bool}. «{n} cambios y {m} ventas esperando
    a la página web» (plan §7)."""
    if protocolo(eid) != PROTOCOLO:
        return {"cambios": 0, "ventas": 0, "pausa": False}
    from .db import Documento
    with Session(engine_empresa(eid)) as s:
        n = int(s.connection().execute(_sql("SELECT COUNT(*) FROM sinc_cambio WHERE estado IN (:a, :e)"), {"a": ABIERTA, "e": ENVIADA}).scalar() or 0)
        pend = s.exec(select(Documento).where((Documento.sinc_en == None) | (Documento.sinc_estado != Documento.estado))).all()  # noqa: E711
        m = len(documentos_en_espera(s, eid, pend))
    return {"cambios": n, "ventas": m, "pausa": en_pausa(eid)}


# ---- carga inicial (plan §2.8) y /datos/filas del rango propio (§2.10) ----
TOPE_FILAS = 500                     # contrato §2.3: de 1 a 500 refs por llamada
SEGUNDOS_FILAS = 60                  # si /datos/filas falla, no se insiste antes de esto
_pasos_carga: list = []
_filas_despues: dict[int, float] = {}


def registrar_paso_carga(fn) -> None:
    """Gancho para la carga inicial (B6): `fn(eid) -> bool` corre en el estado «reenlace», después de las /filas del rango propio; True = terminó.
    Cuando todos terminan, la carga queda «hecha»."""
    if fn not in _pasos_carga:
        _pasos_carga.append(fn)


def _refs_propias(s, eid: int, terminal: int) -> list:
    """(tipo, ref) de lo de ESTE rango que la web todavía no confirmó: datos «todos» de forma fila o elemento con id del rango de la terminal,
    sin versión de la web (v = 0 o sin línea), sin lápida y sin operación propia pendiente."""
    if terminal < 1:
        return []
    lo, hi = terminal * modulos.RANGO, (terminal + 1) * modulos.RANGO
    con = s.connection()
    lineas = {(t, str(r)): (int(v or 0), bool(b)) for t, r, v, b in con.execute(_sql("SELECT tipo, ref, v, borrado FROM sinc_dato")).all()}
    pend = {(t, str(r)) for t, r in con.execute(_sql("SELECT tipo, ref FROM sinc_cambio WHERE estado IN (:a, :e)"), {"a": ABIERTA, "e": ENVIADA}).all()}
    out = []
    for d in _sd().DATOS.values():
        if d.escribe != "todos" or d.viaja not in ("dos", "sube") or _forma(d) not in ("fila", "elemento"):
            continue
        if _forma(d) == "fila":
            ids = [i for (i,) in con.execute(_sql(f'SELECT id FROM "{d.modelo.__table__.name}" WHERE id > :lo AND id < :hi ORDER BY id'),
                                             {"lo": lo, "hi": hi}).all()]
        else:
            r = modulos._registro(s, eid, d.registro)
            if r is None:
                continue
            if r.coleccion:
                ids = [i for (i,) in con.execute(_sql("SELECT item_id FROM registroitem WHERE empresa_id = :e AND clave = :c AND item_id > :lo "
                                                      "AND item_id < :hi ORDER BY item_id"), {"e": eid, "c": d.registro, "lo": lo, "hi": hi}).all()]
            else:
                lista = _json(r.datos, [])
                ids = sorted(i for i in (modulos._id_entero(x.get("id")) for x in (lista if isinstance(lista, list) else []) if isinstance(x, dict))
                             if i is not None and lo < i < hi)
        for i in ids:
            k = (d.tipo, str(i))
            linea = lineas.get(k)
            if k in pend or (linea and (linea[0] > 0 or linea[1])):
                continue
            out.append(k)
    return out


def _paso_filas(eid: int, url: str, token: str, terminal: int) -> bool:
    """Plan §2.8 paso 4 y §2.10: pregunta con /datos/filas por lo propio sin versión. «existe»: queda lo de la web (lo que difería, en
    sinc_pisado con motivo «programa_anterior»); «borrado»: la regla de baja; «nunca»: se vuelve a dar de alta con su mismo id (es su rango, no
    choca). True si terminó; False = probar en la vuelta siguiente (sin conexión o la web todavía no tiene la ruta)."""
    if time.monotonic() < _filas_despues.get(eid, 0.0):
        return False
    with Session(engine_empresa(eid)) as s:
        refs = _refs_propias(s, eid, terminal)
    for i in range(0, len(refs), TOPE_FILAS):
        tramo = refs[i:i + TOPE_FILAS]
        try:
            r = httpx.post(url + RUTA_FILAS, headers={"Authorization": "Bearer " + token},
                           json={"refs": [{"tipo": t, "ref": ref} for t, ref in tramo]}, timeout=httpx.Timeout(PLAZO_LLAMADA, connect=3.0))
            j = r.json() if getattr(r, "status_code", 0) == 200 else None
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc_datos empresa %s: /datos/filas sin respuesta (%s)", eid, type(ex).__name__)
            j = None
        if not isinstance(j, dict) or not isinstance(j.get("filas"), list):
            _filas_despues[eid] = time.monotonic() + SEGUNDOS_FILAS
            return False
        for f in j["filas"]:
            if not isinstance(f, dict) or (str(f.get("tipo")), str(f.get("ref"))) not in tramo:
                continue
            tipo, ref, cual = str(f["tipo"]), str(f["ref"]), f.get("estado")
            d = _sd().dato(tipo)
            if d is None:
                continue
            if cual == "nunca":
                with Session(engine_empresa(eid)) as s:
                    contenido = contenido_local(s, eid, d, ref)
                    if contenido is not None and anotar(s, eid, tipo, ref, None, contenido):
                        s.commit()
            elif cual in ("existe", "borrado"):
                fila = {"tipo": tipo, "ref": ref, "v": int(f.get("v") or 0), "dueno": None, "borrado": cual == "borrado", "origen": 0, "campos": {},
                        "datos": f.get("datos") if cual == "existe" else None}
                with Session(engine_empresa(eid)) as s, diario.aplicando(0):
                    acepto = aplicar_canonico(s, eid, fila, motivo_pisado="programa_anterior")
                    s.commit()
                if acepto:
                    _al_aplicar(eid, fila)
    return True


def _avanzar_carga(eid: int, url: str, token: str, terminal: int) -> None:
    """La carga inicial después del goteo desde 0 (plan §2.8): «pendiente» (relectura) → «filas» (lo propio sin versión, paso 4) → «reenlace»
    (los pasos que registre la primera subida, B6) → «hecha». `filas_propias` repite el paso 4 después de una época nueva de la web (§2.10)."""
    est = estado(eid)
    if est.get("releyendo"):
        return
    carga = est.get("carga")
    if carga == "pendiente":
        est = _guardar_estado(eid, carga="filas")
        carga = "filas"
    if carga == "filas" or est.get("filas_propias"):
        if not _paso_filas(eid, url, token, terminal):
            return
        cambios = {"filas_propias": False}
        if carga == "filas":
            carga = cambios["carga"] = "reenlace" if _pasos_carga else "hecha"
        _guardar_estado(eid, **cambios)
    if carga == "reenlace":
        hechos = True
        for fn in list(_pasos_carga):
            try:
                hechos = bool(fn(eid)) and hechos
            except Exception as ex:  # noqa: BLE001
                log.warning("sinc_datos empresa %s: paso de la carga inicial (%s)", eid, type(ex).__name__)
                hechos = False
        if hechos:
            _guardar_estado(eid, carga="hecha")


# ======================================================================================================================
# Contenido local de un dato y cómo se escribe (por forma: fila, elemento, llave, parte)
# ======================================================================================================================
def _sin(d, contenido: dict, extra: bool = True) -> dict:
    """Lo que viaja de una fila: sin empresa_id, sin `locales`, sin `no_viajan` (y sin `extra` para la huella)."""
    fuera = {"empresa_id", *d.locales, *d.no_viajan, *((d.extra or {}).keys() if extra else ())}
    return {k: v for k, v in contenido.items() if k not in fuera}


def contenido_local(s, eid: int, d, ref: str):
    """El contenido que viaja de ese dato tal como está aquí (None si no existe)."""
    forma = _forma(d)
    if forma == "fila":
        try:
            obj = s.get(d.modelo, int(ref))
        except (TypeError, ValueError):
            return None
        if obj is None:
            return None
        return json.loads(json.dumps(_sin(d, obj.model_dump(), extra=True), default=_iso))
    r = modulos._registro(s, eid, d.registro)
    if r is None:
        return None
    if forma == "elemento":
        try:
            iid = int(ref)
        except (TypeError, ValueError):
            return None
        if r.coleccion:
            f = s.exec(select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == eid, modulos.RegistroItem.clave == d.registro,
                                                          modulos.RegistroItem.item_id == iid)).first()
            return _json(f.datos) if f is not None else None
        lista = _json(r.datos, [])
        return next((x for x in lista if isinstance(x, dict) and modulos._id_entero(x.get("id")) == iid), None) if isinstance(lista, list) else None
    obj = _json(r.datos, {})
    if not isinstance(obj, dict):
        return None
    if forma == "llave":
        return obj.get(ref)
    if ref == "_":
        return {k: v for k, v in obj.items() if k not in (d.partir or {})}
    lista, _, iid = ref.partition("#")
    campo = (d.partir or {}).get(lista)
    return next((x for x in (obj.get(lista) or []) if isinstance(x, dict) and campo and str(x.get(campo)) == iid), None)


def _valor_columna(modelo, k, v):
    col = modelo.__table__.columns.get(k)
    if col is None or not isinstance(v, str):
        return v
    try:
        if isinstance(col.type, _TipoFechaHora):
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        if isinstance(col.type, _TipoFecha):
            return date.fromisoformat(v[:10])
    except ValueError:
        return v
    return v


def _baja_fila(s, eid: int, d, obj) -> None:
    """La regla de baja de la declaración (contrato §1.4): «historia:…» → con historia queda inactivo; si no, se borra."""
    regla = d.baja or "borrar"
    if not d.copia_local and regla.startswith("historia:"):
        fn = _resolver(regla.split(":", 1)[1])
        if fn(s, eid, int(obj.id)):
            if hasattr(obj, "activo"):
                obj.activo = False
            if d.modelo.__name__ == "Producto":           # lo mismo que main._borrar_producto_aqui: libera los códigos
                obj.codigo = None; obj.codigos_alternos = None
            s.add(obj)
            return
    s.delete(obj)


def _escribir(s, eid: int, d, ref: str, contenido) -> None:
    """Escribe aquí el contenido de un dato (None = quitarlo). Quien llama ya está dentro de aplicando(0). No confirma."""
    forma = _forma(d)
    if forma == "elemento":
        modulos.aplicar_elemento(s, eid, d.registro, int(ref), None if contenido is None else {**contenido, "id": int(ref)})
    elif forma == "llave":
        modulos.aplicar_llave(s, eid, d.registro, ref, contenido)
    elif forma == "parte":
        modulos.aplicar_llave(s, eid, d.registro, ref, contenido, partir=d.partir)
    else:
        iid = int(ref)
        obj = s.get(d.modelo, iid)
        if contenido is None:
            if obj is not None:
                _baja_fila(s, eid, d, obj)
                s.flush()
            return
        campos = {k: _valor_columna(d.modelo, k, v) for k, v in contenido.items()
                  if k in d.modelo.model_fields and k not in ("id", "empresa_id") and k not in d.locales and k not in d.no_viajan}
        if obj is None:
            obj = d.modelo(**campos)
            obj.id = iid
        else:
            for k, v in campos.items():
                setattr(obj, k, v)
        obj.empresa_id = eid
        s.add(obj); s.flush()


# ======================================================================================================================
# La cola: anotar (la llama el oyente de sinc_datos en modo réplica, dentro de la transacción del guardado)
# ======================================================================================================================
def _grupos(d, *contenidos) -> dict:
    """{grupo: (campo, …)} de un dato (contrato §1.4 y §2.2): en un registro cada llave de primer nivel es su propio grupo; en una fila,
    los de `grupos` y cada campo no nombrado es su propio grupo. Sin `id`, `empresa_id`, `locales`, `no_viajan` ni `conjuntos`."""
    fuera = {"id", "empresa_id", *d.locales, *d.no_viajan, *d.conjuntos, *(d.extra or {}).keys()}
    if d.modelo is None:
        claves = sorted({k for c in contenidos if isinstance(c, dict) for k in c} - fuera)
        return {k: (k,) for k in claves}
    out = {g: tuple(c) for g, c in (d.grupos or {}).items()}
    nombrados = {c for cs in out.values() for c in cs}
    for k in d.modelo.model_fields:
        if k not in fuera and k not in nombrados:
            out[k] = (k,)
    return out


def _conjunto(v) -> set:
    if v is None or v == "":
        return set()
    if isinstance(v, str):
        j = _json(v, None) if v.strip().startswith("[") else None
        v = j if isinstance(j, list) else v.split(",")
    if isinstance(v, (list, tuple, set)):
        return {str(x).strip() for x in v if str(x).strip()}
    return {str(v).strip()} if str(v).strip() else set()


def _diferencia(d, antes: dict, despues: dict, cuando: str) -> dict:
    """{"campos": {grupo: [antes, después, cuándo]}, "conjuntos": {campo: {"mas", "menos"}}} entre dos contenidos (vacío si son iguales)."""
    campos, conj = {}, {}
    if isinstance(antes, dict) and isinstance(despues, dict):
        for g, cs in _grupos(d, antes, despues).items():
            a, b = [antes.get(c) for c in cs], [despues.get(c) for c in cs]
            if not _igual(a, b):
                campos[g] = [a, b, cuando]
        for c in d.conjuntos:
            a, b = _conjunto(antes.get(c)), _conjunto(despues.get(c))
            if a != b:
                conj[c] = {"mas": sorted(b - a), "menos": sorted(a - b)}
    elif not _igual(antes, despues):
        campos["_"] = [[antes], [despues], cuando]          # una llave cuyo valor no es un objeto: un solo grupo
    out = {"campos": campos}
    if conj:
        out["conjuntos"] = conj
    return out


def _vacia(datos: dict) -> bool:
    return not datos.get("campos") and not any((v.get("mas") or v.get("menos")) for v in (datos.get("conjuntos") or {}).values())


def _fundir_cambios(d1: dict, d2: dict) -> dict:
    """Une dos cambios del mismo dato: conserva el primer «antes» de cada grupo, toma el último «después» y su hora; un grupo que volvió a su
    valor de antes desaparece. Conjuntos: lo agregado y lo quitado netos (agregar y quitar lo mismo se anula)."""
    campos = dict(d1.get("campos") or {})
    for g, (a2, b2, w2) in (d2.get("campos") or {}).items():
        a = campos[g][0] if g in campos else a2
        if _igual(a, b2):
            campos.pop(g, None)
        else:
            campos[g] = [a, b2, w2]
    conj = {}
    c1, c2 = d1.get("conjuntos") or {}, d2.get("conjuntos") or {}
    for c in set(c1) | set(c2):
        m1, n1 = set((c1.get(c) or {}).get("mas") or []), set((c1.get(c) or {}).get("menos") or [])
        m2, n2 = set((c2.get(c) or {}).get("mas") or []), set((c2.get(c) or {}).get("menos") or [])
        mas, menos = (m1 - n2) | (m2 - n1), (n1 - m2) | (n2 - m1)
        if mas or menos:
            conj[c] = {"mas": sorted(mas), "menos": sorted(menos)}
    out = {"campos": campos}
    if conj:
        out["conjuntos"] = conj
    return out


def _fundir(d, abierta: tuple, nueva: tuple, cuando: str):
    """(op, datos) que queda al fundir la op abierta con la nueva, o None si se anulan (alta y baja antes de salir)."""
    op1, datos1 = abierta
    op2, datos2 = nueva
    if op1 == "copia" or op2 == "copia":
        return nueva
    if op1 == "alta":
        if op2 == "baja":
            return None
        return "alta", {"fila": datos2.get("fila") if op2 == "alta" else datos2["_despues"]}
    if op1 == "cambio":
        if op2 == "baja":
            return nueva
        if op2 == "alta":
            return nueva
        unido = _fundir_cambios(datos1, datos2)
        return None if _vacia(unido) else ("cambio", unido)
    if op1 == "baja":
        if op2 == "alta":                                    # se eliminó y se volvió a crear con el mismo id antes de salir
            foto = (datos1 or {}).get("foto")
            if isinstance(foto, dict):
                dif = _diferencia(d, foto, datos2.get("fila"), cuando)
                return None if _vacia(dif) else ("cambio", dif)
            return nueva
        return abierta
    return nueva


def anotar(s, eid: int, tipo: str, ref, antes, despues, por: Optional[str] = None) -> bool:
    """Encola en sinc_cambio, EN LA MISMA TRANSACCIÓN de `s` (I1), lo que cambió de un dato declarado: `antes` es el contenido al empezar la
    transacción (None si no existía) y `despues` el del final (None si se eliminó). La llama el oyente de app/sinc_datos.py en modo réplica
    (before_commit). Funde con la operación abierta del mismo dato; nunca toca una enviada (I10). Devuelve True si escribió algo. Nunca lanza
    (un guardado no se detiene por la cola: el error va al registro sin datos)."""
    try:
        return _anotar(s, eid, tipo, str(ref), antes, despues, por)
    except Exception as ex:  # noqa: BLE001
        log.error("sinc_datos: no se pudo encolar un cambio de %s (%s)", tipo, type(ex).__name__)
        return False


def _anotar(s, eid: int, tipo: str, ref: str, antes, despues, por) -> bool:
    d = _sd().dato(tipo)
    if d is None or d.viaja == "baja" or d.escribe == "web" or protocolo(eid) != PROTOCOLO:
        return False
    if d.escribe == "todos" and diario._origen.get() is not None:
        return False                                         # lo que llegó de afuera (aplicando) no se devuelve
    if d.escribe == "todos" and antes is not None:          # el alta del rango 0 solo la encola la carga (sinc_completar.paso_filas)
        from . import sinc_completar
        if sinc_completar.lo_resuelve_la_carga(s, eid, d, ref):
            return False                                     # cambio o baja del rango 0 sin versión de la web durante la carga (plan §5.3 3c)
    con = s.connection()
    cuando = _hora_local()
    if d.escribe == "dueno":
        if _dueno(d, ref, despues if despues is not None else antes) != _terminal(s, eid):
            return False                                     # una cuenta de otro rango nunca la sube esta computadora (plan §2.5)
        va_antes, va_despues = _pasa(d, antes), _pasa(d, despues)
        if not va_antes and not va_despues:
            return False
        nueva = ("copia", {"fila": despues if va_despues else None})
    else:
        if d.filtro is not None:
            antes = antes if _pasa(d, antes) else None
            despues = despues if _pasa(d, despues) else None
        if antes is None and despues is None:
            return False
        if antes is None:
            nueva = ("alta", {"fila": despues})
        elif despues is None:
            nueva = ("baja", {"foto": antes})
        else:
            dif = _diferencia(d, antes, despues, cuando)
            if _vacia(dif):
                return False
            nueva = ("cambio", {**dif, "_despues": despues})
    abierta = con.execute(_sql("SELECT id, op, datos FROM sinc_cambio WHERE tipo = :t AND ref = :r AND estado = :e ORDER BY id DESC LIMIT 1"),
                          {"t": tipo, "r": ref, "e": ABIERTA}).first()
    if abierta is not None:
        res = _fundir(d, (abierta[1], _json(abierta[2], {})), nueva, cuando)
        if res is None:
            con.execute(_sql("DELETE FROM sinc_cambio WHERE id = :i AND estado = :e"), {"i": abierta[0], "e": ABIERTA})
        else:
            op, datos = res[0], {k: v for k, v in res[1].items() if k != "_despues"}
            hecho = con.execute(_sql("UPDATE sinc_cambio SET op = :o, datos = :d, por = COALESCE(:p, por) WHERE id = :i AND estado = :e"),
                                {"o": op, "d": _texto(datos), "p": (por or None) and str(por)[:80], "i": abierta[0], "e": ABIERTA})
            if hecho.rowcount != 1:
                abierta = None                               # salió mientras tanto: va una nueva
        if abierta is not None:
            avisar(eid)
            return True
    op, datos = nueva[0], {k: v for k, v in nueva[1].items() if k != "_despues"}
    est = _leer_estado(s, eid)
    autora = f"{_terminal(s, eid)}.{est.get('epoca') or ''}"
    n_local = con.execute(_sql("SELECT COALESCE(MAX(n), 0) FROM sinc_cambio WHERE autora = :a"), {"a": autora}).scalar() or 0
    conocido = _n_web.get(eid)
    n = max(int(n_local), conocido[1] if conocido and conocido[0] == autora else 0) + 1
    fila = con.execute(_sql("SELECT v FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": ref}).first()
    con.execute(_sql("INSERT INTO sinc_cambio (autora, n, tipo, ref, op, base_v, datos, por, estado, resultado, intentos, creado) "
                     "VALUES (:a, :n, :t, :r, :o, :b, :d, :p, :e, NULL, 0, :c)"),
                {"a": autora, "n": n, "t": tipo, "r": ref, "o": op, "b": int(fila[0] or 0) if fila else 0, "d": _texto(datos),
                 "p": (por or None) and str(por)[:80], "e": ABIERTA, "c": _ahora()})
    avisar(eid)
    return True


# ======================================================================================================================
# aplicar_canonico: la única función que escribe aquí lo que viene de la web (I8)
# ======================================================================================================================
def _pendientes(s, tipo: str, ref: str) -> list:
    return [(op, _json(datos, {})) for op, datos in s.connection().execute(
        _sql("SELECT op, datos FROM sinc_cambio WHERE tipo = :t AND ref = :r AND estado IN (:a, :e) ORDER BY id"),
        {"t": tipo, "r": ref, "a": ABIERTA, "e": ENVIADA}).all()]


def _retenidos(d, pendientes: list):
    """Campos que no se pisan (I3): None = ninguno; True = todo (hay un alta o una baja propia sin veredicto); si no, el conjunto de campos."""
    if not pendientes:
        return None
    campos = set()
    for op, datos in pendientes:
        if op in ("alta", "baja", "copia"):
            return True
        for g in (datos.get("campos") or {}):
            campos.update((d.grupos or {}).get(g, (g,)) if d.modelo is not None else (g,))
        campos.update((datos.get("conjuntos") or {}).keys())
    return campos


def _pisado(s, tipo: str, ref: str, motivo: str, perdio, nombre: str = "", campo: str = "", perdio_de: str = PERDIO_AQUI, quedo_de: str = QUEDO_WEB) -> None:
    s.connection().execute(_sql("INSERT INTO sinc_pisado (cuando, tipo, ref, nombre, campo, motivo, perdio, perdio_de, quedo_de, visto) "
                                "VALUES (:c, :t, :r, :n, :ca, :m, :p, :pd, :q, 0)"),
                           {"c": _ahora(), "t": tipo, "r": str(ref)[:60], "n": str(nombre or "")[:120], "ca": str(campo or "")[:60],
                            "m": motivo, "p": _texto(perdio)[:4000], "pd": str(perdio_de or "")[:80], "q": str(quedo_de or "")[:80]})


def _nombre(contenido) -> str:
    return str(contenido.get("nombre") or "") if isinstance(contenido, dict) else ""


def _guardar_linea(s, d, ref: str, v: int, campos, huella: str, borrado: bool, foto=None, dueno=None, etiqueta=None) -> None:
    s.connection().execute(_sql(
        "INSERT INTO sinc_dato (tipo, ref, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta, cambiado) "
        "VALUES (:t, :r, :v, :ca, 0, :du, :b, :f, :h, NULL, :e, :cm) "
        "ON CONFLICT(tipo, ref) DO UPDATE SET v = excluded.v, campos = excluded.campos, dueno = excluded.dueno, borrado = excluded.borrado, "
        "foto = CASE WHEN excluded.borrado THEN COALESCE(excluded.foto, sinc_dato.foto) ELSE NULL END, huella = excluded.huella, "
        "etiqueta = COALESCE(excluded.etiqueta, sinc_dato.etiqueta), cambiado = excluded.cambiado"),
        {"t": d.tipo, "r": ref, "v": int(v or 0), "ca": _texto(campos if isinstance(campos, dict) else {}), "du": dueno, "b": bool(borrado),
         "f": _texto(foto) if foto is not None else None, "h": huella or "", "e": etiqueta, "cm": _ahora()})


def _no_anotar(s, eid: int, d, ref: str) -> None:
    """Lo que aplicar_canonico acaba de escribir no es un cambio de esta computadora: se vacía la sesión aquí (dentro de aplicando) y se
    quita de lo que el oyente de sinc_datos acumuló para decidir en before_commit (s.info["sinc_tocado"], contrato §3.1). Así no vuelve a
    la cola aunque quien llama confirme fuera de aplicando(0). Un registro de valor tocado entero («*») no se quita: por eso quien llama
    confirma igual dentro de aplicando(0) (todas las llamadas de este módulo lo hacen)."""
    s.flush()
    tocado = s.info.get("sinc_tocado")
    if isinstance(tocado, dict):
        tocado.pop((eid, d.tipo, ref), None)


def _rango0(ref) -> bool:
    n = modulos._id_entero(ref)
    return n is not None and 0 < n < modulos.RANGO


def _crear_tabla_ganchos(s, eid: int) -> None:
    if eid not in _tabla_ganchos:
        s.connection().execute(_sql("CREATE TABLE IF NOT EXISTS sinc_gancho (tipo TEXT NOT NULL, ref TEXT NOT NULL, fila TEXT NOT NULL, "
                                    "PRIMARY KEY (tipo, ref))"))
        _tabla_ganchos.add(eid)


def _marcar_gancho(s, eid: int, d, fila: dict) -> None:
    """Revisión n.º 8 y 16: el al_aplicar pendiente queda en la base (tabla sinc_gancho del programa) en la MISMA transacción que la fila;
    _al_aplicar lo quita cuando el gancho termina. Así un cierre del programa entre el commit y el gancho (o con el gancho pidiendo volver a
    llamarse) no deja un pedido aceptado sin cuenta ni comanda: la primera vuelta después de abrir lo vuelve a correr con la misma fila."""
    if d is None or not d.al_aplicar:
        return
    _crear_tabla_ganchos(s, eid)
    s.connection().execute(_sql("INSERT INTO sinc_gancho (tipo, ref, fila) VALUES (:t, :r, :f) ON CONFLICT(tipo, ref) DO UPDATE SET fila = excluded.fila"),
                           {"t": d.tipo, "r": str(fila.get("ref")), "f": _texto({**fila, "tipo": d.tipo, "ref": str(fila.get("ref"))})})


def aplicar_canonico(s: Session, eid: int, fila: dict, *, forzar: bool = False, motivo_pisado: Optional[str] = None) -> bool:
    """Ver _aplicar_canonico. Si la aceptó y la declaración tiene al_aplicar, el gancho queda pendiente en la base (sinc_gancho), en la
    misma transacción: quien llama confirma y después corre _al_aplicar, que lo quita."""
    acepto = _aplicar_canonico(s, eid, fila, forzar=forzar, motivo_pisado=motivo_pisado)
    if acepto:
        _marcar_gancho(s, eid, _sd().dato(str(fila.get("tipo") or "")), fila)
    return acepto


def _aplicar_canonico(s: Session, eid: int, fila: dict, *, forzar: bool = False, motivo_pisado: Optional[str] = None) -> bool:
    """Aplica aquí una Fila de la web (contrato §2.2 / §3.2). Devuelve True si la aceptó (versión mayor: escribió el contenido o, si era
    igual, solo la versión) y False si no hizo nada. No confirma: quien llama hace s.commit() DENTRO de sinc_diario.aplicando(0) y después
    al_aplicar.
    `forzar` (solo para el `canonico` de una op rechazada) acepta aunque la versión no sea mayor, sin bajarla. `motivo_pisado`
    («programa_anterior» en la relectura) anota en sinc_pisado lo local que la web reemplaza."""
    sd = _sd()
    d = sd.dato(str(fila.get("tipo") or ""))
    if d is None or d.viaja == "sube":
        return False                                         # un dato que solo sube nunca se guarda aquí como copia de la web
    ref = str(fila.get("ref"))
    v = int(fila.get("v") or 0)
    con = s.connection()
    con.execute(_sql("UPDATE sinc_dato SET v = v WHERE tipo = :t AND ref = :r"), {"t": d.tipo, "r": ref})   # toma el bloqueo antes de releer (I2)
    linea = con.execute(_sql("SELECT v, borrado FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": d.tipo, "r": ref}).first()
    v_local = int(linea[0] or 0) if linea else 0
    if not forzar and v <= v_local:
        return False
    v_final = max(v, v_local)
    local = contenido_local(s, eid, d, ref)
    pend = _pendientes(s, d.tipo, ref)
    # relectura de la carga inicial: un dato del rango 0 que nunca vino de la web (sin línea) se conserva o se anota (sinc_completar, plan §5.3 3c)
    nunca_vino = bool(motivo_pisado) and linea is None and not pend and local is not None
    with diario.aplicando(0):
        if fila.get("borrado"):
            if nunca_vino:
                from . import sinc_completar
                if sinc_completar.conservar_en_relectura(s, eid, d, ref, local, None):
                    local = None
                elif _rango0(ref):
                    # revisión n.º 24: la web creó y eliminó un dato con el mismo número que uno de aquí que nunca subió: el de aquí se
                    # queda y va a la lista de choques («¿Eliminado en la página web?»); la línea guarda la lápida (no vuelve a subir solo)
                    sinc_completar.anotar_choque(s, "eliminado_web", d.tipo, ref, _nombre(local), {"programa": local})
                    _guardar_linea(s, d, ref, v_final, fila.get("campos") or {}, "", True, foto=local, dueno=fila.get("dueno"))
                    return True
            if local is not None:
                _escribir(s, eid, d, ref, None)              # la lápida gana (I7); una op propia pendiente la arbitra la web
                _no_anotar(s, eid, d, ref)
            _guardar_linea(s, d, ref, v_final, fila.get("campos") or {}, "", True, foto=local, dueno=fila.get("dueno"))
            return True
        datos = fila.get("datos")
        if datos is None:
            return False
        entrante = _sin(d, datos) if isinstance(datos, dict) else datos
        h_entrante = sd.huella(d, entrante)
        etiqueta = None
        if d.etiqueta is not None:
            try:
                etiqueta = str(_resolver(d.etiqueta)(datos))[:120]
            except Exception:  # noqa: BLE001
                etiqueta = None
        if local is not None and sd.huella(d, local) == h_entrante:
            _guardar_linea(s, d, ref, v_final, fila.get("campos") or {}, h_entrante, False, dueno=fila.get("dueno"), etiqueta=etiqueta)
            return True
        if nunca_vino:
            from . import sinc_completar
            if sinc_completar.conservar_en_relectura(s, eid, d, ref, local, entrante):
                local = None
        retener = _retenidos(d, pend)
        if retener is True:
            nuevo = _SIN_CAMBIO                              # alta o baja propia sin veredicto: no se toca el contenido
        elif retener and isinstance(entrante, dict):
            nuevo = dict(entrante)
            for c in retener:
                if isinstance(local, dict) and c in local:
                    nuevo[c] = local[c]
                else:
                    nuevo.pop(c, None)
        elif retener:
            nuevo = _SIN_CAMBIO                              # valor que no es un objeto con un cambio propio pendiente
        else:
            nuevo = entrante
        if motivo_pisado and local is not None and nuevo is not _SIN_CAMBIO:
            if isinstance(local, dict) and isinstance(nuevo, dict):
                for g, cs in _grupos(d, local, nuevo).items():
                    a, b = [local.get(c) for c in cs], [nuevo.get(c) for c in cs]
                    if not _igual(a, b):
                        _pisado(s, d.tipo, ref, motivo_pisado, a, _nombre(local) or _nombre(nuevo), g)
                for c in d.conjuntos:
                    if _conjunto(local.get(c)) != _conjunto(nuevo.get(c)):
                        _pisado(s, d.tipo, ref, motivo_pisado, local.get(c), _nombre(local), c)
            elif not _igual(local, nuevo):
                _pisado(s, d.tipo, ref, motivo_pisado, local)
        if nuevo is not _SIN_CAMBIO:
            _escribir(s, eid, d, ref, nuevo)
            _no_anotar(s, eid, d, ref)
        _guardar_linea(s, d, ref, v_final, fila.get("campos") or {}, h_entrante, False, dueno=fila.get("dueno"), etiqueta=etiqueta)
    return True


def _al_aplicar(eid: int, fila: dict) -> None:
    """Corre el gancho de la declaración después del commit, dentro de aplicando(0) y con el candado de la empresa (contrato §3.3)."""
    d = _sd().dato(str(fila.get("tipo") or ""))
    fn = _resolver(d.al_aplicar) if d is not None else None
    if fn is None:
        return
    clave = (d.tipo, str(fila.get("ref")))
    ok = False
    with candado(eid):
        try:
            with Session(engine_empresa(eid)) as s, diario.aplicando(0):
                ok = bool(fn(s, eid, fila))
        except Exception as ex:  # noqa: BLE001  sin datos del pedido en el registro: solo el tipo del error
            log.error("sinc_datos: el gancho al aplicar de %s falló (%s)", d.tipo, type(ex).__name__)
            ok = False
    if ok:
        _reintentar.get(eid, set()).discard(clave)
        _quitar_gancho(eid, clave, fila)
    else:
        _reintentar.setdefault(eid, set()).add(clave)


def _quitar_gancho(eid: int, clave: tuple, fila: dict) -> None:
    """El gancho terminó: se quita la marca de la base (solo si es de esa versión o de una anterior: una fila más nueva deja la suya)."""
    try:
        with Session(engine_empresa(eid)) as s:
            _crear_tabla_ganchos(s, eid)
            con = s.connection()
            guardada = con.execute(_sql("SELECT fila FROM sinc_gancho WHERE tipo = :t AND ref = :r"), {"t": clave[0], "r": clave[1]}).first()
            if guardada is not None:
                g = _json(guardada[0], {})
                if not isinstance(g, dict) or int(g.get("v") or 0) <= int(fila.get("v") or 0):
                    con.execute(_sql("DELETE FROM sinc_gancho WHERE tipo = :t AND ref = :r"), {"t": clave[0], "r": clave[1]})
            s.commit()
    except Exception as ex:  # noqa: BLE001  (si no se pudo quitar, el gancho se vuelve a correr: los ganchos son idempotentes)
        log.warning("sinc_datos empresa %s: no se pudo quitar un gancho pendiente (%s)", eid, type(ex).__name__)


def _reintentar_ganchos(eid: int) -> None:
    """Los al_aplicar pendientes: los de la base (sinc_gancho: sobreviven a un reinicio, revisión n.º 8 y 16) y los de la memoria."""
    pend: dict = {}
    try:
        with Session(engine_empresa(eid)) as s:
            _crear_tabla_ganchos(s, eid)
            for tipo, ref, f in s.connection().execute(_sql("SELECT tipo, ref, fila FROM sinc_gancho ORDER BY rowid")).all():
                pend[(str(tipo), str(ref))] = _json(f, None)
            s.commit()
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos empresa %s: no se pudieron leer los ganchos pendientes (%s)", eid, type(ex).__name__)
    for clave in list(_reintentar.get(eid, set())):
        pend.setdefault(clave, None)
    for (tipo, ref), guardada in pend.items():
        d = _sd().dato(tipo)
        if d is None or not d.al_aplicar:
            _reintentar.get(eid, set()).discard((tipo, ref))
            _quitar_gancho(eid, (tipo, ref), {"v": 1 << 62})
            continue
        if isinstance(guardada, dict):
            fila = guardada                                  # la misma fila que llegó (con _caja, edad_s y documento_clave)
        else:
            with Session(engine_empresa(eid)) as s:
                linea = s.connection().execute(_sql("SELECT v, borrado, campos FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": ref}).first()
                contenido = contenido_local(s, eid, d, ref)
            fila = {"tipo": tipo, "ref": ref, "v": int(linea[0] or 0) if linea else 0, "borrado": bool(linea[1]) if linea else contenido is None,
                    "campos": _json(linea[2], {}) if linea else {}, "datos": contenido, "dueno": None, "origen": 0}
        _al_aplicar(eid, fila)


# ======================================================================================================================
# La ida y vuelta con la web
# ======================================================================================================================
def _conexion(eid: int):
    """(url, token, cfg) de la vinculación, o None si la empresa no está conectada (o fue revocada)."""
    from .auth import Empresa
    from . import secretos
    with Session(engine_empresa(eid)) as s:
        cfg = _sinc()._cfg_local(s, eid)
    if cfg.get("revocada_en") or not (cfg.get("vinculado") and cfg.get("token") and cfg.get("url")) or not int(cfg.get("terminal") or 0):
        return None
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        if e is None or e.bloqueada:
            return None
        clave = e.clave_cifrada
    return str(cfg["url"]).rstrip("/"), secretos.descifrar(clave, cfg["token"]), cfg


def _cuerpo_error(r) -> Optional[str]:
    try:
        j = r.json()
    except Exception:  # noqa: BLE001
        return None
    det = j.get("detail") if isinstance(j, dict) else None
    return det if isinstance(det, str) else None


def _estrenar_epoca(eid: int) -> str:
    """Respaldo restaurado en el programa: la web ya vio números de esta autora que aquí no están. Las ops que no tienen veredicto salen con
    una autora nueva, numeradas desde 1 en su orden (plan §2.10)."""
    epoca = _epoca_nueva()
    with Session(engine_empresa(eid)) as s:
        autora = f"{_terminal(s, eid)}.{epoca}"
        con = s.connection()
        ids = [i for (i,) in con.execute(_sql("SELECT id FROM sinc_cambio WHERE estado IN (:a, :e) ORDER BY id"), {"a": ABIERTA, "e": ENVIADA}).all()]
        for n, i in enumerate(ids, start=1):
            con.execute(_sql("UPDATE sinc_cambio SET autora = :a, n = :n WHERE id = :i"), {"a": autora, "n": n, "i": i})
        s.commit()
    _guardar_estado(eid, epoca=epoca)
    _n_web[eid] = (autora, 0)
    log.warning("sinc_datos empresa %s: la página web ya tenía cambios de esta computadora que aquí no están (respaldo restaurado): época nueva", eid)
    return autora


def _revisar_numeros(eid: int, autora: str, n_max: int) -> str:
    """Época nueva si la web vio un número de esta autora que aquí no existe, o si una op abierta (nunca enviada) usa un número que la web ya vio."""
    _n_web[eid] = (autora, int(n_max or 0))
    with Session(engine_empresa(eid)) as s:
        con = s.connection()
        n_local = int(con.execute(_sql("SELECT COALESCE(MAX(n), 0) FROM sinc_cambio WHERE autora = :a"), {"a": autora}).scalar() or 0)
        chocan = int(con.execute(_sql("SELECT COUNT(*) FROM sinc_cambio WHERE autora = :a AND estado = :e AND n <= :m"),
                                 {"a": autora, "e": ABIERTA, "m": int(n_max or 0)}).scalar() or 0)
    if n_local < int(n_max or 0) or chocan:
        return _estrenar_epoca(eid)
    return autora


def _tomar_ops(eid: int, autora: str) -> list:
    """Marca como enviadas (y confirma, ANTES de mandarlas: I10) hasta TOPE_OPS ops de esta autora en orden de la cola, y las devuelve.
    Una op sin veredicto que quedó con otra autora (se anotó justo mientras se estrenaba una época) pasa a esta, con el número siguiente."""
    with Session(engine_empresa(eid)) as s:
        con = s.connection()
        otras = [i for (i,) in con.execute(_sql("SELECT id FROM sinc_cambio WHERE autora <> :a AND estado IN (:ab, :en) ORDER BY id"),
                                            {"a": autora, "ab": ABIERTA, "en": ENVIADA}).all()]
        if otras:
            conocido = _n_web.get(eid)
            n = max(int(con.execute(_sql("SELECT COALESCE(MAX(n), 0) FROM sinc_cambio WHERE autora = :a"), {"a": autora}).scalar() or 0),
                    conocido[1] if conocido and conocido[0] == autora else 0)
            for i in otras:
                n += 1
                con.execute(_sql("UPDATE sinc_cambio SET autora = :a, n = :n WHERE id = :i"), {"a": autora, "n": n, "i": i})
        filas = con.execute(_sql("SELECT id, LENGTH(datos) FROM sinc_cambio WHERE autora = :a AND estado IN (:ab, :en) ORDER BY id LIMIT :l"),
                            {"a": autora, "ab": ABIERTA, "en": ENVIADA, "l": TOPE_OPS}).all()
        ids, total = [], 0
        for i, largo in filas:
            if ids and total + int(largo or 0) > TOPE_BYTES:
                break
            ids.append(i); total += int(largo or 0)
        if not ids:
            return []
        marcas = ",".join(str(int(i)) for i in ids)
        con.execute(_sql(f"UPDATE sinc_cambio SET estado = :en, intentos = intentos + 1 WHERE id IN ({marcas}) AND estado IN (:ab, :en)"),
                    {"en": ENVIADA, "ab": ABIERTA})
        ops = [{"_id": i, "n": n, "tipo": t, "ref": r, "op": o, "base_v": b, "datos": _json(dd, {}), "por": p}
               for i, n, t, r, o, b, dd, p in con.execute(_sql(f"SELECT id, n, tipo, ref, op, base_v, datos, por FROM sinc_cambio WHERE id IN ({marcas}) "
                                                               "AND estado = :en ORDER BY id"), {"en": ENVIADA}).all()]
        from . import sinc_completar
        sinc_completar.completar_ops(s, eid, ops)              # B6 (plan §5.3 paso 3b): el alta de un ítem del rango 0 lleva su existencia con lo pendiente sumado
        s.commit()
    return ops


def _resultado(eid: int, op: dict, res: dict) -> None:
    """El veredicto de la web para una op enviada (contrato §2.2): la marca y deja aquí lo que quedó en la web."""
    sd = _sd()
    d = sd.dato(op["tipo"])
    estado_res = str(res.get("estado") or "")
    motivo = res.get("motivo")
    if estado_res not in ESTADOS_FINALES:
        return                                           # (I-2) «reintentar»: la web no la anotó; sigue «enviada» y sale otra vez tal cual
    rechazo = estado_res == "rechazado" or (estado_res == "repetido" and motivo and res.get("v") is None)
    with Session(engine_empresa(eid)) as s, diario.aplicando(0):
        s.connection().execute(_sql("UPDATE sinc_cambio SET estado = :e, resultado = :r WHERE id = :i"),
                               {"e": RECHAZADA if rechazo else HECHA, "r": _texto(res)[:20000], "i": op["_id"]})
        if d is not None:
            ref = str(res.get("ref") or op["ref"])
            if estado_res in ("renumerar", "repetido") and ref != op["ref"]:   # validación 4.32 (C): «repetido» tras una respuesta perdida
                _renumerar(s, eid, d, op["ref"], ref)
                from . import sinc_completar
                sinc_completar.avisar_renumerado(s, d.tipo, op["ref"], ref, _nombre(contenido_local(s, eid, d, ref)))
            local = contenido_local(s, eid, d, ref)
            for p in res.get("pisados") or []:
                if isinstance(p, dict):
                    _pisado(s, d.tipo, ref, str(p.get("motivo") or "conflicto"), p.get("perdio"), _nombre(local), str(p.get("campo") or ""),
                            op.get("por") or PERDIO_AQUI)
            if rechazo:
                _pisado(s, d.tipo, ref, str(motivo or "no_valido"), op["datos"], _nombre(local) or _nombre((op["datos"] or {}).get("fila")),
                        "", op.get("por") or PERDIO_AQUI)
            canonico = res.get("canonico")
            v = res.get("v")
            if d.escribe == "dueno" or d.viaja == "sube":
                pass                                     # la copia de una cuenta: aquí no hay nada que volver a escribir
            elif isinstance(canonico, dict):
                aplicar_canonico(s, eid, {"tipo": d.tipo, "ref": ref, "v": int(v or 0), "borrado": False, "datos": canonico,
                                          "campos": res.get("campos") or {}}, forzar=rechazo)
            elif rechazo and op["op"] == "alta" and local is not None and _rango0(ref):
                # revisión n.º 6: un dato de antes de conectar (rango 0) que la web no aceptó no se borra de aquí: queda como estaba (sin
                # versión de la web) y va a la lista de choques; lo que mandó ya quedó en «Cambios que no quedaron»
                from . import sinc_completar
                sinc_completar.anotar_choque(s, "no_aceptado", d.tipo, ref, _nombre(local), {"motivo": str(motivo or "no_valido")})
            elif rechazo and op["op"] == "alta" and local is not None:
                _escribir(s, eid, d, ref, None)          # el alta no quedó en la web: se vuelve a lo de la web (no existe)
            elif not rechazo and op["op"] == "baja" and v:
                _guardar_linea(s, d, ref, int(v), {}, "", True, foto=(op["datos"] or {}).get("foto"))
        s.commit()


def _renumerar(s, eid: int, d, viejo: str, nuevo: str) -> None:
    """Contrato §2.2 «renumerar»: el alta de un elemento quedó en la web con otro id; aquí se cambia el suyo (dentro de aplicando(0))."""
    if _forma(d) != "elemento":
        return
    contenido = contenido_local(s, eid, d, viejo)
    if contenido is not None:
        _escribir(s, eid, d, viejo, None)
        _escribir(s, eid, d, nuevo, {**contenido, "id": int(nuevo)})
    con = s.connection()
    con.execute(_sql("UPDATE sinc_cambio SET ref = :n WHERE tipo = :t AND ref = :v AND estado IN (:a, :e)"),
                {"n": nuevo, "t": d.tipo, "v": viejo, "a": ABIERTA, "e": ENVIADA})
    con.execute(_sql("UPDATE sinc_dato SET ref = :n WHERE tipo = :t AND ref = :v AND NOT EXISTS (SELECT 1 FROM sinc_dato WHERE tipo = :t AND ref = :n)"),
                {"n": nuevo, "t": d.tipo, "v": viejo})


def _aplicar_goteo(eid: int, filas: list, motivo: Optional[str]) -> tuple[Optional[int], bool]:
    """Aplica las filas del goteo en orden, cada una con su commit y su gancho. Devuelve (última versión aplicada o saltada, completo)."""
    ultima = None
    for f in filas:
        if not isinstance(f, dict):
            continue
        v = int(f.get("v") or 0)
        try:
            with Session(engine_empresa(eid)) as s, diario.aplicando(0):
                acepto = aplicar_canonico(s, eid, f, motivo_pisado=motivo)
                s.commit()
            if acepto:
                _al_aplicar(eid, f)
            _fallos_fila.pop(eid, None)
        except Exception as ex:  # noqa: BLE001
            previo = _fallos_fila.get(eid)
            intentos = previo[1] + 1 if previo and previo[0] == v else 1
            _fallos_fila[eid] = (v, intentos)
            if intentos < INTENTOS_FILA:
                log.warning("sinc_datos empresa %s: una fila de %s no se pudo aplicar (%s); se reintenta", eid, f.get("tipo"), type(ex).__name__)
                return ultima, False
            log.error("sinc_datos empresa %s: una fila de %s falló %s veces (%s): se salta", eid, f.get("tipo"), intentos, type(ex).__name__)
            _fallos_fila.pop(eid, None)
        ultima = v if ultima is None else max(ultima, v)
    return ultima, True


def ciclo(eid: int) -> float:
    """Una vuelta del canal para una empresa. Devuelve en cuántos segundos toca la siguiente. Nunca lanza."""
    cand = _candado_ciclo(eid)
    if not cand.acquire(blocking=False):
        return SEGUNDOS_MINIMO
    try:
        return _ciclo(eid)
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos empresa %s: %s", eid, type(ex).__name__)
        return SEGUNDOS_ERROR
    finally:
        cand.release()


_ultimo_intento_pausa: dict[int, float] = {}
_siguiente: dict[int, int] = {}
_canal_visto: dict[int, float] = {}                 # 4.35: {eid: cuándo dijo la web que tiene el canal nuevo} mientras la subida espera el candado


def _ciclo(eid: int) -> float:
    con = _conexion(eid)
    if con is None:
        return SEGUNDOS_SIN_VINCULAR                             # sin conectar: se revisa seguido (solo lee la base de aquí)
    url, token, cfg = con
    est = estado(eid)
    if int(est.get("protocolo") or 0) != PROTOCOLO:
        return _probar(eid, url, token, cfg)
    if est.get("pausa_desde") and time.monotonic() - _ultimo_intento_pausa.get(eid, 0.0) < SEGUNDOS_PAUSA:
        return max(SEGUNDOS_MINIMO, SEGUNDOS_PAUSA - (time.monotonic() - _ultimo_intento_pausa.get(eid, 0.0)))
    _reintentar_ganchos(eid)
    terminal = int(cfg.get("terminal") or 0)
    if not est.get("epoca"):
        est = _guardar_estado(eid, epoca=_epoca_nueva())
    autora = f"{terminal}.{est['epoca']}"
    conocido = _n_web.get(eid)
    ops = (_tomar_ops(eid, autora) if conocido and conocido[0] == autora and not _ops_en_espera(eid)
           else [])                                      # n_max desconocido: primero un goteo puro (época mínima); (I-2) en espera: solo goteo
    cuerpo = {"protocolo": PROTOCOLO, "version": _version(), "autora": autora, "hora_local": _hora_local(), "desde": int(est.get("cursor") or 0),
              "epoca_web": est.get("epoca_web"), "estacion_viva": estacion_viva(eid),
              "ops": [{k: v for k, v in o.items() if k != "_id"} for o in ops]}
    from . import sinc_completar
    reserva = sinc_completar.pedido_reserva(eid)          # B6 (contrato §2.2 y §2.6): con la carga «pendiente», reserva los ids del rango 0
    if reserva:
        cuerpo["reservar"] = reserva
    espera = httpx.Timeout(PLAZO_LLAMADA, connect=2.0 if est.get("sin_conexion_desde") else 3.0)
    if est.get("pausa_desde"):
        _ultimo_intento_pausa[eid] = time.monotonic()
    try:
        r = httpx.post(url + RUTA_DATOS, headers={"Authorization": "Bearer " + token}, json=cuerpo, timeout=espera)
    except Exception as ex:  # noqa: BLE001  sin internet, tiempo agotado: las ops quedan «enviadas» y salen iguales la próxima vez
        if not est.get("sin_conexion_desde"):
            _guardar_estado(eid, sin_conexion_desde=_ahora())
        log.warning("sinc_datos empresa %s: sin conexión con la página web (%s)", eid, type(ex).__name__)
        return SEGUNDOS_SIN_CONEXION
    codigo = getattr(r, "status_code", 0)
    if codigo in (200, 404, 405):
        _web_vieja.setdefault(eid, {})["datos"] = codigo == 405          # validación 4.32 (A): 405 = web 4.31; 404 = 4.32 con el interruptor apagado
    if codigo in (404, 405):
        if not est.get("pausa_desde"):
            _guardar_estado(eid, pausa_desde=_ahora(), sin_conexion_desde=None)
            log.warning("sinc_datos empresa %s: la página web no tiene el canal nuevo (respondió %s): en pausa", eid, codigo)
        _ultimo_intento_pausa[eid] = time.monotonic()
        return SEGUNDOS_PAUSA
    if codigo == 429:
        return 2 * _siguiente.get(eid, SEGUNDOS_OCIOSO)
    if codigo != 200:
        log.warning("sinc_datos empresa %s: la página web respondió %s", eid, codigo)
        return SEGUNDOS_ERROR
    try:
        j = r.json()
    except Exception:  # noqa: BLE001
        j = None
    if not isinstance(j, dict) or j.get("protocolo") != PROTOCOLO:
        log.warning("sinc_datos empresa %s: respuesta inesperada de la página web", eid)
        return SEGUNDOS_ERROR
    espera = _procesar(eid, est, autora, ops, j)
    if not estado(eid).get("pausa_desde"):
        try:
            _avanzar_carga(eid, url, token, terminal)        # B3: carga inicial (pasos 2 y 4) y /filas del rango propio tras otra época de la web
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc_datos empresa %s: carga inicial (%s)", eid, type(ex).__name__)
        from . import pedidos_programa
        pedidos_programa.confirmar_cancelaciones(eid)   # revisión n.º 28/29: nunca lanza; como mucho cada 60 s; sin cancelaciones sin respuesta no sale a la red
    return espera


def _ops_en_espera(eid: int) -> float:
    """(I-2) Segundos que faltan para volver a mandar ops después de un «reintentar» de la web (0 = se pueden mandar ya)."""
    e = _espera_ops.get(eid)
    return max(0.0, e[1] - time.monotonic()) if e else 0.0


def _procesar(eid: int, est: dict, autora: str, ops: list, j: dict) -> float:
    cambios = {"sin_conexion_desde": None, "pedidos_programa": bool(j.get("pedidos_programa"))}
    if not _senal_no.get(eid):
        cambios["pausa_desde"] = None
    desfase = _desfase(j.get("hora"))                        # reloj de esta computadora contra el de la web (la web corrige cada op con hora_local)
    if desfase is not None and (est.get("desfase_s") is None or abs(desfase - int(est.get("desfase_s") or 0)) >= SEGUNDOS_DESFASE_CAMBIO):
        cambios["desfase_s"] = desfase
        if abs(desfase) >= SEGUNDOS_DESFASE_AVISO:
            log.warning("sinc_datos empresa %s: el reloj de esta computadora difiere %s s del de la página web", eid, desfase)
    # 1) época de la web: si cambió, la web se restauró de un respaldo; se relee desde 0 aceptando lo de la web (salvo lo pendiente)
    epoca = j.get("epoca")
    nueva_epoca_web = bool(est.get("epoca_web")) and bool(epoca) and epoca != est.get("epoca_web")
    # 2) veredictos de las ops enviadas
    por_n = {o["n"]: o for o in ops}
    reintentar = None
    for res in j.get("resultados") or []:
        if isinstance(res, dict) and res.get("n") in por_n:
            if str(res.get("estado") or "") not in ESTADOS_FINALES:
                reintentar = reintentar or str(res.get("motivo") or res.get("estado") or "?")   # (I-2): queda «enviada», sin tocar nada aquí
                continue
            try:
                _resultado(eid, por_n[res["n"]], res)
            except Exception as ex:  # noqa: BLE001
                log.warning("sinc_datos empresa %s: no se pudo anotar un veredicto (%s)", eid, type(ex).__name__)
    if reintentar is not None:
        veces = (_espera_ops.get(eid) or (0, 0.0))[0] + 1
        pausa = min(SEGUNDOS_REINTENTAR_MAX, SEGUNDOS_REINTENTAR * 2 ** min(veces - 1, 10))
        _espera_ops[eid] = (veces, time.monotonic() + pausa)
        log.warning("sinc_datos empresa %s: la página web pidió reintentar los cambios (%s): salen otra vez en %s s", eid, reintentar[:30], pausa)
    elif ops:
        _espera_ops.pop(eid, None)
    if isinstance(j.get("reservado"), dict):
        from . import sinc_completar
        sinc_completar.al_reservar(eid, j["reservado"])   # B6: guarda max_dado («reservado» de sinc_datos_estado); {} = no es la única instalación
    # 3) números de esta autora (respaldo restaurado aquí)
    if "n_max" in j:
        _revisar_numeros(eid, autora, int(j.get("n_max") or 0))
    if nueva_epoca_web:
        with Session(engine_empresa(eid)) as s:
            s.connection().execute(_sql("UPDATE sinc_dato SET v = 0"))
            s.commit()
        _guardar_estado(eid, **cambios, epoca_web=epoca, cursor=0, releyendo=True, filas_propias=True)   # §2.10: después, /filas del rango propio
        log.warning("sinc_datos empresa %s: la página web cambió de época (respaldo restaurado allá): se relee todo", eid)
        return SEGUNDOS_MINIMO
    if epoca and not est.get("epoca_web"):
        cambios["epoca_web"] = epoca
    # 4) goteo
    filas = [f for f in (j.get("filas") or []) if isinstance(f, dict)]
    releyendo = bool(est.get("releyendo"))
    ultima, completo = _aplicar_goteo(eid, filas, "programa_anterior" if releyendo else None)
    if completo:
        cursor = max(int(est.get("cursor") or 0), int(j.get("cursor") or 0))
    else:
        cursor = max(int(est.get("cursor") or 0), int(ultima or 0))
    mas = bool(j.get("mas")) or not completo
    if cursor != int(est.get("cursor") or 0):
        cambios["cursor"] = cursor
    if releyendo and not mas and not j.get("sembrando"):
        cambios["releyendo"] = False
    if not est.get("ultimo_ok") or _segundos_desde(est.get("ultimo_ok")) >= SEGUNDOS_ULTIMO_OK:
        cambios["ultimo_ok"] = _ahora()
    if any(est.get(k) != v for k, v in cambios.items()):
        _guardar_estado(eid, **cambios)
    try:
        siguiente = max(SEGUNDOS_MINIMO, int(SEGUNDOS_OCIOSO if j.get("siguiente_en") is None else j["siguiente_en"]))
    except (TypeError, ValueError):
        siguiente = SEGUNDOS_OCIOSO
    _siguiente[eid] = siguiente
    if mas:
        return SEGUNDOS_MINIMO
    falta = _ops_en_espera(eid)
    if falta:
        return max(SEGUNDOS_MINIMO, min(siguiente, falta))   # (I-2): las ops esperan; el goteo sigue a su ritmo
    if _hay_pendientes(eid, [o["_id"] for o in ops]):
        return SEGUNDOS_MINIMO
    return siguiente


SEGUNDOS_DESFASE_CAMBIO = 5         # el desfase guardado se actualiza solo si se movió al menos esto
SEGUNDOS_DESFASE_AVISO = 120         # desde aquí queda en el registro (la web lo corrige igual)


def _desfase(hora_web) -> Optional[int]:
    """Segundos que la web va adelante (+) o atrás (−) de esta computadora, con la `hora` de la respuesta; None si no se puede leer."""
    try:
        h = datetime.fromisoformat(str(hora_web).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if h.tzinfo is None:
        return None
    return int(round((h - datetime.now(timezone.utc)).total_seconds()))


def _segundos_desde(iso) -> float:
    try:
        return (datetime.now(timezone.utc) - datetime.fromisoformat(str(iso))).total_seconds()
    except (TypeError, ValueError):
        return 1e9


def _hay_pendientes(eid: int, enviadas: list) -> bool:
    """¿Queda algo por mandar? (las que se acaban de mandar y no trajeron veredicto no cuentan: no se insiste cada 2 s)."""
    fuera = ",".join(str(int(i)) for i in enviadas) or "0"
    with Session(engine_empresa(eid)) as s:
        return bool(s.connection().execute(_sql(f"SELECT 1 FROM sinc_cambio WHERE estado IN (:a, :e) AND id NOT IN ({fuera}) LIMIT 1"),
                                           {"a": ABIERTA, "e": ENVIADA}).first())


def _probar(eid: int, url: str, token: str, cfg: dict) -> float:
    """Sin protocolo guardado: ¿la web ya tiene el canal nuevo? Un goteo puro desde 0; con 200 se pasa al protocolo 2 (plan §2.8)."""
    visto = _canal_visto.pop(eid, None)          # 4.35: la web ya lo dijo hace poco y la subida esperaba el candado: no se vuelve a preguntar
    if visto is None or time.monotonic() - visto >= RECORDAR_CANAL:
        cuerpo = {"protocolo": PROTOCOLO, "version": _version(), "autora": f"{int(cfg.get('terminal') or 0)}.{_epoca_nueva()}",
                  "hora_local": _hora_local(), "desde": 0, "epoca_web": None, "estacion_viva": estacion_viva(eid), "ops": []}
        try:
            r = httpx.post(url + RUTA_DATOS, headers={"Authorization": "Bearer " + token}, json=cuerpo, timeout=httpx.Timeout(PLAZO_LLAMADA, connect=3.0))
        except Exception as ex:  # noqa: BLE001
            log.info("sinc_datos empresa %s: no se pudo preguntar por el canal nuevo (%s)", eid, type(ex).__name__)
            return SEGUNDOS_SIN_CONEXION * 4
        try:
            j = r.json() if getattr(r, "status_code", 0) == 200 else None
        except Exception:  # noqa: BLE001
            j = None
        if not isinstance(j, dict) or j.get("protocolo") != PROTOCOLO:
            return SEGUNDOS_PROBAR
        visto = time.monotonic()
    fotos: dict = {}
    if not _sinc().subida_final_vieja(eid, fotos=fotos):    # plan §2.8 paso 1: lo propio pendiente sale por el camino viejo antes de cambiar
        if _sinc().subida_final_ocupada(eid):
            # 4.35 (arnés S12): otro ciclo de sincronización tuvo el candado más que el plazo (corto: este hilo atiende a todas las empresas): se
            # prueba de nuevo pronto (a los 15 s quedaba en fase con ese ciclo, que también corre cada 15 s, y nunca pasaba al canal nuevo), sin
            # volver a preguntarle a la web por RECORDAR_CANAL
            _canal_visto[eid] = visto
            log.info("sinc_datos empresa %s: la última subida por el camino anterior espera a que termine otro ciclo: se vuelve a probar pronto", eid)
            return SEGUNDOS_MINIMO
        log.info("sinc_datos empresa %s: la última subida por el camino anterior no se pudo hacer: se vuelve a probar", eid)
        return SEGUNDOS_SIN_CONEXION
    pasar_a_protocolo_2(eid)
    _encolar_tras_subida_vieja(eid, int(cfg.get("terminal") or 0), fotos)
    log.warning("sinc_datos empresa %s: la página web tiene el canal nuevo: esta computadora pasa a usarlo", eid)
    return SEGUNDOS_MINIMO


def _encolar_tras_subida_vieja(eid: int, terminal: int, fotos: dict) -> None:
    """Revisión n.º 32: lo que se guardó MIENTRAS corría la última subida por el camino viejo (protocolo 0: el oyente no encolaba y esa subida
    ya había leído) se encola ahora, ya con el protocolo 2 y antes de la relectura: el cambio contra lo que subió, el alta de lo creado y la
    baja de lo eliminado en ese rato. Así la relectura no lo pisa (queda pendiente: I3). Nunca lanza."""
    if not fotos or terminal < 1:
        return
    try:
        with Session(engine_empresa(eid)) as s:
            for tipo, clave in (("cliente", "clientes"), ("producto", "productos")):
                d = _sd().dato(tipo)
                if d is None or _forma(d) != "fila" or clave not in fotos:
                    continue
                subidas = fotos.get(clave) or {}
                vivos = {str(i) for (i,) in s.connection().execute(_sql(f'SELECT id FROM "{d.modelo.__tablename__}"')).all()
                         if modulos.en_rango(int(i), terminal)}
                for ref in sorted(set(subidas) | vivos, key=lambda x: int(x)):
                    antes = json.loads(json.dumps(_sin(d, subidas[ref], extra=True), default=_iso)) if ref in subidas else None
                    ahora = contenido_local(s, eid, d, ref)
                    if not _igual(antes, ahora):
                        anotar(s, eid, tipo, ref, antes, ahora)
            s.commit()
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos empresa %s: no se pudo revisar lo guardado durante la última subida (%s)", eid, type(ex).__name__)


# ======================================================================================================================
# Acciones en vivo (contrato §2.4 y §3.2)
# ======================================================================================================================
def pedir_accion(eid: int, tipo: str, ref: str, accion: str, datos: dict | None = None, por: str | None = None) -> dict:
    """Pide a la web una acción en vivo (aceptar, cancelar, reenlazar…), sin cola. 200: aplica las filas que trae, confirma, corre al_aplicar
    y devuelve {resultado, filas}. 400/404/409 con texto: HTTPException con ese texto. Sin conexión (o la web no la tiene): SinConexionWeb.
    Se conectó y no contestó a tiempo: SinRespuestaWeb (la web PUDO recibirla). Ni el cuerpo ni el detalle van al registro."""
    try:
        con = _conexion(eid)
    except Exception as ex:  # noqa: BLE001
        log.warning("sinc_datos empresa %s: no se pudo leer la conexión (%s)", eid, type(ex).__name__)
        raise SinConexionWeb("sin conexión") from None
    if con is None:
        raise SinConexionWeb("sin conexión")
    url, token, _cfg = con
    espera = httpx.Timeout(PLAZO_ACCION, connect=2.0 if estado(eid).get("sin_conexion_desde") else 4.0)
    cuerpo = {"tipo": str(tipo), "ref": str(ref), "accion": str(accion), "datos": datos or {}, "por": (por or None) and str(por)[:80]}
    try:
        r = httpx.post(url + RUTA_ACCION, headers={"Authorization": "Bearer " + token}, json=cuerpo, timeout=espera)
    except (ConnectError, ConnectTimeout) as ex:
        log.warning("sinc_datos empresa %s: acción sin conexión (%s)", eid, type(ex).__name__)
        raise SinConexionWeb("sin conexión") from None
    except Exception as ex:  # noqa: BLE001  tiempo de lectura agotado, conexión cortada a medias: la web pudo recibirla
        log.warning("sinc_datos empresa %s: acción sin respuesta (%s)", eid, type(ex).__name__)
        raise SinRespuestaWeb("sin respuesta") from None
    codigo = getattr(r, "status_code", 0)
    if codigo == 200:
        try:
            j = r.json()
        except Exception:  # noqa: BLE001
            j = None
        if not isinstance(j, dict) or "resultado" not in j:
            raise SinRespuestaWeb("respuesta inesperada")
        filas = [f for f in (j.get("filas") or []) if isinstance(f, dict)]
        aceptadas = []
        with Session(engine_empresa(eid)) as s, diario.aplicando(0):
            for f in filas:
                if aplicar_canonico(s, eid, f):
                    aceptadas.append(f)
            s.commit()
        for f in aceptadas:
            _al_aplicar(eid, f)
        return {"resultado": j.get("resultado"), "filas": filas}
    detalle = _cuerpo_error(r)
    if codigo in (400, 404, 409) and detalle and detalle.strip() and detalle != "Not Found":
        raise HTTPException(codigo, detalle[:500])
    log.warning("sinc_datos empresa %s: la acción respondió %s", eid, codigo)
    raise SinConexionWeb("sin conexión")


# ======================================================================================================================
# El hilo
# ======================================================================================================================
_hilo = False
_ultima: dict[int, float] = {}
_purga: dict[int, float] = {}


def purgar(eid: int) -> None:
    """La cola guarda 30 días lo que ya tiene veredicto (conserva la última op de cada autora: de ahí sale su número) y sinc_pisado 365 días o
    5000 filas."""
    limite = datetime.fromtimestamp(time.time() - DIAS_COLA * 86400, timezone.utc).isoformat(timespec="seconds")
    limite_p = datetime.fromtimestamp(time.time() - DIAS_PISADO * 86400, timezone.utc).isoformat(timespec="seconds")
    with Session(engine_empresa(eid)) as s:
        con = s.connection()
        con.execute(_sql("DELETE FROM sinc_cambio WHERE estado IN (:h, :r) AND creado < :l "
                         "AND id NOT IN (SELECT MAX(id) FROM sinc_cambio GROUP BY autora)"), {"h": HECHA, "r": RECHAZADA, "l": limite})
        con.execute(_sql("DELETE FROM sinc_pisado WHERE cuando < :l"), {"l": limite_p})
        con.execute(_sql("DELETE FROM sinc_pisado WHERE id NOT IN (SELECT id FROM sinc_pisado ORDER BY id DESC LIMIT :t)"), {"t": TOPE_PISADO})
        s.commit()


def _bucle() -> None:
    time.sleep(10 + random.uniform(0, 5))                    # repartidas: no todas las computadoras preguntan a la vez
    proximo: dict[int, float] = {}
    while True:
        espera = 30.0
        try:
            from .auth import Empresa
            with Session(engine) as sc:
                eids = [x.id for x in sc.exec(select(Empresa)).all()]
            ahora = time.monotonic()
            for eid in eids:
                avisada = eid in _avisadas and ahora - _ultima.get(eid, 0.0) >= SEGUNDOS_MINIMO
                if proximo.get(eid, 0.0) <= ahora or avisada:
                    _avisadas.discard(eid)
                    proximo[eid] = time.monotonic() + ciclo(eid)
                    _ultima[eid] = time.monotonic()
                    if time.monotonic() - _purga.get(eid, 0.0) > 3600:
                        _purga[eid] = time.monotonic()
                        try:
                            if protocolo(eid) == PROTOCOLO:
                                purgar(eid)
                        except Exception as ex:  # noqa: BLE001
                            log.warning("sinc_datos empresa %s: purga (%s)", eid, type(ex).__name__)
            if proximo:
                espera = min(proximo.values()) - time.monotonic()
        except Exception as ex:  # noqa: BLE001
            log.warning("sinc_datos bucle: %s", type(ex).__name__)
        _despertar.wait(min(60.0, max(0.5, espera)))
        if _despertar.is_set():
            _despertar.clear()
            time.sleep(0.5)                                  # que confirme el guardado que avisó


def iniciar_hilo() -> None:
    """Junto a sinc.iniciar_hilo() (main.py l.261): no corre fuera del programa ni con FE_SINC_HILO=0."""
    global _hilo
    if _hilo or not _sinc().MODO_LOCAL or os.environ.get("FE_SINC_HILO", "1") == "0":
        return
    _hilo = True
    threading.Thread(target=_bucle, name="sinc-datos", daemon=True).start()
