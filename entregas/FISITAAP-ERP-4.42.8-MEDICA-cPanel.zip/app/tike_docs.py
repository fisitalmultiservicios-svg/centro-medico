"""TiKe · documentación del cliente (3.54, fase 8). La idea de IT Glue en versión básica: todo lo que el técnico necesita de cada
cliente en un solo lugar, enlazado con tickets y equipos.

Elementos por cliente (una tabla, el tipo decide los campos):
- contacto: cargo, teléfono, correo, notas.            - ubicacion: dirección, horario, notas de acceso al sitio (quién abre, parqueo, alarma).
- clave: usuario, dirección, categoría, notas y el SECRETO cifrado con la clave de la empresa. Se muestra oculto; «ver» y «copiar»
  quedan en la bitácora de accesos (usuario, fecha, IP) y exigen el permiso tike_claves y, si la configuración lo pide (por defecto
  sí), un código vigente de la verificación en dos pasos del usuario.
- procedimiento: texto con formato sencillo (títulos, listas, tablas) con versiones: quién cambió qué y restaurar una anterior.
- red: rango de IP, VLAN, puerta de enlace, DNS, Wi-Fi (nombre; la clave va como elemento «clave» relacionado), proveedor y contrato.
- dominio / certificado / licencia: con fecha de vencimiento; aviso por correo 30 y 7 días antes (también garantías de equipos y
  fin de contratos) y calendario único de vencimientos.
Transversal: relaciones entre elementos, equipos y tickets; búsqueda global; adjuntos; «visible para el cliente» (lo ve en el
portal; las claves nunca); exportación por cliente (zip con un .md legible, los datos en JSON y los adjuntos; las claves solo con
código de dos pasos)."""
import io
import json
import logging
import re
import secrets
import threading
import zipfile
from datetime import timedelta
from html import escape
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from . import planes, secretos
from .auth import Contexto, Usuario, _ip, auditar, requiere, sesion_empresa, verificar_totp
from .config import DATA_DIR, ahora_cr
from .db import Cliente, Empresa, engine, get_session, por_empresa, sesion_de
from .tike import Ticket, TikeConfig, _config, _portal, _acceso, admin
from .tike_contratos import Contrato, Equipo

log = logging.getLogger(__name__)
router = APIRouter(tags=["tike"])

TIPOS = ("contacto", "ubicacion", "clave", "procedimiento", "red", "dominio", "certificado", "licencia")
NOMBRES_TIPO = {"contacto": "Contacto", "ubicacion": "Ubicación", "clave": "Contraseña", "procedimiento": "Procedimiento", "red": "Red", "dominio": "Dominio", "certificado": "Certificado SSL", "licencia": "Licencia"}
CON_VENCIMIENTO = ("dominio", "certificado", "licencia")
CAMPOS = {   # campos de datos por tipo (nombre → máximo de caracteres); lo demás se descarta
    "contacto": {"cargo": 80, "telefono": 30, "correo": 120, "notas": 1000},
    "ubicacion": {"direccion": 300, "horario": 120, "acceso": 1000, "telefono": 30},
    "clave": {"usuario": 120, "url": 300, "categoria": 60, "notas": 1000},
    "procedimiento": {"contenido": 60000, "resumen": 200},
    "red": {"rango_ip": 60, "vlan": 60, "gateway": 60, "dns": 120, "wifi_ssid": 60, "proveedor": 80, "contrato_isp": 80, "notas": 1000},
    "dominio": {"dominio": 120, "registrador": 80, "dns_proveedor": 80, "auto_renueva": 5, "notas": 600},
    "certificado": {"dominio": 120, "emisor": 80, "tipo_cert": 60, "notas": 600},
    "licencia": {"producto": 120, "cantidad": 10, "proveedor": 80, "costo": 20, "facturar_a": 120, "notas": 600},
}
PLANTILLAS = [
    {"nombre": "Alta de usuario", "contenido": "# Alta de usuario\n\n1. Crear el usuario en el directorio (nombre.apellido).\n2. Asignar el grupo del departamento.\n3. Crear el buzón de correo y agregarlo a las listas.\n4. Instalar el equipo con la imagen estándar y unirlo al dominio.\n5. Entregar credenciales temporales y pedir cambio de clave.\n\n## Verificar\n- Entra al correo desde el celular\n- Imprime en la impresora del área"},
    {"nombre": "Respaldo y restauración", "contenido": "# Respaldo y restauración\n\n## Qué se respalda\n| Qué | Dónde | Frecuencia |\n|---|---|---|\n| Base de datos | NAS, carpeta /respaldos | Diaria 10 p. m. |\n| Documentos | Nube | Continua |\n\n## Restaurar\n1. Detener el servicio.\n2. Copiar el respaldo del día.\n3. Iniciar y verificar con el usuario."},
    {"nombre": "Cambio de equipo", "contenido": "# Cambio de equipo\n\n1. Respaldar escritorio, documentos y favoritos.\n2. Anotar impresoras y programas instalados.\n3. Instalar el equipo nuevo con la imagen estándar.\n4. Restaurar datos y configurar el correo.\n5. Registrar el equipo nuevo en TiKe › Equipos y dar de baja el anterior."},
    {"nombre": "Incidente de seguridad", "contenido": "# Incidente de seguridad\n\n1. Aislar el equipo de la red (desconectar el cable o el Wi-Fi).\n2. No apagar: tomar foto de la pantalla.\n3. Avisar al responsable del cliente y abrir ticket crítico.\n4. Cambiar las claves relacionadas (ver Contraseñas).\n5. Documentar qué pasó y qué se cambió."},
]
MAX_ADJUNTO = 8 * 1024 * 1024
AVISOS_DIAS = (30, 7)


# ------------------------------------------------------------------------------------------------- tablas
class Elemento(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    cliente_id: int = Field(index=True)
    tipo: str = Field(index=True)
    nombre: str
    datos: str = "{}"                             # JSON según CAMPOS[tipo]
    secreto: Optional[str] = None                 # solo clave: cifrado con la clave de la empresa
    vence: Optional[str] = None                   # dominio, certificado, licencia (AAAA-MM-DD)
    equipo_id: Optional[int] = None
    etiquetas: str = ""                           # separadas por coma
    visible_cliente: bool = False                 # lo ve el cliente en el portal (nunca las claves)
    adjuntos: str = "[]"                          # JSON [{nombre, archivo, tamano}]
    avisos: str = "[]"                            # JSON [30, 7]: avisos de vencimiento ya enviados para la fecha actual
    version: int = 1
    activo: bool = True
    usuario: str = ""                             # quien hizo el último cambio
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    actualizado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class ElementoVersion(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    elemento_id: int = Field(index=True)
    version: int = 1
    nombre: str = ""
    datos: str = "{}"
    usuario: str = ""
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class Relacion(SQLModel, table=True):
    """Enlace entre dos cosas: elemento, equipo o ticket (tipo + id a cada lado)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    a_tipo: str = "elemento"
    a_id: int = Field(index=True)
    b_tipo: str = "elemento"
    b_id: int = Field(index=True)
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


class AccesoClave(SQLModel, table=True):
    """Bitácora: quién vio o copió una contraseña, cuándo y desde dónde."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    elemento_id: int = Field(index=True)
    usuario: str = ""
    accion: str = "ver"                           # ver | copiar | exportar | cambiar | eliminar (3.87)
    ip: Optional[str] = None
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))


por_empresa(Elemento, ElementoVersion, Relacion, AccesoClave)


# ------------------------------------------------------------------------------------------------- utilidades
def _json(v, defecto):
    try:
        x = json.loads(v or "")
        return x if isinstance(x, type(defecto)) else defecto
    except (ValueError, TypeError):
        return defecto


def _limpiar_datos(tipo: str, datos: dict) -> dict:
    out = {}
    for k, maximo in CAMPOS.get(tipo, {}).items():
        v = datos.get(k)
        if v is None:
            continue
        out[k] = str(v).strip()[:maximo]
    return out


def _salida(e: Elemento, detalle: bool = False) -> dict:
    hoy = ahora_cr().date().isoformat()
    d = {"id": e.id, "cliente_id": e.cliente_id, "tipo": e.tipo, "tipo_nombre": NOMBRES_TIPO.get(e.tipo, e.tipo), "nombre": e.nombre, "datos": _json(e.datos, {}), "vence": e.vence, "equipo_id": e.equipo_id,
         "etiquetas": [x.strip() for x in (e.etiquetas or "").split(",") if x.strip()], "visible_cliente": e.visible_cliente, "adjuntos": _json(e.adjuntos, []), "version": e.version, "activo": e.activo,
         "usuario": e.usuario, "creado": e.creado, "actualizado": e.actualizado, "tiene_secreto": bool(e.secreto),
         "vencido": bool(e.vence and e.vence < hoy), "por_vencer": bool(e.vence and hoy <= e.vence <= (ahora_cr().date() + timedelta(days=30)).isoformat())}
    if e.tipo == "procedimiento" and not detalle:
        d["datos"] = {"resumen": d["datos"].get("resumen", ""), "contenido": (d["datos"].get("contenido") or "")[:160]}
    return d


def _elemento(s: Session, eid: int, xid: int) -> Elemento:
    e = s.get(Elemento, xid)
    if not e or e.empresa_id != eid:
        raise HTTPException(404, "Elemento no encontrado")
    return e


def _cliente(s: Session, eid: int, cid: Optional[int]) -> Cliente:
    c = s.get(Cliente, cid) if cid else None
    if not c or c.empresa_id != eid:
        raise HTTPException(400, "El cliente indicado no existe")
    return c


def _relaciones(s: Session, eid: int, tipo: str, xid: int) -> list[dict]:
    out = []
    filas = s.exec(select(Relacion).where(Relacion.empresa_id == eid, ((Relacion.a_tipo == tipo) & (Relacion.a_id == xid)) | ((Relacion.b_tipo == tipo) & (Relacion.b_id == xid)))).all()  # type: ignore[operator]
    for r in filas:
        ot, oi = (r.b_tipo, r.b_id) if (r.a_tipo, r.a_id) == (tipo, xid) else (r.a_tipo, r.a_id)
        nombre = ""
        if ot == "elemento":
            x = s.get(Elemento, oi); nombre = f"{NOMBRES_TIPO.get(x.tipo, x.tipo)}: {x.nombre}" if x else "(borrado)"
        elif ot == "equipo":
            q = s.get(Equipo, oi); nombre = f"Equipo {q.codigo} · {q.nombre}" if q else "(borrado)"
        elif ot == "ticket":
            t = s.get(Ticket, oi); nombre = f"Ticket {t.codigo} · {t.asunto}" if t else "(borrado)"
        out.append({"id": r.id, "tipo": ot, "ref_id": oi, "nombre": nombre})
    return out


def _guardar_version(s: Session, e: Elemento, usuario: str) -> None:
    s.add(ElementoVersion(empresa_id=e.empresa_id, elemento_id=e.id, version=e.version, nombre=e.nombre, datos=e.datos, usuario=e.usuario or usuario))


# ------------------------------------------------------------------------------------------------- API: elementos
class ElementoIn(BaseModel):
    cliente_id: int
    tipo: str
    nombre: str = PField(min_length=1, max_length=120)
    datos: dict = PField(default_factory=dict)
    secreto: Optional[str] = PField(None, max_length=500)        # clave: None = no tocar; "" = borrar
    vence: Optional[str] = PField(None, max_length=10)
    equipo_id: Optional[int] = None
    etiquetas: Optional[list] = None
    visible_cliente: bool = False


def _validar(s: Session, eid: int, data: ElementoIn, e: Elemento) -> None:
    if data.tipo not in TIPOS:
        raise HTTPException(400, "Tipo de elemento desconocido")
    cli = _cliente(s, eid, data.cliente_id)
    if data.vence:
        try:
            ahora_cr().date().fromisoformat(data.vence[:10])
        except ValueError:
            raise HTTPException(400, "La fecha de vencimiento va como AAAA-MM-DD")
    if data.equipo_id:
        q = s.get(Equipo, data.equipo_id)
        if not q or q.empresa_id != eid or q.cliente_id != cli.id:
            raise HTTPException(400, "El equipo no es de ese cliente")
    if data.tipo == "clave" and data.visible_cliente:
        raise HTTPException(400, "Las contraseñas nunca se muestran al cliente")
    e.cliente_id, e.tipo, e.nombre = cli.id, data.tipo, " ".join(data.nombre.split())[:120]
    e.datos = json.dumps(_limpiar_datos(data.tipo, data.datos or {}), ensure_ascii=False)
    e.vence = data.vence[:10] if data.vence and data.tipo in CON_VENCIMIENTO else None
    e.equipo_id = data.equipo_id or None; e.visible_cliente = bool(data.visible_cliente and data.tipo != "clave")
    e.etiquetas = ",".join(dict.fromkeys(str(x).strip()[:30] for x in (data.etiquetas or []) if str(x).strip()))[:300]


@router.get("/api/tike/docs")
def listar(cliente_id: Optional[int] = None, tipo: Optional[str] = None, q: Optional[str] = None, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    qy = select(Elemento).where(Elemento.empresa_id == eid, Elemento.activo == True)  # noqa: E712
    if cliente_id:
        qy = qy.where(Elemento.cliente_id == cliente_id)
    if tipo:
        qy = qy.where(Elemento.tipo == tipo)
    es = s.exec(qy.order_by(Elemento.tipo, Elemento.nombre)).all()
    if q:
        ql = q.strip().lower()
        es = [e for e in es if ql in e.nombre.lower() or ql in (e.etiquetas or "").lower() or any(ql in str(v).lower() for v in _json(e.datos, {}).values())]
    return [_salida(e) for e in es[:1000]]


@router.get("/api/tike/docs/buscar")
def buscar(q: str, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Búsqueda global: elementos (sin secretos), equipos y tickets."""
    eid = ctx.empresa.id; ql = (q or "").strip().lower()
    if len(ql) < 2:
        return {"elementos": [], "equipos": [], "tickets": []}
    es = [e for e in s.exec(select(Elemento).where(Elemento.empresa_id == eid, Elemento.activo == True)).all() if ql in e.nombre.lower() or ql in (e.etiquetas or "").lower() or any(ql in str(v).lower() for v in _json(e.datos, {}).values())]  # noqa: E712
    qs = [x for x in s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.activo == True)).all() if any(ql in (getattr(x, k) or "").lower() for k in ("nombre", "codigo", "marca", "modelo", "serie", "ubicacion", "notas"))]  # noqa: E712
    ts = [t for t in s.exec(select(Ticket).where(Ticket.empresa_id == eid)).all() if ql in (t.asunto or "").lower() or ql in (t.codigo or "").lower() or ql in (t.descripcion or "").lower()]
    nombres = {c.id: (c.nombre_comercial or c.nombre) for c in s.exec(select(Cliente).where(Cliente.empresa_id == eid)).all()}
    return {"elementos": [{**_salida(e), "cliente_nombre": nombres.get(e.cliente_id, "")} for e in es[:50]],
            "equipos": [{"id": x.id, "codigo": x.codigo, "nombre": x.nombre, "cliente_id": x.cliente_id, "cliente_nombre": nombres.get(x.cliente_id, "")} for x in qs[:30]],
            "tickets": [{"id": t.id, "codigo": t.codigo, "asunto": t.asunto, "estado": t.estado, "cliente_nombre": t.cliente_nombre} for t in ts[:30]]}


@router.get("/api/tike/docs/plantillas")
def plantillas(ctx: Contexto = Depends(admin)):
    return PLANTILLAS


@router.get("/api/tike/docs/vencimientos")
def vencimientos(dias: int = 90, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Calendario único: dominios, certificados, licencias, garantías de equipos y fin de contratos en los próximos N días (y lo vencido)."""
    eid = ctx.empresa.id; hoy = ahora_cr().date(); tope = (hoy + timedelta(days=max(1, min(dias, 730)))).isoformat()
    nombres = {c.id: (c.nombre_comercial or c.nombre) for c in s.exec(select(Cliente).where(Cliente.empresa_id == eid)).all()}
    out = []
    for e in s.exec(select(Elemento).where(Elemento.empresa_id == eid, Elemento.activo == True, Elemento.vence.isnot(None), Elemento.vence <= tope)).all():  # type: ignore[union-attr]  # noqa: E712
        out.append({"tipo": e.tipo, "tipo_nombre": NOMBRES_TIPO.get(e.tipo, e.tipo), "id": e.id, "nombre": e.nombre, "cliente_id": e.cliente_id, "cliente_nombre": nombres.get(e.cliente_id, ""), "vence": e.vence})
    for q in s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.activo == True, Equipo.garantia_hasta.isnot(None), Equipo.garantia_hasta <= tope)).all():  # type: ignore[union-attr]  # noqa: E712
        out.append({"tipo": "garantia", "tipo_nombre": "Garantía de equipo", "id": q.id, "nombre": f"{q.codigo} · {q.nombre}", "cliente_id": q.cliente_id, "cliente_nombre": nombres.get(q.cliente_id, ""), "vence": q.garantia_hasta})
    for c in s.exec(select(Contrato).where(Contrato.empresa_id == eid, Contrato.activo == True, Contrato.fin.isnot(None), Contrato.fin <= tope)).all():  # type: ignore[union-attr]  # noqa: E712
        out.append({"tipo": "contrato", "tipo_nombre": "Fin de contrato", "id": c.id, "nombre": c.nombre or c.cliente_nombre, "cliente_id": c.cliente_id, "cliente_nombre": c.cliente_nombre, "vence": c.fin})
    for x in out:
        x["dias"] = (ahora_cr().date().fromisoformat(x["vence"][:10]) - hoy).days
    return sorted(out, key=lambda x: x["vence"])


@router.post("/api/tike/docs")
def nuevo(data: ElementoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    eid = ctx.empresa.id
    e = Elemento(empresa_id=eid, cliente_id=data.cliente_id, tipo=data.tipo, nombre=data.nombre, usuario=ctx.usuario.nombre)
    _validar(s, eid, data, e)
    if data.tipo == "clave":
        if not (data.secreto or "").strip():
            raise HTTPException(400, "Escriba la contraseña")
        if secretos.asegurar_clave(ctx.empresa):
            ec = sc.get(Empresa, eid)
            if ec:
                ec.clave_cifrada = ctx.empresa.clave_cifrada; sc.add(ec); sc.commit()
        e.secreto = secretos.cifrar(ctx.empresa.clave_cifrada, data.secreto.strip())
    s.add(e); s.commit(); s.refresh(e)
    _guardar_version(s, e, ctx.usuario.nombre); s.commit()
    return _salida(e, True)


@router.get("/api/tike/docs/{xid}")
def ver(xid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; e = _elemento(s, eid, xid)
    d = _salida(e, True)
    d["relaciones"] = _relaciones(s, eid, "elemento", e.id)
    d["versiones"] = [{"version": v.version, "usuario": v.usuario, "creado": v.creado} for v in s.exec(select(ElementoVersion).where(ElementoVersion.elemento_id == e.id).order_by(ElementoVersion.version.desc())).all()]
    if e.tipo == "clave":
        d["accesos"] = [{"usuario": a.usuario, "accion": a.accion, "ip": a.ip, "creado": a.creado} for a in s.exec(select(AccesoClave).where(AccesoClave.elemento_id == e.id).order_by(AccesoClave.id.desc())).all()[:50]]
    if e.equipo_id:
        q = s.get(Equipo, e.equipo_id); d["equipo"] = {"id": q.id, "codigo": q.codigo, "nombre": q.nombre} if q else None
    return d


@router.put("/api/tike/docs/{xid}")
def editar(xid: int, data: ElementoIn, request: Request, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    eid = ctx.empresa.id; e = _elemento(s, eid, xid)
    if data.tipo != e.tipo:
        raise HTTPException(400, "El tipo de un elemento no se cambia: cree otro")
    # 3.87: reemplazar una contraseña guardada exige el mismo permiso que verla (antes el Técnico de soporte la sobrescribía a ciegas y
    # la original se perdía sin rastro); crear una nueva sigue abierto a quien tenga TiKe. El cambio queda en «Quién la vio o la cambió».
    cambia_secreto = e.tipo == "clave" and data.secreto is not None
    if cambia_secreto and not ctx.puede("tike_claves"):
        raise HTTPException(403, "Su rol no puede cambiar contraseñas guardadas: pídaselo a quien las administra")
    antes = (e.nombre, e.datos)
    _validar(s, eid, data, e)
    if cambia_secreto:
        if not data.secreto.strip():
            raise HTTPException(400, "La contraseña no puede quedar vacía")
        e.secreto = secretos.cifrar(ctx.empresa.clave_cifrada, data.secreto.strip()); e.usuario = ctx.usuario.nombre
        s.add(AccesoClave(empresa_id=eid, elemento_id=e.id, usuario=ctx.usuario.nombre, accion="cambiar", ip=_ip(request)))
    if (e.nombre, e.datos) != antes:
        e.version += 1; e.usuario = ctx.usuario.nombre
        _guardar_version(s, e, ctx.usuario.nombre)
    e.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(e); s.commit(); s.refresh(e)
    if cambia_secreto:
        try:
            auditar(sc, "tike_clave_cambiar", f"{e.nombre} (cliente {e.cliente_id})", getattr(ctx.usuario, "id", None) and sc.get(Usuario, ctx.usuario.id), eid, request)
        except Exception:  # noqa: BLE001
            pass
    return ver(xid, ctx, s)


@router.delete("/api/tike/docs/{xid}")
def quitar(xid: int, request: Request, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    e = _elemento(s, ctx.empresa.id, xid)
    # 3.87: quitar una contraseña guardada es como cambiarla (desaparece de la ficha): exige el permiso de contraseñas y queda en la
    # bitácora y en la auditoría. Antes el Técnico de soporte la hacía desaparecer sin dejar rastro.
    es_clave = e.tipo == "clave"
    if es_clave and not ctx.puede("tike_claves"):
        raise HTTPException(403, "Su rol no puede quitar contraseñas guardadas: pídaselo a quien las administra")
    if es_clave:
        s.add(AccesoClave(empresa_id=e.empresa_id, elemento_id=e.id, usuario=ctx.usuario.nombre, accion="eliminar", ip=_ip(request)))
    e.activo = False; e.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(e); s.commit()
    if es_clave:
        try:
            auditar(sc, "tike_clave_eliminar", f"{e.nombre} (cliente {e.cliente_id})", getattr(ctx.usuario, "id", None) and sc.get(Usuario, ctx.usuario.id), e.empresa_id, request)
        except Exception:  # noqa: BLE001  (la auditoría no detiene el borrado)
            pass
    return {"ok": True}


@router.get("/api/tike/docs/{xid}/versiones/{version}")
def ver_version(xid: int, version: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    e = _elemento(s, ctx.empresa.id, xid)
    v = s.exec(select(ElementoVersion).where(ElementoVersion.elemento_id == e.id, ElementoVersion.version == version)).first()
    if not v:
        raise HTTPException(404, "Versión no encontrada")
    return {"version": v.version, "nombre": v.nombre, "datos": _json(v.datos, {}), "usuario": v.usuario, "creado": v.creado}


@router.post("/api/tike/docs/{xid}/restaurar/{version}")
def restaurar(xid: int, version: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    e = _elemento(s, ctx.empresa.id, xid)
    v = s.exec(select(ElementoVersion).where(ElementoVersion.elemento_id == e.id, ElementoVersion.version == version)).first()
    if not v:
        raise HTTPException(404, "Versión no encontrada")
    e.nombre, e.datos = v.nombre, v.datos; e.version += 1; e.usuario = ctx.usuario.nombre; e.actualizado = ahora_cr().isoformat(timespec="seconds")
    s.add(e); s.commit(); s.refresh(e); _guardar_version(s, e, ctx.usuario.nombre); s.commit()
    return ver(xid, ctx, s)


# ------------------------------------------------------------------------------------------------- contraseñas: ver y copiar con bitácora
class RevelarIn(BaseModel):
    codigo: Optional[str] = PField(None, max_length=12)
    accion: str = "ver"


def _exigir_dos_pasos(ctx: Contexto, sc: Session, cfg: TikeConfig, codigo: Optional[str]) -> None:
    if not getattr(cfg, "claves_2fa", True):
        return
    u = sc.get(Usuario, getattr(ctx.usuario, "id", None)) if getattr(ctx.usuario, "id", None) else None
    if not u or not u.mfa_activo or not u.mfa_secret:
        raise HTTPException(403, {"codigo": "sin_mfa", "mensaje": "Para ver contraseñas active la verificación en dos pasos en su perfil"})
    if not codigo or not verificar_totp(u.mfa_secret, codigo):
        raise HTTPException(403, {"codigo": "mfa", "mensaje": "Escriba el código vigente de su aplicación de verificación"})


@router.post("/api/tike/docs/{xid}/revelar")
def revelar(xid: int, data: RevelarIn, request: Request, ctx: Contexto = Depends(requiere("tike_claves")), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    eid = ctx.empresa.id; planes.exigir_modulo(ctx.empresa, "tike"); e = _elemento(s, eid, xid)
    if e.tipo != "clave" or not e.secreto:
        raise HTTPException(400, "Ese elemento no tiene contraseña")
    _exigir_dos_pasos(ctx, sc, _config(s, eid), data.codigo)
    accion = data.accion if data.accion in ("ver", "copiar") else "ver"
    s.add(AccesoClave(empresa_id=eid, elemento_id=e.id, usuario=ctx.usuario.nombre, accion=accion, ip=_ip(request))); s.commit()
    try:
        auditar(sc, "tike_clave_" + accion, f"{e.nombre} (cliente {e.cliente_id})", getattr(ctx.usuario, "id", None) and sc.get(Usuario, ctx.usuario.id), eid, request)
    except Exception:  # noqa: BLE001
        pass
    return {"secreto": secretos.descifrar(ctx.empresa.clave_cifrada, e.secreto), "accion": accion}


# ------------------------------------------------------------------------------------------------- relaciones y adjuntos
class RelacionIn(BaseModel):
    tipo: str                                     # elemento | equipo | ticket
    ref_id: int


@router.post("/api/tike/docs/{xid}/relaciones")
def relacionar(xid: int, data: RelacionIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; e = _elemento(s, eid, xid)
    if data.tipo not in ("elemento", "equipo", "ticket"):
        raise HTTPException(400, "Tipo de relación desconocido")
    destino = {"elemento": Elemento, "equipo": Equipo, "ticket": Ticket}[data.tipo]
    x = s.get(destino, data.ref_id)
    if not x or x.empresa_id != eid or (data.tipo == "elemento" and x.id == e.id):
        raise HTTPException(400, "No existe lo que quiere relacionar")
    ya = s.exec(select(Relacion).where(Relacion.empresa_id == eid, ((Relacion.a_tipo == "elemento") & (Relacion.a_id == e.id) & (Relacion.b_tipo == data.tipo) & (Relacion.b_id == data.ref_id))
                                       | ((Relacion.b_tipo == "elemento") & (Relacion.b_id == e.id) & (Relacion.a_tipo == data.tipo) & (Relacion.a_id == data.ref_id)))).first()  # type: ignore[operator]
    if not ya:
        s.add(Relacion(empresa_id=eid, a_tipo="elemento", a_id=e.id, b_tipo=data.tipo, b_id=data.ref_id)); s.commit()
    return _relaciones(s, eid, "elemento", e.id)


@router.delete("/api/tike/docs/{xid}/relaciones/{rid}")
def quitar_relacion(xid: int, rid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; _elemento(s, eid, xid); r = s.get(Relacion, rid)
    if not r or r.empresa_id != eid:
        raise HTTPException(404, "Relación no encontrada")
    s.delete(r); s.commit()
    return {"ok": True}


def relaciones_de(s: Session, eid: int, tipo: str, ref_id: int) -> list[dict]:
    """Lo relacionado con un equipo o un ticket (lo usan sus fichas)."""
    return _relaciones(s, eid, tipo, ref_id)


@router.get("/api/tike/docs/relacionado/{tipo}/{ref_id}")
def relacionado(tipo: str, ref_id: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    if tipo not in ("equipo", "ticket"):
        raise HTTPException(400, "Tipo desconocido")
    return _relaciones(s, ctx.empresa.id, tipo, ref_id)


def _carpeta(eid: int, xid: int) -> Path:
    p = DATA_DIR / "empresas" / str(eid) / "tike_docs" / str(xid)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _nombre_seguro(nombre: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", (nombre or "archivo").strip())[:80].strip("._") or "archivo"


@router.post("/api/tike/docs/{xid}/adjuntos")
def subir_adjunto(xid: int, archivo: UploadFile = File(...), ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; e = _elemento(s, eid, xid)
    datos = archivo.file.read(MAX_ADJUNTO + 1)
    if len(datos) > MAX_ADJUNTO:
        raise HTTPException(400, "El adjunto no puede pasar de 8 MB")
    if not datos:
        raise HTTPException(400, "El archivo está vacío")
    nombre = _nombre_seguro(archivo.filename or "archivo"); fisico = f"{secrets.token_hex(4)}-{nombre}"
    (_carpeta(eid, e.id) / fisico).write_bytes(datos)
    lista = _json(e.adjuntos, []); lista.append({"nombre": nombre, "archivo": fisico, "tamano": len(datos)})
    e.adjuntos = json.dumps(lista, ensure_ascii=False); e.actualizado = ahora_cr().isoformat(timespec="seconds"); s.add(e); s.commit()
    return lista


@router.get("/api/tike/docs/{xid}/adjuntos/{archivo}", include_in_schema=False)
def ver_adjunto(xid: int, archivo: str, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; _elemento(s, eid, xid)
    ruta = _carpeta(eid, xid) / _nombre_seguro(archivo)
    if not ruta.is_file():
        raise HTTPException(404, "Adjunto no encontrado")
    return FileResponse(ruta, filename=archivo.split("-", 1)[-1] if "-" in archivo else archivo)


@router.delete("/api/tike/docs/{xid}/adjuntos/{archivo}")
def quitar_adjunto(xid: int, archivo: str, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; e = _elemento(s, eid, xid)
    lista = [a for a in _json(e.adjuntos, []) if a.get("archivo") != archivo]
    ruta = _carpeta(eid, xid) / _nombre_seguro(archivo)
    if ruta.is_file():
        ruta.unlink()
    e.adjuntos = json.dumps(lista, ensure_ascii=False); s.add(e); s.commit()
    return lista


# ------------------------------------------------------------------------------------------------- exportar por cliente
def _md_elemento(e: Elemento, secreto: Optional[str] = None) -> str:
    d = _json(e.datos, {})
    lineas = [f"### {NOMBRES_TIPO.get(e.tipo, e.tipo)}: {e.nombre}"]
    if e.vence:
        lineas.append(f"- Vence: {e.vence}")
    for k, v in d.items():
        if k == "contenido":
            continue
        if v:
            lineas.append(f"- {k.replace('_', ' ').capitalize()}: {v}")
    if e.tipo == "clave":
        lineas.append(f"- Contraseña: {secreto if secreto is not None else '(no incluida)'}")
    if d.get("contenido"):
        lineas.append("")
        lineas.append(d["contenido"])
    if e.etiquetas:
        lineas.append(f"- Etiquetas: {e.etiquetas}")
    return "\n".join(lineas) + "\n"


@router.get("/api/tike/docs/exportar/{cliente_id}")
def exportar(cliente_id: int, con_claves: int = 0, codigo: Optional[str] = None, request: Request = None, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa), sc: Session = Depends(get_session)):
    """Zip con documentacion.md (legible), datos.json y los adjuntos. Las contraseñas solo con con_claves=1, permiso tike_claves y código de dos pasos."""
    eid = ctx.empresa.id; cli = _cliente(s, eid, cliente_id)
    es = s.exec(select(Elemento).where(Elemento.empresa_id == eid, Elemento.cliente_id == cli.id, Elemento.activo == True).order_by(Elemento.tipo, Elemento.nombre)).all()  # noqa: E712
    secretos_map: dict = {}
    if con_claves:
        if not ctx.puede("tike_claves"):
            raise HTTPException(403, "Su rol no puede exportar contraseñas")
        _exigir_dos_pasos(ctx, sc, _config(s, eid), codigo)
        for e in es:
            if e.tipo == "clave" and e.secreto:
                secretos_map[e.id] = secretos.descifrar(ctx.empresa.clave_cifrada, e.secreto)
                s.add(AccesoClave(empresa_id=eid, elemento_id=e.id, usuario=ctx.usuario.nombre, accion="exportar", ip=_ip(request) if request else None))
        s.commit()
    equipos = s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.cliente_id == cli.id, Equipo.activo == True)).all()  # noqa: E712
    md = [f"# Documentación de {cli.nombre_comercial or cli.nombre}", f"Exportado el {ahora_cr().strftime('%d/%m/%Y %H:%M')} por {ctx.usuario.nombre}", ""]
    for tipo in TIPOS:
        grupo = [e for e in es if e.tipo == tipo]
        if grupo:
            md.append(f"## {NOMBRES_TIPO[tipo]}s" if tipo != "red" else "## Redes"); md.append("")
            md.extend(_md_elemento(e, secretos_map.get(e.id)) for e in grupo)
    if equipos:
        md.append("## Equipos"); md.append("")
        md.extend(f"- {q.codigo} · {q.nombre} ({q.tipo}{', ' + q.marca if q.marca else ''}{' ' + q.modelo if q.modelo else ''}{', serie ' + q.serie if q.serie else ''}){' · garantía hasta ' + q.garantia_hasta if q.garantia_hasta else ''}" for q in equipos)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("documentacion.md", "\n".join(md))
        z.writestr("datos.json", json.dumps({"cliente": {"id": cli.id, "nombre": cli.nombre, "numero_id": cli.numero_id}, "elementos": [{**_salida(e, True), "secreto": secretos_map.get(e.id)} for e in es],
                                             "equipos": [{"id": q.id, "codigo": q.codigo, "nombre": q.nombre, "tipo": q.tipo, "marca": q.marca, "modelo": q.modelo, "serie": q.serie, "ubicacion": q.ubicacion, "garantia_hasta": q.garantia_hasta} for q in equipos]},
                                            ensure_ascii=False, indent=1))
        for e in es:
            for a in _json(e.adjuntos, []):
                ruta = _carpeta(eid, e.id) / _nombre_seguro(a.get("archivo", ""))
                if ruta.is_file():
                    z.write(ruta, f"adjuntos/{e.id}-{a.get('nombre', 'archivo')}")
    nombre = _nombre_seguro(cli.nombre_comercial or cli.nombre)
    return Response(buf.getvalue(), media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="documentacion-{nombre}.zip"'})


# ------------------------------------------------------------------------------------------------- avisos de vencimiento (cola)
def avisar_vencimientos_empresa(eid: int, enviar=None) -> int:
    """Correo al equipo 30 y 7 días antes de que venza un dominio, certificado, licencia, garantía de equipo o contrato."""
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    if not e:
        return 0
    hoy = ahora_cr().date(); enviados = 0
    with sesion_de(eid) as s:
        cfg = _config(s, eid)
        para = (cfg.correo_aviso or e.correo or "").strip()
        if not para or (enviar is None and not getattr(e, "smtp_host", None)):
            return 0
        pendientes = []
        for x in s.exec(select(Elemento).where(Elemento.empresa_id == eid, Elemento.activo == True, Elemento.vence.isnot(None))).all():  # type: ignore[union-attr]  # noqa: E712
            dias = (hoy.fromisoformat(x.vence[:10]) - hoy).days
            hechos = _json(x.avisos, [])
            for d in AVISOS_DIAS:
                if dias <= d and d not in hechos:
                    pendientes.append((x, dias, d)); break
        for x, dias, d in pendientes:
            hechos = _json(x.avisos, []); hechos.append(d); x.avisos = json.dumps(hechos); s.add(x)
        for q in s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.activo == True, Equipo.garantia_hasta.isnot(None))).all():  # type: ignore[union-attr]  # noqa: E712
            dias = (hoy.fromisoformat(q.garantia_hasta[:10]) - hoy).days
            if 0 <= dias <= 7 and dias in (7, 0):
                pendientes.append((q, dias, dias))
        for c in s.exec(select(Contrato).where(Contrato.empresa_id == eid, Contrato.activo == True, Contrato.fin.isnot(None), Contrato.renovacion_auto == False)).all():  # type: ignore[union-attr]  # noqa: E712
            dias = (hoy.fromisoformat(c.fin[:10]) - hoy).days
            if dias in (30, 7):
                pendientes.append((c, dias, dias))
        s.commit()
        if not pendientes:
            return 0
        filas = []
        for x, dias, _ in pendientes:
            if isinstance(x, Elemento):
                filas.append(f"{NOMBRES_TIPO.get(x.tipo, x.tipo)}: {x.nombre} · vence {x.vence} ({'vencido' if dias < 0 else f'en {dias} día(s)'})")
            elif isinstance(x, Equipo):
                filas.append(f"Garantía del equipo {x.codigo} · {x.nombre} · vence {x.garantia_hasta} (en {dias} día(s))")
            else:
                filas.append(f"Contrato {x.nombre or x.cliente_nombre} · termina {x.fin} (en {dias} día(s))")
        asunto = f"TiKe: {len(filas)} vencimiento(s) próximos"
        from . import correo_diseno as _dz                             # 3.83: diseño común
        html = _dz.armar(_dz.de_empresa(e), titulo=f"{len(filas)} vencimiento(s) próximos", antetitulo="TiKe · Documentación", asunto=asunto,
                         preencabezado=filas[0] if filas else "", parrafos_txt=["Estos documentos de clientes vencen pronto o ya vencieron:"],
                         lista=filas, despues=["Revíselos en TiKe › Documentación › Vencimientos."])
        texto = "Vencimientos próximos:\n" + "\n".join("- " + f for f in filas)
        if enviar is not None:
            enviar(para, asunto, texto); return len(filas)

        def _enviar():
            try:
                from . import correo
                from .main import _cfg_smtp
                correo.enviar(_cfg_smtp(e), [para], asunto, html, texto, [])
            except Exception:  # noqa: BLE001
                pass
        threading.Thread(target=_enviar, daemon=True).start()
        return len(filas)


def avisar_vencimientos_todas() -> int:
    total = 0
    with Session(engine) as sc:
        eids = [e.id for e in sc.exec(select(Empresa)).all() if "tike" in planes.modulos_de(e)]
    for eid in eids:
        try:
            total += avisar_vencimientos_empresa(eid)
        except Exception as ex:  # noqa: BLE001
            log.warning("TiKe vencimientos empresa %s: %s", eid, ex)
    return total


# ------------------------------------------------------------------------------------------------- portal del cliente: lo marcado como visible
@router.get("/api/soporte/{slug}/docs")
def portal_docs(slug: str, x_portal: str | None = Header(default=None)):
    e, eid, cfg = _portal(slug)
    with sesion_de(eid) as s:
        a = _acceso(s, eid, x_portal)
        if not a.cliente_id:
            return {"elementos": [], "equipos": []}
        es = s.exec(select(Elemento).where(Elemento.empresa_id == eid, Elemento.cliente_id == a.cliente_id, Elemento.activo == True, Elemento.visible_cliente == True, Elemento.tipo != "clave").order_by(Elemento.tipo, Elemento.nombre)).all()  # noqa: E712
        qs = s.exec(select(Equipo).where(Equipo.empresa_id == eid, Equipo.cliente_id == a.cliente_id, Equipo.activo == True)).all()  # noqa: E712
        return {"elementos": [{"id": x.id, "tipo": x.tipo, "tipo_nombre": NOMBRES_TIPO.get(x.tipo, x.tipo), "nombre": x.nombre, "datos": _json(x.datos, {}), "vence": x.vence, "actualizado": x.actualizado} for x in es],
                "equipos": [{"id": q.id, "codigo": q.codigo, "nombre": q.nombre, "tipo": q.tipo, "ubicacion": q.ubicacion, "garantia_hasta": q.garantia_hasta} for q in qs]}
