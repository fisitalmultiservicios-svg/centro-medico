# -*- coding: utf-8 -*-
"""4.32: declaraciones del catálogo y del punto de venta para el mecanismo de app/sinc_datos.py (contrato §1.5).

Todas son escribe="todos", viaja="dos": ítems, clientes, categorías, listas de precios, recetas, extras de los ítems, cajas (partidas por
caja; crear o quitar cajas solo en la web), impresoras de la empresa, promociones (las dos) y modificadores. Los pedidos y las cuentas los
declara app/pedidos_programa.py. Lo importa app/main.py una sola vez; `permiso` se revisa solo en el programa (en la web manda la lista
cerrada DATOS)."""
from .db import Cliente, Producto
from .sinc_datos import DATOS, Dato, declarar
from . import sinc_completar  # noqa: F401  (registra la acción «reenlazar» de la carga inicial: sinc_datos.accion_de_carga)


def producto_con_historial(s, eid: int, pid: int) -> bool:
    """Adaptador (contrato D-5): main._con_historial(s, pid) no recibe eid; el núcleo llama siempre fn(s, eid, id)."""
    from . import main
    return main._con_historial(s, pid)


def _d(dato: Dato) -> None:
    if dato.tipo not in DATOS:          # una segunda importación (pruebas) no repite la declaración
        declarar(dato)


_d(Dato("categoria", registro="categorias", escribe="todos", viaja="dos", permiso="catalogos"))

_d(Dato("producto", modelo=Producto, escribe="todos", viaja="dos", alta="rango",
        grupos={"precio": ("precio", "moneda"), "impuesto": ("cabys", "codigo_tarifa", "tarifa", "otro_impuesto"),
                "clase": ("tipo", "es_servicio", "inventariable", "es_venta"),
                "minimos": ("existencia_minima", "existencia_maxima"), "codigos": ("codigo",)},
        conjuntos=("codigos_alternos",), locales=("imagen_nombre",),
        baja="historia:sinc_datos_decl.producto_con_historial",
        permiso="catalogos", validar="main._validar_producto"))

_d(Dato("cliente", modelo=Cliente, escribe="todos", viaja="dos", alta="rango",
        grupos={"identificacion": ("tipo_id", "numero_id"),
                "ubicacion": ("provincia", "canton", "distrito", "barrio", "direccion")},
        conjuntos=("direcciones",),
        baja="historia:main._cliente_con_historial",
        permiso="catalogos", validar="main._validar_cliente"))

_d(Dato("lista_precios", registro="listas_precios", escribe="todos", viaja="dos", permiso="catalogos"))
_d(Dato("receta", registro="recetas", escribe="todos", viaja="dos", permiso="catalogos",
        refs={"producto_id": "producto", "ingredientes[].producto_id": "producto"}))
_d(Dato("item_extra", registro="items_extra", forma="llave", escribe="todos", viaja="dos", permiso="catalogos",
        refs={"": "producto"}))                         # la llave misma es el id del ítem
_d(Dato("caja", registro="pos_config", partir={"terminales": "id"}, escribe="todos", viaja="dos",
        permiso="configurar", altas_bajas="web"))       # los ids de las cajas los pone el navegador: crear o quitar cajas solo en la web
_d(Dato("impresora", registro="pos_impresoras", escribe="todos", viaja="dos", permiso="configurar"))
_d(Dato("promo_pos", registro="pos_promos", escribe="todos", viaja="dos", permiso="configurar"))
_d(Dato("promo", registro="fis_promociones", escribe="todos", viaja="dos", permiso="configurar"))
_d(Dato("modificador", registro="pos_modificadores", escribe="todos", viaja="dos", permiso="configurar"))
