"""Pago con tarjeta en el carrito en línea con Tilopay (3.50, fase 4 de la fusión con FISITAAP).

Cada negocio usa SU PROPIA cuenta de Tilopay: el dinero entra al negocio, no a IT Core Sync. Las llaves (key, usuario y clave del
API) se guardan cifradas con la clave propia de la empresa en NegocioPublico (pedidos.py) y solo se usan en el servidor. La llave
del servidor (suscripcion.py) sigue siendo únicamente para cobrar los planes.

Flujo
1. El cliente elige «Pagar con tarjeta» en el carrito. El pedido se guarda en estado «pendiente_pago» con un número de orden propio
   (GF<empresa>-<pedido>-<azar>) y se pide a Tilopay la página de pago (processPayment). El cliente paga allí; nosotros nunca vemos
   la tarjeta.
2. Tilopay devuelve al cliente a /api/publico/<slug>/pago/retorno?order=… El resultado que trae la dirección NO se cree: el servidor
   consulta la orden a Tilopay (consult) y solo con «código 1 y monto igual» marca el pedido como pagado, lo confirma y lo manda a la
   caja con el pago ya aplicado. La caja emite el tiquete electrónico al procesarlo (así la venta queda dentro del cierre de caja).
3. Si el cliente cierra el navegador antes de volver, la cola revisa los pedidos pendientes contra Tilopay cada pasada; los que no
   se pagan en 45 minutos se cancelan solos y liberan cupón, puntos y tarjeta de regalo.
4. Si el negocio cancela un pedido ya pagado, se pide el reembolso a Tilopay (processModification tipo 2). Si Tilopay no lo acepta
   en ese momento, el pedido queda «reembolso pendiente» para que el negocio lo resuelva desde su panel de Tilopay.

El algoritmo del OrderHash de Tilopay no es público, por eso la verificación siempre es por consulta al API."""
import base64
import logging
import os
import time
from typing import Optional

import httpx
from fastapi import HTTPException

from . import secretos

log = logging.getLogger(__name__)

API_TILOPAY = "https://app.tilopay.com/api/v1/"
# 4.32: FE_TILOPAY_API solo la usa el arnés de pruebas (un Tilopay simulado en 127.0.0.1). No toca suscripcion.API (el cobro del plan).
# Revisión 4.32 (n.º 36): se obedece solo con FE_ENTORNO=qa y un servidor de esta misma máquina; en cualquier otro caso, el Tilopay real.
def api_desde_entorno() -> str:
    v = (os.environ.get("FE_TILOPAY_API") or "").strip()
    if not v:
        return API_TILOPAY
    from urllib.parse import urlsplit
    try:
        host = (urlsplit(v).hostname or "").lower()
    except ValueError:
        host = ""
    if os.environ.get("FE_ENTORNO") != "qa" or host not in ("127.0.0.1", "localhost", "::1"):
        log.warning("FE_TILOPAY_API se ignora: solo vale con FE_ENTORNO=qa y un servidor local; se usa el Tilopay real")
        return API_TILOPAY
    return v if v.endswith("/") else v + "/"


API = api_desde_entorno()
PLATAFORMA = "grupofactura"
MINUTOS_PENDIENTE = 45                   # un pedido sin pagar se cancela solo después de este tiempo

_tokens: dict = {}                       # key → {"valor", "vence"}


def credenciales(e, n) -> Optional[dict]:
    """Llaves de Tilopay del negocio, descifradas. None si el pago con tarjeta no está activo o faltan datos."""
    if not getattr(n, "pago_tarjeta", False):
        return None
    k, u, p = (secretos.descifrar(e.clave_cifrada, getattr(n, x, None)) or "" for x in ("tilopay_key", "tilopay_user", "tilopay_password"))
    return {"key": k.strip(), "user": u.strip(), "password": p.strip()} if k.strip() and u.strip() and p.strip() else None


def _login(cred: dict) -> str:
    t = _tokens.get(cred["key"])
    if t and time.time() < t["vence"]:
        return t["valor"]
    try:
        r = httpx.post(API + "login", json={"apiuser": cred["user"], "password": cred["password"]}, timeout=30)
    except httpx.HTTPError as ex:
        raise HTTPException(504, f"Tilopay no respondió ({type(ex).__name__}); intente de nuevo en unos minutos")
    if r.status_code != 200:
        raise HTTPException(502, "Tilopay no aceptó el usuario y la clave del API del negocio")
    j = r.json()
    _tokens[cred["key"]] = {"valor": j["access_token"], "vence": time.time() + min(int(j.get("expires_in") or 3600), 86400) - 600}
    return j["access_token"]


def llamar(cred: dict, op: str, cuerpo: dict) -> dict:
    """POST a Tilopay con las llaves del negocio. Devuelve el JSON (o {'type': '<código>', 'message': ...}). Las pruebas lo sustituyen."""
    for intento in (1, 2):
        tok = _login(cred)
        try:
            r = httpx.post(API + op, json={"key": cred["key"], **cuerpo}, headers={"Authorization": "bearer " + tok, "Accept": "application/json"}, timeout=40)
        except httpx.HTTPError as ex:
            raise HTTPException(504, f"Tilopay no respondió ({type(ex).__name__}); intente de nuevo en unos minutos")
        if r.status_code == 401 and intento == 1:
            _tokens.pop(cred["key"], None)
            continue
        try:
            return r.json()
        except ValueError:
            return {"type": str(r.status_code), "message": r.text[:200]}
    return {"type": "401", "message": "Sin autorización"}


def probar(cred: dict) -> dict:
    """Comprueba usuario y clave (login) y que la llave responda (consulta de una orden inexistente no debe dar 401/403)."""
    _tokens.pop(cred["key"], None)
    _login(cred)
    j = llamar(cred, "consult", {"orderNumber": "GF-PRUEBA-CONEXION"})
    if str(j.get("type")) in ("401", "403"):
        raise HTTPException(502, "Tilopay rechazó la llave del negocio: " + str(j.get("message") or j.get("type")))
    return {"ok": True}


def _nombre(nombre: str) -> tuple[str, str]:
    partes = (nombre or "Cliente").split()
    return (partes[0] if partes else "Cliente")[:40], (" ".join(partes[1:]) or "Cliente")[:60]


def iniciar_pago(cred: dict, p, monto: float, redirect: str, correo: str, direccion_negocio: str = "") -> str:
    """Pide a Tilopay la página de pago del pedido y devuelve su dirección."""
    nombre, apellidos = _nombre(p.nombre)
    cuerpo = {"redirect": redirect, "amount": f"{float(monto):.2f}", "currency": "CRC", "orderNumber": p.pago_orden, "capture": "1",
              "billToFirstName": nombre, "billToLastName": apellidos, "billToAddress": (p.direccion or direccion_negocio or "Costa Rica")[:100], "billToAddress2": "",
              "billToCity": "San José", "billToState": "CR-SJ", "billToZipPostCode": "10101", "billToCountry": "CR", "billToTelephone": (p.telefono or "")[:20],
              "billToEmail": correo, "subscription": "0", "platform": PLATAFORMA, "returnData": base64.b64encode(p.token.encode()).decode(), "hashVersion": "V2"}
    j = llamar(cred, "processPayment", cuerpo)
    if str(j.get("type")) != "100" or not j.get("url"):
        raise HTTPException(502, "Tilopay no abrió la página de pago: " + str(j.get("message") or j.get("type") or "sin respuesta"))
    return str(j["url"])


def consultar(cred: dict, orden: str) -> Optional[dict]:
    """Estado de la orden en Tilopay: {'aprobado': bool, 'monto': float, 'referencia', 'auth', 'detalle'} o None si no existe."""
    j = llamar(cred, "consult", {"orderNumber": orden})
    filas = j.get("response") if isinstance(j, dict) else None
    if not isinstance(filas, list) or not filas:
        return None
    pagos = [f for f in filas if isinstance(f, dict) and str(f.get("type") or "Payment").lower() == "payment"] or [f for f in filas if isinstance(f, dict)]
    aprobado = next((f for f in pagos if str(f.get("code")) == "1"), None)
    f = aprobado or pagos[-1]
    try:
        monto = float(str(f.get("amount") or 0).replace(",", ""))
    except ValueError:
        monto = 0.0
    return {"aprobado": aprobado is not None, "monto": monto, "referencia": str(f.get("id_tilopay") or ""), "auth": str(f.get("auth") or ""), "detalle": str(f.get("response") or "")[:120]}


def reembolsar(cred: dict, orden: str, monto: float) -> tuple[bool, str]:
    """Reembolso total de la orden (processModification tipo 2). Devuelve (ok, detalle)."""
    try:
        j = llamar(cred, "processModification", {"orderNumber": orden, "type": "2", "amount": f"{float(monto):.2f}"})
    except HTTPException as ex:
        return False, str(ex.detail)
    ok = str(j.get("type")) == "100" and str(j.get("ReasonCode")) == "1101"
    return ok, str(j.get("ReasonCodeDescription") or j.get("message") or j.get("type") or "")[:160]
