"""Cola de Hacienda: reintenta en segundo plano lo que quedó pendiente cuando Hacienda no respondía.

Qué hace cada pasada (`procesar_empresa` / `procesar_todas`):
 1. Verifica que Hacienda responda para el ambiente de la empresa (pide un token). Si no responde, no insiste: deja
    todo en cola y registra el estado para que la interfaz lo muestre.
 2. Si responde: envía los comprobantes FIRMADOS que nunca llegaron (reglamento 44739-H art. 21: se almacenan y se
    reenvían al restablecerse el enlace) y consulta los ENVIADOS que aún no tienen respuesta (aceptado → correo
    automático al cliente; rechazado → revierte inventario).
 3. Reintentos espaciados por comprobante (1, 2, 4, 8, 16 y luego 30 min) hasta MAX_INTENTOS; los estados 'error'
    (rechazo de la petición por Hacienda) NO se reintentan solos: requieren revisión.
 4. 4.9: un solo emisor por comprobante. Solo se envían y consultan los comprobantes emitidos AQUÍ. Los que llegaron por la
    sincronización (Documento.origen_sinc con el nombre de quien los emitió: en la nube, los que subió una instalación local; en
    una instalación, los que mandó otra computadora del local por la red) los envía y consulta solo quien los emitió, y su estado
    llega con la sincronización (la instalación vuelve a subir XML, respuesta y estado cada vez que el estado cambia).
    Excepción (E3): lo que sigue firmado o enviado y cuyo emisor lleva HORAS_RETOMAR sin contacto (PC dañada o perdida, revocada,
    bloqueada) lo retoma quien tiene la copia (retomables): la nube lo subido por esa instalación y, en la red local (R3), otra
    computadora lo que aquella le mandó. Si no, nadie lo enviaba nunca.

Quién la ejecuta:
 - El hilo de la app (`iniciar_hilo`), cada INTERVALO segundos mientras algún proceso esté vivo.
 - Un cron de cPanel: `tools/cola_hacienda.py` o `POST /api/cola/procesar` con la cabecera X-Cron-Token.
 - La lista de facturas, al abrirse (`POST /api/comprobantes/procesar-pendientes`, solo la empresa activa).
Un archivo de bloqueo evita que dos ejecuciones se pisen.
"""
import json
import logging
import os
import threading
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import or_
from sqlmodel import Session, select

from .config import DATA_DIR
from .db import Documento, Empresa, engine, engine_empresa
from .fe import hacienda

log = logging.getLogger(__name__)
ESTADO_FILE = DATA_DIR / "estado_hacienda.json"       # último chequeo por ambiente (compartido entre procesos y cron)
LOCK_FILE = DATA_DIR / "cola.lock"
MARCA_FILE = DATA_DIR / "cola.ultima"                 # mtime = última pasada completa
ULTIMA_FILE = DATA_DIR / "cola.json"                  # 3.87: última pasada (hora, quién la corrió, duración y totales) para la consola
HISTORIAL_FILE = DATA_DIR / "hacienda_historial.jsonl"   # 3.87: una línea por verificación real de Hacienda (historial de la tarjeta Salud)
HISTORIAL_DIAS = 30
CRON_FILE = DATA_DIR / "cron.ultimo"                  # 3.87: última vez que llamó el cron (o el programa de la cola), aunque otra pasada estuviera en curso
INTERVALO = int(os.environ.get("FE_COLA_INTERVALO", "300"))   # segundos entre pasadas del hilo
MAX_INTENTOS = 60                                     # con backoff de 30 min ≈ 1 día de reintentos continuos
HORAS_RETOMAR = 48                                    # 4.9 (E3): se retoma lo que dejó un emisor que lleva este plazo sin contacto (nube y red local)
_estado: dict[str, dict] = {}
_lock = threading.Lock()
_pasada = threading.Lock()                            # 3.87: una pasada a la vez dentro del proceso (hilo + «Procesar ahora»; en Windows el archivo no bloquea)
_hilo_iniciado = False
_ult_hist: dict[str, float] = {}                     # 3.87: última línea del historial por ambiente (varias empresas en una pasada)


# ----------------------------------------------------------------------------- disponibilidad
def _leer_estado_archivo() -> dict:
    try:
        return json.loads(ESTADO_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def verificar(e: Empresa) -> dict:
    """Comprueba que Hacienda responda para el ambiente de la empresa (token). Guarda el resultado por ambiente."""
    from .main import _cliente_hacienda  # import tardío: main importa este módulo
    from fastapi import HTTPException
    r = {"ambiente": e.ambiente, "verificado": datetime.now(timezone.utc).isoformat(timespec="seconds"),
         "disponible": False, "credenciales": True, "detalle": ""}
    real, t0 = True, None
    try:
        cli = _cliente_hacienda(e)
        try:                                                    # 3.87: con el token todavía vigente no se habla con Hacienda (no cuenta en el historial)
            hit = hacienda._TOKENS.get((cli.cred.ambiente, cli.cred.usuario, cli.cred.password))
            real = not (hit and time.time() < hit[1] - 30)
        except Exception:  # noqa: BLE001
            real = True
        t0 = time.monotonic()
        cli.token()
        r.update(disponible=True, detalle="Hacienda responde")
    except hacienda.CredencialesInvalidas as ex:
        r.update(credenciales=False, detalle=str(ex))
    except HTTPException as ex:
        r.update(credenciales=False, detalle=str(ex.detail))
    except Exception as ex:  # noqa: BLE001  timeout, DNS, 5xx del IdP...
        r.update(detalle=f"Hacienda no responde ({type(ex).__name__}): {str(ex)[:160]}")
    with _lock:
        # disponibilidad general por ambiente; el resultado de credenciales es de CADA empresa (antes el rechazo de una se mostraba a todas) (R104)
        gen = {**r, "credenciales": True, "disponible": r["disponible"] or not r["credenciales"], "detalle": r["detalle"] if r["disponible"] or r["credenciales"] else "Hacienda responde"}
        _estado[e.ambiente] = gen; _estado[f"{e.ambiente}:{e.id}"] = r
        try:
            todo = _leer_estado_archivo(); todo[e.ambiente] = gen; todo[f"{e.ambiente}:{e.id}"] = r
            ESTADO_FILE.write_text(json.dumps(todo, ensure_ascii=False), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
    if t0 is not None and (real or not gen["disponible"]):
        anotar_historial(e.ambiente, bool(gen["disponible"]), int((time.monotonic() - t0) * 1000), r["detalle"])
    return r


def anotar_historial(amb: str, ok: bool, ms: int, detalle: str = "") -> None:
    """3.87: agrega una línea al historial de Hacienda. Si responde, como mucho una por minuto y ambiente; las fallas siempre.
    Se poda a HISTORIAL_DIAS cuando pasa de 2 MB."""
    ahora = time.time()
    with _lock:
        if ok and ahora - _ult_hist.get(amb, 0) < 60:
            return
        _ult_hist[amb] = ahora
        try:
            fila = {"t": datetime.now(timezone.utc).isoformat(timespec="seconds"), "amb": amb, "ok": ok, "ms": ms}
            if not ok:
                fila["det"] = str(detalle or "")[:160]
            with open(HISTORIAL_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(fila, ensure_ascii=False) + "\n")
            if HISTORIAL_FILE.stat().st_size > 2_000_000:
                limite = (datetime.now(timezone.utc) - timedelta(days=HISTORIAL_DIAS)).isoformat(timespec="seconds")
                lineas = [l for l in HISTORIAL_FILE.read_text(encoding="utf-8").splitlines() if l[7:32] >= limite]
                HISTORIAL_FILE.write_text("\n".join(lineas) + "\n", encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass


def leer_historial(amb: str, desde: datetime) -> list[dict]:
    """3.87: líneas del historial de un ambiente desde `desde` (UTC), en orden."""
    out = []
    try:
        for l in HISTORIAL_FILE.read_text(encoding="utf-8").splitlines():
            try:
                d = json.loads(l)
            except ValueError:
                continue
            if d.get("amb") == amb and str(d.get("t", "")) >= desde.isoformat(timespec="seconds"):
                out.append(d)
    except FileNotFoundError:
        pass
    return out


def estado(e: Empresa, s: Session) -> dict:
    """Último estado conocido de Hacienda para el ambiente de la empresa + pendientes de la empresa."""
    archivo = _leer_estado_archivo()                           # siempre el más reciente (otro proceso pudo verificar)
    k = f"{e.ambiente}:{e.id}"
    est = archivo.get(k) or _estado.get(k) or archivo.get(e.ambiente) or _estado.get(e.ambiente) or \
        {"ambiente": e.ambiente, "disponible": None, "verificado": None, "detalle": "Sin verificar todavía", "credenciales": True}
    base = select(Documento.id).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente)
    cond = condicion_cola(s, e.id, e.ambiente)                 # 4.9: la cola de este servidor procesa lo emitido aquí y lo retomado
    propios = base.where(cond)
    return {
        **est,
        "pendientes_envio": len(s.exec(propios.where(Documento.estado == "firmado")).all()),
        "pendientes_consulta": len(s.exec(propios.where(Documento.estado == "enviado")).all()),
        "con_error": len(s.exec(base.where(Documento.estado == "error")).all()),
        # 4.9: firmados o enviados que emitió otra instalación u otra computadora del local: los envía y consulta ella, no esta cola
        "pendientes_otro_emisor": len(s.exec(base.where(~cond, Documento.estado.in_(("firmado", "enviado")))).all()),
    }


# ----------------------------------------------------------------------------- un solo emisor (4.9)
def solo_propios():
    """4.9: condición SQL de los comprobantes emitidos en ESTE servidor (sin origen de sincronización). sinc._guardar_documentos
    marca con origen_sinc lo que recibe: en la nube, lo que sube una instalación local (`/api/sinc/documentos`); en una instalación,
    lo que manda otra computadora del local (`/api/sinc/red/.../cambios`). Eso lo envía a Hacienda y lo consulta solo quien lo
    emitió; aquí se ve, y su estado se actualiza con la sincronización."""
    return or_(Documento.origen_sinc == None, Documento.origen_sinc == "")  # noqa: E711


def de_otro_emisor(d: Documento) -> bool:
    """4.9: ¿el comprobante lo emitió otra instalación u otra computadora del local? Entonces este servidor no lo envía ni lo
    consulta en Hacienda (la misma regla que solo_propios(), para un comprobante ya cargado)."""
    return bool(getattr(d, "origen_sinc", None))


def _terminal_de(d: Documento):
    """La terminal del consecutivo (posiciones 4 a 8 de los 20 dígitos), o None."""
    c = str(d.consecutivo or "")
    return int(c[3:8]) if len(c) == 20 and c[3:8].isdigit() else None


def retomables(s, eid: int, ambiente: str | None = None, ahora: datetime | None = None) -> list[int]:
    """4.9 (E3): ids de los comprobantes de otro emisor que esta cola retoma y envía o consulta ella. En la NUBE, los subidos por una
    instalación local que siguen firmados o enviados, que su instalación no movió en HORAS_RETOMAR (Documento.sinc_en: la nube lo pone
    en cada subida del comprobante, y la instalación lo vuelve a subir cada vez que cambia de estado) y cuya instalación tampoco
    habló con la nube en ese plazo (sinc.instalaciones_vivas: la nube anota el último contacto en cada bajada o subida, cada pocos
    minutos mientras sincroniza) o ya no está vigente (revocada). En una INSTALACIÓN (R3), las copias que otra computadora mandó
    por la red local y que siguen firmadas o enviadas, si esa computadora lleva ese plazo sin contacto en ningún sentido
    (sinc.computadoras_vivas); lo que esta procese se sube solo a la nube, porque cambia de estado. Así nunca hay dos emisores a la
    vez: mientras el emisor da señales, el comprobante es suyo; y un emisor sin contacto deja de reintentar solo a las ~28 h
    (MAX_INTENTOS), antes del plazo. Si aun así Hacienda ya lo tenía, enviar_documento lo toma como duplicado y adopta su estado.
    Antes de la 4.9 la nube y las otras computadoras enviaban todo; con 5b (un solo emisor) lo que dejó una PC dañada, perdida o
    revocada quedaba firmado para siempre."""
    from . import sinc as _sinc
    ahora = ahora or datetime.now(timezone.utc)
    limite = (ahora - timedelta(hours=HORAS_RETOMAR)).isoformat(timespec="seconds")
    sin_mover = [Documento.sinc_en == None, Documento.sinc_en < limite]  # noqa: E711
    if _sinc.MODO_LOCAL:
        # lo que esta computadora ya retomó sigue siendo suyo: al subirlo a la nube se renueva sinc_en y, sin esto, un «enviado» se dejaba de consultar otras 48 h
        sin_mover.append(Documento.ultimo_intento != None)  # noqa: E711
    q = select(Documento).where(Documento.empresa_id == eid, ~solo_propios(), Documento.estado.in_(("firmado", "enviado")), or_(*sin_mover))
    if ambiente:
        q = q.where(Documento.ambiente == ambiente)
    candidatos = [d for d in s.exec(q).all() if d.origen_sinc != _sinc.ORIGEN_NUBE]   # etapa 2a: lo que bajó de la nube lo envía la nube
    if not candidatos:
        return []
    if _sinc.MODO_LOCAL:             # el terminal o el nombre: una computadora sin vincular da señal solo con su nombre (su terminal llega 0)
        terminales, nombres = _sinc.computadoras_vivas(s, eid, limite)
        return [d.id for d in candidatos if _terminal_de(d) not in terminales and str(d.origen_sinc or "")[:40] not in nombres]
    terminales, nombres = _sinc.instalaciones_vivas(s, eid, limite)
    out = []
    for d in candidatos:
        t = _terminal_de(d)
        viva = (t in terminales) if t is not None else (str(d.origen_sinc or "")[:40] in nombres)
        if not viva:
            out.append(d.id)
    return out


def condicion_cola(s, eid: int, ambiente: str | None = None, ahora: datetime | None = None):
    """4.9: condición SQL de lo que procesa la cola de este servidor: lo emitido aquí (solo_propios) y lo retomado (E3)."""
    ids = retomables(s, eid, ambiente, ahora)
    return or_(solo_propios(), Documento.id.in_(ids)) if ids else solo_propios()


# ----------------------------------------------------------------------------- procesamiento
def _backoff_min(intentos: int) -> int:
    return min(30, 2 ** min(max(intentos - 1, 0), 4))      # 1, 2, 4, 8, 16, 30, 30, ...


def _toca(d: Documento, ahora: datetime) -> bool:
    intentos = d.intentos_hacienda or 0
    if intentos >= MAX_INTENTOS:
        return False
    if not intentos or not d.ultimo_intento:
        return True
    try:
        ultimo = datetime.fromisoformat(d.ultimo_intento)
        if ultimo.tzinfo is None:
            ultimo = ultimo.replace(tzinfo=timezone.utc)
    except ValueError:
        return True
    return ahora >= ultimo + timedelta(minutes=_backoff_min(intentos))


def procesar_empresa(eid: int, limite: int = 50, usuario=None, sincrono: bool = True, verificar_primero: bool = True) -> dict:
    """Una pasada sobre la cola de una empresa. Devuelve un resumen con contadores."""
    from fastapi import HTTPException
    from .main import consultar_documento, enviar_documento
    res = {"empresa_id": eid, "enviados": 0, "aceptados": 0, "rechazados": 0, "errores": 0, "en_cola": 0, "detalle": ""}
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    if not e or e.bloqueada:
        res["detalle"] = "empresa inexistente o bloqueada"; return res
    if not (e.usuario_hacienda and e.password_hacienda):
        res["detalle"] = "sin credenciales de Hacienda"; return res
    chk = verificar(e) if verificar_primero else {"disponible": True, "detalle": "sin verificar"}
    res["hacienda"] = {k: chk.get(k) for k in ("disponible", "detalle", "verificado", "credenciales")}
    ahora = datetime.now(timezone.utc)
    with Session(engine_empresa(eid)) as s:
        # 4.9: solo lo emitido aquí; lo que subió una instalación (nube) o mandó otra computadora del local lo envía quien lo emitió,
        # salvo (E3) lo que su emisor dejó de mover y retoma quien tiene la copia
        retomar = retomables(s, eid, e.ambiente, ahora)
        if retomar:
            res["retomados"] = len(retomar)
            log.info("Cola Hacienda, empresa %s: se retoman %s comprobante(s) de emisores sin contacto en %s h", eid, len(retomar), HORAS_RETOMAR)
        cond = or_(solo_propios(), Documento.id.in_(retomar)) if retomar else solo_propios()
        base = select(Documento).where(Documento.empresa_id == eid, Documento.ambiente == e.ambiente, cond)
        firmados = s.exec(base.where(Documento.estado == "firmado").order_by(Documento.id)).all()
        enviados = s.exec(base.where(Documento.estado == "enviado").order_by(Documento.id)).all()
        res["en_cola"] = len(firmados) + len(enviados)
        if not chk.get("disponible"):
            res["detalle"] = chk.get("detalle", "Hacienda no disponible"); return res
        procesados = 0
        for d in firmados + enviados:
            if procesados >= limite:
                break
            if not _toca(d, ahora):
                continue
            procesados += 1
            try:
                if d.estado == "firmado":
                    enviar_documento(s, e, d, usuario, None, sincrono=sincrono)
                    if d.estado == "firmado":          # Hacienda no disponible: sigue en cola, no cuenta como enviado
                        raise HTTPException(502, d.mensaje_hacienda or "Hacienda no disponible")
                    res["enviados"] += 1
                    if d.estado == "enviado":        # consulta inmediata: Hacienda suele responder en segundos
                        time.sleep(2)
                        consultar_documento(s, e, d, usuario, None, sincrono=sincrono)
                else:
                    consultar_documento(s, e, d, usuario, None, sincrono=sincrono)
                if d.estado == "aceptado":
                    res["aceptados"] += 1
                elif d.estado == "rechazado":
                    res["rechazados"] += 1
                d.intentos_hacienda, d.ultimo_intento = 0, ahora.isoformat(timespec="seconds")
                s.add(d); s.commit()
            except HTTPException as ex:
                s.rollback()                       # nada a medias (p. ej. una reversión de inventario parcial)
                if ex.status_code not in (502, 504):   # 4.13: Hacienda sin responder no gasta reintentos: se reenvía cuando regrese, aunque sea fuera de plazo
                    d.intentos_hacienda = (d.intentos_hacienda or 0) + 1
                d.ultimo_intento = ahora.isoformat(timespec="seconds")
                s.add(d); s.commit()
                res["errores"] += 1
                log.warning("Cola Hacienda, empresa %s, %s: HTTP %s %s", eid, d.consecutivo, ex.status_code, ex.detail)
                if ex.status_code in (502, 504):     # Hacienda dejó de responder a mitad de la pasada: no insistir
                    res["detalle"] = f"Hacienda dejó de responder: {ex.detail}"; break
            except Exception as ex:  # noqa: BLE001
                s.rollback()
                d.intentos_hacienda = (d.intentos_hacienda or 0) + 1
                d.ultimo_intento = ahora.isoformat(timespec="seconds")
                s.add(d); s.commit()
                res["errores"] += 1
                log.exception("Cola Hacienda, empresa %s, %s", eid, d.consecutivo)
        res["en_cola"] = len(s.exec(base.where(Documento.estado.in_(("firmado", "enviado")))).all())
        # Mensajes de receptor (aceptación/rechazo de comprobantes de proveedores) que quedaron pendientes: antes nadie los
        # reintentaba y se podía vencer el plazo de 8 días hábiles (R45)
        from . import recepcion
        from .main import _consultar_mensaje_receptor, _enviar_mensaje_receptor
        pend = [] if res.get("detalle") else [r for r in s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == eid,
                                                                     recepcion.Recibido.estado_mensaje.in_(("firmado", "enviado")))).all()
                                                if (r.ambiente or e.ambiente) == e.ambiente]   # solo el ambiente activo; nada si Hacienda cayó
        for r in pend[:limite]:
            try:
                if r.estado_mensaje == "firmado" and r.mensaje_xml_nombre:
                    _enviar_mensaje_receptor(s, e, r)
                elif r.estado_mensaje == "enviado" and r.consecutivo_receptor:
                    _consultar_mensaje_receptor(e, r)
                s.add(r); s.commit()
                res["mensajes_receptor"] = res.get("mensajes_receptor", 0) + 1
            except Exception as ex:  # noqa: BLE001
                s.rollback(); log.warning("Cola mensajes receptor, empresa %s, %s: %s", eid, r.clave, ex)
    return res


def _bloquear():
    """Bloqueo entre procesos (hilo de la app, cron, varios procesos de Passenger). En Windows no bloquea."""
    f = open(LOCK_FILE, "w")
    try:
        import fcntl
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            f.close()
            return None
    except ImportError:
        pass
    return f


def _anotar(ruta, datos: dict) -> None:
    try:
        tmp = ruta.with_name(ruta.name + ".tmp")
        tmp.write_text(json.dumps(datos, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, ruta)
    except OSError:
        pass


def _leer_json(ruta) -> dict | None:
    try:
        d = json.loads(ruta.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def ultima_pasada() -> dict | None:
    """3.87: {hora, origen, por, duracion_ms, empresas, enviados, aceptados, rechazados, errores} de la última pasada completa. Si aún no
    hay cola.json (pasadas de versiones anteriores), solo la hora de la marca."""
    d = _leer_json(ULTIMA_FILE)
    if d:
        return d
    try:
        return {"hora": datetime.fromtimestamp(MARCA_FILE.stat().st_mtime, timezone.utc).isoformat(timespec="seconds"), "origen": None}
    except OSError:
        return None


def ultimo_cron() -> dict | None:
    return _leer_json(CRON_FILE)


def en_curso() -> bool:
    """¿Hay una pasada corriendo? En este proceso, o en otro (el mismo cerrojo de archivo que usan el cron y el hilo)."""
    if _pasada.locked():
        return True
    f = _bloquear()
    if f is None:
        return True
    f.close()
    return False


def procesar_todas(limite_por_empresa: int = 50, origen: str = "script", por: str | None = None) -> dict:
    """3.87: la pasada de siempre, anotando quién la corrió (origen: hilo | cron | script | consola) en data/cola.json y, si fue el cron
    o el programa de la cola, también en data/cron.ultimo. Así la consola sabe si el cron existe."""
    from .config import ahora_cr
    if origen in ("cron", "script"):
        _anotar(CRON_FILE, {"hora": ahora_cr().isoformat(timespec="seconds"), "origen": origen})
    if not _pasada.acquire(blocking=False):
        return {"omitido": "otra pasada de la cola está en curso"}
    t0 = time.time()
    try:
        r = _procesar_todas(limite_por_empresa)
    finally:
        _pasada.release()
    if not r.get("omitido"):
        res = r.get("resultados") or []
        _anotar(ULTIMA_FILE, {"hora": ahora_cr().isoformat(timespec="seconds"), "origen": origen, "por": por, "duracion_ms": round((time.time() - t0) * 1000),
                              "empresas": r.get("empresas", 0), **{k: sum(int(x.get(k) or 0) for x in res) for k in ("enviados", "aceptados", "rechazados", "errores")}})
    return r


def _procesar_todas(limite_por_empresa: int = 50) -> dict:
    """Una pasada sobre todas las empresas activas con credenciales (cron / hilo)."""
    f = _bloquear()
    if f is None:
        return {"omitido": "otra pasada de la cola está en curso"}
    try:
        with Session(engine) as sc:
            ids = [e.id for e in sc.exec(select(Empresa).where(Empresa.bloqueada == False)).all()  # noqa: E712
                   if e.usuario_hacienda and e.password_hacienda]
        try:
            from . import sinc
            ids = [i for i in ids if not sinc.bloqueada(i)]            # instalación local revocada y bloqueada: no envía nada (3.15)
        except Exception:  # noqa: BLE001
            pass
        resultados = []
        for eid in ids:                      # una empresa con error no frena a las demás (R105)
            try:
                resultados.append(procesar_empresa(eid, limite_por_empresa))
            except Exception as ex:  # noqa: BLE001
                log.exception("Cola Hacienda, empresa %s: %s", eid, ex)
                resultados.append({"empresa_id": eid, "errores": 1, "detalle": f"error: {type(ex).__name__}"})
        if os.environ.get("FE_COLA_HILO", "1") != "0":       # 4.18: registro diario del tipo de cambio (con el hilo apagado, pruebas y QA, no sale nada a la red)
            try:
                from . import tipo_cambio as _tc
                _tc.completar()
            except Exception as ex:  # noqa: BLE001
                log.warning("Tipo de cambio: %s", ex)
        try:
            if os.environ.get("FE_MODO_LOCAL", "") != "1":   # etapa 1: recurrentes, buzones, recordatorios, iCal, planes, publicidad y TiKe corren solo en la nube
                from .main import procesar_recurrentes_todas, leer_buzones_todas, recordatorios_cobro_todas, hotel_diario_todas      # recurrentes → pendientes; buzones IMAP → recibidos
                procesar_recurrentes_todas()
                leer_buzones_todas()
                recordatorios_cobro_todas()                                              # recordatorios de cobro por correo (una pasada por día)
                hotel_diario_todas()                                                     # hotel: iCal, recordatorios, no presentados, salidas tardías (2.3)
                from . import planes as _planes
                _planes.recordatorios_vencimiento()                                    # planes: aviso 7 días antes de vencer y al vencer (3.17)
                from . import suscripcion as _susc
                _susc.sincronizar_todas()                                              # cobros de Tilopay que el aviso no haya traído (3.36)
                from . import publicidad as _pub
                _pub.procesar_seguro()                                                 # publicidad: siguiente lote dentro del tope por hora (3.39)
                from . import pedidos as _ped
                _ped.revisar_pagos_todas()                                             # pedidos en línea: pagos con tarjeta sin confirmar y pendientes vencidos (3.50)
                from . import tike as _tike
                _tike.leer_buzones_todas()                                             # TiKe: buzones de soporte → tickets y respuestas (3.52)
                from . import tike_docs as _tiked
                _tiked.avisar_vencimientos_todas()                                     # TiKe: dominios, certificados, licencias, garantías y contratos por vencer (3.54)
        except Exception:  # noqa: BLE001
            log.exception("Recurrentes/buzones: fallo en la pasada")
        try:
            from . import avisos_dueno as _avisos
            _avisos.pasada()                                                         # 3.87: rechazos juntados y comprobantes sin respuesta de Hacienda, al dueño
        except Exception:  # noqa: BLE001
            log.exception("Avisos al dueño: fallo en la pasada")
        try:
            from . import respaldo                               # un respaldo de data/ por día
            respaldo.diario()
        except Exception:  # noqa: BLE001
            log.exception("Respaldo automático: fallo")
        try:
            from . import salud                                  # 3.87: resumen diario por correo a los administradores del sistema
            salud.resumen_diario()
        except Exception:  # noqa: BLE001
            log.exception("Resumen diario: fallo")
        try:
            MARCA_FILE.touch()
        except OSError:
            pass
        return {"empresas": len(ids), "resultados": resultados,
                "hora": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    finally:
        f.close()


# ----------------------------------------------------------------------------- hilo dentro de la app
def _hace_falta_pasada() -> bool:
    try:
        return time.time() - MARCA_FILE.stat().st_mtime >= INTERVALO
    except FileNotFoundError:
        return True


def _bucle():
    time.sleep(90)                       # deja arrancar al proceso antes de la primera pasada
    while True:
        try:
            if _hace_falta_pasada():
                procesar_todas(origen="hilo")
        except Exception:  # noqa: BLE001
            log.exception("Cola Hacienda: fallo en la pasada periódica")
        time.sleep(INTERVALO)


def iniciar_hilo() -> None:
    global _hilo_iniciado
    if _hilo_iniciado or os.environ.get("FE_COLA_HILO", "1") == "0":
        return
    _hilo_iniciado = True
    threading.Thread(target=_bucle, name="cola-hacienda", daemon=True).start()
