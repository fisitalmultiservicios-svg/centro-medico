"""Datos de demostración por tipo de negocio (3.64). `demo.crear_empresa_demo(..., tipo=)` arma la base común (clientes, ítems,
comprobantes, cobros, proveedores, planilla, cotizaciones) con el perfil del tipo y luego `poblar()` agrega lo propio de cada uno:

- comercio: caja configurada, una sesión de caja por día con sus tiquetes como ventas, cuentas de Bancos;
- restaurante: lo del comercio en modo restaurante (mesas, sectores, 10 % de servicio) más la página FISITAAP publicada con el menú
  y pedidos en línea del mes;
- hospitalidad: hotel configurado (categorías, 12 habitaciones, tarifas), huéspedes, reservas del mes (salidas, en casa y
  futuras), cuentas con cargos y pagos, y un cierre del día por cada día pasado;
- servicios: TiKe con tickets del mes, respuestas, contratos de soporte y equipos de los clientes.

Nada de esto llega a Hacienda ni a terceros: son empresas marcadas como demo, en ambiente de pruebas, con nombres ficticios.
"""
import json
import secrets
from datetime import date, datetime, timedelta

from sqlmodel import Session, select

from . import modulos
from .config import TZ_CR, ahora_cr
from .db import engine

CABYS_HOSPEDAJE = "6311100000000"

# ------------------------------------------------------------------------------------------------ perfiles
PERSONAS = [("01", "109990101", "Laura Méndez Solano"), ("01", "109990102", "Carlos Jiménez Vargas"), ("01", "109990103", "Andrea Quesada Mora"),
            ("01", "109990104", "José Pablo Castro Ruiz"), ("01", "109990105", "Marcela Vindas Rojas"), ("01", "109990106", "Esteban Araya Calderón")]
EMPRESAS_CLIENTE = [("02", "3101900101", "Hotel Vista Azul S.A.", "Hotel Vista Azul"), ("02", "3101900102", "Clínica Dental Sonrisas S.R.L.", "Clínica Sonrisas"),
                    ("02", "3101900103", "Constructora Pacífico Norte S.A.", "Pacífico Norte"), ("02", "3101900105", "Colegio Bilingüe Las Palmas S.A.", "Colegio Las Palmas"),
                    ("02", "3101900106", "Agroexportadora del Valle S.A.", "Agro del Valle"), ("02", "3101900108", "Despacho Contable Rojas & Asociados S.A.", "Rojas & Asociados"),
                    ("02", "3101900110", "Ferretería El Tornillo S.A.", "Ferretería El Tornillo"), ("02", "3101900112", "Laboratorio Clínico Vida S.A.", "Laboratorio Vida")]


def _clientes(empresas, personas):
    return [(t, c, n, nc) for t, c, n, nc in empresas] + [(t, c, n, None) for t, c, n in personas]


PERFILES = {
    "facturacion": {
        "nombre": "Consultores Río Azul Demo S.A.", "comercial": "Consultores Río Azul", "cedula": "3101999998", "actividad": "6920.0",
        "actividad_nombre": "Actividades de contabilidad, teneduría de libros y auditoría; consultoría fiscal",
        "clientes": _clientes(EMPRESAS_CLIENTE, PERSONAS[:4]), "tiquete_pct": 0.1, "ventas_dia": (1, 3),
        "proveedores": [("3101900204", "Inmobiliaria Torre Central S.A. (alquiler)"), ("3101900205", "Compañía de Telecomunicaciones del Este S.A."),
                        ("3101900206", "Papelería y Suministros La Oficina S.A."), ("3101900207", "Servicios Profesionales Asociados S.A.")],
        "items": [("Consultoría contable (hora)", "8313100009900", 28000, 0, True, "h"), ("Declaración de IVA mensual", "8313100009900", 45000, 0, True, "Sp"),
                  ("Declaración de renta anual", "8313100009900", 185000, 0, True, "Sp"), ("Planilla mensual (hasta 10 empleados)", "8313100009900", 60000, 0, True, "Sp"),
                  ("Asesoría tributaria (hora)", "8313100009900", 35000, 0, True, "h"), ("Constitución de sociedad", "8211100000000", 250000, 0, True, "Sp"),
                  ("Certificación de ingresos", "8313100009900", 25000, 0, True, "Sp"), ("Inscripción ante Hacienda", "8313100009900", 40000, 0, True, "Sp")],
        "empleados": [("María José", "Araya Solís", "Contadora senior", "TES", 1250000), ("Sofía", "Chaves Mora", "Asistente contable", "TOC", 560000),
                      ("Luis Diego", "Mora Castro", "Ejecutivo de cuentas", "TOSC", 620000), ("Esteban", "Salas Jiménez", "Mensajero", "TONC", 410000)],
    },
    "comercio": {
        "nombre": "Minisúper La Esquina Demo S.A.", "comercial": "Minisúper La Esquina", "cedula": "3101999997", "actividad": "4711.0",
        "actividad_nombre": "Venta al por menor en comercios no especializados con predominio de alimentos, bebidas o tabaco",
        "clientes": _clientes(EMPRESAS_CLIENTE[:3], PERSONAS), "tiquete_pct": 0.9, "ventas_dia": (8, 16),
        "proveedores": [("3101900301", "Distribuidora de Abarrotes del Centro S.A."), ("3101900302", "Lácteos y Embutidos Monteverde S.A."),
                        ("3101900303", "Panificadora La Espiga S.A."), ("3101900304", "Bebidas y Refrescos Tropicales S.A."), ("3101900305", "Limpieza Total S.R.L.")],
        "items": [("Arroz 1 kg", "0111100000100", 1350, 980, False, "Unid"), ("Frijoles negros 900 g", "0117100000100", 1250, 900, False, "Unid"),
                  ("Leche entera 1 L", "2211100000100", 1150, 880, False, "Unid"), ("Pan cuadrado grande", "2341100000100", 1800, 1250, False, "Unid"),
                  ("Gaseosa 2.5 L", "2441100000100", 1650, 1150, False, "Unid"), ("Jabón de baño", "3532100000100", 850, 520, False, "Unid"),
                  ("Papel higiénico 4 rollos", "3219300000100", 2200, 1500, False, "Unid"), ("Detergente en polvo 1 kg", "3532200000100", 2900, 2050, False, "Unid"),
                  ("Café molido 500 g", "2391100000100", 3800, 2700, False, "Unid"), ("Galletas surtidas", "2349100000100", 950, 600, False, "Unid"),
                  ("Atún en lata", "2122100000100", 1400, 950, False, "Unid"), ("Huevos (docena)", "0231100000100", 2100, 1600, False, "Unid"),
                  ("Aceite vegetal 900 ml", "2163100000100", 2350, 1700, False, "Unid"), ("Azúcar 2 kg", "2351100000100", 2050, 1500, False, "Unid")],
        "empleados": [("Daniel", "Herrera Vargas", "Encargado de tienda", "TOC", 640000), ("Valeria", "Rodríguez Pérez", "Cajera", "TONC", 450000),
                      ("Kevin", "Zúñiga Mora", "Cajero", "TONC", 450000), ("Ana", "Solano Arce", "Bodeguera", "TONC", 430000)],
    },
    "restaurante": {
        "nombre": "Soda y Restaurante El Fogón Demo S.A.", "comercial": "Restaurante El Fogón", "cedula": "3101999996", "actividad": "5610.0",
        "actividad_nombre": "Actividades de restaurantes y de servicio móvil de comidas",
        "clientes": _clientes(EMPRESAS_CLIENTE[:4], PERSONAS), "tiquete_pct": 0.92, "ventas_dia": (10, 22),
        "proveedores": [("3101900301", "Distribuidora de Abarrotes del Centro S.A."), ("3101900302", "Lácteos y Embutidos Monteverde S.A."),
                        ("3101900306", "Carnes Selectas del Norte S.A."), ("3101900307", "Verduras Frescas de Cartago S.R.L."), ("3101900304", "Bebidas y Refrescos Tropicales S.A.")],
        "items": [("Casado con pollo", "8399000009900", 4500, 1900, False, "Unid"), ("Casado con carne", "8399000009900", 4800, 2100, False, "Unid"),
                  ("Gallo pinto con huevo", "8399000009900", 2800, 1100, False, "Unid"), ("Arroz con pollo", "8399000009900", 3900, 1600, False, "Unid"),
                  ("Olla de carne", "8399000009900", 5200, 2400, False, "Unid"), ("Chifrijo", "8399000009900", 4200, 1700, False, "Unid"),
                  ("Ceviche de pescado", "8399000009900", 4600, 2000, False, "Unid"), ("Hamburguesa de la casa", "8399000009900", 4900, 2000, False, "Unid"),
                  ("Batido natural", "8399000009900", 1800, 600, False, "Unid"), ("Café chorreado", "8399000009900", 1000, 250, False, "Unid"),
                  ("Refresco natural", "8399000009900", 1200, 350, False, "Unid"), ("Tres leches", "8399000009900", 2200, 800, False, "Unid"),
                  ("Cerveza nacional", "2431100000100", 1800, 1000, False, "Unid"), ("Agua embotellada", "2441100000200", 900, 350, False, "Unid")],
        "empleados": [("Daniel", "Herrera Vargas", "Jefe de cocina", "TOC", 720000), ("Valeria", "Rodríguez Pérez", "Salonera", "TONC", 450000),
                      ("Kevin", "Zúñiga Mora", "Salonero", "TONC", 450000), ("Ana", "Solano Arce", "Cajera", "TONC", 470000), ("Marvin", "Campos Rojas", "Ayudante de cocina", "TONC", 420000)],
    },
    "hospitalidad": {
        "nombre": "Hotel Vista al Volcán Demo S.A.", "comercial": "Hotel Vista al Volcán", "cedula": "3101999995", "actividad": "5510.0",
        "actividad_nombre": "Actividades de alojamiento para estancias cortas",
        "clientes": _clientes(EMPRESAS_CLIENTE[:5], PERSONAS), "tiquete_pct": 0.3, "ventas_dia": (1, 3),
        "proveedores": [("3101900301", "Distribuidora de Abarrotes del Centro S.A."), ("3101900305", "Limpieza Total S.R.L."),
                        ("3101900308", "Lavandería Industrial Volcán S.A."), ("3101900205", "Compañía de Telecomunicaciones del Este S.A."), ("3101900309", "Tours y Traslados Arenal S.R.L.")],
        "items": [("Desayuno típico", "8399000009900", 6500, 2200, False, "Unid"), ("Cena a la carta", "8399000009900", 13000, 4800, False, "Unid"),
                  ("Tour al volcán (por persona)", "9631100000100", 28000, 10000, True, "Sp"), ("Traslado al aeropuerto", "6412100000100", 45000, 20000, True, "Sp"),
                  ("Lavandería (bolsa)", "9712100000100", 5000, 1500, True, "Sp"), ("Masaje relajante 60 min", "9729100000100", 32000, 10000, True, "Sp"),
                  ("Parqueo por noche", "6711100000100", 2500, 0, True, "Sp"), ("Cerveza nacional", "2431100000100", 1800, 800, False, "Unid"),
                  ("Agua embotellada", "2441100000200", 1000, 300, False, "Unid"), ("Alquiler de bicicleta (día)", "7321100000100", 8000, 0, True, "Sp")],
        "empleados": [("María José", "Araya Solís", "Gerente", "TES", 1300000), ("Daniel", "Herrera Vargas", "Recepcionista", "TOC", 560000),
                      ("Valeria", "Rodríguez Pérez", "Recepcionista", "TOC", 560000), ("Ana", "Solano Arce", "Camarera", "TONC", 430000),
                      ("Marvin", "Campos Rojas", "Mantenimiento", "TONC", 480000), ("Kevin", "Zúñiga Mora", "Cocinero", "TONC", 520000)],
    },
    "servicios": {
        "nombre": "Redes y Soporte Demo S.R.L.", "comercial": "Redes y Soporte", "cedula": "3102999994", "actividad": "6202.0",
        "actividad_nombre": "Actividades de consultoría de informática y de gestión de instalaciones informáticas",
        "clientes": _clientes(EMPRESAS_CLIENTE, PERSONAS[:2]), "tiquete_pct": 0.05, "ventas_dia": (1, 3),
        "proveedores": [("3101900201", "Mayorista de Cómputo Centroamericana S.A."), ("3101900202", "Distribuidora Eléctrica Nacional S.A."),
                        ("3101900205", "Compañía de Telecomunicaciones del Este S.A."), ("3101900206", "Papelería y Suministros La Oficina S.A.")],
        "items": [("Soporte técnico (hora)", "8313100009900", 28000, 0, True, "h"), ("Soporte técnico mensual (contrato)", "8313100009900", 95000, 0, True, "Sp"),
                  ("Mantenimiento preventivo de equipo", "8715300000200", 35000, 0, True, "Sp"), ("Configuración de red y wifi", "8715300000200", 65000, 0, True, "Sp"),
                  ("Disco de estado sólido 1 TB", "4527100000000", 58000, 39000, False, "Unid"), ("Memoria RAM 16 GB", "4527100000000", 42000, 29000, False, "Unid"),
                  ("Punto de acceso wifi", "4722100000100", 85000, 61000, False, "Unid"), ("Licencia anual de antivirus", "7331100000000", 24500, 14000, True, "Sp"),
                  ("Instalación de cámara de seguridad", "8715300000200", 45000, 0, True, "Sp"), ("Visita técnica", "8313100009900", 20000, 0, True, "Sp")],
        "empleados": [("María José", "Araya Solís", "Gerente", "TES", 1200000), ("Daniel", "Herrera Vargas", "Técnico en soporte", "TOC", 640000),
                      ("Valeria", "Rodríguez Pérez", "Técnica de redes", "TOC", 690000), ("Sofía", "Chaves Mora", "Asistente administrativa", "TOC", 520000)],
    },
}


# ------------------------------------------------------------------------------------------------ utilidades
def _poner(s: Session, eid: int, clave: str, datos) -> None:
    """Escribe un registro exista o no (reemplazar sin versión sobre una lista existente pide recargar la página)."""
    r = modulos._registro(s, eid, clave)
    modulos.reemplazar(s, eid, clave, datos, version=(r.version or 0) if r is not None else 0)


def _iso(d: date, h: int = 10, m: int = 0) -> str:
    return datetime(d.year, d.month, d.day, h, m, tzinfo=TZ_CR).isoformat(timespec="seconds")


def _r2(x) -> float:
    return round(float(x) + 1e-9, 2)


def _bancos(hoy: date) -> list[dict]:
    f = (hoy - timedelta(days=120)).isoformat()
    return [{"id": 1, "nombre": "Banco Nacional · Cuenta corriente", "tipo": "Banco", "moneda": "CRC", "numero": "100-01-000-215487-3", "saldo_inicial": 3200000, "fecha_saldo": f, "saldo": 3200000, "descripcion": "Cuenta corriente principal en colones"},
            {"id": 2, "nombre": "BAC Credomatic USD", "tipo": "Banco", "moneda": "USD", "numero": "951 234 567", "saldo_inicial": 8500, "fecha_saldo": f, "saldo": 8500, "descripcion": "Cuenta en dólares"},
            {"id": 3, "nombre": "Caja general", "tipo": "Efectivo", "moneda": "CRC", "numero": "", "saldo_inicial": 250000, "fecha_saldo": f, "saldo": 250000, "descripcion": "Efectivo en el negocio"}]


def _slug(e) -> str:
    import re
    base = re.sub(r"[^a-z0-9]+", "-", (e.nombre_comercial or e.nombre).lower().replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ñ", "n")).strip("-")[:40]
    return f"{base}-{e.id}"


TERMINAL = {"id": 1, "nombre": "Caja 1", "modo": "mostrador", "tipo_documento": "04", "bodega_id": None,
            "cuentas": {"01": "Caja general", "02": "Banco Nacional · Cuenta corriente", "06": "Banco Nacional · Cuenta corriente", "04": "Banco Nacional · Cuenta corriente", "03": "", "99": "", "USD": ""},
            "imprimir_auto": True, "formato": "tiquete", "ancho_ticket": 80, "servicio_pct": 0, "servicio_detalle": "Impuesto de servicio 10 %",
            "precio_editable": True, "descuento_max_pct": 100, "mostrar_imagenes": True, "mostrar_existencias": True, "pedir_apertura": True, "enviar_hacienda": True,
            "cliente_defecto_id": None, "columnas": 4, "vendedor": "", "fiado": True, "categorias": [], "mesas": [], "sectores": [], "plano_aspecto": "5/3",
            "destinos": {}, "modificadores": [], "saloneros": [], "clave_supervisor": "", "clave_descuento": False, "clave_anular": False, "propina": True,
            "imprimir_comanda": True, "impresora_comprobante_id": "", "abrir_gaveta": False, "pie_tiquete": "¡Gracias por su compra!"}


# ------------------------------------------------------------------------------------------------ punto de venta
def _pos(s: Session, e, info: dict, rnd, hoy: date, modo: str) -> None:
    term = {**TERMINAL, "modo": modo}
    if modo == "restaurante":
        term["servicio_pct"] = 10
        term["sectores"] = [{"id": 1, "nombre": "Salón", "servicio_pct": None}, {"id": 2, "nombre": "Terraza", "servicio_pct": None}]
        term["mesas"] = [{"id": i + 1, "nombre": f"Mesa {i + 1}", "x": 5 + (i % 4) * 24, "y": 8 + (i // 4) * 40, "w": 14, "h": 22, "forma": "cuadrada" if i % 3 else "redonda",
                          "asientos": 4 if i % 3 else 6, "sector_id": 1 if i < 4 else 2, "rot": 0} for i in range(8)]
        term["saloneros"] = ["Valeria Rodríguez", "Kevin Zúñiga"]
    _poner(s, e.id, "pos_config", {"terminales": [term]})
    por_dia: dict[str, list] = {}
    for doc in info["facturas"]:
        if doc["tipo"] == "04":
            por_dia.setdefault(doc["fecha"][:10], []).append(doc)
    cajas, ventas = [], []
    for i, (dia, docs) in enumerate(sorted(por_dia.items()), start=1):
        d = date.fromisoformat(dia)
        cerrada = d < hoy
        caja = {"id": i, "caja": "Caja 1", "terminal_id": 1, "usuario": "cajera@ejemplo.test", "abierta_en": _iso(d, 7, 55), "fecha": dia, "cerrada_en": _iso(d, 18, 10) if cerrada else None,
                "monto_inicial": 50000, "ventas": [], "retiros": [], "conteo": None, "diferencia": None, "estado": "Cerrada" if cerrada else "Abierta", "notas": ""}
        efectivo = 0.0
        for doc in docs:
            medio = rnd.choice(["01", "01", "01", "02", "06", "04"])
            propina = _r2(doc["total"] * 0.1) if modo == "restaurante" and rnd.random() < 0.4 else 0
            ventas.append({"id": len(ventas) + 1, "caja_id": i, "doc_id": doc["id"], "consecutivo": doc["consecutivo"], "tipo": "04", "total": doc["total"],
                           "medios": [{"medio": medio, "monto": doc["total"]}], "propina": propina, "propina_medio": "01",
                           "salonero": rnd.choice(term["saloneros"]) if term["saloneros"] else None, "servicio": _r2(doc["total"] * 0.1 / 1.23) if modo == "restaurante" else 0,
                           "cliente": doc["receptor"] or "Consumidor final", "hora": doc["fecha"]})
            if medio == "01":
                efectivo += doc["total"] + propina
        if cerrada:
            dif = rnd.choice([0, 0, 0, 0, -500, 1000])
            caja["conteo"] = _r2(50000 + efectivo + dif); caja["diferencia"] = dif
        cajas.append(caja)
    _poner(s, e.id, "pos_cajas", cajas)
    _poner(s, e.id, "pos_ventas", ventas)


# ------------------------------------------------------------------------------------------------ FISITAAP
NOMBRES_WEB = ["Carla Jiménez", "Roberto Salas", "Daniela Mora", "Fabián Arce", "Lucía Vargas", "Mario Pérez", "Natalia Chaves", "Andrés Rojas"]


def _fisitaap(s: Session, e, info: dict, rnd, hoy: date) -> None:
    from .pedidos import ESTADOS, NegocioPublico, Pedido, SlugPublico
    slug = _slug(e)
    productos = info["productos"]
    for i, p in enumerate(productos):
        p.visible_catalogo = True
        p.descripcion_publica = "Preparado al momento con ingredientes frescos." if i % 2 else "Receta de la casa."
        p.destacado = i < 3
        s.add(p)
    s.add(NegocioPublico(empresa_id=e.id, slug=slug, activo=True, nombre=e.nombre_comercial or e.nombre, bienvenida="Pida en línea y recoja en el local o reciba en su casa",
                         descripcion="Comida casera costarricense, casados, chifrijo y batidos naturales. Datos de ejemplo.", whatsapp="88881234", telefono="22221234",
                         direccion="100 m sur de la iglesia, San José (ejemplo)", horarios=json.dumps([["11:00", "21:00"]] * 6 + [None]), acepta_recoger=True, acepta_domicilio=True,
                         costo_envio=1500, minimo_pedido=3000, tiempo_estimado="30 a 45 min", presentacion="menu", terminal_id=1, nota_cliente="Pago en efectivo o SINPE al recibir."))
    s.commit()
    for k in range(1, 19):
        d = hoy if k <= 3 else (hoy - timedelta(days=1) if k <= 5 else hoy - timedelta(days=rnd.randint(2, 27)))   # siempre hay pedidos de hoy y de ayer
        prods = rnd.sample(productos, rnd.choice([1, 2, 2, 3]))
        lineas = [{"producto_id": p.id, "detalle": p.nombre, "cantidad": rnd.choice([1, 1, 2]), "precio_unitario": p.precio, "tarifa": 13, "codigo_tarifa": "08"} for p in prods]
        subtotal = _r2(sum(x["cantidad"] * x["precio_unitario"] for x in lineas))
        impuestos = _r2(subtotal * 0.13)
        tipo = rnd.choice(["recoger", "domicilio", "domicilio"])
        envio = 1500 if tipo == "domicilio" else 0
        estado = "entregado" if d < hoy else ["nuevo", "confirmado", "en_preparacion"][k % 3]
        assert estado in ESTADOS
        s.add(Pedido(empresa_id=e.id, numero=k, token=secrets.token_urlsafe(12), nombre=rnd.choice(NOMBRES_WEB), telefono=f"8{rnd.randint(1000000, 9999999)}", tipo=tipo,
                     direccion="Barrio Los Ángeles, casa 24 (ejemplo)" if tipo == "domicilio" else "", nota="" if k % 3 else "Sin cebolla, por favor", lineas=json.dumps(lineas, ensure_ascii=False),
                     subtotal=subtotal, impuestos=impuestos, envio=envio, total=_r2(subtotal + impuestos + envio), estado=estado, canal="online", creado=_iso(d, rnd.randint(11, 20), rnd.randint(0, 59))))
    s.commit()
    with Session(engine) as sc:
        if not sc.exec(select(SlugPublico).where(SlugPublico.slug == slug)).first():
            sc.add(SlugPublico(slug=slug, empresa_id=e.id)); sc.commit()


# ------------------------------------------------------------------------------------------------ hotel
HUESPEDES = [("Laura", "Méndez Solano", "Costa Rica", "cedula", "109990101"), ("Michael", "Johnson", "Estados Unidos", "pasaporte", "US4471920"),
             ("Anna", "Schmidt", "Alemania", "pasaporte", "DE8820311"), ("Carlos", "Jiménez Vargas", "Costa Rica", "cedula", "109990102"),
             ("Sophie", "Dubois", "Francia", "pasaporte", "FR5510098"), ("Diego", "Hernández López", "México", "pasaporte", "MX9931002"),
             ("Emma", "Wilson", "Canadá", "pasaporte", "CA2219874"), ("Andrea", "Quesada Mora", "Costa Rica", "cedula", "109990103"),
             ("Lucas", "Rossi", "Italia", "pasaporte", "IT6630041"), ("María", "Fernández Ruiz", "España", "pasaporte", "ES7740123"),
             ("James", "Brown", "Reino Unido", "pasaporte", "GB1189003"), ("Valentina", "Castro Pérez", "Colombia", "pasaporte", "CO3321098"),
             ("José Pablo", "Castro Ruiz", "Costa Rica", "cedula", "109990104"), ("Mia", "Andersen", "Dinamarca", "pasaporte", "DK9010233")]


def _hotel(s: Session, e, info: dict, rnd, hoy: date, inicio: date) -> None:
    comercial = e.nombre_comercial or e.nombre
    cats = [{"id": 1, "nombre": "Estándar", "personas": 2, "camas": "1 cama matrimonial", "descripcion": "Vista al jardín", "orden": 1},
            {"id": 2, "nombre": "Superior vista al volcán", "personas": 3, "camas": "1 matrimonial + 1 individual", "descripcion": "Balcón con vista al volcán", "orden": 2},
            {"id": 3, "nombre": "Suite familiar", "personas": 4, "camas": "2 camas matrimoniales", "descripcion": "Sala y cocineta", "orden": 3}]
    tarifas = {"1": {"base": 65}, "2": {"base": 95}, "3": {"base": 140}}
    numeros = [("101", 1), ("102", 1), ("103", 1), ("104", 1), ("105", 1), ("106", 1), ("201", 2), ("202", 2), ("203", 2), ("204", 2), ("301", 3), ("302", 3)]
    habs = [{"id": i + 1, "numero": n, "categoria_id": c, "piso": n[0], "personas": cats[c - 1]["personas"], "camas": cats[c - 1]["camas"], "sofa_cama": c == 3, "vista": "Volcán" if c >= 2 else "Jardín",
             "estado": "limpia", "notas": "", "activa": True} for i, (n, c) in enumerate(numeros)]
    cfg = {"activo": True, "nombre": comercial, "telefono": "22221234", "hora_entrada": "15:00", "hora_salida": "12:00", "moneda": "USD", "codigo_tarifa": "08", "tarifa_iva": 13,
           "tc_modo": "auto", "tc_manual": 0, "margen_venta": 2, "margen_compra": 2, "precios_incluyen_iva": True, "cabys_hospedaje": CABYS_HOSPEDAJE, "adelanto_pct": 50, "adelanto_plazo_dias": 0,
           "tope_cuenta": 300, "correo_cierre": "", "bloquear_cerrados": False, "finde_dias": [5, 6], "finde_pct": 10, "ocupacion_reglas": [], "larga_reglas": [{"noches": 5, "descuento": 10}],
           "minibar_categoria": "", "cotizacion_vigencia_dias": 7, "prefijo": "R-", "bodega_id": None, "persona_extra": 20,
           "segmentos": ["Ocio", "Corporativo", "Grupo", "Agencia u OTA", "Evento", "Residente"], "cargos_auto": [], "min_noches": 1,
           "politicas": "Cancelación sin costo hasta 48 horas antes de la llegada. El adelanto no se reembolsa en caso de no presentarse.",
           "wifi": "Red: VistaVolcan · Clave: bienvenido2026", "temporadas": [], "tarifas": tarifas, "planes": [{"id": 1, "nombre": "Solo habitación", "pct": 0}, {"id": 2, "nombre": "Con desayuno", "pct": 15}],
           "no_show_auto": True, "no_show_dias": 1, "salida_tardia_auto": True, "recordatorio_adelanto": True, "recordatorio_adelanto_dias": 7, "recordatorio_llegada": True, "recordatorio_llegada_dias": 1,
           "ical_auto": False, "fecha_hotel": False}
    huespedes = []
    for i, (nom, ape, pais, tdoc, doc) in enumerate(HUESPEDES, start=1):
        huespedes.append({"id": i, "nombre": nom, "apellidos": ape, "tipo_doc": tdoc, "documento": doc, "nacionalidad": pais, "nacimiento": f"{rnd.randint(1960, 1998)}-{rnd.randint(1, 12):02d}-{rnd.randint(1, 28):02d}",
                          "telefono": f"8{rnd.randint(1000000, 9999999)}" if pais == "Costa Rica" else "", "correo": f"huesped{i}@example.com", "pais": pais, "ciudad": "", "vip": i in (2, 9),
                          "preferencias": "Piso alto, almohada firme" if i in (2, 9) else "", "notas": "", "no_marketing": False, "cliente_id": None, "creado": _iso(inicio - timedelta(days=30))})
    reservas, folios, rid, fid = [], [], 0, 0
    origenes = ["directa", "directa", "web", "booking", "airbnb", "agencia", "telefono"]
    usuario = "recepcion@ejemplo.test"

    def cargo(res, fecha, hab, tarifa):
        nonlocal fid
        fid += 1
        return {"id": fid, "reserva_id": res["id"], "tipo": "cargo", "origen": "hospedaje", "fecha": fecha.isoformat(), "detalle": f"Hospedaje hab. {hab['numero']} · noche del {fecha.day}/{fecha.month}",
                "cantidad": 1, "precio": round(tarifa / 1.13, 5), "tarifa": 13, "codigo_tarifa": "08", "cabys": CABYS_HOSPEDAJE, "moneda": "USD", "producto_id": None, "creado": _iso(fecha, 15), "usuario": usuario}

    def pago(res, fecha, monto, detalle, medio="02"):
        nonlocal fid
        fid += 1
        return {"id": fid, "reserva_id": res["id"], "tipo": "pago", "fecha": fecha.isoformat(), "detalle": detalle, "medio": medio, "cuenta": "BAC Credomatic USD" if medio != "01" else "Caja general",
                "monto": _r2(monto), "moneda": "USD", "moneda_pago": "USD", "monto_pago": _r2(monto), "tipo_cambio": None, "referencia": "", "en_banco": True, "creado": _iso(fecha, 16), "usuario": usuario}

    for hab in habs:
        d = inicio - timedelta(days=rnd.randint(0, 3))
        while d < hoy + timedelta(days=12):
            noches = rnd.choice([1, 2, 2, 3, 3, 4, 5])
            salida = d + timedelta(days=noches)
            rid += 1
            hu = rnd.choice(huespedes)
            plan = rnd.choice([1, 1, 2])
            base = tarifas[str(hab["categoria_id"])]["base"]
            tarifa = _r2(base * (1.15 if plan == 2 else 1))
            total = _r2(tarifa * noches)
            if salida <= hoy:
                estado = "no_show" if rnd.random() < 0.06 else ("cancelada" if rnd.random() < 0.05 else "salio")
            elif d <= hoy:
                estado = "en_casa"
            else:
                estado = "pendiente" if rnd.random() < 0.3 else "confirmada"
            creado = d - timedelta(days=rnd.randint(1, 25))
            res = {"id": rid, "tipo": "reserva", "numero": f"R-{rid:04d}", "estado": estado, "huesped_id": hu["id"], "huesped_nombre": f"{hu['nombre']} {hu['apellidos']}", "adultos": min(hab["personas"], rnd.choice([1, 2, 2, 3])),
                   "ninos": rnd.choice([0, 0, 0, 1]), "llegada": d.isoformat(), "salida": salida.isoformat(), "categoria_id": hab["categoria_id"], "habitacion_id": hab["id"], "plan_id": plan, "precio_manual": None,
                   "tarifa_noche": tarifa, "noches": noches, "neto": _r2(total / 1.13), "iva": _r2(total - total / 1.13), "total": total, "moneda": "USD", "origen": rnd.choice(origenes),
                   "segmento": rnd.choice(["Ocio", "Ocio", "Corporativo", "Agencia u OTA"]), "agencia_id": None, "referencia": "", "ocasion": rnd.choice(["", "", "", "Aniversario", "Cumpleaños"]),
                   "especiales": rnd.choice(["", "", "Cuna", "Piso alto", "Dieta sin gluten"]), "notas": "", "vehiculo": "", "acompanantes": "", "cliente_id": None, "grupo": "",
                   "adelanto_requerido": _r2(total * 0.5), "creado": _iso(creado, 11), "usuario": usuario, "checkin": None, "checkout": None, "documento_id": None, "consecutivo": None,
                   "historial": [{"fecha": _iso(creado, 11), "usuario": usuario, "texto": "Reserva creada (datos de ejemplo)"}]}
            if estado in ("salio", "en_casa"):
                res["checkin"] = _iso(d, 15, 30)
                for k in range(noches):
                    folios.append(cargo(res, d + timedelta(days=k), hab, tarifa))
                if rnd.random() < 0.5:
                    fid += 1
                    folios.append({"id": fid, "reserva_id": rid, "tipo": "cargo", "origen": "pos", "fecha": (d + timedelta(days=min(1, noches - 1))).isoformat(), "detalle": "Restaurante · cena",
                                   "cantidad": 1, "precio": round(rnd.choice([18, 24, 32]) / 1.13, 5), "tarifa": 13, "codigo_tarifa": "08", "cabys": "8399000009900", "moneda": "USD", "producto_id": None,
                                   "creado": _iso(d + timedelta(days=min(1, noches - 1)), 20), "usuario": usuario})
                folios.append(pago(res, creado, total * 0.5, "Adelanto Tarjeta"))
                if estado == "salio":
                    res["checkout"] = _iso(salida, 11, 10)
                    extras = sum(f["precio"] * f["cantidad"] * 1.13 for f in folios if f["reserva_id"] == rid and f["tipo"] == "cargo" and f["origen"] == "pos")
                    folios.append(pago(res, salida, total * 0.5 + extras, "Pago al salir " + rnd.choice(["Tarjeta", "Efectivo"]), rnd.choice(["02", "01"])))
            elif estado == "confirmada":
                folios.append(pago(res, creado, total * 0.5, "Adelanto Transferencia", "04"))
            elif estado == "no_show":
                res["motivo_cancelacion"] = "Automático: no se presentó"
            elif estado == "cancelada":
                res["motivo_cancelacion"] = "El huésped canceló por correo"
            reservas.append(res)
            d = salida + timedelta(days=rnd.choice([0, 0, 1, 2]))
    hoy_s = hoy.isoformat()
    for hab in habs:
        if any(r["habitacion_id"] == hab["id"] and r["estado"] == "salio" and r["salida"] == hoy_s for r in reservas):
            hab["estado"] = "sucia"
    cierres, n = [], 0
    d = inicio
    while d < hoy:
        n += 1
        ds = d.isoformat()
        ocupadas = sum(1 for r in reservas if r["estado"] in ("salio", "en_casa") and r["llegada"] <= ds < r["salida"])
        cargos_dia = [f for f in folios if f["tipo"] == "cargo" and f["fecha"] == ds]
        pagos_dia = [f for f in folios if f["tipo"] == "pago" and f["fecha"] == ds]
        por_c = {}
        for f in cargos_dia:
            por_c[f["origen"]] = _r2(por_c.get(f["origen"], 0) + f["cantidad"] * f["precio"] * 1.13)
        por_m = {}
        for f in pagos_dia:
            k = {"01": "Efectivo", "02": "Tarjeta", "04": "Transferencia"}.get(f["medio"], "Otro")
            por_m[k] = _r2(por_m.get(k, 0) + f["monto"])
        cargos = _r2(sum(por_c.values())); pagos = _r2(sum(por_m.values())); hosp = por_c.get("hospedaje", 0)
        cierres.append({"id": n, "fecha": ds, "hora": _iso(d + timedelta(days=1), 0, 20), "usuario": usuario,
                        "resumen": {"ocupadas": ocupadas, "total": len(habs), "pct": round(100 * ocupadas / len(habs)), "cargos": cargos, "porC": por_c, "pagos": pagos, "porM": por_m,
                                    "adr": _r2(hosp / ocupadas) if ocupadas else 0, "revpar": _r2(hosp / len(habs)), "llegadas": sum(1 for r in reservas if r["llegada"] == ds and r["estado"] in ("salio", "en_casa")),
                                    "salidas": sum(1 for r in reservas if r["salida"] == ds and r["estado"] == "salio"), "en_casa": ocupadas,
                                    "no_show": sum(1 for r in reservas if r["llegada"] == ds and r["estado"] == "no_show"), "creadas": sum(1 for r in reservas if r["creado"][:10] == ds)},
                        "pendientes": [], "notas": ""})
        d += timedelta(days=1)
    _poner(s, e.id, "hotel_config", cfg)
    _poner(s, e.id, "hotel_categorias", cats)
    _poner(s, e.id, "hotel_habitaciones", habs)
    _poner(s, e.id, "hotel_huespedes", huespedes)
    _poner(s, e.id, "hotel_reservas", reservas)
    _poner(s, e.id, "hotel_folios", folios)
    _poner(s, e.id, "hotel_cierres", cierres)


# ------------------------------------------------------------------------------------------------ TiKe
ASUNTOS = [("No hay internet en la oficina", "Redes e internet", "alta"), ("La impresora de recepción no imprime", "Impresoras", "media"), ("Correo lleno, no recibe mensajes", "Correo y cuentas", "media"),
           ("Computadora muy lenta al iniciar", "Soporte técnico", "baja"), ("Instalar el sistema de facturación en una laptop nueva", "Software", "media"), ("El servidor no responde", "Redes e internet", "critica"),
           ("Crear usuario para el nuevo empleado", "Correo y cuentas", "baja"), ("Cámara de seguridad sin imagen", "Soporte técnico", "alta"), ("Respaldo semanal falló", "Software", "alta"),
           ("Wifi de la sala de reuniones se cae", "Redes e internet", "media"), ("No puedo abrir un archivo de Excel", "Software", "baja"), ("Teclado dañado", "Soporte técnico", "baja"),
           ("Virus detectado en la computadora de caja", "Software", "critica"), ("Configurar impresora en la laptop de gerencia", "Impresoras", "baja"), ("Error al enviar factura por correo", "Facturación", "media")]
TECNICOS = ["Daniel Herrera", "Valeria Rodríguez"]


def _tike(s: Session, e, info: dict, rnd, hoy: date, inicio: date) -> None:
    from .tike import CATEGORIAS_DEFECTO, ESTADOS, SLA_DEFECTO, Ticket, TicketEntrada, TikeConfig, _codigo
    from .tike_contratos import Contrato, Equipo
    cfg = TikeConfig(empresa_id=e.id, prefijo="TK", categorias=json.dumps(CATEGORIAS_DEFECTO, ensure_ascii=False), sla=json.dumps(SLA_DEFECTO), portal_activo=True, slug=_slug(e),
                     portal_titulo="Soporte · " + (e.nombre_comercial or e.nombre), portal_texto="Cuéntenos qué pasa y le respondemos en el plazo de su contrato.", firma="Equipo de soporte (datos de ejemplo)")
    s.add(cfg); s.commit(); s.refresh(cfg)
    empresas = [c for c in info["clientes"] if c.tipo_id == "02"]
    contratos, equipos = [], []
    for i, cli in enumerate(empresas[:4], start=1):
        tipo = ["horas", "horas", "visitas", "ilimitado"][i - 1]
        ct = Contrato(empresa_id=e.id, cliente_id=cli.id, cliente_nombre=cli.nombre, nombre={"horas": "Soporte mensual 10 horas", "visitas": "Mantenimiento 2 visitas al mes", "ilimitado": "Soporte ilimitado"}[tipo],
                      tipo=tipo, cantidad={"horas": 10, "visitas": 2, "ilimitado": 0}[tipo], periodo="mensual", tarifa_hora=28000, tarifa_visita=35000, cuota=[95000, 95000, 60000, 180000][i - 1],
                      dia_cobro=1, inicio=(inicio - timedelta(days=90)).isoformat(), renovacion_auto=True, notas="Contrato de ejemplo", activo=True)
        s.add(ct); contratos.append(ct)
    s.commit()
    n_eq = 0
    for ct in contratos:
        for nombre, tipo, marca, modelo in [("Servidor principal", "Servidor", "Dell", "PowerEdge T40"), ("Laptop gerencia", "Laptop", "Lenovo", "ThinkPad E14"), ("Impresora recepción", "Impresora", "HP", "LaserJet M428")][: 2 if ct.tipo != "ilimitado" else 3]:
            n_eq += 1
            eq = Equipo(empresa_id=e.id, cliente_id=ct.cliente_id, codigo=f"EQ-{n_eq:04d}", token=secrets.token_urlsafe(10), nombre=nombre, tipo=tipo, marca=marca, modelo=modelo,
                        serie=f"SN{rnd.randint(100000, 999999)}", ubicacion="Oficina principal", fecha_compra=(inicio - timedelta(days=rnd.randint(200, 900))).isoformat(), notas="", activo=True)
            s.add(eq); equipos.append(eq)
    s.commit()
    por_cliente = {}
    for eq in equipos:
        por_cliente.setdefault(eq.cliente_id, []).append(eq)
    contrato_de = {ct.cliente_id: ct for ct in contratos}
    numero = 0
    d = inicio
    while d <= hoy:
        if d.weekday() < 5:
            for _ in range(rnd.choice([0, 1, 1, 2])):
                numero += 1
                asunto, categoria, prioridad = rnd.choice(ASUNTOS)
                cli = rnd.choice(empresas)
                creado = _iso(d, rnd.randint(8, 17), rnd.randint(0, 59))
                edad = (hoy - d).days
                if edad >= 4:
                    estado = rnd.choice(["cerrado", "cerrado", "resuelto"])
                elif edad >= 1:
                    estado = rnd.choice(["en_proceso", "espera_cliente", "resuelto", "asignado"])
                else:
                    estado = rnd.choice(["nuevo", "asignado"])
                assert estado in ESTADOS
                tecnico = rnd.choice(TECNICOS) if estado != "nuevo" else ""
                horas_sla = SLA_DEFECTO[prioridad]
                vence = (datetime.fromisoformat(creado) + timedelta(hours=horas_sla)).isoformat(timespec="seconds")
                minutos = rnd.choice([30, 45, 60, 90, 120]) if estado in ("resuelto", "cerrado", "en_proceso") else 0
                resuelto = _iso(d + timedelta(days=rnd.randint(0, 2)), 16) if estado in ("resuelto", "cerrado") else None
                eqs = por_cliente.get(cli.id) or []
                t = Ticket(empresa_id=e.id, numero=numero, codigo=_codigo(cfg, numero), token=secrets.token_urlsafe(12), cliente_id=cli.id, cliente_nombre=cli.nombre,
                           solicitante=rnd.choice(["Gerencia", "Recepción", "Contabilidad", "Bodega"]), correo=cli.correo or "", telefono="", asunto=asunto,
                           descripcion="Reportado por el cliente. Datos de ejemplo.", categoria=categoria, prioridad=prioridad, estado=estado, tecnico_nombre=tecnico, vence=vence,
                           origen=rnd.choice(["sistema", "portal", "correo"]), minutos=minutos, calificacion=rnd.choice([4, 5, 5]) if estado == "cerrado" else None,
                           equipo_id=rnd.choice(eqs).id if eqs and rnd.random() < 0.6 else None, contrato_id=contrato_de[cli.id].id if cli.id in contrato_de else None,
                           creado=creado, actualizado=resuelto or creado, primera_respuesta=_iso(d, 10) if estado != "nuevo" else None, resuelto_en=resuelto, cerrado_en=resuelto if estado == "cerrado" else None)
                s.add(t); s.flush()
                if estado != "nuevo":
                    s.add(TicketEntrada(empresa_id=e.id, ticket_id=t.id, tipo="respuesta", publico=True, texto="Recibido, lo revisamos hoy mismo.", minutos=0, usuario=tecnico, origen="sistema"))
                if minutos:
                    s.add(TicketEntrada(empresa_id=e.id, ticket_id=t.id, tipo="nota", publico=False, texto="Visita realizada y problema corregido. Se dejan recomendaciones.", minutos=minutos, usuario=tecnico, origen="sistema"))
        d += timedelta(days=1)
    s.commit()


# ------------------------------------------------------------------------------------------------ entrada
def poblar(e, tipo: str, rnd, facturas: list, hoy: date, inicio: date) -> None:
    """facturas: [{id, tipo, fecha, consecutivo, total, receptor}] de los comprobantes que dejó demo._poblar."""
    from .db import Cliente, Producto, engine_empresa
    with Session(engine_empresa(e.id)) as s:
        productos = list(s.exec(select(Producto).where(Producto.empresa_id == e.id, Producto.es_venta == True)).all())  # noqa: E712
        clientes = [c for c in s.exec(select(Cliente).where(Cliente.empresa_id == e.id)).all() if (c.tipo or "Cliente") != "Proveedor"]
        info = {"productos": productos, "clientes": clientes, "facturas": facturas}
        _poner(s, e.id, "bancos", _bancos(hoy))
        if tipo in ("comercio", "restaurante", "hospitalidad"):
            for p in info["productos"]:
                p.visible_catalogo = tipo != "hospitalidad"; s.add(p)
            s.commit()
            _pos(s, e, info, rnd, hoy, "restaurante" if tipo == "restaurante" else "mostrador")
        if tipo == "restaurante":
            _fisitaap(s, e, info, rnd, hoy)
        if tipo == "hospitalidad":
            _hotel(s, e, info, rnd, hoy, inicio)
        if tipo == "servicios":
            _tike(s, e, info, rnd, hoy, inicio)
        s.commit()
