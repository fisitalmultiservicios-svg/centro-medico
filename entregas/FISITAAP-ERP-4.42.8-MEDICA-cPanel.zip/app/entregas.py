"""FISITAAP · Entregas (3.48, fase 2 de la fusión): zonas de entrega sobre el mapa, motorizados con panel propio en el celular,
asignación directa o liberada, PIN del cliente al entregar, incidencias, seguimiento del motorizado y liquidaciones.

- Zonas: círculos sobre el mapa (centro y radio en km) con precio y tiempo estimado. El cliente fija su ubicación en el mapa
  del catálogo; la zona que lo contiene fija el costo de envío (si cae fuera, no se recibe a domicilio).
- Motorizados: no son usuarios del sistema. Entran al panel /motorizado.html con el nombre público del negocio, su teléfono
  y una clave; el token firmado va en el encabezado X-Motorizado. Un mismo motorizado puede estar afiliado a varios negocios
  (una cuenta por negocio).
- Entregas: nacen al confirmar un pedido a domicilio. «Liberada» = cualquier motorizado afiliado puede tomarla; «asignada» =
  la tiene uno en concreto. Estados: pendiente → liberada/asignada → aceptada → recogida → en_camino → entregada (con el PIN
  del cliente) o incidencia. Mientras va en camino manda su posición y el cliente la ve en su enlace de seguimiento.
- Liquidación: lo que se le paga al motorizado por las entregas hechas en un período; se marca liquidado y queda el registro.
El mapa es OpenStreetMap con Leaflet, servido desde el propio sistema: no necesita clave ni cobra por uso."""
import math
import secrets
import uuid
from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field as PField
from sqlmodel import Field, Session, SQLModel, select

from . import modulos, planes
from .auth import Contexto, abrir, firmar, hash_password, limitar_ip, requiere, sesion_empresa, solo_pos, verificar_password
from .config import ahora_cr
from .db import por_empresa, sesion_de

router = APIRouter(tags=["entregas"])
VEHICULOS = {"moto": "Motocicleta", "bici": "Bicicleta", "carro": "Carro", "pie": "A pie"}
ESTADOS = ("pendiente", "liberada", "asignada", "aceptada", "recogida", "en_camino", "entregada", "incidencia", "cancelada")
NOMBRES_ESTADO = {"pendiente": "Pendiente de despachar", "liberada": "Liberada (esperando motorizado)", "asignada": "Asignada", "aceptada": "Aceptada", "recogida": "Recogida",
                  "en_camino": "En camino", "entregada": "Entregada", "incidencia": "Con incidencia", "cancelada": "Cancelada"}
ABIERTAS = ("pendiente", "liberada", "asignada", "aceptada", "recogida", "en_camino", "incidencia")


class ZonaEntrega(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str
    lat: float
    lng: float
    radio_km: float = 2.0
    precio: float = 0                    # costo de envío con IVA que paga el cliente
    pago_motorizado: Optional[float] = None   # lo que se le paga al motorizado por una entrega en esta zona (vacío = su tarifa)
    tiempo: str = ""                     # «30 a 45 min»
    activa: bool = True
    orden: int = 0


class Motorizado(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str
    telefono: str = Field(index=True)    # 8 dígitos; llave para entrar al panel
    clave_hash: str = ""
    vehiculo: str = "moto"
    placa: str = ""
    activo: bool = True
    pago_entrega: float = 0              # tarifa por entrega (si la zona no fija otra)
    notas: str = ""
    intentos: int = 0
    bloqueado_hasta: Optional[str] = None
    lat: Optional[float] = None          # última posición (mientras va en camino)
    lng: Optional[float] = None
    ubicado_en: Optional[str] = None
    creado: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    ultimo_acceso: Optional[str] = None


class Entrega(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    pedido_id: int = Field(index=True)
    pedido_numero: int = 0
    motorizado_id: Optional[int] = Field(default=None, index=True)
    estado: str = "pendiente"
    pin: str = ""                        # 4 dígitos que el cliente le da al motorizado
    nombre_cliente: str = ""
    telefono_cliente: str = ""
    direccion: str = ""
    lat: Optional[float] = None
    lng: Optional[float] = None
    zona_nombre: str = ""
    monto_envio: float = 0
    pago_motorizado: float = 0
    liquidada: bool = False
    liquidacion_id: Optional[int] = None
    incidencia: str = ""
    nota: str = ""
    creada: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    asignada_en: Optional[str] = None
    aceptada_en: Optional[str] = None
    recogida_en: Optional[str] = None
    en_camino_en: Optional[str] = None
    entregada_en: Optional[str] = None
    cancelada_en: Optional[str] = None


class LiquidacionMotorizado(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    motorizado_id: int = Field(index=True)
    desde: str = ""
    hasta: str = ""
    entregas: int = 0
    total: float = 0
    nota: str = ""
    fecha: str = Field(default_factory=lambda: ahora_cr().isoformat(timespec="seconds"))
    usuario: str = ""


por_empresa(ZonaEntrega, Motorizado, Entrega, LiquidacionMotorizado)


# ------------------------------------------------------------------------------------------------- utilidades
def r2(x) -> float:
    return round(float(x or 0) + 1e-9, 2)


def distancia_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Distancia sobre la esfera (Haversine) en kilómetros."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def zona_para(zonas: list, lat: float, lng: float) -> Optional[ZonaEntrega]:
    """La zona activa más pequeña que contiene el punto (si hay varias, gana el radio menor)."""
    dentro = [z for z in zonas if z.activa and distancia_km(z.lat, z.lng, lat, lng) <= float(z.radio_km or 0) + 1e-9]
    return min(dentro, key=lambda z: (float(z.radio_km or 0), float(z.precio or 0))) if dentro else None


def zonas_de(s: Session, eid: int) -> list:
    return s.exec(select(ZonaEntrega).where(ZonaEntrega.empresa_id == eid).order_by(ZonaEntrega.orden, ZonaEntrega.id)).all()


def modulo_activo(e) -> bool:
    return "entregas" in planes.modulos_de(e)


def _tel(v: str) -> str:
    import re
    t = re.sub(r"\D", "", v or "")
    if t.startswith("506") and len(t) == 11:
        t = t[3:]
    if len(t) != 8:
        raise HTTPException(400, "El teléfono debe tener 8 dígitos")
    return t


def _salida_zona(z: ZonaEntrega) -> dict:
    return {"id": z.id, "nombre": z.nombre, "lat": z.lat, "lng": z.lng, "radio_km": z.radio_km, "precio": z.precio, "pago_motorizado": z.pago_motorizado, "tiempo": z.tiempo, "activa": z.activa, "orden": z.orden}


def _salida_moto(m: Motorizado, publico: bool = False) -> dict:
    d = {"id": m.id, "nombre": m.nombre, "vehiculo": m.vehiculo, "vehiculo_nombre": VEHICULOS.get(m.vehiculo, m.vehiculo), "placa": m.placa, "activo": m.activo}
    if not publico:
        d |= {"telefono": m.telefono, "pago_entrega": m.pago_entrega, "notas": m.notas, "con_clave": bool(m.clave_hash), "lat": m.lat, "lng": m.lng, "ubicado_en": m.ubicado_en, "ultimo_acceso": m.ultimo_acceso, "creado": m.creado}
    return d


def _salida_entrega(e: Entrega, motos: Optional[dict] = None) -> dict:
    m = (motos or {}).get(e.motorizado_id)
    return {"id": e.id, "pedido_id": e.pedido_id, "pedido_numero": e.pedido_numero, "motorizado_id": e.motorizado_id, "motorizado": m.nombre if m else None, "vehiculo": VEHICULOS.get(m.vehiculo, m.vehiculo) if m else None,
            "estado": e.estado, "estado_nombre": NOMBRES_ESTADO.get(e.estado, e.estado), "nombre_cliente": e.nombre_cliente, "telefono_cliente": e.telefono_cliente, "direccion": e.direccion, "lat": e.lat, "lng": e.lng,
            "zona_nombre": e.zona_nombre, "monto_envio": e.monto_envio, "pago_motorizado": e.pago_motorizado, "liquidada": e.liquidada, "incidencia": e.incidencia, "nota": e.nota, "creada": e.creada,
            "asignada_en": e.asignada_en, "aceptada_en": e.aceptada_en, "recogida_en": e.recogida_en, "en_camino_en": e.en_camino_en, "entregada_en": e.entregada_en, "cancelada_en": e.cancelada_en, "abierta": e.estado in ABIERTAS}


def crear_entrega(s: Session, eid: int, p, zona_nombre: str = "") -> Entrega:
    """Nace con el pedido confirmado a domicilio (la llama pedidos.cambiar_estado). Si ya existe y está abierta, se reutiliza."""
    previa = s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.pedido_id == p.id)).first()
    if previa and previa.estado != "cancelada":
        return previa
    e = Entrega(empresa_id=eid, pedido_id=p.id, pedido_numero=p.numero, pin=f"{secrets.randbelow(10000):04d}", nombre_cliente=p.nombre, telefono_cliente=p.telefono, direccion=p.direccion,
                lat=getattr(p, "lat", None), lng=getattr(p, "lng", None), zona_nombre=zona_nombre or getattr(p, "zona_nombre", "") or "", monto_envio=r2(p.envio), nota=p.nota or "")
    s.add(e); s.commit(); s.refresh(e)
    return e


def cancelar_entrega_de_pedido(s: Session, eid: int, pedido_id: int):
    for e in s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.pedido_id == pedido_id)).all():
        if e.estado not in ("entregada", "cancelada"):
            e.estado = "cancelada"; e.cancelada_en = ahora_cr().isoformat(timespec="seconds"); s.add(e)
    s.commit()


def entrega_de_pedido(s: Session, eid: int, pedido_id: int) -> Optional[Entrega]:
    return s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.pedido_id == pedido_id).order_by(Entrega.id.desc())).first()


def seguimiento_publico(s: Session, eid: int, pedido_id: int) -> Optional[dict]:
    """Lo que ve el cliente en su enlace: estado de la entrega, motorizado, PIN y la posición del motorizado mientras va en camino."""
    e = entrega_de_pedido(s, eid, pedido_id)
    if not e or e.estado == "cancelada":
        return None
    m = s.get(Motorizado, e.motorizado_id) if e.motorizado_id else None
    d = {"estado": e.estado, "estado_nombre": NOMBRES_ESTADO.get(e.estado, e.estado), "pin": e.pin if e.estado not in ("entregada",) else None, "motorizado": _salida_moto(m, publico=True) if m else None, "zona": e.zona_nombre, "entregada_en": e.entregada_en}
    if m and e.estado == "en_camino" and m.lat is not None and m.lng is not None:
        d["posicion"] = {"lat": m.lat, "lng": m.lng, "en": m.ubicado_en}
    return d


# ------------------------------------------------------------------------------------------------- administración (permiso pos + módulo)
def admin(ctx: Contexto = Depends(requiere("pos"))) -> Contexto:
    planes.exigir_modulo(ctx.empresa, "entregas")
    return ctx


# 3.87: la caja ('pos') ve zonas y motorizados, asigna, cancela y cierra entregas. Las zonas y tarifas de envío, la ubicación del
# negocio y los motorizados (su clave del panel y su pago) los administra quien tiene 'catalogos'; liquidar es un pago a terceros
# ('gastos': Administrador y Avanzado). El Cajero y los roles de solo caja quedan fuera de las dos cosas.
def gestion(ctx: Contexto = Depends(admin)) -> Contexto:
    ctx.exigir("catalogos")
    return ctx


def pagos(ctx: Contexto = Depends(admin)) -> Contexto:
    ctx.exigir("gastos")
    return ctx


class ZonaIn(BaseModel):
    nombre: str = PField(min_length=1, max_length=60)
    lat: float = PField(ge=-90, le=90)
    lng: float = PField(ge=-180, le=180)
    radio_km: float = PField(gt=0, le=200)
    precio: float = PField(0, ge=0, le=1e6)
    pago_motorizado: Optional[float] = PField(None, ge=0, le=1e6)
    tiempo: Optional[str] = PField("", max_length=40)
    activa: bool = True
    orden: int = 0


class UbicacionIn(BaseModel):
    lat: float = PField(ge=-90, le=90)
    lng: float = PField(ge=-180, le=180)


class MotorizadoIn(BaseModel):
    nombre: str = PField(min_length=2, max_length=60)
    telefono: str = PField(min_length=8, max_length=20)
    vehiculo: str = "moto"
    placa: Optional[str] = PField("", max_length=12)
    activo: bool = True
    pago_entrega: float = PField(0, ge=0, le=1e6)
    notas: Optional[str] = PField("", max_length=200)
    clave: Optional[str] = PField(None, min_length=4, max_length=8)


class AsignarIn(BaseModel):
    motorizado_id: Optional[int] = None      # vacío = liberar para cualquier motorizado afiliado


class MotivoIn(BaseModel):
    motivo: str = PField(min_length=3, max_length=200)


class LiquidarIn(BaseModel):
    motorizado_id: int
    hasta: str = PField(min_length=10, max_length=10)
    nota: Optional[str] = PField("", max_length=200)


@router.get("/api/entregas/zonas")
def zonas(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    from .pedidos import _negocio
    n = _negocio(s, ctx.empresa.id)
    return {"ubicacion": {"lat": n.lat, "lng": n.lng}, "zonas": [_salida_zona(z) for z in zonas_de(s, ctx.empresa.id)]}


@router.put("/api/entregas/ubicacion")
def ubicacion(data: UbicacionIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    from .pedidos import _negocio
    n = _negocio(s, ctx.empresa.id); n.lat = data.lat; n.lng = data.lng; s.add(n); s.commit()
    return {"ok": True}


@router.post("/api/entregas/zonas")
def crear_zona(data: ZonaIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    if len(zonas_de(s, ctx.empresa.id)) >= 30:
        raise HTTPException(400, "Máximo 30 zonas")
    z = ZonaEntrega(empresa_id=ctx.empresa.id, **data.model_dump()); s.add(z); s.commit(); s.refresh(z)
    return _salida_zona(z)


@router.put("/api/entregas/zonas/{zid}")
def editar_zona(zid: int, data: ZonaIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    z = s.get(ZonaEntrega, zid)
    if not z or z.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Zona no encontrada")
    for k, v in data.model_dump().items():
        setattr(z, k, v)
    s.add(z); s.commit(); s.refresh(z)
    return _salida_zona(z)


@router.delete("/api/entregas/zonas/{zid}")
def borrar_zona(zid: int, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    z = s.get(ZonaEntrega, zid)
    if z and z.empresa_id == ctx.empresa.id:
        s.delete(z); s.commit()
    return {"ok": True}


@router.get("/api/entregas/motorizados")
def motorizados(ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    out = [_salida_moto(m) for m in s.exec(select(Motorizado).where(Motorizado.empresa_id == ctx.empresa.id).order_by(Motorizado.activo.desc(), Motorizado.nombre)).all()]
    if solo_pos(ctx.permisos):            # 4.5: la caja asigna y llama al motorizado; lo que se le paga por entrega, sus notas y si tiene clave son de quien los administra
        out = [{k: v for k, v in m.items() if k not in ("pago_entrega", "notas", "con_clave")} for m in out]
    return out


def _clave_ok(c: str):
    if not c.isdigit() or not 4 <= len(c) <= 8 or len(set(c)) == 1 or c in ("1234", "12345", "123456", "4321", "0000"):
        raise HTTPException(400, "La clave debe tener de 4 a 8 dígitos y no ser tan fácil de adivinar")


@router.post("/api/entregas/motorizados")
def crear_motorizado(data: MotorizadoIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; tel = _tel(data.telefono)
    if data.vehiculo not in VEHICULOS:
        raise HTTPException(400, "Tipo de vehículo desconocido")
    if s.exec(select(Motorizado).where(Motorizado.empresa_id == eid, Motorizado.telefono == tel)).first():
        raise HTTPException(400, "Ya hay un motorizado con ese teléfono")
    if not data.clave:
        raise HTTPException(400, "Asigne la clave con la que entrará al panel")
    _clave_ok(data.clave)
    m = Motorizado(empresa_id=eid, nombre=" ".join(data.nombre.split())[:60], telefono=tel, clave_hash=hash_password(data.clave), vehiculo=data.vehiculo, placa=(data.placa or "").strip().upper()[:12], activo=data.activo,
                   pago_entrega=r2(data.pago_entrega), notas=(data.notas or "").strip()[:200])
    s.add(m); s.commit(); s.refresh(m)
    return _salida_moto(m)


@router.put("/api/entregas/motorizados/{mid}")
def editar_motorizado(mid: int, data: MotorizadoIn, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    m = s.get(Motorizado, mid)
    if not m or m.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Motorizado no encontrado")
    tel = _tel(data.telefono)
    if data.vehiculo not in VEHICULOS:
        raise HTTPException(400, "Tipo de vehículo desconocido")
    if s.exec(select(Motorizado).where(Motorizado.empresa_id == ctx.empresa.id, Motorizado.telefono == tel, Motorizado.id != mid)).first():
        raise HTTPException(400, "Ya hay otro motorizado con ese teléfono")
    m.nombre = " ".join(data.nombre.split())[:60]; m.telefono = tel; m.vehiculo = data.vehiculo; m.placa = (data.placa or "").strip().upper()[:12]; m.activo = data.activo; m.pago_entrega = r2(data.pago_entrega); m.notas = (data.notas or "").strip()[:200]
    if data.clave:
        _clave_ok(data.clave); m.clave_hash = hash_password(data.clave); m.intentos = 0; m.bloqueado_hasta = None
    s.add(m); s.commit(); s.refresh(m)
    return _salida_moto(m)


@router.delete("/api/entregas/motorizados/{mid}")
def borrar_motorizado(mid: int, ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    m = s.get(Motorizado, mid)
    if not m or m.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Motorizado no encontrado")
    if s.exec(select(Entrega).where(Entrega.empresa_id == ctx.empresa.id, Entrega.motorizado_id == mid)).first():
        m.activo = False; s.add(m); s.commit()
        return {"ok": True, "desactivado": True, "mensaje": "Tiene entregas registradas: se desactivó en vez de borrarse"}
    s.delete(m); s.commit()
    return {"ok": True}


@router.get("/api/entregas")
def listar(estado: Optional[str] = None, desde: Optional[str] = None, hasta: Optional[str] = None, abiertas: bool = False, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    q = select(Entrega).where(Entrega.empresa_id == eid)
    if abiertas:
        q = q.where(Entrega.estado.in_(ABIERTAS))  # type: ignore[attr-defined]
    else:
        if desde:
            q = q.where(Entrega.creada >= desde[:10])
        if hasta:
            q = q.where(Entrega.creada <= hasta[:10] + "T99")
        if not desde and not hasta:
            q = q.where(Entrega.creada >= (ahora_cr() - timedelta(days=3)).date().isoformat())
        if estado:
            q = q.where(Entrega.estado == estado)
    motos = {m.id: m for m in s.exec(select(Motorizado).where(Motorizado.empresa_id == eid)).all()}
    return [_salida_entrega(e, motos) for e in s.exec(q.order_by(Entrega.id.desc())).all()[:500]]


def _entrega_admin(s: Session, eid: int, enid: int) -> Entrega:
    e = s.get(Entrega, enid)
    if not e or e.empresa_id != eid:
        raise HTTPException(404, "Entrega no encontrada")
    return e


def _pago_de(s: Session, eid: int, e: Entrega, m: Motorizado) -> float:
    z = next((z for z in zonas_de(s, eid) if z.nombre == e.zona_nombre), None) if e.zona_nombre else None
    return r2(z.pago_motorizado) if z and z.pago_motorizado is not None else r2(m.pago_entrega)


@router.put("/api/entregas/{enid}/asignar")
def asignar(enid: int, data: AsignarIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """Asigna la entrega a un motorizado (o la libera para que uno afiliado la tome)."""
    eid = ctx.empresa.id; e = _entrega_admin(s, eid, enid)
    if e.estado in ("entregada", "cancelada"):
        raise HTTPException(400, "La entrega ya está cerrada")
    ahora = ahora_cr().isoformat(timespec="seconds")
    if data.motorizado_id:
        m = s.get(Motorizado, data.motorizado_id)
        if not m or m.empresa_id != eid or not m.activo:
            raise HTTPException(400, "Motorizado no disponible")
        e.motorizado_id = m.id; e.estado = "asignada"; e.asignada_en = ahora; e.pago_motorizado = _pago_de(s, eid, e, m)
    else:
        e.motorizado_id = None; e.estado = "liberada"; e.asignada_en = None; e.pago_motorizado = 0
    e.incidencia = ""; s.add(e); s.commit(); s.refresh(e)
    motos = {m.id: m for m in s.exec(select(Motorizado).where(Motorizado.empresa_id == eid)).all()}
    # 3.87: con el PIN, para que Express pendientes lo muestre y la caja lo comparta con el cliente. No va en _salida_entrega: el panel
    # del motorizado la usa y el PIN es lo que él debe pedirle al cliente al entregar.
    return {**_salida_entrega(e, motos), "pin": e.pin}


@router.put("/api/entregas/{enid}/cancelar")
def cancelar(enid: int, data: MotivoIn, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    e = _entrega_admin(s, ctx.empresa.id, enid)
    if e.estado in ("entregada", "cancelada"):
        raise HTTPException(400, "La entrega ya está cerrada")
    e.estado = "cancelada"; e.cancelada_en = ahora_cr().isoformat(timespec="seconds"); e.incidencia = data.motivo.strip(); s.add(e); s.commit()
    return _salida_entrega(e)


@router.put("/api/entregas/{enid}/entregada")
def marcar_entregada(enid: int, ctx: Contexto = Depends(admin), s: Session = Depends(sesion_empresa)):
    """El negocio la cierra a mano (el motorizado no pudo marcarla)."""
    e = _entrega_admin(s, ctx.empresa.id, enid)
    if e.estado in ("entregada", "cancelada"):
        raise HTTPException(400, "La entrega ya está cerrada")
    _cerrar(s, ctx.empresa.id, e)
    return _salida_entrega(e)


def _cerrar(s: Session, eid: int, e: Entrega):
    ahora = ahora_cr().isoformat(timespec="seconds")
    e.estado = "entregada"; e.entregada_en = ahora; e.incidencia = ""; s.add(e); s.commit()
    from .pedidos import Pedido
    p = s.get(Pedido, e.pedido_id)
    if p and p.estado not in ("cancelado", "entregado"):
        p.estado = "entregado"; p.entregado = ahora; p.actualizado = ahora; s.add(p); s.commit()
        from . import pedidos as _ped
        _ped.avisar_cliente_id(eid, p.id, "entregado")                                             # correo «entregado» al cliente (3.50)
        from . import promociones
        promociones.acreditar(s, eid, _ped.telefono_puntos(s, p), r2((p.subtotal or 0) + (p.impuestos or 0) - (getattr(p, "descuento", 0) or 0) - (getattr(p, "descuento_puntos", 0) or 0)), f"pedido:{p.id}", p.nombre)   # 3.87: a la cuenta con que se pidió
        if p.cuenta_espera_id:                               # la cuenta en la caja queda «entregada» (se cobra después, o ya se cobró)
            lista = modulos.leer(s, eid, "pos_espera", []) or []
            c = next((x for x in lista if isinstance(x, dict) and x.get("id") == p.cuenta_espera_id), None)
            if c and c.get("estado") != "entregado":
                # 4.31 (L-9): solo estos dos campos de la cuenta; lo demás lo une el servidor con lo guardado (no pisa un plato de la caja)
                fusion = {"_fusion": {"v": 1, "origen": "servidor", "cuenta": ["estado", "hora_entregado"]}} if modulos.FUSIONES.get("pos_espera") else {}
                modulos.aplicar_cambios(s, eid, "pos_espera", [{**c, "estado": "entregado", "hora_entregado": ahora, **fusion}], [], []); s.commit()


@router.get("/api/entregas/liquidaciones/pendientes")
def liquidacion_pendiente(ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    """Por motorizado: entregas hechas y no liquidadas, con el total a pagar."""
    eid = ctx.empresa.id
    motos = {m.id: m for m in s.exec(select(Motorizado).where(Motorizado.empresa_id == eid)).all()}
    out: dict = {}
    for e in s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.estado == "entregada", Entrega.liquidada == False, Entrega.motorizado_id != None).order_by(Entrega.entregada_en)).all():  # noqa: E711,E712
        o = out.setdefault(e.motorizado_id, {"motorizado_id": e.motorizado_id, "motorizado": motos[e.motorizado_id].nombre if e.motorizado_id in motos else "?", "entregas": 0, "total": 0.0, "desde": e.entregada_en, "hasta": e.entregada_en, "detalle": []})
        o["entregas"] += 1; o["total"] = r2(o["total"] + e.pago_motorizado); o["hasta"] = e.entregada_en; o["detalle"].append(_salida_entrega(e, motos))
    return sorted(out.values(), key=lambda x: x["motorizado"])


@router.post("/api/entregas/liquidaciones")
def liquidar(data: LiquidarIn, ctx: Contexto = Depends(pagos), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id; m = s.get(Motorizado, data.motorizado_id)
    if not m or m.empresa_id != eid:
        raise HTTPException(404, "Motorizado no encontrado")
    pend = s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.motorizado_id == m.id, Entrega.estado == "entregada", Entrega.liquidada == False, Entrega.entregada_en <= data.hasta + "T99")).all()  # noqa: E712
    if not pend:
        raise HTTPException(400, "No hay entregas pendientes de liquidar hasta esa fecha")
    liq = LiquidacionMotorizado(empresa_id=eid, motorizado_id=m.id, desde=min(e.entregada_en for e in pend)[:10], hasta=data.hasta, entregas=len(pend), total=r2(sum(e.pago_motorizado for e in pend)),
                                nota=(data.nota or "").strip(), usuario=ctx.usuario.correo or "")
    s.add(liq); s.commit(); s.refresh(liq)
    for e in pend:
        e.liquidada = True; e.liquidacion_id = liq.id; s.add(e)
    s.commit()
    return {"id": liq.id, "motorizado": m.nombre, "entregas": liq.entregas, "total": liq.total, "desde": liq.desde, "hasta": liq.hasta, "fecha": liq.fecha}


@router.get("/api/entregas/liquidaciones")
def liquidaciones(ctx: Contexto = Depends(gestion), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    motos = {m.id: m.nombre for m in s.exec(select(Motorizado).where(Motorizado.empresa_id == eid)).all()}
    return [{"id": l.id, "motorizado_id": l.motorizado_id, "motorizado": motos.get(l.motorizado_id, "?"), "desde": l.desde, "hasta": l.hasta, "entregas": l.entregas, "total": l.total, "nota": l.nota, "fecha": l.fecha, "usuario": l.usuario}
            for l in s.exec(select(LiquidacionMotorizado).where(LiquidacionMotorizado.empresa_id == eid).order_by(LiquidacionMotorizado.id.desc())).all()[:300]]


# ------------------------------------------------------------------------------------------------- panel del motorizado (sin usuario)
class AccesoMotoIn(BaseModel):
    telefono: str = PField(min_length=8, max_length=20)
    clave: str = PField(min_length=4, max_length=8)


class PinIn(BaseModel):
    pin: str = PField(min_length=4, max_length=4)


class IncidenciaIn(BaseModel):
    texto: str = PField(min_length=3, max_length=200)


class PosicionIn(BaseModel):
    lat: float = PField(ge=-90, le=90)
    lng: float = PField(ge=-180, le=180)


def _empresa_slug(slug: str):
    from .pedidos import _publico
    e, eid = _publico(slug)
    if not modulo_activo(e):
        raise HTTPException(404, "Este negocio no tiene entregas con motorizados")
    return e, eid


def _moto(s: Session, eid: int, x_motorizado: str | None) -> Motorizado:
    d = abrir(x_motorizado or "")
    m = s.get(Motorizado, int(d["mid"])) if d and d.get("tipo") == "motorizado" and int(d.get("eid") or 0) == eid else None
    if not m or m.empresa_id != eid or not m.activo:
        raise HTTPException(401, "Ingrese con su teléfono y clave")
    return m


@router.post("/api/publico/{slug}/motorizado/acceso")
def acceso_motorizado(slug: str, data: AccesoMotoIn, request: Request):
    e, eid = _empresa_slug(slug); tel = _tel(data.telefono)
    limitar_ip(request, clave="motorizado", maximo=15, ventana=600, sujeto=f"moto:{eid}:{tel}", mensaje="Demasiados intentos. Espere unos minutos.")
    with sesion_de(eid) as s:
        m = s.exec(select(Motorizado).where(Motorizado.empresa_id == eid, Motorizado.telefono == tel)).first()
        ahora = ahora_cr().isoformat(timespec="seconds")
        if not m or not m.activo or not m.clave_hash:
            raise HTTPException(401, "Teléfono o clave incorrectos")
        if m.bloqueado_hasta and m.bloqueado_hasta > ahora:
            raise HTTPException(429, "Acceso bloqueado por intentos fallidos. Intente en unos minutos.")
        if not verificar_password(data.clave, m.clave_hash):
            m.intentos += 1
            if m.intentos >= 5:
                m.intentos = 0; m.bloqueado_hasta = (ahora_cr() + timedelta(minutes=10)).isoformat(timespec="seconds")
            s.add(m); s.commit()
            raise HTTPException(401, "Teléfono o clave incorrectos")
        m.intentos = 0; m.bloqueado_hasta = None; m.ultimo_acceso = ahora; s.add(m); s.commit()
        from .pedidos import _negocio, _nombre_negocio
        n = _negocio(s, eid)
        return {"token": firmar({"tipo": "motorizado", "eid": eid, "mid": m.id}, 30 * 24 * 3600), "nombre": m.nombre, "negocio": _nombre_negocio(s, e, n)["nombre"], "negocio_ubicacion": {"lat": n.lat, "lng": n.lng}}


@router.get("/api/publico/{slug}/motorizado/entregas")
def entregas_motorizado(slug: str, x_motorizado: str | None = Header(default=None)):
    """Las liberadas (puede tomarlas), las suyas abiertas y sus últimas 20 cerradas."""
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado)
        from .pedidos import Pedido, estado_efectivo
        abiertas = s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.estado.in_(ABIERTAS)).order_by(Entrega.id)).all()  # type: ignore[attr-defined]
        pedidos = {p.id: p for p in s.exec(select(Pedido).where(Pedido.id.in_([x.pedido_id for x in abiertas] or [0]))).all()}  # type: ignore[attr-defined]
        est = estado_efectivo(s, eid, list(pedidos.values()))
        def fila(x):
            p = pedidos.get(x.pedido_id)
            return {**_salida_entrega(x, {m.id: m}), "pedido_estado": est.get(x.pedido_id), "lista_para_recoger": est.get(x.pedido_id) in ("listo", "entregado"), "lineas": __import__("json").loads(p.lineas) if p else [], "total_pedido": p.total if p else 0, "nota_pedido": p.nota if p else ""}
        mias = [fila(x) for x in abiertas if x.motorizado_id == m.id]
        libres = [fila(x) for x in abiertas if x.estado == "liberada"]
        cerradas = [_salida_entrega(x, {m.id: m}) for x in s.exec(select(Entrega).where(Entrega.empresa_id == eid, Entrega.motorizado_id == m.id, Entrega.estado.in_(("entregada", "cancelada"))).order_by(Entrega.id.desc())).all()[:20]]  # type: ignore[attr-defined]
        pend = [x for x in cerradas if x["estado"] == "entregada" and not x["liquidada"]]
        return {"nombre": m.nombre, "mias": mias, "libres": libres, "cerradas": cerradas, "por_liquidar": {"entregas": len(pend), "total": r2(sum(x["pago_motorizado"] for x in pend))}, "ahora": ahora_cr().isoformat(timespec="seconds")}


def _mi_entrega(s: Session, eid: int, m: Motorizado, enid: int) -> Entrega:
    e = s.get(Entrega, enid)
    if not e or e.empresa_id != eid:
        raise HTTPException(404, "Entrega no encontrada")
    if e.motorizado_id != m.id:
        raise HTTPException(403, "Esta entrega no es suya")
    return e


@router.put("/api/publico/{slug}/motorizado/entregas/{enid}/aceptar")
def aceptar(slug: str, enid: int, x_motorizado: str | None = Header(default=None)):
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado); en = s.get(Entrega, enid)
        if not en or en.empresa_id != eid:
            raise HTTPException(404, "Entrega no encontrada")
        if en.estado == "liberada" or (en.estado == "asignada" and en.motorizado_id == m.id):
            if en.estado == "liberada" and en.motorizado_id not in (None, m.id):
                raise HTTPException(400, "Otro motorizado ya la tomó")
            ahora = ahora_cr().isoformat(timespec="seconds")
            en.motorizado_id = m.id; en.estado = "aceptada"; en.aceptada_en = ahora; en.asignada_en = en.asignada_en or ahora; en.pago_motorizado = _pago_de(s, eid, en, m)
            s.add(en); s.commit(); s.refresh(en)
            return _salida_entrega(en, {m.id: m})
        raise HTTPException(400, "Esta entrega ya no está disponible")


def _paso(slug: str, enid: int, x_motorizado: str | None, de: tuple, a: str, campo: str):
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado); en = _mi_entrega(s, eid, m, enid)
        if en.estado not in de:
            raise HTTPException(400, f"La entrega está «{NOMBRES_ESTADO.get(en.estado, en.estado)}»")
        en.estado = a; setattr(en, campo, ahora_cr().isoformat(timespec="seconds")); en.incidencia = ""; s.add(en); s.commit(); s.refresh(en)
        return _salida_entrega(en, {m.id: m})


@router.put("/api/publico/{slug}/motorizado/entregas/{enid}/recogida")
def recogida(slug: str, enid: int, x_motorizado: str | None = Header(default=None)):
    return _paso(slug, enid, x_motorizado, ("aceptada", "incidencia"), "recogida", "recogida_en")


@router.put("/api/publico/{slug}/motorizado/entregas/{enid}/en-camino")
def en_camino(slug: str, enid: int, x_motorizado: str | None = Header(default=None)):
    r = _paso(slug, enid, x_motorizado, ("recogida", "aceptada", "incidencia"), "en_camino", "en_camino_en")
    if r.get("pedido_id"):
        from . import pedidos as _ped
        _ped.avisar_cliente_id(_empresa_slug(slug)[1], int(r["pedido_id"]), "en_camino")      # correo «en camino» al cliente (3.50)
    return r


@router.put("/api/publico/{slug}/motorizado/entregas/{enid}/entregada")
def entregada(slug: str, enid: int, data: PinIn, request: Request, x_motorizado: str | None = Header(default=None)):
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado); en = _mi_entrega(s, eid, m, enid)
        if en.estado not in ("en_camino", "recogida", "incidencia"):
            raise HTTPException(400, f"La entrega está «{NOMBRES_ESTADO.get(en.estado, en.estado)}»")
        limitar_ip(request, clave="motorizado", maximo=8, ventana=600, sujeto=f"pin:{eid}:{en.id}", mensaje="Demasiados intentos con el código. Pida al negocio que la cierre.")
        if data.pin.strip() != en.pin:
            raise HTTPException(400, "El código del cliente no coincide")
        _cerrar(s, eid, en)
        return _salida_entrega(en, {m.id: m})


@router.put("/api/publico/{slug}/motorizado/entregas/{enid}/incidencia")
def incidencia(slug: str, enid: int, data: IncidenciaIn, x_motorizado: str | None = Header(default=None)):
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado); en = _mi_entrega(s, eid, m, enid)
        if en.estado in ("entregada", "cancelada"):
            raise HTTPException(400, "La entrega ya está cerrada")
        en.estado = "incidencia"; en.incidencia = data.texto.strip(); s.add(en); s.commit(); s.refresh(en)
        return _salida_entrega(en, {m.id: m})


@router.put("/api/publico/{slug}/motorizado/posicion")
def posicion(slug: str, data: PosicionIn, x_motorizado: str | None = Header(default=None)):
    e, eid = _empresa_slug(slug)
    with sesion_de(eid) as s:
        m = _moto(s, eid, x_motorizado); m.lat = data.lat; m.lng = data.lng; m.ubicado_en = ahora_cr().isoformat(timespec="seconds"); s.add(m); s.commit()
    return {"ok": True}
