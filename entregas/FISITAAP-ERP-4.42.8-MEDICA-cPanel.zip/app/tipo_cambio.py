"""Tipo de cambio del dólar: referencia del BCCR publicada por Hacienda (api.hacienda.go.cr/indicadores/tc/dolar).

Se consulta una vez por día y se guarda en data/tipo_cambio.json; si Hacienda no responde se usa el último valor guardado.
El tipo de cambio que la empresa aplica en sus documentos es la VENTA del día más un margen de protección cambiaria
(`Empresa.margen_cambiario`, 5 % por defecto): BCCR venta 455,60 + 5 % = 478,38.
"""
import bisect
import json
import logging
import threading
import time
from datetime import date as _date, datetime as _dt, timedelta, timezone
from typing import Optional

import httpx
from sqlmodel import Field, Session, SQLModel, select

from .config import DATA_DIR, ahora_cr
from .db import central, engine
from .tipo_cambio_semilla import SEMILLA

URL = "https://api.hacienda.go.cr/indicadores/tc/dolar"
URL_HISTORICO = URL + "/historico/"
ARCHIVO = DATA_DIR / "tipo_cambio.json"
INICIO = "2026-10-01"
_lock = threading.Lock()
log = logging.getLogger(__name__)


class TipoCambioDia(SQLModel, table=True):
    """4.18: registro propio del tipo de cambio de referencia del BCCR, un renglón por día (central: es igual para todas las empresas)."""
    __tablename__ = "tipo_cambio_dia"
    fecha: str = Field(primary_key=True, max_length=10)
    compra: float
    venta: float
    fuente: str = "BCCR"
    guardado: _dt = Field(default_factory=lambda: _dt.now(timezone.utc))


central(TipoCambioDia)
_sembrado = False
_memoria = {"t": -1e9, "fechas": [], "filas": []}
_ultimo_historico = [-1e9]


def _sembrar() -> None:
    """Los días anteriores al registro diario. Solo agrega los que falten: nunca pisa lo guardado."""
    global _sembrado
    if _sembrado:
        return
    try:
        with Session(engine) as s:
            hay = set(s.exec(select(TipoCambioDia.fecha)).all())
            for f, c, v in SEMILLA:
                if f not in hay:
                    s.add(TipoCambioDia(fecha=f, compra=c, venta=v, fuente="BCCR"))
            s.commit()
        _sembrado = True
    except Exception as ex:  # noqa: BLE001  otro proceso sembró a la vez: se revisa de nuevo la próxima vez
        log.info("Tipo de cambio: semilla pendiente (%s)", type(ex).__name__)


def guardar_dia(fecha: str, compra: float, venta: float, fuente: str = "BCCR") -> None:
    """Anota el día en el registro propio. Un error aquí nunca afecta a quien consulta el tipo de cambio."""
    f = str(fecha or "")[:10]
    if len(f) != 10 or not venta:
        return
    try:
        with Session(engine) as s:
            x = s.get(TipoCambioDia, f)
            if x is None:
                s.add(TipoCambioDia(fecha=f, compra=round(float(compra or 0), 2), venta=round(float(venta), 2), fuente=fuente))
            elif (x.compra, x.venta) != (round(float(compra or 0), 2), round(float(venta), 2)):
                x.compra, x.venta, x.fuente = round(float(compra or 0), 2), round(float(venta), 2), fuente
                s.add(x)
            else:
                return
            s.commit()
        _memoria["t"] = -1e9
    except Exception as ex:  # noqa: BLE001
        log.warning("Tipo de cambio: no se pudo guardar %s: %s", f, ex)


def _cargar() -> None:
    if time.monotonic() - _memoria["t"] < 600 and _memoria["fechas"]:
        return
    _sembrar()
    with Session(engine) as s:
        filas = s.exec(select(TipoCambioDia).order_by(TipoCambioDia.fecha)).all()
    _memoria.update(t=time.monotonic(), fechas=[x.fecha for x in filas], filas=[(x.compra, x.venta) for x in filas])


def dia(fecha: str, tolerancia: int = 7) -> Optional[dict]:
    """El tipo de cambio de esa fecha. Si ese día no está, el último anterior dentro de `tolerancia` días (el BCCR repite el valor en fines de semana y feriados)."""
    f = str(fecha or "")[:10]
    try:
        pedido = _date.fromisoformat(f)
        _cargar()
    except Exception:  # noqa: BLE001
        return None
    i = bisect.bisect_right(_memoria["fechas"], f) - 1
    if i < 0 or (pedido - _date.fromisoformat(_memoria["fechas"][i])).days > tolerancia:
        return None
    c, v = _memoria["filas"][i]
    return {"fecha": _memoria["fechas"][i], "compra": c, "venta": v, "exacto": _memoria["fechas"][i] == f}


def venta_en(fecha: str) -> Optional[float]:
    d = dia(fecha)
    return d["venta"] if d else None


def mapa() -> dict:
    """{fecha: venta} de todo el registro, para los reportes del navegador."""
    _cargar()
    return {f: v for f, (_c, v) in zip(_memoria["fechas"], _memoria["filas"])}


def historico(anio: Optional[int] = None) -> dict:
    """El registro de un año, del día más reciente al más antiguo, y los años disponibles."""
    _sembrar()
    with Session(engine) as s:
        todas = s.exec(select(TipoCambioDia).order_by(TipoCambioDia.fecha.desc())).all()
    anios = sorted({int(x.fecha[:4]) for x in todas}, reverse=True)
    elegido = int(anio) if anio else (anios[0] if anios else ahora_cr().year)
    return {"anio": elegido, "anios": anios, "filas": [{"id": x.fecha, "fecha": x.fecha, "compra": x.compra, "venta": x.venta, "fuente": x.fuente} for x in todas if x.fecha[:4] == str(elegido)]}


def completar() -> int:
    """Lo llama la cola: anota el día de hoy y, si faltara algún día desde octubre (el servidor estuvo apagado), lo pide al histórico de Hacienda como mucho cada 6 horas.
    Un fallo no afecta nada: se reintenta en la siguiente vuelta."""
    obtener()
    _sembrar()
    with Session(engine) as s:
        hay = set(s.exec(select(TipoCambioDia.fecha)).all())
    d, hoy, faltan = _date.fromisoformat(INICIO), ahora_cr().date(), []
    while d <= hoy:
        if d.isoformat() not in hay:
            faltan.append(d.isoformat())
        d += timedelta(days=1)
    if not faltan or time.monotonic() - _ultimo_historico[0] < 21600:
        return 0
    _ultimo_historico[0] = time.monotonic()
    try:
        r = httpx.get(URL_HISTORICO, params={"d": faltan[0], "h": faltan[-1]}, timeout=15, headers={"Accept": "application/json"})
        r.raise_for_status()
        datos = r.json()
    except Exception as ex:  # noqa: BLE001
        log.info("Tipo de cambio: el histórico de Hacienda no respondió (%s)", type(ex).__name__)
        return 0
    n = 0
    for x in datos if isinstance(datos, list) else []:
        try:
            f, c, v = str(x["fecha"])[:10], float(x["compra"]), float(x["venta"])
        except (KeyError, TypeError, ValueError):
            continue
        if f in faltan:
            guardar_dia(f, c, v, "BCCR (publicado por Hacienda)"); n += 1
    return n


def _leer() -> dict | None:
    try:
        return json.loads(ARCHIVO.read_text(encoding="utf-8"))
    except Exception:
        return None


def obtener(forzar: bool = False) -> dict:
    """{fecha, compra, venta, fuente, consultado, error}. `error` explica por qué no se pudo actualizar (se devuelve lo último guardado)."""
    hoy = ahora_cr().strftime("%Y-%m-%d")
    with _lock:
        cache = _leer()
        if cache and not forzar and cache.get("consultado") == hoy and cache.get("venta"):
            return cache
        # un fallo reciente no se reintenta durante 20 minutos: cada Inicio esperaba 10 s en fila (R158)
        ult = cache.get("fallo_en") if cache else None
        if ult and not forzar and (ahora_cr() - _dt.fromisoformat(ult)).total_seconds() < 1200:
            return {**cache, "error": cache.get("error_texto") or "Hacienda no respondió hace poco; se usa el último valor"}
        try:
            r = httpx.get(URL, timeout=10, headers={"Accept": "application/json"})
            r.raise_for_status()
            j = r.json()
            datos = {"fecha": j["venta"]["fecha"], "venta": round(float(j["venta"]["valor"]), 2),
                     "compra": round(float(j["compra"]["valor"]), 2), "fuente": "BCCR (publicado por Hacienda)",
                     "consultado": hoy, "error": None}
            ARCHIVO.write_text(json.dumps(datos, ensure_ascii=False), encoding="utf-8")
            guardar_dia(datos["fecha"], datos["compra"], datos["venta"], datos["fuente"])     # 4.18: el registro propio
            return datos
        except Exception as ex:
            texto = (f"No se pudo actualizar hoy ({type(ex).__name__}); se usa el valor del {cache.get('fecha')}" if cache and cache.get("venta")
                     else f"No se pudo consultar el tipo de cambio ({type(ex).__name__})")
            marca = {**(cache or {"fecha": None, "venta": None, "compra": None, "fuente": None, "consultado": None}), "fallo_en": ahora_cr().isoformat(timespec="seconds"), "error_texto": texto}
            try:
                ARCHIVO.write_text(json.dumps(marca, ensure_ascii=False), encoding="utf-8")
            except OSError:
                pass
            return {**marca, "error": texto}


def aplicado(venta: float | None, margen: float) -> float | None:
    """Venta del día más el margen de protección (porcentaje), a 2 decimales."""
    if not venta:
        return None
    return round(venta * (1 + (margen or 0) / 100), 2)
