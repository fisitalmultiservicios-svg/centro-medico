"""Diseño común de los correos (3.83).

Todos los correos del sistema salen con la misma estructura, hecha con tablas y estilos en línea para que se vea bien en Gmail,
Outlook (escritorio, web y celular), Apple Mail y Yahoo:
- Correos de la plataforma (prueba gratis, accesos, contraseñas, avisos del plan, solicitudes del sitio): encabezado azul marino
  con el logo de FISITAAP. El fondo oscuro aguanta el «modo oscuro» de Outlook y Gmail sin que el logo desaparezca.
- Correos de una empresa (comprobantes, recordatorios de cobro, pedidos, tickets, hotel, planilla): encabezado blanco con el logo
  de la empresa o de su marca (3.45) en una placa blanca redondeada, y un color de acento sacado del mismo logo.

Los logos van DENTRO del correo (imágenes «cid:», multipart/related): se ven apenas se abre, sin «descargar imágenes», y no
dependen de que el servidor esté en línea. Se reducen antes de adjuntarlos (pocos KB). El texto plano lo arma cada correo aparte.

Uso: html = armar(plataforma(), titulo=..., parrafos=[...], datos=[...], boton=(texto, url)); correo.enviar(..., html, texto, ...)
`armar` devuelve un `CorreoHtml` (un str que además lleva sus imágenes); correo.enviar las adjunta solo.
"""
from __future__ import annotations

import base64
import colorsys
import hashlib
import html as _html
import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional, Sequence

e = _html.escape
FUENTE = "-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif"
NAVY = "#08142f"
AZUL = "#1450f5"
VERDE = "#12c98a"
FONDO = "#eef2f8"
TEXTO = "#1c2740"
GRIS = "#5f6b85"
LINEA = "#e3e8f2"
CAJA = "#f5f7fc"
CAJA_BORDE = "#dfe6f3"
ACENTO_EMPRESA = "#1f3b8f"            # cuando el logo no tiene un color claro o la empresa no tiene logo
LOGO_PLATAFORMA = Path(__file__).resolve().parent / "static" / "fisitaap" / "assets" / "fisitaap-correo.png"
_CACHE: dict = {}


class CorreoHtml(str):
    """El HTML del correo más las imágenes que lleva dentro: [(cid, bytes, tipo, subtipo)]."""
    imagenes: list


def _html_con(texto: str, imagenes: list) -> CorreoHtml:
    h = CorreoHtml(texto)
    h.imagenes = imagenes
    return h


@dataclass
class Remitente:
    nombre: str
    plataforma: bool = False
    logo: Optional[Path] = None
    color: str = AZUL
    contacto: list = field(default_factory=list)       # líneas del pie (correo, teléfono, sitio)
    sitio: str = ""


# ------------------------------------------------------------------------------------------------- remitentes
def plataforma() -> Remitente:
    from .config import URL_PUBLICA, dominio_sistema, nombre_sistema
    sitio = URL_PUBLICA or ("https://" + dominio_sistema() if dominio_sistema() else "")
    return Remitente(nombre=nombre_sistema(), plataforma=True, logo=LOGO_PLATAFORMA if LOGO_PLATAFORMA.exists() else None, color=AZUL, sitio=sitio)


def de_empresa(empresa, marca=None, color: Optional[str] = None, nombre: Optional[str] = None) -> Remitente:
    """Remitente de una empresa (o de su marca): nombre comercial, logo, contacto del pie y color de acento."""
    from . import marcas
    try:
        logo = marcas.logo_de(empresa, marca)
    except Exception:  # noqa: BLE001  (sin logo legible: el nombre va en texto)
        logo = None
    ct = marcas.contacto_de(empresa, marca)
    contacto = [x for x in [ct.get("correo"), (f"+506 {ct['telefono']}" if ct.get("telefono") else ""), (ct.get("sitio_web") or "")] if x]
    acento = _color_valido(color) or (color_de_logo(logo) if logo else None) or ACENTO_EMPRESA
    return Remitente(nombre=nombre or marcas.nombre_de(empresa, marca) or "", plataforma=False, logo=logo, color=acento, contacto=contacto)


def de_nombre(nombre: str) -> Remitente:
    """Remitente con solo el nombre (pruebas de correo sin empresa a mano)."""
    return Remitente(nombre=nombre or "", plataforma=False, color=ACENTO_EMPRESA)


# ------------------------------------------------------------------------------------------------- imágenes
def _color_valido(c) -> Optional[str]:
    c = str(c or "").strip()
    return _legible(c) if re.fullmatch(r"#[0-9a-fA-F]{6}", c) else None


def _lum(rgb) -> float:
    def canal(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * canal(r) + 0.7152 * canal(g) + 0.0722 * canal(b)


def _legible(hex_color: str) -> str:
    """Oscurece el color hasta que el texto blanco del botón tenga buen contraste (4.5 : 1)."""
    rgb = [int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]
    for _ in range(30):
        if (1.05) / (_lum(rgb) + 0.05) >= 4.5:
            break
        rgb = [int(v * 0.9) for v in rgb]
    return "#" + "".join(f"{v:02x}" for v in rgb)


def color_de_logo(ruta: Optional[Path]) -> Optional[str]:
    """Color de acento sacado del logo: el tono saturado que más aparece (sin blancos, negros ni grises)."""
    if not ruta:
        return None
    try:
        clave = ("color", str(ruta), ruta.stat().st_mtime)
        if clave in _CACHE:
            return _CACHE[clave]
        from PIL import Image
        im = Image.open(ruta).convert("RGBA")
        im.thumbnail((160, 160))
        cuenta: dict = {}
        for r, g, b, a in im.getdata():
            if a < 200:
                continue
            h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
            if s < 0.35 or l < 0.12 or l > 0.88:
                continue
            k = (r // 24, g // 24, b // 24)
            cuenta[k] = cuenta.get(k, 0) + 1
        res = None
        if cuenta and sum(cuenta.values()) >= 30:
            r, g, b = (v * 24 + 12 for v in max(cuenta, key=cuenta.get))
            res = _legible(f"#{min(r, 255):02x}{min(g, 255):02x}{min(b, 255):02x}")
        _CACHE[clave] = res
        return res
    except Exception:  # noqa: BLE001
        return None


def _placa(ruta: Path, ancho_max: int, alto_max: int, placa: bool) -> Optional[tuple[bytes, int, int]]:
    """Logo reducido (a 2× para pantallas nítidas) en PNG. `placa`: sobre un rectángulo blanco redondeado con esquinas
    transparentes (en modo oscuro se ve como una placa blanca y el logo no se pierde). Devuelve (png, ancho, alto) en px de pantalla."""
    try:
        clave = ("logo", str(ruta), ruta.stat().st_mtime, ancho_max, alto_max, placa)
        if clave in _CACHE:
            return _CACHE[clave]
        from PIL import Image, ImageDraw
        im = Image.open(ruta).convert("RGBA")
        caja = im.getbbox()
        if caja:
            im = im.crop(caja)
        im.thumbnail((ancho_max * 2, alto_max * 2), Image.LANCZOS)
        if placa:
            pad = 16
            lienzo = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (255, 255, 255, 0))
            ImageDraw.Draw(lienzo).rounded_rectangle((0, 0, lienzo.width - 1, lienzo.height - 1), radius=18, fill=(255, 255, 255, 255))
            lienzo.alpha_composite(im, (pad, pad))
            im = lienzo
        buf = io.BytesIO()
        im.save(buf, "PNG", optimize=True)
        res = (buf.getvalue(), max(1, im.width // 2), max(1, im.height // 2))
        _CACHE[clave] = res
        return res
    except Exception:  # noqa: BLE001  (logo dañado o formato raro: el correo sale con el nombre en texto)
        return None


# ------------------------------------------------------------------------------------------------- piezas del cuerpo
def _enlinea(t: str, color: str) -> str:
    """Texto → HTML seguro: **negrita** y direcciones https como enlace."""
    t = e(str(t or ""))
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    return re.sub(r'(?<![">=])(https?://[^\s<]+[^\s<.,;:!?)])', rf'<a href="\1" style="color:{color};word-break:break-all">\1</a>', t)


def parrafos(texto: str, color: str = AZUL) -> str:
    """Texto escrito por la empresa (plantillas, mensajes): bloques separados por línea en blanco; los saltos se respetan."""
    bloques = [b for b in re.split(r"\n\s*\n", str(texto or "").replace("\r", "").strip()) if b.strip()]
    return "".join(f'<p style="margin:0 0 14px">{"<br>".join(_enlinea(x, color) for x in b.split(chr(10)))}</p>' for b in bloques)


def _datos(filas: Sequence, color: str) -> str:
    """Recuadro de datos: cada dato con su etiqueta arriba (no se corta en celulares angostos ni con correos largos)."""
    filas = [(k, v) for k, v in filas if str(v if v is not None else "").strip()]
    if not filas:
        return ""
    celdas = "".join(
        f'<tr><td style="padding:11px 18px;border-top:{"0" if i == 0 else "1px solid " + CAJA_BORDE};font-family:{FUENTE}">'
        f'<div style="font-size:12px;line-height:1.4;color:{GRIS};margin:0 0 2px">{e(str(k))}</div>'
        f'<div style="font-size:15px;line-height:1.45;font-weight:bold;color:{TEXTO};word-break:break-word;overflow-wrap:anywhere">{_enlinea(v, color)}</div></td></tr>'
        for i, (k, v) in enumerate(filas))
    return (f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:6px 0 20px;background:{CAJA};border:1px solid {CAJA_BORDE};border-radius:12px;border-collapse:separate">'
            f'{celdas}</table>')


def _detalle(lineas: Sequence, totales: Sequence, color: str) -> str:
    """Tabla de ítems: lineas [(descripción, monto, nota)], totales [(etiqueta, monto, fuerte)]."""
    if not lineas and not totales:
        return ""
    filas = "".join(
        f'<tr><td style="padding:10px 0;border-bottom:1px solid {LINEA};font-family:{FUENTE};font-size:14px;color:{TEXTO}" valign="top">{e(str(d))}'
        + (f'<div style="font-size:12px;color:{GRIS};margin-top:2px">{e(str(n))}</div>' if n else "")
        + f'</td><td style="padding:10px 0 10px 12px;border-bottom:1px solid {LINEA};font-family:{FUENTE};font-size:14px;color:{TEXTO};white-space:nowrap" align="right" valign="top">{e(str(m))}</td></tr>'
        for d, m, n in lineas)
    tot = "".join(
        f'<tr><td style="padding:{"10px" if f else "6px"} 0 0;font-family:{FUENTE};font-size:{"16px" if f else "14px"};color:{TEXTO if f else GRIS};{"font-weight:bold" if f else ""}">{e(str(t))}</td>'
        f'<td style="padding:{"10px" if f else "6px"} 0 0 12px;font-family:{FUENTE};font-size:{"16px" if f else "14px"};color:{color if f else GRIS};{"font-weight:bold" if f else ""};white-space:nowrap" align="right">{e(str(m))}</td></tr>'
        for t, m, f in totales)
    return f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:4px 0 22px">{filas}{tot}</table>'


def _cita(texto: str, color: str, autor: str = "") -> str:
    return (f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:2px 0 20px"><tr>'
            f'<td width="4" style="background:{color};border-radius:2px;font-size:0">&nbsp;</td>'
            f'<td style="background:{CAJA};padding:14px 18px;font-family:{FUENTE};font-size:15px;line-height:1.6;color:{TEXTO}">'
            + (f'<div style="font-size:12px;font-weight:bold;color:{GRIS};margin-bottom:6px">{e(autor)}</div>' if autor else "")
            + "<br>".join(_enlinea(x, color) for x in str(texto or "").replace("\r", "").split("\n")) + "</td></tr></table>")


def _aviso(texto: str, tono: str) -> str:
    fondo, borde, letra = {"rojo": ("#fef2f2", "#fecaca", "#991b1b"), "ambar": ("#fffbeb", "#fde68a", "#92400e"),
                           "verde": ("#ecfdf5", "#a7f3d0", "#065f46")}.get(tono, (CAJA, CAJA_BORDE, TEXTO))
    return (f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:2px 0 20px"><tr>'
            f'<td style="background:{fondo};border:1px solid {borde};border-radius:12px;padding:12px 16px;font-family:{FUENTE};font-size:14px;line-height:1.55;color:{letra}">'
            f'{_enlinea(texto, letra)}</td></tr></table>')


def boton(texto: str, url: str, color: str) -> str:
    """Botón que funciona también en Outlook de escritorio (celda con color de fondo, sin imágenes)."""
    return (f'<table role="presentation" cellspacing="0" cellpadding="0" style="margin:8px 0 22px"><tr>'
            f'<td align="center" bgcolor="{color}" style="background:{color};border-radius:10px">'
            f'<a href="{e(url, quote=True)}" target="_blank" style="display:inline-block;padding:14px 28px;font-family:{FUENTE};font-size:15px;font-weight:bold;'
            f'color:#ffffff;text-decoration:none;border-radius:10px">{e(texto)}</a></td></tr></table>'
            f'<p style="margin:0 0 18px;font-family:{FUENTE};font-size:12px;line-height:1.5;color:{GRIS}">Si el botón no abre, copie esta dirección en el navegador:<br>'
            f'<a href="{e(url, quote=True)}" style="color:{color};word-break:break-all">{e(url)}</a></p>')


# ------------------------------------------------------------------------------------------------- documento
def armar(rem: Remitente, *, titulo: str, asunto: str = "", antetitulo: str = "", saludo: str = "", mensaje: str = "", mensaje_autor: str = "",
          parrafos_txt: Iterable[str] = (), texto_libre: str = "", cita: str = "", cita_autor: str = "", aviso: str = "", aviso_tono: str = "",
          datos: Sequence = (), lista: Sequence = (), lineas: Sequence = (), totales: Sequence = (), boton_: Optional[tuple] = None,
          despues: Iterable[str] = (), nota: str = "", preencabezado: str = "", extra_html: str = "") -> CorreoHtml:
    """Correo completo. Orden: saludo, mensaje personal, párrafos, texto libre, cita, aviso, datos, lista, ítems, extra, botón,
    párrafos de después, nota."""
    color = rem.color or AZUL
    imagenes: list = []
    # ---- encabezado
    if rem.plataforma:
        logo = _placa(rem.logo, 220, 70, placa=False) if rem.logo else None
        if logo:
            cid = "logo-" + hashlib.sha1(logo[0]).hexdigest()[:12] + "@fisitaap"
            imagenes.append((cid, logo[0], "image", "png"))
            marca = f'<img src="cid:{cid}" width="{logo[1]}" height="{logo[2]}" alt="{e(rem.nombre)}" style="display:block;border:0;outline:none;width:{logo[1]}px;height:{logo[2]}px">'
        else:
            marca = f'<span style="font-family:{FUENTE};font-size:22px;font-weight:bold;color:#ffffff">{e(rem.nombre)}</span>'
        from .config import FIRMA_MARCA
        if FIRMA_MARCA and FIRMA_MARCA not in str(rem.nombre if not logo else ""):   # 3.86: «by Brillante Agencia» bajo el logo
            marca += f'<div style="font-family:{FUENTE};font-size:12px;font-weight:bold;letter-spacing:0.3px;color:#c9d7e3;margin:8px 0 0">{e(FIRMA_MARCA)}</div>'
        cabeza = (f'<tr><td class="px" bgcolor="{NAVY}" style="background:{NAVY};padding:26px 36px 24px">{marca}</td></tr>'
                  f'<tr><td height="4" bgcolor="{AZUL}" style="background:{AZUL};background-image:linear-gradient(90deg,{AZUL},{VERDE});font-size:0;line-height:0;height:4px">&nbsp;</td></tr>')
    else:
        logo = _placa(rem.logo, 210, 64, placa=True) if rem.logo else None
        if logo:
            cid = "logo-" + hashlib.sha1(logo[0]).hexdigest()[:12] + "@empresa"
            imagenes.append((cid, logo[0], "image", "png"))
            marca = f'<img src="cid:{cid}" width="{logo[1]}" height="{logo[2]}" alt="{e(rem.nombre)}" style="display:block;border:0;outline:none;width:{logo[1]}px;height:{logo[2]}px;margin-left:-8px">'
        else:
            marca = f'<span style="font-family:{FUENTE};font-size:22px;font-weight:bold;color:{color};letter-spacing:-0.2px">{e(rem.nombre)}</span>'
        cabeza = (f'<tr><td height="5" bgcolor="{color}" style="background:{color};font-size:0;line-height:0;height:5px">&nbsp;</td></tr>'
                  f'<tr><td class="px" style="padding:22px 36px 6px">{marca}</td></tr>')
    # ---- cuerpo
    partes = []
    if antetitulo:
        partes.append(f'<div style="font-family:{FUENTE};font-size:12px;font-weight:bold;letter-spacing:1.2px;text-transform:uppercase;color:{color};margin:0 0 8px">{e(antetitulo)}</div>')
    partes.append(f'<h1 style="margin:0 0 18px;font-family:{FUENTE};font-size:24px;line-height:1.3;font-weight:bold;color:{NAVY if rem.plataforma else TEXTO}">{e(titulo)}</h1>')
    if saludo:
        partes.append(f'<p style="margin:0 0 14px">{_enlinea(saludo, color)}</p>')
    if mensaje:
        partes.append(_cita(mensaje, color, mensaje_autor))
    for p in parrafos_txt:
        if str(p or "").strip():
            partes.append(f'<p style="margin:0 0 14px">{"<br>".join(_enlinea(x, color) for x in str(p).split(chr(10)))}</p>')
    if texto_libre:
        partes.append(parrafos(texto_libre, color))
    if cita:
        partes.append(_cita(cita, color, cita_autor))
    if aviso:
        partes.append(_aviso(aviso, aviso_tono))
    partes.append(_datos(datos, color))
    if lista:
        partes.append('<ul style="margin:0 0 18px;padding-left:20px">' + "".join(f'<li style="margin:0 0 8px">{_enlinea(x, color)}</li>' for x in lista if str(x or "").strip()) + "</ul>")
    partes.append(_detalle(lineas, totales, color))
    if extra_html:
        partes.append(extra_html)
    if boton_ and boton_[1]:
        partes.append(boton(boton_[0], boton_[1], color))
    for p in despues:
        if str(p or "").strip():
            partes.append(f'<p style="margin:0 0 14px">{"<br>".join(_enlinea(x, color) for x in str(p).split(chr(10)))}</p>')
    if nota:
        partes.append(f'<p style="margin:4px 0 0;font-size:13px;line-height:1.55;color:{GRIS};word-break:break-word;overflow-wrap:anywhere">{"<br>".join(_enlinea(x, GRIS) for x in str(nota).split(chr(10)))}</p>')
    # ---- pie
    if rem.plataforma:
        sitio = rem.sitio.replace("https://", "").replace("http://", "").rstrip("/")
        pie = (f'<b style="color:{NAVY}">{e(rem.nombre)}</b> · IT Core Sync S.R.L.'
               + (f'<br><a href="{e(rem.sitio, quote=True)}" style="color:{GRIS}">{e(sitio)}</a>' if sitio else "")
               + '<br>Este correo lo envió el sistema automáticamente.')
    else:
        from .config import URL_PUBLICA, dominio_sistema, nombre_sistema
        plataforma_url = URL_PUBLICA or ("https://" + dominio_sistema() if dominio_sistema() else "")
        pie = (f'<b style="color:{TEXTO}">{e(rem.nombre)}</b>' + "".join(f"<br>{_enlinea(x, GRIS)}" for x in rem.contacto)
               + f'<br><span style="font-size:11px;color:#8a94ab">Enviado con '
               + (f'<a href="{e(plataforma_url, quote=True)}" style="color:#8a94ab">{e(nombre_sistema())}</a>' if plataforma_url else e(nombre_sistema())) + "</span>")
    pre = (f'<div style="display:none;max-height:0;overflow:hidden;mso-hide:all;font-size:1px;line-height:1px;color:{FONDO};opacity:0">{e(preencabezado)}'
           + "&#8199;&#65279;&#847;" * 30 + "</div>") if preencabezado else ""
    doc = (
        '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light">'
        f'<title>{e(asunto or titulo)}</title>'
        '<style>@media (max-width:620px){.px{padding-left:22px!important;padding-right:22px!important}.marco{padding:12px 6px!important}h1{font-size:21px!important}}'
        'a{text-decoration:underline}</style></head>'
        f'<body style="margin:0;padding:0;background:{FONDO};-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%">{pre}'
        f'<table role="presentation" width="100%" cellspacing="0" cellpadding="0" bgcolor="{FONDO}" style="background:{FONDO}"><tr><td class="marco" align="center" style="padding:28px 12px">'
        f'<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;'
        f'border:1px solid {LINEA};font-family:{FUENTE};color:{TEXTO}">'
        + cabeza
        + f'<tr><td class="px" style="padding:22px 36px 12px;font-family:{FUENTE};font-size:15px;line-height:1.6;color:{TEXTO}">{"".join(partes)}</td></tr>'
        + f'<tr><td class="px" style="padding:0 36px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td style="border-top:1px solid {LINEA};font-size:0;line-height:0">&nbsp;</td></tr></table></td></tr>'
        + f'<tr><td class="px" style="padding:16px 36px 26px;font-family:{FUENTE};font-size:12px;line-height:1.65;color:{GRIS}">{pie}</td></tr>'
        + '</table></td></tr></table></body></html>')
    return _html_con(doc, imagenes)


def para_navegador(h: str) -> str:
    """Vista previa en el navegador (consola): las imágenes «cid:» pasan a data: para que se vean."""
    out = str(h)
    for cid, datos, tipo, sub in getattr(h, "imagenes", None) or []:
        out = out.replace(f"cid:{cid}", f"data:{tipo}/{sub};base64," + base64.b64encode(datos).decode())
    return out
