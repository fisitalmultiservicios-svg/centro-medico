"""Empresas de demostración y pruebas gratis de 30 días (1.38).

`crear_empresa_demo()` (solo para capturas y pruebas internas, no se expone en el sistema) arma «TecnoTropical Demo S.A.» con 6 meses de datos de ejemplo: clientes, ítems, facturas y tiquetes con su XML
(sin firmar y sin enviar a Hacienda; se marcan aceptados para que se vean los reportes), notas de crédito, cobros, comprobantes de
proveedores, empleados y planillas, cotizaciones y una exoneración. Es ambiente de pruebas, sin llave ni credenciales: nunca llega a
Hacienda. `crear_prueba()` crea al prospecto su usuario, su empresa vacía y una demo, ambas con vencimiento a los 30 días.
"""
import json
import logging
import random
import secrets
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from .config import DATA_DIR, TZ_CR, URL_PUBLICA, ahora_cr, nombre_sistema, dominio_sistema
from .db import Cliente, Documento, DocumentoLinea, Empresa, Producto, Secuencia, engine, engine_empresa, get_session

log = logging.getLogger(__name__)
XML_DIR = DATA_DIR / "xml"

CLIENTES = [
    ("02", "3101900101", "Hotel Vista al Volcán S.A.", "Hotel Vista al Volcán"), ("02", "3101900102", "Clínica Dental Sonrisas S.R.L.", "Clínica Sonrisas"),
    ("02", "3101900103", "Constructora Pacífico Norte S.A.", "Pacífico Norte"), ("02", "3101900104", "Soda y Restaurante El Fogón S.A.", "El Fogón"),
    ("02", "3101900105", "Colegio Bilingüe Las Palmas S.A.", "Colegio Las Palmas"), ("02", "3101900106", "Agroexportadora del Valle S.A.", "Agro del Valle"),
    ("02", "3101900107", "Farmacia La Esquina S.R.L.", "Farmacia La Esquina"), ("02", "3101900108", "Despacho Contable Rojas & Asociados S.A.", "Rojas & Asociados"),
    ("02", "3101900109", "Veterinaria Patitas S.R.L.", "Veterinaria Patitas"), ("02", "3101900110", "Ferretería El Tornillo S.A.", "Ferretería El Tornillo"),
    ("02", "3101900111", "Inmobiliaria Brisas del Mar S.A.", "Brisas del Mar"), ("02", "3101900112", "Laboratorio Clínico Vida S.A.", "Laboratorio Vida"),
    ("01", "109990101", "Laura Méndez Solano", None), ("01", "109990102", "Carlos Jiménez Vargas", None),
    ("01", "109990103", "Andrea Quesada Mora", None), ("01", "109990104", "José Pablo Castro Ruiz", None),
]
PROVEEDORES = [("3101900201", "Mayorista de Cómputo Centroamericana S.A."), ("3101900202", "Distribuidora Eléctrica Nacional S.A."),
               ("3101900203", "Servicios de Mensajería Rápida S.R.L."), ("3101900204", "Inmobiliaria Torre Central S.A. (alquiler)"),
               ("3101900205", "Compañía de Telecomunicaciones del Este S.A."), ("3101900206", "Papelería y Suministros La Oficina S.A.")]
# (nombre, cabys, precio, costo, servicio, unidad)
ITEMS = [
    ("Computadora de escritorio Core i5", "4525000000000", 485000, 360000, False, "Unid"), ("Laptop empresarial 14\"", "4525000000000", 610000, 455000, False, "Unid"),
    ("Disco de estado sólido 1 TB", "4527100000000", 58000, 39000, False, "Unid"), ("Mouse inalámbrico", "4526100000200", 9500, 5200, False, "Unid"),
    ("Impresora multifuncional láser", "4491403990000", 189000, 138000, False, "Unid"), ("Unidad de respaldo externa 2 TB", "4527100000000", 72000, 50500, False, "Unid"),
    ("Mantenimiento preventivo de equipo", "8715300000200", 35000, 0, True, "Sp"), ("Consultoría en tecnología (hora)", "8313100009900", 28000, 0, True, "h"),
    ("Licencia anual de antivirus", "7331100000000", 24500, 14000, True, "Sp"), ("Soporte técnico mensual", "8313100009900", 95000, 0, True, "Sp"),
    ("Configuración de red y wifi", "8715300000200", 65000, 0, True, "Sp"), ("Licencia de ofimática (anual)", "7331100000000", 89000, 61000, True, "Sp"),
]
EMPLEADOS = [("María José", "Araya Solís", "Gerente comercial", "TES", 1450000), ("Daniel", "Herrera Vargas", "Técnico en soporte", "TOC", 640000),
             ("Sofía", "Chaves Mora", "Asistente contable", "TOC", 560000), ("Luis Diego", "Mora Castro", "Vendedor", "TOSC", 520000),
             ("Valeria", "Rodríguez Pérez", "Técnica de redes", "TOC", 690000), ("Esteban", "Salas Jiménez", "Mensajero", "TONC", 410000)]


def _dt(d: date, rnd: random.Random) -> datetime:
    return datetime(d.year, d.month, d.day, rnd.randint(8, 17), rnd.randint(0, 59), rnd.randint(0, 59), tzinfo=TZ_CR)


def crear_empresa_demo(s: Session, nombre: Optional[str] = None, meses: int = 6, semilla: Optional[int] = None, tipo: str = "facturacion") -> Empresa:
    """Crea la empresa de demostración con sus datos. `s` es la sesión central. `tipo` (3.64): facturacion | comercio | restaurante |
    hospitalidad | servicios; cada uno con su perfil de clientes, ítems y empleados (demo_tipos.PERFILES) y lo propio del tipo."""
    from . import main as _main  # noqa: F401  registra TODAS las tablas por empresa (promociones, entregas, TiKe…) antes de crear la base
    from . import auth, demo_tipos
    if tipo not in demo_tipos.PERFILES:
        tipo = "facturacion"
    perfil = demo_tipos.PERFILES[tipo]
    clasica = tipo == "facturacion" and (nombre is None or nombre == "TecnoTropical Demo S.A.")      # la demo de siempre (TecnoTropical)
    if clasica:
        nombre = "TecnoTropical Demo S.A."
        perfil = {**perfil, "clientes": CLIENTES, "proveedores": PROVEEDORES, "items": ITEMS, "empleados": EMPLEADOS, "tiquete_pct": 0.22, "ventas_dia": (1, 4),
                  "comercial": "TecnoTropical Demo", "cedula": "3101999998", "actividad": "4651.0",
                  "actividad_nombre": "Venta al por mayor de computadoras, equipo informático periférico y programas informáticos"}
    nombre = nombre or perfil["nombre"]
    e = auth.crear_empresa(s, nombre, "demo@example.com", perfil["cedula"], nombre_comercial=perfil["comercial"] if clasica or nombre == perfil["nombre"] else nombre, provincia=1, canton=1, distrito=8,
                           otras_senas="San José, 100 m norte del parque central (datos de ejemplo)", actividad=perfil["actividad"],
                           actividad_nombre=perfil["actividad_nombre"], telefono=22223333, correo_automatico=False, es_demo=True, tipo_negocio=tipo)
    try:
        rnd = random.Random(semilla if semilla is not None else e.id * 7919)
        info = _poblar(e, meses, rnd, perfil)
        if not clasica:
            demo_tipos.poblar(e, tipo, rnd, info["facturas"], info["hoy"], info["inicio"])
    except Exception:
        log.exception("No se pudo poblar la empresa demo %s", e.id)
        raise
    return e


def _poblar(e: Empresa, meses: int, rnd: random.Random, perfil: Optional[dict] = None) -> dict:
    from . import modulos, recepcion, rrhh
    from .exoneraciones import ExoneracionCliente
    from .fe.calculo import calcular
    from .fe.clave import generar_clave, generar_consecutivo
    from .fe.modelos import Comprobante, Descuento, Impuesto, Linea, MedioPago, Referencia
    from .fe.xml_builder import a_bytes, construir_xml
    from .main import _parte_cliente, _parte_empresa
    XML_DIR.mkdir(exist_ok=True)
    hoy = ahora_cr().date()
    inicio = (hoy.replace(day=1) - timedelta(days=31 * (meses - 1))).replace(day=1)
    if (hoy - inicio).days < 28:                               # el día 1 del mes con meses=1 dejaba el rango vacío (3.46)
        inicio = hoy - timedelta(days=28)
    emisor = _parte_empresa(e)
    perfil = perfil or {"clientes": CLIENTES, "proveedores": PROVEEDORES, "items": ITEMS, "empleados": EMPLEADOS, "tiquete_pct": 0.22, "ventas_dia": (1, 4)}
    tiquete_pct, ventas_dia = float(perfil.get("tiquete_pct", 0.22)), tuple(perfil.get("ventas_dia", (1, 4)))
    resumen_docs = []
    with Session(engine_empresa(e.id)) as s:
        clientes = []
        for tipo_id, ced, nombre, comercial in perfil["clientes"]:
            c = Cliente(empresa_id=e.id, nombre=nombre, nombre_comercial=comercial, tipo_id=tipo_id, numero_id=ced, correo=f"contacto{ced[-3:]}@example.com",
                        telefono=int(f"2{rnd.randint(2000000, 9999999)}"), provincia=1, canton=1, distrito=1, direccion="Dirección de ejemplo, San José",
                        termino_pago_dias=30 if tipo_id == "02" else 0, actividad="6201.0" if tipo_id == "02" else None)
            s.add(c); clientes.append(c)
        proveedores = []
        for ced, nombre in perfil["proveedores"]:
            p = Cliente(empresa_id=e.id, nombre=nombre, tipo="Proveedor", tipo_id="02", numero_id=ced, correo=f"facturas{ced[-3:]}@example.com")
            s.add(p); proveedores.append(p)
        productos = []
        for i, (nombre, cabys, precio, costo, serv, unidad) in enumerate(perfil["items"], start=1):
            p = Producto(empresa_id=e.id, codigo=f"P{i:03d}", nombre=nombre, cabys=cabys, precio=precio, costo=costo, es_servicio=serv, unidad_medida=unidad,
                         tipo="Servicio" if serv else "Producto", categoria="Servicios" if serv else "Equipo", inventariable=False)
            s.add(p); productos.append(p)
        s.commit()
        for x in clientes + proveedores + productos:
            s.refresh(x)

        consecutivos = {"01": 0, "04": 0, "03": 0}
        facturas = []
        pagos = []
        d = inicio
        dias_total = max(1, (hoy - inicio).days)
        while d <= hoy:
            if d.weekday() < 6:                                  # lunes a sábado
                avance = (d - inicio).days / dias_total          # el negocio crece: más ventas en los meses recientes
                for _ in range(max(1, round(rnd.randint(*ventas_dia) * (0.7 + 0.6 * avance)))):
                    tiquete = rnd.random() < tiquete_pct
                    cli = None if tiquete else rnd.choice(clientes)
                    tipo = "04" if tiquete else "01"
                    credito = (not tiquete) and cli.tipo_id == "02" and rnd.random() < 0.55
                    lineas = []
                    for prod in rnd.sample(productos, rnd.choice([1, 1, 2, 2, 3])):
                        cant = Decimal(rnd.choice([1, 1, 1, 2, 3, 5])) if not prod.es_servicio else Decimal(rnd.choice([1, 1, 2, 4, 8]) if prod.unidad_medida == "h" else 1)
                        desc = [Descuento(monto=(Decimal(str(prod.precio)) * cant * Decimal("0.05")).quantize(Decimal("0.01")), naturaleza="Descuento comercial")] if rnd.random() < 0.15 else []
                        lineas.append((prod, Linea(cabys=prod.cabys, detalle=prod.nombre, cantidad=cant, unidad_medida=prod.unidad_medida, precio_unitario=Decimal(str(prod.precio)),
                                                   es_servicio=prod.es_servicio, codigo_comercial=prod.codigo, descuentos=desc, impuestos=[Impuesto(codigo_tarifa="08", tarifa=Decimal(13))])))
                    consecutivos[tipo] += 1
                    momento = _dt(d, rnd)
                    cons = generar_consecutivo(tipo, consecutivos[tipo], 1, 1)
                    clave = generar_clave(e.numero_id, cons, momento)
                    comp = Comprobante(tipo_documento=tipo, clave=clave, consecutivo=cons, fecha_emision=momento.isoformat(timespec="seconds"), proveedor_sistemas=e.proveedor_sistemas,
                                       emisor=emisor, receptor=_parte_cliente(cli) if cli else None, condicion_venta="02" if credito else "01",
                                       plazo_credito=30 if credito else None, lineas=[l for _, l in lineas],
                                       medios_pago=[MedioPago(tipo=rnd.choice(["01", "02", "04", "06"]))])
                    root = construir_xml(comp)
                    (XML_DIR / f"{clave}.xml").write_bytes(a_bytes(root))
                    r = calcular(comp)
                    vence = (d + timedelta(days=30 if credito else 0)).isoformat()
                    doc = Documento(empresa_id=e.id, tipo_documento=tipo, clave=clave, consecutivo=cons, fecha_emision=comp.fecha_emision,
                                    cliente_id=cli.id if cli else None, receptor_nombre=cli.nombre if cli else None, total=float(r.total_comprobante),
                                    impuesto=float(r.total_impuesto), estado="aceptado", ambiente="sandbox", xml_nombre=f"{clave}.xml",
                                    mensaje_hacienda="Comprobante de demostración: no se envió a Hacienda", fecha_vencimiento=vence,
                                    condicion_venta=comp.condicion_venta, vendedor=rnd.choice(["Luis Diego Mora", "María José Araya", None]))
                    s.add(doc); s.flush()
                    for n, (prod, l) in enumerate(lineas, start=1):
                        lc = r.lineas[n - 1]
                        s.add(DocumentoLinea(documento_id=doc.id, numero=n, producto_id=prod.id, cabys=l.cabys, detalle=l.detalle, cantidad=float(l.cantidad),
                                             unidad_medida=l.unidad_medida, precio_unitario=float(l.precio_unitario), descuento=float(lc.total_descuento),
                                             codigo_tarifa="08", tarifa=13, impuesto=float(lc.impuesto_neto), total=float(lc.monto_total_linea)))
                    # cobro: contado al momento; crédito, casi siempre después del vencimiento si ya pasó (algunas quedan vencidas)
                    pagar_en = d if not credito else (d + timedelta(days=rnd.randint(20, 45)) if rnd.random() < 0.85 else None)
                    if pagar_en and pagar_en <= hoy:
                        doc.pagado = doc.total
                        pagos.append((pagar_en, doc, cli))
                    facturas.append((doc, cli, comp, lineas))
            d += timedelta(days=1)
        s.commit()
        resumen_docs = [{"id": doc.id, "tipo": doc.tipo_documento, "fecha": doc.fecha_emision, "consecutivo": doc.consecutivo, "total": doc.total, "receptor": doc.receptor_nombre} for doc, _, _, _ in facturas]

        # notas de crédito: algunas devoluciones parciales de facturas
        for doc, cli, comp, lineas in rnd.sample([f for f in facturas if f[0].tipo_documento == "01"], k=min(4, len(facturas))):
            prod, l = lineas[0]
            consecutivos["03"] += 1
            momento = _dt(min(hoy, date.fromisoformat(doc.fecha_emision[:10]) + timedelta(days=rnd.randint(2, 10))), rnd)
            cons = generar_consecutivo("03", consecutivos["03"], 1, 1)
            clave = generar_clave(e.numero_id, cons, momento)
            nc = Comprobante(tipo_documento="03", clave=clave, consecutivo=cons, fecha_emision=momento.isoformat(timespec="seconds"), proveedor_sistemas=e.proveedor_sistemas,
                             emisor=emisor, receptor=_parte_cliente(cli), lineas=[l.model_copy(update={"cantidad": Decimal(1), "descuentos": []})],
                             medios_pago=[MedioPago(tipo="04")], referencias=[Referencia(tipo_doc="01", numero=doc.clave, fecha_emision=doc.fecha_emision, codigo="06",
                                                                                         razon="Devolución de mercadería")])
            (XML_DIR / f"{clave}.xml").write_bytes(a_bytes(construir_xml(nc)))
            r = calcular(nc)
            s.add(Documento(empresa_id=e.id, tipo_documento="03", clave=clave, consecutivo=cons, fecha_emision=nc.fecha_emision, cliente_id=cli.id,
                            receptor_nombre=cli.nombre, total=float(r.total_comprobante), impuesto=float(r.total_impuesto), estado="aceptado", ambiente="sandbox",
                            xml_nombre=f"{clave}.xml", mensaje_hacienda="Comprobante de demostración: no se envió a Hacienda", referencia_clave=doc.clave,
                            referencia_codigo="06", condicion_venta="01"))
        # numeración: lo próximo que se emita sigue después de lo de ejemplo
        for tipo, n in consecutivos.items():
            if n:
                s.add(Secuencia(empresa_id=e.id, tipo_documento=tipo, ambiente="sandbox", ultimo=n))
        # cobros
        from .modulos import Pago
        for n, (fecha_pago, doc, cli) in enumerate(sorted(pagos, key=lambda x: x[0]), start=1):
            s.add(Pago(empresa_id=e.id, numero=n, tipo="caja", cliente_id=cli.id if cli else None, cliente_nombre=cli.nombre if cli else "Consumidor final",
                       cliente_cedula=cli.numero_id if cli else None, detalles=f"Cobro {doc.consecutivo}", fecha=fecha_pago.isoformat(), cuenta="Banco Nacional · Cuenta corriente",
                       medio_pago="04", monto=doc.total, estado="Conciliado" if fecha_pago < hoy - timedelta(days=15) else "No conciliado",
                       facturas=json.dumps([{"id": doc.id, "consecutivo": doc.consecutivo, "monto": doc.total}])))
        # comprobantes de proveedores (gastos): los recientes quedan por aceptar, para ver el aviso del plazo
        mes = inicio
        while mes <= hoy:
            for _ in range(rnd.randint(7, 11)):
                dia = min(hoy, mes + timedelta(days=rnd.randint(0, 27)))
                prov = rnd.choice(proveedores)
                base = rnd.choice([45000, 85000, 125000, 260000, 410000, 980000]) * rnd.uniform(0.8, 1.2)
                iva = round(base * 0.13, 2)
                pendiente = (hoy - dia).days <= 6
                s.add(recepcion.Recibido(empresa_id=e.id, clave="506" + dia.strftime("%d%m%y") + prov.numero_id.zfill(12) + f"{rnd.randint(1, 10**20):020d}"[:20] + "1" + f"{rnd.randint(0, 10**8):08d}",
                                         tipo_documento="01", consecutivo=f"00100001010{rnd.randint(1, 10**9):09d}", emisor_nombre=prov.nombre, emisor_id=prov.numero_id,
                                         fecha_emision=f"{dia.isoformat()}T10:00:00-06:00", total=round(base + iva, 2), impuesto=iva, condicion_venta="02",
                                         fecha_limite=recepcion.fecha_limite(f"{dia.isoformat()}T10:00:00-06:00").isoformat(), respuesta=None if pendiente else "05",
                                         condicion_impuesto=None if pendiente else "01", monto_impuesto_acreditar=None if pendiente else iva,
                                         estado_mensaje=None if pendiente else "aceptado", ambiente="sandbox", origen="correo"))
            mes = (mes.replace(day=28) + timedelta(days=4)).replace(day=1)
        # una exoneración registrada (ley especial)
        s.add(ExoneracionCliente(empresa_id=e.id, cliente_id=clientes[4].id, origen="manual", tipo="03", numero="Ley 7210 (ejemplo)", articulo=20,
                                 institucion="04", nombre_institucion="Ministerio de Economía, Industria y Comercio", fecha_emision="2026-01-10T00:00:00",
                                 fecha_vencimiento=(hoy + timedelta(days=25)).isoformat(), tarifa=13, cabys="[]", identificacion=clientes[4].numero_id,
                                 notas="Exoneración de ejemplo"))
        s.commit()

        # recursos humanos: empleados y planillas mensuales pagadas
        empleados = []
        for i, (nom, ape, puesto, cat, salario) in enumerate(perfil["empleados"], start=1):
            empleados.append({"id": i, "nombre": nom, "apellidos": ape, "tipo_id": "01", "numero_id": f"1099902{i:02d}", "nacionalidad": "Costarricense",
                              "correo": f"empleado{i}@example.com", "puesto": puesto, "categoria": cat, "fecha_ingreso": (inicio - timedelta(days=200 * i)).isoformat(),
                              "jornada": "diurna", "horas_semana": 48, "modo_salario": "mensual", "salario_mensual": salario, "salario_hora": None,
                              "periodo_pago": "mensual", "forma_pago": "transferencia", "aplica_renta": True, "activo": True, "hijos": i % 3, "conyuge": i % 2 == 0,
                              "tipo_contrato": "indefinido", "codigo_reloj": f"{i:04d}", "historial": []})
        modulos.reemplazar(s, e.id, "empleados", empleados)
        params = rrhh.parametros_efectivos(None)
        planillas, mes, n = [], inicio, 0
        while mes <= hoy.replace(day=1):
            fin = (mes.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
            if fin > hoy:
                break
            n += 1
            emp_srv = [{**x, "nombre_completo": f"{x['nombre']} {x['apellidos']}"} for x in empleados]
            res = rrhh.calcular_planilla([{"empleado": x} for x in emp_srv], params, "mensual")
            planillas.append({"id": n, "numero": f"PL-{n:04d}", "periodo": "mensual", "desde": mes.isoformat(), "hasta": fin.isoformat(), "fecha": fin.isoformat(),
                              "empleados": res["empleados"], "filas": res["filas"], "totales": res["totales"], "estado": "Pagada", "cuenta": "Banco Nacional · Cuenta corriente",
                              "pagada_en": fin.isoformat()})
            mes = fin + timedelta(days=1)
        modulos.reemplazar(s, e.id, "planillas", planillas)
        # cotizaciones abiertas
        cot = []
        for i in range(1, 6):
            cli = rnd.choice(clientes[:12]); prods = rnd.sample(productos, 2)
            f = hoy - timedelta(days=rnd.randint(0, 20))
            cot.append({"id": i, "numero": f"COT-{i:04d}", "cliente_id": cli.id, "cliente_nombre": cli.nombre, "cliente_cedula": cli.numero_id, "fecha": f.isoformat(),
                        "vence": (f + timedelta(days=15)).isoformat(), "moneda": "CRC", "estado": "Facturada" if i == 1 else "Sin facturar", "vendedor": "Luis Diego Mora",
                        "lineas": [{"producto_id": p.id, "detalle": p.nombre, "cabys": p.cabys, "cantidad": rnd.choice([1, 2, 5]), "precio_unitario": p.precio, "descuento": 0,
                                    "codigo_tarifa": "08", "tarifa": 13, "es_servicio": p.es_servicio, "unidad_medida": p.unidad_medida} for p in prods], "notas": "", "terminos": ""})
        modulos.reemplazar(s, e.id, "cotizaciones", cot)
        modulos.reemplazar(s, e.id, "numeracion-cotizaciones", {"prefijo": "COT-", "siguiente": 6})
        s.commit()
    return {"facturas": resumen_docs, "hoy": hoy, "inicio": inicio}


# ------------------------------------------------------------------------------------------------ pruebas de 30 días
def crear_prueba(s: Session, correo: str, nombre: str, nombre_empresa: str, numero_id: str = "", dias: int = 30, con_demo: bool = False, tipo_negocio: str = "facturacion", medica_activa: bool = False) -> dict:
    """Usuario (con contraseña temporal) + su empresa vacía que vence a los `dias` días (con_demo solo para entornos internos)."""
    from . import auth
    correo = auth.validar_correo(correo)
    hasta = (ahora_cr().date() + timedelta(days=dias)).isoformat()
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
    clave = None
    if not u:
        clave = auth.clave_facil()                               # 3.70: Tucan-Playa-4821, fácil de teclear y de recordar
        u = auth.Usuario(correo=correo, nombre=(nombre or nombre_empresa).strip()[:80], password_hash=auth.hash_password(clave), debe_cambiar_password=True)
        s.add(u); s.commit(); s.refresh(u)
    if tipo_negocio not in auth.TIPOS_NEGOCIO:
        tipo_negocio = "facturacion"
    propia = auth.crear_empresa(s, nombre_empresa.strip()[:100], correo, (numero_id or "").strip()[:20], prueba_hasta=hasta, tipo_negocio=tipo_negocio, medica_activa=medica_activa)
    s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=propia.id, rol="Administrador")); s.commit()
    auth.roles_por_tipo(s, propia.id, tipo_negocio)
    demo_id = None
    if con_demo:
        d = crear_empresa_demo(s)
        d.prueba_hasta = hasta; s.add(d)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=d.id, rol="Administrador"))
        demo_id = d.id
    s.commit()
    return {"usuario_id": u.id, "correo": correo, "password_temporal": clave, "empresa_id": propia.id, "demo_id": demo_id, "vence": hasta}


def _bienvenida(info: dict, nombre: str) -> bool:
    """Correo de bienvenida con el enlace y la contraseña temporal (con el SMTP de los avisos del sitio)."""
    from . import correo as _correo, sitio
    try:
        with Session(engine) as s:
            smtp = sitio._smtp(s, sitio.leer())
        if not smtp:
            return False
        url = (URL_PUBLICA or "https://" + dominio_sistema()).rstrip("/") + "/app/"
        clave = info.get("password_temporal")
        texto = (f"Hola {nombre},\n\nSu prueba gratis de {nombre_sistema()} está lista hasta el {info['vence'][8:10]}/{info['vence'][5:7]}/{info['vence'][:4]}.\n\n"
                 f"Ingrese en {url}\nCorreo: {info['correo']}\n" + (f"Contraseña temporal: {clave}\n(se le pedirá cambiarla al entrar)\n" if clave else "Use la contraseña que ya tiene.\n")
                 + f"\nLe acompañamos en la configuración: escríbanos si necesita ayuda.\n\nEquipo de {nombre_sistema()} · IT Core Sync")
        from . import correo_diseno as _dz                                # 3.83: diseño común
        vence = f"{info['vence'][8:10]}/{info['vence'][5:7]}/{info['vence'][:4]}"
        html = _dz.armar(_dz.plataforma(), titulo="Su prueba gratis está lista", asunto=f"Su prueba gratis de {nombre_sistema()}",
                         preencabezado=f"Puede usar todo el sistema hasta el {vence}.", saludo=f"Hola {nombre},",
                         parrafos_txt=[f"Su prueba gratis de {nombre_sistema()} está lista hasta el **{vence}**. Entre con estos datos:"],
                         datos=[("Correo", info["correo"]), ("Contraseña temporal" if clave else "Contraseña", clave or "La que ya tiene")],
                         boton_=(f"Entrar a {nombre_sistema()}", url),
                         despues=[("Al entrar se le pedirá cambiar la contraseña. " if clave else "")
                                  + "Le acompañamos en la configuración: responda este correo si necesita ayuda."])
        _correo.enviar(smtp, [info["correo"]], f"Su prueba gratis de {nombre_sistema()}", html, texto, [])
        return True
    except Exception:  # noqa: BLE001
        log.exception("No se pudo enviar la bienvenida de la prueba")
        return False


router = APIRouter(prefix="/api/admin")


class PruebaIn(BaseModel):
    medica_activa: bool = False
    correo: str
    nombre: str = Field("", max_length=80)
    nombre_empresa: str = Field(min_length=3, max_length=100)
    numero_id: Optional[str] = Field(None, max_length=20)
    dias: int = Field(30, ge=1, le=90)
    solicitud_id: Optional[int] = None
    enviar_correo: bool = True
    tipo_negocio: str = "facturacion"            # facturacion | comercio | hospitalidad (2.5)


def _superadmin():
    from .auth import superadmin
    return superadmin


def _solo_web():
    """4.25 (tanda 6): en el programa local real estas rutas responden 403 solo_web (se hacen en la página web)."""
    from .auth import solo_web
    return solo_web


@router.post("/pruebas", dependencies=[Depends(_solo_web())])
def nueva_prueba(data: PruebaIn, request: Request, s: Session = Depends(get_session), a=Depends(_superadmin())):
    from . import auth, sitio
    info = crear_prueba(s, data.correo, data.nombre, data.nombre_empresa, data.numero_id or "", data.dias, tipo_negocio=data.tipo_negocio, medica_activa=data.medica_activa)
    if data.solicitud_id:
        sol = s.get(sitio.SolicitudContacto, data.solicitud_id)
        if sol:
            sol.atendida = True; s.add(sol); s.commit()
    info["correo_enviado"] = _bienvenida(info, data.nombre or data.nombre_empresa) if data.enviar_correo else False
    auth.auditar(s, "prueba_creada", f"{info['correo']}: empresa {info['empresa_id']} y demo {info['demo_id']} hasta {info['vence']}", a, info["empresa_id"], request)
    return info


class DemoIn(BaseModel):
    tipo: str = "facturacion"
    meses: int = Field(1, ge=1, le=12)
    nombre: Optional[str] = Field(None, max_length=100)


@router.post("/demo", dependencies=[Depends(_solo_web())])
def nueva_demo(data: DemoIn, request: Request, s: Session = Depends(get_session), a=Depends(_superadmin())):
    """3.64: empresa de demostración de un tipo de negocio con `meses` de datos de ejemplo (para demos a prospectos)."""
    from . import auth, demo_tipos
    if data.tipo not in demo_tipos.PERFILES:
        raise HTTPException(400, "Tipo de negocio desconocido")
    e = crear_empresa_demo(s, nombre=(data.nombre or "").strip() or None, meses=data.meses, tipo=data.tipo)
    auth.auditar(s, "demo_creada", f"{e.nombre} ({data.tipo}, {data.meses} mes(es) de datos)", a, e.id, request)
    return {"empresa_id": e.id, "nombre": e.nombre, "tipo": data.tipo, "meses": data.meses}


class ExtenderIn(BaseModel):
    dias: int = Field(30, ge=0, le=365)      # 0 = convertir en cliente (sin vencimiento)


@router.post("/pruebas/{eid}", dependencies=[Depends(_solo_web())])
def extender_prueba(eid: int, data: ExtenderIn, request: Request, s: Session = Depends(get_session), a=Depends(_superadmin())):
    from . import auth
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if data.dias == 0:
        e.prueba_hasta = None
    else:
        base = max(ahora_cr().date(), date.fromisoformat(e.prueba_hasta)) if e.prueba_hasta else ahora_cr().date()
        e.prueba_hasta = (base + timedelta(days=data.dias)).isoformat()
    s.add(e); s.commit()
    auth.auditar(s, "prueba_extendida" if data.dias else "prueba_convertida", f"Empresa {eid}: {e.prueba_hasta or 'cliente sin vencimiento'}", a, eid, request)
    return {"ok": True, "prueba_hasta": e.prueba_hasta}


@router.delete("/pruebas/{eid}", dependencies=[Depends(_solo_web())])
def eliminar_prueba(eid: int, request: Request, s: Session = Depends(get_session), a=Depends(_superadmin())):
    """Borra una empresa demo o de prueba (base, XML, accesos). Nunca una empresa cliente: solo las marcadas como demo o con prueba.
    4.22: también su carpeta de archivos, data/empresas/<id>/ (los documentos de sus empleados y los adjuntos de otros módulos: sin la
    base ya no hay ficha ni pantalla desde donde borrarlos, y esa carpeta entra en cada respaldo general de la noche), y la de los
    respaldos que la propia empresa creó (respaldo.dir_empresa). Las dos son solo de esa empresa: la base empresa_<id>.db vive al
    lado de la primera, no adentro."""
    import shutil
    from . import auth, respaldo
    from .db import _engines, EMPRESAS_DIR
    e = s.get(Empresa, eid)
    if not e:
        raise HTTPException(404, "Empresa no encontrada")
    if not (e.es_demo or e.prueba_hasta):
        raise HTTPException(400, "Solo se eliminan empresas demo o en prueba; una empresa cliente no se borra desde aquí")
    ruta = EMPRESAS_DIR / f"empresa_{eid}.db"
    xmls = []
    if ruta.exists():
        with Session(engine_empresa(eid)) as se:
            xmls = [x for x in se.exec(select(Documento.xml_nombre)).all() if x]
    hit = _engines.pop(eid, None)
    if hit is not None:
        hit[0].dispose()
    for x in xmls:
        (XML_DIR / x).unlink(missing_ok=True)
    for suf in ("", "-wal", "-shm"):
        (EMPRESAS_DIR / f"empresa_{eid}.db{suf}").unlink(missing_ok=True)
    # 4.22: sus archivos (datos personales de terceros: cédulas, contratos, dictámenes) y sus respaldos propios se van con ella
    carpetas = (EMPRESAS_DIR / str(int(eid)), respaldo.dir_empresa(eid))

    def cuantos(carpeta):                                 # solo para decirlo en el historial: si no se puede contar, se borra igual
        try:
            return sum(1 for x in carpeta.rglob("*") if x.is_file()) if carpeta.is_dir() else 0
        except OSError:
            return 0
    archivos, respaldos = cuantos(carpetas[0]), cuantos(carpetas[1])
    for carpeta in carpetas:
        shutil.rmtree(carpeta, ignore_errors=True)
    usuarios = [m.usuario_id for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).all()]
    for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).all():
        s.delete(m)
    for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid)).all():    # 3.87: sus roles personalizados también
        s.delete(r)
    from .pedidos import liberar_direcciones
    liberar_direcciones(s, eid)          # 3.87: su nombre público, dominio y portal de TiKe quedan libres
    nombre = e.nombre
    s.delete(e); s.commit()
    # usuarios que solo tenían esta empresa (prospectos): se desactivan, no se borran (la auditoría los menciona)
    for uid in usuarios:
        u = s.get(auth.Usuario, uid)
        if u and not u.es_superadmin and not s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).first():
            u.bloqueado = True; s.add(u)
    s.commit()
    auth.auditar(s, "prueba_eliminada", f"Empresa {eid} ({nombre}): {len(xmls)} comprobantes de ejemplo borrados; también sus archivos ({archivos}: documentos de "
                 f"empleados y adjuntos) y sus respaldos propios ({respaldos})", a, None, request)
    return {"ok": True, "xml_borrados": len(xmls), "archivos_borrados": archivos, "respaldos_borrados": respaldos}
