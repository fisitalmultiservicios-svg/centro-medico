"""Factura automática del cobro del plan (3.65).

Cada pago del plan de una empresa (registrado a mano en Administración o cobrado por Tilopay) genera un comprobante desde la
empresa que factura los planes (Administración › Pagos en línea › Factura del plan: empresa facturadora, ítem con que se
factura y cuenta donde entra el dinero). Factura electrónica si la empresa cliente tiene cédula; tiquete si no. Una línea con el
ítem elegido, el nombre del plan, los meses y el período que cubre; queda pagada con un cobro; si la facturadora tiene
facturación electrónica, sale a Hacienda y al correo del cliente como cualquier otra (correo automático al aceptarse); si la
tiene apagada, es un comprobante interno y se manda por correo al momento. Un pago nunca se factura dos veces
(PagoPlan.factura_documento_id) y un fallo al facturar no impide registrar el pago (queda en PagoPlan.factura_error y el
administrador puede reintentar desde la lista de pagos).
"""
import json
import logging
import os
import types
from decimal import Decimal

from sqlmodel import Session, select

from .config import DATA_DIR, ahora_cr

log = logging.getLogger(__name__)
ARCHIVO = DATA_DIR / "factura_plan.json"


def leer_config() -> dict:
    try:
        return json.loads(ARCHIVO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def guardar_config(cfg: dict) -> dict:
    tmp = ARCHIVO.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg), encoding="utf-8")
    os.replace(tmp, ARCHIVO)
    return cfg


def configurada() -> dict | None:
    cfg = leer_config()
    return cfg if cfg.get("activo") and cfg.get("empresa_id") and cfg.get("producto_id") else None


def detalle_pago(e, p) -> str:
    from . import planes
    info = planes.info(e)
    nombre = info.get("nombre") or "Plan"
    extras = [planes.EXTRAS.get(x, {}).get("nombre", x) for x in (info.get("extras") or [])]
    desde, hasta = (p.vence_anterior or p.fecha or "")[:10], (p.vence_nuevo or "")[:10]
    txt = f"Plan {nombre} · {p.meses} mes(es)" + (f" · del {desde} al {hasta}" if desde and hasta else "")
    if extras:
        txt += " · extras: " + ", ".join(extras)
    return txt[:160]


def emitir_por_pago(sc: Session, e, p, usuario=None) -> dict | None:
    """Emite el comprobante del pago `p` de la empresa `e` desde la facturadora. None si no está configurada, si ya se facturó o si
    la facturadora es la misma empresa. `sc` es la sesión central (actualiza PagoPlan)."""
    cfg = configurada()
    if not cfg or getattr(p, "factura_documento_id", None):
        return None
    from . import main as m
    from .auth import Contexto
    from .db import Cliente, Empresa, Producto, engine_empresa
    fe = sc.get(Empresa, int(cfg["empresa_id"]))
    if fe is None or fe.id == e.id:
        return None
    with Session(engine_empresa(fe.id)) as s:
        prod = s.get(Producto, int(cfg["producto_id"]))
        if prod is None or prod.empresa_id != fe.id or not prod.activo:
            raise ValueError("El ítem configurado para facturar el plan ya no existe en la empresa facturadora")
        cli = None
        num = (e.numero_id or "").strip()
        if num:
            num = m._normalizar_identificacion(e.tipo_id or "02", num)
            cli = s.exec(select(Cliente).where(Cliente.empresa_id == fe.id, Cliente.numero_id == num)).first()
            if cli is None:
                cli = Cliente(empresa_id=fe.id, nombre=e.nombre, nombre_comercial=e.nombre_comercial, tipo="Cliente", tipo_id=e.tipo_id or "02", numero_id=num,
                              correo=(e.correo or "").strip() or None, telefono=e.telefono, provincia=e.provincia, canton=e.canton, distrito=e.distrito,
                              direccion=(e.otras_senas or "")[:160] or None, actividad=(e.actividad or None) if (e.tipo_id or "02") == "02" else None)
                s.add(cli); s.commit(); s.refresh(cli)
        tarifa = Decimal(str(prod.tarifa if prod.tarifa is not None else 13))
        moneda = (p.moneda or "CRC").upper()
        tc = Decimal("1")
        if moneda != "CRC":
            from . import tipo_cambio
            venta = (tipo_cambio.obtener() or {}).get("venta") or 0
            if not venta:
                raise ValueError("No hay tipo de cambio para facturar un pago en dólares")
            tc = Decimal(str(venta))
        total = Decimal(str(p.monto))
        precio = (total / (1 + tarifa / 100)).quantize(Decimal("0.00001"))
        medio_txt = (p.medio or "").lower() + " " + (p.referencia or "").lower()
        medio = "02" if ("tilopay" in medio_txt or "tarjeta" in medio_txt) else ("06" if "sinpe" in medio_txt else ("01" if "efectivo" in medio_txt else "04"))
        data = m.ComprobanteIn(tipo_documento="01" if cli else "04", cliente_id=cli.id if cli else None, condicion_venta="01", medio_pago=medio, moneda=moneda, tipo_cambio=tc,
                               lineas=[m.LineaIn(producto_id=prod.id, cabys=prod.cabys, detalle=detalle_pago(e, p), cantidad=Decimal(1), precio_unitario=precio,
                                                 unidad_medida=prod.unidad_medida or "Sp", es_servicio=True, codigo_tarifa=prod.codigo_tarifa or "08", tarifa=tarifa)],
                               observaciones=f"Pago del plan recibido el {(p.fecha or '')[:10]} · {p.medio or ''} {p.referencia or ''}".strip()[:200], idempotencia=f"plan:{p.id}")
        u = usuario if getattr(usuario, "id", None) is not None else types.SimpleNamespace(id=None, correo=str(usuario or "sistema"), nombre="Sistema", es_superadmin=False)
        ctx = Contexto(u, fe, "Administrador")
        doc = m.crear_comprobante(data, ctx, s)
        try:                                                     # el cobro: la factura queda pagada y, con cuenta, el dinero entra a Bancos
            m.crear_pago(m.PagoIn(tipo="caja", cliente_id=cli.id if cli else None, detalles=f"Cobro del plan · {doc.consecutivo}", fecha=(p.fecha or ahora_cr().date().isoformat())[:10],
                                  cuenta=str(cfg.get("cuenta") or ""), medio_pago=medio, moneda=moneda, tipo_cambio=float(tc), monto=float(doc.total),
                                  facturas=[{"id": doc.id, "monto": float(doc.total)}]), ctx, s)
        except Exception as ex:  # noqa: BLE001
            log.warning("Factura del plan %s emitida pero el cobro no se registró: %s", doc.consecutivo, getattr(ex, "detail", ex))
        if doc.estado == "interno" and (e.correo or "").strip():
            try:
                m._correo_comprobante(s, fe, doc, [e.correo.strip()])
            except Exception as ex:  # noqa: BLE001
                log.warning("Factura del plan %s: no se pudo enviar por correo: %s", doc.consecutivo, getattr(ex, "detail", ex))
        p.factura_empresa_id, p.factura_documento_id, p.factura_consecutivo, p.factura_error = fe.id, doc.id, doc.consecutivo, None
        sc.add(p); sc.commit()
        return {"documento_id": doc.id, "consecutivo": doc.consecutivo, "estado": doc.estado, "empresa_id": fe.id}


def facturar_pago(sc: Session, e, p, usuario=None) -> dict | None:
    """Intenta facturar y deja el error en el pago si falla (nunca rompe el registro del pago)."""
    try:
        return emitir_por_pago(sc, e, p, usuario)
    except Exception as ex:  # noqa: BLE001
        detalle = getattr(ex, "detail", None) or str(ex)
        if isinstance(detalle, dict):
            detalle = detalle.get("mensaje") or json.dumps(detalle, ensure_ascii=False)
        log.warning("No se pudo facturar el pago del plan %s de la empresa %s: %s", getattr(p, "id", "?"), getattr(e, "id", "?"), detalle)
        p.factura_error = str(detalle)[:300]
        sc.add(p); sc.commit()
        return None
