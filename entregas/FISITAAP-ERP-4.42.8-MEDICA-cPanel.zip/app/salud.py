"""Salud del sistema para la consola del administrador del sistema (3.87).

`estado(ocultas)` arma, solo leyendo, lo que hace falta para saber si la instalación está sana sin entrar al hosting ni leer el
registro del servidor: última pasada de la cola y quién la corrió, si el cron llama, si Hacienda responde, comprobantes que esperan
respuesta por empresa, el último respaldo REAL (el zip, no la marca), si la carpeta de respaldos se perdería al desplegar, cuándo
se descargó el último, tamaños de las carpetas, versión y arranque del proceso, correo de la plataforma, dirección pública, Tilopay,
buzones con error, llaves por vencer, solicitudes sin atender y las últimas advertencias del servidor. Cada fila trae su semáforo
(ok | aviso | mal | info) y qué hacer.

Reglas: nunca devuelve secretos (de cada configuración solo dice si está o no) y a los mensajes del servidor se les tapan las claves;
una empresa oculta para el administrador (3.80) no aparece en nada; una base dañada no tumba la tarjeta (un try por empresa); los
comprobantes se cuentan con COUNT.

`resumen_diario()` manda una vez al día, después de las 7:00 de Costa Rica, un correo a cada administrador del sistema con lo que pide
acción, sin las empresas que ese administrador tiene ocultas y solo con nombres y cantidades. Lo llama la cola en cada pasada.
"""
import collections
import dataclasses
import json
import logging
import os
import re
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import func
from sqlmodel import Session, select

from . import config
from .config import BASE_DIR, DATA_DIR, TZ_CR, ahora_cr

log = logging.getLogger(__name__)
INICIO = time.time()                                   # cuándo se cargó el módulo (≈ cuándo arrancó el proceso)
_arranque: dict = {"segundos": None, "listo": None}
CONFIG = DATA_DIR / "salud.json"                       # {"resumen_diario": bool}; sin archivo = encendido
MARCA_RESUMEN = DATA_DIR / "resumen_admin.ultimo"      # JSON {"fecha": AAAA-MM-DD, ...} del último resumen diario
HORA_RESUMEN = 7                                       # no antes de las 7:00 de Costa Rica
MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"
ORIGENES = {"cron": "el cron del servidor", "script": "el programa de la cola (cron o a mano)", "hilo": "el propio sistema mientras alguien lo usa",
            "consola": "un administrador desde esta consola"}
_ORDEN = {"mal": 3, "aviso": 2, "ok": 1, "info": 0}


# ----------------------------------------------------------------------------- advertencias del servidor en memoria
_SECRETO = re.compile(r"(?i)\b(password|passwd|contraseña|clave|token|secret\w*|pin|api[_-]?key|bearer|authorization)(\s*[=:]\s*|\s+(?=\S{16,}))(\S+)")
# 3.87: también la clave corta después de un espacio («password Hunter22»; no las palabras comunes: «token de…», «contraseña incorrecta»),
# la clave dentro de una dirección (smtp://usuario:clave@servidor) y los encabezados de autorización («Basic dXNl…», «Bearer …»).
# Estas advertencias se ven en la consola y van en el resumen diario por correo.
_SECRETO_CORTO = re.compile(r"(?i)\b(password|passwd|contraseña|token)(\s+)(?!(?:de|del|la|el|los|las|en|no|es|y|o|para|por|con|sin|que|of|for|is|was|not|the|and|or|to|in"
                            r"|incorrect[ao]s?|inv[aá]lid[ao]s?|invalid|incorrect|expired|vencid[ao]s?|expirad[ao]s?)\b)(?!\*\*\*)(\S+)")
_URL_CLAVE = re.compile(r"(?i)\b([a-z][a-z0-9+.-]*://[^\s:/@]+:)[^\s@]+@")
_AUTORIZACION = re.compile(r"(?i)\b(basic|bearer)(\s+)[A-Za-z0-9+/=._~-]{6,}")


def _tapar(texto: str) -> str:
    """Tapa lo que parezca una clave dentro de un mensaje (password=…, token: …, Bearer …, usuario:clave@servidor)."""
    t = _URL_CLAVE.sub(lambda m: m.group(1) + "***@", str(texto or ""))
    t = _AUTORIZACION.sub(lambda m: m.group(1) + m.group(2) + "***", t)
    t = _SECRETO.sub(lambda m: m.group(1) + m.group(2) + "***", t)
    return _SECRETO_CORTO.sub(lambda m: m.group(1) + m.group(2) + "***", t)


class _Memoria(logging.Handler):
    """Las últimas 50 advertencias o errores del proceso (la consola las muestra; no se escriben en ningún archivo)."""

    def __init__(self, n: int = 50):
        super().__init__(logging.WARNING)
        self.filas = collections.deque(maxlen=n)

    def emit(self, record):
        try:
            msg = record.getMessage()
        except Exception:  # noqa: BLE001
            msg = str(record.msg)
        ex = record.exc_info[1] if record.exc_info else None
        if ex is not None:
            msg += f" ({type(ex).__name__}: {str(ex)[:200]})"
        self.filas.append({"hora": datetime.fromtimestamp(record.created, TZ_CR).isoformat(timespec="seconds"), "nivel": record.levelname,
                           "origen": record.name, "mensaje": _tapar(msg)[:400]})


_memoria = _Memoria()


def instalar_registro() -> None:
    """Lo llama main.arranque(). Si el proceso no tenía manejadores de registro, Python escribía las advertencias en stderr: se
    conserva con un manejador igual, porque al haber uno (este) Python deja de usar el de último recurso."""
    raiz = logging.getLogger()
    if _memoria in raiz.handlers:
        return
    if not raiz.handlers:
        h = logging.StreamHandler()
        h.setLevel(logging.WARNING)
        raiz.addHandler(h)
    raiz.addHandler(_memoria)
    uv = logging.getLogger("uvicorn.error")              # errores 500 sin atrapar (uvicorn no los pasa a la raíz)
    if _memoria not in uv.handlers:
        uv.addHandler(_memoria)


def marcar_arranque(segundos: float) -> None:
    _arranque.update(segundos=round(float(segundos), 1), listo=ahora_cr().isoformat(timespec="seconds"))


# ----------------------------------------------------------------------------- configuración (interruptor del resumen)
def leer_config() -> dict:
    try:
        d = json.loads(CONFIG.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def resumen_activo() -> bool:
    return leer_config().get("resumen_diario", True) is not False


def guardar_config(cambios: dict) -> dict:
    d = {**leer_config(), **cambios}
    tmp = CONFIG.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, CONFIG)
    return d


def ultimo_resumen() -> dict | None:
    try:
        d = json.loads(MARCA_RESUMEN.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


# ----------------------------------------------------------------------------- utilidades
def _dt(v) -> datetime | None:
    """ISO (con o sin zona; sin zona = UTC, como guarda la base) o datetime → datetime con zona."""
    if v is None:
        return None
    if isinstance(v, datetime):
        d = v
    else:
        try:
            d = datetime.fromisoformat(str(v).strip().replace("Z", "+00:00"))
        except ValueError:
            try:
                d = datetime.fromisoformat(str(v)[:10])
            except ValueError:
                return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _hace(d: datetime | None, ahora: datetime | None = None) -> str:
    if d is None:
        return "nunca"
    seg = max(0, ((ahora or ahora_cr()) - d).total_seconds())
    if seg < 90:
        return "hace un momento"
    if seg < 5400:
        return f"hace {round(seg / 60)} min"
    if seg < 172800:
        return f"hace {round(seg / 3600)} h"
    return f"hace {round(seg / 86400)} días"


def historial_hacienda(amb: str, dias: int = 7, ahora: datetime | None = None) -> dict:
    """3.87: resumen del historial de verificaciones de Hacienda (cola.HISTORIAL_FILE): % de respuestas, las de 24 h, el tiempo típico
    y las caídas (fallas seguidas, desde la primera hasta la siguiente respuesta)."""
    from . import cola
    ahora = ahora or datetime.now(timezone.utc)
    filas = cola.leer_historial(amb, ahora - timedelta(days=dias))
    if not filas:
        return {"estado": "info", "valor": "Sin datos todavía: se anota en cada pasada de la cola (cada 5 minutos con el cron)", "accion": "",
                "revisiones": 0, "caidas": 0}
    n, ok = len(filas), sum(1 for f in filas if f.get("ok"))
    dia = [f for f in filas if (_dt(f.get("t")) or ahora) >= ahora - timedelta(hours=24)]
    pct = 100 * ok / n
    caidas, actual = [], None
    for f in filas:
        if not f.get("ok"):
            if actual is None:
                actual = {"desde": _dt(f.get("t")), "hasta": None, "detalle": f.get("det") or "", "fallas": 0}
            actual["fallas"] += 1
        elif actual is not None:
            actual["hasta"] = _dt(f.get("t"))
            caidas.append(actual)
            actual = None
    if actual is not None:
        caidas.append(actual)
    tiempos = sorted(int(f.get("ms") or 0) for f in filas if f.get("ok"))
    tipico = tiempos[len(tiempos) // 2] / 1000 if tiempos else None

    def _h(d):
        return d.astimezone(TZ_CR).strftime("%d/%m %H:%M") if d else "?"

    def _pct(x):
        return f"{x:.1f} %".replace(".", ",")
    partes = [f"Respondió en {ok} de {n} revisiones ({_pct(pct)})"]
    if dia:
        partes.append("últimas 24 h: " + _pct(100 * sum(1 for f in dia if f.get("ok")) / len(dia)))
    if tipico is not None:
        partes.append(f"respuesta típica {tipico:.1f} s".replace(".", ","))
    if caidas:
        partes.append(f"{len(caidas)} caída(s)")
    textos = []
    for c in caidas[-5:][::-1]:
        if c["hasta"] is None:
            fin = "sigue sin responder"
        else:
            fin = f"a {_h(c['hasta'])} ({max(1, round((c['hasta'] - c['desde']).total_seconds() / 60))} min)"
        textos.append(f"{_h(c['desde'])} {fin}: {c['detalle'][:90]}")
    en_caida = bool(caidas) and caidas[-1]["hasta"] is None
    est = "mal" if en_caida or pct < 95 else "aviso" if caidas else "ok"
    accion = ("Caídas, hora de Costa Rica (las 5 más recientes): " + " · ".join(textos)) if textos else "Sin caídas en este periodo."
    return {"estado": est, "valor": " · ".join(partes), "accion": accion, "revisiones": n, "caidas": len(caidas)}


def _tam(b: int) -> str:
    if b >= 1024 ** 3:
        return f"{b / 1024 ** 3:.1f} GB".replace(".", ",")
    if b >= 1024 ** 2:
        return f"{b / 1024 ** 2:.1f} MB".replace(".", ",")
    return f"{max(1, round(b / 1024)) if b else 0} KB"


_tamanos: dict = {}


def _tamano(carpeta) -> tuple[int, int]:
    """(bytes, archivos) de una carpeta; se calcula a lo sumo cada 10 minutos (data/ puede tener miles de XML)."""
    clave = str(carpeta)
    hit = _tamanos.get(clave)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    total = n = 0
    for raiz, _, archivos in os.walk(carpeta):
        for a in archivos:
            try:
                total += os.path.getsize(os.path.join(raiz, a)); n += 1
            except OSError:
                pass
    _tamanos[clave] = (time.time(), (total, n))
    return total, n


def _nombre(e) -> str:
    return e.nombre_comercial or e.nombre or f"Empresa {e.id}"


def _menciona_oculta(texto: str, ocultas: set, nombres: set) -> bool:
    """¿El texto habla de una empresa oculta? («empresa 4», «empresa_4.db» o su nombre)."""
    t = str(texto or "")
    for m in re.finditer(r"(?i)empresa\D{0,4}(\d+)", t):
        if int(m.group(1)) in ocultas:
            return True
    return any(n and len(n) >= 4 and n in t for n in nombres)


def _nombres_de(empresas) -> set:
    return {x for e in empresas for x in (e.nombre, e.nombre_comercial) if x}


def advertencias(ocultas: set = frozenset(), nombres: set = frozenset()) -> list[dict]:
    """Las últimas advertencias del proceso, la más reciente primero, sin las que hablan de empresas ocultas."""
    return [x for x in reversed(list(_memoria.filas)) if not (ocultas and _menciona_oculta(x["mensaje"], ocultas, nombres))]


def guia_cron(base_url: str = "") -> dict:
    """Lo que hace falta para crear el cron en el hosting. El token nunca se muestra: va como AQUI_EL_TOKEN."""
    from . import cola
    base = (config.URL_PUBLICA or base_url or "").rstrip("/")
    url = (base or "https://SU-DOMINIO") + "/api/cola/procesar"
    registro = str(DATA_DIR / "cola.log")
    return {"token_definido": bool(config.CRON_TOKEN), "url": url, "log": registro, "frecuencia": "Cada 5 minutos (*/5 * * * *)",
            "comando": f'curl -s -m 280 -X POST -H "X-Cron-Token: AQUI_EL_TOKEN" {url} >> {registro} 2>&1',
            "ultimo_cron": cola.ultimo_cron(), "ultima_pasada": cola.ultima_pasada(), "en_curso": cola.en_curso()}


# ----------------------------------------------------------------------------- estado
def _atascados(empresas, ahora: datetime) -> list[dict]:
    """Por empresa: comprobantes firmados (sin enviar), enviados (sin respuesta) y con error, con el más viejo. Con COUNT y un try
    por empresa; no crea la base de una empresa que todavía no la tiene."""
    from .db import EMPRESAS_DIR, Documento, engine_empresa
    out = []
    for e in empresas:
        if e.es_demo or e.bloqueada or not (EMPRESAS_DIR / f"empresa_{e.id}.db").exists():
            continue
        try:
            with Session(engine_empresa(e.id)) as se:
                filas = se.exec(select(Documento.estado, func.count(Documento.id), func.min(Documento.fecha_emision))
                                .where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente, Documento.importado_de == None,  # noqa: E711
                                       Documento.estado.in_(("firmado", "enviado", "error")))
                                .group_by(Documento.estado)).all()
        except Exception as ex:  # noqa: BLE001  base dañada o vieja: se informa y se sigue con las demás
            out.append({"empresa_id": e.id, "empresa": _nombre(e), "ambiente": e.ambiente, "firmado": 0, "enviado": 0, "error": 0,
                        "mas_viejo": None, "horas": None, "falla": f"No se pudo leer la base ({type(ex).__name__})"})
            continue
        if not filas:
            continue
        c = {est: (n, viejo) for est, n, viejo in filas}
        viejos = [_dt(v) for est, (n, v) in c.items() if est in ("firmado", "enviado") and v]
        viejos = [v for v in viejos if v]
        mas_viejo = min(viejos) if viejos else None
        out.append({"empresa_id": e.id, "empresa": _nombre(e), "ambiente": e.ambiente, "firmado": c.get("firmado", (0, None))[0],
                    "enviado": c.get("enviado", (0, None))[0], "error": c.get("error", (0, None))[0],
                    "mas_viejo": mas_viejo.isoformat(timespec="seconds") if mas_viejo else None,
                    "horas": round((ahora - mas_viejo).total_seconds() / 3600, 1) if mas_viejo else None})
    return sorted(out, key=lambda x: -(x["horas"] or 0))


def estado(ocultas=None, base_url: str = "") -> dict:
    """Todo lo de la tarjeta «Salud del sistema». `ocultas`: empresas que este administrador no ve (3.80)."""
    from . import cola, respaldo, version
    from .db import Empresa, engine
    ocultas = set(ocultas or ())
    limitado = bool(ocultas)
    ahora = ahora_cr()
    filas: list[dict] = []

    def fila(clave, titulo, est, valor, accion=""):
        filas.append({"clave": clave, "titulo": titulo, "estado": est, "valor": valor, "accion": accion})

    with Session(engine) as s:
        todas = s.exec(select(Empresa).order_by(Empresa.id)).all()
        empresas = [e for e in todas if e.id not in ocultas]
        nombres_ocultos = _nombres_de([e for e in todas if e.id in ocultas])
        limitado = bool(ocultas & {e.id for e in todas})   # 3.87: el id de una empresa ya eliminada no limita (la lista no se depura)

        # ---- cola y cron
        ult = cola.ultima_pasada()
        hora = _dt((ult or {}).get("hora"))
        if hora is None:
            fila("cola", "Cola de Hacienda", "mal", "Nunca ha corrido en esta instalación",
                 "Cree el cron (abajo) o toque «Procesar ahora». Sin la cola, los comprobantes que quedaron sin enviar no se reintentan.")
        else:
            minutos = (ahora - hora).total_seconds() / 60
            quien = ORIGENES.get((ult or {}).get("origen"), "")
            detalle = f"Última pasada {_hace(hora, ahora)}" + (f", la corrió {quien}" if quien else "")
            if ult.get("duracion_ms") is not None:
                detalle += f" ({ult['duracion_ms'] / 1000:.1f} s)".replace(".", ",")
            if ult.get("omitido"):
                detalle += " · " + str(ult["omitido"])
            fila("cola", "Cola de Hacienda", "mal" if minutos > 120 else "aviso" if minutos > 30 else "ok", detalle,
                 "" if minutos <= 30 else "La cola solo corre si el cron llama o si alguien usa el sistema: revise el cron y toque «Procesar ahora».")
        cron = cola.ultimo_cron()
        hcron = _dt((cron or {}).get("hora"))
        if MODO_LOCAL:
            fila("cron", "Cron del servidor", "info", "No aplica en la instalación local")
        elif hcron is None:
            fila("cron", "Cron del servidor", "aviso", "El cron nunca ha llamado: la cola solo corre mientras alguien usa el sistema",
                 "Créelo en el hosting (Cron Jobs) cada 5 minutos con el comando de abajo. También mantiene despierto al servidor.")
        else:
            m = (ahora - hcron).total_seconds() / 60
            fila("cron", "Cron del servidor", "aviso" if m > 20 else "ok", f"Llamó por última vez {_hace(hcron, ahora)}",
                 "" if m <= 20 else "Revise que el Cron Job siga creado en el hosting y que su comando no dé error.")
        if not MODO_LOCAL:
            fila("cron_token", "Clave del cron (FE_CRON_TOKEN)", "ok" if config.CRON_TOKEN else "aviso",
                 "Definida" if config.CRON_TOKEN else "Sin definir: el cron con curl recibe un error 503",
                 "" if config.CRON_TOKEN else "Defínala en las variables de la aplicación y reinicie.")

        # ---- Hacienda por ambiente
        archivo = cola._leer_estado_archivo()
        usados = {e.ambiente for e in empresas if e.usuario_hacienda and not e.es_demo}
        for amb, etiqueta in (("produccion", "Hacienda · producción"), ("sandbox", "Hacienda · pruebas")):
            if amb not in usados and amb not in archivo:
                continue
            g = archivo.get(amb) or {}
            ver = _dt(g.get("verificado"))
            if g.get("disponible") is True:
                fila(f"hacienda_{amb}", etiqueta, "ok", f"Responde (verificado {_hace(ver, ahora)})")
            elif g.get("disponible") is False:
                fila(f"hacienda_{amb}", etiqueta, "mal", f"No responde (verificado {_hace(ver, ahora)}): {str(g.get('detalle') or '')[:140]}",
                     "Los comprobantes quedan en cola y se envían solos cuando Hacienda vuelva.")
            else:
                fila(f"hacienda_{amb}", etiqueta, "info", "Sin verificar todavía (se verifica en cada pasada de la cola)")
            h = historial_hacienda(amb)                           # 3.87: cómo ha estado Hacienda los últimos 7 días
            fila(f"hacienda_hist_{amb}", f"{etiqueta} · últimos 7 días", h["estado"], h["valor"], h["accion"])

        # ---- comprobantes sin respuesta
        atascados = _atascados(empresas, ahora)
        pend = sum(x["firmado"] + x["enviado"] for x in atascados)
        errores = sum(x["error"] for x in atascados)
        horas = max([x["horas"] or 0 for x in atascados if x["firmado"] + x["enviado"]] or [0])
        if not atascados:
            fila("atascados", "Comprobantes sin respuesta de Hacienda", "ok", "Ninguno")
        else:
            partes = []
            if pend:
                partes.append(f"{pend} esperando en {len([x for x in atascados if x['firmado'] + x['enviado']])} empresa(s), el más viejo de hace {horas:.0f} h")
            if errores:
                partes.append(f"{errores} con error de Hacienda (no se reintentan solos)")
            if any(x.get("falla") for x in atascados):
                partes.append("alguna base no se pudo leer")
            fila("atascados", "Comprobantes sin respuesta de Hacienda", "mal" if horas >= 24 else "aviso" if (horas >= 1 or errores) else "ok",
                 "; ".join(partes) or "Ninguno",
                 "Revise la lista de abajo: si Hacienda responde y siguen ahí, entre a la empresa y abra el comprobante." if (horas >= 1 or errores) else "")

        # ---- respaldos
        carpeta = str(respaldo.RESPALDOS_DIR)
        lista = respaldo.listar() if not limitado else []
        ultimo = lista[0] if lista else None
        if limitado:
            fila("respaldo", "Respaldo general", "info", "Incluye todas las empresas: lo maneja el super administrador")
        elif not ultimo:
            fila("respaldo", "Respaldo general", "mal", f"No hay ningún respaldo en {carpeta}",
                 "Toque «Crear respaldo ahora» en la tarjeta de respaldos. El diario lo hace la cola: revise también el cron.")
        else:
            f = _dt(ultimo["fecha"])
            h = (ahora - f).total_seconds() / 3600 if f else 999
            fila("respaldo", "Respaldo general", "aviso" if h > 30 else "ok", f"{ultimo['nombre']} · {_tam(ultimo['bytes'])} · {_hace(f, ahora)}",
                 "El respaldo diario no está corriendo: revise el cron." if h > 30 else "")
        if not respaldo.ubicacion_segura():
            fila("respaldo_carpeta", "Carpeta de respaldos", "mal", f"{carpeta} está dentro de la carpeta de la aplicación: al reemplazarla en un despliegue los respaldos se pierden",
                 f"Defina FE_RESPALDOS_DIR={respaldo.carpeta_sugerida()} (fuera de la aplicación), reinicie y copie allí los respaldos que ya tiene.")
        else:
            fila("respaldo_carpeta", "Carpeta de respaldos", "ok", f"{carpeta} (fuera de la aplicación)")
        if not limitado:
            desc = respaldo.ultima_descarga()
            fd = _dt((desc or {}).get("fecha"))
            dias = (ahora - fd).days if fd else None
            fila("respaldo_descarga", "Copia fuera del servidor", "aviso" if dias is None or dias > 7 else "ok",
                 f"Último respaldo general descargado {_hace(fd, ahora)}" if fd else "Nunca se ha descargado un respaldo general",
                 "Descargue el más reciente y guárdelo fuera del servidor: un respaldo que solo está aquí no sirve si se pierde la cuenta del hosting."
                 if dias is None or dias > 7 else "")
        bd, nd = _tamano(DATA_DIR)
        br, nr = _tamano(respaldo.RESPALDOS_DIR) if respaldo.RESPALDOS_DIR.is_dir() else (0, 0)
        fila("espacio", "Tamaño de los datos", "info", f"Datos: {_tam(bd)} ({nd} archivos) · Respaldos: {_tam(br)} ({nr} archivos)",
             "El espacio libre real lo da la cuota del hosting.")

        # ---- versión y proceso
        v = version.actual()
        inicio = datetime.fromtimestamp(INICIO, TZ_CR)
        if version.falta_reiniciar():                     # 4.2: se subieron los archivos pero el programa en marcha es el anterior
            fila("reinicio", "Reinicio pendiente", "mal", f"Los archivos son de la versión {v.get('version')}, pero el sistema sigue corriendo la {version.EN_EJECUCION}",
                 "Reinicie la aplicación en el hosting (Setup Python App › Restart). Hasta entonces las opciones nuevas no responden y siguen los errores ya corregidos.")
        fila("version", "Versión y proceso", "info", f"Versión {version.EN_EJECUCION} en marcha · proceso desde {inicio:%d/%m %H:%M} ({_hace(inicio, ahora)})"
             + (f" · el arranque tardó {_arranque['segundos']:.1f} s".replace(".", ",") if _arranque.get("segundos") is not None else ""))

        # ---- correo y dirección pública
        try:
            from . import sitio
            cfg_sitio = sitio.leer()
            smtp = sitio._smtp(s, cfg_sitio)
        except Exception:  # noqa: BLE001
            cfg_sitio, smtp = {}, None
        if smtp is None:
            fila("correo", "Correo de la plataforma", "aviso", "Sin configurar: no salen los avisos de solicitudes, de planes ni el resumen diario",
                 "Defina el correo de la plataforma (FE_SMTP_*) o elija en Sitio web › Contacto la empresa que envía los avisos.")
        elif (os.getenv("FE_SMTP_HOST") or "").strip():
            fila("correo", "Correo de la plataforma", "ok", "Configurado en las variables del servidor")
        else:
            eid = (cfg_sitio.get("contacto") or {}).get("correo_empresa_id")
            emp = next((e for e in empresas if e.id == eid), None)
            fila("correo", "Correo de la plataforma", "ok", f"Usa el correo de {_nombre(emp)}" if emp else "Usa el correo de una empresa")
        prod = os.getenv("FE_ENTORNO", "").lower() in ("produccion", "production", "prod")
        if config.URL_PUBLICA:
            fila("url", "Dirección pública (FE_URL_PUBLICA)", "ok", config.URL_PUBLICA)
        else:
            fila("url", "Dirección pública (FE_URL_PUBLICA)", "aviso" if prod else "info", "Sin definir: los correos no llevan el enlace de consulta y Tilopay no puede avisar los cobros",
                 "Defínala con la dirección https del sistema y reinicie." if prod else "")

        # ---- Tilopay (solo si está en prueba o en real; nunca la llave)
        try:
            from . import suscripcion
            p = suscripcion._resumen_config()
            if p.get("activo") and p.get("modo_prueba"):
                fila("tilopay", "Cobro con tarjeta (Tilopay)", "aviso", "Activo en MODO DE PRUEBA: los cobros no son reales",
                     "Cuando la cuenta de Tilopay pase a real, apague «modo de prueba» en Pagos en línea.")
            elif p.get("activo"):
                fila("tilopay", "Cobro con tarjeta (Tilopay)", "ok", "Activo, cobrando de verdad")
            else:
                fila("tilopay", "Cobro con tarjeta (Tilopay)", "info", "Apagado")
        except Exception:  # noqa: BLE001
            pass

        # ---- buzones y llaves
        buzones = [{"empresa_id": e.id, "empresa": _nombre(e), "error": str(e.imap_error)[:160], "desde": getattr(e, "imap_intento", None)}
                   for e in empresas if e.imap_host and e.imap_error and not e.bloqueada]
        con_buzon = [e for e in empresas if e.imap_host and not e.bloqueada]
        if buzones:
            fila("buzones", "Buzones de comprobantes recibidos", "aviso", f"{len(buzones)} con error de {len(con_buzon)}",
                 "Revise el servidor, el usuario y la contraseña del buzón en la configuración de recepción de cada empresa.")
        else:
            fila("buzones", "Buzones de comprobantes recibidos", "ok" if con_buzon else "info", f"Sin errores ({len(con_buzon)} buzón(es))" if con_buzon else "Ninguna empresa tiene buzón")
        hoy = ahora.date()
        llaves = []
        for e in empresas:
            if not (e.p12_nombre and e.p12_vence) or e.es_demo:
                continue
            fv = _dt(e.p12_vence)
            if fv is None:
                continue
            d = (fv.astimezone(TZ_CR).date() - hoy).days
            if d <= 30:
                llaves.append({"empresa_id": e.id, "empresa": _nombre(e), "vence": str(e.p12_vence)[:10], "dias": d})
        llaves.sort(key=lambda x: x["dias"])
        if llaves:
            fila("llaves", "Llaves criptográficas (.p12)", "mal" if any(x["dias"] < 0 for x in llaves) else "aviso",
                 f"{len([x for x in llaves if x['dias'] < 0])} vencida(s) y {len([x for x in llaves if x['dias'] >= 0])} por vencer en 30 días",
                 "Cada empresa la renueva en Hacienda y la sube en Configuración › Facturación electrónica; sin ella no se firma.")
        else:
            fila("llaves", "Llaves criptográficas (.p12)", "ok", "Ninguna vence en los próximos 30 días")

        # ---- solicitudes del sitio
        try:
            from .sitio import SolicitudContacto
            sols = [x for x in s.exec(select(SolicitudContacto).where(SolicitudContacto.atendida == False)).all()  # noqa: E712
                    if not (x.empresa_id and x.empresa_id in ocultas)]
            vieja = min((_dt(x.creado) for x in sols if x.creado), default=None)
            fila("solicitudes", "Solicitudes del sitio sin atender", "aviso" if sols else "ok",
                 f"{len(sols)} sin atender (la más vieja {_hace(vieja, ahora)})" if sols else "Ninguna",
                 "Atiéndalas en la pestaña Solicitudes de contacto." if sols else "")
        except Exception:  # noqa: BLE001
            pass

    # ---- advertencias del servidor
    adv = advertencias(ocultas, nombres_ocultos)
    dia = [x for x in adv if (_dt(x["hora"]) or ahora) >= ahora - timedelta(hours=24)]
    n_err = len([x for x in dia if x["nivel"] in ("ERROR", "CRITICAL")])
    fila("advertencias", "Advertencias del servidor", "aviso" if n_err else "ok",
         f"{n_err} error(es) y {len(dia) - n_err} advertencia(s) en las últimas 24 h" if dia else "Ninguna desde que arrancó el proceso",
         "Revise el detalle abajo (solo las de este proceso; el registro completo está en el hosting)." if n_err else "")

    # ---- resumen diario
    ur = ultimo_resumen()
    if not resumen_activo():
        fila("resumen", "Resumen diario por correo", "info", "Apagado")
    elif ur and ur.get("fecha"):
        fila("resumen", "Resumen diario por correo", "aviso" if ur.get("errores") and not ur.get("enviados") else "ok",
             f"Último: {ur['fecha'][8:10]}/{ur['fecha'][5:7]} a las {str(ur.get('hora') or '')[11:16]}, enviado a {ur.get('enviados', 0)} de {ur.get('destinatarios', 0)} administrador(es)"
             + (f" · error: {str(ur['errores'][0])[:120]}" if ur.get("errores") else ""))
    else:
        fila("resumen", "Resumen diario por correo", "info", f"Encendido: el primero sale en la primera pasada de la cola después de las {HORA_RESUMEN}:00")

    peor = max((_ORDEN.get(f["estado"], 0) for f in filas), default=0)
    n_mal = len([f for f in filas if f["estado"] == "mal"]); n_aviso = len([f for f in filas if f["estado"] == "aviso"])
    resumen = "Todo en orden" if not (n_mal or n_aviso) else ", ".join(x for x in (f"{n_mal} problema(s)" if n_mal else "", f"{n_aviso} aviso(s)" if n_aviso else "") if x)
    ult_publica = dict(ult or {})
    if limitado:                                            # los totales de la pasada incluyen a las empresas que no ve
        for k in ("empresas", "enviados", "aceptados", "rechazados", "errores"):
            ult_publica.pop(k, None)
    guia = guia_cron(base_url)
    guia["ultima_pasada"] = ult_publica or None
    return {"generado": ahora.isoformat(timespec="seconds"), "semaforo": {3: "mal", 2: "aviso"}.get(peor, "ok"), "resumen": resumen, "limitado": limitado,
            "filas": filas, "atascados": atascados, "buzones": buzones, "llaves": llaves, "advertencias": adv[:20], "cron": guia,
            "resumen_diario": {"activo": resumen_activo(), "ultimo": ur, "hora": HORA_RESUMEN}}


# ----------------------------------------------------------------------------- resumen diario por correo
def _lineas_resumen(ocultas: set, ahora: datetime) -> list[tuple[str, list[str]]]:
    """Secciones del resumen para un administrador: [(título, [líneas])]. Solo nombres y cantidades."""
    from . import auth, planes
    from .db import EMPRESAS_DIR, Documento, Empresa, engine, engine_empresa
    hoy = ahora.date()
    ayer = (hoy - timedelta(days=1)).isoformat()
    sec: dict[str, list[str]] = collections.OrderedDict((k, []) for k in (
        "Pruebas gratis por vencer o vencidas sin plan", "Planes que vencen en 7 días", "Solicitudes del sitio sin atender",
        "Empresas donde nadie entra hace 14 días", "Comprobantes rechazados ayer", "Llaves .p12 que vencen en 30 días",
        "Empleados por encima del plan", "Errores del servidor de ayer"))
    with Session(engine) as s:
        empresas = [e for e in s.exec(select(Empresa).order_by(Empresa.id)).all() if e.id not in ocultas]
        nombres_ocultos = _nombres_de([e for e in s.exec(select(Empresa)).all() if e.id in ocultas])
        # último ingreso de los usuarios de cada empresa (sin los administradores del sistema)
        ultimo: dict[int, datetime] = {}
        for m, u in s.exec(select(auth.UsuarioEmpresa, auth.Usuario).where(auth.UsuarioEmpresa.usuario_id == auth.Usuario.id,
                                                                          auth.Usuario.es_superadmin == False)).all():  # noqa: E712
            d = _dt(u.ultimo_acceso)
            if d and (m.empresa_id not in ultimo or d > ultimo[m.empresa_id]):
                ultimo[m.empresa_id] = d
        for e in empresas:
            n = _nombre(e)
            if e.prueba_hasta and not e.bloqueada:
                try:
                    d = (datetime.fromisoformat(str(e.prueba_hasta)[:10]).date() - hoy).days
                except ValueError:
                    d = None
                if d is not None and 0 <= d <= 3:
                    sec["Pruebas gratis por vencer o vencidas sin plan"].append(f"{n}: la prueba vence {'hoy' if d == 0 else f'en {d} día(s)'}")
                elif d is not None and -14 <= d < 0 and not e.plan:
                    sec["Pruebas gratis por vencer o vencidas sin plan"].append(f"{n}: la prueba venció hace {-d} día(s) y no tiene plan")
            if e.plan and e.vence and not e.es_demo and not e.bloqueada:
                try:
                    d = (datetime.fromisoformat(str(e.vence)[:10]).date() - hoy).days
                except ValueError:
                    d = None
                if d is not None and 0 <= d <= 7:
                    p = planes.plan_de(e) or {}
                    sec["Planes que vencen en 7 días"].append(f"{n}: {p.get('nombre') or e.plan} vence el {str(e.vence)[8:10]}/{str(e.vence)[5:7]} ({'hoy' if d == 0 else f'en {d} día(s)'})")
            if not e.bloqueada and not e.es_demo:
                u = ultimo.get(e.id)
                creada = _dt(e.creada)
                if u is None and creada and (ahora - creada).days >= 14:
                    sec["Empresas donde nadie entra hace 14 días"].append(f"{n}: nadie ha entrado desde que se creó")
                elif u is not None and (ahora - u).days >= 14:
                    sec["Empresas donde nadie entra hace 14 días"].append(f"{n}: último ingreso hace {(ahora - u).days} días")
            if e.p12_nombre and e.p12_vence and not e.es_demo:
                fv = _dt(e.p12_vence)
                if fv is not None:
                    d = (fv.astimezone(TZ_CR).date() - hoy).days
                    if d <= 30:
                        sec["Llaves .p12 que vencen en 30 días"].append(f"{n}: " + (f"venció hace {-d} día(s)" if d < 0 else f"vence en {d} día(s)"))
            if (EMPRESAS_DIR / f"empresa_{e.id}.db").exists() and not e.es_demo:
                try:
                    with Session(engine_empresa(e.id)) as se:
                        rech = se.exec(select(func.count(Documento.id)).where(
                            Documento.empresa_id == e.id, Documento.estado == "rechazado", Documento.importado_de == None,  # noqa: E711
                            func.coalesce(func.substr(Documento.fecha_envio, 1, 10), func.substr(Documento.fecha_emision, 1, 10)) == ayer)).one()
                        if rech:
                            sec["Comprobantes rechazados ayer"].append(f"{n}: {rech}")
                        emp = planes.empleados_plan(e, se)
                        if emp and emp.get("excedente"):
                            sec["Empleados por encima del plan"].append(f"{n}: {emp['activos']} de {emp['incluidos']} incluidos (+{emp['excedente']})")
                except Exception:  # noqa: BLE001  una base dañada no frena el resumen
                    pass
        try:
            from .sitio import SolicitudContacto
            sols = [x for x in s.exec(select(SolicitudContacto).where(SolicitudContacto.atendida == False).order_by(SolicitudContacto.creado)).all()  # noqa: E712
                    if not (x.empresa_id and x.empresa_id in ocultas)]
            sec["Solicitudes del sitio sin atender"] = [f"{x.nombre}" + (f" ({x.empresa})" if x.empresa else "") for x in sols]
        except Exception:  # noqa: BLE001
            pass
    errs = [x for x in advertencias(ocultas, nombres_ocultos) if x["nivel"] in ("ERROR", "CRITICAL") and str(x["hora"])[:10] == ayer]
    sec["Errores del servidor de ayer"] = [x["mensaje"][:160] for x in errs]
    return [(k, v) for k, v in sec.items()]


def armar_resumen(u, ahora: datetime | None = None, base_url: str = "") -> tuple[str, str, str]:
    """(asunto, html, texto) del resumen diario para el administrador `u` (sin sus empresas ocultas)."""
    from . import auth, correo_diseno as _dz
    from .config import nombre_sistema
    ahora = ahora or ahora_cr()
    ocultas = auth.empresas_ocultas_de(u)
    est = estado(ocultas, base_url)
    claves = ("cola", "cron", "respaldo", "respaldo_carpeta", "respaldo_descarga", "hacienda_produccion", "hacienda_sandbox", "atascados", "correo", "llaves")
    malas = [f for f in est["filas"] if f["clave"] in claves and f["estado"] in ("mal", "aviso")]
    secciones = [(t, ls) for t, ls in _lineas_resumen(ocultas, ahora) if ls]
    pendientes = sum(len(ls) for _, ls in secciones)
    salud_txt = "Todo en orden" if not malas else "; ".join(f"{f['titulo']}: {f['valor']}" for f in malas[:6])
    asunto = f"Resumen del {ahora:%d/%m/%Y} · {nombre_sistema()}" + (f" · {pendientes} pendiente(s)" if pendientes else "")
    datos = [("Salud del sistema", ("✓ " if not malas else "⚠ ") + salud_txt)] + [(t, str(len(ls))) for t, ls in secciones]
    parrafos = [f"**{t}**\n" + "\n".join("• " + x for x in ls[:15]) + (f"\n… y {len(ls) - 15} más" if len(ls) > 15 else "") for t, ls in secciones]
    if not secciones:
        parrafos = ["Nada pide acción hoy."]
    url = (config.URL_PUBLICA or base_url or "").rstrip("/")
    html = _dz.armar(_dz.plataforma(), titulo=f"Resumen diario del {ahora:%d/%m/%Y}", asunto=asunto, antetitulo="Administración del sistema",
                     preencabezado=salud_txt[:120], saludo=f"Hola, {getattr(u, 'nombre', '') or 'administrador'}.", datos=datos, parrafos_txt=parrafos,
                     boton_=("Abrir la consola", url + "/app/#/admin") if url else None,
                     nota="Lo recibe porque es administrador del sistema. Se apaga en Administración › Salud.")
    texto = (f"Resumen diario del {ahora:%d/%m/%Y}\n\nSalud del sistema: {salud_txt}\n\n"
             + "\n\n".join(p.replace("**", "") for p in parrafos) + (f"\n\nConsola: {url}/app/#/admin" if url else ""))
    return asunto, html, texto


def resumen_diario(enviar=None, ahora: datetime | None = None, forzar: bool = False) -> dict:
    """Una vez al día, después de las 7:00 de Costa Rica: un correo a cada administrador del sistema activo, cada uno sin sus empresas
    ocultas. `enviar(smtp, [correo], asunto, html, texto)` permite simularlo en pruebas (nunca se configura un correo real)."""
    from . import auth, correo, sitio
    from .db import engine
    ahora = ahora or ahora_cr()
    hoy = ahora.date().isoformat()
    if MODO_LOCAL:
        return {"omitido": "instalación local"}
    if not forzar:
        if not resumen_activo():
            return {"omitido": "apagado"}
        if ahora.hour < HORA_RESUMEN:
            return {"omitido": f"antes de las {HORA_RESUMEN}:00"}
        if (ultimo_resumen() or {}).get("fecha") == hoy:
            return {"omitido": "ya se envió hoy"}
    with Session(engine) as s:
        smtp = sitio._smtp(s, sitio.leer())
        if smtp is None:
            return {"omitido": "sin correo de la plataforma"}
        if dataclasses.is_dataclass(smtp):
            smtp = dataclasses.replace(smtp, copia=None, responder_a=None)   # nunca con copia al buzón de una empresa
        admins = s.exec(select(auth.Usuario).where(auth.Usuario.es_superadmin == True, auth.Usuario.bloqueado == False)).all()  # noqa: E712
        admins = [a for a in admins if a.correo and "@" in a.correo]
        for a in admins:
            s.expunge(a)
    if not admins:
        return {"omitido": "sin administradores"}
    marca = {"fecha": hoy, "hora": ahora.isoformat(timespec="seconds"), "destinatarios": len(admins), "enviados": 0, "errores": []}
    try:
        MARCA_RESUMEN.write_text(json.dumps(marca, ensure_ascii=False), encoding="utf-8")      # se toma el día antes de enviar
    except OSError:
        pass
    enviar = enviar or (lambda cfg, para, asunto, html, texto: correo.enviar(cfg, para, asunto, html, texto, []))
    for a in admins:
        try:
            asunto, html, texto = armar_resumen(a, ahora)
            enviar(smtp, [a.correo], asunto, html, texto)
            marca["enviados"] += 1
        except Exception as ex:  # noqa: BLE001
            marca["errores"].append(str(ex)[:200])
            log.warning("Resumen diario: no se pudo enviar a un administrador: %s", str(ex)[:200])
    try:
        MARCA_RESUMEN.write_text(json.dumps(marca, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass
    return marca
