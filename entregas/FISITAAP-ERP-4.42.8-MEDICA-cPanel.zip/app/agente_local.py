# -*- coding: utf-8 -*-
"""Impresión térmica desde el propio sistema cuando corre como instalación local (3.12): el navegador manda comandas, tiquetes y
la gaveta a /api/agente/* y el sistema imprime en las impresoras USB o de red de esta computadora con app/escpos.py. Así en la
computadora de la caja corre un solo programa (no hace falta el agente suelto, que queda para quien trabaja con la nube).
En la nube estas rutas responden 404 y el navegador usa el agente suelto en http://127.0.0.1:9800.

4.25 (tanda 8): la impresión de ESTA computadora (registro «equipo_impresion», GET y PUT /api/agente/equipo, solo en el programa):
  {propias: [impresoras solo de esta computadora, con la forma de una de pos_impresoras y un id «eq-…»],
   ajustes: {<id de una impresora de la empresa>: {conexion usb|red, direccion, y en las de etiquetas densidad, separacion_mm, girar}},
   tiquetes: <id> o '', etiquetas: <id> o ''}
Es solo de esta computadora: no sube a la web, no baja y no se comparte por la red del local (sinc.CLAVES_DEL_EQUIPO); los registros
genéricos no lo leen ni lo escriben. Leerlo: quien usa la caja o el inventario; guardarlo: quien configura (el permiso de pos_impresoras).
Los mensajes de una impresora que no responde son llanos (escpos.mensaje_llano); el detalle técnico va al registro y a ultimo_error."""
import logging
import os
import re
import time
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlmodel import Session

from . import auth, escpos, etiquetas_impresora as ei, modulos
from .auth import Contexto, contexto, sesion_empresa

router = APIRouter(prefix="/api/agente", tags=["agente"])
MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"
VERSION = "1.0-local"
_estado = {"trabajos": 0, "ultimo": "", "ultimo_error": ""}
_log = logging.getLogger(__name__)


def _solo_local():
    if not MODO_LOCAL:
        raise HTTPException(404, "La impresión directa solo existe en la instalación local; en la nube use el agente de impresión")


@router.get("/estado")
def estado(ctx: Contexto = Depends(contexto)):
    _solo_local()
    return {"agente": "FISITAAP ERP", "version": VERSION, "modo_local": True, "impresoras_windows": escpos.impresoras_windows(),
            "trabajos": _estado["trabajos"], "ultimo": _estado["ultimo"], "ultimo_error": _estado["ultimo_error"], "windows": bool(escpos.win32print),
            "etiquetas": escpos.VERSION_ETIQUETAS}                 # 4.24: /api/agente/imprimir también recibe trabajos de etiquetas (TSPL y ZPL)


# ================================================================================ impresión de esta computadora (4.25, tanda 8)
CLAVE_EQUIPO = "equipo_impresion"
PREFIJO_PROPIA = "eq-"
MAX_PROPIAS = 20
DIRECCION_MAX = 120
NOMBRE_MAX = 40
USOS_PROPIA = ("comprobante", "etiquetas")             # solo tiquetes y facturas, o etiquetas: las comandas son de la empresa
_RE_IP = re.compile(r"^\d{1,3}(\.\d{1,3}){3}(:\d+)?$")    # la misma regla del formulario de impresoras
_RE_ID_PROPIA = re.compile(r"^eq-[A-Za-z0-9_-]{1,30}$")
# 4.25 (9c, P1): las etiquetas por red salen solo al puerto 9100 de una IP de la red del local (escpos._raw_permitido)
MENSAJE_ETQ_PUERTO = "La impresora de etiquetas por red se escribe solo con su dirección IP (sin «:puerto»)."
MENSAJE_ETQ_DESTINO = ("La impresora de etiquetas por red tiene que estar en la red del local: escriba su dirección IP, sin «:puerto».")
MODELOS_ETQ = {m["id"]: m for m in ei.MODELOS}


def equipo_vacio() -> dict:
    return {"propias": [], "ajustes": {}, "tiquetes": "", "etiquetas": ""}


def leer_equipo(s, eid: int) -> dict:
    """Lo guardado, con valores por omisión (todo es opcional)."""
    v = modulos.leer(s, eid, CLAVE_EQUIPO, None)
    v = v if isinstance(v, dict) else {}
    out = equipo_vacio()
    out["propias"] = [x for x in v.get("propias") or [] if isinstance(x, dict)] if isinstance(v.get("propias"), list) else []
    out["ajustes"] = {str(k): a for k, a in v.get("ajustes").items() if isinstance(a, dict)} if isinstance(v.get("ajustes"), dict) else {}
    out["tiquetes"] = str(v.get("tiquetes") or "")
    out["etiquetas"] = str(v.get("etiquetas") or "")
    return out


def _vacio(v) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def _numero(v, que: str) -> float:
    if isinstance(v, bool):
        raise ValueError(que)
    try:
        n = float(v)
    except (TypeError, ValueError):
        raise ValueError(que) from None
    if n != n or n in (float("inf"), float("-inf")):
        raise ValueError(que)
    return n


def _direccion(conexion: str, direccion, nombre: str, etiquetas: bool) -> str:
    d = str(direccion or "").strip() if isinstance(direccion, (str, int, float)) and not isinstance(direccion, bool) else ""
    if len(d) > DIRECCION_MAX:
        raise ValueError(f"«{nombre}»: la dirección de la impresora va hasta {DIRECCION_MAX} caracteres")
    if conexion == "red" and not _RE_IP.match(d):
        raise ValueError(f"«{nombre}»: indique la dirección IP de la impresora (por ejemplo 192.168.1.50)")
    if conexion == "red" and etiquetas and d.partition(":")[2] not in ("", "9100"):
        # 4.25 (9c, P1): el servicio manda las etiquetas solo al 9100 (escpos._raw_permitido): otro puerto nunca saldría
        raise ValueError(MENSAJE_ETQ_PUERTO)
    if conexion == "usb" and etiquetas and not d:
        raise ValueError(f"«{nombre}»: indique el nombre de la impresora de etiquetas en Windows")
    return d


def _densidad(v, lenguaje: str, nombre: str):
    if _vacio(v):
        return None
    tope = ei.DENSIDAD_MAX.get(lenguaje, 15)
    n = _numero(v, f"«{nombre}»: la densidad va de 0 a {tope}")
    if n != int(n) or not 0 <= n <= tope:
        raise ValueError(f"«{nombre}»: la densidad va de 0 a {tope} (o vacía, para usar la que tiene puesta la impresora)")
    return int(n)


def _separacion(v, nombre: str):
    if _vacio(v):
        return None
    n = _numero(v, f"«{nombre}»: la separación entre etiquetas va de 0 a 20 mm")
    if not 0 <= n <= 20:
        raise ValueError(f"«{nombre}»: la separación entre etiquetas va de 0 a 20 mm")
    return n


def _propia(x, ids: set) -> dict:
    """Una impresora solo de esta computadora, con los campos y topes del formulario de impresoras. ValueError con el motivo."""
    if not isinstance(x, dict):
        raise ValueError("Una de las impresoras de esta computadora no es válida")
    nombre = str(x.get("nombre") or "").strip()[:NOMBRE_MAX] if isinstance(x.get("nombre"), str) else ""
    if not nombre:
        raise ValueError("Indique el nombre de cada impresora de esta computadora")
    iid = str(x.get("id") or "")
    if not _RE_ID_PROPIA.match(iid) or iid in ids:
        raise ValueError(f"«{nombre}»: la impresora no tiene un número válido; vuelva a agregarla")
    uso = x.get("uso")
    if uso not in USOS_PROPIA:
        raise ValueError(f"«{nombre}»: una impresora solo de esta computadora es de tiquetes y facturas o de etiquetas (las de comanda son de la empresa)")
    etq = uso == "etiquetas"
    out = {"id": iid, "nombre": nombre, "uso": uso, "ancho": 58 if x.get("ancho") in (58, "58") else 80, "activa": x.get("activa") is not False}
    lenguaje = None
    if etq:
        modelo = x.get("modelo") if x.get("modelo") in MODELOS_ETQ else None
        if modelo is None:
            raise ValueError(f"«{nombre}»: elija el modelo de la impresora de etiquetas")
        lenguaje = x.get("lenguaje") if x.get("lenguaje") in ei.LENGUAJES else "tspl"
        dpi = int(_numero(x.get("dpi") or 203, f"«{nombre}»: la resolución de la impresora debe ser 203, 300 o 600 puntos por pulgada"))
        if dpi not in ei.DPI_VALIDOS:
            raise ValueError(f"«{nombre}»: la resolución de la impresora debe ser 203, 300 o 600 puntos por pulgada")
        if not ei.medida_valida(x.get("etq_ancho_mm"), x.get("etq_alto_mm")) or isinstance(x.get("etq_ancho_mm"), bool) or isinstance(x.get("etq_alto_mm"), bool):
            raise ValueError(f"«{nombre}»: la medida de la etiqueta va de {ei.ANCHO_MIN} a {ei.ANCHO_MAX} mm de ancho y de {ei.ALTO_MIN} a {ei.ALTO_MAX} mm de alto")
        ancho, alto = float(x["etq_ancho_mm"]), float(x["etq_alto_mm"])
        if ancho > MODELOS_ETQ[modelo]["ancho_max_mm"]:
            raise ValueError(f"«{nombre}»: la {MODELOS_ETQ[modelo]['nombre']} imprime hasta {MODELOS_ETQ[modelo]['ancho_max_mm']} mm de ancho")
        sep = _separacion(x.get("separacion_mm"), nombre)
        out.update({"modelo": modelo, "lenguaje": lenguaje, "dpi": dpi, "etq_ancho_mm": int(ancho) if ancho == int(ancho) else ancho,
                    "etq_alto_mm": int(alto) if alto == int(alto) else alto, "separacion_mm": ei.SEPARACION_MM if sep is None else sep,
                    "densidad": None if lenguaje == "pdf" else _densidad(x.get("densidad"), lenguaje, nombre),
                    "girar": lenguaje != "pdf" and x.get("girar") is True})
    if lenguaje == "pdf":                                  # imprime el PDF con el controlador de Windows: no tiene conexión propia
        out.update({"conexion": "navegador", "direccion": ""})
    else:
        conexion = x.get("conexion")
        if conexion not in ("usb", "red"):
            raise ValueError(f"«{nombre}»: indique cómo está conectada: impresora de Windows (USB) o por red")
        out.update({"conexion": conexion, "direccion": _direccion(conexion, x.get("direccion"), nombre, etq)})
    return out


def _ajuste(a, imp: dict) -> dict | None:
    """Cómo está conectada aquí una impresora de la empresa (y los ajustes de etiquetas). None = igual que en la configuración."""
    if not isinstance(a, dict):
        return None
    nombre = str(imp.get("nombre") or "la impresora")[:NOMBRE_MAX]
    etq = imp.get("uso") == "etiquetas"
    out = {}
    conexion = a.get("conexion")
    if not _vacio(conexion):
        if conexion not in ("usb", "red"):
            raise ValueError(f"«{nombre}»: en esta computadora puede estar conectada como impresora de Windows (USB) o por red")
        out = {"conexion": conexion, "direccion": _direccion(conexion, a.get("direccion"), nombre, etq)}
    if etq:
        lenguaje = imp.get("lenguaje") if imp.get("lenguaje") in ("tspl", "zpl") else "tspl"
        den, sep = _densidad(a.get("densidad"), lenguaje, nombre), _separacion(a.get("separacion_mm"), nombre)
        if den is not None:
            out["densidad"] = den
        if sep is not None:
            out["separacion_mm"] = sep
        if isinstance(a.get("girar"), bool):
            out["girar"] = a["girar"]
    return out or None


def validar_equipo(datos, empresa: list) -> dict:
    """Lo que se guarda en «equipo_impresion», validado contra las impresoras de la empresa (pos_impresoras). ValueError con el motivo.
    Los ajustes de impresoras que no son de la empresa se descartan; tiquetes y etiquetas deben existir y ser de ese uso."""
    if not isinstance(datos, dict):
        raise ValueError("Los datos de impresión de esta computadora no son válidos")
    empresa = [i for i in (empresa if isinstance(empresa, list) else []) if isinstance(i, dict) and i.get("id") not in (None, "")]
    por_id = {str(i["id"]): i for i in empresa}
    propias_in = datos.get("propias") if datos.get("propias") is not None else []
    if not isinstance(propias_in, list):
        raise ValueError("Las impresoras de esta computadora no son válidas")
    if len(propias_in) > MAX_PROPIAS:
        raise ValueError(f"Esta computadora admite hasta {MAX_PROPIAS} impresoras propias")
    ids = set(por_id)
    propias = []
    for x in propias_in:
        p = _propia(x, ids)
        ids.add(p["id"]); propias.append(p)
    ajustes = {}
    aj_in = datos.get("ajustes") if isinstance(datos.get("ajustes"), dict) else {}
    for k, a in list(aj_in.items())[:500]:
        imp = por_id.get(str(k))
        if imp is None:                                   # una impresora que no es de la empresa (o ya no existe): se descarta
            continue
        a2 = _ajuste(a, imp)
        if a2:
            ajustes[str(k)] = a2

    def _eleccion(campo: str, uso: str, que: str) -> str:
        v = datos.get(campo)
        if _vacio(v):
            return ""
        v = str(v)
        imp = por_id.get(v) or next((p for p in propias if p["id"] == v), None)
        if imp is None or imp.get("activa") is False or (imp.get("uso") or "comanda") != uso:
            raise ValueError(f"La {que} de esta computadora ya no existe o no es de ese uso: elíjala de nuevo")
        return v
    return {"propias": propias, "ajustes": ajustes,
            "tiquetes": _eleccion("tiquetes", "comprobante", "impresora de tiquetes y facturas"),
            "etiquetas": _eleccion("etiquetas", "etiquetas", "impresora de etiquetas")}


def _puede_leer_equipo(ctx: Contexto) -> bool:
    """Quien usa la caja o el resto del negocio (inventario, ventas, configuración). No los roles de un solo módulo (Camarera, Técnico,
    solo Recursos humanos), que no imprimen tiquetes ni etiquetas."""
    return bool(getattr(ctx.usuario, "es_superadmin", False)) or ctx.puede("pos") or not auth.solo_modulo(ctx.permisos)


@router.get("/equipo")
def ver_equipo(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """La impresión de esta computadora y si las impresoras de la empresa las manda la web (programa conectado)."""
    _solo_local()
    if not _puede_leer_equipo(ctx):
        raise HTTPException(403, "Su rol no usa la impresión de esta computadora")
    from . import sinc
    return {"equipo": leer_equipo(s, ctx.empresa.id), "empresa_web": sinc.impresoras_de_la_web(s, ctx.empresa.id)}


@router.put("/equipo")
def guardar_equipo(cuerpo: Any = Body(None), ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Guarda la impresión de esta computadora (permiso «configurar», el mismo de las impresoras de la empresa). El cuerpo se valida
    aquí adentro: un error nunca repite lo enviado."""
    _solo_local()
    if not ctx.puede("configurar"):
        raise HTTPException(403, "La impresión de esta computadora la cambia quien configura el punto de venta")
    datos = cuerpo.get("equipo") if isinstance(cuerpo, dict) and isinstance(cuerpo.get("equipo"), dict) else cuerpo
    eid = ctx.empresa.id
    try:
        limpio = validar_equipo(datos, modulos.leer(s, eid, "pos_impresoras", []) or [])
    except ValueError as ex:
        raise HTTPException(400, str(ex)) from None
    r = modulos._registro(s, eid, CLAVE_EQUIPO)
    try:
        modulos.reemplazar(s, eid, CLAVE_EQUIPO, limpio, version=(r.version or 0) if r else 0)
        s.commit()
    except modulos.ConflictoRegistro:
        s.rollback()
        raise HTTPException(409, "Otra pantalla guardó la impresión de esta computadora al mismo tiempo: inténtelo de nuevo") from None
    from . import sinc
    return {"ok": True, "equipo": limpio, "empresa_web": sinc.impresoras_de_la_web(s, eid)}


@router.post("/{ruta}")
def imprimir(ruta: str, cuerpo: dict = Body(...), ctx: Contexto = Depends(contexto)):
    _solo_local()
    if ruta not in ("imprimir", "prueba", "gaveta", "raw"):
        raise HTTPException(404, "Ruta desconocida")
    imp = cuerpo.get("impresora") or {}
    try:
        escpos.ejecutar(ruta, imp, cuerpo)
    except ValueError as ex:             # 4.24: un trabajo mal armado (medida, copias, código) o un destino no permitido se dice tal cual
        texto, tecnico = escpos.mensaje_llano(ex, imp)     # 4.25 (tanda 8): la impresora que no responde, en texto llano; lo técnico, al registro
        _estado["ultimo_error"] = tecnico
        if isinstance(ex, escpos.ErrorImpresora):
            _log.warning("Impresión %s: %s", ruta, tecnico)
        elif isinstance(ex, escpos.DestinoNoPermitido) and cuerpo.get("etiquetas") is not None:
            # 4.25 (9c, P1): etiquetas a un destino que no es USB ni una IP de la red del local en el 9100: a la pantalla, un texto
            # llano; al registro, solo el rechazo (sin la dirección ni nada del trabajo)
            texto = MENSAJE_ETQ_DESTINO
            _log.warning("Impresión de etiquetas rechazada: el destino no es una impresora USB ni una impresora de la red del local en el puerto 9100")
        raise HTTPException(400 if cuerpo.get("etiquetas") is not None else 500, texto) from None
    except Exception as ex:  # noqa: BLE001
        texto, tecnico = escpos.mensaje_llano(ex, imp)
        _estado["ultimo_error"] = tecnico
        _log.warning("Impresión %s: %s", ruta, tecnico)
        raise HTTPException(500, texto) from None
    _estado["trabajos"] += 1; _estado["ultimo"] = time.strftime("%H:%M:%S") + " " + ruta + " → " + str(imp.get("nombre") or imp.get("direccion") or ""); _estado["ultimo_error"] = ""
    return {"ok": True}
