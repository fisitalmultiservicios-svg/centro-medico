# -*- coding: utf-8 -*-
"""4.29 · Número consecutivo de las comandas del restaurante (servidor).

- POST /api/pos/comanda/numero con {"modo": "dia"} o {"modo": "continuo"} → {"numero", "modo", "fecha"}: el número siguiente de la
  empresa. «dia» vuelve a 1 cuando cambia la fecha de Costa Rica (config.ahora_cr, la de los comprobantes) y devuelve esa fecha;
  «continuo» no se reinicia (fecha null). Permiso «pos», el de las rutas que usa la caja (POST /api/pos/autorizar): Cajero, Vendedor,
  Avanzado, Administrador y cualquier rol propio con el punto de venta. Es una ruta de escritura: con el plan vencido (solo consulta)
  planes.verificar_vigencia la rechaza (403 plan_vencido) y la caja envía la comanda sin número.
- El contador vive en la tabla comanda_numero de la base de la empresa (db.ComandaNumero, una fila por modo) y se sube con el mismo
  mecanismo que los consecutivos de los comprobantes (main._siguiente_numero): primero se escribe (INSERT … WHERE NOT EXISTS y
  UPDATE ultimo + 1, que toman el bloqueo de escritura de SQLite) y después se lee en la misma transacción. Dos cajas que piden a la
  vez nunca reciben el mismo número, también entre procesos. Sin RETURNING ni UPSERT (el SQLite del hosting puede ser viejo).
- El contador NO viaja: ninguna lista de sinc (CLAVES_CATALOGO, CLAVES_OPERATIVAS, CLAVES_RED) ni la subida o bajada de documentos lo
  nombra, así que en el programa de escritorio cada computadora lleva el suyo. Al restaurar un respaldo (respaldo.restaurar_empresa)
  el contador que tenía este servidor se conserva (conservar): un respaldo viejo o de otra computadora no lo atrasa ni repite números
  del mismo día.

4.31 · Estación de comandas: la comanda de un pedido en línea siempre sale.
- pedidos.a_caja guarda, en el mismo commit que crea la cuenta de la caja, una COPIA FIJA de la comanda del pedido (tabla comanda_pedido,
  guardar_copia): las líneas que van a cocina con su posición en la cuenta y su huella, el origen (pago | aceptar | aceptar_anterior) y
  listo_desde (creado, o la hora de entrega menos 45 min). Las pantallas imprimen de esa copia, no de pos_espera.
- Reclamos POR PLATO (tabla comanda_reclamo, una fila por pedido y posición): reclamar un grupo es todo o nada en una transacción
  (INSERT … WHERE NOT EXISTS / UPDATE condicionado, como siguiente); un reclamo vence a los 60 s; «impresa» es para siempre.
- Rutas (permiso «pos»): GET /api/pos/comanda/pendientes, POST /api/pos/comanda/reclamar, /impresa y /soltar. Responden 200 con
  `resultado`; 400 con texto llano si el cuerpo no sirve; nunca 404 por un pedido o una cuenta que ya no están.
- La estación solo imprime copias con la espera cumplida (15 s; 60 s si quien aceptó es una pestaña anterior, que no reclama) y no
  vieja (30 min). Cocina a mano no espera ni tiene tope.
- Las tablas son de ESTE servidor: ninguna lista de sinc las nombra. Al restaurar un respaldo se conserva lo impreso (leer_comandas /
  conservar_comandas). Lo anterior a la 4.31 no tiene copia y nunca es candidato.
"""
import json
import logging
import math
import re
import time
from collections import Counter
from datetime import datetime, timedelta
from typing import Any, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import text
from sqlmodel import Session

from .auth import Contexto, requiere, sesion_empresa
from .config import TZ_CR, ahora_cr

router = APIRouter(tags=["pos"])
MODOS = ("dia", "continuo")
MENSAJE_MODO = "La forma de numerar las comandas no es válida: use «dia» (consecutivo del día) o «continuo»."


def hoy_cr() -> str:
    """Fecha de Costa Rica (AAAA-MM-DD), la misma que usan los comprobantes."""
    return ahora_cr().date().isoformat()


def siguiente(s: Session, eid: int, modo: str, hoy: str | None = None) -> tuple[int, str | None]:
    """Número siguiente de la empresa en ese modo y la fecha que le corresponde (None en el continuo). Hace commit."""
    if modo not in MODOS:
        raise HTTPException(400, MENSAJE_MODO)
    f = (hoy or hoy_cr()) if modo == "dia" else ""
    p = {"e": int(eid), "m": modo, "f": f}
    s.execute(text("INSERT INTO comanda_numero (empresa_id, modo, fecha, ultimo) SELECT :e, :m, :f, 0 "
                   "WHERE NOT EXISTS (SELECT 1 FROM comanda_numero WHERE empresa_id = :e AND modo = :m)"), p)
    if modo == "dia":       # otro día: vuelve a 1 (la fecha que se guarda es la del número que se da)
        s.execute(text("UPDATE comanda_numero SET ultimo = CASE WHEN fecha = :f THEN ultimo + 1 ELSE 1 END, fecha = :f "
                       "WHERE empresa_id = :e AND modo = :m"), p)
    else:
        s.execute(text("UPDATE comanda_numero SET ultimo = ultimo + 1 WHERE empresa_id = :e AND modo = :m"), p)
    n = int(s.execute(text("SELECT ultimo FROM comanda_numero WHERE empresa_id = :e AND modo = :m"), p).scalar_one())
    s.commit()
    return n, (f if modo == "dia" else None)


@router.post("/api/pos/comanda/numero")
def numero_comanda(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.29: el número de la comanda que la caja va a enviar (uno por envío; todas las impresoras de ese envío llevan el mismo)."""
    modo = cuerpo.get("modo") if isinstance(cuerpo, dict) else None
    if not isinstance(modo, str) or modo not in MODOS:
        raise HTTPException(400, MENSAJE_MODO)
    n, fecha = siguiente(s, ctx.empresa.id, modo)
    return {"numero": n, "modo": modo, "fecha": fecha}


# ---------------------------------------------------------------------------------------------- respaldos
def leer_contador(ruta) -> list[tuple]:
    """Filas (modo, fecha, ultimo) del contador en el archivo de base de la empresa, sin abrir su motor. [] si no hay archivo, la base
    es de una versión anterior (sin la tabla) o no se puede leer."""
    import sqlite3
    from pathlib import Path
    if not Path(ruta).exists():
        return []
    try:
        cx = sqlite3.connect(f"file:{Path(ruta).as_posix()}?mode=ro", uri=True, timeout=30)
        try:
            return [(str(m), str(f or ""), int(u or 0)) for m, f, u in cx.execute("SELECT modo, fecha, ultimo FROM comanda_numero")]
        finally:
            cx.close()
    except Exception:  # noqa: BLE001  sin la tabla (base anterior a la 4.29) o ilegible: no hay nada que conservar
        return []


def conservar(eid: int, filas: list[tuple]) -> int:
    """Después de restaurar la base de la empresa: el contador queda en el mayor entre el restaurado y el que tenía este servidor (en
    el modo día, la fecha más reciente y, si es la misma, el número mayor). Así nunca se atrasa ni repite números. Devuelve cuántas
    filas cambió."""
    if not filas:
        return 0
    from .db import engine_empresa
    cambios = 0
    with Session(engine_empresa(int(eid))) as s:
        for modo, fecha, ultimo in filas:
            if modo not in MODOS:
                continue
            p = {"e": int(eid), "m": modo, "f": fecha if modo == "dia" else "", "u": int(ultimo)}
            fila = s.execute(text("SELECT fecha, ultimo FROM comanda_numero WHERE empresa_id = :e AND modo = :m"), p).first()
            if fila is None:
                s.execute(text("INSERT INTO comanda_numero (empresa_id, modo, fecha, ultimo) VALUES (:e, :m, :f, :u)"), p)
                cambios += 1
                continue
            f_rest, u_rest = str(fila[0] or ""), int(fila[1] or 0)
            if modo == "dia":
                gana = p["f"] > f_rest or (p["f"] == f_rest and p["u"] > u_rest)
            else:
                gana = p["u"] > u_rest
            if gana:
                s.execute(text("UPDATE comanda_numero SET fecha = :f, ultimo = :u WHERE empresa_id = :e AND modo = :m"), p)
                cambios += 1
        s.commit()
    return cambios


# ================================================================================================ 4.31 · estación de comandas
_log = logging.getLogger(__name__)

ESPERA_ESTACION_S = 15            # origen pago o aceptar (pestaña que reclama antes de imprimir): la estación espera esto
ESPERA_PESTANA_ANTERIOR_S = 60    # origen aceptar_anterior (pestaña anterior a la 4.31: imprime sin reclamar y marca al final)
VENCE_RECLAMO_S = 60
REINTENTO_MISMO_EQUIPO_S = 60
MAX_INTENTOS_ESTACION = 3
VIGENCIA_MIN = 30
ANTICIPO_PROGRAMADO_MIN = 45      # decisión del dueño: un pedido para más tarde sale 45 minutos antes de la hora de entrega
BORRAR_TRAS_DIAS = 2
MAX_PENDIENTES = 50
MAX_PLATOS = 200
ORIGENES = ("pago", "aceptar", "aceptar_anterior")
MOMENTOS = ("aceptar", "estacion", "cocina")
EQUIPO_PESTANA_ANTERIOR = "pestana-anterior"
EQUIPO_COCINA_ANTERIOR = "cocina-anterior"
MENSAJE_FALTAN = "Faltan datos de la comanda: pedido, platos, impresora y equipo."
MENSAJE_PLATOS = "Esos platos no son de la comanda de este pedido: actualice la página."
MENSAJE_EQUIPO = "El identificador de esta computadora no es válido: actualice la página."
_EQUIPO_RE = re.compile(r"[A-Za-z0-9_-]{8,64}")
_HORA_RE = re.compile(r"([01]\d|2[0-3]):([0-5]\d)")
_COLS_COPIA = ("pedido_id", "pedido_numero", "cuenta_id", "terminal_id", "nombre", "nota", "tipo", "hora_entrega", "numero", "origen", "creado",
               "listo_desde", "lineas", "sin_comanda", "estado", "motivo")
_COLS_RECLAMO = ("pos", "estado", "equipo", "nombre", "momento", "vence", "hora", "soltada_en", "intentos", "motivo", "grupo", "grupo_nombre")
_limpieza: dict = {}              # empresa → última limpieza en este proceso (time.monotonic)


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def _fecha(v) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(str(v))
    except (TypeError, ValueError):
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=TZ_CR)


def _numero_js(v) -> str:
    """El número como lo escribe JavaScript con String(+(v ?? 0)): 2 y 2.0 → «2», 1.5 → «1.5»."""
    if v is None or (isinstance(v, str) and not v.strip()):
        f = 0.0
    else:
        try:
            f = float(v)
        except (TypeError, ValueError):
            return "NaN"
    if math.isnan(f):
        return "NaN"
    if math.isinf(f):
        return "Infinity" if f > 0 else "-Infinity"
    if f == int(f) and abs(f) < 1e21:
        return str(int(f))
    return repr(f)


def huella(l) -> str:
    """Huella de una línea de la cuenta: detalle | enviado | nota | cantidad, la misma comparación que mismaLinea de pos/cocina.js.
    En JavaScript: [String(l.detalle ?? ''), String(l.enviado || ''), String(l.nota || ''), String(+(l.cantidad ?? 0))].join('|')."""
    if not isinstance(l, dict):
        return ""
    det = l.get("detalle")
    return "|".join(("" if det is None else str(det), str(l.get("enviado") or ""), str(l.get("nota") or ""), _numero_js(l.get("cantidad"))))


def listo_desde(creado, hora="") -> str:
    """Desde cuándo la comanda puede salir sola: `creado`, o la hora de entrega («HH:MM») menos ANTICIPO_PROGRAMADO_MIN si es más tarde.
    La hora es del día de `creado`; si queda más de una hora antes de `creado`, es del día siguiente."""
    c = _fecha(creado) or ahora_cr()
    m = _HORA_RE.fullmatch(str(hora or "").strip())
    if not m:
        return _iso(c)
    entrega = c.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
    if entrega < c - timedelta(hours=1):
        entrega += timedelta(days=1)
    return _iso(max(c, entrega - timedelta(minutes=ANTICIPO_PROGRAMADO_MIN)))


def _va_a_cocina(l) -> bool:
    if not isinstance(l, dict) or not l.get("enviado"):
        return False
    try:
        return float(l.get("cantidad") or 0) > 0
    except (TypeError, ValueError):
        return False


def _entero(v) -> Optional[int]:
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def _lista(txt) -> list:
    try:
        v = json.loads(txt or "[]")
    except (TypeError, ValueError):
        return []
    return v if isinstance(v, list) else []


def _espera(origen) -> int:
    return ESPERA_PESTANA_ANTERIOR_S if origen == "aceptar_anterior" else ESPERA_ESTACION_S


def _espere_s(copia: dict, ahora: datetime) -> int:
    listo = _fecha(copia.get("listo_desde")) or ahora
    return max(0, math.ceil((listo + timedelta(seconds=_espera(copia.get("origen"))) - ahora).total_seconds()))


def _vieja(copia: dict, ahora: datetime) -> bool:
    listo = _fecha(copia.get("listo_desde")) or ahora
    return ahora > listo + timedelta(minutes=VIGENCIA_MIN)


# ---------------------------------------------------------------------------------------------- copia fija (pedidos.a_caja)
def guardar_copia(s: Session, eid: int, p, cuenta: dict, cuenta_id: int, origen: str, listo: Optional[str] = None) -> bool:
    """La copia fija de la comanda del pedido, en la transacción de quien crea la cuenta (sin commit propio: pedidos.a_caja la escribe
    justo antes de modulos.aplicar_cambios, que hace el commit de las dos). Solo las líneas que van a cocina (`enviado` con valor y
    cantidad > 0), cada una con su posición en la cuenta y su huella. Una por pedido (ux_comanda_pedido): si ya hay copia (un aceptar a
    medias que se retoma) se conserva y solo pasa a la cuenta nueva (con sus líneas) si ningún plato está reclamado ni impreso. Nunca
    lanza: un error se anota y el pedido entra igual a la caja, sin copia (como en la 4.29).
    4.32 (§4.4): `listo`, si viene, reemplaza a listo_desde(creado, hora): el programa lo calcula para un pedido que llegó tarde (desde la
    llegada, o la hora vieja si tiene más de 3 horas, y entonces no sale sola)."""
    try:
        todas = cuenta.get("lineas") if isinstance(cuenta, dict) else None
        todas = todas if isinstance(todas, list) else []
        lineas = [{"pos": i, "producto_id": l.get("producto_id"), "detalle": "" if l.get("detalle") is None else str(l.get("detalle")),
                   "cantidad": l.get("cantidad"), "nota": str(l.get("nota") or ""), "huella": huella(l)}
                  for i, l in enumerate(todas) if _va_a_cocina(l)]
        if not lineas:
            return False
        creado = str(cuenta.get("creado") or _iso(ahora_cr()))
        hora = str(cuenta.get("hora_entrega") or "").strip()
        hora = hora if _HORA_RE.fullmatch(hora) else ""
        nota = str(cuenta.get("nota") or "").strip()
        if hora:
            nota = f"PARA LAS {hora}" + (f" · {nota}" if nota else "")
        numero = next((l["comanda"] for l in todas if _va_a_cocina(l) and _entero(l.get("comanda")) and l["comanda"] >= 1), None)
        term = cuenta.get("terminal_id")
        try:
            term = int(term) if term not in (None, "") else None
        except (TypeError, ValueError):
            term = None
        par = {"e": int(eid), "pid": int(p.id), "np": _entero(getattr(p, "numero", None)), "c": int(cuenta_id), "t": term,
               "n": str(cuenta.get("nombre") or "")[:200], "nota": nota[:600], "tipo": str(cuenta.get("pedido") or "")[:20], "h": hora,
               "num": numero, "o": origen if origen in ORIGENES else "aceptar_anterior", "cr": creado,
               "ld": listo if isinstance(listo, str) and _fecha(listo) is not None else listo_desde(creado, hora),
               "l": json.dumps(lineas, ensure_ascii=False), "a": _iso(ahora_cr())}
        n = s.execute(text("INSERT INTO comanda_pedido (empresa_id, pedido_id, pedido_numero, cuenta_id, terminal_id, nombre, nota, tipo, hora_entrega, "
                           "numero, origen, creado, listo_desde, lineas, sin_comanda, estado, motivo, actualizado) "
                           "SELECT :e, :pid, :np, :c, :t, :n, :nota, :tipo, :h, :num, :o, :cr, :ld, :l, '[]', 'pendiente', '', :a "
                           "WHERE NOT EXISTS (SELECT 1 FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :pid)"), par).rowcount
        if not n:
            s.execute(text("UPDATE comanda_pedido SET cuenta_id = :c, terminal_id = :t, lineas = :l, numero = :num, actualizado = :a "
                           "WHERE empresa_id = :e AND pedido_id = :pid AND estado = 'pendiente' AND NOT EXISTS (SELECT 1 FROM comanda_reclamo "
                           "WHERE empresa_id = :e AND pedido_id = :pid AND estado IN ('reclamada', 'impresa'))"), par)
        return True
    except Exception as ex:  # noqa: BLE001  la copia nunca impide que el pedido entre a la caja
        _log.warning("Copia de la comanda del pedido %s (empresa %s) no guardada: %s", getattr(p, "id", None), eid, ex)
        return False


def cambiar_cuenta_copia(s: Session, eid: int, pid: int, de: int, a: int) -> None:
    """La cuenta recibió otro id al guardarse (remap de modulos.aplicar_cambios): la copia la sigue. Sin commit. Nunca lanza."""
    try:
        s.execute(text("UPDATE comanda_pedido SET cuenta_id = :a WHERE empresa_id = :e AND pedido_id = :pid AND cuenta_id = :de"),
                  {"a": int(a), "e": int(eid), "pid": int(pid), "de": int(de)})
    except Exception as ex:  # noqa: BLE001
        _log.warning("Copia de la comanda del pedido %s: no se pudo pasar a la cuenta %s: %s", pid, a, ex)


def cerrar_copia(s: Session, eid: int, pid: int, motivo: str = "cancelado") -> bool:
    """El pedido se canceló: su copia queda «cerrada» y ninguna pantalla la imprime. Sin commit (va en la transacción de quien
    cancela). Nunca lanza."""
    try:
        return bool(s.execute(text("UPDATE comanda_pedido SET estado = 'cerrada', motivo = :m, actualizado = :a WHERE empresa_id = :e "
                                   "AND pedido_id = :pid AND estado <> 'cerrada'"),
                              {"m": str(motivo or "")[:300], "a": _iso(ahora_cr()), "e": int(eid), "pid": int(pid)}).rowcount)
    except Exception as ex:  # noqa: BLE001
        _log.warning("Copia de la comanda del pedido %s: no se pudo cerrar: %s", pid, ex)
        return False


def _copia(s: Session, eid: int, pid: int) -> Optional[dict]:
    fila = s.execute(text(f"SELECT {', '.join(_COLS_COPIA)} FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :pid"),
                     {"e": int(eid), "pid": int(pid)}).first()
    if fila is None:
        return None
    d = dict(zip(_COLS_COPIA, fila))
    d["lineas"] = [l for l in _lista(d["lineas"]) if isinstance(l, dict) and _entero(l.get("pos")) is not None]
    d["sin_comanda"] = [x for x in _lista(d["sin_comanda"]) if _entero(x) is not None]
    return d


def _filas(s: Session, eid: int, pid: int) -> dict:
    out = {}
    for f in s.execute(text(f"SELECT {', '.join(_COLS_RECLAMO)} FROM comanda_reclamo WHERE empresa_id = :e AND pedido_id = :pid"),
                       {"e": int(eid), "pid": int(pid)}).all():
        d = dict(zip(_COLS_RECLAMO, f))
        out[int(d["pos"])] = d
    return out


def _pedido_cancelado(s: Session, eid: int, pid: int) -> bool:
    try:
        from .pedidos import Pedido
        p = s.get(Pedido, int(pid))
        return bool(p is not None and p.empresa_id == eid and p.estado == "cancelado")
    except Exception:  # noqa: BLE001
        return False


def _leer_espera(s: Session, eid: int) -> list:
    from . import modulos
    return [x for x in (modulos.leer(s, eid, "pos_espera", []) or []) if isinstance(x, dict)]


def _cuentas_del_pedido(lista: list, pid: int, cuenta_id=None) -> list:
    return [x for x in lista if str(x.get("pedido_id") or "") == str(pid) or (cuenta_id and x.get("id") == cuenta_id)]


def _poner_impresas(s: Session, eid: int, pid: int, posiciones, equipo: str, nombre: str, ahora: str) -> int:
    """Esos platos quedan «impresa» (sin commit). Devuelve cuántos cambiaron."""
    n = 0
    for pos in posiciones:
        par = {"e": int(eid), "pid": int(pid), "p": int(pos), "eq": equipo, "n": nombre[:60], "a": ahora}
        k = s.execute(text("INSERT INTO comanda_reclamo (empresa_id, pedido_id, pos, grupo, grupo_nombre, estado, equipo, nombre, momento, vence, hora, "
                           "soltada_en, intentos, motivo) SELECT :e, :pid, :p, '', '', 'impresa', :eq, :n, '', '', :a, '', 0, '' "
                           "WHERE NOT EXISTS (SELECT 1 FROM comanda_reclamo WHERE empresa_id = :e AND pedido_id = :pid AND pos = :p)"), par).rowcount
        if not k:
            k = s.execute(text("UPDATE comanda_reclamo SET estado = 'impresa', equipo = :eq, nombre = :n, hora = :a WHERE empresa_id = :e "
                               "AND pedido_id = :pid AND pos = :p AND estado <> 'impresa'"), par).rowcount
        n += k
    return n


def _cerrar_si_completa(s: Session, eid: int, pid: int) -> Optional[str]:
    """Si todos los platos con impresora (los que no están en sin_comanda) quedaron impresos, la copia pasa a «impresa»; si ninguno
    tiene impresora, a «sin_comanda». Sin commit. Devuelve el estado de la copia."""
    copia = _copia(s, eid, pid)
    if copia is None or copia["estado"] != "pendiente":
        return copia["estado"] if copia else None
    filas = _filas(s, eid, pid)
    sin = set(copia["sin_comanda"])
    con = [l["pos"] for l in copia["lineas"] if l["pos"] not in sin]
    if not con:
        nuevo = "sin_comanda"
    elif all((filas.get(p) or {}).get("estado") == "impresa" for p in con):
        nuevo = "impresa"
    else:
        return "pendiente"
    s.execute(text("UPDATE comanda_pedido SET estado = :n, actualizado = :a WHERE empresa_id = :e AND pedido_id = :pid AND estado = 'pendiente'"),
              {"n": nuevo, "a": _iso(ahora_cr()), "e": int(eid), "pid": int(pid)})
    return nuevo


# ---------------------------------------------------------------------------------------------- marca «impreso» en la caja (L-9)
def reescribir_cuentas(s: Session, eid: int, elegir, cambiar) -> list:
    """4.31 (L-9 de «una mesa, un equipo a la vez»): lee las cuentas de pos_espera DENTRO del bloqueo de escritura del registro
    (modulos._bloquear, el mismo que toma aplicar_cambios) y guarda las que `cambiar(cuenta)` devuelve distintas (None = sin cambio).
    Nadie puede guardar esas cuentas entre la lectura y la escritura, así que no se pisa un plato que la caja guardó en ese instante
    (antes se leían fuera del bloqueo y se reemplazaban enteras). Siempre hace commit (también lo pendiente de la sesión, como
    aplicar_cambios). Devuelve [(antes, después)] de las que cambió."""
    from . import modulos
    r = modulos._registro(s, eid, "pos_espera")
    if r is None:
        return []
    modulos._bloquear(s, r)
    lista = modulos.leer(s, eid, "pos_espera", []) or []
    cambios = []
    for c in lista:
        if isinstance(c, dict) and elegir(c):
            n = cambiar(c)
            if n is not None and n != c:
                cambios.append((c, n))
    if cambios:
        modulos.aplicar_cambios(s, eid, "pos_espera", [n for _, n in cambios], [], [])
    s.commit()
    return cambios


def marcar_impresas(s: Session, eid: int, pid: int, posiciones=None, cuenta_id=None) -> dict:
    """Marca «impreso» en la caja (pos_espera, con reescribir_cuentas) y en los reclamos. Devuelve {"cuenta": bool, "marcadas": int}.
    - Con `posiciones` y `cuenta_id` (ruta vieja POST /api/pedidos/{id}/comanda/impresa, mismo contrato que la 4.29): esas líneas de esa
      cuenta quedan con «impreso» (solo las enviadas a cocina y sin la marca) y los platos de la copia que coinciden por huella quedan
      «impresa» en comanda_reclamo con el equipo «pestana-anterior» (sin la cuenta, por posición). Así la estación no reimprime lo que
      imprimió una pestaña anterior.
    - Sin `posiciones` (D-18): todas las líneas de la copia quedan con «impreso» donde estén (por huella, en las cuentas de ese pedido),
      las «sin comanda» incluidas, para que Cocina muestre la comanda «Impresa»."""
    if posiciones is not None:
        pos, vista = set(posiciones), {"cuenta": False, "marcadas": 0, "huellas": set()}

        def marcar(c):
            vista["cuenta"] = True; vista["marcadas"] = 0; vista["huellas"] = set()
            lineas = []
            for i, l in enumerate(c.get("lineas") or []):
                if i in pos and isinstance(l, dict) and l.get("enviado"):
                    vista["huellas"].add(huella(l))
                    if not l.get("impreso"):
                        l = {**l, "impreso": True}; vista["marcadas"] += 1
                lineas.append(l)
            return {**c, "lineas": lineas} if vista["marcadas"] else None
        if cuenta_id:
            reescribir_cuentas(s, eid, lambda x: x.get("id") == cuenta_id, marcar)
        cerrada = False
        try:
            copia = _copia(s, eid, pid)
            if copia is not None:
                if vista["cuenta"]:
                    cpos = [l["pos"] for l in copia["lineas"] if l.get("huella") in vista["huellas"]]
                else:
                    validas = {l["pos"] for l in copia["lineas"]}
                    cpos = [p for p in posiciones if p in validas]
                if cpos:
                    _poner_impresas(s, eid, pid, cpos, EQUIPO_PESTANA_ANTERIOR, "Pedidos (versión anterior)", _iso(ahora_cr()))
                    cerrada = _cerrar_si_completa(s, eid, pid) == "impresa" and copia["estado"] == "pendiente"
                    s.commit()
        except Exception as ex:  # noqa: BLE001  la marca de la caja ya quedó; la de los reclamos no detiene la respuesta
            _log.warning("Reclamos de la comanda del pedido %s no marcados: %s", pid, ex)
            cerrada = False
            try:
                s.rollback()
            except Exception:  # noqa: BLE001
                pass
        if cerrada:                       # 4.31: la copia quedó impresa: la marca de Cocina en todos sus platos (D-18), como la estación
            _marcar_cocina(s, eid, pid)
        return {"cuenta": vista["cuenta"], "marcadas": vista["marcadas"]}
    copia = _copia(s, eid, pid)
    if copia is None:
        return {"cuenta": False, "marcadas": 0}
    hs = {l.get("huella") for l in copia["lineas"]}
    vistas = {"cuentas": 0}

    def marcar_todo(c):
        vistas["cuentas"] += 1
        lineas, n = [], 0
        for l in c.get("lineas") or []:
            if isinstance(l, dict) and l.get("enviado") and not l.get("impreso") and huella(l) in hs:
                l = {**l, "impreso": True}; n += 1
            lineas.append(l)
        return {**c, "lineas": lineas} if n else None
    cambios = reescribir_cuentas(s, eid, lambda x: x in _cuentas_del_pedido([x], pid, copia["cuenta_id"]), marcar_todo)
    total = sum(sum(1 for a, b in zip(antes.get("lineas") or [], despues["lineas"]) if a != b) for antes, despues in cambios)
    return {"cuenta": bool(vistas["cuentas"]), "marcadas": total}


def _marcar_cocina(s: Session, eid: int, pid: int) -> int:
    """D-18 cuando la copia acaba de quedar «impresa» por una marca de una pantalla anterior (ruta vieja o Cocina anterior): «impreso» en
    todos los platos de la copia en la caja, para que Cocina la muestre «Impresa» y la reimpresión sea a propósito. Nunca lanza."""
    try:
        return marcar_impresas(s, eid, pid)["marcadas"]
    except Exception as ex:  # noqa: BLE001  la marca de Cocina es un aviso; la copia ya quedó impresa
        _log.warning("Comanda del pedido %s: marca «impreso» en la caja no guardada: %s", pid, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return 0


# ---------------------------------------------------------------------------------------------- reclamar, impresa, soltar, pendientes
def _bloqueo(s: Session, eid: int, pid: int, pos: int, pedidas: list, equipo: str, momento: str, ahora: datetime) -> dict:
    """La respuesta cuando un plato no se pudo tomar (ya se deshizo todo el grupo)."""
    filas = _filas(s, eid, pid)
    if pedidas and all((filas.get(p) or {}).get("estado") == "impresa" for p in pedidas):
        return {"resultado": "impresa"}
    f = filas.get(pos) or {}
    est = f.get("estado")
    if est == "reclamada" and str(f.get("vence") or "") >= _iso(ahora):
        if f.get("equipo") == equipo:
            return {"resultado": "en_curso", "vence": f.get("vence") or ""}
        return {"resultado": "ocupada", "por": f.get("nombre") or "", "vence": f.get("vence") or ""}
    if est == "soltada" and momento == "estacion":
        if int(f.get("intentos") or 0) >= MAX_INTENTOS_ESTACION:
            return {"resultado": "agotada", "motivo": f.get("motivo") or ""}
        suelta = _fecha(f.get("soltada_en"))
        if f.get("equipo") == equipo and suelta is not None:
            return {"resultado": "reintente", "espere_s": max(1, math.ceil(REINTENTO_MISMO_EQUIPO_S - (ahora - suelta).total_seconds()))}
    # impresa por otro en este instante, o cambió entre la lectura y la toma: la pantalla vuelve a pedir los platos libres
    return {"resultado": "ocupada", "por": f.get("nombre") or "", "vence": f.get("vence") or ""}


def reclamar(s: Session, eid: int, pedido_id: int, lineas: list, grupo: str, grupo_nombre: str, equipo: str, nombre: str, momento: str) -> dict:
    """Toma los platos `lineas` (posiciones de la copia) para imprimirlos: todo o nada, en una transacción (5.1 del diseño)."""
    ahora = ahora_cr(); ahora_t = _iso(ahora)
    copia = _copia(s, eid, pedido_id)
    if copia is None:
        return {"resultado": "sin_copia"}
    if copia["estado"] == "cerrada" or _pedido_cancelado(s, eid, pedido_id):
        return {"resultado": "cancelado"}
    if copia["estado"] == "impresa" or (copia["estado"] == "sin_comanda" and momento == "estacion"):
        return {"resultado": "impresa"}
    platos = {l["pos"]: l for l in copia["lineas"]}
    if any(p not in platos for p in lineas):
        raise HTTPException(400, MENSAJE_PLATOS)
    # lo que una Cocina anterior ya imprimió (marca «impreso» en la caja) sale del pedido y queda «impresa». 4.31: plato por plato (dos
    # platos iguales con una sola marca: solo uno), y una marca que ya corresponde a un plato impreso de la copia no cuenta para otro
    impreso: Counter = Counter()
    for c in _cuentas_del_pedido(_leer_espera(s, eid), pedido_id, copia["cuenta_id"]):
        impreso.update(huella(l) for l in (c.get("lineas") or []) if isinstance(l, dict) and l.get("enviado") and l.get("impreso"))
    filas0 = _filas(s, eid, pedido_id)
    for l in copia["lineas"]:
        if (filas0.get(l["pos"]) or {}).get("estado") == "impresa" and impreso[l.get("huella")] > 0:
            impreso[l.get("huella")] -= 1
    ya = []
    for p in lineas:
        h = platos[p].get("huella")
        if (filas0.get(p) or {}).get("estado") != "impresa" and impreso[h] > 0:
            impreso[h] -= 1
            ya.append(p)
    if ya:
        cerrada = False
        try:
            _poner_impresas(s, eid, pedido_id, ya, EQUIPO_COCINA_ANTERIOR, "Cocina (versión anterior)", ahora_t)
            cerrada = _cerrar_si_completa(s, eid, pedido_id) == "impresa"
            s.commit()
        except Exception as ex:  # noqa: BLE001
            _log.warning("Comanda del pedido %s: marca de Cocina anterior no guardada: %s", pedido_id, ex)
            cerrada = False
            s.rollback()
        if cerrada:                   # 4.31: la copia quedó impresa: la marca de Cocina en todos sus platos (D-18), como la estación
            _marcar_cocina(s, eid, pedido_id)
    filas = _filas(s, eid, pedido_id)
    resto = [p for p in lineas if p not in ya and (filas.get(p) or {}).get("estado") != "impresa"]
    if not resto:
        return {"resultado": "impresa"}
    if momento == "estacion":
        espere = _espere_s(copia, ahora)
        if espere > 0:
            return {"resultado": "pronto", "espere_s": espere}
        if _vieja(copia, ahora):
            return {"resultado": "vieja"}
    vence = _iso(ahora + timedelta(seconds=VENCE_RECLAMO_S))
    hace = _iso(ahora - timedelta(seconds=REINTENTO_MISMO_EQUIPO_S))
    pos = resto[0]
    try:
        for pos in resto:
            par = {"e": int(eid), "pid": int(pedido_id), "p": int(pos), "g": grupo, "gn": grupo_nombre, "eq": equipo, "n": nombre, "m": momento,
                   "v": vence, "a": ahora_t, "h60": hace, "max": MAX_INTENTOS_ESTACION}
            if s.execute(text("INSERT INTO comanda_reclamo (empresa_id, pedido_id, pos, grupo, grupo_nombre, estado, equipo, nombre, momento, vence, hora, "
                              "soltada_en, intentos, motivo) SELECT :e, :pid, :p, :g, :gn, 'reclamada', :eq, :n, :m, :v, :a, '', 0, '' "
                              "WHERE NOT EXISTS (SELECT 1 FROM comanda_reclamo WHERE empresa_id = :e AND pedido_id = :pid AND pos = :p)"), par).rowcount:
                continue
            if s.execute(text("UPDATE comanda_reclamo SET estado = 'reclamada', equipo = :eq, nombre = :n, momento = :m, grupo = :g, grupo_nombre = :gn, "
                              "vence = :v, hora = :a WHERE empresa_id = :e AND pedido_id = :pid AND pos = :p AND ("
                              "(estado = 'reclamada' AND vence < :a) OR (estado = 'soltada' AND (:m <> 'estacion' "
                              "OR (intentos < :max AND (equipo <> :eq OR soltada_en < :h60)))))"), par).rowcount:
                continue
            s.rollback()
            return _bloqueo(s, eid, pedido_id, pos, resto, equipo, momento, ahora)
        est = s.execute(text("SELECT estado FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :pid"), {"e": int(eid), "pid": int(pedido_id)}).scalar()
        if est not in ("pendiente", "sin_comanda") or (est == "sin_comanda" and momento == "estacion"):
            s.rollback()                                    # se canceló o se imprimió entre la lectura y la toma
            return {"resultado": "cancelado"} if est in (None, "cerrada") else {"resultado": "impresa"}
        s.commit()
    except HTTPException:
        raise
    except Exception as ex:  # noqa: BLE001  (índice único u otro choque: no ganó)
        _log.info("Reclamo de la comanda del pedido %s no ganado: %s", pedido_id, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return _bloqueo(s, eid, pedido_id, pos, resto, equipo, momento, ahora)
    return {"resultado": "ganada", "vence": vence, "lineas": resto}


def impresa(s: Session, eid: int, pedido_id: int, equipo: str, lineas: list, sin_comanda: list) -> dict:
    """La pantalla imprimió esos platos (y dice cuáles no van a ninguna impresora). Siempre marca: el papel ya salió."""
    copia = _copia(s, eid, pedido_id)
    if copia is None:
        return {"resultado": "sin_reclamo", "copia": "cerrada", "marcadas": 0, "cancelado": _pedido_cancelado(s, eid, pedido_id)}
    validas = {l["pos"] for l in copia["lineas"]}
    lineas = [p for p in lineas if p in validas]
    sin = [p for p in sin_comanda if p in validas]
    ahora_t = _iso(ahora_cr())
    filas = _filas(s, eid, pedido_id)
    doble = sin_reclamo = False
    for p in lineas:
        f = filas.get(p)
        par = {"e": int(eid), "pid": int(pedido_id), "p": int(p), "eq": equipo, "a": ahora_t}
        if f is not None and f.get("estado") == "reclamada" and f.get("equipo") == equipo:
            s.execute(text("UPDATE comanda_reclamo SET estado = 'impresa', hora = :a WHERE empresa_id = :e AND pedido_id = :pid AND pos = :p"), par)
        elif f is not None and f.get("estado") == "impresa":
            if f.get("equipo") != equipo:
                doble = True                              # otra pantalla ya la había impreso: salió dos veces
        elif f is not None and f.get("estado") == "reclamada":
            doble = True                                  # otro la retomó (venció): las dos la imprimen
            s.execute(text("UPDATE comanda_reclamo SET estado = 'impresa', hora = :a WHERE empresa_id = :e AND pedido_id = :pid AND pos = :p"), par)
        else:
            sin_reclamo = True                            # sin reclamo de este equipo (o lo había soltado): se marca igual
            _poner_impresas(s, eid, pedido_id, [p], equipo, (f or {}).get("nombre") or "", ahora_t)
    if doble:
        _log.warning("Comanda del pedido %s (empresa %s): platos %s impresos otra vez por el equipo %s", pedido_id, eid, lineas, equipo)
    elif sin_reclamo:
        _log.info("Comanda del pedido %s (empresa %s): platos %s marcados impresos sin reclamo del equipo %s", pedido_id, eid, lineas, equipo)
    if sin:
        juntas = sorted(set(copia["sin_comanda"]) | set(sin))
        s.execute(text("UPDATE comanda_pedido SET sin_comanda = :sc, actualizado = :a WHERE empresa_id = :e AND pedido_id = :pid"),
                  {"sc": json.dumps(juntas), "a": ahora_t, "e": int(eid), "pid": int(pedido_id)})
    cancelado = copia["estado"] == "cerrada" or _pedido_cancelado(s, eid, pedido_id)
    estado = copia["estado"] if cancelado else _cerrar_si_completa(s, eid, pedido_id)
    s.commit()
    marcadas = 0
    if estado == "impresa" and copia["estado"] == "pendiente":
        try:
            marcadas = marcar_impresas(s, eid, pedido_id)["marcadas"]
        except Exception as ex:  # noqa: BLE001  la marca de Cocina es un aviso; la copia ya quedó impresa
            _log.warning("Comanda del pedido %s: marca «impreso» en la caja no guardada: %s", pedido_id, ex)
            try:
                s.rollback()
            except Exception:  # noqa: BLE001
                pass
    return {"resultado": "doble" if doble else "sin_reclamo" if sin_reclamo else "ok", "copia": estado or "cerrada", "marcadas": marcadas, "cancelado": bool(cancelado)}


def soltar(s: Session, eid: int, pedido_id: int, equipo: str, lineas: list, motivo: str) -> dict:
    """La pantalla no pudo imprimir: suelta sus platos (otra puede tomarlos ya; ella misma, pasados 60 s). Una falla de estación suma
    un intento (con MAX_INTENTOS_ESTACION ninguna estación lo vuelve a intentar)."""
    if not lineas:
        return {"resultado": "no_era_suya"}
    marcas = ", ".join(f":p{i}" for i in range(len(lineas)))
    par = {"e": int(eid), "pid": int(pedido_id), "eq": equipo, "m": motivo, "a": _iso(ahora_cr()), **{f"p{i}": int(p) for i, p in enumerate(lineas)}}
    n = s.execute(text("UPDATE comanda_reclamo SET estado = 'soltada', motivo = :m, soltada_en = :a, intentos = intentos + "
                       f"(CASE WHEN momento = 'estacion' THEN 1 ELSE 0 END) WHERE empresa_id = :e AND pedido_id = :pid AND pos IN ({marcas}) "
                       "AND equipo = :eq AND estado = 'reclamada'"), par).rowcount
    s.commit()
    return {"resultado": "ok" if n else "no_era_suya"}


def _salida_copia(copia: dict, filas: dict, vivas: set, ahora: datetime) -> dict:
    ahora_t = _iso(ahora)
    lineas = []
    for l in copia["lineas"]:
        f = filas.get(l["pos"]) or {}
        est = f.get("estado") or "libre"
        if est == "reclamada" and str(f.get("vence") or "") < ahora_t:
            est = "libre"                                   # venció: cualquiera la puede tomar
        lineas.append({"pos": l["pos"], "producto_id": l.get("producto_id"), "detalle": l.get("detalle") or "", "cantidad": l.get("cantidad"),
                       "nota": l.get("nota") or "", "huella": l.get("huella") or "", "estado": est,
                       "por": (f.get("nombre") or "") if est in ("reclamada", "impresa") else "", "vence": (f.get("vence") or "") if est == "reclamada" else "",
                       "intentos": int(f.get("intentos") or 0)})
    return {"pedido_id": copia["pedido_id"], "pedido_numero": copia["pedido_numero"], "cuenta_id": copia["cuenta_id"],
            "cuenta_viva": copia["pedido_id"] in vivas or ("c", copia["cuenta_id"]) in vivas, "terminal_id": copia["terminal_id"],
            "nombre": copia["nombre"] or "", "nota": copia["nota"] or "", "tipo": copia["tipo"] or "", "hora_entrega": copia["hora_entrega"] or "",
            "numero": copia["numero"], "origen": copia["origen"] or "", "creado": copia["creado"] or "", "listo_desde": copia["listo_desde"] or "",
            "espere_s": _espere_s(copia, ahora), "vieja": _vieja(copia, ahora), "estado": copia["estado"], "lineas": lineas,
            "sin_comanda": copia["sin_comanda"]}


def pendientes(s: Session, eid: int, pedido_id: Optional[int] = None) -> dict:
    """Sin pedido: las copias «pendiente» y no viejas, de la más vieja a la más nueva (MAX_PENDIENTES). Con pedido: esa copia en
    cualquier estado (o ninguna)."""
    ahora = ahora_cr()
    if pedido_id is not None:
        c = _copia(s, eid, pedido_id)
        copias = [c] if c else []
    else:
        lim = _iso(ahora - timedelta(minutes=VIGENCIA_MIN))
        pids = [int(r[0]) for r in s.execute(text("SELECT pedido_id FROM comanda_pedido WHERE empresa_id = :e AND estado = 'pendiente' AND listo_desde >= :lim "
                                                  "ORDER BY listo_desde, id LIMIT :n"), {"e": int(eid), "lim": lim, "n": MAX_PENDIENTES}).all()]
        copias = [c for c in (_copia(s, eid, p) for p in pids) if c]
    if not copias:
        return {"ahora": _iso(ahora), "copias": []}
    vivas: set = set()
    for x in _leer_espera(s, eid):
        if x.get("pedido_id") not in (None, ""):
            try:
                vivas.add(int(x["pedido_id"]))
            except (TypeError, ValueError):
                pass
        vivas.add(("c", x.get("id")))
    return {"ahora": _iso(ahora), "copias": [_salida_copia(c, _filas(s, eid, c["pedido_id"]), vivas, ahora) for c in copias]}


def resumen_comandas(s: Session, eid: int) -> dict:
    """Para GET /api/pedidos/resumen: cuántas copias esperan imprimirse (pendientes y no viejas) y en cuántos segundos la más próxima
    puede tomarla una estación (None si ninguna). Nunca lanza."""
    try:
        ahora = ahora_cr()
        lim = _iso(ahora - timedelta(minutes=VIGENCIA_MIN))
        filas = s.execute(text("SELECT origen, listo_desde FROM comanda_pedido WHERE empresa_id = :e AND estado = 'pendiente' AND listo_desde >= :lim"),
                          {"e": int(eid), "lim": lim}).all()
        esperas = [_espere_s({"origen": o, "listo_desde": l}, ahora) for o, l in filas]
        return {"comandas_pendientes": len(filas), "comanda_espera_s": min(esperas) if esperas else None}
    except Exception as ex:  # noqa: BLE001
        _log.warning("Resumen de comandas (empresa %s): %s", eid, ex)
        return {"comandas_pendientes": 0, "comanda_espera_s": None}


def limpiar(s: Session, eid: int, forzar: bool = False) -> int:
    """Una vez por hora y por proceso: borra copias y reclamos con listo_desde de hace más de BORRAR_TRAS_DIAS días (ya eran viejas
    desde los 30 min: borrarlas no hace reimprimir nada). Nunca lanza. Devuelve cuántas copias borró."""
    ya = time.monotonic()
    if not forzar and eid in _limpieza and ya - _limpieza[eid] < 3600:
        return 0
    _limpieza[eid] = ya
    try:
        par = {"e": int(eid), "lim": _iso(ahora_cr() - timedelta(days=BORRAR_TRAS_DIAS))}
        s.execute(text("DELETE FROM comanda_reclamo WHERE empresa_id = :e AND pedido_id IN (SELECT pedido_id FROM comanda_pedido WHERE empresa_id = :e "
                       "AND listo_desde < :lim)"), par)
        n = s.execute(text("DELETE FROM comanda_pedido WHERE empresa_id = :e AND listo_desde < :lim"), par).rowcount
        s.commit()
        return int(n or 0)
    except Exception as ex:  # noqa: BLE001
        _log.warning("Limpieza de comandas (empresa %s): %s", eid, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return 0


def _pedido_del_cuerpo(cuerpo) -> int:
    pid = _entero(cuerpo.get("pedido_id")) if isinstance(cuerpo, dict) else None
    if pid is None or pid <= 0:
        raise HTTPException(400, MENSAJE_FALTAN)
    return pid


def _equipo_del_cuerpo(cuerpo) -> str:
    eq = cuerpo.get("equipo")
    if not isinstance(eq, str) or not eq:
        raise HTTPException(400, MENSAJE_FALTAN)
    if not _EQUIPO_RE.fullmatch(eq):
        raise HTTPException(400, MENSAJE_EQUIPO)
    return eq


def _posiciones(v, minimo: int, mensaje: str = MENSAJE_FALTAN) -> list:
    if v is None and minimo == 0:
        return []
    if not isinstance(v, list) or not minimo <= len(v) <= MAX_PLATOS or any(_entero(x) is None or x < 0 for x in v):
        raise HTTPException(400, mensaje)
    return list(dict.fromkeys(v))


def _texto(v, largo: int) -> str:
    return v.strip()[:largo] if isinstance(v, str) else ""


@router.get("/api/pos/comanda/pendientes")
def ruta_pendientes(pedido_id: Optional[str] = None, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: las comandas de pedidos en línea que esperan imprimirse (o, con pedido_id, la de ese pedido en cualquier estado)."""
    pid = None
    if pedido_id not in (None, ""):
        try:
            pid = int(pedido_id)
        except ValueError:
            raise HTTPException(400, MENSAJE_FALTAN)
    limpiar(s, ctx.empresa.id)
    if pid is None:
        _estacion_viva(ctx.empresa.id)
    return pendientes(s, ctx.empresa.id, pid)


def _estacion_viva(eid: int) -> None:
    """4.32 (§4.1): en el programa, la estación de comandas de una pantalla consultó sus pendientes: el programa lo dice a la web
    (estacion_viva) y solo así le asigna pedidos. En la web no hace nada. Nunca lanza."""
    try:
        from . import sinc
        if sinc.MODO_LOCAL:
            from . import sinc_datos_programa as _sdp
            _sdp.marcar_estacion(eid)
    except Exception:  # noqa: BLE001
        pass


@router.post("/api/pos/comanda/reclamar")
def ruta_reclamar(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: reclama (todo o nada) los platos de un grupo de la comanda de un pedido antes de imprimirlos."""
    pid = _pedido_del_cuerpo(cuerpo)
    lineas = _posiciones(cuerpo.get("lineas"), 1)
    grupo = cuerpo.get("grupo")
    grupo = str(grupo) if isinstance(grupo, (str, int)) and not isinstance(grupo, bool) else ""
    momento = cuerpo.get("momento")
    if not 1 <= len(grupo) <= 64 or momento not in MOMENTOS:
        raise HTTPException(400, MENSAJE_FALTAN)
    equipo = _equipo_del_cuerpo(cuerpo)
    return reclamar(s, ctx.empresa.id, pid, lineas, grupo, _texto(cuerpo.get("grupo_nombre"), 60), equipo, _texto(cuerpo.get("nombre"), 60), momento)


@router.post("/api/pos/comanda/impresa")
def ruta_impresa(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: la pantalla imprimió esos platos (y avisa cuáles no van a ninguna impresora)."""
    pid = _pedido_del_cuerpo(cuerpo)
    equipo = _equipo_del_cuerpo(cuerpo)
    return impresa(s, ctx.empresa.id, pid, equipo, _posiciones(cuerpo.get("lineas"), 0), _posiciones(cuerpo.get("sin_comanda"), 0))


@router.post("/api/pos/comanda/soltar")
def ruta_soltar(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: la pantalla no pudo imprimir esos platos y los suelta."""
    pid = _pedido_del_cuerpo(cuerpo)
    equipo = _equipo_del_cuerpo(cuerpo)
    return soltar(s, ctx.empresa.id, pid, equipo, _posiciones(cuerpo.get("lineas"), 0), _texto(cuerpo.get("motivo"), 300))


# ---------------------------------------------------------------------------------------------- respaldos (copias y reclamos)
def leer_comandas(ruta) -> dict:
    """Lo ya resuelto en el archivo de base de la empresa (antes de restaurar): copias que no están «pendiente» y platos «impresa».
    4.32 (revisión n.º 2): `filas`, la copia entera de esos pedidos (las columnas de _COLS_COPIA), para reponerla en el programa si el
    respaldo es anterior a ella.
    {} si no hay archivo, la base es anterior a la 4.31 (sin las tablas) o no se puede leer."""
    import sqlite3
    from pathlib import Path
    if not Path(ruta).exists():
        return {}
    try:
        cx = sqlite3.connect(f"file:{Path(ruta).as_posix()}?mode=ro", uri=True, timeout=30)
        try:
            copias = [(int(p), str(e)) for p, e in cx.execute("SELECT pedido_id, estado FROM comanda_pedido WHERE estado <> 'pendiente'")]
            impresas = [(int(p), int(x)) for p, x in cx.execute("SELECT pedido_id, pos FROM comanda_reclamo WHERE estado = 'impresa'")]
            filas = [dict(zip(_COLS_COPIA, f)) for f in cx.execute(
                f"SELECT {', '.join(_COLS_COPIA)} FROM comanda_pedido WHERE estado <> 'pendiente' "
                "OR pedido_id IN (SELECT pedido_id FROM comanda_reclamo WHERE estado = 'impresa')")]
            return {"copias": copias, "impresas": impresas, "filas": filas}
        finally:
            cx.close()
    except Exception:  # noqa: BLE001  sin las tablas (base anterior a la 4.31) o ilegible: no hay nada que conservar
        return {}


def conservar_comandas(eid: int, filas: dict, ajeno: bool = False) -> int:
    """Después de restaurar la base de la empresa: lo que en este servidor ya estaba impreso, sin comanda o cerrado sigue así en la
    base restaurada (un respaldo viejo no hace reimprimir una comanda). Con un respaldo de otra instalación (`ajeno`, los pedidos son
    otros) no se conserva nada y sus copias pendientes quedan cerradas: nunca se imprimen solas aquí. Devuelve cuántas filas cambió.
    4.32 (revisión n.º 2), solo en el programa: si el respaldo es anterior a la copia de un pedido que aquí ya salió (impresa, sin comanda,
    cerrada o con platos impresos), la copia se repone con cuenta_id = 0. Cuando el goteo vuelve a traer ese pedido, pedidos_programa.ya_tomado
    no la cuenta: la cuenta se vuelve a crear (el respaldo se la llevó), pero guardar_copia no toca una copia que no está pendiente ni la que
    tiene platos impresos, así que cocina no recibe otra vez lo que ya imprimió. En la web no se repone (allí el número de un pedido nuevo
    puede repetirse después de restaurar y su comanda no saldría)."""
    from .db import engine_empresa
    cambios = 0
    ahora = _iso(ahora_cr())
    with Session(engine_empresa(int(eid))) as s:
        if ajeno:
            cambios = s.execute(text("UPDATE comanda_pedido SET estado = 'cerrada', motivo = 'respaldo de otra instalación', actualizado = :a "
                                     "WHERE empresa_id = :e AND estado = 'pendiente'"), {"a": ahora, "e": int(eid)}).rowcount
            s.commit()
            return int(cambios or 0)
        if not filas:
            return 0
        from . import sinc
        if sinc.MODO_LOCAL:
            for f in filas.get("filas") or []:
                if not isinstance(f, dict) or set(f) != set(_COLS_COPIA):
                    continue
                par = {**f, "cuenta_id": 0, "e": int(eid), "a": ahora}
                cambios += s.execute(text(f"INSERT INTO comanda_pedido (empresa_id, {', '.join(_COLS_COPIA)}, actualizado) "
                                          f"SELECT :e, {', '.join(':' + c for c in _COLS_COPIA)}, :a "
                                          "WHERE NOT EXISTS (SELECT 1 FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :pedido_id)"),
                                     par).rowcount
        for pid, estado in filas.get("copias") or []:
            if estado in ("impresa", "sin_comanda", "cerrada"):
                cambios += s.execute(text("UPDATE comanda_pedido SET estado = :st, actualizado = :a WHERE empresa_id = :e AND pedido_id = :pid "
                                          "AND estado = 'pendiente'"), {"st": estado, "a": ahora, "e": int(eid), "pid": int(pid)}).rowcount
        por_pedido: dict = {}
        for pid, pos in filas.get("impresas") or []:
            por_pedido.setdefault(pid, []).append(pos)
        for pid, posiciones in por_pedido.items():
            if s.execute(text("SELECT 1 FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :pid"), {"e": int(eid), "pid": int(pid)}).first():
                cambios += _poner_impresas(s, eid, pid, posiciones, "respaldo", "", ahora)
                _cerrar_si_completa(s, eid, pid)
        s.commit()
    return cambios
