"""Recordatorios de cobro (Configuración › Notificaciones de cobro) y plantillas de correo con variables.

Configuración (registro `notificaciones` por empresa): {proximas: {activo, dias, correo, asunto, cuerpo}, vencimiento: {...},
vencidas: {activo, dias, ...}}. Cada día la cola de Hacienda revisa las facturas a crédito con saldo y manda por correo el
recordatorio que toque (días antes del vencimiento, el día del vencimiento o días después); cada factura recibe cada tipo de
recordatorio una sola vez (registro `recordatorios_enviados`). Lógica pura aquí; el envío está en main.recordatorios_cobro_todas.
"""
import html
import re
from datetime import date, timedelta
from typing import Any, Iterable, Optional

TIPOS = ("proximas", "vencimiento", "vencidas")
CREDITO = ("02", "08", "10")
_VAR = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")


def _g(o: Any, k: str, default: Any = None) -> Any:
    if isinstance(o, dict):
        return o.get(k, default)
    return getattr(o, k, default)


def rellenar(plantilla: Optional[str], variables: dict) -> str:
    """Sustituye {{variable}} por su valor (texto); las desconocidas quedan vacías."""
    return _VAR.sub(lambda m: str(variables.get(m.group(1), "") if variables.get(m.group(1)) is not None else ""), plantilla or "")


def html_de_texto(texto: str, enlace: Optional[str] = None, etiqueta: str = "Ver el comprobante en línea") -> str:
    """Texto plano (con saltos de línea) → HTML seguro, más un botón opcional con el enlace público."""
    cuerpo = html.escape(texto or "").replace("\n", "<br/>")
    boton = (f'<p style="margin-top:18px"><a href="{html.escape(enlace, quote=True)}" style="background:#0f766e;color:#fff;padding:9px 16px;'
             f'border-radius:6px;text-decoration:none;font-weight:600">{html.escape(etiqueta)}</a></p>' if enlace else "")
    return f'<div style="font-family:system-ui,Arial,sans-serif;max-width:620px;color:#1d2433;line-height:1.5">{cuerpo}{boton}</div>'


def saldo_doc(d: Any) -> float:
    return round(float(_g(d, "total", 0) or 0) - float(_g(d, "pagado", 0) or 0) - float(_g(d, "acreditado", 0) or 0), 2)


def seleccionar(cfg: Optional[dict], docs: Iterable[Any], hoy: date, enviados: Iterable[str]) -> list[tuple[Any, str]]:
    """Facturas a crédito aceptadas con saldo que hoy deben recibir un recordatorio: [(documento, tipo)].
    `enviados`: claves "id|tipo" ya mandadas (nunca se repite el mismo recordatorio a la misma factura)."""
    if not isinstance(cfg, dict):
        return []
    hechos = set(enviados or [])
    out = []
    for d in docs:
        if _g(d, "tipo_documento") not in ("01", "02", "09") or (_g(d, "estado") or "") != "aceptado":
            continue
        if (_g(d, "condicion_venta") or "01") not in CREDITO or saldo_doc(d) <= 0.005:
            continue
        venc = str(_g(d, "fecha_vencimiento") or "")[:10]
        if not venc:
            continue
        try:
            fv = date.fromisoformat(venc)
        except ValueError:
            continue
        for tipo in TIPOS:
            c = cfg.get(tipo)
            if not isinstance(c, dict) or not c.get("activo") or c.get("correo") is False:
                continue
            try:
                dias = int(c.get("dias") or 0)
            except (TypeError, ValueError):
                dias = 0
            # ventanas (no fechas exactas): si un día la cola no corrió o el correo falló, se manda al día siguiente; la clave
            # id|tipo evita repetirlo. 'proximas' entre (vence − días) y la víspera; 'vencimiento' del día de vencimiento hasta 3
            # días después; 'vencidas' desde (vence + días) en adelante.
            if tipo == "proximas":
                ok = dias > 0 and fv - timedelta(days=dias) <= hoy < fv
            elif tipo == "vencimiento":
                ok = fv <= hoy <= fv + timedelta(days=3)
            else:
                ok = dias > 0 and hoy >= fv + timedelta(days=dias)
            clave = f"{_g(d, 'id')}|{tipo}"
            if ok and clave not in hechos:
                out.append((d, tipo))
    return out


def variables_doc(d: Any, empresa: Any, cliente_nombre: str, total_txt: str, enlace: Optional[str] = None, hoy: Optional[date] = None) -> dict:
    """Variables comunes de plantillas de correo y recordatorios: {{numero}} {{fecha}} {{vencimiento}} {{total}} {{empresa}}
    {{correo}} {{telefono}} {{cliente}} {{clave}} {{enlace}} {{hoy}}."""
    f = lambda v: "/".join(reversed(str(v or "")[:10].split("-"))) if v else ""   # noqa: E731
    tel = _g(empresa, "telefono")
    return {"numero": _g(d, "consecutivo") or "", "fecha": f(_g(d, "fecha_emision")), "vencimiento": f(_g(d, "fecha_vencimiento")),
            "total": total_txt, "saldo": total_txt, "empresa": _g(empresa, "nombre_comercial") or _g(empresa, "nombre") or "",
            "correo": _g(empresa, "correo") or "", "telefono": f"+506 {tel}" if tel else "", "cliente": cliente_nombre or "",
            "clave": _g(d, "clave") or "", "enlace": enlace or "", "hoy": f((hoy or date.today()).isoformat())}
