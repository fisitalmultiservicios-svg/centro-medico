"""Compras desde los comprobantes recibidos (3.75).

Al aceptar la factura de un proveedor, sus líneas (las del XML) se relacionan con los ítems del inventario: la relación
proveedor + código (o CABYS + descripción) → ítem se guarda en el registro `proveedor_items` y se propone sola la próxima
vez; las líneas sin relación se enlazan a un ítem existente, se crean como ítem nuevo o se dejan fuera (gastos y
servicios). Lo relacionado entra a la bodega como compra (CO-0001…) al costo neto de la factura en colones, abre su capa de
costo y, si la empresa lo tiene configurado, actualiza el costo del ítem (app/inventario.py).
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field as PField
from sqlmodel import Session, select

from . import inventario, modulos, recepcion
from .auth import Contexto, requiere, sesion_empresa
from .config import ahora_cr
from .db import Producto

router = APIRouter(prefix="/api/recepcion", tags=["recepcion"])
CLAVE_RELACIONES = "proveedor_items"
TIPOS_CON_MERCADERIA = ("01", "04", "08", "09")
MOTIVOS = {"relacion": "Relacionado en una factura anterior de este proveedor", "codigo": "Mismo código que el ítem",
           "nombre": "Mismo nombre que el ítem", "cabys": "Mismo CABYS y nombre parecido"}


def _recibido(s: Session, eid: int, rid: int) -> recepcion.Recibido:
    r = s.get(recepcion.Recibido, rid)
    if not r or r.empresa_id != eid:
        raise HTTPException(404, "Comprobante recibido no encontrado")
    return r


def _normal(t: Optional[str]) -> str:
    return " ".join((t or "").lower().split())


def _clave(emisor_id: str, linea: dict) -> str:
    """Llave de la relación: por código del proveedor si lo trae; si no, por CABYS y descripción."""
    codigo = (linea.get("codigo") or "").strip().lower()
    if codigo:
        return f"{emisor_id}|c:{codigo}"
    return f"{emisor_id}|d:{linea.get('cabys') or ''}|{_normal(linea.get('detalle'))[:120]}"


def relaciones(s: Session, eid: int) -> dict:
    x = modulos.leer(s, eid, CLAVE_RELACIONES, {}) or {}
    return x if isinstance(x, dict) else {}


def _guardar_relaciones(s: Session, eid: int, rel: dict) -> None:
    r = modulos._registro(s, eid, CLAVE_RELACIONES)
    modulos.reemplazar(s, eid, CLAVE_RELACIONES, rel, (r.version or 0) if r else None)


def _palabras(t: Optional[str]) -> set:
    return {w for w in _normal(t).split() if len(w) > 3}


def sugerir(lineas: list[dict], rel: dict, productos: list[Producto], emisor_id: str) -> None:
    """Anota en cada línea el ítem propuesto (producto_id) y por qué (motivo): relación guardada, mismo código, mismo
    nombre o mismo CABYS con nombre parecido. Sin propuesta, la línea queda sin ítem."""
    por_id = {p.id: p for p in productos}
    inventariables = [p for p in productos if not p.es_servicio and p.inventariable and p.activo]
    por_codigo: dict[str, Producto] = {}
    por_nombre: dict[str, Producto] = {}
    for p in inventariables:
        if p.codigo and p.codigo.strip():
            por_codigo.setdefault(p.codigo.strip().lower(), p)
        por_nombre.setdefault(_normal(p.nombre), p)
    from .etiquetas import alternos
    for p in inventariables:                         # 4.24: después de los códigos principales, los alternos: el código de fábrica que
        for a in alternos(p):                        # quedó como alterno sigue proponiendo el ítem cuando llega la factura del proveedor
            por_codigo.setdefault(a.lower(), p)
    for l in lineas:
        l["producto_id"], l["motivo"] = None, None
        r = rel.get(_clave(emisor_id, l))
        if r and int(r.get("producto_id") or 0) in por_id:
            l["producto_id"], l["motivo"] = int(r["producto_id"]), "relacion"
            continue
        cod = (l.get("codigo") or "").strip().lower()
        if cod and cod in por_codigo:
            l["producto_id"], l["motivo"] = por_codigo[cod].id, "codigo"
            continue
        nom = _normal(l.get("detalle"))
        if nom and nom in por_nombre:
            l["producto_id"], l["motivo"] = por_nombre[nom].id, "nombre"
            continue
        palabras = _palabras(l.get("detalle"))
        cands = [p for p in inventariables if l.get("cabys") and p.cabys == l.get("cabys")]
        if cands and palabras:
            mejor = max(cands, key=lambda p: len(palabras & _palabras(p.nombre)))
            if palabras & _palabras(mejor.nombre):
                l["producto_id"], l["motivo"] = mejor.id, "cabys"


def _lineas(r: recepcion.Recibido) -> list[dict]:
    ruta = recepcion.DIR_RECIBIDOS / (r.xml_nombre or "")
    if not r.xml_nombre or not ruta.exists():
        raise HTTPException(404, "El XML de este comprobante ya no está disponible")
    try:
        return recepcion.lineas_xml(ruta.read_bytes())
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(400, f"No se pudieron leer las líneas del comprobante: {ex}")


def _tc(r: recepcion.Recibido) -> float:
    return float(r.tipo_cambio or 1) if (r.moneda or "CRC") != "CRC" else 1.0


@router.get("/{rid}/lineas")
def lineas_recibido(rid: int, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """Líneas del comprobante recibido con el ítem propuesto para cada una y el costo unitario neto en colones."""
    eid = ctx.empresa.id
    r = _recibido(s, eid, rid)
    lineas = _lineas(r)
    tc = _tc(r)
    for l in lineas:
        l["costo_crc"] = round(float(l["costo_unitario"]) * tc, 4)
    sugerir(lineas, relaciones(s, eid), s.exec(select(Producto).where(Producto.empresa_id == eid)).all(), r.emisor_id)
    return {"recibido": recepcion.recibido_dict(r), "lineas": lineas, "tipo_cambio": tc, "con_mercaderia": r.tipo_documento in TIPOS_CON_MERCADERIA,
            "config": inventario.config_costeo(s, eid), "motivos": MOTIVOS}


class NuevoItemIn(BaseModel):
    nombre: Optional[str] = None            # vacío = el detalle de la línea
    codigo: Optional[str] = None            # vacío = el código del proveedor
    cabys: Optional[str] = None             # vacío = el CABYS de la línea
    precio: float = PField(0, ge=0)
    categoria: Optional[str] = None
    unidad_medida: Optional[str] = None


class LineaInventarioIn(BaseModel):
    numero: int
    producto_id: Optional[int] = None
    crear: Optional[NuevoItemIn] = None     # sin producto_id ni crear: la línea no entra (gasto o servicio)


class InventarioRecibidoIn(BaseModel):
    bodega_id: Optional[int] = None
    fecha: Optional[str] = None
    actualizar_costo: Optional[bool] = None
    lineas: list[LineaInventarioIn]


@router.post("/{rid}/inventario")
def inventario_recibido(rid: int, data: InventarioRecibidoIn, ctx: Contexto = Depends(requiere("inventario")), s: Session = Depends(sesion_empresa)):
    """Relaciona las líneas con los ítems (o crea ítems nuevos), guarda las relaciones y da entrada a la bodega como compra."""
    from .main import UNIDADES_HACIENDA, _moneda_principal, _validar_producto
    from . import etiquetas
    eid = ctx.empresa.id
    r = _recibido(s, eid, rid)
    if r.respuesta == "07":
        raise HTTPException(409, "Un comprobante rechazado no entra al inventario")
    if r.tipo_documento not in TIPOS_CON_MERCADERIA:
        raise HTTPException(400, "Las notas de crédito y de débito no dan entrada de mercadería")
    if r.inventario_ajuste_id:
        raise HTTPException(409, f"Este comprobante ya entró al inventario ({r.inventario_codigo or r.inventario_ajuste_id})")
    if not data.lineas:
        raise HTTPException(400, "Indique qué líneas entran al inventario")
    por_numero = {l["numero"]: l for l in _lineas(r)}
    tc = _tc(r)
    rel = relaciones(s, eid)
    ahora = ahora_cr().isoformat(timespec="seconds")
    creados, entradas, omitidas, nuevas = [], [], 0, 0
    for li in data.lineas:
        l = por_numero.get(li.numero)
        if l is None:
            raise HTTPException(400, f"La línea {li.numero} no existe en el comprobante")
        if li.producto_id:
            p = inventario._producto(s, eid, li.producto_id)
        elif li.crear is not None:
            n = li.crear
            unidad = (n.unidad_medida or l.get("unidad_medida") or "Unid").strip()
            p = Producto(empresa_id=eid, codigo=((n.codigo or l.get("codigo") or "").strip()[:20] or None), nombre=(n.nombre or l.get("detalle") or "").strip()[:200],
                         cabys=(n.cabys or l.get("cabys") or "").strip(), precio=float(n.precio or 0), moneda=_moneda_principal(s, eid),
                         unidad_medida=unidad if unidad in UNIDADES_HACIENDA else "Unid", es_servicio=False, codigo_tarifa=l.get("codigo_tarifa") or "08",
                         tarifa=float(l["tarifa"]) if l.get("tarifa") is not None else 13.0, tipo="Producto", categoria=(n.categoria or "").strip() or None,
                         costo=round(float(l["costo_unitario"]) * tc, 4), inventariable=True, es_venta=True)
            try:
                _validar_producto(p)
            except HTTPException as ex:
                raise HTTPException(400, f"Línea {li.numero}: {ex.detail}")
            # 4.24: el código no se repite. El que escribió el usuario y ya es de otro ítem se rechaza (con su nombre); el del
            # proveedor (el campo vacío, o el mismo que la pantalla ya trae puesto) no entra como código si ya es de otro ítem
            if (n.codigo or "").strip() and p.codigo != (l.get("codigo") or "").strip()[:20]:
                etiquetas.exigir_codigo_libre(s, eid, p.codigo, prefijo=f"Línea {li.numero}: ")
            elif p.codigo and etiquetas.otro_con_codigo(s, eid, p.codigo) is not None:
                p.codigo = None
            s.add(p); s.flush()
            creados.append({"id": p.id, "nombre": p.nombre})
        else:
            omitidas += 1
            continue
        k = _clave(r.emisor_id, l)
        if int((rel.get(k) or {}).get("producto_id") or 0) != p.id:
            rel[k] = {"producto_id": p.id, "emisor_id": r.emisor_id, "emisor": r.emisor_nombre, "codigo": l.get("codigo") or "", "cabys": l.get("cabys") or "",
                      "detalle": (l.get("detalle") or "")[:120], "actualizado": ahora}
            nuevas += 1
        if p.es_servicio or not p.inventariable or float(l.get("cantidad") or 0) <= 0:
            omitidas += 1
            continue
        entradas.append(inventario.LineaCompraIn(producto_id=p.id, cantidad=float(l["cantidad"]), costo_unitario=float(l["costo_unitario"])))
    if nuevas:
        _guardar_relaciones(s, eid, rel)
    if not entradas:
        s.commit()
        return {"ajuste": None, "creados": creados, "relaciones": nuevas, "omitidas": omitidas, "entradas": 0}
    numero = r.consecutivo or (r.clave or "")[21:41]
    detalle = inventario.registrar_compra(s, eid, inventario.CompraInventarioIn(bodega_id=data.bodega_id, fecha=data.fecha, numero=numero, proveedor=r.emisor_nombre,
                                                                                tipo_cambio=tc, actualizar_costo=data.actualizar_costo, lineas=entradas), recibido=r)
    return {"ajuste": detalle, "creados": creados, "relaciones": nuevas, "omitidas": omitidas, "entradas": len(entradas)}
