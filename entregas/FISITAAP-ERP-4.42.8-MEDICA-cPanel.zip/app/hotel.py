"""Hotel (2.2): reglas del servidor para las reservaciones guardadas en el registro `hotel_reservas`.

La interfaz lleva las reservas, los bloqueos, las habitaciones y las cuentas de los huéspedes como registros por empresa
(app/modulos.py). El servidor solo vigila lo que dos recepcionistas podrían pisar a la vez: que una habitación no quede con
dos reservas (o una reserva y un bloqueo) en la misma noche. Una estadía del 17 al 19 ocupa las noches del 17 y del 18: el día
de salida queda libre para otra llegada. Funciones puras, probadas en tests/test_hotel.py."""
import re
from typing import Iterable

OCUPAN = {"pendiente", "confirmada", "en_casa"}          # estados que ocupan la habitación (cancelada, no_show y salio no)
_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def ocupa(r: dict) -> bool:
    if not isinstance(r, dict):
        return False
    return r.get("tipo") == "bloqueo" or r.get("estado") in OCUPAN


def _fechas_validas(r: dict) -> str | None:
    if r.get("tipo") == "folio":                     # cuenta externa (3.0): sin habitación ni noches
        return None
    ll, sa = str(r.get("llegada") or ""), str(r.get("salida") or "")
    if not (_FECHA.match(ll) and _FECHA.match(sa)):
        return f"{r.get('numero') or 'La reserva'}: indique las fechas de llegada y salida"
    if sa <= ll:
        return f"{r.get('numero') or 'La reserva'}: la salida debe ser posterior a la llegada"
    return None


def se_cruzan(a: dict, b: dict) -> bool:
    """Misma habitación y noches en común (el día de salida de una puede ser el de llegada de la otra)."""
    ha, hb = a.get("habitacion_id"), b.get("habitacion_id")
    if not ha or ha != hb:
        return False
    return str(a.get("llegada") or "") < str(b.get("salida") or "") and str(b.get("llegada") or "") < str(a.get("salida") or "")


def _etiqueta(r: dict) -> str:
    if r.get("tipo") == "bloqueo":
        return "el bloqueo " + str(r.get("motivo") or "")[:40]
    return "la reserva " + str(r.get("numero") or "") + (" de " + str(r.get("huesped_nombre"))[:40] if r.get("huesped_nombre") else "")


def conflictos(existentes: Iterable[dict], upserts: Iterable[dict], deletes: Iterable = ()) -> list[str]:
    """Mensajes de error si al aplicar `upserts`/`deletes` sobre `existentes` alguna habitación queda con dos ocupantes en la
    misma noche, o si una reserva trae fechas inválidas. Lista vacía = todo bien."""
    borrar = {str(d) for d in (deletes or [])}
    mapa = {str(r.get("id")): r for r in existentes if isinstance(r, dict) and str(r.get("id")) not in borrar}
    nuevos = [u for u in upserts if isinstance(u, dict)]
    errores: list[str] = []
    for u in nuevos:
        if not ocupa(u):
            mapa[str(u.get("id"))] = u
            continue
        e = _fechas_validas(u)
        if e:
            errores.append(e)
            continue
        mapa[str(u.get("id"))] = u
    for u in nuevos:
        if not ocupa(u) or _fechas_validas(u):
            continue
        for k, otro in mapa.items():
            if k == str(u.get("id")) or not ocupa(otro):
                continue
            if se_cruzan(u, otro):
                errores.append(f"La habitación ya está ocupada esas noches por {_etiqueta(otro)} ({otro.get('llegada')} al {otro.get('salida')}). "
                               f"Elija otra habitación o cambie las fechas de {_etiqueta(u)}.")
                break
    return errores


# ============================================================================= 2.3: iCal, plantillas y tareas diarias
import hashlib  # noqa: E402
import hmac as _hmac  # noqa: E402
import re as _re  # noqa: E402
from datetime import date, timedelta  # noqa: E402


def token_ical(secreto: bytes, eid: int, hab_id: int) -> str:
    """Token del enlace público del calendario de una habitación: HMAC del secreto del servidor (no se guarda nada)."""
    return _hmac.new(secreto, f"ical:{eid}:{hab_id}".encode(), hashlib.sha256).hexdigest()[:24]


def _fecha_ical(v: str) -> str:
    m = _re.match(r"^(\d{4})(\d{2})(\d{2})", v.strip())
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else ""


def _esc_ical(t) -> str:
    return str(t).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def exportar_ical(reservas: list, hab_id: int, nombre_hotel: str, hab_numero: str) -> str:
    """Calendario iCalendar (texto) con las noches ocupadas de una habitación: reservas vigentes y bloqueos propios (no los que
    vinieron de otro canal). Booking y Airbnb lo leen cada pocas horas y cierran esas fechas."""
    lineas = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//FISITAAP ERP//Hotel//ES", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
              "X-WR-CALNAME:" + _esc_ical(f"{nombre_hotel} - Hab. {hab_numero}")]
    for r in reservas:
        if not isinstance(r, dict) or r.get("habitacion_id") != hab_id or not ocupa(r) or r.get("origen") == "ical":
            continue
        ll, sa = str(r.get("llegada") or "")[:10].replace("-", ""), str(r.get("salida") or "")[:10].replace("-", "")
        if len(ll) != 8 or len(sa) != 8:
            continue
        resumen = "No disponible" if r.get("tipo") == "bloqueo" else "Reservado"
        lineas += ["BEGIN:VEVENT", f"UID:gf-{hab_id}-{r.get('id')}@grupofactura", f"DTSTAMP:{ll}T000000Z", f"DTSTART;VALUE=DATE:{ll}",
                   f"DTEND;VALUE=DATE:{sa}", "SUMMARY:" + _esc_ical(resumen), "END:VEVENT"]
    lineas.append("END:VCALENDAR")
    return "\r\n".join(lineas) + "\r\n"


def parsear_ical(texto: str) -> list[dict]:
    """Eventos [{uid, desde, hasta, resumen}] de un iCalendar (Booking, Airbnb, Google). Las líneas continuadas (espacio
    inicial) se unen; las fechas con hora se recortan al día; sin DTEND se toma una noche."""
    lineas: list[str] = []
    for ln in str(texto or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if ln[:1] in (" ", "\t") and lineas:
            lineas[-1] += ln[1:]
        else:
            lineas.append(ln)
    eventos: list[dict] = []
    actual = None
    for ln in lineas:
        k, _, v = ln.partition(":")
        k = k.split(";")[0].upper().strip()
        if ln.strip() == "BEGIN:VEVENT":
            actual = {"uid": "", "desde": "", "hasta": "", "resumen": ""}
        elif ln.strip() == "END:VEVENT":
            if actual and actual["desde"]:
                if not actual["hasta"] or actual["hasta"] <= actual["desde"]:
                    actual["hasta"] = (date.fromisoformat(actual["desde"]) + timedelta(days=1)).isoformat()
                eventos.append(actual)
            actual = None
        elif actual is not None:
            if k == "UID":
                actual["uid"] = v.strip()[:120]
            elif k == "DTSTART":
                actual["desde"] = _fecha_ical(v)
            elif k == "DTEND":
                actual["hasta"] = _fecha_ical(v)
            elif k == "SUMMARY":
                actual["resumen"] = v.strip()[:80]
    return eventos


def sincronizar_ical(reservas: list, hab_id: int, fuente: str, eventos: list[dict], hoy: str, hab_numero: str = "") -> tuple[list[dict], list, list[str]]:
    """Convierte los eventos importados de una fuente (Booking, Airbnb) en bloqueos de la habitación. Devuelve (upserts,
    deletes, avisos): se crean los nuevos, se actualizan los que cambiaron de fechas, se quitan los que ya no vienen (solo
    futuros) y se avisa de los que chocan con una reserva propia (esos no se crean: hay que resolverlos a mano)."""
    # lo propio: reservas y bloqueos del hotel; lo que vino de otro canal por iCal no cuenta (Booking y Airbnb suelen traer la misma fecha)
    propios = [r for r in reservas if isinstance(r, dict) and r.get("habitacion_id") == hab_id and ocupa(r) and r.get("origen") != "ical"]
    existentes = {str(r.get("uid")): r for r in reservas if isinstance(r, dict) and r.get("origen") == "ical" and r.get("fuente") == fuente and r.get("habitacion_id") == hab_id}
    upserts, avisos, vistos = [], [], set()
    for ev in eventos:
        uid = ev.get("uid") or f"{ev.get('desde')}_{ev.get('hasta')}"
        if ev["hasta"] < hoy:
            continue
        vistos.add(uid)
        nuevo = {"tipo": "bloqueo", "estado": "bloqueo", "origen": "ical", "fuente": fuente, "uid": uid, "habitacion_id": hab_id, "llegada": ev["desde"], "salida": ev["hasta"],
                 "motivo": f"{fuente}: {ev.get('resumen') or 'reservado'}"[:80], "numero": "ICAL", "huesped_nombre": ""}
        choque = next((p for p in propios if se_cruzan(nuevo, p)), None)
        if choque:
            avisos.append(f"Hab. {hab_numero or hab_id}: {fuente} trae del {ev['desde']} al {ev['hasta']} y choca con {_etiqueta(choque)} ({choque.get('llegada')} al {choque.get('salida')})")
            continue
        ya = existentes.get(uid)
        if ya is None:
            upserts.append(nuevo)
        elif ya.get("llegada") != nuevo["llegada"] or ya.get("salida") != nuevo["salida"] or ya.get("motivo") != nuevo["motivo"]:
            upserts.append({**ya, **nuevo, "id": ya["id"]})
    deletes = [r["id"] for uid, r in existentes.items() if uid not in vistos and str(r.get("salida") or "") >= hoy]
    return upserts, deletes, avisos


# ----------------------------------------------------------------------------- plantillas de mensajes (mismos campos que la interfaz)
_DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
_MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "setiembre", "octubre", "noviembre", "diciembre"]
MENSAJE_ADELANTO = "Hola {huesped}, su reserva {numero} en {hotel} del {llegada} al {salida} está pendiente del adelanto de {adelanto}. Al recibirlo queda confirmada.\n\n{politicas}"
MENSAJE_LLEGADA = "Hola {huesped}, le esperamos en {hotel} el {llegada} (entrada desde las {hora_entrada}). Reserva {numero}, {categoria}, {noches} noche(s).\n\n{wifi}\n\n¡Buen viaje!"


def fecha_larga(iso) -> str:
    try:
        d = date.fromisoformat(str(iso)[:10])
    except (TypeError, ValueError):
        return str(iso or "")
    return f"{_DIAS[d.weekday()]} {d.day} de {_MESES[d.month - 1]} de {d.year}"


def _monto(v, moneda: str) -> str:
    try:
        n = float(v or 0)
    except (TypeError, ValueError):
        n = 0.0
    txt = f"{n:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("₡" if moneda == "CRC" else "$" if moneda == "USD" else moneda + " ") + txt


def texto_plantilla(plantilla, r: dict, h, cfg: dict, categorias: list, habitaciones: list, nombre_empresa: str) -> str:
    cat = next((c for c in categorias if isinstance(c, dict) and c.get("id") == r.get("categoria_id")), None)
    hab = next((x for x in habitaciones if isinstance(x, dict) and x.get("id") == r.get("habitacion_id")), None)
    try:
        noches = (date.fromisoformat(str(r.get("salida"))[:10]) - date.fromisoformat(str(r.get("llegada"))[:10])).days
    except (TypeError, ValueError):
        noches = 0
    rep = {"huesped": r.get("huesped_nombre") or (h or {}).get("nombre") or "", "numero": r.get("numero") or "", "hotel": cfg.get("nombre") or nombre_empresa,
           "llegada": fecha_larga(r.get("llegada")), "salida": fecha_larga(r.get("salida")), "hora_entrada": cfg.get("hora_entrada") or "", "hora_salida": cfg.get("hora_salida") or "",
           "categoria": cat.get("nombre") if cat else "", "habitacion": hab.get("numero") if hab else "", "noches": str(noches),
           "personas": str(int(r.get("adultos") or 0) + int(r.get("ninos") or 0)), "total": _monto(r.get("total"), r.get("moneda") or "USD"),
           "adelanto": _monto(r.get("adelanto_requerido"), r.get("moneda") or "USD"), "politicas": cfg.get("politicas") or "", "wifi": cfg.get("wifi") or ""}
    return _re.sub(r"\{(\w+)\}", lambda m: rep.get(m.group(1), m.group(0)), str(plantilla or ""))


# ----------------------------------------------------------------------------- tareas diarias (cron)
def cargo_hospedaje(r: dict, fecha: str, cfg: dict, hab_numero: str) -> dict:
    t = float(cfg.get("tarifa_iva") or 0)
    bruto = float(r.get("tarifa_noche") or 0)
    precio = round(bruto / (1 + t / 100), 2) if cfg.get("precios_incluyen_iva", True) else bruto
    d = date.fromisoformat(fecha)
    return {"reserva_id": r.get("id"), "tipo": "cargo", "origen": "hospedaje", "fecha": fecha, "detalle": f"Hospedaje hab. {hab_numero} · noche del {d.day} {_MESES[d.month - 1][:3]} (salida tardía)",
            "cantidad": 1, "precio": precio, "tarifa": t, "codigo_tarifa": cfg.get("codigo_tarifa") or "08", "cabys": cfg.get("cabys_hospedaje") or "6311100000000",
            "moneda": r.get("moneda") or cfg.get("moneda") or "USD", "producto_id": None, "usuario": "sistema"}


def tareas_diarias(reservas: list, huespedes: list, habitaciones: list, cfg: dict, hoy: str, ahora_iso: str) -> dict:
    """Decide qué toca hoy (función pura; main envía los correos y guarda):
    - no presentado: pendientes o confirmadas cuya llegada pasó hace `no_show_dias` días o más (si no_show_auto);
    - salida tardía: en casa con la salida ya pasada: se carga cada noche de más y la salida se corre a hoy (si salida_tardia_auto);
    - recordatorio de adelanto: pendientes con llegada en `recordatorio_adelanto_dias` días o menos, una sola vez;
    - recordatorio de llegada: confirmadas que llegan en `recordatorio_llegada_dias` días, una sola vez.
    Devuelve {upserts, cargos, correos: [{reserva, huesped, tipo}], resumen}."""
    out = {"upserts": [], "cargos": [], "correos": [], "resumen": {"no_show": 0, "salida_tardia": 0, "recordatorio_adelanto": 0, "recordatorio_llegada": 0, "liberadas": 0}}
    h = date.fromisoformat(hoy)
    ns_dias = int(cfg.get("no_show_dias") or 1) if cfg.get("no_show_auto", True) else 0
    plazo_adel = int(cfg.get("adelanto_plazo_dias") or 0)          # liberar la reserva pendiente de adelanto pasados N días (3.21)
    adel_dias = int(cfg.get("recordatorio_adelanto_dias") or 0) if cfg.get("recordatorio_adelanto", True) else 0
    lleg_dias = int(cfg.get("recordatorio_llegada_dias") or 0) if cfg.get("recordatorio_llegada", True) else 0
    hus = {x.get("id"): x for x in huespedes if isinstance(x, dict)}
    habs = {x.get("id"): x for x in habitaciones if isinstance(x, dict)}
    for r in reservas:
        if not isinstance(r, dict) or r.get("tipo") == "bloqueo":
            continue
        try:
            ll, sa = date.fromisoformat(str(r.get("llegada"))[:10]), date.fromisoformat(str(r.get("salida"))[:10])
        except (TypeError, ValueError):
            continue
        rec = dict(r.get("recordatorios") or {})
        hist = list(r.get("historial") or [])
        cambio = None
        creada = str(r.get("creado") or "")[:10]
        try:
            dias_creada = (h - date.fromisoformat(creada)).days if len(creada) == 10 else -1
        except ValueError:
            dias_creada = -1
        if r.get("estado") == "pendiente" and plazo_adel > 0 and dias_creada >= plazo_adel and ll > h:
            cambio = {**r, "estado": "cancelada", "motivo_cancelacion": f"Automático: el adelanto no llegó en {plazo_adel} días",
                      "historial": hist + [{"fecha": ahora_iso, "usuario": "sistema", "texto": f"Cancelada automáticamente: sin adelanto {plazo_adel} día(s) después de crearla; la habitación queda libre"}]}
            out["resumen"]["liberadas"] += 1
        elif r.get("estado") in ("pendiente", "confirmada") and ns_dias > 0 and (h - ll).days >= ns_dias:
            cambio = {**r, "estado": "no_show", "motivo_cancelacion": "Automático: no se presentó",
                      "historial": hist + [{"fecha": ahora_iso, "usuario": "sistema", "texto": f"Marcada como no presentada automáticamente ({(h - ll).days} día(s) después de la llegada prevista)"}]}
            out["resumen"]["no_show"] += 1
        elif r.get("estado") == "en_casa" and sa < h and cfg.get("salida_tardia_auto", True):
            noches = [(sa + timedelta(days=i)).isoformat() for i in range((h - sa).days)]
            num = str((habs.get(r.get("habitacion_id")) or {}).get("numero") or "")
            for f in noches:
                out["cargos"].append(cargo_hospedaje(r, f, cfg, num))
            cambio = {**r, "salida": hoy, "noches": (h - ll).days, "total": round(float(r.get("tarifa_noche") or 0) * (h - ll).days, 2),
                      "historial": hist + [{"fecha": ahora_iso, "usuario": "sistema", "texto": "Salida tardía: se cargó la noche del " + ", ".join(fecha_larga(f) for f in noches) + " y la salida se corrió a hoy"}]}
            out["resumen"]["salida_tardia"] += 1
        elif r.get("estado") == "pendiente" and adel_dias > 0 and 0 <= (ll - h).days <= adel_dias and not rec.get("adelanto"):
            hu = hus.get(r.get("huesped_id"))
            if hu and "@" in str(hu.get("correo") or ""):
                out["correos"].append({"reserva": r, "huesped": hu, "tipo": "adelanto"})
                rec["adelanto"] = hoy
                cambio = {**r, "recordatorios": rec, "historial": hist + [{"fecha": ahora_iso, "usuario": "sistema", "texto": "Recordatorio de adelanto enviado a " + str(hu["correo"])}]}
                out["resumen"]["recordatorio_adelanto"] += 1
        elif r.get("estado") == "confirmada" and lleg_dias > 0 and (ll - h).days == lleg_dias and not rec.get("llegada"):
            hu = hus.get(r.get("huesped_id"))
            if hu and "@" in str(hu.get("correo") or ""):
                out["correos"].append({"reserva": r, "huesped": hu, "tipo": "llegada"})
                rec["llegada"] = hoy
                cambio = {**r, "recordatorios": rec, "historial": hist + [{"fecha": ahora_iso, "usuario": "sistema", "texto": "Recordatorio de llegada enviado a " + str(hu["correo"])}]}
                out["resumen"]["recordatorio_llegada"] += 1
        if cambio is not None:
            cambio["historial"] = cambio["historial"][-60:]
            out["upserts"].append(cambio)
    return out
