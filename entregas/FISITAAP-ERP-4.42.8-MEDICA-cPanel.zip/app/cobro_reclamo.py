# -*- coding: utf-8 -*-
"""4.31 (la misma mesa, tercera vuelta): el cobro de una cuenta de la caja (pos_espera) se pide al servidor antes de emitir.

Dos equipos que cobraban la misma mesa a la vez, o con un segundo de diferencia (la cuenta completa, «Cobrar parte k de n» o «cobrar
ahora solo esos»), emitían los dos y la cuenta se cobraba de más. Ahora la caja, después de que el cajero confirma el cobro y antes de
emitir el comprobante, pide el cobro de ESA cuenta (POST /api/pos/cobro/reclamar). Solo una pestaña lo tiene a la vez (vence a los 60 s,
por si la pestaña se cierra a medias); la otra no emite y se pone al día. Al terminar (bien o mal) la caja lo suelta
(POST /api/pos/cobro/soltar) y, si emitió, deja anotados los platos cobrados (sus `lid`): un equipo atrasado que llega después con esos
mismos platos tampoco emite.

- Una fila por cuenta (ux_cobro_reclamo). Tomar es todo o nada, en una transacción: INSERT ... WHERE NOT EXISTS y, si ya había fila, un
  UPDATE con la condición (libre, vencida o de la misma pestaña), como comandas.reclamar.
- `cobros` (cobro por partes o «cobrar ahora solo esos»): cuántos cobros tenía la cuenta cuando la pantalla armó la parte. Si la cuenta
  guardada ya tiene más, otro equipo cobró una parte mientras tanto (la parte de esta pantalla ya no es la que corresponde).
- La pantalla cobra como siempre, sin pedir nada, sin conexión, con un servidor sin esta ruta (404) y en la venta rápida o de mostrador
  sin cuenta guardada. Ante un error del servidor al reclamar, la respuesta es «ocupada» (no se emite: lo más seguro).
- 4.31 (séptima vuelta) `pares` (solo el cobro de una parte con 2x1): lo que quedó en la cuenta del mismo plato. La respuesta dice cuáles ya
  están cobrados (`pares_cobrados`): solo con eso lo que vuelve de la parte al cancelarla conserva el 2x1.
- Es de ESTE servidor, como comanda_reclamo: ninguna lista de sinc la nombra. El programa de escritorio corre el mismo servidor y la
  misma regla."""
import json
import logging
import re
import time
from datetime import datetime, timedelta
from typing import Any, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import text
from sqlmodel import Session

from .auth import Contexto, requiere, sesion_empresa
from .config import ahora_cr

router = APIRouter(tags=["pos"])
_log = logging.getLogger(__name__)

VENCE_S = 60                      # un reclamo que nadie soltó (pestaña cerrada a medias) vence solo
MAX_LIDS = 300                    # platos por cobro
MAX_COBRADAS = 1000               # platos cobrados que se recuerdan por cuenta (los últimos)
BORRAR_TRAS_DIAS = 2
MENSAJE_FALTAN = "Faltan datos del cobro: cuenta, equipo y clave."
MENSAJE_EQUIPO = "El identificador de esta computadora no es válido: actualice la página."
_CLAVE_RE = re.compile(r"[A-Za-z0-9_-]{8,64}")
_limpieza: dict = {}              # empresa → última limpieza en este proceso (time.monotonic)


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def _lista(txt) -> list:
    try:
        v = json.loads(txt or "[]")
    except (TypeError, ValueError):
        return []
    return [x for x in v if isinstance(x, str)] if isinstance(v, list) else []


def _fila(s: Session, eid: int, cuenta_id: int) -> Optional[dict]:
    f = s.execute(text("SELECT estado, equipo, clave, lids, cobradas, vence FROM cobro_reclamo WHERE empresa_id = :e AND cuenta_id = :c"),
                  {"e": int(eid), "c": int(cuenta_id)}).first()
    if f is None:
        return None
    return {"estado": f[0] or "", "equipo": f[1] or "", "clave": f[2] or "", "lids": _lista(f[3]), "cobradas": _lista(f[4]), "vence": f[5] or "",
            "lids_txt": f[3] or "[]", "cobradas_txt": f[4] or "[]"}


def _cobros_de(s: Session, eid: int, cuenta_id: int) -> Optional[int]:
    """Cuántos cobros tiene anotados la cuenta guardada (None si no está o no se pudo leer: no se compara)."""
    from . import modulos
    try:
        for x in modulos.leer(s, eid, "pos_espera", []) or []:
            if isinstance(x, dict) and x.get("id") == cuenta_id and not isinstance(x.get("id"), bool):
                c = x.get("cobros")
                return len(c) if isinstance(c, list) else 0
    except Exception as ex:  # noqa: BLE001  (sin la cuenta legible no se compara: el reclamo sigue valiendo)
        _log.info("Cobro de la cuenta %s: no se pudo leer la cuenta: %s", cuenta_id, ex)
    return None


def _comunes(lids: list, otros) -> list:
    o = set(otros)
    return [x for x in lids if x in o]


def _partidos(s: Session, eid: int, cuenta_id: int, lids: list, restos: list) -> list:
    """4.31 (sexta vuelta): los platos de esta parte que otro equipo partió a la vez: la cuenta guardada tiene lo que quedó de ellos (`de`) y no
    es lo que dejó esta pantalla (`restos`). Esa porción ya está en la parte del otro: aquí no se cobra ni vuelve a la cuenta (se cobraba dos
    veces). Sin la cuenta legible, ninguno."""
    from . import modulos
    try:
        for x in modulos.leer(s, eid, "pos_espera", []) or []:
            if isinstance(x, dict) and x.get("id") == cuenta_id and not isinstance(x.get("id"), bool):
                mios = set(restos)
                de = {l.get("de") for l in (x.get("lineas") if isinstance(x.get("lineas"), list) else [])
                      if isinstance(l, dict) and isinstance(l.get("de"), str) and l.get("de") and l.get("lid") not in mios}
                return [i for i in lids if i in de]
    except Exception as ex:  # noqa: BLE001  (sin la cuenta legible no se compara: el reclamo sigue valiendo)
        _log.info("Cobro de la cuenta %s: no se pudo leer la cuenta: %s", cuenta_id, ex)
    return []


def reclamar(s: Session, eid: int, cuenta_id: int, equipo: str, clave: str, lids: list, cobros: Optional[int] = None,
             restos: Optional[list] = None, pares: Optional[list] = None) -> dict:
    """Toma el cobro de la cuenta para `equipo` (la pestaña) con `clave` (la de este cobro): todo o nada, en una transacción.
    Resultados: ganada | ocupada (otra pestaña la está cobrando) | cobrada (esos platos ya se cobraron, también mientras la otra pestaña
    termina su cobro) | partida (4.31, sexta vuelta: solo una parte, que dice sus `restos`: otro equipo partió esos mismos platos a la vez)
    | cambiada (otro equipo cobró una parte desde que se armó esta). `comunes`: los platos de este cobro que el otro tiene, ya cobró o
    partió. 4.31 (séptima vuelta): si vienen `pares` (el par del 2x1 de la parte), `pares_cobrados`: los que ya están cobrados."""
    ahora = ahora_cr()
    a, vence = _iso(ahora), _iso(ahora + timedelta(seconds=VENCE_S))
    par = {"e": int(eid), "c": int(cuenta_id), "eq": equipo, "k": clave, "l": json.dumps(lids), "v": vence, "a": a}

    def con_pares(res: dict, cobradas: list) -> dict:
        if pares is not None:
            res["pares_cobrados"] = _comunes(pares, cobradas)
        return res
    try:
        tomada = s.execute(text("INSERT INTO cobro_reclamo (empresa_id, cuenta_id, estado, equipo, clave, lids, cobradas, vence, hora) "
                                "SELECT :e, :c, 'reclamada', :eq, :k, :l, '[]', :v, :a "
                                "WHERE NOT EXISTS (SELECT 1 FROM cobro_reclamo WHERE empresa_id = :e AND cuenta_id = :c)"), par).rowcount
        if not tomada:   # libre, vencida o de esta misma pestaña (el cobro siguiente de la misma caja no espera al anterior)
            tomada = s.execute(text("UPDATE cobro_reclamo SET estado = 'reclamada', equipo = :eq, clave = :k, lids = :l, vence = :v, hora = :a "
                                    "WHERE empresa_id = :e AND cuenta_id = :c AND (estado <> 'reclamada' OR vence < :a OR equipo = :eq)"), par).rowcount
        if not tomada:
            s.rollback()
            f = _fila(s, eid, cuenta_id) or {"lids": [], "cobradas": [], "vence": ""}
            # 4.31 (cuarta vuelta): lo que este cobro tiene en común con el otro ya se emitió (el otro todavía termina pagos y Bancos):
            # «cobrada», así la pantalla descarta esos platos en el acto en lugar de esperar a que el otro suelte
            ya = _comunes(lids, f["cobradas"])
            if ya and not _comunes([x for x in lids if x not in set(ya)], f["lids"]):
                return con_pares({"resultado": "cobrada", "comunes": ya}, f["cobradas"])
            return con_pares({"resultado": "ocupada", "vence": f["vence"], "comunes": _comunes(lids, f["lids"] + f["cobradas"])}, f["cobradas"])
        f = _fila(s, eid, cuenta_id) or {"cobradas": []}
        ya = _comunes(lids, f["cobradas"])
        if ya:
            s.rollback()
            return con_pares({"resultado": "cobrada", "comunes": ya}, f["cobradas"])
        if restos is not None:
            partidos = _partidos(s, eid, cuenta_id, lids, restos)
            if partidos:
                s.rollback()
                return con_pares({"resultado": "partida", "comunes": partidos}, f["cobradas"])
        if cobros is not None:
            n = _cobros_de(s, eid, cuenta_id)
            if n is not None and n > cobros:
                s.rollback()
                return con_pares({"resultado": "cambiada", "comunes": []}, f["cobradas"])
        s.commit()
    except Exception as ex:  # noqa: BLE001  (índice único u otro choque: no ganó)
        _log.info("Cobro de la cuenta %s no reclamado: %s", cuenta_id, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return {"resultado": "ocupada", "vence": "", "comunes": []}
    return con_pares({"resultado": "ganada", "vence": vence}, f["cobradas"])


def soltar(s: Session, eid: int, cuenta_id: int, clave: str, cobrado: bool, lids: list, sigue: bool = False) -> dict:
    """La pantalla terminó el cobro (bien o mal). Si se emitió (`cobrado`), sus platos quedan anotados como cobrados aunque el reclamo ya
    no sea suyo. Suelta solo el reclamo de ESA clave (uno vencido que tomó otra pestaña no se toca). `sigue`: ya se emitió y el cobro
    todavía termina (pagos, Bancos): se anotan los platos y el reclamo se alarga, sin soltarlo. Nunca lanza."""
    a = ahora_cr()
    ahora, vence = _iso(a), _iso(a + timedelta(seconds=VENCE_S))
    for _ in range(3):
        try:
            f = _fila(s, eid, cuenta_id)
            if f is None:
                if cobrado and lids:     # el reclamo no llegó (la respuesta se perdió) o ya se borró: igual quedan anotados
                    s.execute(text("INSERT INTO cobro_reclamo (empresa_id, cuenta_id, estado, equipo, clave, lids, cobradas, vence, hora) "
                                   "SELECT :e, :c, 'libre', '', '', '[]', :cb, '', :a "
                                   "WHERE NOT EXISTS (SELECT 1 FROM cobro_reclamo WHERE empresa_id = :e AND cuenta_id = :c)"),
                              {"e": int(eid), "c": int(cuenta_id), "cb": json.dumps(list(dict.fromkeys(lids))[-MAX_COBRADAS:]), "a": ahora})
                    s.commit()
                return {"resultado": "no_era_suya"}
            suya = f["estado"] == "reclamada" and f["clave"] == clave
            cobradas = f["cobradas"]
            if cobrado:
                ya = set(cobradas)
                for x in (f["lids"] if suya else []) + list(lids):
                    if x not in ya:
                        cobradas.append(x); ya.add(x)
                cobradas = cobradas[-MAX_COBRADAS:]
            if suya and sigue:
                estado, lids_txt, v = "reclamada", f["lids_txt"], vence
            elif suya:
                estado, lids_txt, v = "libre", "[]", f["vence"]
            else:
                estado, lids_txt, v = f["estado"], f["lids_txt"], f["vence"]
            n = s.execute(text("UPDATE cobro_reclamo SET estado = :st, lids = :l, cobradas = :cb, vence = :v, hora = :a WHERE empresa_id = :e "
                               "AND cuenta_id = :c AND estado = :st0 AND clave = :k0 AND cobradas = :cb0"),
                          {"st": estado, "l": lids_txt, "cb": json.dumps(cobradas), "v": v, "a": ahora, "e": int(eid), "c": int(cuenta_id),
                           "st0": f["estado"], "k0": f["clave"], "cb0": f["cobradas_txt"]}).rowcount
            if not n:                    # cambió entre la lectura y la escritura: otra vuelta
                s.rollback()
                continue
            s.commit()
            return {"resultado": "ok" if suya else "no_era_suya"}
        except Exception as ex:  # noqa: BLE001
            _log.info("Cobro de la cuenta %s: no se pudo soltar: %s", cuenta_id, ex)
            try:
                s.rollback()
            except Exception:  # noqa: BLE001
                pass
    return {"resultado": "no_era_suya"}


def limpiar(s: Session, eid: int, forzar: bool = False) -> int:
    """Una vez por hora y por proceso: borra los reclamos libres o vencidos de hace más de BORRAR_TRAS_DIAS días. Nunca lanza."""
    ya = time.monotonic()
    if not forzar and eid in _limpieza and ya - _limpieza[eid] < 3600:
        return 0
    _limpieza[eid] = ya
    try:
        ahora = ahora_cr()
        n = s.execute(text("DELETE FROM cobro_reclamo WHERE empresa_id = :e AND hora < :lim AND (estado <> 'reclamada' OR vence < :a)"),
                      {"e": int(eid), "lim": _iso(ahora - timedelta(days=BORRAR_TRAS_DIAS)), "a": _iso(ahora)}).rowcount
        s.commit()
        return int(n or 0)
    except Exception as ex:  # noqa: BLE001
        _log.warning("Limpieza de los cobros reclamados (empresa %s): %s", eid, ex)
        try:
            s.rollback()
        except Exception:  # noqa: BLE001
            pass
        return 0


def _cuenta(cuerpo) -> int:
    c = cuerpo.get("cuenta_id") if isinstance(cuerpo, dict) else None
    if not isinstance(c, int) or isinstance(c, bool) or c <= 0:
        raise HTTPException(400, MENSAJE_FALTAN)
    return c


def _texto_clave(v, mensaje: str) -> str:
    if not isinstance(v, str) or not v:
        raise HTTPException(400, MENSAJE_FALTAN)
    if not _CLAVE_RE.fullmatch(v):
        raise HTTPException(400, mensaje)
    return v


def _lids(v) -> list:
    if v is None:
        return []
    if not isinstance(v, list) or len(v) > MAX_LIDS or not all(isinstance(x, str) and 0 < len(x) <= 200 for x in v):
        raise HTTPException(400, MENSAJE_FALTAN)
    return list(dict.fromkeys(v))


@router.post("/api/pos/cobro/reclamar")
def ruta_reclamar(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: pide el cobro de una cuenta de la caja antes de emitir (una pestaña a la vez)."""
    cid = _cuenta(cuerpo)
    equipo = _texto_clave(cuerpo.get("equipo"), MENSAJE_EQUIPO)
    clave = _texto_clave(cuerpo.get("clave"), MENSAJE_FALTAN)
    cobros = cuerpo.get("cobros")
    if cobros is not None and (not isinstance(cobros, int) or isinstance(cobros, bool) or cobros < 0):
        raise HTTPException(400, MENSAJE_FALTAN)
    restos = cuerpo.get("restos")                     # 4.31 (sexta vuelta): lo que la parte dejó en la cuenta (solo el cobro de una parte)
    pares = cuerpo.get("pares")                       # 4.31 (séptima vuelta): el par del 2x1 de la parte (lo que quedó en la cuenta del mismo plato)
    limpiar(s, ctx.empresa.id)
    return reclamar(s, ctx.empresa.id, cid, equipo, clave, _lids(cuerpo.get("lids")), cobros, None if restos is None else _lids(restos),
                    None if pares is None else _lids(pares))


@router.post("/api/pos/cobro/soltar")
def ruta_soltar(cuerpo: Any = Body(default=None), ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.31: termina el cobro de una cuenta (si se emitió, sus platos quedan anotados como cobrados)."""
    cid = _cuenta(cuerpo)
    clave = _texto_clave(cuerpo.get("clave"), MENSAJE_FALTAN)
    cobrado, sigue = cuerpo.get("cobrado") is True, cuerpo.get("sigue") is True
    return soltar(s, ctx.empresa.id, cid, clave, cobrado, _lids(cuerpo.get("lids")) if cobrado else [], sigue)
