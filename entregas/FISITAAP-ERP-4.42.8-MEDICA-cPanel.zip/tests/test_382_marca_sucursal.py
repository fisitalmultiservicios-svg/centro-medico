"""3.82: marca por sucursal. Una sucursal puede llevar su marca (logo y nombre comercial): lo que se emite en ella sin elegir
marca sale con la suya; elegir otra en el documento manda; sin marca en la sucursal, o con la marca inactiva, sale la
predeterminada; sin sucursal activa se usa la de la principal; borrar la marca deja la sucursal en la predeterminada."""
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, sucursales
from app.db import Documento, Empresa, engine, engine_empresa, init_db

LINEAS = [{"cabys": "8399000009900", "detalle": "Diseño de logo", "cantidad": 1, "precio_unitario": 10000, "tarifa": 13, "codigo_tarifa": "08"}]


@pytest.fixture()
def api():
    from app.main import app
    init_db()
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Agencia Marcas Sucursal QA S.A.")).first()
        if not e:
            e = Empresa(nombre="Agencia Marcas Sucursal QA S.A.", numero_id="3101382382", actividad="731001", otras_senas="Oficina 382",
                        correo="suc382@example.test", ambiente="sandbox", tipo_negocio="servicios")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
    usuario = types.SimpleNamespace(id=None, correo="qa-382@example.test", es_superadmin=False, nombre="QA")
    ctx = auth.Contexto(usuario, e, "Administrador")
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), e, ctx
    finally:
        app.dependency_overrides.clear()


def _activar(ctx, e, sid):
    with Session(engine_empresa(e.id)) as se:
        ctx.sucursal = sucursales.por_id(se, e.id, sid) if sid else None


def _xml(c, doc):
    return c.get(f"/api/comprobantes/{doc['id']}/xml").text


def test_la_sucursal_emite_con_su_marca(api):
    c, e, ctx = api
    principal = next(x for x in c.get("/api/sucursales").json()["sucursales"] if x["principal"])
    itcore = c.post("/api/marcas", json={"nombre": "IT Core QA", "predeterminada": True}).json()
    brillante = c.post("/api/marcas", json={"nombre": "Brillante Agencia QA", "sitio_web": "brillante.example.test"}).json()

    # la sucursal guarda su marca; una marca que no existe se rechaza
    assert c.post("/api/sucursales", json={"codigo": 2, "nombre": "Mala", "marca_id": 987654}).status_code == 400
    r = c.post("/api/sucursales", json={"codigo": 2, "nombre": "Brillante Agencia", "telefono": "22223333", "marca_id": brillante["id"]})
    assert r.status_code == 200, r.text
    suc = r.json()
    assert suc["marca_id"] == brillante["id"]
    # la sesión la trae para que los formularios la pongan por defecto
    res = sucursales.resumen_sesion(None, e.id, None)
    assert {x["id"]: x["marca_id"] for x in res["sucursales"]}[suc["id"]] == brillante["id"]

    # en la sucursal Brillante, sin elegir marca: sale con la de la sucursal (XML incluido) y su consecutivo 002
    _activar(ctx, e, suc["id"])
    d1 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d1["marca_id"] == brillante["id"] and d1["consecutivo"].startswith("002")
    assert "<NombreComercial>Brillante Agencia QA</NombreComercial>" in _xml(c, d1)
    # elegir otra marca en el documento manda
    d2 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS, "marca_id": itcore["id"]}).json()
    assert d2["marca_id"] == itcore["id"]

    # sin sucursal activa (Todas) se emite con la principal: no tiene marca → la predeterminada
    _activar(ctx, e, None)
    d3 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d3["marca_id"] == itcore["id"] and d3["consecutivo"].startswith("001")
    # si la principal tiene marca, «Todas» usa esa
    assert c.put(f"/api/sucursales/{principal['id']}", json={**principal, "marca_id": brillante["id"]}).status_code == 200
    d4 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d4["marca_id"] == brillante["id"]
    assert c.put(f"/api/sucursales/{principal['id']}", json={**principal, "marca_id": None}).json()["marca_id"] is None

    # marca de la sucursal inactiva → la predeterminada; y no se puede asignar una inactiva
    c.put(f"/api/marcas/{brillante['id']}", json={"nombre": brillante["nombre"], "activa": False})
    _activar(ctx, e, suc["id"])
    d5 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d5["marca_id"] == itcore["id"]
    otra = c.post("/api/sucursales", json={"codigo": 3, "nombre": "Temporal", "marca_id": brillante["id"]})
    assert otra.status_code == 400 and "inactiva" in otra.json()["detail"]


def test_borrar_la_marca_deja_la_sucursal_en_la_predeterminada(api):
    c, e, ctx = api
    c.get("/api/sucursales")
    temporal = c.post("/api/marcas", json={"nombre": "Marca Temporal QA"}).json()
    suc = c.post("/api/sucursales", json={"codigo": 4, "nombre": "Sucursal Temporal", "marca_id": temporal["id"]}).json()
    assert c.delete(f"/api/marcas/{temporal['id']}").json()["ok"] is True          # sin comprobantes: se borra
    lista = {x["id"]: x for x in c.get("/api/sucursales").json()["sucursales"]}
    assert lista[suc["id"]]["marca_id"] is None
    with Session(engine_empresa(e.id)) as se:
        assert se.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.marca_id == temporal["id"])).first() is None
