# -*- coding: utf-8 -*-
"""4.31 (la misma mesa, tercera vuelta): pantallas. Los métodos reales de caja.js en dos «equipos» (cada uno con su api.js y su
_fusion.js), contra el servidor falso de tests/test_431_misma_mesa_pantallas.py, más un servidor falso del cobro (la regla de
app/cobro_reclamo.py) y de los comprobantes que cuenta lo emitido.

- A (alta): dos equipos que cobran la misma mesa a la vez o con un segundo de diferencia (completa, «Cobrar parte k de n» en las dos
  partes, «cobrar ahora solo esos», cargar a la habitación): se emite una sola vez y el total cobrado es el de la cuenta; el segundo no
  emite, recibe el aviso y se pone al día. Un solo equipo no nota nada (tampoco cuando cobra dos partes seguidas). Sin conexión, sin la
  ruta en el servidor y sin cuenta guardada: como siempre, sin pedir el cobro.
- B: el otro equipo cobró y aquí se tocó «Mesas» (o «Precuenta»): el aviso de cuenta nueva, y el plano, la mesa reabierta y la
  precuenta ya sin lo cobrado.
- C: el 2x1 no se pierde al cobrar una cuenta partida (cobrar parte, cobrar ahora solo esos, «· parte k de n»): lo mismo que la 4.29.
- D: la comanda sale aunque la revisión falle; la revisión se rehace si algo quedó a medio subir; al cobrar la venta rápida no se
  revisa; el cliente que llega del otro equipo no corrige el total en esa pasada; la estación se carga al abrir la caja; la comanda
  revisada sale con la mesa a la que otro equipo movió la cuenta; «1 plato» y «2 platos».
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

from tests.test_425_ultimos_pantallas import _node
from tests.test_431_misma_mesa_pantallas import ARNES_MESA, VUE, _fuente_caja, _js, _linea, _metodo, _tramo


def _fuente(mas=()) -> str:
    k = _js("pages/pos/caja.js")
    extra = [_metodo(k, "async emitirCobro(otra) {"), _metodo(k, "async cobrarVenta(otra) {"), _tramo(k, "    async cobrar() {", "\n").strip().rstrip(","),
             _metodo(k, "async confirmarDividir() {"), _linea(k, "datosCredito(c) {"), _metodo(k, "nuevaCuentaEspera(nombre, lineas, mesaId, extra) {"),
             _metodo(k, "aplicarPromos(forzar) {"), _metodo(k, "cargarAHabitacion() {"), _metodo(k, "precuenta() {"), _metodo(k, "imprimirPrecuenta(w) {"),
             _metodo(k, "recuperar(v) {"), _linea(k, "async abrirDividir() {"), _linea(k, "lineaTotal(l) {"), *mas]
    return _fuente_caja() + ",\n" + ",\n".join(extra)


def _arnes(mas=()) -> str:
    a = ARNES_MESA % {"fuente": json.dumps(_fuente(mas))}
    cambios = (("STORE, async () => ({}), A.monedas", "STORE, (u, o) => globalThis.API(u, o, n), A.monedas"),     # el api de la caja: el servidor falso del cobro
               ("  A.mock.alCambiarIds((k, c) => vm.seguirIds(k, c));\n  return vm;\n}", "  A.mock.alCambiarIds((k, c) => vm.seguirIds(k, c));\n  return EXTRA(vm, n);\n}"),
               ("const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); t += m", "const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - this.descuentoDe(l); t += m"))
    for viejo, nuevo in cambios:
        assert a.count(viejo) == 1, viejo
        a = a.replace(viejo, nuevo)
    return a + ARNES_COBRO


ARNES_COBRO = r"""
// ---- el servidor falso del cobro (la regla de app/cobro_reclamo.py) y de los comprobantes
const C = globalThis.C = { reclamos: {}, emitidos: [], llamadas: [], sinRuta: false, caido: false, soltarLento: 0, lentoGet: 0, folios: [], ventanas: [], htmls: [], sinConexion: [], emitirLento: 0, fallaEmitir: 0, cerradas: 0, perderEmitir: 0, reclamoFalla: 0, reclamoLento: 0 };
globalThis.API = async (u, o, n) => {
  const b = o && o.body ? JSON.parse(JSON.stringify(o.body)) : null;
  C.llamadas.push([n, u]);
  const sinRed = () => Object.assign(new Error('Sin conexión con el servidor'), { sinConexion: true });
  if (u.startsWith('/api/pos/cobro/')) { if (C.caido) throw sinRed(); if (C.sinRuta) throw Object.assign(new Error('Error del servidor (404)'), { status: 404 }); }
  if (u === '/api/pos/cobro/reclamar') {
    if (C.reclamoLento) await espera(C.reclamoLento);   // sexta vuelta: «Revisando…» mientras se pregunta
    if (C.reclamoFalla) throw Object.assign(new Error('Error del servidor (500)'), { status: 500 });   // sexta vuelta: sin respuesta clara («incierto»)
    const ahora = Date.now(), f = C.reclamos[b.cuenta_id], cobradas = f ? f.cobradas : [];
    const pc = Array.isArray(b.pares) ? { pares_cobrados: b.pares.filter(x => cobradas.includes(x)) } : {};   // séptima vuelta: el par del 2x1 de la parte, ya cobrado
    if (f && f.estado === 'reclamada' && f.vence > ahora && f.equipo !== b.equipo) {
      const ya = b.lids.filter(x => f.cobradas.includes(x)); if (ya.length && !b.lids.some(x => !ya.includes(x) && f.lids.includes(x))) return { resultado: 'cobrada', comunes: ya, ...pc };
      return { resultado: 'ocupada', vence: new Date(f.vence).toISOString(), comunes: b.lids.filter(x => f.lids.includes(x) || f.cobradas.includes(x)), ...pc };
    }
    const ya = b.lids.filter(x => cobradas.includes(x)); if (ya.length) return { resultado: 'cobrada', comunes: ya, ...pc };
    if (Array.isArray(b.restos)) { const c = S.items.find(x => x.id === b.cuenta_id), de = new Set(((c && c.lineas) || []).filter(l => typeof l.de === 'string' && l.de && !b.restos.includes(l.lid)).map(l => l.de)), par = b.lids.filter(x => de.has(x)); if (par.length) return { resultado: 'partida', comunes: par, ...pc }; }   // sexta vuelta: otro equipo partió lo mismo a la vez
    if (Number.isInteger(b.cobros)) { const c = S.items.find(x => x.id === b.cuenta_id); if (c && (c.cobros || []).length > b.cobros) return { resultado: 'cambiada', comunes: [], ...pc }; }
    C.reclamos[b.cuenta_id] = { estado: 'reclamada', equipo: b.equipo, clave: b.clave, lids: b.lids.slice(), cobradas: cobradas.slice(), vence: ahora + 60000 };
    return { resultado: 'ganada', vence: 'x', ...pc };
  }
  if (u === '/api/pos/cobro/soltar') {
    if (C.soltarLento) await espera(C.soltarLento);
    const f = C.reclamos[b.cuenta_id];
    if (!f) { if (b.cobrado && b.lids.length) C.reclamos[b.cuenta_id] = { estado: 'libre', equipo: '', clave: '', lids: [], cobradas: b.lids.slice(), vence: 0 }; return { resultado: 'no_era_suya' }; }
    const suya = f.estado === 'reclamada' && f.clave === b.clave;
    if (b.cobrado) for (const x of [...(suya ? f.lids : []), ...b.lids]) if (!f.cobradas.includes(x)) f.cobradas.push(x);
    if (suya && b.sigue) f.vence = Date.now() + 60000; else if (suya) { f.estado = 'libre'; f.lids = []; }
    return { resultado: suya ? 'ok' : 'no_era_suya' };
  }
  if (u === '/api/comprobantes') {
    if (C.caido) throw sinRed();
    if (C.emitirLento) await espera(C.emitirLento);
    if (C.fallaEmitir === n) { C.fallaEmitir = 0; throw Object.assign(new Error('Error del servidor (500)'), { status: 500 }); }
    const total = r2(b.lineas.reduce((s, l) => s + ((+l.cantidad || 0) * (+l.precio_unitario || 0) - (+l.descuento || 0)) * (1 + (+l.tarifa || 0) / 100), 0));
    C.emitidos.push({ n, total, lineas: b.lineas.map(l => l.detalle + '×' + l.cantidad) });
    if (C.perderEmitir === n) { C.perderEmitir = 0; throw sinRed(); }   // se emitió, pero la respuesta se perdió (quinta vuelta, M3)
    return { id: C.emitidos.length, consecutivo: '0010000104' + String(C.emitidos.length).padStart(10, '0'), tipo_documento: '04', estado: 'aceptado' };
  }
  if (u === '/api/pagos') return { numero: 'P' + C.llamadas.length };
  return {};
};
const fetch0 = globalThis.fetch;   // la lista de cuentas que tarda en bajar (D-3)
globalThis.fetch = async (url, opt) => { if (C.lentoGet && url === '/api/registros/pos_espera' && !(opt && opt.method)) await espera(C.lentoGet); return fetch0(url, opt); };
// lo que caja.js toma de sus módulos (solo lo que usan estos métodos)
Object.assign(globalThis, { red: { enLinea: true }, money: v => String(v), nombreMedio: m => m, hoy: () => '2026-11-12', registrarVentaEnCaja() {}, vistaTrasCobro: () => 'mesas', abrirGaveta: async () => {},
  formaCobro: () => ({ imprime: false }), esc: s => String(s ?? ''), reservasHotel: () => [{ id: 1, moneda: 'CRC', habitacion_id: 3, huesped_nombre: 'Huésped QA', numero: 'R-1' }], configHotel: () => ({}),
  agregarFolio: x => { C.folios.push(x); return x; }, aMonedaFolio: v => v, nombreHab: () => 'Hab 3', otroImpDe: () => null, otroImpLinea: () => ({ monto: 0, base: 0 }),
  window: { addEventListener() {}, removeEventListener() {}, open: () => ({ closed: false, close() { this.closed = true; C.cerradas++; }, document: { open() {}, write(h) { C.ventanas.push(h); }, close() {} } }) }, Blob: class { constructor(p) { C.htmls.push(p.join('')); } } });
URL.createObjectURL = () => 'blob:x'; URL.revokeObjectURL = () => {};
// lo de cada equipo que la caja necesita para cobrar (y el descuento de la promoción en el total, como totales() de la caja)
const VMS = [];
function EXTRA(vm, n) {
  VMS.push(vm);
  Object.assign(vm, { nEq: n, promosActivas: [], enDolares: false, exoAplica: false, exoSel: null, cupon: null, puntos: null, autorizado: null, cuentaUsd: null, ultima: null, mesas: [M6], modalEspera: false,
    difundir() {}, imprimir() {}, impresoraTiquete: () => null, cargarExistencias() {}, cabSucursal: () => ({}), quienPuntos: () => null, cuentaPara: () => 'Caja general',
    ventaSinConexion(c) { const rec = this._reclamoSinRed || null; this._reclamoSinRed = null; C.sinConexion.push([n, c.esperaId, rec]); this.cobrando = false; },
    descuentoDe(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); return Math.max(0, Math.min(m, l.descuento_pct ? m * (+l.descuento_pct) / 100 : (+l.descuento || 0))); } });
  Object.assign(vm.cfg, { tipo_documento: '04', enviar_hacienda: false, propina: false, servicio_detalle: 'Servicio' });
  Object.defineProperty(vm, 'pagoTot', { get() { return { ok: true, falta: 0, vuelto: 0 }; } });
  return vm;
}
const libre = () => Object.values(C.reclamos).every(r => r.estado !== 'reclamada');
const hastaLibre = async () => { for (let i = 0; i < 300 && !libre(); i++) await espera(10); await espera(20); };
const conPago = async (...vms) => { for (let i = 0; i < 200 && !vms.every(v => v.pago); i++) await espera(5); };
const reiniciarCobro = () => { for (const v of VMS.splice(0)) v._fuera = true; return Object.assign(C, { reclamos: {}, emitidos: [], llamadas: [], sinRuta: false, caido: false, soltarLento: 0, lentoGet: 0, folios: [], ventanas: [], htmls: [], sinConexion: [], emitirLento: 0, fallaEmitir: 0, cerradas: 0, perderEmitir: 0, reclamoFalla: 0, reclamoLento: 0 }); };   // los equipos de antes dejan de mirar la cuenta
const emitidos = () => C.emitidos.map(e => [e.n, e.total]);
const suma = () => r2(C.emitidos.reduce((s, e) => s + e.total, 0));
const AVISO_OCUPADA = 'Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar.';
const AVISO_COBRADA = 'Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar.';
const AVISO_PARTIDA = 'Otro equipo partió esta misma cuenta a la vez. Aquí no se cobró nada; revise la cuenta y cobre lo que queda.';   // séptima vuelta: sin decir que el otro «ya tiene esos platos» (pudo devolverlos)
const AVISO_PARTIDA_1 = AVISO_PARTIDA;   // el mismo con uno o con varios platos
const delCobro = vm => avisos(vm).filter(t => t === AVISO_OCUPADA || t === AVISO_COBRADA || t === AVISO_PARTIDA || t === AVISO_PARTIDA_1);
const reclamos = n => C.llamadas.filter(x => x[1] === '/api/pos/cobro/reclamar' && (n === undefined || x[0] === n)).length;
const CERVEZA = c => ({ ...plato('Cerveza', 1800, 4, c) });
"""

DOS = "[plato('Casado', 3500, 1, 2), plato('Limonada', 1500, 2, 2)]"      # Casado ×2 y Limonada ×2: ₡11 300 con IVA
TOTAL_DOS = 11300.0
MITAD = 5650.0


def _correr(tmp_path, guion, mas=()):
    return _node(tmp_path, _arnes(mas) + guion + "\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n", archivos=("api.js", "pages/pos/_fusion.js"), falsos=VUE)


# ================================================================================================================ A: cobros a la vez
def test_a_dos_equipos_cobran_a_la_vez_y_se_emite_una_vez_en_node(tmp_path):
    r = _correr(tmp_path, """
// (f) la cuenta completa, los dos con F9 a la vez
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await Promise.all([a.abrirPago(), b.abrirPago()]); await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre();
let perdio = C.emitidos[0].n === a.nEq ? b : a;
out.f = { emitidos: emitidos().length, suma: suma(), avisos: delCobro(perdio), ganador: delCobro(perdio === a ? b : a), servidor: servidor().length, pago: perdio.pago };
// (f) un segundo después: el otro ya emitió y soltó; este, con la ventana de cobro abierta desde antes, no emite
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await Promise.all([a.abrirPago(), b.abrirPago()]); await a.cobrar(); await hastaLibre(); await b.cobrar(); await hastaLibre();
out.f1s = { emitidos: emitidos(), suma: suma(), avisos: delCobro(b), vista: b.vista, esperaB: b.esperaId, cerrada: avisos(b).some(t => t.includes('fue cobrada o cerrada en otro equipo')) };
// (b) «Cobrar parte 1 de 2» y F9 en los dos a la vez: el que pierde sigue con su cobro abierto (el otro todavía no emitió: nada se
// descarta); al tocar otra vez, esos platos ya se cobraron: se descartan y el botón dice la parte que sigue; después se cobra lo que queda
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]); await conPago(a, b);
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
perdio = C.emitidos[0].n === a.nEq ? b : a;
out.b = { primero: emitidos().length, avisos: delCobro(perdio), abierto: [!!perdio.pago, perdio.cobroParcial && perdio.cobroParcial.parte, perdio.lineas.map(l => l.detalle + '×' + l.cantidad)], srv: S.items.map(x => [x.lineas.map(l => l.detalle + '×' + l.cantidad), x.partes, x.cobros.length]) };
await perdio.cobrar();
out.b.otra = { emitidos: emitidos().length, avisos: delCobro(perdio).slice(1), pantalla: perdio.lineas.map(l => l.detalle + '×' + l.cantidad), cobroParcial: perdio.cobroParcial, pago: perdio.pago, boton: (perdio.partesDe(perdio.cuentaActual) || {}).cobradas };
await perdio.cobrarParte(2); await conPago(perdio); out.b.parte = [perdio.cobroParcial.parte, perdio.cobroParcial.de]; await perdio.cobrar(); await hastaLibre();
out.b.final = { emitidos: emitidos().length, suma: suma(), servidor: servidor().length };
// (c) B parte la cuenta 1 s después que A (ya ve el resto de A) y cobra cuando A ya terminó: no emite; luego cobra la parte 2 de 2
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await a.cobrarParte(2); await a.A.mock.guardarTodo(); b._alDia = 0; await b.cobrarParte(2); await b.A.mock.guardarTodo(); await conPago(a, b);
out.c = { parteB: b.lineas.map(l => l.cantidad) };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
out.c.tras = { emitidos: emitidos(), avisos: delCobro(b), pantalla: b.lineas.map(l => l.detalle + '×' + l.cantidad), srv: S.items.map(x => [x.lineas.map(l => l.detalle + '×' + l.cantidad), x.partes]) };
b._alDia = 0; await b.cobrarParte(2); await conPago(b); out.c.parte = [b.cobroParcial.parte, b.cobroParcial.de]; await b.cobrar(); await hastaLibre();
out.c.final = { emitidos: emitidos().length, suma: suma(), servidor: servidor().length };
// (e) con la parte 1 ya cobrada, los dos tocan «Cobrar parte 2» y F9 a la vez
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await a.cobrarParte(2); await conPago(a); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await a.sincronizar(); a.abrirMesa(M6); await b.sincronizar(); b.abrirMesa(M6); a._alDia = 0; b._alDia = 0;
await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await conPago(a, b);
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
out.e = { emitidos: emitidos().length, suma: suma(), avisos: delCobro(C.emitidos[1].n === a.nEq ? b : a) };
""" % {"dos": DOS})
    f = r["f"]
    assert f["emitidos"] == 1 and f["suma"] == TOTAL_DOS and f["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert f["ganador"] == [] and f["servidor"] == 0 and f["pago"] is None, r
    s = r["f1s"]
    assert len(s["emitidos"]) == 1 and s["suma"] == TOTAL_DOS, r                                     # antes: dos tiquetes (₡22 600)
    assert s["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."] and s["cerrada"] and s["vista"] == "mesas" and s["esperaB"] is None, r
    b = r["b"]
    assert b["primero"] == 1 and b["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert b["abierto"] == [True, 1, ["Casado×1", "Limonada×1"]], r                                   # cuarta vuelta: con «ocupada» no se descarta nada
    assert b["srv"] == [[["Casado×1", "Limonada×1"], {"total": 2, "cobradas": 1}, 1]], r
    o = b["otra"]                                                                                      # al tocar otra vez: ya se cobraron
    assert o["emitidos"] == 1 and o["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert o["pantalla"] == ["Casado×1", "Limonada×1"] and o["cobroParcial"] is None and o["pago"] is None and o["boton"] == 1, r   # el que no cobró ve lo que queda
    assert b["parte"] == [2, 2] and b["final"] == {"emitidos": 2, "suma": TOTAL_DOS, "servidor": 0}, r   # antes: ₡16 950 (una parte de más)
    c = r["c"]
    assert c["parteB"] == [0.5, 0.5], r                                                              # B partió el resto de A (no sabía que A cobraba)
    assert len(c["tras"]["emitidos"]) == 1 and c["tras"]["emitidos"][0][1] == MITAD, r               # solo la parte de A: B no emitió
    assert c["tras"]["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert c["tras"]["pantalla"] == ["Casado×1", "Limonada×1"] and c["tras"]["srv"] == [[["Casado×1", "Limonada×1"], {"total": 2, "cobradas": 1}]], r
    assert c["parte"] == [2, 2] and c["final"] == {"emitidos": 2, "suma": TOTAL_DOS, "servidor": 0}, r
    e = r["e"]
    assert e["emitidos"] == 2 and e["suma"] == TOTAL_DOS and e["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r


def test_a_cobrar_ahora_solo_esos_y_la_habitacion_en_node(tmp_path):
    r = _correr(tmp_path, """
// «cobrar ahora solo esos» (1 Casado) en los dos a la vez: uno emite; el otro no, y su Casado no vuelve a la cuenta
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
for (const v of [a, b]) { await v.abrirDividir(); v.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } }; }
await Promise.all([a.confirmarDividir(), b.confirmarDividir()]); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]); await conPago(a, b);
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
let perdio = C.emitidos[0].n === a.nEq ? b : a;
out.solo = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(perdio), srv: S.items.map(x => x.lineas.map(l => l.detalle + '×' + l.cantidad)) };
// cargar a la habitación mientras otro equipo cobra la cuenta: no se carga nada y sale el aviso
reiniciarCobro(); [a, b] = await mesaAbierta([CASADO()]);
C.reclamos[1] = { estado: 'reclamada', equipo: 'eOTRO0000000001', clave: 'otraclave1', lids: a.lineas.map(l => l.lid), cobradas: [], vence: Date.now() + 60000 };
b.habCargo = { reserva_id: 1, q: '', firma: false, autoriza: '' }; await b.cargarAHabitacion();
out.hab_ocupada = { folios: C.folios.length, avisos: delCobro(b), habCargo: b.habCargo, srv: servidor().length };
// libre: se carga, la cuenta se cierra y esos platos quedan anotados como cobrados (otro equipo atrasado no los cobra)
delete C.reclamos[1]; b.habCargo = { reserva_id: 1, q: '', firma: false, autoriza: '' }; await b.cargarAHabitacion(); await hastaLibre(); await b.A.mock.guardarTodo();
out.hab = { folios: C.folios.map(x => x.detalle), srv: servidor().length, cobradas: C.reclamos[1].cobradas.length, avisos: delCobro(b).slice(1) };
await a.abrirPago(); await a.cobrar(); await hastaLibre();
out.hab_atrasado = { emitidos: C.emitidos.length, avisos: delCobro(a) };
""" % {"dos": DOS})
    s = r["solo"]
    assert s["emitidos"] == [3955.0] and s["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert [sorted(x) for x in s["srv"]] == [["Casado×1", "Limonada×2"]], r                                               # un Casado cobrado una sola vez; nada de más ni de menos
    h = r["hab_ocupada"]
    assert h["folios"] == 0 and h["habCargo"] is None and h["srv"] == 1, r
    assert h["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert r["hab"]["folios"] == ["Casado (Mesa 6)"] and r["hab"]["srv"] == 0 and r["hab"]["cobradas"] == 1 and r["hab"]["avisos"] == [], r
    assert r["hab_atrasado"] == {"emitidos": 0, "avisos": ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."]}, r


def test_a_un_solo_equipo_no_nota_nada_y_sin_red_o_sin_ruta_cobra_como_siempre_en_node(tmp_path):
    r = _correr(tmp_path, """
// un solo equipo: la parte 1 y enseguida la parte 2 (el soltar de la parte 1 todavía no llegó): las dos se emiten sin aviso ni espera
reiniciarCobro(); let [a] = await mesaAbierta(%(dos)s);
C.soltarLento = 300;
await a.cobrarParte(2); await conPago(a); let t0 = Date.now(); await a.cobrar(); const ms1 = Date.now() - t0;
a._alDia = 0; a.abrirMesa(M6); await a.cobrarParte(2); await conPago(a); t0 = Date.now(); await a.cobrar(); const ms2 = Date.now() - t0;
await hastaLibre(); await espera(400);
out.solo = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(a), reclamos: reclamos(), rapido: ms1 < 250 && ms2 < 250, servidor: servidor().length, tiquetes: avisos(a).filter(t => t.startsWith('Tiquete')).length };
// la cuenta completa, un solo equipo
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]);
await a.abrirPago(); await a.cobrar(); await hastaLibre();
out.completa = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(a), orden: C.llamadas.map(x => x[1]).filter(u => u.startsWith('/api/pos/cobro/') || u === '/api/comprobantes') };
// servidor sin la ruta (404): cobra como siempre
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]); C.sinRuta = true;
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.sin_ruta = { emitidos: C.emitidos.length, avisos: delCobro(a), soltar: C.llamadas.filter(x => x[1] === '/api/pos/cobro/soltar').length, servidor: servidor().length };
// sin conexión: no se pide el cobro y la venta queda para emitirse después, como siempre
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]); red.enLinea = false; C.caido = true;
await a.abrirPago(); await a.cobrar();
out.sin_red = { reclamos: reclamos(), sinConexion: C.sinConexion.length, emitidos: C.emitidos.length }; red.enLinea = true;
// venta sin cuenta guardada (rápida o de mostrador): no se pide nada
reiniciarCobro(); reiniciar(); const v = await equipo(); v.vista = 'venta'; v.lineas.push(CASADO());
await v.abrirPago(); await v.cobrar();
out.sin_cuenta = { reclamos: reclamos(), emitidos: emitidos().map(x => x[1]) };
""" % {"dos": DOS})
    s = r["solo"]
    assert s["emitidos"] == [MITAD, MITAD] and s["avisos"] == [] and s["reclamos"] == 2 and s["rapido"] is True and s["servidor"] == 0 and s["tiquetes"] == 2, r
    c = r["completa"]
    assert c["emitidos"] == [3955.0] and c["avisos"] == [], r
    assert c["orden"] == ["/api/pos/cobro/reclamar", "/api/comprobantes", "/api/pos/cobro/soltar", "/api/pos/cobro/soltar"], r    # pedir, emitir, anotar y soltar
    assert r["sin_ruta"] == {"emitidos": 1, "avisos": [], "soltar": 0, "servidor": 0}, r
    assert r["sin_red"] == {"reclamos": 0, "sinConexion": 1, "emitidos": 0}, r
    assert r["sin_cuenta"] == {"reclamos": 0, "emitidos": [3955.0]}, r


# ================================================================================================================ B: «Mesas» y «Precuenta»
def test_b_otro_equipo_cobro_y_aqui_se_toco_mesas_o_precuenta_en_node(tmp_path):
    r = _correr(tmp_path, """
const NUEVA = 'La cuenta de Mesa 6 se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en Mesa 6 como cuenta nueva.';
// B cobra; A, sin enterarse, agrega el Postre y toca «Mesas» (no «Comanda»)
reiniciarCobro(); let [a, b] = await mesaAbierta([CASADO(), LIMONADA()]);
await b.abrirPago(); await b.cobrar(); await hastaLibre();
a.lineas.push(POSTRE()); a.volverAMesas(false); await a.A.mock.guardarTodo();
await hasta(() => a.espera.length === 1 && a.espera[0].lineas.length === 1);
out.mesas = { avisos: avisos(a).filter(t => t.startsWith('La cuenta de') || t.includes('quedó guardada')), plano: a.espera.map(x => [x.id, x.total, x.lineas.map(l => l.detalle)]), servidor: servidor() };
a.abrirMesa(M6); out.mesas.reabre = [a.esperaId, a.lineas.map(l => l.detalle), a.totales.total];
out.mesas.una = avisos(a).filter(t => t === NUEVA).length;
// variante: «Precuenta» como primer toque: la hoja sale solo con el Postre
reiniciarCobro(); [a, b] = await mesaAbierta([CASADO(), LIMONADA()]);
await b.abrirPago(); await b.cobrar(); await hastaLibre();
C.ventanas = []; C.htmls = []; a.lineas.push(POSTRE()); await a.precuenta();
const hoja = C.ventanas[C.ventanas.length - 1] || C.htmls[C.htmls.length - 1] || '';
out.precuenta = { postre: hoja.includes('Postre'), casado: hoja.includes('Casado'), limonada: hoja.includes('Limonada'), aviso: avisos(a).filter(t => t === NUEVA).length, pantalla: a.lineas.map(l => l.detalle) };
// un solo equipo: la precuenta de una cuenta que nadie más tocó sale con todo
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); await a.precuenta();
const hoja2 = C.ventanas[C.ventanas.length - 1] || C.htmls[C.htmls.length - 1] || '';
out.precuenta_sola = [hoja2.includes('Casado'), hoja2.includes('Postre'), avisos(a).filter(t => t === NUEVA).length];
// la cuenta que cerró ESTA pantalla (cobro): un guardado tardío propio no da el aviso de «otro equipo»
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]);
a.persistirCuenta(); await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.propia = avisos(a).filter(t => t === NUEVA).length;
""")
    m = r["mesas"]
    assert m["avisos"] == ["Mesa 6 quedó guardada con 1 plato sin enviar a cocina: use «Comanda» para enviarlo",
                           "La cuenta de Mesa 6 se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en Mesa 6 como cuenta nueva."], r
    assert m["plano"] == [[2, 1356, ["Postre"]]] and m["servidor"] == [{"id": 2, "nombre": "Mesa 6", "mesa": 6, "platos": ["Postre×1"], "total": 1356}], r
    assert m["reabre"] == [2, ["Postre"], 1356] and m["una"] == 1, r
    p = r["precuenta"]
    assert p == {"postre": True, "casado": False, "limonada": False, "aviso": 1, "pantalla": ["Postre"]}, r
    assert r["precuenta_sola"] == [True, True, 0] and r["propia"] == 0, r


# ================================================================================================================ C: el 2x1 al cobrar una cuenta partida
def test_c_el_2x1_se_conserva_al_cobrar_una_cuenta_partida_en_node(tmp_path):
    r = _correr(tmp_path, """
const PROMO = [{ tipo: '2x1', nombre: '2x1 cervezas', productos: [4] }];
async function mesaCervezas() {
  reiniciarCobro(); reiniciar();
  const a = await equipo(); a.promosActivas = PROMO; a.abrirMesa(M6); a.lineas.push(CERVEZA(2)); a.aplicarPromos(); await comanda(a);
  await a.sincronizar(); a.abrirMesa(M6); return a;
}
// «Cobrar parte» 1 y 2 de 2
let a = await mesaCervezas();
out.guardada = S.items.map(x => [x.lineas.map(l => [l.cantidad, l.descuento_pct]), x.total]);
await a.cobrarParte(2); await conPago(a); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
a._alDia = 0; await a.sincronizar(); a.abrirMesa(M6); await a.cobrarParte(2); await conPago(a); await a.cobrar(); await hastaLibre();
out.partes = emitidos().map(x => x[1]);
// «cobrar ahora solo esos» (1 Cerveza) y después el resto
a = await mesaCervezas();
await a.abrirDividir(); a.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } }; await a.confirmarDividir(); await conPago(a); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
a._alDia = 0; await a.sincronizar(); a.abrirMesa(M6); await a.abrirPago(); await a.cobrar(); await hastaLibre();
out.solo_esos = emitidos().map(x => x[1]);
// «· parte k de n» (cuenta sin mesa dividida en partes iguales): la parte 1 en pantalla y la «parte 2 de 2» recuperada
reiniciarCobro(); reiniciar();
a = await equipo(); a.promosActivas = PROMO; a.vista = 'venta'; a.nombreEspera = 'Ana'; a.lineas.push(CERVEZA(2)); a.aplicarPromos(); a.persistirCuenta(); await a.A.mock.guardarTodo();
a.dividir = { modo: 'partes', partes: 2, destino: 'nueva', sel: {} }; await a.confirmarDividir(); await a.A.mock.guardarTodo();
a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
const p2 = a.espera.find(x => x.nombre === 'Ana · parte 2 de 2');
a.recuperar(p2); a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre();
out.partes_iguales = { nombre: p2 && p2.nombre, emitidos: emitidos().map(x => x[1]) };
// si otro equipo agrega un plato mientras tanto, la promoción se vuelve a calcular (como siempre): la Cerveza que llega con un 2x1 que
// aquí no le toca (va en otra comanda) queda sin él
a = await mesaCervezas(); const b = await equipo(); await b.sincronizar(); b.abrirMesa(M6); b.lineas.push({ ...CERVEZA(1), descuento_pct: 50, promo: '2x1 cervezas' }); await comanda(b);
a._alDia = 0; await a.abrirPago(); out.con_otro = a.lineas.map(l => [l.cantidad, l.descuento_pct]);
""")
    assert r["guardada"] == [[[[2, 50]], 2034]], r                                              # 2 Cervezas con 2x1: ₡1 800 + IVA
    assert r["partes"] == [1017.0, 1017.0], r                                                    # antes: ₡1 017 + ₡2 034 (la parte 2 sin el 2x1)
    assert r["solo_esos"] == [1017.0, 1017.0], r
    assert r["partes_iguales"] == {"nombre": "Ana · parte 2 de 2", "emitidos": [1017.0, 1017.0]}, r
    assert r["con_otro"] == [[2, 50], [1, 0]], r                                                  # llegó un plato: se recalcula


# ================================================================================================================ D: la comanda y lo demás
def test_d_comanda_revision_que_falla_que_se_rehace_y_al_cobrar_en_node(tmp_path):
    r = _correr(tmp_path, """
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
const imprimeEn = (vm, lista) => { vm.cfg.imprimir_comanda = true; vm.destinoDe = () => COCINA; vm.imprimirComanda = (g, ronda, d) => { for (const x of Object.values(g)) for (const l of x.ls) lista.push(l.detalle + (d && d.numero ? ' #' + d.numero : '') + ' @' + (d ? d.cuenta : vm.nombreEspera)); }; };
async function atrasada() {
  reiniciarCobro(); const [a, b] = await mesaAbierta([CASADO()]);
  a.lineas.push(LIMONADA()); await mesas(a);
  await b.sincronizar();
  await a.sincronizar(); a.abrirMesa(M6); a.lineas = a.lineas.filter(l => l.detalle !== 'Limonada'); await mesas(a);
  return [a, b];
}
// D-2: la revisión falla (sin número y con número): la comanda sale igual, con todo, y lo dudoso queda en la cuenta como pedido nuevo
let [a, b] = await atrasada(); let impresos = []; imprimeEn(b, impresos);
b.revisarComanda = async () => { throw new Error('falla'); };
b.lineas.push(POSTRE()); await b.enviarComanda(); await b.A.mock.guardarTodo();
out.falla = { impresos, avisos: avisos(b).slice(-1) };
[a, b] = await atrasada(); impresos = []; imprimeEn(b, impresos); b.numerarComanda = 'dia';
b.revisarComanda = async () => { throw new Error('falla'); };
b.lineas.push(POSTRE()); await b.enviarComanda(); await b.A.mock.guardarTodo();
out.falla_numero = { impresos, avisos: avisos(b).slice(-1) };
// D-3: «Mesas» enseguida de «Comanda» mientras la lista de cuentas baja: se sabe igual y la Limonada que A quitó no sale
[a, b] = await atrasada(); impresos = []; imprimeEn(b, impresos);
C.lentoGet = 150; b.lineas.push(POSTRE()); const p = b.enviarComanda(); setTimeout(() => b.volverAMesas(false), 60);
await p; C.lentoGet = 0; await b.A.mock.guardarTodo();
out.rehace = { impresos, servidor: servidor().map(x => x.platos), avisos: avisos(b).filter(t => t.startsWith('No salió') || t.startsWith('Comanda')) };
// D-4: al cobrar la venta rápida (la caja ya está «cobrando») no se revisa: sale lo que se cobra, sin esperar
[a, b] = await atrasada(); impresos = []; imprimeEn(b, impresos); let revisadas = 0;
b.revisarComanda = async () => { revisadas++; };
b.cobrando = true; b.lineas.push(POSTRE()); const r0 = b.enviarComanda(); b.cobrando = false;
out.al_cobrar = { promesa: !!(r0 && r0.then), revisadas, impresos: impresos.slice() };
b.numerarComanda = 'dia'; b.cobrando = true; b.lineas.push({ ...POSTRE(), detalle: 'Flan' }); await b.enviarComanda(); b.cobrando = false;
out.al_cobrar_numero = { revisadas, impresos: impresos.slice(2) };
""")
    assert r["falla"]["impresos"] == ["Limonada @Mesa 6", "Postre @Mesa 6"] and r["falla"]["avisos"] == ["Comanda 2 enviada a Cocina"], r      # antes: no salía nada
    assert r["falla_numero"]["impresos"] == ["Limonada #77 @Mesa 6", "Postre #77 @Mesa 6"] and r["falla_numero"]["avisos"] == ["Comanda N.º 77 enviada a Cocina"], r
    x = r["rehace"]
    assert x["impresos"] == ["Postre @Mesa 6"] and x["servidor"] == [["Casado×1", "Postre×1"]], r            # antes: salía la Limonada y volvía a la cuenta
    assert x["avisos"] == ["No salió en la comanda: Limonada. En otro equipo ya se había quitado o cobrado de Mesa 6.", "Comanda 2 enviada a Cocina"], r
    assert r["al_cobrar"] == {"promesa": False, "revisadas": 0, "impresos": ["Limonada @Mesa 6", "Postre @Mesa 6"]}, r
    assert r["al_cobrar_numero"]["revisadas"] == 0 and r["al_cobrar_numero"]["impresos"] == ["Flan #78 @Mesa 6"], r


def test_d_mesa_movida_cliente_del_otro_equipo_y_textos_en_node(tmp_path):
    r = _correr(tmp_path, """
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
// D-7: B tiene la Limonada guardada sin enviar; A mueve la cuenta a la Mesa 8; B, sin enterarse, manda la comanda: sale con la Mesa 8
reiniciarCobro(); let [a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(LIMONADA()); await mesas(a); await b.sincronizar();
await a.sincronizar(); a.abrirMesa(M6); a.moverA({ id: 8, nombre: 'Mesa 8' }); await a.A.mock.guardarTodo();
const impresos = []; b.cfg.imprimir_comanda = true; b.destinoDe = () => COCINA; b.imprimirComanda = (g, ronda, d) => { for (const x of Object.values(g)) for (const l of x.ls) impresos.push(l.detalle + ' @' + d.cuenta); };
b.lineas.push(POSTRE()); await b.enviarComanda(); await b.A.mock.guardarTodo();
out.movida = { impresos, pantalla: [b.mesaActual && b.mesaActual.id, b.nombreEspera], servidor: S.items.map(x => [x.mesa_id, x.nombre]) };
// D-5: el cliente que eligió otro equipo llega en la sincronización: ese paso no corrige el total del plano (no guarda nada)
reiniciarCobro(); [a, b] = await mesaAbierta([CASADO()]);
S.items[0].cliente_id = 5; S.items[0].total = 3000; S.version++;
let n0 = S.cuerpos.length; await a.sincronizar(); await a.A.mock.guardarTodo();
out.cliente = { guardados: S.cuerpos.length - n0, cliente: a.clienteId, total: S.items[0].total };
// D-8: «1 plato» y «2 platos»
reiniciarCobro(); [a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); a.volverAMesas(false); await a.A.mock.guardarTodo();
a.abrirMesa(M6); a.lineas.push(LIMONADA()); a.volverAMesas(false); await a.A.mock.guardarTodo();
out.textos = avisos(a).filter(t => t.includes('quedó guardada'));
""")
    m = r["movida"]
    assert m["impresos"] == ["Limonada @Mesa 8", "Postre @Mesa 8"] and m["pantalla"] == [8, "Mesa 8"] and m["servidor"] == [[8, "Mesa 8"]], r   # antes: «Mesa 6»
    assert r["cliente"] == {"guardados": 0, "cliente": 5, "total": 3000}, r                     # antes: guardaba el total calculado sin los precios del cliente
    assert r["textos"] == ["Mesa 6 quedó guardada con 1 plato sin enviar a cocina: use «Comanda» para enviarlo",
                           "Mesa 6 quedó guardada con 2 platos sin enviar a cocina: use «Comanda» para enviarlos"], r


def test_d_la_estacion_se_carga_al_abrir_la_caja_en_node(tmp_path):
    """D-6: created y beforeUnmount reales de caja.js (el import de _estacion.js, cambiado por una función de la prueba): con el módulo, la
    estación se inicia y se detiene; si no carga, la caja abre igual; si se sale antes de que cargue, no se inicia."""
    k = _js("pages/pos/caja.js")
    fuente = _tramo(k, "  async created() {", "\n  mounted()").strip().rstrip(",") + ",\n" + _tramo(k, "  beforeUnmount() {", "\n").strip().rstrip(",")
    assert fuente.count("import('./_estacion.js')") == 1 and "from './_estacion.js'" not in k
    fuente = fuente.replace("import('./_estacion.js')", "cargarEstacion()")
    r = _node(tmp_path, """
const fuente = %s;
const Q = { est: [], modulo: null };
const ev = { addEventListener() {}, removeEventListener() {} };
const M = new Function('mock', 'api', 'cuentasParaMovimientos', 'localStorage', 'sesion', 'cargarEquipo', 'window', 'document', 'red', 'setInterval', 'clearInterval', 'setTimeout', 'cargarEstacion', 'return {' + fuente + '};')(
  { alCambiarIds: () => () => {} }, async () => [], async () => [], { getItem: () => null }, { empresaInfo: {} }, async () => {}, { ...ev, innerWidth: 1200 }, { ...ev, hidden: false }, { enLinea: true }, () => 1, () => {}, () => 1,
  () => Q.cargar());
const EST = { iniciarEstacion: o => Q.est.push('iniciar:' + o), pararEstacion: o => Q.est.push('parar:' + o) };
function caja() {
  const vm = { cfg: { id: 1 }, sinConfigurar: false, caja: null, cola: [], seguirIds() {}, bodegaDefecto() {}, abrirGuia() {}, cargarExistencias() {}, tecla() {}, revisarOnline() {}, sincronizar() {}, cargarCola() {}, reponerPendientes() {}, reintentarPendientes() {}, abrirApertura() {} };
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const out = {};
Q.cargar = () => Promise.resolve(EST); let vm = caja(); await vm.created(); await pasar(); out.carga = [!!vm._est, Q.est.slice()]; vm.beforeUnmount(); out.carga.push(Q.est.slice());
Q.est = []; Q.cargar = () => Promise.reject(new Error('no carga')); vm = caja(); await vm.created(); await pasar(); out.falla = [!!vm._est, Q.est.slice()]; vm.beforeUnmount(); out.falla.push(Q.est.slice());
Q.est = []; let soltar; Q.cargar = () => new Promise(r => { soltar = r; }); vm = caja(); await vm.created(); vm.beforeUnmount(); soltar(EST); await pasar(); out.antes = [!!vm._est, Q.est.slice()];
console.log(JSON.stringify(out));
process.exit(0);
""" % json.dumps(fuente), archivos=(), falsos={})
    assert r["carga"] == [True, ["iniciar:caja"], ["iniciar:caja", "parar:caja"]], r
    assert r["falla"] == [False, [], []], r
    assert r["antes"] == [False, []], r


# ================================================================================================================ textos y contrato
def test_textos_y_contrato_del_cobro():
    k = _js("pages/pos/caja.js")
    for texto in ("'Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar.'",
                  "'Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar.'",
                  "nombre + ' quedó guardada con 1 plato sin enviar a cocina: use «Comanda» para enviarlo'",
                  "nombre + ' quedó guardada con ' + pend + ' platos sin enviar a cocina: use «Comanda» para enviarlos'"):
        assert texto in k, texto
    assert "plato(s)" not in k
    cobro = _metodo(k, "async emitirCobro(otra) {")
    # se pide después de las revisiones que pueden rechazar el cobro y de la comanda de la venta rápida, y antes de emitir
    assert cobro.index("this.cobrando = true;") < cobro.index("if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial")   # 4.39: también la cuenta guardada sin mesa < cobro.index("rc = await this.reclamarCobro(lineasCobradas);") < cobro.index("doc = await api('/api/comprobantes'")
    assert "const reclamar = !!this.cuentaDelCobro().id;" in cobro              # con el id de antes de la comanda de la venta rápida (4.31, cuarta vuelta: la parte, con su cuenta de origen)
    # 4.39 (segunda vuelta, R2): con la cuenta ya en el servidor, después de ganar el cobro se trae y se junta lo de otro equipo ANTES de la
    # comanda: dos salidas nuevas que sueltan el cobro sin emitir (la cuenta ya no está → cobroDeCuentaCerrada; cambió → cobroCambiado).
    # Son 6: cerrada tras refrescar / cambió tras juntar / cambió tras la comanda / no emitió / ya emitió / al terminar; ninguna espera
    # 4.39 (sexta vuelta, W11): en una mesa con el cobro pedido (V2), después de esperar la comanda de otro equipo se junta otra vez: dos
    # salidas más que sueltan el cobro sin emitir (la cuenta ya no está → cobroOcupado «cobrada»; cambió → cobroCambiado). Son 8
    assert cobro.count("this.soltarCobro(rc, ") == 8 and "await this.soltarCobro" not in k                       # no emitió / ya emitió / al terminar; sin esperar; 4.39: la cuenta guardada cambió después de pedir el cobro
    assert "if (!enEspera().some(v => v.id === esperaId)) { if (rc && rc.clave) this.soltarCobro(rc, false); return this.cobroDeCuentaCerrada(); }" in cobro
    assert "if (cambio0) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio0; }" in cobro
    # 4.39 (séptima vuelta, X3): la cuenta que ya no está después de esperar la comanda de otro equipo va con «cerrada» (sin el aviso «ya se
    # cobró»: la cuenta pudo borrarse o pasar a otra mesa); el cobro pedido se suelta igual, sin emitir
    assert "if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }" in cobro   # sexta vuelta
    assert "if (cambio2) { this.soltarCobro(rc, false); return cambio2; }" in cobro                                                                                       # sexta vuelta
    assert cobro.count("this.soltarCobro(rc, true, ") == 2 and cobro.count("this.soltarCobro(rc, false)") == 6   # «cobrado» solo después de emitir (sigue / al terminar)
    hab = _tramo(k, "    cargarAHabitacion() {", "\n    },\n")
    assert hab.index("if (this.esperaId && !this._rcHab) return this.reclamarHab();") < hab.index("const t = this.totales") and "this.soltarCobro(rcHab, true, lineas);" in hab
    assert "    cargarAHabitacion() {" in k and "async cargarAHabitacion" not in k
    # el cobro pedido: la pestaña (EQUIPO de _fusion.js), una clave por cobro, 8 s para empezar a responder; la ruta en una línea de main.py
    rec = _metodo(k, "async reclamarCobro(lineas) {")   # 4.31 (sexta vuelta): sin `fijo` (ya no hay parte «aparte»); sin conexión, {sinRed}
    assert "equipo: EQUIPO, clave," in rec and "const clave = nuevoLid()" in rec and "limite: 8000" in rec and "if (red.enLinea === false) return { sinRed: true };" in rec
    assert "restoDe, cierreDeCobro, EQUIPO } from './_fusion.js';" in k
    assert "aparcarParte" not in k and "revisarAparte" not in k and "quedó aparte" not in k   # 4.31 (sexta vuelta, M3): la variante «aparte» ya no existe
    # la revisión de la comanda nunca detiene la comanda
    assert _metodo(k, "comandaNumerada(modo,").count(".catch(() => {") == 1 and _metodo(k, "comandaRevisada(nuevas, grupos, ronda, ahora) {").count(".catch(() => {") == 1


# ================================================================================================================ cuarta vuelta
def test_cuarta_r1_el_cobro_se_pide_para_la_cuenta_de_origen_en_node(tmp_path):
    """R1: el cobro se pide con la cuenta de la que salieron los platos (antes, con la que quedaba al volver a guardarla: null o un id
    nuevo, y el cobro no frenaba nada)."""
    r = _correr(tmp_path, """
// (a) A cobró la cuenta completa y B, sin enterarse, toca «Cobrar la parte 1»: la cuenta ya no está; no se parte ni se cobra
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b._alDia = 0; await b.cobrarParte(2); await espera(30); if (b.pago) await b.cobrar(); await hastaLibre(); await hasta(() => b.vista === 'mesas');
out.a = { emitidos: emitidos().map(x => x[1]), servidor: servidor().length, pago: b.pago, cp: b.cobroParcial, vista: b.vista, aviso: avisos(b).filter(t => t.includes('fue cobrada o cerrada en otro equipo')).length };
// (b) B abrió «Dividir» hace un momento (no vuelve a bajar la lista); A cobra completa; B agrega un Postre y toca «Cobrar la parte 1» y
// F9: su guardado hace que el servidor rehaga la cuenta con el Postre (otro id). El cobro se pide para la de antes: «cobrada»
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
b._alDia = Date.now();
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b.lineas.push(POSTRE()); await b.cobrarParte(2); await conPago(b); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
b._alDia = 0; await b.alDiaParaCobrar(true);
out.b = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(b), servidor: servidor().map(x => x.platos), pantalla: b.lineas.map(l => l.detalle + '×' + l.cantidad), cp: b.cobroParcial };
// (c) lo mismo con la cuenta completa: B tiene el Postre guardándose y toca F9 sobre la cuenta que A acaba de cerrar
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
b._alDia = Date.now();
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b.lineas.push(POSTRE()); b.persistirCuenta(); await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
b._alDia = 0; await b.alDiaParaCobrar(true);
out.c = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(b), servidor: servidor().map(x => x.platos), pantalla: b.lineas.map(l => l.detalle + '×' + l.cantidad), pedidas: C.llamadas.filter(x => x[0] === b.nEq && x[1] === '/api/pos/cobro/reclamar').length };
// (d) como (a) con «Dividir» → «cobrar ahora solo esos»: la cuenta ya no está; no se parte ni se pide el cobro
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b._alDia = 0; await b.abrirDividir(); b.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } };
await b.confirmarDividir(); await espera(30); if (b.pago) await b.cobrar(); await hastaLibre(); await hasta(() => b.vista === 'mesas');
out.d = { emitidos: emitidos().map(x => x[1]), servidor: servidor().length, pago: b.pago, cp: b.cobroParcial, vista: b.vista, dividir: b.dividir, pedidas: reclamos(b.nEq), aviso: avisos(b).filter(t => t.includes('fue cobrada o cerrada en otro equipo')).length };
// (e) como (b) con «cobrar ahora solo esos» (1 Casado): el guardado del resto con el Postre rehace la cuenta; el cobro se pide para la de antes
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
b._alDia = Date.now();
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b.lineas.push(POSTRE()); await b.abrirDividir(); b.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } };
await b.confirmarDividir(); await conPago(b); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
b._alDia = 0; await b.alDiaParaCobrar(true);
out.e = { emitidos: emitidos().map(x => x[1]), avisos: delCobro(b), servidor: servidor().map(x => x.platos), pantalla: b.lineas.map(l => l.detalle + '×' + l.cantidad), cp: b.cobroParcial, pedidas: reclamos(b.nEq) };
""" % {"dos": DOS})
    a = r["a"]
    assert a == {"emitidos": [TOTAL_DOS], "servidor": 0, "pago": None, "cp": None, "vista": "mesas", "aviso": 1}, r          # antes: la parte se cobraba otra vez
    b = r["b"]
    assert b["emitidos"] == [TOTAL_DOS] and b["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert b["servidor"] == [["Postre×1"]] and b["pantalla"] == ["Postre×1"] and b["cp"] is None, r                          # el Postre, entero, sigue en la mesa
    c = r["c"]
    assert c["emitidos"] == [TOTAL_DOS] and c["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert c["servidor"] == [["Postre×1"]] and c["pantalla"] == ["Postre×1"] and c["pedidas"] == 1, r                      # antes: Casado y Limonada otra vez
    d = r["d"]
    assert d == {"emitidos": [TOTAL_DOS], "servidor": 0, "pago": None, "cp": None, "vista": "mesas", "dividir": None, "pedidas": 0, "aviso": 1}, r
    e = r["e"]
    assert e["emitidos"] == [TOTAL_DOS] and e["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert e["servidor"] == [["Postre×1"]] and e["pantalla"] == ["Postre×1"] and e["cp"] is None and e["pedidas"] == 1, r     # antes: el Casado otra vez


def test_cuarta_r2_r3_ocupada_no_descarta_y_el_resto_se_va_con_el_cobro_en_node(tmp_path):
    """R2: el resto que guardó el que partía se va con el cobro completo del otro. R3: con «ocupada» no se descarta nada (si el otro no
    emite, nada se pierde); al cerrar el cobro que quedó abierto, lo ya cobrado por el otro no vuelve a la cuenta."""
    r = _correr(tmp_path, """
// R2: A, con la cuenta completa en pantalla, cobra mientras B la partía para «Cobrar la parte 1»: el resto que B guardó se va con el cobro
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await b.cobrarParte(2); await b.A.mock.guardarTodo(); await conPago(b);
out.r2 = { srv0: servidor().map(x => x.platos) };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo(); await a.sincronizar();
Object.assign(out.r2, { emitidos: emitidos().map(x => x[1]), servidor: servidor().length, avisosB: delCobro(b), agrego: avisos(a).filter(t => t.includes('otro equipo le agregó')).length });
// R3: A tiene el cobro de la cuenta completa y su emisión falla; B tocó «Cobrar la parte 1» y F9 mientras tanto («ocupada»): su parte
// sigue en su cobro. B la cobra al tocar otra vez y A, al volver a cobrar, cobra lo que queda: la cuenta entera, una sola vez
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await b.cobrarParte(2); await b.A.mock.guardarTodo(); await conPago(b);
C.emitirLento = 150; C.fallaEmitir = a.nEq;
const pA = a.cobrar(); await hasta(() => C.reclamos[1] && C.reclamos[1].estado === 'reclamada');
await b.cobrar();
out.r3 = { avisosB: delCobro(b), abierto: [!!b.pago, b.cobroParcial && b.cobroParcial.parte, b.lineas.map(l => l.detalle + '×' + l.cantidad)] };
await pA; await hastaLibre(); C.emitirLento = 0;
out.r3.fallo = avisos(a).filter(t => t.startsWith('No se emitió')).length; out.r3.srv = servidor().map(x => x.platos);
if (b.pago) await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
a.cerrarPago(); a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.r3.final = { emitidos: emitidos().map(x => x[1]), suma: suma(), servidor: servidor().length };
// con la parte 1 ya cobrada, los dos tocan «Cobrar parte 2» y F9 a la vez; el que pierde queda con su cobro abierto y, ya cobrado por el
// otro, lo cierra (Esc): esos platos no vuelven a la cuenta (si volvían, quedaban en la mesa y se cobraban dos veces)
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await a.cobrarParte(2); await conPago(a); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await a.sincronizar(); a.abrirMesa(M6); await b.sincronizar(); b.abrirMesa(M6); a._alDia = 0; b._alDia = 0;
await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await conPago(a, b);
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
const p2 = C.emitidos[1].n === a.nEq ? b : a;
out.esc = { abierto: !!p2.pago, avisos0: delCobro(p2) };
p2.cerrarPago(); await hasta(() => !p2.pago); await espera(50); await p2.A.mock.guardarTodo();
out.esc.tras = { pago: p2.pago, cp: p2.cobroParcial, avisos: delCobro(p2), servidor: servidor().length, emitidos: emitidos().length, suma: suma() };
""" % {"dos": DOS})
    x = r["r2"]
    assert x["srv0"] == [["Casado×1", "Limonada×1"]], r                                                    # lo que B dejó en la mesa (con `de`)
    assert x["emitidos"] == [TOTAL_DOS] and x["servidor"] == 0 and x["agrego"] == 0, r                        # antes: quedaban ₡5 650 en la mesa
    assert x["avisosB"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    x = r["r3"]
    assert x["avisosB"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert x["abierto"] == [True, 1, ["Casado×1", "Limonada×1"]] and x["fallo"] == 1 and x["srv"] == [["Casado×1", "Limonada×1"]], r
    assert x["final"] == {"emitidos": [MITAD, MITAD], "suma": TOTAL_DOS, "servidor": 0}, r                     # antes: se perdía la mitad
    e = r["esc"]
    assert e["abierto"] is True and e["avisos0"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."], r
    assert e["tras"] == {"pago": None, "cp": None, "avisos": ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar.",
                                                              "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."],
                         "servidor": 0, "emitidos": 2, "suma": TOTAL_DOS}, r


def test_cuarta_p2_p3_partes_y_cuenta_al_dia_tras_el_choque_en_node(tmp_path):
    """P2: el que pierde «Cobrar la parte 1» ve enseguida «Cobrar parte 2» y cobra lo que queda, aunque el cobro del otro todavía no haya
    llegado a la cuenta. P3: tras «se está cobrando en otro equipo» por la cuenta completa, la pantalla se pone al día sola cuando el otro
    termina."""
    r = _correr(tmp_path, """
// P2
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]); await conPago(a, b);
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
const pierde = C.emitidos[0].n === a.nEq ? b : a;
Object.assign(S.items[0], { cobros: [], partes: { total: 2, cobradas: 0 } }); S.version++;    // el cobro del otro todavía no llegó a la cuenta
await pierde.cobrar();
out.p2 = { avisos: delCobro(pierde).slice(1), boton: (pierde.partesDe(pierde.cuentaActual) || {}).cobradas, pantalla: pierde.lineas.map(l => l.detalle + '×' + l.cantidad) };
await pierde.cobrarParte(2); await conPago(pierde); out.p2.parte = [pierde.cobroParcial.parte, pierde.cobroParcial.de];
await pierde.cobrar(); await hastaLibre(); await pierde.A.mock.guardarTodo();
out.p2.final = { emitidos: emitidos().map(x => x[1]), suma: suma() };
// P3
reiniciarCobro(); [a, b] = await mesaAbierta(%(dos)s);
await Promise.all([a.abrirPago(), b.abrirPago()]); C.emitirLento = 300;
const pA = a.cobrar(); await hasta(() => C.reclamos[1] && C.reclamos[1].estado === 'reclamada'); await b.cobrar();
out.p3 = { avisos: delCobro(b), vista0: b.vista, pago: b.pago };
await pA; await hastaLibre(); await a.A.mock.guardarTodo(); C.emitirLento = 0;
for (let i = 0; i < 40 && b.vista !== 'mesas'; i++) await espera(100);
out.p3.despues = { vista: b.vista, esperaId: b.esperaId, aviso: avisos(b).filter(t => t.includes('fue cobrada o cerrada en otro equipo')).length, emitidos: emitidos().map(x => x[1]) };
""" % {"dos": DOS})
    p = r["p2"]
    assert p["avisos"] == ["Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."], r
    assert p["boton"] == 1 and p["pantalla"] == ["Casado×1", "Limonada×1"], r                                # el botón: «Cobrar parte 2»
    assert p["parte"] == [2, 2] and p["final"] == {"emitidos": [MITAD, MITAD], "suma": TOTAL_DOS}, r          # antes: «parte 1 de 2» de lo que quedaba
    q = r["p3"]
    assert q["avisos"] == ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."] and q["vista0"] == "venta" and q["pago"] is None, r
    assert q["despues"] == {"vista": "mesas", "esperaId": None, "aviso": 1, "emitidos": [TOTAL_DOS]}, r        # antes: seguía con la cuenta entera
    # el botón y la marca «parte k de n» de la pantalla salen de partesDe (con la parte que el otro equipo acaba de cobrar)
    k = _js("pages/pos/caja.js")
    assert _linea(k, "partesCuenta() {") == "partesCuenta() { return this.partesDe(this.cuentaActual); }"
    assert 'Cobrar parte {{(+partesCuenta.cobradas || 0) + 1}}' in k and 'parte {{(+partesCuenta.cobradas || 0) + 1}} de {{partesCuenta.total}}' in k


def test_cuarta_p4_la_precuenta_no_sale_con_otra_mesa_en_node(tmp_path):
    """P4: «Precuenta» de una cuenta que ya existía y enseguida «Mesas»: la ventana se cierra y se pide tocar otra vez (antes salía una hoja
    vacía de «Para llevar»). Sin cambiar de mesa sale como siempre."""
    r = _correr(tmp_path, """
reiniciarCobro(); let [a] = await mesaAbierta([CASADO()]);
C.ventanas = []; a.lineas.push(POSTRE()); const pp = a.precuenta(); a.volverAMesas(false); await pp;
out.cambia = { escritas: C.ventanas.length, cerradas: C.cerradas, aviso: avisos(a).filter(t => t === 'La mesa en pantalla cambió antes de que saliera la precuenta. Toque «Precuenta» otra vez.').length };
reiniciarCobro(); [a] = await mesaAbierta([CASADO()]);
C.ventanas = []; a.lineas.push(POSTRE()); await a.precuenta();
out.igual = [C.ventanas.length, C.cerradas, (C.ventanas[0] || '').includes('Postre') && (C.ventanas[0] || '').includes('Casado')];
""")
    assert r["cambia"] == {"escritas": 0, "cerradas": 1, "aviso": 1}, r
    assert r["igual"] == [1, 0, True], r


# ================================================================================================================ quinta vuelta
X6 = """
const VOLVIO = 'La parte que tenía abierta volvió a Mesa 6: Casado, Limonada.';
const totalSrv = () => r2(S.items.reduce((s, x) => s + (x.lineas || []).reduce((t, l) => t + (+l.cantidad || 0) * (+l.precio_unitario || 0) * 1.13, 0), 0));
// X6: A tiene abierto «Cobrar la parte 1» (con un 500 al emitir o sin tocar F9); B, al día, cobra lo que ve (F9 o «Cobrar parte 1»); A cierra
// (Cancelar o Esc) o cobra (F9). `alDia`: A bajó la lista antes de cerrar. Al final A cobra lo que quedó en la mesa
async function x6(variante, falla, alDia) {
  reiniciarCobro(); const [a, b] = await mesaAbierta(%(dos)s);
  await a.cobrarParte(2); await a.A.mock.guardarTodo(); await conPago(a);
  if (falla) { C.fallaEmitir = a.nEq; await a.cobrar(); }
  b._alDia = 0; await b.sincronizar(); b.abrirMesa(M6);
  if (variante === 'b_f9') { await b.abrirPago(); await b.cobrar(); } else { await b.cobrarParte(2); await conPago(b); await b.cobrar(); }
  await hastaLibre(); await b.A.mock.guardarTodo();
  if (alDia) await a.sincronizar();
  if (variante === 'a_f9') await a.cobrar(); else await a.cerrarPago();
  await hastaLibre(); await a.A.mock.guardarTodo(); await espera(60);
  const x = { cobrado: suma(), queda: totalSrv(), cuentas: S.items.length, pago: a.pago, cp: a.cobroParcial, volvio: avisos(a).filter(t => t === VOLVIO).length, pantalla: a.lineas.map(l => l.detalle + '×' + l.cantidad).sort(),
    mientras: avisos(a).filter(t => t.includes('mientras usted agregaba platos')).length };   /* sexta vuelta: A no agregó nada */
  a._alDia = 0; await a.sincronizar(); a.abrirMesa(M6); await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  x.final = { suma: suma(), servidor: S.items.length };
  return x;
}
for (const v of ['b_f9', 'b_boton', 'a_f9']) for (const falla of [false, true]) for (const alDia of [false, true]) out[v + (falla ? '_500' : '') + (alDia ? '_aldia' : '')] = await x6(v, falla, alDia);
"""


def test_quinta_x6_la_parte_abierta_nunca_desaparece_en_node(tmp_path):
    """X6 (alto, prueba:mesa4): con «Cobrar la parte 1» abierto en A, B cobra lo que ve; al cerrar A (o al cobrar con «cambiada») la mitad de
    la cuenta desaparecía y se cobraban ₡5 650 de ₡11 300. Ahora lo que A no emitió vuelve siempre a la mesa: entre los dos se cobra la cuenta
    completa, con el aviso «La parte que tenía abierta volvió a Mesa 6: …» (variantes a, b y c; con y sin un 500 al emitir; con la lista de A
    atrasada o al día)."""
    r = _correr(tmp_path, X6 % {"dos": DOS})
    for k, x in r.items():
        assert x["pago"] is None and x["cp"] is None, (k, x)
        assert x["cobrado"] + x["queda"] == TOTAL_DOS and x["queda"] > 0 and x["cuentas"] == 1, (k, x)       # antes: faltaba media cuenta
        assert x["final"] == {"suma": TOTAL_DOS, "servidor": 0}, (k, x)                                     # y lo que quedó se cobra
        assert x["volvio"] == 1, (k, x)
        assert x["mientras"] == 0, (k, x)                       # sexta vuelta: no «se cobró … mientras usted agregaba platos» (A no agregó nada)
    assert r["b_f9"]["cobrado"] == MITAD and r["b_boton"]["cobrado"] == MITAD / 2 and r["a_f9_500"]["cobrado"] == MITAD / 2, r


def test_quinta_m2_el_resto_ajeno_de_lo_cobrado_entero_sale_con_la_parte_en_node(tmp_path):
    """M2 (medio): A cobra «solo esos» con los 2 Casados (la línea entera) y B, casi a la vez, «solo esos» con 1 Casado; el guardado de B llega
    primero y deja Casado ×1 (con `de`). Antes ese Casado ×1 de B se quedaba en la mesa y se cobraba (3 Casados por 2). Sexta vuelta: A ya
    no emite («partida»: B partió el mismo Casado antes) y B cobra el suyo; el otro queda en la mesa. Igual si A cobra solo parte de la línea."""
    r = _correr(tmp_path, """
async function m2(selA) {
  reiniciarCobro(); const [a, b] = await mesaAbierta(%(dos)s);
  await a.abrirDividir(); await b.abrirDividir();
  b.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } }; await b.confirmarDividir(); await b.A.mock.guardarTodo();
  a.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: selA } }; await a.confirmarDividir(); await a.A.mock.guardarTodo(); await conPago(a, b);
  await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  const x = { emitidos: emitidos().map(e => e[1]), avisosA: delCobro(a), avisosB: delCobro(b), servidor: servidor().map(s => s.platos.slice().sort()) };
  await a.sincronizar(); a.abrirMesa(M6); await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre();
  x.suma = suma(); return x;
}
out.entera = await m2(2);
out.parte = await m2(1);
""" % {"dos": DOS})
    # 4.31 (sexta vuelta, P1): el guardado de B llegó primero y la cuenta tiene el resto de B (de lC): el Casado de A ya está, una parte en la
    # de B y la otra en la cuenta. A no emite («partida») y no vuelve nada; B cobra su Casado. Antes A cobraba los 2 Casados y B quedaba fuera:
    # las dos formas suman lo mismo, pero ahora es la misma regla que «partes a la vez»
    partida = "Otro equipo partió esta misma cuenta a la vez. Aquí no se cobró nada; revise la cuenta y cobre lo que queda."   # séptima vuelta (B2)
    e = r["entera"]
    assert e["emitidos"][0] == 3955 and e["avisosA"] == [partida] and e["avisosB"] == [], r
    assert e["servidor"] == [["Casado×1", "Limonada×2"]] and e["suma"] == TOTAL_DOS, r        # en la quinta: quedaba el Casado ×1 de B (₡15 255)
    p = r["parte"]
    assert p["emitidos"][0] == 3955 and p["avisosA"] == [partida] and p["servidor"] == [["Casado×1", "Limonada×2"]] and p["suma"] == TOTAL_DOS, r


def test_quinta_m3_sin_conexion_al_emitir_no_suelta_el_cobro_en_node(tmp_path):
    """M3 (medio): A emite la cuenta y la respuesta se pierde (sin conexión). Antes soltaba el cobro como «no cobrado» y B, con su cobro
    abierto, lo ganaba y cobraba otra vez. Ahora el cobro queda tomado (vence solo) y la venta sin conexión lleva el cobro pedido con sus
    platos (al emitirse desde la cola se anotan como cobrados). Un error del servidor (500) sí lo suelta, como siempre."""
    r = _correr(tmp_path, """
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await b.abrirPago(); C.perderEmitir = a.nEq;
await a.cobrar(); await espera(30);
out.perdida = { estado: C.reclamos[1] && C.reclamos[1].estado, soltar: C.llamadas.filter(x => x[0] === a.nEq && x[1] === '/api/pos/cobro/soltar').length, cola: C.sinConexion.map(x => [x[0] === a.nEq, x[2] && x[2].id, x[2] && x[2].lids.length, !!(x[2] && x[2].clave)]) };
await b.cobrar(); await espera(30);
out.perdida.b = { emitidos: C.emitidos.length, avisos: delCobro(b) };
reiniciarCobro(); [a] = await mesaAbierta(%(dos)s);
await a.abrirPago(); C.fallaEmitir = a.nEq; await a.cobrar(); await hastaLibre();
out.error = { estado: C.reclamos[1] && C.reclamos[1].estado, emitidos: C.emitidos.length };
""" % {"dos": DOS})
    p = r["perdida"]
    assert p["estado"] == "reclamada" and p["soltar"] == 0, r                                   # antes: «libre» (soltado sin cobrar)
    assert p["cola"] == [[True, 1, 2, True]], r
    assert p["b"] == {"emitidos": 1, "avisos": ["Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."]}, r   # antes: B emitía otra vez
    assert r["error"] == {"estado": "libre", "emitidos": 0}, r


def test_quinta_m3_la_cola_anota_los_platos_cobrados_en_node(tmp_path):
    """M3: la venta que quedó sin conexión guarda el cobro pedido de la cuenta y, cuando la cola la emite, suelta ese cobro como cobrado con
    sus platos (otro equipo atrasado ya no los cobra). Sin cobro pedido (venta rápida) no se manda nada más. ventaSinConexion,
    reintentarPendientes y lo que usan, tal cual de caja.js."""
    k = _js("pages/pos/caja.js")
    fuente = ",\n".join([_metodo(k, "ventaSinConexion(c) {"), _metodo(k, "async reintentarPendientes(manual) {"), _metodo(k, "anotarEnCola(clave, id, cambios) {"),
                         _metodo(k, "quitarDeCola(clave, id) {"), _linea(k, "cargarCola() {"), _linea(k, "guardarCola() {"), _linea(k, "guardarColaEn(clave) {"), _linea(k, "claveCola() {"),
                         _metodo(k, "cierreCobro(id, lineas) {")])   # 4.31 (sexta vuelta): la condición de la baja también lleva lo quitado sin guardar
    r = _node(tmp_path, """
const fuente = %s;
const F = await import('./js/pages/pos/_fusion.js');
const Q = { llamadas: [], toasts: [], ls: {}, bajas: [], espera: [] };
const localStorage = { getItem: k => (k in Q.ls ? Q.ls[k] : null), setItem: (k, v) => { Q.ls[k] = String(v); } };
const api = async (u, o) => { Q.llamadas.push([u, o && o.body ? JSON.parse(JSON.stringify(o.body)) : null]); if (u === '/api/comprobantes') return { id: 7, consecutivo: '00100001040000000007', total: 3955, estado: 'aceptado' }; if (u === '/api/pagos') return { numero: 'P1' }; return {}; };
const mock = { generacion: 1, actualizar: (k, f, d) => f(d), get: (k, d) => (k === 'pos_espera' ? Q.espera : d) };
const NOMBRES = ['api', 'toast', 'money', 'r2', 'hoy', 'nombreMedio', 'store', 'mock', 'localStorage', 'navigator', 'sesion', 'cajaPorId', 'registrarVentaEnCaja', 'uuid', 'vistaTrasCobro', 'porAgente', 'abrirGaveta', 'cierreDeCobro', 'EQUIPO'];
const M = new Function(...NOMBRES, 'return {' + fuente + '};')(api, m => Q.toasts.push(m), v => String(v), n => Math.round((+n || 0) * 100) / 100, () => '2026-11-13', m => m, { empresa: { id: 1 } }, mock, localStorage, {},
  { electronica: false, usuario: { correo: 'caja-431@example.test' } }, () => null, () => {}, () => 'u', () => 'mesas', () => false, async () => {}, F.cierreDeCobro, F.EQUIPO);
function caja() {
  const vm = { cola: [], reintentando: false, _fuera: false, cfg: { enviar_hacienda: false, imprimir_auto: false }, ultima: null, autorizado: null, cupon: null, puntos: null, cobroParcial: null, prepago: null, esRestaurante: true,
    totales: { servicio: 0, iva: 455 }, lineas: [{ lid: 'lC', detalle: 'Casado', cantidad: 1, precio_unitario: 3500, tarifa: 13 }], idem: 'v1', $refs: {}, $nextTick: f => f && f(), _base: null,
    cuentaPara: () => 'Caja general', cabSucursal: () => ({}), bajaCuenta(id, lineas) { Q.bajas.push([id, lineas]); }, difundir() {}, imprimirProvisional() {}, impresoraTiquete: () => null, descuentoDe: () => 0, autorizar: async () => false };
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const out = {};
const c = { body: { lineas: [] }, tipoDoc: '04', total: 3955, medios: [{ medio: '01', monto: 3955 }], propina: 0, principal: { medio: '01' }, usd: null, recibido0: null, pt: { vuelto: 0 }, clienteId: null, cliente: null,
  esperaId: 1, nombreEspera: 'Mesa 6', cajaId: null, salonero: null, imprime: false, fiado: null, regalos: [], rapida: false };
let vm = caja(); vm._reclamoSinRed = { id: 1, clave: 'clave0000001', lids: ['lC'] }; vm.ventaSinConexion(c);
out.limpio = vm._reclamoSinRed;
out.cola = JSON.parse(Q.ls['facturacr:ventas_pendientes:1']).map(v => v.reclamo || null);
await vm.reintentarPendientes(true); await new Promise(r => setTimeout(r, 20));
out.soltar = Q.llamadas.filter(x => x[0] === '/api/pos/cobro/soltar').map(x => x[1]);
out.quedan = JSON.parse(Q.ls['facturacr:ventas_pendientes:1']).length;
Q.llamadas = []; Q.ls = {}; vm = caja(); vm.ventaSinConexion({ ...c, esperaId: null }); await vm.reintentarPendientes(true); await new Promise(r => setTimeout(r, 20));
out.sin = [Q.llamadas.map(x => x[0]), JSON.parse(Q.ls['facturacr:ventas_pendientes:1']).length];
// 4.31 (sexta vuelta, S2): sin conexión, esta pantalla quitó la Limonada (✕) y bajó el Casado de 2 a 1 («−») sin guardar, y en un guardado suyo
// todavía sin confirmar ya había quitado el Postre: la baja (y lo que queda en la cola por si se recarga la página) lleva las tres cosas
Q.ls = {}; Q.bajas = []; vm = caja();
vm._base = { id: 1, lineas: [{ lid: 'lC', cantidad: 2 }, { lid: 'lL', cantidad: 1 }] };
Q.espera = [{ id: 1, lineas: [{ lid: 'lC', cantidad: 2 }, { lid: 'lL', cantidad: 1 }], _fusion: { v: 1, equipo: F.EQUIPO, origen: 'caja', nuevas: [], quitadas: { lP: 1 }, campos: {}, cuenta: [] } }];
vm.ventaSinConexion(c);
out.s2 = { baja: Q.bajas, cola: JSON.parse(Q.ls['facturacr:ventas_pendientes:1'])[0].espera_quitadas };
Q.ls = {}; Q.bajas = []; vm = caja(); vm._base = { id: 2, lineas: [{ lid: 'lX', cantidad: 1 }] }; Q.espera[0]._fusion.equipo = 'eOTRO';   // la base de otra cuenta y el guardado de otro equipo no cuentan
vm.ventaSinConexion(c); out.s2_otra = Q.bajas;
console.log(JSON.stringify(out));
process.exit(0);
""" % json.dumps(fuente), archivos=("pages/pos/_fusion.js",), falsos={})
    s2 = [{"lid": "lC", "cantidad": 2}, {"lid": "lL", "cantidad": 1}, {"lid": "lP", "cantidad": 1}]
    assert r["s2"] == {"baja": [[1, s2]], "cola": s2}, r                                                  # antes: solo lC ×1 (lo demás quedaba en la mesa)
    assert r["s2_otra"] == [[1, [{"lid": "lC", "cantidad": 1}]]], r
    assert r["cola"] == [{"id": 1, "clave": "clave0000001", "lids": ["lC"]}] and r["limpio"] is None, r
    assert r["soltar"] == [{"cuenta_id": 1, "clave": "clave0000001", "cobrado": True, "lids": ["lC"]}] and r["quedan"] == 0, r   # antes: nadie los anotaba
    assert r["sin"] == [["/api/comprobantes", "/api/pagos"], 0], r


def test_quinta_bajos_ocupada_cuanto_falta_aparte_y_dividir_en_node(tmp_path):
    """Bajos: (1) el cobro de una parte que otro equipo tiene tomado: el aviso dice cuánto falta. 4.31 (sexta vuelta, M3): ya no hay parte
    «aparte» (se perdía al salir de Caja o al cerrar la página): el cobro sigue abierto con el aviso, y al tocar Cancelar otra vez se pregunta
    de nuevo; si el otro la cobró se descarta, si no vuelve a la cuenta. (2) «Cobrar la parte 1» sobre una cuenta que otro equipo cerró cierra
    también «Dividir», y «Dividir» sin platos nunca guarda una cuenta vacía."""
    r = _correr(tmp_path, """
const OTRO = lids => ({ estado: 'reclamada', equipo: 'eOTRO0000000001', clave: 'otraclave1', lids, cobradas: [], vence: Date.now() + 45000 });
async function aparte(cobra) {
  reiniciarCobro(); const [a, b] = await mesaAbierta(%(dos)s);
  await b.cobrarParte(2); await b.A.mock.guardarTodo(); await conPago(b);
  const lids = b.lineas.map(l => l.lid); C.reclamos[1] = OTRO(lids);
  await b.cobrar(); const x = { abierto: !!b.pago };
  await b.cerrarPago(); x.esc1 = { pago: !!b.pago, aviso: avisos(b).slice(-1)[0] };
  await b.cerrarPago(); x.esc2 = { pago: !!b.pago, cp: !!b.cobroParcial, pantalla: b.lineas.map(l => l.detalle + '×' + l.cantidad), aviso: avisos(b).slice(-1)[0], servidor: servidor().map(s => s.platos) };
  if (cobra) Object.assign(C.reclamos[1], { estado: 'libre', lids: [], cobradas: lids.slice() }); else Object.assign(C.reclamos[1], { estado: 'libre', lids: [] });
  await b.cerrarPago(); await b.A.mock.guardarTodo();
  x.fin = { pago: b.pago, cp: b.cobroParcial, avisos: avisos(b), servidor: servidor().map(s => s.platos), emitidos: C.emitidos.length };
  return x;
}
out.cobra = await aparte(true);
out.no_cobra = await aparte(false);
// (2) A cobró la cuenta completa; B, sin enterarse, Dividir › En partes iguales (2) › «Cobrar la parte 1»
reiniciarCobro(); let [a, b] = await mesaAbierta(%(dos)s);
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
b._alDia = 0; b.dividir = { modo: 'partes', partes: 2, destino: 'nueva', sel: {} }; await b.confirmarDividir(); await espera(30); await hasta(() => b.vista === 'mesas');
out.dividir = { dividir: b.dividir, vista: b.vista };
b.dividir = { modo: 'partes', partes: 2, destino: 'nueva', sel: {} }; await b.confirmarDividir(); await b.A.mock.guardarTodo();
out.vacia = { cuentas: servidor().length, local: b.A.mock.get('pos_espera', []).length, dividir: b.dividir, dividida: avisos(b).filter(t => t.startsWith('Cuenta dividida')).length };
""" % {"dos": DOS})
    for k in ("cobra", "no_cobra"):
        x = r[k]
        assert x["abierto"] and x["esc1"]["pago"] is True, (k, r)
        for esc in (x["esc1"], x["esc2"]):
            assert esc["aviso"].startswith("Esta cuenta se está cobrando en otro equipo. Se libera en ") and esc["aviso"].endswith(" segundos como mucho. Esta parte sigue abierta aquí: cuando se libere, toque Cancelar otra vez para devolverla a la cuenta (lo que el otro equipo cobre no vuelve)."), (k, r)
        assert x["esc2"]["pago"] is True and x["esc2"]["cp"] is True and x["esc2"]["pantalla"] == ["Casado×1", "Limonada×1"], (k, r)   # sexta vuelta: sigue abierta (nada «aparte»)
        assert x["esc2"]["servidor"] == [["Casado×1", "Limonada×1"]] and x["fin"]["emitidos"] == 0 and x["fin"]["pago"] is None and x["fin"]["cp"] is None, (k, r)
        assert not any("aparte" in t for t in x["fin"]["avisos"]), (k, r)
    assert "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar." in r["cobra"]["fin"]["avisos"] and r["cobra"]["fin"]["servidor"] == [["Casado×1", "Limonada×1"]], r
    assert r["no_cobra"]["fin"]["servidor"] == [["Casado×2", "Limonada×2"]], r   # volvió a sus platos (como un Cancelar sin otro equipo: sin aviso)
    assert not any("ya se cobró" in t for t in r["no_cobra"]["fin"]["avisos"]), r
    assert r["dividir"] == {"dividir": None, "vista": "mesas"}, r                              # antes: «Dividir» quedaba abierto sobre el plano
    assert r["vacia"] == {"cuentas": 0, "local": 0, "dividir": None, "dividida": 0}, r         # antes: «Cuenta · parte 2 de 2» vacía (la guarda está en confirmarDividir)


# ================================================================================================================ sexta vuelta
def test_sexta_s1_pedido_para_llevar_o_express_con_el_carrito_vacio_en_node(tmp_path):
    """S1 (alto): «Para llevar / Express» abierto con el carrito vacío no creaba la cuenta (nuevaCuentaEspera devolvía null sin líneas): el
    pedido se perdía y la comanda quedaba en una «Cuenta N» sin tipo, teléfono, dirección, hora ni estado. Se EJECUTA el flujo: carrito vacío ›
    pedido con cliente y dirección guardada › confirmar › agregar platos › Comanda; el otro equipo la ve con sus datos."""
    k = _js("pages/pos/caja.js")
    mas = (_metodo(k, "abrirPedido() {"), _linea(k, "direccionesDe(c) {"), _metodo(k, "async confirmarPedido() {"))
    r = _correr(tmp_path, """
const CR = { CR_FUENTE };   // el «computed» clienteReal de caja.js
const campos = x => ({ nombre: x.nombre, pedido: x.pedido || null, telefono: x.telefono || '', direccion: x.direccion || '', hora: x.hora_entrega || '', estado: x.estado || null, cliente: x.cliente_id || null, platos: (x.lineas || []).map(l => l.detalle + '×' + l.cantidad + (l.enviado ? ' enviado' : '')) });
async function pedido(tipo) {
  reiniciarCobro(); reiniciar(); const v = await equipo(); v.vista = 'venta'; v.rapida = true;
  Object.defineProperty(v, 'clienteReal', { get() { return CR.clienteReal.call(this); } });
  v.cliente = { id: 7, nombre: 'Cliente QA', celular: '8888-0000', correo: 'cliente-qa@example.test', direcciones: [{ nombre: 'Casa', detalle: 'Barrio QA, 100 m al norte' }] }; v.clienteId = 7;
  v.abrirPedido(); const x = { seguir: v.pedido.seguir, direccion: v.pedido.direccion };
  v.pedido.tipo = tipo; v.pedido.hora_entrega = '19:30';
  await v.confirmarPedido(); await v.A.mock.guardarTodo();
  x.creada = { pantalla: [v.esperaId, v.nombreEspera, v.pedido, v.rapida], srv: S.items.map(campos), avisos: avisos(v) };
  v.lineas.push(CASADO(), LIMONADA()); v.enviarComanda(); await v.A.mock.guardarTodo();
  x.comanda = { srv: S.items.map(campos), pantalla: v.esperaId, avisos: avisos(v).slice(1) };
  const w = await equipo(); x.otro = w.A.mock.get('pos_espera', []).map(campos);
  v.volverAMesas(false); await v.A.mock.guardarTodo(); x.mesas = S.items.map(campos);
  return x;
}
out.express = await pedido('domicilio');
out.llevar = await pedido('llevar');
""".replace("CR_FUENTE", _linea(k, "clienteReal() {")), mas)
    platos = ["Casado×1 enviado", "Limonada×1 enviado"]
    e = r["express"]
    assert e["seguir"] is True and e["direccion"] == "Barrio QA, 100 m al norte", r
    datos = {"nombre": "Cliente QA", "pedido": "domicilio", "telefono": "8888-0000", "direccion": "Barrio QA, 100 m al norte", "hora": "19:30", "estado": "recibido", "cliente": 7}
    assert e["creada"]["srv"] == [{**datos, "platos": []}], r                                   # antes: [] (la cuenta no se creaba)
    assert e["creada"]["pantalla"] == [1, "Cliente QA", None, False], r
    assert e["creada"]["avisos"] == ["🛵 Express de Cliente QA: agregue los platos y envíe la comanda"], r
    assert e["comanda"]["srv"] == [{**datos, "platos": platos}] and e["comanda"]["pantalla"] == 1 and e["comanda"]["avisos"] == ["Comanda 1 enviada"], r
    assert e["otro"] == [{**datos, "platos": platos}] and e["mesas"] == [{**datos, "platos": platos}], r
    ll = r["llevar"]
    datos_ll = {**datos, "pedido": "llevar", "direccion": ""}
    assert ll["creada"]["srv"] == [{**datos_ll, "platos": []}] and ll["creada"]["avisos"] == ["🥡 Para llevar de Cliente QA: agregue los platos y envíe la comanda"], r
    assert ll["comanda"]["srv"] == [{**datos_ll, "platos": platos}] and ll["otro"] == [{**datos_ll, "platos": platos}] and ll["mesas"] == [{**datos_ll, "platos": platos}], r


P1 = """
// «Cobrar la parte 1 de 2» en los dos equipos a la vez (ninguno vuelve a bajar la lista): el guardado de A llega primero y el resto de B no
// entra (otro equipo ya partió esos platos): la parte de B es la misma porción que ya está en la parte de A o en la cuenta
async function aLaVez(sinRuta) {
  reiniciarCobro(); const [a, b] = await mesaAbierta(%(dos)s);
  a._alDia = Date.now(); b._alDia = Date.now();
  await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo(); await conPago(a, b);
  if (sinRuta) C.sinRuta = true;
  return [a, b];
}
const quedan = () => S.items.map(x => x.lineas.map(l => l.detalle + '×' + l.cantidad).sort());
const verParte = vm => vm.lineas.map(l => l.detalle + '×' + l.cantidad);
const alFinal = async vm => { vm._alDia = 0; await vm.sincronizar(); vm.abrirMesa(M6); if (vm.lineas.length) { await vm.abrirPago(); if (vm.pago) await vm.cobrar(); await hastaLibre(); await vm.A.mock.guardarTodo(); } return { suma: suma(), servidor: S.items.length }; };
// (1) B, atrasado, cancela su parte (Esc): no vuelve ni se emite, con el aviso; A cobra la suya y después lo que quedó
let [a, b] = await aLaVez();
out.inicio = { srv: quedan(), parteA: verParte(a), parteB: verParte(b) };
await b.cerrarPago(); await b.A.mock.guardarTodo();
out.esc = { avisos: delCobro(b), pago: b.pago, cp: b.cobroParcial, srv: quedan() };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.esc.emitidos = emitidos().map(e => e[1]); out.esc.fin = await alFinal(a);
// (2) B se pone al día y después cancela (su copia ya tiene el resto de A: solo el servidor sabe que la porción es la misma)
[a, b] = await aLaVez(); b._alDia = 0; await b.sincronizar();
await b.cerrarPago(); await b.A.mock.guardarTodo();
out.sinc = { avisos: delCobro(b), pago: b.pago, cp: b.cobroParcial, srv: quedan() };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); out.sinc.fin = await alFinal(a);
// (3) al revés: A cancela (su parte vuelve a la cuenta) y B cobra la suya con F9: B no emite
[a, b] = await aLaVez();
await a.cerrarPago(); await a.A.mock.guardarTodo();
out.inverso = { a: [a.pago, a.cobroParcial, delCobro(a)], srv: quedan() };
await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
out.inverso.b = { avisos: delCobro(b), emitidos: C.emitidos.length, pago: b.pago, cp: b.cobroParcial, srv: quedan() };
out.inverso.fin = await alFinal(a);
// (4) un servidor sin la ruta del cobro (no se puede preguntar): B, atrasado, cancela; el servidor no acepta su parte como plato suelto
[a, b] = await aLaVez(true);
await b.cerrarPago(); await b.A.mock.guardarTodo(); await b.sincronizar();
out.sin_ruta = { srv: quedan(), cp: b.cobroParcial };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); out.sin_ruta.fin = await alFinal(a);
"""


def test_sexta_p1_partes_a_la_vez_en_node(tmp_path):
    """P1 (alto): «Cobrar la parte 1 de 2» en los dos equipos a la vez. Antes la parte de B (la misma porción que ya está en la de A o en la
    cuenta) volvía como plato suelto al cancelarla (`<lid>+v`) o se emitía: se cobraban 3 mitades (₡16 950 de ₡11 300). Ahora el servidor no
    devuelve una línea que la cuenta nunca tuvo, y al pedir el cobro dice «partida»: la parte duplicada no se emite ni vuelve, con el aviso."""
    r = _correr(tmp_path, P1 % {"dos": DOS})
    partida = "Otro equipo partió esta misma cuenta a la vez. Aquí no se cobró nada; revise la cuenta y cobre lo que queda."   # séptima vuelta (B2)
    mitad = [["Casado×1", "Limonada×1"]]
    assert r["inicio"] == {"srv": mitad, "parteA": ["Casado×1", "Limonada×1"], "parteB": ["Casado×1", "Limonada×1"]}, r
    for k in ("esc", "sinc"):
        x = r[k]
        assert x["avisos"] == [partida] and x["pago"] is None and x["cp"] is None and x["srv"] == mitad, (k, r)   # antes: volvía (Casado ×2 …)
        assert x["fin"] == {"suma": TOTAL_DOS, "servidor": 0}, (k, r)
    assert r["esc"]["emitidos"] == [MITAD], r
    i = r["inverso"]
    assert i["a"] == [None, None, []] and i["srv"] == [["Casado×2", "Limonada×2"]], r
    assert i["b"] == {"avisos": [partida], "emitidos": 0, "pago": None, "cp": None, "srv": [["Casado×2", "Limonada×2"]]}, r   # antes: B emitía ₡5 650 de más
    assert i["fin"] == {"suma": TOTAL_DOS, "servidor": 0}, r
    s = r["sin_ruta"]
    assert s["srv"] == mitad and s["cp"] is None and s["fin"] == {"suma": TOTAL_DOS, "servidor": 0}, r   # antes: Casado×2 y Limonada×2 (₡16 950)


def test_sexta_m1_sin_respuesta_clara_la_parte_sigue_abierta_y_revisando_en_node(tmp_path):
    """M1 (medio): al cancelar una parte sin una respuesta clara del servidor (sin conexión, un error, u «ocupada» sin platos en común) la
    parte ya no vuelve a la cuenta (si el otro equipo la estaba cobrando, se cobraba dos veces): sigue abierta con el aviso y se pregunta otra
    vez al tocar Cancelar; vuelve solo con «ganada» (o lo que el otro no cobró). Mientras se pregunta, la ventana dice «Revisando…»."""
    r = _correr(tmp_path, """
const quedan = () => S.items.map(x => x.lineas.map(l => l.detalle + '×' + l.cantidad).sort());
async function sinClaro(como) {
  reiniciarCobro(); const [a] = await mesaAbierta(%(dos)s);
  await a.cobrarParte(2); await a.A.mock.guardarTodo(); await conPago(a);
  if (como === 'sin_red') { red.enLinea = false; C.caido = true; } else if (como === 'caido') C.caido = true; else if (como === 'error') C.reclamoFalla = 1;
  else C.reclamos[1] = { estado: 'reclamada', equipo: 'eOTRO0000000001', clave: 'otraclave1', lids: [], cobradas: [], vence: Date.now() + 45000 };
  await a.cerrarPago(); await a.A.mock.guardarTodo();
  const x = { pago: !!a.pago, cp: a.cobroParcial && a.cobroParcial.parte, pantalla: a.lineas.map(l => l.detalle + '×' + l.cantidad), aviso: avisos(a).slice(-1)[0], srv: quedan(), emitidos: C.emitidos.length };
  red.enLinea = true; Object.assign(C, { caido: false, reclamoFalla: 0 }); delete C.reclamos[1];
  await a.cerrarPago(); await a.A.mock.guardarTodo();
  x.luego = { pago: a.pago, cp: a.cobroParcial, srv: quedan() };
  return x;
}
for (const como of ['sin_red', 'caido', 'error', 'ocupada']) out[como] = await sinClaro(como);
// «Revisando…» mientras se pregunta (el servidor tarda)
reiniciarCobro(); const [a] = await mesaAbierta(%(dos)s);
await a.cobrarParte(2); await a.A.mock.guardarTodo(); await conPago(a);
C.reclamoLento = 200; const p = a.cerrarPago(); await espera(60);
out.revisando = { durante: [a.revisando, a.cobrando, !!a.pago] };
await p; out.revisando.despues = [a.revisando, a.cobrando, a.pago, a.cobroParcial];
""" % {"dos": DOS})
    sin = "No se pudo confirmar con el servidor si otro equipo cobró esta parte. Sigue abierta aquí: toque Cancelar otra vez en unos segundos para devolverla a la cuenta."
    for k in ("sin_red", "caido", "error", "ocupada"):
        x = r[k]
        assert x["pago"] is True and x["cp"] == 1 and x["pantalla"] == ["Casado×1", "Limonada×1"] and x["srv"] == [["Casado×1", "Limonada×1"]] and x["emitidos"] == 0, (k, r)   # antes: volvía a la cuenta
        assert x["luego"] == {"pago": None, "cp": None, "srv": [["Casado×2", "Limonada×2"]]}, (k, r)        # con respuesta clara, vuelve
    for k in ("sin_red", "caido", "error"):
        assert r[k]["aviso"] == sin, (k, r)
    assert r["ocupada"]["aviso"].startswith("Esta cuenta se está cobrando en otro equipo. Se libera en ") and r["ocupada"]["aviso"].endswith("toque Cancelar otra vez para devolverla a la cuenta (lo que el otro equipo cobre no vuelve)."), r
    assert r["revisando"] == {"durante": [True, True, True], "despues": [False, False, None, None]}, r


def test_sexta_contrato_revisando_y_sin_aparte():
    k = _js("pages/pos/caja.js")
    assert ":title=\"cobrando ? (revisando ? 'Revisando…' : 'Emitiendo…') : 'Cobrar '" in k        # el título del cobro mientras se pregunta
    assert "revisando: false," in k and "this.revisando = true;" in _metodo(k, "async cerrarParte(cp) {")
    assert "aparcarParte" not in k and "revisarAparte" not in k and "quedó aparte" not in k        # M3: sin la variante «aparte»
    assert "if (!(lineas || []).length) return null;" not in _metodo(k, "nuevaCuentaEspera(nombre, lineas, mesaId, extra) {")   # S1


# ================================================================================================================ séptima vuelta
O1 = """
const quedan = () => S.items.map(x => x.lineas.map(l => l.detalle + '×' + l.cantidad).sort());
const verA = vm => vm.lineas.map(l => l.detalle + '×' + l.cantidad).sort();
const SIN = 'No se pudo confirmar con el servidor si otro equipo cobró esta parte. Sigue abierta aquí: toque Cancelar otra vez en unos segundos para devolverla a la cuenta.';
const SIN_RED = 'Sin conexión: la parte volvió a la cuenta; revise el total al volver la red.';
const f0 = globalThis.fetch; let cortar = false;   // sin conexión: tampoco sube ni baja la lista de cuentas
globalThis.fetch = async (url, opt) => { if (cortar && String(url).startsWith('/api/registros/')) throw new TypeError('Failed to fetch'); return f0(url, opt); };
const corte = on => { red.enLinea = !on; C.caido = on; cortar = on; };
// O1: «Cobrar la parte 1» abierto (el guardado ya dejó en el servidor la otra mitad) y se cae la red. `entre`: entre los dos Cancelar sin red
// hubo uno con el servidor fallando (500): ya no son seguidos
async function o1(entre) {
  reiniciarCobro(); const [a] = await mesaAbierta(%(dos)s);
  await a.cobrarParte(2); await a.A.mock.guardarTodo(); await conPago(a);
  corte(true);
  await a.cerrarPago();
  const x = { esc1: { pago: !!a.pago, cp: !!a.cobroParcial, aviso: avisos(a).slice(-1)[0] } };
  if (entre) { corte(false); C.reclamoFalla = 1; await a.cerrarPago(); C.reclamoFalla = 0; corte(true); await a.cerrarPago(); x.entre = { pago: !!a.pago, cp: !!a.cobroParcial, aviso: avisos(a).slice(-1)[0] }; }
  await a.cerrarPago();
  x.esc2 = { pago: a.pago, cp: a.cobroParcial, cobrando: a.cobrando, pantalla: verA(a), aviso: avisos(a).slice(-1)[0], sinRed: avisos(a).filter(t => t === SIN_RED).length, srv: quedan(), emitidos: C.emitidos.length };
  // la caja queda libre: la ventana de cobro se abre y se cierra como siempre, sin red
  await a.abrirPago(); x.esc2.abre = !!a.pago; a.cerrarPago(); x.esc2.cierra = a.pago;
  corte(false); const n0 = S.cuerpos.length; await a.A.mock.guardarTodo(); await espera(30);
  x.luego = { srv: quedan(), vuelve: S.cuerpos.slice(n0).some(c => (c.upserts || []).some(u => u._fusion && u._fusion.vuelve && Object.keys(u._fusion.vuelve).length)) };
  a._alDia = 0; await a.sincronizar(); a.abrirMesa(M6); await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  x.fin = { emitidos: emitidos().map(e => e[1]), servidor: S.items.length };
  return x;
}
out.dos = await o1(false);
out.entre = await o1(true);
"""


def test_septima_o1_sin_red_el_segundo_cancelar_devuelve_la_parte_en_node(tmp_path):
    """O1 (alto, retroceso de la sexta vuelta): sin red, la ventana de cobro de una parte no se podía cerrar ni cobrar y la caja quedaba
    trabada durante el corte (al recargar, la parte se perdía). Ahora «sin red» no es «incierto» ni «ocupada»: el primer Cancelar deja el
    aviso y el segundo seguido devuelve la parte a la cuenta como en la 4.30, con su aviso; el guardado pendiente lleva `vuelve` y, al volver
    la red, el servidor tiene la cuenta completa (y se cobra una sola vez)."""
    r = _correr(tmp_path, O1 % {"dos": DOS})
    sin = "No se pudo confirmar con el servidor si otro equipo cobró esta parte. Sigue abierta aquí: toque Cancelar otra vez en unos segundos para devolverla a la cuenta."
    for k in ("dos", "entre"):
        x = r[k]
        assert x["esc1"] == {"pago": True, "cp": True, "aviso": sin}, (k, r)                                   # el primero: sigue abierta con el aviso
        e = x["esc2"]
        assert e["pago"] is None and e["cp"] is None and e["cobrando"] is False and e["pantalla"] == ["Casado×2", "Limonada×2"], (k, r)   # antes: seguía abierta
        assert e["aviso"] == "Sin conexión: la parte volvió a la cuenta; revise el total al volver la red." and e["sinRed"] == 1, (k, r)
        assert e["srv"] == [["Casado×1", "Limonada×1"]] and e["emitidos"] == 0 and e["abre"] is True and e["cierra"] is None, (k, r)
        assert x["luego"] == {"srv": [["Casado×2", "Limonada×2"]], "vuelve": True}, (k, r)                     # al volver la red, la cuenta completa
        assert x["fin"] == {"emitidos": [TOTAL_DOS], "servidor": 0}, (k, r)
    assert r["entre"]["entre"] == {"pago": True, "cp": True, "aviso": sin}, r                                  # un 500 entre medio: ya no eran seguidos


B1 = """
// B1: Casado lC y Casado lC2 (la misma comanda) y una Limonada. A cobra «solo esos» con lC entero y, casi a la vez, B toca «Cobrar la parte 1
// de 2»; el guardado de A llega primero (el resto de lC que dejó B no entra) y B cancela con su copia sin bajar
async function b1() {
  reiniciarCobro(); reiniciar();
  const a = await equipo(), b = await equipo();
  a.abrirMesa(M6); a.lineas.push(CASADO()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.lineas.push(CASADO(), LIMONADA()); await comanda(a);
  await b.sincronizar(); b.abrirMesa(M6); await a.sincronizar(); a.abrirMesa(M6);
  const x = { inicio: a.lineas.map(l => l.detalle + '×' + l.cantidad) };
  a._alDia = Date.now(); b._alDia = Date.now();
  await a.abrirDividir(); a.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } };
  await Promise.all([a.confirmarDividir(), b.cobrarParte(2)]); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo(); await conPago(a, b);
  await b.cerrarPago(); await b.A.mock.guardarTodo();
  x.vuelta = { srv: S.items.map(c => c.lineas.map(l => l.detalle + '×' + l.cantidad).sort()), cp: b.cobroParcial };
  await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  b._alDia = 0; await b.sincronizar(); b.abrirMesa(M6); await b.abrirPago(); if (b.pago) await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  x.fin = { emitidos: emitidos().map(e => e[1]), suma: suma(), servidor: S.items.length };
  return x;
}
out.b1 = await b1();
"""


def test_septima_b1_lo_que_vuelve_va_primero_a_lo_que_quedo_de_ella_en_node(tmp_path):
    """B1 (bajo): devolverParte sumaba cada línea al primer plato igual de la copia; con dos Casados iguales, la porción del segundo caía en el
    resto del primero, que el servidor no tenía (otro equipo lo cobró entero), y se perdía: medio Casado (₡1 977,50). Ahora va primero a lo que
    quedó de ella misma (`de`)."""
    r = _correr(tmp_path, B1)
    x = r["b1"]
    assert x["inicio"] == ["Casado×1", "Casado×1", "Limonada×1"], r
    assert x["vuelta"] == {"srv": [["Casado×1", "Limonada×1"]], "cp": None}, r              # antes: Casado×0.5 (la porción de lC2 se perdía)
    assert x["fin"] == {"emitidos": [3955, 5650], "suma": 3955 + 3955 + 1695, "servidor": 0}, r   # A cobra su Casado; queda el otro con la Limonada


def test_septima_contrato_textos_y_reloj():
    """B2 (bajo): el aviso «partida» ya no dice que el otro equipo «ya tiene esos platos en su parte» (pudo devolverlos); O1: el aviso de la
    parte que vuelve sin red; V1: el reloj de 30 s no toca las promociones del cobro de una parte."""
    k = _js("pages/pos/caja.js")
    assert k.count("'Otro equipo partió esta misma cuenta a la vez. Aquí no se cobró nada; revise la cuenta y cobre lo que queda.'") == 1
    assert "ya tiene esos platos en su parte" not in k and "ya tiene ese plato en su parte" not in k
    assert k.count("'Sin conexión: la parte volvió a la cuenta; revise el total al volver la red.'") == 1
    w = _tramo(k, "  watch: {", "  methods: {")
    assert "    promosActivas() { if (!this.cobroParcial) this.aplicarPromos(); }," in w
