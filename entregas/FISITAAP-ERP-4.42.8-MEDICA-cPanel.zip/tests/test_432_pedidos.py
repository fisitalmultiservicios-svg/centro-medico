# -*- coding: utf-8 -*-
"""4.32 · bloque B4, PARTE WEB (plan reingenieria_432 §3, §4.1 a §4.8; contrato_432 §3.7, §4.6, §5): los pedidos en línea que atiende el
programa de escritorio, vistos desde la página web.

- Columnas nuevas (Pedido.atiende, NegocioPublico.atiende_terminal, Documento.pedido_id y pedido_parcial) y su índice.
- _tomar_confirmacion decide quién atiende en el mismo UPDATE (a crédito: siempre la web) y su rama de retomar excluye atiende > 0;
  _confirmacion_pendiente también. anotar_fila en las rutas crudas.
- La regla de §4.1 (llamada en 90 s, estación viva, interruptores, terminal elegida) al aceptar en la web y al aprobarse un pago con Tilopay;
  con atiende > 0 la web no crea la cuenta (a_caja).
- Acciones del programa: «aceptar» (idempotente) y «cancelar» (sin reembolso a Tilopay).
- El enlace del cobro que sube del programa y su reintento; estado_efectivo por la copia de la cuenta; 409 de cobro y de cancelar en la web;
  el rescate del administrador; FE_TILOPAY_API; la elección «Los pedidos en línea los atiende».
El mecanismo de sincronización (app/sinc_datos.py, P1) se simula con un módulo de mentira cuando hace falta (ULTIMA_LLAMADA, anotar_fila).
Nada sale a la red: Tilopay y los correos se reemplazan. Solo correos @example.test."""
import json
import sys
import time
import types
import uuid
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import text
from sqlmodel import Session, select

import app as paquete_app
from app import db, modulos, pagos_online, pedidos, pedidos_programa, sinc
from app.db import Documento, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_429_pedido_web_comanda import _eid, _montar_negocio, _pedido


# ================================================================================================================ ayudas
@pytest.fixture(autouse=True)
def _sin_limite_por_ip():
    """El límite por IP de los pedidos públicos (60 cada 10 min) vive en memoria y lo comparten todas las pruebas del proceso: se limpia antes
    y después de cada una para que esta prueba no dependa del orden (ni deje sin pedidos a las que corren después)."""
    from app import auth
    auth._intentos_ip.clear()
    yield
    auth._intentos_ip.clear()


@pytest.fixture
def sd(monkeypatch):
    """Un app.sinc_datos de mentira (lo de P1 que esta parte usa): ULTIMA_LLAMADA y anotar_fila, que anota lo que recibe."""
    m = types.ModuleType("app.sinc_datos")
    m.ULTIMA_LLAMADA = {}
    m.anotados = []
    m.anotar_fila = lambda s, tipo, ref: m.anotados.append((tipo, str(ref)))
    monkeypatch.setitem(sys.modules, "app.sinc_datos", m)
    monkeypatch.setattr(paquete_app, "sinc_datos", m, raising=False)
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    monkeypatch.delenv("FE_PEDIDOS_PROGRAMA", raising=False)
    return m


def _negocio_con_programa(eid, terminal=3, nombre="Caja del local QA", contacto=None):
    """La tienda atiende con el programa de esa terminal, que está conectado (ficha en sinc_vinculacion)."""
    with Session(engine_empresa(eid)) as s:
        n = pedidos._negocio(s, eid); n.atiende_terminal = terminal; s.add(n); s.commit()
        ficha = {"terminal": terminal, "nombre": nombre, "prefijo": "qa" + uuid.uuid4().hex[:6], "token_id": 999}
        if contacto:
            ficha["ultimo_contacto"] = contacto
        modulos.reemplazar(s, eid, sinc.CLAVE_VINC, {"instalaciones": [ficha], "retiradas": []})


def _vivo(sd, eid, terminal=3, hace=5, estacion=True):
    sd.ULTIMA_LLAMADA[(eid, terminal)] = (time.time() - hace, estacion)


def _p(eid, pid):
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid); s.expunge(p)
        return p


def _set(eid, pid, **campos):
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid)
        for k, v in campos.items():
            setattr(p, k, v)
        s.add(p); s.commit()


def _cuentas(eid):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, "pos_espera", []) or []


def _doc(eid, pid=None, parcial=False, tipo="04"):
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=eid, tipo_documento=tipo, clave=(uuid.uuid4().hex * 2)[:50], consecutivo=uuid.uuid4().hex[:20],
                      fecha_emision=datetime.now(timezone.utc).isoformat(), estado="interno", origen_sinc="3", pedido_id=pid, pedido_parcial=parcial)
        s.add(d); s.commit(); s.refresh(d); s.expunge(d)
        return d


def _ctx_programa(terminal=3):
    """El contexto del token de la computadora, con la terminal de su ficha (como la pasa la ruta de P1)."""
    from app import auth
    from app.main import app
    base = app.dependency_overrides[auth.contexto]()
    c = auth.Contexto(base.usuario, base.empresa, "Administrador")
    c.terminal_sinc = terminal
    return c


def _tabla_sinc_dato(eid):
    with Session(engine_empresa(eid)) as s:
        s.execute(text("CREATE TABLE IF NOT EXISTS sinc_dato (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL, ref TEXT NOT NULL, v INTEGER NOT NULL DEFAULT 0, "
                       "campos TEXT NOT NULL DEFAULT '{}', origen INTEGER NOT NULL DEFAULT 0, dueno INTEGER, borrado BOOLEAN NOT NULL DEFAULT 0, foto TEXT, "
                       "huella TEXT NOT NULL DEFAULT '', datos TEXT, etiqueta TEXT, cambiado TEXT NOT NULL DEFAULT '', UNIQUE (tipo, ref))"))
        s.commit()


def _copia(eid, cid, pid, estado="en_cocina", borrado=False):
    with Session(engine_empresa(eid)) as s:
        s.execute(text("INSERT OR REPLACE INTO sinc_dato (tipo, ref, v, campos, origen, dueno, borrado, foto, huella, datos, etiqueta, cambiado) "
                       "VALUES ('cuenta', :r, 0, '{}', 3, 3, :b, NULL, '', :d, :e, '')"),
                  {"r": str(cid), "b": 1 if borrado else 0, "d": None if borrado else json.dumps({"id": cid, "pedido_id": pid, "estado": estado}), "e": f"pedido:{pid}"})
        s.commit()


# ================================================================================================================ columnas (§4.1)
def test_columnas_nuevas_y_su_indice():
    assert "atiende" in pedidos.Pedido.model_fields and pedidos.Pedido.model_fields["atiende"].default is None
    assert "atiende_terminal" in pedidos.NegocioPublico.model_fields
    assert "atiende_terminal" not in pedidos.NegocioIn.model_fields            # una pestaña vieja que guarda la tienda no lo pisa
    assert Documento.model_fields["pedido_id"].default is None and Documento.model_fields["pedido_parcial"].default is False
    assert "CREATE INDEX IF NOT EXISTS ix_documento_pedido_id ON documento(pedido_id)" in db.INDICES_EMPRESA


def test_columnas_se_agregan_a_una_base_que_ya_existe(api):  # noqa: F811
    eid = _eid()
    with Session(engine_empresa(eid)) as s:
        cols = {r[1] for r in s.execute(text("PRAGMA table_info(documento)")).all()}
        assert {"pedido_id", "pedido_parcial"} <= cols
        assert "atiende" in {r[1] for r in s.execute(text("PRAGMA table_info(pedido)")).all()}
        assert "atiende_terminal" in {r[1] for r in s.execute(text("PRAGMA table_info(negociopublico)")).all()}
        assert s.execute(text("SELECT 1 FROM sqlite_master WHERE type='index' AND name='ix_documento_pedido_id'")).first()


# ================================================================================================================ _tomar_confirmacion (§3)
def test_tomar_confirmacion_guarda_quien_atiende_y_a_credito_siempre_la_web(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p1 = _pedido(api, slug, a, b, tel="88880001"); p2 = _pedido(api, slug, a, b, tel="88880002")
    _set(eid, p2["id"], a_credito=True)
    with Session(engine_empresa(eid)) as s:
        assert pedidos._tomar_confirmacion(s, p1["id"], "2026-11-13T10:00:00-06:00", 3) is True
        assert pedidos._tomar_confirmacion(s, p2["id"], "2026-11-13T10:00:00-06:00", 3) is True
    assert _p(eid, p1["id"]).atiende == 3 and _p(eid, p1["id"]).estado == "confirmado"
    assert _p(eid, p2["id"]).atiende == 0                                     # CASE WHEN a_credito THEN 0
    assert ("pedido", str(p1["id"])) in sd.anotados and ("pedido", str(p2["id"])) in sd.anotados   # anotar_fila antes del commit


def test_rama_de_retomar_excluye_lo_que_atiende_un_programa(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    viejo = (pedidos.ahora_cr() - timedelta(minutes=5)).isoformat(timespec="seconds")
    _set(eid, p["id"], estado="confirmado", confirmado=viejo, atiende=3)      # aceptado por el programa: en la web no tiene cuenta
    assert pedidos._confirmacion_pendiente(_p(eid, p["id"])) is False
    with Session(engine_empresa(eid)) as s:
        assert pedidos._tomar_confirmacion(s, p["id"], pedidos.ahora_cr().isoformat(timespec="seconds"), 0) is False
    # la pantalla de la web (también una pestaña sin recargar) a los 61 s: el 400 de siempre, ninguna cuenta nueva
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado", "reclama": True})
    assert r.status_code == 400 and "solo se confirma un pedido nuevo" in r.json()["detail"] and "Otro equipo" not in r.json()["detail"]
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado", "aqui": True})
    assert r.status_code == 400
    assert not [c for c in _cuentas(eid) if c.get("pedido_id") == p["id"]]
    # el mismo pedido con atiende 0 (la web) sí se retoma, como en la 4.29
    _set(eid, p["id"], atiende=0)
    assert pedidos._confirmacion_pendiente(_p(eid, p["id"])) is True
    assert api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).status_code == 200


def test_soltar_confirmacion_anota_la_fila(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    marca = pedidos.ahora_cr().isoformat(timespec="seconds")
    with Session(engine_empresa(eid)) as s:
        assert pedidos._tomar_confirmacion(s, p["id"], marca)
        sd.anotados.clear()
        pedidos._soltar_confirmacion(s, p["id"], marca)
    assert _p(eid, p["id"]).estado == "nuevo" and sd.anotados == [("pedido", str(p["id"]))]


# ================================================================================================================ regla de §4.1
def test_aceptar_en_la_web_con_el_programa_vivo_no_crea_la_cuenta_aqui(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante", "numerar_comanda": "continuo"})
    _negocio_con_programa(eid); _vivo(sd, eid)
    p = _pedido(api, slug, a, b)
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado", "reclama": True})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["atiende"] == 3 and x["atiende_nombre"] == "Caja del local QA" and x["cuenta_espera_id"] is None and x["estado"] == "confirmado"
    assert not [c for c in _cuentas(eid) if c.get("pedido_id") == p["id"]]     # ni cuenta, ni copia, ni número de comanda en la web
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT COUNT(*) FROM comanda_pedido WHERE pedido_id = :p"), {"p": p["id"]}).scalar() == 0
        assert s.execute(text("SELECT COUNT(*) FROM comanda_numero")).scalar() == 0
    lista = api.get("/api/pedidos").json()
    assert next(y for y in lista if y["id"] == p["id"])["atiende"] == 3


@pytest.mark.parametrize("caso", ["llamada_vieja", "sin_estacion", "pedidos_apagado", "sinc_apagado", "sin_eleccion", "otra_terminal", "a_credito"])
def test_aceptar_en_la_web_sin_las_condiciones_lo_atiende_la_web(api, sd, monkeypatch, caso):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    _vivo(sd, eid, hace=100 if caso == "llamada_vieja" else 5, estacion=caso != "sin_estacion", terminal=4 if caso == "otra_terminal" else 3)
    if caso == "pedidos_apagado":
        monkeypatch.setenv("FE_PEDIDOS_PROGRAMA", "0")
    if caso == "sinc_apagado":
        monkeypatch.setenv("FE_SINC_DATOS", "0")
    if caso == "sin_eleccion":
        with Session(engine_empresa(eid)) as s:
            n = pedidos._negocio(s, eid); n.atiende_terminal = None; s.add(n); s.commit()
    p = _pedido(api, slug, a, b)
    if caso == "a_credito":
        _set(eid, p["id"], a_credito=True)
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 200, r.text
    assert r.json()["atiende"] == 0 and r.json()["cuenta_espera_id"]          # el flujo de la 4.31: su a_caja en la web


def test_pago_con_tilopay_sigue_la_misma_regla(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid); _vivo(sd, eid)
    p = _pedido(api, slug, a, b); q = _pedido(api, slug, a, b, tel="88887777")
    for x in (p, q):
        _set(eid, x["id"], estado="pendiente_pago", pago_estado="pendiente", pago_medio="tarjeta", pago_orden=f"GF{eid}-{x['id']}-QA", pago_monto=x["total"])
    from app.db import Empresa, engine
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); sc.expunge(e)
    with Session(engine_empresa(eid)) as s:
        pedidos._pago_aprobado(s, e, pedidos._negocio(s, eid), s.get(pedidos.Pedido, p["id"]), {"referencia": "R1"})
    x = _p(eid, p["id"])
    assert x.estado == "confirmado" and x.atiende == 3 and x.cuenta_espera_id is None and x.pago_estado == "aprobado"
    sd.ULTIMA_LLAMADA.clear()                                                # la computadora se apagó: lo atiende la web
    with Session(engine_empresa(eid)) as s:
        pedidos._pago_aprobado(s, e, pedidos._negocio(s, eid), s.get(pedidos.Pedido, q["id"]), {"referencia": "R2"})
    y = _p(eid, q["id"])
    assert y.estado == "confirmado" and not y.atiende and y.cuenta_espera_id


def test_atiende_para_en_el_programa_siempre_cero(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid); _vivo(sd, eid)
    p = _pedido(api, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        n = pedidos._negocio(s, eid); ped = s.get(pedidos.Pedido, p["id"])
        assert pedidos.atiende_para(eid, n, ped) == 3
        assert pedidos.atiende_para(eid, n, ped, terminal=3) == 3 and pedidos.atiende_para(eid, n, ped, terminal=4) == 0
        monkeypatch.setattr(sinc, "MODO_LOCAL", True)
        assert pedidos.atiende_para(eid, n, ped) == 0


# ================================================================================================================ acciones del programa
def test_aceptar_desde_el_programa_es_idempotente(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        r1 = pedidos_programa.aceptar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {"reclama": True}, "Caja 1 · Ana")
    with Session(engine_empresa(eid)) as s:
        r2 = pedidos_programa.aceptar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {}, "Caja 1 · Ana")   # respuesta perdida: otra vez
    assert r1["atiende"] == 3 and r1["estado"] == "confirmado" and r2["atiende"] == 3 and r2["id"] == p["id"]
    assert not [c for c in _cuentas(eid) if c.get("pedido_id") == p["id"]]
    from fastapi import HTTPException
    with Session(engine_empresa(eid)) as s, pytest.raises(HTTPException) as ex:      # otra computadora: el 400 de siempre
        pedidos_programa.aceptar_desde_programa(s, eid, _ctx_programa(4), str(p["id"]), {}, None)
    assert ex.value.status_code == 400


def test_aceptar_desde_un_programa_que_no_es_el_elegido(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid, terminal=3)
    p = _pedido(api, slug, a, b)
    from fastapi import HTTPException
    with Session(engine_empresa(eid)) as s, pytest.raises(HTTPException) as ex:
        pedidos_programa.aceptar_desde_programa(s, eid, _ctx_programa(4), str(p["id"]), {}, None)
    assert ex.value.status_code == 409 and ex.value.detail == pedidos.TEXTO_ACEPTAR_WEB
    assert _p(eid, p["id"]).estado == "nuevo"


def test_cancelar_desde_el_programa_sin_reembolso_a_tilopay(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3, pago_estado="aprobado", pago_medio="tarjeta", pago_orden="GF-QA-1", pago_monto=p["total"])
    llamadas = []
    monkeypatch.setattr(pagos_online, "reembolsar", lambda *a, **k: llamadas.append(a) or (True, "ok"))
    from fastapi import HTTPException
    with Session(engine_empresa(eid)) as s, pytest.raises(HTTPException) as ex:      # otra computadora no lo cancela
        pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(4), str(p["id"]), {"motivo": "Se acabó el pan"}, None)
    assert ex.value.status_code == 409 and "Caja del local QA" in ex.value.detail
    with Session(engine_empresa(eid)) as s:
        r = pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {"motivo": "Se acabó el pan"}, "Caja 1 · Ana")
    assert r["estado"] == "cancelado" and r["pago_estado"] == "reembolso_pendiente" and llamadas == []
    assert _p(eid, p["id"]).pago_detalle == pedidos.TEXTO_REEMBOLSO_PROGRAMA.format(nombre="Caja del local QA")
    with Session(engine_empresa(eid)) as s:                                   # repetido: 200 con el pedido
        assert pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {"motivo": "otra vez"}, None)["estado"] == "cancelado"
    q = _pedido(api, slug, a, b, tel="88886666")                               # uno que atiende la web: el programa no lo cancela
    assert api.put(f"/api/pedidos/{q['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    with Session(engine_empresa(eid)) as s, pytest.raises(HTTPException) as ex:
        pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(3), str(q["id"]), {"motivo": "Se acabó el pan"}, None)
    assert ex.value.status_code == 409 and ex.value.detail == pedidos.TEXTO_CANCELAR_WEB and _p(eid, q["id"]).estado == "confirmado"


def test_cancelar_en_la_web_sigue_pidiendo_el_reembolso(api, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], pago_estado="aprobado", pago_medio="tarjeta", pago_orden="GF-QA-2", pago_monto=p["total"])
    llamadas = []
    monkeypatch.setattr(pagos_online, "credenciales", lambda e, n: {"key": "k", "user": "u", "password": "x"})
    monkeypatch.setattr(pagos_online, "reembolsar", lambda *a, **k: llamadas.append(a) or (True, "Reembolsado"))
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "El cliente llamó"})
    assert r.status_code == 200 and r.json()["pago_estado"] == "reembolsado" and len(llamadas) == 1


# ================================================================================================================ 409 en la web (§3, §4.7)
def test_cancelar_en_la_web_un_pedido_que_atiende_un_programa_409(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Prueba de cancelación"})
    assert r.status_code == 409 and r.json()["detail"] == "Este pedido lo atiende «Caja del local QA»: cancélelo allá, en Ventas en línea › Pedidos."
    assert _p(eid, p["id"]).estado == "confirmado"


def test_cancelar_con_un_comprobante_del_pedido_409(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    assert api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    _doc(eid, p["id"], parcial=True)                                           # una parte ya cobrada (sin enlace en el pedido)
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Prueba de cancelación"})
    assert r.status_code == 409 and "ya tiene comprobante" in r.json()["detail"]
    assert _p(eid, p["id"]).estado == "confirmado"


def test_cobrar_en_la_web_un_pedido_que_atiende_un_programa_409(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    from app import main
    trabajo = []
    real_desc = main._revisar_descuento_pos
    monkeypatch.setattr(main, "_revisar_descuento_pos", lambda *x: trabajo.append(1) or real_desc(*x))
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"],
              "lineas": [{"cantidad": 1, "detalle": "Casado QA", "cabys": "2111100000000", "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 409 and r.json()["detail"] == "Este pedido lo atiende «Caja del local QA»: cóbrelo allá."
    assert trabajo == []                                                       # la primera revisión, antes de cualquier trabajo
    with Session(engine_empresa(eid)) as s:
        assert s.exec(select(Documento).where(Documento.pedido_id == p["id"])).first() is None


def test_cobrar_revisa_otra_vez_despues_del_flush(api, sd, monkeypatch):  # noqa: F811
    """El programa acepta entre la primera revisión y la escritura: la segunda revisión (ya con el documento escrito) da 409 y no queda nada."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    real = pedidos.texto_cobro_ajeno
    veces = []

    def a_medias(s, e, pid):
        veces.append(pid)
        if len(veces) == 1:
            return None                                                        # en la primera todavía era de la web
        return real(s, e, pid)
    monkeypatch.setattr(pedidos, "texto_cobro_ajeno", a_medias)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"],
              "lineas": [{"cantidad": 1, "detalle": "Casado QA", "cabys": "2111100000000", "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 409 and len(veces) == 2, r.text
    with Session(engine_empresa(eid)) as s:
        assert s.exec(select(Documento).where(Documento.pedido_id == p["id"])).first() is None


def test_el_comprobante_guarda_siempre_su_pedido(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    assert api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"], "pedido_parcial": True,
              "lineas": [{"cantidad": 1, "detalle": "Casado QA", "cabys": "2111100000000", "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 200, r.text
    with Session(engine_empresa(eid)) as s:
        d = s.get(Documento, r.json()["id"])
        assert d.pedido_id == p["id"] and d.pedido_parcial is True
        sin = api.post("/api/comprobantes", json={**cuerpo, "pedido_id": None, "pedido_parcial": False}).json()
        assert s.get(Documento, sin["id"]).pedido_id is None


def test_sin_revisar_existencias_solo_en_el_programa_con_el_canal_nuevo(api, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is False             # en la web, como siempre
        monkeypatch.setattr(sinc, "MODO_LOCAL", True)
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is False             # programa sin el canal nuevo (4.31)
        m = types.ModuleType("app.sinc_datos_programa"); m.protocolo = lambda e: 2
        monkeypatch.setitem(sys.modules, "app.sinc_datos_programa", m); monkeypatch.setattr(paquete_app, "sinc_datos_programa", m, raising=False)
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is False             # revisión n.º 30: «nuevo», sin dueño ni cuenta
    _set(eid, p["id"], estado="confirmado", atiende=3)
    with Session(engine_empresa(eid)) as s:
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is False             # aceptado y suyo, pero sin cuenta en la caja
        modulos.reemplazar(s, eid, "pos_espera", [{"id": 777001, "pedido_id": p["id"], "canal": "online", "lineas": []}]); s.commit()
    with Session(engine_empresa(eid)) as s:
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is True
        assert pedidos.sin_revisar_existencias(s, eid, None) is False and pedidos.sin_revisar_existencias(s, eid, 999999) is False
        m.protocolo = lambda e: 0
        assert pedidos.sin_revisar_existencias(s, eid, p["id"]) is False


def test_crear_comprobante_no_revisa_existencias_cuando_se_le_dice(api, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    item = api.post("/api/productos", json={"nombre": "Pan QA sin existencia", "cabys": "2111100000000", "precio": 500, "tarifa": 13, "codigo_tarifa": "08", "inventariable": True}).json()
    p = _pedido(api, slug, a, b)
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"],
              "lineas": [{"producto_id": item["id"], "cantidad": 2, "detalle": "Pan QA", "cabys": "2111100000000", "precio_unitario": 500, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 400 and "Existencias insuficientes" in r.json()["detail"]
    monkeypatch.setattr(pedidos, "sin_revisar_existencias", lambda s, e, pid: bool(pid))
    assert api.post("/api/comprobantes", json=cuerpo).status_code == 200
    assert api.post("/api/comprobantes", json={**cuerpo, "pedido_id": None}).status_code == 400


def test_cobrar_el_pedido_descuenta_aunque_quede_en_negativo(api, monkeypatch):  # noqa: F811
    """S8: saltar la revisión de main.py no basta; inventario.registrar_movimiento también negaba el descuento con 0 de existencia
    («Existencias insuficientes…»). crear_comprobante pasa permitir_negativo=sin_revisar_existencias(...) a descontar_por_venta."""
    from app import auth, inventario
    from app.db import Empresa, engine
    from app.main import app as aplicacion
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    ctx = aplicacion.dependency_overrides[auth.contexto]()
    with Session(engine) as s:                                       # sin facturación electrónica el inventario se mueve (3.69)
        e = s.get(Empresa, ctx.empresa.id); e.factura_electronica = False; s.add(e); s.commit(); s.refresh(e)
    ctx.empresa = e
    item = api.post("/api/productos", json={"nombre": "Plato Nuevo QA", "cabys": "2111100000000", "precio": 500, "tarifa": 13, "codigo_tarifa": "08", "inventariable": True}).json()
    p = _pedido(api, slug, a, b)
    vistos = []
    original = inventario.descontar_por_venta
    def espia(*args, **kw):
        vistos.append(kw.get("permitir_negativo", False))
        return original(*args, **kw)
    monkeypatch.setattr(inventario, "descontar_por_venta", espia)
    monkeypatch.setattr(pedidos, "sin_revisar_existencias", lambda s, e, pid: bool(pid))
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"],
              "lineas": [{"producto_id": item["id"], "cantidad": 2, "detalle": "Plato Nuevo QA", "cabys": "2111100000000", "precio_unitario": 500, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 200, r.text
    assert vistos == [True]
    assert api.post("/api/comprobantes", json={**cuerpo, "pedido_id": None}).status_code == 400


# ================================================================================================================ enlace del cobro del programa (§4.5)
def test_enlazar_desde_programa_parcial_final_repetido(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    d1 = _doc(eid, p["id"], parcial=True); d2 = _doc(eid, p["id"]); d3 = _doc(eid, p["id"])
    with Session(engine_empresa(eid)) as s:
        assert pedidos.enlazar_desde_programa(s, eid, p["id"], d1, True) is None; s.commit()
    x = _p(eid, p["id"]); assert x.documento_id == d1.id and x.estado == "confirmado"
    with Session(engine_empresa(eid)) as s:
        assert pedidos.enlazar_desde_programa(s, eid, p["id"], d2, False) == p["id"]; s.commit()
    x = _p(eid, p["id"]); assert x.documento_id == d1.id and x.estado == "entregado" and x.entregado
    with Session(engine_empresa(eid)) as s:                                   # reenvío: nada nuevo
        assert pedidos.enlazar_desde_programa(s, eid, p["id"], d3, False) is None
        assert not s.dirty


@pytest.mark.parametrize("caso", ["web", "cancelado", "nota", "programa", "otra_empresa"])
def test_enlazar_desde_programa_no_enlaza(api, sd, monkeypatch, caso):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="cancelado" if caso == "cancelado" else "confirmado", atiende=0 if caso == "web" else 3)
    d = _doc(eid, p["id"], tipo="03" if caso == "nota" else "04")
    if caso == "programa":
        monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    with Session(engine_empresa(eid)) as s:
        assert pedidos.enlazar_desde_programa(s, eid + 1000 if caso == "otra_empresa" else eid, p["id"], d, False) is None; s.commit()
    x = _p(eid, p["id"]); assert x.documento_id is None


def test_reintento_del_enlace_y_puntos_y_correo(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b); q = _pedido(api, slug, a, b, tel="88884444")
    _set(eid, p["id"], estado="confirmado", atiende=3); _set(eid, q["id"], estado="confirmado", atiende=4)
    _doc(eid, p["id"]); _doc(eid, q["id"])                                     # subieron, pero el enlace falló
    avisos = []; puntos = []
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda e, pid, ev: avisos.append((pid, ev)))
    from app import promociones
    monkeypatch.setattr(promociones, "acreditar", lambda s, e, quien, monto, ref, nombre="", usuario="": puntos.append(ref) or 0.0)
    with Session(engine_empresa(eid)) as s:
        assert pedidos.reintentar_enlaces(s, eid, terminal=3) == [p["id"]]
    assert _p(eid, p["id"]).estado == "entregado" and _p(eid, q["id"]).estado == "confirmado"
    assert avisos == [(p["id"], "entregado")] and puntos == [f"pedido:{p['id']}"]
    with Session(engine_empresa(eid)) as s:                                   # la vuelta siguiente no repite nada
        assert pedidos.reintentar_enlaces(s, eid, terminal=3) == []
        assert pedidos.reintentar_enlaces(s, eid, pedido_id=q["id"]) == [q["id"]]
    assert len(avisos) == 2


# ================================================================================================================ estado_efectivo por la copia (§4.6)
def test_estado_efectivo_lee_la_copia_de_la_cuenta(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    ps = [_pedido(api, slug, a, b, tel=f"8888000{i}") for i in range(5)]
    for x in ps:
        _set(eid, x["id"], estado="confirmado", atiende=3)
    ids = [x["id"] for x in ps]
    with Session(engine_empresa(eid)) as s:                                   # sin la tabla (empresa sin programa 4.32): confirmado
        objs = [s.get(pedidos.Pedido, i) for i in ids]
        assert set(pedidos.estado_efectivo(s, eid, objs).values()) == {"confirmado"}
    _tabla_sinc_dato(eid)
    _copia(eid, 30000001, ids[1], "en_cocina"); _copia(eid, 30000002, ids[2], "listo"); _copia(eid, 30000003, ids[3], borrado=True)
    _copia(eid, 30000004, ids[4], "listo"); _copia(eid, 30000005, ids[4], "en_cocina")      # dos partes: una sigue en cocina
    with Session(engine_empresa(eid)) as s:
        est = pedidos.estado_efectivo(s, eid, [s.get(pedidos.Pedido, i) for i in ids])
    assert [est[i] for i in ids] == ["confirmado", "en_preparacion", "listo", "entregado", "en_preparacion"]
    seg = api.get(f"/api/publico/{slug}/pedido/{ps[2]['token']}").json()       # el seguimiento del cliente
    assert seg["estado"] == "listo"


# ================================================================================================================ rescate del administrador (§3)
def test_rescate_del_administrador(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    hace20 = (datetime.now(timezone.utc) - timedelta(minutes=20)).isoformat(timespec="seconds")
    _negocio_con_programa(eid, contacto=hace20)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3, confirmado=pedidos.ahora_cr().isoformat(timespec="seconds"))
    r = api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={})
    assert r.status_code == 409 and r.json()["detail"]["codigo"] == "confirmar"
    assert r.json()["detail"]["mensaje"].startswith("La computadora «Caja del local QA» no se conecta desde hace 20 minutos.")
    sd.anotados.clear()
    r = api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={"confirmo": True, "reclama": True})
    assert r.status_code == 200, r.text
    assert r.json()["atiende"] == 0 and r.json()["cuenta_espera_id"]                # la cuenta y la comanda, ahora en la web
    assert sd.anotados.count(("pedido", str(p["id"]))) == 2                         # el cambio de dueño (rescate) y la aceptación aquí
    assert len([c for c in _cuentas(eid) if c.get("pedido_id") == p["id"]]) == 1


def test_rescate_no_antes_de_10_minutos_ni_sin_ser_administrador(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    hace2 = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat(timespec="seconds")
    _negocio_con_programa(eid, contacto=hace2)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    r = api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={"confirmo": True})
    assert r.status_code == 409 and "se conectó hace 2 minutos" in r.json()["detail"]
    _vivo(sd, eid, hace=1)                                                     # además llamó hace un segundo
    from app import auth
    from app.main import app
    base = app.dependency_overrides[auth.contexto]()
    cajero = auth.Contexto(base.usuario, base.empresa, "Cajero")
    app.dependency_overrides[auth.contexto] = lambda: cajero
    try:
        assert api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={"confirmo": True}).status_code == 403
    finally:
        app.dependency_overrides[auth.contexto] = lambda: base
    assert _p(eid, p["id"]).atiende == 3


def test_textos_de_tiempo():
    assert [pedidos._hace(x) for x in (30, 60, 119, 600, 3600, 7300, 3 * 86400)] == ["1 minuto", "1 minuto", "1 minuto", "10 minutos", "1 hora", "2 horas", "3 días"]


# ================================================================================================================ «Los pedidos en línea los atiende»
def test_elegir_quien_atiende_y_que_guardar_la_tienda_no_lo_pise(api, monkeypatch):  # noqa: F811
    monkeypatch.setenv("FE_SINC_DATOS", "1"); monkeypatch.delenv("FE_PEDIDOS_PROGRAMA", raising=False)
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    assert api.put("/api/pedidos/negocio/atiende", json={"terminal": 3}).status_code == 400   # no hay tal computadora
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, sinc.CLAVE_VINC, {"instalaciones": [{"terminal": 3, "nombre": "Caja del local QA"}]})
    r = api.put("/api/pedidos/negocio/atiende", json={"terminal": 3})
    assert r.status_code == 200 and r.json() == {"atiende_terminal": 3, "atiende_nombre": "Caja del local QA"}
    n = api.get("/api/pedidos/negocio").json()
    assert n["atiende_terminal"] == 3 and n["atiende_opciones"] == [{"terminal": 3, "nombre": "Caja del local QA"}]
    assert api.put("/api/pedidos/negocio", json={"slug": slug, "activo": True, "nombre": "Soda Comanda QA", "horarios": [], "redes": {}}).status_code == 200
    assert api.get("/api/pedidos/negocio").json()["atiende_terminal"] == 3     # una pestaña que guarda la tienda no lo pisa
    assert api.put("/api/pedidos/negocio/atiende", json={"terminal": None}).json()["atiende_terminal"] is None


def test_atiende_terminal_se_llena_una_vez_al_sembrar(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, sinc.CLAVE_VINC, {"instalaciones": [{"terminal": 3, "nombre": "Caja QA"}, {"terminal": 4, "nombre": "Otra QA"}]})
        assert pedidos.fijar_atiende_al_sembrar(s, eid, 3) is False; s.commit()          # dos computadoras: queda la web
        modulos.reemplazar(s, eid, sinc.CLAVE_VINC, {"instalaciones": [{"terminal": 3, "nombre": "Caja QA"}]}, version=modulos._registro(s, eid, sinc.CLAVE_VINC).version)
    d = _doc(eid); _set_doc_origen(eid, d.id, None)                            # una venta hecha en la web hace poco
    with Session(engine_empresa(eid)) as s:
        assert pedidos.fijar_atiende_al_sembrar(s, eid, 3) is False; s.commit()
        s.execute(text("UPDATE documento SET fecha_emision = '2020-01-01T10:00:00-06:00' WHERE id = :i"), {"i": d.id}); s.commit()
        assert pedidos.fijar_atiende_al_sembrar(s, eid, 4) is False                       # no es la instalación vigente
        assert pedidos.fijar_atiende_al_sembrar(s, eid, 3) is True; s.commit()
        assert pedidos._negocio(s, eid).atiende_terminal == 3
        n = pedidos._negocio(s, eid); n.atiende_terminal = None; s.add(n); s.commit()
    with Session(engine_empresa(eid)) as s:                                   # una sola vez: si alguien ya eligió, no lo cambia
        n = pedidos._negocio(s, eid); n.atiende_terminal = 7; s.add(n); s.commit()
        assert pedidos.fijar_atiende_al_sembrar(s, eid, 3) is False


def _set_doc_origen(eid, did, origen):
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE documento SET origen_sinc = :o, fecha_emision = :f WHERE id = :i"),
                  {"o": origen, "f": pedidos.ahora_cr().isoformat(timespec="seconds"), "i": did}); s.commit()


def test_pedidos_programa_para(api, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid, terminal=3)
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    with Session(engine_empresa(eid)) as s:
        assert pedidos.pedidos_programa_para(s, eid, 3) is True and pedidos.pedidos_programa_para(s, eid, 4) is False
        monkeypatch.setenv("FE_PEDIDOS_PROGRAMA", "0")
        assert pedidos.pedidos_programa_para(s, eid, 3) is False


# ================================================================================================================ a_caja y «ya tomado» (contrato D-2)
def test_a_caja_deja_cuenta_espera_id_en_su_mismo_commit(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        cid = pedidos.a_caja(s, eid, s.get(pedidos.Pedido, p["id"]), pedidos._negocio(s, eid))
    assert _p(eid, p["id"]).cuenta_espera_id == cid                           # sin que quien llama lo asigne
    assert any(c.get("id") == cid for c in _cuentas(eid))


# ================================================================================================================ Tilopay simulado (FE_TILOPAY_API)
def test_fe_tilopay_api(monkeypatch):
    monkeypatch.delenv("FE_TILOPAY_API", raising=False)
    assert pagos_online.api_desde_entorno() == "https://app.tilopay.com/api/v1/"
    monkeypatch.setenv("FE_ENTORNO", "qa")
    monkeypatch.setenv("FE_TILOPAY_API", "http://127.0.0.1:8047/api/v1")
    assert pagos_online.api_desde_entorno() == "http://127.0.0.1:8047/api/v1/"
    from app import suscripcion
    assert suscripcion.API == "https://app.tilopay.com/api/v1/"                # el cobro del plan nunca cambia


# ================================================================================================================ declaraciones (pedidos_programa.py)
def test_pedido_que_viaja():
    hoy = pedidos.ahora_cr().isoformat(timespec="seconds")
    viejo = (pedidos.ahora_cr() - timedelta(hours=49)).isoformat(timespec="seconds")
    v = pedidos_programa.pedido_que_viaja
    assert v({"canal": "online", "estado": "nuevo", "actualizado": viejo}) and v({"canal": "online", "estado": "confirmado", "actualizado": viejo})
    assert v({"canal": "online", "estado": "entregado", "actualizado": hoy}) and not v({"canal": "online", "estado": "entregado", "actualizado": viejo})
    assert not v({"canal": "online", "estado": "nuevo", "a_credito": True}) and not v({"canal": "online", "estado": "pendiente_pago", "actualizado": hoy})
    assert not v({"canal": "otro", "estado": "nuevo"}) and not v(None)
    assert pedidos_programa.cuenta_de_pedido({"pedido_id": 4}) and not pedidos_programa.cuenta_de_pedido({"mesa_id": 2})
    assert pedidos_programa.etiqueta_cuenta({"pedido_id": 45}) == "pedido:45"


def test_campos_calculados(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    d = _doc(eid)
    with Session(engine_empresa(eid)) as s:
        ped = s.get(pedidos.Pedido, p["id"])
        assert pedidos_programa.caja_del_negocio(s, eid, ped) is None
        n = pedidos._negocio(s, eid); n.terminal_id = 1; s.add(n); s.commit()
        assert pedidos_programa.caja_del_negocio(s, eid, ped) == 1
        assert 0 <= pedidos_programa.edad_en_la_web(s, eid, ped) < 600
        assert pedidos_programa.clave_del_enlace(s, eid, ped) is None
        ped.documento_id = d.id
        assert pedidos_programa.clave_del_enlace(s, eid, ped) == d.clave


def test_declaraciones_siguen_el_contrato(monkeypatch):
    m = types.ModuleType("app.sinc_datos")
    m.DATOS = {}

    class Dato:
        def __init__(self, tipo, **kw):
            self.tipo = tipo; self.__dict__.update(kw)
    m.Dato = Dato
    m.declarar = lambda d: m.DATOS.__setitem__(d.tipo, d) or d
    monkeypatch.setitem(sys.modules, "app.sinc_datos", m); monkeypatch.setattr(paquete_app, "sinc_datos", m, raising=False)
    assert pedidos_programa._declarar() is True
    c, p = m.DATOS["cuenta"], m.DATOS["pedido"]
    assert (c.registro, c.escribe, c.dueno_de, c.viaja, c.filtro) == ("pos_espera", "dueno", "rango", "sube", pedidos_programa.cuenta_de_pedido)
    assert (p.modelo, p.escribe, p.viaja, p.copia_local) == (pedidos.Pedido, "web", "baja", True)
    assert {"token", "clave_peticion", "pago_orden", "pago_auth", "pago_detalle", "sinpe_comprobante", "cuenta_espera_id", "documento_id"} == set(p.no_viajan)
    assert set(p.locales) == {"cuenta_espera_id", "documento_id"} and set(p.extra) == {"_caja", "edad_s", "documento_clave"}
    assert set(p.acciones) == {"aceptar", "cancelar"}


# ================================================================================================================ cruces pendientes (sinc.py, P2)
# Se saltan mientras el integrador no aplique C-5 y C-6 de cruces_pendientes.md; después tienen que pasar.
def test_cruce_c5_el_comprobante_viaja_con_su_pedido(api):  # noqa: F811
    import inspect
    if "pedido" not in inspect.getsource(sinc._doc_a_dict):
        pytest.skip("cruce C-5 pendiente (sinc._doc_a_dict, P2)")
    eid = _eid()
    d1 = _doc(eid, 77, parcial=True); d2 = _doc(eid)
    with Session(engine_empresa(eid)) as s:
        assert sinc._doc_a_dict(s, s.get(Documento, d1.id), con_xml=False)["pedido"] == {"id": 77, "parcial": True}
        assert "pedido" not in sinc._doc_a_dict(s, s.get(Documento, d2.id), con_xml=False)


def test_cruce_c6_la_web_guarda_el_pedido_del_comprobante_y_lo_enlaza(api, sd, monkeypatch):  # noqa: F811
    import inspect
    if "enlazar_desde_programa" not in inspect.getsource(sinc._guardar_documentos):
        pytest.skip("cruce C-6 pendiente (sinc._guardar_documentos, P2)")
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    avisos = []
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda e, pid, ev: avisos.append((pid, ev)))
    clave = "".join(str((i * 7) % 10) for i in range(50))
    doc = {"clave": clave, "tipo_documento": "04", "consecutivo": "00100001040000000777", "fecha_emision": pedidos.ahora_cr().isoformat(timespec="seconds"),
           "estado": "interno", "total": 4520, "moneda": "CRC", "pedido": {"id": p["id"], "parcial": False}, "lineas": []}
    with Session(engine_empresa(eid)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid, [doc], "Caja del local QA")
    assert recibidos == [clave] and not errores
    x = _p(eid, p["id"])
    assert x.estado == "entregado" and x.documento_id and avisos == [(p["id"], "entregado")]
    with Session(engine_empresa(eid)) as s:
        d = s.exec(select(Documento).where(Documento.clave == clave)).first()
        assert d.pedido_id == p["id"] and d.pedido_parcial is False and x.documento_id == d.id
        sinc._guardar_documentos(s, eid, [doc], "Caja del local QA")         # reenvío: nada nuevo
    assert avisos == [(p["id"], "entregado")]


# ================================================================================================================ PARTE PROGRAMA (días 5-8)
# El programa con el canal nuevo (protocolo 2) y una web de mentira (la de tests/test_432_programa.py) que contesta las acciones.
import httpx  # noqa: E402

from app import cobro_reclamo, comandas, promociones  # noqa: E402
from app import sinc_datos_programa as sdp  # noqa: E402
from app import sinc_diario as diario  # noqa: E402
from tests.test_432_programa import T as T_PROG, _Respuesta, _Web, _empresa as _empresa_prog  # noqa: E402


@pytest.fixture
def prog(monkeypatch):
    """Una computadora (terminal T_PROG) con el protocolo 2 y su web de mentira. Devuelve (eid, web)."""
    w = _Web()
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(sdp, "httpx", w)
    eid = _empresa_prog()
    yield eid, w
    modulos._rangos.pop(eid, None); sdp.olvidar(eid); sdp._reintentar.pop(eid, None)


def _contenido_pedido(eid, pid, estado="confirmado", atiende=T_PROG, numero=None, **campos):
    """Lo que la web manda de un pedido (sin lo que no viaja) más los campos calculados."""
    from app import sinc_datos
    d = sinc_datos.dato("pedido")
    lineas = [{"producto_id": None, "detalle": "Casado QA", "cantidad": 2, "precio_unitario": 2500, "tarifa": 13, "codigo_tarifa": "08", "total": 5650}]
    p = pedidos.Pedido(id=pid, empresa_id=eid, numero=numero or pid, token="no-viaja", nombre="Cliente QA", telefono="88880000",
                       lineas=json.dumps(lineas), subtotal=5000, impuestos=650, total=5650, estado=estado, atiende=atiende, **campos)
    c = sdp._sin(d, json.loads(json.dumps(p.model_dump(), default=str)))
    return {**c, "_caja": None, "edad_s": 5, "documento_clave": None}


_VERSION = [5000]


def _fila_pedido(eid, pid, **kw):
    _VERSION[0] += 1
    return {"tipo": "pedido", "ref": str(pid), "v": _VERSION[0], "dueno": None, "borrado": False, "origen": 0, "campos": {},
            "datos": _contenido_pedido(eid, pid, **kw)}


def _llega(eid, fila):
    """El goteo: aplicar_canonico, commit y al_aplicar (como _aplicar_goteo)."""
    with Session(engine_empresa(eid)) as s, diario.aplicando(0):
        ok = sdp.aplicar_canonico(s, eid, fila)
        s.commit()
    if ok:
        sdp._al_aplicar(eid, fila)
    return ok


def _cuentas_de(eid, pid):
    return [c for c in _cuentas(eid) if c.get("pedido_id") == pid]


def _ctx(eid):
    with Session(db.engine) as sc:
        e = sc.get(db.Empresa, eid); sc.expunge(e)
    return types.SimpleNamespace(empresa=e, usuario=types.SimpleNamespace(nombre="Ana QA", correo="ana@example.test"))


def _estado(eid, pid, estado, **kw):
    with Session(engine_empresa(eid)) as s:
        return pedidos._cambiar_estado(pid, pedidos.EstadoIn(estado=estado, **kw), _ctx(eid), s)


def _ops(eid, tipo):
    with Session(engine_empresa(eid)) as s:
        return [f[0] for f in s.connection().execute(text("SELECT op FROM sinc_cambio WHERE tipo = :t"), {"t": tipo}).all()]


def _con_cobro(eid, cid, cobros=True):
    with Session(engine_empresa(eid)) as s:
        comandas.reescribir_cuentas(s, eid, lambda c: c.get("id") == cid, lambda c: {**c, "cobros": [{"monto": 1000, "medio": "01"}] if cobros else []})


def test_la_copia_del_pedido_se_guarda_sin_token(prog):
    eid, _w = prog
    assert _llega(eid, _fila_pedido(eid, 901, estado="nuevo", atiende=0))
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, 901)
        assert p.numero == 901 and p.token == "" and p.estado == "nuevo"


def test_reconciliar_crea_la_cuenta_una_sola_vez_en_la_vida_del_pedido(prog):
    eid, _w = prog
    assert _llega(eid, _fila_pedido(eid, 902))
    ctas = _cuentas_de(eid, 902)
    assert len(ctas) == 1 and ctas[0]["id"] // modulos.RANGO == T_PROG                 # cuenta del rango de esta computadora
    assert _p(eid, 902).cuenta_espera_id == ctas[0]["id"]
    with Session(engine_empresa(eid)) as s:
        assert comandas._copia(s, eid, 902)["cuenta_id"] == ctas[0]["id"]           # la copia fija de la comanda, aquí
    assert "copia" in _ops(eid, "cuenta")                                          # la copia de la cuenta sube a la web
    assert _llega(eid, _fila_pedido(eid, 902))                                       # otra versión del mismo pedido
    assert len(_cuentas_de(eid, 902)) == 1
    with Session(engine_empresa(eid)) as s:                                        # se cobró: la cuenta sale de la caja
        modulos.aplicar_cambios(s, eid, "pos_espera", [], [ctas[0]["id"]], [])
    assert _llega(eid, _fila_pedido(eid, 902))
    assert _cuentas_de(eid, 902) == []                                             # «ya tomado»: nunca otra cuenta
    assert _ops(eid, "pedido") == []                                               # el pedido es de la web: nunca sube


def test_ya_tomado_por_comprobante_o_copia_de_la_comanda(prog):
    eid, _w = prog
    for pid, como in ((903, "doc"), (904, "copia")):
        _llega(eid, _fila_pedido(eid, pid, estado="nuevo", atiende=0))
        if como == "doc":
            _doc(eid, pid)
        else:
            with Session(engine_empresa(eid)) as s:
                s.execute(text("INSERT INTO comanda_pedido (empresa_id, pedido_id, pedido_numero, cuenta_id, terminal_id, nombre, nota, tipo, hora_entrega, numero, "
                               "origen, creado, listo_desde, lineas, sin_comanda, estado, motivo, actualizado) VALUES (:e, :p, :p, 1, 1, '', '', '', '', NULL, "
                               "'aceptar', '', '', '[]', '[]', 'impresa', '', '')"), {"e": eid, "p": pid}); s.commit()
        _llega(eid, _fila_pedido(eid, pid))
        assert _cuentas_de(eid, pid) == [], como


def test_no_es_suyo_o_sin_el_canal_nuevo_no_crea_nada(prog, monkeypatch):
    eid, _w = prog
    _llega(eid, _fila_pedido(eid, 905, atiende=0))                                  # lo atiende la web
    _llega(eid, _fila_pedido(eid, 906, atiende=T_PROG + 1))                         # otra computadora
    assert _cuentas_de(eid, 905) == [] and _cuentas_de(eid, 906) == []
    monkeypatch.setattr(sdp, "protocolo", lambda e: 0)
    with Session(engine_empresa(eid)) as s:
        assert pedidos_programa.reconciliar_pedido(s, eid, _fila_pedido(eid, 906, atiende=T_PROG)) is True
    assert _cuentas_de(eid, 906) == []


def test_listo_de_comanda_tardia():
    llegada = datetime(2026, 11, 20, 20, 0, tzinfo=pedidos.ahora_cr().tzinfo)
    f = comandas._fecha
    assert f(pedidos_programa.listo_de({"edad_s": 5}, "", llegada)) == llegada
    assert f(pedidos_programa.listo_de({"edad_s": 2 * 3600}, "", llegada)) == llegada              # llegó tarde: sale al llegar
    assert f(pedidos_programa.listo_de({"edad_s": 4 * 3600}, "", llegada)) == llegada - timedelta(hours=4)   # muy viejo: no sale sola
    assert f(pedidos_programa.listo_de({"edad_s": 60}, "22:00", llegada)) == llegada.replace(hour=21, minute=15)   # programado: su hora
    assert pedidos_programa.listo_de({}, "", llegada) is None and pedidos_programa.listo_de({"edad_s": "x"}, "", llegada) is None


def test_guardar_copia_con_listo(prog):
    eid, _w = prog
    listo = "2026-11-20T21:30:00-06:00"
    cuenta = {"lineas": [{"detalle": "Casado", "cantidad": 1, "enviado": "2026-11-20T20:00:00-06:00"}], "creado": "2026-11-20T20:00:00-06:00"}
    with Session(engine_empresa(eid)) as s:
        assert comandas.guardar_copia(s, eid, types.SimpleNamespace(id=907, numero=7), cuenta, 1, "aceptar", listo=listo)
        assert comandas.guardar_copia(s, eid, types.SimpleNamespace(id=908, numero=8), cuenta, 2, "aceptar")
        s.commit()
        assert comandas._copia(s, eid, 907)["listo_desde"] == listo
        assert comandas._copia(s, eid, 908)["listo_desde"] == "2026-11-20T20:00:00-06:00"


def test_la_comanda_tardia_sale_al_llegar(prog):
    eid, _w = prog
    fila = _fila_pedido(eid, 909); fila["datos"]["edad_s"] = 2 * 3600
    antes = pedidos.ahora_cr().replace(microsecond=0)
    _llega(eid, fila)
    with Session(engine_empresa(eid)) as s:
        assert comandas._fecha(comandas._copia(s, eid, 909)["listo_desde"]) >= antes   # no la hora del pedido (hace 2 h): ya venció


def test_aceptar_en_el_programa_pide_a_la_web_y_responde_con_la_copia_de_aqui(prog):
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 910, estado="nuevo", atiende=0))
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 910, "estado": "confirmado"}, "filas": [_fila_pedido(eid, 910)]})
    out = _estado(eid, 910, "confirmado", reclama=True)
    assert w.llamadas[-1] == (sdp.RUTA_ACCION, {"tipo": "pedido", "ref": "910", "accion": "aceptar", "datos": {"reclama": True}, "por": "Ana QA"})
    assert out["cuenta_espera_id"] and out["cuenta_espera_id"] == _cuentas_de(eid, 910)[0]["id"]
    assert out["mensaje"] == "Pedido #910 aceptado: ya está en la caja y su comanda sale sola en unos segundos."
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 910}, "filas": []})   # «Aceptar» repetido (la fila ya está): 200, nada nuevo
    _estado(eid, 910, "confirmado")
    assert len(_cuentas_de(eid, 910)) == 1


def test_aceptar_en_el_programa_sin_conexion_o_sin_respuesta_o_rechazado(prog):
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 911, estado="nuevo", atiende=0))
    for forzar, texto in ((httpx.ConnectError("x"), pedidos_programa.TEXTO_SIN_CONEXION_ACEPTAR),
                          (httpx.ReadTimeout("x"), pedidos_programa.TEXTO_CONFIRMANDO)):
        w.forzar = forzar
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, 911, "confirmado")
        assert ex.value.status_code == 409 and ex.value.detail == texto
    w.forzar = None
    w.accion = lambda c: _Respuesta(409, {"detail": pedidos.TEXTO_ACEPTAR_WEB})
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 911, "confirmado")
    assert ex.value.detail == pedidos.TEXTO_ACEPTAR_WEB
    for kw in ({"estado": "confirmado", "aqui": True}, {"estado": "entregado"}):
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, 911, **kw)
        assert ex.value.status_code == 409 and ex.value.detail == pedidos.TEXTO_SOLO_WEB
    assert _cuentas_de(eid, 911) == [] and _p(eid, 911).estado == "nuevo"


def test_cancelar_en_el_programa(prog):
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 920))
    cid = _cuentas_de(eid, 920)[0]["id"]
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 920, "cancelado", motivo="")
    assert ex.value.status_code == 400
    _con_cobro(eid, cid)
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 920, "cancelado", motivo="Se arrepintió")
    assert ex.value.status_code == 409 and ex.value.detail == pedidos_programa.TEXTO_COBROS_AQUI
    _con_cobro(eid, cid, cobros=False)
    with Session(engine_empresa(eid)) as s:                                       # alguien cobrando en la caja: no se cancela
        assert cobro_reclamo.reclamar(s, eid, cid, "pantalla-qa-1", "clave-qa-1", ["a"])["resultado"] == "ganada"
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 920, "cancelado", motivo="Se arrepintió")
    assert ex.value.detail == pedidos_programa.TEXTO_COBRANDO
    with Session(engine_empresa(eid)) as s:
        cobro_reclamo.soltar(s, eid, cid, "clave-qa-1", False, [])
        p = s.get(pedidos.Pedido, 920); p.pago_estado = "aprobado"; s.add(p); s.commit()
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 920}, "filas": [_fila_pedido(eid, 920, estado="cancelado", pago_estado="reembolso_pendiente")]})
    out = _estado(eid, 920, "cancelado", motivo="Se arrepintió")
    assert w.llamadas[-1][1]["accion"] == "cancelar" and w.llamadas[-1][1]["datos"] == {"motivo": "Se arrepintió"}
    assert out["estado"] == "cancelado" and out["mensaje"] == pedidos_programa.TEXTO_CANCELADO_PAGO
    assert _cuentas_de(eid, 920) == []
    with Session(engine_empresa(eid)) as s:
        assert comandas._copia(s, eid, 920)["estado"] == "cerrada"
        assert cobro_reclamo._fila(s, eid, cid)["estado"] == "libre"


def test_cancelar_con_un_comprobante_de_aqui_no_se_cancela(prog):
    eid, _w = prog
    _llega(eid, _fila_pedido(eid, 921))
    _doc(eid, 921, parcial=True)                                                   # una parte «aparte» ya cobrada y cerrada
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 921, "cancelado", motivo="No vino")
    assert ex.value.detail == pedidos_programa.TEXTO_COBROS_AQUI


def test_cancelar_sin_respuesta_deja_el_cobro_tomado_hasta_el_goteo(prog):
    eid, w = prog
    for pid, llega in ((922, "confirmado"), (923, "cancelado")):
        _llega(eid, _fila_pedido(eid, pid))
        cid = _cuentas_de(eid, pid)[0]["id"]
        w.forzar = httpx.ReadTimeout("x")
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, pid, "cancelado", motivo="Cerramos")
        assert ex.value.detail == pedidos_programa.TEXTO_CONFIRMANDO
        w.forzar = None
        with Session(engine_empresa(eid)) as s:                                   # más de un minuto después, la caja sigue sin poder cobrarla
            assert cobro_reclamo._fila(s, eid, cid)["vence"] > (pedidos.ahora_cr() + timedelta(hours=1)).isoformat(timespec="seconds")
            assert cobro_reclamo.reclamar(s, eid, cid, "pantalla-qa-2", "clave-qa-2", ["a"])["resultado"] == "ocupada"
        _llega(eid, _fila_pedido(eid, pid, estado=llega))
        if llega == "cancelado":
            assert _cuentas_de(eid, pid) == []
        else:                                                                      # la web no la canceló: se suelta y se cobra
            assert len(_cuentas_de(eid, pid)) == 1
            with Session(engine_empresa(eid)) as s:
                assert cobro_reclamo.reclamar(s, eid, cid, "pantalla-qa-2", "clave-qa-2", ["a"])["resultado"] == "ganada"


def test_cancelar_sin_conexion_suelta_el_cobro(prog):
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 924))
    cid = _cuentas_de(eid, 924)[0]["id"]
    w.forzar = httpx.ConnectError("x")
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 924, "cancelado", motivo="Cerramos")
    assert ex.value.detail == pedidos_programa.TEXTO_SIN_CONEXION_CANCELAR
    with Session(engine_empresa(eid)) as s:
        assert cobro_reclamo.reclamar(s, eid, cid, "pantalla-qa-3", "clave-qa-3", ["a"])["resultado"] == "ganada"


def test_rechazar_un_pedido_nuevo_desde_el_programa(prog):
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 925, estado="nuevo", atiende=0))
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 925}, "filas": [_fila_pedido(eid, 925, estado="cancelado", atiende=0)]})
    assert _estado(eid, 925, "cancelado", motivo="Sin existencias")["estado"] == "cancelado"
    _llega(eid, _fila_pedido(eid, 926, atiende=T_PROG + 1))
    with pytest.raises(pedidos.HTTPException) as ex:
        _estado(eid, 926, "cancelado", motivo="x")
    assert ex.value.status_code == 409


def test_rechazar_en_la_web_solo_el_programa_elegido(api, sd):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid, terminal=3)
    p = _pedido(api, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        with pytest.raises(pedidos.HTTPException):
            pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(4), str(p["id"]), {"motivo": "x"}, None)
        out = pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {"motivo": "Sin existencias"}, None)
        assert out["estado"] == "cancelado"
        assert pedidos_programa.cancelar_desde_programa(s, eid, _ctx_programa(3), str(p["id"]), {}, None)["estado"] == "cancelado"   # repetido: 200


def test_rescate_quita_la_cuenta_o_deja_cobrado_fuera(prog):
    eid, _w = prog
    for pid in (930, 931, 932):
        _llega(eid, _fila_pedido(eid, pid))
    c931, c932 = _cuentas_de(eid, 931)[0]["id"], _cuentas_de(eid, 932)[0]["id"]
    _con_cobro(eid, c931)
    with Session(engine_empresa(eid)) as s:
        assert cobro_reclamo.reclamar(s, eid, c932, "pantalla-qa-4", "clave-qa-4", ["a"])["resultado"] == "ganada"
    for pid in (930, 931, 932):
        _llega(eid, _fila_pedido(eid, pid, atiende=0))                            # el administrador lo atiende en la web
    assert _cuentas_de(eid, 930) == []                                             # sin cobros: se quita
    assert len(_cuentas_de(eid, 931)) == 1                                         # con cobros: queda y avisa
    with Session(engine_empresa(eid)) as s:
        assert [f[0] for f in s.execute(text("SELECT ref FROM sinc_pisado WHERE motivo = 'cobrado_fuera'")).all()] == ["931"]
    assert len(_cuentas_de(eid, 932)) == 1 and ("pedido", "932") in sdp._reintentar.get(eid, set())   # cobrando: la vuelta siguiente
    with Session(engine_empresa(eid)) as s:
        cobro_reclamo.soltar(s, eid, c932, "clave-qa-4", False, [])
    sdp._reintentar_ganchos(eid)
    assert _cuentas_de(eid, 932) == [] and ("pedido", "932") not in sdp._reintentar.get(eid, set())
    _llega(eid, _fila_pedido(eid, 931, atiende=0))
    with Session(engine_empresa(eid)) as s:                                        # el aviso, una sola vez
        assert s.execute(text("SELECT COUNT(*) FROM sinc_pisado WHERE motivo = 'cobrado_fuera'")).scalar() == 1
    _llega(eid, _fila_pedido(eid, 933))                                           # cobrado aquí sin internet (la cuenta ya salió) y rescatado
    c933 = _cuentas_de(eid, 933)[0]["id"]
    _doc(eid, 933)
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [], [c933], [])
    _llega(eid, _fila_pedido(eid, 933, atiende=0))
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT COUNT(*) FROM sinc_pisado WHERE motivo = 'cobrado_fuera' AND ref = '933'")).scalar() == 1


def test_entregado_en_la_web_y_prepago_que_cambia(prog):
    eid, _w = prog
    _llega(eid, _fila_pedido(eid, 940))
    _llega(eid, _fila_pedido(eid, 940, pago_estado="aprobado", pago_monto=5650, pago_medio="sinpe"))   # SINPE verificado tarde
    c = _cuentas_de(eid, 940)[0]
    assert c["prepago"] and c["prepago"]["online"] == 5650
    _llega(eid, _fila_pedido(eid, 940, estado="entregado", pago_estado="aprobado", pago_monto=5650, pago_medio="sinpe"))
    assert _cuentas_de(eid, 940)[0]["estado"] == "entregado"


def test_documento_clave_y_vincular_en_el_programa(prog, monkeypatch):
    eid, _w = prog
    monkeypatch.setattr(pedidos.planes, "modulos_de", lambda e: {"pos"})            # sin Entregas: el cobro que cierra entregaría el pedido
    _llega(eid, _fila_pedido(eid, 950))
    d = _doc(eid, 950)
    with Session(engine_empresa(eid)) as s:
        assert pedidos.vincular_documento(s, _ctx(eid).empresa, 950, s.get(Documento, d.id)) is None
        s.commit()
    p = _p(eid, 950)
    assert p.documento_id == d.id and p.estado == "confirmado"                    # el estado lo cambia la web
    _llega(eid, _fila_pedido(eid, 951, estado="entregado"))
    d2 = _doc(eid, 951)
    fila = _fila_pedido(eid, 951, estado="entregado"); fila["datos"]["documento_clave"] = d2.clave
    _llega(eid, fila)
    assert _p(eid, 951).documento_id == d2.id


def test_resumen_ultimo_entrado_id_y_purga(prog):
    eid, _w = prog
    _llega(eid, _fila_pedido(eid, 960)); _llega(eid, _fila_pedido(eid, 961, estado="nuevo", atiende=0))
    viejo = (pedidos.ahora_cr() - timedelta(days=4)).isoformat(timespec="seconds")
    _llega(eid, _fila_pedido(eid, 962, estado="entregado", atiende=0, creado=viejo))
    _llega(eid, _fila_pedido(eid, 963, creado=viejo))                               # suyo y confirmado: se conserva
    pedidos_programa._purga.pop(eid, None)
    with Session(engine_empresa(eid)) as s:
        r = pedidos.resumen(_ctx(eid), s)
        assert r["ultimo_entrado_id"] == 963 and r["nuevos"] == 1
        assert s.get(pedidos.Pedido, 962) is None and s.get(pedidos.Pedido, 963) is not None
    assert _ops(eid, "pedido") == []


def test_resumen_en_la_web_como_la_431(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    with Session(engine_empresa(eid)) as s:
        assert "ultimo_entrado_id" not in pedidos.resumen(_ctx(eid), s)


def test_puntos_del_pedido_los_da_la_web(prog, monkeypatch):
    eid, _w = prog
    ctx = _ctx(eid); ctx.puede = lambda p: True
    dados = []
    monkeypatch.setattr(promociones, "acreditar", lambda *a, **k: dados.append(a[3]) or 50)
    with Session(engine_empresa(eid)) as s:                                        # lo de la caja sigue igual
        assert promociones.fid_acreditar(promociones.PuntosIn(telefono="88880000", monto=5000, referencia="caja:1", nombre="QA"), ctx, s)["puntos"] == 50
    with Session(engine_empresa(eid)) as s:
        r = promociones.fid_acreditar(promociones.PuntosIn(telefono="88880000", monto=5000, referencia="pedido:970", nombre="QA"), ctx, s)
        assert r["puntos"] == 0 and dados == [5000]
        assert s.exec(select(promociones.MovimientoPuntos).where(promociones.MovimientoPuntos.referencia == "pedido:970")).first() is None


def test_lo_de_la_tienda_se_hace_en_la_web(prog):
    eid, _w = prog
    with pytest.raises(pedidos.HTTPException) as ex:
        pedidos.solo_en_la_web(eid)
    assert ex.value.status_code == 409 and ex.value.detail == "Esto se hace en la página web."


def test_estacion_viva(prog):
    eid, _w = prog
    sdp._estacion.pop(eid, None)
    assert not sdp.estacion_viva(eid)
    with Session(engine_empresa(eid)) as s:
        comandas.ruta_pendientes("901", _ctx(eid), s)                             # la de un pedido no es la pasada de la estación
    assert not sdp.estacion_viva(eid)
    with Session(engine_empresa(eid)) as s:
        comandas.ruta_pendientes(None, _ctx(eid), s)
    assert sdp.estacion_viva(eid)


def test_la_comanda_del_programa_se_reclama_una_vez(prog):
    eid, _w = prog
    _llega(eid, _fila_pedido(eid, 980))
    with Session(engine_empresa(eid)) as s:
        a = comandas.reclamar(s, eid, 980, [0], "1", "Cocina", "estacion-qa-0001", "Caja", "aceptar")
        b = comandas.reclamar(s, eid, 980, [0], "1", "Cocina", "estacion-qa-0002", "Caja 2", "aceptar")
    assert a["resultado"] == "ganada" and b["resultado"] != "ganada"


def test_sin_el_canal_nuevo_el_programa_es_la_431(api, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    assert not pedidos.en_programa_v2(eid)
    pedidos.solo_en_la_web(eid)
    with Session(engine_empresa(eid)) as s:
        out = pedidos._cambiar_estado(p["id"], pedidos.EstadoIn(estado="confirmado"), _ctx(eid), s)
    assert out["cuenta_espera_id"]                                                 # como la 4.31: la cuenta nace aquí sin preguntar a nadie



# ================================================================================================================ revisión 4.32, grupo P
def test_rev_p_fe_tilopay_api_se_ignora_fuera_de_qa_o_de_un_servidor_local(monkeypatch):
    """N.º 36: copiada por descuido al servidor, FE_TILOPAY_API no desvía las llaves de Tilopay de las empresas."""
    monkeypatch.setenv("FE_TILOPAY_API", "http://127.0.0.1:8047/api/v1")
    monkeypatch.delenv("FE_ENTORNO", raising=False)
    assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY                  # sin FE_ENTORNO=qa
    monkeypatch.setenv("FE_ENTORNO", "produccion")
    assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY
    monkeypatch.setenv("FE_ENTORNO", "qa")
    for otro in ("https://tilopay-falso.example.test/api/v1/", "http://10.0.0.5:8047/api/v1", "http://127.0.0.1.example.test/api/v1"):
        monkeypatch.setenv("FE_TILOPAY_API", otro)
        assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY, otro       # otro servidor, aunque sea QA
    monkeypatch.setenv("FE_TILOPAY_API", "http://localhost:8047/api/v1/")
    assert pagos_online.api_desde_entorno() == "http://localhost:8047/api/v1/"


def test_rev_p_ultima_llamada_lee_la_base_y_la_memoria(api, sd):  # noqa: F811
    """N.º 1, 15 y 20 (I-1): «llamó hace poco» se lee de sinc_datos.contacto_guardado (la base de la empresa, la ven todos los procesos) y
    de la memoria del proceso; gana lo más reciente. Si la base no contesta, queda la memoria."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    base = {}
    sd.contacto_guardado = lambda e, t: base.get((int(e), int(t)))
    assert pedidos.programa_vivo(eid, 3) is False
    base[(eid, 3)] = (time.time() - 5, True)                                   # lo guardó otro proceso
    assert pedidos.programa_vivo(eid, 3) is True
    base[(eid, 3)] = (time.time() - 5, False)                                  # la estación de comandas no está viva
    assert pedidos.programa_vivo(eid, 3) is False
    _vivo(sd, eid, hace=1, estacion=True)                                      # este proceso vio una llamada más nueva
    assert pedidos.programa_vivo(eid, 3) is True
    base[(eid, 3)] = (time.time() - 200, True); sd.ULTIMA_LLAMADA.clear()      # la base: hace más de 90 s
    assert pedidos.programa_vivo(eid, 3) is False

    def _falla(e, t):
        raise RuntimeError("base ocupada")
    sd.contacto_guardado = _falla; _vivo(sd, eid, hace=5)
    assert pedidos.programa_vivo(eid, 3) is True                               # la memoria de hoy


def test_rev_p_canal_apagado_cancelar_y_cobrar_en_la_web(api, sd, monkeypatch):  # noqa: F811
    """N.º 9 y 14: con FE_SINC_DATOS=0 el programa está en pausa: un pedido que ya atendía se cancela y se cobra en la web, como la 4.31.
    Con solo FE_PEDIDOS_PROGRAMA=0 los ya asignados se terminan donde están (409 como siempre)."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b); q = _pedido(api, slug, a, b, tel="88887777")
    for x in (p, q):
        _set(eid, x["id"], estado="confirmado", atiende=3)
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": q["id"],
              "lineas": [{"cantidad": 1, "detalle": "Casado QA", "cabys": "2111100000000", "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]}
    monkeypatch.setenv("FE_PEDIDOS_PROGRAMA", "0")
    assert api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Prueba de cancelación"}).status_code == 409
    assert api.post("/api/comprobantes", json=cuerpo).status_code == 409
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Prueba de cancelación"})
    assert r.status_code == 200, r.text
    assert _p(eid, p["id"]).estado == "cancelado"
    r = api.post("/api/comprobantes", json=cuerpo)
    assert r.status_code == 200, r.text
    with Session(engine_empresa(eid)) as s:
        assert s.get(Documento, r.json()["id"]).pedido_id == q["id"]


def test_rev_p_cobrar_en_la_web_lo_que_ya_cobro_el_programa_409(api, sd):  # noqa: F811
    """N.º 12: tras «Atenderlo aquí» llega el comprobante que el programa emitió sin conexión: la web no lo cobra otra vez. Los
    comprobantes de la propia web con el mismo pedido (cobro por partes) no lo frenan."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=0)                         # ya rescatado: lo atiende la web
    cuerpo = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "pedido_id": p["id"], "pedido_parcial": True,
              "lineas": [{"cantidad": 1, "detalle": "Casado QA", "cabys": "2111100000000", "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]}
    assert api.post("/api/comprobantes", json=cuerpo).status_code == 200      # una parte cobrada aquí
    assert api.post("/api/comprobantes", json=cuerpo).status_code == 200      # y otra: nada frena
    _doc(eid, p["id"])                                                         # llega el del programa (origen_sinc "3")
    r = api.post("/api/comprobantes", json={**cuerpo, "pedido_parcial": False})
    assert r.status_code == 409 and r.json()["detail"].startswith("Este pedido ya se cobró en la computadora «Caja del local QA»"), r.text
    with Session(engine_empresa(eid)) as s:
        assert len(s.exec(select(Documento).where(Documento.pedido_id == p["id"])).all()) == 3


def test_rev_p_enlazar_solo_la_computadora_que_atiende(api, sd):  # noqa: F811
    """N.º 34 (lado de pedidos.py): con la terminal de la ficha de quien sube, otra computadora no enlaza ni cierra el pedido."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    d = _doc(eid, p["id"])
    with Session(engine_empresa(eid)) as s:
        assert pedidos.enlazar_desde_programa(s, eid, p["id"], d, False, terminal=2) is None; s.commit()
    x = _p(eid, p["id"]); assert x.documento_id is None and x.estado == "confirmado"
    with Session(engine_empresa(eid)) as s:
        assert pedidos.enlazar_desde_programa(s, eid, p["id"], d, False, terminal=3) == p["id"]; s.commit()
    assert _p(eid, p["id"]).estado == "entregado"


@pytest.mark.parametrize("apagado", ["FE_SINC_DATOS", "FE_PEDIDOS_PROGRAMA"])
def test_rev_p_con_un_interruptor_apagado_no_se_elige_quien_atiende(api, monkeypatch, apagado):  # noqa: F811
    """Pedido de pantallas: con FE_SINC_DATOS o FE_PEDIDOS_PROGRAMA apagado la tienda se ve como la 4.31: sin opciones y la ruta da 409."""
    monkeypatch.setenv("FE_SINC_DATOS", "1"); monkeypatch.delenv("FE_PEDIDOS_PROGRAMA", raising=False)
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, sinc.CLAVE_VINC, {"instalaciones": [{"terminal": 3, "nombre": "Caja del local QA"}]})
    assert api.get("/api/pedidos/negocio").json()["atiende_opciones"] == [{"terminal": 3, "nombre": "Caja del local QA"}]
    monkeypatch.setenv(apagado, "0")
    assert api.get("/api/pedidos/negocio").json()["atiende_opciones"] == []
    r = api.put("/api/pedidos/negocio/atiende", json={"terminal": 3})
    assert r.status_code == 409 and r.json()["detail"] == "Esta opción no está disponible ahora."
    with Session(engine_empresa(eid)) as s:
        assert not pedidos._negocio(s, eid).atiende_terminal


# ================================================================================================================ revisión 4.32, grupo C
def _otro_cobra(eid, cid, n="9"):
    with Session(engine_empresa(eid)) as s:
        return cobro_reclamo.reclamar(s, eid, cid, f"pantalla-qa-c{n}", f"clave-qa-c{n}", ["a"])["resultado"]


def test_rev2_respaldo_viejo_recrea_la_cuenta_sin_reimprimir(prog, monkeypatch):
    """Revisión n.º 2: un respaldo anterior a la aceptación vuelve a crear la cuenta del pedido, pero no vuelve a sacar la comanda que ya
    salió (entera o algunos platos). En la web (sin MODO_LOCAL) la copia no se repone."""
    eid, _w = prog
    pids = (961, 962, 963)
    for pid in pids:
        assert _llega(eid, _fila_pedido(eid, pid))
    ahora = comandas._iso(pedidos.ahora_cr())
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE comanda_pedido SET estado = 'impresa' WHERE empresa_id = :e AND pedido_id IN (961, 963)"), {"e": eid})
        comandas._poner_impresas(s, eid, 962, [0], "qa", "", ahora)        # 962: el plato salió pero la copia sigue «pendiente»
        s.commit()
        ruta = engine_empresa(eid).url.database
    resueltas = comandas.leer_comandas(ruta)
    assert {f["pedido_id"] for f in resueltas["filas"]} >= set(pids)
    with Session(engine_empresa(eid)) as s:                               # la base del respaldo: sin los pedidos, sus cuentas ni sus copias
        modulos.aplicar_cambios(s, eid, "pos_espera", [], [c["id"] for pid in pids for c in _cuentas_de(eid, pid)], [])
        for tabla in ("comanda_pedido", "comanda_reclamo"):
            s.execute(text(f"DELETE FROM {tabla} WHERE empresa_id = :e AND pedido_id IN (961, 962, 963)"), {"e": eid})
        s.execute(text("DELETE FROM sinc_dato WHERE tipo = 'pedido' AND ref IN ('961', '962', '963')"))
        s.execute(text(f"DELETE FROM {pedidos.Pedido.__tablename__} WHERE id IN (961, 962, 963)"))
        s.commit()
    comandas.conservar_comandas(eid, {**resueltas, "filas": [f for f in resueltas["filas"] if f["pedido_id"] != 963]})
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)                        # en la web: no se repone
    comandas.conservar_comandas(eid, {"copias": [], "impresas": [], "filas": [f for f in resueltas["filas"] if f["pedido_id"] == 963]})
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    with Session(engine_empresa(eid)) as s:
        assert comandas._copia(s, eid, 963) is None
        assert [comandas._copia(s, eid, p)["estado"] for p in (961, 962)] == ["impresa", "impresa"]
    sdp.olvidar(eid)
    for pid in (961, 962):
        assert _llega(eid, _fila_pedido(eid, pid))
        assert len(_cuentas_de(eid, pid)) == 1                            # la cuenta vuelve a la caja
        with Session(engine_empresa(eid)) as s:
            assert comandas._copia(s, eid, pid)["estado"] == "impresa"    # la comanda no vuelve a salir
            assert pedidos_programa.ya_tomado(s, eid, s.get(pedidos.Pedido, pid))
        assert _llega(eid, _fila_pedido(eid, pid)) and len(_cuentas_de(eid, pid)) == 1     # una sola vez


def test_rev13_version_vieja_no_suelta_el_cobro_de_una_cancelacion_en_camino(prog):
    """Revisión n.º 13: mientras la cancelación viaja, una versión anterior del pedido («confirmado») que trae el goteo no suelta el cobro."""
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 964))
    cid = _cuentas_de(eid, 964)[0]["id"]
    visto = []

    def accion(c):
        assert pedidos_programa.cancelando(eid, 964)
        _llega(eid, _fila_pedido(eid, 964))                               # la versión vieja llega por el goteo
        visto.append(_otro_cobra(eid, cid, "13"))
        return _Respuesta(200, {"resultado": {"id": 964}, "filas": [_fila_pedido(eid, 964, estado="cancelado")]})
    w.accion = accion
    assert _estado(eid, 964, "cancelado", motivo="Se arrepintió")["estado"] == "cancelado"
    assert visto == ["ocupada"] and not pedidos_programa.cancelando(eid, 964)
    assert _cuentas_de(eid, 964) == []


def test_rev28_cancelacion_sin_respuesta_se_confirma_con_la_web(prog):
    """Revisión n.º 28/29: la cancelación sin respuesta no deja el cobro tomado 24 h: pasados 2 minutos se pregunta a la web; si el pedido sigue
    confirmado y suyo, se suelta; si la web lo canceló, se deja para el goteo. Sin cancelaciones pendientes no sale a la red."""
    eid, w = prog
    n0 = len(w.llamadas)
    assert pedidos_programa.confirmar_cancelaciones(eid, forzar=True) == 0 and len(w.llamadas) == n0
    cids = {}
    for pid in (965, 966):
        _llega(eid, _fila_pedido(eid, pid))
        cids[pid] = _cuentas_de(eid, pid)[0]["id"]
        w.forzar = httpx.ReadTimeout("x")
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, pid, "cancelado", motivo="Cerramos")
        assert ex.value.detail == pedidos_programa.TEXTO_CONFIRMANDO
        w.forzar = None
    n0 = len(w.llamadas)
    assert pedidos_programa.confirmar_cancelaciones(eid, forzar=True) == 0 and len(w.llamadas) == n0   # recién pedida: todavía no
    vence = (pedidos.ahora_cr() + timedelta(hours=pedidos_programa.HORAS_RECLAMO_CANCELAR) - timedelta(minutes=5)).isoformat(timespec="seconds")
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE cobro_reclamo SET vence = :v WHERE empresa_id = :e AND equipo = :q"), {"v": vence, "e": eid, "q": pedidos_programa.EQUIPO})
        s.commit()
    w.filas_resp[("pedido", "965")] = ("existe", 9001, _contenido_pedido(eid, 965))
    w.filas_resp[("pedido", "966")] = ("existe", 9002, _contenido_pedido(eid, 966, estado="cancelado"))
    assert pedidos_programa.confirmar_cancelaciones(eid, forzar=True) == 1
    assert w.llamadas[-1][0] == sdp.RUTA_FILAS and {x["ref"] for x in w.llamadas[-1][1]["refs"]} == {"965", "966"}
    assert _otro_cobra(eid, cids[965], "28") == "ganada"                  # la web no la canceló: se cobra
    assert _otro_cobra(eid, cids[966], "29") == "ocupada"                 # la web la canceló: la quita el goteo
    w.forzar = httpx.ConnectError("x")                                    # sin conexión: no lanza
    assert pedidos_programa.confirmar_cancelaciones(eid, forzar=True) == 0
    w.forzar = None


def test_rev14_en_pausa_cancelar_se_hace_en_la_pagina_web(prog):
    """Revisión n.º 7/9/14 (lado programa): con el programa en pausa, cancelar no dice «sin conexión» ni toma el cobro."""
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 967))
    cid = _cuentas_de(eid, 967)[0]["id"]
    sdp._guardar_estado(eid, pausa_desde=sdp._ahora())
    try:
        n0 = len(w.llamadas)
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, 967, "cancelado", motivo="Cerramos")
        assert ex.value.status_code == 409 and ex.value.detail == pedidos_programa.TEXTO_CANCELAR_EN_WEB
        assert len(w.llamadas) == n0 and _otro_cobra(eid, cid, "14") == "ganada"
        with Session(engine_empresa(eid)) as s:
            cobro_reclamo.soltar(s, eid, cid, "clave-qa-c14", False, [])
    finally:
        sdp._guardar_estado(eid, pausa_desde=None)

    def accion(c):                                                        # la web respondió «no existe»: el hilo ya la marcó en pausa
        sdp._guardar_estado(eid, pausa_desde=sdp._ahora())
        return _Respuesta(404, {"detail": "Not Found"})
    w.accion = accion
    try:
        with pytest.raises(pedidos.HTTPException) as ex:
            _estado(eid, 967, "cancelado", motivo="Cerramos")
        assert ex.value.detail == pedidos_programa.TEXTO_CANCELAR_EN_WEB
        assert _otro_cobra(eid, cid, "15") == "ganada"
    finally:
        sdp._guardar_estado(eid, pausa_desde=None)
