# -*- coding: utf-8 -*-
"""3.92: la ficha del ítem no debe decir que sus datos se guardan «localmente»: van por los registros del servidor."""
import pathlib

JS = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "js"


def test_sin_avisos_de_maqueta_en_la_ficha_del_item():
    t = (JS / "pages" / "inventario" / "item-form.js").read_text(encoding="utf-8")
    assert "sin backend" not in t and "Se guardan localmente" not in t
    assert "catálogo de revendedoras" in t
