"""4.32 (B7): la bandera `sinc_pantallas` de auth._info_empresa (franja y «Cambios que no quedaron»). A diferencia de `datos_v2`
(solo en el programa y falsa en pausa), esta sale en la página web y en el programa, también en pausa; con FE_SINC_DATOS apagado es falsa."""
import inspect

from app import auth, sinc_datos, sinc_datos_programa


def test_sinc_pantallas_va_fuera_del_bloque_del_programa():
    fuente = inspect.getsource(auth._info_empresa)
    bloque_programa = fuente[fuente.index("if aviso_local is not None:"):fuente.index('d["sinc_pantallas"]')]
    assert 'd["pedidos_programa"] = False' in bloque_programa            # va después de todo el bloque del programa…
    linea = next(x for x in fuente.splitlines() if 'd["sinc_pantallas"] = bool(' in x)
    assert linea.startswith("        d[")                                # …y a nivel de función (dentro de su try), no del «if aviso_local»
    assert fuente.rstrip().endswith("return d")


def _bandera(monkeypatch, *, encendido: bool, es_local: bool, protocolo: int) -> bool:
    """Evalúa solo las líneas de la bandera con lo mismo que usa _info_empresa."""
    monkeypatch.setattr(sinc_datos, "encendido", lambda: encendido)
    monkeypatch.setattr(sinc_datos_programa, "protocolo", lambda eid: protocolo)
    fuente = inspect.getsource(auth._info_empresa)
    ini = fuente.index("    try:                                                       # 4.32 (B7)")
    cuerpo = inspect.cleandoc(fuente[ini:fuente.rindex("    return d")])
    d = {"es_local": es_local}
    entorno = {"d": d, "e": type("E", (), {"id": 1})()}
    exec(compile(cuerpo.replace("from . import", "from app import"), "<bandera>", "exec"), entorno)
    return d["sinc_pantallas"]


def test_sinc_pantallas_en_la_web_sigue_al_interruptor(monkeypatch):
    assert _bandera(monkeypatch, encendido=True, es_local=False, protocolo=0) is True
    assert _bandera(monkeypatch, encendido=False, es_local=False, protocolo=0) is False


def test_sinc_pantallas_en_el_programa_pide_el_protocolo_nuevo_aunque_este_en_pausa(monkeypatch):
    monkeypatch.setattr(sinc_datos_programa, "en_pausa", lambda eid: True)
    assert _bandera(monkeypatch, encendido=True, es_local=True, protocolo=2) is True
    assert _bandera(monkeypatch, encendido=True, es_local=True, protocolo=1) is False
