# -*- coding: utf-8 -*-
"""4.25 (X2): correcciones de la revisión de las tandas 3 y 4 (ingreso del programa local con la cuenta de la web).

- Los dos pasos de ESTA computadora (los que el programa le exigía antes de la 4.25 a quien viene de la nube) se siguen pidiendo cuando
  el ingreso se valida con lo guardado y la web todavía no dijo nada de sus dos pasos.
- Lo que dijo la web de los dos pasos de Recursos humanos se guarda por empresa (en la membresía), no por persona.
- El cliente «testclient» solo exime de la revisión de Host y Origin dentro de las pruebas: con uvicorn ese nombre puede llegar por la
  red (X-Forwarded-For desde 127.0.0.1).
- Con dos empresas vinculadas en la misma computadora, la ficha «inservible» de una no pisa el hash real que manda la otra ni cierra
  las sesiones en cada ciclo.
- El paso de un hash real al inservible en la bajada (la primera con la política, al actualizar el programa) no cierra sesiones.

Nube y computadora corren en el mismo proceso y comparten la tabla de usuarios (ver tests/test_425_ingreso_programa.py)."""
import os
from datetime import datetime, timezone

import httpx
from fastapi.testclient import TestClient
from sqlmodel import Session

from app import auth, sinc
from app.db import engine
from app.main import app
from test_49_local_sinc import PW, _admin_empresa, _cfg, _modo_local_ingreso, _poner_cfg, _Respuesta, _vincular, c
from test_425_ingreso_programa import (FICHA, INGRESO, USUARIOS, _entrar, _ficha, _llamadas, _miembro, _pareja, _persona, _poner, _revocada,
                                       _sesion_de, _sesion_vieja, _sobre, _solo_estas, _ultima_auditoria, _usuario)

INSERVIBLE = sinc.HASH_INSERVIBLE


def _baja(eid: int, *fichas) -> None:
    """Una bajada de usuarios de la empresa `eid` con esas fichas (lo que haría el ciclo de 2 minutos)."""
    with Session(engine) as sc:
        sinc._bajar_usuarios(sc, eid, {"usuarios": list(fichas), "roles": []})


def _membresia(uid: int, eid: int, rol: str = "Cajero") -> None:
    with Session(engine) as sc:
        sc.add(auth.UsuarioEmpresa(usuario_id=uid, empresa_id=eid, rol=rol)); sc.commit()


# ------------------------------------------------------------------------------------------------- dos pasos de esta computadora
def test_los_dos_pasos_de_esta_computadora_se_piden_cuando_la_web_no_se_consulta(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-c1", "3101425601", "3101425602")
    secreto = auth.nuevo_secreto()
    # la dueña bajó de la nube antes de la 4.25 y activó aquí los dos pasos que el programa le exigía; la web aún no dijo nada de los suyos
    uid, correo = _persona(0, "duena.c1", rol="Administrador", local=eid_b, mfa_activo=True, mfa_secret=auth._cifrar_mfa(secreto))
    assert _usuario(uid).mfa_nube is None and not _usuario(uid).mfa_entrar_nube

    def con_lo_guardado(caso: str) -> str:
        """La contraseña sola no abre sesión: pide el código de aquí. Devuelve el detalle de la auditoría del ingreso."""
        _poner(uid, mfa_ultimo=None)
        r = _entrar(correo)
        assert r.status_code == 200, (caso, r.text)
        j = r.json()
        assert j.get("mfa_requerido") is True and "token" not in j and "usuario" not in j, (caso, j)
        datos = auth.abrir(j["token_mfa"])
        assert datos["tipo"] == "mfa" and datos["uid"] == uid and PW not in str(datos), caso
        bueno = auth.codigo_totp(secreto)
        malo = "000000" if bueno != "000000" else "111111"
        assert c.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": malo}).status_code == 401, caso
        r = c.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": bueno})
        assert r.status_code == 200, (caso, r.text)
        s = r.json()
        assert s["usuario"]["sin_nube"] is True and _sesion_de(s["token"]).sin_nube is True, caso      # sesión abierta con lo guardado
        return _ultima_auditoria(uid, "login").detalle

    # sin internet
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    assert con_lo_guardado("sin internet") == "Sin internet: validado con lo guardado en esta computadora"
    assert _entrar(correo, "Clave-Mala-c1-2026").status_code == 401                 # la contraseña mala, lo de siempre
    # una web anterior a la 4.25 (404 sin versión anotada)
    shim.por_ruta[INGRESO] = _Respuesta(404, {"detail": "Not Found"})
    _poner_cfg(eid_b, version_nube=None)
    assert "web anterior" in con_lo_guardado("web anterior")
    # bloqueada aquí: ni siquiera se le pide el código
    _poner(uid, bloqueado=True)
    r = _entrar(correo)
    assert r.status_code == 403 and "bloqueada" in r.json()["detail"] and "token_mfa" not in r.json(), r.text
    _poner(uid, bloqueado=False)
    # conectada a otra dirección, o FE_NUBE_URL dudosa: la web nunca se consulta (y sus dos pasos nunca llegan)
    for url in ("https://fisitaap.com", ""):
        monkeypatch.setattr(sinc, "URL_NUBE", url)
        shim.llamadas.clear()
        assert "otra dirección" in con_lo_guardado("otra dirección " + url)
        assert shim.llamadas == []
    # sin vinculación
    _solo_estas(monkeypatch)
    assert "sin vinculación" in con_lo_guardado("sin vinculación")
    # en cuanto la web dice que usa los suyos (huella), mandan los de la web: sin internet, solo desde un navegador con la marca
    _poner(uid, mfa_nube="huella-c1", mfa_entrar_nube=True)
    r = _entrar(correo)
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_INTERNET_MFA and "token_mfa" not in r.json()


# ------------------------------------------------------------------------------------------------- Recursos humanos por empresa
def test_recursos_humanos_cubierto_segun_lo_que_dijo_la_web_en_cada_empresa(monkeypatch):
    _modo_local_ingreso(monkeypatch)                # ganchos instalados: para quien viene de la nube vale lo que dijo la web
    with Session(engine) as sc:
        ea = auth.crear_empresa(sc, "Corr34 QA A", "corr34a@example.test", "3101425611")
        eb = auth.crear_empresa(sc, "Corr34 QA B", "corr34b@example.test", "3101425612")
        ec = auth.crear_empresa(sc, "Corr34 QA C", "corr34c@example.test", "3101425613")
        sc.commit()
        eid_a, eid_b, eid_c = ea.id, eb.id, ec.id
    # 4b (D-N): lo que dijo la web vale una vez que la web aceptó un ingreso suyo en esta computadora (nube_validado)
    uid, _ = _persona(0, "contadora.c2", rol="Avanzado", nube_validado=datetime.now(timezone.utc))
    for eid in (eid_a, eid_b, eid_c):
        _membresia(uid, eid, "Avanzado")

    def rrhh(eid: int) -> bool:
        """El permiso de Recursos humanos queda en la sesión de esa empresa."""
        with Session(engine) as sc:
            u = sc.get(auth.Usuario, uid)
            permisos, quitado = auth.quitar_rrhh_sin_mfa({"ver", "rrhh"}, u, "Avanzado", sc, eid)
            assert quitado == ("rrhh" not in permisos) and quitado == (not auth._rrhh_cubierto(u, "Avanzado", sc, eid))
            return "rrhh" in permisos

    # con su renuncia vigente: la empresa A la da por cubierta; la B (con la política «sin excepción») no. El orden de las bajadas no importa
    si, no = _ficha(uid, rol="Avanzado", mfa_rrhh=True), _ficha(uid, rol="Avanzado", mfa_rrhh=False)
    for orden in (((eid_a, si), (eid_b, no)), ((eid_b, no), (eid_a, si)), ((eid_a, si), (eid_b, no))):
        for eid, ficha in orden:
            _baja(eid, ficha)
        assert rrhh(eid_a) is True and rrhh(eid_b) is False, orden
    assert rrhh(eid_c) is False                     # una empresa de la que la web no dijo nada: no queda cubierta
    # una web anterior a la 4.25 (la ficha no trae nada de los dos pasos) no cambia lo que ya se sabía
    vieja = {k: v for k, v in si.items() if k not in ("mfa", "mfa_entrar", "mfa_rrhh", "temporal")}
    _baja(eid_a, vieja); _baja(eid_b, vieja)
    assert rrhh(eid_a) is True and rrhh(eid_b) is False
    # y cada empresa puede cambiar de parecer por su cuenta
    _baja(eid_a, no); _baja(eid_b, si)
    assert rrhh(eid_a) is False and rrhh(eid_b) is True
    # en la web (sin los ganchos) no cambia nada: la regla de siempre, sin mirar lo que dijo «la nube»
    monkeypatch.setattr(auth, "ingreso_nube", None)
    assert rrhh(eid_a) is False and rrhh(eid_b) is False


# ------------------------------------------------------------------------------------------------- Host y Origin
def test_el_cliente_testclient_solo_exime_dentro_de_las_pruebas(monkeypatch):
    """El programa arranca uvicorn con sus valores por omisión: en las conexiones que llegan desde 127.0.0.1 cambia el cliente por lo que
    diga X-Forwarded-For, aunque no sea una dirección. Una página ajena cuyo nombre apunte a 127.0.0.1 puede mandar «testclient»."""
    from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware
    assert os.environ.get(sinc.VAR_PRUEBAS) == "1"                          # la pone tests/conftest.py (y nadie más)
    monkeypatch.setattr(sinc, "_direcciones", lambda: ["http://192.168.1.10:8020"])
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    programa = TestClient(ProxyHeadersMiddleware(app, trusted_hosts="127.0.0.1,::1"), client=("127.0.0.1", 50123))
    disfraz = {"X-Forwarded-For": "testclient"}
    cuerpo = {"correo": "x@example.test", "password": "y"}
    visto = {}

    async def sonda(scope, receive, send):                                  # lo que recibe la aplicación detrás de uvicorn
        visto["cliente"] = scope.get("client")
        await send({"type": "http.response.start", "status": 204, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    TestClient(ProxyHeadersMiddleware(sonda, trusted_hosts="127.0.0.1,::1"), client=("127.0.0.1", 50123)).get("/", headers=disfraz)
    assert visto["cliente"][0] == "testclient"                              # el nombre del cliente sí llega por la red
    monkeypatch.delenv(sinc.VAR_PRUEBAS)                                    # como en el programa de verdad: la variable no existe
    r = programa.post("/api/auth/login", headers={**disfraz, "Host": "pagina-ajena.example:8020"}, json=cuerpo)
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST, r.text
    r = programa.post("/api/auth/pin/entrar", headers={**disfraz, "Host": "pagina-ajena.example:8020"}, json={"correo": "x@example.test", "pin": "1234"})
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST, r.text
    r = programa.post("/api/auth/login", headers={**disfraz, "Host": "127.0.0.1:8020", "Origin": "http://pagina-ajena.example:8020"}, json=cuerpo)
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_ORIGEN, r.text
    assert programa.get("/api/auth/estado", headers={**disfraz, "Host": "127.0.0.1:8020"}).status_code == 200    # el programa abierto como se debe
    falso = TestClient(app, client=("testclient", 0))                       # el cliente tal como lo deja uvicorn
    assert falso.get("/api/auth/estado", headers={"Host": "pagina-ajena.example"}).status_code == 403
    assert c.get("/api/auth/estado").status_code == 403                     # ni el cliente de las pruebas pasa sin la variable (Host «testserver»)
    monkeypatch.setenv(sinc.VAR_PRUEBAS, "1")                               # dentro de las pruebas, como antes
    assert c.get("/api/auth/estado").status_code == 200
    assert falso.get("/api/auth/estado", headers={"Host": "pagina-ajena.example"}).status_code == 200
    lan = TestClient(app, client=("192.168.1.50", 50000))                   # y una conexión con su dirección se revisa siempre
    assert lan.get("/api/auth/estado", headers={"Host": "pagina-ajena.example"}).status_code == 403


# ------------------------------------------------------------------------------------------------- dos empresas vinculadas
def test_dos_empresas_vinculadas_no_pisan_el_hash_ni_cierran_la_sesion(monkeypatch):
    eid_a1, ta1 = _admin_empresa("-c4n1", "3101425621")
    eid_b1, tb1 = _admin_empresa("-c4l1", "3101425622")
    eid_a2, ta2 = _admin_empresa("-c4n2", "3101425623")
    eid_b2, tb2 = _admin_empresa("-c4l2", "3101425624")
    shim = _modo_local_ingreso(monkeypatch)
    _vincular(monkeypatch, ta1, tb1, "Soda")
    _vincular(monkeypatch, ta2, tb2, "Hotel")
    _solo_estas(monkeypatch, eid_b1, eid_b2)
    shim.llamadas.clear()
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a1, "contadora.c4", pin_hash=pin)            # en la web es de las dos empresas; aquí también
    for eid in (eid_a2, eid_b1, eid_b2):
        _membresia(uid, eid)
    # entra con internet: la reconoce la primera (la Soda), y solo esa instalación queda anotada en la web
    r = _entrar(correo)
    assert r.status_code == 200 and _llamadas(shim, INGRESO) == 1, r.text
    token, real = r.json()["token"], _usuario(uid).password_hash
    assert real != INSERVIBLE
    # el ciclo de 2 minutos de cada empresa, contra la web de verdad y en los dos órdenes: la Soda manda el hash real; el Hotel, por cuya
    # instalación nunca entró en línea, el inservible. Lo guardado no cambia y la sesión sigue abierta
    for eid in (eid_b1, eid_b2, eid_b2, eid_b1, eid_b2):
        antes = _llamadas(shim, USUARIOS)
        est = sinc.sincronizar(eid)
        assert not est.get("ultimo_error") and _llamadas(shim, USUARIOS) == antes + 1 and _cfg(eid).get("usuarios_bajada"), (eid, est)
        u = _usuario(uid)
        assert u.password_hash == real and u.pin_hash == pin and not _sesion_de(token).revocada, eid
    assert _miembro(uid, eid_b1) and _miembro(uid, eid_b2)
    # sin internet entra con lo guardado, sea cual sea la empresa que bajó de última
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    r = _entrar(correo)
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True, r.text
    # el PIN de caja pide la ficha de las dos (la del Hotel trae el PIN inservible) y sigue sirviendo
    shim.por_ruta[FICHA] = [_Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, password_hash=real, pin_hash=pin))),
                            _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE)))]
    with monkeypatch.context() as m:
        m.setenv("FE_MODO_LOCAL", "1")
        r = c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"})
    assert r.status_code == 200 and _llamadas(shim, FICHA) == 2 and _usuario(uid).pin_hash == pin, r.text
    # la contraseña cambió en la web: la Soda manda el hash nuevo (se guarda y cierra sus sesiones); el Hotel sigue sin pisarlo
    _sesion_vieja(uid, "sid-c4")
    nuevo = auth.hash_password(PW)
    _baja(eid_b1, _ficha(uid, password_hash=nuevo, pin_hash=pin))
    assert _usuario(uid).password_hash == nuevo and _revocada("sid-c4")
    _sesion_vieja(uid, "sid-c4b")
    _baja(eid_b2, _ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE))
    assert _usuario(uid).password_hash == nuevo and _usuario(uid).pin_hash == pin and not _revocada("sid-c4b")
    # la Soda deja de estar vinculada aquí: ya nadie refresca ese hash, así que el inservible del Hotel vale
    uid2, _ = _persona(eid_a1, "mesera.c4", pin_hash=pin)
    for eid in (eid_a2, eid_b1, eid_b2):
        _membresia(uid2, eid)
    real2 = _usuario(uid2).password_hash
    _baja(eid_b1, _ficha(uid, password_hash=nuevo, pin_hash=pin), _ficha(uid2, password_hash=real2, pin_hash=pin))
    _baja(eid_b2, _ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE), _ficha(uid2, password_hash=INSERVIBLE, pin_hash=INSERVIBLE))
    assert _usuario(uid2).password_hash == real2 and _usuario(uid2).pin_hash == pin
    with monkeypatch.context() as m:
        _solo_estas(m, eid_b2)
        _baja(eid_b2, _ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE), _ficha(uid2, password_hash=INSERVIBLE, pin_hash=INSERVIBLE))
    assert _usuario(uid2).password_hash == INSERVIBLE and _usuario(uid2).pin_hash == INSERVIBLE
    assert _usuario(uid).password_hash == INSERVIBLE                        # lo mismo para la contadora
    # la persona sale de la Soda en la web: se quita esa membresía y el inservible del Hotel pasa a valer
    uid3, _ = _persona(eid_a1, "bodeguero.c4")
    for eid in (eid_a2, eid_b1, eid_b2):
        _membresia(uid3, eid)
    real3 = _usuario(uid3).password_hash
    _baja(eid_b1, _ficha(uid3, password_hash=real3))
    _baja(eid_b2, _ficha(uid3, password_hash=INSERVIBLE))
    assert _usuario(uid3).password_hash == real3
    _baja(eid_b1)
    assert not _miembro(uid3, eid_b1) and _miembro(uid3, eid_b2)
    _baja(eid_b2, _ficha(uid3, password_hash=INSERVIBLE))
    assert _usuario(uid3).password_hash == INSERVIBLE
    # ninguna de las dos manda el hash real (nadie entró en línea aquí): no se conserva el de antes de actualizar (D-E, D-I)
    uid4, correo4 = _persona(eid_a1, "nuevo.c4")
    for eid in (eid_a2, eid_b1, eid_b2):
        _membresia(uid4, eid)
    _baja(eid_b1, _ficha(uid4, password_hash=INSERVIBLE))
    assert _usuario(uid4).password_hash == INSERVIBLE
    _baja(eid_b2, _ficha(uid4, password_hash=INSERVIBLE))
    assert _usuario(uid4).password_hash == INSERVIBLE and _entrar(correo4).status_code == 403      # 9b (D-R): con el motivo, sin fallo      # sin internet no entra


# ------------------------------------------------------------------------------------------------- al actualizar el programa
def test_el_paso_al_hash_inservible_no_cierra_las_sesiones_abiertas(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-c9", "3101425631", "3101425632")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "mesero.c9", local=eid_b, pin_hash=pin)   # como antes de actualizar: con su hash real y una sesión abierta
    _sesion_vieja(uid, "sid-c9")
    # primera bajada con la política de la 4.25: todavía no entró en línea por esta instalación. Nadie le cambió la contraseña
    _baja(eid_b, _ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE))
    u = _usuario(uid)
    assert u.password_hash == INSERVIBLE and u.pin_hash == INSERVIBLE and _miembro(uid, eid_b)
    assert not _revocada("sid-c9")                                          # la sesión abierta sigue (con su tope de 12 horas y 60 minutos sin uso)
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    assert _entrar(correo).status_code == 403                               # pero lo guardado ya no sirve: el siguiente ingreso pide internet
    # lo demás sigue cerrando: otra contraseña (otro hash real), el bloqueo y el cambio de rol
    uid2, _ = _persona(eid_a, "cajera.c9", local=eid_b)
    uid3, _ = _persona(eid_a, "bloqueada.c9", local=eid_b)
    uid4, _ = _persona(eid_a, "ascendida.c9", local=eid_b)
    for n, x in enumerate((uid2, uid3, uid4), 2):
        _sesion_vieja(x, f"sid-c9-{n}")
    inservible = _ficha(uid, password_hash=INSERVIBLE, pin_hash=INSERVIBLE)
    _baja(eid_b, inservible, _ficha(uid2), _ficha(uid3), _ficha(uid4))
    assert not any(_revocada(f"sid-c9-{n}") for n in (2, 3, 4)) and not _revocada("sid-c9")      # nada cambió: nadie sale
    _baja(eid_b, inservible, _ficha(uid2, password_hash=auth.hash_password(PW)), _ficha(uid3, bloqueado=True), _ficha(uid4, rol="Vendedor"))
    assert all(_revocada(f"sid-c9-{n}") for n in (2, 3, 4)) and not _revocada("sid-c9")
    # D-H sigue valiendo: la web rechaza una contraseña que aquí estaba guardada como buena y su ficha solo trae el inservible (todavía
    # no entró en línea aquí): lo guardado deja de servir Y se cierran sus sesiones. Con una contraseña que tampoco era la de aquí, no
    uid5, correo5 = _persona(eid_a, "cambiada.c9", local=eid_b)
    uid6, correo6 = _persona(eid_a, "despistado.c9", local=eid_b)
    _sesion_vieja(uid5, "sid-c9-5"); _sesion_vieja(uid6, "sid-c9-6")
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "credenciales"))
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid5, password_hash=INSERVIBLE)))
    assert _entrar(correo5).status_code == 401
    assert _usuario(uid5).password_hash == INSERVIBLE and _revocada("sid-c9-5")
    assert "lo guardado deja de servir" in _ultima_auditoria(uid5, "login_rechazado").detalle
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid6, password_hash=INSERVIBLE)))
    assert _entrar(correo6, "Clave-Mala-c9-2026").status_code == 401
    assert _usuario(uid6).password_hash == INSERVIBLE and not _revocada("sid-c9-6")
