"""3.81: restaurar en una empresa el respaldo hecho en OTRA instalación (p. ej. Grupo Factura → FISITAAP ERP), donde la misma
empresa tiene otro número interno. Se acepta solo si es de la misma cédula; al restaurar se renumera la base, el logo y los archivos
quedan con el número de esta empresa, la llave criptográfica no se copia y la respuesta dice qué queda pendiente."""
import io
import json
import sqlite3
import tempfile
import types
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, respaldo
from app.config import DATA_DIR
from app.db import Empresa, engine, init_db

CEDULA = "3102381381"


def _empresa(nombre, cedula):
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == nombre)).first()
        if not e:
            e = Empresa(nombre=nombre, numero_id=cedula, actividad="620100", otras_senas="Oficina 381", correo="r381@example.test", ambiente="sandbox", tipo_negocio="facturacion")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
        return e


@pytest.fixture
def cliente():
    from app.main import app
    init_db()
    e = _empresa("Destino 381 QA", CEDULA)
    sa = types.SimpleNamespace(id=None, correo="sa-381@example.test", es_superadmin=True, nombre="SA", mfa_activo=True, empresas_ocultas="[]")
    app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(sa, e, "Administrador")
    app.dependency_overrides[auth.superadmin] = lambda: sa
    try:
        yield TestClient(app), e
    finally:
        for r in respaldo.listar_empresa(e.id):
            respaldo.eliminar_empresa(e.id, r["nombre"])
        app.dependency_overrides.clear()


def _respaldo_ajeno(origen: int, cedula: str, cliente_nombre: str) -> bytes:
    """Un respaldo como el de otra instalación: la base de la empresa número `origen` con un cliente, el logo, una exoneración,
    un adjunto, un XML y la llave .p12, más empresa.json con la cédula."""
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / f"empresa_{origen}.db"
        con = sqlite3.connect(db)
        con.execute("CREATE TABLE cliente (id INTEGER PRIMARY KEY, empresa_id INTEGER, nombre TEXT, tipo_id TEXT, numero_id TEXT, tipo TEXT, activo INTEGER)")
        con.execute("INSERT INTO cliente (empresa_id, nombre, tipo_id, numero_id, tipo, activo) VALUES (?, ?, '01', '101110111', 'Cliente', 1)", (origen, cliente_nombre))
        con.commit(); con.close()
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.write(db, f"data/empresas/empresa_{origen}.db")
            z.writestr(f"data/logo_empresa_{origen}.png", b"\x89PNG logo 381")
            z.writestr(f"data/exoneraciones/empresa_{origen}/exoneracion_1.pdf", b"%PDF exo 381")
            z.writestr(f"data/empresas/{origen}/tike/1/nota.txt", b"adjunto 381")
            z.writestr("data/xml/clave-381-qa.xml", b"<xml>381</xml>")
            z.writestr(f"data/certs/empresa_{origen}.p12", b"llave cifrada con otras claves")
            z.writestr("empresa.json", json.dumps({"id": origen, "nombre": "IT Core Sync S.R.L.", "nombre_comercial": "IT Core Sync", "numero_id": cedula}))
        return buf.getvalue()


def test_restaurar_respaldo_de_otra_instalacion(cliente):
    c, e = cliente
    origen = e.id + 7000
    r = c.post("/api/respaldos/subir", files={"archivo": ("gf.zip", _respaldo_ajeno(origen, "3-102-381381", "Cliente de Grupo Factura"), "application/zip")})
    assert r.status_code == 200, r.text
    nombre = r.json()["nombre"]
    lista = c.get("/api/respaldos").json()["respaldos"]
    assert next(x for x in lista if x["nombre"] == nombre)["origen"] == origen
    r = c.post(f"/api/respaldos/{nombre}/restaurar", json={"confirmacion": "RESTAURAR"}); assert r.status_code == 200, r.text
    j = r.json()
    assert j["otra_instalacion"] is True and j["empresa_origen"] == origen and j["omitidos"]["certs"] == 1 and len(j["pendiente"]) >= 3
    assert j["copiados"]["logo"] == 1 and j["copiados"]["exoneraciones"] == 1 and j["copiados"]["adjuntos"] == 1
    # la base quedó con el número de esta empresa: el cliente del otro servidor se ve aquí
    assert "Cliente de Grupo Factura" in [x["nombre"] for x in c.get("/api/clientes").json()]
    # archivos con el número nuevo y el logo puesto en la empresa; la llave no se copió
    assert (DATA_DIR / f"logo_empresa_{e.id}.png").read_bytes() == b"\x89PNG logo 381"
    assert (DATA_DIR / "exoneraciones" / f"empresa_{e.id}" / "exoneracion_1.pdf").exists()
    assert (DATA_DIR / "empresas" / str(e.id) / "tike" / "1" / "nota.txt").exists()
    assert not (DATA_DIR / "certs" / f"empresa_{origen}.p12").exists()
    with Session(engine) as s:
        assert s.get(Empresa, e.id).logo_nombre == f"logo_empresa_{e.id}.png"
    # un XML que ya existe en este servidor no se pisa al restaurar otra vez
    (DATA_DIR / "xml" / "clave-381-qa.xml").write_bytes(b"<xml>local</xml>")
    nombre2 = c.post("/api/respaldos/subir", files={"archivo": ("gf2.zip", _respaldo_ajeno(origen, CEDULA, "Otra vez"), "application/zip")}).json()["nombre"]
    j2 = c.post(f"/api/respaldos/{nombre2}/restaurar", json={"confirmacion": "RESTAURAR"}).json()
    assert j2["omitidos"]["existentes"] == 1 and (DATA_DIR / "xml" / "clave-381-qa.xml").read_bytes() == b"<xml>local</xml>"


def test_respaldo_de_otra_empresa_se_rechaza(cliente):
    c, e = cliente
    r = c.post("/api/respaldos/subir", files={"archivo": ("otra.zip", _respaldo_ajeno(e.id + 8000, "3101999999", "Ajeno"), "application/zip")})
    assert r.status_code == 400 and "no es un respaldo de esta empresa" in r.json()["detail"] and "3101999999" in r.json()["detail"]
    assert respaldo.listar_empresa(e.id) == []
    # por la consola tampoco
    r = c.post(f"/api/admin/respaldos/empresa/{e.id}/subir", files={"archivo": ("otra.zip", _respaldo_ajeno(e.id + 8000, "3101999999", "Ajeno"), "application/zip")})
    assert r.status_code == 400
