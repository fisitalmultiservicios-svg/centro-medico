# -*- coding: utf-8 -*-
"""4.25: correcciones de la revisión de las tandas 4b, 5 y 6 (ingreso con la cuenta de la web y conexión de una computadora nueva).

- Una instalación que nace por la conexión aprobada en la página web queda marcada `ingreso_en_linea` desde el alta: esa conexión solo la
  hace un programa 4.25 o posterior (VERSION_CONEXION), que siempre valida el ingreso en línea, así que su catálogo baja con la política
  de hash (D-E) desde la primera llamada, mande o no la cabecera X-Fisitaap-Ingreso. Sin la marca, quien tuviera el token recibía por
  GET /api/sinc/catalogo el hash real de la contraseña y del PIN de todo el personal mientras nadie hubiera entrado en línea por ella.
  Las instalaciones vinculadas con código siguen como antes (la marca la pone el primer ingreso aceptado en línea).

Aquí se llaman las rutas de la «nube» directo con el TestClient; nada se aplica en la computadora (nube y computadora comparten la tabla
de usuarios)."""
from sqlmodel import Session, select

from app import auth, sinc
from app.db import engine
from test_49_local_sinc import H, PW, _admin_empresa, _soltar_limite_vinculacion, c
from test_425_conexion_nube import _conectar, _limpieza, _vinc  # noqa: F401  (_limpieza: limpia el limitador y los pases entre pruebas)


def _ficha_de(eid: int, terminal: int) -> dict:
    return [i for i in _vinc(eid)["instalaciones"] if i["terminal"] == terminal][0]


def test_la_instalacion_de_conexion_nace_con_la_politica_de_hash(monkeypatch):
    eid, ta = _admin_empresa("-cz1", "3101425801")
    correo = "cajera-cz1@example.test"
    with Session(engine) as sc:                                             # una cajera con contraseña y PIN en la web
        u = auth.Usuario(correo=correo, nombre="Cajera", password_hash=auth.hash_password(PW), pin_hash=auth.hash_password("4827"),
                         terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol="Cajero")); sc.commit()
        reales = {x.correo: (x.password_hash, x.pin_hash) for x in sc.exec(select(auth.Usuario).where(
            auth.Usuario.correo.in_([correo, "duena-sinc49-cz1@example.test"]))).all()}
    _, r = _conectar(monkeypatch, ta, eid)
    inst = _ficha_de(eid, r["terminal"])
    assert inst["origen"] == "conexion" and inst.get("ingreso_en_linea") is True
    # nadie entró en línea por ella todavía: el catálogo, SIN la cabecera, no trae ningún hash real
    cat = c.get("/api/sinc/catalogo", headers=H(r["token"]))
    assert cat.status_code == 200, cat.text
    usuarios = {x["correo"]: x for x in cat.json()["usuarios"]}
    assert set(usuarios) == set(reales)
    assert all(x["password_hash"] == sinc.HASH_INSERVIBLE for x in usuarios.values())
    assert usuarios[correo]["pin_hash"] == sinc.HASH_INSERVIBLE and usuarios["duena-sinc49-cz1@example.test"]["pin_hash"] is None
    for h, pin in reales.values():
        assert h not in cat.text and (not pin or pin not in cat.text)
    # quien entra en línea por esa instalación sí recibe su hash real (y solo ella)
    ok = c.post("/api/sinc/ingreso", headers=H(r["token"]), json={"correo": correo, "password": PW})
    assert ok.status_code == 200 and ok.json()["ingreso"] == "ok", ok.text
    usuarios = {x["correo"]: x for x in c.get("/api/sinc/catalogo", headers=H(r["token"])).json()["usuarios"]}
    assert (usuarios[correo]["password_hash"], usuarios[correo]["pin_hash"]) == reales[correo]
    assert usuarios["duena-sinc49-cz1@example.test"]["password_hash"] == sinc.HASH_INSERVIBLE


def test_la_instalacion_con_codigo_sigue_sin_la_marca():
    """Compatibilidad (D-E): un programa anterior a la 4.25 se vincula con código y no sabe validar en línea; su instalación nace sin la
    marca y su catálogo sin cabecera trae los hash como antes."""
    eid, ta = _admin_empresa("-cz2", "3101425802")
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja código"}).json()["codigo"]
    j = c.post("/api/sinc/canje", json={"codigo": codigo}).json()
    inst = _ficha_de(eid, j["terminal"])
    assert inst["origen"] == "codigo" and not inst.get("ingreso_en_linea")
    with Session(engine) as sc:
        real = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena-sinc49-cz2@example.test")).first().password_hash
    usuarios = c.get("/api/sinc/catalogo", headers=H(j["token"])).json()["usuarios"]
    assert [x["password_hash"] for x in usuarios] == [real]
