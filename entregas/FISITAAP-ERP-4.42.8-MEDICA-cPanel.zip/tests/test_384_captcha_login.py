"""3.84: verificación contra robots (Turnstile de Cloudflare) en el inicio de sesión y en la recuperación de contraseña.
Solo se pide si el administrador del sistema la activó en Sitio web, y para activarla (o cambiarle las claves) la prueba del
panel tiene que pasar con esas claves. Si Cloudflare no le responde al servidor se deja pasar y queda anotado; la variable
FE_TURNSTILE_LOGIN=0 la apaga sin entrar al panel."""
import time
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, secretos, sitio
from app.db import Auditoria, engine, init_db
from app.main import app

init_db()
c = TestClient(app)
PW = "Clave-Segura-384-QA"
CORREO = "captcha384@example.test"
SITIO, SECRETO = "0x4AAAAAAAsitio384", "0x4AAAAAAAsecreto384"


@pytest.fixture(autouse=True)
def _limpio(monkeypatch):
    monkeypatch.delenv("FE_TURNSTILE_LOGIN", raising=False)
    sitio._CF_RESPONDIO[0] = 0.0
    with Session(engine) as s:                     # los intentos por IP se guardan en la base: otra prueba pudo agotarlos
        for x in s.exec(select(auth.IntentoIp)).all():
            s.delete(x)
        s.commit()
    auth._intentos_ip.clear()
    with Session(engine) as s:
        if not s.exec(select(auth.Usuario).where(auth.Usuario.correo == CORREO)).first():
            s.add(auth.Usuario(correo=CORREO, nombre="QA 384", password_hash=auth.hash_password(PW))); s.commit()
    yield
    sitio.ARCHIVO.unlink(missing_ok=True)
    app.dependency_overrides.clear()


def _claves(login=True, sitio_=SITIO):
    cfg = sitio.leer()
    cfg["prueba"].update({"turnstile_sitio": sitio_, "turnstile_secreto": secretos._maestra.encrypt(SECRETO.encode()).decode(), "turnstile_login": login})
    sitio.guardar(cfg)


def _cloudflare(monkeypatch, respuesta=None, caida=False):
    llamadas = []

    def falso(secreto, token, ip):
        llamadas.append((secreto, token))
        if caida:
            raise OSError("sin red")
        return respuesta(token) if callable(respuesta) else (respuesta or {})
    monkeypatch.setattr(sitio, "_siteverify", falso)
    return llamadas


def _login(token=None, pw=PW):
    return c.post("/api/auth/login", json={"correo": CORREO, "password": pw, **({"turnstile": token} if token is not None else {})})


def _auditorias(accion):
    with Session(engine) as s:
        return [a.detalle for a in s.exec(select(Auditoria).where(Auditoria.accion == accion, Auditoria.correo == CORREO)).all()]


PASA = "Su usuario no tiene empresas asignadas"        # la verificación y la contraseña pasaron (el usuario de prueba no tiene empresas)


def test_sin_activar_el_inicio_de_sesion_no_cambia(monkeypatch):
    llamadas = _cloudflare(monkeypatch, {"success": False})
    assert c.get("/api/auth/estado").json()["captcha"] is None
    assert "challenges.cloudflare.com" not in c.get("/app/").headers["Content-Security-Policy"]
    _claves(login=False)                                                # claves guardadas (formulario público) pero sin pedirla al entrar
    assert c.get("/api/auth/estado").json()["captcha"] is None
    r = _login()
    assert r.status_code == 403 and PASA in r.json()["detail"] and not llamadas
    # la página de la aplicación ya deja cargar el recuadro (para la prueba del panel); la API sigue con la política estricta
    assert c.get("/app/").headers["Content-Security-Policy"].count("https://challenges.cloudflare.com") == 3
    assert "challenges.cloudflare.com" not in c.get("/api/auth/estado").headers["Content-Security-Policy"]


def test_activada_el_inicio_de_sesion_la_exige(monkeypatch):
    _claves()
    assert c.get("/api/auth/estado").json()["captcha"] == SITIO
    llamadas = _cloudflare(monkeypatch, lambda t: {"success": t.startswith("bueno"), "action": "recuperar" if t == "bueno-otra" else "login"})
    r = _login()
    assert r.status_code == 400 and "Falta la verificación contra robots" in r.json()["detail"]
    r = _login("malo")
    assert r.status_code == 400 and "no pasó" in r.json()["detail"] and llamadas[-1] == (SECRETO, "malo")
    r = _login("bueno-otra")                                            # un token sacado para otra acción no sirve para entrar
    assert r.status_code == 400
    r = _login("bueno")
    assert r.status_code == 403 and PASA in r.json()["detail"] and llamadas[-1] == (SECRETO, "bueno")
    r = _login("bueno", pw="otra-clave-incorrecta")
    assert r.status_code == 401
    assert len(_auditorias("captcha_fallido")) == 3


def test_recuperar_contrasena_tambien_la_exige(monkeypatch):
    _claves()
    _cloudflare(monkeypatch, lambda t: {"success": t == "bueno", "action": "recuperar"})
    r = c.post("/api/auth/recuperar", json={"correo": CORREO})
    assert r.status_code == 400 and "robots" in r.json()["detail"]
    r = c.post("/api/auth/recuperar", json={"correo": CORREO, "turnstile": "bueno"})
    assert r.status_code == 200 and "Si el correo está registrado" in r.json()["mensaje"]


def test_si_cloudflare_no_responde_se_deja_pasar_y_se_anota(monkeypatch):
    _claves()
    _cloudflare(monkeypatch, caida=True)
    r = _login("cualquiera")
    assert r.status_code == 403 and PASA in r.json()["detail"]
    r = _login()                                                        # sin token tampoco hay cómo verificar: pasa
    assert r.status_code == 403
    assert len(_auditorias("captcha_sin_respuesta")) == 2
    # Cloudflare dice que la clave secreta no sirve (error de configuración, no del visitante): pasa y se anota
    _cloudflare(monkeypatch, {"success": False, "error-codes": ["invalid-input-secret"]})
    assert _login("x").status_code == 403
    assert any("clave secreta" in d for d in _auditorias("captcha_sin_respuesta"))
    # sin token y con Cloudflare respondiendo hace poco: se rechaza sin consultarlo otra vez
    llamadas = _cloudflare(monkeypatch, {"success": True})
    sitio._CF_RESPONDIO[0] = time.time()
    assert _login().status_code == 400 and not llamadas


def test_la_variable_del_servidor_la_apaga(monkeypatch):
    _claves()
    _cloudflare(monkeypatch, {"success": False})
    monkeypatch.setenv("FE_TURNSTILE_LOGIN", "0")
    assert c.get("/api/auth/estado").json()["captcha"] is None
    assert _login().status_code == 403


def test_activarla_desde_el_panel_exige_una_prueba_que_pase(monkeypatch):
    admin = types.SimpleNamespace(id=None, correo="admin384@example.test", es_superadmin=True, nombre="Admin")
    app.dependency_overrides[auth.superadmin] = lambda: admin
    cfg = c.get("/api/admin/sitio").json()
    assert cfg["prueba"]["turnstile_login"] is False
    prueba = {"automatica": False, "dias": 30, "turnstile_sitio": SITIO, "turnstile_secreto": SECRETO, "turnstile_login": True}
    llamadas = _cloudflare(monkeypatch, lambda t: {"success": t == "bueno"})
    r = c.put("/api/admin/sitio", json={**cfg, "prueba": prueba})
    assert r.status_code == 400 and "Probar la verificación" in r.json()["detail"] and not sitio.leer()["prueba"]["turnstile_login"]
    r = c.put("/api/admin/sitio", json={**cfg, "prueba": {**prueba, "turnstile_prueba": "malo"}})
    assert r.status_code == 400 and "no pasó" in r.json()["detail"] and llamadas[-1] == (SECRETO, "malo")
    _cloudflare(monkeypatch, caida=True)
    assert c.put("/api/admin/sitio", json={**cfg, "prueba": {**prueba, "turnstile_prueba": "bueno"}}).status_code == 400   # aquí no se deja pasar
    assert not sitio.leer()["prueba"]["turnstile_login"]
    llamadas = _cloudflare(monkeypatch, lambda t: {"success": t == "bueno"})
    r = c.put("/api/admin/sitio", json={**cfg, "prueba": {**prueba, "turnstile_prueba": "bueno"}})
    assert r.status_code == 200, r.text
    assert r.json()["prueba"]["turnstile_login"] is True and "turnstile_secreto" not in r.json()["prueba"] and llamadas[-1] == (SECRETO, "bueno")
    assert sitio.turnstile_login() == SITIO and c.get("/api/auth/estado").json()["captcha"] == SITIO
    # guardar otra cosa sin tocar las claves no pide otra prueba; cambiar la clave del sitio sí
    sin_secreta = {**prueba, "turnstile_secreto": ""}
    assert c.put("/api/admin/sitio", json={**cfg, "prueba": {**sin_secreta, "dias": 20}}).status_code == 200
    assert c.put("/api/admin/sitio", json={**cfg, "prueba": {**sin_secreta, "turnstile_sitio": "0x4AAAAAAAotra384"}}).status_code == 400
    assert sitio.turnstile_login() == SITIO
    # sin clave del sitio no queda nada que pedir
    r = c.put("/api/admin/sitio", json={**cfg, "prueba": {**sin_secreta, "turnstile_sitio": ""}})
    assert r.status_code == 200 and r.json()["prueba"]["turnstile_login"] is False and sitio.turnstile_login() == ""
