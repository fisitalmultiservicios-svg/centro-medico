# -*- coding: utf-8 -*-
"""4.29, ajuste tras la segunda revisión (seis puntos):

- A1: en la venta rápida, la comanda automática al cobrar sale DESPUÉS de las revisiones que pueden rechazar el cobro (fiado, crédito,
  clave de supervisor): un cobro rechazado no manda comanda, no gasta número ni deja cuenta guardada.
- A2: el cobro cierra la cuenta con el id de AHORA (si el servidor se lo cambió durante el cobro, no se borra la cuenta de otro equipo).
- A3: la caja se suscribe a los cambios de id antes de la primera espera y, al salir, no queda ninguna suscripción viva.
- A4: sin platos para cocina, la venta rápida no manda comanda (no pide número ni espera nada).
- A5: un pedido «confirmado» sin cuenta en la caja (crear la cuenta falló y la vuelta atrás también) se retoma con «Aceptar»; el error
  original no queda tapado.
- A6: en Pedidos, el reintento de leer la impresión antes de aceptar tiene tope de 1,5 s.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import re

import pytest
from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlmodel import Session

from app import pedidos
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_425_ultimos_pantallas import _node
from tests.test_429_comanda_numero_pantallas import FALSO_API as FALSO_API_CAJA, FALSO_APP as FALSO_APP_CAJA
from tests.test_429_pedido_web_comanda import FALSOS_FIS, _contador, _falsos, _montar_negocio, _pedido, _pedidos_para_node
from tests.test_429_rematar import _arnes_cobro, _ctx, _cuentas_del_pedido, _estado, _guion_pedidos, _js, _tramo


# ================================================================================================================ A1, A2, A4 (cobro en Node)
def test_a1_a2_a4_cobro_de_la_venta_rapida_en_node(tmp_path):
    r = _node(tmp_path, _arnes_cobro() + """
const out = {};
const todo = vm => ({ ...foto(vm), guardados: Q.guardados, numero: Q.log.some(x => x.includes('comanda/numero')), avisos: Q.toasts.map(t => t[0]) });
const FIADO = { tipo_documento: '04', medios: [{ medio: 'fiado', monto: 1000 }], recibido: null, propina: 0 };
// A1: fiado a un cliente sin límite de crédito (caja que numera)
let vm = caja({ clienteId: 5, cliente: { id: 5, nombre: 'Ana', limite_credito: 0 }, pago: FIADO }, { numerar_comanda: 'dia' }); await vm.cobrar(); out.sin_limite = todo(vm);
// A1: fiado sin cliente
vm = caja({ pago: FIADO }); await vm.cobrar(); out.sin_cliente = todo(vm);
// A1: no se pudo revisar el crédito
vm = caja({ clienteId: 5, cliente: { id: 5, nombre: 'Ana', limite_credito: 5000 }, pago: FIADO, saldoFiado: async () => { throw new Error('sin red'); } }); await vm.cobrar(); out.sin_revisar = todo(vm);
// A1: descuento que pide la clave de supervisor y el cajero la cancela
vm = caja({ descuentoDe: () => 500, autorizar: async () => false }, { descuento_max_pct: 10, numerar_comanda: 'dia' }); await vm.cobrar(); out.sin_clave = todo(vm);
// A1: el mismo cobro, ya con la clave: ahora sí sale la comanda (antes del comprobante)
vm = caja({ descuentoDe: () => 500, autorizar: async () => true }, { descuento_max_pct: 10 }); await vm.cobrar(); out.con_clave = todo(vm);
// A4: nada va a cocina (caja que numera): ni comanda, ni número, ni cuenta, ni espera
vm = caja({ destinoDe: () => null }, { numerar_comanda: 'dia' }); await vm.cobrar(); out.sin_cocina = todo(vm);
// A4: uno de los dos va a cocina: sale la comanda como siempre
vm = caja({ destinoDe: l => (l.detalle === 'Casado' ? { id: 'c', nombre: 'Cocina', conexion: 'usb' } : null) }); await vm.cobrar(); out.uno_a_cocina = todo(vm);
// A2: el servidor le cambia el id a la cuenta (1 -> 6) mientras se emite y llega la cuenta 1 de OTRO equipo
const api0 = globalThis.api;
const cambiarId = vm => { globalThis.api = async (u, o) => { if (u === '/api/comprobantes' && !Q.cambiado) { Q.cambiado = true;
  Q.datos.pos_espera = Q.datos.pos_espera.map(x => (x.id === 1 ? { ...x, id: 6 } : x)).concat([{ id: 1, nombre: 'Mesa 2 (otro equipo)', lineas: [] }]); vm.seguirIds('pos_espera', { 1: 6 }); }
  return api0(u, o); }; };
const lista = () => (Q.datos.pos_espera || []).map(x => [x.id, x.nombre]);
vm = caja({ mesaActual: { id: 4, nombre: 'Mesa 4' }, rapida: false, nombreEspera: 'Mesa 4', esperaId: 1, lineas: [plato('Casado', '2026-11-12T10:00:00Z')] });
Q.datos.pos_espera = [{ id: 1, nombre: 'Mesa 4', lineas: [plato('Casado', '2026-11-12T10:00:00Z')] }]; Q.cambiado = false; cambiarId(vm);
await vm.cobrar(); out.mesa = lista(); globalThis.api = api0;
vm = caja(); Q.cambiado = false; cambiarId(vm); await vm.cobrar(); out.rapida = lista(); globalThis.api = api0;
vm = caja(); Q.cambiado = false; cambiarId(vm); Q.falla = Object.assign(new Error('Sin conexión con el servidor'), { sinConexion: true }); await vm.cobrar(); out.sin_conexion = Q.sinConexion; globalThis.api = api0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_datos.js", "pages/pos/_agente.js", "pages/pos/_fusion.js"), falsos={"api.js": FALSO_API_CAJA, "app.js": FALSO_APP_CAJA})
    rechazos = {"sin_limite": "Ana no tiene límite de crédito: defínalo en Contactos", "sin_cliente": "El fiado requiere elegir el cliente",
                "sin_revisar": "No se pudo revisar el crédito del cliente: sin red", "sin_clave": None}
    for k, aviso in rechazos.items():
        x = r[k]
        assert x["comandas"] == [] and x["guardados"] == 0 and not x["numero"] and x["cuentas"] == [] and x["lineas"] == [False, False], (k, r)   # antes: la comanda ya había salido
        assert x["comprobantes"] == 0 and not any(a.startswith("Comanda") for a in x["avisos"]), (k, r)
        if aviso:
            assert aviso in x["avisos"], (k, r)
    c = r["con_clave"]
    assert c["comandas"] == ["COCINA"] and c["comprobantes"] == 1 and c["cuentas"] == [], r
    assert c["log"].index("comanda:Cocina:COCINA") < c["log"].index("guardar-servidor") < c["log"].index("POST /api/comprobantes"), r
    s = r["sin_cocina"]
    assert s["comprobantes"] == 1 and s["guardados"] == 0 and not s["numero"] and s["cuentas"] == [] and s["toasts"] == [], r       # antes: gastaba un número y guardaba la cuenta
    assert s["log"][0] == "POST /api/comprobantes", r
    u = r["uno_a_cocina"]
    assert u["comandas"] == ["COCINA"] and u["guardados"] == 1 and u["comprobantes"] == 1 and u["cuentas"] == [], r
    assert r["mesa"] == [[1, "Mesa 2 (otro equipo)"]], r          # antes: borraba la cuenta 1 del otro equipo y dejaba abierta la 6 ya cobrada
    assert r["rapida"] == [[1, "Mesa 2 (otro equipo)"]], r
    assert r["sin_conexion"] == [6], r                              # la venta sin conexión retira la cuenta con su id de ahora


# ================================================================================================================ A3 (created / beforeUnmount en Node)
def test_a3_la_caja_se_suscribe_antes_de_esperar_y_al_salir_no_queda_nada_en_node(tmp_path):
    k = _js("pages/pos/caja.js")
    fuente = _tramo(k, "  async created() {", "\n  mounted()").strip().rstrip(",") + ",\n" + _tramo(k, "  beforeUnmount() {", "\n").strip().rstrip(",")
    r = _node(tmp_path, """
const fuente = %s;
const subs = new Set();
const mock = { alCambiarIds(f) { subs.add(f); return () => subs.delete(f); } };
let soltar = null; const pendiente = new Promise(r => { soltar = r; });
const api = () => pendiente.then(() => []);
const ev = { addEventListener() {}, removeEventListener() {} };
const M = new Function('mock', 'api', 'cuentasParaMovimientos', 'localStorage', 'sesion', 'cargarEquipo', 'window', 'document', 'red', 'setInterval', 'clearInterval', 'setTimeout', 'iniciarEstacion', 'pararEstacion', 'return {' + fuente + '};')(
  mock, api, async () => [], { getItem: () => null }, { empresaInfo: {} }, async () => {}, { ...ev, innerWidth: 1200 }, { ...ev, hidden: false }, { enLinea: true }, () => 1, () => {}, () => 1, () => {}, () => {});   // 4.31: iniciar y parar la estación de comandas
function caja() {
  const vm = { cfg: { id: 1 }, sinConfigurar: false, caja: null, cola: [], vistos: [], seguirIds(k, c) { this.vistos.push(k); }, bodegaDefecto() {}, abrirGuia() {}, cargarExistencias() {},
    tecla() {}, revisarOnline() {}, sincronizar() {}, cargarCola() {}, reponerPendientes() {}, reintentarPendientes() {}, abrirApertura() {} };
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const out = {};
// la red tarda: la caja ya se ve y ya recibe el aviso del cambio de id; se sale antes de que termine la carga
let vm = caja(); const p = vm.created(); out.al_entrar = subs.size;
for (const f of subs) f('pos_espera', { 1: 6 }); out.avisos = vm.vistos;
vm.beforeUnmount(); out.al_salir = subs.size;
soltar(); await p; await new Promise(r => setImmediate(r)); out.despues = subs.size;
// lo normal: entra, carga, sale (y otra visita no deja una suscripción de más)
vm = caja(); await vm.created(); out.normal = subs.size; vm.beforeUnmount(); out.normal_salir = subs.size;
vm = caja(); await vm.created(); const vm2 = caja(); vm.beforeUnmount(); await vm2.created(); out.otra_visita = subs.size; vm2.beforeUnmount(); out.fin = subs.size;
console.log(JSON.stringify(out));
process.exit(0);
""" % json.dumps(fuente), archivos=(), falsos={})
    assert r["al_entrar"] == 1 and r["avisos"] == ["pos_espera"], r     # antes: 0 hasta que terminaban las dos esperas de red
    assert r["al_salir"] == 0 and r["despues"] == 0, r                  # antes: la suscripción se creaba después de salir y quedaba viva
    assert r["normal"] == 1 and r["normal_salir"] == 0 and r["otra_visita"] == 1 and r["fin"] == 0, r


# ================================================================================================================ A5 (servidor)
def test_a5_confirmado_sin_cuenta_se_retoma_con_aceptar(api, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "continuo"})
    p = _pedido(c, slug, a, b)
    real = pedidos.a_caja

    def falla_y_base_ocupada(s, eid_, ped, n, origen=None):    # 4.31: a_caja recibe el origen de la comanda
        ejecutar = s.execute

        def ocupada(st, *x, **k):                               # la vuelta atrás encuentra la base bloqueada
            if str(st).lstrip().upper().startswith("UPDATE"):
                raise OperationalError("UPDATE", {}, Exception("database is locked"))
            return ejecutar(st, *x, **k)
        monkeypatch.setattr(s, "execute", ocupada)
        raise RuntimeError("falla original de la cuenta")
    monkeypatch.setattr(pedidos, "a_caja", falla_y_base_ocupada)
    with pytest.raises(RuntimeError, match="falla original de la cuenta"):     # antes: subía el «database is locked» de la vuelta atrás
        c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert _estado(eid, p["id"]) == "confirmado" and _cuentas_del_pedido(eid, p["id"]) == []    # quedó confirmado sin cuenta
    monkeypatch.setattr(pedidos, "a_caja", real)
    # al instante: puede ser otro equipo aceptándolo ahora mismo; se avisa que se intente en un minuto
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 400 and "toque «Aceptar» otra vez" in r.text, r.text
    with Session(engine_empresa(eid)) as s:                     # pasó el minuto (o el proceso se había cerrado en medio)
        s.execute(text("UPDATE pedido SET confirmado = :v WHERE id = :id"), {"v": "2026-01-01T00:00:00-06:00", "id": p["id"]}); s.commit()
    segundo = {}

    def a_caja_con_otro_equipo(s, eid_, ped, n, origen=None):   # 4.31: a_caja recibe el origen de la comanda
        if not segundo:                                         # dos equipos lo retoman a la vez: uno solo crea la cuenta
            segundo["hecho"] = True
            with Session(engine_empresa(eid)) as s2:
                try:
                    pedidos.cambiar_estado(p["id"], pedidos.EstadoIn(estado="confirmado"), _ctx(), s2); segundo["status"] = 200
                except HTTPException as e:
                    segundo["status"], segundo["detalle"] = e.status_code, e.detail
        return real(s, eid_, ped, n, origen)
    monkeypatch.setattr(pedidos, "a_caja", a_caja_con_otro_equipo)
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 200, r.text                         # antes: «solo se confirma un pedido nuevo» para siempre
    assert segundo["status"] == 400, segundo
    cuentas = _cuentas_del_pedido(eid, p["id"])
    assert [x["id"] for x in cuentas] == [r.json()["cuenta_espera_id"]], cuentas
    assert _contador(eid) == [("continuo", 1)] and _estado(eid, p["id"]) == "confirmado"
    monkeypatch.setattr(pedidos, "a_caja", real)
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 400 and "solo se confirma un pedido nuevo" in r.text and "otra vez" not in r.text, r.text   # ya tiene cuenta: no se repite


def test_a5_el_boton_aceptar_sale_para_el_confirmado_sin_cuenta():
    ped = _js("fis/pages/pedidos.js")
    m = re.search(r'<form v-if="([^"]+)" @submit\.prevent="aceptar\(f\.p\)">', ped)
    assert m, "no está el botón de aceptar"
    r = _evaluar(m.group(1), [
        {"estado": "nuevo", "p": {}},
        {"estado": "confirmado", "p": {"cuenta_espera_id": None}},
        {"estado": "confirmado", "p": {"cuenta_espera_id": 77}},
        {"estado": "confirmado", "p": {"cuenta_espera_id": None, "documento_id": 3}},
        {"estado": "en_preparacion", "p": {}},
        {"estado": "cancelado", "p": {}}])
    assert r == [True, True, False, False, False, False], r


def _evaluar(expr, filas):
    import subprocess
    from tests.test_425_ultimos_pantallas import _nodo
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    guion = "const f = new Function('enProg', 'f', 'return !!(' + %s + ');'); console.log(JSON.stringify(%s.map(x => f(false, x))));" % (json.dumps(expr), json.dumps(filas))
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=60, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    return json.loads(out.stdout)


# ================================================================================================================ A6 (Pedidos en Node)
def test_a6_aceptar_no_espera_la_impresion_mas_de_1_5_s_en_node(tmp_path):
    casos = """
const { setTimeout: reloj } = await import('node:timers');   /* el guion de siempre anula setTimeout; aquí hace falta el de verdad */
const colgar = async (vm, p) => { R.fallar = null; const api0 = Q.api, st0 = globalThis.setTimeout; globalThis.setTimeout = reloj;
  Q.api = (u, o) => (u === '/api/registros/pos_config' ? (Q.llamadas.push(u), new Promise(() => {})) : api0(u, o));
  const t0 = Date.now(); const ok = await Promise.race([vm.aceptar(p), new Promise(r => reloj(() => r('colgado'), 4000))]); const ms = Date.now() - t0; Q.api = api0; globalThis.setTimeout = st0; return [ok, ms]; };
out.colgada = await caso({ fallar: ['/api/registros/pos_config'] }, true, colgar);
// si la lectura responde a tiempo, imprime como siempre
out.a_tiempo = await caso({ fallar: ['/api/registros/pos_config'] }, true, async (vm, p) => { R.fallar = null; return vm.aceptar(p); });
"""
    falsos = _falsos({**FALSOS_FIS, "fis/pages/pedidos.js": _pedidos_para_node()})
    r = _node(tmp_path, _guion_pedidos(casos), archivos=("pages/pos/_comandas.js",), falsos=falsos)
    x = r["colgada"]
    ok, ms = x["ok"]
    assert ok is True and 1400 <= ms < 3000, r                                                       # antes: «colgado» (sin tope)
    assert "PUT /api/pedidos/9/estado" in x["llamadas"] and x["docs"] == [] and x["estado"] == "en_preparacion", r
    assert x["toasts"] == [["Pedido aceptado. La comanda no se imprimió: no se pudo leer a tiempo la configuración de impresión. Imprímala desde Punto de venta › Cocina.", "err"]], r
    t = r["a_tiempo"]
    assert t["ok"] is True and t["docs"] == ["COMANDA N.º 4"] and t["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]], r
