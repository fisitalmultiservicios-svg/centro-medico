"""3.63: restaurar un respaldo de empresa desde la pantalla (la empresa los suyos, el administrador del sistema los de
cualquiera) y subir un respaldo .zip. Antes de restaurar se guarda una copia de seguridad del estado actual."""
import io
import types
import zipfile

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth, respaldo
from app.db import Empresa, engine, init_db


@pytest.fixture(autouse=True)
def _sin_superadmin_al_final():
    yield
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-363@example.test")).first()
        if u:
            s.delete(u); s.commit()


def _cliente():
    from app.main import app
    init_db()
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-363@example.test")).first()
        if not u:
            u = auth.Usuario(correo="sa-363@example.test", nombre="SA 363", password_hash=auth.hash_password("Clave-Segura-363-QA!"), es_superadmin=True)
            s.add(u); s.commit(); s.refresh(u)
        e = s.exec(select(Empresa).where(Empresa.nombre == "Restaurar 363 QA")).first()
        if not e:
            e = Empresa(nombre="Restaurar 363 QA", numero_id="3101363363", actividad="620100", otras_senas="Oficina 3", correo="rest363@example.test", ambiente="sandbox", tipo_negocio="facturacion")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
        sa = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
    ctx = auth.Contexto(sa, e, "Administrador")
    app.dependency_overrides[auth.superadmin] = lambda: sa
    app.dependency_overrides[auth.solo_usuario] = lambda: sa
    app.dependency_overrides[auth.contexto] = lambda: ctx
    return TestClient(app), e, app


def _nombres(c):
    return [x["nombre"] for x in c.get("/api/clientes").json()]


def _limpiar_respaldos(eid):
    for r in respaldo.listar_empresa(eid):
        respaldo.eliminar_empresa(eid, r["nombre"])


def test_restaurar_vuelve_al_estado_del_respaldo():
    c, e, app = _cliente()
    try:
        _limpiar_respaldos(e.id)
        assert c.post("/api/clientes", json={"nombre": "Cliente Antes", "tipo": "Cliente", "tipo_id": "01", "numero_id": "101110111"}).status_code == 200
        nombre = c.post("/api/respaldos").json()["nombre"]
        assert c.post("/api/clientes", json={"nombre": "Cliente Después", "tipo": "Cliente", "tipo_id": "01", "numero_id": "202220222"}).status_code == 200
        assert "Cliente Después" in _nombres(c)

        assert c.post(f"/api/respaldos/{nombre}/restaurar", json={"confirmacion": "no"}).status_code == 400
        assert c.post("/api/respaldos/empresa_999999_20260101_000000.zip/restaurar", json={"confirmacion": "RESTAURAR"}).status_code == 404
        r = c.post(f"/api/respaldos/{nombre}/restaurar", json={"confirmacion": "restaurar"})
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["ok"] and j["copiados"]["base"] == 1 and j["seguridad"].startswith(f"empresa_{e.id}_")
        nombres = _nombres(c)
        assert "Cliente Antes" in nombres and "Cliente Después" not in nombres
        lista = [x["nombre"] for x in c.get("/api/respaldos").json()["respaldos"]]
        assert nombre in lista and j["seguridad"] in lista            # el respaldo usado y la copia de seguridad previa

        # la copia de seguridad trae el estado anterior a restaurar: restaurarla devuelve a «Cliente Después»
        assert c.post(f"/api/respaldos/{j['seguridad']}/restaurar", json={"confirmacion": "RESTAURAR"}).status_code == 200
        assert "Cliente Después" in _nombres(c)
    finally:
        _limpiar_respaldos(e.id)
        app.dependency_overrides.clear()


def test_subir_respaldo_valida_el_archivo():
    c, e, app = _cliente()
    try:
        _limpiar_respaldos(e.id)
        nombre = c.post("/api/respaldos").json()["nombre"]
        contenido = c.get(f"/api/respaldos/{nombre}").content
        _limpiar_respaldos(e.id)
        assert c.get("/api/respaldos").json()["respaldos"] == []

        r = c.post("/api/respaldos/subir", files={"archivo": ("mi_respaldo.zip", contenido, "application/zip")})
        assert r.status_code == 200, r.text
        subido = r.json()["nombre"]
        assert subido.startswith(f"empresa_{e.id}_") and [x["nombre"] for x in c.get("/api/respaldos").json()["respaldos"]] == [subido]

        assert c.post("/api/respaldos/subir", files={"archivo": ("x.zip", b"hola", "application/zip")}).status_code == 400
        otro = io.BytesIO()
        with zipfile.ZipFile(otro, "w") as z:
            z.writestr("data/empresas/empresa_999999.db", b"SQLite format 3\x00" + b"\x00" * 100)
        r = c.post("/api/respaldos/subir", files={"archivo": ("otra.zip", otro.getvalue(), "application/zip")})
        assert r.status_code == 400 and "no es un respaldo de esta empresa" in r.json()["detail"]
        malo = io.BytesIO()
        with zipfile.ZipFile(malo, "w") as z:
            z.writestr(f"data/empresas/empresa_{e.id}.db", b"SQLite format 3\x00" + b"\x00" * 100)
            z.writestr("data/../../etc/passwd", b"x")
        assert c.post("/api/respaldos/subir", files={"archivo": ("malo.zip", malo.getvalue(), "application/zip")}).status_code == 400
        assert len(respaldo.listar_empresa(e.id)) == 1                  # los rechazados no dejan archivo
    finally:
        _limpiar_respaldos(e.id)
        app.dependency_overrides.clear()


def test_admin_restaura_y_sube_para_una_cuenta():
    c, e, app = _cliente()
    try:
        _limpiar_respaldos(e.id)
        assert c.post("/api/clientes", json={"nombre": "Cliente Admin", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303330333"}).status_code == 200
        nombre = c.post("/api/respaldos").json()["nombre"]
        contenido = c.get(f"/api/respaldos/{nombre}").content
        assert c.post(f"/api/admin/respaldos/empresa/{e.id}/{nombre}/restaurar", json={"confirmacion": "RESTAURAR"}).status_code == 200
        assert c.post(f"/api/admin/respaldos/empresa/999999/{nombre}/restaurar", json={"confirmacion": "RESTAURAR"}).status_code == 404
        r = c.post(f"/api/admin/respaldos/empresa/{e.id}/subir", files={"archivo": ("copia.zip", contenido, "application/zip")})
        assert r.status_code == 200 and r.json()["nombre"].startswith(f"empresa_{e.id}_")
        assert len(respaldo.listar_empresa(e.id)) == 3                  # original, seguridad y subido
    finally:
        _limpiar_respaldos(e.id)
        app.dependency_overrides.clear()
