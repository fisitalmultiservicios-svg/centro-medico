# -*- coding: utf-8 -*-
"""4.23 · Gastos: pulido final, sobre tests/test_423_gastos.py, test_423_adenda.py y test_423_revision.py:
P1 · la tabla de Rectificaciones cabe en pantalla (las exportaciones siguen completas);
P2 · el texto del periodo cerrado depende de la acción;
P3 · el vencimiento de una factura vencida vuelve a verse en rojo en la ventana «Ver»;
P4 · los recibos electrónicos de pago (tipo 10) no entran ni salen del registro;
P5 · la rectificación de una aceptación parcial (06) lleva los montos que cuentan los reportes;
P6 · borrar por el guardado genérico una factura con factura electrónica de compra no es una rectificación;
P7 · la sincronización de la contabilidad empieza trayendo también la lista de compras;
P8 · la factura de un comprobante rechazado (07) se ve atenuada, no suma al pie y eliminarla no pide motivo: la pantalla decide como el servidor;
P9 · la D-104 por moneda decide con todos los recibidos si una factura está cubierta por el suyo;
P10 · un solo criterio (recepcion_id o clave) para saber de qué comprobante salió una factura;
P11 · el aviso de «pendiente de envío» en llano, las fechas del PDF de las listas como en pantalla y ningún «No electrónica» para la
factura de un comprobante aceptado."""
import json
import pathlib
import shutil
import subprocess

import pytest
from sqlmodel import Session

from app import main, recepcion, resumen
from app.db import engine_empresa
from tests.test_423_adenda import _al_reves, _sincronizar
from tests.test_423_gastos import AHORA, MOTIVO, NODOS, NOVIEMBRE, OCTUBRE, _aceptado, _alta, _auditoria, _compra, _compras, _ctx, _eid, _js, _octubre, _recibido, _rects
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

RAIZ = pathlib.Path(main.__file__).parent.parent


@pytest.fixture(autouse=True)
def _reloj(monkeypatch):
    """«Hoy» es el 10 de noviembre de 2026 (como en test_423_gastos); y el resumen no sale a buscar el tipo de cambio."""
    monkeypatch.setattr(main, "ahora_cr", lambda: AHORA)

    def _sin_red():
        raise RuntimeError("sin red en las pruebas")
    monkeypatch.setattr(main.tipo_cambio, "obtener", _sin_red)


def _cambiar(rid, **campos):
    """Deja el comprobante recibido con esos datos (lo que no se arma con la ayuda _aceptado)."""
    with Session(engine_empresa(_eid())) as s:
        r = s.get(recepcion.Recibido, rid)
        for k, v in campos.items():
            setattr(r, k, v)
        s.add(r); s.commit()


API_FALSA = ("export const S = { datos: {} };\nexport const mock = { get(k, d) { return k in S.datos ? JSON.parse(JSON.stringify(S.datos[k])) : d; }, puedeGuardar: () => true, guardarTodo: async () => {} };\n"
             "export const money = (n, m) => (m || 'CRC') + ' ' + n, fecha = v => 'F(' + String(v || '') + ')', fechaHora = v => 'FH(' + String(v || '') + ')', hoy = () => '2026-11-10', toast = () => {};\n"
             "export const api = async () => ({}), fmtCant = n => String(n), verDocumento = async () => {}, token = () => '', cabecerasAuth = () => ({});\n")
# lo que importan las pantallas de Gastos y no hace falta para probar sus reglas
FALSOS = {"api.js": API_FALSA, "app.js": "export const store = {}, sesion = { puede: () => true };\n", "pages/reportes/_montos.js": "export const descargarTabla = () => {};\n",
          "pages/gastos/_datos.js": "export const compras = () => [];\n", "pages/gastos/compra-form.js": "export const lineasInventario = () => [], entradaCompra = async () => ({});\n",
          "pages/contabilidad/catalogo.js": "export const planCuentas = () => [];\n"}


def _node(tmp_path, archivos, guion, falsos=None):
    """Corre un guion de Node sobre los archivos de app/static/js tal como están (los demás módulos, con un sustituto mínimo)."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = tmp_path / "js"
    for ruta, texto in (FALSOS if falsos is None else falsos).items():
        (raiz / ruta).parent.mkdir(parents=True, exist_ok=True)
        (raiz / ruta).write_text(texto, encoding="utf-8")
    for partes in archivos:
        (raiz / pathlib.Path(*partes)).parent.mkdir(parents=True, exist_ok=True)
        (raiz / pathlib.Path(*partes)).write_text(_js(*partes), encoding="utf-8")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


# ------------------------------------------------------------------------------------------------ P1 y P2 · la tabla de Rectificaciones
def test_p1_p2_la_tabla_de_rectificaciones_en_pantalla(tmp_path):
    """En PANTALLA: fecha y usuario en una columna, sin «Fecha del documento», y los textos largos se parten en renglones (para caber
    en 1366 px). Las exportaciones siguen con las trece columnas. Y el periodo cerrado dice «el reverso» solo para lo eliminado."""
    o = _node(tmp_path, [("pages", "gastos", "rectificaciones.js"), ("pages", "gastos", "_registro.js")], r"""
import { S } from './js/api.js';
import pantalla from './js/pages/gastos/rectificaciones.js';
const x = (id, accion, extra) => ({ id, fecha: '2026-11-0' + id + 'T09:00:00-06:00', usuario: 'qa@example.test', accion, tipo: 'gasto', documento: 'C' + id, proveedor: 'Proveedor QA', fecha_documento: '2026-10-08',
  mes: '2026-10', moneda: 'CRC', total: 100, iva_acreditar: 13, motivo: 'Se registró dos veces', periodo_cerrado: true, ...extra });
const filtradas = [x(1, 'eliminado'), x(2, 'registrado'), x(3, 'reclasificado', { tipo: 'compra', tipo_anterior: 'gasto' }), x(4, 'eliminado', { periodo_cerrado: false, usuario: '' })];
const rows = pantalla.computed.rows.call({ filtradas }), cols = pantalla.computed.columns.call({}), exp = pantalla.computed.columnasExportar.call({});
const fila = id => rows.find(r => r.id === id), col = k => cols.find(c => c.key === k);
const o = { claves: cols.map(c => c.key), etiquetas: cols.map(c => c.label), parten: cols.filter(c => /\bparte\b/.test(c.class || '')).map(c => c.key), finas: cols.filter(c => c.class === 'parte fina').map(c => c.key), insignias: cols.filter(c => c.fmt === 'badge').map(c => c.key),
  fechaUsuario: col('fecha').fmt(fila(1).fecha, fila(1)), fechaSinUsuario: col('fecha').fmt(fila(4).fecha, fila(4)),
  exportar: exp.map(c => c.label), periodos: Object.fromEntries(rows.map(r => [r.id, r.periodo])) };
S.datos.periodos_2026 = [{ n: 10, mes: 'Octubre', estado: 'Cerrado' }];
o.hoyCerrado = Object.fromEntries(pantalla.computed.rows.call({ filtradas }).map(r => [r.id, r.periodo]));
console.log(JSON.stringify(o));
""")
    # P1 · diez columnas en pantalla: la fecha con el usuario, sin la fecha del documento
    assert o["claves"] == ["fecha", "accion", "tipo", "documento", "proveedor", "mes", "total", "iva", "motivo", "periodo"]
    assert o["etiquetas"][0] == "Fecha y usuario" and o["fechaUsuario"] == "FH(2026-11-01T09:00:00-06:00) · qa@example.test" and o["fechaSinUsuario"] == "FH(2026-11-04T09:00:00-06:00)"
    # se parten en renglones: documento, proveedor, motivo y periodo contable (y la fecha con el usuario y el tipo con sus cuentas)
    assert set(o["parten"]) == {"fecha", "tipo", "documento", "proveedor", "motivo", "periodo"}
    assert o["insignias"] == ["accion"]                            # el periodo va como texto: una insignia no se parte en renglones
    css = (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")
    assert ".tbl td.parte{white-space:normal;min-width:150px}" in css and ".tbl td.parte.fina{min-width:100px;overflow-wrap:anywhere}" in css
    assert o["finas"] == ["fecha", "tipo", "proveedor", "motivo", "periodo"]      # el número del documento no se parte por la mitad
    # las exportaciones siguen completas
    assert o["exportar"] == ["Fecha", "Usuario", "Acción", "Tipo", "Documento", "Proveedor", "Fecha del documento", "Mes afectado", "Moneda", "Total", "IVA", "Motivo", "Periodo contable"]
    x = _js("pages", "gastos", "rectificaciones.js")
    assert "descargarTabla(formato, 'rectificaciones', this.columnasExportar, this.rows," in x and '<DataTable :rows="rows" :columns="columns" :search="q"' in x
    # P2 · el periodo cerrado: lo eliminado deja un reverso; lo registrado de nuevo o reclasificado, un ajuste
    reverso, ajuste = "Cerrado: el reverso queda en el mes en curso", "Cerrado: el ajuste queda en el mes en curso"
    assert o["periodos"] == {"1": reverso, "2": ajuste, "3": ajuste, "4": "Abierto"}
    assert o["hoyCerrado"] == {"1": reverso, "2": ajuste, "3": ajuste, "4": reverso}


# ------------------------------------------------------------------------------------------------ P3 · el vencimiento en la ventana «Ver»
def test_p3_el_vencimiento_de_una_factura_vencida_se_ve_en_rojo(tmp_path):
    """«Ver» abre la factura tal como está guardada, que no trae «por_pagar»: vencida es con saldo (total − pagado) y la fecha de
    vencimiento ya pasada, como antes de la 4.23."""
    o = _node(tmp_path, [("pages", "gastos", "compras.js"), ("pages", "gastos", "_registro.js")], r"""
import pantalla from './js/pages/gastos/compras.js';
const v = c => pantalla.methods.vencida.call({ hoy: '2026-11-10' }, c);
console.log(JSON.stringify([v({ total: 11300, pagado: 0, vencimiento: '2026-11-01' }), v({ total: 11300, pagado: 5000, vencimiento: '2026-11-09' }), v({ total: '11300', pagado: null, vencimiento: '2026-10-01' }),
  v({ total: 11300, pagado: 11300, vencimiento: '2026-11-01' }), v({ total: 11300, pagado: 12000, vencimiento: '2026-11-01' }), v({ total: 11300, vencimiento: '2026-11-10' }), v({ total: 11300, vencimiento: '2026-12-01' })]));
""")
    assert o == [True, True, True, False, False, False, False]      # con saldo y vencida; pagada, vence hoy o más adelante: no
    c = _js("pages", "gastos", "compras.js")
    assert '''<b :style="vencida(ver)?'color:var(--danger)':''">{{fecha(ver.vencimiento)}}</b>''' in c and '@click.stop="ver=row.compra"' in c


# ------------------------------------------------------------------------------------------------ P4 · los recibos de pago (tipo 10)
RECIBO_FUERA = "Los recibos de pago no forman parte del registro de compras y gastos"


def test_p4_los_recibos_de_pago_no_entran_ni_salen_del_registro(api, tmp_path):  # noqa: F811
    """Un recibo electrónico de pago recibido (tipo 10) nunca cuenta en los reportes: quitarlo del registro o registrarlo responde
    409 y no anota nada; y la pantalla no ofrece registrarlo."""
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    _cambiar(rid, tipo_documento="10")
    assert _octubre(c)[0]["egresos_docs"] == 0                      # no cuenta
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 409 and r.json()["detail"] == RECIBO_FUERA, r.text
    assert _recibido(rid).registrado is True and _rects(c) == []
    _cambiar(rid, registrado=False)                                 # (uno que se hubiera quitado antes)
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO})
    assert r.status_code == 409 and r.json()["detail"] == RECIBO_FUERA, r.text
    assert _recibido(rid).registrado is False and _rects(c) == [] and _auditoria(_eid()) == []
    # la factura que se registró desde un recibo sí se puede eliminar de la lista: sale sola, el recibo no se toca y nada se anota
    _cambiar(rid, registrado=True, compra_id=1)
    _alta(c, _compra(1, "2026-10-08", "gasto", recepcion_id=rid, clave=_recibido(rid).clave))
    r = c.post("/api/gastos/compras/1/eliminar", json={})
    assert r.status_code == 200 and r.json()["rectificacion"] is None and r.json()["compras_eliminadas"] == [1], r.text
    assert _compras(c) == {} and _rects(c) == [] and _recibido(rid).registrado is True and _recibido(rid).compra_id is None
    # los demás comprobantes siguen igual
    otro = _aceptado(2, OCTUBRE, "gasto")
    assert c.post(f"/api/recepcion/{otro}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert c.post(f"/api/recepcion/{otro}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO}).status_code == 200
    assert [(x["accion"], x["recibido_id"]) for x in _rects(c)] == [("eliminado", otro), ("registrado", otro)]
    # la pantalla: Recepción no lo muestra como «Aceptado sin registrar» ni ofrece registrarlo, y las listas no lo traen
    o = _node(tmp_path, [("pages", "gastos", "_registro.js")], r"""
import { sinRegistrar, filasRegistro } from './js/pages/gastos/_registro.js';
const rec = (id, tipo_documento, registrado) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento, respuesta: '05', estado_mensaje: 'aceptado', registrado, fecha_emision: '2026-10-08T10:00:00-06:00', total: 1130, impuesto: 130, clasificacion: 'gasto' });
console.log(JSON.stringify({ sin: [sinRegistrar(rec(1, '10', false)), sinRegistrar(rec(2, '01', false)), sinRegistrar(rec(3, '10', true)), sinRegistrar(rec(4, '01', true))],
  filas: filasRegistro('gasto', [], [rec(1, '10', true), rec(2, '01', true)]).map(f => f.id) }));
""", {})
    assert o == {"sin": [False, True, False, False], "filas": ["r2"]}
    rc = _js("pages", "gastos", "recepcion.js")
    assert '<button class="btn sm" v-if="sinRegistrar(row)" @click.stop="abrirRegistrar(row)"' in rc and "respuesta_nombre: sinRegistrar(r) ? 'Aceptado sin registrar' : r.respuesta_nombre" in rc


# ------------------------------------------------------------------------------------------------ P5 · la aceptación parcial (06)
def test_p5_la_rectificacion_de_una_aceptacion_parcial_lleva_lo_que_cuentan_los_reportes(api):  # noqa: F811
    """De un comprobante aceptado parcialmente (06) los reportes cuentan lo aceptado (monto del gasto aplicable) y el IVA a
    acreditar, no el total del documento: la rectificación guarda esos mismos montos."""
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto", respuesta="06")
    total, impuesto = _recibido(rid).total, _recibido(rid).impuesto
    aplicable, acreditar = round(total * 0.4, 2), round(recepcion.iva_recibido(_recibido(rid)) * 0.4, 2)
    assert 0 < aplicable < total and 0 < acreditar < impuesto
    _cambiar(rid, condicion_impuesto="02", monto_gasto_aplicable=aplicable, monto_impuesto_acreditar=acreditar)

    def octubre():
        res, _ = _octubre(c)
        return res["egresos_docs"], res["egresos"]["CRC"], res["iva"]["credito"]["CRC"]
    assert octubre() == (1, aplicable, acreditar)                   # lo que cuentan los reportes
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200, r.text
    rect = r.json()["rectificacion"]
    assert (rect["accion"], rect["mes"], rect["total"], rect["iva_acreditar"], rect["impuesto"]) == ("eliminado", "2026-10", aplicable, acreditar, impuesto)
    assert octubre() == (0, 0, 0)                                   # lo que salió de octubre es justo lo anotado
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO})
    assert r.status_code == 200 and (r.json()["rectificacion"]["total"], r.json()["rectificacion"]["iva_acreditar"]) == (aplicable, acreditar), r.text
    # el cambio de clasificación de ese comprobante lleva los mismos montos
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra"}).status_code == 200
    assert [(x["accion"], x["total"], x["iva_acreditar"]) for x in _rects(c)] == [("eliminado", aplicable, acreditar), ("registrado", aplicable, acreditar), ("reclasificado", aplicable, acreditar)]
    # y el aceptado por completo (05) sigue con el total del documento, aunque traiga otro monto aplicable
    otro = _aceptado(2, OCTUBRE, "gasto")
    _cambiar(otro, monto_gasto_aplicable=1.0)
    r = c.post(f"/api/recepcion/{otro}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200 and r.json()["rectificacion"]["total"] == _recibido(otro).total == total, r.text


# ------------------------------------------------------------------------------------------------ P6 · la factura con FEC en el guardado genérico
def test_p6_borrar_por_el_guardado_generico_una_factura_con_fec_no_anota(api):  # noqa: F811
    """Con factura electrónica de compra emitida lo que cuenta en los reportes es el documento 08, que sigue ahí: borrar la factura
    del registro 'compras' por el guardado genérico (un navegador con la pantalla anterior) no es una rectificación."""
    c = api
    _alta(c, _compra(1, "2026-10-15", "gasto"), _compra(2, "2026-10-16", "compra", fec_id=77, emision="FEC aceptado"), _compra(3, "2026-09-17", "gasto", fec_id=78, emision="FEC aceptado"))
    r = c.post("/api/registros/compras/cambios", json={"upserts": [], "deletes": [1, 2], "nuevos": []})
    assert r.status_code == 200 and list(_compras(c)) == [3], r.text
    assert [(x["accion"], x["compra_id"], x["mes"]) for x in _rects(c)] == [("eliminado", 1, "2026-10")]      # la hecha a mano sí; la de la FEC no
    # el borrado de la lista completa pasa por la misma revisión
    assert c.delete("/api/registros/compras").status_code == 200 and _compras(c) == {}
    assert len(_rects(c)) == 1
    assert [a for a, _ in _auditoria(_eid())] == ["gastos_registro_quitado"]


# ------------------------------------------------------------------------------------------------ P7 · la sincronización trae 'compras'
def test_p7_la_sincronizacion_empieza_con_la_lista_de_compras_al_dia(tmp_path):
    """Con una copia vieja de 'compras' en la pestaña, la sincronización no vería que otro usuario eliminó una factura de un mes
    cerrado (y no haría su reverso), o borraría el ajuste que ya hizo la sincronización de otro: el refresco del inicio la trae."""
    o = _sincronizar(tmp_path, r"""
periodos('Abierto', 'Abierto');
S.datos.compras = [com(1), com(2)];
await sinc(); o.origenes0 = origenes(); o.cerrado1 = lineas('cm:1');
periodos('Cerrado', 'Abierto');
// otro usuario eliminó la factura 1 (de octubre, ya cerrado): el servidor lo tiene; esta pestaña sigue con la lista de antes
const servidor = { compras: [com(2)], gastos_rectificaciones: [{ id: 1, compra_id: 1, origen: 'manual', accion: 'eliminado', mes: '2026-10', fecha: '2026-11-05T09:00:00-06:00' }] };
o.pedidas = [];
mock.refrescar = async claves => { o.pedidas.push(claves); for (const k of claves) if (k in servidor) S.datos[k] = JSON.parse(JSON.stringify(servidor[k])); return claves; };
o.sinc = await sinc(); o.origenes1 = origenes();
o.reverso = asiento('aj:cm:1') ? lineas('aj:cm:1') : null; o.fechaReverso = asiento('aj:cm:1') ? asiento('aj:cm:1').fecha : null;
o.intacto = JSON.stringify(lineas('cm:1')) === JSON.stringify(o.cerrado1);
""")
    assert o["origenes0"] == ["cm:1", "cm:2"]
    assert len(o["pedidas"]) == 1 and "compras" in o["pedidas"][0] and "gastos_rectificaciones" in o["pedidas"][0] and "asientos" in o["pedidas"][0]
    # con la lista al día: el asiento del mes cerrado no se toca y su reverso queda en el mes en curso
    assert o["origenes1"] == ["aj:cm:1", "cm:1", "cm:2"] and o["intacto"] is True
    assert o["reverso"] == _al_reves(o["cerrado1"]) and o["fechaReverso"] == "2026-11-05"
    au = _js("pages", "contabilidad", "automaticos.js")
    assert "await mock.refrescar(['asientos', 'compras', 'pagos_gastos', 'nd_gastos', 'gastos_rectificaciones', 'planillas'," in au


# ------------------------------------------------------------------------------------------------ P8 · la factura de un comprobante rechazado
def test_p8_lo_que_no_cuenta_en_los_reportes_se_ve_atenuado_no_suma_y_no_pide_motivo(api, tmp_path):  # noqa: F811
    """La factura cuyo comprobante se RECHAZÓ (07) sigue en la lista, con el origen «Comprobante rechazado», atenuada y sin sumar en el
    pie; y eliminarla no pide motivo. La pantalla decide con la regla del servidor: con los mismos datos, pide el motivo exactamente
    cuando el servidor lo exige."""
    c = api
    rechazado, aceptado, recibo = _aceptado(1, OCTUBRE, "gasto", respuesta="07"), _aceptado(2, OCTUBRE, "gasto"), _aceptado(3, OCTUBRE, "gasto")
    _cambiar(recibo, tipo_documento="10")                           # un recibo de pago: tampoco cuenta
    clave = lambda rid: _recibido(rid).clave                        # noqa: E731
    _alta(c, _compra(1, "2026-10-08", "gasto", recepcion_id=rechazado, clave=clave(rechazado)), _compra(2, "2026-10-15", "gasto"),
          _compra(3, "2026-10-08", "gasto", recepcion_id=aceptado, clave=clave(aceptado)), _compra(4, "2026-10-08", "gasto", recepcion_id=recibo, clave=clave(recibo)),
          _compra(5, "2026-11-04", "gasto"))
    total, iva = _recibido(aceptado).total, recepcion.iva_recibido(_recibido(aceptado))
    datos = {"compras": c.get("/api/registros/compras").json()["datos"], "recibidos": c.get("/api/recepcion").json()}
    o = _node(tmp_path, [("pages", "gastos", "_registro.js")], "const D = " + json.dumps(datos) + ";\n" + r"""
import { filasRegistro, totalesRegistro, mesRectificacion, notaSinFactura } from './js/pages/gastos/_registro.js';
const filas = filasRegistro('gasto', D.compras, D.recibidos);
const rec = (id, o) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', respuesta: '05', estado_mensaje: 'aceptado', registrado: true, ...o });
const lista = [rec(1), rec(2, { registrado: false }), rec(3, { tipo_documento: '03', referencia_clave: rec(1).clave }), rec(4, { tipo_documento: '03', referencia_clave: rec(2).clave }),
  rec(5, { tipo_documento: '03', referencia_clave: '9'.repeat(50) }), rec(6, { tipo_documento: '03' })];
console.log(JSON.stringify({ filas: filas.map(f => [f.id, f.origenTexto, f.cuenta, f.atenuada, mesRectificacion(f, '2026-11-10'), f.total]), totales: totalesRegistro(filas),
  notas: lista.map(r => notaSinFactura(r, lista)), sinFila: [mesRectificacion(null, '2026-11-10'), mesRectificacion({ fecha: '2026-10-08' }, '2026-11-10')] }));
""", {})
    # la lista: todas a la vista; la del rechazado con su origen, atenuada y sin mes de rectificación (la del recibo de pago tampoco cuenta)
    assert o["filas"] == [[5, "Manual", True, False, None, 11300], [2, "Manual", True, False, "2026-10", 11300], [4, "Electrónica aceptada", False, True, None, total],
                          [3, "Electrónica aceptada", True, False, "2026-10", total], [1, "Comprobante rechazado", False, True, None, 11300]]
    # el pie suma solo lo que cuenta: las dos hechas a mano y la del comprobante aceptado
    assert o["totales"] == [{"moneda": "CRC", "docs": 3, "total": round(22600 + total, 2), "iva": round(2600 + iva, 2), "por_pagar": 33900}]
    assert _octubre(c)[0]["egresos_docs"] == 2                      # los reportes de octubre cuentan lo mismo: la hecha a mano y el aceptado
    # la nota de crédito cuya factura no está en el registro (o no existe): registrarla no es una rectificación
    assert o["notas"] == [False, False, False, True, True, False] and o["sinFila"] == [None, "2026-10"]
    # la misma regla en el servidor: sin motivo responde 400 justo donde la pantalla lo pide, y solo eso queda anotado
    pide = {f[0]: f[4] is not None for f in o["filas"]}
    assert pide == {1: False, 2: True, 3: True, 4: False, 5: False}
    for cid, con_motivo in sorted(pide.items()):
        r = c.post(f"/api/gastos/compras/{cid}/eliminar", json={})
        assert r.status_code == (400 if con_motivo else 200), (cid, r.text)
        if con_motivo:
            r = c.post(f"/api/gastos/compras/{cid}/eliminar", json={"motivo": MOTIVO})
        assert r.status_code == 200 and (r.json()["rectificacion"] is not None) == con_motivo, (cid, r.text)
    assert _compras(c) == {} and [(x["accion"], x.get("compra_id"), x.get("recibido_id")) for x in _rects(c)] == [("eliminado", 2, None), ("eliminado", None, aceptado)]


def test_p8_los_cuadros_de_eliminar_y_de_registrar_deciden_como_el_servidor(tmp_path):
    """Compras/Gastos: eliminar lo que hoy no cuenta solo pide confirmar (no abre el cuadro del motivo ni dice que quedará anotado), una
    por una o en grupo. Recepción: registrar una nota de crédito cuya factura está fuera del registro tampoco pide motivo."""
    o = _node(tmp_path, [("pages", "gastos", "compras.js"), ("pages", "gastos", "recepcion.js"), ("pages", "gastos", "_registro.js")], r"""
import compras from './js/pages/gastos/compras.js';
import recepcion from './js/pages/gastos/recepcion.js';
import { filasRegistro } from './js/pages/gastos/_registro.js';
const rec = (id, o = {}) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', consecutivo: 'C' + id, emisor_nombre: 'Prov ' + id, fecha_emision: '2026-10-08T10:00:00-06:00', moneda: 'CRC',
  total: 1130, impuesto: 130, iva: 130, respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto', registrado: true, ...o });
const com = (id, o = {}) => ({ id, tipo: 'gasto', numero: 'FC-' + id, proveedor: 'Manual ' + id, creacion: '2026-10-15', moneda: 'CRC', total: 11300, pagado: 0, lineas: [{ cantidad: 1, precio_unitario: 10000, descuento: 0, tarifa: 13 }], ...o });
const recibidos = [rec(1, { respuesta: '07' }), rec(2)];
const lista = [com(1, { recepcion_id: 1, clave: rec(1).clave }), com(2), com(3, { creacion: '2026-11-04' }), com(4, { recepcion_id: 1 })];
const filas = filasRegistro('gasto', lista, recibidos), fila = id => filas.find(f => f.id === id);
const preguntas = [], enviados = [], avisos = [];
globalThis.confirm = t => { preguntas.push(t); return true; };
const yo = () => ({ ...compras.methods, tipo: 'gasto', t: { una: 'el gasto' }, rect: null, enviando: false, enviarEliminar(r, motivo) { enviados.push([r.id, motivo]); },
  pedirEliminar: async r => { enviados.push([r.id, 'grupo']); return {}; }, recargar: async () => {} });
const a = yo(); a.eliminar(fila(1));             // la del comprobante rechazado, de octubre: confirmar y listo
const b = yo(); b.eliminar(fila(2));             // la hecha a mano de octubre: el cuadro del motivo
const d = yo(); d.eliminar(fila(3));             // la del mes en curso: la confirmación de siempre
const o = { rechazada: [a.rect, preguntas[0]], manual: [b.rect && [b.rect.accion, b.rect.mes, b.rect.fila.id], preguntas.length], enCurso: [d.rect, preguntas[1]], enviados: enviados.slice() };
enviados.length = 0;
await yo().eliminarVarios(filas);                // en grupo: lo que no cuenta se elimina; lo de un mes pasado que sí cuenta, no
o.enGrupo = enviados.map(x => x[0]).sort();
// Recepción: «Registrar como compra o gasto»
const todos = [rec(1), rec(2, { registrado: false }), rec(3, { registrado: false, tipo_documento: '03', referencia_clave: rec(2).clave }), rec(4, { registrado: false, tipo_documento: '03', referencia_clave: rec(1).clave }),
  rec(5, { registrado: false, fecha_emision: '2026-11-03T10:00:00-06:00' })];
const abrir = r => { const p = { lista: todos, reg: null }; recepcion.methods.abrirRegistrar.call(p, r); return p.reg.mes; };
o.registrar = [abrir(todos[1]), abrir(todos[2]), abrir(todos[3]), abrir(todos[4])];
console.log(JSON.stringify(o));
""")
    assert o["rechazada"] == [None, "¿Eliminar el gasto FC-1 de Manual 1? Hoy no cuenta en los reportes ni en la contabilidad: solo sale de esta lista."]
    assert o["manual"] == [["eliminar", "2026-10", 2], 2]                                          # abre el cuadro del motivo, sin preguntar
    assert o["enCurso"] == [None, "¿Eliminar el gasto FC-3 de Manual 3? Sale de los reportes y de la contabilidad."]
    assert o["enviados"] == [[1, ""], [3, ""]]
    assert o["enGrupo"] == [1, 3, 4]                                                               # las dos del rechazado y la del mes en curso; no la 2 ni el aceptado r2
    # la factura del 2 (fuera del registro) y la del mes en curso no… la nota cuya factura está fuera, tampoco; la nota con su factura registrada, sí
    assert o["registrar"] == ["2026-10", None, "2026-10", None]
    c = _js("pages", "gastos", "compras.js")
    assert "const mes = mesRectificacion(r, hoy());" in c and "pasadas = libres.filter(r => mesRectificacion(r, hoy())), ahora = libres.filter(r => !mesRectificacion(r, hoy()));" in c
    assert "mes: notaSinFactura(r, this.lista) ? null : mesPasado(r.fecha_emision, hoy())," in _js("pages", "gastos", "recepcion.js")
    # atenuada: la tabla común pone la clase a la fila y el estilo la muestra en gris
    assert ':class="{sel: isSel(r), atenuada: r.atenuada === true}"' in _js("components.js")
    assert ".tbl tr.atenuada td,.tbl tr.atenuada td .link{color:var(--muted)}" in (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")


# ------------------------------------------------------------------------------------------------ P9 · la D-104 por moneda
def test_p9_la_d104_por_moneda_no_cuenta_de_mas_la_factura_cubierta_por_un_recibido_en_otra_moneda():
    """En la vista por moneda de la declaración de IVA, si una factura está cubierta por su comprobante recibido se decide con TODOS
    los recibidos; el filtro por moneda va después. Antes, la factura en colones de un recibido en dólares contaba en la vista de
    colones y el recibido en la de dólares: el mismo documento, dos veces."""
    rec = lambda i, **o: {"id": i, "clave": f"{i:050d}", "tipo_documento": "01", "fecha_emision": OCTUBRE, "moneda": "CRC", "tipo_cambio": 1, "total": 1130, "impuesto": 130, "iva": 130,   # noqa: E731
                          "respuesta": "05", "estado_mensaje": "aceptado", "registrado": True, **o}
    recibidos = [rec(1, moneda="USD", tipo_cambio=500, total=113, impuesto=13, iva=13), rec(2), rec(3, moneda="USD", tipo_cambio=500, respuesta="07"), rec(4, moneda="USD", tipo_cambio=500, registrado=False)]
    compras = [_compra(1, "2026-10-15", recepcion_id=1, clave=rec(1)["clave"]),                     # en colones, de un recibido aceptado en dólares: cuenta el recibido
               _compra(2, "2026-10-16"),                                                          # hecha a mano, en colones
               _compra(3, "2026-10-17", moneda="USD", tipo_cambio=500, clave=rec(2)["clave"]),    # en dólares, de un recibido aceptado en colones: cuenta el recibido
               _compra(4, "2026-10-18", moneda="USD", tipo_cambio=500),                           # hecha a mano, en dólares
               _compra(5, "2026-10-19", recepcion_id=3),                                          # en colones, de un comprobante en dólares que se rechazó: no cuenta
               _compra(6, "2026-10-20", recepcion_id=4)]                                          # en colones, de un recibido en dólares fuera del registro: cuenta por sí misma

    def vista(moneda=None):
        filas = {f["codigo"]: f for f in resumen.iva_por_tarifa([], [], recibidos, compras, "2026-10-01", "2026-10-31", 500, moneda)}
        return {k: (f["compras"], f["credito"], f["docs"]) for k, f in filas.items()}
    # colones: las hechas a mano 2 y 6, y el recibido 2; no la factura 1 (la cubre su recibido en dólares) ni la 5
    assert vista("CRC") == {"08": (20000, 2600, 2), "rec": (1000, 130, 1)}
    # dólares: la hecha a mano 4 y el recibido 1; no la factura 3 (la cubre su recibido en colones)
    assert vista("USD") == {"08": (10000, 1300, 1), "rec": (100, 13, 1)}
    # y todo junto, en colones: cada documento una sola vez, lo mismo que suman las dos vistas
    assert vista() == {"08": (20000 + 10000 * 500, 2600 + 1300 * 500, 3), "rec": (1000 + 100 * 500, 130 + 13 * 500, 2)}
    assert [x["compra"]["id"] for x in resumen.compras_manuales(compras, recibidos, "2026-10-01", "2026-10-31")] == [2, 4, 6]


# ------------------------------------------------------------------------------------------------ P10 · de qué comprobante salió una factura
def test_p10_un_solo_criterio_para_saber_de_que_comprobante_salio_una_factura(api, tmp_path):  # noqa: F811
    """Por su recepcion_id o por su clave, en los cuatro lados (listas, servidor, reportes y asientos). El compra_id que anota el
    recibido no vincula por sí solo: esa factura y ese comprobante son dos documentos en todas partes."""
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    _alta(c, _compra(7, "2026-10-08", "gasto"))                     # no guarda recepcion_id ni clave…
    assert c.put(f"/api/recepcion/{rid}/compra", json={"compra_id": 7}).status_code == 200 and _recibido(rid).compra_id == 7   # …pero el recibido la anotó como suya
    total = _recibido(rid).total
    # reportes: los dos cuentan
    assert _octubre(c)[0]["egresos_docs"] == 2
    cuentan = resumen.compras_manuales(list(_compras(c).values()), c.get("/api/recepcion").json(), "2026-10-01", "2026-10-31")
    assert [x["compra"]["id"] for x in cuentan] == [7]
    # listas: dos filas, cada una con lo suyo
    datos = {"compras": list(_compras(c).values()), "recibidos": c.get("/api/recepcion").json()}
    o = _node(tmp_path / "lista", [("pages", "gastos", "_registro.js")], "const D = " + json.dumps(datos) + ";\n" + r"""
import { filasRegistro, totalesRegistro } from './js/pages/gastos/_registro.js';
const filas = filasRegistro('gasto', D.compras, D.recibidos);
console.log(JSON.stringify({ filas: filas.map(f => [f.id, f.origen, f.cid, f.rid, f.total]), docs: totalesRegistro(filas)[0].docs,
  porIdOClave: filasRegistro('gasto', [{ ...D.compras[0], id: 8, recepcion_id: D.recibidos[0].id }, { ...D.compras[0], id: 9, clave: D.recibidos[0].clave }], D.recibidos).map(f => [f.id, f.origen, f.rid]) }));
""", {})
    assert o["filas"] == [[f"r{rid}", "electronica", None, rid, total], [7, "manual", 7, None, 11300]] and o["docs"] == 2
    assert o["porIdOClave"] == [[9, "electronica", rid], [8, "electronica", rid]]                 # por recepcion_id o por clave sí es su factura: una sola fila
    assert "porCompra" not in _js("pages", "gastos", "_registro.js")
    # asientos: uno por documento (cm: de la factura y rec: del comprobante)
    s = _sincronizar(tmp_path / "asientos", r"""
periodos('Abierto', 'Abierto');
S.recibidos = [rec(11, { compra_id: 7 })]; S.datos.compras = [com(7)];
await sinc(); o.origenes = origenes();
""")
    assert s["origenes"] == ["cm:7", "rec:11"]
    # servidor: eliminar el comprobante del registro no se lleva esa factura (sigue en la lista, contando por sí misma)
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200 and r.json()["compras_eliminadas"] == [] and r.json()["rectificacion"]["recibido_id"] == rid, r.text
    assert set(_compras(c)) == {7} and _recibido(rid).registrado is False and _recibido(rid).compra_id is None
    assert _octubre(c)[0]["egresos_docs"] == 1
    # y eliminar la factura es eliminar una factura hecha a mano: pide su motivo y deja SU rectificación
    assert c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO}).status_code == 200
    assert c.post("/api/gastos/compras/7/eliminar", json={}).status_code == 400
    r = c.post("/api/gastos/compras/7/eliminar", json={"motivo": MOTIVO})
    assert r.status_code == 200 and r.json()["rectificacion"]["origen"] == "manual" and r.json()["rectificacion"]["compra_id"] == 7, r.text
    assert _compras(c) == {} and _recibido(rid).registrado is True and _octubre(c)[0]["egresos_docs"] == 1
    assert [(x["accion"], x["origen"]) for x in _rects(c)] == [("eliminado", "electronica"), ("registrado", "electronica"), ("eliminado", "manual")]
    # la factura que sí guarda el recepcion_id (o la clave) sale con su comprobante, como siempre
    _alta(c, _compra(8, "2026-10-08", "gasto", recepcion_id=rid), _compra(9, "2026-10-08", "gasto", clave=_recibido(rid).clave))
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200 and sorted(r.json()["compras_eliminadas"]) == [8, 9] and _compras(c) == {}, r.text


# ------------------------------------------------------------------------------------------------ P11 · tres detalles vistos en el navegador
def test_p11a_el_aviso_de_pendiente_de_envio_va_en_llano(api, monkeypatch):  # noqa: F811
    """Al aceptar un comprobante sin las credenciales de Hacienda el mensaje guardado (el que muestra Recepción) decía «Pendiente de
    envío: HTTPException: 400: Configure usuario…»: ahora va en llano, sin el nombre de la excepción ni el código."""
    c = api
    rid = _aceptado(1, NOVIEMBRE, "gasto")
    nombre = f"mensaje_pulido_{_eid()}_{rid}.xml"                   # el mensaje receptor ya firmado, pendiente de envío
    (recepcion.DIR_RECIBIDOS / nombre).write_bytes("<MensajeReceptor><FechaEmisionDoc>2026-11-10T09:00:00-06:00</FechaEmisionDoc></MensajeReceptor>".encode("utf-8"))
    _cambiar(rid, mensaje_xml_nombre=nombre, consecutivo_receptor="00100001050000000001", estado_mensaje="firmado", mensaje_hacienda=None)

    def enviar():
        r = c.post(f"/api/recepcion/{rid}/enviar")
        assert r.status_code == 200 and r.json()["estado_mensaje"] == "firmado" and r.json()["mensaje_hacienda"] == _recibido(rid).mensaje_hacienda, r.text
        return r.json()["mensaje_hacienda"]
    # la empresa no tiene usuario ni contraseña de Hacienda
    assert enviar() == "Pendiente de envío: falta configurar el usuario de Hacienda en Configuración › Facturación electrónica"
    # otros errores: su texto, sin el nombre de la excepción ni el código
    e = _ctx().empresa
    monkeypatch.setattr(e, "usuario_hacienda", "cpj-3-101-999999@example.test", raising=False)
    monkeypatch.setattr(e, "password_hacienda", "cifrada", raising=False)

    def falla(ex):
        def cliente(_e):
            raise ex
        monkeypatch.setattr(main, "_cliente_hacienda", cliente)
        return enviar()
    avisos = [falla(main.HTTPException(500, "La contraseña de Hacienda no se pudo leer")), falla(ConnectionError("Hacienda no responde")), falla(TimeoutError()), falla(RuntimeError("x" * 900))]
    assert avisos[:3] == ["Pendiente de envío: La contraseña de Hacienda no se pudo leer", "Pendiente de envío: Hacienda no responde", "Pendiente de envío: no se pudo enviar a Hacienda; se reintenta solo"]
    assert avisos[3] == "Pendiente de envío: " + "x" * 200
    assert not any(tecnico in aviso for aviso in avisos for tecnico in ("HTTPException", "500:", "ConnectionError", "TimeoutError", "RuntimeError"))


def test_p11b_el_pdf_de_las_listas_trae_las_fechas_como_en_pantalla(tmp_path):
    """La exportación en PDF de Compras y de Gastos manda cada fecha como se ve en pantalla (día/mes/año), no AAAA-MM-DD. Corre la
    exportación de verdad (compras.js y reportes/_montos.js) con las funciones de fecha y de dinero de api.js tal como están."""
    api_js = _js("api.js")
    formato = api_js[api_js.index("// Formato costarricense: 1.234,56"):api_js.index("// Fecha de HOY en Costa Rica")]      # fmt, SIM, money, fecha y fechaHora de verdad
    assert "export function fecha(iso)" in formato and "export function money(" in formato
    falsos = {**FALSOS, "api.js": formato + "export const S = { cuerpo: null };\nexport const hoy = () => '2026-11-10', toast = () => {}, mock = { get: (k, d) => d, puedeGuardar: () => true }, "
                                            "api = async () => ({}), fmtCant = n => String(n), verDocumento = async () => {}, monedas = { principal: () => ({ codigo: 'CRC' }) };\n"
                                            "export async function abrirArchivo(url, nombre, body) { S.cuerpo = { url, nombre, body }; }\n",
              "pages/pos/_agente.js": "export const porAgente = () => false, imprimirAgente = async () => {};\n", "pages/pos/_datos.js": "export const impresoras = () => [];\n"}
    del falsos["pages/reportes/_montos.js"]
    o = _node(tmp_path, [("pages", "gastos", "compras.js"), ("pages", "gastos", "_registro.js"), ("pages", "reportes", "_montos.js")], r"""
import { S, fecha } from './js/api.js';
import pantalla from './js/pages/gastos/compras.js';
import { filasRegistro } from './js/pages/gastos/_registro.js';
const lista = [{ id: 1, tipo: 'gasto', numero: 'FC-1', proveedor: 'Manual', creacion: '2026-10-15', moneda: 'CRC', total: 11300, pagado: 0, lineas: [{ cantidad: 1, precio_unitario: 10000, descuento: 0, tarifa: 13 }] }];
const recibidos = [{ id: 2, clave: '5'.repeat(50), tipo_documento: '01', consecutivo: 'C2', emisor_nombre: 'Prov', fecha_emision: '2026-10-08T10:00:00-06:00', moneda: 'CRC', total: 1130, impuesto: 130, iva: 130, respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto' }];
const o = {};
for (const tipo of ['gasto', 'compra']) {
  const yo = { lista, hoy: '2026-11-10', t: { archivo: tipo + 's', titulo: tipo }, abrir() {} };
  yo.rows = filasRegistro('gasto', lista, recibidos); yo.columns = pantalla.computed.columns.call(yo);
  const pantallaFecha = yo.rows.map(r => fecha(r.fecha));       // lo que pinta la tabla en la columna «Fecha» (fmt: 'date')
  await pantalla.methods.exportar.call(yo, 'pdf');
  o[tipo] = { url: S.cuerpo.url, pantalla: pantallaFecha, pdf: S.cuerpo.body.filas.map(f => f.fecha), periodo: S.cuerpo.body.periodo, columnas: S.cuerpo.body.columnas.map(c => c.label) };
}
console.log(JSON.stringify(o));
""", falsos)
    for tipo in ("gasto", "compra"):
        x = o[tipo]
        assert x["url"] == "/api/reportes/pdf" and x["columnas"] == ["Fecha", "Número", "Proveedor", "Origen", "Moneda", "Total", "IVA", "Por pagar"]
        assert x["pdf"] == x["pantalla"] == ["15/10/2026", "8/10/2026"] and x["periodo"] == "Al 10/11/2026"
        assert not any("2026-" in f for f in x["pdf"])


def test_p11c_la_factura_de_un_comprobante_aceptado_no_dice_no_electronica(tmp_path):
    """La factura creada desde un comprobante electrónico aceptado se guarda con la emisión «No electrónica» (no tiene factura
    electrónica de compra), pero en la lista nueva su origen es «Electrónica aceptada»: la ventana «Ver» ya no muestra el otro rótulo."""
    o = _node(tmp_path, [("pages", "gastos", "compras.js"), ("pages", "gastos", "_registro.js")], r"""
import pantalla from './js/pages/gastos/compras.js';
import { filasRegistro } from './js/pages/gastos/_registro.js';
const rec = (id, o = {}) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', consecutivo: 'C' + id, emisor_nombre: 'Prov ' + id, fecha_emision: '2026-10-08T10:00:00-06:00', moneda: 'CRC',
  total: 1130, impuesto: 130, iva: 130, respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto', registrado: true, ...o });
const com = (id, o = {}) => ({ id, tipo: 'gasto', numero: 'FC-' + id, proveedor: 'Manual ' + id, creacion: '2026-10-15', moneda: 'CRC', total: 11300, pagado: 0, emision: 'No electrónica', lineas: [], ...o });
const recibidos = [rec(1), rec(2, { respuesta: '07' }), rec(3, { respuesta: null, estado_mensaje: null })];
const lista = [com(1, { recepcion_id: 1, clave: rec(1).clave }), com(2, { recepcion_id: 2 }), com(3, { recepcion_id: 3 }), com(4), com(5, { fec_id: 9, emision: 'FEC aceptado' })];
const rows = filasRegistro('gasto', lista, recibidos);
console.log(JSON.stringify({ origen: rows.map(r => [r.id, r.origenTexto]).sort((a, b) => a[0] - b[0]), ver: lista.map(c => pantalla.methods.emisionDe.call({ rows }, c)),
  textos: rows.map(r => JSON.stringify([r.origenTexto, r.numero, r.proveedor])).filter(t => t.includes('No electr')).length }));
""")
    assert o["origen"] == [[1, "Electrónica aceptada"], [2, "Comprobante rechazado"], [3, "Manual"], [4, "Manual"], [5, "Factura electrónica de compra"]]
    # «Ver»: la del comprobante aceptado y la del rechazado dicen su origen; la hecha a mano (o la de un XML sin aceptar) y la de la FEC, lo de siempre
    assert o["ver"] == ["Electrónica aceptada", "Comprobante rechazado", "No electrónica", "No electrónica", "FEC aceptado"] and o["textos"] == 0
    c = _js("pages", "gastos", "compras.js")
    assert '<Badge :value="emisionDe(ver)"></Badge>' in c and '<Badge :value="ver.emision">' not in c
    assert "ver.emision" not in c and "row.compra.emision" not in c                                # ninguna otra parte de la pantalla pinta ese rótulo
