# -*- coding: utf-8 -*-
"""4.3: clasificación compra (costo de ventas) o gasto en los comprobantes recibidos y compras, con su cuenta contable; impresión de
reportes en la impresora de tiquetes o en la del equipo."""
import pathlib

from app import main, recepcion
from tests.test_375_costeo import _xml_proveedor
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

JS = pathlib.Path(main.__file__).parent / "static" / "js"


def test_clasificacion_al_cargar_y_al_cambiar(api):  # noqa: F811
    c = api
    x = _xml_proveedor(51, "99999999")
    r = c.post("/api/recepcion/cargar", data={"historico": "1", "clasificacion": "compra"}, files=[("archivos", ("a.xml", x, "text/xml"))])
    assert r.status_code == 200 and r.json()["historicos"] == 1, r.text
    rec = c.get("/api/recepcion").json()[0]
    assert rec["clasificacion"] == "compra" and rec["cuenta_contable"] is None
    r = c.put(f"/api/recepcion/{rec['id']}/clasificacion", json={"clasificacion": "gasto", "cuenta_contable": "6.2.02.05 Papelería"})
    assert r.status_code == 200 and r.json()["clasificacion"] == "gasto" and r.json()["cuenta_contable"] == "6.2.02.05 Papelería"
    assert c.put(f"/api/recepcion/{rec['id']}/clasificacion", json={"clasificacion": "otra"}).status_code == 422
    assert main.RespuestaRecepcionIn(mensaje="05", clasificacion="compra").clasificacion == "compra"
    r2 = recepcion.Recibido(empresa_id=1, clave="7" * 50, total=100, impuesto=13, iva=13)
    assert recepcion.marcar_historico(r2, None, False, "gasto") and r2.clasificacion == "gasto"


def test_contabilidad_y_pantallas():
    au = (JS / "pages/contabilidad/automaticos.js").read_text(encoding="utf-8")
    assert "function cuentaCompra(param, x)" in au and "param.compras_costo || param.compras_gastos" in au
    assert au.count("LC(cuentaCompra(param,") == 5            # recibido, NC recibida, compra manual, ND a proveedor (por nd.facturas) y FEC (08) por su compra
    assert "porFec.get(d.id)" in au and "(nd.facturas || []).slice().sort(" in au
    pa = (JS / "pages/contabilidad/parametros.js").read_text(encoding="utf-8")
    import re
    bloque = re.sub(r"//[^\n]*", "", pa[pa.index("export const DEF = {"):pa.index("export const SECCIONES")])
    assert "caja: '1.1.01.01.02 Caja general'" in bloque and "bancos: '1.1.01.02.01.01 Banco Nacional'" in bloque   # las cuentas reales de DEF, sin comentarios
    assert "compras_costo: '5.1.01.01 Costos del inventario'" in pa and "['compras_costo', 'Compras de mercadería para vender (costo de ventas)']" in pa
    rc = (JS / "pages/gastos/recepcion.js").read_text(encoding="utf-8")
    assert "clasificacion: x.mensaje === '07' ? null : x.clasificacion" in rc and "cambiarClasificacion(row" in rc and "const ref = ['02', '03'].includes(r.tipo_documento)" in rc and 'v-model="hist.clasificacion"' in rc
    cf = (JS / "pages/gastos/compra-form.js").read_text(encoding="utf-8")
    assert "f: { tipo: 'compra'," in cf and "tipo: this.f.tipo === 'gasto' ? 'gasto' : 'compra'" in cf
    rp = (JS / "pages/reportes/reporte.js").read_text(encoding="utf-8")
    assert "if (x.clasificacion === 'compra') continue;" in rp and "{ key: 'clas', label: 'Tipo' }" in rp
    from app import resumen
    import inspect
    src = inspect.getsource(resumen)
    assert '"clasificacion": _g(r, "clasificacion") or "gasto"' in src and '"clasificacion": c.get("tipo") or "gasto"' in src


def test_impresion_de_reportes():
    m = (JS / "pages/reportes/_montos.js").read_text(encoding="utf-8")
    for s in ("export function docReporteTermico(", "export function htmlReporte(", "export async function imprimirReporte(datos, impresora, empresa)", "export function impresorasReporte()"):
        assert s in m, s
    assert "⎙ Imprimir" in (JS / "pages/reportes/reporte.js").read_text(encoding="utf-8")
    assert "imprimirZ(ver" in (JS / "pages/pos/cierres.js").read_text(encoding="utf-8")
    assert "imprimir(i)" in (JS / "pages/pos/reportes.js").read_text(encoding="utf-8")


def test_iva_por_moneda():
    from app import resumen
    docs = [{"id": 1, "tipo_documento": "01", "estado": "aceptado", "fecha_emision": "2026-10-05T10:00:00", "moneda": "USD", "tipo_cambio": 500, "condicion_venta": "01"},
            {"id": 2, "tipo_documento": "04", "estado": "aceptado", "fecha_emision": "2026-10-06T10:00:00", "moneda": "CRC", "tipo_cambio": 1, "condicion_venta": "01"}]
    lineas = [{"documento_id": 1, "codigo_tarifa": "08", "tarifa": 13, "total": 113, "impuesto": 13}, {"documento_id": 2, "codigo_tarifa": "08", "tarifa": 13, "total": 11300, "impuesto": 1300}]
    todo = {f["codigo"]: f for f in resumen.iva_por_tarifa(docs, lineas, [], [], "2026-10-01", "2026-10-31", 520)}
    assert todo["08"]["ventas"] == 60000 and todo["08"]["debito"] == 7800            # 100 × 500 + 10 000 y 13 × 500 + 1 300, con el tipo de cambio de cada uno
    usd = {f["codigo"]: f for f in resumen.iva_por_tarifa(docs, lineas, [], [], "2026-10-01", "2026-10-31", 520, "USD")}
    assert usd["08"]["ventas"] == 100 and usd["08"]["debito"] == 13                 # en dólares, sin tipo de cambio
    crc = {f["codigo"]: f for f in resumen.iva_por_tarifa(docs, lineas, [], [], "2026-10-01", "2026-10-31", 520, "CRC")}
    assert crc["08"]["ventas"] == 10000 and crc["08"]["debito"] == 1300
    r = (JS / "pages/reportes/reporte.js").read_text(encoding="utf-8")
    assert "vistaDecl: 'decl'" in r and "'&moneda=' + porMon" in r and 'v-model="vistaDecl"' in r


def test_reclasificar_limpia_la_cuenta(api):  # noqa: F811
    c = api
    x = _xml_proveedor(52, "98989898")
    assert c.post("/api/recepcion/cargar", data={"historico": "1", "clasificacion": "gasto"}, files=[("archivos", ("a.xml", x, "text/xml"))]).json()["historicos"] == 1
    rec = c.get("/api/recepcion").json()[0]
    c.put(f"/api/recepcion/{rec['id']}/clasificacion", json={"clasificacion": "gasto", "cuenta_contable": "6.2.02.05 Papelería"})
    r = c.put(f"/api/recepcion/{rec['id']}/clasificacion", json={"clasificacion": "compra", "cuenta_contable": "6.2.02.05 Papelería"}).json()
    assert r["clasificacion"] == "compra" and r["cuenta_contable"] is None       # la cuenta era de la clasificación anterior


def test_salud_con_reinicio_pendiente_no_revienta():
    from app import salud, version
    viejo = version.EN_EJECUCION
    try:
        version.EN_EJECUCION = "0.1"
        d = salud.estado()
        fila = next(f for f in d["filas"] if f["clave"] == "reinicio")
        assert fila["estado"] == "mal" and d["semaforo"] == "mal"
    finally:
        version.EN_EJECUCION = viejo


def test_validacion_con_error_en_la_respuesta():
    class Cli:
        def consultar(self, clave):
            return {"estado": "aceptado", "status": 200} if "-" not in clave else {"estado": "http_error", "status": 503, "error": "caído"}
    r = recepcion.Recibido(empresa_id=1, clave="8" * 50, total=100, respuesta="05", estado_mensaje="importado", consecutivo_receptor="00100001050000000001")
    v = recepcion.validar_en_hacienda(Cli(), r)
    assert not v["ok"] and "no se pudo consultar la respuesta" in v["texto"]


def test_turno_a_ciegas_no_revela_la_diferencia():
    k = (JS / "pages/pos/caja.js").read_text(encoding="utf-8")
    linea = next(l for l in k.splitlines() if "if (!this.verMontosCaja && !opcionesCierre(this.caja).corte) return toast('Turno entregado" in l)   # 4.41: también según «el cajero ve el corte»
    assert "diferencia ' + money(dif)" not in linea and "'ok');" in linea
    assert k.count('@click="nuevaSalida"') == 2 and k.count("'#/pos/cierres?cerrar=' + caja.id") == 2     # mostrador y restaurante
    assert "import { money, fmt, fecha, hoy, mock, toast } from '../../api.js';" in (JS / "pages/pos/reportes.js").read_text(encoding="utf-8")
    a = (JS / "app.js").read_text(encoding="utf-8")
    assert "if (srv && arch && arch !== srv && arch !== 'desconocida') return reiniciar;" in a
