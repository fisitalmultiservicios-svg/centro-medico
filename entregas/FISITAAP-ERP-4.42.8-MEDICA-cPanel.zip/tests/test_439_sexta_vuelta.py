# -*- coding: utf-8 -*-
"""4.39, sexta vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos (o tres) «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera, cuarta y quinta: destinoDe e impresoraDe reales, la Cocina como
única impresora de comanda y cada comanda anotada).

- W1 abrirPago: después de sus esperas no abre el cobro si «Dividir» está abierto (si era una parte, la devuelve a la cuenta).
- W2 «Dividir → Cobrar estos platos» en la venta rápida (nueva o la cuenta guardada sin mesa): los platos de la parte que no se habían
  enviado salen a cocina al cobrarla, una vez, y la parte no se guarda como cuenta. Una mesa sigue sin comanda al cobrar.
- W3 emitirCobro: el cobro que se cierra (o se está cerrando) mientras se espera el turno (cobroPermitido) no se emite.
- W4 cobrarParte: si «Dividir» se cancela o se abre mientras espera la comanda de otro equipo, no parte la cuenta ni abre el cobro.
- W5 confirmarDividir: la revisión de la comanda de otro equipo (V4b) también al separar a una cuenta aparte o pasar a una mesa.
- W6 la marca de otro equipo lleva la hora de su comanda: la espera termina en min(verla + 4 s, comanda + 8 s) y la misma comanda vista
  otra vez al juntar no hace esperar de nuevo; una comanda más nueva sí renueva la marca.
- W7 alDiaCuentaNueva: al renumerar una «Cuenta N» repetida avisa con el nombre nuevo.
- W10 tras el aviso de V4b, volver a abrir «Dividir» junta la cuenta y no repite el aviso.
- W11 V2 (la mesa con el cobro pedido) y V3 (la mesa a la habitación): después de esperar la comanda de otro equipo se junta otra vez; si la
  cuenta cambió o ya no está, no se cobra ni se carga nada.
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la sexta vuelta
deshecha (SEXTA y _caja_sin_sexta de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta) y ahí se ve el defecto que el cambio arregla.
Defecto que quedaba (xfail estricto): pasar platos a una cuenta aparte o a una mesa de una cuenta que otro equipo acaba de cobrar. 4.39
(séptima vuelta): lo arregla D0 y es una prueba normal (abajo).
4.39 (séptima vuelta): X0 quitó lo de W2 (la opción «Cobrar estos platos» solo se ofrece con mesa: era código que nunca corría); su prueba
ahora comprueba eso y que enviarComanda y comandaNumerada quedaron como antes de la sexta vuelta. El aviso de V4b cambió de texto (X6) y la
cuenta que desaparece mientras V2 o V3 esperan va con «cerrada» (X3). Lo de la séptima vuelta se prueba en tests/test_439_septima_vuelta.py.
4.39 (octava vuelta, Y4): en la caja de comercio, separar una cuenta ya guardada trae la lista una vez (test_w5_...). Lo de la octava vuelta se
prueba en tests/test_439_octava_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import _linea, _metodo, _tramo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR, AVISO_DIVIDIR_7, UNO_Y_UNO
from tests.test_439_quinta_vuelta import CASOS_LISTA_F9, DOS_Y_DOS, NO_SALIO_M6, REHECHA
from tests.test_439_quinta_vuelta import _correr as _correr5
from tests.test_439_revision_arreglos import EMITIR, RECLAMAR, SOLTAR, _caja
from tests.test_439_tercera_vuelta import AMBOS, CAMBIO, CAMBIO_HAB, RECIENTE, SEXTA, _caja_sin_septima, _caja_sin_sexta

# los métodos que cambió la sexta vuelta (cada tripleta de SEXTA está en uno de ellos)
CAMBIADOS = ("enviarComanda() {", "comandaNumerada(modo,", "async cobrarParte(n) {", "async confirmarDividir() {", "persistirCuenta(devolverId) {",
             "fusionarAbierta(motivo) {", "async alDiaCuentaNueva(id) {", "async reclamarHab() {", "async abrirPago() {", "async emitirCobro(otra) {")
COBRADA = "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."
CERRADA_M6 = "La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo"   # 4.39 (séptima vuelta, X3): el aviso de sincronizar
RENUMERADA = "Ya había otra «{0}» abierta: lo que agregó quedó en «{1}»."
DOS_CASADOS, DOS_POSTRES, CASADO1, POSTRE1 = ["Casado×2"], ["Postre×2"], ["Casado×1"], ["Postre×1"]
MESA6 = [["Mesa 6", AMBOS, None]]


def _antes(cabezas=CAMBIADOS):
    """Los métodos que cambió la sexta vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_sexta()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
const M7 = { id: 7, nombre: 'Mesa 7' };
// la Mesa 7 está libre (cuentaDeMesa de _datos.js no viene en el arnés: pasar platos a una mesa crea su cuenta)
globalThis.cuentaDeMesa = () => null;
// cuántas veces ESE equipo guarda la cuenta mientras tiene una parte en cobro (persistirCuenta con cobroParcial)
const deParte = vm => { const o = { n: 0 }, p0 = vm.persistirCuenta; vm.persistirCuenta = function (...x) { if (this.cobroParcial) o.n++; return p0.apply(this, x); }; return o; };
// cuánto tarda una promesa (ms)
const cuanto = async p => { const t0 = Date.now(); await p; return Date.now() - t0; };
// las marcas de envío de la cuenta `id` en el servidor pasan a `hace` ms atrás (o a un texto que no es una fecha), como si la comanda de otro
// equipo fuera de entonces
const marcarEnServidor = (id, hace) => { const c = S.items.find(x => x.id === id); for (const l of c.lineas) if (l.enviado) l.enviado = typeof hace === 'string' ? hace : new Date(Date.now() - hace).toISOString(); S.version++; };
// otro equipo manda a cocina ese plato de la cuenta `id` (en el servidor): su marca de envío es de hace `hace` ms
const enviarEnServidor = (id, detalle, hace) => { const c = S.items.find(x => x.id === id); for (const l of c.lineas) if (l.detalle === detalle) { l.enviado = new Date(Date.now() - (hace || 0)).toISOString(); l.ronda = (+l.ronda || 0) + 1; } S.version++; };
// lo que está enviado a cocina en cada cuenta del servidor; la marca de otro equipo de ESE equipo
const enviados = () => S.items.map(x => (x.lineas || []).filter(l => l.enviado).map(l => l.detalle + '×' + l.cantidad).sort());
const marca = vm => (vm._marcaAjena ? { id: vm._marcaAjena.id, t: vm._marcaAjena.t, env: vm._marcaAjena.env === undefined ? null : vm._marcaAjena.env } : null);
"""


def _correr(tmp_path, casos, antes=()):
    return _correr5(tmp_path, AYUDAS + casos, antes=antes)   # CAMBIO, CAMBIO_HAB, AVISO_COBRADA y AVISO_DIVIDIR ya están en las ayudas del arnés


# ================================================================================================================ W1: abrirPago con «Dividir»
CASOS_W1 = r"""
// (lista) la Mesa 6 con Casado y Postre sin enviar, solo en A. Se toca «Dividir» (la lista tarda: abrirDividir espera alDiaParaCobrar) y
// enseguida «Cobrar» (abrirPago también espera la lista). Después, si «Dividir» quedó abierto, «Cobrar estos platos» con el Casado; si quedó una
// ventana de cobro, «Cobrar». 4.39 (séptima vuelta): en la Mesa 6 (era la cuenta guardada sin mesa): «Cobrar estos platos» solo se ofrece con mesa
{ const [id, a] = await mesaGuardada([CASADO(), POSTRE()]);
  const suelta = lento(a, 400);
  const pd = a.abrirDividir(); await espera(60); const pp = a.abrirPago(); await pd; await pp; suelta(); const tras = est(a);
  if (a.dividir) { a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1 }; await a.confirmarDividir(); await conPago(a); }
  const parte = est(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.lista = { tras, parte, fin: est(a), hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre() }; }
// (parte) simulado: «Cobrar parte 1 de 2» (la Mesa 6) ya partió la cuenta y su ventana de cobro se está abriendo (abrirPago espera
// cobroPermitido, lento); en ese momento aparece «Dividir» (abrirDividir no abre con una parte: como el F9 de antes de la quinta vuelta). La
// parte vuelve a la cuenta. Después se cierra «Dividir» y se cobra la cuenta entera
{ const [id, a] = await mesaGuardada([CASADO(), POSTRE()]);
  const cp0 = a.cobroPermitido; let n = 0; a.cobroPermitido = async acc => { if (++n === 2) await espera(200); return cp0(acc); };
  const pp = a.cobrarParte(2); await hasta(() => !!a.cobroParcial); const medio = est(a);
  a.dividir = { modo: 'articulos', partes: 2, destino: 'nueva', sel: {} }; await espera(300); await pp; await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  a.cobroPermitido = cp0; const tras = est(a), s1 = srv();
  a.dividir = null; a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.parte = { medio, tras, s1, fin: est(a), hechos: cobrados(a), srv: srv(), orden: orden(a.nEq), libre: libre() }; }
"""


def test_w1_el_cobro_no_se_abre_debajo_de_dividir_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W1)
    x = r["lista"]
    # solo «Dividir» queda abierto; «Cobrar estos platos» cobra el Casado una vez y el Postre queda en la cuenta. 4.39 (séptima vuelta): en la
    # Mesa 6, que no manda comanda al cobrar (W2, la comanda de la parte de la venta rápida, se quitó: esa opción no existe sin mesa)
    assert x["tras"]["dividir"] is True and x["tras"]["pago"] is False and x["tras"]["parcial"] is False and x["tras"]["platos"] == AMBOS, x
    assert x["parte"]["parcial"] is True and x["parte"]["pago"] is True and x["parte"]["platos"] == CASADO1, x
    assert x["hechos"] == [["A", CASADO1]] and x["impresos"] == [] and x["srv"] == [["Mesa 6", POSTRE1, None]] and x["libre"] is True, x
    p = r["parte"]
    # la parte vuelve a la cuenta: ni ventana de cobro ni parte colgada, la cuenta del servidor entera; después se cobra una vez, entera
    assert p["medio"]["parcial"] is True and p["medio"]["pago"] is False, p
    assert p["tras"] == {**p["tras"], "pago": False, "parcial": False, "dividir": True, "platos": AMBOS} and p["s1"] == MESA6, p
    assert p["hechos"] == [["A", AMBOS]] and p["srv"] == [] and p["libre"] is True, p
    assert p["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, EMITIR, SOLTAR, SOLTAR], p                      # la consulta de Cancelar y el cobro

    # abrirPago de antes: quedaban abiertas las dos ventanas («Dividir» y el cobro completo, o el de la parte)
    v = _correr(tmp_path / "antes", CASOS_W1, antes=_antes())
    assert v["lista"]["tras"]["dividir"] is True and v["lista"]["tras"]["pago"] is True, v["lista"]
    assert v["parte"]["tras"]["dividir"] is True and v["parte"]["tras"]["pago"] is True and v["parte"]["tras"]["parcial"] is True, v["parte"]
    # el caso de la quinta vuelta (la Mesa 6, F9 mientras «Dividir» espera la lista): «Cobrar» cobraba la cuenta entera en vez de la mitad
    f = _correr(tmp_path / "f9", CASOS_LISTA_F9, antes=_antes())["r"]
    assert f["tras"]["pago"] is True and f["tras"]["dividir"] is True and f["hechos"] == [["A", DOS_Y_DOS]], f


# ================================================================================================================ W2: la parte de la venta rápida
# 4.39 (séptima vuelta, X0): W2 se quitó. «Dividir → Cobrar estos platos» solo se ofrece con una mesa abierta (la plantilla), así que la parte
# de la venta rápida nunca llegaba al cobro y su comanda era código que no corría. Ahora se comprueba eso, que enviarComanda y comandaNumerada
# quedaron como antes de la sexta vuelta (byte a byte) y que en una mesa «Cobrar estos platos» sigue sin mandar comanda al cobrar
CASOS_W2_MESA = r"""
// la Mesa 6 con 2 Casados y 2 Postres sin enviar: «Dividir → Cobrar estos platos» con los 2 Casados y se cobra la parte; después, desde el plano,
// se cobra lo que quedó
{ const [id0, a] = await mesaGuardada([{ ...CASADO(), cantidad: 2 }, { ...POSTRE(), cantidad: 2 }]); const dp = deParte(a);
  await a.abrirDividir(); a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 2 }; await a.confirmarDividir(); await conPago(a);
  const parte = { ...est(a), rapida: !!(a.cobroParcial && a.cobroParcial.rapida) };
  await a.cobrar(); await hastaLibre(); await espera(50); await a.A.mock.guardarTodo();
  const uno = { hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre() };
  await a.sincronizar(); a.abrirMesa(M6); a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.mesa = { parte, guardadoDeParte: dp.n, uno, dos: { hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre(), fin: est(a) } }; }
"""


def test_w2_cobrar_estos_platos_solo_con_mesa_y_las_comandas_como_antes():
    k, k0 = _caja(), _caja_sin_sexta()
    # la opción «Cobrar ahora solo estos platos» de «Dividir» solo existe con una mesa abierta en una caja de restaurante; «Dividir» se abre con
    # «Una cuenta aparte» elegida y ninguna otra parte del código elige «cobrar» por su cuenta
    tpl = _tramo(k, "  template: `", "\n  setup()")
    assert tpl.count('<option value="cobrar" v-if="esRestaurante && mesaActual">') == 1 and tpl.count('value="cobrar"') == 1
    assert "this.dividir = { modo: 'articulos', partes: 2, destino: 'nueva', sel: {} };" in _linea(k, "async abrirDividir() {")
    assert "destino = 'cobrar'" not in k and "destino: 'cobrar'" not in k
    # lo de W2 ya no está: ni la marca de la parte de la venta rápida ni su comanda al cobrarla
    assert "rapida0" not in k and "cobroParcial.rapida" not in k and "{ rapida: true }" not in k
    # enviarComanda y comandaNumerada, byte a byte como antes de la sexta vuelta (la guarda !this.cobroParcial se fue con W2)
    for c in ("enviarComanda() {", "comandaNumerada(modo,"):
        assert _metodo(k, c) == _metodo(k0, c), c
        assert "!this.cobroParcial" not in _metodo(k, c), c


def test_w2_en_una_mesa_cobrar_estos_platos_no_manda_comanda_en_node(tmp_path):
    m = _correr(tmp_path, CASOS_W2_MESA)["mesa"]
    # la parte no lleva marca ni se guarda como cuenta; al cobrarla no sale comanda (como siempre en una mesa) y el Postre queda en la mesa
    assert m["parte"]["rapida"] is False and m["parte"]["parcial"] is True and m["parte"]["platos"] == DOS_CASADOS and m["guardadoDeParte"] == 0, m
    assert m["uno"]["hechos"] == [["A", DOS_CASADOS]] and m["uno"]["impresos"] == [] and m["uno"]["srv"] == [["Mesa 6", DOS_POSTRES, None]] and m["uno"]["libre"] is True, m
    # lo que quedó se cobra una vez y la mesa queda libre
    assert m["dos"]["hechos"] == [["A", DOS_CASADOS], ["A", DOS_POSTRES]] and m["dos"]["impresos"] == [] and m["dos"]["srv"] == [] and m["dos"]["libre"] is True, m


# ================================================================================================================ W3: Cancelar mientras se espera el turno
CASOS_W3 = r"""
// «Cobrar parte 1 de 2» (la Mesa 6 o la cuenta guardada sin mesa, con Casado y Postre); con su ventana abierta, «Cobrar» espera el turno
// (cobroPermitido, lento: 300 ms) y la cajera toca «Cancelar» a los 50 ms. La consulta de Cancelar al servidor también tarda (400 ms): el turno
// llega con la parte todavía cerrándose. Después se cobra la cuenta entera
async function w3(como) {
  let id, a;
  if (como === 'mesa') [id, a] = await mesaGuardada([CASADO(), POSTRE()]); else { id = await guardada([CASADO(), POSTRE()]); a = await abierta(id); }
  await a.cobrarParte(2); await conPago(a); await a.A.mock.guardarTodo(); const parte = est(a);
  const cp0 = a.cobroPermitido; a.cobroPermitido = async acc => { if (acc === 'cobrar') await espera(300); return cp0(acc); };
  C.reclamoLento = 400;
  let error = null; const pc = a.cobrar().catch(e => { error = String((e && e.message) || e); }); await espera(50); const pz = a.cerrarPago(); await pc; await pz;
  await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  C.reclamoLento = 0; a.cobroPermitido = cp0;
  const tras = { ...est(a), error, hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre() };
  a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { parte, tras, fin: est(a), hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre() };
}
for (const como of ['mesa', 'guardada']) out[como] = await w3(como);
"""


def test_w3_cancelar_mientras_se_espera_el_turno_no_emite_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W3)
    for como, nombre in (("mesa", "Mesa 6"), ("guardada", "Cuenta 1")):
        x = r[como]
        t = x["tras"]
        # nada se emite, la parte vuelve a la cuenta, ni «cobrando» ni el cobro en curso quedan puestos
        assert x["parte"]["parcial"] is True and x["parte"]["platos"] == ["Casado×0.5", "Postre×0.5"], (como, x)
        assert t["error"] is None and t["hechos"] == [] and t["pago"] is False and t["parcial"] is False and t["cobrando"] is False and t["enCurso"] is False, (como, x)
        assert t["platos"] == AMBOS and t["srv"] == [[nombre, AMBOS, None]] and t["libre"] is True and t["impresos"] == [], (como, x)
        # después se cobra normal una vez (la cuenta guardada sin mesa, con su comanda)
        assert x["hechos"] == [["A", AMBOS]] and x["srv"] == [] and x["libre"] is True and x["fin"]["cobrando"] is False, (como, x)
        assert x["impresos"] == ([] if como == "mesa" else [AMBOS]), (como, x)

    # emitirCobro de antes: siguió con el cobro que se estaba cerrando y, cuando la parte volvió, emitió la cuenta ENTERA
    v = _correr(tmp_path / "antes", CASOS_W3, antes=_antes())
    for como in ("mesa", "guardada"):
        assert v[como]["tras"]["hechos"] == [["A", AMBOS]], (como, v[como])


# ================================================================================================================ W4: «Cobrar parte» y «Dividir»
CASOS_W4 = r"""
// la Mesa 6 con 2 Casados y 2 Postres sin enviar, abierta en A y en B. B toca «Comanda» (su revisión, lenta: 1,5 s) y, en cuanto su guardado
// llegó al servidor, A pide la parte 1 de 2: espera la comanda de B (la marca). Mientras espera (a los 800 ms):
//  cancela: A tenía «Dividir» abierto y eligió 2 partes iguales (confirmarDividir → cobrarParte) y ahora cancela «Dividir»
//  abre: A tocó el botón «Cobrar parte» y ahora abre «Dividir»
async function w4(como) {
  const [id, a, b] = await mesaGuardada(DOS_Y_DOS());
  if (como === 'cancela') await a.abrirDividir();
  const suelta = lento(b, 1500);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  const t0 = Date.now();
  let pp; if (como === 'cancela') { a.dividir.modo = 'partes'; a.dividir.partes = 2; pp = a.confirmarDividir(); } else pp = a.cobrarParte(2);
  await espera(800); const medio = est(a);
  if (como === 'cancela') a.dividir = null; else await a.abrirDividir();
  await pp; const ms = Date.now() - t0; await espera(100); const tras = { ...est(a), srv: srv() };
  await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { ms, medio, tras, marca: !!a._marcaAjena && a._marcaAjena.id === id, impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), srv: srv(), enviados: enviados(), libre: libre(), orden: orden(a.nEq) };
}
for (const como of ['cancela', 'abre']) out[como] = await w4(como);
"""


def test_w4_cobrar_parte_no_sigue_si_dividir_cambia_mientras_espera_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W4)
    for como in ("cancela", "abre"):
        x = r[como]
        # deja de esperar en el tramo siguiente: no parte la cuenta ni abre el cobro; «Dividir» queda como lo dejó la cajera
        assert x["ms"] < 2000 and x["medio"]["parcial"] is False and x["marca"] is True, (como, x)
        assert x["tras"] == {**x["tras"], "pago": False, "parcial": False, "dividir": como == "abre", "platos": DOS_Y_DOS, "srv": [["Mesa 6", DOS_Y_DOS, None]]}, (como, x)
        # la comanda de B sale una vez, completa; nada se cobró ni se pidió al servidor
        assert x["impresos"] == [["B", DOS_Y_DOS]] and x["noSalioB"] == [] and x["hechos"] == [] and x["orden"] == [] and x["libre"] is True, (como, x)
        assert x["srv"] == [["Mesa 6", DOS_Y_DOS, None]] and x["enviados"] == [DOS_Y_DOS], (como, x)

    # cobrarParte de antes: esperaba los 4 s sin mirar «Dividir» y después partía la cuenta y abría el cobro de la parte (la cajera había
    # cancelado «Dividir», o lo había abierto y el cobro lo reemplazaba)
    v = _correr(tmp_path / "antes", CASOS_W4, antes=_antes())
    for como in ("cancela", "abre"):
        x = v[como]
        assert x["ms"] >= 3500 and x["tras"]["parcial"] is True and x["tras"]["pago"] is True and x["tras"]["dividir"] is False, (como, x)
        assert x["srv"] == [["Mesa 6", UNO_Y_UNO, {"total": 2, "cobradas": 0}]], (como, x)


# ================================================================================================================ W5 y W10: separar y pasar a una mesa
CASOS_W5 = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B; A tiene «Dividir» abierto. B toca «Comanda» (su revisión, lenta: 1,5 s) y, en
// cuanto su guardado llegó al servidor, A pasa el Casado a una cuenta aparte (nueva) o a la Mesa 7 (7). Si salió el aviso, la cajera espera
// unos segundos (3,1 s después de la comanda de B) y vuelve a pasarlo
async function w5(destino) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await a.abrirDividir();
  const suelta = lento(b, 1500), lis = listas(a);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  const t0 = Date.now();
  a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir();
  const primero = { ms: Date.now() - t0, consultas: lis.n, dividir: !!a.dividir, platos: detalles(a), avisos: avisosDividir(a), srv: srv() };   // 4.39 (séptima vuelta): con el texto de ahora o el de antes
  await pb; suelta(); await b.A.mock.guardarTodo(); const deB = { impresos: quienes(a), noSalioB: noSalio(b), comandasB: comandas(b) };
  let segundo = null;
  if (primero.avisos.length) {
    await espera(3100); const t1 = Date.now(); await a.abrirDividir(); const abierto = !!a.dividir; a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir();
    segundo = { ms: Date.now() - t1, abierto, dividir: !!a.dividir, platos: detalles(a) };
  }
  await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { primero, deB, segundo, avisos: avisosDividir(a), cambio: avisos(a).filter(t => t.startsWith('La cuenta de ')), impresos: quienes(a), srv: srv(), enviados: enviados() };
}
// sin otro equipo: A pasa el Casado; con los platos sin enviar o ya enviados hace un minuto (`enviados`)
async function w5solo(destino, enviados) {
  const [id, a] = await mesaGuardada(enviados ? [{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, { ...POSTRE(), enviado: VIEJA(), ronda: 1 }] : [CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await a.abrirDividir(); const lis = listas(a), t0 = Date.now();
  a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir();
  const ms = Date.now() - t0; await a.A.mock.guardarTodo();
  return { ms, consultas: lis.n, dividir: !!a.dividir, platos: detalles(a), avisos: avisos(a).filter(t => !t.startsWith('Platos pasados a ')), pasados: avisos(a).filter(t => t.startsWith('Platos pasados a ')), srv: srv(), impresos: impresos() };
}
// caja de comercio (sin comanda ni revisión): la cuenta guardada con Casado y Postre; se separa el Casado o se cobra solo
async function comercio(destino) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id); a.esRestaurante = false;
  await a.abrirDividir(); const lis = listas(a), t0 = Date.now();
  a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir(); if (destino === 'cobrar') await conPago(a);
  const ms = Date.now() - t0, parcial = !!a.cobroParcial, pago = !!a.pago, platos = detalles(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { lento: ms > 1000, consultas: lis.n, parcial, pago, platos, hechos: hechos().map(h => h[2]), impresos: impresos(), srv: srv(), avisos: avisos(a), orden: orden(a.nEq) };
}
for (const destino of ['nueva', 7]) {
  out['otro_' + destino] = await w5(destino);
  out['solo_' + destino] = await w5solo(destino, false);
  out['enviados_' + destino] = await w5solo(destino, true);
}
for (const destino of ['nueva', 'cobrar']) out['comercio_' + destino] = await comercio(destino);
"""
APARTE = {"nueva": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "7": [["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]]}


def test_w5_separar_y_pasar_a_una_mesa_esperan_la_comanda_de_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W5)
    for destino in ("nueva", "7"):
        x = r["otro_" + destino]
        p = x["primero"]
        # justo después de la «Comanda» de B: el aviso, «Dividir» cerrado y nada partido (en pantalla y en el servidor); una consulta, sin esperar
        # 4.39 (séptima vuelta, X6): con el texto nuevo del aviso
        assert p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["platos"] == AMBOS and p["srv"] == MESA6 and p["consultas"] == 1 and p["ms"] < 2500, (destino, x)
        # la comanda de B sale completa, una vez
        assert x["deB"] == {"impresos": [["B", AMBOS]], "noSalioB": [], "comandasB": ["Comanda 1 enviada a Cocina"]}, (destino, x)
        # unos segundos después se pasa bien, sin otro aviso: el Casado pasa ya enviado (salió en la comanda de B)
        s = x["segundo"]
        assert s["abierto"] is True and s["dividir"] is False and s["platos"] == POSTRE1 and s["ms"] < 1500, (destino, x)
        assert x["avisos"] == [AVISO_DIVIDIR_7] and x["cambio"] == [] and x["impresos"] == [["B", AMBOS]] and x["srv"] == APARTE[destino], (destino, x)
        assert x["enviados"] == [POSTRE1, CASADO1], (destino, x)
        # sin otro equipo: una consulta (la revisión) y sin esperar. 4.39 (séptima vuelta, X6 y D0): con todo enviado también una consulta (la
        # cuenta ya guardada trae la lista: si otro equipo la cobró, sus platos no se pasan a otra), sin esperar
        s1, s2 = r["solo_" + destino], r["enviados_" + destino]
        assert s1["consultas"] == 1 and s1["ms"] < 1500 and s1["avisos"] == [] and len(s1["pasados"]) == 1 and s1["srv"] == APARTE[destino] and s1["impresos"] == [], (destino, s1)
        assert s2["consultas"] == 1 and s2["ms"] < 1500 and s2["avisos"] == [] and len(s2["pasados"]) == 1 and s2["srv"] == APARTE[destino], (destino, s2)

    # confirmarDividir de antes: pasaba el Casado enseguida (otro id: la revisión de B ya no lo encontraba); la comanda de B salía sin el Casado,
    # con «No salió en la comanda: Casado…», y el Casado quedaba sin enviar en la otra cuenta. Sin consulta
    v = _correr(tmp_path / "antes", CASOS_W5, antes=_antes())
    for destino in ("nueva", "7"):
        x = v["otro_" + destino]
        assert x["primero"]["avisos"] == [] and x["primero"]["consultas"] == 0 and x["primero"]["platos"] == POSTRE1, (destino, x)
        assert x["deB"]["impresos"] == [["B", POSTRE1]] and x["deB"]["noSalioB"] == [NO_SALIO_M6] and x["segundo"] is None, (destino, x)
        assert x["srv"] == APARTE[destino] and x["enviados"] == [POSTRE1, []], (destino, x)
        assert v["solo_" + destino]["consultas"] == 0, (destino, v["solo_" + destino])
    # la caja de comercio: igual que antes (sin espera). 4.39 (octava vuelta, Y4): al separar una cuenta ya guardada se trae la lista una vez (1,5 s
    # como mucho: si otro equipo la cobró o la cambió, no se separa); «Cobrar estos platos» sigue sin consulta. Lo demás, igual que antes
    for destino, consultas in (("nueva", 1), ("cobrar", 0)):
        x, y = r["comercio_" + destino], v["comercio_" + destino]
        assert {**x, "consultas": 0} == y and x["consultas"] == consultas and y["consultas"] == 0 and x["lento"] is False, (destino, x, y)
    assert r["comercio_nueva"]["srv"] == [["Cuenta 1", POSTRE1, None], ["Cuenta 1 · aparte", CASADO1, None]] and r["comercio_cobrar"]["hechos"] == [CASADO1], r


CASOS_W10 = r"""
// la Mesa 6 con Casado y Postre sin enviar en A y en B; A tiene «Dividir» abierto. B toca «Comanda» (revisión lenta: 1,5 s) y A elige el
// Casado para `destino` («cobrar»: cobrar estos platos; «nueva»: una cuenta aparte; 7: la Mesa 7): el aviso. La cajera vuelve a abrir
// «Dividir» ENSEGUIDA (B todavía revisa su comanda), elige lo mismo y, si se abre el cobro de la parte, cobra
async function w10(destino) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await a.abrirDividir();
  const suelta = lento(b, 1500);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir();
  const primero = { dividir: !!a.dividir, avisos: avisosDividir(a), alDia: a._alDia };   // 4.39 (séptima vuelta): con el texto de ahora o el de antes
  const lis = listas(a), t1 = Date.now(); await a.abrirDividir(); const abierto = { dividir: !!a.dividir, consultas: lis.n, platos: detalles(a), sinEnviar: a.lineas.filter(l => !l.enviado).length };
  if (a.dividir) { a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir(); }
  if (destino === 'cobrar') await conPago(a);
  const ms = Date.now() - t1, dividir = !!a.dividir;
  if (a.pago) await a.cobrar();
  await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { primero, abierto, ms, dividir, platos: detalles(a), avisos: avisosDividir(a), cambio: avisos(a).filter(t => t.startsWith('La cuenta de ')),
    impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), srv: srv(), enviados: enviados(), libre: libre() };
}
for (const destino of @DESTINOS@) out['w10_' + destino] = await w10(destino);
"""


def test_w10_volver_a_dividir_tras_el_aviso_junta_y_no_lo_repite_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W10.replace("@DESTINOS@", json.dumps(["cobrar", "nueva", 7])))
    for destino in ("cobrar", "nueva", "7"):
        x = r["w10_" + destino]
        # tras el aviso, la próxima apertura de «Dividir» junta la cuenta (una consulta): los platos ya llegan enviados
        # 4.39 (séptima vuelta, X6): con el texto nuevo del aviso; X2: después de esperar la marca la cuenta no cambió, así que se divide
        assert x["primero"] == {"dividir": False, "avisos": [AVISO_DIVIDIR_7], "alDia": 0}, (destino, x)
        assert x["abierto"] == {"dividir": True, "consultas": 1, "platos": AMBOS, "sinEnviar": 0}, (destino, x)
        # elegir lo mismo no repite el aviso: espera lo que falta de la marca y divide; la comanda de B sale una vez, completa
        assert 2500 <= x["ms"] < 6000 and x["dividir"] is False and x["avisos"] == [AVISO_DIVIDIR_7] and x["cambio"] == [], (destino, x)
        assert x["impresos"] == [["B", AMBOS]] and x["noSalioB"] == [] and x["libre"] is True, (destino, x)
    c = r["w10_cobrar"]
    assert c["hechos"] == [["A", CASADO1]] and c["srv"] == [["Mesa 6", POSTRE1, None]] and c["enviados"] == [POSTRE1], c
    for destino in ("nueva", "7"):
        x = r["w10_" + destino]
        assert x["hechos"] == [] and x["srv"] == APARTE[destino] and x["enviados"] == [POSTRE1, CASADO1], (destino, x)

    # antes de esta vuelta («Cobrar estos platos», la única que avisaba): la apertura siguiente no juntaba (la lista era de hace menos de 3 s),
    # los platos seguían sin enviar en pantalla y el aviso se repetía
    v = _correr(tmp_path / "antes", CASOS_W10.replace("@DESTINOS@", json.dumps(["cobrar"])), antes=_antes())["w10_cobrar"]
    assert v["primero"]["avisos"] == [AVISO_DIVIDIR] and v["abierto"]["sinEnviar"] == 2 and v["abierto"]["consultas"] == 0, v
    assert v["avisos"] == [AVISO_DIVIDIR, AVISO_DIVIDIR] and v["hechos"] == [] and v["srv"] == MESA6, v


# ================================================================================================================ W6: la marca con la hora de la comanda
CASOS_W6 = r"""
// la cuenta guardada sin mesa con Casado y Postre sin enviar, abierta en A y en B. B toca «Comanda» (sale enseguida) y su marca de envío en el
// servidor queda de hace `hace` ms (o un texto que no es una fecha). sinc: A sincroniza (la marca de fusionarAbierta), abre el cobro y cobra;
// bucle: A ya tenía el cobro abierto y cobra (la marca de persistirCuenta, al juntar en el bucle de emitirCobro)
async function w6(via, hace) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  if (via === 'bucle') await a.abrirPago();
  await b.enviarComanda(); await b.A.mock.guardarTodo(); marcarEnServidor(id, hace);
  if (via === 'sinc') { await a.sincronizar(); await a.abrirPago(); }
  const m0 = marca(a), t = await cuanto(a.cobrar()), m1 = marca(a);
  await hastaLibre(); await a.A.mock.guardarTodo();
  return { t, m0, m1, hechos: cobrados(a), impresos: quienes(a), srv: srv(), libre: libre() };
}
for (const hace of [6000, 1000, 'sin fecha']) out[hace] = await w6(@VIA@, hace);
"""


@pytest.mark.parametrize("via", ["sinc", "bucle"])
def test_w6_la_espera_termina_con_la_hora_de_la_comanda_en_node(tmp_path, via):
    casos = CASOS_W6.replace("@VIA@", json.dumps(via))
    r = _correr(tmp_path / "ahora", casos)
    for hace, desde, hasta in (("6000", 1500, 2700), ("1000", 3500, 4900), ("sin fecha", 3500, 4900)):
        x = r[hace]
        # una comanda de hace 6 s: se espera hasta 8 s después de ella (unos 2 s); de hace 1 s, 4 s desde que se vio; sin fecha legible, 4 s
        assert desde <= x["t"] < hasta, (via, hace, x)
        # la comanda de B sale una vez (B) y A cobra una vez, sin otra comanda
        assert x["hechos"] == [["A", AMBOS]] and x["impresos"] == [["B", AMBOS]] and x["srv"] == [] and x["libre"] is True, (via, hace, x)
        m = x["m1"]
        assert m["id"] == 1 and (m["env"] == 0 if hace == "sin fecha" else m["env"] > 0), (via, hace, x)
        assert (m["t"] == m["env"] + 4000) if hace == "6000" else (m["t"] > m["env"]), (via, hace, x)   # t = min(verla, comanda + 4 s)
        assert (x["m0"] == m) if via == "sinc" else (x["m0"] is None), (via, hace, x)                 # sincronizar dejó la marca; el cobro no la renueva

    # antes de esta vuelta: la marca era la hora en que se vio la comanda: siempre 4 s, también con una comanda de hace 6 s
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for hace in ("6000", "1000", "sin fecha"):
        assert 3500 <= v[hace]["t"] < 4900 and v[hace]["m1"]["env"] is None, (via, hace, v[hace])


CASOS_W6_MISMA = r"""
// (parte2) la Mesa 6 con 2 Casados y 2 Postres en A y en B; A tiene «Dividir» abierto. B toca «Comanda» (revisión lenta: 1,5 s); en cuanto su
// guardado llegó al servidor, A elige 2 partes iguales (la parte 1 espera la comanda de B: la lista es de hace menos de 3 s y no se trae otra vez;
// la marca sale de mirar la cuenta en el servidor y después se junta) y la cobra; enseguida vuelve a la mesa y toca «Cobrar parte 2 de 2»
{ const [id, a, b] = await mesaGuardada(DOS_Y_DOS());
  await a.abrirDividir();
  const suelta = lento(b, 1500);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  a.dividir.modo = 'partes'; a.dividir.partes = 2;
  const t1 = await cuanto((async () => { await a.confirmarDividir(); await conPago(a); })()); const m1 = marca(a);
  await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  await a.sincronizar(); a.abrirMesa(M6); a._alDia = 0;
  const t2 = await cuanto((async () => { await a.cobrarParte(2); await conPago(a); })()); const m2 = marca(a), parte2 = est(a);
  if (a.pago) await a.cobrar(); await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  out.parte2 = { t1, t2, m1, m2, parte2, impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), srv: srv(), libre: libre() }; }
// (hab) la Mesa 6 con el Casado sin enviar en A y en B; A abre la ventana de la habitación. B toca «Comanda» (revisión lenta: 1,5 s); A toca
// «Cargar» (espera la comanda de B) y a los 1,5 s cierra la ventana; 3 s después la vuelve a abrir y toca «Cargar» otra vez
{ const [id, a, b] = await mesaGuardada([CASADO()]);
  a.habCargo = HAB();
  const suelta = lento(b, 1500);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  a.comandaHab = () => {}; const p1 = a.cargarAHabitacion(); await espera(1500); a.habCargo = null; await p1; const m1 = marca(a), f1 = folios();
  await pb; suelta(); await espera(3000);
  await a.abrirCargoHab(); const abierta = !!a.habCargo;
  const t2 = await cuanto(cargar(a)); const m2 = marca(a);
  await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  out.hab = { m1, f1, abierta, t2, m2, folios: folios(), impresos: quienes(a), noSalioB: noSalio(b), hechos: hechos().length, srv: srv(), libre: libre(), fin: est(a) }; }
// (renueva) la cuenta guardada sin mesa con Casado y Postre sin enviar en A. En el servidor, otro equipo mandó el Casado hace 6 s: A sincroniza
// (la marca); sincroniza otra vez sin nada nuevo; después otro equipo manda el Postre (ahora): A sincroniza (la marca se renueva) y cobra
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  enviarEnServidor(id, 'Casado', 6000); await a.sincronizar(); const m1 = marca(a);
  await a.sincronizar(); const m1b = marca(a);
  enviarEnServidor(id, 'Postre', 0); await a.sincronizar(); const m2 = marca(a);
  await a.abrirPago(); const t = await cuanto(a.cobrar());
  await hastaLibre(); await a.A.mock.guardarTodo();
  out.renueva = { m1, m1b, m2, t, hechos: cobrados(a), impresos: impresos(), srv: srv(), libre: libre() }; }
"""


def test_w6_la_misma_comanda_no_hace_esperar_otra_vez_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W6_MISMA)
    p = r["parte2"]
    # la parte 1 espera la comanda de B; la parte 2, enseguida después, no vuelve a esperar: al juntar, la misma comanda no renovó la marca
    assert 3500 <= p["t1"] < 6000 and p["t2"] < 1000 and p["m1"] is not None and p["m2"] == p["m1"] and p["parte2"]["parcial"] is True, p
    assert p["impresos"] == [["B", DOS_Y_DOS]] and p["noSalioB"] == [] and p["hechos"] == [["A", UNO_Y_UNO], ["A", UNO_Y_UNO]] and p["srv"] == [] and p["libre"] is True, p
    h = r["hab"]
    # cerrar la ventana durante la espera no carga nada; reabrirla después y «Cargar» no vuelve a esperar (la marca no se renueva): un cargo
    assert h["f1"] == [] and h["m1"] is not None and h["abierta"] is True and h["t2"] < 1500 and h["m2"] == h["m1"], h
    assert h["folios"] == ["Casado (Mesa 6)"] and h["impresos"] == [["B", CASADO1]] and h["noSalioB"] == [] and h["hechos"] == 0 and h["srv"] == [] and h["libre"] is True, h
    n = r["renueva"]
    # la comanda de hace 6 s: t = comanda + 4 s; sincronizar sin nada nuevo no la cambia; una comanda más nueva sí la renueva (4 s desde ahora)
    assert n["m1"]["t"] == n["m1"]["env"] + 4000 and n["m1b"] == n["m1"], n
    assert n["m2"]["env"] > n["m1"]["env"] and n["m2"]["t"] > n["m1"]["t"] and n["m2"]["t"] >= n["m2"]["env"], n
    assert 3500 <= n["t"] < 4900 and n["hechos"] == [["A", AMBOS]] and n["srv"] == [] and n["libre"] is True, n

    # antes de esta vuelta: la marca se renovaba al juntar la misma comanda (la parte 2 esperaba otra vez) y «Cargar» en la ventana reabierta
    # esperaba 4 s otra vez
    v = _correr(tmp_path / "antes", CASOS_W6_MISMA, antes=_antes())
    assert v["parte2"]["t2"] >= 2500 and v["parte2"]["hechos"] == [["A", UNO_Y_UNO], ["A", UNO_Y_UNO]], v["parte2"]
    assert v["hab"]["t2"] >= 3500 and v["hab"]["folios"] == ["Casado (Mesa 6)"], v["hab"]


# ================================================================================================================ W7: el aviso con el nombre nuevo
CASOS_W7 = r"""
// G guarda una cuenta con el Casado («Cuenta 1», «Ana» o la Mesa 6); A la abre (desde «Para llevar en espera», o la mesa) y manda la comanda;
// B la cobra; C hace otra con el Postre y manda su comanda (para C no hay otra abierta: otra «Cuenta 1», «Ana» o «Mesa 6»); A, sin sincronizar,
// agrega la Limonada y toca «Comanda»: el servidor rehace la cuenta de A con otro id. Los avisos de A
async function w7(o) {
  nuevo(); const g = venta(await equipo()); if (o.mesa) g.abrirMesa(M6); if (o.nombre) g.nombreEspera = o.nombre; g.lineas.push(CASADO()); if (o.mesa) g.persistirCuenta(); else g.guardarCuenta(); await g.A.mock.guardarTodo();
  const id1 = S.items[0].id;
  const a = venta(await equipo()), b = venta(await equipo());
  await a.sincronizar(); if (o.mesa) a.abrirMesa(M6); else a.recuperar(a.espera.find(x => x.id === id1));
  await a.enviarComanda(); await a.A.mock.guardarTodo();
  await b.sincronizar(); if (o.mesa) b.abrirMesa(M6); else b.recuperar(b.espera.find(x => x.id === id1)); await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  const c = venta(await equipo()); if (o.mesa) c.abrirMesa(M6); if (o.nombre) c.nombreEspera = o.nombre; c.lineas.push(POSTRE()); await c.enviarComanda(); await c.A.mock.guardarTodo();
  a.lineas.push(LIMONADA()); await a.enviarComanda(); await a.A.mock.guardarTodo(); await a._alDiaNueva; await a.A.mock.guardarTodo();
  return { nombreA: a.nombreEspera, enServidor: nombres(), rehecha: avisos(a).filter(t => t.startsWith('La cuenta de ')), renumerada: avisos(a).filter(t => t.startsWith('Ya había otra ')) };
}
out.automatico = await w7({});
out.propio = await w7({ nombre: 'Ana' });
out.mesa = await w7({ mesa: true });
// (rapida) la venta rápida de A manda la comanda del Casado (queda guardada como «Cuenta 1», sin nombre en pantalla); B la recupera y la cobra; C
// hace otra venta rápida con el Postre y manda su comanda (otra «Cuenta 1»); A, sin sincronizar, agrega la Limonada y toca «Comanda»
{ nuevo(); const a = venta(await equipo()), b = venta(await equipo());
  a.lineas.push(CASADO()); await a.enviarComanda(); await a.A.mock.guardarTodo(); const id1 = a.esperaId;
  await b.sincronizar(); b.recuperar(b.espera.find(x => x.id === id1)); await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  const c = venta(await equipo()); c.lineas.push(POSTRE()); await c.enviarComanda(); await c.A.mock.guardarTodo();
  a.lineas.push(LIMONADA()); await a.enviarComanda(); await a.A.mock.guardarTodo(); await a._alDiaNueva; await a.A.mock.guardarTodo();
  out.rapida = { nombreA: a.nombreEspera, enServidor: nombres(), rehecha: avisos(a).filter(t => t.startsWith('La cuenta de ')), renumerada: avisos(a).filter(t => t.startsWith('Ya había otra ')) }; }
"""


def test_w7_al_renumerar_avisa_con_el_nombre_nuevo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W7)
    for k, nombre in (("automatico", "Cuenta 3"), ("rapida", "")):
        x = r[k]
        # el aviso de seguirIds nombra la cuenta como se llamaba («Cuenta 1»); al renumerarla, otro aviso con el nombre que quedó («Cuenta 3»)
        assert x["enServidor"] == [[2, "Cuenta 1"], [3, "Cuenta 3"]] and x["nombreA"] == nombre, (k, x)
        assert x["rehecha"] == [REHECHA.format("Cuenta 1")] and x["renumerada"] == [RENUMERADA.format("Cuenta 1", "Cuenta 3")], (k, x)
    for k, nombre in (("propio", "Ana"), ("mesa", "Mesa 6")):
        x = r[k]
        # sin renumerar (nombre propio o de una mesa), sin el aviso nuevo
        assert x["enServidor"] == [[2, nombre], [3, nombre]] and x["rehecha"] == [REHECHA.format(nombre)] and x["renumerada"] == [], (k, x)

    # alDiaCuentaNueva de antes: renumeraba en silencio (el único aviso decía que lo agregado quedó en «Cuenta 1»)
    v = _correr(tmp_path / "antes", CASOS_W7, antes=_antes())
    for k in ("automatico", "rapida"):
        assert v[k]["enServidor"] == [[2, "Cuenta 1"], [3, "Cuenta 3"]] and v[k]["rehecha"] == [REHECHA.format("Cuenta 1")] and v[k]["renumerada"] == [], (k, v[k])


# ================================================================================================================ W11: la mesa junta después de esperar
CASOS_W11 = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B. A abre la ventana de cobro (o, con `hab`, la de la habitación). B toca «Comanda»
// (su revisión, lenta: 1,5 s) y, en cuanto su guardado llegó al servidor, A toca «Cobrar» (o «Cargar»): espera la comanda de B. Cuando la
// comanda de B ya salió y A todavía espera, B (`que`): quita el Postre (quita), cierra la cuenta (cierra) o nada (nada). Después, si A quedó con
// la ventana abierta, vuelve a tocar «Cobrar» (o «Cargar»)
async function w11(hab, que) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); HOJAS.length = 0;
  if (hab) { a.habCargo = HAB(); a.comandaHab = (r, ls) => HOJAS.push(ls.map(l => l.detalle + '×' + l.cantidad).sort()); } else await a.abrirPago();
  const suelta = lento(b, 1500);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  const t0 = Date.now(); let fin = 0;
  if (hab) a.habCargo.reserva_id = 1;
  const pa = (hab ? a.cargarAHabitacion() : a.cobrar()).then(() => { fin = Date.now(); });
  await pb; suelta(); await b.A.mock.guardarTodo();
  if (que === 'quita') { b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(); await b.A.mock.guardarTodo(); }
  if (que === 'cierra') { await b.borrarEspera(b.cuentaActual); await b.A.mock.guardarTodo(); }
  const srvB = srv();
  await pa; const t = fin - t0; await hastaLibre(); await a.A.mock.guardarTodo();
  const r = { t, srvB, impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), folios: folios(), avisos: avisos(a).filter(x => x === CAMBIO || x === CAMBIO_HAB || x === AVISO_COBRADA),
    tras: est(a), srv: srv(), libre: libre(), orden: orden(a.nEq), cerradas: cerradas(a), neutro: avisos(a).filter(x => x.startsWith('Aquí no se cobró ni se cargó nada')) };   // 4.39 (séptima vuelta): y los avisos de X3
  if (hab ? a.habCargo : a.pago) {
    if (hab) await cargar(a); else { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
    r.luego = { hechos: cobrados(a), folios: folios(), impresos: quienes(a), srv: srv(), libre: libre(), fin: est(a) };
  }
  return r;
}
for (const que of ['quita', 'cierra', 'nada']) out[que] = await w11(@HAB@, que);
"""


@pytest.mark.parametrize("hab", [False, True])
def test_w11_la_mesa_junta_lo_de_otro_equipo_despues_de_esperar_en_node(tmp_path, hab):
    casos = CASOS_W11.replace("@HAB@", json.dumps(hab))
    r = _correr(tmp_path / "ahora", casos)
    cambio = CAMBIO_HAB if hab else CAMBIO
    for que in ("quita", "cierra", "nada"):
        x = r[que]
        # la comanda de B sale una vez, completa; A esperó y pidió el cobro una vez (y lo soltó)
        assert x["impresos"] == [["B", AMBOS]] and x["noSalioB"] == [] and 3500 <= x["t"] < 7000 and x["libre"] is True, (hab, que, x)
        assert x["orden"][:1] == [RECLAMAR] and x["orden"][-1] == SOLTAR, (hab, que, x)
    q = r["quita"]
    # B quitó el Postre durante la espera: no se cobra ni se carga nada, el cobro pedido queda libre, el aviso, y la ventana sigue abierta con lo
    # que quedó; al tocar otra vez se cobra (o se carga) una vez solo el Casado
    assert q["srvB"] == [["Mesa 6", CASADO1, None]] and q["hechos"] == [] and q["folios"] == [] and q["avisos"] == [cambio], (hab, q)
    assert q["orden"] == [RECLAMAR, SOLTAR] and q["tras"] == {**q["tras"], "pago": not hab, "hab": hab, "platos": CASADO1}, (hab, q)
    lu = q["luego"]
    assert (lu["folios"] == ["Casado (Mesa 6)"] and lu["hechos"] == []) if hab else (lu["hechos"] == [["A", CASADO1]] and lu["folios"] == []), (hab, q)
    assert lu["impresos"] == [["B", AMBOS]] and lu["srv"] == [] and lu["libre"] is True and lu["fin"]["pago"] is False and lu["fin"]["hab"] is False, (hab, q)
    c = r["cierra"]
    # B cerró la cuenta durante la espera: nada emitido ni cargado, sin ventanas abiertas. 4.39 (séptima vuelta, X3): sin el aviso «ya se cobró en
    # otro equipo» (B la borró: no la cobró); solo el de sincronizar, «La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo»
    assert c["srvB"] == [] and c["hechos"] == [] and c["folios"] == [] and c["avisos"] == [] and c["orden"] == [RECLAMAR, SOLTAR], (hab, c)
    assert c["cerradas"] == [CERRADA_M6] and c["neutro"] == [], (hab, c)
    assert c["tras"]["pago"] is False and c["tras"]["hab"] is False and "luego" not in c, (hab, c)
    n = r["nada"]
    # sin cambios: se cobra (o se carga) una vez, entera
    assert n["avisos"] == [] and n["srv"] == [] and "luego" not in n, (hab, n)
    assert (n["folios"] == ["Casado (Mesa 6)", "Postre (Mesa 6)"] and n["hechos"] == []) if hab else (n["hechos"] == [["A", AMBOS]] and n["folios"] == []), (hab, n)

    # antes de esta vuelta: después de esperar se cobraba (o cargaba) lo que había en pantalla: el Postre quitado, o la cuenta ya cerrada
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for que in ("quita", "cierra"):
        x = v[que]
        assert x["avisos"] == [], (hab, que, x)
        assert (x["folios"] == ["Casado (Mesa 6)", "Postre (Mesa 6)"]) if hab else (x["hechos"] == [["A", AMBOS]]), (hab, que, x)


# ================================================================================================================ el defecto que quedaba (D0)
CASOS_CERRADA = r"""
// la Mesa 6 con Casado y Postre sin enviar en A y en B; A abre «Dividir». B cobra la mesa entera (A no sincroniza). A pasa el Casado a `destino`
// («nueva»: una cuenta aparte; 7: la Mesa 7; «cobrar»: cobrar estos platos)
async function cerrada(destino) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await a.abrirDividir();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; await a.confirmarDividir(); await conPago(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await espera(50); await a.A.mock.guardarTodo();
  return { srv: srv(), hechos: cobrados(a), cerrada: avisos(a).filter(t => t.startsWith('La cuenta «Mesa 6» fue cobrada o cerrada')), pasados: avisos(a).filter(t => t.startsWith('Platos pasados a ')), dividir: !!a.dividir };
}
for (const destino of @DESTINOS@) out[destino] = await cerrada(destino);
"""


def test_cobrar_estos_platos_de_una_cuenta_cobrada_en_otro_equipo_no_cobra_en_node(tmp_path):
    """Control del defecto de abajo: con «Cobrar estos platos», la revisión que W5 ya hacía (V4b) trae la lista y la guarda de 4.31 (la cuenta
    guardada que ya no está) no parte ni cobra: B cobró la mesa una vez y A no cobra nada."""
    x = _correr(tmp_path, CASOS_CERRADA.replace("@DESTINOS@", json.dumps(["cobrar"])))["cobrar"]
    assert x["srv"] == [] and x["hechos"] == [["B", AMBOS]] and x["pasados"] == [] and x["dividir"] is False, x


# 4.39 (sexta vuelta): era un defecto real que esa vuelta no cubría (xfail estricto). B cobra la mesa entera mientras A tiene «Dividir» abierto;
# A pasa el Casado a una cuenta aparte o a la Mesa 7: el Casado quedaba en la cuenta nueva («Mesa 6 · aparte» o la Mesa 7) con su precio, por
# cobrar otra vez. 4.39 (séptima vuelta, D0): confirmarDividir ya no separa ni pasa platos de una cuenta guardada que no está en la lista (como
# «Cobrar estos platos» desde la 4.31): dio XPASS y ahora es una prueba normal. Más casos (partir sin mesa, la caja al día y los métodos de antes)
# en tests/test_439_septima_vuelta.py
@pytest.mark.parametrize("destino", ["nueva", 7])
def test_pasar_platos_de_una_cuenta_cobrada_en_otro_equipo_no_deja_cuenta_nueva_en_node(tmp_path, destino):
    x = _correr(tmp_path, CASOS_CERRADA.replace("@DESTINOS@", json.dumps([destino])))[str(destino)]
    assert x["hechos"] == [["B", AMBOS]], x                                                             # B cobró la mesa una vez
    assert x["srv"] == [] and x["pasados"] == [] and x["dividir"] is False, x                           # ninguna cuenta nueva, «Dividir» cerrado
    assert x["cerrada"] == ["La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo"], x               # el aviso de siempre (sincronizar)


# ================================================================================================================ contrato
def test_contrato_de_la_sexta_vuelta():
    # 4.39 (séptima vuelta): «ahora» es caja.js sin la séptima vuelta (la séptima cambió líneas de varios de estos métodos: W2 se fue, V2, V3, V4,
    # V4b y los bucles de la venta rápida); lo de la séptima está en tests/test_439_septima_vuelta.py
    k, k0 = _caja_sin_septima(), _caja_sin_sexta()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de SEXTA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de los métodos cambiados; cada método cambió
    assert len(SEXTA) == 20
    for viejo, nuevo, veces in SEXTA:
        assert k.count(nuevo) == veces and k0.count(viejo) >= veces and k0.count(nuevo) == 0, nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de ellos, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # todo lo de la vuelta lleva su comentario
    assert k.count("4.39 (sexta vuelta)") >= 13 and k0.count("4.39 (sexta vuelta)") == 0 and k.count("Sexta vuelta:") >= 4
    # W6: la marca con la hora de la comanda en las seis revisiones (persistirCuenta, fusionarAbierta, V2, V3, V4 y V4b), sin renovar la misma
    marca = "this._marcaAjena = { id: {0}, t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te };"
    for c, i in (("persistirCuenta(devolverId) {", "id"), ("fusionarAbierta(motivo) {", "this.esperaId"), ("async emitirCobro(otra) {", "esperaId"),
                 ("async reclamarHab() {", "idM"), ("async cobrarParte(n) {", "id0"), ("async confirmarDividir() {", "id1")):
        m = metodos[c]
        assert m.count(marca.replace("{0}", i)) == 1 and m.count("if (!(m1 && m1.id === " + i + " && m1.env >= te)) ") == 1, c
    assert k.count("this._marcaAjena = {") == 6 and "t: Date.now() }" not in k.replace("env: te };", "")
    assert k.count(RECIENTE) == 8                                                                       # como en la quinta vuelta
    e, rh, cp, cd, ap = (metodos[c] for c in ("async emitirCobro(otra) {", "async reclamarHab() {", "async cobrarParte(n) {", "async confirmarDividir() {", "async abrirPago() {"))
    # W1: en abrirPago, después de todas las esperas y antes de armar el cobro
    assert ap.index("await this.cobroPermitido('cobrar')") < ap.index("await this.alDiaParaCobrar();") < ap.index("if (this.habCargo || this.dividir) { if (this.cobroParcial) this.cerrarPago(); return; }") < ap.index("this.pago = { tipo_documento: td,")
    # W3: el cobro abierto se toma antes de esperar el turno y se compara después, antes de «cobrando»
    assert e.index("const pagoAbierto = this.pago;") < e.index("if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }") < e.index("if (this.pago !== pagoAbierto || this.cobrando) return;") < e.index("this.cobrando = true;")
    assert "\n      if (!this.pago) return;" not in e
    # W2: la comanda de la parte de la venta rápida, después del cobro pedido y de V2, justo antes de emitir; la parte no se guarda como cuenta
    w2 = "if (this.esRestaurante && this.cobroParcial && this.cobroParcial.rapida && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) { try { this.enviarComanda(); } catch { /* la comanda no detiene el cobro */ } }"
    assert e.count(w2) == 1 and e.index("if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); }") < e.index("const cambio2 = ") < e.index(w2) < e.index("let doc = null, body = null;")
    assert cd.index("const rapida0 = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada);") < cd.index("this.lineas = resto; const id = this.persistirCuenta(true);") < cd.index("...(rapida0 ? { rapida: true } : {})")
    assert "if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();" in metodos["enviarComanda() {"] and "const id0 = this.esperaId; if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();" in metodos["comandaNumerada(modo,"]
    # W4: «Dividir» como estaba al tocar, en la espera, en el juntar de después y en la guarda final
    assert cp.count("this.dividir === div0") == 2 and cp.index("const id0 = this.esperaId, div0 = this.dividir;") < cp.index("await this.cobroPermitido('cobrar')")
    assert cp.index("this._alDia = 0; await this.alDiaParaCobrar(); }") < cp.index("if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago || this.dividir !== div0) return;") < cp.index("this.lineas = resto; const id = this.persistirCuenta(true);")
    assert "await this.alDiaParaCobrar(true)" not in cp
    # W5 y W10: la revisión de V4b en toda partición salvo las partes iguales de una mesa, antes de pedir el turno y de partir; con el aviso, _alDia = 0
    assert cd.index("if (!(d.modo === 'partes' && this.mesaActual) && this.esRestaurante && this.esperaId !== null && this.esperaId !== undefined) {") < cd.index("this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('" + AVISO_DIVIDIR + "', 'err');") \
        < cd.index("if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura") < cd.index("if (d.modo === 'partes') {") < cd.index("if (d.destino === 'nueva') {")
    # W11: V2 y V3 juntan después de esperar (3 s como mucho) y comparan; V3 con «cargo»
    assert e.index("const falta = this._marcaAjena.t + 4000 - Date.now();") < e.index("if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }") < e.index("const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }")
    assert rh.index("const fin = this._marcaAjena.t + 4000;") < rh.index("if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }") \
        < rh.index("if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;") < rh.index("this._habSigue = true; this.cargarAHabitacion();")
    assert "setTimeout(r, 4000)" not in rh                                                              # la habitación sigue en tramos de 200 ms
    # W6 en los bucles de la venta rápida: solo lo que falta hasta la marca que dejó persistirCuenta al juntar (4 s si no es de esa cuenta)
    assert "falta = ma && ma.id === this.esperaId ? ma.t + 4000 - Date.now() : 4000;" in e and "fin = ma && ma.id === this.esperaId ? ma.t + 4000 : Date.now() + 4000;" in rh
    # W7: el aviso con el nombre nuevo, después de guardarlo
    ad = metodos["async alDiaCuentaNueva(id) {"]
    assert ad.index("this.actualizarCuenta(id, x => ({ ...x, nombre }));") < ad.index("toast('Ya había otra «' + cn.nombre + '» abierta: lo que agregó quedó en «' + nombre + '».', 'ok');")
    # abrirDividir (una línea, no cambió): sigue sin abrir con el cobro, la habitación o una parte después de su espera
    assert "if (!this.lineas.length || this.dividir || this.pago || this.habCargo || this.cobroParcial) return;" in _linea(k, "async abrirDividir() {")
