# -*- coding: utf-8 -*-
"""4.25 (encargo 7b): pendientes de la revisión de las tandas 6b y 7 (conexión de una computadora nueva).

T1 «Salir» revoca siempre la sesión del token (también en «no se sabe»); T2 recarga de #/conectar después de aprobar (sin el código en la
dirección, seguimiento del pase guardado); T3 «Salir» en el paso «aprobada»; T4 instrucciones para los programas anteriores a la 4.25; T5
intento de conexión que se retoma al recargar (y el servidor no cancela uno con el número escrito); T6 marca del aviso antes de conectar
con una cuenta de la computadora; T7 pruebas (en test_425_conexion_pantallas.py y test_425_pendientes_6.py); T8 la sucursal de la
pestaña no va en la aprobación para otra empresa.

Nube y computadora corren en el MISMO proceso (ver tests/test_425_conexion_programa.py, de donde salen las ayudas y la limpieza)."""
import pathlib
import re

from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, engine, engine_empresa
from test_49_local_sinc import H, _admin_empresa, c
from test_425_conexion_nube import _aprobar, _pase
from test_425_conexion_nube import _iniciar as _iniciar_web
from test_425_conexion_programa import _limpieza, _confirmar, _estado, _iniciar, _llamadas, _programa  # noqa: F401

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _sesion(token: str):
    sid = auth.abrir(token)["sid"]
    with Session(engine) as sc:
        return sc.exec(select(auth.Sesion).where(auth.Sesion.sid == sid)).first()


def _logouts(uid: int) -> int:
    with Session(engine) as sc:
        return len(sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "logout")).all())


# ------------------------------------------------------------------------------------------------------------------------ T1
def test_t1_salir_revoca_la_sesion_aunque_no_se_sepa_si_la_cuenta_esta_retirada(monkeypatch):
    eid, tok = _admin_empresa("-t7b1", "3101425671")
    uid = auth.abrir(tok)["uid"]
    # «no se sabe» (no se pudo leer la configuración): las peticiones contestan 503, pero «Salir» cierra la sesión igual
    monkeypatch.setattr(auth, "_local_cerrado", lambda: True)
    monkeypatch.setattr(auth, "_cuenta_local_retirada", lambda s, u: None)
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 503
    antes = _logouts(uid)
    r = c.post("/api/auth/salir", headers=H(tok))
    assert r.status_code == 200 and r.json() == {"ok": True}
    assert _sesion(tok).revocada is True
    assert _logouts(uid) == antes + 1                                              # se sabe quién es: queda la auditoría
    monkeypatch.undo()
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 401                # el token ya no vale
    # un token que no vale: la misma respuesta de siempre, sin auditoría
    antes = _logouts(uid)
    assert c.post("/api/auth/salir", headers=H("no-es-un-token")).json() == {"ok": True}
    assert c.post("/api/auth/salir").json() == {"ok": True}
    assert _logouts(uid) == antes


def test_t1_en_la_web_salir_sigue_igual():
    eid, tok = _admin_empresa("-t7b1w", "3101425672")
    uid = auth.abrir(tok)["uid"]
    antes = _logouts(uid)
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 200
    r = c.post("/api/auth/salir", headers=H(tok))
    assert r.status_code == 200 and r.json() == {"ok": True}
    assert _sesion(tok).revocada is True and _logouts(uid) == antes + 1
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 401
    # una cuenta bloqueada: antes «Salir» no cerraba su sesión; ahora sí
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid)
        tok2 = auth._respuesta(sc, u, eid)["token"]
        u.bloqueado = True; sc.add(u); sc.commit()
    try:
        assert c.post("/api/auth/salir", headers=H(tok2)).status_code == 200
        assert _sesion(tok2).revocada is True
    finally:
        with Session(engine) as sc:
            u = sc.get(auth.Usuario, uid); u.bloqueado = False; sc.add(u); sc.commit()
    fuente = (RAIZ / "app" / "auth.py").read_text(encoding="utf-8")
    salir = _tramo(fuente, "def salir(", "@router.post(\"/salir-todas\")")
    assert "_datos_token(authorization, facturacr_token, request, s)" in salir and "_autenticar(" not in salir
    assert salir.index("ses.revocada = True") < salir.index("auditar(s, \"logout\"")


# ------------------------------------------------------------------------------------------------------------------------ T2 y T3
def test_t2_t3_recarga_de_conectar_despues_de_aprobar():
    a = _js("app.js")
    cx = _tramo(a, "export const conexion = reactive({", "\n});")
    assert "sessionStorage.removeItem('conectar'); sessionStorage.removeItem('conectar:pase');" in cx          # «Salir» limpia todo
    assert "leerPase() {" in cx and "/^[0-9]{1,12}$/.test(v)" in cx
    assert "fijarPase(id) {" in cx and "sessionStorage.setItem('conectar:pase', String(n))" in cx

    cn = _js("pages/conectar.js")
    olvidar = _tramo(cn, "    olvidarCodigo() {", "    async buscar() {")
    assert "conexion.fijar('');" in olvidar and "history.replaceState(null, '', '#/conectar')" in olvidar
    # (a) al aprobar, al rechazar y en un fallo con el código ya resuelto: fuera de la dirección
    aprobar = _tramo(cn, "    async aprobar() {", "    async rechazar() {")
    assert "this.olvidarCodigo();" in aprobar and "conexion.fijarPase(r.pase);" in aprobar
    assert "fijarPase(r.numero" not in cn and "numero" not in _tramo(cn, "conexion.fijarPase(r.pase);", "this.programar();")   # (b) nunca el número
    assert "this.olvidarCodigo(); }" in _tramo(cn, "    async rechazar() {", "    fallo(e) {")
    assert "this.olvidarCodigo(); }" in _tramo(cn, "    fallo(e) {", "    programar() {")
    assert "conexion.fijar('')" not in cn.replace(olvidar, "")                                  # siempre junto con la dirección
    # (c) al cargar con un pase guardado: directo al seguimiento, con «Cancelar» mientras se pueda y «Salir»
    creado = _tramo(cn, "  async created() {", "  beforeUnmount()")
    # 9b (U17): un código NUEVO del enlace manda sobre el pase guardado (que se olvida); el pase se retoma solo sin código nuevo
    assert creado.index("if (this.escrito) { conexion.fijarPase(''); await this.buscar(); return; }") < creado.index("const pid = conexion.leerPase();")
    assert "if (pid) await this.retomar(pid);" in creado
    assert ("const TEXTO_RETOMADO = 'Usted ya aprobó esta computadora. Si no alcanzó a escribir el número en el programa, cancele y empiece "
            "de nuevo.';") in cn and "textoRetomado: TEXTO_RETOMADO" in cn
    retomar = _tramo(cn, "    async retomar(pid) {", "    poner(r) {")
    assert "numero: null" in retomar and "this.retomado = true;" in retomar and "await this.seguir();" in retomar
    assert "puedeDetener() { return !this.cargando && ['aprobada', 'retenida'].includes(this.seguimiento); }," in cn
    # estado final, «entregada» o pase que ya no existe: se limpia la marca
    poner = _tramo(cn, "    poner(r) {", "    async detener() {")
    assert poner.count("conexion.fijarPase('');") == 2
    seguir = _tramo(cn, "    async seguir() {", "    async retomar(pid) {")
    assert "e.status === 404) { conexion.fijarPase('');" in seguir and "this.final = PASE_NO_EXISTE;" in seguir
    # T3: «Salir» siempre a la vista en «aprobada»; si «Cancelar» falla, el error queda en la pantalla
    plantilla = cn.split("template:", 1)[1]
    paso = _tramo(plantilla, "<template v-else-if=\"paso === 'aprobada'\">", "<template v-else-if=\"paso === 'listo'\">")
    assert '<template v-if="retomado">' in paso and "{{textoRetomado}}" in paso
    assert ':disabled="!puedeDetener">Cancelar</button>' in paso and '@click="salir()">Salir</button>' in paso
    assert '<div class="alert err small" style="margin:0 0 12px" v-if="error">{{error}}</div>' in paso
    detener = _tramo(cn, "    async detener() {", "  async created() {")
    assert "else this.error = (e && e.message)" in detener and "toast(" not in detener
    salir = _tramo(cn, "    salir(destino) {", "    olvidarCodigo() {")
    assert "api(" not in salir and "conexion.limpiar();" in salir


# ------------------------------------------------------------------------------------------------------------------------ T4
def test_t4_instrucciones_para_programas_anteriores():
    i = _js("pages/configuracion/instalacion-local.js")
    web = i.split("<template v-else-if=\"est\">", 1)[1]
    assert "<b>Otra forma de conectar (programas anteriores a la 4.25 o soporte)</b>" in web and "Otra forma de conectar (soporte)" not in i
    assert "Para el programa 4.25 o posterior." in _tramo(web, "<h2>Conectar una computadora nueva</h2>", "</div>")
    plegado = _tramo(web, "<details class=\"card\">", "</details>")
    for texto in ("Programa anterior a la 4.25:", "Configuración › Instalación local", "«Vincular esta instalación con la nube»",
                  "«Dirección de la nube»", "<b class=\"mono\">{{origen}}</b>", "«Código de vinculación»", "Vale 15 minutos y se usa una sola vez."):
        assert texto in plegado, texto
    assert "solo si soporte se lo pide" not in plegado.lower().replace("(solo si soporte se lo pide)", "")
    assert "origen: (typeof location !== 'undefined' && location.origin) || ''," in i


# ------------------------------------------------------------------------------------------------------------------------ T5
def test_t5_pantalla_retoma_el_intento_guardado():
    cx = _js("conexion-local.js")
    assert "const CLAVE_INTENTO = 'conexion:intento';" in cx
    iniciar = _tramo(cx, "    async iniciar() {", "    async retomar(id) {")
    assert "guardarIntento(r.intento);" in iniciar and "if (r.retomado) this.poner(r);" in iniciar
    retomar = _tramo(cx, "    async retomar(id) {", "    programar() {")
    assert "'/api/sinc/local/conexion/estado'" in retomar and "e.status === 410) { guardarIntento(''); this.v = null;" in retomar
    assert "created() { const id = leerIntento(); if (id) this.retomar(id); }," in cx
    poner = _tramo(cx, "    poner(r) {", "    fallo(e) {")
    assert "if (FINALES.includes(r.estado) || r.estado === 'lista') guardarIntento('');" in poner
    for metodo, siguiente in (("    async cancelar() {", "    deNuevo() {"), ("    deNuevo() {", "    entrar() {"), ("    fallo(e) {", "    async iniciar() {")):
        assert "guardarIntento('')" in _tramo(cx, metodo, siguiente), metodo
    assert "guardarIntento('')" in _tramo(cx, "    entrar() {", "    alVolver() {")
    # el navegador guarda SOLO la llave del intento (nunca el secreto ni el número)
    assert re.findall(r"sessionStorage\.setItem\(([^;]*)\);", cx) == ["CLAVE_INTENTO, String(id)"]


def test_t5_un_inicio_nuevo_sin_sesion_retoma_el_intento_con_el_numero_escrito(monkeypatch):
    eid_n, ta = _admin_empresa("-t7b5", "3101425675")
    shim = _programa(monkeypatch, retencion=300)
    j = _iniciar("Caja 1").json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert a["retenida"] is True
    assert _estado(j["intento"]).json()["estado"] == "retenida"
    v = _confirmar(j["intento"], a["numero"]).json()
    assert v["estado"] == "retenida" and v["numero_escrito"] is True
    pedidos = len(_llamadas(shim, "/api/sinc/conexion/iniciar"))
    # la pestaña se recargó y la persona tocó «Conectar» otra vez: no se crea otro pase y se devuelve ESE intento
    r = _iniciar("Caja 1")
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["retomado"] is True and v["intento"] == j["intento"] and v["estado"] == "retenida" and v["numero_escrito"] is True
    assert "numero" not in v and "secreto" not in r.text and "token" not in v
    assert len(_llamadas(shim, "/api/sinc/conexion/iniciar")) == pedidos
    assert not _llamadas(shim, "/api/sinc/conexion/cancelar")
    st = sinc._conexiones[j["intento"]]
    assert st["estado"] == "retenida" and st["numero"] == a["numero"] and len(sinc._conexiones) == 1
    assert _pase(id=a["pase"]).estado == "aprobado"
    # aplicando (o «fallo» después de recibir la conexión) también se retoma; uno sin número escrito se cancela como hoy
    for estado in ("aplicando", "fallo"):
        st["estado"] = estado
        assert _iniciar("Caja 1").json()["intento"] == j["intento"]
    st["estado"], st["numero"] = "confirmar", None
    otro = _iniciar("Caja 1").json()
    assert "retomado" not in otro and otro["intento"] != j["intento"]
    assert sinc._conexiones[j["intento"]]["estado"] == "cancelada"


def test_t5_funcion_pura_numero_escrito():
    def st(estado, numero=None):
        return {"estado": estado, "numero": numero}
    assert sinc._numero_escrito(st("retenida", "123")) and sinc._numero_escrito(st("aplicando")) and sinc._numero_escrito(st("fallo"))
    assert sinc._numero_escrito(st("confirmar", "123"))
    for e in ("esperando", "confirmar", "retenida", "lista", "cancelada"):
        assert not sinc._numero_escrito(st(e)), e


# ------------------------------------------------------------------------------------------------------------------------ T6
def test_t6_marca_del_aviso_antes_de_conectar_con_una_cuenta_de_la_computadora():
    cx = _js("conexion-local.js")
    iniciar = _tramo(cx, "    async iniciar() {", "    async retomar(id) {")
    assert iniciar.index("this.$emit('antes');") < iniciar.index("api('/api/sinc/local/conexion/iniciar'")
    assert "emits: ['lista', 'retirada', 'cancelar', 'antes', 'estado']," in cx
    assert "this.$emit('estado', 'cancelada');" in _tramo(cx, "    async cancelar() {", "    deNuevo() {")
    assert "this.$emit('estado', r.estado);" in _tramo(cx, "    poner(r) {", "    fallo(e) {")
    i = _js("pages/configuracion/instalacion-local.js")
    assert '@antes="antesDeConectar" @estado="estadoConexion"' in i
    antes = _tramo(i, "    antesDeConectar() {", "    estadoConexion(e) {")
    assert "if (!sesion.usuario?.de_nube)" in antes and "sessionStorage.setItem('conexion:aviso', this.textoRetirada())" in antes
    estado = _tramo(i, "    estadoConexion(e) {", "    tengoCodigo() {")
    assert "['esperando', 'retenida', 'confirmar', 'aplicando', 'fallo', 'lista'].includes(e)" in estado
    assert "sessionStorage.removeItem('conexion:aviso')" in estado
    # el texto del aviso es el mismo que deja la pantalla cuando el 401 lo recibe ella
    assert "const texto = ev && ev.conectada ? this.textoRetirada() :" in i
    assert "Esta computadora quedó conectada a la página web. La cuenta con la que entró se creó solo en esta computadora" in i


# ------------------------------------------------------------------------------------------------------------------------ T8
def test_t8_aprobar_para_otra_empresa_con_una_sucursal_que_solo_existe_en_la_otra(monkeypatch):
    from app.sucursales import Sucursal
    eid_a, ta = _admin_empresa("-t7b8a", "3101425681")
    eid_b, tb = _admin_empresa("-t7b8b", "3101425682")
    sid = 7777
    with Session(engine_empresa(eid_a)) as s:
        s.add(Sucursal(id=sid, empresa_id=eid_a, codigo=7, nombre="Sucursal de A")); s.commit()
    with Session(engine_empresa(eid_b)) as s:
        assert s.get(Sucursal, sid) is None
    try:
        _secreto, codigo, _j = _iniciar_web("Caja de B")
        r = _aprobar(tb, codigo, eid_b, cab={"X-Sucursal": str(sid), "X-Empresa": str(eid_b)})
        assert r.status_code == 200 and r.json()["estado"] == "aprobado", r.text                # la ignora: no la rechaza
        p = _pase(id=r.json()["pase"])
        assert p.empresa_id == eid_b and p.estado == "aprobado"
    finally:
        with Session(engine_empresa(eid_a)) as s:
            x = s.get(Sucursal, sid)
            if x is not None:
                s.delete(x); s.commit()
    # aun así la pantalla no la manda: con un número que SÍ existiera en la otra empresa tomaría una sucursal que nadie eligió
    api = _js("api.js")
    assert "const sinSucursal = !!opt.sinSucursal; delete opt.sinSucursal;" in api
    assert "if (_sucursalTab && !sinSucursal && !opt.headers['X-Sucursal']) opt.headers['X-Sucursal'] = String(_sucursalTab);" in api
    cn = _js("pages/conectar.js")
    llamar = _tramo(cn, "    async llamarAprobar(eid, si) {", "    async aprobar() {")
    assert llamar.index("opt.sinSucursal = true;") < llamar.index("try { return await api('/api/sinc/conexion/aprobar', opt); }")
    usos = [p.relative_to(JS).as_posix() for p in JS.rglob("*.js") if "vendor" not in p.parts and "sinSucursal" in p.read_text(encoding="utf-8")]
    assert sorted(usos) == ["api.js", "pages/conectar.js"]
