# -*- coding: utf-8 -*-
"""4.29, segunda parte, encargo B: la comanda sale al aceptar un pedido en línea (W-1 a W-7).

- Servidor (app/pedidos.py): al aceptar, si la caja del pedido numera las comandas, las líneas que van a cocina llevan «comanda» con el
  número siguiente del mismo contador que POST /api/pos/comanda/numero (comandas.siguiente); una caja que no numera deja la cuenta como
  siempre; un fallo del contador no impide aceptar. POST /api/pedidos/{id}/comanda/impresa deja la marca «impreso» de Cocina.
- Pantallas: el módulo compartido pos/_comandas.js (imprimir la comanda como «Imprimir» del monitor) corre en Node con impresoras de
  mentira; la pantalla de Pedidos (fis/pages/pedidos.js) acepta, imprime una vez y avisa; textos, sintaxis y plantillas.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import pathlib
import re
import subprocess
import uuid

import pytest
from sqlalchemy import text
from sqlmodel import Session

from app import comandas, modulos, pedidos
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_425_ultimos_pantallas import _node, _nodo

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
CLAVES_LINEA_DE_SIEMPRE = {"producto_id", "detalle", "cabys", "cantidad", "precio_unitario", "descuento", "descuento_pct", "codigo_tarifa", "tarifa", "es_servicio",
                           "unidad_medida", "precio_manual", "nota", "opciones", "enviado", "ronda"}


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _eid():
    from app import auth
    from app.main import app
    return app.dependency_overrides[auth.contexto]().empresa.id


def _montar_negocio(c, terminal: dict):
    """Empresa de prueba con una caja, dos platos y la página publicada; devuelve los productos."""
    eid = _eid()
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA", "mesas": [], **terminal}]})
        modulos.reemplazar(s, eid, "categorias", [{"id": 1, "nombre": "Platos"}, {"id": 2, "nombre": "Bebidas"}])
    a = c.post("/api/productos", json={"nombre": "Casado QA", "cabys": "2111100000000", "precio": 4000, "tarifa": 13, "codigo_tarifa": "08", "visible_catalogo": True, "categoria": "Platos"}).json()
    b = c.post("/api/productos", json={"nombre": "Refresco QA", "cabys": "2202900000000", "precio": 1000, "tarifa": 13, "codigo_tarifa": "08", "visible_catalogo": True, "categoria": "Bebidas"}).json()
    slug = "cmd429-" + uuid.uuid4().hex[:8]
    r = c.put("/api/pedidos/negocio", json={"slug": slug, "activo": True, "nombre": "Soda Comanda QA", "acepta_recoger": True, "acepta_domicilio": True, "costo_envio": 1500,
                                            "minimo_pedido": 0, "horarios": [], "redes": {}})
    assert r.status_code == 200, r.text
    return eid, slug, a, b


def _pedido(c, slug, a, b, tel="88881234"):
    r = c.post(f"/api/publico/{slug}/pedido", json={"nombre": "Cliente QA", "telefono": tel, "tipo": "domicilio", "direccion": "Barrio QA", "lineas": [
        {"producto_id": a["id"], "cantidad": 2, "nota": "sin cebolla"}, {"producto_id": b["id"], "cantidad": 1}]})
    assert r.status_code == 200, r.text
    return r.json()


def _cuenta(eid, cid):
    with Session(engine_empresa(eid)) as s:
        return next(x for x in modulos.leer(s, eid, "pos_espera", []) if x["id"] == cid)


def _contador(eid):
    with Session(engine_empresa(eid)) as s:
        return sorted(tuple(f) for f in s.execute(text("SELECT modo, ultimo FROM comanda_numero WHERE empresa_id = :e"), {"e": eid}).all())


# ================================================================================================================ servidor (W-6, W-2)
def test_caja_que_numera_pone_el_numero_siguiente_en_las_lineas(api):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "continuo"})
    assert c.post("/api/pos/comanda/numero", json={"modo": "continuo"}).json()["numero"] == 1      # la caja ya usó el 1
    p = _pedido(c, slug, a, b)
    conf = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert conf.status_code == 200, conf.text
    cu = _cuenta(eid, conf.json()["cuenta_espera_id"])
    cocina, envio = cu["lineas"][:2], cu["lineas"][2]
    assert [l["comanda"] for l in cocina] == [2, 2]                     # uno solo para todas sus impresoras, el siguiente del contador
    assert envio["detalle"] == "Envío a domicilio" and "comanda" not in envio   # el cargo del envío no va a cocina
    # el siguiente pedido, el siguiente número; la caja sigue después
    p2 = _pedido(c, slug, a, b, tel="88885678")
    cu2 = _cuenta(eid, c.put(f"/api/pedidos/{p2['id']}/estado", json={"estado": "confirmado"}).json()["cuenta_espera_id"])
    assert {l.get("comanda") for l in cu2["lineas"] if l.get("enviado")} == {3}
    assert c.post("/api/pos/comanda/numero", json={"modo": "continuo"}).json()["numero"] == 4
    # dos personas aceptan a la vez: la segunda se rechaza y no gasta número
    assert c.put(f"/api/pedidos/{p2['id']}/estado", json={"estado": "confirmado"}).status_code == 400
    assert _contador(eid) == [("continuo", 4)]


def test_caja_que_numera_por_dia(api):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "dia"})
    p = _pedido(c, slug, a, b)
    cu = _cuenta(eid, c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).json()["cuenta_espera_id"])
    assert [l.get("comanda") for l in cu["lineas"]] == [1, 1, None]
    assert _contador(eid) == [("dia", 1)]


@pytest.mark.parametrize("terminal", [{"modo": "restaurante"}, {"modo": "restaurante", "numerar_comanda": ""}, {"modo": "restaurante", "numerar_comanda": "semana"},
                                      {"modo": "mostrador", "numerar_comanda": "dia"}])
def test_caja_que_no_numera_deja_la_cuenta_como_hoy(api, terminal):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, terminal)
    p = _pedido(c, slug, a, b)
    cu = _cuenta(eid, c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).json()["cuenta_espera_id"])
    assert all("comanda" not in l for l in cu["lineas"]) and all(set(l) == CLAVES_LINEA_DE_SIEMPRE for l in cu["lineas"][:2]), cu["lineas"]   # ni un campo nuevo
    assert _contador(eid) == []                                                             # el contador ni se tocó


def test_funcion_del_modo_igual_que_la_caja():
    m = pedidos.modo_numerar_comanda
    assert m({"modo": "restaurante", "numerar_comanda": "dia"}) == "dia" and m({"modo": "restaurante", "numerar_comanda": "continuo"}) == "continuo"
    assert [m(x) for x in (None, {}, {"modo": "restaurante"}, {"modo": "mostrador", "numerar_comanda": "dia"}, {"modo": "restaurante", "numerar_comanda": "DIA"}, "dia")] == [""] * 6


def test_fallo_del_contador_no_impide_aceptar(api, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "dia"})

    def roto(*a, **k):
        raise RuntimeError("contador dañado")
    monkeypatch.setattr(comandas, "siguiente", roto)
    p = _pedido(c, slug, a, b)
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 200, r.text
    assert r.json()["estado"] in ("confirmado", "en_preparacion") and r.json()["cuenta_espera_id"]
    cu = _cuenta(eid, r.json()["cuenta_espera_id"])
    assert all("comanda" not in l for l in cu["lineas"]) and all(set(l) == CLAVES_LINEA_DE_SIEMPRE for l in cu["lineas"][:2])   # sin número, la de siempre


def test_fallo_del_contador_no_pierde_lo_pendiente_de_la_sesion(api, monkeypatch):  # noqa: F811
    """El pago aprobado de Tilopay (_pago_aprobado) cambia el pedido antes de a_caja: un error del contador no lo deshace."""
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "continuo"})
    p = _pedido(c, slug, a, b)

    def roto(s, *a, **k):
        s.execute(text("SELECT * FROM tabla_que_no_existe"))
    monkeypatch.setattr(comandas, "siguiente", roto)
    with Session(engine_empresa(eid)) as s:
        ped = s.get(pedidos.Pedido, p["id"]); ped.pago_referencia = "REF-QA-429"; s.add(ped)
        cid = pedidos.a_caja(s, eid, ped, pedidos._negocio(s, eid))
    with Session(engine_empresa(eid)) as s:
        assert s.get(pedidos.Pedido, p["id"]).pago_referencia == "REF-QA-429"
    assert all("comanda" not in l for l in _cuenta(eid, cid)["lineas"])


def test_marca_de_impresa_de_la_comanda(api):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante"})
    p = _pedido(c, slug, a, b)
    cid = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).json()["cuenta_espera_id"]
    antes = _cuenta(eid, cid)
    r = c.post(f"/api/pedidos/{p['id']}/comanda/impresa", json={"lineas": [0, 2, 9]})
    assert r.status_code == 200 and r.json() == {"ok": True, "marcadas": 1}                  # el envío (2) no va a cocina; 9 no existe
    despues = _cuenta(eid, cid)
    assert despues["lineas"][0] == {**antes["lineas"][0], "impreso": True}                   # la misma marca que deja Cocina
    assert despues["lineas"][1] == antes["lineas"][1] and despues["lineas"][2] == antes["lineas"][2]
    assert {k: v for k, v in despues.items() if k != "lineas"} == {k: v for k, v in antes.items() if k != "lineas"}
    assert c.post(f"/api/pedidos/{p['id']}/comanda/impresa", json={"lineas": [0, 1]}).json()["marcadas"] == 1   # la ya marcada no cuenta
    assert c.post("/api/pedidos/999999/comanda/impresa", json={"lineas": [0]}).status_code == 404
    q = _pedido(c, slug, a, b, tel="87776655")                                                 # pedido sin aceptar: sin cuenta, nada que marcar
    assert c.post(f"/api/pedidos/{q['id']}/comanda/impresa", json={"lineas": [0]}).json() == {"ok": False, "marcadas": 0}


# ================================================================================================================ módulo compartido en Node
FALSO_API = """
const Q = globalThis.Q = globalThis.Q || { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0 };
export const mock = { get: (k, d) => (k in Q.datos ? Q.datos[k] : d), set: (k, v) => { Q.datos[k] = v; return v; }, actualizar: (k, f, d) => (Q.datos[k] = f(k in Q.datos ? Q.datos[k] : d)), nextId: l => (l || []).length + 1, puedeGuardar: () => true, refrescar: async () => {} };
export const hoy = () => '2026-11-12', sumarDias = (d, n) => d, money = v => String(v), fmt = v => String(v), fecha = v => String(v), fmtCant = v => String(v);
export const toast = (m, t) => Q.toasts.push([m, t || '']);
export const abrirArchivo = async () => {};
export const api = (url, opt) => Q.api(url, opt);
"""
FALSO_AGENTE = """
export { docComanda, textoNumeroComanda, avisoImpresion } from './_agente_real.js';
export const porAgente = imp => imp.conexion === 'usb', cargarEquipo = async () => { globalThis.Q.equipo = (globalThis.Q.equipo || 0) + 1; }, impresoraAqui = x => x;
export const imprimirAgente = async (imp, doc) => { if ((globalThis.Q.rotas || []).includes(imp.nombre)) throw new Error('El agente de impresión no responde en esta computadora'); globalThis.Q.docs.push(doc); };
"""
NAVEGADOR = """
Date.prototype.toLocaleTimeString = () => '10:30';
globalThis.localStorage = { getItem: () => null, setItem() {} };
globalThis.confirm = () => true; globalThis.Blob = class { constructor(p) { Q.htmls.push(p.join('')); } };
globalThis.URL = { createObjectURL: () => 'blob:x', revokeObjectURL() {} };
globalThis.window = { open() { Q.abiertas++; return Q.bloqueada ? null : {}; } };
globalThis.setTimeout = f => 0;
"""
FALSO_DATOS_COCINA = """
export const enEspera = () => [], impresorasComanda = () => [], categorias = () => [], terminales = () => [], terminalActual = () => null, impresoraDe = () => null;
"""
FALSO_APP = "export const sesion = { empresa_id: 1, sucursal_id: null, usuario: { correo: 'caja-429@example.test' }, puede: () => true, empresaInfo: {} };\nexport const store = { productos: [] };\n"


def _falsos(extra=None):
    f = {"api.js": FALSO_API, "pages/pos/_agente.js": FALSO_AGENTE, "pages/pos/_agente_real.js": _js("pages/pos/_agente.js")}
    f.update(extra or {})
    return f


def test_funciones_puras_del_modulo_compartido(tmp_path):
    r = _node(tmp_path, """
const C = await import('./js/pages/pos/_comandas.js');
const COC = { id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'usb' }, BAR = { id: 11, nombre: 'Bar', conexion: 'navegador' }, OFF = { id: 12, nombre: 'Vieja', activa: false }, TIQ = { id: 13, nombre: 'Tiquetes', uso: 'comprobante' };
const out = {};
out.imps = C.impresorasDeComanda([COC, BAR, OFF, TIQ, null, { id: 14 }]).map(i => i.nombre);
out.cajas = [C.cajaDe({ terminales: [{ id: 1, nombre: 'A' }, { id: 2, nombre: 'B' }] }, 2).nombre, C.cajaDe({ terminales: [{ id: 1, nombre: 'A' }, { id: 2, nombre: 'B' }] }, 7).nombre,
  C.cajaDe({ terminales: [{ id: 1, nombre: 'A' }] }, null).nombre, C.cajaDe({ nombre_caja: 'Vieja', imprimir_comanda: false }, 1).imprimir_comanda, C.cajaDe(null, 3).nombre, C.cajaDe({}, null).nombre];
const cfg = imprime => ({ terminales: [{ id: 1, imprimir_comanda: imprime }] });
out.alAceptar = [C.imprimeAlAceptar(true, cfg(true), [COC], 1), C.imprimeAlAceptar(true, cfg(false), [COC], 1), C.imprimeAlAceptar(false, cfg(true), [COC], 1),
  C.imprimeAlAceptar(true, cfg(true), [], 1), C.imprimeAlAceptar(true, cfg(true), [OFF, TIQ], 1), C.imprimeAlAceptar(true, null, [COC], null), C.imprimeAlAceptar(true, cfg(undefined), [BAR], 1)];
const cats = [{ id: 1, nombre: 'Platos' }, { id: 2, nombre: 'Bebidas' }, { id: 3, nombre: 'Postres', padre_id: 1 }];
const term = { destinos: { 2: 11, 1: 10 } };
const P = [{ id: 1, categoria: 'Platos' }, { id: 2, categoria: 'Bebidas' }, { id: 3, categoria: 'Postres' }, { id: 4, categoria: 'Otra' }, { id: 5, categoria: 'Platos' }];
const lista = [COC, BAR];
out.deLista = [C.impresoraDeLista(lista, P[0], cats, term, {}).nombre, C.impresoraDeLista(lista, P[1], cats, term, {}).nombre, C.impresoraDeLista(lista, P[2], cats, term, {}).nombre,
  C.impresoraDeLista(lista, P[3], cats, term, {}).nombre, C.impresoraDeLista(lista, P[4], cats, term, { 5: { impresora_id: 'none' } }), C.impresoraDeLista(lista, P[4], cats, term, { 5: { impresora_id: 11 } }).nombre,
  C.impresoraDeLista(lista, undefined, cats, term, {}).nombre, C.impresoraDeLista(lista, P[0], cats, { destinos: { 1: 'bar' } }, {}).nombre];
const cuenta = { id: 5, terminal_id: 1, lineas: [
  { producto_id: 1, detalle: 'Casado', cantidad: 2, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 7 },
  { producto_id: 2, detalle: 'Refresco', cantidad: 1, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 7 },
  { producto_id: 5, detalle: 'Sin comanda', cantidad: 1, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 7 },
  { producto_id: null, detalle: 'Envío a domicilio', cantidad: 1, enviado: null, ronda: 0 },
  { producto_id: 1, detalle: 'Cero', cantidad: 0, enviado: '2026-11-12T10:00:00', ronda: 1 }] };
const ls = C.lineasComandaPedido(cuenta, { impresoras: [COC, BAR], categorias: cats, extras: { 5: { impresora_id: 'none' } }, productos: P, terminal: term });
out.lineas = ls.map(l => [l.detalle, l.imp.nombre, l.pos]);
out.sinImpresoras = C.lineasComandaPedido(cuenta, { impresoras: [], categorias: cats, productos: P, terminal: term }).length;
out.raros = [C.lineasComandaPedido(null).length, C.lineasComandaPedido({ lineas: 'x' }, { impresoras: [COC] }).length, C.lineasComandaPedido({ lineas: [null, {}] }, { impresoras: [COC], categorias: 'x', productos: null, extras: null }).length];
out.numero = [C.numeroDeRonda(ls), C.numeroDeRonda([{}]), C.numeroDeRonda(null)];
out.grupos = Object.values(C.gruposComanda([{ imp: COC }, { imp: BAR }, { imp: COC }, {}])).map(g => [g.imp.nombre, g.ls.length]);
out.avisos = [C.avisoComandaNoImpresa(['la impresora «Cocina» no respondió: El agente de impresión no responde en esta computadora.']), C.avisoComandaNoImpresa(['a', 'b. ']), C.avisoComandaNoImpresa([]), C.avisoComandaNoImpresa('x')];
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    assert r["imps"] == ["Cocina", "Bar"], r
    assert r["cajas"] == ["B", "A", "A", False, "Caja 1", "Caja 1"], r
    assert r["alAceptar"] == [True, False, False, False, False, True, True], r
    assert r["deLista"] == ["Cocina", "Bar", "Cocina", "Cocina", None, "Bar", "Cocina", "Bar"], r
    assert r["lineas"] == [["Casado", "Cocina", 0], ["Refresco", "Bar", 1]], r                  # sin comanda, envío y cantidad 0 no van
    assert r["sinImpresoras"] == 0 and r["raros"] == [0, 0, 0], r
    assert r["numero"] == [7, None, None], r
    assert r["grupos"] == [["Cocina", 2], ["Bar", 1], ["Cocina", 1]], r                          # sin impresora: la Cocina del navegador
    assert r["avisos"] == [
        "Pedido aceptado. La comanda no se imprimió: la impresora «Cocina» no respondió: El agente de impresión no responde en esta computadora. Imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda no se imprimió: a; b. Imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda no se imprimió: no se pudo imprimir. Imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda no se imprimió: x. Imprímala desde Punto de venta › Cocina."], r


def test_imprimir_comandas_y_es_lo_mismo_que_el_monitor(tmp_path):
    """La función compartida saca exactamente lo mismo que «Imprimir» del monitor de cocina (mismos documentos, misma página del navegador,
    mismos avisos), con y sin número; sin respaldo del navegador (al aceptar) una impresora caída es una falla con su motivo."""
    r = _node(tmp_path, NAVEGADOR.replace("Date.prototype", "const Q = globalThis.Q = { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0 };\nDate.prototype", 1) + """
const app = await import('./js/app.js');
const K = (await import('./js/pages/pos/cocina.js')).default;
const C = await import('./js/pages/pos/_comandas.js');
const vm = Object.assign({}, K.data.call({}));
for (const [k, f] of Object.entries(K.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f;
const COC = { id: 'c', nombre: 'Cocina', conexion: 'usb' }, BAR = { id: 'b', nombre: 'Bar', conexion: 'navegador' }, PAN = { id: 'p', nombre: 'Panadería', conexion: 'usb' };
const ticket = (comanda, extra) => ({ key: '5:1', cuenta: { id: 5, nombre: 'Pedido #9 · Ana', salonero: 'María', nota: 'Tocar el timbre' }, ronda: 1, comanda, desde: '2026-11-12T16:30:00Z', impresa: false,
  origen: { icono: '🌐', nombre: 'En línea' }, lineas: [{ detalle: 'Casado', cantidad: 2, nota: 'sin cebolla', imp: COC, enviado: 'x', ronda: 1 }, { detalle: 'Refresco', cantidad: 1, imp: BAR, enviado: 'x', ronda: 1 },
  { detalle: 'Pan', cantidad: 1, imp: PAN, enviado: 'x', ronda: 1 }, { detalle: 'Sin impresora', cantidad: 1, enviado: 'x', ronda: 1 }], ...(extra || {}) });
const correr = async f => { Q.docs = []; Q.htmls = []; Q.toasts = []; Q.abiertas = 0; const r = await f(); return { docs: Q.docs, htmls: Q.htmls, toasts: Q.toasts, abiertas: Q.abiertas, r }; };
const compartida = (t, extra) => C.imprimirComandas({ cuenta: t.cuenta, ronda: t.ronda, lineas: t.lineas, numero: t.comanda, icono: t.origen.icono, desde: t.desde, local: false, ...(extra || {}) });
const out = {};
for (const [nombre, rotas] of [['bien', []], ['panaderia_caida', ['Panadería']]]) {
  for (const num of [153, null]) {
    Q.rotas = rotas;
    const t = ticket(num);
    const a = await correr(() => vm.imprimir(t)), b = await correr(() => compartida(ticket(num)));
    out[nombre + ':' + num] = { iguales: JSON.stringify([a.docs, a.htmls, a.toasts, a.abiertas]) === JSON.stringify([b.docs, b.htmls, b.toasts, b.abiertas]), docs: b.docs.map(d => d.bloques[0].x), abiertas: b.abiertas,
      impresas: b.r.impresas.map(l => l.detalle), fallas: b.r.fallas, h1: (b.htmls[0] || '').includes('COMANDA N.º 153') };
  }
}
// al aceptar (sin respaldo): la impresora caída es falla, sus platos sin marcar; la del navegador bloqueada, también
Q.rotas = ['Panadería']; Q.bloqueada = false;
const x = await correr(() => compartida(ticket(7), { respaldoNavegador: false }));
out.aceptar = { impresas: x.r.impresas.map(l => l.detalle), fallas: x.r.fallas, toasts: x.toasts, abiertas: x.abiertas, docs: x.docs.map(d => d.bloques.map(b => b.x).filter(Boolean).slice(0, 2)) };
Q.rotas = []; Q.bloqueada = true;
const y = await correr(() => compartida(ticket(7), { respaldoNavegador: false }));
out.bloqueada = { impresas: y.r.impresas.map(l => l.detalle), fallas: y.r.fallas };
Q.bloqueada = false; Q.equipo = 0;
await correr(() => compartida(ticket(7), { respaldoNavegador: false, local: true }));
out.equipo = Q.equipo;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/cocina.js", "pages/pos/_comandas.js"), falsos=_falsos({"app.js": FALSO_APP, "pages/pos/_datos.js": FALSO_DATOS_COCINA}))
    for k in ("bien:153", "bien:null", "panaderia_caida:153", "panaderia_caida:null"):
        assert r[k]["iguales"], (k, r)
        assert r[k]["fallas"] == [], (k, r)
    assert r["bien:153"]["docs"] == ["COMANDA N.º 153", "COMANDA N.º 153"] and r["bien:153"]["h1"] and r["bien:153"]["abiertas"] == 1, r
    assert r["bien:null"]["docs"] == ["COCINA", "PANADERÍA"] and not r["bien:null"]["h1"], r
    assert sorted(r["bien:153"]["impresas"]) == ["Casado", "Pan", "Refresco", "Sin impresora"], r
    assert r["panaderia_caida:153"]["docs"] == ["COMANDA N.º 153"], r                            # la caída sale por el navegador (como el monitor)
    assert r["aceptar"]["impresas"] == ["Casado", "Refresco", "Sin impresora"] and r["aceptar"]["toasts"] == [], r
    assert r["aceptar"]["fallas"] == ["la impresora «Panadería» no respondió: El agente de impresión no responde en esta computadora"], r
    assert r["aceptar"]["docs"] == [["COMANDA N.º 7", "COCINA"]] and r["aceptar"]["abiertas"] == 1, r
    assert r["bloqueada"]["impresas"] == ["Casado", "Pan"], r
    assert r["bloqueada"]["fallas"] == ["el navegador no abrió la ventana de impresión (revise si bloquea las ventanas emergentes de esta página)"], r
    assert r["equipo"] == 1, r                                                                    # en el programa: la impresión de esta computadora


# ================================================================================================================ pantalla de Pedidos en Node
def _pedidos_para_node() -> str:
    """fis/pages/pedidos.js con sus importaciones absolutas (/js/…) llevadas a la copia de la prueba."""
    t = _js("fis/pages/pedidos.js")
    t = t.replace("from '/js/api.js'", "from '../../api.js'").replace("from '/js/avisos.js'", "from '../../avisos.js'").replace("import('/js/pages/pos/_comandas.js')", "import('../../pages/pos/_comandas.js')")
    assert "'/js/" not in t
    return t


FALSOS_FIS = {
    "avisos.js": "export const avisosActivos = () => false, activarAvisos = async () => true, desactivarAvisos = () => {};\n",
    "fis/sesion.js": "export const sesion = globalThis.Q.sesion;\n",
    "fis/ui.js": "export const dinero = v => String(v), fechaCorta = v => String(v), formaPago = () => 'Paga al recibir', puedeEstadoCuenta = () => false, urlEstadoCuenta = () => '';\n",
}
PEDIDOS_GUION = NAVEGADOR.replace("Date.prototype", """const Q = globalThis.Q = { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0 };
Q.sesion = { menu: true, negocio: { terminal_id: 1 }, empresaInfo: {}, fisica: true, tieneModulo: () => false, sucursalActual: null };
Date.prototype""", 1) + """
const COC = { id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'usb' };
const CUENTA = { id: 77, terminal_id: 1, nombre: 'Pedido #9 · Ana', nota: '', lineas: [
  { producto_id: 1, detalle: 'Casado', cantidad: 2, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 4 },
  { producto_id: 2, detalle: 'Refresco', cantidad: 1, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 4 },
  { producto_id: null, detalle: 'Envío a domicilio', cantidad: 1, enviado: null, ronda: 0 }] };
let R = {};
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method ? opt.method + ' ' : '') + url);
  if (R.fallar && R.fallar.some(f => url.startsWith(f))) { const e = new Error(R.mensaje || 'Sin conexión'); throw e; }
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) { if (R.segundo) { const e = new Error('El pedido está «Confirmado»; solo se confirma un pedido nuevo'); e.status = 400; throw e; } return { id: 9, estado: 'en_preparacion', cuenta_espera_id: 77 }; }
  if (url.endsWith('/comanda/impresa')) { Q.marcas = (Q.marcas || []).concat([opt.body.lineas]); return { ok: true, marcadas: opt.body.lineas.length }; }
  if (url === '/api/registros/pos_config') return { datos: R.cfg !== undefined ? R.cfg : { terminales: [{ id: 1, nombre: 'Caja', modo: 'restaurante' }] } };
  if (url === '/api/registros/pos_impresoras') return { datos: R.impresoras || [COC] };
  if (url === '/api/registros/pos_espera') return { datos: [CUENTA] };
  if (url === '/api/registros/categorias') return { datos: [] };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return [{ id: 1, nombre: 'Casado' }, { id: 2, nombre: 'Refresco' }];
  if (url.startsWith('/api/pedidos?')) return [];
  return null;
};
const P = (await import('./js/fis/pages/pedidos.js')).default;
const montar = () => { const vm = Object.assign({ params: { query: {} } }, P.data.call({ params: { query: {} } })); for (const [k, f] of Object.entries(P.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(P.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const caso = async (cfg, menu, accion) => { R = cfg; Q.sesion.menu = menu; Q.llamadas = []; Q.toasts = []; Q.docs = []; Q.marcas = []; Q.abiertas = 0; Q.rotas = R.rotas || [];
  const vm = montar(); await vm.cargarImpresion(); const etiqueta = vm.conComanda; const p = { id: 9, estado: 'nuevo' };
  const ok = await (accion ? accion(vm, p) : vm.aceptar(p));
  return { etiqueta, ok, toasts: Q.toasts, llamadas: Q.llamadas, docs: Q.docs.map(d => d.bloques[0].x), marcas: Q.marcas, abiertas: Q.abiertas, estado: p.estado }; };
const out = {};
out.bien = await caso({}, true);
out.caida = await caso({ rotas: ['Cocina'] }, true);
out.segundo = await caso({ segundo: true }, true);
out.sinMenu = await caso({}, false);
out.sinImpresoras = await caso({ impresoras: [] }, true);
out.cajaSinComanda = await caso({ cfg: { terminales: [{ id: 1, imprimir_comanda: false }] } }, true);
out.sinDatos = await caso({ fallar: ['/api/registros/pos_config'] }, true);
out.esperaCaida = await caso({ fallar: ['/api/registros/pos_espera'], mensaje: 'Sin conexión con el servidor' }, true, async (vm, p) => { R.fallar = null; await vm.cargarImpresion(); R.fallar = ['/api/registros/pos_espera']; return vm.aceptar(p); });
out.marcaCaida = await caso({}, true, async (vm, p) => { R.fallar = ['/api/pedidos/9/comanda']; return vm.aceptar(p); });
out.dobleClic = await caso({}, true, async (vm, p) => { const [a, b] = await Promise.all([vm.aceptar(p), vm.aceptar(p)]); return [a, b]; });
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_pantalla_de_pedidos_acepta_imprime_una_vez_y_avisa(tmp_path):
    falsos = _falsos({**FALSOS_FIS, "fis/pages/pedidos.js": _pedidos_para_node()})
    r = _node(tmp_path, PEDIDOS_GUION, archivos=("pages/pos/_comandas.js",), falsos=falsos)
    W4 = "Pedido aceptado. La comanda no se imprimió: {}. Imprímala desde Punto de venta › Cocina."
    b = r["bien"]
    assert b["etiqueta"] is True and b["ok"] is True and b["estado"] == "en_preparacion", r
    assert b["llamadas"][2] == "PUT /api/pedidos/9/estado"                                       # primero se acepta
    assert b["docs"] == ["COMANDA N.º 4"] and b["marcas"] == [[0, 1]], r                         # una vez, con su número; se marcan las impresas
    assert b["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]], r
    c = r["caida"]
    assert c["ok"] is True and c["docs"] == [] and c["marcas"] == [] and c["abiertas"] == 0, r   # aceptado; la comanda sin marcar
    assert c["toasts"] == [[W4.format("la impresora «Cocina» no respondió: El agente de impresión no responde en esta computadora"), "err"]], r
    s = r["segundo"]                                                                             # dos personas a la vez: solo imprime quien aceptó
    assert s["ok"] is False and s["docs"] == [] and s["marcas"] == [] and not any("pos_espera" in x for x in s["llamadas"]), r
    assert s["toasts"] == [["El pedido está «Confirmado»; solo se confirma un pedido nuevo", "err"]], r
    n = r["sinMenu"]                                                                             # quien no usa menú: como siempre, sin pedir nada más
    assert n["etiqueta"] is False and n["llamadas"] == ["PUT /api/pedidos/9/estado", "/api/pedidos?desde=2026-11-12&hasta=2026-11-12", "/api/registros/pos_espera"], r   # PUT y la recarga de siempre
    assert n["toasts"] == [["Pedido actualizado.", "ok"]] and n["docs"] == [], r
    for k in ("sinImpresoras", "cajaSinComanda", "sinDatos"):                                    # W-3 y datos que faltan: «Aceptar pedido», sin imprimir
        assert r[k]["etiqueta"] is False and r[k]["ok"] is True and r[k]["docs"] == [] and r[k]["toasts"] == [["Pedido actualizado.", "ok"]], (k, r)
        assert not any(x.startswith("/api/productos") or "comanda/impresa" in x for x in r[k]["llamadas"]) and r[k]["llamadas"].count("/api/registros/pos_espera") == 1, (k, r)
    e = r["esperaCaida"]
    assert e["ok"] is True and e["toasts"] == [[W4.format("Sin conexión con el servidor"), "err"]] and e["docs"] == [], r
    m = r["marcaCaida"]
    assert m["docs"] == ["COMANDA N.º 4"] and m["toasts"] == [["Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez.", "err"]], r
    d = r["dobleClic"]                                                                           # doble clic: un solo envío y una sola comanda
    assert d["ok"] == [True, False] and d["llamadas"].count("PUT /api/pedidos/9/estado") == 1 and d["docs"] == ["COMANDA N.º 4"], r


# ================================================================================================================ textos, sintaxis y plantillas
def test_textos_de_las_pantallas():
    ped, com, coc = _js("fis/pages/pedidos.js"), _js("pages/pos/_comandas.js"), _js("pages/pos/cocina.js")
    assert "'Pedido aceptado. La comanda no se imprimió: ' + m + '. Imprímala desde Punto de venta › Cocina.'" in com          # W-4
    assert "await C.imprimirComandas({ cuenta, ronda, lineas, numero: C.numeroDeRonda(lineas)" in ped and "respaldoNavegador: false" in ped
    assert "import('/js/pages/pos/_comandas.js')" in ped and "from '/js/pages/pos/" not in ped                                    # se carga al usarse
    assert '@submit.prevent="aceptar(f.p)"' in ped and ":disabled=\"!!aceptando[f.id]\"" in ped
    assert "{{conComanda ? 'Aceptar e imprimir comanda' : 'Aceptar pedido'}}" in ped
    assert "api('/api/pedidos/' + r.id + '/comanda/impresa', { method: 'POST', body: { lineas: pos } })" in ped
    assert "async created() { this.cargarImpresion();" in ped                                                                      # sin esperar: la pantalla carga igual
    # el módulo compartido no arranca el ERP (fis/ no tiene app.js ni los registros del punto de venta)
    for txt in (com, _js("pages/pos/_agente.js")):
        assert not re.search(r"from '[./]*(app|pages/pos/_datos|_datos)\.js'", txt)
    assert re.findall(r"^import .*$", com, re.M) == ["import { toast, fmtCant } from '../../api.js';",
                                                      "import { porAgente, imprimirAgente, docComanda, cargarEquipo, impresoraAqui, textoNumeroComanda, avisoImpresion } from './_agente.js';"]
    # lo de siempre del monitor sigue (la marca «impreso» y el reimprimir a propósito)
    assert "this.aplicar(v.id, x => ({ ...x, lineas: (x.lineas || []).map(l => (this.enRonda(l, t) ? { ...l, impreso: true } : l)) }));" in coc
    assert "if (t.impresa && !confirm('Esta comanda ya se imprimió. ¿Imprimirla otra vez?')) return;" in coc
    # lo de siempre de Pedidos (test_46_revision, test_49_revendedoras_fis, test_387_tienda)
    assert "estadoWeb(f.p, 'entregado')" in ped and "async estadoWeb(p, estado, motivo)" in ped and "toast('Pedido actualizado.', 'ok')" in ped


def test_sintaxis_plantillas_y_nombres(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("fis/pages/pedidos.js", "pages/pos/_comandas.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") == 0 or b.count(b"\r\n") == b.count(b"\n"), rel
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const txt = fs.readFileSync(%s, 'utf8'); const m = /template:\\s*`([\\s\\S]*?)`/.exec(txt);
const err = []; let codigo = '';
try { codigo = compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }).code; } catch (e) { err.push(String(e)); }
console.log(JSON.stringify({ err, dolar: m[1].includes('${') }));
""" % (json.dumps(vue), json.dumps(str(JS / "fis/pages/pedidos.js")))
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r == {"err": [], "dolar": False}, r
    ped = _js("fis/pages/pedidos.js")
    assert re.search(r"@(click|submit[.a-z]*)=\"[^\"]*\bif\b", ped) is None                                                   # ningún manejador con «if»
    assert "aceptando: {}" in ped and "impresion: null" in ped and "conComanda() {" in ped and "    async aceptar(p) {" in ped     # todo lo que usa la plantilla existe
    for linea in ped.splitlines():                                                                                              # ninguna línea nueva cerrada con «//»
        if any(k in linea for k in ("cargarImpresion", "aceptar(", "comandaDelPedido", "conComanda", "aceptando")):
            assert "//" not in linea or linea.strip().startswith("//"), linea
