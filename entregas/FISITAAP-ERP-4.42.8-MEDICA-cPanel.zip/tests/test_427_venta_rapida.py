# -*- coding: utf-8 -*-
"""4.27: venta rápida en la caja de restaurante (V-1 a V-8 del encargo).

La caja de restaurante gana el dato opcional `inicio` ('mesas' por omisión | 'venta' | 'preguntar'); una sola función pura
(`vistaInicial` en pos/_datos.js) decide con qué pantalla abre y `vistaTrasCobro` adónde vuelve después de cobrar. Arriba están
siempre los botones «Mesas» y «Venta rápida»; con «Preguntar cada vez» se muestran las dos opciones grandes."""
import json
import pathlib
import re
import subprocess

import pytest

from test_425_ultimos_pantallas import _node, _nodo

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


FALSO_API = """
const datos = {};
export const mock = { get: (k, d) => (k in datos ? datos[k] : d), set: (k, v) => { datos[k] = v; return v; }, actualizar() {}, nextId: () => 1, _datos: datos };
export const hoy = () => '2026-11-12', money = v => String(v), precioCliente = () => 0, otroImpLinea = () => ({ monto: 0, base: 0 });
"""
FALSO_APP = "export const sesion = { empresa_id: 1, sucursal_id: null, usuario: { correo: 'caja-427@example.test' }, puede: () => true };\n"


# ------------------------------------------------------------------------------------------------ 1) la función pura (V-2, V-3, V-5)
def test_vista_inicial_y_tras_cobro_en_node(tmp_path):
    r = _node(tmp_path, """
const D = await import('./js/pages/pos/_datos.js');
const { mock } = await import('./js/api.js');
const out = {};
const R = inicio => ({ modo: 'restaurante', inicio });
out.inicial = {
  mostrador: D.vistaInicial({ modo: 'mostrador' }),
  mostrador_con_inicio: D.vistaInicial({ modo: 'mostrador', inicio: 'mesas' }),
  mesas: D.vistaInicial(R('mesas')), venta: D.vistaInicial(R('venta')), preguntar: D.vistaInicial(R('preguntar')),
  vieja: D.vistaInicial({ modo: 'restaurante' }), rara: D.vistaInicial(R('cualquiera')), nula: D.vistaInicial(null), sin_modo: D.vistaInicial({}),
};
out.tras = {
  mostrador: [D.vistaTrasCobro({ modo: 'mostrador', inicio: 'mesas' }, true), D.vistaTrasCobro({ modo: 'mostrador' }, false)],
  mesas: [D.vistaTrasCobro(R('mesas'), true), D.vistaTrasCobro(R('mesas'), false)],
  venta: [D.vistaTrasCobro(R('venta'), true), D.vistaTrasCobro(R('venta'), false)],
  preguntar: [D.vistaTrasCobro(R('preguntar'), true), D.vistaTrasCobro(R('preguntar'), false)],
  vieja: [D.vistaTrasCobro({ modo: 'restaurante' }, true), D.vistaTrasCobro({ modo: 'restaurante' }, false)],
};
out.base = [D.TERMINAL_BASE.inicio, D.terminalCompleta({ modo: 'restaurante' }).inicio, D.terminalCompleta({ modo: 'restaurante', inicio: 'venta' }).inicio, D.terminalCompleta(null).inicio];
out.inicios = D.INICIOS;
// configuración guardada por una versión anterior (sin el campo): abre en Mesas como siempre
mock.set('pos_config', { terminales: [{ id: 1, nombre: 'Salón', modo: 'restaurante' }, { id: 2, nombre: 'Barra', modo: 'mostrador' }] });
out.vieja_cfg = D.config().terminales.map(t => [t.nombre, t.inicio, D.vistaInicial(t)]);
// y la de una sola caja (1.22)
mock.set('pos_config', { nombre_caja: 'Soda', modo: 'restaurante' });
out.una_caja = D.config().terminales.map(t => [t.nombre, t.inicio, D.vistaInicial(t)]);
// guardar conserva lo elegido
D.guardarConfig({ terminales: [{ id: 1, nombre: 'Salón', modo: 'restaurante', inicio: 'preguntar' }] });
out.guardada = [mock._datos.pos_config.terminales[0].inicio, D.vistaInicial(D.config().terminales[0])];
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_datos.js",), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r["inicial"] == {"mostrador": "venta", "mostrador_con_inicio": "venta", "mesas": "mesas", "venta": "venta", "preguntar": "elegir",
                            "vieja": "mesas", "rara": "mesas", "nula": "venta", "sin_modo": "venta"}, r
    assert r["tras"] == {"mostrador": ["venta", "venta"], "mesas": ["mesas", "mesas"], "venta": ["venta", "mesas"],
                         "preguntar": ["elegir", "mesas"], "vieja": ["mesas", "mesas"]}, r
    assert r["base"] == ["mesas", "mesas", "venta", "mesas"], r
    assert r["inicios"] == [["mesas", "Mesas"], ["venta", "Venta rápida"], ["preguntar", "Preguntar cada vez"]], r
    # 4.39: una caja de restaurante sin mesas configuradas (terminalCompleta las deja en []) abre en la venta rápida, no en un plano vacío
    assert r["vieja_cfg"] == [["Salón", "mesas", "venta"], ["Barra", "mesas", "venta"]], r
    assert r["una_caja"] == [["Soda", "mesas", "venta"]], r
    assert r["guardada"] == ["preguntar", "venta"], r


# ------------------------------------------------------------------------------------------------ 2) caja.js (V-3, V-4, V-5)
def test_caja_usa_la_funcion_en_todos_los_lugares():
    k = _js("pages/pos/caja.js")
    assert "modo === 'restaurante' ? 'mesas' : 'venta'" not in k                              # ya no queda la regla repetida
    assert "vistaInicial, vistaTrasCobro, opcionesCierre } from './_datos.js';" in k   # 4.41: opcionesCierre al final
    assert "vista: vistaInicial(cfg), mesaActual: null," in k                                   # al montar la caja
    usar = _tramo(k, "    usarTerminal(id) {", "    precioMostrar(p)")
    assert "this.vista = vistaInicial(t);" in usar                                              # al elegir la caja
    # después de cobrar, cargar a la habitación o guardar sin conexión: la venta rápida sigue según «inicio»; la de mesa vuelve a Mesas
    assert k.count("if (this.esRestaurante) this.vista = vistaTrasCobro(this.cfg, ") == 3
    assert "if (this.esRestaurante) this.vista = 'mesas';" not in k
    cobrar = _tramo(k, "    async cobrar() {", "    async abrirCargoHab() {")
    # corrección 4.27 (H1): se toma la marca de la sesión antes de esperar al servidor; no se deduce de esperaId (la comanda guarda la venta rápida como «Cuenta N»)
    # 4.39 (prueba de punta a punta): lo que no es de una mesa (cuenta guardada sin mesa, pedido) también sigue «inicio»; lo de una mesa vuelve a Mesas
    assert "mesa = this.mesaActual, rapida = this.esVentaRapida || (this.esRestaurante && !this.mesaActual && !(cc && (cc.mesa_id || (Array.isArray(cc.mesas_ids) && cc.mesas_ids.length))));" in cobrar and "vistaTrasCobro(this.cfg, rapida)" in cobrar
    assert "if (this.esRestaurante && this.vista === 'venta') this.rapida = true;" in cobrar
    assert "fiado, regalos, rapida })" in cobrar                                                # y viaja a la venta sin conexión
    hab = _tramo(k, "    cargarAHabitacion() {", "    comandaHab(r, lineas, t) {")
    assert "nombreEspera = this.nombreEspera, rapida = this.esVentaRapida || (this.esRestaurante && !this.mesaActual && !(this.cuentaActual && (this.cuentaActual.mesa_id || (Array.isArray(this.cuentaActual.mesas_ids) && this.cuentaActual.mesas_ids.length)))), lineas" in hab and "vistaTrasCobro(this.cfg, rapida)" in hab
    assert "if (this.esRestaurante && this.vista === 'venta') this.rapida = true;" in hab
    sin = _tramo(k, "    ventaSinConexion(c) {", "    docProvisional(v) {")
    i = sin.index("const rapida = !!c.rapida;")
    assert i < sin.index("this.mesaActual = null;") and "vistaTrasCobro(this.cfg, rapida)" in sin       # se mira antes de limpiar
    assert "!mesa && !esperaId && !nombreEspera" not in k and "!this.mesaActual && !c.esperaId && !c.nombreEspera" not in k


def test_caja_botones_mesas_y_venta_rapida():
    k = _js("pages/pos/caja.js")
    seg = """<button :class="{on: enMesas}" @click="volverAMesas(false)">🍽 Mesas</button><button :class="{on: esVentaRapida}" @click="ventaRapida">⚡ Venta rápida</button>"""
    assert ":class=\"{on: vista==='mesas'}\" @click=\"volverAMesas(false)\"" not in k                 # retoque 3: con una mesa o un pedido cargado también se marca «Mesas»
    assert k.count(seg) == 2                                                                    # en el plano y en la pantalla de venta
    plano = _tramo(k, """<div v-show="esRestaurante && vista==='mesas'">""", "<!-- pantalla de venta -->")
    venta = _tramo(k, """<div class="pos" v-show="!esRestaurante || vista==='venta'">""", "</div>")
    assert seg in plano and seg in venta and '<span class="seg" v-if="esRestaurante"' in k
    assert "◀ Mesas" not in k                                                                   # el botón viejo quedó dentro de los dos nuevos
    # «Venta rápida» hace lo mismo que la venta sin mesa; desde una mesa primero sale de ella como «Mesas»
    assert "    ventaSinMesa() {" in k and "ventaSinMesa()" in k
    vr = _tramo(k, "    ventaRapida() {", "    moverA(m) {")
    assert "this.volverAMesas(false); if (this.vista !== 'mesas') return;" in vr and "this.ventaSinMesa();" in vr
    assert "if (this.esVentaRapida) return;" in vr                                               # ya en ella no suelta la cuenta guardada por la comanda
    # corrección 4.27 (H1): una marca de la sesión, no deducida de esperaId / nombreEspera
    assert "esVentaRapida() { return this.vista === 'venta' && !this.mesaActual && this.rapida; }" in k
    assert "nombreEspera: '', esperaId: null, rapida: true," in k
    assert "this.parteNueva = false; this.rapida = true; this.vista = 'venta';" in _tramo(k, "    ventaSinMesa() {", "\n")
    assert "this.parteNueva = false; this.rapida = false; }," in _tramo(k, "    cargarCuenta(v) {", "\n")
    assert "this.mesaActual = null; this.rapida = false;" in _tramo(k, "    async confirmarPedido() {", "    avanzarPedido(v)")
    # el flujo de «para llevar» con nombre sigue como estaba
    assert "@click=\"abrirPedido\"" in k and "Para llevar en espera" in k


def test_caja_pantalla_de_elegir():
    k = _js("pages/pos/caja.js")
    e = _tramo(k, """<div class="card" v-if="esRestaurante && vista==='elegir'\"""", """<div v-show="esRestaurante && vista==='mesas'">""")
    assert "¿Cómo desea vender ahora?" in e and '@click="volverAMesas(false)"><span>🍽 Mesas' in e and '@click="ventaRapida"><span>⚡ Venta rápida' in e
    assert "usarTerminal(+$event.target.value)" in e and '@click="abrirApertura">Abrir caja' in e
    # retoque 1: el .btn del proyecto es flex en fila y sin salto: en estos dos botones el título va arriba y la ayuda debajo, partiéndose
    grandes = re.findall(r'<button class="btn[^"]*" style="([^"]*)" @click="(?:volverAMesas\(false\)|ventaRapida)"><span>', e)
    assert len(grandes) == 2, e
    for st in grandes:
        assert "flex-direction:column" in st and "white-space:normal" in st and "min-width:0" in st, st
    assert '<span>🍽 Mesas</span><div class="small muted"' in e and '<span>⚡ Venta rápida</span><div class="small"' in e
    # la pantalla de venta no se ve mientras se elige ni en el plano
    assert """<div class="pos" v-show="!esRestaurante || vista==='venta'">""" in k


def test_venta_rapida_en_node(tmp_path):
    """El método ventaRapida sobre un objeto corriente: desde el plano, desde la pantalla de elegir, ya en venta rápida, y desde una
    mesa (sale de ella como «Mesas»; si la persona no confirma, se queda donde estaba)."""
    k = _js("pages/pos/caja.js")
    cuerpo = _tramo(k, "    ventaRapida() {", "    moverA(m) {").strip().rstrip(",")
    r = _node(tmp_path, """
const M = { %s };
function vm(estado, confirma) {
  const v = Object.assign({ vista: 'mesas', mesaActual: null, esperaId: null, nombreEspera: '', rapida: true, llamadas: [] }, estado);
  Object.defineProperty(v, 'esVentaRapida', { get() { return this.vista === 'venta' && !this.mesaActual && this.rapida; } });
  v.volverAMesas = function () { this.llamadas.push('volver'); if (confirma === false) return; this.vista = 'mesas'; this.mesaActual = null; this.esperaId = null; this.nombreEspera = ''; };
  v.ventaSinMesa = function () { this.llamadas.push('sinMesa'); this.vista = 'venta'; };
  v.ventaRapida = M.ventaRapida.bind(v); v.ventaRapida(); return [v.vista, v.llamadas, v.esperaId];
}
console.log(JSON.stringify({
  plano: vm({}), elegir: vm({ vista: 'elegir' }), rapida: vm({ vista: 'venta' }),
  mesa: vm({ vista: 'venta', mesaActual: { id: 3 }, esperaId: 'x', nombreEspera: 'Mesa 3', rapida: false }),
  mesa_no: vm({ vista: 'venta', mesaActual: { id: 3 }, esperaId: 'x', nombreEspera: 'Mesa 3', rapida: false }, false),
  llevar: vm({ vista: 'venta', esperaId: 'y', nombreEspera: 'Ana', rapida: false }),
  comanda: vm({ vista: 'venta', esperaId: 'c1' }),
}));
""" % cuerpo, archivos=(), falsos={})
    assert r["plano"] == ["venta", ["sinMesa"], None] and r["elegir"] == ["venta", ["sinMesa"], None] and r["rapida"] == ["venta", [], None], r
    assert r["mesa"] == ["venta", ["volver", "sinMesa"], None] and r["llevar"] == ["venta", ["volver", "sinMesa"], None], r
    assert r["mesa_no"] == ["venta", ["volver"], "x"], r
    assert r["comanda"] == ["venta", [], "c1"], r                                                  # H1: la venta rápida con comanda no se suelta


def test_venta_rapida_con_comanda_sigue_siendolo_en_node(tmp_path):
    """Corrección 4.27 (H1): en la caja de restaurante, enviar la comanda (F8) guarda la venta rápida como «Cuenta N» con esperaId.
    Con los métodos reales de caja.js: sigue marcada como venta rápida, «Venta rápida» no la suelta, y al cobrar la caja vuelve a la
    siguiente venta rápida (o a preguntar) según «Al entrar a esta caja». Una cuenta recuperada no cuenta como venta rápida."""
    k = _js("pages/pos/caja.js")
    linea = lambda nombre: _tramo(k, "    " + nombre, "\n").strip()
    metodos = [_tramo(k, "    enviarComanda() {", "\n    },\n").strip() + "\n    }", _tramo(k, "    persistirCuenta(devolverId) {", "    ponerEnEspera() {").strip().rstrip(","),
               _tramo(k, "    descartarVacia() {", "    guardarCuenta() {").strip().rstrip(","), _tramo(k, "    ventaRapida() {", "    moverA(m) {").strip().rstrip(","),
               linea("cargarCuenta(v) {").rstrip(","), linea("ventaSinMesa() {").rstrip(",")]
    computadas = [linea("esVentaRapida() {").split("   //")[0].strip().rstrip(","), linea("cuentaActual() {").rstrip(",")]
    r = _node(tmp_path, """
const { vistaTrasCobro } = await import('./js/pages/pos/_datos.js');
Object.assign(globalThis, await import('./js/pages/pos/_fusion.js'));   /* 4.31: la caja usa el módulo de la misma mesa */
let lista = [];
globalThis.mock = { actualizar: (k, f) => (lista = f(lista)), nextId: l => l.length + 1, puedeGuardar: () => true };
globalThis.toast = () => {}; globalThis.sesion = { usuario: { correo: 'caja-427@example.test' } };
const C = { %s }, M = { %s };
function caja(inicio) {
  const vm = { vista: 'venta', mesaActual: null, esperaId: null, nombreEspera: '', rapida: true, espera: [], lineas: [], nota: '', clienteId: null, servicio: false,
    servicioPctCuenta: null, parteNueva: false, salonero: '', esRestaurante: true, totales: { total: 1000 }, cfg: { id: 7, modo: 'restaurante', inicio, imprimir_comanda: false },
    $nextTick: f => f && f(), $refs: {}, destinoDe: () => null, volverAMesas() { this.vista = 'mesas'; } };
  for (const [n, f] of Object.entries(C)) Object.defineProperty(vm, n, { get: f.bind(vm) });
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const out = {};
for (const inicio of ['venta', 'preguntar', 'mesas']) {
  const vm = caja(inicio); lista = [];
  vm.ventaSinMesa(); vm.lineas.push({ producto_id: 1, detalle: 'Casado', cantidad: 1, precio_unitario: 1000 });
  vm.enviarComanda();
  const tras = [vm.esperaId, (lista[0] || {}).nombre, vm.esVentaRapida];
  vm.ventaRapida();   // tocar «Venta rápida» otra vez no la suelta
  tras.push(vm.esperaId, vm.lineas.length, vm.vista, vistaTrasCobro(vm.cfg, vm.esVentaRapida));   // lo que cobrar() toma antes de limpiar
  out[inicio] = tras;
}
const vm = caja('venta'); lista = [{ id: 5, nombre: 'Ana', lineas: [{ detalle: 'x', cantidad: 1 }], pedido: 'llevar' }]; vm.espera = lista;
vm.cargarCuenta(lista[0]); out.recuperada = [vm.esVentaRapida, vistaTrasCobro(vm.cfg, vm.esVentaRapida)];
vm.ventaSinMesa(); out.despues = vm.esVentaRapida;
console.log(JSON.stringify(out));
""" % (",\n".join(computadas), ",\n".join(metodos)), archivos=("pages/pos/_datos.js", "pages/pos/_fusion.js"), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r["venta"] == [1, "Cuenta 1", True, 1, 1, "venta", "venta"], r
    assert r["preguntar"] == [1, "Cuenta 1", True, 1, 1, "venta", "elegir"], r
    assert r["mesas"] == [1, "Cuenta 1", True, 1, 1, "venta", "mesas"], r
    assert r["recuperada"] == [False, "mesas"] and r["despues"] is True, r


def test_boton_mesas_marcado_en_node(tmp_path):
    """Retoque 3: en la pantalla de venta de una caja de restaurante, con una mesa abierta, una cuenta recuperada o un pedido para
    llevar cargado se marca «Mesas»; en una venta rápida, «Venta rápida». Nunca los dos a la vez. Computadas reales de caja.js."""
    k = _js("pages/pos/caja.js")
    linea = lambda nombre: _tramo(k, "    " + nombre, "\n").strip().split("   //")[0].strip().rstrip(",")
    r = _node(tmp_path, """
const C = { %s, %s };
function vm(estado) {
  const v = Object.assign({ vista: 'venta', mesaActual: null, rapida: true }, estado);
  for (const [n, f] of Object.entries(C)) Object.defineProperty(v, n, { get: f.bind(v) });
  return [v.enMesas, v.esVentaRapida];
}
console.log(JSON.stringify({
  plano: vm({ vista: 'mesas' }), elegir: vm({ vista: 'elegir' }), rapida: vm({}),
  mesa: vm({ mesaActual: { id: 3 }, rapida: false }), mesa_con_marca: vm({ mesaActual: { id: 3 } }),
  llevar: vm({ rapida: false }),
}));
""" % (linea("esVentaRapida() {"), linea("enMesas() {")), archivos=(), falsos={})
    assert r == {"plano": [True, False], "elegir": [False, False], "rapida": [False, True], "mesa": [True, False],
                 "mesa_con_marca": [True, False], "llevar": [True, False]}, r
    assert "    enMesas() {" in _tramo(k, "  computed: {", "  methods: {")


def test_nombre_del_modo_venta_rapida():
    """Retoque 2: la opción del modo de la caja se llama «Venta rápida / mostrador (tienda, soda, spa)» en Configuración (MODOS)
    y en la guía de la primera caja."""
    d, k = _js("pages/pos/_datos.js"), _js("pages/pos/caja.js")
    assert "['mostrador', 'Venta rápida / mostrador (tienda, soda, spa)']" in d and "Mostrador (tienda, supermercado, spa)" not in d
    assert '<option value="mostrador">Venta rápida / mostrador (tienda, soda, spa)</option>' in k and "Mostrador (tienda, soda rápida, spa)" not in k
    assert "{{m[1]}}" in _tramo(_js("pages/pos/configuracion.js"), '<Field label="Modo" req', "</Field>")   # Configuración lo toma de MODOS


def test_nombres_de_la_plantilla_de_caja_existen():
    k = _js("pages/pos/caja.js")
    computed = _tramo(k, "  computed: {", "  methods: {")
    methods = k[k.index("  methods: {"):]
    assert "    esVentaRapida() {" in computed and "    esRestaurante() {" in computed
    for m in ("    ventaRapida() {", "    volverAMesas(sinPreguntar) {", "    usarTerminal(id) {", "    abrirApertura() {"):
        assert m in methods, m
    assert re.search(r"@click=\"[^\"]*\bif\b", k) is None                                       # ningún manejador en línea con «if»


# ------------------------------------------------------------------------------------------------ 3) configuracion.js (V-2, V-6)
def test_configuracion_selector_y_ayuda():
    c = _js("pages/pos/configuracion.js")
    assert "esDeco, INICIOS } from './_datos.js';" in c and "MEDIOS, MODOS, INICIOS, MODIFICADORES_BASE," in c
    campo = """<Field label="Al entrar a esta caja" v-if="t.modo==='restaurante'\""""
    assert campo in c and """<select v-model="t.inicio"><option v-for="x in INICIOS" :key="x[0]" :value="x[0]">{{x[1]}}</option></select>""" in c
    assert "Preguntar cada vez: muestra las dos opciones" in c
    modo = _tramo(c, '<Field label="Modo" req', "</Field>")
    assert "caja aparte solo para venta rápida, con su propia apertura y cierre" in modo and "Cree otra caja en modo Mostrador" in modo and "plan" in modo
    assert c.index('<Field label="Modo" req') < c.index(campo) < c.index('id="cfg-restaurante"')     # junto al modo, dentro de «Caja y comprobante»
    # se guarda como el resto de la caja (sin quitar el campo)
    assert "this.cfg.terminales.map(({ modificadores_txt, saloneros_txt, clave_nueva, quitar_clave, ...t }) => t)" in c


def test_franja_de_la_cuenta_abajo_en_el_telefono():
    """Corrección 4.27 (H2): a ancho de teléfono la franja de la cuenta (.pos-der, fija) va ABAJO. La regla base le pone
    top:calc(var(--header) + 12px) (sticky en escritorio); sin anularlo quedaba fija arriba y tapaba «Mesas» y «Venta rápida»."""
    css = (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")
    assert ".pos-der{display:flex;" in css and "position:sticky;top:calc(var(--header) + 12px)" in css
    tel = [b for b in css.split("@media(max-width:640px){")[1:] if b.split("\n")[0].count(".pos-der{position:fixed !important;")]
    assert len(tel) == 1
    regla = tel[0][tel[0].index(".pos-der{position:fixed !important;"):]
    regla = regla[:regla.index("}")]
    assert "top:auto;" in regla and "bottom:0;" in regla, regla


# ------------------------------------------------------------------------------------------------ 4) sintaxis y plantillas
def test_sintaxis_y_plantillas(tmp_path):
    """node --check de los tres archivos tocados y el compilador de Vue del proyecto sobre las plantillas de caja y configuración."""
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/pos/_datos.js", "pages/pos/caja.js", "pages/pos/configuracion.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in tocados[1:]])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0, saltadas = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) { saltadas++; continue; }
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, saltadas, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] == 2 and r["saltadas"] == 0 and r["malos"] == [], r
