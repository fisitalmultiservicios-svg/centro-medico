"""3.87: sitio público y página del negocio (QA 3.87).
- Las páginas del sitio (precios, prueba-gratis, guías, hotel…) son nombres reservados: ningún negocio las reemplaza con su página.
- «Mis pedidos» del cliente de la página trae solo los pedidos hechos con ese acceso (saber un teléfono ya no deja ver los pedidos,
  la dirección ni el PIN de entrega de otra persona); un pedido de invitado se suma a la cuenta abriendo su enlace de seguimiento.
  Hay un límite por conexión para crear accesos y el negocio puede restablecer el acceso de un teléfono.
- Los puntos que se canjean en la página son los del teléfono del acceso, nunca los del teléfono escrito en el pedido.
- Modo mayorista: cada revendedora crea su acceso con su código personal; el código común del negocio ya no basta para entrar con
  el teléfono de otra, y la sesión se corta si el negocio cambia el celular del contacto. Las fotos del catálogo privado piden la
  firma que reciben las revendedoras con sesión.
- Prueba gratis: los planes de restaurante y de servicios están en el formulario.
- El límite de cupones y tarjetas de regalo es por conexión, no uno solo para todo el negocio.
- Página 404 del sitio en HTML para quien navega (la API sigue respondiendo JSON).
- La política de seguridad de las páginas con etiqueta de Google admite sus destinos de medición.
- Textos públicos: pie sin horario, calculadora de aguinaldo, cabecera del sitio, marca y migas para buscadores."""
import io
import json
import pathlib
import re

from sqlmodel import Session, select

from app import auth, pedidos, sitio
from app.db import Cliente, engine, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_pedidos import _eid, _productos, _publicar

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
PNG = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xf8"
       b"\xcf\xc0\xf0\x1f\x00\x05\x00\x01\xff\x89\x99=\x1d\x00\x00\x00\x00IEND\xaeB`\x82")


def _static(*partes) -> str:
    return (RAIZ / "static").joinpath(*partes).read_text(encoding="utf-8")


# ------------------------------------------------------------------------------------------------ publico:1
def test_paginas_del_sitio_son_nombres_reservados(api):  # noqa: F811
    c = api; eid = _eid()
    segmentos = {r.strip("/").split("/")[0] for r in sitio.PAGINAS if r.strip("/")}
    assert segmentos <= pedidos.RESERVADOS                       # al agregar una página al sitio queda reservada sola
    for nombre in ("prueba-gratis", "precios", "guias", "hotel", "restaurante", "herramientas", "ventas-en-linea"):
        r = _publicar(c, slug=nombre, google_id="G-QA12345678")
        assert r.status_code == 400 and "reservada" in r.text, (nombre, r.text)
    # un negocio que ya tenía ese nombre (guardado antes del arreglo) no reemplaza la página del sitio: su página sigue en /t/<nombre>
    assert _publicar(c, slug="tienda-387-reservado-qa", google_id="G-QA12345678").status_code == 200
    with Session(engine) as s:
        fila = s.exec(select(pedidos.SlugPublico).where(pedidos.SlugPublico.empresa_id == eid)).first()
        fila.slug = "precios"; s.add(fila); s.commit()
    with Session(engine_empresa(eid)) as s:
        n = pedidos._negocio(s, eid); n.slug = "precios"; s.add(n); s.commit()
    pedidos._cache_slugs.clear()
    try:
        r = c.get("/precios")
        assert r.status_code == 200 and "tienda.js" not in r.text and "googletagmanager" not in r.headers.get("content-security-policy", "")
        assert "Precios" in re.search(r"<title>(.*?)</title>", r.text).group(1)
        assert "tienda.js" in c.get("/t/precios").text                                     # la tienda no se queda sin página mientras cambia el nombre
        # revisión: puede seguir guardando su página con ese nombre (solo no puede elegir otro reservado) y sus enlaces van a /t/precios
        r = _publicar(c, slug="precios", google_id="G-QA12345678")
        assert r.status_code == 200, r.text
        assert r.json()["url"].endswith("/t/precios") and r.json()["url_publica"].endswith("/t/precios") and r.json()["url_subdominio"] is None
        assert re.search(r'<link rel="canonical" href="[^"]*/t/precios"', c.get("/t/precios").text)
        assert _publicar(c, slug="hotel").status_code == 400
    finally:
        with Session(engine) as s:
            for f in s.exec(select(pedidos.SlugPublico).where(pedidos.SlugPublico.empresa_id == eid)).all():
                s.delete(f)
            s.commit()
        pedidos._cache_slugs.clear()


# ------------------------------------------------------------------------------------------------ publico:2
def test_mis_pedidos_solo_los_del_acceso(api):  # noqa: F811
    c = api
    a, b, _, _ = _productos(c)
    assert _publicar(c, slug="tel-ajeno-387-qa", minimo_pedido=0).status_code == 200
    base = "/api/publico/tel-ajeno-387-qa"
    lineas = [{"producto_id": b["id"], "cantidad": 2}]
    # una persona pide como invitada con su teléfono y su dirección
    inv = c.post(base + "/pedido", json={"nombre": "Invitada QA", "telefono": "87654321", "tipo": "domicilio", "direccion": "Casa amarilla QA, San Pedro", "nota": "Timbre dañado", "lineas": lineas}).json()
    assert inv["numero"] == 1
    # otra persona crea el acceso con ese teléfono: no ve el pedido de la invitada (ni su dirección ni su enlace de seguimiento)
    t = c.post(base + "/cliente/acceso", json={"telefono": "87654321", "pin": "2580", "nombre": "Otra Persona QA"}).json()
    H = {"X-Cliente": t["token"]}
    m = c.get(base + "/mis-pedidos", headers=H).json()
    assert m["pedidos"] == [] and "Casa amarilla" not in json.dumps(m) and inv["token"] not in json.dumps(m)
    # sus propios pedidos con ese acceso sí aparecen (y «Repetir» tiene las líneas)
    propio = c.post(base + "/pedido", json={"nombre": "Otra Persona QA", "telefono": "87654321", "tipo": "recoger", "lineas": lineas}, headers=H).json()
    m = c.get(base + "/mis-pedidos", headers=H).json()
    assert [p["numero"] for p in m["pedidos"]] == [propio["numero"]] and "producto_id" in m["pedidos"][0]["lineas"][0]
    # quien tiene el enlace de seguimiento (la dueña del pedido) lo suma a su cuenta al abrirlo con su sesión
    t2 = c.post(base + "/cliente/acceso", json={"telefono": "86001111", "pin": "1357", "nombre": "Dueña QA"}).json(); H2 = {"X-Cliente": t2["token"]}
    suyo = c.post(base + "/pedido", json={"nombre": "Dueña QA", "telefono": "86001111", "tipo": "recoger", "lineas": lineas}).json()   # como invitada
    assert c.get(base + "/mis-pedidos", headers=H2).json()["pedidos"] == []
    assert c.get(f"{base}/pedido/{suyo['token']}", headers=H).status_code == 200                       # otra sesión (otro teléfono) no se lo lleva
    assert c.get(f"{base}/pedido/{suyo['token']}", headers=H2).status_code == 200
    assert [p["numero"] for p in c.get(base + "/mis-pedidos", headers=H2).json()["pedidos"]] == [suyo["numero"]]
    assert [p["numero"] for p in c.get(base + "/mis-pedidos", headers=H).json()["pedidos"]] == [propio["numero"]]
    # el negocio sigue viendo los pedidos por teléfono en su lista de clientes
    lista = {x["telefono"]: x for x in c.get("/api/pedidos/clientes").json()}
    assert lista["87654321"]["pedidos"] == 2


def test_limite_de_accesos_nuevos_por_conexion(api):  # noqa: F811
    c = api
    _productos(c)
    assert _publicar(c, slug="barrido-387-qa", minimo_pedido=0).status_code == 200
    codigos = [c.post("/api/publico/barrido-387-qa/cliente/acceso", json={"telefono": f"8800{i:04d}", "pin": "1234", "nombre": "Barrido QA"}).status_code for i in range(22)]
    assert codigos[:20] == [200] * 20 and codigos[20] == 429, codigos
    # entrar a un acceso que ya existe no cuenta para ese límite
    assert c.post("/api/publico/barrido-387-qa/cliente/acceso", json={"telefono": "88000001", "pin": "1234"}).status_code == 200


def test_negocio_restablece_el_acceso_de_un_telefono(api):  # noqa: F811
    c = api
    a, b, _, _ = _productos(c)
    assert _publicar(c, slug="restablecer-387-qa", minimo_pedido=0).status_code == 200
    base = "/api/publico/restablecer-387-qa"
    t = c.post(base + "/cliente/acceso", json={"telefono": "87001234", "pin": "1111", "nombre": "Tercero QA"}).json(); H = {"X-Cliente": t["token"]}
    c.post(base + "/pedido", json={"nombre": "Tercero QA", "telefono": "87001234", "tipo": "recoger", "lineas": [{"producto_id": b["id"], "cantidad": 2}]}, headers=H)
    assert c.post(base + "/cliente/acceso", json={"telefono": "87001234", "pin": "2222"}).status_code == 401    # la dueña real no puede entrar
    cf = next(x for x in c.get("/api/pedidos/clientes").json() if x["telefono"] == "87001234")
    assert c.delete(f"/api/pedidos/clientes/{cf['id']}").json()["ok"] is True
    assert c.delete(f"/api/pedidos/clientes/{cf['id']}").status_code == 404
    assert c.get(base + "/mis-pedidos", headers=H).status_code == 401                                            # la sesión del tercero ya no vale
    assert "87001234" not in [x["telefono"] for x in c.get("/api/pedidos/clientes").json()]
    t2 = c.post(base + "/cliente/acceso", json={"telefono": "87001234", "pin": "2222", "nombre": "Dueña QA"}).json()
    assert t2["nombre"] == "Dueña QA"
    m = c.get(base + "/mis-pedidos", headers={"X-Cliente": t2["token"]}).json()
    assert m["pedidos"] == []                                                                                      # no hereda los pedidos del acceso retirado
    assert c.post(base + "/pedido", json={"nombre": "Tercero QA", "telefono": "87001234", "tipo": "recoger", "puntos": 0, "lineas": [{"producto_id": b["id"], "cantidad": 2}]}, headers=H).json()["cliente_final_id"] is None


# ------------------------------------------------------------------------------------------------ publico:3
def test_puntos_del_acceso_no_del_telefono_del_pedido(api):  # noqa: F811
    c = api
    a, b, _, _ = _productos(c)
    assert _publicar(c, slug="puntos-387-qa", minimo_pedido=0).status_code == 200
    base = "/api/publico/puntos-387-qa"
    assert c.put("/api/fidelizacion/config", json={"activo": True, "puntos_por_mil": 10, "valor_punto": 5, "minimo_canje": 50, "maximo_pct": 50}).status_code == 200
    assert c.post("/api/fidelizacion/acreditar", json={"telefono": "87650001", "monto": 60000, "referencia": "doc:387-1"}).json()["saldo"] == 600   # la víctima
    vic = c.post(base + "/cliente/acceso", json={"telefono": "87650001", "pin": "4321", "nombre": "Víctima QA"}).json()
    ata = c.post(base + "/cliente/acceso", json={"telefono": "86650002", "pin": "9999", "nombre": "Atacante QA"}).json(); HA = {"X-Cliente": ata["token"]}
    lineas = [{"producto_id": b["id"], "cantidad": 10}]                                                            # 11.300
    r = c.post(base + "/pedido", json={"nombre": "Atacante QA", "telefono": "87650001", "tipo": "recoger", "puntos": 300, "lineas": lineas}, headers=HA)
    assert r.status_code == 400, r.text                                                                            # el atacante no tiene puntos
    assert c.get("/api/fidelizacion/saldo?telefono=87650001").json()["saldo"] == 600
    # la víctima, dentro de su sesión, pide para otra persona (otro teléfono en el pedido) y usa SUS puntos
    HV = {"X-Cliente": vic["token"]}
    q = c.post(base + "/pedido", json={"nombre": "Para mi mamá", "telefono": "88880000", "tipo": "recoger", "puntos": 300, "lineas": lineas}, headers=HV)
    assert q.status_code == 200, q.text
    assert q.json()["puntos_canjeados"] == 300 and q.json()["descuento_puntos"] == 1500
    assert c.get("/api/fidelizacion/saldo?telefono=87650001").json()["saldo"] == 300
    assert c.get("/api/fidelizacion/saldo?telefono=88880000").json()["saldo"] == 0
    assert c.get(base + "/puntos", headers=HV).json()["saldo"] == 300


# ------------------------------------------------------------------------------------------------ publico:4
def _mayorista(c, slug, **extra):
    a, b, _o, _g = _productos(c)
    ana = c.post("/api/clientes", json={"nombre": "Revendedora Ana QA", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303870001", "celular": 81110001, "limite_credito": 50000}).json()
    bea = c.post("/api/clientes", json={"nombre": "Revendedora Bea QA", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303870002", "celular": 81110002, "limite_credito": 30000}).json()
    assert ana.get("id") and bea.get("id"), (ana, bea)
    r = _publicar(c, slug=slug, activo=True, mayorista=True, mayorista_codigo="REV2026", mayorista_credito=True, minimo_pedido=0, **extra); assert r.status_code == 200, r.text
    return a, b, ana, bea


def test_mayorista_codigo_personal_por_revendedora(api):  # noqa: F811
    c = api; eid = _eid()
    a, b, ana, bea = _mayorista(c, "mayor-387-qa")
    base = "/api/publico/mayor-387-qa"
    revs = {x["contacto_id"]: x for x in c.get("/api/pedidos/revendedoras").json()}
    assert revs[ana["id"]]["telefono"] == "81110001" and revs[ana["id"]]["con_acceso"] is False
    cod_ana, cod_bea = revs[ana["id"]]["codigo"], revs[bea["id"]]["codigo"]
    assert re.fullmatch(r"[A-Z2-7]{8}", cod_ana) and cod_ana != cod_bea and cod_ana != "REV2026"
    # Ana conoce el código del negocio y el celular de Bea: ya no entra como Bea; con su propio código personal tampoco
    for codigo in ("REV2026", "rev2026", cod_ana, "", None):
        r = c.post(base + "/cliente/acceso", json={"telefono": "81110002", "pin": "1234", "codigo": codigo})
        assert r.status_code == 403, (codigo, r.text)
    # Bea con su código personal (minúsculas o con guion también) crea su acceso; después entra solo con su clave
    r = c.post(base + "/cliente/acceso", json={"telefono": "81110002", "pin": "2468", "codigo": cod_bea[:4].lower() + "-" + cod_bea[4:]})
    assert r.status_code == 200, r.text
    assert r.json()["contacto"]["contacto_id"] == bea["id"] and r.json()["contacto"]["credito"]["disponible"] == 30000
    tok_bea = r.json()["token"]
    assert c.post(base + "/cliente/acceso", json={"telefono": "81110002", "pin": "2468"}).status_code == 200
    assert c.post(base + "/cliente/acceso", json={"telefono": "81110002", "pin": "1234", "codigo": cod_bea}).status_code == 401   # el código no cambia la clave
    assert {x["contacto_id"]: x for x in c.get("/api/pedidos/revendedoras").json()}[bea["id"]]["con_acceso"] is True
    # su catálogo y su pedido a crédito siguen funcionando
    d = c.get(base, headers={"X-Cliente": tok_bea}).json(); assert not d.get("privado") and d["cliente"]["contacto_id"] == bea["id"]
    p = c.post(base + "/pedido", json={"nombre": "Bea", "telefono": "81110002", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}], "pago": "credito"}, headers={"X-Cliente": tok_bea})
    assert p.status_code == 200 and p.json()["a_credito"] is True and p.json()["contacto_id"] == bea["id"], p.text
    # el negocio cambia el celular de Bea en Contactos: la sesión vieja ya no entra a su cuenta ni a su crédito
    with Session(engine_empresa(eid)) as s:
        cb = s.get(Cliente, bea["id"]); cb.celular = 81119999; s.add(cb); s.commit()
    d = c.get(base, headers={"X-Cliente": tok_bea}).json()
    assert d.get("privado") is True and d["items"] == []
    assert c.get(base + "/mis-pedidos", headers={"X-Cliente": tok_bea}).json()["cuenta"] is None
    assert c.post(base + "/pedido", json={"nombre": "Bea", "telefono": "81110002", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}], "pago": "credito"}, headers={"X-Cliente": tok_bea}).status_code == 401
    # cambiar el código del negocio cambia los códigos personales que todavía no se usaron
    assert _publicar(c, slug="mayor-387-qa", activo=True, mayorista=True, mayorista_codigo="OTRO2027", mayorista_credito=True, minimo_pedido=0).status_code == 200
    assert {x["contacto_id"]: x for x in c.get("/api/pedidos/revendedoras").json()}[ana["id"]]["codigo"] != cod_ana
    # la pantalla del negocio y la página traen el código personal
    pub = _static("js", "fis", "pages", "publicar.js"); js = _static("js", "tienda.js")
    assert "/api/pedidos/revendedoras" in pub and "código personal" in pub and "Código de acceso" in js


def test_mayorista_fotos_solo_con_sesion(api):  # noqa: F811
    c = api
    a, b, ana, bea = _mayorista(c, "fotos-387-qa")
    assert c.post(f"/api/productos/{a['id']}/imagen", files={"archivo": ("foto.png", io.BytesIO(PNG), "image/png")}).status_code == 200
    assert c.get(f"/api/publico/fotos-387-qa/foto/{a['id']}").status_code == 404                                   # sin sesión
    assert c.get(f"/api/publico/fotos-387-qa/foto/{a['id']}?k=inventada").status_code == 404
    cod = {x["contacto_id"]: x for x in c.get("/api/pedidos/revendedoras").json()}[ana["id"]]["codigo"]
    tok = c.post("/api/publico/fotos-387-qa/cliente/acceso", json={"telefono": "81110001", "pin": "1234", "codigo": cod}).json()["token"]
    d = c.get("/api/publico/fotos-387-qa", headers={"X-Cliente": tok}).json()
    foto = next(i for i in d["items"] if i["id"] == a["id"])["foto"]
    assert "?k=" in foto
    r = c.get(foto); assert r.status_code == 200 and r.headers["content-type"] == "image/png"   # como la pide el <img>: sin cabeceras
    # un negocio normal sigue con sus fotos públicas
    assert _publicar(c, slug="fotos-387-qa", activo=True, minimo_pedido=0).status_code == 200
    d = c.get("/api/publico/fotos-387-qa").json()
    foto = next(i for i in d["items"] if i["id"] == a["id"])["foto"]
    assert "?k=" not in foto and c.get(foto).status_code == 200
    # despublicado: sin fotos, igual que sin datos
    assert _publicar(c, slug="fotos-387-qa", activo=False, minimo_pedido=0).status_code == 200
    assert c.get(foto).status_code == 404


# ------------------------------------------------------------------------------------------------ publico:5
def test_prueba_gratis_ofrece_los_planes_de_restaurante_y_servicios():
    from fastapi.testclient import TestClient
    from app.main import app
    c = TestClient(app)
    cfg = sitio.leer()
    html = c.get("/prueba-gratis").text
    opciones = re.findall(r"<option>(.*?)</option>", html)
    precios = c.get("/precios").text
    for p in (cfg["planes"].get("restaurante") or []) + (cfg["planes"].get("servicios") or []):
        nombre = sitio.escape(p["nombre"])
        assert nombre in opciones, p["nombre"]
    for plan in re.findall(r'data-plan="([^"]+)"', precios):                 # cada «Probar gratis» de /precios tiene su opción
        assert plan in opciones or plan in ("Hotelería", "Hotelería con canales"), plan
    assert len(opciones) == len(set(opciones))
    assert "sel.selectedIndex < 0" in _static("landing.js")                   # un plan desconocido en la dirección no deja el select en blanco


# ------------------------------------------------------------------------------------------------ publico:8
def test_limite_de_cupones_y_tarjetas_por_conexion(api, monkeypatch):  # noqa: F811
    c = api
    _productos(c)
    assert _publicar(c, slug="cupones-387-qa", minimo_pedido=0).status_code == 200
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    A, B = {"X-Forwarded-For": "203.0.113.5"}, {"X-Forwarded-For": "198.51.100.7"}
    cods = [c.post("/api/publico/cupones-387-qa/cupon", json={"codigo": f"FALSO{i}", "subtotal": 10000}, headers=A).status_code for i in range(31)]
    assert cods[:30] == [400] * 30 and cods[30] == 429, cods
    assert c.post("/api/publico/cupones-387-qa/cupon", json={"codigo": "OTRO", "subtotal": 10000}, headers=B).status_code == 400   # los demás clientes siguen
    tar = [c.get(f"/api/publico/cupones-387-qa/tarjeta/GFFALSA{i}", headers=A).status_code for i in range(21)]
    assert 429 not in tar[:20] and tar[20] == 429, tar
    assert c.get("/api/publico/cupones-387-qa/tarjeta/GFOTRA", headers=B).status_code != 429
    js = _static("js", "tienda.js")
    assert "e.status === 429" in js                                            # la página muestra el aviso de espera, no «código no válido»


# ------------------------------------------------------------------------------------------------ publico:14
def test_pagina_404_del_sitio_en_html(api, monkeypatch):  # noqa: F811
    c = api
    nav = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
    for ruta in ("/no-existe-387", "/guias/no-existe-387"):
        r = c.get(ruta, headers=nav)
        assert r.status_code == 404 and r.headers["content-type"].startswith("text/html"), ruta
        assert "FISITAAP by Brillante Agencia" in r.text and 'href="/precios"' in r.text and "noindex" in r.text and "{{" not in r.text, ruta
        assert 'rel="canonical"' not in r.text
        assert 'property="og:url"' not in r.text and "application/ld+json" not in r.text, ruta        # revisión: no es la página de inicio
        assert c.head(ruta, headers=nav).status_code == 404
    # lo que ven los clientes de un negocio (/t/, enlaces /p/ de comprobantes, su dominio): sin la marca ni la venta del sistema
    for ruta, texto in (("/t/negocio-que-no-existe-387", "no existe"), ("/p/token-falso-387", "ya venció")):
        r = c.get(ruta, headers=nav)
        assert r.status_code == 404 and r.headers["content-type"].startswith("text/html") and texto in r.text, ruta
        assert "/precios" not in r.text and "Prueba gratis" not in r.text and "Brillante" not in r.text and "noindex" in r.text, ruta
        assert 'href="/"' not in r.text, ruta
        assert c.head(ruta, headers=nav).status_code == 404
    monkeypatch.setattr(pedidos, "negocio_de_host", lambda h: (1, "minegocio-qa") if h.startswith("minegocio-qa.example.test") else None)
    r = c.get("/lo-que-sea-387", headers={**nav, "Host": "minegocio-qa.example.test"})
    assert r.status_code == 404 and "/precios" not in r.text and "Brillante" not in r.text and 'href="/">Ir al inicio' in r.text
    # la API y los programas que no piden HTML siguen recibiendo JSON
    assert c.get("/no-existe-387").headers["content-type"].startswith("application/json")
    r = c.get("/api/publico/negocio-que-no-existe-387", headers=nav); assert r.status_code == 404 and r.json()["detail"]
    assert c.get("/api/no-existe-387", headers=nav).headers["content-type"].startswith("application/json")


# ------------------------------------------------------------------------------------------------ publico:16
def test_csp_de_pixeles_admite_la_medicion_de_google(api):  # noqa: F811
    c = api
    _productos(c)
    assert _publicar(c, slug="pixeles-387-qa", google_id="AW-123456789", minimo_pedido=0).status_code == 200
    csp = c.get("/pixeles-387-qa").headers["content-security-policy"]
    reglas = {p.split()[0]: p.split()[1:] for p in csp.split("; ") if p.strip()}
    for destino in ("https://www.google.com", "https://*.g.doubleclick.net"):
        assert destino in reglas["connect-src"] and destino in reglas["img-src"], destino
    assert "https://td.doubleclick.net" in reglas["frame-src"]
    assert "https://www.google.com" not in reglas["script-src"] and "'unsafe-inline'" not in reglas["script-src"]
    assert "google.com" not in c.get("/app/").headers["content-security-policy"]


# ------------------------------------------------------------------------------------------------ textos e interfaz
def test_textos_publicos():
    js = _static("js", "tienda.js")
    assert "conHorario()" in js and 'v-if="aj.horario_texto || conHorario"' in js          # publico:9: sin horario el pie no dice «Cerrado» 7 días
    calc = _static("calculadora-aguinaldo.js")
    assert r"/^\d{1,3}(,\d{3})+(\.\d+)?$/" in calc                                          # publico:12: 450,000 son 450 mil
    css = _static("landing.css")
    assert ".barra .marca{flex-shrink:0" in css and "@media (max-width:1100px)" in css      # publico:6: la firma no se monta sobre el menú
    assert "Grupo Factura" not in _static("motorizado.webmanifest")                         # publico:10
    assert "FISITAAP ERP" not in _static("img", "sitio", "marca", "iconos.svg")
    # publico:15: en los datos para buscadores cada miga intermedia lleva su dirección
    from fastapi.testclient import TestClient
    from app.main import app
    t = TestClient(app).get("/herramientas/calculadora-aguinaldo").text
    ld = json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>', t, re.S).group(1))
    migas = next(g for g in ld["@graph"] if g["@type"] == "BreadcrumbList")["itemListElement"]
    assert all("item" in m for m in migas) and [m["position"] for m in migas] == list(range(1, len(migas) + 1))
    assert "Herramientas" in t                                                               # la miga visible se conserva


# ------------------------------------------------------------------------------------------------ revisión de la 3.87
def _con_rol(rol, permisos=None):
    """Cambia el rol del contexto de la prueba; devuelve el contexto original para restaurarlo."""
    from app.main import app
    ctx0 = app.dependency_overrides[auth.contexto]()
    ctx = auth.Contexto(ctx0.usuario, ctx0.empresa, rol, permisos=permisos)
    app.dependency_overrides[auth.contexto] = lambda: ctx
    return ctx0


def _restaurar(ctx0):
    from app.main import app
    app.dependency_overrides[auth.contexto] = lambda: ctx0


def test_codigos_de_revendedoras_y_restablecer_para_quien_administra_clientes(api):  # noqa: F811
    c = api
    _a, _b, ana, _bea = _mayorista(c, "roles-387-qa")
    cod = {x["contacto_id"]: x for x in c.get("/api/pedidos/revendedoras").json()}[ana["id"]]["codigo"]
    t = c.post("/api/publico/roles-387-qa/cliente/acceso", json={"telefono": "81110001", "pin": "1234", "codigo": cod})
    assert t.status_code == 200, t.text
    supervisor = {"ver", "escribir", "facturar", "catalogos", "inventario", "cobros", "pos"}      # rol propio «Supervisor de caja» del comercio
    for rol, permisos, esperado in (("Avanzado", None, 200), ("Vendedor", None, 200), ("Supervisor de caja", supervisor, 200),
                                    ("Cajero", None, 403), ("Solo lectura", None, 403)):
        ctx0 = _con_rol(rol, permisos)
        try:
            r = c.get("/api/pedidos/revendedoras")
            assert r.status_code == esperado, (rol, r.text)
            if esperado == 200:
                assert {x["contacto_id"]: x for x in r.json()}[ana["id"]]["codigo"] == cod
        finally:
            _restaurar(ctx0)
    cf = next(x for x in c.get("/api/pedidos/clientes").json() if x["telefono"] == "81110001")
    ctx0 = _con_rol("Cajero")
    try:
        assert c.delete(f"/api/pedidos/clientes/{cf['id']}").status_code == 403                    # la caja no libera teléfonos
    finally:
        _restaurar(ctx0)
    ctx0 = _con_rol("Vendedor")
    try:
        assert c.delete(f"/api/pedidos/clientes/{cf['id']}").json()["ok"] is True
    finally:
        _restaurar(ctx0)
    pub = _static("js", "fis", "pages", "publicar.js"); cli = _static("js", "fis", "pages", "clientes.js")
    assert "tab==='mayorista' && sesion.puede('catalogos')" in pub and pub.count("sesion.puede('catalogos')) this.cargarRevendedoras()") == 2
    assert "sesion.puede('configurar')) this.cargarRevendedoras" not in pub and "v-if=\"sesion.puede('catalogos')\" class=\"btn btn-light\"" in cli
    assert 'placeholder="Buscar por nombre o celular" @keydown.enter.prevent' in pub              # Enter en el buscador no guarda la página
    assert "código del negocio" not in (RAIZ / "sitio_web" / "ventas-en-linea.html").read_text(encoding="utf-8")


def test_restablecer_por_clave_olvidada_recupera_los_pedidos_con_su_enlace(api):  # noqa: F811
    c = api
    _a, b, _o, _g = _productos(c)
    assert _publicar(c, slug="olvido-387-qa", minimo_pedido=0).status_code == 200
    base = "/api/publico/olvido-387-qa"
    lineas = [{"producto_id": b["id"], "cantidad": 2}]
    t = c.post(base + "/cliente/acceso", json={"telefono": "87001111", "pin": "1111", "nombre": "Cliente QA"}).json()
    H1 = {"X-Cliente": t["token"]}
    ped = c.post(base + "/pedido", json={"nombre": "Cliente QA", "telefono": "87001111", "tipo": "recoger", "lineas": lineas}, headers=H1).json()
    para_otro = c.post(base + "/pedido", json={"nombre": "Para mi mamá", "telefono": "88880001", "tipo": "recoger", "lineas": lineas}, headers=H1).json()
    assert ped["cliente_final_id"] and ped["cliente_final_id"] == para_otro["cliente_final_id"]
    cf = next(x for x in c.get("/api/pedidos/clientes").json() if x["telefono"] == "87001111")
    assert c.delete(f"/api/pedidos/clientes/{cf['id']}").json()["ok"] is True                    # olvidó la clave
    # otra persona (otro teléfono) que tenga el enlace no se lo lleva
    ajeno = c.post(base + "/cliente/acceso", json={"telefono": "86002222", "pin": "2222", "nombre": "Ajeno QA"}).json()
    HA = {"X-Cliente": ajeno["token"]}
    assert c.get(f"{base}/pedido/{ped['token']}", headers=HA).status_code == 200
    assert c.get(base + "/mis-pedidos", headers=HA).json()["pedidos"] == []
    # el cliente crea su acceso nuevo: no hereda nada solo, y cada pedido vuelve al abrir su enlace de seguimiento
    t2 = c.post(base + "/cliente/acceso", json={"telefono": "87001111", "pin": "3333", "nombre": "Cliente QA"}).json()
    H2 = {"X-Cliente": t2["token"]}
    assert c.get(base + "/mis-pedidos", headers=H2).json()["pedidos"] == []
    assert c.get(f"{base}/pedido/{ped['token']}", headers=H2).status_code == 200
    assert [p["numero"] for p in c.get(base + "/mis-pedidos", headers=H2).json()["pedidos"]] == [ped["numero"]]
    # un pedido hecho para otro teléfono no se mueve (el teléfono del pedido no es el del acceso)
    c.get(f"{base}/pedido/{para_otro['token']}", headers=H2)
    assert [p["numero"] for p in c.get(base + "/mis-pedidos", headers=H2).json()["pedidos"]] == [ped["numero"]]
    # el pedido de un acceso vigente no pasa a otra cuenta aunque se abra su enlace
    c3 = c.post(base + "/cliente/acceso", json={"telefono": "86003333", "pin": "4444", "nombre": "Vigente QA"}).json()
    H3 = {"X-Cliente": c3["token"]}
    suyo = c.post(base + "/pedido", json={"nombre": "Vigente QA", "telefono": "86003333", "tipo": "recoger", "lineas": lineas}, headers=H3).json()
    c.get(f"{base}/pedido/{suyo['token']}", headers=H2)
    assert [p["numero"] for p in c.get(base + "/mis-pedidos", headers=H3).json()["pedidos"]] == [suyo["numero"]]
