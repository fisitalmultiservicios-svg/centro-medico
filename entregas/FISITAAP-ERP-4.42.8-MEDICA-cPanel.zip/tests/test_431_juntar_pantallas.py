# -*- coding: utf-8 -*-
"""4.31, al juntar: los ganchos de la estación de comandas en la caja y en Cocina (diseño exe430/diseno_estacion.md, 4.2 puntos 4 y 5).

- caja.js: solo llamadas de una línea a pos/_estacion.js (el import, iniciar y parar, la pasada al final de sincronizar, el resumen en
  revisarOnline y el aviso al cobrar o cargar a la habitación, antes de quitar la cuenta).
- cocina.js (Node, el módulo real): carga _estacion.js al abrirse (si no carga, sigue como antes), la pasada al final de refrescar, la
  banda, «Imprimir» de un pedido en línea pasa primero por la estación (8.4: con «ocupada» y sin confirmar no imprime) y las cuentas en
  línea van a las impresoras de la caja de la cuenta.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import re

from tests.test_425_ultimos_pantallas import MONTAR, _node
from tests.test_429_pedido_web_comanda import FALSO_AGENTE, FALSO_API, NAVEGADOR, _js


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def test_caja_llama_a_la_estacion_en_una_linea_en_cada_lugar():
    """4.31 (tercera vuelta): la caja carga _estacion.js al abrirse, como Cocina (import dinámico): si el módulo no carga, la caja sigue
    como antes. Cada llamada es de una línea y pasa por `this._est`."""
    k = _js("pages/pos/caja.js")
    assert "from './_estacion.js'" not in k                                              # sin import fijo: un fallo del módulo no tumba la caja
    assert "import('./_estacion.js').then(E => { if (this._fuera) return; this._est = E; E.iniciarEstacion('caja'); }).catch(() => {});" in _tramo(k, "  async created() {", "\n  mounted()")
    sinc = _tramo(k, "    async sincronizar() {", "\n    },\n")
    assert sinc.rstrip().endswith("if (this._est) this._est.revisarEstacion('caja');   /* 4.31: estación de comandas (sin esperar; no lanza) */")
    assert sinc.index("this.sync++;") < sinc.index("this._est.revisarEstacion('caja');")
    online = _tramo(k, "    async revisarOnline() {", "\n    },\n")
    assert online.index("const r = await api('/api/pedidos/resumen');") < online.index("if (this._est) this._est.guardarResumen(r);") < online.index("this.online = {")
    cobro = _tramo(k, "    async emitirCobro(otra) {", "\n    },\n")
    assert cobro.index("const idFin = this.esperaId || esperaId;") < cobro.index("if (this._est) this._est.avisarSiPendiente(idFin);") < cobro.index("if (idFin) { this.bajaCuenta(idFin,")
    hab = _tramo(k, "    cargarAHabitacion() {", "\n    },\n")
    assert hab.index("if (this._est) this._est.avisarSiPendiente(esperaId);") < hab.index("if (esperaId) this.bajaCuenta(esperaId,")
    assert _tramo(k, "  beforeUnmount() {", "\n").rstrip().endswith("if (this._est) this._est.pararEstacion('caja'); },")
    # ninguna se espera ni bloquea, todas pasan por el módulo cargado, y no hay más llamadas que esas
    for f in ("revisarEstacion(", "guardarResumen(", "avisarSiPendiente(", "iniciarEstacion(", "pararEstacion("):
        assert "await " + f not in k and "await this._est." + f not in k and "await E." + f not in k
    assert [len(re.findall(r"\b" + f + r"\(", k)) for f in ("revisarEstacion", "guardarResumen", "avisarSiPendiente", "iniciarEstacion", "pararEstacion")] == [1, 1, 2, 1, 1]
    assert [len(re.findall(r"(?<![\w.])" + f + r"\(", k)) for f in ("revisarEstacion", "guardarResumen", "avisarSiPendiente", "iniciarEstacion", "pararEstacion")] == [0, 0, 0, 0, 0]
    assert k.count("if (this._est) this._est.") == 5 and k.count("E.iniciarEstacion('caja')") == 1


def test_cocina_llama_a_la_estacion():
    c = _js("pages/pos/cocina.js")
    assert "from './_estacion.js'" not in c                                              # se carga al abrir la pantalla: si falla, Cocina sigue
    assert "import('./_estacion.js').then(E => {" in _tramo(c, "  created() {", "\n  beforeUnmount()")
    assert "if (this._est) this._est.pararEstacion('cocina');" in _tramo(c, "  beforeUnmount() {", "\n")
    assert "this.reloj = Date.now(); if (this._est) this._est.revisarEstacion('cocina');" in c
    imp = _tramo(c, "    async imprimir(t) {", "    async refrescar()")
    # 4.31 (corrección): la estación decide primero; la marca de Cocina solo en los platos que salieron; lo que no es de la copia, como hoy
    assert imp.splitlines()[1].strip().startswith("const enLinea = this._est ? await this._est.imprimirCocinaEnLinea(t, ls => this.aplicar(t.cuenta.id,")
    assert imp.splitlines()[2].strip() == "if (enLinea === true) return;"
    assert imp.splitlines()[3].strip().startswith("if (enLinea && Array.isArray(enLinea.resto)) t = { ...t, lineas: enLinea.resto, impresa: false };")
    assert "{{textoEstacion()}}" in c and "estEstado.lista" in c and "{{textoListaCocina}}" in c and '@click="imprimirListaCocina(x.pedido_id)"' in c


COC = "{ id: 'c', nombre: 'Cocina', conexion: 'usb' }"
BAR = "{ id: 'b', nombre: 'Bar del salón', conexion: 'usb' }"
FALSO_DATOS = """
const T1 = { id: 1, nombre: 'Caja 1' }, T2 = { id: 2, nombre: 'Caja terraza' };
export const enEspera = () => globalThis.Q.espera || [], impresorasComanda = () => [], categorias = () => [], terminales = () => [T1, T2], terminalActual = () => T1;
export const impresoraDe = (p, cats, term) => (term && term.id === 2 ? %s : %s);
""" % (BAR, COC)
FALSO_ESTACION = """
const Q = globalThis.Q;
export const estadoEstacion = { lista: [{ pedido_id: 9, numero: 45, texto: '#45 · hace 2 min' }] }, TEXTO_LISTA_COCINA = 'Pedidos en línea con la comanda sin imprimir:';
export const iniciarEstacion = o => Q.est.push('iniciar:' + o), pararEstacion = o => Q.est.push('parar:' + o), revisarEstacion = o => Q.est.push('revisar:' + o);
export const textoEstacion = () => 'Las comandas de los pedidos en línea salen solas en esta computadora.';
export const imprimirListaCocina = id => Q.est.push('lista:' + id);
export const imprimirCocinaEnLinea = async (t, marcar) => { Q.est.push('en_linea:' + t.cuenta.id); if (Q.marcarCon) await marcar(Q.marcarCon(t)); else if (Q.respuesta) await marcar(); return Q.respuesta; };
"""
FALSO_APP = "export const sesion = { empresa_id: 1, usuario: { correo: 'cocina-431@example.test' }, empresaInfo: {} };\nexport const store = { productos: [{ id: 1, categoria: 'Platos' }, { id: 2, categoria: 'Bebidas' }] };\n"

GUION = NAVEGADOR.replace("Date.prototype", "const Q = globalThis.Q = { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0, est: [] };\nDate.prototype", 1) + MONTAR + """
globalThis.setInterval = () => 1; globalThis.clearInterval = () => {};
const K = (await import('./js/pages/pos/cocina.js')).default;
const out = {};
const E = '2026-11-12T16:30:00Z';
Q.espera = [
  { id: 5, nombre: 'Pedido #45 · Ana', canal: 'online', pedido_id: 9, terminal_id: 2, creado: E, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: E, ronda: 1 }] },
  { id: 6, nombre: 'Mesa 3', mesa_id: 3, terminal_id: 2, lineas: [{ producto_id: 2, detalle: 'Fresco', cantidad: 1, enviado: E, ronda: 1 }] },
  { id: 7, nombre: 'Pedido #46 · Luis', canal: 'online', pedido_id: 10, terminal_id: 99, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: E, ronda: 1 }] }];
Q.datos.pos_espera = JSON.parse(JSON.stringify(Q.espera));
const vm = montar(K);
// el pedido en línea va a la impresora de la caja de su cuenta (terraza → Bar); la mesa y una caja que ya no existe, a la de esta computadora
out.imps = vm.tickets.map(t => [t.cuenta.id, t.lineas[0].imp.nombre]).sort();
// antes de cargar la estación: sin banda; «Imprimir» como hoy
out.sinModulo = [vm.textoEstacion(), vm.estEstado];
K.created.call(vm); for (let i = 0; i < 50; i++) await new Promise(r => setImmediate(r));   /* el import de la estación */
out.cargada = [vm.textoEstacion(), vm.textoListaCocina, vm.estEstado && vm.estEstado.lista.length, Q.est.slice()];
await vm.refrescar(); out.refrescar = Q.est.slice(-1);
vm.imprimirListaCocina(9); out.lista = Q.est.slice(-1);
// 8.4: la estación resolvió (impresa o «ocupada» sin confirmar): Cocina no imprime nada más; con «hecho», la marca de hoy
const t = vm.tickets.find(x => x.cuenta.id === 5);
Q.respuesta = true; Q.docs = []; Q.abiertas = 0; await vm.imprimir(t);
out.resuelta = [Q.docs.length, Q.abiertas, Q.datos.pos_espera.find(x => x.id === 5).lineas.every(l => l.impreso === true), Q.est.slice(-1)];
Q.datos.pos_espera = JSON.parse(JSON.stringify(Q.espera));
// la estación dice «sigue como hoy» (cuenta sin copia, reimpresión): Cocina imprime como siempre
Q.respuesta = false; Q.docs = []; await vm.imprimir(t); for (let i = 0; i < 50; i++) await new Promise(r => setImmediate(r));   /* la marca de hoy no se espera */
out.comoHoy = [Q.docs.map(d => d.bloques[0].x), Q.datos.pos_espera.find(x => x.id === 5).lineas.every(l => l.impreso === true)];
// al salir se detiene
K.beforeUnmount.call(vm); out.salir = Q.est.slice(-1);
console.log(JSON.stringify(out));
process.exit(0);
"""


def _falsos(con_estacion: bool) -> dict:
    f = {"api.js": FALSO_API, "app.js": FALSO_APP, "pages/pos/_datos.js": FALSO_DATOS, "pages/pos/_agente.js": FALSO_AGENTE,
         "pages/pos/_agente_real.js": _js("pages/pos/_agente.js")}
    if con_estacion:
        f["pages/pos/_estacion.js"] = FALSO_ESTACION
    return f


def test_cocina_con_la_estacion_en_node(tmp_path):
    r = _node(tmp_path, GUION, archivos=("pages/pos/cocina.js",), falsos=_falsos(True))
    assert r["imps"] == [[5, "Bar del salón"], [6, "Cocina"], [7, "Cocina"]], r
    assert r["sinModulo"] == ["", None], r
    assert r["cargada"] == ["Las comandas de los pedidos en línea salen solas en esta computadora.", "Pedidos en línea con la comanda sin imprimir:", 1, ["iniciar:cocina"]], r
    assert r["refrescar"] == ["revisar:cocina"] and r["lista"] == ["lista:9"], r
    assert r["resuelta"] == [0, 0, True, ["en_linea:5"]], r
    assert r["comoHoy"] == [["BAR DEL SALÓN"], True], r
    assert r["salir"] == ["parar:cocina"], r


def test_cocina_marca_solo_lo_que_salio_y_lo_de_fuera_de_la_copia_como_hoy(tmp_path):
    """4.31 (corrección, «Imprimir» de una tarjeta): la marca «impreso» de Cocina va solo en los platos que la estación dice que salieron
    (antes: todos los de la ronda, también los que otra computadora tenía o que no salieron), y los platos de la tarjeta que no son de la copia
    de la comanda (`resto`) se imprimen como siempre, solos."""
    guion = GUION.split("// 8.4:")[0] + """
Q.espera = [{ id: 8, nombre: 'Pedido #48 · Eva', canal: 'online', pedido_id: 12, terminal_id: 1, creado: E, lineas: [
  { producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: E, ronda: 1 }, { producto_id: 2, detalle: 'Limonada', cantidad: 2, enviado: E, ronda: 1 }] }];
const fresco = () => { Q.datos.pos_espera = JSON.parse(JSON.stringify(Q.espera)); };
const impresos = () => Q.datos.pos_espera[0].lineas.map(l => [l.detalle, !!l.impreso]);
// solo salió la Limonada (la Casado la tenía otra computadora y se contestó «No»): solo ella queda marcada
fresco(); Q.respuesta = true; Q.marcarCon = t => t.lineas.filter(l => l.detalle === 'Limonada'); Q.docs = [];
await vm.imprimir(vm.tickets.find(x => x.cuenta.id === 8)); out.soloLimonada = [impresos(), Q.docs.length];
// sin nada que salió: no se marca nada
fresco(); Q.marcarCon = () => []; await vm.imprimir(vm.tickets.find(x => x.cuenta.id === 8)); out.nada = impresos();
// la Casado no es de la copia: Cocina la imprime como hoy, sola, y la marca; la Limonada salió desde la copia
fresco(); Q.marcarCon = t => t.lineas.filter(l => l.detalle === 'Limonada'); Q.docs = [];
const t8 = vm.tickets.find(x => x.cuenta.id === 8); Q.respuesta = { resto: t8.lineas.filter(l => l.detalle === 'Casado') };
await vm.imprimir(t8); for (let i = 0; i < 50; i++) await new Promise(r => setImmediate(r));
out.resto = [impresos(), Q.docs.map(d => d.bloques.filter(b => b.t === 'item').map(b => b.x))];
K.beforeUnmount.call(vm);
console.log(JSON.stringify(out));
process.exit(0);
"""
    r = _node(tmp_path, guion, archivos=("pages/pos/cocina.js",), falsos=_falsos(True))
    assert r["soloLimonada"] == [[["Casado", False], ["Limonada", True]], 0], r
    assert r["nada"] == [["Casado", False], ["Limonada", False]], r
    assert r["resto"] == [[["Casado", True], ["Limonada", True]], [["Casado"]]], r


def test_cocina_sin_el_modulo_de_la_estacion_sigue_como_antes(tmp_path):
    guion = GUION.split("// 8.4:")[0] + """
Q.respuesta = true; Q.docs = []; await vm.imprimir(vm.tickets.find(x => x.cuenta.id === 5));
out.imprime = Q.docs.map(d => d.bloques[0].x);
K.beforeUnmount.call(vm);
console.log(JSON.stringify(out));
process.exit(0);
"""
    r = _node(tmp_path, guion, archivos=("pages/pos/cocina.js",), falsos=_falsos(False))
    assert r["cargada"][0] == "" and r["cargada"][2] is None and r["cargada"][3] == [], r      # el import falló: sin banda, sin pasadas
    assert r["refrescar"] == [] and r["imprime"] == ["BAR DEL SALÓN"], r                        # «Imprimir» como hoy
