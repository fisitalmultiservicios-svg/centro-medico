"""3.70: matriz de módulos por empresa y por usuario (lo apagado sale del menú y de los permisos, los datos no se tocan), módulos que
nacen apagados según el tipo de negocio, y contraseña temporal fácil de recordar que cumple la política."""
import re
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, planes
from app.db import Empresa, engine, init_db


def test_ocultos_por_tipo_y_clave_facil():
    assert "hotel" in planes.ocultos_por_tipo("comercio") and "pos" not in planes.ocultos_por_tipo("comercio") and "tike" not in planes.ocultos_por_tipo("comercio")
    assert "tike" in planes.ocultos_por_tipo("comercio", prueba=True) and "tike" not in planes.ocultos_por_tipo("servicios", prueba=True)
    assert {"pos", "hotel", "pedidos_online"} <= set(planes.ocultos_por_tipo("servicios")) and "reportes" not in planes.ocultos_por_tipo("servicios")
    assert planes.ocultos_por_tipo("otro") == []
    vistas = set()
    for _ in range(30):
        c = auth.clave_facil()
        assert re.fullmatch(r"[A-Z][a-z]+-[A-Z][a-z]+-\d{4}", c), c
        auth.validar_password(c, "cliente@example.test")        # no levanta
        vistas.add(c)
    assert len(vistas) > 20


@pytest.fixture()
def empresa():
    from app.main import app
    init_db()
    with Session(engine) as s:
        for n in ("Módulos QA Comercio S.A.",):
            v = s.exec(select(Empresa).where(Empresa.nombre == n)).first()
            if v:
                s.delete(v); s.commit()
        e = auth.crear_empresa(s, "Módulos QA Comercio S.A.", "modulos370@example.test", "3101370370", tipo_negocio="comercio")
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "cajera370@example.test")).first()
        if not u:
            u = auth.Usuario(correo="cajera370@example.test", nombre="Cajera 370", password_hash=auth.hash_password("Clave-370-qa"))
            s.add(u); s.commit(); s.refresh(u)
        for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
            s.delete(m)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Administrador")); s.commit()
        s.refresh(e); s.refresh(u)
        eid, uid = e.id, u.id
        admin = types.SimpleNamespace(id=None, correo="admin370@example.test", es_superadmin=False, nombre="Admin")
        ctx = auth.Contexto(admin, e, "Administrador")
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), eid, uid, ctx
    finally:
        app.dependency_overrides.clear()


def test_matriz_por_empresa_y_por_usuario(empresa):
    c, eid, uid, ctx = empresa
    with Session(engine) as s:
        e = s.get(Empresa, eid)
        assert "hotel" in planes.ocultos_de(e) and "tike" not in planes.ocultos_de(e)      # comercio real: TiKe sigue disponible como extra
        assert "hotel" not in planes.modulos_de(e) and "pos" in planes.modulos_de(e) and "contabilidad" in planes.modulos_de(e)
    m = c.get("/api/auth/modulos").json()
    codigos = [x["codigo"] for x in m["disponibles"]]
    assert "pos" in codigos and "hotel" in codigos and m["ocultos"] == planes.ocultos_de(e) and any(x["nombre"] == "Punto de venta" for x in m["disponibles"])
    # apagar contabilidad y tike para toda la empresa
    assert c.put("/api/auth/modulos", json={"ocultos": ["hotel", "contabilidad", "tike", "noexiste"]}).status_code == 400
    r = c.put("/api/auth/modulos", json={"ocultos": ["hotel", "contabilidad", "tike"]})
    assert r.status_code == 200 and r.json()["ocultos"] == ["contabilidad", "hotel", "tike"]
    with Session(engine) as s:
        e = s.get(Empresa, eid); u = s.get(auth.Usuario, uid)
        assert "contabilidad" not in planes.modulos_de(e) and "contabilidad" in planes.info(e)["ocultos"] and "contabilidad" in planes.info(e)["disponibles"]
        p = auth._permisos_sesion(s, u, eid, "Administrador")
        assert "contabilidad" not in p and "tike" not in p and "rrhh" in p and "facturar" in p
        # por usuario: además se apaga rrhh solo para la cajera
        ctx.empresa = e
    r = c.put(f"/api/auth/usuarios/{uid}", json={"rol": "Administrador", "modulos_ocultos": ["rrhh"]})
    assert r.status_code == 200 and r.json()["modulos_ocultos"] == ["rrhh"]
    lista = c.get("/api/auth/usuarios").json()
    assert next(x for x in lista if x["id"] == uid)["modulos_ocultos"] == ["rrhh"]
    with Session(engine) as s:
        u = s.get(auth.Usuario, uid)
        p = auth._permisos_sesion(s, u, eid, "Administrador")
        assert "rrhh" not in p and "facturar" in p
        emp = next(x for x in auth._empresas_de(s, u) if x["id"] == eid)
        assert "rrhh" not in emp["plan"]["modulos"] and "contabilidad" not in emp["plan"]["modulos"] and "pos" in emp["plan"]["modulos"] and emp["plan"]["ocultos_usuario"] == ["rrhh"]
    # volver a encender todo
    assert c.put(f"/api/auth/usuarios/{uid}", json={"rol": "Administrador", "modulos_ocultos": []}).json()["modulos_ocultos"] == []
    assert c.put("/api/auth/modulos", json={"ocultos": []}).json()["ocultos"] == []
    with Session(engine) as s:
        assert "contabilidad" in planes.modulos_de(s.get(Empresa, eid))
