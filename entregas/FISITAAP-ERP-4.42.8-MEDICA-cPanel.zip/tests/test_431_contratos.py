# -*- coding: utf-8 -*-
"""4.31, al juntar las cuatro partes: lo que cada pantalla manda y lee es lo que el servidor de verdad recibe y responde.

- La misma mesa (diseño exe430/diseno_mesa.md, 5): los elementos con `_fusion`, las altas y la condición de una baja se arman en Node con
  pos/_fusion.js tal cual (como persistirCuenta, cocina «aplicar» y bajaCuenta) y se mandan a la ruta real POST /api/registros/pos_espera/
  cambios. Lo que queda guardado es EXACTAMENTE lo que la pantalla predice con la misma regla (fusionarCuenta / cerrarCuenta), y la
  respuesta trae `fusionados` / `conservados` como listas de ids (lo que lee api.js).
- La estación de comandas (diseño exe430/diseno_estacion.md, 5): la copia real de GET /api/pos/comanda/pendientes y el resumen real pasan
  por pos/_comandas.js en Node (huella, posiciones, grupos por impresora); los cuerpos que arma la pantalla (reclamarComanda,
  marcarComandaImpresa, soltarComanda) se mandan tal cual a las rutas reales y el servidor responde lo que la pantalla espera.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest
from sqlmodel import Session

from app import comandas, modulos
from app.db import engine_empresa
from tests.test_387_r4_caja import Entorno
from tests.test_425_ultimos_pantallas import _node
from tests.test_429_pedido_web_comanda import FALSO_AGENTE, _cuenta, _js
from tests.test_431_estacion_servidor import _aceptar, _negocio, _pedido3, sin_limite  # noqa: F401  (fixture)
from tests.test_431_fusion_cruzada import _igual
from tests.test_exoneraciones import api  # noqa: F401  (fixture)

E1, E2, E3 = "2026-11-12T12:00:00.000Z", "2026-11-12T12:01:00.000Z", "2026-11-12T12:02:00.000Z"


def _plato(pid, det, precio, enviado, ronda):
    m = precio
    return {"producto_id": pid, "detalle": det, "cantidad": 1, "precio_unitario": precio, "tarifa": 13, "descuento_pct": 0, "descuento": 0, "nota": "",
            "enviado": enviado, "ronda": ronda, "importe": round(m * 1.13, 5), "importe_de": [1, precio, 0, 0]}


# ================================================================================================================ la misma mesa
@pytest.fixture()
def rest():
    x = Entorno("restaurante")
    x.usuario("admin", "Administrador")
    try:
        yield x
    finally:
        x.limpiar()


def _post(x, cuerpo):
    r = x.c.post("/api/registros/pos_espera/cambios", json=cuerpo, headers=x.h("admin"))
    assert r.status_code == 200, r.text
    return r.json()


def _guardada(x, iid):
    r = x.c.get("/api/registros/pos_espera", headers=x.h("admin"))
    assert r.status_code == 200 and "_fusion" not in r.text, r.text
    return next((v for v in r.json()["datos"] if v["id"] == iid), None)


PANTALLA_MESA = """
const F = await import('./js/pages/pos/_fusion.js');
const fs = await import('node:fs');
const D = JSON.parse(fs.readFileSync('./datos.json', 'utf-8'));
const copia = v => JSON.parse(JSON.stringify(v));
const out = {};
const G = F.ponerLids(copia(D.guardada));
// como persistirCuenta: la base es lo que la pantalla sabía; las líneas nuevas llevan un lid nuevo; _fusion con lo que cambió
const guardar = (base, agregar, cuenta) => {
  const lineas = copia(base.lineas).concat(agregar.map(l => ({ ...l, lid: F.nuevoLid() })));
  const x = { ...copia(base), ...(cuenta || {}), lineas, actualizado: D.ahora };
  const cambios = Object.keys(cuenta || {});
  return { ...x, _fusion: F.conFusion(null, F.diferencia(base.lineas, lineas), cambios, 'caja') };
};
out.b = guardar(G, [D.limonada]);                              // B agrega la Limonada
out.a = guardar(G, [D.postre], { nota: 'Sin prisa' });         // A, con su copia de antes de la Limonada, agrega el Postre y una nota
out.pred1 = F.fusionarCuenta(G, out.b);
out.pred2 = F.fusionarCuenta(out.pred1, out.a);
// la cocina marca «listo» la Limonada (cocina.js aplicar)
const limonada = out.pred2.lineas.find(l => l.detalle === 'Limonada');
out.cocina = F.conFusionDe(F.ponerLids(copia(out.pred2)), { ...copia(out.pred2), lineas: out.pred2.lineas.map(l => (l.lid === limonada.lid ? { ...l, listo: D.ahora } : { ...l })) }, 'cocina');
out.pred3 = F.fusionarCuenta(out.pred2, out.cocina);
// A cobra lo que tenía en pantalla (Casado y Postre) y cierra la cuenta con su condición (bajaCuenta)
out.cond = F.condicionDe(G.id, out.a.lineas);
out.pred4 = F.cerrarCuenta(out.pred3, out.cond);
// un guardado con _fusion que llega después del cierre: la pantalla espera la cuenta recreada solo con lo que agregó
out.tarde = guardar(out.pred4 ? copia(out.pred4) : G, [D.cafe]);
console.log(JSON.stringify(out));
"""


def test_mesa_lo_que_manda_la_pantalla_es_lo_que_el_servidor_guarda(rest, tmp_path):
    x = rest
    alta = {"id": 1, "nombre": "Mesa 6", "mesa_id": 6, "mesas_ids": [6], "terminal_id": 1, "salonero": "", "servicio": False, "servicio_pct": 10,
            "cliente_id": None, "nota": "", "lineas": [_plato(1, "Casado", 3500, E1, 1)], "cobros": [], "partes": None, "total": 3955}
    r = _post(x, {"upserts": [alta], "deletes": [], "nuevos": [1]})          # las altas van sin _fusion (persistirCuenta)
    assert set(r) == {"ok", "clave", "version", "remap", "ultimo_id"}, r
    g = _guardada(x, 1)
    (tmp_path / "datos.json").write_text(json.dumps({"guardada": g, "ahora": "2026-11-12T12:05:00.000Z", "limonada": _plato(2, "Limonada", 1500, E2, 2),
                                                      "postre": _plato(3, "Postre", 1200, E3, 2), "cafe": _plato(4, "Café", 900, E3, 3)}), encoding="utf-8")
    p = _node(tmp_path, PANTALLA_MESA, archivos=("pages/pos/_fusion.js",), falsos={})
    assert p["b"]["_fusion"]["origen"] == "caja" and len(p["b"]["_fusion"]["nuevas"]) == 1 and p["b"]["_fusion"]["equipo"].startswith("e")
    # B: nada que unir (la respuesta de siempre); A atrasado: se une y la respuesta lo dice como lo lee api.js
    r = _post(x, {"upserts": [p["b"]], "deletes": [], "nuevos": []})
    assert "fusionados" not in r and "conservados" not in r, r
    assert _igual(_guardada(x, 1), p["pred1"])
    r = _post(x, {"upserts": [p["a"]], "deletes": [], "nuevos": []})
    assert r["fusionados"] == [1] and "conservados" not in r, r
    g2 = _guardada(x, 1)
    assert _igual(g2, p["pred2"]), (g2, p["pred2"])
    assert [l["detalle"] for l in g2["lineas"]] == ["Casado", "Limonada", "Postre"] and g2["nota"] == "Sin prisa" and g2["total"] == 3955 + 1695 + 1356
    # la cocina: solo su marca
    _post(x, {"upserts": [p["cocina"]], "deletes": [], "nuevos": []})
    assert _igual(_guardada(x, 1), p["pred3"])
    # la baja con la condición que arma la pantalla: la Limonada de B queda (conservados), como predice cerrarCuenta
    assert p["cond"]["v"] == 1 and len(p["cond"]["quitadas"]) == 2
    r = _post(x, {"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": p["cond"]}})
    assert r["conservados"] == [1], r
    g4 = _guardada(x, 1)
    assert p["pred4"] is not None and _igual(g4, p["pred4"]) and [l["detalle"] for l in g4["lineas"]] == ["Limonada"]
    # se cierra la Limonada; el Café que otro equipo guarda después llega a una cuenta recreada (remap, como lo sigue api.js)
    r = _post(x, {"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": {"v": 1, "quitadas": {g4["lineas"][0]["lid"]: 1}}}})
    assert "conservados" not in r and _guardada(x, 1) is None
    r = _post(x, {"upserts": [p["tarde"]], "deletes": [], "nuevos": []})
    nuevo = int(r["remap"]["1"])
    assert r["fusionados"] == [nuevo], r
    rec = _guardada(x, nuevo)
    assert rec["recreada_de"] == 1 and [l["detalle"] for l in rec["lineas"]] == ["Café"] and rec["cobros"] == [] and rec["partes"] is None


PANTALLA_COBRO = """
const F = await import('./js/pages/pos/_fusion.js');
const fs = await import('node:fs');
const D = JSON.parse(fs.readFileSync('./datos.json', 'utf-8'));
const copia = v => JSON.parse(JSON.stringify(v));
const G = F.ponerLids(copia(D.guardada)), out = {};
// la caja cobra lo que tenía en pantalla (el Casado) y cierra con la condición de un cobro (bajaCuenta(..., true)); otro equipo había
// agregado Limonadas: la cuenta queda con ellas y sin lo ya pagado del pedido en línea
out.cond = F.condicionDe(G.id, [G.lineas[0]], true);
out.pred1 = F.cerrarCuenta(copia(G), out.cond);
// dos equipos parten a la vez las Limonadas (×2, cobran 1 cada uno): cada uno guarda su resto con la marca de origen (restoDe)
const parte = (base) => { const resto = F.restoDe(base.lineas[0], 1); return { ...copia(base), lineas: [resto], _fusion: F.conFusion(null, F.diferencia(base.lineas, [resto]), [], 'caja') }; };
out.a = parte(out.pred1); out.b = parte(out.pred1);
out.pred2 = F.fusionarCuenta(copia(out.pred1), out.a);
out.pred3 = F.fusionarCuenta(copia(out.pred2), out.b);
// 4.31 (cuarta vuelta): un tercer equipo tenía las dos Limonadas enteras en pantalla y las cobra; su baja (cobro) se lleva también el resto
// que dejaron los otros dos al partirlas (`de` = la Limonada que él cobró)
out.cond4 = F.condicionDe(G.id, [out.pred1.lineas[0]], true);
out.pred4 = F.cerrarCuenta(copia(out.pred3), out.cond4);
out.cond5 = F.condicionDe(G.id, [out.pred1.lineas[0]], false);
out.pred5 = F.cerrarCuenta(copia(out.pred3), out.cond5);
console.log(JSON.stringify(out));
"""


def test_mesa_cobro_y_resto_partido_pantalla_y_servidor_dan_lo_mismo(rest, tmp_path):
    """4.31 (corrección): la condición de una baja por cobro (`cobro: true`) y el resto de una línea partida (`de`), armados en Node con
    pos/_fusion.js como en la caja, van a la ruta real y lo guardado es exactamente lo que predice la pantalla."""
    x = rest
    online = {"canal": "online", "pedido_id": 7, "pedido_numero": 7, "prepago": {"monto": 3955, "online": 3955}, "cupon": "QA", "puntos_canjeados": 10, "credito": False}
    alta = {"id": 1, "nombre": "Pedido #7", "mesa_id": 6, "mesas_ids": [6], "terminal_id": 1, "salonero": "", "servicio": False, "servicio_pct": 10,
            "cliente_id": None, "nota": "", "lineas": [_plato(1, "Casado", 3500, E1, 1), {**_plato(2, "Limonada", 1500, E2, 2), "cantidad": 2, "importe": 3390.0, "importe_de": [2, 1500, 0, 0]}],
            "cobros": [], "partes": None, "total": 7345, **online}
    with Session(engine_empresa(x.eid)) as se:
        modulos.aplicar_cambios(se, x.eid, "pos_espera", [alta], [], [1])
        se.commit()
    g = _guardada(x, 1)
    (tmp_path / "datos.json").write_text(json.dumps({"guardada": g}), encoding="utf-8")
    p = _node(tmp_path, PANTALLA_COBRO, archivos=("pages/pos/_fusion.js",), falsos={})
    assert p["cond"]["cobro"] is True and len(p["cond"]["quitadas"]) == 1
    r = _post(x, {"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": p["cond"]}})
    assert r["conservados"] == [1], r
    g1 = _guardada(x, 1)
    assert _igual(g1, p["pred1"]), (g1, p["pred1"])
    assert g1["prepago"] is None and g1["cupon"] is None and g1["puntos_canjeados"] == 0 and [l["detalle"] for l in g1["lineas"]] == ["Limonada"]
    _post(x, {"upserts": [p["a"]], "deletes": [], "nuevos": []})
    assert _igual(_guardada(x, 1), p["pred2"])
    r = _post(x, {"upserts": [p["b"]], "deletes": [], "nuevos": []})                 # el resto del otro equipo no se agrega otra vez
    assert r["fusionados"] == [1], r
    g3 = _guardada(x, 1)
    assert _igual(g3, p["pred3"]) and [(l["detalle"], l["cantidad"]) for l in g3["lineas"]] == [("Limonada", 1)], g3
    # sin cobro (cond5) la pantalla predice que el resto queda; con el cobro (cond4) se va y la cuenta se cierra, en la pantalla y en el servidor
    assert p["pred5"] is not None and [l["lid"] for l in p["pred5"]["lineas"]] == [l["lid"] for l in g3["lineas"]], p["pred5"]
    assert g3["lineas"][0]["de"] == p["pred1"]["lineas"][0]["lid"] and p["cond4"]["cobro"] is True
    assert p["pred4"] is None, p["pred4"]
    r = _post(x, {"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": p["cond4"]}})
    assert "conservados" not in r, r
    assert _guardada(x, 1) is None


PANTALLA_VUELVE = """
const F = await import('./js/pages/pos/_fusion.js');
const fs = await import('node:fs');
const D = JSON.parse(fs.readFileSync('./datos.json', 'utf-8'));
const copia = v => JSON.parse(JSON.stringify(v));
const G = F.ponerLids(copia(D.guardada)), out = {};
const [lC, lL] = G.lineas;
// A abre «Cobrar la parte 1» con un Casado: en la cuenta deja el resto (Casado ×1, `de` = lC)
const resto = F.restoDe(lC, 1);
out.a1 = { ...copia(G), lineas: [resto, copia(lL)], _fusion: F.conFusion(null, F.diferencia(G.lineas, [resto, lL]), [], 'caja') };
out.pred1 = F.fusionarCuenta(copia(G), out.a1);
// B cobra lo que ve (el resto del Casado) y cierra con la condición de un cobro
const r1 = out.pred1.lineas.find(l => l.lid === resto.lid);
out.condB = F.condicionDe(G.id, [r1], true);
out.pred2 = F.cerrarCuenta(copia(out.pred1), out.condB);
// A cierra su cobro sin cobrar (con la copia de antes del cobro de B): suma la parte al resto y dice cuánto vuelve (devolverParte)
out.a2 = F.conFusionDe(F.ponerLids(copia(out.pred1)), { ...copia(out.pred1), lineas: out.pred1.lineas.map(l => (l.lid === r1.lid ? { ...l, cantidad: 2, importe: 7910, importe_de: [2, 3500, 0, 0] } : { ...l })) }, 'caja', { vuelve: { [r1.lid]: 1 } });
out.pred3 = F.fusionarCuenta(copia(out.pred2), out.a2);
// C parte las Limonadas (deja una, `de` = lL); D, atrasado, cobra en su parte las dos Limonadas enteras y lo dice (`enteras`)
const rL = F.restoDe(out.pred3.lineas.find(l => l.lid === lL.lid), 1);
const sinL = out.pred3.lineas.filter(l => l.lid !== lL.lid);
out.c1 = { ...copia(out.pred3), lineas: [...copia(sinL), rL], _fusion: F.conFusion(null, F.diferencia(out.pred3.lineas, [...sinL, rL]), [], 'caja') };
out.pred4 = F.fusionarCuenta(copia(out.pred3), out.c1);
out.d1 = F.conFusionDe(F.ponerLids(copia(out.pred3)), { ...copia(out.pred3), lineas: copia(sinL), cobros: [{ doc_id: 31, consecutivo: 'C31', monto: 3390 }] }, 'caja', { enteras: [lL.lid] });
out.pred5 = F.fusionarCuenta(copia(out.pred4), out.d1);
out.lids = { lC: lC.lid, lL: lL.lid, r1: r1.lid, rL: rL.lid };
console.log(JSON.stringify(out));
"""


def test_mesa_parte_que_vuelve_y_cobro_entero_pantalla_y_servidor_dan_lo_mismo(rest, tmp_path):
    """4.31 (quinta vuelta): `_fusion.vuelve` (la parte de un cobro cerrado sin cobrar vuelve sola si su plato ya se cobró) y `_fusion.enteras`
    (el resto que otro equipo dejó de lo que esta parte cobró entero sale con el cobro), armados en Node con pos/_fusion.js como en la caja,
    van a la ruta real y lo guardado es exactamente lo que predice la pantalla."""
    x = rest
    alta = {"id": 1, "nombre": "Mesa 6", "mesa_id": 6, "mesas_ids": [6], "terminal_id": 1, "salonero": "", "servicio": False, "servicio_pct": 10,
            "cliente_id": None, "nota": "", "cobros": [], "partes": None, "total": 11300,
            "lineas": [{**_plato(1, "Casado", 3500, E1, 1), "cantidad": 2, "importe": 7910.0, "importe_de": [2, 3500, 0, 0]},
                       {**_plato(2, "Limonada", 1500, E2, 2), "cantidad": 2, "importe": 3390.0, "importe_de": [2, 1500, 0, 0]}]}
    with Session(engine_empresa(x.eid)) as se:
        modulos.aplicar_cambios(se, x.eid, "pos_espera", [alta], [], [1])
        se.commit()
    (tmp_path / "datos.json").write_text(json.dumps({"guardada": _guardada(x, 1)}), encoding="utf-8")
    p = _node(tmp_path, PANTALLA_VUELVE, archivos=("pages/pos/_fusion.js",), falsos={})
    ids = p["lids"]
    assert p["a2"]["_fusion"]["vuelve"] == {ids["r1"]: 1} and p["d1"]["_fusion"]["enteras"] == [ids["lL"]], (p["a2"]["_fusion"], p["d1"]["_fusion"])
    _post(x, {"upserts": [p["a1"]], "deletes": [], "nuevos": []})
    assert _igual(_guardada(x, 1), p["pred1"])
    r = _post(x, {"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": p["condB"]}})
    assert r["conservados"] == [1] and _igual(_guardada(x, 1), p["pred2"]), r
    r = _post(x, {"upserts": [p["a2"]], "deletes": [], "nuevos": []})
    g3 = _guardada(x, 1)
    assert r["fusionados"] == [1] and _igual(g3, p["pred3"]), (r, g3, p["pred3"])
    assert [(l["lid"], l["detalle"], l["cantidad"]) for l in g3["lineas"]] == [(ids["lL"], "Limonada", 2), (ids["r1"] + "+v", "Casado", 1)], g3   # la parte no desaparece
    _post(x, {"upserts": [p["c1"]], "deletes": [], "nuevos": []})
    assert _igual(_guardada(x, 1), p["pred4"])
    _post(x, {"upserts": [p["d1"]], "deletes": [], "nuevos": []})
    g5 = _guardada(x, 1)
    assert _igual(g5, p["pred5"]), (g5, p["pred5"])
    assert [l["lid"] for l in g5["lineas"]] == [ids["r1"] + "+v"] and ids["rL"] in g5["lids_quitados"], g5          # el resto de las Limonadas sale con el cobro


# ================================================================================================================ la estación de comandas
PANTALLA_ESTACION = """
const C = await import('./js/pages/pos/_comandas.js');
const fs = await import('node:fs');
const D = JSON.parse(fs.readFileSync('./datos.json', 'utf-8'));
const out = {};
const pen = await C.pendientesComanda(async (url, opt) => { out.url_pendientes = url; return D.pendientes; }, { pedido_id: D.pedido_id });
out.pen = pen.resultado;
const copia = pen.copias.find(c => c.pedido_id === D.pedido_id);
out.huellas = copia.lineas.map(l => [l.huella, C.huellaLinea(D.cuenta.lineas[l.pos])]);
out.posiciones = C.posicionesDeCopia(D.cuenta.lineas.filter(l => l.enviado), copia);
out.libres = copia.lineas.map(l => C.platoLibre(l, pen.ahora, true, false));
const COC = { id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'usb' };
const g = C.gruposDeCopia(copia, { impresoras: [COC], categorias: [], extras: {}, productos: [], cfg: D.cfg, ahora: pen.ahora, paraEstacion: true });
out.grupos = g.grupos.map(x => [x.id, x.directo, x.pos]); out.sin = g.sin_comanda;
const cuerpos = [];
const pedir = async (url, opt) => { cuerpos.push([url, opt && opt.method, opt && opt.body]); return { resultado: 'ok' }; };
const equipo = C.nuevoEquipo();
await C.reclamarComanda(pedir, { pedido_id: copia.pedido_id, lineas: g.grupos[0].pos, grupo: String(g.grupos[0].id), grupo_nombre: g.grupos[0].imp.nombre, equipo, nombre: 'Caja QA · Caja', momento: 'aceptar' });
await C.soltarComanda(pedir, { pedido_id: copia.pedido_id, equipo, lineas: g.grupos[0].pos, motivo: 'la impresora «Cocina» no respondió' });
await C.reclamarComanda(pedir, { pedido_id: copia.pedido_id, lineas: g.grupos[0].pos, grupo: String(g.grupos[0].id), grupo_nombre: g.grupos[0].imp.nombre, equipo, nombre: 'Caja QA · Caja', momento: 'cocina' });
await C.marcarComandaImpresa(pedir, { pedido_id: copia.pedido_id, equipo, lineas: g.grupos[0].pos, sin_comanda: g.sin_comanda });
out.cuerpos = cuerpos;
console.log(JSON.stringify(out));
"""


def test_estacion_lo_que_manda_la_pantalla_es_lo_que_el_servidor_espera(api, sin_limite, tmp_path):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    cid = _aceptar(c, pid, reclama=True)                     # el PUT de la pantalla de Pedidos 4.31 (reclama: true)
    cuenta = _cuenta(eid, cid)
    pen = c.get(f"/api/pos/comanda/pendientes?pedido_id={pid}").json()
    res = c.get("/api/pedidos/resumen").json()
    # el resumen trae los dos campos nuevos con el tipo que lee la pantalla (guardarResumen / indicio)
    assert isinstance(res["comandas_pendientes"], int) and res["comandas_pendientes"] >= 1, res
    assert res["comanda_espera_s"] is None or isinstance(res["comanda_espera_s"], int), res
    with Session(engine_empresa(eid)) as s:
        cfg = modulos.leer(s, eid, "pos_config", {})
    (tmp_path / "datos.json").write_text(json.dumps({"pendientes": pen, "pedido_id": pid, "cuenta": cuenta, "cfg": cfg}), encoding="utf-8")
    falsos = {"api.js": "export const toast = () => {}, fmtCant = v => String(v), api = async () => ({}), fmt = v => String(v), fecha = v => String(v);\n",
              "pages/pos/_agente.js": FALSO_AGENTE, "pages/pos/_agente_real.js": _js("pages/pos/_agente.js")}
    p = _node(tmp_path, "globalThis.Q = { docs: [] };\n" + PANTALLA_ESTACION, archivos=("pages/pos/_comandas.js",), falsos=falsos)
    assert p["url_pendientes"] == f"/api/pos/comanda/pendientes?pedido_id={pid}" and p["pen"] == "ok"
    # la huella de la pantalla es la del servidor; cada línea enviada de la cuenta es un plato de la copia
    assert p["huellas"] and all(h == j for h, j in p["huellas"]), p["huellas"]
    assert all(h == comandas.huella(cuenta["lineas"][l["pos"]]) for h, l in zip((x[0] for x in p["huellas"]), pen["copias"][0]["lineas"]))
    assert sorted(p["posiciones"]) == sorted(l["pos"] for l in pen["copias"][0]["lineas"]), p
    assert p["libres"] == [True] * len(pen["copias"][0]["lineas"])
    assert [[str(x[0]), x[1], x[2]] for x in p["grupos"]] == [["10", True, [l["pos"] for l in pen["copias"][0]["lineas"]]]] and p["sin"] == [], p
    # los cuerpos que arma la pantalla, tal cual, a las rutas reales
    resultados = []
    for url, metodo, cuerpo in p["cuerpos"]:
        assert metodo == "POST"
        r = c.post(url, json=cuerpo)
        assert r.status_code == 200, (url, r.text)
        resultados.append(r.json())
    reclamo, soltar, otra_vez, marca = resultados
    assert reclamo["resultado"] == "ganada" and sorted(reclamo["lineas"]) == sorted(p["grupos"][0][2]) and reclamo["vence"], reclamo
    assert soltar == {"resultado": "ok"}, soltar
    assert otra_vez["resultado"] == "ganada", otra_vez                     # Cocina a mano: sin la espera de 60 s del mismo equipo
    assert marca["resultado"] == "ok" and marca["copia"] == "impresa" and marca["cancelado"] is False and marca["marcadas"] == len(p["grupos"][0][2]), marca
    # la caja ve la marca «impreso» en cada plato de la copia (D-18) y la copia ya no está pendiente
    lineas = _cuenta(eid, cid)["lineas"]
    assert all(lineas[i].get("impreso") is True for i in p["grupos"][0][2]), lineas
    assert all(x["pedido_id"] != pid for x in c.get("/api/pos/comanda/pendientes").json()["copias"])
