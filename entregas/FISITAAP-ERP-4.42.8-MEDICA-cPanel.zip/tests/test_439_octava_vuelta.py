# -*- coding: utf-8 -*-
"""4.39, octava vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera a séptima: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada).

- Y1 cobroOcupado con «cerrada»: el aviso neutro solo si la cuenta sigue en pantalla. Si mientras trae la lista una sincronización ya cerró
  la cuenta (la caja vuelve al plano), queda un solo aviso, el de sincronizar; en el cobro y en la habitación.
- Y2 las revisiones «vistos» de cobrarParte y confirmarDividir ignoran las líneas del servidor sin lid: el pedido en línea (sus líneas no
  traen lid) con un plato agregado aquí (todavía sin lid) ya no da el aviso falso «Otro equipo mandó a cocina…» al dividir.
- Y3 confirmarDividir, al separar, pasar a una mesa o partir una cuenta ya guardada: si la cuenta del servidor no es la que esta pantalla
  conoce (otro equipo cobró una parte, quitó o bajó un plato con «Dividir» abierto aquí), no se parte nada, se cierra «Dividir» y se avisa;
  al volver a abrirlo la cuenta está al día y se divide sin repetir el aviso. Un solo equipo nunca ve el aviso.
- Y4 la caja de comercio trae la lista antes de esa revisión (y de la de la cuenta cerrada, D0): lo cobrado en otro equipo no pasa a una
  cuenta nueva; un solo equipo, una consulta (1,5 s como mucho) y divide igual.
- Y5 la firma de X2 (después de esperar la marca) lleva la marca de envío: una segunda «Comanda» del otro equipo durante la espera hace
  volver a dividir; el plato sale una vez (del otro equipo) y lo que se pasa o se cobra después ya va enviado.
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la octava vuelta
deshecha (OCTAVA y _caja_sin_octava de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta) y ahí se ve el defecto que el cambio arregla.
4.39 (novena vuelta): el contrato compara la octava vuelta contra caja.js sin la novena (NOVENA y _caja_sin_novena de
tests/test_439_tercera_vuelta.py: la novena cambió la firma de X2 y la de Y3, que ahora miran cada línea de la base y el servicio); lo de la
novena vuelta se prueba en tests/test_439_novena_vuelta.py. Ninguna prueba de esta vuelta esperaba el aviso con un plato que otro equipo SOLO
agregó (todas quitan, bajan, cobran o mandan a cocina un plato que la pantalla conoce), así que siguen igual.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import _metodo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR_7, MEDIAS
from tests.test_439_septima_vuelta import CAMBIO_DIV, CERRADA_C1, CERRADA_M6, NEUTRO
from tests.test_439_septima_vuelta import _correr as _correr7
from tests.test_439_tercera_vuelta import AMBOS, FIRMA_ENV, OCTAVA, REFRESCAR15, _caja_sin_novena, _caja_sin_octava

# los métodos que cambió la octava vuelta (cada tripleta de OCTAVA está en uno de ellos)
CAMBIADOS = ("async cobrarParte(n) {", "async confirmarDividir() {", "async cobroOcupado(r) {")
AVISO_Y3 = "La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día."
PEDIDO = "Pedido #41 · Cliente QA"
CASADO1, POSTRE1, LIMONADA1 = ["Casado×1"], ["Postre×1"], ["Limonada×1"]
CON_LIM = ["Casado×1", "Limonada×1", "Postre×1"]
MEDIAS_LIM = ["Casado×0.5", "Limonada×0.5", "Postre×0.5"]
# los avisos de todos los días (lo hecho), que no cuentan como aviso de esta vuelta
HECHO = ("Platos pasados a ", "Cuenta dividida", "Comanda ", "Tiquete ")


def _antes(cabezas=CAMBIADOS):
    """Los métodos que cambió la octava vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_octava()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
const AVISO_Y3 = @AVISO_Y3@, HECHO = @HECHO@;
const PROMO = [{ tipo: '2x1', nombre: '2x1 cervezas', productos: [4] }];
// el aviso de Y3 de ESE equipo, y sus avisos sin los de todos los días (lo hecho)
const avisoY3 = vm => avisos(vm).filter(t => t === AVISO_Y3);
const otrosAvisos = vm => avisos(vm).filter(t => !HECHO.some(h => t.startsWith(h)));
// B quita el Casado (en su pantalla) y guarda la cuenta; B baja el Casado a 1 y la guarda
async function quitarCasado(b) { b.lineas = b.lineas.filter(l => l.detalle !== 'Casado'); b.persistirCuenta(); await b.A.mock.guardarTodo(); }
async function bajarCasado(b) { b.lineas.find(l => l.detalle === 'Casado').cantidad = 1; b.persistirCuenta(); await b.A.mock.guardarTodo(); }
// en cuanto empieza cobroOcupado, la lista que trae (alDiaParaCobrar) tarda 600 ms y mientras tanto corre la sincronización de siempre (el reloj de
// la caja). Anota cuántas veces se llamó y, cuando llega esa lista, si la sincronización ya había cerrado la cuenta en pantalla
function sincEnMedio(a) {
  const co0 = a.cobroOcupado, n = { co: 0, alLlegar: null };
  a.cobroOcupado = function (r) {
    n.co++;
    const r0 = a.A.mock.refrescar;
    a.A.mock.refrescar = async function (...x) { if (x[1] && x[1].sinCorte) { await espera(600); n.alLlegar = { cuenta: a.esperaId, cerradas: cerradas(a).length }; } return r0.apply(this, x); };
    const p = co0(r); a.sincronizar();
    return Promise.resolve(p).finally(() => { a.A.mock.refrescar = r0; });
  };
  return n;
}
"""


def _correr(tmp_path, casos, antes=()):
    guion = AYUDAS.replace("@AVISO_Y3@", json.dumps(AVISO_Y3)).replace("@HECHO@", json.dumps(list(HECHO))) + casos
    return _correr7(tmp_path, guion, antes=antes)


# ================================================================================================================ Y1: un solo aviso
CASOS_Y1 = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B. B toca «Comanda» (sale enseguida); A sincroniza (la marca), abre el cobro (o, con
// `hab`, la ventana de la habitación) y toca «Cobrar» («Cargar»): espera la marca. Al segundo, B borra la cuenta. Después de esperar, A ve que ya no
// está (cobroOcupado con «cerrada») y, mientras trae la lista, la sincronización de siempre cierra la cuenta en pantalla
async function y1(hab) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]);
  await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar(); const m0 = marca(a);
  const n = sincEnMedio(a);
  if (hab) { a.habCargo = HAB(); hojaHab(a); a.habCargo.reserva_id = 1; } else await a.abrirPago();
  const pa = hab ? a.cargarAHabitacion() : a.cobrar();
  await espera(1000); await b.borrarEspera(b.cuentaActual); await b.A.mock.guardarTodo();
  await pa; await hastaLibre(); await espera(800); await a.A.mock.guardarTodo();
  return { m0: !!m0, co: n.co, alLlegar: n.alLlegar, avisos: avisos(a), neutro: neutros(a), cerradas: cerradas(a), delCobro: delCobroA(a), fin: est(a), vista: a.vista,
    srv: srv(), hechos: cobrados(a), folios: folios(), impresos: quienes(a), orden: orden(a.nEq), libre: libre() };
}
out.borra = await y1(@HAB@);
// (sigue) cobroOcupado con «cerrada» y la cuenta todavía en la lista, con la sincronización en medio: el aviso neutro, una vez; la cuenta sigue en pantalla
if (!@HAB@) { const [id, a] = await mesaGuardada([CASADO(), POSTRE()]); const n = sincEnMedio(a); await a.abrirPago(); await a.cobroOcupado({ resultado: 'cerrada', comunes: [] }); await espera(700);
  out.sigue = { co: n.co, alLlegar: n.alLlegar, avisos: avisos(a), neutro: neutros(a), cerradas: cerradas(a), delCobro: delCobroA(a), fin: est(a), srv: srv() }; }
"""


@pytest.mark.parametrize("hab", [False, True])
def test_y1_la_cuenta_que_cierra_una_sincronizacion_da_un_solo_aviso_en_node(tmp_path, hab):
    casos = CASOS_Y1.replace("@HAB@", json.dumps(hab))
    r = _correr(tmp_path / "ahora", casos)
    x = r["borra"]
    # A esperó la marca y fue por cobroOcupado una vez; cuando llegó su lista, la sincronización ya había cerrado la cuenta (el caso de Y1)
    assert x["m0"] is True and x["co"] == 1 and x["alLlegar"] == {"cuenta": None, "cerradas": 1}, (hab, x)
    # un solo aviso, el de sincronizar: ni el neutro ni «ya se cobró»
    assert x["avisos"] == [CERRADA_M6] and x["neutro"] == [] and x["cerradas"] == [CERRADA_M6] and x["delCobro"] == [], (hab, x)
    # nada cobrado ni cargado; la comanda de B salió una vez; el cobro pedido quedó libre; de vuelta al plano, sin ventanas ni cuenta
    assert x["hechos"] == [] and x["folios"] == [] and x["impresos"] == [["B", AMBOS]] and x["srv"] == [] and x["libre"] is True, (hab, x)
    assert x["fin"]["pago"] is False and x["fin"]["hab"] is False and x["fin"]["platos"] == [] and x["fin"]["cuenta"] is None and x["vista"] == "mesas", (hab, x)
    if not hab:
        s = r["sigue"]
        # con la cuenta todavía en la lista: el aviso neutro, una vez, sin «ya se cobró» ni el de sincronizar; la cuenta sigue en pantalla
        assert s["co"] == 1 and s["alLlegar"] == {"cuenta": 1, "cerradas": 0} and s["avisos"] == [NEUTRO] and s["neutro"] == [NEUTRO] and s["cerradas"] == [], s
        assert s["delCobro"] == [] and s["fin"]["pago"] is False and s["fin"]["platos"] == AMBOS and s["srv"] == [["Mesa 6", AMBOS, None]], s

    # antes de esta vuelta: los dos avisos, el de sincronizar y el neutro («la cuenta cambió en otro equipo. Revísela»), de una cuenta que ya no estaba
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    b = v["borra"]
    assert b["alLlegar"] == {"cuenta": None, "cerradas": 1} and b["avisos"] == [CERRADA_M6, NEUTRO] and b["hechos"] == [] and b["folios"] == [], (hab, b)
    if not hab:
        assert v["sigue"]["avisos"] == [NEUTRO], v["sigue"]                                              # con la cuenta en la lista, igual que ahora


# ================================================================================================================ Y2: el pedido en línea sin lid
CASOS_Y2 = r"""
// el pedido en línea a domicilio (sus líneas no traen lid: el Casado enviado hace un minuto y el envío) abierto desde «Para llevar en espera». A abre
// «Dividir» y lo cierra (la cuenta queda al día), agrega un Postre y enseguida (menos de 3 s: no se vuelve a juntar, el Postre sigue sin lid) vuelve
// a abrir «Dividir»: separa el Postre (nueva) o 2 partes iguales (partes)
async function y2(como) {
  nuevo(); pedidoEnServidor([CASADO()]);
  const a = venta(await equipo()); await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === 1));
  await a.abrirDividir(); a.dividir = null;
  a.lineas.push(POSTRE());
  const lis = listas(a); await a.abrirDividir(); const abierto = !!a.dividir, sinLid = !a.lineas.find(l => l.detalle === 'Postre').lid;
  if (a.dividir) { if (como === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = 'nueva'; a.dividir.sel = { [a.lineas.findIndex(l => l.detalle === 'Postre')]: 1 }; } await a.confirmarDividir(); }
  await a.A.mock.guardarTodo(); await hastaLibre();
  return { abierto, sinLid, consultas: lis.n, dividir: !!a.dividir, avisos: otrosAvisos(a), hecho: avisos(a).filter(t => t.startsWith('Platos pasados a ') || t.startsWith('Cuenta dividida')),
    platos: detalles(a), srv: srv(), enviados: enviados(), impresos: quienes(a) };
}
for (const como of ['nueva', 'partes']) out[como] = await y2(como);
"""
Y2_FIN = {"nueva": ([[PEDIDO, ["Casado×1", "Envío a domicilio×1"], None], [PEDIDO + " · aparte", POSTRE1, None]], [CASADO1, []], ["Casado×1", "Envío a domicilio×1"]),
          "partes": ([[PEDIDO, ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"], None], [PEDIDO + " · parte 2 de 2", ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"], None]],
                     [["Casado×0.5"], ["Casado×0.5"]], ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"])}


def test_y2_el_pedido_en_linea_con_un_plato_agregado_divide_sin_aviso_falso_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Y2)
    for como in ("nueva", "partes"):
        x = r[como]
        srv, enviados, platos = Y2_FIN[como]
        # el caso de Y2: «Dividir» se abrió con el Postre todavía sin lid; una consulta de la lista (la revisión de la comanda)
        assert x["abierto"] is True and x["sinLid"] is True and x["consultas"] == 1, (como, x)
        # sin aviso: se divide bien, el Casado sigue enviado (no vuelve a cocina) y no sale ninguna comanda
        assert x["avisos"] == [] and len(x["hecho"]) == 1 and x["dividir"] is False and x["srv"] == srv and x["enviados"] == enviados and x["platos"] == platos and x["impresos"] == [], (como, x)

    # antes de esta vuelta: el aviso falso (el Postre sin lid «coincidía» con el Casado del servidor, sin lid y enviado) y no se dividía
    v = _correr(tmp_path / "antes", CASOS_Y2, antes=_antes())
    for como in ("nueva", "partes"):
        x = v[como]
        assert x["sinLid"] is True and x["avisos"] == [AVISO_DIVIDIR_7] and x["hecho"] == [] and x["srv"] == [[PEDIDO, ["Casado×1", "Envío a domicilio×1"], None]], (como, x)


# ================================================================================================================ Y3: la cuenta cambió con «Dividir» abierto
CASOS_Y3 = r"""
// la Mesa 6 con 2 Casados, un Postre y una Limonada sin enviar, abierta en A y en B. A abre «Dividir». B, sobre los Casados (`que`): estos, «Dividir →
// Cobrar estos platos» con los 2 Casados y los cobra; parte, «Cobrar parte 1 de 2» y la cobra; quita, quita el Casado; baja, baja el Casado a 1. A (sin
// sincronizar) elige los 2 Casados para `destino` (nueva: una cuenta aparte; 7: la Mesa 7) y confirma. Si salió el aviso, vuelve a abrir «Dividir»,
// elige el Postre y confirma
async function y3(que, destino) {
  const [id, a, b] = await mesaGuardada([{ ...CASADO(), cantidad: 2 }, POSTRE(), LIMONADA()]); a.mesas = [M6, M7];
  await a.abrirDividir();
  if (que === 'estos') { await b.abrirDividir(); b.dividir.destino = 'cobrar'; b.dividir.sel = { 0: 2 }; await b.confirmarDividir(); await conPago(b); await b.cobrar(); }
  else if (que === 'parte') { await b.cobrarParte(2); await conPago(b); await b.cobrar(); }
  else if (que === 'quita') await quitarCasado(b);
  else await bajarCasado(b);
  await hastaLibre(); await b.A.mock.guardarTodo();
  const srvB = srv(), hechosB = cobrados(a);
  a.dividir.destino = destino; a.dividir.sel = { 0: 2 }; const lis = listas(a); await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { dividir: !!a.dividir, y3: avisoY3(a), srv: srv(), consultas: lis.n, alDia: a._alDia, platos: detalles(a) };
  let segundo = null;
  if (primero.y3.length && !a.dividir) {
    await a.abrirDividir(); const abierto = !!a.dividir, platos = detalles(a);
    if (a.dividir) { const i = a.lineas.findIndex(l => l.detalle === 'Postre'); a.dividir.destino = destino; a.dividir.sel = { [i]: +a.lineas[i].cantidad }; await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre(); }
    segundo = { abierto, platos, dividir: !!a.dividir };
  }
  return { srvB, hechosB, primero, segundo, y3: avisoY3(a), hecho: avisos(a).filter(t => t.startsWith('Platos pasados a ')), hechos: cobrados(a), srv: srv(), impresos: quienes(a), libre: libre() };
}
for (const destino of @DESTINOS@) out[destino] = await y3(@QUE@, destino);
"""
Y3_B = {"estos": ([["Mesa 6", ["Limonada×1", "Postre×1"], None]], [["B", ["Casado×2"]]]),
        "parte": ([["Mesa 6", ["Casado×1", "Limonada×0.5", "Postre×0.5"], {"total": 2, "cobradas": 1}]], [["B", ["Casado×1", "Limonada×0.5", "Postre×0.5"]]]),
        "quita": ([["Mesa 6", ["Limonada×1", "Postre×1"], None]], []),
        "baja": ([["Mesa 6", ["Casado×1", "Limonada×1", "Postre×1"], None]], [])}
# lo que queda en la Mesa 6 y lo que pasa (el Postre) al volver a dividir
Y3_FIN = {"estos": ([["Mesa 6", LIMONADA1, None]], POSTRE1), "parte": ([["Mesa 6", ["Casado×1", "Limonada×0.5"], {"total": 2, "cobradas": 1}]], ["Postre×0.5"]),
          "quita": ([["Mesa 6", LIMONADA1, None]], POSTRE1), "baja": ([["Mesa 6", ["Casado×1", "Limonada×1"], None]], POSTRE1)}
DESTINO = {"nueva": "Mesa 6 · aparte", "7": "Mesa 7"}


@pytest.mark.parametrize("que", ["estos", "parte", "quita", "baja"])
def test_y3_dividir_no_parte_la_cuenta_que_cambio_en_otro_equipo_en_node(tmp_path, que):
    casos = CASOS_Y3.replace("@QUE@", json.dumps(que)).replace("@DESTINOS@", json.dumps(["nueva", 7]))
    r = _correr(tmp_path / "ahora", casos)
    srv_b, hechos_b = Y3_B[que]
    for destino in ("nueva", "7"):
        x, p, s = r[destino], r[destino]["primero"], r[destino]["segundo"]
        assert x["srvB"] == srv_b and x["hechosB"] == hechos_b, (que, destino, x)
        # el aviso, «Dividir» cerrado y nada partido: ninguna cuenta nueva (la cuenta del servidor sigue como la dejó B); una consulta; la próxima apertura
        # de «Dividir» junta la cuenta
        assert p["y3"] == [AVISO_Y3] and p["dividir"] is False and p["srv"] == srv_b and p["consultas"] == 1 and p["alDia"] == 0, (que, destino, x)
        # al volver a abrir «Dividir» la cuenta está al día y el Postre pasa bien, sin repetir el aviso
        mesa, pasa = Y3_FIN[que]
        assert s["abierto"] is True and s["platos"] == sorted(sum((c[1] for c in srv_b), [])) and s["dividir"] is False, (que, destino, x)
        assert x["y3"] == [AVISO_Y3] and len(x["hecho"]) == 1 and x["srv"] == mesa + [[DESTINO[destino], pasa, None]], (que, destino, x)
        # lo cobrado se cobró una vez (en B) y nada salió a cocina (es una mesa)
        assert x["hechos"] == hechos_b and x["impresos"] == [] and x["libre"] is True, (que, destino, x)

    # antes de esta vuelta: los 2 Casados pasaban a la cuenta aparte o a la Mesa 7 aunque B ya los había cobrado (en todo o en parte), quitado o bajado:
    # por cobrar otra vez (o un Casado que ya no se pidió)
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for destino in ("nueva", "7"):
        x = v[destino]
        assert x["primero"]["y3"] == [] and x["segundo"] is None and [DESTINO[destino], ["Casado×2"], None] in x["srv"] and x["hechos"] == hechos_b, (que, destino, x)


CASOS_Y3_PARTES = r"""
// la cuenta guardada sin mesa con 2 Casados, un Postre y una Limonada sin enviar, abierta en A y en B. A abre «Dividir»; B quita el Casado (quita) o lo
// baja a 1 (baja). A (sin sincronizar) elige 2 partes iguales y confirma. Si salió el aviso, vuelve a abrir «Dividir» y parte otra vez
async function y3p(que) {
  const [id, a, b] = await cuenta(false, [{ ...CASADO(), cantidad: 2 }, POSTRE(), LIMONADA()]);
  await a.abrirDividir();
  if (que === 'quita') await quitarCasado(b); else await bajarCasado(b);
  const srvB = srv(), lis = listas(a);
  a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { dividir: !!a.dividir, y3: avisoY3(a), srv: srv(), consultas: lis.n, alDia: a._alDia };
  let segundo = null;
  if (primero.y3.length && !a.dividir) {
    await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: detalles(a) };
    if (a.dividir) { a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre(); segundo.dividir = !!a.dividir; }
  }
  return { srvB, primero, segundo, y3: avisoY3(a), hecho: avisos(a).filter(t => t.startsWith('Cuenta dividida')), srv: srv(), impresos: quienes(a) };
}
for (const que of ['quita', 'baja']) out[que] = await y3p(que);
"""
LIM_POSTRE, MEDIAS_LP = ["Limonada×1", "Postre×1"], ["Limonada×0.5", "Postre×0.5"]


def test_y3_partir_la_cuenta_guardada_que_cambio_en_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Y3_PARTES)
    for que, quedan, mitad in (("quita", LIM_POSTRE, MEDIAS_LP), ("baja", CON_LIM, MEDIAS_LIM)):
        x, p, s = r[que], r[que]["primero"], r[que]["segundo"]
        # B quitó o bajó el Casado: el aviso, «Dividir» cerrado y nada partido (una consulta); al volver a abrirlo la cuenta está al día y se parte bien
        assert x["srvB"] == [["Cuenta 1", quedan, None]] and p["y3"] == [AVISO_Y3] and p["dividir"] is False and p["srv"] == x["srvB"] and p["consultas"] == 1 and p["alDia"] == 0, (que, x)
        assert s == {"abierto": True, "platos": quedan, "dividir": False} and x["y3"] == [AVISO_Y3] and len(x["hecho"]) == 1, (que, x)
        assert x["srv"] == [["Cuenta 1", mitad, None], ["Cuenta 1 · parte 2 de 2", mitad, None]] and x["impresos"] == [], (que, x)

    # antes de esta vuelta: se partía con los 2 Casados de la pantalla: la parte 2 se llevaba un Casado que B ya había quitado (y, si lo había bajado a
    # 1, quedaban 2 Casados por cobrar, uno en cada parte)
    v = _correr(tmp_path / "antes", CASOS_Y3_PARTES, antes=_antes())
    parte2 = ["Cuenta 1 · parte 2 de 2", ["Casado×1", "Limonada×0.5", "Postre×0.5"], None]
    for que, primera in (("quita", MEDIAS_LP), ("baja", ["Casado×1", "Limonada×0.5", "Postre×0.5"])):
        x = v[que]
        assert x["primero"]["y3"] == [] and x["segundo"] is None and x["srv"] == [["Cuenta 1", primera, None], parte2], (que, x)


CASOS_Y3_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo; `caso`: comanda (A toca «Comanda» y divide enseguida), comanda_ya (después de que su guardado llegó),
// guardado / guardado_ya (A agrega una Limonada y la guarda), singuardar (la Limonada sin guardar), dosxuno (2 Cervezas con el 2x1 y un Casado),
// prepago (el pedido en línea con ₡1 000 ya pagados en línea, con Casado y Postre). A separa la primera línea (nueva), la pasa a la Mesa 7 (7) o parte
// en 2 partes iguales (partes)
async function solo(caso, destino) {
  let a;
  if (caso === 'prepago') {
    nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); S.items[0].prepago = { monto: 1000, medio: '06', referencia: 'QA-1' };
    a = venta(await equipo()); await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === 1));
  } else if (caso === 'dosxuno') {
    nuevo(); const g = venta(await equipo()); g.promosActivas = PROMO; g.abrirMesa(M6); g.lineas.push(CASADO(), CERVEZA(2)); g.aplicarPromos(); g.persistirCuenta(); await g.A.mock.guardarTodo();
    a = venta(await equipo()); a.promosActivas = PROMO; await a.sincronizar(); a.abrirMesa(M6);
  } else {
    [, a] = await mesaGuardada([CASADO(), POSTRE()]);
    if (caso.startsWith('comanda')) { await a.enviarComanda(); if (caso === 'comanda_ya') await a.A.mock.guardarTodo(); }
    if (caso.startsWith('guardado')) { a.lineas.push(LIMONADA()); a.persistirCuenta(); if (caso === 'guardado_ya') await a.A.mock.guardarTodo(); }
    if (caso === 'singuardar') a.lineas.push(LIMONADA());
  }
  a.mesas = [M6, M7];
  const promo = a.lineas.filter(l => +l.descuento_pct > 0).map(l => l.detalle + '×' + l.cantidad);
  await a.abrirDividir(); const lis = listas(a), t0 = Date.now();
  if (destino === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = destino; a.dividir.sel = { 0: +a.lineas[0].cantidad }; }
  await a.confirmarDividir(); const ms = Date.now() - t0; await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, consultas: lis.n, dividir: !!a.dividir, promo, avisos: otrosAvisos(a), hecho: avisos(a).filter(t => t.startsWith('Platos pasados a ') || t.startsWith('Cuenta dividida')), srv: srv(), impresos: quienes(a) };
}
for (const [caso, destino] of @CASOS@) out[caso + '_' + destino] = await solo(caso, destino);
"""
Y3_SOLO = {"comanda_nueva": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "comanda_ya_7": [["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]],
           "guardado_nueva": [["Mesa 6", ["Limonada×1", "Postre×1"], None], ["Mesa 6 · aparte", CASADO1, None]],
           "guardado_ya_7": [["Mesa 6", ["Limonada×1", "Postre×1"], None], ["Mesa 7", CASADO1, None]],
           "singuardar_nueva": [["Mesa 6", ["Limonada×1", "Postre×1"], None], ["Mesa 6 · aparte", CASADO1, None]],
           "singuardar_7": [["Mesa 6", ["Limonada×1", "Postre×1"], None], ["Mesa 7", CASADO1, None]],
           "dosxuno_nueva": [["Mesa 6", ["Cerveza×2"], None], ["Mesa 6 · aparte", CASADO1, None]], "dosxuno_7": [["Mesa 6", ["Cerveza×2"], None], ["Mesa 7", CASADO1, None]],
           "prepago_nueva": [[PEDIDO, ["Envío a domicilio×1", "Postre×1"], None], [PEDIDO + " · aparte", CASADO1, None]],
           "prepago_partes": [[PEDIDO, ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"], None], [PEDIDO + " · parte 2 de 2", ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"], None]]}


def test_y3_un_solo_equipo_divide_sin_aviso_en_node(tmp_path):
    casos = [k.rsplit("_", 1) for k in Y3_SOLO]
    r = _correr(tmp_path, CASOS_Y3_SOLO.replace("@CASOS@", json.dumps([[c, 7 if d == "7" else d] for c, d in casos])))
    for k, srv in Y3_SOLO.items():
        x = r[k]
        # sin el aviso (su propia comanda, su guardado, un plato sin guardar, el 2x1 y el prepago no cuentan como «otro equipo»); una consulta, sin esperar
        assert x["avisos"] == [] and len(x["hecho"]) == 1 and x["dividir"] is False and x["consultas"] == 1 and x["ms"] < 1500 and x["srv"] == srv, (k, x)
    # la comanda de A salió una vez; el 2x1 estaba aplicado
    assert r["comanda_nueva"]["impresos"] == [["A", AMBOS]] and r["comanda_ya_7"]["impresos"] == [["A", AMBOS]] and r["dosxuno_nueva"]["promo"] == ["Cerveza×2"], r


# ================================================================================================================ Y4: la caja de comercio
CASOS_Y4 = r"""
// caja de comercio (sin comanda ni revisión): la cuenta guardada con Casado y Postre, abierta en A (y en B). A abre «Dividir». `que`: entera, B cobra la
// cuenta entera; parte, B cobra el Casado («Dividir → Cobrar estos platos»); solo, nadie más; lenta, nadie más y la lista tarda 3 s. A separa el Casado
// (o, con `partes`, 2 partes iguales). Si salió el aviso, vuelve a abrir «Dividir»
async function y4(que, partes) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id); a.esRestaurante = false;
  let b = null; if (que === 'entera' || que === 'parte') { b = await abierta(id); b.esRestaurante = false; }
  await a.abrirDividir();
  if (que === 'entera') { await b.abrirPago(); await b.cobrar(); }
  else if (que === 'parte') { await b.abrirDividir(); b.dividir.destino = 'cobrar'; b.dividir.sel = { 0: 1 }; await b.confirmarDividir(); await conPago(b); await b.cobrar(); }
  if (b) { await hastaLibre(); await b.A.mock.guardarTodo(); }
  if (que === 'lenta') lento(a, 3000);
  const srvB = srv(), lis = listas(a), t0 = Date.now();
  if (partes) { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = 'nueva'; a.dividir.sel = { 0: 1 }; }
  await a.confirmarDividir(); const ms = Date.now() - t0, consultas = lis.n; await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { ms, consultas, dividir: !!a.dividir, y3: avisoY3(a), cerradas: cerradas(a), srv: srv(), fin: est(a) };
  let segundo = null;
  if (primero.y3.length) { await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: detalles(a) }; }
  return { srvB, primero, segundo, hechos: cobrados(a), avisos: otrosAvisos(a), hecho: avisos(a).filter(t => t.startsWith('Platos pasados a ') || t.startsWith('Cuenta dividida')), impresos: quienes(a) };
}
for (const [que, partes] of [['entera', false], ['parte', false], ['solo', false], ['solo', true], ['lenta', false]]) out[que + (partes ? '_partes' : '')] = await y4(que, partes);
"""
APARTE_C1 = [["Cuenta 1", POSTRE1, None], ["Cuenta 1 · aparte", CASADO1, None]]


def test_y4_la_caja_de_comercio_trae_la_lista_y_no_pasa_lo_cobrado_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Y4)
    e = r["entera"]
    # B cobró la cuenta entera: A no crea nada; la caja se pone al día (el aviso de siempre de sincronizar y la cuenta fuera de la pantalla); la lista
    # se trajo (Y4) y otra vez al sincronizar
    assert e["hechos"] == [["B", AMBOS]] and e["srvB"] == [] and e["primero"]["srv"] == [] and e["primero"]["y3"] == [] and e["primero"]["dividir"] is False, e
    assert e["primero"]["cerradas"] == [CERRADA_C1] and e["primero"]["fin"]["platos"] == [] and e["primero"]["fin"]["cuenta"] is None and e["primero"]["consultas"] == 2 and e["hecho"] == [], e
    p = r["parte"]
    # B cobró el Casado: A no lo pasa a otra cuenta; el aviso de Y3 y «Dividir» cerrado; al volver a abrirlo la caja está al día (solo el Postre)
    assert p["hechos"] == [["B", CASADO1]] and p["srvB"] == [["Cuenta 1", POSTRE1, None]] and p["primero"]["srv"] == p["srvB"] and p["hecho"] == [], p
    assert p["primero"]["y3"] == [AVISO_Y3] and p["primero"]["dividir"] is False and p["primero"]["consultas"] == 1 and p["segundo"] == {"abierto": True, "platos": POSTRE1}, p
    # un solo equipo: una consulta, sin esperar y divide igual; con la lista lenta, 1,5 s como mucho y divide con la copia que hay. 4.39 (décima vuelta):
    # la consulta de la caja de comercio no cambia con R1 (los platos por enviar esperan hasta 3 s solo en el restaurante). 4.39 (undécima vuelta): Q1
    # lleva esa consulta a 3 s como mucho: con la lista a 3 s, unos 3 s (la lista o el tope, lo que llegue primero) y divide igual
    for k, srv, tope in (("solo", APARTE_C1, 1000), ("solo_partes", [["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], 1000), ("lenta", APARTE_C1, 4000)):
        x = r[k]
        assert x["primero"]["consultas"] == 1 and x["primero"]["ms"] < tope and x["primero"]["srv"] == srv and x["avisos"] == [] and len(x["hecho"]) == 1 and x["impresos"] == [], (k, x)
    assert r["lenta"]["primero"]["ms"] >= 2900, r["lenta"]

    # antes de esta vuelta: la caja de comercio no traía la lista (ninguna consulta) y separaba con la copia que tenía: el Casado que B ya había cobrado
    # quedaba en una cuenta nueva, por cobrar otra vez
    v = _correr(tmp_path / "antes", CASOS_Y4, antes=_antes())
    assert v["entera"]["primero"]["srv"] == [["Cuenta 1 · aparte", CASADO1, None]] and v["entera"]["primero"]["consultas"] == 0 and v["entera"]["hechos"] == [["B", AMBOS]], v["entera"]
    assert v["parte"]["primero"]["srv"] == APARTE_C1 and v["parte"]["primero"]["y3"] == [] and v["parte"]["hechos"] == [["B", CASADO1]], v["parte"]
    assert v["solo"]["primero"]["consultas"] == 0 and v["solo"]["primero"]["srv"] == APARTE_C1, v["solo"]


# ================================================================================================================ Y5: otra «Comanda» durante la espera
CASOS_Y5 = r"""
// la Mesa 6 (o, con `destino` partes, la cuenta guardada sin mesa) con Casado y Postre sin enviar, abierta en A y en B. A agrega una Limonada y la guarda
// sin enviar; B toca «Comanda» (salen el Casado y el Postre). A sincroniza (la marca), abre «Dividir» y elige la Limonada para `destino` (nueva, 7 o
// cobrar) o 2 partes iguales (partes): espera la marca. A los 1,5 s B sincroniza (le llega la Limonada sin enviar) y toca «Comanda» otra vez: sale la
// Limonada. Si salió el aviso, A vuelve a abrir «Dividir», elige lo mismo y confirma; con «cobrar», cobra la parte
async function y5(destino) {
  const [id, a, b] = await cuenta(destino !== 'partes'); a.mesas = [M6, M7];
  a.lineas.push(LIMONADA()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const m0 = marca(a);
  const elegir = () => { if (destino === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = destino; a.dividir.sel = { [a.lineas.findIndex(l => l.detalle === 'Limonada')]: 1 }; } };
  await a.abrirDividir(); elegir();
  const t0 = Date.now(), pd = a.confirmarDividir();
  await espera(1500); await b.sincronizar(); const limB = b.lineas.filter(l => l.detalle === 'Limonada' && !l.enviado).length; await b.enviarComanda(); await b.A.mock.guardarTodo();
  await pd; if (destino === 'cobrar' && a.cobroParcial) await conPago(a); const ms = Date.now() - t0;
  const tras = { ...est(a), cambio: cambioDividir(a), alDia: a._alDia, srv: srv(), enviados: enviados() };
  let segundo = null;
  if (tras.cambio.length && !a.dividir && !a.pago && !a.cobroParcial) {
    await a.abrirDividir(); const abierto = !!a.dividir, sinEnviar = a.lineas.filter(l => !l.enviado).length;
    if (a.dividir) { elegir(); const t1 = Date.now(); await a.confirmarDividir(); if (destino === 'cobrar' && a.cobroParcial) await conPago(a); segundo = { abierto, sinEnviar, ms: Date.now() - t1, dividir: !!a.dividir }; }
  }
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { m0: !!m0, limB, ms, tras, segundo, cambio: cambioDividir(a), impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), srv: srv(), enviados: enviados(), libre: libre() };
}
out.r = await y5(@DESTINO@);
"""
Y5_FIN = {"nueva": ([["Mesa 6", AMBOS, None], ["Mesa 6 · aparte", LIMONADA1, None]], [AMBOS, LIMONADA1], []),
          "7": ([["Mesa 6", AMBOS, None], ["Mesa 7", LIMONADA1, None]], [AMBOS, LIMONADA1], []),
          "cobrar": ([["Mesa 6", AMBOS, None]], [AMBOS], [["A", LIMONADA1]]),
          "partes": ([["Cuenta 1", MEDIAS_LIM, None], ["Cuenta 1 · parte 2 de 2", MEDIAS_LIM, None]], [MEDIAS_LIM, MEDIAS_LIM], [])}
# antes de esta vuelta: lo que quedaba enviado en cada cuenta del servidor (la Limonada pasaba sin enviar)
Y5_ANTES = {"nueva": [AMBOS, []], "7": [AMBOS, []], "partes": [MEDIAS, MEDIAS]}


@pytest.mark.parametrize("destino", ["nueva", "7", "cobrar", "partes"])
def test_y5_otra_comanda_durante_la_espera_hace_volver_a_dividir_en_node(tmp_path, destino):
    casos = CASOS_Y5.replace("@DESTINO@", json.dumps(7 if destino == "7" else destino))
    r = _correr(tmp_path / "ahora", casos)["r"]
    nombre = "Cuenta 1" if destino == "partes" else "Mesa 6"
    # A vio la comanda de B (la marca) y esperó unos 4 s; B tenía la Limonada sin enviar para su segunda comanda
    assert r["m0"] is True and r["limB"] == 1 and 3000 <= r["ms"] < 6500, (destino, r)
    # la segunda «Comanda» de B durante la espera: el aviso, «Dividir» cerrado, nada partido ni cobrado y la próxima apertura junta
    t = r["tras"]
    assert t["cambio"] == [CAMBIO_DIV] and t["dividir"] is False and t["pago"] is False and t["parcial"] is False and t["alDia"] == 0, (destino, r)
    assert t["platos"] == CON_LIM and t["srv"] == [[nombre, CON_LIM, None]] and t["enviados"] == [CON_LIM], (destino, r)
    # al volver a dividir todo está enviado y se divide (o se cobra) una vez, sin repetir el aviso (con la marca de esa comanda, todavía reciente, se espera)
    s = r["segundo"]
    assert s["abierto"] is True and s["sinEnviar"] == 0 and s["dividir"] is False and s["ms"] < 6500 and r["cambio"] == [CAMBIO_DIV], (destino, r)
    # la Limonada salió una sola vez, de B (con las dos comandas completas); lo que se pasó o se partió ya va enviado; lo cobrado, una vez
    srv, enviados, hechos = Y5_FIN[destino]
    assert r["impresos"] == [["B", AMBOS], ["B", LIMONADA1]] and r["noSalioB"] == [] and r["srv"] == srv and r["enviados"] == enviados and r["hechos"] == hechos and r["libre"] is True, (destino, r)
    if destino == "cobrar":
        return   # control: la parte de una mesa se cobraba igual antes (la cocina ya tenía la Limonada de B y la mesa no manda comanda al cobrar)

    # antes de esta vuelta: la firma no miraba la marca de envío: sin aviso se partía con la Limonada «sin enviar» de la pantalla, que quedaba así en la
    # cuenta aparte, en la Mesa 7 o en las dos partes y volvía a salir a cocina con la próxima «Comanda»
    v = _correr(tmp_path / "antes", casos, antes=_antes())["r"]
    assert v["tras"]["cambio"] == [] and v["segundo"] is None and v["impresos"] == [["B", AMBOS], ["B", LIMONADA1]] and v["enviados"] == Y5_ANTES[destino], (destino, v)


# ================================================================================================================ contrato
def test_contrato_de_la_octava_vuelta():
    # 4.39 (novena vuelta): «ahora» es caja.js sin la novena vuelta (la novena cambió la firma de X2 y su comparación, la firma de Y3, el comentario
    # del bloque de Y3/Y4 y las partes de una mesa: Z1 a Z3); lo de la novena está en tests/test_439_novena_vuelta.py
    k, k0 = _caja_sin_novena(), _caja_sin_octava()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de OCTAVA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de los métodos cambiados; cada método cambió
    assert len(OCTAVA) == 5
    for viejo, nuevo, veces in OCTAVA:
        assert k.count(nuevo) == veces and k0.count(viejo) == veces and k0.count(nuevo) == 0 and k.count(viejo) == 0, nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de ellos, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (Y5 y el bloque de Y3/Y4)
    assert k.count("4.39 (octava vuelta)") == 2 and k0.count("4.39 (octava vuelta)") == 0
    cp, cd, co = (metodos[c] for c in CAMBIADOS)
    # Y2: las dos revisiones «vistos» solo con líneas del servidor que tienen lid
    vistos = "vistos = c1 ? (c1.lineas || []).filter(l => l && l.lid && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : []"
    assert cp.count(vistos) == 1 and cd.count(vistos) == 1
    # Y5: la firma de X2 con la marca de envío y, sin base de esa cuenta, sin comparar
    assert cd.count("const firma = ls => " + FIRMA_ENV + ", c2 = enEspera().find(v => v.id === id1);") == 1
    assert "if (!c2 || (this._base && this._base.id === id1 && firma(ponerLids(JSON.parse(JSON.stringify(c2))).lineas) !== firma(this._base.lineas))) {" in cd
    assert "this._base.id === id1 ? this._base.lineas : []" not in cd
    # Y3 y Y4 (con D0): después de X2 y antes de pedir el turno y de partir; la caja de comercio trae la lista (1,5 s como mucho) y no sigue si «Dividir»
    # cambió mientras tanto; la cuenta que ya no está va a sincronizar; la que cambió se compara con la base de ESA cuenta
    pasos = ["this._alDia = 0; this.dividir = null; return toast('" + CAMBIO_DIV + "', 'err');", "{ const idx = this.esperaId, bx = this._base;",
             "if ((d.modo === 'partes' || d.destino !== 'cobrar') && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx)))) {",
             "if (!this.esRestaurante) { " + REFRESCAR15 + " if (this.dividir !== d || this.esperaId !== idx) return; }",
             "const cx = enEspera().find(v => v.id === idx); if (!cx) { this.dividir = null; this.sincronizar(); return; }",
             "const fm = ls => " + FIRMA_ENV + ";",
             "if (this._base && this._base.id === idx && fm(ponerLids(JSON.parse(JSON.stringify(cx))).lineas) !== fm(this._base.lineas)) { this._alDia = 0; this.dividir = null; return toast('" + AVISO_Y3 + "', 'err'); }",
             "if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura", "if (d.modo === 'partes') {", "if (d.destino === 'nueva') {"]
    pos = [cd.index(x) for x in pasos]
    assert pos == sorted(pos), pos
    assert cd.count(REFRESCAR15) == 3 and cd.count("this.sincronizar(); return;") == 3                    # V4b, X2 y Y4; la cuenta que ya no está: X2, D0 y la de 4.31 al cobrar
    # Y1: el aviso neutro de «cerrada» solo con la cuenta todavía en pantalla
    assert co.index("if (this.esperaId && !enEspera().some(v => v.id === this.esperaId)) this.sincronizar();") \
        < co.index("else { if (res === 'cerrada' && this.esperaId) toast('" + NEUTRO + "', 'err'); this.seguirCobroAjeno(this.esperaId); }")
