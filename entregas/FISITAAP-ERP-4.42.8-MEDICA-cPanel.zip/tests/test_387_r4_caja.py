"""3.87 (segunda ronda, r4_caja): caja y punto de venta.
- g3b F1:         la cuenta de un pedido en línea ya pagado conserva lo pagado al agregarle un plato (la caja y, por defensa, el
                  servidor): antes se cobraba otra vez lo pagado en línea.
- comercio-r1:    la caja en mostrador ofrece Fiados, Tarjeta de regalo, Turno y Ventas (antes solo el plano de mesas).
- g6 F1:          la caja de una sucursal emite con esa sucursal aunque la sesión esté en «Todas»: consecutivo y bodega coinciden.
- restaurante-r1: tarjeta, SINPE y transferencia no caen en la cuenta de efectivo cuando no hay cuenta bancaria.
- comercio-r10:   el cierre y el Z muestran lo fiado en «Por medio de pago» y el aviso de Bancos no lo cuenta.
- extras F4:      el comercio y el hotel nuevos nacen con «Caja general» (el cobro en efectivo de la caja queda registrado).
- extras F2:      quien factura (Administrador, Vendedor) emite a crédito a un cliente sin límite aunque la empresa tenga caja; el
                  Cajero sigue con el fiado dentro del límite."""
import json
import pathlib
import re
import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, modulos
from app.db import Empresa, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CLAVE = "Clave-larga-387-r4-caja-QA"
LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]
CAMPOS_ONLINE = ("canal", "pedido_id", "pedido_numero", "prepago", "cupon", "puntos_canjeados", "credito")


def _js(*p):
    return (RAIZ / "static" / "js" / pathlib.Path(*p)).read_text(encoding="utf-8")


class Entorno:
    """Empresa de prueba (sin plan: todo encendido) con usuarios @example.test y sesión real; se borra al final."""

    def __init__(self, tipo):
        init_db()
        self.suf = uuid.uuid4().hex[:6]
        with Session(engine) as s:
            e = Empresa(nombre=f"Caja R4 {self.suf} QA S.A.", numero_id="3101" + str(uuid.uuid4().int)[:6], actividad="551001",
                        otras_senas="Local de pruebas de la caja", correo=f"emp.r4.{self.suf}@example.test", ambiente="sandbox", tipo_negocio=tipo)
            s.add(e); s.commit(); s.refresh(e)
            self.eid = e.id
        self.c, self.uids, self.t = TestClient(app), [], {}

    def usuario(self, clave, rol):
        with Session(engine) as s:
            u = auth.Usuario(correo=f"{clave}.r4.{self.suf}@example.test", nombre=clave.capitalize(), password_hash=auth.hash_password(CLAVE),
                             terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True,
                             paleta="turquesa", mfa_activo=(rol == "Administrador"))
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=self.eid, rol=rol)); s.commit()
            self.uids.append(u.id)
            self.t[clave] = auth._respuesta(s, u, self.eid)["token"]

    def h(self, clave):
        return {"Authorization": "Bearer " + self.t[clave]}

    def limpiar(self):
        with Session(engine) as s:
            for uid in self.uids:
                for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).all():
                    s.delete(m)
                for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid)).all():
                    s.delete(x)
                u = s.get(auth.Usuario, uid)
                if u:
                    s.delete(u)
            e = s.get(Empresa, self.eid)
            if e:
                s.delete(e)
            s.commit()


@pytest.fixture()
def rest():
    x = Entorno("restaurante")
    try:
        yield x
    finally:
        x.limpiar()


@pytest.fixture()
def com():
    x = Entorno("comercio")
    try:
        yield x
    finally:
        x.limpiar()


# ----------------------------------------------------------------------------- g3b F1: pedido en línea ya pagado
def _cuenta_en_linea(eid, prepago):
    """La cuenta que arma pedidos.a_caja para un pedido en línea pagado por SINPE (escrita desde el servidor)."""
    cuenta = {"id": 50, "nombre": "Pedido #7 · Cliente Prepago QA", "cliente_id": None, "credito": False,
              "lineas": [{"producto_id": None, "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08", "enviado": "2026-11-05T09:00:00-06:00", "ronda": 1}],
              "nota": "", "servicio": False, "servicio_pct": 0, "creado": "2026-11-05T09:00:00-06:00", "actualizado": "2026-11-05T09:00:00-06:00", "usuario": "pedidos en línea",
              "total": 4520, "mesa_id": None, "terminal_id": 1, "salonero": "", "pedido": "llevar", "canal": "online", "pedido_id": 7, "pedido_numero": 7,
              "telefono": "87001234", "direccion": "", "hora_entrega": None, "estado": "en_cocina", "mesas_ids": [], "cobros": [], "partes": None,
              "prepago": prepago, "cupon": "BIENVENIDA", "puntos_canjeados": 0}
    with Session(engine_empresa(eid)) as se:
        _, remap = modulos.aplicar_cambios(se, eid, "pos_espera", [cuenta], [], [50]); se.commit()
    return {**cuenta, "id": int(remap.get(50, 50))}


def _guardado(x, eid, cid):
    r = x.c.get("/api/registros/pos_espera", headers=x.h("admin"))
    assert r.status_code == 200, r.text
    return next(c for c in r.json()["datos"] if c["id"] == cid)


def test_la_caja_no_borra_lo_pagado_en_linea_al_guardar_la_cuenta(rest):
    rest.usuario("admin", "Administrador"); rest.usuario("caja", "Cajero")
    prepago = {"tarjeta": "", "monto": 4520.0, "regalo": 0.0, "online": 4520.0, "referencia": "SINPE"}
    c0 = _cuenta_en_linea(rest.eid, prepago)
    # la caja de antes guardaba la cuenta armada desde cero: sin canal, pedido ni prepago, y con el plato nuevo
    vieja = {k: v for k, v in c0.items() if k not in CAMPOS_ONLINE}
    vieja.update({"lineas": c0["lineas"] + [{**c0["lineas"][0], "enviado": "2026-11-05T09:20:00-06:00", "ronda": 2}], "total": 9040})
    for quien in ("caja", "admin"):
        r = rest.c.post("/api/registros/pos_espera/cambios", json={"upserts": [vieja], "deletes": [], "nuevos": []}, headers=rest.h(quien))
        assert r.status_code == 200, (quien, r.text)
        g = _guardado(rest, rest.eid, c0["id"])
        assert {k: g.get(k) for k in CAMPOS_ONLINE} == {k: c0[k] for k in CAMPOS_ONLINE}, (quien, g)
        assert len(g["lineas"]) == 2 and g["total"] == 9040           # lo que sí cambió la caja se guarda
    # el negocio rechaza el SINPE (pedidos.py quita el prepago) y una caja con la copia vieja vuelve a guardar la cuenta: no lo revive
    with Session(engine_empresa(rest.eid)) as se:
        modulos.aplicar_cambios(se, rest.eid, "pos_espera", [{**_guardado(rest, rest.eid, c0["id"]), "prepago": None}], [], []); se.commit()
    r = rest.c.post("/api/registros/pos_espera/cambios", json={"upserts": [{**vieja, **{k: c0[k] for k in CAMPOS_ONLINE}}], "deletes": [], "nuevos": []}, headers=rest.h("caja"))
    assert r.status_code == 200, r.text
    assert _guardado(rest, rest.eid, c0["id"])["prepago"] is None
    # una cuenta de la caja (sin pedido en línea) se guarda tal cual la manda la caja
    propia = {"id": 60, "nombre": "Llevar QA", "lineas": c0["lineas"], "total": 4520, "terminal_id": 1, "pedido": "llevar", "estado": "recibido"}
    r = rest.c.post("/api/registros/pos_espera/cambios", json={"upserts": [propia], "deletes": [], "nuevos": [60]}, headers=rest.h("caja"))
    pid = int(r.json().get("remap", {}).get("60", 60))
    sin_estado = {k: v for k, v in propia.items() if k != "estado"}
    assert rest.c.post("/api/registros/pos_espera/cambios", json={"upserts": [{**sin_estado, "id": pid}], "deletes": [], "nuevos": []}, headers=rest.h("caja")).status_code == 200
    g = _guardado(rest, rest.eid, pid)
    assert "estado" not in g and not set(g) & set(CAMPOS_ONLINE), g


def test_caja_conserva_el_pedido_en_linea_al_guardar_la_cuenta():
    caja = _js("pages", "pos", "caja.js")
    i = caja.index("persistirCuenta(devolverId) {")
    cuerpo = caja[i:caja.index("ponerEnEspera() {", i)]
    for k in CAMPOS_ONLINE:             # lo que pedidos.a_caja escribe en un pedido en línea; si se pierde, se cobra otra vez lo pagado
        assert re.search(r"\b" + k + r": (?:!!)?prev\." + k + r"\b", cuerpo), k
    assert "...(prev && prev.canal ? { canal: prev.canal, pedido_id: prev.pedido_id" in cuerpo
    assert "estado: prev.estado, hora_entregado: prev.hora_entregado }" in cuerpo       # lo del monitor de cocina (3.87) sigue


# ----------------------------------------------------------------------------- comercio-r1: barra de la caja en mostrador
def test_caja_en_mostrador_ofrece_fiados_tarjeta_turno_y_ventas():
    caja = _js("pages", "pos", "caja.js")
    venta = caja.split("<!-- pantalla de venta -->", 1)[1].split('<div class="pos-cats">', 1)[0]
    for accion in ('@click="abrirFiados"', '@click="abrirRegalo"', '@click="abrirTurno"', '@click="modalVentas=true"'):
        assert accion in venta, accion
    assert '<template v-if="caja && !esRestaurante">' in venta          # el restaurante ya los tiene en el plano de mesas


# ----------------------------------------------------------------------------- g6 F1: caja de una sucursal con «Todas»
def test_caja_de_sucursal_emite_con_su_sucursal():
    caja = _js("pages", "pos", "caja.js")
    m = re.search(r"cabSucursal\(\) \{(.*?)\},", caja)
    assert m and "sesion.sucursal_id" in m.group(1) and "this.cfg.sucursal_id" in m.group(1) and "sesion.sucursales" in m.group(1), m and m.group(1)
    # venta (contado, fiado y pendiente), anulación con nota de crédito y la cola sin conexión llevan la sucursal de la caja
    assert caja.count("api('/api/comprobantes', { method: 'POST', headers: this.cabSucursal(), body") == 2
    assert "...(v.sucursal ? { 'X-Sucursal': String(v.sucursal) } : {})" in caja and "sucursal: this.cabSucursal()['X-Sucursal'] || null" in caja
    assert "(this.cfg && this.cfg.sucursal_id) || sesion.sucursal_id" in caja                 # la bodega es la de esa misma sucursal


def test_venta_con_la_sucursal_de_la_caja_sale_con_su_consecutivo(com):
    """Lo que hace la caja con «Todas»: X-Sucursal de su caja y la bodega de esa sucursal → 002 y Bodega Norte."""
    com.usuario("admin", "Administrador")
    h = com.h("admin")
    p = com.c.post("/api/productos", json={"nombre": "Teclado R4 QA", "cabys": "4526100000200", "precio": 10000, "costo": 5000, "cantidad_inicial": 50}, headers=h).json()
    bn = com.c.post("/api/inventario/bodegas", json={"nombre": "Bodega Norte R4"}, headers=h).json()
    assert com.c.post("/api/inventario/ajustes", json={"bodega_id": bn["id"], "observaciones": "Inicial", "lineas": [{"producto_id": p["id"], "tipo": "incremento", "cantidad": 20, "costo_unitario": 5000}]}, headers=h).status_code == 200
    com.c.get("/api/sucursales", headers=h)
    s2 = com.c.post("/api/sucursales", json={"codigo": 2, "nombre": "Sucursal Norte R4", "bodega_id": bn["id"], "activa": True}, headers=h).json()
    body = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "bodega_id": bn["id"],
            "lineas": [{"producto_id": p["id"], "detalle": "Teclado R4 QA", "cabys": "4526100000200", "cantidad": 1, "precio_unitario": 10000, "tarifa": 13, "codigo_tarifa": "08"}]}
    r = com.c.post("/api/comprobantes", json=body, headers={**h, "X-Sucursal": str(s2["id"])})
    assert r.status_code == 200, r.text
    assert r.json()["consecutivo"].startswith("002") and r.json().get("sucursal_id") == s2["id"], r.json()


# ----------------------------------------------------------------------------- restaurante-r1
def test_caja_tarjeta_sinpe_y_transferencia_no_caen_en_la_cuenta_de_efectivo():
    linea = next(x for x in _js("pages", "pos", "caja.js").splitlines() if "cuentaPara(medio) {" in x)
    assert "medio === '01' ? this.cuentas : this.cuentas.filter(x => x.tipo !== 'Efectivo')" in linea, linea


# ----------------------------------------------------------------------------- comercio-r10
def test_cierre_muestra_lo_fiado_por_medio_de_pago():
    datos = _js("pages", "pos", "_datos.js")
    cuerpo = datos.split("export function resumenCaja(c)", 1)[1].split("\n}\n", 1)[0]
    assert re.search(r"porMedio\.fiado\s*=.*v\.fiado", cuerpo), "resumenCaja no suma lo fiado"
    assert re.search(r"const bancos = .*\['01', '01usd', 'fiado', 'hab', 'regalo'\]", cuerpo) and "porMedio, bancos," in cuerpo
    cierres = _js("pages", "pos", "cierres.js")
    linea = next(x for x in cierres.splitlines() if "Tarjeta, SINPE y transferencias" in x)
    assert "resumenCerrar.bancos" in linea and "resumenCerrar.total -" not in linea, linea
    assert cierres.count(".concat(+v.fiado > 0 ? [nombreMedio('fiado') + ' ' + money(v.fiado)] : [])") == 2    # columna «Pago» del detalle y del Z


# ----------------------------------------------------------------------------- extras F4
def test_comercio_y_hotel_nuevos_nacen_con_cuenta_de_efectivo():
    ids = []
    try:
        for tipo in ("comercio", "hospitalidad", "facturacion", "servicios"):
            with Session(engine) as s:
                e = auth.crear_empresa(s, f"Efectivo R4 QA {tipo}", f"efectivo.{tipo}.r4@example.test", tipo_negocio=tipo)
                ids.append(e.id)
            with Session(engine_empresa(e.id)) as s:
                bancos = modulos.leer(s, e.id, "bancos", None)
            if tipo in ("facturacion", "servicios"):
                assert bancos is None, (tipo, bancos)                     # sin caja: Bancos como siempre
            else:
                assert [(b["nombre"], b["tipo"], b["moneda"]) for b in bancos] == [("Caja general", "Efectivo", "CRC")], (tipo, bancos)
                assert not bancos[0].get("ejemplo") and bancos[0]["saldo_inicial"] == 0
    finally:
        with Session(engine) as s:
            for eid in ids:
                x = s.get(Empresa, eid)
                if x:
                    s.delete(x)
            s.commit()


# ----------------------------------------------------------------------------- extras F2
def test_quien_factura_emite_a_credito_sin_limite_y_el_cajero_sigue_con_el_fiado(com):
    com.usuario("admin", "Administrador"); com.usuario("vend", "Vendedor"); com.usuario("caja", "Cajero")
    h = com.h("admin")
    cli = com.c.post("/api/clientes", json={"nombre": "Cliente Credito R4", "tipo_id": "01", "numero_id": "109990981", "tipo": "Cliente"}, headers=h).json()
    fac = {"tipo_documento": "01", "condicion_venta": "02", "plazo_credito": 30, "medio_pago": "01", "cliente_id": cli["id"], "lineas": LINEAS}
    for quien in ("admin", "vend"):                                       # Ingresos › Facturas de venta › Crédito
        r = com.c.post("/api/comprobantes", json=fac, headers=com.h(quien))
        assert r.status_code == 200 and r.json()["condicion_venta"] == "02", (quien, r.text)
    r = com.c.post("/api/comprobantes", json=fac, headers=com.h("caja"))   # el Cajero no fía a un cliente sin límite
    assert r.status_code == 403 and "límite de crédito" in r.json()["detail"], r.text
    datos = {k: v for k, v in next(x for x in com.c.get("/api/clientes", headers=h).json() if x["id"] == cli["id"]).items() if k not in ("id", "empresa_id")}
    assert com.c.put(f"/api/clientes/{cli['id']}", json={**datos, "limite_credito": 1000}, headers=h).status_code == 200
    for quien in ("caja", "admin"):                                       # con límite se revisa para todos (debe 9.040 + 4.520 > 1.000)
        r = com.c.post("/api/comprobantes", json=fac, headers=com.h(quien))
        assert r.status_code == 403 and "no se puede fiar" in r.json()["detail"], (quien, r.text)
    assert com.c.put(f"/api/clientes/{cli['id']}", json={**datos, "limite_credito": 100000}, headers=h).status_code == 200
    assert com.c.post("/api/comprobantes", json=fac, headers=com.h("caja")).status_code == 200
    r = com.c.post("/api/comprobantes", json={**fac, "cliente_id": 999999}, headers=h)   # un cliente que no existe: 400 de siempre, no 500
    assert r.status_code == 400, r.text
