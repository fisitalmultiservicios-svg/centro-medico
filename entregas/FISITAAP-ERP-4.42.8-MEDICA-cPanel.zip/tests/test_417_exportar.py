# -*- coding: utf-8 -*-
"""4.17: ninguna exportación corre sola al pintar una pantalla, y las listas se ofrecen en PDF, Excel y CSV."""
import pathlib
import re

PAGES = pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js" / "pages"


def _paginas():
    for f in PAGES.rglob("*.js"):
        yield f.relative_to(PAGES).as_posix(), f.read_text(encoding="utf-8")


def _computed(t):
    """El bloque computed de un componente, contando llaves y saltando cadenas y comentarios."""
    for m in re.finditer(r"^  computed:\s*\{", t, re.M):
        i, d, q = m.end(), 1, None
        while i < len(t) and d:
            c = t[i]
            if q:
                if c == "\\":
                    i += 1
                elif c == q:
                    q = None
            elif c in "'\"`":
                q = c
            elif t[i:i + 2] == "//":
                i = t.find("\n", i)
            elif c == "{":
                d += 1
            elif c == "}":
                d -= 1
            i += 1
        yield t[m.end():i]


def test_ninguna_descarga_vive_en_computed():
    malos = [n for n, t in _paginas() for b in _computed(t) if re.search(r"descargarCSV\(|exportarTabla\(|exportarFilas\(|descargarTabla\(|URL\.createObjectURL", b)]
    assert malos == []


def test_facturas_exporta_desde_methods_y_sin_borradores():
    t = (PAGES / "ventas" / "facturas.js").read_text(encoding="utf-8")
    assert t.index("  methods: {") < t.index("    exportar() {") and "exportarCSV" not in t
    assert "this.rows.filter(r => r.estado !== 'borrador'), { titulo: 'Facturas de venta' }" in t


def test_solo_quedan_los_csv_que_deben_ser_csv():
    permitidos = {"reportes/_montos.js", "reportes/reporte.js", "rrhh/informes.js"}
    assert sorted(n for n, t in _paginas() if "descargarCSV(" in t and n not in permitidos) == []
    inf = (PAGES / "rrhh" / "informes.js").read_text(encoding="utf-8")
    assert inf.count("descargarCSV(") == 2 and "planilla_ccss_sicere_" in inf and "planilla_ins_riesgos_" in inf     # archivos oficiales
    assert sorted(n for n, t in _paginas() if "text/csv" in t) == ["hotel/reportes.js", "inventario/gestion.js", "reportes/_montos.js"]    # la plantilla de importación


def test_los_botones_csv_tienen_excel_y_no_quedan_exportaciones_falsas():
    for n, t in _paginas():
        assert "Exportación en preparación" not in t, n
        if re.search(r"@click(\.stop)?=\"\w+\([^\"]*'csv'\)\"", t):
            assert "'xlsx'" in t or "⤓ Excel" in t, n
    r = (PAGES / "reportes" / "reporte.js").read_text(encoding="utf-8")
    assert "descargarDoc('pdf')" in r and "⤓ Excel" in r and "⤓ CSV" in r


def test_la_funcion_comun_ofrece_los_tres_formatos():
    t = (PAGES / "reportes" / "_montos.js").read_text(encoding="utf-8")
    assert "[['pdf', 'PDF'], ['xlsx', 'Excel'], ['csv', 'CSV']]" in t
    assert "money(v || 0, r.moneda || principal())" in t                        # el dinero del PDF va en la moneda de cada fila


def test_registro_de_clientes_tambien_en_datos(monkeypatch):
    t = (PAGES / "admin.js").read_text(encoding="utf-8")
    assert "/api/admin/registro-clientes?formato=json" in t and "(CSV)</a>" not in t
