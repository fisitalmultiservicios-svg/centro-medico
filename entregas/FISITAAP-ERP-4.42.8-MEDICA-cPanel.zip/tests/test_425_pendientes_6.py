# -*- coding: utf-8 -*-
"""4.25 (encargo 6b): pendientes del servidor de la revisión de las tandas 4b, 5 y 6.

R1 (D-O) un descarte automático de la web no es una revocación: la señal trae motivo «sin_estrenar» y el programa queda desvinculado, sin
cuenta de bloqueo; R2 el tope de «iniciar» no gasta cupo sin internet y un intento nuevo sin sesión cancela los anteriores; R3 «no se sabe»
no es «retirada»; R4 la memoria de «vinculada alguna vez» al vincular; R5 reintentos del estado «fallo»; R6 acción propia en el Historial
para la cuenta de la computadora ya retirada; R7 pruebas que faltaban (candado, otra empresa, estado del programa).

Nube y computadora corren en el MISMO proceso (ver tests/test_425_conexion_programa.py, de donde salen las ayudas y la limpieza)."""
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
import pytest
from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine, select

from app import auth, modulos, sinc
from app.db import Auditoria, engine, engine_empresa, get_session
from app.main import app
from test_49_local_sinc import NUBE, PW, H, _Respuesta, _admin_empresa, _cfg, _poner_cfg, c
from test_425_conexion_nube import _aprobar, _limpiar_limitador, _pase, _vinc
from test_425_conexion_programa import (_limpieza, _conectar, _cuenta_local, _empresa_local, _estado, _iniciar, _llamadas,  # noqa: F401
                                        _membresias, _programa, _soltar_programa, _confirmar, _vivas)

RAIZ = Path(__file__).resolve().parent.parent


@pytest.fixture(autouse=True)
def _limpieza_6b():
    sinc._purgados.clear()
    yield
    sinc._purgados.clear()
    sinc._VINC_ALGUNA.clear()


def _auditoria(eid: int, accion: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == accion)).all()


def _sesiones_vivas(uid: int) -> list:
    with Session(engine) as sc:
        return sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid, auth.Sesion.revocada == False)).all()  # noqa: E712


def _token_local(cfg_eid: int) -> str:
    with Session(engine) as sc:
        e = sc.get(auth.Empresa, cfg_eid)
        return sinc.secretos.descifrar(e.clave_cifrada, _cfg(cfg_eid)["token"])


def _envejecer_conexiones(eid_n: int, minutos: int = 11) -> None:
    """Las instalaciones de conexión de la empresa de la web nacieron hace `minutos` minutos."""
    with Session(engine_empresa(eid_n)) as s:
        v = sinc._leer(s, eid_n, sinc.CLAVE_VINC, {})
        for i in v.get("instalaciones", []):
            if i.get("origen") == "conexion":
                i["creado"] = (datetime.now(timezone.utc) - timedelta(minutes=minutos)).isoformat(timespec="seconds")
        sinc._escribir(s, eid_n, sinc.CLAVE_VINC, v); s.commit()
    sinc._DESCARTE.clear()


# ------------------------------------------------------------------------------------------------------------------------ R1
def test_r1_descarte_por_tiempo_desvincula_sin_bloqueo_y_la_revocacion_de_una_persona_sigue_igual(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b1n", "3101425651")
    eid_l, tl = _admin_empresa("-s6b1l", "3101425651")
    shim = _programa(monkeypatch, sin_estrenar=False)
    miembros = sorted(m.id for m in _membresias(eid_l))
    v = _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))                 # RECONEXIÓN con sesión (sin la marca «primera»)
    assert v["empresa_id"] == eid_l and "primera" not in _cfg(eid_l)
    terminal, token = _cfg(eid_l)["terminal"], _token_local(eid_l)
    # se fue el internet justo después de recoger: a los 10 minutos la web la descarta sola
    _envejecer_conexiones(eid_n)
    with monkeypatch.context() as m:                                         # la lista de la web (el descarte no corre en el programa)
        m.setattr(sinc, "MODO_LOCAL", False)
        assert c.get("/api/sinc/instalaciones", headers=H(ta)).status_code == 200
    retirada = _vinc(eid_n)["retiradas"][-1]
    assert retirada["motivo"] == "sin_estrenar" and retirada["terminal"] == terminal and retirada["token_id"]
    # la señal: el mismo 401 y el mismo código de siempre (un programa anterior no mira el motivo), con el motivo
    r = c.get("/api/sinc/catalogo", headers=H(token))
    assert r.status_code == 401, r.text
    det_descarte = r.json()["detail"]
    assert det_descarte["codigo"] == sinc.CODIGO_REVOCADA and det_descarte["motivo"] == "sin_estrenar"
    # el programa: desvinculado, SIN revocada_en ni cuenta de bloqueo; terminal, membresías y datos se conservan
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg["vinculado"] is False and cfg["token"] is None and cfg["terminal"] == terminal
    assert not cfg.get("revocada_en") and not cfg.get("revocacion_explicita") and not cfg.get("bloqueada_en")
    assert cfg["ultimo_error"] == "La página web descartó esta conexión porque no se terminó a tiempo. Conecte la computadora de nuevo."
    assert sorted(m.id for m in _membresias(eid_l)) == miembros
    assert _auditoria(eid_l, "sinc_local_conexion_descartada") and not _auditoria(eid_l, "sinc_local_revocada")
    assert not (sinc._inst_estado.get(eid_l) or {}).get("revocada_en")
    # se puede volver a conectar con sesión (vuelve con su terminal)
    _soltar_programa()
    _limpiar_limitador()
    v2 = _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))
    assert v2["empresa_id"] == eid_l and _cfg(eid_l)["vinculado"] and _cfg(eid_l)["terminal"] == terminal
    # revocación hecha por una PERSONA: la señal de siempre, sin motivo, y el camino de siempre (revocada, 3 días)
    token2 = _token_local(eid_l)
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta)).status_code == 200
    r = c.get("/api/sinc/catalogo", headers=H(token2))
    assert r.status_code == 401 and r.json()["detail"]["codigo"] == sinc.CODIGO_REVOCADA and "motivo" not in r.json()["detail"]
    assert r.json()["detail"]["mensaje"] == det_descarte["mensaje"]
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg.get("revocada_en") and cfg.get("revocacion_explicita") and cfg["vinculado"]
    assert sorted(m.id for m in _membresias(eid_l)) == miembros


def test_r1_funciones_puras_del_motivo():
    # el programa solo reconoce «sin_estrenar»; sin motivo o con otro, revocación de siempre
    con = _Respuesta(401, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "x", "motivo": "sin_estrenar"}})
    sin = _Respuesta(401, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "x"}})
    otro = _Respuesta(401, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "x", "motivo": "cualquiera"}})
    for r, motivo in ((con, "sin_estrenar"), (sin, None), (otro, None)):
        with pytest.raises(sinc.Revocada) as ex:
            sinc._revisar_respuesta(r, "/api/sinc/catalogo")
        assert ex.value.motivo == motivo
    texto = (RAIZ / "app" / "static" / "js" / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "sinc_local_conexion_descartada: ['Seguridad', " in texto


def test_r1_configuracion_ilegible_va_sin_motivo(monkeypatch):
    # 4.25 (7b, T7b): la web, si no se puede leer la configuración de la empresa del token (error de lectura de verdad, empresa real),
    # va sin motivo; y no queda ninguna base de datos de más
    from app.db import EMPRESAS_DIR
    eid, _t = _admin_empresa("-t7b7b", "3101425679")
    t = auth.TokenApi(id=10 ** 9, empresa_id=eid, usuario_id=auth.TOKEN_EMPRESA, nombre="x", prefijo="x", hash="x", permisos="[]")
    with Session(engine_empresa(eid)) as s:                                         # la web SÍ lo anotó como descarte automático
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
        v.setdefault("retiradas", []).append({"terminal": 99, "token_id": t.id, "motivo": sinc.MOTIVO_SIN_ESTRENAR})
        sinc._escribir(s, eid, sinc.CLAVE_VINC, v); s.commit()
    assert sinc._descartada_sin_estrenar(t) is True                                   # leída de verdad: con motivo
    antes = sorted(p.name for p in EMPRESAS_DIR.glob("*.db"))
    llamadas = []

    def roto(x):
        llamadas.append(int(x))
        raise OSError("archivo ocupado por otro programa")
    monkeypatch.setattr(sinc, "engine_empresa", roto)
    assert sinc._descartada_sin_estrenar(t) is False                                  # no se pudo leer: sin motivo
    assert llamadas == [eid]                                                          # sí intentó leer (y falló)
    assert sorted(p.name for p in EMPRESAS_DIR.glob("*.db")) == antes


# ------------------------------------------------------------------------------------------------------------------------ R2
def test_r2_sin_internet_no_gasta_cupo_y_el_tope_cuenta_solo_lo_aceptado(monkeypatch):
    _admin_empresa("-s6b2a", "3101425652")
    shim = _programa(monkeypatch)
    monkeypatch.setattr(sinc, "TOPE_INICIAR_LOCAL", (3, 600))
    shim.por_ruta["/api/sinc/conexion/iniciar"] = httpx.ConnectError("sin red")
    for _ in range(5):
        r = _iniciar()
        assert r.status_code == 502, r.text
    shim.por_ruta.clear()
    for _ in range(3):
        assert _iniciar().status_code == 200
    llamadas = len(_llamadas(shim, "/api/sinc/conexion/iniciar"))
    r = _iniciar()
    assert r.status_code == 429 and r.json()["detail"] == sinc.MENSAJES_LOCAL["tope"]
    assert len(_llamadas(shim, "/api/sinc/conexion/iniciar")) == llamadas          # se rechazó antes de ir a la web


def test_r2_un_intento_nuevo_sin_sesion_cancela_los_anteriores_y_no_toca_los_de_otra_persona(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b2b", "3101425653")
    eid_l, tl = _admin_empresa("-s6b2c", "3101425654")
    shim = _programa(monkeypatch)
    # un intento CON sesión (otra persona, en su empresa)
    monkeypatch.setattr(sinc, "_sin_estrenar", lambda sc: False)
    con = _iniciar("Caja con sesión", H(tl)).json()
    monkeypatch.setattr(sinc, "_sin_estrenar", lambda sc: True)
    primeros = []
    for i in range(sinc.MAX_CONEXIONES + 2):                               # más que el cupo: nunca se llena
        r = _iniciar(f"Caja {i}")
        assert r.status_code == 200, r.text
        primeros.append(r.json()["intento"])
    for intento in primeros[:-1]:
        st = sinc._conexiones[intento]
        assert st["estado"] == "cancelada" and st["secreto"] is None
    assert sinc._conexiones[primeros[-1]]["estado"] == "esperando"
    assert sinc._conexiones[con["intento"]]["estado"] == "esperando"               # el de otra persona no se toca
    cancelados = [x[2] for x in _llamadas(shim, "/api/sinc/conexion/cancelar")]
    assert len(cancelados) == len(primeros) - 1
    assert all(_pase(secreto_hash=sinc._hash(x["secreto"])).estado == "cancelado" for x in cancelados)
    # la pantalla del intento viejo dice que se canceló
    v = _estado(primeros[0]).json()
    assert v["estado"] == "cancelada"


# ------------------------------------------------------------------------------------------------------------------------ R3
def test_r3_no_se_sabe_no_es_retirada(monkeypatch):
    vinc = _empresa_local("-s6b3", "3101425655", True)
    uid, correo = _cuenta_local(vinc, "cajera-local-s6b3", rol="Administrador")
    token_api = "fcr_" + "p3" + "x" * 40
    with Session(engine) as sc:
        tok = auth._respuesta(sc, sc.get(auth.Usuario, uid), vinc)["token"]
        t = auth.TokenApi(empresa_id=vinc, usuario_id=uid, nombre="Integración QA", prefijo=token_api[:12], hash=auth._hash_token_api(token_api), permisos='["ver"]')
        sc.add(t); sc.commit(); sc.refresh(t); tid = t.id
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    sinc._VINC_ALGUNA.clear()
    real = sinc.engine_empresa

    def ocupado(eid):
        if int(eid) == vinc:
            raise OSError("archivo ocupado por otro programa")
        return real(eid)
    monkeypatch.setattr(sinc, "engine_empresa", ocupado)
    assert sinc.vinculada_alguna_vez(vinc) is None and vinc not in sinc._VINC_ALGUNA     # no se guarda en la memoria
    with Session(engine) as sc:
        assert auth._cuenta_local_retirada(sc, sc.get(auth.Usuario, uid)) is None
        sinc.cerrar_cuentas_retiradas(sc)
    assert _sesiones_vivas(uid)
    r = c.get("/api/auth/yo", headers=H(tok))
    assert r.status_code == 503 and "inténtelo de nuevo" in r.text.lower(), r.text
    r = c.get("/api/auth/roles", headers=H(token_api))
    assert r.status_code == 503, r.text
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 503 and r.json()["detail"]["codigo"] == "reintentar" and "token" not in r.text, r.text
    assert _sesiones_vivas(uid)                                                       # nada se cerró ni se revocó
    with Session(engine) as sc:
        assert sc.get(auth.TokenApi, tid).revocado is False
        assert not sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login_cuenta_local")).all()
    # se vuelve a leer de verdad: ahora sí se revoca
    monkeypatch.setattr(sinc, "engine_empresa", real)
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 401
    assert not _sesiones_vivas(uid)


def test_r3_registro_ilegible_y_hay_vinculada(monkeypatch):
    eid = _empresa_local("-s6b3b", "3101425656", True)
    sinc._VINC_ALGUNA.clear()
    assert sinc.vinculada_alguna_vez(eid) is True
    sinc._VINC_ALGUNA.clear()
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, sinc.CLAVE_LOCAL)
        bueno, r.datos = r.datos, "{no es json"
        s.add(r); s.commit()
    try:
        assert sinc.vinculada_alguna_vez(eid) is None and eid not in sinc._VINC_ALGUNA
    finally:
        with Session(engine_empresa(eid)) as s:
            r = modulos._registro(s, eid, sinc.CLAVE_LOCAL)
            r.datos = bueno; s.add(r); s.commit()
    # hay_vinculada: «sí» manda sobre «no se sabe»; «no se sabe» manda sobre «no»
    with Session(engine) as sc:
        eids = [e.id for e in sc.exec(select(auth.Empresa)).all()]
    primera, ultima = eids[0], eids[-1]
    for valores, esperado in (({primera: None, ultima: True}, True), ({primera: None}, None), ({}, False)):
        monkeypatch.setattr(sinc, "vinculada_alguna_vez", lambda x, v=valores: v.get(x, False))
        assert sinc.hay_vinculada() is esperado, valores
    # sin poder leer la lista de empresas: no se sabe
    monkeypatch.setattr(sinc, "Session", lambda *_a, **_k: (_ for _ in ()).throw(OSError("ocupado")))
    assert sinc.hay_vinculada() is None


# ------------------------------------------------------------------------------------------------------------------------ R4
def test_r4_al_vincular_se_olvida_el_no_y_se_cierran_las_cuentas_locales_en_el_momento(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b4n", "3101425657")
    eid_l = _empresa_local("-s6b4l", "3101425658", False)
    uid, correo = _cuenta_local(eid_l, "admin-local-s6b4", rol="Administrador", mfa_activo=True, consiente_factura=True)
    _, correo2 = _cuenta_local(eid_l, "cajera-local-s6b4")
    with Session(engine) as sc:
        tok = auth._respuesta(sc, sc.get(auth.Usuario, uid), eid_l)["token"]
    # el canje lo contesta la «web» (con FE_MODO_LOCAL=1 su ruta daría 404 en este mismo proceso)
    from test_49_local_sinc import _soltar_limite_vinculacion
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja P4"}).json()["codigo"]
    canje = c.post("/api/sinc/canje", json={"codigo": codigo, "nombre": "Caja P4"})
    assert canje.status_code == 200, canje.text
    shim = _programa(monkeypatch, sin_estrenar=False)
    shim.por_ruta["/api/sinc/canje"] = _Respuesta(200, canje.json())
    monkeypatch.setattr(sinc, "sincronizar", lambda eid: None)
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    sinc._VINC_ALGUNA.clear()
    r = c.get("/api/auth/yo", headers=H(tok))                                         # deja anotado el «no» de esta empresa
    assert r.status_code == 200, r.text
    assert sinc._VINC_ALGUNA[eid_l][0] is False
    assert _sesiones_vivas(uid)
    r = c.post("/api/sinc/local/vincular", headers=H(tok), json={"codigo": codigo, "nombre": "Caja P4"})
    assert r.status_code == 200, r.text
    assert sinc._VINC_ALGUNA[eid_l][0] is True
    assert not _sesiones_vivas(uid)                                                   # se cerraron en ese momento
    r = c.post("/api/auth/login", json={"correo": correo2, "password": PW})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local", r.text


# ------------------------------------------------------------------------------------------------------------------------ R5
def test_r5_fallo_reintenta_una_vez_por_minuto_audita_una_vez_y_purgado_dice_la_verdad(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b5", "3101425659")
    _programa(monkeypatch)
    veces = []
    real = sinc._aplicar_usuarios_recogida
    falla = [True]

    def aplicar(sc, eid, j):
        veces.append(eid)
        if falla[0]:
            raise OSError("disco lleno")
        return real(sc, eid, j)
    monkeypatch.setattr(sinc, "_aplicar_usuarios_recogida", aplicar)
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    _estado(j["intento"])
    assert _confirmar(j["intento"], a["numero"]).json()["estado"] == "fallo"
    st = sinc._conexiones[j["intento"]]
    eid_l = st["eid_destino"]
    assert len(veces) == 1
    for _ in range(10):                                                              # el sondeo (cada 3 s) no reintenta antes de un minuto
        assert _estado(j["intento"]).json()["estado"] == "fallo"
    assert len(veces) == 1
    st["fallo_en"] -= sinc.SEGUNDOS_REINTENTO_FALLO + 1                               # pasó un minuto: el sondeo reintenta una vez
    _estado(j["intento"]); _estado(j["intento"])
    assert len(veces) == 2
    r = c.post("/api/sinc/local/conexion/reintentar", json={"intento": j["intento"]})  # «Reintentar»: en el momento
    assert r.json()["estado"] == "fallo" and len(veces) == 3
    assert len(_auditoria(eid_l, "sinc_local_conexion_fallida")) == 1                  # una sola fila por intento
    # se purga por tiempo sin terminar: la ruta dice la verdad
    st["limite"] = time.time() - sinc.SEGUNDOS_INFORME - 1
    r = c.post("/api/sinc/local/conexion/reintentar", json={"intento": j["intento"]})
    assert r.status_code == 410 and r.json()["detail"] == {"codigo": "intento_perdido", "mensaje": "No se pudo terminar de conectar: empiece de nuevo."}
    r = c.post("/api/sinc/local/conexion/reintentar", json={"intento": "no-existe"})
    assert r.status_code == 410 and r.json()["detail"]["mensaje"] == sinc.MENSAJE_INTENTO_PERDIDO


# ------------------------------------------------------------------------------------------------------------------------ R6
def test_r6_accion_propia_para_la_cuenta_local_retirada(monkeypatch):
    vinc = _empresa_local("-s6b6", "3101425660", True)
    uid, correo = _cuenta_local(vinc, "cajera-local-s6b6")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local"
    with Session(engine) as sc:
        acciones = [a.accion for a in sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid)).all()]
    assert "login_cuenta_local" in acciones and "login_rechazado" not in acciones
    texto = (RAIZ / "app" / "static" / "js" / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "login_cuenta_local: ['Seguridad', 'Acceso rechazado: cuenta de esta computadora que ya no se usa']" in texto
    assert "login_rechazado: ['Seguridad', 'Acceso rechazado (cuenta bloqueada)']" in texto


# ------------------------------------------------------------------------------------------------------------------------ R7
def test_r7a_aplicar_espera_al_ciclo_de_sincronizacion(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b7n", "3101425661")
    eid_l, tl = _admin_empresa("-s6b7l", "3101425661")
    _programa(monkeypatch, sin_estrenar=False)
    j = _iniciar("Caja", H(tl)).json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert _estado(j["intento"], H(tl)).json()["estado"] == "confirmar"
    orden = []
    real = sinc._aplicar_vinculacion

    def aplica(*args, **kw):
        orden.append("aplica")
        return real(*args, **kw)
    monkeypatch.setattr(sinc, "_aplicar_vinculacion", aplica)
    tomado = threading.Event()

    def ciclo():
        with sinc._lock:
            sinc._en_curso[eid_l] = True                                              # un ciclo de sincronización en curso
        tomado.set()
        time.sleep(0.8)
        orden.append("ciclo_termina")
        sinc._soltar_candado(eid_l)
    h = threading.Thread(target=ciclo)
    h.start()
    tomado.wait(5)
    v = _confirmar(j["intento"], a["numero"], cab=H(tl)).json()
    h.join(5)
    assert v["estado"] == "lista", v
    assert orden == ["ciclo_termina", "aplica"]
    assert sinc._en_curso.get(eid_l) is False


def test_r7b_otra_empresa_cancela_el_pase_y_no_aplica_nada(monkeypatch):
    eid_n, ta = _admin_empresa("-s6b8n", "3101425662")
    eid_l, tl = _admin_empresa("-s6b8l", "3101425663")
    shim = _programa(monkeypatch, sin_estrenar=False)
    j = _iniciar("Caja", H(tl)).json()
    assert _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]["cedula"] is None       # todavía sin datos
    _poner_cfg(eid_l, terminal=7)                                                     # mientras tanto quedó con datos de SU cédula
    antes = len(_vivas(eid_n))
    a = _aprobar(ta, j["codigo"], eid_n).json()
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "otra_empresa", v
    assert _pase(id=a["pase"]).estado == "cancelado"
    cfg = _cfg(eid_l)
    assert not cfg.get("vinculado") and not cfg.get("token") and cfg["terminal"] == 7
    assert len(_vivas(eid_n)) == antes
    assert not _auditoria(eid_l, "sinc_local_vinculada")


def test_r7c_estado_del_programa_nueva_y_admin_local(monkeypatch):
    e2 = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    SQLModel.metadata.create_all(e2, tables=[auth.Usuario.__table__, auth.UsuarioEmpresa.__table__, auth.Sesion.__table__, Auditoria.__table__])

    def sesion():
        with Session(e2) as s:
            yield s
    app.dependency_overrides[get_session] = sesion
    try:
        monkeypatch.setenv("FE_MODO_LOCAL", "1")
        monkeypatch.delenv("FE_LOCAL_ADMIN", raising=False)
        monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
        j = c.get("/api/auth/estado").json()["local"]
        assert j["nueva"] is True and j["admin_local"] is False                      # computadora sin estrenar
        with Session(e2) as sc:                                                       # el primer ingreso: cuenta que entra y su sesión
            u = auth.Usuario(correo="primera-s6b9@example.test", nombre="Primera", password_hash=auth.hash_password(PW), de_nube=True)
            sc.add(u); sc.commit(); sc.refresh(u)
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=1, rol="Administrador"))
            sc.add(auth.Sesion(sid="sid-s6b9", usuario_id=u.id)); sc.add(Auditoria(accion="login", usuario_id=u.id)); sc.commit()
        j = c.get("/api/auth/estado").json()["local"]
        assert j["nueva"] is False and j["admin_local"] is False
        monkeypatch.setenv("FE_LOCAL_ADMIN", "1")
        assert c.get("/api/auth/estado").json()["local"]["admin_local"] is True
    finally:
        app.dependency_overrides.pop(get_session, None)
