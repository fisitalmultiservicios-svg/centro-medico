# -*- coding: utf-8 -*-
"""4.31, P-1 del diseño «la misma mesa» (exe430/diseno_mesa.md, 8): la regla escrita dos veces da lo MISMO en los dos lados.

- Los mismos casos de tests/test_431_fusion_casos.json pasan por app/fusion_cuentas.py (Python) y por pages/pos/_fusion.js (Node), y los
  dos resultados tienen que ser iguales entre sí y a `esperado` (unir con su `fusiono` y, si es repetible, la segunda pasada también).
- Además, unos cientos de cuentas armadas al azar (con semilla fija: siempre las mismas) pasan por los dos lados: unir (con y sin
  `_fusion`, con orígenes y datos raros), cerrar, recrear y poner_lids. Los dos tienen que dar exactamente lo mismo.
Comparación: igualdad profunda de JSON, números por valor (1 == 1.0), el orden de las claves no importa, el de las listas sí; una clave
ausente no es lo mismo que una en null; true no es 1. Nada va a la red ni a un servidor."""
import copy
import json
import pathlib
import random

import pytest

from app import fusion_cuentas as fc
from tests.test_425_ultimos_pantallas import _node

RAIZ = pathlib.Path(__file__).resolve().parents[1]
CASOS = RAIZ / "tests" / "test_431_fusion_casos.json"


def _igual(a, b) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return float(a) == float(b)
    if isinstance(a, list) or isinstance(b, list):
        return isinstance(a, list) and isinstance(b, list) and len(a) == len(b) and all(_igual(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) or isinstance(b, dict):
        return isinstance(a, dict) and isinstance(b, dict) and set(a) == set(b) and all(_igual(a[k], b[k]) for k in a)
    return a == b


# ------------------------------------------------------------------------------------------------ un lado y el otro
def _python(c: dict):
    """El resultado de Python para un caso, con la misma forma que devuelve el guion de Node."""
    f = c["funcion"]
    if f == "unir":
        res, fus = fc.unir(copy.deepcopy(c["guardada"]), copy.deepcopy(c["nueva"]))
        otra = fc.unir(copy.deepcopy(res), copy.deepcopy(c["nueva"]))[0] if c.get("repetible") else None
        return {"r": res, "f": fus, "otra": otra}
    if f == "cerrar":
        res = fc.cerrar(copy.deepcopy(c["guardada"]), copy.deepcopy(c["condicion"]))
        return {"r": res, "otra": fc.cerrar(copy.deepcopy(res), copy.deepcopy(c["condicion"])) if res is not None and c.get("repetible") else None}
    if f == "recrear":
        return {"r": fc.recrear(copy.deepcopy(c["nueva"]), c["id_viejo"], c["id_nuevo"])}
    if f == "poner_lids":
        return {"r": fc.poner_lids(copy.deepcopy(c["cuenta"]))}
    raise AssertionError("función desconocida: " + f)


GUION_JS = """
const F = await import('./js/pages/pos/_fusion.js');
const fs = await import('node:fs');
const casos = JSON.parse(fs.readFileSync('./casos.json', 'utf-8'));
const copia = v => (v === undefined || v === null ? v : JSON.parse(JSON.stringify(v)));
const out = [];
for (const c of casos) {
  try {
    if (c.funcion === 'unir') {
      const [r, f] = F.unir(copia(c.guardada), copia(c.nueva));
      const otra = c.repetible ? F.unir(copia(r), copia(c.nueva))[0] : null;
      out.push({ r, f, otra });
    } else if (c.funcion === 'cerrar') {
      const r = F.cerrarCuenta(copia(c.guardada), copia(c.condicion));
      out.push({ r, otra: r !== null && c.repetible ? F.cerrarCuenta(copia(r), copia(c.condicion)) : null });
    } else if (c.funcion === 'recrear') out.push({ r: F.recrearCuenta(copia(c.nueva), c.id_viejo, c.id_nuevo) });
    else if (c.funcion === 'poner_lids') out.push({ r: F.ponerLids(copia(c.cuenta)) });
    else out.push({ error: 'función desconocida' });
  } catch (e) { out.push({ error: String(e && e.stack || e) }); }
}
console.log(JSON.stringify(out));
"""


def _javascript(tmp_path, casos: list) -> list:
    (tmp_path / "casos.json").write_text(json.dumps(casos, ensure_ascii=False), encoding="utf-8")
    return _node(tmp_path, GUION_JS, archivos=("pages/pos/_fusion.js",), falsos={})


def _diferencias(casos, py, js):
    malos = []
    for c, p, j in zip(casos, py, js):
        if "error" in j:
            malos.append((c["nombre"], "JS lanzó", j["error"][:300]))
            continue
        for k in p:
            if not _igual(p[k], j.get(k)):
                malos.append((c["nombre"], k, json.dumps(p[k], ensure_ascii=False)[:600], json.dumps(j.get(k), ensure_ascii=False)[:600]))
    return malos


# ------------------------------------------------------------------------------------------------ 1) los casos compartidos
def test_p1_los_casos_compartidos_dan_lo_mismo_en_python_y_en_node(tmp_path):
    if not CASOS.exists():
        pytest.skip("faltan los casos compartidos")
    casos = json.loads(CASOS.read_text(encoding="utf-8"))["casos"]
    assert len(casos) >= 40
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    assert not _diferencias(casos, py, js), _diferencias(casos, py, js)
    # y los dos dan `esperado` (con su `fusiono` y la repetición)
    for c, p in zip(casos, py):
        assert _igual(p["r"], c["esperado"]), c["nombre"]
        if c["funcion"] == "unir":
            assert p["f"] == c["fusiono"], c["nombre"]
            if c.get("repetible"):
                assert _igual(p["otra"], c["esperado"]), c["nombre"]


# ------------------------------------------------------------------------------------------------ 2) cuentas al azar (semilla fija)
PLATOS = [(1, "Casado", 3500), (2, "Limonada", 1500), (3, "Postre", 1200), (4, "Cerveza", 1800), (None, "Envío a domicilio", 1500), ("9", "Té", 900), (2.5, "Raro", 100)]
ENVIOS = [None, None, "2026-11-12T12:00:00.000Z", "2026-11-12T12:05:00.000Z", ""]
LIDS = ["lA", "lB", "lC", "lD", "lE"]


def _linea(rnd: random.Random, con_lid: bool) -> dict:
    pid, det, precio = rnd.choice(PLATOS)
    cant = rnd.choice([1, 1, 2, 3, 0.5, 1.25, 0])
    l = {"producto_id": pid, "detalle": det, "cantidad": cant, "precio_unitario": precio, "tarifa": 13, "descuento_pct": 0, "descuento": 0,
         "nota": rnd.choice(["", "", "sin sal"]), "enviado": rnd.choice(ENVIOS), "ronda": rnd.choice([0, 1, 2])}
    if con_lid:
        l["lid"] = rnd.choice(LIDS + ["l" + str(rnd.randint(1, 9))])
    if rnd.random() < 0.6:
        l["importe"] = round(cant * precio * 1.13, 5)
        l["importe_de"] = [cant, precio, 0, 0]
    if rnd.random() < 0.2:
        l[rnd.choice(fc.CAMPOS_MARCA)] = rnd.choice(["2026-11-12T12:10:00.000Z", True, 7])
    if rnd.random() < 0.15:                                    # 4.31 (corrección): el resto de una línea partida lleva «de»
        l["de"] = rnd.choice(LIDS + ["", 7])
    return l


def _cuenta(rnd: random.Random) -> dict:
    n = rnd.randint(0, 5)
    lineas = [_linea(rnd, rnd.random() < 0.6) for _ in range(n)]
    v = {"id": 6, "nombre": "Mesa 6", "mesa_id": 6, "mesas_ids": [6], "terminal_id": 1, "salonero": "Ana", "servicio": False, "servicio_pct": 10,
         "cliente_id": None, "nota": "", "lineas": lineas, "cobros": [], "partes": None, "creado": "2026-11-12T11:59:00.000Z",
         "actualizado": "2026-11-12T12:01:00.000Z", "usuario": "b@example.test", "total": rnd.choice([0, 6150.0, 1234.56])}
    if rnd.random() < 0.3:
        v["cobros"] = [{"doc_id": rnd.randint(1, 3), "consecutivo": "C" + str(rnd.randint(1, 3)), "monto": 1000}]
    if rnd.random() < 0.2:
        v["cobros"].append({"monto": 500, "hora": "x"})
    if rnd.random() < 0.3:
        v["partes"] = {"de": 2, "cobradas": rnd.randint(0, 2)}
    if rnd.random() < 0.3:
        v["lids_quitados"] = rnd.sample(LIDS, rnd.randint(0, 3))
    if rnd.random() < 0.15:
        v["recreada_de"] = 5
    if rnd.random() < 0.1:
        v["pedido_id"] = 45
        v["prepago"] = 2000
        if rnd.random() < 0.5:                                 # 4.31 (corrección): lo del pedido en línea que no se hereda
            v.update(canal="online", cupon="QA", puntos_canjeados=10, credito=False, pedido_numero=45)
    return v


def _nueva_desde(rnd: random.Random, g: dict) -> dict:
    n = copy.deepcopy(g) if g else _cuenta(rnd)
    lineas = n.get("lineas") or []
    # quitar, cambiar y agregar líneas (como una pantalla atrasada o al día)
    lineas = [l for l in lineas if rnd.random() > 0.25]
    for l in lineas:
        if rnd.random() < 0.3:
            l["cantidad"] = rnd.choice([1, 2, 4, 0.5])
        if rnd.random() < 0.2:
            l["nota"] = "con hielo"
        if rnd.random() < 0.15:
            l["listo"] = "2026-11-12T12:20:00.000Z"
        if rnd.random() < 0.1:
            l.pop("importe", None)
    for _ in range(rnd.randint(0, 3)):
        lineas.append(_linea(rnd, rnd.random() < 0.8))
    rnd.shuffle(lineas) if rnd.random() < 0.15 else None
    n["lineas"] = lineas
    if rnd.random() < 0.3:
        n["nombre"] = "Mesa 6 (Ana)"
    if rnd.random() < 0.2:
        n["mesa_id"] = 8
    if rnd.random() < 0.2:
        n["cobros"] = (n.get("cobros") or []) + [{"doc_id": 9, "consecutivo": "C9", "monto": 300}]
    if rnd.random() < 0.2:
        n["partes"] = rnd.choice([None, {"de": 2, "cobradas": 1}, {"de": 3, "cobradas": 0}])
    for k in ("lids_quitados", "recreada_de"):
        if rnd.random() < 0.5:
            n.pop(k, None)
    n["actualizado"] = "2026-11-12T12:30:00.000Z"
    n["usuario"] = "a@example.test"
    n["total"] = rnd.choice([n.get("total", 0), 9999.99, 2.675])
    # el _fusion: válido casi siempre; a veces raro o ausente (paso 0)
    p = rnd.random()
    if p < 0.12:
        return n
    lids_n = [l.get("lid") for l in lineas if isinstance(l.get("lid"), str)]
    lids_g = [l.get("lid") for l in (g or {}).get("lineas") or [] if isinstance(l.get("lid"), str)] + ["h:6:1:2026-11-12T12:00:00.000Z:0", "h:6:2::0"]
    f = {"v": 1, "equipo": "e0123456789abcdef", "origen": rnd.choice(["caja", "caja", "caja", "cocina", "servidor"]),
         "nuevas": sorted(set(rnd.sample(lids_n, rnd.randint(0, len(lids_n))))) if lids_n else [],
         "quitadas": {x: rnd.choice([1, 2, 0.5, 3]) for x in rnd.sample(lids_g, rnd.randint(0, min(3, len(lids_g))))},
         "campos": {x: sorted(rnd.sample(["cantidad", "nota", "listo", "impreso", "comanda", "descuento_pct"], rnd.randint(1, 3))) for x in rnd.sample(lids_n, min(len(lids_n), rnd.randint(0, 2)))},
         "cuenta": sorted(rnd.sample(["nombre", "mesa_id", "nota", "partes", "cobros", "cliente_id", "estado"], rnd.randint(0, 3)))}
    if p < 0.18:
        f = rnd.choice([{"v": 2}, True, "x", [], {"v": 1, "origen": "otro"}, {"v": True, "origen": "caja"}, {"v": 1, "origen": "caja", "nuevas": "x"},
                        {"v": 1, "origen": "caja", "quitadas": {"lA": "dos"}}, {"v": 1, "origen": "caja", "campos": []},
                        {"v": 1, "origen": "caja", "quitadas": []}, {"v": 1, "origen": "caja", "nuevas": {}}, {"v": 1, "origen": "caja", "cuenta": {}},
                        {"v": 1, "origen": "caja", "campos": [1]}, {"v": 1, "origen": "caja", "nuevas": {"a": 1}}])
    n["_fusion"] = f
    return n


def _al_azar(semilla: int, cuantos: int) -> list:
    rnd = random.Random(semilla)
    casos = []
    for i in range(cuantos):
        tipo = rnd.random()
        if tipo < 0.6:
            g = None if rnd.random() < 0.05 else _cuenta(rnd)
            n = _nueva_desde(rnd, g)
            casos.append({"nombre": "azar_unir_%d" % i, "funcion": "unir", "guardada": g, "nueva": n, "repetible": g is not None and rnd.random() < 0.5})
        elif tipo < 0.78:
            g = _cuenta(rnd)
            lids = [l.get("lid") for l in g["lineas"] if isinstance(l.get("lid"), str)] + ["h:6:1:2026-11-12T12:00:00.000Z:0", "h:6:3::0", "lZ"]
            cond = {"v": 1, "quitadas": {x: rnd.choice([1, 2, 0.5]) for x in rnd.sample(lids, rnd.randint(0, min(4, len(lids))))}}
            if rnd.random() < 0.3:                             # 4.31 (corrección): la baja que viene de un cobro
                cond["cobro"] = rnd.choice([True, True, 1, "si"])
            if rnd.random() < 0.1:
                cond = rnd.choice([{"v": 2}, None, {"v": 1, "quitadas": {"lA": "x"}}, {"v": 1}, {"v": 1, "quitadas": []}, {"v": 1, "quitadas": [], "cobro": True}])
            casos.append({"nombre": "azar_cerrar_%d" % i, "funcion": "cerrar", "guardada": g, "condicion": cond, "repetible": True})
        elif tipo < 0.9:
            g = _cuenta(rnd)
            n = _nueva_desde(rnd, g)
            casos.append({"nombre": "azar_recrear_%d" % i, "funcion": "recrear", "nueva": n, "id_viejo": 6, "id_nuevo": rnd.choice([7, 12])})
        else:
            casos.append({"nombre": "azar_lids_%d" % i, "funcion": "poner_lids", "cuenta": _cuenta(rnd)})
    return casos


@pytest.mark.parametrize("semilla", [431, 4310, 43100])
def test_p1_cuentas_al_azar_dan_lo_mismo_en_python_y_en_node(tmp_path, semilla):
    casos = _al_azar(semilla, 400)
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    malos = _diferencias(casos, py, js)
    assert not malos, (len(malos), malos[:5])
    # la prueba no es vacía: hubo fusiones de verdad, bajas conservadas y recreadas
    assert sum(1 for c, p in zip(casos, py) if c["funcion"] == "unir" and p["f"]) > 20
    assert sum(1 for c, p in zip(casos, py) if c["funcion"] == "cerrar" and p["r"] is not None) > 10
    assert sum(1 for c, p in zip(casos, py) if c["funcion"] == "recrear" and p["r"] is not None) > 5


# ------------------------------------------------------------------------------------------------ 3) recrear con restos de líneas partidas
def _recrear_con_restos(semilla: int, cuantos: int) -> list:
    """4.31 (tercera vuelta): guardados atrasados que llegan a una cuenta ya cerrada con el resto de una línea partida (`de`): unas veces su
    línea de origen se quita en ese mismo guardado (era de la cuenta cerrada: no pasa a la nueva) y otras no."""
    rnd = random.Random(semilla)
    casos = []
    for i in range(cuantos):
        g = _cuenta(rnd)
        n = _nueva_desde(rnd, g)
        f = n.get("_fusion")
        if not isinstance(f, dict) or not isinstance(f.get("quitadas", {}), dict) or not isinstance(f.get("nuevas", []), list):
            continue
        lids_g = [l["lid"] for l in g["lineas"] if isinstance(l.get("lid"), str)] + ["h:6:1:2026-11-12T12:00:00.000Z:0", "lZ"]
        de = rnd.choice(lids_g)
        resto = _linea(rnd, False)
        resto.update(lid="r%d" % i, de=de, cantidad=rnd.choice([1, 0.5, 2]))
        n["lineas"] = list(n.get("lineas") or []) + [resto]
        f["nuevas"] = sorted(set(x for x in (f.get("nuevas") or []) if isinstance(x, str)) | {resto["lid"]})
        if rnd.random() < 0.6:
            f["quitadas"] = {**(f.get("quitadas") or {}), de: rnd.choice([1, 2, 0.5])}
        casos.append({"nombre": "restos_recrear_%d" % i, "funcion": "recrear", "nueva": n, "id_viejo": 6, "id_nuevo": rnd.choice([7, 12])})
    return casos


@pytest.mark.parametrize("semilla", [4312, 43120])
def test_recrear_con_restos_de_lineas_partidas_da_lo_mismo_en_python_y_en_node(tmp_path, semilla):
    casos = _recrear_con_restos(semilla, 300)
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    malos = _diferencias(casos, py, js)
    assert not malos, (len(malos), malos[:5])
    fuera = dentro = 0
    for c, p in zip(casos, py):
        resto = c["nueva"]["lineas"][-1]
        q = c["nueva"]["_fusion"].get("quitadas") or {}
        if p["r"] is None:
            continue
        lids = [l["lid"] for l in p["r"]["lineas"]]
        if isinstance(q, dict) and resto["de"] in q and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in q.values()):
            assert resto["lid"] not in lids and resto["lid"] in p["r"].get("lids_quitados", []), c["nombre"]   # el resto de lo cobrado no pasa
            fuera += 1
        elif resto["lid"] in lids:
            dentro += 1
    assert fuera > 20 and dentro > 20, (fuera, dentro)                  # la prueba no es vacía: de los dos tipos


# ------------------------------------------------------------------------------------------------ 4) bajas por cobro con restos de líneas partidas
def _cerrar_con_restos(semilla: int, cuantos: int) -> list:
    """4.31 (cuarta vuelta): bajas a una cuenta donde otro equipo dejó el resto (`de`) de una línea partida. Unas veces la baja viene de un
    cobro que cerró esa línea entera (el resto se va con lo cobrado) y otras no (sin `cobro`, o con un `cobro` que no es true: el resto queda)."""
    rnd = random.Random(semilla)
    casos = []
    for i in range(cuantos):
        g = _cuenta(rnd)
        origen = rnd.choice(LIDS + ["lZ", "h:6:1:2026-11-12T12:00:00.000Z:0"])
        resto = _linea(rnd, False)
        resto.update(lid="r%d" % i, de=origen, cantidad=rnd.choice([1, 0.5, 2]))
        g["lineas"] = list(g["lineas"]) + [resto]
        if rnd.random() < 0.7:
            g["lids_quitados"] = sorted(set(g.get("lids_quitados") or []) | {origen})
        lids = [l.get("lid") for l in g["lineas"][:-1] if isinstance(l.get("lid"), str)] + ["lZ"]
        quitadas = {x: rnd.choice([1, 2, 0.5]) for x in rnd.sample(lids, rnd.randint(0, min(2, len(lids))))}
        if rnd.random() < 0.7:
            quitadas[origen] = rnd.choice([1, 2])
        cond = {"v": 1, "quitadas": quitadas}
        if rnd.random() < 0.65:
            cond["cobro"] = rnd.choice([True, True, True, 1, "si"])
        casos.append({"nombre": "restos_cerrar_%d" % i, "funcion": "cerrar", "guardada": g, "condicion": cond, "repetible": True})
    return casos


@pytest.mark.parametrize("semilla", [4314, 43140])
def test_baja_por_cobro_con_restos_de_lineas_partidas_da_lo_mismo_en_python_y_en_node(tmp_path, semilla):
    casos = _cerrar_con_restos(semilla, 300)
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    malos = _diferencias(casos, py, js)
    assert not malos, (len(malos), malos[:5])
    se_va = queda = 0
    for c, p in zip(casos, py):
        resto, cond = c["guardada"]["lineas"][-1], c["condicion"]
        lids = [l["lid"] for l in p["r"]["lineas"]] if p["r"] is not None else []
        if cond.get("cobro") is True and resto["de"] in cond["quitadas"]:
            assert resto["lid"] not in lids, c["nombre"]                                     # se va con lo cobrado
            assert p["r"] is None or resto["lid"] in p["r"]["lids_quitados"], c["nombre"]
            se_va += 1
        else:
            assert resto["lid"] in lids, c["nombre"]                                         # queda: no lo cerró un cobro
            queda += 1
    assert se_va > 40 and queda > 40, (se_va, queda)                    # la prueba no es vacía: de los dos tipos


# ------------------------------------------------------------------------------------------------ 5) la parte que vuelve y lo cobrado entero
def _vuelve_y_enteras(semilla: int, cuantos: int) -> list:
    """4.31 (quinta vuelta): guardados de la caja con `vuelve` (la parte de un cobro cerrado sin cobrar sumada a una línea que a veces ya
    no está en la cuenta, o ya volvió, o ya se cobró) y con `enteras` (líneas cobradas enteras cuyo resto `de` dejó otro equipo). Unir,
    recrear y la segunda pasada tienen que dar lo mismo en los dos lados."""
    rnd = random.Random(semilla)
    casos = []
    for i in range(cuantos):
        g = _cuenta(rnd)
        n = _nueva_desde(rnd, g)
        f = n.get("_fusion")
        if not isinstance(f, dict) or rnd.random() < 0.05:
            f = n["_fusion"] = {"v": 1, "equipo": "e5", "origen": "caja", "nuevas": [], "quitadas": {}, "campos": {}, "cuenta": []}
        lids_n = [l["lid"] for l in n.get("lineas") or [] if isinstance(l.get("lid"), str)]
        lids_g = [l["lid"] for l in g["lineas"] if isinstance(l.get("lid"), str)]
        if lids_n and rnd.random() < 0.8:
            f["vuelve"] = {x: rnd.choice([1, 2, 0.5, 0, 1.25]) for x in rnd.sample(lids_n, rnd.randint(1, min(3, len(lids_n))))}
            if rnd.random() < 0.3:                             # la línea ya no está en la cuenta (otro equipo la cobró)
                quita = set(f["vuelve"])
                g["lineas"] = [l for l in g["lineas"] if l.get("lid") not in quita]
                g["lids_quitados"] = sorted(set(g.get("lids_quitados") or []) | quita)
            if rnd.random() < 0.2:                             # ya volvió antes (o ya se cobró lo que volvió)
                x = rnd.choice(sorted(f["vuelve"]))
                if rnd.random() < 0.5:
                    g["lineas"] = list(g["lineas"]) + [{**_linea(rnd, False), "lid": x + "+v"}]
                else:
                    g["lids_quitados"] = sorted(set(g.get("lids_quitados") or []) | {x + "+v"})
        if rnd.random() < 0.6:
            origen = rnd.choice(LIDS + ["lZ"])
            resto = _linea(rnd, False)
            resto.update(lid="r%d" % i, de=origen, cantidad=rnd.choice([1, 0.5, 2]))
            g["lineas"] = list(g["lineas"]) + [resto]
            f["enteras"] = sorted(set(rnd.sample(LIDS + ["lZ"], rnd.randint(0, 2))) | ({origen} if rnd.random() < 0.7 else set()))
            if rnd.random() < 0.3:                             # el resto también va en lo que manda esta pantalla
                n["lineas"] = list(n.get("lineas") or []) + [dict(resto)]
                f["nuevas"] = sorted(set(x for x in f.get("nuevas") or [] if isinstance(x, str)) | {resto["lid"]})
        if rnd.random() < 0.08:                                # datos raros: lo de antes en los dos lados
            f[rnd.choice(["vuelve", "enteras"])] = rnd.choice([[], "x", {"lA": "uno"}, [1], {"lA": True}, None])
        if rnd.random() < 0.15:
            f["origen"] = rnd.choice(["cocina", "servidor"])
        if rnd.random() < 0.7:
            casos.append({"nombre": "vuelve_unir_%d" % i, "funcion": "unir", "guardada": g, "nueva": n, "repetible": True})
        else:
            casos.append({"nombre": "vuelve_recrear_%d" % i, "funcion": "recrear", "nueva": n, "id_viejo": 6, "id_nuevo": rnd.choice([7, 12])})
    return casos


@pytest.mark.parametrize("semilla", [4315, 43150])
def test_vuelve_y_enteras_dan_lo_mismo_en_python_y_en_node(tmp_path, semilla):
    casos = _vuelve_y_enteras(semilla, 300)
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    malos = _diferencias(casos, py, js)
    assert not malos, (len(malos), malos[:5])
    volvio = salio = 0                                         # la prueba no es vacía: hubo partes que volvieron y restos que salieron
    for c, p in zip(casos, py):
        if p["r"] is None:
            continue
        lids = {l.get("lid") for l in p["r"].get("lineas") or []}
        volvio += sum(1 for x in lids if isinstance(x, str) and x.endswith("+v") and x not in {l.get("lid") for l in (c.get("guardada") or {}).get("lineas") or []})
        if c["funcion"] == "unir":
            salio += sum(1 for l in c["guardada"]["lineas"] if isinstance(l.get("lid"), str) and l["lid"].startswith("r") and l["lid"] not in lids
                         and l["lid"] in (p["r"].get("lids_quitados") or []))
        if c["funcion"] == "unir" and p["otra"] is not None:
            assert _igual(p["otra"], p["r"]), c["nombre"]          # un reenvío no agrega la parte otra vez
    assert volvio > 20 and salio > 20, (volvio, salio)


# ------------------------------------------------------------------------------------------------ 6) sexta vuelta: partes a la vez y el 2x1 de lo que vuelve
PROMOS = [("", 0), ("2x1 cervezas", 50), ("2x1 cervezas", 0), ("", 10), (None, 50), ("2x1 cervezas", 33.33)]


def _vuelve_y_lo_que_tuvo(semilla: int, cuantos: int) -> list:
    """4.31 (sexta vuelta, P1 y M2): guardados de la caja con `vuelve` a una línea que la cuenta tiene, tuvo (lids_quitados) o nunca tuvo (el
    resto de una parte que el servidor no aceptó porque otro equipo partió los mismos platos a la vez), con y sin promoción; y en la recreada,
    `vuelve` al resto de una línea que ese mismo guardado quita (era de lo cerrado). El nombre dice dónde estaba: sexta_<donde>_<i>."""
    rnd = random.Random(semilla)
    casos = []
    for i in range(cuantos):
        g = _cuenta(rnd)
        n = _nueva_desde(rnd, g)
        lv = "p%d" % i
        promo, pct = rnd.choice(PROMOS)
        linea = {**_linea(rnd, False), "lid": lv, "cantidad": rnd.choice([1, 2, 0.5]), "descuento_pct": pct}
        linea.pop("de", None)
        if promo is not None:
            linea["promo"] = promo
        if rnd.random() < 0.5:
            linea["de"] = rnd.choice(LIDS)
        n["lineas"] = list(n.get("lineas") or []) + [linea]
        donde = rnd.choice(["tiene", "tuvo", "nunca", "nunca"])
        if donde == "tiene":
            g["lineas"] = list(g["lineas"]) + [dict(linea, cantidad=1)]
        elif donde == "tuvo":
            g["lids_quitados"] = sorted(set(g.get("lids_quitados") or []) | {lv})
        lids_n = [l["lid"] for l in n["lineas"] if isinstance(l.get("lid"), str)]
        f = n["_fusion"] = {"v": 1, "equipo": "e6", "origen": "caja" if rnd.random() < 0.9 else rnd.choice(["cocina", "servidor"]),
                            "nuevas": sorted(set(rnd.sample(lids_n, rnd.randint(0, min(2, len(lids_n)))))), "quitadas": {}, "campos": {}, "cuenta": [],
                            "vuelve": {lv: rnd.choice([1, 0.5, 2])}}
        if rnd.random() < 0.3:
            f["vuelve"][rnd.choice(lids_n)] = 1
        if rnd.random() < 0.7:
            casos.append({"nombre": "sexta_%s_%d" % (donde, i), "funcion": "unir", "guardada": g, "nueva": n, "repetible": True})
        else:
            if linea.get("de") and rnd.random() < 0.6:          # este guardado quita la línea de origen: el resto era de lo cerrado
                f["quitadas"] = {linea["de"]: rnd.choice([1, 2])}
            casos.append({"nombre": "sexta_%s_%d" % (donde, i), "funcion": "recrear", "nueva": n, "id_viejo": 6, "id_nuevo": rnd.choice([7, 12])})
    return casos


@pytest.mark.parametrize("semilla", [4316, 43160])
def test_sexta_vuelve_solo_a_lo_que_la_cuenta_tuvo_y_con_su_2x1_en_python_y_en_node(tmp_path, semilla):
    casos = _vuelve_y_lo_que_tuvo(semilla, 300)
    py = [_python(c) for c in casos]
    js = _javascript(tmp_path, casos)
    assert len(js) == len(casos)
    malos = _diferencias(casos, py, js)
    assert not malos, (len(malos), malos[:5])
    volvio = nunca = marca = sin_marca = salta = 0
    for c, p in zip(casos, py):
        f, lv = c["nueva"]["_fusion"], c["nueva"]["lineas"][-1]
        if p["r"] is None or f["origen"] != "caja":
            continue
        v = next((l for l in p["r"]["lineas"] if l.get("lid") == lv["lid"] + "+v"), None)
        if c["funcion"] == "unir" and c["nombre"].startswith("sexta_nunca_"):
            assert v is None, c["nombre"]                       # P1: la cuenta nunca tuvo esa línea: no vuelve (se cobraba dos veces)
            nunca += 1
        if c["funcion"] == "recrear" and lv.get("de") in f["quitadas"]:
            assert v is None, c["nombre"]                       # P1: el resto de lo cerrado no vuelve en la recreada
            salta += 1
        if v is None:
            continue
        volvio += 1
        assert "promo_fija" not in v and "de" not in v, c["nombre"]   # séptima vuelta (V1): el servidor no sabe si su par se cobró: sin la marca (lo decide la caja)
        if isinstance(lv.get("promo"), str) and lv["promo"] and lv["descuento_pct"] > 0:
            assert v["descuento_pct"] == lv["descuento_pct"] and v["promo"] == lv["promo"], c["nombre"]   # con su descuento y su promoción (la caja la calcula al llegar)
            marca += 1
        else:
            sin_marca += 1
    assert volvio > 40 and nunca > 40 and marca > 10 and sin_marca > 10 and salta > 5, (volvio, nunca, marca, sin_marca, salta)   # la prueba no es vacía
