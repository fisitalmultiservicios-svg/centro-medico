# -*- coding: utf-8 -*-
"""4.32, bloque B7 (pantallas), parte «caja» (plan exe432/reingenieria_432.md §4.2, §4.4, §4.5 y §4.8).

- pos/_estacion.js: estacionPosible() con la bandera pedidos_programa (ESTACION_EN_PROGRAMA sigue en false); iniciarDesdeApp() y
  pararDesdeApp() para app.js: temporizador propio de 10 s con la misma pasada de la caja, que cede a la Caja y a Cocina y nunca corre dos
  pasadas a la vez en la pestaña.
- pos/caja.js: con la bandera, el resumen cada 10 s y el aviso «Entró a la caja el pedido en línea #{n}.» una vez por pedido; sin ella,
  todo como en la 4.31. El cobro de la cuenta de un pedido sigue mandando pedido_id y pedido_parcial y muestra el 409 del servidor.
- pos/configuracion.js: en el programa con datos_v2, sin «Agregar caja» ni «Eliminar caja».
Nada va a una impresora, a la red ni a un servidor de verdad: el agente y el servidor son funciones de la prueba (las de la 4.31)."""
import json
import re
import subprocess

import pytest

import tests.test_431_estacion_pantallas as T431
from tests.test_425_ultimos_pantallas import JS, _js, _node, _nodo, _tramo

# setInterval de la prueba: se anota y nunca corre solo (la prueba llama las vueltas a mano)
RELOJES = r"""
const RELOJ = globalThis.RELOJ = { vivos: new Map(), n: 0, ms: [] };
globalThis.setInterval = (f, ms) => { const id = ++RELOJ.n; RELOJ.vivos.set(id, f); RELOJ.ms.push(ms); return id; };
globalThis.clearInterval = id => { RELOJ.vivos.delete(id); };
"""


# ================================================================================================================ _estacion.js
def test_estacion_posible_con_la_bandera_y_la_constante_se_queda(tmp_path):
    r = _node(tmp_path, T431.BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
copia(1); Q.espera = [cuentaDe(1)];
const caso = async antes => { limpiar(); E._reiniciar(); antes(); const res = await E.revisarEstacion('caja'); return [res, Q.llamadas.length + Q.fetchs.length, E.estacionPosible()]; };
out.web = await caso(() => { Q.sesion.empresaInfo = { es_local: false, numero_id: '1' }; });
out.programa = await caso(() => { Q.sesion.empresaInfo = { es_local: true, numero_id: '1' }; });
out.programa_falsa = await caso(() => { Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: false }; });
out.programa_bandera = await caso(() => { Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: true }; });
out.bandera_sin_modulo = await caso(() => { Q.modulos = []; });
out.constante = E.ESTACION_EN_PROGRAMA;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=T431.ARCHIVOS, falsos=T431._falsos())
    assert r["programa"] == ["sin_modulo", 0, False] and r["programa_falsa"] == ["sin_modulo", 0, False], r   # sin la bandera, como la 4.31
    assert r["programa_bandera"][2] is True and r["programa_bandera"][0] != "sin_modulo" and r["programa_bandera"][1] > 0, r
    assert r["web"][2] is True and r["web"][0] != "sin_modulo", r
    assert r["bandera_sin_modulo"] == ["sin_modulo", 0, False], r
    assert r["constante"] is False, r


def test_estacion_desde_app_cede_a_caja_y_cocina_y_nunca_dos_pasadas(tmp_path):
    r = _node(tmp_path, RELOJES + T431.BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: true };
const rutas = () => Q.llamadas.map(x => x.split(' ').slice(0, 2).join(' '));
// iniciar varias veces: un solo temporizador de 10 s; parar varias veces: ninguno
out.iniciar = [E.iniciarDesdeApp(), E.iniciarDesdeApp(), E.iniciarDesdeApp(), RELOJ.vivos.size, RELOJ.ms.slice(), E.estacionDesdeApp()];
await new Promise(r => setTimeout(r, 30));
out.parar = [E.pararDesdeApp(), E.pararDesdeApp(), RELOJ.vivos.size, E.estacionDesdeApp()];
out.reiniciar = [E.iniciarDesdeApp(), RELOJ.vivos.size]; E.pararDesdeApp();
await new Promise(r => setTimeout(r, 30));
// la Caja tiene la estación: el temporizador de app.js cede sin una sola petición
limpiar(); E._reiniciar(); S.copias = {}; S.filas = {}; copia(1); Q.espera = [cuentaDe(1)];
E.iniciarEstacion('caja');
out.cedida_caja = [await E.pasoDesdeApp(), Q.llamadas.length + Q.fetchs.length, E.estacionCedida()];
E.iniciarEstacion('cocina'); E.pararEstacion('caja');
limpiar(); out.cedida_cocina = [await E.pasoDesdeApp(), Q.llamadas.filter(x => !x.startsWith('/api/pedidos/resumen')).length];
E.pararEstacion('cocina');
// la sueltan: la vuelta siguiente hace el resumen y LA PASADA (imprime una vez)
limpiar(); out.retoma = [await E.pasoDesdeApp(), rutas(), Q.impresos.length, E.estacionCedida()];
limpiar(); out.otra = [await E.pasoDesdeApp(), Q.impresos.length];                              // ya impresa: no sale otra vez
// dos vueltas a la vez y la pasada de la Caja a la vez: una sola corre
limpiar(); E._reiniciar(); S.copias = {}; S.filas = {}; copia(2); Q.espera = [cuentaDe(2)];
let soltarLento; Q.lento = new Promise(r => { soltarLento = r; });
const a = E.pasoDesdeApp(); await new Promise(r => setTimeout(r, 20));
const b = await E.pasoDesdeApp(), c = await E.revisarEstacion('caja');
soltarLento(); Q.lento = null;
out.a_la_vez = [await a, b, c, Q.impresos.length];
// apagada en esta computadora: ni el resumen
limpiar(); E._reiniciar(); E.encenderEstacion(false); out.apagada = [await E.pasoDesdeApp(), Q.llamadas.length]; E.encenderEstacion(true);
// sin la bandera: nada (como la 4.31)
Q.sesion.empresaInfo = { es_local: true, numero_id: '1' };
limpiar(); E._reiniciar(); out.sin_bandera = [await E.pasoDesdeApp(), Q.llamadas.length + Q.fetchs.length];
// pestaña oculta: nada
Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: true }; document.hidden = true;
limpiar(); out.oculta = [await E.pasoDesdeApp(), Q.llamadas.length]; document.hidden = false;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=T431.ARCHIVOS, falsos=T431._falsos())
    assert r["iniciar"] == [True, False, False, 1, [10000], True], r
    assert r["parar"] == [True, False, 0, False] and r["reiniciar"] == [True, 1], r
    assert r["cedida_caja"] == ["cedida", 0, True], r
    assert r["cedida_cocina"][0] == "cedida" and r["cedida_cocina"][1] == 0, r
    assert r["retoma"][1][0] == "/api/pedidos/resumen" and "POST /api/pos/comanda/reclamar" in r["retoma"][1] and r["retoma"][2] == 1 and r["retoma"][3] is False, r["retoma"]
    assert r["otra"][1] == 0, r
    assert r["a_la_vez"][1] == "corriendo" and r["a_la_vez"][2] == "corriendo" and r["a_la_vez"][3] == 1, r
    assert r["apagada"] == ["apagada", 0], r
    assert r["sin_bandera"] == ["sin_modulo", 0], r
    assert r["oculta"] == ["oculta", 0], r


def test_contrato_de_app_js_escrito_en_la_estacion():
    est = _js("pages/pos/_estacion.js")
    for linea in ("iniciarDesdeApp();", "pararDesdeApp();", "export function iniciarDesdeApp() {", "export function pararDesdeApp() {",
                  "export const ESTACION_APP_MS = 10000;", "ESTACION_EN_PROGRAMA = false",
                  "|| !!(sesion.empresaInfo && sesion.empresaInfo.pedidos_programa)); }"):
        assert linea in est, linea
    # el reclamo por plato del servidor sigue en la pasada
    assert "reclamarComanda(pedir, { pedido_id: id, lineas: gr.pos, grupo: gr.id" in est


# ================================================================================================================ caja.js
def _caja_online():
    k = _js("pages/pos/caja.js")
    return _tramo(k, "    async revisarOnline() {", "\n    // 3.87:")


def test_caja_avisa_el_pedido_que_entro_una_vez_y_sin_bandera_como_antes(tmp_path):
    fuente = _caja_online()
    assert "async avisarEntrados(r) {" in fuente and "sonarPedido() {" in fuente
    r = _node(tmp_path, """
const fuente = %s;
const Q = { resp: null, toasts: [], sincs: 0, sonidos: 0, espera: [], llamadas: 0 };
const sesion = { empresaInfo: { es_local: true, pedidos_programa: true }, tieneModulo: m => m === 'pedidos_online' };
const api = async url => { Q.llamadas++; if (url !== '/api/pedidos/resumen') throw new Error('ruta ' + url); return Q.resp; };
const toast = (m, t) => Q.toasts.push(m);
const win = { AudioContext: function () { Q.sonidos++; throw new Error('sin audio en la prueba'); } };
const M = new Function('api', 'toast', 'sesion', 'enEspera', 'window', 'return {' + fuente + '};')(api, toast, sesion, () => Q.espera, win);
const vm = { online: { nuevos: 0, ultimo: null }, _est: null, sincronizar: async () => { Q.sincs++; } };
for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const vuelta = async resp => { Q.resp = resp; Q.toasts = []; Q.sincs = 0; Q.sonidos = 0; await vm.revisarOnline(); await pasar(); return [Q.toasts.slice(), Q.sincs, Q.sonidos]; };
const cta = (pid, num, extra) => ({ id: 900 + pid, canal: 'online', pedido_id: pid, pedido_numero: num, ...(extra || {}) });
const out = {};
out.primera = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 5 });
Q.espera = [cta(4, 104), cta(5, 105), cta(6, 106), cta(7, 107), cta(7, 107, { id: 999 }), { id: 1, nombre: 'Mesa 1' }];
out.sube = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 7 });
out.igual = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 7 });
out.sin_cuenta = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
Q.espera.push(cta(9, 109));
out.llega = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
out.despues = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
// el aviso de siempre del pedido nuevo sigue igual
out.nuevo = await vuelta({ nuevos: 1, ultimo_id: 3, ultimo_entrado_id: 9 });
// sin la bandera: ni aviso nuevo ni traer cuentas, aunque el número suba
sesion.empresaInfo = { es_local: true };
Q.espera.push(cta(12, 112));
out.sin_bandera = await vuelta({ nuevos: 0, ultimo_id: 3, ultimo_entrado_id: 12 });
// la página web de antes (sin el campo): nada nuevo
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
out.sin_campo = await vuelta({ nuevos: 0, ultimo_id: 3 });
console.log(JSON.stringify(out));
process.exit(0);
""" % json.dumps(fuente), archivos=(), falsos={})
    assert r["primera"] == [[], 0, 0], r                                                         # la primera respuesta solo marca el punto de partida
    assert r["sube"] == [["Entró a la caja el pedido en línea #106.", "Entró a la caja el pedido en línea #107."], 1, 1], r   # una vez por pedido, un sonido
    assert r["igual"] == [[], 0, 0], r
    assert r["sin_cuenta"] == [[], 1, 0], r                                                      # la cuenta todavía no llegó: se busca otra vez
    assert r["llega"] == [["Entró a la caja el pedido en línea #109."], 1, 1], r
    assert r["despues"] == [[], 0, 0], r
    assert r["nuevo"][0] == ["Entró un pedido en línea: tóquelo en «🌐 Pedidos web» para verlo."] and r["nuevo"][1] == 0, r
    assert r["sin_bandera"] == [[], 0, 0], r
    assert r["sin_campo"] == [[], 0, 0], r


def test_caja_resumen_cada_10_s_solo_con_la_bandera():
    k = _js("pages/pos/caja.js")
    creado = _tramo(k, "  async created() {", "\n  mounted()")
    assert "this.revisarOnline(); this._online = setInterval(() => this.revisarOnline(), sesion.empresaInfo && sesion.empresaInfo.pedidos_programa ? 10000 : 30000);" in creado
    online = _tramo(k, "    async revisarOnline() {", "\n    },\n")
    # el aviso nuevo va después de lo de siempre, sin esperarlo, y solo con la bandera y el campo
    assert online.index("this.online = {") < online.index("if (r.ultimo_entrado_id !== undefined && sesion.empresaInfo && sesion.empresaInfo.pedidos_programa) this.avisarEntrados(r);")
    assert "await this.avisarEntrados" not in k and k.count("this.avisarEntrados(") == 1
    assert "'Entró a la caja el pedido en línea #' + n + '.'" in k


def test_cobro_de_un_pedido_manda_pedido_id_y_parcial_y_muestra_el_409():
    k = _js("pages/pos/caja.js")
    cobro = _tramo(k, "    async emitirCobro(otra) {", "\n    },\n")
    assert "pedido_id: cc && cc.pedido_id ? +cc.pedido_id : null," in cobro and "pedido_parcial: pedidoParcial," in cobro
    assert "doc = await api('/api/comprobantes', { method: 'POST', headers: this.cabSucursal(), body });" in cobro
    # el texto del 409 («Este pedido lo atiende «{nombre}»: cóbrelo allá.») llega en e.message y se muestra completo; el cobro pedido se suelta
    falla = _tramo(cobro, "      } catch (e) {", "      if (rc && rc.clave) this.soltarCobro(rc, true")
    assert "if (rc && rc.clave && !e.sinConexion) this.soltarCobro(rc, false);" in falla
    assert "this.cobrando = false; return toast('No se emitió: ' + e.message, 'err');" in falla
    assert "4.32" not in cobro                                                                  # el cobro no cambió


# ================================================================================================================ configuracion.js
def test_configuracion_sin_agregar_ni_eliminar_caja_en_el_programa_con_datos_v2(tmp_path):
    cfg = _js("pages/pos/configuracion.js")
    assert '+ Agregar caja</button>' in cfg and ':disabled="!puedeConfigurar || topeCajas"' in cfg
    assert ''':title="topeCajas ? textoLimite : ''" v-if="!cajasEnWeb">+ Agregar caja</button>''' in cfg
    assert '@click="eliminar" v-if="cfg.terminales.length>1 && !cajasEnWeb">' in cfg
    assert '<span class="small muted" v-if="cajasEnWeb">Agregar o quitar cajas se hace en la página web. Aquí puede cambiar las cajas que ya existen.</span>' in cfg
    linea = next(x for x in cfg.splitlines() if x.strip().startswith("cajasEnWeb() {"))
    cuerpo = linea.strip().split("   /*")[0].rstrip(",")
    r = _node(tmp_path, """
const C = new Function('sesion', 'return { ' + %s + ' };');
const prueba = (info, esPrograma) => C({ empresaInfo: info }).cajasEnWeb.call({ esPrograma });
console.log(JSON.stringify([prueba({ es_local: true, datos_v2: true }, true), prueba({ es_local: true }, true), prueba({ es_local: true, datos_v2: false }, true),
  prueba({ datos_v2: true }, false), prueba(null, false)]));
process.exit(0);
""" % json.dumps(cuerpo), archivos=(), falsos={})
    assert r == [True, False, False, False, False], r


# ================================================================================================================ sintaxis y plantillas
def test_sintaxis_finales_de_linea_y_plantillas(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/pos/caja.js", "pages/pos/_estacion.js", "pages/pos/configuracion.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
        assert (JS / rel).read_bytes().count(b"\r\n") == 0, rel
        for linea in _js(rel).splitlines():                                                  # ninguna línea nueva de código cerrada con «//»
            if "4.32" in linea and not linea.strip().startswith("//"):
                assert "//" not in linea.replace("http://", "").replace("https://", ""), (rel, linea)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    for rel in ("pages/pos/configuracion.js", "pages/pos/caja.js"):
        guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const txt = fs.readFileSync(%s, 'utf8'); const m = /template:\\s*`([\\s\\S]*?)`,\\s*\\n};/.exec(txt) || /template:\\s*`([\\s\\S]*?)`/.exec(txt);
const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
console.log(JSON.stringify({ err }));
""" % (json.dumps(vue), json.dumps(str(JS / rel)))
        out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
        assert out.returncode == 0, out.stderr
        assert json.loads(out.stdout) == {"err": []}, rel
    cfg = _js("pages/pos/configuracion.js")
    assert "cajasEnWeb() {" in cfg                                                               # lo que usa la plantilla existe
    assert re.search(r"@[a-z:.]+=\"[^\"]*\bif\b", _tramo(cfg, '<div class="card"><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">', "</div></div>")) is None
