# -*- coding: utf-8 -*-
"""3.94: marca de asistencia desde la barra del sistema (código + PIN, sin quiosco) y datos de la empresa sin los de Hacienda
cuando la facturación electrónica está apagada."""
from tests.test_asistencia import _preparar
from tests.test_exoneraciones import api  # noqa: F401


def test_marca_desde_el_sistema_con_codigo_y_pin(api):  # noqa: F811
    c = api
    _preparar(c)
    assert c.put("/api/asistencia/clave", json={"empleado_id": 1, "clave": "2580"}).status_code == 200
    r = c.post("/api/asistencia/sistema/marcar", json={"codigo": "7", "clave": "0000", "tipo": "entrada"})
    assert r.status_code == 400 and "incorrect" in r.text                       # 400 (no 401: no cierra la sesión de quien está en la computadora)
    r = c.post("/api/asistencia/sistema/marcar", json={"codigo": "7", "clave": "2580", "tipo": "salida"})
    assert r.status_code == 400 and "corresponde" in r.text                     # primero la entrada
    r = c.post("/api/asistencia/sistema/marcar", json={"codigo": "7", "clave": "2580", "tipo": "entrada", "clave_peticion": "s-394"})
    assert r.status_code == 200 and r.json()["marca"]["tipo"] == "entrada" and r.json()["marca"]["origen"] == "sistema", r.text
    r2 = c.post("/api/asistencia/sistema/marcar", json={"codigo": "7", "clave": "2580", "tipo": "entrada", "clave_peticion": "s-394"})
    assert r2.status_code == 200 and r2.json()["repetida"] is True                # doble clic: la misma marca
    js = c.get("/js/app.js").text
    assert "MarcaRapida" in js and "marcaAbierta=true" in js
    assert "sesion.tieneModulo('rrhh') && !sesion.sinCaja\" @click=\"marcaAbierta=true\"" in js   # sin Recursos humanos (plan o usuario) no se ve
    assert "/api/asistencia/sistema/marcar" in c.get("/js/pages/rrhh/marca-rapida.js").text


def test_empresa_sin_fe_no_exige_actividad_ni_otras_senas(api):  # noqa: F811
    c = api
    emp = c.get("/api/empresa").json()
    cuerpo = {k: emp.get(k) for k in ("tipo_id", "numero_id", "nombre", "nombre_comercial", "correo", "telefono", "provincia", "canton", "distrito", "barrio", "ambiente") if k in emp}
    r = c.put("/api/empresa", json={**cuerpo, "actividad": "", "otras_senas": "", "factura_electronica": False})
    assert r.status_code == 200, r.text
    r = c.put("/api/empresa", json={**cuerpo, "actividad": "", "otras_senas": "", "factura_electronica": True})
    assert r.status_code == 400
    r = c.put("/api/empresa", json={**cuerpo, "actividad": emp.get("actividad") or "6201.0", "otras_senas": emp.get("otras_senas") or "Frente al parque central", "factura_electronica": True})
    assert r.status_code == 200, r.text
