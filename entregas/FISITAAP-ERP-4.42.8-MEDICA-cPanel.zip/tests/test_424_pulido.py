# -*- coding: utf-8 -*-
"""4.24 · Pulido final de las etiquetas de productos con código de barras (puntos U1 a U14):
U1 · el código generado lleva la marca de la empresa (3 dígitos de su cédula): no coincide entre las empresas de un grupo."""
import json
import pathlib
import types

import pytest
from sqlmodel import Session

from app import auth, etiquetas, main
from app import etiquetas_impresora as ei
from app.db import Empresa, Producto, engine, engine_empresa, init_db
from tests.test_424_etiquetas import CABYS, MARCA, RAIZ, _alta, _ctx, _eid, _js, _node, _prod, _propio
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)


def _otra_empresa(numero_id, nombre="Sucursal QA 424", sucursal=1):
    init_db()
    with Session(engine) as s:
        e = Empresa(nombre=nombre, numero_id=numero_id, correo="sucursal424@example.test", ambiente="sandbox", sucursal=sucursal)
        s.add(e); s.commit(); s.refresh(e)
        return e


def _entrar(e, rol="Administrador"):
    main.app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="qa-pulido@example.test", es_superadmin=False, nombre="QA"), e, rol)


# ================================================================================================ U1 · la marca de la empresa en el código generado
def test_u1_marca_de_la_empresa_y_formato_del_codigo():
    m = ei.marca_empresa
    assert m("3101999999") == "999" and m("3-101-123456") == "456" and m(" 1 0123 0007 ") == "007"      # solo sus dígitos, los 3 últimos
    assert m("12") == "012" and m("7") == "007" and m("") == "000" and m(None) == "000" and m("sin cédula") == "000"   # con ceros; sin cédula
    assert m(3101123456) == "456"
    # las sucursales de una misma cédula son empresas aparte: la marca suma el código de sucursal menos 1 (sin dato o con 1, los 3 dígitos tal cual)
    assert m("3-101-123456", 1) == m("3-101-123456", None) == m("3-101-123456", 0) == m("3-101-123456", "x") == m("3-101-123456", -4) == "456"
    assert m("3-101-123456", 2) == "457" and m("3-101-123456", "003") == "458" and m("3101999999", 2) == "000" and m("3101999998", 4) == "001" and m("", 2) == "001"
    assert len({m("3-101-123456", s) for s in range(1, 1000)}) == 999 and all(len(m("3101999999", s)) == 3 and m("3101999999", s).isdigit() for s in (1, 2, 500, 999, 1000, 10 ** 12))
    f = ei.codigo_barras_propio
    # el formato exacto: «2» + marca + id a 8 dígitos + verificador
    assert f(37, m("3101123456")) == "2456000000379" and f(37, m("3101999999")) == "2999000000371" and f(37, m("")) == "2000000000374"
    assert f(99_999_999, "007") == "2007999999993" and ei.es_ean13(f(99_999_999, "007"))             # id de 8 dígitos: todavía EAN-13
    assert f(100_000_000, "007") == "P007-100000000" and f(123_456_789_012, "456") == "P456-123456789012"   # id de 9 o más: «P» + marca + «-» + id
    for pid in (0, 1, 37, 9_999_999, 10_000_000, 99_999_999):
        for marca in ("000", "007", "456", "999"):
            cod = f(pid, marca)
            assert cod == "2" + marca + str(pid).zfill(8) + str(ei.digito_ean13("2" + marca + str(pid).zfill(8))) and ei.es_ean13(cod)
            assert sum(int(x) * (3 if i % 2 else 1) for i, x in enumerate(cod)) % 10 == 0            # el verificador que calcula cualquier lector
    # el mismo id en dos empresas con cédulas distintas: códigos distintos
    assert f(37, m("3101123456")) != f(37, m("3101654321")) and f(100_000_005, "123") != f(100_000_005, "321")
    # el mismo id en la Central y en la Sucursal 2 de una misma cédula: códigos distintos
    assert f(37, m("3-101-123456", 1)) == "2456000000379" and f(37, m("3-101-123456", 2)) == "2457000000376" and ei.es_ean13(f(37, m("3-101-123456", 2)))
    # la etiqueta de prueba: marca «000» e id 0
    assert f(0, "000") == "2000000000008"


def test_u1_es_codigo_propio_con_cualquier_marca():
    p = ei.es_codigo_propio
    assert p("2456000000379", 37) and p("2999000000371", 37) and p("2000000000374", 37) and p(" 2456000000379 ", 37)   # con CUALQUIER marca
    assert not p("2456000000379", 38) and not p("2456000000379", 370) and not p("2456000000370", 37)                   # otro id; verificador malo
    assert not p("7441000000376", 37) and not p("", 37) and not p(None, 37) and not p("CAF-37", 37)                    # de fábrica o a mano
    assert not p("2456000000379", None) and not p("2456000000379", "x") and not p("2456000000379", -37)
    assert p("P007-100000000", 100_000_000) and p("p456-100000000", 100_000_000) and p(" P456-123456789012", 123_456_789_012)   # la forma «P…-id»
    assert not p("P007-100000001", 100_000_000) and not p("P07-100000000", 100_000_000) and not p("PABC-100000000", 100_000_000) and not p("P007-37", 37)
    assert not p("P100000000", 100_000_000) and not p("2007100000008", 100_000_000)


def test_u1_gemela_de_la_pantalla_da_lo_mismo_que_el_servidor(tmp_path):
    cedulas = ["3101999999", "3-101-123456", "12", "7", "", None, "sin cédula", " 1 0123 0007 ", "000", "3101000000"]
    ids = [0, 1, 37, 123, 9_999_999, 10_000_000, 30_000_123, 99_999_999, 100_000_000, 100_000_001, 570_000_123, 99_990_000_499]
    codigos = ["2456000000379", "2999000000371", " 2000000000374 ", "2456000000370", "7441000000376", "", None, "CAF-37", "P007-100000000", "p456-100000000", "P07-100000000",
               "PABC-100000000", "P007-37", "P100000000", "2007999999993", "2007100000008"]
    sucursales = [None, 0, 1, 2, 3, 45, 999, 1000, 1001, -2, "2", "002", "x", ""]
    r = _node(tmp_path, """
import * as E from './js/pages/inventario/_etiquetas.js';
const cedulas = %s, ids = %s, codigos = %s, sucursales = %s;
console.log(JSON.stringify({ marcas: cedulas.map(c => E.marcaEmpresa(c)), con_sucursal: cedulas.map(c => sucursales.map(s => E.marcaEmpresa(c, s))),
  propios: cedulas.map(c => ids.map(i => E.codigoBarrasPropio(i, E.marcaEmpresa(c)))),
  es_propio: codigos.map(c => ids.concat([38, 370]).map(i => E.esCodigoPropio(c, i))),
  sin_marca: [E.codigoBarrasPropio(37), E.codigoBarrasPropio(37, null), E.codigoBarrasPropio(37, ''), E.codigoBarrasPropio(37, '45'), E.codigoBarrasPropio(37, '4567'), E.codigoBarrasPropio(37, 'abc'), E.codigoBarrasPropio(-1, '456')],
  marca_de: [E.marcaDe(null), E.marcaDe(undefined), E.marcaDe({ numero_id: '3101123456' }), E.marcaDe({ numero_id: '' }), E.marcaDe({}),
    E.marcaDe({ numero_id: '3101123456', sucursal: 1 }), E.marcaDe({ numero_id: '3101123456', sucursal: 2 }), E.marcaDe({ numero_id: '3101999999', sucursal: 2 })],
  prueba: E.codigoBarrasPropio(0, '000') }));
""" % (json.dumps(cedulas), ids, json.dumps(codigos), json.dumps(sucursales)))
    assert r["marcas"] == [ei.marca_empresa(c) for c in cedulas] == ["999", "456", "012", "007", "000", "000", "000", "007", "000", "000"]
    assert r["con_sucursal"] == [[ei.marca_empresa(c, s) for s in sucursales] for c in cedulas]                      # con el código de sucursal de la empresa
    assert r["con_sucursal"][1] == ["456", "456", "456", "457", "458", "500", "454", "455", "456", "456", "457", "457", "456", "456"] and r["con_sucursal"][0][3] == "000"
    assert r["propios"] == [[ei.codigo_barras_propio(i, ei.marca_empresa(c)) for i in ids] for c in cedulas]
    assert r["propios"][1][2] == "2456000000379" and r["propios"][3][7] == "2007999999993" and r["propios"][3][8] == "P007-100000000"
    assert r["es_propio"] == [[ei.es_codigo_propio(c, i) for i in ids + [38, 370]] for c in codigos]
    assert any(any(f) for f in r["es_propio"]) and r["es_propio"][0][2] is True and r["es_propio"][1][2] is True and r["es_propio"][8][8] is True
    # sin la marca la pantalla no supone un código; la marca sale de la ficha de la empresa que la aplicación ya tiene cargada
    assert r["sin_marca"] == [""] * 7 and r["marca_de"] == [None, None, "456", "000", "000", "456", "457", "000"]
    assert r["prueba"] == ei.codigo_barras_propio(0, "000") == "2000000000008"


def test_u1_dos_empresas_con_el_mismo_id_generan_codigos_distintos_y_el_traslado_conserva_el_codigo(api):  # noqa: F811
    """El producto 37 de la Central y el 37 de la Sucursal ya no reciben el mismo código: la etiqueta pegada en la Central no se lee
    en la Sucursal como otro producto, y lo que la Central traslada llega a la Sucursal con el código de la Central."""
    from app import traslados
    c = api
    central = _ctx().empresa
    aceite = _alta(c, "Aceite 1L")
    assert c.post("/api/productos/codigos/generar", json={"ids": [aceite["id"]]}).json()["codigos"] == {str(aceite["id"]): _propio(aceite["id"])}
    cod_central = _prod(c, aceite["id"])["codigo"]
    assert cod_central == "2" + MARCA + str(aceite["id"]).zfill(8) + cod_central[-1] and ei.es_ean13(cod_central)
    sucursal = _otra_empresa("3101123456")
    with Session(engine_empresa(sucursal.id)) as s:
        s.add(Producto(id=aceite["id"], empresa_id=sucursal.id, nombre="Jabón azul", cabys=CABYS, precio=500, inventariable=False)); s.commit()   # el mismo número de ítem
    _entrar(sucursal)
    d = c.post("/api/productos/codigos/generar", json={"ids": [aceite["id"]]}).json()
    cod_sucursal = d["codigos"][str(aceite["id"])]
    assert d["cambiados"] == 1 and cod_sucursal == ei.codigo_barras_propio(aceite["id"], "456") and cod_sucursal != cod_central
    assert cod_sucursal[4:12] == cod_central[4:12] and cod_sucursal[1:4] == "456" and cod_central[1:4] == MARCA
    # el traslado de la Central a la Sucursal: el código de la Central no es de nadie aquí; el ítem nuevo lo conserva
    with Session(engine_empresa(sucursal.id)) as s:
        p, nuevo = traslados._producto_destino(s, sucursal.id, {"codigo": cod_central, "nombre": "Aceite 1L", "cabys": CABYS, "precio_unitario": 900})
        assert nuevo is True and p.nombre == "Aceite 1L" and p.codigo == cod_central and p.id != aceite["id"]
        s.commit(); nuevo_id = p.id
        p, nuevo = traslados._producto_destino(s, sucursal.id, {"codigo": cod_central, "nombre": "ACEITE 1L", "cabys": CABYS})   # el siguiente, por el código
        assert nuevo is False and p.id == nuevo_id
        assert etiquetas.producto_con_codigo(s, sucursal.id, cod_sucursal).nombre == "Jabón azul"
    assert c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0
    # «A todos» en la Sucursal: el jabón ya tiene el suyo; al aceite, que trae el de la Central (otro id), se le pone el de aquí y el de allá queda como alterno
    d = c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True}).json()
    assert d["cambiados"] == 1 and d["sin_cambio"] == 1
    p = _prod(c, nuevo_id); assert p["codigo"] == ei.codigo_barras_propio(nuevo_id, "456") and p["codigos_alternos"] == cod_central
    _entrar(central)


def test_u1_la_central_y_la_sucursal_de_una_misma_cedula_no_generan_el_mismo_codigo(api):  # noqa: F811
    """Las sucursales de una misma persona jurídica se llevan como empresas aparte, con la MISMA cédula y su propio código de sucursal:
    el producto 37 de la Central y el 37 de la Sucursal 2 tampoco reciben el mismo código (la marca lleva el código de sucursal)."""
    from app import traslados
    c = api
    central = _ctx().empresa
    assert central.numero_id == "3101999999" and central.sucursal == 1
    aceite = _alta(c, "Aceite 1L")
    assert c.post("/api/productos/codigos/generar", json={"ids": [aceite["id"]]}).json()["codigos"] == {str(aceite["id"]): _propio(aceite["id"])}
    cod_central = _prod(c, aceite["id"])["codigo"]; assert cod_central[1:4] == MARCA
    sucursal = _otra_empresa("3101999999", "Sucursal 2 QA 424", sucursal=2)                     # la misma cédula, sucursal 002
    with Session(engine_empresa(sucursal.id)) as s:
        s.add(Producto(id=aceite["id"], empresa_id=sucursal.id, nombre="Jabón azul", cabys=CABYS, precio=500, inventariable=False)); s.commit()   # el mismo número de ítem
    _entrar(sucursal)
    d = c.post("/api/productos/codigos/generar", json={"ids": [aceite["id"]]}).json()
    cod_sucursal = d["codigos"][str(aceite["id"])]
    assert d["cambiados"] == 1 and cod_sucursal != cod_central and cod_sucursal == ei.codigo_barras_propio(aceite["id"], "000") and ei.es_ean13(cod_sucursal)   # 999 + 1 → 000
    with Session(engine_empresa(sucursal.id)) as s:
        # la etiqueta pegada en la Central no es de ningún producto de la Sucursal (ya no se lee como «Jabón azul»)…
        assert etiquetas.producto_con_codigo(s, sucursal.id, cod_central) is None and etiquetas.producto_con_codigo(s, sucursal.id, cod_sucursal).nombre == "Jabón azul"
        # …y lo que la Central traslada entra con el código de la Central: su etiqueta sirve en la Sucursal
        p, nuevo = traslados._producto_destino(s, sucursal.id, {"codigo": cod_central, "nombre": "Aceite 1L", "cabys": CABYS, "precio_unitario": 900})
        assert nuevo is True and p.nombre == "Aceite 1L" and p.codigo == cod_central and p.id != aceite["id"]
    _entrar(central)


def test_u1_si_la_empresa_corrige_su_cedula_sus_codigos_generados_siguen_siendo_propios(api):  # noqa: F811
    c = api
    a, b = _alta(c, "Galletas de avena"), _alta(c, "Galletas de coco", "7441009876543")
    assert c.post("/api/productos/codigos/generar", json={"ids": [a["id"]]}).json()["cambiados"] == 1
    viejo = _prod(c, a["id"])["codigo"]; assert viejo == _propio(a["id"])
    e = _ctx().empresa
    e.numero_id = "3101999123"                                          # la empresa corrige su cédula: la marca pasa de 999 a 123
    try:
        d = c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True}).json()
        assert d["cambiados"] == 1 and d["sin_cambio"] == 1, d           # el que ya tenía su código generado no se vuelve a cambiar
        assert _prod(c, a["id"])["codigo"] == viejo and _prod(c, a["id"])["codigos_alternos"] is None
        nuevo = _prod(c, b["id"]); assert nuevo["codigo"] == ei.codigo_barras_propio(b["id"], "123") and nuevo["codigos_alternos"] == "7441009876543"
        assert c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True}).json()["cambiados"] == 0
    finally:
        e.numero_id = "3101999999"
    # una empresa sin cédula: marca «000»
    sin = _otra_empresa("", "Empresa sin cédula QA 424")
    with Session(engine_empresa(sin.id)) as s:
        s.add(Producto(id=5, empresa_id=sin.id, nombre="Pan", cabys=CABYS, precio=1, inventariable=False)); s.commit()
    _entrar(sin)
    assert c.post("/api/productos/codigos/generar", json={"ids": [5]}).json()["codigos"] == {"5": "2000000000053"}


def test_u1_la_pantalla_toma_la_marca_de_un_solo_lugar_y_no_la_inventa():
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js"); ficha = _js("pages", "inventario", "item-form.js"); cfg = _js("pages", "pos", "configuracion.js")
    puras = _js("pages", "inventario", "_etiquetas.js")
    assert "export function marcaDe(empresa) { return empresa ? marcaEmpresa(empresa.numero_id, empresa.sucursal) : null; }" in puras
    # una sola fuente: la ficha de la empresa que la aplicación ya tiene cargada (store.empresa)
    assert dlg.count("marcaDe(store.empresa)") == 1 and ficha.count("marcaDe(store.empresa)") == 1 and "marcaEmpresa(" not in dlg + ficha + cfg
    # vista previa de un producto sin código: el que se le va a generar; sin la marca, uno de muestra y se dice
    assert "const propio = x.codigo ? '' : codigoBarrasPropio(x.id, marcaDe(store.empresa)), muestra = !x.codigo && !propio;" in dlg
    assert "const codigo = x.codigo || propio || codigoBarrasPropio(0, '000')," in dlg
    assert '<div class="small muted" v-if="previa.muestra" style="margin-top:4px">Código de muestra: el código se genera al imprimir</div>' in dlg
    # «Generar» en la ficha de un ítem que ya existe
    assert "if (esCodigoPropio(this.f.codigo, this.params.id)) return toast('Este ítem ya tiene su código generado', 'ok');" in ficha
    assert "const propio = codigoBarrasPropio(this.params.id, marcaDe(store.empresa));" in ficha
    assert "if (!propio) return toast('No se pudo generar el código porque faltan los datos de la empresa: actualice la página e intente de nuevo', 'err');" in ficha
    # la cuenta de «A todos»: los que no tienen ya su código generado (con cualquier marca), como en el servidor
    assert "this.productos.filter(p => !esCodigoPropio(p.codigo, p.id)).length" in dlg
    srv = pathlib.Path(etiquetas.__file__).read_text(encoding="utf-8")
    assert "marca = ei.marca_empresa(ctx.empresa.numero_id, ctx.empresa.sucursal)" in srv and "if ei.es_codigo_propio(actual, p.id) or (actual and not data.reemplazar):" in srv
    # la etiqueta de prueba: marca «000» e id 0 en los dos lados
    assert "codigo: codigoBarrasPropio(0, '000'), copias: 1 }" in cfg and '"codigo": ei.codigo_barras_propio(0, "000"),' in srv
    # la sesión del servidor entrega la cédula de la empresa a todos los roles (de ahí sale la marca en la pantalla)
    ficha_empresa = main._empresa_dict(Empresa(nombre="x", numero_id="3101123456", correo="x@example.test", sucursal=2), False)
    assert ficha_empresa["numero_id"] == "3101123456" and ficha_empresa["sucursal"] == 2


def test_u1_la_vista_previa_del_cuadro_no_supone_un_codigo_sin_la_ficha_de_la_empresa(tmp_path):
    """El cuadro de etiquetas montado en Node (no solo su texto): la vista previa de un producto sin código."""
    r = _node(tmp_path, MONTAR + """
const SIN = [{ id: 37, nombre: 'Aceite 1L', codigo: '', precio: 900, tarifa: 13, existencias: 2 }];
const previa = (empresa, productos) => { Q.store.empresa = empresa; const p = montar(productos || SIN).previa; return [p.codigo, p.muestra, p.barras.ancho > 0]; };
console.log(JSON.stringify({ sin_ficha: previa(null), sin_ficha_2: previa(undefined), con_ficha: previa({ numero_id: '3-101-123456' }), sucursal_2: previa({ numero_id: '3-101-123456', sucursal: 2 }),
  sin_cedula: previa({ numero_id: '' }), con_codigo: previa(null, PRODS), con_codigo_y_ficha: previa({ numero_id: '3101123456' }, PRODS) }));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert r["sin_ficha"] == ["2000000000008", True, True] and r["sin_ficha_2"] == ["2000000000008", True, True]     # sin la marca: uno de muestra, y se dice
    assert r["con_ficha"] == ["2456000000379", False, True] and r["sucursal_2"] == ["2457000000376", False, True]    # el que se le va a generar
    assert r["con_ficha"][0] == ei.codigo_barras_propio(37, ei.marca_empresa("3-101-123456")) and r["sucursal_2"][0] == ei.codigo_barras_propio(37, ei.marca_empresa("3-101-123456", 2))
    assert r["sin_cedula"] == ["2000000000374", False, True]                                                         # una empresa sin cédula sí tiene marca: «000»
    assert r["con_codigo"] == ["2456000000010", False, True] and r["con_codigo_y_ficha"] == ["2456000000010", False, True]


# ================================================================================================ U2 · la barra angosta según la resolución
FUENTES = [((f, m), a, h) for f, m, a, h in ei.FUENTES_TSPL]


def test_u2_el_ancho_de_la_barra_angosta_depende_de_la_resolucion():
    f = ei.puntos_del_modulo
    # los puntos posibles: de 0,5 mm (en Code128, 0,375) bajando de uno en uno hasta 0,12 mm
    posibles = lambda dpi, ean: sorted({f(ancho, 100, dpi, ean) for ancho in range(0, 3000)})   # noqa: E731
    assert posibles(203, True) == [0, 1, 2, 3, 4] and posibles(300, True) == [0, 2, 3, 4, 5, 6] and posibles(600, True) == [0] + list(range(3, 13))
    assert posibles(203, False) == [0, 1, 2, 3] and posibles(300, False) == [0, 2, 3, 4] and posibles(600, False) == [0] + list(range(3, 10))
    # el mayor que cabe con su zona quieta; si no cabe ni el menor, 0
    assert f(400, 117, 203, True) == 3 and f(468, 117, 203, True) == 4 and f(467, 117, 203, True) == 3 and f(117, 117, 203, True) == 1 and f(116, 117, 203, True) == 0
    assert f(591, 117, 300, True) == 5 and f(234, 117, 300, True) == 2 and f(233, 117, 300, True) == 0                   # a 300, un punto solo (0,085 mm) ya no se usa
    assert f(1181, 117, 600, True) == 10 and f(351, 117, 600, True) == 3 and f(350, 117, 600, True) == 0
    # a 203 puntos por pulgada el resultado es el de antes en todas las medidas (4, 3, 2 o 1; Code128: 3, 2 o 1)
    for ancho, alto in ei.MEDIDAS + ((20, 15), (110, 160), (45.5, 28)):
        for codigo in ("2000000000015", "TOR-38X2", "123456", "ABCDEFGHIJ-KLMNOPQRS"):
            ean = ei.es_ean13(codigo); W = ei._puntos(ancho, 203)
            modulos = (95 + 22) if ean else 11 * (len(codigo) + 2) + 13 + 20
            antes = next((k for k in ((4, 3, 2, 1) if ean else (3, 2, 1)) if modulos * k <= W), 0)
            assert f(W, modulos, 203, ean) == antes, (ancho, codigo)
            if antes:
                assert ei.plan_etiqueta("Café", codigo, "", ancho, alto, 203, FUENTES)["n"] == antes
            else:
                with pytest.raises(ValueError, match="no cabe en una etiqueta"):
                    ei.plan_etiqueta("Café", codigo, "", ancho, alto, 203, FUENTES)
    # a 300 y a 600: más puntos por barra, casi el mismo ancho en milímetros, siempre con su zona quieta y dentro de la etiqueta
    n = lambda codigo, ancho, alto, dpi: ei.plan_etiqueta("", codigo, "", ancho, alto, dpi, FUENTES)["n"]   # noqa: E731
    assert [n("2000000000015", 50, 30, d) for d in (203, 300, 600)] == [3, 5, 10]
    assert [n("2000000000015", 30, 20, d) for d in (203, 300, 600)] == [2, 3, 6]
    assert [n("2000000000015", 100, 50, d) for d in (203, 300, 600)] == [4, 6, 12]                                      # el tope: 0,5 mm
    assert [n("2000000000015", 20, 15, d) for d in (203, 300, 600)] == [1, 2, 4]
    assert [n("TOR-38X2", 58, 40, d) for d in (203, 300, 600)] == [3, 4, 9] and [n("TOR-38X2", 30, 20, d) for d in (203, 300, 600)] == [1, 2, 4]
    for dpi in (300, 600):
        for ancho, alto in ei.MEDIDAS + ((20, 15), (110, 160)):
            p = ei.plan_etiqueta("Café", "2000000000015", "", ancho, alto, dpi, FUENTES)
            x = p["barras"][0]
            assert 0.12 <= p["n"] * 25.4 / dpi <= 0.51 and x >= 11 * p["n"] - 1 and x + 95 * p["n"] <= p["W"] - 7 * p["n"], (dpi, ancho)
    # un código que a 203 cabía con barras de un punto (0,125 mm) no cabe a 300 con las de dos (0,17 mm): se dice, no se imprime ilegible
    assert n("TOR-38X2", 20, 15, 203) == 1
    with pytest.raises(ValueError, match="El código TOR-38X2 no cabe en una etiqueta de 20 mm de ancho: use una etiqueta más ancha"):
        ei.plan_etiqueta("", "TOR-38X2", "", 20, 15, 300, FUENTES)
    # el trabajo que llega al servicio de impresión con su resolución
    b = ei.trabajo_etiquetas({"conexion": "usb", "direccion": "Etiquetas", "lenguaje": "tspl", "ancho_mm": 50, "alto_mm": 30, "dpi": 300, "etiquetas": [{"nombre": "", "codigo": "2000000000015", "copias": 1}]})[1]
    assert b',"EAN13",' in b and b',0,0,5,5,"200000000001"' in b
    b = ei.trabajo_etiquetas({"conexion": "usb", "direccion": "Zebra", "lenguaje": "zpl", "ancho_mm": 50, "alto_mm": 30, "dpi": 600, "etiquetas": [{"nombre": "", "codigo": "2000000000015", "copias": 1}]})[1]
    assert b"^BY10^BEN," in b
    # sigue siendo solo biblioteca estándar (va dentro del agente suelto y del programa de escritorio)
    fuente = pathlib.Path(ei.__file__).read_text(encoding="utf-8")
    assert [ln for ln in fuente.splitlines() if ln.startswith(("import ", "from "))] == ["import unicodedata"]


# ================================================================================================ U3 · el PDF con la resolución de la impresora
def test_u3_en_el_pdf_el_modulo_es_multiplo_exacto_de_un_punto_de_la_impresora(api):  # noqa: F811
    import io
    from pypdf import PdfReader
    from tests.test_424_etiquetas import PT_MM, _geometria, _pdf
    vistos = {}
    for dpi in (203, 300, 600):
        punto = 72 / dpi                                              # un punto de la impresora (25,4/dpi mm), en puntos del PDF
        for ancho, alto in ei.MEDIDAS + ((20, 15), (110, 160)):
            for codigo in ("2000000001234", "TOR-38X2"):
                try:
                    pdf = etiquetas.pdf_etiquetas([{"nombre": "Café molido", "codigo": codigo, "precio": "", "copias": 1}], ancho, alto, None, dpi)
                except ValueError as ex:
                    assert "no cabe en una etiqueta" in str(ex) and codigo == "TOR-38X2" and dpi == 300 and ancho == 20, (dpi, ancho, codigo)
                    continue
                barras, _ = _geometria(PdfReader(io.BytesIO(pdf)).pages[0])
                anchos = [(b[1] - b[0]) / punto for b in barras]
                n = round(min(anchos))
                assert all(abs(a - round(a)) < 0.01 and round(a) % n == 0 for a in anchos), (dpi, ancho, codigo, sorted(set(anchos)))   # múltiplos exactos de 25,4/dpi mm
                assert {203: 1, 300: 2, 600: 3}[dpi] <= n <= round((0.5 if codigo == "2000000001234" else 0.375) * dpi / 25.4)   # de 0,12 mm a 0,5 mm (Code128: 0,375)
                x0, x1 = min(b[0] for b in barras), max(b[1] for b in barras)
                assert x0 >= 10 * n * punto - 0.01 and ancho * PT_MM - x1 >= 10 * n * punto - 0.01                      # con su zona quieta
                vistos[(dpi, ancho, codigo)] = n
                if codigo == "2000000001234":                                                                         # una sola regla: la del envío directo
                    assert n == ei.plan_etiqueta("", codigo, "", ancho, alto, dpi, FUENTES)["n"], (dpi, ancho)
    assert [vistos[(d, 50, "2000000001234")] for d in (203, 300, 600)] == [3, 5, 10] and [vistos[(d, 30, "2000000001234")] for d in (203, 300, 600)] == [2, 3, 6]
    # la ruta: dpi opcional (203, 300 o 600; por omisión 203); otro valor, 400 con mensaje llano
    c = api
    cafe = _alta(c, "Café molido 500 g", "2000000001234")
    pedir = lambda **k: c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 1}], "ancho_mm": 50, "alto_mm": 30, **k})   # noqa: E731
    modulo = lambda r: min(b[1] - b[0] for b in _geometria(_pdf(r).pages[0])[0])   # noqa: E731
    assert abs(modulo(pedir()) - 3 * 72 / 203) < 0.001 and abs(modulo(pedir(dpi=203)) - 3 * 72 / 203) < 0.001 and abs(modulo(pedir(dpi=None)) - 3 * 72 / 203) < 0.001
    assert abs(modulo(pedir(dpi=300)) - 5 * 72 / 300) < 0.001 and abs(modulo(pedir(dpi=600)) - 10 * 72 / 600) < 0.001
    assert abs(modulo(pedir(dpi=300, hoja="carta")) - 5 * 72 / 300) < 0.001
    assert abs(modulo(c.post("/api/productos/etiquetas", json={"prueba": True, "ancho_mm": 50, "alto_mm": 30, "dpi": 300})) - 5 * 72 / 300) < 0.001
    for malo in (0, 72, 150, 204, 1200, -300):
        r = pedir(dpi=malo); assert r.status_code == 400 and r.json()["detail"] == "La resolución de la impresora debe ser 203, 300 o 600 puntos por pulgada", (malo, r.text)
    # la pantalla manda la resolución de la impresora de etiquetas elegida cuando la tiene; con «Elegir al imprimir (PDF)» o en hoja carta, nada
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js")
    assert "hoja: this.impId === 'carta' ? 'carta' : null, ...(imp && +imp.dpi ? { dpi: +imp.dpi } : {}) }" in dlg and "const lista = this.conCopias.filter(x => x.codigo), n = totalEtiquetas(lista), imp = this.imp;" in dlg
    assert "imp() { return this.imps.find(i => String(i.id) === String(this.impId)) || null; }," in dlg                  # '' y 'carta' no son impresoras: imp = null


# ================================================================================================ U4 · barras muy finas y rechazo del servicio
def test_u4_aviso_de_barras_finas(tmp_path):
    r = _node(tmp_path, """
import * as E from './js/pages/inventario/_etiquetas.js';
const P = E.PUNTO_MM, pts = (c, a) => Math.round(E.barraAngostaMm(c, a) / P);
const items = [{ id: 1, codigo: '2000000000015' }, { id: 2, codigo: 'TOR-38X2' }, { id: 3, codigo: '' }, { id: 4, codigo: 'ABCDEFGHIJ-KLMNOPQRS' }, { id: 5, codigo: '123456' }];
console.log(JSON.stringify({ punto: P,
  ean: [20, 29, 30, 40, 50, 58, 60, 100, 110].map(a => pts('2000000000015', a)), sin_codigo: [20, 30, 50].map(a => pts('', a)),
  letras: [20, 30, 40, 50, 58, 76, 100].map(a => pts('TOR-38X2', a)), digitos_par: [20, 30, 50].map(a => pts('123456', a)), digitos_impar: [20, 30, 50].map(a => pts('12345', a)),
  veinte: [30, 50, 60, 100].map(a => pts('ABCDEFGHIJ-KLMNOPQRS', a)), raros: [E.barraAngostaMm('A1', 0), E.barraAngostaMm('A1', null), E.barraAngostaMm(null, 50) / P],
  finas: [20, 30, 40, 50, 76, 100].map(a => E.conBarrasFinas(items, a)), vacio: [E.conBarrasFinas([], 30), E.conBarrasFinas(null, 30)],
  avisos: [0, 1, 2, 37].map(E.avisoBarrasFinas) }));
""")
    assert abs(r["punto"] - 0.12512) < 0.0001
    assert r["ean"] == [1, 1, 2, 2, 3, 3, 4, 4, 4] and r["sin_codigo"] == [1, 2, 3]            # EAN-13: 95 + 22 módulos; sin código = el que se le va a generar
    assert r["letras"] == [1, 1, 2, 2, 3, 4, 4]                                                # Code128: 11 × (8 + 2) + 13 + 20 = 143 módulos; tope de 4 puntos
    assert r["digitos_par"] == [1, 2, 4] and r["digitos_impar"] == [1, 2, 3]                   # solo dígitos y largo par: la mitad de símbolos
    assert r["veinte"] == [0, 1, 1, 2] and r["raros"] == [0, 0, 3]                              # 0 = ni cabe
    assert r["finas"] == [5, 2, 1, 1, 0, 0] and r["vacio"] == [0, 0]                            # por debajo de 0,25 mm (menos de 2 puntos)
    assert r["avisos"] == ["", "Con esta medida las barras de 1 producto quedan muy finas y el lector puede no leerlas: use una etiqueta más ancha",
                           "Con esta medida las barras de 2 productos quedan muy finas y el lector puede no leerlas: use una etiqueta más ancha",
                           "Con esta medida las barras de 37 productos quedan muy finas y el lector puede no leerlas: use una etiqueta más ancha"]
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js")
    assert "avisoFinas() { return medidaValida(this.medida[0], this.medida[1]) ? avisoBarrasFinas(conBarrasFinas(this.conCopias, this.medida[0])) : ''; }," in dlg
    assert '<div class="alert warn" v-if="avisoFinas" style="margin:10px 0 0">{{avisoFinas}}</div>' in dlg
    assert "Es un cálculo APROXIMADO, solo para avisar en" in _js("pages", "inventario", "_etiquetas.js")


FALSO_API = """
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const api = async (url, opt) => globalThis.Q.api(url, opt);
export const money = (v, m) => (m === 'USD' ? '$' : '₡') + v;
export const otroImpLinea = () => ({ monto: 0, base: 0 });
export const fmtCant = v => String(v), fmt = v => String(v), fecha = v => String(v);
export const mock = { get: (k, d) => (k in globalThis.Q.mock ? globalThis.Q.mock[k] : d) };
export const abrirArchivo = async (...a) => globalThis.Q.abrirArchivo(...a);
"""
FALSO_APP = "export const store = globalThis.Q.store;\nexport const sesion = { puede: p => globalThis.Q.permisos.includes(p) };\n"
FALSO_AGENTE = """
export const agenteEstado = async () => globalThis.Q.estado;
export const sabeEtiquetas = e => !!(e && e.ok && e.info && e.info.etiquetas);
export const imprimirEtiquetas = async (imp, trabajo) => globalThis.Q.imprimir(imp, trabajo);
"""
# el cuadro de etiquetas montado en Node: los datos, las computadas y los métodos del componente sobre un objeto corriente
MONTAR = """
globalThis.Q = { toasts: [], abiertos: [], enviados: [], pedidos: [], mock: { pos_impresoras: [] }, store: { empresa: { numero_id: '3101123456' }, productos: [], poner() {} }, permisos: ['catalogos'],
  estado: { ok: true, info: { etiquetas: 1 } }, imprimir: async (imp, t) => { Q.enviados.push(t); return { ok: true }; }, abrirArchivo: async (...a) => { Q.abiertos.push(a); },
  api: async (url, opt) => { Q.pedidos.push([url, opt && opt.body]); return { codigos: {}, no_se_pudo: [] }; }, guardado: {} };
globalThis.localStorage = { getItem: k => (k in Q.guardado ? Q.guardado[k] : null), setItem: (k, v) => { Q.guardado[k] = String(v); } };
const { DialogoEtiquetas } = await import('./js/pages/inventario/_etiquetas-dialogos.js');
function montar(productos) {
  const vm = { productos, $emit() {} };
  Object.assign(vm, DialogoEtiquetas.data.call(vm));
  for (const [k, f] of Object.entries(DialogoEtiquetas.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm) });
  for (const [k, f] of Object.entries(DialogoEtiquetas.methods)) vm[k] = f.bind(vm);
  return vm;
}
const IMP = { id: 7, nombre: 'Etiquetas bodega', uso: 'etiquetas', conexion: 'usb', direccion: '3nStar LDT124', lenguaje: 'tspl', dpi: 203, etq_ancho_mm: 58, etq_alto_mm: 40, separacion_mm: 2, densidad: 8, activa: true };
const PRODS = [{ id: 1, nombre: 'Café', codigo: '2456000000010', precio: 1000, tarifa: 13, existencias: 4 }, { id: 2, nombre: 'Té', codigo: 'TE-1', precio: 500, tarifa: 13, existencias: 0 }];
"""
ARCHIVOS_CUADRO = (("pages", "inventario", "_etiquetas-dialogos.js"), ("pages", "inventario", "_etiquetas.js"), ("pages", "inventario", "_barras.js"))
FALSOS_CUADRO = {"api.js": FALSO_API, "app.js": FALSO_APP, "pages/pos/_agente.js": FALSO_AGENTE}


def test_u4_el_rechazo_del_servicio_se_muestra_con_su_impresora_y_no_abre_el_pdf(tmp_path):
    r = _node(tmp_path, MONTAR + """
Q.mock.pos_impresoras = [IMP];
const out = {};
const correr = async (preparar) => { Q.toasts = []; Q.abiertos = []; Q.enviados = []; const vm = montar(PRODS); preparar(); await vm.imprimir(false); return { toasts: Q.toasts.slice(), pdf: Q.abiertos.length, enviados: Q.enviados.length, trabajando: vm.trabajando, imp: vm.impId }; };
// el servicio lo imprime
out.bien = await correr(() => { Q.imprimir = async (imp, t) => { Q.enviados.push(t); return { ok: true }; }; });
// el servicio lo rechaza con un motivo: se muestra completo, con la impresora, y no se abre el PDF
out.rechazo = await correr(() => { Q.imprimir = async () => { const e = new Error('El código TE-1 no cabe en una etiqueta de 20 mm de ancho: use una etiqueta más ancha'); e.rechazo = true; throw e; }; });
// la impresora está apagada o su nombre está mal escrito: el servicio también responde, con un motivo técnico; el aviso dice cuál impresora falló
out.apagada = await correr(() => { Q.imprimir = async () => { const e = new Error('timed out'); e.rechazo = true; throw e; }; });
// el servicio no responde: aviso y se abre el PDF para imprimir a mano
out.caido = await correr(() => { Q.imprimir = async () => { throw new Error('El agente de impresión no responde en esta computadora'); }; });
// el programa de escritorio no sabe de etiquetas (uno anterior): al PDF
out.viejo = await correr(() => { Q.estado = { ok: true, info: {} }; Q.imprimir = async () => { throw new Error('no debe llamarse'); }; });
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert r["bien"] == {"toasts": [["2 etiquetas enviadas a «Etiquetas bodega»", "ok"]], "pdf": 0, "enviados": 1, "trabajando": False, "imp": "7"}
    assert r["rechazo"] == {"toasts": [["No se imprimió en «Etiquetas bodega»: El código TE-1 no cabe en una etiqueta de 20 mm de ancho: use una etiqueta más ancha", "err"]],
                            "pdf": 0, "enviados": 0, "trabajando": False, "imp": "7"}
    assert r["apagada"] == {"toasts": [["No se imprimió en «Etiquetas bodega»: timed out", "err"]], "pdf": 0, "enviados": 0, "trabajando": False, "imp": "7"}
    assert r["caido"]["pdf"] == 1 and r["caido"]["toasts"] == [["No se imprimió en «Etiquetas bodega»: El agente de impresión no responde en esta computadora. Se abre el PDF para imprimir a mano.", "err"]]
    assert r["viejo"]["pdf"] == 1 and r["viejo"]["toasts"] == [["El envío directo necesita el programa de escritorio actualizado: se abre el PDF para imprimir a mano", "err"]] and r["viejo"]["trabajando"] is False


def test_u4_el_servicio_de_impresion_marca_el_rechazo_con_motivo(tmp_path):
    """pos/_agente.js: un error con el que el servicio RESPONDIÓ (400 «no cabe», «muy baja», la impresora no está…) lleva rechazo = true;
    si no respondió (sin conexión, vencido), no."""
    r = _node(tmp_path, """
globalThis.Q = { api: null };
const A = await import('./js/pages/pos/_agente.js');
const imp = { nombre: 'Etiquetas', conexion: 'usb', direccion: '3nStar' }, out = {};
const probar = async () => { try { await A.imprimirEtiquetas(imp, { etiquetas: [] }); return 'ok'; } catch (e) { return [e.message, e.rechazo === true]; } };
// instalación local (el propio sistema imprime): el motivo llega con su estado 400
let estado400 = false;
Q.api = async (url) => { if (url.endsWith('/estado')) return { agente: 'FISITAAP ERP', etiquetas: 1 }; const e = new Error(estado400 ? 'Una etiqueta de 15 mm de alto es muy baja para ese formato' : 'Sin conexión con el servidor'); if (estado400) e.status = 400; throw e; };
await A.agenteEstado(true);
estado400 = true; out.local_rechazo = await probar();
estado400 = false; out.local_sin_red = await probar();
// sistema en la nube: el agente suelto en esta computadora
Q.api = async () => { const e = new Error('no hay'); e.status = 404; throw e; };
let modo = 'rechaza';
globalThis.fetch = async (url) => { if (String(url).endsWith('/estado')) return { ok: true, json: async () => ({ etiquetas: 1 }) };
  if (modo === 'caido') throw new Error('fallo de red');
  return modo === 'rechaza' ? { ok: false, status: 500, json: async () => ({ ok: false, error: 'El código X no cabe en una etiqueta de 30 mm de ancho: use una etiqueta más ancha' }) } : { ok: true, status: 200, json: async () => ({ ok: true }) }; };
await A.agenteEstado(true);
out.agente_rechazo = await probar(); modo = 'bien'; out.agente_bien = await probar(); modo = 'caido'; out.agente_caido = await probar();
console.log(JSON.stringify(out));
""", archivos=(("pages", "pos", "_agente.js"),), falsos={"api.js": FALSO_API})
    assert r["local_rechazo"] == ["Una etiqueta de 15 mm de alto es muy baja para ese formato", True] and r["local_sin_red"] == ["Sin conexión con el servidor", False]
    assert r["agente_rechazo"] == ["El código X no cabe en una etiqueta de 30 mm de ancho: use una etiqueta más ancha", True]
    assert r["agente_bien"] == "ok" and r["agente_caido"] == ["El agente de impresión no responde en esta computadora", False]


# ================================================================================================ U5 · girar la impresión 180°
def test_u5_girar_la_impresion_180_en_los_dos_lenguajes(tmp_path):
    from tests.test_424_etiquetas import CAFE, _trabajo
    # TSPL: DIRECTION 1 normal y DIRECTION 0 girada; lo demás, igual
    normal, girada = ei.tspl([CAFE], 50, 30).decode("cp1252").split("\r\n"), ei.tspl([CAFE], 50, 30, girar=True).decode("cp1252").split("\r\n")
    assert normal[2] == "DIRECTION 1" and girada[2] == "DIRECTION 0" and normal[:2] + normal[3:] == girada[:2] + girada[3:] and ei.tspl([CAFE], 50, 30, girar=False) == ei.tspl([CAFE], 50, 30)
    # ZPL: ^PON normal y ^POI girada, justo después de ^XA (en cada etiqueta)
    dos = [CAFE, {"nombre": "Té", "codigo": "TE-1", "copias": 1}]
    normal, girada = ei.zpl(dos, 50, 30).decode("utf-8").split("\n"), ei.zpl(dos, 50, 30, girar=True).decode("utf-8").split("\n")
    assert [normal[i + 1] for i, ln in enumerate(normal) if ln == "^XA"] == ["^PON", "^PON"] and [girada[i + 1] for i, ln in enumerate(girada) if ln == "^XA"] == ["^POI", "^POI"]
    assert [ln for ln in normal if not ln.startswith("^PO")] == [ln for ln in girada if not ln.startswith("^PO")] and ei.zpl([CAFE], 50, 30, 20, girar=True).startswith(b"~SD20\n^XA\n^POI\n^CI28\n")
    # viaja en el trabajo como girar: true | false (sin el dato, normal)
    t = lambda **k: ei.trabajo_etiquetas(_trabajo(**k))[1]   # noqa: E731
    assert t() == t(girar=False) == t(girar=None) == ei.tspl([CAFE], 50, 30) and t(girar=True) == ei.tspl([CAFE], 50, 30, girar=True) and b"DIRECTION 0\r\n" in t(girar=True)
    assert t(lenguaje="zpl", densidad=None, girar=True) == ei.zpl([CAFE], 50, 30, girar=True) and t(lenguaje="zpl", densidad=None) == ei.zpl([CAFE], 50, 30)
    assert t(girar="false") == t() and t(girar=0) == t()                                         # solo «true» gira
    # la pantalla: la casilla de la impresora de etiquetas y el trabajo que arma
    r = _node(tmp_path, """
import { trabajoEtiquetas } from './js/pages/inventario/_etiquetas.js';
const imp = { id: 7, nombre: 'Etiquetas', uso: 'etiquetas', conexion: 'usb', direccion: '3nStar', lenguaje: 'tspl', dpi: 203 }, items = [{ id: 1, nombre: 'Café', codigo: '2000000000015', copias: 3 }];
console.log(JSON.stringify([trabajoEtiquetas(imp, items, 'nombre_codigo', [50, 30]).girar, trabajoEtiquetas({ ...imp, girar: true }, items, 'nombre_codigo', [50, 30]), trabajoEtiquetas({ ...imp, girar: false }, items, 'nombre_codigo', [50, 30]).girar]));
""")
    assert r[0] is False and r[2] is False and r[1]["girar"] is True
    assert ei.trabajo_etiquetas(r[1])[1] == ei.tspl([CAFE | {"nombre": "Café"}], 50, 30, 2, None, 203, True)
    cfg = _js("pages", "pos", "configuracion.js")
    assert ('<label class="row" v-if="impForm.lenguaje!==\'pdf\'" style="gap:6px;cursor:pointer;align-items:flex-start;align-self:end"><input type="checkbox" v-model="impForm.girar" style="margin-top:3px">'
            '<span>Girar la impresión 180°<br><span class="small muted">Actívela si la etiqueta sale de cabeza</span></span></label>') in cfg
    assert "densidad: sinDato(f.densidad) ? null : +f.densidad, girar: f.lenguaje !== 'pdf' && !!f.girar });" in cfg
    assert "nuevaImp(uso) { this.impForm = { id: null, nombre: '', uso: uso || 'comanda', conexion: 'navegador', direccion: '', ancho: 80, activa: true };" in cfg   # apagada por omisión


# ================================================================================================ U6 · la impresora de tiquetes de la caja, en todos los modos
def test_u6_la_impresora_de_tiquetes_de_la_caja_se_elige_en_la_tarjeta_impresion():
    cfg = _js("pages", "pos", "configuracion.js")
    campo = ('<Field label="Impresora de tiquetes y facturas de esta caja" style="margin-top:10px" help=\'"La del navegador" abre el comprobante para imprimirlo con Ctrl+P. '
             'Una impresora USB o de red imprime directo, sin preguntar, por el servicio de impresión de esta computadora\'><select v-model="t.impresora_comprobante_id">'
             '<option value="">— La del navegador —</option><option v-for="i in impsComprobante" :key="i.id" :value="String(i.id)">{{i.nombre}}</option></select></Field>')
    assert cfg.count(campo) == 1 and cfg.count('v-model="t.impresora_comprobante_id"') == 1 and "Hoy imprime por el navegador" not in cfg
    impresion, carrito, restaurante = cfg.index('<div id="cfg-impresion" class="card">'), cfg.index('<div id="cfg-carrito" class="card">'), cfg.index('<div id="cfg-restaurante" class="card"')
    assert impresion < cfg.index(campo) < carrito < restaurante                                 # dentro de «Impresión»: ya no en el bloque que solo ve el restaurante
    assert '<div id="cfg-impresion" class="card"><h2>Impresión</h2>' in cfg                      # sin condición: visible en todos los modos
    assert '<div id="cfg-restaurante" class="card" style="grid-column:1/-1" v-if="t.modo===\'restaurante\'">' in cfg
    # el campo guardado y la lógica de la caja no cambian
    assert "impresora_comprobante_id: ''," in _js("pages", "pos", "_datos.js") and "const id = this.cfg.impresora_comprobante_id;" in _js("pages", "pos", "caja.js")


# ================================================================================================ U7 · la impresora de etiquetas no recibe tiquetes
FALSO_API_POS = FALSO_API + """
export const hoy = () => '2026-11-11';
export const precioCliente = p => p.precio;
Object.assign(mock, { puedeGuardar: () => true, nextId: l => Math.max(0, ...l.map(x => +x.id || 0)) + 1, actualizar: (k, f, d) => { globalThis.Q.mock[k] = f(k in globalThis.Q.mock ? globalThis.Q.mock[k] : d); }, set: (k, v) => { globalThis.Q.mock[k] = v; } });
"""


ARCHIVOS_CFG = (("pages", "pos", "configuracion.js"), ("pages", "pos", "_datos.js"), ("pages", "pos", "_agente.js"), ("pages", "inventario", "_etiquetas.js"))
FALSOS_CFG = {"api.js": FALSO_API_POS, "app.js": FALSO_APP, "pages/bancos/cuentas.js": "export const cuentasParaMovimientos = () => [];\n"}


def test_u7_una_impresora_de_etiquetas_no_recibe_tiquetes_ni_se_le_quita_a_la_caja(tmp_path):
    caja = _js("pages", "pos", "caja.js"); cierres = _js("pages", "pos", "cierres.js")
    assert "impresoras().find(i => String(i.id) === String(id) && i.activa !== false && i.uso !== 'etiquetas') || null : null; }," in caja
    assert "impresoras().find(i => String(i.id) === String(t.impresora_comprobante_id) && i.activa !== false && i.uso !== 'etiquetas') : null;" in cierres
    r = _node(tmp_path, """
globalThis.Q = { toasts: [], mock: {}, store: { clientes: [], productos: [] }, permisos: ['configurar'], api: async () => ({}), abrirArchivo: async () => {} };
Q.mock.pos_impresoras = [{ id: 1, nombre: 'Caja', uso: 'comprobante', conexion: 'usb', direccion: 'EPSON', ancho: 80, activa: true }, { id: 2, nombre: 'Cocina', uso: 'comanda', conexion: 'usb', direccion: 'COCINA', ancho: 80, activa: true },
  { id: 3, nombre: 'Bar', uso: 'comanda', conexion: 'usb', direccion: 'BAR', ancho: 80, activa: true }, { id: 4, nombre: 'Libre', uso: 'comprobante', conexion: 'usb', direccion: 'OTRA', ancho: 80, activa: true },
  { id: 5, nombre: 'Etiquetas', uso: 'etiquetas', conexion: 'usb', direccion: '3nStar', modelo: '3nstar-ldt124', lenguaje: 'tspl', dpi: 203, etq_ancho_mm: 50, etq_alto_mm: 30, activa: true }];
Q.mock.items_extra = { 10: { impresora_id: '3' }, 11: { impresora_id: '' } };
Q.mock.categorias = [{ id: 7, nombre: 'Platos fuertes' }, { id: 8, nombre: 'Vitrina' }, { id: 9, nombre: 'Postres' }];
const Pagina = (await import('./js/pages/pos/configuracion.js')).default;
const { impresoras } = await import('./js/pages/pos/_datos.js');
const cfg = { terminales: [{ id: 1, nombre: 'Caja principal', modo: 'restaurante', impresora_comprobante_id: '1', destinos: { 7: '2', 8: 'none', 9: '' } }, { id: 2, nombre: 'Caja 2', modo: 'mostrador', impresora_comprobante_id: '', destinos: {} }] };
const guardar = (id, cambios) => { Q.toasts = []; const vm = { cfg, imps: impresoras(), impForm: null }; for (const k of ['alCambiarUso', 'guardarImp']) vm[k] = Pagina.methods[k].bind(vm);
  vm.impForm = { ...impresoras().find(i => i.id === id), ...cambios }; vm.alCambiarUso(); vm.guardarImp(); return { toasts: Q.toasts.slice(), uso: impresoras().find(i => i.id === id).uso, cerrado: vm.impForm === null }; };
const out = {};
out.de_caja = guardar(1, { uso: 'etiquetas' });           // la impresora de tiquetes de una caja
out.de_categoria = guardar(2, { uso: 'etiquetas' });      // asignada a una categoría como impresora de comanda
out.de_item = guardar(3, { uso: 'etiquetas' });           // asignada a un ítem como impresora de comanda
out.libre = guardar(4, { uso: 'etiquetas' });             // la que nadie usa sí puede pasar a etiquetas
out.ya_era = guardar(5, { etq_ancho_mm: 58, etq_alto_mm: 40, girar: true });   // la que ya era de etiquetas se sigue editando
out.girar = impresoras().find(i => i.id === 5).girar; out.medida = [impresoras().find(i => i.id === 5).etq_ancho_mm, impresoras().find(i => i.id === 5).etq_alto_mm];
out.otro_cambio = guardar(1, { nombre: 'Caja de adelante' });   // cambiar otra cosa de la impresora de la caja no se impide
out.nombre = impresoras().find(i => i.id === 1).nombre;
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CFG, falsos=FALSOS_CFG)
    assert r["de_caja"] == {"toasts": [["Esta impresora está asignada a la caja Caja principal: cree otra impresora para las etiquetas", "err"]], "uso": "comprobante", "cerrado": False}
    assert r["de_categoria"] == {"toasts": [["Esta impresora está asignada a comandas: cree otra impresora para las etiquetas", "err"]], "uso": "comanda", "cerrado": False}
    assert r["de_item"] == {"toasts": [["Esta impresora está asignada a comandas: cree otra impresora para las etiquetas", "err"]], "uso": "comanda", "cerrado": False}
    assert r["libre"] == {"toasts": [["Impresora «Libre» guardada", "ok"]], "uso": "etiquetas", "cerrado": True}
    assert r["ya_era"]["toasts"] == [["Impresora «Etiquetas» guardada", "ok"]] and r["girar"] is True and r["medida"] == [58, 40]
    assert r["otro_cambio"]["toasts"] == [["Impresora «Caja de adelante» guardada", "ok"]] and r["nombre"] == "Caja de adelante"


def test_u7_solo_cuentan_las_asignaciones_de_comanda_que_el_usuario_puede_ver_y_quitar(tmp_path):
    """Una impresora que quedó asignada a una categoría que ya se borró, a una caja que pasó a modo mostrador (su bloque de comandas no
    se ve) o a un ítem inactivo no está en uso: sí puede pasar a ser de etiquetas. Las asignaciones vigentes siguen impidiéndolo."""
    r = _node(tmp_path, """
globalThis.Q = { toasts: [], mock: {}, store: { clientes: [], productos: [{ id: 10, nombre: 'Batido', activo: true }, { id: 11, nombre: 'Plato viejo', activo: false }] }, permisos: ['configurar'], api: async () => ({}), abrirArchivo: async () => {} };
const imp = (id, nombre) => ({ id, nombre, uso: 'comanda', conexion: 'usb', direccion: nombre.toUpperCase(), ancho: 80, activa: true });
Q.mock.pos_impresoras = [imp(1, 'Borrada'), imp(2, 'Mostrador'), imp(3, 'Inactivo'), imp(4, 'Cocina'), imp(5, 'Barra'), imp(6, 'Sin ficha')];
Q.mock.categorias = [{ id: 7, nombre: 'Platos fuertes' }, { id: 8, nombre: 'Bebidas' }];           // la 99 («Licores») ya se borró
Q.mock.items_extra = { 10: { impresora_id: '5' }, 11: { impresora_id: '3' }, 12: { impresora_id: '6' } };   // el 11 está inactivo; el 12 no está en la lista cargada
const Pagina = (await import('./js/pages/pos/configuracion.js')).default;
const { impresoras } = await import('./js/pages/pos/_datos.js');
const cfg = { terminales: [{ id: 1, nombre: 'Restaurante', modo: 'restaurante', impresora_comprobante_id: '', destinos: { 7: '4', 99: '1' } }, { id: 2, nombre: 'Tienda', modo: 'mostrador', impresora_comprobante_id: '', destinos: { 8: '2' } }] };
const guardar = id => { Q.toasts = []; const vm = { cfg, imps: impresoras(), impForm: null }; for (const k of ['alCambiarUso', 'guardarImp']) vm[k] = Pagina.methods[k].bind(vm);
  vm.impForm = { ...impresoras().find(i => i.id === id), uso: 'etiquetas' }; vm.alCambiarUso(); vm.guardarImp(); return [Q.toasts.slice(), impresoras().find(i => i.id === id).uso]; };
const out = { borrada: guardar(1), mostrador: guardar(2), inactivo: guardar(3), vigente_categoria: guardar(4), vigente_item: guardar(5), sin_ficha: guardar(6) };
cfg.terminales[1].modo = 'restaurante'; Q.mock.pos_impresoras.push(imp(7, 'Otra barra')); cfg.terminales[1].destinos[8] = '7'; out.vuelve_a_restaurante = guardar(7);
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CFG, falsos=FALSOS_CFG)
    asignada = [["Esta impresora está asignada a comandas: cree otra impresora para las etiquetas", "err"]]
    assert r["borrada"] == [[["Impresora «Borrada» guardada", "ok"]], "etiquetas"]                 # la categoría ya no existe: nada que quitar en la pantalla
    assert r["mostrador"] == [[["Impresora «Mostrador» guardada", "ok"]], "etiquetas"]             # la caja ya no es restaurante: su bloque de comandas no se ve
    assert r["inactivo"] == [[["Impresora «Inactivo» guardada", "ok"]], "etiquetas"]               # el ítem está inactivo
    assert r["vigente_categoria"] == [asignada, "comanda"] and r["vigente_item"] == [asignada, "comanda"]
    assert r["sin_ficha"] == [asignada, "comanda"]                                                  # un ítem que la pantalla no sabe inactivo sí cuenta
    assert r["vuelve_a_restaurante"] == [asignada, "comanda"]


# ================================================================================================ U8 · el cuadro de etiquetas en el celular
def test_u8_la_tabla_del_cuadro_de_etiquetas_cabe_en_el_celular():
    """OJO: esta prueba NO mide el diseño. Solo fija el texto de la plantilla y de ui.css y suma anchos estimados a mano: pasa igual
    aunque la tabla no quepa en un celular de verdad (por ejemplo, si el título «Existencias» mide más de lo estimado). No es evidencia
    de U8: que la tabla cabe a 390 px sigue PENDIENTE DE REVISIÓN VISUAL en un navegador."""
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js"); css = (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")
    # el nombre se parte en renglones (y el código va debajo, en la misma celda: una columna menos a lo ancho)
    assert '<td class="parte fina">{{x.nombre}}<div class="mono small muted">{{x.codigo || \'Sin código\'}}</div></td>' in dlg
    assert '<thead><tr><th>Producto</th><th class="num">Existencias</th><th class="num">Copias</th><th></th></tr></thead>' in dlg and "<th>Código</th>" not in dlg
    assert ".tbl td.parte{white-space:normal;min-width:150px}" in css and ".tbl td.parte.fina{min-width:100px;overflow-wrap:anywhere}" in css
    # el campo de copias angosto y el botón de quitar siempre a la vista (sin desplazamiento horizontal)
    assert 'style="width:60px;padding:8px 6px;text-align:right" :aria-label="\'Copias de \' + x.nombre"' in dlg
    assert '<td style="padding-left:0"><button class="btn icon" title="Quitar de la lista" @click="quitar(i)">×</button></td>' in dlg
    assert 'style="white-space:normal">{{x.nombre}}' not in dlg and "width:76px" not in dlg
    # las cuentas a 390 px de ancho (aproximadas: el título «Existencias» se estima en 76 px): lo visible del cuadro, la pantalla menos el
    # relleno de 16 px a cada lado, alcanza para las cuatro columnas con su relleno de celda (8 px por lado en el celular)
    visible = 390 - 2 * 16
    producto, existencias, copias, quitar = 100 + 16, 76 + 16, 60 + 16, 28 + 8
    assert producto + existencias + copias + quitar <= visible
    assert ".tbl th,.tbl td{padding:8px 8px;font-size:11.5px}" in css and ".modal .m-body{padding:16px}" in css


# ================================================================================================ U9 · el campo «Copias»
def test_u9_las_copias_se_normalizan_al_salir_del_campo_y_el_tope_esta_a_la_vista(tmp_path):
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js")
    assert 'v-model.number="x.copias" @change="x.copias = copiasDe(x.copias)"' in dlg and "fmtCant, copiasDe," in dlg
    assert ":style=\"copiasDe(x.copias) === 0 ? 'opacity:.55' : ''\"" in dlg and "x.copias > 0" not in dlg
    assert "{{conCopias.length === 1 ? 'producto' : 'productos'}} · hasta 500 por producto y 3.000 por pedido</span>" in dlg
    r = _node(tmp_path, MONTAR + """
const vm = montar(PRODS), out = { normal: [], atenuada: [] };
// lo que hace el campo al salir de él (@change) y la condición con que la fila se atenúa
for (const v of [800, 500, 499.9, 3, 1, 0.5, 0, -2, '', null, 'abc', '12']) { vm.items[0].copias = v; out.atenuada.push(vm.copiasDe(vm.items[0].copias) === 0); vm.items[0].copias = vm.copiasDe(vm.items[0].copias); out.normal.push(vm.items[0].copias); }
vm.items[0].copias = 800; vm.items[1].copias = 0.5; out.total_sin_normalizar = vm.total; out.con_copias = vm.conCopias.map(x => x.id);
vm.copiasTodos = 900; vm.aplicarTodos(); out.todos = vm.items.map(x => x.copias);
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert r["normal"] == [500, 500, 499, 3, 1, 0, 0, 0, 0, 0, 0, 12]                           # entero de 0 a 500
    assert r["atenuada"] == [False, False, False, False, False, True, True, True, True, True, True, False]   # 0,5 ya no se ve activa
    assert r["total_sin_normalizar"] == 500 and r["con_copias"] == [1] and r["todos"] == [500, 500]


# ================================================================================================ U10 · la medida de la impresora elegida
def test_u10_con_una_impresora_de_etiquetas_elegida_la_medida_inicial_es_la_suya(tmp_path):
    r = _node(tmp_path, MONTAR + """
const OTRA = { ...IMP, id: 8, nombre: 'Zebra caja', lenguaje: 'zpl', etq_ancho_mm: 100, etq_alto_mm: 50 }, RARA = { ...IMP, id: 9, nombre: 'Rollo raro', etq_ancho_mm: 45, etq_alto_mm: 28 };
const abrir = (imps, guardado) => { Q.mock.pos_impresoras = imps; Q.guardado = guardado; const vm = montar(PRODS); return [vm.impId, vm.medidaSel, vm.medida]; };
const out = {
  // una sola impresora de etiquetas: se propone y manda su medida, aunque el navegador recuerde otra
  unica: abrir([IMP], { 'etiquetas:medida': '30x20' }), unica_sin_recuerdo: abrir([IMP], {}),
  // varias: la última usada, con su medida
  ultima: abrir([IMP, OTRA], { 'etiquetas:impresora': '8', 'etiquetas:medida': '30x20' }), personalizada: abrir([IMP, RARA], { 'etiquetas:impresora': '9', 'etiquetas:medida': '30x20' }),
  // «Elegir al imprimir (PDF)» u hoja carta: la medida recordada en este navegador
  varias_sin_ultima: abrir([IMP, OTRA], { 'etiquetas:medida': '30x20' }), pdf: abrir([], { 'etiquetas:medida': '40x25' }), carta: abrir([IMP, OTRA], { 'etiquetas:impresora': 'carta', 'etiquetas:medida': '76x51' }),
  nada: abrir([], {}), recuerdo_malo: abrir([], { 'etiquetas:medida': '500x30' }) };
// cambiar la medida a mano después sigue permitido, y al cambiar de impresora se pone la de la impresora nueva
Q.mock.pos_impresoras = [IMP, OTRA]; Q.guardado = { 'etiquetas:impresora': '7' };
const vm = montar(PRODS); vm.medidaSel = '40x30'; out.a_mano = [vm.impId, vm.medida]; vm.impId = '8'; vm.alCambiarImpresora(); out.otra = vm.medida; vm.impId = ''; vm.alCambiarImpresora(); out.a_pdf = vm.medida;
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert r["unica"] == ["7", "58x40", [58, 40]] and r["unica_sin_recuerdo"] == ["7", "58x40", [58, 40]]
    assert r["ultima"] == ["8", "100x50", [100, 50]] and r["personalizada"] == ["9", "personalizada", [45, 28]]
    assert r["varias_sin_ultima"] == ["", "30x20", [30, 20]] and r["pdf"] == ["", "40x25", [40, 25]] and r["carta"] == ["carta", "76x51", [76, 51]]
    assert r["nada"] == ["", "50x30", [50, 30]] and r["recuerdo_malo"] == ["", "50x30", [50, 30]]
    assert r["a_mano"] == ["7", [40, 30]] and r["otra"] == [100, 50] and r["a_pdf"] == [100, 50]
    assert "medida = imp ? medidaImpresora(imp) : m && medidaValida(+m[1], +m[2]) ? [+m[1], +m[2]] : [50, 30];" in _js("pages", "inventario", "_etiquetas-dialogos.js")


# ================================================================================================ U11 · buscar por código alterno fuera de la caja
FALSO_API_COMP = FALSO_API + """
export const fechaHora = v => String(v), demo = { activo: false }, CAT = {}, opts = () => [], monedas = { principal: () => ({ codigo: 'CRC' }) };
export const precioCliente = p => p.precio, hoy = () => '2026-11-11', otroImpDe = () => null, otroImpTexto = () => '';
"""


def test_u11_buscar_por_codigo_alterno_en_el_buscador_en_items_y_en_las_compras(tmp_path):
    # (a) el Buscador (facturas, cotizaciones, compras…) y (b) la búsqueda de la lista de Ítems
    r = _node(tmp_path, """
globalThis.Q = { toasts: [], mock: {}, store: { productos: [] }, permisos: [], api: async () => ({}), abrirArchivo: async () => {} };
const { Buscador, DataTable } = await import('./js/components.js');
const prods = [{ id: 1, nombre: 'Leche 1L', codigo: '2456000000010', codigos_alternos: '7441234567890,LEC-01' }, { id: 2, nombre: 'Crema dulce', codigo: 'CRE-1', codigos_alternos: null },
  { id: 3, nombre: 'Queso tierno', codigo: null }, { id: 4, nombre: 'Yogur', codigo: 'LEC-99', codigos_alternos: '' }];
const B = q => Buscador.computed.filtradas.call({ q, fuente: prods, maximo: 60, lab: o => o.nombre, det: () => '' }).map(o => o.id);
const columnas = [{ key: 'nombre', label: 'Nombre' }, { key: 'codigo', label: 'Código', mono: true, fmt: v => v || '—', busca: x => x.codigos_alternos || '' }];
const D = (search, cols) => { const vm = { search, rows: prods, columns: cols || columnas }; vm.cell = DataTable.methods.cell.bind(vm); return DataTable.computed.filtered.call(vm).map(x => x.id); };
console.log(JSON.stringify({ buscador: ['7441234567890', 'lec-01', '2456000000010', 'leche', 'LEC', 'crema cre-1', 'no-existe', ''].map(B),
  tabla: ['7441234567890', 'lec-01', '2456000000010', 'leche', 'LEC', 'no-existe', ''].map(q => D(q)), sin_busca: D('7441234567890', [{ key: 'nombre', label: 'Nombre' }, { key: 'codigo', label: 'Código' }]),
  celda: DataTable.methods.cell.call({}, prods[0], columnas[1]) }));
""", archivos=(("components.js",),), falsos={"api.js": FALSO_API_COMP, "app.js": FALSO_APP + "export const rutaPermitida = () => true;\n"})
    assert r["buscador"] == [[1], [1], [1], [1], [1, 4], [2], [], [1, 2, 3, 4]]                     # por un código alterno (el de fábrica o una etiqueta vieja), además de lo de siempre
    assert r["tabla"] == [[1], [1], [1], [1], [1, 4], [], [1, 2, 3, 4]]
    assert r["sin_busca"] == [] and r["celda"] == "2456000000010"                                   # las demás tablas del sistema siguen igual; el alterno no se muestra en la columna
    comp = _js("components.js"); items = _js("pages", "inventario", "items.js")
    assert "+ ' ' + (o.codigo || '') + ' ' + (o.numero_id || '') + ' ' + (o.codigos_alternos || '')).toLowerCase();" in comp
    assert "|| (c.busca && String(c.busca(r) ?? '').toLowerCase().includes(q))));" in comp
    assert "{ key: 'codigo', label: 'Código', mono: true, fmt: v => v || '—', busca: r => r.codigos_alternos || '' }," in items
    # (c) al recibir una compra: el código de fábrica que quedó como alterno sigue proponiendo el ítem (después de los códigos principales)
    from app import compras_inventario as ci
    P = lambda i, nombre, codigo=None, alternos=None, **k: Producto(**{"id": i, "empresa_id": 1, "nombre": nombre, "codigo": codigo, "codigos_alternos": alternos, "cabys": CABYS, "precio": 1,   # noqa: E731
                                                                      "inventariable": True, "es_servicio": False, "activo": True, **k})
    productos = [P(1, "Leche 1L", "2456000000010", "7441234567890,LEC-01"), P(2, "Crema dulce", "CRE-1"), P(3, "Yogur natural", "LEC-01"), P(4, "Queso viejo", "QUE-1", "CRE-1"),
                 P(5, "Servicio de flete", "FLE-1", "7449999999999", es_servicio=True, inventariable=False), P(6, "Mantequilla inactiva", "MAN-1", "7448888888888", activo=False)]
    lineas = [{"codigo": "7441234567890", "detalle": "LECHE ENTERA UHT 1000ML"}, {"codigo": " lec-01 ", "detalle": "otra cosa"}, {"codigo": "CRE-1", "detalle": "crema"},
              {"codigo": "7449999999999", "detalle": "flete"}, {"codigo": "7448888888888", "detalle": "mantequilla"}, {"codigo": "NADA-1", "detalle": "sin relación"}, {"codigo": "", "detalle": "Crema dulce"}]
    ci.sugerir(lineas, {}, productos, "3101000000")
    assert [(ln["producto_id"], ln["motivo"]) for ln in lineas] == [(1, "codigo"), (3, "codigo"), (2, "codigo"), (None, None), (None, None), (None, None), (2, "nombre")]
    # lo mismo por la ruta, con un comprobante recibido de verdad (su línea 1 trae el código del proveedor «CEM-50»)
    fuente = pathlib.Path(ci.__file__).read_text(encoding="utf-8")
    assert "    for p in inventariables:                         # 4.24: después de los códigos principales, los alternos" in fuente
    assert fuente.index("por_codigo.setdefault(p.codigo.strip().lower(), p)") < fuente.index("por_codigo.setdefault(a.lower(), p)")


def test_u11_la_compra_propone_el_item_por_su_codigo_alterno(api):  # noqa: F811
    from tests.test_375_costeo import _registrar, _xml_proveedor
    c = api
    cemento = _alta(c, "Cemento de la casa", "CEM-50", inventariable=True)
    rid = _registrar(_eid(), _xml_proveedor(1))
    assert c.get(f"/api/recepcion/{rid}/lineas").json()["lineas"][0]["producto_id"] == cemento["id"]                 # por su código, como siempre
    # se le genera el código propio: el de fábrica queda como alterno y la factura del proveedor lo sigue proponiendo
    assert c.post("/api/productos/codigos/generar", json={"ids": [cemento["id"]], "reemplazar": True}).json()["cambiados"] == 1
    p = _prod(c, cemento["id"]); assert p["codigo"] == _propio(cemento["id"]) and p["codigos_alternos"] == "CEM-50"
    ln = c.get(f"/api/recepcion/{rid}/lineas").json()["lineas"][0]
    assert ln["codigo"] == "CEM-50" and ln["producto_id"] == cemento["id"] and ln["motivo"] == "codigo"
    # sin el alterno ya no lo propone por código (el nombre del comprobante es otro)
    assert c.put(f"/api/productos/{cemento['id']}", json={"codigos_alternos": []}).json()["codigos_alternos"] is None
    assert c.get(f"/api/recepcion/{rid}/lineas").json()["lineas"][0]["motivo"] != "codigo"


# ================================================================================================ U14 · el navegador bloquea la ventana del PDF
def test_u14_si_el_navegador_bloquea_la_ventana_el_pdf_ya_bajado_queda_en_las_descargas(tmp_path):
    r = _node(tmp_path, """
const abiertos = [], clics = [];
let ventana = {}, pedidos = 0;
globalThis.localStorage = { getItem: () => 'tok', setItem() {}, removeItem() {} };
globalThis.fetch = async () => { pedidos++; return { ok: true, status: 200, blob: async () => ({}) }; };
URL.createObjectURL = () => 'blob:prueba'; URL.revokeObjectURL = () => {};
const { abrirArchivo } = await import('./js/api.js');
globalThis.setTimeout = () => 0;                                   // el que suelta el archivo al minuto: no hace falta esperarlo
globalThis.window = { open: (u, t) => { abiertos.push([u, t]); return ventana; } };
globalThis.document = { createElement: () => ({ click() { clics.push([this.download, this.href]); } }) };
const out = {};
// la ventana abre: nada cambia (no se descarga nada, no devuelve nada)
out.abre = [await abrirArchivo('/api/productos/etiquetas', null, { items: [] }, 'etiquetas.pdf') ?? null, abiertos.length, clics.length];
ventana = null;                                                      // el navegador bloquea la ventana nueva (window.open devuelve null)
out.con_respaldo = [await abrirArchivo('/api/productos/etiquetas', null, { items: [] }, 'etiquetas.pdf'), clics.slice(), pedidos];   // el archivo ya bajado se descarga: no se pide otra vez
try { await abrirArchivo('/api/reportes/x', null, { a: 1 }); out.sin_respaldo = 'sin aviso'; } catch (e) { out.sin_respaldo = e.message; }   // los demás usos: el error de hoy
out.descargas_tras_error = clics.length;
out.con_nombre = [await abrirArchivo('/api/productos/etiquetas', 'etiquetas.pdf', { items: [] }, 'otro.pdf') ?? null, clics[clics.length - 1][0], abiertos.length];   // «Descargar PDF»: como siempre
console.log(JSON.stringify(out));
""", archivos=(("api.js",),), falsos={"vendor/vue.esm-browser.prod.min.js": "export const reactive = x => x;\n"})
    assert r["abre"] == [None, 1, 0]
    assert r["con_respaldo"] == ["descargado", [["etiquetas.pdf", "blob:prueba"]], 2]
    assert r["sin_respaldo"] == "El navegador bloqueó la ventana del archivo: use el botón de descargar, o permita las ventanas emergentes de este sitio y vuelva a intentarlo" and r["descargas_tras_error"] == 1
    assert r["con_nombre"] == [None, "etiquetas.pdf", 3]                                     # con nombre no se abre ventana (3 = los tres intentos de antes)
    # el cuadro de etiquetas y la etiqueta de prueba lo usan con 'etiquetas.pdf' y avisan; los demás usos de abrirArchivo no cambian
    (tmp_path / "cuadro").mkdir()
    r = _node(tmp_path / "cuadro", MONTAR + """
const out = {};
const correr = async (resultado, descargar) => { Q.toasts = []; Q.abiertos = []; Q.abrirArchivo = async (...a) => { Q.abiertos.push(a); return resultado; }; const vm = montar(PRODS); await vm.imprimir(descargar); return { toasts: Q.toasts.slice(), llamada: Q.abiertos[0] && [Q.abiertos[0][1], Q.abiertos[0][3]], trabajando: vm.trabajando }; };
out.bloqueada = await correr('descargado', false); out.abre = await correr(undefined, false); out.descargar = await correr(undefined, true);
console.log(JSON.stringify(out));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert r["bloqueada"] == {"toasts": [["El navegador no dejó abrir la ventana: el PDF quedó en sus descargas", ""]], "llamada": [None, "etiquetas.pdf"], "trabajando": False}
    assert r["abre"] == {"toasts": [], "llamada": [None, "etiquetas.pdf"], "trabajando": False} and r["descargar"] == {"toasts": [], "llamada": ["etiquetas.pdf", "etiquetas.pdf"], "trabajando": False}
    cfg = _js("pages", "pos", "configuracion.js")
    assert ("try { if (await abrirArchivo('/api/productos/etiquetas', null, { prueba: true, formato: 'nombre_codigo', ancho_mm: medida[0], alto_mm: medida[1], ...(+i.dpi ? { dpi: +i.dpi } : {}) }, 'etiquetas.pdf') === 'descargado') "
            "toast('El navegador no dejó abrir la ventana: el PDF quedó en sus descargas'); } catch (e) { toast(e.message, 'err'); }") in cfg
    # nadie más pasa el cuarto parámetro
    import re
    con_respaldo = []
    for ruta in sorted((RAIZ / "app" / "static" / "js").rglob("*.js")):
        if "vendor" in ruta.parts:
            continue
        if re.search(r"abrirArchivo\([^\n]*, 'etiquetas\.pdf'\)", ruta.read_text(encoding="utf-8")):
            con_respaldo.append(ruta.name)
    assert con_respaldo == ["_etiquetas-dialogos.js", "configuracion.js"]
    assert "export async function abrirArchivo(url, nombre, body, respaldo) {" in _js("api.js")


# ================================================================================================ U12 · productos inactivos y su código
INACTIVO = " (está inactivo: actívelo o cámbiele el código)"


def test_u12_el_choque_con_un_producto_inactivo_lo_dice_el_mensaje(api):  # noqa: F811
    from tests.test_358_b import _subir, _xlsx
    from tests.test_375_costeo import _registrar, _xml_proveedor
    c = api
    viejo = _alta(c, "Coca 600 ml vieja", "7441000000017")
    activo = _alta(c, "Fanta 600 ml", "7441000000024")
    assert c.put(f"/api/productos/{viejo['id']}", json={"codigo": "7441000000031", "conservar_codigo_anterior": True}).json()["codigos_alternos"] == "7441000000017"
    assert c.put(f"/api/productos/{viejo['id']}", json={"activo": False}).json()["activo"] is False        # «Desactivar»: conserva su código y su alterno
    esperado = "Ya existe otro producto con el código 7441000000031: Coca 600 ml vieja" + INACTIVO
    # alta
    r = c.post("/api/productos", json={"nombre": "Coca 600 ml", "codigo": "7441000000031", "cabys": CABYS, "precio": 900})
    assert r.status_code == 409 and r.json()["detail"] == esperado, r.text
    r = c.post("/api/productos", json={"nombre": "Coca 600 ml", "codigo": "7441000000017", "cabys": CABYS, "precio": 900})   # también por un código alterno del inactivo
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código 7441000000017: Coca 600 ml vieja" + INACTIVO
    # cambio (la ficha) y «Registrar código» (el mismo cambio, conservando el anterior)
    r = c.put(f"/api/productos/{activo['id']}", json={"codigo": "7441000000031"}); assert r.status_code == 409 and r.json()["detail"] == esperado
    r = c.put(f"/api/productos/{activo['id']}", json={"codigo": " 7441000000031 ", "conservar_codigo_anterior": True}); assert r.status_code == 409 and r.json()["detail"] == esperado
    r = c.put(f"/api/productos/{activo['id']}", json={"codigos_alternos": ["7441000000031"]}); assert r.status_code == 409 and r.json()["detail"] == esperado
    # importación
    fila = lambda nombre, codigo: [nombre, codigo, CABYS, 900, "Unid", "Producto", "08", "CRC", "", "", "", "", ""]   # noqa: E731
    d = _subir(c, _xlsx([fila("Coca 600 ml", "7441000000031"), fila("Naranja 600 ml", "7441000000024")])).json()
    assert d["creados"] == 0 and d["errores"] == [f"Fila 2 (Coca 600 ml): {esperado}; use el modo «actualizar» para cambiarlo",
                                                  "Fila 3 (Naranja 600 ml): Ya existe otro producto con el código 7441000000024: Fanta 600 ml; use el modo «actualizar» para cambiarlo"]
    # compras: el código que escribe el usuario
    rid = _registrar(_eid(), _xml_proveedor(1))
    r = c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "crear": {"codigo": "7441000000031", "precio": 9500}}]})
    assert r.status_code == 409 and r.json()["detail"] == "Línea 1: " + esperado
    # con uno ACTIVO el mensaje es el de siempre; «Generar» también dice cuándo el dueño del código está inactivo
    r = c.post("/api/productos", json={"nombre": "Otra Fanta", "codigo": "7441000000024", "cabys": CABYS, "precio": 1})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código 7441000000024: Fanta 600 ml"
    assert etiquetas.mensaje_repetido(" X-1 ", "Pan") == "Ya existe otro producto con el código X-1: Pan" == etiquetas.mensaje_repetido("X-1", "Pan", True) == etiquetas.mensaje_repetido("X-1", "Pan", None)
    assert etiquetas.mensaje_repetido("X-1", "Pan", False) == "Ya existe otro producto con el código X-1: Pan" + INACTIVO
    sin = _alta(c, "Sprite 600 ml")
    assert c.put(f"/api/productos/{viejo['id']}", json={"codigo": _propio(sin["id"])}).status_code == 200            # el inactivo tiene, a mano, el código que le tocaría a otro
    d = c.post("/api/productos/codigos/generar", json={"ids": [sin["id"]]}).json()
    assert d["cambiados"] == 0 and d["no_se_pudo"][0]["motivo"] == f"Ya existe otro producto con el código {_propio(sin['id'])}: Coca 600 ml vieja" + INACTIVO
    # al activarlo, el mensaje vuelve a ser el corriente
    assert c.put(f"/api/productos/{viejo['id']}", json={"activo": True}).status_code == 200
    r = c.post("/api/productos", json={"nombre": "Coca 600 ml", "codigo": "7441000000017", "cabys": CABYS, "precio": 900})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código 7441000000017: Coca 600 ml vieja"


def test_u12_la_importacion_en_modo_actualizar_avisa_cuando_el_item_esta_inactivo(api):  # noqa: F811
    """En modo «actualizar» la fila cambia también un ítem INACTIVO (por su código, por un código alterno o por su nombre) y no lo
    reactiva: el resumen lo dice, porque el usuario no lo ve en la lista de activos."""
    from tests.test_358_b import _subir, _xlsx
    c = api
    cafe = _alta(c, "Café molido 500 g", "7441000000012")
    te = _alta(c, "Té negro", "7441000000029")
    azucar = _alta(c, "Azúcar a granel")
    leche = _alta(c, "Leche 1L", "LEC-2")
    assert c.put(f"/api/productos/{leche['id']}", json={"codigo": "LEC-3", "conservar_codigo_anterior": True}).json()["codigos_alternos"] == "LEC-2"
    for p in (cafe, azucar, leche):
        assert c.put(f"/api/productos/{p['id']}", json={"activo": False}).json()["activo"] is False        # «Desactivar»: conservan su código
    fila = lambda nombre, codigo, precio: [nombre, codigo, CABYS, precio, "Unid", "Producto", "08", "CRC", "", "", "", "", ""]   # noqa: E731
    archivo = _xlsx([fila("Café 500 g", "7441000000012", 1500), fila("Té negro", "7441000000029", 800), fila("Azúcar a granel", "", 700), fila("Leche 1L", "lec-2", 950)])
    avisos = ["Fila 2 (Café 500 g): el ítem «Café molido 500 g» está inactivo: se actualiza, pero sigue inactivo",
              "Fila 4 (Azúcar a granel): el ítem «Azúcar a granel» está inactivo: se actualiza, pero sigue inactivo",
              "Fila 5 (Leche 1L): el ítem «Leche 1L» está inactivo: se actualiza, pero sigue inactivo"]
    d = _subir(c, archivo, modo="actualizar", simular="1").json()                                         # la revisión previa ya lo dice
    assert d["actualizados"] == 4 and d["creados"] == 0 and d["errores"] == [] and d["avisos"] == avisos, d
    assert _prod(c, cafe["id"])["precio"] == 1000
    d = _subir(c, archivo, modo="actualizar").json()
    assert d["actualizados"] == 4 and d["creados"] == 0 and d["errores"] == [] and d["avisos"] == avisos, d
    for p, precio in ((cafe, 1500), (azucar, 700), (leche, 950)):
        q = _prod(c, p["id"]); assert q["precio"] == precio and q["activo"] is False                     # se actualizó y sigue inactivo
    assert _prod(c, te["id"])["precio"] == 800 and _prod(c, te["id"])["activo"] is True                   # el activo, sin aviso


def test_u12_eliminar_un_producto_con_movimientos_lo_desactiva_y_le_libera_el_codigo(api):  # noqa: F811
    from sqlmodel import select
    c = api
    coca = _alta(c, "Coca 600 ml mal hecha", "7441000000017", inventariable=True, cantidad_inicial=5)       # con existencia inicial: ya tiene un movimiento
    assert c.put(f"/api/productos/{coca['id']}", json={"codigo": "7441000000031", "conservar_codigo_anterior": True}).json()["codigos_alternos"] == "7441000000017"
    fanta = _alta(c, "Fanta 600 ml", "7441000000024", inventariable=True, cantidad_inicial=2)
    sprite = _alta(c, "Sprite sin código", inventariable=True, cantidad_inicial=1)
    limpio = _alta(c, "Sin movimientos", "LIM-1")
    # «Desactivar» (en la ficha o en lote) NO libera nada
    assert c.put(f"/api/productos/{fanta['id']}", json={"activo": False}).json()["codigo"] == "7441000000024"
    assert c.post("/api/productos/lote/cambios", json={"ids": [coca["id"]], "activo": False}).status_code == 200
    p = _prod(c, coca["id"]); assert p["activo"] is False and p["codigo"] == "7441000000031" and p["codigos_alternos"] == "7441000000017"
    assert c.post("/api/productos", json={"nombre": "Coca 600 ml", "codigo": "7441000000031", "cabys": CABYS, "precio": 900}).status_code == 409
    # «Eliminar» uno que ya tiene movimientos: queda inactivo y su código y sus códigos alternos quedan vacíos
    r = c.delete(f"/api/productos/{coca['id']}"); assert r.status_code == 200 and r.json() == {"ok": True, "desactivado": True}
    p = _prod(c, coca["id"]); assert p["activo"] is False and p["codigo"] is None and p["codigos_alternos"] is None and p["nombre"] == "Coca 600 ml mal hecha"
    # ... así el usuario puede crear el nuevo con el mismo código (y con el que era alterno)
    nueva = c.post("/api/productos", json={"nombre": "Coca 600 ml", "codigo": "7441000000031", "cabys": CABYS, "precio": 900}); assert nueva.status_code == 200, nueva.text
    assert c.put(f"/api/productos/{nueva.json()['id']}", json={"codigos_alternos": ["7441000000017"]}).json()["codigos_alternos"] == "7441000000017"
    assert c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0
    # la auditoría anota cuál tenía
    def liberados():
        with Session(engine) as s:
            return [a.detalle for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == _eid(), auth.Auditoria.accion == "producto_codigo_liberado").order_by(auth.Auditoria.id)).all()]
    assert liberados() == [f"«Coca 600 ml mal hecha» (ítem {coca['id']}) ya tenía ventas o movimientos: al eliminarlo quedó inactivo y sin código. Tenía el código 7441000000031 y el código alterno 7441000000017"]
    # eliminar el que ya estaba inactivo (con «Desactivar») también lo libera; sin código no hay nada que anotar
    assert c.delete(f"/api/productos/{fanta['id']}").json() == {"ok": True, "desactivado": True} and _prod(c, fanta["id"])["codigo"] is None
    assert c.delete(f"/api/productos/{sprite['id']}").json() == {"ok": True, "desactivado": True}
    assert liberados()[1:] == [f"«Fanta 600 ml» (ítem {fanta['id']}) ya tenía ventas o movimientos: al eliminarlo quedó inactivo y sin código. Tenía el código 7441000000024"]
    # uno sin ventas ni movimientos se borra de verdad, como siempre
    assert c.delete(f"/api/productos/{limpio['id']}").json() == {"ok": True} and all(x["id"] != limpio["id"] for x in c.get("/api/productos").json())
    # la pantalla quita el código del ítem que quedó inactivo sin volver a cargar la lista
    items = _js("pages", "inventario", "items.js")
    assert items.count("if (res?.desactivado) store.poner('productos', { id: r.id, codigo: null, codigos_alternos: null });") == 2


def test_u12_eliminar_en_la_instalacion_local_tambien_libera_el_codigo_en_la_nube(api):  # noqa: F811
    """La caja con el programa de escritorio «elimina» un ítem suyo que ya tiene ventas: queda inactivo y sin código, y así sube. La nube
    no lo toma por un código que la instalación no había visto (no lo devuelve como código alterno): también allí queda libre."""
    from app import sinc
    c = api
    eid, pid = _eid(), 3 * 10_000_000 + 21
    with Session(engine_empresa(eid)) as s:
        s.add(Producto(id=pid, empresa_id=eid, nombre="Jabón azul", codigo="7441001234567", codigos_alternos="JAB-1", cabys=CABYS, precio=500, inventariable=False))
        s.add(Producto(id=pid + 1, empresa_id=eid, nombre="Jabón verde", codigo="7441001234574", cabys=CABYS, precio=500, inventariable=False))
        s.add(Producto(id=pid + 2, empresa_id=eid, nombre="Jabón rojo", codigo="7441001234581", cabys=CABYS, precio=500, inventariable=False))
        s.add(Producto(id=pid + 3, empresa_id=eid, nombre="Jabón lila", codigo="7441001234598", cabys=CABYS, precio=500, inventariable=False)); s.commit()
        azul, verde, rojo, lila = (s.get(Producto, pid + i).model_dump() for i in range(4))                # como los tiene la instalación

    def sube(*filas):
        with Session(engine_empresa(eid)) as s:
            out = sinc._aplicar_cambios_instalacion(s, _ctx(), eid, 3, "Caja local", {"productos": list(filas)})
        assert out["productos"] == len(filas) and out["errores"] == [], out
    # «Eliminar» en la caja (main.borrar_producto): inactivo, sin código y sin códigos alternos
    sube({**azul, "activo": False, "codigo": None, "codigos_alternos": None})
    p = _prod(c, pid); assert p["activo"] is False and p["codigo"] is None and p["codigos_alternos"] is None
    with Session(engine_empresa(eid)) as s:
        assert etiquetas.producto_con_codigo(s, eid, "7441001234567") is None and etiquetas.producto_con_codigo(s, eid, "JAB-1") is None
    nuevo = c.post("/api/productos", json={"nombre": "Jabón azul 2", "codigo": "7441001234567", "cabys": CABYS, "precio": 600}); assert nuevo.status_code == 200, nuevo.text
    assert c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0
    # «Desactivar» en la caja conserva el código: en la nube sigue siendo de ese ítem
    sube({**verde, "activo": False})
    assert _prod(c, pid + 1)["codigo"] == "7441001234574"
    r = c.post("/api/productos", json={"nombre": "Otro verde", "codigo": "7441001234574", "cabys": CABYS, "precio": 1})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código 7441001234574: Jabón verde" + INACTIVO
    # lo de siempre no cambia: un ítem ACTIVO que sube sin el código de la nube lo deja como código alterno (las etiquetas ya pegadas se siguen leyendo)…
    sube({**rojo, "codigo": None, "precio": 650})
    p = _prod(c, pid + 2); assert p["precio"] == 650 and p["codigo"] is None and p["codigos_alternos"] == "7441001234581"
    # …y también uno inactivo que sube un programa anterior, que no conoce los códigos alternos (no los manda) ni libera nada al eliminar
    sube({k: v for k, v in lila.items() if k != "codigos_alternos"} | {"activo": False, "codigo": None})
    p = _prod(c, pid + 3); assert p["activo"] is False and p["codigo"] is None and p["codigos_alternos"] == "7441001234598"


# ================================================================================================ U13 · el programa de escritorio lleva el armador de etiquetas
def test_u13_el_armador_de_etiquetas_va_en_los_modulos_ocultos_del_programa():
    import importlib.util
    bat = RAIZ / "agente" / "construir.bat"; herramienta = RAIZ / "tools" / "construir_local.py"
    assert "--hidden-import app.escpos --hidden-import app.etiquetas_impresora --hidden-import win32print" in bat.read_text(encoding="utf-8")
    spec = importlib.util.spec_from_file_location("construir_424_pulido", herramienta); C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
    assert "app.etiquetas_impresora" in C.OCULTOS and "app.escpos" in C.OCULTOS
    assert 'for mod in ("win32print", "win32api", "pywintypes", "uvicorn", "app.main", "app.escpos", "app.etiquetas_impresora"):' in herramienta.read_text(encoding="utf-8")   # y se revisa que no falte en el exe
    # cada archivo conserva sus finales de línea
    b = herramienta.read_bytes(); assert b.count(b"\n") == b.count(b"\r\n") > 0
    assert b"\r\n" not in bat.read_bytes()
    # escpos.py lo importa dentro de imprimir_etiquetas (al imprimir): por eso se nombra, para que el exe lo lleve
    assert "    from . import etiquetas_impresora" in (RAIZ / "app" / "escpos.py").read_text(encoding="utf-8")
