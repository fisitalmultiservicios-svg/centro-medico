# -*- coding: utf-8 -*-
"""4.31, tanda 16a (D:/Claude/FISITAAP-trabajo/scratchpad/sinc427/diseno_tanda16_empresa.md, «Tanda 16a — Guardas y correcciones»):
guardas para la compañía que se armó en el programa de una computadora y nunca se conectó a la página web.

1. Web: con un pase que trae cédula (la computadora ya tiene comprobantes) y sin la terminal de una computadora de ESA empresa, la web no
   deja aprobar; si se aprobó antes de saberlo, la entrega se detiene sin dar nada. Protege también a los programas 4.25 a 4.30.
2. Programa: «Conectar con mi cuenta» (y «Tengo un código», salvo en modo soporte) se detiene antes de pedir el pase cuando la compañía
   local tiene comprobantes, clientes o ítems y nunca se conectó.
3. Respaldos en la web: la cédula se compara siempre; la llave que no se puede abrir no se copia; un respaldo que viene de un programa se
   restaura solo si la persona lo confirma.
4. Programa conectado: los datos de la empresa que manda la web no se cambian en Configuración › Empresa ni › Facturación electrónica
   (la regla de «antes»).

Nube y computadora corren en el mismo proceso (como tests/test_49_local_sinc.py y tests/test_425_conexion_programa.py)."""
import io
import json
import pathlib
import sqlite3
import zipfile

import pytest
from sqlmodel import Session, select

from app import auth, modulos, respaldo, secretos, sinc
from app.config import DATA_DIR
from app.db import Auditoria, Cliente, Documento, Empresa, Producto, engine, engine_empresa
from test_49_local_sinc import H, NUBE, _admin_empresa, _cfg, _modo_local, _soltar_limite_vinculacion, _vincular, c
from test_425_conexion_nube import _aprobar, _limpiar_limitador, _misma, _pase, _recoger, _vinc
from test_425_conexion_nube import _iniciar as _iniciar_web
from test_425_conexion_programa import _BASE, _confirmar, _conectar, _estado, _llamadas, _programa, _soltar_programa
from test_425_conexion_programa import _iniciar as _iniciar_programa

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
TEXTO_WEB = ("Esta computadora ya tiene ventas de esta empresa que no están en la página web. Si la conecta así, se pierden o se duplican. "
             "Escriba a soporte.")
TEXTO_PROGRAMA = ("Esta empresa tiene datos que no están en la página web. Si la conecta así, se pierden. No la conecte: escriba a soporte para "
                  "pasarla a la página web.")
TEXTO_RESPALDO = ("Este respaldo viene del programa de una computadora. Si después conecta esa computadora, sus cobros quedarán dobles. Para "
                  "pasar una empresa de la computadora a la página web, escriba a soporte. ¿Restaurar igual?")
CAMPOS_PANTALLA = ("nombre", "nombre_comercial", "tipo_id", "numero_id", "actividad", "provincia", "canton", "distrito", "barrio", "otras_senas",
                   "telefono", "correo", "proveedor_sistemas", "ambiente", "registro_fiscal_8707", "factura_electronica")


@pytest.fixture(autouse=True)
def _limpieza():
    _limpiar_limitador()
    _soltar_programa()
    with Session(engine) as sc:
        _BASE[0] = max([e.id for e in sc.exec(select(Empresa)).all()] or [0])
    base = _BASE[0]
    yield
    _soltar_programa()
    _limpiar_limitador()
    with Session(engine) as sc:
        nuevas = [e.id for e in sc.exec(select(Empresa).where(Empresa.id > base)).all()]
    for eid in nuevas:                       # otras pruebas buscan empresas vinculadas en la base compartida
        try:
            with Session(engine_empresa(eid)) as s:
                cfg = sinc._cfg_local(s, eid)
                if cfg.get("vinculado"):
                    cfg.update({"vinculado": False, "token": None})
                    sinc._escribir(s, eid, sinc.CLAVE_LOCAL, cfg); s.commit()
        except Exception:  # noqa: BLE001
            pass
        sinc._fijas.pop(eid, None); sinc._inst_estado.pop(eid, None); modulos._rangos.pop(eid, None)
        for r in respaldo.listar_empresa(eid):
            respaldo.eliminar_empresa(eid, r["nombre"])


# ------------------------------------------------------------------------------------------------------------------ ayudas
def _comprobante(eid: int, n: int = 1, terminal: int = 1, **campos) -> None:
    with Session(engine_empresa(eid)) as s:
        s.add(Documento(empresa_id=eid, tipo_documento="04", clave=f"506{eid:07d}{terminal:05d}{n:035d}", consecutivo=f"001{terminal:05d}04{n:010d}",
                        fecha_emision="2026-11-12T08:00:00-06:00", estado="aceptado", ambiente="sandbox", moneda="CRC", tipo_cambio=1, total=1000, **campos))
        s.commit()


def _cliente_local(eid: int) -> None:
    with Session(engine_empresa(eid)) as s:
        s.add(Cliente(empresa_id=eid, nombre="Cliente de la computadora QA", numero_id="101110111")); s.commit()


def _item_local(eid: int) -> None:
    with Session(engine_empresa(eid)) as s:
        s.add(Producto(empresa_id=eid, nombre="Ítem de la computadora QA", cabys="4321000000000", precio=1000)); s.commit()


def _vacia(cedula: str) -> int:
    """Una empresa de esta computadora sin nadie que pueda entrar (la que ve la conexión sin sesión)."""
    with Session(engine) as sc:
        return auth.crear_empresa(sc, "Local sin miembros QA " + cedula, "", cedula).id


def _empresa(eid: int) -> Empresa:
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); sc.expunge(e)
        return e


def _acciones(eid: int, accion: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == accion)).all()


# =================================================================================================== 2. parada en el programa
def test_conectar_con_mi_cuenta_se_detiene_con_datos_locales_y_no_llama_a_la_web(monkeypatch):
    eid_n, ta = _admin_empresa("-g1n", "3101431001")
    locales = [(dato, *_admin_empresa("-g1l" + dato.__name__, "3101431001")) for dato in (_comprobante, _cliente_local, _item_local)]
    shim = _programa(monkeypatch, sin_estrenar=False)
    for dato, eid_l, tl in locales:                                         # comprobantes, clientes o ítems: cualquiera detiene
        dato(eid_l)
        r = _iniciar_programa("Caja 1", H(tl))
        assert r.status_code == 409, r.text
        assert r.json()["detail"] == {"codigo": "datos_locales", "mensaje": TEXTO_PROGRAMA}
        assert _acciones(eid_l, "sinc_local_conexion_detenida")
        # «Tengo un código» tampoco (sin modo soporte), y la empresa local queda igual
        r = c.post("/api/sinc/local/vincular", headers=H(tl), json={"url": NUBE, "codigo": "L1-AAAA-BBBB-CCCC-DDDD", "nombre": "Caja"})
        assert r.status_code == 409 and r.json()["detail"]["mensaje"] == TEXTO_PROGRAMA, r.text
        assert not _cfg(eid_l).get("terminal") and _empresa(eid_l).nombre.startswith("Sinc49 QA-g1l")
    assert _llamadas(shim, "/api/sinc/conexion/iniciar") == [] and _llamadas(shim, "/api/sinc/canje") == []
    assert not _vinc(eid_n).get("instalaciones")
    # sin sesión (computadora sin estrenar): una empresa sin miembros con datos también detiene
    _soltar_programa()
    shim = _programa(monkeypatch, sin_estrenar=True)
    vacia = _vacia("3101431011")
    _cliente_local(vacia)
    r = _iniciar_programa("Caja 1")
    assert r.status_code == 409 and r.json()["detail"]["mensaje"] == TEXTO_PROGRAMA, r.text
    assert _llamadas(shim, "/api/sinc/conexion/iniciar") == []


def test_tengo_un_codigo_en_modo_soporte_si_sigue(monkeypatch):
    eid_n, ta = _admin_empresa("-g1bn", "3101431012")
    eid_l, tl = _admin_empresa("-g1bl", "3101431012")
    _programa(monkeypatch, sin_estrenar=False)
    _item_local(eid_l)
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")                                  # soporte decidió conectarla así
    j = _vincular(monkeypatch, ta, tl, "Caja soporte")
    assert j["vinculado"] and j["terminal"] >= 2


def test_sin_datos_propios_o_ya_conectada_conecta_igual(monkeypatch):
    """Lo más importante: una computadora sin datos propios conecta como siempre, y una que ya estuvo conectada (con sus ventas) vuelve."""
    eid_n, ta = _admin_empresa("-g2n", "3101431002")
    eid_l, tl = _admin_empresa("-g2l", "3101431002")
    shim = _programa(monkeypatch, sin_estrenar=False)
    v = _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))
    assert v["empresa_id"] == eid_l and _cfg(eid_l)["vinculado"]
    terminal = _cfg(eid_l)["terminal"]
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    assert ini["cedula"] is None                                               # sin datos: no manda cédula (como siempre)
    # ya conectada: vende, se desconecta y se conecta de nuevo: manda su terminal y la web la deja pasar
    _comprobante(eid_l, 1, terminal)
    _cliente_local(eid_l)
    assert c.post("/api/sinc/local/desvincular", headers=H(tl)).status_code == 200
    _soltar_programa(); _limpiar_limitador()
    v = _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))
    assert v["empresa_id"] == eid_l and _cfg(eid_l)["vinculado"]
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    rec = [x[2] for x in _llamadas(shim, "/api/sinc/conexion/recoger") if x[2].get("confirmar")][-1]
    assert ini["cedula"] == "3101431002" and rec["terminal_anterior"] == terminal
    assert not _acciones(eid_n, "sinc_conexion_bloqueada")


# ======================================================================================================= 1. guarda en la web
def test_web_no_deja_aprobar_un_pase_425_con_cedula_y_sin_terminal_anterior(monkeypatch):
    """P-20/E-2 (simulado): lo que manda un programa 4.25 con una compañía local con comprobantes: cédula al iniciar y, al sondear, nada de
    terminal anterior. La página no ofrece aprobar y aprobar da 409; rechazar sí se puede."""
    eid_n, ta = _admin_empresa("-g3n", "3101431003")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar_web("Caja 1", cedula="3-101-431003", cab=cab)
    assert _recoger(secreto, cab=cab).json()["estado"] == "pendiente"         # el programa sondea (sin terminal_anterior)
    assert _pase(codigo_hash=sinc._hash_codigo(codigo)).terminal_previa == 0
    v = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **cab}, json={"codigo": codigo}).json()
    assert [x["id"] for x in v["empresas"]] == [eid_n] and v["empresas"][0]["bloqueada"] is True and v["bloqueo"] == TEXTO_WEB
    r = _aprobar(ta, codigo, eid_n, cab=cab)
    assert r.status_code == 409 and r.json()["detail"] == {"codigo": "datos_locales", "mensaje": TEXTO_WEB}, r.text
    p = _pase(codigo_hash=sinc._hash_codigo(codigo))
    assert p.estado == "pendiente" and p.numero_hash is None and p.usuario_id is None
    assert _acciones(eid_n, "sinc_conexion_bloqueada")
    assert _aprobar(ta, codigo, eid_n, aprobar=False, cab=cab).json()["estado"] == "rechazado"
    assert not _vinc(eid_n).get("instalaciones")


def test_aprobada_antes_de_saberlo_la_entrega_se_detiene_sin_dar_nada(monkeypatch):
    eid_n, ta = _admin_empresa("-g4n", "3101431004")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar_web("Caja 1", cedula="3101431004", cab=cab)
    a = _aprobar(ta, codigo, eid_n, cab=cab).json()                            # todavía no sondeó: la web no lo sabe
    assert a["estado"] == "aprobado"
    j = _recoger(secreto, cab=cab).json()                                      # el primer sondeo ya aprobado, sin terminal: se detiene
    assert j["estado"] == "anulada" and j["motivo"] == "datos_locales" and j["mensaje"] == TEXTO_WEB, j
    assert "token" not in j and "empresa" not in j
    j = _recoger(secreto, a["numero"], True, cab=cab).json()                   # ni con el número
    assert j["estado"] == "anulada" and j["motivo"] == "datos_locales" and "token" not in j
    assert _pase(id=a["pase"]).estado == "bloqueado" and _pase(id=a["pase"]).token_id is None
    assert c.post("/api/sinc/conexion/seguimiento", headers=H(ta), json={"pase": a["pase"]}).json()["estado"] == "bloqueada"
    assert not _vinc(eid_n).get("instalaciones")
    with Session(engine) as sc:
        assert not sc.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == eid_n, auth.TokenApi.usuario_id == auth.TOKEN_EMPRESA)).all()
        assert all(x.respuesta == "anulada" for x in sc.exec(select(sinc.SincAviso).where(sinc.SincAviso.pase_id == a["pase"])).all())


def test_web_deja_pasar_a_la_computadora_que_vuelve_y_no_a_una_terminal_ajena(monkeypatch):
    eid_n, ta = _admin_empresa("-g5n", "3101431005")
    cab = _misma(monkeypatch)
    _soltar_limite_vinculacion()
    codigo_v = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja"}).json()["codigo"]
    t = c.post("/api/sinc/canje", json={"codigo": codigo_v, "nombre": "Caja"}).json()["terminal"]
    # la computadora que estuvo conectada a ESTA empresa: pasa
    secreto, codigo, _ = _iniciar_web("Caja", cedula="3101431005", cab=cab)
    assert _recoger(secreto, cab=cab, terminal_anterior=t, secuencias={}).json()["estado"] == "pendiente"
    v = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **cab}, json={"codigo": codigo}).json()
    assert v["empresas"][0]["bloqueada"] is False and v["bloqueo"] is None
    a = _aprobar(ta, codigo, eid_n, cab=cab).json()
    assert a["estado"] == "aprobado", a
    ok = _recoger(secreto, a["numero"], True, cab=cab, terminal_anterior=t, secuencias={}).json()
    assert ok["estado"] == "conectada" and ok["token"], ok
    # una terminal que no es de ninguna computadora de esta empresa: no
    _limpiar_limitador()
    secreto, codigo, _ = _iniciar_web("Caja", cedula="3101431005", cab=cab)
    _recoger(secreto, cab=cab, terminal_anterior=77, secuencias={})
    assert _aprobar(ta, codigo, eid_n, cab=cab).json()["detail"]["codigo"] == "datos_locales"


def test_programa_425_sin_la_guarda_no_conecta_una_compania_con_comprobantes(monkeypatch):
    """Un programa sin la guarda nueva (4.25 a 4.30: _parar_con_datos_locales no existe) con una compañía local con comprobantes: la web no
    deja aprobar y, si se aprobó antes de que el programa sondeara, la entrega se detiene. La computadora no recibe nada."""
    eid_n, ta = _admin_empresa("-g6n", "3101431006")
    eid_l, tl = _admin_empresa("-g6l", "3101431006")
    shim = _programa(monkeypatch, sin_estrenar=False)
    monkeypatch.setattr(sinc, "_parar_con_datos_locales", lambda *a, **k: None)
    _comprobante(eid_l)
    nombre_local = _empresa(eid_l).nombre
    j = _iniciar_programa("Caja 1", H(tl)).json()
    assert _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]["cedula"] == "3101431006"
    assert _estado(j["intento"], H(tl)).json()["estado"] == "esperando"      # sondea: la web ya sabe que nunca estuvo conectada
    r = _aprobar(ta, j["codigo"], eid_n)
    assert r.status_code == 409 and r.json()["detail"]["mensaje"] == TEXTO_WEB, r.text
    # aprobada antes del primer sondeo: la entrega se detiene
    _soltar_programa(); _limpiar_limitador()
    j = _iniciar_programa("Caja 1", H(tl)).json()
    assert _aprobar(ta, j["codigo"], eid_n).json()["estado"] == "aprobado"
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "anulada" and v["mensaje"] == TEXTO_PROGRAMA, v       # (un programa 4.25 dice su propio «se anuló»)
    assert _confirmar(j["intento"], "123", cab=H(tl)).json()["estado"] == "anulada"
    cfg = _cfg(eid_l)
    assert not cfg.get("terminal") and not cfg.get("vinculado") and _empresa(eid_l).nombre == nombre_local
    assert not _vinc(eid_n).get("instalaciones")


def test_conexion_normal_de_un_programa_425_sigue_igual(monkeypatch):
    eid_n, ta = _admin_empresa("-g7n", "3101431007")
    shim = _programa(monkeypatch)                                              # sin estrenar, versión 4.25
    v = _conectar(monkeypatch, shim, ta, eid_n)
    assert v["estado"] == "lista" and v["empresa_id"] != eid_n
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    assert ini["cedula"] is None and set(ini) == {"secreto_hash", "nombre", "cedula", "version"}
    p = _pase(codigo_hash=sinc._hash_codigo(v["codigo"]))
    assert p.estado == "entregado" and p.terminal_previa is None               # sin cédula no se anota nada
    # por la web directo (lo que manda un programa 4.25): consultar trae lo de siempre, sin bloqueo
    _limpiar_limitador()
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar_web("Caja 2", cab=cab)
    _recoger(secreto, cab=cab)
    w = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **cab}, json={"codigo": codigo}).json()
    assert w["bloqueo"] is None and w["empresas"][0]["bloqueada"] is False and w["cedula"] is None
    a = _aprobar(ta, codigo, eid_n, cab=cab).json()
    assert _recoger(secreto, a["numero"], True, cab=cab).json()["estado"] == "conectada"


# ======================================================================================== 4. programa conectado: Empresa y Hacienda
def _como_la_pantalla(tok: str, antes: bool = True, **cambios) -> dict:
    """Lo que manda Configuración › Empresa o › Facturación electrónica: la empresa entera y, desde la 4.31, «antes»."""
    d = c.get("/api/empresa", headers=H(tok)).json()
    claves = CAMPOS_PANTALLA + ("margen_cambiario", "sucursal", "terminal", "smtp_puerto", "smtp_seguridad", "correo_automatico", "sitio_web")
    cuerpo = {k: d.get(k) for k in claves if d.get(k) is not None}
    cuerpo.update({"usuario_hacienda": None, "password_hacienda": None})
    if antes:
        cuerpo["antes"] = {k: d.get(k) for k in CAMPOS_PANTALLA}
    cuerpo.update(cambios)
    return cuerpo


def test_programa_conectado_los_datos_de_la_web_no_se_cambian_aqui(monkeypatch):
    eid_a, ta = _admin_empresa("-g8n", "3101431008")
    eid_b, tb = _admin_empresa("-g8l", "3101431009")
    _modo_local(monkeypatch)
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
    _vincular(monkeypatch, ta, tb, "Caja")
    # cambiar la actividad: 409 con el texto
    r = c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, actividad="5610.0"))
    assert r.status_code == 409, r.text
    assert r.json()["detail"] == {"codigo": "solo_web_empresa", "campos": ["actividad"], "mensaje": "Se cambia en la página web (nube49)."}
    # cambiar solo la contraseña con el formulario cargado ANTES de una bajada que cambió el nombre: no da 409 y el nombre queda el de la web
    cuerpo = _como_la_pantalla(tb, password_hacienda="Clave-ATV-431-QA")
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_b); e.nombre = "Nombre que bajó de la web QA"; sc.add(e); sc.commit()
    r = c.put("/api/empresa", headers=H(tb), json=cuerpo)
    assert r.status_code == 200 and "aviso" not in r.json(), r.text
    e = _empresa(eid_b)
    assert e.nombre == "Nombre que bajó de la web QA" and secretos.descifrar(e.clave_cifrada, e.password_hacienda) == "Clave-ATV-431-QA"
    # una pantalla vieja (sin «antes»): lo de la web se ignora y la respuesta lo avisa
    r = c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, antes=False, nombre="Otro nombre local QA", ambiente="produccion"))
    assert r.status_code == 200 and "se cambian en la página web (nube49)" in r.json()["aviso"], r.text
    assert _empresa(eid_b).nombre == "Nombre que bajó de la web QA" and _empresa(eid_b).ambiente == "sandbox" and r.json()["cambio_ambiente"] is False
    assert "aviso" not in c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, antes=False)).json()     # sin diferencias, sin aviso
    # lo que no manda la web sí se cambia aquí; la sucursal sigue con su regla de siempre
    r = c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, sitio_web="https://local431.example.test"))
    assert r.status_code == 200 and _empresa(eid_b).sitio_web == "https://local431.example.test", r.text
    r = c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, sucursal=2))
    assert r.status_code == 400 and "quedaron fijas" in r.json()["detail"], r.text
    # en la web (y en un programa sin conectar) nada cambia: «antes» se ignora y se guarda lo que manda
    r = c.put("/api/empresa", headers=H(ta), json=_como_la_pantalla(ta, actividad="5610.0", otras_senas="Frente al parque central QA"))
    assert r.status_code == 200 and _empresa(eid_a).actividad == "5610.0", r.text
    assert c.post("/api/sinc/local/desvincular", headers=H(tb)).status_code == 200
    r = c.put("/api/empresa", headers=H(tb), json=_como_la_pantalla(tb, actividad="5610.0", otras_senas="Frente al parque central QA",
                                                                    nombre="Nombre local QA"))
    assert r.status_code == 200 and _empresa(eid_b).nombre == "Nombre local QA", r.text


# ============================================================================================================== 3. respaldos
def _respaldo_de(eid: int) -> pathlib.Path:
    return respaldo.ejecutar_empresa(_empresa(eid), forzar=True)


def _rehacer(origen: pathlib.Path, quitar=(), cambiar=None, agregar=None) -> bytes:
    """El zip `origen` con entradas quitadas, cambiadas ({nombre: bytes}) o agregadas."""
    buf = io.BytesIO()
    with zipfile.ZipFile(origen) as z, zipfile.ZipFile(buf, "w") as w:
        for n in z.namelist():
            if n in quitar:
                continue
            w.writestr(n, (cambiar or {}).get(n, z.read(n)))
        for n, datos in (agregar or {}).items():
            w.writestr(n, datos)
    return buf.getvalue()


def _subir(tok: str, contenido: bytes):
    return c.post("/api/respaldos/subir", headers=H(tok), files={"archivo": ("r.zip", contenido, "application/zip")})


def test_respaldo_de_otra_cedula_con_el_mismo_numero_se_rechaza(monkeypatch, tmp_path):
    eid, t = _admin_empresa("-g9", "3101431010")
    zipf = _respaldo_de(eid)
    with zipfile.ZipFile(zipf) as z:
        datos = json.loads(z.read("empresa.json"))
    otro = _rehacer(zipf, cambiar={"empresa.json": json.dumps({**datos, "numero_id": "3101999431", "nombre": "Otra QA"}).encode()})
    r = _subir(t, otro)
    assert r.status_code == 400 and "no es un respaldo de esta empresa" in r.json()["detail"] and "3101999431" in r.json()["detail"], r.text
    p = tmp_path / "otro.zip"
    p.write_bytes(otro)
    with pytest.raises(ValueError):
        respaldo.validar_zip_empresa(eid, p)
    # el mismo número sin empresa.json: se acepta (trae la base de esta misma empresa) y lo dice
    r = _subir(t, _rehacer(zipf, quitar=("empresa.json",)))
    assert r.status_code == 200 and r.json()["aviso"] == respaldo.AVISO_SIN_EMPRESA_JSON, r.text
    # el suyo, como siempre
    r = _subir(t, zipf.read_bytes())
    assert r.status_code == 200 and "aviso" not in r.json(), r.text


def test_llave_que_no_se_puede_abrir_no_se_copia(monkeypatch):
    eid, t = _admin_empresa("-g10", "3101431013")
    e = _empresa(eid)
    ajena, propia = f"ajena_{eid}_qa431.p12", f"propia_{eid}_qa431.p12"
    contenido = _rehacer(_respaldo_de(eid), agregar={f"data/certs/{ajena}": secretos.cifrar_archivo(secretos.nueva_clave_empresa(), b"p12 de otra"),
                                                      f"data/certs/{propia}": secretos.cifrar_archivo(e.clave_cifrada, b"p12 propia")})
    nombre = _subir(t, contenido).json()["nombre"]
    r = c.post(f"/api/respaldos/{nombre}/restaurar", headers=H(t), json={"confirmacion": "RESTAURAR"})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["omitidos"]["certs"] == 1 and j["copiados"]["certs"] == 1 and j["pendiente"] == [respaldo.MENSAJE_LLAVE_OMITIDA] and j["programa"] is False
    assert not (DATA_DIR / "certs" / ajena).exists() and (DATA_DIR / "certs" / propia).exists()


def _zip_a_mano(carpeta: pathlib.Path, eid: int, cedula: str, docs=(), sinc_local: bool = False) -> pathlib.Path:
    """Un respaldo armado a mano con la base mínima: comprobantes [(consecutivo, importado_de)] y, si se pide, el registro sinc_local."""
    _zip_a_mano.n = getattr(_zip_a_mano, "n", 0) + 1
    tmp = carpeta / f"a_mano_{_zip_a_mano.n}"
    tmp.mkdir()
    db = tmp / f"empresa_{eid}.db"
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE documento (id INTEGER PRIMARY KEY, empresa_id INTEGER, consecutivo TEXT, importado_de TEXT)")
    con.execute("CREATE TABLE registro (id INTEGER PRIMARY KEY, empresa_id INTEGER, clave TEXT, datos TEXT, coleccion INTEGER)")
    for cons, imp in docs:
        con.execute("INSERT INTO documento (empresa_id, consecutivo, importado_de) VALUES (?, ?, ?)", (eid, cons, imp))
    if sinc_local:
        con.execute("INSERT INTO registro (empresa_id, clave, datos, coleccion) VALUES (?, 'sinc_local', '{}', 0)", (eid,))
    con.commit(); con.close()
    ruta = tmp / "respaldo.zip"
    with zipfile.ZipFile(ruta, "w") as z:
        z.write(db, f"data/empresas/empresa_{eid}.db")
        z.writestr("empresa.json", json.dumps({"id": eid, "nombre": "QA 431", "numero_id": cedula}))
    return ruta


def test_respaldo_que_viene_de_un_programa_pide_confirmar(monkeypatch, tmp_path):
    eid, t = _admin_empresa("-g11", "3101431014")
    ced = "3101431014"
    # señales: la marca de los programas 4.31, el registro sinc_local, o comprobantes de una terminal que no es de esta empresa en la web
    assert respaldo.viene_de_programa(eid, _zip_a_mano(tmp_path, eid, ced, sinc_local=True)) is True
    assert respaldo.viene_de_programa(eid, _zip_a_mano(tmp_path, eid, ced, docs=[("00100007040000000001", None)])) is True
    assert respaldo.viene_de_programa(eid, _zip_a_mano(tmp_path, eid, ced, docs=[("00100001040000000001", None)])) is False
    assert respaldo.viene_de_programa(eid, _zip_a_mano(tmp_path, eid, ced, docs=[("00100007040000000001", "Otro sistema QA")])) is False   # importados
    with Session(engine_empresa(eid)) as s:                                   # la terminal 7 es de una computadora de esta empresa
        sinc._escribir(s, eid, sinc.CLAVE_VINC, {"instalaciones": [], "retiradas": [{"terminal": 7, "nombre": "Caja vieja"}]}); s.commit()
    assert respaldo.viene_de_programa(eid, _zip_a_mano(tmp_path, eid, ced, docs=[("00100007040000000001", None)])) is False
    assert respaldo.viene_de_programa(eid, _respaldo_de(eid)) is False         # el suyo de la web
    # un respaldo hecho EN el programa lleva la marca; en la web se pide confirmar antes de restaurarlo
    with monkeypatch.context() as m:
        m.setattr(sinc, "MODO_LOCAL", True)
        del_programa = _respaldo_de(eid)
    with zipfile.ZipFile(del_programa) as z:
        assert json.loads(z.read("empresa.json"))["origen"] == "programa"
    assert respaldo.viene_de_programa(eid, del_programa) is True
    nombre = del_programa.name
    r = c.post(f"/api/respaldos/{nombre}/restaurar", headers=H(t), json={"confirmacion": "RESTAURAR"})
    assert r.status_code == 409 and r.json()["detail"] == {"codigo": "respaldo_programa", "mensaje": TEXTO_RESPALDO}, r.text
    r = c.post(f"/api/respaldos/{nombre}/restaurar", headers=H(t), json={"confirmacion": "RESTAURAR", "programa": True})
    assert r.status_code == 200 and r.json()["programa"] is True and r.json()["copiados"]["base"] == 1, r.text
    with Session(engine) as sc:
        fila = sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == "respaldo").order_by(Auditoria.id.desc())).first()
        assert "respaldo del programa de una computadora, confirmado" in fila.detalle
    # el programa restaura los suyos sin preguntar; la consola del administrador del sistema tampoco pregunta
    with monkeypatch.context() as m:
        m.setattr(sinc, "MODO_LOCAL", True)
        r = c.post(f"/api/respaldos/{nombre}/restaurar", headers=H(t), json={"confirmacion": "RESTAURAR"})
        assert r.status_code == 200 and r.json()["programa"] is False, r.text
    from app import main
    r = main._restaurar(_empresa(eid), eid, nombre, main.RestaurarIn(confirmacion="RESTAURAR"))
    assert r["programa"] is True and r["copiados"]["base"] == 1


# ================================================================================================================ textos
def test_textos_y_pantallas_de_la_16a():
    assert sinc.MENSAJES_WEB_CONEXION["datos_locales"] == TEXTO_WEB
    assert sinc.MENSAJES_LOCAL["datos_locales"] == TEXTO_PROGRAMA
    assert sinc.MENSAJE_SOLO_WEB_EMPRESA == "Se cambia en la página web ({web})."
    assert respaldo.MENSAJE_RESPALDO_PROGRAMA == TEXTO_RESPALDO
    assert set(sinc.CAMPOS_EMPRESA_WEB) >= set(CAMPOS_PANTALLA) and "sucursal" not in sinc.CAMPOS_EMPRESA_WEB
    s = (JS / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "const CAMPOS_WEB = [" + ", ".join(f"'{k}'" for k in CAMPOS_PANTALLA) + "];" in s
    assert "return 'Se cambia en la página web (' + (w || 'la página web') + ').';" in s
    assert "if (actual) { const a = cuerpoBase(actual, {}); out.antes = {}; for (const k of CAMPOS_WEB) out.antes[k] = a[k]; }" in s
    emp = s[s.index("const SecEmpresa = {"):s.index("const SecHacienda = {")]
    for campo in ("f.tipo_id", "f.numero_id", "f.nombre", "f.nombre_comercial", "f.telefono", "f.correo", "f.actividad", "f.provincia", "f.canton",
                  "f.distrito", "f.barrio", "f.otras_senas", "f.registro_fiscal_8707"):
        tramo = emp[emp.index(f'v-model="{campo}"') if f'v-model="{campo}"' in emp else emp.index(f'v-model.number="{campo}"'):]
        assert ':disabled="!!soloWeb"' in tramo[:tramo.index("</Field>")], campo
    assert "this.soloWeb = est && est.modo_local && est.vinculado ? textoSoloWeb(est.url) : '';" in emp
    hac = s[s.index("const SecHacienda = {"):s.index("const SecUsuarios = {")]
    for campo in ("f.ambiente", "f.proveedor_sistemas"):
        tramo = hac[hac.index(f'v-model="{campo}"'):]
        assert ':disabled="!!soloWeb"' in tramo[:tramo.index("</Field>")], campo
    assert ":style=\"soloWeb ? 'pointer-events:none;opacity:.55' : ''\"" in hac and '<p class="small muted" style="margin:6px 0 0" v-if="soloWeb">{{soloWeb}}</p>' in hac
    assert "this.soloWeb = est && est.modo_local && est.vinculado ? textoSoloWeb(est.url) : '';" in hac
    res = s[s.index("const SecRespaldos = {"):s.index("const SecExportar = {")]
    assert "e.detail.codigo === 'respaldo_programa' && programa !== true) { if (confirm(e.message)) this.confirmarRestaurar(true); return; }" in res
    assert "body: { confirmacion: x.texto, programa: programa === true }" in res and "(r.aviso ? '. ' + r.aviso : '')" in res
    for clave in ("sinc_conexion_bloqueada", "sinc_local_conexion_detenida"):
        assert clave + ": ['Seguridad', " in s
    cn = (JS / "pages" / "conectar.js").read_text(encoding="utf-8")
    assert "  bloqueada: '" + TEXTO_WEB + "'," in cn and "&& !this.bloqueada; }," in cn
    assert '<div class="alert err small" style="margin:0 0 10px" v-if="bloqueada">{{info.bloqueo || textoBloqueo}}</div>' in cn
    assert "textoBloqueo: FINALES.bloqueada" in cn
