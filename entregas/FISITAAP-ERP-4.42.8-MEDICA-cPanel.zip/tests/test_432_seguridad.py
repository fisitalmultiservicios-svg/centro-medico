"""4.32, bloque B2: seguridad del token de instalación en /api/sinc/datos* (plan §8).

Recorre lo que el token puede y lo que no puede nunca: ningún permiso nuevo; ninguna declaración nombra modelos o registros prohibidos;
tipos no declarados, pedidos (escribe="web"), cuentas de otro dueño, autoras ajenas, ids fuera de su rango, cajas nuevas y lo que tiene
lápida se rechazan; solo instalaciones de ESTA empresa; la cubeta propia es en memoria; un error nunca repite lo enviado."""
import json

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlmodel import Session

from app import auth, modulos, pedidos_programa, sinc_datos  # noqa: F401  (pedidos_programa declara «pedido» y «cuenta»)
from app import sinc_datos_decl  # noqa: F401
from app.db import Producto, engine_empresa, init_db
import pytest

from tests.test_432_mecanismo import CABYS, H, R, _cuerpo, _empresa, _instalacion, _lineas, _op, _prod, _sembrada

init_db()
_app = FastAPI()
_app.include_router(sinc_datos.router)
c = TestClient(_app)


@pytest.fixture(autouse=True)
def _encendido(monkeypatch):
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    yield


def _resultados(tok: str, *ops) -> list:
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=list(ops)))
    assert r.status_code == 200, r.text
    return r.json()["resultados"]


def test_el_token_no_gana_ningun_permiso():
    assert auth.PERMISOS_API == ("ver", "ver_todo", "facturar", "catalogos", "inventario", "cobros", "gastos", "contabilidad", "reportes", "documentos", "escribir")
    assert not {"pos", "configurar", "usuarios", "rrhh"} & set(auth.PERMISOS_API)


def test_ninguna_declaracion_nombra_lo_prohibido():
    for d in sinc_datos.DATOS.values():
        if d.tipo.startswith("zz_"):
            continue
        assert d.modelo is None or d.modelo.__name__ not in sinc_datos.MODELOS_PROHIBIDOS, d.tipo
        if d.registro is not None:
            assert d.registro not in sinc_datos.REGISTROS_PROHIBIDOS and not d.registro.startswith(("numeracion-", "rrhh_")), d.tipo
            assert d.registro not in ("sinc_vinculacion", "sinc_local", "empresa_extra", "equipo_impresion", "impuestos", "monedas"), d.tipo
            assert d.registro != "pos_espera" or d.escribe == "dueno", d.tipo
    for malo in (dict(modelo=auth.Usuario), dict(modelo=auth.TokenApi), dict(modelo=auth.Empresa), dict(registro="empresa_extra"),
                 dict(registro="rrhh_planilla"), dict(registro="numeracion-01"), dict(registro="equipo_impresion"), dict(registro="pos_espera")):
        with pytest.raises(ValueError):
            sinc_datos.declarar(sinc_datos.Dato("zz_prohibido", **malo))
    assert "zz_prohibido" not in sinc_datos.DATOS


def test_tipos_no_declarados_y_pedidos_se_rechazan_sin_tocar_nada():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    ops = [_op(1, "usuario", 1, "cambio", {"campos": {"es_superadmin": [[False], [True], "2026-11-13T00:00:00+00:00"]}}),
           _op(2, "empresa_extra", "_", "cambio", {"campos": {}}),
           _op(3, "sinc_vinculacion", "_", "alta", {"fila": {"instalaciones": []}}),
           _op(4, "pedido", 1, "cambio", {"campos": {"estado": [["nuevo"], ["entregado"], "2026-11-13T00:00:00+00:00"]}}),
           _op(5, "pedido", 1, "copia", {"fila": {"id": 1}})]
    assert [(x["estado"], x["motivo"]) for x in _resultados(tok, *ops)] == [("rechazado", "no_valido")] * 5


def test_solo_instalaciones_de_esta_empresa_y_autora_propia():
    eid, otra = _sembrada(), _sembrada()
    tok_otra = _instalacion(otra, terminal=2)
    tok = _instalacion(eid, terminal=2)
    # el token de una instalación de OTRA empresa no entra aquí: cada token tiene su empresa, y la ficha se busca en la suya
    from app.db import engine
    with Session(engine) as sc:
        t = sc.exec(text("SELECT empresa_id FROM tokenapi WHERE prefijo = :p").bindparams(p=tok_otra[:12])).first()
    assert t[0] == otra
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(autora="3.qa1234"))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "autora"
    for ruta, cuerpo in (("/api/sinc/datos", _cuerpo()), ("/api/sinc/datos/filas", {"refs": [{"tipo": "producto", "ref": "1"}]}),
                         ("/api/sinc/datos/accion", {"tipo": "_carga", "ref": "_", "accion": "reenlazar", "datos": {}})):
        assert c.post(ruta, json=cuerpo).status_code in (401, 403)
    # un token común de la empresa (sin ficha de instalación) no entra
    import secrets
    token = "fcr_" + secrets.token_urlsafe(32)
    with Session(engine) as sc:
        sc.add(auth.TokenApi(empresa_id=eid, usuario_id=auth.TOKEN_EMPRESA, nombre="Integración QA", prefijo=token[:12], hash=auth._hash_token_api(token),
                             permisos=json.dumps(["ver", "facturar", "catalogos"])))
        sc.commit()
    for ruta, cuerpo in (("/api/sinc/datos", _cuerpo()), ("/api/sinc/datos/filas", {"refs": [{"tipo": "producto", "ref": "1"}]})):
        assert c.post(ruta, headers=H(token), json=cuerpo).status_code == 403


def test_ids_fuera_de_su_rango_cajas_nuevas_y_lapidas_no_entran():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    muerto = _prod(eid, "Eliminado en la web")
    with Session(engine_empresa(eid)) as s:
        s.delete(s.get(Producto, muerto)); s.commit()
    fila = {"nombre": "Revive", "cabys": CABYS, "precio": 1}
    res = _resultados(tok, _op(1, "producto", muerto, "alta", {"fila": {**fila, "id": muerto}}),          # nada con lápida revive
                      _op(2, "producto", 3 * R + 1, "alta", {"fila": {**fila, "id": 3 * R + 1}}),         # rango de otra computadora
                      _op(3, "cliente", 5, "alta", {"fila": {"id": 5, "nombre": "Sin carga inicial", "tipo_id": "", "numero_id": ""}}),
                      _op(4, "categoria", 3 * R + 2, "alta", {"fila": {"nombre": "Ajena"}}),
                      _op(5, "caja", "terminales#9", "alta", {"fila": {"id": 9, "nombre": "Caja nueva"}}))
    assert [x["motivo"] for x in res] == ["eliminado", "no_valido", "no_valido", None, "no_valido"]
    assert res[3]["estado"] == "renumerar" and modulos.en_rango(int(res[3]["ref"]), 2)     # el elemento ajeno entra con un id de su rango
    with Session(engine_empresa(eid)) as s:
        assert s.get(Producto, muerto) is None and s.get(Producto, 3 * R + 1) is None
    assert [x["borrado"] for x in _lineas(eid, "producto") if x["ref"] == str(muerto)] == [True]


def test_cuenta_de_otro_dueno_no_se_escribe():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    res = _resultados(tok, _op(1, "cuenta", 3 * R + 1, "copia", {"fila": {"id": 3 * R + 1, "pedido_id": 4}}))
    assert res[0]["estado"] == "rechazado" and res[0]["motivo"] == "no_dueno"
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "pos_espera", None) in (None, [])
        assert s.execute(text("SELECT motivo FROM sinc_pisado")).scalars().all() == ["no_dueno"]


def test_cubeta_propia_en_memoria(monkeypatch):
    assert "sinc_datos" not in auth.CLAVES_PERSISTENTES                  # en memoria por proceso: ninguna fila en la base central por llamada
    monkeypatch.setattr(sinc_datos, "LIMITE_DATOS", (2, 300))
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    assert [c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo()).status_code for _ in range(3)] == [200, 200, 429]
    assert c.post("/api/sinc/datos/filas", headers=H(tok), json={"refs": [{"tipo": "producto", "ref": "1"}]}).status_code == 429


def test_un_error_nunca_repite_lo_enviado():
    eid = _empresa()
    tok = _instalacion(eid, terminal=2)
    secreto = "NO-REPETIR-9f3a"
    for cuerpo in ({**_cuerpo(), "protocolo": secreto}, {**_cuerpo(), "ops": [{"n": 1, "tipo": secreto * 3, "ref": "1", "op": "x"}]},
                   {**_cuerpo(), "reservar": {"producto": secreto}}):
        r = c.post("/api/sinc/datos", headers=H(tok), json=cuerpo)
        assert r.status_code == 400 and secreto not in r.text
    r = c.post("/api/sinc/datos/filas", headers=H(tok), json={"refs": [{"tipo": secreto, "ref": "1"}]})
    assert r.status_code == 400 and secreto not in r.text


def test_cada_operacion_queda_registrada_con_quien_y_lo_enviado():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    pid = _prod(eid, "Registrado")
    _resultados(tok, _op(1, "producto", pid, "cambio", {"campos": {"precio": [[1500, "CRC"], [1700, "CRC"], "2026-11-13T00:00:00+00:00"]}}),
                _op(2, "producto", pid, "baja", {}))
    with Session(engine_empresa(eid)) as s:
        filas = s.execute(text("SELECT autora, n, op, datos, por, estado FROM sinc_cambio ORDER BY n")).all()
    assert [(f[0], f[1], f[2], f[4], f[5]) for f in filas] == [("2.qa1234", 1, "cambio", "Caja 2 · Luis", "aplicado"), ("2.qa1234", 2, "baja", "Caja 2 · Luis", "aplicado")]
    assert json.loads(filas[0][3])["campos"]["precio"][1] == [1700, "CRC"] and json.loads(filas[1][3])["foto_web"]["precio"] == 1700


def test_rev_34_copia_de_cuenta_con_pedido_de_otra_computadora_no_entra():
    """Revisión n.º 34: la cuenta es del rango de la computadora 2, pero nombra un pedido que atiende la 3. Ni la copia ni su lápida
    entran (con ellas el seguimiento daría «entregado» a un pedido ajeno). Pedido suyo o con atiende 0: como antes."""
    from app import pedidos
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    pids = {}
    with Session(engine_empresa(eid)) as s:
        for clave, atiende in (("ajeno", 3), ("propio", 2), ("web", 0)):
            p = pedidos.Pedido(empresa_id=eid, numero=len(pids) + 1, token="t" * 20, nombre="Cliente QA", telefono="88880000",
                               estado="confirmado", atiende=atiende)
            s.add(p); s.commit(); s.refresh(p)
            pids[clave] = p.id
    res = _resultados(tok, _op(1, "cuenta", 2 * R + 1, "copia", {"fila": {"id": 2 * R + 1, "pedido_id": pids["ajeno"], "estado": "entregado"}}),
                      _op(2, "cuenta", 2 * R + 2, "copia", {"fila": {"id": 2 * R + 2, "pedido_id": pids["propio"]}}),
                      _op(3, "cuenta", 2 * R + 3, "copia", {"fila": {"id": 2 * R + 3, "pedido_id": pids["web"]}}))
    assert [(x["estado"], x["motivo"]) for x in res] == [("rechazado", "no_dueno"), ("aplicado", None), ("aplicado", None)]
    # la lápida de una copia que entró cuando el pedido era de la web, después de que lo atiende otra computadora, tampoco entra
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE pedido SET atiende = 3 WHERE id = :i"), {"i": pids["web"]}); s.commit()
    res = _resultados(tok, _op(4, "cuenta", 2 * R + 3, "copia", {"fila": None}))
    assert (res[0]["estado"], res[0]["motivo"]) == ("rechazado", "no_dueno")
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT motivo FROM sinc_pisado ORDER BY id")).scalars().all() == ["no_dueno", "no_dueno"]
        estados = pedidos.estado_efectivo(s, eid, [s.get(pedidos.Pedido, pids["ajeno"]), s.get(pedidos.Pedido, pids["web"])])
    assert estados == {pids["ajeno"]: "confirmado", pids["web"]: "en_preparacion"}
    vivas = {x["ref"]: x["borrado"] for x in _lineas(eid, "cuenta")}
    assert str(2 * R + 1) not in vivas and not vivas[str(2 * R + 2)] and not vivas[str(2 * R + 3)]


# ===================================================================================================================== hallazgo n.º 38
# Los casos de seguridad que ninguna prueba cubría (orden de valor: 8, 7, 10, 5, 6, 11, 3). Cada una falla si alguien quita la guarda.
def test_rev_38_8_comprobante_con_el_pedido_de_otra_computadora_no_lo_enlaza(monkeypatch):
    """El comprobante se guarda (es una venta real), pero solo enlaza el pedido que atiende la terminal de SU ficha (no la que dice el cuerpo)."""
    from sqlmodel import select
    from app import pedidos, sinc
    from app.db import Documento
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda e, pid, ev: None)
    eid = _sembrada()
    with Session(engine_empresa(eid)) as s:
        p = pedidos.Pedido(empresa_id=eid, numero=1, token="t" * 20, nombre="Cliente QA", telefono="88880000", estado="confirmado", atiende=3)
        s.add(p); s.commit(); s.refresh(p)
        pid = p.id
    clave = "".join(str((i * 7) % 10) for i in range(50))
    doc = {"clave": clave, "tipo_documento": "04", "consecutivo": "00100001040000000007", "fecha_emision": pedidos.ahora_cr().isoformat(timespec="seconds"),
           "estado": "interno", "total": 4520, "moneda": "CRC", "pedido": {"id": pid, "parcial": False}, "lineas": []}
    with Session(engine_empresa(eid)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid, [doc], "Caja 3 (dice el cuerpo)", terminal_ficha=2)
    assert recibidos == [clave] and not errores
    with Session(engine_empresa(eid)) as s:
        assert s.exec(select(Documento.pedido_id).where(Documento.clave == clave)).first() is None
        x = s.get(pedidos.Pedido, pid)
        assert x.estado == "confirmado" and x.documento_id is None


def test_rev_38_7_reservar_no_acepta_numeros_enormes_ni_mueve_una_reserva_hecha():
    from app import modulos as _m
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)                                    # la única instalación vigente
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(reservar={"producto": 400, "cliente": 10})).json()
    assert j["reservado"] == {"producto": {"max_dado": 0}, "cliente": {"max_dado": 0}}

    def ultimo(e, tabla):
        with Session(engine_empresa(e)) as s:
            return s.execute(text("SELECT ultimo FROM sinc_id_propio WHERE tabla = :t AND rango = 0").bindparams(t=tabla)).scalar() or 0
    assert (ultimo(eid, "producto"), ultimo(eid, "cliente")) == (400, 10)
    # un reintento con un número enorme (dentro del rango) no agranda la reserva ya hecha
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(reservar={"producto": _m.RANGO - 1})).json()
    assert j["reservado"]["producto"] == {"max_dado": 0} and ultimo(eid, "producto") == 400
    # un número enorme en una tabla sin reserva: no se reserva (la web se quedaría sin ids) y no se dice que se reservó
    otra = _sembrada()
    tok2 = _instalacion(otra, terminal=2)
    j = c.post("/api/sinc/datos", headers=H(tok2), json=_cuerpo(reservar={"producto": _m.RANGO - 1})).json()
    assert "producto" not in (j.get("reservado") or {})
    assert ultimo(otra, "producto") == 0


def test_rev_38_10_fe_tilopay_api_se_ignora_fuera_de_qa(monkeypatch):
    from app import pagos_online
    monkeypatch.setenv("FE_TILOPAY_API", "http://127.0.0.1:9999/api/v1/")
    monkeypatch.delenv("FE_ENTORNO", raising=False)
    assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY            # sin FE_ENTORNO=qa
    monkeypatch.setenv("FE_ENTORNO", "produccion")
    assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY
    monkeypatch.setenv("FE_ENTORNO", "qa")
    monkeypatch.setenv("FE_TILOPAY_API", "https://ajeno.example.test/api/v1/")     # qa, pero no es de esta máquina
    assert pagos_online.api_desde_entorno() == pagos_online.API_TILOPAY
    monkeypatch.setenv("FE_TILOPAY_API", "http://127.0.0.1:9999/api/v1")           # qa y local: se obedece
    assert pagos_online.api_desde_entorno() == "http://127.0.0.1:9999/api/v1/"


def test_rev_38_5_el_tope_del_cuerpo_vale_tambien_sin_content_length():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    cuerpo = json.dumps({**_cuerpo(), "relleno": "x" * (sinc_datos.MAX_BYTES + 10)}).encode("utf-8")

    def por_trozos():                                      # sin Content-Length: el cliente lo manda en trozos
        for i in range(0, len(cuerpo), 65536):
            yield cuerpo[i:i + 65536]
    r = c.post("/api/sinc/datos", headers={**H(tok), "Content-Type": "application/json"}, content=por_trozos())
    assert "content-length" not in {k.lower() for k in r.request.headers}
    assert r.status_code == 400 and r.json()["detail"]["codigo"] == "grande"


def test_rev_38_6_reenlazar_con_dos_computadoras_no_toca_lo_de_la_otra_ni_lo_de_antes_de_conectar():
    from sqlmodel import select
    from app.db import Cliente
    eid = _sembrada()
    tok2 = _instalacion(eid, terminal=2)
    _instalacion(eid, terminal=3)                          # dos instalaciones vigentes
    with Session(engine_empresa(eid)) as s:
        cli = Cliente(empresa_id=eid, nombre="Ana", tipo_id="", numero_id="")
        s.add(cli); s.commit(); s.refresh(cli)
        cid = cli.id
        for n, ref in ((1, "0:9:1730000000"), (2, "2:9:1730000000"), (3, "3:9:1730000000")):
            s.add(modulos.Pago(empresa_id=eid, numero=n, cliente_id=None, cliente_nombre="Ana", origen_sinc=ref, monto=1000))
        s.commit()
    cobros = [{"referencia": r, "cliente_id": cid} for r in ("0:9:1730000000", "2:9:1730000000", "3:9:1730000000")]
    r = c.post("/api/sinc/datos/accion", headers=H(tok2), json={"tipo": "_carga", "ref": "_", "accion": "reenlazar", "datos": {"cobros": cobros}})
    assert r.status_code == 200, r.text
    assert r.json()["resultado"]["cobros"] == 1
    with Session(engine_empresa(eid)) as s:
        assert {p.origen_sinc: p.cliente_id for p in s.exec(select(modulos.Pago)).all()} == {"0:9:1730000000": None, "2:9:1730000000": cid, "3:9:1730000000": None}


def test_rev_38_11_una_ficha_revocada_recibe_401_tambien_en_accion_y_filas():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    from app.db import engine
    with Session(engine) as sc:
        sc.exec(text("UPDATE tokenapi SET revocado = 1 WHERE prefijo = :p").bindparams(p=tok[:12])); sc.commit()
    for ruta, cuerpo in (("/api/sinc/datos/accion", {"tipo": "_carga", "ref": "_", "accion": "reenlazar", "datos": {}}),
                         ("/api/sinc/datos/filas", {"refs": [{"tipo": "producto", "ref": "1"}]}),
                         ("/api/sinc/datos", _cuerpo())):
        r = c.post(ruta, headers=H(tok), json=cuerpo)
        assert r.status_code == 401 and r.json()["detail"]["codigo"] == "instalacion_revocada", (ruta, r.text)


def test_rev_38_3_con_el_plan_vencido_reenlazar_sigue_y_las_demas_acciones_no(monkeypatch):
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    monkeypatch.setattr(sinc_datos, "_plan_vencido", lambda ctx: True)
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "_carga", "ref": "_", "accion": "reenlazar", "datos": {}})
    assert r.status_code == 200, r.text
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "pedido", "ref": "1", "accion": "aceptar", "datos": {}})
    assert r.status_code == 409 and sinc_datos.PLAN_VENCIDO_ACCION in r.text
