# -*- coding: utf-8 -*-
"""4.39 (frente B), soporte de un restaurante (16 nov 2026) y Norman: «todas las pantallas deberían tener el botón atrás». Botón «← Atrás»
al principio de la barra de migas del ERP y de Ventas en línea (vuelve con el historial; sin pantalla anterior, al inicio; el cajero solo a
donde puede entrar), y la caja de restaurante sin mesas nunca muestra el plano vacío."""
import json
import re
import shutil
import subprocess

import pytest

from tests.test_424_etiquetas import COMPILAR_JS
from tests.test_425_ultimos_pantallas import JS, _js, _nodo, _tramo


def _metodo(t, firma):
    return _tramo(t, "    " + firma, "\n    },") + "\n    }"


def _correr(tmp_path, guion):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


BOTON = 'class="atras-btn" v-if="puedeAtras" title="Volver a la pantalla anterior" aria-label="Volver a la pantalla anterior" @click="atras">← Atrás</button>'


def test_el_boton_esta_al_principio_de_las_dos_barras_y_con_su_condicion():
    erp, fis = _js("app.js"), _js("fis/app.js")
    assert '<div class="breadcrumb"><div class="hstack"><button type="button" ' + BOTON + '<button type="button" @click="go(sesion.inicio' in erp
    assert '<div class="breadcrumb"><div class="hstack"><button type="button" ' + BOTON + '<a href="/app/#/inicio">Mi espacio</a>' in fis
    assert "puedeAtras() { return this.path !== '/inicio' && this.path !== (sesion.inicio || '/inicio'); }" in erp
    assert "puedeAtras() { return this.estado.ruta !== 'resumen' || !!this.sesion.modoCajero; }" in fis   # revisión: el cajero también en Pedidos
    for t in (erp, fis):
        assert "marcarPaso()" in t and "atras()" in t and "history.back()" in t
    css = (JS.parent / "ui.css").read_text(encoding="utf-8")
    cfis = (JS.parent / "fisitaap" / "fis.css").read_text(encoding="utf-8")
    assert ".breadcrumb .atras-btn{" in css and ".breadcrumb .atras-btn{" in cfis


GUION_ATRAS = """
const sesion = %(sesion)s;
const rutaPermitida = r => !!sesion.permitidas && sesion.permitidas.includes(r);
const decodificarRuta = r => decodeURIComponent(r);
const mk = (hash, pila, largo, extra, referrer) => {
  const eventos = [];
  globalThis.location = { hash, origin: 'http://127.0.0.1:8000', href: '' };
  globalThis.document = { referrer: referrer || '' };
  globalThis.history = { length: largo, back() { eventos.push('back'); } };
  const vm = Object.assign({ pila, go(to) { eventos.push('go ' + to); } }, extra || {});
  const M = { %(metodos)s };
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return { vm, eventos };
};
%(cuerpo)s
"""


def _metodos_atras(t):
    return ",\n".join([_metodo_o_linea(t, "marcarPaso() {"), _metodo(t, "atras() {")])


def _metodo_o_linea(t, firma):
    return _tramo(t, "    " + firma, "\n").strip().rstrip(",").split("   /*")[0]


def test_atras_del_erp_historia_corta_larga_y_modo_cajero(tmp_path):
    t = _js("app.js")
    metodos = _metodos_atras(t)
    cuerpo = """
const r = {};
let x = mk('#/contactos', ['#/contactos'], 1); x.vm.atras(); r.sola = x.eventos;
x = mk('#/contactos', ['#/inicio', '#/contactos'], 5); x.vm.atras(); r.dos = x.eventos;
x = mk('#/contactos', ['#/inicio', '#/contactos'], 1); x.vm.atras(); r.historia1 = x.eventos;
sesion.inicio = '/tike/tablero'; x = mk('#/contactos', ['#/contactos'], 3); x.vm.atras(); r.inicioRol = x.eventos; sesion.inicio = '';
x = mk('#/a', ['#/a'], 2); location.hash = '#/b'; x.vm.marcarPaso(); location.hash = '#/c'; x.vm.marcarPaso(); r.pila1 = [...x.vm.pila];
location.hash = '#/b'; x.vm.marcarPaso(); r.pila2 = [...x.vm.pila]; location.hash = '#/b'; x.vm.marcarPaso(); r.pila3 = [...x.vm.pila];
sesion.modoCajero = true;
let y = mk('#/pos/ventas', ['#/contactos', '#/pos/ventas'], 4); y.vm.atras(); r.prohibida = y.eventos;
y = mk('#/pos/ventas', ['#/pos/caja', '#/pos/ventas'], 4); y.vm.atras(); r.permitida = y.eventos;
y = mk('#/pos/ventas', ['#/pos/ventas'], 4); y.vm.atras(); r.cajeroSola = y.eventos;
console.log(JSON.stringify(r));
"""
    s = {"modoCajero": False, "inicio": "", "permitidas": ["/pos/caja"]}
    r = _correr(tmp_path, GUION_ATRAS % {"sesion": json.dumps(s), "metodos": metodos, "cuerpo": cuerpo})
    assert r["sola"] == ["go /inicio"] and r["historia1"] == ["go /inicio"]
    assert r["dos"] == ["back"] and r["inicioRol"] == ["go /tike/tablero"]
    assert r["pila1"] == ["#/a", "#/b", "#/c"] and r["pila2"] == ["#/a", "#/b"] and r["pila3"] == ["#/a", "#/b"]
    assert r["prohibida"] == ["go /pos/caja"] and r["permitida"] == ["back"] and r["cajeroSola"] == ["go /pos/caja"]


def _metodos_atras_fis(t):
    vino = _tramo(t, "    vieneDelSistema() {", "\n").split("   /*")[0].strip().rstrip(",")
    return _metodos_atras(t) + ",\n" + vino


def test_atras_de_ventas_en_linea_historia_corta_larga_y_modo_cajero(tmp_path):
    """Revisión 4.39: el cajero tiene «Atrás» también en Pedidos y, sin pantalla anterior en esta página, vuelve a la caja; si se llegó desde
    el sistema (la caja u otra pantalla de /app/, con history.length > 1) se vuelve allá con el historial, sea cajero o dueño."""
    t = _js("fis/app.js")
    metodos = _metodos_atras_fis(t)
    puede = _tramo(t, "    puedeAtras() {", "\n").split("   /*")[0].strip().rstrip(",")
    cuerpo = """
const r = {};
const sin = { modoCajero: false }, caj = { modoCajero: true };
const ERP = 'http://127.0.0.1:8000/app/', FIS = 'http://127.0.0.1:8000/app/fisitaap/', OTRO = 'https://otro.example.test/app/';
const ir = () => location.href || location.hash;
let x = mk('#/pedidos', ['#/pedidos'], 1, { sesion: sin }); x.vm.atras(); r.sola = [x.eventos, ir()];
x = mk('#/pedidos', ['#/resumen', '#/pedidos'], 6, { sesion: sin }); x.vm.atras(); r.dos = x.eventos;
x = mk('#/pedidos', ['#/campanas', '#/pedidos'], 6, { sesion: caj }, ERP); x.vm.atras(); r.cajeroProhibida = [x.eventos, ir()];
x = mk('#/pedido/5', ['#/pedidos', '#/pedido/5'], 6, { sesion: caj }); x.vm.atras(); r.cajeroDetalle = x.eventos;
x = mk('#/pedido/5', ['#/pedido/5'], 6, { sesion: caj }); x.vm.atras(); r.cajeroSola = [x.eventos, ir()];
/* llegada desde la caja (/app/#/pos/caja → «Ver todos en Ventas en línea › Pedidos»): el historial la tiene detrás */
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: caj }, ERP); x.vm.atras(); r.cajeroDesdeCaja = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: sin }, ERP); x.vm.atras(); r.duenoDesdeCaja = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: sin }, 'http://127.0.0.1:8000/app/index.html'); x.vm.atras(); r.duenoIndex = x.eventos;
/* sin historial (pestaña nueva), desde Ventas en línea misma o desde otro sitio: no se usa el historial */
x = mk('#/pedidos', ['#/pedidos'], 1, { sesion: caj }, ERP); x.vm.atras(); r.cajeroPestanaNueva = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: sin }, FIS); x.vm.atras(); r.duenoDesdeFis = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: sin }, 'http://127.0.0.1:8000/app/fisitaap'); x.vm.atras(); r.duenoDesdeFis2 = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: caj }, OTRO); x.vm.atras(); r.cajeroDesdeOtro = [x.eventos, ir()];
x = mk('#/pedidos', ['#/pedidos'], 5, { sesion: sin }, 'no es una dirección'); x.vm.atras(); r.duenoRaro = [x.eventos, ir()];
/* el botón (computada real): no en la portada del dueño; el cajero lo tiene también en Pedidos */
const P = { %(puede)s };
const boton = (ruta, sesion) => P.puedeAtras.call({ estado: { ruta }, sesion });
r.boton = { cajeroPedidos: boton('pedidos', caj), cajeroDetalle: boton('pedido', caj), duenoResumen: boton('resumen', sin), duenoPedidos: boton('pedidos', sin), sinSesion: boton('pedidos', {}) };
console.log(JSON.stringify(r));
""" % {"puede": puede}
    r = _correr(tmp_path, GUION_ATRAS % {"sesion": "{}", "metodos": metodos, "cuerpo": cuerpo})
    caja = "/app/#/pos/caja"
    assert r["sola"] == [[], "#/resumen"] and r["dos"] == ["back"]
    assert r["cajeroProhibida"] == [[], caja] and r["cajeroDetalle"] == ["back"] and r["cajeroSola"] == [[], caja]
    assert r["cajeroDesdeCaja"] == [["back"], "#/pedidos"] and r["duenoDesdeCaja"] == [["back"], "#/pedidos"] and r["duenoIndex"] == ["back"]
    assert r["cajeroPestanaNueva"] == [[], caja] and r["cajeroDesdeOtro"] == [[], caja]
    assert r["duenoDesdeFis"] == [[], "#/resumen"] and r["duenoDesdeFis2"] == [[], "#/resumen"] and r["duenoRaro"] == [[], "#/resumen"]
    assert r["boton"] == {"cajeroPedidos": True, "cajeroDetalle": True, "duenoResumen": False, "duenoPedidos": True, "sinSesion": True}


GUION_VISTAS = """
import { readFileSync } from 'node:fs';
const src = readFileSync(process.argv[2], 'utf8');
const trozos = [/export const FORMAS_DECO[^\\n]*\\n/, /export function esDeco[^\\n]*\\n/, /export function vistaInicial[^]*?\\n}\\n/, /export function vistaTrasCobro[^]*?\\n}\\n/, /export function sinMesas[^\\n]*\\n/]
  .map(re => { const m = re.exec(src); if (!m) throw new Error('falta ' + re); return m[0].replace(/^export /, ''); });
const f = new Function(trozos.join('\\n') + '\\nreturn { vistaInicial, vistaTrasCobro, sinMesas };')();
const mesa = { id: 1, nombre: 'M1', forma: 'cuadrada' }, deco = { id: 2, deco: true, forma: 'planta' };
const rest = (inicio, mesas) => ({ modo: 'restaurante', inicio, mesas });
const out = { };
for (const [n, mesas] of [['vacia', []], ['sinCampo', undefined], ['soloDeco', [deco]], ['conMesas', [mesa, deco]]]) {
  out[n] = { mesas: ['mesas', 'venta', 'preguntar', undefined].map(i => f.vistaInicial(rest(i, mesas))),
    tras: [f.vistaTrasCobro(rest('mesas', mesas), true), f.vistaTrasCobro(rest('mesas', mesas), false), f.vistaTrasCobro(rest('preguntar', mesas), true)], tiene: f.sinMesas(rest('mesas', mesas)) };
}
out.mostrador = [f.vistaInicial({ modo: 'mostrador', mesas: [] }), f.vistaInicial({ modo: 'mostrador', mesas: [mesa] }), f.vistaTrasCobro({ modo: 'mostrador' }, false), f.vistaInicial(null)];
console.log(JSON.stringify(out));
"""


def test_vista_inicial_y_tras_cobro_con_y_sin_mesas(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "v.mjs").write_text(GUION_VISTAS, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "v.mjs"), str(JS / "pages" / "pos" / "_datos.js")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    for n in ("vacia", "soloDeco"):
        assert o[n]["mesas"] == ["venta"] * 4 and o[n]["tras"] == ["venta"] * 3 and o[n]["tiene"] is True, n
    assert o["sinCampo"]["mesas"] == ["mesas", "venta", "elegir", "mesas"] and o["sinCampo"]["tiene"] is False   # configuración muy vieja: como antes
    assert o["conMesas"]["mesas"] == ["mesas", "venta", "elegir", "mesas"]
    assert o["conMesas"]["tras"] == ["mesas", "mesas", "elegir"] and o["conMesas"]["tiene"] is False
    assert o["mostrador"] == ["venta", "venta", "venta", "venta"]


def _linea_caja(t, firma):
    return _tramo(t, "    " + firma, "\n").split("   /*")[0].split("   //")[0].strip().rstrip(",")


GUION_SALIR = """
const avisos = [], foco = []; globalThis.toast = m => avisos.push(m); globalThis.uuid = () => 'u';
let respuesta = true; globalThis.confirm = () => respuesta; globalThis.mock = { puedeGuardar: () => true };
const C = { %(computadas)s }, M = { %(metodos)s };
function caja(mesas, estado) {
  const vm = Object.assign({ esRestaurante: true, lineas: [], esperaId: null, nombreEspera: '', nota: '', mesaActual: null, cfg: { cliente_defecto_id: 1, mesas }, clienteId: null,
    vista: 'venta', rapida: false, idem: 'x', parteNueva: true, servicioPctCuenta: 1, cobroParcial: null, guardadas: 0,
    $nextTick(f) { f(); }, $refs: { buscar: { focus() { foco.push(1); } } }, descartarVacia() {}, persistirCuenta() { this.guardadas++; } }, estado || {});
  for (const [n, f] of Object.entries(C)) Object.defineProperty(vm, n, { get: f.bind(vm) });
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const esDeco = m => !!(m && m.deco);
const foto = c => ({ vista: c.vista, rapida: c.rapida, esVentaRapida: c.esVentaRapida, mesa: c.mesaActual, espera: c.esperaId, lineas: c.lineas.length, guardadas: c.guardadas, avisos: avisos.splice(0), foco: foco.splice(0).length });
const r = {};
%(cuerpo)s
console.log(JSON.stringify(r));
"""


def _guion_salir(t, cuerpo):
    computadas = ",\n".join(_linea_caja(t, n + "() {") for n in ("esVentaRapida", "mesas"))
    metodos = ",\n".join([_metodo(t, "volverAMesas(sinPreguntar) {"), _metodo(t, "ventaRapida() {"), _linea_caja(t, "ventaSinMesa() {")])
    return GUION_SALIR % {"computadas": computadas, "metodos": metodos, "cuerpo": cuerpo}


def test_volver_a_mesas_sin_mesas_deja_la_venta_rapida_y_con_mesas_el_plano(tmp_path):
    """Las salidas solas (guardar, vaciar, cuenta cerrada: sinPreguntar) de una caja sin mesas quedan en la venta rápida. Revisión: si la
    persona toca «🍽 Mesas», se abre el plano (tarjeta «Sin mesas» con «⚡ Venta rápida», y la barra con Turno, Fiados, Tarjeta...), sin aviso."""
    t = _js("pages/pos/caja.js")
    metodo = _metodo(t, "volverAMesas(sinPreguntar) {")
    assert "if (sinPreguntar && Array.isArray(this.mesas) && !this.mesas.length) { this.vista = 'venta'; this.rapida = true; }" in metodo
    assert "toast('Esta caja no tiene mesas" not in t
    cuerpo = """
let c = caja([], { mesaActual: { nombre: 'M' } }); c.volverAMesas(true); r.vaciaSola = foto(c);
c = caja([]); c.volverAMesas(false); r.vaciaBoton = foto(c);
c = caja([{ deco: true }], { esperaId: 3 }); c.volverAMesas(true); r.deco = foto(c);
c = caja([{ id: 1, nombre: 'M1' }], { mesaActual: { nombre: 'M1' } }); c.volverAMesas(true); r.mesasSola = foto(c);
c = caja([{ id: 1, nombre: 'M1' }], { mesaActual: { nombre: 'M1' } }); c.volverAMesas(false); r.mesasBoton = foto(c);
"""
    r = _correr(tmp_path, _guion_salir(t, cuerpo))
    assert r["vaciaSola"] == {"vista": "venta", "rapida": True, "esVentaRapida": True, "mesa": None, "espera": None, "lineas": 0, "guardadas": 0, "avisos": [], "foco": 0}
    assert r["vaciaBoton"]["vista"] == "mesas" and r["vaciaBoton"]["avisos"] == []          # el plano con la tarjeta «Sin mesas»
    assert r["deco"]["vista"] == "venta" and r["deco"]["rapida"] is True and r["deco"]["espera"] is None
    assert r["mesasSola"]["vista"] == "mesas" and r["mesasSola"]["rapida"] is False and r["mesasBoton"]["vista"] == "mesas"


def test_venta_rapida_en_caja_sin_mesas_sin_aviso_y_con_el_cursor_en_la_busqueda(tmp_path):
    """Revisión 4.39 (hallazgo 4): tocar «⚡ Venta rápida» con una cuenta recuperada en una caja sin mesas ya no muestra el aviso de «no tiene
    mesas»: guarda la cuenta como siempre, deja la venta rápida lista y pone el cursor en la búsqueda. Si la persona no confirma salir de
    una venta sin guardar, se queda donde estaba. Con mesas, igual que antes."""
    t = _js("pages/pos/caja.js")
    cuerpo = """
const plato = { detalle: 'Casado', cantidad: 1, enviado: '2026-11-16T12:00:00Z' };
let c = caja([], { esperaId: 3, nombreEspera: 'Cuenta 3', lineas: [plato] }); c.ventaRapida(); r.recuperada = foto(c);
c = caja([], { rapida: false }); c.ventaRapida(); r.sinCuenta = foto(c);
respuesta = false; c = caja([], { lineas: [{ detalle: 'Café', cantidad: 1 }] }); c.ventaRapida(); r.noConfirma = foto(c); respuesta = true;
c = caja([{ id: 1, nombre: 'M1' }], { mesaActual: { nombre: 'M1' }, esperaId: 4, lineas: [plato] }); c.ventaRapida(); r.conMesas = foto(c);
c = caja([], { vista: 'mesas' }); c.ventaRapida(); r.desdePlano = foto(c);
"""
    r = _correr(tmp_path, _guion_salir(t, cuerpo))
    lista = {"vista": "venta", "rapida": True, "esVentaRapida": True, "mesa": None, "espera": None, "lineas": 0}
    assert {k: r["recuperada"][k] for k in lista} == lista and r["recuperada"]["guardadas"] == 1, r["recuperada"]
    assert r["recuperada"]["avisos"] == [] and r["recuperada"]["foco"] == 1
    assert {k: r["sinCuenta"][k] for k in lista} == lista and r["sinCuenta"]["avisos"] == [] and r["sinCuenta"]["foco"] == 1
    assert r["noConfirma"]["vista"] == "venta" and r["noConfirma"]["lineas"] == 1 and r["noConfirma"]["esVentaRapida"] is False and r["noConfirma"]["foco"] == 0
    assert {k: r["conMesas"][k] for k in lista} == lista and r["conMesas"]["guardadas"] == 1 and r["conMesas"]["avisos"] == []
    assert {k: r["desdePlano"][k] for k in lista} == lista and r["desdePlano"]["foco"] == 1


GUION_TRAS_COBRO = """
import { readFileSync } from 'node:fs';
globalThis.document = { createElement: () => ({}) };
const V = await import('./vue.mjs');
const datos = readFileSync(process.argv[2], 'utf8');
const trozos = [/export const FORMAS_DECO[^\\n]*\\n/, /export function esDeco[^\\n]*\\n/, /export function vistaInicial[^]*?\\n}\\n/, /export function vistaTrasCobro[^]*?\\n}\\n/, /export function sinMesas[^\\n]*\\n/]
  .map(re => { const m = re.exec(datos); if (!m) throw new Error('falta ' + re); return m[0].replace(/^export /, ''); });
const { esDeco, vistaInicial, vistaTrasCobro } = new Function(trozos.join('\\n') + '\\nreturn { esDeco, vistaInicial, vistaTrasCobro };')();
const C = { %(computadas)s };
const W = { %(vigia)s };
const condicion = function () { return %(condicion)s; };
/* la caja con la reactividad de Vue: datos, computadas reales y el vigía real (watch) sobre ventaLibreSinMesas */
function caja(cfg) {
  const crudo = { cfg, vista: vistaInicial(cfg), rapida: true, mesaActual: null, esperaId: null, nombreEspera: '', lineas: [], cobroParcial: null, destinoDe: () => 'cocina' };
  for (const [n, f] of Object.entries(C)) Object.defineProperty(crudo, n, { get() { return f.call(this); }, enumerable: false });
  const vm = V.reactive(crudo);
  V.watch(() => vm.ventaLibreSinMesas, (v, a) => W.ventaLibreSinMesas.call(vm, v, a));
  return vm;
}
const recuperar = (vm, id, mesa) => { vm.esperaId = id; vm.nombreEspera = 'Cuenta ' + id; vm.mesaActual = mesa || null; vm.lineas = [{ detalle: 'Casado', cantidad: 1, enviado: '2026-11-16T12:00:00Z' }]; vm.rapida = false; vm.vista = 'venta'; };   /* como cargarCuenta / abrirMesa */
const cobrar = vm => { const rapida = vm.esVentaRapida; vm.lineas = []; vm.esperaId = null; vm.nombreEspera = ''; vm.mesaActual = null; vm.cobroParcial = null; vm.vista = vistaTrasCobro(vm.cfg, rapida); };   /* lo que limpian emitirCobro, cargarAHabitacion y ventaSinConexion */
const siguiente = vm => { vm.lineas = [{ detalle: 'Casado', cantidad: 1 }, { detalle: 'Arroz', cantidad: 2 }]; };
const foto = vm => ({ vista: vm.vista, rapida: vm.rapida, esVentaRapida: vm.esVentaRapida, enMesas: vm.enMesas });
const r = {};
const rest = mesas => ({ modo: 'restaurante', inicio: 'venta', mesas });
/* 1) sin mesas: cuenta recuperada (o pedido o «Abrir para cobrar»), cobro y siguiente cliente */
let vm = caja(rest([])); await V.nextTick(); r.entrada = foto(vm);
recuperar(vm, 3); await V.nextTick(); r.recuperada = foto(vm);
cobrar(vm); await V.nextTick(); r.trasCobro = foto(vm);
siguiente(vm); r.comandaSiguiente = condicion.call(vm);
/* 2) sin mesas, cobro de una parte de la cuenta: mientras se cobra la parte no cambia nada; al terminar, la venta rápida */
vm = caja(rest([{ id: 9, deco: true, forma: 'planta' }])); recuperar(vm, 4); await V.nextTick();
vm.esperaId = null; vm.cobroParcial = { cuentaId: 4, parte: 1, de: 2 }; await V.nextTick(); r.parte = foto(vm);
cobrar(vm); await V.nextTick(); r.parteCobrada = foto(vm); siguiente(vm); r.parteComanda = condicion.call(vm);
/* 3) con mesas: una mesa cobrada vuelve al plano como siempre y la marca no cambia */
vm = caja(rest([{ id: 1, nombre: 'M1', forma: 'cuadrada' }])); recuperar(vm, 5, { id: 1, nombre: 'M1' }); await V.nextTick();
cobrar(vm); await V.nextTick(); r.conMesas = foto(vm);
/* 4) mostrador: nada cambia */
vm = caja({ modo: 'mostrador', mesas: [] }); vm.rapida = false; await V.nextTick(); vm.esperaId = 7; await V.nextTick(); vm.esperaId = null; await V.nextTick(); r.mostrador = foto(vm);
console.log(JSON.stringify(r));
"""


def test_caja_sin_mesas_despues_de_cobrar_una_cuenta_recuperada_sigue_en_venta_rapida(tmp_path):
    """Revisión 4.39 (hallazgo 1): en una caja de restaurante sin mesas, después de cobrar una cuenta recuperada (rapida = false) la venta
    siguiente es venta rápida y vuelve a mandar la comanda al cobrar (condición real de la 4.29). Con la reactividad de Vue: computadas reales
    de caja.js y el vigía real; vistaInicial y vistaTrasCobro reales de _datos.js. Con mesas y en mostrador, igual que antes."""
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    t = _js("pages/pos/caja.js")
    computadas = ",\n".join(_linea_caja(t, n + "() {") for n in ("esRestaurante", "esVentaRapida", "enMesas", "ventaLibreSinMesas", "mesas"))
    vigia = _linea_caja(_tramo(t, "  watch: {", "  methods: {"), "ventaLibreSinMesas(v) {")
    assert vigia == "ventaLibreSinMesas(v) { if (v) this.rapida = true; }"
    m = re.search(r"if \((this\.esRestaurante && \(this\.esVentaRapida \|\| this\.cuentaRapidaGuardada\) && [^\n]*?)\) \{\n", _metodo(t, "async emitirCobro(otra) {"))   # 4.39: también la cuenta guardada sin mesa
    assert m, "falta la condición de la comanda al cobrar (4.29)"
    # el vigía depende de que los tres cobros dejen la venta sin cuenta cargada antes de elegir la vista
    for firma, hasta in (("    async emitirCobro(otra) {", "\n    },"), ("    cargarAHabitacion() {", "    comandaHab(r, lineas, t) {"), ("    ventaSinConexion(c) {", "    docProvisional(v) {")):
        cuerpo = _tramo(t, firma, hasta)
        assert "this.esperaId = null;" in cuerpo and "this.mesaActual = null;" in cuerpo and "vistaTrasCobro(this.cfg, rapida)" in cuerpo, firma
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    guion = GUION_TRAS_COBRO % {"computadas": computadas, "vigia": vigia, "condicion": m.group(1)}
    (tmp_path / "tras.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, "tras.mjs", str(JS / "pages" / "pos" / "_datos.js")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    rapida = {"vista": "venta", "rapida": True, "esVentaRapida": True, "enMesas": False}
    assert o["entrada"] == rapida
    assert o["recuperada"] == {"vista": "venta", "rapida": False, "esVentaRapida": False, "enMesas": True}   # la cuenta recuperada, como antes
    assert o["trasCobro"] == rapida and o["comandaSiguiente"] is True                                    # antes: rapida false y sin comanda
    assert o["parte"] == {"vista": "venta", "rapida": False, "esVentaRapida": False, "enMesas": True}
    assert o["parteCobrada"] == rapida and o["parteComanda"] is True
    assert o["conMesas"] == {"vista": "mesas", "rapida": False, "esVentaRapida": False, "enMesas": True}
    assert o["mostrador"]["rapida"] is False


def test_caja_sin_mesas_tiene_turno_fiados_tarjeta_y_la_caja_en_la_barra_de_venta():
    """Revisión 4.39 (hallazgo 2): el restaurante sin mesas ya no pasa por el plano, así que «Fiados», «🎁 Tarjeta», «Turno» y el selector de
    caja también salen en la barra de la venta. Mostrador y restaurante con mesas, como antes (el «🧾 Ventas» no se repite)."""
    t = _js("pages/pos/caja.js")
    venta = t.split("<!-- pantalla de venta -->", 1)[1].split('<div class="pos-cats">', 1)[0]
    grupo = _tramo(venta, '<template v-if="caja && esRestaurante && !mesas.length">', "</template>")
    assert '<button class="btn sm ghost" v-if="cfg.fiado !== false" @click="abrirFiados"' in grupo
    assert '@click="abrirRegalo"' in grupo and '@click="abrirTurno"' in grupo and "modalVentas" not in grupo
    assert '<template v-if="caja && !esRestaurante">' in venta                                            # el de mostrador sigue igual
    assert '<select class="inp" v-if="terminalesLista.length>1 && (!esRestaurante || !mesas.length)" :value="cfg.id"' in venta
    plano = _tramo(t, """<div v-show="esRestaurante && vista==='mesas'">""", "<!-- pantalla de venta -->")
    vacio = _tramo(plano, '<Empty icon="🍽" title="Sin mesas"', "</Empty>")
    assert '<button class="btn" @click="ventaRapida" data-sin-mesas-venta>⚡ Venta rápida</button>' in vacio
    for accion in ('@click="abrirFiados"', '@click="abrirRegalo"', '@click="abrirTurno"'):
        assert accion in plano, accion


def test_las_plantillas_de_app_fis_app_y_caja_compilan(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    for nombre, partes in {"app.js": ("app.js",), "fis-app.js": ("fis", "app.js"), "caja.js": ("pages", "pos", "caja.js")}.items():
        (tmp_path / nombre).write_text(JS.joinpath(*partes).read_text(encoding="utf-8"), encoding="utf-8")
    r = subprocess.run([node, "compilar.mjs", "app.js", "fis-app.js", "caja.js"], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-2000:]
    out = json.loads(r.stdout)
    for ruta, plantillas in out.items():
        assert plantillas, ruta
        for p in plantillas:
            assert p["errores"] == [] and p["desbalance"] == [], (ruta, p)
