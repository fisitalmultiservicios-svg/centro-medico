# -*- coding: utf-8 -*-
"""Validación 4.32, bloque «pantallas y banderas del programa» (f1). Copias de las pruebas de reproducción de la segunda validación
(proyecto432_val/tests/test_val_*.py), con el mismo contenido; solo se renombraron los nombres repetidos entre archivos. La contraprueba
del programa de test_val_pantallas_r1 se ajustó al hallazgo «Entregar y Marcar entregado en el programa» (allá ya no se ofrecen).
Al final, las pruebas propias de este bloque."""
import pathlib
import re

from sqlmodel import Session

from app import comandas
from app import sinc_datos_programa as sdp
from app.db import engine_empresa
from tests.test_425_ultimos_pantallas import JS, _js, _node
from tests.test_431_estacion_pantallas import BASE
from tests.test_432_pantallas_pedidos import MONTAR_PED, _falsos
from tests.test_432_pedidos import (_Respuesta, _ctx, _cuentas_de, _estado, _fila_pedido, _llega, _sin_limite_por_ip, prog)  # noqa: F401

# ==================================================================================================== copia de test_val_pantallas_r1.py
# """SEGUNDA VALIDACIÓN 4.32 (pantallas), hallazgo 1: en la PÁGINA WEB, Ventas en línea › Pedidos perdió «Abrir monitor», «Marcar entregado»,
# «Asignar a Express» y «Entregar».
# 
# A diferencia de la prueba del primer validador (que dibuja la plantilla sobre un objeto escrito a mano), aquí se monta el componente DE VERDAD
# (sus datos, sus computadas y sus métodos: enProg, enWeb, lejos, entregas, filas…) sobre la sesión falsa de las pruebas del proyecto y se dibuja
# SU plantilla con el Vue del proyecto. Así no queda duda de que el resultado sale del código que se entrega y no del objeto de la prueba.
# 
# Causa: el arreglo de esta noche envolvió «Aceptar» en `<template v-if="!enProg || f.estado === 'nuevo'">`; los cuatro botones siguientes
# cuelgan de ese `v-if` con `v-else-if`, y en la web `!enProg` siempre es verdadero: la cadena nunca se evalúa."""
GUION_P1 = BASE + MONTAR_PED + r"""
const dec = s => String(s).replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
globalThis.document = { hidden: false, createElement() { let raw = ''; return { set innerHTML(v) { raw = String(v); }, get textContent() { return dec(raw); }, get children() { const m = /^<div foo="([\s\S]*)">$/.exec(raw); return [{ getAttribute: () => dec(m ? m[1] : '') }]; } }; } };
const Vue = await import('./js/vendor/vue.esm-browser.prod.min.js');
const dibujar = Vue.compile(P.template);                                          // la plantilla del componente que se entrega
const ped = (id, estado, extra) => ({ id, numero: id, nombre: 'Cliente ' + id, total: 1000, estado, estado_nombre: estado, tipo: 'recoger', creado: '2026-11-13T10:' + (10 + id), ...(extra || {}) });
function botones(info, extraSesion) {
  sesionPara(info, extraSesion);
  const vm = montar();
  vm.pedidos = [ped(1, 'nuevo'), ped(2, 'confirmado', { cuenta_espera_id: 102 }), ped(3, 'en_preparacion', { cuenta_espera_id: 103 }), ped(4, 'listo', { cuenta_espera_id: 104 }),
    ped(5, 'listo', { tipo: 'domicilio', cuenta_espera_id: 105, entrega: { id: 9, estado: 'pendiente', estado_nombre: 'Pendiente' } })];
  const texto = n => n == null ? '' : typeof n === 'string' ? n : Array.isArray(n) ? n.map(texto).join('') : typeof n.children === 'string' ? n.children : Array.isArray(n.children) ? n.children.map(texto).join('') : '';
  const out = {};
  (function andar(n, fila) {
    if (!n || typeof n !== 'object') return;
    if (Array.isArray(n)) { n.forEach(x => andar(x, fila)); return; }
    const props = n.props || {};
    if (n.type === 'tr' && props['data-order-row']) fila = props['data-order-row'];
    if (fila && (n.type === 'button' || n.type === 'a')) (out[fila] = out[fila] || []).push(texto(n).trim());
    if (Array.isArray(n.children)) n.children.forEach(x => andar(x, fila));
  })(dibujar.call(vm, vm, []), null);
  return { enProg: vm.enProg, enWeb: vm.enWeb, entregas: vm.entregas, menu: vm.menu, filas: out };
}
const conEntregas = { tieneModulo: m => m === 'entregas' };
const out = {
  // la página web de un restaurante SIN nada de la 4.32 (empresa sin programa, o el interruptor FE_SINC_DATOS apagado): la sesión no trae banderas
  webRestaurante: botones({}, { menu: true, ...conEntregas }),
  // la página web de un comercio sin menú
  webComercio: botones({ es_local: false }, { menu: false }),
  // contraste: el programa con la bandera pedidos_programa (ahí la cadena sí se evalúa: por eso las pruebas del programa no lo vieron)
  programa: botones({ es_local: true, datos_v2: true, pedidos_programa: true }, { menu: true }),
};
console.log(JSON.stringify(out));
process.exit(0);
"""


def _dibujar_P1(tmp_path):
    return _node(tmp_path, GUION_P1, archivos=("vendor/vue.esm-browser.prod.min.js",), falsos=_falsos())


def test_web_restaurante_conserva_los_botones_de_la_431_en_un_pedido_ya_aceptado(tmp_path):
    r = _dibujar_P1(tmp_path)["webRestaurante"]
    assert r["enProg"] is False and r["enWeb"] is True and r["menu"] is True and r["entregas"] is True, r     # es la página web, no el programa
    f = r["filas"]
    assert f["web-1"][0] == "Aceptar pedido", f                                    # el pedido nuevo sí conserva su botón
    faltan = [(fila, boton) for fila, boton in (("web-2", "Abrir monitor"), ("web-3", "Abrir monitor"), ("web-4", "Entregar"), ("web-5", "Asignar a Express")) if boton not in f[fila]]
    assert not faltan, {"faltan": faltan, "filas": f}


def test_web_comercio_sin_menu_conserva_marcar_entregado(tmp_path):
    r = _dibujar_P1(tmp_path)["webComercio"]
    assert r["enProg"] is False and r["enWeb"] is True and r["menu"] is False, r
    f = r["filas"]
    faltan = [(fila, boton) for fila, boton in (("web-2", "Marcar entregado"), ("web-3", "Marcar entregado"), ("web-4", "Entregar")) if boton not in f[fila]]
    assert not faltan, {"faltan": faltan, "filas": f}


def test_contraste_en_el_programa_la_cadena_si_se_evalua(tmp_path):
    r = _dibujar_P1(tmp_path)["programa"]
    assert r["enProg"] is True, r
    f = r["filas"]
    # ajuste f1 (hallazgo «Entregar y Marcar entregado en el programa»): allá ya no se ofrecen; la cadena sigue evaluándose («Abrir monitor»)
    assert "Abrir monitor" in f["web-2"] and "Entregar" not in f["web-4"], f
    assert not any("Aceptar" in b for b in f["web-2"]), f                          # y lo que quería el arreglo de esta noche sí se cumple


# ==================================================================================================== copia de test_val_pantallas_r2.py
# """SEGUNDA VALIDACIÓN 4.32 (pantallas), hallazgo 2: en el PROGRAMA, Ventas en línea › Pedidos acepta el pedido, promete «su comanda sale sola
# en unos segundos» y en esa página nadie la saca.
# 
# Lo que se comprobó leyendo (y que estas pruebas repiten):
# - Ventas en línea es OTRO documento (/app/fisitaap/ → js/fis/app.js). El menú del ERP y el aviso de la Caja llevan ahí en la misma pestaña
#   (menu.js l.7: href '/app/fisitaap/#/…'), así que la página del ERP se descarga, y con ella la estación (app.js, caja.js, cocina.js).
# - Ningún módulo de js/fis carga pages/pos/_estacion.js (ese módulo importa app.js, el cascarón del ERP: no se puede cargar ahí).
# - `aceptarEnPrograma` (fis/pages/pedidos.js) solo manda el PUT y recarga la lista; `cargarImpresion` corta con `enProg`.
# - La copia de la comanda queda «pendiente» en el servidor del programa (origen «aceptar») hasta que se abra una pantalla del ERP; pasados
#   30 minutos (comandas.VIGENCIA_MIN) ya no sale sola.
# 
# El servidor es el falso de tests/test_431_estacion_pantallas.py (copias y reclamos por plato). Nada va a la red ni a una impresora."""
_IMPORTA_P2 = re.compile(r"(?:from\s+|import\s*\(\s*|import\s+)['\"`]([^'\"`]+\.js)['\"`]")

GUION_P2 = BASE + MONTAR_PED + r"""
Q.imps = [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'red', direccion: '192.168.1.60' }];   // la impresora de comandas del restaurante (de red)
Q.cfg = { terminales: [{ id: 1, nombre: 'Caja 1', destinos: { 1: '10', 2: '10', 3: 'none' } }] };
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) {
    Q.llamadas.push('PUT ' + url + ' ' + JSON.stringify(opt.body));
    copia(Q.pid, { origen: 'aceptar' });                                          // al aceptar, el servidor crea la cuenta y la copia fija de la comanda
    return Q.modo === 'programa'
      ? { id: Q.pid, numero: 40 + Q.pid, estado: 'confirmado', atiende: 3, atiende_nombre: 'Caja 1', cuenta_espera_id: 100 + Q.pid, mensaje: 'Pedido #' + (40 + Q.pid) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.' }
      : { id: Q.pid, numero: 40 + Q.pid, estado: 'en_preparacion', atiende: 0, cuenta_espera_id: 100 + Q.pid };
  }
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
async function caso(modo, info, pid) {
  S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.modo = modo; Q.pid = pid; Q.rotas = []; Q.agente = true;
  sesionPara(info);
  const vm = montar();
  await vm.cargarImpresion();
  const ok = await vm.aceptar({ id: pid, numero: 40 + pid, estado: 'nuevo' });
  // la persona se queda en Pedidos: la página se actualiza sola cada 20 s (cargar(true)); aquí, tres vueltas
  for (let i = 0; i < 3; i++) { S.t += 20000; await vm.cargar(true); }
  await new Promise(r => setTimeout(r, 100));
  return { ok, enProg: vm.enProg, toasts: Q.toasts.map(t => t[0]), impresos: Q.impresos, copia: S.copias[pid] ? S.copias[pid].estado : null,
    comanda: Q.llamadas.filter(x => x.includes('/api/pos/comanda/')).map(x => x.split(' ').slice(0, 2).join(' ').split('?')[0]), llamadas: Q.llamadas.map(x => x.split(' {')[0]) };
}
const out = {};
out.web = await caso('web', {}, 5);                                                                // la página web sin banderas: como la 4.31
out.programa = await caso('programa', { es_local: true, datos_v2: true, pedidos_programa: true }, 6);   // el programa del cliente
console.log(JSON.stringify(out));
process.exit(0);
"""


def _correr_P2(tmp_path):
    return _node(tmp_path, GUION_P2, archivos=("pages/pos/_comandas.js",), falsos=_falsos())


def test_contraste_en_la_web_la_pagina_de_pedidos_imprime_la_comanda_al_aceptar(tmp_path):
    r = _correr_P2(tmp_path)["web"]
    assert r["ok"] is True and r["enProg"] is False, r
    assert r["impresos"] and r["impresos"][0][0] == "Cocina" and r["copia"] == "impresa", r      # reclamó cada plato, imprimió y marcó la copia


def test_en_el_programa_la_comanda_que_promete_pedidos_tiene_quien_la_saque_en_esa_pagina(tmp_path):
    r = _correr_P2(tmp_path)["programa"]
    assert r["ok"] is True and r["enProg"] is True, r
    assert "su comanda sale sola en unos segundos" in r["toasts"][0], r                          # la promesa que lee el cajero
    # Un minuto después, sin salir de Pedidos (una computadora, una pestaña): alguien de esta página tuvo que reclamar la comanda e imprimirla.
    # Hoy: solo el PUT y las recargas de la lista; la copia sigue «pendiente» y nada sale por la impresora.
    assert r["impresos"] or r["comanda"], {"copia_de_la_comanda": r["copia"], "impresos": r["impresos"], "llamadas": r["llamadas"]}
    assert r["copia"] == "impresa", r


def _grafo_fis_P2() -> dict:
    """Todo lo que puede cargar la aplicación de Ventas en línea: js/fis/** y lo que importan (import fijo o import('…'))."""
    vistos, cola = {}, [p.relative_to(JS).as_posix() for p in (JS / "fis").rglob("*.js")]
    while cola:
        rel = cola.pop()
        if rel in vistos or not (JS / rel).exists():
            continue
        txt = vistos[rel] = (JS / rel).read_text(encoding="utf-8")
        base = (JS / rel).parent
        for m in _IMPORTA_P2.finditer(txt):
            ruta = m.group(1)
            if "${" in ruta:
                continue
            destino = (JS / ruta[len("/js/"):]) if ruta.startswith("/js/") else (base / ruta)
            try:
                cola.append(destino.resolve().relative_to(JS.resolve()).as_posix())
            except ValueError:
                pass
    return vistos


def test_en_ventas_en_linea_no_hay_estacion_ni_aviso_de_comandas_sin_imprimir():
    g = _grafo_fis_P2()
    assert "fis/app.js" in g and "fis/pages/pedidos.js" in g and "pages/pos/_comandas.js" in g       # el grafo sí sigue los import('…')
    con_estacion = "pages/pos/_estacion.js" in g or "app.js" in g
    # el respaldo del plan (§4.4: «Hay N comandas de pedidos sin imprimir: abra la Caja.») tampoco existe en esta aplicación
    con_aviso = any("comandas_pendientes" in t or "sin imprimir: abra la Caja" in t for rel, t in g.items() if rel.startswith("fis/"))
    assert con_estacion or con_aviso, "Ventas en línea no corre la estación ni avisa de comandas sin imprimir"


# ==================================================================================================== copia de test_val_pantallas_r3.py
# """SEGUNDA VALIDACIÓN 4.32 (pantallas), hallazgo 3: la página del ERP en el PROGRAMA lee las banderas (`pedidos_programa`, `datos_v2`,
# `sinc_pantallas`) una sola vez, al cargar (/api/arranque) o al entrar (/api/auth/login). El programa las enciende DESPUÉS: el día de la
# actualización, local.py abre el navegador a los 1,5 s (l.220) y el hilo de la sincronización espera 10 a 15 s antes de su primera vuelta
# (sinc_datos_programa._bucle); `pedidos_programa` solo queda verdadero cuando una respuesta de /api/sinc/datos lo dice
# (sinc_datos_programa l.1424), y eso pasa cuando la web termina de sembrar la empresa (minutos).
# 
# Precisión sobre lo que dijo el primer validador: la página de Ventas en línea › Pedidos SÍ vuelve a leer las banderas cada vez que se abre
# (es otro documento: fis/sesion.js restaurar → /api/arranque), y la del ERP también cuando se vuelve desde Ventas en línea (otra carga
# completa). La que se queda vieja es la página del ERP mientras nadie la recargue ni salga de ella: sin `pedidos_programa` no queda ningún
# temporizador que vuelva a preguntar, la estación no arranca, el programa no dice «estación viva» y la web sigue atendiendo los pedidos pagados
# o aceptados allá (como la 4.31), sin que nada lo avise.
# 
# Aquí corre con Node el bloque de verdad de app.js (vigilarAvisoLocal + franja + estación) con relojes falsos: pasan 10 minutos."""
APP_P3 = _js("app.js")


def _bloque_P3() -> str:
    i = APP_P3.index("let _avisoLocal = null;")
    return APP_P3[i:APP_P3.index("let _precargando", i)]


FALSOS_P3 = {
    "pages/pos/_estacion.js": """
export const estadoEstacion = { resumen: null };
export function iniciarDesdeApp() { globalThis.Q.estacion.push('inicia'); }
export function pararDesdeApp() { globalThis.Q.estacion.push('para'); }
""",
}

GUION_P3 = r"""
import fs from 'node:fs';
const Q = globalThis.Q = { llamadas: [], estacion: [], relojes: [], hash: '/pos/caja', servidor: { pedidos_programa: false, datos_v2: false, sinc_pantallas: false },
  store: { franja: null, avisoLocal: null } };
// lo que contesta el programa cuando se le pregunta por la sesión: la información de la empresa con las banderas QUE TENGA EN ESE MOMENTO
const yo = () => ({ usuario: { id: 1 }, empresa_id: 7, empresas: [{ id: 7, es_local: true, ...Q.servidor }] });
// la sesión del ERP, reducida: `empresas` se llena al cargar y refrescarEmpresas es la de app.js (misma consulta, mismas condiciones)
Q.sesion = { activa: true, usuario: { id: 1 }, empresa_id: 7, empresas: [], puede: () => true,
  get empresaInfo() { return this.empresas.find(e => e.id === this.empresa_id) || null; },
  async refrescarEmpresas() { let r = null; try { r = await api('/api/auth/yo', { sinExpirar: true }); } catch { return null; } if (!r || !r.usuario || r.usuario.id !== this.usuario?.id || r.empresa_id !== this.empresa_id) return null; if (Array.isArray(r.empresas)) this.empresas = r.empresas; return r; } };
const api = async (u, o) => { Q.llamadas.push(u.split('?')[0]); if (u === '/api/auth/yo') return yo(); if (u === '/api/arranque') return { yo: yo() }; if (u === '/api/sinc/local/aviso') return { conectada: true }; if (u === '/api/sinc/datos/franja') return { cambios: 0, ventas: 0, sin_ver: 0 }; if (u === '/api/pedidos/resumen') return { comandas_pendientes: 0 }; return null; };
globalThis.apiFalsa = api;
globalThis.location = { get hash() { return '#' + Q.hash; } };
globalThis.window = {};
globalThis.setInterval = (f, ms) => { Q.relojes.push({ f, ms, sig: ms }); return Q.relojes.length; };
globalThis.clearInterval = n => { if (Q.relojes[n - 1]) Q.relojes[n - 1].f = null; };
const pre = `const sesion = globalThis.Q.sesion, store = globalThis.Q.store, api = globalThis.apiFalsa;
const decodificarRuta = x => x;\n`;
fs.writeFileSync('./js/bloque.mjs', pre + fs.readFileSync('./bloque.txt', 'utf8') + '\nexport { vigilarAvisoLocal, vigilarFranja };');
const F = await import('./js/bloque.mjs');
const respiro = () => new Promise(r => setTimeout(r, 5));
async function pasan(segundos) {                                                  // el reloj falso: dispara cada temporizador cuando le toca
  for (let t = 1000; t <= segundos * 1000; t += 1000) for (const r of Q.relojes) { if (!r.f) continue; r.sig -= 1000; if (r.sig <= 0) { r.sig = r.ms; await r.f(); await respiro(); } }
}
const out = {};
// 1) El programa abre la página a los 1,5 s: todavía no sabe que atiende los pedidos. La página carga la sesión y termina store.cargar():
Q.sesion.empresas = yo().empresas;
F.vigilarAvisoLocal(); F.vigilarFranja(); await respiro();
out.alCargar = { estacion: Q.estacion.slice(), relojes: Q.relojes.filter(r => r.f).map(r => r.ms) };
// 2) Un minuto después el programa ya habló con la página web: protocolo 2 y «los pedidos los atiende este programa»
Q.servidor = { pedidos_programa: true, datos_v2: true, sinc_pantallas: true };
// 3) Pasan 10 minutos con la Caja abierta, sin recargar
Q.llamadas = [];
await pasan(600);
out.despues = { estacion: Q.estacion.slice(), preguntas: [...new Set(Q.llamadas)], banderaEnLaPagina: !!(Q.sesion.empresaInfo && Q.sesion.empresaInfo.pedidos_programa), franja: Q.store.franja };
console.log(JSON.stringify(out));
process.exit(0);
"""


def _correr_P3(tmp_path):
    (tmp_path / "bloque.txt").write_text(_bloque_P3(), encoding="utf-8")
    return _node(tmp_path, GUION_P3, archivos=(), falsos=FALSOS_P3)


def test_la_pagina_del_erp_se_entera_de_que_el_programa_ya_atiende_los_pedidos(tmp_path):
    r = _correr_P3(tmp_path)
    assert r["alCargar"]["estacion"] == [], r                                     # al cargar no había bandera: sin estación (correcto)
    d = r["despues"]
    # 10 minutos después de que el programa encendió la bandera, la página abierta tiene que haberse enterado y la estación tiene que estar
    # corriendo. Hoy: lo único que pregunta es el aviso de conexión, la bandera de la página sigue apagada y la estación nunca arranca.
    assert d["banderaEnLaPagina"] is True and "inicia" in d["estacion"], d


def test_app_js_define_refrescar_empresas_y_solo_la_llama_instalacion_local():
    import re
    from tests.test_425_ultimos_pantallas import JS
    quienes = sorted(p.relative_to(JS).as_posix() for p in JS.rglob("*.js") if "vendor" not in p.parts and re.search(r"refrescarEmpresas\(\)\s*[.;]", p.read_text(encoding="utf-8")))
    assert quienes != ["pages/configuracion/instalacion-local.js"], quienes       # nadie más vuelve a leer las banderas de la empresa abierta


# ==================================================================================================== copia de test_val_pedidos_dinero_r2.py
# """VALIDACIÓN 4.32 · segundo validador (pedidos y dinero) · r2. Reproduce el hallazgo n.º 2 y FALLA mientras exista.
# 
# La pantalla del programa (Caja y el resto del ERP, app/static/js/app.js) lee la bandera pedidos_programa UNA vez, al cargarse. El día de la
# actualización, o cuando en la web se elige «Los pedidos en línea los atiende: el programa» con el programa abierto, el servidor del
# programa ya dice pedidos_programa = true, pero esa pestaña sigue con la bandera en falso: su estación de comandas no arranca nunca (hasta
# recargar la página). Mientras tanto, un pedido aceptado desde el programa se le asigna a esa computadora (la acción «aceptar» no mira
# estacion_viva: lo prueba tests/test_val_pedidos_dinero_6.py) y su comanda no sale sola.
# 
# Aquí se ejecuta con Node el bloque real de app.js (el aviso de cada minuto, la franja y la estación) sobre un servidor de mentira: la
# pestaña carga con la bandera en falso, el servidor pasa a decir verdadero y corren 5 minutos de temporizadores. Lo que debe pasar: la
# pestaña se entera sola y arranca la estación. Lo que pasa hoy: nada vuelve a leer la bandera.
# (Las pantallas de Ventas en línea, /app/fisitaap/, son otra página: al abrirlas se vuelve a leer la bandera, pero ahí no corre la estación.)"""
APP_D2 = _js("app.js")
FALSOS_D2 = {
    "pages/pos/_estacion.js": """
export const estadoEstacion = { resumen: null };
export function iniciarDesdeApp() { globalThis.Q.estacion.push('inicia'); }
export function pararDesdeApp() { globalThis.Q.estacion.push('para'); }
""",
}
GUION_D2 = r"""
import fs from 'node:fs';
const Q = globalThis.Q = { llamadas: [], estacion: [], timers: [], servidor: { datos_v2: false, pedidos_programa: false, sinc_pantallas: false }, store: { franja: null, avisoLocal: null } };
const empresas = () => [{ id: 7, es_local: true, ...Q.servidor }];
Q.api = async u => {
  u = u.split('?')[0]; Q.llamadas.push(u);
  if (u === '/api/auth/yo') return { usuario: { id: 1 }, empresa_id: 7, empresas: empresas() };
  if (u === '/api/arranque') return { yo: { usuario: { id: 1 }, empresa_id: 7, empresas: empresas() } };
  if (u === '/api/sinc/datos/franja') return { cambios: 0, ventas: 0, pausa: false, sin_ver: 0 };
  if (u === '/api/pedidos/resumen') return { nuevos: 0, ultimo_id: 0, comandas_pendientes: 0 };
  return {};
};
// la sesión de app.js, con la misma refrescarEmpresas (app.js l.303-308)
Q.sesion = { usuario: { id: 1 }, empresa_id: 7, empresas: empresas(), get activa() { return !!this.usuario; },
  get empresaInfo() { return this.empresas.find(e => e.id === this.empresa_id) || null; }, puede: () => true,
  async refrescarEmpresas() { let r = null; try { r = await Q.api('/api/auth/yo'); } catch { return null; }
    if (!r || !r.usuario || r.usuario.id !== this.usuario?.id || r.empresa_id !== this.empresa_id) return null;
    if (Array.isArray(r.empresas)) this.empresas = r.empresas; return r; } };
globalThis.location = { hash: '#/pos/caja' };
globalThis.window = {};
globalThis.setInterval = (f, ms) => { Q.timers.push({ f, ms }); return Q.timers.length; };
globalThis.clearInterval = id => { if (Q.timers[id - 1]) Q.timers[id - 1].f = null; };
const pre = `const sesion = globalThis.Q.sesion, store = globalThis.Q.store;
const api = (u, o) => globalThis.Q.api(u, o);
const decodificarRuta = x => x;\n`;
fs.mkdirSync('./js/pages/pos', { recursive: true });
fs.writeFileSync('./js/bloque.mjs', pre + fs.readFileSync('./bloque.txt', 'utf8') + '\nexport { vigilarAvisoLocal, vigilarFranja };');
const F = await import('./js/bloque.mjs');
const esperar = () => new Promise(r => setTimeout(r, 30));
const out = {};
// 1) la pestaña del programa carga (store.cargar termina con vigilarAvisoLocal y vigilarFranja): el servidor todavía dice falso
F.vigilarAvisoLocal(); F.vigilarFranja(); await esperar();
out.al_cargar = { estacion: [...Q.estacion], bandera: Q.sesion.empresaInfo.pedidos_programa };
// 2) termina la primera vuelta del canal nuevo (o en la web eligen que los pedidos los atiende este programa): el servidor ya dice verdadero
Q.servidor = { datos_v2: true, pedidos_programa: true, sinc_pantallas: true };
// 3) pasan 5 minutos: corren todos los temporizadores vivos de la pestaña, una vez por «minuto»
for (let i = 0; i < 5; i++) { for (const t of [...Q.timers]) if (t.f) { await t.f(); await esperar(); } }
out.despues = { estacion: [...Q.estacion], bandera: Q.sesion.empresaInfo.pedidos_programa, temporizadores: Q.timers.filter(t => t.f).map(t => t.ms),
  llamadas: [...new Set(Q.llamadas)] };
console.log(JSON.stringify(out));
process.exit(0);
"""


def _bloque_D2() -> str:
    i = APP_D2.index("let _avisoLocal = null;")
    return APP_D2[i:APP_D2.index("let _precargando", i)]


def test_r2_la_pestana_del_programa_se_entera_sola_de_que_ya_atiende_los_pedidos_y_arranca_su_estacion(tmp_path):
    (tmp_path / "bloque.txt").write_text(_bloque_D2(), encoding="utf-8")
    r = _node(tmp_path, GUION_D2, archivos=(), falsos=FALSOS_D2)
    assert r["al_cargar"] == {"estacion": [], "bandera": False}, r        # al cargar: sin la bandera no hay estación (bien, como la 4.31)
    assert r["despues"]["bandera"] is True and "inicia" in r["despues"]["estacion"], (
        "El servidor del programa ya dice pedidos_programa = true, pero 5 minutos después la pestaña sigue con la bandera en "
        f"{r['despues']['bandera']} y la estación de comandas {'arrancó' if 'inicia' in r['despues']['estacion'] else 'NO arrancó'}; "
        f"temporizadores vivos (ms): {r['despues']['temporizadores']}; lo único que pidió al servidor: {r['despues']['llamadas']}")


# ==================================================================================================== copia de test_val_dia_del_cliente_r3.py
# """Segunda validación 4.32 · lente «el día del cliente» · hallazgo 3 (aceptar en Ventas en línea › Pedidos del programa).
# 
# Esta prueba describe lo que DEBERÍA pasar y por eso FALLA con el código que se va a entregar: muestra el defecto.
#   1. Lado servidor (programa con el canal nuevo y una web de mentira): el cajero acepta un pedido nuevo. La respuesta dice «su comanda sale
#      sola en unos segundos»; la cuenta y la copia de la comanda quedan creadas aquí y la comanda queda PENDIENTE de imprimir.
#   2. Lado pantalla: el cajero está en /app/fisitaap/ (otra aplicación, js/fis). Se exige que ALGO de esa aplicación saque la comanda:
#      que «Aceptar» imprima, o que la aplicación corra la estación (pida /api/pos/comanda/pendientes), o que lo lleve a la Caja del ERP.
#   3. Y lo que pasa si se queda ahí: a los 120 s el programa le dice a la web que su estación no vive.
# No cambia la aplicación."""
JS_C3 = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "js"


def test_r3_aceptar_en_pedidos_del_programa_saca_la_comanda_sin_salir_de_esa_pantalla(prog, monkeypatch):  # noqa: F811
    eid, w = prog
    # --- 1. el pedido nuevo llega y el cajero lo acepta en Ventas en línea › Pedidos del programa
    _llega(eid, _fila_pedido(eid, 915, estado="nuevo", atiende=0))
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 915, "estado": "confirmado"}, "filas": [_fila_pedido(eid, 915)]})
    out = _estado(eid, 915, "confirmado")
    assert out["mensaje"] == "Pedido #915 aceptado: ya está en la caja y su comanda sale sola en unos segundos."
    assert len(_cuentas_de(eid, 915)) == 1                                  # la cuenta entró a la caja del programa
    with Session(engine_empresa(eid)) as s:
        copia = comandas._copia(s, eid, 915)
        assert copia is not None                                           # la comanda existe aquí…
        pend = comandas.pendientes(s, eid)
        assert [c["pedido_id"] for c in pend["copias"]] == [915]          # …y está pendiente de imprimir
        assert not any(l.get("estado") == "impresa" for c in pend["copias"] for l in c.get("lineas") or [])

    # --- 2. ¿quién la imprime mientras el cajero sigue en la aplicación de Ventas en línea?
    quien = []
    ped = (JS_C3 / "fis" / "pages" / "pedidos.js").read_text(encoding="utf-8")
    cuerpo = ped[ped.index("async aceptarEnPrograma(p) {"):ped.index("async atenderAqui(p) {")]
    if "comandaDelPedido" in cuerpo:
        quien.append("aceptarEnPrograma imprime la comanda")
    if re.search(r"location\.(href|assign|replace)[^;]*/app/#/pos/(caja|cocina)", cuerpo):
        quien.append("aceptarEnPrograma lleva a la Caja o a Cocina del ERP")
    for p in sorted((JS_C3 / "fis").rglob("*.js")):
        t = p.read_text(encoding="utf-8")
        if re.search(r"_estacion\.js", t) and re.search(r"iniciarDesdeApp|iniciarEstacion|revisarEstacion|pasoDesdeApp", t):
            quien.append("%s corre la estación de comandas" % p.name)
        # la pasada de la estación pide los pendientes SIN pedido (comandas.ruta_pendientes solo así marca la estación viva); la lectura
        # con pedido_id de comandaDelPedido (pedidos.js) es de la página web: aceptarEnPrograma no la usa (se revisó arriba)
        if re.search(r"pendientesComanda\(\s*api\s*\)|comanda/pendientes['\"`]\s*\)", t):
            quien.append("%s pide las comandas pendientes de la estación" % p.name)
    html = (JS_C3.parent / "app" / "fisitaap" / "index.html").read_text(encoding="utf-8")
    if '"/js/app.js"' in html or "'/js/app.js'" in html:
        quien.append("la aplicación de Ventas en línea carga js/app.js (la estación «en cualquier pantalla»)")

    # --- 3. dos minutos en esa pantalla: la última pasada de la estación fue justo antes de entrar a Pedidos
    sdp.marcar_estacion(eid)
    real = sdp.time.time
    monkeypatch.setattr(sdp.time, "time", lambda: real() + 121)
    viva = sdp.estacion_viva(eid)

    assert quien, ("El cajero aceptó el pedido #915 en Ventas en línea › Pedidos del programa y la pantalla le dijo «su comanda sale sola en unos "
                   "segundos», pero en esa aplicación (/app/fisitaap/) nada la imprime ni corre la estación ni lo devuelve a la Caja: la comanda "
                   "sigue pendiente (%s pendiente) hasta que vuelva a una pantalla del ERP y la deje a la vista. A los 121 s ahí, estacion_viva = %s "
                   "(la web deja de pasarle los pedidos pagados con tarjeta)." % (len(pend["copias"]), viva))


# ==================================================================================================================== pruebas propias (f1)
# (e) en el programa no se ofrecen «Entregar» ni «Marcar entregado» (allá siempre contestaban «Esto se hace en la página web.»); en la web sí
GUION_E = GUION_P1.replace("const out = {\n  // la página web", """const out = {
  programaComercio: botones({ es_local: true, datos_v2: true, pedidos_programa: true }, { menu: false }),
  programaSinBandera: botones({ es_local: true, datos_v2: true }, { menu: false }),
  // la página web""", 1)


def test_f1_programa_sin_entregar_ni_marcar_entregado(tmp_path):
    assert "programaComercio" in GUION_E
    r = _node(tmp_path, GUION_E, archivos=("vendor/vue.esm-browser.prod.min.js",), falsos=_falsos())
    for caso in ("programa", "programaComercio"):
        botones = [b for fila in r[caso]["filas"].values() for b in fila]
        assert "Entregar" not in botones and "Marcar entregado" not in botones, r[caso]
    assert "Abrir monitor" in r["programa"]["filas"]["web-2"], r["programa"]
    # el programa sin la bandera pedidos_programa: como la 4.31 (los botones siguen)
    f = r["programaSinBandera"]["filas"]
    assert "Marcar entregado" in f["web-2"] and "Entregar" in f["web-4"], f
    # la web de comercio sigue con los dos
    f = r["webComercio"]["filas"]
    assert "Marcar entregado" in f["web-2"] and "Entregar" in f["web-4"], f


# (f) aceptar en el programa un pedido cuya copia ya es vieja: si no se pudo imprimir aquí, no se promete que «saldrá sola»
GUION_F = BASE + MONTAR_PED + r"""
Q.imps = [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'red', direccion: '192.168.1.60' }];
Q.cfg = { terminales: [{ id: 1, nombre: 'Caja 1', destinos: { 1: '10', 2: '10', 3: 'none' } }] };
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) {
    Q.llamadas.push('PUT ' + url);
    const viejo = new Date(Date.now() - 4 * 3600000).toISOString();
    copia(Q.pid, Q.vieja ? { origen: 'aceptar', creado: viejo, listo_desde: viejo } : { origen: 'aceptar' });
    return { id: Q.pid, numero: 40 + Q.pid, estado: 'confirmado', atiende: 3, atiende_nombre: 'Caja 1', cuenta_espera_id: 100 + Q.pid, mensaje: 'Pedido #' + (40 + Q.pid) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.' };
  }
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
async function caso(vieja, agente, pid) {
  S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.vieja = vieja; Q.agente = agente; Q.rotas = [];
  sesionPara({ es_local: true, datos_v2: true, pedidos_programa: true });
  const vm = montar();
  const ok = await vm.aceptar({ id: pid, numero: 40 + pid, estado: 'nuevo' });
  return { ok, toasts: Q.toasts, impresos: Q.impresos, copia: S.copias[pid] ? S.copias[pid].estado : null, aviso: vm.sinImprimir };
}
const out = {};
out.viejaSinAgente = await caso(true, false, 7);
out.nuevaSinAgente = await caso(false, false, 8);
out.viejaConAgente = await caso(true, true, 9);
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_f1_aceptar_en_el_programa_no_promete_que_sale_sola_una_comanda_vieja(tmp_path):
    r = _node(tmp_path, GUION_F, archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    v = r["viejaSinAgente"]
    assert v["ok"] is True and v["copia"] == "pendiente" and not v["impresos"], r
    ultimo = v["toasts"][-1][0]
    assert "saldrá sola" not in ultimo and "Imprímala desde Punto de venta › Cocina" in ultimo, v["toasts"]
    n = r["nuevaSinAgente"]
    assert "saldrá sola" in n["toasts"][-1][0], n["toasts"]                       # la copia nueva sí la saca la estación de la Caja
    c = r["viejaConAgente"]
    assert c["impresos"] and c["copia"] == "impresa" and c["toasts"][-1][0] == "Pedido aceptado y comanda impresa.", c   # aceptar la imprime aquí, sin mirar la edad


# (c) en la página web no hay consulta ni temporizador nuevos: como la 4.31
GUION_WEB = GUION_D2.replace("const empresas = () => [{ id: 7, es_local: true, ...Q.servidor }];", "const empresas = () => [{ id: 7, es_local: false, ...Q.servidor }];", 1)


def test_f1_en_la_web_no_relee_banderas_ni_crea_temporizadores(tmp_path):
    assert GUION_WEB != GUION_D2
    (tmp_path / "bloque.txt").write_text(_bloque_D2(), encoding="utf-8")
    r = _node(tmp_path, GUION_WEB, archivos=(), falsos=FALSOS_D2)
    d = r["despues"]
    assert "/api/auth/yo" not in d["llamadas"] and d["estacion"] == [], r
    assert d["temporizadores"] == [60000], r                                      # solo el del aviso del programa, que ya existía en la 4.31 (en la web no pregunta nada)


# (d) con un interruptor apagado, la estación sigue mientras queden comandas pendientes de pedidos ya asignados (bandera comandas_programa)
GUION_D = GUION_D2.replace("servidor: { datos_v2: false, pedidos_programa: false, sinc_pantallas: false }", "servidor: { datos_v2: false, pedidos_programa: false, sinc_pantallas: false, comandas_programa: true }", 1).replace(
    "Q.servidor = { datos_v2: true, pedidos_programa: true, sinc_pantallas: true };", "Q.servidor = { datos_v2: false, pedidos_programa: false, sinc_pantallas: false, comandas_programa: false };", 1)


def test_f1_la_estacion_sigue_con_comandas_pendientes_y_se_para_al_terminar(tmp_path):
    assert GUION_D.count("comandas_programa") == 2
    (tmp_path / "bloque.txt").write_text(_bloque_D2(), encoding="utf-8")
    r = _node(tmp_path, GUION_D, archivos=(), falsos=FALSOS_D2)
    assert r["al_cargar"]["estacion"] == ["inicia"], r                           # se recargó con el interruptor apagado y una comanda pendiente
    assert r["despues"]["estacion"] == ["inicia", "para"], r                     # ya no quedan: al minuto se para sola


def test_f1_estacion_posible_con_comandas_programa():
    est = _js("pages/pos/_estacion.js")
    assert "|| !!(sesion.empresaInfo && sesion.empresaInfo.comandas_programa) || !!(sesion.empresaInfo && sesion.empresaInfo.pedidos_programa)); }" in est


def test_f1_bandera_comandas_programa(prog, monkeypatch):  # noqa: F811
    from sqlalchemy import text
    from app import auth, db
    eid, _w = prog
    monkeypatch.setattr(auth, "aviso_local", lambda e: None)              # como en el programa

    def info():
        with Session(db.engine) as sc:
            return auth._info_empresa(sc.get(db.Empresa, eid))
    sdp._guardar_estado(eid, pedidos_programa=True)
    d = info()
    assert d["pedidos_programa"] is True and d["comandas_programa"] is False, d   # con la bandera de siempre no hace falta la nueva
    assert _llega(eid, _fila_pedido(eid, 990, hora_programada="23:59"))   # pedido ya asignado, para más tarde: su comanda espera aquí
    sdp._guardar_estado(eid, pedidos_programa=False)                      # FE_PEDIDOS_PROGRAMA=0 en la web
    d = info()
    assert d["pedidos_programa"] is False and d["comandas_programa"] is True, d
    sdp._guardar_estado(eid, pedidos_programa=True, pausa_desde=sdp._ahora())   # o FE_SINC_DATOS=0: en pausa
    try:
        d = info()
        assert d["pedidos_programa"] is False and d["comandas_programa"] is True, d
    finally:
        sdp._guardar_estado(eid, pausa_desde=None, pedidos_programa=False)
    with Session(engine_empresa(eid)) as s:                               # la comanda salió: la bandera se apaga
        s.execute(text("UPDATE comanda_pedido SET estado = 'impresa' WHERE pedido_id = 990")); s.commit()
    assert info()["comandas_programa"] is False


# revisión tras el arreglo (14 nov): con la cadena de botones de vuelta, «Entregar» (pedido «Listo») se ofrecía en la página web aunque el pedido
# lo atendiera un programa (allá están su cuenta y su cobro), igual que «Marcar entregado» antes de la 4.32 (ese ya tenía !lejos). Ahora los dos
# se ocultan mientras lo atiende un programa y vuelven si el administrador lo rescata (atiende 0).
GUION_LEJOS = GUION_P1.replace("...(extra || {}) });", "...(extra || {}), ...(globalThis.EXTRA_PED || {}) });", 1).replace(
    "};\nconsole.log(JSON.stringify(out));", """  webLejos: (globalThis.EXTRA_PED = { atiende: 5, atiende_nombre: 'Caja 1' }, botones({}, { menu: true, ...conEntregas })),
  webComercioLejos: botones({ es_local: false }, { menu: false }),
  rescatado: (globalThis.EXTRA_PED = { atiende: 0 }, botones({}, { menu: true, ...conEntregas })),
};
console.log(JSON.stringify(out));""", 1)


def test_f1_web_no_entrega_lo_que_atiende_un_programa(tmp_path):
    assert "webLejos" in GUION_LEJOS and "EXTRA_PED || {}" in GUION_LEJOS
    r = _node(tmp_path, GUION_LEJOS, archivos=("vendor/vue.esm-browser.prod.min.js",), falsos=_falsos())
    for caso in ("webLejos", "webComercioLejos"):
        botones = [b for fila in r[caso]["filas"].values() for b in fila]
        assert "Entregar" not in botones and "Marcar entregado" not in botones, r[caso]
    assert "Entregar" in r["rescatado"]["filas"]["web-4"], r["rescatado"]
    assert "Entregar" in r["webRestaurante"]["filas"]["web-4"] and "Marcar entregado" in r["webComercio"]["filas"]["web-2"], r
