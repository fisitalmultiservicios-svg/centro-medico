# -*- coding: utf-8 -*-
"""3.87 (segunda ronda, r2_sincaja): el Cajero de una empresa sin punto de venta (Facturación, o un hotel sin el extra).
- facturacion-r2 / g3a F3 / hospitalidad F4 / g5-R1: la sesión trae sin_caja con su motivo y la interfaz muestra una sola pantalla
  propia (sin pedir datos que dan 403 ni avisos rojos); el 403 sin_caja del servidor no cambia.
- facturacion-r2 / F4: ese rol ya no se ofrece ni se asigna donde no hay punto de venta (Usuarios de la empresa y consola), no se le
  apaga la caja a un Cajero, y apagar el punto de venta (módulos, plan o tipo de negocio) avisa de los cajeros que quedan sin trabajo.
- g3a F1: sin resumen, «Cobros de los próximos 30 días» y «Planilla» no quedan ocultas por una preferencia del navegador.
- admin_sistema F3: «Elija la empresa» con la lista vacía explica que ya no tiene empresas.
- comercio-r2: el menú lateral no pinta grupos que quedan sin entradas (Ventas en línea del Cajero)."""
import json
import pathlib
import re
import types

from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine
from app.main import app
from tests.test_387_registros import H, _borrar, _empresa, c

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
JS = RAIZ / "static" / "js"


def _js(*p):
    return (JS / pathlib.Path(*p)).read_text(encoding="utf-8")


def _poner(eid, **campos):
    with Session(engine) as s:
        e = s.get(Empresa, eid)
        for k, v in campos.items():
            setattr(e, k, v)
        s.add(e); s.commit()


def _ocultar_a(eid, correo, ocultos):
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).one()
        m = s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == eid)).one()
        m.modulos_ocultos = json.dumps(ocultos) if ocultos else None
        s.add(m); s.commit()
        return u.id


def _uid(correo):
    with Session(engine) as s:
        return s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).one().id


def _consola():
    """El administrador del sistema de la consola (como en test_rol_avanzado): solo para estas llamadas."""
    admin = types.SimpleNamespace(id=None, correo="admin.r2sincaja@example.test", es_superadmin=True, nombre="Admin", admin_principal=True)
    app.dependency_overrides[auth.superadmin] = lambda: admin


def _sin_consola():
    app.dependency_overrides.pop(auth.superadmin, None)


def test_la_sesion_marca_al_cajero_sin_caja_con_su_motivo():
    """La interfaz decide su pantalla con esto: es exactamente la condición del 403 sin_caja de contexto()."""
    correos = {"Administrador": "admin.sc1.387@example.test", "Cajero": "cajero.sc1.387@example.test"}
    fac = {"Administrador": "admin.sc1f.387@example.test", "Cajero": "cajero.sc1f.387@example.test"}
    eid, tok = _empresa("Hotel SinCaja r2 387 QA", "hospitalidad", {}, correos, "71")
    fid, ftok = _empresa("Facturas SinCaja r2 387 QA", "facturacion", {}, fac, "72")
    try:
        def yo(t):
            return c.get("/api/auth/yo", headers=H(t)).json()

        def bloqueado(t):
            r = c.get("/api/clientes", headers=H(t))
            return r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_caja"

        # hotel sin plan (todo encendido): el Cajero tiene su caja
        assert yo(tok["Cajero"])["sin_caja"] is None and not bloqueado(tok["Cajero"])
        # plan «hotel» sin el extra del punto de venta
        _poner(eid, plan="hotel", extras="[]")
        assert yo(tok["Cajero"])["sin_caja"] == "plan" and bloqueado(tok["Cajero"])
        assert yo(tok["Administrador"])["sin_caja"] is None and not bloqueado(tok["Administrador"])
        a = c.get("/api/arranque", headers=H(tok["Cajero"])).json()                       # entra con la marca y sin datos de la empresa
        assert a["yo"]["sin_caja"] == "plan" and "empresa" not in a and "registros" not in a
        # con el extra vuelve a tener su caja; apagado para la empresa o solo para él, el motivo cambia
        _poner(eid, extras='["pos"]')
        assert yo(tok["Cajero"])["sin_caja"] is None and not bloqueado(tok["Cajero"])
        _poner(eid, modulos_ocultos='["pos"]')
        assert yo(tok["Cajero"])["sin_caja"] == "empresa" and bloqueado(tok["Cajero"])
        _poner(eid, modulos_ocultos="[]")
        _ocultar_a(eid, correos["Cajero"], ["pos"])
        assert yo(tok["Cajero"])["sin_caja"] == "usuario" and bloqueado(tok["Cajero"])
        _ocultar_a(eid, correos["Cajero"], None)
        # Facturación con plan: su tipo de negocio no tiene punto de venta
        _poner(fid, plan="fac_emprendedor")
        assert yo(ftok["Cajero"])["sin_caja"] == "tipo" and bloqueado(ftok["Cajero"])
        assert yo(ftok["Administrador"])["sin_caja"] is None
        # el inicio de sesión y el cambio de empresa traen la misma marca (_respuesta)
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == fac["Cajero"])).one()
            assert auth._respuesta(s, u, fid)["sin_caja"] == "tipo"
    finally:
        _borrar(eid, correos.values())
        _borrar(fid, fac.values())


def test_no_se_ofrece_ni_se_asigna_cajero_donde_no_hay_caja():
    correos = {"Administrador": "admin.sc2.387@example.test", "Vendedor": "vend.sc2.387@example.test", "Cajero": "cajero.sc2.387@example.test"}
    com = {"Administrador": "admin.sc2c.387@example.test", "Cajero": "cajero.sc2c.387@example.test"}
    nuevo, nuevo_c = "nuevo.sc2.387@example.test", "nuevo.sc2c.387@example.test"
    eid, tok = _empresa("Facturas Roles r2 387 QA", "facturacion", {}, correos, "73")
    cid, ctok = _empresa("Comercio Roles r2 387 QA", "comercio", {"Caja propia": ["pos"]}, com, "74")
    _poner(eid, plan="fac_emprendedor")
    t = tok["Administrador"]
    try:
        # Configuración › Usuarios: «Cajero» viene marcado y no se asigna
        roles = {r["rol"]: r for r in c.get("/api/auth/roles", headers=H(t)).json()["roles"]}
        assert roles["Cajero"]["solo_caja"] and roles["Cajero"]["sin_caja"]
        assert not roles["Vendedor"]["solo_caja"] and not roles["Vendedor"]["sin_caja"]
        r = c.post("/api/auth/usuarios", headers=H(t), json={"correo": nuevo, "nombre": "Nuevo", "rol": "Cajero", "password_temporal": "Clave-larga-r2-sincaja-387"})
        assert r.status_code == 400 and r.json()["detail"]["codigo"] == "rol_sin_caja", r.text
        assert "punto de venta" in r.json()["detail"]["mensaje"] and "Elija otro rol" in r.json()["detail"]["mensaje"]
        with Session(engine) as s:                                                       # no quedó un usuario a medias
            assert s.exec(select(auth.Usuario).where(auth.Usuario.correo == nuevo)).first() is None
        uv = _uid(correos["Vendedor"])
        assert c.put(f"/api/auth/usuarios/{uv}", headers=H(t), json={"rol": "Cajero"}).status_code == 400
        assert c.put(f"/api/auth/usuarios/{uv}", headers=H(t), json={"rol": "Contador"}).status_code == 200
        # el Cajero que ya estaba así (de antes) no empeora: se puede volver a guardar, y pasarlo a otro rol
        uc = _uid(correos["Cajero"])
        assert c.put(f"/api/auth/usuarios/{uc}", headers=H(t), json={"rol": "Cajero"}).status_code == 200
        # consola: la lista de roles no ofrece Cajero aquí (sí en el comercio) y tampoco lo autoriza ni lo asigna
        _consola()
        try:
            cuentas = {x["id"]: x for x in c.get("/api/admin/cuentas").json()}
            assert "Cajero" not in cuentas[eid]["roles"] and "Vendedor" in cuentas[eid]["roles"]
            assert "Cajero" in cuentas[cid]["roles"] and "Caja propia" in cuentas[cid]["roles"]
            r = c.post(f"/api/admin/cuentas/{eid}/usuarios", json={"correo": nuevo, "rol": "Cajero", "password": "Clave-larga-r2-sincaja-387"})
            assert r.status_code == 400 and r.json()["detail"]["codigo"] == "rol_sin_caja", r.text
            assert c.put(f"/api/admin/cuentas/{eid}/usuarios/{uv}/rol", json={"rol": "Cajero"}).status_code == 400
            assert c.put(f"/api/admin/cuentas/{eid}/usuarios/{uc}/rol", json={"rol": "Vendedor"}).status_code == 200
            r = c.post(f"/api/admin/cuentas/{cid}/usuarios", json={"correo": nuevo_c, "rol": "Cajero", "password": "Clave-larga-r2-sincaja-387"})
            assert r.status_code == 200, r.text                                         # donde hay caja, igual que siempre
        finally:
            _sin_consola()
        # comercio con caja: el rol propio de solo caja se asigna, pero a un Cajero no se le apaga el punto de venta
        tc = ctok["Administrador"]
        ucc = _uid(com["Cajero"])
        roles_c = {r["rol"]: r for r in c.get("/api/auth/roles", headers=H(tc)).json()["roles"]}
        assert roles_c["Cajero"]["solo_caja"] and not roles_c["Cajero"]["sin_caja"] and roles_c["Caja propia"]["solo_caja"]
        r = c.put(f"/api/auth/usuarios/{ucc}", headers=H(tc), json={"rol": "Cajero", "modulos_ocultos": ["pos"]})
        assert r.status_code == 400 and "no está activo para esta persona" in r.json()["detail"]["mensaje"]
        assert c.put(f"/api/auth/usuarios/{ucc}", headers=H(tc), json={"rol": "Caja propia", "modulos_ocultos": ["rrhh"]}).status_code == 200
        assert c.put(f"/api/auth/usuarios/{ucc}", headers=H(tc), json={"rol": "Vendedor", "modulos_ocultos": ["pos"]}).status_code == 200   # otro rol sí
    finally:
        _sin_consola()
        _borrar(eid, [*correos.values(), nuevo])
        _borrar(cid, [*com.values(), nuevo_c])


def test_apagar_el_punto_de_venta_avisa_de_los_cajeros():
    correos = {"Administrador": "admin.sc3.387@example.test", "Cajero": "cajero.sc3.387@example.test"}
    eid, tok = _empresa("Comercio Apagar r2 387 QA", "comercio", {}, correos, "75")
    t = tok["Administrador"]
    try:
        # Configuración › Usuarios › Módulos por usuario (toda la empresa)
        r = c.put("/api/auth/modulos", headers=H(t), json={"ocultos": ["pos"]})
        assert r.status_code == 200 and correos["Cajero"] in r.json()["aviso"] and "sin nada que hacer" in r.json()["aviso"]
        assert c.get("/api/auth/yo", headers=H(tok["Cajero"])).json()["sin_caja"] == "empresa"
        assert c.put("/api/auth/modulos", headers=H(t), json={"ocultos": ["pos", "tike"]}).json()["aviso"] is None   # ya estaba avisado
        assert c.put("/api/auth/modulos", headers=H(t), json={"ocultos": []}).json()["aviso"] is None
        _consola()
        try:
            # consola: el tipo de negocio (Comercio → Facturación quita el punto de venta) y el plan
            r = c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": "facturacion"})
            assert r.status_code == 200 and correos["Cajero"] in r.json()["aviso"]
            assert c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": "hospitalidad"}).json()["aviso"] is None
            r = c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "hotel", "extras": ["pos"], "habitaciones": 6})
            assert r.status_code == 200 and "aviso" not in r.json()                     # con el extra, la caja sigue
            r = c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "hotel", "extras": [], "habitaciones": 6})
            assert r.status_code == 200 and correos["Cajero"] in r.json()["aviso"] and r.json()["id"] == eid
        finally:
            _sin_consola()
    finally:
        _borrar(eid, correos.values())


def test_pantalla_propia_del_cajero_sin_caja():
    js = _js("app.js")
    assert "sinCaja: null," in js
    assert "this.sinCaja = r.sin_caja || null;" in js and js.count("this.sinCaja = r.sin_caja || null;") == 2     # al entrar y al recargar
    assert "if (sesion.empresa_id && sesion.sinCaja && this.path !== '/configuracion/perfil') return 'sincaja';" in js
    assert '<SinCaja v-else-if="pantalla===\'sincaja\'"></SinCaja>' in js and "PruebaVencida, SinCaja," in js
    i = js.index("const SinCaja = {")
    pantalla = js[i:js.index("\n};\n", i)]
    for texto in ("Su rol solo usa el punto de venta", "Qué hacer:", "Comprobar de nuevo", "#/configuracion/perfil", "Cerrar sesión", "Entrar a otra empresa"):
        assert texto in pantalla, texto
    # no se pide nada de la empresa ni salen los dos avisos rojos
    cargar = js[js.index("  async cargar(completo = false, pre = null) {"):js.index("  async tipoCambio(")]
    assert cargar.index("if (sesion.sinCaja) { if (vigente()) this.listo = true; return; }") < cargar.index("api('/api/arranque')")
    assert "if (err?.reason?.detail?.codigo === 'sin_caja') sesion.sinCaja = true;" in cargar
    assert "toast('No se pudo cargar: ' + (err.reason?.message || err.reason), 'err');" in cargar                   # los demás fallos, igual
    aviso = js[js.index("  avisarFallo(e) {"):]
    assert aviso.index("e?.detail?.codigo === 'sin_caja'") < aviso.index("toast(")
    assert "if (mock.cargado || !token() || !sesion.empresa_id || sesion.sinCaja) return;" in js
    # sin menú ni buscador de contactos
    assert "menu() { return sesion.sinCaja ? [] : menuTipo(sesion.tipo); }" in js
    assert "export function menuVisible() { return sesion.sinCaja ? [] : menuVisibleDe(sesion, hotelActivo); }" in js
    assert 'v-if="sesion.empresa_id && !sesion.modoCajero && !sesion.sinCaja"' in js
    assert "if (this.sinCaja) return '/inicio';" in js
    # respaldo en Inicio: si llega el 403 sin_caja de las alertas, el aviso queda fijo
    ini = _js("pages", "inicio.js")
    i = ini.index("async cargar() {")
    cuerpo = ini[i:ini.index("    },", i)]
    assert "api('/api/inicio/alertas').catch(e => { if (e && e.detail && e.detail.codigo === 'sin_caja') this.error = e.message; return { alertas: [], flujo: null }; })" in cuerpo
    assert "if (this.veResumen) {" in cuerpo and '<div class="alert warn" v-if="error">' in ini


def test_configuracion_no_ofrece_cajero_sin_caja_y_avisa_al_apagar():
    sec = _js("pages", "configuracion", "seccion.js")
    assert "ROLES() { return this.roles ? this.roles.roles.filter(r => !r.sin_caja).map(r => r.rol) : ROLES; }," in sec
    assert '<option v-for="r in rolesCambio" :key="r">' in sec and '<option v-for="r in ROLES" :key="r">' in sec   # cambio de rol / agregar
    assert "rolesCambio() { const a = this.cambio && this.cambio.usuario.rol;" in sec
    assert "|| cajaFija(u, m.codigo)" in sec and "cajaFija(u, c) { return c === 'pos'" in sec
    t = sec[sec.index("    async toggleEmpresa(c, encendido) {"):]
    t = t[:t.index("\n    },")]
    assert t.index("confirm(") < t.index("api('/api/auth/modulos'") and "toast(r.aviso ||" in t
    adm = _js("pages", "admin.js")
    assert "const { aviso, ...cuenta } = r; Object.assign(c, cuenta);" in adm and "(r.aviso ? ' ' + r.aviso : '')" in adm


def test_inicio_sin_resumen_no_esconde_cobros_ni_planilla():
    ini = _js("pages", "inicio.js")
    m = re.search(r"\n    vis\(w\) \{ return (.+?); \},", ini)
    assert m, "no se encontró vis(w) en inicio.js"
    assert "!this.veResumen" in m.group(1) and "'cobros'" in m.group(1) and "'planilla'" in m.group(1), m.group(1)
    assert '<div class="erp-page-tools" v-if="veResumen">' in ini                 # el control sigue siendo de quien ve el resumen
    assert "vis('cobros') && avisos && avisos.flujo" in ini and "vis('planilla') && planilla" in ini


def test_elegir_empresa_sin_empresas_explica_que_no_tiene_acceso():
    js = _js("app.js")
    bloque = js[js.index("const ElegirEmpresa = {"):js.index("const SinCaja")]
    assert "(sesion.empresas || []).length ? 'Elija la empresa' : 'Sin empresas asignadas'" in bloque
    assert "ninguna empresa" in bloque and "Su usuario tiene acceso a varias empresas." in bloque


def test_menu_lateral_no_pinta_grupos_sin_entradas():
    js = _js("app.js")
    nivel = js.split("const MenuNivel = {", 1)[1].split("\n};\n", 1)[0]
    filtro = re.search(r'v-for="c in items\.filter\((\w+)\)"', nivel).group(1)
    assert filtro != "ok", "MenuNivel pinta items.filter(ok): un grupo sin entradas visibles sale vacío"
    metodo = re.search(filtro + r"\(c\) \{([^}]*)\}", nivel).group(1)
    assert "conHijos(c)" in metodo and "this.ok(c)" in metodo, metodo
