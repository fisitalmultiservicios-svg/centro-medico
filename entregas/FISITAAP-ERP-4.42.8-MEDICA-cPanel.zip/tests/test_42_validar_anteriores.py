# -*- coding: utf-8 -*-
"""4.2: validar en Hacienda los comprobantes recibidos del sistema anterior (comprobante del proveedor aceptado y, con el consecutivo
del mensaje de receptor, también la respuesta); menú Reportes con sus tipos."""
import json
import pathlib

from app import main, recepcion
from tests.test_375_costeo import _xml_proveedor
from tests.test_401_recibidos_anteriores import _clave, _mensaje
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)


class _Cli:
    def __init__(self, estados):
        self.estados, self.consultas = estados, []

    def consultar(self, clave):
        self.consultas.append(clave)
        return self.estados.get(clave, {"estado": "no_encontrado", "status": 404})


def test_validar_en_hacienda_comprobante_y_respuesta():
    r = recepcion.Recibido(empresa_id=1, clave="1" * 50, consecutivo="00100001010000000001", total=100, respuesta="05", estado_mensaje="importado", consecutivo_receptor="00100001050000000009")
    cli = _Cli({"1" * 50: {"estado": "aceptado", "status": 200, "fecha": "2026-03-02"}, "1" * 50 + "-00100001050000000009": {"estado": "aceptado", "status": 200}})
    v = recepcion.validar_en_hacienda(cli, r)
    assert v["ok"] and v["comprobante"] == "aceptado" and v["respuesta"] == "aceptado" and "aceptado por Hacienda" in v["texto"]
    assert json.loads(r.validacion)["ok"] and r.validado_en
    r2 = recepcion.Recibido(empresa_id=1, clave="2" * 50, total=100, respuesta="05", estado_mensaje="importado")
    v2 = recepcion.validar_en_hacienda(_Cli({}), r2)
    assert not v2["ok"] and v2["comprobante"] == "no_encontrado" and "no está en Hacienda" in v2["texto"]
    r3 = recepcion.Recibido(empresa_id=1, clave="3" * 50, total=100, respuesta="05", estado_mensaje="importado")
    v3 = recepcion.validar_en_hacienda(_Cli({"3" * 50: {"estado": "aceptado", "status": 200}}), r3)
    assert v3["ok"] and v3["respuesta"] is None and "sin el mensaje de receptor" in v3["texto"]
    v4 = recepcion.validar_en_hacienda(_Cli({"3" * 50: {"estado": "http_error", "status": 500, "error": "caído"}}), r3)
    assert not v4["ok"] and v4["texto"].startswith("No se pudo consultar")


def test_endpoint_valida_los_importados(api, monkeypatch):  # noqa: F811
    c = api
    x1, x2 = _xml_proveedor(31, "55555555"), _xml_proveedor(32, "66666666")
    r = c.post("/api/recepcion/cargar", data={"historico": "1"}, files=[("archivos", ("a.xml", x1, "text/xml")), ("archivos", ("b.xml", x2, "text/xml")),
                                                                        ("archivos", ("b_msg.xml", _mensaje(_clave(x2), "1", "ok").replace(b"</Mensaje>", b"</Mensaje><NumeroConsecutivoReceptor>00100001050000000077</NumeroConsecutivoReceptor>"), "text/xml"))])
    assert r.status_code == 200 and r.json()["historicos"] == 2, r.text
    estados = {_clave(x1): {"estado": "aceptado", "status": 200}, _clave(x2): {"estado": "aceptado", "status": 200}, _clave(x2) + "-00100001050000000077": {"estado": "rechazado", "status": 200, "detalle": "fuera de plazo"}}
    cli = _Cli(estados)
    monkeypatch.setattr(main, "_cliente_hacienda", lambda e: cli)
    r = c.post("/api/recepcion/validar-anteriores")
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["validados"] == 2 and j["ok"] == 1 and j["con_problema"] == 1 and j["pendientes"] == 0
    por = {x["clave"]: x for x in c.get("/api/recepcion").json()}
    assert por[_clave(x1)]["validacion"]["ok"] is True and por[_clave(x2)]["validacion"]["respuesta"] == "rechazado" and por[_clave(x2)]["consecutivo_receptor"] == "00100001050000000077"
    assert c.post("/api/recepcion/validar-anteriores").json()["validados"] == 0       # los ya validados no se repiten solos
    assert c.post("/api/recepcion/validar-anteriores", json=[por[_clave(x1)]["id"]]).json()["validados"] == 1   # salvo que se pidan por id


def test_menu_reportes_con_tipos():
    m = (pathlib.Path(main.__file__).parent / "static/js/menu.js").read_text(encoding="utf-8")
    assert "{ label: 'Reportes', ico: '▤', modulo: 'reportes', children: [" in m
    for to in ("/reportes", "/reportes/favoritos", "/reportes/ejecutivo", "/reportes/modulos", "/reportes/ventas", "/reportes/contables", "/reportes/fiscales", "/reportes/pos", "/reportes/para-trabajar"):
        assert f"to: '{to}'" in m, to
    assert "to: '/reportes/pos', permisos: ['pos', 'reportes'], tipos: ['comercio', 'restaurante', 'hospitalidad', 'servicios']" in m
    js = (pathlib.Path(main.__file__).parent / "static/js/pages/gastos/recepcion.js").read_text(encoding="utf-8")
    assert "✔ Validar en Hacienda" in js and "/api/recepcion/validar-anteriores" in js
