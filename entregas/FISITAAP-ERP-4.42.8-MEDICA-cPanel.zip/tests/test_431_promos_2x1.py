# -*- coding: utf-8 -*-
"""4.31 (la misma mesa, cuarta vuelta): el 2x1 nunca deja una Cerveza gratis (hallazgo P1 de la prueba en navegador).

Causa: aplicarPromos ponía el descuento con descuentoDe({...l, descuento_pct: 0}) y descuentoDe, con el porcentaje en 0, usaba el monto viejo
de la línea (el de las 2 unidades): la Cerveza que quedaba sola salía gratis. Pasaba con un solo equipo («−» en la venta rápida, o un plato
agregado después de cobrar la parte 1) y con dos (el resto de la línea partida que llega por sincronización contaba como un plato que sale y
otro que entra, y eso volvía a calcular la promoción y daba dos avisos falsos).

- El descuento de una promoción se calcula siempre con la cantidad de ahora; sin promoción no queda ninguno.
- Lo que queda de una línea partida (`de`) conserva el 2x1 con que se partió (salvo que el cajero le cambie la cantidad).
- El descuento que puso el cajero, el cupón y los puntos (también los de un pedido en línea) no se tocan.
- El resto que llega de otro equipo en lugar de su línea no cuenta como plato agregado ni quitado.
Los métodos reales de caja.js (y descuentoDe real) en dos «equipos», contra los servidores falsos de tests/test_431_cobro_reclamo_pantallas.py.
Precios con IVA: Cerveza ₡1 130 (2x1), Casado ₡3 390, Café ₡791. Nada va a la red ni a una impresora; solo correos @example.test."""
import json

from tests.test_425_ultimos_pantallas import _node
from tests.test_431_cobro_reclamo_pantallas import ARNES_COBRO, _fuente
from tests.test_431_misma_mesa_pantallas import ARNES_MESA, VUE, _js, _linea, _metodo, _tramo

DESCUENTO_FALSO = "    descuentoDe(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); return Math.max(0, Math.min(m, l.descuento_pct ? m * (+l.descuento_pct) / 100 : (+l.descuento || 0))); } });"


def _arnes() -> str:
    k = _js("pages/pos/caja.js")
    fuente = _fuente() + ",\n" + ",\n".join([_linea(k, "descuentoDe(l) {"), _linea(k, "async cambiarCantidad(l, delta) {"), _linea(k, "descuentoPct(l, pct) {"), _linea(k, "async quitar(l) {")])
    a = ARNES_MESA % {"fuente": json.dumps(fuente)}
    cambios = (("STORE, async () => ({}), A.monedas", "STORE, (u, o) => globalThis.API(u, o, n), A.monedas"),
               ("  A.mock.alCambiarIds((k, c) => vm.seguirIds(k, c));\n  return vm;\n}", "  A.mock.alCambiarIds((k, c) => vm.seguirIds(k, c));\n  return EXTRA(vm, n);\n}"),
               ("const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); t += m", "const m = (+l.cantidad || 0) * (+l.precio_unitario || 0) - this.descuentoDe(l); t += m"))
    for viejo, nuevo in cambios:
        assert a.count(viejo) == 1, viejo
        a = a.replace(viejo, nuevo)
    c = ARNES_COBRO
    assert c.count(DESCUENTO_FALSO) == 1                     # el descuentoDe de caja.js, no la copia de la otra prueba
    c = c.replace(DESCUENTO_FALSO, "  });")
    return a + c + PROMOS


PROMOS = r"""
const PROMO = [{ tipo: '2x1', nombre: '2x1 cervezas', productos: [4] }];
const P_CERVEZA = { id: 4, nombre: 'Cerveza', precio: 1000, tarifa: 13 }, P_CASADO = { id: 1, nombre: 'Casado', precio: 3000, tarifa: 13 }, P_CAFE = { id: 5, nombre: 'Café', precio: 700, tarifa: 13 };
const ver = vm => vm.lineas.map(l => [l.detalle, l.cantidad, l.descuento_pct, r2(vm.descuentoDe(l))]);   // el descuento que de verdad se cobra
const FALSOS = ['Se sumó 1 plato', 'Se sumaron', 'En otro equipo se quitó', 'En otro equipo se quitaron'];
const falsos = vm => avisos(vm).filter(t => FALSOS.some(f => t.startsWith(f)));
// la Mesa 6 con esos productos (2x1 aplicado), comanda enviada; abierta en A y en B
async function mesa(productos) {
  reiniciarCobro(); reiniciar();
  const a = await equipo(), b = await equipo(); a.promosActivas = PROMO; b.promosActivas = PROMO;
  a.abrirMesa(M6); for (const p of productos) a.agregar(p); await comanda(a);
  await b.sincronizar(); b.abrirMesa(M6); await a.sincronizar(); a.abrirMesa(M6);
  return [a, b];
}
const cobrarParte = async vm => { vm._alDia = 0; await vm.cobrarParte(2); await conPago(vm); await vm.cobrar(); await hastaLibre(); await vm.A.mock.guardarTodo(); };
"""


def _correr(tmp_path, guion):
    return _node(tmp_path, _arnes() + guion + "\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n", archivos=("api.js", "pages/pos/_fusion.js"), falsos=VUE)


def test_un_equipo_venta_rapida_y_partes_en_node(tmp_path):
    r = _correr(tmp_path, """
// venta rápida: 2 Cervezas en 2x1 y «−» en la línea: queda 1 Cerveza sin promoción (₡1 130), no gratis
reiniciarCobro(); reiniciar();
let v = await equipo(); v.promosActivas = PROMO; v.vista = 'venta';
v.agregar(P_CERVEZA); v.agregar(P_CERVEZA);
out.rapida = { dos: [ver(v), v.totalDe(v.lineas, false)] };
await v.cambiarCantidad(v.lineas[0], -1);
out.rapida.una = [ver(v), v.totalDe(v.lineas, false)];
await v.abrirPago(); await v.cobrar(); await hastaLibre();
out.rapida.emitidos = emitidos().map(x => x[1]);
// mesa, un solo equipo: «Cobrar la parte 1» y «Cobrar parte 2»
let [a] = await mesa([P_CERVEZA, P_CERVEZA]);
await cobrarParte(a); a.abrirMesa(M6); await cobrarParte(a);
out.partes = emitidos().map(x => x[1]);
// mesa, un solo equipo: después de la parte 1 se agrega un Café en la misma pantalla y se cobra la parte 2
[a] = await mesa([P_CERVEZA, P_CERVEZA]);
await cobrarParte(a); a.abrirMesa(M6); a.agregar(P_CAFE); await comanda(a); a.abrirMesa(M6);
out.cafe = { lineas: ver(a) };
await cobrarParte(a);
out.cafe.emitidos = emitidos().map(x => x[1]);
""")
    x = r["rapida"]
    assert x["dos"] == [[["Cerveza", 2, 50, 1000]], 1130], r
    assert x["una"] == [[["Cerveza", 1, 0, 0]], 1130] and x["emitidos"] == [1130], r          # antes: descuento 1000 y total ₡0
    assert r["partes"] == [565, 565], r
    assert r["cafe"]["lineas"] == [["Cerveza", 1, 50, 500], ["Café", 1, 0, 0]], r            # el resto de la línea partida conserva el 2x1
    assert r["cafe"]["emitidos"] == [565, 1356], r                                            # ₡1 921 en total (antes la Cerveza salía gratis: ₡791)


def test_dos_equipos_la_cuenta_partida_que_llega_en_node(tmp_path):
    r = _correr(tmp_path, """
// A cobra la parte 1; B se sincroniza y cobra la parte 2 («Cobrar parte 2»)
let [a, b] = await mesa([P_CERVEZA, P_CERVEZA]);
await cobrarParte(a); await b.sincronizar();
out.parte = { lineasB: ver(b), falsos: falsos(b) };
await cobrarParte(b);
out.parte.emitidos = emitidos().map(x => x[1]); out.parte.servidor = servidor().length;
// lo mismo, pero B cobra con F9 directo
[a, b] = await mesa([P_CERVEZA, P_CERVEZA]);
await cobrarParte(a); b._alDia = 0; await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
out.f9 = { emitidos: emitidos().map(x => x[1]), falsos: falsos(b), servidor: servidor().length };
// «cobrar ahora solo esos»: A cobra 1 Cerveza de 2 y B, ya sincronizado, cobra el resto (Casado y la otra Cerveza) con F9
[a, b] = await mesa([P_CASADO, P_CERVEZA, P_CERVEZA]);
await a.abrirDividir(); a.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 1: 1 } }; await a.confirmarDividir(); await conPago(a); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await b.sincronizar(); b._alDia = 0; await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
out.solo = { emitidos: emitidos().map(x => x[1]), suma: suma(), falsos: falsos(b) };
// después de la parte 1 (A), B agrega un Café y A cobra la parte 2
[a, b] = await mesa([P_CERVEZA, P_CERVEZA]);
await cobrarParte(a); await b.sincronizar(); b.agregar(P_CAFE); out.cafe = { lineasB: ver(b) }; await comanda(b);
await a.sincronizar(); a.abrirMesa(M6); out.cafe.lineasA = ver(a);
await cobrarParte(a);
out.cafe.emitidos = emitidos().map(x => x[1]); out.cafe.suma = suma();
""")
    p = r["parte"]
    assert p["lineasB"] == [["Cerveza", 1, 50, 500]] and p["falsos"] == [], r                  # antes: 0 % con ₡1 000 (gratis) y dos avisos falsos
    assert p["emitidos"] == [565, 565] and p["servidor"] == 0, r                              # antes: ₡565 + ₡0
    assert r["f9"] == {"emitidos": [565, 565], "falsos": [], "servidor": 0}, r
    assert r["solo"]["emitidos"] == [565, 3955] and r["solo"]["suma"] == 4520 and r["solo"]["falsos"] == [], r   # antes: ₡565 + ₡3 390
    c = r["cafe"]
    assert c["lineasB"] == [["Cerveza", 1, 50, 500], ["Café", 1, 0, 0]] and c["lineasA"] == [["Cerveza", 1, 50, 500], ["Café", 1, 0, 0]], r
    assert c["emitidos"] == [565, 1356] and c["suma"] == 1921, r                              # antes: la parte 2 en ₡791


def test_lo_que_no_es_de_una_promocion_no_se_toca_en_node(tmp_path):
    r = _correr(tmp_path, """
reiniciarCobro(); reiniciar();
const v = await equipo(); v.promosActivas = PROMO; v.vista = 'venta';
v.agregar(P_CASADO); v.descuentoPct(v.lineas[0], 10);
// la línea de un pedido en línea con el cupón repartido (sin descuento_manual, como la arma pedidos.py) y una con un monto de descuento
v.lineas.push({ producto_id: 4, detalle: 'Cerveza', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento_pct: 10, descuento: 100, promo: 'Cupón QA', nota: '', enviado: 'E1', ronda: 1 });
v.lineas.push({ producto_id: 4, detalle: 'Cerveza', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento_pct: 0, descuento: 200, promo: '', nota: '', enviado: 'E1', ronda: 1 });
v.agregar(P_CERVEZA); v.agregar(P_CERVEZA);
out.otros = ver(v);
// el cajero quita su descuento (0 %): no queda el monto de antes
v.descuentoPct(v.lineas[0], 0); out.cero = ver(v)[0];
// el resto de una línea partida conserva su 2x1, salvo que el cajero le cambie la cantidad
v.lineas = [{ producto_id: 4, detalle: 'Cerveza', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento_pct: 50, descuento: 1000, promo: '2x1 cervezas', nota: '', enviado: 'E1', ronda: 1, lid: 'lR', de: 'lC' }];
v.aplicarPromos(); out.resto = ver(v);
await v.cambiarCantidad(v.lineas[0], 2); out.resto_mas = ver(v);
await v.cambiarCantidad(v.lineas[0], -2); out.resto_menos = ver(v);
// contarCambio: el resto que llega en lugar de su línea no cuenta; si la línea sigue, el resto sí es un plato nuevo
const F = v.F;
out.cuenta = [F.contarCambio([{ lid: 'a' }, { lid: 'b' }], [{ lid: 'a2', de: 'a' }, { lid: 'b' }]), F.contarCambio([{ lid: 'a' }], [{ lid: 'a' }, { lid: 'a2', de: 'a' }]),
  F.contarCambio([{ lid: 'a' }, { lid: 'b' }], [{ lid: 'c' }]), F.contarCambio([{ lid: 'a' }], [{ lid: 'a2', de: 'a' }, { lid: 'a3', de: 'a' }])];
""")
    assert r["otros"] == [["Casado", 1, 10, 300], ["Cerveza", 1, 10, 100], ["Cerveza", 1, 0, 200], ["Cerveza", 2, 50, 1000]], r
    assert r["cero"] == ["Casado", 1, 0, 0], r                                                  # antes: 0 % y ₡300 de descuento
    assert r["resto"] == [["Cerveza", 1, 50, 500]], r                                            # el monto, de la cantidad de ahora
    assert r["resto_mas"] == [["Cerveza", 3, 33.33, 999.9]] and r["resto_menos"] == [["Cerveza", 1, 0, 0]], r
    assert r["cuenta"] == [{"agregadas": 0, "quitadas": 0}, {"agregadas": 1, "quitadas": 0}, {"agregadas": 1, "quitadas": 2}, {"agregadas": 0, "quitadas": 0}], r


def test_contrato_de_aplicar_promos():
    k = _js("pages/pos/caja.js")
    ap = _metodo(k, "aplicarPromos(forzar) {")
    assert "descuentoDe({ ...l, descuento_pct: pct })" not in ap and "descuento_pct: pct, descuento: 0 }" in ap   # nunca el monto viejo
    assert "this.aplicarPromos(l);" in _linea(k, "async cambiarCantidad(l, delta) {")
    assert "descuento_pct: pct, descuento: 0 }" in _linea(k, "descuentoPct(l, pct) {")
    # 4.31 (quinta vuelta): la casilla de la cantidad también vuelve a calcular la promoción de esa línea (como «−» y «+»)
    # 4.39 (decimotercera vuelta): con cantidad > 0 la casilla sigue calculando la promoción de esa línea; con 0 o vacía quita el plato como «✕» (quitar, que
    # también vuelve a calcular el 2x1 de las que quedan); el caso se prueba en tests/test_439_decimotercera_vuelta.py (V2, también el 2x1 con la casilla en 3)
    assert '<input class="inp mini" type="number" step="0.001" min="0" v-model.number="l.cantidad" @change="+l.cantidad > 0 ? aplicarPromos(l) : quitar(l)" style="width:58px;text-align:center">' in k
    # 4.39 (decimocuarta vuelta): quitar, con la clave de anular y la línea en 0, devuelve ANTES de pedir la clave la cantidad de la base (y, en una línea
    # partida o marcada, su 2x1 de la base) y vuelve a calcular las promociones; al quitar sigue recalculando el 2x1 de las que quedan, como aquí se exige.
    # El caso (con la clave negada, el 2x1 de 2 Cervezas vuelve y se cobra ₡2 034) se prueba en tests/test_439_decimocuarta_vuelta.py (U1)
    assert "this.aplicarPromos(); this.cuentaVacia();" in _linea(k, "async quitar(l) {")
    assert _linea(k, "async quitar(l) {").count("this.lineas = this.lineas.filter(x => x !== l); this.aplicarPromos(); this.cuentaVacia(); }") == 1


def test_quinta_m1_el_par_del_2x1_en_dos_lineas_en_node(tmp_path):
    """M1 (medio): el 2x1 repartido en dos líneas del mismo producto y la misma comanda (la segunda Cerveza se agregó con la cuenta ya
    guardada). Después de «cobrar ahora solo esos» con una, la otra se cobraba a precio completo (₡1 695 por dos Cervezas en 2x1). Ahora
    conserva la promoción con que se formó el par, con dos equipos y con uno solo (y un Café agregado antes de cobrar); +/− la vuelve a
    calcular. Y una unidad sola nunca queda con el 2x1 al quitar la otra (✕) ni al escribir la cantidad."""
    r = _correr(tmp_path, """
async function dosLineas() {
  reiniciarCobro(); reiniciar();
  const a = await equipo(), b = await equipo(); a.promosActivas = PROMO; b.promosActivas = PROMO;
  a.abrirMesa(M6); a.agregar(P_CERVEZA); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.agregar(P_CERVEZA); await comanda(a);
  await b.sincronizar(); b.abrirMesa(M6); await a.sincronizar(); a.abrirMesa(M6);
  return [a, b];
}
const soloUna = async vm => { await vm.abrirDividir(); vm.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } }; await vm.confirmarDividir(); await conPago(vm); await vm.cobrar(); await hastaLibre(); await vm.A.mock.guardarTodo(); };
// dos equipos: A cobra una Cerveza; B, con la mesa abierta, se sincroniza y cobra la otra
let [a, b] = await dosLineas();
out.inicio = ver(a);
await soloUna(a); await b.sincronizar(); out.dos = { lineasB: ver(b), falsos: falsos(b) };
b._alDia = 0; await b.abrirPago(); await b.cobrar(); await hastaLibre();
out.dos.emitidos = emitidos().map(x => x[1]); out.dos.suma = suma();
// un solo equipo: después de «solo esos» se agrega un Café y se cobra lo demás
[a] = await dosLineas();
await soloUna(a); a.abrirMesa(M6); a.agregar(P_CAFE); out.cafe = { lineas: ver(a) };
a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre();
out.cafe.emitidos = emitidos().map(x => x[1]); out.cafe.suma = suma();
// +/− sobre la que quedó: se vuelve a calcular (2 → 2x1; 1 → sin promoción)
[a] = await dosLineas();
await soloUna(a); a.abrirMesa(M6);
const l = a.lineas.find(x => x.detalle === 'Cerveza'); out.marca = l.promo_fija;
await a.cambiarCantidad(l, 1); out.mas = [ver(a), 'promo_fija' in l]; await a.cambiarCantidad(l, -1); out.menos = [ver(a), l.promo_fija];
/* 4.31 (sexta vuelta): vuelve a la cantidad que tenía al marcarse: vuelve la marca y el 2x1 del par ya cobrado; se cobra ₡565 (₡1 130 por las dos) */
a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); out.menos_cobro = [emitidos().map(x => x[1]), suma()];
// quitar (✕) una de dos Cervezas en 2x1 y escribir la cantidad en la casilla
reiniciarCobro(); reiniciar();
const v = await equipo(); v.promosActivas = PROMO; v.vista = 'venta';
v.lineas.push({ producto_id: 4, detalle: 'Cerveza', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento_pct: 0, descuento: 0, promo: '', nota: '', enviado: 'E1', ronda: 1, lid: 'l1' });
v.lineas.push({ producto_id: 4, detalle: 'Cerveza', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento_pct: 0, descuento: 0, promo: '', nota: '', enviado: 'E1', ronda: 1, lid: 'l2' });
v.aplicarPromos(); out.par = ver(v);
await v.quitar(v.lineas[0]); out.quitar = ver(v);
v.lineas = [{ producto_id: 4, detalle: 'Cerveza', cantidad: 2, precio_unitario: 1000, tarifa: 13, descuento_pct: 0, descuento: 0, promo: '', nota: '', enviado: null, ronda: 0, lid: 'l3' }];
v.aplicarPromos(); v.lineas[0].cantidad = 1; v.aplicarPromos(v.lineas[0]); out.casilla = ver(v);
""")
    assert r["inicio"] == [["Cerveza", 1, 50, 500], ["Cerveza", 1, 50, 500]], r
    d = r["dos"]
    assert d["lineasB"] == [["Cerveza", 1, 50, 500]] and d["falsos"] == ["En otro equipo se quitó o cobró 1 plato de Mesa 6. La cuenta quedó como está ahora."], r   # cierto: A cobró 1
    assert d["emitidos"] == [565, 565] and d["suma"] == 1130, r                                 # antes: ₡565 + ₡1 130
    c = r["cafe"]
    assert c["lineas"] == [["Cerveza", 1, 50, 500], ["Café", 1, 0, 0]] and c["emitidos"] == [565, 1356] and c["suma"] == 1921, r
    assert r["marca"] == 1 and r["mas"] == [[["Cerveza", 2, 50, 1000]], False], r            # la marca guarda la cantidad que tenía (1)
    assert r["menos"] == [[["Cerveza", 1, 50, 500]], 1] and r["menos_cobro"] == [[565, 565], 1130], r   # sexta vuelta: vuelve la marca (en la quinta: sin promoción, ₡1 695 por dos)
    assert r["par"] == [["Cerveza", 1, 50, 500], ["Cerveza", 1, 50, 500]], r
    assert r["quitar"] == [["Cerveza", 1, 0, 0]] and r["casilla"] == [["Cerveza", 1, 0, 0]], r    # antes: la que quedaba seguía al 50 %


# ================================================================================================================ sexta vuelta
S2 = """
// S2: en la Mesa 6 (comanda enviada) A quita (✕) o baja («−» o la casilla) un plato y cobra con F9. `cuando`: «ya» (sin bajar la lista), «baja»
// (abrir el cobro baja la lista), «sinc» (pasaron unos segundos y se sincronizó), «pendiente» (lo guardó y la subida no llegó: el cobro igual)
const MIENTRAS = vm => avisos(vm).filter(t => t.startsWith('Mientras se cobraba'));
const f0 = globalThis.fetch; let cortar = false;
globalThis.fetch = async (url, opt) => { if (cortar && url === '/api/registros/pos_espera/cambios') throw new TypeError('Failed to fetch'); return f0(url, opt); };
const HACER = {
  quitar: async a => a.quitar(a.lineas.find(l => l.detalle === 'Café')),
  menos: async a => a.cambiarCantidad(a.lineas.find(l => l.detalle === 'Casado'), -1),
  casilla: async a => { const l = a.lineas.find(l => l.detalle === 'Casado'); l.cantidad = 1; a.aplicarPromos(l); },
};
const F9 = async vm => { await vm.abrirPago(); await vm.cobrar(); await hastaLibre(); cortar = false; await vm.A.mock.guardarTodo(); await vm.sincronizar(); await espera(30); };
const fin = vm => ({ emitidos: emitidos().map(x => x[1]), servidor: servidor().map(s => s.platos), mientras: MIENTRAS(vm), falsos: falsos(vm), pantalla: vm.lineas.length, vista: vm.vista });
async function s2(como, cuando) {
  const [a] = await mesa(como === 'quitar' ? [P_CASADO, P_CAFE] : [P_CASADO, P_CASADO, P_CAFE]);
  await HACER[como](a);
  if (cuando === 'sinc') await a.sincronizar();
  if (cuando === 'pendiente') { cortar = true; a.persistirCuenta(); }
  a._alDia = cuando === 'baja' ? 0 : Date.now();
  await F9(a); return fin(a);
}
for (const como of Object.keys(HACER)) for (const cuando of ['ya', 'baja', 'sinc', 'pendiente']) out[como + '_' + cuando] = await s2(como, cuando);
// 2 Cervezas en 2x1 en dos líneas (la segunda se agregó con la cuenta ya guardada): ✕ o «−» en una y F9
async function dosLineas() {
  reiniciarCobro(); reiniciar();
  const a = await equipo(); a.promosActivas = PROMO;
  a.abrirMesa(M6); a.agregar(P_CERVEZA); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.agregar(P_CERVEZA); await comanda(a); await a.sincronizar(); a.abrirMesa(M6);
  return a;
}
let a = await dosLineas(); out.dos_inicio = ver(a);
await a.quitar(a.lineas[1]); out.dos_quitar = { lineas: ver(a) }; a._alDia = Date.now(); await F9(a); Object.assign(out.dos_quitar, fin(a));
a = await dosLineas(); await a.cambiarCantidad(a.lineas[0], -1); out.dos_menos = { lineas: ver(a) }; a._alDia = 0; await F9(a); Object.assign(out.dos_menos, fin(a));
// lo que otro equipo agregó mientras tanto sí queda en la mesa (con el aviso)
let b; [a, b] = await mesa([P_CASADO, P_CAFE]);
await HACER.quitar(a); b.agregar(P_CERVEZA); await comanda(b);
a._alDia = Date.now(); await F9(a); out.otro = fin(a);
"""


def test_sexta_s2_lo_quitado_o_bajado_antes_de_f9_no_queda_en_la_mesa_en_node(tmp_path):
    """S2 (alto): un plato ya enviado que se quita (✕) o se baja («−» o la casilla) y enseguida se cobra con F9 se quedaba en la mesa «sin
    cobrar», con el aviso falso «Mientras se cobraba … otro equipo le agregó 1 plato»: la baja llevaba solo lo cobrado. Ahora lleva también lo
    que esta pantalla quitó o bajó (su base y su guardado sin confirmar); lo que otro equipo agregó mientras tanto sigue quedando."""
    r = _correr(tmp_path, S2)
    for k, x in r.items():
        if not k.startswith(("quitar_", "menos_", "casilla_")):
            continue
        cuanto = [3390] if k.startswith("quitar_") else [4181]                      # Casado ₡3 390 (+ Café ₡791)
        assert x["emitidos"] == cuanto and x["servidor"] == [] and x["mientras"] == [] and x["falsos"] == [], (k, x)   # antes: Café ×1 o Casado ×1 en la mesa
        assert x["pantalla"] == 0 and x["vista"] == "mesas", (k, x)
    assert r["dos_inicio"] == [["Cerveza", 1, 50, 500], ["Cerveza", 1, 50, 500]], r
    for k in ("dos_quitar", "dos_menos"):
        x = r[k]
        assert x["lineas"] == [["Cerveza", 1, 0, 0]] and x["emitidos"] == [1130] and x["servidor"] == [] and x["mientras"] == [], (k, r)
    o = r["otro"]
    assert o["emitidos"] == [3390] and o["servidor"] == [["Cerveza×1"]], r
    assert o["mientras"] == ["Mientras se cobraba o se cerraba Mesa 6, otro equipo le agregó 1 plato. Quedó en la mesa sin cobrar."], r


def test_sexta_m2_la_parte_que_vuelve_sola_conserva_el_2x1_en_node(tmp_path):
    """M2 (medio): la parte de un cobro que se cancela y vuelve como línea suelta (la línea a la que se sumaba ya no está) perdía el 2x1: su
    par ya se cobró en la otra parte y esa Cerveza se cobraba completa (₡1 695 por dos Cervezas en 2x1). Ahora conserva la marca
    (`promo_fija`): sin la cuenta (rama sin cuenta de devolverParte) o con la cuenta sin esa línea. 4.31 (séptima vuelta): solo porque el
    servidor confirmó que su par se cobró; con la copia atrasada ya no pasa por `<lid>+v` (no se suma a lo que el servidor dio por cobrado)."""
    r = _correr(tmp_path, """
async function m2(variante) {
  const [a, b] = await mesa(variante === 'con_cuenta' ? [P_CERVEZA, P_CERVEZA, P_CAFE] : [P_CERVEZA, P_CERVEZA]);
  a._alDia = 0; await a.cobrarParte(2); await a.A.mock.guardarTodo(); await conPago(a);
  await b.sincronizar(); b.abrirMesa(M6); b._alDia = 0;
  if (variante === 'con_cuenta') { const i = b.lineas.findIndex(l => l.detalle === 'Cerveza'); await b.abrirDividir(); b.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { [i]: 1 } }; await b.confirmarDividir(); await conPago(b); }
  else await b.abrirPago();
  await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  if (variante !== 'atrasado') await a.sincronizar();
  await a.cerrarPago(); await a.A.mock.guardarTodo(); await a.sincronizar(); await espera(30);
  const x = { b: emitidos().map(e => e[1]), vuelta: S.items.map(c => c.lineas.map(l => [l.detalle, l.cantidad, l.descuento_pct, l.promo_fija ?? null])) };
  a.abrirMesa(M6); x.pantalla = ver(a); a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  x.emitidos = emitidos().map(e => e[1]); x.suma = suma(); x.servidor = S.items.length; x.mientras = avisos(a).filter(t => t.includes('mientras usted agregaba platos')).length;
  return x;
}
for (const v of ['sin_cuenta', 'atrasado', 'con_cuenta']) out[v] = await m2(v);
""")
    for k in ("sin_cuenta", "atrasado"):
        x = r[k]
        assert x["b"] == [565] and x["vuelta"] == [[["Cerveza", 1, 50, 1]]] and x["pantalla"] == [["Cerveza", 1, 50, 500]], (k, r)
        assert x["emitidos"] == [565, 565] and x["suma"] == 1130 and x["servidor"] == 0 and x["mientras"] == 0, (k, r)   # antes: ₡565 + ₡1 130
    c = r["con_cuenta"]
    assert c["b"] == [565] and c["pantalla"] == [["Café", 1, 0, 0], ["Cerveza", 1, 50, 500]], r
    assert c["emitidos"] == [565, 1356] and c["suma"] == 1921 and c["servidor"] == 0, r              # antes: ₡565 + ₡1 921 (₡2 486)


# ================================================================================================================ séptima vuelta
def _reloj() -> str:
    """El observador `promosActivas` de caja.js (el reloj de 30 s lo dispara), tal cual."""
    w = _tramo(_js("pages/pos/caja.js"), "  watch: {", "  methods: {")
    linea = next(x.strip() for x in w.splitlines() if x.strip().startswith("promosActivas() {"))
    return linea.split("   /*")[0].split("   //")[0].strip().rstrip(",")


V1 = """
const W = { RELOJ };   // el observador de caja.js que dispara el reloj cada 30 s
const tic = vm => W.promosActivas.call(vm);
// Cerveza ×2 en 2x1 en una línea (y un Café). A abre «Cobrar la parte 1» y pasa el reloj de 30 s; B cobra lo que quedó de la Cerveza (F9 con
// toda la cuenta, o «Cobrar estos platos» con solo la Cerveza si hay Café) o la quita (✕); A cancela (Esc) con la lista al día o atrasada
// (`solo`: A abre «Cobrar estos platos» con 1 de las 2 Cervezas en lugar de la parte 1)
async function v1(hace, cafe, copia, solo) {
  const [a, b] = await mesa(cafe ? [P_CERVEZA, P_CERVEZA, P_CAFE] : [P_CERVEZA, P_CERVEZA]);
  a._alDia = 0;
  if (solo) { await a.abrirDividir(); a.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { 0: 1 } }; await a.confirmarDividir(); }
  else await a.cobrarParte(2);
  await a.A.mock.guardarTodo(); await conPago(a);
  tic(a); const x = { parte: ver(a) };
  await b.sincronizar(); b.abrirMesa(M6); b._alDia = 0;
  const i = b.lineas.findIndex(l => l.detalle === 'Cerveza');
  if (hace === 'quita') { await b.quitar(b.lineas[i]); await mesas(b); }
  else if (cafe) { await b.abrirDividir(); b.dividir = { modo: 'articulos', partes: 2, destino: 'cobrar', sel: { [i]: 1 } }; await b.confirmarDividir(); await conPago(b); await b.cobrar(); }
  else { await b.abrirPago(); await b.cobrar(); }
  await hastaLibre(); await b.A.mock.guardarTodo();
  if (copia === 'al_dia') await a.sincronizar();
  tic(a);
  await a.cerrarPago(); await a.A.mock.guardarTodo(); await a.sincronizar(); await espera(30);
  Object.assign(x, { b: emitidos().map(e => e[1]), vuelta: S.items.map(c => c.lineas.map(l => [l.detalle, l.cantidad, l.descuento_pct, l.promo_fija ?? null])) });
  a.abrirMesa(M6); x.pantalla = ver(a); a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  x.emitidos = emitidos().map(e => e[1]); x.suma = suma(); x.servidor = S.items.length;
  return x;
}
for (const copia of ['al_dia', 'atrasada']) {
  out['cobra_' + copia] = await v1('cobra', false, copia); out['cobra_cafe_' + copia] = await v1('cobra', true, copia);
  out['quita_' + copia] = await v1('quita', false, copia); out['quita_cafe_' + copia] = await v1('quita', true, copia);
  out['solo_' + copia] = await v1('cobra', false, copia, true); out['solo_quita_' + copia] = await v1('quita', false, copia, true);
}
"""


def test_septima_v1_lo_que_vuelve_conserva_el_2x1_solo_si_su_par_se_cobro_en_node(tmp_path):
    """V1 (alto, dos equipos): la parte que vuelve perdía el 2x1 cuando la pantalla ya no tenía la Cerveza en su copia («sin cuenta» o «cuenta
    con un Café»): ₡565 de más. La causa en pantalla: el reloj de 30 s volvía a calcular las promociones de la parte abierta (una Cerveza sola
    al 0 %); ahora no la toca. Regla única en todas las ramas de devolverParte: la línea que vuelve conserva el 2x1 (`promo_fija`) SOLO si el
    servidor confirmó que su par se cobró («cambiada», «ganada»… con `pares_cobrados`); si su par se quitó (✕), se calcula como cualquier
    línea (₡1 130 por una Cerveza), también cuando el servidor la deja sola (`<lid>+v`, ahora sin la marca)."""
    r = _correr(tmp_path, V1.replace("RELOJ", _reloj()))
    for copia in ("al_dia", "atrasada"):
        c = r["cobra_" + copia]
        assert c["parte"] == [["Cerveza", 1, 50, 500]], (copia, r)                               # el reloj no le quita el 2x1 a la parte abierta
        assert c["b"] == [565] and c["vuelta"] == [[["Cerveza", 1, 50, 1]]] and c["pantalla"] == [["Cerveza", 1, 50, 500]], (copia, r)
        assert c["emitidos"] == [565, 565] and c["suma"] == 1130 and c["servidor"] == 0, (copia, r)   # antes: ₡565 + ₡1 130
        cc = r["cobra_cafe_" + copia]
        assert cc["parte"] == [["Cerveza", 1, 50, 500], ["Café", 0.5, 0, 0]] and cc["b"] == [565], (copia, r)
        assert cc["pantalla"] == [["Café", 1, 0, 0], ["Cerveza", 1, 50, 500]] and cc["emitidos"] == [565, 1356] and cc["suma"] == 1921 and cc["servidor"] == 0, (copia, r)   # antes: ₡2 486
        q = r["quita_" + copia]
        assert q["parte"] == [["Cerveza", 1, 50, 500]] and q["b"] == [], (copia, r)
        assert all(l[3] is None for v in q["vuelta"] for l in v), (copia, r)                    # sin la marca: su par no se cobró, se quitó
        assert q["pantalla"] == [["Cerveza", 1, 0, 0]] and q["emitidos"] == [1130] and q["suma"] == 1130 and q["servidor"] == 0, (copia, r)   # antes: ₡565 (una Cerveza sola con 2x1)
        qc = r["quita_cafe_" + copia]
        assert all(l[3] is None for v in qc["vuelta"] for l in v), (copia, r)
        assert sorted(qc["pantalla"]) == [["Café", 1, 0, 0], ["Cerveza", 1, 0, 0]] and qc["emitidos"] == [1921] and qc["servidor"] == 0, (copia, r)
        s = r["solo_" + copia]                                                                  # «Cobrar estos platos» con 1 de 2: lo mismo
        assert s["parte"] == [["Cerveza", 1, 50, 500]] and s["b"] == [565] and s["vuelta"] == [[["Cerveza", 1, 50, 1]]], (copia, r)
        assert s["emitidos"] == [565, 565] and s["suma"] == 1130 and s["servidor"] == 0, (copia, r)
        sq = r["solo_quita_" + copia]
        assert sq["b"] == [] and all(l[3] is None for v in sq["vuelta"] for l in v) and sq["emitidos"] == [1130] and sq["servidor"] == 0, (copia, r)
    assert r["quita_al_dia"]["vuelta"] == [[["Cerveza", 1, 0, None]]], r                       # la que vuelve sola ya se guarda calculada
    assert r["quita_atrasada"]["vuelta"] == [[["Cerveza", 1, 50, None]]], r                    # `<lid>+v` del servidor: sin la marca (la caja la calcula al abrirla)
