"""3.85: al quitar de la consola a un administrador del sistema que no pertenece a ninguna empresa, su cuenta queda bloqueada y no
aparece en ningún lado para desbloquearla. Volver a agregarlo la reactiva con una contraseña temporal nueva (la verificación en dos
pasos se conserva). Si la cuenta bloqueada sí pertenece a alguna empresa, se sigue pidiendo desbloquearla en Cuentas."""
import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine, init_db
from app.main import app

CORREOS = ("principal.385@example.test", "vendedora.385@example.test", "conempresa.385@example.test")


def _usuario(correo):
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
        if u:
            s.expunge(u)
        return u


@pytest.fixture
def consola():
    init_db()
    with Session(engine) as s:
        yo = auth.Usuario(correo=CORREOS[0], nombre="Principal QA", password_hash=auth.hash_password("Clave-larga-385-qa"), es_superadmin=True,
                          admin_principal=True, mfa_activo=True)
        s.add(yo); s.commit(); s.refresh(yo); s.expunge(yo)
    app.dependency_overrides[auth.solo_usuario] = lambda: _usuario(yo.correo)
    try:
        yield TestClient(app), yo
    finally:
        app.dependency_overrides.pop(auth.solo_usuario, None)
        with Session(engine) as s:
            ids = [x.id for x in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_(CORREOS))).all()]  # type: ignore[attr-defined]
            for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id.in_(ids))).all():  # type: ignore[attr-defined]
                s.delete(m)
            for x in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_(CORREOS))).all():  # type: ignore[attr-defined]
                s.delete(x)
            s.commit()


def test_quitar_y_volver_a_agregar_reactiva_la_cuenta(consola):
    c, _ = consola
    r = c.post("/api/admin/administradores", json={"nombre": "Vendedora QA", "correo": CORREOS[1], "enviar_correo": False}); assert r.status_code == 200, r.text
    primera = r.json()["password_temporal"]
    v = _usuario(CORREOS[1])
    with Session(engine) as s:                                   # ya había entrado y activado su verificación en dos pasos
        u = s.get(auth.Usuario, v.id); u.mfa_activo, u.debe_cambiar_password = True, False; s.add(u); s.commit()
    r = c.delete(f"/api/admin/administradores/{v.id}"); assert r.status_code == 200 and r.json()["bloqueado"] is True
    r = c.post("/api/admin/administradores", json={"nombre": "Vendedora QA", "correo": CORREOS[1], "enviar_correo": False})
    assert r.status_code == 200, r.text
    j = r.json(); nueva = j["password_temporal"]
    assert nueva and nueva != primera and j["administrador"]["correo"] == CORREOS[1]
    v = _usuario(CORREOS[1])
    assert v.es_superadmin and not v.bloqueado and v.debe_cambiar_password and v.mfa_activo and v.intentos_fallidos == 0
    assert auth.verificar_password(nueva, v.password_hash) and not auth.verificar_password(primera, v.password_hash)
    assert any("cuenta reactivada" in (x["detalle"] or "") for x in c.get("/api/admin/auditoria").json() if x["accion"] == "admin_sistema_agregado")


def test_bloqueada_con_empresa_se_desbloquea_en_cuentas(consola):
    c, _ = consola
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Empresa Admin 385 QA S.A.")).first()
        if not e:
            e = Empresa(nombre="Empresa Admin 385 QA S.A.", numero_id="3101385385", actividad="731001", otras_senas="Oficina 385",
                        correo="emp385@example.test", ambiente="sandbox")
            s.add(e); s.commit(); s.refresh(e)
        u = auth.Usuario(correo=CORREOS[2], nombre="Con empresa QA", password_hash=auth.hash_password("Otra-clave-385-qa"), bloqueado=True)
        s.add(u); s.commit(); s.refresh(u)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Administrador")); s.commit()
    r = c.post("/api/admin/administradores", json={"nombre": "Con empresa QA", "correo": CORREOS[2], "enviar_correo": False})
    assert r.status_code == 400 and "desbloquéelo en Cuentas" in r.json()["detail"]
    u = _usuario(CORREOS[2]); assert u.bloqueado and not u.es_superadmin
