"""3.67: importar las marcas exportadas por un reloj marcador (Excel o CSV) a la tabla de marcas: se reconoce al empleado por su
código de reloj o su identificación, se deduce el tipo por el orden del día cuando no viene, no se duplican y lo del futuro no entra."""
import io
from datetime import timedelta

from sqlmodel import Session

from app import asistencia, modulos
from app.config import ahora_cr
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)


def _preparar(c):
    from app.main import app  # noqa: F401
    ctx = app.dependency_overrides[__import__("app.auth", fromlist=["contexto"]).contexto]()
    eid = ctx.empresa.id
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "empleados")
        modulos.reemplazar(s, eid, "empleados", [{"id": 1, "nombre": "Ana", "apellidos": "Mora Solís", "codigo_reloj": "0007", "numero_id": "109990101", "activo": True},
                                                  {"id": 2, "nombre": "Luis", "apellidos": "Rojas", "codigo_reloj": "12", "numero_id": "109990102", "activo": True}],
                           version=(r.version or 0) if r is not None else 0)
    return eid


def _csv(texto: str):
    return {"archivo": ("reloj.csv", texto.encode("utf-8"), "text/csv")}


def test_interpretar_formatos():
    r = asistencia.interpretar_reloj([["No.", "Name", "Date", "Time", "Status"], ["7", "Ana", "2026-10-05", "08:02:11", "Check In"], ["7", "Ana", "05/10/2026", "17:01", "Check Out"], ["", "", "", "", ""]])
    assert len(r["marcas"]) == 2 and r["marcas"][0]["tipo"] == "entrada" and r["marcas"][1]["tipo"] == "salida" and r["marcas"][1]["fecha_hora"].hour == 17
    r = asistencia.interpretar_reloj([["ID", "Fecha y hora"], ["12", "2026-10-06 07:55"], ["12", "06/10/2026 12:00"], ["12", "basura"]])
    assert len(r["marcas"]) == 2 and r["marcas"][0]["tipo"] is None and r["avisos"] and "Fila 4" in r["avisos"][0]
    r = asistencia.interpretar_reloj([["7", "2026-10-07 08:00:00"], ["7", "2026-10-07", "16:30:00"]])      # sin cabeceras
    assert len(r["marcas"]) == 2 and r["marcas"][1]["fecha_hora"].hour == 16


def test_importar_csv_crea_marcas_y_no_duplica(api):  # noqa: F811
    c = api
    _preparar(c)
    d = (ahora_cr() - timedelta(days=3)).date().isoformat()
    d2 = (ahora_cr() - timedelta(days=2)).date().isoformat()
    futuro = (ahora_cr() + timedelta(days=2)).strftime("%Y-%m-%d %H:%M")
    texto = "Código;Fecha;Hora;Tipo\n" + f"0007;{d};08:01;\n7;{d};12:02;\n7;{d};12:31;\n7;{d};17:05;\n" + f"12;{d2};07:58;in\n12;{d2};16:02;out\n" + f"99;{d};08:00;\n" + f"7;{futuro};;\n"
    r = c.post("/api/asistencia/importar", files=_csv(texto), data={"equipo": "ZKTeco recepción"})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["creadas"] == 6 and j["repetidas"] == 0 and j["futuras"] == 1
    assert j["sin_empleado"] == [{"codigo": "99", "marcas": 1}]
    marcas = c.get(f"/api/asistencia/marcas?desde={d}&hasta={d}&empleado_id=1").json()
    assert [m["tipo"] for m in sorted(marcas, key=lambda m: m["fecha_hora"])] == ["entrada", "pausa", "regreso", "salida"]
    assert all(m["origen"] == "reloj" and m["equipo"] == "ZKTeco recepción" for m in marcas)
    marcas2 = c.get(f"/api/asistencia/marcas?desde={d2}&hasta={d2}&empleado_id=2").json()
    assert [m["tipo"] for m in sorted(marcas2, key=lambda m: m["fecha_hora"])] == ["entrada", "salida"]
    # el mismo archivo otra vez: nada nuevo
    r = c.post("/api/asistencia/importar", files=_csv(texto)).json()
    assert r["creadas"] == 0 and r["repetidas"] == 6
    # formato que no se entiende
    assert c.post("/api/asistencia/importar", files=_csv("hola\nmundo")).json()["creadas"] == 0


def test_importar_xlsx(api):  # noqa: F811
    from openpyxl import Workbook
    c = api
    _preparar(c)
    d = ahora_cr() - timedelta(days=5)
    wb = Workbook(); ws = wb.active
    ws.append(["AC-No.", "Name", "Time", "State"])
    ws.append(["0007", "Ana Mora", d.replace(hour=8, minute=3, second=0, microsecond=0, tzinfo=None), "C/In"])
    ws.append(["0007", "Ana Mora", d.replace(hour=16, minute=45, second=0, microsecond=0, tzinfo=None), "C/Out"])
    buf = io.BytesIO(); wb.save(buf)
    r = c.post("/api/asistencia/importar", files={"archivo": ("reloj.xlsx", buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
    assert r.status_code == 200, r.text
    assert r.json()["creadas"] == 2 and not r.json()["sin_empleado"]
    dia = d.date().isoformat()
    marcas = c.get(f"/api/asistencia/marcas?desde={dia}&hasta={dia}&empleado_id=1").json()
    assert sorted(m["tipo"] for m in marcas) == ["entrada", "salida"] and all(m["hora"] in ("08:03", "16:45") for m in marcas)
