# -*- coding: utf-8 -*-
"""4.0: estado de resultados por mes (columnas Ene..mes de «Al día» y Acumulado), documento de compras y gastos con enlace al
comprobante, y reportes contables y de bancos sin selector de moneda (los asientos están en la moneda principal)."""
import pathlib

from app import main

JS = pathlib.Path(main.__file__).parent / "static" / "js" / "pages" / "reportes"


def test_reportes_4_0():
    r = (JS / "reporte.js").read_text(encoding="utf-8")
    assert "async 'estado-resultados-mensual'(c)" in r   # 4.1: una columna según el mes y el modo elegidos (ver test_401)
    assert "const SIN_SELECTOR = new Set(['documentos-por-conciliar', 'flujo-caja', 'presupuesto-vs-real', 'transacciones'])" in r   # 4.1: los contables tienen selector (estado por moneda)
    assert r.count("link: abrirEgreso") == 2 and "/api/recepcion/' + x.rid + '/pdf'" in r
    assert "slug: 'estado-resultados-mensual'" in (JS / "hub.js").read_text(encoding="utf-8")
