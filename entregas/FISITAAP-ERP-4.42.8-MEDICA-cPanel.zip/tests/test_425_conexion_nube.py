# -*- coding: utf-8 -*-
"""4.25 (tanda 5, X1a, lado nube): conectar una computadora nueva con la cuenta de la web.

El programa inicia un pase sin sesión con el sha256 de su secreto (POST /api/sinc/conexion/iniciar) y recibe un código; un administrador
lo busca y lo aprueba en la página web (consultar y aprobar, con sesión); al aprobar, la PÁGINA muestra un número de comprobación que la
persona escribe en el PROGRAMA (E-1); el programa recoge con {secreto, numero} y recibe, una sola vez, lo mismo que el canje del código.
Con una conexión distinta (o que no se puede saber) la entrega se retiene unos minutos y se avisa a los administradores (E-2, E-7).

Aquí se llaman las rutas directo con el TestClient (la «nube»). La recogida devuelve usuarios con el hash inservible, pero estas pruebas
NO los aplican: nube y computadora comparten la tabla de usuarios."""
import hashlib
import logging
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, Empresa, engine, engine_empresa
from app.main import app
from test_49_local_sinc import H, PW, _admin_empresa, _soltar_limite_vinculacion, c

_SUPERADMINES: list = []
CLAVES = ("sinc_par", "sinc_cod", "sinc_rec")


def _limpiar_limitador() -> None:
    """Las claves persistentes del limitador de la conexión (y el tope en memoria de recoger) quedan en cero, y ningún pase de otra
    prueba sigue vivo: los topes por conexión cuentan todo lo que viene del mismo cliente «testclient»."""
    with Session(engine) as sc:
        for x in sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(CLAVES))).all():
            sc.delete(x)
        sc.commit()
        sc.execute(sinc._sql("UPDATE sincpase SET estado='vencido' WHERE estado IN ('pendiente','aprobado')"))
        sc.commit()
    with auth._lock_ip:
        for k in [k for k in auth._intentos_ip if k.startswith("sinc_recoger:") or k.split(":", 1)[0] in CLAVES]:
            auth._intentos_ip.pop(k, None)
    sinc._DESCARTE.clear()


@pytest.fixture(autouse=True)
def _limpieza():
    _limpiar_limitador()
    yield
    _limpiar_limitador()
    with Session(engine) as sc:                      # test_api.py exige que no quede ningún administrador del sistema
        for correo in _SUPERADMINES:
            u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if u:
                for m in sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                    sc.delete(m)
                sc.delete(u)
        sc.commit()
    _SUPERADMINES.clear()


def _iniciar(nombre: str = "Caja 1", cedula=None, cab=None, version: str = "4.25") -> tuple:
    secreto = "fcs_" + secrets.token_urlsafe(32)
    r = c.post("/api/sinc/conexion/iniciar", headers=cab or {}, json={"secreto_hash": hashlib.sha256(secreto.encode()).hexdigest(), "nombre": nombre,
                                                                     "cedula": cedula, "version": version})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["servicio"] == "fisitaap-conexion" and j["estado"] == "pendiente", j
    return secreto, j["codigo"], j


def _ip(ip: str) -> dict:
    return {"X-Forwarded-For": ip}


def _aprobar(token: str, codigo: str, eid: int, aprobar: bool = True, cab=None):
    return c.post("/api/sinc/conexion/aprobar", headers={**H(token), **(cab or {})}, json={"codigo": codigo, "empresa_id": eid, "aprobar": aprobar})


def _recoger(secreto: str, numero=None, confirmar: bool = False, cab=None, cliente=None, **extra):
    cuerpo = {"secreto": secreto, **extra}
    if numero is not None:
        cuerpo.update(numero=numero, confirmar=confirmar)
    return (cliente or c).post("/api/sinc/conexion/recoger", headers=cab or {}, json=cuerpo)


def _pase(**filtro) -> sinc.SincPase:
    with Session(engine) as sc:
        q = select(sinc.SincPase)
        for k, v in filtro.items():
            q = q.where(getattr(sinc.SincPase, k) == v)
        return sc.exec(q.order_by(sinc.SincPase.id.desc())).first()


def _poner_pase(pid: int, **campos) -> None:
    with Session(engine) as sc:
        p = sc.get(sinc.SincPase, pid)
        for k, v in campos.items():
            setattr(p, k, v)
        sc.add(p); sc.commit()


def _secreto_hash(secreto: str) -> str:
    return hashlib.sha256(secreto.encode()).hexdigest()


def _vinc(eid: int) -> dict:
    with Session(engine_empresa(eid)) as s:
        return sinc._leer(s, eid, sinc.CLAVE_VINC, {})


def _auditoria(eid: int, accion: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == accion).order_by(Auditoria.id)).all()


def _persona(eid, nombre: str, rol: str = "Administrador", **campos) -> tuple:
    """Una persona con sesión en la empresa `eid` (sesión creada directo en la base: sin pasar por el ingreso)."""
    correo = f"{nombre}@example.test"
    if campos.get("es_superadmin"):
        _SUPERADMINES.append(correo)
    datos = {"terminos_version": auth.TERMINOS_VERSION, "mfa_activo": rol == "Administrador" or bool(campos.get("es_superadmin")), **campos}
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(PW), **datos)
        sc.add(u); sc.commit(); sc.refresh(u)
        if eid:
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol)); sc.commit()
        return u.id, auth._respuesta(sc, u, eid)["token"]


def _empresa(sufijo: str, cedula: str) -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Conexion425 QA" + sufijo, f"conexion425{sufijo}@example.test", cedula)
        sc.commit(); sc.refresh(e)
        return e.id


def _misma(monkeypatch) -> dict:
    """El programa y la persona salen por la misma conexión (pública): sin retención."""
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    return _ip("190.10.20.30")


def _conectar(monkeypatch, ta: str, eid: int, nombre: str = "Caja 1", **extra) -> tuple:
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(nombre, cab=cab)
    j = _aprobar(ta, codigo, eid, cab=cab).json()
    assert j["estado"] == "aprobado" and j["retenida"] is False, j
    r = _recoger(secreto, j["numero"], True, cab=cab, **extra).json()
    assert r["estado"] == "conectada", r
    return secreto, r


# ------------------------------------------------------------------------------------------------------------------------------
def test_camino_completo_con_la_persona_en_la_auditoria(monkeypatch):
    eid, ta = _admin_empresa("-cx1", "3101425501")
    cab = _misma(monkeypatch)
    secreto, codigo, j = _iniciar("Caja 1", cab=cab)
    assert set(j) >= {"codigo", "segundos", "intervalo"} and j["segundos"] == sinc.MINUTOS_PASE * 60
    assert len(codigo) == 9 and codigo[4] == "-" and all(ch in sinc._ALFABETO_CODIGO for ch in codigo.replace("-", ""))
    # antes de aprobar el programa solo ve «pendiente»
    assert _recoger(secreto, cab=cab).json()["estado"] == "pendiente"
    # la página web lo encuentra con sesión
    r = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **cab}, json={"codigo": codigo.lower().replace("-", " ")})
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["nombre"] == "Caja 1" and v["misma_conexion"] is True and [x["id"] for x in v["empresas"]] == [eid] and "numero" not in v
    # aprobar: el número sale en la PÁGINA
    a = _aprobar(ta, codigo, eid, cab=cab)
    assert a.status_code == 200, a.text
    a = a.json()
    assert a["estado"] == "aprobado" and len(a["numero"]) == 3 and a["numero"].isdigit() and a["retenida"] is False
    # E-4: sin el número, la recogida solo confirma (empresa y quién aprobó), sin secretos
    conf = _recoger(secreto, cab=cab).json()
    assert conf["estado"] == "aprobada" and conf["empresa"]["numero_id"] == "3101425501" and conf["aprobo"]["correo"] == "duena-sinc49-cx1@example.test"
    assert "token" not in conf and "credenciales" not in conf
    assert _recoger(secreto, a["numero"], False, cab=cab).json()["estado"] == "aprobada"          # sin «Sí, es mi empresa» no se entrega
    # con el número y la confirmación: la instalación nace y viaja una sola vez
    ok = _recoger(secreto, a["numero"], True, cab=cab).json()
    assert ok["estado"] == "conectada", ok
    assert {"token", "terminal", "nombre", "revinculada", "empresa", "credenciales", "credenciales_huella", "usuarios", "roles", "aprobo"} <= set(ok)
    assert ok["aprobo"]["correo"] == "duena-sinc49-cx1@example.test"
    assert ok["usuarios"] and all(u["password_hash"] == sinc.HASH_INSERVIBLE and u["pin_hash"] is None for u in ok["usuarios"])
    assert _recoger(secreto, a["numero"], True, cab=cab).json()["estado"] == "entregada"
    assert c.get("/api/sinc/catalogo", headers=H(ok["token"])).status_code == 200
    inst = [i for i in _vinc(eid)["instalaciones"] if i["terminal"] == ok["terminal"]][0]
    assert inst["origen"] == "conexion" and inst["por"] == "duena-sinc49-cx1@example.test"
    fila = _auditoria(eid, "sinc_vinculada")[-1]
    with Session(engine) as sc:
        duena = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena-sinc49-cx1@example.test")).first()
    assert fila.usuario_id == duena.id and "aprobada en la página web" in fila.detalle and "recogida desde la misma conexión" in fila.detalle
    ap = _auditoria(eid, "sinc_conexion_aprobada")[-1]
    assert ap.usuario_id == duena.id and "desde su conexión" in ap.detalle and "la misma conexión" in ap.detalle
    # la página ve el pase entregado
    assert c.post("/api/sinc/conexion/seguimiento", headers=H(ta), json={"pase": a["pase"]}).json()["estado"] == "entregada"


def test_iniciar_no_devuelve_numero_ni_guarda_nada_en_claro():
    secreto, codigo, j = _iniciar("Recepción")
    assert "numero" not in j and "secreto" not in j and "token" not in j
    p = _pase(secreto_hash=_secreto_hash(secreto))
    assert p.estado == "pendiente" and p.numero_hash is None and abs(p.vence - p.creado - 600) < 1
    texto = " ".join(str(x) for x in p.model_dump().values())
    assert secreto not in texto and codigo not in texto and codigo.replace("-", "") not in texto
    # un secreto_hash repetido no crea otro pase; uno que no es hex, tampoco
    r = c.post("/api/sinc/conexion/iniciar", json={"secreto_hash": _secreto_hash(secreto), "nombre": "x", "version": "4.25"})
    assert r.status_code == 409 and r.json()["estado"] == "repetido"
    r = c.post("/api/sinc/conexion/iniciar", json={"secreto_hash": "Z" * 64, "version": "4.25"})
    assert r.status_code == 400 and r.json()["servicio"] == "fisitaap-conexion"
    # un cuerpo con campos de más largo no copia lo enviado en la respuesta (sin el 422 de pydantic)
    r = c.post("/api/sinc/conexion/iniciar", json={"secreto_hash": "a" * 64, "nombre": "N" * 500, "version": "4.25"})
    assert r.status_code == 400 and "NNNN" not in r.text
    # un programa anterior recibe el estado dentro del sobre
    r = c.post("/api/sinc/conexion/iniciar", json={"secreto_hash": "b" * 64, "version": "4.24.3"})
    assert r.status_code == 200 and r.json()["estado"] == "programa_viejo" and "descargue la versión nueva" in r.json()["mensaje"]


def test_nombre_de_la_computadora_se_limpia():
    assert sinc._nombre_computadora('<script>alert("x")</script>\nCaja #2 (bar)') == "script alert( x ) script Caja #2 (bar)"
    assert sinc._nombre_computadora("www.banco-falso.com/entrar?x=1 @soporte: llame ya") == "www banco-falso com entrar x 1 soporte llame ya"
    assert sinc._nombre_computadora("Caja Ñandú 1") == "Caja Ñandú 1"
    assert len(sinc._nombre_computadora("x" * 300)) == 60
    assert sinc._nombre_computadora("") == sinc._nombre_computadora("<>.:/") == "Computadora nueva"
    secreto, _, _ = _iniciar("<b>Caja</b>.local:80")
    nombre = _pase(secreto_hash=_secreto_hash(secreto)).nombre
    assert nombre == "b Caja b local 80" and not set(nombre) & set("<>.:/@\"'")


def test_recoger_sin_numero_con_numero_errado_y_con_un_secreto_que_no_es(monkeypatch):
    eid, ta = _admin_empresa("-cx2", "3101425502")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(cab=cab)
    a = _aprobar(ta, codigo, eid, cab=cab).json()
    malo = "999" if a["numero"] != "999" else "998"
    # secreto que no existe: 404 sin detalle y cuenta en «sinc_rec»
    r = _recoger("fcs_" + secrets.token_urlsafe(32), cab=cab)
    assert r.status_code == 404 and r.json()["estado"] == "desconocido" and r.json()["servicio"] == "fisitaap-conexion"
    with Session(engine) as sc:
        assert len(sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc_rec")).all()) == 1
    # sin número: solo la confirmación
    assert _recoger(secreto, cab=cab).json()["estado"] == "aprobada"
    j1 = _recoger(secreto, malo, True, cab=cab).json()
    assert j1["estado"] == "numero_errado" and j1["intentos_restantes"] == 2
    assert _recoger(secreto, malo, True, cab=cab).json()["intentos_restantes"] == 1
    j3 = _recoger(secreto, malo, True, cab=cab).json()
    assert j3["estado"] == "anulada" and "tres veces" in j3["mensaje"]
    # anulado: ni con el número bueno
    assert _recoger(secreto, a["numero"], True, cab=cab).json()["estado"] == "anulada"
    fallidas = _auditoria(eid, "sinc_conexion_fallida")
    assert len(fallidas) == 3 and "quedó anulado" in fallidas[-1].detalle
    assert all(malo not in f.detalle and a["numero"] not in f.detalle for f in fallidas)
    with Session(engine) as sc:
        assert not sc.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == eid, auth.TokenApi.usuario_id == auth.TOKEN_EMPRESA)).all()
    # 10 secretos que no existen desde la misma conexión: 429 (también para cancelar)
    for _ in range(9):
        assert _recoger("fcs_otro" + secrets.token_hex(8), cab=cab).status_code == 404
    assert _recoger("fcs_otro" + secrets.token_hex(8), cab=cab).status_code == 429
    assert c.post("/api/sinc/conexion/cancelar", headers=cab, json={"secreto": "x"}).status_code == 429


def test_dos_recogidas_a_la_vez(monkeypatch):
    eid, ta = _admin_empresa("-cx3", "3101425503")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(cab=cab)
    numero = _aprobar(ta, codigo, eid, cab=cab).json()["numero"]
    salidas: list = []
    puerta = threading.Barrier(2)

    def recoger():
        cliente = TestClient(app)
        puerta.wait()
        r = _recoger(secreto, numero, True, cab=cab, cliente=cliente)
        salidas.append((r.status_code, r.json().get("estado")))
    hilos = [threading.Thread(target=recoger) for _ in range(2)]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join(60)
    assert len(salidas) == 2 and all(s == 200 for s, _ in salidas), salidas
    assert sorted(e for _, e in salidas).count("conectada") == 1, salidas
    with Session(engine) as sc:
        vivos = sc.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == eid, auth.TokenApi.usuario_id == auth.TOKEN_EMPRESA, auth.TokenApi.revocado == False)).all()  # noqa: E712
    assert len(vivos) == 1 and len(_vinc(eid)["instalaciones"]) == 1


def test_aprobar_una_sola_vez_y_nunca_vencido(monkeypatch):
    eid, ta = _admin_empresa("-cx4", "3101425504")
    cab = _misma(monkeypatch)
    _, codigo, _ = _iniciar(cab=cab)
    assert _aprobar(ta, codigo, eid, cab=cab).status_code == 200
    r = _aprobar(ta, codigo, eid, cab=cab)
    assert r.status_code == 409 and r.json()["detail"]["codigo"] == "ya_resuelto"
    # rechazar uno ya aprobado tampoco cambia nada
    assert _aprobar(ta, codigo, eid, aprobar=False, cab=cab).status_code == 409
    # vencido: «venció», sin ningún cambio y sin contar como fallo
    secreto2, codigo2, _ = _iniciar(cab=cab)
    p = _pase(secreto_hash=_secreto_hash(secreto2))
    _poner_pase(p.id, vence=time.time() - 1)
    r = _aprobar(ta, codigo2, eid, cab=cab)
    assert r.status_code == 410 and r.json()["detail"]["codigo"] == "vencido"
    q = _pase(id=p.id)
    assert q.estado == "pendiente" and q.usuario_id is None and q.numero_hash is None
    assert _recoger(secreto2, cab=cab).json()["estado"] == "vencida"
    with Session(engine) as sc:
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc_cod")).all()


def test_codigo_vencido_no_cuenta_y_los_que_no_existen_si():
    eid, ta = _admin_empresa("-cx5", "3101425505")
    _, codigo, _ = _iniciar()
    p = _pase(codigo_hash=sinc._hash_codigo(codigo))
    _poner_pase(p.id, vence=time.time() - 5)
    for _ in range(12):
        r = c.post("/api/sinc/conexion/consultar", headers=H(ta), json={"codigo": codigo})
        assert r.status_code == 410 and r.json()["detail"]["codigo"] == "vencido"
    with Session(engine) as sc:
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc_cod")).all()
    for i in range(10):
        r = c.post("/api/sinc/conexion/consultar", headers=H(ta), json={"codigo": "ZZZZ-ZZZ" + "23456789ABCDEFGH"[i]})
        assert r.status_code == 404 and r.json()["detail"]["codigo"] == "no_existe"
    r = c.post("/api/sinc/conexion/consultar", headers=H(ta), json={"codigo": "ZZZZ-ZZZZ"})
    assert r.status_code == 429


def test_quien_no_puede_aprobar(monkeypatch):
    eid, ta = _admin_empresa("-cx6", "3101425506")
    _, codigo, _ = _iniciar()
    # contadora (rol sin «configurar»): no ve empresas para aprobar y no puede aprobar
    _, tcaj = _persona(eid, "contadora.cx6", rol="Contador")
    r = c.post("/api/sinc/conexion/consultar", headers=H(tcaj), json={"codigo": codigo})
    assert r.status_code == 200 and r.json()["empresas"] == []
    r = _aprobar(tcaj, codigo, eid)
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_permiso"
    # administrador del sistema (aunque sea miembro): rechazado
    _, tsa = _persona(eid, "sa.cx6", rol="Administrador", es_superadmin=True)
    for ruta, cuerpo in (("/api/sinc/conexion/consultar", {"codigo": codigo}), ("/api/sinc/conexion/aprobar", {"codigo": codigo, "empresa_id": eid})):
        r = c.post(ruta, headers=H(tsa), json=cuerpo)
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "soporte", r.text
    # contraseña temporal, sin dos pasos y sin términos
    _, ttemp = _persona(eid, "temporal.cx6", debe_cambiar_password=True)
    _, tsin2 = _persona(eid, "sin2pasos.cx6", mfa_activo=False)
    _, tterm = _persona(eid, "terminos.cx6", terminos_version=None)
    for tok, esperado in ((ttemp, "cambiar_password"), (tterm, "aceptar_terminos"), (tsin2, None)):
        for ruta, cuerpo in (("/api/sinc/conexion/consultar", {"codigo": codigo}), ("/api/sinc/conexion/aprobar", {"codigo": codigo, "empresa_id": eid})):
            r = c.post(ruta, headers=H(tok), json=cuerpo)
            assert r.status_code == 403, (ruta, r.text)
            if esperado:
                assert r.json()["detail"]["codigo"] == esperado
            else:
                assert "dos pasos" in str(r.json()["detail"])
    # un token de API tampoco
    tok = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "x"}).json()["codigo"]
    _soltar_limite_vinculacion()
    api = c.post("/api/sinc/canje", json={"codigo": tok, "nombre": "Caja token"}).json()["token"]
    r = _aprobar(api, codigo, eid)
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "token"
    # sin sesión: 401
    assert c.post("/api/sinc/conexion/consultar", json={"codigo": codigo}).status_code == 401
    assert _pase(codigo_hash=sinc._hash_codigo(codigo)).estado == "pendiente"


def test_persona_con_dos_empresas_aprueba_para_la_elegida(monkeypatch):
    eid_a, ta = _admin_empresa("-cx7", "3101425507")
    eid_b = _empresa("-cx7b", "3101425517")
    with Session(engine) as sc:
        u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena-sinc49-cx7@example.test")).first()
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_b, rol="Administrador")); sc.commit()
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(cab=cab)
    v = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **cab}, json={"codigo": codigo}).json()
    assert sorted(x["id"] for x in v["empresas"]) == sorted([eid_a, eid_b])
    # con la sesión en A no se aprueba para B
    r = _aprobar(ta, codigo, eid_b, cab=cab)
    assert r.status_code == 409 and r.json()["detail"]["codigo"] == "empresa_distinta"
    # un token de B solo para esta llamada: la sesión de A sigue en A
    tb = c.post("/api/auth/empresa", headers=H(ta), json={"empresa_id": eid_b}).json()["token"]
    a = _aprobar(tb, codigo, eid_b, cab=cab).json()
    assert a["estado"] == "aprobado" and a["empresa"].startswith("Conexion425 QA-cx7b")
    assert auth.abrir(ta)["eid"] == eid_a and c.get("/api/sinc/instalaciones", headers=H(ta)).status_code == 200
    ok = _recoger(secreto, a["numero"], True, cab=cab).json()
    assert ok["estado"] == "conectada" and ok["empresa"]["numero_id"] == "3101425517"
    assert len(_vinc(eid_b)["instalaciones"]) == 1 and not _vinc(eid_a).get("instalaciones")


def test_cedula_distinta_al_reconectar(monkeypatch):
    eid_a, ta = _admin_empresa("-cx8", "3101425508")
    eid_b = _empresa("-cx8b", "3-101-425518")
    with Session(engine) as sc:
        u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena-sinc49-cx8@example.test")).first()
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_b, rol="Administrador")); sc.commit()
    _, codigo, _ = _iniciar(cedula="3-101-425518")
    v = c.post("/api/sinc/conexion/consultar", headers=H(ta), json={"codigo": codigo}).json()
    assert [x["id"] for x in v["empresas"]] == [eid_b] and v["cedula"] == "3101425518"         # comparada por dígitos
    r = _aprobar(ta, codigo, eid_a)
    assert r.status_code == 409 and r.json()["detail"]["codigo"] == "cedula_distinta" and "3101425518" in r.json()["detail"]["mensaje"]
    assert _pase(codigo_hash=sinc._hash_codigo(codigo)).estado == "pendiente"
    tb = c.post("/api/auth/empresa", headers=H(ta), json={"empresa_id": eid_b}).json()["token"]
    assert _aprobar(tb, codigo, eid_b).json()["estado"] == "aprobado"


def test_conexion_distinta_retiene_avisa_y_se_cancela(monkeypatch):
    eid, ta = _admin_empresa("-cx9", "3101425509")
    _persona(eid, "otra.admin.cx9")
    _persona(eid, "cajero.cx9", rol="Cajero")
    enviados: list = []
    monkeypatch.setenv("FE_SMTP_HOST", "smtp.example.test")
    monkeypatch.setattr(sinc, "_en_hilo", lambda fn: fn())
    from app import correo
    monkeypatch.setattr(correo, "enviar", lambda cfg, para, asunto, html, texto, adjuntos: enviados.append((tuple(para), asunto, texto)))
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    secreto, codigo, _ = _iniciar(cab=_ip("201.1.2.3"))
    v = c.post("/api/sinc/conexion/consultar", headers={**H(ta), **_ip("190.9.9.9")}, json={"codigo": codigo}).json()
    assert v["misma_conexion"] is False
    a = _aprobar(ta, codigo, eid, cab=_ip("190.9.9.9")).json()
    assert a["retenida"] is True and a["segundos_retencion"] == sinc.SEGUNDOS_RETENCION and a["segundos"] > sinc.SEGUNDOS_RETENCION
    # el aviso sale AL APROBAR a los administradores (no a la cajera), sin número ni código
    destinos = sorted(d for para, _, _ in enviados for d in para)
    assert destinos == sorted(["duena-sinc49-cx9@example.test", "otra.admin.cx9@example.test"])
    assert all(a["numero"] not in t and codigo not in t and "llave criptográfica nueva" in t for _, _, t in enviados)
    # el programa ve «retenida» (con la confirmación) y ni con el número se entrega todavía
    r = _recoger(secreto, a["numero"], True, cab=_ip("201.1.2.3")).json()
    assert r["estado"] == "retenida" and r["segundos"] > 0 and r["empresa"]["numero_id"] == "3101425509" and "token" not in r
    # aviso dentro del sistema para cada administrador
    av = c.get("/api/sinc/conexion/avisos", headers=H(ta)).json()["avisos"]
    assert len(av) == 1 and av[0]["estado"] == "por_completar" and "Revocar" in av[0]["texto"]
    assert c.post("/api/sinc/conexion/seguimiento", headers=H(ta), json={"pase": a["pase"]}).json()["estado"] == "retenida"
    # «Cancelar» en la página
    assert c.post("/api/sinc/conexion/detener", headers=H(ta), json={"pase": a["pase"]}).json()["estado"] == "cancelada"
    assert _recoger(secreto, a["numero"], True, cab=_ip("201.1.2.3")).json()["estado"] == "cancelada"
    assert c.get("/api/sinc/conexion/avisos", headers=H(ta)).json()["avisos"] == []
    assert _auditoria(eid, "sinc_conexion_cancelada")
    # otra: al terminar la retención sí se entrega (y la auditoría dice que se recogió desde otra conexión)
    secreto2, codigo2, _ = _iniciar(cab=_ip("201.1.2.3"))
    a2 = _aprobar(ta, codigo2, eid, cab=_ip("190.9.9.9")).json()
    p = _pase(id=a2["pase"])
    _poner_pase(p.id, retener_hasta=time.time() - 1, vence=time.time() + 60)
    ok = _recoger(secreto2, a2["numero"], True, cab=_ip("201.1.2.3")).json()
    assert ok["estado"] == "conectada", ok
    assert "recogida desde otra conexión" in _auditoria(eid, "sinc_vinculada")[-1].detalle
    # sin poder saber la conexión (dirección privada o el cliente de pruebas): siempre «distinta»
    assert sinc._misma_conexion("10.0.0.5", "10.0.0.5") is False and sinc._misma_conexion(None, None) is False
    assert sinc._misma_conexion("testclient", "testclient") is False and sinc._misma_conexion("127.0.0.1", "127.0.0.1") is False
    assert sinc._misma_conexion("2800:860:1:2::5", "2800:860:1:2::99") is True and sinc._misma_conexion("2800:860:1:2::5", "2800:860:1:3::5") is False


def test_avisos_si_y_revocar(monkeypatch):
    eid, ta = _admin_empresa("-cx10", "3101425510")
    _, tb = _persona(eid, "segunda.cx10")
    _, r = _conectar(monkeypatch, ta, eid, "Bodega")
    a1 = c.get("/api/sinc/conexion/avisos", headers=H(ta)).json()["avisos"]
    a2 = c.get("/api/sinc/conexion/avisos", headers=H(tb)).json()["avisos"]
    assert len(a1) == len(a2) == 1 and a1[0]["estado"] == "conectada" and "llave criptográfica nueva" in a1[0]["texto"]
    # «Sí» solo lo cierra para quien contesta
    assert c.post(f"/api/sinc/conexion/avisos/{a1[0]['id']}", headers=H(ta), json={"respuesta": "si"}).json()["estado"] == "si"
    assert c.get("/api/sinc/conexion/avisos", headers=H(ta)).json()["avisos"] == []
    # el aviso de otra persona no se contesta
    assert c.post(f"/api/sinc/conexion/avisos/{a2[0]['id']}", headers=H(ta), json={"respuesta": "revocar"}).status_code == 404
    # «Revocar» revoca la instalación
    assert c.post(f"/api/sinc/conexion/avisos/{a2[0]['id']}", headers=H(tb), json={"respuesta": "revocar"}).json()["estado"] == "revocada"
    assert c.get("/api/sinc/catalogo", headers=H(r["token"])).status_code == 401
    v = _vinc(eid)
    assert not v["instalaciones"] and v["retiradas"][-1]["terminal"] == r["terminal"]
    assert c.get("/api/sinc/conexion/avisos", headers=H(tb)).json()["avisos"] == []


def test_500_pases_de_otras_direcciones_no_impiden_iniciar_y_tope_por_conexion(monkeypatch):
    ahora = time.time()
    with Session(engine) as sc:
        for i in range(500):
            sc.add(sinc.SincPase(secreto_hash=f"{i:064x}", codigo_hash=f"x{i}", nombre="QA", red=f"200.0.{i // 250}.{i % 250}", ip=f"200.0.{i // 250}.{i % 250}",
                                 creado=ahora, vence=ahora + 600))
        sc.commit()
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    _iniciar(cab=_ip("201.50.60.70"))
    # tope por conexión: 10 pases vivos
    for _ in range(9):
        _iniciar(cab=_ip("201.50.60.70"))
    r = c.post("/api/sinc/conexion/iniciar", headers=_ip("201.50.60.70"), json={"secreto_hash": secrets.token_hex(32), "version": "4.25"})
    assert r.status_code == 429 and r.json()["estado"] == "tope"
    # en IPv6 cuenta el /64 entero
    for i in range(10):
        _iniciar(cab=_ip(f"2800:860:7:9::{i + 1}"))
    r = c.post("/api/sinc/conexion/iniciar", headers=_ip("2800:860:7:9:abcd::1"), json={"secreto_hash": secrets.token_hex(32), "version": "4.25"})
    assert r.status_code == 429
    _iniciar(cab=_ip("2800:860:7:a::1"))                                   # otro /64: sí
    # un pase vencido no ocupa cupo
    with Session(engine) as sc:
        sc.execute(sinc._sql("UPDATE sincpase SET vence=:t WHERE red='201.50.60.70'"), {"t": time.time() - 1}); sc.commit()
    _iniciar(cab=_ip("201.50.60.70"))
    # techo de la plataforma: desaloja los pendientes más viejos que nadie consultó, nunca rechaza a todos
    monkeypatch.setattr(sinc, "TECHO_PASES", 5)
    _iniciar(cab=_ip("201.80.80.80"))
    with Session(engine) as sc:
        vivos = sc.execute(sinc._sql("SELECT COUNT(*) FROM sincpase WHERE estado='pendiente' AND vence > :t"), {"t": time.time()}).scalar()
    assert vivos <= 6


def test_fallo_despues_de_crear_el_token_lo_revoca_y_el_pase_vuelve(monkeypatch):
    eid, ta = _admin_empresa("-cx11", "3101425511")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(cab=cab)
    a = _aprobar(ta, codigo, eid, cab=cab).json()
    with monkeypatch.context() as m:
        m.setattr(sinc.diario, "sembrar", lambda s: (_ for _ in ()).throw(OSError("disco lleno (QA)")))
        r = _recoger(secreto, a["numero"], True, cab=cab)
        assert r.status_code == 200 and r.json()["estado"] == "pendiente", r.text
    with Session(engine) as sc:
        tokens = sc.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == eid, auth.TokenApi.usuario_id == auth.TOKEN_EMPRESA)).all()
    assert len(tokens) == 1 and tokens[0].revocado
    p = _pase(id=a["pase"])
    assert p.estado == "aprobado" and p.token_id is None and p.entregado is None
    assert not _vinc(eid).get("instalaciones")
    ok = _recoger(secreto, a["numero"], True, cab=cab).json()                # el siguiente sondeo reintenta
    assert ok["estado"] == "conectada" and c.get("/api/sinc/catalogo", headers=H(ok["token"])).status_code == 200


def test_descarte_de_una_instalacion_que_no_bajo_nada_y_reintento_con_la_misma_terminal(monkeypatch):
    eid, ta = _admin_empresa("-cx12", "3101425512")
    _, r1 = _conectar(monkeypatch, ta, eid, "Caja sin estrenar")
    _, r2 = _conectar(monkeypatch, ta, eid, "Caja que sí habló")
    assert c.get("/api/sinc/catalogo", headers=H(r2["token"])).status_code == 200            # esta sí usó su token
    lista = c.get("/api/sinc/instalaciones", headers=H(ta)).json()["instalaciones"]
    assert {i["terminal"]: i["sin_estrenar"] for i in lista} == {r1["terminal"]: True, r2["terminal"]: False}
    # 11 minutos después
    with Session(engine_empresa(eid)) as s:
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
        for i in v["instalaciones"]:
            i["creado"] = (datetime.now(timezone.utc) - timedelta(minutes=11)).isoformat(timespec="seconds")
        sinc._escribir(s, eid, sinc.CLAVE_VINC, v); s.commit()
    sinc._DESCARTE.clear()
    lista = c.get("/api/sinc/instalaciones", headers=H(ta)).json()["instalaciones"]
    assert [i["terminal"] for i in lista] == [r2["terminal"]]
    v = _vinc(eid)
    assert v["retiradas"][-1] == {**v["retiradas"][-1], "terminal": r1["terminal"], "motivo": "sin_estrenar"}
    assert c.get("/api/sinc/catalogo", headers=H(r1["token"])).status_code == 401
    assert c.get("/api/sinc/catalogo", headers=H(r2["token"])).status_code == 200
    assert "descartada" in _auditoria(eid, "sinc_descartada")[-1].detalle
    # la misma computadora vuelve con su terminal anterior (sin datos emitidos): la recupera
    _, r3 = _conectar(monkeypatch, ta, eid, "Caja sin estrenar", terminal_anterior=r1["terminal"], secuencias={})
    assert r3["terminal"] == r1["terminal"]
    # reintento con una instalación viva sin estrenar: se reemplaza (mismo número, token viejo revocado, una sola viva)
    _, r4 = _conectar(monkeypatch, ta, eid, "Caja sin estrenar", terminal_anterior=r3["terminal"])
    assert r4["terminal"] == r3["terminal"] and r4["token"] != r3["token"]
    assert c.get("/api/sinc/catalogo", headers=H(r3["token"])).status_code == 401
    assert [i["terminal"] for i in _vinc(eid)["instalaciones"]].count(r3["terminal"]) == 1
    # una instalación que ya habló no se reemplaza: la terminal anterior de r2 da una nueva
    _, r5 = _conectar(monkeypatch, ta, eid, "Otra", terminal_anterior=r2["terminal"])
    assert r5["terminal"] not in (r2["terminal"], r4["terminal"])


def test_el_canje_con_codigo_no_cambia():
    eid, ta = _admin_empresa("-cx13", "3101425513")
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja código"}).json()["codigo"]
    j = c.post("/api/sinc/canje", json={"codigo": codigo}).json()
    assert set(j) == {"token", "terminal", "nombre", "revinculada", "empresa", "credenciales", "credenciales_huella"}
    assert j["nombre"] == "Caja código" and j["revinculada"] is False
    fila = _auditoria(eid, "sinc_vinculada")[-1]
    assert fila.usuario_id is None and fila.detalle == f"Instalación local «Caja código» vinculada como terminal {j['terminal']} (token {j['token'][:12]}…)"
    inst = _vinc(eid)["instalaciones"][-1]
    assert inst["origen"] == "codigo" and inst["por"] == "duena-sinc49-cx13@example.test"
    # un canje no se descarta aunque no use su token
    with Session(engine_empresa(eid)) as s:
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
        v["instalaciones"][-1]["creado"] = "2000-01-01T00:00:00+00:00"
        sinc._escribir(s, eid, sinc.CLAVE_VINC, v); s.commit()
    c.get("/api/sinc/instalaciones", headers=H(ta))
    assert len(_vinc(eid)["instalaciones"]) == 1


def test_con_el_programa_real_todas_dan_404(monkeypatch):
    eid, ta = _admin_empresa("-cx14", "3101425514")
    rutas = [("/api/sinc/codigo", {"nombre": "x"}), ("/api/sinc/canje", {"codigo": "L1-AAAA"}),
             ("/api/sinc/conexion/iniciar", {"secreto_hash": "c" * 64, "version": "4.25"}), ("/api/sinc/conexion/consultar", {"codigo": "AAAA-AAAA"}),
             ("/api/sinc/conexion/aprobar", {"codigo": "AAAA-AAAA", "empresa_id": eid}), ("/api/sinc/conexion/recoger", {"secreto": "x"}),
             ("/api/sinc/conexion/cancelar", {"secreto": "x"}), ("/api/sinc/conexion/seguimiento", {"pase": 1}),
             ("/api/sinc/conexion/detener", {"pase": 1}), ("/api/sinc/conexion/avisos/1", {"respuesta": "si"})]
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    for ruta, cuerpo in rutas:
        assert c.post(ruta, headers=H(ta), json=cuerpo).status_code == 404, ruta
    assert c.get("/api/sinc/conexion/avisos", headers=H(ta)).status_code == 404
    monkeypatch.delenv("FE_MODO_LOCAL")
    assert c.post("/api/sinc/conexion/iniciar", json={"secreto_hash": "c" * 64, "version": "4.25"}).status_code == 200


def test_rechazar_y_cancelar_desde_el_programa(monkeypatch):
    eid, ta = _admin_empresa("-cx15", "3101425515")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar(cab=cab)
    assert _aprobar(ta, codigo, eid, aprobar=False, cab=cab).json()["estado"] == "rechazado"
    assert _recoger(secreto, cab=cab).json()["estado"] == "rechazada"
    assert _auditoria(eid, "sinc_conexion_rechazada")
    # E-4: la persona dice que no es su empresa → cancela; no nace ninguna instalación
    secreto2, codigo2, _ = _iniciar(cab=cab)
    a = _aprobar(ta, codigo2, eid, cab=cab).json()
    assert _recoger(secreto2, cab=cab).json()["estado"] == "aprobada"
    r = c.post("/api/sinc/conexion/cancelar", headers=cab, json={"secreto": secreto2})
    assert r.status_code == 200 and r.json()["estado"] == "cancelada"
    assert _recoger(secreto2, a["numero"], True, cab=cab).json()["estado"] == "cancelada"
    assert not _vinc(eid).get("instalaciones")
    assert c.get("/api/sinc/conexion/avisos", headers=H(ta)).json()["avisos"] == []


def test_ni_el_registro_ni_la_auditoria_ni_las_respuestas_tienen_secretos(monkeypatch, caplog):
    caplog.set_level(logging.DEBUG)
    eid, ta = _admin_empresa("-cx16", "3101425516")
    cab = _misma(monkeypatch)
    secreto, codigo, _ = _iniciar("Caja secreta", cab=cab)
    a = _aprobar(ta, codigo, eid, cab=cab).json()
    malo = "999" if a["numero"] != "999" else "998"
    _recoger(secreto, malo, True, cab=cab)
    ok = _recoger(secreto, a["numero"], True, cab=cab).json()
    assert ok["estado"] == "conectada"
    prohibidos = [secreto, _secreto_hash(secreto), ok["token"], codigo, codigo.replace("-", "")]
    with Session(engine) as sc:
        filas = sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid)).all()
    texto_aud = " ".join(f"{f.accion} {f.detalle}" for f in filas)
    for x in prohibidos:
        assert x not in texto_aud and x not in caplog.text
    assert f" {a['numero']}" not in texto_aud and f"«{a['numero']}" not in texto_aud
    # las respuestas a la página nunca traen el secreto ni el token; la del programa al iniciar no trae el número
    seg = c.post("/api/sinc/conexion/seguimiento", headers=H(ta), json={"pase": a["pase"]}).text
    assert secreto not in seg and ok["token"] not in seg
    with Session(engine) as sc:
        p = sc.get(sinc.SincPase, a["pase"])
        en_base = " ".join(str(x) for x in p.model_dump().values())
    assert secreto not in en_base and ok["token"] not in en_base and codigo not in en_base
