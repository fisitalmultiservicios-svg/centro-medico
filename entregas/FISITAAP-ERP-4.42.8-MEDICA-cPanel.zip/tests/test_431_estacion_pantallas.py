# -*- coding: utf-8 -*-
"""4.31, estación de comandas, pantallas (diseño exe430/diseno_estacion.md: 4.2, 4.3, 5.4, 7 y las pruebas de Node de la sección 8).

- pos/_comandas.js: piezas puras nuevas (huella, posiciones, grupos de la copia, avisos) y las cuatro llamadas que nunca lanzan.
- pos/_estacion.js: indicio, interruptor, la pasada de la estación con un servidor falso que aplica la regla de 5.1 (reclamo por plato,
  todo o nada), dos estaciones, Cocina a mano y la estación a la vez en la misma pestaña, aviso al cobrar.
- pos/_agente.js: agenteEstado({soloAgente}) sin preguntar al servidor; cargarEquipo lee /equipo del 9800 solo con `equipo: 1`.
- fis/pages/pedidos.js: aceptar manda `reclama: true`; la comanda sale de la copia, reclamada; tope de 5 s; textos.
- pos/configuracion.js: la tarjeta «En esta computadora» del interruptor (solo en la web y con pedidos en línea).
Nada va a una impresora, a la red ni a un servidor de verdad: el agente del 9800 y el servidor son funciones de la prueba."""
import json
import re
import subprocess

import pytest

from tests.test_425_ultimos_pantallas import JS, _js, _node, _nodo

# ================================================================================================================ sustitutos
FALSO_API = """
export const api = (url, opt) => globalThis.Q.api(url, opt);
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const fmt = v => String(v), fecha = v => String(v), fmtCant = v => String(v);
export const mock = { get: (k, d) => (k in globalThis.Q.reg ? globalThis.Q.reg[k] : d), get cargado() { return globalThis.Q.cargado !== false; }, get refrescar() { return globalThis.Q.refrescar; } };
"""
FALSO_APP = "export const sesion = globalThis.Q.sesion, store = globalThis.Q.store;\n"
FALSO_VUE = "export const reactive = o => o;\n"
FALSO_DATOS = """
export const terminalActual = () => globalThis.Q.terminal, enEspera = () => globalThis.Q.espera, categorias = () => globalThis.Q.cats;
export const impresoras = () => globalThis.Q.imps, config = () => globalThis.Q.cfg;
"""
# Q: el estado de la prueba; el agente del 9800 (fetch) y el servidor (Q.api, regla de 5.1) son de mentira
BASE = r"""
const HORA0 = Date.now();
const Q = globalThis.Q = { toasts: [], llamadas: [], fetchs: [], impresos: [], rotas: [], reg: { items_extra: {} }, cargado: true, agente: true, estadoExtra: {},
  sesion: { empresa_id: 7, sucursal_id: null, tipo: 'restaurante', empresaInfo: { es_local: false, numero_id: '3101123456' }, tieneModulo: m => Q.modulos.includes(m) }, modulos: ['pedidos_online'],
  store: { productos: [{ id: 1, nombre: 'Casado', categoria: 'Platos' }, { id: 2, nombre: 'Refresco', categoria: 'Bebidas' }, { id: 3, nombre: 'Agua', categoria: 'Vitrina' }] },
  terminal: { id: 1, nombre: 'Caja 1' }, cats: [{ id: 1, nombre: 'Platos' }, { id: 2, nombre: 'Bebidas' }, { id: 3, nombre: 'Vitrina' }],
  imps: [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'red', direccion: '192.168.1.60' }, { id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'navegador' }],
  cfg: { terminales: [{ id: 1, nombre: 'Caja 1', destinos: { 1: '10', 2: '11', 3: 'none' } }, { id: 2, nombre: 'Caja Sur', sucursal_id: 9, destinos: { 1: '10' } }] }, espera: [] };
const mem = new Map();
globalThis.localStorage = { getItem: k => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: k => mem.delete(k) };
globalThis.document = { hidden: false };
globalThis.window = { open() { Q.ventanas = (Q.ventanas || 0) + 1; return { closed: false, document: { open() {}, write(h) { Q.htmls = (Q.htmls || []).concat([h]); }, close() {} }, close() { this.closed = true; } }; } };
globalThis.Blob = class { constructor(p) { this.p = p; } };
globalThis.URL.createObjectURL = () => 'blob:x'; globalThis.URL.revokeObjectURL = () => {};
globalThis.confirm = t => { Q.preguntas = (Q.preguntas || []).concat([t]); return !!Q.responder; };
const resp = (j, ok = true) => ({ ok, json: async () => j });
globalThis.fetch = async (url, opt) => {
  Q.fetchs.push(String(url).replace('http://127.0.0.1:9800', '9800'));
  if (!Q.agente) throw new Error('sin agente');
  if (url.endsWith('/estado')) return resp({ agente: 'FISITAAP ERP', ...Q.estadoExtra });
  if (url.includes('/equipo')) return resp(Q.equipo9800 ? { ok: true, equipo: Q.equipo9800 } : { ok: false }, !!Q.equipo9800);
  if (url.endsWith('/imprimir')) { const b = JSON.parse(opt.body); if (Q.lento) await Q.lento; if (Q.rotas.includes(b.impresora.nombre)) return resp({ ok: false, error: 'La impresora «' + b.impresora.nombre + '» no responde' }, false);
    Q.impresos.push([b.impresora.nombre, ...b.documento.bloques.filter(x => x.t === 'item').map(x => x.x)]); return resp({ ok: true }); }
  throw new Error('ruta 9800 inesperada ' + url);
};
// ---- servidor falso: copias y reclamos por plato (5.1) ----
const S = globalThis.S = { t: Date.now(), copias: {}, filas: {} };
const iso = ms => new Date(ms).toISOString();
const ESPERA = o => (o === 'aceptar_anterior' ? 60 : 15) * 1000;
function copia(pid, extra) {
  const ahora = iso(Date.now() - 20000);
  S.copias[pid] = { pedido_id: pid, pedido_numero: 40 + pid, cuenta_id: 100 + pid, cuenta_viva: true, terminal_id: 1, nombre: 'Pedido #' + (40 + pid) + ' · Ana', nota: '', tipo: 'llevar', hora_entrega: '', numero: 7,
    origen: 'pago', creado: ahora, listo_desde: ahora, estado: 'pendiente', sin_comanda: [],
    lineas: [{ pos: 0, producto_id: 1, detalle: 'Casado', cantidad: 2, nota: 'sin cebolla' }, { pos: 1, producto_id: 2, detalle: 'Refresco', cantidad: 1, nota: '' }, { pos: 2, producto_id: 3, detalle: 'Agua', cantidad: 1, nota: '' }], ...(extra || {}) };
  return S.copias[pid];
}
function vista(c) {
  const t = S.t, listo = Date.parse(c.listo_desde), espere = Math.max(0, Math.ceil((listo + ESPERA(c.origen) - t) / 1000));
  return { ...c, espere_s: espere, vieja: t > listo + 30 * 60000, lineas: c.lineas.map(l => { const f = S.filas[c.pedido_id + '|' + l.pos]; return { ...l, estado: f ? f.estado : 'libre', por: f ? f.nombre : '', vence: f ? f.vence : '', intentos: f ? f.intentos : 0 }; }) };
}
function reclamar(b) {
  const c = S.copias[b.pedido_id]; if (!c) return { resultado: 'sin_copia' };
  if (c.estado === 'cerrada') return { resultado: 'cancelado' };
  if (c.estado === 'impresa') return { resultado: 'impresa' };
  const t = S.t, listo = Date.parse(c.listo_desde);
  if (b.momento === 'estacion') { if (t < listo + ESPERA(c.origen)) return { resultado: 'pronto', espere_s: Math.ceil((listo + ESPERA(c.origen) - t) / 1000) }; if (t > listo + 30 * 60000) return { resultado: 'vieja' }; }
  const tomar = {}, libres = b.lineas.filter(p => !(S.filas[b.pedido_id + '|' + p] && S.filas[b.pedido_id + '|' + p].estado === 'impresa'));
  if (!libres.length) return { resultado: 'impresa' };
  for (const p of libres) {
    const k = b.pedido_id + '|' + p, f = S.filas[k];
    const puede = !f || (f.estado === 'reclamada' && Date.parse(f.vence) < t) || (f.estado === 'soltada' && (b.momento !== 'estacion' || (f.intentos < 3 && (f.equipo !== b.equipo || Date.parse(f.soltada_en) < t - 60000))));
    if (!puede) {
      if (f.estado === 'reclamada') return f.equipo === b.equipo ? { resultado: 'en_curso', vence: f.vence } : { resultado: 'ocupada', por: f.nombre, vence: f.vence };
      return f.intentos >= 3 ? { resultado: 'agotada', motivo: f.motivo } : { resultado: 'reintente', espere_s: 60 };
    }
    tomar[k] = { ...(f || { intentos: 0 }), estado: 'reclamada', equipo: b.equipo, nombre: b.nombre, momento: b.momento, vence: iso(t + 60000) };
  }
  Object.assign(S.filas, tomar);
  return { resultado: 'ganada', vence: iso(t + 60000), lineas: libres };
}
function impresa(b) {
  const c = S.copias[b.pedido_id]; let suyas = 0, otras = 0;
  for (const p of b.lineas) { const k = b.pedido_id + '|' + p, f = S.filas[k]; if (f && f.equipo === b.equipo && f.estado === 'reclamada') suyas++; else otras++; S.filas[k] = { ...(f || { intentos: 0 }), estado: 'impresa', equipo: b.equipo }; }
  c.sin_comanda = [...new Set([...c.sin_comanda, ...b.sin_comanda])];
  if (c.lineas.every(l => c.sin_comanda.includes(l.pos) || (S.filas[b.pedido_id + '|' + l.pos] || {}).estado === 'impresa')) c.estado = c.lineas.every(l => c.sin_comanda.includes(l.pos)) ? 'sin_comanda' : 'impresa';
  return { resultado: !b.lineas.length || suyas && !otras ? 'ok' : suyas ? 'doble' : 'sin_reclamo', copia: c.estado, marcadas: 0, cancelado: c.estado === 'cerrada' || !!c.cancelado };
}
function soltar(b) { for (const p of b.lineas) { const k = b.pedido_id + '|' + p, f = S.filas[k]; if (f && f.equipo === b.equipo) S.filas[k] = { ...f, estado: 'soltada', soltada_en: iso(S.t), intentos: f.intentos + (f.momento === 'estacion' ? 1 : 0), motivo: b.motivo }; } return { resultado: 'ok' }; }
Q.api = async (url, opt) => {
  const b = opt && opt.body; Q.llamadas.push((opt && opt.method ? opt.method + ' ' : '') + url + (b ? ' ' + JSON.stringify(b) : ''));
  if (Q.sinRed && url.startsWith('/api/pos/comanda/' + Q.sinRed)) throw new Error('Sin conexión con el servidor');
  if (url.startsWith('/api/pos/comanda/pendientes')) { const m = /pedido_id=(\d+)/.exec(url); const l = Object.values(S.copias).filter(c => (m ? c.pedido_id === +m[1] : c.estado === 'pendiente')).map(vista).filter(c => m || !c.vieja); return { ahora: iso(S.t), copias: l }; }
  if (url === '/api/pos/comanda/reclamar') return reclamar(b);
  if (url === '/api/pos/comanda/impresa') return impresa(b);
  if (url === '/api/pos/comanda/soltar') return soltar(b);
  if (url === '/api/pedidos/resumen') return { nuevos: 0, ultimo_id: 1, comandas_pendientes: Object.values(S.copias).filter(c => c.estado === 'pendiente').length, comanda_espera_s: 0 };
  if (url === '/api/agente/estado') throw Object.assign(new Error('no existe'), { status: 404 });
  throw new Error('ruta inesperada ' + url);
};
const cuentaDe = (pid, extra) => { const c = S.copias[pid]; return { id: 100 + pid, canal: 'online', pedido_id: pid, pedido_numero: 40 + pid, creado: c.creado, lineas: c.lineas.map(l => ({ ...l, enviado: c.creado })), ...(extra || {}) }; };
const limpiar = () => { Q.toasts = []; Q.llamadas = []; Q.fetchs = []; Q.impresos = []; Q.preguntas = []; };
"""


def _falsos(extra=None):
    f = {"api.js": FALSO_API, "app.js": FALSO_APP, "vendor/vue.esm-browser.prod.min.js": FALSO_VUE, "pages/pos/_datos.js": FALSO_DATOS}
    f.update(extra or {})
    return f


ARCHIVOS = ("pages/pos/_agente.js", "pages/pos/_comandas.js", "pages/pos/_estacion.js")


# ================================================================================================================ piezas puras
def test_piezas_puras_de_comandas_y_estacion(tmp_path):
    r = _node(tmp_path, BASE + """
const C = await import('./js/pages/pos/_comandas.js');
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
const eq = C.nuevoEquipo(); out.equipo = [eq.length, /^[0-9a-f]{32}$/.test(eq), C.nuevoEquipo() !== eq];
out.huella = [C.huellaLinea({ detalle: 'Casado', enviado: 'T', nota: 'sin cebolla', cantidad: 2 }), C.huellaLinea({ detalle: 'Té', cantidad: 1.5 }), C.huellaLinea(null)];
const cp = copia(1);
const cuenta = cuentaDe(1);
out.posiciones = C.posicionesDeCopia([cuenta.lineas[1], cuenta.lineas[0], { ...cuenta.lineas[0], enviado: 'otra hora' }], cp);
const datos = { impresoras: Q.imps, categorias: Q.cats, extras: {}, productos: Q.store.productos, cfg: Q.cfg, ahora: iso(S.t) };
const resumen = g => ({ grupos: g.grupos.map(x => [x.imp.nombre, x.directo, x.pos]), sin: g.sin_comanda, caja: g.caja.nombre });
out.grupos = resumen(C.gruposDeCopia(vista(cp), datos));
out.cajaSinComanda = resumen(C.gruposDeCopia(vista(cp), { ...datos, cfg: { terminales: [{ id: 1, nombre: 'Caja 1', imprimir_comanda: false }] } }));
out.sinImpresoras = resumen(C.gruposDeCopia(vista(cp), { ...datos, impresoras: [] }));
out.platoNone = resumen(C.gruposDeCopia(vista(cp), { ...datos, extras: { 1: { impresora_id: 'none' } } }));
S.filas['1|0'] = { estado: 'impresa' }; S.filas['1|1'] = { estado: 'reclamada', vence: iso(S.t + 30000) };
out.ocupados = resumen(C.gruposDeCopia(vista(cp), datos));
S.filas['1|1'] = { estado: 'reclamada', vence: iso(S.t - 1000) }; out.vencido = resumen(C.gruposDeCopia(vista(cp), datos)).grupos;
S.filas['1|1'] = { estado: 'soltada', intentos: 3 }; out.agotadoEstacion = resumen(C.gruposDeCopia(vista(cp), { ...datos, paraEstacion: true })).grupos; out.agotadoCocina = resumen(C.gruposDeCopia(vista(cp), datos)).grupos;
S.filas = {};
out.nota = [C.notaDeCopia({ nota: 'Timbre', hora_entrega: '19:00' }), C.notaDeCopia({ hora_entrega: '19:00', nota: 'PARA LAS 19:00' }), C.notaDeCopia({ nota: 'x' })];
out.avisos = [C.avisoComandaNoImpresa(['a.']), C.avisoComandaNoImpresa(['a.'], { saleSola: true }), C.avisoComandaNoImpresa([C.MOTIVO_SIN_AGENTE], { saleSola: true }), C.textoAceptadoOcupada('Caja 1 · Caja'), C.textoAceptadoMasTarde('19:00')];
// sucursal (D-13)
out.sucursal = [E.esDeEstaSucursal({ terminal_id: 1 }, Q.cfg, null), E.esDeEstaSucursal({ terminal_id: 2 }, Q.cfg, null), E.esDeEstaSucursal({ terminal_id: 2 }, Q.cfg, 9), E.esDeEstaSucursal({ terminal_id: 1 }, Q.cfg, 9)];
// indicio (D-15)
const ahora = Date.now(), vieja = { ...cuenta, creado: iso(ahora - 31 * 60000), lineas: cuenta.lineas.map(l => ({ ...l, enviado: iso(ahora - 31 * 60000) })) };
out.indicio = [E.indicio([cuenta], null, { ahora }), E.indicio([{ ...cuenta, lineas: cuenta.lineas.map(l => ({ ...l, impreso: true })) }], null, { ahora }), E.indicio([vieja], null, { ahora }),
  E.indicio([{ ...cuenta, canal: '' }], null, { ahora }), E.indicio([cuenta], null, { ahora, resueltos: new Set([1]) }), E.indicio([cuenta], null, { ahora, esperando: new Map([[1, ahora + 5000]]) }),
  E.indicio([], { comandas_pendientes: 2, comanda_espera_s: 0, hora: ahora }, { ahora }), E.indicio([], { comandas_pendientes: 2, comanda_espera_s: 40, hora: ahora }, { ahora }),
  E.indicio([], { comandas_pendientes: 2, comanda_espera_s: null, hora: ahora }, { ahora }), E.indicio([], { comandas_pendientes: 0 }, { ahora }), E.indicio([{ id: 5, lineas: [{ enviado: 'x' }] }], null, { ahora })];
// interruptor (D-14): encendido por omisión; por empresa
out.interruptor = [E.estacionEncendida(), E.encenderEstacion(false), localStorage.getItem('pos:estacion_comandas:7'), E.estacionEncendida(), E.encenderEstacion(true), E.estacionEncendida()];
out.nombre = [E.nombreEquipo('caja'), E.nombreEquipo('cocina'), E.ESTACION_EN_PROGRAMA];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["equipo"] == [32, True, True], r
    assert r["huella"] == ["Casado|T|sin cebolla|2", "Té|||1.5", "|||0"], r
    assert r["posiciones"] == [1, 0], r                                            # la tercera no es de la copia (otra hora)
    assert r["grupos"] == {"grupos": [["Cocina", True, [0]], ["Bar", False, [1]]], "sin": [2], "caja": "Caja 1"}, r
    assert r["cajaSinComanda"]["grupos"] == [] and r["cajaSinComanda"]["sin"] == [0, 1, 2], r   # «imprimir la comanda» apagado: todo sin comanda
    assert r["sinImpresoras"]["grupos"] == [] and r["sinImpresoras"]["sin"] == [0, 1, 2], r
    assert r["platoNone"]["grupos"] == [["Bar", False, [1]]] and r["platoNone"]["sin"] == [0, 2], r
    assert r["ocupados"]["grupos"] == [] and r["ocupados"]["sin"] == [2], r            # impresa y reclamada vigente: no se intentan
    assert r["vencido"] == [["Bar", False, [1]]], r
    assert r["agotadoEstacion"] == [] and r["agotadoCocina"] == [["Bar", False, [1]]], r
    assert r["nota"] == ["Timbre · PARA LAS 19:00", "PARA LAS 19:00", "x"], r
    assert r["avisos"] == [
        "Pedido aceptado. La comanda no se imprimió: a. Imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda no se imprimió en este equipo (a): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda no se imprimió en este equipo (este equipo no tiene el programa de escritorio ni el agente de impresión abiertos): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.",
        "Pedido aceptado. La comanda la está imprimiendo «Caja 1 · Caja».",
        "Pedido aceptado para las 19:00. La comanda saldrá sola en la computadora de la caja o de la cocina 45 minutos antes."], r
    assert r["sucursal"] == [True, False, True, False], r
    assert r["indicio"] == [True, False, False, False, False, False, True, False, False, False, False], r
    assert r["interruptor"] == [True, False, "0", False, True, True], r
    assert r["nombre"] == ["Caja 1 · Caja", "Caja 1 · Cocina", False], r


# ================================================================================================================ cero peticiones
def test_la_estacion_no_hace_peticiones_sin_motivo(tmp_path):
    r = _node(tmp_path, BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
copia(1); Q.espera = [cuentaDe(1)];
const caso = async (nombre, antes, despues) => { limpiar(); E._reiniciar(); antes(); const res = await E.revisarEstacion('caja'); out[nombre] = [res, Q.llamadas.length + Q.fetchs.length]; despues(); };
await caso('apagada', () => E.encenderEstacion(false), () => E.encenderEstacion(true));
await caso('sin_modulo', () => { Q.modulos = []; }, () => { Q.modulos = ['pedidos_online']; });
await caso('oculta', () => { document.hidden = true; }, () => { document.hidden = false; });
await caso('programa', () => { Q.sesion.empresaInfo.es_local = true; }, () => { Q.sesion.empresaInfo.es_local = false; });
await caso('sin_datos', () => { Q.cargado = false; }, () => { Q.cargado = true; });
await caso('sin_indicio', () => { Q.espera = []; }, () => { Q.espera = [cuentaDe(1)]; });
await caso('otra_sucursal', () => { Q.terminal = { id: 2, nombre: 'Caja Sur', sucursal_id: 9 }; }, () => { Q.terminal = { id: 1, nombre: 'Caja 1' }; });
out.otra_sucursal_llamadas = Q.llamadas.map(x => x.split(' ')[0]);
// solo impresoras del navegador: se pregunta al servidor, pero nunca al agente
Q.imps = [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'navegador' }, { id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'navegador' }];
limpiar(); E._reiniciar(); out.navegador = [await E.revisarEstacion('cocina'), Q.llamadas.map(x => x.split(' ')[0]), Q.fetchs, Q.impresos.length];
// avisarSiPendiente no hace peticiones
limpiar(); out.aviso = [E.avisarSiPendiente(cuentaDe(1)), Q.toasts, Q.llamadas.length + Q.fetchs.length];
Q.modulos = []; limpiar(); out.avisoSinModulo = [E.avisarSiPendiente(cuentaDe(1)), Q.toasts.length]; Q.modulos = ['pedidos_online'];
limpiar(); out.avisoImpresa = E.avisarSiPendiente(cuentaDe(1, { lineas: cuentaDe(1).lineas.map(l => ({ ...l, impreso: true })) }));
// soloAgente: ni una petición a /api/agente/estado
const A = await import('./js/pages/pos/_agente.js');
limpiar(); await A.agenteEstado(true, { soloAgente: true }); out.soloAgente = [Q.llamadas, Q.fetchs];
limpiar(); await A.agenteEstado(true); out.normal = [Q.llamadas.map(x => x.split(' ')[0]), Q.fetchs];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    for k in ("apagada", "sin_modulo", "oculta", "programa", "sin_datos", "sin_indicio"):
        assert r[k][1] == 0, (k, r)                                                   # cero llamadas a la red
    assert [r[k][0] for k in ("apagada", "sin_modulo", "oculta", "programa", "sin_datos", "sin_indicio")] == ["apagada", "sin_modulo", "oculta", "sin_modulo", "sin_datos", "sin_indicio"], r
    assert r["otra_sucursal"][0] == "sin_directos" and r["otra_sucursal_llamadas"] == ["/api/pos/comanda/pendientes"], r   # la copia es de otra caja: no se toca
    assert r["navegador"][0] == "sin_directos" and r["navegador"][1] == ["/api/pos/comanda/pendientes"] and r["navegador"][2] == [] and r["navegador"][3] == 0, r
    assert r["aviso"][0] is True and r["aviso"][2] == 0, r
    assert r["aviso"][1] == [["La comanda del pedido #41 todavía no se ha impreso. Saldrá sola en la computadora de la caja o de la cocina; si en un minuto no ha salido, imprímala desde Punto de venta › Cocina, en «Pedidos en línea con la comanda sin imprimir».", "info"]], r
    assert r["avisoSinModulo"] == [False, 0] and r["avisoImpresa"] is False, r
    assert r["soloAgente"] == [[], ["9800/estado"]], r
    assert r["normal"] == [["/api/agente/estado"], ["9800/estado"]], r


# ================================================================================================================ la pasada con el servidor falso
def test_la_estacion_imprime_una_vez_y_respeta_los_reclamos(tmp_path):
    r = _node(tmp_path, BASE + """
const fs = await import('node:fs');
fs.cpSync('./js', './js2', { recursive: true });                                  // la segunda estación: otra pestaña (otro módulo, otro EQUIPO)
const E = await import('./js/pages/pos/_estacion.js');
const E2 = await import('./js2/pages/pos/_estacion.js');
const out = {};
const reset = () => { S.copias = {}; S.filas = {}; S.t = Date.now(); E._reiniciar(); E2._reiniciar(); limpiar(); Q.rotas = []; };
// ganada: una impresión (solo la Cocina de red: el Bar es del navegador y el Agua «sin comanda») y una marca con las «sin comanda»
reset(); copia(1); Q.espera = [cuentaDe(1)];
out.ganada = [await E.revisarEstacion('caja'), Q.impresos, Q.toasts, Q.llamadas.filter(x => x.startsWith('POST')).map(x => x.replace(/"equipo":"[0-9a-f]+"/, '"equipo":"E"'))];
out.ganadaFilas = Object.entries(S.filas).map(([k, f]) => [k, f.estado]);
limpiar(); out.otraPasada = [await E.revisarEstacion('caja'), Q.impresos.length];               // ya impresa: no sale otra vez
// pronto: antes de 15 s el servidor no deja; la estación espera sin imprimir
reset(); copia(2, { listo_desde: iso(Date.now() - 5000), creado: iso(Date.now() - 5000) }); Q.espera = [cuentaDe(2)];
out.pronto = [await E.revisarEstacion('caja'), Q.impresos.length, Q.llamadas.filter(x => x.includes('reclamar')).length];
// ocupada: otra computadora la tiene (aceptó en Pedidos): nada
reset(); copia(3); Q.espera = [cuentaDe(3)]; S.filas['3|0'] = { estado: 'reclamada', equipo: 'otraPestana01', nombre: 'Pedidos · Ana', vence: iso(S.t + 50000), intentos: 0 };
out.ocupada = [await E.revisarEstacion('caja'), Q.impresos.length, Q.toasts.length];
// falla de la impresora: suelta con el motivo y no lo intenta otra vez en 60 s (otra estación sí puede de inmediato)
reset(); copia(4); Q.espera = [cuentaDe(4)]; Q.rotas = ['Cocina'];
out.falla = [await E.revisarEstacion('cocina'), Q.impresos.length, Q.toasts, Q.llamadas.filter(x => x.includes('soltar')).map(x => JSON.parse(x.slice(x.indexOf('{'))).motivo), S.filas['4|0'].estado, S.filas['4|0'].intentos];
limpiar(); out.fallaOtraVez = [await E.revisarEstacion('cocina'), Q.llamadas.filter(x => x.includes('reclamar')).length];
Q.rotas = []; limpiar(); out.otraEstacion = [await E2.revisarEstacion('caja'), Q.impresos];
// dos estaciones a la vez: cada plato sale una sola vez
reset(); copia(5); copia(6); Q.espera = [cuentaDe(5), cuentaDe(6)];
let liberar; Q.lento = new Promise(r => { liberar = r; });
const a = E.revisarEstacion('caja'), b = E2.revisarEstacion('cocina');
await new Promise(r => setTimeout(r, 50)); liberar(); Q.lento = null;
out.dos = [await a, await b, Q.impresos.map(x => x.join(':')).sort()];
// dos pasadas superpuestas en la misma pestaña: la segunda no corre
reset(); copia(7); Q.espera = [cuentaDe(7)]; Q.lento = new Promise(r => { liberar = r; });
const p1 = E.revisarEstacion('caja'); const p2 = await E.revisarEstacion('cocina'); liberar(); Q.lento = null;
out.superpuestas = [p2, await p1, Q.impresos.length];
// la estación y Cocina a mano en la misma pestaña: una sola impresión
reset(); copia(8); Q.espera = [cuentaDe(8)]; Q.lento = new Promise(r => { liberar = r; }); Q.responder = true;
const est = E.revisarEstacion('cocina'); await new Promise(r => setTimeout(r, 30));
const mano = await E.imprimirPedidoCocina(8, { preguntar: () => true }); liberar(); Q.lento = null;
out.mismaPestana = [await est, mano, Q.impresos.length];
// Cocina a mano con otra computadora imprimiendo: pregunta; sin confirmar no imprime
reset(); copia(9, { lineas: [{ pos: 0, producto_id: 1, detalle: 'Casado', cantidad: 2, nota: '' }] }); S.filas['9|0'] = { estado: 'reclamada', equipo: 'otraPestana01', nombre: 'Caja 2 · Caja', vence: iso(S.t + 50000), intentos: 0 };
let pregunta = null; const no = await E.imprimirPedidoCocina(9, { preguntar: t => { pregunta = t; return false; } });
out.cocinaOcupada = [no, pregunta, Q.impresos.length];
const si = await E.imprimirPedidoCocina(9, { preguntar: () => true }); out.cocinaOcupadaSi = [si.hecho, Q.impresos.length, S.filas['9|0'].estado];
// Cocina a mano sin red para revisar: pregunta; con «sí» sigue lo de hoy (sin copia)
reset(); copia(10); Q.sinRed = 'pendientes'; let p3 = null, p4 = null;
out.cocinaSinRed = [await E.imprimirPedidoCocina(10, { preguntar: t => { p3 = t; return true; }, lineas: cuentaDe(10).lineas }), p3];
// la banda (sin tarjeta) no tiene de dónde imprimir sin la copia: no pregunta
out.bandaSinRed = [await E.imprimirPedidoCocina(10, { preguntar: t => { p4 = t; return true; } }), p4]; Q.sinRed = null;
// la línea de cocina.js: sin pedido en línea o ya impresa, Cocina sigue como hoy
out.lineaCocina = [await E.imprimirCocinaEnLinea({ impresa: false, cuenta: { canal: '', pedido_id: null } }), await E.imprimirCocinaEnLinea({ impresa: true, cuenta: { canal: 'online', pedido_id: 10 } })];
// cancelado mientras se imprimía
reset(); copia(11, { cancelado: true }); Q.espera = [cuentaDe(11)];
out.cancelado = [await E.revisarEstacion('caja'), Q.toasts];
// agotada: 3 fallas de estación → aviso una vez; Cocina a mano todavía puede
reset(); copia(12); Q.espera = [cuentaDe(12)]; S.filas['12|0'] = { estado: 'soltada', equipo: 'otraPestana01', intentos: 3, soltada_en: iso(S.t - 120000), momento: 'estacion' };
out.agotada = [await E.revisarEstacion('caja'), Q.impresos.length, Q.llamadas.filter(x => x.includes('reclamar')).length];
// el agente no responde: no se reclama nada y la banda dice que no sale sola
reset(); copia(13); Q.espera = [cuentaDe(13)]; Q.agente = false; const A = await import('./js/pages/pos/_agente.js'); await A.agenteEstado(true, { soloAgente: true }); limpiar();
out.sinAgente = [await E.revisarEstacion('cocina'), Q.llamadas.filter(x => x.includes('reclamar')).length, E.textoEstacion()]; Q.agente = true; await A.agenteEstado(true, { soloAgente: true });
reset(); copia(14); Q.espera = [cuentaDe(14)]; await E.revisarEstacion('cocina'); out.activa = E.textoEstacion();
// la banda de Cocina: la cuenta ya se cobró o la espera pasó hace más de 60 s
out.lista = E.listaCocina([vista(copia(15, { cuenta_viva: false })), vista(copia(16)), vista(copia(17, { listo_desde: iso(S.t - 120000), creado: iso(S.t - 120000) }))], iso(S.t), Q.cfg, null).map(x => x.texto);
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["ganada"][0] == "lista" and r["ganada"][1] == [["Cocina", "Casado"]], r
    assert r["ganada"][2] == [["Comanda del pedido #41 impresa en «Cocina».", "ok"]], r
    posts = r["ganada"][3]
    assert [p.split(" ")[1] for p in posts] == ["/api/pos/comanda/reclamar", "/api/pos/comanda/impresa"], r
    assert '"momento":"estacion"' in posts[0] and '"lineas":[0]' in posts[0] and '"nombre":"Caja 1 · Caja"' in posts[0], r
    assert '"lineas":[0],"sin_comanda":[2]' in posts[1], r
    assert r["ganadaFilas"] == [["1|0", "impresa"]] and r["otraPasada"][1] == 0, r
    assert r["pronto"] == ["sin_directos", 0, 0], r                                   # antes de 15 s: ni se reclama (el servidor tampoco dejaría)
    assert r["ocupada"][1:] == [0, 0], r                                               # otra computadora la tiene: nada
    f = r["falla"]
    assert f[1] == 0 and f[3] == ["La impresora «Cocina» no responde"] and f[4] == "soltada" and f[5] == 1, r
    assert f[2] == [["La comanda del pedido #44 no salió sola en «Cocina»: La impresora «Cocina» no responde. Imprímala desde Punto de venta › Cocina.", "err"]], r
    assert r["fallaOtraVez"][1] == 0, r                                               # la misma computadora no la intenta antes de 60 s
    assert r["otraEstacion"][1] == [["Cocina", "Casado"]], r                          # otra estación sí, de inmediato
    assert r["dos"][2] == ["Cocina:Casado", "Cocina:Casado"], r                       # dos pedidos, cada plato una sola vez
    assert r["superpuestas"][0] == "corriendo" and r["superpuestas"][2] == 1, r
    assert r["mismaPestana"][2] == 1, r                                               # la estación y Cocina a mano: un solo papel
    assert r["cocinaOcupada"][0] == {"hecho": False, "resultado": "no"} and r["cocinaOcupada"][2] == 0, r
    assert r["cocinaOcupada"][1] == "La computadora «Caja 2 · Caja» está imprimiendo esta comanda en este momento. ¿Imprimirla aquí también?", r
    assert r["cocinaOcupadaSi"] == [True, 1, "impresa"], r
    assert r["cocinaSinRed"] == [{"hecho": False, "resultado": "sin_copia"}, "No se pudo revisar si otra computadora está imprimiendo esta comanda. ¿Imprimirla de todos modos?"], r
    assert r["bandaSinRed"] == [{"hecho": False, "resultado": "sin_red"}, None], r
    assert r["lineaCocina"] == [False, False], r
    assert ["El pedido #51 se canceló mientras se imprimía su comanda: avise a la cocina.", "err"] in r["cancelado"][1], r
    assert r["agotada"][1] == 0 and r["agotada"][2] == 0, r                           # la estación ya no lo intenta (lo hace Cocina a mano)
    assert r["sinAgente"] == ["sin_agente", 0, "Las comandas de los pedidos en línea no salen solas en esta computadora: abra el programa de escritorio o el agente de impresión."], r
    assert r["activa"] == "Las comandas de los pedidos en línea salen solas en esta computadora.", r
    assert [x.split(" · ")[0] for x in r["lista"]] == ["#55", "#57"] and all(re.fullmatch(r"#\d+ · hace \d+ min", x) for x in r["lista"]), r


# ================================================================================================================ correcciones (verificación 4.31)
# «Imprimir» de una tarjeta de Cocina: el servidor manda (ya impresa = reimpresión a propósito), nada se marca si no salió, solo lo de la
# tarjeta (su ronda y su estación), la ventana del navegador se abre en el toque y la bloqueada no cuenta como impresa.
TARJETAS = r"""
const E = await import('./js/pages/pos/_estacion.js');
const out = {}, marcas = [];
const IMPS0 = Q.imps, CFG0 = Q.cfg;
const abrirBase = globalThis.window.open;
globalThis.window.open = (...a) => { const w = abrirBase.apply(globalThis.window, a); if (w) Q.abiertas.push(w); return w; };
const reset = () => { S.copias = {}; S.filas = {}; S.t = Date.now(); E._reiniciar(); limpiar(); Q.rotas = []; Q.ventanas = 0; Q.abiertas = []; Q.htmls = []; Q.responder = false; Q.imps = IMPS0; Q.cfg = CFG0; marcas.length = 0; };
const IMP = { 0: Q.imps[0], 1: Q.imps[1], 2: null };
const tarjeta = (pid, poss) => { const cu = cuentaDe(pid); return { cuenta: cu, impresa: false, lineas: cu.lineas.filter(l => poss.includes(l.pos)).map(l => ({ ...l, imp: IMP[l.pos] })) }; };
const marcar = async ls => { marcas.push(ls ? ls.map(l => l.detalle) : 'TODAS'); };
const reclamos = () => Q.llamadas.filter(x => x.includes('/reclamar')).map(x => JSON.parse(x.slice(x.indexOf('{'))).lineas);
const posts = ruta => Q.llamadas.filter(x => x.includes(ruta)).map(x => { const b = JSON.parse(x.slice(x.indexOf('{'))); return [b.lineas, b.sin_comanda]; });
const forma = r => (r && typeof r === 'object' && r.ventana ? { ...r, ventana: r.ventana.closed ? 'cerrada' : 'abierta' } : r);   /* la ventana que va a Cocina */
"""


def test_cocina_a_mano_el_servidor_manda_y_solo_la_tarjeta(tmp_path):
    r = _node(tmp_path, BASE + TARJETAS + """
// (alta 1) la copia ya está impresa en el servidor y la tarjeta todavía no se ve «Impresa»: la pregunta de siempre
reset(); copia(1, { estado: 'impresa' }); S.filas['1|0'] = { estado: 'impresa' }; S.filas['1|1'] = { estado: 'impresa' };
out.yaNo = [await E.imprimirCocinaEnLinea(tarjeta(1, [0, 1, 2]), marcar), Q.preguntas, Q.impresos.length, reclamos().length, marcas.slice(), Q.abiertas.every(w => w.closed)];
reset(); copia(1, { estado: 'impresa' }); Q.responder = true;
out.yaSi = [forma(await E.imprimirCocinaEnLinea(tarjeta(1, [0, 1, 2]), marcar)), Q.preguntas, marcas.slice(), Q.abiertas.map(w => w.closed)];
// (alta 1) la parte de la tarjeta del Bar ya salió (la estación) aunque la Cocina no: la tarjeta del Bar pregunta y no imprime nada
reset(); copia(2); S.filas['2|1'] = { estado: 'impresa', equipo: 'otraPestana01', nombre: 'Caja 1 · Caja', intentos: 0 };
out.barYa = [await E.imprimirCocinaEnLinea(tarjeta(2, [1]), marcar), Q.preguntas, Q.impresos.length, reclamos(), marcas.slice()];
// (alta 2) la caja con «imprimir la comanda» apagado o sin impresoras de comanda: no se marca nada; Cocina imprime como hoy si se pidió
reset(); copia(3); Q.cfg = { terminales: [{ ...CFG0.terminales[0], imprimir_comanda: false }, CFG0.terminales[1]] };
out.cajaSinComanda = [forma(await E.imprimirCocinaEnLinea(tarjeta(3, [0, 1, 2]), marcar)), Q.impresos.length, marcas.slice(), posts('/impresa'), S.copias[3].estado];
reset(); copia(4); Q.imps = [];
out.sinImpresoras = [forma(await E.imprimirCocinaEnLinea(tarjeta(4, [0, 1, 2]), marcar)), Q.impresos.length, marcas.slice(), S.copias[4].estado];
// (alta 3) la tarjeta del Bar (filtro por estación) reclama, imprime y marca solo el Bar; la Cocina queda libre para la estación
reset(); copia(5);
out.soloBar = [await E.imprimirCocinaEnLinea(tarjeta(5, [1]), marcar), reclamos(), Q.impresos.length, (Q.htmls || []).length, marcas.slice(), S.filas['5|0'] || null, S.filas['5|1'].estado];
// (alta 3) una ronda que no es la de la copia (la caja agregó platos): Cocina como hoy, sin reclamar ni marcar nada de la copia
reset(); copia(6); const t6 = tarjeta(6, [0]); t6.lineas = t6.lineas.map(l => ({ ...l, enviado: iso(Date.now()), ronda: 2 }));
out.ronda2 = [await E.imprimirCocinaEnLinea(t6, marcar), reclamos().length, Q.impresos.length, marcas.slice()];
// (media, prueba T9c) otra computadora tiene la Cocina y se contesta «No»: sale el Bar y solo el Bar queda marcado; al vencer, la estación imprime la Cocina
reset(); copia(7); S.filas['7|0'] = { estado: 'reclamada', equipo: 'otraPestana01', nombre: 'Caja salón · Caja', vence: iso(S.t + 50000), intentos: 0 };
out.t9c = [await E.imprimirCocinaEnLinea(tarjeta(7, [0, 1, 2]), marcar), Q.preguntas, marcas.slice(), S.filas['7|0'].estado, S.filas['7|1'].estado, Q.impresos.length];
S.t += 61000; Q.espera = [cuentaDe(7)]; limpiar();
out.t9cDespues = [await E.revisarEstacion('cocina'), Q.impresos, S.filas['7|0'].estado];
// platos de la tarjeta que no son de la copia: los de la copia salen desde la copia y el resto se lo devuelve a Cocina
reset(); copia(8); const t8 = tarjeta(8, [1]); t8.lineas.push({ ...t8.lineas[0], detalle: 'Refresco grande', cantidad: 3 });
const r8 = await E.imprimirCocinaEnLinea(t8, marcar); out.resto = [r8 && r8.resto ? r8.resto.map(l => l.detalle) : r8, reclamos(), marcas.slice()];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    ya = "Esta comanda ya se imprimió. ¿Imprimirla otra vez?"
    assert r["yaNo"] == [True, [ya], 0, 0, [["Casado", "Refresco", "Agua"]], True], r          # «No»: nada sale (la ventana se cierra); la tarjeta pasa a «Impresa»
    # «Sí»: Cocina reimprime como siempre, con otra ventana abierta enseguida (la del toque se cerró para que se viera la pregunta)
    assert r["yaSi"] == [{"ventana": "abierta"}, [ya], [], [True, False]], r
    assert r["barYa"] == [True, [ya], 0, [], [["Refresco"]]], r                                  # ni reclama ni imprime la Cocina ajena a la tarjeta
    # sin marca de impresa; ya no es candidata de la estación; Cocina imprime como hoy en la ventana del toque (Bar del navegador y Agua)
    assert r["cajaSinComanda"] == [{"ventana": "abierta"}, 0, [], [[[], [0, 1, 2]]], "sin_comanda"], r
    assert r["sinImpresoras"] == [{"ventana": "abierta"}, 0, [], "sin_comanda"], r
    assert r["soloBar"][:2] == [True, [[1]]] and r["soloBar"][2:5] == [0, 1, [["Refresco"]]] and r["soloBar"][5] is None and r["soloBar"][6] == "impresa", r
    assert r["ronda2"] == [False, 0, 0, []], r
    assert r["t9c"] == [True, ["La computadora «Caja salón · Caja» está imprimiendo esta comanda en este momento. ¿Imprimirla aquí también?"], [["Refresco"]], "reclamada", "impresa", 0], r
    assert r["t9cDespues"] == ["lista", [["Cocina", "Casado"]], "impresa"], r                     # la parte de la Cocina sale una vez
    assert r["resto"] == [["Refresco grande"], [[1]], [["Refresco"]]], r


def test_cocina_a_mano_la_ventana_se_abre_en_el_toque_y_la_bloqueada_no_cuenta(tmp_path):
    r = _node(tmp_path, BASE + TARJETAS + """
const abrir0 = globalThis.window.open, api0 = Q.api, orden = [];
globalThis.window.open = (...a) => { orden.push('ventana' + (a[0] ? ':blob' : '')); return abrir0.apply(globalThis.window, a); };
Q.api = async (u, o) => { orden.push(u.split('?')[0]); return api0(u, o); };
reset(); copia(1);
out.toque = [await E.imprimirCocinaEnLinea(tarjeta(1, [1]), marcar), orden.slice(0, 2), orden.includes('ventana:blob'), (Q.htmls || []).filter(h => h.includes('Refresco')).length, marcas.slice()];
// la tarjeta solo con impresoras directas: ninguna ventana
reset(); copia(2); orden.length = 0;
out.directa = [await E.imprimirCocinaEnLinea(tarjeta(2, [0]), marcar), orden.filter(x => x.startsWith('ventana')), Q.impresos];
// el navegador bloquea la ventana: no se marca (ni en el servidor ni en Cocina), se suelta y se avisa
reset(); copia(3); globalThis.window.open = () => null;
out.bloqueada = [await E.imprimirCocinaEnLinea(tarjeta(3, [1]), marcar), marcas.slice(), S.filas['3|1'].estado, posts('/impresa'), Q.toasts];
globalThis.window.open = abrir0; Q.api = api0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["toque"][0] is True and r["toque"][1] == ["ventana", "/api/pos/comanda/pendientes"], r   # abierta antes de esperar al servidor
    assert r["toque"][2] is False and r["toque"][3] == 1 and r["toque"][4] == [["Refresco"]], r      # la comanda se escribe en esa ventana
    assert r["directa"] == [True, [], [["Cocina", "Casado"]]], r
    b = r["bloqueada"]
    assert b[0] is True and b[1] == [] and b[2] == "soltada" and b[3] == [], r
    assert b[4] == [["La comanda del pedido #43 no se imprimió en «Bar»: el navegador no abrió la ventana de impresión (revise si bloquea las ventanas emergentes de esta página). Toque «Imprimir» otra vez cuando lo haya revisado.", "err"]], r


# ================================================================================================================ tercera vuelta (verificación 4.31 r2)
def test_la_ventana_del_toque_tambien_para_lo_de_hoy_y_queda_para_cocina(tmp_path):
    """revisa:431-corr (media, _estacion.js): la ventana se abre en el toque también para platos sin impresora o de la «Cocina» del
    navegador, y cuando la tarjeta termina en el camino de siempre de Cocina (sin copia, «ya impresa» con «Sí», platos de fuera de la copia)
    la ventana va a Cocina en vez de cerrarse. La banda sin conexión no pregunta ni dice «ya no está pendiente»."""
    r = _node(tmp_path, BASE + TARJETAS + """
const abrir0 = globalThis.window.open, api0 = Q.api, orden = [];
globalThis.window.open = (...a) => { orden.push('ventana' + (a[0] ? ':blob' : '')); return abrir0.apply(globalThis.window, a); };
Q.api = async (u, o) => { orden.push(u.split('?')[0]); return api0(u, o); };
// (a) el iPad sin impresoras de comanda (imprime desde Cocina por la ventana del navegador): el Agua no tiene impresora
reset(); copia(1); Q.imps = []; orden.length = 0;
out.sinImpresoras = [forma(await E.imprimirCocinaEnLinea(tarjeta(1, [0, 2]), marcar)), orden[0], Q.abiertas.length, marcas.slice()];
// la «Cocina» del navegador (virtual) también
reset(); copia(2); Q.imps = []; orden.length = 0;
const t2 = tarjeta(2, [0]); t2.lineas = t2.lineas.map(l => ({ ...l, imp: { id: 'v:Cocina', nombre: 'Cocina', virtual: true } }));
out.virtual = [forma(await E.imprimirCocinaEnLinea(t2, marcar)), orden[0]];
// (b) sin red al revisar y «Sí»: la ventana se cierra para la pregunta y se abre otra enseguida, que va a Cocina
reset(); copia(3); Q.sinRed = 'pendientes'; Q.responder = true; orden.length = 0;
out.sinRedSi = [forma(await E.imprimirCocinaEnLinea(tarjeta(3, [1]), marcar)), Q.preguntas.length, Q.abiertas.map(w => w.closed), orden.filter(x => x.startsWith('ventana'))];
Q.sinRed = null;
// (c) la copia sale por la impresora directa y un plato de fuera de la copia va al navegador: la ventana del toque queda para él
reset(); copia(4); const t4 = tarjeta(4, [0]); t4.lineas.push({ ...t4.lineas[0], detalle: 'Limonada grande', imp: IMP[1] });
const r4 = await E.imprimirCocinaEnLinea(t4, marcar);
out.resto = [forma(r4 && r4.resto ? { ...r4, resto: r4.resto.map(l => l.detalle) } : r4), Q.impresos, Q.abiertas.length, marcas.slice()];
// (d) la banda sin conexión: no pregunta (sin la copia no hay qué imprimir), avisa y el pedido sigue en la lista
reset(); copia(5); E.estadoEstacion.lista = [{ pedido_id: 5, texto: '#45 · hace 2 min' }]; Q.sinRed = 'pendientes';
out.banda = [await E.imprimirListaCocina(5), Q.preguntas, Q.toasts, E.estadoEstacion.lista.map(x => x.pedido_id), Q.abiertas.every(w => w.closed)];
Q.sinRed = null; globalThis.window.open = abrir0; Q.api = api0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["sinImpresoras"] == [{"ventana": "abierta"}, "ventana", 1, []], r                  # abierta antes de esperar al servidor; nada marcado
    assert r["virtual"] == [{"ventana": "abierta"}, "ventana"], r
    assert r["sinRedSi"] == [{"ventana": "abierta"}, 1, [True, False], ["ventana", "ventana"]], r
    assert r["resto"] == [{"resto": ["Limonada grande"], "ventana": "abierta"}, [["Cocina", "Casado"]], 1, [["Casado"]]], r
    assert r["banda"] == [{"hecho": False, "resultado": "sin_red"}, [], [["No se pudo revisar esa comanda porque no hay conexión con el servidor. Toque «Imprimir» otra vez en un momento.", "err"]], [5], True], r


# cocina.js con la estación de mentira: la ventana del toque, la ventana bloqueada y la marca «impreso»
FALSO_DATOS_COCINA = """
const COC = { id: 'c', nombre: 'Cocina', conexion: 'usb' }, BAR = { id: 'b', nombre: 'Bar', conexion: 'navegador' };
export const enEspera = () => globalThis.Q.espera || [], impresorasComanda = () => [], categorias = () => [], terminales = () => [], terminalActual = () => null;
export const impresoraDe = p => (p.id === 1 ? COC : p.id === 2 ? BAR : null);
"""
FALSO_ESTACION_COCINA = """
export const estadoEstacion = { lista: [] }, TEXTO_LISTA_COCINA = '';
export const iniciarEstacion = () => {}, pararEstacion = () => {}, revisarEstacion = () => {}, textoEstacion = () => '', imprimirListaCocina = () => null;
export const imprimirCocinaEnLinea = async () => globalThis.Q.respuesta;
"""
FALSO_APP_COCINA = ("export const sesion = { empresa_id: 1, usuario: { correo: 'cocina-431@example.test' }, empresaInfo: {} };\n"
                    "export const store = { productos: [{ id: 1, categoria: 'Platos' }, { id: 2, categoria: 'Bebidas' }, { id: 3, categoria: 'Vitrina' }] };\n")


def test_cocina_usa_la_ventana_del_toque_y_no_marca_si_no_se_abrio(tmp_path):
    """revisa:431-corr (media, cocina.js): «Imprimir» escribe la comanda del navegador en la ventana abierta en el toque (la que manda la
    estación) y, si no hay ventana (el navegador la bloqueó), avisa en rojo y no marca «impreso» lo que iba a ella: solo lo que salió por la
    impresora directa. Antes marcaba todo y el servidor lo tomaba como impreso por una Cocina anterior: la comanda no salía nunca."""
    from tests.test_425_ultimos_pantallas import MONTAR
    from tests.test_429_pedido_web_comanda import FALSO_AGENTE as AGENTE_429, FALSO_API as API_429, NAVEGADOR as NAVEGADOR_429
    guion = NAVEGADOR_429.replace("Date.prototype", "const Q = globalThis.Q = { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0 };\nDate.prototype", 1) + MONTAR + """
globalThis.setInterval = () => 1; globalThis.clearInterval = () => {};
const K = await import('./js/pages/pos/cocina.js'), C = K.default;
const out = {};
const E = '2026-11-12T16:30:00Z', L = (id, detalle) => ({ producto_id: id, detalle, cantidad: 1, enviado: E, ronda: 1 });
Q.espera = [{ id: 5, nombre: 'Pedido #45 · Ana', canal: 'online', pedido_id: 9, terminal_id: 1, creado: E, lineas: [L(1, 'Casado'), L(2, 'Limonada'), L(3, 'Agua')] },
  { id: 6, nombre: 'Pedido #46 · Luis', canal: 'online', pedido_id: 10, terminal_id: 1, creado: E, lineas: [L(2, 'Limonada'), L(3, 'Agua')] },
  { id: 7, nombre: 'Pedido #47 · Eva', canal: 'online', pedido_id: 11, terminal_id: 1, creado: E, lineas: [L(1, 'Casado')] },
  { id: 8, nombre: 'Pedido #48 · Rosa', canal: 'online', pedido_id: 12, terminal_id: 1, creado: E, lineas: [L(1, 'Casado'), L(3, 'Agua')] }];
const fresco = () => { Q.datos.pos_espera = JSON.parse(JSON.stringify(Q.espera)); Q.docs = []; Q.htmls = []; Q.abiertas = 0; Q.toasts = []; Q.bloqueada = false; };
const esperar = async () => { for (let i = 0; i < 50; i++) await new Promise(r => setImmediate(r)); };
const vm = montar(C);
C.created.call(vm); await esperar();
const tarjeta = id => vm.tickets.find(x => x.cuenta.id === id);
const marcados = id => Q.datos.pos_espera.find(x => x.id === id).lineas.map(l => [l.detalle, !!l.impreso]);
const ventana = () => { const w = { closed: false, html: [], document: { open() {}, write(h) { w.html.push(h); }, close() {} }, close() { w.closed = true; } }; return w; };
// (1) la estación manda la ventana del toque: la Limonada (Bar del navegador) y el Agua (sin impresora) se escriben ahí; no se abre otra
fresco(); const w1 = ventana(); Q.respuesta = { ventana: w1 }; Q.bloqueada = true;
await vm.imprimir(tarjeta(5)); await esperar();
out.delToque = [Q.abiertas, w1.html.length, /Limonada/.test(w1.html[0] || '') && /Agua/.test(w1.html[0] || '') && !/Casado/.test(w1.html[0] || ''), w1.closed, Q.docs.length, marcados(5), Q.toasts];
// (2) sin ventana del toque y el navegador bloquea la nueva: aviso en rojo; solo queda marcado lo que salió por la impresora directa
fresco(); Q.respuesta = false; Q.bloqueada = true;
await vm.imprimir(tarjeta(5)); await esperar();
out.bloqueada = [Q.abiertas, Q.docs.length, marcados(5), Q.toasts];
// (3) solo platos del navegador y la ventana bloqueada: nada queda marcado
fresco(); Q.respuesta = false; Q.bloqueada = true;
await vm.imprimir(tarjeta(6)); await esperar();
out.nada = [marcados(6), Q.toasts.map(x => x[1])];
// (4) todo salió por la impresora directa: la ventana del toque sobra y se cierra
fresco(); const w4 = ventana(); Q.respuesta = { ventana: w4 };
await vm.imprimir(tarjeta(7)); await esperar();
out.sobra = [w4.closed, Q.abiertas, Q.docs.length, marcados(7)];
// (5) el usuario cerró la ventana del toque: se abre otra como siempre
fresco(); const w5 = ventana(); w5.closed = true; Q.respuesta = { ventana: w5 };
await vm.imprimir(tarjeta(6)); await esperar();
out.cerrada = [Q.abiertas, w5.html.length, marcados(6)];
// (6) los platos de fuera de la copia van a la ventana del toque; solo ellos se imprimen y se marcan aquí
fresco(); const w6 = ventana(), t6 = tarjeta(5); Q.respuesta = { resto: t6.lineas.filter(l => l.detalle === 'Limonada'), ventana: w6 };
await vm.imprimir(t6); await esperar();
out.resto = [Q.abiertas, w6.html.length, /Limonada/.test(w6.html[0] || '') && !/Agua/.test(w6.html[0] || ''), Q.docs.length, marcados(5)];
// (7) prueba:estacion3 W4 (c), baja: la impresora «Cocina» imprime el Casado y solo el Agua (sin impresora de comanda) iba a la ventana, que
// el navegador bloqueó: el aviso nombra el Agua, no «Cocina»
fresco(); Q.respuesta = false; Q.bloqueada = true;
await vm.imprimir(tarjeta(8)); await esperar();
out.soloSinImpresora = [Q.docs.length, marcados(8), Q.toasts];
out.textos = typeof K.textoVentanaBloqueada === 'function' ? [K.textoVentanaBloqueada(['Bar']), K.textoVentanaBloqueada(['Bar', 'Cocina', 'Bar']), K.textoVentanaBloqueada(['Bar', 'Cocina', 'Postres'])] : 'no existe';
out.textosPlatos = typeof K.textoVentanaBloqueada === 'function' ? [K.textoVentanaBloqueada([], ['Agua']), K.textoVentanaBloqueada([], ['Agua', 'Té frío', 'Agua']), K.textoVentanaBloqueada(['Bar'], ['Agua']),
  K.textoVentanaBloqueada(['Bar', 'Postres'], ['Agua', 'Té frío'])] : 'no existe';
console.log(JSON.stringify(out));
process.exit(0);
"""
    falsos = {"api.js": API_429, "app.js": FALSO_APP_COCINA, "pages/pos/_datos.js": FALSO_DATOS_COCINA, "pages/pos/_agente.js": AGENTE_429,
              "pages/pos/_agente_real.js": _js("pages/pos/_agente.js"), "pages/pos/_estacion.js": FALSO_ESTACION_COCINA}
    r = _node(tmp_path, guion, archivos=("pages/pos/cocina.js",), falsos=falsos)
    fin = ": el navegador no abrió la ventana de impresión (revise si bloquea las ventanas emergentes de esta página). Toque «Imprimir» otra vez cuando lo haya revisado."
    assert r["delToque"] == [0, 1, True, False, 1, [["Casado", True], ["Limonada", True], ["Agua", True]], []], r
    # prueba:estacion3 (baja): el Agua no tiene impresora de comanda (en la hoja sale como «Cocina»): el aviso la nombra a ella, no a «Cocina»,
    # que es la impresora que sí imprimió el Casado
    assert r["bloqueada"] == [1, 1, [["Casado", True], ["Limonada", False], ["Agua", False]], [["No se imprimieron la comanda de «Bar» ni el plato «Agua»" + fin, "err"]]], r
    assert r["soloSinImpresora"] == [1, [["Casado", True], ["Agua", False]], [["El plato «Agua» no se imprimió" + fin, "err"]]], r
    assert r["nada"] == [[["Limonada", False], ["Agua", False]], ["err"]], r
    assert r["sobra"] == [True, 0, 1, [["Casado", True]]], r
    assert r["cerrada"] == [1, 0, [["Limonada", True], ["Agua", True]]], r
    assert r["resto"] == [0, 1, True, 0, [["Casado", False], ["Limonada", True], ["Agua", False]]], r
    assert r["textos"] == ["La comanda de «Bar» no se imprimió" + fin, "Las comandas de «Bar» y «Cocina» no se imprimieron" + fin,
                           "Las comandas de «Bar», «Cocina» y «Postres» no se imprimieron" + fin], r
    assert r["textosPlatos"] == ["El plato «Agua» no se imprimió" + fin, "Los platos «Agua» y «Té frío» no se imprimieron" + fin,
                                 "No se imprimieron la comanda de «Bar» ni el plato «Agua»" + fin,
                                 "No se imprimieron las comandas de «Bar» y «Postres» ni los platos «Agua» y «Té frío»" + fin], r


def test_aviso_al_cobrar_un_pedido_para_mas_tarde(tmp_path):
    """prueba:estacion2 (baja, D-19): al cobrar un pedido para más tarde el aviso dice cuándo saldrá sola la comanda (45 minutos antes de
    la hora de entrega, con la regla del servidor) y no «si en un minuto no ha salido»."""
    from app import comandas
    casos = [("2026-11-12T18:00:00-06:00", "20:00"), ("2026-11-12T23:30:00-06:00", "01:00"), ("2026-11-12T18:00:00-06:00", "18:20"),
             ("2026-11-12T18:00:00-06:00", "17:30"), ("2026-11-12T18:00:00-06:00", ""), ("2026-11-12T18:00:00-06:00", "25:00")]
    r = _node(tmp_path, BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
const hhmm = ms => { const d = new Date(ms - 6 * 3600000); return String(d.getUTCHours()).padStart(2, '0') + ':' + String(d.getUTCMinutes()).padStart(2, '0'); };
const ahora = Date.now();
copia(1, { creado: iso(ahora), listo_desde: iso(ahora) });
out.hora = hhmm(ahora + 2 * 3600000);
limpiar(); out.masTarde = [E.avisarSiPendiente(cuentaDe(1, { hora_entrega: out.hora })), Q.toasts];
limpiar(); out.yaEsHora = [E.avisarSiPendiente(cuentaDe(1, { hora_entrega: hhmm(ahora + 30 * 60000) })), Q.toasts.map(x => x[0].includes('si en un minuto no ha salido'))];
limpiar(); out.sinHora = [E.avisarSiPendiente(cuentaDe(1)), Q.toasts.map(x => x[0].includes('si en un minuto no ha salido'))];
out.puras = typeof E.salidaProgramada === 'function' ? CASOS.map(([c, h]) => E.salidaProgramada(c, h)) : 'no existe';
console.log(JSON.stringify(out));
process.exit(0);
""".replace("CASOS", json.dumps(casos)), archivos=ARCHIVOS, falsos=_falsos())
    assert r["masTarde"] == [True, [["El pedido #41 es para las " + r["hora"] + ": su comanda saldrá sola en la computadora de la caja o de la cocina 45 minutos antes de esa hora.", "info"]]], r
    assert r["yaEsHora"] == [True, [True]] and r["sinHora"] == [True, [True]], r      # a menos de 45 minutos de la hora, o sin hora: el aviso de siempre
    from datetime import datetime
    esperado = [int(datetime.fromisoformat(comandas.listo_desde(c, h)).timestamp() * 1000) if h in ("20:00", "01:00", "18:20", "17:30") else None for c, h in casos]
    assert r["puras"] == esperado, (r["puras"], esperado)                           # la misma regla que el servidor (comandas.listo_desde)


def test_marcas_por_empresa_y_la_que_falla_no_tapa_a_las_demas(tmp_path):
    """revisa:431-corr (bajas, _estacion.js): las marcas «impresa» que no llegaron y los platos impresos aquí llevan la empresa (una pestaña
    que cambia de empresa no manda la marca con la sesión de otra ni da por impresos sus platos); lo que la pestaña recuerda por número de
    pedido se olvida al cambiar de empresa. Una marca que falla siempre queda para la próxima pasada y las demás siguen."""
    r = _node(tmp_path, BASE + TARJETAS + """
const api0 = Q.api;
Q.api = async (u, o) => {
  if (u.startsWith('/api/pos/comanda/impresa')) {
    const b = o.body;
    if (Q.siempre500 === b.pedido_id) { Q.llamadas.push('POST ' + u + ' 500 ' + b.pedido_id); throw Object.assign(new Error('Error del servidor'), { status: 500 }); }
    if (Q.caido) { Q.llamadas.push('POST ' + u + ' caido ' + b.pedido_id); throw Object.assign(new Error('Bad Gateway'), { status: 502 }); }
  }
  return api0(u, o);
};
const marcasA = () => Q.llamadas.filter(x => x.startsWith('POST /api/pos/comanda/impresa'));
// empresa 7: imprime el pedido 1 y la marca no llega
reset(); copia(1); Q.espera = [cuentaDe(1)]; Q.caido = true;
out.e7 = [await E.revisarEstacion('caja'), Q.impresos.length, E._marcasPendientes().length];
// la pestaña cambia a la empresa 8 (otro servidor de datos), que tiene su propio pedido 1 con la comanda pendiente
Q.sesion.empresa_id = 8; S.copias = {}; S.filas = {}; copia(1); Q.espera = [cuentaDe(1)]; Q.caido = false; limpiar();
out.e8 = [await E.revisarEstacion('caja'), Q.impresos, marcasA().map(x => JSON.parse(x.slice(x.indexOf('{'))).lineas), E._marcasPendientes().length, S.filas['1|0'].estado];
// de vuelta en la empresa 7: su marca llega
Q.sesion.empresa_id = 7; limpiar();
await E.revisarEstacion('caja'); out.vuelta7 = [marcasA().length, E._marcasPendientes().length];
// una marca que falla siempre (500) no tapa a las que vienen detrás
reset(); copia(2); copia(3); Q.espera = [cuentaDe(2), cuentaDe(3)]; Q.caido = true;
out.dos = [await E.revisarEstacion('caja'), Q.impresos.length, E._marcasPendientes().map(c => c.pedido_id)];
Q.caido = false; Q.siempre500 = 2; limpiar();
await E.revisarEstacion('caja');
out.siguen = [marcasA(), E._marcasPendientes().map(c => c.pedido_id), S.filas['3|0'].estado, Q.impresos.length];
// sin conexión se para en la primera (las demás tampoco llegarían) y la que falló pasa al final de la cola
reset(); copia(4); copia(5); Q.espera = [cuentaDe(4), cuentaDe(5)]; Q.siempre500 = null; Q.caido = true;
await E.revisarEstacion('caja'); Q.caido = false; Q.sinRed = 'impresa'; limpiar();
await E.revisarEstacion('caja');
out.sinRed = [Q.llamadas.filter(x => x.includes('/impresa')).length, E._marcasPendientes().map(c => c.pedido_id)];
Q.sinRed = null; Q.api = api0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["e7"] == ["lista", 1, 1], r
    # en la empresa 8: la marca de la 7 no se manda, su pedido 1 no se da por impreso (ni por «ya resuelto» ni en espera): sale una vez
    assert r["e8"] == ["lista", [["Cocina", "Casado"]], [[0]], 1, "impresa"], r
    assert r["vuelta7"] == [1, 0], r
    assert r["dos"] == ["lista", 2, [2, 3]], r
    s = r["siguen"]                                                                 # la del pedido 2 falla (500), la del 3 llega igual
    assert len(s[0]) == 2 and s[0][0] == "POST /api/pos/comanda/impresa 500 2" and s[0][1].startswith('POST /api/pos/comanda/impresa {"pedido_id":3,'), r
    assert s[1:] == [[2], "impresa", 0], r
    assert r["sinRed"] == [1, [5, 4]], r


def test_cambio_de_empresa_mientras_la_estacion_imprime(tmp_path):
    """prueba:estacion3 (media, M2 y M2b): la pestaña cambia de empresa con el selector mientras la estación (o «Imprimir» de Cocina) imprime.
    La pasada recuerda la empresa con la que empezó: ninguna petición sale con la sesión de la otra empresa, la pasada se detiene sin reclamar
    ni imprimir nada más, la marca de lo que ya salió queda en la cola con su empresa y llega cuando la pestaña vuelve a ella. Antes la marca
    y el resto de la pasada se mandaban con la otra empresa: la comanda en curso salía dos veces y otro pedido con el mismo número quedaba
    «impresa» sin salir. Cada empresa tiene su propio servidor de mentira; la sesión de cada petición es la del momento en que sale."""
    r = _node(tmp_path, BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {}, IMPS0 = Q.imps;
const SE = { 7: { copias: {}, filas: {} }, 8: { copias: {}, filas: {} } };
const en = e => { S.copias = SE[e].copias; S.filas = SE[e].filas; };
const api0 = Q.api;
Q.porEmpresa = []; Q.malaCabecera = [];
Q.api = async (u, o) => {
  const e = Q.sesion.empresa_id, b = o && o.body;                    /* la sesión con la que sale la petición */
  Q.porEmpresa.push(e + ' ' + u.split('?')[0].split('/').pop() + (b && b.pedido_id ? ' #' + b.pedido_id + ' ' + JSON.stringify(b.lineas) : ''));
  if (String((o && o.headers && o.headers['X-Empresa']) || '') !== String(e)) Q.malaCabecera.push(e + ' ' + u);
  if (Q.retener && u.startsWith(Q.retener.ruta)) { const x = Q.retener; Q.retener = null; await x.p; }
  en(e); return api0(u, o);
};
const espera = async c => { for (let i = 0; i < 500 && !c(); i++) await new Promise(r => setTimeout(r, 1)); };
const cambiar = e => { Q.sesion.empresa_id = e; en(e); Q.espera = Object.values(SE[e].copias).map(c => cuentaDe(c.pedido_id)); };
const filas = e => Object.entries(SE[e].filas).map(([k, f]) => k + ':' + f.estado).sort();
const nuevo = () => { E._reiniciar(); SE[7] = { copias: {}, filas: {} }; SE[8] = { copias: {}, filas: {} }; S.t = Date.now(); };
let liberar;
// (M2) Cocina y Bar por red; las dos empresas tienen su pedido 1 pagado (mismo número, mismos ids de impresora, platos distintos)
nuevo(); Q.imps = [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'red', direccion: '192.168.1.60' }, { id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'red', direccion: '192.168.1.61' }];
en(7); copia(1);
en(8); copia(1, { lineas: [{ pos: 0, producto_id: 1, detalle: 'Casado E8', cantidad: 1, nota: '' }, { pos: 1, producto_id: 2, detalle: 'Refresco E8', cantidad: 1, nota: '' }] });
cambiar(7); limpiar(); Q.porEmpresa = [];
Q.lento = new Promise(x => { liberar = x; });
const p1 = E.revisarEstacion('caja');
await espera(() => Q.fetchs.includes('9800/imprimir'));                 /* la Cocina del pedido 1 de la empresa 7 se está imprimiendo */
cambiar(8); liberar(); Q.lento = null;                                    /* el selector de arriba: la empresa 8, sin recargar */
out.durante = [await p1, Q.impresos.slice(), Q.porEmpresa.filter(x => x.startsWith('8 ')), Q.toasts.slice(), E._marcasPendientes().map(m => [m.pedido_id, m.lineas]), [...E.IMPRESAS_AQUI], filas(8), filas(7)];
// en la empresa 8: su pedido 1 sale una vez, con sus platos; la marca de la 7 sigue en la cola
limpiar(); Q.porEmpresa = [];
out.e8 = [await E.revisarEstacion('caja'), Q.impresos.slice(), Q.porEmpresa.every(x => x.startsWith('8 ')), filas(8), E._marcasPendientes().map(m => m.pedido_id), Q.toasts.map(x => x[0])];
// de vuelta en la 7: llega su marca, la Cocina no sale otra vez y el Bar (que la pasada no llegó a tocar) sale una vez
cambiar(7); limpiar(); Q.porEmpresa = [];
out.vuelta7 = [await E.revisarEstacion('caja'), Q.impresos.slice(), Q.porEmpresa.every(x => x.startsWith('7 ')), Q.porEmpresa.filter(x => x.includes('impresa')), filas(7), E._marcasPendientes().length];
// (M2b con «Imprimir» de Cocina) la tarjeta de la empresa 7 se imprime y la pestaña cambia a la 8 en medio: ni la marca de Cocina ni la del servidor
nuevo(); en(7); copia(2); en(8); copia(2); cambiar(7); limpiar(); Q.porEmpresa = [];
const marcas = [], cu = cuentaDe(2), t = { cuenta: cu, impresa: false, lineas: cu.lineas.filter(l => l.pos === 0).map(l => ({ ...l, imp: Q.imps[0] })) };
Q.lento = new Promise(x => { liberar = x; });
const p2 = E.imprimirCocinaEnLinea(t, async ls => { marcas.push(ls.map(l => l.detalle)); });
await espera(() => Q.fetchs.includes('9800/imprimir'));
cambiar(8); liberar(); Q.lento = null;
out.cocina = [await p2, marcas, Q.impresos.slice(), Q.porEmpresa.filter(x => x.startsWith('8 ')), Q.toasts.slice(), E._marcasPendientes().map(m => [m.pedido_id, m.lineas]), filas(8)];
cambiar(7); limpiar(); Q.porEmpresa = [];
await E.revisarEstacion('caja');
out.cocinaVuelta = [Q.porEmpresa.filter(x => x.includes('impresa')), Q.impresos.slice(), filas(7)];
// las marcas que se reintentan: la pestaña cambia de empresa mientras sale la primera; la segunda no sale con la otra empresa
nuevo(); Q.imps = IMPS0; en(7); copia(3); copia(4); en(8); copia(3); copia(4); cambiar(7); limpiar(); Q.sinRed = 'impresa';
await E.revisarEstacion('caja'); Q.sinRed = null;
out.cola = [Q.impresos.length, E._marcasPendientes().map(m => m.pedido_id)];
limpiar(); Q.porEmpresa = [];
Q.retener = { ruta: '/api/pos/comanda/impresa', p: new Promise(x => { liberar = x; }) };
const p3 = E.revisarEstacion('caja');
await espera(() => Q.porEmpresa.length > 0);
cambiar(8); liberar();
out.reintento = [await p3, Q.porEmpresa.slice(), E._marcasPendientes().map(m => m.pedido_id), filas(8)];
cambiar(7); limpiar(); Q.porEmpresa = [];
await E.revisarEstacion('caja');
out.reintentoVuelta = [Q.porEmpresa.filter(x => x.includes('impresa')), E._marcasPendientes().length, Q.impresos.length];
out.malaCabecera = Q.malaCabecera;
Q.api = api0; Q.imps = IMPS0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    d = r["durante"]
    assert d[0] == "otra_empresa" and d[1] == [["Cocina", "Casado"]], r                   # el Bar de la empresa 7 no se imprimió con la sesión de la 8
    assert d[2] == [] and d[3] == [], r                                                    # ni una petición con la empresa 8; ningún aviso de la 7 en la 8
    assert d[4] == [[1, [0]]] and d[5] == ["7|1|0"] and d[6] == [] and d[7] == ["1|0:reclamada"], r   # la marca espera con su empresa
    assert r["e8"] == ["lista", [["Cocina", "Casado E8"], ["Bar", "Refresco E8"]], True, ["1|0:impresa", "1|1:impresa"], [1],
                       ["Comanda del pedido #41 impresa en «Cocina».", "Comanda del pedido #41 impresa en «Bar»."]], r
    v = r["vuelta7"]
    assert v[0] == "lista" and v[1] == [["Bar", "Refresco"]] and v[2] is True, r          # la Cocina no sale dos veces
    assert v[3] == ["7 impresa #1 [0]", "7 impresa #1 [1]"] and v[4] == ["1|0:impresa", "1|1:impresa"] and v[5] == 0, r
    c = r["cocina"]
    assert c[0] is True and c[1] == [] and c[2] == [["Cocina", "Casado"]] and c[3] == [] and c[4] == [] and c[5] == [[2, [0]]] and c[6] == [], r
    assert r["cocinaVuelta"] == [["7 impresa #2 [0]", "7 impresa #2 [1]"], [["Bar", "Refresco"]], ["2|0:impresa", "2|1:impresa"]], r
    assert r["cola"] == [2, [3, 4]], r
    assert r["reintento"] == ["otra_empresa", ["7 impresa #3 [0]"], [4], []], r            # la segunda marca no salió con la empresa 8
    assert r["reintentoVuelta"] == [["7 impresa #4 [0]"], 0, 0], r
    assert r["malaCabecera"] == [], r                                                     # cada petición lleva la empresa de su sesión


def test_la_estacion_reintenta_la_marca_hasta_que_llega_y_no_reimprime(tmp_path):
    r = _node(tmp_path, BASE + TARJETAS + """
const api0 = Q.api, ahora0 = Date.now;
Q.api = async (u, o) => { if (Q.caido && u.startsWith('/api/pos/comanda/impresa')) { Q.llamadas.push('POST ' + u + ' caido'); throw Object.assign(new Error('Bad Gateway'), { status: 502 }); } return api0(u, o); };
reset(); copia(1); Q.espera = [cuentaDe(1)]; Q.caido = true;
out.p1 = [await E.revisarEstacion('caja'), Q.impresos.length, E._marcasPendientes().length];
// 11 minutos después (el reclamo del servidor ya venció y la espera local también) y el servidor sigue caído: no se reclama ni se imprime otra vez
Date.now = () => ahora0() + 11 * 60000; S.t += 61000; Q.llamadas = [];
out.p2 = [await E.revisarEstacion('caja'), Q.impresos.length, reclamos().length, E._marcasPendientes().length];
// el servidor vuelve: la marca llega
Q.caido = false; Q.llamadas = [];
out.p3 = [await E.revisarEstacion('caja'), Q.impresos.length, E._marcasPendientes().length, S.filas['1|0'].estado];
// con la estación apagada, lo impreso a mano también se reintenta
Date.now = ahora0; reset(); copia(2); Q.caido = true;
await E.imprimirPedidoCocina(2, { preguntar: () => true }); const pend = E._marcasPendientes().length;
E.encenderEstacion(false); Q.caido = false; limpiar();
out.apagada = [pend, await E.revisarEstacion('cocina'), E._marcasPendientes().length, S.filas['2|0'].estado, S.filas['2|1'].estado];
E.encenderEstacion(true); Q.api = api0;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["p1"] == ["lista", 1, 1], r                                                        # un 502 también se reintenta
    assert r["p2"][1:] == [1, 0, 1], r                                                           # nunca otra vez el mismo plato
    assert r["p3"] == ["sin_directos", 1, 0, "impresa"], r
    assert r["apagada"] == [2, "apagada", 0, "impresa", "impresa"], r


def test_avisos_lista_y_datos_frescos(tmp_path):
    r = _node(tmp_path, BASE + TARJETAS + """
const A = await import('./js/pages/pos/_agente.js');
// (baja, D-12) solo impresoras «del navegador» en la empresa y el programa 4.31 de esta computadora la tiene por USB (primero: sin nada en memoria)
const NAV = () => [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'navegador' }, { id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'navegador' }];
reset(); copia(8); Q.espera = [cuentaDe(8)]; Q.imps = NAV();
Q.estadoExtra = { equipo: 1 }; Q.equipo9800 = { propias: [], ajustes: { 10: { conexion: 'usb', direccion: 'EPSON' } }, tiquetes: '', etiquetas: '' };
out.d12sin = [await E.revisarEstacion('caja'), Q.fetchs.slice()];                             /* la pestaña no ha hablado con el agente: ni una petición */
await A.agenteEstado(true, { soloAgente: true }); limpiar(); Q.imps = NAV();                  /* ya habló con él (por ejemplo, al imprimir un tiquete) */
out.d12con = [await E.revisarEstacion('caja'), Q.impresos];
Q.estadoExtra = {}; Q.equipo9800 = null; await A.agenteEstado(true, { soloAgente: true }); await A.cargarEquipo(true, { soloAgente: true });
// (baja) el aviso al cobrar es informativo y no sale si nada va a una impresora de comanda
reset(); copia(1); const av = [];
Q.imps = []; av.push(E.avisarSiPendiente(cuentaDe(1))); Q.imps = IMPS0;
Q.cfg = { terminales: [{ ...CFG0.terminales[0], imprimir_comanda: false }, CFG0.terminales[1]] }; av.push(E.avisarSiPendiente(cuentaDe(1))); Q.cfg = CFG0;
Q.sesion.tipo = 'comercio'; av.push(E.avisarSiPendiente(cuentaDe(1)));
Q.cfg = { terminales: [{ ...CFG0.terminales[0], modo: 'restaurante' }, CFG0.terminales[1]] }; av.push(E.avisarSiPendiente(cuentaDe(1))); Q.cfg = CFG0; Q.sesion.tipo = 'restaurante';
av.push(E.avisarSiPendiente(cuentaDe(1)));
out.avisos = [av, Q.toasts.map(x => x[1])];
// (baja) la banda: un pedido para más tarde no entra antes de su hora aunque ya se cobró; una copia sin platos para impresoras de comanda tampoco
const datos = { impresoras: Q.imps, categorias: Q.cats, extras: {}, productos: Q.store.productos, cfg: Q.cfg };
out.lista = E.listaCocina([vista(copia(20, { cuenta_viva: false, hora_entrega: '19:00', listo_desde: iso(S.t + 3600000) })), vista(copia(21, { cuenta_viva: false })),
  vista(copia(22, { cuenta_viva: false, lineas: [{ pos: 0, producto_id: 3, detalle: 'Agua', cantidad: 1, nota: '' }] }))], iso(S.t), Q.cfg, null, datos).map(x => x.pedido_id);
// (baja) antes de decidir «sin comanda» se traen las impresoras y las cajas: la configuración vieja de la pantalla no cierra la copia
reset(); copia(3); Q.espera = [cuentaDe(3)]; Q.cfg = { terminales: [{ ...CFG0.terminales[0], imprimir_comanda: false }, CFG0.terminales[1]] };
Q.refrescos = []; Q.refrescar = async (claves, ctrl) => { Q.refrescos.push([claves, !!(ctrl && ctrl.sinCorte)]); Q.cfg = CFG0; return claves; };
out.fresca = [await E.revisarEstacion('caja'), Q.refrescos, Q.impresos, S.copias[3].estado];
reset(); copia(4); Q.espera = [cuentaDe(4)]; Q.cfg = { terminales: [{ ...CFG0.terminales[0], imprimir_comanda: false }, CFG0.terminales[1]] }; Q.refrescar = async () => false;
out.sinRefresco = [await E.revisarEstacion('caja'), posts('/impresa').length, S.copias[4].estado];
reset(); copia(5); Q.espera = [cuentaDe(5)]; Q.cfg = { terminales: [{ ...CFG0.terminales[0], imprimir_comanda: false }, CFG0.terminales[1]] }; Q.refrescar = async () => [];
out.deVerdad = [await E.revisarEstacion('caja'), posts('/impresa'), S.copias[5].estado];
reset(); copia(9); Q.espera = [cuentaDe(9)]; Q.refrescar = async () => false;               /* imprime, pero la marca no lleva «sin comanda» sin datos frescos */
out.marcaSinFresca = [await E.revisarEstacion('caja'), Q.impresos, posts('/impresa')];
Q.refrescar = undefined;
// (baja) un negocio que no es restaurante: solo las cajas en modo restaurante imprimen comandas solas
reset(); copia(6); Q.espera = [cuentaDe(6)]; Q.sesion.tipo = 'comercio';
out.tienda = [await E.revisarEstacion('caja'), Q.impresos.length, S.copias[6].estado];
reset(); copia(7); Q.espera = [cuentaDe(7)]; Q.sesion.tipo = 'comercio'; Q.cfg = { terminales: [{ ...CFG0.terminales[0], modo: 'restaurante' }, CFG0.terminales[1]] };
out.tiendaConRestaurante = [await E.revisarEstacion('caja'), Q.impresos];
Q.sesion.tipo = 'restaurante';
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["avisos"] == [[False, False, False, True, True], ["info", "info"]], r
    assert r["lista"] == [21], r
    assert r["fresca"][0] == "lista" and r["fresca"][1] == [[["pos_config", "pos_impresoras", "categorias", "items_extra"], True]], r
    assert r["fresca"][2] == [["Cocina", "Casado"]] and r["fresca"][3] == "pendiente", r
    assert r["sinRefresco"] == ["sin_directos", 0, "pendiente"], r                                # sin datos frescos no se decide «sin comanda»
    assert r["deVerdad"] == ["sin_directos", [[[], [0, 1, 2]]], "sin_comanda"], r                 # con datos frescos que lo confirman, sí
    assert r["marcaSinFresca"] == ["lista", [["Cocina", "Casado"]], [[[0], []]]], r
    assert r["tienda"] == ["sin_directos", 0, "sin_comanda"], r
    assert r["tiendaConRestaurante"] == ["lista", [["Cocina", "Casado"]]], r
    assert r["d12sin"] == ["sin_directos", []], r
    assert r["d12con"] == ["lista", [["Cocina", "Casado"]]], r


# ================================================================================================================ D-12: el 9800 del programa 4.31
def test_cargar_equipo_lee_el_9800_solo_con_equipo(tmp_path):
    r = _node(tmp_path, BASE + """
const A = await import('./js/pages/pos/_agente.js');
const COC = { id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'navegador' };
const out = {};
limpiar(); const a = await A.cargarEquipo(true, { cedula: '3101123456', soloAgente: true }); out.sin = [a.datos, Q.fetchs, A.impresoraAqui(COC).conexion];
Q.estadoExtra = { equipo: 1 }; Q.equipo9800 = { propias: [], ajustes: { 10: { conexion: 'usb', direccion: 'EPSON TM-T20' } }, tiquetes: '', etiquetas: '' };
limpiar(); const b = await A.cargarEquipo(true, { cedula: '3101123456', soloAgente: true }); out.con = [!!b.datos, Q.fetchs, A.impresoraAqui(COC).conexion, A.impresoraAqui(COC).direccion, Q.llamadas];
Q.equipo9800 = null; limpiar(); const c = await A.cargarEquipo(true, { soloAgente: true }); out.noEsta = [c.datos, Q.fetchs];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_agente.js",), falsos=_falsos())
    assert r["sin"] == [None, ["9800/estado"], "navegador"], r                      # programa anterior o agente suelto: como en la configuración
    assert r["con"] == [True, ["9800/estado", "9800/equipo?cedula=3101123456"], "usb", "EPSON TM-T20", []], r
    assert r["noEsta"] == [None, ["9800/estado", "9800/equipo?cedula=3101123456"]], r   # la cédula se recuerda


# ================================================================================================================ Pedidos al aceptar
FALSO_AGENTE_PED = """
export { docComanda, textoNumeroComanda, avisoImpresion } from './_agente_real.js';
export const porAgente = imp => imp.conexion === 'usb' || imp.conexion === 'red', cargarEquipo = async () => {}, impresoraAqui = x => x;
export const imprimirAgente = async (imp, doc) => { if (globalThis.Q.rotas.includes(imp.nombre)) throw new Error('El agente de impresión no responde en esta computadora'); globalThis.Q.impresos.push([imp.nombre, ...doc.bloques.filter(b => b.t === 'item').map(b => b.x)]); };
export const agenteEstado = async (f, o) => { globalThis.Q.estadoPedido = o || null; return { ok: !!globalThis.Q.agente }; };
"""
FALSOS_PED = {
    "avisos.js": "export const avisosActivos = () => false, activarAvisos = async () => true, desactivarAvisos = () => {};\n",
    "fis/sesion.js": "export const sesion = globalThis.Q.sesionFis;\n",
    "fis/ui.js": "export const dinero = v => String(v), fechaCorta = v => String(v), formaPago = () => 'Paga al recibir', puedeEstadoCuenta = () => false, urlEstadoCuenta = () => '';\n",
    "api.js": FALSO_API + "export const hoy = () => '2026-11-12', sumarDias = d => d, abrirArchivo = async () => {};\n",
    "pages/pos/_agente.js": FALSO_AGENTE_PED,
}


def _pedidos_js():
    t = _js("fis/pages/pedidos.js")
    t = t.replace("from '/js/api.js'", "from '../../api.js'").replace("from '/js/avisos.js'", "from '../../avisos.js'").replace("import('/js/pages/pos/_comandas.js')", "import('../../pages/pos/_comandas.js')")
    assert "'/js/" not in t
    return t


def test_pedidos_acepta_reclama_e_imprime_de_la_copia(tmp_path):
    falsos = dict(FALSOS_PED)
    falsos["fis/pages/pedidos.js"] = _pedidos_js()
    falsos["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    r = _node(tmp_path, BASE + """
Q.sesionFis = { menu: true, negocio: { terminal_id: 1 }, empresaInfo: {}, fisica: true, tieneModulo: () => false, sucursalActual: null, nombreUsuario: 'Ana QA' };
Q.imps = [{ id: 10, nombre: 'Cocina', uso: 'comanda', conexion: 'red' }, { id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'navegador' }];
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) { Q.llamadas.push('PUT ' + url + ' ' + JSON.stringify(opt.body)); return { id: Q.pid, estado: 'en_preparacion', cuenta_espera_id: 100 + Q.pid }; }
  if (url === '/api/registros/pos_config') { if (Q.colgar) return new Promise(() => {}); return { datos: Q.cfg }; }
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
const P = (await import('./js/fis/pages/pedidos.js')).default;
const montar = () => { const vm = Object.assign({ params: { query: {} } }, P.data.call({ params: { query: {} } })); for (const [k, f] of Object.entries(P.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(P.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const out = {};
const caso = async (pid, prep, tras) => { S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.rotas = []; Q.agente = true; Q.ventanas = 0; copia(pid, { origen: 'aceptar' }); if (prep) prep();
  const vm = montar(); await vm.cargarImpresion(); if (tras) tras(); const p = { id: pid, estado: 'nuevo' }; const t0 = Date.now(); const ok = await vm.aceptar(p);
  return { ok, ms: Date.now() - t0, toasts: Q.toasts, impresos: Q.impresos, ventanas: Q.ventanas, put: Q.llamadas.find(x => x.startsWith('PUT')), posts: Q.llamadas.filter(x => x.startsWith('POST')).map(x => x.split(' ')[1] + ' ' + JSON.stringify(JSON.parse(x.slice(x.indexOf('{'))).lineas)), filas: Object.entries(S.filas).map(([k, f]) => k + ':' + f.estado).sort(), estado: Q.estadoPedido }; };
out.bien = await caso(1);
out.sinAgente = await caso(2, () => { Q.agente = false; });
out.ocupada = await caso(3, () => { S.filas['3|1'] = { estado: 'reclamada', equipo: 'otraPestana01', nombre: 'Caja 1 · Cocina', vence: iso(S.t + 50000), intentos: 0 }; });
out.sinRed = await caso(4, () => { Q.sinRed = 'reclamar'; }); Q.sinRed = null;
out.masTarde = await caso(5, () => { Q.agente = false; Object.assign(S.copias[5], { hora_entrega: '19:00', listo_desde: iso(Date.now() + 3600000) }); });
out.caida = await caso(6, () => { Q.rotas = ['Cocina']; });
out.colgada = await caso(7, null, () => { Q.colgar = true; }); Q.colgar = false;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=falsos)
    b = r["bien"]
    assert b["ok"] is True and '"reclama":true' in b["put"] and '"estado":"confirmado"' in b["put"], r
    assert b["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]] and b["impresos"] == [["Cocina", "Casado"]] and b["ventanas"] == 1, r
    assert b["posts"] == ["/api/pos/comanda/reclamar [1]", "/api/pos/comanda/reclamar [0]", "/api/pos/comanda/impresa [1]", "/api/pos/comanda/impresa [0]"], r
    assert b["filas"] == ["1|0:impresa", "1|1:impresa"] and b["estado"] == {"soloAgente": True}, r
    s = r["sinAgente"]                                                                # el agente no responde: los directos no se reclaman
    assert s["posts"] == ["/api/pos/comanda/reclamar [1]", "/api/pos/comanda/impresa [1]"] and s["impresos"] == [], r
    assert s["toasts"] == [["Pedido aceptado. La comanda no se imprimió en este equipo (este equipo no tiene el programa de escritorio ni el agente de impresión abiertos): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.", "info"]], r
    o = r["ocupada"]
    assert o["toasts"] == [["Pedido aceptado. La comanda la está imprimiendo «Caja 1 · Cocina».", "ok"]] and o["ventanas"] == 1, r
    n = r["sinRed"]                                                                   # sin red para reservar: no imprime nada
    assert n["impresos"] == [] and not any("impresa" in x for x in n["posts"]), r
    assert n["toasts"] == [["Pedido aceptado. La comanda no se imprimió: no hubo conexión con el servidor para reservar la impresión. Imprímala desde Punto de venta › Cocina.", "err"]], r
    assert r["masTarde"]["toasts"] == [["Pedido aceptado para las 19:00. La comanda saldrá sola en la computadora de la caja o de la cocina 45 minutos antes.", "ok"]], r
    c = r["caida"]                                                                    # la impresora de red falla: se suelta y sale sola después
    assert "/api/pos/comanda/soltar [0]" in c["posts"] and c["filas"] == ["6|0:soltada", "6|1:impresa"], r
    assert c["toasts"] == [["Pedido aceptado. La comanda no se imprimió en este equipo (la impresora «Cocina» no respondió: El agente de impresión no responde en esta computadora): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.", "info"]], r
    g = r["colgada"]                                                                  # lecturas colgadas: aviso a los 5 s, siempre
    assert 4800 <= g["ms"] < 8000 and g["impresos"] == [] and g["ok"] is True, r
    assert g["toasts"] == [["Pedido aceptado. La comanda no se imprimió en este equipo (no se pudo leer a tiempo la configuración de impresión): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.", "info"]], r


def test_pedidos_marca_en_segundo_plano_y_error_del_servidor(tmp_path):
    """Correcciones (bajas): la marca de quien aceptó que no llegó se reintenta sola unos 50 s antes de avisar «no la imprima otra vez»;
    un error del servidor al leer la copia no imprime sin reclamar (como la 4.29): aviso informativo «saldrá sola»."""
    falsos = dict(FALSOS_PED)
    falsos["fis/pages/pedidos.js"] = _pedidos_js()
    falsos["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    r = _node(tmp_path, BASE + """
Q.sesionFis = { menu: true, negocio: { terminal_id: 1 }, empresaInfo: {}, fisica: true, tieneModulo: () => false, sucursalActual: null, nombreUsuario: 'Ana QA' };
const st0 = globalThis.setTimeout;
globalThis.setTimeout = (f, ms, ...a) => st0(f, ms === 4000 ? 1 : ms, ...a);     /* los 4 s entre reintentos pasan enseguida */
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) { Q.llamadas.push('PUT ' + url); return { id: Q.pid, estado: 'en_preparacion', cuenta_espera_id: 100 + Q.pid }; }
  if (url === '/api/pos/comanda/impresa' && Q.fallasMarca > 0) { Q.fallasMarca--; throw new Error('Sin conexión con el servidor'); }
  if (url.startsWith('/api/pos/comanda/pendientes') && Q.pendError) throw Object.assign(new Error('Error del servidor'), { status: 500 });
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') { Q.llamadas.push('GET pos_espera'); return { datos: [] }; }
  return api0(url, opt);
};
const P = (await import('./js/fis/pages/pedidos.js')).default;
const montar = () => { const vm = Object.assign({ params: { query: {} } }, P.data.call({ params: { query: {} } })); for (const [k, f] of Object.entries(P.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(P.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const esperar = async c => { for (let i = 0; i < 400 && !c(); i++) await new Promise(r => st0(r, 5)); };
const caso = async (pid, prep) => { S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.agente = true; Q.fallasMarca = 0; Q.pendError = false; copia(pid, { origen: 'aceptar' }); if (prep) prep();
  const vm = montar(); await vm.cargarImpresion(); await vm.aceptar({ id: pid, estado: 'nuevo' }); return { toasts: Q.toasts.slice(), impresos: Q.impresos.slice() }; };
const out = {};
// la marca falla las dos primeras veces: el aviso de siempre (bien) y la marca llega sola, sin aviso de error
out.tarde = await caso(1, () => { Q.fallasMarca = 2; }); await esperar(() => Object.values(S.filas).filter(f => f.estado === 'impresa').length === 2);
out.tarde.despues = [Q.toasts.slice(), Object.entries(S.filas).map(([k, f]) => k + ':' + f.estado).sort()];
// nunca llega: después de los reintentos, entonces sí el aviso
out.nunca = await caso(2, () => { Q.fallasMarca = 999; }); await esperar(() => Q.toasts.length > 1);
out.nunca.despues = Q.toasts.slice();
// error del servidor al leer la copia: no se imprime sin reclamar ni se busca la cuenta vieja; aviso informativo
out.error = await caso(3, () => { Q.pendError = true; }); out.error.llamadas = Q.llamadas.filter(x => x.startsWith('GET pos_espera')).length;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=falsos)
    bien, aviso = ["Pedido aceptado y comanda impresa.", "ok"], "Pedido aceptado y comanda impresa, pero en Punto de venta › Cocina no quedó marcada como impresa: no la imprima otra vez."
    assert r["tarde"]["toasts"] == [bien] and r["tarde"]["impresos"] == [["Cocina", "Casado"]], r
    assert r["tarde"]["despues"] == [[bien], ["1|0:impresa", "1|1:impresa"]], r
    assert r["nunca"]["toasts"] == [bien] and r["nunca"]["despues"] == [bien, [aviso, "err"]], r
    assert r["error"]["toasts"] == [["Pedido aceptado. La comanda no se imprimió en este equipo (no hubo conexión con el servidor para reservar la impresión): saldrá sola en la computadora de la caja o de la cocina. Si en un minuto no ha salido, imprímala desde Punto de venta › Cocina.", "info"]], r
    assert r["error"]["impresos"] == [] and r["error"]["llamadas"] == 1, r      # solo la recarga de la lista (la de siempre), no la cuenta para imprimir


# ================================================================================================================ textos, sintaxis y plantillas
def test_textos_contrato_y_archivos_ajenos():
    est, com, ped, cfg = _js("pages/pos/_estacion.js"), _js("pages/pos/_comandas.js"), _js("fis/pages/pedidos.js"), _js("pages/pos/configuracion.js")
    # _comandas.js sigue sin importar app.js ni _datos.js (Pedidos lo usa fuera del punto de venta) y no tiene importaciones nuevas
    assert re.findall(r"^import .*$", com, re.M) == ["import { toast, fmtCant } from '../../api.js';",
                                                      "import { porAgente, imprimirAgente, docComanda, cargarEquipo, impresoraAqui, textoNumeroComanda, avisoImpresion } from './_agente.js';"]
    # la configuración no depende de la estación para cargar (se importa al usarse)
    assert "import('./_estacion.js')" in cfg and "from './_estacion.js'" not in cfg
    assert "'Esta computadora imprime sola las comandas de los pedidos en línea'" in est and "pie: 'Solo cambia esta computadora; las demás siguen como estén.'" in est
    assert "'Listo: esta computadora imprime sola las comandas de los pedidos en línea.'" in est and "'Listo: esta computadora ya no imprime sola las comandas de los pedidos en línea.'" in est
    assert 'v-if="estComandas"' in cfg and "if (!this.esPrograma && sesion.tieneModulo('pedidos_online')) this.cargarEstacionComandas();" in cfg
    # el contrato para caja.js y cocina.js está escrito arriba de _estacion.js
    for linea in ("guardarResumen(r);", "avisarSiPendiente(idFin);", "avisarSiPendiente(esperaId);", "revisarEstacion('caja');", "revisarEstacion('cocina');", "iniciarEstacion('cocina');", "pararEstacion('caja');"):
        assert linea in est, linea
    assert "'pos:estacion_comandas:' + (sesion.empresa_id || 0)" in est and "ESTACION_EN_PROGRAMA = false" in est
    assert "body: { estado: 'confirmado', reclama: true }" in ped and "import('../../pages/pos/_agente.js')" in ped


def test_sintaxis_finales_de_linea_y_plantillas(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/pos/_estacion.js", "pages/pos/_comandas.js", "pages/pos/_agente.js", "fis/pages/pedidos.js", "pages/pos/configuracion.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
        assert (JS / rel).read_bytes().count(b"\r\n") == 0, rel                    # todos son LF
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    for rel in ("fis/pages/pedidos.js", "pages/pos/configuracion.js"):
        guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const txt = fs.readFileSync(%s, 'utf8'); const m = /template:\\s*`([\\s\\S]*?)`,\\s*\\n};/.exec(txt) || /template:\\s*`([\\s\\S]*?)`/.exec(txt);
const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
console.log(JSON.stringify({ err }));
""" % (json.dumps(vue), json.dumps(str(JS / rel)))
        out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
        assert out.returncode == 0, out.stderr
        assert json.loads(out.stdout) == {"err": []}, rel
    cfg = _js("pages/pos/configuracion.js")
    tarjeta = cfg[cfg.index('<div id="cfg-estacion"'):cfg.index('<div id="cfg-restaurante"')]
    assert re.search(r"@[a-z:.]+=\"[^\"]*\bif\b", tarjeta) is None                       # ningún manejador con «if»
    for nombre in ("estComandas", "cambiarEstacionComandas", "programaAnteriorEstacion"):    # todo lo que usa la tarjeta existe
        assert nombre + ": null" in cfg or nombre + "(" in cfg, nombre
    for rel in tocados:                                                                       # ninguna línea nueva de código cerrada con «//»
        for linea in _js(rel).splitlines():
            if ("4.31" in linea or rel.endswith("_estacion.js")) and not linea.strip().startswith("//"):
                assert "//" not in linea.replace("http://", ""), (rel, linea)
