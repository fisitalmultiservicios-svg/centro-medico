# -*- coding: utf-8 -*-
"""4.23 · Adenda de Gastos (A1 a A4), sobre lo de tests/test_423_gastos.py:
A1 · el asiento de una compra o un gasto de un mes con el periodo contable cerrado no se toca: el reverso (o el ajuste por
     reclasificación) va en el mes en curso, en un asiento automático aj:<origen>;
A2 · cambiar la cuenta contable de un documento de un mes pasado también es una rectificación;
A3 · la factura registrada desde un XML en una empresa sin facturación electrónica (su recibido no se acepta) cuenta por sí misma;
A4 · dos textos del hotel y dos enlaces de los reportes que quedaron con el nombre o la ruta de antes."""
import json
import pathlib
import shutil
import subprocess

import pytest
from sqlmodel import Session

from app import main, recepcion, resumen
from app.db import engine_empresa
from tests.test_375_costeo import _registrar, _xml_proveedor
from tests.test_423_gastos import AHORA, MOTIVO, NODOS, NOVIEMBRE, OCTUBRE, _aceptado, _alta, _auditoria, _compra, _compras, _eid, _node, _octubre, _recibido, _rects
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

JS = pathlib.Path(main.__file__).parent / "static" / "js"


@pytest.fixture(autouse=True)
def _reloj(monkeypatch):
    """«Hoy» es el 10 de noviembre de 2026 (como en test_423_gastos); y el resumen no sale a buscar el tipo de cambio."""
    monkeypatch.setattr(main, "ahora_cr", lambda: AHORA)

    def _sin_red():
        raise RuntimeError("sin red en las pruebas")
    monkeypatch.setattr(main.tipo_cambio, "obtener", _sin_red)


def _js(*partes):
    return (JS / pathlib.Path(*partes)).read_text(encoding="utf-8").replace("\r\n", "\n")


# ------------------------------------------------------------------------------------------------ la sincronización de verdad, en Node
# automaticos.js, parametros.js (periodos y cuentas) y gastos/_registro.js son los de verdad; lo demás son sustitutos mínimos: el
# registro de la pestaña (mock) en memoria, las tres consultas que hace la sincronización y los permisos de la sesión.
API_JS = r"""const copia = v => JSON.parse(JSON.stringify(v));
export const S = { datos: {}, recibidos: [], docs: [], pagos: [], hoy: '2026-11-10', tc: 500, permisos: ['contabilidad', 'gastos'], guardados: 0 };
export async function api(url) { const r = { '/api/comprobantes': S.docs, '/api/recepcion': S.recibidos, '/api/pagos': S.pagos }[url]; if (!r) throw new Error('ruta sin sustituto: ' + url); return copia(r); }
export const mock = {
  get(k, d) { return k in S.datos ? copia(S.datos[k]) : d; },
  async set(k, v) { S.datos[k] = copia(v); S.guardados++; return true; },
  async refrescar() { return []; },
  nextId(lista) { return (lista || []).reduce((m, x) => Math.max(m, +x.id || 0), 0) + 1; },
};
export const monedas = { principal: () => ({ codigo: 'CRC' }), tc: () => S.tc, get: () => ({ tipo_cambio: S.tc }) };
export const fmt = n => (+n || 0).toFixed(2);
export const hoy = () => S.hoy;
"""
SUSTITUTOS = {
    ("app.js",): "import { S } from './api.js';\nexport const sesion = { puede: p => S.permisos.includes(p) };\n",
    ("pages", "contabilidad", "asientos.js"): "import { mock } from '../../api.js';\nexport const asientosMock = () => mock.get('asientos', []);\n",
    ("pages", "contabilidad", "activos.js"): "export const activosMock = () => [], periodosDepreciados = () => 0, cuota = () => 0, baseDepreciable = () => 0, fechaPeriodo = () => '';\n",
    ("pages", "bancos", "cuentas.js"): "export const bancosMock = () => [];\n",
}
DE_VERDAD = (("pages", "contabilidad", "automaticos.js"), ("pages", "contabilidad", "parametros.js"), ("pages", "gastos", "_registro.js"))
# Lo común de los guiones: documentos de prueba y cómo se mira el resultado
COMUN_JS = r"""
import { S, mock } from './js/api.js';
import { sincronizarAutomaticos } from './js/pages/contabilidad/automaticos.js';
const rec = (id, o = {}) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', consecutivo: 'C' + id, emisor_nombre: 'Prov ' + id, fecha_emision: '2026-10-08T10:00:00-06:00', moneda: 'CRC', tipo_cambio: 1,
  total: 1130, impuesto: 130, iva: 130, monto_impuesto_acreditar: 130, respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto', cuenta_contable: null, registrado: true, compra_id: null, ...o });
const com = (id, o = {}) => ({ id, tipo: 'gasto', recepcion_id: null, clave: null, numero: 'FC-' + id, proveedor: 'Manual ' + id, creacion: '2026-10-15', moneda: 'CRC', tipo_cambio: 1, total: 11300, pagado: 0, fec_id: null,
  lineas: [{ cantidad: 1, precio_unitario: 10000, descuento: 0, tarifa: 13 }], ...o });
const periodos = (octubre, noviembre) => { S.datos.periodos_2026 = [{ n: 10, mes: 'Octubre', estado: octubre }, { n: 11, mes: 'Noviembre', estado: noviembre }, { n: 12, mes: 'Diciembre', estado: 'Abierto' }]; };
const rectificacion = x => { S.datos.gastos_rectificaciones = [...(S.datos.gastos_rectificaciones || []), { id: (S.datos.gastos_rectificaciones || []).length + 1, ...x }]; };
const R = id => S.recibidos.find(r => r.id === id);
const asiento = o => { const a = mock.get('asientos', []).filter(x => x.origen === o); if (a.length > 1) throw new Error('repetido: ' + o); return a[0] || null; };
const lineas = o => asiento(o).lineas.map(l => [l.cuenta, l.debito, l.credito]);
const cuadra = o => Math.abs(asiento(o).lineas.reduce((s, l) => s + l.debito - l.credito, 0)) < 0.005;
const origenes = () => mock.get('asientos', []).map(a => a.origen || 'a mano').sort();
const idDe = o => asiento(o).id;
const sinc = async () => { const g = S.guardados, r = await sincronizarAutomaticos(); return { creados: r.creados, actualizados: r.actualizados, eliminados: r.eliminados, bloqueados: r.bloqueados, huerfanos: r.huerfanos, guardo: S.guardados > g }; };
const o = {};
"""


def _sincronizar(carpeta, guion):
    """Corre `guion` en Node contra sincronizarAutomaticos TAL COMO ESTÁ en automaticos.js y devuelve el objeto `o` que el guion llena."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = carpeta / "js"
    for partes in DE_VERDAD:
        (raiz / pathlib.Path(*partes)).parent.mkdir(parents=True, exist_ok=True)
        (raiz / pathlib.Path(*partes)).write_text(_js(*partes), encoding="utf-8")
    for partes, fuente in SUSTITUTOS.items():
        (raiz / pathlib.Path(*partes)).parent.mkdir(parents=True, exist_ok=True)
        (raiz / pathlib.Path(*partes)).write_text(fuente, encoding="utf-8")
    (raiz / "api.js").write_text(API_JS, encoding="utf-8")
    (carpeta / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (carpeta / "prueba.mjs").write_text(COMUN_JS + guion + "\nconsole.log(JSON.stringify(o));\n", encoding="utf-8")
    r = subprocess.run([node, str(carpeta / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(carpeta))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


def _al_reves(lineas):
    return [[c, h, d] for c, d, h in lineas]


# ------------------------------------------------------------------------------------------------ A1 · mes con el periodo contable cerrado
GUION_A1 = r"""
periodos('Abierto', 'Abierto');
S.datos.param_contable = { contabilizar_importados: true };
S.recibidos = [rec(1), rec(2, { clasificacion: 'compra' }), rec(3, { fecha_emision: '2026-11-03T10:00:00-06:00' }), rec(4, { fecha_emision: '2026-11-04T10:00:00-06:00', clasificacion: 'compra' }),
  rec(5, { moneda: 'USD', tipo_cambio: 500, total: 113, impuesto: 13, iva: 13, monto_impuesto_acreditar: 13 }), rec(6, { estado_mensaje: 'importado' }), rec(7), rec(8, { tipo_documento: '03', referencia_clave: rec(1).clave, total: 226, impuesto: 26, iva: 26, monto_impuesto_acreditar: 26 })];
S.datos.compras = [com(1), com(2, { creacion: '2026-11-03' }), com(3)];
S.datos.asientos = [{ id: 1, codigo: 'AC-1', fecha: '2026-10-02', tipo: 'Asiento contable', numeracion: 'AC', observaciones: 'A mano', lineas: [] }];
// todo abierto: cada documento lleva su asiento en su fecha
o.inicial = await sinc(); o.origenes0 = origenes();
o.fechas0 = ['rec:1', 'rec:3', 'cm:1', 'cm:2'].map(x => asiento(x).fecha);
// se cierra octubre: nada cambia (el importado sigue con su regla de siempre: se avisa)
periodos('Cerrado', 'Abierto');
o.alCerrar = await sinc(); o.huerfanoImportado = o.alCerrar.huerfanos.length === 1 && o.alCerrar.huerfanos[0] === idDe('rec:6');
const cerrados = ['rec:1', 'rec:2', 'rec:5', 'rec:7', 'rec:8', 'cm:1', 'cm:3'], foto = () => JSON.stringify(cerrados.map(asiento));
const antes = foto(); o.cerrados = Object.fromEntries(cerrados.map(x => [x, lineas(x)]));
// rectificaciones de octubre (cerrado): el 1 se elimina del registro (y su nota de crédito 8 deja de valer), el 2 pasa de compra a gasto,
// el 5 (en dólares) y el 7 se eliminan, la factura a mano 1 se elimina sin que haya anotación; y de noviembre (abierto): el 3 se
// elimina, el 4 pasa a gasto y la factura a mano 2 se elimina
R(1).registrado = false; rectificacion({ recibido_id: 1, accion: 'eliminado', fecha: '2026-11-05T09:00:00-06:00' });
R(2).clasificacion = 'gasto'; rectificacion({ recibido_id: 2, accion: 'reclasificado', fecha: '2026-11-07T16:30:00-06:00' }); rectificacion({ recibido_id: 2, accion: 'reclasificado', fecha: '2026-11-02T08:00:00-06:00' });
R(5).registrado = false; rectificacion({ recibido_id: 5, accion: 'eliminado', fecha: '2026-11-06T09:00:00-06:00' });
R(7).registrado = false; rectificacion({ recibido_id: 7, accion: 'eliminado', fecha: '2026-10-30T09:00:00-06:00' });
rectificacion({ compra_id: 7, accion: 'eliminado', fecha: '2026-11-09T09:00:00-06:00' });
R(3).registrado = false; R(4).clasificacion = 'gasto';
S.datos.compras = [com(3)];
o.rectificado = await sinc(); o.origenes1 = origenes();
o.intactos = foto() === antes;
o.aj = Object.fromEntries(['aj:rec:1', 'aj:rec:2', 'aj:rec:5', 'aj:rec:7', 'aj:rec:8', 'aj:cm:1'].map(x => { const a = asiento(x); return [x, { fecha: a.fecha, tipo: a.tipo, numeracion: a.numeracion, codigo: a.codigo, obs: a.observaciones,
  automatico: a.automatico, ajustado: a.ajustado, lineas: lineas(x), cuadra: cuadra(x), moneda_doc: a.moneda_doc || null, doc: a.lineas.map(l => [l.debito_doc, l.credito_doc]), textos: a.lineas.map(l => l.descripcion), contacto: a.lineas[0].contacto, documento: a.lineas[0].documento }]; }));
o.docCerrado5 = asiento('rec:5').lineas.map(l => [l.debito_doc, l.credito_doc]);
o.rec4 = lineas('rec:4'); o.gastoYCosto = [asiento('rec:1').lineas[0].cuenta, asiento('rec:2').lineas[0].cuenta];
// sincronizar otra vez, otro día: no lo mueve ni lo duplica, y no guarda nada
S.hoy = '2026-11-20'; const foto2 = JSON.stringify(mock.get('asientos', []));
o.otraVez = await sinc(); o.igual = JSON.stringify(mock.get('asientos', [])) === foto2;
// el 1 se vuelve a registrar tal como estaba: su ajuste (y el de su nota) se van; el 2 cambia además de cuenta: su ajuste se actualiza
R(1).registrado = true; rectificacion({ recibido_id: 1, accion: 'registrado', fecha: '2026-11-21T09:00:00-06:00' });
R(2).cuenta_contable = '6.2.02.05 Papelería'; rectificacion({ recibido_id: 2, accion: 'reclasificado', fecha: '2026-11-22T09:00:00-06:00' });
o.registradoDeNuevo = await sinc(); o.origenes2 = origenes(); o.intactos2 = foto() === antes;
o.aj2 = { fecha: asiento('aj:rec:2').fecha, lineas: lineas('aj:rec:2'), cuadra: cuadra('aj:rec:2') };
// quien no puede leer las facturas a mano (sin el permiso de gastos no le llegan) no borra el ajuste de una ni genera el de otra
S.permisos = ['contabilidad']; const compras = S.datos.compras; S.datos.compras = [];
o.sinGastos = await sinc(); o.origenes3 = origenes();
S.permisos = ['contabilidad', 'gastos'];
o.conGastos = await sinc(); o.origenes4 = origenes(); o.ajCm3 = { fecha: asiento('aj:cm:3').fecha, lineas: lineas('aj:cm:3'), obs: asiento('aj:cm:3').observaciones };
// un asiento cerrado que el contador ajustó a mano sigue como siempre: no se toca y se avisa, sin ajuste automático
S.datos.compras = compras; await sinc();
S.datos.asientos = S.datos.asientos.map(a => (a.origen === 'cm:3' ? { ...a, ajustado: true } : a)); S.datos.compras = [];
o.ajustadoAMano = await sinc(); o.origenes5 = origenes(); o.huerfanoAjustado = o.ajustadoAMano.huerfanos.includes(idDe('cm:3'));
// se reabre octubre: los asientos de lo eliminado se quitan como en cualquier mes abierto, y con ellos sus ajustes
periodos('Abierto', 'Abierto');
o.reabierto = await sinc(); o.origenes6 = origenes();
"""


def test_a1_mes_cerrado_el_reverso_va_en_el_mes_en_curso(tmp_path):
    o = _sincronizar(tmp_path, GUION_A1)
    nada = {"creados": 0, "actualizados": 0, "eliminados": 0, "bloqueados": 0, "huerfanos": [], "guardo": False}
    base = ["cm:1", "cm:2", "cm:3", "rec:1", "rec:2", "rec:3", "rec:4", "rec:5", "rec:6", "rec:7", "rec:8"]
    assert o["inicial"] == {**nada, "creados": 11, "guardo": True} and o["origenes0"] == sorted(base + ["a mano"])
    assert o["fechas0"] == ["2026-10-08", "2026-11-03", "2026-10-15", "2026-11-03"]
    # al cerrar el mes no pasa nada; el importado de otro sistema sigue con su aviso de siempre (no lleva ajuste)
    assert o["alCerrar"]["creados"] == o["alCerrar"]["eliminados"] == o["alCerrar"]["actualizados"] == 0 and o["huerfanoImportado"] and not o["alCerrar"]["guardo"]
    # (1) y (3): los asientos de octubre siguen IGUALES; lo eliminado y lo reclasificado va en su asiento aj: de noviembre.
    # (5) lo de noviembre (abierto) se borra o se actualiza como siempre, sin ajuste
    r = o["rectificado"]
    assert o["intactos"] is True
    assert (r["creados"], r["actualizados"], r["eliminados"], r["bloqueados"], r["guardo"]) == (6, 1, 2, 0, True)
    assert len(r["huerfanos"]) == 1                                # solo el importado: los de compras y gastos ya no se avisan como huérfanos ni bloqueados
    ajustes = ["aj:cm:1", "aj:rec:1", "aj:rec:2", "aj:rec:5", "aj:rec:7", "aj:rec:8"]
    assert o["origenes1"] == sorted([x for x in base if x not in ("rec:3", "cm:2")] + ajustes + ["a mano"])
    gasto, costo = o["gastoYCosto"]
    assert gasto != costo and o["rec4"][0] == [gasto, 1000, 0]     # el de noviembre se reescribió en su sitio
    aj, cerrados = o["aj"], o["cerrados"]
    for origen in ("rec:1", "rec:5", "rec:7", "rec:8", "cm:1"):    # eliminado: el reverso exacto, línea por línea, y cuadra
        x = aj["aj:" + origen]
        assert x["lineas"] == _al_reves(cerrados[origen]) and x["cuadra"] is True, origen
        assert x["obs"].startswith("Reverso por rectificación · ") and x["obs"].endswith(" de octubre de 2026"), origen
        assert all(t.startswith("Reverso por rectificación · ") for t in x["textos"])
        assert (x["tipo"], x["numeracion"], x["automatico"], x["ajustado"]) == ("Compra", "AU", True, False) and x["codigo"].startswith("AU-")
    assert aj["aj:rec:1"]["obs"] == "Reverso por rectificación · C1 de octubre de 2026" and aj["aj:cm:1"]["obs"] == "Reverso por rectificación · FC-1 de octubre de 2026"
    assert aj["aj:rec:1"]["lineas"] == [[gasto, 0, 1000], ["1.1.04.01.01.01", 0, 130], ["2.1.01.01.01", 1130, 0]]
    assert (aj["aj:rec:1"]["contacto"], aj["aj:rec:1"]["documento"]) == ("Prov 1", "C1")
    assert aj["aj:rec:8"]["lineas"] == [["2.1.01.01.01", 0, 226], [gasto, 200, 0], ["1.1.04.01.01.01", 26, 0]]     # la nota de crédito de la factura eliminada
    # reclasificado de compra a gasto: solo mueve el monto de una cuenta a la otra (el IVA y la cuenta por pagar no cambian)
    assert aj["aj:rec:2"]["lineas"] == [[gasto, 1000, 0], [costo, 0, 1000]] and aj["aj:rec:2"]["cuadra"] is True
    assert aj["aj:rec:2"]["obs"] == "Ajuste por reclasificación · C2 de octubre de 2026" and aj["aj:rec:2"]["textos"] == ["Ajuste por reclasificación · Gasto", "Ajuste por reclasificación · Compra de mercadería"]
    # la fecha: la de la rectificación más reciente del documento; sin anotación, hoy; y siempre en un mes abierto
    assert [aj[x]["fecha"] for x in ("aj:rec:1", "aj:rec:2", "aj:rec:5", "aj:rec:7", "aj:cm:1", "aj:rec:8")] == ["2026-11-05", "2026-11-07", "2026-11-06", "2026-11-01", "2026-11-10", "2026-11-10"]
    # el documento en dólares se reversa también en dólares (los reportes por moneda lo toman de ahí)
    assert aj["aj:rec:5"]["moneda_doc"] == "USD" and aj["aj:rec:5"]["doc"] == [[h, d] for d, h in o["docCerrado5"]] and aj["aj:rec:5"]["lineas"][2] == ["2.1.01.01.01", 56500, 0]
    assert aj["aj:rec:1"]["moneda_doc"] is None and aj["aj:rec:1"]["doc"] == [[None, None]] * 3
    # (2) sincronizar otra vez, aunque sea otro día, no cambia nada
    assert o["otraVez"] == {**nada, "huerfanos": r["huerfanos"]} and o["igual"] is True
    # (4) vuelto a registrar: su ajuste se va (y el de su nota de crédito); el que además cambió de cuenta actualiza el suyo
    v = o["registradoDeNuevo"]
    assert (v["creados"], v["actualizados"], v["eliminados"], v["bloqueados"]) == (0, 1, 2, 0) and o["intactos2"] is True
    assert o["origenes2"] == sorted(x for x in o["origenes1"] if x not in ("aj:rec:1", "aj:rec:8"))
    assert o["aj2"] == {"fecha": "2026-11-22", "lineas": [["6.2.02.05", 1000, 0], [costo, 0, 1000]], "cuadra": True}
    # quien no puede leer el origen no borra el ajuste ni lo genera
    assert o["sinGastos"] == {**nada, "huerfanos": r["huerfanos"]} and o["origenes3"] == o["origenes2"]
    g = o["conGastos"]
    assert (g["creados"], g["eliminados"]) == (1, 0) and o["origenes4"] == sorted(o["origenes2"] + ["aj:cm:3"])
    assert o["ajCm3"] == {"fecha": "2026-11-20", "lineas": _al_reves(cerrados["cm:3"]), "obs": "Reverso por rectificación · FC-3 de octubre de 2026"}
    # el ajustado a mano: sin ajuste automático y con el aviso de siempre
    assert "aj:cm:3" not in o["origenes5"] and "cm:3" in o["origenes5"] and o["huerfanoAjustado"] is True
    # al reabrir el periodo todo vuelve a la regla del mes abierto: salen los asientos de lo eliminado y sus ajustes
    assert o["origenes6"] == sorted(["a mano", "cm:3", "rec:1", "rec:2", "rec:4", "rec:6", "rec:8"])


def test_a1_lo_que_no_es_una_rectificacion_sigue_con_su_aviso(tmp_path):
    """Sin ajuste automático (y con el aviso de siempre): el asiento cerrado que solo cambiaría por el tipo de cambio del día y la
    diferencia que no cuadra. Eliminado, el comprobante en otra moneda sí lleva su reverso, por lo que dice el asiento cerrado."""
    o = _sincronizar(tmp_path, r"""
periodos('Abierto', 'Abierto');
S.recibidos = [rec(1, { moneda: 'USD', tipo_cambio: 1, total: 113, impuesto: 13, iva: 13, monto_impuesto_acreditar: 13 })];
S.datos.compras = [com(1, { total: 11299.5 })];
o.inicial = await sinc(); o.cerrado = lineas('rec:1'); o.cm = lineas('cm:1'); o.cmCuadra = cuadra('cm:1');
periodos('Cerrado', 'Abierto');
S.tc = 510;
o.otroTipoDeCambio = await sinc(); o.origenes1 = origenes();
S.datos.compras = [];
o.sinCuadrar = await sinc(); o.origenes2 = origenes(); o.huerfano = o.sinCuadrar.huerfanos.length === 1 && o.sinCuadrar.huerfanos[0] === idDe('cm:1');
R(1).registrado = false;
o.eliminado = await sinc(); o.origenes3 = origenes();
o.aj = { lineas: lineas('aj:rec:1'), doc: asiento('aj:rec:1').lineas.map(l => [l.debito_doc, l.credito_doc]), cuadra: cuadra('aj:rec:1'), moneda_doc: asiento('aj:rec:1').moneda_doc, intacto: JSON.stringify(lineas('rec:1')) === JSON.stringify(o.cerrado) };
""")
    assert o["inicial"]["creados"] == 2 and o["cerrado"][2][1:] == [0, 56500] and o["cmCuadra"] is False     # el de la factura a mano no cuadra por 50 céntimos
    c = o["otroTipoDeCambio"]
    assert (c["creados"], c["actualizados"], c["eliminados"], c["bloqueados"], c["guardo"]) == (0, 0, 0, 1, False) and o["origenes1"] == ["cm:1", "rec:1"]
    s = o["sinCuadrar"]
    assert (s["creados"], s["eliminados"], s["bloqueados"]) == (0, 0, 1) and o["huerfano"] is True and o["origenes2"] == ["cm:1", "rec:1"]
    e = o["eliminado"]
    assert (e["creados"], e["bloqueados"], len(e["huerfanos"])) == (1, 0, 1) and o["origenes3"] == ["aj:rec:1", "cm:1", "rec:1"]
    assert o["aj"] == {"lineas": _al_reves(o["cerrado"]), "doc": [[0, 100], [0, 13], [113, 0]], "cuadra": True, "moneda_doc": "USD", "intacto": True}


def test_a1_lineas_del_ajuste_y_textos(tmp_path):
    o = _sincronizar(tmp_path, r"""
import { lineasAjuste } from './js/pages/contabilidad/automaticos.js';
const L = (cuenta, debito, credito, descripcion = '') => ({ cuenta, cuenta_nombre: 'N ' + cuenta, contacto: 'P', documento: 'D', descripcion, debito, credito });
const corta = ls => ls.map(l => [l.cuenta, l.debito, l.credito]);
o.reverso = lineasAjuste([], [L('6', 100.1, 0, 'Gasto'), L('1', 13.01, 0), L('2', 0, 113.11)], 'Reverso por rectificación');
o.igual = lineasAjuste([L('6', 100, 0), L('2', 0, 100)], [L('2', 0, 100), L('6', 60, 0), L('6', 40, 0)], 'x');
o.traslado = corta(lineasAjuste([L('5', 100, 0), L('1', 13, 0), L('2', 0, 113)], [L('6', 100, 0), L('1', 13, 0), L('2', 0, 113)], 'x'));
o.parcial = corta(lineasAjuste([L('6', 80, 0), L('1', 10.4, 0), L('2', 0, 90.4)], [L('6', 100, 0), L('1', 13, 0), L('2', 0, 113)], 'x'));
o.centavos = corta(lineasAjuste([L('6', 0.1, 0), L('6', 0.2, 0), L('2', 0, 0.3)], [], 'x'));
o.vacios = [lineasAjuste(null, undefined, 'x'), lineasAjuste([null, {}, { cuenta: '' }], [], 'x')];
""")
    assert o["reverso"] == [{"cuenta": "6", "cuenta_nombre": "N 6", "contacto": "P", "documento": "D", "descripcion": "Reverso por rectificación · Gasto", "debito": 0, "credito": 100.1},
                            {"cuenta": "1", "cuenta_nombre": "N 1", "contacto": "P", "documento": "D", "descripcion": "Reverso por rectificación", "debito": 0, "credito": 13.01},
                            {"cuenta": "2", "cuenta_nombre": "N 2", "contacto": "P", "documento": "D", "descripcion": "Reverso por rectificación", "debito": 113.11, "credito": 0}]
    assert o["igual"] == [] and o["vacios"] == [[], []]                                            # sin diferencia no hay líneas (ni asiento)
    assert o["traslado"] == [["5", 100, 0], ["6", 0, 100]] and o["parcial"] == [["6", 0, 20], ["1", 0, 2.6], ["2", 22.6, 0]]
    assert o["centavos"] == [["6", 0.3, 0], ["2", 0, 0.3]]
    au = _js("pages", "contabilidad", "automaticos.js")
    sinc = au[au.index("export async function sincronizarAutomaticos() {"):]
    # el asiento cerrado no pasa por la actualización (ni se cuenta como bloqueado) ni por el aviso de huérfanos
    assert "    vivos.add(f.origen);\n    if (cubiertos.has(f.origen)) continue;\n    const ex = porOrigen.get(f.origen);" in sinc and "&& !cubiertos.has(a.origen) && (a.ajustado || periodoCerrado(a.fecha))" in sinc
    assert "if ((pref !== 'rec' && pref !== 'cm') || ex.ajustado || !leibles.has(pref) || importados.has(origen) || !periodoCerrado(ex.fecha)) continue;" in sinc
    # (sufijo: '' o, si el ajuste anterior quedó en un mes que después se cerró, ':2', ':3'…; tests/test_423_revision.py)
    assert "fuentes.push({ origen: 'aj:' + origen + sufijo, fecha: fechaAbierta(ultima || hoy())," in sinc and "'nd_gastos', 'gastos_rectificaciones', 'planillas'" in sinc
    # permisos: aj se revisa como su origen (rec siempre; cm solo con gastos o ver todo)
    assert "leibles.add('aj');" in sinc and "if (pref === 'aj') { if (!leibles.has(id)) vivos.add(origen); continue; }" in sinc
    assert sinc.index("const leibles = new Set([") < sinc.index("const cubiertos = new Set()") < sinc.index("for (const f of fuentes) {\n    vivos.add(f.origen);")
    # Rectificaciones y la tabla de Configuración
    # (el texto depende de la acción: «el reverso» para lo eliminado, «el ajuste» para lo demás; tests/test_423_pulido.py)
    assert "periodo: !cerrado ? 'Abierto' : (x.accion === 'eliminado' ? 'Cerrado: el reverso queda en el mes en curso' : 'Cerrado: el ajuste queda en el mes en curso') };" in _js("pages", "gastos", "rectificaciones.js")
    assert "['aj', 'Reversos y ajustes de compras y gastos de meses cerrados (rectificaciones)']" in _js("pages", "configuracion", "seccion.js")


# ------------------------------------------------------------------------------------------------ A2 · cambiar la cuenta contable
PAPELERIA, LIMPIEZA = "6.2.02.05 Papelería", "6.2.02.07 Aseo y limpieza"


def test_a2_cambiar_la_cuenta_contable_de_un_mes_pasado_es_una_rectificacion(api):  # noqa: F811
    c = api
    eid = _eid()
    rid, hoy = _aceptado(1, OCTUBRE, "gasto"), _aceptado(2, NOVIEMBRE, "gasto")
    fila = _recibido(rid)
    poner = lambda i, **cuerpo: c.put(f"/api/recepcion/{i}/clasificacion", json=cuerpo)        # noqa: E731
    # un guardado que no cambia nada no anota (ni el tipo ni la cuenta; una cuenta en blanco es «sin cuenta»)
    assert poner(rid, clasificacion="gasto").status_code == 200 and poner(rid, clasificacion="gasto", cuenta_contable="  ", motivo=MOTIVO).status_code == 200
    assert _rects(c) == []
    # solo la cuenta: «reclasificado» con cuenta_anterior y cuenta_nueva, sin tipo_anterior
    r = poner(rid, clasificacion="gasto", cuenta_contable=f" {PAPELERIA} ", motivo="Era papelería")
    assert r.status_code == 200 and r.json()["cuenta_contable"] == PAPELERIA, r.text
    assert _rects(c) == [{"id": 1, "fecha": "2026-11-10T09:00:00-06:00", "usuario": "qa-exo@example.test", "accion": "reclasificado", "tipo": "gasto", "origen": "electronica",
                          "recibido_id": rid, "documento": fila.consecutivo, "clave": fila.clave, "tipo_documento": "01", "proveedor": fila.emisor_nombre,
                          "proveedor_identificacion": fila.emisor_id, "fecha_documento": "2026-10-08", "moneda": "CRC", "tipo_cambio": 1.0, "total": fila.total, "impuesto": fila.impuesto,
                          "iva_acreditar": recepcion.iva_recibido(fila), "cuenta_anterior": "", "cuenta_nueva": PAPELERIA, "mes": "2026-10", "motivo": "Era papelería", "periodo_cerrado": False}]
    # lo mismo otra vez no anota; otra cuenta sí (el motivo puede ir vacío, como al cambiar de compra a gasto)
    assert poner(rid, clasificacion="gasto", cuenta_contable=PAPELERIA).status_code == 200 and len(_rects(c)) == 1
    assert poner(rid, clasificacion="gasto", cuenta_contable=LIMPIEZA).status_code == 200
    x = _rects(c)[1]
    assert (x["accion"], x["tipo"], x["cuenta_anterior"], x["cuenta_nueva"], x["motivo"]) == ("reclasificado", "gasto", PAPELERIA, LIMPIEZA, "") and "tipo_anterior" not in x
    assert poner(rid, clasificacion="gasto", cuenta_contable=LIMPIEZA, motivo="x" * 301).status_code == 400
    # cambia el tipo y, con él, la cuenta (era de la clasificación anterior: se quita): las dos cosas en UNA anotación
    assert poner(rid, clasificacion="compra", cuenta_contable=LIMPIEZA).status_code == 200 and _recibido(rid).cuenta_contable is None
    x = _rects(c)[2]
    assert (x["tipo"], x["tipo_anterior"], x["cuenta_anterior"], x["cuenta_nueva"]) == ("compra", "gasto", LIMPIEZA, "")
    # solo el tipo (la cuenta sigue vacía): como antes, con tipo_anterior y sin cuentas
    assert poner(rid, clasificacion="gasto").status_code == 200
    x = _rects(c)[3]
    assert (x["tipo"], x["tipo_anterior"]) == ("gasto", "compra") and "cuenta_anterior" not in x and "cuenta_nueva" not in x
    # quitar la cuenta también es cambiarla
    assert poner(rid, clasificacion="gasto", cuenta_contable=PAPELERIA).status_code == 200 and poner(rid, clasificacion="gasto", cuenta_contable=None).status_code == 200
    assert [(x["cuenta_anterior"], x["cuenta_nueva"]) for x in _rects(c)[4:]] == [("", PAPELERIA), (PAPELERIA, "")]
    # del mes en curso, o fuera del registro: se cambia sin rectificación
    assert poner(hoy, clasificacion="gasto", cuenta_contable=PAPELERIA).status_code == 200 and _recibido(hoy).cuenta_contable == PAPELERIA
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert poner(rid, clasificacion="gasto", cuenta_contable=LIMPIEZA).status_code == 200
    assert [x["accion"] for x in _rects(c)] == ["reclasificado"] * 6 + ["eliminado"]
    aud = [d for a, d in _auditoria(eid) if a == "recepcion_clasificacion"]
    assert aud[2] == f"{fila.consecutivo}: gasto · {PAPELERIA} · rectificación de octubre de 2026: Era papelería" and "rectificación" not in aud[0] + aud[1] + aud[3] + aud[-1] + aud[-2]
    # la pantalla lo muestra junto al tipo
    x = _js("pages", "gastos", "rectificaciones.js")
    assert "' · cuenta: ' + (x.cuenta_anterior || 'la de su clasificación') + ' → ' + (x.cuenta_nueva || 'la de su clasificación')" in x


def test_a2_la_cuenta_de_una_factura_hecha_a_mano_por_el_guardado_generico(api):  # noqa: F811
    c = api
    eid = _eid()
    _alta(c, _compra(1, "2026-10-15", "gasto"), _compra(2, "2026-11-04", "gasto"), _compra(3, "2026-10-16", "compra", cuenta_contable=PAPELERIA))
    cambiar = lambda i, **campos: c.post("/api/registros/compras/cambios", json={"upserts": [{**_compras(c)[i], **campos}], "deletes": [], "nuevos": []})   # noqa: E731
    # sin cambios, con otro cambio cualquiera o del mes en curso: nada
    assert cambiar(1).status_code == 200 and cambiar(1, notas="revisada", cuenta_contable="").status_code == 200 and cambiar(2, cuenta_contable=PAPELERIA).status_code == 200
    assert _rects(c) == []
    # la cuenta de una de octubre
    assert cambiar(1, cuenta_contable=PAPELERIA).status_code == 200
    x = _rects(c)[0]
    assert (x["accion"], x["tipo"], x["origen"], x["compra_id"], x["mes"], x["motivo"], x["cuenta_anterior"], x["cuenta_nueva"], x["total"]) == \
        ("reclasificado", "gasto", "manual", 1, "2026-10", "", "", PAPELERIA, 11300.0) and "tipo_anterior" not in x
    assert cambiar(1, cuenta_contable=PAPELERIA).status_code == 200 and len(_rects(c)) == 1
    # el tipo y la cuenta a la vez, por el PUT de la lista completa
    v = c.get("/api/registros/compras").json()
    datos = [({**y, "tipo": "gasto", "cuenta_contable": None} if y["id"] == 3 else y) for y in v["datos"]]
    assert c.put("/api/registros/compras", json={"datos": datos, "version": v["version"]}).status_code == 200
    x = _rects(c)[1]
    assert (x["tipo"], x["tipo_anterior"], x["compra_id"], x["cuenta_anterior"], x["cuenta_nueva"]) == ("gasto", "compra", 3, PAPELERIA, "") and len(_rects(c)) == 2
    assert _auditoria(eid) == [("gastos_reclasificado", f"Gasto FC-0001 de Proveedor QA cambia de cuenta contable · cuenta: {PAPELERIA} · rectificación de octubre de 2026"),
                               ("gastos_reclasificado", "Compra FC-0003 de Proveedor QA pasa a gasto · cuenta: la de su clasificación · rectificación de octubre de 2026")]


# ------------------------------------------------------------------------------------------------ A3 · empresa sin facturación electrónica
def _responder(rid, respuesta, estado="aceptado"):
    """Deja el recibido como queda después de responderlo (05 aceptado, 07 rechazado)."""
    with Session(engine_empresa(_eid())) as s:
        r = s.get(recepcion.Recibido, rid)
        r.respuesta, r.estado_mensaje = respuesta, estado
        r.condicion_impuesto, r.monto_impuesto_acreditar, r.monto_gasto_aplicable = "01", recepcion.iva_recibido(r), r.total
        s.add(r); s.commit()


def test_a3_la_factura_de_un_recibido_sin_aceptar_cuenta_por_si_misma(api):  # noqa: F811
    """Los cuatro casos (con o sin recibido; recibido aceptado o no) en el resumen y en la D-104: cada documento cuenta UNA vez."""
    c = api
    eid = _eid()
    pend = _registrar(eid, _xml_proveedor(1, "42300001", fecha_emision=OCTUBRE))                # el XML que una empresa sin facturación electrónica no «acepta»
    acept, solo = _aceptado(2, OCTUBRE, "compra"), _aceptado(3, OCTUBRE, "gasto")
    total, iva = _recibido(acept).total, recepcion.iva_recibido(_recibido(acept))
    clave = lambda rid: _recibido(rid).clave                                                    # noqa: E731
    _alta(c, _compra(1, "2026-10-10", "gasto"),                                                 # sin recibido: cuenta la factura (como siempre)
          _compra(2, "2026-10-11", "compra", recepcion_id=pend, clave=clave(pend)),             # recibido SIN aceptar: cuenta la factura (antes no contaba nadie)
          _compra(3, "2026-10-12", "compra", recepcion_id=acept, clave=clave(acept)))           # recibido aceptado: cuenta el recibido, no la factura
    #                                                                                             y `solo`: aceptado sin factura, cuenta el recibido

    def octubre():
        res, d104 = _octubre(c)
        return (res["egresos_docs"], res["egresos"]["CRC"], res["iva"]["credito"]["CRC"], res["iva"]["docs_recibidos"],
                sorted((x["origen"], x["id"]) for x in res["detalle"]["egresos"]), {k: (d104[k]["docs"], d104[k]["compras"], d104[k]["credito"]) for k in ("08", "rec") if k in d104})
    assert octubre() == (4, round(22600 + 2 * total, 2), round(2600 + 2 * iva, 2), 4, [("Compra registrada", 1), ("Compra registrada", 2), ("Recibido", acept), ("Recibido", solo)],
                         {"08": (2, 20000.0, 2600.0), "rec": (2, round(2 * (total - iva), 2), round(2 * iva, 2))})
    res, _ = _octubre(c)
    assert [(x["id"], x["clasificacion"], x["total"], x["acreditar"]) for x in res["detalle"]["egresos"] if x["origen"] == "Compra registrada"] == [(1, "gasto", 11300.0, 1300.0), (2, "compra", 11300.0, 1300.0)]
    # el XML se acepta después (la empresa activó la facturación electrónica): pasa a contar el recibido y la factura deja de contar
    _responder(pend, "05")
    assert octubre() == (4, round(11300 + 3 * total, 2), round(1300 + 3 * iva, 2), 4, [("Compra registrada", 1), ("Recibido", pend), ("Recibido", acept), ("Recibido", solo)],
                         {"08": (1, 10000.0, 1300.0), "rec": (3, round(3 * (total - iva), 2), round(3 * iva, 2))})
    # se rechaza ante Hacienda (07): un comprobante rechazado no es una compra; ni él ni su factura cuentan (como antes de la 4.23)
    _responder(pend, "07", "aceptado")
    assert octubre() == (3, round(11300 + 2 * total, 2), round(1300 + 2 * iva, 2), 3, [("Compra registrada", 1), ("Recibido", acept), ("Recibido", solo)],
                         {"08": (1, 10000.0, 1300.0), "rec": (2, round(2 * (total - iva), 2), round(2 * iva, 2))})
    _responder(pend, "05", "rechazado")                                                         # aceptado, pero Hacienda rechazó la respuesta: tampoco cubre
    assert octubre()[:2] == (4, round(22600 + 2 * total, 2))
    # la factura que solo guarda la clave (los traslados del grupo): igual
    _alta(c, _compra(4, "2026-10-13", "gasto", clave=clave(solo)), _compra(5, "2026-10-14", "gasto", clave="7" * 50), _compra(6, "2026-10-15", "gasto", recepcion_id=987654))
    assert octubre()[:2] == (6, round(4 * 11300 + 2 * total, 2))                                 # la 4 no (su recibido está aceptado); la 5 y la 6 sí (no hay tal recibido)
    # eliminar del registro el aceptado que tiene factura saca las dos cosas: no queda contando ninguna
    assert c.post(f"/api/recepcion/{acept}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200 and 3 not in _compras(c)
    assert octubre()[:2] == (5, round(4 * 11300 + total, 2))
    # y si una pantalla vieja dejó la factura de un aceptado que ya no está en el registro, cuenta la factura (está en la lista)
    _alta(c, _compra(7, "2026-10-16", "compra", recepcion_id=acept, clave=clave(acept)))
    assert octubre()[:2] == (6, round(5 * 11300 + total, 2))
    # el cambio de compra a gasto de una factura cuyo recibido no la cubre también queda en Rectificaciones (ya cuenta en los reportes)
    antes = len(_rects(c))
    assert c.post("/api/registros/compras/cambios", json={"upserts": [{**_compras(c)[2], "tipo": "gasto"}, {**_compras(c)[4], "tipo": "compra"}], "deletes": [], "nuevos": []}).status_code == 200
    nuevas = _rects(c)[antes:]
    assert [(x["accion"], x["compra_id"], x["tipo"], x["tipo_anterior"]) for x in nuevas] == [("reclasificado", 2, "gasto", "compra")]     # la 4 no: su recibido aceptado es el que cuenta


def test_a3_la_regla_en_las_funciones_del_resumen():
    rec = lambda i, **o: {"id": i, "clave": f"{i:050d}", "tipo_documento": "01", "fecha_emision": OCTUBRE, "moneda": "CRC", "total": 1130, "impuesto": 130,   # noqa: E731
                          "respuesta": "05", "estado_mensaje": "aceptado", "registrado": True, **o}
    recibidos = [rec(1, respuesta=None, estado_mensaje=None), rec(2), rec(3), rec(4, registrado=False), rec(5, respuesta="07"), rec(6, estado_mensaje="error"), rec(7, respuesta="06"),
                 {k: v for k, v in rec(8).items() if k != "registrado"}, rec(9, tipo_documento="10")]
    com = lambda i, **o: _compra(i, "2026-10-15", **o)                                                                                                       # noqa: E731
    compras = [com(1), com(2, recepcion_id=1), com(3, recepcion_id=2), com(4, recepcion_id=4, clave=rec(4)["clave"]), com(5, clave=rec(5)["clave"]), com(6, recepcion_id="6"),
               com(7, recepcion_id="7"), com(8, clave=rec(8)["clave"]), com(9, recepcion_id=99), com(10, clave=rec(1)["clave"]), com(11, recepcion_id=9), com(12, fec_id=3), com(13, recepcion_id=3.5)]
    cuentan = [x["compra"]["id"] for x in resumen.compras_manuales(compras, recibidos, "2026-10-01", "2026-10-31")]
    # cuentan por sí mismas: la hecha a mano (1), las de un recibido sin aceptar (2 y 10), fuera del registro (4), con la respuesta rechazada por
    # Hacienda (6) o que no existe (9 y 13). No: las de un recibido aceptado y registrado (3, 7, 8 y la 11), la de un comprobante que se RECHAZÓ
    # (5: respuesta 07, no es una compra) ni la que tiene FEC (12)
    assert cuentan == [1, 2, 4, 6, 9, 10, 13]
    assert [x["id"] for x in resumen._aceptados(recibidos, "2026-10-01", "2026-10-31")] == [2, 3, 7, 8]            # y estos son los recibidos que cuentan (el recibo de pago 9 nunca)
    # sin recibidos todas cuentan menos la de la FEC; y el generador que se recorre una sola vez también sirve
    assert len(resumen.compras_manuales(compras, [], "2026-10-01", "2026-10-31")) == 12
    assert [x["compra"]["id"] for x in resumen.compras_manuales(iter(compras), iter(recibidos), "2026-10-01", "2026-10-31")] == cuentan


GUION_A3 = r"""
import { filasRegistro } from './js/pages/gastos/_registro.js';
periodos('Abierto', 'Abierto');
// 1 sin aceptar (empresa sin facturación electrónica), 2 aceptado con factura, 3 aceptado sin factura, 4 aceptado y quitado del registro,
// 5 rechazado, 6 sin aceptar (su factura solo guarda la clave), 7 aceptado (su factura solo guarda la clave)
S.recibidos = [rec(1, { respuesta: null, estado_mensaje: null }), rec(2, { clasificacion: 'compra' }), rec(3), rec(4, { registrado: false }), rec(5, { respuesta: '07' }),
  rec(6, { respuesta: null, estado_mensaje: null }), rec(7)];
S.datos.compras = [com(1), com(2, { recepcion_id: 1, clave: rec(1).clave }), com(3, { recepcion_id: 2, clave: rec(2).clave, tipo: 'compra' }), com(4, { recepcion_id: 4, clave: rec(4).clave }),
  com(5, { recepcion_id: 5 }), com(6, { clave: rec(6).clave }), com(7, { clave: rec(7).clave }), com(8, { recepcion_id: 99 }), com(9, { fec_id: 5 })];
const lista = () => [...filasRegistro('gasto', S.datos.compras, S.recibidos), ...filasRegistro('compra', S.datos.compras, S.recibidos)].map(f => [f.id, f.origen, f.total]).sort((a, b) => String(a[0]).localeCompare(String(b[0]), 'es', { numeric: true }));
o.inicial = await sinc(); o.origenes0 = origenes(); o.lista0 = lista();
o.cm2 = { fecha: asiento('cm:2').fecha, lineas: lineas('cm:2'), cuadra: cuadra('cm:2'), obs: asiento('cm:2').observaciones };
// el XML 1 se acepta: el asiento de su factura se va y entra el del recibido; cada documento sigue una sola vez
Object.assign(R(1), { respuesta: '05', estado_mensaje: 'aceptado' });
o.aceptado = await sinc(); o.origenes1 = origenes(); o.lista1 = lista();
// con octubre cerrado, se acepta el 6: el asiento de su factura no se toca, se reversa en noviembre, y el del recibido entra en el primer mes abierto
periodos('Cerrado', 'Abierto');
Object.assign(R(6), { respuesta: '05', estado_mensaje: 'aceptado' });
o.cerrado = await sinc(); o.origenes2 = origenes();
o.rec6 = asiento('rec:6').fecha; o.aj6 = { fecha: asiento('aj:cm:6').fecha, lineas: lineas('aj:cm:6'), reverso: JSON.stringify(lineas('aj:cm:6')) === JSON.stringify(lineas('cm:6').map(([c, d, h]) => [c, h, d])) };
"""


def test_a3_asientos_y_listas_con_la_misma_regla(tmp_path):
    o = _sincronizar(tmp_path, GUION_A3)
    # asientos: cm: de la factura cuando su recibido no la cubre (o no hay recibido); rec: del recibido aceptado y registrado. Nada dos veces
    # (la factura 5 es de un comprobante RECHAZADO, respuesta 07: no lleva asiento)
    assert o["inicial"]["creados"] == 8 and o["origenes0"] == ["cm:1", "cm:2", "cm:4", "cm:6", "cm:8", "rec:2", "rec:3", "rec:7"]
    assert o["cm2"] == {"fecha": "2026-10-15", "lineas": [["6.2.02.20", 10000, 0], ["1.1.04.01.01.01", 1300, 0], ["2.1.01.01.01", 0, 11300]], "cuadra": True,
                        "obs": "Factura de compra FC-2 · Manual 2 (registrada a mano)"}
    # las listas Compras y Gastos muestran lo mismo que se contabiliza: una fila por documento (la factura 9 es la de la FEC, que cuenta por su comprobante
    # emitido; la 5, del comprobante rechazado, sigue en la lista para eliminarla, con su origen «Comprobante rechazado», pero no se contabiliza)
    assert o["lista0"] == [[1, "manual", 11300], [2, "manual", 11300], [3, "electronica", 1130], [4, "manual", 11300], [5, "rechazado", 11300], [6, "manual", 11300], [7, "electronica", 1130],
                           [8, "manual", 11300], [9, "fec", 11300], ["r3", "electronica", 1130]]
    a = o["aceptado"]
    assert (a["creados"], a["eliminados"]) == (1, 1) and o["origenes1"] == ["cm:1", "cm:4", "cm:6", "cm:8", "rec:1", "rec:2", "rec:3", "rec:7"]
    assert [x for x in o["lista1"] if x[0] == 2] == [[2, "electronica", 1130]] and len(o["lista1"]) == len(o["lista0"])
    k = o["cerrado"]
    assert (k["creados"], k["eliminados"], k["bloqueados"], k["huerfanos"]) == (2, 0, 0, []) and o["origenes2"] == sorted(o["origenes1"] + ["aj:cm:6", "rec:6"])
    assert o["rec6"] == "2026-11-01" and o["aj6"]["fecha"] == "2026-11-10" and o["aj6"]["reverso"] is True
    au = _js("pages", "contabilidad", "automaticos.js")
    assert "if (c.id && !c.fec_id && !(c.recepcion_id && idsNo.has(String(c.recepcion_id))) && !(c.clave && clavesNo.has(c.clave)) && +c.total > 0) fuentes.push({ origen: 'cm:' + c.id," in au
    assert "const rechazados = recibidos.filter(r => r.respuesta === '07'), idsNo = new Set([...idsOk, ...rechazados.map(r => String(r.id))]), clavesNo = new Set([...aceptadasOk, ...rechazados.map(r => r.clave)]);" in au
    assert "const idsOk = new Set(recibidos.filter(r => r.clave && aceptadasOk.has(r.clave)).map(r => String(r.id)));" in au and "clavesRec" not in au


# ------------------------------------------------------------------------------------------------ A4 · dos textos y dos enlaces
def test_a4_textos_del_hotel_y_enlaces_de_los_reportes(tmp_path):
    s = _js("pages", "hotel", "servicios.js")
    assert s.count("en Gastos › Pagos a proveedores") == 2 and "Compras ›" not in s
    r = _js("pages", "reportes", "reporte.js")
    # la ruta /gastos/compras/<id> no existe: los reportes llevan a la lista donde sale el documento
    assert "'/gastos/compras/'" not in r and "import { filasRegistro } from '../gastos/_registro.js';" in r
    assert "else if (x.cid) location.hash = x.lista || '/gastos/compras'; };" in r and "{ key: 'doc', label: 'Documento', mono: true, link: x => abrirCompra(x.id) }" in r
    a = _js("app.js")
    assert "'/gastos/compras': 'gastos/compras'," in a and "'/gastos/gastos': 'gastos/compras'," in a and "'/gastos/compras/:" not in a
    # las funciones de reporte.js tal como están, con la regla de verdad de las listas (filasRegistro)
    ini = r.index("const listaDeTipo = tipo => ")
    fuente = r[ini:r.index("\n}\n", r.index("async function abrirCompra(id) {", ini)) + 3]
    o = _node(tmp_path, """
import { filasRegistro } from './registro.mjs';
const location = { hash: '' }, E = { compras: [], recibidos: [], falla: false, pedidos: 0 };
const compras = () => E.compras, api = async url => { E.pedidos++; if (E.falla || url !== '/api/recepcion') throw new Error('sin acceso'); return E.recibidos; };
""" + fuente + """
const rec = (id, o = {}) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto', registrado: true, total: 1130, ...o });
const com = (id, tipo, o = {}) => ({ id, tipo, total: 11300, lineas: [], ...o });
E.recibidos = [rec(1), rec(2, { clasificacion: 'compra' }), rec(3, { respuesta: null, estado_mensaje: null, clasificacion: 'compra' }), rec(4, { clasificacion: 'compra', registrado: false })];
E.compras = [com(1, 'compra'), com(2, 'gasto'), com(3, 'compra', { recepcion_id: 1 }), com(4, 'gasto', { clave: rec(2).clave }), com(5, 'gasto', { recepcion_id: 3 }), com(6, 'gasto', { recepcion_id: 4 }), com(7)];
const ir = async id => { location.hash = ''; await abrirCompra(id); return location.hash; };
const destinos = []; for (const id of [1, 2, 3, 4, 5, 6, 7, '3', 99]) destinos.push(await ir(id));
const pedidos = E.pedidos; E.falla = true;
console.log(JSON.stringify({ destinos, pedidos, sinAcceso: [await ir(3), await ir(4)],
  egresos: [idsEgreso({ id: 8, origen: 'Compra registrada', clasificacion: 'compra' }), idsEgreso({ id: 9, origen: 'Compra registrada', clasificacion: 'gasto' }), idsEgreso({ id: 5, origen: 'Recibido' })] }));
""", registro=("pages", "gastos", "_registro.js"))
    C, G = "/gastos/compras", "/gastos/gastos"
    # la hecha a mano, por su tipo; la creada desde un comprobante aceptado, donde está clasificado ese comprobante (3 y 4); la de un
    # recibido sin aceptar o fuera del registro, por su tipo (5 y 6); sin tipo es gasto; la que no se encuentra, a Compras
    assert o["destinos"] == [C, G, G, C, G, G, G, G, C] and o["pedidos"] == 5                    # solo consulta los recibidos si la factura salió de uno
    assert o["sinAcceso"] == [C, G]                                                             # sin poder leerlos, por el tipo de la factura
    assert o["egresos"] == [{"rid": None, "cid": 8, "lista": C}, {"rid": None, "cid": 9, "lista": G}, {"rid": 5, "cid": None, "lista": G}]
