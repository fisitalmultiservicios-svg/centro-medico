# -*- coding: utf-8 -*-
"""4.25: correcciones que salieron de la verificación de la tanda 9c (suite completa, revisor y prueba con servidores de verdad).
Cada prueba falla sin su arreglo.

- Programa con dos empresas y una revocada: el ingreso de quien aquí solo es de la empresa revocada no se pregunta a la web con la llave
  de la otra empresa (era la falla de tests/test_425_ultimos_servidor.py::test_p7… dentro de la suite completa, donde quedan empresas
  vinculadas por otras pruebas).
- «Conectar otra empresa»: una cancelación que llega del programa o de la web con su mensaje (la empresa sin cédula) ya no cierra el
  bloque (pages/configuracion/instalacion-local.js, con el componente de verdad).
- #/conectar: la respuesta del seguimiento de un pase que ya no es el que se sigue se descarta (pages/conectar.js).

Nube y computadora corren en el MISMO proceso y comparten la tabla de usuarios (ayudas de tests/test_49_local_sinc.py y
tests/test_425_ingreso_programa.py). Las pantallas corren en Node con los módulos de verdad (ayudas de
tests/test_425_ultimos_pantallas.py). Nada va a la red."""
import json
from datetime import datetime, timezone

from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, engine
from test_49_local_sinc import PW, H, _admin_empresa, _cfg, _poner_cfg, _vincular, c
from test_425_conexion_programa import _limpieza, _programa  # noqa: F401  (la limpieza desvincula las empresas de cada prueba)
from test_425_ingreso_programa import INGRESO, _miembro, _persona, _poner, _sesion_de, _solo_estas, _ultima_auditoria
from test_425_ultimos_pantallas import MEMORIA, MONTAR, _js, _node, _tramo


# ================================================================================================ dos empresas y una revocada
def _fallos(correo: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login_fallo", "login_cuenta", "login_fallo_prog")),
                                                    auth.IntentoIp.ip.endswith(correo))).all()


def _fallidos(correo: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.correo == correo, Auditoria.accion.in_(("login_fallido", "login_bloqueado")))).all()


def _preguntas(shim) -> int:
    return len([x for x in shim.llamadas if x[1] == INGRESO])


def _entrar(correo: str, pw: str = PW):
    return c.post("/api/auth/login", json={"correo": correo, "password": pw})


def test_dos_empresas_y_una_revocada_no_se_pregunta_con_la_llave_de_la_otra(monkeypatch):
    eid_a1, ta1 = _admin_empresa("-c9c1n", "3101425981")                    # la web: Uno y Dos
    eid_a2, ta2 = _admin_empresa("-c9c2n", "3101425983")
    eid_l1, tl1 = _admin_empresa("-c9c1l", "3101425982")                    # la computadora: Uno y Dos
    eid_l2, tl2 = _admin_empresa("-c9c2l", "3101425984")
    shim = _programa(monkeypatch, sin_estrenar=False)
    terminal = _vincular(monkeypatch, ta1, tl1, "Caja")["terminal"]
    _vincular(monkeypatch, ta2, tl2, "Caja")
    _solo_estas(monkeypatch, eid_l1, eid_l2)                                # la computadora «solo tiene» estas dos empresas
    for eid in (eid_l1, eid_l2):
        _poner_cfg(eid, version_nube="4.25")
    # en la web se revoca la computadora SOLO en Uno; el programa se entera en su ciclo
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta1)).status_code == 200
    assert sinc.sincronizar(eid_l1)["revocada_en"]
    assert _cfg(eid_l1)["vinculado"] and _cfg(eid_l1)["revocada_en"] and not _cfg(eid_l2).get("revocada_en")
    assert [x[0] for x in sinc._vinculadas()] == [eid_l2]                   # para el ingreso solo cuenta Dos
    shim.llamadas.clear()

    # (1) cajera de Uno que bajó a esta computadora y nunca entró aquí (solo el hash inservible): no está conectada, sin contar fallo,
    # las veces que lo intente, y sin preguntarle a la web con la llave de Dos
    uid3, correo3 = _persona(eid_a1, "cajera3-c9c", local=eid_l1)
    _poner(uid3, password_hash=sinc.HASH_INSERVIBLE)
    for _ in range(6):
        r = _entrar(correo3)
        assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_CONECTAR_AQUI, r.text
    assert _preguntas(shim) == 0 and not _fallos(correo3) and not _fallidos(correo3)

    # (2) con su contraseña guardada pero sin haber entrado en línea aquí: tampoco (lo más estricto: Dos valida en línea contra la 4.25)
    uid2, correo2 = _persona(eid_a1, "cajera2-c9c", local=eid_l1)
    r = _entrar(correo2)
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_CONECTAR_AQUI, r.text
    assert _preguntas(shim) == 0 and not _fallos(correo2)

    # (3) la que ya había entrado aquí en línea: como en una computadora con solo esa empresa, entra con lo guardado; una contraseña
    # mala sigue contando fallo (se compara aquí)
    uid1, correo1 = _persona(eid_a1, "cajera1-c9c", local=eid_l1, nube_validado=datetime.now(timezone.utc))
    r = _entrar(correo1)
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True and _sesion_de(r.json()["token"]).sin_nube is True, r.text
    assert "instalación revocada" in _ultima_auditoria(uid1, "login").detalle
    assert _entrar(correo1, "Clave-Mala-c9c-2026").status_code == 401 and len(_fallos(correo1)) == 1
    assert _preguntas(shim) == 0

    # (4) quien además es de Dos (conectada) se sigue preguntando a la web, con la llave de Dos
    uid4, correo4 = _persona(eid_a2, "mesera-c9c", local=eid_l2)
    with Session(engine) as sc:
        sc.add(auth.UsuarioEmpresa(usuario_id=uid4, empresa_id=eid_l1, rol="Cajero")); sc.commit()
    r = _entrar(correo4)
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is False and _preguntas(shim) == 1, r.text

    # (5) quien aquí no es de ninguna empresa de esta computadora: se pregunta con las empresas conectadas, como siempre (D-K)
    uid5, correo5 = _persona(eid_a2, "nueva-c9c")
    r = _entrar(correo5)
    assert r.status_code == 200 and _preguntas(shim) == 2 and _miembro(uid5, eid_l2) and not _miembro(uid5, eid_l1), r.text

    # la función, con sus casos: sin la persona, sin empresas conectadas o con alguna suya conectada, no aplica
    vinc = {eid: (cfg, tok) for eid, cfg, tok in sinc._vinculadas()}
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid3)
    assert sinc._solo_de_revocadas(u, {eid_a1, eid_l1}, vinc) is True
    assert sinc._solo_de_revocadas(u, {eid_a1}, vinc) is False                # ninguna suya está revocada aquí
    assert sinc._solo_de_revocadas(u, {eid_l1, eid_l2}, vinc) is False        # también es de una conectada
    assert sinc._solo_de_revocadas(None, {eid_l1}, vinc) is False and sinc._solo_de_revocadas(u, {eid_l1}, {}) is False


# ================================================================================================ «Conectar otra empresa»: la cancelación con mensaje
SIN_CEDULA = "Esa empresa no tiene cédula registrada en la página web: complete sus datos allá e inténtelo de nuevo."
FALSO_API = """
export const toast = () => {};
export const fechaHora = x => x;
export const api = async (url, opt) => { globalThis.Q.pedidos.push([url, opt && opt.body]); return globalThis.Q.respuesta || {}; };
"""
FALSO_APP = "export const sesion = { puede: () => true, usuario: { de_nube: true }, cerrar() {}, async refrescarEmpresas() { return {}; } };\n"


def test_otra_empresa_la_cancelacion_con_mensaje_no_cierra_el_bloque(tmp_path):
    assert sinc.MENSAJES_LOCAL["sin_cedula"] == SIN_CEDULA
    r = _node(tmp_path, MONTAR + MEMORIA + """
globalThis.Q = { pedidos: [], respuesta: null };
globalThis.document = { visibilityState: 'visible', addEventListener() {}, removeEventListener() {} };
globalThis.confirm = () => true;
const P = (await import('./js/pages/configuracion/instalacion-local.js')).default;
const C = (await import('./js/conexion-local.js')).default;
const TEXTO = __TEXTO__;
// la pantalla con el bloque «Conectar otra empresa» abierto y su componente, enlazados como en la plantilla (ref="otraCx", @estado="otraEstado")
function armar(vista) {
  const pagina = montar(P); pagina.cargar = () => {}; pagina.otra = true;
  const cx = montar(C, { web: '', equipo: '', conSesion: true, boton: 'Conectar otra empresa', otraEmpresa: true,
                         $emit(ev, x) { if (ev === 'estado') pagina.otraEstado(x); } });
  cx.programar = () => {};
  pagina.$refs = { otraCx: cx };
  mem['conexion:intento'] = 'abc'; mem['conexion:otra'] = 'abc'; Q.pedidos = [];
  cx.v = Object.assign({ intento: 'abc' }, vista);
  return [pagina, cx];
}
const out = {};
// en la web se aprobó para una empresa sin cédula: el programa termina el intento «cancelada» con su mensaje
let [pagina, cx] = armar({ estado: 'esperando', codigo: 'ABCD-EFGH' });
Q.respuesta = { intento: 'abc', estado: 'cancelada', mensaje: TEXTO, error: null };
await cx.consultar();
out.sin_cedula = [pagina.otra, pagina.enCurso, cx.v && cx.v.estado, cx.v && cx.v.mensaje, cx.final, mem['conexion:intento'] === undefined];
cx.deNuevo();                                   // «Empezar de nuevo»: vuelve el formulario, dentro del mismo bloque
out.de_nuevo = [pagina.otra, cx.v, Q.pedidos.filter(x => x[0].endsWith('/cancelar')).length];
await pagina.volverDeOtra(); out.volver = pagina.otra;
// «No es mi empresa»: la respuesta también trae su mensaje y se ve
[pagina, cx] = armar({ estado: 'confirmar' });
Q.respuesta = { intento: 'abc', estado: 'cancelada', mensaje: 'La conexión se canceló.' };
await cx.noEsMia(); out.no_es_mia = [pagina.otra, cx.v && cx.v.mensaje];
// la persona toca «Cancelar» mientras espera (el componente ya no tiene vista): el bloque se cierra, como antes
[pagina, cx] = armar({ estado: 'esperando' }); Q.respuesta = {};
await cx.cancelar(); out.cancelar = [pagina.otra, pagina.enCurso, cx.v, mem['conexion:intento'] === undefined];
// «Empezar de nuevo» después de un fallo al aplicar: también como antes
[pagina, cx] = armar({ estado: 'fallo', mensaje: 'x' });
cx.deNuevo(); out.fallo = [pagina.otra, cx.v];
console.log(JSON.stringify(out));
""".replace("__TEXTO__", json.dumps(SIN_CEDULA, ensure_ascii=False)), archivos=("pages/configuracion/instalacion-local.js", "conexion-local.js"), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r["sin_cedula"] == [True, False, "cancelada", SIN_CEDULA, True, True], r      # el bloque sigue abierto, con el mensaje
    assert r["de_nuevo"] == [True, None, 0] and r["volver"] is False, r
    assert r["no_es_mia"] == [True, "La conexión se canceló."], r
    assert r["cancelar"] == [False, False, None, True], r
    assert r["fallo"] == [False, None], r
    i = _js("pages/configuracion/instalacion-local.js")
    assert "if (e === 'cancelada' && !(cx && cx.v && cx.v.estado === 'cancelada')) this.otra = false; }," in i
    assert "if (e === 'cancelada') this.otra = false;" not in i
    # lo que se ve en ese estado: el mensaje y «Empezar de nuevo» (rama final del componente)
    cl = _js("conexion-local.js")
    final = cl[cl.rindex("<template v-else>"):]
    assert "{{v.mensaje || 'No se pudo terminar de conectar. Empiece de nuevo.'}}" in final and '@click="deNuevo">Empezar de nuevo</button>' in final


# ================================================================================================ #/conectar: la respuesta de un pase anterior
FALSO_API_CONECTAR = """
export const toast = () => {};
export const api = (url, opt) => {
  globalThis.Q.pedidos.push([url, opt && opt.body]);
  if (url === '/api/auth/estado') return Promise.resolve({});
  if (url === '/api/sinc/conexion/seguimiento') return new Promise((ok, mal) => globalThis.Q.pendientes.push({ pase: opt.body.pase, ok, mal }));
  return Promise.resolve({ codigo: opt.body.codigo, nombre: 'Caja ' + opt.body.codigo, empresas: [] });
};
"""
FALSO_APP_CONECTAR = """
export const sesion = { empresa_id: null, puede: () => false };
export const conexion = { codigo: '', fijar(c) { this.codigo = c; }, limpiar() { this.codigo = ''; },
  leerPase() { return globalThis.Q.pase; }, fijarPase(p) { globalThis.Q.pase = p || null; } };
"""


def test_conectar_descarta_la_respuesta_del_pase_anterior(tmp_path):
    r = _node(tmp_path, MONTAR + """
globalThis.Q = { pedidos: [], pase: null, pendientes: [] };
globalThis.history = { replaceState() {} };
const C = (await import('./js/pages/conectar.js')).default;
const { conexion } = await import('./js/app.js');
const out = {};
const tic = () => new Promise(r => setTimeout(r, 0));
const no404 = () => Object.assign(new Error('Esa conexión ya no existe'), { status: 404 });
// la pestaña sigue el pase 7 de la computadora A, con una consulta de seguimiento EN CURSO, y llega el enlace con el código de B
const hastaB = async () => {
  conexion.codigo = ''; Q.pase = 7; Q.pedidos = []; Q.pendientes = [];
  const vm = montar(C); vm.paso = 'aprobada'; vm.consultado = 'ABCD-EFGH'; vm.aprobada = { pase: 7, numero: '555', nombre: 'Caja A', empresa: 'Uno' }; vm.seguimiento = 'aprobada';
  const p = vm.seguir();
  conexion.codigo = 'JKLMNPQR'; C.watch.codigoPestana.call(vm); await tic();
  return [vm, p, Q.pendientes.shift()];
};
// (1) la respuesta vieja dice «entregada»: la pantalla sigue en la revisión de B
let [vm, p, vieja] = await hastaB();
out.revisando = [vm.paso, vm.info && vm.info.nombre, vieja.pase];
vieja.ok({ estado: 'entregada' }); await p; await tic();
out.entregada = [vm.paso, vm.aprobada, vm.final, vm._t == null];
// (2) la respuesta vieja es un final, o el pase viejo ya no existe (404)
[vm, p, vieja] = await hastaB(); vieja.ok({ estado: 'cancelada' }); await p; await tic(); out.cancelada = [vm.paso, vm.final, vm.aprobada];
[vm, p, vieja] = await hastaB(); vieja.mal(no404()); await p; await tic(); out.no_existe = [vm.paso, vm.final, vm.aprobada];
// (3) la persona ya aprobó la de B (se sigue SU pase, el 9): la respuesta vieja de A no toca su seguimiento ni su pase guardado
for (const [nombre, llegar] of [['b_entregada', v => v.ok({ estado: 'entregada' })], ['b_vencida', v => v.ok({ estado: 'vencida' })], ['b_404', v => v.mal(no404())]]) {
  [vm, p, vieja] = await hastaB();
  vm.aprobada = { pase: 9, numero: '123', nombre: 'Caja B', empresa: 'Dos' }; vm.paso = 'aprobada'; vm.seguimiento = 'retenida'; Q.pase = 9;
  llegar(vieja); await p; await tic();
  out[nombre] = [vm.paso, vm.seguimiento, Q.pase, vm.aprobada.numero, vm.final, vm._t == null];
}
// (4) sin código nuevo todo sigue igual: la respuesta del pase que se sigue se aplica
const normal = async (llegar) => {
  conexion.codigo = ''; Q.pase = 7; Q.pendientes = [];
  const vm = montar(C); vm.paso = 'aprobada'; vm.aprobada = { pase: 7, numero: '555', nombre: 'Caja A' }; vm.seguimiento = 'aprobada';
  const p = vm.seguir(); llegar(Q.pendientes.shift()); await p;
  const s = [vm.paso, vm.seguimiento, Q.pase, vm._t == null]; vm.parar(); return s;
};
out.normal = [await normal(v => v.ok({ estado: 'entregada' })), await normal(v => v.ok({ estado: 'retenida', segundos_retencion: 200 })), await normal(v => v.mal(no404()))];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/conectar.js",), falsos={"api.js": FALSO_API_CONECTAR, "app.js": FALSO_APP_CONECTAR})
    assert r["revisando"] == ["revisar", "Caja JKLM-NPQR", 7], r
    assert r["entregada"] == ["revisar", None, "", True], r
    assert r["cancelada"] == ["revisar", "", None] and r["no_existe"] == ["revisar", "", None], r
    for nombre in ("b_entregada", "b_vencida", "b_404"):
        assert r[nombre] == ["aprobada", "retenida", 9, "123", "", True], (nombre, r)
    assert r["normal"] == [["listo", "aprobada", None, True], ["aprobada", "retenida", 7, False], ["fin", "aprobada", None, True]], r
    seguir = _tramo(_js("pages/conectar.js"), "    async seguir() {", "    async retomar(pid) {")
    assert "const pase = this.aprobada.pase, yaEsOtro = () => this.paso !== 'aprobada' || !this.aprobada || this.aprobada.pase !== pase;" in seguir
    assert seguir.count("if (yaEsOtro()) return;") == 2
    assert seguir.index("if (yaEsOtro()) return;") < seguir.index("this.poner(r);") < seguir.index("} catch (e) {") < seguir.rindex("if (yaEsOtro()) return;") < seguir.index("e.status === 404")
