"""3.87 (g6_documentos): lecturas de documentos y sucursales, con sesiones reales (token → contexto → sucursal fija).
- comercio:3: el Cajero abre por número solo lo reciente (hoy, o las últimas 6 horas si su turno cruzó la medianoche), igual que su
  lista: detalle, PDF, XML y tiquete. Antes solo se revisaba la empresa y recorría todo el historial por id.
- comercio:7: el Cajero no lee las facturas recurrentes pendientes ni marca una como emitida con su tiquete.
- comercio:14: el PDF, el tiquete, el XML o la respuesta cuyo archivo no está en disco responden 404 con un mensaje claro (antes 500).
- extras:6: quien está amarrado a una sucursal abre por id solo lo de ella. extras:5: si se la desactivan sigue limitado a ella y
  no emite (antes veía todo y emitía con la principal). extras:8: la numeración es la de la sucursal activa.
- extras:3: la sesión trae la bodega de cada sucursal; la caja y la factura la proponen (prueba de texto).
- extras:10 / servicios:5: los roles de un solo módulo (solo RRHH, Técnico de soporte, Camarera…) no leen ventas, cobros, borradores,
  recurrentes, cotizaciones ni montos de clientes.
- facturacion:8: el Contador corrige sus proveedores (no los convierte en clientes); la pantalla no ofrece lo que el servidor rechaza."""
import json
import pathlib
import uuid
from datetime import datetime, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, main as M, sucursales
from app.config import TZ_CR
from app.db import Documento, Empresa, engine, engine_empresa, init_db

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CLAVE = "Clave-larga-387-g6-qa"
LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]
TIQ = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "lineas": LINEAS}


class Entorno:
    """Empresa de prueba con usuarios @example.test reales (token de sesión); todo se borra al final."""

    def __init__(self, tipo="comercio"):
        init_db()
        self.suf = uuid.uuid4().hex[:6]
        with Session(engine) as s:
            e = Empresa(nombre=f"Documentos G6 {self.suf} QA S.A.", numero_id="3101" + str(uuid.uuid4().int)[:6], actividad="471101",
                        otras_senas="Local central de pruebas", correo=f"emp.g6.{self.suf}@example.test", ambiente="sandbox", tipo_negocio=tipo)
            s.add(e); s.commit(); s.refresh(e); s.expunge(e)
        self.e, self.c, self.uids, self.t = e, TestClient(M.app), [], {}

    def usuario(self, clave, rol, permisos_propios=None, sucursal_id=None):
        with Session(engine) as s:
            if permisos_propios is not None and not auth.rol_personalizado(s, self.e.id, rol):
                s.add(auth.RolEmpresa(empresa_id=self.e.id, nombre=rol, descripcion="QA", permisos=json.dumps(sorted(permisos_propios)))); s.commit()
            u = auth.Usuario(correo=f"{clave}.g6.{self.suf}@example.test", nombre=clave.capitalize(), password_hash=auth.hash_password(CLAVE),
                             terminos_version=auth.TERMINOS_VERSION, paleta="turquesa", mfa_activo=(rol == "Administrador"))
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=self.e.id, rol=rol, sucursal_id=sucursal_id)); s.commit()
            self.uids.append(u.id)
            self.t[clave] = auth._respuesta(s, u, self.e.id)["token"]
        return self.t[clave]

    def h(self, clave, **extra):
        return {"Authorization": "Bearer " + self.t[clave], **extra}

    def get(self, clave, path, **extra):
        return self.c.get(path, headers=self.h(clave, **extra))

    def emitir(self, clave, extra=None, **cab):
        r = self.c.post("/api/comprobantes", json={**TIQ, **(extra or {})}, headers=self.h(clave, **cab))
        assert r.status_code == 200, r.text
        return r.json()

    def fecha(self, did, iso):
        with Session(engine_empresa(self.e.id)) as se:
            d = se.get(Documento, did); d.fecha_emision = iso; se.add(d); se.commit()

    def limpiar(self):
        with Session(engine) as s:
            for uid in self.uids:
                for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).all():
                    s.delete(m)
                for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid)).all():
                    s.delete(x)
                u = s.get(auth.Usuario, uid)
                if u:
                    s.delete(u)
            for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == self.e.id)).all():
                s.delete(r)
            e = s.get(Empresa, self.e.id)
            if e:
                s.delete(e)
            s.commit()


@pytest.fixture()
def ent():
    x = Entorno()
    try:
        yield x
    finally:
        x.limpiar()


def _ahora(monkeypatch, iso):
    """Fija la hora de Costa Rica que usan las reglas de lectura (main.ahora_cr)."""
    fijo = datetime.fromisoformat(iso).astimezone(TZ_CR)
    monkeypatch.setattr(M, "ahora_cr", lambda: fijo)


# ----------------------------------------------------------------------------- comercio:3
def test_cajero_por_id_solo_lo_reciente(ent, monkeypatch):
    ent.usuario("admin", "Administrador"); ent.usuario("cajero", "Cajero")
    viejo, noche, tarde, hoy = (ent.emitir("admin") for _ in range(4))
    ent.fecha(viejo["id"], "2026-10-20T10:06:51-06:00")
    ent.fecha(tarde["id"], "2026-11-04T17:00:00-06:00")
    ent.fecha(noche["id"], "2026-11-04T23:50:00-06:00")
    ent.fecha(hoy["id"], "2026-11-05T00:10:00-06:00")
    _ahora(monkeypatch, "2026-11-05T00:30:00-06:00")            # la caja sigue abierta pasada la medianoche
    for sufijo in ("", "/pdf", "/xml", "/tiquete?ancho=80", "/respuesta"):
        for d in (viejo, tarde):
            r = ent.get("cajero", f"/api/comprobantes/{d['id']}{sufijo}")
            assert r.status_code == 404 and r.json()["detail"] == "Comprobante no encontrado", (sufijo, d["id"], r.status_code)
        assert ent.get("admin", f"/api/comprobantes/{viejo['id']}{sufijo}").status_code in (200, 404 if sufijo == "/respuesta" else 200)
    for d in (noche, hoy):                                           # reimprimir lo de su turno: detalle y tiquete
        assert ent.get("cajero", f"/api/comprobantes/{d['id']}").status_code == 200
        r = ent.get("cajero", f"/api/comprobantes/{d['id']}/tiquete?ancho=80")
        assert r.status_code == 200 and r.content[:4] == b"%PDF"
    _ahora(monkeypatch, "2026-11-05T10:30:00-06:00")            # de día: solo lo de hoy, como su lista
    assert ent.get("cajero", f"/api/comprobantes/{noche['id']}").status_code == 404
    assert ent.get("cajero", f"/api/comprobantes/{hoy['id']}").status_code == 200
    assert ent.get("admin", f"/api/comprobantes/{noche['id']}").status_code == 200
    ids = {d["id"] for d in ent.get("cajero", "/api/comprobantes").json()}
    assert hoy["id"] in ids and not ({viejo["id"], tarde["id"], noche["id"]} & ids)


# ----------------------------------------------------------------------------- comercio:7
def test_cajero_no_lee_ni_toma_recurrentes_pendientes(ent):
    ent.usuario("admin", "Administrador"); ent.usuario("cajero", "Cajero")
    cli = ent.c.post("/api/clientes", json={"nombre": "Cliente Recurrente QA", "tipo_id": "01", "numero_id": "109990998", "tipo": "Cliente"}, headers=ent.h("admin")).json()
    hoy = M.ahora_cr().date().isoformat()
    r = ent.c.post("/api/recurrentes", json={"nombre": "Mensualidad QA", "cliente_id": cli["id"], "tipo_documento": "01", "periodicidad": "diaria", "inicio": hoy,
                                             "lineas": [{**LINEAS[0], "precio_unitario": 12345.67}], "observaciones": "Precio negociado QA (confidencial)"}, headers=ent.h("admin"))
    assert r.status_code == 200, r.text
    pend = ent.get("admin", "/api/recurrentes/pendientes").json()
    assert len(pend) == 1
    pid = pend[0]["id"]
    for path in ("/api/recurrentes", "/api/recurrentes/pendientes", f"/api/recurrentes/pendientes/{pid}"):
        r = ent.get("cajero", path)
        assert r.status_code == 403 and "recurrentes" in r.json()["detail"], (path, r.status_code)
    r = ent.c.post("/api/comprobantes", json={**TIQ, "pendiente_id": pid}, headers=ent.h("cajero"))
    assert r.status_code == 403 and "facturar" in r.json()["detail"]
    assert ent.emitir("cajero")["consecutivo"]                      # su venta normal sigue saliendo
    assert [p["id"] for p in ent.get("admin", "/api/recurrentes/pendientes").json()] == [pid]


# ----------------------------------------------------------------------------- comercio:14
def test_archivos_que_faltan_en_disco_dan_404_claro(ent):
    ent.usuario("admin", "Administrador")
    d = ent.emitir("admin")
    xml = M.XML_DIR / d["xml_nombre"]
    assert ent.get("admin", f"/api/comprobantes/{d['id']}/pdf").status_code == 200
    xml.unlink()
    for sufijo in ("/pdf", "/tiquete?ancho=58", "/xml"):
        r = ent.get("admin", f"/api/comprobantes/{d['id']}{sufijo}")
        assert r.status_code == 404 and "no está disponible" in r.json()["detail"], (sufijo, r.status_code, r.text[:200])
    with Session(engine_empresa(ent.e.id)) as se:
        x = se.get(Documento, d["id"]); x.respuesta_nombre = "no_existe_respuesta_g6.xml"; se.add(x); se.commit()
    r = ent.get("admin", f"/api/comprobantes/{d['id']}/respuesta")
    assert r.status_code == 404 and "respuesta" in r.json()["detail"]


# ----------------------------------------------------------------------------- extras:6, extras:8, extras:5 y extras:3
def _con_sucursal_002(ent):
    """Principal (001) con 2 tiquetes y sucursal 002 (con su bodega) con 3; vendedor y cajero amarrados a 002 y un vendedor libre."""
    ent.usuario("admin", "Administrador")
    h = ent.h("admin")
    bn = ent.c.post("/api/inventario/bodegas", json={"nombre": "Bodega Norte G6"}, headers=h).json()
    ent.get("admin", "/api/sucursales")
    s2 = ent.c.post("/api/sucursales", json={"codigo": 2, "nombre": "Norte G6", "bodega_id": bn["id"]}, headers=h).json()
    ent.usuario("vend2", "Vendedor", sucursal_id=s2["id"]); ent.usuario("caja2", "Cajero", sucursal_id=s2["id"]); ent.usuario("vendedor", "Vendedor")
    p1 = [ent.emitir("admin") for _ in range(2)]                                        # principal: 001…1 y 001…2
    p2 = [ent.emitir("admin", **{"X-Sucursal": str(s2["id"])}) for _ in range(3)]      # 002…1 a 002…3
    assert all(d["consecutivo"].startswith("001") for d in p1) and all(d["consecutivo"].startswith("002") for d in p2)
    return bn, s2, p1, p2


def test_sucursal_fija_abre_por_id_solo_lo_suyo(ent):
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    for sufijo in ("", "/pdf", "/xml", "/tiquete?ancho=80"):                           # extras:6
        assert ent.get("vend2", f"/api/comprobantes/{p1[0]['id']}{sufijo}").status_code == 404, sufijo
        assert ent.get("vend2", f"/api/comprobantes/{p2[0]['id']}{sufijo}").status_code == 200, sufijo
        assert ent.get("vendedor", f"/api/comprobantes/{p1[0]['id']}{sufijo}").status_code == 200, sufijo
    assert ent.get("vend2", f"/api/comprobantes/{p1[0]['id']}", **{"X-Sucursal": ""}).status_code == 404     # la cabecera no lo suelta
    assert ent.get("admin", f"/api/comprobantes/{p1[0]['id']}", **{"X-Sucursal": str(s2["id"])}).status_code == 200   # elegir en la barra no es un límite
    yo = ent.get("vend2", "/api/auth/yo").json()                                       # extras:3: la sesión trae la bodega de cada sucursal
    assert next(x for x in yo["sucursales"] if x["id"] == s2["id"])["bodega_id"] == bn["id"]


def test_numeracion_de_la_sucursal_activa(ent):
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    h = ent.h("admin")
    n = {x["tipo"]: x for x in ent.get("vend2", "/api/numeraciones").json()["numeraciones"]}              # extras:8
    assert n["04"]["proximo"] == "00200001040000000004" and n["04"]["emitidos"] == 3 and n["04"]["minimo"] == 3
    assert n["10"]["proximo"].startswith("001")                     # el recibo de pago (REP) sale siempre con la principal
    info = ent.get("admin", "/api/numeraciones").json()
    n = {x["tipo"]: x for x in info["numeraciones"]}
    assert info["sucursal"] == 1 and n["04"]["minimo"] == 2 and n["04"]["emitidos"] == 2 and n["04"]["proximo"].startswith("001")
    r = ent.c.put("/api/numeraciones/04", json={"ultimo": 2}, headers=h)                 # antes: 400 «no puede ser menor que 3» (el de 002)
    assert r.status_code == 200, r.text
    assert ent.c.put("/api/numeraciones/04", json={"ultimo": 1}, headers=h).status_code == 400
    r = ent.c.put("/api/numeraciones/04", json={"ultimo": 10}, headers=ent.h("admin", **{"X-Sucursal": str(s2["id"])}))
    assert r.status_code == 200 and r.json()["proximo"] == "00200001040000000011"
    assert ent.emitir("admin", **{"X-Sucursal": str(s2["id"])})["consecutivo"] == "00200001040000000011"
    assert ent.emitir("admin")["consecutivo"] == "00100001040000000003"                # la principal sigue su propia serie


def test_sucursal_desactivada_sigue_limitada_y_no_emite(ent):
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    h = ent.h("admin")
    x = dict(s2); x["activa"] = False                                                   # extras:5
    assert ent.c.put(f"/api/sucursales/{s2['id']}", json={k: x[k] for k in ("codigo", "nombre", "bodega_id", "activa")}, headers=h).status_code == 200
    pref = {d["consecutivo"][:3] for d in ent.get("vend2", "/api/comprobantes").json()}
    assert pref == {"002"}
    r = ent.c.post("/api/comprobantes", json=TIQ, headers=ent.h("caja2"))
    assert r.status_code == 403 and "desactivada" in r.json()["detail"]
    yo = ent.get("vend2", "/api/auth/yo").json()
    assert yo["sucursal_fija"] == s2["id"] and any(x["id"] == s2["id"] and x["activa"] is False for x in yo["sucursales"])
    yo_adm = ent.get("admin", "/api/auth/yo").json()
    assert not any(x["id"] == s2["id"] for x in yo_adm["sucursales"])                  # para los demás ya no se ofrece
    with Session(engine_empresa(ent.e.id)) as se:
        assert sucursales.resolver(se, ent.e.id, str(s2["id"]), None) is None           # elegida en la barra: no vale desactivada
        assert sucursales.resolver(se, ent.e.id, None, s2["id"]).id == s2["id"]         # fija: sigue mandando
    assert ent.emitir("admin")["consecutivo"].startswith("001")
    x["activa"] = True                                                                  # al reactivarla, vuelve a emitir con 002
    assert ent.c.put(f"/api/sucursales/{s2['id']}", json={k: x[k] for k in ("codigo", "nombre", "bodega_id", "activa")}, headers=h).status_code == 200
    assert ent.emitir("caja2")["consecutivo"].startswith("002")


def test_caja_y_factura_proponen_la_bodega_de_la_sucursal():
    caja = (RAIZ / "static/js/pages/pos/caja.js").read_text(encoding="utf-8")
    assert "this.cfg.bodega_id = this.bodegaDefecto();" in caja and "bodegaDefecto() {" in caja
    assert "(this.cfg && this.cfg.sucursal_id) || sesion.sucursal_id" in caja
    form = (RAIZ / "static/js/pages/ventas/factura-form.js").read_text(encoding="utf-8")
    assert "sesion.sucursalActual?.bodega_id" in form


# ----------------------------------------------------------------------------- extras:10 y servicios:5
def test_roles_de_un_solo_modulo_no_leen_ventas(ent):
    ent.usuario("admin", "Administrador")
    ent.usuario("planillas", "Planillas QA", permisos_propios=["rrhh"])
    ent.usuario("soporte", "Soporte QA", permisos_propios=["tike"])
    ent.usuario("camarera", "Camarera QA", permisos_propios=["limpieza"])
    ent.usuario("contador", "Contador")
    ent.c.post("/api/clientes", json={"nombre": "Cliente Montos QA", "tipo_id": "01", "numero_id": "109990997", "tipo": "Cliente", "limite_credito": 75000}, headers=ent.h("admin"))
    d = ent.emitir("admin")
    rutas = ("/api/comprobantes", f"/api/comprobantes/{d['id']}", f"/api/comprobantes/{d['id']}/pdf", f"/api/comprobantes/{d['id']}/tiquete", "/api/pagos",
             "/api/borradores", "/api/recurrentes", "/api/recurrentes/pendientes", "/api/registros/cotizaciones", "/api/registros/notas-credito")
    for rol in ("planillas", "soporte", "camarera"):
        for path in rutas:
            assert ent.get(rol, path).status_code == 403, (rol, path)
    assert ent.get("planillas", "/api/clientes").json() == [] and ent.get("camarera", "/api/clientes").json() == []
    cl = ent.get("soporte", "/api/clientes").json()                  # TiKe trabaja con el cliente del ticket: nombre sí, montos no
    assert cl and all("limite_credito" not in x for x in cl)
    for path in rutas[:8] + ("/api/clientes",):                      # el Contador sigue igual
        assert ent.get("contador", path).status_code == 200, path
    assert ent.get("contador", "/api/clientes").json()[0]["limite_credito"] == 75000
    # puede_leer_registro: sin ventas ni costos de proveedores; RRHH y sus módulos sí
    for permisos in ({"ver", "rrhh"}, {"ver", "tike"}, {"ver", "limpieza"}, {"ver", "seguridad"}, {"ver"}):
        assert auth.solo_modulo(permisos)
        for clave in ("cotizaciones", "remisiones", "notas-credito", "proveedor_items"):
            assert not auth.puede_leer_registro(permisos, clave), (permisos, clave)
    assert auth.puede_leer_registro({"ver", "rrhh"}, "empleados") and auth.puede_leer_registro({"ver", "limpieza"}, "hotel_habitaciones")
    for rol in ("Administrador", "Avanzado", "Contador", "Vendedor", "Cajero", "Solo lectura"):
        assert not auth.solo_modulo(auth.permisos_de_rol(None, 0, rol)), rol
    for _n, _d, permisos in auth.ROLES_POR_TIPO["hospitalidad"] + auth.ROLES_POR_TIPO["comercio"] + auth.ROLES_POR_TIPO["servicios"]:
        assert auth.solo_modulo({"ver", *permisos}) == (not ({"escribir", "facturar", "cobros", "pos"} & set(permisos))), permisos


# ----------------------------------------------------------------------------- facturacion:8
def test_contador_corrige_sus_proveedores(ent):
    ent.usuario("admin", "Administrador"); ent.usuario("contador", "Contador"); ent.usuario("vendedor", "Vendedor"); ent.usuario("lectura", "Solo lectura")
    hc = ent.h("contador")
    prov = ent.c.post("/api/clientes", json={"nombre": "Proveedor QA g6", "tipo_id": "02", "numero_id": "3101999888", "tipo": "Proveedor"}, headers=hc)
    assert prov.status_code == 200
    prov = prov.json()
    r = ent.c.put(f"/api/clientes/{prov['id']}", json={**prov, "nombre": "Proveedor QA g6 corregido"}, headers=hc)
    assert r.status_code == 200 and r.json()["nombre"] == "Proveedor QA g6 corregido"
    for tipo in ("Cliente", "Ambos"):
        assert ent.c.put(f"/api/clientes/{prov['id']}", json={**prov, "tipo": tipo}, headers=hc).status_code == 403
    assert ent.c.post("/api/clientes", json={"nombre": "Ambos QA g6", "tipo_id": "02", "numero_id": "3101999777", "tipo": "Ambos"}, headers=hc).status_code == 403
    cli = ent.c.post("/api/clientes", json={"nombre": "Cliente QA g6", "tipo_id": "01", "numero_id": "109990996", "tipo": "Cliente"}, headers=ent.h("vendedor")).json()
    assert ent.c.put(f"/api/clientes/{cli['id']}", json={**cli, "nombre": "Cambiado"}, headers=hc).status_code == 403
    assert ent.c.put(f"/api/clientes/{prov['id']}", json={**prov, "tipo": "Ambos"}, headers=ent.h("vendedor")).status_code == 200
    assert ent.c.put(f"/api/clientes/{prov['id']}", json={**prov, "nombre": "x" * 5}, headers=hc).status_code == 403     # ya es «Ambos»: también cliente
    r = ent.c.put("/api/clientes/999999", json={**prov}, headers=ent.h("lectura"))
    assert r.status_code == 403                                      # sin permiso, ni se revela si el id existe
    assert ent.c.put("/api/clientes/999999", json={**prov}, headers=hc).status_code == 404
    lista = (RAIZ / "static/js/pages/contactos/lista.js").read_text(encoding="utf-8")
    assert "tiposContacto()" in lista and "v-for=\"t in tiposContacto\"" in lista
    form = (RAIZ / "static/js/pages/contactos/form.js").read_text(encoding="utf-8")
    assert "puedeGuardar()" in form and 'v-if="puedeGuardar"' in form
