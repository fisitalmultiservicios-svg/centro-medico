# -*- coding: utf-8 -*-
"""4.25 (X2, tanda 4): dos pasos sin internet con la marca del navegador, PIN de caja, revisión de Host y Origin en el programa local
real y pantallas.

- Dos pasos sin internet: al pasar el código EN LÍNEA el programa entrega al navegador una marca firmada con su llave, atada a la
  persona, a su contraseña guardada y a la huella de sus dos pasos en la web. Sin internet entra con su contraseña solo el navegador que
  la traiga vigente (30 días desde su último ingreso en línea con código ahí); otro navegador no.
- PIN de caja: no entra quien usa dos pasos (los de la web o los de la computadora); 10 PIN malos seguidos desde cualquier conexión lo
  apagan en esta computadora hasta que la persona entre con su contraseña; con internet se pide antes la ficha a la web (un bloqueo o una
  baja valen también por PIN); sin internet el PIN sirve solo a quien tiene aquí un hash de PIN utilizable.
- Host y Origin: solo en el programa local real (FE_MODO_LOCAL=1); la red local entre computadoras sigue funcionando.

Nube y computadora corren en el mismo proceso (ver tests/test_49_local_sinc.py y tests/test_425_ingreso_programa.py)."""
import time
from pathlib import Path

import httpx
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, engine
from app.main import app
from test_49_local_sinc import NUBE, PW, H, _admin_empresa, _poner_cfg, _Respuesta, c
from test_425_ingreso_programa import (FICHA, INGRESO, _ficha, _llamadas, _miembro, _pareja, _persona, _poner, _revocada, _sesion_vieja,
                                       _sobre, _usuario)

JS = Path(sinc.__file__).parent / "static" / "js"


def _marca_de(r) -> str | None:
    """La galleta de la marca que entregó una respuesta (texto completo de Set-Cookie) o None."""
    return next((x for x in r.headers.get_list("set-cookie") if x.startswith(auth.COOKIE_MFA_AQUI + "=")), None)


def _marca(uid: int, segundos_atras: int) -> str:
    """Una marca bien firmada para `uid`, como si su último ingreso con código en ese navegador hubiera sido hace `segundos_atras`."""
    u = _usuario(uid)
    return auth.firmar({"tipo": "mfa_aqui", "c": [[uid, auth._huella_mfa_aqui(u), int(time.time()) - segundos_atras]]}, 86400)


def _con_cookie(nav, correo: str, valor: str):
    return nav.post("/api/auth/login", json={"correo": correo, "password": PW}, headers={"Cookie": f"{auth.COOKIE_MFA_AQUI}={valor}"})


def _pin(correo: str, pin: str, ip: str | None = None):
    return c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": pin}, headers={"X-Forwarded-For": ip} if ip else {})


# ------------------------------------------------------------------------------------------------------------------------- dos pasos
def test_dos_pasos_sin_internet_solo_desde_el_navegador_con_la_marca(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t1", "3101425401", "3101425402")
    secreto = auth.nuevo_secreto()
    uid, correo = _persona(eid_a, "jefa.t1", rol="Administrador", mfa_activo=True, mfa_secret=auth._cifrar_mfa(secreto))
    nav1, nav2, nav3 = TestClient(app), TestClient(app), TestClient(app)     # tres navegadores de la misma computadora
    # con internet: contraseña y código en la web; el programa entrega la marca a ESTE navegador (sin «Secure» por http)
    j = nav1.post("/api/auth/login", json={"correo": correo, "password": PW}).json()
    assert j.get("mfa_requerido") is True and auth.abrir(j["token_mfa"])["tipo"] == auth.TIPO_MFA_NUBE
    r = nav1.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": auth.codigo_totp(secreto)})
    assert r.status_code == 200, r.text
    galleta = _marca_de(r)
    assert galleta and "HttpOnly" in galleta and "Path=/api/auth" in galleta and "secure" not in galleta.lower(), galleta
    assert "samesite=strict" in galleta.lower()
    datos = auth.abrir(nav1.cookies.get(auth.COOKIE_MFA_AQUI))
    assert datos["tipo"] == "mfa_aqui" and datos["c"][-1][0] == uid and _usuario(uid).mfa_nube
    assert secreto not in str(datos) and PW not in str(datos)                # ni el secreto ni la contraseña van en la marca
    # sin internet: el navegador con la marca entra; otro navegador (sin marca), con el mismo usuario y contraseña, no
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    r = nav1.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True, r.text
    r = nav2.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_INTERNET_MFA and "token" not in r.json(), r.text
    assert nav1.post("/api/auth/login", json={"correo": correo, "password": "Clave-Mala-t1-2026"}).status_code == 401   # la marca no salta la contraseña
    # marca vencida (más de 30 días desde el último ingreso en línea con código en ese navegador) no entra; una de 29 días sí
    assert _con_cookie(nav3, correo, _marca(uid, 31 * 86400)).status_code == 403
    assert _con_cookie(nav3, correo, _marca(uid, 29 * 86400)).status_code == 200
    # marca de otra persona, o firmada con otra llave, no sirve
    uid2, _ = _persona(eid_a, "otra.t1")
    assert _con_cookie(nav3, correo, _marca(uid2, 60)).status_code == 403
    assert _con_cookie(nav3, correo, _marca(uid, 60)[:-3] + "AAA").status_code == 403
    # cambia la huella de sus dos pasos en la web (otro teléfono): la marca deja de servir; con la misma huella vuelve a servir
    huella = _usuario(uid).mfa_nube
    _poner(uid, mfa_nube="otra-huella-t1")
    assert nav1.post("/api/auth/login", json={"correo": correo, "password": PW}).status_code == 403
    _poner(uid, mfa_nube=huella)
    assert nav1.post("/api/auth/login", json={"correo": correo, "password": PW}).status_code == 200
    # cambia la contraseña guardada (otro hash, aunque sea el mismo texto): la marca deja de servir
    _poner(uid, password_hash=auth.hash_password(PW))
    r = nav1.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_INTERNET_MFA


def test_la_marca_solo_la_entrega_el_codigo_en_linea(monkeypatch):
    """Un ingreso en línea sin código (persona sin dos pasos) o con lo guardado no entrega marca; en la web no existe."""
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t2", "3101425403", "3101425404")
    _, correo = _persona(eid_a, "cajero.t2", local=eid_b)
    nav = TestClient(app)
    r = nav.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 200 and _marca_de(r) is None
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    r = nav.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True and _marca_de(r) is None
    u = _usuario(_persona(0, "sin-dos-pasos.t2")[0])
    resp = type("R", (), {"set_cookie": lambda *a, **k: (_ for _ in ()).throw(AssertionError("no debe marcar"))})()
    auth.marcar_mfa_aqui(None, resp, u)                                      # sin mfa_nube: nada
    assert auth.mfa_aqui_vigente(None, u) is False


# ------------------------------------------------------------------------------------------------------------------------- PIN de caja
def test_pin_con_dos_pasos_de_la_web_o_de_aqui_no_entra(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t3", "3101425405", "3101425406")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "cajera.t3", local=eid_b, pin_hash=pin)
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, mfa="huella-t3", mfa_entrar=True)))
    r = _pin(correo, "4827")
    assert r.status_code == 403 and "solo para usuarios de caja" in r.json()["detail"] and "token" not in r.json(), r.text
    assert _usuario(uid).mfa_nube == "huella-t3" and _llamadas(shim, FICHA) == 1 and shim.llamadas[-1][2] == {"correo": correo}   # el PIN no viaja
    # la web le exige los dos pasos (aunque no los tenga): tampoco
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, mfa="", mfa_entrar=True)))
    assert _pin(correo, "4827").status_code == 403
    # sin dos pasos en la web: entra
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin)))
    r = _pin(correo, "4827")
    assert r.status_code == 200 and r.json().get("token"), r.text
    # una cuenta creada en esta computadora con sus dos pasos de aquí: tampoco (y no se le pide nada a la web)
    _, correo2 = _persona(0, "cajero-local.t3", local=eid_b, de_nube=False, pin_hash=pin, mfa_activo=True)
    antes = len(shim.llamadas)
    assert _pin(correo2, "4827").status_code == 403 and len(shim.llamadas) == antes


def test_diez_fallos_de_pin_desde_tres_direcciones_lo_apagan_y_la_contrasena_lo_enciende(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t4", "3101425407", "3101425408")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")                           # cada petición con su dirección (X-Forwarded-For)
    shim.por_ruta[FICHA] = httpx.ConnectError("sin red")                    # sin internet: vale lo guardado
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    uid, correo = _persona(eid_a, "cajero.t4", local=eid_b, pin_hash=auth.hash_password("4827"))
    # los fallos seguidos se cuentan por cuenta; un acierto los borra
    for _ in range(3):
        assert _pin(correo, "1111", "10.0.0.1").status_code == 401
    assert _pin(correo, "4827", "10.0.0.1").status_code == 200 and _usuario(uid).pin_fallos == 0
    # 10 fallos repartidos en tres direcciones (ninguna llega a su espera de 5): el PIN queda apagado en esta computadora
    for ip, n in (("10.0.0.2", 4), ("10.0.0.3", 3), ("10.0.0.4", 3)):
        for _ in range(n):
            r = _pin(correo, "1111", ip)
            assert r.status_code == 401, (ip, r.text)
    assert _usuario(uid).pin_fallos == auth.PIN_MAX_FALLOS
    r = _pin(correo, "4827", "10.0.0.5")                                    # el PIN bueno, desde otra dirección: no entra
    assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_PIN_APAGADO and "token" not in r.json()
    assert _pin(correo, "1111", "10.0.0.6").status_code == 403 and _usuario(uid).pin_fallos == auth.PIN_MAX_FALLOS   # ya no cuenta ni compara
    with Session(engine) as sc:
        a = sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login_fallido").order_by(Auditoria.id.desc())).first()
        assert "apagado" in a.detalle and "1111" not in (a.detalle or "")
    # entra con su contraseña (sin internet, con lo guardado): el PIN vuelve a servir
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW}, headers={"X-Forwarded-For": "10.0.0.5"})
    assert r.status_code == 200, r.text
    assert _usuario(uid).pin_fallos == 0
    assert _pin(correo, "4827", "10.0.0.5").status_code == 200


def test_pin_de_persona_bloqueada_o_dada_de_baja_en_la_web_no_entra_con_internet(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t5", "3101425409", "3101425410")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "cajero.t5", local=eid_b, pin_hash=pin)
    _sesion_vieja(uid, "sid-t5")
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, bloqueado=True)))
    r = _pin(correo, "4827")
    assert r.status_code == 403 and "bloqueada" in r.json()["detail"] and "token" not in r.json(), r.text
    assert _usuario(uid).bloqueado and _revocada("sid-t5")
    # dado de baja de la empresa en la web: se quita su membresía aquí y no entra
    uid2, correo2 = _persona(0, "retirada.t5", local=eid_b, pin_hash=pin)      # aquí solo es miembro de la empresa de la computadora
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=False, usuario=None))
    assert _pin(correo2, "4827").status_code == 403
    assert not _miembro(uid2, eid_b)
    # la web le cambió el PIN: el viejo ya no entra (y es un fallo); el nuevo sí
    uid3, correo3 = _persona(eid_a, "cajera.t5", local=eid_b, pin_hash=pin)
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid3, pin_hash=auth.hash_password("5938"))))
    assert _pin(correo3, "4827").status_code == 401
    assert _pin(correo3, "5938").status_code == 200
    # sin internet: el PIN sirve solo a quien tiene aquí un hash de PIN utilizable
    shim.por_ruta[FICHA] = httpx.ConnectError("sin red")
    assert _pin(correo3, "5938").status_code == 200
    _, correo4 = _persona(eid_a, "nueva.t5", local=eid_b, pin_hash=sinc.HASH_INSERVIBLE)
    r = _pin(correo4, "4827")
    assert r.status_code == 403 and "activar su PIN aquí" in r.json()["detail"]
    # una computadora conectada a otra dirección no pide fichas (y sigue con lo guardado)
    monkeypatch.setattr(sinc, "URL_NUBE", "https://fisitaap.com")
    antes = _llamadas(shim, FICHA)
    assert _pin(correo3, "5938").status_code == 200 and _llamadas(shim, FICHA) == antes


# ------------------------------------------------------------------------------------------------------------------------- Host y Origin
def test_host_y_origin_solo_en_el_programa_local_real(monkeypatch):
    lan = TestClient(app, client=("192.168.1.50", 50000))                   # una conexión de verdad (con su IP)
    monkeypatch.setattr(sinc, "_direcciones", lambda: ["http://192.168.1.10:8020"])
    # en la web nada de esto aplica
    assert lan.get("/api/auth/estado", headers={"Host": "pagina-ajena.example"}).status_code == 200
    assert lan.get("/api/auth/estado", headers={"Host": "127.0.0.1:8020", "Origin": "https://pagina-ajena.example"}).status_code == 200
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    # 4b (Q9): cualquier IP literal vale (un cambio de DNS llega con el NOMBRE del atacante; una IP escrita no se redirige)
    for host in ("127.0.0.1:8020", "localhost:8020", "[::1]:8020", "192.168.1.10:8020", "LOCALHOST", "192.168.1.99:8020"):
        r = lan.get("/api/auth/estado", headers={"Host": host})
        assert r.status_code == 200, (host, r.text)
    for host in ("pagina-ajena.example", "127.0.0.1.pagina-ajena.example:8020", "", "usuario@127.0.0.1"):
        r = lan.get("/api/auth/estado", headers={"Host": host})
        assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST, (host, r.text)
    # el ingreso con un Host ajeno no llega a la ruta (no reenvía contraseñas a la web ni cuenta intentos)
    r = lan.post("/api/auth/login", headers={"Host": "pagina-ajena.example"}, json={"correo": "x@example.test", "password": "y"})
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST
    # Origin: si viene, tiene que ser el mismo servidor del Host; sin Origin pasa
    base = {"Host": "127.0.0.1:8020"}
    assert lan.get("/api/auth/estado", headers={**base, "Origin": "http://127.0.0.1:8020"}).status_code == 200
    assert lan.get("/api/auth/estado", headers={"Host": "localhost", "Origin": "http://localhost"}).status_code == 200
    for origen in ("https://pagina-ajena.example", "http://127.0.0.1:9800", "http://localhost:8020", "https://127.0.0.1:8020", "null", ""):
        r = lan.post("/api/auth/login", headers={**base, "Origin": origen}, json={"correo": "x@example.test", "password": "y"})
        assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_ORIGEN, (origen, r.text)


def test_la_red_local_sigue_funcionando_con_la_revision(monkeypatch):
    eid, t = _admin_empresa("-t7", "3101425413")
    _poner_cfg(eid, red={"clave_hash": sinc._hash("red-qa-t7-425")})
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(sinc, "_direcciones", lambda: ["http://192.168.1.10:8020"])
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    otra_pc = TestClient(app, client=("192.168.1.20", 51000))               # otra computadora del local: httpx, sin Origin
    cab = {"Host": "192.168.1.10:8020", "X-Clave-Red": "red-qa-t7-425"}
    r = otra_pc.get("/api/sinc/red/3101425413/ping", headers=cab)
    assert r.status_code == 200 and r.json()["ok"] is True, r.text
    r = otra_pc.post("/api/sinc/red/3101425413/cambios", headers=cab, json={"terminal": 9, "nombre": "PC QA", "registros": {}})
    assert r.status_code == 200, r.text
    r = otra_pc.get("/api/sinc/red/3101425413/ping", headers={**cab, "Host": "otra-pc-ajena:8020"})
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST


# ------------------------------------------------------------------------------------------------------------------------- pantallas
def test_estado_del_ingreso_en_el_programa(monkeypatch):
    estado = c.get("/api/auth/estado").json()
    assert "sin_internet_desde" not in estado and "pagina_web" not in estado        # en la web no cambia nada
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t8", "3101425414", "3101425415")
    _poner_cfg(eid_b, sin_conexion_desde="2000-01-01T00:00:00+00:00")
    estado = c.get("/api/auth/estado").json()
    assert estado["sin_internet_desde"] == "2000-01-01T00:00:00+00:00" and estado["pagina_web"] == NUBE
    _poner_cfg(eid_b, sin_conexion_desde=None)
    assert c.get("/api/auth/estado").json().get("sin_internet_desde") != "2000-01-01T00:00:00+00:00"
    # la sesión de quien la web le exige los dos pasos y no los tiene: la pantalla le pide activarlos en la web
    uid, correo = _persona(eid_a, "admin.t8", rol="Administrador", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=_ficha(uid, rol="Administrador")))
    u = c.post("/api/auth/login", json={"correo": correo, "password": PW}).json()["usuario"]
    assert u["dos_pasos_falta"] is False and u["dos_pasos_en_web"] is False
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=_ficha(uid, rol="Administrador", mfa_entrar=True)))
    t = c.post("/api/auth/login", json={"correo": correo, "password": PW}).json()["token"]
    u = c.get("/api/auth/yo", headers=H(t)).json()["usuario"]
    assert u["dos_pasos_falta"] is True and u["dos_pasos_en_web"] is True and u["mfa_obligatorio"] is False


def test_pantallas_del_ingreso_del_programa():
    lg = (JS / "pages" / "login.js").read_text(encoding="utf-8")
    assert "Sin internet: entra con lo guardado en esta computadora." in lg and 'v-if="!setup && sinInternet"' in lg
    assert ":href=\"paginaWeb + '/app/'\" target=\"_blank\" rel=\"noopener\"" in lg                 # en el programa, «¿Olvidó…?» abre la web
    assert lg.count("¿Olvidó su contraseña?") == 2 and "@click=\"modo='recuperar'\">¿Olvidó su contraseña?" in lg   # en la web, lo de siempre
    assert "if (r.aviso_ingreso) toast(r.aviso_ingreso);" in lg and "catch (e) { toast(e.message, 'err');" in lg   # los rechazos tal como llegan
    assert "Un servicio de" in lg
    a = (JS / "app.js").read_text(encoding="utf-8")
    assert 'v-if="sesion.usuario?.sin_nube"><b>Entró sin internet:</b>' in a
    assert 'v-if="store.avisoLocal?.usuarios_atrasados"><b>Los usuarios de esta computadora no se están actualizando.</b>' in a
    i = a.index('<ActivarMfaWeb v-else-if="pantalla===\'mfa\' && sesion.usuario?.dos_pasos_en_web"></ActivarMfaWeb>')
    assert i < a.index('<ActivarMfa v-else-if="pantalla===\'mfa\'"></ActivarMfa>')
    assert "Active la verificación en dos pasos en la página web" in a and "ActivarMfa, ActivarMfaWeb," in a
    assert "if (sesion.mfaPendiente) return 'mfa';\n      if (sesion.usuario?.dos_pasos_falta) return 'mfa';" in a
    # las franjas del programa que revisa tests/test_49_local_sinc.py siguen intactas
    assert 'v-if="sesion.empresaInfo?.instalacion"><b>Esta instalación fue revocada en la nube.' in a
    assert 'v-if="sesion.empresaInfo?.sin_acceso_nube && !sesion.empresaInfo?.instalacion"><b>Sin acceso a la nube.' in a
