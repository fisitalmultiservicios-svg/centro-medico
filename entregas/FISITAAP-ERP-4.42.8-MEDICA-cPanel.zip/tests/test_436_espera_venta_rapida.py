# -*- coding: utf-8 -*-
"""4.36, soporte de un restaurante (14 nov 2026): «los pedidos guardados no se ven en modo venta rápida»; «así salen en mesas pero en
venta rápida no sale» (con la foto del botón «Para llevar en espera (1)»). En la caja de restaurante el botón que abre «Cuentas en
espera» solo estaba en el plano de mesas: quien trabaja en venta rápida no encontraba el pedido guardado. Arreglo mínimo: el mismo
botón en la pantalla de la venta rápida. No cambia cómo se guardan las cuentas ni nada del cobro."""
import json
import shutil
import subprocess

import pytest

from tests.test_425_ultimos_pantallas import JS, _js, _nodo, _tramo


def _venta():
    """La pantalla de venta de caja.js: de su comentario al comienzo de la ventana de pedidos web."""
    return _tramo(_js("pages/pos/caja.js"), "<!-- pantalla de venta -->", '<div class="pos-der"')


def test_el_boton_sale_en_la_venta_rapida_y_abre_las_cuentas_en_espera():
    v = _venta()
    # solo en la caja de restaurante: la de mostrador ya tiene su botón «En espera» (ahí «rapida» también vale y saldría repetido)
    assert ('<button class="btn sm ghost" v-if="esRestaurante && esVentaRapida && esperaRapida.length" @click="modalEspera=true" data-espera-rapida '
            'title="Cuentas guardadas sin mesa: tóquelo para recuperar una y cobrarla">Para llevar en espera ({{esperaRapida.length}})</button>') in v
    assert v.count("data-espera-rapida") == 1
    # va en la barra de arriba, justo después de «Mesas / Venta rápida»
    assert v.index("⚡ Venta rápida</button></span>") < v.index("data-espera-rapida") < v.index("data-pedidos-web")


def test_el_plano_de_mesas_queda_como_estaba():
    t = _js("pages/pos/caja.js")
    assert '<button class="btn sm ghost" @click="modalEspera=true" v-if="esperaSinMesa.length">Para llevar en espera ({{esperaSinMesa.length}})</button>' in t
    assert t.count("Para llevar en espera ({{") == 2                      # el del plano y el de la venta rápida, ninguno más
    assert "esperaSinMesa() { return this.esperaCaja.filter(v => !v.mesa_id); }," in t


def test_el_contador_no_cuenta_la_cuenta_abierta_ni_las_de_mesa_ni_las_de_otra_caja(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    t = _js("pages/pos/caja.js")
    partes = {}
    for nombre in ("esperaCaja", "esperaSinMesa", "esperaRapida", "esVentaRapida"):
        cuerpo = _tramo(t, "    " + nombre + "() {", "\n")
        assert cuerpo.startswith("    " + nombre + "() {"), nombre
        partes[nombre] = cuerpo.split("//")[0].split("/*")[0].strip().rstrip(",")
    guion = "const C = {\n" + ",\n".join("  get " + p for p in partes.values()) + """
};
function caja(estado) { return Object.create(C, Object.getOwnPropertyDescriptors(estado)); }
const espera = [
  { id: 1, nombre: 'Cuenta 1', terminal_id: 1 },                 // sin mesa, de esta caja
  { id: 2, nombre: 'Mesa 4', terminal_id: 1, mesa_id: 4 },       // de una mesa
  { id: 3, nombre: 'Cuenta 3', terminal_id: 2 },                 // de otra caja
  { id: 4, nombre: 'Juan', terminal_id: 1, pedido: 'llevar' },   // para llevar, de esta caja
  { id: 5, nombre: 'Vieja' },                                    // sin caja guardada: vale para la caja actual
];
const base = { cfg: { id: 1 }, espera, vista: 'venta', mesaActual: null, rapida: true, esperaId: null };
const o = {
  vacia: caja(base).esperaRapida.map(v => v.id),
  abierta: caja({ ...base, esperaId: 4 }).esperaRapida.map(v => v.id),
  sin_guardadas: caja({ ...base, espera: [espera[1], espera[2]] }).esperaRapida.length,
  rapida: caja(base).esVentaRapida,
  en_mesa: caja({ ...base, mesaActual: { id: 4 } }).esVentaRapida,
  en_plano: caja({ ...base, vista: 'mesas' }).esVentaRapida,
  sin_mesa_no_rapida: caja({ ...base, rapida: false }).esVentaRapida,
};
console.log(JSON.stringify(o));
"""
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-2000:]
    o = json.loads(r.stdout)
    assert o["vacia"] == [1, 4, 5]                 # ni la de mesa ni la de la otra caja
    assert o["abierta"] == [1, 5]                  # sin la que está abierta en pantalla
    assert o["sin_guardadas"] == 0                 # con 0 el botón no sale
    assert o["rapida"] is True and o["en_mesa"] is False and o["en_plano"] is False and o["sin_mesa_no_rapida"] is False


def test_recuperar_sigue_preguntando_antes_de_reemplazar_el_carrito():
    t = _js("pages/pos/caja.js")
    r = _tramo(t, "    recuperar(v) {", "\n    },")
    assert "if (this.lineas.length && !confirm('El carrito actual se reemplaza por «' + v.nombre + '». ¿Continuar?')) return;" in r
    assert "this.modalEspera = false; this.vista = 'venta';" in r


def test_caja_compila_y_no_mezcla_finales_de_linea(tmp_path):
    from tests.test_424_etiquetas import COMPILAR_JS
    node = _nodo()
    b = (JS / "pages/pos/caja.js").read_bytes()
    assert b.count(b"\r\n") in (0, b.count(b"\n"))
    if not node:
        pytest.skip("sin Node.js en este equipo")
    copia = tmp_path / "caja.mjs"
    copia.write_bytes(b)
    r = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-2000:]
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    (tmp_path / "pages_pos_caja.js").write_bytes(b)
    r = subprocess.run([node, "compilar.mjs", "pages_pos_caja.js"], capture_output=True, text=True, encoding="utf-8", timeout=180, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    assert o["pages_pos_caja.js"]
    for p in o["pages_pos_caja.js"]:
        assert p["errores"] == [] and p["desbalance"] == [], p
