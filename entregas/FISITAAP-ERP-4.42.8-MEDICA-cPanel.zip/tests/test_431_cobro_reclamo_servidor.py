# -*- coding: utf-8 -*-
"""4.31 (la misma mesa, tercera vuelta): el cobro de una cuenta de la caja se pide al servidor antes de emitir (app/cobro_reclamo.py).

- Dos pedidos a la vez sobre la misma cuenta (hilos con dos sesiones y dos motores sobre el mismo archivo, como dos procesos): gana uno.
- Un pedido vencido (60 s) se puede volver a pedir; soltar con otra clave no suelta; la misma pestaña no espera a su cobro anterior.
- Lo cobrado queda anotado: un equipo atrasado que llega después con esos platos no gana; «sigue» anota sin soltar.
- `cobros`: si otro equipo cobró una parte desde que se armó esta, «cambiada».
- Rutas reales: datos que faltan (400), sin sesión (401), sin el permiso de la caja (403) y con el plan vencido; la tabla y su índice;
  main.py la registra en una línea; no viaja (sinc no la nombra).
Todo con cuentas @example.test y bases temporales."""
import inspect
import pathlib
import threading
from datetime import datetime, timedelta

import pytest
from sqlalchemy import text
from sqlmodel import Session

from app import cobro_reclamo as cr, config, db, modulos, planes, sinc
from app.db import engine_empresa
from tests.test_387_r4_caja import Entorno

RAIZ = pathlib.Path(__file__).resolve().parents[1] / "app"
T0 = datetime(2026, 11, 12, 15, 0, 0, tzinfo=config.TZ_CR)
EQ_A, EQ_B, EQ_C = "eA0000000000000001", "eB0000000000000002", "eC0000000000000003"


@pytest.fixture()
def rest():
    x = Entorno("restaurante")
    x.usuario("admin", "Administrador")
    try:
        yield x
    finally:
        x.limpiar()


def _reloj(monkeypatch, t=T0):
    R = {"t": t}
    monkeypatch.setattr(cr, "ahora_cr", lambda: R["t"])
    return R


def _rec(eid, cuenta, equipo, clave, lids, cobros=None, restos=None, pares=None):
    with Session(engine_empresa(eid)) as s:
        return cr.reclamar(s, eid, cuenta, equipo, clave, lids, cobros, restos, pares=pares)


def _soltar(eid, cuenta, clave, cobrado=False, lids=(), sigue=False):
    with Session(engine_empresa(eid)) as s:
        return cr.soltar(s, eid, cuenta, clave, cobrado, list(lids), sigue)


def _fila(eid, cuenta):
    with Session(engine_empresa(eid)) as s:
        return cr._fila(s, eid, cuenta)


def _borrar_filas(eid):
    with Session(engine_empresa(eid)) as s:
        s.execute(text("DELETE FROM cobro_reclamo WHERE empresa_id = :e"), {"e": eid}); s.commit()


# ================================================================================================================ dos a la vez
def test_dos_pedidos_a_la_vez_gana_uno(rest):
    eid = rest.eid
    engine_empresa(eid)
    otro = db._nuevo_engine(f"sqlite:///{db.EMPRESAS_DIR / f'empresa_{eid}.db'}")
    try:
        for vuelta in range(20):
            _borrar_filas(eid)
            barrera, out, errores = threading.Barrier(2), [None, None], []

            def trabajar(i):
                try:
                    with Session(otro if i else engine_empresa(eid)) as s:     # dos motores sobre el mismo archivo: como dos procesos
                        barrera.wait()
                        out[i] = cr.reclamar(s, eid, 7, (EQ_A, EQ_B)[i], f"clave{i}{vuelta:04d}x", ["lC", "lL"])
                except Exception as ex:  # noqa: BLE001
                    errores.append(repr(ex))
            hilos = [threading.Thread(target=trabajar, args=(i,)) for i in range(2)]
            for h in hilos:
                h.start()
            for h in hilos:
                h.join(60)
            assert not errores, errores
            assert sorted(r["resultado"] for r in out) == ["ganada", "ocupada"], out
            perdio = next(r for r in out if r["resultado"] == "ocupada")
            assert perdio["comunes"] == ["lC", "lL"], out                   # lo que el otro tiene: la pantalla no lo devuelve a la cuenta
            f = _fila(eid, 7)
            assert f["estado"] == "reclamada" and f["equipo"] == (EQ_A, EQ_B)[[r["resultado"] for r in out].index("ganada")], f
    finally:
        otro.dispose()


def test_otra_cuenta_no_se_bloquea_y_el_error_no_gana(rest):
    eid = rest.eid
    assert _rec(eid, 7, EQ_A, "claveA0001", ["lC"])["resultado"] == "ganada"
    assert _rec(eid, 8, EQ_B, "claveB0001", ["lC"])["resultado"] == "ganada"          # otra mesa: cada cuenta lo suyo

    class Rota:
        def execute(self, *a, **k):
            raise RuntimeError("database is locked")

        def rollback(self):
            pass
    assert cr.reclamar(Rota(), eid, 9, EQ_A, "claveA0002", ["lX"]) == {"resultado": "ocupada", "vence": "", "comunes": []}   # ante un error, no se emite
    assert cr.soltar(Rota(), eid, 9, "claveA0002", True, ["lX"]) == {"resultado": "no_era_suya"}                       # nunca lanza


# ================================================================================================================ vence, soltar ajeno, misma pestaña
def test_vencido_se_puede_volver_a_pedir_y_soltar_ajeno_no_suelta(rest, monkeypatch):
    eid = rest.eid
    R = _reloj(monkeypatch)
    a = _rec(eid, 7, EQ_A, "claveA0001", ["lC"])
    assert a == {"resultado": "ganada", "vence": (T0 + timedelta(seconds=60)).isoformat(timespec="seconds")}, a
    R["t"] = T0 + timedelta(seconds=30)
    assert _rec(eid, 7, EQ_B, "claveB0001", ["lC"])["resultado"] == "ocupada"
    # soltar con otra clave (otra pestaña, o un cobro viejo) no suelta: B sigue sin poder
    assert _soltar(eid, 7, "claveB0001") == {"resultado": "no_era_suya"}
    assert _soltar(eid, 7, "claveZ9999", cobrado=False) == {"resultado": "no_era_suya"}
    assert _rec(eid, 7, EQ_B, "claveB0002", ["lC"])["resultado"] == "ocupada"
    # vencido (la pestaña de A se cerró a medias): B lo toma
    R["t"] = T0 + timedelta(seconds=61)
    assert _rec(eid, 7, EQ_B, "claveB0003", ["lC"])["resultado"] == "ganada"
    # el soltar tardío de A ya no suelta el de B
    assert _soltar(eid, 7, "claveA0001") == {"resultado": "no_era_suya"}
    assert _rec(eid, 7, EQ_C, "claveC0001", ["lC"])["resultado"] == "ocupada"
    # B suelta (no cobró): queda libre y C lo toma
    assert _soltar(eid, 7, "claveB0003") == {"resultado": "ok"}
    assert _fila(eid, 7)["estado"] == "libre"
    assert _rec(eid, 7, EQ_C, "claveC0002", ["lC"])["resultado"] == "ganada"


def test_la_misma_pestana_no_espera_a_su_cobro_anterior(rest, monkeypatch):
    """Una sola caja que cobra la parte 1 y enseguida la parte 2: el soltar de la parte 1 todavía no llegó y la parte 2 se pide igual."""
    eid = rest.eid
    _reloj(monkeypatch)
    assert _rec(eid, 7, EQ_A, "parte1aaaa", ["lC", "lL"])["resultado"] == "ganada"
    assert _rec(eid, 7, EQ_A, "parte2aaaa", ["lC~r", "lL~r"])["resultado"] == "ganada"
    # el soltar de la parte 1 llega después: anota lo cobrado pero no suelta el de la parte 2
    assert _soltar(eid, 7, "parte1aaaa", cobrado=True, lids=["lC", "lL"]) == {"resultado": "no_era_suya"}
    f = _fila(eid, 7)
    assert f["estado"] == "reclamada" and f["clave"] == "parte2aaaa" and f["cobradas"] == ["lC", "lL"], f
    assert _rec(eid, 7, EQ_B, "claveB0001", ["lC~r"])["resultado"] == "ocupada"


# ================================================================================================================ lo cobrado y los cobros
def test_lo_cobrado_queda_anotado_y_el_atrasado_no_gana(rest, monkeypatch):
    eid = rest.eid
    R = _reloj(monkeypatch)
    assert _rec(eid, 7, EQ_A, "claveA0001", ["lC", "lL"])["resultado"] == "ganada"
    # ya emitió: anota lo cobrado y sigue pedido (los pagos y Bancos todavía corren)
    assert _soltar(eid, 7, "claveA0001", cobrado=True, lids=["lC", "lL"], sigue=True) == {"resultado": "ok"}
    f = _fila(eid, 7)
    assert f["estado"] == "reclamada" and f["cobradas"] == ["lC", "lL"] and f["lids"] == ["lC", "lL"], f
    R["t"] = T0 + timedelta(seconds=50)
    assert _soltar(eid, 7, "claveA0001", cobrado=True, lids=["lC", "lL"], sigue=True) == {"resultado": "ok"}   # «sigue» alarga el pedido
    R["t"] = T0 + timedelta(seconds=100)
    assert _rec(eid, 7, EQ_B, "claveB0001", ["lP"])["resultado"] == "ocupada"
    assert _soltar(eid, 7, "claveA0001", cobrado=True, lids=["lC", "lL"]) == {"resultado": "ok"}
    f = _fila(eid, 7)
    assert f["estado"] == "libre" and f["cobradas"] == ["lC", "lL"] and f["lids"] == [], f
    # B, atrasado un segundo, cobra con la Limonada que A ya cobró: no gana (y no queda pedido)
    r = _rec(eid, 7, EQ_B, "claveB0002", ["lL", "lP"])
    assert r == {"resultado": "cobrada", "comunes": ["lL"]}, r
    assert _fila(eid, 7)["estado"] == "libre"
    # lo que A no cobró (un plato agregado después) sí se cobra
    assert _rec(eid, 7, EQ_B, "claveB0003", ["lP"])["resultado"] == "ganada"
    # el soltar de un cobro cuyo pedido no llegó al servidor igual anota lo cobrado
    assert _soltar(eid, 8, "claveA0009", cobrado=True, lids=["lX"]) == {"resultado": "no_era_suya"}
    assert _rec(eid, 8, EQ_B, "claveB0009", ["lX"])["resultado"] == "cobrada"
    assert _soltar(eid, 10, "claveA0010", cobrado=False) == {"resultado": "no_era_suya"} and _fila(eid, 10) is None


def test_otro_equipo_cobro_una_parte_desde_que_se_armo_esta(rest, monkeypatch):
    x = rest
    eid = x.eid
    _reloj(monkeypatch)
    cuenta = {"id": 7, "nombre": "Mesa 7", "mesa_id": 7, "terminal_id": 1, "lineas": [{"lid": "lC~1", "producto_id": 1, "detalle": "Casado", "cantidad": 1}],
              "cobros": [{"doc_id": 1, "consecutivo": "T1", "monto": 1977.5}], "partes": {"total": 2, "cobradas": 1}, "total": 1977.5}
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [cuenta], [], [7])
        s.commit()
    r = _rec(eid, 7, EQ_B, "claveB0001", ["lC~1"], cobros=0)          # B armó su parte cuando la cuenta no tenía cobros
    assert r == {"resultado": "cambiada", "comunes": []}, r
    assert _fila(eid, 7) is None                                        # no quedó pedido
    assert _rec(eid, 7, EQ_B, "claveB0002", ["lC~1"], cobros=1)["resultado"] == "ganada"
    assert _soltar(eid, 7, "claveB0002") == {"resultado": "ok"}
    assert _rec(eid, 99, EQ_B, "claveB0003", ["lZ"], cobros=0)["resultado"] == "ganada"   # cuenta que el servidor no tiene: no se compara


def test_limpieza_borra_lo_viejo_libre(rest, monkeypatch):
    eid = rest.eid
    R = _reloj(monkeypatch)
    assert _rec(eid, 7, EQ_A, "claveA0001", ["lC"])["resultado"] == "ganada"
    assert _soltar(eid, 7, "claveA0001", cobrado=True, lids=["lC"])["resultado"] == "ok"
    assert _rec(eid, 8, EQ_A, "claveA0002", ["lC"])["resultado"] == "ganada"
    R["t"] = T0 + timedelta(days=3)
    assert _rec(eid, 9, EQ_A, "claveA0003", ["lC"])["resultado"] == "ganada"
    with Session(engine_empresa(eid)) as s:
        assert cr.limpiar(s, eid, forzar=True) == 2                         # la libre y la vencida de hace 3 días; la de ahora no
    assert _fila(eid, 7) is None and _fila(eid, 8) is None and _fila(eid, 9)["estado"] == "reclamada"


# ================================================================================================================ rutas
def test_rutas_reales(rest, monkeypatch):
    x = rest
    h = x.h("admin")
    _reloj(monkeypatch)
    ok = {"cuenta_id": 7, "equipo": EQ_A, "clave": "claveA0001", "lids": ["lC", "lL"]}
    for malo in ({}, {**ok, "cuenta_id": True}, {**ok, "cuenta_id": "7"}, {**ok, "cuenta_id": 0}, {**ok, "equipo": "corto"}, {**ok, "equipo": "con espacios 123"},
                 {**ok, "clave": None}, {**ok, "lids": "lC"}, {**ok, "lids": [1]}, {**ok, "lids": ["x"] * 301}, {**ok, "cobros": -1}, {**ok, "cobros": True}):
        r = x.c.post("/api/pos/cobro/reclamar", json=malo, headers=h)
        assert r.status_code == 400 and isinstance(r.json()["detail"], str), (malo, r.text)
    r = x.c.post("/api/pos/cobro/reclamar", json=ok, headers=h)
    assert r.status_code == 200 and r.json()["resultado"] == "ganada", r.text
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "equipo": EQ_B, "clave": "claveB0001", "lids": ["lL"]}, headers=h)
    assert r.json() == {"resultado": "ocupada", "vence": (T0 + timedelta(seconds=60)).isoformat(timespec="seconds"), "comunes": ["lL"]}, r.text
    assert x.c.post("/api/pos/cobro/soltar", json={"cuenta_id": 7, "clave": "claveB0001"}, headers=h).json() == {"resultado": "no_era_suya"}
    assert x.c.post("/api/pos/cobro/soltar", json={"cuenta_id": 7}, headers=h).status_code == 400
    r = x.c.post("/api/pos/cobro/soltar", json={"cuenta_id": 7, "clave": "claveA0001", "cobrado": True, "lids": ["lC", "lL"]}, headers=h)
    assert r.json() == {"resultado": "ok"}, r.text
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "equipo": EQ_B, "clave": "claveB0002", "lids": ["lL"]}, headers=h)
    assert r.json() == {"resultado": "cobrada", "comunes": ["lL"]}, r.text
    # «cobrado» que no es true no anota nada
    assert x.c.post("/api/pos/cobro/reclamar", json={"cuenta_id": 8, "equipo": EQ_A, "clave": "claveA0002", "lids": ["lP"]}, headers=h).json()["resultado"] == "ganada"
    x.c.post("/api/pos/cobro/soltar", json={"cuenta_id": 8, "clave": "claveA0002", "cobrado": "si", "lids": ["lP"]}, headers=h)
    assert _fila(x.eid, 8)["cobradas"] == []


def test_permisos_y_plan_vencido():
    from tests.test_387_registros import H, _borrar, _empresa, c as cli
    usuarios = {"Administrador": "admin.cobro431@example.test", "Cajero": "cajero.cobro431@example.test", "Bodega": "bodega.cobro431@example.test"}
    eid, tok = _empresa("Cobro 431 QA", "restaurante", {"Bodega": ["inventario"]}, usuarios, "c431")
    try:
        rutas = (("/api/pos/cobro/reclamar", {"cuenta_id": 1, "equipo": EQ_A, "clave": "claveA0001", "lids": ["lC"]}), ("/api/pos/cobro/soltar", {"cuenta_id": 1, "clave": "claveA0001"}))
        for url, js in rutas:
            assert cli.post(url, json=js).status_code == 401, url                                  # sin sesión
            assert cli.post(url, json=js, headers=H(tok["Bodega"])).status_code == 403, url        # sin el permiso de la caja
            assert cli.post(url, json=js, headers=H(tok["Cajero"])).status_code == 200, url
        orig = planes.vencido
        planes.vencido = lambda e: True
        try:
            for url, js in rutas:
                r = cli.post(url, json=js, headers=H(tok["Cajero"]))
                assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", (url, r.text)
        finally:
            planes.vencido = orig
    finally:
        _borrar(eid, list(usuarios.values()))


def test_tabla_indice_registro_y_no_viaja(rest):
    assert "cobro_reclamo" in {t.name for t in db.TABLAS_EMPRESA}
    assert "CREATE UNIQUE INDEX IF NOT EXISTS ux_cobro_reclamo ON cobro_reclamo(empresa_id, cuenta_id)" in db.INDICES_EMPRESA
    with engine_empresa(rest.eid).connect() as conn:
        nombres = {r[0] for r in conn.exec_driver_sql("SELECT name FROM sqlite_master WHERE type IN ('table', 'index')")}
    assert {"cobro_reclamo", "ux_cobro_reclamo"} <= nombres
    main = (RAIZ / "main.py").read_text(encoding="utf-8")
    lineas = [l for l in main.splitlines() if "cobro_reclamo" in l]
    assert len(lineas) == 1 and lineas[0].startswith("from . import cobro_reclamo as _cobro_reclamo; app.include_router(_cobro_reclamo.router)"), lineas
    for url in ("/api/pos/cobro/reclamar", "/api/pos/cobro/soltar"):                     # registradas: piden sesión (no 404)
        assert rest.c.post(url, json={}).status_code == 401, url
    assert rest.c.post("/api/pos/cobro/no-existe", json={}).status_code != 401                 # una ruta que no existe no pide sesión
    fuente = inspect.getsource(sinc)
    assert "cobro_reclamo" not in fuente and "CobroReclamo" not in fuente
    for lista in (sinc.CLAVES_CATALOGO, sinc.CLAVES_OPERATIVAS, sinc.CLAVES_RED, sinc.CLAVES_DEL_EQUIPO):
        assert not any("cobro" in str(k) for k in lista), lista


def test_lo_ya_emitido_es_cobrada_aunque_el_otro_siga_cobrando(rest, monkeypatch):
    """4.31 (cuarta vuelta): A emitió (anotó lo cobrado con «sigue») y todavía termina pagos y Bancos. B, con esos mismos platos, recibe
    «cobrada» en el acto (antes «ocupada»: esperaba a que A soltara). Si B tiene además platos que A todavía cobra sin emitir, «ocupada»."""
    eid = rest.eid
    _reloj(monkeypatch)
    assert _rec(eid, 7, EQ_A, "claveA0001", ["lC", "lL"])["resultado"] == "ganada"
    r = _rec(eid, 7, EQ_B, "claveB0001", ["lC"])
    assert r["resultado"] == "ocupada" and r["comunes"] == ["lC"], r                       # A todavía no emitió: no se sabe
    assert _soltar(eid, 7, "claveA0001", cobrado=True, lids=["lC", "lL"], sigue=True) == {"resultado": "ok"}
    assert _rec(eid, 7, EQ_B, "claveB0002", ["lC", "lP"]) == {"resultado": "cobrada", "comunes": ["lC"]}
    f = _fila(eid, 7)
    assert f["estado"] == "reclamada" and f["clave"] == "claveA0001", f                      # el cobro de A sigue siendo de A
    assert _rec(eid, 7, EQ_B, "claveB0003", ["lP"])["resultado"] == "ocupada"                # nada en común con lo cobrado: espera
    # A pide otro cobro (lP2) y todavía no lo emite: B con lC y lP2 → «ocupada» (lP2 no se sabe)
    assert _rec(eid, 7, EQ_A, "claveA0002", ["lP2"])["resultado"] == "ganada"
    r = _rec(eid, 7, EQ_B, "claveB0004", ["lC", "lP2"])
    assert r["resultado"] == "ocupada" and r["comunes"] == ["lC", "lP2"], r


# ================================================================================================================ sexta vuelta
def test_sexta_partes_a_la_vez_es_partida(rest, monkeypatch):
    """4.31 (sexta vuelta, P1): A y B tocaron «Cobrar la parte 1 de 2» a la vez; la cuenta guardada tiene el resto de A (lRa de lC, lLa de lL)
    y el de B no entró. Al pedir el cobro (o al cancelar) B dice sus restos: la cuenta tiene lo que quedó de sus platos y no es suyo, así que
    esa porción ya está en la parte de A: «partida» (no emite ni vuelve) y no queda pedido. A, con sus restos, gana. Sin restos (la cuenta
    completa), con una cuenta que el servidor no tiene o con datos raros, como antes."""
    x = rest
    eid = x.eid
    _reloj(monkeypatch)
    cuenta = {"id": 7, "nombre": "Mesa 7", "mesa_id": 7, "terminal_id": 1, "cobros": [], "partes": {"total": 2, "cobradas": 0}, "total": 5650,
              "lineas": [{"lid": "lRa", "de": "lC", "producto_id": 1, "detalle": "Casado", "cantidad": 1},
                         {"lid": "lLa", "de": "lL", "producto_id": 2, "detalle": "Limonada", "cantidad": 1},
                         {"lid": "lP", "producto_id": 3, "detalle": "Postre", "cantidad": 1}]}
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [cuenta], [], [7])
        s.commit()
    assert _rec(eid, 7, EQ_B, "claveB0001", ["lC", "lL"], cobros=0, restos=["lRb", "lLb"]) == {"resultado": "partida", "comunes": ["lC", "lL"]}
    assert _fila(eid, 7) is None                                                             # no quedó pedido
    assert _rec(eid, 7, EQ_A, "claveA0001", ["lC", "lL"], cobros=0, restos=["lRa", "lLa"])["resultado"] == "ganada"
    assert _soltar(eid, 7, "claveA0001") == {"resultado": "ok"}
    assert _rec(eid, 7, EQ_B, "claveB0002", ["lC", "lX"], restos=["lLa"]) == {"resultado": "partida", "comunes": ["lC"]}   # solo el Casado
    assert _rec(eid, 7, EQ_B, "claveB0003", ["lC", "lL"], cobros=0)["resultado"] == "ganada"   # sin restos (no es una parte): no se compara
    assert _soltar(eid, 7, "claveB0003") == {"resultado": "ok"}
    assert _rec(eid, 99, EQ_B, "claveB0004", ["lC"], restos=["lRb"])["resultado"] == "ganada"  # cuenta que el servidor no tiene
    # lo ya cobrado se dice primero («cobrada»)
    assert _rec(eid, 7, EQ_A, "claveA0002", ["lP"], restos=[])["resultado"] == "ganada"
    assert _soltar(eid, 7, "claveA0002", cobrado=True, lids=["lP", "lC"]) == {"resultado": "ok"}
    assert _rec(eid, 7, EQ_B, "claveB0005", ["lC", "lL"], restos=["lRb"]) == {"resultado": "cobrada", "comunes": ["lC"]}
    # la ruta: `restos` es opcional y, si viene, una lista de textos
    h = x.h("admin")
    ok = {"cuenta_id": 7, "equipo": EQ_C, "clave": "claveC0001", "lids": ["lL"]}
    for malo in ("lRb", [1], ["x"] * 301, [""], {"lRb": 1}):
        r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "restos": malo}, headers=h)
        assert r.status_code == 400 and isinstance(r.json()["detail"], str), (malo, r.text)
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "restos": ["lRb"]}, headers=h)
    assert r.json() == {"resultado": "partida", "comunes": ["lL"]}, r.text
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "restos": None}, headers=h)
    assert r.json()["resultado"] == "ganada", r.text


def test_sexta_partida_sin_la_cuenta_legible_no_bloquea(rest, monkeypatch):
    eid = rest.eid
    _reloj(monkeypatch)

    def roto(*a, **k):
        raise RuntimeError("lectura rota")
    monkeypatch.setattr(modulos, "leer", roto)
    assert _rec(eid, 7, EQ_B, "claveB0001", ["lC"], restos=["lRb"])["resultado"] == "ganada"   # sin la cuenta legible, el pedido vale


# ================================================================================================================ séptima vuelta
def test_septima_pares_cobrados_dice_si_el_par_del_2x1_se_cobro(rest, monkeypatch):
    """4.31 (séptima vuelta, V1): la parte (Cerveza lB al 2x1) dice su par (`pares`: lo que quedó en la cuenta del mismo plato, rB). En cada
    respuesta, `pares_cobrados`: cuáles ya están cobrados. Con eso la caja decide si lo que vuelve conserva el 2x1. Sin `pares`, la respuesta
    es la de siempre (sin el campo)."""
    x = rest
    eid = x.eid
    _reloj(monkeypatch)
    cuenta = {"id": 7, "nombre": "Mesa 7", "mesa_id": 7, "terminal_id": 1, "cobros": [], "partes": {"total": 2, "cobradas": 0}, "total": 1130,
              "lineas": [{"lid": "rB", "de": "lB", "producto_id": 4, "detalle": "Cerveza", "cantidad": 1, "descuento_pct": 50, "promo": "2x1"},
                         {"lid": "rF", "de": "lF", "producto_id": 5, "detalle": "Café", "cantidad": 0.5}]}
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [cuenta], [], [7])
        s.commit()
    r = _rec(eid, 7, EQ_A, "claveA0001", ["lB", "lF"], cobros=0, restos=["rB", "rF"], pares=["rB"])
    assert r["resultado"] == "ganada" and r["pares_cobrados"] == [], r                       # nadie cobró el par
    assert _soltar(eid, 7, "claveA0001") == {"resultado": "ok"}
    assert "pares_cobrados" not in _rec(eid, 7, EQ_B, "claveB0001", ["rB"], cobros=0)          # sin `pares`: como siempre
    assert _soltar(eid, 7, "claveB0001", cobrado=True, lids=["rB"]) == {"resultado": "ok"}    # B cobró la Cerveza que quedó (rB)
    r = _rec(eid, 7, EQ_A, "claveA0002", ["lB", "lF"], cobros=0, restos=["rB", "rF"], pares=["rB", "rX"])
    assert r["resultado"] == "ganada" and r["pares_cobrados"] == ["rB"], r                   # el par ya se cobró
    assert _soltar(eid, 7, "claveA0002") == {"resultado": "ok"}
    # también con «cambiada» (otro equipo cobró una parte), «cobrada», «partida» y «ocupada»
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [{**cuenta, "cobros": [{"doc_id": 1}], "lineas": cuenta["lineas"][1:]}], [], [])
        s.commit()
    assert _rec(eid, 7, EQ_A, "claveA0003", ["lB", "lF"], cobros=0, restos=["rF"], pares=["rB"]) == {"resultado": "cambiada", "comunes": [], "pares_cobrados": ["rB"]}
    assert _rec(eid, 7, EQ_A, "claveA0004", ["rB", "lF"], pares=["rB"]) == {"resultado": "cobrada", "comunes": ["rB"], "pares_cobrados": ["rB"]}
    assert _rec(eid, 7, EQ_A, "claveA0005", ["lF"], restos=["rZ"], pares=["rB"]) == {"resultado": "partida", "comunes": ["lF"], "pares_cobrados": ["rB"]}
    assert _rec(eid, 7, EQ_B, "claveB0002", ["lQ"])["resultado"] == "ganada"
    r = _rec(eid, 7, EQ_A, "claveA0006", ["lB"], pares=["rB", "rY"])
    assert r["resultado"] == "ocupada" and r["pares_cobrados"] == ["rB"], r
    # la ruta: `pares` es opcional y, si viene, una lista de textos
    h = x.h("admin")
    ok = {"cuenta_id": 8, "equipo": EQ_C, "clave": "claveC0001", "lids": ["lL"]}
    for malo in ("rB", [1], ["x"] * 301, [""], {"rB": 1}):
        r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "pares": malo}, headers=h)
        assert r.status_code == 400 and isinstance(r.json()["detail"], str), (malo, r.text)
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "pares": ["rB"]}, headers=h)
    assert r.json()["resultado"] == "ganada" and r.json()["pares_cobrados"] == [], r.text
    r = x.c.post("/api/pos/cobro/reclamar", json={**ok, "clave": "claveC0002", "pares": None}, headers=h)
    assert r.json()["resultado"] == "ganada" and "pares_cobrados" not in r.json(), r.text
