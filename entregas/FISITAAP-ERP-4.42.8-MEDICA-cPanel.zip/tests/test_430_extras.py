# -*- coding: utf-8 -*-
"""4.30: «No está preguntando los extras y opcionales del producto al elegirlos en caja y en catálogo en línea».

Causa: «Guardar modificadores» de Punto de venta › Configuración (pos/configuracion.js, guardarMods) volvía a escribir cada grupo de
pos_modificadores solo con id, nombre, mínimo, máximo, activo y opciones, y borraba productos, categorias, tipo y fis, donde FISITAAP ›
Extras y Opcionales guarda a qué producto o categoría va cada grupo.

- X1: la pantalla parte del grupo guardado y cambia solo lo que edita (modsParaGuardar, corrida en Node). La ficha del ítem tampoco bota
  lo que no edita de items_extra.
- X2: el servidor conserva esas claves cuando un grupo llega sin ellas (por /cambios y por el PUT completo); una clave que llega se
  respeta, un grupo borrado se borra.
- X3: recuperar lo perdido de un respaldo sin restaurarlo (app/recuperar_mods.py, GET/POST /api/pos/modificadores/recuperar).
- X4: ida y vuelta: extras de FISITAAP → guardado de la pantalla (el de antes, con seis campos, y el de ahora) → /api/publico/<slug> y
  la regla de la caja (gruposDe de pos/caja.js, corrida en Node con los datos guardados) siguen encontrando los grupos.
Solo cuentas @example.test y las bases temporales de las pruebas."""
import json
import pathlib
import zipfile

import pytest
from sqlmodel import Session, select

from app import auth, modulos, recuperar_mods, respaldo
from app.db import Auditoria, engine, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_pedidos import _eid, _publicar
from test_425_ultimos_pantallas import _node

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
SLUG = "extras-qa-430"
CAMPOS = ("productos", "categorias", "tipo", "fis")
# El guardado de la pantalla hasta la 4.29 (copia literal de la línea de guardarMods): solo seis campos por grupo
GUARDADO_ANTERIOR = ("mods => mods.map(g => ({ id: g.id, nombre: g.nombre.trim(), minimo: Math.max(0, +g.minimo || 0), maximo: Math.max(0, +g.maximo || 0), "
                     "activo: g.activo !== false, opciones: g.opciones.map(o => ({ id: o.id, nombre: o.nombre.trim(), precio: Math.max(0, +o.precio || 0) })) }))")
AVISO = "Encontramos extras y opcionales que perdieron sus productos y categorías ("


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _funcion_guardar() -> str:
    """modsParaGuardar(mods, guardados) de pos/configuracion.js, tal como está."""
    return _tramo(_js("pages/pos/configuracion.js"), "export function modsParaGuardar(", "\n}\n").replace("export function", "function") + "\n}\n"


def _grupos_de_caja() -> str:
    """El método gruposDe de pos/caja.js, tal como está."""
    return _tramo(_js("pages/pos/caja.js"), "    gruposDe(p) {", "\n    toggleOpcion(")


# ------------------------------------------------------------------------------------------------ ayudas
def _producto(c, nombre, categoria):
    r = c.post("/api/productos", json={"nombre": nombre, "cabys": "2111100000000", "precio": 3000, "tarifa": 13, "codigo_tarifa": "08", "visible_catalogo": True, "categoria": categoria})
    assert r.status_code == 200, r.text
    return r.json()


def _negocio(c, eid):
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "restaurante", "mesas": []}]})
        modulos.reemplazar(s, eid, "categorias", [{"id": 1, "nombre": "Platos"}, {"id": 2, "nombre": "Postres"}, {"id": 3, "nombre": "Bebidas"}])
    pizza, flan, batido = _producto(c, "Pizza QA", "Platos"), _producto(c, "Flan QA", "Postres"), _producto(c, "Batido QA", "Bebidas")
    assert _publicar(c, slug=f"{SLUG}-{eid}").status_code == 200
    return pizza, flan, batido


def _extras_fisitaap(c, pizza):
    op = c.post("/api/fisitaap/opcionales", json={"nombre": "Tamaño QA", "opciones": [{"nombre": "Personal"}, {"nombre": "Grande"}], "obligatorio": True, "productos": [pizza["id"]]})
    assert op.status_code == 200, op.text
    ex = c.post("/api/fisitaap/extras", json={"nombre": "Helado QA", "precio": 400, "categorias": ["Postres"]})
    assert ex.status_code == 200, ex.text
    return op.json(), ex.json()


def _registro(c, clave):
    r = c.get(f"/api/registros/{clave}"); assert r.status_code == 200, r.text
    return r.json()


def _publico(c) -> dict:
    r = c.get(f"/api/publico/{SLUG}-{_eid()}"); assert r.status_code == 200, r.text
    return {i["id"]: sorted(g["nombre"] for g in (i.get("modificadores") or [])) for i in r.json()["items"]}


def _caja(tmp_path, productos) -> dict:
    """La regla de la caja (gruposDe) con lo que está guardado en el servidor: {id de producto: [nombres de grupos]}."""
    c, sub = productos[0][0], tmp_path / f"caja_{len(list(tmp_path.iterdir()))}"
    sub.mkdir()
    datos = {"pos_modificadores": _registro(c, "pos_modificadores")["datos"] or [], "items_extra": _registro(c, "items_extra")["datos"] or {}}
    prods = [{"id": p["id"], "categoria": p.get("categoria")} for _, p in productos]
    r = _node(sub, "const D = %s;\nconst mock = { get: (k, f) => (k in D ? JSON.parse(JSON.stringify(D[k])) : f) };\nconst M = {\n%s\n};\n"
                   "const out = {}; for (const p of %s) out[p.id] = M.gruposDe(p).map(g => g.nombre).sort();\nconsole.log(JSON.stringify(out));\n"
              % (json.dumps(datos, ensure_ascii=False), _grupos_de_caja(), json.dumps(prods)), archivos=(), falsos={})
    return {int(k): v for k, v in r.items()}


def _como_la_pantalla(tmp_path, funcion: str, mods: list, guardados: list) -> list:
    """Lo que la pantalla manda a guardar: `funcion` es el guardado (el de antes o modsParaGuardar de ahora)."""
    sub = tmp_path / f"pantalla_{len(list(tmp_path.iterdir()))}"
    sub.mkdir()
    return _node(sub, funcion + "\nconst guardar = %s;\nconsole.log(JSON.stringify(guardar(%s, %s)));\n"
                 % ("modsParaGuardar" if "function modsParaGuardar" in funcion else "(m, g) => anterior(m)",
                    json.dumps(mods, ensure_ascii=False), json.dumps(guardados, ensure_ascii=False)), archivos=(), falsos={})


def _subir(c, base: list, nuevo: list):
    """Lo que hace api.js (_subirAhora) con una lista con ids: altas, cambios y bajas por id (POST /cambios)."""
    b = {str(x["id"]): x for x in base}; n = {str(x["id"]): x for x in nuevo}
    upserts = [x for x in nuevo if str(x["id"]) not in b or b[str(x["id"])] != x]
    deletes = [b[k]["id"] for k in b if k not in n]
    nuevos = [x["id"] for x in nuevo if str(x["id"]) not in b]
    r = c.post("/api/registros/pos_modificadores/cambios", json={"upserts": upserts, "deletes": deletes, "nuevos": nuevos})
    assert r.status_code == 200, r.text


ANTERIOR = "const anterior = " + GUARDADO_ANTERIOR + ";\n"


# ------------------------------------------------------------------------------------------------ X4: ida y vuelta
def test_ida_y_vuelta_fisitaap_pantalla_catalogo_y_caja(api, tmp_path):  # noqa: F811
    c = api; eid = _eid()
    pizza, flan, batido = _negocio(c, eid)
    op, ex = _extras_fisitaap(c, pizza)
    prods = [(c, pizza), (c, flan), (c, batido)]
    esperado = {pizza["id"]: ["Tamaño QA"], flan["id"]: ["Helado QA"], batido["id"]: []}

    def comprobar(paso):
        pub = _publico(c)
        assert {k: pub[k] for k in esperado} == esperado, (paso, pub)
        assert _caja(tmp_path, prods) == esperado, paso

    comprobar("recién creados en FISITAAP")
    # 1) el guardado de ANTES (seis campos), por /cambios: el servidor conserva las asignaciones
    base = _registro(c, "pos_modificadores")["datos"]
    _subir(c, base, _como_la_pantalla(tmp_path, ANTERIOR, base, base))
    comprobar("guardado anterior por /cambios")
    # 2) el mismo guardado de ANTES por el PUT del registro completo
    reg = _registro(c, "pos_modificadores")
    seis = _como_la_pantalla(tmp_path, ANTERIOR, reg["datos"], reg["datos"])
    assert all(not (set(CAMPOS) & set(g)) for g in seis)                                 # de verdad llega sin las claves
    r = c.put("/api/registros/pos_modificadores", json={"datos": seis, "version": reg["version"]}); assert r.status_code == 200, r.text
    comprobar("guardado anterior por PUT")
    # 3) el guardado de AHORA: se renombra un grupo, se cambia un precio, se desactiva nada y se agrega un grupo desde Punto de venta
    base = _registro(c, "pos_modificadores")["datos"]
    mods = json.loads(json.dumps(base))
    t = next(g for g in mods if g["id"] == op["id"]); t["nombre"] = "  Tamaño QA "; t["opciones"][1]["precio"] = 900
    for g in mods:                                                                       # la copia de la pantalla vieja no traía las claves
        for k in CAMPOS:
            g.pop(k, None)
    nid = max(g["id"] for g in mods) + 1
    mods.append({"id": nid, "nombre": "Término QA", "minimo": 1, "maximo": 1, "activo": True, "opciones": [{"id": nid * 100 + 1, "nombre": "Medio", "precio": 0}]})
    ahora = _como_la_pantalla(tmp_path, _funcion_guardar(), mods, base)
    por = {g["id"]: g for g in ahora}
    assert por[op["id"]]["productos"] == [pizza["id"]] and por[op["id"]]["tipo"] == "opcional" and por[op["id"]]["fis"] is True
    assert por[ex["id"]]["categorias"] == ["Postres"] and por[ex["id"]]["tipo"] == "extra"
    assert por[op["id"]]["nombre"] == "Tamaño QA" and por[op["id"]]["opciones"][1]["precio"] == 900
    assert not (set(CAMPOS) & set(por[nid]))                                              # el grupo nuevo, como lo hizo la pantalla
    _subir(c, base, ahora)
    comprobar("guardado de ahora")
    guardado = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert guardado[op["id"]]["opciones"][1]["precio"] == 900 and guardado[nid]["nombre"] == "Término QA"
    # 4) borrar desde Punto de venta un grupo: se borra (no lo revive nadie)
    base = _registro(c, "pos_modificadores")["datos"]
    sin = [g for g in base if g["id"] != nid]
    _subir(c, base, _como_la_pantalla(tmp_path, _funcion_guardar(), sin, base))
    assert nid not in {g["id"] for g in _registro(c, "pos_modificadores")["datos"]}
    comprobar("grupo borrado")
    # 5) FISITAAP quita a propósito una asignación (lista vacía): se respeta, también después de otro guardado de seis campos
    r = c.put(f"/api/fisitaap/extras/{ex['id']}", json={"nombre": "Helado QA", "precio": 400, "categorias": []}); assert r.status_code == 200, r.text
    base = _registro(c, "pos_modificadores")["datos"]
    _subir(c, base, _como_la_pantalla(tmp_path, ANTERIOR, base, base))
    esperado[flan["id"]] = []
    comprobar("asignación quitada en FISITAAP")
    assert c.get("/api/fisitaap/modificadores?tipo=extra").json()["grupos"][0]["nombre"] == "Helado QA"   # sigue siendo extra


# ------------------------------------------------------------------------------------------------ X2: el servidor, función por función
def test_reponer_asignaciones_reglas():
    g = {"id": 1, "nombre": "A", "productos": [5], "categorias": ["X"], "tipo": "extra", "fis": True, "otro": 1}
    llega = {"id": 1, "nombre": "B", "opciones": []}
    assert recuperar_mods.reponer_asignaciones(g, llega) == {"id": 1, "nombre": "B", "opciones": [], "productos": [5], "categorias": ["X"], "tipo": "extra", "fis": True}
    assert recuperar_mods.reponer_asignaciones(g, {**llega, "productos": []})["productos"] == []          # lo que llega se respeta
    assert recuperar_mods.reponer_asignaciones(None, llega) is llega                                      # grupo nuevo: como llega
    assert recuperar_mods.reponer_en_lista([g], [llega, {"id": 2, "nombre": "C"}]) == [recuperar_mods.reponer_asignaciones(g, llega), {"id": 2, "nombre": "C"}]
    assert recuperar_mods.reponer_en_lista([g], []) == []                                                 # todos borrados: se borran
    assert recuperar_mods.reponer_en_upserts({1: g}, [llega], [1]) == [llega]                             # un alta no toma nada de otro grupo


def test_put_y_cambios_de_otras_claves_no_cambian(api):  # noqa: F811
    """Solo pos_modificadores: en otra clave un elemento que llega sin «productos» queda sin ellos, como siempre."""
    c = api
    r = c.put("/api/registros/pos_promos", json={"datos": [{"id": 1, "nombre": "2x1", "productos": [1, 2]}], "version": 0}); assert r.status_code == 200, r.text
    r = c.post("/api/registros/pos_promos/cambios", json={"upserts": [{"id": 1, "nombre": "2x1"}], "deletes": [], "nuevos": []}); assert r.status_code == 200, r.text
    assert _registro(c, "pos_promos")["datos"] == [{"id": 1, "nombre": "2x1"}]


# ------------------------------------------------------------------------------------------------ X1: las pantallas
def test_pantalla_conserva_lo_que_no_edita(tmp_path):
    guardados = [{"id": 1, "nombre": "Tamaño", "minimo": 1, "maximo": 1, "activo": True, "tipo": "opcional", "fis": True, "productos": [7], "categorias": ["Platos"], "futuro": {"a": 1},
                  "opciones": [{"id": 11, "nombre": "Grande", "precio": 500, "codigo": "G"}]}]
    mods = [{"id": 1, "nombre": " Tamaño grande ", "minimo": "0", "maximo": 2, "activo": False, "opciones": [{"id": 11, "nombre": " Enorme ", "precio": "700"}, {"id": 12, "nombre": "Nueva", "precio": -5}]},
            {"id": 2, "nombre": "Nuevo", "minimo": 1, "maximo": 1, "activo": True, "opciones": [{"id": 201, "nombre": "Sí", "precio": 0}]}]
    r = _node(tmp_path, _funcion_guardar() + "console.log(JSON.stringify(modsParaGuardar(%s, %s)));\n" % (json.dumps(mods, ensure_ascii=False), json.dumps(guardados, ensure_ascii=False)),
              archivos=(), falsos={})
    assert r == [{"id": 1, "nombre": "Tamaño grande", "minimo": 0, "maximo": 2, "activo": False, "tipo": "opcional", "fis": True, "productos": [7], "categorias": ["Platos"], "futuro": {"a": 1},
                  "opciones": [{"id": 11, "nombre": "Enorme", "precio": 700, "codigo": "G"}, {"id": 12, "nombre": "Nueva", "precio": 0}]},
                 {"id": 2, "nombre": "Nuevo", "minimo": 1, "maximo": 1, "activo": True, "opciones": [{"id": 201, "nombre": "Sí", "precio": 0}]}]


def test_textos_de_las_pantallas():
    cfg = _js("pages/pos/configuracion.js")
    assert "mock.set('pos_modificadores', modsParaGuardar(this.mods, mock.get('pos_modificadores', []) || [], alDia))" in cfg      # H3
    assert "mock.refrescar(['pos_modificadores'])" not in cfg                             # H3: la copia de la pestaña sigue alineada con la pantalla
    assert "nombre: g.nombre.trim(), minimo: Math.max(0, +g.minimo || 0), maximo: Math.max(0, +g.maximo || 0), activo: g.activo !== false, opciones: g.opciones.map(o => ({ id: o.id" not in cfg
    assert ("Si un extra u opcional de FISITAAP dejó de preguntarse en la caja o en el catálogo en línea y aquí no aparece el aviso para recuperarlo, "
            "vuelva a asignarle sus productos y categorías en FISITAAP › Extras u Opcionales.") in cfg
    assert "if (this.puedeConfigurar) this.cargarRecuperar();" in cfg and '<div v-if="recMods" class="alert info"' in cfg
    for nombre in ("recMods", "recViendo", "recuperandoMods", "modsQuitados"):              # todo lo de la plantilla existe en data
        assert nombre + ":" in _tramo(cfg, "  data() {", "  computed: {")
    assert '@click="quitarMod(i)"' in cfg and '@click="mods.splice(i, 1)"' not in cfg              # H1: quitar un grupo lo anota
    for m in ("cargarRecuperar()", "recuperarMods()", "quitarMod(i)", "nuevoMod()"):
        assert m in _tramo(cfg, "  methods: {", "  mounted() {")
    ficha = _js("pages/inventario/item-form.js")
    assert "x[p.id] = { ...(x[p.id] || {}), ...dato };" in ficha and "x[p.id] = dato;" not in ficha
    comp = _js("pages/pos/_recuperar_mods.js")
    for rel in ("fis/pages/extras.js", "fis/pages/opcionales.js"):
        t = _js(rel)
        assert "import { AvisoRecuperarMods } from '/js/pages/pos/_recuperar_mods.js';" in t and "components: { AvisoRecuperarMods }," in t and '<AvisoRecuperarMods clase="card" @recuperado="cargar"/>' in t
    assert ">Recuperar</button>" in comp and ">Recuperar</button>" in cfg and "Confirmar y recuperar" in comp and "Confirmar y recuperar" in cfg


def test_textos_del_aviso_en_node(tmp_path):
    r = _node(tmp_path, "const M = await import('./js/pages/pos/_recuperar_mods.js');\nconsole.log(JSON.stringify([M.textoAviso(2, '10/11/2026'), M.textoAviso(1, '09/11/2026'), "
                        "M.textoGrupo({ reponer: { productos: [1, 2], categorias: ['Postres'], tipo: 'extra', fis: true }, productos_nombres: ['Pizza', 'Flan'] }), M.textoGrupo({ reponer: { fis: true } })]));\n",
              archivos=("pages/pos/_recuperar_mods.js",), falsos={"api.js": "export const api = async () => ({}); export const toast = () => {};\n"})
    assert r[0] == "Encontramos extras y opcionales que perdieron sus productos y categorías (2 grupos). Podemos recuperarlos del respaldo del 10/11/2026."
    assert r[1] == "Encontramos extras y opcionales que perdieron sus productos y categorías (1 grupo). Podemos recuperarlos del respaldo del 09/11/2026."
    assert r[2] == "productos: Pizza, Flan; categorías: Postres; vuelve a mostrarse como extra en FISITAAP" and r[3] == "vuelve a mostrarse en FISITAAP"


def test_sintaxis_y_plantillas(tmp_path):
    from test_425_ultimos_pantallas import _nodo
    import subprocess
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/pos/configuracion.js", "pages/pos/_recuperar_mods.js", "pages/inventario/item-form.js", "fis/pages/extras.js", "fis/pages/opcionales.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") == 0, rel                                                    # todos LF, sin mezclar
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = []; let n = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) { if (m[1].includes('${')) continue; n++; const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); } if (err.length) malos.push([a, err.slice(0, 2)]); }
}
console.log(JSON.stringify({ n, malos }));
""" % (json.dumps(vue), json.dumps([str(JS / r) for r in tocados]))
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] >= 5 and r["malos"] == [], r


# ------------------------------------------------------------------------------------------------ X3: recuperar de un respaldo
def _respaldo_general(carpeta: pathlib.Path, eid: int, nombre: str) -> pathlib.Path:
    """Un respaldo general como el diario (respaldo.ejecutar): la base de la empresa en data/empresas/empresa_<id>.db."""
    carpeta.mkdir(parents=True, exist_ok=True)
    copia = carpeta / f"copia_{eid}.db"
    respaldo._copiar_db(respaldo.DATA_DIR / "empresas" / f"empresa_{eid}.db", copia)
    with zipfile.ZipFile(carpeta / nombre, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(copia, f"data/empresas/empresa_{eid}.db")
    copia.unlink()
    return carpeta / nombre


def _olvidar():
    """Lo que recuperar_mods guarda en memoria entre peticiones: los respaldos ya leídos y (H5) la última revisión completa."""
    recuperar_mods._cache.clear()
    getattr(recuperar_mods, "_revisado", {}).clear()


def _danar(eid, nombres, quitar_grupo=None):
    """Lo que hacía el guardado de la 4.29 (sin pasar por la protección nueva del servidor)."""
    with Session(engine_empresa(eid)) as s:
        grupos = modulos.leer(s, eid, "pos_modificadores", [])
        grupos = [{k: v for k, v in g.items() if not (g["nombre"] in nombres and k in CAMPOS)} for g in grupos if g["nombre"] != quitar_grupo]
        r = modulos._registro(s, eid, "pos_modificadores")
        modulos.reemplazar(s, eid, "pos_modificadores", grupos, r.version); s.commit()


def test_recuperar_de_un_respaldo(api, tmp_path, monkeypatch):  # noqa: F811
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False                       # nada perdido: ni se buscan respaldos
    op, ex = _extras_fisitaap(c, pizza)
    queso = c.post("/api/fisitaap/extras", json={"nombre": "Queso QA", "precio": 300, "productos": [pizza["id"]]}).json()
    viejo = c.post("/api/fisitaap/extras", json={"nombre": "Viejo QA", "precio": 100, "productos": [batido["id"]]}).json()
    with Session(engine_empresa(eid)) as s:                                                       # un producto que ya no existe
        grupos = modulos.leer(s, eid, "pos_modificadores", [])
        for g in grupos:
            if g["id"] == op["id"]:
                g["productos"] = [pizza["id"], 987654]
        modulos.reemplazar(s, eid, "pos_modificadores", grupos, modulos._registro(s, eid, "pos_modificadores").version); s.commit()
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False                       # sin respaldos: no sale nada
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")
    # el daño: se pierden las asignaciones de los cuatro; «Viejo» se borra hoy; «Queso» se vuelve a asignar hoy en FISITAAP
    _danar(eid, {"Tamaño QA", "Helado QA", "Queso QA"}, quitar_grupo="Viejo QA")
    r = c.put(f"/api/fisitaap/extras/{queso['id']}", json={"nombre": "Queso QA", "precio": 300, "productos": [flan["id"]]}); assert r.status_code == 200, r.text
    assert _publico(c)[pizza["id"]] == [] and _publico(c)[flan["id"]] == ["Queso QA"]
    # un respaldo de la empresa hecho DESPUÉS del daño (más nuevo): no sirve y se sigue con el anterior
    from app.main import app
    empresa = app.dependency_overrides[auth.contexto]().empresa
    nuevo = respaldo.ejecutar_empresa(empresa, forzar=True)
    assert nuevo.name > "empresa_%d_2020" % eid
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p["hay"] is True and p["respaldo"] == "facturacr_20200110_020000.zip" and p["fecha"] == "10/01/2020" and p["origen"] == "general", p
    por = {g["id"]: g for g in p["grupos"]}
    assert set(por) == {op["id"], ex["id"]}, p                                                    # Queso tiene lo suyo hoy; Viejo se borró
    # H2: la clave que el respaldo tiene se repone aunque su lista quede vacía (FISITAAP siempre guarda las cuatro)
    assert por[op["id"]]["reponer"] == {"productos": [pizza["id"]], "categorias": [], "tipo": "opcional", "fis": True} and por[op["id"]]["productos_nombres"] == ["Pizza QA"]
    assert por[ex["id"]]["reponer"] == {"productos": [], "categorias": ["Postres"], "tipo": "extra", "fis": True}
    # quien no puede configurar: no ve nada y no puede recuperar
    ctx_admin = app.dependency_overrides[auth.contexto]()
    vendedor = auth.Contexto(ctx_admin.usuario, ctx_admin.empresa, "Vendedor")
    app.dependency_overrides[auth.contexto] = lambda: vendedor
    try:
        assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False
        assert c.post("/api/pos/modificadores/recuperar", json={"respaldo": p["respaldo"]}).status_code == 403
    finally:
        app.dependency_overrides[auth.contexto] = lambda: ctx_admin
    # el tope de tiempo: sin tiempo no se propone nada (y no se cuelga)
    recuperar_mods._cache.clear()
    with Session(engine_empresa(eid)) as s:
        assert recuperar_mods.propuesta(s, eid, segundos=0)["incompleta"] is True
    assert c.post("/api/pos/modificadores/recuperar", json={"respaldo": "../data/otro.zip"}).status_code == 400
    # recuperar
    r = c.post("/api/pos/modificadores/recuperar", json={"respaldo": p["respaldo"]}); assert r.status_code == 200, r.text
    assert {g["id"] for g in r.json()["grupos"]} == {op["id"], ex["id"]}
    pub = _publico(c)
    assert pub[pizza["id"]] == ["Tamaño QA"] and pub[flan["id"]] == ["Helado QA", "Queso QA"] and pub[batido["id"]] == []
    guardados = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert viejo["id"] not in guardados and guardados[queso["id"]]["productos"] == [flan["id"]]  # no revive ni pisa
    assert guardados[op["id"]]["productos"] == [pizza["id"]]                                       # sin el producto que ya no existe
    with Session(engine) as s:
        a = s.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == "pos_modificadores_recuperados")).all()
    assert len(a) == 1 and "2 grupos recuperados del respaldo del 10/01/2020" in a[0].detalle, [x.detalle for x in a]
    # ya no hay nada que recuperar
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False
    assert c.post("/api/pos/modificadores/recuperar", json={"respaldo": p["respaldo"]}).status_code == 409


# ================================================================================================ correcciones de la revisión (H1 a H6)
# Punto de venta › Configuración › Modificadores corrida en Node: configuracion.js tal como está, con api.js y app.js sustitutos.
# Q.mock es la copia de la pestaña (mock.get / mock.set), Q.servidor lo que responde GET /api/registros/pos_modificadores y
# Q.respuestas lo que responden otras rutas. mock.nextId da el id por encima de la lista y del tope del servidor, como api.js en la nube.
FALSO_API_CFG = """
const copia = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const api = async (url, opt) => {
  globalThis.Q.pedidos.push(url);
  if (url in globalThis.Q.respuestas) return copia(globalThis.Q.respuestas[url]);
  if (url === '/api/registros/pos_modificadores') { if (globalThis.Q.sinRed) throw new Error('Sin conexión'); return { datos: copia(globalThis.Q.servidor), version: 9 }; }
  throw new Error('ruta no prevista ' + url);
};
export const money = v => String(v), fmt = v => String(v), fecha = v => String(v), hoy = () => '2026-11-12', abrirArchivo = async () => {};
export const precioCliente = p => p.precio, otroImpLinea = () => ({ monto: 0, base: 0 });
export const mock = {
  get: (k, d) => (k in globalThis.Q.mock ? copia(globalThis.Q.mock[k]) : d),
  set: (k, v) => { globalThis.Q.mock[k] = copia(v); globalThis.Q.enviados.push(copia(v)); return Promise.resolve(true); },
  nextId: (l, k) => { globalThis.Q.claves.push(k); return Math.max(0, ...(l || []).map(x => +x.id || 0), +(globalThis.Q.topes[k] || 0)) + 1; },
};
"""
FALSO_APP_CFG = "export const store = globalThis.Q.store;\nexport const sesion = { puede: p => globalThis.Q.permisos.includes(p), empresaInfo: globalThis.Q.empresaInfo };\n"
ARCHIVOS_CFG = ("pages/pos/configuracion.js", "pages/pos/_datos.js", "pages/pos/_agente.js", "pages/inventario/_etiquetas.js", "pages/pos/_recuperar_mods.js")
FALSOS_CFG = {"api.js": FALSO_API_CFG, "app.js": FALSO_APP_CFG, "pages/bancos/cuentas.js": "export const cuentasParaMovimientos = async () => [];\n"}


def _pantalla(tmp_path, pestana: list, pasos: str, servidor=None, tope=0, respuestas=None, programa=False, sin_red=False) -> dict:
    """La pantalla montada sobre un objeto (data, computed y methods del componente); `pasos` es lo que hace el usuario sobre `vm`."""
    sub = tmp_path / f"cfg_{len(list(tmp_path.iterdir()))}"
    sub.mkdir()
    q = {"toasts": [], "enviados": [], "claves": [], "pedidos": [], "mock": {"pos_modificadores": pestana}, "servidor": pestana if servidor is None else servidor,
         "topes": {"pos_modificadores": tope}, "respuestas": respuestas or {}, "sinRed": sin_red, "store": {"clientes": [], "productos": []},
         "permisos": ["configurar"], "empresaInfo": {"es_local": programa}}
    guion = ("globalThis.Q = %s;\nconst P = (await import('./js/pages/pos/configuracion.js')).default;\nconst vm = P.data.call({});\n"
             "for (const [k, f] of Object.entries(P.computed || {})) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });\n"
             "for (const [k, f] of Object.entries(P.methods || {})) vm[k] = f.bind(vm);\n%s\n"
             "console.log(JSON.stringify({ enviados: Q.enviados, toasts: Q.toasts, mods: vm.mods, claves: Q.claves, pedidos: Q.pedidos, recMods: vm.recMods, recEnWeb: vm.recEnWeb, extra: Q.extra }));\n"
             % (json.dumps(q, ensure_ascii=False), pasos))
    return _node(sub, guion, archivos=ARCHIVOS_CFG, falsos=FALSOS_CFG)


def _grupos_directo(eid, grupos):
    """Escribe pos_modificadores tal cual (como lo dejan FISITAAP o un guardado viejo), sin pasar por las reglas de /api/registros."""
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "pos_modificadores")
        modulos.reemplazar(s, eid, "pos_modificadores", grupos, (r.version or 0) if r else 0); s.commit()


def _grupo(gid, nombre, precio=0, **asignacion):
    return {"id": gid, "nombre": nombre, "minimo": 0, "maximo": 1, "activo": True, "opciones": [{"id": gid * 100 + 1, "nombre": nombre, "precio": precio}], **asignacion}


# ------------------------------------------------------------------------------------------------ H1
def test_h1_grupo_nuevo_no_toma_el_id_ni_las_asignaciones_de_uno_quitado(api, tmp_path):  # noqa: F811
    """Se quita «Helado» (el de id más alto, un extra de FISITAAP con productos y categorías) y antes de guardar se agrega «Término».
    El grupo nuevo no recibe el id de Helado ni el de otro grupo guardado o quitado en la sesión, sale como alta y no lleva productos,
    categorías, tipo ni fis: ni la caja ni el catálogo en línea lo preguntan en Pizza ni en los postres. Helado se borra."""
    c = api; eid = _eid()
    pizza, flan, batido = _negocio(c, eid)
    _grupos_directo(eid, [_grupo(1, "Tamaño QA"), _grupo(2, "Salsas QA"),
                          _grupo(3, "Helado QA", 400, productos=[pizza["id"]], categorias=["Postres"], tipo="extra", fis=True)])
    reg = _registro(c, "pos_modificadores"); base = reg["datos"]
    assert _publico(c)[pizza["id"]] == ["Helado QA"] and _publico(c)[flan["id"]] == ["Helado QA"]
    r = _pantalla(tmp_path, base, """
vm.quitarMod(vm.mods.findIndex(g => g.nombre === 'Helado QA'));
vm.nuevoMod();
const g = vm.mods[vm.mods.length - 1]; g.nombre = 'Término QA'; g.opciones[0].nombre = 'Medio'; g.opciones[1].nombre = 'Tres cuartos';
await vm.guardarMods();
""", tope=reg["ultimo_id"])
    assert r["toasts"] == [["Modificadores guardados", "ok"]], r
    assert r["claves"] == ["pos_modificadores"]                                         # el id sale de mock.nextId de esta clave
    enviado = {g["id"]: g for g in r["enviados"][-1]}
    nid = next(i for i, g in enviado.items() if g["nombre"] == "Término QA")
    assert nid not in {g["id"] for g in base}, nid                                      # ni el de Helado ni el de otro grupo guardado
    assert set(enviado) == {1, 2, nid} and not (set(CAMPOS) & set(enviado[nid])), enviado
    _subir(c, base, r["enviados"][-1])
    guardado = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert set(guardado) == {1, 2, nid} and not (set(CAMPOS) & set(guardado[nid])), guardado
    assert _publico(c)[pizza["id"]] == [] and _publico(c)[flan["id"]] == []
    assert _caja(tmp_path, [(c, pizza), (c, flan), (c, batido)]) == {pizza["id"]: [], flan["id"]: [], batido["id"]: []}
    # el id de un grupo nuevo tampoco repite el de uno quitado en la sesión que ya no está guardado ni en la pantalla
    r = _pantalla(tmp_path, [_grupo(1, "Uno"), _grupo(5, "Cinco")], """
vm.quitarMod(1); vm.nuevoMod(); Q.extra = vm.mods[1].id; vm.quitarMod(1); vm.nuevoMod();
""")
    assert r["extra"] == 6 and [g["id"] for g in r["mods"]] == [1, 7], r
    # un grupo que no está guardado nunca lleva asignaciones, aunque las traiga la copia de la pantalla
    sin = _como_la_pantalla(tmp_path, _funcion_guardar(), [_grupo(9, "Nueve", productos=[pizza["id"]], categorias=["Postres"], tipo="extra", fis=True)], [_grupo(1, "Uno")])
    assert sin == [_grupo(9, "Nueve")], sin


# ------------------------------------------------------------------------------------------------ H2
def test_h2_lista_vacia_del_respaldo_se_repone_y_no_se_buscan_respaldos_mas_viejos(api, tmp_path, monkeypatch):  # noqa: F811
    """Respaldo viejo: «Tamaño» en Batido y en Bebidas, «Helado» en Flan y un grupo 900 «Antiguo» en Batido. Después el dueño cambió en
    FISITAAP las asignaciones (Tamaño solo en Pizza, sin categorías; Helado en Postres, sin productos) y borró «Antiguo»: respaldo nuevo.
    Un guardado de la 4.29 las borró y en Punto de venta se creó otro grupo con el id 900. Se recupera del respaldo nuevo con sus listas
    vacías y después ya no sale el aviso: nunca se ofrecen las asignaciones viejas ni las de otro grupo que tuvo el mismo id."""
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    op, ex = _extras_fisitaap(c, pizza)
    actuales = _registro(c, "pos_modificadores")["datos"]
    assert {g["id"]: (g["productos"], g["categorias"]) for g in actuales} == {op["id"]: ([pizza["id"]], []), ex["id"]: ([], ["Postres"])}
    viejas = {op["id"]: {"productos": [batido["id"]], "categorias": ["Bebidas"]}, ex["id"]: {"productos": [flan["id"]], "categorias": []}}
    _grupos_directo(eid, [{**g, **viejas[g["id"]]} for g in actuales] + [_grupo(900, "Antiguo QA", 100, productos=[batido["id"]], categorias=[], tipo="extra", fis=True)])
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200105_020000.zip")
    _grupos_directo(eid, actuales)
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")
    _danar(eid, {"Tamaño QA", "Helado QA"})
    with Session(engine_empresa(eid)) as s:
        hoy = modulos.leer(s, eid, "pos_modificadores", [])
    _grupos_directo(eid, hoy + [_grupo(900, "Nuevo QA")])
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p["hay"] is True and p["respaldo"] == "facturacr_20200110_020000.zip", p
    assert {g["id"]: g["reponer"] for g in p["grupos"]} == {op["id"]: {"productos": [pizza["id"]], "categorias": [], "tipo": "opcional", "fis": True},
                                                            ex["id"]: {"productos": [], "categorias": ["Postres"], "tipo": "extra", "fis": True}}, p
    r = c.post("/api/pos/modificadores/recuperar", json={"respaldo": p["respaldo"]}); assert r.status_code == 200, r.text
    guardados = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert guardados[op["id"]]["categorias"] == [] and guardados[ex["id"]]["productos"] == []        # el grupo vuelve a tener la clave
    assert not (set(CAMPOS) & set(guardados[900]))
    # después de recuperar ya no sale el aviso (aunque se vuelvan a leer todos los respaldos)
    _olvidar()
    assert c.get("/api/pos/modificadores/recuperar").json() == {"hay": False, "grupos": [], "incompleta": False}
    assert c.post("/api/pos/modificadores/recuperar", json={"respaldo": "facturacr_20200105_020000.zip"}).status_code == 409
    pub = _publico(c)
    assert pub[pizza["id"]] == ["Tamaño QA"] and pub[flan["id"]] == ["Helado QA"] and pub[batido["id"]] == []
    # el aviso cuenta solo los grupos con algo que reponer: el 900, que en el respaldo más nuevo tenía solo listas vacías, no sale ni
    # deja que se busque en respaldos más viejos; los otros dos se ofrecen de su respaldo
    _danar(eid, {"Tamaño QA", "Helado QA"})
    with Session(engine_empresa(eid)) as s:
        grupos = modulos.leer(s, eid, "pos_modificadores", [])
    _grupos_directo(eid, [g for g in grupos if g["id"] != 900] + [_grupo(900, "Nuevo QA", productos=[], categorias=[])])
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200111_020000.zip")
    _grupos_directo(eid, [g for g in grupos if g["id"] != 900] + [_grupo(900, "Nuevo QA")])
    _olvidar()
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p["hay"] is True and p["respaldo"] == "facturacr_20200110_020000.zip" and {g["id"] for g in p["grupos"]} == {op["id"], ex["id"]}, p
    r = c.post("/api/pos/modificadores/recuperar", json={"respaldo": p["respaldo"]}); assert r.status_code == 200, r.text
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False


# ------------------------------------------------------------------------------------------------ H3
def test_h3_la_pantalla_no_manda_asignaciones_viejas(api, tmp_path):  # noqa: F811
    """Pestaña 1: Punto de venta › Configuración abierta. Pestaña 2: FISITAAP › Extras quita Pizza de «Queso», sube el precio de «Salsa»
    y crea «Aguacate». En la pestaña 1 se sube el precio de Queso, se quita «Tamaño» y se guarda: Queso queda sin Pizza (lo que quitó
    FISITAAP no revive), Salsa conserva su precio nuevo, Aguacate no se borra y Tamaño, quitado aquí, sí se borra."""
    c = api; eid = _eid()
    pizza, flan, batido = _negocio(c, eid)
    queso = c.post("/api/fisitaap/extras", json={"nombre": "Queso QA", "precio": 300, "productos": [pizza["id"]]}).json()
    salsa = c.post("/api/fisitaap/extras", json={"nombre": "Salsa QA", "precio": 200, "categorias": ["Bebidas"]}).json()
    with Session(engine_empresa(eid)) as s:
        grupos = modulos.leer(s, eid, "pos_modificadores", [])
    _grupos_directo(eid, grupos + [_grupo(10, "Tamaño QA")])
    pestana = _registro(c, "pos_modificadores")["datos"]                                          # lo que la pestaña 1 cargó al abrir
    assert c.put(f"/api/fisitaap/extras/{queso['id']}", json={"nombre": "Queso QA", "precio": 300, "productos": []}).status_code == 200
    assert c.put(f"/api/fisitaap/extras/{salsa['id']}", json={"nombre": "Salsa QA", "precio": 350, "categorias": ["Bebidas"]}).status_code == 200
    agua = c.post("/api/fisitaap/extras", json={"nombre": "Aguacate QA", "precio": 500, "productos": [flan["id"]]}).json()
    servidor = _registro(c, "pos_modificadores")
    r = _pantalla(tmp_path, pestana, """
vm.mods.find(g => g.nombre === 'Queso QA').opciones[0].precio = 800;
vm.quitarMod(vm.mods.findIndex(g => g.nombre === 'Tamaño QA'));
await vm.guardarMods();
""", servidor=servidor["datos"], tope=servidor["ultimo_id"])
    assert r["toasts"] == [["Modificadores guardados", "ok"]] and "/api/registros/pos_modificadores" in r["pedidos"], r
    enviado = {g["id"]: g for g in r["enviados"][-1]}
    assert enviado[queso["id"]]["productos"] == [] and enviado[queso["id"]]["opciones"][0]["precio"] == 800, enviado
    assert enviado[salsa["id"]] == next(g for g in pestana if g["id"] == salsa["id"])                # no cambió aquí: igual a la copia, no se manda
    _subir(c, pestana, r["enviados"][-1])
    guardado = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert guardado[queso["id"]]["productos"] == [] and guardado[queso["id"]]["opciones"][0]["precio"] == 800, guardado
    assert guardado[salsa["id"]]["opciones"][0]["precio"] == 350 and agua["id"] in guardado and 10 not in guardado, guardado
    pub = _publico(c)
    assert pub[pizza["id"]] == [] and pub[flan["id"]] == ["Aguacate QA"] and pub[batido["id"]] == ["Salsa QA"], pub
    # si no se puede leer lo guardado en este momento, no se guarda nada (no se manda la copia vieja)
    r = _pantalla(tmp_path, pestana, "vm.mods[0].opciones[0].precio = 999; await vm.guardarMods();", sin_red=True)
    assert r["enviados"] == [] and len(r["toasts"]) == 1 and r["toasts"][0][1] == "err" and "Sin conexión" in r["toasts"][0][0], r


# ------------------------------------------------------------------------------------------------ H4
class _Vigia:
    """recuperar_mods.modulos con un gancho: anota el orden en que se toma el registro y se leen los grupos, y la primera vez que se leen
    los grupos DESPUÉS de tomar el registro, otra persona guarda (como un extra que se guarda en FISITAAP mientras corre el POST)."""
    def __init__(self, real, otro):
        self._real, self._otro, self.orden = real, otro, []

    def __getattr__(self, nombre):
        return getattr(self._real, nombre)

    def _registro(self, s, eid, clave):
        self.orden.append(("registro", clave))
        return self._real._registro(s, eid, clave)

    def leer(self, s, eid, clave, defecto=None):
        if clave == recuperar_mods.CLAVE:
            self.orden.append(("leer", clave))
            if self._otro and ("registro", clave) in self.orden:
                otro, self._otro = self._otro, None
                otro()
        return self._real.leer(s, eid, clave, defecto)


def test_h4_aplicar_toma_la_version_antes_de_leer_los_grupos(api, tmp_path, monkeypatch):  # noqa: F811
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    op, ex = _extras_fisitaap(c, pizza)
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")
    _danar(eid, {"Tamaño QA", "Helado QA"})

    def otro_guarda():
        with Session(engine_empresa(eid)) as s2:
            grupos = modulos.leer(s2, eid, "pos_modificadores", [])
            nuevo = _grupo(77, "En medio QA", 100, productos=[flan["id"]], categorias=[], tipo="extra", fis=True)
            modulos.reemplazar(s2, eid, "pos_modificadores", grupos + [nuevo], modulos._registro(s2, eid, "pos_modificadores").version); s2.commit()

    vigia = _Vigia(modulos, otro_guarda)
    monkeypatch.setattr(recuperar_mods, "modulos", vigia)
    with Session(engine_empresa(eid)) as s:
        with pytest.raises(modulos.ConflictoRegistro):
            recuperar_mods.aplicar(s, eid, "facturacr_20200110_020000.zip")
    assert vigia.orden[0] == ("registro", recuperar_mods.CLAVE), vigia.orden                     # la versión se toma antes de leer los grupos
    monkeypatch.setattr(recuperar_mods, "modulos", modulos)
    guardado = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert 77 in guardado and not (set(CAMPOS) & set(guardado[op["id"]])), guardado                  # no se pisó lo de la otra persona
    # sin nadie en medio se recupera, y lo que guardó la otra persona se conserva
    r = c.post("/api/pos/modificadores/recuperar", json={"respaldo": "facturacr_20200110_020000.zip"}); assert r.status_code == 200, r.text
    guardado = {g["id"]: g for g in _registro(c, "pos_modificadores")["datos"]}
    assert 77 in guardado and guardado[op["id"]]["productos"] == [pizza["id"]] and guardado[ex["id"]]["categorias"] == ["Postres"]


# ------------------------------------------------------------------------------------------------ H5
def test_h5_respaldo_lento_queda_anotado_y_no_se_relee(api, tmp_path, monkeypatch):  # noqa: F811
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    _extras_fisitaap(c, pizza)
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")                # antes del daño
    _danar(eid, {"Tamaño QA", "Helado QA"})
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200111_020000.zip")                # después del daño: se lee, no decide nada
    lecturas, real = [], recuperar_mods._descomprimir

    def lento(z, info, destino, hasta):
        nombre = pathlib.Path(z.filename).name
        lecturas.append(nombre)
        if nombre == "facturacr_20200110_020000.zip":
            raise recuperar_mods._SinTiempo()                    # este zip no alcanza a descomprimirse en el tiempo de una petición
        return real(z, info, destino, hasta)

    monkeypatch.setattr(recuperar_mods, "_descomprimir", lento)
    # 1) llega después de otro zip que esta petición ya descomprimió: no se anota; la próxima petición empieza por él
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p == {"hay": False, "grupos": [], "incompleta": True} and lecturas == ["facturacr_20200111_020000.zip", "facturacr_20200110_020000.zip"], (p, lecturas)
    # 2) con todo el tiempo de la petición tampoco alcanza: queda anotado como no leído y no se ofrece nada de respaldos más viejos
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p == {"hay": False, "grupos": [], "incompleta": False} and lecturas[2:] == ["facturacr_20200110_020000.zip"], (p, lecturas)
    # 3) las peticiones siguientes no lo vuelven a descomprimir, aunque se vuelva a revisar
    getattr(recuperar_mods, "_revisado", {}).clear()
    for _ in range(3):
        assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False
    assert len(lecturas) == 3, lecturas


def test_h5_sin_nada_nuevo_pendiente_no_se_revisan_respaldos(api, tmp_path, monkeypatch):  # noqa: F811
    """Un grupo creado en Punto de venta nunca tiene esas claves. Después de una revisión completa que no encontró nada, abrir otra vez
    Configuración, Extras u Opcionales no vuelve a revisar los respaldos mientras lo pendiente siga igual; si cambia, sí."""
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    op, ex = _extras_fisitaap(c, pizza)
    with Session(engine_empresa(eid)) as s:
        grupos = modulos.leer(s, eid, "pos_modificadores", [])
    _grupos_directo(eid, grupos + [_grupo(50, "Término QA")])
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")
    vistos, real = [], recuperar_mods._grupos_del_respaldo
    monkeypatch.setattr(recuperar_mods, "_grupos_del_respaldo", lambda r, *a, **k: (vistos.append(r["nombre"]), real(r, *a, **k))[1])
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False and vistos == ["facturacr_20200110_020000.zip"], vistos
    for _ in range(3):
        assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is False
    assert vistos == ["facturacr_20200110_020000.zip"], vistos                                       # no se volvió a revisar
    # cambia lo pendiente (un guardado viejo le borra las asignaciones a «Helado»): se revisa otra vez y se ofrece recuperarlo
    _danar(eid, {"Helado QA"})
    p = c.get("/api/pos/modificadores/recuperar").json()
    assert p["hay"] is True and {g["id"] for g in p["grupos"]} == {ex["id"]} and len(vistos) == 2, (p, vistos)


# ------------------------------------------------------------------------------------------------ H6
def _sinc_local(eid, datos):
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "sinc_local")
        modulos.reemplazar(s, eid, "sinc_local", datos, (r.version or 0) if r else 0); s.commit()


def test_h6_en_el_programa_conectado_no_se_ofrece_recuperar(api, tmp_path, monkeypatch):  # noqa: F811
    """En el programa de escritorio conectado a la web, lo recuperado de los respaldos de esa computadora lo pisa la bajada: no se ofrece
    ni se acepta; la respuesta trae la línea que manda a recuperar en la página web. Sin conectar (o revocado) sí se recupera ahí."""
    from app import sinc
    c = api; eid = _eid()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "respaldos")
    _olvidar()
    pizza, flan, batido = _negocio(c, eid)
    op, ex = _extras_fisitaap(c, pizza)
    _respaldo_general(respaldo.RESPALDOS_DIR, eid, "facturacr_20200110_020000.zip")
    _danar(eid, {"Tamaño QA", "Helado QA"})
    assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is True                         # en la página web sí sale
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    try:
        _sinc_local(eid, {"vinculado": True, "url": "https://web.example.test"})
        p = c.get("/api/pos/modificadores/recuperar").json()
        assert p["hay"] is False and p.get("en_la_web") is True and p["grupos"] == [], p
        assert p["aviso_web"] == recuperar_mods.EN_LA_WEB and "se recuperan en la página web" in p["aviso_web"]
        r = c.post("/api/pos/modificadores/recuperar", json={"respaldo": "facturacr_20200110_020000.zip"})
        assert r.status_code == 409 and r.json()["detail"] == recuperar_mods.EN_LA_WEB, r.text
        assert not (set(CAMPOS) & set(next(g for g in _registro(c, "pos_modificadores")["datos"] if g["id"] == op["id"])))
        _sinc_local(eid, {"vinculado": False})                                                        # programa sin conectar: se recupera ahí
        assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is True
        _sinc_local(eid, {"vinculado": True, "revocada_en": "2026-11-01T00:00:00"})                   # conexión revocada: ya no baja nada
        assert c.get("/api/pos/modificadores/recuperar").json()["hay"] is True
    finally:
        _sinc_local(eid, {})


def test_h6_la_pantalla_muestra_la_linea_de_la_web(tmp_path):
    url = "/api/pos/modificadores/recuperar"
    web = {"hay": False, "grupos": [], "incompleta": False, "en_la_web": True, "aviso_web": "Esta computadora está conectada a la página web: QA."}
    r = _pantalla(tmp_path, [], "await vm.cargarRecuperar();", respuestas={url: web}, programa=True)
    assert r["recMods"] is None and r["recEnWeb"] == web["aviso_web"], r
    hay = {"hay": True, "respaldo": "facturacr_20200110_020000.zip", "fecha": "10/01/2020", "incompleta": False,
           "grupos": [{"id": 1, "nombre": "Queso", "reponer": {"productos": [7], "categorias": [], "tipo": "extra", "fis": True}, "productos_nombres": ["Pizza"]}]}
    r = _pantalla(tmp_path, [], "await vm.cargarRecuperar();", respuestas={url: hay})
    assert r["recEnWeb"] == "" and r["recMods"]["lineas"] == [{"id": 1, "nombre": "Queso", "texto": "productos: Pizza; vuelve a mostrarse como extra en FISITAAP"}], r
    cfg = _js("pages/pos/configuracion.js")
    assert "recEnWeb:" in _tramo(cfg, "  data() {", "  computed: {")
    assert '<p class="small muted" style="margin:8px 0 0" v-if="recEnWeb">{{recEnWeb}}</p><p class="small muted" style="margin:8px 0 0" v-else>Si un extra u opcional' in cfg
