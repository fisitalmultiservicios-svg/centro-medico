# -*- coding: utf-8 -*-
"""4.39, decimoquinta vuelta de los arreglos (17 nov 2026), la última: lo que quedaba de la casilla de la cantidad en 0 (V2 de la decimotercera vuelta y
U2 de la decimocuarta). Una prueba por cada cambio.

- T1 la fila del carrito (plantilla de caja.js): <div v-for="(l,i) in lineas" :key="l" class="pos-linea"> (antes :key="i"). Con 0 en la casilla de la
  cantidad, su «change» llama a quitar; eso pasaba en el mousedown del clic siguiente (la casilla pierde el cursor) y, con la posición como llave, Vue
  volvía a pintar las filas en su lugar: el botón donde se soltaba el clic era el mismo elemento, ya con el plato que subió a esa posición (el «+» de la
  Limonada le sumaba al Postre; el «+» del plato quitado, a la Limonada) y la casilla con el cursor quedaba en otro plato. Se prueba con la fila REAL de la
  plantilla montada con el Vue 3.4 del árbol (vendor/vue.esm-browser.prod.min.js) en Node, sobre un DOM mínimo (createRenderer) que sigue el clic como
  el navegador: el clic llega al botón solo si al soltar es el mismo elemento del mousedown. Si hay Playwright con Chromium en el entorno, también en un
  navegador de verdad (si no, esa prueba se salta sola).
- T2 tecla(e): con F9, F8 o F4 y el cursor en una casilla numérica, el valor de la casilla solo frena si es la de la cantidad (e.target.closest(
  '.pos-linea .c'); sin closest, como antes: frena). Con el precio a mano en 0 o vacío (cfg.precio_editable) la tecla pedía dos pulsaciones; ahora F9 abre
  el cobro, F8 manda la comanda y F4 guarda en la primera. Con un plato en 0 en las líneas frena siempre, como antes.
- Contrato: los 2 pares de DECIMOQUINTA (tests/test_439_tercera_vuelta.py; deshechos dan, byte a byte, el caja.js de antes de la vuelta), el resto de
  caja.js igual, un comentario «4.39 (decimoquinta vuelta)», el de la tercera vuelta otra vez al final de la línea de la habitación, y las notas.
Cada caso que muestra el defecto corre también con lo de ANTES de esta vuelta (la plantilla y tecla de _caja_sin_decimoquinta).
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import re

import pytest

from tests.test_425_ultimos_pantallas import _node
from tests.test_431_misma_mesa_pantallas import RAIZ, _js, _linea, _metodo, _tramo
from tests.test_439_decimocuarta_vuelta import AYUDAS as AYUDAS14
from tests.test_439_decimocuarta_vuelta import _mas
from tests.test_439_decimotercera_vuelta import AYUDAS as AYUDAS13
from tests.test_439_decimotercera_vuelta import CASADO1, GUARDADA, LIMONADA1, QUITAR, _expresion, _extras
from tests.test_439_revision_arreglos import CASADO, _caja
from tests.test_439_tercera_vuelta import COM3, DECIMOQUINTA, NUEVA_U2, VIEJA_U2, _caja_sin_decimoquinta
from tests.test_439_undecima_vuelta import _correr as _correr11

FILA = '<div v-for="(l,i) in lineas" :key="l" class="pos-linea">'
FILA_ANTES = '<div v-for="(l,i) in lineas" :key="i" class="pos-linea">'
HAB = "      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }"
VUE = "vendor/vue.esm-browser.prod.min.js"


def _fila(k: str) -> str:
    """La fila del carrito de la plantilla: desde su <div v-for> hasta su </div> (la única fila de `lineas`)."""
    assert k.count('<div v-for="(l,i) in lineas"') == 1
    i = k.index('<div v-for="(l,i) in lineas"')
    j = k.index("\n          </div>", i) + len("\n          </div>")
    fila = k[i:j]
    # va tal cual a Vue: dentro del template de caja.js no lleva escapes ni ${ } (si los llevara, el texto no sería el que ve Vue)
    assert "\\" not in fila and "${" not in fila and "`" not in fila
    return fila


# ================================================================================================================ T1: la llave de la fila
def test_t1_la_fila_del_carrito_usa_la_linea_como_llave():
    k, k0 = _caja(), _caja_sin_decimoquinta()
    f, f0 = _fila(k), _fila(k0)
    # ahora la fila se identifica por su línea; antes, por su posición
    assert f.startswith(FILA) and k.count(FILA) == 1 and k.count(FILA_ANTES) == 0, f[:120]
    assert f0.startswith(FILA_ANTES) and k0.count(FILA) == 0
    # fuera de la llave, la fila no cambió
    assert f.replace(FILA, FILA_ANTES, 1) == f0
    # dentro de la fila no se usa la posición `i` (ni en las expresiones ni en las interpolaciones): todo va por `l`
    dentro = f[len(FILA):]
    exprs = re.findall(r'\s(?::|@|v-)[\w.:-]*="([^"]*)"', dentro) + re.findall(r"\{\{(.*?)\}\}", dentro)
    assert len(exprs) > 15, exprs
    for e in exprs:
        sin_textos = re.sub(r"'[^']*'", "''", e)
        assert not re.search(r"(?<![\w$.])i(?![\w$])", sin_textos), e
    # la casilla de la cantidad es la única entrada numérica dentro de un .c de la fila (es lo que busca T2); la del precio está en .d
    c = _tramo(dentro, '<div class="c">', "</div>")
    d = _tramo(dentro, '<div class="d">', '<div class="c">')
    assert c.count('type="number"') == 1 and 'v-model.number="l.cantidad"' in c
    assert d.count('type="number"') == 1 and 'v-model.number="l.precio_unitario"' in d and "@change" not in d
    assert dentro.count('type="number"') == 2


# la fila real de la plantilla montada con el Vue del árbol en Node: un DOM mínimo (elementos con hijos, padre, props y oyentes; closest para selectores
# de clases «.a .b», como el navegador) y la vista con lo que la fila usa. quitar es el de caja.js (con el plato sin enviar quita enseguida);
# cambiarCantidad anota el plato del «+» o «−» que recibió el clic. Los errores y avisos de Vue se juntan (en producción no se lanzan)
CASOS_VUE = r"""
import * as Vue from './js/vendor/vue.esm-browser.prod.min.js';
const errores = [];
console.warn = (...a) => errores.push('warn: ' + a.map(String).join(' '));
console.error = (...a) => errores.push('error: ' + a.map(x => x && x.stack ? x.stack : String(x)).join(' '));
globalThis.document = { activeElement: null };   // v-model mira el cursor al volver a pintar
const FILA = @FILA@;
const clases = el => String((el.props && el.props.class) || '').split(/\s+/).filter(Boolean);
const casa = (el, sel) => !!el && sel.startsWith('.') && clases(el).includes(sel.slice(1));
function closest(sel) {
  const partes = sel.trim().split(/\s+/);
  for (let el = this; el; el = el.parent) {
    if (!casa(el, partes[partes.length - 1])) continue;
    let ok = true, p = el.parent;
    for (let q = partes.length - 2; q >= 0; q--) { while (p && !casa(p, partes[q])) p = p.parent; if (!p) { ok = false; break; } p = p.parent; }
    if (ok) return el;
  }
  return null;
}
const elemento = tag => ({ tag, children: [], parent: null, props: {}, oyentes: {}, value: '', type: undefined, closest,
  addEventListener(t, f) { (this.oyentes[t] || (this.oyentes[t] = [])).push(f); }, removeEventListener(t, f) { this.oyentes[t] = (this.oyentes[t] || []).filter(x => x !== f); } });
const ops = {
  insert(c, p, a) { if (c.parent) ops.remove(c); const i = a ? p.children.indexOf(a) : -1; if (i >= 0) p.children.splice(i, 0, c); else p.children.push(c); c.parent = p; },
  remove(c) { const p = c.parent; if (p) { p.children.splice(p.children.indexOf(c), 1); c.parent = null; } },
  createElement: elemento,
  createText: text => ({ tag: '#text', text, parent: null }),
  createComment: text => ({ tag: '#comment', text, parent: null }),
  setText(nd, text) { nd.text = text; },
  setElementText(el, text) { for (const c of el.children) c.parent = null; el.children = text === '' ? [] : [{ tag: '#text', text, parent: el }]; },
  parentNode: nd => nd.parent,
  nextSibling(nd) { const p = nd.parent; return p ? p.children[p.children.indexOf(nd) + 1] || null : null; },
  querySelector: () => null,
  setScopeId() {},
  patchProp(el, key, prev, next) { el.props[key] = next; if (key === 'type') el.type = next; if (key === 'value') el.value = next; },
};
const C = {
  template: '<div class="pos-carrito">' + FILA + '</div>',
  data: () => ({ lineas: [], cfg: { precio_editable: true }, esRestaurante: true, clics: [] }),
  methods: {
    money: v => '₡' + (+v || 0).toFixed(2), fmt: (v, d) => (+v || 0).toFixed(d), horaCorta: s => String(s || ''),
    descuentoDe: () => 0, lineaTotal: l => (+l.cantidad || 0) * (+l.precio_unitario || 0),
    pedirDescuento() {}, abrirNota() {}, aplicarPromos() {}, cuentaVacia() {},
    cambiarCantidad(l, d) { this.clics.push([l.detalle, d]); l.cantidad = (+l.cantidad || 0) + d; },
    @QUITAR@,
  },
};
const raiz = elemento('#raiz');
const vm = Vue.createRenderer(ops).createApp(C).mount(raiz);
const texto = nd => nd.tag === '#text' ? nd.text : nd.tag === '#comment' ? '' : (nd.children || []).map(texto).join('');
const buscar = (nd, f) => { if (f(nd)) return nd; for (const c of nd.children || []) { const r = buscar(c, f); if (r) return r; } return null; };
const filas = () => raiz.children.find(x => x.tag === 'div').children.filter(x => x.tag === 'div');
const enPagina = nd => { for (let x = nd; x; x = x.parent) if (x === raiz) return true; return false; };
const filaDe = nd => { for (let x = nd; x; x = x.parent) if (clases(x).includes('pos-linea')) return x; return null; };
const detalleDe = fila => fila ? texto(buscar(fila, x => x.tag === 'b')) : null;
const cantidadDe = fila => buscar(fila, x => x.tag === 'input' && !!x.closest('.pos-linea .c'));
const precioDe = fila => buscar(fila, x => x.tag === 'input' && !x.closest('.pos-linea .c'));
const masDe = fila => buscar(buscar(fila, x => clases(x).includes('c')), x => x.tag === 'button' && texto(x) === '+');
// un evento del navegador sobre el elemento: los oyentes de v-model y el @evento de la plantilla
const disparar = (el, tipo) => { for (const f of (el.oyentes[tipo] || []).slice()) f({ target: el, type: tipo }); const h = el.props['on' + tipo[0].toUpperCase() + tipo.slice(1)]; if (h) h({ target: el, type: tipo }); };
const plato = (lid, detalle, p) => ({ lid, detalle, cantidad: 1, precio_unitario: p, tarifa: 13 });
const out = {};
// Casado, Limonada y Postre (sin enviar). Se escribe 0 en la casilla del Casado (v-model) y se hace clic en el «+» de la fila `pos`: en el mousedown la
// casilla pierde el cursor (corre su «change»: quitar) y Vue vuelve a pintar antes de soltar; el clic llega al botón solo si al soltar, en ese mismo lugar
// (la fila `pos`), está el mismo elemento
async function clic(pos) {
  vm.lineas = [plato('a', 'Casado', 3500), plato('b', 'Limonada', 1500), plato('c', 'Postre', 1200)]; vm.clics = []; await Vue.nextTick();
  const f0 = filas(), inp = cantidadDe(f0[0]), antes = f0.map(detalleDe);
  inp.value = '0'; disparar(inp, 'input');
  const baja = masDe(f0[pos]);
  disparar(inp, 'change'); await Vue.nextTick();
  const f1 = filas(), suelta = f1[pos] ? masDe(f1[pos]) : null, mismo = !!suelta && suelta === baja;
  if (mismo) suelta.props.onClick({ target: suelta });
  await Vue.nextTick();
  return { antes, lineas: vm.lineas.map(l => l.detalle + ':' + l.cantidad), clics: vm.clics, filas: filas().map(detalleDe), mismo,
           baja: [enPagina(baja), detalleDe(filaDe(baja))], casilla: enPagina(inp) ? detalleDe(filaDe(inp)) : null };
}
out.pos1 = await clic(1);
out.pos0 = await clic(0);
// las dos casillas numéricas de la fila real y la expresión de T2 (`cant`) sobre cada una, con un 0
{ vm.lineas = [plato('a', 'Casado', 3500)]; await Vue.nextTick(); const f = filas()[0];
  const CANT = new Function('e', 'return (' + @CANT@ + ');');
  const c = cantidadDe(f), p = precioDe(f);
  out.casillas = { cantidad: [c.type, c.props['onChange'] ? 'change' : null, CANT({ target: c })], precio: [p.type, p.props['onChange'] ? 'change' : null, CANT({ target: p })] }; }
out.errores = errores;
console.log(JSON.stringify(out));
process.exit(0);
"""


def _cant() -> str:
    """La expresión de T2 que dice si el cursor está en la casilla de la cantidad (la de la línea de tecla)."""
    m = re.search(r"const v = e\.target\.value, cant = (.*?); e\.target\.blur\(\);", NUEVA_U2)
    return m.group(1)


def _correr_vue(tmp_path, k):
    guion = CASOS_VUE.replace("@FILA@", json.dumps(_fila(k))).replace("@QUITAR@", _linea(_caja(), QUITAR)).replace("@CANT@", json.dumps(_cant()))
    return _node(tmp_path, guion, [VUE], {})


def test_t1_el_clic_despues_del_0_no_cae_en_otro_plato_con_vue_en_node(tmp_path):
    assert '"3.4.' in _js(VUE)   # el Vue 3.4 del árbol
    r = _correr_vue(tmp_path / "ahora", _caja())
    assert r["errores"] == [], r["errores"]
    for pos in ("pos1", "pos0"):
        x = r[pos]
        # el Casado sale (su casilla en 0) y su fila se va con él (la casilla con el cursor ya no está en la página); las otras filas suben con sus platos.
        # Al soltar, en ese lugar hay otro botón: el clic no llega a ningún «+» y ningún plato cambia
        assert x["antes"] == ["Casado", "Limonada", "Postre"] and x["filas"] == ["Limonada", "Postre"], (pos, x)
        assert x["mismo"] is False and x["clics"] == [] and x["lineas"] == ["Limonada:1", "Postre:1"] and x["casilla"] is None, (pos, x)
    # el botón del mousedown sigue con su plato: el de la Limonada en la página; el del Casado se fue con su fila
    assert r["pos1"]["baja"] == [True, "Limonada"] and r["pos0"]["baja"] == [False, "Casado"], r
    # T2 sobre la fila real: la casilla de la cantidad (con su «change») es la de la cantidad; la del precio (sin «change») no
    assert r["casillas"] == {"cantidad": ["number", "change", True], "precio": ["number", None, False]}, r["casillas"]

    # antes de esta vuelta (:key="i"): Vue repintaba cada fila en su posición; al soltar, el botón era el mismo elemento, ya con el plato que subió: el «+»
    # de la Limonada le sumaba al Postre y el del Casado (quitado) a la Limonada; la casilla con el cursor quedaba en la fila de la Limonada
    v = _correr_vue(tmp_path / "antes", _caja_sin_decimoquinta())
    assert v["errores"] == [], v["errores"]
    assert v["pos1"]["mismo"] is True and v["pos1"]["clics"] == [["Postre", 1]] and v["pos1"]["lineas"] == ["Limonada:1", "Postre:2"], v["pos1"]
    assert v["pos0"]["mismo"] is True and v["pos0"]["clics"] == [["Limonada", 1]] and v["pos0"]["lineas"] == ["Limonada:2", "Postre:1"], v["pos0"]
    assert v["pos1"]["casilla"] == "Limonada" and v["pos1"]["baja"] == [True, "Postre"], v["pos1"]
    assert v["casillas"] == r["casillas"]


# la misma fila en Chromium (Playwright), con el DOM y los eventos del navegador: la página se sirve desde una dirección falsa interceptada (nada sale a
# la red). Se escribe 0 en la casilla del Casado y se hace clic con el mouse en el «+» de la Limonada
PAGINA = """<!doctype html><html><head><meta charset="utf-8"><style>
.pos-linea{display:flex;align-items:center;height:48px;overflow:hidden}.pos-linea .d{width:260px}.pos-linea .c{width:160px}.pos-linea .t{width:160px}
button{width:32px;height:32px}</style></head><body><div id="app"></div><script type="module" src="prueba.js"></script></body></html>"""
PRUEBA_JS = r"""
import { createApp } from './vue.js';
const plato = (lid, detalle, p) => ({ lid, detalle, cantidad: 1, precio_unitario: p, tarifa: 13 });
window.vm = createApp({
  template: '<div class="pos-carrito">' + @FILA@ + '</div>',
  data: () => ({ lineas: [plato('a', 'Casado', 3500), plato('b', 'Limonada', 1500), plato('c', 'Postre', 1200)], cfg: { precio_editable: true }, esRestaurante: true, clics: [] }),
  methods: {
    money: v => '₡' + (+v || 0).toFixed(2), fmt: (v, d) => (+v || 0).toFixed(d), horaCorta: s => String(s || ''),
    descuentoDe: () => 0, lineaTotal: l => (+l.cantidad || 0) * (+l.precio_unitario || 0),
    pedirDescuento() {}, abrirNota() {}, aplicarPromos() {}, cuentaVacia() {},
    cambiarCantidad(l, d) { this.clics.push([l.detalle, d]); l.cantidad = (+l.cantidad || 0) + d; },
    @QUITAR@,
  },
}).mount('#app');
window.resultado = () => ({ lineas: window.vm.lineas.map(l => l.detalle + ':' + l.cantidad), clics: window.vm.clics });
window.listo = true;
"""


def _en_chromium(k):
    sync_api = pytest.importorskip("playwright.sync_api")
    archivos = {"index.html": (PAGINA, "text/html"), "vue.js": (_js(VUE), "text/javascript"),
                "prueba.js": (PRUEBA_JS.replace("@FILA@", json.dumps(_fila(k))).replace("@QUITAR@", _linea(_caja(), QUITAR)), "text/javascript")}
    with sync_api.sync_playwright() as pw:
        try:
            nav = pw.chromium.launch()
        except Exception as e:   # sin el Chromium de Playwright instalado
            pytest.skip("sin Chromium para Playwright: %s" % str(e).splitlines()[0])
        try:
            pag = nav.new_page()

            def servir(ruta):
                nombre = ruta.request.url.rsplit("/", 1)[-1]
                if ruta.request.url.startswith("http://caja.test/") and nombre in archivos:
                    ruta.fulfill(status=200, body=archivos[nombre][0], content_type=archivos[nombre][1] + "; charset=utf-8")
                else:
                    ruta.abort()   # nada sale a la red
            pag.route("**/*", servir)
            pag.goto("http://caja.test/index.html")
            pag.wait_for_function("window.listo === true")
            casilla = pag.locator(".pos-linea").nth(0).locator(".c input")
            casilla.click()
            casilla.fill("0")   # el «input» de v-model; el «change» llega cuando la casilla pierde el cursor
            caja = pag.locator(".pos-linea").nth(1).locator(".c button").nth(1).bounding_box()
            x, y = caja["x"] + caja["width"] / 2, caja["y"] + caja["height"] / 2
            pag.mouse.move(x, y)
            pag.mouse.down()
            pag.wait_for_timeout(50)
            pag.mouse.up()
            pag.wait_for_timeout(100)
            return pag.evaluate("window.resultado()")
        finally:
            nav.close()


def test_t1_el_clic_despues_del_0_no_cae_en_otro_plato_en_chromium():
    r = _en_chromium(_caja())
    # el Casado sale; el clic en el «+» de la Limonada no le suma a otro plato (en ese lugar quedó el Postre)
    assert r == {"lineas": ["Limonada:1", "Postre:1"], "clics": []}, r
    # antes de esta vuelta: el clic le sumaba al Postre
    v = _en_chromium(_caja_sin_decimoquinta())
    assert v == {"lineas": ["Limonada:1", "Postre:2"], "clics": [["Postre", 1]]}, v


# ================================================================================================================ T2: el precio a mano en 0
AYUDAS = r"""
// la casilla de la cantidad del plato con el cursor, como en la página: closest('.pos-linea .c') la encuentra (está dentro del .c de su fila)
const enCantidad = (vm, l) => Object.assign(casillaDe(vm, l), { selectores: [], closest(s) { this.selectores.push(s); return s === '.pos-linea .c' ? { clase: 'c' } : null; } });
// la casilla del precio a mano (cfg.precio_editable) del plato con el cursor: su valor es el precio; al dejarla no corre nada (no tiene «change»);
// closest('.pos-linea .c') no la encuentra (está en el .d de su fila)
const enPrecio = l => ({ type: 'number', blurs: 0, selectores: [], get value() { return String(l.precio_unitario ?? ''); }, blur() { this.blurs++; },
                         closest(s) { this.selectores.push(s); return null; } });
"""


def _correr(tmp_path, casos, antes=False):
    """El arnés de la decimocuarta vuelta (la casilla de la plantilla, cuentaDeMesa real, teclaEn, casillaDe) con estas ayudas; con `antes`, tecla como
    estaba antes de esta vuelta (lo demás no cambió en los métodos). Al final se quita el cursor."""
    k = _caja()
    expr = _expresion(k)
    assert expr == _expresion(_caja_sin_decimoquinta())
    mesa = _tramo(_js("pages/pos/_datos.js"), "export function ocupaMesa(", "\nexport const MESA_BASE").replace("export function ", "function ")
    ayudas = AYUDAS13.replace("@CASILLA@", json.dumps(expr)).replace("@MESA_REAL@", json.dumps(mesa)) + AYUDAS14 + AYUDAS
    viejos = (_metodo(_caja_sin_decimoquinta(), "tecla(e) {"),) if antes else ()
    return _correr11(tmp_path, ayudas + casos + "\nsinCursor();\n", antes=_extras() + _mas() + viejos)


CASOS_T2 = r"""
// un solo equipo: la Mesa 6 guardada con el Casado ya enviado y una Limonada sin enviar, con el precio a mano. El cursor está en (`donde`): 'sin', la
// casilla de la cantidad de la Limonada sin closest (como el arnés de la decimocuarta); 'cantidad', esa casilla en la página; 'precio', la casilla del
// precio de la Limonada. `q`: lo que tiene esa casilla (la cantidad o el precio de la Limonada). Con `cero`, además el Casado con 0 en la cantidad (no
// se da la clave de anular). Toca `key` una vez; si se abrió el cobro, cobra
async function t2(key, donde, q, cero) {
  const [id, a] = await cuenta(true, [{ ...CASADO(), ...ENV() }, LIMONADA()]);
  a.cfg.precio_editable = true;
  const pedidas = []; a.cfg.clave_anular = '1234'; a.autorizar = async t => { pedidas.push(t); return false; };
  const lim = a.lineas.find(x => x.detalle === 'Limonada'), cas = a.lineas.find(x => x.detalle === 'Casado');
  if (cero) cas.cantidad = 0;
  let c;
  if (donde === 'precio') { lim.precio_unitario = q; lim.precio_manual = true; c = enPrecio(lim); }
  else { lim.cantidad = q; c = donde === 'sin' ? casillaDe(a, lim) : enCantidad(a, lim); }
  const g0 = guardados();
  const pd = teclaEn(a, key, c); await espera(30); await a.A.mock.guardarTodo(); await hastaLibre();
  const r = { pd, blurs: c.blurs, selectores: c.selectores || null, vista: a.vista, pago: !!a.pago, platos: detalles(a), srv: srv(), impresos: quienes(a),
              guardados: guardados() - g0, pedidas, avisos: avisos(a).filter(t => !t.startsWith('Comanda ')) };
  if (a.pago) { r.total = a.totales.total; await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
  r.hechos = cobrados(a); r.suma = suma();
  return r;
}
for (const [nombre, key, donde, q, cero] of @CASOS@) out[nombre] = await t2(key, donde, q, cero);
"""
T2_CASOS = [
    # el precio a mano en 0 o vacío: la tecla sigue en la primera pulsación
    ["precio0_F9", "F9", "precio", 0, False], ["precio0_F8", "F8", "precio", 0, False], ["precio0_F4", "F4", "precio", 0, False],
    ["vacio_F9", "F9", "precio", "", False], ["vacio_F4", "F4", "precio", "", False],
    # la casilla de la cantidad en 0 (con closest o sin él): frena, como antes
    ["cant0_F9", "F9", "cantidad", 0, False], ["cant0_F4", "F4", "cantidad", 0, False], ["sin0_F9", "F9", "sin", 0, False], ["sin0_F8", "F8", "sin", 0, False],
    # la cantidad mayor que 0 con closest: sigue, como antes
    ["cant2_F9", "F9", "cantidad", 2, False],
    # un plato en 0 en las líneas: frena siempre (con el cursor en el precio, con 0 o con un precio)
    ["cero_precio0_F9", "F9", "precio", 0, True], ["cero_precio5_F9", "F9", "precio", 500, True], ["cero_precio5_F4", "F4", "precio", 500, True],
    ["cero_precio5_F8", "F8", "precio", 500, True],
]
# lo que deja una pulsación que no hizo nada (ni guardar, ni comanda, ni cobro), con la casilla dejada una vez
NADA = {"pd": True, "blurs": 1, "vista": "venta", "pago": False, "impresos": [], "guardados": 0, "avisos": [], "hechos": [], "suma": 0}


def _nada(x):
    return {k: x[k] for k in NADA}


def test_t2_el_precio_a_mano_en_0_no_pide_dos_pulsaciones_en_node(tmp_path):
    casos = CASOS_T2.replace("@CASOS@", json.dumps(T2_CASOS))
    r = _correr(tmp_path / "ahora", casos)
    srv0 = [["Mesa 6", ["Casado×1", "Limonada×1"], None]]   # la Mesa 6 como está guardada
    # el precio de la Limonada en 0 (o vacío) con el cursor: la casilla se deja (blur) y se pregunta si es la de la cantidad (no lo es); sin plato en 0, F9
    # abre el cobro en esa pulsación y se cobran el Casado y la Limonada a ₡0 (lo del Casado); F8 manda la Limonada a cocina; F4 guarda las dos
    for k in ("precio0_F9", "vacio_F9"):
        x = r[k]
        assert x["pd"] is True and x["blurs"] == 1 and x["selectores"] == [".pos-linea .c"] and x["pago"] is True and x["avisos"] == [], (k, x)
        assert x["total"] == CASADO and x["hechos"] == [["A", ["Casado×1", "Limonada×1"]]] and x["suma"] == CASADO and x["srv"] == srv0, (k, x)
    x = r["precio0_F8"]
    assert x["pd"] is True and x["blurs"] == 1 and x["impresos"] == [["A", LIMONADA1]] and x["pago"] is False and x["avisos"] == [], x
    assert x["srv"] == [["Mesa 6", ["Casado×1", "Limonada×1"], None]] and x["hechos"] == [], x
    for k in ("precio0_F4", "vacio_F4"):
        x = r[k]
        assert x["pd"] is True and x["blurs"] == 1 and x["vista"] == "mesas" and x["guardados"] == 1 and x["avisos"] == [GUARDADA], (k, x)
        assert x["srv"] == [["Mesa 6", ["Casado×1", "Limonada×1"], None]] and x["impresos"] == [] and x["hechos"] == [], (k, x)
    # la casilla de la cantidad en 0 (en la página, o sin closest): al dejarla sale la Limonada (sin enviar: sin clave) y no se sigue en esa pulsación
    for k in ("cant0_F9", "cant0_F4", "sin0_F9", "sin0_F8"):
        x = r[k]
        assert _nada(x) == NADA and x["platos"] == CASADO1 and x["srv"] == srv0 and x["pedidas"] == [], (k, x)
    assert r["cant0_F9"]["selectores"] == [".pos-linea .c"] and r["sin0_F9"]["selectores"] is None
    # la cantidad en 2 en la casilla de la página: F9 abre el cobro y se cobran el Casado y 2 Limonadas
    x = r["cant2_F9"]
    assert x["pago"] is True and x["hechos"] == [["A", ["Casado×1", "Limonada×2"]]] and x["avisos"] == [], x
    # el Casado (ya enviado) en 0 en las líneas: frena siempre, con el precio en 0 o con un precio, y no se pide la clave (la casilla con el cursor es otra)
    for k in ("cero_precio0_F9", "cero_precio5_F9", "cero_precio5_F4", "cero_precio5_F8"):
        x = r[k]
        assert _nada(x) == NADA and x["platos"] == ["Casado×0", "Limonada×1"] and x["srv"] == srv0 and x["pedidas"] == [], (k, x)

    # antes de esta vuelta: el valor de cualquier casilla numérica frenaba. Con el precio en 0 o vacío, la primera pulsación no hacía nada (había que tocar
    # la tecla otra vez); lo demás, igual
    v = _correr(tmp_path / "antes", casos, antes=True)
    for k in ("precio0_F9", "precio0_F8", "precio0_F4", "vacio_F9", "vacio_F4"):
        x = v[k]
        assert _nada(x) == NADA and x["selectores"] == [] and x["platos"] == ["Casado×1", "Limonada×1"] and x["srv"] == srv0, (k, x)
    for k in ("cant0_F9", "cant0_F4", "sin0_F9", "sin0_F8", "cero_precio0_F9", "cero_precio5_F9", "cero_precio5_F4", "cero_precio5_F8"):
        assert {**v[k], "selectores": None} == {**r[k], "selectores": None}, (k, v[k], r[k])
    assert v["cant2_F9"]["hechos"] == r["cant2_F9"]["hechos"] and v["cant2_F9"]["suma"] == r["cant2_F9"]["suma"], v["cant2_F9"]


# ================================================================================================================ contrato
def test_contrato_de_la_decimoquinta_vuelta():
    k, k0 = _caja(), _caja_sin_decimoquinta()
    # cada tripleta de DECIMOQUINTA: «lo de ahora» está en caja.js las veces anotadas y «lo de antes» ya no; se deshacen en orden inverso y al final queda
    # caja.js sin la vuelta (comprobado byte a byte contra la copia de caja.js de antes de la vuelta)
    assert len(DECIMOQUINTA) == 2
    estado = k
    for viejo, nuevo, veces in reversed(DECIMOQUINTA):
        assert estado.count(nuevo) == veces and k.count(nuevo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        assert k.count(viejo) == 0 and k0.count(viejo) == veces, viejo[:120]
        estado = estado.replace(nuevo, viejo)
    assert estado == k0
    # T1 en la plantilla y T2 en tecla; fuera de ellos caja.js no cambió
    te, te0 = _metodo(k, "tecla(e) {"), _metodo(k0, "tecla(e) {")
    assert te.count(DECIMOQUINTA[1][1]) == 1 and te0.count(DECIMOQUINTA[1][0]) == 1
    resto = k.replace(te, "@TECLA@").replace(FILA, "@FILA@")
    resto0 = k0.replace(te0, "@TECLA@").replace(FILA_ANTES, "@FILA@")
    assert resto == resto0
    # un solo comentario de esta vuelta (T2; T1 está en la plantilla)
    assert k.count("4.39 (decimoquinta vuelta)") == 1 and k0.count("4.39 (decimoquinta vuelta)") == 0 and te.count("4.39 (decimoquinta vuelta)") == 1
    # el comentario de la tercera vuelta volvió al final de la línea de la habitación (U2 lo había dejado al final de su propia línea)
    lineas = te.split("\n")
    assert lineas[1] == HAB + COM3 and te.count(COM3) == 1 and k.count(COM3) == 1
    assert te0.split("\n")[1] == HAB and te0.count(VIEJA_U2 + COM3) == 1
    # T2: la línea de U2 nueva, justo después de sus comentarios (decimocuarta y decimoquinta), sin comentario al final; el valor propio frena solo en la
    # casilla de la cantidad (sin closest, como antes), los platos en 0 frenan siempre
    i = lineas.index(NUEVA_U2)
    assert lineas[i - 1].startswith("      /* 4.39 (decimoquinta vuelta): el valor propio solo frena si es la casilla de la cantidad")
    assert lineas[i - 3].startswith("      /* 4.39 (decimocuarta vuelta): con el cursor en una casilla numérica") and i == 5
    assert te.index(HAB) < te.index(NUEVA_U2) < te.index("if (e.key === 'F9')") and VIEJA_U2 not in k
    for t in ("const v = e.target.value, cant = typeof e.target.closest !== 'function' || !!e.target.closest('.pos-linea .c'); e.target.blur();",
              "if ((cant && !(+v > 0)) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; }"):
        assert NUEVA_U2.count(t) == 1, t
    assert NUEVA_U2.index("const v = e.target.value") < NUEVA_U2.index("e.target.blur();")
    # T1: la fila con la línea como llave (ver test_t1_la_fila_del_carrito_usa_la_linea_como_llave)
    assert k.count(FILA) == 1 and ':key="i"' not in _fila(k)
    # las notas cuentan la vuelta: la frase de «Cantidad en 0» (la sincronización con la casilla de la cantidad en 0 o vacía), Técnico (la decimoquinta
    # vuelta, después de la decimocuarta) y la lista de pruebas; cada frase nueva una vez y ya no dicen lo de antes
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("hay que tocar la tecla otra vez. Mientras la casilla de la cantidad está en 0 o vacía, la caja no junta lo que cambiaron los otros equipos "
              "hasta salir de ella. Antes la pantalla lo escondía",
              "«A dónde» marca la mesa unida a esta cuenta. Decimoquinta vuelta: la fila del carrito usa la línea como llave (:key=\"l\"; con la posición, tras "
              "un 0 el clic siguiente caía en otro plato); en tecla, el valor de la casilla solo frena si es la de la cantidad.",
              "y de test_439_segunda_vuelta.py a test_439_decimoquinta_vuelta.py;"):
        assert notas.count(t) == 1, t
    assert notas.index("Decimocuarta vuelta: quitar devuelve") < notas.index("Decimoquinta vuelta: la fila del carrito")
    for t in ("Mientras se escribe una cantidad, la caja no se pone al día", "de test_439_segunda_vuelta.py a test_439_decimocuarta_vuelta.py"):
        assert notas.count(t) == 0, t
    # las pruebas que la lista nombra existen
    assert (RAIZ / "tests" / "test_439_decimoquinta_vuelta.py").exists()
