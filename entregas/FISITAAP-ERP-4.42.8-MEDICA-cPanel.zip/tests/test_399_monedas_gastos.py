# -*- coding: utf-8 -*-
"""3.99: reportes por moneda sin tipo de cambio (salvo «Convertir todo» y las declaraciones), reporte de Gastos completo, y
comprobantes internos (sin facturación electrónica) aunque la empresa no tenga actividad ni dirección."""
import pathlib
import types

from app import main

JS = pathlib.Path(main.__file__).parent / "static" / "js" / "pages" / "reportes"


def test_emisor_interno_sin_actividad_ni_direccion():
    e = types.SimpleNamespace(nombre="Perfumeria QA 399", tipo_id="02", numero_id="3101399399", nombre_comercial=None, actividad="", provincia=None, canton=None,
                              distrito=None, barrio=None, otras_senas="", telefono=None, correo="p399@example.test", registro_fiscal_8707=None, factura_electronica=False)
    p = main._parte_empresa(e)
    assert p.actividad is None and p.ubicacion is not None and p.ubicacion.otras_senas == "Costa Rica"


def test_reportes_por_moneda_y_gastos():
    r = (JS / "reporte.js").read_text(encoding="utf-8")
    assert "const EN_COLONES = ['declaracion-iva-d104', 'compras-trimestre']" in r
    assert "MODO.sinTc = (!this.convertir" in r and "(d.moneda || 'CRC') === p" in r and "Convertir todo a la moneda principal" in r
    assert "async 'gastos'(c)" in r and "'Gasto sin factura'" in r and "tipo: 'Planilla'" in r
    h = (JS / "hub.js").read_text(encoding="utf-8")
    assert "slug: 'gastos', nombre: 'Gastos'" in h and "gastos: P_RESUMEN" in h
