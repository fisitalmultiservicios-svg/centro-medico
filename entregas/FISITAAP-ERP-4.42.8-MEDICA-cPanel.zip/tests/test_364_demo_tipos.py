"""3.64: empresas demo por tipo de negocio con un mes de datos. Cada tipo crea su empresa con la base común (comprobantes, cobros,
proveedores, planilla) y lo propio: caja y ventas (comercio), FISITAAP con menú y pedidos (restaurante), hotel completo
(hospitalidad) y TiKe (servicios). La demo clásica (TecnoTropical) sigue igual."""
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth, demo, demo_tipos, modulos
from app.db import Documento, Empresa, Producto, engine, engine_empresa, init_db


def _crear(tipo, meses=1):
    init_db()
    with Session(engine) as s:
        e = demo.crear_empresa_demo(s, meses=meses, semilla=11, tipo=tipo)
        s.refresh(e); s.expunge(e)
    return e


def _reg(eid, clave):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, clave, None)


def _docs(eid):
    with Session(engine_empresa(eid)) as s:
        return s.exec(select(Documento).where(Documento.empresa_id == eid)).all()


def test_comercio_tiene_caja_sesiones_y_ventas():
    e = _crear("comercio")
    assert e.es_demo and e.tipo_negocio == "comercio" and "Minisúper" in e.nombre
    docs = _docs(e.id)
    tiquetes = [d for d in docs if d.tipo_documento == "04"]
    assert len(docs) >= 100 and len(tiquetes) > len(docs) * 0.7            # tienda: casi todo son tiquetes
    cfg = _reg(e.id, "pos_config")
    assert cfg["terminales"][0]["modo"] == "mostrador" and cfg["terminales"][0]["cuentas"]["01"] == "Caja general"
    cajas, ventas = _reg(e.id, "pos_cajas"), _reg(e.id, "pos_ventas")
    assert len(cajas) >= 20 and sum(1 for c in cajas if c["estado"] == "Cerrada") >= len(cajas) - 1
    assert len(ventas) == len(tiquetes) and all(v["caja_id"] and v["doc_id"] for v in ventas)
    assert [b["nombre"] for b in _reg(e.id, "bancos")][:1] == ["Banco Nacional · Cuenta corriente"]
    with Session(engine_empresa(e.id)) as s:
        assert all(p.visible_catalogo for p in s.exec(select(Producto).where(Producto.empresa_id == e.id)).all())


def test_restaurante_tiene_mesas_menu_en_linea_y_pedidos():
    from app.pedidos import NegocioPublico, Pedido, SlugPublico
    e = _crear("restaurante")
    term = _reg(e.id, "pos_config")["terminales"][0]
    assert term["modo"] == "restaurante" and len(term["mesas"]) == 8 and term["servicio_pct"] == 10
    with Session(engine_empresa(e.id)) as s:
        n = s.exec(select(NegocioPublico).where(NegocioPublico.empresa_id == e.id)).first()
        pedidos = s.exec(select(Pedido).where(Pedido.empresa_id == e.id)).all()
    assert n and n.activo and n.slug.endswith(f"-{e.id}") and n.presentacion == "menu"
    assert len(pedidos) == 18 and all(p.total > 0 and p.lineas.startswith("[") for p in pedidos)
    with Session(engine) as sc:
        assert sc.exec(select(SlugPublico).where(SlugPublico.empresa_id == e.id)).first().slug == n.slug
    from app.main import app
    c = TestClient(app)
    r = c.get(f"/api/publico/{n.slug}")
    assert r.status_code == 200 and len(r.json()["items"]) >= 10


def test_hospitalidad_tiene_hotel_reservas_cuentas_y_cierres():
    e = _crear("hospitalidad")
    cfg = _reg(e.id, "hotel_config")
    assert cfg["activo"] and cfg["moneda"] == "USD" and cfg["tarifas"]["1"]["base"] == 65
    assert len(_reg(e.id, "hotel_categorias")) == 3 and len(_reg(e.id, "hotel_habitaciones")) == 12 and len(_reg(e.id, "hotel_huespedes")) == 14
    reservas, folios, cierres = _reg(e.id, "hotel_reservas"), _reg(e.id, "hotel_folios"), _reg(e.id, "hotel_cierres")
    estados = {r["estado"] for r in reservas}
    assert {"salio", "en_casa", "confirmada"} <= estados and len(reservas) >= 40
    assert all(r["numero"].startswith("R-") and r["total"] > 0 for r in reservas)
    en_casa = [r for r in reservas if r["estado"] == "en_casa"]
    assert en_casa and all(any(f["reserva_id"] == r["id"] and f["origen"] == "hospedaje" for f in folios) for r in en_casa)
    assert len(cierres) >= 27 and all("resumen" in c and c["resumen"]["total"] == 12 for c in cierres)


def test_servicios_tiene_tickets_contratos_y_equipos():
    from app.tike import Ticket, TicketEntrada, TikeConfig
    from app.tike_contratos import Contrato, Equipo
    e = _crear("servicios")
    with Session(engine_empresa(e.id)) as s:
        cfg = s.exec(select(TikeConfig).where(TikeConfig.empresa_id == e.id)).first()
        tickets = s.exec(select(Ticket).where(Ticket.empresa_id == e.id)).all()
        entradas = s.exec(select(TicketEntrada).where(TicketEntrada.empresa_id == e.id)).all()
        contratos = s.exec(select(Contrato).where(Contrato.empresa_id == e.id)).all()
        equipos = s.exec(select(Equipo).where(Equipo.empresa_id == e.id)).all()
    assert cfg and cfg.portal_activo
    assert len(tickets) >= 15 and {t.estado for t in tickets} & {"cerrado", "resuelto"} and all(t.codigo.startswith("TK-") for t in tickets)
    assert len(entradas) >= len(tickets) // 2 and len(contratos) == 4 and len(equipos) >= 8


def test_demo_clasica_sigue_igual_y_ruta_admin():
    e = _crear("facturacion")
    assert e.nombre == "TecnoTropical Demo S.A." and e.tipo_negocio == "facturacion"
    assert _reg(e.id, "pos_cajas") is None                                 # la clásica no lleva caja
    from app.main import app
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-364@example.test")).first()
        if not u:
            u = auth.Usuario(correo="sa-364@example.test", nombre="SA 364", password_hash=auth.hash_password("Clave-Segura-364-QA!"), es_superadmin=True)
            s.add(u); s.commit(); s.refresh(u)
        sa = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
    app.dependency_overrides[auth.superadmin] = lambda: sa
    try:
        c = TestClient(app)
        assert c.post("/api/admin/demo", json={"tipo": "inventado"}).status_code == 400
        r = c.post("/api/admin/demo", json={"tipo": "facturacion", "meses": 1, "nombre": "Oficina Demo Ruta S.A."})
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["nombre"] == "Oficina Demo Ruta S.A." and j["tipo"] == "facturacion"
        with Session(engine) as s:
            d = s.get(Empresa, j["empresa_id"])
            assert d.es_demo and d.nombre_comercial == "Oficina Demo Ruta S.A."
            sa_u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-364@example.test")).first()
            s.delete(sa_u); s.commit()
    finally:
        app.dependency_overrides.clear()
