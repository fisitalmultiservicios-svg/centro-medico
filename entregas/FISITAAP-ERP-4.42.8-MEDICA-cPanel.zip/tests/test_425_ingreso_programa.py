# -*- coding: utf-8 -*-
"""4.25 (X2, lado del programa, tanda 3): el ingreso diario del programa local con la cuenta de la web.

El programa (FE_MODO_LOCAL=1) instala los ganchos auth.ingreso_nube y auth.dos_pasos_nube: el ingreso de quien viene de la nube (o no
existe aquí) se pregunta a la web por /api/sinc/ingreso, solo a sinc.URL_NUBE, y la respuesta se lee con D-G: un sobre válido se obedece
(un «rechazado» nunca cae a lo guardado), sin respuesta se valida con lo guardado (sesión marcada sin_nube), 429/422 no entran, 404 según
la versión anotada. Las cuentas creadas en la computadora siguen como hoy.

Nube y computadora corren en el mismo proceso y comparten la tabla de usuarios (ver tests/test_49_local_sinc.py): por eso aquí una
persona «de la nube» se crea con de_nube=True (como si ya hubiera bajado) y lo que la web contesta se fuerza con el simulador cuando
hace falta que la ficha sea distinta de la fila real."""
import logging
import time
from datetime import datetime, timedelta, timezone

import httpx
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, engine
from test_49_local_sinc import (NUBE, PW, H, _admin_empresa, _bloquear_en_nube, _cfg, _modo_local_ingreso, _poner_cfg, _Respuesta,
                                _vincular, c)

INGRESO, FICHA, USUARIOS, DOS_PASOS = "/api/sinc/ingreso", "/api/sinc/usuario", "/api/sinc/usuarios", "/api/sinc/ingreso/dos-pasos"


def _pareja(monkeypatch, sufijo: str, a: str, b: str):
    """Nube (a) y computadora (b) vinculadas, con los ganchos del ingreso instalados. La computadora «solo tiene» su empresa: las
    empresas vinculadas que dejaron otras pruebas en la misma base no cuentan."""
    eid_a, ta = _admin_empresa(sufijo + "n", a)
    eid_b, tb = _admin_empresa(sufijo + "l", b)
    shim = _modo_local_ingreso(monkeypatch)
    _vincular(monkeypatch, ta, tb, "Caja")
    _solo_estas(monkeypatch, eid_b)
    shim.llamadas.clear()                                                   # la vinculación (canje) no cuenta
    return eid_a, ta, eid_b, tb, shim


def _solo_estas(monkeypatch, *eids) -> None:
    real = sinc._vinculadas
    monkeypatch.setattr(sinc, "_vinculadas", lambda: [x for x in real() if x[0] in eids])


def _persona(eid_nube: int, nombre: str, rol: str = "Cajero", local: int | None = None, pw: str = PW, **campos) -> tuple[int, str]:
    """Una persona de la empresa de la nube; con `local`, también miembro de la empresa de la computadora (como tras una bajada)."""
    correo = f"{nombre}@example.test"
    campos.setdefault("de_nube", True)
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(pw), terminos_version=auth.TERMINOS_VERSION,
                         terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa", **campos)
        sc.add(u); sc.commit(); sc.refresh(u)
        if eid_nube:
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_nube, rol=rol))
        if local:
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=local, rol=rol))
        sc.commit()
        return u.id, correo


def _usuario(uid: int) -> auth.Usuario:
    with Session(engine) as sc:
        return sc.get(auth.Usuario, uid)


def _poner(uid: int, **cambios) -> None:
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid)
        for k, v in cambios.items():
            setattr(u, k, v)
        sc.add(u); sc.commit()


def _sobre(ingreso: str, motivo: str | None = None, **extra) -> dict:
    return {"servicio": sinc.SERVICIO_INGRESO, "ingreso": ingreso, "motivo": motivo, "mensaje": sinc.MENSAJES_INGRESO.get(motivo or "", ""),
            "version": "4.25", **extra}


def _ficha(uid: int, **cambios) -> dict:
    u = _usuario(uid)
    f = {"correo": u.correo, "nombre": u.nombre, "password_hash": u.password_hash, "pin_hash": u.pin_hash, "bloqueado": False,
         "terminos_version": auth.TERMINOS_VERSION, "paleta": "turquesa", "rol": "Cajero", "sucursal_id": None, "modulos_ocultos": None,
         "mfa": "", "mfa_entrar": False, "mfa_rrhh": False, "temporal": False}
    f.update(cambios)
    return f


def _sesion_vieja(uid: int, sid: str) -> None:
    with Session(engine) as sc:
        sc.add(auth.Sesion(sid=sid, usuario_id=uid)); sc.commit()


def _revocada(sid: str) -> bool:
    with Session(engine) as sc:
        return bool(sc.exec(select(auth.Sesion).where(auth.Sesion.sid == sid)).first().revocada)


def _entrar(correo: str, pw: str = PW):
    return c.post("/api/auth/login", json={"correo": correo, "password": pw})


def _llamadas(shim, ruta: str) -> int:
    return len([x for x in shim.llamadas if x[1] == ruta])


def _sesion_de(token: str) -> auth.Sesion:
    sid = auth.abrir(token)["sid"]
    with Session(engine) as sc:
        return sc.exec(select(auth.Sesion).where(auth.Sesion.sid == sid)).first()


def _ultima_auditoria(uid: int, accion: str):
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == accion).order_by(Auditoria.id.desc())).first()


def _miembro(uid: int, eid: int) -> bool:
    with Session(engine) as sc:
        return sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid, auth.UsuarioEmpresa.empresa_id == eid)).first() is not None


def _hace(minutos: int) -> str:
    return (datetime.now(timezone.utc) - timedelta(minutes=minutos)).isoformat(timespec="seconds")


# ------------------------------------------------------------------------------------------------------------------------------
def test_en_linea_entra_y_refresca_lo_guardado(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p1", "3101425201", "3101425202")
    uid, correo = _persona(eid_a, "cajero.p1", local=eid_b)
    # de verdad, contra la web del mismo proceso
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["usuario"]["de_nube"] is True and j["usuario"]["sin_nube"] is False and j["usuario"]["dos_pasos_en_web"] is False
    assert _llamadas(shim, INGRESO) == 1 and _sesion_de(j["token"]).sin_nube is False
    assert _usuario(uid).nube_validado is not None
    assert _ultima_auditoria(uid, "login").detalle == "Validado en la web"
    assert _ultima_auditoria(uid, "login_programa") is not None                     # la web anotó el ingreso del programa
    # la web manda otro hash (la contraseña se cambió allá con el mismo texto): se guarda y se cierran las otras sesiones
    _sesion_vieja(uid, "sid-p1-vieja")
    nuevo = auth.hash_password(PW)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=_ficha(uid, password_hash=nuevo)))
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    assert _usuario(uid).password_hash == nuevo and _revocada("sid-p1-vieja") and _sesion_de(j["token"]).revocada
    # un «ok» con una ficha que no cuadra no guarda nada y no entra
    for f in (_ficha(uid, correo="otro.p1@example.test"), _ficha(uid, password_hash=auth.hash_password("Otra-Clave-p1-2026"))):
        shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=f))
        r = _entrar(correo)
        assert r.status_code == 503 and r.json()["detail"] == sinc.NO_CONFIRMADO and "token" not in r.json(), r.text
    assert _usuario(uid).password_hash == nuevo


def test_un_rechazo_de_la_web_nunca_cae_a_lo_guardado(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p2", "3101425203", "3101425204")
    uid, correo = _persona(eid_a, "cajero.p2", local=eid_b)
    _sesion_vieja(uid, "sid-p2")
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "credenciales"))
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid)))     # sigue siendo miembro: la contraseña es la mala
    r = _entrar(correo)                                                      # la contraseña coincide con lo guardado aquí
    assert r.status_code == 401 and "token" not in r.json(), r.text
    assert _usuario(uid).password_hash == sinc.HASH_INSERVIBLE and _revocada("sid-p2")
    assert _llamadas(shim, FICHA) == 1 and shim.llamadas[-1][2] == {"correo": correo}
    assert "la web rechazó el ingreso" in _ultima_auditoria(uid, "login_fallido").detalle
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")                  # y sin internet lo guardado ya no sirve
    assert _entrar(correo).status_code == 403                  # 9b (D-R): el motivo, sin fallo
    # bloqueado en la web: no entra, queda bloqueado aquí y se cierran sus sesiones
    uid2, correo2 = _persona(eid_a, "bloqueado.p2", local=eid_b)
    _sesion_vieja(uid2, "sid-p2b")
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "bloqueado"))
    r = _entrar(correo2)
    assert r.status_code == 403 and "bloqueada" in r.json()["detail"] and _usuario(uid2).bloqueado and _revocada("sid-p2b")
    # ya no es miembro de esa empresa (D-H): se entera por su ficha y se quita SOLO esa membresía
    uid3, correo3 = _persona(eid_a, "retirado.p2", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "credenciales"))
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=False, usuario=None))
    assert _entrar(correo3).status_code == 401
    assert not _miembro(uid3, eid_b) and _miembro(uid3, eid_a)
    # contraseña temporal sin cambiar en la web: el mensaje de la web
    uid4, correo4 = _persona(eid_a, "temporal.p2", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "temporal"))
    r = _entrar(correo4)
    assert r.status_code == 403 and "fisitaap.com" in r.json()["detail"] and _usuario(uid4).temporal_nube


def test_sin_respuesta_entra_con_lo_guardado_y_queda_anotado(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p3", "3101425205", "3101425206")
    uid, correo = _persona(eid_a, "cajero.p3", local=eid_b)
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["usuario"]["sin_nube"] is True and _sesion_de(j["token"]).sin_nube is True and _llamadas(shim, INGRESO) == 1
    assert _ultima_auditoria(uid, "login").detalle == "Sin internet: validado con lo guardado en esta computadora"
    assert c.get("/api/auth/yo", headers=H(j["token"])).json()["usuario"]["sin_nube"] is True
    # tiempo agotado: sin contacto reciente de la sincronización, una sola llamada; con contacto en los últimos 5 minutos, un reintento
    shim.por_ruta[INGRESO] = httpx.ReadTimeout("lento")
    _poner_cfg(eid_b, ultima_bajada=None, ultima_subida=None, usuarios_bajada=None)
    antes = _llamadas(shim, INGRESO)
    assert _entrar(correo).json()["usuario"]["sin_nube"] is True and _llamadas(shim, INGRESO) == antes + 1
    _poner_cfg(eid_b, ultima_bajada=_hace(1))
    antes = _llamadas(shim, INGRESO)
    assert _entrar(correo).json()["usuario"]["sin_nube"] is True and _llamadas(shim, INGRESO) == antes + 2
    # respuestas que no son el sobre: 502, HTML con 200 (wifi con portal), JSON ajeno, 403 de un cortafuegos
    for resp in (_Respuesta(502, None, "<html>Bad gateway</html>"), _Respuesta(200, None, "<html>Portal del wifi</html>"),
                 _Respuesta(200, {"ok": True}), _Respuesta(403, {"detail": "Forbidden"}), _Respuesta(200, {**_sobre("ok"), "servicio": "otro"})):
        shim.por_ruta[INGRESO] = resp
        r = _entrar(correo)
        assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True, (resp.status_code, r.text)
    # la instalación revocada en la web (señal explícita) o no reconocida: lo guardado, como en la 4.9
    for resp in (_Respuesta(401, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "x"}}), _Respuesta(200, _sobre("sin_acceso", "token"))):
        shim.por_ruta[INGRESO] = resp
        assert _entrar(correo).json()["usuario"]["sin_nube"] is True
    # sin internet valen los topes locales: cinco contraseñas malas dejan en espera también la buena
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    for _ in range(auth.MAX_INTENTOS):
        assert _entrar(correo, "Clave-Mala-p3-2026").status_code == 401
    assert _entrar(correo).status_code == 429


def test_429_422_y_la_web_ocupada_no_entran(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p4", "3101425207", "3101425208")
    uid, correo = _persona(eid_a, "cajero.p4", local=eid_b)
    real = _usuario(uid).password_hash
    for resp in (_Respuesta(429, {"detail": "Demasiados intentos"}), _Respuesta(422, {"detail": [{"loc": ["body"], "input": {}}]}),
                 _Respuesta(200, _sobre("rechazado", "tope")), _Respuesta(200, _sobre("rechazado", "error"))):
        shim.por_ruta[INGRESO] = resp
        antes = _llamadas(shim, INGRESO)
        r = _entrar(correo)
        assert r.status_code == 503 and "token" not in r.json(), r.text
        assert _llamadas(shim, INGRESO) == antes + 2                       # un reintento
    assert r.json()["detail"] == sinc.MENSAJES_INGRESO["error"]
    assert _usuario(uid).password_hash == real                              # no deja inservible lo guardado
    with Session(engine) as sc:                                             # ni cuenta fallos locales
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_fallo", auth.IntentoIp.ip.endswith("|" + correo))).all()
    # espera de la web: no entra (429) y tampoco es un fallo local
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "espera"))
    assert _entrar(correo).status_code == 429


def test_404_segun_la_version_anotada(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p5", "3101425209", "3101425210")
    uid, correo = _persona(eid_a, "cajero.p5", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(404, {"detail": "Not Found"})
    _poner_cfg(eid_b, version_nube=None)                                    # nunca contestó la bajada liviana: web anterior
    assert _entrar(correo).json()["usuario"]["sin_nube"] is True
    _poner_cfg(eid_b, version_nube="4.24")
    assert _entrar(correo).json()["usuario"]["sin_nube"] is True
    _poner_cfg(eid_b, version_nube="4.25")                                  # una web que ya trae la ruta no puede contestar 404
    r = _entrar(correo)
    assert r.status_code == 503 and r.json()["detail"] == sinc.NO_CONFIRMADO
    shim.por_ruta[INGRESO] = _Respuesta(405, {"detail": "Method Not Allowed"})
    assert _entrar(correo).status_code == 503


def test_sin_internet_solo_entra_quien_ya_entro_en_linea_y_no_usa_dos_pasos(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p6", "3101425211", "3101425212")
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    uid, correo = _persona(eid_a, "nuevo.p6", local=eid_b)
    _poner(uid, password_hash=sinc.HASH_INSERVIBLE)                          # nunca entró en línea aquí: bajó el hash inservible
    assert _entrar(correo).json()["detail"] == sinc.SIN_VALIDAR_AQUI   # 9b (D-R): 403 con el motivo
    uid2, correo2 = _persona(eid_a, "jefa.p6", rol="Administrador", local=eid_b, mfa_nube="huella-p6", mfa_entrar_nube=True)
    r = _entrar(correo2)
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_INTERNET_MFA and "token" not in r.json()
    assert _entrar(correo2, "Clave-Mala-p6-2026").status_code == 401         # con la contraseña mala, lo de siempre
    _, correo3 = _persona(eid_a, "temporal.p6", local=eid_b, temporal_nube=True)
    r = _entrar(correo3)
    assert r.status_code == 403 and "contraseña temporal" in r.json()["detail"]
    _, correo4 = _persona(eid_a, "admin.p6", rol="Administrador", local=eid_b, mfa_entrar_nube=True)    # la web le exige activarlos
    r = _entrar(correo4)
    assert r.status_code == 403 and "Mi perfil" in r.json()["detail"]
    _, correo5 = _persona(0, "nadie-aqui.p6")                               # no es miembro de ninguna empresa de esta computadora
    r = _entrar(correo5)
    assert r.status_code == 403 and "no tiene empresas" in r.json()["detail"] and "token" not in r.json()


def test_otra_direccion_no_recibe_la_contrasena(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p7", "3101425213", "3101425214")
    uid, correo = _persona(eid_a, "cajero.p7", local=eid_b)
    for url in ("https://fisitaap.com", ""):                                # conectada a otra dirección, o FE_NUBE_URL dudosa
        monkeypatch.setattr(sinc, "URL_NUBE", url)
        shim.llamadas.clear()
        r = _entrar(correo)
        assert r.status_code == 200, r.text
        assert r.json()["aviso_ingreso"] == sinc.OTRA_DIRECCION and r.json()["usuario"]["sin_nube"] is True
        assert shim.llamadas == []                                          # cero llamadas: la contraseña no sale
    assert "otra dirección" in _ultima_auditoria(uid, "login").detalle


def test_dos_empresas_vinculadas(monkeypatch):
    eid_a1, ta1 = _admin_empresa("-p8n1", "3101425215")
    eid_b1, tb1 = _admin_empresa("-p8l1", "3101425216")
    eid_a2, ta2 = _admin_empresa("-p8n2", "3101425217")
    eid_b2, tb2 = _admin_empresa("-p8l2", "3101425218")
    shim = _modo_local_ingreso(monkeypatch)
    _vincular(monkeypatch, ta1, tb1, "Caja 1")
    _vincular(monkeypatch, ta2, tb2, "Caja 2")
    _solo_estas(monkeypatch, eid_b1, eid_b2)
    shim.llamadas.clear()
    # aquí no es miembro de nada: se pregunta con cada empresa vinculada hasta la que la reconoce (la de la empresa 2)
    uid, correo = _persona(eid_a2, "cajera.p8")
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    assert _llamadas(shim, INGRESO) == 2 and _miembro(uid, eid_b2) and not _miembro(uid, eid_b1)
    # miembro aquí de las dos, y en la web solo de la 2: con una contraseña mala, la 1 dice que ya no es miembro y la 2 que sí
    uid2, correo2 = _persona(eid_a2, "mesero.p8")
    with Session(engine) as sc:
        for eid in (eid_b1, eid_b2):
            sc.add(auth.UsuarioEmpresa(usuario_id=uid2, empresa_id=eid, rol="Cajero"))
        sc.commit()
    assert _entrar(correo2).status_code == 200                              # entra por la 2 (la 1 dijo «credenciales»)
    assert _miembro(uid2, eid_b1)
    assert _entrar(correo2, "Clave-Mala-p8-2026").status_code == 401
    assert not _miembro(uid2, eid_b1) and _miembro(uid2, eid_b2)            # solo se quitó la que contestó que ya no es miembro
    assert _usuario(uid2).password_hash != sinc.HASH_INSERVIBLE
    antes = _llamadas(shim, INGRESO)
    assert _entrar(correo2).status_code == 200 and _llamadas(shim, INGRESO) == antes + 1     # ahora solo se pregunta a la 2
    # nadie la reconoce: no entra
    _, ajena = _persona(0, "ajena.p8")
    assert _entrar(ajena).status_code == 401


def test_bajada_temporal_conserva_la_membresia_y_el_cambio_de_hash_cierra_sesiones(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p9", "3101425219", "3101425220")
    uid, correo = _persona(eid_a, "temporal.p9", local=eid_b)
    _sesion_vieja(uid, "sid-p9")
    with Session(engine) as sc:                                             # la contraseña cambió en la web (otro hash real): cierra sus sesiones
        sinc._bajar_usuarios(sc, eid_b, {"usuarios": [_ficha(uid, password_hash=auth.hash_password(PW))], "roles": []})
    assert _revocada("sid-p9")
    _sesion_vieja(uid, "sid-p9b")
    with Session(engine) as sc:
        sinc._bajar_usuarios(sc, eid_b, {"usuarios": [_ficha(uid, password_hash=sinc.HASH_INSERVIBLE, pin_hash=sinc.HASH_INSERVIBLE, temporal=True)], "roles": []})
    u = _usuario(uid)
    # revisión de las tandas 3 y 4: el paso al hash inservible no es un cambio de contraseña (se guarda, pero no cierra sesiones;
    # ver tests/test_425_correcciones_3_4.py)
    assert _miembro(uid, eid_b) and u.temporal_nube and u.password_hash == sinc.HASH_INSERVIBLE and not _revocada("sid-p9b")
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    assert _entrar(correo).status_code == 403                               # ni sin internet
    # una ficha sin hash tampoco la saca de la empresa (queda con el hash inservible)
    uid2, _ = _persona(eid_a, "sinhash.p9", local=eid_b)
    with Session(engine) as sc:
        sinc._bajar_usuarios(sc, eid_b, {"usuarios": [_ficha(uid, password_hash=sinc.HASH_INSERVIBLE, temporal=True), _ficha(uid2, password_hash=None)], "roles": []})
    assert _miembro(uid2, eid_b) and _usuario(uid2).password_hash == sinc.HASH_INSERVIBLE
    # los dos pasos de la web bajan como huella y lo que dijo la web
    uid3, _ = _persona(eid_a, "jefa.p9", local=eid_b)
    with Session(engine) as sc:
        sinc._bajar_usuarios(sc, eid_b, {"usuarios": [_ficha(uid, password_hash=sinc.HASH_INSERVIBLE, temporal=True), _ficha(uid2, password_hash=None),
                                                      _ficha(uid3, mfa="huella-p9", mfa_entrar=True, mfa_rrhh=True)], "roles": []})
    u3 = _usuario(uid3)
    assert u3.mfa_nube == "huella-p9" and u3.mfa_entrar_nube and not u3.temporal_nube
    with Session(engine) as sc:                                             # lo de Recursos humanos es de la empresa de la ficha: va en la membresía
        m3 = sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid3, auth.UsuarioEmpresa.empresa_id == eid_b)).first()
        assert m3.mfa_rrhh_nube is True and not hasattr(u3, "mfa_rrhh_nube")


def test_la_bajada_de_usuarios_corre_primero_aunque_fallen_las_novedades(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p10", "3101425221", "3101425222")
    uid, correo = _persona(eid_a, "cajero.p10", local=eid_b)
    _sesion_vieja(uid, "sid-p10")
    shim.por_ruta[USUARIOS] = _Respuesta(200, _sobre("ok", sin_cambios=False, huella="h1", usuarios=[_ficha(uid, bloqueado=True)], roles=[], empresa_bloqueada=False))
    shim.por_ruta["/api/sinc/novedades"] = _Respuesta(500, None, "<html>error</html>")
    est = sinc.sincronizar(eid_b)
    assert est["ultimo_error"] and "500" in est["ultimo_error"]
    assert shim.llamadas[0][:2] == ("post", USUARIOS) and shim.llamadas[0][2] == {"huella": ""}      # primero, con la huella
    assert _usuario(uid).bloqueado and _revocada("sid-p10")
    cfg = _cfg(eid_b)
    assert cfg["usuarios_huella"] == "h1" and cfg["version_nube"] == "4.25" and cfg["usuarios_bajada"] and not sinc.usuarios_atrasados(cfg)
    # con la empresa bloqueada en la web (el resto del ciclo no tiene acceso) los usuarios llegan igual
    _bloquear_en_nube(eid_a, True)
    try:
        shim.por_ruta.pop("/api/sinc/novedades")
        shim.por_ruta[USUARIOS] = _Respuesta(200, _sobre("ok", sin_cambios=False, huella="h2", usuarios=[_ficha(uid, rol="Vendedor")], roles=[]))
        shim.llamadas.clear()
        sinc.sincronizar(eid_b)
        assert shim.llamadas[0][2] == {"huella": "h1"} and not _usuario(uid).bloqueado
        with Session(engine) as sc:
            assert sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid, auth.UsuarioEmpresa.empresa_id == eid_b)).first().rol == "Vendedor"
    finally:
        _bloquear_en_nube(eid_a, False)
    # sin cambios: no toca nada y anota la fecha
    _poner_cfg(eid_b, usuarios_bajada=_hace(30))
    assert sinc.usuarios_atrasados(_cfg(eid_b))                             # más de 10 minutos habiendo internet: avisa
    shim.por_ruta[USUARIOS] = _Respuesta(200, _sobre("ok", sin_cambios=True, huella="h2"))
    shim.por_ruta["/api/sinc/novedades"] = _Respuesta(500, None, "x")
    sinc.sincronizar(eid_b)
    assert not sinc.usuarios_atrasados(_cfg(eid_b)) and _cfg(eid_b)["usuarios_huella"] == "h2"
    # una computadora conectada a otra dirección no la llama (le bajaría el hash inservible a todos)
    monkeypatch.setattr(sinc, "URL_NUBE", "https://fisitaap.com")
    shim.llamadas.clear()
    sinc.sincronizar(eid_b)
    assert _llamadas(shim, USUARIOS) == 0


def test_cuenta_creada_en_la_computadora_entra_como_hoy(monkeypatch):
    assert auth.ingreso_nube is None and auth.dos_pasos_nube is None          # en la web (sin FE_MODO_LOCAL) los ganchos están vacíos
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p11", "3101425223", "3101425224")
    j = _entrar("duena-sinc49-p11l@example.test").json()                    # la administradora creada aquí, con sus dos pasos de aquí
    assert j.get("mfa_requerido") is True and auth.abrir(j["token_mfa"])["tipo"] == "mfa"
    uid, correo = _persona(0, "cajero-local.p11", local=eid_b, de_nube=False)
    r = _entrar(correo)
    assert r.status_code == 200 and r.json()["usuario"]["de_nube"] is False and r.json()["usuario"]["sin_nube"] is False
    assert shim.llamadas == []                                              # cero llamadas a la web


def test_dos_pasos_con_internet_pasan_por_la_web(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p12", "3101425225", "3101425226")
    secreto = auth.nuevo_secreto()
    uid, correo = _persona(eid_a, "jefa.p12", rol="Administrador", mfa_activo=True, mfa_secret=auth._cifrar_mfa(secreto))
    j = _entrar(correo).json()
    assert j.get("mfa_requerido") is True and "token" not in j
    datos = auth.abrir(j["token_mfa"])
    assert datos["tipo"] == auth.TIPO_MFA_NUBE and datos["eid"] == eid_b and "password" not in str(datos)
    malo = "000000" if auth.codigo_totp(secreto) != "000000" else "111111"
    r = c.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": malo})
    assert r.status_code == 401 and r.json()["detail"] == "Código de verificación incorrecto"
    r = c.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": auth.codigo_totp(secreto, time.time() + 30)})
    assert r.status_code == 200, r.text
    s = r.json()
    assert s["usuario"]["dos_pasos_en_web"] is True and s["usuario"]["mfa_obligatorio"] is False and s["usuario"]["sin_nube"] is False
    assert _usuario(uid).mfa_nube and _miembro(uid, eid_b)
    # se va la conexión en el segundo paso: no entra
    j = _entrar(correo).json()
    shim.por_ruta[DOS_PASOS] = httpx.ConnectError("sin red")
    r = c.post("/api/auth/mfa/verificar", json={"token_mfa": j["token_mfa"], "codigo": auth.codigo_totp(secreto, time.time() + 60)})
    assert r.status_code == 503 and r.json()["detail"] == sinc.SIN_CONEXION_CODIGO
    # sin internet quien usa los dos pasos no entra desde un navegador sin la marca de que ya pasó su código aquí (tanda 4: con la
    # marca sí; ver tests/test_425_ingreso_dos_pasos_pin.py)
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    marca = c.cookies.get(auth.COOKIE_MFA_AQUI)
    assert marca                                                            # la entregó el ingreso con código de arriba
    c.cookies.delete(auth.COOKIE_MFA_AQUI)
    r = _entrar(correo)
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_INTERNET_MFA
    # el token «mfa_nube» no sirve en la web (sin los ganchos)
    monkeypatch.setattr(auth, "dos_pasos_nube", None)
    tok = auth.firmar({"tipo": auth.TIPO_MFA_NUBE, "t": "x", "eid": eid_b, "correo": correo}, 300)
    assert c.post("/api/auth/mfa/verificar", json={"token_mfa": tok, "codigo": auth.codigo_totp(secreto)}).status_code == 401


def test_al_que_viene_de_la_nube_no_se_le_pide_otro_dos_pasos(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p13", "3101425227", "3101425228")
    uid, correo = _persona(eid_a, "admin.p13", rol="Administrador", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=_ficha(uid, rol="Administrador", mfa_rrhh=True)))   # p. ej. con su renuncia en la web
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["usuario"]["mfa_obligatorio"] is False and j["usuario"]["mfa_exigido_rol"] is False and j["usuario"]["dos_pasos_en_web"] is False
    t = c.post("/api/auth/empresa", headers=H(j["token"]), json={"empresa_id": eid_b}).json()["token"]
    assert c.get("/api/sinc/local/aviso", headers=H(t)).status_code == 200      # contexto() no le pide activar otros dos pasos aquí
    assert "rrhh_requiere_mfa" in c.get("/api/auth/yo", headers=H(t)).json()
    _poner(uid, mfa_entrar_nube=True)                                       # la web dice que le faltan
    r = c.get("/api/sinc/local/aviso", headers=H(t))
    assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_FALTA_MFA_WEB
    for metodo, ruta, cuerpo in (("post", "/api/auth/mfa/activar", None), ("post", "/api/auth/mfa/confirmar", {"codigo": "123456"}),
                                 ("post", "/api/auth/mfa/respaldo", {"codigo": "123456"}), ("post", "/api/auth/mfa/desactivar", {"codigo": "123456"}),
                                 ("post", "/api/auth/mfa/renuncia", {"version": "x", "acepta": True, "asume_responsabilidad": True, "password": PW, "confirmacion": "ACEPTO"}),
                                 ("delete", "/api/auth/mfa/renuncia", None)):
        r = getattr(c, metodo)(ruta, headers=H(t), **({"json": cuerpo} if cuerpo is not None else {}))
        assert r.status_code == 400 and r.json()["detail"] == auth.MENSAJE_SOLO_WEB_MFA, (ruta, r.text)
    # el enlace de recuperación tampoco cambia la contraseña aquí (la administra la nube)
    real = _usuario(uid).password_hash
    enlace = auth._token_recuperacion(_usuario(uid))
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    r = c.post("/api/auth/restablecer", json={"token": enlace, "nueva": "Otra-Clave-Nueva-p13-2026"})
    # 4.25 (tanda 6): en el programa real la ruta está apagada (403 solo_web: se hace en la página web)
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web" and _usuario(uid).password_hash == real
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")                                # modo soporte: la ruta responde, y la cuenta de la nube sigue sin cambiar aquí
    r = c.post("/api/auth/restablecer", json={"token": enlace, "nueva": "Otra-Clave-Nueva-p13-2026"})
    monkeypatch.delenv("FE_LOCAL_ADMIN")
    monkeypatch.delenv("FE_MODO_LOCAL")
    assert r.status_code == 400 and "la administra la nube" in r.json()["detail"] and _usuario(uid).password_hash == real


def test_ni_el_registro_ni_ultimo_error_ni_la_auditoria_tienen_la_contrasena(monkeypatch, caplog):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-p14", "3101425229", "3101425230")
    clave, mala = "Clave-Secreta-p14-QA-2026", "Mala-Secreta-p14-QA-2026"
    uid, correo = _persona(eid_a, "cajero.p14", local=eid_b, pw=clave)
    with Session(engine) as sc:
        desde = max([a.id for a in sc.exec(select(Auditoria)).all()] or [0])
    eco = _Respuesta(422, {"detail": [{"type": "missing", "loc": ["body"], "input": {"correo": correo, "password": clave}}]})   # un 422 que repite el cuerpo
    with caplog.at_level(logging.DEBUG):
        for resp in (eco, _Respuesta(429, {"detail": clave}), httpx.ConnectError(clave), _Respuesta(502, None, clave), None):
            shim.por_ruta[INGRESO] = resp
            _entrar(correo, clave)
        shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "credenciales"))
        shim.por_ruta[FICHA] = eco
        _entrar(correo, mala)
        shim.por_ruta[USUARIOS] = eco
        shim.por_ruta["/api/sinc/novedades"] = _Respuesta(422, {"detail": [{"input": {"password": clave}}]}, clave)
        sinc.sincronizar(eid_b)
    texto = caplog.text + str(_cfg(eid_b).get("ultimo_error") or "") + str(_cfg(eid_b))
    assert clave not in texto and mala not in texto
    with Session(engine) as sc:
        filas = sc.exec(select(Auditoria).where(Auditoria.id > desde)).all()
        assert any(a.accion == "login" for a in filas) and any(a.accion == "login_fallido" for a in filas)
        for a in filas:
            assert clave not in (a.detalle or "") and mala not in (a.detalle or "") and clave not in (a.correo or "")
