# -*- coding: utf-8 -*-
"""4.25: correcciones de la revisión de las tandas 6b y 7 (conexión de una computadora nueva: servidor y pantallas).

- H1. Cuando la página web descarta SOLA una conexión (D-O: la reconexión no usó su token nuevo a tiempo), el programa queda desvinculado
  y deja de subir y de bajar. Nadie se enteraba: el motivo quedaba en `ultimo_error`, que Configuración › Instalación local solo mostraba
  dentro de la tarjeta de la instalación VINCULADA (que ya no aparece), y no había franja (la de conexión y la de usuarios atrasados solo
  miran empresas vinculadas, y la de revocación mira `revocada_en`, que D-O no pone a propósito). Ahora el estado local trae `descartada`,
  Instalación local lo dice en la tarjeta «Conectar esta computadora» y la franja de la aplicación lo avisa a todo el que entra (nivel
  «info») hasta que la computadora se conecte de nuevo. Una desvinculación hecha por una persona no avisa.

Nube y computadora corren en el MISMO proceso (ver tests/test_425_conexion_programa.py, de donde salen las ayudas y la limpieza)."""
import pathlib
from datetime import timedelta

from sqlmodel import Session

from app import sinc
from app.config import ahora_cr
from app.db import Documento, Empresa, engine, engine_empresa
from test_49_local_sinc import H, _admin_empresa, _cfg, _modo_local, _poner_cfg, c
from test_425_conexion_nube import _limpiar_limitador
from test_425_conexion_programa import _limpieza, _conectar, _programa, _soltar_programa  # noqa: F401  (_limpieza: limpia entre pruebas)
from test_425_pendientes_6 import _envejecer_conexiones

JS = pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js"


# ------------------------------------------------------------------------------------------------------------------------ H1
def test_h1_la_conexion_descartada_por_la_web_avisa_en_la_franja_y_en_instalacion_local(monkeypatch):
    eid_n, ta = _admin_empresa("-c7an", "3101425711")
    eid_l, tl = _admin_empresa("-c7al", "3101425711")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))                      # un programa en uso se reconecta con sesión
    est = c.get("/api/sinc/local/estado", headers=H(tl)).json()
    assert est["vinculado"] is True and est["descartada"] is False
    assert c.get("/api/sinc/local/aviso", headers=H(tl)).json()["nivel"] is None
    # se va el internet justo después de recoger: a los 10 minutos la web descarta sola la instalación; al volver, el ciclo recibe la señal
    _envejecer_conexiones(eid_n)
    with monkeypatch.context() as m:                                         # la lista de la web (el descarte no corre en el programa)
        m.setattr(sinc, "MODO_LOCAL", False)
        assert c.get("/api/sinc/instalaciones", headers=H(ta)).status_code == 200
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg["vinculado"] is False and not cfg.get("revocada_en") and cfg["ultimo_error"] == sinc.MENSAJE_CONEXION_DESCARTADA
    # Instalación local: el estado lo dice (la pantalla lo muestra en la tarjeta «Conectar esta computadora»)
    est = c.get("/api/sinc/local/estado", headers=H(tl)).json()
    assert est["vinculado"] is False and not est["revocada_en"] and est["descartada"] is True
    assert est["ultimo_error"] == sinc.MENSAJE_CONEXION_DESCARTADA
    # la franja de la aplicación: la ve todo el que entra, no solo quien abre Configuración
    f = c.get("/api/sinc/local/aviso", headers=H(tl)).json()
    assert f["nivel"] == "info" and f["conectado"] is False and f["titulo"] == "Computadora sin conectar.", f
    assert "descartó la conexión de esta computadora" in f["texto"] and "no sube ni baja nada" in f["texto"]
    assert "Configuración › Instalación local" in f["texto"] and "Sin conexión con la nube" not in f["texto"]
    assert sinc._aviso_local(eid_l) is None                                  # no es una revocación: sin esa franja ni cuenta de bloqueo
    # al conectarla de nuevo, el aviso se quita solo
    _soltar_programa()
    _limpiar_limitador()
    _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))
    est = c.get("/api/sinc/local/estado", headers=H(tl)).json()
    assert est["vinculado"] is True and est["descartada"] is False and not est["ultimo_error"]
    assert c.get("/api/sinc/local/aviso", headers=H(tl)).json()["nivel"] is None


def test_h1_solo_el_descarte_de_la_web_avisa_y_se_suma_al_plazo_de_hacienda(monkeypatch):
    eid, _ = _admin_empresa("-c7b", "3101425712")
    _modo_local(monkeypatch)
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); e.ambiente = "sandbox"; sc.add(e); sc.commit()

    def franja():
        with Session(engine) as sc, Session(engine_empresa(eid)) as s:
            return sinc.franja_local(s, sc.get(Empresa, eid))

    def descartada():
        with Session(engine_empresa(eid)) as s:
            return sinc._estado_local(s, eid)["descartada"]
    # nunca vinculada, o desvinculada por una persona con un error viejo anotado: sin aviso
    assert franja()["nivel"] is None and descartada() is False
    _poner_cfg(eid, vinculado=False, ultimo_error="2026-11-10T08:00:00 comprobantes: tiempo agotado")
    assert franja()["nivel"] is None and descartada() is False
    # vinculada: tampoco (vincular de nuevo limpia ultimo_error; aunque el texto quedara, la computadora ya sincroniza)
    _poner_cfg(eid, vinculado=True, ultimo_error=sinc.MENSAJE_CONEXION_DESCARTADA)
    assert franja()["nivel"] is None and descartada() is False
    # el descarte de la web, tal como lo deja el programa (D-O)
    with Session(engine) as sc, Session(engine_empresa(eid)) as s:
        sinc._desvincular_descartada(s, sc, eid, sinc._cfg_local(s, eid))
    f = franja()
    assert f["nivel"] == "info" and f["conectado"] is False and f["titulo"] == "Computadora sin conectar." and descartada() is True
    # con un comprobante fuera de plazo manda el plazo de Hacienda, y el aviso de la conexión va en el mismo texto
    viejo = (ahora_cr().date() - timedelta(days=15)).isoformat() + "T08:00:00-06:00"
    with Session(engine_empresa(eid)) as s:
        s.add(Documento(empresa_id=eid, tipo_documento="04", clave=f"506{1:047d}", consecutivo=f"00100002040{1:09d}", fecha_emision=viejo,
                        estado="firmado", ambiente="sandbox", moneda="CRC", tipo_cambio=1, total=1000))
        s.commit()
    f = franja()
    assert f["nivel"] == "vencido" and f["titulo"] == "Plazo de Hacienda vencido." and f["conectado"] is False
    assert "descartó la conexión de esta computadora" in f["texto"] and "2 días hábiles" in f["texto"]


def test_h1_instalacion_local_muestra_el_descarte_en_la_tarjeta_de_conectar():
    i = (JS / "pages" / "configuracion" / "instalacion-local.js").read_text(encoding="utf-8")
    tarjeta = i[i.index('<div class="card" v-if="!est.vinculado || est.revocada_en">'):i.index('<div class="card" v-if="cuentas && cuentas.cuentas')]
    aviso = '<div class="alert warn" style="margin:0 0 10px" v-if="est.descartada">{{est.ultimo_error}} Mientras tanto'
    assert aviso in tarjeta and "no sube ni baja nada de la página web" in tarjeta
    assert tarjeta.index("</h2>") < tarjeta.index(aviso) < tarjeta.index("<ConexionLocal ")       # arriba, antes de «Conectar con mi cuenta»
    # el texto sale del servidor (ultimo_error) con interpolación: nada de v-html
    assert "v-html" not in "\n".join(x for x in i.splitlines() if not x.lstrip().startswith("//"))
