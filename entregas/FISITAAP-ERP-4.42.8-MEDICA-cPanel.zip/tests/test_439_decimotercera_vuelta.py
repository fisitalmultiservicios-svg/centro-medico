# -*- coding: utf-8 -*-
"""4.39, decimotercera vuelta de los arreglos (17 nov 2026). Una prueba por cada cambio, con los métodos reales de caja.js en Node: para
«Pedidos web» en el programa, la ventana, el resumen y el sincronizar real contra el servidor falso de pedidos con «puertas» de
tests/test_439_duodecima_vuelta.py; para la caja, uno o dos «equipos» con el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py
y las ayudas de las vueltas tercera a undécima (destinoDe e impresoraDe reales, la Cocina como única impresora de comanda y cada comanda
anotada). Casi todos estos defectos ya estaban en la 4.38.

- V1 aceptarWeb (programa): el pedido queda anotado como ya avisado (_entAvisados) en cuanto el PUT sale bien, antes del aviso, de sincronizar y
  de recargar la ventana (cargarPanelWeb). Si la consulta del resumen llega mientras se recarga la ventana (abierta o ya cerrada), su cuenta ya
  está en la caja y no suena «Entró a la caja…», ni avisa, ni el botón «Pedidos web» se vuelve a poner en 1 (antes lo anotaba
  imprimirComandaWeb al volver, y ahí ya había sonado). Sin consulta en medio, igual que antes.
- V2 la casilla de la cantidad: 0 (o vacía) quita el plato como «✕» (quitar, con la clave de anular si ya se mandó a cocina); con la clave
  negada, la línea vuelve a la cantidad guardada (o 1). Antes la línea en 0 quedaba en pantalla, fuera de lo guardado, y el servidor la
  conservaba: el plato volvía y se cobraba después (y sin pedir la clave de anular). La venta rápida y la caja de comercio quitan la línea;
  el 2x1 con la casilla en 3 se calcula como antes.
- V3 cobrarParte: lo que queda de cada línea sale de su propia parte. Con una línea en 0 la lista de la parte ya filtrada se corría de posición
  y en las partes siguientes se cobraba de más; ahora la suma de lo cobrado en todas las partes es la cuenta.
- V4 sincronizar: si la cuenta abierta fue cobrada o cerrada en otro equipo, «Dividir» se cierra (antes quedaba abierto y su selección, por
  posición, se llevaba el plato sin guardar que quedó en pantalla a la otra mesa).
- V5 confirmarDividir: las partes iguales de una mesa no se comparan en el paso 4 (cobrarParte trae y junta la cuenta): si la sincronización de
  siempre ya había traído la «Comanda» de otro equipo o un plato quitado, antes pedía volver a abrir «Dividir»; ahora junta y cobra la mitad al día,
  con la comanda una sola vez, igual que sin la sincronización. Lo que cuidaba el paso 4 lo cuida cobrarParte: si otro equipo cobró la cuenta
  entera no se cobra nada; si cobró unos platos o cambió un precio, la parte sale de la cuenta al día (nada se cobra dos veces).
- V6 confirmarDividir: pasar platos a una mesa unida a esta misma cuenta avisa «<mesa> ya está unida a esta cuenta» y «Dividir» sigue abierto,
  sin cambiar nada (antes duplicaba el plato con un aviso falso y, al pasar todos, la cuenta se borraba sin cobrar). cuentaDeMesa es la lógica
  real de _datos.js (con las mesas unidas). Pasar a una mesa libre o con su propia cuenta sigue igual.
Cada caso que muestra el defecto corre también con los métodos de ANTES de esta vuelta: se sacan de caja.js con la decimotercera vuelta deshecha
(DECIMOTERCERA y _caja_sin_decimotercera de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta), y la casilla con su expresión de antes.
Defecto que quedaba (era xfail estricto): V2 corre con el «change» de la casilla, que el navegador da al salir de ella o con Enter. Con el cursor
todavía en la casilla en 0, F4 («Guardar cuenta») guardaba la línea en 0 sin pasar por quitar: el servidor conservaba el plato con el aviso falso de
otro equipo y se cobraba después. 4.39 (decimocuarta vuelta): lo arregla U2 (tecla deja primero la casilla); la prueba ya no es xfail y conserva el
control con la tecla de antes de la decimocuarta vuelta.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

from tests.test_431_misma_mesa_pantallas import RAIZ, _js, _linea, _metodo, _tramo
from tests.test_432_caja_pedidos_web import _computadas, _metodos, _node
from tests.test_439_duodecima_vuelta import ARNES as ARNES_WEB
from tests.test_439_duodecima_vuelta import ENTRO, NUEVO, PROG, SERVIDOR_41
from tests.test_439_revision_arreglos import CASADO, LIMONADA, POSTRE, _caja
from tests.test_439_tercera_vuelta import DECIMOTERCERA, _caja_sin_decimocuarta, _caja_sin_decimotercera
from tests.test_439_undecima_vuelta import _correr as _correr11

# los métodos de la caja que cambió la decimotercera vuelta (además de la casilla de la cantidad, en la plantilla); quitar es de una línea
CAMBIADOS = ("async aceptarWeb(p) {", "async cobrarParte(n) {", "async sincronizar() {", "async confirmarDividir() {")
QUITAR = "async quitar(l) {"
# dónde está cada tripleta de DECIMOTERCERA, en orden (None: la plantilla)
DE_CADA = ("async aceptarWeb(p) {", None, QUITAR, "async cobrarParte(n) {", "async sincronizar() {", "async confirmarDividir() {",
           "async confirmarDividir() {", "async confirmarDividir() {")
CASILLA = 'v-model.number="l.cantidad" @change="'
UNIDA_7 = "Mesa 7 ya está unida a esta cuenta"
CERRADA_M6 = "La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo; lo que no se había enviado sigue en pantalla como cuenta nueva"
CASADO1, POSTRE1, LIMONADA1, AMBOS = ["Casado×1"], ["Postre×1"], ["Limonada×1"], ["Casado×1", "Postre×1"]


def _expresion(k: str) -> str:
    """La expresión del @change de la casilla de la cantidad (la única de la plantilla)."""
    assert k.count(CASILLA) == 1
    i = k.index(CASILLA) + len(CASILLA)
    return k[i:k.index('"', i)]


# ================================================================================================================ V1: «Pedidos web» en el programa
# el arnés de la duodécima vuelta, con una puerta más: la lista de pedidos con que se recarga la ventana (cargarPanelWeb) llega cuando la prueba la suelta
ARNES_V1 = ARNES_WEB.replace("  if (url === '/api/pedidos') return S.pedidos.map(p => ({ ...p }));\n",
                             "  if (url === '/api/pedidos') { const l = S.pedidos.map(p => ({ ...p })); if (Q.puerta.pedidos) await Q.puerta.pedidos; return l; }\n")
assert ARNES_V1 != ARNES_WEB


def _fuente_web(antes=False) -> str:
    """La ventana «Pedidos web», el resumen y el sincronizar real; con `antes`, aceptarWeb de antes de esta vuelta (va al final y pisa al de ahora)."""
    k = _caja()
    met = _metodos() + _tramo(k, "    async revisarOnline() {", "\n    // 3.87:") + "\n    " + _metodo(k, "async sincronizar() {") + ",\n"
    if antes:
        met += "    " + _metodo(_caja_sin_decimotercera(), "async aceptarWeb(p) {") + ",\n"
    return met


def _correr_web(tmp_path, escenario, antes=False):
    guion = (ARNES_V1.replace("@INFO@", json.dumps(PROG)).replace("@COMP@", json.dumps(_computadas())).replace("@MET@", json.dumps(_fuente_web(antes)))
             + escenario + "\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n")
    tmp_path.mkdir(parents=True, exist_ok=True)
    return _node(tmp_path, guion)


CASOS_V1 = r"""
// el programa: el #41 entra (nuevo: el botón en 1). Se abre «Pedidos web» y se acepta («Imprimir comanda», con impresora de cocina): el PUT sale bien y la
// cuenta del #41 entra a la caja, pero la lista con que aceptarWeb recarga la ventana (cargarPanelWeb) queda retenida. Con `medio`, mientras tanto llega
// la consulta del resumen (ultimo_entrado_id = 41: la cuenta ya está en la lista de la caja). Con `cierra`, el cajero cerró la ventana antes. Después
// llega la lista y otra consulta
async function v1(cierra, medio) {
  S.pedidos = [pedido(40, 40, 'entregado')]; S.espera = []; S.entrado = 40; Q.local = []; Q.todos = [];
  const vm = caja(); await vuelta(vm);
  S.pedidos.push(pedido(41, 41, 'nuevo'));
  marca(); await vuelta(vm); const alEntrar = ver(vm);
  await abrir(vm); const p = vm.panelWeb.lista.find(x => x.id === 41);
  marca(); const suelta = cerrar('pedidos');
  const hecho = vm.imprimirComandaWeb(p); await pasar();
  const aceptado = { estado: S.pedidos[1].estado, cuentas: S.espera.map(v => v.pedido_id), avisados: [...(vm._entAvisados || [])], esperando: Q.llamadas.filter(x => x === 'GET /api/pedidos').length };
  if (cierra) vm.panelWeb = null;
  if (medio) { await vm.revisarOnline(); await pasar(); }
  const durante = ver(vm);
  suelta(); await hecho; await pasar();
  const alTerminar = { ...ver(vm), ventana: !!vm.panelWeb };
  marca(); await vuelta(vm); const otra = ver(vm);
  return { alEntrar, aceptado, durante, alTerminar, otra, entraron: entraron(), avisados: [...(vm._entAvisados || [])].sort() };
}
for (const cierra of [false, true]) for (const medio of [true, false]) { Q.llamadas = []; out[(cierra ? 'cerrada' : 'abierta') + (medio ? '_medio' : '')] = await v1(cierra, medio); }
"""
V1_CASOS = ("abierta_medio", "abierta", "cerrada_medio", "cerrada")


def test_v1_el_resumen_que_llega_mientras_se_recarga_la_ventana_no_vuelve_a_avisar_en_node(tmp_path):
    r = _correr_web(tmp_path / "ahora", CASOS_V1)
    for k in V1_CASOS:
        x, medio = r[k], k.endswith("_medio")
        assert x["alEntrar"] == {"avisos": [NUEVO], "sonidos": 1, "boton": 1, "resumenes": 1}, (k, x)
        # el PUT salió bien (la cuenta del #41 ya está en la caja) y la ventana se está recargando (la segunda lectura de la lista, retenida): el
        # pedido ya figura como avisado
        assert x["aceptado"] == {"estado": "confirmado", "cuentas": [41], "avisados": [41], "esperando": 2}, (k, x)
        # la consulta del resumen que llega mientras tanto (ventana abierta o ya cerrada): ni «Entró a la caja…», ni sonido, y el botón en 0
        assert x["durante"] == {"avisos": [SERVIDOR_41], "sonidos": 0, "boton": 0 if medio else 1, "resumenes": 1 if medio else 0}, (k, x)
        # al terminar, el botón en 0 (con la consulta en medio, imprimirComandaWeb vuelve a leer el resumen: W2 de la duodécima vuelta)
        assert x["alTerminar"] == {"avisos": [SERVIDOR_41], "sonidos": 0, "boton": 0, "resumenes": 2 if medio else 0, "ventana": k.startswith("abierta")}, (k, x)
        assert x["otra"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1} and x["entraron"] == [] and x["avisados"] == [41], (k, x)

    # antes de esta vuelta: el pedido se anotaba al volver de aceptarWeb (después de recargar la ventana): la consulta que llegaba mientras tanto ya veía
    # su cuenta en la caja y sonaba «Entró a la caja el pedido en línea #41.»; con la ventana cerrada, además, el botón quedaba en 1 (rojo) aunque el
    # pedido se aceptó aquí. Sin consulta en medio, igual que ahora
    v = _correr_web(tmp_path / "antes", CASOS_V1, antes=True)
    for k in ("abierta_medio", "cerrada_medio"):
        x = v[k]
        assert x["aceptado"]["avisados"] == [] and x["durante"]["avisos"] == [SERVIDOR_41, ENTRO.format(41)] and x["durante"]["sonidos"] == 1, (k, x)
        assert x["entraron"] == [ENTRO.format(41)] and x["avisados"] == [41], (k, x)
    assert v["abierta_medio"]["alTerminar"]["boton"] == 0 and v["cerrada_medio"]["alTerminar"]["boton"] == 1 and v["cerrada_medio"]["otra"]["boton"] == 1, v
    for k in ("abierta", "cerrada"):
        assert v[k]["aceptado"]["avisados"] == [] and {**v[k], "aceptado": None} == {**r[k], "aceptado": None}, (k, v[k])


# ================================================================================================================ la caja: uno o dos equipos
AYUDAS = r"""
// la marca de envío de hace un minuto (la comanda salió hace rato)
const ENV = () => ({ enviado: VIEJA(), ronda: 1 });
// la casilla de la cantidad: se escribe `q` y corre la expresión de su @change en la plantilla de caja.js (o la de antes), sobre ESE equipo, como Vue
const CASILLA = new Function('l', 'with (this) { return (' + @CASILLA@ + '); }');
const casilla = async (vm, l, q) => { l.cantidad = q; await CASILLA.call(vm, l); };
// cuentaDeMesa con la lógica real de _datos.js (ocupaMesa y cuentasDeMesa: también la mesa unida a otra cuenta), sobre la lista de cuentas de ESE equipo
const MESA_REAL = @MESA_REAL@;
const mesaReal = vm => new Function('enEspera', MESA_REAL + '\nreturn cuentaDeMesa;')(() => vm.A.mock.get('pos_espera', []) || []);
const sinMesaReal = () => { globalThis.cuentaDeMesa = () => null; };
// lo cobrado en todos los comprobantes, por plato (la suma de las cantidades)
const porPlato = () => { const t = {}; for (const e of C.emitidos) for (const x of e.lineas) { const [d, q] = x.split('×'); t[d] = Math.round(((t[d] || 0) + +q) * 1000) / 1000; } return t; };
// un plato con esa cantidad
const conCant = (p, q) => ({ ...p, cantidad: q });
"""


def _extras():
    """Los métodos de ahora que estas pruebas usan además de los del arnés: quitar (la casilla en 0) y unir mesas."""
    k = _caja()
    return (_linea(k, QUITAR), _linea(k, "abrirUnir() {"), _metodo(k, "confirmarUnir() {"))


def _antes13():
    """Los métodos de la caja que cambió la decimotercera vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k0 = _caja_sin_decimotercera()
    return (_linea(k0, QUITAR),) + tuple(_metodo(k0, c) for c in CAMBIADOS[1:])


def _correr(tmp_path, casos, antes=False, mas=()):
    """El arnés de dos equipos de las vueltas anteriores, con la casilla de la plantilla y cuentaDeMesa real; con `antes`, todo lo que cambió esta
    vuelta en la caja como estaba antes de ella (quitar, cobrarParte, sincronizar, confirmarDividir y la expresión de la casilla). 4.39 (decimocuarta
    vuelta): `mas`, otros métodos que van al final de la fuente y pisan a los de ahora (la tecla de antes de la decimocuarta vuelta)."""
    expr = _expresion(_caja_sin_decimotercera() if antes else _caja())
    mesa = _tramo(_js("pages/pos/_datos.js"), "export function ocupaMesa(", "\nexport const MESA_BASE").replace("export function ", "function ")
    ayudas = AYUDAS.replace("@CASILLA@", json.dumps(expr)).replace("@MESA_REAL@", json.dumps(mesa))
    return _correr11(tmp_path, ayudas + casos, antes=_extras() + (_antes13() if antes else ()) + tuple(mas))


# ================================================================================================================ V2: la casilla en 0
CASOS_V2 = r"""
// un solo equipo: la Mesa 6 guardada con Casado y Postre (con `dos`, 2 Postres) ya enviados a cocina. Con `clave` (true o false), la caja pide la clave de
// anular y se da o no. Escribe `q` (0 o vacío) en la casilla del Postre y toca «Guardar cuenta»; después abre la Mesa 6 y la cobra (F9)
async function v2(q, clave, dos) {
  const [id, a] = await cuenta(true, [{ ...CASADO(), ...ENV() }, { ...conCant(POSTRE(), dos ? 2 : 1), ...ENV() }]);
  const pedidas = [];
  if (clave !== undefined) { a.cfg.clave_anular = '1234'; a.autorizar = async t => { pedidas.push(t); return clave; }; }
  await casilla(a, a.lineas.find(x => x.detalle === 'Postre'), q);
  const pantalla = a.lineas.map(l => l.detalle + '×' + l.cantidad);
  a.guardarCuenta(); await a.A.mock.guardarTodo(); await hastaLibre();
  const guardada = { srv: srv(), avisos: avisos(a).slice(), vista: a.vista };
  await a.sincronizar(); a.abrirMesa(M6); const alAbrir = detalles(a);
  a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { pedidas, pantalla, guardada, alAbrir, hechos: cobrados(a), suma: suma(), srv: srv(), avisos: avisos(a), impresos: quienes(a) };
}
out.cero = await v2(0);
out.vacia = await v2('');
out.negada = await v2(0, false);
out.negada_dos = await v2(0, false, true);
out.dada = await v2(0, true);
// la venta rápida (sin mesa) y la caja de comercio: Casado y Postre sin enviar; 0 en la casilla del Postre y cobrar
async function v2rapida(comercio) {
  nuevo(); const v = venta(await equipo()); if (comercio) v.esRestaurante = false;
  v.lineas.push(CASADO(), POSTRE());
  await casilla(v, v.lineas.find(x => x.detalle === 'Postre'), 0);
  const pantalla = v.lineas.map(l => l.detalle + '×' + l.cantidad);
  await v.abrirPago(); if (v.pago) await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo();
  return { pantalla, hechos: hechos().map(h => h[2]), suma: suma(), impresos: impresos(), srv: srv() };
}
out.rapida = await v2rapida(false);
out.comercio = await v2rapida(true);
// el 2x1: 2 Cervezas con la promoción y la casilla en 3 (y en 1)
{ nuevo(); const v = venta(await equipo()); v.promosActivas = PROMO; v.lineas.push(CERVEZA(2)); v.aplicarPromos(); const l = v.lineas[0];
  const dos = [l.cantidad, l.descuento_pct, r2(v.descuentoDe(l))];
  await casilla(v, l, 3); const tres = [l.cantidad, l.descuento_pct, r2(v.descuentoDe(l))];
  await casilla(v, l, 1); const una = [l.cantidad, l.descuento_pct, r2(v.descuentoDe(l))];
  out.dosxuno = { dos, tres, una, lineas: v.lineas.length }; }
"""
GUARDADA = "«Mesa 6» guardada"
TIQUETE = "Tiquete 0000000001 emitido · {:g}"


def test_v2_la_casilla_en_0_quita_el_plato_y_no_se_cobra_despues_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V2)
    for k in ("cero", "vacia", "dada"):
        x = r[k]
        # 0 (o la casilla vacía) quita el Postre como «✕» (con la clave de anular dada, después de pedirla): sin aviso, el servidor queda sin el Postre
        # y al abrir la mesa y cobrarla se cobra solo el Casado; nada sale a cocina
        assert x["pedidas"] == (["Quitar Postre ya enviado a cocina"] if k == "dada" else []) and x["pantalla"] == CASADO1, (k, x)
        assert x["guardada"] == {"srv": [["Mesa 6", CASADO1, None]], "avisos": [GUARDADA], "vista": "mesas"}, (k, x)
        assert x["alAbrir"] == CASADO1 and x["hechos"] == [["A", CASADO1]] and x["suma"] == CASADO and x["srv"] == [] and x["impresos"] == [], (k, x)
        assert x["avisos"] == [GUARDADA, TIQUETE.format(CASADO)], (k, x)
    # con la clave de anular negada, la línea vuelve a la cantidad guardada (1, o 2 con dos Postres) y nada cambia: se guarda y se cobra la cuenta entera
    for k, postres in (("negada", "Postre×1"), ("negada_dos", "Postre×2")):
        x, total = r[k], CASADO + (POSTRE if k == "negada" else 2 * POSTRE)
        assert x["pedidas"] == ["Quitar Postre ya enviado a cocina"] and x["pantalla"] == ["Casado×1", postres], (k, x)
        assert x["guardada"] == {"srv": [["Mesa 6", ["Casado×1", postres], None]], "avisos": [GUARDADA], "vista": "mesas"}, (k, x)
        assert x["hechos"] == [["A", ["Casado×1", postres]]] and x["suma"] == total and x["srv"] == [] and x["avisos"] == [GUARDADA, TIQUETE.format(total)], (k, x)
    # la venta rápida y la caja de comercio: la línea se quita y se cobra solo el Casado (en la venta rápida su comanda sale con el Casado)
    assert r["rapida"] == {"pantalla": CASADO1, "hechos": [CASADO1], "suma": CASADO, "impresos": [CASADO1], "srv": []}, r["rapida"]
    assert r["comercio"] == {"pantalla": CASADO1, "hechos": [CASADO1], "suma": CASADO, "impresos": [], "srv": []}, r["comercio"]
    # el 2x1: con la casilla en 3 (y en 1) se vuelve a calcular la promoción, como antes
    assert r["dosxuno"] == {"dos": [2, 50, 1800], "tres": [3, 33.33, 1799.82], "una": [1, 0, 0], "lineas": 1}, r["dosxuno"]

    # antes de esta vuelta: la línea en 0 (o vacía) quedaba en pantalla y fuera de lo guardado; el servidor la conservaba (con el aviso falso de que otro
    # equipo la quitó o cobró) y el Postre volvía y se cobraba; con la clave de anular configurada ni siquiera se pedía. La venta rápida y la caja de
    # comercio emitían la línea en 0. El 2x1, igual
    v = _correr(tmp_path / "antes", CASOS_V2, antes=True)
    falso = "En otro equipo se quitó o cobró 1 plato de Mesa 6. La cuenta quedó como está ahora."
    for k in ("cero", "vacia", "negada", "dada"):
        x = v[k]
        assert x["pedidas"] == [] and x["pantalla"] == ["Casado×1", "Postre×0" if k != "vacia" else "Postre×"], (k, x)
        assert x["guardada"]["srv"] == [["Mesa 6", AMBOS, None]] and x["guardada"]["avisos"] == [falso, GUARDADA], (k, x)
        assert x["hechos"] == [["A", AMBOS]] and x["suma"] == CASADO + POSTRE, (k, x)
    assert v["negada_dos"]["hechos"] == [["A", ["Casado×1", "Postre×2"]]] and v["negada_dos"]["pedidas"] == [], v["negada_dos"]
    assert v["rapida"]["hechos"] == [["Casado×1", "Postre×0"]] and v["comercio"]["hechos"] == [["Casado×1", "Postre×0"]], v
    assert v["dosxuno"] == r["dosxuno"], v["dosxuno"]


CASOS_V2_F4 = r"""
// un solo equipo, la Mesa 6 guardada con Casado y Postre ya enviados. Escribe 0 en la casilla del Postre (v-model: la línea ya tiene 0) y, con el cursor
// todavía en la casilla (el navegador da «change» al salir de ella o con Enter, no con una tecla de función), toca F4 («Guardar cuenta»). Después abre la
// Mesa 6 y la cobra
// 4.39 (decimocuarta vuelta): el evento de la tecla lleva la casilla con el cursor (e.target: type number, su valor, y un blur() que corre el «change» de
// la casilla con la expresión real de la plantilla, como el navegador al salir de ella). Si la cuenta sigue en pantalla después de la primera F4 (U2: la
// casilla tenía 0, no se guarda en esa pulsación), se toca F4 otra vez, ya sin el cursor en la casilla
{ const [id, a] = await cuenta(true, [{ ...CASADO(), ...ENV() }, { ...POSTRE(), ...ENV() }]);
  const l = a.lineas.find(x => x.detalle === 'Postre'); l.cantidad = 0;
  const ev = { key: 'F4', pd: false, preventDefault() { this.pd = true; }, target: { type: 'number', value: '0', blur() { CASILLA.call(a, l); } } };
  a.tecla(ev); await a.A.mock.guardarTodo(); await hastaLibre();
  out.primera = { pd: ev.pd, vista: a.vista, platos: detalles(a), srv: srv(), avisos: avisos(a).slice() };
  if (a.vista === 'venta') { tecla(a, 'F4'); await a.A.mock.guardarTodo(); await hastaLibre(); }
  out.guardada = { srv: srv(), avisos: avisos(a).slice() };
  await a.sincronizar(); a.abrirMesa(M6); a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.hechos = cobrados(a); out.suma = suma(); }
"""


def test_v2_f4_con_el_cursor_en_la_casilla_en_0_no_deja_el_plato_para_cobrarlo_despues_en_node(tmp_path):
    # 4.39 (decimocuarta vuelta): era xfail estricto (defecto que quedaba de V2); U2 lo arregla: la primera F4 deja la casilla (corre quitar: sin clave de
    # anular, el Postre sale de la pantalla) y, como tenía 0, no guarda en esa pulsación; la segunda F4 guarda sin el Postre. Lo esperado es lo de antes:
    # el servidor sin el Postre, sin aviso falso, y se cobra solo el Casado
    r = _correr(tmp_path / "ahora", CASOS_V2_F4)
    assert r["primera"] == {"pd": True, "vista": "venta", "platos": CASADO1, "srv": [["Mesa 6", AMBOS, None]], "avisos": []}, r
    assert r["guardada"] == {"srv": [["Mesa 6", CASADO1, None]], "avisos": [GUARDADA]} and r["hechos"] == [["A", CASADO1]] and r["suma"] == CASADO, r

    # el control, con la tecla de antes de la decimocuarta vuelta (no mira la casilla con el cursor): F4 guarda la línea en 0 sin pasar por quitar; el
    # servidor conserva el Postre con el aviso falso de otro equipo y se cobran Casado y Postre (₡5 311)
    v = _correr(tmp_path / "antes", CASOS_V2_F4, mas=(_metodo(_caja_sin_decimocuarta(), "tecla(e) {"),))
    falso = "En otro equipo se quitó o cobró 1 plato de Mesa 6. La cuenta quedó como está ahora."
    assert v["primera"]["vista"] == "mesas" and v["guardada"] == {"srv": [["Mesa 6", AMBOS, None]], "avisos": [falso, GUARDADA]}, v
    assert v["hechos"] == [["A", AMBOS]] and v["suma"] == CASADO + POSTRE, v


# ================================================================================================================ V3: partes iguales con una línea en 0
CASOS_V3 = r"""
// la Mesa 6 sin guardar en A con esos platos (una línea en 0, como la dejaba la casilla antes de V2); A la cobra en `n` partes iguales: «Dividir» → partes
// iguales y después, en cada vuelta a la mesa, «Cobrar parte k de n» hasta la última
const PL = { Casado: CASADO, Postre: POSTRE, Limonada: LIMONADA };
async function v3(platos, n) {
  nuevo(); const a = venta(await equipo()); a.abrirMesa(M6);
  for (const [d, q] of platos) a.lineas.push(conCant(PL[d](), q));
  await a.abrirDividir(); a.dividir.modo = 'partes'; a.dividir.partes = n; await a.confirmarDividir(); await conPago(a);
  const partes = [];
  for (let k = 1; k <= n + 1; k++) {
    if (k > 1) { await a.sincronizar(); if (!S.items.length) break; a.abrirMesa(M6); a._alDia = 0; await a.cobrarParte(n); await conPago(a); }
    partes.push({ parte: a.cobroParcial ? [a.cobroParcial.parte, a.cobroParcial.de] : null, platos: detalles(a) });
    if (!a.pago) break;
    await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  }
  return { partes, porPlato: porPlato(), suma: suma(), emitidos: C.emitidos.length, srv: srv() };
}
for (const [nombre, platos] of [['postre0', [['Postre', 0], ['Casado', 2]]], ['tres', [['Casado', 2], ['Postre', 0], ['Limonada', 4]]]])
  for (const n of [2, 3]) out[nombre + '_' + n] = await v3(platos, n);
"""
# lo que hay en cada cuenta, por plato, y su total con IVA
V3_CUENTA = {"postre0": ({"Casado": 2}, 2 * CASADO), "tres": ({"Casado": 2, "Limonada": 4}, 2 * CASADO + 4 * LIMONADA)}


def test_v3_las_partes_iguales_con_una_linea_en_0_cobran_la_cuenta_exacta_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V3)
    for nombre, (platos, total) in V3_CUENTA.items():
        for n in (2, 3):
            x = r[nombre + "_" + str(n)]
            # las n partes se cobran (una por comprobante) y no queda cuenta; la suma de lo cobrado en todas las partes es la cuenta: las cantidades de
            # cada plato, exactas; el dinero, salvo el redondeo a céntimos de cada comprobante (con 3 partes: 0,667 + 0,667 + 0,666)
            assert x["emitidos"] == n and [p["parte"] for p in x["partes"]] == [[i, n] for i in range(1, n + 1)] and x["srv"] == [], (nombre, n, x)
            assert x["porPlato"] == platos and abs(x["suma"] - total) <= 0.01 * n, (nombre, n, x)
            assert all("Postre" not in t for p in x["partes"] for t in p["platos"]), (nombre, n, x)
    assert r["postre0_2"]["partes"] == [{"parte": [1, 2], "platos": CASADO1}, {"parte": [2, 2], "platos": CASADO1}] and r["postre0_2"]["suma"] == 2 * CASADO, r
    assert r["tres_2"]["partes"] == [{"parte": [1, 2], "platos": ["Casado×1", "Limonada×2"]}, {"parte": [2, 2], "platos": ["Casado×1", "Limonada×2"]}], r

    # antes de esta vuelta: lo que quedaba de cada línea se calculaba con la parte de la MISMA POSICIÓN en la lista ya filtrada (sin la línea en 0): la
    # línea que seguía al 0 quedaba entera y en las partes siguientes se cobraba de más (₡3 955 de más con 2 partes de [Postre×0, Casado×2])
    v = _correr(tmp_path / "antes", CASOS_V3, antes=True)
    assert v["postre0_2"]["porPlato"] == {"Casado": 3} and v["postre0_2"]["suma"] == 3 * CASADO, v["postre0_2"]
    assert v["postre0_3"]["porPlato"] == {"Casado": 2.667}, v["postre0_3"]
    assert v["tres_2"]["porPlato"] == {"Casado": 2, "Limonada": 6} and v["tres_2"]["suma"] == 2 * CASADO + 6 * LIMONADA, v["tres_2"]
    assert v["tres_3"]["porPlato"] == {"Casado": 2, "Limonada": 5.333}, v["tres_3"]
    for k in v:
        assert v[k]["suma"] > V3_CUENTA[k.split("_")[0]][1] + 1000, (k, v[k])


# ================================================================================================================ V4: la sincronización cierra «Dividir»
CASOS_V4 = r"""
// la Mesa 6 con Casado y Postre ya enviados, abierta en A y en B. A agrega una Limonada (sin guardar), abre «Dividir» y marca el Casado para la Mesa 7. B
// cobra la cuenta entera. Pasa la sincronización de siempre de A. Si «Dividir» sigue abierto, A toca «Pasar»; si queda algo en pantalla, «Guardar cuenta»
async function v4() {
  const [id, a, b] = await cuenta(true, [{ ...CASADO(), ...ENV() }, { ...POSTRE(), ...ENV() }]); a.mesas = [M6, M7];
  a.lineas.push(LIMONADA());
  await a.abrirDividir(); elegir(a, 'Casado', 7); const marcado = Object.keys(a.dividir.sel).map(i => a.lineas[i].detalle);
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar();
  const tras = { dividir: !!a.dividir, platos: detalles(a), cuenta: a.esperaId, mesa: a.mesaActual ? a.mesaActual.nombre : null, cerradas: cerradas(a) };
  if (a.dividir) { await a.confirmarDividir(); await a.A.mock.guardarTodo(); await hastaLibre(); }
  const despues = { dividir: !!a.dividir, platos: detalles(a), hecho: hechoDiv(a), srv: srv() };
  if (a.lineas.length) { a.guardarCuenta(); await a.A.mock.guardarTodo(); }
  return { marcado, tras, despues, srv: srv(), hechos: cobrados(a), impresos: quienes(a) };
}
out.v4 = await v4();
"""


def test_v4_la_cuenta_cobrada_en_otro_equipo_cierra_dividir_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V4)["v4"]
    assert r["marcado"] == ["Casado"], r
    # la sincronización de A ve la cuenta cobrada en B: el aviso de siempre, «Dividir» se cierra y la Limonada queda en pantalla como cuenta nueva de la
    # Mesa 6; «Guardar cuenta» la guarda en la Mesa 6. Nada pasa a la Mesa 7; B cobró lo suyo y nada salió a cocina
    assert r["tras"] == {"dividir": False, "platos": LIMONADA1, "cuenta": None, "mesa": "Mesa 6", "cerradas": [CERRADA_M6]}, r
    assert r["despues"] == {"dividir": False, "platos": LIMONADA1, "hecho": [], "srv": []}, r
    assert r["srv"] == [["Mesa 6", LIMONADA1, None]] and r["hechos"] == [["B", AMBOS]] and r["impresos"] == [], r

    # antes de esta vuelta: «Dividir» seguía abierto con la selección por posición (el Casado era el primero); el primero ahora era la Limonada, y al tocar
    # «Pasar» se fue a la Mesa 7 (una cuenta que nadie pidió)
    v = _correr(tmp_path / "antes", CASOS_V4, antes=True)["v4"]
    assert v["tras"] == {**r["tras"], "dividir": True}, v
    assert v["despues"] == {"dividir": False, "platos": [], "hecho": ["Todo se pasó a Mesa 7: la cuenta quedó vacía"], "srv": [["Mesa 7", LIMONADA1, None]]}, v
    assert v["srv"] == [["Mesa 7", LIMONADA1, None]] and v["hechos"] == r["hechos"], v


# ================================================================================================================ V5: las partes de una mesa tras la sincronización
CASOS_V5 = r"""
// la Mesa 6 (Casado y Postre; con `que` = comanda, sin enviar; con quita, ya enviados), abierta en A y en B. A abre «Dividir» y elige 2 partes iguales.
// B toca «Comanda» (comanda) o quita el Postre (quita). Con `sinc`, pasa la sincronización de siempre de A («Dividir» sigue abierto). A confirma y cobra
// la parte 1
async function v5(que, sinc) {
  const env = que === 'quita' ? ENV() : {};
  const [id, a, b] = await cuenta(true, [{ ...CASADO(), ...env }, { ...POSTRE(), ...env }]);
  await a.abrirDividir(); a.dividir.modo = 'partes'; a.dividir.partes = 2;
  if (que === 'comanda') { await b.enviarComanda(); await b.A.mock.guardarTodo(); } else await quitarPostre(b);
  const srvB = srv();
  if (sinc) await a.sincronizar();
  const tras = { dividir: !!a.dividir, platos: detalles(a) };
  const t0 = Date.now(); await a.confirmarDividir(); await conPago(a); const ms = Date.now() - t0;
  const parte = { pago: !!a.pago, dividir: !!a.dividir, platos: detalles(a), parte: a.cobroParcial ? [a.cobroParcial.parte, a.cobroParcial.de] : null, avisos: avisos(a).filter(t => !t.startsWith('Comanda ')) };
  if (a.pago) { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
  return { srvB, tras, parte, ms, hechos: cobrados(a), suma: suma(), impresos: quienes(a), srv: srv() };
}
for (const que of ['comanda', 'quita']) for (const sinc of [true, false]) out[que + (sinc ? '_sinc' : '')] = await v5(que, sinc);
"""
CAMBIO_M6 = "La cuenta de Mesa 6 cambió en otro equipo. Revise el total antes de cobrar."
VUELVA = "La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día."
MEDIAS = ["Casado×0.5", "Postre×0.5"]


def test_v5_las_partes_de_una_mesa_tras_la_sincronizacion_juntan_y_cobran_al_dia_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V5)
    for sufijo in ("_sinc", ""):
        c, q = r["comanda" + sufijo], r["quita" + sufijo]
        # B tocó «Comanda» (con «Dividir» abierto, la pantalla de A no cambia aunque pase la sincronización): A espera esa comanda, junta y cobra la mitad
        # de la cuenta al día; la comanda salió una sola vez (la de B) y queda la otra mitad con la parte 1 cobrada
        assert c["srvB"] == [["Mesa 6", AMBOS, None]] and c["tras"] == {"dividir": True, "platos": AMBOS}, (sufijo, c)
        assert c["parte"] == {"pago": True, "dividir": False, "platos": MEDIAS, "parte": [1, 2], "avisos": []} and 3500 < c["ms"] < 8000, (sufijo, c)
        assert c["hechos"] == [["A", MEDIAS]] and c["suma"] == (CASADO + POSTRE) / 2 and c["impresos"] == [["B", AMBOS]], (sufijo, c)
        assert c["srv"] == [["Mesa 6", MEDIAS, {"total": 2, "cobradas": 1}]], (sufijo, c)
        # B quitó el Postre: A junta (el aviso de que la cuenta cambió, con el cobro de la parte abierto) y cobra la mitad del Casado, sin el Postre
        assert q["srvB"] == [["Mesa 6", CASADO1, None]] and q["tras"] == {"dividir": True, "platos": AMBOS}, (sufijo, q)
        assert q["parte"] == {"pago": True, "dividir": False, "platos": ["Casado×0.5"], "parte": [1, 2], "avisos": [CAMBIO_M6]}, (sufijo, q)
        assert q["hechos"] == [["A", ["Casado×0.5"]]] and q["suma"] == CASADO / 2 and q["impresos"] == [], (sufijo, q)
        assert q["srv"] == [["Mesa 6", ["Casado×0.5"], {"total": 2, "cobradas": 1}]], (sufijo, q)
    # con o sin la sincronización de siempre, lo mismo
    for que in ("comanda", "quita"):
        assert {**r[que + "_sinc"], "ms": 0} == {**r[que], "ms": 0}, que

    # antes de esta vuelta: sin la sincronización, igual que ahora; si la sincronización ya había traído el cambio, el paso 4 comparaba y pedía volver a
    # abrir «Dividir» (no se cobraba nada; las partes iguales de una mesa ya juntan solas en cobrarParte)
    v = _correr(tmp_path / "antes", CASOS_V5, antes=True)
    for que in ("comanda", "quita"):
        assert {**v[que], "ms": 0} == {**r[que], "ms": 0}, (que, v[que])
        x = v[que + "_sinc"]
        assert x["parte"] == {"pago": False, "dividir": False, "platos": AMBOS, "parte": None, "avisos": [VUELVA]} and x["hechos"] == [] and x["suma"] == 0, (que, x)
        assert x["srv"] == x["srvB"], (que, x)


CASOS_V5_OTROS = r"""
// la Mesa 6 (Casado y Postre ya enviados) abierta en A y en B; A abre «Dividir» y elige 2 partes iguales. B (`que`): entera, cobra la cuenta entera; estos,
// «Dividir → Cobrar estos platos» con el Casado y lo cobra; precio, le pone ₡3 000 al Casado y la guarda. Con `sinc`, pasa la sincronización de A. Si
// «Dividir» sigue abierto, A confirma y cobra la parte 1
async function v5o(que, sinc) {
  const [id, a, b] = await cuenta(true, [{ ...CASADO(), ...ENV() }, { ...POSTRE(), ...ENV() }]);
  await a.abrirDividir(); a.dividir.modo = 'partes'; a.dividir.partes = 2;
  if (que === 'entera') { await b.abrirPago(); await b.cobrar(); }
  else if (que === 'estos') { await b.abrirDividir(); elegir(b, 'Casado', 'cobrar'); await b.confirmarDividir(); await conPago(b); await b.cobrar(); }
  else await cambiar(b, 'precio', true, true);
  await hastaLibre(); await b.A.mock.guardarTodo();
  if (sinc) await a.sincronizar();
  const tras = { dividir: !!a.dividir, platos: detalles(a) };
  if (a.dividir) { await a.confirmarDividir(); await conPago(a); }
  const parte = { pago: !!a.pago, dividir: !!a.dividir, platos: detalles(a), avisos: avisos(a) };
  if (a.pago) { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
  return { tras, parte, hechos: cobrados(a), suma: suma(), srv: srvZ() };
}
for (const que of ['entera', 'estos', 'precio']) for (const sinc of [false, true]) out[que + (sinc ? '_sinc' : '')] = await v5o(que, sinc);
"""


def test_v5_las_partes_de_una_mesa_cobrada_o_cambiada_en_otro_equipo_no_cobran_dos_veces_en_node(tmp_path):
    # sin el paso 4, lo que cuidaba en las partes iguales de una mesa lo cuida cobrarParte (trae y junta la cuenta, cerradaAfuera, partesDe)
    r = _correr(tmp_path / "ahora", CASOS_V5_OTROS)
    for sufijo in ("", "_sinc"):
        e, s, p = r["entera" + sufijo], r["estos" + sufijo], r["precio" + sufijo]
        # B cobró la cuenta entera: A no cobra nada y sale el aviso de siempre (con la sincronización, «Dividir» ya se cerró ahí: V4)
        assert e["tras"] == ({"dividir": True, "platos": AMBOS} if not sufijo else {"dividir": False, "platos": []}), (sufijo, e)
        assert e["parte"] == {"pago": False, "dividir": False, "platos": [], "avisos": ["La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo"]}, (sufijo, e)
        assert e["hechos"] == [["B", AMBOS]] and e["suma"] == CASADO + POSTRE and e["srv"] == [], (sufijo, e)
        # B cobró el Casado: A cobra la mitad de lo que queda (el Postre), con el aviso de que la cuenta cambió; el Casado no se cobra dos veces
        assert s["parte"] == {"pago": True, "dividir": False, "platos": ["Postre×0.5"], "avisos": [CAMBIO_M6]}, (sufijo, s)
        assert s["hechos"] == [["B", CASADO1], ["A", ["Postre×0.5"]]] and s["suma"] == CASADO + POSTRE / 2 and s["srv"] == [["Mesa 6", ["Postre×0.5"], False]], (sufijo, s)
        # B le cambió el precio al Casado: la mitad al precio nuevo
        assert p["parte"] == {"pago": True, "dividir": False, "platos": MEDIAS, "avisos": [CAMBIO_M6]}, (sufijo, p)
        assert p["hechos"] == [["A", MEDIAS]] and p["suma"] == 1695 + POSTRE / 2 and p["srv"] == [["Mesa 6", ["Casado×0.5 a 3000", "Postre×0.5"], False]], (sufijo, p)

    # antes de esta vuelta: sin la sincronización, igual; con ella, el cobro de una parte o el precio cambiado pedían volver a abrir «Dividir» (sin cobrar)
    v = _correr(tmp_path / "antes", CASOS_V5_OTROS, antes=True)
    for k in ("entera", "estos", "precio"):
        assert v[k] == r[k], (k, v[k])
    assert v["entera_sinc"]["tras"] == {"dividir": True, "platos": []} and v["entera_sinc"]["hechos"] == r["entera_sinc"]["hechos"], v["entera_sinc"]
    for k in ("estos_sinc", "precio_sinc"):
        assert v[k]["parte"]["avisos"] == [VUELVA] and v[k]["parte"]["pago"] is False and ["A", MEDIAS] not in v[k]["hechos"], (k, v[k])


# ================================================================================================================ V6: pasar a una mesa unida a la misma cuenta
CASOS_V6 = r"""
// la Mesa 6 con Casado y Postre ya enviados (guardada por un tercer equipo); `mesa7`: unida, la Mesa 7 unida a esa cuenta («Unir mesas»: «Mesa 6 + Mesa 7»);
// libre, la Mesa 7 sin cuenta; propia, la Mesa 7 con su propia cuenta (una Limonada). A abre la Mesa 6, abre «Dividir» y pasa a la Mesa 7 el Casado (casado)
// o todo (todo). cuentaDeMesa: la de _datos.js, con la lista de cuentas de A. Después cada cuenta que quedó se cobra en un equipo nuevo
async function v6(mesa7, que) {
  nuevo();
  const g = venta(await equipo()); g.mesas = [M6, M7];
  if (mesa7 === 'propia') { g.abrirMesa(M7); g.lineas.push({ ...LIMONADA(), ...ENV() }); g.persistirCuenta(); g.volverAMesas(true); }
  g.abrirMesa(M6); g.lineas.push({ ...CASADO(), ...ENV() }, { ...POSTRE(), ...ENV() }); g.persistirCuenta();
  if (mesa7 === 'unida') { g.abrirUnir(); g.unir.sel = { 7: true }; g.confirmarUnir(); }
  await g.A.mock.guardarTodo();
  const a = venta(await equipo()); a.mesas = [M6, M7]; await a.sincronizar(); a.abrirMesa(M6);
  globalThis.cuentaDeMesa = mesaReal(a);
  const srv0 = cuentasQ(), nombre = a.nombreEspera;
  await a.abrirDividir();
  if (que === 'todo') { a.dividir.destino = 7; a.dividir.sel = Object.fromEntries(a.lineas.map((l, i) => [i, +l.cantidad])); } else elegir(a, 'Casado', 7);
  await a.confirmarDividir(); await a.A.mock.guardarTodo(); await hastaLibre(); await a.A.mock.guardarTodo();
  const r = { nombre, srv0, dividir: !!a.dividir, platos: detalles(a), cuenta: a.esperaId, avisos: avisos(a), srv: cuentasQ() };
  sinMesaReal();
  await cobrarTodas(); r.cobrados = hechos().map(h => h[2]); r.suma = suma(); r.quedan = S.items.length;
  return r;
}
for (const mesa7 of ['unida', 'libre', 'propia']) for (const que of ['casado', 'todo']) out[mesa7 + '_' + que] = await v6(mesa7, que);
"""


def _cta(nombre, platos, mesa):
    return {"nombre": nombre, "platos": platos, "prepago": 0, "pedido": None, "telefono": None, "credito": False, "cliente": None, "mesa": mesa}


UNIDA = _cta("Mesa 6 + Mesa 7", AMBOS, 6)


def test_v6_pasar_a_una_mesa_unida_a_la_misma_cuenta_avisa_y_no_cambia_nada_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V6)
    for que in ("casado", "todo"):
        x = r["unida_" + que]
        # la Mesa 7 está unida a la cuenta abierta: el aviso, «Dividir» sigue abierto, la pantalla y la cuenta del servidor intactas; después la cuenta se
        # cobra entera, una vez
        assert x["nombre"] == "Mesa 6 + Mesa 7" and x["srv0"] == [UNIDA] and x["avisos"] == [UNIDA_7], (que, x)
        assert x["dividir"] is True and x["platos"] == AMBOS and x["cuenta"] == 1 and x["srv"] == [UNIDA], (que, x)
        assert x["cobrados"] == [AMBOS] and x["suma"] == CASADO + POSTRE and x["quedan"] == 0, (que, x)
    # la Mesa 7 libre o con su propia cuenta (cuentaDeMesa real la encuentra): como siempre
    assert r["libre_casado"]["srv"] == [_cta("Mesa 6", POSTRE1, 6), _cta("Mesa 7", CASADO1, 7)] and r["libre_casado"]["avisos"] == ["Platos pasados a Mesa 7"], r
    assert r["libre_todo"]["srv"] == [_cta("Mesa 7", AMBOS, 7)] and r["libre_todo"]["avisos"] == ["Todo se pasó a Mesa 7: la cuenta quedó vacía"], r
    assert r["propia_casado"]["srv"] == [_cta("Mesa 7", ["Casado×1", "Limonada×1"], 7), _cta("Mesa 6", POSTRE1, 6)], r
    assert r["propia_todo"]["srv"] == [_cta("Mesa 7", ["Casado×1", "Limonada×1", "Postre×1"], 7)], r
    for k in ("libre_casado", "libre_todo", "propia_casado", "propia_todo"):
        assert r[k]["dividir"] is False and r[k]["quedan"] == 0 and r[k]["suma"] == CASADO + POSTRE + (LIMONADA if k.startswith("propia") else 0), (k, r[k])

    # antes de esta vuelta: la mesa unida se tomaba como otra cuenta: al pasar el Casado salía el aviso falso de un plato «que agregó otro equipo»; al pasar
    # todo, la cuenta se daba de baja sin cobrarse (₡5 311 que no se cobraron nunca). Con la Mesa 7 libre o con su propia cuenta, igual que ahora
    v = _correr(tmp_path / "antes", CASOS_V6, antes=True)
    assert v["unida_casado"]["avisos"] == ["Se sumó 1 plato que agregó otro equipo a la cuenta de Mesa 6 + Mesa 7.", "Platos pasados a Mesa 7"], v["unida_casado"]
    assert v["unida_casado"]["dividir"] is False, v["unida_casado"]
    t = v["unida_todo"]
    assert t["avisos"] == ["Todo se pasó a Mesa 7: la cuenta quedó vacía"] and t["srv"] == [] and t["cobrados"] == [] and t["suma"] == 0, t
    for k in ("libre_casado", "libre_todo", "propia_casado", "propia_todo"):
        assert v[k] == r[k], (k, v[k])


# ================================================================================================================ contrato
def _quitar_entero(k: str) -> str:
    """La línea entera de quitar y, si las tiene justo arriba, las dos líneas de su comentario de esta vuelta."""
    i = k.index("    " + QUITAR)
    j = k.rfind("    /* 4.39 (decimotercera vuelta): también con 0 en la casilla de la cantidad", 0, i)
    return k[j if j >= 0 and k.count("\n", j, i) == 2 else i:k.index("\n", i)]


def test_contrato_de_la_decimotercera_vuelta():
    # 4.39 (decimocuarta vuelta): la decimotercera se compara contra caja.js sin la decimocuarta (DECIMOCUARTA y _caja_sin_decimocuarta de
    # tests/test_439_tercera_vuelta.py): la decimocuarta cambió la línea de quitar (U1) y el comentario de V6 (U6). Su contrato está en
    # tests/test_439_decimocuarta_vuelta.py
    k, k0 = _caja_sin_decimocuarta(), _caja_sin_decimotercera()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    qk, qk0 = _quitar_entero(k), _quitar_entero(k0)
    # cada tripleta de DECIMOTERCERA: «lo de ahora» está en caja.js las veces anotadas, en su método (o en la plantilla); «lo de antes» ya no está (salvo
    # dentro de «lo de ahora»: V4 y el comentario de V6 agregan líneas antes de una que sigue). Se deshacen en orden inverso: «lo de antes» de cada una
    # está, las veces anotadas, en caja.js con las que van después ya deshechas (el comentario de V6, el último, se aplicó sobre la línea ya cambiada
    # por V6) y al final queda caja.js sin la vuelta. Los cuatro métodos y quitar cambiaron
    assert len(DECIMOTERCERA) == 8 and len(DE_CADA) == 8
    plantilla, estado = k[k.index("  template: `"):], k
    for (viejo, nuevo, veces), c in reversed(list(zip(DECIMOTERCERA, DE_CADA))):
        assert estado.count(nuevo) == veces and k.count(nuevo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        estado = estado.replace(nuevo, viejo)
        assert estado.count(viejo) == veces and estado.count(nuevo) == 0, nuevo[:120]
        assert k.count(viejo) == (veces if viejo in nuevo else 0), nuevo[:120]
        donde = plantilla if c is None else qk if c == QUITAR else metodos[c]
        assert donde.count(nuevo) == veces, (c, nuevo[:120])
    assert estado == k0
    for c in metodos:
        assert metodos[c] != antes[c], c
    assert qk != qk0 and qk0.startswith("    " + QUITAR)
    # fuera de ellos (y de la casilla de la cantidad), caja.js no cambió: ningún método nuevo (los arneses sacan los métodos por texto)
    v2a, v2b = DECIMOTERCERA[1][:2]
    resto, resto0 = k.replace(qk, "@QUITAR@").replace(v2b, "@CASILLA@"), k0.replace(qk0, "@QUITAR@").replace(v2a, "@CASILLA@")
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], "@" + c + "@"), resto0.replace(antes[c], "@" + c + "@")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (V1, V2 en quitar, V3, V4, V5 y V6)
    assert k.count("4.39 (decimotercera vuelta)") == 6 and k0.count("4.39 (decimotercera vuelta)") == 0
    aw, cp, si, cd = (metodos[c] for c in CAMBIADOS)
    # V1: el pedido se anota en cuanto el PUT sale bien, antes del aviso, de sincronizar y de recargar la ventana; imprimirComandaWeb lo sigue anotando
    v1 = "(this._entAvisados || (this._entAvisados = new Set())).add(+p.id);"
    assert aw.count(v1) == 1 and aw.index("catch (e) { toast(e.message, 'err'); return; }") < aw.index(v1) < aw.index("toast(pw.imprime === false") \
        < aw.index("this.sincronizar();") < aw.index("await this.cargarPanelWeb();")
    assert _metodo(k, "async imprimirComandaWeb(p) {").count("if (ok) " + v1) == 1
    # V2: la casilla con cantidad > 0 vuelve a calcular la promoción (como «−» y «+»); con 0 o vacía, quitar (la clave de anular si ya se mandó a cocina; con
    # la clave negada, la cantidad de la base o 1); quitar sigue recalculando el 2x1 y revisando si la cuenta quedó vacía
    assert _expresion(k) == "+l.cantidad > 0 ? aplicarPromos(l) : quitar(l)" and _expresion(k0) == "aplicarPromos(l)"
    assert "this.aplicarPromos(); this.cuentaVacia();" in qk and "await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina')" in qk
    assert "l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1; } return; }" in qk and "this._base.id === this.esperaId" in qk
    # V3: lo que queda de cada línea sale de su propia parte; ya no de la parte filtrada por posición
    assert "parte[i]" not in cp and cp.count("this.lineas.map(l => restoDe(l, Math.round(((+l.cantidad || 0) - Math.round(((+l.cantidad || 0) / faltan) * 1000) / 1000) * 1000) / 1000))") == 1
    # V4: en la rama de la cuenta cobrada o cerrada en otro equipo, «Dividir» se cierra después del aviso y antes de dejar lo nuevo en pantalla
    assert si.index("fue cobrada o cerrada en otro equipo") < si.index("this.dividir = null;") < si.index("if (nuevas.length) { this.lineas = nuevas;")
    # V5: el paso 4 no corre para las partes iguales de una mesa (las de una cuenta sin mesa y la caja de comercio, sí)
    assert cd.count("&& !(d.modo === 'partes' && this.esRestaurante && this.mesaActual) && idx !== null") == 1
    # V6: una mesa unida a esta misma cuenta avisa antes de tocar nada (ni la otra cuenta ni «Dividir»)
    v6 = "if (cu && cu.id === this.esperaId) return toast(m.nombre + ' ya está unida a esta cuenta', 'err'); if (cu) {"
    assert cd.count(v6) == 1 and cd.index(v6) < cd.index("this.lineas = resto; this.dividir = null;", cd.index(v6))
    # las notas de la versión cuentan la vuelta: «Preparando…» cada vez, la mesa unida en el párrafo de «Dividir», «Cantidad en 0», el piso de avisarEntrados
    # en la duodécima, Técnico (la decimotercera vuelta) y la lista de pruebas hasta este archivo; cada frase nueva una vez
    # 4.39 (decimocuarta vuelta): la decimocuarta reescribió el final de la frase de la mesa unida («y en "A dónde" esa mesa dice…», con lo de antes
    # corregido), agregó a «Cantidad en 0» lo de la clave negada, F4/F8/F9 y la sincronización, y llevó la lista de pruebas hasta
    # test_439_decimocuarta_vuelta.py: aquí quedan solo los principios de esas frases que no cambiaron; las frases enteras de ahora las exige el contrato
    # de tests/test_439_decimocuarta_vuelta.py
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("En la página web, cada vez que se abre «Pedidos web» el botón del pedido nuevo dice «Preparando…» un instante mientras la caja lee lo de imprimir.",
              "Con «Cobrar estos platos», si otro equipo ya cobró la cuenta o una parte, al cobrar avisa y no emite. Pasar platos a una mesa unida a la misma cuenta "
              "avisa que ya está unida",
              "- [arreglo] **Cantidad en 0.** Escribir 0 en la cantidad de un plato lo quita, como «✕» (con la clave de anular si ya se mandó a cocina",
              "Antes la pantalla lo escondía pero la cuenta guardada lo conservaba y se cobraba después; y al cobrar por partes iguales una cuenta con un plato en 0 "
              "se podía cobrar de más.\n- [arreglo] **Modo cajero.**",
              "Duodécima vuelta: avisarEntrados sube el piso cuando la cuenta del tope está en la lista traída o a los 6 intentos, como en la 4.38 (ya no porque el "
              "pedido figure en _entAvisados), y la primera respuesta conserva _entAvisados; si la consulta de pedidos llegó mientras se aceptaba o cancelaba, se "
              "vuelve a leer (revisarOnline) en vez de dejar el número viejo; en el programa, «Aceptar pedido» avisa sin decir que la comanda sale sola.",
              "Decimotercera vuelta: aceptarWeb anota el pedido en _entAvisados en cuanto el PUT sale bien; la casilla de la cantidad en 0 llama a quitar (con la "
              "clave negada vuelve a la cantidad de la base); cobrarParte calcula el resto de cada línea con su propia parte; sincronizar cierra «Dividir» cuando la "
              "cuenta abierta ya no está; el paso 4 de confirmarDividir no compara las partes de una mesa (cobrarParte trae y junta); pasar platos a una mesa unida "
              "a la misma cuenta avisa y no cambia nada."):
        assert notas.count(t) == 1, t
    # y ya no dicen lo de antes
    for t in ("la primera vez que se abre «Pedidos web»", "avisarEntrados sube el piso solo cuando", "de test_439_segunda_vuelta.py a test_439_duodecima_vuelta.py"):
        assert notas.count(t) == 0, t
