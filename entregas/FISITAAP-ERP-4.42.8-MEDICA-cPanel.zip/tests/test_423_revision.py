# -*- coding: utf-8 -*-
"""4.23 · Gastos: lo que encontró la revisión, sobre tests/test_423_gastos.py y tests/test_423_adenda.py:
H1 · dos peticiones a la vez sobre el mismo comprobante no anotan dos rectificaciones;
H2 · borrar completa la lista de compras también deja en Rectificaciones lo de meses pasados;
H3 · la factura de un comprobante RECHAZADO (07) no cuenta por sí misma;
H4 y H5 · al eliminar (o registrar de nuevo) una factura recibida, sus notas de crédito de meses pasados también quedan anotadas;
H6 · el ajuste aj: que quedó en un mes cerrado tampoco se toca: lo que cambie después va en el siguiente de la cadena;
H7 · un cambio en Parametrización no es una rectificación: no genera ajustes de los meses cerrados;
H8 · Rectificaciones muestra el estado de hoy del periodo contable."""
import json
import pathlib
import shutil
import subprocess

import pytest
from sqlmodel import Session

from app import main, recepcion
from app.db import engine_empresa
from tests.test_423_adenda import _sincronizar
from tests.test_423_gastos import AHORA, MOTIVO, NODOS, NOVIEMBRE, OCTUBRE, _aceptado, _alta, _auditoria, _compra, _compras, _ctx, _eid, _js, _octubre, _recibido, _rects
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

SETIEMBRE = "2026-09-10T10:00:00-06:00"


@pytest.fixture(autouse=True)
def _reloj(monkeypatch):
    """«Hoy» es el 10 de noviembre de 2026 (como en test_423_gastos); y el resumen no sale a buscar el tipo de cambio."""
    monkeypatch.setattr(main, "ahora_cr", lambda: AHORA)

    def _sin_red():
        raise RuntimeError("sin red en las pruebas")
    monkeypatch.setattr(main.tipo_cambio, "obtener", _sin_red)


# ------------------------------------------------------------------------------------------------ H1 · dos peticiones a la vez
def _otra_peticion_primero(monkeypatch, hacer):
    """Dos peticiones a la vez sobre el mismo comprobante: las dos lo leen como estaba; una hace lo suyo y confirma mientras la
    otra espera el candado de escritura. Aquí «la primera» corre entera, con su propia sesión, justo después de que la petición
    de la prueba leyó el comprobante (y antes de que revise o escriba nada)."""
    real, estado = main._recibido, {"hacer": hacer, "hecha": False}

    def recibido(s, eid, rid):
        r = real(s, eid, rid)
        ahora, estado["hacer"] = estado["hacer"], None
        if ahora:
            estado["hecha"] = True
            with Session(engine_empresa(eid)) as otra:
                ahora(otra)
        return r
    monkeypatch.setattr(main, "_recibido", recibido)
    return estado


def test_h1_dos_eliminaciones_a_la_vez_anotan_una_rectificacion(api, monkeypatch):  # noqa: F811
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    estado = _otra_peticion_primero(monkeypatch, lambda otra: main.quitar_registro_recepcion(rid, main.MotivoRegistroIn(motivo=MOTIVO), _ctx(), otra))
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
    assert estado["hecha"] is True
    # la segunda ve lo que dejó la primera: ya no está en el registro, y no anota otra vez
    assert r.status_code == 409 and "ya no está en el registro" in r.json()["detail"], r.text
    assert [(x["accion"], x["recibido_id"]) for x in _rects(c)] == [("eliminado", rid)]
    assert _recibido(rid).registrado is False
    assert [a for a, _ in _auditoria(_eid())] == ["gastos_registro_quitado"]


def test_h1_dos_registros_a_la_vez_anotan_una_rectificacion(api, monkeypatch):  # noqa: F811
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    estado = _otra_peticion_primero(monkeypatch, lambda otra: main.registrar_recepcion(rid, main.RegistrarRecepcionIn(clasificacion="gasto", motivo=MOTIVO), _ctx(), otra))
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO})
    assert estado["hecha"] is True
    assert r.status_code == 409 and "ya está registrado" in r.json()["detail"], r.text
    assert [x["accion"] for x in _rects(c)] == ["eliminado", "registrado"]
    assert _recibido(rid).registrado is True
    # y el rechazo no deja tomado el candado: la siguiente petición guarda sin esperar
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200


def test_h1_dos_cambios_de_clasificacion_a_la_vez_anotan_una_rectificacion(api, monkeypatch):  # noqa: F811
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    estado = _otra_peticion_primero(monkeypatch, lambda otra: main.clasificar_recepcion(rid, main.ClasificacionRecepcionIn(clasificacion="compra"), _ctx(), otra))
    r = c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra", "cuenta_contable": None})
    assert estado["hecha"] is True
    # para la segunda ya era compra: guarda sin cambios y no anota
    assert r.status_code == 200 and r.json()["clasificacion"] == "compra", r.text
    assert [(x["accion"], x["tipo"], x["tipo_anterior"]) for x in _rects(c)] == [("reclasificado", "compra", "gasto")]
    # eliminar y reclasificar a la vez: el cambio de clasificación de lo que ya salió del registro no es una rectificación
    estado.update(hecha=False, hacer=lambda otra: main.quitar_registro_recepcion(rid, main.MotivoRegistroIn(motivo=MOTIVO), _ctx(), otra))
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "gasto"}).status_code == 200 and estado["hecha"] is True
    assert [x["accion"] for x in _rects(c)] == ["reclasificado", "eliminado"]


# ------------------------------------------------------------------------------------------------ H2 · borrar la lista completa
def test_h2_borrar_la_lista_completa_tambien_anota(api):  # noqa: F811
    """DELETE /api/registros/compras saca de los reportes todas las facturas a mano: las de meses pasados quedan en Rectificaciones
    (con el motivo vacío), igual que al borrarlas por el guardado genérico."""
    c = api
    rid = _aceptado(1, OCTUBRE, "gasto")
    _alta(c, _compra(1, "2026-10-15", "gasto"), _compra(2, "2026-11-04", "gasto"), _compra(3, "2026-10-08", "gasto", recepcion_id=rid, clave=_recibido(rid).clave),
          _compra(4, "2026-09-16", "compra", pagado=500))
    antes, _ = _octubre(c)
    assert antes["egresos_docs"] == 2                              # la hecha a mano de octubre y el comprobante aceptado (su factura no cuenta aparte)
    r = c.delete("/api/registros/compras")
    assert r.status_code == 200 and _compras(c) == {}
    despues, _ = _octubre(c)
    assert despues["egresos_docs"] == 1                            # la factura a mano salió de los reportes; el aceptado sigue en el registro
    # quedan anotadas las de meses pasados que contaban por sí mismas; no la del mes en curso ni la del comprobante que sigue aceptado y registrado
    assert [(x["accion"], x["origen"], x["compra_id"], x["tipo"], x["mes"], x["motivo"], x["total"], x["iva_acreditar"], x["usuario"]) for x in _rects(c)] == \
        [("eliminado", "manual", 1, "gasto", "2026-10", "", 11300.0, 1300.0, "qa-exo@example.test"), ("eliminado", "manual", 4, "compra", "2026-09", "", 11300.0, 1300.0, "qa-exo@example.test")]
    assert _recibido(rid).registrado is True
    assert _auditoria(_eid()) == [("gastos_registro_quitado", "Gasto FC-0001 de Proveedor QA eliminado del registro · rectificación de octubre de 2026"),
                                  ("gastos_registro_quitado", "Compra FC-0004 de Proveedor QA eliminada del registro · rectificación de setiembre de 2026")]
    # con la lista ya vacía, o al borrar otro registro, no se anota nada
    assert c.delete("/api/registros/compras").status_code == 200 and c.delete("/api/registros/pagos_gastos").status_code == 200
    assert len(_rects(c)) == 2


# ------------------------------------------------------------------------------------------------ H3 · la factura de un comprobante rechazado
GUION_H3 = r"""
periodos('Abierto', 'Abierto');
S.recibidos = [rec(1, { respuesta: '07' }), rec(2, { respuesta: '07', estado_mensaje: 'error' }), rec(3, { respuesta: null, estado_mensaje: null })];
S.datos.compras = [com(1, { recepcion_id: 1 }), com(2, { clave: rec(2).clave }), com(3, { recepcion_id: 1, clave: rec(1).clave }), com(4), com(5, { recepcion_id: 3, clave: rec(3).clave })];
o.inicial = await sinc(); o.origenes0 = origenes();
// se rechaza el que estaba sin responder: el asiento de su factura se va
R(3).respuesta = '07';
o.rechazado = await sinc(); o.origenes1 = origenes();
"""


def test_h3_la_factura_de_un_comprobante_rechazado_no_cuenta(api, tmp_path):  # noqa: F811
    """El XML se registró para pagar y después se RECHAZÓ ante Hacienda (07): ni el comprobante ni su factura cuentan en los reportes,
    en la D-104 ni en los asientos (como antes de la 4.23). La factura sigue en la lista, para pagarla o eliminarla."""
    c = api
    rech = _aceptado(1, OCTUBRE, "gasto", respuesta="07")
    clave = _recibido(rech).clave
    _alta(c, _compra(1, "2026-10-10", "gasto", recepcion_id=rech, clave=clave), _compra(2, "2026-10-11", "compra", clave=clave), _compra(3, "2026-10-12", "gasto"))
    res, d104 = _octubre(c)
    assert res["egresos_docs"] == 1 and res["egresos"]["CRC"] == 11300 and res["iva"]["credito"]["CRC"] == 1300 and res["iva"]["docs_recibidos"] == 1
    assert [(x["origen"], x["id"]) for x in res["detalle"]["egresos"]] == [("Compra registrada", 3)] and "rec" not in d104
    assert (d104["08"]["docs"], d104["08"]["compras"], d104["08"]["credito"]) == (1, 10000.0, 1300.0)
    # como no contaba, cambiarla de clasificación o eliminarla no es una rectificación: no pide motivo ni anota nada
    assert c.post("/api/registros/compras/cambios", json={"upserts": [{**_compras(c)[1], "tipo": "compra"}], "deletes": [], "nuevos": []}).status_code == 200
    r = c.post("/api/gastos/compras/1/eliminar", json={})
    assert r.status_code == 200 and r.json()["rectificacion"] is None and r.json()["compras_eliminadas"] == [1], r.text
    assert c.post("/api/registros/compras/cambios", json={"upserts": [], "deletes": [2], "nuevos": []}).status_code == 200
    assert _rects(c) == [] and set(_compras(c)) == {3}
    # la hecha a mano sí contaba: de un mes pasado pide el motivo
    assert c.post("/api/gastos/compras/3/eliminar", json={}).status_code == 400
    # los asientos, con la sincronización de verdad: la factura del rechazado (por su recepcion_id o por su clave) no lleva asiento cm:
    o = _sincronizar(tmp_path, GUION_H3)
    assert o["inicial"]["creados"] == 2 and o["origenes0"] == ["cm:4", "cm:5"]
    assert (o["rechazado"]["creados"], o["rechazado"]["eliminados"]) == (0, 1) and o["origenes1"] == ["cm:4"]


# ------------------------------------------------------------------------------------------------ H4 y H5 · las notas de crédito de la factura
def _nota(n, fecha, de_rid, aceptada=True):
    """Una nota de crédito recibida (03) que se refiere al comprobante `de_rid`; aceptada y registrada, o todavía sin responder."""
    nid = _aceptado(n, fecha, "gasto")
    with Session(engine_empresa(_eid())) as s:
        x = s.get(recepcion.Recibido, nid)
        x.tipo_documento, x.referencia_clave = "03", s.get(recepcion.Recibido, de_rid).clave
        if not aceptada:
            x.respuesta = x.estado_mensaje = None
        s.add(x); s.commit()
    return nid


def test_h4_h5_las_notas_de_credito_de_la_factura_tambien_quedan_anotadas(api):  # noqa: F811
    """Al eliminar del registro una factura recibida, sus notas de crédito aceptadas dejan de restar (y vuelven a restar al
    registrarla de nuevo): cada nota de un mes pasado queda en Rectificaciones, en su mes y en negativo."""
    c = api
    factura, otra = _aceptado(1, SETIEMBRE, "compra"), _aceptado(2, SETIEMBRE, "gasto")
    nota, de_otra = _nota(3, OCTUBRE, factura), _nota(4, OCTUBRE, otra)
    de_hoy, pendiente = _nota(5, NOVIEMBRE, factura), _nota(6, OCTUBRE, factura, aceptada=False)
    total, iva = _recibido(factura).total, recepcion.iva_recibido(_recibido(factura))

    def octubre():
        res, d104 = _octubre(c)
        return res["egresos_docs"], res["egresos"]["CRC"], res["iva"]["credito"]["CRC"], d104.get("rec", {}).get("credito", 0)
    assert octubre() == (2, round(-2 * total, 2), round(-2 * iva, 2), round(-2 * iva, 2))            # las dos notas de octubre restan
    r = c.post(f"/api/recepcion/{factura}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200 and r.json()["rectificacion"]["recibido_id"] == factura, r.text
    assert octubre() == (1, round(-total, 2), round(-iva, 2), round(-iva, 2))                        # la nota de la factura eliminada ya no resta
    rects = _rects(c)
    # la factura en setiembre y SU nota de octubre en octubre, con su signo; no la del mes en curso, la de otra factura ni la que no está aceptada
    assert [(x["id"], x["accion"], x["recibido_id"], x["tipo_documento"], x["tipo"], x["mes"], x["total"], x["iva_acreditar"], x["motivo"]) for x in rects] == \
        [(1, "eliminado", factura, "01", "compra", "2026-09", total, iva, MOTIVO), (2, "eliminado", nota, "03", "gasto", "2026-10", -total, -iva, MOTIVO)]
    assert rects[1]["documento"] == _recibido(nota).consecutivo and rects[1]["usuario"] == "qa-exo@example.test" and rects[1]["fecha_documento"] == "2026-10-08"
    assert all(_recibido(x).registrado is True for x in (nota, de_otra, de_hoy, pendiente))          # las notas no se tocan
    # registrarla de nuevo: entra la factura y vuelve a restar su nota
    r = c.post(f"/api/recepcion/{factura}/registrar", json={"clasificacion": "compra", "motivo": "Sí era de la empresa"})
    assert r.status_code == 200 and r.json()["rectificacion"]["id"] == 3, r.text
    assert octubre() == (2, round(-2 * total, 2), round(-2 * iva, 2), round(-2 * iva, 2))
    assert [(x["id"], x["accion"], x["recibido_id"], x["mes"], x["total"], x["motivo"]) for x in _rects(c)[2:]] == \
        [(3, "registrado", factura, "2026-09", total, "Sí era de la empresa"), (4, "registrado", nota, "2026-10", -total, "Sí era de la empresa")]
    # por la ruta de la factura del registro 'compras' pasa lo mismo (saca el comprobante y anota su nota)
    _alta(c, _compra(1, "2026-09-10", "compra", recepcion_id=factura, clave=_recibido(factura).clave))
    assert c.post("/api/gastos/compras/1/eliminar", json={"motivo": MOTIVO}).status_code == 200
    assert [(x["accion"], x["recibido_id"], x["mes"]) for x in _rects(c)[4:]] == [("eliminado", factura, "2026-09"), ("eliminado", nota, "2026-10")]
    # la nota que se elimina ella sola se anota una vez; y la factura que ya no tiene notas en el registro, sola
    assert c.post(f"/api/recepcion/{de_otra}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert c.post(f"/api/recepcion/{otra}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert [(x["accion"], x["recibido_id"]) for x in _rects(c)[6:]] == [("eliminado", de_otra), ("eliminado", otra)]
    # con su factura fuera del registro la nota no resta: registrarla o quitarla no cambia ningún mes, así que no pide motivo ni se
    # anota; queda anotada, una sola vez, cuando vuelve a entrar su factura
    r = c.post(f"/api/recepcion/{de_otra}/registrar", json={"clasificacion": "gasto"})
    assert r.status_code == 200 and r.json()["rectificacion"] is None and _recibido(de_otra).registrado is True, r.text
    assert c.post(f"/api/recepcion/{de_otra}/quitar-registro", json={}).status_code == 200 and c.post(f"/api/recepcion/{de_otra}/registrar", json={"clasificacion": "gasto"}).status_code == 200
    assert len(_rects(c)) == 8 and octubre()[:2] == (0, 0)
    assert c.post(f"/api/recepcion/{otra}/registrar", json={"clasificacion": "gasto"}).status_code == 400              # la factura sí: es de un mes pasado
    assert c.post(f"/api/recepcion/{otra}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO}).status_code == 200
    assert [(x["accion"], x["recibido_id"], x["mes"]) for x in _rects(c)[8:]] == [("registrado", otra, "2026-09"), ("registrado", de_otra, "2026-10")]
    # Rectificaciones cuadra con los reportes: octubre empezó con dos notas restando; lo que salió y lo que entró deja lo que hay hoy
    de_octubre = lambda accion: sum(x["total"] for x in _rects(c) if x["mes"] == "2026-10" and x["accion"] == accion)   # noqa: E731
    assert (de_octubre("eliminado"), de_octubre("registrado")) == (round(-3 * total, 2), round(-2 * total, 2))
    assert octubre()[:2] == (1, round(-2 * total - de_octubre("eliminado") + de_octubre("registrado"), 2)) == (1, round(-total, 2))


# ------------------------------------------------------------------------------------------------ H6 · el ajuste que quedó en un mes cerrado
GUION_H6 = r"""
const per = (oct, nov, dic) => { S.datos.periodos_2026 = [{ n: 10, mes: 'Octubre', estado: oct }, { n: 11, mes: 'Noviembre', estado: nov }, { n: 12, mes: 'Diciembre', estado: dic }]; };
const A = 'Abierto', C = 'Cerrado';
// lo que dicen los libros de un documento, cuenta por cuenta, sumando su asiento y todos sus ajustes
const neto = id => { const m = {}; for (const a of mock.get('asientos', [])) if (new RegExp('^(aj:)?rec:' + id + '(:\\d+)?$').test(a.origen || '')) for (const l of a.lineas) m[l.cuenta] = Math.round(((m[l.cuenta] || 0) + l.debito - l.credito) * 100) / 100;
  return Object.fromEntries(Object.entries(m).filter(([, v]) => v).sort()); };
const deLineas = ls => { const m = {}; for (const [c, d, h] of ls) m[c] = Math.round(((m[c] || 0) + d - h) * 100) / 100; return Object.fromEntries(Object.entries(m).filter(([, v]) => v).sort()); };
const ver = x => { const a = asiento(x); return a ? { fecha: a.fecha, obs: a.observaciones, lineas: lineas(x), cuadra: cuadra(x), codigo: /^AU-\d+$/.test(a.codigo), automatico: a.automatico, ajustado: a.ajustado } : null; };
per(A, A, A);
S.recibidos = [rec(12, { total: 565000, impuesto: 65000, iva: 65000, monto_impuesto_acreditar: 65000 }), rec(14)];
o.inicial = await sinc();
o.gasto = deLineas(lineas('rec:12'));
// octubre está cerrado; en noviembre los dos se eliminan del registro: el reverso de cada uno queda en noviembre
per(C, A, A);
for (const id of [12, 14]) { R(id).registrado = false; rectificacion({ recibido_id: id, accion: 'eliminado', fecha: '2026-11-05T09:00:00-06:00' }); }
o.eliminados = await sinc(); o.neto1 = [neto(12), neto(14)];
// se cierra noviembre: nada cambia, y los reversos (que siguen vigentes) no se avisan como huérfanos
per(C, C, A); S.hoy = '2026-12-03';
const cerrados = () => JSON.stringify(['rec:12', 'aj:rec:12', 'rec:14', 'aj:rec:14'].map(asiento)), antes = cerrados();
o.alCerrarNoviembre = await sinc(); o.origenes1 = origenes();
// en diciembre el 12 se vuelve a registrar igual, y el 14 como compra: cada uno vuelve a contar UNA vez, con un ajuste nuevo en diciembre
R(12).registrado = true; rectificacion({ recibido_id: 12, accion: 'registrado', fecha: '2026-12-04T09:00:00-06:00' });
Object.assign(R(14), { registrado: true, clasificacion: 'compra' }); rectificacion({ recibido_id: 14, accion: 'registrado', fecha: '2026-12-02T09:00:00-06:00' });
o.registrados = await sinc(); o.origenes2 = origenes(); o.intactos = cerrados() === antes;
o.aj12 = ver('aj:rec:12:2'); o.aj14 = ver('aj:rec:14:2'); o.neto2 = [neto(12), neto(14)];
// sincronizar otra vez, otro día: no lo mueve ni lo duplica, y no guarda nada
S.hoy = '2026-12-20'; const foto = JSON.stringify(mock.get('asientos', []));
o.otraVez = await sinc(); o.igual = JSON.stringify(mock.get('asientos', [])) === foto;
// el 12 pasa a compra en diciembre (abierto): el mismo ajuste de diciembre se actualiza; el 14 se elimina otra vez: su ajuste de diciembre se va
R(12).clasificacion = 'compra'; rectificacion({ recibido_id: 12, accion: 'reclasificado', fecha: '2026-12-21T09:00:00-06:00' });
R(14).registrado = false; rectificacion({ recibido_id: 14, accion: 'eliminado', fecha: '2026-12-21T10:00:00-06:00' });
o.cambiados = await sinc(); o.origenes3 = origenes(); o.neto3 = [neto(12), neto(14)]; o.intactos3 = cerrados() === antes;
// se cierra diciembre con el ajuste del 12 adentro; en enero el 12 se elimina: el tercer eslabón reversa lo que quedó en libros
per(C, C, C); S.hoy = '2027-01-08';
R(12).registrado = false; rectificacion({ recibido_id: 12, accion: 'eliminado', fecha: '2027-01-07T09:00:00-06:00' });
const dic = JSON.stringify(asiento('aj:rec:12:2'));
o.enero = await sinc(); o.origenes4 = origenes(); o.aj12c = ver('aj:rec:12:3'); o.neto4 = neto(12); o.intactos4 = cerrados() === antes && JSON.stringify(asiento('aj:rec:12:2')) === dic;
// se reabre noviembre (octubre y diciembre siguen cerrados): el ajuste de noviembre vuelve a ser el que se actualiza y los libros siguen bien
per(C, A, C);
o.reabierto = await sinc(); o.origenes5 = origenes(); o.neto5 = neto(12);
"""


def test_h6_el_ajuste_de_un_mes_que_tambien_se_cerro_no_deja_el_documento_en_cero(tmp_path):
    o = _sincronizar(tmp_path, GUION_H6)
    nada = {"creados": 0, "actualizados": 0, "eliminados": 0, "bloqueados": 0, "huerfanos": [], "guardo": False}
    gasto, cxp, iva = "6.2.02.20", "2.1.01.01.01", "1.1.04.01.01.01"
    assert o["inicial"]["creados"] == 2 and o["gasto"] == {gasto: 500000, iva: 65000, cxp: -565000}
    e = o["eliminados"]
    assert (e["creados"], e["bloqueados"], e["huerfanos"]) == (2, 0, []) and o["neto1"] == [{}, {}]            # asiento de octubre + reverso de noviembre = 0
    # al cerrar noviembre no pasa nada: el reverso cerrado no es un huérfano (sigue vigente)
    assert o["alCerrarNoviembre"] == nada and o["origenes1"] == ["aj:rec:12", "aj:rec:14", "rec:12", "rec:14"]
    # vuelto a registrar con noviembre cerrado: el documento vuelve a los libros en diciembre (antes quedaba en cero y sin ajuste)
    r = o["registrados"]
    assert (r["creados"], r["actualizados"], r["eliminados"], r["bloqueados"], r["huerfanos"]) == (2, 0, 0, 0, []) and o["intactos"] is True
    assert o["origenes2"] == ["aj:rec:12", "aj:rec:12:2", "aj:rec:14", "aj:rec:14:2", "rec:12", "rec:14"]
    assert o["aj12"] == {"fecha": "2026-12-04", "obs": "Ajuste por rectificación · C12 de octubre de 2026", "lineas": [[gasto, 500000, 0], [iva, 65000, 0], [cxp, 0, 565000]],
                         "cuadra": True, "codigo": True, "automatico": True, "ajustado": False}
    assert o["aj14"]["fecha"] == "2026-12-02" and o["aj14"]["lineas"] == [["5.1.01.01", 1000, 0], [iva, 130, 0], [cxp, 0, 1130]] and o["aj14"]["cuadra"] is True    # registrado como compra
    assert o["neto2"] == [{gasto: 500000, iva: 65000, cxp: -565000}, {"5.1.01.01": 1000, iva: 130, cxp: -1130}]
    assert o["otraVez"] == nada and o["igual"] is True
    # el ajuste que sigue en un mes abierto es el que se actualiza o se quita
    k = o["cambiados"]
    assert (k["creados"], k["actualizados"], k["eliminados"], k["bloqueados"], k["huerfanos"]) == (0, 1, 1, 0, []) and o["intactos3"] is True
    assert o["origenes3"] == ["aj:rec:12", "aj:rec:12:2", "aj:rec:14", "rec:12", "rec:14"]
    assert o["neto3"] == [{"5.1.01.01": 500000, iva: 65000, cxp: -565000}, {}]
    # tercer eslabón: con diciembre también cerrado, la eliminación de enero se reversa en enero
    n = o["enero"]
    assert (n["creados"], n["actualizados"], n["eliminados"], n["bloqueados"], n["huerfanos"]) == (1, 0, 0, 0, []) and o["intactos4"] is True
    assert o["origenes4"] == ["aj:rec:12", "aj:rec:12:2", "aj:rec:12:3", "aj:rec:14", "rec:12", "rec:14"]
    assert o["aj12c"]["fecha"] == "2027-01-07" and o["aj12c"]["obs"] == "Reverso por rectificación · C12 de octubre de 2026" and o["aj12c"]["cuadra"] is True
    assert o["aj12c"]["lineas"] == [[iva, 0, 65000], [cxp, 565000, 0], ["5.1.01.01", 0, 500000]] and o["neto4"] == {}      # lo que quedó en libros: como compra
    # al reabrir un mes de en medio los libros siguen diciendo lo mismo (el documento está eliminado: neto cero), sin huérfanos ni repetidos
    assert o["reabierto"]["huerfanos"] == [] and o["reabierto"]["bloqueados"] == 0 and o["neto5"] == {}
    assert o["origenes5"] == ["aj:rec:12", "aj:rec:12:2", "aj:rec:14", "rec:12", "rec:14"]
    au = _js("pages", "contabilidad", "automaticos.js")
    assert "fuentes.push({ origen: 'aj:' + origen + sufijo, fecha: fechaAbierta(ultima || hoy())," in au
    assert "const f = porFuente.get(origen), cadena = cadenas.get(origen) || [], fijos = cadena.filter(a => periodoCerrado(a.fecha));" in au


# ------------------------------------------------------------------------------------------------ H7 · un cambio en Parametrización no es una rectificación
GUION_H7 = r"""
periodos('Abierto', 'Abierto');
S.recibidos = [rec(1), rec(2, { clasificacion: 'compra' }), rec(3, { fecha_emision: '2026-11-03T10:00:00-06:00' }), rec(4), rec(5)];
S.datos.compras = [com(1), com(2, { creacion: '2026-11-03' }), com(3)];
o.inicial = await sinc();
periodos('Cerrado', 'Abierto');
const octubre = () => JSON.stringify(mock.get('asientos', []).filter(a => a.fecha < '2026-11-01')), antes = octubre();
o.deOctubre = mock.get('asientos', []).filter(a => a.fecha < '2026-11-01').length;
// el contador cambia en Parametrización la cuenta por pagar, la de gastos y la del IVA acreditable, para lo que viene
S.datos.param_contable = { cxp: '2.1.01.01.02 Cuentas por pagar a proveedores del exterior', compras_gastos: '6.2.02.05 Papelería', iva_credito: '1.1.04.01.01.02 IVA soportado' };
o.parametros = await sinc(); o.origenes1 = origenes(); o.intactos = octubre() === antes;
o.rec3 = lineas('rec:3'); o.cm2 = lineas('cm:2');
// lo que SÍ se rectificó lleva su ajuste: el 4 se elimina del registro, el 5 pasa a compra (con su anotación) y la factura a mano 3 se elimina
R(4).registrado = false; rectificacion({ recibido_id: 4, accion: 'eliminado', fecha: '2026-11-06T09:00:00-06:00' });
R(5).clasificacion = 'compra'; rectificacion({ recibido_id: 5, accion: 'reclasificado', fecha: '2026-11-07T09:00:00-06:00' });
S.datos.compras = [com(1), com(2, { creacion: '2026-11-03' })];
o.rectificado = await sinc(); o.origenes2 = origenes(); o.intactos2 = octubre() === antes;
o.aj4 = lineas('aj:rec:4'); o.cerrado4 = lineas('rec:4'); o.aj5 = lineas('aj:rec:5'); o.aj5cuadra = cuadra('aj:rec:5'); o.ajCm3 = lineas('aj:cm:3'); o.cerradoCm3 = lineas('cm:3');
"""


def test_h7_cambiar_una_cuenta_en_parametrizacion_no_genera_ajustes(tmp_path):
    o = _sincronizar(tmp_path, GUION_H7)
    base = ["cm:1", "cm:2", "cm:3", "rec:1", "rec:2", "rec:3", "rec:4", "rec:5"]
    assert o["inicial"]["creados"] == 8 and o["deOctubre"] == 6
    # los seis asientos de octubre (cerrado) quedan como estaban, con el aviso de siempre, y NO se trasladan sus saldos con ajustes en
    # noviembre; los dos de noviembre (abierto) se reescriben con las cuentas nuevas
    p = o["parametros"]
    assert (p["creados"], p["actualizados"], p["eliminados"], p["bloqueados"], p["huerfanos"], p["guardo"]) == (0, 2, 0, 6, [], True)
    assert o["origenes1"] == base and o["intactos"] is True
    assert o["rec3"] == [["6.2.02.05", 1000, 0], ["1.1.04.01.01.02", 130, 0], ["2.1.01.01.02", 0, 1130]] and o["cm2"][2] == ["2.1.01.01.02", 0, 11300]
    # lo rectificado sí lleva su ajuste (los otros tres de octubre siguen solo con el aviso)
    r = o["rectificado"]
    assert (r["creados"], r["actualizados"], r["eliminados"], r["bloqueados"], r["huerfanos"]) == (3, 0, 0, 3, []) and o["intactos2"] is True
    assert o["origenes2"] == sorted(base + ["aj:cm:3", "aj:rec:4", "aj:rec:5"])
    assert o["aj4"] == [[c, h, d] for c, d, h in o["cerrado4"]] and o["ajCm3"] == [[c, h, d] for c, d, h in o["cerradoCm3"]]     # eliminados: el reverso exacto de lo cerrado
    assert o["aj5cuadra"] is True and ["5.1.01.01", 1000, 0] in o["aj5"] and ["6.2.02.20", 0, 1000] in o["aj5"]
    assert "    if (f && !ultima && !cadena.length) continue;\n" in _js("pages", "contabilidad", "automaticos.js")


# ------------------------------------------------------------------------------------------------ H8 · el periodo contable en Rectificaciones
def test_h8_rectificaciones_muestra_el_estado_de_hoy_del_periodo(tmp_path):
    """La columna «Periodo contable» dice cómo está HOY el periodo de ese mes (pudo cerrarse o reabrirse después de anotar la
    rectificación); solo si este rol no puede leer los periodos se queda con el estado que tenía al anotarla."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = tmp_path / "js"
    for partes in (("pages", "gastos", "rectificaciones.js"), ("pages", "gastos", "_registro.js")):          # la pantalla y sus reglas, tal como están
        (raiz / pathlib.Path(*partes)).parent.mkdir(parents=True, exist_ok=True)
        (raiz / pathlib.Path(*partes)).write_text(_js(*partes), encoding="utf-8")
    (raiz / "pages" / "reportes").mkdir(parents=True)
    (raiz / "pages" / "reportes" / "_montos.js").write_text("export const descargarTabla = () => {};\n", encoding="utf-8")
    (raiz / "api.js").write_text("export const S = { datos: {} };\nexport const mock = { get(k, d) { return k in S.datos ? JSON.parse(JSON.stringify(S.datos[k])) : d; } };\n"
                                 "export const money = n => String(n), fecha = v => String(v || ''), fechaHora = v => String(v || ''), hoy = () => '2026-11-10', toast = () => {};\n", encoding="utf-8")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(r"""
import { S } from './js/api.js';
import pantalla from './js/pages/gastos/rectificaciones.js';
const x = (id, mes, periodo_cerrado) => ({ id, fecha: '2026-11-0' + id + 'T09:00:00-06:00', accion: 'eliminado', tipo: 'gasto', documento: 'C' + id, mes, total: 100, iva_acreditar: 13, periodo_cerrado });
const filtradas = [x(1, '2026-10', false), x(2, '2026-10', true), x(3, '2026-09', false), x(4, '2026-09', true), x(5, '2025-12', true), x(6, '2025-12', false)];
const ver = () => Object.fromEntries(pantalla.computed.rows.call({ filtradas }).map(r => [r.id, r.periodo === 'Abierto' ? 'A' : r.periodo === 'Cerrado: el reverso queda en el mes en curso' ? 'C' : r.periodo]));
const o = { sinLeer: ver() };
S.datos.periodos_2026 = [{ n: 9, mes: 'Setiembre', estado: 'Abierto' }, { n: 10, mes: 'Octubre', estado: 'Cerrado' }];
o.octubreCerrado = ver();
S.datos.periodos_2026 = [{ n: 9, mes: 'Setiembre', estado: 'Cerrado' }, { n: 10, mes: 'Octubre', estado: 'Abierto' }];
o.setiembreCerrado = ver();
console.log(JSON.stringify(o));
""", encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    # sin poder leer los periodos: el estado que tenía cada una al anotarla
    assert o["sinLeer"] == {"1": "A", "2": "C", "3": "A", "4": "C", "5": "C", "6": "A"}
    # octubre se cerró DESPUÉS de anotar la 1 (antes seguía diciendo «Abierto»); setiembre se reabrió después de anotar la 4; 2025 no se puede leer
    assert o["octubreCerrado"] == {"1": "C", "2": "C", "3": "A", "4": "A", "5": "C", "6": "A"}
    assert o["setiembreCerrado"] == {"1": "A", "2": "A", "3": "C", "4": "C", "5": "C", "6": "A"}
