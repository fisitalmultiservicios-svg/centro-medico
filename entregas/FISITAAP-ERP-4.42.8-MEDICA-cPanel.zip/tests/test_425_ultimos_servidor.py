# -*- coding: utf-8 -*-
"""4.25 (tanda 9c, lado servidor): los últimos arreglos que salieron de las pruebas de punta a punta 2 y 3 y de la revisión de la 9b
(P1 a P10). Cada prueba falla sin su arreglo.

Nube y computadora corren en el MISMO proceso y comparten la tabla de usuarios y la de empresas (ayudas de tests/test_49_local_sinc.py,
tests/test_425_conexion_programa.py y tests/test_425_punta_a_punta.py). Nada va a una impresora real ni a la red."""
import logging
import secrets

import httpx
import pytest
from sqlmodel import Session, select

from app import agente_local, auth, escpos, sinc
from app.db import Auditoria, Documento, Empresa, Producto, engine, engine_empresa
from test_49_local_sinc import NUBE, PW, H, _admin_empresa, _cfg, _poner_cfg, _Respuesta, _vincular, c
from test_425_conexion_nube import _aprobar, _limpiar_limitador
from test_425_conexion_programa import (_BASE, _confirmar, _estado, _iniciar, _limpieza, _llamadas, _membresias,  # noqa: F401
                                        _programa, _soltar_programa)
from test_425_ingreso_programa import _persona, _sobre, _solo_estas

RECOGER, CANCELAR, INGRESO = "/api/sinc/conexion/recoger", "/api/sinc/conexion/cancelar", "/api/sinc/ingreso"
CABYS = "8311000000000"


def _iniciar_otra(cab, nombre: str = "Caja 2"):
    return c.post("/api/sinc/local/conexion/iniciar", headers=cab, json={"nombre": nombre, "otra_empresa": True})


def _otra_simulada(cedula, aprobo: str, nombre: str) -> tuple:
    """Lo que contesta la web a «recoger» para una empresa que NO está en la tabla compartida de empresas (así lo que la computadora busca
    con esa cédula corre de verdad): la confirmación («aprobada») y la entrega («conectada»)."""
    emp, ap = {"nombre": nombre, "nombre_comercial": nombre, "numero_id": cedula}, {"correo": aprobo, "nombre": "Dueña"}
    aprobada = _Respuesta(200, sinc._sobre_conexion("aprobada", intervalo=3, segundos=600, empresa=emp, aprobo=ap))
    conectada = _Respuesta(200, sinc._sobre_conexion("conectada", token="fcr_" + secrets.token_urlsafe(32), terminal=7, nombre="Caja 2", revinculada=False,
                                                     empresa=emp, credenciales={}, roles=[], aprobo=ap,
                                                     usuarios=[{"correo": aprobo, "nombre": "Dueña", "rol": "Administrador"}]))
    return aprobada, conectada


def _empresas_nuevas() -> list:
    with Session(engine) as sc:
        return [e.id for e in sc.exec(select(Empresa).where(Empresa.id > _BASE[0]).order_by(Empresa.id)).all()]


def _fallos(correo: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login_fallo", "login_cuenta", "login_fallo_prog")),
                                                    auth.IntentoIp.ip.endswith(correo))).all()


# ================================================================================================================ P1
ETQ_RED = {"id": 5, "nombre": "Etiquetas Empresa", "uso": "etiquetas", "conexion": "red", "direccion": "192.168.1.60", "modelo": "3nstar-ldt124",
           "lenguaje": "tspl", "dpi": 203, "etq_ancho_mm": 50, "etq_alto_mm": 30, "activa": True}
TIQ_RED = {"id": 1, "nombre": "Tiquetes Empresa", "uso": "comprobante", "conexion": "red", "direccion": "192.168.1.50", "ancho": 80, "activa": True}


def _propia(uso: str, direccion: str, i: str = "eq-a") -> dict:
    p = {"id": i, "nombre": "Propia " + uso, "uso": uso, "conexion": "red", "direccion": direccion, "ancho": 80, "activa": True}
    if uso == "etiquetas":
        p.update({"modelo": "3nstar-ldt124", "lenguaje": "tspl", "dpi": 203, "etq_ancho_mm": 50, "etq_alto_mm": 30})
    return p


def test_p1_etiquetas_por_red_solo_con_la_ip_y_el_rechazo_en_texto_llano(monkeypatch, caplog):
    v = agente_local.validar_equipo
    # la de etiquetas (propia o ajuste de una de la empresa) no admite un puerto distinto del 9100
    for datos in ({"propias": [_propia("etiquetas", "192.168.1.60:9101")]}, {"ajustes": {"5": {"conexion": "red", "direccion": "192.168.1.61:8080"}}}):
        with pytest.raises(ValueError) as ex:
            v(datos, [ETQ_RED, TIQ_RED])
        assert str(ex.value) == "La impresora de etiquetas por red se escribe solo con su dirección IP (sin «:puerto»).", ex.value
    for direccion in ("192.168.1.60", "192.168.1.60:9100"):                # solo la IP (o el 9100, que es el mismo)
        assert v({"propias": [_propia("etiquetas", direccion)]}, [ETQ_RED])["propias"][0]["direccion"] == direccion
    assert v({"ajustes": {"5": {"conexion": "red", "direccion": "192.168.1.61"}}}, [ETQ_RED])["ajustes"]["5"]["direccion"] == "192.168.1.61"
    # las de tiquetes siguen aceptando su puerto
    assert v({"propias": [_propia("comprobante", "192.168.1.50:9101")]}, [TIQ_RED])["propias"][0]["direccion"] == "192.168.1.50:9101"
    assert v({"ajustes": {"1": {"conexion": "red", "direccion": "192.168.1.51:9102"}}}, [TIQ_RED])["ajustes"]["1"]["direccion"] == "192.168.1.51:9102"
    # el servicio rechaza un trabajo de etiquetas por el destino: a la pantalla, el texto llano; al registro, el rechazo (sin datos)
    monkeypatch.setattr(agente_local, "MODO_LOCAL", True)
    monkeypatch.setitem(agente_local._estado, "ultimo_error", "")
    enviados = []
    monkeypatch.setattr(escpos, "enviar", lambda impresora, datos: enviados.append(impresora))
    trabajo = {"conexion": "red", "direccion": "192.168.1.60:9101", "lenguaje": "tspl", "ancho_mm": 50, "alto_mm": 30, "separacion_mm": 2,
               "densidad": 8, "etiquetas": [{"nombre": "Café molido P1-9c", "codigo": "2000000000015", "copias": 1}]}
    caplog.set_level(logging.WARNING, logger="app.agente_local")
    for direccion in ("192.168.1.60:9101", "127.0.0.1", "8.8.8.8"):
        with pytest.raises(agente_local.HTTPException) as ex:
            agente_local.imprimir("imprimir", {"impresora": {"nombre": "Etiquetas"}, "etiquetas": {**trabajo, "direccion": direccion}}, None)
        assert ex.value.status_code == 400 and ex.value.detail == ("La impresora de etiquetas por red tiene que estar en la red del local: escriba su "
                                                                   "dirección IP, sin «:puerto»."), ex.value.detail
    assert enviados == []
    rechazos = [r for r in caplog.records if r.name == "app.agente_local" and "rechazada" in r.getMessage()]
    assert len(rechazos) == 3 and rechazos[0].levelno == logging.WARNING
    assert not any(x in caplog.text for x in ("192.168.1.60", "8.8.8.8", "Café molido"))      # nada del trabajo ni del destino
    # el texto técnico de siempre se conserva donde lo miran las pruebas viejas (escpos)
    with pytest.raises(ValueError, match="impresora USB o a una impresora de la red local"):
        escpos.ejecutar("imprimir", {}, {"etiquetas": trabajo})
    # un trabajo de etiquetas bien dirigido sigue saliendo, y un tiquete a otro puerto también
    assert agente_local.imprimir("imprimir", {"impresora": {"nombre": "Etiquetas"}, "etiquetas": {**trabajo, "direccion": "192.168.1.60"}}, None) == {"ok": True}
    assert agente_local.imprimir("imprimir", {"impresora": {"nombre": "Caja", "conexion": "red", "direccion": "192.168.1.50:9101"},
                                              "documento": {"bloques": [{"t": "texto", "x": "hola"}]}}, None) == {"ok": True}
    assert [i["direccion"] for i in enviados] == ["192.168.1.60", "192.168.1.50:9101"]


def test_p1_por_la_ruta_de_guardar_la_impresion_de_esta_computadora(monkeypatch):
    eid, tok = _admin_empresa("-p9c1", "3101425961")
    monkeypatch.setattr(agente_local, "MODO_LOCAL", True)
    try:
        r = c.put("/api/agente/equipo", headers=H(tok), json={"equipo": {"propias": [_propia("etiquetas", "192.168.1.60:9101")]}})
        assert r.status_code == 400 and r.json()["detail"] == agente_local.MENSAJE_ETQ_PUERTO, r.text
        r = c.put("/api/agente/equipo", headers=H(tok), json={"equipo": {"propias": [_propia("etiquetas", "192.168.1.60"),
                                                                                     _propia("comprobante", "192.168.1.50:9101", "eq-b")]}})
        assert r.status_code == 200, r.text
    finally:
        _poner_cfg(eid, vinculado=False)


# ================================================================================================================ P2 y P3
def _pareja_items(monkeypatch, sufijo: str, a: str, b: str):
    from test_425_items_web_desde_programa import _MIAS, _modo_local_red
    eid_a, ta = _admin_empresa(sufijo + "n", a)
    eid_b, tb = _admin_empresa(sufijo + "l", b)
    _MIAS.extend([eid_a, eid_b])
    shim = _modo_local_red(monkeypatch)
    _vincular(monkeypatch, ta, tb, "Caja 9c")
    return eid_a, ta, eid_b, tb, shim


def _item_web(ta: str, nombre: str) -> int:
    r = c.post("/api/productos", headers=H(ta), json={"nombre": nombre, "cabys": CABYS, "precio": 1000, "unidad_medida": "Sp", "es_servicio": True,
                                                      "inventariable": False, "codigo_tarifa": "08", "tarifa": 13, "categoria": "Web 9c"})
    assert r.status_code == 200, r.text
    return r.json()["id"]


def _p(eid: int, pid: int):
    with Session(engine_empresa(eid)) as s:
        return s.get(Producto, pid)


def _auditorias_item(eid: int) -> list:
    with Session(engine) as sc:
        return sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid, Auditoria.accion == "producto_editado_programa").order_by(Auditoria.id)).all()


def test_p2_la_auditoria_de_la_web_nombra_solo_lo_que_cambio(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja_items(monkeypatch, "-p9c2", "3101425962", "3101425963")
    pid = _item_web(ta, "Servicio web P2-9c")
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    # la ficha completa, como la manda la pantalla al guardar, con solo el nombre y el precio cambiados
    ficha = {k: v for k, v in _p(eid_b, pid).model_dump().items() if k not in ("id", "empresa_id", "imagen_nombre")}
    ficha.update({"cantidad_inicial": 0, "bodega_id": None, "nombre": "Servicio web P2-9c editado", "precio": 2500})
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json=ficha)
    assert r.status_code == 200 and r.json()["precio"] == 2500, r.text
    filas = _auditorias_item(eid_a)
    assert len(filas) == 1, [f.detalle for f in filas]
    assert filas[0].detalle.split("cambiado desde el programa: ", 1)[1] == "nombre, precio", filas[0].detalle
    # guardar otra vez la misma ficha (nada cambia): no audita
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json=ficha)
    assert r.status_code == 200, r.text
    assert len(_auditorias_item(eid_a)) == 1
    # un cambio corto sigue diciendo solo ese campo
    assert c.put(f"/api/productos/{pid}", headers=H(tb), json={"categoria": "Web 9c dos"}).status_code == 200
    filas = _auditorias_item(eid_a)
    assert len(filas) == 2 and filas[-1].detalle.endswith("cambiado desde el programa: categoria"), filas[-1].detalle


def test_p3_sin_internet_el_plazo_de_conexion_es_corto(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja_items(monkeypatch, "-p9c3", "3101425964", "3101425965")
    pid = _item_web(ta, "Servicio web P3-9c")
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    plazos, real = [], shim.post

    def anotar(url, headers=None, json=None, timeout=None):  # noqa: A002
        if url.endswith(sinc.RUTA_PRODUCTO):
            plazos.append(timeout)
        return real(url, headers=headers, json=json, timeout=timeout)
    shim.post = anotar
    assert c.put(f"/api/productos/{pid}", headers=H(tb), json={"precio": 1100}).status_code == 200
    _poner_cfg(eid_b, sin_conexion_desde="2026-11-11T10:00:00+00:00")       # la sincronización ya sabe que no hay internet
    shim.por_ruta[sinc.RUTA_PRODUCTO] = httpx.ConnectError("sin red")
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"precio": 1200})
    assert r.status_code == 503 and r.json()["detail"] == sinc.MENSAJE_ITEM_WEB
    assert [(t.connect, t.read) for t in plazos] == [(4.0, sinc.PLAZO_PRODUCTO), (2.0, sinc.PLAZO_PRODUCTO)]
    shim.por_ruta.pop(sinc.RUTA_PRODUCTO)
    _poner_cfg(eid_b, sin_conexion_desde=None)


# ================================================================================================================ P4
def test_p4_revocada_por_una_persona_el_error_guardado_es_propio_y_completo(monkeypatch):
    eid_a, ta = _admin_empresa("-p9c4n", "3101425966")
    eid_l, tl = _admin_empresa("-p9c4l", "3101425967")
    _programa(monkeypatch, sin_estrenar=False)
    terminal = _vincular(monkeypatch, ta, tl, "Caja")["terminal"]
    assert not sinc.sincronizar(eid_l)["ultimo_error"]
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta)).status_code == 200
    est = sinc.sincronizar(eid_l)
    assert est["revocada_en"], est
    err = _cfg(eid_l)["ultimo_error"]
    fecha, texto = err[:19], err[20:]
    assert len(fecha) == 19 and fecha[4] == "-" and fecha[10] == "T"                            # el comienzo de siempre: la fecha…
    assert texto == ("Esta instalación fue revocada en la nube. Para seguir, un administrador la conecta de nuevo en Configuración › Instalación "
                     "local («Conectar con mi cuenta»)."), err                               # …y el texto propio, completo
    assert "código" not in err and "(" + "Esta instalación" not in err


# ================================================================================================================ P5
def test_p5_numero_errado_en_la_retencion_no_dice_aprobada(monkeypatch):
    eid_n, ta = _admin_empresa("-p9c5", "3101425968")
    _programa(monkeypatch, retencion=300)
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert _estado(j["intento"]).json()["estado"] == "retenida"
    otro = "100" if a["numero"] != "100" else "101"
    v = _confirmar(j["intento"], otro).json()
    assert v["estado"] == "retenida" and v["error"] == sinc.MENSAJES_LOCAL["numero_errado"], v
    assert v["mensaje"] == "La conexión sigue en espera por seguridad: corrija el número de comprobación y escríbalo de nuevo.", v
    assert "Aprobada" not in v["mensaje"]
    assert _estado(j["intento"]).json()["mensaje"] == v["mensaje"]            # el sondeo dice lo mismo mientras no lo corrija
    v = _confirmar(j["intento"], a["numero"]).json()                           # el bueno: vuelve el texto de la espera
    assert v["estado"] == "retenida" and not v.get("error") and v["mensaje"] == sinc.MENSAJES_LOCAL["retenida"], v


# ================================================================================================================ P6
def test_p6_otra_empresa_sin_cedula_termina_cancelada_y_no_crea_nada(monkeypatch):
    eid_a, ta = _admin_empresa("-p9c6n", "3101425969")
    eid_l, tl = _admin_empresa("-p9c6l", "3101425969")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    texto = "Esa empresa no tiene cédula registrada en la página web: complete sus datos allá e inténtelo de nuevo."
    antes = _empresas_nuevas()
    # (a) la aprobación trae la empresa sin cédula (vacía, nula o sin dígitos): cancelado, con aviso a la web
    for ced in ("", None, "--- "):
        _soltar_programa(); _limpiar_limitador()
        j = _iniciar_otra(H(tl)).json()
        aprobada, _ = _otra_simulada(ced, "duena-sinc49-p9c6l@example.test", "Sin Cédula QA-p9c6")
        shim.por_ruta[RECOGER] = aprobada
        n = len(_llamadas(shim, CANCELAR))
        v = _estado(j["intento"], H(tl)).json()
        assert v["estado"] == "cancelada" and v["mensaje"] == texto, (ced, v)
        assert len(_llamadas(shim, CANCELAR)) == n + 1
        assert _empresas_nuevas() == antes
    # (b) aprobada con cédula, pero la entrega llega sin ella: tampoco se aplica nada
    _soltar_programa(); _limpiar_limitador()
    j = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = _otra_simulada("3-101-425970", "duena-sinc49-p9c6l@example.test", "Con Cédula QA-p9c6")[0]
    assert _estado(j["intento"], H(tl)).json()["estado"] == "confirmar"
    shim.por_ruta[RECOGER] = _otra_simulada("", "duena-sinc49-p9c6l@example.test", "Con Cédula QA-p9c6")[1]
    v = _confirmar(j["intento"], "123", cab=H(tl)).json()
    assert v["estado"] == "cancelada" and v["mensaje"] == texto, v
    assert _empresas_nuevas() == antes
    # la empresa abierta no cambió
    assert _cfg(eid_l)["vinculado"] and _cfg(eid_l)["terminal"]


# ================================================================================================================ P7
def test_p7_sin_conectar_no_es_lo_mismo_que_sin_internet(monkeypatch):
    eid_a, ta = _admin_empresa("-p9c7n", "3101425971")
    eid_l, tl = _admin_empresa("-p9c7l", "3101425972")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    _poner_cfg(eid_l, version_nube="4.25")
    correo = "cajera-p9c7@example.test"
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre="C", password_hash=sinc.HASH_INSERVIBLE, de_nube=True, terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_l, rol="Cajero")); sc.commit()
    sin_conectar = ("Esta computadora no está conectada a la página web y aquí no quedó guardado su ingreso. Un administrador tiene que "
                    "conectarla de nuevo en Configuración › Instalación local.")

    def entrar(pw=PW):
        return c.post("/api/auth/login", json={"correo": correo, "password": pw})
    with monkeypatch.context() as m:
        _solo_estas(m, eid_l)
        # la web no contestó: el texto de siempre
        for falla in (httpx.ConnectError("sin red"), _Respuesta(502, None, "<html>Bad gateway</html>")):
            shim.por_ruta[INGRESO] = falla
            r = entrar()
            assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_VALIDAR_AQUI, r.text
        # la web no reconoció esta computadora, o es una web anterior: no está conectada
        for resp in (_Respuesta(200, _sobre("sin_acceso")), _Respuesta(404, {"detail": "Not Found"})):
            if resp.status_code == 404:
                _poner_cfg(eid_l, version_nube=None)
            shim.por_ruta[INGRESO] = resp
            r = entrar()
            assert r.status_code == 403 and r.json()["detail"] == sin_conectar, r.text
        shim.por_ruta.pop(INGRESO, None)
        _poner_cfg(eid_l, version_nube="4.25")
        # otra dirección
        with monkeypatch.context() as m2:
            m2.setattr(sinc, "URL_NUBE", "https://fisitaap.com")
            r = entrar()
            assert r.status_code == 403 and r.json()["detail"] == sin_conectar, r.text
    # sin vinculación (ninguna empresa conectada, o la instalación revocada: _vinculadas no la cuenta)
    with monkeypatch.context() as m:
        _solo_estas(m)
        r = entrar()
        assert r.status_code == 403 and r.json()["detail"] == sin_conectar, r.text
    _poner_cfg(eid_l, revocada_en="2026-11-11T08:00:00+00:00")
    try:
        r = entrar()
        assert r.status_code == 403 and r.json()["detail"] == sin_conectar, r.text
    finally:
        _poner_cfg(eid_l, revocada_en=None)
    assert not _fallos(correo)                                                  # nunca cuenta fallo
    # con su contraseña real guardada, pero sin haber entrado en línea aquí (D-I): la web no reconoció esta computadora → no está conectada
    uid_r, correo_r = _persona(eid_a, "cajera-p9c7r", local=eid_l)
    with monkeypatch.context() as m:
        _solo_estas(m, eid_l)
        shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("sin_acceso"))
        r = c.post("/api/auth/login", json={"correo": correo_r, "password": PW})
        assert r.status_code == 403 and r.json()["detail"] == sin_conectar, r.text
        shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
        r = c.post("/api/auth/login", json={"correo": correo_r, "password": PW})
        assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_VALIDAR_AQUI, r.text
    assert not _fallos(correo_r)
    shim.por_ruta.pop(INGRESO, None)


# ================================================================================================================ P8
def test_p8_empresa_con_cedula_y_ya_esta_de_verdad():
    """Funciones reales con empresas locales controladas (cédulas que solo usa esta prueba)."""
    def nueva(ced: str) -> int:
        with Session(engine) as sc:
            return auth.crear_empresa(sc, "Local9c QA " + ced, "", ced).id
    # con guiones y espacios en la computadora y en lo que manda la web: se compara por dígitos
    con_datos = nueva(" 3-101 425973 ")
    with Session(engine) as sc:
        u = auth.Usuario(correo="entra-p9c8@example.test", nombre="QA", password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=con_datos, rol="Cajero")); sc.commit()
        assert sinc._empresa_con_cedula(sc, "3101425973") == con_datos
    for escrita in ("3-101-425973", " 3 101 425973", "3101425973"):
        assert sinc._ya_esta({"empresa": {"numero_id": escrita}}) is True, escrita
    # una empresa vacía y sin vincular (la que deja un intento que no terminó): no cuenta y se vuelve a usar
    vacia = nueva("3 101-425974")
    with Session(engine) as sc:
        assert sinc._empresa_con_cedula(sc, "3101425974") is None and sinc._huerfanas(sc, "3101425974") == [vacia]
    assert sinc._ya_esta({"empresa": {"numero_id": "3-101-425974"}}) is False
    # la misma cédula con comprobantes: ya está
    with Session(engine_empresa(vacia)) as s:
        s.add(Documento(empresa_id=vacia, tipo_documento="04", clave=f"506{8:047d}", consecutivo=f"00100002040{8:09d}",
                        fecha_emision="2026-11-11T08:00:00-06:00", estado="firmado", ambiente="sandbox", moneda="CRC", tipo_cambio=1, total=1000))
        s.commit()
    with Session(engine) as sc:
        assert sinc._empresa_con_cedula(sc, "3101425974") == vacia
    assert sinc._ya_esta({"empresa": {"numero_id": "3-101-425974"}}) is True
    # sin cédula no hay empresa que buscar
    with Session(engine) as sc:
        assert sinc._empresa_con_cedula(sc, "") is None
    assert sinc._ya_esta({"empresa": {"numero_id": ""}}) is False and sinc._cedula_de({"empresa": {"numero_id": " - "}}) == ""


def test_p8_conectar_otra_empresa_de_punta_a_punta_sin_sustituir_funciones(monkeypatch):
    eid_a, ta = _admin_empresa("-p9c8n", "3101425975")
    eid_l, tl = _admin_empresa("-p9c8l", "3101425975")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    aprobo = "duena-sinc49-p9c8l@example.test"
    with Session(engine) as sc:                                                 # la que dejó un intento que no terminó, con espacios
        vacia = auth.crear_empresa(sc, "Otra QA-p9c8", "", "3 101 425976").id
    aprobada, conectada = _otra_simulada("3-101-425976", aprobo, "Otra QA-p9c8")
    j = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = aprobada
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "confirmar" and v["con_sesion"] is True, v
    shim.por_ruta[RECOGER] = conectada
    v = _confirmar(j["intento"], "123", cab=H(tl)).json()
    assert v["estado"] == "lista" and v["otra_empresa"] is True and v["empresa_id"] == vacia, v
    assert v["mensaje"] == "Listo. La empresa Otra QA-p9c8 quedó en esta computadora. Para trabajar con ella, elíjala en el menú de su empresa, arriba."
    assert _cfg(vacia)["vinculado"] and [m.rol for m in _membresias(vacia)] == ["Administrador"]
    # ya está (vinculada y con gente): otro intento para ella termina en «ya está», sin crear nada
    _soltar_programa(); _limpiar_limitador()
    antes = _empresas_nuevas()
    j = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = _otra_simulada(" 3101425976", aprobo, "Otra QA-p9c8")[0]
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "ya_esta", v
    assert _empresas_nuevas() == antes
    # «no un token»: un token de API que SÍ tiene «configurar» tampoco puede empezarla
    with Session(engine) as sc:
        tok = "fcr_" + secrets.token_urlsafe(32)
        uid_admin = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == aprobo)).first().id
        sc.add(auth.TokenApi(empresa_id=eid_l, usuario_id=uid_admin, nombre="QA p9c8", prefijo=tok[:12], hash=auth._hash_token_api(tok),
                             permisos='["ver", "catalogos", "configurar"]'))
        sc.commit()
    r = _iniciar_otra(H(tok))
    assert r.status_code == 403 and r.json()["detail"] == "La conexión la empieza una persona con sesión, no un token", r.text


# ================================================================================================================ P9 y P10
def test_p9_p10_textos_finales_y_con_sesion(monkeypatch):
    assert sinc.MENSAJES_LOCAL["lista_otra"] == ("Listo. La empresa {empresa} quedó en esta computadora. Para trabajar con ella, elíjala en el menú de "
                                                 "su empresa, arriba.")
    eid_n, ta = _admin_empresa("-p9c10n", "3101425977")
    eid_l, tl = _admin_empresa("-p9c10l", "3101425977")
    _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    # reconexión de la misma empresa empezada con sesión: no le pide «entrar» a quien ya la tiene
    j = _iniciar("Caja", H(tl)).json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    v = _estado(j["intento"], H(tl)).json()
    assert v["con_sesion"] is True, v
    v = _confirmar(j["intento"], a["numero"], cab=H(tl)).json()
    assert v["estado"] == "lista" and v["reconexion"] is True and v["con_sesion"] is True, v
    assert v["mensaje"] == ("Listo. Esta computadora quedó conectada de nuevo a Sinc49 QA-p9c10n. Cada persona tiene que entrar una vez con su "
                            "contraseña, con internet, para usar su PIN de nuevo y poder entrar sin internet aquí."), v
    assert "Ahora entre" not in v["mensaje"]
    # sin sesión (computadora sin estrenar): no trae con_sesion y el texto final es el de siempre
    _soltar_programa(); _limpiar_limitador()
    eid_m, tm = _admin_empresa("-p9c10m", "3101425978")
    _programa(monkeypatch, sin_estrenar=True)
    j = _iniciar().json()
    a = _aprobar(tm, j["codigo"], eid_m).json()
    v = _estado(j["intento"]).json()
    assert "con_sesion" not in v, v
    v = _confirmar(j["intento"], a["numero"]).json()
    assert v["estado"] == "lista" and "con_sesion" not in v and v["mensaje"].startswith("Listo. Esta computadora quedó conectada a Sinc49 QA-p9c10m. Ahora entre"), v
