"""4.31: la misma mesa abierta en dos equipos sin perder platos — parte del servidor (diseño «la misma mesa», 4.1 a 4.6 y 4.10).
- P-1 (Python): app/fusion_cuentas.py da exactamente `esperado` en los casos compartidos con la pantalla (test_431_fusion_casos.json),
  y aplicar dos veces la misma fusión da lo mismo.
- P-7: la ruta POST /api/registros/pos_espera/cambios une, conserva y recrea; nunca guarda `_fusion`; sin `_fusion` ni `condiciones`
  responde lo mismo que la 4.29.
- P-8: las demás claves (y quien llama a aplicar_cambios sin los parámetros nuevos) siguen como antes.
- L-9: entregas.py marca «entregado» sin pisar un plato que la caja guardó en ese instante.
Todo con cuentas @example.test y bases temporales."""
import json
import pathlib
import threading

import pytest
from sqlmodel import Session, SQLModel, create_engine

from app import fusion_cuentas as fc, modulos
from app.db import engine_empresa
from app.main import CambiosIn
from tests.test_387_r4_caja import Entorno

AQUI = pathlib.Path(__file__).resolve().parent
RAIZ = AQUI.parent / "app"
CASOS = json.loads((AQUI / "test_431_fusion_casos.json").read_text(encoding="utf-8"))["casos"]
CLAVES_429 = {"ok", "clave", "version", "remap", "ultimo_id"}
E1, E2, E3 = "2026-11-12T12:00:00.000Z", "2026-11-12T12:01:00.000Z", "2026-11-12T12:02:00.000Z"


def _j(x):
    return json.loads(json.dumps(x))


def _correr(c):
    if c["funcion"] == "unir":
        res, fusiono = fc.unir(_j(c["guardada"]), _j(c["nueva"]))
        return _j(res), fusiono
    if c["funcion"] == "cerrar":
        return _j(fc.cerrar(_j(c["guardada"]), _j(c["condicion"]))), None
    if c["funcion"] == "recrear":
        return _j(fc.recrear(_j(c["nueva"]), c["id_viejo"], c["id_nuevo"])), None
    if c["funcion"] == "poner_lids":
        return _j(fc.poner_lids(_j(c["cuenta"]))), None
    raise AssertionError(c["funcion"])


# ----------------------------------------------------------------------------- P-1
@pytest.mark.parametrize("caso", CASOS, ids=[c["nombre"] for c in CASOS])
def test_p1_casos_compartidos(caso):
    res, fusiono = _correr(caso)
    assert res == caso["esperado"], caso["que_prueba"]
    if caso["funcion"] == "unir":
        assert fusiono is caso["fusiono"], caso["que_prueba"]
        assert "_fusion" not in (res or {})
        if caso.get("repetible", True):                          # aplicar dos veces la misma fusión da lo mismo (reenvío)
            assert _j(fc.unir(_j(res), _j(caso["nueva"]))[0]) == res, caso["nombre"]
    if caso["funcion"] == "cerrar" and res is not None:          # cerrar dos veces da lo mismo
        assert _j(fc.cerrar(_j(res), _j(caso["condicion"]))) == res


def _caso(nombre):
    return next(c for c in CASOS if c["nombre"] == nombre)


def test_p1_los_casos_dicen_lo_que_pide_el_diseno():
    """Lo esencial de cada caso, escrito a mano (el JSON no es el único juez)."""
    assert len(CASOS) >= 40 and len({c["nombre"] for c in CASOS}) == len(CASOS)
    det = lambda c: [l["detalle"] for l in c["esperado"]["lineas"]]   # noqa: E731
    hoy = _caso("hoy_a_atrasado")
    assert det(hoy) == ["Casado", "Limonada", "Postre"] and hoy["fusiono"] is True and hoy["esperado"]["total"] == 7995
    assert det(_caso("hoy_a_al_dia")) == ["Casado", "Limonada", "Postre"] and _caso("hoy_a_al_dia")["fusiono"] is False
    assert det(_caso("quitado_por_otro_no_vuelve")) == ["Casado"] and _caso("quitado_por_otro_no_vuelve")["esperado"]["lineas"][0]["nota"] == "sin sal"
    assert det(_caso("reenvio_con_lapida")) == ["Casado"]
    assert det(_caso("cobrado_por_otro_solo_esos")) == ["Casado", "Postre"] and _caso("cobrado_por_otro_solo_esos")["esperado"]["cobros"][0]["doc_id"] == 10
    r = _caso("quitada_con_resto")["esperado"]["lineas"][1]
    assert r["lid"] == "lB~1" and r["cantidad"] == 1
    p = _caso("partes_y_nota_de_cuenta")["esperado"]
    assert p["nota"] == "cliente frecuente" and p["lineas"][0]["cantidad"] == 1 and p["partes"]["cobradas"] == 1 and p["cobros"][0]["doc_id"] == 20
    assert _caso("promo_no_devuelve_cantidad")["esperado"]["lineas"][0]["cantidad"] == 3
    assert _caso("promo_no_devuelve_cantidad")["esperado"]["lineas"][0]["promo"] == "2x1"
    assert _caso("misma_cantidad_gana_el_ultimo")["esperado"]["lineas"][0]["cantidad"] == 2
    assert det(_caso("cocina_listo")) == ["Casado", "Limonada"] and _caso("cocina_listo")["esperado"]["lineas"][0]["listo"]
    assert _caso("cocina_deshace")["esperado"]["lineas"][0]["listo"] is None
    co = _caso("cocina_no_cambia_platos")["esperado"]["lineas"]
    assert len(co) == 1 and co[0]["cantidad"] == 1 and co[0]["nota"] == "" and co[0]["listo"]
    assert _caso("comanda_tardia")["esperado"]["lineas"][0]["comanda"] == 7 and det(_caso("comanda_tardia")) == ["Casado", "Limonada"]
    cpm = _caso("cobros_partes_mesa")["esperado"]
    assert [c.get("doc_id") or c.get("consecutivo") for c in cpm["cobros"]] == [1, 2, "X1", 3, "X2"]
    assert cpm["partes"]["cobradas"] == 2 and cpm["mesa_id"] == 9
    pl = _caso("pedido_en_linea_intacto")["esperado"]
    assert pl["prepago"] == 5000 and pl["cupon"] == "BIEN10"
    sf = _caso("sin_fusion_hoy")["esperado"]
    assert det(_caso("sin_fusion_hoy")) == ["Casado", "Postre"] and sf["recreada_de"] == 4 and sf["lids_quitados"] == ["lZ", "lL"]
    assert "lid" not in sf["lineas"][1]                          # sin _fusion: lo que llega, tal cual
    assert _caso("total_siete_lineas")["esperado"]["total"] == 28918.52
    assert _caso("total_punto_cinco")["esperado"]["total"] == 1.13
    assert _caso("total_sin_importe")["esperado"]["total"] == 1234.5
    assert _caso("cerrar_nada_mas")["esperado"] is None and _caso("cerrar_condicion_rara")["esperado"] is None
    assert [l["detalle"] for l in _caso("cerrar_limonada_de_otro")["esperado"]["lineas"]] == ["Limonada"]
    assert _caso("cerrar_cerveza_resto")["esperado"]["lineas"][0]["lid"] == "lB~1"
    rc = _caso("recrear_solo_nuevas")["esperado"]
    assert [l["detalle"] for l in rc["lineas"]] == ["Postre"] and rc["recreada_de"] == 6 and rc["id"] == 12
    assert not {"prepago", "cupon", "puntos_canjeados", "canal", "pedido_id"} & set(rc) and rc["cobros"] == [] and rc["partes"] is None
    assert _caso("recrear_cocina")["esperado"] is None and _caso("recrear_sin_nuevas")["esperado"] is None
    # 4.31 (corrección): el resto de una línea partida (marca «de»)
    lids = lambda c: [l["lid"] for l in c["esperado"]["lineas"]]   # noqa: E731
    assert lids(_caso("partida_por_dos_equipos")) == ["lRA"] and _caso("partida_por_dos_equipos")["fusiono"] is True   # no dos restos
    assert lids(_caso("partida_resto_propio")) == ["lRA"] and _caso("partida_resto_propio")["esperado"]["lineas"][0]["de"] == "lC"
    assert lids(_caso("partida_dos_veces_sin_confirmar")) == ["lR2"] and lids(_caso("de_de_otra_cuenta_si_va")) == ["lC", "lM"]
    # contenedores vacíos del tipo contrario: vacíos (como en la pantalla), no datos raros
    for n in ("fusion_campos_lista_vacio", "fusion_quitadas_lista_vacio", "fusion_nuevas_objeto_vacio", "fusion_cuenta_objeto_vacio"):
        assert lids(_caso(n)) == ["lC"] and _caso(n)["fusiono"] is True, n
    assert lids(_caso("cerrar_quitadas_lista_vacia")) == ["lC"]
    # baja por cobro y cuenta recreada: lo ya pagado del pedido en línea no se hereda
    pc = _caso("cerrar_por_cobro_sin_lo_pagado")["esperado"]
    assert lids(_caso("cerrar_por_cobro_sin_lo_pagado")) == ["lL"] and pc["prepago"] is None and pc["cupon"] is None and pc["puntos_canjeados"] == 0
    assert pc["pedido_id"] == 45 and _caso("cerrar_sin_cobro_conserva_lo_pagado")["esperado"]["prepago"]["monto"] == 5000
    assert not {"prepago", "cupon", "puntos_canjeados"} & set(_caso("cerrar_por_cobro_cuenta_sin_pedido")["esperado"])
    rr = _caso("recreada_no_hereda_el_pedido_cobrado")["esperado"]
    assert lids(_caso("recreada_no_hereda_el_pedido_cobrado")) == ["lP", "lF"] and not set(fc.CAMPOS_PEDIDO_COBRADO) & set(rr)


def test_p1_nunca_lanza_y_es_recreada_de():
    for g, n in [(None, None), ("x", {"id": 1}), ({"id": 1, "lineas": [1, 2]}, {"id": 1, "lineas": [{"cantidad": float("nan")}], "_fusion": {"v": 1, "origen": "caja"}}),
                 ({"id": 1}, {"id": 1, "_fusion": {"v": True, "origen": "caja"}}), ({"id": 1}, {"id": 1, "_fusion": {"v": 1, "origen": "caja", "quitadas": {"a": "1"}}})]:
        res, fusiono = fc.unir(g, n)
        assert fusiono is False and (not isinstance(res, dict) or "_fusion" not in res)
    assert fc.cerrar(None, {"v": 1}) is None and fc.cerrar({"id": 1, "lineas": "x"}, {"v": 1, "quitadas": {}}) is None
    assert fc.recrear(None, 1, 2) is None and fc.poner_lids("x") == "x"
    assert fc.es_recreada_de({"recreada_de": 6}, 6) and fc.es_recreada_de({"recreada_de": 6.0}, 6)
    assert not fc.es_recreada_de({"recreada_de": 7}, 6) and not fc.es_recreada_de({}, 6) and not fc.es_recreada_de("x", 6)
    assert not fc.es_recreada_de({"recreada_de": True}, 1)


# ----------------------------------------------------------------------------- helpers de cuentas
def _l(lid, pid, det, precio, enviado, cant=1):
    m = cant * precio
    return {"lid": lid, "producto_id": pid, "detalle": det, "cantidad": cant, "precio_unitario": precio, "tarifa": 13, "descuento_pct": 0, "descuento": 0,
            "nota": "", "enviado": enviado, "ronda": 1, "importe": round(m + m * 0.13 + m * 0.10, 5), "importe_de": [cant, precio, 0, 0]}


CASADO, LIMONADA, POSTRE = _l("lC", 1, "Casado", 3500, E1), _l("lL", 2, "Limonada", 1500, E2), _l("lP", 3, "Postre", 1500, E3)


def _cuenta(iid, lineas, fusion=None, **extra):
    x = {"id": iid, "nombre": "Mesa 6", "mesa_id": 6, "mesas_ids": [6], "terminal_id": 1, "salonero": "", "servicio": True, "servicio_pct": 10,
         "cliente_id": None, "nota": "", "lineas": lineas, "cobros": [], "partes": None, "total": fc.total_de(lineas) or 0, **extra}
    if fusion is not None:
        x["_fusion"] = {"v": 1, "equipo": "eQA", "origen": "caja", "nuevas": [], "quitadas": {}, "campos": {}, "cuenta": [], **fusion}
    return x


def _s(tmp_path=None):
    eng = create_engine(f"sqlite:///{(tmp_path / 'r.db').as_posix()}" if tmp_path else "sqlite://")
    SQLModel.metadata.create_all(eng, tables=[modulos.Registro.__table__, modulos.RegistroItem.__table__])
    return eng


# ----------------------------------------------------------------------------- P-8
def test_p8_registro_solo_pos_espera_y_otras_claves_como_antes():
    assert modulos.FUSIONES == {"pos_espera": fc}                 # main.py la registra; ninguna otra clave
    assert CambiosIn().condiciones == {} and CambiosIn(upserts=[], deletes=[], nuevos=[], otra=1).condiciones == {}
    with Session(_s()) as s:
        x = {"id": 1, "n": "A", "_fusion": {"v": 1, "origen": "caja", "nuevas": ["z"]}}
        modulos.aplicar_cambios(s, 1, "compras", [x], [], [1])
        modulos.aplicar_cambios(s, 1, "compras", [{**x, "n": "B"}], [], [])
        assert modulos.leer(s, 1, "compras") == [{**x, "n": "B"}]                    # se guarda tal cual (como hoy)
        inf = {}
        modulos.aplicar_cambios(s, 1, "compras", [], [1], [], condiciones={"1": {"v": 1, "quitadas": {}}}, informe=inf)
        assert modulos.leer(s, 1, "compras") == [] and inf == {"fusionados": [], "conservados": []}   # la baja sin condición
        v, remap = modulos.aplicar_cambios(s, 1, "compras", [{"id": 5, "n": "C"}], [], [5])  # la firma de siempre
        assert remap == {} and modulos.leer(s, 1, "compras") == [{"id": 5, "n": "C"}]


def test_p8_sin_fusion_en_pos_espera_es_lo_de_hoy():
    with Session(_s()) as s:
        modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO, LIMONADA], lids_quitados=["lZ"], recreada_de=3)], [], [6])
        inf = {}
        modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO, POSTRE])], [], [], informe=inf)   # pestaña 4.29 / pedidos.py
        g = modulos.leer(s, 1, "pos_espera")[0]
        assert [l["detalle"] for l in g["lineas"]] == ["Casado", "Postre"]          # gana el último, como hoy
        assert g["recreada_de"] == 3 and g["lids_quitados"] == ["lZ", "lL"] and inf["fusionados"] == []
        modulos.aplicar_cambios(s, 1, "pos_espera", [], [6], [])                     # baja sin condición: se borra como hoy
        assert modulos.leer(s, 1, "pos_espera") == []
        # un cambio sin _fusion a una cuenta ya borrada: gana el borrado, como hoy
        _, remap = modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO])], [], [])
        assert remap == {} and modulos.leer(s, 1, "pos_espera") == []


def test_alta_con_fusion_no_guarda_fusion_y_su_reintento_no_duplica():
    with Session(_s()) as s:
        alta = _cuenta(6, [CASADO], {"nuevas": ["lC"]})
        modulos.aplicar_cambios(s, 1, "pos_espera", [alta], [], [6])
        modulos.aplicar_cambios(s, 1, "pos_espera", [alta], [], [6])                 # reintento (respuesta perdida)
        datos = modulos.leer(s, 1, "pos_espera")
        assert len(datos) == 1 and "_fusion" not in datos[0]


def test_dos_procesos_a_la_vez_no_pierden_platos(tmp_path):
    """Dos hilos con sesiones propias sobre la misma base (como dos procesos): el bloqueo de aplicar_cambios los ordena y la fusión
    deja los dos platos."""
    eng = _s(tmp_path)
    with Session(eng) as s:
        modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO])], [], [6])
    barrera, errores = threading.Barrier(2), []

    def guardar(linea):
        try:
            with Session(eng) as s:
                barrera.wait(5)
                modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO, linea], {"nuevas": [linea["lid"]]})], [], [])
        except Exception as ex:  # noqa: BLE001
            errores.append(ex)
    hilos = [threading.Thread(target=guardar, args=(x,)) for x in (LIMONADA, POSTRE)]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join(30)
    assert not errores
    with Session(eng) as s:
        lineas = modulos.leer(s, 1, "pos_espera")[0]["lineas"]
    assert sorted(l["detalle"] for l in lineas) == ["Casado", "Limonada", "Postre"] and len(lineas) == 3
    eng.dispose()


def test_l9_entregas_no_pisa_un_plato_de_la_caja():
    """entregas._cerrar lee la cuenta fuera del bloqueo; si la caja agrega un plato en ese instante, la marca de «entregado» ya no lo pisa."""
    texto = (RAIZ / "entregas.py").read_text(encoding="utf-8")
    assert '"_fusion": {"v": 1, "origen": "servidor", "cuenta": ["estado", "hora_entregado"]}' in texto
    with Session(_s()) as s:
        modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO], estado="listo", canal="online", prepago=4305)], [], [6])
        c = modulos.leer(s, 1, "pos_espera")[0]                                      # lo que leyó entregas
        modulos.aplicar_cambios(s, 1, "pos_espera", [_cuenta(6, [CASADO, LIMONADA], {"nuevas": ["lL"]}, estado="listo")], [], [])   # la caja
        modulos.aplicar_cambios(s, 1, "pos_espera", [{**c, "estado": "entregado", "hora_entregado": "12:30",
                                                      "_fusion": {"v": 1, "origen": "servidor", "cuenta": ["estado", "hora_entregado"]}}], [], [])
        g = modulos.leer(s, 1, "pos_espera")[0]
        assert [l["detalle"] for l in g["lineas"]] == ["Casado", "Limonada"] and g["estado"] == "entregado" and g["hora_entregado"] == "12:30"
        assert g["prepago"] == 4305 and "_fusion" not in g
        # la cuenta ya cobrada: la marca del servidor no la revive
        modulos.aplicar_cambios(s, 1, "pos_espera", [], [6], [])
        _, remap = modulos.aplicar_cambios(s, 1, "pos_espera", [{**c, "_fusion": {"v": 1, "origen": "servidor", "cuenta": ["estado"]}}], [], [])
        assert remap == {} and modulos.leer(s, 1, "pos_espera") == []


# ----------------------------------------------------------------------------- P-7 (ruta real)
@pytest.fixture()
def rest():
    x = Entorno("restaurante")
    x.usuario("admin", "Administrador")
    try:
        yield x
    finally:
        x.limpiar()


def _post(x, upserts=(), deletes=(), nuevos=(), **extra):
    r = x.c.post("/api/registros/pos_espera/cambios", json={"upserts": list(upserts), "deletes": list(deletes), "nuevos": list(nuevos), **extra}, headers=x.h("admin"))
    assert r.status_code == 200, r.text
    return r.json()


def _espera(x):
    r = x.c.get("/api/registros/pos_espera", headers=x.h("admin"))
    assert r.status_code == 200, r.text
    assert "_fusion" not in r.text
    return r.json()


def test_p7_ruta_de_registros(rest):
    x = rest
    # alta de Casado y su reintento (respuesta perdida): no duplica; respuesta de siempre
    alta = _cuenta(1, [CASADO])
    r = _post(x, [alta], nuevos=[1])
    assert set(r) == CLAVES_429
    assert set(_post(x, [alta], nuevos=[1])) == CLAVES_429
    assert len(_espera(x)["datos"]) == 1
    # B guarda Casado+Limonada; A, con su copia de antes de la Limonada, guarda Casado+Postre
    r = _post(x, [_cuenta(1, [CASADO, LIMONADA], {"nuevas": ["lL"]})])
    assert set(r) == CLAVES_429                                  # nada que unir: la respuesta de siempre
    r = _post(x, [_cuenta(1, [CASADO, POSTRE], {"nuevas": ["lP"]})])
    assert r["fusionados"] == [1] and "conservados" not in r
    d = _espera(x)["datos"]
    assert len(d) == 1 and [l["detalle"] for l in d[0]["lineas"]] == ["Casado", "Limonada", "Postre"] and d[0]["total"] == 7995
    # sin _fusion: lo de hoy (gana lo último) y la respuesta de siempre
    r = _post(x, [_cuenta(1, [CASADO, POSTRE])])
    assert set(r) == CLAVES_429
    d = _espera(x)["datos"][0]
    assert [l["detalle"] for l in d["lineas"]] == ["Casado", "Postre"] and "lL" in d["lids_quitados"]
    # dos envíos a la vez (Limonada y Postre de dos equipos): quedan los dos
    l2, p2 = {**LIMONADA, "lid": "lL2"}, {**POSTRE, "lid": "lP2"}
    errores = []

    def enviar(linea):
        try:
            _post(x, [_cuenta(1, [CASADO, POSTRE, linea], {"nuevas": [linea["lid"]]})])
        except Exception as ex:  # noqa: BLE001
            errores.append(ex)
    hilos = [threading.Thread(target=enviar, args=(z,)) for z in (l2, p2)]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join(30)
    assert not errores
    lids = [l["lid"] for l in _espera(x)["datos"][0]["lineas"]]
    assert sorted(lids) == ["lC", "lL2", "lP", "lP2"]
    # baja con condición y un plato que agregó otro equipo: no se borra
    r = _post(x, deletes=[1], condiciones={"1": {"v": 1, "quitadas": {"lC": 1, "lP": 1, "lL2": 1}}})
    assert r["conservados"] == [1]
    d = _espera(x)["datos"]
    assert len(d) == 1 and [l["lid"] for l in d[0]["lineas"]] == ["lP2"]
    # baja con condición que se lleva todo: se borra (respuesta de siempre)
    r = _post(x, deletes=[1], condiciones={"1": {"v": 1, "quitadas": {"lP2": 1}}})
    assert set(r) == CLAVES_429 and _espera(x)["datos"] == []
    # un guardado con _fusion que llega a la cuenta ya cerrada: cuenta recreada (remap); repetirlo cae en la misma
    tardio = _cuenta(1, [CASADO, {**POSTRE, "lid": "lP3"}], {"nuevas": ["lP3"]})
    r = _post(x, [tardio])
    nuevo = r["remap"]["1"]
    assert nuevo != 1 and r["fusionados"] == [nuevo]
    r2 = _post(x, [tardio])
    assert r2["remap"] == {"1": nuevo}
    d = _espera(x)["datos"]
    assert len(d) == 1 and d[0]["id"] == nuevo and d[0]["recreada_de"] == 1 and [l["lid"] for l in d[0]["lineas"]] == ["lP3"]
    # el PUT quita _fusion
    v = _espera(x)["version"]
    r = x.c.put("/api/registros/pos_espera", json={"datos": [{**d[0], "_fusion": {"v": 1, "origen": "caja"}}], "version": v}, headers=x.h("admin"))
    assert r.status_code == 200, r.text
    assert "_fusion" not in _espera(x)["datos"][0]


def test_p7_otras_claves_por_la_ruta_como_antes(rest):
    x = rest
    url = "/api/registros/tareas_qa431/cambios"
    item = {"id": 1, "texto": "A", "_fusion": {"v": 1, "origen": "caja"}}
    r = x.c.post(url, json={"upserts": [item], "deletes": [], "nuevos": [1]}, headers=x.h("admin"))
    assert r.status_code == 200, r.text
    assert set(r.json()) == CLAVES_429
    g = x.c.get("/api/registros/tareas_qa431", headers=x.h("admin")).json()["datos"]
    assert g == [item]                                           # otra clave: se guarda tal cual, como hoy
    r = x.c.post(url, json={"upserts": [], "deletes": [1], "nuevos": [], "condiciones": {"1": {"v": 1, "quitadas": {}}}}, headers=x.h("admin"))
    assert r.status_code == 200 and set(r.json()) == CLAVES_429
    assert x.c.get("/api/registros/tareas_qa431", headers=x.h("admin")).json()["datos"] == []


def test_p7_baja_por_cobro_y_cuenta_recreada_no_heredan_lo_pagado(rest):
    """4.31 (corrección, revisión media): A cobra el pedido en línea con prepago y B le agregó una Limonada en esos segundos. La cuenta que
    queda (conservados) no se lleva el prepago, el cupón ni los puntos, tampoco cuando la pantalla atrasada de B vuelve a guardar con su
    copia vieja; y la cuenta recreada para un guardado que llega después del cierre tampoco los toma de lo que llega."""
    x = rest
    online = dict(canal="online", pedido_id=7, pedido_numero=7, prepago={"monto": 4305, "online": 4305}, cupon="QA", puntos_canjeados=20, credito=False)
    with Session(engine_empresa(x.eid)) as se:
        modulos.aplicar_cambios(se, x.eid, "pos_espera", [_cuenta(40, [CASADO, LIMONADA], **online)], [], [40])
        se.commit()
    r = _post(x, deletes=[40], condiciones={"40": {"v": 1, "quitadas": {"lC": 1}, "cobro": True}})
    assert r["conservados"] == [40]
    d = [c for c in _espera(x)["datos"] if c["id"] == 40][0]
    assert [l["lid"] for l in d["lineas"]] == ["lL"] and d["prepago"] is None and d["cupon"] is None and d["puntos_canjeados"] == 0 and d["pedido_id"] == 7
    # B, con su copia de antes del cobro, agrega el Postre: lo pagado no vuelve
    _post(x, [_cuenta(40, [CASADO, LIMONADA, POSTRE], {"nuevas": ["lP"]}, **online)])
    d = [c for c in _espera(x)["datos"] if c["id"] == 40][0]
    assert [l["lid"] for l in d["lineas"]] == ["lL", "lP"] and d["prepago"] is None and d["cupon"] is None and d["puntos_canjeados"] == 0
    # se cierra del todo; otro guardado atrasado (con lo del pedido) llega después: cuenta recreada, sin lo del pedido cobrado
    _post(x, deletes=[40], condiciones={"40": {"v": 1, "quitadas": {"lL": 1, "lP": 1}, "cobro": True}})
    cafe = {**POSTRE, "lid": "lF", "detalle": "Café"}
    r = _post(x, [_cuenta(40, [CASADO, cafe], {"nuevas": ["lF"]}, **online)])
    nuevo = r["remap"]["40"]
    r = _post(x, [_cuenta(40, [CASADO, cafe, {**POSTRE, "lid": "lP4"}], {"nuevas": ["lF", "lP4"]}, **online)])   # reenvío con un plato más: cae en la recreada
    assert r["remap"] == {"40": nuevo}
    d = [c for c in _espera(x)["datos"] if c["id"] == nuevo][0]
    assert d["recreada_de"] == 40 and [l["lid"] for l in d["lineas"]] == ["lF", "lP4"]
    assert not {"canal", "pedido_id", "pedido_numero", "prepago", "cupon", "puntos_canjeados", "credito"} & set(d), d


def test_p7_pedido_en_linea_conserva_lo_pagado(rest):
    """La cuenta de un pedido en línea pagado: la caja nueva le agrega un plato con _fusion y el prepago guardado queda."""
    x = rest
    with Session(engine_empresa(x.eid)) as se:
        modulos.aplicar_cambios(se, x.eid, "pos_espera", [_cuenta(40, [CASADO], canal="online", pedido_id=7, pedido_numero=7, prepago=4305, cupon="QA")], [], [40])
        se.commit()
    r = _post(x, [_cuenta(40, [CASADO, POSTRE], {"nuevas": ["lP"], "cuenta": ["prepago"]}, canal="online", prepago=0)])
    d = [c for c in _espera(x)["datos"] if c["id"] == 40][0]
    assert d["prepago"] == 4305 and d["cupon"] == "QA" and [l["detalle"] for l in d["lineas"]] == ["Casado", "Postre"]
    assert set(r) == CLAVES_429                                  # lo que quedó es lo que llegó (con el prepago impuesto antes)
