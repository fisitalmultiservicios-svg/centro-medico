# -*- coding: utf-8 -*-
"""4.39, novena vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera a octava: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada).

- Z1 confirmarDividir, al separar, pasar a una mesa o partir una cuenta ya guardada (Y3) y después de esperar la marca (X2): cada línea que
  la pantalla conoce (su base) tiene que seguir igual en el servidor (cantidad, envío, precio, descuento y nota) y el servicio también. Si
  otro equipo puso un descuento, cambió el precio o la nota o quitó el servicio con «Dividir» abierto aquí, no se parte nada y se avisa; al
  volver a abrirlo, lo que se separa conserva lo que puso el otro equipo (antes se perdía: la cuenta aparte, la Mesa 7 o las partes salían
  al precio de lista, sin la nota o con el servicio quitado). Un solo equipo (con sus cambios guardados o no, el 2x1, un cupón, el prepago o
  el pedido en línea sin lid) nunca ve el aviso. También en la caja de comercio y con «Cobrar estos platos» después de esperar la marca.
- Z3 una línea que otro equipo SOLO agregó ya no detiene la división: queda en la cuenta de origen y, si la mandó a cocina, su comanda sale
  una vez (antes salía el aviso y, al volver a partir la cuenta en partes iguales, el plato cambiaba de identificador y su comanda no salía
  nunca: «No salió en la comanda: Postre»).
- Z2 las partes iguales de una mesa se calculan con la cuenta traída en el acto (_alDia = 0 antes de cobrarParte), aunque «Dividir» se haya
  abierto hace menos de 3 s: lo que otro equipo quitó o bajó no se cobra (antes la parte llevaba medio plato quitado o un Casado de más).
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la novena vuelta
deshecha (NOVENA y _caja_sin_novena de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta) y ahí se ve el defecto que el cambio arregla.
Defecto que dejaba Z3 (era un xfail estricto, abajo): en un pedido en línea con prepago, si otro equipo le agregó un plato y aquí se pasa todo lo
que se ve a una cuenta aparte, el prepago quedaba en las DOS cuentas (la cuenta aparte se lo llevaba y la del pedido seguía con él y con el plato
agregado): se descontaba dos veces. 4.39 (décima vuelta): P1 lo corrige (sale el aviso y no se pasa nada; ver tests/test_439_decima_vuelta.py) y
la prueba ya no lleva la marca xfail.
4.39 (décima vuelta): el contrato compara la novena vuelta contra caja.js sin la décima (DECIMA y _caja_sin_decima de
tests/test_439_tercera_vuelta.py: la décima cambió dos consultas de confirmarDividir que contaban como REFRESCAR15 y agregó P1).
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import RAIZ, _metodo
from tests.test_439_octava_vuelta import AVISO_Y3
from tests.test_439_octava_vuelta import _correr as _correr8
from tests.test_439_septima_vuelta import CAMBIO_DIV
from tests.test_439_tercera_vuelta import FIRMA_ENV, FIRMA_LINEA, NOVENA, REFRESCAR15, _caja_sin_decima, _caja_sin_novena

# el único método que cambió la novena vuelta (cada tripleta de NOVENA está en él)
CAMBIADOS = ("async confirmarDividir() {",)
CAMBIO_M6 = "La cuenta de Mesa 6 cambió en otro equipo. Revise el total antes de cobrar."
NO_SALIO_C1 = "No salió en la comanda: Postre. En otro equipo ya se había quitado o cobrado de Cuenta 1."
CASADO1, POSTRE1, LIMONADA1 = ["Casado×1"], ["Postre×1"], ["Limonada×1"]
# el Casado con lo que le puso el otro equipo (como lo anota `plano`)
SUFIJO = {"desc": " −50 %", "precio": " a 3000", "nota": " «Sin cebolla»", "servicio": ""}


def _casado(q, que=None):
    return "Casado×" + q + (SUFIJO[que] if que else "")


def _antes(cabezas=CAMBIADOS):
    """Los métodos que cambió la novena vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_novena()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
// el precio de lista de cada plato: lo que se aparta de él se anota
const PRECIO = { Casado: 3500, Limonada: 1500, Postre: 1200, Cerveza: 1800, 'Envío a domicilio': 1327.43 };
// cada plato con su cantidad y, si los tiene, su descuento, su precio cambiado y su nota; las cuentas del servidor con el servicio
const plano = l => l.detalle + '×' + l.cantidad + (+l.descuento_pct ? ' −' + (+l.descuento_pct) + ' %' : '') + (+l.precio_unitario !== PRECIO[l.detalle] ? ' a ' + (+l.precio_unitario) : '') + (l.nota ? ' «' + l.nota + '»' : '');
const srvZ = () => S.items.map(x => [x.nombre, (x.lineas || []).map(plano).sort(), !!x.servicio]);
const pantallaZ = vm => vm.lineas.map(plano).sort();
// los avisos de «Dividir» (el de Y3, el de X2 y el de una comanda que la pantalla no tiene)
const avisosDiv = vm => avisos(vm).filter(t => t === AVISO_Y3 || t === CAMBIO_DIV || t === AVISO_DIVIDIR_7);
// la Mesa 6 (o, sin mesa, la cuenta guardada) con esos platos y con o sin servicio, guardada por un tercer equipo y abierta en A y en B
async function conServicio(mesa, platos, servicio) {
  nuevo();
  const g = venta(await equipo());
  if (mesa) g.abrirMesa(M6);
  g.servicio = !!servicio; for (const p of platos) g.lineas.push(p);
  if (mesa) g.persistirCuenta(); else g.guardarCuenta();
  await g.A.mock.guardarTodo();
  const id = S.items[S.items.length - 1].id;
  if (mesa) { const a = venta(await equipo()), b = venta(await equipo()); await a.sincronizar(); a.abrirMesa(M6); await b.sincronizar(); b.abrirMesa(M6); return [id, a, b]; }
  const a = await abierta(id), b = await abierta(id); return [id, a, b];
}
// el cambio `que` sobre el Casado (o la cuenta) en ESE equipo: desc (50 % de descuento, como descuentoPct), precio (₡3 000), nota («Sin cebolla»),
// servicio (lo quita); con `guardar`, guarda la cuenta (y con `subir`, la sube al servidor)
async function cambiar(vm, que, guardar, subir) {
  const l = vm.lineas.find(x => x.detalle === 'Casado');
  if (que === 'desc') Object.assign(l, { descuento_pct: 50, descuento_manual: true, promo: '', descuento: r2(+l.cantidad * +l.precio_unitario / 2) });
  else if (que === 'precio') Object.assign(l, { precio_unitario: 3000, precio_manual: true });
  else if (que === 'nota') l.nota = 'Sin cebolla';
  else if (que === 'servicio') vm.servicio = false;
  if (guardar) vm.persistirCuenta();
  if (subir) await vm.A.mock.guardarTodo();
}
// ESE equipo elige el Casado para `destino` (nueva, 7, cobrar) o 2 partes iguales (partes); con todo, todo lo que ve para la Mesa 7
function elegirCasado(vm, destino) {
  if (destino === 'partes') { vm.dividir.modo = 'partes'; vm.dividir.partes = 2; return; }
  if (destino === 'todo') { vm.dividir.destino = 7; vm.dividir.sel = Object.fromEntries(vm.lineas.map((l, i) => [i, +l.cantidad])); return; }
  const i = vm.lineas.findIndex(x => x.detalle === 'Casado'); vm.dividir.destino = destino; vm.dividir.sel = { [i]: +vm.lineas[i].cantidad };
}
// lo hecho al dividir (los avisos de todos los días)
const hechoDiv = vm => avisos(vm).filter(t => t.startsWith('Platos pasados a ') || t.startsWith('Cuenta dividida') || t.startsWith('Todo se pasó a '));
"""


def _correr(tmp_path, casos, antes=()):
    return _correr8(tmp_path, AYUDAS + casos, antes=antes)


# ================================================================================================================ Z1: lo que otro equipo cambió
CASOS_Z1 = r"""
// la Mesa 6 con Casado y Postre ya enviados (hace un minuto) y con servicio, abierta en A y en B (con `destino` partes, la cuenta guardada sin mesa
// sin enviar; con comercio, esa cuenta en la caja de comercio). A abre «Dividir». B hace `que` sobre el Casado (o la cuenta) y guarda. A (sin
// sincronizar) separa el Casado (nueva), lo pasa a la Mesa 7 (7) o parte en 2 partes iguales (partes). Si salió el aviso, vuelve a abrir «Dividir» y
// elige lo mismo
async function z1(que, destino) {
  const mesa = destino === 'nueva' || destino === 7, com = destino === 'comercio', env = mesa ? { enviado: VIEJA(), ronda: 1 } : {};
  const [id, a, b] = await conServicio(mesa, [{ ...CASADO(), ...env }, { ...POSTRE(), ...env }], true); a.mesas = [M6, M7];
  if (com) { a.esRestaurante = false; b.esRestaurante = false; }
  const dest = com ? 'nueva' : destino;
  await a.abrirDividir();
  await cambiar(b, que, true, true);
  const srvB = srvZ(), lis = listas(a);
  elegirCasado(a, dest); await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { dividir: !!a.dividir, y3: avisoY3(a), srv: srvZ(), consultas: lis.n, alDia: a._alDia };
  let segundo = null;
  if (primero.y3.length && !a.dividir) {
    await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: pantallaZ(a), servicio: a.servicio };
    if (a.dividir) { elegirCasado(a, dest); await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre(); segundo.dividir = !!a.dividir; }
  }
  return { srvB, primero, segundo, y3: avisoY3(a), srv: srvZ(), hecho: hechoDiv(a), impresos: quienes(a) };
}
for (const destino of ['nueva', 7, 'partes', 'comercio']) out[destino] = await z1(@QUE@, destino);
"""


def _z1_fin(que, destino, conservado):
    """Las cuentas del servidor al final: con lo que puso el otro equipo (conservado) o como quedaban antes de esta vuelta (se perdía)."""
    sv = que != "servicio"
    q = que if (conservado and que != "servicio") else None
    nuevo = sv if conservado else True                                                  # antes, la cuenta nueva salía con el servicio que ya no estaba
    if destino == "partes":
        mitad = sorted([_casado("0.5", q), "Postre×0.5"])
        return [["Cuenta 1", mitad, sv], ["Cuenta 1 · parte 2 de 2", mitad, nuevo]]
    nombre, origen = {"nueva": ("Mesa 6 · aparte", "Mesa 6"), "7": ("Mesa 7", "Mesa 6"), "comercio": ("Cuenta 1 · aparte", "Cuenta 1")}[destino]
    return [[origen, POSTRE1, sv], [nombre, [_casado("1", q)], nuevo]]


@pytest.mark.parametrize("que", ["desc", "precio", "nota", "servicio"])
def test_z1_dividir_no_pierde_lo_que_cambio_otro_equipo_en_node(tmp_path, que):
    casos = CASOS_Z1.replace("@QUE@", json.dumps(que))
    r = _correr(tmp_path / "ahora", casos)
    sv = que != "servicio"
    for destino in ("nueva", "7", "partes", "comercio"):
        x, p, s = r[destino], r[destino]["primero"], r[destino]["segundo"]
        origen = "Mesa 6" if destino in ("nueva", "7") else "Cuenta 1"
        cambiado = sorted([_casado("1", que if que != "servicio" else None), "Postre×1"])
        # B guardó su cambio; A no partió nada: el aviso «La cuenta cambió…», «Dividir» cerrado, la cuenta del servidor como la dejó B, una consulta
        # y la próxima apertura junta
        assert x["srvB"] == [[origen, cambiado, sv]], (que, destino, x)
        assert p["y3"] == [AVISO_Y3] and p["dividir"] is False and p["srv"] == x["srvB"] and p["consultas"] == 1 and p["alDia"] == 0, (que, destino, x)
        # al volver a abrir «Dividir» la pantalla tiene lo que puso B (y el servicio quitado) y se divide sin repetir el aviso
        assert s == {"abierto": True, "platos": cambiado, "servicio": sv, "dividir": False}, (que, destino, x)
        # lo separado, lo pasado a la Mesa 7 o cada parte conserva el descuento, el precio, la nota o el servicio quitado por B; nada sale a cocina
        assert x["y3"] == [AVISO_Y3] and len(x["hecho"]) == 1 and x["srv"] == _z1_fin(que, destino, True) and x["impresos"] == [], (que, destino, x)

    # antes de esta vuelta: la comparación miraba solo lid, cantidad y envío: sin aviso se partía con la línea de la pantalla y lo que puso B se perdía
    # (el Casado separado al precio de lista o sin la nota; con partes, también el que quedaba; la cuenta nueva con el servicio que B quitó)
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for destino in ("nueva", "7", "partes", "comercio"):
        x = v[destino]
        assert x["primero"]["y3"] == [] and x["segundo"] is None and len(x["hecho"]) == 1 and x["srv"] == _z1_fin(que, destino, False), (que, destino, x)


CASOS_Z1_X2 = r"""
// la Mesa 6 (con partes, la cuenta guardada sin mesa) con Casado y Postre sin enviar y con servicio, abierta en A y en B. B toca «Comanda» (sale
// enseguida); A sincroniza (la marca), abre «Dividir» y elige el Casado para `destino` (nueva, 7, cobrar) o 2 partes iguales: espera la marca. A los
// 1,5 s B hace `que` y guarda. Si salió el aviso, A vuelve a abrir «Dividir», elige lo mismo y confirma (con cobrar, cobra la parte)
async function z1x2(que, destino) {
  const [id, a, b] = await conServicio(destino !== 'partes', [CASADO(), POSTRE()], true); a.mesas = [M6, M7];
  await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar(); const m0 = !!marca(a);
  await a.abrirDividir(); elegirCasado(a, destino);
  const t0 = Date.now(), pd = a.confirmarDividir();
  await espera(1500); await cambiar(b, que, true, true);
  await pd; if (a.cobroParcial) await conPago(a); const ms = Date.now() - t0; await a.A.mock.guardarTodo();
  const primero = { dividir: !!a.dividir, pago: !!a.pago, parcial: !!a.cobroParcial, avisos: avisosDiv(a), srv: srvZ(), alDia: a._alDia, ms };
  let segundo = null;
  if (primero.avisos.length && !a.dividir && !a.pago) {
    await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: pantallaZ(a), servicio: a.servicio };
    if (a.dividir) { elegirCasado(a, destino); await a.confirmarDividir(); if (a.cobroParcial) await conPago(a); segundo.dividir = !!a.dividir; }
  }
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { m0, primero, segundo, avisos: avisosDiv(a), srv: srvZ(), hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), impresos: quienes(a), hecho: hechoDiv(a), libre: libre() };
}
out.r = await z1x2(@QUE@, @DESTINO@);
"""
# lo que queda en el servidor al final, con lo de B conservado (ahora) y como quedaba antes; lo cobrado (con cobrar: el Casado con el 50 %, ₡1 977,50)
Z1_X2 = {
    "desc_nueva": ([["Mesa 6", POSTRE1, True], ["Mesa 6 · aparte", [_casado("1", "desc")], True]], [["Mesa 6", POSTRE1, True], ["Mesa 6 · aparte", CASADO1, True]]),
    "precio_7": ([["Mesa 6", POSTRE1, True], ["Mesa 7", [_casado("1", "precio")], True]], [["Mesa 6", POSTRE1, True], ["Mesa 7", CASADO1, True]]),
    "nota_nueva": ([["Mesa 6", POSTRE1, True], ["Mesa 6 · aparte", [_casado("1", "nota")], True]], [["Mesa 6", POSTRE1, True], ["Mesa 6 · aparte", CASADO1, True]]),
    "servicio_nueva": ([["Mesa 6", POSTRE1, False], ["Mesa 6 · aparte", CASADO1, False]], [["Mesa 6", POSTRE1, False], ["Mesa 6 · aparte", CASADO1, True]]),
    "desc_partes": ([["Cuenta 1", [_casado("0.5", "desc"), "Postre×0.5"], True], ["Cuenta 1 · parte 2 de 2", [_casado("0.5", "desc"), "Postre×0.5"], True]],
                    [["Cuenta 1", ["Casado×0.5", "Postre×0.5"], True], ["Cuenta 1 · parte 2 de 2", ["Casado×0.5", "Postre×0.5"], True]]),
    "desc_cobrar": ([["Mesa 6", POSTRE1, True]], [["Mesa 6", POSTRE1, True]]),
}


@pytest.mark.parametrize("caso", list(Z1_X2))
def test_z1_despues_de_esperar_la_marca_no_pierde_lo_que_cambio_otro_equipo_en_node(tmp_path, caso):
    que, destino = caso.split("_")
    casos = CASOS_Z1_X2.replace("@QUE@", json.dumps(que)).replace("@DESTINO@", json.dumps(7 if destino == "7" else destino))
    r = _correr(tmp_path / "ahora", casos)["r"]
    ahora, antes = Z1_X2[caso]
    sv = que != "servicio"
    origen = "Cuenta 1" if destino == "partes" else "Mesa 6"
    cambiado = sorted([_casado("1", que if que != "servicio" else None), "Postre×1"])
    # A vio la comanda de B (la marca) y esperó unos 4 s; B cambió la cuenta durante la espera: el aviso de X2, nada partido ni cobrado, la cuenta del
    # servidor como la dejó B y la próxima apertura junta
    assert r["m0"] is True and 3000 <= r["primero"]["ms"] < 6500, (caso, r)
    p = r["primero"]
    assert p["avisos"] == [CAMBIO_DIV] and p["dividir"] is False and p["pago"] is False and p["parcial"] is False and p["alDia"] == 0, (caso, r)
    assert p["srv"] == [[origen, cambiado, sv]], (caso, r)
    # al volver a abrir «Dividir» la pantalla tiene lo de B y se divide (o se cobra) una vez, sin repetir el aviso; la comanda de B salió una vez
    assert r["segundo"] == {"abierto": True, "platos": cambiado, "servicio": sv, "dividir": False} and r["avisos"] == [CAMBIO_DIV], (caso, r)
    assert r["srv"] == ahora and r["impresos"] == [["B", ["Casado×1", "Postre×1"]]] and r["libre"] is True, (caso, r)
    assert r["hechos"] == ([["A", 1977.5, CASADO1]] if destino == "cobrar" else []), (caso, r)

    # antes de esta vuelta: ni X2 ni la comparación de Y3 miraban el descuento, el precio, la nota ni el servicio: se partía (o se cobraba) con la
    # línea de la pantalla y lo de B se perdía; con cobrar, el Casado se cobraba al precio de lista (₡3 955 en vez de ₡1 977,50)
    v = _correr(tmp_path / "antes", casos, antes=_antes())["r"]
    assert v["primero"]["avisos"] == [] and v["segundo"] is None and v["srv"] == antes, (caso, v)
    assert v["hechos"] == ([["A", 3955, CASADO1]] if destino == "cobrar" else []), (caso, v)


CASOS_Z1_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo. `caso`: «que_como» con que = desc, precio, nota, servicio o cupon (10 % en cada plato, como aplicarCupon)
// y como = singuardar, guardado (persistirCuenta) o ya (y subido); dosxuno (Casado y 2 Cervezas con el 2x1, en la Mesa 6); prepago (el pedido en línea
// con ₡1 000 ya pagados en línea) y pedido (el pedido en línea sin prepago; sus líneas no traen lid). A separa el Casado (nueva), lo pasa a la Mesa 7
// (7) o parte en 2 partes iguales (partes; la cuenta guardada sin mesa)
const PROMO9 = [{ tipo: '2x1', nombre: '2x1 cervezas', productos: [4] }];
async function solo(caso, destino) {
  let a; const mesa = destino !== 'partes';
  if (caso === 'prepago' || caso === 'pedido') {
    nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); if (caso === 'prepago') S.items[0].prepago = { monto: 1000, medio: '06', referencia: 'QA-1' };
    a = venta(await equipo()); await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === 1));
  } else if (caso === 'dosxuno') {
    nuevo(); const g = venta(await equipo()); g.promosActivas = PROMO9; g.abrirMesa(M6); g.lineas.push(CASADO(), CERVEZA(2)); g.aplicarPromos(); g.persistirCuenta(); await g.A.mock.guardarTodo();
    a = venta(await equipo()); a.promosActivas = PROMO9; await a.sincronizar(); a.abrirMesa(M6);
  } else {
    const env = mesa ? { enviado: VIEJA(), ronda: 1 } : {};
    [, a] = await conServicio(mesa, [{ ...CASADO(), ...env }, { ...POSTRE(), ...env }], true);
    const [que, como] = caso.split('_');
    if (que === 'cupon') {
      for (const l of a.lineas) Object.assign(l, { descuento_pct: 10, descuento_manual: true, promo: 'Cupón QA10', descuento: r2(+l.cantidad * +l.precio_unitario / 10) });
      a.cupon = { codigo: 'QA10', descuento: 470, base: 4700 }; if (como !== 'singuardar') a.persistirCuenta(); if (como === 'ya') await a.A.mock.guardarTodo();
    } else await cambiar(a, que, como !== 'singuardar', como === 'ya');
  }
  a.mesas = [M6, M7];
  const promo = a.lineas.filter(l => +l.descuento_pct > 0).map(l => l.detalle + '×' + l.cantidad);
  await a.abrirDividir(); const lis = listas(a), t0 = Date.now();
  elegirCasado(a, destino); await a.confirmarDividir(); const ms = Date.now() - t0; await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, consultas: lis.n, dividir: !!a.dividir, promo, avisos: otrosAvisos(a), hecho: hechoDiv(a), srv: srvZ(), impresos: quienes(a) };
}
for (const [caso, destino] of @CASOS@) out[caso + '__' + destino] = await solo(caso, destino);
"""


def _solo_casos():
    """{«caso__destino»: cuentas del servidor al final}: lo que A cambió (guardado o no) viaja con lo que se separa o se parte."""
    PED = "Pedido #41 · Cliente QA"
    fin = {}
    for que in ("desc", "precio", "nota", "servicio", "cupon"):
        sv = que != "servicio"
        cas = (lambda q: _casado(q) + " −10 %") if que == "cupon" else (lambda q: _casado(q, que if que != "servicio" else None))
        pos = (lambda q: "Postre×" + q + " −10 %") if que == "cupon" else (lambda q: "Postre×" + q)
        for como in ("singuardar", "guardado", "ya"):
            dest, nombre = ("7", "Mesa 7") if que == "nota" else ("nueva", "Mesa 6 · aparte")
            fin[que + "_" + como + "__" + dest] = [["Mesa 6", [pos("1")], sv], [nombre, [cas("1")], sv]]
            mitad = sorted([cas("0.5"), pos("0.5")])
            fin[que + "_" + como + "__partes"] = [["Cuenta 1", mitad, sv], ["Cuenta 1 · parte 2 de 2", mitad, sv]]
    fin["dosxuno__nueva"] = [["Mesa 6", ["Cerveza×2 −50 %"], False], ["Mesa 6 · aparte", CASADO1, False]]
    fin["dosxuno__7"] = [["Mesa 6", ["Cerveza×2 −50 %"], False], ["Mesa 7", CASADO1, False]]
    for c in ("prepago", "pedido"):
        fin[c + "__nueva"] = [[PED, ["Envío a domicilio×1", "Postre×1"], False], [PED + " · aparte", CASADO1, False]]
        mitad = ["Casado×0.5", "Envío a domicilio×0.5", "Postre×0.5"]
        fin[c + "__partes"] = [[PED, mitad, False], [PED + " · parte 2 de 2", mitad, False]]
    return fin


def test_z1_un_solo_equipo_divide_sin_aviso_en_node(tmp_path):
    fin = _solo_casos()
    casos = [[k.split("__")[0], 7 if k.endswith("__7") else k.split("__")[1]] for k in fin]
    r = _correr(tmp_path, CASOS_Z1_SOLO.replace("@CASOS@", json.dumps(casos)))
    for k, srv in fin.items():
        x = r[k]
        # sin el aviso: lo que A cambió (guardado o no), el 2x1, el cupón, el prepago y el pedido sin lid no cuentan como «otro equipo»; una consulta, sin
        # esperar; lo separado o partido lleva lo que A le puso
        assert x["avisos"] == [] and len(x["hecho"]) == 1 and x["dividir"] is False and x["consultas"] == 1 and x["ms"] < 1500 and x["srv"] == srv and x["impresos"] == [], (k, x)
    # el 2x1 y el cupón estaban aplicados
    assert r["dosxuno__nueva"]["promo"] == ["Cerveza×2"] and r["cupon_ya__nueva"]["promo"] == ["Casado×1", "Postre×1"] and r["desc_singuardar__nueva"]["promo"] == CASADO1, r


# ================================================================================================================ Z3: un plato que otro equipo solo agregó
CASOS_Z3 = r"""
// `como`: y3, la cuenta con Casado y Limonada ya enviados (hace un minuto); con «Dividir» abierto en A, B agrega un Postre, lo guarda y toca «Comanda»
// con su revisión lenta (1,5 s) y, en cuanto su guardado llegó al servidor, A elige; x2, Casado y Limonada sin enviar: B toca «Comanda», A sincroniza
// (la marca), abre «Dividir», elige y confirma (espera la marca) y a los 1,5 s B agrega el Postre, lo guarda y toca «Comanda» con su revisión lenta.
// `destino`: nueva o 7 (la Mesa 6, A separa el Casado), todo (la Mesa 6, A pasa todo lo que ve a la Mesa 7) o partes (la cuenta guardada sin mesa, 2
// partes iguales). Si salió un aviso, A vuelve a abrir «Dividir» y elige lo mismo
async function z3(como, destino) {
  const mesa = destino !== 'partes', ENV = VIEJA();
  const platos = como === 'y3' ? [{ ...CASADO(), enviado: ENV, ronda: 1 }, { ...LIMONADA(), enviado: ENV, ronda: 1 }] : [CASADO(), LIMONADA()];
  const [id, a, b] = await cuenta(mesa, platos); a.mesas = [M6, M7];
  const agrega = async () => { b.lineas.push(POSTRE()); b.persistirCuenta(); await b.A.mock.guardarTodo(); const s = lento(b, 1500), p = b.enviarComanda(); await hasta(() => enviadaEnServidor(id)); return [s, p]; };
  let suelta = () => {}, pb = null, m0 = null;
  if (como === 'x2') { await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar(); m0 = !!marca(a); }
  await a.abrirDividir();
  if (como === 'y3') [suelta, pb] = await agrega();
  const lis = listas(a), t0 = Date.now();
  elegirCasado(a, destino); const pd = a.confirmarDividir();
  if (como === 'x2') { await espera(1500); [suelta, pb] = await agrega(); }
  await pd; const ms = Date.now() - t0; await a.A.mock.guardarTodo();
  const primero = { dividir: !!a.dividir, avisos: avisosDiv(a), srv: srvZ(), consultas: lis.n, ms, vista: a.vista };
  let segundo = null;
  if (primero.avisos.length && !a.dividir) {
    await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: pantallaZ(a) };
    if (a.dividir) { elegirCasado(a, destino); await a.confirmarDividir(); await a.A.mock.guardarTodo(); segundo.dividir = !!a.dividir; }
  }
  if (pb) await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { m0, primero, segundo, avisos: avisosDiv(a), srv: srvZ(), enviados: enviados(), impresos: quienes(a), noSalioB: noSalio(b), hecho: hechoDiv(a) };
}
out.r = await z3(@COMO@, @DESTINO@);
"""
# lo que queda en el servidor al final (ahora): el Postre de B queda en la cuenta de origen, enviado
LIM_POS = ["Limonada×1", "Postre×1"]
Z3_FIN = {"nueva": [["Mesa 6", LIM_POS, False], ["Mesa 6 · aparte", CASADO1, False]], "7": [["Mesa 6", LIM_POS, False], ["Mesa 7", CASADO1, False]],
          "todo": [["Mesa 6", POSTRE1, False], ["Mesa 7", ["Casado×1", "Limonada×1"], False]],
          "partes": [["Cuenta 1", ["Casado×0.5", "Limonada×0.5", "Postre×1"], False], ["Cuenta 1 · parte 2 de 2", ["Casado×0.5", "Limonada×0.5"], False]]}
Z3_CASOS = ["y3_nueva", "y3_7", "y3_todo", "y3_partes", "x2_nueva", "x2_7", "x2_partes"]


@pytest.mark.parametrize("caso", Z3_CASOS)
def test_z3_un_plato_que_otro_equipo_solo_agrego_no_detiene_la_division_en_node(tmp_path, caso):
    como, destino = caso.split("_")
    casos = CASOS_Z3.replace("@COMO@", json.dumps(como)).replace("@DESTINO@", json.dumps(7 if destino == "7" else destino))
    r = _correr(tmp_path / "ahora", casos)["r"]
    comandas = ([["B", ["Casado×1", "Limonada×1"]]] if como == "x2" else []) + [["B", POSTRE1]]
    srv = Z3_FIN[destino]
    # se divide al primer intento, sin aviso: una consulta sin esperar (con todo, otra más: la sincronización de siempre después de cerrar la cuenta
    # en esta pantalla); con la marca, la espera de siempre y una consulta más después de esperar
    p = r["primero"]
    assert p["avisos"] == [] and p["dividir"] is False and r["segundo"] is None and len(r["hecho"]) == 1, (caso, r)
    if como == "y3":
        assert p["consultas"] == (2 if destino == "todo" else 1) and p["ms"] < 1000, (caso, r)
    else:
        assert p["consultas"] == 2 and 3000 <= p["ms"] < 6500 and r["m0"] is True, (caso, r)
    # el Postre que agregó B queda en la cuenta de origen (también si A pasó todo lo que veía a la Mesa 7: la cuenta no se cierra) y enviado; su comanda
    # salió una vez, de B, y la revisión de B no avisó nada
    assert r["srv"] == srv and r["impresos"] == comandas and r["noSalioB"] == [], (caso, r)
    assert all("Postre×1" not in e for e in r["enviados"][1:]) and "Postre×1" in r["enviados"][0], (caso, r)
    if destino == "todo":
        assert r["hecho"] == ["Todo se pasó a Mesa 7: la cuenta quedó vacía"] and p["vista"] == "mesas", (caso, r)   # el texto no es literal (límite aceptado)

    # antes de esta vuelta: la comparación miraba la lista entera: el Postre que B solo agregó daba el aviso y había que volver a dividir. Al volver a
    # partir en partes iguales la cuenta guardada (con la revisión de B todavía en curso), el Postre cambiaba de identificador: su comanda no salía nunca
    v = _correr(tmp_path / "antes", casos, antes=_antes())["r"]
    assert v["primero"]["avisos"] == [AVISO_Y3 if como == "y3" else CAMBIO_DIV] and v["primero"]["srv"] == [[("Cuenta 1" if destino == "partes" else "Mesa 6"), sorted(["Casado×1", "Limonada×1", "Postre×1"]), False]], (caso, v)
    assert v["segundo"]["abierto"] is True and v["segundo"]["dividir"] is False, (caso, v)
    if caso == "y3_partes":
        assert v["noSalioB"] == [NO_SALIO_C1] and v["impresos"] == [], v                               # la cocina nunca recibió el Postre
        assert v["srv"] == [["Cuenta 1", ["Casado×0.5", "Limonada×0.5", "Postre×0.5"], False], ["Cuenta 1 · parte 2 de 2", ["Casado×0.5", "Limonada×0.5", "Postre×0.5"], False]], v


CASOS_PREPAGO = r"""
// el pedido en línea a domicilio con ₡1 000 ya pagados en línea (prepago), abierto en A y en B. A abre «Dividir»; B agrega una Limonada y la guarda. A
// pasa todo lo que ve (Casado, Postre y el envío) a una cuenta aparte. Después cada cuenta abre su cobro (abrirPago toma el prepago de la cuenta)
nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); S.items[0].prepago = { monto: 1000, medio: '06', referencia: 'QA-1' };
const a = venta(await equipo()); await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === 1));
const b = venta(await equipo()); await b.sincronizar(); b.recuperar(b.espera.find(x => x.id === 1));
await a.abrirDividir();
b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
a.dividir.destino = 'nueva'; a.dividir.sel = Object.fromEntries(a.lineas.map((l, i) => [i, +l.cantidad]));
await a.confirmarDividir(); await a.A.mock.guardarTodo(); await hastaLibre(); await espera(50); await a.A.mock.guardarTodo();
const cuentas = S.items.map(x => ({ nombre: x.nombre, platos: (x.lineas || []).map(l => l.detalle + '×' + l.cantidad).sort(), prepago: x.prepago ? +x.prepago.monto : 0, pedido: x.pedido_id || null }));
const prepagos = [];
for (const c of S.items.slice()) { const v = venta(await equipo()); await v.sincronizar(); v.recuperar(v.espera.find(x => x.id === c.id)); await v.abrirPago(); prepagos.push(v.prepago ? +v.prepago.monto : 0); v.cerrarPago(); }
out.r = { cuentas, prepagos, avisos: avisos(a) };
"""


# 4.39 (décima vuelta): era un xfail estricto (el defecto que dejaba Z3); P1 lo corrige: con un plato que la pantalla no conoce no se pasa todo, sale el
# aviso y queda una sola cuenta con el prepago. Las versiones «de antes» de la décima están en tests/test_439_decima_vuelta.py
def test_z3_pasar_todo_un_pedido_con_prepago_y_un_plato_de_otro_equipo_no_duplica_el_prepago_en_node(tmp_path):
    # antes de esta vuelta (control, va primero): la Limonada de B daba el aviso de Y3 y no se partía; una sola cuenta con el prepago, una vez
    v = _correr(tmp_path / "antes", CASOS_PREPAGO, antes=_antes())["r"]
    assert v["avisos"] == [AVISO_Y3] and v["prepagos"] == [1000], v
    assert v["cuentas"] == [{"nombre": "Pedido #41 · Cliente QA", "platos": ["Casado×1", "Envío a domicilio×1", "Limonada×1", "Postre×1"], "prepago": 1000, "pedido": 9}], v

    r = _correr(tmp_path / "ahora", CASOS_PREPAGO)["r"]
    # todo lo pedido sigue en alguna cuenta, una sola vez (el Casado, el Postre y el envío de A; la Limonada de B)
    platos = sorted(sum((c["platos"] for c in r["cuentas"]), []))
    assert platos == ["Casado×1", "Envío a domicilio×1", "Limonada×1", "Postre×1"], r
    # lo pagado en línea (₡1 000) está en UNA sola cuenta y se descuenta una vez; el pedido queda enlazado a una sola cuenta. 4.39 (décima vuelta): con
    # P1 sale el aviso de volver a abrir «Dividir» y no se pasa nada (antes de la décima, la cuenta aparte se llevaba el prepago y el enlace y la del
    # pedido, que no se cerraba por la Limonada de B, se quedaba también con ellos: prepagos == [1000, 1000])
    assert sum(c["prepago"] for c in r["cuentas"]) == 1000 and sum(r["prepagos"]) == 1000, r
    assert sum(1 for c in r["cuentas"] if c["pedido"] == 9) == 1, r
    assert r["avisos"] == [AVISO_Y3] and r["prepagos"] == [1000] and r["cuentas"] == v["cuentas"], r


# ================================================================================================================ Z2: partes iguales de una mesa
CASOS_Z2 = r"""
// la Mesa 6 con 2 Casados y un Postre (ya enviados hace un minuto; con `sin`, sin enviar), abierta en A y en B. A abre «Dividir». `que`: quita, B quita el
// Postre; baja, B baja el Casado a 1; solo, nadie más; lenta, nadie más y la lista de A tarda 3 s. Enseguida (menos de 3 s después de abrir «Dividir»)
// A elige 2 partes iguales y confirma: se abre el cobro de la parte 1 y se cobra
async function z2(que, sin) {
  const env = sin ? {} : { enviado: VIEJA(), ronda: 1 };
  const [id, a, b] = await mesaGuardada([{ ...CASADO(), cantidad: 2, ...env }, { ...POSTRE(), ...env }]);
  await a.abrirDividir(); const t0 = Date.now();
  if (que === 'quita') await quitarPostre(b); else if (que === 'baja') await bajarCasado(b);
  if (que === 'lenta') lento(a, 3000);
  const srvB = srv(), lis = listas(a), t1 = Date.now();
  a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); const ms = Date.now() - t1; await conPago(a);
  const abierto = { menos3s: t1 - t0 < 3000, pago: !!a.pago, parte: detalles(a), parcial: a.cobroParcial ? [a.cobroParcial.parte, a.cobroParcial.de] : null, consultas: lis.n, ms, avisos: otrosAvisos(a) };
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { srvB, abierto, hechos: cobrados(a), srv: srv(), avisos: otrosAvisos(a), impresos: quienes(a), libre: libre() };
}
for (const [que, sin] of @CASOS@) out[que + (sin ? '_sin' : '')] = await z2(que, sin);
"""
# lo que B dejó en la cuenta; la parte 1 que se cobra y lo que queda en la Mesa 6 (ahora y antes de esta vuelta)
Z2 = {"quita": (["Casado×2"], ["Casado×1"], ["Casado×1"], ["Casado×1", "Postre×0.5"], ["Casado×1"]),
      "baja": (["Casado×1", "Postre×1"], ["Casado×0.5", "Postre×0.5"], ["Casado×0.5", "Postre×0.5"], ["Casado×1", "Postre×0.5"], ["Casado×1", "Postre×0.5"])}


def test_z2_partes_iguales_de_una_mesa_con_la_cuenta_al_dia_en_node(tmp_path):
    casos = CASOS_Z2.replace("@CASOS@", json.dumps([["quita", False], ["baja", False], ["quita", True], ["baja", True]]))
    r = _correr(tmp_path / "ahora", casos)
    for k in ("quita", "baja", "quita_sin", "baja_sin"):
        x, a = r[k], r[k]["abierto"]
        dejo, parte, queda, _, _ = Z2[k.split("_")[0]]
        assert x["srvB"] == [["Mesa 6", dejo, None]] and a["menos3s"] is True, (k, x)
        # la parte se calculó con la cuenta de ahora (el aviso «cambió…»): la parte 1 de 2 sin lo que B quitó o bajó; una consulta más que antes
        assert a["avisos"] == [CAMBIO_M6] and a["pago"] is True and a["parcial"] == [1, 2] and a["parte"] == parte, (k, x)
        assert a["consultas"] == (2 if k.endswith("_sin") else 1) and a["ms"] < 1000, (k, x)
        # se cobró esa parte, una vez; en la Mesa 6 queda la otra mitad de lo que hay ahora (nada se cobra de más); nada salió a cocina
        assert x["hechos"] == [["A", parte]] and x["srv"] == [["Mesa 6", queda, {"total": 2, "cobradas": 1}]] and x["impresos"] == [] and x["libre"] is True, (k, x)

    # antes de esta vuelta: «Dividir» se había abierto hace menos de 3 s y cobrarParte no traía la cuenta: la parte salía de la pantalla de antes (medio
    # Postre que B ya había quitado, o 1 Casado de más con el Casado bajado a 1) y se cobraba así
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for k in ("quita", "baja", "quita_sin", "baja_sin"):
        x = v[k]
        _, _, _, parte_antes, queda_antes = Z2[k.split("_")[0]]
        assert x["abierto"]["parte"] == parte_antes and x["hechos"] == [["A", parte_antes]] and x["srv"] == [["Mesa 6", queda_antes, {"total": 2, "cobradas": 1}]], (k, x)
        assert CAMBIO_M6 not in x["avisos"], (k, x)


def test_z2_un_solo_equipo_una_consulta_y_nada_mas_en_node(tmp_path):
    casos = CASOS_Z2.replace("@CASOS@", json.dumps([["solo", False], ["solo", True], ["lenta", False]]))
    r = _correr(tmp_path / "ahora", casos)
    TODO, MITAD = ["Casado×2", "Postre×1"], ["Casado×1", "Postre×0.5"]
    for k in ("solo", "solo_sin", "lenta"):
        x, a = r[k], r[k]["abierto"]
        # sin aviso; la parte 1 de 2 de la cuenta como está; se cobra una vez y en la Mesa 6 queda la otra mitad
        assert x["srvB"] == [["Mesa 6", TODO, None]] and a["avisos"] == [] and a["pago"] is True and a["parcial"] == [1, 2] and a["parte"] == MITAD, (k, x)
        assert x["hechos"] == [["A", MITAD]] and x["srv"] == [["Mesa 6", MITAD, {"total": 2, "cobradas": 1}]] and x["avisos"] == [] and x["impresos"] == [], (k, x)
    # con los platos enviados (lo de siempre en una mesa), UNA consulta y sin esperar; sin enviar, la de siempre de cobrarParte (quinta vuelta) y la de
    # esta vuelta; con la lista lenta, 1,5 s como mucho y se parte con la copia que hay. 4.39 (décima vuelta): las partes de una mesa van por cobrarParte,
    # que R1 no toca (sigue en 1,5 s)
    assert r["solo"]["abierto"]["consultas"] == 1 and r["solo"]["abierto"]["ms"] < 1000, r["solo"]
    assert r["solo_sin"]["abierto"]["consultas"] == 2 and r["solo_sin"]["abierto"]["ms"] < 1000, r["solo_sin"]
    assert r["lenta"]["abierto"]["consultas"] == 1 and 1400 <= r["lenta"]["abierto"]["ms"] < 2500, r["lenta"]

    # antes de esta vuelta: ninguna consulta con los platos enviados (la parte salía de la pantalla, aunque estuviera atrasada)
    v = _correr(tmp_path / "antes", CASOS_Z2.replace("@CASOS@", json.dumps([["solo", False]])), antes=_antes())
    assert v["solo"]["abierto"]["consultas"] == 0 and v["solo"]["hechos"] == [["A", MITAD]], v["solo"]


# ================================================================================================================ contrato
def test_contrato_de_la_novena_vuelta():
    # 4.39 (décima vuelta): «ahora» es caja.js sin la décima vuelta (la décima cambió las dos consultas del restaurante de confirmarDividir, que contaban
    # como REFRESCAR15, y agregó P1); lo de la décima está en tests/test_439_decima_vuelta.py
    k, k0 = _caja_sin_decima(), _caja_sin_novena()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de NOVENA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de confirmarDividir; el método cambió
    assert len(NOVENA) == 4
    for viejo, nuevo, veces in NOVENA:
        assert k.count(nuevo) == veces and k0.count(viejo) == veces and k0.count(nuevo) == 0 and k.count(viejo) == 0, nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de él, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (X2, Y3 y las partes de una mesa)
    assert k.count("4.39 (novena vuelta)") == 3 and k0.count("4.39 (novena vuelta)") == 0
    cd = metodos["async confirmarDividir() {"]
    # Z1 + Z3: las dos comparaciones usan la firma de UNA línea (lid, cantidad, envío, precio, descuento y nota); cada línea de la base tiene que estar en
    # el servidor (las que solo agregó otro equipo no cuentan) y el servicio tiene que ser el mismo; ya no queda la firma de la lista entera
    assert cd.count(FIRMA_LINEA) == 2 and FIRMA_ENV not in cd and ".sort().join('|')" not in cd
    x2 = ("const s2 = c2 ? new Set((ponerLids(JSON.parse(JSON.stringify(c2))).lineas || []).map(firma)) : null;",
          "if (!c2 || (this._base && this._base.id === id1 && ((this._base.lineas || []).some(l => !s2.has(firma(l))) || !!c2.servicio !== !!(this._base.cuenta || {}).servicio))) {")
    y3 = ("sv = new Set((ponerLids(JSON.parse(JSON.stringify(cx))).lineas || []).map(fm));",
          "if (this._base && this._base.id === idx && ((this._base.lineas || []).some(l => !sv.has(fm(l))) || !!cx.servicio !== !!(this._base.cuenta || {}).servicio)) {")
    for t in x2 + y3:
        assert cd.count(t) == 1, t
    # el orden de siempre: X6, la espera de la marca, X2 (después de traer la lista y si la cuenta ya no está, a sincronizar), Y3/Y4 (la caja de comercio trae
    # la lista; la cuenta que ya no está, a sincronizar), el turno de «Cobrar estos platos» y las partes (Z2: _alDia = 0 antes de cobrarParte)
    pasos = ["if (vistos.length) { if (ls.length) {", "const espero = ", "if (espero) {", REFRESCAR15, "const firma = l => " + FIRMA_LINEA + ", c2 = enEspera().find(v => v.id === id1);",
             "if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }", x2[0], x2[1], "return toast('" + CAMBIO_DIV + "', 'err'); }",
             "{ const idx = this.esperaId, bx = this._base;", "if (!this.esRestaurante) { " + REFRESCAR15,
             "const cx = enEspera().find(v => v.id === idx); if (!cx) { this.dividir = null; this.sincronizar(); return; }",
             "const fm = l => " + FIRMA_LINEA + ", " + y3[0], y3[1], "return toast('" + AVISO_Y3 + "', 'err'); }",
             "if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura", "if (d.modo === 'partes') {",
             "if (this.esRestaurante && this.mesaActual) { if (pre0 > 0) return toast(", "this._alDia = 0; return this.cobrarParte(n); }", "if (d.destino === 'nueva') {"]
    i = -1
    for p in pasos:                                                                 # cada paso después del anterior (REFRESCAR15 está tres veces)
        assert cd.find(p, i + 1) > i, p
        i = cd.find(p, i + 1)
    assert cd.count(REFRESCAR15) == 3 and cd.count("this.sincronizar(); return;") == 3
    assert cd.count("this._alDia = 0; return this.cobrarParte(n);") == 1 and "return this.cobrarParte(n); }   // 4.9" in cd
    # las notas de la versión cuentan la vuelta: la cuenta cobrada en otro equipo con y sin mesa, «Dividir» (la espera sola, el aviso de volver a abrir,
    # la cuenta cobrada entera, la cobrada en parte o cambiada, las partes iguales de una mesa) y el límite nuevo de «Cobrar estos platos»
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("sin mesa, como una venta rápida nueva que manda su comanda al cobrarla; en una mesa, como una cuenta nueva de esa mesa",
              "la caja espera sola unos segundos a que salga esa comanda", "sale el aviso de siempre (la cuenta fue cobrada o cerrada en otro equipo)",
              "o quitó o cambió un plato (cantidad, precio, descuento o nota)", "Las partes iguales de una mesa se calculan con la cuenta al día.",
              "se cobra lo elegido con la cuenta de antes (es así desde la 4.31)", "Novena vuelta: esa comparación"):
        assert notas.count(t) == 1, t
