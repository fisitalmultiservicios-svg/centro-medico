"""3.87, segunda ronda (r6_privacidad): privacidad en el servidor por puesto, sucursal y administrador del sistema.
- g6_documentos:F2: el Cajero lee de la caja (pos_cajas y pos_ventas) solo lo de su día: las sesiones abiertas y las abiertas o
  cerradas desde _desde_cajero(), con sus ventas, en /api/registros/{clave}, /api/registros, /api/arranque y en el 409 del PUT.
- g6_documentos:F3: quien está amarrado a una sucursal ve en /api/pagos (y por id) solo los cobros de los comprobantes de ella.
- extras:F1: Reportes › Ventas por sucursal y Ventas por bodega del amarrado, solo su sucursal.
- admin_sistema:F1/F2 y g2_salud:F1: el administrador del sistema limitado no ve sus empresas ocultas en IA ni en Pagos en línea, no
  usa ni ve una empresa oculta como «Empresa que factura» el plan y no entra a Publicidad (lista única de toda la plataforma).
- servicios-R4: el Técnico de soporte ve los contratos de TiKe y su consumo sin tarifas ni cuotas.
- extras:F7: dentro de una empresa, el administrador del sistema usa lo que el plan incluye (sin RRHH ni caja si el plan no los trae)
  y sigue dando soporte (configuración y respaldos).
Empresas y usuarios @example.test creados aquí y borrados al final."""
import json
import pathlib
import uuid
from datetime import datetime

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, factura_plan, main as M, publicidad as pub
from app.config import TZ_CR
from app.db import EMPRESAS_DIR, Empresa, Producto, engine, engine_empresa, init_db
from app.ia import UsoIA
from app.suscripcion import SuscripcionPago

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CLAVE = "Clave-larga-387-r6-privacidad"
LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]
TIQ = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "lineas": LINEAS}


def _js(*partes):
    return (RAIZ / "static" / "js" / pathlib.Path(*partes)).read_text(encoding="utf-8")


def _borrar_empresas(ids):
    from app.db import _engines
    for eid in ids:
        hit = _engines.pop(eid, None)
        if hit is not None:
            hit[0].dispose()
        for suf in ("", "-wal", "-shm"):
            (EMPRESAS_DIR / f"empresa_{eid}.db{suf}").unlink(missing_ok=True)


class Entorno:
    """Empresa de prueba con usuarios @example.test reales (token de sesión → contexto → sucursal fija); se borra al final."""

    def __init__(self, tipo="comercio"):
        init_db()
        self.suf = uuid.uuid4().hex[:6]
        with Session(engine) as s:
            e = Empresa(nombre=f"Privacidad R6 {self.suf} QA S.A.", numero_id="3101" + str(uuid.uuid4().int)[:6], actividad="471101",
                        otras_senas="Local de pruebas R6", correo=f"emp.r6.{self.suf}@example.test", ambiente="sandbox", tipo_negocio=tipo)
            s.add(e); s.commit(); s.refresh(e); s.expunge(e)
        self.e, self.c, self.uids, self.t = e, TestClient(M.app), [], {}

    def usuario(self, clave, rol, permisos_propios=None, sucursal_id=None):
        with Session(engine) as s:
            if permisos_propios is not None and not auth.rol_personalizado(s, self.e.id, rol):
                s.add(auth.RolEmpresa(empresa_id=self.e.id, nombre=rol, descripcion="QA", permisos=json.dumps(sorted(permisos_propios)))); s.commit()
            u = auth.Usuario(correo=f"{clave}.r6.{self.suf}@example.test", nombre=clave.capitalize(), password_hash=auth.hash_password(CLAVE),
                             terminos_version=auth.TERMINOS_VERSION, paleta="turquesa", mfa_activo=(rol == "Administrador"))
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=self.e.id, rol=rol, sucursal_id=sucursal_id)); s.commit()
            self.uids.append(u.id)
            self.t[clave] = auth._respuesta(s, u, self.e.id)["token"]
        return self.t[clave]

    def h(self, clave, **extra):
        return {"Authorization": "Bearer " + self.t[clave], **extra}

    def get(self, clave, path, **extra):
        return self.c.get(path, headers=self.h(clave, **extra))

    def emitir(self, clave, **cab):
        r = self.c.post("/api/comprobantes", json=TIQ, headers=self.h(clave, **cab))
        assert r.status_code == 200, r.text
        return r.json()

    def limpiar(self):
        with Session(engine) as s:
            for uid in self.uids:
                for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).all():
                    s.delete(m)
                for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid)).all():
                    s.delete(x)
                u = s.get(auth.Usuario, uid)
                if u:
                    s.delete(u)
            for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == self.e.id)).all():
                s.delete(r)
            for r in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == self.e.id)).all():
                s.delete(r)
            e = s.get(Empresa, self.e.id)
            if e:
                s.delete(e)
            s.commit()
        _borrar_empresas([self.e.id])


@pytest.fixture()
def ent():
    x = Entorno()
    try:
        yield x
    finally:
        x.limpiar()


def _ahora(monkeypatch, iso):
    """Fija la hora de Costa Rica que usan las reglas de lectura (main.ahora_cr)."""
    fijo = datetime.fromisoformat(iso).astimezone(TZ_CR)
    monkeypatch.setattr(M, "ahora_cr", lambda: fijo)


# ----------------------------------------------------------------------------- g6_documentos:F2 (Cajero y ventas de caja viejas)
def test_cajero_lee_de_la_caja_solo_lo_de_su_dia(ent, monkeypatch):
    ent.usuario("admin", "Administrador"); ent.usuario("cajero", "Cajero"); ent.usuario("vendedor", "Vendedor")
    h = ent.h("admin")
    cajas = [{"id": 1, "caja": "Caja 1", "terminal_id": 1, "estado": "Cerrada", "abierta_en": "2026-10-20T14:00:00.000Z", "cerrada_en": "2026-10-21T00:00:00.000Z",
              "ventas": [{"consecutivo": "00100001040000000009", "total": 55000, "cliente": "Cliente Viejo Incrustado QA"}]},
             {"id": 2, "caja": "Caja 2", "terminal_id": 2, "estado": "Cerrada", "abierta_en": "2026-11-04T14:00:00.000Z", "cerrada_en": "2026-11-05T06:20:00.000Z"},
             {"id": 3, "caja": "Caja 1", "terminal_id": 1, "estado": "Abierta", "abierta_en": "2026-11-05T04:00:00.000Z"},
             {"id": 4, "caja": "Caja 3", "terminal_id": 3, "estado": "Cerrada", "abierta_en": "2026-11-04T14:00:00.000Z", "cerrada_en": "2026-11-04T23:00:00.000Z"}]
    ventas = [{"id": 1, "caja_id": 1, "consecutivo": "00100001040000000001", "total": 87010, "cliente": "Cliente Secreto QA", "hora": "2026-10-20T16:06:51.000Z",
               "lineas": [{"detalle": "Casado", "cantidad": 1, "precio": 77000}]},
              {"id": 2, "caja_id": 2, "consecutivo": "00100001040000000002", "total": 3000, "hora": "2026-11-04T20:00:00.000Z"},    # 14:00 de ayer, sesión cerrada hoy
              {"id": 3, "caja_id": 3, "consecutivo": "00100001040000000003", "total": 4520, "hora": "2026-11-05T04:30:00.000Z"},    # 22:30 de ayer, su sesión abierta
              {"id": 4, "caja_id": 3, "consecutivo": "00100001040000000004", "total": 4520, "hora": "2026-11-05T15:00:00-06:00"},
              {"id": 5, "caja_id": 4, "consecutivo": "00100001040000000005", "total": 8800, "cliente": "Cliente de Ayer QA", "hora": "2026-11-04T21:00:00.000Z"}]
    assert ent.c.put("/api/registros/pos_cajas", json={"datos": cajas}, headers=h).status_code == 200
    assert ent.c.put("/api/registros/pos_ventas", json={"datos": ventas}, headers=h).status_code == 200
    _ahora(monkeypatch, "2026-11-05T16:30:00-06:00")
    ids = lambda r: {x["id"] for x in r}                                                       # noqa: E731
    for quien in ("admin", "vendedor"):                                                         # quien no es solo caja ve todo, como antes
        assert ids(ent.get(quien, "/api/registros/pos_ventas").json()["datos"]) == {1, 2, 3, 4, 5}
        assert ids(ent.get(quien, "/api/registros/pos_cajas").json()["datos"]) == {1, 2, 3, 4}
    r = ent.get("cajero", "/api/registros/pos_ventas")
    assert r.status_code == 200 and ids(r.json()["datos"]) == {2, 3, 4}, r.json()["datos"]      # su sesión abierta completa y la cerrada hoy
    assert "Cliente Secreto QA" not in r.text and "Cliente de Ayer QA" not in r.text
    cj = ent.get("cajero", "/api/registros/pos_cajas")
    assert ids(cj.json()["datos"]) == {2, 3} and "Cliente Viejo Incrustado QA" not in cj.text   # el Z viejo (con sus ventas incrustadas), no
    arr = ent.get("cajero", "/api/arranque").json()["registros"]
    assert ids(arr["datos"]["pos_ventas"]) == {2, 3, 4} and ids(arr["datos"]["pos_cajas"]) == {2, 3}
    assert "pos_ventas" not in arr["parciales"]                                                 # lo suyo está completo: Cierres no lo pide otra vez
    v2 = ent.get("cajero", "/api/registros?v=2").json()["datos"]
    v0 = ent.get("cajero", "/api/registros").json()
    assert ids(v2["pos_ventas"]) == ids(v0["pos_ventas"]) == {2, 3, 4} and ids(v0["pos_cajas"]) == {2, 3}
    r = ent.c.put("/api/registros/pos_ventas", json={"datos": [], "version": 0}, headers=ent.h("cajero"))   # el 409 trae lo guardado: también recortado
    assert r.status_code == 409 and ids(r.json()["detail"]["datos"]) == {2, 3, 4}, r.text
    assert ids(ent.get("admin", "/api/registros/pos_ventas").json()["datos"]) == {1, 2, 3, 4, 5}   # nada se borró
    _ahora(monkeypatch, "2026-11-06T00:40:00-06:00")                                           # de madrugada: el turno que cruzó la medianoche
    assert ids(ent.get("cajero", "/api/registros/pos_ventas").json()["datos"]) == {3, 4}
    assert ids(ent.get("cajero", "/api/registros/pos_cajas").json()["datos"]) == {3}


def test_cajero_sigue_cerrando_y_anulando_en_su_sesion(ent, monkeypatch):
    """Lo que la caja escribe sigue igual con la copia recortada: las colecciones se suben por diferencias (sin tocar lo viejo)."""
    ent.usuario("admin", "Administrador"); ent.usuario("cajero", "Cajero")
    _ahora(monkeypatch, "2026-11-05T10:30:00-06:00")
    cajas = [{"id": 1, "caja": "Caja 1", "estado": "Cerrada", "abierta_en": "2026-10-20T14:00:00.000Z", "cerrada_en": "2026-10-21T00:00:00.000Z"},
             {"id": 2, "caja": "Caja 1", "estado": "Abierta", "abierta_en": "2026-11-05T14:00:00.000Z"}]
    ventas = [{"id": 1, "caja_id": 1, "total": 87010, "hora": "2026-10-20T16:06:51.000Z"}, {"id": 2, "caja_id": 2, "total": 4520, "hora": "2026-11-05T15:00:00.000Z"}]
    assert ent.c.put("/api/registros/pos_cajas", json={"datos": cajas}, headers=ent.h("admin")).status_code == 200
    assert ent.c.put("/api/registros/pos_ventas", json={"datos": ventas}, headers=ent.h("admin")).status_code == 200
    hc = ent.h("cajero")
    r = ent.c.post("/api/registros/pos_ventas/cambios", json={"upserts": [{**ventas[1], "anulada": True, "anulada_hora": "2026-11-05T16:00:00.000Z",
                                                                           "anulada_por": "cajero", "motivo_anulacion": "QA"}], "deletes": [], "nuevos": []}, headers=hc)
    assert r.status_code == 200, r.text
    r = ent.c.post("/api/registros/pos_cajas/cambios", json={"upserts": [{**cajas[1], "estado": "Cerrada", "cerrada_en": "2026-11-05T16:20:00.000Z", "conteo": 0}],
                                                             "deletes": [], "nuevos": []}, headers=hc)
    assert r.status_code == 200, r.text
    todo = ent.get("admin", "/api/registros/pos_cajas").json()["datos"]
    assert [c["estado"] for c in sorted(todo, key=lambda c: c["id"])] == ["Cerrada", "Cerrada"] and len(ent.get("admin", "/api/registros/pos_ventas").json()["datos"]) == 2
    assert {c["id"] for c in ent.get("cajero", "/api/registros/pos_cajas").json()["datos"]} == {2}   # su cierre de hoy lo sigue viendo


# ----------------------------------------------------------------------------- sucursal fija (g6_documentos:F3 y extras:F1)
def _con_sucursal_002(ent):
    """Principal (001) con 2 tiquetes y sucursal 002 (con su bodega) con 3; vendedor y cajero amarrados a 002 y un vendedor libre."""
    ent.usuario("admin", "Administrador")
    h = ent.h("admin")
    bn = ent.c.post("/api/inventario/bodegas", json={"nombre": "Bodega Norte R6"}, headers=h).json()
    ent.get("admin", "/api/sucursales")
    s2 = ent.c.post("/api/sucursales", json={"codigo": 2, "nombre": "Norte R6", "bodega_id": bn["id"]}, headers=h).json()
    ent.usuario("vend2", "Vendedor", sucursal_id=s2["id"]); ent.usuario("caja2", "Cajero", sucursal_id=s2["id"]); ent.usuario("vendedor", "Vendedor")
    p1 = [ent.emitir("admin") for _ in range(2)]
    p2 = [ent.emitir("admin", **{"X-Sucursal": str(s2["id"])}) for _ in range(3)]
    assert all(d["consecutivo"].startswith("001") for d in p1) and all(d["consecutivo"].startswith("002") for d in p2)
    return bn, s2, p1, p2


def test_sucursal_fija_no_ve_cobros_de_otra_sucursal(ent):
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    hoy = M.ahora_cr().date().isoformat()

    def cobrar(clave, monto, d=None):
        r = ent.c.post("/api/pagos", json={"tipo": "caja", "fecha": hoy, "medio_pago": "01", "monto": monto, "detalles": f"Cobro QA {monto}",
                                           "facturas": [{"id": d["id"], "monto": monto}] if d else []}, headers=ent.h(clave))
        assert r.status_code == 200, r.text
        return r.json()

    tiq2 = ent.emitir("caja2")
    assert tiq2["consecutivo"].startswith("002")
    de001 = cobrar("admin", 1001, p1[0]); cobrar("admin", 1002, p2[0]); cobrar("admin", 1003); cobrar("vend2", 1004); cobrar("caja2", 500, tiq2)
    montos = lambda clave, **cab: sorted(p["monto"] for p in ent.get(clave, "/api/pagos", **cab).json())  # noqa: E731
    assert montos("vend2") == [500, 1002, 1004]                    # 002 y su anticipo; no el de 001 ni el anticipo de otro
    assert not any(f["consecutivo"].startswith("001") for p in ent.get("vend2", "/api/pagos").json() for f in p["facturas"] if f.get("consecutivo"))
    assert montos("vendedor") == montos("admin") == [500, 1001, 1002, 1003, 1004]   # el vendedor libre y el administrador ven todo
    assert montos("admin", **{"X-Sucursal": str(s2["id"])}) == [500, 1001, 1002, 1003, 1004]   # elegir en la barra no limita
    assert montos("caja2") == [500]                                # el Cajero sigue viendo sus cobros de hoy
    assert ent.c.put(f"/api/pagos/{de001['id']}/estado", json={"estado": "Conciliado"}, headers=ent.h("vend2")).status_code == 404   # ni por id
    assert ent.c.delete(f"/api/pagos/{de001['id']}", headers=ent.h("vend2")).status_code == 404
    assert ent.c.put(f"/api/pagos/{de001['id']}/estado", json={"estado": "Conciliado"}, headers=ent.h("vendedor")).status_code == 200


def test_amarrado_ve_solo_su_sucursal_en_ventas_por_sucursal_y_por_bodega(ent):
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    ent.usuario("conta2", "Contador", sucursal_id=s2["id"]); ent.usuario("conta", "Contador")
    hoy = M.ahora_cr().date().isoformat()
    docs = lambda filas: sum(f["documentos"] for f in filas)       # noqa: E731
    v = ent.get("conta2", "/api/sucursales/ventas").json()["filas"]
    assert [(f["codigo"], f["documentos"]) for f in v] == [("002", 3)], v
    assert docs(ent.get("conta2", f"/api/inventario/ventas-por-bodega?desde={hoy}&hasta={hoy}").json()["filas"]) == 3
    assert docs(ent.get("conta", "/api/sucursales/ventas").json()["filas"]) == 5                       # sin amarrar: consolidado
    assert docs(ent.get("admin", "/api/sucursales/ventas", **{"X-Sucursal": str(s2["id"])}).json()["filas"]) == 5
    assert docs(ent.get("conta", f"/api/inventario/ventas-por-bodega?desde={hoy}&hasta={hoy}").json()["filas"]) == 5


def test_amarrado_ve_solo_su_sucursal_en_el_resumen_con_ia(ent, monkeypatch):
    from app import ia
    monkeypatch.setattr(ia, "_exigir", lambda s, e, uso: {})                       # sin llave de IA en las pruebas: se mira lo que se le manda
    monkeypatch.setattr(ia, "_llamar", lambda sistema, mensajes, **k: ("Resumen QA", {}))
    monkeypatch.setattr(ia, "_registrar_uso", lambda *a, **k: None)
    bn, s2, p1, p2 = _con_sucursal_002(ent)
    ent.usuario("conta2", "Contador", sucursal_id=s2["id"]); ent.usuario("conta", "Contador")
    datos = lambda clave: ent.c.post("/api/ia/resumen", json={}, headers=ent.h(clave)).json()["datos"][0]   # noqa: E731
    assert "Comprobantes de venta válidos: 3 " in datos("conta2")                  # antes: los 5 de las dos sucursales
    assert "Comprobantes de venta válidos: 5 " in datos("conta")


# ----------------------------------------------------------------------------- consola: administrador del sistema limitado
P_CORREO, L_CORREO = "principal.r6priv@example.test", "limitado.r6priv@example.test"
N_V, N_O = "R6 Visible Privacidad QA", "R6 Oculta Privacidad QA"


def _usuario(correo_):
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo_)).first()
        if u:
            s.expunge(u)
        return u


def _como(correo_):
    M.app.dependency_overrides[auth.solo_usuario] = lambda: _usuario(correo_)


@pytest.fixture
def consola():
    init_db()
    fp_antes = factura_plan.leer_config()
    with Session(engine) as s:
        ev = auth.crear_empresa(s, N_V, "visible.r6priv@example.test", "3101386601").id
        eo = auth.crear_empresa(s, N_O, "oculta.r6priv@example.test", "3101386602").id
        for c_, princ in ((P_CORREO, True), (L_CORREO, False)):
            s.add(auth.Usuario(correo=c_, nombre=c_.split("@")[0], password_hash=auth.hash_password(CLAVE), es_superadmin=True, admin_principal=princ,
                               mfa_activo=True, debe_cambiar_password=False, terminos_version=auth.TERMINOS_VERSION,
                               empresas_ocultas=json.dumps([eo]) if c_ == L_CORREO else "[]"))
        for eid in (ev, eo):
            s.add(UsoIA(empresa_id=eid, tipo="catalogo", modelo="qa", tokens_entrada=10, tokens_salida=5))
            s.add(SuscripcionPago(empresa_id=eid, monto=19900, correo=f"pago.{eid}.r6priv@example.test", estado="activa"))
        s.commit()
    _como(P_CORREO)
    try:
        yield TestClient(M.app), ev, eo
    finally:
        M.app.dependency_overrides.pop(auth.solo_usuario, None)
        if fp_antes:
            factura_plan.guardar_config(fp_antes)
        else:
            factura_plan.ARCHIVO.unlink(missing_ok=True)
        with Session(engine) as s:
            for x in s.exec(select(UsoIA).where(UsoIA.empresa_id.in_([ev, eo]))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(SuscripcionPago).where(SuscripcionPago.empresa_id.in_([ev, eo]))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(pub.PubContacto).where(pub.PubContacto.correo.like("%r6priv@example.test"))).all():  # type: ignore[attr-defined]
                s.delete(x)
            ids = [u.id for u in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_((P_CORREO, L_CORREO)))).all()]  # type: ignore[attr-defined]
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id.in_(ids))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(auth.Auditoria).where(auth.Auditoria.usuario_id.in_(ids))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(auth.Usuario).where(auth.Usuario.id.in_(ids))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for eid in (ev, eo):
                e = s.get(Empresa, eid)
                if e:
                    s.delete(e)
            s.commit()
        _borrar_empresas([ev, eo])


def _producto(eid, nombre, precio):
    with Session(engine_empresa(eid)) as se:
        p = Producto(empresa_id=eid, nombre=nombre, cabys="4525000000000", precio=precio, es_venta=True, activo=True)
        se.add(p); se.commit(); se.refresh(p)
        return p.id


def test_ia_y_pagos_en_linea_sin_empresas_ocultas(consola):
    c, ev, eo = consola
    _como(L_CORREO)
    uso = c.get("/api/admin/ia/uso"); assert uso.status_code == 200, uso.text
    ids = [x["empresa_id"] for x in uso.json()["empresas"]]
    assert ev in ids and eo not in ids and N_O not in uso.text
    su = c.get("/api/admin/suscripciones"); assert su.status_code == 200, su.text
    ids = [x["empresa_id"] for x in su.json()]
    assert ev in ids and eo not in ids and N_O not in su.text and f"pago.{eo}.r6priv@example.test" not in su.text
    assert c.post(f"/api/admin/suscripciones/{eo}/sincronizar").status_code == 404
    _como(P_CORREO)
    assert {ev, eo} <= {x["empresa_id"] for x in c.get("/api/admin/ia/uso").json()["empresas"]}
    assert {ev, eo} <= {x["empresa_id"] for x in c.get("/api/admin/suscripciones").json()}


def test_factura_del_plan_no_usa_ni_muestra_una_empresa_oculta(consola):
    c, ev, eo = consola
    po, pv = _producto(eo, "Servicio secreto r6priv", 99000), _producto(ev, "Plan visible r6priv", 15000)
    _como(L_CORREO)
    assert c.get(f"/api/admin/factura-plan/items?empresa_id={eo}").status_code == 404
    r = c.put("/api/admin/factura-plan", json={"activo": False, "empresa_id": eo, "producto_id": None, "cuenta": ""})
    assert r.status_code == 404 and "Servicio secreto" not in r.text
    r = c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": eo, "producto_id": po, "cuenta": ""})
    assert r.status_code == 404 and factura_plan.leer_config().get("empresa_id") != eo
    _como(P_CORREO)
    assert c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": eo, "producto_id": po, "cuenta": "Banco secreto"}).status_code == 200
    _como(L_CORREO)
    g = c.get("/api/admin/factura-plan"); assert g.status_code == 200
    assert g.json()["empresa_id"] is None and g.json()["items"] == [] and g.json()["oculta"] is True
    assert "Servicio secreto" not in g.text and "Banco secreto" not in g.text and g.json()["producto_id"] is None
    r = c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": ev, "producto_id": pv, "cuenta": ""})
    assert r.status_code == 403
    assert factura_plan.leer_config()["empresa_id"] == eo and factura_plan.leer_config()["producto_id"] == po
    _como(P_CORREO)
    g = c.get("/api/admin/factura-plan").json()
    assert g["empresa_id"] == eo and [i["nombre"] for i in g["items"]] == ["Servicio secreto r6priv"] and not g.get("oculta")
    assert c.put("/api/admin/factura-plan", json={"activo": False, "empresa_id": None, "producto_id": None, "cuenta": ""}).status_code == 200
    _como(L_CORREO)                                                                     # con una visible (o vacía) el limitado sí la configura
    r = c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": ev, "producto_id": pv, "cuenta": ""})
    assert r.status_code == 200 and r.json()["empresa_id"] == ev and [i["nombre"] for i in r.json()["items"]] == ["Plan visible r6priv"]
    assert c.get("/api/admin/factura-plan").json()["empresa_id"] == ev


def test_publicidad_solo_para_quien_ve_todas_las_empresas(consola):
    c, ev, eo = consola
    with Session(engine) as s:
        s.add(pub.PubContacto(correo="adm.oculta.r6priv@example.test", nombre="Admin Oculta", empresa=N_O, etiquetas="clientes", origen="plataforma"))
        s.commit()
    assert any(x["correo"] == "adm.oculta.r6priv@example.test" for x in c.get("/api/admin/publicidad/contactos").json())   # el super administrador sí
    _como(L_CORREO)
    for metodo, ruta in (("get", "/api/admin/publicidad/contactos"), ("get", "/api/admin/publicidad/resumen"), ("get", "/api/admin/publicidad/campanas"),
                         ("get", "/api/admin/publicidad/config"), ("post", "/api/admin/publicidad/contactos/importar-clientes"),
                         ("delete", "/api/admin/publicidad/contactos/1")):
        r = getattr(c, metodo)(ruta)
        assert r.status_code == 403 and N_O not in r.text and "ve todas las empresas" in r.json()["detail"], (ruta, r.status_code, r.text)
    with Session(engine) as s:                                                          # la oculta ya no existe: deja de contar
        s.delete(s.get(Empresa, eo)); s.commit()
    assert c.get("/api/admin/publicidad/contactos").status_code == 200
    ui = _js("pages", "admin-publicidad.js")
    assert "if (e.status === 403) { this.bloqueado = e.message; return; }" in ui and '<div class="card" v-if="bloqueado">' in ui
    adm = _js("pages", "admin.js")
    assert "oculta: !!fp.oculta" in adm and 'v-if="fpForm && fpForm.oculta"' in adm and 'v-if="fpForm && !fpForm.oculta"' in adm


# ----------------------------------------------------------------------------- servicios-R4 (TiKe sin montos para el Técnico de soporte)
def test_tecnico_de_soporte_ve_contratos_sin_tarifas_ni_cuotas():
    ent = Entorno("servicios")
    try:
        ent.usuario("admin", "Administrador"); ent.usuario("tecnico", "Técnico de soporte", permisos_propios=["tike"])
        h = ent.h("admin")
        cli = ent.c.post("/api/clientes", json={"nombre": "Clínica R6 QA", "tipo_id": "02", "numero_id": "3101386698", "correo": "clinica.r6priv@example.test"}, headers=h).json()
        r = ent.c.post("/api/tike/contratos", json={"cliente_id": cli["id"], "nombre": "Bolsa R6", "tipo": "horas", "cantidad": 2, "periodo": "mensual", "tarifa_hora": 20000,
                                                    "tarifa_visita": 5000, "cuota": 50000, "inicio": "2026-01-01", "facturar_cuota": False}, headers=h)
        assert r.status_code == 200, r.text
        cid = r.json()["id"]
        assert ent.get("admin", "/api/tike/contratos").json()[0]["cuota"] == 50000                     # quien factura sí los ve
        lista = ent.get("tecnico", "/api/tike/contratos")
        assert lista.status_code == 200 and lista.json()[0]["consumo"] is not None and lista.json()[0]["vigente"] is True
        assert {k: lista.json()[0][k] for k in ("tarifa_hora", "tarifa_visita", "cuota")} == {"tarifa_hora": None, "tarifa_visita": None, "cuota": None}
        uno = ent.get("tecnico", f"/api/tike/contratos/{cid}").json()
        assert uno["tarifa_hora"] is None and uno["cuota"] is None and "tickets" in uno
        rep = ent.get("tecnico", "/api/tike/reportes?desde=2026-01-01&hasta=2099-12-31").json()
        assert rep["contratos"] and all(x["cuota"] is None for x in rep["contratos"])
        assert ent.get("admin", "/api/tike/reportes?desde=2026-01-01&hasta=2099-12-31").json()["contratos"][0]["cuota"] == 50000
    finally:
        ent.limpiar()


# ----------------------------------------------------------------------------- extras:F7 (el administrador del sistema y el plan)
def test_administrador_del_sistema_usa_lo_que_el_plan_incluye():
    init_db()
    suf = uuid.uuid4().hex[:6]
    correo = f"sa.plan.{suf}.r6priv@example.test"
    with Session(engine) as s:
        sin = auth.crear_empresa(s, f"Fac sin RRHH R6 {suf}", f"sin.rrhh.{suf}@example.test", tipo_negocio="facturacion")
        sin.plan = "fac_basico"; s.add(sin)
        con = auth.crear_empresa(s, f"Fac con RRHH R6 {suf}", f"con.rrhh.{suf}@example.test", tipo_negocio="facturacion")
        con.plan = "fac_250"; con.extras = json.dumps(["rrhh"]); s.add(con)
        s.commit(); s.refresh(sin); s.refresh(con)
        u = auth.Usuario(correo=correo, nombre="SA plan QA", password_hash=auth.hash_password(CLAVE), es_superadmin=True,
                         mfa_activo=True, terminos_version=auth.TERMINOS_VERSION, paleta="turquesa")
        s.add(u); s.commit(); s.refresh(u)
        t_sin, t_con = auth._respuesta(s, u, sin.id)["token"], auth._respuesta(s, u, con.id)["token"]
        ids = (sin.id, con.id)
    emp = {"nombre": "E", "apellidos": "C", "salario_mensual": 500000, "modo_salario": "mensual", "jornada": "diurna", "horas_semana": 48,
           "aplica_renta": True, "fecha_ingreso": "2024-01-15"}
    try:
        c = TestClient(M.app)
        h = lambda t: {"Authorization": "Bearer " + t}                                             # noqa: E731
        r = c.post("/api/rrhh/calcular", json={"empleado": emp}, headers=h(t_sin))
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo", r.text      # antes: 200 con el cálculo
        assert c.get("/api/rrhh/parametros", headers=h(t_sin)).status_code == 403
        assert c.get("/api/asistencia/config", headers=h(t_sin)).status_code == 403
        r = c.get("/api/cupones", headers=h(t_sin))                                                # caja: el plan de facturación no la trae
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo", r.text
        assert c.post("/api/rrhh/calcular", json={"empleado": emp}, headers=h(t_con)).status_code == 200   # con el extra, sí
        assert c.get("/api/asistencia/config", headers=h(t_con)).status_code == 200
        for t in (t_sin, t_con):                                                                   # el soporte sigue: empresa, respaldos y la sesión
            assert c.get("/api/empresa", headers=h(t)).status_code == 200
            assert c.get("/api/respaldos", headers=h(t)).status_code == 200
        perm = set(c.get("/api/auth/yo", headers=h(t_sin)).json()["permisos"])
        assert {"configurar", "usuarios", "facturar"} <= perm and not ({"rrhh", "pos"} & perm)   # lo mismo que ya veía la interfaz
        from app import planes
        with Session(engine) as s:                                                                 # Contexto.puede: la misma regla
            e_sin = s.get(Empresa, ids[0])
            ctx = auth.Contexto(s.get(auth.Usuario, u.id), e_sin, "Administrador", permisos=planes.filtrar_permisos(e_sin, set(auth.PERMISOS)))
            assert ctx.puede("configurar") and ctx.puede("tike_claves") and not ctx.puede("rrhh") and not ctx.puede("pos")
            assert set(auth.PERMISOS) - planes.filtrar_permisos(Empresa(plan="fac_basico", tipo_negocio="facturacion"), set(auth.PERMISOS)) <= auth.PERMISOS_MODULO
    finally:
        with Session(engine) as s:
            uu = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uu.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Auditoria).where(auth.Auditoria.usuario_id == uu.id)).all():
                s.delete(x)
            s.delete(uu)
            for eid in ids:
                e = s.get(Empresa, eid)
                if e:
                    s.delete(e)
            s.commit()
        _borrar_empresas(ids)
