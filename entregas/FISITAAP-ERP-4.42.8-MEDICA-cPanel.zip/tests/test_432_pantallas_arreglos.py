# -*- coding: utf-8 -*-
"""4.32, B7 (pantallas): arreglos de la revisión.

- _estacion.js: en el programa con pedidos_programa, la pasada pide los pendientes al menos cada 60 s aunque no haya indicio (así el programa
  dice estacion_viva y la web le asigna pedidos); en la web y sin la bandera, como la 4.31.
- app.js: la franja de la sincronización también con sinc_pantallas (en pausa y en la página web) y solo para quien configura; las comandas
  que esperan su hora no cuentan como «sin imprimir».
- fis/pages/pedidos.js: aceptar en la web un pedido que atiende el programa no intenta imprimir ni avisa en rojo; en el programa no se
  ofrece «Aceptar» en un pedido ya confirmado.
- pages/sinc/pisados.js y app/sinc_pantallas.py: se ve el valor que no quedó (nunca el de un campo delicado), sin el detalle crudo de los
  choques ni el nombre interno del campo."""
import json

from tests.test_425_ultimos_pantallas import _js, _node
from tests.test_431_estacion_pantallas import ARCHIVOS, BASE, _falsos
from tests.test_432_pantallas_franja import _correr
from tests.test_432_pantallas_pedidos import MONTAR_PED, _falsos as _falsos_ped


# ================================================================================================================ _estacion.js (latido)
def test_estacion_del_programa_pide_pendientes_cada_60_s_sin_indicio(tmp_path):
    r = _node(tmp_path, BASE + """
const E = await import('./js/pages/pos/_estacion.js');
const out = {}, real = Date.now;
const rutas = () => Q.llamadas.map(x => x.split(' ')[0]);
Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: true };
S.copias = {}; Q.espera = [];
limpiar(); E._reiniciar(); out.primera = [await E.pasoDesdeApp(), rutas()];
limpiar(); out.segunda = [await E.pasoDesdeApp(), rutas()];
Date.now = () => real() + 61000; limpiar(); out.minuto = [await E.pasoDesdeApp(), rutas()]; Date.now = real;
limpiar(); E._reiniciar(); out.caja = [await E.revisarEstacion('caja'), rutas()];
Q.sesion.empresaInfo = { es_local: false, numero_id: '1' };
limpiar(); E._reiniciar(); out.web = [await E.revisarEstacion('caja'), rutas()];
Q.sesion.empresaInfo = { es_local: true, numero_id: '1', pedidos_programa: false };
limpiar(); E._reiniciar(); out.sin_bandera = [await E.revisarEstacion('caja'), rutas()];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["primera"] == ["sin_directos", ["/api/pedidos/resumen", "/api/pos/comanda/pendientes"]], r
    assert r["segunda"] == ["sin_indicio", ["/api/pedidos/resumen"]], r            # dentro del minuto: sin consulta de más
    assert r["minuto"] == ["sin_directos", ["/api/pedidos/resumen", "/api/pos/comanda/pendientes"]], r
    assert r["caja"] == ["sin_directos", ["/api/pos/comanda/pendientes"]], r       # la Caja abierta también lo hace
    assert r["web"] == ["sin_indicio", []] and r["sin_bandera"] == ["sin_modulo", []], r


# ================================================================================================================ app.js (franja)
def test_franja_con_sinc_pantallas_en_pausa_y_en_la_web(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { es_local: true, sinc_pantallas: true };
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 3, ventas: 0, pausa: true, sin_ver: 0, choques: 0 };
F.vigilarFranja(); await esperar();
out.pausa = [Q.store.franja, Q.timers.slice()];
F.pararFranja(); await esperar();
Q.sesion.empresaInfo = { es_local: false, sinc_pantallas: true }; Q.timers = []; Q.llamadas = [];
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 0, ventas: 0, pausa: false, sin_ver: 2, choques: 0 };
F.vigilarFranja(); await esperar();
out.web = [Q.store.franja, Q.llamadas.slice()];
""")
    assert r["pausa"][0]["pausa"].startswith("Este programa no puede enviar") and r["pausa"][1] == [30000], r
    assert r["web"][0]["sinVer"] == "Hay 2 cambios que no quedaron: " and r["web"][1] == ["/api/sinc/datos/franja"], r


def test_franja_no_consulta_para_quien_no_configura(tmp_path):
    r = _correr(tmp_path, """
Q.cajero = true;
Q.sesion.empresaInfo = { es_local: true, datos_v2: true, sinc_pantallas: true };
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 2, ventas: 1, pausa: false, sin_ver: 3, choques: 0 };
F.vigilarFranja(); await esperar(); await F.franjaTick();
out.cajero = [Q.llamadas.slice(), Q.timers.slice(), Q.store.franja];
""")
    assert r["cajero"] == [[], [], None], r


def test_comandas_que_esperan_su_hora_no_cuentan(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { pedidos_programa: true };
let espera = 600; Q.respuestas['/api/pedidos/resumen'] = () => ({ comandas_pendientes: 2, comanda_espera_s: espera });
await F.franjaTick(); out.espera = [Q.store.franja, Q.sonidos];
const E = await import('./js/pages/pos/_estacion.js');
E.estadoEstacion.resumen = { comandas_pendientes: 3, comanda_espera_s: 300, hora: Date.now() };
await F.franjaTick(); out.estacion = [Q.store.franja, Q.sonidos];
E.estadoEstacion.resumen = null; espera = 0;
await F.franjaTick(); out.lista = [Q.store.franja && Q.store.franja.comandas, Q.sonidos];
""")
    assert r["espera"] == [None, 0] and r["estacion"] == [None, 0], r
    assert r["lista"] == ["Hay 2 comandas de pedidos sin imprimir: abra la Caja.", 1], r


def test_banderas_de_instalacion_local_y_cajas():
    inst = _js("pages/configuracion/instalacion-local.js")
    assert "verPisados() { return !!(sesion.empresaInfo && (sesion.empresaInfo.datos_v2 || sesion.empresaInfo.sinc_pantallas)); }" in inst
    cfg = _js("pages/pos/configuracion.js")
    assert "cajasEnWeb() { return this.esPrograma && !!(sesion.empresaInfo && (sesion.empresaInfo.datos_v2 || sesion.empresaInfo.sinc_pantallas)); }" in cfg
    app = _js("app.js")
    assert "export const conFranjaSinc = info => !!(info && (info.datos_v2 || info.sinc_pantallas) && sesion.puede('configurar'));" in app


# ================================================================================================================ fis/pages/pedidos.js
SERVIDOR_PED = r"""
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method || 'GET') + ' ' + url + (opt && opt.body ? ' ' + JSON.stringify(opt.body) : ''));
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) return Q.respEstado;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias' || url === '/api/registros/items_extra') return { datos: [] };
  if (url.startsWith('/api/productos')) return [];
  if (url.startsWith('/api/pos/comanda/pendientes')) return { copias: [], ahora: new Date().toISOString() };
  throw new Error('llamada inesperada ' + url);
};
"""


def test_web_aceptar_un_pedido_que_atiende_el_programa_no_imprime_ni_avisa_en_rojo(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + SERVIDOR_PED + r"""
const out = {};
sesionPara({ es_local: false }, { negocio: { terminal_id: 1, activo: true, atiende_terminal: 4 } });
const vm = montar(); await vm.cargarImpresion();
out.conComanda = vm.conComanda;
Q.respEstado = { id: 21, numero: 9, estado: 'confirmado', atiende: 4, atiende_nombre: 'Caja 2' };
limpiar(); await vm.aceptar({ id: 21, numero: 9, estado: 'nuevo' });
out.programa = [Q.toasts, Q.llamadas.filter(x => x.includes('/comanda/'))];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos_ped())
    assert r["conComanda"] is True, r                                               # el botón prometía imprimir la comanda
    assert r["programa"] == [[["Pedido aceptado: lo atiende «Caja 2»; su comanda sale allá.", "ok"]], []], r


def test_programa_no_ofrece_aceptar_un_pedido_ya_confirmado():
    t = _js("fis/pages/pedidos.js").split("template: `")[1]
    # validación 4.32: la condición va en el propio <form> (sin <template> envolvente) para que «Abrir monitor», «Marcar entregado»,
    # «Asignar a Express» y «Entregar» sigan colgando de él con v-else-if, como en la 4.31
    assert "!f.p.cuenta_espera_id && !f.p.documento_id)) && (!enProg || f.estado === 'nuevo')\" @submit.prevent=\"aceptar(f.p)\">" in t   # en el programa, solo el pedido nuevo
    assert "data-confirmando>Confirmando con la página web…</small></form>\n            <a v-else-if=\"menu && " in t
    assert "<template v-if=\"!enProg || f.estado === 'nuevo'\">" not in t


# ================================================================================================================ pisados
def test_pisados_muestra_el_valor_que_no_quedo_sin_crudos(tmp_path):
    pis = _js("pages/sinc/pisados.js")
    t = pis.split("template:")[1]
    assert "<th>Lo que no quedó</th>" in t and "{{valorPerdido(p.perdio) || '—'}}" in t
    assert "{{c.detalle}}" not in t and "{{p.campo}}" not in t and "v-html" not in t
    r = _node(tmp_path, """
const P = await import('./js/pages/sinc/pisados.js');
const v = P.valorPerdido;
console.log(JSON.stringify([v(['1500']), v([{ precio: 1500, activo: true, x: null }]), v({ nombre: 'Casado', notas: { a: 1 } }), v(null), v([]), v(['a', 'b']), v(false)]));
process.exit(0);
""", archivos=("pages/sinc/pisados.js",), falsos={"api.js": "export const api = () => null, toast = () => null, fechaHora = v => v;\n", "app.js": "export const sesion = {};\n"})
    assert r == ["1500", "precio: 1500 · activo: Sí", "nombre: Casado", "", "", "a, b", "No"], r


def test_pisados_no_devuelve_el_valor_de_un_campo_delicado():
    from app.sinc_pantallas import _fila
    def fila(campo, perdio):
        return (1, "2026-11-13T10:00:00", "caja", "1", "Caja 1", campo, "conflicto", perdio, "Caja 1", "la página web", 0)
    assert _fila(fila("clave_supervisor", json.dumps(["x1y2"])))["perdio"] is None
    assert _fila(fila("pin_cajero", json.dumps({"a": 1})))["perdio"] is None
    assert _fila(fila("precio", json.dumps(["1500"])))["perdio"] == ["1500"]
    assert _fila(fila("", json.dumps({"nombre": "Casado", "clave": "x"})))["perdio"] == {"nombre": "Casado"}
