"""3.74: FISITAAP embebido tal cual. La aplicación de FISITAAP en /app/fisitaap/ con sus hojas de estilo originales; sus pantallas usan
el ERP y, para lo propio, /api/fisitaap/*: resumen y KPIs, configurador, contactos de la página, promociones por producto, extras y
opcionales asignables a productos y categorías, combos (ítem Combo + ficha técnica), ajustes y diseño de la página. El ERP solo
cambia el menú (cajón) y la entrada FISITAAP, que abre la aplicación; la página pública usa el diseño de FISITAAP."""
import io

from sqlmodel import Session

from app import modulos, promociones
from app.config import BASE_DIR
from app.db import Producto, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_pedidos import _eid, _productos, _publicar


def _static(*partes):
    return io.open(BASE_DIR.joinpath("app", "static", *partes), encoding="utf-8").read()


def test_aplicacion_fisitaap_servida_y_erp_con_cajon(api):  # noqa: F811
    c = api
    html = c.get("/app/fisitaap/").text
    assert 'class="admin-body r14-app r14-admin r15-app" data-design="fusion"' in html and "/js/fis/app.js" in html and "/fisitaap/assets/linea-reference-r15.css" in html
    for hoja in ("app.bundle.css", "v12.css", "interface-r15.css", "linea-reference-r15.css", "qa180.css", "fisichat.css"):
        r = c.get("/fisitaap/assets/" + hoja); assert r.status_code == 200 and len(r.text) > 500, hoja
    assert c.get("/fisitaap/assets/fisitapp-logo.webp").status_code == 200
    for m in ("app.js", "sesion.js", "ui.js"):
        assert c.get("/js/fis/" + m).status_code == 200
    for p in ("resumen", "bienvenida", "configurador", "productos", "extras", "opcionales", "combos", "promociones", "cupones", "pedidos", "pedido", "express", "clientes", "fidelizacion", "kpis", "configuracion", "contenido", "delivery", "afiliados", "historial", "contactos", "producto-extras", "publicar"):
        assert c.get(f"/js/fis/pages/{p}.js").status_code == 200, p
    app_js = _static("js", "app.js") + _static("js", "menu.js"); ui = _static("ui.css"); sw = _static("sw-app.js")   # 3.77: el menú vive en menu.js
    assert "href: '/app/fisitaap/#/resumen'" in app_js and "function saltoFisitaap" in app_js and "'/fisitaap/pagina': '/publicar'" in app_js
    assert "@click=\"mobileOpen=!mobileOpen\"" in app_js and "fijarAutoCerrar(!autoCerrar)" not in app_js
    assert "transform:translateX(-105%)" in ui and ".sidebar.open{transform:translateX(0)" in ui
    from app import version as _version
    assert f"const VERSION = 'app-v{_version.actual()['version']}'" in sw and "'/app/fisitaap/'" in sw and "'/api/fisitaap/'" in sw
    fis = _static("js", "fis", "app.js")
    # 3.77: un solo cascarón: el cajón de Ventas en línea arma el mismo árbol del ERP (menu.js) y enlaza sus pantallas
    assert c.get("/js/menu.js").status_code == 200 and "menuVisibleDe" in fis and "Todo el ERP" in fis and "/app/#/inicio" in fis and "mode-switch" not in fis
    assert "fis('express-pendientes', 'Express pendientes')" in app_js and "label: 'Catálogo web'" in app_js


def test_resumen_kpis_configurador_y_contactos(api):  # noqa: F811
    c = api; eid = _eid()
    a, b, _o, _ag = _productos(c)
    assert _publicar(c, slug="emb-qa").status_code == 200
    r = c.get("/api/fisitaap/resumen"); assert r.status_code == 200, r.text
    d = r.json(); assert set(d) >= {"hoy", "ventas", "pedidos", "grafica", "bajo_minimo", "periodo"} and d["periodo"] == "today" and d["ventas"]["n"] == 0
    assert len(c.get("/api/fisitaap/resumen?periodo=week").json()["grafica"]) == 7 and len(c.get("/api/fisitaap/resumen?periodo=month").json()["grafica"]) == 30
    # un pedido web nuevo cuenta como pedido activo y aparece entre los que necesitan atención
    rp = c.post("/api/publico/emb-qa/pedido", json={"nombre": "Ana Mora", "telefono": "88881234", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}]}); assert rp.status_code == 200, rp.text
    d = c.get("/api/fisitaap/resumen").json(); assert d["pedidos"]["activos"] >= 1 and d["pedidos"]["nuevos"] >= 1 and d["pedidos"]["pendientes"][0]["numero"] == rp.json()["numero"]
    k = c.get("/api/fisitaap/kpis").json(); assert len(k["ventas"]) == 30 and k["pedidos_n"] >= 1 and "productos" in k
    assert c.get("/api/fisitaap/kpis?desde=2026-01-01&hasta=2025-01-01").status_code == 400
    # configurador: avanzar, retroceder, pausar
    g = c.get("/api/fisitaap/configurador").json(); assert g["paso"] == 0 and g["total"] == 11 and g["invitar"]
    assert c.put("/api/fisitaap/configurador", json={"accion": "next", "paso": 0}).json()["paso"] == 1
    assert c.put("/api/fisitaap/configurador", json={"accion": "next", "paso": 0}).status_code == 409
    assert c.put("/api/fisitaap/configurador", json={"accion": "back"}).json()["paso"] == 0
    p = c.put("/api/fisitaap/configurador", json={"accion": "pause"}).json(); assert p["pausado"] and not p["invitar"]
    # contactos: el formulario público deja el mensaje; el negocio lo lee y cambia el estado
    assert c.post("/api/publico/emb-qa/contacto", json={"nombre": "L", "mensaje": "hola"}).status_code == 400
    assert c.post("/api/publico/emb-qa/contacto", json={"nombre": "Luis Pérez", "correo": "luis@example.test", "telefono": "8888-0000", "asunto": "Horario", "mensaje": "¿Abren los domingos?"}).status_code == 200
    l = c.get("/api/fisitaap/contactos").json(); assert l["nuevos"] == 1 and l["lista"][0]["asunto"] == "Horario" and l["lista"][0]["telefono"] == "88880000"
    cid = l["lista"][0]["id"]
    assert c.put(f"/api/fisitaap/contactos/{cid}", json={"estado": "resolved"}).json()["estado"] == "resolved"
    assert c.get("/api/fisitaap/contactos?estado=new").json()["lista"] == [] and c.get("/api/fisitaap/contactos?q=domingos").json()["lista"][0]["id"] == cid
    assert c.put(f"/api/fisitaap/contactos/{cid}", json={"estado": "x"}).status_code == 400


def test_promociones_por_producto(api):  # noqa: F811
    c = api
    a, b, _o, _ag = _productos(c)
    assert _publicar(c, slug="fispromo-qa").status_code == 200
    assert c.post("/api/fisitaap/promociones", json={"producto_id": a["id"], "tipo": "special", "valor": 0}).status_code == 400
    r = c.post("/api/fisitaap/promociones", json={"producto_id": a["id"], "tipo": "special", "valor": 3000}); assert r.status_code == 200, r.text
    r2 = c.post("/api/fisitaap/promociones", json={"producto_id": b["id"], "tipo": "bogo", "desde": "2020-01-01T00:00", "hasta": "2099-12-31T23:59"}); assert r2.status_code == 200, r2.text
    lista = c.get("/api/fisitaap/promociones").json(); assert {x["producto_id"] for x in lista} == {a["id"], b["id"]}
    pub = {i["id"]: i for i in c.get("/api/publico/fispromo-qa").json()["items"]}
    assert pub[a["id"]]["precio"] == 3000.0 and pub[a["id"]]["promo"]["etiqueta"] == "Precio especial" and pub[a["id"]]["promo"]["precio_antes"] == 4520.0
    assert pub[b["id"]]["promo"]["tipo"] == "bogo"
    # el pedido usa el precio especial y el 2 × 1 (dos unidades pagan una; los impuestos se calculan sobre lo pagado)
    rp = c.post("/api/publico/fispromo-qa/pedido", json={"nombre": "Ana Mora", "telefono": "88881234", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}, {"producto_id": b["id"], "cantidad": 2}]})
    assert rp.status_code == 200, rp.text
    ls = {l["producto_id"]: l for l in rp.json()["lineas"]}
    assert ls[a["id"]]["total"] == 3000.0 and ls[a["id"]]["promo"] == "Precio especial"
    assert ls[b["id"]]["promo"] == "2 × 1" and ls[b["id"]]["total"] == round(b["precio"] * 1.13, 2)
    # una promoción nueva del mismo producto desactiva la anterior; desactivar la quita del catálogo
    c.post("/api/fisitaap/promociones", json={"producto_id": a["id"], "tipo": "special", "valor": 2500})
    assert [x for x in c.get("/api/fisitaap/promociones").json() if x["producto_id"] == a["id"]][0]["valor"] == 2500
    assert c.delete(f"/api/fisitaap/promociones/{r2.json()['id']}").status_code == 200
    assert "promo" not in {i["id"]: i for i in c.get("/api/publico/fispromo-qa").json()["items"]}[b["id"]]


def test_extras_opcionales_y_asignacion(api):  # noqa: F811
    c = api; eid = _eid()
    a, b, _o, _ag = _productos(c)
    assert _publicar(c, slug="extras-qa").status_code == 200
    cat_a = c.get(f"/api/productos/{a['id']}").json().get("categoria") or ""
    ex = c.post("/api/fisitaap/extras", json={"nombre": "Queso extra", "precio": 500, "obligatorio": False, "productos": [a["id"]], "categorias": []}); assert ex.status_code == 200, ex.text
    assert ex.json()["tipo"] == "extra" and ex.json()["precio"] == 500.0 and ex.json()["opciones"][0]["nombre"] == "Queso extra"
    assert c.post("/api/fisitaap/opcionales", json={"nombre": "Tallas", "opciones": [{"nombre": "S"}, {"nombre": "M"}, {"nombre": "S"}]}).status_code == 400   # repetida
    op = c.post("/api/fisitaap/opcionales", json={"nombre": "Tallas", "opciones": [{"nombre": "S"}, {"nombre": "M"}, {"nombre": "L"}], "obligatorio": True, "multiple": False, "productos": [], "categorias": [cat_a] if cat_a else []})
    assert op.status_code == 200, op.text
    assert op.json()["tipo"] == "opcional" and [o["nombre"] for o in op.json()["opciones"]] == ["S", "M", "L"] and op.json()["obligatorio"] and not op.json()["multiple"]
    assert c.post("/api/fisitaap/opcionales", json={"nombre": "Tallas", "opciones": [{"nombre": "XL"}]}).status_code == 400          # ya existe
    todos = c.get("/api/fisitaap/modificadores").json(); assert {g["nombre"] for g in todos["grupos"]} >= {"Queso extra", "Tallas"} and todos["productos"]
    assert [g["nombre"] for g in c.get("/api/fisitaap/modificadores?tipo=extra").json()["grupos"]] == ["Queso extra"]
    # el producto hereda: el extra por asignación directa y Tallas por la categoría; el catálogo público los muestra
    with Session(engine_empresa(eid)) as s:
        nombres = [g["nombre"] for g in promociones.grupos_de_producto(s, eid, a["id"])]
    assert "Queso extra" in nombres and (("Tallas" in nombres) == bool(cat_a))
    pub = {i["id"]: i for i in c.get("/api/publico/extras-qa").json()["items"]}
    assert "Queso extra" in [g["nombre"] for g in pub[a["id"]]["modificadores"]] and pub[b["id"]]["modificadores"] == [] or cat_a
    # asignación manual desde la ficha del producto (items_extra) y edición de la opción conservando su identidad
    gid = op.json()["id"]; oid_s = op.json()["opciones"][0]["id"]
    asg = c.get(f"/api/fisitaap/productos/{b['id']}/modificadores").json(); assert asg["producto"]["id"] == b["id"] and any(g["id"] == gid for g in asg["grupos"])
    assert c.put(f"/api/fisitaap/productos/{b['id']}/modificadores", json={"grupos": [gid]}).json()["grupos"] == [gid]
    assert c.put(f"/api/fisitaap/productos/{b['id']}/modificadores", json={"grupos": [999999]}).status_code == 400
    with Session(engine_empresa(eid)) as s:
        assert [g["id"] for g in promociones.grupos_de_producto(s, eid, b["id"])] == [gid]
    ed = c.put(f"/api/fisitaap/opcionales/{gid}", json={"nombre": "Tallas", "opciones": [{"id": oid_s, "nombre": "Small"}, {"nombre": "XL"}], "obligatorio": False, "multiple": True})
    assert ed.status_code == 200 and ed.json()["opciones"][0]["id"] == oid_s and ed.json()["opciones"][0]["nombre"] == "Small" and ed.json()["multiple"]
    assert c.put(f"/api/fisitaap/opcionales/{gid}", json={"nombre": "Tallas", "opciones": [{"id": 999999, "nombre": "x"}]}).status_code == 400
    assert c.delete(f"/api/fisitaap/modificadores/{gid}").status_code == 200
    assert gid not in [g["id"] for g in c.get("/api/fisitaap/modificadores").json()["grupos"]]
    # extra inexistente
    assert c.put("/api/fisitaap/extras/999999", json={"nombre": "x", "precio": 1}).status_code == 404


def test_combos_ajustes_y_diseno(api):  # noqa: F811
    c = api; eid = _eid()
    a, b, _o, _ag = _productos(c)
    assert _publicar(c, slug="combo-qa").status_code == 200
    assert c.post("/api/fisitaap/combos", json={"nombre": "Combo", "precio": 5000, "tarifa": 13, "componentes": []}).status_code == 400
    r = c.post("/api/fisitaap/combos", json={"nombre": "Combo desayuno", "precio": 5000, "tarifa": 13, "descripcion": "Casado + refresco", "componentes": [{"producto_id": a["id"], "cantidad": 1}, {"producto_id": b["id"], "cantidad": 2}, {"producto_id": b["id"], "cantidad": 1}]})
    assert r.status_code == 200, r.text
    cid = r.json()["id"]; assert {x["producto_id"]: x["cantidad"] for x in r.json()["componentes"]} == {a["id"]: 1.0, b["id"]: 3.0}
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, cid); assert p.tipo == "Combo" and p.visible_catalogo and p.categoria == "Combos" and p.cabys == a["cabys"] and not p.inventariable
        rec = next(x for x in modulos.leer(s, eid, "recetas", []) if x.get("producto_id") == cid); assert len(rec["ingredientes"]) == 2 and rec["vender"]
    lista = c.get("/api/fisitaap/combos").json(); assert [x["id"] for x in lista["combos"]] == [cid] and all(x["id"] != cid for x in lista["productos"])
    assert "Combo desayuno" in [i["nombre"] for i in c.get("/api/publico/combo-qa").json()["items"]]
    r = c.post("/api/fisitaap/combos", json={"id": cid, "nombre": "Combo desayuno grande", "precio": 6000, "tarifa": 13, "componentes": [{"producto_id": a["id"], "cantidad": 2}]}); assert r.status_code == 200 and r.json()["nombre"] == "Combo desayuno grande"
    assert c.post("/api/fisitaap/combos", json={"nombre": "Combo de combos", "precio": 1, "componentes": [{"producto_id": cid, "cantidad": 1}]}).status_code == 400
    assert c.delete(f"/api/fisitaap/combos/{cid}").status_code == 200 and c.get("/api/fisitaap/combos").json()["combos"] == []
    # ajustes de Generales y diseño de la página: validaciones y lo que ve el público
    aj = c.get("/api/fisitaap/ajustes").json(); assert aj["metodos_pago"] == ["SINPE Móvil", "Efectivo", "Tarjeta al recibir", "Transferencia"] and aj["precios_con_iva"]
    assert c.put("/api/fisitaap/ajustes", json={"metodos_pago": []}).status_code == 400
    assert c.put("/api/fisitaap/ajustes", json={"metodos_pago": ["Efectivo"], "mapa_embed": "<script>x</script>"}).status_code == 400
    assert c.put("/api/fisitaap/ajustes", json={"metodos_pago": ["Efectivo"], "tiktok": "tiktok.com/@soda"}).status_code == 400
    r = c.put("/api/fisitaap/ajustes", json={"metodos_pago": ["Efectivo", "Transferencia", "Otro"], "horario_texto": "Lunes a sábado", "mapa_embed": '<iframe src="https://www.google.com/maps/embed?pb=1" width="1"></iframe>', "correo_contacto": "soda@example.test", "tiktok": "https://tiktok.com/@soda"})
    assert r.status_code == 200 and r.json()["metodos_pago"] == ["Efectivo", "Transferencia"] and r.json()["horario_texto"] == "Lunes a sábado"
    assert c.put("/api/fisitaap/diseno", json={"campos": {"catalog_slide_seconds": 1}}).status_code == 400
    assert c.put("/api/fisitaap/diseno", json={"campos": {"accent_color": "rojo"}}).status_code == 400
    r = c.put("/api/fisitaap/diseno", json={"campos": {"hero_title": "  Bienvenidos  ", "about_promise_1": "x" * 200, "catalog_intro_mode": "hidden", "catalog_slide_seconds": 7, "accent_color": "#112233", "catalog_text_color": "#ffffff", "service_1_title": "Nuestros platos"}})
    assert r.status_code == 200 and r.json()["hero_title"] == "Bienvenidos" and len(r.json()["about_promise_1"]) == 80 and r.json()["catalog_slide_seconds"] == 7
    pub = c.get("/api/publico/combo-qa").json()
    assert pub["diseno"]["hero_title"] == "Bienvenidos" and pub["diseno"]["catalog_intro_mode"] == "hidden" and pub["ajustes"]["metodos_pago"] == ["Efectivo", "Transferencia"] and pub["etiqueta"] in ("Catálogo", "Menú")
    html = c.get("/t/combo-qa").text
    assert 'class="public-body r14-store r15-store"' in html and "/fisitaap/assets/app.bundle.css" in html and "--accent:#112233" in html and "/js/tienda.js" in html


def test_express_pendientes_sin_entregas(api):  # noqa: F811
    c = api
    r = c.get("/api/fisitaap/express/pendientes"); assert r.status_code == 200 and r.json() == {"entregas": [], "motorizados": []}
