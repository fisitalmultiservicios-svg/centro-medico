# -*- coding: utf-8 -*-
"""4.25 (tanda 9): cambios hechos en el programa conectado a ítems creados en la página web (o en otra computadora). El programa los
manda a la web EN EL MOMENTO (POST /api/sinc/producto) y aplica aquí las filas que la web devuelve; sin internet no se guardan y el
programa lo dice (503). Los ítems del rango propio siguen como siempre (cero llamadas). También: imagen e importación de ítems ajenos,
la ruta de la web (solo para el token de una instalación de esa empresa, con su tope) y la protección de códigos en la red del local.

Nube y computadora corren en el mismo proceso (ayudas de tests/test_49_local_sinc.py y tests/test_425_xml_lote.py)."""
import pathlib

import httpx
import pytest
from sqlmodel import Session, select

from app import auth, inventario, modulos, sinc
from app.db import Documento, DocumentoLinea, Producto, engine, engine_empresa
from test_49_local_sinc import H, NUBE, _admin_empresa, _HttpxRed, _poner_cfg, _Respuesta, _vincular, c
from test_425_xml_lote import _canje

R = modulos.RANGO
RAIZ = pathlib.Path(__file__).resolve().parents[1]
RUTA = sinc.RUTA_PRODUCTO
CABYS = "8311000000000"
_MIAS: list = []


@pytest.fixture(autouse=True, scope="module")
def _limpieza():
    yield
    for eid in _MIAS:                                  # otras pruebas buscan instalaciones vinculadas: se desvinculan al terminar
        try:
            with Session(engine_empresa(eid)) as s:
                cfg = sinc._cfg_local(s, eid)
                if cfg.get("vinculado"):
                    cfg.update({"vinculado": False, "token": None})
                    sinc._escribir(s, eid, sinc.CLAVE_LOCAL, cfg); s.commit()
        except Exception:  # noqa: BLE001
            pass
        modulos._rangos.pop(eid, None); sinc._fijas.pop(eid, None); sinc._inst_estado.pop(eid, None)
    with Session(engine) as sc:
        for x in sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc_producto")).all():
            sc.delete(x)
        sc.commit()


def _empresa(sufijo: str, cedula: str):
    eid, t = _admin_empresa(sufijo, cedula)
    _MIAS.append(eid)
    return eid, t


def _modo_local_red(monkeypatch) -> _HttpxRed:
    shim = _HttpxRed()
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(sinc, "httpx", shim)
    monkeypatch.setattr(auth, "bloqueo_local", sinc._bloqueo_local)
    monkeypatch.setattr(auth, "aviso_local", sinc._aviso_local)
    return shim


def _pareja(monkeypatch, sufijo: str, a: str, b: str):
    """Web (a) y programa (b) vinculados, con la primera bajada hecha."""
    eid_a, ta = _empresa(sufijo + "n", a)
    eid_b, tb = _empresa(sufijo + "l", b)
    shim = _modo_local_red(monkeypatch)
    _vincular(monkeypatch, ta, tb, "Caja T9")
    return eid_a, ta, eid_b, tb, shim


def _item(tok: str, nombre: str, codigo: str | None = None) -> int:
    cuerpo = {"nombre": nombre, "cabys": CABYS, "precio": 1000, "unidad_medida": "Sp", "es_servicio": True, "inventariable": False,
              "codigo_tarifa": "08", "tarifa": 13}
    if codigo:
        cuerpo["codigo"] = codigo
    r = c.post("/api/productos", headers=H(tok), json=cuerpo)
    assert r.status_code == 200, r.text
    return r.json()["id"]


def _p(eid: int, pid: int):
    with Session(engine_empresa(eid)) as s:
        return s.get(Producto, pid)


def _sincronizar(eid: int) -> None:
    assert not sinc.sincronizar(eid)["ultimo_error"]


def _llamadas(shim) -> int:
    return sum(1 for x in shim.llamadas if x[1] == RUTA)


# ---------------------------------------------------------------------------------------------------------------- editar
def test_editar_un_item_de_la_web_desde_el_programa(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9a", "3101942501", "3101942502")
    pid = _item(ta, "Servicio de la web T9", "QA-T9-A1")
    _sincronizar(eid_b)
    assert _p(eid_b, pid) is not None and pid < R
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"precio": 2500, "categoria": "Web T9"})
    assert r.status_code == 200, r.text
    assert r.json()["id"] == pid and r.json()["precio"] == 2500 and r.json()["empresa_id"] == eid_b      # la forma de la ruta de siempre
    assert _llamadas(shim) == 1
    assert _p(eid_a, pid).precio == 2500 and _p(eid_a, pid).categoria == "Web T9"                     # la web lo tiene
    assert _p(eid_b, pid).precio == 2500                                                              # el programa también
    _sincronizar(eid_b)
    assert _p(eid_b, pid).precio == 2500 and _p(eid_b, pid).categoria == "Web T9"                     # y la bajada siguiente lo conserva
    # F-4: auditoría en la web con el nombre de la instalación y quién lo hizo en el programa (solo texto)
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_a, auth.Auditoria.accion == "producto_editado_programa")).first()
    assert a is not None and "[en el programa: duena-sinc49-t9al@example.test]" in a.detalle and "precio" in a.detalle and "[API:" in a.detalle
    # «Registrar código»: el código nuevo y el anterior como alterno, en la web y aquí
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"codigo": "7501234567893", "conservar_codigo_anterior": True})
    assert r.status_code == 200, r.text
    for eid in (eid_a, eid_b):
        p = _p(eid, pid)
        assert p.codigo == "7501234567893" and p.codigos_alternos == "QA-T9-A1", (eid, p.codigo, p.codigos_alternos)
    _sincronizar(eid_b)
    assert _p(eid_b, pid).codigo == "7501234567893"


def test_codigo_repetido_en_la_web_o_aqui(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9b", "3101942503", "3101942504")
    pid = _item(ta, "Ítem web T9b")
    _sincronizar(eid_b)
    _item(ta, "Otro de la web T9b", "QA-T9-DUP")                      # todavía no bajó al programa
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"codigo": "QA-T9-DUP", "precio": 777})
    assert r.status_code == 409 and "Ya existe otro producto con el código QA-T9-DUP: Otro de la web T9b" in r.json()["detail"], r.text
    assert _p(eid_b, pid).codigo is None and _p(eid_b, pid).precio == 1000 and _p(eid_a, pid).precio == 1000
    # el código ya lo tiene OTRO ítem de esta computadora: 409 como hoy y no se llama a la web
    _item(tb, "Ítem del programa T9b", "QA-T9-LOC")
    antes = _llamadas(shim)
    r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"codigo": "QA-T9-LOC"})
    assert r.status_code == 409 and "QA-T9-LOC" in r.json()["detail"] and _llamadas(shim) == antes
    assert _p(eid_a, pid).codigo is None


def test_sin_internet_o_web_que_no_atiende_no_cambia_nada(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9c", "3101942505", "3101942506")
    pid = _item(ta, "Ítem web T9c")
    _sincronizar(eid_b)
    for falla in (httpx.ConnectError("sin red"), httpx.ReadTimeout("tiempo"), _Respuesta(500, {"detail": "error"}),
                  _Respuesta(404, {"detail": "Not Found"}), _Respuesta(405, {"detail": "Method Not Allowed"}), _Respuesta(429, {"detail": "espere"}),
                  _Respuesta(401, {"detail": "token"}), _Respuesta(403, {"detail": "no"}), _Respuesta(200, {"raro": True}), _Respuesta(200, None, "<html>"),
                  _Respuesta(401, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "revocada"}})):
        shim.por_ruta[RUTA] = falla
        r = c.put(f"/api/productos/{pid}", headers=H(tb), json={"precio": 3333})
        assert r.status_code == 503 and r.json()["detail"] == sinc.MENSAJE_ITEM_WEB, (falla, r.text)
        assert _p(eid_b, pid).precio == 1000
    assert _p(eid_a, pid).precio == 1000
    # el detalle del error de la web nunca queda en la configuración
    with Session(engine_empresa(eid_b)) as s:
        assert not sinc._cfg_local(s, eid_b).get("ultimo_error")
    shim.por_ruta.pop(RUTA)


def test_item_propio_y_programa_sin_conectar_no_llaman(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9d", "3101942507", "3101942508")
    propio = _item(tb, "Ítem del programa T9d")
    assert propio // R == 2
    r = c.put(f"/api/productos/{propio}", headers=H(tb), json={"precio": 1500})
    assert r.status_code == 200 and r.json()["precio"] == 1500 and _llamadas(shim) == 0
    assert c.delete(f"/api/productos/{propio}", headers=H(tb)).json() == {"ok": True} and _llamadas(shim) == 0
    # programa sin conectar: todo como hoy, cero llamadas
    eid_s, ts = _empresa("-t9ds", "3101942509")
    shim.llamadas.clear()
    pid = _item(ts, "Ítem sin conectar T9d")
    assert pid < R
    r = c.put(f"/api/productos/{pid}", headers=H(ts), json={"precio": 1700, "codigo": "QA-T9-SC"})
    assert r.status_code == 200 and r.json()["precio"] == 1700 and r.json()["codigo"] == "QA-T9-SC"
    g = c.post("/api/productos/codigos/generar", headers=H(ts), json={"ids": [pid], "reemplazar": True}).json()
    assert g["cambiados"] == 1 and "aviso" not in g
    assert c.post("/api/productos/lote/cambios", headers=H(ts), json={"ids": [pid], "categoria": "SC"}).json() == {"ok": True, "cambiados": 1, "omitidos": 0}
    assert c.delete(f"/api/productos/{pid}", headers=H(ts)).json() == {"ok": True}
    assert shim.llamadas == []


# ---------------------------------------------------------------------------------------------------------------- generar y lote
def test_generar_y_lote_mezclados_con_la_web_caida_a_medias(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9e", "3101942510", "3101942511")
    w1, w2 = _item(ta, "Web uno T9e"), _item(ta, "Web dos T9e")
    _sincronizar(eid_b)
    propio = _item(tb, "Propio T9e")
    monkeypatch.setattr(sinc, "MAX_IDS_PRODUCTO", 1)                  # un ítem por llamada: la primera llega, la segunda no
    shim.por_ruta[RUTA] = [None, httpx.ConnectError("sin red")]
    r = c.post("/api/productos/codigos/generar", headers=H(tb), json={"ids": [propio, w1, w2]})
    assert r.status_code == 200, r.text
    g = r.json()
    assert g["cambiados"] == 2 and g["no_guardados"] == 1 and sinc.MENSAJE_ITEM_WEB in g["aviso"]
    assert [x["id"] for x in g["no_se_pudo"]] == [w2] and g["no_se_pudo"][0]["motivo"] == sinc.MENSAJE_ITEM_WEB
    assert set(g["codigos"]) == {str(propio), str(w1)}
    assert _p(eid_b, propio).codigo == g["codigos"][str(propio)]                                     # el propio, aquí como siempre
    assert _p(eid_a, w1).codigo == g["codigos"][str(w1)] == _p(eid_b, w1).codigo                      # el de la web, en la web y aquí
    assert _p(eid_a, w2).codigo is None and _p(eid_b, w2).codigo is None
    assert _llamadas(shim) == 2
    # lote: igual
    shim.por_ruta[RUTA] = [None, httpx.ConnectError("sin red")]
    r = c.post("/api/productos/lote/cambios", headers=H(tb), json={"ids": [propio, w1, w2], "categoria": "Lote T9e"})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["cambiados"] == 2 and j["no_guardados"] == 1 and "1 ítem creado en la página web no se cambió" in j["aviso"] and sinc.MENSAJE_ITEM_WEB in j["aviso"]
    assert _p(eid_b, propio).categoria == "Lote T9e" and _p(eid_a, w1).categoria == "Lote T9e" == _p(eid_b, w1).categoria
    assert _p(eid_a, w2).categoria is None and _p(eid_b, w2).categoria is None
    shim.por_ruta.pop(RUTA)
    # sin fallas, todo junto (y la bajada siguiente lo conserva)
    monkeypatch.setattr(sinc, "MAX_IDS_PRODUCTO", 500)
    j = c.post("/api/productos/lote/cambios", headers=H(tb), json={"ids": [propio, w1, w2], "activo": False}).json()
    assert j == {"ok": True, "cambiados": 3, "omitidos": 0}
    _sincronizar(eid_b)
    assert not _p(eid_b, w2).activo and not _p(eid_a, w2).activo and not _p(eid_a, propio).activo


# ---------------------------------------------------------------------------------------------------------------- eliminar
def test_eliminar_un_item_de_la_web(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9f", "3101942512", "3101942513")
    vendido, libre = _item(ta, "Vendido en la web T9f", "QA-T9-VEN"), _item(ta, "Sin ventas T9f")
    with Session(engine_empresa(eid_a)) as s:                          # tiene ventas en la web
        s.add(DocumentoLinea(documento_id=987654, numero=1, producto_id=vendido, cabys=CABYS, detalle="QA", cantidad=1, unidad_medida="Sp", precio_unitario=1000))
        s.commit()
    _sincronizar(eid_b)
    r = c.delete(f"/api/productos/{vendido}", headers=H(tb))
    assert r.status_code == 200 and r.json() == {"ok": True, "desactivado": True}, r.text
    for eid in (eid_a, eid_b):                                         # la web lo desactiva y libera el código; aquí queda igual
        p = _p(eid, vendido)
        assert p is not None and not p.activo and p.codigo is None and not p.codigos_alternos, eid
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_a, auth.Auditoria.accion == "producto_codigo_liberado")).first()
    assert a is not None and "QA-T9-VEN" in a.detalle and "[en el programa: duena-sinc49-t9fl@example.test]" in a.detalle
    # sin ventas: la web lo elimina y aquí también
    assert c.delete(f"/api/productos/{libre}", headers=H(tb)).json() == {"ok": True}
    assert _p(eid_a, libre) is None and _p(eid_b, libre) is None
    # sin internet: aquí no cambia nada
    otro = _item(ta, "Otro T9f")
    _sincronizar(eid_b)
    shim.por_ruta[RUTA] = httpx.ConnectError("sin red")
    r = c.delete(f"/api/productos/{otro}", headers=H(tb))
    assert r.status_code == 503 and _p(eid_b, otro) is not None and _p(eid_b, otro).activo and _p(eid_a, otro) is not None
    shim.por_ruta.pop(RUTA)


def test_eliminar_un_item_que_la_web_ya_no_tiene(monkeypatch):
    """Corrección de la revisión: la bajada nunca quita los ítems que la web eliminó. Si al eliminarlo aquí la web contesta 404 «ya no
    existe», se aplica aquí la regla de siempre (se elimina; con ventas o movimientos de aquí, queda inactivo y sin código) en vez de
    repetir el error para siempre. Solo con ese 404 exacto: cualquier otra respuesta sigue sin cambiar nada aquí."""
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9k", "3101942521", "3101942522")
    libre, vendido, queda = _item(ta, "Fantasma T9k", "QA-T9-FAN"), _item(ta, "Fantasma vendido T9k", "QA-T9-FAV"), _item(ta, "Sigue T9k")
    _sincronizar(eid_b)
    for pid in (libre, vendido):                                       # se eliminan en la página web (allá no tienen ventas)
        assert c.delete(f"/api/productos/{pid}", headers=H(ta)).json() == {"ok": True}
        assert _p(eid_a, pid) is None
    _sincronizar(eid_b)
    assert _p(eid_b, libre).activo and _p(eid_b, vendido).codigo == "QA-T9-FAV"      # la bajada no los quita: siguen aquí, a la venta
    with Session(engine_empresa(eid_b)) as s:                          # uno ya se vendió en esta computadora
        s.add(DocumentoLinea(documento_id=987655, numero=1, producto_id=vendido, cabys=CABYS, detalle="QA", cantidad=1, unidad_medida="Sp", precio_unitario=1000))
        s.commit()
    r = c.put(f"/api/productos/{libre}", headers=H(tb), json={"precio": 4444})       # editar: la web dice que ya no existe y aquí no cambia
    assert r.status_code == 404 and r.json()["detail"] == sinc.NO_EXISTE_EN_WEB and _p(eid_b, libre).precio == 1000
    antes = _llamadas(shim)
    r = c.delete(f"/api/productos/{libre}", headers=H(tb))
    assert r.status_code == 200 and r.json() == {"ok": True}, r.text
    assert _p(eid_b, libre) is None and _llamadas(shim) == antes + 1    # se preguntó a la web y se eliminó aquí
    r = c.delete(f"/api/productos/{vendido}", headers=H(tb))
    assert r.status_code == 200 and r.json() == {"ok": True, "desactivado": True}, r.text
    p = _p(eid_b, vendido)
    assert p is not None and not p.activo and p.codigo is None         # con ventas de aquí: inactivo y con el código libre
    # una web anterior (404 sin el texto), otro 404 o el mismo texto con otro código NO son «ya no existe»: aquí no cambia nada
    for falla, estado in ((_Respuesta(404, {"detail": "Not Found"}), 503), (_Respuesta(404, {"detail": "Otro texto"}), 404),
                          (_Respuesta(409, {"detail": sinc.NO_EXISTE_EN_WEB}), 409), (_Respuesta(404, {"detail": {"codigo": sinc.NO_EXISTE_EN_WEB}}), 503)):
        shim.por_ruta[RUTA] = falla
        r = c.delete(f"/api/productos/{queda}", headers=H(tb))
        assert r.status_code == estado, (estado, r.text)
        assert _p(eid_b, queda) is not None and _p(eid_b, queda).activo and _p(eid_a, queda) is not None
    shim.por_ruta.pop(RUTA)


def test_eliminar_con_ventas_de_esta_computadora_que_la_web_no_tiene(monkeypatch):
    """Corrección de la revisión: la web decide con SUS ventas. Si el ítem tiene aquí ventas o movimientos (que pueden no haber subido),
    el programa lo dice (`con_historial`) y la web lo desactiva y libera el código en vez de borrarlo: el comprobante que sube después
    conserva su ítem. Sin ventas ni movimientos aquí no va la marca y la web decide como siempre."""
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9m", "3101942523", "3101942524")
    vendido, movido, libre = _item(ta, "Vendido aquí T9m", "QA-T9-LOCV"), _item(ta, "Con movimiento aquí T9m", "QA-T9-LOCM"), _item(ta, "Sin ventas T9m")
    _sincronizar(eid_b)
    clave = "506" + "081126" + "003101942524" + "00100002040000094251" + "1" + "00009425"
    assert len(clave) == 50
    with Session(engine_empresa(eid_b)) as s:                          # la caja lo vende: el comprobante todavía no subió a la web
        d = Documento(empresa_id=eid_b, tipo_documento="04", clave=clave, consecutivo="00100002040000094251", fecha_emision="2026-11-08T10:00:00-06:00",
                      moneda="CRC", tipo_cambio=1, total=1130, impuesto=130, estado="interno", ambiente="sandbox", condicion_venta="01")
        s.add(d); s.commit(); s.refresh(d)
        s.add(DocumentoLinea(documento_id=d.id, numero=1, producto_id=vendido, cabys=CABYS, detalle="Vendido aquí T9m", cantidad=1, unidad_medida="Sp",
                             precio_unitario=1000, descuento=0, codigo_tarifa="08", tarifa=13, impuesto=130, total=1130))
        s.add(inventario.MovimientoInventario(empresa_id=eid_b, fecha="2026-11-08", producto_id=movido, bodega_id=1, tipo="ajuste", cantidad=1))
        s.commit()
    for pid in (vendido, movido):
        r = c.delete(f"/api/productos/{pid}", headers=H(tb))
        assert r.status_code == 200 and r.json() == {"ok": True, "desactivado": True}, r.text
        assert shim.llamadas[-1][1] == RUTA and shim.llamadas[-1][2]["operacion"] == "eliminar" and shim.llamadas[-1][2].get("con_historial") is True
        for eid in (eid_a, eid_b):                                     # la web NO lo borra: lo desactiva y libera el código; aquí queda igual
            p = _p(eid, pid)
            assert p is not None and not p.activo and p.codigo is None and not p.codigos_alternos, (pid, eid)
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_a, auth.Auditoria.accion == "producto_codigo_liberado")).first()
    assert a is not None and "QA-T9-LOCV" in a.detalle and "[en el programa: duena-sinc49-t9ml@example.test]" in a.detalle
    _sincronizar(eid_b)                                                # el comprobante sube y en la web su línea conserva el ítem
    with Session(engine_empresa(eid_a)) as s:
        dn = s.exec(select(Documento).where(Documento.clave == clave)).first()
        assert dn is not None
        assert [x.producto_id for x in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == dn.id)).all()] == [vendido]
    assert _p(eid_b, vendido) is not None and not _p(eid_b, vendido).activo
    # sin ventas ni movimientos aquí: no va la marca y la web lo elimina, como siempre
    assert c.delete(f"/api/productos/{libre}", headers=H(tb)).json() == {"ok": True}
    assert "con_historial" not in shim.llamadas[-1][2] and _p(eid_a, libre) is None and _p(eid_b, libre) is None
    # la marca en la ruta de la web: solo hace que desactive (nunca borra de más) y un valor que no es sí/no no entra
    tok, _terminal = _canje(ta)
    otro = _item(ta, "Otro T9m", "QA-T9-OTRO")
    assert c.post(RUTA, headers=H(tok), json={"operacion": "eliminar", "id": otro, "con_historial": "quizás"}).status_code == 400
    assert _p(eid_a, otro).activo and _p(eid_a, otro).codigo == "QA-T9-OTRO"
    r = c.post(RUTA, headers=H(tok), json={"operacion": "eliminar", "id": otro, "con_historial": True})
    assert r.status_code == 200 and r.json()["resultado"] == {"ok": True, "desactivado": True} and [x["id"] for x in r.json()["productos"]] == [otro], r.text
    assert not _p(eid_a, otro).activo and _p(eid_a, otro).codigo is None


# ---------------------------------------------------------------------------------------------------------------- imagen e importación
def test_imagen_e_importacion_de_items_ajenos(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9g", "3101942514", "3101942515")
    pid = _item(ta, "Ítem web T9g", "QA-T9-IMP")
    _sincronizar(eid_b)
    r = c.post(f"/api/productos/{pid}/imagen", headers=H(tb), files={"archivo": ("foto.png", b"\x89PNG\r\n\x1a\nQA", "image/png")})
    assert r.status_code == 409 and r.json()["detail"] == "La imagen de este ítem se cambia en la página web"
    assert c.delete(f"/api/productos/{pid}/imagen", headers=H(tb)).status_code == 409
    assert _p(eid_b, pid).imagen_nombre is None
    propio = _item(tb, "Propio T9g")
    r = c.post(f"/api/productos/{propio}/imagen", headers=H(tb), files={"archivo": ("foto.png", b"\x89PNG\r\n\x1a\nQA", "image/png")})
    assert r.status_code == 200, r.text
    # importar: la fila que actualizaría el ítem de la web no se aplica y se avisa; la nueva entra como hoy
    csv = ("nombre,codigo,cabys,precio,unidad,tipo,tarifa\n"
           f"Ítem web T9g,QA-T9-IMP,{CABYS},9999,Sp,Servicio,08\n"
           f"Nuevo importado T9g,QA-T9-NUEVO,{CABYS},500,Sp,Servicio,08\n").encode()
    for simular in ("1", "0"):
        r = c.post("/api/productos/importar", headers=H(tb), files={"archivo": ("items.csv", csv, "text/csv")}, data={"modo": "actualizar", "simular": simular})
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["ajenos_sin_actualizar"] == 1 and j["avisos"][0] == "1 ítem creado en la página web no se actualizó: impórtelo allá"
        assert j["creados"] == 1 and j["actualizados"] == 0 and j["omitidos"] == 1
    assert _p(eid_b, pid).precio == 1000 and _p(eid_a, pid).precio == 1000
    assert _llamadas(shim) == 0


# ---------------------------------------------------------------------------------------------------------------- la ruta de la web
def test_la_ruta_de_la_web(monkeypatch):
    eid_a, ta = _empresa("-t9h", "3101942516")
    eid_o, to = _empresa("-t9ho", "3101942517")
    tok, terminal = _canje(ta)
    pid = _item(ta, "Ítem web T9h")
    ajeno = [_item(to, f"De otra empresa T9h {i}") for i in range(3)][-1]          # un id que en la empresa del token no existe
    assert _p(eid_a, ajeno) is None
    r = c.post(RUTA, headers=H(tok), json={"operacion": "editar", "id": pid, "cambios": {"precio": 1200}, "por": "Caja\n  Uno" + "x" * 200})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["resultado"]["precio"] == 1200 and [x["id"] for x in j["productos"]] == [pid] and j["productos"][0]["precio"] == 1200
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_a, auth.Auditoria.accion == "producto_editado_programa")).first()
    por = a.detalle.split("[en el programa: ", 1)[1].split("]", 1)[0]
    assert por.startswith("Caja Uno") and len(por) == sinc.LARGO_POR and "\n" not in a.detalle
    # ítem de otra empresa: 404 (con texto), en todas las operaciones de un ítem
    for cuerpo in ({"operacion": "editar", "id": ajeno, "cambios": {"precio": 1}}, {"operacion": "eliminar", "id": ajeno}):
        r = c.post(RUTA, headers=H(tok), json=cuerpo)
        assert r.status_code == 404 and r.json()["detail"] == sinc.NO_EXISTE_EN_WEB, r.text
    assert _p(eid_o, ajeno).precio == 1000
    # cuerpo malo: 400 sin repetir lo enviado
    for malo in (None, [], {"operacion": "otra"}, {"operacion": "editar", "id": "x" * 30}, {"operacion": "lote", "ids": list(range(1, 600)), "cambios": {}},
                 {"operacion": "lote", "ids": [pid], "cambios": {"precio_factor": "secreto-QA"}}):
        r = c.post(RUTA, headers=H(tok), json=malo)
        assert r.status_code == 400 and "secreto-QA" not in r.text and "xxxxxxxx" not in r.text, (malo, r.text)
    # token de una persona: 403
    assert c.post(RUTA, headers=H(ta), json={"operacion": "editar", "id": pid, "cambios": {"precio": 5}}).status_code == 403
    assert c.post(RUTA, json={"operacion": "editar", "id": pid, "cambios": {"precio": 5}}).status_code == 401
    # tope por instalación
    monkeypatch.setattr(sinc, "LIMITE_PRODUCTO", (r_max := 3, 300))
    with Session(engine) as sc:
        for x in sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc_producto")).all():
            sc.delete(x)
        sc.commit()
    estados = [c.post(RUTA, headers=H(tok), json={"operacion": "generar", "ids": [pid]}).status_code for _ in range(r_max + 1)]
    assert estados == [200] * r_max + [429], estados
    # en un programa real la ruta no existe
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    assert c.post(RUTA, headers=H(tok), json={"operacion": "editar", "id": pid, "cambios": {}}).status_code == 404
    monkeypatch.delenv("FE_MODO_LOCAL")
    # instalación revocada: la señal explícita de siempre
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta)).status_code == 200
    r = c.post(RUTA, headers=H(tok), json={"operacion": "editar", "id": pid, "cambios": {"precio": 9}})
    assert r.status_code == 401 and r.json()["detail"]["codigo"] == sinc.CODIGO_REVOCADA
    assert _p(eid_a, pid).precio == 1200


# ---------------------------------------------------------------------------------------------------------------- red del local
def test_la_red_del_local_conserva_el_codigo_desplazado(monkeypatch):
    eid, t = _empresa("-t9i", "3101942518")
    _modo_local_red(monkeypatch)
    _poner_cfg(eid, red={"clave_hash": sinc._hash("clave-red-t9i"), "pcs": []})
    with Session(engine_empresa(eid)) as s:
        for i, cod in ((5, "VIEJO-T9I"), (6, "LIBERAR-T9I")):
            s.add(Producto(id=3 * R + i, empresa_id=eid, nombre=f"De la PC tres {i}", cabys=CABYS, precio=1, es_servicio=True, inventariable=False, tipo="Servicio", codigo=cod))
        s.commit()
    base = {"cabys": CABYS, "precio": 1, "es_servicio": True, "inventariable": False, "tipo": "Servicio"}
    cuerpo = {"terminal": 3, "nombre": "PC tres", "productos": [
        {**base, "id": 3 * R + 5, "nombre": "De la PC tres 5", "codigo": "NUEVO-T9I", "codigos_alternos": None},
        {**base, "id": 3 * R + 6, "nombre": "De la PC tres 6", "codigo": None, "codigos_alternos": None, "activo": False}]}   # «eliminar» con ventas
    r = c.post("/api/sinc/red/3101942518/cambios", headers={"X-Clave-Red": "clave-red-t9i"}, json=cuerpo)
    assert r.status_code == 200 and r.json()["productos"] == 2, r.text
    p5, p6 = _p(eid, 3 * R + 5), _p(eid, 3 * R + 6)
    assert p5.codigo == "NUEVO-T9I" and p5.codigos_alternos == "VIEJO-T9I"          # el desplazado queda como alterno
    assert p6.codigo is None and not p6.codigos_alternos and not p6.activo          # el liberado queda libre


# ---------------------------------------------------------------------------------------------------------------- pantalla
def test_la_ficha_avisa_que_el_item_es_de_la_web():
    js = (RAIZ / "app" / "static" / "js" / "pages" / "inventario" / "item-form.js").read_text(encoding="utf-8")
    assert ('<p class="small muted" v-if="deLaWeb" style="margin:-6px 0 12px">Este ítem se creó en la página web: sus cambios se guardan allá en el momento '
            '(hace falta internet).</p>') in js
    assert "deLaWeb() { const r = sesion.empresaInfo?.es_local ? +(sesion.empresaInfo?.rango_items || 0) : 0; return !!(r && this.editando && (r < 0 || Math.floor(+this.params.id / 10000000) !== r)); }" in js
    items = (RAIZ / "app" / "static" / "js" / "pages" / "inventario" / "items.js").read_text(encoding="utf-8")
    assert "(r.aviso ? ' · ' + r.aviso : ''), r.aviso ? 'err' : 'ok');" in items


def test_el_programa_sabe_su_rango(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-t9j", "3101942519", "3101942520")
    with Session(engine) as sc:
        e = sc.get(auth.Empresa, eid_b)
        assert auth._info_empresa(e)["rango_items"] == 2
    assert sinc.va_a_la_web(eid_b, 5) and not sinc.va_a_la_web(eid_b, 2 * R + 5) and sinc.va_a_la_web(eid_b, 3 * R + 5)
    assert not sinc.va_a_la_web(eid_a, 5)                              # la web nunca manda a otra parte
    _poner_cfg(eid_b, vinculado=False)
    assert not sinc.va_a_la_web(eid_b, 5)
