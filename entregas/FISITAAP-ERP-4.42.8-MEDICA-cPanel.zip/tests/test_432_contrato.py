"""4.32, día 1 (contrato): main._cliente_con_historial(s, eid, cid) sacada de borrar_cliente sin cambiar la regla (R238), y el
interruptor FE_SINC_DATOS apagado para las pruebas viejas (tests/conftest.py)."""
import os
import random
from types import SimpleNamespace

from sqlmodel import Session

from app import auth, main, modulos
from app.db import Cliente, Documento, engine, engine_empresa, init_db

init_db()


def _empresa() -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Contrato 432 QA", f"contrato432-{random.randint(1, 10**9)}@example.test", "31010" + str(random.randint(10**4, 10**5 - 1)))
        return e.id


def _cliente(s: Session, eid: int, nombre: str) -> int:
    c = Cliente(empresa_id=eid, nombre=nombre, tipo_id="", numero_id="")
    s.add(c); s.commit(); s.refresh(c)
    return c.id


def _ctx(eid: int):
    return SimpleNamespace(empresa=SimpleNamespace(id=eid))


def test_conftest_apaga_el_canal_nuevo():
    assert os.environ.get("FE_SINC_DATOS") == "0"


def test_cliente_con_historial_misma_regla_que_borrar_cliente():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        libre = _cliente(s, eid, "Sin historia")
        assert main._cliente_con_historial(s, eid, libre) is False
        # con un comprobante
        con_doc = _cliente(s, eid, "Con comprobante")
        s.add(Documento(empresa_id=eid, tipo_documento="04", clave="5" * 49 + "1", consecutivo="00100001040000000001",
                        fecha_emision="2026-11-13T10:00:00-06:00", cliente_id=con_doc))
        s.commit()
        assert main._cliente_con_historial(s, eid, con_doc) is True
        # con un cobro
        con_pago = _cliente(s, eid, "Con cobro")
        s.add(modulos.Pago(empresa_id=eid, numero=1, cliente_id=con_pago)); s.commit()
        assert main._cliente_con_historial(s, eid, con_pago) is True
        # usado en gastos (registro «compras» como proveedor)
        proveedor = _cliente(s, eid, "Proveedor en compras")
        modulos.reemplazar(s, eid, "compras", [{"id": 1, "proveedor_id": proveedor}], version=0)
        assert main._cliente_con_historial(s, eid, proveedor) is True
        assert main._cliente_con_historial(s, eid, libre) is False


def test_borrar_cliente_decide_con_la_funcion(monkeypatch):
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        a = _cliente(s, eid, "Se desactiva")
        b = _cliente(s, eid, "Se borra")
        llamadas = []
        monkeypatch.setattr(main, "_cliente_con_historial", lambda s_, e_, c_: llamadas.append((e_, c_)) or c_ == a)
        assert main.borrar_cliente(a, ctx=_ctx(eid), s=s) == {"ok": True, "desactivado": True}
        assert main.borrar_cliente(b, ctx=_ctx(eid), s=s) == {"ok": True}
        assert llamadas == [(eid, a), (eid, b)]
        s.expire_all()
        assert s.get(Cliente, a).activo is False
        assert s.get(Cliente, b) is None


def test_borrar_cliente_de_punta_a_punta_sin_cambio_de_comportamiento():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        con = _cliente(s, eid, "Con cobro real")
        s.add(modulos.Pago(empresa_id=eid, numero=1, cliente_id=con)); s.commit()
        sin = _cliente(s, eid, "Sin nada")
        assert main.borrar_cliente(con, ctx=_ctx(eid), s=s) == {"ok": True, "desactivado": True}
        assert main.borrar_cliente(sin, ctx=_ctx(eid), s=s) == {"ok": True}
        assert main.borrar_cliente(999999, ctx=_ctx(eid), s=s) == {"ok": True}      # no existe: como siempre
        s.expire_all()
        assert s.get(Cliente, con).activo is False and s.get(Cliente, sin) is None
