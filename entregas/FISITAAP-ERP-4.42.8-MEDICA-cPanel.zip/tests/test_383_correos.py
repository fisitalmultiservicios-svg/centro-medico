"""3.83: diseño común de los correos. El logo va dentro del correo (imagen «cid:» en multipart/related, junto a los adjuntos);
el color de acento sale del logo de la empresa con contraste suficiente para el botón; el texto de los usuarios se escapa;
la factura, la bienvenida de la prueba gratis, el pedido y la prueba de correo salen con el diseño nuevo."""
import io

from PIL import Image, ImageDraw
from sqlmodel import Session

from app import correo, correo_diseno as dz, demo, pedidos, sitio
from app import main as m
from app.db import Documento, Empresa, engine, engine_empresa, init_db
from tests.test_correo_copia import LINEAS, SmtpFalso
from tests.test_exoneraciones import api  # noqa: F401  (fixture)


def _html_de(msg) -> str:
    return next(p for p in msg.walk() if p.get_content_type() == "text/html").get_content()


def _contraste(hex_color: str) -> float:
    rgb = [int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]
    return 1.05 / (dz._lum(rgb) + 0.05)


def test_el_logo_va_dentro_del_correo_con_los_adjuntos(monkeypatch):
    SmtpFalso.enviados = []
    monkeypatch.setattr(correo, "_conectar", lambda cfg, timeout=30: SmtpFalso())
    html = dz.armar(dz.plataforma(), titulo="Bienvenida", saludo="Hola <script>alert(1)</script>", datos=[("Correo", "a@example.test")],
                    boton_=("Entrar", "https://fisitaap.example.test/app/"))
    assert html.imagenes and "<script>" not in html and "&lt;script&gt;" in html
    cid = html.imagenes[0][0]
    assert f'src="cid:{cid}"' in html and "https://fisitaap.example.test/app/" in html
    cfg = correo.ConfigSMTP("smtp.example.test", 465, "u", "p", "sistema@example.test")
    correo.enviar(cfg, ["x@example.test"], "Prueba", html, "texto", [("f.pdf", b"%PDF-1.4", "application", "pdf")])
    msg = SmtpFalso.enviados[-1][0]
    tipos = [p.get_content_type() for p in msg.walk()]
    assert tipos[0] == "multipart/mixed" and {"multipart/alternative", "text/plain", "multipart/related", "text/html", "image/png", "application/pdf"} <= set(tipos)
    img = next(p for p in msg.walk() if p.get_content_type() == "image/png")
    assert img["Content-ID"] == f"<{cid}>" and img.get_content_disposition() == "inline"
    rel = next(p for p in msg.walk() if p.get_content_type() == "multipart/related")
    assert [p.get_content_type() for p in rel.iter_parts()] == ["text/html", "image/png"]
    # un HTML simple sigue saliendo igual, sin imágenes
    correo.enviar(cfg, ["x@example.test"], "Simple", "<p>x</p>", "x", [])
    assert "image/png" not in [p.get_content_type() for p in SmtpFalso.enviados[-1][0].walk()]
    # vista previa en el navegador: el cid pasa a data:
    vista = dz.para_navegador(html)
    assert "cid:" not in vista and "data:image/png;base64," in vista


def test_color_y_placa_del_logo(tmp_path):
    amarillo = tmp_path / "amarillo.png"
    im = Image.new("RGBA", (300, 100), (255, 255, 255, 0))
    ImageDraw.Draw(im).rectangle((40, 20, 260, 80), fill=(245, 200, 10, 255))
    im.save(amarillo)
    color = dz.color_de_logo(amarillo)
    assert color and _contraste(color) >= 4.5                         # el amarillo se oscurece hasta que el botón se lea
    gris = tmp_path / "gris.png"
    Image.new("RGB", (200, 80), (90, 90, 90)).save(gris)
    assert dz.color_de_logo(gris) is None                             # sin color claro: el acento de siempre
    png, ancho, alto = dz._placa(amarillo, 210, 64, placa=True)
    p = Image.open(io.BytesIO(png))
    assert p.getpixel((0, 0))[3] == 0 and p.getpixel((p.width // 2, 4))[:3] == (255, 255, 255)   # esquinas transparentes, placa blanca
    assert ancho <= 226 and alto <= 80
    rem = dz.Remitente(nombre="Agencia QA", logo=amarillo, color=color)
    h = dz.armar(rem, titulo="Hola", boton_=("Ver", "https://x.example.test/"))
    assert f'bgcolor="{color}"' in h and len(h.imagenes) == 1 and "Enviado con" in h


def test_la_factura_sale_con_el_diseno_y_el_mensaje(api, monkeypatch):  # noqa: F811
    c = api
    cli = c.post("/api/clientes", json={"nombre": "Cliente 383", "tipo": "Cliente", "tipo_id": "01", "numero_id": "101830383", "correo": "cliente383@example.test"}).json()
    doc = c.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "lineas": LINEAS}).json()
    with Session(engine_empresa(doc["empresa_id"])) as s:
        d = s.get(Documento, doc["id"]); d.estado = "aceptado"; s.add(d); s.commit()
    with Session(engine) as s0:
        e = s0.get(Empresa, doc["empresa_id"]); s0.expunge(e)
    e.smtp_host, e.smtp_remitente = "smtp.example.test", "facturas@example.test"
    monkeypatch.setattr(m.secretos, "descifrar", lambda *a, **k: "clave")
    SmtpFalso.enviados = []
    monkeypatch.setattr(correo, "_conectar", lambda cfg, timeout=30: SmtpFalso())
    with Session(engine_empresa(e.id)) as s:
        d = s.get(Documento, doc["id"])
        m._correo_comprobante(s, e, d, ["cliente383@example.test"], mensaje="Le adjunto <la> factura")
        consecutivo = d.consecutivo
    msg = SmtpFalso.enviados[-1][0]
    html = _html_de(msg)
    assert "Le enviamos su factura de venta electrónica" in html
    assert consecutivo in html and "Le adjunto &lt;la&gt; factura" in html
    assert "Hola Cliente 383," in html and "Enviado con" in html and "<!doctype html>" in html
    assert {"application/pdf", "application/xml"} <= {p.get_content_type() for p in msg.walk()}


def test_bienvenida_de_la_prueba_gratis(monkeypatch):
    init_db()
    enviados = []
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: correo.ConfigSMTP("smtp.example.test", 465, None, None, "sistema@example.test"))
    monkeypatch.setattr(correo, "enviar", lambda cfg, para, asunto, html, texto, adj, cc=None: enviados.append((asunto, html, texto)))
    assert demo._bienvenida({"correo": "nuevo383@example.test", "password_temporal": "Clave-Prueba-0000", "vence": "2026-12-04"}, "Ana")
    asunto, html, texto = enviados[0]
    assert "Su prueba gratis está lista" in html and "04/12/2026" in html and "Clave-Prueba-0000" in html and "<pre" not in html
    assert html.imagenes and "Clave-Prueba-0000" in texto                # el texto plano sigue con los datos


def test_correo_del_pedido_al_cliente():
    d = {"numero": 48, "nombre": "María <b>", "correo": "m@example.test", "lineas": [{"cantidad": 2, "detalle": "Logo", "total": 30000, "nota": "Rojo"}],
         "total": 32000, "envio": 2000, "descuento": 0, "tarjeta_monto": 0, "pago_monto": 0, "tipo": "A domicilio", "direccion": "San José", "hora": None,
         "motivo": None, "enlace": "https://fisitaap.example.test/brillante/p/48", "token": "t"}
    html, texto = pedidos._plantilla_cliente("Brillante QA", "#ff0000", "Recibimos su pedido #48", "Ya lo recibimos.", d)
    assert "Ver el estado del pedido" in html and "₡32.000" in html and "₡30.000" in html and "₡2.000" in html
    assert "María &lt;b&gt;" in html and "Seguimiento:" in texto
    assert "Por pagar al recibir" not in html                           # sin pagos previos no hay saldo aparte


def test_prueba_de_correo(monkeypatch):
    enviados = []
    monkeypatch.setattr(correo, "enviar", lambda *a, **k: enviados.append(a))
    correo.probar(correo.ConfigSMTP("smtp.example.test", 465, None, None, "a@example.test", seguridad="ssl"), "b@example.test", "Empresa QA")
    _cfg, para, asunto, html, texto, _adj = enviados[0]
    assert para == ["b@example.test"] and "El correo funciona" in html and "smtp.example.test:465" in html and "SSL" in html
