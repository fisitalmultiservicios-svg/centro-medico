# -*- coding: utf-8 -*-
"""4.39, el cobro de la venta rápida que viene de la 4.29 (revisión del 14 nov 2026). En una caja de restaurante, al cobrar la venta
rápida con platos sin enviar, el cobro manda la comanda automática y esa comanda guarda la cuenta (persistirCuenta) DESPUÉS de que el
cobro tomó el total, los medios y los platos que cierra. Si la cuenta ya estaba guardada (la venta rápida había mandado otra comanda antes)
y otro equipo la tocó con la ventana de cobro abierta:
- otro equipo le agregó un plato (o cambió una cantidad): el plato entraba al comprobante sin estar en el total ni en los medios y además
  quedaba en la cuenta sin cobrar. Ahora no se emite: aviso, la ventana sigue abierta con el total nuevo y al tocar otra vez se cobra todo
  una sola vez (la comanda no sale otra vez);
- otro equipo ya la cobró: la comanda la rehacía con otro id, el cobro se pedía al servidor para ese id nuevo, el servidor decía «ganada» y
  se cobraba dos veces. Ahora no se emite: el aviso de «ya se cobró en otro equipo», la ventana se cierra y en pantalla queda solo lo que
  no se había cobrado (lo que acaba de salir a cocina), que se cobra después una vez.
Un solo equipo (nada cambió) y la venta rápida nueva (sin cuenta guardada al empezar) cobran exactamente como antes.
4.39 (revisión): si esta caja ya sabía que la cuenta se cobró o se cerró (no está en su lista), no sale la comanda ni se emite: guardarla
la rehacía con lo enviado hace menos de 20 s (regla de la 4.6) y al segundo toque se cobraba otra vez; en pantalla queda, como venta
nueva, lo no enviado. Y un alta que todavía no había subido y a la que el servidor le dio otro id (chocó con la de otra caja) no es una
cuenta cobrada en otro equipo: se cobra con el id nuevo, sin aviso.
4.39 (segunda vuelta, R2): con la cuenta ya en el servidor, después de ganar el cobro se trae la lista, se junta lo de otro equipo y se
compara ANTES de la comanda: si otro equipo agregó o quitó algo, no sale comanda ni se emite en ese toque (antes la comanda salía igual,
sin lo agregado o con lo quitado); al tocar otra vez sale una comanda con lo que se cobra y una emisión.
Los métodos reales de caja.js en dos «equipos» (cada uno con su api.js y su _fusion.js), con el arnés y el servidor falso de
tests/test_431_cobro_reclamo_pantallas.py. Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
from tests.test_431_cobro_reclamo_pantallas import _correr
from tests.test_431_misma_mesa_pantallas import _js, _linea, _metodo

CAMBIO = "La cuenta cambió en otro equipo y aquí no se cobró nada. Revise el total antes de cobrar."
COBRADA = "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."
CERRADA = ("Esta cuenta fue cobrada o cerrada en otro equipo y aquí no se cobró nada. Lo que no se había enviado sigue en pantalla como "
           "venta nueva: revise el total antes de cobrar.")                     # 4.39 (revisión): esta caja ya lo sabía
CASADO, LIMONADA, POSTRE = 3955.0, 1695.0, 1356.0          # con 13 % de IVA


def _guion(casos: str) -> str:
    k = _js("pages/pos/caja.js")
    computadas = ", ".join(_linea(k, n + "() {") for n in ("esVentaRapida", "totalCobro", "porCobrar"))
    return """
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
const CMP = { @CMP@ };
// la caja en la venta rápida (computadas reales de caja.js) y los platos con destino a la cocina
const venta = vm => { for (const [n, f] of Object.entries(CMP)) Object.defineProperty(vm, n, { get() { return f.call(this); }, configurable: true }); Object.assign(vm, { vista: 'venta', rapida: true, mesaActual: null, destinoDe: () => COCINA }); return vm; };
// la venta rápida de A ya mandó su comanda (el Casado, hace un minuto o `hace` ms) y quedó guardada; B, otro equipo, tiene esa cuenta abierta
async function rapida(conOtro, hace) {
  reiniciarCobro(); reiniciar();
  const a = venta(await equipo());
  a.lineas.push({ ...CASADO(), enviado: new Date(Date.now() - (hace || 60000)).toISOString(), ronda: 1 }); a.persistirCuenta(); await a.A.mock.guardarTodo();
  let b = null;
  if (conOtro) { b = venta(await equipo()); await b.sincronizar(); b.cargarCuenta(b.espera.find(x => x.id === a.esperaId)); }
  return [a, b];
}
const detalles = vm => vm.lineas.map(l => l.detalle + '×' + l.cantidad).sort();
const comandas = vm => avisos(vm).filter(t => t.startsWith('Comanda '));
const CAMBIO = %(cambio)s, CERRADA = %(cerrada)s;
const deEste = vm => avisos(vm).filter(t => t === CAMBIO || t === AVISO_COBRADA || t === CERRADA);
const hechos = () => C.emitidos.map(e => [e.n, e.total, e.lineas.slice().sort()]);
const orden = () => C.llamadas.map(x => x[1]).filter(u => u.startsWith('/api/pos/cobro/') || u === '/api/comprobantes');
const pantalla = vm => ({ pago: !!vm.pago, cobrando: vm.cobrando, platos: detalles(vm), total: vm.totales.total, medios: vm.pago ? vm.pago.medios.map(m => [m.medio, m.monto]) : null, cuenta: vm.esperaId });
""".replace("@CMP@", computadas) % {"cambio": repr(CAMBIO), "cerrada": repr(CERRADA)} + casos


def _correr_439(tmp_path, casos):
    k = _js("pages/pos/caja.js")
    return _correr(tmp_path, _guion(casos), mas=(_linea(k, "propinaCambio() {"), _linea(k, "recibidoCambio() {")))


# ================================================================================================================ un solo equipo
def test_un_solo_equipo_y_la_venta_rapida_nueva_cobran_como_siempre_en_node(tmp_path):
    r = _correr_439(tmp_path, """
// la venta rápida que ya mandó comanda, con un plato más sin enviar: la comanda sale una vez, se emite una vez, sin avisos
let [a] = await rapida(false);
a.lineas.push(POSTRE()); await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.normal = { hechos: hechos(), comandas: comandas(a), avisos: deEste(a), orden: orden(), servidor: servidor(), pago: a.pago, cobrando: a.cobrando, platos: a.lineas.length, n: a.nEq };
// 4.39 (revisión): lo mismo con la comanda anterior de hace 5 s (la cuenta sigue en la lista: se cobra como siempre)
[a] = await rapida(false, 5000);
a.lineas.push(POSTRE()); await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.normal_5s = { hechos: hechos(), comandas: comandas(a), avisos: deEste(a), orden: orden(), servidor: servidor(), pago: a.pago, cobrando: a.cobrando, platos: a.lineas.length, n: a.nEq };
// la venta rápida nueva (sin cuenta guardada al empezar): la comanda la guarda y el cobro la cierra, sin pedir el cobro al servidor
reiniciarCobro(); reiniciar(); const v = venta(await equipo());
v.lineas.push(CASADO(), POSTRE()); await v.abrirPago(); await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo();
out.nueva = { hechos: hechos(), comandas: comandas(v), avisos: deEste(v), orden: orden(), servidor: servidor(), pago: v.pago, n: v.nEq };
// la venta rápida que ya mandó comanda y no tiene nada nuevo: no hay comanda y se cobra como siempre
[a] = await rapida(false);
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.sin_nuevos = { hechos: hechos(), comandas: comandas(a), avisos: deEste(a), servidor: servidor() };
""")
    for k in ("normal", "normal_5s"):
        n = r[k]
        assert n["hechos"] == [[n["n"], CASADO + POSTRE, ["Casado×1", "Postre×1"]]], (k, r)
        assert n["comandas"] == ["Comanda 2 enviada a Cocina"] and n["avisos"] == [], (k, r)
        assert n["orden"] == ["/api/pos/cobro/reclamar", "/api/comprobantes", "/api/pos/cobro/soltar", "/api/pos/cobro/soltar"], (k, r)   # pedir, emitir, anotar y soltar
        assert n["servidor"] == [] and n["pago"] is None and n["cobrando"] is False and n["platos"] == 0, (k, r)
    v = r["nueva"]
    assert v["hechos"] == [[v["n"], CASADO + POSTRE, ["Casado×1", "Postre×1"]]] and v["comandas"] == ["Comanda 1 enviada a Cocina"], r
    assert v["avisos"] == [] and v["orden"] == ["/api/comprobantes"] and v["servidor"] == [] and v["pago"] is None, r   # como en la 4.29: sin pedir el cobro
    s = r["sin_nuevos"]
    assert len(s["hechos"]) == 1 and s["hechos"][0][1] == CASADO and s["comandas"] == [] and s["avisos"] == [] and s["servidor"] == [], r


# ================================================================================================================ otro equipo agregó
def test_otro_equipo_agrego_un_plato_con_la_ventana_de_cobro_abierta_en_node(tmp_path):
    r = _correr_439(tmp_path, """
// A abre el cobro (Casado + Postre sin enviar); B agrega la Limonada y la manda a cocina; A ya la tiene en su copia, no en pantalla
let [a, b] = await rapida(true);
a.lineas.push(POSTRE()); await a.abrirPago();
b.lineas.push(LIMONADA()); b.enviarComanda(); await b.A.mock.guardarTodo();
await a.sincronizar();
out.antes = pantalla(a);
await a.cobrar(); await hastaLibre();
out.tras = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), reclamos: reclamos(), servidor: servidor().map(x => ({ ...x, sinEnviar: S.items.find(y => y.id === x.id).lineas.filter(l => !l.enviado).map(l => l.detalle) })), comandas: comandas(a) };
// al tocar otra vez: se cobra todo una sola vez y la comanda no sale otra vez
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.luego = { hechos: hechos(), comandas: comandas(a), servidor: servidor(), avisos: deEste(a), n: a.nEq };
// otro equipo cambió una cantidad (2 Casados): tampoco se emite; el efectivo recibido queda como estaba y la ventana dice el total nuevo
[a, b] = await rapida(true);
a.lineas.push(POSTRE()); await a.abrirPago(); a.pago.recibido = 20000; a.recibidoCambio();
b.lineas[0].cantidad = 2; b.persistirCuenta(); await b.A.mock.guardarTodo();
await a.sincronizar(); await a.cobrar(); await hastaLibre();
out.cantidad = { ...pantalla(a), hechos: hechos(), avisos: deEste(a) };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.cantidad.luego = { hechos: hechos(), servidor: servidor() };
// otro equipo le puso un descuento al Casado (los mismos platos y cantidades, otro total): tampoco se emite
[a, b] = await rapida(true);
a.lineas.push(POSTRE()); await a.abrirPago();
b.lineas[0].descuento_pct = 10; b.persistirCuenta(); await b.A.mock.guardarTodo();
await a.sincronizar(); await a.cobrar(); await hastaLibre();
out.descuento = { ...pantalla(a), hechos: hechos(), avisos: deEste(a) };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.descuento.luego = { hechos: hechos(), servidor: servidor() };
// la Limonada todavía no había llegado a esta caja. 4.39 (segunda vuelta, R2): con un plato sin enviar (el Postre), antes de la comanda se
// trae la lista y se junta: la Limonada entra, no se emite (aviso y total nuevo) y al segundo toque se cobra todo una vez
[a, b] = await rapida(true);
a.lineas.push(POSTRE()); await a.abrirPago();
b.lineas.push(LIMONADA()); b.enviarComanda(); await b.A.mock.guardarTodo();
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.sin_saber = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), servidor: servidor(), comandas: comandas(a), reclamos: reclamos() };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.sin_saber.luego = { hechos: hechos(), avisos: deEste(a), servidor: servidor(), comandas: comandas(a), n: a.nEq };
// sin platos por enviar no hay comanda ni nada que juntar antes: se cobra lo de la pantalla y la Limonada queda en la cuenta, como en la 4.31
[a, b] = await rapida(true);
await a.abrirPago();
b.lineas.push(LIMONADA()); b.enviarComanda(); await b.A.mock.guardarTodo();
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.sin_saber_sin_platos = { hechos: hechos(), avisos: deEste(a), servidor: servidor(), comandas: comandas(a) };
""")
    a = r["antes"]
    assert a["platos"] == ["Casado×1", "Postre×1"] and a["total"] == CASADO + POSTRE, r
    t = r["tras"]
    # antes: un tiquete con la Limonada fuera del total. 4.39 (revisión de los arreglos): la cuenta ya estaba en el servidor, así que el cobro se
    # pidió antes de la comanda (reclamos 1) y, al ver el cambio, se soltó: al tocar otra vez se cobra (abajo)
    assert t["hechos"] == [] and t["reclamos"] == 1, r
    assert t["avisos"] == [CAMBIO] and t["pago"] is True and t["cobrando"] is False, r
    total = CASADO + LIMONADA + POSTRE
    assert t["platos"] == ["Casado×1", "Limonada×1", "Postre×1"] and t["total"] == total and t["medios"] == [["01", total]], r   # el total nuevo
    assert [(x["id"], sorted(x["platos"])) for x in t["servidor"]] == [(1, ["Casado×1", "Limonada×1", "Postre×1"])], r   # el Postre quedó guardado en la cuenta
    # 4.39 (segunda vuelta, R2): la comanda sale DESPUÉS de juntar lo que guardó otro equipo; como la cuenta cambió (la Limonada), no se
    # emite y tampoco sale comanda en este toque (antes salía el Postre aquí). Sale una sola vez, en el toque siguiente (abajo)
    assert t["comandas"] == [], r
    assert [sorted(l for l in x["sinEnviar"]) for x in t["servidor"]] == [["Postre"]], r          # el Postre sigue sin enviar: sale al cobrar
    lu = r["luego"]
    assert lu["hechos"] == [[lu["n"], total, ["Casado×1", "Limonada×1", "Postre×1"]]] and lu["servidor"] == [], r
    # 4.39 (segunda vuelta, R2): una sola comanda, al segundo toque y ya con la Limonada de B junta: por eso es la ronda 3 (la 2 fue la de B).
    # Antes salía en el primer toque, sin la Limonada, como «Comanda 2» (el mismo número que la de B)
    assert lu["comandas"] == ["Comanda 3 enviada a Cocina"] and lu["avisos"] == [CAMBIO], r   # una sola comanda, un solo aviso
    c = r["cantidad"]
    assert c["hechos"] == [] and c["avisos"] == [CAMBIO] and c["pago"] is True, r
    assert c["platos"] == ["Casado×2", "Postre×1"] and c["total"] == 2 * CASADO + POSTRE and c["medios"] == [["01", 20000]], r
    assert len(c["luego"]["hechos"]) == 1 and c["luego"]["hechos"][0][1] == 2 * CASADO + POSTRE and c["luego"]["servidor"] == [], r
    d, con_desc = r["descuento"], 4915.5                                                       # (3500 − 10 %) con IVA + Postre
    assert d["hechos"] == [] and d["avisos"] == [CAMBIO] and d["pago"] is True and d["platos"] == ["Casado×1", "Postre×1"], r
    assert d["total"] == con_desc and d["medios"] == [["01", con_desc]], r                   # el total nuevo, con el descuento
    assert len(d["luego"]["hechos"]) == 1 and d["luego"]["hechos"][0][1] == con_desc and d["luego"]["servidor"] == [], r
    # 4.39 (segunda vuelta, R2): antes se cobraba Casado + Postre y la Limonada quedaba en la cuenta (también sin cobro doble). Ahora la caja
    # la trae antes de la comanda: no emite ni manda comanda en ese toque, avisa y deja el total nuevo; al segundo toque, una emisión con los
    # tres platos y una comanda (el Postre)
    s = r["sin_saber"]
    assert s["hechos"] == [] and s["avisos"] == [CAMBIO] and s["reclamos"] == 1 and s["comandas"] == [], r
    assert s["pago"] is True and s["platos"] == ["Casado×1", "Limonada×1", "Postre×1"] and s["total"] == total and s["medios"] == [["01", total]], r
    sl = s["luego"]
    assert sl["hechos"] == [[sl["n"], total, ["Casado×1", "Limonada×1", "Postre×1"]]] and sl["servidor"] == [], r
    assert sl["comandas"] == ["Comanda 3 enviada a Cocina"] and sl["avisos"] == [CAMBIO], r
    s0 = r["sin_saber_sin_platos"]
    assert len(s0["hechos"]) == 1 and s0["hechos"][0][1] == CASADO and s0["avisos"] == [] and s0["comandas"] == [], r
    assert [x["platos"] for x in s0["servidor"]] == [["Limonada×1"]], r                        # lo que otro agregó queda en la cuenta sin cobrar


# ================================================================================================================ otro equipo cobró
def test_otro_equipo_cobro_la_cuenta_con_la_ventana_de_cobro_abierta_en_node(tmp_path):
    r = _correr_439(tmp_path, """
// A abre el cobro (Casado + Postre sin enviar); B cobra la cuenta (el Casado); A se entera (sabe) o todavía no. 4.39 (revisión): la
// comanda del Casado fue hace un minuto o hace 5 s (con menos de 20 s, guardar la cuenta la rehacía con el Casado: cobro doble)
for (const [nombre, sabe, hace] of [['no_sabe', false, 60000], ['sabe', true, 60000], ['no_sabe_5s', false, 5000], ['sabe_5s', true, 5000]]) {
  const [a, b] = await rapida(true, hace);
  a.lineas.push(POSTRE()); await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  if (sabe) await a.sincronizar();
  await a.cobrar(); await hastaLibre();
  const o = out[nombre] = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), servidor: servidor().map(x => x.platos), reclamosA: reclamos(a.nEq), comandas: comandas(a), a: a.nEq, b: b.nEq };
  // en pantalla queda lo que no se había cobrado: se cobra una vez
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos(), servidor: servidor(), comandas: comandas(a), avisos: deEste(a), suma: suma() };
}
// 4.39 (revisión): B cobra antes de que A abra la ventana; A agrega el Postre y abre el cobro (la lista ya llega sin la cuenta)
for (const [nombre, hace] of [['al_abrir', 60000], ['al_abrir_5s', 5000]]) {
  const [a, b] = await rapida(true, hace);
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  a.lineas.push(POSTRE()); a._alDia = 0; await a.abrirPago();
  await a.cobrar(); await hastaLibre();
  const o = out[nombre] = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), servidor: servidor().map(x => x.platos), reclamosA: reclamos(a.nEq), comandas: comandas(a), a: a.nEq, b: b.nEq };
  a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos(), servidor: servidor(), comandas: comandas(a), avisos: deEste(a), suma: suma() };
}
""")
    # A todavía no lo sabía. 4.39 (revisión de los arreglos): la cuenta ya estaba en el servidor, así que A pide el cobro ANTES de la comanda; el
    # servidor dice «cobrada» (reclamosA 1): no sale comanda (antes salía la del Postre, que no se cobraba ahí) y no se rehace ninguna cuenta
    for k in ("no_sabe", "no_sabe_5s"):
        x = r[k]
        assert x["hechos"] == [[x["b"], CASADO, ["Casado×1"]]] and x["reclamosA"] == 1, (k, r)   # antes de la 4.39: el Casado otra vez (dos tiquetes)
        assert x["avisos"] == [COBRADA] and x["pago"] is False and x["cobrando"] is False, (k, r)
        assert x["platos"] == ["Postre×1"] and x["total"] == POSTRE and x["servidor"] == [] and x["cuenta"] is None, (k, r)   # en pantalla, venta nueva con lo agregado
        assert x["comandas"] == [], (k, r)
        lu = x["luego"]
        assert lu["hechos"] == [[x["b"], CASADO, ["Casado×1"]], [x["a"], POSTRE, ["Postre×1"]]] and lu["servidor"] == [] and lu["suma"] == CASADO + POSTRE, (k, r)
        assert lu["comandas"] == ["Comanda 1 enviada a Cocina"] and lu["avisos"] == [COBRADA], (k, r)   # el Postre sale a cocina una vez, al cobrarlo
    for k in ("sabe", "sabe_5s", "al_abrir", "al_abrir_5s"):   # A ya lo sabía: ni comanda ni cobro, la cuenta no se rehace
        x = r[k]
        assert x["hechos"] == [[x["b"], CASADO, ["Casado×1"]]] and x["reclamosA"] == 0, (k, r)   # antes, con 5 s: Casado + Postre al segundo toque
        assert x["avisos"] == [CERRADA] and x["pago"] is False and x["cobrando"] is False and x["comandas"] == [], (k, r)
        assert x["platos"] == ["Postre×1"] and x["total"] == POSTRE and x["servidor"] == [] and x["cuenta"] is None, (k, r)   # venta nueva, solo lo no enviado
        lu = x["luego"]
        assert lu["hechos"] == [[x["b"], CASADO, ["Casado×1"]], [x["a"], POSTRE, ["Postre×1"]]] and lu["servidor"] == [] and lu["suma"] == CASADO + POSTRE, (k, r)
        assert lu["comandas"] == ["Comanda 1 enviada a Cocina"] and lu["avisos"] == [CERRADA], (k, r)   # el Postre sale a cocina una vez, al cobrarlo


# ================================================================================================================ alta que choca de id
def test_el_alta_de_la_venta_rapida_choca_de_id_con_otra_caja_en_node(tmp_path):
    """4.39 (revisión): el alta de la cuenta de A todavía no subió y otra caja sube primero la suya con el mismo id; al guardarla con la
    comanda del cobro, el servidor le da otro id a la de A. Nadie más pudo cobrarla: se cobra con el id nuevo, sin aviso y una sola vez
    (antes: «Esta cuenta ya se cobró en otro equipo», la ventana se cerraba y no se cobraba nada)."""
    r = _correr_439(tmp_path, """
reiniciarCobro(); reiniciar();
const a = venta(await equipo()), b = venta(await equipo());
a.lineas.push(CASADO()); a.enviarComanda();                                    // el alta de A queda aquí, todavía sin subir (la red tarda)
out.antes = [a.esperaId, !!a.A.mock.pendientes];
b.lineas.push(LIMONADA()); b.enviarComanda(); await b.A.mock.guardarTodo();     // la de B sube primero, con el mismo id
out.srv0 = servidor().map(x => [x.id, x.platos]);
// A agrega el Postre; la ventana de cobro se abrió antes de que su alta subiera
a.lineas.push(POSTRE());
a.pago = { tipo_documento: '04', medios: [{ medio: '01', monto: a.totales.total }], recibido: null, propina: 0, moneda: 'CRC', recibido_usd: null, tc: 0, debe: null };
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.tras = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), comandas: comandas(a), reclamos: reclamos(a.nEq), servidor: servidor().map(x => [x.id, x.platos]), a: a.nEq };
""")
    assert r["antes"] == [1, True] and r["srv0"] == [[1, ["Limonada×1"]]], r
    t = r["tras"]
    assert t["hechos"] == [[t["a"], CASADO + POSTRE, ["Casado×1", "Postre×1"]]] and t["reclamos"] == 1, r
    assert t["avisos"] == [] and t["pago"] is False and t["cobrando"] is False and t["platos"] == [] and t["cuenta"] is None, r
    assert t["comandas"] == ["Comanda 1 enviada a Cocina", "Comanda 2 enviada a Cocina"], r
    assert t["servidor"] == [[1, ["Limonada×1"]]], r                                          # la cuenta de la otra caja sigue intacta


def test_la_cuenta_cambia_de_id_mientras_se_espera_la_clave_del_supervisor_en_node(tmp_path):
    """4.39 (revisión): B cobra la cuenta y, mientras A espera la clave del supervisor (descuento mayor al de la caja), sube un guardado de
    A y el servidor la rehace con otro id (con el Postre). No se cobra ahí y A sigue con ESA cuenta: no queda otra cuenta abierta con el
    Postre (que alguien podría cobrar otra vez) y el Postre se cobra una sola vez, con su descuento."""
    r = _correr_439(tmp_path, """
const [a, b] = await rapida(true);
a.cfg.descuento_max_pct = 5;
a.lineas.push({ ...POSTRE(), descuento_pct: 10, descuento_manual: true }); await a.abrirPago();
await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
a.autorizar = async () => { a.persistirCuenta(); await a.A.mock.guardarTodo(); return true; };
await a.cobrar(); await hastaLibre();
out.tras = { ...pantalla(a), hechos: hechos(), avisos: deEste(a), servidor: servidor().map(x => [x.id, x.platos]), comandas: comandas(a), a: a.nEq, b: b.nEq };
a.autorizar = async () => true;
a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.luego = { hechos: hechos(), servidor: servidor(), suma: suma(), comandas: comandas(a), cuenta: a.esperaId };
""")
    t, postre = r["tras"], 1220.4                                                            # (1200 − 10 %) con IVA
    assert t["hechos"] == [[t["b"], CASADO, ["Casado×1"]]] and t["avisos"] == [COBRADA] and t["pago"] is False and t["cobrando"] is False, r
    assert t["platos"] == ["Postre×1"] and t["total"] == postre and t["cuenta"] == 2 and t["servidor"] == [[2, ["Postre×1"]]], r   # la misma cuenta en pantalla y en el servidor
    assert t["comandas"] == ["Comanda 2 enviada a Cocina"], r
    lu = r["luego"]
    assert lu["hechos"] == [[t["b"], CASADO, ["Casado×1"]], [t["a"], postre, ["Postre×1"]]] and lu["suma"] == CASADO + postre, r
    assert lu["servidor"] == [] and lu["cuenta"] is None and lu["comandas"] == ["Comanda 2 enviada a Cocina"], r   # sin otra cuenta abierta con el Postre


# ================================================================================================================ contrato
def test_contrato_del_cobro_de_la_venta_rapida():
    k = _js("pages/pos/caja.js")
    cobro = _metodo(k, "async emitirCobro(otra) {")
    # 4.39 (tercera vuelta, T3): la comanda se manda solo si al juntar queda algún plato sin enviar (otro equipo pudo mandarlos con
    # «Comanda»): sin el aviso falso «No hay platos nuevos por enviar» en un cobro que sale bien
    i_comanda = cobro.index("try { if (this.lineas.some(l => !l.enviado && +l.cantidad > 0)) this.enviarComanda(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }")
    i_revisa = cobro.index("const cambio = this.cobroCambiado(esperaId, lineasCobradas, total, alta0); if (cambio) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio; }")
    # 4.39 (revisión): la cuenta que esta caja ya sabe cerrada se revisa ANTES de la comanda (sin yaGuardada: tras la primera comanda daría false)
    # (solo si la cuenta sigue con el id con que empezó el cobro: si cambió mientras se esperaba el crédito o la clave, decide cobroCambiado sin «alta»)
    i_mismo = cobro.index("const mismoId = esperaId !== null && esperaId !== undefined && this.esperaId === esperaId;")
    i_cerrada = cobro.index("if (mismoId && !enEspera().some(v => v.id === esperaId)) return this.cobroDeCuentaCerrada();")
    i_alta = cobro.index("const alta0 = mismoId && !this.yaGuardada(esperaId);")
    # 4.39 (revisión de los arreglos): la cuenta que ya estaba en el servidor pide su cobro ANTES de la comanda (si dos equipos la cobran a la
    # vez, la comanda sale solo del que ganó); si después cambió (cobroCambiado), ese cobro pedido se suelta. La venta rápida nueva, como antes
    # 4.39 (segunda vuelta, R2): con la cuenta ya en el servidor, después de ganar el cobro se trae la lista, se revisa si la cuenta sigue, se
    # junta lo de otro equipo y se compara ANTES de la comanda (la comanda ya no imprime un plato quitado ni deja afuera uno agregado)
    # 4.39 (tercera vuelta, T3): lo que aquí estaba sin enviar (sin0) se toma ANTES de pedir el cobro; traer y juntar va en un bucle de dos
    # vueltas como mucho: si un plato de sin0 llegó enviado (otro equipo tocó «Comanda» y allá se revisa su comanda), 4 s y se junta otra vez
    i_pide = cobro.index("if (reclamar && mismoId && !alta0) {\n          const sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));")
    i_rc = cobro.index("          rcPedido = true; try { rc = await this.reclamarCobro(lineasCobradas); }")
    i_bucle = cobro.index("          for (let vuelta = 0; ; vuelta++) {\n            try { await Promise.race([mock.refrescar(['pos_espera'])")
    i_refresca = cobro.index("try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); }")
    i_cerrada2 = cobro.index("if (!enEspera().some(v => v.id === esperaId)) { if (rc && rc.clave) this.soltarCobro(rc, false); return this.cobroDeCuentaCerrada(); }")
    i_junta = cobro.index("try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }")
    # 4.39 (quinta vuelta, V1): la espera de 4 s solo por un plato que va a cocina (destinoDe) con una marca de envío de hace menos de 10 s
    # 4.39 (sexta vuelta, W6): en el bucle se espera solo lo que falta hasta la marca que dejó persistirCuenta al juntar (4 s si no es de esa cuenta)
    # 4.39 (séptima vuelta, X7): una tercera vuelta como mucho, solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó)
    i_otra = cobro.index("            if (vuelta > 1 || (vuelta ? !(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000) : "
                         "!this.lineas.some(l => l.enviado && sin0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)))) break;   "
                         "/* 4.39 (séptima vuelta): otra vuelta solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó) */\n"
                         "            { const ma = this._marcaAjena, falta = ma && ma.id === this.esperaId ? ma.t + 4000 - Date.now() : 4000; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }")
    i_cambio0 = cobro.index("const cambio0 = this.cobroCambiado(esperaId, lineasCobradas, total, alta0); if (cambio0) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio0; }")
    assert cobro.index("const lineasCobradas = this.lineas.map(") < cobro.index("let total = this.totales.total,") < i_mismo < i_cerrada < i_alta < i_pide < i_rc < i_bucle < i_refresca < i_cerrada2 < i_junta < i_otra < i_cambio0 < i_comanda < i_revisa < cobro.index("if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); }"), cobro[:200]
    # dos revisiones con cobroCambiado (tras juntar y tras la comanda), dos salidas a cobroDeCuentaCerrada (ya lo sabía / tras refrescar) y seis soltarCobro
    # 4.39 (sexta vuelta, W11): más la revisión de la mesa con el cobro pedido (V2) después de esperar la comanda de otro equipo: tres cobroCambiado
    # y ocho soltarCobro (la cuenta que ya no está va a cobroOcupado «cobrada»: siguen dos cobroDeCuentaCerrada). 4.39 (séptima vuelta, X3): ahora
    # va con «cerrada»; las cuentas no cambian
    assert cobro.count("this.cobroCambiado(") == 3 and cobro.count("this.cobroDeCuentaCerrada(") == 2 and cobro.count("this.soltarCobro(rc, ") == 8
    # R3: no mientras la habitación pide su cobro. 4.39 (cuarta vuelta, U3): en su propia línea (la segunda), con aviso en vez de callar
    assert cobro.startswith("async emitirCobro(otra) {\n      if (this.cobrando) return;\n      if (this._habEnCurso) return toast('Se está revisando el cargo a la habitación: espere un momento', 'err');")
    # 4.39 (cuarta vuelta, U2): la espera de la marca de otro equipo va con «cobrando» ya puesto, antes del bloque de la comanda y del reclamo
    i_marca = cobro.index("{ const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }")
    assert cobro.index("this.cobrando = true;") < cobro.index("const clienteId = this.clienteId, cliente = this.cliente, esperaId = this.esperaId,") < i_marca < cobro.index("let rc = null, rcPedido = false;") < i_mismo
    # 4.39 (tercera vuelta, T4): con `cargo` (desde reclamarHab) el aviso dice «aquí no se cargó nada»; sin él, el de siempre
    m = _metodo(k, "cobroCambiado(id0, lineas0, total0, alta0, cargo) {")
    assert "toast(cargo ? 'La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar.' : '" + CAMBIO + "', 'err');" in m
    assert "if (id0 === null || id0 === undefined) return null;" in m                          # venta rápida nueva: como siempre
    assert "const otraCuenta = this.esperaId !== id0 && alta0 !== true;" in m and "if (otraCuenta) return this.cobroOcupado({ resultado: 'cobrada', comunes: [] });" in m
    assert "this.propinaCambio()" in m and "'" + CAMBIO + "'" in m and "4.39" in k
    c = _metodo(k, "cobroDeCuentaCerrada() {")
    # 4.39 (revisión de los arreglos): queda solo lo que esta pantalla agregó sin guardar (lo guardado sin enviar ya estaba en la cuenta que el otro cobró)
    assert "this.cobrando = false; this.pago = null;" in c and "const g = lidsDeBase(this._base, this.esperaId); this.lineas = this.lineas.filter(l => !l.enviado && !g.has(l.lid)); this.esperaId = null;" in c
    assert "' fue cobrada o cerrada en otro equipo y aquí no se cobró nada.' + (this.lineas.length ? ' Lo que no se había enviado sigue en pantalla como venta nueva: revise el total antes de cobrar.' : '')" in c
    assert CERRADA.startswith("Esta cuenta") and "'La cuenta «' + m + '»' : 'Esta cuenta'" in c
