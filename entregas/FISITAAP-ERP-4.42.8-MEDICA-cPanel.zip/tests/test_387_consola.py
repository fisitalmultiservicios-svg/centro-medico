"""3.87: consola del sistema y seguridad de los administradores (QA 3.87, grupo consola).
- La consola exige cambiar la contraseña temporal, como el resto del sistema (R123).
- Un administrador con empresas ocultas no bloquea ni restablece la contraseña de quien pertenece a ellas, ni lo trae a otra empresa.
- Las membresías de un administrador del sistema solo las toca el super administrador (consola y Usuarios de la empresa), se ven en la
  consola, y ser miembro de una empresa oculta ya no la abre.
- El administrador del sistema que también es Cajero trabaja como Administrador (borradores, recurrentes, movimientos de inventario).
- Si la empresa de la sesión se borró, se ocultó o le quitaron el acceso, la sesión sigue sin empresa (y no se crea su base vacía).
- Solo el super administrador cambia la lista de IP permitidas.
- Al borrar una empresa (cuenta o demo) se liberan su nombre público, su dominio y su portal de TiKe.
- Traslados: el administrador del sistema ve el grupo del dueño de la empresa, nunca empresas de otros clientes ni las ocultas.
- Respaldos de la empresa: además de «configurar» piden «usuarios» (la base completa trae RRHH).
- Inicio de sesión: la espera por intentos fallidos es la misma exista o no el correo, y no deja afuera a la persona en su dispositivo;
  la marca del dispositivo, copiada, no da intentos sin fin y deja de valer al cambiar o restablecer la contraseña.
Todo con usuarios y empresas @example.test creados aquí y borrados al final."""
import re
import json
import pathlib
import types

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete as sa_delete
from sqlmodel import Session, select

from app import auth, pedidos
from app.db import EMPRESAS_DIR, Empresa, engine, init_db
from app.main import app

PW = "Clave-larga-387-consola"
SUF = ".387c@example.test"
NOMBRE = "C387 "


def H(t):
    return {"Authorization": "Bearer " + t}


def _usuario(s, nombre, **kw):
    correo = nombre + SUF
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
    if not u:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION, **kw)
        s.add(u); s.commit(); s.refresh(u)
    return u


def _empresa(s, nombre, cedula, **kw):
    return auth.crear_empresa(s, NOMBRE + nombre, nombre.lower() + SUF, cedula, provincia=1, canton=1, distrito=1, otras_senas="QA 387",
                              actividad="471101", telefono=22223870, factura_electronica=False, correo_automatico=False, **kw)


def _miembro(s, u, e, rol):
    s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()


def _token(uid, eid=None):
    with Session(engine) as s:
        return auth._respuesta(s, s.get(auth.Usuario, uid), eid)["token"]


def _ocultar(uid, ids):
    with Session(engine) as s:
        u = s.get(auth.Usuario, uid); u.empresas_ocultas = json.dumps(sorted(ids)); s.add(u); s.commit()


@pytest.fixture
def mundo():
    """Super administrador P, administrador normal N y administrador limitado L (con empresas ocultas), todos con dos pasos activos."""
    init_db()
    with Session(engine) as s:
        p = _usuario(s, "principal", es_superadmin=True, admin_principal=True, mfa_activo=True)
        n = _usuario(s, "normal", es_superadmin=True, mfa_activo=True)
        lim = _usuario(s, "limitado", es_superadmin=True, mfa_activo=True)
        ids = types.SimpleNamespace(p=p.id, n=n.id, l=lim.id, correo_p=p.correo, correo_l=lim.correo)
    try:
        yield TestClient(app), ids
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            us = s.exec(select(auth.Usuario).where(auth.Usuario.correo.like("%" + SUF))).all()  # type: ignore[attr-defined]
            uids = [u.id for u in us]
            es = s.exec(select(Empresa).where(Empresa.nombre.like(NOMBRE + "%"))).all()  # type: ignore[attr-defined]
            eids = [e.id for e in es]
            for m in s.exec(select(auth.UsuarioEmpresa)).all():
                if m.usuario_id in uids or m.empresa_id in eids:
                    s.delete(m)
            for x in s.exec(select(auth.Sesion)).all():
                if x.usuario_id in uids:
                    s.delete(x)
            for r in s.exec(select(auth.RolEmpresa)).all():
                if r.empresa_id in eids:
                    s.delete(r)
            for e in es:
                s.delete(e)
            for u in us:
                s.delete(u)
            s.exec(sa_delete(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login", "login_fallo", "login_cuenta", "login_disp"))))  # type: ignore[attr-defined]
            s.commit()


def test_consola_exige_cambiar_la_contrasena_temporal(mundo):
    c, ids = mundo
    with Session(engine) as s:
        t = _usuario(s, "temporal", es_superadmin=True, mfa_activo=True, debe_cambiar_password=True)
        tid = t.id
    tok = _token(tid)
    for ruta in ("/api/admin/cuentas", "/api/admin/usuarios", "/api/admin/auditoria", "/api/admin/administradores", "/api/admin/seguridad"):
        r = c.get(ruta, headers=H(tok))
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cambiar_password", (ruta, r.text)
    assert c.post(f"/api/admin/usuarios/{ids.n}/bloqueo", json={"bloquear": True}, headers=H(tok)).status_code == 403
    assert c.post("/api/auth/password", json={"actual": PW, "nueva": "Otra-clave-387-consola"}, headers=H(tok)).status_code == 200   # sale de ese estado
    assert c.get("/api/admin/cuentas", headers=H(tok)).status_code == 200


def test_limitado_no_toca_cuentas_de_empresas_ocultas(mundo):
    c, ids = mundo
    with Session(engine) as s:
        h, v = _empresa(s, "Oculta", "3101387101"), _empresa(s, "Visible", "3101387102")
        x, y, z = _usuario(s, "solo.oculta", mfa_activo=True), _usuario(s, "compartido"), _usuario(s, "solo.visible")
        _miembro(s, x, h, "Administrador"); _miembro(s, y, h, "Contador"); _miembro(s, y, v, "Contador"); _miembro(s, z, v, "Vendedor")
        hid, vid, xid, yid, zid, correo_x = h.id, v.id, x.id, y.id, z.id, x.correo
    _ocultar(ids.l, [hid])
    tl = _token(ids.l)
    # solo pertenece a la oculta: para él no existe
    assert c.post(f"/api/admin/usuarios/{xid}/password", json={"password": "Clave-Tomada-QA-2026!"}, headers=H(tl)).status_code == 404
    assert c.post(f"/api/admin/usuarios/{xid}/bloqueo", json={"bloquear": True}, headers=H(tl)).status_code == 404
    # también está en una visible: la ve, pero no actúa sobre la cuenta entera
    assert c.post(f"/api/admin/usuarios/{yid}/bloqueo", json={"bloquear": True}, headers=H(tl)).status_code == 403
    assert c.post(f"/api/admin/usuarios/{yid}/password", json={"password": "Clave-Tomada-QA-2026!"}, headers=H(tl)).status_code == 403
    # ni la trae a una empresa visible (así dejaría de estar «solo en la oculta»): ni por la consola, ni con «Nueva cuenta», ni desde
    # Usuarios de la empresa entrando como soporte
    assert c.post(f"/api/admin/cuentas/{vid}/usuarios", json={"correo": correo_x, "rol": "Vendedor"}, headers=H(tl)).status_code == 403
    r = c.post("/api/admin/cuentas", json={"correo": correo_x, "password": "Clave-larga-cuenta-387", "nombre_empresa": NOMBRE + "Nueva con x"}, headers=H(tl))
    assert r.status_code == 403, r.text
    r = c.post("/api/auth/usuarios", json={"correo": correo_x, "nombre": "x", "rol": "Vendedor", "password_temporal": PW}, headers=H(_token(ids.l, vid)))
    assert r.status_code == 403, r.text
    with Session(engine) as s:
        x = s.get(auth.Usuario, xid)
        assert not x.bloqueado and auth.verificar_password(PW, x.password_hash) and x.mfa_activo
        assert [m.empresa_id for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == xid)).all()] == [hid]
        assert not s.exec(select(Empresa).where(Empresa.nombre == NOMBRE + "Nueva con x")).first()
    assert correo_x not in [u["correo"] for u in c.get("/api/admin/usuarios", headers=H(tl)).json()]
    # lo de las empresas visibles sigue igual
    assert c.post(f"/api/admin/usuarios/{zid}/bloqueo", json={"bloquear": True}, headers=H(tl)).json()["bloqueado"] is True
    assert c.post(f"/api/admin/usuarios/{zid}/bloqueo", json={"bloquear": False}, headers=H(tl)).json()["bloqueado"] is False
    assert c.put(f"/api/admin/cuentas/{vid}/usuarios/{yid}/rol", json={"rol": "Vendedor"}, headers=H(tl)).status_code == 200   # solo en la visible
    # el super administrador sí
    tp = _token(ids.p)
    assert c.post(f"/api/admin/usuarios/{xid}/bloqueo", json={"bloquear": True}, headers=H(tp)).status_code == 200
    assert c.post(f"/api/admin/usuarios/{xid}/bloqueo", json={"bloquear": False}, headers=H(tp)).status_code == 200
    # y el limitado restablece su propia contraseña aunque sea miembro de una empresa que tiene oculta (antes: 404 «Usuario no encontrado»)
    with Session(engine) as s:
        _miembro(s, s.get(auth.Usuario, ids.l), s.get(Empresa, hid), "Cajero")
    r = c.post(f"/api/admin/usuarios/{ids.l}/password", json={"password": "Otra-clave-limitado-387"}, headers=H(tl))
    assert r.status_code == 200, r.text


def test_membresias_de_administradores_del_sistema(mundo):
    c, ids = mundo
    with Session(engine) as s:
        e = _empresa(s, "Membresias", "3101387201")
        a = _usuario(s, "admin.empresa", mfa_activo=True)
        _miembro(s, a, e, "Administrador")
        eid, aid = e.id, a.id
    tn, tp = _token(ids.n), _token(ids.p)
    # el administrador normal no agrega, cambia ni quita a otro administrador del sistema
    assert c.post(f"/api/admin/cuentas/{eid}/usuarios", json={"correo": ids.correo_p, "rol": "Cajero"}, headers=H(tn)).status_code == 403
    assert c.post(f"/api/admin/cuentas/{eid}/usuarios", json={"correo": ids.correo_l, "rol": "Cajero"}, headers=H(tp)).status_code == 200   # el super administrador sí
    assert c.put(f"/api/admin/cuentas/{eid}/usuarios/{ids.l}/rol", json={"rol": "Vendedor"}, headers=H(tn)).status_code == 403
    assert c.delete(f"/api/admin/cuentas/{eid}/usuarios/{ids.l}", headers=H(tn)).status_code == 403
    # ni lo hace Administrador de una empresa nueva con «Nueva cuenta» y su correo
    r = c.post("/api/admin/cuentas", json={"correo": ids.correo_p, "password": "Clave-larga-cuenta-387", "nombre_empresa": NOMBRE + "Nueva con P"}, headers=H(tn))
    assert r.status_code == 403, r.text
    with Session(engine) as s:
        assert not s.exec(select(Empresa).where(Empresa.nombre == NOMBRE + "Nueva con P")).first()
    # su propia membresía sí la maneja
    me = c.post(f"/api/admin/cuentas/{eid}/usuarios", json={"correo": "normal" + SUF, "rol": "Vendedor"}, headers=H(tn))
    assert me.status_code == 200 and c.delete(f"/api/admin/cuentas/{eid}/usuarios/{ids.n}", headers=H(tn)).status_code == 200
    # ni el Administrador de la empresa desde Usuarios
    ta = _token(aid, eid)
    assert c.put(f"/api/auth/usuarios/{ids.l}", json={"rol": "Vendedor"}, headers=H(ta)).status_code == 403
    assert c.delete(f"/api/auth/usuarios/{ids.l}", headers=H(ta)).status_code == 403
    assert c.post("/api/auth/usuarios", json={"correo": ids.correo_p, "nombre": "P", "rol": "Vendedor", "password_temporal": PW}, headers=H(ta)).status_code == 403
    # la consola lo muestra aparte (y no en la lista de usuarios con selector de rol); quitarlo solo se ofrece a quien puede
    cuenta = next(x for x in c.get("/api/admin/cuentas", headers=H(tp)).json() if x["id"] == eid)
    assert [(x["id"], x["rol"], x["editable"]) for x in cuenta["admins_sistema"]] == [(ids.l, "Cajero", True)]
    assert ids.l not in [x["id"] for x in cuenta["usuarios"]]
    cuenta_n = next(x for x in c.get("/api/admin/cuentas", headers=H(tn)).json() if x["id"] == eid)
    assert [(x["id"], x["editable"]) for x in cuenta_n["admins_sistema"]] == [(ids.l, False)]
    # y en Usuarios de la empresa su fila es de solo lectura para el Administrador de la empresa
    filas = {x["id"]: x for x in c.get("/api/auth/usuarios", headers=H(ta)).json()}
    assert filas[ids.l]["admin_sistema"] is True and filas[ids.l]["editable"] is False
    assert filas[aid]["admin_sistema"] is False and filas[aid]["editable"] is True
    js = c.get("/js/pages/configuracion/seccion.js").text
    assert 'v-if="row.editable !== false"' in js and "u.editable === false" in js
    assert 'v-if="u.editable"' in c.get("/js/pages/admin.js").text
    # ser miembro no abre una empresa que el super administrador le ocultó
    tl_e = _token(ids.l, eid)
    assert c.get("/api/empresa", headers=H(tl_e)).json()["rol"] == "Administrador"          # 3.87a: como Administrador
    _ocultar(ids.l, [eid])
    assert c.get("/api/empresa", headers=H(tl_e)).status_code == 403
    assert c.post("/api/auth/empresa", json={"empresa_id": eid}, headers=H(_token(ids.l))).status_code == 403
    assert c.get("/api/auth/yo", headers=H(tl_e)).json()["empresa_id"] is None


def test_administrador_del_sistema_cajero_ve_todo(mundo):
    c, ids = mundo
    with Session(engine) as s:
        e = _empresa(s, "Cajero SA", "3101387301")
        _miembro(s, s.get(auth.Usuario, ids.n), e, "Cajero")
        eid = e.id
    t = _token(ids.n, eid)
    assert c.get("/api/empresa", headers=H(t)).json()["rol"] == "Administrador"
    for ruta in ("/api/borradores", "/api/recurrentes", "/api/inventario/movimientos", "/api/inventario/movimientos?limite=5000", "/api/pagos"):
        assert c.get(ruta, headers=H(t)).status_code == 200, ruta


def test_sesion_sin_empresa_cuando_ya_no_hay_acceso(mundo):
    c, ids = mundo
    with Session(engine) as s:
        v, g, k = _empresa(s, "Se oculta", "3101387401"), _empresa(s, "Retiro", "3101387402"), _empresa(s, "Se borra", "3101387403")
        w, q = _usuario(s, "retirado"), _usuario(s, "cliente.borrada", mfa_activo=True)
        _miembro(s, w, g, "Vendedor"); _miembro(s, q, k, "Administrador")
        vid, gid, kid, wid, qid = v.id, g.id, k.id, w.id, q.id
    # 1) al administrador le ocultan la empresa que tenía abierta
    tl = _token(ids.l, vid)
    _ocultar(ids.l, [vid])
    yo = c.get("/api/auth/yo", headers=H(tl)).json()
    assert yo["empresa_id"] is None and yo["rol"] is None and yo["permisos"] == []
    assert c.get("/api/arranque", headers=H(tl)).json()["yo"]["empresa_id"] is None
    # 2) a un usuario le quitan el acceso con la sesión abierta
    tw = _token(wid, gid)
    with Session(engine) as s:
        for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == wid)).all():
            s.delete(m)
        s.commit()
    assert c.get("/api/auth/yo", headers=H(tw)).json()["empresa_id"] is None
    # 3) se borra la empresa con sesiones abiertas: no vuelve a crearse su base
    tq, tp = _token(qid, kid), _token(ids.p, kid)
    assert c.delete(f"/api/admin/cuentas/{kid}", headers=H(tp)).json()["ok"] is True
    archivo = EMPRESAS_DIR / f"empresa_{kid}.db"
    assert not archivo.exists()
    assert c.get("/api/auth/yo", headers=H(tq)).json()["empresa_id"] is None
    assert c.get("/api/arranque", headers=H(tp)).json()["yo"]["empresa_id"] is None
    assert not archivo.exists()
    # 4) el administrador del sistema no abre (ni crea) una empresa que no existe
    assert c.post("/api/auth/empresa", json={"empresa_id": 987654321}, headers=H(_token(ids.p))).status_code == 404
    assert not (EMPRESAS_DIR / "empresa_987654321.db").exists()


def test_lista_de_ip_solo_la_cambia_el_super_administrador(mundo):
    c, ids = mundo
    antes = auth._SEGURIDAD.read_text(encoding="utf-8") if auth._SEGURIDAD.exists() else None
    try:
        r = c.put("/api/admin/seguridad", json={"activa": False, "ips": ["203.0.113.7"]}, headers=H(_token(ids.n)))
        assert r.status_code == 403 and "super administrador" in r.json()["detail"]
        assert c.get("/api/admin/seguridad", headers=H(_token(ids.n))).status_code == 200          # ver el estado sí
        assert c.put("/api/admin/seguridad", json={"activa": False, "ips": ["203.0.113.7"]}, headers=H(_token(ids.p))).status_code == 200
    finally:
        if antes is None:
            auth._SEGURIDAD.unlink(missing_ok=True)
        else:
            auth._SEGURIDAD.write_text(antes, encoding="utf-8")
    js = c.get("/js/pages/admin.js").text
    assert '<template v-if="yoPrincipal"><!-- 3.87: la lista' in js and "Solo el super administrador cambia la lista de direcciones permitidas." in js
    assert "Administrador del sistema · miembro como" in js


def test_borrar_empresa_libera_nombre_publico_dominio_y_portal(mundo):
    c, ids = mundo
    from app.tike import TikeSlug
    with Session(engine) as s:
        e, d = _empresa(s, "Libera", "3101387501"), _empresa(s, "Demo libera", "3101387502", es_demo=True)
        s.add(pedidos.SlugPublico(slug="c387-tienda", empresa_id=e.id)); s.add(pedidos.DominioNegocio(dominio="c387-tienda.test", empresa_id=e.id, slug="c387-tienda"))
        s.add(TikeSlug(slug="c387-soporte", empresa_id=e.id)); s.add(pedidos.SlugPublico(slug="c387-huerfano", empresa_id=987654320))
        s.add(pedidos.SlugPublico(slug="c387-demo", empresa_id=d.id)); s.add(auth.RolEmpresa(empresa_id=d.id, nombre="Rol demo 387", permisos="[]"))
        s.commit()
        eid, did = e.id, d.id
    assert pedidos.empresa_de_slug("c387-tienda") == eid
    tp = _token(ids.p)
    assert c.delete(f"/api/admin/cuentas/{eid}", headers=H(tp)).json()["ok"] is True
    assert c.delete(f"/api/admin/pruebas/{did}", headers=H(tp)).json()["ok"] is True
    with Session(engine) as s:
        assert not s.exec(select(pedidos.SlugPublico).where(pedidos.SlugPublico.slug.in_(("c387-tienda", "c387-huerfano", "c387-demo")))).all()  # type: ignore[attr-defined]
        assert not s.exec(select(pedidos.DominioNegocio).where(pedidos.DominioNegocio.dominio == "c387-tienda.test")).first()
        assert not s.exec(select(TikeSlug).where(TikeSlug.slug == "c387-soporte")).first()
        assert not s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == did)).first()
    assert pedidos.empresa_de_slug("c387-tienda") is None and pedidos.negocio_de_host("c387-tienda.test") is None


def test_traslados_del_administrador_del_sistema_solo_al_grupo_del_dueno(mundo):
    c, ids = mundo
    with Session(engine) as s:
        a, b, cc, d = (_empresa(s, "Grupo A", "3101387601", tipo_negocio="comercio"), _empresa(s, "Grupo B", "3101387602", tipo_negocio="comercio"),
                       _empresa(s, "Otro cliente", "3101387603", tipo_negocio="comercio"), _empresa(s, "Grupo D", "3101387604", tipo_negocio="comercio"))
        dueno, otro = _usuario(s, "dueno.grupo", mfa_activo=True), _usuario(s, "dueno.otro", mfa_activo=True)
        for x in (a, b, d):
            _miembro(s, dueno, x, "Administrador")
        _miembro(s, otro, cc, "Administrador")
        _miembro(s, s.get(auth.Usuario, ids.p), cc, "Administrador")      # una membresía del administrador del sistema no arma grupo
        aid, bid, cid, did, duid = a.id, b.id, cc.id, d.id, dueno.id
    ver = lambda tok: {x["id"] for x in c.get("/api/traslados/destinos", headers=H(tok)).json()}
    tp = _token(ids.p, aid)
    assert ver(tp) == {bid, did}                                          # antes: todas las empresas de la plataforma
    assert ver(_token(duid, aid)) == {bid, did}                           # lo mismo que ve el dueño
    linea = {"producto_id": 1, "cantidad": 1}
    r = c.post("/api/traslados", json={"empresa_destino_id": cid, "lineas": [linea]}, headers=H(tp))
    assert r.status_code == 400 and "No puede trasladar a esa empresa" in r.json()["detail"]
    _ocultar(ids.l, [did])
    tl = _token(ids.l, aid)
    assert ver(tl) == {bid}                                               # la oculta jamás aparece
    r = c.post("/api/traslados", json={"empresa_destino_id": did, "lineas": [linea]}, headers=H(tl))
    assert r.status_code == 400 and "No puede trasladar a esa empresa" in r.json()["detail"]


def test_respaldo_de_la_empresa_pide_tambien_usuarios(mundo):
    c, ids = mundo
    with Session(engine) as s:
        e = _empresa(s, "Respaldos", "3101387701")
        s.add(auth.RolEmpresa(empresa_id=e.id, nombre="Configurador", permisos=json.dumps(["configurar"]))); s.commit()
        k, a = _usuario(s, "configurador", mfa_activo=True), _usuario(s, "admin.respaldos", mfa_activo=True)
        _miembro(s, k, e, "Configurador"); _miembro(s, a, e, "Administrador")
        eid, kid, aid = e.id, k.id, a.id
    tk = _token(kid, eid)
    assert c.get("/api/empresa", headers=H(tk)).status_code == 200
    for metodo, ruta in (("get", "/api/respaldos"), ("post", "/api/respaldos"), ("get", "/api/respaldos/empresa_1_20260101_000000.zip"),
                         ("delete", "/api/respaldos/empresa_1_20260101_000000.zip")):
        r = getattr(c, metodo)(ruta, headers=H(tk))
        assert r.status_code == 403 and "todos los datos" in r.json()["detail"], (ruta, r.text)
    assert c.post("/api/respaldos/x.zip/restaurar", json={"confirmacion": "RESTAURAR"}, headers=H(tk)).status_code == 403
    assert c.get("/api/respaldos", headers=H(_token(aid, eid))).status_code == 200
    # la interfaz solo ofrece Respaldos a quien también administra usuarios
    texto = (pathlib.Path(__file__).resolve().parent.parent / "app/static/js/pages/configuracion/hub.js").read_text(encoding="utf-8")
    texto += (pathlib.Path(__file__).resolve().parent.parent / "app/static/js/menu.js").read_text(encoding="utf-8")   # 3.87: la tabla PERMISO_CONFIG vive en menu.js
    assert "respaldos: ['configurar', 'usuarios']" in texto and "[].concat(p).every(x => sesion.puede(x))" in texto   # los dos, como el servidor


def test_espera_por_intentos_no_revela_correos_ni_deja_afuera_al_dueno(mundo, monkeypatch):
    c, ids = mundo
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    with Session(engine) as s:
        e = _empresa(s, "Login", "3101387801")
        v = _usuario(s, "victima")
        _miembro(s, v, e, "Vendedor")
        vid, correo_v = v.id, v.correo
    nadie = "nadie" + SUF
    ip = lambda x: {"X-Forwarded-For": x}
    entrar = lambda cli, correo, clave, desde: cli.post("/api/auth/login", json={"correo": correo, "password": clave}, headers=ip(desde))
    # la persona ya entró desde su computadora (queda la marca del dispositivo) y desde su oficina
    casa = TestClient(app, base_url="https://testserver")
    assert entrar(casa, correo_v, PW, "203.0.113.20").status_code == 200
    # alguien prueba claves desde otra conexión: la misma respuesta exista o no la cuenta
    atacante = TestClient(app)
    r_v = [entrar(atacante, correo_v, "mala-clave-387", "198.51.100.7") for _ in range(6)]
    r_n = [entrar(atacante, nadie, "mala-clave-387", "198.51.100.7") for _ in range(6)]
    assert [r.status_code for r in r_v] == [r.status_code for r in r_n] == [401] * 5 + [429]
    _sin_min = lambda x: re.sub(r"\d+ minutos?", "N minutos", str(x))   # 3.88: las dos series pueden caer a lados distintos del minuto
    assert [_sin_min(r.json()["detail"]) for r in r_v] == [_sin_min(r.json()["detail"]) for r in r_n]
    assert "facturacr_disp" in casa.cookies                                # marca firmada del dispositivo donde ya entró
    # desde otra conexión desconocida también espera (la fuerza bruta no se reparte entre conexiones), igual para los dos correos
    assert entrar(TestClient(app), correo_v, PW, "192.0.2.55").status_code == 429
    assert entrar(TestClient(app), nadie, PW, "192.0.2.55").status_code == 429
    # pero la persona entra desde su dispositivo (aunque cambie de conexión) y desde donde ya había entrado
    assert entrar(casa, correo_v, PW, "192.0.2.99").status_code == 200
    assert entrar(TestClient(app), correo_v, PW, "203.0.113.20").status_code == 200
    # y desde su dispositivo también rige el límite de 5 fallos por conexión
    r = [entrar(casa, correo_v, "mala-clave-387", "192.0.2.98").status_code for _ in range(6)]
    assert r == [401] * 5 + [429]
    # desbloquear desde la consola quita la espera
    assert c.post(f"/api/admin/usuarios/{vid}/bloqueo", json={"bloquear": False}, headers=H(_token(ids.p))).status_code == 200
    assert entrar(TestClient(app), correo_v, PW, "192.0.2.55").status_code == 200
    assert entrar(casa, correo_v, PW, "192.0.2.98").status_code == 200


def test_marca_del_dispositivo_copiada_no_da_intentos_sin_fin(mundo, monkeypatch):
    """La marca del dispositivo es un pase al portador: copiada a otro navegador y rotando conexiones solo agrega sus propios 5 intentos
    (antes, sin tope), y deja de valer al restablecer o cambiar la contraseña. La persona sigue entrando desde su conexión conocida."""
    c, ids = mundo
    monkeypatch.setenv("FE_PROXY_CONFIABLE", "1")
    with Session(engine) as s:
        e = _empresa(s, "Marca", "3101387901")
        v = _usuario(s, "victima.marca")
        _miembro(s, v, e, "Vendedor")
        vid, correo_v = v.id, v.correo

    def entrar(clave, desde, marca=None):
        cli = TestClient(app, base_url="https://testserver")
        if marca:
            cli.cookies.set(auth.COOKIE_DISPOSITIVO, marca, domain="testserver.local", path="/api/auth")
        return cli.post("/api/auth/login", json={"correo": correo_v, "password": clave}, headers={"X-Forwarded-For": desde})

    r = entrar(PW, "203.0.113.30")
    assert r.status_code == 200
    marca = r.cookies.get(auth.COOKIE_DISPOSITIVO)
    assert marca
    # 1) la copia, una conexión distinta por intento: 5 con la marca + 5 del correo, y luego espera (antes: 40 de 40 sin espera)
    codigos = [entrar(f"mala-{i}", f"198.18.{i}.1", marca).status_code for i in range(20)]
    assert codigos == [401] * 10 + [429] * 10, codigos
    # la persona entra desde la conexión donde ya había entrado, con la misma marca (la copia no la deja afuera)...
    r = entrar(PW, "203.0.113.30", marca)
    assert r.status_code == 200
    nueva = r.cookies.get(auth.COOKIE_DISPOSITIVO)
    assert nueva and nueva != marca                       # cada ingreso correcto da una marca nueva
    # ...y eso no le devuelve intentos a la copia vieja
    assert entrar("mala-otra", "198.18.99.1", marca).status_code == 429
    # 2) restablecer la contraseña desde la consola invalida las marcas: con la espera del correo activa, la marca vieja ya no exime
    assert c.post(f"/api/admin/usuarios/{vid}/password", json={"password": "Clave-restablecida-387"}, headers=H(_token(ids.p))).status_code == 200
    assert [entrar(f"mala-r{i}", f"198.19.{i}.1").status_code for i in range(6)] == [401] * 5 + [429]
    assert entrar("Clave-restablecida-387", "192.0.2.70", nueva).status_code == 429
    # 3) al cambiar ella misma la contraseña, su dispositivo sigue conocido y la marca de antes deja de valer
    with Session(engine) as s:
        auth._limpiar_fallos_login(s, correo_v)
    r = entrar("Clave-restablecida-387", "192.0.2.71")
    assert r.status_code == 200
    casa = r.cookies.get(auth.COOKIE_DISPOSITIVO)
    cli = TestClient(app, base_url="https://testserver")
    cli.cookies.set(auth.COOKIE_DISPOSITIVO, casa, domain="testserver.local", path="/api/auth")
    r = cli.post("/api/auth/password", json={"actual": "Clave-restablecida-387", "nueva": "Clave-propia-nueva-387"}, headers=H(r.json()["token"]))
    assert r.status_code == 200
    casa_nueva = r.cookies.get(auth.COOKIE_DISPOSITIVO)
    assert casa_nueva and casa_nueva != casa
    assert [entrar(f"mala-c{i}", f"198.20.{i}.1").status_code for i in range(6)] == [401] * 5 + [429]
    assert entrar("Clave-propia-nueva-387", "192.0.2.72", casa_nueva).status_code == 200
    assert entrar("Clave-propia-nueva-387", "192.0.2.73", casa).status_code == 429
