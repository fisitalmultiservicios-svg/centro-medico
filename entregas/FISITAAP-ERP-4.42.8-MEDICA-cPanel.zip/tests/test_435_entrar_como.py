"""4.35 (C): «Entrar como» cualquiera de los usuarios de una empresa desde la consola del administrador del sistema (soporte).
POST /api/admin/cuentas/{eid}/usuarios/{uid}/entrar-como abre una sesión NUEVA de esa cuenta en esa empresa, con el rol de su membresía,
marcada con quién la abrió (Sesion.suplantada_por) y a qué sesión suya vuelve (Sesion.suplantada_vuelve); dura 1 hora como máximo, no pide
los dos pasos de la persona, no anida, no abre la consola ni la seguridad de la cuenta, y todo lo auditado lleva « · por soporte <correo>».
POST /api/auth/volver la cierra y devuelve la sesión del administrador. Solo en la página web.
Todo con usuarios y empresas @example.test creados aquí y borrados al final."""
import pathlib
import types
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete as sa_delete
from sqlmodel import Session, select

from app import auth
from app.db import Auditoria, Empresa, engine, init_db
from app.main import app

PW = "Clave-larga-435-entrar-como"
SUF = ".435c@example.test"
NOMBRE = "C435 "
JS = pathlib.Path(auth.__file__).parent / "static" / "js"


def H(t):
    return {"Authorization": "Bearer " + t}


def _usuario(s, nombre, **kw):
    correo = nombre + SUF
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
    if not u:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION, **kw)
        s.add(u); s.commit(); s.refresh(u)
    return u


def _empresa(s, nombre, cedula, **kw):
    return auth.crear_empresa(s, NOMBRE + nombre, nombre.lower() + SUF, cedula, provincia=1, canton=1, distrito=1, otras_senas="QA 435 C",
                              actividad="471101", telefono=22224351, factura_electronica=False, correo_automatico=False, **kw)


def _miembro(s, u, e, rol):
    s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id if hasattr(e, "id") else e, rol=rol)); s.commit()


def _token(uid, eid=None):
    with Session(engine) as s:
        return auth._respuesta(s, s.get(auth.Usuario, uid), eid)["token"]


def _sesion(token):
    with Session(engine) as s:
        return s.exec(select(auth.Sesion).where(auth.Sesion.sid == auth.abrir(token)["sid"])).first()


def _cuenta(uid):
    with Session(engine) as s:
        return s.get(auth.Usuario, uid)


_BASE = {"id": 0}                    # filas de auditoría de antes de cada prueba (los ids de empresas y usuarios se repiten entre pruebas)


def _auditoria(accion, correo_en_detalle=None):
    with Session(engine) as s:
        filas = s.exec(select(Auditoria).where(Auditoria.accion == accion, Auditoria.id > _BASE["id"]).order_by(Auditoria.id)).all()
    return [a for a in filas if correo_en_detalle is None or correo_en_detalle in (a.detalle or "")]


def _ruta(eid, uid):
    return f"/api/admin/cuentas/{eid}/usuarios/{uid}/entrar-como"


@pytest.fixture
def mundo():
    """Super administrador P; administrador del sistema N2 que no ve la empresa E2; empresas E1 y E2.
    E1: A1 Administrador (con dos pasos), V1 Vendedor (con dos pasos: no se le piden), X Contador (también Vendedor en E2).
    E2: A2 Administrador."""
    init_db()
    with Session(engine) as s:
        _BASE["id"] = max([a.id for a in s.exec(select(Auditoria).order_by(Auditoria.id.desc()).limit(1)).all()] or [0])
        p = _usuario(s, "principal", es_superadmin=True, admin_principal=True, mfa_activo=True)
        e1, e2 = _empresa(s, "Uno", "3101435101"), _empresa(s, "Dos", "3101435102")
        n2 = _usuario(s, "sistema.limitado", es_superadmin=True, mfa_activo=True, empresas_ocultas=f"[{e2.id}]")
        a1, a2 = _usuario(s, "admin.uno", mfa_activo=True), _usuario(s, "admin.dos", mfa_activo=True)
        v1, x = _usuario(s, "vendedor.uno", mfa_activo=True), _usuario(s, "contador.x")
        _miembro(s, a1, e1, "Administrador"); _miembro(s, a2, e2, "Administrador")
        _miembro(s, v1, e1, "Vendedor"); _miembro(s, x, e1, "Contador"); _miembro(s, x, e2, "Vendedor")
        ids = types.SimpleNamespace(p=p.id, n2=n2.id, e1=e1.id, e2=e2.id, a1=a1.id, a2=a2.id, v1=v1.id, x=x.id,
                                    correo_p=p.correo, correo_n2=n2.correo, correo_a1=a1.correo, correo_v1=v1.correo, correo_x=x.correo)
    try:
        yield TestClient(app), ids
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            us = s.exec(select(auth.Usuario).where(auth.Usuario.correo.like("%" + SUF))).all()  # type: ignore[attr-defined]
            uids = [u.id for u in us]
            es = s.exec(select(Empresa).where(Empresa.nombre.like(NOMBRE + "%"))).all()  # type: ignore[attr-defined]
            eids = [e.id for e in es]
            for m in s.exec(select(auth.UsuarioEmpresa)).all():
                if m.usuario_id in uids or m.empresa_id in eids:
                    s.delete(m)
            for x in s.exec(select(auth.Sesion)).all():
                if x.usuario_id in uids:
                    s.delete(x)
            for t in s.exec(select(auth.TokenApi)).all():
                if t.usuario_id in uids or t.empresa_id in eids:
                    s.delete(t)
            for r in s.exec(select(auth.RolEmpresa)).all():
                if r.empresa_id in eids:
                    s.delete(r)
            for e in es:
                s.delete(e)
            for u in us:
                s.delete(u)
            s.exec(sa_delete(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login", "login_fallo", "login_cuenta", "login_disp"))))  # type: ignore[attr-defined]
            s.commit()


def _entrar(c, ids, uid, eid=None, actor=None):
    r = c.post(_ruta(eid or ids.e1, uid), headers=H(actor or _token(ids.p)))
    assert r.status_code == 200, r.text
    return r.json()


# ----------------------------------------------------------------------------- entra con el rol de su membresía
def test_entra_con_el_rol_de_la_persona_y_ve_lo_suyo(mundo):
    c, ids = mundo
    t_p = _token(ids.p)
    propia = _sesion(t_p)
    r = c.post(_ruta(ids.e1, ids.v1), headers=H(t_p))
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["usuario"]["id"] == ids.v1 and j["usuario"]["correo"] == ids.correo_v1 and j["usuario"]["es_superadmin"] is False
    assert j["empresa_id"] == ids.e1 and j["rol"] == "Vendedor"
    assert "facturar" in j["permisos"] and "usuarios" not in j["permisos"] and "configurar" not in j["permisos"]
    assert j["usuario"]["soporte"]["correo"] == ids.correo_p and j["usuario"]["paleta"]          # la franja; sin pedir colores por la persona
    assert "mfa_requerido" not in j and j["token"]                                              # sin el código de dos pasos de la persona
    t = j["token"]
    datos = auth.abrir(t)
    assert datos["uid"] == ids.v1 and datos["eid"] == ids.e1 and datos["exp"] - datetime.now(timezone.utc).timestamp() <= auth.DURACION_SUPLANTACION + 5
    ses = _sesion(t)
    assert ses.usuario_id == ids.v1 and ses.suplantada_por == ids.p and ses.suplantada_vuelve == propia.id and not ses.revocada
    assert _cuenta(ids.v1).ultimo_acceso is None                     # no entró la persona
    # ve lo que la persona ve: su sesión, la lista corta de usuarios (sin correos) y nada de configuración
    yo = c.get("/api/auth/yo", headers=H(t)).json()
    assert yo["usuario"]["id"] == ids.v1 and yo["rol"] == "Vendedor" and yo["usuario"]["soporte"]["correo"] == ids.correo_p
    lista = c.get("/api/auth/usuarios", headers=H(t))
    assert lista.status_code == 200 and lista.json() and all("correo" not in x for x in lista.json())
    r = c.get("/api/auth/tokens-api", headers=H(t))
    assert r.status_code == 403 and "Vendedor" in r.text
    assert c.get("/api/auth/auditoria", headers=H(t)).status_code == 200
    # la sesión del administrador sigue abierta y es la suya
    assert not _sesion(t_p).revocada and c.get("/api/admin/cuentas", headers=H(t_p)).status_code == 200


def test_solo_ve_esta_empresa(mundo):
    c, ids = mundo
    j = _entrar(c, ids, ids.x)                                       # X también es Vendedor en E2
    assert j["rol"] == "Contador" and [e["id"] for e in j["empresas"]] == [ids.e1]
    t = j["token"]
    r = c.post("/api/auth/empresa", json={"empresa_id": ids.e2}, headers=H(t))
    assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_SUPLANTADA
    assert [e["id"] for e in c.get("/api/auth/yo", headers=H(t)).json()["empresas"]] == [ids.e1]


def test_administrador_con_dos_pasos_entra_sin_codigo(mundo):
    c, ids = mundo
    j = _entrar(c, ids, ids.a1)
    assert j["rol"] == "Administrador" and "usuarios" in j["permisos"] and j["usuario"]["mfa_activo"] is True
    assert c.get("/api/auth/usuarios", headers=H(j["token"])).status_code == 200


# ----------------------------------------------------------------------------- auditoría
def test_auditoria_al_entrar_durante_y_al_volver(mundo):
    c, ids = mundo
    j = _entrar(c, ids, ids.a1)
    t = j["token"]
    empresa = [a for a in _auditoria("soporte_entro_como", ids.correo_a1) if a.empresa_id == ids.e1]
    sistema = [a for a in _auditoria("soporte_entro_como", ids.correo_a1) if a.empresa_id is None]
    assert [a.detalle for a in empresa] == [f"{ids.correo_p} entró como {ids.correo_a1}"]
    assert len(sistema) == 1 and f"en la empresa {ids.e1}" in sistema[0].detalle and sistema[0].correo == ids.correo_p
    assert empresa[0].usuario_id == ids.p
    # la Auditoría de la empresa lo muestra (transparencia), también a la persona
    acciones = [a["accion"] for a in c.get("/api/auth/auditoria", headers=H(_token(ids.a1, ids.e1))).json()]
    assert "soporte_entro_como" in acciones
    # lo que se audita mientras dura lleva al administrador: en la misma base (auth.auditar) y en una sesión aparte (main._auditar)
    r = c.put("/api/auth/modulos", json={"ocultos": []}, headers=H(t))
    assert r.status_code == 200, r.text
    fila = _auditoria("modulos_empresa")[-1]
    assert fila.usuario_id == ids.a1 and fila.empresa_id == ids.e1 and fila.detalle.endswith(f" · por soporte {ids.correo_p}")
    r = c.post("/api/empresa/enlaces/invalidar", headers=H(t))
    assert r.status_code == 200, r.text
    fila = _auditoria("enlaces_invalidados")[-1]
    assert fila.usuario_id == ids.a1 and fila.detalle.endswith(f" · por soporte {ids.correo_p}")
    # la persona misma, con su propia sesión, no lleva la marca
    assert c.put("/api/auth/modulos", json={"ocultos": []}, headers=H(_token(ids.a1, ids.e1))).status_code == 200
    assert "por soporte" not in (_auditoria("modulos_empresa")[-1].detalle or "")
    # al volver
    assert c.post("/api/auth/volver", headers=H(t)).json()["volvio"] is True
    salio = _auditoria("soporte_salio", ids.correo_a1)
    assert {a.empresa_id for a in salio} == {ids.e1, None} and all(ids.correo_p in a.detalle for a in salio)
    assert all("por soporte" not in (a.detalle or "") for a in salio)


def test_cerrar_sesion_de_soporte_tambien_queda(mundo):
    c, ids = mundo
    t_p = _token(ids.p)
    t = _entrar(c, ids, ids.v1, actor=t_p)["token"]
    assert c.post("/api/auth/salir", headers=H(t)).status_code == 200
    assert _sesion(t).revocada and _sesion(t_p).revocada              # «Cerrar sesión» cierra también la del administrador (huérfana)
    assert {a.empresa_id for a in _auditoria("soporte_salio", ids.correo_v1)} == {ids.e1, None}
    assert c.get("/api/auth/yo", headers=H(t)).status_code == 401


# ----------------------------------------------------------------------------- dura 1 hora
def test_vence_a_la_hora(mundo):
    c, ids = mundo
    t = _entrar(c, ids, ids.v1)["token"]
    assert c.get("/api/auth/yo", headers=H(t)).status_code == 200
    with Session(engine) as s:
        ses = s.exec(select(auth.Sesion).where(auth.Sesion.sid == auth.abrir(t)["sid"])).first()
        ses.creada = datetime.now(timezone.utc) - timedelta(seconds=auth.DURACION_SUPLANTACION + 30)
        s.add(ses); s.commit()
    r = c.get("/api/auth/yo", headers=H(t))
    assert r.status_code == 401 and r.json()["detail"] == auth.MENSAJE_SOPORTE_VENCIDO
    assert _sesion(t).revocada
    # una sesión propia de la misma edad sigue (12 horas)
    t2 = _token(ids.v1, ids.e1)
    with Session(engine) as s:
        ses = s.exec(select(auth.Sesion).where(auth.Sesion.sid == auth.abrir(t2)["sid"])).first()
        ses.creada = datetime.now(timezone.utc) - timedelta(seconds=auth.DURACION_SUPLANTACION + 30)
        s.add(ses); s.commit()
    assert c.get("/api/auth/yo", headers=H(t2)).status_code == 200


# ----------------------------------------------------------------------------- sin anidar ni consola
def test_no_anida_ni_abre_la_consola(mundo):
    c, ids = mundo
    t = _entrar(c, ids, ids.a1)["token"]
    for metodo, ruta in (("post", _ruta(ids.e1, ids.v1)), ("get", "/api/admin/cuentas"), ("get", "/api/admin/auditoria"),
                         ("get", "/api/admin/usuarios")):
        r = getattr(c, metodo)(ruta, headers=H(t))
        assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_SUPLANTADA, (ruta, r.text)
    with Session(engine) as s:
        assert not s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == ids.v1, auth.Sesion.suplantada_por != None)).all()  # noqa: E711


# ----------------------------------------------------------------------------- a quién no
def test_nunca_como_administrador_del_sistema_ni_bloqueado(mundo):
    c, ids = mundo
    with Session(engine) as s:
        _miembro(s, s.get(auth.Usuario, ids.p), ids.e1, "Administrador")
        _miembro(s, s.get(auth.Usuario, ids.n2), ids.e1, "Administrador")
        b = _usuario(s, "bloqueada", bloqueado=True); _miembro(s, b, ids.e1, "Vendedor")
        temp = _usuario(s, "temporal", debe_cambiar_password=True); _miembro(s, temp, ids.e1, "Vendedor")
        sin_t = _usuario(s, "sin.terminos"); sin_t.terminos_version = None; s.add(sin_t); s.commit(); _miembro(s, sin_t, ids.e1, "Vendedor")
        sin_mfa = _usuario(s, "admin.sin.mfa"); _miembro(s, sin_mfa, ids.e1, "Administrador")
        fuera = _usuario(s, "fuera")
        bid, tid, sid_, mid, fid = b.id, temp.id, sin_t.id, sin_mfa.id, fuera.id
    t_p, t_n2 = _token(ids.p), _token(ids.n2)
    r = c.post(_ruta(ids.e1, ids.n2), headers=H(t_p))
    assert r.status_code == 403 and "administrador del sistema" in r.text
    r = c.post(_ruta(ids.e1, ids.p), headers=H(t_n2))
    assert r.status_code == 403 and "administrador del sistema" in r.text                  # ni como el super administrador
    assert c.post(_ruta(ids.e1, ids.p), headers=H(t_p)).status_code == 403                 # ni como uno mismo
    r = c.post(_ruta(ids.e1, bid), headers=H(t_p))
    assert r.status_code == 409 and "bloqueada" in r.text
    assert c.post(_ruta(ids.e1, fid), headers=H(t_p)).status_code == 404                    # no es de esta empresa
    assert c.post(_ruta(ids.e2, ids.v1), headers=H(t_p)).status_code == 404
    assert c.post(_ruta(987654321, ids.v1), headers=H(t_p)).status_code == 404
    for uid, texto in ((tid, "contraseña temporal"), (sid_, "términos"), (mid, "verificación en dos pasos")):
        r = c.post(_ruta(ids.e1, uid), headers=H(t_p))
        assert r.status_code == 409 and texto in r.text, r.text
    with Session(engine) as s:                                                              # la empresa bloqueada
        e = s.get(Empresa, ids.e1); e.bloqueada = True; s.add(e); s.commit()
    r = c.post(_ruta(ids.e1, ids.v1), headers=H(t_p))
    assert r.status_code == 409 and "bloqueada" in r.text
    with Session(engine) as s:
        e = s.get(Empresa, ids.e1); e.bloqueada = False; s.add(e); s.commit()
        assert not s.exec(select(auth.Sesion).where(auth.Sesion.suplantada_por != None, auth.Sesion.usuario_id.in_(  # noqa: E711
            [ids.p, ids.n2, bid, tid, sid_, mid, fid, ids.v1]))).all()  # type: ignore[attr-defined]


def test_administrador_del_sistema_sin_dos_pasos_no_entra(mundo):
    c, ids = mundo
    with Session(engine) as s:
        sin = _usuario(s, "sistema.sin.mfa", es_superadmin=True)
        sid_ = sin.id
    r = c.post(_ruta(ids.e1, ids.v1), headers=H(_token(sid_)))
    assert r.status_code == 403 and "verificación en dos pasos" in r.text


def test_respeta_empresas_ocultas(mundo):
    c, ids = mundo
    t_n2 = _token(ids.n2)
    assert c.post(_ruta(ids.e2, ids.a2), headers=H(t_n2)).status_code == 404               # E2 no existe para él
    r = c.post(_ruta(ids.e1, ids.x), headers=H(t_n2))                                       # X también está en E2
    assert r.status_code == 403 and "no administra" in r.text
    j = _entrar(c, ids, ids.v1, actor=t_n2)                                                 # V1 solo está en E1: sí
    assert j["usuario"]["soporte"]["correo"] == ids.correo_n2
    assert _entrar(c, ids, ids.a2, eid=ids.e2)["rol"] == "Administrador"                    # el super administrador las ve todas


# ----------------------------------------------------------------------------- seguridad de la cuenta y administración de la empresa
def test_rutas_de_seguridad_y_administracion_prohibidas(mundo):
    c, ids = mundo
    with Session(engine) as s:
        rol = auth.RolEmpresa(empresa_id=ids.e1, nombre="Propio 435", permisos='["ver"]'); s.add(rol); s.commit(); rid = rol.id
    antes = _cuenta(ids.a1)
    t = _entrar(c, ids, ids.a1)["token"]
    propias = _token(ids.a1, ids.e1)                                                       # la sesión de la persona misma
    prohibidas = [
        ("post", "/api/auth/password", {"actual": PW, "nueva": "Otra-clave-larga-435-c"}),
        ("put", "/api/auth/pin", {"pin": "4826", "password": PW}),
        ("post", "/api/auth/mfa/activar", None), ("post", "/api/auth/mfa/confirmar", {"codigo": "123456"}),
        ("post", "/api/auth/mfa/respaldo", {"codigo": "123456"}), ("post", "/api/auth/mfa/desactivar", {"codigo": "123456"}),
        ("post", "/api/auth/mfa/renuncia", {"acepta": True, "asume_responsabilidad": True, "version": auth.RENUNCIA_MFA_VERSION, "password": PW,
                                            "confirmacion": "ACEPTO"}),
        ("delete", "/api/auth/mfa/renuncia", None), ("put", "/api/auth/mfa/politica", {"sin_excepcion": True}),
        ("post", "/api/auth/salir-todas", None), ("post", "/api/auth/terminos", {"acepta": True}), ("post", "/api/auth/paleta", {"paleta": "noche"}),
        ("post", "/api/auth/usuarios", {"correo": "nuevo" + SUF, "nombre": "Nuevo", "rol": "Vendedor", "password_temporal": "Tucan-Playa-4821"}),
        ("put", f"/api/auth/usuarios/{ids.v1}", {"rol": "Contador"}), ("delete", f"/api/auth/usuarios/{ids.v1}", None),
        ("post", f"/api/auth/usuarios/{ids.v1}/password", {}),
        ("post", "/api/auth/roles", {"nombre": "Otro 435", "permisos": ["ver"]}), ("put", f"/api/auth/roles/{rid}", {"nombre": "Propio 435", "permisos": ["ver", "escribir"]}),
        ("delete", f"/api/auth/roles/{rid}", None),
        ("post", "/api/auth/tokens-api", {"nombre": "Integración", "permisos": ["ver"]}),
        ("post", "/api/auth/empresa", {"empresa_id": ids.e1}),
    ]
    for metodo, ruta, cuerpo in prohibidas:
        kw = {"headers": H(t)}
        if cuerpo is not None:
            kw["json"] = cuerpo
        r = c.request(metodo.upper(), ruta, **kw)
        assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_SUPLANTADA, (metodo, ruta, r.status_code, r.text)
    # nada cambió: contraseña, dos pasos, PIN, renuncia, la persona sigue en su rol, sin cuenta nueva ni token de API, sus sesiones vivas
    despues = _cuenta(ids.a1)
    assert (despues.password_hash, despues.mfa_activo, despues.mfa_secret, despues.pin_hash, despues.mfa_renuncia_version, despues.paleta) == \
           (antes.password_hash, antes.mfa_activo, antes.mfa_secret, antes.pin_hash, antes.mfa_renuncia_version, antes.paleta)
    with Session(engine) as s:
        assert s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == ids.v1)).first().rol == "Vendedor"
        assert s.exec(select(auth.Usuario).where(auth.Usuario.correo == "nuevo" + SUF)).first() is None
        assert not s.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == ids.e1)).all()
        assert s.get(auth.RolEmpresa, rid).permisos == '["ver"]'
    assert not _sesion(propias).revocada and not _sesion(t).revocada
    # lo de consultar sí: su sesión, sus sesiones, la renuncia y los usuarios (es Administrador)
    for ruta in ("/api/auth/yo", "/api/auth/sesiones", "/api/auth/mfa/renuncia", "/api/auth/usuarios", "/api/auth/roles"):
        assert c.get(ruta, headers=H(t)).status_code == 200, ruta
    # con su propia sesión la persona sí puede (la regla es de la sesión de soporte, no de la cuenta)
    assert c.post("/api/auth/paleta", json={"paleta": "noche"}, headers=H(propias)).status_code == 200


# ----------------------------------------------------------------------------- 4.35 (revisión h1): el 🔑 de Usuarios en una sesión de soporte
def test_en_soporte_la_lista_no_ofrece_restablecer(mundo):
    """Al entrar como el Administrador de E1, POST /api/auth/usuarios/{uid}/password da 403 (RUTAS_NO_SUPLANTADA). Antes la lista decía
    «restablecible» = true para V1 (solo en E1, no traída, no bloqueada) y la pantalla mostraba el 🔑 activo, que al tocarlo daba 403.
    Ahora la lista dice que no en todas las filas (la misma regla, _no_restablecible, sabe de la sesión de soporte) y la pantalla no
    muestra la llave, ni la gris «La restablece el soporte de FISITAAP», que se lo diría al soporte mismo."""
    c, ids = mundo
    propia = c.get("/api/auth/usuarios", headers=H(_token(ids.a1, ids.e1)))           # la persona, con su propia sesión: a V1 sí
    assert propia.status_code == 200 and {f["id"]: f["restablecible"] for f in propia.json()}[ids.v1] is True, propia.text
    t = _entrar(c, ids, ids.a1)["token"]
    r = c.get("/api/auth/usuarios", headers=H(t))
    assert r.status_code == 200, r.text
    filas = r.json()
    assert {f["id"] for f in filas} >= {ids.a1, ids.v1, ids.x}
    assert {f["id"]: f["restablecible"] for f in filas} == {f["id"]: False for f in filas}
    antes = _cuenta(ids.v1).password_hash
    for f in filas:                                                                     # la lista y la ruta dicen lo mismo: no
        rr = c.post(f"/api/auth/usuarios/{f['id']}/password", json={}, headers=H(t))
        assert rr.status_code == 403 and rr.json()["detail"] == auth.MENSAJE_SUPLANTADA, (f["id"], rr.status_code, rr.text)
    assert _cuenta(ids.v1).password_hash == antes
    with Session(engine) as s:                                                          # la regla misma, la de la ruta y la lista
        v1 = s.get(auth.Usuario, ids.v1)
        m = s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == ids.v1, auth.UsuarioEmpresa.empresa_id == ids.e1)).first()
        assert auth._no_restablecible(ids.v1, v1, m, ids.a1, False) is None
        assert auth._no_restablecible(ids.v1, v1, m, ids.a1, False, soporte=True) == (403, auth.MENSAJE_SUPLANTADA)
    # la pantalla: en una sesión de soporte no hay 🔑 en ninguna fila
    sec = (JS / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    usu = sec[sec.index("const SecUsuarios = {"):sec.index("// ------------------------------------------------------------------ Mi perfil")]
    boton = usu.index('v-if="row.restablecible"')
    llave = usu[usu.rindex("<template", 0, boton):boton]
    assert "!esLocal" in llave and "!(sesion.usuario && sesion.usuario.soporte)" in llave, llave


def test_ruta_no_suplantada_lista():
    assert auth.ruta_no_suplantada("GET", "/api/admin/cuentas") and auth.ruta_no_suplantada("POST", "/api/auth/password")
    assert auth.ruta_no_suplantada("PUT", "/api/auth/usuarios/5") and not auth.ruta_no_suplantada("GET", "/api/auth/usuarios")
    assert not auth.ruta_no_suplantada("POST", "/api/auth/volver") and not auth.ruta_no_suplantada("POST", "/api/auth/salir")
    assert not auth.ruta_no_suplantada("POST", "/api/auth/pin/entrar") and not auth.ruta_no_suplantada("GET", "/api/auth/mfa/renuncia")
    assert not auth.ruta_no_suplantada("DELETE", "/api/auth/tokens-api/3") and auth.ruta_no_suplantada("POST", "/api/auth/tokens-api")


# ----------------------------------------------------------------------------- 4.35 (revisión h3): computadoras nuevas y sus avisos (E-6)
def test_no_conecta_computadoras_ni_contesta_sus_avisos(mundo, monkeypatch):
    """E-6: el soporte no aprueba computadoras (_cuenta_en_regla rechaza al administrador del sistema). Al entrar como un Administrador
    tampoco: quedaría a nombre de la persona (aprobo=admin.uno y «sinc_vinculada» sin « · por soporte»). Ni ve ni reconoce, a nombre de
    ella, los avisos de seguridad de computadoras nuevas. Antes: aprobar daba 200 «aprobado» y el aviso quedaba reconocido."""
    import time
    from app import sinc
    monkeypatch.setattr(sinc, "_avisar_conexion", lambda *a, **k: None)          # nada a correos, pase lo que pase
    c, ids = mundo
    assert auth.ruta_no_suplantada("POST", "/api/sinc/conexion/aprobar") and auth.ruta_no_suplantada("POST", "/api/sinc/conexion/consultar")
    assert auth.ruta_no_suplantada("POST", "/api/sinc/conexion/seguimiento") and auth.ruta_no_suplantada("POST", "/api/sinc/conexion/detener")
    assert auth.ruta_no_suplantada("POST", "/api/sinc/conexion/avisos/7") and not auth.ruta_no_suplantada("GET", "/api/sinc/conexion/avisos")
    assert not auth.ruta_no_suplantada("POST", "/api/sinc/conexion/iniciar")     # la del programa (sin sesión) no cambia
    codigo, ahora, creados = "QA43-5HJK", time.time(), []
    with Session(engine) as s:
        pendiente = sinc.SincPase(secreto_hash="qa435c-pendiente-" + str(ahora), codigo_hash=sinc._hash_codigo(codigo), nombre="Caja QA 435",
                                  estado="pendiente", creado=ahora, vence=ahora + 600)
        aprobado = sinc.SincPase(secreto_hash="qa435c-aprobado-" + str(ahora), codigo_hash="qa435c-x", nombre="Caja vieja QA 435", estado="aprobado",
                                 empresa_id=ids.e1, usuario_id=ids.a1, creado=ahora, vence=ahora + 600)
        s.add(pendiente); s.add(aprobado); s.commit(); s.refresh(pendiente); s.refresh(aprobado)
        aviso = sinc.SincAviso(empresa_id=ids.e1, usuario_id=ids.a1, pase_id=aprobado.id, nombre="Caja vieja QA 435", aprobo="QA", creado=ahora)
        s.add(aviso); s.commit(); s.refresh(aviso)
        creados = [(sinc.SincAviso, aviso.id), (sinc.SincPase, pendiente.id), (sinc.SincPase, aprobado.id)]
        pid, aid = pendiente.id, aviso.id
    try:
        t = _entrar(c, ids, ids.a1)["token"]
        for ruta, cuerpo in (("/api/sinc/conexion/consultar", {"codigo": codigo}),
                             ("/api/sinc/conexion/aprobar", {"codigo": codigo, "empresa_id": ids.e1, "aprobar": True}),
                             ("/api/sinc/conexion/seguimiento", {"pase": pid}), ("/api/sinc/conexion/detener", {"pase": pid}),
                             (f"/api/sinc/conexion/avisos/{aid}", {"respuesta": "si"})):
            r = c.post(ruta, json=cuerpo, headers=H(t))
            assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_SUPLANTADA, (ruta, r.status_code, r.text)
        r = c.get("/api/sinc/conexion/avisos", headers=H(t))
        assert r.status_code == 200 and r.json() == {"avisos": []}                  # como al administrador del sistema
        with Session(engine) as s:
            assert s.get(sinc.SincPase, pid).estado == "pendiente" and s.get(sinc.SincPase, pid).usuario_id is None
            assert s.get(sinc.SincAviso, aid).respuesta is None
        assert not _auditoria("sinc_conexion_aprobada") and not _auditoria("sinc_aviso_reconocida")
        # la persona, con su propia sesión, sigue viendo su aviso (la regla es de la sesión de soporte)
        r = c.get("/api/sinc/conexion/avisos", headers=H(_token(ids.a1, ids.e1)))
        assert r.status_code == 200 and [x["id"] for x in r.json()["avisos"]] == [aid]
    finally:
        with Session(engine) as s:
            for modelo, i in creados:
                x = s.get(modelo, i)
                if x is not None:
                    s.delete(x)
            s.commit()


# ----------------------------------------------------------------------------- volver a la cuenta del administrador
def test_volver_restituye_al_administrador_y_revoca_la_de_soporte(mundo):
    c, ids = mundo
    t_p = _token(ids.p)
    propia = _sesion(t_p)
    t = _entrar(c, ids, ids.v1, actor=t_p)["token"]
    r = c.post("/api/auth/volver", headers=H(t))
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["volvio"] is True and j["usuario"]["id"] == ids.p and j["usuario"]["es_superadmin"] is True and j["empresa_id"] is None
    assert "soporte" not in j["usuario"] and auth.abrir(j["token"])["sid"] == propia.sid
    assert _sesion(t).revocada and not _sesion(t_p).revocada
    assert c.get("/api/auth/yo", headers=H(t)).status_code == 401                                # la de soporte ya no sirve
    assert c.get("/api/admin/cuentas", headers=H(j["token"])).status_code == 200                  # la suya sí
    assert c.post("/api/auth/volver", headers=H(t)).status_code == 401
    r = c.post("/api/auth/volver", headers=H(j["token"]))                                          # su sesión no es de soporte
    assert r.status_code == 400


def test_volver_sin_la_sesion_del_administrador_lleva_a_entrar(mundo):
    c, ids = mundo
    t_p = _token(ids.p)
    t = _entrar(c, ids, ids.v1, actor=t_p)["token"]
    with Session(engine) as s:                                                                   # p. ej. cerró todas sus sesiones en otro lado
        ses = s.exec(select(auth.Sesion).where(auth.Sesion.sid == auth.abrir(t_p)["sid"])).first(); ses.revocada = True; s.add(ses); s.commit()
    r = c.post("/api/auth/volver", headers=H(t))
    assert r.status_code == 200 and r.json()["volvio"] is False and "entre de nuevo" in r.json()["mensaje"] and "token" not in r.json()
    assert _sesion(t).revocada


def test_la_de_soporte_se_cierra_si_el_administrador_pierde_el_acceso(mundo):
    c, ids = mundo
    t_p = _token(ids.p)
    t = _entrar(c, ids, ids.v1, actor=t_p)["token"]
    with Session(engine) as s:
        ses = s.exec(select(auth.Sesion).where(auth.Sesion.sid == auth.abrir(t_p)["sid"])).first(); ses.revocada = True; s.add(ses); s.commit()
    r = c.get("/api/auth/yo", headers=H(t))
    assert r.status_code == 401 and r.json()["detail"] == auth.MENSAJE_SOPORTE_CERRADO and _sesion(t).revocada
    t_n2 = _token(ids.n2)
    t = _entrar(c, ids, ids.v1, actor=t_n2)["token"]
    with Session(engine) as s:
        n2 = s.get(auth.Usuario, ids.n2); n2.bloqueado = True; s.add(n2); s.commit()
    assert c.get("/api/auth/yo", headers=H(t)).status_code == 401


def test_volver_aunque_bloquearan_a_la_persona(mundo):
    c, ids = mundo
    t = _entrar(c, ids, ids.v1)["token"]
    with Session(engine) as s:
        v = s.get(auth.Usuario, ids.v1); v.bloqueado = True; s.add(v); s.commit()
    assert c.get("/api/auth/yo", headers=H(t)).status_code == 403
    r = c.post("/api/auth/volver", headers=H(t))
    assert r.status_code == 200 and r.json()["volvio"] is True and r.json()["usuario"]["id"] == ids.p


# ----------------------------------------------------------------------------- quién puede llamar la ruta
def test_un_usuario_normal_no_puede(mundo):
    c, ids = mundo
    for t in (_token(ids.a1, ids.e1), _token(ids.v1, ids.e1)):
        r = c.post(_ruta(ids.e1, ids.v1), headers=H(t))
        assert r.status_code == 403 and "administrador del sistema" in r.text
    assert c.post(_ruta(ids.e1, ids.v1)).status_code == 401
    with Session(engine) as s:
        assert not s.exec(select(auth.Sesion).where(auth.Sesion.suplantada_por != None, auth.Sesion.usuario_id == ids.v1)).all()  # noqa: E711


def test_solo_en_la_web(mundo, monkeypatch):
    c, ids = mundo
    t_p = _token(ids.p)
    t = _entrar(c, ids, ids.v1, actor=t_p)["token"]
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.delenv("FE_LOCAL_ADMIN", raising=False)
    r = c.post(_ruta(ids.e1, ids.a1), headers=H(t_p))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web"
    r = c.post("/api/auth/volver", headers=H(t))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web"
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")                    # tampoco en el programa en modo soporte
    r = c.post(_ruta(ids.e1, ids.a1), headers=H(t_p))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web"
    monkeypatch.delenv("FE_LOCAL_ADMIN")
    monkeypatch.delenv("FE_MODO_LOCAL")
    with Session(engine) as s:
        assert not s.exec(select(auth.Sesion).where(auth.Sesion.suplantada_por != None, auth.Sesion.usuario_id == ids.a1)).all()  # noqa: E711
    texto = pathlib.Path(auth.__file__).read_text(encoding="utf-8").splitlines()
    for inicio in ('@admin.post("/cuentas/{eid}/usuarios/{uid}/entrar-como"', '@router.post("/volver"'):
        assert "Depends(solo_web)" in next(x for x in texto if x.startswith(inicio)), inicio


# ----------------------------------------------------------------------------- pantallas
def test_pantallas():
    adm = (JS / "pages" / "admin.js").read_text(encoding="utf-8")
    assert 'title="Entrar a la empresa como este usuario, para ver lo que él ve"' in adm and "👤" in adm
    assert "entrarComo(c,u)" in adm and "/entrar-como`, { method: 'POST' }" in adm
    boton = next(x for x in adm.splitlines() if "entrarComo(c,u)" in x)
    assert "!esLocal" in boton and "!u.bloqueado" in boton and "!c.bloqueada" in boton
    app_js = (JS / "app.js").read_text(encoding="utf-8")
    assert 'v-if="sesion.usuario?.soporte"' in app_js and "Está usando FISITAAP como {{sesion.usuario.correo}}" in app_js
    assert "soporte: {{sesion.usuario.soporte.correo}}" in app_js and "Volver a mi cuenta" in app_js
    assert "api('/api/auth/volver', { method: 'POST' })" in app_js
    volver = app_js[app_js.index("async volverCuenta()"):app_js.index("iniciales()")]
    assert "localStorage" not in volver and "setToken" not in volver                     # el token del administrador no se guarda aquí
    sec = (JS / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "soporte_entro_como:" in sec and "soporte_salio:" in sec
