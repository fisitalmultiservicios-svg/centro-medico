# -*- coding: utf-8 -*-
"""4.34, pedido de Norman (14 nov 2026): «en punto de venta la opcion para ver todas las ventas y imprimir a carta o reimprimir ticket».
Punto de venta › Ventas de caja (#/pos/ventas): todas las ventas de todas las cajas, con Ver (tiquete con COPIA), Carta (PDF del comprobante)
y Reimprimir (tiquete con COPIA por la impresora de tiquetes). Pruebas estáticas de las pantallas y, con Node, de las funciones puras de
pages/pos/_ventas.js. Nada va a una impresora, a la red ni a un servidor."""
import pathlib
import re

from tests.test_425_ultimos_pantallas import _js, _node, _tramo


def test_la_ruta_esta_en_la_tabla_y_entre_las_frescas():
    t = _js("app.js")
    assert "'/pos/ventas': 'pos/ventas'" in t
    assert "'/pos/ventas'" in _tramo(t, "const RUTAS_FRESCAS = [", "];")


def test_el_menu_la_pone_despues_de_caja_con_el_permiso_de_pos():
    m = _js("menu.js")
    bloque = _tramo(m, "{ label: 'Punto de venta'", "] },")
    assert bloque.index("{ label: 'Caja', to: '/pos/caja' }") < bloque.index("{ label: 'Ventas de caja', to: '/pos/ventas' }") < bloque.index("Cierres de caja")
    assert "permiso: 'pos'" in bloque.split("children")[0]                       # el del grupo, el mismo de Caja y Cierres
    assert "{ label: 'Ventas de caja', to: '/pos/ventas' }" in bloque and "permiso" not in re.search(r"\{ label: 'Ventas de caja'[^}]*\}", bloque).group(0)
    assert "['/pos', 'pos', true]" in m   # la regla de PERMISO_RUTA no se toca


def test_ver_y_reimprimir_llevan_copia_y_carta_el_pdf_sin_gaveta_ni_post():
    t = _js("pages/pos/ventas.js")
    assert "'&copia=true'" in t and "/tiquete?ancho=" in t
    assert "copia: true" in t and "docTiquete(" in t
    assert "'/api/comprobantes/' + r.doc_id + '/pdf'" in t
    assert "abrirGaveta" not in t
    assert "method: 'POST'" not in t and 'method:"POST"' not in t and "'POST'" not in t
    assert "api('/api/comprobantes/' + r.doc_id)" in t                         # solo lee el comprobante
    assert "impresoraTiqueteAqui(deCaja, impresoras())" in t and "uso !== 'etiquetas'" in t
    assert "Se abre el tiquete del navegador." in t and "imprimiendo[r.key]" in t  # sin doble clic


def test_los_botones_solo_salen_con_comprobante_vigente_y_los_abonos_no_son_ventas():
    t = _js("pages/pos/ventas.js")
    assert 'v-if="r.imprimible"' in t
    h = _js("pages/pos/_ventas.js")
    assert "v.doc_id && !v.anulada && v.tipo !== 'hab' && !v.abono" in h
    assert "if (!v || v.abono || v.tipo === 'abono') continue;" in h


def test_la_ventana_de_la_caja_trae_el_enlace_a_todas_las_ventas():
    m = _tramo(_js("pages/pos/caja.js"), '<Modal v-if="modalVentas && caja"', "</Modal>")
    assert re.search(r'<a class="btn sm ghost" href="#/pos/ventas" @click="modalVentas=false"[^>]*>Ver todas las ventas</a>', m)
    assert "Las de cajas anteriores están en Punto de venta › Ventas de caja." in m


def test_el_cajero_ve_solo_lo_de_hoy_y_la_regla_es_la_del_servidor():
    h = _js("pages/pos/_ventas.js")
    assert "HORAS_CAJERO = 6" in h and "UTC_CR = 6" in h
    t = _js("pages/pos/ventas.js")
    assert "sesion.modoCajero" in t and "Como cajero ve las ventas de hoy. Las anteriores las ve un supervisor o el administrador." in t
    assert 'v-if="!esCajero"' in t                                              # sin filtros de fecha para él
    assert "!sesion.modoCajero && rutaPermitida('/ventas/facturas')" in t       # el enlace al comprobante


def test_exporta_en_pdf_excel_y_csv_sin_numeros_de_tarjeta():
    t = _js("pages/pos/ventas.js")
    for f in ("descargar('pdf')", "descargar('xlsx')", "descargar('csv')"):
        assert f in t, f
    assert "descargarReporte('pdf'" in t and "descargarTabla(formato" in t
    for c in ("Fecha y hora", "Caja", "Cajero", "Comprobante", "Cliente", "Pago", "Total", "Estado"):
        assert "label: '" + c + "'" in t, c
    assert "v-html" not in t
    assert "Sin cajas todavía" in t and "La caja se abre desde Punto de venta › Caja." in t


_GUION = r"""
import { filasVentas, diaCR, desdeCajeroMs, dePrefijo, esDeSucursal } from './js/pages/pos/_ventas.js';
const nm = c => ({ '01': 'Efectivo', '02': 'Tarjeta' }[c] || c);
const cajaA = { id: 1, caja: 'Caja 1', terminal_id: 1, usuario: 'ana@x.cr', fecha: '2026-11-14', ventas: [
  { id: 1, doc_id: 10, consecutivo: 'T-1', total: 1000, medios: [{ medio: '01', monto: 1000 }], hora: '2026-11-15T05:30:00Z', usuario: 'ana@x.cr' },   // 23:30 del 14 en Costa Rica
  { id: 2, doc_id: 11, consecutivo: 'T-2', total: 500, medios: [{ medio: '02', monto: 500 }], hora: '2026-11-14T18:00:00Z', anulada: true },
  { id: 3, doc_id: null, consecutivo: 'HAB 3', tipo: 'hab', total: 700, medios: [{ medio: 'hab', monto: 700 }], hora: '2026-11-14T17:00:00Z' },
  { id: 4, doc_id: 12, consecutivo: 'ABONO 1', abono: true, total: 900, medios: [{ medio: '01', monto: 900 }], hora: '2026-11-14T16:00:00Z' },
  { id: 5, doc_id: 13, consecutivo: 'T-5', total: 300, cliente: 'Pedro', mesa: 'Mesa 4', medios: [], fiado: 300, hora: '2026-11-13T20:00:00Z' } ] };
const cajaB = { id: 2, caja: 'Barra', usuario: 'luis@x.cr', fecha: '2026-11-14', ventas: [ { id: 6, doc_id: 14, consecutivo: 'T-6', total: 200, medios: [{ medio: '01', monto: 200 }], hora: '2026-11-14T15:00:00Z' } ] };
const ay = { ventasDe: c => c.ventas, nombreMedio: nm };
const ahora = new Date('2026-11-15T06:00:00Z');   // 00:00 del 15 en Costa Rica
const dia = (d, extra) => filasVentas([cajaA, cajaB], Object.assign({ desde: d, hasta: d }, extra || {}), ahora, ay);
const d14 = dia('2026-11-14'), d15 = dia('2026-11-15'), todo = filasVentas([cajaA, cajaB], { desde: '2026-11-13', hasta: '2026-11-15' }, ahora, ay);
const cajero = filasVentas([cajaA, cajaB], { cajero: true }, ahora, ay);
const salida = {
  dia23: diaCR('2026-11-15T05:30:00Z'), dia06: diaCR('2026-11-15T06:00:00Z'),
  d14: d14.filas.map(f => f.consecutivo), d14n: d14.n, d14total: d14.total, d15: d15.filas.map(f => f.consecutivo),
  todoOrden: todo.filas.map(f => f.consecutivo), todoN: todo.n, todoTotal: todo.total,
  anuladas: filasVentas([cajaA], { desde: '2026-11-14', hasta: '2026-11-14', estado: 'anuladas' }, ahora, ay).filas.map(f => f.consecutivo),
  vigentes: filasVentas([cajaA], { desde: '2026-11-13', hasta: '2026-11-15', estado: 'vigentes' }, ahora, ay).filas.map(f => f.consecutivo),
  busca: filasVentas([cajaA, cajaB], { desde: '2026-11-13', hasta: '2026-11-15', q: 'mesa 4' }, ahora, ay).filas.map(f => f.consecutivo),
  buscaCajero: filasVentas([cajaA, cajaB], { desde: '2026-11-13', hasta: '2026-11-15', q: 'LUIS' }, ahora, ay).filas.map(f => f.consecutivo),
  caja2: filasVentas([cajaA, cajaB], { desde: '2026-11-13', hasta: '2026-11-15', cajaId: 2, cajaNombre: 'Barra' }, ahora, ay).filas.map(f => f.consecutivo),
  caja1: filasVentas([cajaA, cajaB], { desde: '2026-11-13', hasta: '2026-11-15', cajaId: 1, cajaNombre: 'Caja 1' }, ahora, ay).filas.map(f => f.consecutivo),
  estados: Object.fromEntries(todo.filas.map(f => [f.consecutivo, f.estado])), imprimibles: todo.filas.filter(f => f.imprimible).map(f => f.consecutivo),
  pagos: todo.filas.find(f => f.consecutivo === 'T-5').pagos.map(p => p.nombre),
  cajeroFilas: cajero.filas.map(f => f.consecutivo),
  desdeMadrugada: new Date(desdeCajeroMs(new Date('2026-11-15T07:00:00Z'))).toISOString(),   // 01:00 CR: ahora - 6 h = 01:00Z del 15, antes que las 06:00Z
  desdeTarde: new Date(desdeCajeroMs(new Date('2026-11-15T20:00:00Z'))).toISOString(),       // 14:00 CR: hoy 00:00 CR = 06:00Z
};
// 4.34: una caja de la sucursal 002 con ventas emitidas con su código, con el de la principal (un administrador con «Todas»), sin consecutivo,
// con uno que no es de Hacienda y una anulada de la otra sucursal
const cajaS = { id: 3, caja: 'Caja Norte', terminal_id: 3, usuario: 'ana@x.cr', fecha: '2026-11-14', ventas: [
  { id: 7, doc_id: 20, consecutivo: '00200001040000000007', total: 1000, medios: [{ medio: '01', monto: 600, referencia: '4111' }, { medio: '02', monto: 400 }], hora: '2026-11-14T15:00:00Z', usuario: 'ana@x.cr' },
  { id: 8, doc_id: 21, consecutivo: '00100001040000000008', total: 50, medios: [{ medio: '01', monto: 50 }], hora: '2026-11-14T16:00:00Z', usuario: 'ana@x.cr' },
  { id: 9, doc_id: 22, consecutivo: '', total: 60, medios: [{ medio: '01', monto: 60 }], hora: '2026-11-14T16:10:00Z', usuario: 'ana@x.cr' },
  { id: 10, doc_id: 23, consecutivo: '0020000104', total: 70, medios: [{ medio: '01', monto: 70 }], hora: '2026-11-14T16:20:00Z', usuario: 'ana@x.cr' },
  { id: 11, doc_id: 24, consecutivo: '00100001040000000011', anulada: true, total: 80, medios: [{ medio: '01', monto: 80 }], hora: '2026-11-14T16:30:00Z', usuario: 'luis@x.cr' } ] };
const porId = filas => Object.fromEntries(filas.map(f => [f.key.split('-')[1], f.imprimible]));
const resS = extra => filasVentas([cajaS], Object.assign({ desde: '2026-11-14', hasta: '2026-11-14' }, extra || {}), ahora, ay);
const deS = extra => filasVentas([cajaS], Object.assign({ desde: '2026-11-14', hasta: '2026-11-14' }, extra || {}), ahora, ay).filas;
const fijo = deS({ codigoSucursal: '002' });
salida.medios = fijo.find(f => f.doc_id === 20).medios;
salida.fijo = porId(fijo);
salida.fijoNumero = porId(deS({ codigoSucursal: 2 }));     // el código como número también vale
salida.principal = porId(deS({ codigoSucursal: '001' }));
salida.fijoCuenta = (x => [x.n, x.total])(resS({ codigoSucursal: '002' }));
salida.libreCuenta = (x => [x.n, x.total])(resS({ codigoSucursal: null }));
salida.libre = porId(deS({ codigoSucursal: null }));
salida.libreSinFiltro = porId(deS());
salida.prefijos = ['00200001040000000007', '', null, '0020000104', 'PENDIENTE ABC123', '002000010400000000071', 'ABONO 0000000007'].map(dePrefijo);
salida.esDe = [esDeSucursal('00100001040000000008', null), esDeSucursal('00100001040000000008', '002'), esDeSucursal('00200001040000000007', '002'), esDeSucursal('', '002'), esDeSucursal('', null)];
const cajaM = { id: 4, caja: 'Caja M', terminal_id: 4, usuario: 'ana@x.cr', fecha: '2026-11-15', ventas: [
  { id: 20, doc_id: 40, consecutivo: 'T-20', total: 10, medios: [], hora: '2026-11-15T00:03:00Z' },
  { id: 21, doc_id: 41, consecutivo: 'T-21', total: 10, medios: [], hora: '2026-11-15T05:55:00Z' } ] };
salida.margen = filasVentas([cajaM], { cajero: true }, new Date('2026-11-15T06:00:00Z'), ay).filas.map(f => [f.consecutivo, f.imprimible]);   // ventana desde 00:00Z
console.log(JSON.stringify(salida));
"""


def test_filtros_totales_y_ventana_del_cajero_con_node(tmp_path):
    r = _node(tmp_path, _GUION, ["pages/pos/_ventas.js"], None)
    assert r["dia23"] == "2026-11-14" and r["dia06"] == "2026-11-15"             # 05:30Z es la noche del 14 en Costa Rica
    # el día 14: T-1 (23:30 CR), T-2 anulada, HAB 3 y T-6; el abono no sale; más recientes primero
    assert r["d14"] == ["T-1", "T-2", "HAB 3", "T-6"], r["d14"]
    assert r["d14n"] == 2 and r["d14total"] == 1200                              # solo T-1 y T-6: sin la anulada ni el cargo a habitación
    assert r["d15"] == []                                                        # nada cae en el 15
    assert r["todoOrden"] == ["T-1", "T-2", "HAB 3", "T-6", "T-5"]
    assert r["todoN"] == 3 and r["todoTotal"] == 1500
    assert r["anuladas"] == ["T-2"] and r["vigentes"] == ["T-1", "HAB 3", "T-5"]
    assert r["busca"] == ["T-5"] and r["buscaCajero"] == ["T-6"]
    assert r["caja2"] == ["T-6"] and r["caja1"] == ["T-1", "T-2", "HAB 3", "T-5"]   # la caja B no trae terminal_id: se compara por el nombre
    assert r["estados"] == {"T-1": "Vigente", "T-2": "Anulada", "HAB 3": "Cargo a habitación", "T-6": "Vigente", "T-5": "Vigente"}
    assert r["imprimibles"] == ["T-1", "T-6", "T-5"]
    assert r["pagos"] == ["fiado"]
    assert r["desdeMadrugada"] == "2026-11-15T01:00:00.000Z" and r["desdeTarde"] == "2026-11-15T06:00:00.000Z"
    assert r["cajeroFilas"] == ["T-1"]                                           # ahora 00:00 CR del 15: solo lo de las últimas 6 horas (T-1 a las 23:30)
    assert r["medios"] == [{"medio": "01", "monto": 600}, {"medio": "02", "monto": 400}]   # 4.34: la COPIA por agente lleva los medios, sin referencias
    # 4.34: usuario fijo en la 002, en una caja de su sucursal: solo lo emitido con 002 ofrece botones (la regla de sucursales.pertenece);
    # la de 001 dice «De otra sucursal»; sin consecutivo de Hacienda (vacío o corto) no se ofrece, con el estado normal; la anulada, sin aviso
    assert r["fijo"] == {"7": True, "9": True, "10": True}, r["fijo"]            # la de 001 (8) y la anulada de 001 (11) no salen: ni lista, ni conteo, ni exportación
    assert r["fijoNumero"] == r["fijo"]
    assert r["fijoCuenta"] == [3, 1130] and r["libreCuenta"] == [4, 1180]       # sin la de otra sucursal: n y total no la cuentan
    assert r["principal"] == {"8": True, "9": True, "10": True, "11": False}
    assert r["margen"] == [["T-21", True], ["T-20", False]]                     # 4.34: a 3 minutos del límite del cajero no ofrece botones (el reloj de la caja puede ir adelantado)
    # sin sucursal fija no cambia nada: todo lo que tiene comprobante vigente se ve e imprime
    assert r["libre"] == {"7": True, "8": True, "9": True, "10": True, "11": False}
    assert r["libreSinFiltro"] == r["libre"]
    assert r["prefijos"] == ["002", "", "", "", "", "", ""]
    assert r["esDe"] == [True, False, True, False, True]


def test_reimprimir_usa_la_caja_de_la_venta_y_el_selector_las_de_la_sucursal():
    t = _js("pages/pos/ventas.js")
    assert "cajero: cfg.vendedor || r.sesion.caja" in t and "sesion.usuario?.nombre" not in t   # nunca quien reimprime
    assert "terms() { return terminales(); }" in t and "configPos().terminales || []; }," not in t.split("terminalDe(c)")[0]
    assert "De otra sucursal" not in t and "otraSucursal" not in t and "otraSucursal" not in _js("pages/pos/_ventas.js")


def test_la_sucursal_fija_se_compara_por_el_codigo_del_consecutivo():
    t = _js("pages/pos/ventas.js")
    assert "codigoSucursal: this.codigoSucursal" in t and "{ ventasDe, nombreMedio })" in t
    cod = _tramo(t, "    codigoSucursal() {", "    res() {")
    assert "if (!sesion.sucursal_fija) return null;" in cod                       # sin sucursal fija no hay límite
    assert "sesion.sucursales || []).find(s => s.id === sesion.sucursal_fija)" in cod and "sesion.sucursal_fija_codigo" in cod
    assert "String(c).padStart(3, '0')" in cod
    for viejo in ("sinSede", "sucursalFija", "correo"):                           # la regla anterior (caja sin sucursal + quién vendió) ya no está
        assert viejo not in t, viejo
        assert viejo not in _js("pages/pos/_ventas.js"), viejo
    h = _js("pages/pos/_ventas.js")
    assert "/^\\d{20}$/.test(t) ? t.slice(0, 3) : ''" in h
    assert "imprimible: sePuedeImprimir(v) && !enBorde" in h and "if (f.codigoSucursal && dePrefijo(v.consecutivo) && !esDeSucursal(v.consecutivo, f.codigoSucursal)) continue;" in h
    a = _js("app.js")
    assert "sucursal_fija_codigo: null" in a and "this.sucursal_fija_codigo = r.sucursal_fija_codigo || null;" in a


def test_la_lista_se_refresca_cada_minuto_y_el_reloj_se_quita_al_salir():
    t = _js("pages/pos/ventas.js")
    assert "mounted() { this._tick = setInterval(() => { this.tick++; }, 60000); }," in t
    assert "beforeUnmount() { clearInterval(this._tick); }," in t
    assert t.count("setInterval(") == 1 and ", 1000)" not in t                    # no recalcula cada segundo
    assert "sesiones() { this.listo; this.tick; return cajas(); }," in t and "this.listo; this.tick;\n      const t = this.terminalSel;" in t


def test_la_sesion_trae_el_codigo_de_la_sucursal_fija(monkeypatch):
    """4.34: resumen_sesion devuelve sucursal_fija_codigo ('002'), también cuando la lista sale vacía por haber una sola sucursal activa.
    Con una base SQLite en memoria: no toca las bases de las empresas."""
    from types import SimpleNamespace
    from sqlalchemy.pool import StaticPool
    from sqlmodel import Session, create_engine
    from app import db, sucursales
    from app.sucursales import Sucursal
    eng = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Sucursal.__table__.create(eng)
    with Session(eng) as s:
        s.add_all([Sucursal(id=1, empresa_id=9, codigo=1, nombre="Principal", principal=True), Sucursal(id=2, empresa_id=9, codigo=2, nombre="Norte"),
                   Sucursal(id=3, empresa_id=9, codigo=3, nombre="Cerrada", activa=False), Sucursal(id=4, empresa_id=8, codigo=4, nombre="De otra empresa")])
        s.commit()
    monkeypatch.setattr(db, "engine_empresa", lambda eid: eng)
    m = lambda sid: SimpleNamespace(sucursal_id=sid)  # noqa: E731
    r = sucursales.resumen_sesion(None, 9, m(2))
    assert r["sucursal_fija"] == 2 and r["sucursal_fija_codigo"] == "002" and [x["id"] for x in r["sucursales"]] == [1, 2]
    assert {x["id"]: x["codigo"] for x in r["sucursales"]} == {1: 1, 2: 2}            # la lista ya traía el código (sin cambios)
    assert sucursales.resumen_sesion(None, 9, m(3))["sucursal_fija_codigo"] == "003"   # la fija desactivada también
    assert sucursales.resumen_sesion(None, 9, None)["sucursal_fija_codigo"] is None     # sin sucursal fija
    assert sucursales.resumen_sesion(None, 9, m(None))["sucursal_fija_codigo"] is None
    assert sucursales.resumen_sesion(None, 9, m(4))["sucursal_fija_codigo"] is None    # una de otra empresa no cuenta
    with Session(eng) as s:                                                            # cierran la Norte: queda una sola activa
        x = s.get(Sucursal, 2); x.activa = False; s.add(x); s.commit()
    r = sucursales.resumen_sesion(None, 9, m(1))
    assert r["sucursales"] == [] and r["sucursal_fija"] == 1 and r["sucursal_fija_codigo"] == "001"   # la lista vacía, el código sí

    def _falla(eid):
        raise RuntimeError("sin base")
    monkeypatch.setattr(db, "engine_empresa", _falla)
    assert sucursales.resumen_sesion(None, 9, m(2)) == {"sucursales": [], "sucursal_fija": 2, "sucursal_fija_codigo": None}


def test_434_celular_tarjetas_y_singular():
    """Foto del arnés en celular: los botones quedaban fuera de la vista. En ≤ 700 px cada venta es una tarjeta; «1 venta» en singular."""
    raiz = pathlib.Path(__file__).resolve().parents[1]
    t = (raiz / "app/static/js/pages/pos/ventas.js").read_text(encoding="utf-8")
    css = (raiz / "app/static/ui.css").read_text(encoding="utf-8")
    assert '<table class="tbl tbl-ventas">' in t
    for etiqueta in ("Fecha", "Caja", "Cajero", "Comprobante", "Cliente", "Pago", "Total", "Estado"):
        assert 'data-l="' + etiqueta + '"' in t, etiqueta
    assert '<td class="acciones-venta">' in t
    assert "r.n === 1 ? ' venta · ' : ' ventas · '" in t
    m = re.search(r"@media \(max-width:700px\)\{(\.tbl-ventas[^\n]*)\}\n", css)
    assert m and ".tbl-ventas thead{display:none}" in m.group(1) and "content:attr(data-l)" in m.group(1), m
