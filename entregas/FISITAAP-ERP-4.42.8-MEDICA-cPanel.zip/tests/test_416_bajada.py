# -*- coding: utf-8 -*-
"""4.16, etapa 2a, tramo A: diario de cambios, canal de bajada, comprobantes y cobros en dos sentidos, XML viejos a pedido y ciclo corto."""
import base64
import json
from datetime import datetime, timezone

from sqlmodel import Session, select

from app import cola, main as M, modulos, sinc
from app.db import Documento, engine_empresa
from app.sinc_diario import SincDiario
from test_49_local_sinc import H, _admin_empresa, _cfg, _modo_local, _Respuesta, _vincular, c

FECHA = "2026-11-08T08:00:00-06:00"


def _doc(eid, n, estado="firmado", xml=None, **extra):
    clave = f"506{n:047d}"
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=eid, tipo_documento="04", clave=clave, consecutivo=f"00100001040{n:09d}", fecha_emision=FECHA, estado=estado, ambiente="sandbox",
                      receptor_nombre="QA", moneda="CRC", total=1000, xml_nombre=f"{clave}.xml" if xml else None, **extra)
        s.add(d); s.commit(); s.refresh(d)
        if xml:
            (M.XML_DIR / d.xml_nombre).write_bytes(xml)
        return d.id


def _clave(n):
    return f"506{n:047d}"


def _en(eid, n):
    with Session(engine_empresa(eid)) as s:
        return s.exec(select(Documento).where(Documento.clave == _clave(n))).first()


def _cobro(eid, did, monto=1000, numero=1, **extra):
    with Session(engine_empresa(eid)) as s:
        p = modulos.Pago(empresa_id=eid, numero=numero, fecha="2026-11-08", cuenta="Caja", monto=monto, facturas=json.dumps([{"id": did, "monto": monto}]), moneda="CRC", **extra)
        s.add(p); s.commit(); s.refresh(p)
        modulos.aplicar_pago(s, eid, [{"id": did, "monto": monto}], 1); s.commit()
        return p.id


def _pareja(monkeypatch, sufijo, a, b):
    eid_a, ta = _admin_empresa(sufijo + "n", a)
    eid_b, tb = _admin_empresa(sufijo + "l", b)
    shim = _modo_local(monkeypatch)
    return eid_a, ta, eid_b, tb, shim


def _pagos(eid):
    with Session(engine_empresa(eid)) as s:
        return s.exec(select(modulos.Pago)).all()


def test_lo_emitido_en_la_nube_baja_una_vez_y_no_regresa(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-a1", "3101416001", "3101416002")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 1, estado="enviado", xml=b"<xml>uno</xml>")
    sinc.sincronizar(eid_b)
    d = _en(eid_b, 1)
    assert d is not None and d.estado == "enviado" and d.origen_sinc == sinc.ORIGEN_NUBE and d.sinc_estado == "enviado"
    assert (M.XML_DIR / d.xml_nombre).read_bytes() == b"<xml>uno</xml>"
    # cambio de estado en la nube: baja; y lo que bajó no vuelve a subir
    with Session(engine_empresa(eid_a)) as s:
        x = s.exec(select(Documento).where(Documento.clave == _clave(1))).one(); x.estado = "aceptado"; s.add(x); s.commit()
    llamadas = []
    original = sinc._post
    monkeypatch.setattr(sinc, "_post", lambda url, cab, ruta, cuerpo, timeout=None: llamadas.append(cuerpo) or original(url, cab, ruta, cuerpo))
    sinc.sincronizar(eid_b, nube=False, red=False, ligero=True)
    assert _en(eid_b, 1).estado == "aceptado"
    assert not any(cuerpo.get("documentos") for cuerpo in llamadas)
    # la nube no lo envía otra vez a Hacienda desde la computadora, ni lo retoma pasado el plazo
    with Session(engine_empresa(eid_b)) as s:
        x = s.exec(select(Documento).where(Documento.clave == _clave(1))).one(); x.estado = "firmado"; x.sinc_en = "2026-01-01T00:00:00+00:00"; s.add(x); s.commit()
        assert cola.retomables(s, eid_b) == []
        assert sinc._huerfanos_red(s, eid_b) == []


def test_lo_que_subio_una_computadora_no_le_baja(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-a2", "3101416003", "3101416004")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_b, 2, estado="firmado", xml=b"<xml>dos</xml>")
    sinc.sincronizar(eid_b)
    assert _en(eid_a, 2) is not None
    with Session(engine_empresa(eid_a)) as s:
        linea = s.exec(select(SincDiario).where(SincDiario.ref == _clave(2))).one()
        assert linea.origen == _cfg(eid_b)["terminal"]
    tok = _token(eid_b)
    r = c.get("/api/sinc/novedades?desde=0", headers=H(tok)).json()
    assert _clave(2) not in [d["clave"] for d in r["documentos"]]
    assert r["cursor"] >= linea.id                                              # aunque no haya nada para ella, avanza


def _token(eid):
    from app import secretos
    from app.db import Empresa, engine
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        return secretos.descifrar(e.clave_cifrada, _cfg(eid)["token"])


def test_historia_sin_efectos_y_xml_a_pedido(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-a3", "3101416005", "3101416006")
    did = _doc(eid_a, 3, estado="aceptado", xml=b"<xml>viejo</xml>")
    _cobro(eid_a, did, 700, 4)
    _vincular(monkeypatch, ta, tb, "Caja")
    r = c.get("/api/sinc/novedades?desde=0", headers=H(_token(eid_b))).json()
    x = next(d for d in r["documentos"] if d["clave"] == _clave(3))
    assert x["historia"] is True and x["sin_xml"] is True and "xml_b64" not in x and r["pagos"][0]["historia"] is True
    sinc.sincronizar(eid_b)
    d = _en(eid_b, 3)
    assert d.estado == "aceptado" and d.xml_nombre == f"{_clave(3)}.xml" and d.pagado == 700
    p = _pagos(eid_b)
    assert len(p) == 1 and p[0].numero == 4 and p[0].origen_sinc.startswith("0:")
    # el XML viejo se trae cuando se pide (en estas pruebas nube y computadora comparten carpeta: la respuesta de la nube se simula)
    (M.XML_DIR / d.xml_nombre).unlink()
    shim.forzar = _Respuesta(200, {"xml_b64": base64.b64encode(b"<xml>viejo</xml>").decode()})
    sinc.traer_archivos(eid_b, d)
    shim.forzar = None
    assert (M.XML_DIR / d.xml_nombre).read_bytes() == b"<xml>viejo</xml>"
    # sin conexión o sin respuesta no falla: quien llama informa que el archivo no está
    (M.XML_DIR / d.xml_nombre).unlink()
    shim.forzar = _Respuesta(503, {})
    sinc.traer_archivos(eid_b, d)
    shim.forzar = None
    assert not (M.XML_DIR / d.xml_nombre).exists()


def test_cobros_en_dos_sentidos_y_sus_bajas(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-a4", "3101416007", "3101416008")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_a, 4, estado="aceptado", xml=b"<x/>")
    pid = _cobro(eid_a, did, 300, 5)
    sinc.sincronizar(eid_b)
    assert _en(eid_b, 4).pagado == 300 and len(_pagos(eid_b)) == 1
    # baja en la nube: desaparece también en la computadora
    with Session(engine_empresa(eid_a)) as s:
        p = s.get(modulos.Pago, pid); modulos.aplicar_pago(s, eid_a, json.loads(p.facturas), -1); s.delete(p); s.commit()
    sinc.sincronizar(eid_b)
    assert _pagos(eid_b) == [] and not _en(eid_b, 4).pagado
    # cobro hecho en la computadora: sube; y su baja también
    local = _en(eid_b, 4)
    lid = _cobro(eid_b, local.id, 200, 9)
    sinc.sincronizar(eid_b)
    assert len(_pagos(eid_a)) == 1 and _en(eid_a, 4).pagado == 200
    with Session(engine_empresa(eid_b)) as s:
        p = s.get(modulos.Pago, lid); modulos.aplicar_pago(s, eid_b, json.loads(p.facturas), -1); s.delete(p); s.commit()
    sinc.sincronizar(eid_b)
    assert _pagos(eid_a) == [] and not _en(eid_a, 4).pagado
    # y esa baja no regresa ni se repite
    assert sinc.sincronizar(eid_b) is not None and _pagos(eid_b) == []


def test_una_computadora_no_borra_cobros_de_otra(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-a5", "3101416009", "3101416010")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_a, 5, estado="aceptado", xml=b"<x/>")
    _cobro(eid_a, did, 100, 6, origen_sinc="77:12")
    r = c.post("/api/sinc/cambios", headers=H(_token(eid_b)), json={"terminal": _cfg(eid_b)["terminal"], "pagos_borrados": ["77:12"]}).json()
    assert r["pagos_borrados"] == 0 and len(_pagos(eid_a)) == 1


def test_paginas_y_ciclo_corto_sin_escritura(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-a6", "3101416011", "3101416012")
    _vincular(monkeypatch, ta, tb, "Caja")
    for n in range(60, 65):
        _doc(eid_a, n, estado="firmado", xml=b"<x/>")
    monkeypatch.setattr(sinc, "LIMITE_NOVEDADES", 2)
    sinc.sincronizar(eid_b)
    assert all(_en(eid_b, n) is not None for n in range(60, 65))
    cfg = _cfg(eid_b)
    assert cfg["cursor_bajada"] > 0
    # sin novedades: el ciclo corto no pide catálogos ni escribe la configuración
    rutas = []
    original = shim.get
    monkeypatch.setattr(shim, "get", lambda url, headers=None, timeout=None: rutas.append(url) or original(url, headers=headers, timeout=timeout))
    with Session(engine_empresa(eid_b)) as s:
        v0 = modulos._registro(s, eid_b, sinc.CLAVE_LOCAL).version
    sinc.sincronizar(eid_b, nube=False, red=False, ligero=True)
    assert len(rutas) == 1 and "/api/sinc/novedades" in rutas[0]
    with Session(engine_empresa(eid_b)) as s:
        assert modulos._registro(s, eid_b, sinc.CLAVE_LOCAL).version == v0


def test_paquete_con_errores_reintenta_y_luego_sigue(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-a7", "3101416013", "3101416014")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 7, estado="firmado", xml=b"<x/>")
    monkeypatch.setattr(sinc, "_guardar_documentos", lambda *a, **k: ([], [{"clave": "X", "error": "malo"}]))
    for i in range(sinc.INTENTOS_BAJADA - 1):
        sinc.sincronizar(eid_b, nube=False, red=False, ligero=True)
        assert not _cfg(eid_b).get("cursor_bajada")
    sinc.sincronizar(eid_b, nube=False, red=False, ligero=True)
    cfg = _cfg(eid_b)
    assert cfg["cursor_bajada"] > 0 and "no se pudieron bajar" in cfg["aviso_bajada"] and cfg["saltados"]


def test_el_diario_no_guarda_lo_que_se_deshizo():
    eid, _ = _admin_empresa("-a8", "3101416015")
    with Session(engine_empresa(eid)) as s:
        s.add(Documento(empresa_id=eid, tipo_documento="04", clave=_clave(8), consecutivo="00100001040000000008", fecha_emision=FECHA, estado="firmado", ambiente="sandbox",
                        receptor_nombre="QA", moneda="CRC", total=1)); s.flush()
        assert s.exec(select(SincDiario).where(SincDiario.ref == _clave(8))).first() is not None
        s.rollback()
    with Session(engine_empresa(eid)) as s:
        assert s.exec(select(SincDiario).where(SincDiario.ref == _clave(8))).first() is None


def test_un_cambio_nuevo_siempre_recibe_un_numero_mayor():
    eid, _ = _admin_empresa("-a9", "3101416016")
    _doc(eid, 9, estado="firmado")
    with Session(engine_empresa(eid)) as s:
        primero = s.exec(select(SincDiario).where(SincDiario.ref == _clave(9))).one().id
    for estado in ("enviado", "aceptado"):
        with Session(engine_empresa(eid)) as s:
            d = s.exec(select(Documento).where(Documento.clave == _clave(9))).one(); d.estado = estado; s.add(d); s.commit()
        with Session(engine_empresa(eid)) as s:
            nuevo = s.exec(select(SincDiario).where(SincDiario.ref == _clave(9))).one().id
        assert nuevo > primero
        primero = nuevo
    # lo interno de cada base no genera líneas
    with Session(engine_empresa(eid)) as s:
        d = s.exec(select(Documento).where(Documento.clave == _clave(9))).one(); d.sinc_en = datetime.now(timezone.utc).isoformat(); s.add(d); s.commit()
    with Session(engine_empresa(eid)) as s:
        assert s.exec(select(SincDiario).where(SincDiario.ref == _clave(9))).one().id == primero


# ---- revisión independiente
def test_lo_propio_no_se_vuelve_de_la_nube(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b1", "3101416101", "3101416102")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_b, 101, estado="firmado", xml=b"<x/>")
    sinc.sincronizar(eid_b)
    _cobro(eid_a, _en(eid_a, 101).id, 400, 3)                                   # un cobro en la web trae el comprobante en el mismo paquete
    sinc.sincronizar(eid_b)
    d = _en(eid_b, 101)
    assert not d.origen_sinc and d.pagado == 400 and d.estado == "firmado"


def test_estado_intermedio_propio_no_retrocede_y_el_final_si_cuenta(monkeypatch):
    eid, _ = _admin_empresa("-b2", "3101416103")
    _doc(eid, 102, estado="enviado", sinc_estado="firmado", sinc_en="2026-11-08T00:00:00+00:00", mensaje_hacienda="enviado aquí")
    with Session(engine_empresa(eid)) as s:
        sinc._guardar_documentos(s, eid, [{"clave": _clave(102), "estado": "firmado", "mensaje_hacienda": "copia vieja"}], sinc.ORIGEN_NUBE, de_red=True, desde_nube=True)
    d = _en(eid, 102)
    assert d.estado == "enviado" and d.mensaje_hacienda == "enviado aquí" and d.sinc_estado == "firmado"       # lo suyo todavía tiene que subir
    with Session(engine_empresa(eid)) as s:
        sinc._guardar_documentos(s, eid, [{"clave": _clave(102), "estado": "aceptado", "mensaje_hacienda": "la nube lo retomó"}], sinc.ORIGEN_NUBE, de_red=True, desde_nube=True)
    assert _en(eid, 102).estado == "aceptado"


def test_id_reutilizado_no_se_confunde(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b3", "3101416105", "3101416106")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 103, estado="aceptado", xml=b"<x/>")
    sinc.sincronizar(eid_b)
    local = _en(eid_b, 103).id
    t1, t2 = datetime(2026, 11, 8, 10, tzinfo=timezone.utc), datetime(2026, 11, 8, 11, tzinfo=timezone.utc)
    _cobro(eid_b, local, 100, 55, id=20000055, creado=t1)
    sinc.sincronizar(eid_b)
    assert [p.monto for p in _pagos(eid_a)] == [100]
    with Session(engine_empresa(eid_b)) as s:
        p = s.get(modulos.Pago, 20000055); modulos.aplicar_pago(s, eid_b, json.loads(p.facturas), -1); s.delete(p); s.commit()
    _cobro(eid_b, local, 250, 55, id=20000055, creado=t2)                       # corrección: mismo número, sin sincronizar en medio
    sinc.sincronizar(eid_b)
    assert [p.monto for p in _pagos(eid_a)] == [250] and _en(eid_a, 103).pagado == 250


def test_una_computadora_no_borra_lo_conciliado(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b4", "3101416107", "3101416108")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 104, estado="aceptado", xml=b"<x/>")
    sinc.sincronizar(eid_b)
    lid = _cobro(eid_b, _en(eid_b, 104).id, 90, 7)
    sinc.sincronizar(eid_b)
    with Session(engine_empresa(eid_a)) as s:
        p = s.exec(select(modulos.Pago)).one(); p.estado = "Conciliado"; s.add(p); s.commit()
    with Session(engine_empresa(eid_b)) as s:
        p = s.get(modulos.Pago, lid); modulos.aplicar_pago(s, eid_b, json.loads(p.facturas), -1); s.delete(p); s.commit()
    sinc.sincronizar(eid_b)
    assert len(_pagos(eid_a)) == 1 and not _cfg(eid_b).get("ultimo_error")


def test_la_reversion_por_rechazo_no_sube_como_baja(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b5", "3101416109", "3101416110")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_b, 105, estado="rechazado", mensaje_hacienda="Rechazado (QA)")
    _cobro(eid_b, did, 80, 8)
    with Session(engine_empresa(eid_b)) as s:
        assert M.revertir_cobros_rechazado(s, eid_b, s.get(Documento, did), "enviado") == 1
        terminal = _cfg(eid_b)["terminal"]
        assert s.exec(select(SincDiario).where(SincDiario.tipo == "pago", SincDiario.borrado == True, SincDiario.origen == terminal)).all() == []  # noqa: E712


def test_cobro_tarde_sobre_un_rechazado_no_entra(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b6", "3101416111", "3101416112")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 106, estado="rechazado", xml=b"<x/>")
    r = c.post("/api/sinc/cambios", headers=H(_token(eid_b)), json={"terminal": _cfg(eid_b)["terminal"], "pagos": [
        {"id": 5, "sello": 1, "monto": 10, "moneda": "CRC", "facturas": [{"clave": _clave(106), "monto": 10}]}]}).json()
    assert r["pagos"] == [] and "rechazó" in r["errores"][0]["error"] and _pagos(eid_a) == []


def test_un_problema_pasajero_nunca_salta_el_paquete(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b7", "3101416113", "3101416114")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 107, estado="firmado", xml=b"<x/>")
    monkeypatch.setattr(sinc, "_guardar_documentos", lambda *a, **k: ([], [{"clave": "X", "error": "database is locked"}]))
    for _ in range(sinc.INTENTOS_BAJADA + 2):
        sinc.sincronizar(eid_b, nube=False, red=False, ligero=True)
    assert not _cfg(eid_b).get("cursor_bajada") and not _cfg(eid_b).get("aviso_bajada")


def test_no_se_borra_aqui_la_copia_de_un_cobro_ajeno(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b8", "3101416115", "3101416116")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_b, 108, estado="aceptado")
    pid = _cobro(eid_b, did, 70, 9, origen_sinc="3:40:123")
    assert c.delete(f"/api/pagos/{pid}", headers=H(tb)).status_code == 409
    assert len(_pagos(eid_b)) == 1


def test_lo_cobrado_sin_cobro_baja_como_base(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b9", "3101416117", "3101416118")
    did = _doc(eid_a, 109, estado="aceptado", xml=b"<x/>", pagado=500)
    _cobro(eid_a, did, 200, 10)                                                 # 500 importados + 200 cobrados
    _vincular(monkeypatch, ta, tb, "Caja")
    sinc.sincronizar(eid_b)
    assert _en(eid_b, 109).pagado == 700


def test_lo_propio_de_una_terminal_anterior_no_se_duplica(monkeypatch):
    eid, _ = _admin_empresa("-b10", "3101416119")
    did = _doc(eid, 110, estado="aceptado")
    pid = _cobro(eid, did, 60, 11)
    with Session(engine_empresa(eid)) as s:
        p = s.get(modulos.Pago, pid)
        ref = f"2:{pid}:{sinc.diario.sello(p)}"
        assert sinc._guardar_pago(s, eid, {"facturas": [], "monto": 60}, ref, "Nube", {}, propias={3, 2}) is False
    assert len(_pagos(eid)) == 1


def test_el_ciclo_no_pisa_una_desvinculacion():
    eid, _ = _admin_empresa("-b11", "3101416121")
    sincro = {"vinculado": True, "token": "x", "cursor_bajada": 1}
    with Session(engine_empresa(eid)) as s:
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, sincro); s.commit()
        cfg = sinc._cfg_local(s, eid)
        inicial = json.loads(json.dumps(cfg))
        cfg["cursor_bajada"] = 9                                                # el ciclo avanza...
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, {**sincro, "vinculado": False, "token": None}); s.commit()   # ...y mientras tanto el usuario desvincula
        sinc._guardar_cfg(s, eid, cfg, inicial)
    fin = _cfg(eid)
    assert fin["vinculado"] is False and fin["token"] is None and fin["cursor_bajada"] == 9


def test_trae_la_respuesta_aunque_ya_tenga_el_xml(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-b12", "3101416123", "3101416124")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_b, 112, estado="aceptado", xml=b"<x/>", respuesta_nombre=f"{_clave(112)}_respuesta.xml")
    (M.XML_DIR / f"{_clave(112)}_respuesta.xml").unlink(missing_ok=True)
    shim.forzar = _Respuesta(200, {"respuesta_b64": base64.b64encode(b"<r/>").decode()})
    sinc.traer_archivos(eid_b, _en(eid_b, 112))
    shim.forzar = None
    assert (M.XML_DIR / f"{_clave(112)}_respuesta.xml").read_bytes() == b"<r/>" and did


def test_cursor_mayor_que_el_tope_vuelve_a_empezar(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b13", "3101416125", "3101416126")
    _vincular(monkeypatch, ta, tb, "Caja")
    _doc(eid_a, 113, estado="firmado", xml=b"<x/>")
    r = c.get("/api/sinc/novedades?desde=99999999", headers=H(_token(eid_b))).json()
    assert _clave(113) in [d["clave"] for d in r["documentos"]]


def test_no_se_envia_a_mano_lo_emitido_en_la_web(monkeypatch):
    eid_a, ta, eid_b, tb, _ = _pareja(monkeypatch, "-b14", "3101416127", "3101416128")
    _vincular(monkeypatch, ta, tb, "Caja")
    did = _doc(eid_b, 114, estado="firmado", xml=b"<x/>", origen_sinc=sinc.ORIGEN_NUBE)
    assert c.post(f"/api/comprobantes/{did}/enviar", headers=H(tb)).status_code == 409


def test_crear_tablas_tolera_a_otro_proceso(monkeypatch):
    from sqlalchemy.exc import OperationalError
    from sqlmodel import SQLModel
    from app import db
    llamadas = []

    def create_all(eng, tables=None):
        llamadas.append(1)
        if len(llamadas) == 1:
            raise OperationalError("CREATE TABLE sinc_diario", {}, Exception("table sinc_diario already exists"))
    monkeypatch.setattr(SQLModel.metadata, "create_all", create_all)
    db._crear_tablas(None)
    assert len(llamadas) == 2
