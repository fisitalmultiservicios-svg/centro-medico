# -*- coding: utf-8 -*-
"""4.12: etapa 1 del plan sin internet (franja y plazo de Hacienda, usuarios y credenciales que bajan, PIN de caja, correo desde la nube,
tareas solo en la nube, gracia del plan, situación 3 apagada) y la venta de la caja que se perdía al recargar."""
import json
import pathlib
import re
import shutil
import subprocess
from datetime import date, datetime, timedelta, timezone

import pytest
from sqlmodel import Session, select

from app import auth, main as M, sinc
from app.config import ahora_cr
from app.db import Documento, Empresa, engine, engine_empresa
from test_49_local_sinc import H, PW, _admin_empresa, _modo_local, _poner_cfg, c

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")


def _doc(eid, n, fecha, estado="firmado", **extra):
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=eid, tipo_documento="04", clave=f"506{n:047d}", consecutivo=f"00100002040{n:09d}", fecha_emision=fecha, estado=estado, ambiente="sandbox", moneda="CRC", tipo_cambio=1, total=1000, **extra)
        s.add(d); s.commit()


def test_dias_habiles_del_plazo():
    assert sinc._mas_habiles(date(2026, 11, 6), 2) == date(2026, 11, 10)       # viernes → martes
    assert sinc._mas_habiles(date(2026, 11, 9), 2) == date(2026, 11, 11)


def test_franja_conexion_y_plazo(monkeypatch):
    eid, _ = _admin_empresa("-e1a", "3101412001")
    _modo_local(monkeypatch)
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); e.ambiente = "sandbox"; sc.add(e); sc.commit()

    def franja():
        with Session(engine) as sc, Session(engine_empresa(eid)) as s:
            return sinc.franja_local(s, sc.get(Empresa, eid))
    assert franja()["nivel"] is None
    _poner_cfg(eid, vinculado=True, sin_conexion_desde=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    f = franja()
    assert f["nivel"] == "info" and f["conectado"] is False and "Sin conexión" in f["texto"] and f["por_subir"] == 0 and "0 cambio(s) por subir" in f["texto"]
    hoy = ahora_cr().date()
    _doc(eid, 1, (hoy - timedelta(days=15)).isoformat() + "T08:00:00-06:00")
    f = franja()
    assert f["nivel"] == "vencido" and f["pendientes"] == 1 and "2 días hábiles" in f["texto"] and f["por_subir"] == 1 and "1 cambio(s) por subir" in f["texto"]
    _poner_cfg(eid, sin_conexion_desde=None)
    with Session(engine_empresa(eid)) as s:
        for d in s.exec(select(Documento)).all():
            s.delete(d)
        s.commit()
    _doc(eid, 2, hoy.isoformat() + "T08:00:00-06:00")
    assert franja()["nivel"] is None                                           # conectado y con tiempo de sobra: sin franja


def test_bajan_usuarios_roles_y_bloqueos(monkeypatch):
    eid, t = _admin_empresa("-e1b", "3101412002")
    _modo_local(monkeypatch)
    with Session(engine) as sc:
        admin = sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).first()
        aqui = admin.usuario_id
        base = {"nombre": "Cajera Nube", "password_hash": auth.hash_password("Clave-Nube-12345"), "pin_hash": None, "bloqueado": False, "terminos_version": auth.TERMINOS_VERSION, "paleta": "turquesa", "rol": "Cajero", "sucursal_id": None, "modulos_ocultos": None}
        sinc._bajar_usuarios(sc, eid, {"usuarios": [{**base, "correo": "cajera412@example.test"}], "roles": [{"nombre": "Bodega QA", "descripcion": "x", "permisos": "[\"inventario\"]"}]})
        u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "cajera412@example.test")).first()
        assert u and u.de_nube and sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == eid)).first().rol == "Cajero"
        assert auth.rol_personalizado(sc, eid, "Bodega QA")
        uid = u.id
        sc.add(auth.Sesion(usuario_id=uid, sid="sid-e1b", expira=datetime.now(timezone.utc) + timedelta(hours=1))) if hasattr(auth.Sesion, "sid") else None
        sc.commit()
        sinc._bajar_usuarios(sc, eid, {"usuarios": [{**base, "correo": "cajera412@example.test", "bloqueado": True}], "roles": []})
        sc.refresh(u)
        assert u.bloqueado
        sinc._bajar_usuarios(sc, eid, {"usuarios": [], "roles": []})          # ya no está en la empresa; la que se creó aquí sigue
        filas = sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).all()
        assert {m.usuario_id for m in filas} == {aqui}
        # limpieza
        sc.delete(sc.get(auth.Usuario, uid)); sc.commit()
    fuente = (RAIZ / "app" / "sinc.py").read_text(encoding="utf-8")
    assert "**_usuarios_empresa(eid)} if inst else {}" in fuente               # solo al token de una instalación
    assert "if not u.es_superadmin" in fuente


def test_credenciales_bajan_cuando_cambian():
    class E:
        id = 1; usuario_hacienda = "a"; password_hacienda = "b"; p12_nombre = None; p12_pin = None; p12_vence = None; ambiente = "sandbox"
    h1 = sinc._huella_credenciales(E)
    E.ambiente = "produccion"
    assert sinc._huella_credenciales(E) != h1


def test_pin_de_caja(monkeypatch):
    eid, t = _admin_empresa("-e1c", "3101412003")
    correo = "pincajera412@example.test"
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre="Cajera PIN", password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION, paleta="turquesa")
        sc.add(u); sc.flush(); uid = u.id
        sc.add(auth.UsuarioEmpresa(usuario_id=uid, empresa_id=eid, rol="Cajero")); sc.commit()
        tok = auth._respuesta(sc, u, eid)["token"]
    assert c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"}).status_code == 404   # en la nube no existe
    assert c.put("/api/auth/pin", headers=H(tok), json={"pin": "1234", "password": PW}).status_code == 400   # muy fácil
    assert c.put("/api/auth/pin", headers=H(tok), json={"pin": "4827", "password": "mala"}).status_code == 400
    assert c.put("/api/auth/pin", headers=H(tok), json={"pin": "4827", "password": PW}).status_code == 200
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    assert c.get("/api/auth/estado").json()["pin_local"] is True
    assert c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "9999"}).status_code == 401
    r = c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"})
    assert r.status_code == 200 and r.json().get("token"), r.text
    with Session(engine) as sc:                                                # un rol que no es de caja no entra con PIN
        m = sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).first(); m.rol = "Administrador"; sc.add(m); sc.commit()
    assert c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"}).status_code == 403
    with Session(engine) as sc:                                                # el usuario de la nube cambia contraseña y PIN en la web
        u = sc.get(auth.Usuario, uid); u.de_nube = True; sc.add(u); sc.commit()
    r = c.put("/api/auth/pin", headers=H(tok), json={"pin": "4827", "password": PW})
    assert r.status_code == 400 and "nube" in r.text


def test_correo_desde_la_nube_y_sin_enlace_local(monkeypatch):
    llamado = []
    monkeypatch.setattr(M.threading, "Thread", lambda *a, **k: llamado.append(1) or type("T", (), {"start": lambda self: None})())
    e = type("E", (), {"id": 1, "correo_automatico": True, "smtp_host": "x", "smtp_remitente": "y"})()
    d = type("D", (), {"id": 5, "correo_enviado": None, "cliente_id": 9})()
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(sinc, "correo_en_nube", lambda eid: True)
    M._programar_correo_automatico(e, d, None)
    assert not llamado
    assert M.enlace_publico(e, 5, "http://127.0.0.1:8020") is None


def test_gracia_del_plan_y_situacion_3(monkeypatch):
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    hoy = ahora_cr().date()
    assert sinc.fecha_confirmada(999999, (hoy - timedelta(days=8)).isoformat()) is False    # sin vincular: nunca bloquea (tiene que poder vincularse)
    monkeypatch.setattr(sinc, "vinculada", lambda eid: True)
    assert sinc.fecha_confirmada(999999, (hoy - timedelta(days=8)).isoformat()) is True     # vinculada: pasó la gracia
    monkeypatch.delenv("FE_SITUACION_3", raising=False)
    alcanza = set()
    monkeypatch.setattr(sinc, "_alcanza", lambda h: h in alcanza)

    def situacion():
        sinc._SITUACION["t"] = -1e9                                            # sin el resultado guardado
        return sinc.situacion_emision()
    assert situacion() == "3"                                                  # sin internet
    alcanza.add("1.1.1.1")
    assert situacion() == "1"                                                  # hay internet y Hacienda está caída: normal, se reenvía
    alcanza.clear(); alcanza.add("api.comprobanteselectronicos.go.cr")
    assert situacion() == "1"
    alcanza.clear()
    monkeypatch.setenv("FE_SITUACION_3", "0")
    assert situacion() == "1"
    monkeypatch.delenv("FE_SITUACION_3")
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    assert situacion() == "1"                                                  # en la nube siempre 1


def test_decisiones_del_contador_en_la_caja_y_la_cola():
    k = (JS / "pages" / "pos" / "caja.js").read_text(encoding="utf-8")
    i = k.index("ventaSinConexion(c) {")
    assert "if (sesion.electronica) { this.cobrando = false; return toast(" in k[i:i + 700]
    c = (RAIZ / "app" / "cola.py").read_text(encoding="utf-8")
    assert "if ex.status_code not in (502, 504):" in c


def test_cierre_etapa_1_pantallas():
    a = (JS / "app.js").read_text(encoding="utf-8")
    assert "if (m === 'tike' && this.empresaInfo?.es_local) return false;" in a
    s = (JS / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "const SOLO_NUBE = { ia:" in s and "Requiere internet" in s
    ad = (JS / "pages" / "admin.js").read_text(encoding="utf-8")
    assert ad.count('v-if="!esLocal"') == 2 and "this.esLocal = !!r.pin_local;" in ad
    r = (JS / "pages" / "gastos" / "recepcion.js").read_text(encoding="utf-8")
    assert "Requiere internet" in r and r.count('!sesion.empresaInfo?.es_local" @click="leerBuzon"') == 2
    h = (JS / "pages" / "hotel" / "configuracion.js").read_text(encoding="utf-8")
    assert h.count("Requiere internet") == 2 and "esLocal()" in h
    for f in ("facturas", "notas-credito", "notas-debito"):
        assert "sesion.empresaInfo?.correo_en_nube" in (JS / "pages" / "ventas" / (f + ".js")).read_text(encoding="utf-8")


def test_tareas_de_la_nube_apagadas_en_la_local():
    t = (RAIZ / "app" / "cola.py").read_text(encoding="utf-8")
    i = t.index('if os.environ.get("FE_MODO_LOCAL", "") != "1":   # etapa 1')
    assert i < t.index("procesar_recurrentes_todas()") and i < t.index("_pub.procesar_seguro()") and i < t.index("_tike.leer_buzones_todas()")


def test_la_venta_en_cola_se_repone_al_recargar():
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    fuente = (JS / "pages" / "pos" / "caja.js").read_text(encoding="utf-8")
    assert "v.espera_id = c.esperaId || null;" in fuente and "this.cargarCola(); this.reponerPendientes();" in fuente
    m = re.search(r"    reponerPendientes\(\) \{.*?\n    \},\n", fuente.replace("\r\n", "\n"), re.S)
    prueba = """
const reg = { pos_ventas: [], pos_espera: [{ id: 7 }, { id: 8 }] };
const mock = { cargado: true, get: (k, d) => reg[k] ?? d, actualizar: (k, f) => (reg[k] = f(reg[k])) };
const cajaPorId = id => ({ id, estado: 'Abierta' });
const registrarVentaEnCaja = (caja_id, v) => reg.pos_ventas.push({ caja_id, ...v });
const o = { cola: [{ id: 'abc123xyz', caja_id: 3, tipo_documento: '04', total: 100, medios: [], espera_id: 7, creado: 'h', cliente_nombre: 'C' }], espera: reg.pos_espera,
  """ + m.group(0).strip().rstrip(",") + """ };
o.reponerPendientes(); o.reponerPendientes();
console.log(JSON.stringify({ n: reg.pos_ventas.length, p: reg.pos_ventas[0].pendiente_id, c: reg.pos_ventas[0].consecutivo, e: o.espera.map(x => x.id) }));
"""
    out = subprocess.run([node, "--input-type=module", "-e", prueba], capture_output=True, text=True, timeout=30)
    assert out.returncode == 0, out.stderr
    assert json.loads(out.stdout) == {"n": 1, "p": "abc123xyz", "c": "PENDIENTE ABC123", "e": [8]}
