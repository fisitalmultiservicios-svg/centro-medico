# -*- coding: utf-8 -*-
"""4.39, segunda vuelta de los arreglos de la comanda automática al cobrar (16 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py: destinoDe e impresoraDe reales, la Cocina como única impresora de comanda y cada comanda anotada).

- R1 cuentaRapidaGuardada ya no excluye los pedidos: el pedido para llevar hecho en la caja con platos sin enviar manda su comanda una vez
  al cobrarlo; sus partes iguales mandan cada una su fracción (la comanda completa llega en partes); el pedido en línea (platos enviados
  por pedidos.a_caja, envío sin destino) no manda nada, salvo el plato que la cajera le agregó.
- R2 emitirCobro, con la cuenta ya en el servidor: después de ganar el cobro trae la lista, revisa que la cuenta siga, junta lo de otro
  equipo y compara ANTES de la comanda. B quita o agrega un plato con la ventana de cobro de A abierta: no sale comanda ni se emite; al
  segundo toque, una comanda y una emisión correctas. B borra la cuenta: ni comanda ni cobro.
- R3 emitirCobro no cobra mientras «Cargar a la habitación» pide su cobro (_habEnCurso).
- R4 lo que queda tras el cobro en otro equipo, en una caja CON mesas, es venta rápida y su comanda sale al cobrarlo.
- R5 persistirCuenta tras el cobro en otro equipo («Comanda», «Mesas» o F4 con la ventana de cobro cancelada) no rehace lo de la base.
- R6 cargarAHabitacion sin platos: no carga ₡0.
- R7 reclamarHab: B agrega una Limonada con la habitación abierta en A: A no carga, avisa y la ventana sigue con el total nuevo; sin
  cambios, una comanda y un cargo. Y la segunda pasada de cargarAHabitacion: si al guardar con la comanda la cuenta cambió, no carga.
Cada caso corre también, cuando se puede, con el método de ANTES del cambio (sacado de caja.js con un reemplazo de texto exacto): ahí se
ve el defecto que el cambio arregla. Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

from tests.test_431_misma_mesa_pantallas import _linea, _metodo
from tests.test_439_revision_arreglos import (CASADO, COMANDA, EMITIR, H2_COMANDA, H2_COMANDA_ANTES, H2_PIDE, LIMONADA, POSTRE, RECLAMAR,
                                              SOLTAR, _caja, _cambiar, _correr_rev)

CAMBIO = "La cuenta cambió en otro equipo y aquí no se cobró nada. Revise el total antes de cobrar."
CAMBIO_HAB = "La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar."
SIN_PLATOS_HAB = "No quedan platos para cargar a la habitación"
CERRADA = ("Esta cuenta fue cobrada o cerrada en otro equipo y aquí no se cobró nada. Lo que no se había enviado sigue en pantalla como "
           "venta nueva: revise el total antes de cobrar.")
CERRADA_C1 = CERRADA.replace("Esta cuenta", "La cuenta «Cuenta 1»", 1)        # la misma, con el nombre de la cuenta recuperada
AVISO_R5 = "La cuenta «Cuenta 1» fue cobrada o cerrada en otro equipo; lo que acaba de agregar queda como cuenta nueva"
TRES = CASADO + LIMONADA + POSTRE
AMBOS, LOS_TRES = ["Casado×1", "Postre×1"], ["Casado×1", "Limonada×1", "Postre×1"]

# lo que cada cambio agregó, tal como está en caja.js (las versiones «de antes» salen de quitarlo)
# 4.39 (cuarta vuelta, U3): la guarda de R3 dejó de estar en la misma línea que la de «cobrando»: es la segunda línea de emitirCobro y avisa
# («Se está revisando el cargo a la habitación…») en vez de volver callada. La versión de antes de R3 sale de quitar esa línea
R3_GUARDA = "if (this._habEnCurso) return toast('Se está revisando el cargo a la habitación: espere un momento', 'err');"
R3_AVISO = "Se está revisando el cargo a la habitación: espere un momento"
R4_RAPIDA = " if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true;"
R5_FILTRO = "this.lineas = this.lineas.filter(l => !g.has(l.lid) && (!l.enviado || new Date(l.enviado).getTime() >= corte));"
R6_GUARDA = "if (!this.lineas.some(l => +l.cantidad > 0)) { this.habCargo = null; return toast('No quedan platos para cargar a la habitación', 'err'); }"
R1_REGLA = "!(c && (c.mesa_id || (Array.isArray(c.mesas_ids) && c.mesas_ids.length)))"


def _extra():
    """Los métodos de la caja que estas pruebas usan además de los del arnés (el pedido para llevar de la caja)."""
    k = _caja()
    return (_metodo(k, "async confirmarPedido() {"), _linea(k, "direccionesDe(c) {"), _linea(k, "elegirDireccion() {"))


def _antes_r2():
    """emitirCobro sin lo que agregó R2: tras pedir el cobro, la comanda sale enseguida (sin traer, juntar ni comparar antes).
    4.39 (tercera vuelta): R2 quedó dentro del bucle de espera de T3 (y T3 agregó sin0 y la guarda de la comanda). El reemplazo de antes
    cortaba a mitad del bucle (código roto). Ahora se quita la línea de sin0, todo lo que va después del pedido del cobro hasta la
    comparación (cambio0) inclusive, y la línea de la comanda vuelve a la de antes de T3: el método sin la revisión de R2 ni lo de T3."""
    e = _metodo(_caja(), "async emitirCobro(otra) {")
    s = e.index("          const sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));")
    e = e[:s] + e[e.index("\n", s) + 1:]
    i = e.index("\n", e.index(H2_PIDE)) + 1
    j = e.index("\n", e.index("const cambio0 = this.cobroCambiado(")) + 1
    assert e[i:j].count("this.persistirCuenta();") == 1 and e[i:j].count("cobroDeCuentaCerrada()") == 1 and e[i:j].count("for (let vuelta = 0; ; vuelta++) {") == 1
    e = _cambiar(e[:i] + e[j:], H2_COMANDA, H2_COMANDA_ANTES)
    # 4.39 (sexta vuelta, W11): la revisión de la mesa con el cobro pedido (V2, después del bloque de la venta rápida) también trae la lista
    # (3 s como mucho) después de esperar la comanda de otro equipo: esa queda; la de R2 (en el bloque de la venta rápida) ya no está
    assert "sin0" not in e and "for (let vuelta" not in e and e.count("mock.refrescar(['pos_espera'])") == 1
    assert e.index("mock.refrescar(['pos_espera'])") > e.index("if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial")
    return (e,)


def _antes_r3():
    """emitirCobro sin la guarda de R3 (4.39, cuarta vuelta: se quita la línea entera, la de «cobrando» queda como estaba)."""
    e = _metodo(_caja(), "async emitirCobro(otra) {")
    assert e.count("\n      if (this.cobrando) return;\n      " + R3_GUARDA) == 1
    i = e.index("      " + R3_GUARDA)
    return (e[:i] + e[e.index("\n", i) + 1:],)


def _antes_r4():
    k = _caja()
    return (_cambiar(_metodo(k, "async sincronizar() {"), R4_RAPIDA, ""), _cambiar(_metodo(k, "cobroDeCuentaCerrada() {"), "     " + R4_RAPIDA, ""))


def _antes_r5():
    return (_cambiar(_metodo(_caja(), "persistirCuenta(devolverId) {"), R5_FILTRO,
                     "this.lineas = this.lineas.filter(l => !l.enviado || new Date(l.enviado).getTime() >= corte);"),)


def _antes_r6():
    m = _metodo(_caja(), "cargarAHabitacion() {")
    i = m.index("      " + R6_GUARDA)
    return (m[:i] + m[m.index("\n", i) + 1:],)


def _antes_r7():
    """reclamarHab sin traer y juntar antes de la comanda, y cargarAHabitacion sin revisar el guardado de la comanda (como en la primera vuelta).
    4.39 (tercera vuelta, T1): la llamada a cargarAHabitacion de reclamarHab enciende _habSigue (la única que pasa la puerta nueva de
    cargarAHabitacion mientras se revisa): se conserva, si no la versión de antes no cargaría nunca."""
    k = _caja()
    r = _metodo(k, "async reclamarHab() {")
    i = r.index("        if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada)")
    j = r.index("        this._habSigue = true; this.cargarAHabitacion();")
    h = _metodo(k, "cargarAHabitacion() {")
    a = h.index("        if (conComanda) {")
    b = h.index("\n", h.index("aquí no se cargó nada. Revise el total antes de cargar.", a))
    b = h.index("\n", b + 1) + 1                                                       # el «}» que cierra el bloque
    assert h[b:].lstrip().startswith("}"), h[b:b + 60]
    return (r[:i] + r[j:], h[:a] + "        if (conComanda) comandaHab();\n" + h[b:])


AYUDAS = r"""
const CAMBIO = @CAMBIO@, CAMBIO_HAB = @CAMBIO_HAB@, SIN_PLATOS_HAB = @SIN@, CERRADA_C1 = @C1@;
const delCobroAqui = vm => avisos(vm).filter(t => t === AVISO_OCUPADA || t === AVISO_COBRADA || t === CERRADA || t === CERRADA_C1);
const conTexto = (vm, t) => avisos(vm).filter(x => x === t);
const hab = vm => avisos(vm).filter(x => x.includes('habitación'));
const pedidoLlevar = () => ({ tipo: 'llevar', nombre: 'Cliente QA', telefono: '', direccion: '', direccion_sel: '', direccion_nombre: '', guardar_dir: false, hora_entrega: '', nota: '', seguir: true, q: '' });
"""


def _correr(tmp_path, casos, antes=()):
    guion = (AYUDAS.replace("@CAMBIO@", json.dumps(CAMBIO)).replace("@CAMBIO_HAB@", json.dumps(CAMBIO_HAB))
             .replace("@SIN@", json.dumps(SIN_PLATOS_HAB)).replace("@C1@", json.dumps(CERRADA_C1)) + casos)
    return _correr_rev(tmp_path, guion, antes=_extra() + tuple(antes))


# ================================================================================================================ R1: los pedidos
CASOS_R1 = r"""
const RG_ANTES = (new Function('return {' + @RG_ANTES@ + '};'))().cuentaRapidaGuardada;   // la regla de antes: sin los pedidos
// (llevar) pedido para llevar hecho en la caja (abierto antes de cargar los platos): Casado y Postre sin enviar; al cobrarlo sale la comanda una vez
for (const sinR1 of [false, true]) {
  nuevo(); const a = venta(await equipo());
  if (sinR1) Object.defineProperty(a, 'cuentaRapidaGuardada', { get() { return RG_ANTES.call(this); }, configurable: true });
  a.pedido = pedidoLlevar(); await a.confirmarPedido(); await a.A.mock.guardarTodo();
  const marca = { pedido: (a.cuentaActual || {}).pedido || null, rapida: a.rapida, guardada: a.cuentaRapidaGuardada };
  a.lineas.push(CASADO(), POSTRE());
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out['llevar' + (sinR1 ? '_antes' : '')] = { marca, impresos: impresos(), comandas: comandas(a), hechos: hechos().map(h => [h[1], h[2]]), orden: orden(a.nEq), servidor: servidor(), pago: !!a.pago };
}
// (partes) el mismo pedido para llevar dividido en 2 partes iguales: la parte 1 sigue con la marca de pedido; la 2 no. Cada parte manda su fracción
for (const sinR1 of [false, true]) {
  nuevo(); const a = venta(await equipo());
  if (sinR1) Object.defineProperty(a, 'cuentaRapidaGuardada', { get() { return RG_ANTES.call(this); }, configurable: true });
  a.pedido = pedidoLlevar(); await a.confirmarPedido(); await a.A.mock.guardarTodo();
  a.lineas.push(CASADO(), POSTRE());
  a.dividir = { modo: 'partes', partes: 2, destino: 'nueva', sel: {} }; await a.confirmarDividir(); await a.A.mock.guardarTodo();
  const marcas = S.items.map(x => [x.nombre, x.pedido || null]), p2 = S.items.find(x => x.nombre.endsWith(' · parte 2 de 2'));
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();          // la parte 1, la que quedó en pantalla
  const p1 = { impresos: impresos(), hechos: hechos().map(h => h[2]) };
  a.recuperar(a.espera.find(x => x.id === p2.id));
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out['partes' + (sinR1 ? '_antes' : '')] = { marcas, p1, impresos: impresos(), hechos: hechos().map(h => h[2]), suma: suma(), servidor: servidor() };
}
// (en_linea) el pedido en línea como lo crea pedidos.a_caja (Casado enviado, envío sin enviar); con un Postre que agregó la cajera
for (const conPostre of [false, true]) {
  nuevo(); pedidoEnServidor([CASADO()]);
  const a = venta(await equipo()); a.recuperar(a.espera.find(x => x.id === 1));
  const guardada0 = a.cuentaRapidaGuardada;
  if (conPostre) a.lineas.push(POSTRE());
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out['en_linea' + (conPostre ? '_postre' : '')] = { guardada0, impresos: impresos(), comandas: comandas(a), hechos: hechos().map(h => h[2]), orden: orden(a.nEq), servidor: servidor() };
}
"""


def test_r1_los_pedidos_de_la_caja_mandan_su_comanda_al_cobrarlos_en_node(tmp_path):
    regla = _linea(_caja(), "cuentaRapidaGuardada() {")
    antes = _cambiar(regla, R1_REGLA, "!(c && (c.pedido || c.pedido_id || c.mesa_id || (Array.isArray(c.mesas_ids) && c.mesas_ids.length)))")
    r = _correr(tmp_path, CASOS_R1.replace("@RG_ANTES@", json.dumps(antes)))
    ll = r["llevar"]
    assert ll["marca"] == {"pedido": "llevar", "rapida": False, "guardada": True}, ll                 # R1: el pedido para llevar sin mesa es cuenta guardada
    assert ll["impresos"] == [AMBOS] and ll["comandas"] == ["Comanda 1 enviada a Cocina"], ll         # una comanda, con los dos platos
    assert ll["hechos"] == [[CASADO + POSTRE, AMBOS]] and ll["servidor"] == [] and ll["pago"] is False, ll   # una emisión
    assert ll["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR], ll                               # ya estaba en el servidor: reclamar antes (H2)
    la = r["llevar_antes"]                                                                              # antes de R1: cobrado y nunca a cocina
    assert la["marca"]["guardada"] is False and la["impresos"] == [] and la["hechos"] == [[CASADO + POSTRE, AMBOS]], la
    pa = r["partes"]
    assert sorted(map(tuple, pa["marcas"])) == [("Cliente QA", "llevar"), ("Cliente QA · parte 2 de 2", None)], pa
    medio = ["Casado×0.5", "Postre×0.5"]
    assert pa["p1"] == {"impresos": [medio], "hechos": [medio]}, pa                                     # la parte 1 (con la marca de pedido) manda su mitad
    assert pa["impresos"] == [medio, medio] and pa["hechos"] == [medio, medio], pa                      # la comanda completa, en dos fracciones
    assert pa["suma"] == CASADO + POSTRE and pa["servidor"] == [], pa                                   # cada parte se cobra una vez
    assert r["partes_antes"]["impresos"] == [medio], r["partes_antes"]                                  # antes: la mitad de la parte 1 no llegaba a cocina
    e = r["en_linea"]
    assert e["guardada0"] is True and e["impresos"] == [] and e["comandas"] == [], e                    # sus platos llegan enviados; el envío no va a cocina
    assert e["hechos"] == [["Casado×1", "Envío a domicilio×1"]] and e["orden"] == [RECLAMAR, EMITIR, SOLTAR, SOLTAR] and e["servidor"] == [], e
    ep = r["en_linea_postre"]
    assert ep["impresos"] == [["Postre×1"]] and ep["comandas"] == ["Comanda 2 enviada a Cocina"], ep    # solo el plato que agregó la cajera
    assert ep["hechos"] == [["Casado×1", "Envío a domicilio×1", "Postre×1"]] and ep["servidor"] == [], ep
    assert ep["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR], ep


# ================================================================================================================ R2: juntar antes de la comanda
CASOS_R2 = r"""
// A y B recuperaron la misma cuenta guardada sin mesa (Casado y Postre sin enviar). A abre el cobro; B cambia la cuenta y guarda; A cobra
async function caso(nombre, cambiar, conLimonadaA) {
  const id = await guardada([CASADO(), POSTRE()]);
  const a = await abierta(id), b = await abierta(id);
  if (conLimonadaA) a.lineas.push(LIMONADA());
  await a.abrirPago();
  await cambiar(b, id);
  await a.cobrar(); await hastaLibre();
  const o = out[nombre] = { ...pantalla(a), total: a.totales.total, medios: a.pago ? a.pago.medios.map(m => [m.medio, m.monto]) : null, cambio: conTexto(a, CAMBIO),
    avisos: delCobroAqui(a), hechos: hechos(), impresos: impresos(), orden: orden(a.nEq), servidor: servidor().map(x => x.platos.slice().sort()), libre: libre() };
  a._alDia = 0; if (!a.pago && a.lineas.length) await a.abrirPago();
  if (a.pago) { await a.cobrar(); await hastaLibre(); } await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [h[1], h[2]]), impresos: impresos(), orden: orden(a.nEq), servidor: servidor(), pago: !!a.pago, cambio: conTexto(a, CAMBIO), suma: suma() };
}
await caso('quita', async b => { b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(); await b.A.mock.guardarTodo(); });
await caso('agrega', async b => { b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo(); });
await caso('agrega_enviada', async b => { b.lineas.push(LIMONADA()); await b.enviarComanda(); await b.A.mock.guardarTodo(); });   // con la comanda ya impresa
await caso('borrada', async (b, id) => { await b.borrarEspera(b.espera.find(x => x.id === id)); await b.A.mock.guardarTodo(); }, true);
await caso('igual', async () => {});
"""


def test_r2_la_comanda_sale_despues_de_juntar_lo_de_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_R2)
    q = r["quita"]
    # B quitó el Postre: no sale comanda (antes se imprimía el Postre quitado) ni se emite; aviso y la ventana sigue con el total nuevo
    assert q["hechos"] == [] and q["impresos"] == [] and q["cambio"] == [CAMBIO] and q["libre"] is True, q
    assert q["pago"] is True and q["cobrando"] is False and q["platos"] == ["Casado×1"] and q["total"] == CASADO and q["medios"] == [["01", CASADO]], q
    assert q["orden"] == [RECLAMAR, SOLTAR] and q["servidor"] == [["Casado×1"]], q                      # el cobro pedido quedó libre
    lu = q["luego"]
    assert lu["hechos"] == [[CASADO, ["Casado×1"]]] and lu["impresos"] == [["Casado×1"]] and lu["servidor"] == [] and lu["pago"] is False, q
    assert lu["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and lu["cambio"] == [CAMBIO], q   # una comanda, una emisión
    for k in ("agrega", "agrega_enviada"):
        x = r[k]
        # B agregó la Limonada: A no manda comanda (antes salía sin la Limonada) ni emite; la ventana sigue con el total de los tres. Con
        # «agrega_enviada», B mandó la comanda (con lo que tenía sin enviar: los tres) y esa es la única
        assert x["hechos"] == [] and x["impresos"] == ([] if k == "agrega" else [LOS_TRES]) and x["cambio"] == [CAMBIO] and x["libre"] is True, (k, x)
        assert x["pago"] is True and x["platos"] == LOS_TRES and x["total"] == TRES and x["medios"] == [["01", TRES]], (k, x)
        assert x["orden"] == [RECLAMAR, SOLTAR] and x["servidor"] == [LOS_TRES], (k, x)
        lu = x["luego"]
        assert lu["hechos"] == [[TRES, LOS_TRES]] and lu["servidor"] == [] and lu["suma"] == TRES and lu["cambio"] == [CAMBIO], (k, x)
        assert lu["orden"][:2] == [RECLAMAR, SOLTAR], (k, x)
    assert r["agrega"]["luego"]["impresos"] == [LOS_TRES], r["agrega"]                                  # una comanda con los tres
    assert r["agrega"]["luego"]["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR], r["agrega"]
    ae = r["agrega_enviada"]["luego"]                                                                   # todo ya salió con la comanda de B: A no imprime nada
    assert ae["impresos"] == [LOS_TRES] and ae["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, EMITIR, SOLTAR, SOLTAR], ae
    b = r["borrada"]
    # B borró la cuenta: no sale comanda de Casado ni Postre (nadie los paga) y no se emite; en pantalla queda la Limonada que A no había guardado
    assert b["hechos"] == [] and b["impresos"] == [] and b["avisos"] == [CERRADA_C1] and b["libre"] is True, b
    assert b["pago"] is False and b["platos"] == ["Limonada×1"] and b["cuenta"] is None and b["rapida"] is True and b["servidor"] == [], b
    assert b["orden"] == [RECLAMAR, SOLTAR], b
    assert b["luego"]["hechos"] == [[LIMONADA, ["Limonada×1"]]] and b["luego"]["impresos"] == [["Limonada×1"]] and b["luego"]["servidor"] == [], b
    i = r["igual"]                                                                                      # nada cambió: como siempre, al primer toque
    assert i["hechos"] == [[i["hechos"][0][0], CASADO + POSTRE, AMBOS]] and i["impresos"] == [AMBOS] and i["cambio"] == [], i
    assert i["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and i["servidor"] == [] and i["pago"] is False, i

    # emitirCobro de antes de R2 (la comanda enseguida del cobro pedido): el Postre quitado y la cuenta borrada salían a cocina
    v = _correr(tmp_path / "antes", CASOS_R2, antes=_antes_r2())
    assert "Postre×1" in v["quita"]["impresos"][0], v["quita"]
    assert v["agrega"]["impresos"][0] == AMBOS, v["agrega"]                                             # sin la Limonada (salía en otra comanda)
    assert v["agrega_enviada"]["impresos"] == [LOS_TRES, AMBOS], v["agrega_enviada"]                    # Casado y Postre otra vez en cocina
    assert v["borrada"]["impresos"] and "Casado×1" in v["borrada"]["impresos"][0], v["borrada"]


# ================================================================================================================ R3: la habitación pide su cobro
CASOS_R3 = r"""
// (unidad) con «Cargar a la habitación» pidiendo su cobro (_habEnCurso), F9 y emitirCobro no hacen nada
{ nuevo(); const v = venta(await equipo()); v.lineas.push(CASADO()); await v.abrirPago(); v._habEnCurso = true;
  await v.emitirCobro(false); if (v.pago) await v.cobrar();
  // 4.39 (cuarta vuelta, U3): y avisa (una vez por toque: aquí, emitirCobro y cobrar)
  out.unidad = { hechos: hechos(), llamadas: C.llamadas.length, impresos: impresos(), cobrando: v.cobrando, pago: !!v.pago, platos: detalles(v), aviso: avisos(v).filter(t => t === @R3_AVISO@) }; }
// (carrera) la cuenta guardada sin mesa: «Cargar a la habitación» pide su cobro (el servidor tarda) y mientras tanto la cajera toca F9
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.abrirPago(); a.habCargo = HAB();
  C.reclamoLento = 80;
  const p1 = a.cargarAHabitacion(), enCurso = !!a._habEnCurso, p2 = a.cobrar();
  await Promise.all([p1, p2]); C.reclamoLento = 0; await hastaLibre(); await a.A.mock.guardarTodo();
  out.carrera = { enCurso, hechos: hechos().map(h => [h[1], h[2]]), folios: C.folios.map(x => x.detalle).sort(), impresos: impresos(), orden: orden(a.nEq), servidor: servidor() }; }
"""


def test_r3_no_se_cobra_mientras_la_habitacion_pide_su_cobro_en_node(tmp_path):
    casos = CASOS_R3.replace("@R3_AVISO@", json.dumps(R3_AVISO))
    r = _correr(tmp_path / "ahora", casos)
    u = r["unidad"]
    # 4.39 (cuarta vuelta, U3): lo mismo que antes (nada se cobra ni se pide) y además el aviso, una vez por cada toque (emitirCobro y cobrar)
    assert u == {"hechos": [], "llamadas": 0, "impresos": [], "cobrando": False, "pago": True, "platos": ["Casado×1"], "aviso": [R3_AVISO, R3_AVISO]}, u
    c = r["carrera"]
    assert c["enCurso"] is True and c["hechos"] == [], c                                                # F9 no emitió
    assert c["folios"] == ["Casado (Cuenta 1)", "Postre (Cuenta 1)"] and c["impresos"] == [AMBOS], c    # un cargo y una comanda
    assert c["orden"] == [RECLAMAR, COMANDA, SOLTAR] and c["servidor"] == [], c

    # emitirCobro de antes de R3: con la habitación pidiendo su cobro, F9 emitía igual (el servidor le daba el cobro otra vez al mismo
    # equipo). En la carrera de arriba lo frenaba después cobroCambiado (la habitación ya había vaciado la pantalla), pero depende del orden
    v = _correr(tmp_path / "antes", casos, antes=_antes_r3())
    assert len(v["unidad"]["hechos"]) == 1 and v["unidad"]["aviso"] == [], v["unidad"]
    # 4.39 (tercera vuelta, T1): cargarAHabitacion ya no carga con un cobro en curso en esta caja (_cobroEnCurso), así que en la carrera con
    # el emitirCobro de antes de R3 ahora sale el tiquete y no el cargo (antes de T1 salía el cargo y cobroCambiado frenaba el tiquete). Lo que
    # importa: UN solo cobro (tiquete o cargo, nunca los dos) y una sola comanda
    vc = v["carrera"]
    assert (len(vc["hechos"]) == 1) != bool(vc["folios"]), vc                                      # o el tiquete o el cargo
    assert len(vc["hechos"]) <= 1 and vc["impresos"] == [AMBOS] and vc["servidor"] == [], vc        # (hoy sale el tiquete: T1 frena el cargo)


# ================================================================================================================ R4: caja con mesas
CASOS_R4 = r"""
// caja CON mesas (la del arnés tiene la Mesa 6): B recuperó la cuenta guardada sin mesa (Casado y Postre sin enviar) y la cobra mientras A,
// que también la recuperó (rapida = false) y le agregó la Limonada sin guardar, tiene la ventana de cobro abierta. A ya lo sabe o no
for (const sabe of [true, false]) {
  const id = await guardada([CASADO(), POSTRE()]);
  const a = await abierta(id), b = await abierta(id);
  a.lineas.push(LIMONADA());
  await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  if (sabe) await a.sincronizar();
  await a.cobrar(); await hastaLibre(); await hasta(() => a.esperaId === null);
  const o = out[sabe ? 'sabe' : 'no_sabe'] = { ...pantalla(a), mesas: a.mesas.length, esVentaRapida: a.esVentaRapida, avisos: delCobroAqui(a), hechos: hechos().length };
  a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), suma: suma(), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), servidor: servidor() };
}
"""


def test_r4_lo_que_queda_en_una_caja_con_mesas_sale_a_cocina_al_cobrarlo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_R4)
    for k, aviso in (("sabe", CERRADA_C1), ("no_sabe", "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar.")):
        x = r[k]
        assert x["mesas"] == 1 and x["platos"] == ["Limonada×1"] and x["cuenta"] is None and x["pago"] is False and x["hechos"] == 1, (k, x)
        assert x["rapida"] is True and x["esVentaRapida"] is True and x["vista"] == "venta" and x["avisos"] == [aviso], (k, x)   # R4
        lu = x["luego"]
        assert lu["hechos"] == [["B", CASADO + POSTRE, AMBOS], ["A", LIMONADA, ["Limonada×1"]]] and lu["suma"] == TRES and lu["servidor"] == [], (k, x)
        assert lu["impresos"] == [["B", AMBOS], ["A", ["Limonada×1"]]], (k, x)                       # la Limonada sale a cocina una vez, al cobrarla

    # sincronizar y cobroDeCuentaCerrada de antes de R4: lo que quedaba seguía con rapida = false y se cobraba sin comanda
    v = _correr(tmp_path / "antes", CASOS_R4, antes=_antes_r4())
    for k in ("sabe", "no_sabe"):
        assert v[k]["rapida"] is False and v[k]["luego"]["impresos"] == [["B", AMBOS]], (k, v[k])
        assert v[k]["luego"]["suma"] == TRES, (k, v[k])                                                 # (se cobraba una vez, pero sin llegar a cocina)


# ================================================================================================================ R5: no rehacer lo de la base
CASOS_R5 = r"""
// A y B recuperaron la cuenta guardada sin mesa (Casado y Postre sin enviar); A le agregó la Limonada sin guardar y abrió el cobro. B la
// cobra. A sincroniza con la ventana abierta (la pantalla no cambia), cancela el cobro y toca «Comanda», «Mesas» o F4 antes de la sincronización siguiente
for (const via of ['comanda', 'mesas', 'f4']) {
  const id = await guardada([CASADO(), POSTRE()]);
  const a = await abierta(id), b = await abierta(id);
  a.lineas.push(LIMONADA());
  await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar();
  a.cerrarPago();
  const enPantalla = detalles(a);
  if (via === 'comanda') await a.enviarComanda(); else if (via === 'mesas') a.volverAMesas(false); else a.guardarCuenta();
  await a.A.mock.guardarTodo();
  const o = out[via] = { enPantalla, avisos: cerradas(a), servidor: servidor().map(x => x.platos.slice().sort()), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]) };
  for (const c of S.items.slice()) { const v = await abierta(c.id); await v.abrirPago(); await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo(); }   // lo que quedó se cobra
  o.luego = { hechos: hechos().map(h => [h[1], h[2]]), suma: suma(), servidor: servidor() };
}
"""


def test_r5_tras_el_cobro_en_otro_equipo_no_se_rehace_lo_de_la_base_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_R5)
    for via in ("comanda", "mesas", "f4"):
        x = r[via]
        assert x["enPantalla"] == LOS_TRES and x["avisos"] == [AVISO_R5], (via, x)
        assert x["servidor"] == [["Limonada×1"]], (via, x)                                             # la cuenta nueva solo con lo agregado
        lu = x["luego"]
        assert lu["hechos"] == [[CASADO + POSTRE, AMBOS], [LIMONADA, ["Limonada×1"]]] and lu["suma"] == TRES and lu["servidor"] == [], (via, x)   # cada plato una vez
    assert r["comanda"]["impresos"] == [["B", AMBOS], ["A", ["Limonada×1"]]], r["comanda"]              # la comanda de A, solo la Limonada

    # persistirCuenta de antes de R5: lo guardado sin enviar (y, con «Comanda», recién marcado como enviado) se rehacía y se cobraba otra vez
    v = _correr(tmp_path / "antes", CASOS_R5, antes=_antes_r5())
    for via in ("comanda", "mesas", "f4"):
        assert v[via]["servidor"] == [LOS_TRES], (via, v[via])
        assert v[via]["luego"]["suma"] == TRES + CASADO + POSTRE, (via, v[via])                        # cobro doble


# ================================================================================================================ R6: cargo de ₡0
CASOS_R6 = r"""
// (cerrada) A abrió «Cargar a la habitación» con la cuenta guardada; B la cobra; A sincroniza (no queda nada) y toca «Cargar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  a.habCargo = HAB();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar();
  const antes = { platos: detalles(a), hab: !!a.habCargo, cuenta: a.esperaId };
  await a.cargarAHabitacion(); await hastaLibre();
  out.cerrada = { antes, folios: C.folios.length, hab: a.habCargo, avisos: hab(a), orden: orden(a.nEq) }; }
// (cero) una venta con la única línea en cantidad 0
{ nuevo(); const v = venta(await equipo()); v.lineas.push({ ...CASADO(), cantidad: 0 }); v.habCargo = HAB();
  await v.cargarAHabitacion(); out.cero = { folios: C.folios.length, hab: v.habCargo, avisos: hab(v), orden: orden(v.nEq) }; }
"""


def test_r6_no_se_carga_cero_a_la_habitacion_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_R6)
    c = r["cerrada"]
    assert c["antes"] == {"platos": [], "hab": True, "cuenta": None}, c                                 # la ventana seguía abierta sin platos
    assert c == {**c, "folios": 0, "hab": None, "avisos": [SIN_PLATOS_HAB], "orden": []}, c            # se cierra con el aviso; nada se carga ni se pide
    assert r["cero"] == {"folios": 0, "hab": None, "avisos": [SIN_PLATOS_HAB], "orden": []}, r["cero"]

    # cargarAHabitacion de antes de R6: «₡0 cargados a la habitación» (una venta de 0 en la caja)
    v = _correr(tmp_path / "antes", CASOS_R6, antes=_antes_r6())
    assert v["cerrada"]["avisos"] == ["0 cargados a la habitación Hab 3 · Huésped QA"], v["cerrada"]
    assert v["cero"]["avisos"] == ["0 cargados a la habitación Hab 3 · Huésped QA"], v["cero"]


# ================================================================================================================ R7: la habitación junta antes
CASOS_R7 = r"""
// (cambia) B agrega la Limonada (sin enviar) mientras A tiene abierta «Cargar a la habitación»; A sincronizó con la ventana abierta o no
for (const sinc of [false, true]) {
  const id = await guardada([CASADO(), POSTRE()]);
  const a = await abierta(id), b = await abierta(id);
  a.habCargo = HAB();
  b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  if (sinc) await a.sincronizar();
  await a.cargarAHabitacion(); await hastaLibre();
  // 4.39 (tercera vuelta, T4): el aviso de la habitación dice «aquí no se cargó nada» (cambioCobro: el de cobrar, que ya no sale aquí)
  const o = out['cambia' + (sinc ? '_sinc' : '')] = { folios: C.folios.length, impresos: impresos(), hab: !!a.habCargo, platos: detalles(a), total: a.totales.total,
    cambio: conTexto(a, CAMBIO_HAB), cambioCobro: conTexto(a, CAMBIO), orden: orden(a.nEq), servidor: servidor().map(x => x.platos.slice().sort()), libre: libre() };
  if (a.habCargo) await a.cargarAHabitacion(); await hastaLibre(); await a.A.mock.guardarTodo();   // (la ventana sigue abierta: otro toque)
  o.luego = { folios: C.folios.map(x => x.detalle).sort(), impresos: impresos(), hab: a.habCargo, orden: orden(a.nEq), servidor: servidor() };
}
// (igual) sin cambios: una comanda y un cargo
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  a.habCargo = HAB(); await a.cargarAHabitacion(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.igual = { folios: C.folios.map(x => x.detalle).sort(), impresos: impresos(), hab: a.habCargo, orden: orden(a.nEq), servidor: servidor(), avisos: avisos(a).filter(t => t === CAMBIO || t === CAMBIO_HAB) }; }
// (borrada) B borra la cuenta: A gana el cobro, trae la lista y la cuenta ya no está: cobroDeCuentaCerrada y la ventana se cierra
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  a.lineas.push(LIMONADA()); a.habCargo = HAB();
  await b.borrarEspera(b.espera.find(x => x.id === id)); await b.A.mock.guardarTodo();
  await a.cargarAHabitacion(); await hastaLibre();
  out.borrada = { folios: C.folios.length, impresos: impresos(), hab: a.habCargo, platos: detalles(a), cuenta: a.esperaId, rapida: a.rapida, avisos: delCobroAqui(a), orden: orden(a.nEq), libre: libre() }; }
// (segunda) simulado: la cuenta cambia justo en el guardado de la comanda de la habitación (comandaHab junta un plato de otro equipo)
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  const p0 = a.persistirCuenta; let inyectar = true;
  a.persistirCuenta = function (...x) { const r = p0(...x); if (inyectar && this.cobrando && this.habCargo) { inyectar = false; this.lineas.push({ ...LIMONADA(), lid: 'lotro00000000001', enviado: new Date().toISOString(), ronda: 9 }); } return r; };
  a.habCargo = HAB(); await a.cargarAHabitacion(); await hastaLibre();
  out.segunda = { folios: C.folios.length, impresos: impresos(), hab: !!a.habCargo, avisos: conTexto(a, CAMBIO_HAB), orden: orden(a.nEq), libre: libre() };
  a.persistirCuenta = p0; if (a.habCargo) await a.cargarAHabitacion(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.segunda.luego = { folios: C.folios.length, impresos: impresos(), hab: a.habCargo }; }
"""


def test_r7_la_habitacion_junta_lo_de_otro_equipo_antes_de_cargar_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_R7)
    for k in ("cambia", "cambia_sinc"):
        x = r[k]
        # A no carga ni manda comanda: aviso y la ventana sigue abierta con el total nuevo (la Limonada en pantalla); el cobro pedido quedó libre.
        # 4.39 (tercera vuelta, T4): el aviso es el de la habitación («aquí no se cargó nada… antes de cargar»), no el de cobrar
        assert x["folios"] == 0 and x["impresos"] == [] and x["hab"] is True and x["cambio"] == [CAMBIO_HAB] and x["cambioCobro"] == [] and x["libre"] is True, (k, x)
        assert x["platos"] == LOS_TRES and x["total"] == TRES and x["orden"] == [RECLAMAR, SOLTAR] and x["servidor"] == [LOS_TRES], (k, x)
        lu = x["luego"]                                                                                  # al tocar otra vez: una comanda y un cargo con los tres
        assert lu["folios"] == ["Casado (Cuenta 1)", "Limonada (Cuenta 1)", "Postre (Cuenta 1)"] and lu["impresos"] == [LOS_TRES], (k, x)
        assert lu["hab"] is None and lu["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, COMANDA, SOLTAR] and lu["servidor"] == [], (k, x)
    i = r["igual"]
    assert i["folios"] == ["Casado (Cuenta 1)", "Postre (Cuenta 1)"] and i["impresos"] == [AMBOS] and i["hab"] is None, i
    assert i["orden"] == [RECLAMAR, COMANDA, SOLTAR] and i["servidor"] == [] and i["avisos"] == [], i
    b = r["borrada"]
    assert b["folios"] == 0 and b["impresos"] == [] and b["hab"] is None and b["avisos"] == [CERRADA_C1] and b["libre"] is True, b   # ni comanda ni cargo; la ventana se cierra
    assert b["platos"] == ["Limonada×1"] and b["cuenta"] is None and b["rapida"] is True and b["orden"] == [RECLAMAR, SOLTAR], b
    s = r["segunda"]
    # la comanda ya salió (los platos quedan enviados en la cuenta), pero el cargo no: aviso, la ventana sigue abierta y el cobro pedido se suelta
    assert s["folios"] == 0 and s["impresos"] == [AMBOS] and s["hab"] is True and s["avisos"] == [CAMBIO_HAB] and s["libre"] is True, s
    assert s["orden"] == [RECLAMAR, COMANDA, SOLTAR], s
    assert s["luego"]["folios"] == 3 and s["luego"]["impresos"] == [AMBOS] and s["luego"]["hab"] is None, s   # se carga una vez, sin otra comanda

    # reclamarHab y cargarAHabitacion de la primera vuelta: con la Limonada ya en la copia de A (sincronizó), la comanda salía sin ella y el
    # cargo la incluía: la Limonada se cargaba a la habitación sin llegar nunca a cocina
    v = _correr(tmp_path / "antes", CASOS_R7, antes=_antes_r7())
    cs = v["cambia_sinc"]
    assert cs["impresos"] == [AMBOS] and cs["folios"] == 3, cs
    assert v["segunda"]["folios"] == 3 and v["segunda"]["avisos"] == [], v["segunda"]


# ================================================================================================================ contrato
def test_contrato_de_la_segunda_vuelta():
    k = _caja()
    # R1: la regla sin los pedidos
    c = _linea(k, "cuentaRapidaGuardada() {")
    assert R1_REGLA in c and "pedido" not in c
    # R2 (también en tests/test_439_cobro_venta_rapida.py y tests/test_439_arreglos_e2e.py) y R3: la primera línea de emitirCobro
    e = _metodo(k, "async emitirCobro(otra) {")
    # 4.39 (cuarta vuelta, U3): la guarda de «cobrando» y la de R3 son las dos primeras líneas (la de R3, con aviso)
    assert e.startswith("async emitirCobro(otra) {\n      if (this.cobrando) return;\n      " + R3_GUARDA)
    assert e.index("rcPedido = true;") < e.index("mock.refrescar(['pos_espera'])") < e.index("const cambio0 = ") < e.index("this.enviarComanda();")
    # R4: en las dos salidas
    assert _metodo(k, "async sincronizar() {").count(R4_RAPIDA) == 1 and _metodo(k, "cobroDeCuentaCerrada() {").count(R4_RAPIDA) == 1
    # R5: lo de la base de esa cuenta no se rehace
    p = _metodo(k, "persistirCuenta(devolverId) {")
    assert p.count(R5_FILTRO) == 1 and p.index("const corte = Date.now() - 20000, g = lidsDeBase(this._base, this.esperaId);") < p.index(R5_FILTRO)
    # R6: antes de todo lo demás del cargo (después de elegir la habitación)
    h = _metodo(k, "cargarAHabitacion() {")
    assert h.index("if (!r) return toast('Elija la habitación del huésped', 'err');") < h.index(R6_GUARDA) < h.index("if (!mock.puedeGuardar()) return;")
    # R7: en reclamarHab, con el cobro ganado: traer, revisar, juntar y comparar antes de cargarAHabitacion; el finally suelta el cobro.
    # 4.39 (tercera vuelta): T2, sin0 se toma antes de traer; traer y juntar van en un bucle de dos vueltas como mucho (4 s si un plato de
    # sin0 llegó enviado: otro equipo tocó «Comanda») y después de cada espera se sigue solo si la ventana y la cuenta son las mismas; T4,
    # cobroCambiado con `cargo`; T1, la llamada a cargarAHabitacion enciende _habSigue y el finally lo apaga.
    # 4.39 (cuarta vuelta, U2): antes de pedir el cobro, la espera de la marca de otro equipo (_marcaAjena, en tramos de 200 ms); y la
    # espera de 4 s del bucle va en tramos de 200 ms que se cortan si se cierra la ventana o cambia la cuenta
    rh = _metodo(k, "async reclamarHab() {")
    sigue = "if (this.habCargo !== hc || this.esperaId !== id0) return;"
    # 4.39 (séptima vuelta, X1): antes de esperar la marca se anota si se va a esperar (esperoHab: después se junta en el bloque de la mesa) y
    # antes del bloque de la venta rápida, su condición (rapHab: lo demás va por el bloque de la mesa)
    pasos = ["const esperoHab = !!(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000);",
             "const ma = this._marcaAjena, id1 = this.esperaId;", "if (this.habCargo !== hc || this.esperaId !== id1) return;",
             "rc = await this.reclamarCobro(this.lineas);", "this._rcHab = rc || {};",
             "const rapHab = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l));",
             "if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) {",
             "sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));", "for (let vuelta = 0; ; vuelta++) {",
             "mock.refrescar(['pos_espera'])", sigue, "if (!enEspera().some(v => v.id === id0)) { this.habCargo = null; return this.cobroDeCuentaCerrada(); }",
             "try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }",
             # 4.39 (quinta vuelta, V1): la espera del bucle solo por un plato que va a cocina con una marca de envío de hace menos de 10 s
             # 4.39 (séptima vuelta, X7): una tercera vuelta como mucho, solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó)
             "if (vuelta > 1 || (vuelta ? !(this._marcaAjena && this._marcaAjena.id === this.esperaId && Date.now() < this._marcaAjena.t + 4000) : "
             "!this.lineas.some(l => l.enviado && sin0.has(l.lid) && this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)))) break;",
             # 4.39 (sexta vuelta, W6): la espera del bucle, en tramos, solo hasta la marca que dejó persistirCuenta al juntar (4 s si no es de esa cuenta)
             "{ const ma = this._marcaAjena, fin = ma && ma.id === this.esperaId ? ma.t + 4000 : Date.now() + 4000; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200)); }",
             "if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;",
             # 4.39 (quinta vuelta, V3): en una mesa (sin el bloque de arriba), la revisión de la comanda de otro equipo va justo antes de cargar
             # 4.39 (séptima vuelta, X1): el bloque de la mesa corre para todo lo que no fue por el de la venta rápida (también si se esperó la marca)
             "if (this.esRestaurante && !this.cobroParcial && !rapHab) {",
             "if (this.habCargo !== hc || this.esperaId !== idM) return;", "this._habSigue = true; this.cargarAHabitacion();",
             "} finally {", "const sobra = this._rcHab; this._rcHab = null; this._habEnCurso = false; this._habSigue = false;", "if (sobra && sobra.clave) this.soltarCobro(sobra, false);"]
    pos = [rh.index(x) for x in pasos]
    assert pos == sorted(pos), pos
    assert rh.count(sigue) == 2 and rh.count("this.cargarAHabitacion();") == 1, rh                  # tras traer y tras juntar
    assert "setTimeout(r, 4000)" not in rh, rh                                                      # 4.39 (cuarta vuelta): ninguna espera de 4 s de una vez
    # T1: la puerta de cargarAHabitacion (antes de todo) y la de emitirCobro siguen. 4.39 (cuarta vuelta, U3): el segundo toque avisa y
    # tampoco se carga con una parte en cobro (cobroParcial)
    g1 = h.index("      if (this._habEnCurso && !this._habSigue) return toast('Se está revisando la cuenta para cargarla: espere un momento', 'ok');")
    g2 = h.index("      if (this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('Hay un cobro en curso en esta caja: espere a que termine', 'err');")
    assert h.index("\n") + 1 == g1 < g2 < h.index("reservasHotel()"), h[:300]


# ================================================================================================================ el nombre de la cuenta
CASOS_NOMBRE = r"""
// la venta rápida manda su comanda (queda guardada como «Cuenta 1», sin nombre en pantalla) y después otra: ¿sigue llamándose igual?
nuevo(); const v = venta(await equipo());
v.lineas.push(CASADO()); v.enviarComanda(); await v.A.mock.guardarTodo();
const n1 = S.items.map(x => x.nombre);
v.lineas.push(POSTRE()); v.enviarComanda(); await v.A.mock.guardarTodo();
out.nombres = [n1, S.items.map(x => x.nombre), v.nombreEspera];
"""


# 4.39 (tercera vuelta, T9): era xfail(strict) por un defecto preexistente: la venta rápida que su comanda guardó como «Cuenta N» no tiene
# nombreEspera, y persistirCuenta le calculaba otro nombre en cada guardado (max(cuentas, números) + 1): «Cuenta 1» pasaba a «Cuenta 2»,
# «Cuenta 3»… en la lista de los otros equipos. T9 lo arregla (la cuenta que ya está en this.espera conserva su nombre); ahora es una
# prueba normal. Más casos (varias comandas, el otro equipo y la versión de antes) en tests/test_439_tercera_vuelta.py
def test_la_venta_rapida_guardada_conserva_su_nombre_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_NOMBRE)
    assert r["nombres"][0] == ["Cuenta 1"], r
    assert r["nombres"][1] == ["Cuenta 1"], r
