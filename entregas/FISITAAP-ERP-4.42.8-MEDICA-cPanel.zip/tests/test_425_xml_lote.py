# -*- coding: utf-8 -*-
"""4.25 (X3): XML viejos al exportar. La nube entrega los XML en lote (POST /api/sinc/xml) solo al token de una instalación de esa
empresa; el programa los trae antes de armar el ZIP (sinc.traer_archivos_lote) y avisa cuántos llegaron y cuántos no, con el motivo.
Solo claves de 50 dígitos arman nombres de archivo.

Nube y computadora corren en el mismo proceso y comparten la carpeta de XML (ver tests/test_416_bajada.py): por eso en la nube el
comprobante guarda su XML con otro nombre («nube425_<clave>.xml») y la computadora espera «<clave>.xml»."""
import base64
import io
import pathlib
import zipfile

import httpx
from sqlmodel import Session, select

from app import auth, exportar, main as M, sinc
from app.db import Documento, Empresa, engine, engine_empresa
from test_49_local_sinc import H, _admin_empresa, _modo_local, _Respuesta, _soltar_limite_vinculacion, _vincular, c

FECHA = "2026-11-08T08:00:00-06:00"
RAIZ = pathlib.Path(__file__).resolve().parents[1]


def _clave(n: int) -> str:
    return f"506{425000 + n:047d}"


def _ambiente(eid: int) -> str:
    with Session(engine) as sc:
        return sc.get(Empresa, eid).ambiente or "sandbox"


def _doc(eid: int, n: int, xml_nombre: str | None = None, contenido: bytes | None = None, respuesta: str | None = None, clave: str | None = None) -> str:
    """Un comprobante con su XML anotado. Sin `contenido`, el archivo no está (como uno viejo que bajó como historia)."""
    clave = clave or _clave(n)
    nombre = xml_nombre or f"{clave}.xml"
    if "/" not in nombre:
        (M.XML_DIR / nombre).unlink(missing_ok=True)
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=eid, tipo_documento="04", clave=clave, consecutivo=f"00100001040{425000 + n:09d}", fecha_emision=FECHA, estado="aceptado",
                      ambiente=_ambiente(eid), receptor_nombre="QA", moneda="CRC", total=1000, xml_nombre=nombre, respuesta_nombre=respuesta)
        s.add(d); s.commit()
    if contenido is not None:
        (M.XML_DIR / nombre).write_bytes(contenido)
    return clave


def _docs(eid: int):
    with Session(engine_empresa(eid)) as s:
        return s.exec(select(Documento)).all()


def _xml(clave: str) -> bytes:
    return f"<FacturaElectronica><Clave>{clave}</Clave></FacturaElectronica>".encode()


def _canje(ta: str, nombre: str = "Caja") -> tuple[str, int]:
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": nombre}).json()["codigo"]
    j = c.post("/api/sinc/canje", json={"codigo": codigo, "nombre": nombre}).json()
    return j["token"], j["terminal"]


def _zip(contenido: bytes) -> zipfile.ZipFile:
    return zipfile.ZipFile(io.BytesIO(contenido))


class _Contador:
    """Cuenta las llamadas a la nube del programa y deja pasar las demás al simulador."""
    def __init__(self, shim, falla=None):
        self.shim, self.falla, self.n = shim, falla, 0
        self._post, self._get = shim.post, shim.get

    def post(self, url, **kw):
        self.n += 1
        if self.falla:
            raise self.falla
        return self._post(url, **kw)

    def get(self, url, **kw):
        self.n += 1
        if self.falla:
            raise self.falla
        return self._get(url, **kw)


def _contar(monkeypatch, shim, falla=None) -> _Contador:
    k = _Contador(shim, falla)
    monkeypatch.setattr(shim, "post", k.post)
    monkeypatch.setattr(shim, "get", k.get)
    return k


def _pareja(monkeypatch, sufijo: str, a: str, b: str):
    """Nube (a) y computadora (b) vinculadas."""
    eid_a, ta = _admin_empresa(sufijo + "n", a)
    eid_b, tb = _admin_empresa(sufijo + "l", b)
    shim = _modo_local(monkeypatch)
    _vincular(monkeypatch, ta, tb, "Caja")
    return eid_a, ta, eid_b, tb, shim


# ---------------------------------------------------------------------------------------------------------------- nube
def test_la_nube_entrega_los_xml_en_lote_solo_a_su_instalacion():
    eid_a, ta = _admin_empresa("-x1n", "3101425001")
    eid_o, _to = _admin_empresa("-x1o", "3101425002")
    tok, _ = _canje(ta)
    k1 = _doc(eid_a, 1, xml_nombre=f"nube425_{_clave(1)}.xml", contenido=_xml(_clave(1)), respuesta=f"nube425_{_clave(1)}_r.xml")
    (M.XML_DIR / f"nube425_{_clave(1)}_r.xml").write_bytes(b"<MensajeHacienda>" + k1.encode() + b"</MensajeHacienda>")
    ajena = _doc(eid_o, 2, xml_nombre=f"nube425_{_clave(2)}.xml", contenido=_xml(_clave(2)))   # de otra empresa
    r = c.post("/api/sinc/xml", headers=H(tok), json={"claves": [k1, ajena]})
    assert r.status_code == 200, r.text
    j = r.json()
    assert set(j["archivos"]) == {k1} and j["no_estan"] == [ajena] and j["pendientes"] == []
    assert base64.b64decode(j["archivos"][k1]["xml_b64"]) == _xml(k1) and k1.encode() in base64.b64decode(j["archivos"][k1]["respuesta_b64"])
    # token de una persona (no de una instalación): 403
    assert c.post("/api/sinc/xml", headers=H(ta), json={"claves": [k1]}).status_code == 403
    # más de 100 claves: 400
    assert c.post("/api/sinc/xml", headers=H(tok), json={"claves": [_clave(i) for i in range(101)]}).status_code == 400
    # sin token: no entra
    assert c.post("/api/sinc/xml", json={"claves": [k1]}).status_code == 401


def test_clave_con_letras_o_barras_da_400_y_no_escribe_nada(monkeypatch):
    eid_a, ta = _admin_empresa("-x2n", "3101425003")
    tok, _ = _canje(ta)
    for mala in ("506" + "A" * 47, "506/../" + "1" * 43, "506\\..\\" + "1" * 43, "1" * 49, "１" * 50):
        r = c.post("/api/sinc/xml", headers=H(tok), json={"claves": [mala]})
        assert r.status_code == 400, (mala, r.text)
    # en el programa (vinculado: P5 de la revisión): un comprobante con una clave así no se pide ni se escribe, aunque la web lo mande
    _ea, _ta, eid_b, _tb, shim = _pareja(monkeypatch, "-x2p", "3101425022", "3101425023")
    mala = "506/../" + "1" * 43
    buena = _clave(3)
    _doc(eid_b, 3, clave=mala, xml_nombre=f"{mala}.xml")
    _doc(eid_b, 33, clave=buena)
    pedidas = []

    def post(url, headers=None, json=None, timeout=None):  # noqa: A002
        pedidas.append(list((json or {}).get("claves") or []))
        return _Respuesta(200, {"archivos": {mala: {"xml_b64": base64.b64encode(_xml(mala)).decode()},
                                             buena: {"xml_b64": base64.b64encode(_xml(buena)).decode()}}, "no_estan": [], "pendientes": []})
    monkeypatch.setattr(shim, "post", post)
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    assert pedidas == [[buena]]                                            # la mala nunca se pide
    assert res["traidos"] == 1 and res["sin_traer"] == 1 and res["por_clave"][mala] == sinc.CLAVE_MALA_XML
    assert (M.XML_DIR / f"{buena}.xml").read_bytes() == _xml(buena)
    assert not (M.XML_DIR / ("1" * 43 + ".xml")).exists() and not (M.XML_DIR / f"{mala}.xml").exists()
    assert not list(M.XML_DIR.glob(".*.tmp"))
    # y lo que llega de la nube o de la red con una clave así no arma ningún archivo (_guardar_documentos)
    letras = "506" + "B" * 47
    with Session(engine_empresa(eid_b)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid_b, [
            {"clave": letras, "tipo_documento": "04", "consecutivo": "00100001040425000009", "fecha_emision": FECHA, "estado": "aceptado",
             "xml_b64": base64.b64encode(b"<x/>").decode(), "respuesta_b64": base64.b64encode(b"<r/>").decode()},
            {"clave": "506/../" + "2" * 43, "tipo_documento": "04", "consecutivo": "00100001040425000010", "fecha_emision": FECHA, "estado": "aceptado",
             "xml_b64": base64.b64encode(b"<x/>").decode()}], "1", desde_nube=True)
    assert not (M.XML_DIR / f"{letras}.xml").exists() and not (M.XML_DIR / f"{letras}_respuesta.xml").exists()
    assert not (M.XML_DIR / ("2" * 43 + ".xml")).exists()
    with Session(engine_empresa(eid_b)) as s:
        d = s.exec(select(Documento).where(Documento.clave == letras)).first()
        assert d is None or (d.xml_nombre is None and d.respuesta_nombre is None)


def test_la_ruta_no_existe_en_un_programa_local_real(monkeypatch):
    eid_a, ta = _admin_empresa("-x3n", "3101425005")
    tok, _ = _canje(ta)
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    assert c.post("/api/sinc/xml", headers=H(tok), json={"claves": []}).status_code == 404
    monkeypatch.delenv("FE_MODO_LOCAL")
    assert c.post("/api/sinc/xml", headers=H(tok), json={"claves": []}).status_code == 200


def test_la_instalacion_revocada_recibe_la_senal_explicita():
    eid_a, ta = _admin_empresa("-x4n", "3101425006")
    tok, terminal = _canje(ta)
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta)).status_code == 200
    r = c.post("/api/sinc/xml", headers=H(tok), json={"claves": [_clave(4)]})
    assert r.status_code == 401 and r.json()["detail"]["codigo"] == sinc.CODIGO_REVOCADA, r.text


def test_el_lote_respeta_el_tope_de_tamano(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x5", "3101425007", "3101425008")
    claves = []
    for n in (5, 6, 7):
        k = _clave(n)
        _doc(eid_a, n, xml_nombre=f"nube425_{k}.xml", contenido=_xml(k))
        _doc(eid_b, n)
        claves.append(k)
    monkeypatch.setattr(sinc, "BYTES_NOVEDADES", 10)
    tok = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Otra"}).json()["codigo"]
    tok = c.post("/api/sinc/canje", json={"codigo": tok, "nombre": "Otra"}).json()["token"]
    j = c.post("/api/sinc/xml", headers=H(tok), json={"claves": claves}).json()
    assert list(j["archivos"]) == [claves[0]] and j["pendientes"] == claves[1:] and j["no_estan"] == []
    # el programa pide la siguiente tanda hasta tenerlos todos
    k = _contar(monkeypatch, shim)
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    assert res["faltaban"] == 3 and res["traidos"] == 3 and res["sin_traer"] == 0 and res["motivo"] is None and k.n == 3
    for x in claves:
        assert (M.XML_DIR / f"{x}.xml").read_bytes() == _xml(x)


# ---------------------------------------------------------------------------------------------------------------- programa
def test_exportar_trae_los_xml_que_faltan(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x6", "3101425009", "3101425010")
    k = _clave(8)
    _doc(eid_a, 8, xml_nombre=f"nube425_{k}.xml", contenido=_xml(k))
    _doc(eid_b, 8)
    r = c.get("/api/exportar", headers=H(tb))
    assert r.status_code == 200, r.text
    assert r.headers["X-Xml-Traidos"] == "1" and r.headers["X-Xml-Faltantes"] == "0"
    z = _zip(r.content)
    assert z.read(f"emitidos/00100001040{425008:09d}_{k}.xml") == _xml(k)
    assert "FALTANTES.txt" not in z.namelist() or k not in z.read("FALTANTES.txt").decode()
    assert "XML traídos de la web para esta exportación: 1; sin traer: 0." in z.read("LEEME.txt").decode()
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_b, auth.Auditoria.accion == "exportacion").order_by(auth.Auditoria.id.desc())).first()
    assert "1 XML traídos de la web, 0 sin traer" in a.detalle


def test_exportar_sin_internet_avisa_cuantos_faltan(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x7", "3101425011", "3101425012")
    for n in (9, 10, 11):
        _doc(eid_b, n)
    k = _contar(monkeypatch, shim, falla=httpx.ConnectError("sin red"))
    r = c.get("/api/exportar?pdf_incluir=1", headers=H(tb))
    assert r.status_code == 200, r.text
    assert k.n == 1                                                        # una sola llamada, no una por comprobante (ni por PDF)
    assert r.headers["X-Xml-Traidos"] == "0" and r.headers["X-Xml-Faltantes"] == "3" and r.headers["X-Xml-Motivo"] == "sin-internet"
    z = _zip(r.content)
    falt = z.read("FALTANTES.txt").decode()
    for n in (9, 10, 11):
        assert f"({_clave(n)}): falta el XML {_clave(n)}.xml; no se pudo traer de la web: sin internet. Vuelva a exportar cuando haya conexión." in falt
        assert f"({_clave(n)}): sin PDF porque falta el XML" in falt
    assert not any(x.endswith(".pdf.error.txt") for x in z.namelist())
    with Session(engine) as sc:
        a = sc.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid_b, auth.Auditoria.accion == "exportacion").order_by(auth.Auditoria.id.desc())).first()
    assert "0 XML traídos de la web, 3 sin traer (sin internet)" in a.detalle


def test_exportar_con_pdf_ya_no_da_por_faltante_lo_que_llego(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x8", "3101425013", "3101425014")
    k = _clave(12)
    _doc(eid_a, 12, xml_nombre=f"nube425_{k}.xml", contenido=_xml(k))
    _doc(eid_b, 12)
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_b)
    resumen: dict = {}
    with Session(engine_empresa(eid_b)) as s:
        datos = exportar.generar_zip(s, e, M.XML_DIR, None, None, con_pdf=True, render_pdf=lambda d: b"%PDF " + (M.XML_DIR / d.xml_nombre).read_bytes(),
                                     traer=lambda docs: sinc.traer_archivos_lote(eid_b, docs), xml_traidos=resumen)
    z = _zip(datos)
    base = f"emitidos/00100001040{425012:09d}_{k}"
    assert z.read(base + ".xml") == _xml(k) and z.read(base + ".pdf") == b"%PDF " + _xml(k)
    assert "FALTANTES.txt" not in z.namelist() or k not in z.read("FALTANTES.txt").decode()
    assert resumen["traidos"] == 1 and resumen["sin_traer"] == 0


def test_exportar_respeta_el_plazo(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x9", "3101425015", "3101425016")
    _doc(eid_b, 13)
    k = _contar(monkeypatch, shim)
    monkeypatch.setattr(sinc, "PLAZO_XML", 0)
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    assert k.n == 0 and res["motivo"] == "tiempo" and res["sin_traer"] == 1 and res["por_clave"][_clave(13)] == sinc.MOTIVOS_XML["tiempo"]


def test_el_archivo_solo_se_guarda_si_es_el_pedido(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x10", "3101425017", "3101425018")
    k, otra = _clave(14), _clave(15)
    _doc(eid_b, 14)
    shim.forzar = _Respuesta(200, {"archivos": {k: {"xml_b64": base64.b64encode(_xml(otra)).decode()},
                                                otra: {"xml_b64": base64.b64encode(_xml(otra)).decode()}}, "no_estan": [], "pendientes": []})
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    shim.forzar = None
    assert not (M.XML_DIR / f"{k}.xml").exists() and not (M.XML_DIR / f"{otra}.xml").exists()   # ni el ajeno ni lo que no se pidió
    assert res["traidos"] == 0 and res["por_clave"][k] == sinc.AJENO_XML
    # lo que la nube no tiene queda anotado como «no está en la web»
    shim.forzar = _Respuesta(200, {"archivos": {}, "no_estan": [k], "pendientes": []})
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    shim.forzar = None
    assert res["por_clave"][k] == sinc.NO_ESTA_XML and res["motivo"] is None


def test_web_anterior_cae_a_uno_por_uno(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x11", "3101425019", "3101425020")
    k = _clave(16)
    _doc(eid_b, 16)
    llamadas = []

    def post(url, **kw):
        llamadas.append(("post", url)); return _Respuesta(404, {"detail": "Not Found"})

    def get(url, **kw):
        llamadas.append(("get", url)); return _Respuesta(200, {"xml_b64": base64.b64encode(_xml(k)).decode()})
    monkeypatch.setattr(shim, "post", post)
    monkeypatch.setattr(shim, "get", get)
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    assert res["traidos"] == 1 and [x[0] for x in llamadas] == ["post", "get"] and llamadas[1][1].endswith(f"/api/sinc/xml/{k}")
    assert (M.XML_DIR / f"{k}.xml").read_bytes() == _xml(k)


def test_en_la_web_exportar_no_llama_a_nadie(monkeypatch):
    eid, t = _admin_empresa("-x12", "3101425021")
    k = _doc(eid, 17)
    llamadas = []

    class _Nadie:
        Timeout = httpx.Timeout

        def get(self, *a, **kw):
            llamadas.append(a)

        def post(self, *a, **kw):
            llamadas.append(a)
    monkeypatch.setattr(sinc, "httpx", _Nadie())
    assert sinc.MODO_LOCAL is False
    r = c.get("/api/exportar?pdf_incluir=1", headers=H(t))
    assert r.status_code == 200 and llamadas == []
    assert r.headers["X-Xml-Traidos"] == "0" and r.headers["X-Xml-Faltantes"] == "0" and r.headers["X-Xml-Motivo"] == ""
    z = _zip(r.content)
    falt = z.read("FALTANTES.txt").decode()
    assert f"00100001040{425017:09d} ({k}): falta el XML {k}.xml\n" in falt                 # como hoy: sin motivo
    assert "XML traídos de la web" not in z.read("LEEME.txt").decode()
    assert f"emitidos/00100001040{425017:09d}_{k}.pdf.error.txt" in z.namelist()             # el PDF se intenta como hoy


# ---------------------------------------------------------------------------------------------------------------- pantalla
def test_pantalla_exportar_avisa():
    s = (RAIZ / "app" / "static" / "js" / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    i = s.index("const SecExportar = {")
    sec = s[i:s.index("\n};\n", i)]
    assert "r.headers.get('X-Xml-Traidos')" in sec and "r.headers.get('X-Xml-Faltantes')" in sec and "r.headers.get('X-Xml-Motivo')" in sec
    assert "'Exportación descargada. ' + (traidos === 1 ? '1 XML se trajo de la web.' : traidos + ' XML se trajeron de la web.')" in sec
    assert "'sin-internet': 'no se pudieron traer porque no hay internet'" in sec
    assert "'. Están anotados en FALTANTES.txt dentro del archivo.'" in sec and "' Vuelva a exportar cuando haya conexión.'" in sec
    assert ('v-if="esPrograma">Los comprobantes anteriores a la conexión de esta computadora se traen de la web al exportar: hace falta internet.</p>') in sec
    assert "esPrograma() { return !!sesion.empresaInfo?.es_local; }" in sec


# ---------------------------------------------------------------------------------------------------------------- revisión (P1, P2 y P4)
def test_guardar_xml_aguanta_el_archivo_abierto_en_windows(monkeypatch):
    """P1: en Windows os.replace falla (PermissionError) si el XML de destino está abierto o el antivirus retiene el temporal: se
    reintenta y, si sigue fallando, se escribe directo como antes. Nunca queda un temporal."""
    monkeypatch.setattr(sinc, "PAUSA_XML", 0)
    k = _clave(40)
    (M.XML_DIR / f"{k}.xml").unlink(missing_ok=True)
    real, veces = sinc.os.replace, []

    def siempre(a, b):
        veces.append(1); raise PermissionError("[WinError 32] El proceso no tiene acceso al archivo")
    monkeypatch.setattr(sinc.os, "replace", siempre)
    assert sinc._guardar_xml(k, _xml(k)) == f"{k}.xml"
    assert len(veces) == sinc.INTENTOS_XML and (M.XML_DIR / f"{k}.xml").read_bytes() == _xml(k)
    assert not list(M.XML_DIR.glob(f".{k}*.tmp"))
    fallos = []

    def a_la_segunda(a, b):
        if not fallos:
            fallos.append(1); raise PermissionError("[WinError 5] Acceso denegado")
        return real(a, b)
    monkeypatch.setattr(sinc.os, "replace", a_la_segunda)
    sinc._guardar_xml(k, _xml(k) + b" ")
    assert (M.XML_DIR / f"{k}.xml").read_bytes() == _xml(k) + b" " and not list(M.XML_DIR.glob(f".{k}*.tmp"))
    (M.XML_DIR / f"{k}.xml").unlink(missing_ok=True)


def test_sin_vincular_exportar_sale_como_en_la_web(monkeypatch):
    """P2: una computadora sin vincular no tiene a quién pedirle los XML: el resultado es el de la web (sin motivo ni por_clave) y
    FALTANTES.txt y las cabeceras salen como antes, sin mandar a revisar una vinculación que no existe."""
    eid, t = _admin_empresa("-x13", "3101425024")
    _modo_local(monkeypatch)
    k = _doc(eid, 41)
    res = sinc.traer_archivos_lote(eid, _docs(eid))
    assert res["motivo"] is None and res["por_clave"] == {} and res["faltaban"] == 0 and res["sin_traer"] == 0
    r = c.get("/api/exportar", headers=H(t))
    assert r.status_code == 200 and r.headers["X-Xml-Motivo"] == "" and r.headers["X-Xml-Faltantes"] == "0", r.headers
    z = _zip(r.content)
    assert f"00100001040{425041:09d} ({k}): falta el XML {k}.xml\n" in z.read("FALTANTES.txt").decode()
    assert "XML traídos de la web" not in z.read("LEEME.txt").decode()


def test_si_solo_falta_la_respuesta_el_xml_cuenta_como_traido(monkeypatch):
    """P4: el comprobante cuyo XML quedó en disco cuenta como traído aunque falte la respuesta de Hacienda; se cuenta aparte
    (sin_respuesta), FALTANTES.txt lo dice y X-Xml-Faltantes cuenta solo los XML que faltan."""
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-x14", "3101425025", "3101425026")
    k = _clave(42)
    _doc(eid_a, 42, xml_nombre=f"nube425_{k}.xml", contenido=_xml(k))          # la web tiene el XML pero no la respuesta
    (M.XML_DIR / f"{k}_respuesta.xml").unlink(missing_ok=True)
    _doc(eid_b, 42, respuesta=f"{k}_respuesta.xml")
    res = sinc.traer_archivos_lote(eid_b, _docs(eid_b))
    assert res["traidos"] == 1 and res["sin_traer"] == 0 and res["sin_respuesta"] == 1 and res["motivo"] is None, res
    assert res["por_clave"][k] == sinc.SOLO_RESPUESTA_XML
    (M.XML_DIR / f"{k}.xml").unlink()                                           # otra vez por la ruta: cabeceras y FALTANTES
    r = c.get("/api/exportar", headers=H(tb))
    assert r.status_code == 200 and r.headers["X-Xml-Traidos"] == "1" and r.headers["X-Xml-Faltantes"] == "0" and r.headers["X-Xml-Motivo"] == ""
    falt = _zip(r.content).read("FALTANTES.txt").decode()
    assert f"({k}): falta la respuesta {k}_respuesta.xml; falta solo la respuesta de Hacienda" in falt
    assert f"({k}): falta el XML" not in falt
