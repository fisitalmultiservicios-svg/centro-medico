# -*- coding: utf-8 -*-
"""4.32, B7 (pantallas), parte «franja»: la franja global y la estación desde app.js, «Cambios que no quedaron» y su entrada en
Instalación local. Siguen el patrón de test_431_estacion_pantallas.py: leen el texto de los JS y ejecutan con Node el bloque de la franja
de app.js sobre sustitutos (sin servidor, sin red, sin navegador)."""
import json

import pytest

from tests.test_425_ultimos_pantallas import JS, _js, _node, _nodo

APP = _js("app.js")
PIS = _js("pages/sinc/pisados.js")
INST = _js("pages/configuracion/instalacion-local.js")


def _bloque() -> str:
    i = APP.index("const FRANJA_MS")
    return APP[i:APP.index("let _precargando", i)]


# ------------------------------------------------------------------------------------------------------------- texto de los archivos
def test_ruta_y_menu_de_la_pagina_nueva():
    assert "'/sinc/pisados': 'sinc/pisados'" in APP
    assert (JS / "pages" / "sinc" / "pisados.js").exists()


def test_la_franja_y_la_estacion_se_arrancan_y_se_paran_con_la_sesion():
    assert "vigilarFranja(); }" in APP                                     # al terminar de cargar la empresa
    assert "this.listo = false; pararFranja();" in APP                     # cambiar de empresa
    assert "pararFranja(); setToken('')" in APP                            # salir
    assert "import('./pages/pos/_estacion.js')" in APP
    b = _bloque()
    assert "typeof m.iniciarDesdeApp === 'function'" in b and "typeof m.pararDesdeApp === 'function'" in b
    assert "info.datos_v2" in b and "info.pedidos_programa" in b
    assert "/api/sinc/datos/franja" in b and "/api/pedidos/resumen" in b


def test_plantilla_de_la_franja_usa_llaves_y_no_v_html():
    for n in ("esperando", "pausa", "sinVer", "comandas"):
        assert "v-if=\"store.franja && store.franja." + n + "\"" in APP
    assert 'href="#/sinc/pisados"' in APP and "franja: null" in APP
    assert "v-html" not in PIS and "v-html" not in _bloque()


def test_pagina_pisados_textos_y_llamadas():
    for t in ("Esta lista es solo para leer: si quiere su valor, vuelva a escribirlo.", "Marcar como vistos", "Datos que no subieron solos",
              "No hay cambios pendientes de revisar.", "Cambios que no quedaron"):
        assert t in PIS
    for u in ("/api/sinc/datos/pisados?limite=200", "/api/sinc/datos/pisados/vistos", "/api/sinc/datos/choques"):
        assert u in PIS
    for mal in ("Restaurar", "Volver a poner", "sincroniza", "token", "servidor", "API"):
        assert mal not in PIS.split("template:")[1], mal


def test_instalacion_local_entrada_solo_con_datos_v2():
    assert "verPisados() { return !!(sesion.empresaInfo && (sesion.empresaInfo.datos_v2 || sesion.empresaInfo.sinc_pantallas)); }" in INST
    assert 'v-if="verPisados && est"' in INST and 'href="#/sinc/pisados"' in INST and "Cambios que no quedaron" in INST


# ------------------------------------------------------------------------------------------------------------- con Node: el bloque
FALSOS_FRANJA = {
    "pages/pos/_estacion.js": """
export const estadoEstacion = { resumen: null };
export function iniciarDesdeApp() { globalThis.Q.estacion.push('inicia'); }
export function pararDesdeApp() { globalThis.Q.estacion.push('para'); }
""",
}


def _guion(cuerpo: str) -> str:
    return """
import fs from 'node:fs';
const Q = globalThis.Q = { llamadas: [], estacion: [], sonidos: 0, timers: [], respuestas: {}, hash: '/inicio',
  sesion: { activa: true, empresa_id: 7, empresaInfo: {}, puede: p => !globalThis.Q.cajero }, store: { franja: null } };
globalThis.location = { get hash() { return '#' + Q.hash; } };
globalThis.window = { AudioContext: class { constructor() { Q.sonidos++; } createOscillator() { return { connect() {}, frequency: {}, start() {}, stop() {} }; } createGain() { return { connect() {}, gain: {} }; } get destination() { return {}; } get currentTime() { return 0; } } };
globalThis.setInterval = (f, ms) => { Q.timers.push(ms); return Q.timers.length; };
globalThis.clearInterval = () => { Q.timers.push('clear'); };
let src = fs.readFileSync('./bloque.txt', 'utf8');
const pre = `const sesion = globalThis.Q.sesion, store = globalThis.Q.store;
const api = async (u, o) => { globalThis.Q.llamadas.push(u); const r = globalThis.Q.respuestas[u.split('?')[0]]; if (r instanceof Error) throw r; if (typeof r === 'function') return r(); return r; };
const decodificarRuta = x => x;\\n`;
fs.mkdirSync('./js/pages/pos', { recursive: true });
fs.writeFileSync('./js/franja.mjs', pre + src + '\\nexport { franjaTick, vigilarFranja, ajustarEstacion };');
const F = await import('./js/franja.mjs');
const esperar = () => new Promise(r => setTimeout(r, 30));
const out = {};
""" + cuerpo + "\nconsole.log(JSON.stringify(out));\n"


def _correr(tmp_path, cuerpo):
    (tmp_path / "bloque.txt").write_text(_bloque(), encoding="utf-8")
    return _node(tmp_path, _guion(cuerpo), archivos=(), falsos=FALSOS_FRANJA)


def test_textos_puros_singular_y_plural(tmp_path):
    r = _correr(tmp_path, """
out.esp = [F.textoEsperando(0, 0), F.textoEsperando(1, 1), F.textoEsperando(3, 0), F.textoEsperando(0, 2), F.textoEsperando(5, 12), F.textoEsperando(null, undefined)];
out.nq = [F.textoNoQuedaron(0), F.textoNoQuedaron(1), F.textoNoQuedaron(4)];
out.co = [F.textoComandas(0), F.textoComandas(1), F.textoComandas(3)];
""")
    assert r["esp"] == ["", "1 cambio y 1 venta esperando a la página web", "3 cambios esperando a la página web", "2 ventas esperando a la página web",
                        "5 cambios y 12 ventas esperando a la página web", ""]
    assert r["nq"] == ["", "Hay 1 cambio que no quedó: ", "Hay 4 cambios que no quedaron: "]
    assert r["co"] == ["", "Hay 1 comanda de pedidos sin imprimir: abra la Caja.", "Hay 3 comandas de pedidos sin imprimir: abra la Caja."]


def test_sin_banderas_todo_como_la_431(tmp_path):
    # ni consulta, ni temporizador, ni estación, ni texto; una pestaña vieja (sin la función) tampoco rompe
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { es_local: true };
F.vigilarFranja(); await esperar();
out.llamadas = Q.llamadas; out.timers = Q.timers; out.estacion = Q.estacion; out.franja = Q.store.franja;
F.pararFranja(); await esperar(); out.despues = Q.estacion;
""")
    assert r["llamadas"] == [] and r["timers"] == [] and r["estacion"] == [] and r["franja"] is None and r["despues"] == []


def test_franja_con_datos_v2_muestra_y_se_esconde_con_404_o_sin_red(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { datos_v2: true };
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 2, ventas: 1, pausa: false, sin_ver: 3, choques: 0 };
F.vigilarFranja(); await esperar();
out.timers = Q.timers.slice(); out.franja = Q.store.franja; out.llamadas = Q.llamadas.slice();
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 0, ventas: 0, pausa: true, sin_ver: 0, choques: 0 };
await F.franjaTick(); out.pausa = Q.store.franja;
const e = new Error('Not Found'); e.status = 404; Q.respuestas['/api/sinc/datos/franja'] = e;
await F.franjaTick(); out.error404 = Q.store.franja;
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 0, ventas: 0, pausa: false, sin_ver: 0, choques: 0 };
await F.franjaTick(); out.limpia = Q.store.franja;
F.pararFranja(); await esperar(); out.final = [Q.store.franja, Q.timers.slice(-1)[0]];
""")
    assert r["timers"] == [30000]
    assert r["llamadas"] == ["/api/sinc/datos/franja"]                          # sin pedidos_programa: nada de /api/pedidos/resumen
    assert r["franja"]["esperando"] == "2 cambios y 1 venta esperando a la página web"
    assert r["franja"]["sinVer"] == "Hay 3 cambios que no quedaron: " and not r["franja"]["pausa"] and not r["franja"]["comandas"]
    assert r["pausa"]["pausa"].startswith("Este programa no puede enviar")
    assert r["error404"] is None and r["limpia"] is None and r["final"] == [None, "clear"]


def test_comandas_sin_imprimir_con_sonido_una_vez_por_subida_y_no_en_caja_ni_cocina(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { pedidos_programa: true };
let n = 2; Q.respuestas['/api/pedidos/resumen'] = () => ({ comandas_pendientes: n, comanda_espera_s: 0 });
await F.franjaTick(); out.a = [Q.store.franja && Q.store.franja.comandas, Q.sonidos];
await F.franjaTick(); out.b = Q.sonidos;                       // mismo número: no vuelve a sonar
n = 3; await F.franjaTick(); out.c = Q.sonidos;                // subió: suena
n = 0; await F.franjaTick(); out.d = [Q.store.franja, Q.sonidos];
n = 1; Q.hash = '/pos/caja'; const antes = Q.llamadas.length; await F.franjaTick(); out.caja = [Q.store.franja, Q.llamadas.length - antes, Q.sonidos];
Q.hash = '/pos/cocina?x=1'; await F.franjaTick(); out.cocina = [Q.store.franja, Q.sonidos];
Q.hash = '/inicio'; await F.franjaTick(); out.fuera = [Q.store.franja && Q.store.franja.comandas, Q.sonidos];
out.consultas_franja = Q.llamadas.filter(u => u.includes('datos/franja')).length;
""")
    assert r["a"] == ["Hay 2 comandas de pedidos sin imprimir: abra la Caja.", 1]
    assert r["b"] == 1 and r["c"] == 2 and r["d"] == [None, 2]
    assert r["caja"] == [None, 0, 2] and r["cocina"] == [None, 2]                # con la Caja o la Cocina abiertas: ni texto ni consulta
    assert r["fuera"] == ["Hay 1 comanda de pedidos sin imprimir: abra la Caja.", 3]   # 1 > 0: subió otra vez
    assert r["consultas_franja"] == 0                                           # sin datos_v2 no se pide la franja


def test_comandas_reusa_el_resumen_de_la_estacion_si_es_reciente(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { pedidos_programa: true };
const E = await import('./js/pages/pos/_estacion.js');
E.estadoEstacion.resumen = { comandas_pendientes: 4, hora: Date.now() };
Q.respuestas['/api/pedidos/resumen'] = () => ({ comandas_pendientes: 9 });
await F.franjaTick(); out.fresco = [Q.store.franja.comandas, Q.llamadas.length];
E.estadoEstacion.resumen = { comandas_pendientes: 4, hora: Date.now() - 120000 };
await F.franjaTick(); out.viejo = [Q.store.franja.comandas, Q.llamadas.length];
""")
    assert r["fresco"] == ["Hay 4 comandas de pedidos sin imprimir: abra la Caja.", 0]
    assert r["viejo"] == ["Hay 9 comandas de pedidos sin imprimir: abra la Caja.", 1]


def test_estacion_desde_app_inicia_una_vez_y_para_al_salir_o_cambiar_de_empresa(tmp_path):
    r = _correr(tmp_path, """
Q.sesion.empresaInfo = { datos_v2: true, pedidos_programa: true };
Q.respuestas['/api/sinc/datos/franja'] = { cambios: 0, ventas: 0, pausa: false, sin_ver: 0, choques: 0 };
Q.respuestas['/api/pedidos/resumen'] = { comandas_pendientes: 0 };
F.vigilarFranja(); await esperar(); F.vigilarFranja(); await esperar(); await F.franjaTick();
out.inicia = Q.estacion.slice();
F.pararFranja(); await esperar(); F.pararFranja(); await esperar();
out.para = Q.estacion.slice();
Q.sesion.empresa_id = 8; F.vigilarFranja(); await esperar();
out.otra = Q.estacion.slice();
Q.sesion.activa = false; F.pararFranja(); await esperar(); out.salio = Q.estacion.slice();
""")
    assert r["inicia"] == ["inicia"]                                            # varias llamadas, un solo efecto
    assert r["para"] == ["inicia", "para"]                                      # parar dos veces no repite
    assert r["otra"] == ["inicia", "para", "inicia"] and r["salio"] == ["inicia", "para", "inicia", "para"]


def test_estacion_version_vieja_en_cache_no_rompe(tmp_path):
    (tmp_path / "x").mkdir()
    falsos = {"pages/pos/_estacion.js": "export const estadoEstacion = { resumen: null };\n"}      # sin iniciarDesdeApp ni pararDesdeApp
    (tmp_path / "bloque.txt").write_text(_bloque(), encoding="utf-8")
    r = _node(tmp_path, _guion("""
Q.sesion.empresaInfo = { pedidos_programa: true };
Q.respuestas['/api/pedidos/resumen'] = { comandas_pendientes: 0 };
F.vigilarFranja(); await esperar(); F.pararFranja(); await esperar();
out.ok = true;
"""), archivos=(), falsos=falsos)
    assert r["ok"] is True


# ------------------------------------------------------------------------------------------------------------- con Node: la página
def test_pagina_pisados_con_node(tmp_path):
    falsos = {
        "api.js": """
export const api = async (u, o) => { globalThis.Q.llamadas.push([u, o && o.method || 'GET']); const r = globalThis.Q.resp[u.split('?')[0]]; if (r instanceof Error) throw r; return r; };
export const toast = (m, t) => globalThis.Q.toasts.push(m);
export const fechaHora = v => 'F:' + v;
""",
        "app.js": "export const sesion = globalThis.Q.sesion;\n",
    }
    r = _node(tmp_path, """
const Q = globalThis.Q = { llamadas: [], toasts: [], resp: {}, sesion: { empresa_id: 7, esAdmin: true, puede: () => true, empresaInfo: { es_local: false } } };
const C = (await import('./js/pages/sinc/pisados.js')).default;
function montar() { const vm = Object.assign({ $emit() {} }, C.data.call({})); for (const [k, f] of Object.entries(C.computed || {})) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm); return vm; }
const out = {};
let vm = montar();
Q.resp['/api/sinc/datos/pisados'] = { pisados: [{ id: 1, cuando: '2026-11-13T10:00:00', tipo: 'item', tipo_nombre: 'Ítem', nombre: 'Casado', campo: 'precio', texto: 'Su cambio de precio no quedó.', quedo_de: 'Caja 2', visto: false }], sin_ver: 1 };
Q.resp['/api/sinc/datos/pisados/vistos'] = { ok: true, marcados: 1 };
await vm.cargar(); out.web = [vm.pisados.length, vm.sinVer, vm.choques.length, vm.cargando, Q.llamadas.map(x => x[0])];
Q.resp['/api/sinc/datos/pisados'] = { pisados: [], sin_ver: 0 };
await vm.marcarVistos(); out.vistos = Q.llamadas.map(x => x.join(' ')).slice(-2);   // ya estaba visto = 0 ... se marca solo si hay sin ver
vm = montar(); Q.sesion.empresaInfo = { es_local: true };
Q.resp['/api/sinc/datos/pisados'] = { pisados: [], sin_ver: 0 };
Q.resp['/api/sinc/datos/choques'] = { choques: [{ clase: 'x', texto: 'No subió el ítem.', tipo_nombre: 'Ítem', nombre: 'Casado', detalle: 'd', cuando: 'c' }] };
await vm.cargar(); out.programa = [vm.enPrograma, vm.choques.length, vm.pisados.length, Q.llamadas.slice(-2).map(x => x[0])];
const e = new Error('Not Found'); e.status = 404; Q.resp['/api/sinc/datos/pisados'] = e; Q.resp['/api/sinc/datos/choques'] = e;
await vm.cargar(); out.silencio = [vm.pisados.length, vm.choques.length, vm.cargando, Q.toasts.length];
Q.sesion.puede = () => false; Q.sesion.esAdmin = false; out.puede = vm.puede;
console.log(JSON.stringify(out));
""", archivos=("pages/sinc/pisados.js",), falsos=falsos)
    assert r["web"] == [1, 1, 0, False, ["/api/sinc/datos/pisados?limite=200"]]      # en la web no se pide la lista de choques
    assert r["programa"] == [True, 1, 0, ["/api/sinc/datos/pisados?limite=200", "/api/sinc/datos/choques"]]
    assert r["silencio"] == [0, 0, False, 0] and r["puede"] is False


def test_pagina_pisados_marcar_vistos_manda_el_post_y_recarga(tmp_path):
    falsos = {
        "api.js": """
export const api = async (u, o) => { globalThis.Q.llamadas.push((o && o.method || 'GET') + ' ' + u); return globalThis.Q.resp(u); };
export const toast = () => {}; export const fechaHora = v => String(v);
""",
        "app.js": "export const sesion = globalThis.Q.sesion;\n",
    }
    r = _node(tmp_path, """
let sin = 2;
const Q = globalThis.Q = { llamadas: [], sesion: { empresa_id: 7, esAdmin: true, puede: () => true, empresaInfo: {} },
  resp: u => u.includes('vistos') ? (sin = 0, { ok: true, marcados: 2 }) : { pisados: [{ id: 1, texto: 't', visto: sin === 0 }], sin_ver: sin } };
const C = (await import('./js/pages/sinc/pisados.js')).default;
const vm = Object.assign({ $emit() {} }, C.data.call({})); for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
await vm.cargar(); await vm.marcarVistos();
console.log(JSON.stringify({ llamadas: Q.llamadas, sinVer: vm.sinVer }));
""", archivos=("pages/sinc/pisados.js",), falsos=falsos)
    assert r["llamadas"] == ["GET /api/sinc/datos/pisados?limite=200", "POST /api/sinc/datos/pisados/vistos", "GET /api/sinc/datos/pisados?limite=200"]
    assert r["sinVer"] == 0
