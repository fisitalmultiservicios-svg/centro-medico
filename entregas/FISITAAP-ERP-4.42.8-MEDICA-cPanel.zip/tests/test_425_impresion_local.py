# -*- coding: utf-8 -*-
"""4.25 (tanda 8): impresión en el programa de escritorio. Las impresoras de cada computadora (registro «equipo_impresion», solo de
esa computadora: no sube, no baja y no se comparte por la red del local), tiquetes a la suya y etiquetas a la suya, la guarda de las
impresoras de la empresa en el programa conectado (E-6) y los mensajes llanos del servicio de impresión.

Nada va a una impresora real: socket.create_connection y win32print se sustituyen por dobles que guardan los bytes. No se usa ninguno
de los puertos 8020, 8030, 8031 ni 9800 (el agente suelto de la última prueba escucha en un puerto libre que da el sistema)."""
import http.client
import json
import logging
import pathlib
import types

import pytest
from sqlmodel import Session

from app import agente_local, auth, escpos, modulos, sinc
from app import etiquetas_impresora as ei
from app.db import Empresa, engine, engine_empresa
from test_49_local_sinc import H, NUBE, _admin_empresa, _poner_cfg, _Respuesta, c
from tests.test_424_etiquetas import _node

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
CAFE = {"nombre": "Café molido 500 g", "codigo": "2000000000015", "copias": 1}
CAJA = {"id": 1, "nombre": "Caja", "uso": "comprobante", "conexion": "red", "direccion": "192.168.1.50", "ancho": 80, "activa": True}
COCINA = {"id": 2, "nombre": "Cocina", "uso": "comanda", "conexion": "usb", "direccion": "COCINA", "ancho": 80, "activa": True}
ETQ = {"id": 5, "nombre": "Etiquetas", "uso": "etiquetas", "conexion": "usb", "direccion": "3nStar LDT124", "modelo": "3nstar-ldt124", "lenguaje": "tspl", "dpi": 203,
       "etq_ancho_mm": 50, "etq_alto_mm": 30, "separacion_mm": 2, "densidad": 8, "girar": False, "activa": True}
ETQ_PDF = {"id": 6, "nombre": "Etiquetas PDF", "uso": "etiquetas", "conexion": "navegador", "direccion": "", "modelo": "otra-pdf", "lenguaje": "pdf", "dpi": 203,
           "etq_ancho_mm": 50, "etq_alto_mm": 30, "activa": True}
FALSO_API = """
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const api = async (url, opt) => globalThis.Q.api(url, opt);
export const fmt = v => String(v), fecha = v => String(v);
"""


def _trabajo(**cambios):
    return {"conexion": "usb", "direccion": "3nStar LDT124", "lenguaje": "tspl", "ancho_mm": 50, "alto_mm": 30, "separacion_mm": 2, "densidad": 8,
            "etiquetas": [dict(CAFE)], **cambios}


# ------------------------------------------------------------------------------------------------ dobles de las impresoras
class _Red:
    """socket.create_connection: guarda (destino, bytes) o falla con la excepción indicada."""
    def __init__(self):
        self.enviados, self.falla = [], None

    def create_connection(self, destino, timeout=None):
        if self.falla:
            raise self.falla
        self.enviados.append([destino, b""])
        return self

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def sendall(self, datos):
        self.enviados[-1][1] += datos


class _ErrorWin(Exception):
    """Como pywintypes.error: (código, función, texto) y .winerror."""
    def __init__(self, codigo, funcion, texto):
        super().__init__(codigo, funcion, texto)
        self.winerror = codigo


class _Win:
    """win32print: las impresoras de Windows de esta computadora y los trabajos que recibe cada una."""
    PRINTER_ENUM_LOCAL, PRINTER_ENUM_CONNECTIONS = 2, 4

    def __init__(self, nombres):
        self.nombres, self.trabajos, self.falla_abrir, self.falla_imprimir = list(nombres), [], None, None

    def EnumPrinters(self, _banderas):
        return [(0, "", n, "") for n in self.nombres]

    def GetDefaultPrinter(self):
        return self.nombres[0]

    def OpenPrinter(self, nombre):
        if self.falla_abrir:
            raise self.falla_abrir
        return nombre

    def StartDocPrinter(self, h, _nivel, _info):
        if self.falla_imprimir:
            raise self.falla_imprimir
        self.trabajos.append([h, b""])

    def StartPagePrinter(self, h):
        pass

    def WritePrinter(self, h, datos):
        self.trabajos[-1][1] += datos

    def EndPagePrinter(self, h):
        pass

    def EndDocPrinter(self, h):
        pass

    def ClosePrinter(self, h):
        pass


# ------------------------------------------------------------------------------------------------ empresa del programa
@pytest.fixture(scope="module")
def emp():
    eid, tok = _admin_empresa("-t8a", "3101425808")
    yield eid, tok
    _poner_cfg(eid, vinculado=False, impresoras_web=None)          # que ninguna otra prueba la tome por vinculada


@pytest.fixture
def programa(monkeypatch):
    """El programa de escritorio: /api/agente/* responde y las impresoras de Windows y de red son dobles."""
    red, win = _Red(), _Win(["EPSON TM-T20", "3nStar LDT124", "Zebra ZD230"])
    monkeypatch.setattr(agente_local, "MODO_LOCAL", True)
    monkeypatch.setattr(escpos, "socket", types.SimpleNamespace(create_connection=red.create_connection))
    monkeypatch.setattr(escpos, "win32print", win)
    monkeypatch.setitem(agente_local._estado, "ultimo_error", "")
    return types.SimpleNamespace(red=red, win=win)


def _impresoras_empresa(eid, lista):
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "pos_impresoras")
        modulos.reemplazar(s, eid, "pos_impresoras", lista, version=(r.version or 0) if r else 0)
        s.commit()


def _equipo(eid):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, "equipo_impresion", None)


# ================================================================================================ el servicio de impresión
def test_estado_y_etiquetas_tspl_y_zpl_por_red_y_por_usb(emp, programa):
    _, tok = emp
    e = c.get("/api/agente/estado", headers=H(tok)).json()
    assert e["etiquetas"] == escpos.VERSION_ETIQUETAS == 1 and e["impresoras_windows"] == ["EPSON TM-T20", "3nStar LDT124", "Zebra ZD230"]
    imprimir = lambda trabajo, imp=None: c.post("/api/agente/imprimir", headers=H(tok), json={"impresora": imp or {"nombre": "Etiquetas"}, "etiquetas": trabajo})   # noqa: E731
    # por red: a la IP en el 9100
    assert imprimir(_trabajo(conexion="red", direccion="192.168.1.60")).status_code == 200
    assert imprimir(_trabajo(conexion="red", direccion="192.168.1.61", lenguaje="zpl", densidad=None)).status_code == 200
    (d1, b1), (d2, b2) = programa.red.enviados
    assert d1 == ("192.168.1.60", 9100) and b1.startswith(b"SIZE 50 mm,30 mm\r\nGAP 2 mm,0 mm\r\n") and b1 == ei.tspl([CAFE], 50, 30, 2, 8)
    assert d2 == ("192.168.1.61", 9100) and b2.startswith(b"^XA") and b2 == ei.zpl([CAFE], 50, 30)
    # por USB: a la impresora de Windows por su nombre
    assert imprimir(_trabajo()).status_code == 200
    assert imprimir(_trabajo(direccion="Zebra ZD230", lenguaje="zpl", densidad=None)).status_code == 200
    (n1, u1), (n2, u2) = programa.win.trabajos
    assert n1 == "3nStar LDT124" and u1.startswith(b"SIZE 50 mm,30 mm\r\nGAP 2 mm,0 mm\r\n") and n2 == "Zebra ZD230" and u2.startswith(b"^XA")
    # un trabajo mal armado: 400 con su motivo y no sale nada
    for malo in (_trabajo(ancho_mm=500), _trabajo(lenguaje="pdf"), _trabajo(etiquetas=[]), "SIZE 50 mm,30 mm\r\nPRINT 1", _trabajo(conexion="red", direccion="127.0.0.1:8020")):
        r = imprimir(malo)
        assert r.status_code == 400, (malo, r.text)
    assert "de 20 a 110 mm de ancho" in imprimir(_trabajo(ancho_mm=500)).json()["detail"]
    assert len(programa.red.enviados) == 2 and len(programa.win.trabajos) == 2


def test_en_la_misma_caja_el_tiquete_va_a_su_impresora_y_la_etiqueta_a_la_suya(emp, programa):
    _, tok = emp
    tiquete = {"impresora": {"nombre": "Caja", "conexion": "red", "direccion": "192.168.1.50", "ancho": 80}, "documento": {"bloques": [{"t": "texto", "x": "TIQUETE 1"}]}}
    etiqueta = {"impresora": {"nombre": "Etiquetas", "conexion": "usb", "direccion": "3nStar LDT124"}, "etiquetas": _trabajo()}
    assert c.post("/api/agente/imprimir", headers=H(tok), json=tiquete).status_code == 200
    assert c.post("/api/agente/imprimir", headers=H(tok), json=etiqueta).status_code == 200
    assert [d for d, _ in programa.red.enviados] == [("192.168.1.50", 9100)] and programa.red.enviados[0][1].startswith(b"\x1b@") and b"TIQUETE 1" in programa.red.enviados[0][1]
    assert [n for n, _ in programa.win.trabajos] == ["3nStar LDT124"] and programa.win.trabajos[0][1].startswith(b"SIZE ") and b"TIQUETE" not in programa.win.trabajos[0][1]


# ================================================================================================ la función única de la pantalla
def test_la_pantalla_decide_la_impresora_de_esta_computadora_con_una_sola_funcion(tmp_path):
    r = _node(tmp_path, """
globalThis.Q = { toasts: [], pedidos: [], api: async () => { throw Object.assign(new Error('no'), { status: 404 }); } };
globalThis.fetch = async () => { throw new Error('sin agente suelto en esta prueba'); };
const A = await import('./js/pages/pos/_agente.js');
const CAJA = """ + json.dumps(CAJA) + """, COCINA = """ + json.dumps(COCINA) + """, ETQ = """ + json.dumps(ETQ) + """;
const CAJA2 = { id: 7, nombre: 'Caja 2', uso: 'comprobante', conexion: 'red', direccion: '192.168.1.51', ancho: 80, activa: true };
const lista = [CAJA, COCINA, ETQ, CAJA2];
const eq = { propias: [{ id: 'eq-a', nombre: 'Mostrador', uso: 'comprobante', conexion: 'usb', direccion: 'EPSON TM-T20', ancho: 58, activa: true },
                       { id: 'eq-e', nombre: 'Zebra de aquí', uso: 'etiquetas', conexion: 'red', direccion: '192.168.1.70', lenguaje: 'zpl', etq_ancho_mm: 50, etq_alto_mm: 30, activa: true }],
             ajustes: { '1': { conexion: 'usb', direccion: 'EPSON TM-T20' }, '5': { conexion: 'red', direccion: '192.168.1.90', densidad: 12, girar: true } }, tiquetes: '', etiquetas: '' };
const d = i => i && [i.nombre, i.conexion, i.direccion];
const out = {};
// en la web (sin el programa): nada se pide y todo queda como en la configuración
out.web = await A.cargarEquipo(true); out.web_pedidos = Q.pedidos.slice(); out.web_igual = A.impresoraAqui(CAJA) === CAJA && A.impresoraTiqueteAqui(CAJA, lista) === CAJA;
// lo de esta computadora: ajustes, propias, tiquetes
out.caja_aqui = d(A.impresoraAqui(CAJA, eq)); out.cocina = d(A.impresoraAqui(COCINA, eq));
const e5 = A.impresoraAqui(ETQ, eq); out.etq = [d(e5), e5.densidad, e5.girar, e5.separacion_mm]; out.sin_tocar = [ETQ.conexion, ETQ.densidad];
out.tiq_caja = d(A.impresoraTiqueteAqui(CAJA, lista, eq));
out.tiq_propia = d(A.impresoraTiqueteAqui(CAJA, lista, { ...eq, tiquetes: 'eq-a' }));
out.tiq_otra = d(A.impresoraTiqueteAqui(CAJA, lista, { ...eq, tiquetes: '7' }));
out.tiq_mal_uso = d(A.impresoraTiqueteAqui(CAJA, lista, { ...eq, tiquetes: 'eq-e' }));
out.tiq_sin_caja = d(A.impresoraTiqueteAqui(null, lista, { ...eq, tiquetes: 'eq-a' }));
out.etiquetas = A.impresorasAqui(lista, 'etiquetas', eq).map(d);
out.misma_caja = [d(A.impresoraTiqueteAqui(CAJA, lista, eq)), d(A.impresorasAqui(lista, 'etiquetas', eq)[0])];
out.por_id = d(A.impresoraPorId('5', lista, eq));
// en el programa: se lee /api/agente/equipo
Q.api = async (url) => { Q.pedidos.push(url); if (url === '/api/agente/estado') return { agente: 'FISITAAP ERP', etiquetas: 1 }; if (url === '/api/agente/equipo') return { equipo: eq, empresa_web: true }; throw new Error('?'); };
const p = await A.cargarEquipo(true); out.programa = [p.web, !!A.equipo(), A.empresaWeb(), Q.pedidos];
out.cache = d(A.impresoraTiqueteAqui(CAJA, lista));
console.log(JSON.stringify(out));
""", archivos=(("pages", "pos", "_agente.js"),), falsos={"api.js": FALSO_API})
    assert r["web"] == {"datos": None, "web": False, "hora": r["web"]["hora"]} and r["web_pedidos"] == [] and r["web_igual"] is True
    assert r["caja_aqui"] == ["Caja", "usb", "EPSON TM-T20"] and r["cocina"] == ["Cocina", "usb", "COCINA"]          # los ajustes de aquí cambian el destino; sin ajuste, igual
    assert r["etq"] == [["Etiquetas", "red", "192.168.1.90"], 12, True, 2] and r["sin_tocar"] == ["usb", 8]           # la de la empresa no se toca
    assert r["tiq_caja"] == ["Caja", "usb", "EPSON TM-T20"]                                                           # sin elegir: la de la caja, como está aquí
    assert r["tiq_propia"] == ["Mostrador", "usb", "EPSON TM-T20"] and r["tiq_otra"] == ["Caja 2", "red", "192.168.1.51"]   # la de esta computadora manda
    assert r["tiq_mal_uso"] == ["Caja", "usb", "EPSON TM-T20"] and r["tiq_sin_caja"] == ["Mostrador", "usb", "EPSON TM-T20"]
    assert r["etiquetas"] == [["Etiquetas", "red", "192.168.1.90"], ["Zebra de aquí", "red", "192.168.1.70"]]
    assert r["misma_caja"][0] != r["misma_caja"][1] and r["por_id"] == ["Etiquetas", "red", "192.168.1.90"]
    assert r["programa"] == [True, True, True, ["/api/agente/estado", "/api/agente/equipo"]] and r["cache"] == ["Caja", "usb", "EPSON TM-T20"]


def test_todos_los_caminos_de_impresion_pasan_por_la_funcion_unica():
    caja = (JS / "pages/pos/caja.js").read_text(encoding="utf-8"); cierres = (JS / "pages/pos/cierres.js").read_text(encoding="utf-8")
    cocina = (JS / "pages/pos/cocina.js").read_text(encoding="utf-8"); cfg = (JS / "pages/pos/configuracion.js").read_text(encoding="utf-8")
    dlg = (JS / "pages/inventario/_etiquetas-dialogos.js").read_text(encoding="utf-8"); montos = (JS / "pages/reportes/_montos.js").read_text(encoding="utf-8")
    # tiquete, factura, gaveta y provisional: todos por impresoraTiquete(), que pasa por la de esta computadora
    assert "impresoraTiquete() { return impresoraTiqueteAqui(this.impresoraCaja(), impresoras()); }," in caja
    assert caja.count("this.impresoraTiquete()") == 4 and caja.count("impresoras().find(") == 1
    assert "g.imp = impresoraAqui(g.imp);" in caja and "g.imp = impresoraAqui(g.imp);" in cocina                  # comandas: la de la categoría, como está aquí
    assert "const imp = impresoraTiqueteAqui(completa && !propia ? null : deCaja, impresoras());" in cierres        # la colilla del cierre (4.41: la completa que la caja no da a su cajero, no en la de la caja)
    assert "i = impresoraAqui(i);" in cfg and "async probarGaveta(i) { i = impresoraAqui(i);" in cfg              # «Probar» y «Gaveta»
    assert "const imp = esPropia(i) ? i : impresoraAqui(i, this.eqLimpio());" in cfg                              # «Probar» de la tarjeta, con lo que está en pantalla
    assert "this.imps = A.impresorasAqui(mock.get('pos_impresoras', []) || [], 'etiquetas', eq);" in dlg            # el cuadro de etiquetas
    assert "if (A.impresoraAqui) impresora = A.impresoraAqui(impresora);" in montos                                 # reportes en la térmica


# ================================================================================================ el registro no viaja
def test_el_registro_de_esta_computadora_no_sube_no_baja_ni_se_comparte(emp, programa, monkeypatch):
    eid, tok = emp
    _impresoras_empresa(eid, [CAJA, COCINA, ETQ])
    eq = {"propias": [{"id": "eq-a1", "nombre": "Mostrador", "uso": "comprobante", "conexion": "usb", "direccion": "EPSON TM-T20", "ancho": 58, "activa": True}],
          "ajustes": {"5": {"conexion": "red", "direccion": "192.168.1.90", "densidad": 12}}, "tiquetes": "eq-a1", "etiquetas": "5"}
    r = c.put("/api/agente/equipo", headers=H(tok), json=eq)
    assert r.status_code == 200, r.text
    guardado = _equipo(eid)
    assert guardado["tiquetes"] == "eq-a1" and guardado["ajustes"] == {"5": {"conexion": "red", "direccion": "192.168.1.90", "densidad": 12}}
    # no está en ninguna de las listas que viajan
    for lista in (sinc.CLAVES_CATALOGO, sinc.CLAVES_OPERATIVAS, sinc.CLAVES_RED):
        assert "equipo_impresion" not in lista
    assert sinc.CLAVES_DEL_EQUIPO == ("equipo_impresion",)
    py = (RAIZ / "app" / "sinc.py").read_text(encoding="utf-8")
    sube = py[py.index("def _subir_registros("):py.index("def _subir_pagos(")]
    assert "    for clave in CLAVES_OPERATIVAS:" in sube                                       # lo que sube: solo las operativas
    nube = py[py.index('@router.get("/catalogo")'):py.index("def _version_minima_ingreso(") if "def _version_minima_ingreso(" in py else py.index('@router.get("/catalogo")') + 4000]
    assert "    for clave in CLAVES_CATALOGO:" in nube                                         # lo que baja: solo el catálogo
    assert "            if clave not in CLAVES_RED or not isinstance(cambio, dict):" in py      # lo que recibe de otra computadora del local
    red = py[py.index("def _payload_red("):]
    assert "    for clave in CLAVES_RED:" in red[:red.index("\ndef ", 10)]                     # lo que manda a otra computadora del local
    # los registros genéricos no lo leen ni lo escriben (ni aquí ni en la web)
    todo = c.get("/api/registros?v=2", headers=H(tok)).json()
    assert "equipo_impresion" not in todo["datos"] and "equipo_impresion" not in todo["versiones"] and "pos_impresoras" in todo["datos"]
    assert "equipo_impresion" not in c.get("/api/registros/versiones", headers=H(tok)).json()
    assert c.get("/api/registros/equipo_impresion", headers=H(tok)).status_code == 403
    assert c.put("/api/registros/equipo_impresion", headers=H(tok), json={"datos": {}, "version": 1}).status_code == 403
    assert c.post("/api/registros/equipo_impresion/cambios", headers=H(tok), json={"upserts": [], "deletes": []}).status_code == 403
    assert c.delete("/api/registros/equipo_impresion", headers=H(tok)).status_code == 403
    assert _equipo(eid) == guardado
    # una bajada (aunque una nube lo mandara) no lo borra ni lo pisa; y anota que la web mandó su lista de impresoras
    nuevas = [dict(CAJA, nombre="Caja de la web"), COCINA, ETQ]

    class _Nube:
        def get(self, url, headers=None, timeout=None):
            assert url == NUBE + "/api/sinc/catalogo"
            return _Respuesta(200, {"empresa": {}, "registros": {"pos_impresoras": nuevas, "equipo_impresion": {"propias": [], "tiquetes": ""}}})
    monkeypatch.setattr(sinc, "httpx", _Nube())
    cfg = {}
    with Session(engine_empresa(eid)) as s, Session(engine) as sc:
        sinc._bajar(s, sc, sc.get(Empresa, eid), cfg, NUBE, {}, 0)
    assert cfg["impresoras_web"] is True and _equipo(eid) == guardado
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "pos_impresoras")[0]["nombre"] == "Caja de la web"
    # sin lista de impresoras en la bajada: no se anota
    monkeypatch.setattr(sinc, "httpx", types.SimpleNamespace(get=lambda url, headers=None, timeout=None: _Respuesta(200, {"empresa": {}, "registros": {"monedas": []}})))
    cfg = {}
    with Session(engine_empresa(eid)) as s, Session(engine) as sc:
        sinc._bajar(s, sc, sc.get(Empresa, eid), cfg, NUBE, {}, 0)
    assert cfg["impresoras_web"] is False and _equipo(eid) == guardado
    _impresoras_empresa(eid, [CAJA, COCINA, ETQ])


# ================================================================================================ E-6
def test_e6_en_el_programa_conectado_las_impresoras_de_la_empresa_son_de_la_web(emp, programa, monkeypatch):
    eid, tok = emp
    _impresoras_empresa(eid, [CAJA, COCINA, ETQ])
    leer = lambda: c.get("/api/registros/pos_impresoras", headers=H(tok)).json()   # noqa: E731
    poner = lambda lista: c.put("/api/registros/pos_impresoras", headers=H(tok), json={"datos": lista, "version": leer()["version"]})   # noqa: E731
    try:
        monkeypatch.setattr(sinc, "MODO_LOCAL", True)
        # programa sin conectar: como hoy
        _poner_cfg(eid, vinculado=False, impresoras_web=True)
        assert poner([CAJA, COCINA, ETQ, dict(CAJA, id=8, nombre="Barra")]).status_code == 200
        assert c.get("/api/agente/equipo", headers=H(tok)).json()["empresa_web"] is False
        # conectado, pero la web todavía no mandó su lista: como hoy
        _poner_cfg(eid, vinculado=True, impresoras_web=False)
        assert poner([CAJA, COCINA, ETQ]).status_code == 200
        # conectado y la web ya mandó su lista: 409 al crear, cambiar o eliminar una impresora de la empresa
        _poner_cfg(eid, vinculado=True, impresoras_web=True)
        antes = leer()
        r = poner([dict(CAJA, nombre="Caja cambiada"), COCINA, ETQ])
        assert r.status_code == 409 and r.json()["detail"] == sinc.IMPRESORAS_DE_LA_WEB == (
            "Las impresoras de la empresa se crean y se cambian en la página web. Aquí puede indicar cómo está conectada cada una en esta "
            "computadora, o agregar una impresora solo de esta computadora.")
        assert c.post("/api/registros/pos_impresoras/cambios", headers=H(tok), json={"upserts": [], "deletes": [2]}).status_code == 409
        assert c.post("/api/registros/pos_impresoras/cambios", headers=H(tok), json={"upserts": [dict(CAJA, id=9, nombre="Nueva")], "deletes": [], "nuevos": [9]}).status_code == 409
        assert c.delete("/api/registros/pos_impresoras", headers=H(tok)).status_code == 409
        assert leer()["datos"] == antes["datos"]
        # lo de esta computadora sí se guarda
        r = c.get("/api/agente/equipo", headers=H(tok)).json()
        assert r["empresa_web"] is True
        r = c.put("/api/agente/equipo", headers=H(tok), json={"ajustes": {"1": {"conexion": "usb", "direccion": "EPSON TM-T20"}}, "propias": [], "tiquetes": "", "etiquetas": ""})
        assert r.status_code == 200 and r.json()["empresa_web"] is True and _equipo(eid)["ajustes"] == {"1": {"conexion": "usb", "direccion": "EPSON TM-T20"}}
        # las demás claves de configuración no cambian en esta tanda
        assert c.put("/api/registros/pos_promos", headers=H(tok), json={"datos": [], "version": 0}).status_code == 200
        # en la web (no es el programa) la misma configuración no impide nada
        monkeypatch.setattr(sinc, "MODO_LOCAL", False)
        assert poner([CAJA, COCINA, ETQ]).status_code == 200
    finally:
        _poner_cfg(eid, vinculado=False, impresoras_web=None)


# ================================================================================================ validación y permisos
def test_validacion_del_registro_y_permisos(emp, programa):
    eid, tok = emp
    _impresoras_empresa(eid, [CAJA, COCINA, ETQ, ETQ_PDF, dict(CAJA, id=3, nombre="Caja vieja", activa=False)])
    propia = {"id": "eq-b1", "nombre": "Mostrador", "uso": "comprobante", "conexion": "red", "direccion": "192.168.1.77", "ancho": 80, "activa": True}
    etq_propia = {"id": "eq-b2", "nombre": "Zebra de aquí", "uso": "etiquetas", "conexion": "usb", "direccion": "Zebra ZD230", "modelo": "zebra-zd230", "lenguaje": "zpl",
                  "dpi": 203, "etq_ancho_mm": 50, "etq_alto_mm": 30, "densidad": 20, "girar": True, "activa": True, "otro_campo": "<script>"}
    put = lambda cuerpo: c.put("/api/agente/equipo", headers=H(tok), json=cuerpo)   # noqa: E731
    r = put({"propias": [propia, etq_propia], "ajustes": {"1": {"conexion": "usb", "direccion": "EPSON TM-T20"}, "99": {"conexion": "red", "direccion": "192.168.1.5"},
                                                          "eq-b1": {"conexion": "usb"}, "2": {}, "5": {"densidad": "", "separacion_mm": 3, "girar": False}},
             "tiquetes": "eq-b1", "etiquetas": "eq-b2"})
    assert r.status_code == 200, r.text
    g = _equipo(eid)
    assert set(g["ajustes"]) == {"1", "5"} and g["ajustes"]["5"] == {"separacion_mm": 3, "girar": False}            # los ids desconocidos (y los vacíos) se descartan
    assert "otro_campo" not in g["propias"][1] and g["propias"][1]["densidad"] == 20 and g["propias"][1]["girar"] is True
    malos = [
        ({"ajustes": {"1": {"conexion": "navegador"}}}, "impresora de Windows (USB) o por red"),
        ({"ajustes": {"1": {"conexion": "red", "direccion": "impresora.ejemplo.test"}}}, "dirección IP"),
        ({"ajustes": {"1": {"conexion": "usb", "direccion": "x" * 121}}}, "hasta 120 caracteres"),
        ({"ajustes": {"5": {"densidad": 16}}}, "densidad va de 0 a 15"),
        ({"ajustes": {"5": {"separacion_mm": 21}}}, "de 0 a 20 mm"),
        ({"propias": [dict(propia, uso="comanda")]}, "las de comanda son de la empresa"),
        ({"propias": [dict(propia, conexion="navegador")]}, "cómo está conectada"),
        ({"propias": [dict(propia, direccion="192.168.1")]}, "dirección IP"),
        ({"propias": [dict(propia, nombre="  ")]}, "nombre"),
        ({"propias": [dict(propia, id="5")]}, "número válido"),
        ({"propias": [propia, dict(propia)]}, "número válido"),
        ({"propias": [dict(etq_propia, etq_ancho_mm=500)]}, "medida de la etiqueta"),
        ({"propias": [dict(etq_propia, densidad=31)]}, "densidad va de 0 a 30"),
        ({"propias": [dict(etq_propia, conexion="usb", direccion="")]}, "nombre de la impresora de etiquetas en Windows"),
        ({"propias": [dict(propia, id=f"eq-{n}") for n in range(21)]}, "hasta 20"),
        ({"tiquetes": "5"}, "no es de ese uso"),                     # la de etiquetas no recibe tiquetes
        ({"tiquetes": "3"}, "no es de ese uso"),                     # inactiva
        ({"tiquetes": "eq-nada"}, "ya no existe"),
        ({"etiquetas": "1"}, "no es de ese uso"),
        ({"propias": [propia], "etiquetas": "eq-b1"}, "no es de ese uso"),
        ([1, 2], "no son válidos"),
    ]
    for cuerpo, motivo in malos:
        r = put(cuerpo)
        assert r.status_code == 400 and motivo in r.json()["detail"], (cuerpo, r.text)
    assert _equipo(eid) == g                                                                       # nada de eso se guardó
    assert put({"tiquetes": "1", "etiquetas": "6"}).status_code == 200                           # de la empresa, del uso correcto (la de PDF también)
    assert put({}).status_code == 200 and _equipo(eid) == agente_local.equipo_vacio()            # todo es opcional
    # permisos: guardar pide «configurar»; leer, quien usa la caja o el negocio (no los roles de un solo módulo)
    usuario = types.SimpleNamespace(es_superadmin=False)
    cajero = auth.Contexto(usuario, types.SimpleNamespace(id=eid), "Cajero")
    camarera = auth.Contexto(usuario, types.SimpleNamespace(id=eid), "Camarera", permisos={"ver", "limpieza"})
    assert "pos" in cajero.permisos and not cajero.puede("configurar")
    with Session(engine_empresa(eid)) as s:
        assert agente_local.ver_equipo(cajero, s)["equipo"] == agente_local.equipo_vacio()
        with pytest.raises(agente_local.HTTPException) as ex:
            agente_local.guardar_equipo({"tiquetes": "1"}, cajero, s)
        assert ex.value.status_code == 403
        with pytest.raises(agente_local.HTTPException) as ex:
            agente_local.ver_equipo(camarera, s)
        assert ex.value.status_code == 403
    assert _equipo(eid) == agente_local.equipo_vacio()


# ================================================================================================ mensajes llanos
def test_mensajes_llanos_y_el_detalle_tecnico_solo_en_el_registro(emp, programa, caplog):
    import socket as _socket
    _, tok = emp
    caplog.set_level(logging.WARNING, logger="app.agente_local")
    prueba = lambda imp, **extra: c.post("/api/agente/" + extra.pop("ruta", "prueba"), headers=H(tok), json={"impresora": imp, **extra})   # noqa: E731
    casos = [
        (lambda: setattr(programa.red, "falla", _socket.timeout("timed out")), {"nombre": "Caja", "conexion": "red", "direccion": "192.168.1.50"}, {},
         "La impresora «Caja» no responde: revise que esté encendida y conectada a la red", "timed out"),
        (lambda: setattr(programa.red, "falla", ConnectionRefusedError(10061, "[WinError 10061] No se puede establecer una conexión")), {"nombre": "Caja", "conexion": "red", "direccion": "192.168.1.50"}, {},
         "La impresora «Caja» no responde: revise que esté encendida y conectada a la red", "10061"),
        (lambda: None, {"nombre": "Cocina", "conexion": "usb", "direccion": "Impresora que no está"}, {},
         "Windows no tiene una impresora llamada «Cocina». Elíjala de nuevo en Punto de venta › Configuración › Impresoras", "EPSON TM-T20"),
        (lambda: setattr(programa.win, "falla_abrir", _ErrorWin(1801, "OpenPrinter", "El nombre de la impresora no es válido.")), {"nombre": "Caja", "conexion": "usb", "direccion": "EPSON TM-T20"}, {},
         "Windows no tiene una impresora llamada «Caja». Elíjala de nuevo en Punto de venta › Configuración › Impresoras", "1801"),
        (lambda: setattr(programa.win, "falla_imprimir", _ErrorWin(1906, "StartDocPrinter", "La impresora está en pausa.")), {"nombre": "Caja", "conexion": "usb", "direccion": "EPSON TM-T20"}, {},
         "Windows no pudo imprimir en «Caja»: revise que esté encendida, con papel y sin trabajos detenidos", "1906"),
        (lambda: setattr(programa.red, "falla", TimeoutError("timed out")), {"nombre": "Etiquetas", "conexion": "red", "direccion": "192.168.1.60"},
         {"ruta": "imprimir", "etiquetas": _trabajo(conexion="red", direccion="192.168.1.60")}, "La impresora «Etiquetas» no responde: revise que esté encendida y conectada a la red", "timed out"),
        (lambda: None, {"nombre": "Etiquetas", "conexion": "usb", "direccion": "Otra"}, {"ruta": "imprimir", "etiquetas": _trabajo(direccion="Otra")},
         "Windows no tiene una impresora llamada «Etiquetas». Elíjala de nuevo en Punto de venta › Configuración › Impresoras", "EPSON TM-T20"),
    ]
    for preparar, imp, extra, texto, tecnico in casos:
        programa.red.falla = programa.win.falla_abrir = programa.win.falla_imprimir = None
        caplog.clear()
        preparar()
        r = prueba(imp, **dict(extra))
        assert r.status_code == (400 if "etiquetas" in extra else 500) and r.json()["detail"] == texto, r.text
        for raro in ("timed out", "WinError", "1801", "1906", "OpenPrinter", "StartDocPrinter", "Error", "EPSON"):
            assert raro not in r.text, (raro, r.text)
        assert tecnico in caplog.text                                                              # el detalle técnico, al registro
        assert tecnico in c.get("/api/agente/estado", headers=H(tok)).json()["ultimo_error"]       # y al último error del estado
    # un trabajo mal armado sigue diciendo su motivo tal cual
    programa.red.falla = None
    r = prueba({"nombre": "Etiquetas"}, ruta="imprimir", etiquetas=_trabajo(ancho_mm=500))
    assert r.status_code == 400 and "de 20 a 110 mm de ancho" in r.json()["detail"]
    # el agente suelto (en un puerto libre que da el sistema, nunca el 9800) dice lo mismo
    programa.red.falla = _socket.timeout("timed out")
    srv = escpos.iniciar_agente_en_hilo(0, version="4.25")
    try:
        assert srv.puerto not in (8020, 8030, 8031, 9800)
        con = http.client.HTTPConnection("127.0.0.1", srv.puerto, timeout=10)
        con.request("POST", "/prueba", body=json.dumps({"impresora": {"nombre": "Caja", "conexion": "red", "direccion": "192.168.1.50"}}).encode(), headers={"Content-Type": "application/json"})
        resp = con.getresponse(); j = json.loads(resp.read()); con.close()
        assert resp.status == 500 and j == {"ok": False, "error": "La impresora «Caja» no responde: revise que esté encendida y conectada a la red"}
        assert "timed out" in srv.estado["ultimo_error"]
    finally:
        srv.shutdown(); srv.server_close()


# ================================================================================================ en la web nada cambia
def test_en_la_web_nada_cambia(emp, monkeypatch):
    _, tok = emp
    monkeypatch.setattr(agente_local, "MODO_LOCAL", False)
    assert c.get("/api/agente/equipo", headers=H(tok)).status_code == 404
    assert c.put("/api/agente/equipo", headers=H(tok), json={"tiquetes": ""}).status_code == 404
    assert c.get("/api/agente/estado", headers=H(tok)).status_code == 404
    assert c.get("/api/registros/equipo_impresion", headers=H(tok)).status_code == 403
    assert c.put("/api/registros/equipo_impresion", headers=H(tok), json={"datos": {"tiquetes": "1"}, "version": 0}).status_code == 403
    cfg = (JS / "pages/pos/configuracion.js").read_text(encoding="utf-8"); caja = (JS / "pages/pos/caja.js").read_text(encoding="utf-8")
    cierres = (JS / "pages/pos/cierres.js").read_text(encoding="utf-8"); cocina = (JS / "pages/pos/cocina.js").read_text(encoding="utf-8")
    dlg = (JS / "pages/inventario/_etiquetas-dialogos.js").read_text(encoding="utf-8"); agente = (JS / "pages/pos/_agente.js").read_text(encoding="utf-8")
    # la tarjeta solo se muestra en el programa y el registro solo se pide ahí
    assert '<div id="cfg-equipo" class="card" style="grid-column:1/-1" v-if="esPrograma && eq">' in cfg and cfg.count('id="cfg-equipo"') == 1
    assert "esPrograma() { return !!(sesion.empresaInfo && sesion.empresaInfo.es_local); }," in cfg and "if (this.esPrograma) this.cargarEq().catch(() => {});" in cfg
    assert '<div class="alert" v-if="esPrograma && eqWeb"' in cfg
    assert "if (sesion.empresaInfo?.es_local) cargarEquipo().catch(() => {});" in caja
    assert "if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});" in cierres and "if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});" in cocina
    assert "    if (!sesion.empresaInfo?.es_local) return;" in dlg
    assert "if (est.via !== 'local') { _equipo = { datos: null, web: false, hora: Date.now() }; return _equipo; }" in agente     # sin el programa no se pide
    assert agente.count("'/api/agente/equipo'") == 1
    # sin el registro, la función única deja cada impresora como está (la web imprime igual que antes)
    assert "if (!imp || !e || imp.virtual || esPropia(imp)) return imp;" in agente
