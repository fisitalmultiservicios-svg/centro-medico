# -*- coding: utf-8 -*-
"""4.29: número consecutivo en las comandas del restaurante: las PANTALLAS (N-1, N-2 y N-5 a N-8 del encargo).

La caja de restaurante gana el dato opcional `numerar_comanda` ('' = no numerar, por omisión | 'dia' | 'continuo'). Con numeración,
cada envío de comanda pide UN número al servidor (POST /api/pos/comanda/numero, con un tope de 3 s), lo guarda en cada línea enviada
(`comanda`) y lo imprime arriba y en grande en todas las impresoras de ese envío; la pantalla de cocina lo muestra y reimprime con el
mismo. Sin numeración, o si el servidor no contesta, todo sale exactamente como en la 4.28.

Estas pruebas no dependen de la ruta del servidor (la hace otra persona con el mismo contrato): corren las funciones y los métodos
reales de las pantallas en Node, con el servidor simulado, y comparan con el código de la 4.28 copiado aquí abajo."""
import json
import pathlib
import re
import subprocess

import pytest

from test_425_ultimos_pantallas import _node, _nodo

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _metodo(txt: str, cabeza: str) -> str:
    """Un método del componente, de su cabeza hasta su cierre «\\n    },» (sin la coma)."""
    return _tramo(txt, "    " + cabeza, "\n    },\n").strip() + "\n    }"


# ---- el código de la 4.28, tal como se entregó (para comparar: sin número todo debe salir IGUAL) ----
VIEJO_ENVIAR = """
    enviarComanda() {
      const nuevas = this.lineas.filter(l => !l.enviado && +l.cantidad > 0); if (!nuevas.length) return toast('No hay platos nuevos por enviar', 'err');
      const ronda = Math.max(0, ...this.lineas.map(l => +l.ronda || 0)) + 1, ahora = new Date().toISOString(), grupos = {};
      for (const l of nuevas) { const imp = this.destinoDe(l); l.enviado = ahora; l.ronda = ronda; if (imp) { const g = grupos[imp.id] || (grupos[imp.id] = { imp, ls: [] }); g.ls.push(l); } }
      if (this.cfg.imprimir_comanda !== false && Object.keys(grupos).length) this.imprimirComanda(grupos, ronda);
      if (this.esRestaurante) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos
      toast('Comanda ' + ronda + ' enviada' + (Object.keys(grupos).length ? ' a ' + Object.values(grupos).map(g => g.imp.nombre).join(', ') : ''), 'ok');
    },
"""
VIEJO_IMPRIMIR = """
    async imprimirComanda(grupos, ronda) {
      // impresoras USB o de red: por el agente local; las del navegador (o si el agente falla) salen en la ventana de impresión
      const navegador = {};
      if (sesion.empresaInfo?.es_local) await cargarEquipo().catch(() => {});
      for (const [k, g] of Object.entries(grupos)) {
        g.imp = impresoraAqui(g.imp);   // 4.25: la de la categoría, como está conectada en esta computadora
        if (!porAgente(g.imp)) { navegador[k] = g; continue; }
        try { await imprimirAgente(g.imp, docComanda({ impresora: g.imp.nombre, cuenta: this.nombreEspera, ronda, salonero: this.salonero, caja: this.cfg.nombre, lineas: g.ls, nota: this.nota })); }
        catch (e) { toast('Comanda de «' + g.imp.nombre + '» no se imprimió por el agente: ' + e.message, 'err'); navegador[k] = g; }
      }
      if (!Object.keys(navegador).length) return;
      grupos = navegador;
      const hora = new Date().toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' });
      const secciones = Object.values(grupos).map(({ imp, ls }) => '<div class="pg"><h2>' + esc(String(imp.nombre).toUpperCase()) + '</h2><h3>' + esc(this.nombreEspera || 'Para llevar') + ' · ronda ' + ronda + '</h3><p>' + esc(hora) + (this.salonero ? ' · ' + esc(this.salonero) : '') + ' · ' + esc(this.cfg.nombre) + '</p><table>' + ls.map(l => '<tr><td class="q">' + esc(fmtCant(l.cantidad)) + '</td><td>' + esc(l.detalle) + (l.nota ? '<div class="o">' + esc(l.nota) + '</div>' : '') + '</td></tr>').join('') + '</table>' + (this.nota ? '<p class="o">' + esc(this.nota) + '</p>' : '') + '</div>').join('');
      const html = '<!doctype html><html><head><meta charset="utf-8"><title>Comanda</title><style>body{font-family:Arial,sans-serif;font-size:15px;width:72mm;margin:4mm auto;color:#111}h2{margin:2px 0;text-align:center;font-size:20px}h3{margin:2px 0;text-align:center;font-size:16px}p{margin:4px 0;text-align:center}table{width:100%;border-collapse:collapse}td{padding:5px 0;border-bottom:1px dotted #bbb;vertical-align:top}td.q{width:34px;font-weight:700;font-size:18px}.o{font-weight:700;font-style:italic}.pg{page-break-after:always;padding-bottom:12px}@media print{body{margin:0}}</style></head><body>' + secciones + '</body></html>';
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); window.open(u, '_blank'); setTimeout(() => URL.revokeObjectURL(u), 60000);
    },
"""
VIEJO_DOC = """
export function docComanda({ impresora, cuenta, ronda, salonero, caja, lineas, nota }) {
  const bloques = [
    { t: 'texto', x: String(impresora || 'COCINA').toUpperCase(), al: 'C', b: true, tam: 2 },
    { t: 'texto', x: (cuenta || 'Para llevar') + ' · ronda ' + ronda, al: 'C', b: true },
    { t: 'texto', x: new Date().toLocaleTimeString('es-CR', { hour: '2-digit', minute: '2-digit' }) + (salonero ? ' · ' + salonero : '') + (caja ? ' · ' + caja : ''), al: 'C' },
    { t: 'linea' },
  ];
  for (const l of lineas) bloques.push({ t: 'item', cant: String(l.cantidad), x: l.detalle, notas: l.nota ? [l.nota] : [] });
  if (nota) { bloques.push({ t: 'linea' }); bloques.push({ t: 'texto', x: nota, b: true }); }
  return { bloques };
}
"""

FALSO_API = """
const Q = globalThis.Q = globalThis.Q || { toasts: [], llamadas: [], datos: {} };
export const mock = { get: (k, d) => (k in Q.datos ? Q.datos[k] : d), set: (k, v) => { Q.datos[k] = v; return v; }, actualizar: (k, f, d) => (Q.datos[k] = f(k in Q.datos ? Q.datos[k] : d)), nextId: l => (l || []).length + 1, puedeGuardar: () => true, refrescar: async () => {} };
export const hoy = () => '2026-11-12', money = v => String(v), precioCliente = () => 0, otroImpLinea = () => ({ monto: 0, base: 0 });
export const fmt = v => String(v), fecha = v => String(v), fmtCant = v => String(v);
export const toast = (m, t) => Q.toasts.push([m, t || '']);
export const api = (url, opt) => Q.api(url, opt);
"""
FALSO_APP = "export const sesion = { empresa_id: 1, sucursal_id: null, usuario: { correo: 'caja-429@example.test' }, puede: () => true, empresaInfo: {} };\nexport const store = { productos: [] };\n"


# ------------------------------------------------------------------------------------------------ 1) _datos.js (N-1, N-2, N-8)
def test_datos_campo_y_pedir_numero_en_node(tmp_path):
    r = _node(tmp_path, """
const D = await import('./js/pages/pos/_datos.js');
const { mock } = await import('./js/api.js');
const out = {};
out.opciones = D.NUMERAR_COMANDA;
out.base = [D.TERMINAL_BASE.numerar_comanda, D.terminalCompleta({ modo: 'restaurante' }).numerar_comanda, D.terminalCompleta({ modo: 'restaurante', numerar_comanda: 'dia' }).numerar_comanda, D.terminalCompleta(null).numerar_comanda];
const R = numerar_comanda => ({ modo: 'restaurante', numerar_comanda });
out.modo = [D.modoNumerarComanda(R('dia')), D.modoNumerarComanda(R('continuo')), D.modoNumerarComanda(R('')), D.modoNumerarComanda({ modo: 'restaurante' }),
  D.modoNumerarComanda(R('raro')), D.modoNumerarComanda({ modo: 'mostrador', numerar_comanda: 'dia' }), D.modoNumerarComanda(null), D.modoNumerarComanda(undefined)];
out.numero = [D.numeroDeComanda({ numero: 153 }), D.numeroDeComanda({ numero: '7' }), D.numeroDeComanda({ numero: 0 }), D.numeroDeComanda({ numero: -3 }), D.numeroDeComanda({ numero: 2.5 }),
  D.numeroDeComanda({ numero: 'x' }), D.numeroDeComanda({}), D.numeroDeComanda(null), D.numeroDeComanda(5)];
// configuración guardada por una versión anterior (sin el campo): no numera
mock.set('pos_config', { terminales: [{ id: 1, nombre: 'Salón', modo: 'restaurante' }] });
out.vieja = D.config().terminales.map(t => [t.numerar_comanda, D.modoNumerarComanda(t)]);
D.guardarConfig({ terminales: [{ id: 1, nombre: 'Salón', modo: 'restaurante', numerar_comanda: 'continuo' }] });
out.guardada = [mock.get('pos_config').terminales[0].numerar_comanda, D.modoNumerarComanda(D.config().terminales[0])];
// pedir el número: la ruta y el cuerpo del contrato; nunca falla ni se queda esperando
const pedidos = [];
const ok = (url, opt) => { pedidos.push([url, opt.method, opt.body, opt.limite]); return Promise.resolve({ numero: 153, modo: opt.body.modo, fecha: '2026-11-12' }); };
out.ok = await D.pedirNumeroComanda('dia', ok, 200);
out.ok2 = await D.pedirNumeroComanda('continuo', ok, 200);
out.pedidos = pedidos;
out.error = await D.pedirNumeroComanda('dia', () => Promise.reject(Object.assign(new Error('Sin conexión con el servidor'), { sinConexion: true })), 200);
out.lanza = await D.pedirNumeroComanda('dia', () => { throw new Error('x'); }, 200);
out.raro = await D.pedirNumeroComanda('dia', () => Promise.resolve({ detalle: 'otra cosa' }), 200);
let t0 = Date.now(); out.nunca = await D.pedirNumeroComanda('dia', () => new Promise(() => {}), 60); out.nunca_ms = Date.now() - t0;
t0 = Date.now(); out.tarde = await D.pedirNumeroComanda('dia', () => new Promise(r => setTimeout(() => r({ numero: 9 }), 300)), 60); out.tarde_ms = Date.now() - t0;
let llamado = false; out.sin_modo = await D.pedirNumeroComanda('', () => { llamado = true; return Promise.resolve({ numero: 1 }); }, 60); out.sin_modo_llamo = llamado;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_datos.js",), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r["opciones"] == [["", "No numerar"], ["dia", "Consecutivo del día (vuelve a 1 cada día)"], ["continuo", "Consecutivo continuo"]], r
    assert r["base"] == ["", "", "dia", ""], r                                                       # N-1: por omisión no se numera
    assert r["modo"] == ["dia", "continuo", "", "", "", "", "", ""], r                               # solo restaurante con 'dia' o 'continuo'
    assert r["numero"] == [153, 7, None, None, None, None, None, None, None], r
    assert r["vieja"] == [["", ""]] and r["guardada"] == ["continuo", "continuo"], r
    assert r["ok"] == 153 and r["ok2"] == 153, r
    assert r["pedidos"] == [["/api/pos/comanda/numero", "POST", {"modo": "dia"}, 200], ["/api/pos/comanda/numero", "POST", {"modo": "continuo"}, 200]], r
    assert r["error"] is None and r["lanza"] is None and r["raro"] is None, r
    assert r["nunca"] is None and r["nunca_ms"] < 1000, r                                            # N-6: el tope corta la espera
    assert r["tarde"] is None and r["tarde_ms"] < 280, r
    assert r["sin_modo"] is None and r["sin_modo_llamo"] is False, r


# ------------------------------------------------------------------------------------------------ 2) _agente.js: docComanda (N-7)
def test_doc_comanda_con_y_sin_numero_en_node(tmp_path):
    r = _node(tmp_path, """
Date.prototype.toLocaleTimeString = () => '10:30';
const A = await import('./js/pages/pos/_agente.js');
const viejo = (function () { %s; return docComanda; })();
const casos = [
  { impresora: 'Cocina', cuenta: 'Mesa 4', ronda: 2, salonero: 'María', caja: 'Salón', lineas: [{ cantidad: 2, detalle: 'Casado', nota: 'Sin cebolla' }, { cantidad: 1, detalle: 'Sopa' }], nota: 'Rápido' },
  { impresora: '', cuenta: '', ronda: 1, salonero: '', caja: '', lineas: [{ cantidad: 1.5, detalle: 'Café' }], nota: '' },
  { impresora: 'Bar', cuenta: 'Ana', ronda: 3, salonero: null, caja: 'Barra', lineas: [] },
];
const out = { iguales: casos.map(c => JSON.stringify(A.docComanda(c)) === JSON.stringify(viejo(c))),
  iguales_nulo: casos.map(c => JSON.stringify(A.docComanda({ ...c, numero: null })) === JSON.stringify(viejo(c)) && JSON.stringify(A.docComanda({ ...c, numero: 0 })) === JSON.stringify(viejo(c))) };
const con = A.docComanda({ ...casos[0], numero: 153 });
out.primero = con.bloques[0];
out.resto_igual = JSON.stringify(con.bloques.slice(1)) === JSON.stringify(viejo(casos[0]).bloques);
out.texto = [A.textoNumeroComanda(153), A.textoNumeroComanda(1), A.textoNumeroComanda(null), A.textoNumeroComanda(0)];
console.log(JSON.stringify(out));
process.exit(0);
""" % VIEJO_DOC.replace("export function", "function"), archivos=("pages/pos/_agente.js",), falsos={"api.js": FALSO_API})
    assert r["iguales"] == [True, True, True] and r["iguales_nulo"] == [True, True, True], r      # sin número, IGUAL al de la 4.28
    assert r["primero"] == {"t": "texto", "x": "COMANDA N.º 153", "al": "C", "b": True, "tam": 2}, r   # arriba y en grande
    assert r["resto_igual"] is True, r
    assert r["texto"] == ["COMANDA N.º 153", "COMANDA N.º 1", "", ""], r


# ------------------------------------------------------------------------------------------------ 3) caja.js en Node (N-5, N-6, N-7)
ARNES_CAJA = """
Date.prototype.toLocaleTimeString = () => '10:30';
Date.prototype.toISOString = function () { return '2026-11-12T16:00:00.000Z'; };
const D = await import('./js/pages/pos/_datos.js');
const A = await import('./js/pages/pos/_agente.js');
const API = await import('./js/api.js');
Object.assign(globalThis, await import('./js/pages/pos/_fusion.js'));   /* 4.31: la caja usa el módulo de la misma mesa */
const Q = globalThis.Q;
Object.assign(globalThis, { mock: API.mock, toast: (m, t) => { Q.log.push('aviso'); Q.toasts.push([m, t || '']); }, sesion: { usuario: { correo: 'caja-429@example.test' }, empresaInfo: {} },
  api: (u, o) => Q.api(u, o), modoNumerarComanda: D.modoNumerarComanda,
  pedirNumeroComanda: (modo, pedir) => D.pedirNumeroComanda(modo, pedir, 80),   /* el mismo tope, más corto para la prueba */
  docComanda: A.docComanda, textoNumeroComanda: A.textoNumeroComanda, cargarEquipo: async () => {}, impresoraAqui: x => x,
  porAgente: imp => imp.conexion === 'usb', imprimirAgente: async (imp, doc) => { Q.log.push('agente:' + imp.nombre); Q.docs.push(doc); },
  esc: s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])), fmtCant: v => String(v),
  Blob: class { constructor(p) { Q.htmls.push(p.join('')); } }, URL: { createObjectURL: () => 'blob:x', revokeObjectURL() {} }, window: { open() {} }, setTimeout: globalThis.setTimeout });
const C = { %(computadas)s };
const NUEVO = { %(nuevos)s };
const VIEJO = { %(viejos)s };
const espera = ms => new Promise(r => setTimeout(r, ms));
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' }, BAR = { id: 'b', nombre: 'Bar', conexion: 'navegador' };
function caja(M, numerar, estado) {
  Q.datos = {}; Q.toasts = []; Q.log = []; Q.docs = []; Q.htmls = []; Q.pedidos = 0;
  const vm = Object.assign({ vista: 'venta', mesaActual: { id: 4, nombre: 'Mesa 4' }, esperaId: null, nombreEspera: 'Mesa 4', rapida: false, espera: [], nota: 'Rápido', clienteId: null,
    servicio: false, servicioPctCuenta: null, parteNueva: false, salonero: 'María', totales: { total: 1000 },
    cfg: { id: 7, nombre: 'Salón', modo: 'restaurante', imprimir_comanda: true, ...(numerar === undefined ? {} : { numerar_comanda: numerar }) },
    lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 2, nota: 'Sin cebolla', enviado: null, ronda: 0 }, { producto_id: 2, detalle: 'Cerveza', cantidad: 1, enviado: null, ronda: 0 }],
    destinoDe: l => (l.producto_id === 1 ? COCINA : BAR), $nextTick: f => f && f(), $refs: {} }, estado || {});
  for (const [n, f] of Object.entries(C)) Object.defineProperty(vm, n, { get: f.bind(vm) });
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  const imp = vm.imprimirComanda, per = vm.persistirCuenta;
  vm.imprimirComanda = (...a) => { Q.log.push('imprimir'); return imp(...a); };
  vm.persistirCuenta = (...a) => { Q.log.push('guardar'); return per(...a); };
  return vm;
}
const foto = vm => ({ log: Q.log, toasts: Q.toasts, docs: Q.docs, htmls: Q.htmls, lineas: vm.lineas, guardadas: (Q.datos.pos_espera || []).map(x => x.lineas), esperaId: vm.esperaId });
"""


def _arnes_caja():
    k = _js("pages/pos/caja.js")
    linea = lambda nombre: _tramo(k, "    " + nombre, "\n").strip().split("   /*")[0].split("   //")[0].strip().rstrip(",")
    computadas = [linea("esRestaurante() {"), linea("numerarComanda() {")]
    persistir = _tramo(k, "    persistirCuenta(devolverId) {", "    ponerEnEspera() {").strip().rstrip(",")
    nuevos = [_metodo(k, "enviarComanda() {"), _metodo(k, "comandaNumerada(modo,"), _metodo(k, "ponerNumeroComanda(e, n) {"), _metodo(k, "async imprimirComanda(grupos, ronda, datos) {"), persistir]
    viejos = [VIEJO_ENVIAR.strip().rstrip(","), VIEJO_IMPRIMIR.strip().rstrip(","), persistir]
    return ARNES_CAJA % {"computadas": ",\n".join(computadas), "nuevos": ",\n".join(nuevos), "viejos": ",\n".join(viejos)}


def _correr_caja(tmp_path, guion):
    return _node(tmp_path, _arnes_caja() + guion, archivos=("pages/pos/_datos.js", "pages/pos/_agente.js", "pages/pos/_fusion.js"), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})


def test_caja_sin_numerar_igual_que_antes_en_node(tmp_path):
    """N-1 / N-6: la caja que NO numera (sin el campo, con '' o en una caja vieja) hace lo mismo, en el mismo orden y en el mismo
    momento que la 4.28: sin esperas, sin pedir número, el mismo documento al agente y la misma página para el navegador."""
    r = _correr_caja(tmp_path, """
const out = {};
for (const [nombre, numerar] of [['sin_campo', undefined], ['vacio', ''], ['raro', 'semanal']]) {
  Q.api = () => { Q.pedidos++; return Promise.resolve({ numero: 1 }); };
  const v = caja(VIEJO, numerar); const rv = v.enviarComanda(); const sync_v = { log: [...Q.log], lineas: JSON.parse(JSON.stringify(v.lineas)) }; await espera(30); const fv = JSON.parse(JSON.stringify(foto(v)));
  const n = caja(NUEVO, numerar); const rn = n.enviarComanda(); const sync_n = { log: [...Q.log], lineas: JSON.parse(JSON.stringify(n.lineas)) }; await espera(30); const fn = JSON.parse(JSON.stringify(foto(n)));
  out[nombre] = { igual_sync: JSON.stringify(sync_v) === JSON.stringify(sync_n), igual: JSON.stringify(fv) === JSON.stringify(fn), devuelve: [rv === undefined, rn === undefined], pedidos: Q.pedidos, log: fn.log, toasts: fn.toasts, docs: fn.docs.length, htmls: fn.htmls.length, comanda: fn.lineas.map(l => 'comanda' in l) };
}
console.log(JSON.stringify(out));
process.exit(0);
""")
    for nombre in ("sin_campo", "vacio", "raro"):
        x = r[nombre]
        assert x["igual_sync"] and x["igual"], (nombre, x)
        assert x["devuelve"] == [True, True] and x["pedidos"] == 0, (nombre, x)
        assert x["log"] == ["imprimir", "agente:Cocina", "guardar", "aviso"], (nombre, x)
        assert x["toasts"] == [["Comanda 1 enviada a Cocina, Bar", "ok"]] and x["docs"] == 1 and x["htmls"] == 1 and x["comanda"] == [False, False], (nombre, x)


def test_caja_numerada_en_node(tmp_path):
    """N-5 a N-7: con numeración, en el acto quedan las líneas enviadas y la cuenta guardada (nada espera); un segundo toque no
    manda otra vez; llega el número, se pone en cada línea (en pantalla y en la cuenta guardada) y la comanda sale con el MISMO
    número en las dos impresoras; el aviso lo dice."""
    r = _correr_caja(tmp_path, """
const out = {};
let pedidos = [];
Q.api = (u, o) => { Q.pedidos++; pedidos.push([u, o.method, o.body]); return new Promise(res => setTimeout(() => res({ numero: 153, modo: 'dia', fecha: '2026-11-12' }), 20)); };
const vm = caja(NUEVO, 'dia');
const p = vm.enviarComanda();
out.al_instante = { log: [...Q.log], enviadas: vm.lineas.map(l => [l.enviado, l.ronda, l.comanda === undefined]), guardada: (Q.datos.pos_espera || []).length, esperaId: vm.esperaId, promesa: typeof (p && p.then) };
vm.enviarComanda();                                         // segundo toque mientras espera
out.segundo = Q.toasts.slice(-1)[0];
out.numero = await p;
await espera(30);
out.final = { log: Q.log, pedidos, lineas: vm.lineas.map(l => l.comanda), guardadas: Q.datos.pos_espera[0].lineas.map(l => l.comanda), toasts: Q.toasts,
  agente: Q.docs.map(d => d.bloques[0]), html: Q.htmls.map(h => (h.match(/<h1[^>]*>([^<]*)<\\/h1>/) || [])[1] || null), h3: Q.htmls.map(h => (h.match(/<h3>([^<]*)<\\/h3>/) || [])[1]) };
// el mismo envío con «continuo» pide con ese modo
Q.api = (u, o) => { pedidos = [o.body]; return Promise.resolve({ numero: 8, modo: 'continuo', fecha: null }); };
const vc = caja(NUEVO, 'continuo'); out.continuo = [await vc.enviarComanda(), pedidos, vc.lineas.map(l => l.comanda)];
// sin imprimir la comanda (interruptor apagado): igual lleva número en las líneas y en el aviso
Q.api = () => Promise.resolve({ numero: 21 });
const vs = caja(NUEVO, 'dia'); vs.cfg.imprimir_comanda = false; out.sin_imprimir = [await vs.enviarComanda(), Q.docs.length, Q.htmls.length, vs.lineas.map(l => l.comanda), Q.toasts.slice(-1)[0]];
console.log(JSON.stringify(out));
process.exit(0);
""")
    a = r["al_instante"]
    assert a["log"] == ["guardar"] and a["guardada"] == 1 and a["esperaId"] == 1 and a["promesa"] == "function", r
    assert a["enviadas"] == [["2026-11-12T16:00:00.000Z", 1, True], ["2026-11-12T16:00:00.000Z", 1, True]], r
    assert r["segundo"] == ["No hay platos nuevos por enviar", "err"], r                    # no se envía dos veces
    assert r["numero"] == 153, r
    f = r["final"]
    assert f["pedidos"] == [["/api/pos/comanda/numero", "POST", {"modo": "dia"}]], r                 # un solo número por envío
    assert f["lineas"] == [153, 153] and f["guardadas"] == [153, 153], r
    assert ["Comanda N.º 153 enviada a Cocina, Bar", "ok"] in f["toasts"], r
    assert f["agente"] == [{"t": "texto", "x": "COMANDA N.º 153", "al": "C", "b": True, "tam": 2}], r     # Cocina (directa)
    assert f["html"] == ["COMANDA N.º 153"] and f["h3"] == ["Mesa 4 · ronda 1"], r                         # Bar (navegador)
    assert f["log"].index("guardar") < f["log"].index("imprimir"), r
    assert r["continuo"] == [8, [{"modo": "continuo"}], [8, 8]], r
    assert r["sin_imprimir"] == [21, 0, 0, [21, 21], ["Comanda N.º 21 enviada a Cocina, Bar", "ok"]], r


def test_caja_numerada_sin_respuesta_en_node(tmp_path):
    """N-6: si el servidor no contesta a tiempo o da error, la comanda sale igual (mismo documento que la 4.28) y sin número, con un
    aviso corto. Si el cobro (o el cambio de mesa) termina antes de que llegue el número, la comanda sale con los datos de la cuenta
    que se envió y la cuenta cobrada no se resucita; si la cuenta se recargó en pantalla, la copia también recibe el número."""
    r = _correr_caja(tmp_path, """
const out = {};
for (const [nombre, f] of [['nunca', () => new Promise(() => {})], ['error', () => Promise.reject(new Error('Error del servidor (500)'))], ['sin_ruta', () => Promise.reject(Object.assign(new Error('Not Found'), { status: 404 }))]]) {
  Q.api = f; const vm = caja(NUEVO, 'dia'); const n = await vm.enviarComanda(); await espera(20);
  const hn = Q.htmls.slice(), dn = Q.docs.slice(), tn = Q.toasts.slice(), ln = vm.lineas.map(l => 'comanda' in l);
  const vv = caja(VIEJO); vv.enviarComanda(); await espera(20);
  out[nombre] = { numero: n, mismo_html: JSON.stringify(hn) === JSON.stringify(Q.htmls), mismo_doc: JSON.stringify(dn) === JSON.stringify(Q.docs), toasts: tn, comanda: ln };
}
// el cobro termina antes del número: la pantalla quedó limpia y la cuenta se cerró
let soltar; Q.api = () => new Promise(res => { soltar = res; });
const vm = caja(NUEVO, 'dia'); const p = vm.enviarComanda();
const cuenta = vm.esperaId; vm.lineas = []; vm.esperaId = null; vm.nombreEspera = ''; vm.nota = ''; vm.salonero = ''; vm.mesaActual = null; Q.datos.pos_espera = [];
await espera(5); soltar({ numero: 40 }); out.cobrada = { numero: await p, cuenta, guardadas: Q.datos.pos_espera.length, h3: Q.htmls.map(h => (h.match(/<h3>([^<]*)<\\/h3>/) || [])[1]), notas: Q.htmls.map(h => h.includes('Rápido')), salonero: Q.docs.map(d => d.bloques[3].x), toasts: Q.toasts.slice(-1) };
// la cuenta se recargó en pantalla (otra copia de las líneas) mientras llegaba el número
Q.api = () => new Promise(res => { soltar = res; });
const vr = caja(NUEVO, 'dia'); const pr = vr.enviarComanda();
vr.lineas = vr.lineas.map(x => ({ ...x }));
await espera(5); soltar({ numero: 41 }); await pr; out.recargada = [vr.lineas.map(l => l.comanda), Q.datos.pos_espera[0].lineas.map(l => l.comanda)];
// otra cuenta en pantalla (se cambió de mesa): no recibe el número
Q.api = () => new Promise(res => { soltar = res; });
const vo = caja(NUEVO, 'dia'); const po = vo.enviarComanda();
const otra = [{ producto_id: 9, detalle: 'Flan', cantidad: 1, enviado: '2026-11-12T15:00:00.000Z', ronda: 1 }]; vo.lineas = otra; vo.esperaId = 99;
await espera(5); soltar({ numero: 42 }); await po; out.otra = [vo.lineas.map(l => l.comanda === undefined), Q.datos.pos_espera[0].lineas.map(l => l.comanda)];
console.log(JSON.stringify(out));
process.exit(0);
""")
    for nombre in ("nunca", "error", "sin_ruta"):
        x = r[nombre]
        assert x["numero"] is None and x["mismo_html"] and x["mismo_doc"] and x["comanda"] == [False, False], (nombre, x)
        assert x["toasts"] == [["Comanda 1 enviada a Cocina, Bar sin número: el servidor no respondió a tiempo", "err"]], (nombre, x)
    c = r["cobrada"]
    assert c["numero"] == 40 and c["cuenta"] == 1 and c["guardadas"] == 0, r                       # no se resucita la cuenta cobrada
    assert c["h3"] == ["Mesa 4 · ronda 1"] and c["notas"] == [True] and c["salonero"] == ["10:30 · María · Salón"], r
    assert c["toasts"] == [["Comanda N.º 40 enviada a Cocina, Bar", "ok"]], r
    assert r["recargada"] == [[41, 41], [41, 41]], r
    assert r["otra"] == [[True], [42, 42]], r


def test_caja_numerada_abre_la_ventana_del_navegador_en_el_toque_en_node(tmp_path):
    """En la web, la ventana para las impresoras «del navegador» se abre en el mismo toque (fuera del gesto el navegador puede
    bloquearla) y la comanda se escribe en ella cuando llega el número; si todo va por el agente no se abre, y en el programa de
    escritorio sigue como estaba."""
    r = _correr_caja(tmp_path, """
const out = {};
const abiertas = [];
const ventana = () => { const v = { closed: false, html: '', cerrada: false, document: { open() {}, write(h) { v.html += h; }, close() {} }, close() { v.cerrada = true; } }; return v; };
globalThis.window.open = (u, d) => { const v = ventana(); abiertas.push({ u, d, v }); return v; };
let soltar; Q.api = () => new Promise(res => { soltar = res; });
const vm = caja(NUEVO, 'dia'); const p = vm.enviarComanda();
out.en_el_toque = abiertas.map(a => [a.u, a.d]);                  // antes de que llegue el número
await espera(5); soltar({ numero: 153 }); await p; await espera(5);
out.despues = { abiertas: abiertas.length, h1: (abiertas[0].v.html.match(/<h1[^>]*>([^<]*)<\\/h1>/) || [])[1] || null, htmls: Q.htmls.length };
// todo por el agente: no se abre ninguna ventana
abiertas.length = 0; Q.api = () => Promise.resolve({ numero: 154 });
const va = caja(NUEVO, 'dia'); va.destinoDe = () => ({ id: 'c', nombre: 'Cocina', conexion: 'usb' }); await va.enviarComanda(); await espera(5);
out.agente = abiertas.length;
// sin número (el servidor no contesta): la ventana abierta en el toque recibe la comanda igual, sin número
abiertas.length = 0; Q.api = () => Promise.reject(new Error('Error del servidor (500)'));
const vs = caja(NUEVO, 'dia'); await vs.enviarComanda(); await espera(5);
out.sin_numero = [abiertas.length, abiertas[0] && abiertas[0].u, abiertas[0] && abiertas[0].v.html.includes('<h2>BAR</h2>'), abiertas[0] && abiertas[0].v.html.includes('<h1')];
// programa de escritorio: como estaba (se abre al final, con la página)
abiertas.length = 0; globalThis.sesion.empresaInfo = { es_local: true }; Q.api = () => new Promise(res => { soltar = res; });
const vl = caja(NUEVO, 'dia'); const pl = vl.enviarComanda(); out.local_en_el_toque = abiertas.length;
await espera(5); soltar({ numero: 155 }); await pl; await espera(5); out.local_final = abiertas.map(a => a.u);
console.log(JSON.stringify(out));
process.exit(0);
""")
    assert r["en_el_toque"] == [["", "_blank"]], r
    assert r["despues"] == {"abiertas": 1, "h1": "COMANDA N.º 153", "htmls": 1}, r
    assert r["agente"] == 0, r
    assert r["sin_numero"] == [1, "", True, False], r
    assert r["local_en_el_toque"] == 0 and r["local_final"] == ["blob:x"], r


def test_guardar_desde_otro_equipo_conserva_el_numero_en_node(tmp_path):
    """Un equipo cuya copia de la cuenta tiene las líneas enviadas sin el número (las cargó antes de que llegara) no lo borra al
    guardar: el número se conserva como las marcas de la cocina."""
    r = _correr_caja(tmp_path, """
const env = '2026-11-12T15:00:00.000Z';
const vm = caja(NUEVO, 'dia', { esperaId: 1, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 2, nota: 'Sin cebolla', enviado: env, ronda: 1 }, { producto_id: 3, detalle: 'Flan', cantidad: 1, enviado: null, ronda: 0 }] });
Q.datos.pos_espera = [{ id: 1, nombre: 'Mesa 4', mesa_id: 4, terminal_id: 7, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 2, nota: 'Sin cebolla', enviado: env, ronda: 1, comanda: 153, listo: 'x' }] }];
vm.persistirCuenta();
console.log(JSON.stringify(Q.datos.pos_espera[0].lineas.map(l => [l.detalle, l.comanda === undefined ? null : l.comanda, l.listo || null])));
process.exit(0);
""")
    assert r == [["Casado", 153, "x"], ["Flan", None, None]], r


def test_caja_textos():
    k = _js("pages/pos/caja.js")
    assert "import { modoNumerarComanda, pedirNumeroComanda } from './_datos.js';" in k and "import { textoNumeroComanda } from './_agente.js';" in k
    assert "    numerarComanda() { return modoNumerarComanda(this.cfg); }," in _tramo(k, "  computed: {", "  methods: {")
    env = _metodo(k, "enviarComanda() {")
    # la caja que no numera: las mismas tres líneas de la 4.28, en el mismo orden
    viejas = [x.strip() for x in VIEJO_ENVIAR.strip().splitlines()[1:-1]]
    # 4.39 (séptima vuelta): la guarda de la sexta vuelta (no guardar la parte de un cobro) se quitó con la comanda de la parte de la venta
    # rápida («Cobrar estos platos» solo se ofrece con mesa): la línea que guarda la cuenta vuelve a ser la de la 4.28, tal cual
    assert sum("if (this.esRestaurante) this.persistirCuenta();   // 4.6:" in x for x in viejas) == 1 and "!this.cobroParcial" not in env
    for x in viejas:
        assert x in env, x
    assert env.index("if (modo) return this.comandaNumerada(") < env.index("this.imprimirComanda(grupos, ronda);") < env.index("this.persistirCuenta();")
    assert "await" not in env and "async enviarComanda" not in k                                     # sigue sin esperar
    assert "pedirNumeroComanda(modo, api, 3000)" in _metodo(k, "comandaNumerada(modo,")
    imp = _metodo(k, "async imprimirComanda(grupos, ronda, datos) {")
    assert "this.nombreEspera" not in imp.split("const navegador")[1] and "numero })" in imp            # datos tomados al empezar
    assert "'<div class=\"pg\">' + (numero ? '<h1 style=\"margin:0 0 4px;text-align:center;font-size:30px\">' + esc(textoNumeroComanda(numero)) + '</h1>' : '') + '<h2>'" in imp
    # la página del navegador: mismo estilo que antes (el número va con su estilo propio, solo cuando hay número)
    estilo = re.search(r"<style>.*?</style>", VIEJO_IMPRIMIR).group(0)
    assert estilo in imp
    # el botón y F8 siguen llamando igual
    assert '<button class="btn sec" @click="enviarComanda" :disabled="!lineas.some(l => !l.enviado)"' in k
    assert "if (this.esRestaurante && this.vista === 'venta' && !this.pago) this.enviarComanda(); }" in k
    assert "if (this.esRestaurante && this.lineas.some(l => !l.enviado)) { try { this.enviarComanda(); } catch {} }" in k


# ------------------------------------------------------------------------------------------------ 4) configuracion.js (N-2)
def test_configuracion_selector():
    c = _js("pages/pos/configuracion.js")
    assert "import { NUMERAR_COMANDA } from './_datos.js';" in c
    data = _tramo(c, "  data() {", "  computed: {")
    assert "IMPRESORAS_DE_LA_WEB, NUMERAR_COMANDA };" in data
    rest = _tramo(c, '<div id="cfg-restaurante"', '<div id="cfg-mesas"')
    campo = ('<Field label="Numerar las comandas" help="Cada envío sale con su número, el mismo en cocina y en bar.">'
             '<select v-model="t.numerar_comanda"><option v-for="x in NUMERAR_COMANDA" :key="x[0]" :value="x[0]">{{x[1]}}</option></select></Field>')
    assert campo in rest and rest.index('label="Abrir la comanda para imprimir al enviarla"') < rest.index(campo)   # junto a lo de la comanda
    assert "this.cfg.terminales.map(({ modificadores_txt, saloneros_txt, clave_nueva, quitar_clave, ...t }) => t)" in c   # se guarda con la caja


# ------------------------------------------------------------------------------------------------ 5) cocina.js (N-7)
FALSO_DATOS_COCINA = """
export const enEspera = () => globalThis.Q.cuentas, impresorasComanda = () => [], categorias = () => [], terminales = () => [], terminalActual = () => null;
export const impresoraDe = p => globalThis.Q.imp(p);
"""
FALSO_AGENTE_COCINA = """
export { docComanda, textoNumeroComanda } from './_agente_real.js';
export const porAgente = imp => imp.conexion === 'usb', cargarEquipo = async () => {}, impresoraAqui = x => x;
export const imprimirAgente = async (imp, doc) => { globalThis.Q.docs.push(doc); };
"""


def test_cocina_muestra_y_reimprime_el_mismo_numero_en_node(tmp_path):
    r = _node(tmp_path, """
Date.prototype.toLocaleTimeString = () => '10:30';
const Q = globalThis.Q = { toasts: [], datos: {}, docs: [], htmls: [] };
globalThis.localStorage = { getItem: () => null, setItem() {} };
globalThis.confirm = () => true; globalThis.Blob = class { constructor(p) { Q.htmls.push(p.join('')); } };
globalThis.URL = { createObjectURL: () => 'blob:x', revokeObjectURL() {} }; globalThis.window = { open() {} };
const app = await import('./js/app.js'); app.store.productos = [{ id: 1, nombre: 'Casado' }, { id: 2, nombre: 'Cerveza' }];
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' }, BAR = { id: 'b', nombre: 'Bar', conexion: 'navegador' };
Q.imp = p => (p.id === 1 ? COCINA : BAR);
const hace = new Date(Date.now() - 60000).toJSON();
Q.cuentas = [{ id: 5, nombre: 'Mesa 4', mesa_id: 4, salonero: 'María', lineas: [
  { producto_id: 1, detalle: 'Casado', cantidad: 2, enviado: hace, ronda: 1, comanda: 153 }, { producto_id: 2, detalle: 'Cerveza', cantidad: 1, enviado: hace, ronda: 1, comanda: 153 },
  { producto_id: 1, detalle: 'Flan', cantidad: 1, enviado: hace, ronda: 2 }] }];
Q.datos.pos_espera = Q.cuentas;
const K = (await import('./js/pages/pos/cocina.js'));
const C = K.default;
const vm = Object.assign({}, C.data.call({}));
for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm) });
for (const [k, f] of Object.entries(C.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f;
const out = { tickets: vm.tickets.map(t => [t.ronda, t.comanda]), puro: [K.numeroDeRonda([{ comanda: 7 }]), K.numeroDeRonda([{}, { comanda: '9' }]), K.numeroDeRonda([{ comanda: 0 }]), K.numeroDeRonda([]), K.numeroDeRonda(null)] };
const t1 = vm.tickets.find(t => t.ronda === 1), t2 = vm.tickets.find(t => t.ronda === 2);
await vm.imprimir(t1); await vm.imprimir(t1);                 // imprimir y reimprimir: el mismo número, sin pedir otro
out.docs = Q.docs.map(d => d.bloques[0].x); out.htmls = Q.htmls.map(h => (h.match(/<h1[^>]*>([^<]*)<\\/h1>/) || [])[1] || null);
Q.docs = []; Q.htmls = []; await vm.imprimir(t2);
out.sin = [Q.docs.map(d => d.bloques[0].x), Q.htmls.length];
vm.preparado(t1); vm.preparado(t2); out.toasts = Q.toasts.slice(-2);
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/cocina.js",), falsos={"api.js": FALSO_API.replace("const Q = globalThis.Q = globalThis.Q || { toasts: [], llamadas: [], datos: {} };", "const Q = globalThis.Q;"), "app.js": FALSO_APP,
                                               "pages/pos/_datos.js": FALSO_DATOS_COCINA, "pages/pos/_agente.js": FALSO_AGENTE_COCINA, "pages/pos/_agente_real.js": _js("pages/pos/_agente.js")})
    assert sorted(r["tickets"]) == [[1, 153], [2, None]], r
    assert r["puro"] == [7, 9, None, None, None], r
    assert r["docs"] == ["COMANDA N.º 153", "COMANDA N.º 153"] and r["htmls"] == ["COMANDA N.º 153", "COMANDA N.º 153"], r
    assert r["sin"] == [["COCINA"], 0], r                                                             # sin número, como antes
    assert r["toasts"] == [["Comanda N.º 153 de Mesa 4 lista", "ok"], ["Comanda 2 de Mesa 4 lista", "ok"]], r


def test_cocina_textos():
    k = _js("pages/pos/cocina.js")
    num = '<span v-if="t.comanda" class="kds-num" style="display:block;font-size:22px;font-weight:800;line-height:1.1" title="Número de comanda">N.º {{t.comanda}}</span><b>{{titulo(t)}}</b>'
    assert k.count(num) == 2                                                                          # en Columnas y en Por rondas
    assert "{{t.comanda ? 'N.º ' + t.comanda + ' · ' : ''}}comanda {{t.ronda}}" in k                 # entregadas
    assert "comanda: numeroDeRonda(lineas)," in _tramo(k, "    tickets() {", "    ticketsRondas()")
    imp = _tramo(k, "    async imprimir(t) {", "    async refrescar()")
    assert "nota: v.nota || '', numero: t.comanda }" in imp and "esc(textoNumeroComanda(t.comanda))" in imp
    assert "api(" not in imp                                                                          # reimprimir no pide otro número


# ------------------------------------------------------------------------------------------------ 6) sintaxis y plantillas (N-8)
TOCADOS = ("pages/pos/_datos.js", "pages/pos/caja.js", "pages/pos/configuracion.js", "pages/pos/_agente.js", "pages/pos/cocina.js")


def test_sintaxis_y_plantillas(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    for rel in TOCADOS:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in ("pages/pos/caja.js", "pages/pos/configuracion.js", "pages/pos/cocina.js")])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0, saltadas = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) { saltadas++; continue; }
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, saltadas, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] == 3 and r["saltadas"] == 0 and r["malos"] == [], r


def test_nombres_de_plantilla_y_manejadores():
    """Todo nombre nuevo que usan las plantillas existe; ningún manejador en línea con «if»; los finales de línea no se mezclaron."""
    c, k, coc = _js("pages/pos/configuracion.js"), _js("pages/pos/caja.js"), _js("pages/pos/cocina.js")
    assert "NUMERAR_COMANDA" in _tramo(c, "  data() {", "  computed: {")
    for txt in (c, k, coc):
        assert re.search(r"@click=\"[^\"]*\bif\b", txt) is None
    for rel in TOCADOS:
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") == 0 or b.count(b"\r\n") == b.count(b"\n"), rel
