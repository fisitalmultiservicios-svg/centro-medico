# -*- coding: utf-8 -*-
"""Hotel, reportes y consultas de solo lectura (H3, H8, H9, H10, H14a, H14b y H21).
- H3   disponibilidadPorTipo: una sola cuenta de «libres por categoría»; la reserva sin habitación resta en la categoría que pidió.
- H8   vuelos y traslado en la reserva, el grupo, la tarjeta de registro, Recepción y el reporte Transporte.
- H9   Entradas y Salidas con filtros (nacionalidad, plan, piso, grupo, origen); Salidas elige sus columnas por clave.
- H10  Ocupación por plan y piso.   H14a Mano corriente.   H14b Facturación del día (los cargos guardan la fecha de la factura).
- H21  Reservaciones › Histórico: criterios que se combinan y quedan en la dirección, y la historia de una habitación.
Tanda 2: H4 (calendario de 1 a 60 días, fila por tipo y pie con la cuenta única), H15 (marcas de la barra, leyenda y reservas sin
habitación), H6 (bloqueos en lote) y H7 (tablero: indicadores, alertas y tareas).
Las pruebas de texto corren siempre; las de cálculo corren las funciones de verdad en Node (se saltan si el equipo no lo tiene)."""
import json
import pathlib
import re
import shutil
import subprocess
import types

import pytest

RAIZ = pathlib.Path(__file__).resolve().parent.parent
JS = RAIZ / "app" / "static" / "js"
HOTEL = JS / "pages" / "hotel"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
NUEVOS = ("pronostico_tipo", "ocupacion_plan", "mano_corriente", "facturacion_dia", "transporte")


def _js(*partes):
    return (JS / pathlib.Path(*partes)).read_text(encoding="utf-8")


def _funcion(src, nombre):
    """El texto de una función exportada de un módulo: desde su «export function» hasta la siguiente declaración de primer nivel."""
    i = src.index("export function " + nombre + "(")
    m = re.search(r"^(export |const |function |// ----)", src[i + 10:], re.M)
    return src[i:i + 10 + m.start()] if m else src[i:]


# ============================================================================= texto: lo que debe decir cada archivo
def test_h3_disponibilidad_por_tipo_es_la_unica_cuenta():
    d = _js("pages/hotel/_datos.js")
    f = _funcion(d, "disponibilidadPorTipo")
    assert f.startswith("export function disponibilidadPorTipo(fecha, lista, opts = {}) {")
    assert "ent(r.categoria_id)" in f and "e.sin_asignar++" in f                         # sin habitación: cuenta en la categoría que pidió
    assert "fecha <= hoyHotel()" in f and "['en_casa', 'salio'].includes(r.estado)" in f   # real: solo lo que durmió, y solo hasta hoy
    assert "h.activa !== false" in f and "retenido: 0" in f and "opts.excluir" in f
    assert "e.libres = e.total - e.ocupadas - e.bloqueadas - e.sin_asignar" in f         # puede dar negativo: sobreventa
    # ocupacionDia no se tocó (la usan ADR, RevPAR, ICT y el comparativo) y la nueva va justo después
    vieja = _funcion(d, "ocupacionDia")
    assert "const ocupadas = new Set(rs.filter(r => r.tipo !== 'bloqueo' && (ocupa(r) || r.estado === 'salio') && r.llegada <= fecha && fecha < r.salida && r.habitacion_id).map(r => r.habitacion_id));" in vieja
    assert "return { total: n, ocupadas: oc, bloqueadas: bl, libres: n - oc - bl, pct: n ? Math.round(oc / n * 100) : 0 };" in vieja
    assert d.index("export function ocupacionDia(") < d.index("export function disponibilidadPorTipo(") < d.index("// ---- huéspedes ----")


def test_h8_vuelos_traslado_y_paquete_del_cierre():
    d = _js("pages/hotel/_datos.js")
    nueva = _funcion(d, "reservaNueva")
    for campo in ("vuelo_llegada", "hora_vuelo_llegada", "vuelo_salida", "hora_vuelo_salida", "traslado", "traslado_nota"):
        assert campo + ": ''" in nueva, campo
    assert "export const TRASLADOS = [['', 'No necesita'], ['hotel', 'Lo da el hotel'], ['servicio', 'Servicio contratado'], ['propio', 'Por su cuenta']];" in d
    assert "export function nombrePlan(id, cfg) {" in d and "kv('Vuelo de llegada'," in d and "kv('Vuelo de salida'," in d
    # el paquete del cierre: la clave en PAQUETE_CIERRE y su línea en cierre.js (una sin la otra no imprime nada)
    claves = re.findall(r"\['(\w+)', '[^']*'\]", re.search(r"export const PAQUETE_CIERRE = (\[.*\]);", d).group(1))
    assert claves[:2] == ["informe_diario", "mano_corriente"] and "transporte" in claves and len(claves) == len(set(claves))
    c = _js("pages/hotel/cierre.js")
    assert "if (claves.includes('mano_corriente')) rep(unDia, 'mano_corriente', 'Mano corriente');" in c
    assert "if (claves.includes('transporte')) rep(dosDias, 'transporte', 'Transporte de hoy y de mañana');" in c
    for k in claves:
        assert "claves.includes('" + k + "')" in c, k
    # el servidor imprime el resumen más N secciones de la pantalla y un reporte admite hasta M secciones: si el paquete crece
    # (una clave más en PAQUETE_CIERRE), hay que subir esos dos topes también o la última sección no sale en el PDF
    tope = int(re.search(r"secciones=\[sec_resumen, \*data\.secciones\[:(\d+)\]\]", (RAIZ / "app" / "main.py").read_text(encoding="utf-8")).group(1))
    maximo = int(re.search(r"secciones: list\[SeccionIn\] = Field\(default_factory=list, max_length=(\d+)\)", (RAIZ / "app" / "reportes.py").read_text(encoding="utf-8")).group(1))
    assert len(claves) <= tope and tope + 1 <= maximo, (len(claves), tope, maximo)
    # la firma solo creció al final: el cierre la sigue llamando con cuatro argumentos
    assert "definirReportesHotel(this.cfg, this.lista, d, sumarDias(d, 1)), unDia = definirReportesHotel(this.cfg, this.lista, d, d);" in c


def test_reportes_nuevos_filtros_y_columnas_por_clave():
    r = _js("pages/hotel/reportes.js")
    assert "export function definirReportesHotel(cfg, lista, desde, hasta, filtros = {}) {" in r
    for txt in ("pronostico_tipo: { nombre: 'Pronóstico por tipo de habitación'", "ocupacion_plan: { nombre: 'Ocupación por plan y piso'", "mano_corriente: { nombre: 'Mano corriente'",
                "facturacion_dia: { nombre: 'Facturación del día'", "transporte: { nombre: 'Transporte (llegadas y salidas)'"):
        assert r.count(txt) == 1, txt
    assert "key: 'cat_' + c.id" in r and "disponibilidadPorTipo(f, todas, { modo: 'proyectado', habs, cfg })" in r and "f <= hoyS ? disponibilidadPorTipo(f, todas, { modo: 'real', habs, cfg }) : null" in r
    assert "a.piso.localeCompare(b.piso, 'es', { numeric: true })" in r                    # ocupación por plan: ordenada por piso
    lineas = {k: next(x for x in r.split("\n") if x.strip().startswith(k + ": {")) for k in ("llegadas", "salidas", "en_casa")}
    lineas["ocupacion_plan"] = r[r.index("        ocupacion_plan: {"):r.index("        cumpleanos: {")]
    assert all("filtrable: true" in lineas[k] and ".filter(pasa)" in lineas[k] for k in ("llegadas", "salidas", "ocupacion_plan"))
    assert "filtrable" not in lineas["en_casa"]
    # Salidas ya no arma sus columnas por posición: Saldo y Estado siguen al final aunque Entradas gane columnas
    assert "colsRes.slice(" not in r and "colsRes[" not in r
    assert "cols: [...['numero', 'huesped_nombre', 'hab', 'cat', 'llegada', 'salida', 'noches_n', 'nacionalidad', 'plan_txt'].map(col), { key: 'saldo', label: 'Saldo', num: true, fmt: v => M(v) }, col('estado_txt')]" in lineas["salidas"]
    assert "{ key: 'origen_txt', label: 'Origen' }, { key: 'nacionalidad', label: 'Nacionalidad' }, { key: 'plan_txt', label: 'Plan' }, { key: 'especiales', label: 'Pedidos especiales' }" in r
    # la pantalla: filtros desde la dirección y de vuelta a ella, y escritos en lo exportado
    assert "filtros: { nac: this.params.nac || '', plan: this.params.plan || '', piso: this.params.piso || '', grupo: this.params.grupo || '', canal: this.params.canal || '' }" in r
    assert "definirReportesHotel(this.cfg, this.lista, this.desde, this.hasta, this.filtros)" in r and 'v-if="hayFiltrables"' in r and r.count('v-model="filtros.') == 5
    assert "history.replaceState(history.state, '', '#/hotel/reportes?' + q.toString())" in r and "subtitulo: (conF(a) + a.desc).slice(0, 300)" in r
    assert r.count("text/csv") == 1                                                      # no hay otra exportación propia (4.17)


def test_h14b_los_cargos_guardan_la_fecha_y_el_tipo_de_la_factura():
    rec = _js("pages/hotel/recepcion.js")
    marca = next(x for x in rec.split("\n") if "for (const f of this.coCargos) cambiarFolio(f.id, {" in x)       # la línea que marca lo facturado
    assert "documento_id: doc.id" in marca and "consecutivo: doc.consecutivo" in marca and "facturado_fecha: this.hoyS" in marca and "doc_tipo: doc.tipo_documento" in marca
    ag = _js("pages/hotel/agencias.js")
    marca = next(x for x in ag.split("\n") if "for (const f of cargos) cambiarFolio(f.id, {" in x)
    assert "documento_id: doc.id" in marca and "facturado_fecha: hoyHotel()" in marca and "doc_tipo: '01'" in marca
    assert re.search(r"import \{[^}]*\bhoyHotel\b[^}]*\} from './_datos.js'", ag)
    r = _js("pages/hotel/reportes.js")
    assert "f.facturado_fecha" in r and "fechaDoc.get(docId)" in r and "TIPO_COMPROBANTE[tipo] || 'Comprobante'" in r


def test_h8_ficha_grupos_y_recepcion_muestran_el_vuelo():
    f = _js("pages/hotel/reserva-form.js")
    assert re.search(r"\bTRASLADOS\b", f[f.index("  data() {"):f.index("  computed: {")]) and re.search(r"import \{[^}]*\bTRASLADOS\b[^}]*\} from './_datos.js'", f)   # la plantilla solo ve lo que data expone
    for txt in ('<input v-model="f.vuelo_llegada" maxlength="12"', '<input type="time" v-model="f.hora_vuelo_llegada"', '<input v-model="f.vuelo_salida" maxlength="12"', '<input type="time" v-model="f.hora_vuelo_salida"',
                '<select v-model="f.traslado" :disabled="!editable"><option v-for="t in TRASLADOS" :key="t[0]" :value="t[0]">{{t[1]}}</option></select>', '<input v-model="f.traslado_nota" maxlength="120"'):
        assert txt in f, txt
    assert f.index('<Field label="Vehículo (placa)">') < f.index('<Field label="Vuelo de llegada"') < f.index('<Field label="Pedidos especiales"')
    assert "setup() { return { hoy, hoyHotel, " in f and "cuentaParaMedio('06', this.cfg.moneda, this.cuentas)" in f      # lo que otras pruebas exigen sigue igual
    g = _js("pages/hotel/grupos.js")
    assert "hoy()" not in g and "llegada: hoyHotel(), salida: sumarDias(hoyHotel(), 2)" in g                            # la fecha del hotel, no la del calendario
    assert "vuelo_llegada: (f.vuelo_llegada || '').trim(), hora_vuelo_llegada: f.hora_vuelo_llegada || ''" in g and 'v-model="form.vuelo_llegada"' in g and 'v-model="form.hora_vuelo_salida"' in g
    assert "esc(vuelosTexto(r))" in g and "<th>Vuelo</th>" in g and '<td colspan="9">Total del grupo</td>' in g
    rec = _js("pages/hotel/recepcion.js")
    assert "v-if=\"r.vuelo_llegada || r.hora_vuelo_llegada\" title=\"Vuelo de llegada\"" in rec and "✈ {{[r.vuelo_llegada, r.hora_vuelo_llegada].filter(Boolean).join(' ')}}" in rec


def test_h21_historico_ruta_menu_y_exportacion():
    assert "'/hotel/historico': 'hotel/historico'" in _js("app.js")
    m = _js("menu.js")
    assert m.count("{ label: 'Histórico', to: '/hotel/historico' }") == 1
    assert m.index("{ label: 'Agencias y empresas', to: '/hotel/agencias' }") < m.index("to: '/hotel/historico'") < m.rindex("{ label: 'Reportes', to: '/hotel/reportes' }")
    assert "|espera|cotizaciones|historico)/.test(path)" in m                              # abre con la misma regla que Reservaciones
    crudo = (JS / "menu.js").read_bytes()
    assert crudo.count(b"\r\n") == crudo.count(b"\n") > 300                                # menu.js conserva sus finales de línea (CRLF)
    h = (HOTEL / "historico.js").read_text(encoding="utf-8")
    assert "import { exportarTabla } from '../reportes/_montos.js';" in h and "descargarReporte" not in h and "text/csv" not in h and "descargarCSV" not in h
    metodos = h[h.index("  methods: {"):h.index("  template: `")]
    assert h.count("exportarTabla(") == 2 and metodos.count("exportarTabla(") == 2         # se exporta desde methods, nunca al pintar
    assert "exportarTabla('hotel_historico', this.columnas, this.filas, { titulo: 'Histórico de reservas', periodo })" in metodos
    assert "money(v || 0, m)" in h and "+r.total || 0" in h                                # tolera que el total no llegue (roles sin montos)
    for campo in ("r.agente_id", "r.origen_negocio", "r.reservante_nombre"):                # campos de tandas posteriores: se leen con valor por omisión
        assert campo in h, campo
    assert "location.hash = destino" in h and "params(p) {" in h and "props: ['params']" in h
    hu = _js("pages/hotel/huespedes.js")
    assert ":href=\"'#/hotel/historico?q=' + encodeURIComponent(ver.documento || nombreHuesped(ver))\">Ver en el histórico</a>" in hu
    assert "'#/hotel/reportes?rep=pronostico,pronostico_tipo&desde=' + hoy() + '&hasta=' + sumarDias(hoy(), 29)" in _js("pages/inicio.js")


# ============================================================================= cálculo: las funciones de verdad, en Node
API_JS = """// Sustituto mínimo de api.js: un registro en memoria y los formatos, para correr los módulos del hotel fuera del navegador
const datos = globalThis.__DATOS || (globalThis.__DATOS = {});
const copia = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
export const mock = { cargado: true, get(k, fb) { return k in datos ? copia(datos[k]) : fb; }, set(k, v) { datos[k] = copia(v); return Promise.resolve(true); },
  actualizar(k, fn, fb) { const v = this.get(k, fb); const r = fn(v); const n = r === undefined ? v : r; this.set(k, n); return n; }, nextId(l) { return (l || []).reduce((m, x) => Math.max(m, +x.id || 0), 0) + 1; }, puedeGuardar() { return true; } };
export function hoy() { return globalThis.__HOY; }
export function sumarDias(iso, n) { const d = new Date(String(iso || hoy()).slice(0, 10) + 'T00:00:00'); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function fmt(n, dec = 2) { return (+n || 0).toFixed(dec); }
export function money(n, moneda = 'CRC') { return moneda + ' ' + fmt(n); }
export function fecha(iso) { return iso ? String(iso).slice(0, 10).split('-').reverse().join('/') : ''; }
export function fechaHora(iso) { return String(iso || ''); }
export function siguienteNumero(l) { return (l || []).length + 1; }
export const monedas = { tc() { return 500; }, principal() { return { codigo: 'CRC' }; } };
export function toast() {}
export function cabecerasAuth() { return {}; }
export function otroImpLinea() { return { monto: 0, base: 0 }; }
export async function api() { return {}; }
"""
APP_JS = """export const sesion = { tipo: 'hospitalidad', usuario: { correo: 'qa@example.test' }, puede() { return true; } };
export const store = globalThis.__STORE || (globalThis.__STORE = { clientes: [], empresa: {} });
"""
MONTOS_JS = """import { fecha } from '../../api.js';
export function celdaTexto(row, c) { const v = row[c.key]; if (typeof c.fmt === 'function') return c.fmt(v, row); if (c.fmt === 'date') return fecha(v); return v === null || v === undefined ? '' : String(v); }
const anotar = x => (globalThis.__DESCARGAS = globalThis.__DESCARGAS || []).push(x);
export async function descargarReporte(formato, d) { anotar({ formato, titulo: d.titulo, subtitulo: d.subtitulo, periodo: d.periodo, filas: d.rows.length, secciones: (d.secciones || []).map(s => s.nota) }); }
export async function descargarTabla(formato, nombre, cols, rows, opts) { anotar({ formato, nombre, filas: rows.length, opts }); }
export async function exportarTabla(nombre, cols, rows, opts) { (globalThis.__EXPORTADO = globalThis.__EXPORTADO || []).push({ nombre, cols: cols.map(c => c.key), filas: rows.length, opts }); }
"""
# Un componente sin Vue: data, computed (calculados al pedirlos y descartados cuando cambia un dato) y methods
MONTAR_JS = """function montarComp(comp, params) {
  const datos = comp.data.call({ params }), cache = {};
  const ctx = new Proxy({}, {
    get(_, k) { if (k === 'params') return params; if (k in datos) return datos[k]; if (comp.computed[k]) return k in cache ? cache[k] : (cache[k] = comp.computed[k].call(ctx)); if (comp.methods[k]) return comp.methods[k].bind(ctx); return undefined; },
    set(_, k, v) { datos[k] = v; for (const x of Object.keys(cache)) delete cache[x]; return true; },
  });
  return ctx;
}
"""
# Hoy es el 9/11/2026. Estándar: 101, 102 y 103 (en mantenimiento); Suite: 201 y 202 (inactiva). El 10 hay dos reservas «asignar al
# llegar» de Suite y una de Estándar, la 4 pidió Estándar pero duerme en la Suite 201, la 102 está bloqueada y la 7 está cancelada.
DATOS_REPORTES = """const D = globalThis.__DATOS = {};
globalThis.__HOY = '2026-11-09';
globalThis.__STORE = { clientes: [{ id: 5, nombre: 'Empresa QA S.A.' }], empresa: {} };
D.hotel_config = { activo: true, moneda: 'USD', tarifa_iva: 13, precios_incluyen_iva: true, planes: [{ id: 1, nombre: 'Solo habitación', pct: 0 }, { id: 2, nombre: 'Con desayuno', pct: 0 }] };
D.hotel_categorias = [{ id: 1, nombre: 'Estándar', orden: 1 }, { id: 2, nombre: 'Suite', orden: 2 }];
D.hotel_habitaciones = [{ id: 11, numero: '101', categoria_id: 1 }, { id: 12, numero: '102', categoria_id: 1 }, { id: 13, numero: '103', categoria_id: 1, estado: 'mantenimiento' }, { id: 21, numero: '201', categoria_id: 2 }, { id: 22, numero: '202', categoria_id: 2, activa: false }];
D.hotel_huespedes = [{ id: 1, nombre: 'Ana', nacionalidad: 'Costa Rica' }, { id: 2, nombre: 'Bob', nacionalidad: 'Canadá' }];
D.hotel_agencias = [{ id: 3, nombre: 'Viajes QA', modalidad: 'neta' }];
const R = (id, estado, hab, cat, llegada, salida, x = {}) => ({ id, tipo: 'reserva', numero: 'R-' + String(id).padStart(4, '0'), estado, habitacion_id: hab, categoria_id: cat, llegada, salida, adultos: 2, ninos: 0, moneda: 'USD', origen: 'directa', huesped_nombre: 'Huésped ' + id, ...x });
D.hotel_reservas = [
  R(1, 'en_casa', 11, 1, '2026-11-08', '2026-11-11', { tarifa_noche: 100, plan_id: 2, ninos: 1, huesped_id: 1, origen: 'booking', grupo: 'Tour A', vuelo_salida: 'AV 642', hora_vuelo_salida: '09:10', traslado: 'hotel', traslado_nota: '3 maletas' }),
  R(2, 'confirmada', null, 1, '2026-11-10', '2026-11-12', { tarifa_noche: 80, plan_id: 1, huesped_id: 2, vuelo_llegada: 'AC 900', hora_vuelo_llegada: '14:30' }),
  R(3, 'pendiente', null, 2, '2026-11-10', '2026-11-11', { tarifa_noche: 0 }),
  R(4, 'confirmada', 21, 1, '2026-11-10', '2026-11-12', { tarifa_noche: 120, plan_id: 2, agencia_id: 3, origen: 'agencia' }),
  R(5, 'confirmada', null, 2, '2026-11-10', '2026-11-11'),
  { id: 6, tipo: 'bloqueo', estado: 'bloqueo', numero: 'BLQ', habitacion_id: 12, llegada: '2026-11-10', salida: '2026-11-11', motivo: 'Pintura' },
  R(7, 'cancelada', null, 1, '2026-11-10', '2026-11-11', { vuelo_llegada: 'XX 1' }),
  { id: 8, tipo: 'folio', estado: 'abierto', numero: 'CE-0001', huesped_nombre: 'Boda QA', habitacion_id: null, categoria_id: null, llegada: '2026-11-09', salida: '2026-11-09', moneda: 'USD' },
  R(9, 'salio', 12, 1, '2026-11-06', '2026-11-08', { documento_id: 77, consecutivo: '00100001010000000077', salida_real: '2026-11-08', cliente_id: 5 }),
];
const C = (id, res, fecha, origen, precio, x = {}) => ({ id, reserva_id: res, tipo: 'cargo', origen, fecha, cantidad: 1, precio, tarifa: 13, moneda: 'USD', ...x });
const P = (id, res, fecha, monto) => ({ id, reserva_id: res, tipo: 'pago', fecha, monto, medio: '01', moneda: 'USD' });
D.hotel_folios = [
  C(1, 1, '2026-11-08', 'hospedaje', 100), P(2, 1, '2026-11-08', 50),
  C(3, 1, '2026-11-09', 'hospedaje', 100), C(4, 1, '2026-11-09', 'pos', 20), P(5, 1, '2026-11-09', 30),
  C(6, 1, '2026-11-09', 'manual', 10, { documento_id: 78, consecutivo: '00100001040000000078', facturado_fecha: '2026-11-09', doc_tipo: '04' }),           // factura parcial de hoy
  C(7, 8, '2026-11-09', 'eventos', 200), C(8, 8, '2026-11-09', 'manual', 20, { tarifa: 0, es_otro_cargo: true }),                                     // cuenta externa
  C(9, 9, '2026-11-06', 'hospedaje', 100, { documento_id: 77, consecutivo: '00100001010000000077' }), C(10, 9, '2026-11-07', 'hospedaje', 100, { documento_id: 77, consecutivo: '00100001010000000077' }),   // anterior: sin fecha
  C(11, 9, '2026-11-07', 'auto', 10, { documento_id: 79, consecutivo: '00100001010000000079', a_agencia: true, agencia_id: 3 }),                       // a la agencia, anterior y sin fecha
  C(12, 4, '2026-11-09', 'no_show', 50, { documento_id: 80, consecutivo: '00100001040000000080' }),                                                   // penalidad: la fecha del cargo
];
"""
PRUEBA_REPORTES = DATOS_REPORTES + """
const H = await import('./js/pages/hotel/_datos.js');
const { definirReportesHotel } = await import('./js/pages/hotel/reportes.js');
const { celdaTexto } = await import('./js/pages/reportes/_montos.js');
const cfg = H.config(), todas = H.reservas(), estadias = todas.filter(H.esEstadia);
const tabla = (defs, k) => { const r = defs[k], f = r.filas(); return { cols: r.cols.map(c => c.key), filas: f.map(x => r.cols.map(c => x[c.key])), totales: r.totales ? r.totales(f) : [] }; };
const dia = definirReportesHotel(cfg, estadias, '2026-11-09', '2026-11-09'), semana = definirReportesHotel(cfg, estadias, '2026-11-09', '2026-11-12'), mes = definirReportesHotel(cfg, estadias, '2026-11-01', '2026-11-30');
const cierre = definirReportesHotel(cfg, todas, '2026-11-09', '2026-11-10');   // como cierre.js: cuatro argumentos y la lista completa (con bloqueos y cuentas externas)
const con = f => definirReportesHotel(cfg, estadias, '2026-11-08', '2026-11-12', f);
const nums = (defs, k) => defs[k].filas().map(x => x.numero);
const pron = semana.pronostico_tipo, filasPron = pron.filas();
console.log(JSON.stringify({
  d10: H.disponibilidadPorTipo('2026-11-10', todas, { modo: 'proyectado' }), d09: H.disponibilidadPorTipo('2026-11-09', todas), r09: H.disponibilidadPorTipo('2026-11-09', todas, { modo: 'real' }),
  r10: H.disponibilidadPorTipo('2026-11-10', todas, { modo: 'real' }), r07: H.disponibilidadPorTipo('2026-11-07', todas, { modo: 'real' }), ex10: H.disponibilidadPorTipo('2026-11-10', todas, { excluir: 5 }).porCat[2].libres,
  oc10: H.ocupacionDia('2026-11-10', todas),
  plan: [H.nombrePlan(2, cfg), H.nombrePlan(99, cfg)], traslado: [H.nombreTraslado(''), H.nombreTraslado('hotel'), H.nombreTraslado(undefined)], vuelos: [H.vuelosTexto(todas[0]), H.vuelosTexto(todas[1]), H.vuelosTexto({})],
  tarjeta: H.tarjetaRegistroHTML(todas[0], null), tarjeta2: H.tarjetaRegistroHTML(todas[2], null), paquete: H.paqueteCierre(cfg), paqueteElegido: H.paqueteCierre({ paquete_cierre: ['llegadas', 'transporte'] }),
  claves: Object.keys(dia), limites: Object.fromEntries(Object.entries(mes).map(([k, r]) => { const f = r.filas(); return [k, [(r.desc || '').length, r.cols.length, (r.totales ? r.totales(f) : []).length]]; })),
  pron: tabla(semana, 'pronostico_tipo'), pronTexto: pron.cols.map(c => celdaTexto(filasPron[1], c)), plan_hoy: tabla(dia, 'ocupacion_plan'), plan_manana: tabla(definirReportesHotel(cfg, estadias, '2026-11-10', '2026-11-10'), 'ocupacion_plan'),
  mano: tabla(dia, 'mano_corriente'), manoTexto: celdaTexto(dia.mano_corriente.filas()[0], dia.mano_corriente.cols[3]), mano08: tabla(definirReportesHotel(cfg, estadias, '2026-11-08', '2026-11-08'), 'mano_corriente'), manoCierre: tabla(cierre, 'mano_corriente').cols,
  fact: tabla(mes, 'facturacion_dia'), factHoy: tabla(dia, 'facturacion_dia').filas.map(x => x[1]), transp: tabla(semana, 'transporte'), transpCierre: tabla(cierre, 'transporte').filas,
  llegadas: tabla(semana, 'llegadas').cols, salidas: tabla(semana, 'salidas').cols, salidaTexto: celdaTexto(semana.salidas.filas().find(x => x.id === 1), semana.salidas.cols[1]), cierreLlegadas: tabla(cierre, 'llegadas').cols,
  f_nac: nums(con({ nac: 'Canadá' }), 'llegadas'), f_plan: nums(con({ plan: '2' }), 'llegadas'), f_sin: nums(con({ piso: 'Sin habitación' }), 'llegadas'), f_piso: nums(con({ piso: '2' }), 'llegadas'), f_grupo: nums(con({ grupo: 'Tour A' }), 'salidas'),
  f_contrato: nums(con({ canal: 'ag3' }), 'llegadas'), f_origen: nums(con({ canal: 'booking' }), 'llegadas'), f_dos: nums(con({ plan: '2', canal: 'booking' }), 'llegadas'), f_plan_piso: nums(definirReportesHotel(cfg, estadias, '2026-11-10', '2026-11-10', { plan: '1' }), 'ocupacion_plan'),
  sin_filtro: nums(con({}), 'llegadas'), en_casa: nums(con({ nac: 'Canadá' }), 'en_casa'),
}));
"""
# Histórico: la 1 es de 2024 (fuera de los 12 meses que se proponen al entrar), la 3 está cancelada, la 4 se cobra en colones y trae
# los campos de tandas posteriores, y la 5 llega sin total (lo que recibe un rol sin montos).
# La pantalla de Reportes con filtros en la dirección: lo que muestra, lo que ofrece filtrar, lo que deja en la dirección y lo que exporta
PRUEBA_PANTALLA = DATOS_REPORTES + MONTAR_JS + """
globalThis.history = { state: null, replaceState(s, t, url) { globalThis.__URL = url; } };
const comp = (await import('./js/pages/hotel/reportes.js')).default;
const p = montarComp(comp, { rep: 'llegadas,salidas,en_casa', desde: '2026-11-08', hasta: '2026-11-12', nac: 'Canadá' });
const vista = c => c.activos.map(a => [a.k, a.filtrable, a.filas.map(x => x.numero)]);
const v1 = vista(p), texto1 = p.textoFiltros, hay1 = p.hayFiltrables, opciones = p.opcionesFiltro;
p.sincronizar(); const url1 = globalThis.__URL;
p.exportar('pdf'); p.exportar('xlsx');
p.filtros = { ...p.filtros, nac: '', plan: '2', canal: 'ag3' }; const v2 = vista(p), texto2 = p.textoFiltros;
p.sel = ['llegadas']; p.sincronizar(); const url2 = globalThis.__URL; p.exportar('pdf'); p.exportar('xlsx'); p.exportar('csv');
p.limpiarFiltros(); const v3 = vista(p), texto3 = p.textoFiltros; p.exportar('pdf'); p.sincronizar(); const url3 = globalThis.__URL;
const q = montarComp(comp, { rep: 'pronostico,pronostico_tipo', desde: '2026-11-09', hasta: '2026-11-12' });
console.log(JSON.stringify({ v1, texto1, hay1, opciones, url1, v2, texto2, url2, v3, texto3, url3, descargas: globalThis.__DESCARGAS,
  inicio: [q.activos.map(a => a.k), q.hayFiltrables, q.activos[1].filas.length], sinNada: montarComp(comp, {}).activos.map(a => [a.k, a.periodo]) }));
"""
# El paquete del cierre tal como lo arma cierre.js › secciones(): con el paquete completo y con uno elegido en Habitaciones y tarifas
PRUEBA_CIERRE = DATOS_REPORTES + MONTAR_JS + """
const comp = (await import('./js/pages/hotel/cierre.js')).default;
const secciones = montarComp(comp, { dia: '2026-11-09' }).secciones();
globalThis.__DATOS.hotel_config.paquete_cierre = ['llegadas', 'transporte'];
console.log(JSON.stringify({ secciones, elegido: montarComp(comp, { dia: '2026-11-09' }).secciones().map(s => s.titulo.split(' · ')[0]) }));
"""
POS_JS = """export function cajas() { return []; }
export function resumenCaja() { return { ventas: 0, total: 0, porMedio: {}, efectivo_esperado: 0 }; }
export function nombreMedio(m) { return m; }
"""
PRUEBA_HISTORICO = MONTAR_JS + """const D = globalThis.__DATOS = {};
globalThis.__HOY = '2026-11-09';
globalThis.location = { hash: '#/hotel/historico' };
D.hotel_config = { activo: true, moneda: 'USD', tarifa_iva: 13, precios_incluyen_iva: true };
D.hotel_categorias = [{ id: 1, nombre: 'Estándar', orden: 1 }, { id: 2, nombre: 'Suite', orden: 2 }];
D.hotel_habitaciones = [{ id: 11, numero: '101', categoria_id: 1 }, { id: 21, numero: '201', categoria_id: 2, activa: false }];
D.hotel_huespedes = [{ id: 1, nombre: 'Ana', documento: '1-1111-1111', nacionalidad: 'Costa Rica' }, { id: 2, nombre: 'Bob', documento: 'P123', nacionalidad: 'Canadá' }];
D.hotel_agencias = [{ id: 3, nombre: 'Viajes QA' }];
D.vendedores = [{ id: 7, nombre: 'Carla' }];
const R = (id, estado, hab, llegada, salida, x = {}) => ({ id, tipo: 'reserva', numero: 'R-' + String(id).padStart(4, '0'), estado, habitacion_id: hab, categoria_id: 1, llegada, salida, adultos: 2, ninos: 0, moneda: 'USD', origen: 'directa', total: 100, creado: llegada + 'T12:00:00.000Z', huesped_nombre: 'Huésped ' + id, ...x });
D.hotel_reservas = [
  R(1, 'salio', 11, '2024-03-01', '2024-03-04', { huesped_id: 1, huesped_nombre: 'Ana Mora', total: 300 }),
  R(2, 'salio', 11, '2026-10-01', '2026-10-03', { huesped_id: 1, huesped_nombre: 'Ana Mora', total: 200, segmento: 'Ocio', especiales: 'Cuna' }),
  R(3, 'cancelada', null, '2026-10-10', '2026-10-12', { huesped_id: 2, huesped_nombre: 'Bob Roy', agencia_id: 3, origen: 'agencia', grupo: 'Tour A' }),
  R(4, 'en_casa', 11, '2026-11-08', '2026-11-11', { huesped_id: 2, huesped_nombre: 'Bob Roy', moneda: 'CRC', total: 150000, agente_id: 7, origen_negocio: 'Feria', reservante_nombre: 'Zoe Asistente', vuelo_llegada: 'AV 1', hora_vuelo_llegada: '10:00' }),
  R(5, 'confirmada', 21, '2026-12-01', '2026-12-02', { total: undefined }),
  { id: 6, tipo: 'bloqueo', estado: 'bloqueo', numero: 'BLQ', habitacion_id: 11, llegada: '2026-10-05', salida: '2026-10-07', motivo: 'Pintura' },
  { id: 8, tipo: 'folio', estado: 'abierto', numero: 'CE-0001', habitacion_id: null, llegada: '2026-10-02', salida: '2026-10-02' },
];
const C = (id, res, fecha, x = {}) => ({ id, reserva_id: res, tipo: 'cargo', origen: 'hospedaje', fecha, cantidad: 1, precio: 100, tarifa: 13, moneda: 'USD', ...x });
D.hotel_folios = [C(1, 2, '2026-10-01'), C(2, 2, '2026-10-02'), C(3, 8, '2026-11-08', { reserva_origen_id: 4 }), C(4, 4, '2026-11-08', { origen: 'pos' }), C(5, 1, '2024-03-01')];

const M = await import('./js/pages/hotel/historico.js');
const comp = M.default, montar = p => montarComp(comp, p);
const nums = c => c.filas.map(r => r.numero), ver = p => nums(montar(p));
const todo = montar({ todo: '1' }), hab = montar({ tab: 'habitacion', hab: '11', hd: '2026-10-01', hh: '2026-11-09' });
const fila = (c, id) => { const r = c.filas.find(x => x.id === id); return c.columnas.map(k => r[k.key]); };
// «Aplicar»: lo escrito pasa a lo aplicado y a la dirección; Atrás devuelve los parámetros anteriores y la pantalla los toma
const p = montar({}); p.f = { ...p.f, ld: '', q: ' ana ', estados: 'salio' }; const antes = nums(p); p.aplicar(); const hash1 = globalThis.location.hash, n1 = nums(p), pendiente1 = p.pendiente;
p.f = { ...p.f, grupo: 'x' }; const pendiente2 = p.pendiente;
p.limpiar(); const hash2 = globalThis.location.hash, n2 = nums(p);
p.cambiarTab('habitacion'); p.f.hab = 11; p.aplicar(); const hash3 = globalThis.location.hash;
comp.watch.params.call(p, { q: 'bob' }); const atras = { tab: p.tab, q: p.f.q, n: nums(p) };
p.alternarEstado('cancelada'); p.alternarEstado('no_show'); p.alternarEstado('cancelada'); const marcados = [p.f.estados, p.tieneEstado('no_show'), p.tieneEstado('cancelada')];
todo.exportar(); hab.exportarHab(); montar({ tab: 'habitacion' }).exportarHab();
console.log(JSON.stringify({
  entrar: M.criterios({}), conQ: M.criterios({ q: ' x ' }).ld, conTodo: M.criterios({ todo: '1' }).ld,
  defecto: ver({}), todo: nums(todo), cols: todo.columnas.map(c => c.key), fila2: fila(todo, 2), total4: fila(todo, 4).pop(), total5: fila(todo, 5).pop(), textoTotal5: todo.columnas.find(c => c.key === 'total').fmt(undefined), resumen: todo.resumen,
  texto: montar({ ld: '2026-10-01', estados: 'cancelada,no_show', agencia: '3' }).textoCriterios,
  documento: ver({ q: '1-1111' }), nombre: ver({ q: 'BOB' }), reservante: ver({ q: 'zoe' }), numero: ver({ num: 'r-0003' }), estados: ver({ estados: 'cancelada,en_casa' }), agencia: ver({ agencia: '3' }), mercado: ver({ seg: 'Ocio' }),
  origen: ver({ origen: 'agencia' }), negocio: ver({ negocio: 'Feria' }), agente: ver({ agente: '7' }), habitacion: ver({ hab: '11' }), nacionalidad: ver({ nac: 'Canadá' }), grupo: ver({ grupo: 'tour' }), especiales: ver({ esp: '1' }),
  entrada: ver({ ld: '2026-10-01', lh: '2026-10-31' }), salida: ver({ sd: '2026-11-01', sh: '2026-11-30' }), creacion: ver({ cd: '2026-10-10', ch: '2026-10-10' }), combinado: ver({ ld: '2026-01-01', nac: 'Canadá', estados: 'en_casa' }), nada: ver({ nac: 'Canadá', seg: 'Ocio' }),
  negocios: todo.negocios, nacionalidades: todo.nacionalidades, agentes: todo.agentes.map(x => x.nombre),
  porHab: { ...hab.porHab, hab: hab.porHab.hab.numero, filas: hab.porHab.filas.map(x => hab.columnasHab.map(c => x[c.key])) }, colsHab: hab.columnasHab.map(c => c.key), tabHab: hab.tab, sinElegir: montar({ tab: 'habitacion' }).porHab.filas.length,
  antes, hash1, n1, pendiente1, pendiente2, hash2, n2, hash3, atras, marcados, exportado: globalThis.__EXPORTADO,
}));
"""

# Tanda 2 (H4, H15, H6 y H7) sobre los mismos datos: marcas y reservas sin habitación, tablero y alertas, el calendario y su pantalla,
# los bloqueos en lote con su cuadro y la lista de Fuera de servicio. mock.set se cuenta y puede fallar una vez, como un 409 del servidor.
PRUEBA_TANDA2 = DATOS_REPORTES + """
// Un componente sin Vue, con propiedades: data (con las props como this), computed (se recalculan cuando cambia un dato), methods y $emit
function montar(comp, props = {}) {
  const emitidos = [], datos = comp.data ? comp.data.call(props) : {}, cache = {}, calc = comp.computed || {}, met = comp.methods || {};
  const ctx = new Proxy({}, {
    get(_, k) { if (k === '$emit') return (...a) => { emitidos.push(a); }; if (k === 'emitidos') return emitidos; if (k in datos) return datos[k]; if (k in props) return props[k]; if (calc[k]) return k in cache ? cache[k] : (cache[k] = calc[k].call(ctx)); if (met[k]) return met[k].bind(ctx); return undefined; },
    set(_, k, v) { if (k in props && !(k in datos)) props[k] = v; else datos[k] = v; for (const x of Object.keys(cache)) delete cache[x]; return true; },
  });
  return ctx;
}
const guardado = {};
globalThis.localStorage = { getItem: k => (k in guardado ? guardado[k] : null), setItem(k, v) { guardado[k] = String(v); } };
globalThis.location = { hash: '' };
globalThis.confirm = () => true;
const { mock } = await import('./js/api.js');
const H = await import('./js/pages/hotel/_datos.js');
// mock.set contado y con un fallo a pedido (como cuando el servidor rechaza el envío: la copia local se queda con lo enviado)
const set0 = mock.set.bind(mock); let envios = 0, fallar = false;
mock.set = (k, v) => { envios++; set0(k, v); if (fallar) { fallar = false; return Promise.resolve(false); } return Promise.resolve(true); };
const nums = l => l.map(r => r.numero), cfg = H.config(), todas = H.reservas();

// ---- H15: marcas, pagos y reservas sin habitación
const pagos = H.pagosPorReserva();
const marcas = { r1: H.marcasReserva(todas[0], pagos, '2026-11-09'), r2: H.marcasReserva(todas[1], pagos), pre: H.marcasReserva({ ...todas[3], preasignada: true }, pagos), preSinHab: H.marcasReserva({ ...todas[1], preasignada: true }, pagos),
  preEnCasa: H.marcasReserva({ ...todas[0], preasignada: true }, pagos), bloqueo: H.marcasReserva(todas[5], { 6: 99 }), sinMapa: H.marcasReserva(todas[0]) };
const sinHab = { semana: nums(H.reservasSinHabitacion('2026-11-09', '2026-11-15', todas)), noche11: nums(H.reservasSinHabitacion('2026-11-11', '2026-11-12', todas)), antes: nums(H.reservasSinHabitacion('2026-11-01', '2026-11-09', todas)), todas: nums(H.reservasSinHabitacion(null, null)) };

// ---- H7: tablero, alertas y tareas
const hace = h => new Date(Date.now() - h * 3600000).toISOString();
D.hotel_reportes = [
  { id: 1, numero: 'RP-0001', modulo: 'limpieza', estado: 'abierto', prioridad: 'normal', creado: hace(1) },
  { id: 2, numero: 'RP-0002', modulo: 'mantenimiento', estado: 'abierto', prioridad: 'normal', creado: hace(72) },                 // más de 24 horas: atrasada
  { id: 3, numero: 'RP-0003', modulo: 'mantenimiento', estado: 'en_proceso', prioridad: 'urgente', creado: hace(1) },             // urgente: atrasada
  { id: 4, numero: 'RP-0004', modulo: 'limpieza', estado: 'resuelto', creado: hace(100), resuelto_en: '2026-11-09T18:00:00.000Z' },   // mediodía del 9 en Costa Rica
  { id: 5, numero: 'RP-0005', modulo: 'mantenimiento', estado: 'resuelto', creado: hace(100), resuelto_en: '2026-11-08T12:00:00.000Z' },
  { id: 6, numero: 'RP-0006', modulo: 'limpieza', estado: 'resuelto', creado: hace(100), resuelto_en: '2026-11-09T03:00:00.000Z' },   // en Costa Rica todavía era el 8 por la noche
  { id: 7, numero: 'RP-0007', modulo: 'limpieza', estado: 'resuelto', creado: hace(100), resuelto_en: '2026-11-09T04:00:00' },        // un sello sin zona es UTC: también fue el 8
];
D.hotel_preventivo = [{ id: 1, nombre: 'Aires', proxima: '2026-11-01', activo: true }, { id: 2, nombre: 'Bombas', proxima: '2026-12-01', activo: true }, { id: 3, nombre: 'Viejo', proxima: '2026-10-01', activo: false }];
const tablero = H.tableroHotel('2026-11-09'), tareas = H.tareasHotel('2026-11-09');
const claves = l => l.map(a => a.clave);
const alertas09 = H.alertasHotel('2026-11-09', todas, cfg);
// variantes: plazo del adelanto vencido, tope de la cuenta, salida de hoy con saldo y habitación sucia con llegada hoy
D.hotel_reservas[2].creado = '2026-11-01T10:00:00.000Z';                                                    // la 3 (pendiente) se creó hace 8 días
const conPlazo = H.alertasHotel('2026-11-09', H.reservas(), { ...cfg, adelanto_plazo_dias: 3, tope_cuenta: 100 });
const sinPlazo = claves(H.alertasHotel('2026-11-09', H.reservas(), { ...cfg, adelanto_plazo_dias: 30, tope_cuenta: 500 }));
D.hotel_habitaciones[3].estado = 'sucia';                                                                  // la 201, donde llega la 4 el día 10
const dia10 = H.alertasHotel('2026-11-10', H.reservas(), cfg), dia11 = H.alertasHotel('2026-11-11', H.reservas(), cfg);
D.hotel_habitaciones[3].estado = 'limpia';
// la cuenta de una agencia con tarifa neta: el hospedaje no es saldo del huésped
D.hotel_reservas.push({ id: 40, tipo: 'reserva', numero: 'R-0040', estado: 'en_casa', habitacion_id: null, categoria_id: 1, llegada: '2026-11-08', salida: '2026-11-09', agencia_id: 3, moneda: 'USD', huesped_nombre: 'Neta' });
D.hotel_folios.push({ id: 90, reserva_id: 40, tipo: 'cargo', origen: 'hospedaje', fecha: '2026-11-08', cantidad: 1, precio: 100, tarifa: 13, moneda: 'USD' });
const neta = claves(H.alertasHotel('2026-11-09', H.reservas(), cfg)).includes('salidas_saldo');
D.hotel_folios.push({ id: 91, reserva_id: 40, tipo: 'cargo', origen: 'pos', fecha: '2026-11-08', cantidad: 1, precio: 10, tarifa: 13, moneda: 'USD' });
const netaConExtra = H.alertasHotel('2026-11-09', H.reservas(), cfg).find(a => a.clave === 'salidas_saldo');
D.hotel_reservas.pop(); D.hotel_folios.pop(); D.hotel_folios.pop();
// con la fecha del hotel activa y un día atrás, falta el cierre
D.hotel_config.fecha_hotel = true; D.hotel_fecha = { fecha: '2026-11-08' };
const cierre = H.alertasHotel(H.hoyHotel(), H.reservas(), H.config())[0];
delete D.hotel_config.fecha_hotel; delete D.hotel_fecha;
const sinFolios = (() => { const f = D.hotel_folios; D.hotel_folios = []; const t = H.tableroHotel('2026-11-09'), x = { adr: t.adr, revpar: t.revpar, revpor: t.revpor, ingreso: t.ingreso, alertas: claves(t.alertas), pagos: H.pagosPorReserva() }; D.hotel_folios = f; return x; })();

// ---- H4 y H15: el calendario (_tape.js) y su pantalla
const Tape = (await import('./js/pages/hotel/_tape.js')).default;
const dias3 = ['2026-11-09', '2026-11-10', '2026-11-11'];
const t = montar(Tape, { dias: dias3, habitaciones: H.habitaciones(), reservas: H.reservas(), agrupar: 'categoria', resumenTipo: true });
const g = t.grupos, res = id => H.reservas().find(r => r.id === id);
const tape = { grupos: g.map(x => [x.nombre, x.catId, x.habs.length]), libres: g.map(x => dias3.map((d, i) => t.libresTipo(x, i))), tarifas: g.map(x => dias3.map((d, i) => t.tarifaTipo(x, i))), tituloTipo: t.tituloTipo(g[1], 1),
  pie: t.porDia.map(o => [o.pct, o.libres]), tituloPie: t.tituloPie(t.porDia[1]), texto1: t.texto(res(1)), texto4: t.texto(res(4)), bloqueo: t.texto(res(6)), marcas1: t.marcas(res(1)), titulo1: t.titulo(res(1)) };
t.dias = ['2026-11-10']; tape.unDia = [t.texto(res(1)), t.texto(res(4)), t.texto(res(6))];
const porPiso = montar(Tape, { dias: dias3, habitaciones: H.habitaciones(), reservas: H.reservas(), agrupar: 'piso' }).grupos.map(x => [x.nombre, x.catId]);

const Cal = (await import('./js/pages/hotel/calendario.js')).default;
guardado['hotel:cal:dias'] = '14'; const c = montar(Cal, { params: {} });
const cal = { dias14: [c.dias_n, c.inicio, c.fin, c.dias.length] };
guardado['hotel:cal:dias'] = '1'; cal.dias1 = (x => [x.dias_n, x.inicio, x.fin])(montar(Cal, { params: {} }));
guardado['hotel:cal:dias'] = '45'; cal.dias45 = montar(Cal, { params: {} }).dias_n;
cal.desde = montar(Cal, { params: { desde: '2026-12-01' } }).inicio;
cal.sinHab = c.sinHab.map(r => [r.numero, r.cat, r.deposito]); cal.cols = c.colsSinHab.map(x => x.key);
c.cat = 2; cal.sinHabSuite = nums(c.sinHab); cal.vistaSuite = c.listaVista.length; c.cat = null;
c.exportarSinHab();
c.abrir(res(6)); cal.quitar = c.quitar && c.quitar.id; c.bloqueoQuitado(); cal.quitarDespues = c.quitar;
c.abrirPreasignar(c.sinHab[0]); cal.habsPre = [c.habsPre.propias.map(h => h.numero), c.habsPre.otras.map(h => h.numero)];
await c.guardarPreasignar(); cal.sinElegir = [!!c.pre, res(2).habitacion_id];                                 // sin habitación elegida no guarda
c.pre.habitacion_id = 13; await c.guardarPreasignar();
cal.pre = { hab: res(2).habitacion_id, preasignada: res(2).preasignada, historial: res(2).historial.at(-1).texto, cerrado: c.pre === null, quedan: nums(c.sinHab), marca: H.marcasReserva(res(2), {}) };
Cal.watch.dias_n.call(c, 1, 15); cal.aUnDia = [c.inicio, guardado['hotel:cal:dias']];
c.inicio = '2027-01-10'; Cal.watch.dias_n.call(c, 1, 15); cal.lejos = c.inicio;
// el servidor rechaza la preasignación (otra recepción tomó la habitación): no queda nada cambiado
c.abrirPreasignar(res(3)); c.pre.habitacion_id = 12; fallar = true; await c.guardarPreasignar();
cal.rechazo = { abierto: !!c.pre, hab: res(3).habitacion_id, preasignada: res(3).preasignada === true }; c.pre = null;

// ---- H6: bloqueos en lote
const antes = H.reservas().length; envios = 0;
const b1 = H.crearBloqueos([11, 21, 11, null], '2026-12-01', '2026-12-04', '  Remodelación piso 1 ', 'remodelacion'); const ok1 = await b1.promesa;
const lote = { ok: ok1, envios, regs: b1.regs.map(x => [x.id, x.tipo, x.estado, x.habitacion_id, x.llegada, x.salida, x.motivo, x.motivo_tipo, x.numero, x.usuario, 'origen' in x]), mismoLote: new Set(b1.regs.map(x => x.lote)).size === 1 && /^[0-9a-f-]{36}$/.test(b1.regs[0].lote),
  guardados: H.reservas().length - antes, deLote: H.bloqueosDeLote(b1.regs[0].lote).length, sinMotivo: H.crearBloqueos([12], '2026-12-10', '2026-12-11', '', 'uso_interno').regs[0].motivo };
envios = 0; fallar = true; const b2 = H.crearBloqueos([12, 13], '2027-01-01', '2027-01-03', 'Pintura', 'mantenimiento'); const ok2 = await b2.promesa;
lote.rechazo = { ok: ok2, quedaron: H.reservas().filter(r => r.llegada === '2027-01-01').length, n: b2.regs.length };
lote.invalidos = [await H.crearBloqueos([], '2026-12-01', '2026-12-02').promesa, await H.crearBloqueos([11], '2026-12-02', '2026-12-02').promesa, H.crearBloqueos([11], '', '2026-12-02').regs.length];
const total = H.reservas().length;
lote.quitar = [await H.quitarBloqueos([b1.regs[0].id, 1]), total - H.reservas().length, !!res(1), await H.quitarBloqueos([999]), await H.quitarBloqueos([1])];
fallar = true; lote.quitarRechazado = [await H.quitarBloqueos([b1.regs[1].id]), !!res(b1.regs[1].id)];
lote.motivos = [H.MOTIVOS_BLOQUEO.map(x => x[0]), H.nombreMotivoBloqueo('uso_interno'), H.nombreMotivoBloqueo('x'), H.nombreMotivoBloqueo(undefined)];

const M = await import('./js/pages/hotel/_bloqueo.js');
const m = montar(M.default, { lista: H.reservas(), habs: H.habitaciones(), habInicial: 13 });
const cuadro = { fechas: [m.desde, m.hasta, m.fechasOk, m.cubreHoy], libres: m.libres.map(h => h.numero), pisos: m.pisos.map(p => [p.piso, p.ids, p.cats.map(x => [x.nombre, x.habs.map(h => h.numero)])]), cats: m.cats.map(x => [x.nombre, x.ids]), elegidas: m.elegidas.slice() };
m.marcarGrupo(m.cats[1].ids, true); cuadro.conSuite = [m.elegidas.slice(), m.todasDe(m.cats[0].ids), m.todasDe(m.cats[1].ids)];
m.hasta = '2026-11-12'; cuadro.tresNoches = [m.libres.map(h => h.numero), m.elegidas.slice(), m.sel.slice()];   // del 9 al 12 ninguna está libre todas las noches: lo marcado no cuenta
m.hasta = '2026-11-10'; m.motivo = 'Remodelación'; m.motivo_tipo = 'remodelacion'; m.marcar = true;
await m.guardar();
const listo = m.emitidos[0], habs = Object.fromEntries(D.hotel_habitaciones.map(h => [h.numero, h]));
cuadro.listo = [listo[0], listo[1].regs.map(x => [x.habitacion_id, x.motivo, x.motivo_tipo]), listo[1].marcadas, new Set(listo[1].regs.map(x => x.lote)).size];
cuadro.mantenimiento = [habs['201'].estado, habs['201'].estado_usuario, !!habs['201'].estado_hora, habs['103'].estado, 'estado_hora' in habs['103'], habs['101'].estado || ''];
const m2 = montar(M.default, { lista: H.reservas() }); m2.hasta = m2.desde; const malas = [m2.fechasOk, m2.libres.length, m2.cubreHoy]; await m2.guardar(); const e1 = m2.emitidos.length;
m2.hasta = '2026-11-10'; m2.sel = []; await m2.guardar();                                                   // sin habitaciones marcadas tampoco guarda
cuadro.sinGuardar = [malas, e1, m2.emitidos.length, m2.libres.map(h => h.numero), m2.sel];
m2.desde = '2026-11-20'; m2.hasta = '2026-11-22'; cuadro.futuro = [m2.cubreHoy, m2.libres.map(h => h.numero)];
const q = montar(M.QuitarBloqueo, { bloqueo: listo[1].regs[0], lista: H.reservas(), puede: true });
cuadro.quitar = [q.lote.length, q.numerosLote, q.tipoTxt];
await q.quitar(false); cuadro.quitoUna = [q.emitidos[0], H.bloqueosDeLote(listo[1].regs[0].lote).map(x => x.habitacion_id)];
const suelto = montar(M.QuitarBloqueo, { bloqueo: res(6), lista: H.reservas() }); cuadro.suelto = [suelto.lote.length, suelto.tipoTxt];

// ---- H6: Mantenimiento › Fuera de servicio
const b3 = H.crearBloqueos([13, 21], '2026-11-12', '2026-11-14', 'Pintura de pasillo', 'mantenimiento'); await b3.promesa;
D.hotel_reservas.push({ id: 70, tipo: 'bloqueo', estado: 'bloqueo', origen: 'ical', habitacion_id: 11, llegada: '2026-12-20', salida: '2026-12-22', motivo: 'Booking' },
  { id: 71, tipo: 'bloqueo', estado: 'bloqueo', habitacion_id: 11, llegada: '2026-10-01', salida: '2026-10-03', motivo: 'Viejo' });
const F = (await import('./js/pages/hotel/fuera-servicio.js')).default, f = montar(F, { params: {} });
const fuera = { enMant: f.fuera.map(h => h.numero), lotes: f.lotes.map(x => [x.n, x.habs_txt, x.llegada, x.salida, x.motivo, x.tipo_txt, !!x.lote]), bloqueos: f.bloqueos.length };
f.exportar(); f.alternar(f.lotes[0]); fuera.abiertos = f.abiertos.length; f.alternar(f.lotes[0]); fuera.cerrados = f.abiertos.length;
f.abrirBloqueo({ id: 13 }); fuera.abrir = f.bloqueo; f.abrirBloqueo(null); fuera.abrirSin = f.bloqueo; f.bloqueoListo(); fuera.listo = f.bloqueo;
const loteGrande = f.lotes.find(x => x.n > 1); await f.quitarLote(loteGrande); fuera.trasLote = f.lotes.map(x => [x.n, x.habs_txt]);
await f.quitarLote(f.lotes[0]); fuera.trasUno = f.lotes.map(x => [x.n, x.habs_txt]);
fuera.quedan = H.reservas().filter(r => r.tipo === 'bloqueo').map(r => r.id).sort((a, z) => a - z);       // el de iCal y el viejo no se tocan

console.log(JSON.stringify({ marcas, pagos, sinHab, tablero, tareas, alertas09, conPlazo, sinPlazo, dia10, dia11, neta, netaConExtra, cierre, sinFolios, tape, porPiso, cal, lote, cuadro, fuera, exportado: globalThis.__EXPORTADO }));
"""


def _node():
    return shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)


def _sustituto(base, fuentes, ruta):
    """El sustituto de un módulo más, vacías, las exportaciones que los módulos del hotel le piden y él no trae: así una importación
    nueva (de otra tanda) no rompe estas pruebas con «does not provide an export named…»."""
    ya = set(re.findall(r"^export (?:async )?(?:function|const) (\w+)", base, re.M))
    pedidas = set()
    for src in fuentes:
        for mo in re.finditer(r"^import \{([^}]*)\} from '" + re.escape(ruta) + "'", src, re.M):
            pedidas |= {x.strip().split(" as ")[0].strip() for x in mo.group(1).split(",") if x.strip()}
    return base + "".join("export function " + n + "() {}\n" for n in sorted(pedidas - ya))


def _correr(tmp_path, codigo, *modulos):
    """Copia los módulos del hotel a una carpeta con sustitutos de api.js, app.js, _montos.js y pos/_datos.js, y corre la prueba en Node."""
    node = _node()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    fuentes = {m: (HOTEL / m).read_text(encoding="utf-8") for m in ("_datos.js",) + modulos}
    for carpeta in ("hotel", "reportes", "pos"):
        (tmp_path / "js" / "pages" / carpeta).mkdir(parents=True)
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "js" / "api.js").write_text(_sustituto(API_JS, fuentes.values(), "../../api.js"), encoding="utf-8")
    (tmp_path / "js" / "app.js").write_text(_sustituto(APP_JS, fuentes.values(), "../../app.js"), encoding="utf-8")
    (tmp_path / "js" / "pages" / "reportes" / "_montos.js").write_text(_sustituto(MONTOS_JS, fuentes.values(), "../reportes/_montos.js"), encoding="utf-8")
    (tmp_path / "js" / "pages" / "pos" / "_datos.js").write_text(_sustituto(POS_JS, fuentes.values(), "../pos/_datos.js"), encoding="utf-8")
    for m, src in fuentes.items():
        (tmp_path / "js" / "pages" / "hotel" / m).write_text(src, encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(codigo, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


@pytest.fixture(scope="module")
def rep(tmp_path_factory):
    return _correr(tmp_path_factory.mktemp("hotel_reportes"), PRUEBA_REPORTES, "reportes.js")


@pytest.fixture(scope="module")
def hist(tmp_path_factory):
    return _correr(tmp_path_factory.mktemp("hotel_historico"), PRUEBA_HISTORICO, "historico.js")


@pytest.fixture(scope="module")
def pantalla(tmp_path_factory):
    return _correr(tmp_path_factory.mktemp("hotel_pantalla"), PRUEBA_PANTALLA, "reportes.js")


CAMPOS_CAT = ("total", "ocupadas", "bloqueadas", "sin_asignar", "retenido", "libres", "pct", "tarifa_prom", "n_tarifa")


def _cat(d):
    """Los campos de una categoría que fija esta prueba, en orden (otra tanda puede agregar más sin romperla)."""
    return tuple(d[k] for k in CAMPOS_CAT)


def test_h3_la_reserva_sin_habitacion_resta_en_su_categoria(rep):
    d = rep["d10"]
    # Estándar: 3 activas; la 101 ocupada, la 102 bloqueada y una «asignar al llegar» → 0 libres. La 4 pidió Estándar pero cuenta en la Suite donde duerme
    assert _cat(d["porCat"]["1"]) == (3, 1, 1, 1, 0, 0, 67, 90, 2)
    # Suite: 1 activa (la 202 no cuenta), ocupada por la 4, y dos reservas sin habitación → sobreventa de 2
    assert _cat(d["porCat"]["2"]) == (1, 1, 0, 2, 0, -2, 300, 120, 1)
    assert [d[k] for k in ("total", "ocupadas", "bloqueadas", "sin_asignar", "libres", "pct")] == [4, 2, 1, 3, -2, 125] and sorted(d["porCat"]) == ["1", "2"]
    assert rep["ex10"] == -1                                                             # sin la reserva que se está editando
    assert rep["oc10"] == {"total": 4, "ocupadas": 2, "bloqueadas": 1, "libres": 1, "pct": 50}   # ocupacionDia sigue igual: no ve las «asignar al llegar»
    # hoy: la 103 está en mantenimiento y cuenta como bloqueada (solo hoy: es un estado actual, sin fechas)
    assert _cat(rep["d09"]["porCat"]["1"]) == (3, 1, 1, 0, 0, 1, 33, 100, 1) and rep["d09"]["libres"] == 2
    # real: hoy solo quien está en casa; un día futuro no tiene ocupación real; uno pasado cuenta a quien ya salió
    assert rep["r09"]["ocupadas"] == 1 and rep["r09"]["sin_asignar"] == 0
    assert rep["r10"]["ocupadas"] == 0 and rep["r10"]["sin_asignar"] == 0 and rep["r10"]["bloqueadas"] == 1
    assert rep["r07"]["ocupadas"] == 1 and rep["r07"]["porCat"]["1"]["bloqueadas"] == 0


def test_h3_pronostico_por_tipo(rep):
    t = rep["pron"]
    assert t["cols"] == ["fecha", "libres", "pct_proy", "pct_real", "sin_asignar", "cat_1", "cat_2"]
    assert t["filas"] == [["2026-11-09", 2, 25, 25, 0, 1, 1], ["2026-11-10", -2, 125, None, 3, 0, -2], ["2026-11-11", 2, 50, None, 1, 2, 0], ["2026-11-12", 4, 0, None, 0, 3, 1]]
    assert rep["pronTexto"] == ["10/11/2026", "⚠ -2", "125", "—", "3", 0, "⚠ -2"]              # la sobreventa se marca; los días futuros no tienen ocupación real
    assert t["totales"] == [{"t": "Ocupación proyectada promedio", "v": "50 %"}, {"t": "Ocupación real promedio", "v": "25 %"}, {"t": "Noches sin habitación asignada", "v": "4"}, {"t": "Días con sobreventa", "v": "1"}]


def test_h9_entradas_y_salidas_con_filtros(rep):
    assert rep["llegadas"] == rep["cierreLlegadas"] == ["numero", "huesped_nombre", "hab", "cat", "llegada", "salida", "noches_n", "personas", "origen_txt", "nacionalidad", "plan_txt", "especiales", "estado_txt"]
    assert rep["salidas"] == ["numero", "huesped_nombre", "hab", "cat", "llegada", "salida", "noches_n", "nacionalidad", "plan_txt", "saldo", "estado_txt"]   # Saldo y Estado, al final como siempre
    assert rep["salidaTexto"] == "Huésped 1 · grupo Tour A"                                # el grupo, junto al nombre
    assert rep["sin_filtro"] == ["R-0001", "R-0002", "R-0003", "R-0005", "R-0004"]
    assert rep["f_nac"] == ["R-0002"] and rep["f_plan"] == ["R-0001", "R-0004"] and rep["f_sin"] == ["R-0002", "R-0003", "R-0005"] and rep["f_piso"] == ["R-0004"]
    assert rep["f_grupo"] == ["R-0001"] and rep["f_contrato"] == ["R-0004"] and rep["f_origen"] == ["R-0001"] and rep["f_dos"] == ["R-0001"]
    assert rep["en_casa"] == ["R-0001"]                                                    # los demás reportes no se filtran


def test_h9_la_pantalla_filtra_guarda_la_direccion_y_lo_escribe_al_exportar(pantalla):
    p = pantalla
    # los filtros llegan en la dirección y solo tocan los reportes que los aplican (Huéspedes en casa sigue completo)
    assert p["v1"] == [["llegadas", True, ["R-0002"]], ["salidas", True, ["R-0002"]], ["en_casa", False, ["R-0001"]]] and p["hay1"] is True and p["texto1"] == "Nacionalidad: Canadá"
    o = p["opciones"]
    assert o["nac"] == ["Canadá", "Costa Rica", "Sin indicar"] and o["plan"] == [["1", "Solo habitación"], ["2", "Con desayuno"]] and o["piso"] == ["1", "2", "Sin habitación"] and o["grupo"] == ["Tour A"]
    assert o["canal"][0] == ["directa", "Directa (teléfono, WhatsApp, mostrador)"] and o["canal"][-1] == ["ag3", "Contrato: Viajes QA"] and len(o["canal"]) == 9
    assert p["url1"] == "#/hotel/reportes?rep=llegadas%2Csalidas%2Cen_casa&desde=2026-11-08&hasta=2026-11-12&nac=Canad%C3%A1"
    assert p["v2"][0] == ["llegadas", True, ["R-0004"]] and p["texto2"] == "Plan: Con desayuno · Contrato: Viajes QA"
    assert p["url2"] == "#/hotel/reportes?rep=llegadas&desde=2026-11-08&hasta=2026-11-12&plan=2&canal=ag3"
    assert p["v3"] == [["llegadas", True, ["R-0001", "R-0002", "R-0003", "R-0005", "R-0004"]]] and p["texto3"] == "" and p["url3"] == "#/hotel/reportes?rep=llegadas&desde=2026-11-08&hasta=2026-11-12"
    varios_pdf, varios_xlsx, uno_pdf, uno_xlsx, uno_csv, limpio_pdf = p["descargas"]
    assert varios_pdf["subtitulo"] == "Filtros: Nacionalidad: Canadá · Entradas · Salidas · Huéspedes en casa"
    assert varios_pdf["secciones"] == ["Filtros: Nacionalidad: Canadá · Reservas que llegan en el período (sin canceladas).", "Filtros: Nacionalidad: Canadá · Huéspedes que salen en el período.", "Quién está hospedado ahora, con su saldo."]
    assert varios_xlsx == {"formato": "xlsx", "nombre": "hotel_reportes", "filas": 3, "opts": {"titulo": "Reportes del hotel · Hotel"}}
    assert uno_pdf["titulo"] == "Entradas · Hotel" and uno_pdf["subtitulo"] == "Filtros: Plan: Con desayuno · Contrato: Viajes QA · Reservas que llegan en el período (sin canceladas)." and uno_pdf["filas"] == 1
    assert uno_xlsx == {"formato": "xlsx", "nombre": "hotel_llegadas", "filas": 1, "opts": {"titulo": "Entradas · Plan: Con desayuno · Contrato: Viajes QA"}} and uno_csv["formato"] == "csv" and uno_csv["filas"] == 1
    assert limpio_pdf["subtitulo"] == "Reservas que llegan en el período (sin canceladas)." and limpio_pdf["filas"] == 5      # sin filtros, como antes
    # el enlace de Inicio abre los dos pronósticos, sin filtros que mostrar; sin parámetros, Entradas de hoy
    assert p["inicio"] == [["pronostico", "pronostico_tipo"], False, 4] and p["sinNada"] == [["llegadas", "09/11/2026 al 09/11/2026"]]


def test_h10_ocupacion_por_plan_y_piso(rep):
    hoy, manana = rep["plan_hoy"], rep["plan_manana"]
    assert hoy["cols"] == ["piso", "hab", "huesped_nombre", "adultos", "ninos", "plan_txt", "nacionalidad", "llegada", "salida"]
    assert hoy["filas"] == [["1", "101", "Huésped 1", 2, 1, "Con desayuno", "Costa Rica", "2026-11-08", "2026-11-11"]]     # hoy: solo quien está en casa
    assert hoy["totales"] == [{"t": "Con desayuno", "v": "2 adulto(s) · 1 niño(s)"}, {"t": "Habitaciones", "v": "1"}, {"t": "Piso 1", "v": "1 hab."}]
    # mañana: también las confirmadas y pendientes; por piso y, al final, las que no tienen habitación
    assert [(x[0], x[1], x[2]) for x in manana["filas"]] == [("1", "101", "Huésped 1"), ("2", "201", "Huésped 4"), ("Sin habitación", "—", "Huésped 2"), ("Sin habitación", "—", "Huésped 3"), ("Sin habitación", "—", "Huésped 5")]
    assert manana["totales"] == [{"t": "Con desayuno", "v": "4 adulto(s) · 1 niño(s)"}, {"t": "Solo habitación", "v": "2 adulto(s) · 0 niño(s)"}, {"t": "Sin plan", "v": "4 adulto(s) · 0 niño(s)"}, {"t": "Habitaciones", "v": "5"},
                                 {"t": "Piso 1", "v": "1 hab."}, {"t": "Piso 2", "v": "1 hab."}, {"t": "Sin habitación", "v": "3 hab."}]
    assert rep["f_plan_piso"] == ["R-0002"]


def test_h14a_mano_corriente(rep):
    m = rep["mano"]
    # solo las columnas de los conceptos con movimiento ese día, en el orden de siempre
    assert m["cols"] == rep["manoCierre"] == ["hab", "numero", "huesped", "saldo_ant", "c_hospedaje", "c_pos", "c_eventos", "c_manual", "c_servicio", "total_dia", "pagos_dia", "saldo_final"]
    assert m["filas"] == [["101", "R-0001", "Huésped 1", 63, 113, 22.6, 0, 11.3, 0, 146.9, 30, 179.9],          # saldo anterior: 113 de la noche del 8 menos 50 pagados
                          ["201", "R-0004", "Huésped 4", 0, 0, 0, 0, 56.5, 0, 56.5, 0, 56.5],
                          ["—", "CE-0001", "Boda QA", 0, 0, 0, 226, 0, 20, 246, 0, 246]]                       # la cuenta externa también, al final
    assert rep["manoTexto"] == "USD 63.00"
    assert m["totales"] == [{"t": "Saldo anterior", "v": "USD 63.00"}, {"t": "Hospedaje", "v": "USD 113.00"}, {"t": "Restaurante y bar", "v": "USD 22.60"}, {"t": "Eventos", "v": "USD 226.00"}, {"t": "Otros", "v": "USD 67.80"},
                            {"t": "Servicio 10 %", "v": "USD 20.00"}, {"t": "Total del día", "v": "USD 449.40"}, {"t": "Pagos del día", "v": "USD 30.00"}, {"t": "Saldo final", "v": "USD 482.40"}]
    ayer = rep["mano08"]
    assert ayer["cols"] == ["hab", "numero", "huesped", "saldo_ant", "c_hospedaje", "total_dia", "pagos_dia", "saldo_final"] and ayer["filas"] == [["101", "R-0001", "Huésped 1", 0, 113, 113, 50, 63]]


def test_h14b_facturacion_del_dia(rep):
    f = rep["fact"]
    assert f["cols"] == ["fecha", "consecutivo", "tipo_txt", "cuenta", "hab", "facturado_a", "n", "neto", "iva", "total"]
    assert f["filas"] == [["2026-11-08", "00100001010000000077", "Factura", "R-0009", "102", "Empresa QA S.A.", 2, 200, 26, 226],       # anterior: la salida real de la reserva que cerró con ese comprobante
                          ["2026-11-09", "00100001040000000078", "Tiquete", "R-0001", "101", "Huésped 1", 1, 10, 1.3, 11.3],            # parcial: su facturado_fecha
                          ["2026-11-09", "00100001040000000080", "Tiquete", "R-0004", "201", "Huésped 4", 1, 50, 6.5, 56.5]]            # penalidad por no presentación: la fecha del cargo
    assert f["totales"] == [{"t": "Factura", "v": "USD 226.00"}, {"t": "Tiquete", "v": "USD 67.80"}, {"t": "Total facturado", "v": "USD 293.80"}, {"t": "Comprobantes", "v": "3"}, {"t": "Anteriores sin fecha (no incluidos)", "v": "1"}]
    assert rep["factHoy"] == ["00100001040000000078", "00100001040000000080"]


def test_h8_transporte_tarjeta_y_textos(rep):
    t = rep["transp"]
    assert t["cols"] == ["fecha", "hora", "tipo", "vuelo", "numero", "huesped_nombre", "hab", "personas", "traslado_txt", "traslado_nota"]
    assert t["filas"] == [["2026-11-10", "14:30", "Llegada", "AC 900", "R-0002", "Huésped 2", "—", 2, "No necesita", ""],
                          ["2026-11-11", "09:10", "Salida", "AV 642", "R-0001", "Huésped 1", "101", 3, "Lo da el hotel", "3 maletas"]]   # la cancelada con vuelo no sale
    assert t["totales"] == [{"t": "Llegadas", "v": "1"}, {"t": "Salidas", "v": "1"}, {"t": "Traslados que da el hotel", "v": "1"}]
    assert rep["transpCierre"] == [t["filas"][0]]                                          # el paquete del cierre: hoy y mañana
    assert rep["plan"] == ["Con desayuno", "—"] and rep["traslado"] == ["No necesita", "Lo da el hotel", "No necesita"]
    assert rep["vuelos"] == ["Sale AV 642 09:10", "Llega AC 900 14:30", ""]
    assert 'Vuelo de salida:</span> AV 642 09:10' in rep["tarjeta"] and 'Traslado:</span> Lo da el hotel · 3 maletas' in rep["tarjeta"] and "Vuelo de llegada" not in rep["tarjeta"]
    assert "Vuelo" not in rep["tarjeta2"] and "Traslado" not in rep["tarjeta2"]              # sin datos no agrega renglones
    assert rep["paquete"][:5] == ["informe_diario", "mano_corriente", "llegadas", "salidas", "transporte"] and rep["paqueteElegido"] == ["llegadas", "transporte"]


def test_el_paquete_del_cierre_trae_las_dos_secciones_nuevas_y_el_pdf_se_arma(tmp_path):
    from app import reportes
    j = _correr(tmp_path, PRUEBA_CIERRE, "reportes.js", "cierre.js")
    titulos = [s["titulo"] for s in j["secciones"]]
    assert [t.split(" · ")[0] for t in titulos] == ["Informe diario", "Mano corriente", "Llegadas de hoy y de mañana", "Salidas de hoy y de mañana", "Transporte de hoy y de mañana", "Huéspedes en casa con saldo",
                                                    "Caja de recepción", "Habitaciones por estado", "No presentados del día", "Pendientes al cerrar"]
    assert titulos[1] == "Mano corriente · 3 fila(s)" and titulos[4] == "Transporte de hoy y de mañana · 1 fila(s)"
    mano, transporte = j["secciones"][1], j["secciones"][4]
    assert [c["label"] for c in mano["columnas"]] == ["Hab.", "Cuenta", "Huésped", "Saldo anterior", "Hospedaje", "Restaurante y bar", "Eventos", "Otros", "Servicio 10 %", "Total del día", "Pagos del día", "Saldo final"]
    assert mano["filas"][0] == {"hab": "101", "numero": "R-0001", "huesped": "Huésped 1", "saldo_ant": "USD 63.00", "c_hospedaje": "USD 113.00", "c_pos": "USD 22.60", "c_eventos": "USD 0.00", "c_manual": "USD 11.30",
                                "c_servicio": "USD 0.00", "total_dia": "USD 146.90", "pagos_dia": "USD 30.00", "saldo_final": "USD 179.90"}
    assert mano["totales"][-1] == {"t": "Saldo final", "v": "USD 482.40"} and all(c["num"] for c in mano["columnas"][3:])
    assert transporte["filas"] == [{"fecha": "10/11/2026", "hora": "14:30", "tipo": "Llegada", "vuelo": "AC 900", "numero": "R-0002", "huesped_nombre": "Huésped 2", "hab": "—", "personas": "2", "traslado_txt": "No necesita", "traslado_nota": ""}]
    assert j["elegido"] == ["Llegadas de hoy y de mañana", "Transporte de hoy y de mañana"]     # el hotel que ya eligió su paquete solo ve lo que marcó
    # lo que manda la pantalla cabe en los modelos del servidor y el PDF se arma (resumen + las secciones)
    secciones = [reportes.SeccionIn(**s) for s in j["secciones"]]
    doc = reportes.ReporteIn(titulo="Cierre del día 09/11/2026 · Hotel QA", periodo="09/11/2026", secciones=secciones, archivo="cierre_2026-11-09")
    empresa = types.SimpleNamespace(nombre="Hotel QA S.A.", nombre_comercial="Hotel QA", tipo_id="02", numero_id="3101419419", provincia=None, canton=None, distrito=None, otras_senas="", telefono="", correo="hotel419@example.test")
    pdf = reportes._pdf(doc, empresa, None)
    assert pdf[:5] == b"%PDF-" and len(pdf) > 4000


def test_los_reportes_caben_en_lo_que_admite_el_servidor(rep):
    """app/reportes.py rechaza el PDF con más de 30 columnas, más de 12 totales o más de 300 letras de descripción (va como subtítulo)."""
    for k in NUEVOS:
        assert k in rep["claves"], k
    assert rep["claves"][0] == "llegadas" and len(rep["claves"]) == len(set(rep["claves"])) >= 31    # Entradas sigue primero (es el reporte que abre la pantalla)
    for k, (desc, cols, totales) in rep["limites"].items():
        assert 0 < desc <= 300 and 0 < cols <= 30 and totales <= 12, (k, desc, cols, totales)


def test_h21_criterios_del_historico(hist):
    h = hist
    assert h["entrar"]["ld"] == "2025-11-09" and h["conQ"] == "" and h["conTodo"] == ""    # sin criterios: los últimos 12 meses; con alguno, sin tope
    assert (h["entrar"]["hd"], h["entrar"]["hh"]) == ("2025-11-09", "2026-11-09")
    assert h["defecto"] == ["R-0005", "R-0004", "R-0003", "R-0002"] and h["todo"] == ["R-0005", "R-0004", "R-0003", "R-0002", "R-0001"]   # la más reciente primero; ni bloqueos ni cuentas externas
    assert h["cols"] == ["numero", "huesped_nombre", "nacionalidad", "cat", "hab", "llegada", "salida", "noches_n", "personas", "agencia", "segmento", "estado_txt", "total"]
    assert h["fila2"] == ["R-0002", "Ana Mora", "Costa Rica", "Estándar", "101", "2026-10-01", "2026-10-03", 2, 2, "", "Ocio", "Salió", 200]
    assert h["total4"] == 300 and h["total5"] == 0 and h["textoTotal5"] == "USD 0.00"      # colones a la moneda del hotel; sin total no revienta
    assert h["resumen"] == {"n": 5, "canceladas": 1, "noches": 9, "valor": 800}             # noches y valor sin la cancelada
    assert h["texto"] == "Entrada desde 01/10/2026 · Agencia: Viajes QA · Estado: Cancelada, No llegó"
    assert h["documento"] == ["R-0002", "R-0001"] and h["nombre"] == ["R-0004", "R-0003"] and h["reservante"] == ["R-0004"] and h["numero"] == ["R-0003"]
    assert h["estados"] == ["R-0004", "R-0003"] and h["agencia"] == ["R-0003"] and h["mercado"] == ["R-0002"] and h["origen"] == ["R-0003"]
    assert h["negocio"] == ["R-0004"] and h["agente"] == ["R-0004"] and h["habitacion"] == ["R-0004", "R-0002", "R-0001"] and h["nacionalidad"] == ["R-0004", "R-0003"]
    assert h["grupo"] == ["R-0003"] and h["especiales"] == ["R-0002"] and h["entrada"] == ["R-0003", "R-0002"] and h["salida"] == ["R-0004"] and h["creacion"] == ["R-0003"]
    assert h["combinado"] == ["R-0004"] and h["nada"] == []                                 # los criterios se suman
    assert h["negocios"] == ["Feria"] and h["nacionalidades"] == ["Canadá", "Costa Rica", "Sin indicar"] and h["agentes"] == ["Carla"]


def test_h21_aplicar_deja_los_criterios_en_la_direccion(hist):
    h = hist
    assert h["antes"] == ["R-0005", "R-0004", "R-0003", "R-0002"]                           # lo escrito no cambia el resultado hasta aplicar
    assert h["hash1"] == "/hotel/historico?q=ana&estados=salio" and h["n1"] == ["R-0002", "R-0001"] and h["pendiente1"] is False and h["pendiente2"] is True
    assert h["hash2"] == "/hotel/historico?todo=1" and h["n2"] == ["R-0005", "R-0004", "R-0003", "R-0002", "R-0001"]
    assert h["hash3"] == "/hotel/historico?tab=habitacion&hab=11&hd=2025-11-09&hh=2026-11-09"
    assert h["atras"] == {"tab": "reservas", "q": "bob", "n": ["R-0004", "R-0003"]}        # Atrás: la pantalla toma los criterios de la dirección
    assert h["marcados"] == ["no_show", True, False]
    assert h["exportado"] == [{"nombre": "hotel_historico", "cols": h["cols"], "filas": 5, "opts": {"titulo": "Histórico de reservas", "periodo": ""}},
                              {"nombre": "hotel_historico_habitacion", "cols": h["colsHab"], "filas": 3, "opts": {"titulo": "Histórico de la habitación 101", "periodo": "01/10/2026 al 09/11/2026"}}]


def test_h21_historia_de_una_habitacion(hist):
    p = hist["porHab"]
    assert hist["tabHab"] == "habitacion" and hist["sinElegir"] == 0
    assert hist["colsHab"] == ["tipo", "numero", "huesped", "llegada", "salida", "noches_n", "en_rango", "estado_txt", "hospedaje"]
    assert p["filas"] == [["Estadía", "R-0004", "Bob Roy", "2026-11-08", "2026-11-11", 3, 2, "En casa", 113],    # 2 de sus 3 noches caen en el período; el hospedaje se cargó a otra cuenta
                          ["Bloqueo", "", "Pintura", "2026-10-05", "2026-10-07", 2, 2, "Bloqueo", 0],
                          ["Estadía", "R-0002", "Ana Mora", "2026-10-01", "2026-10-03", 2, 2, "Salió", 226]]
    assert {k: p[k] for k in ("hab", "dias", "ocupadas", "bloqueadas", "pct", "ingreso")} == {"hab": "101", "dias": 40, "ocupadas": 4, "bloqueadas": 2, "pct": 10, "ingreso": 339}


# ============================================================================= tanda 2: calendario, bloqueos en lote y tablero (H4, H15, H6 y H7)
CSS = RAIZ / "app" / "static" / "ui.css"


def test_h4_calendario_vistas_fila_por_tipo_y_pie():
    c = _js("pages/hotel/calendario.js")
    assert "[1,7,15,30,60]" in c and "const VISTAS = [1, 7, 15, 30, 60];" in c and "guardado === 14 ? 15" in c         # la vista guardada de 14 días pasa a 15
    for n in (-30, -15, -7, -1, 1, 7, 15, 30):
        assert '@click="mover(%d)"' % n in c, n
    assert '@click="inicio = dias_n === 1 ? hoyHotel() : domingoAnterior(hoyHotel())"' in c and "setup() { return { hoy, hoyHotel, domingoAnterior }; }," in c
    assert ":resumen-tipo=\"agrupar==='categoria'\"" in c and ':reservas="listaVista"' in c
    t = _js("pages/hotel/_tape.js")
    assert "resumenTipo: Boolean" in t and "ocupacionDia" not in t                                                  # el pie ya no usa la cuenta que ignora las «asignar al llegar»
    assert "porDia() { const cfg = this.cfg; return (this.dias || []).map(d => disponibilidadPorTipo(d, this.reservas, { habs: this.habitaciones, cfg })); }," in t
    assert '<tfoot v-if="!compacto"><tr><td class="hab">Ocupación</td><td v-for="(o, i) in porDia"' in t
    assert '<tr class="tipo" v-if="g.nombre && resumenTipo && g.catId">' in t and "(dias || []).length === 1 ? 'un-dia' : ''" in t
    css = CSS.read_text(encoding="utf-8")
    for regla in (".tape tr.tipo td{", ".tape tr.tipo td.sin b{color:var(--danger)}", ".tape tfoot td.sin b,", ".tape.un-dia th:not(.hab),.tape.un-dia td:not(.hab){min-width:320px}"):
        assert regla in css, regla
    r = _js("pages/hotel/reservaciones.js")
    assert "resumen-tipo" not in r and ' :agrupar="agrupar" compacto ' in r                                         # Reservaciones sigue con la semana compacta


def test_h15_marcas_leyenda_y_tarjeta_sin_habitacion():
    d = _js("pages/hotel/_datos.js")
    assert "export function marcasReserva(r, pagosMap, hoyS) {" in d and "export function pagosPorReserva() {" in d and "export function reservasSinHabitacion(desde, hasta, lista) {" in d
    assert "export function sinHabitacion(" not in d                                                                # chocaría con el computed de la ficha de reserva
    assert "if (r.estado === 'en_casa') return r.salida <= h ? 'sale' : 'casa';" in _funcion(d, "claseEstado")       # claseEstado no cambió
    for f in sorted(HOTEL.glob("*.js")):                                                                            # «check-in en proceso» se pospuso: abrir un cuadro no escribe la reserva
        assert "checkin_iniciado" not in f.read_text(encoding="utf-8"), f.name
    c = _js("pages/hotel/calendario.js")
    metodos = c[c.index("  methods: {"):c.index("  template: `")]
    assert c.count("exportarTabla(") == 1 and "exportarTabla('hotel_sin_habitacion', this.colsSinHab, this.sinHab, { titulo: 'Reservas sin habitación'" in metodos
    assert "anotar({ ...x, habitacion_id: p.habitacion_id, preasignada: true }, 'Preasignada a la hab. ' + nombreHab(p.habitacion_id))" in metodos
    assert "sinHab() { return reservasSinHabitacion(this.inicio, this.fin, this.listaVista)" in c and 'text/csv' not in c
    rec = _js("pages/hotel/recepcion.js")
    llegada = next(x for x in rec.split("\n") if "const { reg, promesa } = cambiarReserva(r.id, x => anotar({ ...x, ...extra, estado: 'en_casa'" in x)
    assert "preasignada: undefined }" in llegada and "garantia: c.garantia" in llegada                                # al hacer el check-in deja de estar preasignada
    # la leyenda es un solo componente y pinta con las clases de las barras: no puede volver a quedar con otros colores
    t = _js("pages/hotel/_tape.js")
    leyenda = t[t.index("export const Leyenda = {"):t.index("export default {")]
    clases = re.findall(r'<i class="res ([\w ]+)"></i>', leyenda)
    css = CSS.read_text(encoding="utf-8")
    assert len(clases) == 9 and "style=" not in leyenda
    for k in sorted(set(" ".join(clases).split())):
        assert ".res." + k + "{" in css, k
    assert ".res.dep{box-shadow:inset 0 -3px 0 #facc15}.res.pre{outline:2px dashed #fff;outline-offset:-3px}" in css and ".leyenda i.res{position:static;" in css
    for arch in ("pages/hotel/calendario.js", "pages/hotel/reservaciones.js"):
        src = _js(arch)
        assert "<Leyenda></Leyenda>" in src and "#15803d" not in src and "import Tape, { Leyenda } from './_tape.js';" in src, arch
    assert ':class="[claseEstado(c.r, hoyS), marcas(c.r)]"' in t and "(this.marcas(r).dep ? '$ ' : '')" in t


def test_h6_un_cuadro_de_bloqueo_y_un_solo_guardado():
    d = _js("pages/hotel/_datos.js")
    f = _funcion(d, "crearBloqueos")
    assert f.startswith("export function crearBloqueos(habIds, desde, hasta, motivo, motivo_tipo) {")
    assert f.count("mock.set('hotel_reservas', acumulada)") == 1 and "crypto.randomUUID()" in f and "guardarReserva(" not in f   # un envío para todo el lote
    assert "tipo: 'bloqueo', estado: 'bloqueo'" in f and "origen" not in f                                          # sin origen 'ical': el Técnico los crea y los quita
    assert "if (!ok) { const altas = new Set(regs.map(x => x.id)); mock.set('hotel_reservas', reservas().filter(x => !altas.has(x.id))); }" in f
    assert "export const MOTIVOS_BLOQUEO = [['mantenimiento', 'Mantenimiento'], ['remodelacion', 'Remodelación'], ['uso_interno', 'Uso interno'], ['otro', 'Otro']];" in d
    assert "export function quitarBloqueos(ids) {" in d
    r, fs = _js("pages/hotel/reservaciones.js"), _js("pages/hotel/fuera-servicio.js")
    assert "import BloqueoModal, { QuitarBloqueo } from './_bloqueo.js';" in r and "import BloqueoModal from './_bloqueo.js';" in fs
    for src in (r, fs):
        assert "guardarBloqueo" not in src and "habsBloqueo" not in src and "guardarReserva" not in src and '<BloqueoModal v-if="bloqueo" :lista="lista" :habs="habs"' in src
    assert ">Bloquear habitaciones</button>" in r and "abrirDesdeCalendario(r) { if (r.tipo === 'bloqueo') { this.quitar = r; return; } this.abrir(r); }," in r
    metodos = fs[fs.index("  methods: {"):fs.index("  template: `")]
    assert fs.count("exportarTabla(") == 1 and "exportarTabla('hotel_bloqueos', cols, filas, { titulo: 'Bloqueos de habitaciones'" in metodos
    assert "hoy()" not in fs and "bloqueos() { const h = hoyHotel()," in fs and "{{g.n > 1 ? 'Quitar el lote' : 'Quitar'}}" in fs   # la fecha del hotel, no la del calendario
    crudo = (HOTEL / "fuera-servicio.js").read_bytes()
    assert crudo.count(b"\r\n") == crudo.count(b"\n") > 60                                                          # conserva sus finales de línea (CRLF)
    b = _js("pages/hotel/_bloqueo.js")
    assert "props: { lista: Array, habs: Array, habInicial: { type: Number, default: null } }," in b and b.count("emits: ['listo', 'cerrar'],") == 2
    assert "crearBloqueos(ids, this.desde, this.hasta, this.motivo, this.motivo_tipo)" in b and 'label="Además marcarlas en mantenimiento"' in b and "export const QuitarBloqueo = {" in b
    cal = _js("pages/hotel/calendario.js")
    assert "import { QuitarBloqueo } from './_bloqueo.js';" in cal and "abrir(r) { if (r.tipo === 'bloqueo') { this.quitar = r; return; }" in cal


def test_h7_tablero_en_inicio_y_alertas_en_recepcion():
    d = _js("pages/hotel/_datos.js")
    for firma in ("alertasHotel(fecha, lista, cfg)", "tareasHotel(fecha)", "tableroHotel(fecha)"):
        assert "export function " + firma + " {" in d, firma
    assert d.index("export function listasDelDia(") < d.index("export function alertasHotel(") < d.index("// ---- mensajes")
    assert "export const HORAS_TAREA_ATRASADA = 24;" in d
    a = _funcion(d, "alertasHotel")
    assert "disponibilidadPorTipo(f, todas, { habs, cfg: c })" in a and "fechaHotelActiva() && hoyHotel() < hoy()" in a
    ini = _js("pages/inicio.js")
    assert "hoyT: H.tableroHotel(H.hoyHotel())" in ini and "from './hotel/_datos.js'" not in ini and "import('./hotel/_datos.js')" in ini
    assert "const veMontos = sesion.puede('escribir') || sesion.puede('cobros') || sesion.puede('facturar') || sesion.puede('ver_todo');" in ini
    assert "hoyS = hoy(), todas = reservasHotel()" in ini                                                           # lo del mes sigue con la fecha del calendario
    bloque = ini[ini.index('<template v-if="r && hg">'):ini.index('<template v-if="r && pg">')]                     # sin resumen (r) no se pinta
    assert "<h2>Hoy <small>" in bloque and "<h2>Alertas y tareas <small>" in bloque and 'v-for="d in hg.hoyT.ingresos8"' in bloque
    assert 'href="#/hotel/ama-de-llaves/incidencias"' in bloque and 'href="#/hotel/mantenimiento/incidencias"' in bloque
    # ADR, RevPAR, RevPOR y la gráfica solo para quien recibe montos (a los demás hotel_folios les llega vacío y saldrían en cero)
    i = bloque.index('<template v-if="hg.veMontos">')
    dinero = bloque[i:bloque.index("</template>", i)]
    assert all(x in dinero for x in ("hg.hoyT.adr", "hg.hoyT.revpar", "hg.hoyT.revpor")) and "Bloqueadas o fuera de servicio" not in dinero
    assert bloque.count("hg.hoyT.adr") == bloque.count("hg.hoyT.revpor") == 1 and '<div class="chart" style="height:110px" v-if="hg.veMontos"' in bloque
    rec = _js("pages/hotel/recepcion.js")
    assert "alertas() { void this.reloj; return alertasHotel(this.hoyS, this.lista, this.cfg); }," in rec and "ocultarAlertas: false" in rec
    assert '<div class="card" v-if="alertas.length && !ocultarAlertas"' in rec and '@click="ocultarAlertas = !ocultarAlertas"' in rec
    assert '<div class="kpis k7">' in rec and "{{ocup.bloqueadas + fueraServicio}}" in rec
    assert ".kpis.k7{grid-template-columns:repeat(7,1fr)}" in CSS.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def t2(tmp_path_factory):
    return _correr(tmp_path_factory.mktemp("hotel_tanda2"), PRUEBA_TANDA2, "_tape.js", "_bloqueo.js", "calendario.js", "fuera-servicio.js")


def test_h15_marcas_de_la_barra_y_reservas_sin_habitacion(t2):
    m = t2["marcas"]
    assert m["r1"] == {"dep": True, "pre": False} and m["r2"] == {"dep": False, "pre": False} and t2["pagos"] == {"1": 80}   # la 1 ya pagó 50 + 30
    # preasignada: solo con habitación y mientras no haga el check-in
    assert m["pre"] == {"dep": False, "pre": True} and m["preSinHab"]["pre"] is False and m["preEnCasa"] == {"dep": True, "pre": False}
    assert m["bloqueo"] == {"dep": False, "pre": False} and m["sinMapa"] == {"dep": False, "pre": False}
    s = t2["sinHab"]
    assert s["semana"] == s["todas"] == ["R-0002", "R-0003", "R-0005"]                      # ni la cancelada ni la cuenta externa
    assert s["noche11"] == ["R-0002"] and s["antes"] == []                                  # la 3 y la 5 salen el 11: esa noche ya no cuentan


def test_h7_indicadores_del_dia(t2):
    t = t2["tablero"]
    assert (t["fecha"], t["moneda"], t["ocupadas"], t["total"], t["pct"]) == ("2026-11-09", "USD", 1, 4, 25)
    # hospedaje de hoy 113; todos los cargos de hoy 449,40 (los mismos de la mano corriente): ADR = 113/1, RevPAR = 113/4, RevPOR = 449,40/1
    assert (t["hospedaje"], t["ingreso"], t["adr"], t["revpar"], t["revpor"]) == (113, 449.4, 113, 28.25, 449.4)
    assert (t["bloqueadas"], t["fuera"]) == (0, 1)                                         # la 103 está en mantenimiento y no tiene bloqueo de fechas
    assert [x["fecha"] for x in t["ingresos8"]] == ["2026-11-0" + str(i) for i in range(2, 10)]
    assert [x["total"] for x in t["ingresos8"]] == [0, 0, 0, 0, 113, 124.3, 113, 449.4] and t["maxIngreso"] == 449.4
    assert t["alertas"] == t2["alertas09"] and t["tareas"] == t2["tareas"]
    # quien no recibe montos: todo en cero y sin alertas de saldo (por eso Inicio no le muestra esos indicadores)
    sf = t2["sinFolios"]
    assert (sf["adr"], sf["revpar"], sf["revpor"], sf["ingreso"]) == (0, 0, 0, 0) and sf["pagos"] == {} and sf["alertas"] == ["sobreventa", "sin_habitacion"]


def test_h7_alertas_del_hotel(t2):
    assert t2["alertas09"] == [
        {"clave": "sobreventa", "nivel": "danger", "texto": "Sobreventa: 1 día de los próximos 14 con más reservas que habitaciones (Suite, desde el 10 nov)",
         "enlace": "#/hotel/reportes?rep=pronostico_tipo&desde=2026-11-09&hasta=2026-11-22"},
        {"clave": "sin_habitacion", "nivel": "warn", "texto": "3 llegadas de hoy o de mañana no tienen habitación asignada", "enlace": "#/hotel/calendario"}]
    cp = {x["clave"]: x for x in t2["conPlazo"]}
    assert list(cp) == ["sobreventa", "sin_habitacion", "adelanto", "tope"]
    assert cp["adelanto"]["texto"] == "1 reserva pendiente tiene vencido el plazo de 3 días para el adelanto" and cp["adelanto"]["enlace"] == "#/hotel/reservaciones?estado=pendiente"
    assert cp["tope"]["texto"] == "1 cuenta en casa supera el tope de USD 100.00"           # la cuenta de la 1 va en 179,90
    assert t2["sinPlazo"] == ["sobreventa", "sin_habitacion"]                               # 8 días de 30 y 179,90 de 500: sin alerta
    d10 = {x["clave"]: x for x in t2["dia10"]}
    assert d10["sucias"] == {"clave": "sucias", "nivel": "warn", "texto": "La habitación 201 tiene llegada hoy y sigue sucia", "enlace": "#/hotel/ama-de-llaves/tablero"}
    assert [(x["clave"], x["texto"]) for x in t2["dia11"]] == [("atrasadas", "4 llegadas de días anteriores siguen sin check-in"), ("salidas_saldo", "1 salida de hoy tiene saldo por cobrar")]
    # tarifa neta: el hospedaje lo paga la agencia y no es saldo del huésped; un consumo suyo sí
    assert t2["neta"] is False and t2["netaConExtra"]["texto"] == "1 salida de hoy tiene saldo por cobrar"
    assert t2["cierre"] == {"clave": "cierre", "nivel": "danger", "texto": "El día 8 nov sigue abierto: falta el cierre del día", "enlace": "#/hotel/cierre"}


def test_h7_tareas_de_ama_de_llaves_y_mantenimiento(t2):
    t = t2["tareas"]
    # 2 pendientes y 1 en proceso; atrasadas: la de hace 3 días, la urgente y el plan preventivo vencido; completada: solo la resuelta hoy
    # en hora de Costa Rica (la resuelta a las 03:00 UTC del 9 fue el 8 por la noche)
    assert (t["pendientes"], t["en_proceso"], t["atrasadas"], t["completadas"], t["preventivo"]) == (2, 1, 3, 1, 1)
    assert t["porModulo"] == {"limpieza": {"pendientes": 1, "en_proceso": 0, "atrasadas": 0, "completadas": 1}, "mantenimiento": {"pendientes": 1, "en_proceso": 1, "atrasadas": 3, "completadas": 0}}


def test_h4_fila_por_tipo_pie_y_vista_de_un_dia(t2):
    t = t2["tape"]
    assert t["grupos"] == [["Estándar", 1, 3], ["Suite", 2, 1]] and t2["porPiso"] == [["Piso 1", None], ["Piso 2", None]]   # la fila por tipo solo al agrupar por categoría
    # libres de cada tipo el 9, el 10 y el 11: las mismas cifras del pronóstico por tipo (la Suite queda en -2 el día 10)
    assert t["libres"] == [[1, 0, 2], [1, -2, 0]]
    assert t["tarifas"] == [["USD 100.00", "USD 90.00", "USD 80.00"], ["—", "USD 120.00", "USD 120.00"]]            # promedio vendido; sin ventas, raya
    assert t["pie"] == [[25, 2], [125, -2], [50, 2]]                                                             # el pie descuenta las «asignar al llegar»
    assert t["tituloTipo"] == "Suite: -2 libre(s) de 1 · 1 ocupada(s) · 2 sin habitación asignada · tarifa promedio vendida USD 120.00"
    assert t["tituloPie"] == "2 ocupada(s) · 3 sin habitación asignada · 1 bloqueada(s) o fuera de servicio · 4 habitaciones"
    assert t["texto1"] == "$ Huésped 1" and t["texto4"] == "Huésped 4" and t["bloqueo"] == "⛔ Pintura" and t["marcas1"] == {"dep": True, "pre": False}
    assert t["titulo1"] == "R-0001 · Huésped 1 · 2026-11-08 al 2026-11-11 · en_casa · con depósito o adelanto"
    assert t["unDia"] == ["$ Huésped 1 · 3 noches · Con desayuno", "Huésped 4 · 2 noches · Con desayuno", "⛔ Pintura"]   # con un solo día, noches y plan


def test_h4_h15_pantalla_del_calendario(t2):
    c = t2["cal"]
    # hoy es lunes 9: 14 días guardados pasan a 15 desde el domingo 8; con un solo día abre en hoy; un valor desconocido vuelve a 30
    assert c["dias14"] == [15, "2026-11-08", "2026-11-22", 15] and c["dias1"] == [1, "2026-11-09", "2026-11-09"] and c["dias45"] == 30 and c["desde"] == "2026-12-01"
    assert c["sinHab"] == [["R-0002", "Estándar", 0], ["R-0003", "Suite", 0], ["R-0005", "Suite", 0]]
    assert c["cols"] == ["numero", "huesped_nombre", "cat", "llegada", "salida", "deposito"]
    assert c["sinHabSuite"] == ["R-0003", "R-0005"] and c["vistaSuite"] == 6                # con el filtro de categoría no cuentan las «asignar al llegar» de otras
    assert t2["exportado"][0] == {"nombre": "hotel_sin_habitacion", "cols": c["cols"], "filas": 3, "opts": {"titulo": "Reservas sin habitación", "periodo": "08/11/2026 al 22/11/2026"}}
    assert c["quitar"] == 6 and c["quitarDespues"] is None                                 # tocar un bloqueo abre su cuadro
    # preasignar la 2 (Estándar, del 10 al 12): solo la 103 está libre esas noches
    assert c["habsPre"] == [["103"], []] and c["sinElegir"] == [True, None]
    assert c["pre"] == {"hab": 13, "preasignada": True, "historial": "Preasignada a la hab. 103", "cerrado": True, "quedan": ["R-0003", "R-0005"], "marca": {"dep": False, "pre": True}}
    assert c["aUnDia"] == ["2026-11-09", "1"] and c["lejos"] == "2027-01-10"               # a un día: muestra hoy si estaba en el período; si no, se queda
    assert c["rechazo"] == {"abierto": True, "hab": None, "preasignada": False}            # el servidor la rechazó: la reserva queda como estaba


def test_h6_crear_y_quitar_bloqueos_en_lote(t2):
    b = t2["lote"]
    assert b["ok"] is True and b["envios"] == 1 and b["guardados"] == 2 and b["deLote"] == 2 and b["mismoLote"] is True      # un solo guardado; la habitación repetida, una vez
    assert b["regs"] == [[10, "bloqueo", "bloqueo", 11, "2026-12-01", "2026-12-04", "Remodelación piso 1", "remodelacion", "BLQ", "qa@example.test", False],
                         [11, "bloqueo", "bloqueo", 21, "2026-12-01", "2026-12-04", "Remodelación piso 1", "remodelacion", "BLQ", "qa@example.test", False]]
    assert b["sinMotivo"] == "Uso interno"                                                  # sin detalle, el nombre del motivo
    assert b["rechazo"] == {"ok": False, "quedaron": 0, "n": 2}                             # el servidor rechazó el lote: no queda ninguna alta local
    assert b["invalidos"] == [False, False, 0]
    assert b["quitar"] == [True, 1, True, False, False]                                     # quita el bloqueo y nunca una reserva, aunque venga su id
    assert b["quitarRechazado"] == [False, True]                                            # si no se pudo quitar, el bloqueo sigue en pantalla
    assert b["motivos"] == [["mantenimiento", "remodelacion", "uso_interno", "otro"], "Uso interno", "", ""]


def test_h6_cuadro_de_bloqueo(t2):
    c = t2["cuadro"]
    assert c["fechas"] == ["2026-11-09", "2026-11-10", True, True]                          # propone la fecha del hotel, una noche
    assert c["libres"] == ["102", "103", "201"] and c["elegidas"] == [13]                   # la 101 tiene huésped; llega marcada la habitación inicial
    assert c["pisos"] == [["1", [12, 13], [["Estándar", ["102", "103"]]]], ["2", [21], [["Suite", ["201"]]]]]
    assert c["cats"] == [["Estándar", [12, 13]], ["Suite", [21]]] and c["conSuite"] == [[13, 21], False, True]
    assert c["tresNoches"] == [[], [], [13, 21]]
    evento, regs, marcadas, lotes = c["listo"]
    assert evento == "listo" and regs == [[13, "Remodelación", "remodelacion"], [21, "Remodelación", "remodelacion"]] and marcadas == [13, 21] and lotes == 1
    # «además en mantenimiento»: la 201 cambia de estado con su hora y usuario; la 103 ya lo estaba y no se toca; las demás, igual
    assert c["mantenimiento"] == ["mantenimiento", "qa@example.test", True, "mantenimiento", False, ""]
    assert c["sinGuardar"] == [[False, 0, False], 0, 0, ["102"], []]                        # con fechas malas o sin habitaciones no guarda nada
    assert c["futuro"] == [False, ["101", "102", "103", "201"]]                             # un bloqueo que no cubre hoy no ofrece el mantenimiento
    assert c["quitar"] == [2, "103, 201", "Remodelación"] and c["quitoUna"][0][0] == "listo" and len(c["quitoUna"][0][1]) == 1 and c["quitoUna"][1] == [21]
    assert c["suelto"] == [0, ""]                                                           # un bloqueo anterior (sin lote) se quita solo


def test_h6_fuera_de_servicio_agrupa_por_lote(t2):
    f = t2["fuera"]
    assert f["enMant"] == ["103", "201"] and f["bloqueos"] == 6                             # ni el de iCal ni el que ya pasó
    assert f["lotes"] == [[1, "201", "2026-11-09", "2026-11-10", "Remodelación", "Remodelación", True], [1, "102", "2026-11-10", "2026-11-11", "Pintura", "", False],
                          [2, "103, 201", "2026-11-12", "2026-11-14", "Pintura de pasillo", "Mantenimiento", True],
                          [1, "201", "2026-12-01", "2026-12-04", "Remodelación piso 1", "Remodelación", True], [1, "102", "2026-12-10", "2026-12-11", "Uso interno", "Uso interno", True]]
    assert t2["exportado"][1] == {"nombre": "hotel_bloqueos", "cols": ["hab", "cat", "llegada", "salida", "noches_n", "tipo_txt", "motivo", "lote_txt", "usuario"], "filas": 6,
                                  "opts": {"titulo": "Bloqueos de habitaciones", "periodo": "Vigentes al 09/11/2026"}}
    assert (f["abiertos"], f["cerrados"]) == (1, 0) and f["abrir"] == {"hab": 13} and f["abrirSin"] == {"hab": None} and f["listo"] is None
    assert f["trasLote"] == [[1, "201"], [1, "102"], [1, "201"], [1, "102"]]                # «Quitar el lote» quita sus dos habitaciones
    assert f["trasUno"] == [[1, "102"], [1, "201"], [1, "102"]] and f["quedan"] == [6, 11, 12, 70, 71]
