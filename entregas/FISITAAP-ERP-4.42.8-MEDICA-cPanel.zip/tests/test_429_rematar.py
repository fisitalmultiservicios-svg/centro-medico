# -*- coding: utf-8 -*-
"""4.29, remate de la verificación: los puntos que se corrigieron antes de entregar.

- H1: al aceptar un pedido en línea, si la comanda salió completa, los platos «sin comanda» de esa ronda también quedan marcados
  (en Punto de venta › Cocina la comanda se ve «Impresa» y no se vuelve a imprimir por costumbre).
- H2: si la primera lectura de la impresión falló, Pedidos la vuelve a intentar (al aceptar y en cada recarga).
- H3: la ventana de las impresoras «del navegador» se abre en el toque de «Aceptar» (Safari bloquea la que se abre después de esperar).
- H4: si guardar lo pendiente antes de pedir el número falla, el error sube (no se deshace en silencio el pago aprobado).
- H5: dos equipos que aceptan el mismo pedido a la vez: uno solo lo confirma, crea la cuenta y gasta el número.
- H8: en Cocina, «Imprimir» de una comanda impresa en parte saca solo lo que falta.
- T1: dos equipos que crean a la vez la primera cuenta de mesas distintas ya no la duplican (ni pisan la del otro).
- T2: en la venta rápida de una caja de restaurante, cobrar con platos sin enviar manda la comanda una sola vez.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import pathlib

import pytest
from fastapi import HTTPException
from sqlalchemy.exc import OperationalError
from sqlmodel import Session

from app import comandas, modulos, pedidos
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_425_ultimos_pantallas import _node
from tests.test_429_comanda_numero_pantallas import FALSO_API as FALSO_API_CAJA, FALSO_APP as FALSO_APP_CAJA
from tests.test_429_pedido_web_comanda import (FALSO_APP, FALSO_DATOS_COCINA, FALSOS_FIS, NAVEGADOR, PEDIDOS_GUION, _contador, _falsos, _montar_negocio,
                                               _pedido, _pedidos_para_node)

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _metodo(txt: str, cabeza: str) -> str:
    return _tramo(txt, "    " + cabeza, "\n    },\n").strip() + "\n    }"


def _ctx():
    from app import auth
    from app.main import app
    return app.dependency_overrides[auth.contexto]()


def _cuentas_del_pedido(eid, pid):
    with Session(engine_empresa(eid)) as s:
        return [x for x in modulos.leer(s, eid, "pos_espera", []) or [] if isinstance(x, dict) and x.get("pedido_id") == pid]


def _estado(eid, pid):
    with Session(engine_empresa(eid)) as s:
        return s.get(pedidos.Pedido, pid).estado


# ================================================================================================================ H4 (servidor)
def test_h4_si_guardar_lo_pendiente_falla_el_error_sube(api, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "continuo"})
    p = _pedido(c, slug, a, b)
    pedidos_numero = []
    monkeypatch.setattr(comandas, "siguiente", lambda *x, **k: pedidos_numero.append(1) or (1, None))
    with Session(engine_empresa(eid)) as s:
        ped = s.get(pedidos.Pedido, p["id"]); ped.pago_estado = "aprobado"; ped.pago_referencia = "REF-QA-H4"; s.add(ped)

        def ocupada():
            raise OperationalError("COMMIT", {}, Exception("database is locked"))
        monkeypatch.setattr(s, "commit", ocupada)
        with pytest.raises(OperationalError):                 # antes: se tragaba el error, deshacía el pago en memoria y seguía sin prepago
            pedidos._numero_comanda(s, eid, {"modo": "restaurante", "numerar_comanda": "continuo"})
    assert pedidos_numero == []                                # no se pidió número sobre una sesión a medias


# ================================================================================================================ H5 (servidor)
def test_h5_dos_equipos_aceptan_a_la_vez_solo_uno_confirma(api, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante", "numerar_comanda": "continuo"})
    p = _pedido(c, slug, a, b)
    real, segundo = pedidos.a_caja, {}

    def a_caja_con_otro_equipo(s, eid_, ped, n, origen=None):  # 4.31: a_caja recibe el origen de la comanda
        if not segundo:                                        # justo cuando el primero va a crear la cuenta, llega el segundo equipo
            segundo["hecho"] = True
            with Session(engine_empresa(eid)) as s2:
                try:
                    pedidos.cambiar_estado(p["id"], pedidos.EstadoIn(estado="confirmado"), _ctx(), s2); segundo["status"] = 200
                except HTTPException as e:
                    segundo["status"], segundo["detalle"] = e.status_code, e.detail
        return real(s, eid_, ped, n, origen)
    monkeypatch.setattr(pedidos, "a_caja", a_caja_con_otro_equipo)
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert r.status_code == 200, r.text
    assert segundo["status"] == 400 and "solo se confirma un pedido nuevo" in segundo["detalle"], segundo
    cuentas = _cuentas_del_pedido(eid, p["id"])
    assert [x["id"] for x in cuentas] == [r.json()["cuenta_espera_id"]], cuentas      # una sola cuenta en la caja
    assert _contador(eid) == [("continuo", 1)]                                        # un solo número gastado
    assert _estado(eid, p["id"]) == "confirmado"


@pytest.mark.parametrize("error", ["http", "otro"])
def test_h5_si_crear_la_cuenta_falla_el_pedido_vuelve_a_nuevo(api, monkeypatch, error):  # noqa: F811
    c = api
    eid, slug, a, b = _montar_negocio(c, {"modo": "restaurante"})
    p = _pedido(c, slug, a, b)

    def falla(*x, **k):
        if error == "http":
            raise HTTPException(400, "Configure una caja en Punto de venta › Configuración para recibir pedidos")
        raise RuntimeError("falla de prueba")
    monkeypatch.setattr(pedidos, "a_caja", falla)
    if error == "http":
        r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
        assert r.status_code == 400 and "Configure una caja" in r.text
    else:
        with pytest.raises(RuntimeError):
            c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"})
    assert _estado(eid, p["id"]) == "nuevo"                                           # se puede aceptar después
    monkeypatch.undo()
    assert c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}).status_code == 200


# ================================================================================================================ H1, H2, H3 (Pedidos en Node)
def _guion_pedidos(casos: str) -> str:
    g = PEDIDOS_GUION
    g = g.replace("  { producto_id: null, detalle: 'Envío a domicilio', cantidad: 1, enviado: null, ronda: 0 }] };",
                  "  { producto_id: 3, detalle: 'Agua', cantidad: 1, enviado: '2026-11-12T10:00:00', ronda: 1, comanda: 4 },\n"
                  "  { producto_id: null, detalle: 'Envío a domicilio', cantidad: 1, enviado: null, ronda: 0 }] };", 1)
    g = g.replace("if (url === '/api/registros/items_extra') return { datos: {} };", "if (url === '/api/registros/items_extra') return { datos: R.extras || {} };", 1)
    g = g.replace("return [{ id: 1, nombre: 'Casado' }, { id: 2, nombre: 'Refresco' }];", "return [{ id: 1, nombre: 'Casado' }, { id: 2, nombre: 'Refresco' }, { id: 3, nombre: 'Agua' }];", 1)
    assert g.count("'Agua'") == 2 and "R.extras" in g
    return g[:g.index("const out = {};")] + """
Q.ventanas = [];
globalThis.window.open = (u, d) => { Q.abiertas++; Q.llamadas.push('ventana:' + u); if (u === '') { const v = { closed: false, html: '', cerrada: false, document: { open() {}, write(h) { v.html += h; }, close() {} }, close() { v.cerrada = true; } }; Q.ventanas.push(v); return v; } return Q.bloqueada ? null : {}; };
const tick = () => new Promise(r => setImmediate(r));
const out = {};
""" + casos + """
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_h1_h2_h3_aceptar_en_pedidos_en_node(tmp_path):
    BAR = "{ id: 11, nombre: 'Bar', uso: 'comanda', conexion: 'navegador' }"
    casos = """
// H1: Agua es «sin comanda» (impresora 'none'); todo salió: también queda marcada
out.h1 = await caso({ extras: { 3: { impresora_id: 'none' } } }, true);
out.h1_caida = await caso({ extras: { 3: { impresora_id: 'none' } }, rotas: ['Cocina'] }, true);
// H2: la primera lectura falló; al aceptar se intenta otra vez y la comanda sale
out.h2 = await caso({ fallar: ['/api/registros/pos_config'] }, true, async (vm, p) => { const antes = vm.conComanda; R.fallar = null; const ok = await vm.aceptar(p); return [antes, ok]; });
// H2: también la recarga de cada 20 s la vuelve a leer
out.h2_recarga = await caso({ fallar: ['/api/registros/pos_config'] }, true, async (vm) => { const antes = vm.conComanda; R.fallar = null; await vm.cargar(true); for (let i = 0; i < 50 && !vm.impresion; i++) await tick(); return [antes, vm.conComanda]; });
// H3: impresora del navegador y el navegador bloquea la ventana abierta después de esperar: la del toque recibe la comanda
Q.bloqueada = true;
out.h3 = await caso({ impresoras: [%(bar)s] }, true);
out.h3.html = Q.ventanas.map(v => [(v.html.match(/<h1[^>]*>([^<]*)<\\/h1>/) || [])[1] || null, v.cerrada]);
Q.ventanas = [];
out.h3_rechazado = await caso({ impresoras: [%(bar)s], segundo: true }, true);
out.h3_rechazado.ventanas = Q.ventanas.map(v => v.cerrada);
Q.ventanas = [];
out.h3_agente = await caso({}, true);
Q.bloqueada = false; Q.sesion.empresaInfo = { es_local: true };
out.h3_programa = await caso({ impresoras: [%(bar)s] }, true);
Q.sesion.empresaInfo = {};
""" % {"bar": BAR}
    falsos = _falsos({**FALSOS_FIS, "fis/pages/pedidos.js": _pedidos_para_node()})
    r = _node(tmp_path, _guion_pedidos(casos), archivos=("pages/pos/_comandas.js",), falsos=falsos)
    assert r["h1"]["docs"] == ["COMANDA N.º 4"] and r["h1"]["marcas"] == [[0, 1, 2]], r                   # antes: [[0, 1]] y Cocina la veía «sin imprimir»
    assert r["h1"]["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]], r
    assert r["h1_caida"]["marcas"] == [] and r["h1_caida"]["toasts"][0][1] == "err", r                 # si no salió, nada se marca
    h2 = r["h2"]
    assert h2["ok"] == [False, True] and h2["docs"] == ["COMANDA N.º 4"] and h2["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]], r
    assert r["h2_recarga"]["ok"] == [False, True], r
    h3 = r["h3"]
    assert h3["llamadas"].index("ventana:") < h3["llamadas"].index("PUT /api/pedidos/9/estado"), r       # abierta en el toque, antes de esperar
    assert "ventana:blob:x" not in h3["llamadas"] and h3["html"] == [["COMANDA N.º 4", False]], r
    assert h3["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]] and h3["marcas"] == [[0, 1, 2]], r
    assert r["h3_rechazado"]["ventanas"] == [True] and r["h3_rechazado"]["ok"] is False, r                # el otro equipo ya lo aceptó: se cierra
    assert r["h3_agente"]["abiertas"] == 0 and r["h3_agente"]["docs"] == ["COMANDA N.º 4"], r            # todo por el agente: ninguna ventana
    assert "ventana:" not in r["h3_programa"]["llamadas"] and "ventana:blob:x" in r["h3_programa"]["llamadas"], r   # el programa, como estaba


# ================================================================================================================ H8 (Cocina en Node)
def test_h8_cocina_imprime_solo_lo_que_falta_en_node(tmp_path):
    r = _node(tmp_path, NAVEGADOR.replace("Date.prototype", "const Q = globalThis.Q = { toasts: [], llamadas: [], datos: {}, docs: [], htmls: [], abiertas: 0 };\nDate.prototype", 1) + """
const app = await import('./js/app.js');
const K = (await import('./js/pages/pos/cocina.js')).default;
const vm = Object.assign({}, K.data.call({}));
for (const [k, f] of Object.entries(K.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f;
const COC = { id: 'c', nombre: 'Cocina', conexion: 'usb' }, BAR = { id: 'b', nombre: 'Bar', conexion: 'navegador' };
const ticket = (impresoBar, impresoCocina) => ({ key: '5:1', cuenta: { id: 5, nombre: 'Pedido #7 · Ana' }, ronda: 1, comanda: 3, desde: '2026-11-12T16:30:00Z', impresa: !!(impresoBar && impresoCocina),
  origen: { icono: '🌐', nombre: 'En línea' }, lineas: [{ detalle: 'Casado', cantidad: 1, imp: COC, enviado: 'x', ronda: 1, impreso: impresoCocina }, { detalle: 'Limonada', cantidad: 1, imp: BAR, enviado: 'x', ronda: 1, impreso: impresoBar }] });
const correr = async t => { Q.docs = []; Q.htmls = []; Q.abiertas = 0; await vm.imprimir(t); return { cocina: Q.docs.length, bar: Q.htmls.length }; };
const out = { parcial: await correr(ticket(true, false)), nada: await correr(ticket(false, false)), todo: await correr(ticket(true, true)) };
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/cocina.js", "pages/pos/_comandas.js"), falsos=_falsos({"app.js": FALSO_APP, "pages/pos/_datos.js": FALSO_DATOS_COCINA}))
    assert r["parcial"] == {"cocina": 1, "bar": 0}, r      # el bar ya la imprimió al aceptar: no la recibe otra vez
    assert r["nada"] == {"cocina": 1, "bar": 1}, r         # como siempre
    assert r["todo"] == {"cocina": 1, "bar": 1}, r         # reimprimir a propósito (con la pregunta de siempre): todo


# ================================================================================================================ T1 (dos equipos, api.js real)
SERVIDOR_FALSO = """
const S = globalThis.S = { items: [], ultimo: 0, version: 1 };
globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
const resp = j => ({ ok: true, status: 200, headers: { get: () => null }, json: async () => j });
globalThis.fetch = async (url, opt) => {
  const m = (opt && opt.method) || 'GET', body = opt && opt.body ? JSON.parse(opt.body) : null;
  if (url === '/api/registros/versiones') return resp({ pos_espera: S.version });
  if (url === '/api/registros/pos_espera' && m === 'GET') return resp({ datos: JSON.parse(JSON.stringify(S.items)), version: S.version, ultimo_id: S.ultimo });
  if (url === '/api/registros/pos_espera/cambios') {     // como modulos.aplicar_cambios: un alta con un id ya usado recibe otro
    const remap = {}, nuevos = new Set(body.nuevos.map(String));
    S.items = S.items.filter(x => !body.deletes.map(String).includes(String(x.id)));
    for (let x of body.upserts) {
      const existe = S.items.some(y => y.id === x.id);
      if (nuevos.has(String(x.id)) && (existe || x.id <= S.ultimo)) { const n = Math.max(S.ultimo, ...S.items.map(y => y.id)) + 1; remap[String(x.id)] = n; x = { ...x, id: n }; }
      else if (!nuevos.has(String(x.id)) && !existe) continue;   // gana el borrado
      const i = S.items.findIndex(y => y.id === x.id); if (i >= 0) S.items[i] = x; else S.items.push(x);
      S.ultimo = Math.max(S.ultimo, x.id);
    }
    S.version++; return resp({ version: S.version, remap, ultimo_id: S.ultimo });
  }
  return resp(null);
};
"""


def test_t1_dos_equipos_crean_a_la_vez_la_primera_cuenta_en_node(tmp_path):
    k = _js("pages/pos/caja.js")
    persistir = _tramo(k, "    persistirCuenta(devolverId) {", "    ponerEnEspera() {").strip().rstrip(",")
    fuente = persistir + ",\n" + _metodo(k, "seguirIds(key, cambios) {")
    crea = _tramo(k, "  async created() {", "  mounted()")
    assert "this._ids = mock.alCambiarIds ? mock.alCambiarIds((k, c) => this.seguirIds(k, c)) : null;" in crea
    assert "if (this._ids) this._ids();" in _tramo(k, "  beforeUnmount() {", "\n")
    r = _node(tmp_path, SERVIDOR_FALSO + """
Object.assign(globalThis, await import('./js/pages/pos/_fusion.js'));   /* 4.31: la caja usa el módulo de la misma mesa */
const fuente = %s;
const VACIO = () => ({ datos: { pos_espera: [] }, versiones: { pos_espera: 1 }, topes: {}, rango: 0 });   // uno por equipo (cargar se queda con el objeto)
const linea = (d, env) => ({ producto_id: 1, detalle: d, cantidad: 1, precio_unitario: 1000, enviado: env, ronda: env ? 1 : 0 });
function equipo(A, mesa) {
  const toasts = [];
  const M = new Function('mock', 'toast', 'sesion', 'enEspera', 'return {' + fuente + '};')(A.mock, (m, t) => toasts.push([m, t || '']), { usuario: { correo: 'salonero@example.test' } }, () => A.mock.get('pos_espera', []));
  const vm = { espera: [], esperaId: null, nombreEspera: mesa.nombre, mesaActual: mesa, parteNueva: false, clienteId: null, nota: '', servicio: false, servicioPctCuenta: null,
    salonero: '', totales: { total: 1000 }, cfg: { id: 7 }, cobroParcial: null, lineas: [linea('Casado', new Date().toISOString()), linea('Limonada', new Date().toISOString())], toasts };
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  vm.quitar = A.mock.alCambiarIds((key, c) => vm.seguirIds(key, c));
  return vm;
}
const vista = () => S.items.map(x => [x.id, x.nombre, x.lineas.length]).sort((p, q) => p[0] - q[0]);
const out = {};
// 1) los dos envían la primera comanda en el mismo instante (mismo id siguiente); después B vuelve a «Mesas» con un plato más
let A = await import('./js/api.js?equipo=a'), B = await import('./js/api.js?equipo=b');
await A.mock.cargar(VACIO()); await B.mock.cargar(VACIO());
let a = equipo(A, { id: 1, nombre: 'Mesa 1' }), b = equipo(B, { id: 5, nombre: 'Mesa 5' });
a.persistirCuenta(); b.persistirCuenta();
out.locales = [a.esperaId, b.esperaId];
await Promise.all([A.mock.guardarTodo(), B.mock.guardarTodo()]);
out.tras_guardar = [a.esperaId, b.esperaId, b.espera.map(x => x.id)];
b.lineas.push(linea('Postre', null)); b.persistirCuenta(); await B.mock.guardarTodo();
await A.mock.refrescar(['pos_espera']); a.persistirCuenta(); await A.mock.guardarTodo();
out.servidor = vista(); out.avisos = [a.toasts, b.toasts];
// 2) igual, pero B ya trajo la cuenta del otro equipo antes de volver a guardar (con el id viejo la pisaba)
Object.assign(S, { items: [], ultimo: 0, version: 1 });
A = await import('./js/api.js?equipo=c'); B = await import('./js/api.js?equipo=d');
await A.mock.cargar(VACIO()); await B.mock.cargar(VACIO());
a = equipo(A, { id: 1, nombre: 'Mesa 1' }); b = equipo(B, { id: 5, nombre: 'Mesa 5' });
a.persistirCuenta(); b.persistirCuenta();
await Promise.all([A.mock.guardarTodo(), B.mock.guardarTodo()]);
await B.mock.refrescar(['pos_espera']);
b.lineas.push(linea('Postre', null)); b.persistirCuenta(); await B.mock.guardarTodo();
out.pisada = vista(); out.avisos2 = b.toasts;
out.quitar = [a.quitar(), b.quitar()];
console.log(JSON.stringify(out));
process.exit(0);
""" % json.dumps(fuente), archivos=("api.js", "pages/pos/_fusion.js"), falsos={"vendor/vue.esm-browser.prod.min.js": "export const reactive = x => x;\n"})
    assert r["locales"] == [1, 1], r                                                   # el mismo id siguiente en los dos equipos
    assert r["tras_guardar"] == [1, 2, [2]], r                                        # el servidor le dio otro a la de B y B la sigue
    assert r["servidor"] == [[1, "Mesa 1", 2], [2, "Mesa 5", 3]], r                   # una cuenta por mesa (antes: «Mesa 5» dos veces)
    assert r["avisos"] == [[], []], r                                                  # sin «fue cobrada o cerrada en otro equipo»
    assert r["pisada"] == [[1, "Mesa 1", 2], [2, "Mesa 5", 3]], r                     # la Mesa 1 del otro equipo sigue intacta
    assert r["avisos2"] == [] and r["quitar"] == [True, True], r


# ================================================================================================================ T2 (venta rápida, métodos reales)
ARNES_COBRO = """
Date.prototype.toLocaleTimeString = () => '10:30';
const Q = globalThis.Q = { toasts: [], log: [], docs: [], htmls: [], datos: {}, comprobantes: 0, guardados: 0, sinConexion: [] };
const D = await import('./js/pages/pos/_datos.js');
const A = await import('./js/pages/pos/_agente.js');
Object.assign(globalThis, await import('./js/pages/pos/_fusion.js'));   /* 4.31: la caja usa el módulo de la misma mesa */
const mock = { get: (k, d) => (k in Q.datos ? JSON.parse(JSON.stringify(Q.datos[k])) : d), set: (k, v) => { Q.datos[k] = v; return v; }, actualizar(k, f, d) { const v = f(this.get(k, d)); Q.datos[k] = v; return v; },
  nextId: l => Math.max(0, ...(l || []).map(x => +x.id || 0)) + 1, puedeGuardar: () => true, guardarTodo: async () => { Q.guardados++; Q.log.push('guardar-servidor'); return true; } };
Object.assign(globalThis, { mock, enEspera: () => mock.get('pos_espera', []), toast: (m, t) => Q.toasts.push([m, t || '']), sesion: { usuario: { correo: 'caja-429@example.test', nombre: 'Caja' }, empresaInfo: {}, permisos: ['pos'] }, store: { clientes: [] },
  api: async (u, o) => { Q.log.push((o && o.method ? o.method + ' ' : '') + u); if (u === '/api/pos/comanda/numero') return Q.numero(); if (u === '/api/comprobantes') { if (Q.falla) throw Q.falla; Q.comprobantes++; return { id: Q.comprobantes, consecutivo: '0010000104000000000' + Q.comprobantes, total: 1000, tipo_documento: '04', estado: 'aceptado' }; } return {}; },
  money: v => String(v), r2: n => Math.round((+n || 0) * 100) / 100, hoy: () => '2026-11-12', uuid: () => 'u' + Math.random(), nombreMedio: m => m, cajaPorId: () => null, cajaAbierta: () => null, registrarVentaEnCaja() {},
  vistaTrasCobro: D.vistaTrasCobro, modoNumerarComanda: D.modoNumerarComanda, pedirNumeroComanda: (modo, pedir) => D.pedirNumeroComanda(modo, pedir, 80),
  docComanda: A.docComanda, textoNumeroComanda: A.textoNumeroComanda, cargarEquipo: async () => {}, impresoraAqui: x => x, abrirGaveta: async () => {},
  porAgente: imp => !!imp && imp.conexion === 'usb', imprimirAgente: async (imp, doc) => { Q.log.push('comanda:' + imp.nombre + ':' + doc.bloques[0].x); Q.docs.push(doc); },
  esc: s => String(s ?? ''), fmtCant: v => String(v), Blob: class { constructor(p) { Q.htmls.push(p.join('')); } }, URL: { createObjectURL: () => 'blob:x', revokeObjectURL() {} }, window: { open() { return {}; } } });
Object.assign(globalThis, { revisarEstacion() {}, avisarSiPendiente: () => false, guardarResumen() {}, iniciarEstacion() {}, pararEstacion() {} });   /* 4.31: la estación de comandas no es de esta prueba */
%(forma)s
const C = { %(computadas)s };
const M = { %(metodos)s };
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
const plato = (d, env) => ({ producto_id: 1, detalle: d, cantidad: 1, precio_unitario: 1000, tarifa: 13, enviado: env || null, ronda: env ? 1 : 0 });
function caja(estado, cfg) {
  Q.datos = { pos_espera: [] }; Q.toasts = []; Q.log = []; Q.docs = []; Q.comprobantes = 0; Q.guardados = 0; Q.falla = null; Q.sinConexion = []; Q.numero = async () => ({ numero: 7 });
  const vm = Object.assign({ vista: 'venta', mesaActual: null, rapida: true, esperaId: null, nombreEspera: '', espera: [], nota: '', clienteId: null, cliente: null, servicio: false, servicioPctCuenta: null, parteNueva: false,
    salonero: '', caja: null, cobrando: false, cobroParcial: null, prepago: null, cupon: null, puntos: null, autorizado: null, enDolares: false, exoAplica: false, idem: 'i1', productos: [], servicioPct: 0,
    cfg: { id: 7, nombre: 'Caja salón', modo: 'restaurante', imprimir_comanda: true, imprimir_auto: true, enviar_hacienda: false, ...(cfg || {}) },
    lineas: [plato('Casado'), plato('Postre')], totales: { total: 1000, servicio: 0, items: 2 }, pago: { tipo_documento: '04', medios: [{ medio: '01', monto: 1000 }], recibido: null, propina: 0 },
    get pagoTot() { return { ok: true, falta: 0, vuelto: 0 }; }, get cuentaCobro() { return null; },
    destinoDe: () => COCINA, cobroPermitido: async () => true, descuentoDe: () => 0, cabSucursal: () => ({}), quienPuntos: () => null, cuentaPara: () => 'Caja general', difundir() {}, imprimir() { Q.log.push('tiquete'); },
    impresoraTiquete: () => null, cerrarPago() {}, abrirApertura() {}, cargarExistencias() {}, ventaSinConexion(c) { Q.sinConexion.push(c.esperaId); this.cobrando = false; },
    $nextTick: f => f && f(), $refs: {} }, estado || {});
  for (const [n, f] of Object.entries(C)) Object.defineProperty(vm, n, { get: f.bind(vm) });
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const espera = ms => new Promise(r => setTimeout(r, ms));
const foto = vm => ({ log: Q.log.filter(x => !x.startsWith('POST /api/pagos')), comprobantes: Q.comprobantes, comandas: Q.docs.map(d => d.bloques[0].x), cuentas: (Q.datos.pos_espera || []).map(x => [x.nombre, x.lineas.map(l => !!l.enviado)]),
  lineas: vm.lineas.map(l => !!l.enviado), toasts: Q.toasts.map(t => t[0]).filter(t => /^Comanda|No se emitió/.test(t)) });
"""


def _arnes_cobro() -> str:
    from tests.test_429_cobro_botones import _funcion_forma
    k = _js("pages/pos/caja.js")
    linea = lambda nombre: _tramo(k, "    " + nombre, "\n").strip().split("   /*")[0].split("   //")[0].strip().rstrip(",")  # noqa: E731
    computadas = [linea("esRestaurante() {"), linea("numerarComanda() {"), linea("esVentaRapida() {")]
    cobrar = [_tramo(k, "    async cobrar() {", "\n").strip().rstrip(","), _tramo(k, "    cobrarOtro() {", "\n").strip().rstrip(","), _metodo(k, "async cobrarVenta(otra) {"), _metodo(k, "async emitirCobro(otra) {")]
    persistir = _tramo(k, "    persistirCuenta(devolverId) {", "    ponerEnEspera() {").strip().rstrip(",")
    comanda = [_metodo(k, "enviarComanda() {"), _metodo(k, "comandaNumerada(modo,"), _metodo(k, "seguirIds(key, cambios) {"), _metodo(k, "ponerNumeroComanda(e, n) {"), _metodo(k, "async imprimirComanda(grupos, ronda, datos) {"), persistir]
    return ARNES_COBRO % {"forma": _funcion_forma(k), "computadas": ",\n".join(computadas), "metodos": ",\n".join(cobrar + comanda)}


def test_t2_venta_rapida_cobrar_manda_la_comanda_una_vez_en_node(tmp_path):
    r = _node(tmp_path, _arnes_cobro() + """
const out = {};
// venta rápida, F9 sin tocar «Comanda»: sale la comanda (antes del comprobante) y la cuenta no queda en espera
let vm = caja(); await vm.cobrar(); out.rapida = foto(vm);
// F9 y F10 a la vez: un solo cobro y una sola comanda
vm = caja(); await Promise.all([vm.cobrar(), vm.cobrarOtro(), vm.cobrar()]); out.doble = foto(vm);
// el cobro falla: la comanda ya salió y los platos quedan enviados en la cuenta; al reintentar no sale otra vez
vm = caja(); Q.falla = Object.assign(new Error('Error del servidor (500)'), { status: 500 }); await vm.cobrar(); out.falla = foto(vm);
Q.falla = null; await vm.cobrar(); out.reintento = foto(vm);
// caja que numera: el cobro no espera el número; la comanda sale con su número cuando llega
vm = caja(null, { numerar_comanda: 'dia' }); Q.numero = () => new Promise(r => setTimeout(() => r({ numero: 7 }), 30)); await vm.cobrar(); out.num_al_cobrar = foto(vm); await espera(60); out.numerada = foto(vm);
// el servidor no da el número: sale sin número (tope)
vm = caja(null, { numerar_comanda: 'dia' }); Q.numero = () => new Promise(() => {}); await vm.cobrar(); await espera(120); out.sin_numero = foto(vm);
// sin conexión: la venta se guarda para emitirse después, con la cuenta de la comanda
vm = caja(); Q.falla = Object.assign(new Error('Sin conexión con el servidor'), { sinConexion: true }); await vm.cobrar(); out.offline = { ...foto(vm), sinConexion: Q.sinConexion };
// «imprimir la comanda» apagado: se envía (pantalla de cocina) sin imprimir
vm = caja(null, { imprimir_comanda: false }); await vm.cobrar(); out.sin_imprimir = foto(vm);
// lo demás queda como estaba: mesa, para llevar con nombre, caja de mostrador, cobro por partes
vm = caja({ mesaActual: { id: 4, nombre: 'Mesa 4' }, rapida: false, nombreEspera: 'Mesa 4' }); await vm.cobrar(); out.mesa = foto(vm);
vm = caja({ rapida: false, nombreEspera: 'Ana' }); await vm.cobrar(); out.llevar = foto(vm);
vm = caja(null, { modo: 'mostrador' }); await vm.cobrar(); out.mostrador = foto(vm);
vm = caja({ cobroParcial: { cuentaId: 9, parte: 1, de: 2 } }); await vm.cobrar(); out.partes = foto(vm);
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_datos.js", "pages/pos/_agente.js", "pages/pos/_fusion.js"), falsos={"api.js": FALSO_API_CAJA, "app.js": FALSO_APP_CAJA})
    x = r["rapida"]
    assert x["comandas"] == ["COCINA"] and x["comprobantes"] == 1 and x["cuentas"] == [], r
    assert x["log"].index("comanda:Cocina:COCINA") < x["log"].index("guardar-servidor") < x["log"].index("POST /api/comprobantes"), r
    assert x["toasts"] == ["Comanda 1 enviada a Cocina"], r
    assert r["doble"]["comandas"] == ["COCINA"] and r["doble"]["comprobantes"] == 1, r
    f = r["falla"]
    assert f["comandas"] == ["COCINA"] and f["comprobantes"] == 0 and f["cuentas"] == [["Cuenta 1", [True, True]]] and f["lineas"] == [True, True], r
    assert r["reintento"]["comandas"] == ["COCINA"] and r["reintento"]["comprobantes"] == 1 and r["reintento"]["cuentas"] == [], r
    assert r["num_al_cobrar"]["comprobantes"] == 1 and r["num_al_cobrar"]["comandas"] == [], r          # el cobro no esperó el número
    assert r["numerada"]["comandas"] == ["COMANDA N.º 7"] and r["numerada"]["cuentas"] == [], r          # sale con su número; la cuenta cobrada no se resucita
    assert r["sin_numero"]["comandas"] == ["COCINA"] and r["sin_numero"]["comprobantes"] == 1, r
    o = r["offline"]
    assert o["comandas"] == ["COCINA"] and o["sinConexion"] == [1], r
    assert r["sin_imprimir"]["comandas"] == [] and r["sin_imprimir"]["comprobantes"] == 1 and r["sin_imprimir"]["toasts"] == ["Comanda 1 enviada a Cocina"], r
    for k in ("mesa", "llevar", "mostrador", "partes"):
        assert r[k]["comandas"] == [] and "guardar-servidor" not in r[k]["log"] and r[k]["comprobantes"] == 1 and r[k]["lineas"] in ([], [False, False]), (k, r)
