"""3.69: traslado de inventario entre dos empresas del mismo dueño (cédulas distintas) en un paso: factura al costo (+ %) de A a B,
descuento en la bodega de A, compra registrada y entrada a la bodega de B con los productos casados por código o creados."""
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, inventario, modulos, traslados
from app.db import Cliente, Documento, Empresa, Producto, engine, engine_empresa, init_db


@pytest.fixture()
def grupo():
    from app.main import app
    init_db()
    with Session(engine) as s:
        for n in ("Tienda Central QA S.A.", "Tienda Sucursal QA S.A."):
            viejo = s.exec(select(Empresa).where(Empresa.nombre == n)).first()
            if viejo:
                s.delete(viejo); s.commit()
        a = auth.crear_empresa(s, "Tienda Central QA S.A.", "central369@example.test", "3101369001", provincia=1, canton=1, distrito=1, otras_senas="Centro (QA)", actividad="471101",
                               telefono=22221111, tipo_negocio="comercio", factura_electronica=False, correo_automatico=False)
        b = auth.crear_empresa(s, "Tienda Sucursal QA S.A.", "sucursal369@example.test", "3101369002", provincia=2, canton=1, distrito=1, otras_senas="Este (QA)", actividad="471101",
                               telefono=22222222, tipo_negocio="comercio", factura_electronica=False, correo_automatico=False)
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena369@example.test")).first()
        if not u:
            u = auth.Usuario(correo="duena369@example.test", nombre="Dueña 369", password_hash=auth.hash_password("Clave-369-qa"))
            s.add(u); s.commit(); s.refresh(u)
        for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
            s.delete(m)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=a.id, rol="Administrador"))
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=b.id, rol="Administrador")); s.commit()
        s.refresh(a); s.refresh(b); s.refresh(u)
        a_id, b_id = a.id, b.id
        usuario = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=False, nombre=u.nombre)
    # productos: uno con código en ambas (se casa), otro solo en A (se crea en B), uno sin costo
    with Session(engine_empresa(a_id)) as sa:
        p1 = Producto(empresa_id=a_id, codigo="TOR-01", nombre="Tornillo 1/4", cabys="4291000000100", precio=16000, costo=10000, unidad_medida="Unid")
        p2 = Producto(empresa_id=a_id, codigo="MAR-02", nombre="Martillo carpintero", cabys="4291000000100", precio=9000, costo=5000, unidad_medida="Unid", categoria="Herramientas")
        p3 = Producto(empresa_id=a_id, codigo="SIN-03", nombre="Sin costo", cabys="4291000000100", precio=1000, costo=0)
        sa.add(p1); sa.add(p2); sa.add(p3); sa.commit(); sa.refresh(p1); sa.refresh(p2); sa.refresh(p3)
        bod_a = inventario.bodega_principal(sa, a_id)
        for p, cant in ((p1, 200), (p2, 50)):
            inventario.registrar_movimiento(sa, producto=p, bodega_id=bod_a.id, tipo="compra", cantidad=cant, fecha="2026-10-01", costo_unitario=p.costo, referencia="inicial")
        sa.commit()
        ids = {"p1": p1.id, "p2": p2.id, "p3": p3.id, "bod_a": bod_a.id}
    with Session(engine_empresa(b_id)) as sb:
        pb = Producto(empresa_id=b_id, codigo="TOR-01", nombre="Tornillo de un cuarto", cabys="4291000000100", precio=16000, costo=0)
        sb.add(pb); sb.commit(); sb.refresh(pb)
        ids["pb"] = pb.id; ids["bod_b"] = inventario.bodega_principal(sb, b_id).id
    with Session(engine) as s:
        ctx = auth.Contexto(usuario, s.get(Empresa, a_id), "Administrador")
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), a_id, b_id, ids, ctx
    finally:
        app.dependency_overrides.clear()


def _existencia(eid, pid, bid):
    with Session(engine_empresa(eid)) as s:
        ex = s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == pid, inventario.Existencia.bodega_id == bid)).first()
        return float(ex.cantidad) if ex else 0.0


def test_destinos_y_traslado_completo(grupo):
    c, a_id, b_id, ids, ctx = grupo
    d = c.get("/api/traslados/destinos").json()
    assert [x["id"] for x in d] == [b_id] and d[0]["bodegas"] and d[0]["numero_id"] == "3101369002"
    # sin costo no se traslada
    r = c.post("/api/traslados", json={"empresa_destino_id": b_id, "lineas": [{"producto_id": ids["p3"], "cantidad": 1}]})
    assert r.status_code == 400 and "costo" in r.json()["detail"]
    # porcentaje predeterminado
    assert c.put("/api/traslados/config", json={"porcentaje": 5}).json() == {"porcentaje": 5.0}
    r = c.post("/api/traslados", json={"empresa_destino_id": b_id, "bodega_origen_id": ids["bod_a"], "observaciones": "Reposición semanal", "clave_peticion": "t-369-1",
                                       "lineas": [{"producto_id": ids["p1"], "cantidad": 100}, {"producto_id": ids["p2"], "cantidad": 10}]})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["consecutivo"] and j["estado"] == "interno" and j["compra_id_destino"] and not j["error"] and j["porcentaje"] == 5.0
    assert j["productos_creados"] == ["Martillo carpintero"] and j["empresa_destino"] == "Tienda Sucursal QA S.A."
    # 100 × 10.500 + 10 × 5.250 = 1.102.500 + 13 % = 1.245.825
    assert abs(j["total"] - 1245825) < 0.01 and abs(j["impuesto"] - 143325) < 0.01
    # A: factura al cliente = empresa B, inventario descontado
    with Session(engine_empresa(a_id)) as sa:
        doc = sa.get(Documento, j["documento_id"])
        cli = sa.get(Cliente, doc.cliente_id)
        assert doc.tipo_documento == "01" and cli.numero_id == "3101369002" and cli.nombre == "Tienda Sucursal QA S.A." and cli.tipo == "Cliente"
    assert _existencia(a_id, ids["p1"], ids["bod_a"]) == 100 and _existencia(a_id, ids["p2"], ids["bod_a"]) == 40
    # B: proveedor = empresa A, compra registrada con la clave, productos casado y creado, existencias y costo
    with Session(engine_empresa(b_id)) as sb:
        prov = sb.exec(select(Cliente).where(Cliente.empresa_id == b_id, Cliente.numero_id == "3101369001")).first()
        assert prov and prov.tipo == "Proveedor"
        compras = modulos.leer(sb, b_id, "compras", [])
        cp = next(x for x in compras if x["id"] == j["compra_id_destino"])
        assert cp["numero"] == j["consecutivo"] and cp["proveedor_id"] == prov.id and cp["emision"] == "Traslado del grupo" and cp["traslado"] and abs(cp["total"] - 1245825) < 0.01
        assert [l["producto_id"] for l in cp["lineas"]][0] == ids["pb"]           # TOR-01 casó por código aunque el nombre sea distinto
        nuevo = sb.exec(select(Producto).where(Producto.empresa_id == b_id, Producto.codigo == "MAR-02")).first()
        assert nuevo and nuevo.nombre == "Martillo carpintero" and nuevo.precio == 9000 and nuevo.costo == 5250 and nuevo.categoria == "Herramientas"
        assert cp["lineas"][1]["producto_id"] == nuevo.id and cp["lineas"][1]["precio_unitario"] == 5250
        entradas = modulos.leer(sb, b_id, traslados.CLAVE_ENTRADAS, [])
        assert entradas[-1]["empresa_origen"] == "Tienda Central QA S.A." and entradas[-1]["compra_id"] == j["compra_id_destino"] and entradas[-1]["lineas"] == 2
        assert _existencia(b_id, ids["pb"], ids["bod_b"]) == 100 and _existencia(b_id, nuevo.id, ids["bod_b"]) == 10
    # historial en A
    h = c.get("/api/traslados").json()
    assert h["extra_activo"] and h["salidas"][0]["consecutivo"] == j["consecutivo"] and h["salidas"][0]["compra_id_destino"] == j["compra_id_destino"]
    # el mismo formulario reenviado no factura dos veces
    r2 = c.post("/api/traslados", json={"empresa_destino_id": b_id, "bodega_origen_id": ids["bod_a"], "clave_peticion": "t-369-1", "lineas": [{"producto_id": ids["p1"], "cantidad": 100}]})
    assert r2.json()["documento_id"] == j["documento_id"] and _existencia(a_id, ids["p1"], ids["bod_a"]) == 100
    # vinculación cuando la factura llegue a la bandeja de B: se encuentra por la clave
    with Session(engine_empresa(b_id)) as sb:
        assert traslados.compra_por_clave(sb, b_id, "no-existe") is None
        cp["clave"] = "5060211260000" + "0" * 37
        modulos.aplicar_cambios(sb, b_id, "compras", [cp], [], []); sb.commit()
        assert traslados.compra_por_clave(sb, b_id, cp["clave"]) == cp["id"]


def test_extra_del_plan_y_acceso(grupo):
    c, a_id, b_id, ids, ctx = grupo
    with Session(engine) as s:
        a = s.get(Empresa, a_id); a.plan = "com_250"; a.extras = "[]"; s.add(a); s.commit(); s.refresh(a)
    ctx.empresa = a
    r = c.post("/api/traslados", json={"empresa_destino_id": b_id, "lineas": [{"producto_id": ids["p1"], "cantidad": 1}]})
    assert r.status_code == 400 and "Grupo de empresas" in r.json()["detail"]
    assert c.get("/api/traslados").json()["extra_activo"] is False
    with Session(engine) as s:
        a = s.get(Empresa, a_id); a.extras = '["grupo"]'; s.add(a); s.commit(); s.refresh(a)
    ctx.empresa = a
    # sin acceso a B (se quita la membresía) la empresa ya no es destino
    with Session(engine) as s:
        m = s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == ctx.usuario.id, auth.UsuarioEmpresa.empresa_id == b_id)).first()
        s.delete(m); s.commit()
    assert c.get("/api/traslados/destinos").json() == []
    r = c.post("/api/traslados", json={"empresa_destino_id": b_id, "lineas": [{"producto_id": ids["p1"], "cantidad": 1}]})
    assert r.status_code == 400 and "acceso" in r.json()["detail"]
    # con un rol sin gastos en B tampoco
    with Session(engine) as s:
        s.add(auth.UsuarioEmpresa(usuario_id=ctx.usuario.id, empresa_id=b_id, rol="Vendedor")); s.commit()
    assert c.get("/api/traslados/destinos").json() == []
