"""3.72: más liviano y rápido. Las listas grandes se serializan directo y viajan comprimidas sin cambiar su contenido; los
registros se envían como el JSON guardado; el SDK de IA no se importa al arrancar; el catálogo CABYS viaja en csv.gz."""
import gzip
import json
import os
import subprocess
import sys
import types

from sqlmodel import Session, select

from app import auth, cabys, modulos, resumen
from app.db import Documento, Empresa, engine, engine_empresa, init_db
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)


def _ctx():
    from app.main import app
    return app.dependency_overrides[auth.contexto]()


def test_comprobantes_mismo_contenido_y_gzip(api):  # noqa: F811
    c = api
    ctx = _ctx(); eid = ctx.empresa.id
    cli = c.post("/api/clientes", json={"nombre": "Cliente Rendimiento", "tipo": "Cliente", "tipo_id": "01", "numero_id": "101110372"}).json()
    with Session(engine) as s:
        e = s.get(Empresa, eid); e.factura_electronica = False; s.add(e); s.commit(); s.refresh(e)
    ctx.empresa = e
    for i in range(3):
        r = c.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "condicion_venta": "01", "medio_pago": "01", "moneda": "CRC",
                                              "lineas": [{"detalle": f"Servicio {i}", "cabys": "8314100000000", "cantidad": 1, "precio_unitario": 1000 + i, "unidad_medida": "Sp", "es_servicio": True}],
                                              "otros_cargos": [{"tipo": "06", "detalle": "Impuesto de servicio", "porcentaje": 10}] if i == 0 else []})
        assert r.status_code == 200, r.text
    # sin gzip: el contenido es el de siempre (model_dump + total_otros_cargos), ordenado por id descendente
    r = c.get("/api/comprobantes", headers={"Accept-Encoding": "identity"})
    assert r.status_code == 200 and r.headers.get("content-encoding") is None and r.headers["content-type"].startswith("application/json")
    lista = r.json()
    assert len(lista) >= 3 and lista[0]["id"] > lista[1]["id"]
    with Session(engine_empresa(eid)) as s:
        d = s.get(Documento, lista[0]["id"])
        esperado = {**json.loads(json.dumps(d.model_dump(), default=lambda o: o.isoformat())), "total_otros_cargos": resumen.otros_cargos_de(d)}
    assert lista[0] == esperado
    assert any(x["total_otros_cargos"] > 0 for x in lista)
    # con gzip: mismo contenido, comprimido
    r2 = c.get("/api/comprobantes", headers={"Accept-Encoding": "gzip"})
    assert r2.status_code == 200 and r2.headers.get("content-encoding") == "gzip" and r2.headers.get("vary") == "Accept-Encoding"
    assert r2.json() == lista
    # filtro por sucursal con dicts (3.66): un comprobante con sucursal_id queda fuera si la activa es otra
    from app import sucursales as _suc
    suc = types.SimpleNamespace(id=99, codigo=2)
    assert _suc.pertenece({"sucursal_id": 99, "consecutivo": "00100001010000000001"}, suc) and not _suc.pertenece({"sucursal_id": None, "consecutivo": "00100001010000000001"}, suc)
    assert _suc.pertenece({"sucursal_id": None, "consecutivo": "00200001010000000001"}, suc)


def test_registros_como_texto_igual_que_antes(api):  # noqa: F811
    c = api
    ctx = _ctx(); eid = ctx.empresa.id
    # una colección y un valor, como los guarda la aplicación
    assert c.post("/api/registros/compras/cambios", json={"upserts": [{"id": 1, "numero": "FC-0001", "total": 1500.5, "lineas": [{"detalle": "Ñandú · «comillas»", "cantidad": 2}]}], "deletes": [], "nuevos": [1]}).status_code == 200
    assert c.put("/api/registros/numeracion-cotizaciones", json={"datos": {"prefijo": "COT-", "siguiente": 6}}).status_code == 200
    with Session(engine_empresa(eid)) as s:
        datos, vers = modulos.leer_todo(s, eid)
        texto, vers2, _ = modulos.leer_todo_texto(s, eid)
        assert json.loads(texto) == datos and vers2 == vers
        texto_f, vers_f, _ = modulos.leer_todo_texto(s, eid, lambda k: k != "numeracion-cotizaciones")
        assert "numeracion-cotizaciones" not in json.loads(texto_f) and "numeracion-cotizaciones" not in vers_f and "compras" in json.loads(texto_f)
    r = c.get("/api/registros?v=2", headers={"Accept-Encoding": "identity"})
    assert r.status_code == 200 and r.headers.get("content-encoding") is None
    j = r.json()
    assert j["datos"]["compras"][0]["lineas"][0]["detalle"] == "Ñandú · «comillas»" and j["datos"]["numeracion-cotizaciones"] == {"prefijo": "COT-", "siguiente": 6}
    assert set(j) == {"datos", "versiones", "topes", "rango", "parciales"} and j["versiones"]["compras"] >= 1 and "compras" in j["topes"]
    viejo = c.get("/api/registros", headers={"Accept-Encoding": "identity"}).json()
    assert viejo["compras"] == j["datos"]["compras"]
    # comprimido cuando el navegador lo acepta (si pesa más de 1 KB)
    nuevos = [{"id": i, "numero": f"FC-{i:04d}", "total": 1500.5, "notas": "x" * 400} for i in range(2, 8)]
    assert c.post("/api/registros/compras/cambios", json={"upserts": nuevos, "deletes": [], "nuevos": [x["id"] for x in nuevos]}).status_code == 200
    rz = c.get("/api/registros?v=2", headers={"Accept-Encoding": "gzip, deflate"})
    assert rz.headers.get("content-encoding") == "gzip" and len(rz.json()["datos"]["compras"]) == 7 and rz.json()["datos"]["compras"][-1]["notas"] == "x" * 400


def test_ia_no_importa_el_sdk_al_arrancar():
    codigo = "import sys, app.ia; print('anthropic' in sys.modules)"
    r = subprocess.run([sys.executable, "-c", codigo], capture_output=True, text=True, timeout=120, env={**os.environ, "FE_COLA_HILO": "0", "FE_SINC_HILO": "0"})
    assert r.returncode == 0, r.stderr[-500:]
    assert r.stdout.strip().endswith("False")
    from app import ia
    assert ia._sdk() is not None or ia.anthropic is None          # con el paquete instalado, lo trae bajo demanda


def test_cabys_csv_gz_y_zip():
    assert cabys.CSV.exists(), "falta catalogos/cabys.csv.gz (tools/convertir_cabys.py)"
    filas = list(cabys._filas_csv(cabys.CSV))
    assert len(filas) > 20000 and all(len(f) == 8 for f in filas[:50])
    codigos = {f[0] for f in filas}
    assert "9292000000100" in codigos                             # código real del catálogo (usado en las pruebas en vivo)
    # la tarifa cruda se interpreta igual que desde el Excel
    tarifas = {cabys.leer_impuesto(f[2]) for f in filas}
    assert 13.0 in tarifas and 0.0 in tarifas and 1.0 in tarifas
    # la imagen sin referencias ya no viaja
    assert not (cabys.BASE_DIR / "app" / "static" / "img" / "fisitaap.png").exists()


def test_version_recortada(api):  # noqa: F811
    from app import version
    from app.main import app
    c = api
    app.dependency_overrides[auth.solo_usuario] = lambda: _ctx().usuario
    r = c.get("/api/version").json()
    assert len(r["historial"]) <= 12 and r["total"] == len(version.historial()) and r["actual"]["version"] == version.actual()["version"]
    assert len(c.get("/api/version?todo=1").json()["historial"]) == r["total"]
