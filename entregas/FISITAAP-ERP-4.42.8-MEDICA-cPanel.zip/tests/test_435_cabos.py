"""4.35 (cabos sueltos de Usuarios y de la consola).
C1) Configuración › Usuarios: el 🔑 se veía en filas que el servidor no deja restablecer (cuenta traída de otra empresa, que entra a otras
    empresas, administrador del sistema, uno mismo, bloqueada) y al tocarlo daba 409. Ahora GET /api/auth/usuarios manda por persona
    «restablecible» (un sí o un no, nada de las otras empresas), calculado con LA MISMA regla que POST /api/auth/usuarios/{uid}/password
    (auth._no_restablecible) y con una sola consulta para toda la lista; la pantalla muestra el botón solo en esas filas.
C2) Consola › «Nueva cuenta» con el correo de una cuenta huérfana (sin empresas, no es del sistema ni está bloqueada): antes ignoraba la
    contraseña escrita y avisaba «Al entrar por primera vez…». Ahora se trata como nueva (como al autorizarla en la consola) y el aviso dice
    la verdad; las que conservan su contraseña lo dicen. La prueba gratis del sitio (demo.crear_prueba) NUNCA le pone contraseña a una cuenta
    que ya existe.
Todo con usuarios y empresas @example.test creados aquí y borrados al final (fixtures de test_435_usuarios)."""
import copy
import inspect

from sqlalchemy import event
from sqlmodel import Session, select

from app import auth, demo, sitio
from app.db import engine
from test_435_usuarios import (JS, NOMBRE, PROPIA, PW, PW2, SUF, H, _auditoria_con, _crear_entrar_y_quitar, _cuenta, _empresas, _login,  # noqa: F401
                               _miembro, _quitar_de, _sesiones_vivas, _token, _usuario, equipo, mundo)


def _membresia(uid, eid):
    with Session(engine) as s:
        return s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid, auth.UsuarioEmpresa.empresa_id == eid)).first()


# ----------------------------------------------------------------------------- C1) quién se puede restablecer, en la lista
CLAVES_FILA = {"id", "correo", "nombre", "rol", "mfa_activo", "bloqueado", "sucursal_id", "modulos_ocultos", "ultimo_acceso", "mfa_renuncia",
               "admin_sistema", "editable", "restablecible"}


def test_c1_la_lista_dice_a_quien_se_le_restablece(equipo):
    c, ids = equipo
    t1, t2 = _token(ids.a1, ids.e1), _token(ids.a2, ids.e2)
    with Session(engine) as s:
        y = _usuario(s, "compartida.c1"); _miembro(s, y, ids.e1, "Contador"); _miembro(s, y, ids.e2, "Vendedor")
        b = _usuario(s, "bloqueada.c1", bloqueado=True); _miembro(s, b, ids.e1, "Vendedor")
        _miembro(s, s.get(auth.Usuario, ids.p), ids.e1, "Administrador")
        z = _usuario(s, "de.dos.c1"); _miembro(s, z, ids.e2, "Contador")
        yid, bid, zid = y.id, b.id, z.id
    # traída: E1 agrega a Z, que es de E2 («otras»: conserva su contraseña); E2 la quita: hoy E1 es su única empresa, pero no es suya
    r = c.post("/api/auth/usuarios", json={"correo": "de.dos.c1" + SUF, "nombre": "x", "rol": "Vendedor", "password_temporal": PW2}, headers=H(t1))
    assert r.status_code == 200 and r.json()["motivo"] == "otras", r.text
    assert c.delete(f"/api/auth/usuarios/{zid}", headers=H(t2)).status_code == 200
    assert _empresas(zid) == [ids.e1]
    r = c.get("/api/auth/usuarios", headers=H(t1))
    assert r.status_code == 200, r.text
    filas = {f["id"]: f for f in r.json()}
    esperado = {ids.x: True, ids.v: True, ids.a1: False, yid: False, bid: False, ids.p: False, zid: False}
    assert {k: filas[k]["restablecible"] for k in esperado} == esperado
    # solo un sí o un no: ni el nombre ni el número de las otras empresas
    assert all(set(f) == CLAVES_FILA and type(f["restablecible"]) is bool for f in filas.values())
    assert (NOMBRE + "Dos") not in r.text and "empresas" not in r.text
    # quien no administra usuarios recibe solo id y nombre (sin el campo)
    r = c.get("/api/auth/usuarios", headers=H(_token(ids.v, ids.e1)))
    assert r.status_code == 200 and all(set(f) == {"id", "nombre"} for f in r.json()), r.text
    # la misma regla que la ruta: donde dice que sí, restablece; donde dice que no, la ruta también dice que no y no toca nada
    for uid, f in filas.items():
        antes = _cuenta(f["correo"]).password_hash
        rr = c.post(f"/api/auth/usuarios/{uid}/password", json={}, headers=H(t1))
        if f["restablecible"]:
            assert rr.status_code == 200, (f["correo"], rr.text)
        else:
            assert rr.status_code in (400, 403, 409) and _cuenta(f["correo"]).password_hash == antes, (f["correo"], rr.status_code, rr.text)
    # «uno mismo» es quien mira: el super administrador como soporte no se ve a sí mismo, pero sí al Administrador de la empresa
    filas_p = {f["id"]: f for f in c.get("/api/auth/usuarios", headers=H(_token(ids.p, ids.e1))).json()}
    assert filas_p[ids.p]["restablecible"] is False and filas_p[ids.a1]["restablecible"] is True


def test_c1_una_sola_consulta_para_toda_la_lista(equipo):
    c, ids = equipo
    muchos = []
    with Session(engine) as s:
        for i in range(12):
            x = _usuario(s, f"muchos{i}.c1")
            _miembro(s, x, ids.e1, "Vendedor")
            if i % 3 == 0:
                _miembro(s, x, ids.e2, "Vendedor")
            muchos.append(x.id)
    t1 = _token(ids.a1, ids.e1)
    sql = []

    def anotar(conn, cursor, statement, parameters, context, executemany):
        sql.append(statement.lower())
    event.listen(engine, "before_cursor_execute", anotar)
    try:
        r = c.get("/api/auth/usuarios", headers=H(t1))
    finally:
        event.remove(engine, "before_cursor_execute", anotar)
    assert r.status_code == 200, r.text
    filas = {f["id"]: f for f in r.json()}
    assert [filas[u]["restablecible"] for u in muchos] == [i % 3 != 0 for i in range(12)]
    otras = [q for q in sql if "usuarioempresa.empresa_id !=" in q]
    assert len(otras) == 1 and "group by" in otras[0], otras


def test_c1_la_regla_es_una_sola_para_la_ruta_y_la_lista():
    for f in (auth.restablecer_password_usuario, auth.usuarios_empresa):
        src = inspect.getsource(f)
        assert "_no_restablecible(" in src and "_en_otras_empresas(" in src, f.__name__
    ruta = inspect.getsource(auth.restablecer_password_usuario)
    assert "MENSAJE_CUENTA_TRAIDA" not in ruta and "m.cuenta_traida" not in ruta and "u.es_superadmin" not in ruta and "u.bloqueado" not in ruta


def test_c1_pantalla_muestra_la_llave_solo_si_se_puede():
    sec = (JS / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    usu = sec[sec.index("const SecUsuarios = {"):sec.index("// ------------------------------------------------------------------ Mi perfil")]
    assert '<button class="btn icon" v-if="row.restablecible" @click.stop="restablecer(row)" title="Restablecer contraseña">🔑</button>' in usu
    assert usu.count("restablecer(row)") == 1 and "!esLocal" in usu
    gris = usu[usu.index('<span class="btn icon" v-else'):]
    gris = gris[:gris.index("</span>")]
    assert 'title="La restablece el soporte de FISITAAP"' in gris and "@click" not in gris and "restablecer" not in gris


# ----------------------------------------------------------------------------- C2) «Nueva cuenta» en la consola
def _nueva_cuenta(c, tp, correo, nombre_empresa, pw=PW2, **extra):
    return c.post("/api/admin/cuentas", json={"correo": correo, "password": pw, "nombre_empresa": NOMBRE + nombre_empresa, **extra}, headers=H(tp))


def test_c2_nueva_cuenta_con_una_cuenta_huerfana_la_trata_como_nueva(mundo):
    c, ids = mundo
    t1, tp = _token(ids.a1, ids.e1), _token(ids.p)
    correo = "duena.c2" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t1, correo, _quitar_de(c, t1))   # con PIN, renuncia, intentos fallidos y una sesión abierta
    with Session(engine) as s:
        s.add(auth.TokenApi(empresa_id=ids.e1, usuario_id=uid, nombre="QA 435 cabos", prefijo="fcr_qa435c2", hash="sin-uso-qa-435")); s.commit()
    r = _nueva_cuenta(c, tp, correo, "Nueva C2", nombre_contacto="Persona Nueva")
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["existia"] is True and j["password_aplica"] is True and j["reactivada"] is True and j["motivo"] is None and j["usuario_id"] == uid
    # el aviso dice la verdad: no es su primer ingreso; la temporal vale y lo que le falta al entrar
    assert j["aviso"] != auth.AVISO_PRIMER_INGRESO and "por primera vez" not in j["aviso"]
    assert j["aviso"] == (auth.AVISOS_CUENTA_EXISTENTE["reactivada"] + " Al entrar, el administrador de la cuenta deberá cambiar la contraseña "
                          "temporal, activar la verificación en dos pasos (obligatoria para administradores: necesita una aplicación de códigos en "
                          "su celular) y aceptar los términos del servicio.")
    assert PW2 not in r.text
    u = _cuenta(correo)
    assert auth.verificar_password(PW2, u.password_hash) and u.debe_cambiar_password
    assert u.pin_hash is None and u.pin_fallos == 0 and u.mfa_renuncia_version is None and u.intentos_fallidos == 0 and u.nombre == "Persona Nueva"
    assert _login(c, correo, PROPIA).status_code == 401 and _login(c, correo, PW2).status_code == 200
    assert c.get("/api/auth/sesiones", headers=H(vieja)).status_code == 401         # su sesión de antes quedó cerrada
    with Session(engine) as s:
        assert all(t.revocado for t in s.exec(select(auth.TokenApi).where(auth.TokenApi.usuario_id == uid)).all())
    assert _empresas(uid) == [j["empresa_id"]] and _membresia(uid, j["empresa_id"]).cuenta_traida is False
    assert not _auditoria_con(PW2)
    assert any("contraseña temporal nueva" in (a.detalle or "") for a in _auditoria_con("cuenta_creada") if a.empresa_id == j["empresa_id"])


def test_c2_el_aviso_solo_pide_lo_que_le_falta(mundo):
    """Una cuenta huérfana con la verificación en dos pasos activa y los términos aceptados: solo debe cambiar la contraseña temporal (la
    verificación en dos pasos se conserva). La consola es de confianza: no importa de qué empresa la quitaron."""
    c, ids = mundo
    with Session(engine) as s:
        x = _usuario(s, "con.todo.c2", mfa_activo=True, mfa_secret="SECRETO-QA-435")
        xid = x.id
    r = _nueva_cuenta(c, _token(ids.p), "con.todo.c2" + SUF, "Nueva Todo")
    assert r.status_code == 200 and r.json()["reactivada"] is True, r.text
    assert r.json()["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["reactivada"] + " Al entrar, el administrador de la cuenta deberá cambiar la contraseña temporal."
    u = _cuenta("con.todo.c2" + SUF)
    assert u.mfa_activo and u.mfa_secret == "SECRETO-QA-435" and u.debe_cambiar_password and auth.verificar_password(PW2, u.password_hash)
    assert u.nombre == "con.todo.c2"                                                  # sin nombre de contacto: conserva el suyo
    assert _empresas(xid) == [r.json()["empresa_id"]]


def test_c2_nueva_cuenta_con_una_cuenta_que_conserva_su_contrasena(mundo):
    c, ids = mundo
    tp = _token(ids.p)
    with Session(engine) as s:
        z = _usuario(s, "en.dos.c2"); _miembro(s, z, ids.e2, "Contador")
        b = _usuario(s, "bloqueada.c2", bloqueado=True)
        zid, bid = z.id, b.id
    viva = _token(zid, ids.e2)
    casos = (("en.dos.c2", zid, "otras", "Nueva Otras"), ("bloqueada.c2", bid, "bloqueada", "Nueva Bloqueada"),
             ("sistema", ids.n, "sistema", "Nueva Sistema"))
    for nombre, uid, motivo, empresa in casos:
        correo = nombre + SUF
        antes = _cuenta(correo).password_hash
        r = _nueva_cuenta(c, tp, correo, empresa, nombre_contacto="Otro nombre")
        assert r.status_code == 200, (nombre, r.text)
        j = r.json()
        assert j["existia"] is True and j["password_aplica"] is False and j["reactivada"] is False and j["motivo"] == motivo, (nombre, j)
        assert j["aviso"] == auth.AVISOS_CUENTA_EXISTENTE[motivo] and "no se aplicó" in j["aviso"]
        u = _cuenta(correo)
        assert u.password_hash == antes and not u.debe_cambiar_password and u.nombre == nombre, nombre
        assert _membresia(uid, j["empresa_id"]).cuenta_traida is True                 # traída: la empresa nueva no le restablece la contraseña
    assert c.get("/api/auth/sesiones", headers=H(viva)).status_code == 200            # sus sesiones siguen
    assert _cuenta("bloqueada.c2" + SUF).bloqueado and _login(c, "en.dos.c2" + SUF, PW).status_code == 200
    # una cuenta nueva: como siempre
    r = _nueva_cuenta(c, tp, "nueva.c2" + SUF, "Nueva Nueva")
    j = r.json()
    assert r.status_code == 200 and j["existia"] is False and j["password_aplica"] is True and j["reactivada"] is False and j["motivo"] is None
    assert j["aviso"] == auth.AVISO_PRIMER_INGRESO and _membresia(j["usuario_id"], j["empresa_id"]).cuenta_traida is False


def test_c2_nueva_cuenta_invalida_no_toca_la_cuenta(mundo):
    c, ids = mundo
    t1, tp = _token(ids.a1, ids.e1), _token(ids.p)
    correo = "invalida.c2" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t1, correo, _quitar_de(c, t1))
    antes = _cuenta(correo).password_hash
    assert _nueva_cuenta(c, tp, correo, "Invalida 1", tipo_negocio="taller").status_code == 400     # antes la cuenta se tocaba antes de esto
    assert _nueva_cuenta(c, tp, correo, "Invalida 2", pw="corta").status_code == 400
    u = _cuenta(correo)
    assert u.password_hash == antes and not u.debe_cambiar_password and u.pin_hash is not None and _empresas(uid) == []
    assert c.get("/api/auth/sesiones", headers=H(vieja)).status_code == 200
    with Session(engine) as s:
        assert not s.exec(select(auth.Empresa).where(auth.Empresa.nombre.in_((NOMBRE + "Invalida 1", NOMBRE + "Invalida 2")))).all()  # type: ignore[attr-defined]
    # un correo nuevo con un tipo inválido tampoco deja una cuenta creada a medias
    assert _nueva_cuenta(c, tp, "a.medias.c2" + SUF, "Invalida 3", tipo_negocio="taller").status_code == 400
    assert _cuenta("a.medias.c2" + SUF) is None


def test_c2_pantalla_de_la_consola_no_ofrece_una_contrasena_que_no_se_aplico():
    adm = (JS / "admin.js").read_text(encoding="utf-8")
    crear = adm[adm.index("    async crear() {"):]
    crear = crear[:crear.index("\n    },")]
    assert "r.password_aplica === false" in crear and "la que escribió no se aplicó" in crear and "r.aviso" in crear
    entregar = crear.index("Entregue al cliente")
    assert crear.rindex("else", 0, entregar) > crear.index("r.password_aplica === false")


# ----------------------------------------------------------------------------- C2) la prueba gratis del sitio no toca cuentas existentes
def _limpiar_contacto():
    with auth._lock_ip:
        for k in [k for k in auth._intentos_ip if k.startswith(("contacto:", "prueba_auto:"))]:
            auth._intentos_ip.pop(k, None)


def test_c2_prueba_gratis_nunca_pone_contrasena_a_una_cuenta_existente(mundo, monkeypatch):
    """La cuenta huérfana (la que la consola sí trataría como nueva): registrarse con su correo en la prueba gratis no cambia su contraseña,
    no la deja con temporal, no le manda una ni abre sesión con ella."""
    c, ids = mundo
    t1 = _token(ids.a1, ids.e1)
    correo = "prueba.c2" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t1, correo, _quitar_de(c, t1))
    u0 = _cuenta(correo)
    hash0, debe0, sesiones0 = u0.password_hash, u0.debe_cambiar_password, _sesiones_vivas(uid)
    monkeypatch.delenv("FE_MODO_LOCAL", raising=False)
    cfg = sitio.leer()
    cfg["prueba"] = {**cfg["prueba"], "automatica": True, "dias": 30, "turnstile_sitio": "", "turnstile_secreto": ""}
    monkeypatch.setattr(sitio, "leer", lambda: copy.deepcopy(cfg))        # sin escribir la configuración del sitio
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: object())
    monkeypatch.setattr(sitio, "_avisar", lambda sid: None)
    enviados = []
    monkeypatch.setattr(demo, "_bienvenida", lambda info, nombre: enviados.append(info) or True)
    _limpiar_contacto()
    try:
        r = c.post("/api/contacto", json={"nombre": "Persona C2", "empresa": NOMBRE + "Prueba Web", "cedula": "3101435991", "telefono": "8888-4350",
                                          "correo": correo, "tipo": "comercio", "plan": "Prueba gratis de 1 mes",
                                          "mensaje": "Tienda de prueba de QA para la versión 4.35", "segundos": 20})
    finally:
        _limpiar_contacto()
    assert r.status_code == 200 and r.json() == {"ok": True, "prueba": False, "correo_enviado": False}, r.text
    assert not enviados and "token" not in r.text
    u = _cuenta(correo)
    assert u.password_hash == hash0 and u.debe_cambiar_password == debe0 and _empresas(uid) == [] and _sesiones_vivas(uid) == sesiones0
    # crear_prueba directo (también la usa «Crear prueba» de la consola): con una cuenta que ya existe no genera ni aplica contraseña
    with Session(engine) as s:
        info = demo.crear_prueba(s, correo, "Otra persona", NOMBRE + "Prueba Directa", dias=30)
    assert info["password_temporal"] is None and info["usuario_id"] == uid and "token" not in info
    u = _cuenta(correo)
    assert u.password_hash == hash0 and u.debe_cambiar_password == debe0 and u.nombre == "Persona" and u.pin_hash is not None
    assert _sesiones_vivas(uid) == sesiones0 and c.get("/api/auth/sesiones", headers=H(vieja)).status_code == 200   # su sesión sigue
    assert _login(c, correo, PROPIA).status_code == 200                                # entra con la suya de siempre
    src = inspect.getsource(demo.crear_prueba)
    assert all(x not in src for x in ("_reactivar_huerfana", "_poner_temporal", "_motivo_cuenta_existente", "u.password_hash"))
