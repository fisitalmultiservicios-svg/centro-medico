# -*- coding: utf-8 -*-
"""3.98: reportes en Excel (.xlsx) con formato: números como números, fila de totales, textos que nunca se vuelven fórmulas."""
import io
import types

from openpyxl import load_workbook

from app import reportes


def test_excel_con_numeros_totales_y_sin_formulas_en_textos():
    d = reportes.ExcelIn(titulo="Ventas generales", periodo="Del 01/10/2026 al 31/10/2026", columnas=[
        {"key": "numero", "label": "Número"}, {"key": "cliente", "label": "Cliente"},
        {"key": "subtotal", "label": "Subtotal", "num": True, "sumar": True}, {"key": "total", "label": "Total", "num": True, "sumar": True}],
        filas=[{"numero": "00100001010000005735", "cliente": "MONTEZUMA OPERATIONS SOCIEDAD ANONIMA", "subtotal": 4225.549, "total": "4.774,87"},
               {"numero": "00100001010000005736", "cliente": "=HYPERLINK(\"http://x\")", "subtotal": 150, "total": 169.5}])
    wb = load_workbook(io.BytesIO(reportes._xlsx(d, types.SimpleNamespace(nombre="Hotel QA", nombre_comercial=None))))
    ws = wb.active
    enc = next(r for r in range(1, 10) if ws.cell(row=r, column=1).value == "Número")
    assert ws.cell(row=enc + 1, column=3).value == 4225.549 and ws.cell(row=enc + 1, column=4).value == 4774.87
    assert ws.cell(row=enc + 1, column=1).value == "00100001010000005735"            # el consecutivo queda como texto
    assert ws.cell(row=enc + 2, column=2).data_type == "s"                          # un nombre con «=» no es fórmula
    assert ws.cell(row=enc + 3, column=1).value == "Total" and str(ws.cell(row=enc + 3, column=3).value).startswith("=SUM(")
    assert ws.freeze_panes and ws.auto_filter.ref


def test_pantalla_de_reportes_ofrece_excel():
    import pathlib
    js = (pathlib.Path(reportes.__file__).parent / "static/js/pages/reportes/reporte.js").read_text(encoding="utf-8")
    assert "⤓ Excel" in js and "descargarExcel(" in js
