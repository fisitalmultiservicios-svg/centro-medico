# -*- coding: utf-8 -*-
"""4.32 (§4.4), la estación de comandas DENTRO del programa (con la bandera pedidos_programa): imprime por el servicio de impresión del
propio programa (/api/agente/*), como la Caja del programa, y nunca por el agente suelto del 9800 (que en la computadora del cliente es
otro programa, o nadie). Antes del arreglo la pasada preguntaba solo al 9800 ({ soloAgente: true }): en el programa terminaba en
«sin_agente» y la comanda del pedido en línea no salía (escenario S4 de dos servidores: «la comanda salió UNA sola vez · []»).

- en el programa: la pasada imprime por /api/agente/imprimir, sin una sola petición al 9800, y el plato sale UNA vez con dos pestañas;
- en la página web (y en el programa sin la bandera) nada cambia: la web sigue con el 9800 y sin la bandera la estación no corre."""
from tests.test_425_ultimos_pantallas import _node
from tests.test_431_estacion_pantallas import ARCHIVOS, BASE, _falsos

# el servicio de impresión del programa (/api/agente/*) sobre el servidor falso de la 4.31
PROGRAMA = r"""
const apiWeb = Q.api;
Q.api = async (url, opt) => {
  if (Q.programa && url === '/api/agente/estado') { Q.llamadas.push(url); return { agente: 'FISITAAP Local', version: '4.32' }; }
  if (Q.programa && url === '/api/agente/equipo') { Q.llamadas.push(url); return { equipo: null, empresa_web: true }; }
  if (Q.programa && url === '/api/agente/imprimir') { const b = opt.body; Q.llamadas.push('POST ' + url); if (Q.lento) await Q.lento;
    Q.impresos.push(['local', b.impresora.nombre, ...b.documento.bloques.filter(x => x.t === 'item').map(x => x.x)]); return { ok: true }; }
  return apiWeb(url, opt);
};
"""


def test_en_el_programa_la_estacion_imprime_por_el_propio_programa_y_nunca_por_el_9800(tmp_path):
    r = _node(tmp_path, BASE + PROGRAMA + r"""
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
const reset = () => { S.copias = {}; S.filas = {}; S.t = Date.now(); E._reiniciar(); limpiar(); };
Q.programa = true; Q.agente = false;                                            // en el programa el 9800 no es suyo: no responde
Q.sesion.empresaInfo = { es_local: true, numero_id: '3101123456', pedidos_programa: true };
reset(); copia(1); Q.espera = [cuentaDe(1)];
out.caja = [await E.revisarEstacion('caja'), Q.impresos, Q.fetchs, Q.llamadas.filter(x => x.includes('/api/pos/comanda/')).map(x => /\/api\/\S+/.exec(x)[0]), E.textoEstacion()];
limpiar(); out.otra = [await E.revisarEstacion('caja'), Q.impresos.length];
// desde cualquier pantalla (temporizador de app.js): lo mismo
reset(); copia(2); Q.espera = [];
out.app = [await E.pasoDesdeApp(), Q.impresos, Q.fetchs];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["caja"][0] == "lista", r
    assert r["caja"][1] == [["local", "Cocina", "Casado"]], r                  # por el programa, una vez
    assert r["caja"][2] == [], r                                                # ni una petición al 9800
    assert r["caja"][3] == ["/api/pos/comanda/pendientes", "/api/pos/comanda/reclamar", "/api/pos/comanda/impresa"], r
    assert r["otra"][1] == 0, r                                                 # ya impresa: no sale otra vez
    assert r["app"][0] == "lista" and r["app"][1] == [["local", "Cocina", "Casado"]] and r["app"][2] == [], r


def test_en_el_programa_dos_pestanas_imprimen_la_comanda_una_sola_vez(tmp_path):
    r = _node(tmp_path, BASE + PROGRAMA + r"""
const fs = await import('node:fs');
fs.cpSync('./js', './js2', { recursive: true });                                  // la otra pestaña del programa (otro módulo, otro EQUIPO)
const E = await import('./js/pages/pos/_estacion.js');
const E2 = await import('./js2/pages/pos/_estacion.js');
Q.programa = true; Q.agente = false;
Q.sesion.empresaInfo = { es_local: true, numero_id: '3101123456', pedidos_programa: true };
S.copias = {}; S.filas = {}; S.t = Date.now(); E._reiniciar(); E2._reiniciar(); limpiar();
copia(5); Q.espera = [cuentaDe(5)];
let liberar; Q.lento = new Promise(r => { liberar = r; });
const a = E.revisarEstacion('caja'), b = E2.pasoDesdeApp();                    // la Caja en una pestaña y otra pantalla en la otra
await new Promise(r => setTimeout(r, 50)); liberar(); Q.lento = null;
const out = { dos: [await a, await b, Q.impresos.map(x => x.join(':'))], fetchs: Q.fetchs };
limpiar(); out.despues = [await E.revisarEstacion('caja'), await E2.revisarEstacion('caja'), Q.impresos.length];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["dos"][2] == ["local:Cocina:Casado"], r                            # UNA vez entre las dos pestañas
    assert r["fetchs"] == [] and r["despues"][2] == 0, r


def test_en_la_web_y_sin_la_bandera_nada_cambia(tmp_path):
    r = _node(tmp_path, BASE + PROGRAMA + r"""
const E = await import('./js/pages/pos/_estacion.js');
const out = {};
const reset = () => { S.copias = {}; S.filas = {}; S.t = Date.now(); E._reiniciar(); limpiar(); };
// la página web: el agente suelto del 9800, como en la 4.31 (nunca el /api/agente del servidor)
Q.programa = false; Q.agente = true;
Q.sesion.empresaInfo = { es_local: false, numero_id: '3101123456' };
reset(); copia(1); Q.espera = [cuentaDe(1)];
out.web = [await E.revisarEstacion('caja'), Q.impresos, Q.fetchs.filter(x => x.startsWith('9800/')).map(x => x.split('?')[0]), Q.llamadas.filter(x => x.includes('/api/agente'))];
// la web sin el 9800: no sale sola (como la 4.31)
const A = await import('./js/pages/pos/_agente.js'); Q.agente = false; await A.agenteEstado(true, { soloAgente: true });
reset(); copia(2); Q.espera = [cuentaDe(2)];
out.webSinAgente = [await E.revisarEstacion('caja'), Q.impresos.length, Q.llamadas.filter(x => x.includes('/api/agente'))];
// el programa sin la bandera: la estación no corre
Q.programa = true; Q.sesion.empresaInfo = { es_local: true, numero_id: '3101123456', pedidos_programa: false };
reset(); copia(3); Q.espera = [cuentaDe(3)];
out.sinBandera = [await E.revisarEstacion('caja'), await E.pasoDesdeApp(), Q.llamadas, Q.fetchs];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=ARCHIVOS, falsos=_falsos())
    assert r["web"][0] == "lista" and r["web"][1] == [["Cocina", "Casado"]], r
    assert "9800/imprimir" in r["web"][2] and r["web"][3] == [], r
    assert r["webSinAgente"] == ["sin_agente", 0, []], r
    assert r["sinBandera"] == ["sin_modulo", "sin_modulo", [], []], r
