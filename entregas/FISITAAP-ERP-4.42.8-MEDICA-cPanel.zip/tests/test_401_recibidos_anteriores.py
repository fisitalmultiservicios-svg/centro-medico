# -*- coding: utf-8 -*-
"""4.1: comprobantes recibidos del sistema anterior (Alegra u otro): se cargan como ya respondidos, sin enviar nada a Hacienda,
como diga el Mensaje Receptor que se suba junto (si se sube) y, si se pide, ya pagados."""
import pathlib

from app import recepcion
from tests.test_375_costeo import _xml_proveedor
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)


def _mensaje(clave, mensaje="3", detalle="Mercadería no recibida"):
    return (f'<MensajeReceptor xmlns="https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.4/mensajeReceptor">'
            f'<Clave>{clave}</Clave><NumeroCedulaEmisor>3101123456</NumeroCedulaEmisor><FechaEmisionDoc>2026-10-09T10:00:00-06:00</FechaEmisionDoc>'
            f'<Mensaje>{mensaje}</Mensaje><DetalleMensaje>{detalle}</DetalleMensaje><MontoTotalImpuesto>0</MontoTotalImpuesto>'
            f'<TotalFactura>1</TotalFactura><NumeroCedulaReceptor>3101999999</NumeroCedulaReceptor></MensajeReceptor>').encode()


def _clave(xml):
    return recepcion.parsear(xml)["clave"]


def test_carga_del_sistema_anterior(api):  # noqa: F811
    c = api
    x1, x2, x3 = _xml_proveedor(11, "11111111"), _xml_proveedor(12, "22222222"), _xml_proveedor(13, "33333333")
    # carga normal: queda pendiente de respuesta
    r = c.post("/api/recepcion/cargar", files=[("archivos", ("normal.xml", x3, "text/xml"))])
    assert r.status_code == 200 and r.json()["nuevos"] == 1 and r.json()["historicos"] == 0
    # del sistema anterior: el 1 aceptado (sin mensaje), el 2 rechazado según su Mensaje Receptor, el 3 (ya cargado) también se marca
    r = c.post("/api/recepcion/cargar", data={"historico": "1", "pagados": "1"},
               files=[("archivos", ("a.xml", x1, "text/xml")), ("archivos", ("b.xml", x2, "text/xml")),
                      ("archivos", ("b_respuesta.xml", _mensaje(_clave(x2)), "text/xml")), ("archivos", ("c.xml", x3, "text/xml"))])
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["nuevos"] == 2 and j["duplicados"] == 1 and j["historicos"] == 3 and not j["descartados"]
    por = {x["clave"]: x for x in c.get("/api/recepcion").json()}
    a, b, d = por[_clave(x1)], por[_clave(x2)], por[_clave(x3)]
    assert a["respuesta"] == "05" and a["estado_mensaje"] == "importado" and a["condicion_impuesto"] == "01" and a["pagado_anterior"] is True
    assert a["monto_impuesto_acreditar"] == recepcion.iva_recibido(type("R", (), a)) and a["monto_gasto_aplicable"] == a["total"]
    assert b["respuesta"] == "07" and b["detalle_mensaje"] == "Mercadería no recibida" and b["pagado_anterior"] is None
    assert d["respuesta"] == "05" and d["estado_mensaje"] == "importado"
    assert "no se envía" in a["mensaje_hacienda"]


def test_respondido_aqui_no_se_toca():
    r = recepcion.Recibido(empresa_id=1, clave="5" * 50, total=100, impuesto=13, iva=13, respuesta="05", estado_mensaje="aceptado")
    assert recepcion.marcar_historico(r, None, True) is False and r.estado_mensaje == "aceptado"
    r2 = recepcion.Recibido(empresa_id=1, clave="6" * 50, total=113, impuesto=13, iva=13)
    assert recepcion.marcar_historico(r2, {"mensaje": "2", "condicion": "02", "acreditar": 6.5, "gasto": 106.5}, False)
    assert r2.respuesta == "06" and r2.condicion_impuesto == "02" and r2.monto_impuesto_acreditar == 6.5 and r2.monto_gasto_aplicable == 106.5 and r2.pagado_anterior is False


def test_contabilidad_y_pantalla():
    js = pathlib.Path(recepcion.__file__).parent / "static" / "js" / "pages"
    au = (js / "contabilidad" / "automaticos.js").read_text(encoding="utf-8")
    assert "function asientoCobroAnterior(d, param)" in au and "function asientoPagoAnterior(r, param)" in au
    assert "origen: 'impc:' + d.id" in au and "origen: 'recp:' + r.id" in au and "'impc', 'recp']" in au
    assert "const recOk = r => r.estado_mensaje !== 'importado' || (param.contabilizar_importados === true" in au
    pa = (js / "contabilidad" / "parametros.js").read_text(encoding="utf-8")
    assert "importados_cobro:" in pa and "['Documentos del sistema anterior'" in pa
    rc = (js / "gastos" / "recepcion.js").read_text(encoding="utf-8")
    assert "⤒ Del sistema anterior" in rc and "fd.append('historico', '1')" in rc and "'sistema anterior'" in rc
