# -*- coding: utf-8 -*-
"""4.39, arreglos de la revisión adversaria de 1e (la comanda automática al cobrar la venta rápida y la cuenta guardada sin mesa), 16 nov 2026.

- H1 destinoDe: un cargo sin producto (el «Envío a domicilio» de un pedido en línea: producto_id None y es_servicio) no va a cocina. Las
  partes iguales y las cuentas «aparte» de un pedido sin mesa pierden la marca de pedido (datosCredito da null si no es a crédito) y 1e,
  al cobrarlas, mandaba «0,5 × Envío a domicilio» a cocina. Tampoco sale con «Comanda» sobre la cuenta del pedido.
- H2 emitirCobro: la cuenta que ya estaba en el servidor pide su cobro ANTES de la comanda. Dos equipos con la misma cuenta guardada con
  «Guardar y nueva venta» que la cobran casi a la vez (o uno después del otro sin sincronizar): una comanda y un comprobante. La venta
  rápida nueva (sin cuenta o con el alta pendiente) sigue como antes: comanda, guardado y después el reclamo si corresponde.
- H3 sincronizar y cobroDeCuentaCerrada: si otro equipo cobró la cuenta abierta, en pantalla queda solo lo que esta pantalla agregó sin
  guardar (lo guardado sin enviar ya estaba en la cuenta cobrada): se cobra una vez. También en una cuenta de MESA (sincronizar, 4.31).
- H4 cargarAHabitacion: la venta rápida nueva y la cuenta guardada sin mesa con platos sin enviar sacan su comanda una vez; la cuenta
  guardada, con el cobro ya pedido al servidor (reclamar antes de la comanda).
Cada caso corre también, cuando se puede, con el método de ANTES del arreglo (sacado de caja.js con un reemplazo de texto exacto) y ahí
se ve el defecto: así consta que la prueba lo detecta.
4.39 (segunda vuelta): H2 quedó dentro de un bloque más largo (R2: traer, juntar y comparar antes de la comanda); la cuenta del pedido
también es cuentaRapidaGuardada (R1); el defecto de la caja CON mesas que era xfail quedó arreglado con R4. Las pruebas de R1 a R7 están
en tests/test_439_segunda_vuelta.py.
Límite que queda (no se prueba como defecto): dividir en partes iguales una venta rápida o una cuenta guardada con platos sin enviar
manda a cocina cada porción al cobrarla (0,333 × Pizza).
Los métodos reales de caja.js en dos «equipos» (cada uno con su api.js y su _fusion.js), con el arnés y el servidor falso de
tests/test_431_cobro_reclamo_pantallas.py; destinoDe (caja.js) e impresoraDe (_datos.js) son los reales, con la Cocina como única
impresora de comanda. Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

from tests.test_431_cobro_reclamo_pantallas import _correr
from tests.test_431_misma_mesa_pantallas import _js, _linea, _metodo, _tramo

OCUPADA = "Esta cuenta se está cobrando en otro equipo. Espere unos segundos y revise el total antes de cobrar."
COBRADA = "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."
CERRADA = ("Esta cuenta fue cobrada o cerrada en otro equipo y aquí no se cobró nada. Lo que no se había enviado sigue en pantalla como "
           "venta nueva: revise el total antes de cobrar.")
CASADO, LIMONADA, POSTRE = 3955.0, 1695.0, 1356.0          # con 13 % de IVA
RECLAMAR, SOLTAR, EMITIR, COMANDA = "/api/pos/cobro/reclamar", "/api/pos/cobro/soltar", "/api/comprobantes", "COMANDA"

# los arreglos, tal como están en caja.js (las versiones «de antes» salen de quitarlos o cambiarlos)
H1_GUARDA = "if (l && !l.producto_id && l.es_servicio) return null; "
# 4.39 (segunda vuelta, R2): el bloque de H2 ya no es de una línea: tras pedir el cobro se trae la lista, se junta lo de otro equipo y se
# compara antes de la comanda. H2_BLOQUE es el bloque entero (de su «if» a la línea de la comanda); H2_PIDE, el pedido del cobro adentro
H2_ABRE = "        if (reclamar && mismoId && !alta0) {\n"
H2_PIDE = "rcPedido = true; try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc);"
# 4.39 (tercera vuelta, T3): la comanda del cobro se manda solo si al juntar queda algún plato sin enviar (sin el aviso falso «No hay platos
# nuevos por enviar» en un cobro que sale bien). H2_COMANDA es la línea de ahora; H2_COMANDA_ANTES, la de antes de T3 (la versión «antes de
# H2» la usa tal cual era, sin esa guarda)
H2_COMANDA = "        try { if (this.lineas.some(l => !l.enviado && +l.cantidad > 0)) this.enviarComanda(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }"
H2_COMANDA_ANTES = "        try { this.enviarComanda(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }"
H3_SINC = "const g = lidsDeBase(this._base, this.esperaId), nuevas = this.lineas.filter(l => !l.enviado && !g.has(l.lid));"
H3_CERRADA = "const g = lidsDeBase(this._base, this.esperaId); this.lineas = this.lineas.filter(l => !l.enviado && !g.has(l.lid));"


def _caja() -> str:
    return _js("pages/pos/caja.js")


def _cambiar(texto: str, viejo: str, nuevo: str) -> str:
    assert texto.count(viejo) == 1, viejo
    return texto.replace(viejo, nuevo)


def _antes_h2():
    """emitirCobro sin pedir el cobro antes de la comanda (rcPedido queda en false: el reclamo va después, como antes). 4.39 (segunda vuelta):
    se quita el bloque entero (el pedido del cobro y, con él, lo que R2 le agregó: refrescar, juntar y comparar antes de la comanda).
    4.39 (tercera vuelta): el bloque trae también la espera de T3 (que se va con él) y la línea de la comanda vuelve a ser la de antes de T3."""
    e = _metodo(_caja(), "async emitirCobro(otra) {")
    assert e.count(H2_ABRE) == 1 and e.count(H2_COMANDA) == 1, "falta el bloque de H2"
    i, j = e.index(H2_ABRE), e.index(H2_COMANDA)
    assert H2_PIDE in e[i:j] and "for (let vuelta = 0; ; vuelta++) {" in e[i:j]
    return (_cambiar(e[:i] + e[j:], H2_COMANDA, H2_COMANDA_ANTES),)


def _antes_h3():
    """sincronizar y cobroDeCuentaCerrada dejando en pantalla todo lo no enviado (también lo guardado sin enviar)."""
    k = _caja()
    return (_cambiar(_metodo(k, "async sincronizar() {"), H3_SINC, "const nuevas = this.lineas.filter(l => !l.enviado);"),
            _cambiar(_metodo(k, "cobroDeCuentaCerrada() {"), H3_CERRADA, "this.lineas = this.lineas.filter(l => !l.enviado);"))


def _antes_h4():
    """cargarAHabitacion sin la comanda: la cuenta guardada se carga con su cobro pedido y nada más."""
    m = _metodo(_caja(), "cargarAHabitacion() {")
    i, j = m.index("      const conComanda = "), m.index("      const rcHab = this._rcHab;")
    return (m[:i] + "      if (this.esperaId && !this._rcHab) return this.reclamarHab();\n" + m[j:],)


PREFIJO = r"""
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
const CMP = { @CMP@ };
const PRODUCTOS = [{ id: 1, nombre: 'Casado', categoria: 'Platos' }, { id: 2, nombre: 'Limonada', categoria: 'Bebidas' }, { id: 3, nombre: 'Postre', categoria: 'Postres' }];
// impresoraDe real (_datos.js) con la Cocina como única impresora de comanda; destinoDe real (caja.js) y el de antes de H1 (sin la guarda)
const IMPRESORA = new Function('impresorasComanda', 'return ' + @IMP@ + ';')(() => [COCINA]);
const DESTINO = new Function('mock', 'impresoraDe', 'return {' + @DESTINO@ + '};');
const DESTINO_ANTES = new Function('mock', 'impresoraDe', 'return {' + @DESTINO_ANTES@ + '};');
const IMPRESOS = [];   // [equipo, platos] de cada comanda que llegó a la impresora
// la caja en la venta (computadas reales de caja.js); la comanda se «imprime» en la Cocina y queda anotada, también en el orden de llamadas
function venta(vm, o) {
  o = o || {};
  for (const [n, f] of Object.entries(CMP)) Object.defineProperty(vm, n, { get() { return f.call(this); }, configurable: true });
  Object.assign(vm, { vista: 'venta', rapida: true, mesaActual: null, productos: PRODUCTOS, cats: [] });
  if (o.sinMesas) vm.mesas = [];
  vm.destinoDe = (o.antes ? DESTINO_ANTES : DESTINO)(vm.A.mock, IMPRESORA).destinoDe.bind(vm);
  vm.cfg.imprimir_comanda = true;
  vm.imprimirComanda = g => { const ls = []; for (const x of Object.values(g)) for (const l of x.ls) ls.push(l.detalle + '×' + l.cantidad); IMPRESOS.push([vm.nEq, ls.sort()]); C.llamadas.push([vm.nEq, 'COMANDA']); };
  return vm;
}
// el observador «ventaLibreSinMesas» de caja.js (en una caja sin mesas, la venta sin cuenta cargada es venta rápida)
const vigilar = vm => { if (vm.ventaLibreSinMesas) vm.rapida = true; return vm; };
const nuevo = () => { reiniciarCobro(); reiniciar(); IMPRESOS.length = 0; };
// una cuenta guardada con «Guardar y nueva venta» (platos sin enviar) en otro equipo; devuelve su id
async function guardada(platos, o) {
  nuevo();
  const g = venta(await equipo(), o);
  for (const p of platos) g.lineas.push(p);
  g.guardarCuenta(); await g.A.mock.guardarTodo();
  return S.items[S.items.length - 1].id;
}
// un equipo que recupera esa cuenta (cargarCuenta: rapida = false)
async function abierta(id, o) { const v = venta(await equipo(), o); await v.sincronizar(); v.cargarCuenta(v.espera.find(x => x.id === id)); return v; }
// el pedido en línea a domicilio como lo crea app/pedidos.py (a_caja): los platos con la comanda enviada y el envío sin enviar
const ENVIO = () => ({ producto_id: null, detalle: 'Envío a domicilio', cabys: '7332000000000', cantidad: 1, precio_unitario: 1327.43, descuento: 0, descuento_pct: 0, codigo_tarifa: '08', tarifa: 13, es_servicio: true, unidad_medida: 'Sp', precio_manual: true, nota: '', enviado: null, ronda: 0 });
function pedidoEnServidor(platos) {
  const hace = new Date(Date.now() - 60000).toISOString(), lineas = [...platos.map(p => ({ ...p, enviado: hace, ronda: 1 })), ENVIO()];
  S.items.push({ id: 1, nombre: 'Pedido #41 · Cliente QA', cliente_id: null, credito: false, lineas, nota: '', servicio: false, servicio_pct: 0, creado: hace, actualizado: hace,
    usuario: 'pedidos en línea', total: r2(lineas.reduce((s, l) => s + l.cantidad * l.precio_unitario * 1.13, 0)), mesa_id: null, terminal_id: 1, salonero: '', pedido: 'domicilio',
    canal: 'online', pedido_id: 9, pedido_numero: 41, telefono: null, direccion: 'Dirección QA', hora_entrega: null, estado: 'en_cocina', mesas_ids: [], cobros: [], partes: null, prepago: null, cupon: null, puntos_canjeados: 0 });
  S.ultimo = 1; S.version++;
}
const HAB = () => ({ reserva_id: 1, q: '', firma: false, autoriza: '' });
const CERRADA = @CERRADA@;
const detalles = vm => vm.lineas.map(l => l.detalle + '×' + l.cantidad).sort();
const comandas = vm => avisos(vm).filter(t => t.startsWith('Comanda '));
const deEste = vm => avisos(vm).filter(t => t === AVISO_OCUPADA || t === AVISO_COBRADA || t === CERRADA);
const cerradas = vm => avisos(vm).filter(t => t.startsWith('La cuenta «') && t.includes('fue cobrada o cerrada en otro equipo'));
const impresos = () => IMPRESOS.map(x => x[1]);
const quien = (n, a) => (n === a.nEq ? 'A' : 'B');
const hechos = () => C.emitidos.map(e => [e.n, e.total, e.lineas.slice().sort()]);
const orden = n => C.llamadas.filter(x => n === undefined || x[0] === n).map(x => x[1]).filter(u => u === 'COMANDA' || u.startsWith('/api/pos/cobro/') || u === '/api/comprobantes');
const pantalla = vm => ({ pago: !!vm.pago, cobrando: vm.cobrando, platos: detalles(vm), cuenta: vm.esperaId, vista: vm.vista, rapida: vm.rapida });
"""


def _guion(casos: str) -> str:
    k = _caja()
    cmp = ", ".join(_linea(k, n + "() {") for n in ("esVentaRapida", "totalCobro", "porCobrar", "cuentaRapidaGuardada", "ventaLibreSinMesas"))
    destino = _linea(k, "destinoDe(l) {")
    assert destino.count(H1_GUARDA) == 1, destino
    imp = _tramo(_js("pages/pos/_datos.js"), "export function impresoraDe(", "\n}\n").replace("export ", "", 1) + "\n}"
    return (PREFIJO.replace("@CMP@", cmp).replace("@IMP@", json.dumps(imp)).replace("@DESTINO@", json.dumps(destino))
            .replace("@DESTINO_ANTES@", json.dumps(destino.replace(H1_GUARDA, ""))).replace("@CERRADA@", json.dumps(CERRADA)) + casos)


def _correr_rev(tmp_path, casos: str, antes=()):
    """El arnés de dos equipos con «Guardar y nueva venta» (guardarCuenta, ponerEnEspera, nuevaVentaRapida) y, con `antes`, los métodos de
    antes del arreglo (van al final de la fuente: en un objeto literal la última definición es la que queda)."""
    k = _caja()
    mas = (_linea(k, "propinaCambio() {"), _linea(k, "recibidoCambio() {"), _metodo(k, "guardarCuenta() {"), _metodo(k, "ponerEnEspera() {"),
           _linea(k, "nuevaVentaRapida() {"), *antes)
    tmp_path.mkdir(parents=True, exist_ok=True)
    return _correr(tmp_path, _guion(casos), mas=mas)


# ================================================================================================================ H1: el envío no va a cocina
CASOS_H1 = r"""
// destinoDe real: el envío (sin producto, es servicio) no tiene impresora; un plato sí. Antes de H1, impresoraDe(undefined) daba la primera
{ const v = venta(await equipo()), w = venta(await equipo(), { antes: true });
  out.destino = { envio: v.destinoDe(ENVIO()), plato: v.destinoDe(CASADO()), sinProductoNoServicio: v.destinoDe({ ...ENVIO(), es_servicio: false }),
    servicioConProducto: v.destinoDe({ ...CASADO(), es_servicio: true }), antes: w.destinoDe(ENVIO()) }; }
// la «parte 2 de 2» y la cuenta «aparte» de un pedido a domicilio (2 Casados ya enviados y el envío sin enviar), cobradas en otro equipo
for (const antes of [false, true]) {
  for (const modo of ['partes', 'aparte']) {
    nuevo(); pedidoEnServidor([{ ...CASADO(), cantidad: 2 }]);
    const a = venta(await equipo(), { antes });
    a.recuperar(a.espera.find(x => x.id === 1));
    const delPedido = a.cuentaRapidaGuardada;
    a.dividir = modo === 'partes' ? { modo: 'partes', partes: 2, destino: 'nueva', sel: {} } : { modo: 'articulos', partes: 2, destino: 'nueva', sel: { 0: 1, 1: 1 } };
    await a.confirmarDividir(); await a.A.mock.guardarTodo();
    const sufijo = modo === 'partes' ? ' · parte 2 de 2' : ' · aparte', p = S.items.find(x => x.nombre.endsWith(sufijo));
    const b = venta(await equipo(), { antes }); b.recuperar(b.espera.find(x => x.id === p.id));
    const o = out[modo + (antes ? '_antes' : '')] = { delPedido, marca: [p.pedido || null, p.pedido_id || null, p.canal || null], guardada: b.cuentaRapidaGuardada,
      platos: detalles(b), sinEnviar: b.lineas.filter(l => !l.enviado).map(l => l.detalle) };
    await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
    Object.assign(o, { impresos: impresos(), comandas: comandas(b), hechos: hechos().map(h => h[2]), orden: orden(b.nEq), avisos: deEste(b), quedan: servidor().map(x => x.nombre) });
  }
}
// «Comanda» sobre la cuenta del pedido con el envío sin enviar y un Postre nuevo: sale solo el Postre
for (const antes of [false, true]) {
  nuevo(); pedidoEnServidor([CASADO()]);
  const a = venta(await equipo(), { antes }); a.recuperar(a.espera.find(x => x.id === 1));
  a.lineas.push(POSTRE()); await a.enviarComanda(); await a.A.mock.guardarTodo();
  out['comanda' + (antes ? '_antes' : '')] = { impresos: impresos(), comandas: comandas(a), servidor: servidor().map(x => x.platos.slice().sort()) };
}
"""


def test_h1_el_envio_a_domicilio_no_va_a_cocina_en_node(tmp_path):
    r = _correr_rev(tmp_path, CASOS_H1)
    d = r["destino"]
    assert d["envio"] is None and d["plato"] == {"id": "c", "nombre": "Cocina", "conexion": "usb"}, d
    assert d["sinProductoNoServicio"]["nombre"] == "Cocina" and d["servicioConProducto"]["nombre"] == "Cocina", d   # solo el cargo sin producto
    assert d["antes"]["nombre"] == "Cocina", d                                  # antes de H1 el envío iba a la primera impresora de comanda
    for modo, platos in (("partes", ["Casado×1", "Envío a domicilio×0.5"]), ("aparte", ["Casado×1", "Envío a domicilio×1"])):
        x = r[modo]
        # 4.39 (segunda vuelta, R1): la cuenta del pedido también es cuentaRapidaGuardada (ya no se excluyen los pedidos: toda cuenta guardada
        # sin mesa manda sus platos sin enviar al cobrarla). Del pedido en línea no sale nada: sus platos llegan enviados y el envío no tiene
        # destino (H1). La parte o la «aparte» lo son igual (perdieron la marca de pedido)
        assert x["delPedido"] is True and x["marca"] == [None, None, None] and x["guardada"] is True, (modo, x)
        assert x["platos"] == platos and x["sinEnviar"] == ["Envío a domicilio"], (modo, x)
        assert x["impresos"] == [] and x["comandas"] == [], (modo, x)          # al cobrarla no sale comanda
        assert x["hechos"] == [platos] and x["avisos"] == [], (modo, x)       # se cobra una vez, con el envío
        assert x["orden"] == [RECLAMAR, EMITIR, SOLTAR, SOLTAR] and x["quedan"] == ["Pedido #41 · Cliente QA"], (modo, x)
        v = r[modo + "_antes"]                                                  # antes de H1: el envío salía a cocina
        envio = [p for p in platos if p.startswith("Envío")]
        assert v["impresos"] == [envio] and v["comandas"] == ["Comanda 2 enviada a Cocina"] and v["hechos"] == [platos], (modo, v)
    c = r["comanda"]
    assert c["impresos"] == [["Postre×1"]] and c["comandas"] == ["Comanda 2 enviada a Cocina"], c
    assert c["servidor"] == [["Casado×1", "Envío a domicilio×1", "Postre×1"]], c       # el envío sigue en la cuenta para cobrarse
    assert r["comanda_antes"]["impresos"] == [["Envío a domicilio×1", "Postre×1"]], r["comanda_antes"]


# ================================================================================================================ H2: el cobro se pide antes de la comanda
CASOS_H2 = r"""
// (vez) A y B recuperaron la misma cuenta (Casado y Postre sin enviar) y la cobran a la vez, A primero
let id = await guardada([CASADO(), POSTRE()]);
let a = await abierta(id), b = await abierta(id);
out.inicio = { guardadas: [a.cuentaRapidaGuardada, b.cuentaRapidaGuardada], rapida: [a.rapida, b.rapida], sinEnviar: detalles(a), servidor: servidor().map(x => [x.nombre, x.platos]) };
await a.abrirPago(); await b.abrirPago();
await Promise.all([a.cobrar(), b.cobrar()]); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
let gana = C.emitidos.length && C.emitidos[0].n === b.nEq ? b : a, pierde = gana === a ? b : a;
out.vez = { hechos: hechos().map(h => [h[1], h[2]]), impresos: impresos(), avisosGana: deEste(gana), avisosPierde: deEste(pierde), ordenGana: orden(gana.nEq), ordenPierde: orden(pierde.nEq),
  comandasPierde: comandas(pierde), servidor: servidor() };
await pierde.sincronizar(); await hasta(() => pierde.esperaId === null);
out.vez.luego = { platos: detalles(pierde), cuenta: pierde.esperaId, impresos: IMPRESOS.length, hechos: C.emitidos.length };
// (ocupada) A pide el cobro y emite despacio; B cobra mientras tanto, sin sincronizar
id = await guardada([CASADO(), POSTRE()]); a = await abierta(id); b = await abierta(id);
await a.abrirPago(); await b.abrirPago();
C.emitirLento = 150;
const pa = a.cobrar(); await hasta(() => reclamos(a.nEq) === 1); const pb = b.cobrar(); await Promise.all([pa, pb]); C.emitirLento = 0;
await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
out.ocupada = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), avisosA: deEste(a), avisosB: deEste(b),
  ordenA: orden(a.nEq), ordenB: orden(b.nEq), comandasB: comandas(b) };
// (después) A ya terminó; B, con la ventana de cobro abierta desde antes y sin sincronizar, cobra
id = await guardada([CASADO(), POSTRE()]); a = await abierta(id); b = await abierta(id);
await a.abrirPago(); await b.abrirPago();
await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo(); await hasta(() => b.esperaId === null);
out.despues = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), avisosB: deEste(b), ordenB: orden(b.nEq),
  comandasB: comandas(b), platosB: detalles(b), cuentaB: b.esperaId, servidor: servidor() };
// (solo) un solo equipo: comanda y comprobante una vez; el cobro se pide antes de la comanda
id = await guardada([CASADO(), POSTRE()]); a = await abierta(id);
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
out.solo = { hechos: hechos().map(h => [h[1], h[2]]), impresos: impresos(), orden: orden(a.nEq), avisos: deEste(a), comandas: comandas(a), servidor: servidor(), pago: a.pago, cobrando: a.cobrando };
// (nueva) la venta rápida nueva: comanda y comprobante, sin pedir el cobro (como antes)
nuevo(); const v = venta(await equipo()); v.lineas.push(CASADO(), POSTRE());
await v.abrirPago(); await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo();
out.nueva = { orden: orden(v.nEq), impresos: impresos(), hechos: hechos().map(h => [h[1], h[2]]), servidor: servidor() };
// (alta) la venta rápida mandó la comanda del Casado y su alta todavía no subió; con el Postre, la comanda va antes del reclamo (como antes)
nuevo(); const w = venta(await equipo()); w.lineas.push(CASADO()); w.enviarComanda(); w.lineas.push(POSTRE());
out.alta = { pendiente: !!w.A.mock.pendientes };
w.pago = { tipo_documento: '04', medios: [{ medio: '01', monto: w.totales.total }], recibido: null, propina: 0, moneda: 'CRC', recibido_usd: null, tc: 0, debe: null };
await w.cobrar(); await hastaLibre(); await w.A.mock.guardarTodo();
Object.assign(out.alta, { orden: orden(w.nEq), impresos: impresos(), hechos: hechos().map(h => [h[1], h[2]]), servidor: servidor() });
"""


def test_h2_dos_equipos_cobran_la_misma_cuenta_guardada_y_sale_una_comanda_en_node(tmp_path):
    r = _correr_rev(tmp_path / "ahora", CASOS_H2)
    ambos = ["Casado×1", "Postre×1"]
    i = r["inicio"]
    assert i["guardadas"] == [True, True] and i["rapida"] == [False, False] and i["sinEnviar"] == ambos, i
    assert i["servidor"] == [["Cuenta 1", ["Casado×1", "Postre×1"]]], i
    x = r["vez"]
    assert x["hechos"] == [[CASADO + POSTRE, ambos]] and x["impresos"] == [ambos], x                   # una comanda y un comprobante
    assert x["avisosGana"] == [] and x["avisosPierde"] in ([OCUPADA], [COBRADA]) and x["comandasPierde"] == [], x
    assert x["ordenGana"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and x["ordenPierde"] == [RECLAMAR], x
    assert x["servidor"] == [], x
    assert x["luego"] == {"platos": [], "cuenta": None, "impresos": 1, "hechos": 1}, x                # el que perdió no queda con nada que cobrar
    o = r["ocupada"]
    assert o["hechos"] == [["A", CASADO + POSTRE, ambos]] and o["impresos"] == [["A", ambos]], o
    assert o["avisosA"] == [] and o["avisosB"] == [OCUPADA] and o["comandasB"] == [], o
    assert o["ordenA"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and o["ordenB"] == [RECLAMAR], o
    d = r["despues"]
    assert d["hechos"] == [["A", CASADO + POSTRE, ambos]] and d["impresos"] == [["A", ambos]], d
    assert d["avisosB"] == [COBRADA] and d["ordenB"] == [RECLAMAR] and d["comandasB"] == [], d
    assert d["platosB"] == [] and d["cuentaB"] is None and d["servidor"] == [], d                       # B se pone al día sin nada que cobrar (H3)
    s = r["solo"]
    assert s["hechos"] == [[CASADO + POSTRE, ambos]] and s["impresos"] == [ambos] and s["comandas"] == ["Comanda 1 enviada a Cocina"], s
    assert s["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and s["avisos"] == [], s           # reclamar → (comanda) → comprobante → soltar
    assert s["servidor"] == [] and s["pago"] is None and s["cobrando"] is False, s
    n = r["nueva"]
    assert n["orden"] == [COMANDA, EMITIR] and n["impresos"] == [ambos] and n["hechos"] == [[CASADO + POSTRE, ambos]] and n["servidor"] == [], n
    al = r["alta"]
    assert al["pendiente"] is True and al["impresos"] == [["Casado×1"], ["Postre×1"]], al
    assert al["orden"] == [COMANDA, COMANDA, RECLAMAR, EMITIR, SOLTAR, SOLTAR] and al["hechos"] == [[CASADO + POSTRE, ambos]] and al["servidor"] == [], al

    # el emitirCobro de antes de H2 (la comanda antes de pedir el cobro): las dos cajas imprimían la comanda
    v = _correr_rev(tmp_path / "antes", CASOS_H2, antes=_antes_h2())
    assert len(v["vez"]["hechos"]) == 1 and v["vez"]["impresos"] == [ambos, ambos], v["vez"]
    assert len(v["ocupada"]["hechos"]) == 1 and v["ocupada"]["impresos"] == [["A", ambos], ["B", ambos]], v["ocupada"]
    assert len(v["despues"]["hechos"]) == 1 and v["despues"]["impresos"] == [["A", ambos], ["B", ambos]], v["despues"]
    assert v["solo"]["orden"][:2] == [COMANDA, RECLAMAR], v["solo"]


# ================================================================================================================ H3: lo guardado sin enviar no queda
CASOS_H3 = r"""
// (sinc) B recuperó la cuenta (Casado y Postre sin enviar) y agregó la Limonada sin guardar; A la cobra; B sincroniza y cobra. Una caja sin
// mesas (con el observador de caja.js) y una caja con mesas
for (const sinMesas of [true, false]) {
  const id = await guardada([CASADO(), POSTRE()], { sinMesas });
  const a = await abierta(id, { sinMesas }), b = await abierta(id, { sinMesas });
  b.lineas.push(LIMONADA());
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  await b.sincronizar(); vigilar(b);
  const o = out[sinMesas ? 'sin_mesas' : 'con_mesas'] = { ...pantalla(b), cerradas: cerradas(b) };
  b._alDia = 0; await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), suma: suma(), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), servidor: servidor(), avisos: deEste(b) };
}
// (cerrada) A: venta rápida con el Casado ya enviado, el Postre guardado sin enviar y la Limonada agregada sin guardar; abre el cobro. B la
// recupera y la cobra; A ya lo sabe (sincronizó con la ventana abierta) y toca cobrar: cobroDeCuentaCerrada
{
  nuevo();
  const a = venta(await equipo());
  a.lineas.push({ ...CASADO(), enviado: new Date(Date.now() - 60000).toISOString(), ronda: 1 }); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.lineas.push(POSTRE()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.lineas.push(LIMONADA());
  const b = await abierta(a.esperaId);
  await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar();
  await a.cobrar(); await hastaLibre();
  const o = out.cerrada = { ...pantalla(a), avisos: deEste(a), hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]) };
  a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), suma: suma(), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), servidor: servidor() };
}
// (mesa) la Mesa 6 con el Casado enviado; A guarda el Postre sin enviar y agrega la Limonada sin guardar; B (al día) cobra la mesa
{
  nuevo();
  const [a, b] = await mesaAbierta([CASADO()]);
  a.lineas.push(POSTRE()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  a.lineas.push(LIMONADA());
  await b.sincronizar();
  const vistoB = detalles(b);
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar();
  const o = out.mesa = { ...pantalla(a), vistoB, mesa: a.mesaActual && a.mesaActual.id, cerradas: cerradas(a) };
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), suma: suma(), servidor: servidor() };
}
"""


def test_h3_queda_solo_lo_agregado_sin_guardar_y_se_cobra_una_vez_en_node(tmp_path):
    r = _correr_rev(tmp_path / "ahora", CASOS_H3)
    ambos, tres = ["Casado×1", "Postre×1"], CASADO + POSTRE + LIMONADA
    aviso = "La cuenta «Cuenta 1» fue cobrada o cerrada en otro equipo; lo que no se había enviado sigue en pantalla como cuenta nueva"
    for k in ("sin_mesas", "con_mesas"):
        x = r[k]
        assert x["platos"] == ["Limonada×1"] and x["cuenta"] is None and x["pago"] is False and x["cerradas"] == [aviso], (k, x)
        lu = x["luego"]
        assert lu["hechos"] == [["A", CASADO + POSTRE, ambos], ["B", LIMONADA, ["Limonada×1"]]] and lu["suma"] == tres, (k, x)   # cada plato una vez
        assert lu["servidor"] == [] and lu["avisos"] == [], (k, x)
        assert lu["impresos"][0] == ["A", ambos] and ["B", ambos] not in lu["impresos"], (k, x)   # lo guardado sale a cocina una sola vez
    s = r["sin_mesas"]
    assert s["rapida"] is True and s["luego"]["impresos"] == [["A", ambos], ["B", ["Limonada×1"]]], s   # sin mesas: la Limonada sale al cobrarla
    c = r["cerrada"]
    assert c["avisos"] == [CERRADA] and c["pago"] is False and c["cobrando"] is False and c["cuenta"] is None, c
    assert c["platos"] == ["Limonada×1"] and c["hechos"] == [["B", CASADO + POSTRE, ambos]] and c["impresos"] == [["B", ["Postre×1"]]], c
    lu = c["luego"]
    assert lu["hechos"] == [["B", CASADO + POSTRE, ambos], ["A", LIMONADA, ["Limonada×1"]]] and lu["suma"] == tres and lu["servidor"] == [], c
    assert lu["impresos"] == [["B", ["Postre×1"]], ["A", ["Limonada×1"]]], c                                   # el Postre, una sola comanda
    m = r["mesa"]
    assert m["vistoB"] == ["Casado×1", "Postre×1"], m
    assert m["platos"] == ["Limonada×1"] and m["cuenta"] is None and m["mesa"] == 6, m                      # la mesa sigue en pantalla con la Limonada
    assert m["cerradas"] == ["La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo; lo que no se había enviado sigue en pantalla como cuenta nueva"], m
    assert m["luego"]["hechos"] == [["B", CASADO + POSTRE, ambos], ["A", LIMONADA, ["Limonada×1"]]] and m["luego"]["suma"] == tres, m
    assert m["luego"]["servidor"] == [], m

    # sincronizar y cobroDeCuentaCerrada de antes de H3: lo guardado sin enviar quedaba en pantalla y se cobraba (y, sin mesas, se mandaba) otra vez
    v = _correr_rev(tmp_path / "antes", CASOS_H3, antes=_antes_h3())
    assert v["sin_mesas"]["platos"] == ["Casado×1", "Limonada×1", "Postre×1"], v["sin_mesas"]
    assert v["sin_mesas"]["luego"]["suma"] == tres + CASADO + POSTRE and ["B", ["Casado×1", "Limonada×1", "Postre×1"]] in v["sin_mesas"]["luego"]["impresos"], v["sin_mesas"]
    assert v["con_mesas"]["luego"]["suma"] == tres + CASADO + POSTRE, v["con_mesas"]
    assert v["cerrada"]["platos"] == ["Limonada×1", "Postre×1"] and v["cerrada"]["luego"]["suma"] == tres + POSTRE, v["cerrada"]
    assert v["mesa"]["platos"] == ["Limonada×1", "Postre×1"] and v["mesa"]["luego"]["suma"] == tres + POSTRE, v["mesa"]


CASOS_H3_CON_MESAS = r"""
// caja CON mesas: B recuperó la cuenta guardada sin mesa (Casado y Postre sin enviar) y agregó la Limonada; A la cobra; B sincroniza y cobra
const id = await guardada([CASADO(), POSTRE()]);
const a = await abierta(id), b = await abierta(id);
b.lineas.push(LIMONADA());
await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
await b.sincronizar(); vigilar(b);
out.pantalla = { ...pantalla(b), mesas: b.mesas.length, esVentaRapida: b.esVentaRapida, cuentaRapidaGuardada: b.cuentaRapidaGuardada };
b._alDia = 0; await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
out.hechos = hechos().map(h => [quien(h[0], a), h[1], h[2]]);
out.impresos = IMPRESOS.map(x => [quien(x[0], a), x[1]]);
"""


# 4.39 (segunda vuelta, R4): era xfail(strict) por un defecto preexistente que H3 no arreglaba: en una caja de restaurante CON mesas, la cuenta
# guardada sin mesa recuperada (cargarCuenta deja rapida = false) que otro equipo cobraba dejaba en pantalla lo agregado sin guardar sin cuenta
# (esperaId null); eso no era esVentaRapida ni cuentaRapidaGuardada y la Limonada se cobraba sin llegar nunca a cocina. R4 lo arregla: en
# sincronizar y en cobroDeCuentaCerrada, lo que queda y no es de una mesa (restaurante, sin mesaActual, vista 'venta') es venta rápida
# (rapida = true) y su comanda sale al cobrarlo. Ahora es una prueba normal: la Limonada sale a cocina una vez
def test_h3_lo_que_queda_en_una_caja_con_mesas_sale_a_cocina_al_cobrarlo_en_node(tmp_path):
    r = _correr_rev(tmp_path, CASOS_H3_CON_MESAS)
    p = r["pantalla"]
    # lo que H3 promete se cumple (también lo revisa test_h3_queda_solo_lo_agregado_sin_guardar_y_se_cobra_una_vez_en_node)
    assert p["platos"] == ["Limonada×1"] and p["cuenta"] is None and p["mesas"] == 1, p
    assert p["rapida"] is True and p["esVentaRapida"] is True, p                                   # R4: lo que queda es venta rápida
    assert r["hechos"] == [["A", CASADO + POSTRE, ["Casado×1", "Postre×1"]], ["B", LIMONADA, ["Limonada×1"]]], r
    # la Limonada, cobrada por B, sale a cocina una vez (antes de R4 no salía: esVentaRapida y cuentaRapidaGuardada en false)
    assert r["impresos"] == [["A", ["Casado×1", "Postre×1"]], ["B", ["Limonada×1"]]], r


# ================================================================================================================ H4: la habitación
CASOS_H4 = r"""
// (nueva) venta rápida nueva con un plato sin enviar: comanda (que la guarda), después el cobro pedido y el cargo
nuevo(); let v = venta(await equipo());
v.lineas.push(CASADO()); v.habCargo = HAB();
await v.cargarAHabitacion(); await hastaLibre(); await v.A.mock.guardarTodo();
out.nueva = { impresos: impresos(), comandas: comandas(v), folios: C.folios.map(x => x.detalle), orden: orden(v.nEq), servidor: servidor(), cobrando: v.cobrando,
  habCargo: v.habCargo, platos: v.lineas.length, cuenta: v.esperaId, avisos: deEste(v) };
// (doble) dos toques seguidos en «Cargar a la habitación» (el segundo, solo si la ventana sigue abierta: sin ella no hay botón)
nuevo(); v = venta(await equipo()); v.lineas.push(CASADO()); v.habCargo = HAB();
const p1 = v.cargarAHabitacion(), p2 = v.habCargo ? v.cargarAHabitacion() : null;
out.doble0 = { segundo: p2 !== null };
await Promise.all([p1, p2]); await hastaLibre(); await v.A.mock.guardarTodo();
out.doble = { impresos: impresos(), folios: C.folios.map(x => x.detalle), orden: orden(v.nEq), servidor: servidor() };
// (sin_guardar) la comanda no pudo guardar la cuenta (sin esperaId): se carga igual, ya con la comanda
nuevo(); v = venta(await equipo()); v.lineas.push(CASADO()); v.habCargo = HAB();
v.persistirCuenta = () => { throw new Error('no se pudo guardar'); };
await v.cargarAHabitacion(); await hastaLibre();
out.sin_guardar = { impresos: impresos(), folios: C.folios.map(x => x.detalle), orden: orden(v.nEq), cuenta: v.esperaId, servidor: servidor(), cobrando: v.cobrando };
// (guardada) la cuenta guardada sin mesa (Casado y Postre sin enviar): primero el cobro pedido, con él la comanda (sin revisar «platos dudosos») y el cargo
let id = await guardada([CASADO(), POSTRE()]); v = await abierta(id);
let revisadas = 0; v.revisarComanda = async () => { revisadas++; };
const guardada0 = v.cuentaRapidaGuardada;
v.habCargo = HAB(); await v.cargarAHabitacion(); await hastaLibre(); await v.A.mock.guardarTodo();
out.guardada = { guardada0, impresos: impresos(), comandas: comandas(v), folios: C.folios.map(x => x.detalle), orden: orden(v.nEq), servidor: servidor(), revisadas, cobrando: v.cobrando, avisos: deEste(v) };
// (ocupada) otro equipo está cobrando esa cuenta: ni comanda ni cargo
id = await guardada([CASADO()]); v = await abierta(id);
C.reclamos[id] = { estado: 'reclamada', equipo: 'eOTRO0000000001', clave: 'otraclave1', lids: v.lineas.map(l => l.lid), cobradas: [], vence: Date.now() + 60000 };
v.habCargo = HAB(); await v.cargarAHabitacion();
out.ocupada = { impresos: IMPRESOS.length, folios: C.folios.length, avisos: deEste(v), habCargo: v.habCargo, sinEnviar: v.lineas.filter(l => !l.enviado).length, orden: orden(v.nEq) };
delete C.reclamos[id];
"""


def test_h4_cargar_a_la_habitacion_saca_la_comanda_una_vez_en_node(tmp_path):
    r = _correr_rev(tmp_path / "ahora", CASOS_H4)
    n = r["nueva"]
    assert n["impresos"] == [["Casado×1"]] and n["comandas"] == ["Comanda 1 enviada a Cocina"] and n["folios"] == ["Casado"], n
    assert n["orden"] == [COMANDA, RECLAMAR, SOLTAR], n                                        # la comanda la guarda y después se pide el cobro
    assert n["servidor"] == [] and n["cobrando"] is False and n["habCargo"] is None and n["platos"] == 0 and n["cuenta"] is None and n["avisos"] == [], n
    d = r["doble"]
    assert r["doble0"] == {"segundo": True}, r                                                  # el segundo toque llegó con el cobro en curso
    assert d["impresos"] == [["Casado×1"]] and d["folios"] == ["Casado"] and d["orden"] == [COMANDA, RECLAMAR, SOLTAR] and d["servidor"] == [], d
    s = r["sin_guardar"]
    assert s["impresos"] == [["Casado×1"]] and s["folios"] == ["Casado"] and s["orden"] == [COMANDA], s   # sin cuenta guardada no se pide el cobro
    assert s["cuenta"] is None and s["servidor"] == [] and s["cobrando"] is False, s
    g = r["guardada"]
    assert g["guardada0"] is True and g["impresos"] == [["Casado×1", "Postre×1"]] and g["comandas"] == ["Comanda 1 enviada a Cocina"], g
    assert g["orden"] == [RECLAMAR, COMANDA, SOLTAR], g                                        # el cobro se pide ANTES de la comanda
    assert g["folios"] == ["Casado (Cuenta 1)", "Postre (Cuenta 1)"] and g["servidor"] == [] and g["avisos"] == [], g
    assert g["revisadas"] == 0 and g["cobrando"] is False, g                                    # sin la revisión de «platos dudosos»
    o = r["ocupada"]
    assert o == {"impresos": 0, "folios": 0, "avisos": [OCUPADA], "habCargo": None, "sinEnviar": 1, "orden": [RECLAMAR]}, o

    # cargarAHabitacion de antes de H4: el cargo salía sin comanda (los platos no llegaban a cocina)
    v = _correr_rev(tmp_path / "antes", CASOS_H4, antes=_antes_h4())
    assert v["nueva"]["impresos"] == [] and v["nueva"]["folios"] == ["Casado"] and v["nueva"]["orden"] == [], v["nueva"]
    assert v["guardada"]["impresos"] == [] and v["guardada"]["orden"] == [RECLAMAR, SOLTAR], v["guardada"]


# ================================================================================================================ contrato
def test_contrato_de_los_arreglos_h1_a_h4():
    k = _caja()
    d = _linea(k, "destinoDe(l) {")
    assert d.index(H1_GUARDA) < d.index("impresoraDe(")
    e = _metodo(k, "async emitirCobro(otra) {")
    # 4.39 (segunda vuelta, R2): el pedido del cobro (H2) sigue antes de la comanda, ahora dentro de un bloque de varias líneas
    assert e.count(H2_ABRE) == 1 and e.count(H2_PIDE) == 1
    assert e.index(H2_ABRE) < e.index(H2_PIDE) < e.index("this.enviarComanda();") < e.index("if (reclamar && !rcPedido) {")
    s = _metodo(k, "async sincronizar() {")
    # 4.39 (segunda vuelta, R4): lo que queda y no es de una mesa pasa a ser venta rápida (su comanda sale al cobrarlo, también con mesas)
    queda = "if (nuevas.length) { this.lineas = nuevas; this.esperaId = null; if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true; }"
    assert s.count(H3_SINC) == 1 and s.index(H3_SINC) < s.index(queda)
    c = _metodo(k, "cobroDeCuentaCerrada() {")
    assert c.count(H3_CERRADA) == 1 and c.index(H3_CERRADA) < c.index("if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true;")
    h = _metodo(k, "cargarAHabitacion() {")
    # 4.39 (segunda vuelta): R6 (sin platos no se carga ₡0) va primero; R7: en la segunda pasada, si al guardar con la comanda cambiaron las
    # líneas o el total, no se carga (aviso); el cobro pedido lo suelta reclamarHab
    pasos = ["if (!this.lineas.some(l => +l.cantidad > 0)) { this.habCargo = null; return toast('No quedan platos para cargar a la habitación', 'err'); }",
             "if (!mock.puedeGuardar()) return;",
             "const conComanda = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l));",
             "const comandaHab = () => { const c0 = this.cobrando; this.cobrando = true; try { this.enviarComanda(); }",
             "if (conComanda && !this.esperaId && !this._rcHab) { comandaHab(); if (this.esperaId) return this.reclamarHab(); }",
             "if (this.esperaId && !this._rcHab) return this.reclamarHab();",
             "const fir = () => this.lineas.map(l => String(l.lid || '') + ':' + (+l.cantidad || 0)).sort().join('|'), f0 = fir(), t0 = +this.totales.total || 0;",
             "comandaHab();\n",
             "if (fir() !== f0 || Math.abs((+this.totales.total || 0) - t0) > 0.005) return toast('La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar.', 'err');",
             "const rcHab = this._rcHab; this._rcHab = null;"]
    pos = [h.index(p) for p in pasos]
    assert pos == sorted(pos), pos
    assert "finally { this.cobrando = c0; }" in h
    # la comanda con «cobrando» no pasa por la revisión de platos dudosos (como al cobrar)
    assert "if (this.esRestaurante && !this.cobrando && this.platosDudosos(nuevas).length) return this.comandaRevisada(" in _metodo(k, "enviarComanda() {")
