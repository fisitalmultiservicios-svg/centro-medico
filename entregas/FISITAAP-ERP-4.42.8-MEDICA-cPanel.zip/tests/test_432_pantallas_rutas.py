# -*- coding: utf-8 -*-
"""4.32 (B7): las rutas de app/sinc_pantallas.py (pisados, vistos, franja, choques)."""
import json
import random
from types import SimpleNamespace

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlmodel import Session

from app import auth, sinc_completar, sinc_datos, sinc_datos_programa, sinc_pantallas
from app.db import engine, engine_empresa, init_db

init_db()
_app = FastAPI()
_app.include_router(sinc_pantallas.router)
c = TestClient(_app)
_ROL = {"v": "Administrador"}
_EMP = {"v": None}


def _ctx():
    with Session(engine) as sc:
        e = sc.get(auth.Empresa, _EMP["v"])
        sc.expunge(e)
    return auth.Contexto(SimpleNamespace(es_superadmin=False, id=0, correo="qa@example.test"), e, _ROL["v"])


_app.dependency_overrides[auth.contexto] = _ctx


@pytest.fixture(autouse=True)
def _entorno(monkeypatch):
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    _ROL["v"] = "Administrador"
    yield
    _EMP["v"] = None


def _empresa() -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Pantallas 432 QA", f"pan432-{random.randint(1, 10**9)}@example.test", "31010" + str(random.randint(10**4, 10**5 - 1)))
        eid = e.id
    _EMP["v"] = eid
    return eid


def _pisado(eid, motivo="conflicto", tipo="producto", perdio=None, visto=0, nombre="Café"):
    crudo = perdio if isinstance(perdio, str) else json.dumps(perdio, ensure_ascii=False)
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(text("INSERT INTO sinc_pisado (cuando, tipo, ref, nombre, campo, motivo, perdio, perdio_de, quedo_de, visto) VALUES "
                                    "(:cu, :t, :r, :n, :ca, :m, :p, :pd, :qd, :v)"),
                               {"cu": "2026-11-13T10:00:00+00:00", "t": tipo, "r": "7", "n": nombre, "ca": "precio", "m": motivo,
                                "p": crudo, "pd": "Caja 1", "qd": "la página web", "v": visto})
        s.commit()


def test_apagado_da_404_y_encendido_responde(monkeypatch):
    _empresa()
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    for m, u in (("get", "/api/sinc/datos/pisados"), ("post", "/api/sinc/datos/pisados/vistos"), ("get", "/api/sinc/datos/franja"), ("get", "/api/sinc/datos/choques")):
        assert getattr(c, m)(u).status_code == 404, u
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    assert c.get("/api/sinc/datos/pisados").status_code == 200


def test_sin_tabla_todo_vacio_y_sin_500():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(text("DROP TABLE IF EXISTS sinc_pisado"))
        s.commit()
    assert c.get("/api/sinc/datos/pisados").json() == {"pisados": [], "sin_ver": 0}
    assert c.post("/api/sinc/datos/pisados/vistos").json() == {"ok": True, "marcados": 0}
    assert c.get("/api/sinc/datos/franja").json() == {"cambios": 0, "ventas": 0, "pausa": False, "sin_ver": 0, "choques": 0}
    assert c.get("/api/sinc/datos/choques").json() == {"choques": []}


def test_filas_con_texto_tipo_nombre_y_orden_nuevo_primero():
    eid = _empresa()
    _pisado(eid, "conflicto", "producto")
    _pisado(eid, "cobrado_fuera", "pedido", nombre="Pedido 12")
    _pisado(eid, "inventado", "categoria")
    r = c.get("/api/sinc/datos/pisados").json()
    assert r["sin_ver"] == 3 and [x["tipo_nombre"] for x in r["pisados"]] == ["Categoría", "Pedido", "Ítem"]
    por = {x["motivo"]: x for x in r["pisados"]}
    assert por["cobrado_fuera"]["texto"] == ("Este pedido se cobró aquí después de que la página web lo canceló o lo pasó a otra caja. "
                                             "Revise que no se haya cobrado dos veces.")
    assert por["inventado"]["texto"] == sinc_pantallas.TEXTO_GENERICO and por["conflicto"]["texto"] == sinc_pantallas.TEXTOS["conflicto"]
    assert por["conflicto"]["perdio_de"] == "Caja 1" and por["conflicto"]["quedo_de"] == "la página web" and por["conflicto"]["visto"] is False
    for k in ("conflicto", "eliminado", "no_dueno", "no_valido", "codigo_repetido", "ocupado", "freno", "plan_vencido", "programa_anterior", "cobrado_fuera"):
        t = sinc_pantallas.TEXTOS[k].lower()
        assert not any(p in t for p in ("sincroniz", "token", "api", "servidor")), k


def test_perdio_es_objeto_sin_llaves_delicadas_a_cualquier_profundidad():
    eid = _empresa()
    _pisado(eid, perdio={"precio": 5, "api_token": "zzz-secreto-1", "anidado": {"Password": "zzz-2", "ok": 1, "lista": [{"pin": "zzz-3", "n": 2}]},
                         "clave_hacienda": "zzz-4", "hash_x": "zzz-5", "Firma": "zzz-6", "llave_privada": "zzz-7", "contrasena": "zzz-8", "secreto": "zzz-9"})
    cuerpo = c.get("/api/sinc/datos/pisados")
    assert "zzz-" not in cuerpo.text
    assert cuerpo.json()["pisados"][0]["perdio"] == {"precio": 5, "anidado": {"ok": 1, "lista": [{"n": 2}]}}
    _pisado(eid, perdio='{"precio": 5, "token": "zzz-cortado')              # guardado cortado: no es JSON
    assert "zzz-" not in c.get("/api/sinc/datos/pisados").text


def test_limite_tope_y_validacion():
    eid = _empresa()
    for _ in range(5):
        _pisado(eid)
    assert len(c.get("/api/sinc/datos/pisados?limite=2").json()["pisados"]) == 2
    assert c.get("/api/sinc/datos/pisados?limite=0").status_code == 422 and c.get("/api/sinc/datos/pisados?limite=501").status_code == 422
    assert len(c.get("/api/sinc/datos/pisados").json()["pisados"]) == 5


def test_vistos_marca_solo_esta_empresa():
    a, b = _empresa(), _empresa()
    _pisado(a)
    _pisado(a)
    _pisado(b)
    _EMP["v"] = a
    assert c.get("/api/sinc/datos/franja").json()["sin_ver"] == 2
    assert c.post("/api/sinc/datos/pisados/vistos").json() == {"ok": True, "marcados": 2}
    r = c.get("/api/sinc/datos/pisados").json()
    assert r["sin_ver"] == 0 and all(x["visto"] for x in r["pisados"])
    _EMP["v"] = b
    r = c.get("/api/sinc/datos/pisados").json()
    assert r["sin_ver"] == 1 and len(r["pisados"]) == 1 and r["pisados"][0]["visto"] is False


def test_otra_empresa_no_ve_nada():
    a, b = _empresa(), _empresa()
    _pisado(a)
    _EMP["v"] = b
    assert c.get("/api/sinc/datos/pisados").json() == {"pisados": [], "sin_ver": 0}


@pytest.mark.parametrize("rol", ["Cajero", "Vendedor", "Solo lectura"])
def test_quien_no_administra_recibe_el_rechazo_de_siempre(rol):
    _empresa()
    _ROL["v"] = rol
    for m, u in (("get", "/api/sinc/datos/pisados"), ("post", "/api/sinc/datos/pisados/vistos"), ("get", "/api/sinc/datos/franja"), ("get", "/api/sinc/datos/choques")):
        r = getattr(c, m)(u)
        assert r.status_code == 403 and "no tiene permiso" in r.json()["detail"], u


def test_franja_y_choques_en_la_web(monkeypatch):
    eid = _empresa()
    monkeypatch.setattr(sinc_datos, "_es_programa", lambda: False)
    llamado = []
    monkeypatch.setattr(sinc_datos_programa, "en_espera", lambda e: llamado.append(e) or {"cambios": 9, "ventas": 9, "pausa": True})
    with Session(engine_empresa(eid)) as s:
        sinc_completar.anotar_choque(s, "choque", "producto", "5", "Café", {"x": 1, "token": "zzz-c"})
        s.commit()
    assert c.get("/api/sinc/datos/franja").json() == {"cambios": 0, "ventas": 0, "pausa": False, "sin_ver": 0, "choques": 1} and not llamado
    r = c.get("/api/sinc/datos/choques")
    assert "zzz-c" not in r.text
    x = r.json()["choques"][0]
    assert x["clase"] == "choque" and x["tipo_nombre"] == "Ítem" and x["nombre"] == "Café" and x["detalle"] == {"x": 1} and x["texto"]


def test_franja_en_el_programa_trae_lo_que_espera(monkeypatch):
    eid = _empresa()
    monkeypatch.setattr(sinc_datos, "_es_programa", lambda: True)
    monkeypatch.setattr(sinc_datos_programa, "en_espera", lambda e: {"cambios": 3, "ventas": 2, "pausa": True} if e == eid else {})
    _pisado(eid)
    assert c.get("/api/sinc/datos/franja").json() == {"cambios": 3, "ventas": 2, "pausa": True, "sin_ver": 1, "choques": 0}
