# -*- coding: utf-8 -*-
"""4.32, pedido de Norman del 14 nov: «🌐 Pedidos web» en la caja (Mesas y Venta rápida).

- El botón está siempre a la vista en el plano de mesas y en la pantalla de venta (Venta rápida y mostrador) cuando la empresa tiene
  pedidos en línea; se pone rojo con el número de pedidos por aceptar más los que entraron a esta caja sin verse.
- Al tocarlo se abre una ventana dentro de la caja con los pedidos activos (nuevo, confirmado, en preparación, listo), los nuevos primero.
  En el programa que atiende los pedidos el nuevo se acepta ahí mismo (PUT estado confirmado, sin «reclama», como Ventas en línea › Pedidos
  del programa) y la cuenta se trae a la caja; en la página web el botón lleva a Ventas en línea › Pedidos. El aceptado que ya está en esta
  caja se abre para cobrar.
Nada va a una impresora, a la red ni a un servidor de verdad: la API es una función de la prueba."""
import json
import pathlib
import re
import shutil
import subprocess

import pytest

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
CSS = RAIZ / "app" / "static" / "ui.css"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")


def _caja() -> str:
    return (JS / "pages" / "pos" / "caja.js").read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _nodo():
    return shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)


def _node(tmp_path, guion):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout.strip().splitlines()[-1])


def _computadas():
    k = _caja()
    return _tramo(k, "    conPedidosWeb() {", "\n    },\n") + "\n    },\n"


def _metodos():
    return _tramo(_caja(), "    abrirPanelWeb() {", "    recuperar(v) {")


def _boton():
    k = _caja()
    i = k.index('<button class="btn sm" :class="avisoWeb ? \'pos-web-nuevo\' : \'sec\'"')
    return k[i:k.index("</button>", i) + len("</button>")]


def _ventana():
    """La ventana con Modal y Empty como div y el pie siempre dibujado (fuera de una aplicación de Vue no hay componentes)."""
    v = _tramo(_caja(), '    <Modal v-if="panelWeb"', '    <Modal v-if="habCargo"')
    v = v.replace('<Modal v-if="panelWeb" title="Pedidos en línea" lg @close="panelWeb=null">', '<div v-if="panelWeb">').replace("</Modal>", "</div>")
    v = v.replace("<Empty v-else ", '<div data-vacio v-else ').replace("></Empty>", "></div>").replace("<template #foot>", '<template v-if="true">')
    return v


# ================================================================================================================ fuente
def test_boton_en_mesas_y_en_la_pantalla_de_venta_y_sin_el_enlace_viejo():
    k = _caja()
    mesas = _tramo(k, "<div v-show=\"esRestaurante && vista==='mesas'\">", "<!-- pantalla de venta -->")
    venta = _tramo(k, "<!-- pantalla de venta -->", '<div class="pos-cats">')
    assert mesas.count("data-pedidos-web") == 1 and venta.count("data-pedidos-web") == 1, "un botón en Mesas y otro en Venta rápida"
    assert k.count("data-pedidos-web") == 2
    assert "🌐 En línea (" not in k                                                              # el enlace de antes (solo con nuevos) ya no está
    assert 'v-if="conPedidosWeb" @click="abrirPanelWeb"' in _boton()
    assert "else if (this.panelWeb) this.atrasWeb();" in _tramo(k, "    tecla(e) {", "\n    },\n")   # Escape cierra la ventana (4.39: antes vuelve del resumen a la lista)
    assert "panelWeb: null," in k and "sinVer: 0" in k
    css = CSS.read_text(encoding="utf-8")
    assert ".btn.pos-web-nuevo{" in css and "@keyframes posWebLatido" in css and "prefers-reduced-motion:reduce){.btn.pos-web-nuevo{animation:none}" in css


def test_aceptar_desde_la_caja_manda_lo_mismo_que_pedidos_del_programa():
    m = _metodos()
    acep = _tramo(m, "    async aceptarWeb(p) {", "    abrirCuentaWeb(v) {")
    assert "{ method: 'PUT', body: { estado: 'confirmado' } }" in acep and "reclama" not in acep
    assert "!this.enProgWeb" in acep                                                             # en la página web no se acepta desde la caja
    ped = (JS / "fis" / "pages" / "pedidos.js").read_text(encoding="utf-8")
    prog = _tramo(ped, "    async aceptarEnPrograma(p) {", "\n    },\n")
    assert "{ method: 'PUT', body: { estado: 'confirmado' } }" in prog                           # el mismo cuerpo que Ventas en línea › Pedidos del programa


# ================================================================================================================ plantilla
GUION_VUE = r"""
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\s\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const Vue = await import(%(vue)s);
const fs = await import('node:fs');
const txt = fs.readFileSync(%(caja)s, 'utf8');
const m = /template:\s*`([\s\S]*?)`,\s*\n};/.exec(txt) || /template:\s*`([\s\S]*?)`/.exec(txt);
const errores = []; try { Vue.compile(m[1], { onError: e => errores.push(e.message), onWarn: () => {} }); } catch (e) { errores.push(String(e)); }
const texto = n => n == null ? '' : typeof n === 'string' ? n : Array.isArray(n) ? n.map(texto).join('') : typeof n.children === 'string' ? n.children : Array.isArray(n.children) ? n.children.map(texto).join('') : '';
function buscar(n, f, out) { out = out || []; if (!n || typeof n !== 'object') return out; if (Array.isArray(n)) { n.forEach(x => buscar(x, f, out)); return out; } if (f(n)) out.push(n); if (Array.isArray(n.children)) n.children.forEach(x => buscar(x, f, out)); return out; }
const sesion = { empresaInfo: {}, tieneModulo: x => x === 'pedidos_online' };
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, async () => [], () => {});
function vmCon(extra) {
  const vm = Object.assign({ online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], money: v => '₡' + v, recuperar() {} }, extra || {});
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const boton = Vue.compile(%(boton)s), ventana = Vue.compile(%(ventana)s);
const out = { errores };
function dibujarBoton(vm) { const v = boton.call(vm, vm, []); return v && v.type === 'button' ? { texto: texto(v).trim(), clase: v.props.class, insignias: buscar(v, n => n.type === 'span').map(texto) } : null; }
sesion.tieneModulo = () => false; out.sin_modulo = dibujarBoton(vmCon());
sesion.tieneModulo = x => x === 'pedidos_online';
out.calmo = dibujarBoton(vmCon());
out.nuevos = dibujarBoton(vmCon({ online: { nuevos: 2, ultimo: 7, sinVer: 1 } }));
const mk = (id, estado, extra) => ({ id, numero: 100 + id, nombre: 'Cli ' + id, total: 1000 * id, estado, estado_nombre: estado, tipo: 'recoger', tipo_nombre: 'Para recoger', creado: '2026-11-14T10:' + String(10 + id) + ':00', lineas: [{ detalle: 'Casado', cantidad: 2 }], ...(extra || {}) });
const lista = [mk(1, 'confirmado'), mk(2, 'nuevo'), mk(3, 'entregado'), mk(4, 'listo'), mk(5, 'cancelado'), mk(6, 'nuevo', { atiende: 5, atiende_nombre: 'Caja 2' }), mk(8, 'en_preparacion', { atiende: 9, atiende_nombre: 'Barra' }), mk(9, 'pendiente_pago')];
function dibujarVentana(vm) {
  const v = ventana.call(vm, vm, []);
  const filas = buscar(v, n => n.type === 'tr' && n.props && n.props['data-pedido-web'] !== undefined).map(tr => ({ id: tr.props['data-pedido-web'], acciones: buscar(tr, n => n.type === 'button' || n.type === 'a').map(n => texto(n).trim()), texto: texto(tr) }));
  return { filas, vacio: buscar(v, n => n.props && n.props['data-vacio'] !== undefined).length > 0, aviso_web: texto(buscar(v, n => n.props && n.props.class === 'alert info')).trim(), pie: buscar(v, n => n.type === 'a' || n.type === 'button').map(n => texto(n).trim()).slice(-2) };
}
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
out.programa = dibujarVentana(vmCon({ panelWeb: { cargando: false, lista, error: '', aceptando: { 2: true } }, esperaCaja: [{ id: 900, pedido_id: 1 }, { id: 901, pedido_id: 4 }] }));
out.programa_libre = dibujarVentana(vmCon({ panelWeb: { cargando: false, lista, error: '', aceptando: {} }, esperaCaja: [] }));
sesion.empresaInfo = {};
out.web = dibujarVentana(vmCon({ panelWeb: { cargando: false, lista, error: '', aceptando: {} }, esperaCaja: [{ id: 900, pedido_id: 1 }] }));
out.vacia = dibujarVentana(vmCon({ panelWeb: { cargando: false, lista: [mk(3, 'entregado')], error: '', aceptando: {} } }));
out.cargando = texto(ventana.call(vmCon({ panelWeb: { cargando: true, lista: [], error: '', aceptando: {} } }), vmCon({ panelWeb: { cargando: true, lista: [], error: '', aceptando: {} } }), []));
console.log(JSON.stringify(out));
"""


def test_plantilla_compila_y_dibuja_el_boton_y_la_ventana(tmp_path):
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    r = _node(tmp_path, GUION_VUE % {"vue": json.dumps(vue), "caja": json.dumps(str(JS / "pages" / "pos" / "caja.js")), "comp": json.dumps(_computadas()),
                                     "met": json.dumps(_metodos()), "boton": json.dumps(_boton()), "ventana": json.dumps(_ventana())})
    assert r["errores"] == [], r["errores"]
    assert r["sin_modulo"] is None                                                               # sin pedidos en línea no se dibuja
    assert r["calmo"]["texto"] == "🌐 Pedidos web" and r["calmo"]["clase"].split() == ["btn", "sm", "sec"] and r["calmo"]["insignias"] == []
    assert r["nuevos"]["texto"] == "🌐 Pedidos web3" and "pos-web-nuevo" in r["nuevos"]["clase"] and r["nuevos"]["insignias"] == ["3"]
    p = r["programa"]
    assert [f["id"] for f in p["filas"]] == [6, 2, 8, 4, 1], p                                   # nuevos primero; sin entregados, cancelados ni esperando pago
    acc = {f["id"]: f["acciones"] for f in p["filas"]}
    # 4.39: «Ver pedido» en todos (test_439_pedidos_caja.py prueba el resumen)
    assert acc[2] == ["Ver pedido", "Confirmando…"] and acc[6] == ["Ver pedido"] and acc[8] == ["Ver pedido"], acc   # el que atiende otra computadora no se acepta aquí
    assert acc[1] == ["Ver pedido", "Abrir para cobrar"] and acc[4] == ["Ver pedido", "Abrir para cobrar"], acc
    assert "Lo atiende «Caja 2»" in next(f["texto"] for f in p["filas"] if f["id"] == 6)
    assert "2 × Casado" in next(f["texto"] for f in p["filas"] if f["id"] == 2) and "10:12" in next(f["texto"] for f in p["filas"] if f["id"] == 2)
    assert p["aviso_web"] == "" and p["pie"] == ["Ver todos en Ventas en línea › Pedidos", "Cerrar"]
    assert {f["id"]: f["acciones"] for f in r["programa_libre"]["filas"]}[2] == ["Ver pedido", "Imprimir comanda"]   # 4.39: antes «Aceptar»
    w = r["web"]
    assert {f["id"]: f["acciones"] for f in w["filas"]}[2] == ["Ver pedido", "Imprimir comanda"]   # 4.39: en la página web también se acepta aquí (antes «Aceptar en Pedidos»)
    assert {f["id"]: f["acciones"] for f in w["filas"]}[1] == ["Ver pedido", "Abrir para cobrar"]
    assert w["aviso_web"] == ""                                                                  # 4.39: sin el aviso «ábralo en Ventas en línea › Pedidos»
    assert r["vacia"]["filas"] == [] and r["vacia"]["vacio"] is True
    assert "Cargando los pedidos" in r["cargando"]


# ================================================================================================================ comportamiento
GUION_METODOS = r"""
const Q = { llamadas: [], toasts: [], sincs: 0, recuperadas: [], falla: null, lista: [] };
const sesion = { empresaInfo: { es_local: true, pedidos_programa: true }, tieneModulo: x => x === 'pedidos_online' };
let soltar = null;
const api = async (url, op) => {
  Q.llamadas.push([url, op ? op.method : 'GET', op && op.body ? op.body : null]);
  if (Q.falla) throw new Error(Q.falla);
  if (url === '/api/pedidos') return Q.lista;
  if (/^\/api\/pedidos\/\d+\/estado$/.test(url)) { await new Promise(r => { soltar = r; }); return { id: 2, numero: 102, mensaje: 'Pedido #102 aceptado.' }; }
  throw new Error('ruta ' + url);
};
const toast = (m, t) => Q.toasts.push([m, t]);
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, api, toast);
const vm = { online: { nuevos: 1, ultimo: 3, sinVer: 2 }, panelWeb: null, esperaCaja: [{ id: 900, pedido_id: 1, nombre: 'Pedido #101' }],
  sincronizar: async () => { Q.sincs++; }, recuperar: v => Q.recuperadas.push(v.id) };
for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const out = {};
Q.lista = [{ id: 1, estado: 'confirmado' }, { id: 2, numero: 102, estado: 'nuevo' }];
out.antes = vm.avisoWeb;
vm.abrirPanelWeb(); out.al_abrir = [vm.online.sinVer, vm.panelWeb.cargando]; await pasar();
out.abierta = [vm.panelWeb.cargando, vm.panelWeb.lista.length, vm.avisoWeb, Q.llamadas.map(l => l[0])];
Q.llamadas = [];
const p2 = vm.panelWeb.lista[1];
const a = vm.aceptarWeb(p2), b = vm.aceptarWeb(p2); await pasar();
out.mientras = [Q.llamadas.length, !!vm.panelWeb.aceptando[2]];
soltar(); await a; await b; await pasar();
out.aceptado = { llamadas: Q.llamadas, toasts: Q.toasts, sincs: Q.sincs, aceptando: vm.panelWeb.aceptando };
// en la página web no se acepta desde la caja
Q.llamadas = []; sesion.empresaInfo = {}; await vm.aceptarWeb(p2); out.web = Q.llamadas.length; sesion.empresaInfo = { es_local: true, pedidos_programa: true };
// cobrar: cierra la ventana y abre la cuenta del pedido
out.cuenta = vm.cuentaDePedidoWeb({ id: 1 }) && vm.cuentaDePedidoWeb({ id: 1 }).id; out.sin_cuenta = vm.cuentaDePedidoWeb({ id: 2 });
vm.abrirCuentaWeb(vm.cuentaDePedidoWeb({ id: 1 })); out.cobrar = [vm.panelWeb, Q.recuperadas];
// sin red: el texto del error y la lista que había se queda
vm.abrirPanelWeb(); await pasar(); Q.falla = 'Sin conexión con el servidor'; await vm.cargarPanelWeb();
out.error = [vm.panelWeb.error, vm.panelWeb.lista.length, vm.panelWeb.cargando];
// error al aceptar: el aviso y el botón vuelve
Q.falla = 'El pedido ya fue aceptado en la página web'; Q.toasts = []; Q.sincs = 0; await vm.aceptarWeb({ id: 5, numero: 105 });
out.error_aceptar = [Q.toasts, Q.sincs, vm.panelWeb.aceptando];
// cerrada mientras carga: no escribe en una ventana que ya no está
Q.falla = null; vm.abrirPanelWeb(); const pw = vm.panelWeb; vm.panelWeb = null; await pasar(); out.cerrada = [vm.panelWeb, pw.lista.length];
out.horas = [vm.horaWeb({ creado: '2026-11-14T09:05:33' }), vm.horaWeb({ creado: null }), vm.lineasWeb({ lineas: [{ detalle: 'Casado', cantidad: 2 }, { nombre: 'Fresco' }] }), vm.lineasWeb({})];
console.log(JSON.stringify(out));
"""


def test_abrir_aceptar_cobrar_y_errores(tmp_path):
    r = _node(tmp_path, GUION_METODOS % {"comp": json.dumps(_computadas()), "met": json.dumps(_metodos())})
    assert r["antes"] == 3                                                                       # 1 por aceptar + 2 que entraron sin verse
    assert r["al_abrir"] == [0, True]                                                            # abrir la ventana los da por vistos
    assert r["abierta"] == [False, 2, 1, ["/api/pedidos"]]
    assert r["mientras"] == [1, True]                                                            # dos toques: una sola aceptación
    ac = r["aceptado"]
    assert ac["llamadas"][0] == ["/api/pedidos/2/estado", "PUT", {"estado": "confirmado"}]        # sin «reclama»: la comanda la saca la estación
    assert ac["llamadas"][1:] == [["/api/pedidos", "GET", None]] and ac["sincs"] == 1 and ac["aceptando"] == {}
    assert ac["toasts"] == [["Pedido #102 aceptado.", "ok"]]
    assert r["web"] == 0
    assert r["cuenta"] == 900 and r["sin_cuenta"] is None
    assert r["cobrar"] == [None, [900]]
    assert r["error"][0].startswith("No se pudieron leer los pedidos en línea: Sin conexión con el servidor") and r["error"][1:] == [2, False]
    assert r["error_aceptar"] == [[["El pedido ya fue aceptado en la página web", "err"]], 0, {}]
    assert r["cerrada"] == [None, 0]
    assert r["horas"] == ["09:05", "", "2 × Casado, 1 × Fresco", ""]


GUION_RESUMEN = r"""
const Q = { resp: null, toasts: [], sincs: 0, espera: [], cargas: 0 };
const sesion = { empresaInfo: { es_local: true, pedidos_programa: true }, tieneModulo: m => m === 'pedidos_online' };
const api = async url => { if (url !== '/api/pedidos/resumen') throw new Error('ruta ' + url); return Q.resp; };
const toast = (m, t) => Q.toasts.push(m);
const win = { AudioContext: function () { throw new Error('sin audio en la prueba'); } };
const M = new Function('api', 'toast', 'sesion', 'enEspera', 'window', 'return {' + %(fuente)s + '};')(api, toast, sesion, () => Q.espera, win);
const vm = { online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, _est: null, sincronizar: async () => { Q.sincs++; }, cargarPanelWeb: async () => { Q.cargas++; } };
for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const vuelta = async resp => { Q.resp = resp; Q.toasts = []; await vm.revisarOnline(); await pasar(); return [Q.toasts.slice(), vm.online.nuevos, vm.online.sinVer]; };
const cta = (pid, num) => ({ id: 900 + pid, canal: 'online', pedido_id: pid, pedido_numero: num });
const out = {};
out.primera = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 5 });
Q.espera = [cta(6, 106), cta(7, 107)];
out.entran = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 7 });
out.nuevo = await vuelta({ nuevos: 1, ultimo_id: 3, ultimo_entrado_id: 7 });                 // sinVer se conserva aunque el resumen cambie
vm.panelWeb = { cargando: false, lista: [] }; Q.cargas = 0;
Q.espera.push(cta(8, 108));
out.con_ventana = await vuelta({ nuevos: 1, ultimo_id: 3, ultimo_entrado_id: 8 });          // con la ventana abierta no suma y la recarga
out.cargas = Q.cargas;
vm.panelWeb.cargando = true; Q.cargas = 0; await vuelta({ nuevos: 1, ultimo_id: 3, ultimo_entrado_id: 8 }); out.cargas_ocupada = Q.cargas;
console.log(JSON.stringify(out));
"""


def test_el_resumen_suma_lo_que_entro_sin_verse_y_recarga_la_ventana(tmp_path):
    fuente = _tramo(_caja(), "    async revisarOnline() {", "\n    // 3.87:")
    r = _node(tmp_path, GUION_RESUMEN % {"fuente": json.dumps(fuente)})
    assert r["primera"] == [[], 0, 0]
    assert r["entran"] == [["Entró a la caja el pedido en línea #106.", "Entró a la caja el pedido en línea #107."], 0, 2]
    assert r["nuevo"] == [["Entró un pedido en línea: tóquelo en «🌐 Pedidos web» para verlo."], 1, 2]
    assert r["con_ventana"] == [["Entró a la caja el pedido en línea #108."], 1, 2]
    assert r["cargas"] == 1 and r["cargas_ocupada"] == 0


def test_lineas_nuevas_sin_comentario_de_doble_barra_al_final():
    for linea in _caja().splitlines():
        if ("Pedidos web" in linea or "panelWeb" in linea or "sinVer" in linea) and not linea.strip().startswith("//"):
            assert not re.search(r"(?<![:\"'])//(?!/)", linea.replace("http://", "").replace("https://", "")) or "pedidos en línea nuevos (FISITAAP, 3.47)" in linea, linea
