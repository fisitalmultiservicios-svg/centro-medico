# -*- coding: utf-8 -*-
"""4.25 (tanda 7): pantallas para conectar una computadora nueva con la cuenta de la página web. Programa sin estrenar (login.js con el
componente compartido conexion-local.js), pantalla #/conectar de la web (conectar.js y app.js), avisos a los administradores dentro del
sistema (E-7), Configuración › Instalación local en la web y en el programa, la franja «Modo soporte» (E-13), los nombres del Historial
de operaciones, los documentos del programa y la revisión de sintaxis y de plantillas de cada archivo JS tocado."""
import json
import pathlib
import re
import shutil
import subprocess

import pytest

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
TOCADOS = ("app.js", "api.js", "conexion-local.js", "pages/login.js", "pages/conectar.js", "pages/configuracion/instalacion-local.js",
           "pages/configuracion/seccion.js")


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _sin_comentarios(txt: str) -> str:
    return "\n".join(x for x in txt.splitlines() if not x.lstrip().startswith("//"))


def _node():
    return shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)


# ----------------------------------------------------------------------------------------------------------- programa sin estrenar
def test_pantalla_del_programa_sin_estrenar():
    lg = _js("pages/login.js")
    assert "import ConexionLocal from '../conexion-local.js';" in lg and "components: { ConexionLocal }," in lg
    assert "Conecte esta computadora con su cuenta" in lg and "Un administrador de la empresa lo aprueba desde la página web." in lg
    assert '<ConexionLocal :web="local.web || \'\'" :equipo="local.equipo || \'\'" @lista="conectadaLista"></ConexionLocal>' in lg
    # en el programa ya no se ofrece «Configurar administrador del sistema» (setup da 403 solo_web), salvo en modo soporte y a pedido
    assert "setup() { return !!this.estado && !this.estado.hay_admin && (!this.local || (!!this.local.admin_local && this.soporte)); }," in lg
    assert "primerIngreso() { const l = this.local; return !!l && !!l.nueva && !this.soporte && !this.conectada && (!l.vinculada || this.reconectar); }," in lg
    assert lg.count("Crear un administrador de esta computadora (soporte)") == 2
    assert "Listo. Esta computadora quedó conectada a {{conectada}}." in lg
    assert "sessionStorage.getItem('conexion:aviso')" in lg and "sessionStorage.removeItem('conexion:aviso')" in lg
    # lo de siempre sigue: la marca y los textos que revisan otras pruebas
    assert "Un servicio de" in lg and "Desarrollado por" not in lg and 'v-if="!setup && sinInternet"' in lg
    assert "v-html" not in _sin_comentarios(lg)


def test_componente_de_conexion_del_programa():
    cx = _js("conexion-local.js")
    for ruta in ("iniciar", "estado", "confirmar", "reintentar", "cancelar"):
        assert f"'/api/sinc/local/conexion/{ruta}'" in cx, ruta
    # el enlace es real (un window.open después de esperar al servidor lo bloquean) y la web se nombra con estado.local.web
    assert '<a class="link" :href="v.url" target="_blank" rel="noopener"><b>Abrir {{sitio}}</b></a>' in cx and "window.open" not in _sin_comentarios(cx)
    assert "sitio() { return (this.v && this.v.web) || this.web || 'la página web'; }," in cx and "sistemaCfg" not in cx
    for texto in ("Apruebe esta computadora en la página web", "2. Revise que la página muestre este mismo código:", "Este código vence en ",
                  "¿La página no se abre? Desde cualquier computadora o celular entre a", "«Tengo un código del programa»",
                  "No comparta este código ni el número de comprobación por teléfono, correo o mensaje.",
                  # E-4: antes de aplicar, la empresa, la cédula y quién aprobó; el número (E-1) lo muestra la PÁGINA y se escribe AQUÍ
                  "revise que esta sea su empresa", "<b>Cédula:</b>", "<b>La aprobó:</b>", 'label="Número de comprobación"',
                  "Sí, es mi empresa", "No es mi empresa", "Por seguridad se completa en unos minutos",
                  "Aprobada. Bajando los datos de su empresa… No cierre el programa; puede tardar un minuto.", "Reintentar", "Empezar de nuevo",
                  "Cancelar", "Entrar"):
        assert texto in cx, texto
    assert "numero: n, es_mia: true" in cx and "numero: '', es_mia: false" in cx
    # «Bajando los datos…» con tope de espera y salida; sondeo cada 2 s y al volver a estar visible
    assert "const ESPERA_BAJADA_MS = 180000;" in cx and "const CADA_MS = 2000;" in cx and "visibilitychange" in cx
    # con sesión, el 401 de la cuenta de la computadora retirada lo atiende la pantalla (no cierra la sesión como «vencida»)
    assert "return { method: 'POST', body, sinExpirar: this.conSesion };" in cx and "this.$emit('retirada'" in cx
    assert "v-html" not in _sin_comentarios(cx) and "secreto" not in cx.split("template:", 1)[1]
    api = _js("api.js")
    assert "const sinExpirar = !!opt.sinExpirar; delete opt.sinExpirar;" in api
    assert "if (r.status === 401 && !url.startsWith('/api/auth/') && !sinExpirar) alExpirar();" in api


def test_olvido_su_contrasena_en_el_programa_abre_la_web():
    lg = _js("pages/login.js")
    assert lg.count("¿Olvidó su contraseña?") == 2                                     # los dos enlaces de siempre, nada más
    assert "if (l && !l.admin_local && !j.pagina_web && l.pagina) j.pagina_web = l.pagina;" in lg      # 9b (U7): con el puerto, de URL_NUBE
    assert "programaCerrado() { return !!this.local && !this.local.admin_local; }," in lg
    i = lg.index("<template v-else-if=\"modo==='recuperar'\">")
    rec = lg[i:lg.index("<template v-else-if=\"modo==='restablecer'\">")]
    assert rec.index('<template v-if="programaCerrado">') < rec.index("La contraseña se recupera en la página web") < rec.index("<template v-else>") < rec.index("@click=\"recuperar\"")


# ----------------------------------------------------------------------------------------------------------- web: #/conectar
def test_pantalla_conectar_de_la_web():
    a = _js("app.js")
    assert "const Conectar = defineAsyncComponent(() => import('./pages/conectar.js').then(m => m.default));" in a
    assert "export const conexion = reactive({" in a and "\nconexion.tomar();\n" in a
    assert "sessionStorage.setItem('conectar', c || '1')" in a and "sessionStorage.removeItem('conectar')" in a
    assert "match(/^#\\/conectar\\/?(?:\\?(.*))?$/)" in a
    ruta = a[a.index("    async route() {"):a.index("    abrirGrupo(limpio) {")]
    assert ruta.index("conexion.tomar();") < ruta.index("const nav = this._nav")
    pant = a[a.index("    pantalla() {"):a.index("    empresaActual() {")]
    assert pant.index("return 'paleta';") < pant.index("if (conexion.activa) return 'conectar';") < pant.index("return 'prueba';")
    assert '<Conectar v-else-if="pantalla===\'conectar\'"></Conectar>' in a and "PruebaVencida, SinCaja, Conectar, ReporteProblema" in a
    # lo que comparan otras pruebas sigue igual
    assert "components: { Login, ElegirEmpresa, ActivarMfa," in a and "PruebaVencida, SinCaja," in a
    assert "Conectar" not in a[a.index("const ElegirEmpresa = {"):a.index("const SinCaja")]
    assert re.search(r"^export const VERSION_APP = '\d+\.\d+';", a, re.M)     # 7b (T7a): la versión la publica otra persona: sin número fijo

    cn = _js("pages/conectar.js")
    assert "import { sesion, conexion } from '../app.js';" in cn and "v-html" not in _sin_comentarios(cn)
    for texto in ("Conectar una computadora", "Escriba el código que aparece en la pantalla del programa.", 'label="Código de la computadora"',
                  "quiere conectarse a su empresa.", "Nombre escrito por quien la conecta (no verificado).", "Pidió conectarse {{hace}}.",
                  "Apruebe solo si usted mismo, o alguien de su confianza a quien usted se lo pidió, está frente a esa computadora en este momento.",
                  "la llave con la que se firman sus facturas ante Hacienda", "Nadie de soporte le va a pedir que apruebe una computadora ni que le dicte un número.",
                  "esa computadora no está usando la misma conexión a internet que usted", "¿A cuál empresa la conecta?", "Se conectará a:",
                  "es el mismo que veo en la pantalla del programa.", "'Conectar a ' + nombreEmpresa(elegida)", "No es mía: rechazar",
                  # E-1: el número lo muestra la web, en grande, con la advertencia
                  "{{aprobada.numero}}", "Escríbalo solo en el programa que tiene delante; si alguien se lo pide por teléfono o mensaje, es un engaño",
                  # E-2 y E-15: retención con «Cancelar» y «Listo» solo al ver «entregada»
                  "la entrega espera {{retencion}}", "'/api/sinc/conexion/detener'", "'/api/sinc/conexion/seguimiento'",
                  "if (r.estado === 'entregada') { this.paso = 'listo';", "Ver las computadoras conectadas",
                  "Esta pantalla es de la página web. Ábrala en"):
        assert texto in cn, texto
    # aprobar para otra empresa NO cambia la empresa de la sesión: token de esa empresa solo para la llamada (E-15)
    llamar = cn[cn.index("    async llamarAprobar(eid, si) {"):cn.index("    async aprobar() {")]
    assert "opt.headers = { Authorization: 'Bearer ' + r.token, 'X-Empresa': String(eid) };" in llamar
    assert "sesion.iniciar" not in cn and "setToken" not in cn
    # 9b (U13): la única elección de empresa es la de «Ver las computadoras conectadas», y solo si la pestaña no tenía empresa elegida
    ver = cn[cn.index("    async verComputadoras() {"):cn.index("    async buscar() {")]
    assert cn.count("sesion.cambiarEmpresa") == 1 and ver.index("if (!sesion.empresa_id && eid) {") < ver.index("await sesion.cambiarEmpresa(eid);")
    # «Cancelar» siempre limpia lo guardado en el navegador, aunque el servidor no responda
    salir = cn[cn.index("    salir(destino) {"):cn.index("    async buscar() {")]
    assert salir.index("conexion.limpiar();") < salir.index("location.hash =") and "api(" not in salir
    lg = _js("pages/login.js")
    assert "pendienteWeb() { return !this.local && conexion.activa; }," in lg and "Entre con su cuenta para aprobar la computadora nueva." in lg


def test_avisos_de_computadora_nueva_y_franja_de_modo_soporte():
    a = _js("app.js")
    assert "'store.listo'(v) { if (v) this.cargarAvisosConexion(); else this.avisosConexion = []; }," in a
    carga = a[a.index("    async cargarAvisosConexion() {"):a.index("    async responderAviso(a, respuesta) {")]
    assert "sesion.empresaInfo?.es_local" in carga and "!sesion.puede('configurar')" in carga and "api('/api/sinc/conexion/avisos')" in carga
    assert "api('/api/sinc/conexion/avisos/' + a.id, { method: 'POST', body: { respuesta } })" in a
    assert "v-for=\"a in avisosConexion\"" in a and "@click=\"responderAviso(a, 'si')\">Sí</button>" in a and "@click=\"responderAviso(a, 'revocar')\">Revocar</button>" in a
    assert "genere una llave criptográfica nueva" in a
    assert "this.modoSoporte = !!(j && j.local && j.local.admin_local);" in a and '<div v-if="modoSoporte"' in a and ">Modo soporte:" in a
    assert "avisosConexion: [], modoSoporte: false, paginaWebRrhh: '' }; }," in a


# ----------------------------------------------------------------------------------------------------------- Instalación local
def test_instalacion_local_sin_direccion():
    i = _js("pages/configuracion/instalacion-local.js")
    # 7b (T4): «Dirección de la nube» solo se nombra en la instrucción para los programas anteriores (web); el programa no tiene ese campo
    assert 'label="Dirección de la nube"' not in i and "Dirección de la nube" not in i.split('<template v-else-if="est">', 1)[0] and "f.url" not in i and "f: { codigo: '', nombre: '' }," in i
    assert "body: { codigo: this.f.codigo.trim(), nombre: this.f.nombre.trim() }" in i
    for texto in ("Conectar con mi cuenta", "Tengo un código", "Conectar con el código", "Otra forma de conectar (programas anteriores a la 4.25 o soporte)", "Generar código",
                  "Cuentas que solo existen en esta computadora", "Computadoras conectadas", "<th>Conectada por</th>", "Sin terminar de conectar",
                  "Todavía no hay computadoras conectadas.", "Conectar una computadora nueva", "Tengo un código del programa",
                  "Vale 15 minutos y se usa una sola vez."):
        assert texto in i, texto
    assert "import ConexionLocal from '../../conexion-local.js';" in i and "con-sesion boton=\"Conectar con mi cuenta\"" in i
    assert "api('/api/sinc/local/cuentas')" in i and "tengoCodigo() { location.hash = '/conectar'; }," in i
    assert "sessionStorage.setItem('conexion:aviso', texto)" in i and "sesion.cerrar(false);" in i
    assert '<div class="page">\n    <PageHead title="Instalación local"' in i.replace("\r\n", "\n")       # lo que revisa test_387_pantallas
    assert "v-html" not in _sin_comentarios(i)


def test_seccion_usuarios_solo_en_la_web_y_nombres_del_historial():
    s = _js("pages/configuracion/seccion.js")
    linea = next(x for x in s.splitlines() if x.startswith("const SOLO_NUBE = {"))
    assert linea.startswith("const SOLO_NUBE = { ia:") and "usuarios: 'La administración de usuarios y roles' };" in linea
    acciones = s[s.index("export const ACCIONES = {"):s.index("\n};", s.index("export const ACCIONES = {"))]
    for clave in ("sinc_vinculada", "sinc_conexion_aprobada", "sinc_conexion_rechazada", "sinc_conexion_fallida", "sinc_conexion_cancelada",
                  "sinc_conexion_anulada", "sinc_aviso_reconocida", "sinc_descartada", "sinc_local_vinculada", "login_cuenta_local",
                  "cuenta_local_convertida", "sinc_local_modo_soporte"):
        assert re.search(r"\b" + clave + r": \['", acciones), clave


# ----------------------------------------------------------------------------------------------------------- documentos
def test_readme_y_encabezado_del_programa():
    r = (RAIZ / "local" / "README.md").read_text(encoding="utf-8")
    assert "local\\dist\\nube" in r and "Cómo se reemplaza una 1.46" in r and "## Publicar una versión" in r   # test_49_local_programa
    i = r.index("## Instalar en un cliente")
    paso = r[i:r.index("## Construir")]
    for texto in ("Conecte esta\n   computadora con su cuenta", "NÚMERO DE COMPROBACIÓN", "Sí, es mi empresa", "«Tengo un código del programa»",
                  "### Actualizar a la 4.25", "Primero se instala la página web 4.25 y después el programa", "cerrar las cajas abiertas",
                  "su PIN de caja no sirve", "FE_LOCAL_ADMIN=1"):
        assert texto in paso, texto
    assert "crear el administrador del sistema" not in paso and "dirección de la nube (https://fisitaap.com)" not in paso
    b = (RAIZ / "local" / "README.md").read_bytes()
    assert b.count(b"\r\n") == b.count(b"\n")                                                 # CRLF, sin mezclar
    lp = (RAIZ / "local" / "local.py").read_text(encoding="utf-8")
    cab = lp[:lp.index('"""', lp.index('"""') + 3)]
    assert "Primera vez (4.25)" in cab and "número de comprobación" in cab and "Modo soporte" in cab


def test_archivos_nuevos_en_la_lista_de_la_aplicacion():
    from fastapi.testclient import TestClient
    from app.main import app
    j = TestClient(app).get("/app-archivos.json").json()
    assert "/js/pages/conectar.js" in j["archivos"] and "/js/conexion-local.js" in j["archivos"]


# ----------------------------------------------------------------------------------------------------------- sintaxis y plantillas
def test_sintaxis_y_plantillas_de_los_archivos_js(tmp_path):
    node = _node()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    for rel in TOCADOS:                                                        # node --check sobre una copia .mjs (módulos ES)
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    # las plantillas se compilan con el compilador de Vue del proyecto (node --check no las revisa)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in TOCADOS if r != "api.js"])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) continue;
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] >= 16 and r["malos"] == [], r
