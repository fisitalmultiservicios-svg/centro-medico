"""4.35 (arnés S12 con el exe 4.34): la última subida por el camino anterior (sinc.subida_final_vieja) espera el candado del ciclo de
sincronización (_en_curso) hasta ESPERA_SUBIDA_FINAL en vez de rendirse al instante, y sinc_datos_programa._probar vuelve a probar pronto
(SEGUNDOS_MINIMO) cuando se rindió por el candado. Antes los dos ciclos corrían cada 15 s y quedaban en fase: «no se pudo hacer» una y otra vez
y la computadora nunca pasaba al canal nuevo.

Sin red: la web del canal es el simulador de test_432_programa y _subir_catalogos se reemplaza. Los «ciclos viejos» son hilos que toman y
sueltan el candado como lo hace sinc.sincronizar."""
import ast
import pathlib
import threading
import time

from app import sinc
from app import sinc_datos_programa as sdp
from test_432_programa import NUBE, T, _empresa, _limpieza, web  # noqa: F401  (fixtures: la web simulada y la limpieza del módulo)

APP = pathlib.Path(__file__).resolve().parent.parent / "app"


def _subida_simulada(monkeypatch, falla: bool = False):
    """_subir_catalogos sin red: anota cuándo corrió y si en ese momento el candado era de la subida."""
    llamadas = []

    def subir(s, eid, cfg, url, cab, rango, fotos=None):
        llamadas.append({"cuando": time.monotonic(), "url": url, "rango": rango, "candado": sinc._en_curso.get(eid)})
        if falla:
            raise RuntimeError("la web no contestó")
        return 0
    monkeypatch.setattr(sinc, "_subir_catalogos", subir)
    return llamadas


def _tomar(eid: int) -> None:
    with sinc._lock:
        assert not sinc._en_curso.get(eid)
        sinc._en_curso[eid] = True                    # como sinc.sincronizar al empezar un ciclo


def _ciclo_viejo(eid: int, segundos: float, tomado: threading.Event, soltado: list) -> threading.Thread:
    """Un ciclo de sincronización en otro hilo: toma el candado, lo tiene `segundos` y lo suelta (anota cuándo)."""
    def correr():
        _tomar(eid)
        tomado.set()
        time.sleep(segundos)
        soltado.append(time.monotonic())
        sinc._soltar_candado(eid)
    h = threading.Thread(target=correr, daemon=True)
    h.start()
    assert tomado.wait(5)
    return h


# ------------------------------------------------------------------------------------------------------------------------ (1)
def test_espera_el_candado_y_sigue_cuando_el_ciclo_lo_suelta(monkeypatch):
    eid = _empresa(protocolo2=False)
    llamadas = _subida_simulada(monkeypatch)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 5)                 # plazo holgado: se prueba que espera, no cuánto dura el plazo
    tomado, soltado = threading.Event(), []
    h = _ciclo_viejo(eid, 0.5, tomado, soltado)
    try:
        assert sinc.subida_final_vieja(eid, fotos={}) is True
    finally:
        h.join(5)
    # esperó al ciclo (antes: False al instante): subió DESPUÉS de que el ciclo soltó el candado. Sin medir duraciones desde este hilo
    # (4.35, revisión: dependían del reparto de tiempo entre hilos y de la resolución del reloj en Windows)
    assert len(llamadas) == 1 and soltado and llamadas[0]["cuando"] >= soltado[0]
    assert llamadas[0]["candado"] is True                                # subió con el candado tomado por ella
    assert llamadas[0]["url"] == NUBE and llamadas[0]["rango"] == T
    assert sinc._en_curso.get(eid) is False                              # y lo soltó
    assert sinc.subida_final_ocupada(eid) is False


# ------------------------------------------------------------------------------------------------------------------------ (2)
def test_candado_tomado_mas_que_el_plazo_devuelve_false_sin_colgarse(monkeypatch):
    eid = _empresa(protocolo2=False)
    llamadas = _subida_simulada(monkeypatch)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 0.6)
    _tomar(eid)                                                          # un ciclo largo (p. ej. una bajada lenta) que no suelta
    salida = {}
    try:
        def llamar():
            t0 = time.monotonic()
            salida["r"] = sinc.subida_final_vieja(eid, fotos={})
            salida["seg"] = time.monotonic() - t0
        h = threading.Thread(target=llamar, daemon=True)
        h.start()
        h.join(10)
        assert not h.is_alive(), "subida_final_vieja quedó colgada"
        assert salida["r"] is False
        assert 0.5 <= salida["seg"] < 5, salida
        assert llamadas == []                                            # no subió nada
        assert sinc._en_curso.get(eid) is True                           # no le quitó el candado al ciclo que lo tiene
        assert sinc.subida_final_ocupada(eid) is True                    # se rindió por el candado ...
        assert sinc.subida_final_ocupada(eid) is False                   # ... y la marca se lee una sola vez
    finally:
        sinc._soltar_candado(eid)
    assert sinc.subida_final_vieja(eid, fotos={}) is True                # con el candado libre, sube al momento
    assert len(llamadas) == 1 and sinc._en_curso.get(eid) is False


def test_otra_falla_no_queda_como_candado(monkeypatch):
    eid = _empresa(protocolo2=False)
    _subida_simulada(monkeypatch, falla=True)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 0.3)
    with sinc._lock:
        sinc._subida_final_ocupada.add(eid)                              # una marca vieja de una vuelta anterior
    assert sinc.subida_final_vieja(eid, fotos={}) is False               # la web no contestó: no es el candado
    assert sinc.subida_final_ocupada(eid) is False
    assert sinc._en_curso.get(eid) is False


# ------------------------------------------------------------------------------------------------------------------------ (3)
def test_probar_reintenta_pronto_si_la_subida_se_rindio_por_el_candado(web, monkeypatch):
    eid = _empresa(protocolo2=False)
    _subida_simulada(monkeypatch)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 0.3)
    _tomar(eid)
    try:
        assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO                     # antes: SEGUNDOS_SIN_CONEXION (15 s, en fase con el ciclo viejo)
        assert sdp.protocolo(eid) == 0                                   # todavía no pasa: lo propio no subió
    finally:
        sinc._soltar_candado(eid)
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO
    assert sdp.protocolo(eid) == sdp.PROTOCOLO                           # con el candado libre pasa al canal nuevo


def test_probar_sin_conexion_para_la_subida_sigue_a_los_15_segundos(web, monkeypatch):
    eid = _empresa(protocolo2=False)
    _subida_simulada(monkeypatch, falla=True)
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_SIN_CONEXION                   # otra falla: el ritmo de siempre
    assert sdp.protocolo(eid) == 0


def test_s12_el_ciclo_viejo_en_curso_ya_no_impide_pasar_al_canal_nuevo(web, monkeypatch):
    """El caso del arnés: el canal nuevo pregunta justo mientras corre el ciclo viejo. Ahora espera a que termine y pasa en la misma vuelta."""
    eid = _empresa(protocolo2=False)
    llamadas = _subida_simulada(monkeypatch)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 5)                 # plazo holgado (el ciclo viejo de esta prueba dura 0,5 s)
    tomado, soltado = threading.Event(), []
    h = _ciclo_viejo(eid, 0.5, tomado, soltado)
    try:
        assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO
    finally:
        h.join(5)
    assert sdp.protocolo(eid) == sdp.PROTOCOLO
    assert len(llamadas) == 1 and llamadas[0]["cuando"] >= soltado[0]
    assert sinc._en_curso.get(eid) is False


def test_el_finally_de_sincronizar_no_le_quita_el_candado_a_quien_lo_tomo_despues(monkeypatch):
    """sincronizar suelta el candado antes de armar su respuesta y su finally lo soltaba otra vez: si en ese rato la subida (que ahora espera
    con pasos de 0,2 s) lo tomaba, quedaba subiendo sin candado y otro ciclo podía entrar a la vez."""
    eid = _empresa(protocolo2=False)
    liberado, subiendo, termino = threading.Event(), threading.Event(), threading.Event()
    vio, salida = {}, {}

    def estado_local(s, e_id, e):                                        # sincronizar ya soltó el candado y arma su respuesta ...
        liberado.set()
        subiendo.wait(5)                                                 # ... y en ese rato la subida lo toma
        return {"sincronizando": bool(sinc._en_curso.get(e_id))}
    monkeypatch.setattr(sinc, "_estado_local", estado_local)

    def subir(s, e_id, cfg, url, cab, rango, fotos=None):
        subiendo.set()
        termino.wait(5)                                                  # sincronizar ya pasó por su finally
        vio["candado"] = sinc._en_curso.get(e_id)
        return 0
    monkeypatch.setattr(sinc, "_subir_catalogos", subir)
    hs = threading.Thread(target=lambda: salida.setdefault("sinc", sinc.sincronizar(eid, nube=False, red=False)), daemon=True)
    hs.start()
    assert liberado.wait(5)
    hw = threading.Thread(target=lambda: salida.setdefault("subida", sinc.subida_final_vieja(eid, fotos={})), daemon=True)
    hw.start()
    hs.join(5)
    assert not hs.is_alive() and salida["sinc"] == {"sincronizando": True}
    termino.set()
    hw.join(5)
    assert not hw.is_alive() and salida["subida"] is True
    assert vio["candado"] is True                                        # antes: False a media subida
    assert sinc._en_curso.get(eid) is False                              # y la subida lo soltó al terminar


# ------------------------------------------------------------------------------------------------------------------------ (5)
def _preguntas(web) -> int:
    return sum(1 for ruta, _ in web.llamadas if ruta == sdp.RUTA_DATOS)


def test_la_espera_es_corta_y_no_atrasa_a_las_demas_empresas(web, monkeypatch):
    """4.35 (revisión): el hilo sinc-datos recorre las empresas una por una. Mientras A (todavía sin el canal nuevo) espera el candado de su
    ciclo viejo, B (ya en el canal nuevo: pedidos web, ops de la caja) no avanza. Antes A lo detenía 20 s en cada intento y le volvía a
    preguntar a la web cada vez; ahora espera poco y los reintentos pronto no vuelven a preguntar (RECORDAR_CANAL)."""
    assert sinc.ESPERA_SUBIDA_FINAL <= 3
    a, b = _empresa(protocolo2=False), _empresa(protocolo2=True)
    llamadas = _subida_simulada(monkeypatch)
    _tomar(a)                                                            # el ciclo viejo de A es largo (una bajada lenta) y no suelta
    try:
        n0 = _preguntas(web)
        t0 = time.monotonic()
        assert sdp.ciclo(a) == sdp.SEGUNDOS_MINIMO                       # se rinde pronto y vuelve a probar a los 2 s
        assert time.monotonic() - t0 < sinc.ESPERA_SUBIDA_FINAL + 2      # lo que B espera su turno en esta vuelta (antes: 20 s)
        assert _preguntas(web) == n0 + 1                                 # le preguntó a la web una vez
        sdp.ciclo(b)                                                     # la vuelta sigue con B
        n1 = _preguntas(web)
        assert n1 > n0 + 1
        assert sdp.ciclo(a) == sdp.SEGUNDOS_MINIMO                       # el reintento pronto ...
        assert _preguntas(web) == n1                                     # ... no le vuelve a preguntar a la web
        assert sdp.protocolo(a) == 0 and llamadas == []
    finally:
        sinc._soltar_candado(a)
    assert sdp.ciclo(a) == sdp.SEGUNDOS_MINIMO                           # el ciclo viejo terminó: sube lo propio y pasa al canal nuevo
    assert sdp.protocolo(a) == sdp.PROTOCOLO and len(llamadas) == 1
    assert _preguntas(web) == n1                                         # con lo que la web ya había dicho


def test_pasado_el_rato_le_vuelve_a_preguntar_a_la_web(web, monkeypatch):
    """Pasado RECORDAR_CANAL el reintento vuelve a preguntar (la web pudo cambiar de versión mientras tanto)."""
    a = _empresa(protocolo2=False)
    _subida_simulada(monkeypatch)
    monkeypatch.setattr(sinc, "ESPERA_SUBIDA_FINAL", 0.3)
    monkeypatch.setattr(sdp, "RECORDAR_CANAL", 0)
    _tomar(a)
    try:
        n0 = _preguntas(web)
        assert sdp.ciclo(a) == sdp.SEGUNDOS_MINIMO and sdp.ciclo(a) == sdp.SEGUNDOS_MINIMO
        assert _preguntas(web) == n0 + 2
    finally:
        sinc._soltar_candado(a)


# ------------------------------------------------------------------------------------------------------------------------ (4)
def _llamadores(nombre: str) -> set:
    """{(archivo, función que llama)} de cada llamada a `nombre` (como nombre suelto o atributo) en app/*.py."""
    out = set()
    for ruta in sorted(APP.glob("*.py")):
        arbol = ast.parse(ruta.read_text(encoding="utf-8"))

        def visitar(nodo, funcion):
            for hijo in ast.iter_child_nodes(nodo):
                f = hijo.name if isinstance(hijo, (ast.FunctionDef, ast.AsyncFunctionDef)) else funcion
                if isinstance(hijo, ast.Call):
                    fn = hijo.func
                    if (isinstance(fn, ast.Name) and fn.id == nombre) or (isinstance(fn, ast.Attribute) and fn.attr == nombre):
                        out.add((ruta.name, funcion))
                visitar(hijo, f)
        visitar(arbol, None)
    return out


def test_nadie_llama_a_la_espera_con_el_candado_ya_tomado():
    """Si un llamador ya tuviera _en_curso tomado, la espera sería contra sí mismo (hasta el plazo). Hoy: subida_final_vieja solo desde
    _probar (hilo sinc-datos, dentro de ciclo, que solo tiene su propio _candado_ciclo); _tomar_candado solo desde _aplicar_conexion (hilo de la
    conexión o ruta de estado, con el candado del intento). Ninguno corre dentro de sincronizar ni de otra espera. Un llamador nuevo se revisa."""
    assert _llamadores("subida_final_vieja") == {("sinc_datos_programa.py", "_probar")}
    assert _llamadores("_probar") == {("sinc_datos_programa.py", "_ciclo")}
    assert _llamadores("ciclo") == {("sinc_datos_programa.py", "_bucle")}
    assert _llamadores("_tomar_candado") == {("sinc.py", "_aplicar_conexion")}
    assert _llamadores("_aplicar_conexion") == {("sinc.py", "_paso")}
    assert not {f for (a, f) in _llamadores("sincronizar") if a == "sinc_datos_programa.py"}
