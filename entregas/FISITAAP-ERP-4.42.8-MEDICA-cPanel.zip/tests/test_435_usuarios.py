"""4.35: Configuración › Usuarios.
A) Un usuario creado, quitado y vuelto a crear en la misma empresa: al quitarlo solo se borraba su membresía y la cuenta (global) quedaba
   con su contraseña vieja; al volver a agregar el mismo correo la contraseña temporal no se aplicaba (existia=True,
   password_aplica=False) y la persona no podía entrar con ella: 401 «Correo o contraseña incorrectos». Ahora, si la cuenta quedó
   huérfana (no es miembro de ninguna empresa), no es administrador del sistema y no está bloqueada, se trata como nueva: contraseña
   temporal, debe cambiarla, sin el PIN ni la renuncia de antes y con sus sesiones cerradas. Si entra a otras empresas, su contraseña no
   se toca (y la respuesta lo dice). Por los tres caminos: administrador de la empresa, administrador del sistema como soporte y consola.
B) Restablecer la contraseña de un usuario desde Usuarios de la empresa (POST /api/auth/usuarios/{uid}/password).
Todo con usuarios y empresas @example.test creados aquí y borrados al final."""
import pathlib
import types
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete as sa_delete
from sqlmodel import Session, select

from app import auth
from app.db import Auditoria, Empresa, engine, init_db
from app.main import app

PW = "Clave-larga-435-usuarios"
PW1, PW2 = "Tucan-Playa-4821", "Volcan-Cafe-1234"
PROPIA = "Mi-clave-propia-435"
SUF = ".435u@example.test"
NOMBRE = "U435 "
JS = pathlib.Path(auth.__file__).parent / "static" / "js" / "pages"


def H(t):
    return {"Authorization": "Bearer " + t}


def _usuario(s, nombre, **kw):
    correo = nombre + SUF
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
    if not u:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION, **kw)
        s.add(u); s.commit(); s.refresh(u)
    return u


def _empresa(s, nombre, cedula, **kw):
    return auth.crear_empresa(s, NOMBRE + nombre, nombre.lower() + SUF, cedula, provincia=1, canton=1, distrito=1, otras_senas="QA 435",
                              actividad="471101", telefono=22224350, factura_electronica=False, correo_automatico=False, **kw)


def _miembro(s, u, e, rol):
    s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id if hasattr(e, "id") else e, rol=rol)); s.commit()


def _token(uid, eid=None):
    with Session(engine) as s:
        return auth._respuesta(s, s.get(auth.Usuario, uid), eid)["token"]


def _login(c, correo, pw):
    return c.post("/api/auth/login", json={"correo": correo, "password": pw})


def _cuenta(correo):
    with Session(engine) as s:
        return s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()


def _empresas(uid):
    with Session(engine) as s:
        return sorted(m.empresa_id for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).all())


def _sesiones_vivas(uid):
    with Session(engine) as s:
        return len(s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid, auth.Sesion.revocada == False)).all())  # noqa: E712


def _con_pin_y_renuncia(uid):
    """La cuenta queda con PIN de caja y renuncia a los dos pasos (lo que podía quedar de antes de quitarla)."""
    with Session(engine) as s:
        u = s.get(auth.Usuario, uid)
        u.pin_hash, u.pin_fallos = auth.hash_password("4826"), 2
        u.mfa_renuncia_version, u.mfa_renuncia_fecha = auth.RENUNCIA_MFA_VERSION, datetime.now(timezone.utc)
        u.intentos_fallidos = 3
        s.add(u); s.commit()


def _auditoria_con(texto):
    with Session(engine) as s:
        return [a for a in s.exec(select(Auditoria)).all() if texto in (a.detalle or "") or texto in (a.accion or "")]


@pytest.fixture
def mundo():
    """Super administrador P (y otro administrador del sistema N); empresas E1 y E2 con su Administrador (A1, A2, con dos pasos)."""
    init_db()
    with Session(engine) as s:
        p = _usuario(s, "principal", es_superadmin=True, admin_principal=True, mfa_activo=True)
        n = _usuario(s, "sistema", es_superadmin=True, mfa_activo=True)
        e1, e2 = _empresa(s, "Uno", "3101435001"), _empresa(s, "Dos", "3101435002")
        a1, a2 = _usuario(s, "admin.uno", mfa_activo=True), _usuario(s, "admin.dos", mfa_activo=True)
        _miembro(s, a1, e1, "Administrador"); _miembro(s, a2, e2, "Administrador")
        ids = types.SimpleNamespace(p=p.id, n=n.id, e1=e1.id, e2=e2.id, a1=a1.id, a2=a2.id)
    try:
        yield TestClient(app), ids
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            us = s.exec(select(auth.Usuario).where(auth.Usuario.correo.like("%" + SUF))).all()  # type: ignore[attr-defined]
            uids = [u.id for u in us]
            es = s.exec(select(Empresa).where(Empresa.nombre.like(NOMBRE + "%"))).all()  # type: ignore[attr-defined]
            eids = [e.id for e in es]
            for m in s.exec(select(auth.UsuarioEmpresa)).all():
                if m.usuario_id in uids or m.empresa_id in eids:
                    s.delete(m)
            for x in s.exec(select(auth.Sesion)).all():
                if x.usuario_id in uids:
                    s.delete(x)
            for t in s.exec(select(auth.TokenApi)).all():
                if t.usuario_id in uids:
                    s.delete(t)
            for r in s.exec(select(auth.RolEmpresa)).all():
                if r.empresa_id in eids:
                    s.delete(r)
            for e in es:
                s.delete(e)
            for u in us:
                s.delete(u)
            s.exec(sa_delete(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login", "login_fallo", "login_cuenta", "login_disp"))))  # type: ignore[attr-defined]
            s.commit()


# ----------------------------------------------------------------------------- A) crear, quitar y volver a crear
def _crear_entrar_y_quitar(c, t, correo, quitar):
    """Crea a la persona con PW1, ella entra y pone su propia contraseña (PROPIA), le queda una sesión abierta, PIN y renuncia; después
    se la quita de la empresa. Devuelve (uid, token de la sesión vieja)."""
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "Persona", "rol": "Vendedor", "password_temporal": PW1}, headers=H(t))
    assert r.status_code == 200 and r.json()["existia"] is False and r.json()["password_aplica"] is True and r.json()["aviso"] is None, r.text
    r = _login(c, correo, PW1)
    assert r.status_code == 200 and r.json()["usuario"]["debe_cambiar_password"] is True, r.text
    vieja = r.json()["token"]
    assert c.post("/api/auth/password", json={"actual": PW1, "nueva": PROPIA}, headers=H(vieja)).status_code == 200
    vieja = _login(c, correo, PROPIA).json()["token"]
    uid = _cuenta(correo).id
    _con_pin_y_renuncia(uid)
    quitar(uid)
    assert _empresas(uid) == []                                            # huérfana: la cuenta global sigue, sin empresas
    return uid, vieja


def _revisar_reactivada(c, r, correo, uid, vieja, nombre="Persona Nueva"):
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["existia"] is True and j["password_aplica"] is True and j["reactivada"] is True and j["motivo"] is None
    assert j["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["reactivada"]
    assert PW2 not in r.text                                               # el servidor no repite la contraseña
    assert _login(c, correo, PROPIA).status_code == 401                    # la contraseña de antes ya no sirve
    r2 = _login(c, correo, PW2)                                            # ANTES: 401 «Correo o contraseña incorrectos»
    assert r2.status_code == 200 and r2.json()["usuario"]["debe_cambiar_password"] is True, r2.text
    u = _cuenta(correo)
    assert u.pin_hash is None and u.pin_fallos == 0 and u.mfa_renuncia_version is None and u.intentos_fallidos == 0
    assert u.nombre == nombre
    assert c.get("/api/auth/sesiones", headers=H(vieja)).status_code == 401   # su sesión de antes quedó cerrada
    assert not _auditoria_con(PW2)                                          # la contraseña no queda en la auditoría


def test_a1_administrador_crea_quita_y_vuelve_a_crear(mundo):
    c, ids = mundo
    t = _token(ids.a1, ids.e1)
    correo = "persona.a1" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t, correo, lambda uid: c.delete(f"/api/auth/usuarios/{uid}", headers=H(t)).raise_for_status())
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "Persona Nueva", "rol": "Contador", "password_temporal": PW2}, headers=H(t))
    _revisar_reactivada(c, r, correo, uid, vieja)
    assert _empresas(uid) == [ids.e1]
    fila = next(x for x in c.get("/api/auth/usuarios", headers=H(t)).json() if x["id"] == uid)
    assert fila["rol"] == "Contador"
    # otra vez: ya es miembro → 409 (sin tocar nada)
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "x", "rol": "Vendedor", "password_temporal": PW1}, headers=H(t))
    assert r.status_code == 409


def test_a1_huerfana_con_temporal_invalida_no_cambia_nada(mundo):
    c, ids = mundo
    t = _token(ids.a1, ids.e1)
    correo = "persona.corta" + SUF
    uid, _ = _crear_entrar_y_quitar(c, t, correo, lambda uid: c.delete(f"/api/auth/usuarios/{uid}", headers=H(t)).raise_for_status())
    antes = _cuenta(correo).password_hash
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "x", "rol": "Vendedor", "password_temporal": "corta"}, headers=H(t))
    assert r.status_code == 400 and "12" in r.text
    assert _cuenta(correo).password_hash == antes and _empresas(uid) == []


def test_a1_cuenta_en_otra_empresa_no_toca_su_contrasena(mundo):
    c, ids = mundo
    with Session(engine) as s:
        x = _usuario(s, "contador.compartido")
        _miembro(s, x, ids.e2, "Contador")
        xid, correo, hash_antes = x.id, x.correo, x.password_hash
    viva = _token(xid, ids.e2)
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "Otro nombre", "rol": "Contador", "password_temporal": PW2},
               headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["existia"] is True and j["password_aplica"] is False and j["reactivada"] is False and j["motivo"] == "otras"
    assert j["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["otras"] and "otras empresas" in j["aviso"]
    u = _cuenta(correo)
    assert u.password_hash == hash_antes and u.nombre == "contador.compartido" and not u.debe_cambiar_password
    assert _login(c, correo, PW2).status_code == 401 and _login(c, correo, PW).status_code == 200
    assert c.get("/api/auth/sesiones", headers=H(viva)).status_code == 200    # sus sesiones siguen
    assert _empresas(xid) == sorted([ids.e1, ids.e2])


def test_a1_cuenta_bloqueada_por_el_sistema_no_se_reactiva(mundo):
    c, ids = mundo
    with Session(engine) as s:
        x = _usuario(s, "bloqueada", bloqueado=True)
        xid, correo, hash_antes = x.id, x.correo, x.password_hash
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "x", "rol": "Vendedor", "password_temporal": PW2},
               headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 200 and r.json()["motivo"] == "bloqueada" and r.json()["password_aplica"] is False
    assert "bloqueada" in r.json()["aviso"]
    u = _cuenta(correo)
    assert u.password_hash == hash_antes and u.bloqueado and _empresas(xid) == [ids.e1]


def test_a2_soporte_crea_quita_y_vuelve_a_crear(mundo):
    c, ids = mundo
    t = _token(ids.p, ids.e1)                                              # el super administrador entró a E1 como soporte
    correo = "persona.a2" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t, correo, lambda uid: c.delete(f"/api/auth/usuarios/{uid}", headers=H(t)).raise_for_status())
    r = c.post("/api/auth/usuarios", json={"correo": correo, "nombre": "Persona Nueva", "rol": "Vendedor", "password_temporal": PW2}, headers=H(t))
    _revisar_reactivada(c, r, correo, uid, vieja)
    # un administrador del sistema que no es miembro de nada: el super administrador lo agrega, pero su contraseña no se toca
    hash_n = _cuenta("sistema" + SUF).password_hash
    r = c.post("/api/auth/usuarios", json={"correo": "sistema" + SUF, "nombre": "x", "rol": "Vendedor", "password_temporal": PW2}, headers=H(t))
    assert r.status_code == 200 and r.json()["motivo"] == "sistema" and r.json()["password_aplica"] is False, r.text
    assert _cuenta("sistema" + SUF).password_hash == hash_n


def test_a3_consola_autoriza_quita_y_vuelve_a_autorizar(mundo):
    c, ids = mundo
    tp = _token(ids.p)
    correo = "persona.a3" + SUF
    r = c.post(f"/api/admin/cuentas/{ids.e1}/usuarios", json={"correo": correo, "rol": "Vendedor", "nombre": "Persona", "password": PW1}, headers=H(tp))
    assert r.status_code == 200 and r.json()["existia"] is False and r.json()["aviso"] is None, r.text
    vieja = _login(c, correo, PW1).json()["token"]
    assert c.post("/api/auth/password", json={"actual": PW1, "nueva": PROPIA}, headers=H(vieja)).status_code == 200
    vieja = _login(c, correo, PROPIA).json()["token"]
    uid = r.json()["usuario_id"]
    _con_pin_y_renuncia(uid)
    assert c.delete(f"/api/admin/cuentas/{ids.e1}/usuarios/{uid}", headers=H(tp)).status_code == 200
    # sin contraseña inicial: se autoriza, conserva la anterior y el aviso lo dice
    r = c.post(f"/api/admin/cuentas/{ids.e2}/usuarios", json={"correo": correo, "rol": "Vendedor"}, headers=H(tp))
    assert r.status_code == 200 and r.json()["motivo"] == "sin_password" and r.json()["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["sin_password"]
    assert _login(c, correo, PROPIA).status_code == 200
    assert c.delete(f"/api/admin/cuentas/{ids.e2}/usuarios/{uid}", headers=H(tp)).status_code == 200
    assert _login(c, correo, PROPIA).status_code == 403                    # huérfana: «no tiene empresas asignadas» (su sesión vieja sigue)
    # con contraseña inicial: se trata como nueva
    r = c.post(f"/api/admin/cuentas/{ids.e1}/usuarios", json={"correo": correo, "rol": "Vendedor", "nombre": "Persona Nueva", "password": PW2}, headers=H(tp))
    _revisar_reactivada(c, r, correo, uid, vieja)
    # ya es miembro de E1: con contraseña, en otra empresa no se toca (aviso «otras»); en la misma, solo cambia el rol (sin aviso)
    hash_antes = _cuenta(correo).password_hash
    r = c.post(f"/api/admin/cuentas/{ids.e2}/usuarios", json={"correo": correo, "rol": "Contador", "password": "Otra-clave-larga-435"}, headers=H(tp))
    assert r.status_code == 200 and r.json()["motivo"] == "otras" and r.json()["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["otras"]
    r = c.post(f"/api/admin/cuentas/{ids.e1}/usuarios", json={"correo": correo, "rol": "Contador", "password": "Otra-clave-larga-435"}, headers=H(tp))
    assert r.status_code == 200 and r.json()["rol"] == "Contador" and r.json()["aviso"] is None
    assert _cuenta(correo).password_hash == hash_antes


# ----------------------------------------------------------------------------- 4.35 (revisión h1): la huérfana es de la empresa que la quitó
def _quitar_de(c, t):
    return lambda uid: c.delete(f"/api/auth/usuarios/{uid}", headers=H(t)).raise_for_status()


def _agregar(c, t, correo, pw=PW2, nombre="Atacante"):
    return c.post("/api/auth/usuarios", json={"correo": correo, "nombre": nombre, "rol": "Vendedor", "password_temporal": pw}, headers=H(t))


def test_a1_huerfana_de_otra_empresa_no_se_toma(mundo):
    """h1: E1 quita a su persona (huérfana). Antes el Administrador de E2 la agregaba con SU temporal y la cuenta quedaba con la clave que él
    eligió (reactivada): entraba como ella y, cuando E1 la volviera a agregar («otras»), leía los datos de E1. Ahora conserva su contraseña
    («ajena»), queda traída en E2 (sin 🔑) y E1 sigue siendo la que la trata como nueva, aunque E2 la agregue y la quite."""
    c, ids = mundo
    t1, t2 = _token(ids.a1, ids.e1), _token(ids.a2, ids.e2)
    correo = "persona.h1" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t1, correo, _quitar_de(c, t1))
    hash_antes = _cuenta(correo).password_hash
    r = _agregar(c, t2, correo)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["existia"] is True and j["password_aplica"] is False and j["reactivada"] is False and j["motivo"] == "ajena"
    assert j["aviso"] == auth.AVISOS_CUENTA_EXISTENTE["ajena"] and "¿Olvidó su contraseña?" in j["aviso"]
    u = _cuenta(correo)
    assert u.password_hash == hash_antes and not u.debe_cambiar_password and u.nombre == "Persona" and u.pin_hash is not None
    assert _login(c, correo, PW2).status_code == 401 and _login(c, correo, PROPIA).status_code == 200
    assert c.get("/api/auth/sesiones", headers=H(vieja)).status_code == 200     # sus sesiones siguen
    r = c.post(f"/api/auth/usuarios/{uid}/password", json={}, headers=H(t2))      # h2: ni con 🔑, aunque hoy E2 sea su única empresa
    assert r.status_code == 409 and r.json()["detail"] == auth.MENSAJE_CUENTA_TRAIDA and "password" not in r.json()
    assert _cuenta(correo).password_hash == hash_antes
    _quitar_de(c, t2)(uid)                                                  # E2 la quita y la vuelve a agregar: sigue sin ser suya
    assert _agregar(c, t2, correo).json()["motivo"] == "ajena" and _cuenta(correo).password_hash == hash_antes
    _quitar_de(c, t2)(uid)
    r = _agregar(c, t1, correo, nombre="Persona Nueva")                    # E1, la dueña, todavía la trata como nueva
    _revisar_reactivada(c, r, correo, uid, vieja)


def test_a1_huerfana_quitada_antes_de_435_se_decide_por_la_auditoria(mundo):
    """Las cuentas quitadas antes de 4.35 no tienen anotada la empresa (ultima_empresa_id vacío): es de esta empresa si TODAS las veces que
    se quitó («usuario_retirado») fue de aquí. Sin ninguna (nunca estuvo en una empresa, o la empresa se eliminó) no es de nadie."""
    c, ids = mundo
    t1, t2 = _token(ids.a1, ids.e1), _token(ids.a2, ids.e2)

    def como_antes(uid):
        with Session(engine) as s:
            u = s.get(auth.Usuario, uid); u.ultima_empresa_id = None; s.add(u); s.commit()
    correo = "persona.antes" + SUF
    uid, vieja = _crear_entrar_y_quitar(c, t1, correo, _quitar_de(c, t1))
    como_antes(uid)
    hash_antes = _cuenta(correo).password_hash
    assert _agregar(c, t2, correo).json()["motivo"] == "ajena" and _cuenta(correo).password_hash == hash_antes
    _quitar_de(c, t2)(uid)
    como_antes(uid)                                                         # se quitó de E1 y de E2: ninguna de las dos la toma
    assert _agregar(c, t1, correo).json()["motivo"] == "ajena" and _cuenta(correo).password_hash == hash_antes
    correo2 = "persona.antes2" + SUF                                       # quitada solo de E1: E1 la trata como nueva
    uid2, vieja2 = _crear_entrar_y_quitar(c, t1, correo2, _quitar_de(c, t1))
    como_antes(uid2)
    _revisar_reactivada(c, _agregar(c, t1, correo2, nombre="Persona Nueva"), correo2, uid2, vieja2)
    with Session(engine) as s:                                              # nunca estuvo en ninguna empresa
        suelta = _usuario(s, "suelta")
        hash_suelta = suelta.password_hash
    assert _agregar(c, t1, "suelta" + SUF).json()["motivo"] == "ajena" and _cuenta("suelta" + SUF).password_hash == hash_suelta


def test_a_pantallas_muestran_lo_que_dijo_el_servidor():
    sec = (JS / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    usu = sec[sec.index("const SecUsuarios = {"):sec.index("// ------------------------------------------------------------------ Mi perfil")]
    enviar = usu[usu.index("    async enviar() {"):]
    enviar = enviar[:enviar.index("\n    },")]
    assert "r.aviso" in enviar and "r.password_aplica" in enviar and "la temporal no aplica" not in enviar
    rrhh = (JS / "rrhh" / "empleado-form.js").read_text(encoding="utf-8")
    assert "r.aviso" in rrhh and "r.password_aplica" in rrhh
    adm = (JS / "admin.js").read_text(encoding="utf-8")
    assert "r.aviso" in adm[adm.index("    async confirmarAutorizar() {"):adm.index("    async quitarAutorizacion(")]


# ----------------------------------------------------------------------------- B) restablecer la contraseña desde Usuarios
@pytest.fixture
def equipo(mundo):
    """Persona X solo de E1, con dos pasos activos y una sesión abierta; un Vendedor V de E1."""
    c, ids = mundo
    with Session(engine) as s:
        x = _usuario(s, "persona.b", mfa_activo=True, mfa_secret="SECRETO-QA-435")
        v = _usuario(s, "vendedor.b")
        _miembro(s, x, ids.e1, "Contador"); _miembro(s, v, ids.e1, "Vendedor")
        ids.x, ids.v, ids.correo_x = x.id, v.id, x.correo
    _con_pin_y_renuncia(ids.x)
    ids.sesion_x = _token(ids.x, ids.e1)
    return c, ids


def test_b_restablece_genera_y_cierra_sesiones(equipo):
    c, ids = equipo
    assert _sesiones_vivas(ids.x) >= 1
    previas = len(_auditoria_con("usuario_password_restablecida"))       # la auditoría queda entre pruebas (test_435_cabos también restablece)
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 200, r.text
    j = r.json()
    clave = j["password"]
    assert j["correo"] == ids.correo_x and j["mfa_activo"] is True
    auth.validar_password(clave, ids.correo_x)                             # cumple la política
    u = _cuenta(ids.correo_x)
    assert auth.verificar_password(clave, u.password_hash) and u.debe_cambiar_password
    assert u.mfa_activo and u.mfa_secret == "SECRETO-QA-435"               # la verificación en dos pasos no se apaga
    assert u.pin_hash is not None                                          # el PIN de caja no se toca
    assert u.mfa_renuncia_version is None and u.intentos_fallidos == 0
    assert _sesiones_vivas(ids.x) == 0
    assert c.get("/api/auth/sesiones", headers=H(ids.sesion_x)).status_code == 401
    filas = _auditoria_con("usuario_password_restablecida")[previas:]
    assert [(a.accion, a.detalle, a.empresa_id, a.usuario_id) for a in filas] == [("usuario_password_restablecida", ids.correo_x, ids.e1, ids.a1)]
    assert not _auditoria_con(clave)                                       # la contraseña no queda en ningún registro
    # sin cuerpo también genera una
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 200 and r.json()["password"] != clave


def test_b_restablece_con_la_que_escribe_el_administrador(equipo):
    c, ids = equipo
    t = _token(ids.a1, ids.e1)
    assert c.post(f"/api/auth/usuarios/{ids.x}/password", json={"password": "corta"}, headers=H(t)).status_code == 400
    assert c.post(f"/api/auth/usuarios/{ids.x}/password", json={"password": "Clave-persona.b.435u"}, headers=H(t)).status_code == 400   # contiene el correo
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", json={"password": "Clave-tecleada-435-QA"}, headers=H(t))
    assert r.status_code == 200 and r.json()["password"] == "Clave-tecleada-435-QA"
    assert auth.verificar_password("Clave-tecleada-435-QA", _cuenta(ids.correo_x).password_hash)


def test_b_permisos_y_tenancia(equipo):
    c, ids = equipo
    ruta = f"/api/auth/usuarios/{ids.x}/password"
    hash_antes = _cuenta(ids.correo_x).password_hash
    # sin el permiso «usuarios»
    assert c.post(ruta, json={}, headers=H(_token(ids.v, ids.e1))).status_code == 403
    # el Administrador de otra empresa: la persona no es de la suya
    assert c.post(ruta, json={}, headers=H(_token(ids.a2, ids.e2))).status_code == 404
    # a sí mismo: Mi perfil
    r = c.post(f"/api/auth/usuarios/{ids.a1}/password", json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 400 and "Mi perfil" in r.text
    # un usuario que no existe
    assert c.post("/api/auth/usuarios/987654321/password", json={}, headers=H(_token(ids.a1, ids.e1))).status_code == 404
    assert _cuenta(ids.correo_x).password_hash == hash_antes and _sesiones_vivas(ids.x) >= 1
    # la cuenta también entra a otra empresa: la restablece el soporte
    with Session(engine) as s:
        _miembro(s, s.get(auth.Usuario, ids.x), ids.e2, "Contador")
    r = c.post(ruta, json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 409 and r.json()["detail"] == auth.MENSAJE_RESTABLECE_SOPORTE
    assert c.post(ruta, json={}, headers=H(_token(ids.a2, ids.e2))).status_code == 409
    assert _cuenta(ids.correo_x).password_hash == hash_antes


def test_b_administradores_del_sistema_y_bloqueadas_protegidos(equipo):
    c, ids = equipo
    with Session(engine) as s:
        _miembro(s, s.get(auth.Usuario, ids.p), ids.e1, "Administrador")
        _miembro(s, s.get(auth.Usuario, ids.n), ids.e1, "Administrador")
        b = _usuario(s, "bloqueada.b", bloqueado=True)
        _miembro(s, b, ids.e1, "Vendedor")
        bid = b.id
    hashes = {k: _cuenta(k + SUF).password_hash for k in ("principal", "sistema", "bloqueada.b")}
    for actor in (_token(ids.a1, ids.e1), _token(ids.p, ids.e1)):          # ni el Administrador ni el super administrador como soporte
        for uid in (ids.p, ids.n):
            r = c.post(f"/api/auth/usuarios/{uid}/password", json={}, headers=H(actor))
            assert r.status_code in (400, 403), (uid, r.text)
    r = c.post(f"/api/auth/usuarios/{ids.n}/password", json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 403 and "administrador del sistema" in r.text
    r = c.post(f"/api/auth/usuarios/{bid}/password", json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 409 and "bloqueada" in r.text
    assert {k: _cuenta(k + SUF).password_hash for k in hashes} == hashes
    # el super administrador como soporte sí restablece a una persona de la empresa
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", json={}, headers=H(_token(ids.p, ids.e1)))
    assert r.status_code == 200 and _cuenta(ids.correo_x).debe_cambiar_password


def test_b_cuenta_traida_no_se_restablece_aunque_hoy_sea_la_unica(equipo):
    """h2: E2 agrega por su cuenta a X, que es de E1 (motivo «otras»: su contraseña no se toca). Cuando E1 la quita, X queda solo en E2,
    pero E2 no la creó: 🔑 da 409. Antes daba 200 con la contraseña nueva y E2 tomaba la cuenta (y, si E1 la volvía a agregar, sus datos)."""
    c, ids = equipo
    t2 = _token(ids.a2, ids.e2)
    r = c.post("/api/auth/usuarios", json={"correo": ids.correo_x, "nombre": "x", "rol": "Contador", "password_temporal": PW2}, headers=H(t2))
    assert r.status_code == 200 and r.json()["motivo"] == "otras", r.text
    hash_antes = _cuenta(ids.correo_x).password_hash
    assert c.delete(f"/api/auth/usuarios/{ids.x}", headers=H(_token(ids.a1, ids.e1))).status_code == 200
    assert _empresas(ids.x) == [ids.e2]
    ruta = f"/api/auth/usuarios/{ids.x}/password"
    auditadas = len(_auditoria_con("usuario_password_restablecida"))     # la auditoría queda entre pruebas
    for actor in (t2, _token(ids.p, ids.e2)):                              # ni su Administrador ni el super administrador desde la empresa
        r = c.post(ruta, json={}, headers=H(actor))
        assert r.status_code == 409 and r.json()["detail"] == auth.MENSAJE_CUENTA_TRAIDA and "password" not in r.json(), r.text
    assert _cuenta(ids.correo_x).password_hash == hash_antes and _sesiones_vivas(ids.x) >= 1
    assert len(_auditoria_con("usuario_password_restablecida")) == auditadas
    # E2 la quita: queda huérfana y su dueña sigue siendo E1 (E2 no la trata como nueva)
    assert c.delete(f"/api/auth/usuarios/{ids.x}", headers=H(t2)).status_code == 200
    r = c.post("/api/auth/usuarios", json={"correo": ids.correo_x, "nombre": "x", "rol": "Contador", "password_temporal": PW2}, headers=H(t2))
    assert r.status_code == 200 and r.json()["motivo"] == "ajena" and _cuenta(ids.correo_x).password_hash == hash_antes


def test_b_traida_desde_la_consola_tampoco(equipo):
    """La consola agrega a X (de E1) a E2 con su contraseña de siempre («otras»): también queda traída en E2."""
    c, ids = equipo
    tp = _token(ids.p)
    r = c.post(f"/api/admin/cuentas/{ids.e2}/usuarios", json={"correo": ids.correo_x, "rol": "Contador"}, headers=H(tp))
    assert r.status_code == 200 and r.json()["motivo"] == "otras", r.text
    assert c.delete(f"/api/admin/cuentas/{ids.e1}/usuarios/{ids.x}", headers=H(tp)).status_code == 200
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", json={}, headers=H(_token(ids.a2, ids.e2)))
    assert r.status_code == 409 and r.json()["detail"] == auth.MENSAJE_CUENTA_TRAIDA


def test_b_solo_en_la_web(equipo, monkeypatch):
    c, ids = equipo
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.delenv("FE_LOCAL_ADMIN", raising=False)
    r = c.post(f"/api/auth/usuarios/{ids.x}/password", json={}, headers=H(_token(ids.a1, ids.e1)))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web"
    linea = next(x for x in (pathlib.Path(auth.__file__)).read_text(encoding="utf-8").splitlines()
                 if x.startswith('@router.post("/usuarios/{uid}/password"'))
    assert "Depends(solo_web)" in linea
    monkeypatch.delenv("FE_MODO_LOCAL")
    assert not _cuenta(ids.correo_x).debe_cambiar_password


def test_b_pantalla_usuarios():
    sec = (JS / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    usu = sec[sec.index("const SecUsuarios = {"):sec.index("// ------------------------------------------------------------------ Mi perfil")]
    assert "api('/api/auth/usuarios/' + u.id + '/password', { method: 'POST', body: {} })" in usu
    assert 'title="Restablecer contraseña"' in usu and "🔑" in usu and "!esLocal" in usu
    assert "Désela a la persona: deberá cambiarla al entrar." in usu and "copiarClave" in usu
    assert "prompt(" not in usu
    assert "usuario_password_restablecida:" in sec
