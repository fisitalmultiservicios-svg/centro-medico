"""3.87: permisos de la caja y de Ventas en línea en el servidor.
- La página en línea: el Cajero y el Mesero (solo caja) la leen y atienden los pedidos, pero no la editan; quien administra ítems
  (Vendedor, Supervisor de caja, Recepcionista, Avanzado) edita textos, fotos, horario y publicación; el SINPE, la tarjeta (Tilopay),
  el correo de aviso, el dominio y los píxeles solo los cambia quien configura.
- Entregas: la caja ve zonas y motorizados, asigna y entrega; zonas, ubicación y motorizados los administra quien tiene «catalogos»
  y las liquidaciones quien tiene «gastos».
- Cupones, fidelización y tarjetas: la caja valida, usa, acredita (solo por una venta o un pedido que existen, con tope en su total),
  canjea y vende; crear o cambiar cupones, configurar puntos, regalar puntos, listar, recargar o anular tarjetas pide «catalogos». En la página: promociones, extras, opcionales, ajustes y
  diseño piden «catalogos»; el configurador, «configurar».
- El Cajero no recibe costos, márgenes ni el valor del inventario.
- Cambiar de plan ajusta las cajas a las del plan nuevo; el restaurante nuevo nace con una cuenta de efectivo.
- La lista de usuarios: completa con «usuarios», solo nombres para los demás roles, nada para la caja ni los tokens de API."""
import json
import pathlib
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, main as _main, modulos, planes
from app.config import ahora_cr
from app.db import Cliente, Documento, Empresa, engine, engine_empresa, init_db
from app.main import app

init_db()
RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"

BASE = {"ver"}
ROLES = {   # permisos efectivos de cada rol que interesa (los propios de ROLES_POR_TIPO y un «Mesero» de solo caja)
    "Administrador": None, "Avanzado": None, "Vendedor": None, "Cajero": None, "Contador": None,
    "Mesero": BASE | {"pos"},
    "Supervisor de caja": BASE | {"escribir", "facturar", "catalogos", "inventario", "cobros", "pos"},
    "Recepcionista": BASE | {"escribir", "facturar", "catalogos", "cobros", "pos"},
}
CAJA = ("Cajero", "Mesero")
GESTION = ("Vendedor", "Supervisor de caja", "Recepcionista", "Avanzado")


@pytest.fixture
def tienda():
    """Empresa restaurante sin plan (todo encendido) y un cliente HTTP cuyo rol se cambia con c.como(rol)."""
    with Session(engine) as s:
        e = Empresa(nombre="Soda Permisos QA 387", numero_id="3101387401", actividad="561001", otras_senas="Frente al parque",
                    correo="soda387@example.test", ambiente="sandbox", tipo_negocio="restaurante")
        s.add(e); s.commit(); s.refresh(e)
    with Session(engine_empresa(e.id)) as s:                 # la caja que recibe los pedidos en línea
        modulos.reemplazar(s, e.id, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA 387", "modo": "restaurante", "mesas": []}]})
    estado = {"rol": "Administrador"}
    usuario = types.SimpleNamespace(id=None, correo="dueno.tienda387@example.test", es_superadmin=False, nombre="QA 387")

    def ctx():
        rol = estado["rol"]
        c = auth.Contexto(usuario, e, rol, permisos=ROLES.get(rol))
        if estado.get("api"):
            c.token_api = types.SimpleNamespace(prefijo="fcr_qa387", id=0)
        return c
    app.dependency_overrides[auth.contexto] = ctx
    c = TestClient(app)

    def como(rol, api=False):
        estado["rol"] = rol; estado["api"] = api
        return c
    c.como = como
    c.eid = e.id
    try:
        yield c
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            x = s.get(Empresa, e.id)
            if x:
                s.delete(x); s.commit()


def _negocio(**extra):
    d = {"slug": "soda-permisos-387", "activo": True, "nombre": "Soda Permisos 387", "bienvenida": "Bienvenidos", "whatsapp": "88887777", "acepta_recoger": True,
         "acepta_domicilio": True, "costo_envio": 1000, "minimo_pedido": 0, "horarios": [], "redes": {}, "abierto_manual": True,
         "pago_sinpe": True, "sinpe_numero": "88001122", "sinpe_nombre": "Soda Permisos SA", "correo_aviso": "avisos387@example.test"}
    d.update(extra)
    return d


def _producto(c, nombre="Casado QA 387", costo=0):
    r = c.como("Administrador").post("/api/productos", json={"nombre": nombre, "cabys": "2111100000000", "precio": 4000, "tarifa": 13, "codigo_tarifa": "08",
                                                             "visible_catalogo": True, "categoria": "Platos", "costo": costo})
    assert r.status_code == 200, r.text
    return r.json()


def test_pagina_en_linea_la_caja_opera_pero_no_configura(tienda):
    c = tienda
    p = _producto(c)
    r = c.como("Administrador").put("/api/pedidos/negocio", json=_negocio())
    assert r.status_code == 200, r.text
    for rol in CAJA:
        c.como(rol)
        assert c.put("/api/pedidos/negocio", json=_negocio(sinpe_numero="87776655", sinpe_nombre="Cuenta del cajero")).status_code == 403, rol
        n = c.get("/api/pedidos/negocio")
        assert n.status_code == 200 and n.json()["slug"] == "soda-permisos-387"                  # la bandeja y el aviso «no publicada» lo leen
        assert n.json()["correo_aviso"] is None and n.json()["mayorista_codigo"] == ""            # sin datos de configuración
        assert c.put("/api/pedidos/negocio", json=_negocio(activo=False)).status_code == 403, rol
        assert c.post("/api/pedidos/negocio/galeria", files={"archivo": ("f.png", b"\x89PNG qa", "image/png")}).status_code == 403
        assert c.delete("/api/pedidos/negocio/portada").status_code == 403
        assert c.post("/api/pedidos/negocio/dominio/verificar", json={}).status_code == 403
        assert c.post("/api/pedidos/negocio/tilopay/probar", json={}).status_code == 403
    pub = c.get("/api/publico/soda-permisos-387").json()
    assert pub["sinpe"]["numero"] == "88001122"                                                    # el público sigue viendo el número del negocio
    # quien administra los ítems edita la página (textos, publicación) pero no el cobro, el correo de aviso, el dominio ni los píxeles
    actual = c.como("Administrador").get("/api/pedidos/negocio").json()
    for rol in GESTION:
        c.como(rol)
        r = c.put("/api/pedidos/negocio", json={**actual, "bienvenida": "Hoy casado " + rol, "tilopay_key": None, "tilopay_user": None, "tilopay_password": None})
        assert r.status_code == 200, (rol, r.text)
        assert r.json()["bienvenida"] == "Hoy casado " + rol and r.json()["sinpe_numero"] == "88001122"
        for cambio in ({"sinpe_numero": "87776655"}, {"sinpe_nombre": "Otra cuenta"}, {"pago_sinpe": False}, {"correo_aviso": "otro387@example.test"},
                       {"dominio": "www.otro387.cr"}, {"pixel_meta": "123456789012345"}, {"tilopay_key": "llave-ajena"}):
            r = c.put("/api/pedidos/negocio", json={**actual, **cambio})
            assert r.status_code == 403 and "administrador" in r.json()["detail"], (rol, cambio, r.text)
        assert c.post("/api/pedidos/negocio/tilopay/probar", json={}).status_code == 403
    # un cuerpo sin esos campos no los borra
    r = c.como("Vendedor").put("/api/pedidos/negocio", json={"slug": "soda-permisos-387", "activo": True, "acepta_recoger": True, "horarios": [], "redes": {}})
    assert r.status_code == 200, r.text
    n = c.como("Administrador").get("/api/pedidos/negocio").json()
    assert n["sinpe_numero"] == "88001122" and n["pago_sinpe"] and n["sinpe_nombre"] == "Soda Permisos SA" and n["correo_aviso"] == "avisos387@example.test"
    # el administrador sí cambia el cobro
    r = c.put("/api/pedidos/negocio", json={**n, "sinpe_numero": "87001234", "tilopay_key": None, "tilopay_user": None, "tilopay_password": None})
    assert r.status_code == 200 and r.json()["sinpe_numero"] == "87001234", r.text
    # la caja sigue atendiendo los pedidos: lista y estados
    ped = c.post("/api/publico/soda-permisos-387/pedido", json={"nombre": "Ana", "telefono": "88880001", "tipo": "recoger", "lineas": [{"producto_id": p["id"], "cantidad": 1}]})
    assert ped.status_code == 200, ped.text
    c.como("Cajero")
    assert any(x["id"] == ped.json()["id"] for x in c.get("/api/pedidos").json())
    assert c.put(f"/api/pedidos/{ped.json()['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    # y pausa o reanuda los pedidos en línea en un pico de trabajo, sin tocar el resto de la página
    for rol in CAJA:
        r = c.como(rol).put("/api/pedidos/negocio/abierto", json={"abierto_manual": False})
        assert r.status_code == 200 and r.json()["abierto"]["abierto"] is False, r.text
    cerrado = c.post("/api/publico/soda-permisos-387/pedido", json={"nombre": "Eva", "telefono": "88880003", "tipo": "recoger", "lineas": [{"producto_id": p["id"], "cantidad": 1}]})
    assert cerrado.status_code == 400, cerrado.text
    assert c.put("/api/pedidos/negocio/abierto", json={"abierto_manual": None}).json()["abierto"]["abierto"] is True
    n = c.como("Administrador").get("/api/pedidos/negocio").json()
    assert n["abierto_manual"] is None and n["sinpe_numero"] == "87001234" and n["slug"] == "soda-permisos-387"
    assert c.como("Contador").put("/api/pedidos/negocio/abierto", json={"abierto_manual": False}).status_code == 403   # sin caja, no
    # la caja pausa y reanuda, pero no deja la página «abierta siempre» fuera del horario (eso es del horario, en Mi página)
    for rol in CAJA:
        r = c.como(rol).put("/api/pedidos/negocio/abierto", json={"abierto_manual": True})
        assert r.status_code == 403, (rol, r.text)
    assert c.como("Administrador").get("/api/pedidos/negocio").json()["abierto_manual"] is None
    r = c.como("Vendedor").put("/api/pedidos/negocio/abierto", json={"abierto_manual": True})
    assert r.status_code == 200 and r.json()["abierto_manual"] is True, r.text


LIB = (10.0, -84.0)


def test_entregas_la_caja_asigna_y_entrega_sin_administrar(tienda):
    c = tienda
    p = _producto(c, "Casado entregas 387")
    adm = c.como("Administrador")
    assert adm.put("/api/pedidos/negocio", json=_negocio(slug="soda-entregas-387", pago_sinpe=False, sinpe_numero="")).status_code == 200
    assert adm.put("/api/entregas/ubicacion", json={"lat": LIB[0], "lng": LIB[1]}).status_code == 200
    z = adm.post("/api/entregas/zonas", json={"nombre": "Centro", "lat": LIB[0], "lng": LIB[1], "radio_km": 3, "precio": 1200}).json()
    m = adm.post("/api/entregas/motorizados", json={"nombre": "Moto Admin", "telefono": "87001387", "vehiculo": "moto", "pago_entrega": 1000, "clave": "2580"}).json()
    zona = {"nombre": "Gratis", "lat": LIB[0], "lng": LIB[1], "radio_km": 1, "precio": 0}
    moto = {"nombre": "Moto Cajero", "telefono": "87669999", "vehiculo": "moto", "pago_entrega": 50000, "clave": "7391"}
    for rol in CAJA:
        c.como(rol)
        assert c.get("/api/entregas/zonas").status_code == 200 and c.get("/api/entregas/motorizados").status_code == 200   # el selector de asignar
        assert c.put("/api/entregas/ubicacion", json={"lat": 9.0, "lng": -84.0}).status_code == 403
        assert c.post("/api/entregas/zonas", json=zona).status_code == 403
        assert c.put(f"/api/entregas/zonas/{z['id']}", json={**zona, "nombre": "Centro"}).status_code == 403
        assert c.delete(f"/api/entregas/zonas/{z['id']}").status_code == 403
        assert c.post("/api/entregas/motorizados", json=moto).status_code == 403
        assert c.put(f"/api/entregas/motorizados/{m['id']}", json={**moto, "nombre": "Moto Admin", "telefono": "87001387", "clave": "9753"}).status_code == 403   # no reinicia la clave
        assert c.delete(f"/api/entregas/motorizados/{m['id']}").status_code == 403
        assert c.get("/api/entregas/liquidaciones/pendientes").status_code == 403
        assert c.post("/api/entregas/liquidaciones", json={"motorizado_id": m["id"], "hasta": ahora_cr().date().isoformat()}).status_code == 403
    # la caja opera: confirma el pedido a domicilio, asigna el motorizado y cierra la entrega
    ped = c.post("/api/publico/soda-entregas-387/pedido", json={"nombre": "Luis", "telefono": "88880002", "tipo": "domicilio", "direccion": "Casa azul",
                                                               "lat": LIB[0] + 0.01, "lng": LIB[1], "lineas": [{"producto_id": p["id"], "cantidad": 1}]})
    assert ped.status_code == 200, ped.text
    c.como("Cajero")
    en = c.put(f"/api/pedidos/{ped.json()['id']}/estado", json={"estado": "confirmado"}).json()["entrega"]
    assert c.put(f"/api/entregas/{en['id']}/asignar", json={"motorizado_id": m["id"]}).status_code == 200
    assert c.get("/api/entregas?abiertas=1").status_code == 200
    assert c.put(f"/api/entregas/{en['id']}/entregada").status_code == 200
    # quien administra ítems administra zonas y motorizados; liquidar es un pago a terceros (gastos)
    for rol in ("Vendedor", "Supervisor de caja"):
        c.como(rol)
        r = c.post("/api/entregas/zonas", json={**zona, "nombre": "Zona " + rol}); assert r.status_code == 200, r.text
        assert c.get("/api/entregas/liquidaciones/pendientes").status_code == 200
        assert c.post("/api/entregas/liquidaciones", json={"motorizado_id": m["id"], "hasta": ahora_cr().date().isoformat()}).status_code == 403
    r = c.como("Avanzado").post("/api/entregas/liquidaciones", json={"motorizado_id": m["id"], "hasta": ahora_cr().date().isoformat(), "nota": "QA"})
    assert r.status_code == 200 and r.json()["total"] == 1000, r.text


def test_promociones_la_caja_usa_pero_no_crea(tienda):
    c = tienda
    adm = c.como("Administrador")
    cup = adm.post("/api/cupones", json={"codigo": "ADMIN10", "tipo": "pct", "valor": 10, "canales": ["caja", "online"]}).json()
    assert adm.put("/api/fidelizacion/config", json={"activo": True, "puntos_por_mil": 10, "valor_punto": 1, "minimo_canje": 0, "maximo_pct": 50}).status_code == 200
    tar = adm.post("/api/tarjetas", json={"monto": 5000, "meses_vigencia": 0}).json()
    docs = _ventas_con_cliente(c, len(CAJA), total=10000)
    for rol, (cli, consec) in zip(CAJA, docs):
        c.como(rol)
        assert c.post("/api/cupones", json={"codigo": "CIEN" + rol[:3].upper(), "tipo": "pct", "valor": 100, "canales": ["caja", "online"]}).status_code == 403, rol
        assert c.put(f"/api/cupones/{cup['id']}", json={"codigo": "ADMIN10", "tipo": "pct", "valor": 100}).status_code == 403
        assert c.delete(f"/api/cupones/{cup['id']}").status_code == 403
        assert c.put("/api/fidelizacion/config", json={"activo": True, "puntos_por_mil": 1000, "valor_punto": 100000, "minimo_canje": 0, "maximo_pct": 100}).status_code == 403
        assert c.post("/api/fidelizacion/ajuste", json={"telefono": "88887777", "puntos": 50000}).status_code == 403
        assert c.get("/api/tarjetas").status_code == 403                                        # la lista trae los códigos de todas las tarjetas
        assert c.post(f"/api/tarjetas/{tar['codigo']}/recargar", json={"monto": 1000000}).status_code == 403
        assert c.delete(f"/api/tarjetas/{tar['codigo']}").status_code == 403
        # lo que la caja usa al cobrar sigue igual
        v = c.post("/api/cupones/validar", json={"codigo": "ADMIN10", "subtotal": 10000})
        assert v.status_code == 200 and v.json()["descuento"] == 1000
        assert c.post("/api/cupones/usar", json={"codigo": "ADMIN10", "subtotal": 10000, "referencia": "doc:" + rol}).status_code == 200
        assert c.get("/api/fidelizacion/config").status_code == 200
        a = c.post("/api/fidelizacion/acreditar", json={"cliente_id": cli, "telefono": "88887777", "monto": 10000, "referencia": "doc:" + consec})
        assert a.status_code == 200 and a.json()["puntos"] == 100, a.text                     # como lo manda la caja al cobrar
        assert c.post("/api/fidelizacion/canjear", json={"telefono": "88887777", "puntos": 10, "monto": 10000, "referencia": "doc:c" + rol}).json()["descuento"] == 10
        assert c.get("/api/fidelizacion/saldo?telefono=88887777").status_code == 200
        assert c.post("/api/tarjetas", json={"monto": 2000, "meses_vigencia": 0}).status_code == 400   # 4.5: desde la caja, solo con el cobro en una cuenta de Bancos
        venta = c.post("/api/tarjetas", json={"monto": 2000, "meses_vigencia": 0, "medio": "01", "cuenta": "Caja general"})
        assert venta.status_code == 400 and "no existe en Bancos" in venta.text, venta.text     # esta empresa de prueba no tiene cuentas: sin cobro no hay tarjeta
        assert c.get(f"/api/tarjetas/{tar['codigo']}").status_code == 200
        assert c.post(f"/api/tarjetas/{tar['codigo']}/canjear", json={"monto": 100, "referencia": "doc:t" + rol}).json()["aplicado"] == 100
    t = c.como("Administrador").get(f"/api/tarjetas/{tar['codigo']}").json()
    assert t["saldo"] == 4800 and t["activa"]                                                    # nadie de la caja la recargó ni la anuló
    assert c.get(f"/api/cupones").json()[0]["valor"] == 10
    for rol in GESTION:
        c.como(rol)
        r = c.post("/api/cupones", json={"codigo": "QA" + rol[:4].upper().replace(" ", ""), "tipo": "pct", "valor": 15}); assert r.status_code == 200, (rol, r.text)
        assert c.post("/api/fidelizacion/ajuste", json={"telefono": "88887777", "puntos": 5, "motivo": "Bienvenida"}).status_code == 200
        assert c.get("/api/tarjetas").status_code == 200
        assert c.post(f"/api/tarjetas/{tar['codigo']}/recargar", json={"monto": 100}).status_code == 200


def _ventas_con_cliente(c, n, total, telefono=88887777):
    """n tiquetes de la caja con un cliente (su celular es el teléfono de los puntos); devuelve [(cliente_id, consecutivo)]."""
    out = []
    with Session(engine_empresa(c.eid)) as s:
        cli = Cliente(empresa_id=c.eid, nombre="Ana Puntos QA 387", numero_id="114560387", celular=telefono)
        s.add(cli); s.commit(); s.refresh(cli)
        for i in range(n):
            consec = f"0010000104{c.eid:05d}{i:05d}"
            s.add(Documento(empresa_id=c.eid, tipo_documento="04", clave=f"qa387{c.eid}x{i}".ljust(50, "0"), consecutivo=consec, fecha_emision=ahora_cr().isoformat(),
                            cliente_id=cli.id, total=total, estado="aceptado"))
            out.append((cli.id, consec))
        s.commit()
    return out


def test_la_caja_acredita_puntos_solo_por_una_venta_que_existe(tienda):
    """Revisión 3.87: el Cajero ya no se regala puntos «acreditando» una compra inventada (antes 50 000 puntos y luego el canje)."""
    c = tienda
    p = _producto(c, "Casado puntos 387")
    assert c.como("Administrador").put("/api/fidelizacion/config", json={"activo": True, "puntos_por_mil": 10, "valor_punto": 1, "minimo_canje": 0,
                                                                         "maximo_pct": 50}).status_code == 200
    assert c.put("/api/pedidos/negocio", json=_negocio(slug="soda-puntos-387", pago_sinpe=False, sinpe_numero="")).status_code == 200
    (cli, consec), (_, consec2) = _ventas_con_cliente(c, 2, total=10000)
    for rol in CAJA:
        c.como(rol)
        for cuerpo in ({"telefono": "88887777", "monto": 5_000_000, "referencia": "doc:inventado-" + rol},
                       {"telefono": "88887777", "monto": 5_000_000, "referencia": "pedido:999999"}):
            r = c.post("/api/fidelizacion/acreditar", json=cuerpo)
            assert r.status_code == 400, (rol, cuerpo, r.text)
        for cuerpo in ({"telefono": "88887777", "monto": 5_000_000}, {"telefono": "88887777", "monto": 5_000_000, "referencia": "caja:regalo"}):
            r = c.post("/api/fidelizacion/acreditar", json=cuerpo)
            assert r.status_code == 403 and "ajuste manual" in r.json()["detail"], (rol, cuerpo, r.text)
        # la venta existe, pero sus puntos no se pasan a otro teléfono
        r = c.post("/api/fidelizacion/acreditar", json={"telefono": "87776655", "monto": 10000, "referencia": "doc:" + consec})
        assert r.status_code == 400, r.text
        assert c.get("/api/fidelizacion/saldo?telefono=88887777").json()["saldo"] == 0
        assert c.get("/api/fidelizacion/saldo?telefono=87776655").json()["saldo"] == 0
    # una venta real de 10 000: el monto se topa en su total (100 puntos, no 50 000) y no se acredita dos veces
    c.como("Cajero")
    r = c.post("/api/fidelizacion/acreditar", json={"cliente_id": cli, "telefono": "88887777", "monto": 5_000_000, "referencia": "doc:" + consec})
    assert r.status_code == 200 and r.json()["puntos"] == 100, r.text
    assert c.post("/api/fidelizacion/acreditar", json={"cliente_id": cli, "telefono": "88887777", "monto": 10000, "referencia": "doc:" + consec}).json()["puntos"] == 0
    r = c.post("/api/fidelizacion/acreditar", json={"cliente_id": cli, "monto": 10000, "referencia": "doc:" + consec2})   # cliente sin teléfono en la caja
    assert r.status_code == 200 and r.json()["puntos"] == 100, r.text
    canje = c.post("/api/fidelizacion/canjear", json={"telefono": "88887777", "puntos": 5000, "monto": 10000, "referencia": "doc:x"})
    assert canje.status_code == 400, canje.text                                                       # ya no hay 50 000 puntos que canjear
    # el pedido en línea cobrado en la caja: con el teléfono del pedido y tope en su total
    ped = c.post("/api/publico/soda-puntos-387/pedido", json={"nombre": "Eva", "telefono": "88880009", "tipo": "recoger", "lineas": [{"producto_id": p["id"], "cantidad": 1}]})
    assert ped.status_code == 200, ped.text
    ref = f"pedido:{ped.json()['id']}"
    assert c.post("/api/fidelizacion/acreditar", json={"telefono": "88887777", "monto": 4520, "referencia": ref}).status_code == 400
    r = c.post("/api/fidelizacion/acreditar", json={"telefono": "88880009", "monto": 5_000_000, "referencia": ref})
    assert r.status_code == 200 and r.json()["puntos"] == round(ped.json()["total"] / 100, 2), r.text
    # quien administra los ítems sigue acreditando a mano (también tiene el ajuste manual)
    r = c.como("Vendedor").post("/api/fidelizacion/acreditar", json={"telefono": "88880010", "monto": 20000, "referencia": "manual:1"})
    assert r.status_code == 200 and r.json()["puntos"] == 200, r.text


def test_pagina_fisitaap_gestion_y_configurador(tienda):
    c = tienda
    p = _producto(c, "Pizza 387")
    for rol in CAJA:
        c.como(rol)
        assert c.get("/api/fisitaap/ajustes").status_code == 200 and c.get("/api/fisitaap/express/pendientes").status_code == 200
        assert c.put("/api/fisitaap/ajustes", json={"metodos_pago": ["Efectivo"]}).status_code == 403
        assert c.put("/api/fisitaap/diseno", json={"campos": {"hero_title": "Del cajero"}}).status_code == 403
        assert c.post("/api/fisitaap/promociones", json={"producto_id": p["id"], "tipo": "special", "valor": 1}).status_code == 403
        assert c.post("/api/fisitaap/extras", json={"nombre": "Queso extra", "precio": 0}).status_code == 403
        assert c.post("/api/fisitaap/opcionales", json={"nombre": "Término", "opciones": [{"nombre": "Medio"}]}).status_code == 403
        assert c.delete("/api/fisitaap/modificadores/1").status_code == 403
        assert c.put("/api/fisitaap/configurador", json={"accion": "reset"}).status_code == 403
    c.como("Vendedor")
    assert c.put("/api/fisitaap/ajustes", json={"metodos_pago": ["Efectivo", "SINPE Móvil"]}).status_code == 200
    g = c.post("/api/fisitaap/extras", json={"nombre": "Queso extra", "precio": 500})
    assert g.status_code == 200, g.text
    assert c.put("/api/fisitaap/configurador", json={"accion": "reset"}).status_code == 403            # el recorrido guiado es del dueño
    assert c.como("Administrador").put("/api/fisitaap/configurador", json={"accion": "reset"}).status_code == 200


def test_cajero_no_recibe_costos_del_inventario(tienda):
    c = tienda
    p = _producto(c, "Galleta Verif QA 387", costo=700)
    adm = c.como("Administrador")
    aj = adm.post("/api/inventario/ajustes", json={"lineas": [{"producto_id": p["id"], "cantidad": 10, "costo_unitario": 700}]})
    assert aj.status_code == 200, aj.text
    aid = aj.json()["id"]
    with Session(engine_empresa(c.eid)) as s:
        modulos.reemplazar(s, c.eid, "recetas", [{"id": 1, "producto_id": p["id"], "ingredientes": [{"producto_id": p["id"], "cantidad": 1}], "rendimiento": 1}])
    for rol in CAJA:
        c.como(rol)
        prods = c.get("/api/productos").json()
        assert prods and all("costo" not in x for x in prods) and prods[0]["precio"] == 4000       # la caja vende con el precio, sin el costo
        ex = c.get("/api/inventario/existencias").json()
        assert ex and ex[0]["cantidad"] == 10 and "costo_promedio" not in ex[0] and "valor" not in ex[0]
        assert all("costo_promedio" not in b for x in ex for b in x["bodegas"].values())
        for ruta in ("/api/inventario/valor", "/api/inventario/ajustes", f"/api/inventario/ajustes/{aid}", f"/api/inventario/capas?producto_id={p['id']}",
                     "/api/inventario/recetas/costos", "/api/sinc/catalogo"):
            assert c.get(ruta).status_code == 403, (rol, ruta)
        assert c.get("/api/inventario/recetas/porciones").status_code == 200                      # la caja sí ve cuántas porciones alcanzan
        co = c.get("/api/fisitaap/combos")                                                          # Catálogo web › Combos: tampoco por ahí
        assert co.status_code == 200 and co.json()["productos"] and all("costo" not in x for x in co.json()["productos"]), (rol, co.text)
        with Session(engine_empresa(c.eid)) as s:                                                    # /api/arranque usa la misma función
            assert all("costo" not in x for x in _main.productos(None, app.dependency_overrides[auth.contexto](), s))
    for rol in ("Vendedor", "Supervisor de caja", "Avanzado"):
        c.como(rol)
        assert c.get("/api/productos").json()[0]["costo"] == 700
        assert c.get("/api/inventario/existencias").json()[0]["costo_promedio"] == 700
        assert c.get("/api/inventario/valor").json()["total"] == 7000
        assert c.get("/api/inventario/recetas/costos").status_code == 200
        assert c.get("/api/fisitaap/combos").json()["productos"][0]["costo"] == 700


def test_cambiar_de_plan_ajusta_las_cajas():
    e = Empresa(nombre="Comercio cajas QA 387", correo="cajas387@example.test", tipo_negocio="comercio")
    for plan, enviadas, esperadas in (("pos_basico", 0, 1), ("pos", 1, 2), ("pos_basico", 2, 1), ("pos", 3, 3), ("pos", 3, 3), ("pos", 0, 2), ("pos_basico", 3, 3)):
        planes.asignar(e, {"plan": plan, "extras": [], "cajas": enviadas})
        assert (e.plan, e.cajas) == (plan, esperadas), (plan, enviadas, e.cajas)
    r = Empresa(nombre="Restaurante cajas QA 387", correo="rcajas387@example.test", tipo_negocio="restaurante")
    planes.asignar(r, {"plan": "rest_basico", "cajas": 0}); assert r.cajas == 1
    planes.asignar(r, {"plan": "rest", "cajas": 1}); assert r.cajas == 2
    h = Empresa(nombre="Hotel cajas QA 387", correo="hcajas387@example.test", tipo_negocio="hospitalidad")
    planes.asignar(h, {"plan": "hotel", "habitaciones": 10, "cajas": 0}); assert h.cajas == 0       # los planes sin cajas no cambian
    admin = (RAIZ / "static/js/pages/admin.js").read_text(encoding="utf-8")
    assert 'help="Punto de venta; 0 = sin límite"' not in admin and "alCambiarPlan" in admin


def test_restaurante_nuevo_nace_con_cuenta_de_efectivo():
    with Session(engine) as s:
        e = auth.crear_empresa(s, "Soda Efectivo QA 387", "efectivo387@example.test", tipo_negocio="restaurante")
        eid = e.id
    try:
        with Session(engine_empresa(eid)) as s:
            bancos = modulos.leer(s, eid, "bancos", [])
            cfg = modulos.leer(s, eid, "pos_config", {})
        assert [(b["nombre"], b["tipo"], b["moneda"]) for b in bancos] == [("Caja general", "Efectivo", "CRC")]
        assert not bancos[0].get("ejemplo") and bancos[0]["saldo_inicial"] == 0 and not bancos[0]["principal"]
        assert cfg["terminales"][0]["nombre"] == "Caja salón" and len(cfg["terminales"][0]["mesas"]) == 6
        with Session(engine_empresa(eid)) as s:                                                       # no se siembra dos veces ni pisa lo del cliente
            assert modulos.cuenta_efectivo_inicial(s, eid) is False
    finally:
        with Session(engine) as s:
            x = s.get(Empresa, eid)
            if x:
                s.delete(x); s.commit()


def test_lista_de_usuarios_segun_el_rol(tienda):
    c = tienda
    with Session(engine) as s:
        creados = []
        for correo, rol in (("dueno.usr387@example.test", "Administrador"), ("cajero.usr387@example.test", "Cajero"), ("vend.usr387@example.test", "Vendedor"),
                            ("sinnombre.usr387@example.test", "Vendedor")):
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if not u:
                u = auth.Usuario(correo=correo, nombre="" if correo.startswith("sinnombre") else correo.split("@")[0], password_hash="x", mfa_activo=rol == "Administrador")
                s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=c.eid, rol=rol)); s.commit()
            creados.append(u.id)
    try:
        for rol in CAJA:
            assert c.como(rol).get("/api/auth/usuarios").status_code == 403, rol
        assert c.como("Administrador", api=True).get("/api/auth/usuarios").status_code == 403           # token de integración
        for rol in ("Vendedor", "Contador", "Avanzado", "Supervisor de caja"):
            lista = c.como(rol).get("/api/auth/usuarios").json()
            assert len(lista) == 4 and all(set(x) == {"id", "nombre"} for x in lista), (rol, lista)      # nombres para Mis tareas, sin correos ni MFA
            assert {x["nombre"] for x in lista} == {"dueno.usr387", "cajero.usr387", "vend.usr387", f"Usuario {creados[-1]}"}   # sin nombre: rótulo, no el correo
        lista = c.como("Administrador").get("/api/auth/usuarios").json()
        assert len(lista) == 4 and {"correo", "rol", "mfa_activo", "ultimo_acceso"} <= set(lista[0])
    finally:
        with Session(engine) as s:
            for uid in creados:
                for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid)).all():
                    s.delete(m)
                u = s.get(auth.Usuario, uid)
                if u:
                    s.delete(u)
            s.commit()


def test_pantallas_no_ofrecen_lo_que_el_rol_no_puede():
    js = lambda r: (RAIZ / "static/js" / r).read_text(encoding="utf-8")   # noqa: E731
    express = js("fis/pages/express.js")
    assert "v-if=\"sesion.puede('catalogos')\"" in express                          # invitar, pausar y bloquear motorizados
    af = js("fis/pages/afiliados.js")
    assert "sesion.puede('gastos')" in af and "sesion.puede('catalogos')" in af
    conf = js("fis/pages/configuracion.js")
    assert ":disabled=\"!cobros\"" in conf and "cobros() { return sesion.puede('configurar'); }" in conf
    pub = js("fis/pages/publicar.js")
    assert ":disabled=\"!cobros\"" in pub
    sec = js("pages/configuracion/seccion.js")
    assert "if (!sesion.puede('usuarios'))" in sec
    emp = js("pages/rrhh/empleados.js")
    assert "if (sesion.puede('usuarios')) api('/api/auth/usuarios')" in emp
    ped = js("fis/pages/pedidos.js")
    assert "api('/api/pedidos/negocio/abierto', { method: 'PUT'" in ped and "Pausar pedidos en línea" in ped
    assert "from '/js/avisos.js'" in ped and "Avisar en este dispositivo" in ped                     # los avisos de pedido, también desde Pedidos
    hist = js("fis/pages/historial.js")                                                             # Historial: la caja no pide las liquidaciones
    assert "sesion.puede('catalogos') ? await api('/api/entregas/liquidaciones') : []" in hist and "v-if=\"sesion.puede('catalogos')\"><h2>Liquidaciones hechas" in hist
    fid = js("fis/pages/fidelizacion.js")                                                            # Fidelización: la caja la ve sin la lista de tarjetas
    assert "this.gestiona ? api('/api/tarjetas') : Promise.resolve([])" in fid and "gestiona() { return sesion.puede('catalogos'); }" in fid
    assert 'v-if="gestiona"><h2>Tarjeta de regalo promocional' in fid and '<template v-if="gestiona"><hr><h3>Ajuste manual de puntos' in fid
    combos = js("fis/pages/combos.js")
    assert "(+p.costo || 0)" in combos and 'v-if="conCosto"' in combos
