"""3.68: prueba gratis automática desde el formulario público (crea usuario + empresa al instante y manda la bienvenida) y
verificación Turnstile de Cloudflare. Sin correo configurado, con un correo que ya tiene cuenta o con «Solo información» no se
crea nada y la solicitud queda con el motivo para atenderla a mano."""
import re
import types
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, demo, sitio
from app.config import ahora_cr
from app.db import Empresa, engine, init_db
from app.main import app

init_db()
c = TestClient(app)
COMPLETO = {"nombre": "Marta Solano", "empresa": "Ferretería El Tornillo", "cedula": "3-101-777888", "telefono": "+506 8888-7777", "correo": "marta368@example.test",
            "tipo": "comercio", "plan": "Prueba gratis de 1 mes", "mensaje": "Ferretería en Cartago con dos cajas; facturamos a crédito a empresas", "segundos": 20}


def _config(automatica=True, dias=30, **prueba):
    cfg = sitio.leer()
    cfg["prueba"].update({"automatica": automatica, "dias": dias, **prueba})
    sitio.guardar(cfg)


@pytest.fixture(autouse=True)
def _sin_limite_por_ip():
    """Los límites por IP del formulario viven en memoria: se limpian antes y después para no afectar a otras pruebas."""
    auth._intentos_ip.clear()
    yield
    auth._intentos_ip.clear()


def _post(datos):
    auth._intentos_ip.clear()
    return c.post("/api/contacto", json=datos)


def _solicitud(correo):
    with Session(engine) as s:
        return s.exec(select(sitio.SolicitudContacto).where(sitio.SolicitudContacto.correo == correo).order_by(sitio.SolicitudContacto.id.desc())).first()


def test_formulario_automatico_pide_los_datos_de_la_empresa(monkeypatch):
    _config(False)
    try:
        pagina = c.get("/prueba-gratis").text
        assert 'data-auto="1"' not in pagina and 'name="cedula"' not in pagina and "Déjenos sus datos" in pagina and "Llene el formulario" not in pagina
        _config(True)
        pagina = c.get("/prueba-gratis").text
        assert 'data-auto="1"' in pagina and 'name="cedula"' in pagina and 'name="tipo"' in pagina and "Crear mi prueba gratis" in pagina
        assert "Llene el formulario" in pagina and "Déjenos sus datos" not in pagina and "<!--AUTO-->" not in pagina and "cf-turnstile" not in pagina
        # el servidor exige los datos cuando la prueba es automática
        monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: object())
        for campo, valor, aviso in (("empresa", "", "empresa"), ("cedula", "12", "cédula"), ("telefono", "1234", "8 dígitos"), ("tipo", "otro", "tipo de negocio"), ("mensaje", "corto", "dedica")):
            r = _post({**COMPLETO, campo: valor})
            assert r.status_code == 400 and aviso in r.json()["detail"], (campo, r.text)
    finally:
        sitio.ARCHIVO.unlink(missing_ok=True)


def test_crea_la_prueba_sola_y_manda_la_bienvenida(monkeypatch):
    _config(True, dias=21)
    enviados = []
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: object())
    monkeypatch.setattr(demo, "_bienvenida", lambda info, nombre: enviados.append((info["correo"], info["password_temporal"], nombre)) or True)
    try:
        r = _post(COMPLETO)
        assert r.status_code == 200, r.text
        assert r.json() == {"ok": True, "prueba": True, "correo_enviado": True}
        assert enviados and enviados[0][0] == "marta368@example.test" and re.fullmatch(r"[A-Z][a-z]+-[A-Z][a-z]+-\d{4}", enviados[0][1]) and enviados[0][2] == "Marta Solano"
        sol = _solicitud("marta368@example.test")
        assert sol.empresa_id and sol.atendida and sol.resultado == "Prueba creada automáticamente" and sol.cedula == "3101777888" and sol.telefono == "88887777" and sol.tipo_negocio == "comercio"
        with Session(engine) as s:
            e = s.get(Empresa, sol.empresa_id)
            assert e.nombre == "Ferretería El Tornillo" and e.numero_id == "3101777888" and e.tipo_negocio == "comercio"
            assert e.prueba_hasta == (ahora_cr().date() + timedelta(days=21)).isoformat()
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "marta368@example.test")).one()
            assert u.debe_cambiar_password and s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == e.id)).first().rol == "Administrador"
        # el mismo correo otra vez: no se crea una segunda cuenta
        r = _post({**COMPLETO, "cedula": "109990999"})
        assert r.status_code == 200 and r.json()["prueba"] is False
        assert "ya tiene cuenta" in _solicitud("marta368@example.test").resultado
        # otra persona con la misma cédula: tampoco
        r = _post({**COMPLETO, "correo": "otra368@example.test"})
        assert r.json()["prueba"] is False and "cédula" in _solicitud("otra368@example.test").resultado
        assert len(enviados) == 1
        # si la bienvenida no sale, la prueba existe pero la solicitud queda sin atender y lo dice
        monkeypatch.setattr(demo, "_bienvenida", lambda info, nombre: False)
        r = _post({**COMPLETO, "correo": "sinmail368@example.test", "cedula": "109990111"})
        assert r.json() == {"ok": True, "prueba": True, "correo_enviado": False}
        sol = _solicitud("sinmail368@example.test")
        assert sol.empresa_id and not sol.atendida and "NO salió" in sol.resultado
    finally:
        sitio.ARCHIVO.unlink(missing_ok=True)


def test_sin_correo_o_solo_informacion_no_crea_nada(monkeypatch):
    _config(True)
    try:
        monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: None)
        r = _post({**COMPLETO, "correo": "sinsmtp368@example.test", "cedula": "109990222"})
        assert r.status_code == 200 and r.json()["prueba"] is False
        sol = _solicitud("sinsmtp368@example.test")
        assert sol.empresa_id is None and not sol.atendida and "falta el correo" in sol.resultado
        with Session(engine) as s:
            assert s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sinsmtp368@example.test")).first() is None
        monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: object())
        r = _post({**COMPLETO, "correo": "info368@example.test", "plan": "", "empresa": "", "cedula": ""})     # «Solo información»: sin exigencias ni cuenta
        assert r.status_code == 200 and r.json()["prueba"] is False
        assert _solicitud("info368@example.test").resultado is None
        _config(False)
        r = _post({**COMPLETO, "correo": "manual368@example.test"})                                        # modo manual: como antes
        assert r.json()["prueba"] is False and _solicitud("manual368@example.test").empresa_id is None
    finally:
        sitio.ARCHIVO.unlink(missing_ok=True)


def test_turnstile_se_configura_sin_exponer_la_secreta_y_se_exige(monkeypatch):
    admin = types.SimpleNamespace(id=None, correo="admin@example.test", es_superadmin=True, nombre="Admin")
    app.dependency_overrides[auth.superadmin] = lambda: admin
    try:
        cfg = c.get("/api/admin/sitio").json()
        assert cfg["prueba"]["turnstile_configurado"] is False and "turnstile_secreto" not in cfg["prueba"]
        assert c.put("/api/admin/sitio", json={**cfg, "prueba": {**cfg["prueba"], "dias": 3}}).status_code == 400
        assert c.put("/api/admin/sitio", json={**cfg, "prueba": {**cfg["prueba"], "turnstile_sitio": "mal clave"}}).status_code == 400
        r = c.put("/api/admin/sitio", json={**cfg, "prueba": {"automatica": True, "dias": 14, "turnstile_sitio": "0x4AAAAAAAtest", "turnstile_secreto": "0x4AAAAAAAsecreto"}})
        assert r.status_code == 200, r.text
        assert r.json()["prueba"] == {"automatica": True, "dias": 14, "turnstile_sitio": "0x4AAAAAAAtest", "turnstile_configurado": True, "turnstile_login": False}
        guardado = sitio.leer()["prueba"]
        assert guardado["turnstile_secreto"] != "0x4AAAAAAAsecreto" and sitio._turnstile_secreto(sitio.leer()) == "0x4AAAAAAAsecreto"     # cifrada en disco
        # guardar de nuevo sin escribir la secreta la conserva; quitar la clave del sitio la borra
        c.put("/api/admin/sitio", json={**cfg, "prueba": {"automatica": True, "dias": 14, "turnstile_sitio": "0x4AAAAAAAtest", "turnstile_secreto": ""}})
        assert sitio._turnstile_secreto(sitio.leer()) == "0x4AAAAAAAsecreto"
        # la página carga el widget y la política de seguridad deja entrar a Cloudflare
        r = c.get("/prueba-gratis")
        assert 'class="cf-turnstile" data-sitekey="0x4AAAAAAAtest"' in r.text and "challenges.cloudflare.com/turnstile/v0/api.js" in r.text
        assert r.headers["Content-Security-Policy"].count("https://challenges.cloudflare.com") == 3 and "X-Pagina-Turnstile" not in r.headers
        assert "challenges.cloudflare.com" not in c.get("/api/auth/estado").headers["Content-Security-Policy"]
        # sin token se rechaza; con token se consulta a Cloudflare
        monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: object())
        consultas = []
        monkeypatch.setattr(sitio, "_consultar_cloudflare", lambda secreto, token, ip: consultas.append((secreto, token)) or token == "bueno")
        r = _post({**COMPLETO, "correo": "ts368@example.test", "cedula": "109990333"})
        assert r.status_code == 400 and "robot" in r.json()["detail"] and not consultas
        r = _post({**COMPLETO, "correo": "ts368@example.test", "cedula": "109990333", "turnstile": "malo"})
        assert r.status_code == 400 and consultas[-1] == ("0x4AAAAAAAsecreto", "malo")
        monkeypatch.setattr(demo, "_bienvenida", lambda info, nombre: True)
        r = _post({**COMPLETO, "correo": "ts368@example.test", "cedula": "109990333", "turnstile": "bueno"})
        assert r.status_code == 200 and r.json()["prueba"] is True
        # si Cloudflare no responde, no pasa (mejor rechazar que dejar entrar robots)
        def caida(secreto, token, ip):
            raise OSError("sin red")
        monkeypatch.setattr(sitio, "_consultar_cloudflare", caida)
        assert _post({**COMPLETO, "correo": "ts2368@example.test", "cedula": "109990444", "turnstile": "bueno"}).status_code == 400
        c.put("/api/admin/sitio", json={**cfg, "prueba": {"automatica": False, "dias": 30, "turnstile_sitio": "", "turnstile_secreto": ""}})
        assert sitio.leer()["prueba"]["turnstile_secreto"] == "" and "cf-turnstile" not in c.get("/prueba-gratis").text
    finally:
        app.dependency_overrides.clear()
        sitio.ARCHIVO.unlink(missing_ok=True)
